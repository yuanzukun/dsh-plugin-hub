# Changelog

本项目遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 与 [语义化版本](https://semver.org/lang/zh-CN/)。

## [0.6.2] — 2026-11-27（修复运行中排队/插话跟随宿主设置与用户消息 Markdown 兼容 dsh-rewind）

### 修复

- **运行中发送跟随 DSH「运行中按 Enter 的行为」设置（Issue #18）**：此前接管后的输入框统一走 `actions.submit()`（宿主内固定为排队）且 `Toolbar` 硬编码返回 `'queue'`，导致宿主「插话 / 排队」设置失效。现新增 `src/client/submission.ts`，通过 `slots.entries('conversation.composer.bar')`（`inject(undefined)`，无会话上下文副作用）与 `settings.general.item`（`composer-enter`）订阅宿主实时 `hooks.busyEnter`（旧 0.2.0 宿主缺席时安全回退 `'queue'`），在 `CodinputBar` / `SidebarCodinputBody` 派生 `steeringAvailable`，`CodinputSurface` 改走 `keyboard.submit(primarySubmitMode, source)`，`Toolbar` 主按钮标签实时跟随切换「插话发送 / 排队发送」（覆盖普通、悬浮、侧栏三态）。
- **开启「用户消息 Markdown 渲染」与 `dsh-rewind` 等插件共存（Issue #19）**：此前 `UserMessageMarkdown` 以 `priority: -1` 遮蔽 `conversation.chat.node` 的 `user` / `steering` 条目，导致同样包装该槽位默认条目的 `dsh-rewind-plugin` 无法挂载撤回按钮。现于 DSH 0.2.2+ 改为接入 `uiConversation.userText` 规则与 `conversation.user.text.node` 槽位，完全让出 `conversation.chat.node`，使 `dsh-rewind` 等节点包装插件及官方附件、操作行与引用划词完整保留；规则自动跳过 `QueueDock` 与 `/goal` 输入卡，并复用 `file` / `skill` 条目注入动作；旧 0.2.0 宿主无 `uiConversation` 时仍自动回退 `conversation.chat.node`。

### 优化

- **品牌图标精修**：优化品牌图标几何对称性与小尺寸清晰度（`f467fd5`）。

### 质量与验证

- `scripts/test-unit.mjs` 扩充至 **16/16** 组零依赖单元测试（新增 `userTextMarkdownRule` 与 `submission` 用例）。
- `npm run prepublishOnly`（`check:popup` + `npm test` 16/16 + `npm run build` + `tsc --noEmit`）全过。
- 隔离宿主 `@deepseek-ai/dsh@0.2.2-rc.3` 实测：`probe.mjs` 三形态 **23/23**、`probe-switch.mjs` 会话切换 **6/6**，以及用户消息气泡 `user-text` 渲染/切换与运行中 `steer` / `queue` 实测全过（0 插件错误）。
- `lib/client.js`：`3,543,263 B`（gzip `1,156,698 B` / brotli `958,311 B`），md5 `4dba2909c334b32efec6ad790011e8bd`，sha256 `f78c5c2fcfb2241091aa5c6261f7462827a0326ce1190626aeb2d7dc0d9e70bf`。

## [0.6.1] — 2026-11-25（修复拖放 HTML 等文件时源码进入草稿与文档预览图更新）

### 修复

- **拖放 HTML / 文本类文件进编辑区仅添加附件，源码不再进入草稿（PR #17，贡献者 `@RaM-bugourp`）**：启用官方附件座位（`officialAttachments = true`）时，`CodinputSurface` 的捕获阶段 `drop` 会让权给官方 `document` 级附件监听；但事件先经过 ShadowRoot 内 CodeMirror `contentDOM`，导致 CM6 默认 `drop` 处理器对 `.html` / `.txt` 等文件调用 `FileReader.readAsText` 并把文件内容写入草稿。现于 `src/client/cm.ts` 的 `EditorView.domEventHandlers` 中增加 `drop: (event) => dragHasFiles(event.dataTransfer)`，含文件载荷时阻止 CM 默认读取，同时**不**调用 `stopPropagation()` 以保留事件冒泡给官方 `document` 监听；普通纯文本拖放、粘贴与编辑器内选区拖动仍维持原语义。

### 文档与资源

- **预览图与 README 排版刷新**：中英文 `README` 换用浅色主题四态预览图（`assets/preview-*.webp`），修复开头徽章与标题居中对齐，并将赞赏码缩小至 `280×280`（`assets/donate-qr.jpg`）；同步更新中英文 README 单测计数为 14 组，并将拖放验收要点整理入 `TESTING.md` §4 附件行清单。

### 质量与验证

- `scripts/test-unit.mjs` 扩充至 **14/14** 组零依赖单元测试（新增 `cm & attachments` 文件拖放拦截用例，验证 `dragHasFiles` 与 `EditorView.domEventHandlers.drop` 拦截含 `Files` 拖放且保留冒泡）。
- CI（`check:popup` + `npm test` 14/14 + `npm run build` + `tsc --noEmit` + `lib/` 与源码逐字节一致性校验）全过。
- `lib/client.js`：`3,539,052 B`（gzip `1,155,928 B` / brotli `957,251 B`），md5 `fb7fdc3904c172a44529977aab45dd9e`，sha256 `8d687781f4ccf6e7021154925eec44f861cd5f6887b1acecca3564b6b5aade30`。

## [0.6.0] — 2026-11-23（3D 悬浮、GPU FLIP 丝滑过渡、底部状态栏交回官方槽位与插件元信息完善）

### 新增

- **3D 悬浮模式（`src/client/float3d.ts`、设置 →「3D 悬浮」，默认关）**：悬浮模式下以视口中心为球心呈球面微倾朝向（居中严格 0° 保持代码编辑清晰），拖动时 Z 轴浮空并随平滑速度矢量产生迎风惯性倾摆，松手由欠阻尼弹簧自然落回；实时输出动态投影、内凹边缘高光与镜面微高光，并尊重 `prefers-reduced-motion`。`overlay-host.ts` 同步增加 3D 透视下的两次不动点坐标修正，确保 `/` `@` 菜单与官方弹层在 3D 倾角下仍贴合卡片。
- **全场景 GPU 合成层 FLIP 模式切换过渡（`src/client/float-flip.ts`）**：`normal ↔ float / side` 切换时仅改一次布局，通过一次性 `ResizeObserver` 紧随宿主 `ChatViewport` / `seatObserver` 捕获异步 `scrollTop` 与 `--dsh-composer-height` 更新，在 GPU 合成层协同动画化聊天内容区、`composerSeat::before` 渐变底板（`scaleY`）、固定 GPU 幕布、归位卡片磁吸与回底浮动按钮，零逐帧回流、零首帧上跳闪动。
- **拖动脱出与底部归位区引导（`src/client/float-dock.ts`、`FloatingShell.tsx`）**：卡片顶部新增居中抓取条与官方 `Tooltip` 提示；拖动期间在底部展示自动避让状态栏的虚线归位区及 `pulling / idle / armed` 三态反馈，松手区分 `enter-float / dock / cancel-detach / move-float` 并触发卡片脉冲反馈。
- **插件多语言元信息与文档刷新**：新增 `locale/zh.json` 与 `locale/en.json`（含 `meta.title`、`meta.description` 与 `detail` 指向 `README.md` / `README.en.md`），重写 `package.json` `description`（移除「DSH 插件（桌面版，适配 DSH 0.2.2-rc.3）」前缀）并将 `locale/`、`README.md`、`README.en.md` 纳入 `package.json` `files`；精简优化中英文 `README`，刷新 4 张预览图（`assets/preview-*.webp`）。

### 变更

- **底部状态栏原位常驻，彻底交回官方槽位（`StatsRow.tsx`、`ComposerDockSlot.tsx`）**：`StatsRow` 从 `CodinputSurface` 迁回 `CodinputBar` 对话区底部原位锚定，不随 `normal / float / side` 切换移动或卸载重挂，窄窗自动折行防叠字；移除自绘 `src/client/stats.ts` 统计胶囊与三详情面板，完整保留官方 `[data-composer-dock="true"]` 与 `<div data-slot="conversation.composer.dock" style="display: contents">` DOM 结构，使官方统计以及 `dsh-desktop-statusbar`（替换型）、`dsh-cost-meter`（追加型）等第三方插件按官方语义原样生效；仅保留官方非槽位上下文占用小圈（`ContextGauge`）。

### 质量与验证

- `scripts/check-popup-contract.mjs` 新增 §9 契约断言（校验 `StatsRowMemo` 锚定在 `CodinputBar`、`ComposerDockSlot` 完整镜像 `composer.dock` 且无自绘统计胶囊）；`scripts/test-unit.mjs` 扩充至 **13/13** 组单元测试（覆盖 `prefs.float3d`、`float3d`、`float-dock`、`float-flip`）。
- `npm run prepublishOnly`（`check:popup` + `npm test` 13/13 + `npm run build` + `tsc --noEmit`）全过。
- 隔离宿主 `@deepseek-ai/dsh@0.2.2-rc.3` + 无头 Edge CDP：
  - `scripts/verify/probe.mjs` 三形态 **23/23** 通过（0 插件错误、0 console 错误）；
  - `scripts/verify/probe-switch.mjs` 会话切换 **6/6** 通过（0 插件错误、0 console 错误）。
- `lib/client.js`：`3,539,025 B`（gzip `1,158,827 B` / brotli `957,447 B`），md5 `0cd19246a28cf0588e655f3311f659c6`，sha256 `ffa78f1635ec49649505f836df785a2cca382641bf3357d10132fbf5482e0204`。

## [0.5.3] — 2026-11-20（长按回车/退格满帧流畅优化与全项目架构整改）

### 性能（编辑器长按 Enter / Backspace 满帧流畅）

- **编辑器与行列指示器迁入 open ShadowRoot 隔离（根治宿主 `:has()` 级联重算）**：CDP Tracing 实测表明，Light DOM 下每次增删行都会触发宿主 `.wSkVaW_scrollBody` / `[data-files-navigator-row]` / `html` 上的 `:has(...)` 规则与 166 张宿主样式表（5,987 条规则），在含 2,000 个聊天节点的会话中单键 `RecalcStyle` 耗时 25–30 ms。现通过 `ensureEditorShadow` 将 CodeMirror `EditorView({ root: shadow })` 与 `.dci-pos` 挂载至 `.dci-cm-host` 的 open ShadowRoot，截断宿主 `:has()` 失效链，样式重算复杂度与聊天历史长度彻底解耦为 O(1)；ShadowRoot 内复刻宿主 5 条滚动条规则（继承 `--dsh-scrollbar-*` / `--dsw-*` 变量），浅/深色换肤视觉一致；`.cm-scroller` 启用 `contain: layout style paint`。同步适配分屏被动滚动监听（`onEditorScroll`）与附件粘贴 `composedPath()`。
- **移除 `drawSelection()`，改用原生合成器光标**：单光标编辑器移除 CodeMirror JS 自绘光标层（省去每次按键一次同步 `coordsAtPos` 布局 + 光标动画样式失效），直接使用 `.cm-content` 的 `caret-color`（品牌强调色）与原生 `::selection`。
- **热输入路径零 React 重渲染、零整篇字符串分配**：`.dci-pos` 改为 ShadowRoot 内 `rAF` 合并直写 `textContent`；`cm.ts` `updateListener` 与 `liveDocs` 直接传递不可变 `Text` 树，仅在空闲同步、发送、预览停手 140 ms 或触发 `/` `@` 菜单时惰性 `toString()`；非触发词上下文短路跳过 `triggers.track(fullText)`；草稿空/命令态通过 `classifyDoc(doc)` O(1) 判定。
- **自动增高态连按稳高**：未手动拖高且处于自动增高态时，检测到 `event.repeat` 连按 `Enter` / `Backspace` / `Delete` 期间锁定 `.dci-body` 精确浮点高度（连按 `Enter` 至多每 200 ms 阶梯扩展一次，连按 `Backspace` 保持视口稳定不跳动），避免宿主 `seatObserver` 每行改写继承变量 `--dsh-composer-height` 触发整页样式重算；松手 `keyup` 或短暂空闲后立即交回 CSS 自适应。
- **隔离宿主实测（`0.2.2-rc.3` + 2,000 可见聊天节点 + 无头 Edge CDP）**：
  - 200 行连按 Enter / Backspace：单键 p50 **35.3 / 36.1 ms → 7.0 / 6.4 ms**，帧间隔 p95/max **33.4 / 100 ms → 16.7 / 16.8 ms**（满帧 60 fps），`RecalcStyle` 总耗时下降 **96%–97%**；
  - 600 行与分屏预览 200 行：单键 p50 **6.1–6.8 ms**，帧间隔锁在 **16.7–16.8 ms**（与草稿长度、聊天长度均无关）；
  - 空草稿自动增高（1→35 行）与自动收缩（35→1 行）：单键 p50 **34.7 ms → 6.8 / 6.7 ms**，收缩阶段全程满帧 60 fps。

### 架构与缺陷修复

- **响应式状态与插件生命周期收口**：`services.ts` 升级为响应式订阅存储（`subscribeServices` / `useService`）；`prefs.ts` 增加冻结内存快照缓存与跨标签 `storage` 同步，消除热路径重复 `localStorage` 读写；`i18n.ts` / `barinject.ts` / `sideinput.ts` / `slotEntry.tsx` 统一改用 `useSyncExternalStore` 稳定快照；`index.tsx` / `command.ts` / `attachments.ts` 的全局订阅、定时器、`console.error` 钩子与隐藏 `<input type="file">` 全部纳入 `ctx.effect` 严格回收。
- **组件拆解与多处隐蔽 Bug 修复**：
  - 从 `CodinputBar.tsx` 拆出独立 `FloatingShell.tsx`，修复悬浮拖放首帧视口/局部坐标夹取跳变，补充 `data-dragging` 态、视口缩放重夹取与卸载清理；
  - `slotEntry.tsx`：修复 `snapshotHookFor` 订阅引用抖动、`listRows` 丢弃多个 `id === undefined` 条目、`EntryBoundary` 换会话不自动复位、`entryInjectCache` 无上限增长（加 LRU 16 上限）及 `useStableKit` 误比对未过滤 props；
  - `VoiceActivity.tsx` / `AttachmentsSeat.tsx` / `ModelLabel.tsx`：移除绕过 0.5.2 会话绑定代失效的旧 `useMemo` 包装；
  - `PermissionMenu.tsx`：修复 `disabled` 判断反转并把 `RiskConfirmation` 迁入 portal；
  - `CodinputSurface.tsx` / `Toolbar.tsx`：向 `openCommandMenu` 传递 `keyboard`（修复 `draftRev: 0`）、修复仅预览态切会话残留旧草稿、卸载时回收顶边拖拽监听、修复发送按钮 steer/queue 宿主页签键；
  - `cm.ts` / `EditorPane.tsx`：隔离 `editableCompartment` 防止偏好变更意外解锁只读态、修复切会话后偏好/锁定 effect 钉在旧 view、自定义 `lineBreakHotkey` 正确替换当前选区；
  - `StatsRow.tsx` / `stats.ts` / `MenuSurface.tsx` / `ExpandBall.tsx` / `overlay-host.ts` / `settings.tsx` / `hotkey.ts`：补全语言切换联动与时长本地化、去重 `contextPressure` 订阅、菜单支持 `Escape` 关闭、`ExpandBall` 支持标题栏晚挂载、清理 `overlay-host` 内联残留、修复字体输入框无法清空与 `mod` vs `ctrl`/`meta` 冲突检测；
  - **Markdown 管线**：消除 `commentBlockExtension` / `calloutExtension` 的 O(N²) 拆行、无脚注时快路径返回、缓存 DOMPurify 配置并统一 SVG 净化、Mermaid 改为单 ref 计数主题监听 + 节点级 `data-dci-md-theme`、`renderMathNode` 幂等化、`chipTextNodes` 跳过 `.katex` / `.dci-md-mermaid` / `.dci-md-codebar` / `svg` / `style`。
- **构建、打包与测试体系**：
  - `package.json` 将 9 个已由 esbuild 打入 `lib/client.js` 的前端依赖迁至 `devDependencies`，用户安装本插件达到 **0 运行时传递依赖**；
  - `scripts/build.mjs` 改为动态扫描 Mermaid layout-switch chunk（移除硬编码文件名）并新增构建期 CSS 模板压缩（`lib/client.js` 体积由 3,554,543 B 降至 3,524,758 B，省 ~30 KiB）；
  - 清理 13 个未用 i18n 键、11 个未用图标组件及重复旧 CSS；
  - 新增零依赖单元测试套件 `scripts/test-unit.mjs`（10 组用例覆盖 hotkey / prefs / stats / slotEntry / markdown / sideinput & barinject）并接入 `prepublishOnly` 与 GitHub Actions CI；
  - `scripts/verify/` 探针（`page-helpers.mjs` / `probe-core.mjs` / `probe.mjs`）适配 ShadowRoot 穿透查询。

### 验证

- `npm run prepublishOnly`（`check:popup` + `npm test` 10/10 + `npm run build` + `tsc --noEmit`）全过；二次重建 `lib/client.js` SHA-256 确定性一致。
- 隔离宿主 `@deepseek-ai/dsh@0.2.2-rc.3` + 无头 Edge CDP：
  - `scripts/verify/probe.mjs` 三形态 **23/23** 通过（0 插件错误、0 console 错误）；
  - `scripts/verify/probe-switch.mjs` 会话切换 **6/6** 通过（0 插件错误、0 console 错误）；
  - CDP 连按基准与分屏视觉截图复核通过。

## [0.5.2] — 2026-11-18（修复切换会话后 `/` 候选面板不再出现）

### 修复

- **切换会话两次后 slash 面板唤不出（报障：对话 1 → 对话 2 → 对话 1 后输入 `/` 无菜单）**：根因是镜像座位的 inject 结果缓存（`src/client/components/slotEntry.tsx` 的 `entryInjectCache`）只按 `sessionId` 缓存。宿主在会话重新驻留时会重建该会话的 scope / binding（`sessions.binding` 换新对象），官方触发管线控制器随之换代；缓存的 inject 面仍指向上一代控制器——编辑器在**新**控制器的 menu store 上 track 出 open，`MenuView` 却订阅上一代已关闭的 store，于是「状态 open、面板永不渲染」（无任何报错，刷新页面即恢复）。现缓存按 **sessionId × 会话绑定代** 失效：代变即重新 inject。
- 同一机制下所有镜像座位一并受益：overlay 座位里的 slash 菜单 / `/model`、`/permission` 弹层 / feedback 弹窗，以及模型座、权限/计划座、附件座；顺带修掉「inject 一次性失败被永久缓存」（同一代内仍只尝试一次，换代重试）。
- 这类失效没有异常可抓（`__dshCodinputErrs` 全程为空、`slot.inject` 无诊断），不能以「没报错」判定正常；诊断口只反映 `slot.entry` / `slot.inject` 一类硬失败。

### 验证

- 新增 `scripts/verify/probe-switch.mjs`：隔离宿主 + 本地 mock Messages 端点 + `dsh headless` 造两个**非空**会话 + 无头 Edge，往返 A→B→A 与 A→B→A→B→A 后断言 `/` 菜单每次都在、切回后 `/model` 弹层照常打开。**红/绿双向验证**：未修复产物（v0.5.1）W3/W4 红（菜单 6s 内不出现，控制器状态却是 open），修复产物 6/6 全绿。
- `npm run check:popup` / `npm run typecheck` / `npm run build` 三门禁通过；`lib/client.js` 由当前源码重建。
- 原三形态探针 `scripts/verify/probe.mjs` 在修复产物上 **23/23 全通过**。运行中定位到该探针长期偶发失败（首帧/侧栏键入不落、清草稿失败）的真实原因：隔离宿主没有凭据时会弹「开始使用」凭据门，模态盖住输入面并吞掉合成键入。现 `scripts/verify/lib/probe-host.mjs` 给隔离宿主注入**占位凭据**（不读真实凭据、端点指向本机丢弃端口，不联网），该 flake 消失；用未修复产物对照亦复现同一 flake，与本次改动无关。

## [0.5.1] — 2026-11-17（修复 0.5.0 三处形态回归，补齐侧栏形态的 rc.3 能力）

修复 0.5.0「官方条目镜像」改造后暴露的回归（用户报障：悬浮形态 slash 面板不能自适应调整位置、右侧栏形态触发不了 slash 面板、切换形态偶发草稿丢失/不同步），并把 0.5.0 只在主输入形态上接的 rc.3 能力补到侧栏形态。

### 修复

- **悬浮形态 `/` `@` 候选与 `/model` `/permission` 弹层不能自适应位置（报障 #1）**：0.5.0 改为官方条目内联渲染后，官方 `bottom: calc(100% + 4px)` 的「向上长 + 只钳顶部」假设在悬浮卡片上不成立——卡片被拖到视口顶部时官方 `useAnchoredMaxHeight` 会把菜单压成 0 高，菜单也可能落到视口外。新增 `src/client/components/overlay-host.ts`：**只在 float / side 形态**把 overlay 锚点改为卡片内的固定定位自适应宿主（normal 形态几何完全不动），逐帧量卡片矩形，在卡片上/下/左/右四向选位（沿用 0.4.x 验收算法：优先能完整容纳、按空间取最大，都放不下时压缩到该侧空间并在菜单内滚动），菜单夹进视口、与卡片零交叠（极小窗口放不下最小可用尺寸时允许少量重叠，与 0.4.x 验收口径一致）、跟随悬浮拖动/缩放与窗口变化；官方条目的 DOM/键盘/焦点/无障碍与「点卡片内不关闭」语义保持原样（宿主仍在 `[data-composer-card]` 子树内，官方 dismiss 的 `closest` 判定不受影响）。官方 `useAnchoredMaxHeight` 的应用级上限在自适应宿主下改由 `--dci-overlay-maxh` 覆盖。
- **右侧栏（side）形态 `/` 候选与弹层不可见（报障 #2）**：侧栏卡片铺满右侧栏 pane，官方绝对定位浮层被 pane 的 `overflow:auto` 裁剪。自适应宿主让浮层落到**右侧栏左侧的对话区**（`data-placement="left"`；该侧放不下时退上/下/右侧），完整在视口内、不遮编辑区；`/model`、`/permission` 与第三方 overlay 下拉条目同样生效。
- **切换形态草稿丢失 / 不同步（报障 #3）**：
  - 编辑器挂载不再从空文档起步：按「快照 / 实时文档 / 宿主草稿」三方对账——刷新页面、首次开启接管、切回会话、退出后再进入都以宿主草稿或实时镜像起步（0.5.0 的空起步会让首键顶掉持久化草稿）；
  - 形态切换跨 React 树不是原子操作（侧栏 body 可能先挂载、主输入面下一拍才卸载）：新增同键挂载实例计数 + 实时文档镜像（`cm.ts` 的 `enterEditor` / `leaveEditor` + `liveDocs`），新实例先挂载时用实时文档而不是空/旧快照起步；
  - 旧实例卸载不再回写过期文本：只有「仍持有该会话最新文档」的实例才 publish / 暂存快照，共享句柄（`editorCtlRef` / `viewRef`）按身份清理；
  - 新增卸载时宿主读数（published / stale）区分「同一提交内重挂载的滞后回声」与「离开期间官方侧被外部改写」：滞后回声本地优先，外部改写（在官方输入框里改过、`/codinput` token 剥离、提交清空、其它插件 `setDraft`）宿主优先，不再互相吞字。
- **发送按钮同帧丢输入**：发送手势的判空改用编辑器同步读取（`EditorControl.getDraft()`）。修复「最后一笔输入与点击发送落在同一帧」时 `draftRef` 还是上一拍的空文本、误走队列 Steer 导致消息不发的问题。
- **侧栏形态补 rc.3 能力（0.5.0 遗漏）**：`conversation.composer.bar` 注入面里的 `retry` 与 `registerFileIntake` 经 `barinject.ts` 按会话转存给侧栏 body，`ContinueState` 抽到 `continuation.ts` 两处共用——侧栏形态现在也有官方**「继续生成 / 重试」主按钮**与**文档级粘贴路由**；开标签即启用时 bar 条目晚于侧栏 body 挂载也能等到注入面。契约自检 `check:popup` 增加对应断言。

### 验证

- `npm run check:popup` / `npm run build` / `npm run typecheck` 三门禁通过；`lib/client.js` 由当前源码重建（发布构建、无 sourcemap）。
- 隔离宿主 `@deepseek-ai/dsh@0.2.2-rc.3` + 无头 Edge CDP 三形态探针（normal / float / side，`scripts/verify/probe.mjs`）**23/23 全通过**（`__dshCodinputErrs` 与 console 全空）：
  - normal：`/` 候选在卡片上方（`bottom = card top − 4`、宽度 = 卡片宽），`/model` 弹层同官方几何，Esc 关闭；
  - float（`floatY=16/655/floatX=12`）：自适应宿主 `data-mode="dd"` + `data-placement=bottom/top/right`，菜单 400px 高、完整在视口、与卡片零交叠、跟随拖动（拖动中重新选位 right→bottom）；`/model` 弹层同宿主；
  - side：卡片在右侧栏 tab 内，`/` 候选与 `/model` 弹层 `data-placement=left`，菜单右边缘 772 ≤ pane 左边缘 775（落在对话区），400px 高不被裁剪；
  - 草稿：normal→float→normal、normal→side（含关标签回 normal）编辑器与官方草稿一致；输入后 **18ms** 拖成悬浮（<500ms）不丢字；float→normal 拖回不丢字。
- 桌面实机按 `TESTING.md` §8.1 目检（Continue 重试需真实失败轮次、侧栏文档级粘贴需真实剪贴板）。

### 已知限制（0.5.1）

- 自适应宿主只接管官方下拉形态（绝对定位、左右贴边的 `MenuView` / `PopupSelectView`）；第三方 overlay 条目若是自定义绝对定位浮层，仍由其自身几何决定。
- 附件入口仍走插件草稿附件链路：桌面端拖**文件夹** / 非图片路径引用行为与官方输入框（bar 注入的 `addFiles`）不完全一致（0.5.0 起的既有范围）。
- 悬浮 / 侧栏容器若被第三方以 `transform` 包裹（非常规布局），宿主会按实测包含块回补坐标；若该祖先同时 `overflow` 裁剪，浮层仍可能被裁（与官方 InputBar 内联浮层同源限制）。
- 侧栏形态的 bar 注入面（`retry` / `registerFileIntake`）按**当前会话**转存：分栏里同时存在多个会话的 Codinput 标签时，非当前会话的标签不保证拿到这两个注入面（Continue/文档级粘贴在该标签内可能缺席）。

## [0.5.0] — 2026-11-14（含 rc.3 Continue/Retry、附件座、文档级粘贴补齐）

补上 0.5.0 遗留的已知缺口（「还有什么已知的也要补上」），全部延续「能不复刻就不复刻」原则：

### 新特性（rc.3 官方行为补齐）

- **「继续生成 / 重试」主按钮（rc.3 官方 InputBar 新增）**：本会话有失败轮次（`conversationContinuation` 投影）且输入面「干净」时，主按钮改为官方**三角 Continue** 图标 + 「继续生成」文案，点击调用官方 `retry(failureSeq)`（重新提交空输入重试该轮）。条件逐项对齐官方 `primaryRetries`：非运行中、无 subagent、草稿与附件皆空、无待输入的人类问题（`inbox.next-step` 无 user 源）、会话打开态、无在途提交、会话未移除、`phase === 'plain'`、队列为空、`retry` 可用；同时按官方 `primaryDisabled` 修正非停止分支（`(!primaryRetries && empty) || disabled || machineBusy`）。三角以官方 `.continueIcon` 的 `scale(1.5)` 绘制，Tooltip/aria 文案走官方 `input.continue` 同文案。
- **附件座改镜像官方 `ComposerAttachments`**：`conversation.input.attachments` 不再自绘——条目可镜像时直接渲染宿主官方组件：图片 64×64 缩略图/原图灯箱、文件卡（类型 glyph + 名称 + 体积）、上传进度、失败重试、拖放浮层与**文档级拖放监听**全部官方实现。owner props 与官方 InputBar 逐项对齐（attachments / canAcceptDrop / onAddFiles / onRemoveAttachment / uploads / onRetryFile / uploadFailureText / dropLimits）。旧宿主（无该官条条目）、inject 不可复现或组件崩溃 → `fallbackOnMissing` 回退 0.4.x 自绘 `AttachmentRail`（不空、不崩）。
- **文档级粘贴路由（rc.3 `registerFileIntake`）**：接管卡片注册进宿主的 composer 粘贴路由（`occurrence: main/embedded`、`accepts` 跟随禁用/忙态、`add` 走本插件草稿附件链路）。没有聚焦可编辑控件时粘贴文件，现在会正确路由进本 composer；编辑器内粘贴仍由本插件落地（CodeMirror 不处理文件粘贴），卡片其它区域让位官方路由，避免重复添加。拖放同理：官方附件条目接管时，卡片层拖放/粘贴处理器自动让位。
- **`occurrence` 透传**：rc.3 bar owner props 新增的 `occurrence` 原样交给粘贴路由；`useProjection` 增加官方 rc.3 的「带选择器」重载（`useProjection('inbox', sel)`）。

### 验证（隔离宿主 `@deepseek-ai/dsh@0.2.2-rc.3` + 无头 Edge CDP）

- 0.5.0 全部项目回归通过（卡片/overlay 锚点、官方 `/` 候选与 `/model` `/permission` 弹层、官方 ModelSelect、官方 Tooltip、行号 39px 三位预留）；`__dshCodinputErrs` 与 console 全空。
- **附件座实测**：向页面 dispatch 一个真实 `DataTransfer` 的 drop（`probe.txt`, 13B）→ 卡片内出现官方 FileCard（「probe.txt / TXT 13B」），自绘 `.dci-attach-*` 元素数为 **0**，证明渲染与拖放链路都走官方条目；截图见验收记录。
- **继续生成**：无 API Key 的隔离宿主无法制造失败轮次，按钮逻辑以类型/契约自检与代码逐项对齐保证（`primaryRetries` 条件、`retry(failureSeq)` 调用、disabled 分支均有断言）；桌面实机按 `TESTING.md` §8.0 复验。
- **文档级粘贴**：注册/让位路径静态与契约验证通过；合成 `ClipboardEvent` 在 Chromium 里不携带可路由的 `clipboardData`，真实粘贴行为需桌面/浏览器实机目检（已写入已知限制）。

### 修复（体验）：长按回车 / 删除不再卡顿

- **根因**：此前每次本地输入都会把整篇草稿经官方 `inputActions.setDraft(text)` 上报一次。官方该接口是**整篇替换**——重写整棵 Lexical 文档（`clear()` + 逐行重建段落）、重算投影、序列化快照、触发草稿持久化，单次成本 **O(草稿长度)**。长草稿下连按 Enter/Backspace 变成每键 O(n)：隔离宿主演示 600 行（约 22KB）草稿单次 `setDraft` ≈ **52–64ms**，主线程被占满，表现为明显掉帧（60 行/120 行时依次减轻）。
- **修法**：把「写入官方输入机」从逐键改为**按需**——纯输入期间只更新插件本地镜像（编辑器 + 界面），宿主往返只发生在：
  1. **空闲去抖 500ms**（停手后同步一版，保证草稿持久化与其它插件读数最终一致）；
  2. **宿主即将读写草稿的语义动作前同步 flush**：发送（编辑器手势 / 工具行发送钮）、命令草稿的空格 claim、候选菜单的键盘 Enter/Tab 与遮罩层鼠标按下（`pointerdown` 捕获相位先 `flush + 重新 track`，保证 pick/claim 的 `span.draftRev` CAS 命中）、指令按钮；
  3. **触发词起点**（当前 token 恰好是刚敲下的单个 `/` 或 `@`）——候选菜单打开前先把宿主草稿对齐，之后的查询串输入不再逐键上报。
  界面按钮形态（空草稿 / 命令草稿 / 发送禁用 / Continue 重试可显性）改由本地镜像驱动；官方草稿回写（pick、claim、提交清空、权限草稿交换）仍是唯一外部写入口，按公共前后缀把光标落在被改写片段之后，避免 pick 后候选菜单复现。
- **实测（隔离宿主 0.2.2-rc.3 + 无头 Edge CDP，600 行草稿，30 次/秒连按）**：Enter 帧间隔 p50 **50ms → 16.7ms**、单键 p50 延迟 **37.6ms → 10.7ms**；Backspace p50 延迟 **71.9ms → 6.7ms**（此前 600 行时每个键都是一次 60ms 级长任务，现在输入期间零宿主往返、零长任务）。120 行草稿与普通字符连打同样回到 60fps。
- **分屏预览**：预览开启时「编辑 → 预览」的滚动同步改为 140ms 去抖（连按期间不再把整篇预览 markup 拉进布局），并为预览栏建立独立合成层，避免键入重绘连带整篇预览；预览正文仍只在停手后刷新。
- **切会话 / 退出接管的草稿安全**：本地草稿尚未同步时切换会话或关闭接管，收尾 flush 写回**原会话**的输入机（不是新会话）。隔离宿主实测：A 会话输入后立即切到 B，B 草稿保持为空，切回 A 草稿完整还原。
- **行为回归（隔离宿主实测）**：`/` 候选（鼠标点选与 Tab/Enter 选取）、`@` 引用（鼠标点选）、发送手势与工具行发送、空草稿禁用、官方外部改写回灌、鼠标/键盘 pick 后的 `draftRev` CAS 全部通过；`__dshCodinputErrs` 与 console 为空；空格 claim 行为与官方输入框一致。

### 发布前收尾（0.5.0 终版）

- **页面生命周期兜底**：`EditorPane` 挂载期间监听 `pagehide` 与 `visibilitychange(hidden)`，在刷新 / 关窗 / 最小化前把最后几个字符同步给**当前会话**的官方输入机（沿用 mountActions 归属，不会写进切换后的新会话）；失焦与卸载 flush 保留。隔离 rc.3 web 宿主实测：手动派发 `pagehide` 后宿主草稿立即变为最新输入；web 宿主本身不持久化草稿（官方输入框同样刷新即空），桌面端跨刷新/重开由宿主持久化承接，实机复验见 TESTING §8.0。
- **外部整篇写入不覆盖本地未同步输入**：官方/第三方其它来源的整篇 `setDraft` 到达时，若本地还有未同步文本则先 flush 本地草稿（本地优先），避免「用户正在输入 + 其它插件写草稿」互相吞字；pick / claim / 提交清空等宿主动作前已有 `flushAndTrack`，走到回写时本地不 dirty，行为不变。
- **CI 门禁**：`npm run build` 增加 `prebuild` 生命周期，先跑 `check:popup`（官方条目镜像 + overlay/模型/附件座位 + rc.3 continue/retry + 按需写回契约），CI 既有的 Build 步骤因此自动卡住契约回归；`prepublishOnly` 原有链路不变。
- **死代码清理**：删除已下线的自绘组件（SlashMenu / PopupSelectView / ImageLightbox / 旧 stats 行）遗留的 102 行 CSS，仓库内 `dci-*` 类名已无未引用项。
- **文档 / 元数据口径**：`package.json` description 改为「桌面版，适配 DSH 0.2.2-rc.3」，移除 `webui` 关键词；README 中英同步宿主 npm dist-tag（`latest` = `0.2.2-rc.1`、`next` = `0.2.2-rc.3`，0.5.0 完整能力需 rc.3），并补 rc.3 目标版本验证行；TESTING 增加页面生命周期与第三方座位清单。
- **第三方座位实测（隔离 rc.3 宿主）**：装 `dsh-context@0.84.1`（占用 `conversation.input.overlay`，id `context-modal`）与 `@knyazevai/dsh-client-ui-attachment@0.2.6`（`conversation.input.attachments` 附件呈现）后，normal / float / side 三形态：`/context` 弹层可正常打开、附件 rail 渲染（单个文件卡、无重复、自绘 `dci-attach` 回退为 0）、`__dshCodinputErrs` 与 console 全空；float/side 下 overlay 锚点几何随卡片/侧栏（float 720×0 于卡片顶边，side 647×0 于侧栏卡片顶边）。

### 已知限制（0.5.0）

- `uploadFailureText` 使用官方 `attachmentErrorText` 的插件侧近似文案（宿主细化到具体 reason 的文案未逐条复刻）。
- 文档级粘贴路由为契约级实现 + 让位逻辑，合成事件无法覆盖真实剪贴板路径。
- `conversation.composer.dock` 仍只镜像第三方条目（官方 Activity/Usage 胶囊由自绘数据行承担）。


### 0.5.0 初版（架构改造：官方条目镜像）

本版本适配 **DSH `0.2.2-rc.3` 桌面版**，并把「**能不复刻就不复刻**」定为输入面的最高原则：凡是官方座位、官方弹层、官方 UI 原语可以原样复用的，一律**镜像官方条目本体**，不再自绘等价款——自绘覆盖面越小，第三方插件依赖官方输入框的能力（座位注入、键盘/焦点、无障碍、弹层几何）就越不会被本插件改写；只有 CodeMirror 编辑器与卡片外观无法避免由本插件承担，且必须逐像素对齐官方。同时**不再维护 web 宿主**（`dsh web`），只维护桌面版 DSH。

### 变更（架构：官方条目镜像，删掉自绘复刻）

- **模型座改镜像官方 `ModelSelect`**（`conversation.input.model`）：自绘模型/推理等级芯片下线，工具行模型座直接渲染 official `client-ui-model-selection` 的条目组件——两段式根菜单（模型 / 推理等级）、下钻列表、目录分组与吸顶标题、`>4` 条时的搜索框、键盘（↑↓/Enter/Tab/Esc/Shift+Tab）、焦点归还、加载/失败条带、Toast 全部是宿主同一份实现。官方组件签名里的 `renderSlot` 子座（`conversation.input.model.label` / `.options`）由插件侧按官方 renderer 语义合成后以 owner props 下发（`slotEntry.renderChildSlot`），模型名发布徽章等第三方子座条目照常显示。
- **输入区弹层改镜像官方 `conversation.input.overlay` 座位**：官方 `MenuView`（`/`、`@` 候选）、`PopupSelectView`（`/model`、`/permission` 等弹层）、`FeedbackDialog` 都是注册在该座位的官方条目；本插件不再自绘斜杠菜单与指令弹层，而是在卡片里新增与官方 `InputBar .overlayAnchor` 同构的零高绝对定位条（`.dci-overlay-anchor[data-composer-overlay]`），把座位条目原样渲染进去。弹层几何（卡片全宽、`bottom: calc(100% + 4px)`、视口/上方空间钳制）、菜单材质与动画、搜索与虚拟高亮、Esc/Tab/外部点击关闭、焦点语义全部与官方输入框一致。
- **悬停提示改用宿主 baseline 原语 `Tooltip`**（`@deepseek-ai/dsh-client-ui-primitives`，0.2.2-rc.3 的 `PLATFORM_MODULES` 共享模块，构建 external、不随包内置）：工具行的 添加/停止/发送 钮与编辑/预览开关、侧栏唤回小球、数据行上下文胶囊、用户消息复制钮等原生 `title` 全部替换为官方 Tooltip（`side:"top"`、`delayMs:500`、`portal`），样式、延迟、键盘 focus 行为、`aria-describedby`、移动端抑制与官方一致。
- **保持既有座位镜像**：`conversation.input.permission` / `.plan` / `.left` / `.right` / `.activity` / `conversation.composer.dock` 继续按官方条目镜像（0.4.x 引入的引擎不变）；`conversation.input.overlay` 从「未镜像座位」移入「已镜像」，`seats.ts` 运行时审计只保留仍未镜像的 `conversation.input.attachments`（附件行仍由自绘 `AttachmentRail` 承担，后续版本再改镜像）。
- **构建契约**：`package.json` 不新增宿主依赖（官方原语走共享模块表）；`scripts/build.mjs` 的 external 增加 `@deepseek-ai/dsh-client-ui-primitives`，`src/client/host-primitives.d.ts` 只声明用到的结构化类型面，保持「运行时零宿主依赖」。
- **契约自检更新**：`scripts/check-popup-contract.mjs` 从「自绘 popup 锚点」改为校验新架构——overlay 锚点结构与官方座位渲染、模型座镜像 + 子座合成、styles 的锚点规则、构建 external；`prepublishOnly` 链路（`check:popup` → `build` → `typecheck`）保持。

### 修复

- **点击「模型 / 推理等级」闪动一下（#1）**：自绘芯片在点击时会被焦点环/重渲染与官方菜单打开抢拍，改为官方 `ModelSelect` 后，触发钮的 `data-selection-focus`（选择后恢复焦点但不画焦点环）、CSS 锚点跟随、菜单开合状态全部由官方实现，无闪动，达到官方效果。
- **`/model`、`/permission` 面板未达官方效果（#2）**：自绘弹层与官方 `PopupSelectView` 在分组/吸顶、搜索清空、`Tab` 确认/`Shift+Tab` 返回、`↑↓` 环绕、`full access` 风险确认、加载/重试条带等细节上必然漂移；改为镜像官方 overlay 条目后逐项与官方一致（`/model` 使用模型目录 + 推理等级默认值，`/permission` 走官方命令装饰）。
- **行号多一位整体右移（#3）**：CodeMirror 行号栏宽度此前由「当前最大行号」决定（9→10、99→100 时栏宽跳变，正文整体右移）。现在 `.cm-lineNumbers .cm-gutterElement` 预留 **3 位数字宽度**（`calc(3ch + 16px)` 加 `font-variant-numeric: tabular-nums`），≤999 行时栏宽恒定、正文不再位移；超过 999 行按内容自然加宽而不是裁切。
- **悬停提示非官方（#4）**：见上「悬停提示改用官方 Tooltip」。

### 适配 DSH 0.2.2-rc.3

- **契约复核（rc.1 → rc.3）**：composer 座位名/kind/scope 全部未变，`conversation.composer.bar` owner props 新增 `occurrence`、注入面新增 `registerFileIntake` / `retry`；模型座新增 `conversation.input.model.options` 子槽；官方 `ModelSelect` 从 `useAnchoredPosition` 改为 CSS anchor positioning；input-trigger `MenuView`、commands `PopupSelectView`、permission-presets 无破坏性变更；shell `PLATFORM_MODULES` baseline 与 rc.1 相同（仍含 primitives）。
- **本插件落点**：模型座同时适配 `label` + 新增 `options` 子槽；overlay/模型弹层都改用官方 CSS 锚点实现（以 `[data-composer-card]` 为包含块），不再自己量卡片几何；bar owner props 原样透传给座位条目（`occurrence` 等新字段随 standard kit 走，第三方条目按官方契约消费）。
- **已知未覆盖（后续版本）**：rc.3 官方 `InputBar` 新增的「继续生成 / 重试」（`conversationContinuation` 投影 + `retry(failureSeq)`）尚未接入本插件的发送钮；`registerFileIntake` 文档级粘贴路由仍由本插件自己的粘贴/拖放链路承担；`conversation.input.attachments` 仍为自绘。

### 不兼容 / 范围

- **只维护桌面版 DSH**：`dsh web`（浏览器宿主）不再作为验证/兼容目标；插件仍以 `platform: "web"` 的客户端 bundle 形式注入（桌面版渲染层即该 bundle），无需额外配置。
- 目标宿主 **DSH 0.2.2-rc.3 桌面版**；更早宿主上官方条目/官方原语可能缺失，模型座/权限座会回退到 0.4.x 的自绘兜底控件（overlay 座在旧宿主上没有官方条目，弹层不会自绘——旧宿主不再支持）。

### 验证

- **静态门禁**：`npm run check:popup`（新契约自检）、`npm run build`（esbuild + `node --check` 自检）、`npm run typecheck` 全通过；构建产物自带 `require("@deepseek-ai/dsh-client-ui-primitives")` 外部解析。
- **隔离宿主运行时验收（`@deepseek-ai/dsh@0.2.2-rc.3` + 独立 `DSH_HOME`/profile + 无头 Edge CDP 探针）**，首页真实渲染、零发消息：
  - 接管卡片与 overlay 锚点存在（`[data-composer-card="codinput"]`、`.dci-overlay-anchor[data-composer-overlay]`）；`__dshCodinputShell` 全部 registered，`__dshCodinputErrs` 为空，console 无错误。
  - **`/` 候选（官方 MenuView）**：点 `+` 后在 overlay 锚点内出现官方菜单（774×341、行：文件/目标/计划/反馈/codinput/压缩/权限/模型），点外部即关闭。
  - **模型座（官方 ModelSelect）**：触发钮为官方「请选择模型」（隔离宿主无 API Key，目录为空），点击打开官方 `MenuSurface`（`aria-expanded=true`、`data-menu-material`、文案「暂无可用模型」），再点关闭。
  - **`/model` 弹层（官方 PopupSelectView）**：从候选行进入 → 官方弹层 774×79、带搜索框、点外部关闭。
  - **`/permission` 弹层（官方 PopupSelectView）**：774×143，三档「仅可查看 / 工作区内修改 / 完全权限」。
  - **官方 Tooltip**：悬停 `+` 出现官方气泡「指令（/）」（71×26，位于按钮上方），且按钮已无原生 `title`。
  - **行号三位预留**：仅 1 行时行号栏宽度即 39px（= `calc(3ch + 16px)`，默认等宽字体），证明 ≤999 行内不会随位数变化。
- 桌面实机终检（用户侧）：强刷页面后按 `TESTING.md` §8.0 清单目检模型/推理选择器、`/model`、`/permission`、行号与悬停提示。

[0.6.1]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.5.3...v0.6.0
[0.5.3]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.5.2...v0.5.3
[0.5.2]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.5.1...v0.5.2
[0.5.1]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.4.1...v0.5.0

## [0.4.1] — 2026-11-13

### 修复

- **`conversation.composer.dock` 座位被静默抹掉（issue #8）**：官方 `InputBar` 在卡片下方 `.dock` 容器里渲染该 list 座（`[renderSlot("conversation.composer.dock", {}), ContextMeter]`），bar 被 `priority:-1` 遮蔽后渲染点随官方输入框消失——注册在这里的 `dsh-cost-meter`（默认 `position="dock"`）、`dsh-quota-meter` 等条目整块 UI 不可见。现在数据行在胶囊组之前按官方 list 语义复刻该座位（`ComposerDockSlot`，与左右座共用 `InputSlotSeat` 引擎；owner props 为空、`sessionId` 缺省不渲染）。**只镜像第三方条目**：官方宿主自己也往该座注册 `ActivityPill(id activity)` / `UsagePill(id usage)`（client-ui-chat，slot catalog 与运行时双证），它们由数据行自绘胶囊顶替，整座镜像会重复渲染（隔离宿主实测 3 项 → 5 项），故按 `SHIPPED_DOCK_IDS` 过滤；没有第三方条目时行为与旧版一致。
- **未镜像座位静默失效无告警**：`input.overlay` / `input.attachments` 在接管期间仍无渲染点。新增 `src/client/seats.ts` 运行时审计：接管生效时订阅这两个座位的条目变化，发现「有**第三方**占用者但无渲染点」即写 `__dshCodinputErrs`（`slot.unmirrored`）+ console 告警；官方自带占用者（overlay 的 `slash-menu` / `command-popup` / `feedback-dialog`、attachments 的 `ComposerAttachments`——接管设计已知代价，其 UI 由自绘面或官方其它路径承担）静默跳过，干净宿主不再刷屏；同座位同占用者只报一次，插件卸载时断开订阅。占用者名按 `options.id` → 组件名 → 归属名取值，不再出现不可读的压缩短名。

### 验证

- **隔离宿主运行时验证（issue #8 修复）**：独立 `DSH_HOME` + `@deepseek-ai/dsh@0.2.2-rc.1` + 无头 Edge，加载真实关闭态会话，未发消息、未调模型。结果：装 `dsh-cost-meter@1.9.64` 后数据行出现其 dock 条目（成本按钮），修复前该 UI 无渲染点；干净宿主数据行保持 3 项（官方 Activity/Usage 胶囊不再重复）、`__dshCodinputErrs` 为空、无 console 告警；第三方 overlay 告警路径保留。报告与截图见 `docs/review/issue8-runtime.md`（仓库外文档目录，不入库）。

### 文档

- **修正 README 的租客断言**：原文「`input.attachments` / `overlay` / `dock` 生态暂无租客，留扩展位」未经核验且不成立——`dsh-cost-meter` 默认注册 `conversation.composer.dock`、`dsh-context` 注册 `conversation.input.overlay`、`@knyazevai/dsh-client-ui-attachment` 无条件注册 `conversation.input.attachments`（其首版早于该断言）。中英 README 同步改为「已镜像 / 未镜像」清单 + 宿主侧原因（slot 声明单 owner、无原生转发），并区分 `conversation.input.dock`（bar 之外、不受影响）与 `conversation.composer.dock`（bar 体内、原被抹掉）；同时补上这些座位上**官方自带占用者**（composer.dock 的 Activity/Usage 胶囊、attachments 的 `ComposerAttachments`、overlay 的指令/斜杠/反馈弹层）——镜像与审计都只针对第三方。

[0.4.1]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.4.0...v0.4.1

## [0.4.0] — 2026-11-10

本版本适配 DSH `0.2.2-rc.1` 桌面/网页宿主，带来 Markdown 渲染升级（Obsidian 风格，全内置离线）与编辑器字面字符渲染（移除字体连字）。

### 修复

- **`/codinput` 退出丢草稿**：宿主的命令通道在调用插件 `ui.run()` 之前已把命令 token 从草稿消费掉，旧实现随后 `setTimeout(80ms)` **无条件 `setDraft('')`**，把 token 之外的用户草稿整体清空。现改为**同步** `stripCommandToken()`：只在草稿确实以 `/codinput` 开头（token 后跟空白或行尾）时剥掉 token，其余内容原样保留；普通 / 悬浮 / 侧栏三形态与三条退出入口均不再丢草稿。
- **编辑器「丢字」实为字体连字**：JetBrains Mono 的连字把 `->` 画成 `→`、把 `//` 画成合并字形，用户视角是「编辑侧的 `-` / 首个 `/` 消失」，与消息记录（纯文本）不一致；隔离宿主逐键码点取证确认**文档 / 机器草稿 / 持久化草稿里的字符一个不少**，纯属渲染层。现默认关闭编辑器字体连字：`.cm-scroller` / `.cm-content` 输出 `font-variant-ligatures: none` 与 `font-feature-settings: "liga" 0, "calt" 0`；本版同时移除「字体连字」设置（理由见下）。
- **桌面端 calt shaping bug 结论**：DSH 桌面 `0.2.2-rc.1`（Electron 44.7 / Chromium 152）在「`calt`/`liga` 连字 + 后续任意字符」时会把连字第一格画空，**只在 CodeMirror 编辑器面**出现；普通 DOM（预览/用户消息/代码块）正常，web/Edge 157 正常。实测修补字体（calt 搬 liga）、12 种 CSS/合成层 workaround 均无法规避 → **编辑器保持字面是桌面端唯一稳定解**；Markdown 渲染面可以使用连字（见下）。
- **麦克风按钮消失（0.2.2 回归）**：0.2.2 的 voice-input 条目 `inject()` 新增 `hooks.microphoneDevice` / `hooks.pluginNavigation`，`VoiceInput` 需要 `useSpeechReadiness` / `useMicrophoneDevice` / `usePluginNavigation`；旧 `VoiceActivity` 只绑定 `speechReadiness`、丢弃其余 hooks → 组件内 `usePluginNavigation is not a function` 抛错被条目边界静默，麦克风整体不渲染。改为 `slotEntry.entryInjectProps` 通用折叠：`hooks` 表任意键 → `use<Name>` 选择器钩子、其余字段原样。
- **带图用户消息渲染错误（0.2.2 回归）**：0.2.2 移除了座位 prop `renderMessageImages`，用户消息附件行改由 `conversation.chat.user.content` factory 渲染、图片走 `conversation.chat.user.images` 槽位（官方 `MessageImages` 缩略图 + 原图灯箱）。旧实现拿不到新 prop → 回退文件卡 `image.png PNG 53KB` 且点击无法放大。现在附件行整体委托官方 factory（`content.text=""` → 官方只渲染附件行），图片/灯箱完全走官方；旧宿主回退链保留（`renderMessageImages` → 文件卡）。
- **Shift+Enter 换行失效（B1，@RaM-bugourp）**：旧版偏好迁移把 `lineBreakHotkey` 写成 `shift-enter`（规范分隔符是 `+`）→ 永远不匹配。迁移值改为 `shift+enter` 并修复已存坏值；另修行为层：自定义换行快捷键显式插入 `\n` 后选区未随之前移，光标留在插入点之前导致后续输入落回上一行 → `EditorPane` dispatch 现带 `selection: { anchor: head + 1 }`。
- **快捷键被旧迁移反复覆盖（B2，@RaM-bugourp）**：旧字段 `sendKey` / `lineBreakKey` / `floating` 一直留在存储里，每次加载都重新迁移、覆盖用户改过的快捷键。改为一次性迁移：迁移后删除旧字段、只写已知字段；用户已改过的新值优先。
- **偏好设置无类型校验（B3，@RaM-bugourp）**：存储写坏（坏 JSON、错误类型、数组、未知键、越界数值）会抛错或污染界面。新增 `normalizePrefs`：每字段独立类型/枚举/范围校验并回退默认，任意输入不抛错；保存前同样归一化。偏好键 `dsh-codinput.prefs.v2` → `.v3` 一次性迁移（旧字段清理、坏值修复）。
- **统计与缓存命中边界文本（B4，@RaM-bugourp）**：`formatCacheHitPercent` 完整复刻官方 0.2.2 算法（`99.9 / 99.99 / 99.999…`）；`formatTokens` K 位舍入到 1000 时进位 M（`999_950 → 1M tok`，永不 1000K）；tps/duration 补 NaN/±Infinity 防护；数据行胶囊、详情面板、上下文小圈全部走安全函数。
- **用户消息可伪造会话 chip（B5，安全，@RaM-bugourp）**：marked 默认透传原始 HTML、DOMPurify 白名单允许 `span` + `data-dci-wire` → 手写 `<span data-dci-wire="x">` 会被装饰成会话 chip。现在原始 HTML 一律转义为文本，`data-dci-wire` 只能由插件自身的 Markdown 扩展产生；伪造 span/script/onerror/style/iframe/javascript: 均不执行、不产生 chip。
- **「问答被渲染成用户侧消息」**：确认是宿主 0.2.2 官方行为——会把 `ask_user_question` 的回答渲染成官方 **question-reply 回执卡片**（DOM 带 `data-question-reply`），不是本插件气泡；插件另加防御：遇到 `source.kind === 'user-question-reply'` 的节点让位官方渲染。
- **Markdown 渲染缺陷（验收发现并复验）**：callout `question` 家族误用背景语义 token 作前景 accent（浅/深对比度仅 1.15/1.47）→ 8 家族统一改为前景派生，最低 4.93（浅）/7.87（深）；用户消息图片 `width` 属性被 legacy `.dci-umsg-md img { width:auto }` 覆盖 → 删除该规则，Obsidian 尺寸语法两侧一致；预览「后开」时 `activateMarkdown` effect 缺 `previewOn` 依赖 → KaTeX/Mermaid/复制按钮未激活，补齐依赖；用户消息 h1–h6/th/td 因 legacy `font:` 简写未跟随等宽字体 → mono 态显式补 family/连字。
- **构建 P0**：`scripts/build.mjs` banner 拼接双重转义（`.join('\n')`）产出字面 `\n`，整包 JS 语法无效（宿主 `import failed`）→ 修复为 `.join('\n')` 并新增构建末尾 `node --check` 与单文件断言，坏产物直接阻断构建。

### 变更

- **底部工具行逐值对齐官方 `0.2.2-rc.1` InputBar**：`+` 指令钮 28×28、`conversation.input.permission` / `.plan` 槽位镜像（官方权限选择器 / 计划 chip）、`input.left` / `.right` / `.model` 座位顺序、语音 activity 座位（麦克风钮）、sending 阶段独立停止钮与旋转发送态、官方 stop / sending / steer·queue 文案、行 `container-type: inline-size` / padding `2px 8px 6px` / gap 12 / `@container` 窄宽 gap 8、模型文字 compact 收起；圆形按钮补 `corner-shape: round`（宿主默认 squircle）。
- **编辑器字面渲染**：`->`、`//` 等始终按字面字符显示，与预览 / 用户消息的纯文本一致；「字体连字」设置项移除（prefs 遗留字段忽略并丢弃）。
- **用户消息 Markdown 统一渲染管线**：预览 `.dci-preview` 与用户消息 `.dci-umsg-md` 共用同一 `renderMarkdown`，输出一致；会话 chip 装饰、附件 factory 委托、question-reply 让位、官方气泡外层均保留。
- **候选菜单四向自适应浮层**：悬浮 / 右侧栏形态的 `/` `@` 候选菜单从「头部行下方固定弹出、覆盖编辑区」改为 `createPortal(document.body)` 的 `position: fixed` 浮层——以 `.dci-card` 实时矩形为不可覆盖区，在上/下/左/右按可用空间自适应选位，打开期间逐帧复算；普通形态保持卡片上方浮层。
- 预览面板 `overflow-y: auto` → `overflow: auto`（宽表格/代码块可横向滚动）。
- 设置项调整：移除「字体连字」；新增「Markdown 等宽连字」（默认开）。
- 数据行详情面板 portal 化：三枚面板（会话统计 / Token 用量 / 上下文分段）`createPortal(document.body)` + `position: fixed`，跟随滚动/尺寸变化、Escape 与点外关闭、三枚互斥。

### 新增

- **Markdown 渲染（Obsidian 风格，全内置离线）**：GFM 表格（逐列对齐、宽表横滚）/ 任务清单（只读勾选、嵌套）/ 删除线 / 自动链接；**脚注**（上标 + 文末脚注区 + 回跳）；**8 类 Obsidian Callouts**（note/tip/warning/danger/info/success/question/quote，图标/配色/折叠，浅深主题对比度达标）；Obsidian 扩展语法 `==高亮==`、`%%注释%%`（隐藏、不误伤代码）、`[[wikilink|别名]]`（chip，点击复制目标）、`![[file]]`（样式化降级）、图片尺寸 `![alt|300](url)`、图片点击灯箱。
- **代码块**：highlight.js 46 种语言高亮 + 语言标签 + 复制按钮（未知语言不高亮不崩）。
- **数学公式**：KaTeX 行内 `$...$` / 块级 `$$...$$`；错误公式回退原文；20 个 woff2 字体全部内联 data URI，运行时**零网络请求**。
- **Mermaid**：13 类图表（flowchart / sequence / class / state / ER / gantt / pie / journey / gitGraph / info / mindmap / timeline），可见时懒渲染、浅深主题跟随、`securityLevel:'strict'`、失败回退源码；ELK/cose 与 cytoscape 构建期排除。
- **Markdown 正文等宽连字（默认开、设置可关）**：预览与用户消息正文改用 JetBrains Mono，`->`/`=>`/`//` 等靠**字体连字**显示箭头/连字（DOM、草稿、复制、发送内容仍是原文）；代码块/行内代码使用各自代码字体并同样显示连字；用户消息 h1–h6/th/td 同步等宽。
- 构建：`scripts/build.mjs` 新增 `katex-css-inline` / `mermaid-trim` 两个构建期 plugin（带断言防依赖升级静默失效）+ 产物 `node --check` / 单文件自检。
- 新依赖：`highlight.js ^11.12.0`（BSD-3）、`katex ^0.18.0`（MIT）、`mermaid ^12.3.0`（MIT）；`NOTICE` 补三方许可与传递依赖（ELK/cytoscape 未分发）。

### 说明

- 本版同时包含编辑器字面渲染、Markdown 渲染与正文/行内代码连字等能力（详见上文章节）。
- **体积**：`lib/client.js` ≈ 3.55 MB（gzip ≈ 1.10 MiB / brotli ≈ 0.94 MiB）；相对 0.3.9 基线（≈ 540 KB）增加约 2.84 MiB raw——全部 Markdown 渲染依赖（KaTeX 字体、highlight.js、Mermaid）内联打包，换来**离线可用、零网络请求**；构建约 1–7 s，单文件、连续构建字节一致。
- **安全**：原始 HTML 一律转义；外链 `target=_blank rel=noopener noreferrer`、`javascript:`/`data:` 协议拦截；KaTeX `trust:false`；Mermaid `securityLevel:'strict'` + SVG 过 DOMPurify；代码高亮只输出 class/文本。
- **已知限制**：Mermaid 仅内置 13 类常用图（其余回退源码）；`[[wikilink]]` 仅复制目标名、不做仓库导航；`![[图片]]` 只做文本降级；**编辑器不做字体连字**（桌面 Chromium 152 无解，等宿主升级）；系统未安装 JetBrains Mono 时正文等宽回退到宿主 code font（无连字则箭头退化为字面）。
- **「Markdown 等宽连字」开关语义**：开启时预览与用户消息的正文/标题/表格/行内代码均用 JBM 显示连字；关闭后**预览行内代码**回到阅读字体字面、正文恢复阅读字体；**用户消息行内代码**回到宿主代码字体（该字体默认连字，视觉上仍可能显示箭头，开关不改变它）。
- **验收记录**（隔离 web DSH `0.2.2-rc.1` + 无头 Edge；隔离桌面 Electron 44.7 / Chromium 152 抽验）：底部工具行/麦克风、带图用户消息与问答、prefs 迁移与统计边界、Markdown 渲染（GFM/脚注/Callouts/Obsidian 语法/图片尺寸与灯箱/代码高亮/KaTeX/Mermaid/正文与行内代码连字）、安全与回归全部 PASS；桌面抽验（编辑器字面渲染、预览正文连字、无第一格空白）PASS；`__dshCodinputErrs` / console error 全为 0。
- **发布材料**：`npm run typecheck` 通过；`lib/client.js` 由当前源码重建（md5 `a7708d2d00ce005de5e599cc7819296f`，3,555,033 B；gzip 1,157,872 B / brotli 958,709 B；构建自检 `node --check` OK）。

[0.4.0]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.3.9...v0.4.0

## [0.3.9] — 2026-11-06

修复 dsh `0.2.2-rc.1` 上模型 / 权限 / 设置下拉的整体错位、布局变化不跟随与开合失效：菜单改为 portal 到 `document.body`，锚点改按元素实时读取。

### 修复

- **菜单包含块被劫持，整体错位**（`MenuSurface`）：`.dci-menu` 虽为 `position: fixed`，但祖先链上的 `transform` / `filter` / `backdrop-filter` / `contain` 会把包含块从视口换成该祖先，`left/top` 按错误坐标系解释（实测可偏出 400px+）。现改为 `createPortal(document.body)`，与官方 ModelSelect 菜单、数据行详情面板同路数。
- **锚点是矩形快照，布局变化不跟随**（`MenuSurface`）：原实现保存 `getBoundingClientRect()` 快照，`scroll` / `resize` 重算读同一份快照、结果恒等被丢弃。现改为按元素实时读取；打开期间逐帧比对锚点位置（1px 阈值）兜住不产生 scroll/resize 的布局重排；锚点未布局或菜单零尺寸时不落位。
- **点触发器开合失效**（`MenuSurface` / `ModelMenu`）：全局 `pointerdown` 捕获监听把落在触发器上的点击也当作外部点击先关闭，触发器 `onClick` 随后读到 `open=false` 又开回来（点一次收不起来）。现外部点击判定跳过锚点、开合交给触发器 toggle；`ModelMenu` 移除自管点外关闭。模型 / 权限 / 设置三处调用方同步改为传元素 + 打开瞬间矩形。

### 说明

- 发布材料：`npm run typecheck` 通过；两次发布构建字节一致（`lib/client.js` sha256 `4ef5a5917614b811b7345adbc5166e649014718dbb63929ee3654e8b2656460c`，与入库产物一致）。
- 兼容验证：隔离 web 宿主 `@deepseek-ai/dsh@0.2.2-rc.1`（临时 prefix + 独立 `DSH_HOME` + 无头 Edge 自动化探针，`link:` 安装本仓库构建产物）33/33 断言通过——菜单为 `body` 直接子节点 / `position: fixed`；模型菜单 top = 触发器 top − 8 − 菜单高（逐像素 0 误差、右对齐）；祖先 `transform: translateY(150px)` 下仍 0 误差；布局位移 120px 后 2 帧内回贴；连点两次 开→收；点外部关闭、点菜单内不关；设置下拉 top = 触发器 bottom + 4（0 误差）且不被设置容器裁剪；窗口 1440×900→1100×760 后重算跟随。全程 console error / pageerror 为 0、`__dshCodinputErrs` 为空。
- 未覆盖：模型子页长列表滚动（隔离宿主无凭据、目录为空）、视口 12px 夹取分支、真实模型/权限切换提交。
- 0.3.8 既有功能与行为不变；本版仅调整菜单定位与开合实现（`lib/client.js` 同步重建）。PR #5（@LittleFishStars）。

[0.3.9]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.3.8...v0.3.9

## [0.3.8] — 2026-10-30

数据行三枚详情面板改为官方同构的 portal + fixed 锚定定位（滚动/尺寸变化跟随、Escape 与点外关闭、三面板单一展开）；设置页开关样式与面板背景/圆角 token 对齐官方；修复 patchReload live 热更新后新增样式类不注入；修复 0.3.7 带图用户消息渲染崩溃（P0）并收紧用户消息 Markdown 的安全基线（P1）。

### 变更

- **数据行详情面板 portal 化**（`StatsRow`）：会话统计 / Token 用量 / 上下文分段三枚面板改为 `createPortal(document.body)` + `position: fixed`，插件侧移植官方 `useAnchoredPosition` / `useStatDialog` 语义——side top / align start、gap 8、视口 margin 12、帧顶 clearance（`--dsh-frame-top-clearance`，`data-fullscreen` 归零）、滚动（捕获相位）/窗口 resize/面板尺寸变化重算并夹进视口。三枚面板各有独立 seat；新增 Escape 与点外关闭（点面板内部不关），并保持三枚单一展开态互斥。
- **设置页开关对齐官方 primitives**：`Switch.module.css` 逐值对齐——`999px` 圆角 + `corner-shape: round`、`disabled` 态、`focus-visible` 走官方 focus ring token、滑块走 `--dsw-alias-switch-thumb`；ON 轨道用 `--dsw-alias-brand-primary`（随宿主主题，与官方 Switch 同款）。
- **面板与数据行 token 对齐官方**：面板背景优先 `--dsw-specific-menu`、保留 `--dsw-menu-surface-fill` 旧宿主回退链；圆角改 `var(--dsw-radius-lg)`；数据行胶囊 expanded 态、上下文仪表条 `corner-shape`、trigger 字号 token 与官方对齐。
- **npm 包描述**：`package.json` description 扩为「DSH 插件……web 与桌面端通用」。

### 修复

- **样式热更新失效**（`injectStyles`）：宿主 `patchReload: live` 原地更新插件后，旧 `<style id="dsh-codinput-styles">` 仍在、原实现「已存在即 return」导致新版新增类名（如 `.dci-umsg-*`）永不注入；现改为已存在时按内容原位刷新 `textContent`。
- **带图用户消息渲染崩溃（0.3.7 发布回归，P0）**：`contentParts` 把 `ImageAttachmentRef` 裸传给官方 `renderMessageImages`，官方 `ImageGallery` 计算 React key 时读 `image.attachment.attachmentId` 抛错；宿主 `SlotErrorBoundary` 捕获后**废黜**该键控条目，该页此后所有用户/插队消息退回官方纯文本（静默失效）。现按官方形状包成 `{ attachment }`；并补图片降级卡——宿主缺 `renderMessageImages` 座位 prop 时不再静默丢图。
- **用户消息 Markdown 安全基线收紧（P1）**：marked 透传的原始 HTML 经 DOMPurify 白名单收敛（禁 `style` / `form` / 控件 / 媒体 / 行内 style 等原始 HTML），链接与图片 URI 只放行 http(s)/mailto（非白名单链接拆成纯文本、破图降级为 alt 文本），与官方 `MarkdownText` 的 `sanitizeUrl` / `remoteImageUrl` 口径对齐；http(s) 链接统一新开页。
- **用户消息 Markdown 细节**：补 `useT` 订阅（宿主语言切换后复制钮/引用摘要等文案即时更新）；复制成功态定时器在卸载时清理；文件夹 chip 与官方一致不可点；chip 点击实时读取最新 `openFile`/`openSkill`（晚到不再失效）；组件加 `memo`；0 字节文件卡显示 `0B`；`bindForeign` 不再缓存 null（宿主 locale 晚到仍能绑定）。

### 说明

- 本版发布材料确认范围：`npm run typecheck` 通过、两次发布构建字节一致（sha256 可复现）。
- 已在隔离 web 宿主 `0.2.0-rc.2`（独立 `DSH_HOME` + 无头 Edge + `link:` 安装本仓库构建产物）实测：三枚面板均为 `body` 直接子节点、`position: fixed`，几何逐像素吻合（面板底距锚点顶 8px、左缘对齐锚点）；互斥、点外关闭、点面板内不关、Escape 关闭、窗口 resize 后跟随且不出视口均通过。用户消息 Markdown（strong/code/pre/list/link、@引用 chip、复制态）正常，XSS 探针（`<img onerror>`、`<script>`）被净化且未执行，`__dshCodinputErrs` 为空。未单独覆盖：滚动跟随、面板自身 ResizeObserver 分支、macOS 桌面实机目检。
- 桌面 `0.2.1-rc.3` 取证：从该版 `app.asar` 提取官方 CSS Modules 与主题 token，逐值核对 Switch 规则、stats / ContextMeter 面板的 portal+fixed 与背景/圆角、`--dsh-frame-top-clearance`，与 0.3.8 实现一致；macOS 毛玻璃/不透明度差异未实机目检。
- 0.3.7 已发布的三项功能（用户消息 Markdown、插件页图标、数据行三面板互斥）机制不变；本版修正其带图崩溃与安全基线，以及交互/样式细节。

[0.3.8]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.3.7...v0.3.8

## [0.3.7] — 2026-10-29

用户消息 Markdown 渲染：右侧自己发出的消息按 Markdown 排版（设置可关）；插件页图标接入；数据行三面板唯一展开修复。

### 新增

- **用户消息 Markdown 渲染**（`UserMessageMarkdown`）：`conversation.chat.node` 键控座 user/steering 官方渲染器的 priority 遮蔽条目——气泡文本经 marked（GFM+breaks）+ DOMPurify 渲染，Markdown 样式逐条移植官方 MarkdownText.module.css；官方气泡形态全保留：附件行（图片走官方 `renderMessageImages` 座位 prop、文件卡复刻）、@文件/@会话//技能 引用 chip（官方 `projectUserText` 三组正则逐值复刻，文件/技能可点开）、复制钮与时间戳、引用摘要行、悬停显形（复刻官方 `data-actions-reveal` + `data-chat-flow-kind` 选择器面）。设置 → Codinput「用户消息 Markdown 渲染」开关（默认开）；关闭即卸载条目还原官方纯文本，无需刷新页面。行内代码与围栏代码块统一用 `--dsw-alias-markdown-code-block` 底色（深浅主题同色、随肤跟随）。已知边界：KaTeX 数学式、Shiki 代码高亮、代码块语言横幅不做；发送瞬间的本地回显不经该槽位，落库后即换 Markdown 形态。
- **插件页图标**：package.json 顶层 `"icon": "./assets/icon.png"`——宿主读取该字段（相对路径、限 SVG/PNG/JPEG/WebP、≤256 KiB）转 data URL，已装插件列表不再落默认图。

### 修复

- **数据行三面板唯一展开**：上下文小圈（`ContextGauge`）原先自持展开态，可与两枚统计胶囊同时展开（同时存在两个详情面板）；现并入 `StatsRow` 单一展开态，任意时刻至多一个面板。

### 说明

- **挂载面事实**：键控座每 key 低 priority 者胜，宿主动态包守卫对插件 register 强制分配唯一负秩——注册即遮蔽、卸载即还座官方（与 `composer.bar` 接管同机制）。
- **已实测**（真实 web 宿主 `0.2.0-rc.2`，本地 link 安装本仓库构建产物，Chromium 自动化探针）：Markdown 消息渲染语义正确（ARIA 树 paragraph/strong/code/list、截图目检排版）、设置开关不刷新页面即时切换形态、整页重载后持久消息保持 Markdown、复制/时间戳/引用 chip 行为正常、`__dshCodinputErrs` 为空；插件卡图标与 `assets/icon.png` 逐字节一致；轮步/用量/上下文三面板互斥展开（开新关旧、再点收起）实测通过。

[0.3.7]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.3.6...v0.3.7

## [0.3.6] — 2026-10-28

模型座让位（issue #4）：`conversation.input.model` 单值座上的第三方遮蔽者恢复显示；出厂 ModelSelect 不镜像，继续由自绘模型芯片代表。

### 新增

- **`conversation.input.model` 单值座让位镜像**（`ModelSlot`）：以 priority 遮蔽宿主模型座的插件（reasoning-slider / dsh-effort-dial 一类）注册会成功、条目确实是单值座赢家，但官方 InputBar 被遮蔽后该座唯一的 `renderSlot` 调用点随之消失——「不报错、永不上屏」（issue #4）。接管工具行现于官方同位（`.dci-standard-controls` 内、`input.right` 之后）镜像该座赢家，并把官方 `InputControlOwnerProps` 的 owner prop `locked` 原样下发。有第三方遮蔽者时让位并隐藏自绘模型芯片（同座只留一个控件，与官方单值座语义一致）；无遮蔽者时保持既有自绘芯片（普通/悬浮/侧栏三形态同享）。
- **单值座「第三方遮蔽者」判据**（`isShadowingOccupant`）：宿主动态包守卫对非 chain 槽位的 register **强制**分配页内遮蔽秩（`options.priority` 为唯一负数）、fiber 名取 `dyn/<pluginId>`；出厂占用者（client-ui-model-selection 的 ModelSelect）不带 priority（≡0）。只镜像前者——镜像出厂条目会与自绘芯片重复成两个模型选择器。
- **让位失败降级**：条目 `inject(sessionId)` 是宿主 fiber 上下文里的闭包，插件侧调用会丢 ctx 绑定，依赖宿主服务面的 inject 会抛错（实测 dsh-model-accordion 0.2.1 的 `directoryFor` 抛 `cannot get property "remote.session" without inject`）。`entryInjectFailed` 预检 + 条目边界 `fallback` 让单值座在「inject 不可复现 / 组件崩溃」时回退自绘芯片，而不是留空或连坐输入面。

### 说明

- **已实测**（真实 web 宿主 `0.2.0-rc.2`，本地 link 安装本仓库构建产物，Chromium 自动化探针）：reasoning-slider 0.0.7 与 dsh-effort-dial 0.1.0 均在官方模型座原位显示（`.dci-standard-controls` 内 `input.right` 座位之后）、自绘芯片隐藏、弹层可打开并读出真实模型/推理档位；卸载插件后自绘芯片原样恢复；同屏右座（dsh-prompt-enhancer）无回归；`__dshCodinputErrs` 为空、无控制台报错。
- **降级实测**：dsh-model-accordion 0.2.1（带 inject 面）在模型座降级回自绘芯片——座位不空、无控制台报错，仅 `__dshCodinputErrs` 记一条 `slot.inject` 诊断（其 inject 依赖宿主 ctx，插件侧不可复现）。
- **机制覆盖未逐一实测**：悬浮 / 侧栏两形态与普通形态共用同一 Toolbar（座位自动同享）；`locked` 置灰只在会话拒绝交互时可见（官方语义 `removed || inert || !live`，Codinput 下发自身 `inert`，含 blocked，口径略严一档）。
- **边界**：第三方若自行给该座补声明 children 会与宿主已声明冲突（宿主 `already declared`），镜像层不做；多个插件同时遮蔽同一单值座属槽位竞争，由宿主 fail-loud。

[0.3.6]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.3.5...v0.3.6

## [0.3.5] — 2026-10-23

第三方输入座位补齐（issue #1 之左座）：`conversation.input.left` 条目恢复显示；v0.3.4 的右座实现泛化为「座位镜像」层。

### 新增

- **左座 `conversation.input.left` 槽位转发渲染**：该子槽位位于官方工具行左区 `.tools` 内 modes（权限→计划）之后——issue 截图里的底栏按钮（如「上传视频」）、dsh-qoder-plugin 的额度读数等第三方条目注册在这里；遮蔽官方输入框后渲染点随条目一起消失。接管卡片工具行现于同位置（`.dci-tools` 内、权限触发器之后）复刻官方 renderer 的 list 合成，三形态（普通/悬浮/侧栏标签）同享。已在真实 web 宿主（`0.2.0-rc.2`）实测：座位条目渲染进左区几何正确位置、三形态一致、无横向溢出，卸载条目后零残留。
- **座位镜像通用引擎**：v0.3.4 的右座实现抽成 `InputSlotSeat`（座位名 + standard props 面参数化），左右两座共用同一套 list 合成（id 首占位去重 + order 升序）、条目 inject/`use<Name>` 钩子、条目 locale 的 `t`、standard props 原样通道与逐条目崩溃隔离；后续座位接入只需再加一片薄壳。

### 说明

- 检测即兼容：槽位无条目或宿主过旧（无该子槽位）时座位不渲染，零样式零行为残留；单个条目崩溃被边界隔离，不连坐输入面。
- 左右两座的 standard props 面同源：宿主下发给 bar/侧栏 body 条目的 kit 减去 owner props（侧栏再剔除注入的 `useTabInfo`）。
- **已知限制（本版边界）**：`conversation.input.model` 单座（如 dsh-model-accordion 类替换模型选择器的插件）与自绘模型芯片 UX 冲突，本版不镜像；`conversation.input.attachments` / `overlay` / `dock` 生态暂无租客，留扩展位。
- **覆盖边界（措辞分界）**：左座转发在真实 web 宿主（`0.2.0-rc.2`）上以确定性探针条目实测通过（渲染位置/三形态/卸载零残留）；dsh-qoder-plugin 的左额度读数与右探针双座条目实测注册成功、无报错，但其组件按官方契约在未选中 Qoder provider 时返回 `null`，可见读数属机制推断、未实测；左座席位的「上传视频」类插件真身未在本环境出现，同属机制覆盖（其注册形态与已实测样本同轴）。右座既有租客（dsh-prompt-enhancer）端到端回归实测不受影响。

[0.3.5]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.3.4...v0.3.5

## [0.3.4] — 2026-10-23

第三方输入条目兼容（issue #1 之右座）：接管后 `conversation.input.right` 座条目恢复显示（已实测 dsh-prompt-enhancer 的 ✨/🎤）；模型/推理强度弹层恢复官方形态。

### 新增

- **`conversation.input.right` 槽位转发渲染**：该子槽位由官方 InputBar（`conversation.composer.bar` 缺省条目）声明并在其工具行内渲染；Codinput 以 priority -1 遮蔽官方条目后，槽位渲染点随官方输入框一起消失，注册在此槽位的第三方按钮（如 dsh-prompt-enhancer 的 ✨ 提示词优化 / 🎤 语音识别）无处挂载。接管卡片的工具行现于官方同座位（右侧标准控件区、模型选择之前）复刻官方 renderer 的 list 条目合成（id 首占位去重 + order 升序 + priority 遮蔽序、条目 inject/`use<Name>` 钩子、条目 locale 的 `t`、standard props 原样通道、逐条目崩溃隔离），三形态（普通/悬浮/侧栏标签）同享。
- **检测即兼容**：槽位无条目或宿主过旧（无该子槽位）时座位不渲染，零样式零行为残留；单个条目崩溃被边界隔离，不连坐输入面。

### 修复

- **菜单钻入子页后向下弹出**：`MenuSurface` 旧实现只在打开瞬间定位一次（尺寸变化不重算），从根菜单点进更长的「模型 / 推理强度」列表时，卡片保持小菜单算好的顶边向下生长、盖住触发器，视觉上变成「向下弹出」。现复刻官方 ModelSelect 的 `place()` 三路监听（ResizeObserver 挂卡片 + 页面 scroll/resize），内容尺寸每次变化即重算上方锚位并夹进视口。
- **模型选择框无滚动条**：旧 `.dci-menu` 把 `max-height: 100vh - 24px` 与 `overflow-y: auto` 压在卡片本体且未注入官方卡片的 `--dsh-scrollbar-thumb`（l2）变量；叠加上一条后卡片伸出视口被浏览器裁切，列表项既够不着也不出条。现按官方两级结构复刻——卡片 `overflow: hidden` + `max-height: min(360px, 100vh - 96px)`，列表在 `.dci-viewport` 内滚、细滚动条按官方 l2 变量着色；`popupSelect` 壳（命令选项弹层）同步内滚结构。

### 说明

- 官方渲染门槛同款复刻：`input === undefined || sessionId === undefined` 时整个座位不渲染。
- 条目声明 store 的 `useStore`/`actions` 面依赖宿主私有记账，插件侧不可复现；现网此类条目未出现。
- **覆盖边界**：本版转发的是 `conversation.input.right`（右座）；`conversation.input.left`（左座，如部分插件的「上传视频」按钮与 qoder-plugin 的额度读数）暂未转发，后续版本补齐。
- **右座覆盖面**：同座其他条目（如各 Qoder 渠道插件的积分/余额读数）按同一合成机制恢复显示——推断自各包源码的槽位注册（五家 Qoder 桥接包均注册于 right 座），未逐一实测。

[0.3.4]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.3.3...v0.3.4

## [0.3.3] — 2026-10-23

主题/皮肤插件兼容：错误色与预览链接逐值对齐官方；README 增补皮肤作者指南。

### 变更

- **错误色回退值逐值对齐官方**：`.dci-error` 与完全权限确认警示图标的错误色回退值由 `#ff6b6b` 改为官方同款 `#d54941`（token 仍走 `--dsw-alias-state-error-primary`，仅无该令牌的宿主回退时可见差异）。
- **预览链接走官方 alias-link token**：markdown 预览的链接色由写死 `#4c8dff` 改为 `var(--dsw-alias-link, #4c8dff)`，换肤下与官方 markdown 链接同进退。

### 新增

- **README 皮肤作者指南（中英）**：新增「主题 / 皮肤插件兼容」章节——覆写宿主 `--dsw-*` token 即全盘生效（含 token 定义在 body 层、覆写需写同层的注意点）；官方写死的值清单（发送钮图标前景白等，属预期不跟 token）；稳定的 `dci-` 前缀类名契约与注入顺序（皮肤后注入按常规 CSS 权重覆盖）。

[0.3.3]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.3.2...v0.3.3

## [0.3.2] — 2026-10-18

桌面版 0.2.1 模型区同步（官方 1017 发布徽章）；侧栏标签与指南页条目上品牌标。

### 新增

- **模型名 1017 发布徽章同步（桌面版 `0.2.1-rc.2`）**：官方给模型座位新增了模型名标签子槽位（`conversation.input.model.label`），并以内置插件给 DeepSeek 官方通道的 flash 模型显示名后追加一枚 info 色发布徽章「1017」。Codinput 原样渲染该槽位的官方条目组件——触发器、模型菜单根页与模型列表三处与原生输入框同款（徽章样式随官方插件自带注入）。官方未提供条目时（web 各版本、桌面 `0.2.0-rc.2` 及更早）自动回退纯模型名，与各自宿主的原生表现一致。
- **侧栏标签与指南页条目上品牌标**：侧栏标签芯片改走官方标签标题座位（`sidebar.right.pane.tab.title`，与官方 Files / Guide 标签同构），在标签名前渲染鲸鱼蓝 `#3964FE` 品牌标（此前是无图标的纯文本）；指南页「Codinput」条目同样以品牌标替换官方的灰色立方体兜底图标；拖出浮动后窗口标题同享。

### 变更

- **思考强度显示对齐官方公式**：会话未显式指定强度时回落当前模型的默认强度并显示其名字（此前一律显示「Default」，官方显示的是默认强度名，如 Max / High）；模型未提供推理元数据时显示会话保留强度。推理等级菜单在模型未声明默认强度时补官方的「Default（跟随提供方默认）」行；模型无推理元数据时不再显示强度入口（官方同款）。
- **触发器样式逐值对齐**：圆角走 `--dsw-radius-sm` 令牌链（无令牌的旧宿主回退原 24px 视觉）；模型触发器字重 400、权限触发器保持 500——官方两款触发器本就不同，此前共用类一律 500。

### 说明

- **检测即兼容**：模型徽章经官方槽位条目渲染，条目缺席时自动回退纯名，无样式无行为残留。桌面版 `0.2.1-rc.2` 端到端实测（徽章、强度显示、品牌标、触发器）；web `0.1.7-rc.2` 按官方包逐行取证（无该子槽位与徽章插件、目录快照字段一致）加守卫降级覆盖；`0.1.5-rc.2` / `0.1.6-alpha.2` 沿用既往结论。升级宿主后建议按 [TESTING.md](./TESTING.md) 冒烟。

[0.3.2]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.3.1...v0.3.2

## [0.3.1] — 2026-10-11

编辑 + 预览分屏同步滚动；README 展示图与品牌视觉更新；第三方归属补全。

### 新增

- **分屏同步滚动**：编辑 + 预览分屏时两栏按滚动比例互随（两侧内容高度不同，按比例映射）；只保留编辑栏一个滚动条，预览栏藏起滚动条但滚轮仍可反向带动编辑器；进入分屏、草稿更新或切换会话后，预览按编辑器当前比例自动对齐。同时修复分屏内容过高时两栏都出不了滚动条的布局缺陷（grid 隐式行随内容撑高、不受 `max-height` 钳制——两栏改 `minmax(0,1fr)` + `min-height:0`）。

### 变更

- **README 展示图更新为桌面版实拍四图**（普通 / 编辑+预览分屏 / 悬浮 / 侧栏，2×2 布局），并改用**无损 webp**（体积约为原 PNG 的 1/4，像素级无损）；英文 README 与中文共用同一套配图（`assets/en/` 移除）；DSH 兼容徽章更新为 `0.2.0-rc.2+`（展示图摄于桌面版 `0.2.0-rc.2`）。
- **品牌图标重上色**：描边由紫蓝 `#4632DE` 换为 DeepSeek 鲸鱼蓝 `#3964FE`（README 头图、`icon.svg` / `icon.png` 同步，PNG 重渲染仍为 320×320 透明底）。
- **第三方归属补全**：内置依赖（CodeMirror 6、marked、DOMPurify）的版权行与许可声明集中进 [NOTICE](./NOTICE)——压缩产物不留许可注释，NOTICE 随 npm 包分发，覆盖源码与包两种安装路径。

### 说明

- 宿主兼容不变：桌面版（Electron，`0.2.0-rc.2`）与 `0.1.7-rc.2`（next）实测通过，`0.1.5-rc.2` / `0.1.6-alpha.2` 沿用既往结论；升级宿主后建议按 [TESTING.md](./TESTING.md) 冒烟。

[0.3.1]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.3.0...v0.3.1

## [0.3.0] — 2026-10-02

官方桌面版语音输入同步：原生输入框有语音按钮时，Codinput 在一模一样的位置渲染一模一样的按钮。

### 新增

- **语音输入按钮同步（官方桌面版兼容）**：官方桌面版（Electron，`0.2.0-rc.2` 起）的输入框带语音输入按钮。Codinput 开启时在完全相同的位置（工具行右侧、模型选择器与发送钮之间）渲染**同一个官方语音组件**——`conversation.input.activity` 槽位条目原样渲染：麦克风触发钮、录音波形、转写、未就绪引导弹窗与中英文案全部是官方代码，官方后续更新自动跟随。录音展开时工具行行为也与官方一致（左侧工具与模型控件让位、capture 行接管整行、发送钮保留）。

### 说明

- **检测即兼容**：宿主未挂载语音插件（web 端各版本、桌面版语音插件关闭）时该槽位无条目，Codinput 同样不渲染按钮——与原生输入框行为一致；条目出现/消失经槽位订阅实时跟随（设置里开关语音插件即时生效）。按钮文案走官方 `voice-input` 词典（听写 / 开始录音 / 识别中… 等），不自备译文。
- **桌面版实测（Electron `0.2.0-rc.2`）**：授权麦克风 → 录音（波形）→ 停止 → 官方转写链路端到端通过；本地模型首次唤醒可能报「Unable to decode audio data」，重试即成功（官方输入框同样如此）。展开态布局、Escape/失焦取消、转写空结果与失败反馈均与官方一致。
- **web 宿主回归**：`0.1.7-rc.2` 实测无语音插件时按钮不渲染、工具行无任何变化，既往功能不受影响。
- 宿主兼容其余不变：`0.1.7-rc.2`（next）实测通过，`0.1.5-rc.2` / `0.1.6-alpha.2` 沿用既往结论；升级宿主后建议按 [TESTING.md](./TESTING.md) 冒烟。

[0.3.0]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.2.0...v0.3.0

## [0.2.0] — 2026-09-29

品牌换新 + 一批交互补全：图片原图预览、发送/停止、侧栏 `/codinput` 退出与自动启用，以及输入卡片与数据行对官方布局的逐值对齐。

### 新增

- **品牌图标全面换新**：自绘机型标（代码括号 + 航迹 + 纸飞机）替代 lucide `file-code-corner`——README 头图、悬浮/侧栏唤回小球、slash 的 `/codinput` 命令图标全部换新（小尺寸做了可读性简化）；`assets/` 附透明 PNG、紫色矢量与白色线稿三件套。
- **附件图片原图预览**：点图片缩略图弹出全屏预览层（官方 primitives `ImageLightbox` 逐值复刻）——Esc、背板按下、右上关闭钮三种方式关闭，关闭后焦点还原缩略图。
- **发送 ⇆ 停止**：流式回复期间主按钮自动变停止（官方同款方块 glyph），点击即中断生成（官方 `conversation.cancel` 同链路）；会话阻塞（审批等待）时停止钮仍可点；回复结束或中断后恢复发送。
- **侧栏 `/codinput` 退出**：侧栏里输入 `/codinput` 回车——接管关闭、Codinput 标签自动关闭、官方输入框原样回归；重新打开标签（或再次 `/codinput`）即恢复接管。
- **开标签即启用**：未启用接管时，打开右侧栏的 Codinput 标签直接启用插件。

### 变更

- **slash「添加 · 文件」接管期间照常可用**：接管面按官方契约绑定会话文件拾取器（`bindFilePicker`），文件条目不再随官方输入框卸载而消失；工具行的独立附件按钮随之移除（官方已并入 slash），粘贴 / 拖拽路径不变。
- **slash 菜单排序修正**：空查询不再整列排序（会把「添加/指令」小节打散），改为 `/codinput` 单行按字典序排入指令节首，其余保持官方使用序。
- **输入卡片与数据行对齐官方布局**：surface 复刻官方 composer root（侧向 clearance + 底距）、数据行复刻官方 dock（无横向内缩、距卡片 4px、胶囊组居中），窄列下卡片宽度与官方逐像素一致；圆角/字号/行高改走官方令牌。
- **侧栏承载语义补全**：标签定义 `keepMounted` 保活（浏览同栏其他标签不丢承载）；承载以接管开关为前提（`/codinput` 退出即让位，重开自动恢复）；分栏多标签时编辑面跟随后被查看的一栏。
- **性能与用量取数对齐官方**：`sessionStats` 投影优先、chat 节点派生兜底——tok/s 为 decodeTokens÷decodeMs 的会话持久值（历史会话也显示），缓存命中/时长格式化同官方规则；数据行字号走官方 secondary-1px 公式。
- **README 全面重写 + 五张展示图重拍**（真实对话素材、深色主题）。

### 修复

- 唤回小球在「侧栏收起 + Codinput 浮动面板打开」时不再多余出现（输入就在眼前）。

### 说明

- 宿主兼容不变：`0.1.7-rc.2`（next）实测通过，`0.1.5-rc.2` / `0.1.6-alpha.2` 沿用既往结论；升级宿主后建议按 [TESTING.md](./TESTING.md) 冒烟。

[0.2.0]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.1.1...v0.2.0

## [0.1.1] — 2026-09-25

适配宿主 `0.1.7-rc.2`（`next` 通道）的官方候选菜单亚克力改版；旧 rc 宿主经 token 回退链保持原样。

### 新增

- **候选框亚克力背景**：`/` `@` 候选菜单对齐官方 `0.1.7-rc.2`——官方此版起菜单表面改为 primitives `MenuSurface` 的 material 层（`--dsw-menu-surface-fill` ≈ 45% alpha + `backdrop-filter: blur(40px) saturate(150%)`），菜单本体不再自带背景。复刻菜单改为单元素合并两层，取值逐值一致；同一 token 链应用到指令菜单、数据行详情面板与上下文分段面板。
- **上下文小圈挪进数据行**：官方 `0.1.7-rc.2` 把上下文占用小圈从输入卡片工具行挪到卡片下方 dock 行（stats 胶囊之后），trigger 变为「双环仪表 + 百分比」药丸（padding 1px 8px、gap 6px、13px tabular-nums），且独立于 stats 胶囊渲染（无统计数据时也出现）。已逐值对齐。
- **候选菜单尺寸同步 rc.2**：max-height 320→400（`SlashMenu` 的 JS 上限常量同步修正——该常量以内联样式覆盖 CSS，仅改 CSS 不生效）、item 行 40px/14px→34px/13px（gap 8→6、radius→`--dsw-radius-md`）、图标 16→14px 且颜色走新的 `--dsw-alias-menu-icon`、分节标题/骨架屏/面包屑收紧值同步。

### 修复

- **上下文小圈数值与官方不一致**：官方 `contextOccupancy` 优先取 `projectedTokens`（含投影增长），缺失才退 `pressureTokens`；复刻此前只读 `pressureTokens`，导致启用 Codinput 前后小圈显示不同（如官方 3%、Codinput 2%）。已按官方语义修正（含分段面板 figures 取数）。

### 说明

- **双通道兼容**：`0.1.7-rc.2` 走新 token（亚克力、16px 圆角、menu-icon 色）；`0.1.5-rc.3` 等旧宿主没有这些 token，回退链落回原 rc.3 形态（不透明 `--dsw-specific-menu`、20px 圆角、无 blur），两端均与各自官方一致。
- 官方 rc.2 新增的候选菜单 `[data-overflow-below]` 底部渐隐未复刻（需宿主溢出方向状态，仅影响菜单向下展开的变体）。
- 测试状况（分两层）：静态层面，官方 CSS 从 `dsh-client-ui-theme` / `dsh-client-ui-input-trigger` / `dsh-client-ui-conversation` 的 `0.1.7-rc.2` 包内逐值提取核对；运行时层面，在实机 `0.1.7-rc.2` 上验证了暗/亮主题亚克力、悬浮形态菜单与小圈挪位（CI 仍只做静态把关，运行时零覆盖不变）。

[0.1.1]: https://github.com/0x2fovo/DSH-Codinput/compare/v0.1.0...v0.1.1

## [0.1.0] — 2026-09-23

首个公开版本。

### 新增

- **三态单实例输入入口**：普通 / 悬浮 / 侧栏标签三形态，任一时刻恰好一个，且绝不与官方输入框共存。
- **侧栏收起不让位 + 右上角小球**：侧栏收起后输入入口仍是侧栏那一个（不唤回普通模式，也不唤回官方输入框），标题栏下方出现圆形品牌小球，点击展开侧栏并聚焦 Codinput。小球 portal 定位、不占用官方槽位。
- **悬浮窗口式缩放**：四条边 + 四个角落 1:1 跟手，对边为锚点、不越出视口、不小于 360×140，位置与尺寸双记忆。
- **附件三入口**：点选文件、直接粘贴图片、把文件拖进卡片（拖入时描边提示）。
- **附件展示复刻官方**：图片 64×64 圆角缩略图、非图片文件卡（类型 glyph + 名称 + 「扩展名 体积」）、上传中 spinner 与进度条、失败红框整卡重试、轨道溢出时两端翻页箭头——取值逐条对齐官方 `dsh-client-ui-attachment`。
- **撤销历史跨形态保留**：编辑器状态按会话暂存，形态切换/会话切换后 `Ctrl+Z` 依然有效。
- **上下文小圈与数据行**：官方 composer stats 与上下文占用小圈的逐值复刻（含详情面板）。
- **界面多语言（中文 / English）**：全部文案走宿主 locale 服务（`ctx.locale.register` + `bind`），跟随宿主语言设置实时切换；宿主 locale 缺席时退回内置词典。README 提供[中文](./README.md)与 [English](./README.en.md) 两份。

### 说明
- 进入侧栏形态只经侧栏标签本身；早期内部版本的「拖入右侧栏 = 侧栏模式」手势已按产品决策舍弃。
- 偏好键为 `dsh-codinput.prefs.v2` 的 `mode: 'normal' | 'float'`（侧栏态由承载派生、不落盘）；早期内部版本的两态模型 `floating: true` 会自动迁移为 `mode: 'float'`。
- 发布产物为压缩 + 无内联 sourcemap（约 460 KiB）；`npm run build:dev` 保留未压缩 + 内联 sourcemap 的调试产物。
- 官方侧草稿灌入（pick / claim / 提交清空）不进撤销栈。

### 修复

- **侧栏标签里打字不落草稿**：编辑器回调走的是模块级单槽（跨形态复用 `EditorState` 必需），但卸载时无条件清空——侧栏 body 先挂载、主输入面晚一拍才卸载，于是晚卸载的旧实例把新实例的 hooks 摘掉。症状是在侧栏 Codinput 里打字只留在本地面板：不进草稿（刷新/关标签即丢）、行列指示不动、发送/换行手势失效。改为按实例身份清空（`clearActiveEditorHooks`）。

[0.1.0]: https://github.com/0x2fovo/DSH-Codinput/releases/tag/v0.1.0
