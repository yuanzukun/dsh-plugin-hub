/**
 * 文案国际化：走宿主 locale 服务（`ctx.locale.register` + `bind`），
 * 宿主未就绪或形状漂移时退回内置词典（默认中文），绝不把 key 直接显示给用户。
 *
 * - 注册命名空间 `dsh-codinput` 的 zh / en 两份词典（宿主内置语言只有这两个）。
 * - `bind(ns)` 返回的函数**引用稳定、按调用当拍读当前语言**，所以组件里直接
 *   调 `t('key')` 即可；要跟随语言切换重渲染的地方用 `useT()`（基于
 *   `useSyncExternalStore` 订阅宿主 locale 快照变化）。动态键（如权限预设）用
 *   `tOptional()`，词典里没有就返回 undefined，交由调用方回退原名。
 * - 插值占位符用 `{name}`（与宿主 Translate 约定一致）。
 */

import { useSyncExternalStore } from 'react';

export type TranslateParams = Record<string, string | number>;
type Dict = Record<string, string>;

const NS = 'dsh-codinput';

/** 中文词典（默认语言，也是宿主缺词典键时的兜底）。 */
const ZH: Dict = {
  'head.edit': '编辑',
  'head.preview': '预览',
  'head.editOnly': '仅编辑',
  'head.previewOnly': '仅预览',
  'head.split': '编辑 + 预览',
  'editor.placeholder': '描述你想要构建的内容，/ 调用指令，@ 文件或对话',
  'preview.empty': '暂无可预览内容',
  'tool.command': '指令（/）',
  'tool.send': '发送消息',
  // 官方 0.2.2 input.* 按钮文案（conversation 词典逐值）：sending / queue / steer。
  'tool.sending': '正在发送消息',
  'tool.continue': '继续生成',
  'tool.sendQueue': '排队发送',
  'tool.sendSteer': '插话发送',
  'tool.model': '选择模型，当前 {name}',
  'tool.modelPlain': '选择模型',
  'tool.context': '上下文已用 {percent}%',
  'tool.contextTitle': '上下文已用',
  'attach.group': '草稿附件',
  'attach.uploading': '上传中…',
  'attach.failed': '上传失败',
  'attach.retry': '重试上传',
  'attach.remove': '移除附件 {name}',
  'attach.scrollLeft': '向左滚动附件',
  'attach.scrollRight': '向右滚动附件',
  'attach.channelUnavailable': '附件通道不可用',
  'attach.pending': '待上传文件 {name}',
  'stats.prompt': '系统提示词',
  'stats.tools': '工具定义',
  'stats.messages': '对话消息',
  'menu.model': '模型',
  'menu.reasoning': '推理等级',
  'menu.reasoningNone': '当前模型未提供推理等级。',
  'menu.refreshingModels': '正在刷新模型列表…',
  'menu.noModels': '没有可用的模型。',
  'md.mermaidError': 'Mermaid 渲染失败',
  'perm.trigger': '访问模式，当前：{name}',
  'perm.confirmTitle': '确认启用完全权限？',
  'perm.confirmEnable': '启用完全权限',
  'perm.warning':
    '启用完全权限后，智能体将减少确认步骤，并且可以直接执行更多操作，包括敏感操作、文件修改或外部命令。仅建议在你信任当前任务时使用。',
  'perm.ack': '我已了解风险，并愿意继续',
  'perm.cancel': '取消',
  'perm.close': '关闭',
  'perm.switchFailed': '权限切换失败',
  'perm.channelRejected': '命令通道拒绝',
  'perm.noInputSurface': '无可用输入面',
  'perm.preset.read-only': '仅可查看',
  'perm.preset.workspace-write': '工作区内修改',
  'perm.preset.danger-full-access': '完全权限',
  'set.enabled': '启用接管',
  'set.enabledDesc': '关闭即恢复官方输入框，草稿不丢；/codinput 同样可切换',
  'set.userMarkdown': '用户消息 Markdown 渲染',
  'set.userMarkdownDesc': '右侧自己发出的消息按 Markdown 排版（标题/列表/代码块等）；关闭恢复官方纯文本',
  'umsg.copy': '复制',
  'umsg.copied': '已复制',
  'umsg.referenceSummary': '引用：{labels}',
  'umsg.clock.md': '{m}月{d}日',
  'umsg.clock.ymd': '{y}年{m}月{d}日',
  'umsg.extraBlock': '额外内容块',
  'umsg.image': '图片',
  'set.lineNumbers': '显示行号',
  'set.lineNumbersDesc': '当前行与行号高亮常开',
  'set.markdownMono': 'Markdown 等宽连字',
  'set.markdownMonoDesc':
    '预览与用户消息正文改用 JetBrains Mono 等宽连字字体：-> 靠字体连字显示为箭头（文本仍是原文，编辑器输入框始终按字面显示）；关闭后正文恢复普通阅读字体，代码块不受影响',
  'set.float3d': '3D 悬浮',
  'set.float3dDesc': '悬浮模式下以视口中心为球心呈 3D 球面朝向，拖动时叠加浮空与惯性回弹，配动态投影与边缘反光',
  'set.font': '编辑器字体',
  'set.fontDesc': 'CSS font-family，留空恢复默认',
  'set.sendKey': '发送快捷键',
  'set.sendKeyDesc': '点击后按下任意组合完成录制；与换行快捷键不得相同',
  'set.lineBreakKey': '换行快捷键',
  'set.lineBreakKeyDesc': '点击后按下任意组合完成录制；与发送快捷键不得相同',
  'set.defaultView': '默认视图',
  'set.defaultViewDesc': '接管面板初始显示的形态',
  'set.recording': '按键…',
  'set.reset': '恢复默认',
  'set.resetAction': '重置',
  'set.resetAll': '清空全部 Codinput 偏好',
  'ball.label': '展开 Codinput 输入面板',
  'ball.title': '展开 Codinput',
  'side.notice': '本会话的输入面已在另一个分栏中打开（输入入口唯一）。',
  'side.guideDesc': '代码编辑器风格的输入面板；开启期间主输入框由本面板接管（共用同一台输入机）',
  'side.disabled': 'Codinput 接管已关闭：主输入在原输入位（官方输入框）。输入 /codinput 或到 设置 → Codinput 重新开启。',
  'tool.stop': '停止生成',
  'image.preview': '原图预览',
  'image.closePreview': '关闭原图预览',
  'image.openOriginal': '查看原图',
  'image.openOriginalLabel': '{name}，点击查看原图',
  'cmd.enter': '进入 Codinput 输入接管',
  'cmd.exit': '退出 Codinput，恢复官方输入框',
  'float.dragToFloat': '拖动脱出为悬浮窗',
  'float.dragToMove': '拖动移动，拖回底部恢复普通模式',
  'float.dockPulling': '向上拖出以悬浮 · 松手取消',
  'float.dockIdle': '拖回底部恢复普通模式',
  'float.dockArmed': '松手恢复普通模式',
};

/** 英文词典（键集与中文一致）。 */
const EN: Dict = {
  'head.edit': 'Edit',
  'head.preview': 'Preview',
  'head.editOnly': 'Edit only',
  'head.previewOnly': 'Preview only',
  'head.split': 'Edit + Preview',
  'editor.placeholder': 'Describe what you want to build — / for commands, @ for files or chats',
  'preview.empty': 'Nothing to preview',
  'tool.command': 'Commands (/)',
  'tool.send': 'Send message',
  // Official 0.2.2 input.* copy (conversation dictionary, verbatim).
  'tool.sending': 'Sending message',
  'tool.continue': 'Continue generating',
  'tool.sendQueue': 'Queue message',
  'tool.sendSteer': 'Steer message',
  'tool.model': 'Select model, current {name}',
  'tool.modelPlain': 'Select model',
  'tool.context': '{percent}% context used',
  'tool.contextTitle': 'Context used',
  'attach.group': 'Draft attachments',
  'attach.uploading': 'Uploading…',
  'attach.failed': 'Upload failed',
  'attach.retry': 'Retry upload',
  'attach.remove': 'Remove attachment {name}',
  'attach.scrollLeft': 'Scroll attachments left',
  'attach.scrollRight': 'Scroll attachments right',
  'attach.channelUnavailable': 'Attachment channel unavailable',
  'attach.pending': 'Pending file {name}',
  'stats.prompt': 'System prompt',
  'stats.tools': 'Tool definitions',
  'stats.messages': 'Conversation',
  'menu.model': 'Model',
  'menu.reasoning': 'Reasoning effort',
  'menu.reasoningNone': 'The current model exposes no reasoning effort.',
  'menu.refreshingModels': 'Refreshing model list…',
  'menu.noModels': 'No models available.',
  'md.mermaidError': 'Mermaid render failed',
  'perm.trigger': 'Access mode, current: {name}',
  'perm.confirmTitle': 'Enable full access?',
  'perm.confirmEnable': 'Enable full access',
  'perm.warning':
    'With full access the agent skips most confirmations and can perform more actions directly, including sensitive operations, file writes, or external commands. Only use it when you trust the current task.',
  'perm.ack': 'I understand the risk and want to continue',
  'perm.cancel': 'Cancel',
  'perm.close': 'Close',
  'perm.switchFailed': 'Failed to switch permission',
  'perm.channelRejected': 'Command channel rejected',
  'perm.noInputSurface': 'No input surface available',
  'perm.preset.read-only': 'Read only',
  'perm.preset.workspace-write': 'Write in workspace',
  'perm.preset.danger-full-access': 'Full access',
  'set.enabled': 'Take over composer',
  'set.enabledDesc': 'Turning it off restores the official composer; the draft is kept. /codinput toggles it too.',
  'set.userMarkdown': 'Markdown for user messages',
  'set.userMarkdownDesc': 'Render your own (right-side) messages as Markdown — headings, lists, code blocks; off restores the official plain text',
  'umsg.copy': 'Copy',
  'umsg.copied': 'Copied',
  'umsg.referenceSummary': 'Referenced: {labels}',
  'umsg.clock.md': '{m}/{d}',
  'umsg.clock.ymd': '{y}/{m}/{d}',
  'umsg.extraBlock': 'Extra content block',
  'umsg.image': 'Image',
  'set.lineNumbers': 'Show line numbers',
  'set.lineNumbersDesc': 'The current line and its gutter number stay highlighted',
  'set.markdownMono': 'Monospace ligatures in Markdown',
  'set.markdownMonoDesc':
    'Render previews and your own messages in the JetBrains Mono ligature font, so -> shows as an arrow while the text itself stays unchanged (the editor always shows literal characters); turn it off to restore the reading font. Code blocks are unaffected',
  'set.float3d': '3D float',
  'set.float3dDesc':
    'In floating mode, orient the card on a subtle sphere around the viewport center with drag lift, inertia settle, dynamic shadows, and rim highlights',
  'set.font': 'Editor font',
  'set.fontDesc': 'CSS font-family; leave empty for the default',
  'set.sendKey': 'Send shortcut',
  'set.sendKeyDesc': 'Click, then press any combination to record it; must differ from the line-break shortcut',
  'set.lineBreakKey': 'Line-break shortcut',
  'set.lineBreakKeyDesc': 'Click, then press any combination to record it; must differ from the send shortcut',
  'set.defaultView': 'Default view',
  'set.defaultViewDesc': 'Initial layout of the takeover panel',
  'set.recording': 'Press keys…',
  'set.reset': 'Reset',
  'set.resetAction': 'Reset',
  'set.resetAll': 'Clear all Codinput preferences',
  'ball.label': 'Open the Codinput input panel',
  'ball.title': 'Open Codinput',
  'side.notice': "This session's input panel is already open in another split pane (only one input surface exists).",
  'side.guideDesc': 'Code-editor style input panel. While enabled it takes over the composer (sharing the same input machine).',
  'side.disabled': 'Codinput takeover is off: the composer is back at its original place (official input). Type /codinput or open Settings → Codinput to re-enable.',
  'tool.stop': 'Stop generating',
  'image.preview': 'Original image preview',
  'image.closePreview': 'Close original image preview',
  'image.openOriginal': 'View original',
  'image.openOriginalLabel': '{name}, click to view the original',
  'cmd.enter': 'Enable the Codinput composer takeover',
  'cmd.exit': 'Disable Codinput and restore the official composer',
  'float.dragToFloat': 'Drag to float',
  'float.dragToMove': 'Drag to move; drop at bottom to dock',
  'float.dockPulling': 'Drag up to float · release to cancel',
  'float.dockIdle': 'Drag to bottom to dock',
  'float.dockArmed': 'Release to return to normal mode',
};

interface LocaleFaceLike {
  register?(ns: string, locale: string, dict: Dict): (() => void) | void;
  bind?(ns: string): (key: string, params?: TranslateParams) => string;
  subscribe?(fn: () => void): () => void;
  getSnapshot?(): { active?: string };
}

let hostFace: LocaleFaceLike | null = null;
let bound: ((key: string, params?: TranslateParams) => string) | null = null;
let activeLocale = 'zh';
let localeVersion = 0;
const listeners = new Set<() => void>();
const foreignBinds = new Map<string, ((key: string, params?: TranslateParams) => string) | null>();

function emit(): void {
  localeVersion += 1;
  for (const fn of listeners) fn();
}

function interpolate(text: string, params?: TranslateParams): string {
  if (!params) return text;
  return text.replace(/\{(\w+)\}/g, (whole, key: string) => {
    const value = params[key];
    return value === undefined ? whole : String(value);
  });
}

/** 当前语言的内置词典（宿主 bind 不可用时的兜底）。 */
function builtinDict(): Dict {
  return activeLocale.startsWith('zh') ? ZH : EN;
}

/** 安装：注册词典并绑定翻译函数（宿主 locale 服务就绪后调用一次；返回卸载清理函数）。 */
export function installI18n(locale: unknown): (() => void) | undefined {
  const face = locale as LocaleFaceLike | undefined;
  if (!face) return undefined;
  hostFace = face;
  foreignBinds.clear();
  const disposers: Array<() => void> = [];
  try {
    const offZh = face.register?.(NS, 'zh', ZH);
    if (typeof offZh === 'function') disposers.push(offZh);
    const offEn = face.register?.(NS, 'en', EN);
    if (typeof offEn === 'function') disposers.push(offEn);
    bound = face.bind?.(NS) ?? null;
  } catch {
    // 重复注册（热重载）或形状漂移：退回内置词典
    try {
      bound = face.bind?.(NS) ?? null;
    } catch {
      bound = null;
    }
  }
  try {
    const snapshot = face.getSnapshot?.();
    if (snapshot?.active) activeLocale = snapshot.active;
    const offSub = face.subscribe?.(() => {
      const next = face.getSnapshot?.();
      if (next?.active && next.active !== activeLocale) activeLocale = next.active;
      emit();
    });
    if (typeof offSub === 'function') disposers.push(offSub);
  } catch {
    /* 快照不可用：语言切换不重渲染，但不影响首屏文案 */
  }
  emit();
  return () => {
    for (const off of disposers.splice(0)) {
      try {
        off();
      } catch {
        /* 忽略宿主卸载期异常 */
      }
    }
    if (hostFace === face) {
      hostFace = null;
      bound = null;
      foreignBinds.clear();
    }
  };
}

/**
 * 绑定其他命名空间的宿主词典（如语音插件注册的 voice-input——渲染官方条目
 * 组件时，官方 renderer 传的就是 locale.bind(entry.locale)）。返回引用稳定
 * 的翻译函数；宿主 face 未就绪或 bind 失败返回 null。结果按 ns 缓存。
 */
export function bindForeign(ns: string): ((key: string, params?: TranslateParams) => string) | null {
  const cached = foreignBinds.get(ns);
  if (cached) return cached;
  // 只缓存成功的绑定：宿主 locale 服务可能晚于首次调用就绪，null 缓存会让
  // 之后所有文案永远拿不到官方词典。
  let foreign: ((key: string, params?: TranslateParams) => string) | null = null;
  try {
    foreign = hostFace?.bind?.(ns) ?? null;
  } catch {
    foreign = null;
  }
  if (foreign) foreignBinds.set(ns, foreign);
  return foreign;
}

export function subscribeI18n(fn: () => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

function getLocaleVersion(): number {
  return localeVersion;
}

function lookup(key: string, params?: TranslateParams): string | undefined {
  if (bound) {
    try {
      const text = bound(key, params);
      if (text && text !== key) return text;
    } catch {
      /* 落到内置词典 */
    }
  }
  const dict = builtinDict()[key] ?? ZH[key];
  return dict === undefined ? undefined : interpolate(dict, params);
}

/**
 * 翻译。优先级：宿主 bind（按当拍语言查，含宿主自己的回退链）→ 内置词典 →
 * 原 key。宿主词典缺键时 bind 原样返回 key，这里据此再落到内置词典。
 */
export function t(key: string, params?: TranslateParams): string {
  return lookup(key, params) ?? key;
}

/**
 * 官方输入框文案的宿主命名空间映射：这些字符串宿主 `conversation` 词典里已有
 * （8 种语言、与官方输入框逐字一致），不再由本插件的 zh/en 复刻一遍。
 * 键值映射到官方 rc.3 的 `input.*` / `file.*` 等键；宿主词典缺失时回退内置词典。
 */
const HOST_BAR_KEYS: Record<string, string> = {
  'tool.command': 'input.commands',
  'tool.send': 'input.send',
  'tool.stop': 'input.stop',
  'tool.sending': 'input.sending',
  'tool.sendQueue': 'input.send.queue',
  'tool.sendSteer': 'input.send.steer',
  'tool.continue': 'input.continue',
  'attach.group': 'attachment.pending',
  'attach.uploading': 'file.uploading',
  'attach.failed': 'file.uploadFailed',
  'attach.retry': 'file.retry',
  'attach.remove': 'file.remove',
  'attach.pending': 'file.pending',
};

/**
 * 官方 bar 文案：优先取宿主 `conversation` 词典（与官方输入框逐字一致、随宿主
 * 语言包），缺失时回退本插件词典。用于工具行标签/提示等「官方已有同名文案」处。
 */
export function tBar(key: string, params?: TranslateParams): string {
  const hostKey = HOST_BAR_KEYS[key];
  if (hostKey !== undefined) {
    const host = bindForeign('conversation');
    if (host) {
      try {
        const text = host(hostKey, params);
        if (text && text !== hostKey) return text;
      } catch {
        /* 宿主 bind 异常：回退内置词典 */
      }
    }
  }
  return t(key, params);
}

/**
 * 可选翻译：词典里没有该键时返回 undefined——用于动态键，
 * 调用方回退显示原名而不是把 key 摆到界面上。
 */
export function tOptional(key: string, params?: TranslateParams): string | undefined {
  return lookup(key, params);
}

/** 语言切换时重渲染的订阅钩子（useSyncExternalStore，无撕裂，返回稳定的 t）。 */
export function useT(): typeof t {
  useSyncExternalStore(subscribeI18n, getLocaleVersion, getLocaleVersion);
  return t;
}
