/**
 * 座位镜像通用引擎：把注册在官方 InputBar 子槽位（conversation.input.left /
 * conversation.input.right 等，均为 list/session）上的**条目组件本体**在自绘
 * 工具行的对应座位重新渲染。
 *
 * 为什么需要这里：这些子槽位由官方 InputBar（conversation.composer.bar 的缺省
 * 条目）声明并在其工具行内渲染——Codinput 以 priority -1 遮蔽官方条目后，槽位
 * 声明仍在（宿主按注册周期记账），但渲染点随官方输入框一起消失，第三方按钮/
 * 读数便无处挂载（issue #1）。本组件复刻官方 renderer 的 list 合成，座位名与
 * standard props 面由调用方给（InputLeftSlot / InputRightSlot 两片薄壳）——
 * 一套引擎、N 个座位。
 *
 * props 合成复刻官方 SessionEntry → renderEntry 的展开式：
 *   {...standard(kit), ...entryInjectProps(entry, sessionId), ...(t)}
 * standard 走 bar/session 条目已下发的原样通道（CodinputBar 与
 * SidebarCodinputBody 把宿主 kit props 减去 owner props 传下来）——第三方
 * 条目按官方契约消费 sessionId + useSession/useInput 选择器 hook +
 * inputActions（enhancer v3.4.x 实证），有的条目还从 inject 面拿自带 props
 * （如 qoder 左座的 directory store 与 t）；这里只做原样转发，绝不重新
 * 物化宿主绑定。
 *
 * 检测即兼容：无条目 → 渲染 null；单条目崩溃被 EntryBoundary 隔离，不连坐
 * 输入面；旧宿主（无该子槽位声明）槽位未声明 → entries 空数组，同样不渲染。
 * 条目声明 store 的 useStore/actions 面插件侧不可复现（官方 host.storeOf
 * 私有），现网无此类条目；如出现则降级为无 store props 渲染。
 */

import { memo, useMemo } from 'react';
import type { ReactNode } from 'react';
import {
  entryId,
  entryInjectFailed,
  firstComponentEntry,
  listRows,
  renderSlotEntry,
  useSlotEntries,
} from './slotEntry';

export interface InputSlotSeatProps {
  /** 官方子槽位全名（如 conversation.input.left）。 */
  slot: string;
  sessionId: string | undefined;
  /** 宿主下发给本插件条目的 standard props 原样面（见组件头注释）。 */
  standard: Record<string, unknown> | undefined;
  /**
   * 镜像时跳过的宿主自带条目 id（可选）：这些条目的 UI 已由 Codinput 自绘面
   * 顶替，整座镜像会重复（典型：`composer.dock` 的官方 Activity/Usage 胶囊）。
   */
  excludeIds?: readonly string[] | undefined;
}

export const InputSlotSeat = memo(function InputSlotSeat(props: InputSlotSeatProps): JSX.Element | null {
  const { slot, sessionId, standard, excludeIds } = props;
  const entries = useSlotEntries(slot);
  // 官方 list 合成：id 首占位去重 + order 升序（entries 快照引用稳定，直接 memo）。
  const rows = useMemo(() => listRows(entries, excludeIds), [entries, excludeIds]);

  // 官方同款门槛：无会话不渲染（input.left / input.right 都是 strict session 槽位）。
  if (sessionId === undefined || rows.length === 0) return null;

  return <>{rows.map((entry, index) => renderSlotEntry(entry, entryId(entry, index), { sessionId, standard }))}</>;
});

export interface InputSingleSlotProps {
  /** 官方单值子槽位全名（如 conversation.input.permission / .plan）。 */
  slot: string;
  sessionId: string | undefined;
  /** 宿主下发给本插件条目的 standard props 原样面。 */
  standard: Record<string, unknown> | undefined;
  /** 官方 renderSlot 第二参数的 owner props（如 { locked }）。 */
  ownerProps?: Record<string, unknown> | undefined;
  /**
   * 兜底渲染（可选）：
   * - 条目 inject 面在插件 fiber 里不可复现（依赖宿主服务面的 inject 会抛
   *   `without inject`，见 slotEntry.boundInject）→ 渲染 fallback；
   * - 条目组件自身崩溃 → EntryBoundary 回退 fallback。
   * 缺省 null（槽位有占用者但无法镜像时按官方「画不出来」处理）。
   */
  fallback?: ReactNode;
  /**
   * 槽位**已声明但无占用者**时也渲染 fallback（缺省 false = 官方留空）。
   * 用于「官方条目存在才镜像、否则保住旧自绘实现」的座位（附件行）。
   */
  fallbackOnMissing?: boolean;
}

/**
 * 单值槽位镜像（0.2.2 的 `conversation.input.permission` / `.plan` 用）。
 *
 * 官方口径（InputBar.tsx）：`renderSlot("conversation.input.permission", { locked })`
 * 与 `renderSlot("conversation.input.plan", { locked })` 位于 `.tools` 内
 * `.modes` 容器（permission 在前）。**槽位已声明但无占用者 = 官方留空**，
 * 因此这里对「已声明 + 空」返回 null，绝不回退自绘控件；「未声明」由调用方
 * 用 `useSlotDeclaration` 区分后决定回退（旧宿主才回退 PermissionMenu）。
 */
export const InputSingleSlot = memo(function InputSingleSlot(props: InputSingleSlotProps): JSX.Element | null {
  const { slot, sessionId, standard, ownerProps, fallback, fallbackOnMissing } = props;
  const entries = useSlotEntries(slot);
  const occupant = useMemo(() => firstComponentEntry(entries), [entries]);

  // 官方门槛：无会话不画该座位（InputBar 的 sessionId 三元）。
  if (sessionId === undefined) return null;
  if (occupant === null) return <>{fallbackOnMissing === true ? fallback ?? null : null}</>;

  // 让位可行性：inject 面必须在宿主 fiber 上下文里才算数（见 slotEntry）。
  // 不可复现时回退调用方给的兜底（permission 用自绘菜单保住旧功能）。
  if (entryInjectFailed(occupant, sessionId)) return <>{fallback ?? null}</>;

  return renderSlotEntry(occupant, `single:${entryId(occupant, 0)}`, {
    sessionId,
    standard,
    ownerProps,
    fallback,
  });
});
