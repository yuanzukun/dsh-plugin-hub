/**
 * GatewayClient — the gateway adapter the TUI app talks to.
 *
 * The app expects a GatewayClient: an EventEmitter speaking a JSON-RPC-style
 * `tui_gateway` protocol. clawcodex instead has an agent-server that speaks its
 * own NDJSON protocol over stdio, so this class keeps the EXACT public interface
 * the app depends on (start/drain/kill/getLogTail/publishLocalEvent/request,
 * emitting 'event' and 'exit') but:
 *   - spawns `clawcodex agent-server --stdio` (the backend),
 *   - maps clawcodex NDJSON messages → `GatewayEvent`s,
 *   - maps the app's RPCs (prompt.submit, session.interrupt, …) → agent-server
 *     stdin (user messages + control_requests).
 *
 * Phase 1 covers the basic flow (prompt → streamed text response). Tools,
 * permissions and the remaining control RPCs are best-effort stubs refined in
 * Phase 2.
 */
import { type ChildProcess, spawn } from 'node:child_process'
import { EventEmitter } from 'node:events'
import { readdirSync } from 'node:fs'
import { resolve as pathResolve } from 'node:path'
import { createInterface } from 'node:readline'

import type {
  CostSnapshot,
  CronSnapshot,
  GatewayEvent,
  GoalSnapshot,
  PatchHunk,
  StructuredDiffPayload
} from './gatewayTypes.js'
import { formatTotalCost, setLastCostSnapshot } from './lib/costSummary.js'
import { extractTag } from './lib/messages.js'
import type { SessionInfo } from './types.js'

const STARTUP_TIMEOUT_MS = 30_000
const MAX_LOG_LINES = 500
const RPC_TIMEOUT_MS = 5_000

/** Worktree exit RPCs get a LONG deadline: `git worktree remove --force` on a
 *  node_modules-scale tree can far exceed the default 5 s — a timeout there
 *  would misreport "cleanup failed" and SIGTERM the backend mid-removal,
 *  leaving a half-deleted directory. The prompt shows an interim
 *  "Removing worktree…" state while this runs. */
const WORKTREE_RPC_TIMEOUT_MS = 600_000

/** Image attach/clipboard RPCs need more than the 5 s default: the backend
 *  shells out to osascript/xclip (~1.5 s for a large clipboard image on macOS,
 *  per the reference implementation's own measurement) and then decodes and
 *  downsamples through Pillow. A timeout here would drop an image the user
 *  watched themselves paste. */
const IMAGE_RPC_TIMEOUT_MS = 30_000
// clawcodex app version shown in the banner ("clawcodex v{version}"). Keep in
// sync with the installer (install.sh INSTALLER_VERSION).
const DSH_CCTUI_VERSION = '1.4.0'

/** Command that launches the clawcodex agent-server (set by the Python launcher). */
function resolveAgentCmd(): string[] {
  const raw = process.env.DSH_CCTUI_AGENT_SERVER_CMD?.trim()

  if (!raw) {return ['clawcodex', 'agent-server']}

  // JSON-array form (what the Python launcher now sets): survives argv
  // elements containing spaces — e.g. a Windows interpreter path under
  // `C:\Program Files\...` or a user profile with a space. Legacy
  // space-joined values (older launchers) keep the whitespace split.
  if (raw.startsWith('[')) {
    try {
      const parsed: unknown = JSON.parse(raw)

      if (Array.isArray(parsed) && parsed.length > 0 && parsed.every(x => typeof x === 'string')) {
        return parsed
      }
    } catch {
      // fall through to the legacy split
    }
  }

  return raw.split(/\s+/)
}

function safeJson(v: unknown): string {
  if (typeof v === 'string') {return v}

  try {
    return JSON.stringify(v)
  } catch {
    return String(v)
  }
}

/** A human label for a permission suggestion's rule(s), e.g. `Bash(ls:*)` or
 *  `Bash(grep:*), Bash(tr:*), …` for a compound command's bundled rules (just
 *  the tool name for a content-less rule). Shown on the "don't ask again"
 *  option so the user sees what it will persist. */
export function describeSuggestionRule(suggestion: any): string | null {
  const rules = Array.isArray(suggestion?.rules) ? suggestion.rules : []

  const labels = rules
    .filter((r: any) => r && r.tool_name)
    .map((r: any) => (r.rule_content ? `${r.tool_name}(${r.rule_content})` : String(r.tool_name)))

  if (labels.length === 0) {return null}

  return labels.length > 3 ? `${labels.slice(0, 3).join(', ')}, …` : labels.join(', ')
}

// The human-reviewable action for a permission prompt: the actual Bash command,
// file path, or URL under review — NOT the full tool-input JSON blob (which the
// box previously dumped verbatim and made the prompt unreadable).
export function approvalCommandText(input: unknown): string {
  if (input && typeof input === 'object') {
    const o = input as Record<string, unknown>

    // pattern before path so a Grep/Glob box shows the search pattern (matching
    // the tool trail label), not the directory it searched.
    for (const key of ['command', 'file_path', 'url', 'pattern', 'path']) {
      if (typeof o[key] === 'string' && o[key]) {return o[key] as string}
    }
  }

  return safeJson(input)
}

/** Pick the salient arg for a tool so the trail label reads `Bash(ls)` /
 *  `Read(package.json)` / `Grep(TODO)` (Claude-style) instead of a bare tool
 *  name. File paths are shown relative to the workspace so the label stays
 *  short; search tools show their pattern rather than the search directory. */
function toolContext(input: any): string {
  if (!input || typeof input !== 'object') {return ''}

  if (input.pattern != null) {return String(input.pattern)}
  const p = input.file_path ?? input.path ?? input.notebook_path

  if (p != null) {return relativizePath(String(p))}
  const v = input.command ?? input.url ?? input.query ?? input.description ?? input.prompt

  return v == null ? '' : String(v)
}

/** Shorten an absolute path to a workspace-relative path (or basename). */
function relativizePath(p: string): string {
  const ws = (process.env.DSH_CCTUI_WORKSPACE || process.env.DSH_CCTUI_CWD || process.cwd()).replace(/\/+$/, '')

  if (ws && p.startsWith(ws + '/')) {return p.slice(ws.length + 1)}
  const parts = p.split('/')

  return parts[parts.length - 1] || p
}

/** Summarize a tool result for the trail. A successful Read returns
 *  line-numbered file contents (cat -n: `N\t…`), which read as noise when
 *  crammed onto one line, so collapse it to a line count (Claude-style). Only
 *  genuine numbered output is collapsed — errors (is_error) and Read's other
 *  acknowledgements (empty-file / file_unchanged warnings, PDF/image stubs)
 *  aren't `N\t…` text and pass through, so nothing is mislabeled or hidden. */
// Memory bound for retained raw results — render caps (VERBOSE_TRAIL_MAX_*)
// apply separately at display time.
const RESULT_RAW_MAX_CHARS = 48_000

// Full result retained only when the compact summary lost information.
function rawToolResult(formatted: string, full: string): string | undefined {
  const raw = (full ?? '').trim()

  if (!raw || raw === formatted.trim()) {
    return undefined
  }

  return raw.length > RESULT_RAW_MAX_CHARS ? raw.slice(0, RESULT_RAW_MAX_CHARS) + '\n…' : raw
}

// TodoWrite's input IS the todo list — surface it on tool events so the task
// HUD renders (the original never shows todo tool calls inline; the checklist
// under the busy line is the whole UI).
function todosFromInput(name: string | undefined, input: unknown): undefined | unknown[] {
  if (name !== 'TodoWrite' || !input || typeof input !== 'object') {
    return undefined
  }

  const todos = (input as { todos?: unknown }).todos

  return Array.isArray(todos) ? todos : undefined
}

type TaskTodo = {
  activeForm?: string
  content: string
  id: string
  status: 'completed' | 'in_progress' | 'pending'
}

const taskListLine = /^#(\S+)\s+\[(pending|in_progress|completed)\]\s+(.+)$/
const createdTaskId = /^Task #(\S+) created successfully:/m

// Per-tool result summaries, matching the original Claude Code transcript
// (tools/*/UI.tsx): Read → "Read N lines", Grep/Glob → "Found N …", Bash →
// first 3 stdout lines + overflow hint, errors → red "Error: …" capped at 10
// lines. Hints reference ctrl+o — the real expand binding (toggles
// /details expanded); the raw output rides tool.complete as result_raw so
// the expanded view can actually show it.
const ERROR_RESULT_MAX_LINES = 10
const BASH_RESULT_MAX_LINES = 3

/** WebSearch display data forwarded by the agent-server (`tool_use_result`
 *  trimmed to the two numbers the original's one-liner needs). */
export type WebSearchDisplay = { durationSeconds?: number; searchCount?: number }

// One marker line per performed search in the model-facing blob
// (web_search.py _map_result_to_api emits `Links: […]` / `No links found.`
// per structured result block). Fallback only — the envelope is authoritative.
const WEB_SEARCH_BLOCK_RE = /^(?:Links: \[|No links found\.$)/gm

// Exact port of WebSearchTool/UI.tsx renderToolResultMessage: "Did N
// search(es) in Xs" (whole seconds at >=1s, else ms). Without the envelope
// (older backend) the duration is unknown and omitted.
function webSearchSummary(result: string, webSearch?: WebSearchDisplay): string {
  const searchCount = webSearch?.searchCount ?? (result.match(WEB_SEARCH_BLOCK_RE)?.length ?? 0)
  const line = `Did ${searchCount} search${searchCount !== 1 ? 'es' : ''}`
  const s = webSearch?.durationSeconds

  return s === undefined ? line : `${line} in ${s >= 1 ? `${Math.round(s)}s` : `${Math.round(s * 1000)}ms`}`
}

/** Image-read display data forwarded by the agent-server (`tool_use_result`
 *  trimmed to the byte count the one-liner needs). Carries no base64 —
 *  the payload travels on the model-facing tool_result content only. */
export type ImageDisplay = { originalSize?: number }

/** AskUserQuestion display data forwarded by the agent-server (`tool_use_result`
 *  trimmed to the answered map, or the declined flag). The model-facing prose
 *  ("User has answered your questions: …") travels on the tool_result content;
 *  the transcript renders from this structure instead of scraping that. */
export type AskUserDisplay = { answers?: Record<string, string>; declined?: boolean }

/** Port of AskUserQuestionTool.tsx's renderToolResultMessage body: one
 *  `· question → answer` row per answered question, in the order they were
 *  answered (the answers map's insertion order) — which differs from ask order
 *  if the user tabbed back and forth. */
export function askUserSummary(display: AskUserDisplay): string {
  if (display.declined) {
    return 'User declined to answer questions'
  }

  const entries = Object.entries(display.answers ?? {})

  // An empty submit is reachable: the review step lets you submit with
  // questions left blank. Say so rather than rendering nothing at all.
  return entries.length
    ? entries.map(([question, answer]) => `· ${question} → ${answer}`).join('\n')
    : 'No answers submitted'
}

/** Exact port of typescript/src/utils/format.ts formatFileSize. */
export function formatFileSize(sizeInBytes: number): string {
  const kb = sizeInBytes / 1024

  if (kb < 1) {
    return `${sizeInBytes} bytes`
  }

  // Compare the rounded magnitude so values that round up to 1024 roll over to
  // the next unit (e.g. 1048575 bytes → "1MB", not "1024KB").
  if (Number(kb.toFixed(1)) < 1024) {
    return `${kb.toFixed(1).replace(/\.0$/, '')}KB`
  }

  const mb = kb / 1024

  if (Number(mb.toFixed(1)) < 1024) {
    return `${mb.toFixed(1).replace(/\.0$/, '')}MB`
  }

  const gb = mb / 1024

  return `${gb.toFixed(1).replace(/\.0$/, '')}GB`
}

// Port of FileReadTool/UI.tsx renderToolResultMessage `case 'image'`:
// "Read image (12.3KB)". The size comes from the envelope; a backend that
// predates it leaves the count unknown, so say only what we know rather than
// inventing a number.
//
// The "Read" in the label is hardcoded, where the original earns it structurally
// (renderToolResultMessage is per-tool, so the string cannot escape
// FileReadTool). Here the backend's `_display_tool_result` is shape-keyed and
// global, so a future tool emitting `{type:"image", file:{originalSize}}` would
// borrow this wording. Read is the only producer of that shape today; give the
// label a tool-aware branch if a second one appears.
function imageSummary(image?: ImageDisplay): string {
  const size = image?.originalSize
  // Guard finiteness HERE, not only in imageDisplay: formatFileSize divides and
  // toFixed()s, so a non-finite size renders "NaNGB". imageDisplay already
  // filters the wire path, but this function is also reachable with a
  // hand-built envelope, and an unknown size should read as unknown.
  const known = typeof size === 'number' && Number.isFinite(size)

  return known ? `Read image (${formatFileSize(size)})` : 'Read image'
}

/** Flatten Anthropic tool_result content for DISPLAY.
 *
 *  `content` is either a string or an array of content blocks. The array form
 *  used to go through `safeJson`, which dumped megabytes of base64 into the
 *  transcript the moment a tool returned an image block — the observed bug was
 *  `Read` on a PNG printing
 *  `[{"type":"image","source":{"type":"base64","data":"/9j/4AAQ…"}}]` as text.
 *
 *  Binary-bearing blocks are replaced by a short placeholder instead of being
 *  serialized. Applies to every tool that can emit them (Read, PDF page
 *  extraction, Bash image output), not just Read. */
export function flattenToolResultContent(content: unknown): string {
  if (typeof content === 'string') {return content}

  if (!Array.isArray(content)) {return safeJson(content)}

  return content
    .map(block => {
      if (typeof block === 'string') {return block}

      if (!block || typeof block !== 'object') {return safeJson(block)}

      const type = (block as { type?: unknown }).type

      if (type === 'text') {return String((block as { text?: unknown }).text ?? '')}

      if (type === 'image') {return '[image]'}

      if (type === 'document') {return '[document]'}

      return safeJson(block)
    })
    .filter(part => part.length > 0)
    .join('\n')
}

// Shared with the backend Read tool (read.py FILE_NOT_FOUND_CWD_NOTE) and the
// original (utils/file.ts:213) — the marker the per-tool error renderers key
// "File not found" on.
const FILE_NOT_FOUND_CWD_NOTE = 'Note: your current working directory is'

/** Collapsed one-liners for known error shapes, port of each tool's
 *  renderToolUseErrorMessage (tools/{FileReadTool,GrepTool,GlobTool,
 *  FileEditTool,FileWriteTool,NotebookEditTool}/UI.tsx). These fire in the
 *  original's non-verbose transcript — our trail line — while the raw text
 *  stays reachable behind ctrl+o (result_raw), the verbose analog. Only
 *  `<tool_use_error>`-tagged results collapse (pre-execution failures:
 *  validation, permissions); thrown call() errors arrive untagged and fall
 *  through to the full message. Exception: Read's file-not-found check is on
 *  the raw string — Read throws that error, so it's never tagged
 *  (FileReadTool/UI.tsx:150-156). */
function toolSpecificErrorSummary(name: string | undefined, result: string): string | undefined {
  if (name === 'Read' && result.includes(FILE_NOT_FOUND_CWD_NOTE)) {
    return 'File not found'
  }

  const tagged = extractTag(result, 'tool_use_error')

  if (!tagged) {return undefined}

  switch (name) {
    case 'Read':
      return 'Error reading file'

    case 'Grep':

    case 'Glob':
      return tagged.includes(FILE_NOT_FOUND_CWD_NOTE) ? 'File not found' : 'Error searching files'

    case 'Edit':
      // "Show a less scary message for intended behavior" (FileEditTool/UI.tsx:138).
      if (tagged.includes('File has not been read yet')) {return 'File must be read first'}

      return tagged.includes(FILE_NOT_FOUND_CWD_NOTE) ? 'File not found' : 'Error editing file'

    case 'Write':
      return 'Error writing file'

    case 'NotebookEdit':
      return 'Error editing notebook'

    default:
      return undefined
  }
}

/** Collapse the legacy `{"questions":[…],"status":"pending"}` dead-letter
 *  result to one line. Falls back to the raw text only if it does not parse as
 *  that shape, so a genuinely different payload is never silently hidden. */
function pendingQuestionsSummary(result: string): string {
  try {
    const parsed = JSON.parse(result)
    const questions = parsed?.questions

    if (Array.isArray(questions)) {
      const n = questions.length

      return `Waiting on ${n} question${n === 1 ? '' : 's'} (no interactive surface)`
    }
  } catch {
    // Not JSON — fall through and show whatever it is.
  }

  return result
}

/** Bash-style result preview: the first few lines, then a `+N lines` hint.
 *  Shared by the Bash tool and by TaskOutput's background-shell branch —
 *  the original routes the latter through the very same renderer
 *  (TaskOutputTool.tsx:384-410 hands `task.output` to BashToolResultMessage),
 *  so the two must not drift. */
function bashOutputSummary(result: string): string {
  const trimmed = result.replace(/\s+$/, '')

  if (!trimmed) {
    return '(No output)'
  }

  const lines = trimmed.split('\n')

  // CC parity: when exactly one line overflows, show it instead of a hint.
  if (lines.length <= BASH_RESULT_MAX_LINES + 1) {
    return trimmed
  }

  return [
    ...lines.slice(0, BASH_RESULT_MAX_LINES),
    `… +${lines.length - BASH_RESULT_MAX_LINES} lines (ctrl+o to expand)`
  ].join('\n')
}

/** The tool's own name plus its back-compat aliases (tasks_v2.py
 *  `aliases=("AgentOutputTool", "BashOutputTool")`). A model that calls an
 *  alias reaches the same backend tool, so it must reach the same renderer —
 *  in the original that is automatic, the renderer hanging off the resolved
 *  tool object rather than off the wire name. */
const TASK_OUTPUT_TOOL_NAMES = new Set(['AgentOutputTool', 'BashOutputTool', 'TaskOutput'])

/** The two tags a TaskOutput result can open with (`stuck_task_hint` leads
 *  when the poll guard fired). Used only when the tool name is unknown. */
const TASK_OUTPUT_LEAD_TAG = /^<(?:retrieval_status|stuck_task_hint)>/

/** A task object was serialized at all — as opposed to the `task: null`
 *  result, which carries `<retrieval_status>` and nothing else. */
const TASK_PRESENT_TAG = /<task_(?:id|type)>/

/** Opening tag of the wrapper a result over the persistence threshold is
 *  replaced with (tool_result_persistence.py PERSISTED_OUTPUT_TAG). Hyphen,
 *  not underscore. */
const PERSISTED_OUTPUT_TAG = '<persisted-output>'

/** Read the `<output>` block.
 *
 *  The captured log is written as `<output>\n…\n</output>` so it starts on its
 *  own line; those two newlines are delimiters, not content. Exactly one is
 *  stripped at each end — any further blank line or indentation is the task's
 *  own layout and must survive.
 *
 *  The unterminated case is real, not defensive padding. When a result clears
 *  the persistence threshold, `maybe_persist_large_tool_result` replaces the
 *  whole content with a `<persisted-output>` wrapper around a 2KB HEAD
 *  preview, which lands mid-log with no closing tag. `extractTag` requires the
 *  pair, so it returns null and the caller used to render "(No output)" for a
 *  result that plainly contains log text — worse than the raw dump this change
 *  removes. `_format_task_output` now keeps results under that threshold in
 *  the normal case; the per-message aggregate budget can still trip it, so
 *  take whatever follows the opening tag rather than claiming there was
 *  nothing.
 *
 *  That "everything after the opening tag" is only safe because the serializer
 *  emits `<output>` LAST — no metadata part can be swallowed. The two are
 *  load-bearing on each other: reordering the part list without revisiting
 *  this would start folding `<truncated>` / `<error>` into the log preview. */
function readOutputTag(result: string): string | undefined {
  const closed = extractTag(result, 'output')

  if (closed !== null) {
    return closed.replace(/^\n/, '').replace(/\n$/, '')
  }

  const open = result.indexOf('<output>')

  if (open === -1) {
    return undefined
  }

  // extractTag returns null for an EMPTY body as well as for a missing close,
  // and only the latter is a truncated preview. Without this, `<output></output>`
  // would take the fallback and render the literal string "</output>".
  // Unreachable today — the serializer gates on `text.strip()` — but the guard
  // costs one line and the failure mode is silent.
  if (result.indexOf('</output>', open) !== -1) {
    return ''
  }

  return (
    result
      .slice(open + '<output>'.length)
      .replace(/^\n/, '')
      // The wrapper closes itself after the cut, so drop its own trailing
      // bytes rather than showing them as log. Both shapes
      // build_large_tool_result_message emits: with and without the `...`
      // has-more marker.
      .replace(/\n?(?:\.\.\.\n)?<\/persisted-output>\s*$/, '')
  )
}

/** The fields TaskOutput's transcript row renders, recovered from the
 *  tool_result content. `hasTask` is false for the `task: null` result
 *  (unknown/evicted id) — distinct from a task whose fields are simply
 *  empty. */
type TaskOutputView = {
  description?: string
  hasTask: boolean
  output?: string
  retrievalStatus?: string
  status?: string
  taskType?: string
}

/** Read a TaskOutput result out of the two serializations it can arrive in.
 *
 *  The tagged form is what the current backend sends (tasks_v2.py
 *  `_task_output_map_result_to_api`). The `json.dumps` blob is what a backend
 *  older than that fix sends, and the two ship separately — `resolveAgentCmd`
 *  picks up whatever `clawcodex` is installed, which a TUI update does not
 *  move. Parsing both means a skewed pair still renders instead of falling
 *  back to the raw dump this change exists to remove. (It is NOT about
 *  transcripts: `/resume` restores the conversation backend-side and replies
 *  with counters only — it never replays tool results to the client, so no
 *  stored result ever reaches this function.)
 *
 *  Anything else declines, and the caller shows the content as-is. Note that
 *  the `<persisted-output>` wrapper is NOT such a case: its 2KB preview keeps
 *  the head of the part list intact, so `<retrieval_status>` still matches and
 *  this parses it — see `readOutputTag` for the half-cut `<output>` that
 *  leaves behind.
 *
 *  Captured output that itself contains a literal `</output>` ends the tag
 *  early and shortens the preview by that much. Same ambiguity the original's
 *  own wire format carries; it costs a few preview lines, never correctness —
 *  the untouched result still rides `result_raw` for ctrl+o. */
function parseTaskOutput(result: string): TaskOutputView | undefined {
  const retrievalStatus = extractTag(result, 'retrieval_status')

  if (retrievalStatus !== null) {
    const taskType = extractTag(result, 'task_type')

    return {
      description: extractTag(result, 'description') ?? undefined,
      // Tag PRESENCE, not extracted content: extractTag returns null for an
      // empty body too (`depth === 0 && content`, and '' is falsy), so a task
      // serialized with an empty id would otherwise read as "no task".
      hasTask: TASK_PRESENT_TAG.test(result),
      output: readOutputTag(result),
      retrievalStatus,
      status: extractTag(result, 'status') ?? undefined,
      taskType: taskType ?? undefined
    }
  }

  try {
    const parsed = JSON.parse(result)

    if (!parsed || typeof parsed !== 'object' || !('retrieval_status' in parsed)) {
      return undefined
    }

    const task = parsed.task
    const str = (v: unknown) => (typeof v === 'string' ? v : undefined)

    if (!task || typeof task !== 'object') {
      return { hasTask: false, retrievalStatus: str(parsed.retrieval_status) }
    }

    return {
      description: str(task.description),
      hasTask: true,
      output: str(task.output),
      retrievalStatus: str(parsed.retrieval_status),
      status: str(task.status),
      taskType: str(task.task_type)
    }
  } catch {
    return undefined
  }
}

/** Port of TaskOutputTool.tsx's renderToolResultMessage
 *  (TaskOutputResultDisplay, lines 353-582) in its non-verbose form — the
 *  full body stays reachable behind ctrl+o via result_raw, which is the
 *  original's `verbose` branch.
 *
 *  Task-type names are the backend's (`bash_background`, `local_agent`,
 *  `task_list`), not TS' (`local_bash`, `local_agent`, `remote_agent`); the
 *  branches are matched by role, not by spelling. */
function taskOutputSummary(result: string): string {
  const view = parseTaskOutput(result)

  if (!view) {
    return result
  }

  if (!view.hasTask) {
    return 'No task output available'
  }

  const output = view.output ?? ''

  // Closes the bug class this change exists to fix, rather than one instance
  // of it. `readOutputTag` recovers a preview cut INSIDE `<output>`; a cut
  // BEFORE it (reachable when an oversized `<description>` eats the whole 2KB
  // window) leaves no opening tag at all, and every branch below would then
  // report a truncated wrapper as "the task produced nothing". Showing the
  // wrapper is honest and actionable — it names the file holding the rest.
  if (!output && result.includes(PERSISTED_OUTPUT_TAG)) {
    return result
  }

  // Background shell → the Bash renderer, exactly as the original does.
  if (view.taskType === 'bash_background') {
    return bashOutputSummary(output)
  }

  // Subagent → never the body itself. The original prints only a pointer
  // because the result is already in the model's context and re-printing a
  // multi-paragraph answer under the tool row buries the transcript.
  if (view.taskType === 'local_agent') {
    if (view.retrievalStatus === 'success') {
      return 'Read output (ctrl+o to expand)'
    }

    if (view.retrievalStatus === 'timeout' || view.retrievalStatus === 'not_ready' || view.status === 'running') {
      return 'Task is still running…'
    }

    return 'Task not ready'
  }

  // Todos (`task_list`) and any future task type: identity line, then a
  // bounded peek at whatever output it carries.
  const head = `${view.description ?? ''} [${view.status ?? 'unknown'}]`.trim()

  return output ? `${head}\n${output.slice(0, 500)}` : head
}

export function formatToolResult(
  name: string | undefined,
  result: string,
  isError = false,
  webSearch?: WebSearchDisplay,
  image?: ImageDisplay,
  askUser?: AskUserDisplay
): string {
  if (isError) {
    const summary = toolSpecificErrorSummary(name, result ?? '')

    if (summary) {return summary}

    // Port of FallbackToolUseErrorMessage.tsx:30-55 — unwrap the wire-format
    // error markup before display: the `<tool_use_error>` envelope, sandbox
    // violation blocks, and bare `<error>` tags are model-facing bytes, not
    // something the transcript should print.
    const extracted = extractTag(result ?? '', 'tool_use_error') ?? (result ?? '')

    const trimmed = extracted
      .replace(/<sandbox_violations>[\s\S]*?<\/sandbox_violations>/g, '')
      .replace(/<\/?error>/g, '')
      .trim()

    let msg: string

    if (!trimmed) {
      msg = 'Tool execution failed'
    } else if (trimmed.includes('InputValidationError: ')) {
      msg = 'Invalid tool parameters'
    } else if (/^(Error|Cancelled): /.test(trimmed)) {
      msg = trimmed
    } else {
      msg = `Error: ${trimmed}`
    }

    const lines = msg.split('\n')

    if (lines.length > ERROR_RESULT_MAX_LINES) {
      const plusLines = lines.length - ERROR_RESULT_MAX_LINES

      return [
        ...lines.slice(0, ERROR_RESULT_MAX_LINES),
        `… +${plusLines} ${plusLines === 1 ? 'line' : 'lines'} (ctrl+o to see all)`
      ].join('\n')
    }

    return msg
  }

  // Shape-keyed ahead of the `!result` bail: an image read's display text comes
  // entirely from the envelope, and its flattened content ("[image]") carries
  // nothing worth printing.
  if (image) {
    return imageSummary(image)
  }

  // Same: the answers live on the envelope, and the content is the model-facing
  // prose ("User has answered your questions: …") which reads badly here.
  if (askUser) {
    return askUserSummary(askUser)
  }

  if (!result) {return result}

  // Backstop for a surface that never collected answers — an agent-server
  // predating the ask_user round-trip, or the MCP/SDK path — where the tool
  // falls through to its outbox branch and returns its own questions as a
  // "pending" result. Without this the whole {"questions":[…]} blob is dumped
  // into the transcript verbatim, which is the bug that started all this.
  if (name === 'AskUserQuestion') {
    return pendingQuestionsSummary(result)
  }

  // The original renders the whole result as ONE line (never the blob —
  // that's tens of wrapped rows of snippets); the full text stays reachable
  // behind ctrl+o via result_raw. Shape-keyed on the envelope too so a
  // mid-turn attach without tool_use bookkeeping still summarizes.
  if (name === 'WebSearch' || webSearch) {
    return webSearchSummary(result, webSearch)
  }

  if (name === 'Read' && /^\s*\d+[\t→ ]/.test(result)) {
    const n = result.split('\n').filter(l => l.length > 0).length

    return `Read ${n} line${n === 1 ? '' : 's'}`
  }

  if (name === 'Grep' || name === 'Glob') {
    if (/^No (files|matches|content)/i.test(result.trim())) {
      return `Found 0 ${name === 'Glob' ? 'files' : 'lines'}`
    }

    const n = result.split('\n').filter(l => l.length > 0).length
    const noun = name === 'Glob' ? (n === 1 ? 'file' : 'files') : n === 1 ? 'line' : 'lines'

    return `Found ${n} ${noun}${n > 0 ? ' (ctrl+o to expand)' : ''}`
  }

  if (name === 'Bash') {
    return bashOutputSummary(result)
  }

  // Without this the whole `{"retrieval_status":…,"task":{…}}` result was
  // printed verbatim under the tool row — a wall of JSON with every newline
  // of the captured log escaped to a literal `\n`, plus pid/started_at/
  // finished_at bookkeeping. Both halves are fixed: the backend now emits the
  // original's tagged format, and this renders it the way CC does.
  //
  // Shape-keyed as well as name-keyed, like the WebSearch branch above: a
  // client that attached mid-turn never saw the tool_use block, so `name` is
  // undefined and the name test alone would drop it straight back to a raw
  // dump. Only TaskOutput opens with these two tags.
  if (name ? TASK_OUTPUT_TOOL_NAMES.has(name) : TASK_OUTPUT_LEAD_TAG.test(result)) {
    return taskOutputSummary(result)
  }

  return result
}

/** clawcodex-backed slash commands (handled via command.dispatch → dispatchSlash).
 *  Drives both the catalog (recognition) and the complete.slash menu.
 *
 *  `hint` is the argument grammar shown dim in the menu and as ghost text
 *  after `/name ` (original CC's Command.argumentHint). Names shadowed by a
 *  TUI-local command (/model, /compact, /bg, /resume, /clear, /exit — the
 *  local registry dispatches first) deliberately carry NO hint here: the
 *  local command's argumentHint is the one that matches actual behavior. */
export const SLASHES: ReadonlyArray<{ desc: string; hint?: string; name: string }> = [
  { desc: 'Show available commands', name: '/help' },
  { desc: 'Clear the conversation', name: '/clear' },
  { desc: 'Switch the model', name: '/model' },
  { desc: 'Set the output style', hint: '[<name>]', name: '/output-style' },
  { desc: 'Change the startup logo color scheme', name: '/logo' },
  { desc: 'Choose what dsh-ccTUI is allowed to do', name: '/permissions' },
  { desc: 'Compact the conversation to save context', name: '/compact' },
  { desc: 'Show context-window usage', name: '/context' },
  { desc: 'Show the total cost and duration of the current session', name: '/cost' },
  { desc: 'Toggle Bash-output token compression (RTK-style)', hint: '[on|off|status]', name: '/eco' },
  // Local-registry command (slash/commands/session.ts) — listed here so it
  // reaches the completion menu; per the shadowing note above it carries no
  // hint (the local argumentHint is authoritative).
  { desc: 'Toggle the end-of-turn recap + suggested next prompt', name: '/recap' },
  { desc: 'Undo recent turns', hint: '[<turns>]', name: '/rewind' },
  { desc: 'Toggle extended thinking', hint: '[on|off|toggle]', name: '/thinking' },
  {
    desc: 'Set reasoning effort (or "ultracode" workflow mode)',
    // The real ladder is VALID_EFFORT_VALUES (agent_server _do_set_effort).
    // This used to advertise `minimal` — a GPT-5 level the backend now
    // rejects — while omitting xhigh and max, the two levels Claude Opus 5
    // actually wants for coding/agentic work.
    hint: '[low|medium|high|xhigh|max|auto|ultracode]',
    name: '/effort'
  },
  { desc: 'Switch the provider', hint: '[<provider>]', name: '/provider' },
  {
    desc: 'Configure the advisor reviewer model (consulted mid-task by the worker)',
    hint: '[<provider>:<model> [--client] [--effort <level>] | --effort <level> | --no-client | off|unset]',
    name: '/advisor'
  },
  {
    desc: 'Give a text-only model vision by fusing it with a multimodal one',
    hint: '[list | create <name> <base> <vision> | delete|enable|disable <name>]',
    name: '/fusion'
  },
  {
    desc: 'Set the vision model the vision_analyze tool asks about images',
    hint: '[<provider>:<model> | on | off]',
    name: '/vision'
  },
  { desc: 'List running and recent dynamic workflows', name: '/workflows' },
  { desc: 'Search / manage the knowledge base', hint: '[status|list|clear|enable|disable]', name: '/knowledge' },
  {
    desc: 'Edit memory files, or manage the bounded memory store',
    hint: '[status|pending|approve <id|all>|reject <id|all>]',
    name: '/memory'
  },
  { desc: 'Browse and inspect available skills', hint: '[list | inspect <name> | search <query>]', name: '/skills' },
  { desc: 'Enable plan mode or view the current session plan', hint: '[<description>]', name: '/plan' },
  {
    desc: 'Set a completion condition Claude keeps working toward',
    hint: '[<condition> | status | clear | pause | resume]',
    name: '/goal'
  },
  { desc: 'Add or manage extra criteria on the active goal', hint: '[<text> | remove <n> | clear]', name: '/subgoal' },
  {
    desc: 'Run a prompt repeatedly on a schedule (Esc while waiting stops a self-paced loop)',
    hint: '[interval] [prompt]',
    name: '/loop'
  },
  { desc: 'Generate session insights', name: '/insights' },
  { desc: 'List or start background agents', name: '/bg' },
  { desc: 'Resume a past session', name: '/resume' },
  { desc: 'Rename this session', hint: '<name>', name: '/rename' },
  { desc: 'Exit dsh-ccTUI', name: '/exit' }
]

type Pending = { reject: (e: Error) => void; resolve: (v: unknown) => void }

/** A workflow slash command reported by the backend (`list_workflow_commands`):
 *  bundled /deep-research plus saved `.clawcodex/workflows/*.py`. */
type WorkflowCommand = { argument_hint?: string; description?: string; name: string }

/** A skill reported by the backend (`list_skills` control). */
type BackendSkill = { category?: string; description?: string; name: string; path?: string }

/** How long a fetched workflow-command list stays fresh. The slash menu
 *  re-queries per keystroke; the TTL keeps that to ~1 RPC per burst while a
 *  workflow authored mid-session (ultracode flow) still shows up promptly. */
const WORKFLOW_CMDS_TTL_MS = 3_000

/** How long a fetched skill list stays fresh. The skills hub inspects per
 *  selection, so a burst of skills.manage RPCs rides one backend disk scan. */
const SKILLS_TTL_MS = 3_000

export class GatewayClient extends EventEmitter {
  private buffered: GatewayEvent[] = []
  private logs: string[] = []
  // The tool-permission request currently awaiting the user's choice.
  private pendingApproval: { input: unknown; request_id: string; suggestions: any[] } | null = null
  // The AskUserQuestion round-trip currently awaiting answers. A SEPARATE slot
  // from pendingApproval on purpose: that one is single-flight and reusing it
  // would let a permission ask and a question dialog clobber each other.
  private pendingQuestions: { questions: any[]; request_id: string } | null = null
  // ch13 round-4 — subagent ids already announced via subagent.start, so a
  // second agent_progress emits subagent.progress (not a duplicate start).
  private seenSubagents = new Set<string>()
  // Tool inputs by tool_use id, so tool_result can render an Edit/Write diff.
  private toolInputs = new Map<string, { input: any; name: string }>()
  // TaskV2 mutates one task at a time, unlike TodoWrite which carries the
  // complete checklist in every call. Keep a session-local projection so the
  // existing checklist HUD can render both protocols.
  private taskTodos = new Map<string, TaskTodo>()
  private msgStarted = false
  private pending = new Map<string, Pending>()
  private pendingExit: null | number | undefined
  private proc: ChildProcess | null = null
  private readyPromise: Promise<void>
  private readyResolve: (() => void) | null = null
  private readyTimer: null | ReturnType<typeof setTimeout> = null
  private reqId = 0
  private sessionId = ''
  private sessionInfo: null | SessionInfo = null
  private subscribed = false
  // Backend skills (skills hub + /skills subcommands), TTL-cached.
  private skills: BackendSkill[] = []
  private skillsFetchedAt = 0
  private skillsTotal = 0
  // Backend workflow commands (slash menu + dispatch), TTL-cached.
  private wfCommands: WorkflowCommand[] = []
  private wfFetchedAt = 0

  constructor() {
    super()
    // The app attaches many 'event' listeners (one per hook); lift the cap.
    this.setMaxListeners(0)
    // Resolves once the backend's system/init has set the session id, so
    // session.create (awaited by the app before it enables the composer) can
    // return a real session_id even if it races the init message.
    this.readyPromise = new Promise<void>(resolve => {
      this.readyResolve = resolve
    })
  }

  // ── lifecycle ────────────────────────────────────────────────────────────
  start(): void {
    const cmd = resolveAgentCmd()
    const cwd = process.env.DSH_CCTUI_WORKSPACE || process.env.DSH_CCTUI_CWD || process.cwd()
    const env = { ...process.env, PYTHONUNBUFFERED: '1' }

    this.readyTimer = setTimeout(() => {
      this.publish({
        payload: { cwd, python: cmd.join(' '), stderr_tail: this.getLogTail(20) },
        type: 'gateway.start_timeout'
      })
    }, STARTUP_TIMEOUT_MS)

    try {
      this.proc = spawn(cmd[0]!, [...cmd.slice(1), '--stdio', '--workspace', cwd], {
        cwd,
        env,
        stdio: ['pipe', 'pipe', 'pipe']
      })
    } catch (err) {
      this.pushLog(`[spawn error] ${String(err)}`)
      this.handleExit(null, String(err))

      return
    }

    const rl = createInterface({ input: this.proc.stdout! })
    rl.on('line', raw => {
      const line = raw.trim()

      if (!line) {return}

      try {
        this.dispatch(JSON.parse(line))
      } catch {
        this.pushLog(`[protocol] malformed stdout: ${line.slice(0, 200)}`)
      }
    })

    const erl = createInterface({ input: this.proc.stderr! })
    erl.on('line', line => {
      this.pushLog(line)
      this.publish({ payload: { line }, type: 'gateway.stderr' })
    })

    this.proc.on('error', err => {
      this.pushLog(`[proc error] ${String(err)}`)
      this.handleExit(null, String(err))
    })
    this.proc.on('exit', code => this.handleExit(code))
  }

  drain(): void {
    this.subscribed = true

    for (const ev of this.buffered) {this.emit('event', ev)}
    this.buffered = []

    if (this.pendingExit !== undefined) {this.emit('exit', this.pendingExit)}
  }

  getLogTail(limit = 20): string {
    return this.logs.slice(-limit).join('\n')
  }

  kill(_reason = 'requested'): void {
    if (this.readyTimer) {
      clearTimeout(this.readyTimer)
      this.readyTimer = null
    }

    try {
      this.proc?.kill('SIGTERM')
    } catch {
      // best effort
    }

    this.proc = null
  }

  publishLocalEvent(ev: GatewayEvent): void {
    this.publish(ev)
  }

  // ── client → server RPCs ─────────────────────────────────────────────────
  request<T = unknown>(method: string, params?: Record<string, unknown>): Promise<T> {
    const p = (params ?? {}) as Record<string, unknown>

    switch (method) {
      // ── startup handshake ────────────────────────────────────────────────
      case 'commands.catalog': {
        // Await the backend so the catalog can include its workflow commands
        // (/deep-research + saved .clawcodex/workflows) alongside the static set.
        return this.readyPromise
          .then(() => this.fetchWorkflowCommands())
          .catch(() => [] as WorkflowCommand[])
          .then(wf => {
            const pairs = SLASHES.map(s => [s.name, s.desc] as [string, string])
            const canon: Record<string, string> = {}
            const hints: Record<string, string> = {}

            for (const s of SLASHES) {
              canon[s.name] = s.name

              if (s.hint) {hints[s.name] = s.hint}
            }

            for (const w of wf) {
              const name = `/${w.name}`

              if (canon[name]) {continue}
              canon[name] = name
              pairs.push([name, w.description ?? 'Run a dynamic workflow'])

              if (w.argument_hint) {hints[name] = w.argument_hint}
            }

            // skill_count is served lazily from the skills cache (warmed by any
            // /skills use) so the startup catalog doesn't pay a full disk scan.
            return { canon, categories: [], hints, pairs, skill_count: this.skillsTotal, sub: {} } as T
          })
      }

      case 'complete.slash': {
        const text = String(p.text ?? '').toLowerCase() || '/'

        return this.fetchWorkflowCommands()
          .catch(() => [] as WorkflowCommand[])
          .then(wf => {
            const entries = [
              ...SLASHES,
              ...wf
                .filter(w => !SLASHES.some(s => s.name === `/${w.name}`))
                .map(w => ({
                  desc: w.description ?? 'Run a dynamic workflow',
                  hint: w.argument_hint,
                  name: `/${w.name}`
                }))
            ]

            const items = entries
              .filter(s => s.name.toLowerCase().startsWith(text))
              .map(s => ({ display: s.name, hint: s.hint, meta: s.desc, text: s.name }))

            return { items, replace_from: 1 } as T
          })
      }

      case 'complete.path':
        // @-file mentions: serve workspace file completions from disk (the hook
        // computes the replace offset; we just return matching entries).
        return Promise.resolve({ items: this.completePath(String(p.word ?? '')) } as T)
      case 'config.get': {
        // Settings slashes read config; only 'full' maps to clawcodex settings.
        if (String(p.key ?? '') === 'full') {
          return this.controlQuery('get_settings', {}).then(s => (s ?? {}) as T)
        }

        if (String(p.key ?? '') === 'recap') {
          // /recap status — served off the get_settings rider.
          return this.controlQuery('get_settings', {}).then(s => {
            const enabled = (s as { recap?: boolean } | null)?.recap !== false

            return { value: enabled ? 'on' : 'off' } as T
          })
        }

        return Promise.resolve({} as T)
      }

      case 'config.set': {
        // Route clawcodex-backed settings to control_requests; display-only prefs
        // (mouse/details/statusbar/skin/…) have no backend and apply locally, so
        // accept them silently.
        const key = String(p.key ?? '')
        const value = p.value

        if (key === 'permission_mode') {
          // The server can reject this (bypassPermissions is gated on
          // selectability); reflect its FULL verdict — `/permissions` needs the
          // applied mode and the rejection text, not just a boolean, so a
          // refused set can neither flip the badge nor report success.
          return this.controlQuery('set_permission_mode', { mode: value, persist: Boolean(p.persist) })
            .then(r => {
              const res = (r ?? {}) as { error?: string; mode?: string; ok?: boolean; persisted?: boolean }

              return {
                error: res.error,
                mode: res.mode,
                ok: res.ok !== false,
                persisted: res.persisted
              } as T
            })
        }

        if (key === 'model') {return this.setModel(String(value ?? '')) as Promise<T>}

        if (key === 'logoColor') {
          return this.controlQuery('set_logo_color', { name: value }).then(r => {
            const ok = (r as any)?.ok === true

            return (ok ? { ok: true, value: String(value ?? '') } : { ok: false }) as T
          })
        }

        if (key === 'recap') {
          // Round-trip so /recap reports the EFFECTIVE post-write state (a
          // project/local settings override can beat the global write).
          return this.controlQuery('set_recap', { value }).then(r => {
            const res = (r ?? {}) as { error?: string; note?: string; ok?: boolean; value?: string }

            return { error: res.error, note: res.note, ok: res.ok !== false, value: res.value } as T
          })
        }

        if (key === 'effort' || key === 'reasoning') {this.sendControl('set_effort', { effort: value })}
        else if (key === 'provider') {this.sendControl('set_provider', { provider: value })}
        else if (key === 'thinking') {this.sendControl('set_thinking', { action: value })}

        return Promise.resolve({ ok: true } as T)
      }

      case 'permission.cycle':
        // ch13 round-4 — shift+tab: the SERVER computes the guarded next
        // mode (get_next_permission_mode; bypass only when available) from
        // the live mode, so the client can't step into bypassPermissions
        // unconditionally or desync a cursor after /mode.
        return this.controlQuery('cycle_permission_mode', {}).then(r => (r ?? {}) as T)

      case 'session.activate':

      case 'session.create':

      case 'session.resume':
        // clawcodex runs a single agent-server session; hand back its id once
        // system/init has set it. The app then enables the composer.
        return this.readyPromise.then(() => ({ info: this.sessionInfo ?? undefined, session_id: this.sessionId }) as T)

      case 'session.clear':
        // /clear's server half: reset the backend conversation (and its turn
        // odometer) so a "cleared" transcript isn't silently re-fed the old
        // context next prompt. The reply's stats rider refreshes the line.
        return this.controlQuery('clear', {}).then(r => {
          this.publishSessionStats(r)

          return { ok: (r as any)?.ok !== false } as T
        })

      case 'setup.status':
        return Promise.resolve({ provider_configured: true } as T)

      // ── runtime ──────────────────────────────────────────────────────────
      // The picker's step 1 needs EVERY provider clawcodex knows about, which
      // only `list_model_providers` reports. `get_settings` describes just the
      // active one, so synthesizing the list from it (as this used to) could
      // never show more than a single row.
      case 'model.options':
        return this.controlQuery('list_model_providers', {}).then((r: any) => {
          const providers = Array.isArray(r?.providers) ? r.providers : []

          if (providers.length) {
            return {
              // On a fused session the backend reports `model` as the base id;
              // the picker's "current" marker must point at the fusion entry
              // the user actually selected, not at the base model row.
              model: typeof r?.fusion === 'string' && r.fusion ? r.fusion : r?.model,
              provider: r?.provider,
              providers
            } as T
          }

          // An explicit refusal is real information — most importantly the
          // `init_error` short-circuit, which fires exactly when no provider
          // is configured. Papering over it with the get_settings synthesis
          // would invent a single row named `clawcodex` (that being the
          // `?? 'clawcodex'` default when the errored reply carries no
          // provider) and reproduce the original one-row symptom. Surface it.
          if (r != null) {
            throw new Error(
              typeof r.error === 'string' && r.error ? r.error : 'could not list providers'
            )
          }

          // Only a null reply reaches here: a backend too old to know the
          // control, or an RPC timeout. Fall back to the single active
          // provider so /model still switches models.
          return this.controlQuery('get_settings', {}).then((s: any) => {
            const models: string[] = Array.isArray(s?.available_models) ? s.available_models : []
            const provider = String(s?.provider ?? 'clawcodex')

            return {
              // Same fusion rule as the catalog path above.
              model: typeof s?.fusion === 'string' && s.fusion ? s.fusion : s?.model,
              provider,
              providers: [
                {
                  authenticated: true,
                  is_current: true,
                  models,
                  name: provider,
                  slug: provider,
                  total_models: models.length
                }
              ]
            } as T
          })
        })

      case 'model.effort_options':
        return this.controlQuery('effort_options', {
          model: String(p.model ?? ''),
          provider: String(p.provider ?? '')
        }).then((r: any) => {
          // A backend too old to know the control answers null, and an
          // errored one answers {ok:false}. Neither is worth failing the
          // switch over — the model is already chosen by this point, so fall
          // back to "no ladder" and let the picker apply what it has.
          if (r == null || r.ok === false) {
            return { levels: [], supported: false } as T
          }

          return {
            current: typeof r.current === 'string' ? r.current : '',
            levels: Array.isArray(r.levels) ? r.levels.filter((l: unknown) => typeof l === 'string') : [],
            supported: r.supported === true
          } as T
        })

      case 'model.save_key':
        return this.controlQuery('save_provider_key', {
          api_key: String(p.api_key ?? ''),
          slug: String(p.slug ?? '')
        }).then((r: any) => {
          if (r == null) {throw new Error('save key: no response from backend')}

          if (r.ok === false) {throw new Error(typeof r.error === 'string' && r.error ? r.error : 'failed to save key')}

          return { provider: r.provider } as T
        })

      case 'model.disconnect':
        return this.controlQuery('disconnect_provider', { slug: String(p.slug ?? '') }).then((r: any) => {
          if (r == null) {throw new Error('disconnect: no response from backend')}

          // A refusal (the active provider) and a partial disconnect (a key
          // still exported in the shell) both carry `error`; surface either
          // rather than silently returning to the list as if it worked.
          if (r.ok === false || (r.disconnected !== true && r.error)) {
            throw new Error(typeof r.error === 'string' && r.error ? r.error : 'disconnect failed')
          }

          return { disconnected: r.disconnected === true } as T
        })
      case 'prompt.submit': {
        const text = String(p.text ?? '')
        this.msgStarted = false
        this.send({ message: { content: text, role: 'user' }, type: 'user' })

        return Promise.resolve({ ok: true } as T)
      }

      case 'session.active_list':

      case 'session.list':
        // Single agent-server session in the basic port; the switcher/resume
        // list is Phase 2. Resolve locally so the 1.5s poll doesn't spam the
        // backend with list_sessions.
        return Promise.resolve({ sessions: [] } as T)

      case 'session.interrupt':
        this.sendControl('interrupt', {})

        return Promise.resolve({ ok: true } as T)

      // ── --worktree exit flow (long deadline: removal can take minutes) ───
      case 'worktree.exit':
        return this.controlQuery(
          'worktree_exit',
          { action: String(p.action ?? '') },
          WORKTREE_RPC_TIMEOUT_MS
        ).then(r => (r ?? { error: 'no response from backend', ok: false }) as T)

      case 'worktree.status':
        return this.controlQuery('worktree_status', {}, WORKTREE_RPC_TIMEOUT_MS).then(
          r => (r ?? { error: 'no response from backend', ok: false }) as T
        )
      // ── skills hub + /skills subcommands ─────────────────────────────────
      case 'skills.manage': {
        const action = String(p.action ?? 'list')
        const query = String(p.query ?? '').trim().toLowerCase()

        // Community install/browse are Nous-portal features with no clawcodex
        // backend; reject so the hub/command surfaces a real error, not a fake
        // success.
        if (action === 'install' || action === 'browse') {
          return Promise.reject(
            new Error(`/skills ${action}: not supported here — the harness owns skills (ctx.skills)`)
          )
        }

        return this.fetchSkills().then(skills => {
          if (action === 'inspect') {
            const found = skills.find(s => s.name.toLowerCase() === query)

            return (
              found
                ? { info: { category: found.category, description: found.description, name: found.name, path: found.path } }
                : {}
            ) as T
          }

          if (action === 'search') {
            const results = skills
              .filter(s => s.name.toLowerCase().includes(query) || (s.description ?? '').toLowerCase().includes(query))
              .slice(0, 30)
              .map(s => ({ description: s.description, name: s.name }))

            return { results } as T
          }

          // 'list' (default): group by category for the hub / /skills panel.
          const byCat: Record<string, string[]> = {}

          for (const s of skills) {
            ;(byCat[s.category || 'other'] ??= []).push(s.name)
          }

          for (const names of Object.values(byCat)) {
            names.sort()
          }

          return { skills: byCat, total: this.skillsTotal } as T
        })
      }

      case 'skills.reload':
        // get_all_skills re-scans disk on every call; "reload" just busts the
        // client TTL cache and fetches fresh.
        this.skillsFetchedAt = 0

        return this.fetchSkills().then(
          skills => ({ output: `Re-scanned skills: ${this.skillsTotal || skills.length} available.` }) as T
        )

      // ── /memory picker (backend enumerates; the TUI owns the editor) ─────
      case 'memory.targets':
        return this.controlQuery('memory_targets', {}).then(
          r => (r ?? { error: 'no response from backend', ok: false, targets: [] }) as T
        )

      case 'memory.edited':
        // Post-$EDITOR cache bust so the next turn re-reads memory files.
        return this.controlQuery('memory_edited', {}).then(r => (r ?? { ok: false }) as T)

      // ── slash commands → clawcodex control_requests ──────────────────────
      case 'command.dispatch':
        return this.dispatchSlash(String(p.name ?? ''), p.arg == null ? undefined : String(p.arg)) as Promise<T>
      case 'slash.exec': {
        const raw = String(p.command ?? '').trim()
        const sp = raw.indexOf(' ')
        const name = sp === -1 ? raw : raw.slice(0, sp)
        const arg = sp === -1 ? undefined : raw.slice(sp + 1)

        return this.dispatchSlash(name, arg) as Promise<T>
      }

      // ── tool permission / elicitation responses ──────────────────────────
      case 'approval.respond': {
        const ap = this.pendingApproval
        this.pendingApproval = null

        if (ap) {
          const deny = p.choice === 'deny'
          // 'always' = "don't ask again": send the backend's suggestion AS-IS so
          // its intended SCOPE is preserved — Bash's is a localSettings rule
          // (survives sessions); a file-edit's is a session-scoped acceptEdits
          // setMode; a read's is a content-less allow. The ONLY mutation is the
          // user's optional edit of a Bash rule (git status:* → git:*), which
          // rewrites just that rule's content and nothing else. 'once' → no rule.
          let chosenUpdates: any[] = []
          const first = ap.suggestions?.[0]

          if (!deny && first && p.choice === 'always') {
            const edited = typeof p.rule === 'string' ? p.rule.trim() : ''
            const baseRule = Array.isArray(first.rules) ? first.rules[0] : undefined
            chosenUpdates = [
              edited && baseRule?.rule_content
                ? { ...first, rules: [{ ...baseRule, rule_content: edited }, ...first.rules.slice(1)] }
                : first
            ]
          }

          this.send({
            response: {
              request_id: ap.request_id,
              response: deny
                ? { behavior: 'deny', message: 'Denied by user' }
                : { behavior: 'allow', updatedInput: ap.input, chosen_updates: chosenUpdates }
            },
            type: 'control_response'
          })
        }

        return Promise.resolve({ ok: true } as T)
      }

      case 'planApproval.respond': {
        // Plan-approval dialog reply (ExitPlanModePermissionRequest analog):
        //   choice 'accept-edits'  → allow + setMode acceptEdits (session)
        //   choice 'bypass'        → allow + setMode bypassPermissions (session)
        //   choice 'default'       → allow + setMode default (session)
        //   choice 'deny'          → deny; `feedback` (may be '') becomes the
        //     rejection reason the model reads ("No, keep planning").
        // The setMode updates are client-built exactly like the original
        // dialog's buildPermissionUpdates — the backend applies them via the
        // same chosen_updates path as "don't ask again" rules.
        const ap = this.pendingApproval
        this.pendingApproval = null

        if (ap) {
          const choice = String(p.choice ?? 'deny')

          const modeByChoice: Record<string, string> = {
            'accept-edits': 'acceptEdits',
            bypass: 'bypassPermissions',
            default: 'default'
          }

          const mode = modeByChoice[choice]

          this.send({
            response: {
              request_id: ap.request_id,
              response: mode
                ? {
                    behavior: 'allow',
                    chosen_updates: [{ destination: 'session', mode, type: 'setMode' }],
                    updatedInput: ap.input
                  }
                : { behavior: 'deny', message: typeof p.feedback === 'string' ? p.feedback : '' }
            },
            type: 'control_response'
          })
        }

        return Promise.resolve({ ok: true } as T)
      }

      case 'question.respond': {
        // AskUserQuestion dialog reply. `answers` is a question-text → answer
        // map (multi-select answers already joined by the dialog); a null/
        // absent `answers` means the user dismissed the dialog, which the
        // backend maps to a decline rather than an empty submit.
        const pq = this.pendingQuestions
        this.pendingQuestions = null

        if (!pq) {
          // No live slot: the round trip already ended (timed out server-side,
          // or a second reply raced the first). Reporting ok here made the app
          // stamp "questions answered" on a turn whose answers went nowhere.
          return Promise.resolve({ ok: false } as T)
        }

        const answers = p.answers && typeof p.answers === 'object' ? p.answers : null

        this.send({
          response: {
            request_id: pq.request_id,
            response: answers ? { action: 'submit', answers } : { action: 'cancel' }
          },
          type: 'control_response'
        })

        return Promise.resolve({ ok: true } as T)
      }

      case 'clarify.respond':
        this.send({
          response: {
            request_id: String(p.request_id ?? ''),
            response: { action: 'accept', content: { answer: p.answer } }
          },
          type: 'control_response'
        })

        return Promise.resolve({ ok: true } as T)

      // ── image attachment ─────────────────────────────────────────────────
      // The composer and /image have called these since the port; without a
      // case here they hit the `default` below and resolved `{}`, so every
      // image paste silently degraded to pasting the path as literal text.
      //
      // The backend queues the decoded image and attaches it to the next user
      // message, so these responses carry metadata only, never base64 — the
      // client has nothing to hold and nothing to re-send.
      case 'image.attach':
        // Longer deadline than a normal RPC: reading + downsampling a large
        // screenshot is Pillow work, and osascript alone is ~1.5s.
        //
        // `placeholder` must come from the CALLER, not be hardcoded here:
        // whether an `[Image #N]` chip gets rendered is a property of the call
        // site, not of the RPC. Six sites reach these four RPCs and only three
        // insert a chip — hardcoding `true` made the backend drop the images of
        // the other three (`/image`, the startup image, and typed-path submit)
        // at submit time, after their UI had already confirmed success.
        // Default false is fail-open: an unmarked caller keeps its image.
        return this.controlQuery(
          'attach_image',
          { path: String(p.path ?? ''), placeholder: p.placeholder === true },
          IMAGE_RPC_TIMEOUT_MS
        ).then(r => (r ?? {}) as T)

      case 'image.clipboard':
        return this.controlQuery(
          'clipboard_image',
          { placeholder: p.placeholder === true },
          IMAGE_RPC_TIMEOUT_MS
        ).then(r => (r ?? {}) as T)

      // The macOS Cmd+V route, and the one users actually reach first. Apple
      // Terminal and iTerm handle Cmd+V themselves and deliver the clipboard as
      // a BRACKETED PASTE, so the app never sees a Cmd+V keypress — and with an
      // image on the clipboard there is no text, so what arrives is an EMPTY
      // bracketed paste. That lands in handleResolvedPaste's empty branch, which
      // calls onClipboardPaste → this RPC. Unwired, it resolved `{}` and Cmd+V
      // did nothing at all, silently (the call passes quiet=true).
      case 'clipboard.paste':
        return this.controlQuery(
          'clipboard_image',
          { placeholder: p.placeholder === true },
          IMAGE_RPC_TIMEOUT_MS
        ).then(r => {
          const res = (r ?? {}) as {
            attached?: boolean
            error?: string
            message?: string
            unavailable?: boolean
          }

          // Only synthesize for a genuinely empty clipboard. Adding it to an
          // error/unavailable reply would have it claim "no image found"
          // alongside a real failure.
          if (res.attached || res.error || res.unavailable) {
            return res as T
          }

          return { ...res, message: 'No image found in clipboard' } as T
        })

      case 'input.detect_drop':
        return this.controlQuery(
          'detect_file_drop',
          { text: String(p.text ?? ''), placeholder: p.placeholder === true },
          IMAGE_RPC_TIMEOUT_MS
        ).then(r => (r ?? {}) as T)

      default:
        // Unhandled RPC (Phase 2): resolve empty so the app degrades gracefully.
        return Promise.resolve({} as T)
    }
  }

  // Fetch the backend's workflow slash commands, TTL-cached (see
  // WORKFLOW_CMDS_TTL_MS). Degrades to the last-known list on RPC failure.
  private fetchWorkflowCommands(): Promise<WorkflowCommand[]> {
    const now = Date.now()

    if (now - this.wfFetchedAt < WORKFLOW_CMDS_TTL_MS) {return Promise.resolve(this.wfCommands)}
    this.wfFetchedAt = now

    return this.controlQuery('list_workflow_commands', {}).then((r: any) => {
      if (Array.isArray(r?.commands)) {
        this.wfCommands = r.commands.filter((c: any) => typeof c?.name === 'string' && c.name)
      }

      return this.wfCommands
    })
  }

  // Fetch the backend's unified skill set (`list_skills` control), TTL-cached
  // (see SKILLS_TTL_MS). Degrades to the last-known list on RPC failure.
  private fetchSkills(): Promise<BackendSkill[]> {
    const now = Date.now()

    if (now - this.skillsFetchedAt < SKILLS_TTL_MS) {return Promise.resolve(this.skills)}
    this.skillsFetchedAt = now

    return this.controlQuery('list_skills', {}).then((r: any) => {
      if (Array.isArray(r?.skills)) {
        this.skills = r.skills.filter((s: any) => typeof s?.name === 'string' && s.name)
        this.skillsTotal = Number(r.total) || this.skills.length
      }

      return this.skills
    })
  }

  // config.set{model} carries the hermes /model grammar —
  // "<model> [--provider <slug>] [--global|--tui-session]" — verbatim from the
  // picker/slash layer; parsing it is the gateway's job. The callers require a
  // ConfigSetResponse `value` on success (its absence is what "error: invalid
  // response: model switch" reports), so this must round-trip the control
  // rather than fire-and-forget. Scope flags are dropped: the backend persists
  // every switch (agent_server set_model → app-state on_change).
  private setModel(raw: string): Promise<{ provider?: string; value: string; warning?: string }> {
    const tokens = raw.trim().split(/\s+/).filter(Boolean)
    const modelParts: string[] = []
    let provider: string | undefined

    for (let i = 0; i < tokens.length; i++) {
      const tok = tokens[i]!

      if (tok === '--provider') {
        provider = tokens[++i]

        continue
      }

      if (tok === '--global' || tok === '--tui-session') {
        continue
      }

      modelParts.push(tok)
    }

    const model = modelParts.join(' ')

    return this.applyModel(model, provider)
  }

  // `set_model` deliberately refuses to point the live provider at another
  // provider's model id — a cross-provider switch needs the registry rebuild
  // only `set_provider` performs. The /model picker selects exactly that way
  // (step 1 a provider, step 2 one of its models), so on the backend's
  // `provider_mismatch` signal we do the switch first and re-apply the model.
  // `allowSwitch` guards the retry against recursing.
  private applyModel(
    model: string,
    provider: string | undefined,
    allowSwitch = true
  ): Promise<{ provider?: string; value: string; warning?: string }> {
    return this.controlQuery('set_model', { model, ...(provider ? { provider } : {}) }).then((r: any) => {
      if (r == null) {
        // Tagged: a silent backend may still have APPLIED the model, so the
        // cross-provider retry below must not "roll back" over it.
        throw Object.assign(new Error('model switch: no response from backend'), {
          indeterminate: true
        })
      }

      if (r.ok === false) {
        if (r.provider_mismatch === true && provider && allowSwitch) {
          return this.controlQuery('set_provider', { provider }).then((sr: any) => {
            if (sr == null) {
              throw new Error('provider switch: no response from backend')
            }

            if (sr.ok === false) {
              throw new Error(
                typeof sr.error === 'string' && sr.error ? sr.error : `could not switch to provider '${provider}'`
              )
            }

            // The switch has already COMMITTED backend-side: set_provider
            // rebuilt the registry, reset the model to the new provider's
            // default and persisted the pairing. If selecting the requested
            // model now fails, "model switch failed" would read as "nothing
            // happened" while the session quietly sits on a different
            // provider AND a different model. Roll back to where we came
            // from (the mismatch reply names it) and say what actually stuck.
            return this.applyModel(model, provider, false)
              // The retry lands on the NEW provider, so its reply names it.
              // Fall back to the one we just switched to for older backends
              // that echo no provider: set_provider returning ok is proof of
              // where the session now is, and this is the path that MOVES it.
              .then(res => ({ ...res, provider: res.provider ?? provider }))
              .catch((e: unknown) => {
                const why = e instanceof Error ? e.message : String(e)
                const previous = typeof r.provider === 'string' ? r.provider : ''

                // A silent backend is NOT a known failure — it may have applied
                // the model. Rolling back would then throw away a switch that
                // worked, so report the uncertainty instead of acting on it.
                if ((e as { indeterminate?: boolean })?.indeterminate) {
                  throw new Error(
                    `switched to '${provider}' but the model selection got no response — ` +
                      `the session may be on '${provider}'`
                  )
                }

                if (!previous) {
                  throw new Error(`switched to '${provider}' but could not select '${model}': ${why}`)
                }

                return this.controlQuery('set_provider', { provider: previous }).then((back: any) => {
                  throw new Error(
                    back != null && back.ok !== false
                      ? // set_provider resets the model to that provider's
                        // configured default and persists it, so the provider is
                        // restored but the previously-selected model is not.
                        `could not select '${model}' on '${provider}': ${why} — rolled back to ` +
                          `'${previous}' (its default model)`
                      : `could not select '${model}': ${why} — session is now on '${provider}'`
                  )
                })
              })
          })
        }

        throw new Error(typeof r.error === 'string' && r.error ? r.error : 'model switch failed')
      }

      // Older backends ack {ok:true} without echoing the model — or, for
      // `provider`, without echoing it at all. Omit the key in that case so
      // callers can tell "unchanged/unknown" (keep the current label) from a
      // real move, rather than blanking a provider that is still correct.
      return {
        value: typeof r.model === 'string' && r.model ? r.model : model,
        ...(typeof r.provider === 'string' && r.provider ? { provider: r.provider } : {}),
        ...(typeof r.warning === 'string' && r.warning ? { warning: r.warning } : {})
      }
    })
  }

  // ── event plumbing ───────────────────────────────────────────────────────
  private controlQuery(
    subtype: string,
    params: Record<string, unknown>,
    timeoutMs: number = RPC_TIMEOUT_MS
  ): Promise<unknown> {
    const requestId = `q${++this.reqId}`

    return new Promise(resolve => {
      this.pending.set(requestId, { reject: () => resolve(null), resolve })
      this.send({ request: { subtype, ...params }, request_id: requestId, type: 'control_request' })
      setTimeout(() => {
        if (this.pending.has(requestId)) {
          this.pending.delete(requestId)
          resolve(null)
        }
      }, timeoutMs)
    })
  }

  // Map a slash command (name + optional arg) to a clawcodex control_request
  // and return a CommandDispatchResponse — `type:'exec'` + human-readable output
  // the app prints, or `type:'send'` for workflow commands whose expanded
  // directive the app submits as a prompt. Unknown commands are offered to the
  // backend as workflow commands (/deep-research, saved .clawcodex/workflows)
  // before reporting they aren't wired.
  private async dispatchSlash(
    name: string,
    arg?: string
  ): Promise<
    | { output: string; type: string }
    | { message: string; notice?: string; type: 'send' }
    | { message?: string; name: string; type: 'skill' }
  > {
    const out = (output: string) => ({ output, type: 'exec' })

    // Skill slash commands (/loop today; any user-invocable skill via the
    // default fallback below): the backend expands the skill body through
    // the same path the model-side Skill tool uses, and the app submits it
    // as a user turn (createSlashHandler's {type:'skill'} consumer).
    const trySkill = async (skillName: string) => {
      const r = (await this.controlQuery('skill_command', { args: arg ?? '', name: skillName })) as any

      if (r?.ok && typeof r.prompt === 'string' && r.prompt) {
        return { message: r.prompt as string, name: skillName, type: 'skill' as const }
      }

      return null
    }

    switch (name) {
      case 'loop': {
        const skill = await trySkill('loop')

        return skill ?? out('loop: backend not ready')
      }

      case 'advisor': {
        const r = (await this.controlQuery('advisor', { arg: arg ?? '' })) as any

        if (!r || Object.keys(r).length === 0) {return out('advisor: backend not ready')}

        return out(String(r.text ?? r.error ?? 'advisor: no response'))
      }
      case 'fusion': {
        // Manage fusion models (a text-only base model + a borrowed vision
        // model). The backend owns the whole grammar — list / create /
        // delete / enable / disable — so this only relays the arg and
        // prints the reply, exactly like /advisor above.
        const r = (await this.controlQuery('fusion', { arg: arg ?? '' })) as any

        if (!r || Object.keys(r).length === 0) {return out('fusion: backend not ready')}

        return out(String(r.text ?? r.error ?? 'fusion: no response'))
      }
      case 'vision': {
        // Configure the vision model behind the vision_analyze tool. The
        // backend owns the grammar (<provider>:<model> | on | off), so this
        // relays the arg and prints the reply, exactly like /fusion above.
        const r = (await this.controlQuery('vision', { arg: arg ?? '' })) as any

        if (!r || Object.keys(r).length === 0) {return out('vision: backend not ready')}

        return out(String(r.text ?? r.error ?? 'vision: no response'))
      }
      case 'memory': {
        // Arg-ful /memory (status | pending | approve | reject) — the
        // bounded-store management surface. The no-arg picker never routes
        // here (ops.ts opens the overlay directly).
        const r = (await this.controlQuery('memory_manage', { arg: arg ?? '' })) as any

        if (!r || Object.keys(r).length === 0) {return out('memory: backend not ready')}

        return out(String(r.text ?? r.error ?? 'memory: no response'))
      }

      case 'clear': {
        const r = (await this.controlQuery('clear', {})) as any

        // The clear control is idle-only — a rejected /clear (active turn)
        // must NOT hide the goal indicator or claim success (critic R1).
        if (!r || r.ok === false) {
          return out(`clear: ${r?.error ?? 'backend not ready'}`)
        }

        this.publishSessionStats(r)

        // Backend /clear also removes any active goal (CC docs/en/goal
        // §Clear a goal). New backends say so via the reply's goal rider;
        // a legacy success reply without the field falls back to an
        // explicit hide — the goal IS gone backend-side either way.
        if ('goal' in r) {
          this.publishGoalState(r)
        } else {
          this.publish({ payload: { goal: null }, type: 'goal.state' })
        }

        return out('Conversation cleared.')
      }

      case 'compact': {
        const r = (await this.controlQuery('compact', { instructions: arg ?? null })) as any

        return out(`Compacted${r?.tokens_saved ? ` (saved ~${r.tokens_saved} tokens)` : ''}.`)
      }

      case 'context': {
        const r = (await this.controlQuery('get_context_usage', {})) as any
        const pct = r?.percentage == null ? '?' : Math.round(r.percentage)

        return out(`Context: ${r?.total_tokens ?? '?'}/${r?.max_tokens ?? '?'} tokens (${pct}%).`)
      }

      case 'cost': {
        // The original /cost prints formatTotalCost over live cost-tracker
        // state (commands/cost/cost.ts:23); clawcodex's accounting lives in
        // the backend bootstrap singleton, so pull a fresh snapshot.
        const r = (await this.controlQuery('cost', {})) as CostSnapshot | null

        if (!r || Object.keys(r).length === 0) {
          return out('Cost totals unavailable (backend not ready).')
        }

        setLastCostSnapshot(r)

        return out(formatTotalCost(r))
      }

      case 'eco': {
        const r = (await this.controlQuery('eco', { arg: arg ?? '' })) as any

        if (!r || Object.keys(r).length === 0) {return out('eco: backend not ready')}

        if (r.ok === false) {return out(`eco: ${r.error ?? 'failed'}`)}

        return out(String(r.text ?? `Eco mode ${r.enabled ? 'on' : 'off'}.`))
      }

      case 'effort': {
        const r = (await this.controlQuery('set_effort', { effort: arg ?? null })) as any

        if (r && r.ok === false) {return out(`effort: ${r.error ?? 'invalid value'}`)}

        if (r?.effort === 'ultracode') {
          return out('Ultracode on: workflow auto-orchestration for this session (reset with /effort high).')
        }

        // Keep the model-line badge in step with the new level (the backend
        // only sends reasoning_effort on the init frame).
        if (this.sessionInfo && typeof r?.effort === 'string') {
          this.sessionInfo.reasoning_effort = r.effort === 'default' ? undefined : r.effort
          this.publish({ payload: this.sessionInfo, session_id: this.sessionId, type: 'session.info' })
        }

        // `note` carries a caveat the level alone doesn't convey — today:
        // extended thinking is off, which discards effort entirely.
        const note = typeof r?.note === 'string' && r.note ? ` ${r.note}` : ''

        return out(`Effort: ${r?.effort ?? arg ?? '(unchanged)'}.${note}`)
      }

      // `/permissions` (formerly `/mode`) is a LOCAL slash command
      // (app/slash/commands/session.ts) — createSlashHandler resolves the local
      // registry first and returns, so a gateway case here would be unreachable.
      // The RPC it uses is `config.set{key:'permission_mode'}` above.

      case 'model': {
        const r = (await this.controlQuery('set_model', { model: arg })) as any

        // DEFENCE-IN-DEPTH, not the reachable path: like /permissions above,
        // `/model` is a TUI-local command (app/slash/commands/session.ts) and
        // createSlashHandler resolves the local registry first, so the live
        // route is config.set → setModel — which already throws on
        // `ok === false` and already patches the badge from `r.value`. This
        // case only runs if that local command is ever removed. Kept correct
        // anyway because set_model can now decline for several actionable
        // reasons (a disabled fusion model, missing credentials for a fusion
        // half, an active turn), each carrying the fix in its message.
        if (r?.ok === false) {
          return out(String(r.error ?? 'model switch failed'))
        }

        const applied = typeof r?.model === 'string' && r.model ? r.model : (arg ?? '(unchanged)')

        return out(`Model set to ${applied}.${r?.warning ? ` ${r.warning}` : ''}`)
      }
      case 'output-style': {
        if (arg) {
          const r = (await this.controlQuery('set_output_style', { style: arg })) as any

          if (r?.ok === false) {
            const avail = Array.isArray(r?.available_styles) ? ` Available: ${r.available_styles.join(', ')}.` : ''

            return out(`${r?.error ?? 'Failed to set output style.'}${avail}`)
          }

          return out(`Output style: ${r?.style ?? arg}.`)
        }

        const st = (await this.controlQuery('get_settings', {})) as any
        const avail = Array.isArray(st?.available_output_styles) ? st.available_output_styles : []
        const current = st?.output_style ?? 'default'

        return out(
          avail.length
            ? `Output style: ${current}. Available: ${avail.map((n: string) => (n === current ? `${n} (current)` : n)).join(', ')}.`
            : `Output style: ${current}.`
        )
      }

      case 'provider': {
        const r = (await this.controlQuery('set_provider', { provider: arg })) as any

        return out(`Provider: ${r?.provider ?? arg ?? '(unchanged)'}${r?.model ? ` (model ${r.model})` : ''}.`)
      }

      case 'rewind': {
        const r = (await this.controlQuery('rewind', { turns: arg ? Number(arg) || 1 : 1 })) as any

        return out(`Rewound ${r?.removed ?? 0} turn(s).`)
      }

      case 'thinking': {
        const r = (await this.controlQuery('set_thinking', { action: arg ?? 'toggle' })) as any
        // `note` warns when turning thinking off discards an effort level
        // the user already set (effort rides inside the thinking block).
        const note = typeof r?.note === 'string' && r.note ? ` ${r.note}` : ''

        return out(`Thinking ${r?.thinking ? 'on' : 'off'}.${note}`)
      }

      case 'bg': {
        if (arg) {
          const r = (await this.controlQuery('bg_agent', { command: arg })) as any

          return out(`Started background agent ${r?.id ?? ''}.`)
        }

        const r = (await this.controlQuery('bg_list', {})) as any
        const tasks = Array.isArray(r?.tasks) ? r.tasks : []

        return out(tasks.length ? tasks.map((t: any) => `${t.id} [${t.status}] ${t.command}`).join('\n') : 'No background tasks.')
      }

      case 'insights': {
        const r = (await this.controlQuery('insights', {})) as any

        return out(r?.insights ? String(r.insights) : 'No insights available.')
      }

      case 'knowledge': {
        const r = (await this.controlQuery('knowledge', { action: arg || 'status' })) as any

        const bits = [
          r?.enabled != null ? `enabled=${r.enabled}` : '',
          r?.semantic != null ? `semantic=${r.semantic}` : ''
        ].filter(Boolean)

        return out(`Knowledge ${bits.join(' ') || safeJson(r ?? {})}`)
      }

      case 'plan': {
        // CC /plan semantics (commands/plan/plan.tsx): not in plan mode →
        // enable it (with an argument, the argument is submitted as the
        // prompt); already in plan mode → show the current plan file.
        const status = (await this.controlQuery('plan', { action: 'status' })) as any

        if (status?.mode !== 'plan') {
          const r = (await this.controlQuery('set_permission_mode', { mode: 'plan' })) as any

          if (r && r.ok === false) {
            return out(String(r.error ?? 'failed to enable plan mode'))
          }

          this.publish({ payload: { mode: 'plan' }, type: 'permission.mode' })

          const description = (arg ?? '').trim()

          if (description && description !== 'open') {
            // TS onDone('Enabled plan mode', {shouldQuery:true}) — a
            // {type:'send'} dispatch renders the notice and submits the
            // description as the prompt (same contract as /goal kickoff).
            return { message: description, notice: 'Enabled plan mode', type: 'send' }
          }

          return out('Enabled plan mode')
        }

        if (!status?.plan) {
          return out('Already in plan mode. No plan written yet.')
        }

        const pathLine = status.plan_file_path ? `${status.plan_file_path}\n\n` : ''

        return out(`Current Plan\n${pathLine}${status.plan}`)
      }

      case 'goal': {
        // Hermes /goal contract: SET replies carry a kickoff — the app
        // renders the notice as a system line and submits the condition as
        // the first goal turn ({type:'send'} in createSlashHandler). Every
        // other subcommand (status/clear/pause/resume) is plain exec text.
        const r = (await this.controlQuery('goal', { arg: arg ?? '' })) as any

        if (!r || Object.keys(r).length === 0) {return out('goal: backend not ready')}

        this.publishGoalState(r)

        if (r.ok && typeof r.kickoff === 'string' && r.kickoff) {
          return { message: r.kickoff, notice: typeof r.notice === 'string' ? r.notice : undefined, type: 'send' }
        }

        return out(String(r.text ?? r.error ?? 'goal: no response'))
      }

      case 'subgoal': {
        const r = (await this.controlQuery('subgoal', { arg: arg ?? '' })) as any

        if (!r || Object.keys(r).length === 0) {return out('subgoal: backend not ready')}

        this.publishGoalState(r)

        return out(String(r.text ?? r.error ?? 'subgoal: no response'))
      }

      case 'rename': {
        const r = (await this.controlQuery('rename', { name: arg })) as any

        return out(`Renamed to ${r?.name ?? arg ?? '(unchanged)'}.`)
      }

      case 'resume': {
        if (arg) {
          const r = (await this.controlQuery('resume', { session_id: arg })) as any
          this.publishSessionStats(r)

          // mode_banner: coordinator-mode flip notice (matchSessionMode) —
          // e.g. "Entered coordinator mode to match resumed session."
          const banner = typeof r?.mode_banner === 'string' && r.mode_banner ? `\n${r.mode_banner}` : ''

          return out(`Resumed ${arg} (${r?.count ?? 0} messages).${banner}`)
        }

        const r = (await this.controlQuery('list_sessions', {})) as any
        const ss = Array.isArray(r?.sessions) ? r.sessions : []

        return out(
          ss.length
            ? `Sessions:\n${ss.slice(0, 10).map((s: any) => `${s.session_id} — ${s.preview ?? ''}`).join('\n')}\nUse /resume <id>`
            : 'No saved sessions.'
        )
      }

      case 'skills':
        // Reached only via the slash-worker fallback for unknown subcommands —
        // the TUI-local /skills (ops.ts) owns the hub + list/inspect/search.
        return out('usage: /skills [list | inspect <name> | search <query>] — bare /skills opens the hub')
      case 'workflows': {
        const r = (await this.controlQuery('workflows', {})) as any

        if (r && r.ok === false) {return out(`workflows: ${r.error ?? 'unavailable'}`)}

        return out(String(r?.text ?? 'No workflow runs.'))
      }

      default: {
        // Workflow commands (/deep-research + saved .clawcodex/workflows/*.py):
        // the backend expands the directive; the app submits it as a prompt so
        // the model launches the run via the Workflow tool.
        const r = (await this.controlQuery('workflow_command', { args: arg ?? '', name })) as any

        if (r?.ok && typeof r.prompt === 'string' && r.prompt) {
          return {
            message: r.prompt,
            notice: typeof r.notice === 'string' ? r.notice : undefined,
            type: 'send'
          }
        }

        // Not a workflow — try skills (bundled + on-disk SKILL.md), the CC
        // rule that a typed /name falls back to the skill of that name.
        const skill = await trySkill(name).catch(() => null)

        if (skill) {
          return skill
        }

        return out(`/${name} isn't wired into the clawcodex backend yet.`)
      }
    }
  }

  // @-file mention completion, served from the workspace filesystem (shell-style:
  // resolve the dir part of the typed word, list it, filter by the basename).
  private completePath(word: string): Array<{ display: string; meta: string; text: string }> {
    try {
      const cwd = process.env.DSH_CCTUI_WORKSPACE || process.env.DSH_CCTUI_CWD || process.cwd()
      const stripped = word.startsWith('@') ? word.slice(1) : word
      const slash = stripped.lastIndexOf('/')
      const dirPart = slash === -1 ? '' : stripped.slice(0, slash + 1)
      const base = (slash === -1 ? stripped : stripped.slice(slash + 1)).toLowerCase()
      const absDir = pathResolve(cwd, dirPart || '.')

      return readdirSync(absDir, { withFileTypes: true })
        .filter(e => !e.name.startsWith('.') && e.name.toLowerCase().startsWith(base))
        .slice(0, 50)
        .map(e => {
          const isDir = e.isDirectory()
          const rel = dirPart + e.name + (isDir ? '/' : '')

          return { display: rel, meta: isDir ? 'dir' : 'file', text: rel }
        })
    } catch {
      return []
    }
  }
  // Rich Edit/Write result forwarded by the agent-server (`tool_use_result`
  // on the user envelope, trimmed to the display shape). Shape-detected from
  // the value itself — self-describing type/filePath/structuredPatch — so it
  // works even when the tool_use bookkeeping is empty (mid-turn attach).
  private structuredDiff(value: any): StructuredDiffPayload | undefined {
    if (!value || typeof value !== 'object') {return undefined}
    const kind = value.type

    if (kind !== 'create' && kind !== 'update') {return undefined}

    if (typeof value.filePath !== 'string' || !Array.isArray(value.structuredPatch)) {return undefined}
    const hunks: PatchHunk[] = []

    for (const h of value.structuredPatch) {
      if (!h || typeof h !== 'object' || !Array.isArray(h.lines)) {return undefined}
      hunks.push({
        lines: h.lines.map(String),
        newLines: Number(h.newLines ?? 0),
        newStart: Number(h.newStart ?? 1),
        oldLines: Number(h.oldLines ?? 0),
        oldStart: Number(h.oldStart ?? 1)
      })
    }

    return {
      ...(typeof value.content === 'string' && { content: value.content }),
      filePath: value.filePath,
      ...(typeof value.firstLine === 'string' && { firstLine: value.firstLine }),
      hunks,
      kind
    }
  }

  // WebSearch display data on the same envelope (agent_server trims the
  // structured output to searchCount/durationSeconds). Shape-detected like
  // structuredDiff so it renders without tool_use bookkeeping.
  private webSearchDisplay(value: any): undefined | WebSearchDisplay {
    if (!value || typeof value !== 'object' || value.type !== 'web_search') {return undefined}
    const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : undefined)

    return { durationSeconds: num(value.durationSeconds), searchCount: num(value.searchCount) }
  }

  // AskUserQuestion answers on the same envelope. Shape-detected like the
  // others so a mid-turn attach renders without tool_use bookkeeping.
  private askUserDisplay(value: any): AskUserDisplay | undefined {
    if (!value || typeof value !== 'object' || value.type !== 'ask_user_question') {return undefined}

    if (value.declined) {
      return { declined: true }
    }

    const raw = value.answers
    const answers: Record<string, string> = {}

    if (raw && typeof raw === 'object') {
      for (const [question, answer] of Object.entries(raw)) {
        answers[question] = String(answer)
      }
    }

    return { answers }
  }

  private imageDisplay(value: any): ImageDisplay | undefined {
    if (!value || typeof value !== 'object' || value.type !== 'image') {return undefined}
    const size = value.originalSize

    return {
      originalSize: typeof size === 'number' && Number.isFinite(size) ? size : undefined
    }
  }

  // Legacy fallback (agent-server predating tool_use_result): a fake unified
  // diff from the Edit/Write tool *input* so the app can render at least a
  // colored ```diff block. No line numbers/context — superseded by
  // structuredDiff whenever the backend forwards the real patch.
  private editDiff(name: string, input: any): string | undefined {
    try {
      const file = String(input?.file_path ?? input?.path ?? '')

      if (name === 'Write') {
        const body = String(input?.content ?? '')
          .split('\n')
          .map(l => '+' + l)
          .join('\n')

        return body ? `+++ ${file}\n${body}` : undefined
      }

      if (name === 'Edit') {
        const oldB = String(input?.old_string ?? '')
          .split('\n')
          .map(l => '-' + l)
          .join('\n')

        const newB = String(input?.new_string ?? '')
          .split('\n')
          .map(l => '+' + l)
          .join('\n')

        return `--- ${file}\n+++ ${file}\n${oldB}\n${newB}`
      }
    } catch {
      /* ignore */
    }

    return undefined
  }

  // ── clawcodex NDJSON → clawcodex GatewayEvent ───────────────────────────────
  private dispatch(msg: any): void {
    switch (msg?.type) {
      case 'assistant': {
        const content = msg.message?.content

        if (Array.isArray(content)) {
          for (const b of content) {
            if (b?.type === 'tool_use') {
              this.ensureMsgStart()
              this.toolInputs.set(String(b.id), { input: b.input, name: String(b.name ?? '') })
              this.publish({
                payload: {
                  args_text: safeJson(b.input),
                  context: toolContext(b.input),
                  name: b.name,
                  todos: todosFromInput(b.name, b.input),
                  tool_id: b.id
                },
                type: 'tool.start'
              })
            }
          }
        }

        break
      }

      case 'control_request':
        this.handleServerControl(msg)

        break

      case 'control_response':
        this.resolvePending(msg)

        break

      case 'result':
        this.publish({
          payload: {
            // Running session totals for /cost + the exit summary.
            cost: msg.cost && typeof msg.cost === 'object' ? msg.cost : undefined,
            permission_mode: typeof msg.permission_mode === 'string' ? msg.permission_mode : undefined,
            session_turns: typeof msg.session_turns === 'number' ? msg.session_turns : undefined,
            text: typeof msg.result === 'string' ? msg.result : undefined,
            usage: msg.usage
          },
          type: 'message.complete'
        })
        this.msgStarted = false

        if (msg.is_error || msg.subtype === 'error') {
          // `message.complete` above has ALREADY rendered `msg.result` as the
          // turn's text. Echoing it again here printed the same string twice —
          // once as the assistant message, once as a red error line — because
          // an early stop (`error_during_execution` / `error_max_turns`, from
          // a run the agent loop ended itself) carries its explanation in
          // `result` and sets no separate `error` field. Prefer a distinct
          // `error`; otherwise say WHY in one short line and let the already-
          // rendered text stand on its own.
          const distinct = typeof msg.error === 'string' && msg.error ? msg.error : undefined
          const stopped =
            typeof msg.subtype === 'string' && msg.subtype.startsWith('error_')
              ? `run stopped early (${msg.subtype})`
              : undefined
          this.publish({
            payload: { message: distinct ?? stopped ?? String(msg.result ?? 'error') },
            type: 'error'
          })
        }

        break
      case 'stream_event': {
        const d = msg.event?.delta

        if (d?.type === 'text_delta' && d.text) {
          this.ensureMsgStart()
          this.publish({ payload: { text: d.text }, type: 'message.delta' })
        } else if (d?.type === 'thinking_delta' && d.thinking) {
          this.ensureMsgStart()
          this.publish({ payload: { text: d.thinking }, type: 'thinking.delta' })
        }

        break
      }

      case 'system':
        if (msg.subtype === 'init') {
          this.sessionId = String(msg.session_id ?? '')
          this.sessionInfo = this.toSessionInfo(msg)
          this.readyResolve?.()
          this.publish({ payload: {}, session_id: this.sessionId, type: 'gateway.ready' })
          this.publish({ payload: this.sessionInfo, session_id: this.sessionId, type: 'session.info' })
        } else if (msg.subtype === 'status') {
          if (typeof msg.permission_mode === 'string' && msg.permission_mode) {
            // Server-initiated mode push (a plan-approval setMode, EnterPlanMode/
            // ExitPlanMode transition — the print.ts:1054-1073 permissionMode
            // status analog). Routes to the existing permission.mode handler so
            // the footer badge tracks mid-turn flips the RPC replies can't see.
            this.publish({ payload: { mode: String(msg.permission_mode) }, type: 'permission.mode' })
          } else if (msg.level === 'error') {
            this.publish({ payload: { message: String(msg.message ?? 'error') }, type: 'error' })
          } else {
            this.publish({ payload: { kind: 'status', text: String(msg.message ?? '') }, type: 'status.update' })
          }
        } else if (msg.subtype === 'task_notification') {
          // A background workflow/agent finished: render the completion banner
          // as a persistent system transcript line ("[bg <id>] ✔ … completed").
          this.publish({
            payload: { task_id: String(msg.task_id ?? 'task'), text: String(msg.message ?? '') },
            type: 'background.complete'
          })
        } else if (msg.subtype === 'goal_status') {
          // /goal verdict line ("✓ Goal achieved" / "↻ Continuing" / "⏸ …").
          // kind:'goal' routes to the hermes-ported handler in
          // createGatewayEventHandler (sys transcript line + brief status).
          this.publish({
            payload: { kind: 'goal', text: String(msg.message ?? '') },
            type: 'status.update'
          })

          // Indicator refresh: every loop transition (continue/done/paused/
          // restored) rides here. Backends without the snapshot field only
          // clear on an explicit goal_active=false — never invent state.
          if ('goal' in msg) {
            this.publishGoalState(msg)
          } else if (msg.goal_active === false) {
            this.publish({ payload: { goal: null }, type: 'goal.state' })
          }
        } else if (msg.subtype === 'review_summary') {
          // Self-improvement background review finished with committed
          // writes: forward as the hermes-native review.summary event —
          // createGatewayEventHandler renders it as a persistent
          // "💾 Self-improvement review: …" transcript line.
          this.publish({
            payload: { text: String(msg.message ?? '') },
            session_id: this.sessionId,
            type: 'review.summary'
          })
        } else if (msg.subtype === 'recap') {
          // Post-turn recap: the "✻ recap: …" transcript line plus the
          // tab-acceptable composer suggestion (ghost text). The handler
          // drops it when a new turn is already running.
          this.publish({
            payload: { recap: String(msg.recap ?? ''), suggestion: String(msg.suggestion ?? '') },
            session_id: this.sessionId,
            type: 'turn.recap'
          })
        } else if (msg.subtype === 'cron_status') {
          // Scheduled-task transitions (/loop wakeup fired, cron job fired,
          // Esc-cleared, restore): kind:'cron' renders the transcript line;
          // the `scheduled` snapshot feeds the CronIndicator store.
          if (typeof msg.message === 'string' && msg.message.trim()) {
            this.publish({ payload: { kind: 'cron', text: String(msg.message) }, type: 'status.update' })
          }

          this.publish({
            payload: { scheduled: (msg.scheduled ?? null) as CronSnapshot | null },
            type: 'cron.state'
          })
        }

        break
      case 'user': {
        const content = msg.message?.content

        if (Array.isArray(content)) {
          // The backend builds one user message per tool result, so a
          // message-level tool_use_result belongs to the lone block. Consume
          // it on first attach so a hypothetical multi-block message can't
          // pin the same patch onto every result.
          let structured = this.structuredDiff(msg.tool_use_result)
          let webSearch = this.webSearchDisplay(msg.tool_use_result)
          let image = this.imageDisplay(msg.tool_use_result)
          let askUser = this.askUserDisplay(msg.tool_use_result)

          for (const b of content) {
            if (b?.type === 'tool_result') {
              const stored = this.toolInputs.get(String(b.tool_use_id))
              // A failed edit must not render a diff at all — neither the
              // real patch nor a fabricated one for an edit that never ran.
              const isError = Boolean(b.is_error)
              const fullText = flattenToolResultContent(b.content)
              const resultText = formatToolResult(stored?.name, fullText, isError, webSearch, image, askUser)
              const taskTodos = isError ? undefined : this.taskTodosFromResult(stored?.name, stored?.input, fullText)
              // Read shows no expand hint (the summary loses nothing the user
              // needs — the file is in context), so retain nothing for it.
              const expandable = stored?.name !== 'Read'
              this.publish({
                payload: {
                  // error drives the ✗ mark (red bullet + red result rows);
                  // without it a real failure renders as a green success.
                  error: isError ? resultText : undefined,
                  inline_diff:
                    isError || structured || !stored ? undefined : this.editDiff(stored.name, stored.input),
                  name: stored?.name,
                  result_raw: expandable ? rawToolResult(resultText, fullText) : undefined,
                  result_text: resultText,
                  structured_diff: isError ? undefined : structured,
                  todos: taskTodos ?? (isError ? undefined : todosFromInput(stored?.name, stored?.input)),
                  tool_id: b.tool_use_id
                },
                type: 'tool.complete'
              })
              structured = undefined
              webSearch = undefined
              image = undefined
              askUser = undefined
              this.toolInputs.delete(String(b.tool_use_id))
            }
          }
        }

        break
      }

      case 'agent_progress': {
        // ch13 round-4 — the backend emits rich subagent progress
        // (agent.py ProgressTracker) but the bridge dropped it, so the
        // subagent HUD stayed dark during Task/Agent delegation. Map it to
        // the subagent.* events the app renderer already handles.
        const aid = String(msg.agent_id ?? '')

        if (aid) {
          const payload: any = {
            depth: msg.depth ?? 0,
            goal: msg.description || msg.name || 'subagent',
            // The model the subagent actually runs on. Without this the
            // agents overlay falls back to 'inherit' — which the
            // per-provider default-subagent-model change makes actively
            // wrong (spawns default to e.g. claude-haiku-4-5 now).
            model: msg.model,
            subagent_id: aid,
            subagent_type: msg.subagent_type
          }

          if (!this.seenSubagents.has(aid)) {
            this.seenSubagents.add(aid)
            this.publish({ payload: { ...payload, status: 'running' }, type: 'subagent.start' })
          }

          const activity = String(msg.activity ?? '').trim()

          if (activity) {
            // ch13 round-4 — map to the field names the HUD renderer reads
            // (turnController: output_tokens / tool_count), not the backend's
            // raw `tokens`/`tool_use_count` which the renderer ignores.
            this.publish({
              payload: { ...payload, text: activity, output_tokens: msg.tokens, tool_count: msg.tool_use_count },
              type: 'subagent.progress'
            })
          }

          const status = String(msg.status ?? '')

          if (status === 'completed' || status === 'failed' || status === 'killed') {
            this.publish({ payload: { ...payload, status }, type: 'subagent.complete' })
          }
        }

        break
      }
      // keep_alive / streamlined_* → ignored for the basic port
    }
  }

  private taskTodosFromResult(name: string | undefined, input: unknown, result: string): undefined | TaskTodo[] {
    if (!name?.startsWith('Task') || !input || typeof input !== 'object') {
      return undefined
    }

    const args = input as Record<string, unknown>
    let parsed: Record<string, any> | undefined

    try {
      const value = JSON.parse(result)

      if (value && typeof value === 'object' && !Array.isArray(value)) {
        parsed = value
      }
    } catch {
      // Older backends emitted the human-readable TaskV2 strings parsed below.
    }

    if (name === 'TaskCreate') {
      const id = String(parsed?.task?.id ?? result.match(createdTaskId)?.[1] ?? '').trim()
      const content = String(args.subject ?? '').trim()

      if (id && content) {
        const activeForm = String(args.activeForm ?? '').trim()
        this.taskTodos.set(id, {
          ...(activeForm && { activeForm }),
          content,
          id,
          status: 'pending'
        })
      }
    } else if (name === 'TaskUpdate') {
      const id = String(args.taskId ?? '').trim()

      if (parsed?.success === false) {
        return [...this.taskTodos.values()]
      } else if (id && args.status === 'deleted') {
        this.taskTodos.delete(id)
      } else if (id) {
        const current = this.taskTodos.get(id)

        if (current) {
          const content = String(args.subject ?? current.content).trim()
          const activeForm = String(args.activeForm ?? current.activeForm ?? '').trim()

          const status =
            args.status === 'pending' || args.status === 'in_progress' || args.status === 'completed'
              ? args.status
              : current.status

          this.taskTodos.set(id, {
            ...(activeForm && { activeForm }),
            content,
            id,
            status
          })
        }
      }
    } else if (name === 'TaskList') {
      const listed = new Map<string, TaskTodo>()

      if (Array.isArray(parsed?.tasks)) {
        for (const task of parsed.tasks) {
          const id = String(task?.id ?? '').trim()
          const content = String(task?.subject ?? '').trim()
          const status = task?.status

          if (!id || !content || (status !== 'pending' && status !== 'in_progress' && status !== 'completed')) {
            continue
          }

          const previous = this.taskTodos.get(id)
          listed.set(id, {
            ...(previous?.activeForm && { activeForm: previous.activeForm }),
            content,
            id,
            status
          })
        }
      } else {
        for (const line of result.split('\n')) {
          const match = line.match(taskListLine)

          if (!match) {continue}
          const [, id, status, content] = match
          const previous = this.taskTodos.get(id!)
          listed.set(id!, {
            ...(previous?.activeForm && { activeForm: previous.activeForm }),
            content: content!,
            id: id!,
            status: status as TaskTodo['status']
          })
        }
      }

      // "No tasks found" is an authoritative empty list. For other malformed
      // output, preserve the projection rather than blanking the HUD.
      if (listed.size || Array.isArray(parsed?.tasks) || result.trim() === 'No tasks found') {
        this.taskTodos = listed
      }
    } else {
      return undefined
    }

    return [...this.taskTodos.values()]
  }

  private ensureMsgStart(): void {
    if (!this.msgStarted) {
      this.msgStarted = true
      this.publish({ type: 'message.start' })
    }
  }

  // Server-initiated control requests (tool permission / elicitation).
  private handleServerControl(msg: any): void {
    const req = msg.request

    if (req?.subtype === 'can_use_tool') {
      // ch13 round-4 — carry the backend's permission SUGGESTIONS so the
      // "don't ask again" choice persists a real rule.
      const suggestions: any[] = Array.isArray(req.suggestions) ? req.suggestions : []
      this.pendingApproval = { input: req.input, request_id: String(msg.request_id ?? ''), suggestions }

      // ExitPlanMode's ask is the plan-approval dialog, not the generic
      // command box (ExitPlanModePermissionRequest.tsx). The backend sends
      // the plan body (read from the session plan file), its path, and
      // whether bypass is available (elevated-option label). Replies go
      // through planApproval.respond against the same pendingApproval slot.
      if (String(req.tool_name ?? '') === 'ExitPlanMode') {
        this.publish({
          payload: {
            bypass_available: req.bypass_available === true,
            plan: typeof req.plan === 'string' ? req.plan : null,
            plan_file_path: typeof req.plan_file_path === 'string' ? req.plan_file_path : null
          },
          type: 'plan.approval'
        })

        return
      }

      // Show the ACTUAL command/action under review, not the tool name or a raw
      // JSON dump — and carry the editable grant rule separately so the box can
      // offer a broadenable "don't ask again for <rule>" option. Only offer the
      // persistable option when the backend sent a rule.
      // Editable rule only when the suggestion carries exactly ONE rule — a
      // compound command's suggestion bundles several (grep:*, tr:*, …) and
      // is accepted/declined as a set (static label via session_label).
      const suggestionRules = Array.isArray(suggestions[0]?.rules) ? suggestions[0].rules : []
      const ruleContent = suggestionRules.length === 1 ? (suggestionRules[0]?.rule_content ?? null) : null
      this.publish({
        payload: {
          allow_permanent: suggestions.length > 0,
          command: approvalCommandText(req.input),
          rule: ruleContent,
          rule_label: describeSuggestionRule(suggestions[0]),
          // Authoritative per-tool wording for the persist option (e.g. "allow
          // all edits during this session"); the box uses it verbatim for
          // non-Bash tools instead of a generic "don't ask again for <tool>".
          session_label: typeof req.session_label === 'string' ? req.session_label : null,
          tool_name: String(req.tool_name ?? 'tool'),
          // Destructive-command caution (backend-computed) → warning line.
          warning: typeof req.warning === 'string' && req.warning ? req.warning : null
        },
        type: 'approval.request'
      })
    } else if (req?.subtype === 'ask_user_question') {
      // AskUserQuestion does NOT come through the permission lane (the
      // questions are the gate), so it carries its own subtype and its own
      // reply shape — free-form, because permission replies have nowhere to
      // put structured answers.
      const questions: any[] = Array.isArray(req.questions) ? req.questions : []
      this.pendingQuestions = { questions, request_id: String(msg.request_id ?? '') }
      this.publish({ payload: { questions }, type: 'question.request' })
    } else if (req?.subtype === 'mcp_elicitation') {
      this.publish({
        payload: { choices: null, question: 'Input requested', request_id: String(msg.request_id ?? '') },
        type: 'clarify.request'
      })
    }
  }

  private handleExit(code: null | number, reason?: string): void {
    if (this.readyTimer) {
      clearTimeout(this.readyTimer)
      this.readyTimer = null
    }

    const err = new Error(reason || `agent-server exited${code === null ? '' : ` (${code})`}`)

    for (const p of this.pending.values()) {p.reject(err)}
    this.pending.clear()

    if (this.subscribed) {this.emit('exit', code)}
    else {this.pendingExit = code}
  }

  private publish(ev: GatewayEvent): void {
    if (ev.type === 'gateway.ready' && this.readyTimer) {
      clearTimeout(this.readyTimer)
      this.readyTimer = null
    }

    if (this.subscribed) {this.emit('event', ev)}
    else {this.buffered.push(ev)}
  }

  /** /goal indicator refresh from any carrier with a `goal` snapshot field
   *  (goal/subgoal/clear replies, goal_status events). A carrier WITHOUT the
   *  field (older backend) is a no-op — never invent or drop state on
   *  silence. `goal_rev` rides along so the store can drop stale carriers. */
  private publishGoalState(carrier: unknown): void {
    const c = carrier as { goal?: unknown; goal_rev?: unknown; session_id?: unknown } | null

    if (!c || typeof c !== 'object' || !('goal' in c)) {
      return
    }

    const goal = c.goal && typeof c.goal === 'object' ? (c.goal as GoalSnapshot) : null

    this.publish({
      payload: { goal, rev: typeof c.goal_rev === 'number' ? c.goal_rev : undefined },
      session_id: typeof c.session_id === 'string' ? c.session_id : undefined,
      type: 'goal.state'
    })
  }

  /** Stats-line refresh from a clear/resume reply's rider (session_turns +
   *  cost snapshot). Silently a no-op for replies without the fields. */
  private publishSessionStats(r: unknown): void {
    const reply = r as { cost?: unknown; session_turns?: unknown } | null

    if (typeof reply?.session_turns !== 'number' && !reply?.cost) {
      return
    }

    this.publish({
      payload: {
        cost: reply.cost && typeof reply.cost === 'object' ? (reply.cost as any) : undefined,
        session_turns: typeof reply.session_turns === 'number' ? reply.session_turns : undefined
      },
      type: 'session.stats'
    })
  }

  private pushLog(line: string): void {
    this.logs.push(line)

    if (this.logs.length > MAX_LOG_LINES) {this.logs.shift()}
  }

  private resolvePending(msg: any): void {
    const r = msg.response
    const id = r?.request_id
    const p = id ? this.pending.get(id) : undefined

    if (!p) {return}
    this.pending.delete(id)

    if (r.subtype === 'error') {p.reject(new Error(String(r.error ?? 'error')))}
    else {p.resolve(r.response)}
  }

  private send(obj: unknown): void {
    try {
      this.proc?.stdin?.write(JSON.stringify(obj) + '\n')
    } catch {
      // best effort
    }
  }

  private sendControl(subtype: string, params: Record<string, unknown>): void {
    this.send({ request: { subtype, ...params }, request_id: `c${++this.reqId}`, type: 'control_request' })
  }

  private toSessionInfo(init: any): SessionInfo {
    const toolNames: string[] = Array.isArray(init.tools)
      ? init.tools.map((t: any) => t?.name).filter(Boolean)
      : []

    // A fused session reports `model` as the BASE model id (what serves the
    // turn, and what the backend's cost/context-window lookups key off) and
    // the fusion model's name separately. The name is what the user selected
    // and the only signal that images are being routed through a second
    // model, so it is what the model line shows — matching CCR's contract
    // that a fusion model behaves "like a normal model". `/fusion list`
    // remains the place to see which two models it is made of.
    const fusion = typeof init.fusion === 'string' ? init.fusion : ''

    return {
      cwd: init.cwd,
      model: fusion || String(init.model ?? ''),
      // Nano mode chip (backend --nano). Strict === true: absent on older
      // backends must stay falsy, never render a stale badge.
      nano: init.nano === true,
      permission_mode: typeof init.permission_mode === 'string' ? init.permission_mode : undefined,
      profile_name: init.provider ? String(init.provider) : undefined,
      // Rendered beside the model name; the backend sends the session's
      // /effort level (seeded from --effort at launch), null when unset.
      reasoning_effort: typeof init.reasoning_effort === 'string' ? init.reasoning_effort : undefined,
      skills: {},
      tools: { '': toolNames },
      // The app gates "ready" on info.version (useSessionLifecycle:227) and the
      // banner shows it as "clawcodex v{version}", so this is the app version,
      // not the wire protocol_version.
      version: DSH_CCTUI_VERSION
    } as SessionInfo
  }
}
