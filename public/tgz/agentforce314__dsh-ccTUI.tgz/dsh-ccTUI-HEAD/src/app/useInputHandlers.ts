import { forceRedraw, useInput } from '@dsh-cctui/ink'
import { useStore } from '@nanostores/react'
import { useEffect, useRef } from 'react'

import { DASHBOARD_TUI_MODE } from '../config/env.js'
import { TYPING_IDLE_MS } from '../config/timing.js'
import { PLACEHOLDER, suggestedQuery } from '../content/placeholders.js'
import type {
  ApprovalRespondResponse,
  QuestionRespondResponse,
  SecretRespondResponse,
  SudoRespondResponse,
  VoiceRecordResponse
} from '../gatewayTypes.js'
import { isAction, isCopyShortcut, isMac, isVoiceToggleKey } from '../lib/platform.js'
import { computePrecisionWheelStep, initPrecisionWheel } from '../lib/precisionWheel.js'
import { computeWheelStep, initWheelAccelForHost } from '../lib/wheelAccel.js'

import { getCronState } from './cronStore.js'
import { getInputSelection } from './inputSelectionStore.js'
import type { InputHandlerActions, InputHandlerContext, InputHandlerResult } from './interfaces.js'
import { $isBlocked, $overlayState, patchOverlayState } from './overlayStore.js'
import { turnController } from './turnController.js'
import { getTurnState, patchTurnState, toggleTodoCollapsed } from './turnStore.js'
import { getUiState, patchUiState } from './uiStore.js'

const isCtrl = (key: { ctrl: boolean }, ch: string, target: string) => key.ctrl && ch.toLowerCase() === target
const DASHBOARD_NEW_SESSION_MESSAGE = 'starting a fresh dashboard chat...'

export const shouldAllowIdleHotkeyExit = (dashboardTuiMode = DASHBOARD_TUI_MODE) => !dashboardTuiMode

export function handleIdleHotkeyExit(
  actions: Pick<InputHandlerActions, 'requestExit' | 'sys'>,
  dashboardTuiMode = DASHBOARD_TUI_MODE,
  requestDashboardNewSession?: () => void
) {
  if (!shouldAllowIdleHotkeyExit(dashboardTuiMode)) {
    requestDashboardNewSession?.()

    return actions.sys(DASHBOARD_NEW_SESSION_MESSAGE)
  }

  // requestExit runs the --worktree keep/remove flow when one is active and
  // dies directly otherwise — same routing as /exit.
  return actions.requestExit()
}

/**
 * Approval / clarify / confirm overlays mount their own `useInput` handlers
 * for the in-prompt keys (arrows, numbers, Enter, sometimes Esc).  The global
 * input handler used to early-return for any other key while one of those
 * overlays was up, which silently disabled transcript scrolling — the user
 * couldn't read context above the prompt that the prompt itself was asking
 * about.  Returns true when the key is a transcript-scroll input that should
 * fall through to the global scroll handlers even while a prompt is active.
 *
 * Modifier-held wheel (precision mode) is included — a user who wants to
 * scroll a single line at a time during a prompt expects it to work.
 */
export function shouldFallThroughForScroll(key: {
  downArrow: boolean
  pageDown: boolean
  pageUp: boolean
  shift: boolean
  upArrow: boolean
  wheelDown: boolean
  wheelUp: boolean
}): boolean {
  if (key.wheelUp || key.wheelDown) {
    return true
  }

  if (key.pageUp || key.pageDown) {
    return true
  }

  if (key.shift && (key.upArrow || key.downArrow)) {
    return true
  }

  return false
}

/**
 * Plain Tab accepts the composer placeholder's suggested query (`Try "…"`).
 * True only while that suggestion is actually visible — fresh conversation,
 * idle, empty input (appLayout gates the placeholder on the first two;
 * TextInput hides it once the input has text) — and only for unmodified Tab
 * with no completion menu open, so it can never shadow completion-accept or
 * the Shift+Tab permission-mode cycle. Mirrors original CC's Tab fallback
 * (useTypeahead.tsx handleKeyDown: tab / no shift / no suggestions / empty
 * input → insert the prompt suggestion).
 */
export const shouldAcceptPlaceholderSuggestion = (
  key: { shift: boolean; tab: boolean },
  state: { busy: boolean; completionsLen: number; conversationEmpty: boolean; input: string }
): boolean =>
  key.tab && !key.shift && !state.completionsLen && !state.input && state.conversationEmpty && !state.busy

/**
 * Plain Tab accepts the end-of-turn recap suggestion showing as the
 * composer's ghost text. Unlike the placeholder accept above this fires
 * MID-conversation — that is the feature: the turn just ended and the server
 * suggested the next prompt — but under the same visibility gates (idle,
 * empty input, no completion menu open, unmodified Tab), so it can never
 * shadow completion-accept or the Shift+Tab permission-mode cycle.
 */
export const shouldAcceptPendingSuggestion = (
  key: { shift: boolean; tab: boolean },
  state: { busy: boolean; completionsLen: number; input: string; suggestion: null | string }
): boolean =>
  key.tab && !key.shift && !state.completionsLen && !state.input && !state.busy && Boolean(state.suggestion)

export function applyVoiceRecordResponse(
  response: null | VoiceRecordResponse,
  starting: boolean,
  voice: Pick<InputHandlerContext['voice'], 'setProcessing' | 'setRecording'>,
  sys: (text: string) => void
) {
  if (!starting || response?.status === 'recording') {
    return
  }

  voice.setRecording(false)

  if (response?.status === 'busy') {
    voice.setProcessing(true)
    sys('voice: still transcribing; try again shortly')
  } else {
    voice.setProcessing(false)
  }
}

export function useInputHandlers(ctx: InputHandlerContext): InputHandlerResult {
  const { actions, composer, conversationEmpty, gateway, terminal, voice, wheelStep } = ctx
  const { actions: cActions, refs: cRefs, state: cState } = composer

  const overlay = useStore($overlayState)
  const isBlocked = useStore($isBlocked)
  const pagerPageSize = Math.max(5, (terminal.stdout?.rows ?? 24) - 6)
  const scrollIdleTimer = useRef<null | ReturnType<typeof setTimeout>>(null)

  // Wheel accel ported from claude-code: inter-event timing drives step size,
  // direction flips reset. wheelStep (WHEEL_SCROLL_STEP) is the base; final
  // rows = wheelStep × accelMult. State mutates in place across renders.
  const wheelAccelRef = useRef(initWheelAccelForHost())

  const precisionWheelRef = useRef(initPrecisionWheel())

  useEffect(() => () => clearTimeout(scrollIdleTimer.current ?? undefined), [])

  const scrollTranscript = (delta: number) => {
    if (getUiState().busy) {
      turnController.boostStreamingForScroll()
      clearTimeout(scrollIdleTimer.current ?? undefined)
      scrollIdleTimer.current = setTimeout(() => {
        scrollIdleTimer.current = null
        turnController.relaxStreaming()
      }, TYPING_IDLE_MS)
    }

    terminal.scrollWithSelection(delta)
  }

  const copySelection = () => {
    // ink's copySelection() already calls setClipboard() which handles
    // pbcopy (macOS), wl-copy/xclip (Linux), tmux, and OSC 52 fallback.
    terminal.selection.copySelection()
  }

  const clearSelection = () => {
    terminal.selection.clearSelection()
  }

  const cancelOverlayFromCtrlC = () => {
    if (overlay.clarify) {
      return actions.answerClarify('')
    }

    if (overlay.approval) {
      return gateway
        .rpc<ApprovalRespondResponse>('approval.respond', { choice: 'deny', session_id: getUiState().sid })
        .then(r => r && (patchOverlayState({ approval: null }), patchTurnState({ outcome: 'denied' })))
    }

    if (overlay.planApproval) {
      // Ctrl+C on the plan dialog = reject without feedback (stay in plan
      // mode), same as the dialog's own Esc.
      return gateway
        .rpc<ApprovalRespondResponse>('planApproval.respond', { choice: 'deny', session_id: getUiState().sid })
        .then(
          r =>
            r &&
            (patchOverlayState({ planApproval: null }),
            patchTurnState({ outcome: 'plan rejected — still planning' }))
        )
    }

    if (overlay.questions) {
      // Ctrl+C on the question dialog = dismiss without answering, same as the
      // dialog's own Esc. Without a branch here Ctrl+C is a silent no-op and
      // the tool stays blocked until the ask_user timeout. Direct rpc rather
      // than an action, like the two branches above: useMainApp declares
      // answerQuestions AFTER it calls useInputHandlers.
      return gateway
        .rpc<QuestionRespondResponse>('question.respond', { answers: null, session_id: getUiState().sid })
        .then(
          r => r && (patchOverlayState({ questions: null }), patchTurnState({ outcome: 'questions dismissed' }))
        )
    }

    if (overlay.sudo) {
      return gateway
        .rpc<SudoRespondResponse>('sudo.respond', { password: '', request_id: overlay.sudo.requestId })
        .then(r => r && (patchOverlayState({ sudo: null }), actions.sys('sudo cancelled')))
    }

    if (overlay.secret) {
      return gateway
        .rpc<SecretRespondResponse>('secret.respond', { request_id: overlay.secret.requestId, value: '' })
        .then(r => r && (patchOverlayState({ secret: null }), actions.sys('secret entry cancelled')))
    }

    if (overlay.modelPicker) {
      return patchOverlayState({ modelPicker: false })
    }

    if (overlay.petPicker) {
      return patchOverlayState({ petPicker: false })
    }

    if (overlay.logoPicker) {
      return patchOverlayState({ logoPicker: false })
    }

    if (overlay.memoryPicker) {
      return patchOverlayState({ memoryPicker: false })
    }

    if (overlay.billing) {
      return patchOverlayState({ billing: null })
    }

    if (overlay.skillsHub) {
      return patchOverlayState({ skillsHub: false })
    }

    if (overlay.pluginsHub) {
      return patchOverlayState({ pluginsHub: false })
    }

    if (overlay.sessions) {
      return patchOverlayState({ sessions: false })
    }

    if (overlay.agents) {
      return patchOverlayState({ agents: false })
    }
  }

  const cycleQueue = (dir: 1 | -1) => {
    const len = cRefs.queueRef.current.length

    if (!len) {
      return false
    }

    const index = cState.queueEditIdx === null ? (dir > 0 ? 0 : len - 1) : (cState.queueEditIdx + dir + len) % len

    cActions.setQueueEdit(index)
    cActions.setHistoryIdx(null)
    cActions.setInput(cRefs.queueRef.current[index] ?? '')

    return true
  }

  const cycleHistory = (dir: 1 | -1) => {
    const h = cRefs.historyRef.current
    const cur = cState.historyIdx

    if (dir < 0) {
      if (!h.length) {
        return
      }

      if (cur === null) {
        cRefs.historyDraftRef.current = cState.input
      }

      const index = cur === null ? h.length - 1 : Math.max(0, cur - 1)

      cActions.setHistoryIdx(index)
      cActions.setQueueEdit(null)
      cActions.setInput(h[index] ?? '')

      return
    }

    if (cur === null) {
      return
    }

    const next = cur + 1

    if (next >= h.length) {
      cActions.setHistoryIdx(null)
      cActions.setInput(cRefs.historyDraftRef.current)
    } else {
      cActions.setHistoryIdx(next)
      cActions.setInput(h[next] ?? '')
    }
  }

  // CLI parity: Ctrl+B toggles a VAD-bounded push-to-talk capture
  // (NOT the voice-mode umbrella bit). The mode is enabled via /voice on;
  // Ctrl+B while the mode is off sys-nudges the user. While the mode is
  // on, the first press starts a single VAD-bounded capture
  // (gateway -> start_continuous(auto_restart=false), VAD auto-stop ->
  // transcribe -> idle), a subsequent press stops and transcribes it.
  // The gateway publishes voice.status + voice.transcript events that
  // createGatewayEventHandler turns into UI badges and composer injection.
  const voiceRecordToggle = () => {
    if (!voice.enabled) {
      return actions.sys('voice: mode is off — enable with /voice on')
    }

    const starting = !voice.recording
    const action = starting ? 'start' : 'stop'

    // Optimistic UI — flip the REC badge immediately so the user gets
    // feedback while the RPC round-trips; the voice.status event is the
    // authoritative source and may correct us.
    if (starting) {
      voice.setRecording(true)
    } else {
      voice.setRecording(false)
      voice.setProcessing(false)
    }

    gateway
      .rpc<VoiceRecordResponse>('voice.record', { action, session_id: getUiState().sid })
      .then(r => applyVoiceRecordResponse(r, starting, voice, actions.sys))
      .catch((e: Error) => {
        // Revert optimistic UI on failure.
        if (starting) {
          voice.setRecording(false)
        }

        actions.sys(`voice error: ${e.message}`)
      })
  }

  useInput((ch, key) => {
    const live = getUiState()

    if (isBlocked) {
      // When approval/clarify/confirm overlays are active, their own useInput
      // handlers must receive keystrokes (arrow keys, numbers, Enter).  Only
      // intercept Ctrl+C here so the user can deny/dismiss — all other keys
      // fall through to the component-level handlers.
      //
      // Scroll inputs (wheel / PageUp / PageDown / Shift+↑↓) are special:
      // they must reach the transcript scroll handlers below even with a
      // prompt up.  Long-thread context the prompt is asking about often
      // lives above the visible viewport, and being unable to read it while
      // answering felt like the prompt had locked the entire UI.  Explicitly
      // skip the prompt-overlay early-return for scroll keys so they fall
      // through to the wheel / PageUp / Shift+arrow handlers below.
      const promptOverlay =
        overlay.approval || overlay.billing || overlay.clarify || overlay.confirm || overlay.questions

      const fallThroughForScroll = promptOverlay && shouldFallThroughForScroll(key)

      if (promptOverlay && !fallThroughForScroll) {
        if (isCtrl(key, ch, 'c')) {
          cancelOverlayFromCtrlC()
        }

        return
      }

      if (overlay.pager) {
        if (key.escape || isCtrl(key, ch, 'c') || ch === 'q') {
          return patchOverlayState({ pager: null })
        }

        const move = (delta: number | 'top' | 'bottom') =>
          patchOverlayState(prev => {
            if (!prev.pager) {
              return prev
            }

            const { lines, offset } = prev.pager
            const max = Math.max(0, lines.length - pagerPageSize)
            const step = delta === 'top' ? -lines.length : delta === 'bottom' ? lines.length : delta
            const next = Math.max(0, Math.min(offset + step, max))

            return next === offset ? prev : { ...prev, pager: { ...prev.pager, offset: next } }
          })

        if (key.upArrow || ch === 'k') {
          return move(-1)
        }

        if (key.downArrow || ch === 'j') {
          return move(1)
        }

        if (key.pageUp || ch === 'b') {
          return move(-pagerPageSize)
        }

        if (ch === 'g') {
          return move('top')
        }

        if (ch === 'G') {
          return move('bottom')
        }

        if (key.return || ch === ' ' || key.pageDown) {
          patchOverlayState(prev => {
            if (!prev.pager) {
              return prev
            }

            const { lines, offset } = prev.pager
            const max = Math.max(0, lines.length - pagerPageSize)

            // Auto-close only when already at the last page — otherwise clamp
            // to `max` so the offset matches what the line/page-back handlers
            // can reach (prevents a snap-back jump on the next ↑/↓/PgUp).
            return offset >= max
              ? { ...prev, pager: null }
              : { ...prev, pager: { ...prev.pager, offset: Math.min(offset + pagerPageSize, max) } }
          })
        }

        return
      }

      if (isCtrl(key, ch, 'c')) {
        cancelOverlayFromCtrlC()
      } else if (key.escape && overlay.sessions) {
        patchOverlayState({ sessions: false })
      }

      // When a prompt overlay is up and the user pressed a scroll key, fall
      // through to the global scroll handlers below instead of returning.
      // Otherwise nothing above this comment matched, and there's nothing
      // useful to do for an arbitrary key while blocked.
      if (!fallThroughForScroll) {
        return
      }
    }

    if (cState.completions.length && cState.input && cState.historyIdx === null && (key.upArrow || key.downArrow)) {
      const len = cState.completions.length

      cActions.setCompIdx(i => (key.upArrow ? (i - 1 + len) % len : (i + 1) % len))

      return
    }

    if (key.wheelUp || key.wheelDown) {
      const dir: -1 | 1 = key.wheelUp ? -1 : 1
      const now = Date.now()
      // Modifier-held wheel = precision mode: one row per frame, no accel.
      // Smooth mice / trackpads emit tiny same-frame bursts; coalesce those
      // without the old 80ms throttle that made opt-scroll feel stepped.
      // SGR/X10 mouse encoding only carries shift/meta/ctrl bits; Cmd on
      // macOS is intercepted by the terminal, so we honor Option (meta) on
      // Mac / Alt (meta) on Win+Linux / Ctrl as a portable fallback. Shift
      // is reserved for selection extension.
      const hasModifier = key.meta || key.ctrl
      const precision = computePrecisionWheelStep(precisionWheelRef.current, dir, hasModifier, now)

      if (precision.active) {
        // Entering precision mode must discard any accelerated wheel state;
        // otherwise the next normal wheel event inherits stale momentum.
        if (precision.entered) {
          wheelAccelRef.current = initWheelAccelForHost()
        }

        return precision.rows ? scrollTranscript(dir * wheelStep) : undefined
      }

      // 0 = direction-flip bounce deferred; skip the no-op scroll.
      const rows = computeWheelStep(wheelAccelRef.current, dir, now)

      return rows ? scrollTranscript(dir * rows * wheelStep) : undefined
    }

    if (key.shift && key.upArrow) {
      return scrollTranscript(-1)
    }

    if (key.shift && key.downArrow) {
      return scrollTranscript(1)
    }

    if (key.pageUp || key.pageDown) {
      // Half-viewport keeps 50% continuity and stays under Ink's
      // `delta < innerHeight` DECSTBM fast-path threshold.
      const viewport = terminal.scrollRef.current?.getViewportHeight() ?? Math.max(6, (terminal.stdout?.rows ?? 24) - 8)
      const step = Math.max(4, Math.floor(viewport / 2))

      return scrollTranscript(key.pageUp ? -step : step)
    }

    // Escape-based voice bindings (ctrl/alt/super+escape) must win before the
    // generic Esc handlers below; otherwise queue-edit cancel / selection-clear
    // would swallow the chord and /voice would advertise a shortcut that never
    // actually toggles recording in those UI states.
    if (key.escape && isVoiceToggleKey(key, ch, voice.recordKey)) {
      return voiceRecordToggle()
    }

    // Queue-edit cancel beats selection-clear for plain Esc: the queue header
    // explicitly promises "Esc cancel", so honoring it takes priority over the
    // implicit selection-dismissal convention. Without an active edit, fall through.
    if (key.escape && cState.queueEditIdx !== null) {
      return cActions.clearIn()
    }

    if (key.escape && terminal.hasSelection) {
      return clearSelection()
    }

    // Esc dismisses an open completion menu before anything else — the
    // original registers autocomplete as an overlay so its chat:cancel
    // handler defers to the menu (useTypeahead.tsx); a second Esc then
    // interrupts. Without this, Esc would kill the turn out from under a
    // user who is mid-command (or mid-path) in the composer.
    if (key.escape && cState.completions.length) {
      return cActions.dismissCompletions()
    }

    // Esc interrupts the running turn, matching the original's
    // `escape → chat:cancel` binding (defaultBindings.ts / useCancelRequest).
    // NOTE deliberate deviation: the original ALSO binds `ctrl+c →
    // app:interrupt`; Ctrl+C's interrupt/exit roles were removed here per
    // explicit user request (Esc interrupts, /exit exits).
    if (key.escape && live.busy && live.sid) {
      return turnController.interruptTurn({
        appendMessage: actions.appendMessage,
        gw: gateway.gw,
        sid: live.sid,
        sys: actions.sys
      })
    }

    // Esc while IDLE stops a waiting /loop: the interrupt control clears
    // the pending self-paced wakeup backend-side (docs/en/scheduled-tasks
    // §Stop a loop) and its cron_status event confirms in the transcript.
    // Cron jobs scheduled by asking directly are not affected. Only fires
    // when a wakeup is actually pending, so plain Esc stays inert.
    if (key.escape && !live.busy && live.sid && getCronState()?.wakeup) {
      void gateway.gw.request('session.interrupt', { session_id: live.sid }).catch(() => {})

      return
    }

    if (key.upArrow) {
      const inputSel = getInputSelection()
      const cursor = inputSel && inputSel.start === inputSel.end ? inputSel.start : null

      const noLineAbove =
        !cState.input || (cursor !== null && cState.input.lastIndexOf('\n', Math.max(0, cursor - 1)) < 0)

      if (noLineAbove) {
        cycleQueue(1) || cycleHistory(-1)

        return
      }
    }

    if (key.downArrow) {
      const inputSel = getInputSelection()
      const cursor = inputSel && inputSel.start === inputSel.end ? inputSel.start : null
      const noLineBelow = !cState.input || (cursor !== null && cState.input.indexOf('\n', cursor) < 0)

      if (noLineBelow || cState.historyIdx !== null) {
        cycleQueue(-1) || cycleHistory(1)

        return
      }
    }

    if (isCopyShortcut(key, ch)) {
      if (terminal.hasSelection) {
        return copySelection()
      }

      const inputSel = getInputSelection()

      if (inputSel && inputSel.end > inputSel.start) {
        inputSel.clear()

        return
      }

      // On macOS, Cmd+C with no selection is a no-op (Ctrl+C below clears the
      // draft). On non-macOS, isAction uses Ctrl, so fall through to the
      // clear-draft / hint handler.
      if (isMac) {
        return
      }
    }

    if (isCtrl(key, ch, 'x') && cState.queueEditIdx !== null) {
      cActions.removeQueue(cState.queueEditIdx)

      return cActions.clearIn()
    }

    if (isCtrl(key, ch, 'x')) {
      return patchOverlayState({ sessions: true })
    }

    if (key.ctrl && ch.toLowerCase() === 'c') {
      if (cState.input) {
        return cActions.clearIn()
      }

      // Ctrl+C neither interrupts (Esc does) nor exits (/exit does) — a bare
      // press stays harmless so terminal muscle-memory can't kill a live turn
      // or the whole app. Point at the real bindings instead. Dashboard chat
      // gates /exit (core.ts DASHBOARD_EXIT_DISABLED_MESSAGE), so hint /new
      // there.
      const exitHint = DASHBOARD_TUI_MODE ? '/new to start a fresh chat' : '/exit to quit dsh-ccTUI'

      return actions.sys(live.busy ? `esc to interrupt · ${exitHint}` : exitHint)
    }

    if (isAction(key, ch, 'd')) {
      return handleIdleHotkeyExit(actions, DASHBOARD_TUI_MODE, () => {
        gateway.gw.publishLocalEvent({
          payload: { reason: 'idle_exit_hotkey' },
          session_id: live.sid ?? undefined,
          type: 'dashboard.new_session_requested'
        })
      })
    }

    if (isAction(key, ch, 'l')) {
      clearSelection()
      forceRedraw(terminal.stdout ?? process.stdout)

      return
    }

    if (isVoiceToggleKey(key, ch, voice.recordKey)) {
      return voiceRecordToggle()
    }

    // Cmd/Ctrl+G, plus Alt+G fallback for VSCode/Cursor (they bind the
    // primary keystroke to "Find Next" before the TUI sees it; Alt+G
    // arrives as meta+g across platforms).
    if (ch.toLowerCase() === 'g' && (isAction(key, ch, 'g') || key.meta)) {
      return void cActions.openEditor().catch((err: unknown) => {
        actions.sys(err instanceof Error ? `failed to open editor: ${err.message}` : 'failed to open editor')
      })
    }

    // ch13 round-4 — shift+tab CYCLES the permission mode (claude-code
    // parity). The SERVER computes the guarded next mode from the live
    // mode (get_next_permission_mode: bypassPermissions only when
    // available), so the keybinding can never step into "allow everything"
    // in a session that didn't opt into bypass, and never desyncs after
    // /mode. Previously it toggled an unwired `config.set{yolo}` → dead.
    // ctrl+o — the original's "verbose output" toggle. Like the original it is
    // GLOBAL: it drives the same detailsMode /details patches, so expanded also
    // opens thinking/subagent sections. This coupling is intentional (matches
    // CC's single verbose axis); a dedicated tool-only flag was considered and
    // rejected to keep one obvious "show me everything" control.
    if (key.ctrl && ch === 'o') {
      const next = live.detailsMode === 'expanded' ? 'collapsed' : 'expanded'

      patchUiState({ detailsMode: next, detailsModeCommandOverride: false })
      actions.sys(`details: ${next}`)

      return
    }

    // ctrl+t — the original's app:toggleTodos (defaultBindings.ts:43): show or
    // hide the pinned task checklist.
    if (key.ctrl && ch === 't') {
      // Say something even with no list — a silent no-op reads as a dead key.
      if (!getTurnState().todos.length) {
        return actions.sys('tasks: none yet')
      }

      toggleTodoCollapsed()
      actions.sys(`tasks: ${getTurnState().todoCollapsed ? 'hidden' : 'shown'}`)

      return
    }

    if (key.shift && key.tab && !cState.completions.length) {
      if (!live.sid) {
        return void actions.sys('mode needs an active session')
      }

      return void gateway
        .rpc<{ mode?: string }>('permission.cycle', {})
        .then(r => {
          if (r?.mode) {
            patchUiState({ permissionMode: r.mode })
            actions.sys(`permission mode: ${r.mode}`)
          }
        })
    }

    if (key.tab && cState.completions.length) {
      const row = cState.completions[cState.compIdx]

      if (row?.text) {
        const text =
          cState.input.startsWith('/') && row.text.startsWith('/') && cState.compReplace > 0
            ? row.text.slice(1)
            : row.text

        cActions.setInput(cState.input.slice(0, cState.compReplace) + text)
      }

      return
    }

    if (
      shouldAcceptPendingSuggestion(key, {
        busy: live.busy,
        completionsLen: cState.completions.length,
        input: cState.input,
        suggestion: live.pendingSuggestion
      })
    ) {
      // Recap ghost accept: the suggestion becomes real editable input (the
      // external value change snaps TextInput's cursor to the end) and stops
      // being a ghost — Enter from here submits it like any typed prompt.
      cActions.setInput(live.pendingSuggestion ?? '')
      patchUiState({ pendingSuggestion: null })

      return
    }

    if (
      shouldAcceptPlaceholderSuggestion(key, {
        busy: live.busy,
        completionsLen: cState.completions.length,
        conversationEmpty,
        input: cState.input
      })
    ) {
      const query = suggestedQuery(PLACEHOLDER)

      // 'Ask me anything…' carries no query — Tab stays inert. On accept the
      // external value change snaps TextInput's cursor to the end, and a
      // suggested `/command` pops its completion menu exactly as if typed.
      if (query) {
        cActions.setInput(query)
      }

      return
    }

    if (isAction(key, ch, 'k') && cRefs.queueRef.current.length && live.sid) {
      const next = cActions.dequeue()

      if (next) {
        cActions.setQueueEdit(null)
        actions.dispatchSubmission(next)
      }
    }
  })

  return { pagerPageSize }
}
