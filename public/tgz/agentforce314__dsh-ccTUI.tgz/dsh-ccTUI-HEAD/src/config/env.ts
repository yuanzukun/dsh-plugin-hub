import type { MouseTrackingMode } from '@dsh-cctui/ink'

import { isTermuxTuiMode } from '../lib/termux.js'

const truthy = (v?: string) => /^(?:1|true|yes|on)$/i.test((v ?? '').trim())
const falsy = (v?: string) => /^(?:0|false|no|off)$/i.test((v ?? '').trim())

const parseToggle = (v?: string): boolean | null => {
  const raw = (v ?? '').trim()

  if (!raw) {
    return null
  }

  if (truthy(raw)) {
    return true
  }

  if (falsy(raw)) {
    return false
  }

  return null
}

export const TERMUX_TUI_MODE = isTermuxTuiMode()

export const STARTUP_RESUME_ID = (process.env.DSH_CCTUI_RESUME ?? '').trim()
export const STARTUP_QUERY = (process.env.DSH_CCTUI_QUERY ?? '').trim()
export const STARTUP_IMAGE = (process.env.DSH_CCTUI_IMAGE ?? '').trim()

// Mouse tracking mode resolution at startup. Per-mode selection (off|wheel|
// buttons|all) lives in display.mouse_tracking in config.yaml — these env
// vars only set the boot-time default before that config is applied.
//
// Precedence (highest first):
//
// - DSH_CCTUI_MOUSE_TRACKING (truthy/falsy) explicitly overrides everything.
//   This is the "force a value" knob and intentionally beats the legacy
//   kill-switch and the Termux default.
// - DSH_CCTUI_DISABLE_MOUSE=1 forces mouse off — the legacy kill switch.
// - On Termux the default is mouse off so touch selection isn't intercepted
//   by terminal mouse protocols. Desktop defaults to 'all' to preserve prior
//   behavior.
const mouseTrackingOverride = parseToggle(process.env.DSH_CCTUI_MOUSE_TRACKING)
const mouseTrackingDisabledLegacy = truthy(process.env.DSH_CCTUI_DISABLE_MOUSE)

const resolvedBootMouseEnabled = mouseTrackingOverride ?? (TERMUX_TUI_MODE ? false : !mouseTrackingDisabledLegacy)

export const MOUSE_TRACKING: MouseTrackingMode = resolvedBootMouseEnabled ? 'all' : 'off'

export const NO_CONFIRM_DESTRUCTIVE = truthy(process.env.DSH_CCTUI_NO_CONFIRM)

// Set by the dashboard PTY launcher. This is intentionally narrower than
// INLINE_MODE: users can opt into inline terminal rendering locally, but the
// browser-embedded TUI has no healthy restart path after an idle exit.
export const DASHBOARD_TUI_MODE = truthy(process.env.DSH_CCTUI_DASHBOARD)

// DSH_CCTUI_DEV_CREDITS — dev-only live-spend readout (Δ status segment + "(dev credits)"
// banner). Throwaway dev scaffolding; the whole readout gates on this one flag.
export const DEV_CREDITS_MODE = truthy(process.env.DSH_CCTUI_DEV_CREDITS)

const inlineOverride = parseToggle(process.env.DSH_CCTUI_INLINE)

// Skip AlternateScreen — render into the primary buffer so the host terminal's
// native scrollback captures whatever scrolls off the top.
//
// This is the DEFAULT, matching the original Claude Code's inline rendering (the
// transcript stays in your terminal history rather than vanishing on exit).
// Opt into the fullscreen/alternate-screen experience with DSH_CCTUI_INLINE=0.
export const INLINE_MODE = inlineOverride ?? true

// Live FPS counter overlay, fed by ink's onFrame (real render rate, not a
// synthetic timer).
export const SHOW_FPS = truthy(process.env.DSH_CCTUI_FPS)

// Whether the output stream renders color at all (NO_COLOR / FORCE_COLOR=0 /
// TERM=dumb → false). The renderer's chalk does NOT read NO_COLOR itself —
// lib/forceTruecolor.ts translates NO_COLOR into FORCE_COLOR=0 before chalk's
// import, which is what keeps this signal and the renderer's actual output in
// agreement (both honor FORCE_COLOR). The transcript's user-input band is
// pure background color, so monochrome terminals fall back to the textual
// `───` inter-turn separator (domain/blockLayout.ts::showsInterTurnSeparator).
// hasColors is missing on mocked/piped streams in tests — treat that as
// color-capable so the designed band path is the default and the fallback
// stays scoped to explicit no-color terminals.
export const TRANSCRIPT_COLOR: boolean = (() => {
  try {
    return process.stdout.hasColors?.() ?? true
  } catch {
    return true
  }
})()
