import { describe, expect, it } from 'vitest'

import {
  boundedLiveRenderText,
  buildToolTrailLine,
  buildVerboseToolTrailLine,
  edgePreview,
  estimateRows,
  estimateTokensRough,
  fmtK,
  hasAnsi,
  isToolTrailResultLine,
  lastCotTrailIndex,
  parseToolTrailResultLine,
  pasteTokenLabel,
  sameToolTrailGroup,
  sanitizeAnsiForRender,
  splitToolDuration,
  stripAnsi,
  thinkingPreview
} from '../lib/text.js'

describe('isToolTrailResultLine', () => {
  it('detects completion markers', () => {
    expect(isToolTrailResultLine('foo ✓')).toBe(true)
    expect(isToolTrailResultLine('foo ✗')).toBe(true)
    expect(isToolTrailResultLine('drafting x…')).toBe(false)
  })
})

describe('buildToolTrailLine', () => {
  it('omits durations on the tool line (CC parity)', () => {
    const line = buildToolTrailLine('read_file', 'x', false, '', 0.94)

    expect(line).toBe('Read File(x) ✓')
    expect(parseToolTrailResultLine(line)).toEqual({ call: 'Read File(x)', detail: '', mark: '✓' })
    // legacy resumed-session lines still split cleanly
    expect(splitToolDuration('Read File(x) (0.9s)')).toEqual({ label: 'Read File(x)', duration: ' (0.9s)' })
  })

  it('keeps multi-line details intact for the shelf', () => {
    const line = buildToolTrailLine('Bash', 'ls', false, 'a\nb\nc')

    expect(line).toBe('Bash(ls) :: a\nb\nc ✓')
    expect(parseToolTrailResultLine(line)).toEqual({ call: 'Bash(ls)', detail: 'a\nb\nc', mark: '✓' })
  })

  it('caps runaway details at the safety limit', () => {
    const big = Array.from({ length: 40 }, (_, i) => `l${i}`).join('\n')
    const line = buildToolTrailLine('Bash', 'x', false, big)
    const detail = parseToolTrailResultLine(line)!.detail

    // 12 kept + a marker that says how much went, not a bare … that reads as
    // "a bit more" whether three lines were dropped or three hundred
    expect(detail.split('\n')).toHaveLength(13)
    expect(detail.endsWith('… +28 lines')).toBe(true)
  })

  it('reads the truncation marker in the singular when one line went', () => {
    const big = Array.from({ length: 13 }, (_, i) => `l${i}`).join('\n')
    const detail = parseToolTrailResultLine(buildToolTrailLine('Bash', 'x', false, big))!.detail

    expect(detail.endsWith('… +1 line')).toBe(true)
  })

  it('anchors the call/detail split so args containing :: cannot mis-split', () => {
    const line = buildToolTrailLine('Bash', 'echo a :: b', false, 'out')

    expect(parseToolTrailResultLine(line)).toEqual({ call: 'Bash(echo a :: b)', detail: 'out', mark: '✓' })
  })
})

describe('buildVerboseToolTrailLine', () => {
  it('preserves multiline args and result details', () => {
    const line = buildVerboseToolTrailLine(
      'terminal',
      'npm test',
      false,
      1.25,
      '{\n  "cmd": "npm test"\n}',
      'first line\nsecond :: line'
    )

    expect(line).toContain('Args:\n{')
    expect(line).toContain('Result:\nfirst line\nsecond :: line')
    expect(parseToolTrailResultLine(line)).toEqual({
      call: 'Terminal(npm test) (1.3s)',
      detail: 'Args:\n{\n  "cmd": "npm test"\n}\nResult:\nfirst line\nsecond :: line',
      mark: '✓'
    })
  })

  it('labels verbose failures as errors', () => {
    const line = buildVerboseToolTrailLine('terminal', 'npm test', true, 0.5, undefined, 'command failed')

    expect(line).toContain('Error:\ncommand failed')
    expect(line).not.toContain('Result:\ncommand failed')
    expect(parseToolTrailResultLine(line)).toEqual({
      call: 'Terminal(npm test) (0.5s)',
      detail: 'Error:\ncommand failed',
      mark: '✗'
    })
  })

  it('bounds a huge result while still expanding meaningfully (#34095 guard)', () => {
    // A huge result must NOT embed whole — the render block stays bounded
    // (VERBOSE_TRAIL_MAX_*) so a burst can't rebuild the #34095 OOM. Verbose
    // renders only behind ctrl+o, so the budget is a real expansion (~16KB),
    // not the old 800-char glance.
    const huge = 'A'.repeat(40_000)
    const line = buildVerboseToolTrailLine('browser_snapshot', 'https://x.example', false, 2, undefined, huge)

    expect(line).toContain('Result:\n')
    expect(line.length).toBeLessThan(17_000)
    expect(line).toContain('omitted')
    expect(line.endsWith(' ✓')).toBe(true)
  })

  it('keeps the HEAD of a multi-line result, not the tail (#34095 Finding B)', () => {
    // A 500-line result: the reader hitting ctrl+o wants the START of the
    // output (first matches / first error lines), with the rest marked
    // omitted — not the live-stream tail.
    const body = Array.from({ length: 500 }, (_, i) => `line ${i}`).join('\n')
    const line = buildVerboseToolTrailLine('Grep', 'pattern', false, 0.1, undefined, body)

    expect(line).toContain('Result:\nline 0\nline 1')
    expect(line).toContain('line 199') // within the 200-line cap
    expect(line).not.toContain('line 200') // beyond it, dropped
    expect(line).not.toContain('line 499') // tail is NOT what we keep
    // The omitted count reflects the DROPPED suffix (500 − 200 = 300), not the
    // kept head — a constant here would be a lying status line.
    expect(line).toContain('+300 lines omitted')
    expect(line).not.toContain('showing live tail') // the misleading label is gone
  })

  it('reports the true omitted-line count near the cap boundary', () => {
    // 201 lines: exactly one dropped past the 200-line cap.
    const body = Array.from({ length: 201 }, (_, i) => `r${i}`).join('\n')
    const line = buildVerboseToolTrailLine('Bash', 'seq', false, 0.1, undefined, body)

    expect(line).toContain('r199')
    expect(line).not.toContain('r200')
    expect(line).toContain('+1 lines omitted')
  })

  it('does not truncate a result that already fits the preview budget', () => {
    const small = 'ok: 3 files changed'
    const line = buildVerboseToolTrailLine('patch', 'index.html', false, 0.1, undefined, small)

    expect(line).toContain(`Result:\n${small}`)
    expect(line).not.toContain('omitted')
  })
})

describe('lastCotTrailIndex', () => {
  it('finds last non-result line', () => {
    expect(lastCotTrailIndex(['a ✓', 'thinking…'])).toBe(1)
    expect(lastCotTrailIndex(['only result ✓'])).toBe(-1)
  })
})

describe('sameToolTrailGroup', () => {
  it('matches bare check lines', () => {
    expect(sameToolTrailGroup('searching', 'searching ✓')).toBe(true)
    expect(sameToolTrailGroup('searching', 'searching ✗')).toBe(true)
  })

  it('matches contextual lines', () => {
    expect(sameToolTrailGroup('searching', 'searching: * ✓')).toBe(true)
    expect(sameToolTrailGroup('searching', 'searching: foo ✓')).toBe(true)
  })

  it('rejects other tools', () => {
    expect(sameToolTrailGroup('searching', 'reading ✓')).toBe(false)
    expect(sameToolTrailGroup('searching', 'searching extra ✓')).toBe(false)
  })
})

describe('fmtK', () => {
  it('keeps small numbers plain', () => {
    expect(fmtK(999)).toBe('999')
  })

  it('formats thousands as lowercase k', () => {
    expect(fmtK(1000)).toBe('1k')
    expect(fmtK(1500)).toBe('1.5k')
  })

  it('formats millions and billions with lowercase suffixes', () => {
    expect(fmtK(1_000_000)).toBe('1m')
    expect(fmtK(1_000_000_000)).toBe('1b')
  })
})

describe('estimateTokensRough', () => {
  it('uses 4 chars per token rounding up', () => {
    expect(estimateTokensRough('')).toBe(0)
    expect(estimateTokensRough('a')).toBe(1)
    expect(estimateTokensRough('abcd')).toBe(1)
    expect(estimateTokensRough('abcde')).toBe(2)
  })
})

describe('ANSI sanitizers', () => {
  const ESC = String.fromCharCode(27)
  const BEL = String.fromCharCode(7)

  it('strips CSI/OSC/control bytes from plain previews', () => {
    const sample = `A${ESC}[31mB${ESC}[39m${ESC}[2J${ESC}]0;title${BEL}C${ESC}[?25lD`

    expect(stripAnsi(sample)).toBe('ABCD')
  })

  it('strips incomplete CSI prefixes and carriage returns', () => {
    const sample = `A${ESC}[31mB${ESC}[12;${ESC}[CD\rE`

    expect(stripAnsi(sample)).toBe('ABDE')
  })

  it('keeps SGR color spans but removes cursor controls for Ansi rendering', () => {
    const sample = `A${ESC}[31mB${ESC}[39m${ESC}[2J${ESC}]0;title${BEL}${ESC}[?25lC`

    expect(sanitizeAnsiForRender(sample)).toBe(`A${ESC}[31mB${ESC}[39mC`)
  })

  it('keeps valid SGR while removing dangling CSI and carriage returns', () => {
    const sample = `A${ESC}[31mB${ESC}[12;${ESC}[39mC\rD`

    expect(sanitizeAnsiForRender(sample)).toBe(`A${ESC}[31mB${ESC}[39mCD`)
  })

  it('strips multi-byte non-CSI ESC sequences without leaving trailing bytes', () => {
    const sample = `A${ESC}(0B${ESC}%GC${ESC})0D`

    expect(stripAnsi(sample)).toBe('ABCD')
    expect(sanitizeAnsiForRender(sample)).toBe('ABCD')
  })

  it('detects non-CSI escape prefixes too', () => {
    expect(hasAnsi(`ok${ESC}Ppayload${ESC}\\`)).toBe(true)
  })
})

describe('thinkingPreview', () => {
  it('adds paragraph breaks before markdown thinking headings', () => {
    const raw =
      '**Considering user instructions**\nI need to answer.**Planning tool execution**\nI can run tools.**Determining weather search parameters**\nUse SF.'

    expect(thinkingPreview(raw, 'full')).toBe(
      '**Considering user instructions**\nI need to answer.\n\n**Planning tool execution**\nI can run tools.\n\n**Determining weather search parameters**\nUse SF.'
    )
  })
})

describe('boundedLiveRenderText', () => {
  it('preserves short live text verbatim', () => {
    expect(boundedLiveRenderText('one\ntwo', { maxChars: 100, maxLines: 10 })).toBe('one\ntwo')
  })

  it('keeps the live tail by character budget', () => {
    const out = boundedLiveRenderText('abcdefghij', { maxChars: 4, maxLines: 10 })

    expect(out).toContain('ghij')
    expect(out).toContain('omitted')
    expect(out).not.toContain('abcdef')
  })

  it('keeps the live tail by line budget', () => {
    const out = boundedLiveRenderText(['a', 'b', 'c', 'd'].join('\n'), { maxChars: 100, maxLines: 2 })

    expect(out).toContain('c\nd')
    expect(out).toContain('omitted 2 lines')
    expect(out).not.toContain('a\nb')
  })
})

describe('edgePreview', () => {
  it('keeps both ends for long text', () => {
    expect(edgePreview('Vampire Bondage ropes slipped from her neck, still stained with blood', 8, 18)).toBe(
      'Vampire.. stained with blood'
    )
  })
})

describe('pasteTokenLabel', () => {
  it('builds readable long-paste labels with counts', () => {
    const label = pasteTokenLabel('Vampire Bondage ropes slipped from her neck, still stained with blood', 250)
    expect(label.startsWith('[[ ')).toBe(true)
    expect(label).toContain('[250 lines]')
    expect(label.endsWith(' ]]')).toBe(true)
  })
})

describe('estimateRows', () => {
  it('handles tilde code fences', () => {
    const md = ['~~~markdown', '# heading', '~~~'].join('\n')

    expect(estimateRows(md, 40)).toBeGreaterThanOrEqual(2)
  })

  it('handles checklist bullets as list rows', () => {
    const md = ['- [x] done', '- [ ] todo'].join('\n')

    expect(estimateRows(md, 40)).toBe(2)
  })

  it('keeps intraword underscores when sizing snake_case identifiers', () => {
    const w = 80
    const snake = 'look at test_case_with_underscores now'
    const plain = 'look at test case with underscores now'

    expect(estimateRows(snake, w)).toBe(estimateRows(plain, w))
  })
})
