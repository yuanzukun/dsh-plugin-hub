import { describe, expect, it } from 'vitest'

import { approvalAction, approvalOptions } from '../components/prompts.js'

describe('approvalAction — pure key dispatch for ApprovalPrompt', () => {
  it('maps Esc to deny — parity with global Ctrl+C cancellation', () => {
    expect(approvalAction('', { escape: true }, 0)).toEqual({ kind: 'choose', choice: 'deny' })
    expect(approvalAction('', { escape: true }, 2)).toEqual({ kind: 'choose', choice: 'deny' })
  })

  it('maps number keys 1..3 to once/always/deny in registration order', () => {
    expect(approvalAction('1', {}, 0)).toEqual({ kind: 'choose', choice: 'once' })
    expect(approvalAction('2', {}, 0)).toEqual({ kind: 'choose', choice: 'always' })
    expect(approvalAction('3', {}, 0)).toEqual({ kind: 'choose', choice: 'deny' })
    expect(approvalAction('4', {}, 0)).toEqual({ kind: 'noop' })
  })

  it('ignores out-of-range numbers', () => {
    expect(approvalAction('0', {}, 1)).toEqual({ kind: 'noop' })
    expect(approvalAction('5', {}, 1)).toEqual({ kind: 'noop' })
    expect(approvalAction('9', {}, 1)).toEqual({ kind: 'noop' })
  })

  it('confirms the current selection on Enter', () => {
    expect(approvalAction('', { return: true }, 0)).toEqual({ kind: 'choose', choice: 'once' })
    expect(approvalAction('', { return: true }, 2)).toEqual({ kind: 'choose', choice: 'deny' })
  })

  it('moves selection up/down within bounds', () => {
    expect(approvalAction('', { upArrow: true }, 2)).toEqual({ kind: 'move', delta: -1 })
    expect(approvalAction('', { downArrow: true }, 1)).toEqual({ kind: 'move', delta: 1 })
  })

  it('clamps selection movement at the edges', () => {
    expect(approvalAction('', { upArrow: true }, 0)).toEqual({ kind: 'noop' })
    expect(approvalAction('', { downArrow: true }, 2)).toEqual({ kind: 'noop' })
  })

  it('Esc beats numeric/return — denying is always the first interpretation', () => {
    // If a terminal somehow delivers Esc + a digit in the same event, deny
    // wins.  Documents the precedence so a future refactor doesn't flip it.
    expect(approvalAction('1', { escape: true }, 0)).toEqual({ kind: 'choose', choice: 'deny' })
    expect(approvalAction('', { escape: true, return: true }, 1)).toEqual({ kind: 'choose', choice: 'deny' })
  })

  it('returns noop for unrelated keystrokes (printable letters etc.)', () => {
    expect(approvalAction('a', {}, 0)).toEqual({ kind: 'noop' })
    expect(approvalAction(' ', {}, 0)).toEqual({ kind: 'noop' })
  })

  it('offers the persist option for EVERY tool with a suggestion, editable only for Bash', () => {
    // Bash: suggestion with an editable rule → 3 options, editable.
    expect(approvalOptions({ allowPermanent: true, rule: 'git status:*' })).toEqual({
      editable: true,
      opts: ['once', 'always', 'deny']
    })
    // Non-Bash (Write/Read/WebFetch): suggestion but no rule → 3 options, NOT
    // editable (this is the regression that was fixed — the option must appear).
    expect(approvalOptions({ allowPermanent: true, rule: undefined })).toEqual({
      editable: false,
      opts: ['once', 'always', 'deny']
    })
    // No suggestion / tirith warning → 2 options, not editable.
    expect(approvalOptions({ allowPermanent: false, rule: undefined })).toEqual({
      editable: false,
      opts: ['once', 'deny']
    })
  })

  it('respects a reduced option set when permanent allow is disabled', () => {
    // tirith content-security warning (or no suggestion) → no "don't ask again";
    // the 2-item set is once/deny, so 2 maps to deny and 3 is out of range.
    const opts = ['once', 'deny'] as const

    expect(approvalAction('2', {}, 0, opts)).toEqual({ kind: 'choose', choice: 'deny' })
    expect(approvalAction('3', {}, 0, opts)).toEqual({ kind: 'noop' })
    expect(approvalAction('', { downArrow: true }, 1, opts)).toEqual({ kind: 'noop' })
    expect(approvalAction('', { return: true }, 1, opts)).toEqual({ kind: 'choose', choice: 'deny' })
  })
})
