import { describe, expect, it } from 'vitest'

const ENV_KEYS = ['COLORTERM', 'FORCE_COLOR', 'DSH_CCTUI_TRUECOLOR', 'NO_COLOR', 'TERM', 'TERM_PROGRAM'] as const
let importId = 0

async function withCleanEnv(setup: () => void, body: () => Promise<void>) {
  const saved: Record<string, string | undefined> = {}

  for (const k of ENV_KEYS) {
    saved[k] = process.env[k]
    delete process.env[k]
  }

  try {
    setup()
    await body()
  } finally {
    for (const k of ENV_KEYS) {
      if (saved[k] === undefined) {
        delete process.env[k]
      } else {
        process.env[k] = saved[k]
      }
    }
  }
}

describe('forceTruecolor', () => {
  it('does not force truecolor by default', async () => {
    await withCleanEnv(
      () => {},
      async () => {
        await import('../lib/forceTruecolor.js?t=default-' + importId++)
        expect(process.env.COLORTERM).toBeUndefined()
        expect(process.env.FORCE_COLOR).toBeUndefined()
      }
    )
  })

  it('does not infer truecolor from Apple Terminal on pre-Tahoe macOS', async () => {
    await withCleanEnv(
      () => {
        process.env.TERM_PROGRAM = 'Apple_Terminal'
        process.env.TERM = 'xterm-256color'
      },
      async () => {
        const mod = await import('../lib/forceTruecolor.js?t=apple-' + importId++)
        expect(mod.shouldForceTruecolor({ TERM_PROGRAM: 'Apple_Terminal' })).toBe(false)
        expect(process.env.COLORTERM).toBeUndefined()
        expect(process.env.FORCE_COLOR).toBeUndefined()
      }
    )
  })

  it('downgrades Apple Terminal when truecolor is only advertised by env', async () => {
    await withCleanEnv(
      () => {
        process.env.TERM_PROGRAM = 'Apple_Terminal'
        process.env.COLORTERM = 'truecolor'
        process.env.FORCE_COLOR = '3'
      },
      async () => {
        const mod = await import('../lib/forceTruecolor.js?t=downgrade-' + importId++)
        expect(
          mod.shouldDowngradeAppleTerminalTruecolor({
            TERM_PROGRAM: 'Apple_Terminal',
            COLORTERM: 'truecolor',
            FORCE_COLOR: '3'
          } as NodeJS.ProcessEnv)
        ).toBe(true)
        expect(process.env.COLORTERM).toBeUndefined()
        expect(process.env.FORCE_COLOR).toBeUndefined()
      }
    )
  })

  it('keeps non-Apple terminals untouched when they advertise truecolor', async () => {
    await withCleanEnv(
      () => {
        process.env.TERM_PROGRAM = 'vscode'
        process.env.COLORTERM = 'truecolor'
        process.env.FORCE_COLOR = '3'
      },
      async () => {
        const mod = await import('../lib/forceTruecolor.js?t=keep-non-apple-' + importId++)
        expect(
          mod.shouldDowngradeAppleTerminalTruecolor({
            TERM_PROGRAM: 'vscode',
            COLORTERM: 'truecolor',
            FORCE_COLOR: '3'
          } as NodeJS.ProcessEnv)
        ).toBe(false)
        expect(process.env.COLORTERM).toBe('truecolor')
        expect(process.env.FORCE_COLOR).toBe('3')
      }
    )
  })

  it('sets COLORTERM=truecolor and FORCE_COLOR=3 when explicitly enabled', async () => {
    await withCleanEnv(
      () => {
        process.env.DSH_CCTUI_TRUECOLOR = '1'
      },
      async () => {
        await import('../lib/forceTruecolor.js?t=enabled-' + importId++)
        expect(process.env.COLORTERM).toBe('truecolor')
        expect(process.env.FORCE_COLOR).toBe('3')
      }
    )
  })

  it('respects DSH_CCTUI_TRUECOLOR=0 opt-out', async () => {
    await withCleanEnv(
      () => {
        process.env.DSH_CCTUI_TRUECOLOR = '0'
        process.env.TERM_PROGRAM = 'Apple_Terminal'
      },
      async () => {
        await import('../lib/forceTruecolor.js?t=optout-' + importId++)
        expect(process.env.COLORTERM).toBeUndefined()
        expect(process.env.FORCE_COLOR).toBeUndefined()
      }
    )
  })

  it('lets explicit opt-in keep Apple truecolor advertisement', async () => {
    await withCleanEnv(
      () => {
        process.env.TERM_PROGRAM = 'Apple_Terminal'
        process.env.COLORTERM = 'truecolor'
        process.env.FORCE_COLOR = '3'
        process.env.DSH_CCTUI_TRUECOLOR = '1'
      },
      async () => {
        const mod = await import('../lib/forceTruecolor.js?t=apple-explicit-on-' + importId++)
        expect(
          mod.shouldDowngradeAppleTerminalTruecolor({
            TERM_PROGRAM: 'Apple_Terminal',
            COLORTERM: 'truecolor',
            FORCE_COLOR: '3',
            DSH_CCTUI_TRUECOLOR: '1'
          } as NodeJS.ProcessEnv)
        ).toBe(false)
        expect(process.env.COLORTERM).toBe('truecolor')
        expect(process.env.FORCE_COLOR).toBe('3')
      }
    )
  })

  it('respects NO_COLOR — even over the explicit truecolor opt-in', async () => {
    await withCleanEnv(
      () => {
        process.env.NO_COLOR = '1'
        process.env.DSH_CCTUI_TRUECOLOR = '1'
      },
      async () => {
        await import('../lib/forceTruecolor.js?t=no-color-' + importId++)
        expect(process.env.COLORTERM).toBeUndefined()
        // The bundled chalk never checks NO_COLOR itself, so the bootstrap
        // translates it into the FORCE_COLOR=0 channel chalk does honor.
        expect(process.env.FORCE_COLOR).toBe('0')
      }
    )
  })

  it('lets an explicit FORCE_COLOR outrank NO_COLOR', async () => {
    await withCleanEnv(
      () => {
        process.env.NO_COLOR = '1'
        process.env.FORCE_COLOR = '2'
      },
      async () => {
        const mod = await import('../lib/forceTruecolor.js?t=no-color-force-' + importId++)
        expect(mod.shouldSuppressColorForNoColor(process.env)).toBe(false)
        expect(process.env.FORCE_COLOR).toBe('2')
      }
    )
  })

  it('respects existing FORCE_COLOR unless Clawcodex truecolor is explicit', async () => {
    await withCleanEnv(
      () => {
        process.env.FORCE_COLOR = ''
      },
      async () => {
        const mod = await import('../lib/forceTruecolor.js?t=force-color-' + importId++)
        expect(mod.shouldForceTruecolor(process.env)).toBe(false)
        expect(process.env.COLORTERM).toBeUndefined()
        expect(process.env.FORCE_COLOR).toBe('')
      }
    )
  })

  it('lets explicit Clawcodex truecolor override existing FORCE_COLOR', async () => {
    await withCleanEnv(
      () => {
        process.env.FORCE_COLOR = '0'
        process.env.DSH_CCTUI_TRUECOLOR = '1'
      },
      async () => {
        await import('../lib/forceTruecolor.js?t=explicit-force-' + importId++)
        expect(process.env.COLORTERM).toBe('truecolor')
        expect(process.env.FORCE_COLOR).toBe('3')
      }
    )
  })
})
