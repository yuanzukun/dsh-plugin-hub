import { createRequire } from 'node:module'
import { copyFile, mkdtemp, mkdir, readFile, readdir, symlink, writeFile } from 'node:fs/promises'
import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { dirname, join, resolve } from 'node:path'
import { homedir, tmpdir } from 'node:os'
import { pathToFileURL } from 'node:url'

const tarball = process.argv[2]
if (!tarball) throw new Error('用法：node scripts/replay-dsh-install.mjs <tarball>')

const packageName = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8')).name
// 版本事实源取自 version.json：回放脚本不再硬编码 DSH 版本，升级时无需改动。
const versionFile = JSON.parse(await readFile(new URL('../version.json', import.meta.url), 'utf8'))
const expectedDshVersion = versionFile.dshTestedVersion
const expectedCompatibility = versionFile.dshCompatibility
const runtimeDsh = process.env.DSH_RUNTIME_DSH
  ?? '/Applications/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh'
if (!existsSync(runtimeDsh)) throw new Error(`找不到 DSH ${expectedDshVersion} runtime：${runtimeDsh}`)

const home = await mkdtemp(join(tmpdir(), 'dsh-codingns-replay-'))
const profile = join(home, 'profiles', 'replay')
await run(runtimeDsh, ['--profile', 'replay', '--from-default-profile', 'web', '--dump-config'], home)
await run(runtimeDsh, ['plugin', '--profile', 'replay', 'add', resolve(tarball)], home)
const dump = run(runtimeDsh, ['--profile', 'replay', '--dump-config'], home).stdout
await mkdir(join(profile, 'replay-artifacts'), { recursive: true })
await writeFile(join(profile, 'replay-artifacts', 'dump-config.txt'), dump)

const requireFromProfile = createRequire(join(profile, 'package.json'))
const packageJsonPath = requireFromProfile.resolve(`${packageName}/package.json`)
const packageRoot = dirname(packageJsonPath)
const manifest = JSON.parse(await readFile(packageJsonPath, 'utf8'))
if (manifest.version !== JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8')).version) {
  throw new Error(`安装后的包版本不一致：${manifest.version}`)
}
if (manifest.peerDependencies?.['@deepseek-ai/dsh'] !== expectedCompatibility) {
  throw new Error(`安装后的包没有声明与 version.json 一致的 DSH peer ABI：${String(manifest.peerDependencies?.['@deepseek-ai/dsh'])}`)
}
if (!dump.includes(packageName)) throw new Error('Profile dump-config 未包含 CodingNS bundle')

const moduleResolution = []
const runtimeNodeModules = process.env.DSH_RUNTIME_NODE_MODULES
  ?? join(homedir(), `.local/share/codingns/deepseek-harness/${expectedDshVersion}/node_modules`)
const resolutionAnchors = [
  { anchor: join(profile, 'package.json'), source: 'profile' },
  { anchor: join(runtimeNodeModules, '.codingns-replay-anchor.cjs'), source: 'dsh-runtime' },
]
for (const moduleName of manifest.dsh?.client?.inject ?? []) {
  try {
    const resolved = resolvePackageManifest(moduleName, resolutionAnchors)
    if (resolved === undefined) throw new Error(`无法从安装 Profile 或 Desktop DSH runtime 解析 ${moduleName}`)
    const { path, source } = resolved
    const moduleManifest = JSON.parse(await readFile(path, 'utf8'))
    moduleResolution.push({ name: moduleName, version: moduleManifest.version, path, source })
    if (moduleManifest.version !== expectedDshVersion) throw new Error(`${moduleName}@${moduleManifest.version} 不是 ${expectedDshVersion}`)
  } catch (error) {
    moduleResolution.push({ name: moduleName, error: error instanceof Error ? error.message : String(error) })
    throw error
  }
}

// DSH Desktop 的 runtime resolution 会把 peer 包映射到宿主 runtime；CLI 临时 Profile
// 的 Node 进程没有加载该拦截器，因此在回放目录建立同一份只读映射，再导入安装后的 Host。
await linkRuntimePackage('@deepseek-ai/cordis')
// 原生悬浮助理使用宿主路径服务；独立 Node 回放同样需要这份运行时映射。
await linkRuntimePackage('@deepseek-ai/dsh-home-paths')

const hostPath = requireFromProfile.resolve(`${packageName}/host`)
const host = await import(pathToFileURL(hostPath).href)
const rootPath = requireFromProfile.resolve(packageName)
const bundle = await import(pathToFileURL(rootPath).href)
const checks = {}

// 通过实际安装后的 Host bundle 回放 Agent catalog、模型目录及 session/create/follow。
const calls = []
const driver = {
  descriptor: { id: 'replay-agent', name: 'Replay Agent', protocol: 'json-rpc', capabilities: ['models', 'steer'] },
  async detect() { return { installed: true, version: 'replay', command: '/replay-agent' } },
  async listModels() { return { groups: [{ id: 'replay', name: 'Replay', models: [{ id: 'replay-model', name: 'Replay Model', efforts: ['low'] }] }], currentModel: 'replay-model', currentEffort: 'low' } },
  async *executeTurn() { yield { type: 'text', text: 'replay' } },
  async steer(sessionId, prompt) { calls.push(['session/create', sessionId, prompt]) },
  async followUp(sessionId, prompt) { calls.push(['session/follow', sessionId, prompt]) },
}
const registry = new host.CodingNsCliAdapterRegistry([driver])
const catalog = await registry.catalog()
const models = await registry.models('replay-agent')
registry.setSession('replay-session', { adapterId: 'replay-agent', modelId: 'replay-model' })
await registry.steer('replay-session', 'create', false)
await registry.steer('replay-session', 'follow', true)
if (catalog.length !== 1 || catalog[0].id !== 'replay-agent') throw new Error('Agent catalog 回放失败')
if (models.groups?.[0]?.models?.[0]?.id !== 'replay-model') throw new Error('模型列表回放失败')
if (JSON.stringify(calls.map((call) => call[0])) !== JSON.stringify(['session/create', 'session/follow'])) throw new Error('session/create 或 session/follow 回放失败')
checks.agentCatalog = 'passed'
checks.models = 'passed'
checks.sessionCreate = 'passed'
checks.sessionFollow = 'passed'
await registry.dispose()

// 验证 PeerHost 原生 RPC 白名单和虚拟 ID 改写边界。
if (!host.DSH_NATIVE_REMOTE_METHODS.includes('session/create') || !host.DSH_NATIVE_REMOTE_METHODS.includes('session/follow')) throw new Error('PeerHost native RPC 白名单不完整')
const nativeRequest = host.rewriteNativeRequestIds('session/create', { args: { workspaceId: 'virtual-workspace', requestId: 'stable-request' } }, {
  resolveWorkspace(id) { return id === 'virtual-workspace' ? { workspaceId: 'real-workspace', targetHostId: null } : null },
  resolveSession() { return null },
})
if (nativeRequest?.args?.workspaceId !== 'real-workspace' || nativeRequest?.args?.requestId !== 'stable-request') throw new Error('PeerHost native RPC 虚拟 ID 改写失败')
checks.peerHostNativeRpc = 'passed'

class MemoryChannel {
  label = 'codingns-tunnel'
  readyState = 'open'
  bufferedAmount = 0
  peer = null
  listeners = new Map()
  send(data) {
    const bytes = data instanceof ArrayBuffer ? new Uint8Array(data) : new Uint8Array(data.buffer, data.byteOffset, data.byteLength)
    this.peer?.emit('message', { data: new Uint8Array(bytes) })
  }
  close() { this.readyState = 'closed'; this.emit('close', {}) }
  addEventListener(type, listener) { const list = this.listeners.get(type) ?? new Set(); list.add(listener); this.listeners.set(type, list) }
  removeEventListener(type, listener) { this.listeners.get(type)?.delete(listener) }
  emit(type, event) { for (const listener of this.listeners.get(type) ?? []) listener(event) }
}

// 用两个内存 DataChannel 回放 Relay hello 后的数据通道建立，覆盖实际 Carrier 分片入口。
const left = new MemoryChannel()
const right = new MemoryChannel()
left.peer = right
right.peer = left
const clientCarrier = bundle.createDataChannelCarrier(left)
const relayCarrier = bundle.createRelayTunnelHostCarrier(bundle.createDataChannelCarrier(right))
const received = []
relayCarrier.subscribe((value) => received.push(value))
await clientCarrier.send(bundle.encodeTunnelFrame({ type: 'hello', clientContext: null, protocolVersion: '1' }))
await clientCarrier.send(new Uint8Array([0x63, 0x6e, 0x73]))
if (received.length !== 1 || received[0][0] !== 0x63) throw new Error('Relay DataChannel 建立或数据收发失败')
checks.relayDataChannel = 'passed'
await clientCarrier.close()
await relayCarrier.close()

const report = {
  package: packageName,
  version: manifest.version,
  dsh: expectedDshVersion,
  profile,
  packageRoot,
  moduleResolution,
  checks,
}
const reportPath = process.env.DSH_REPLAY_REPORT ?? join(profile, 'replay-artifacts', 'install-replay.json')
await writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`)
console.log(JSON.stringify(report, null, 2))
console.log(`安装回放通过，报告：${reportPath}`)

function run(command, args, cwd) {
  const windowsBatch = process.platform === 'win32' && /\.(?:cmd|bat)$/i.test(command)
  const executable = windowsBatch ? (process.env.ComSpec ?? 'cmd.exe') : command
  const executableArgs = windowsBatch
    ? ['/d', '/s', '/c', `"${[command, ...args].map(quoteWindowsCommandArgument).join(' ')}"`]
    : args
  const result = spawnSync(executable, executableArgs, {
    cwd,
    env: { ...process.env, DSH_HOME: home },
    encoding: 'utf8',
    windowsHide: true,
    windowsVerbatimArguments: windowsBatch,
    timeout: 180_000,
  })
  if (result.status !== 0) {
    throw new Error(`${command} ${args.join(' ')}\n${result.stdout ?? ''}\n${result.stderr ?? ''}`)
  }
  return result
}

function quoteWindowsCommandArgument(value) {
  return `"${String(value).replaceAll('"', '""')}"`
}

function resolvePackageManifest(packageName, anchors) {
  for (const { anchor, source } of anchors) {
    try {
      return { path: createRequire(anchor).resolve(`${packageName}/package.json`), source }
    } catch {
      // Desktop 的 client-modules Loader 会以宿主 DSH runtime 作为外部包解析根。
    }
  }
  const runtimePath = findRuntimePackageManifest(packageName)
  if (runtimePath !== undefined) return { path: runtimePath, source: 'dsh-runtime' }
  return undefined
}

async function linkRuntimePackage(packageName) {
  const target = findRuntimePackageRoot(packageName)
  if (target === undefined) return
  const destination = join(profile, 'node_modules', packageName)
  if (existsSync(destination)) return
  await mkdir(dirname(destination), { recursive: true })
  try {
    await symlink(target, destination, 'dir')
  } catch (error) {
    if (process.platform !== 'win32' || !['EPERM', 'EACCES'].includes(error?.code)) throw error
    await copyDirectory(target, destination)
  }
}

/** Resolve both flat and pnpm virtual-store runtime layouts without mutating the runtime. */
function findRuntimePackageManifest(packageName) {
  const direct = join(runtimeNodeModules, packageName, 'package.json')
  if (existsSync(direct)) return direct
  const store = join(runtimeNodeModules, '.pnpm')
  if (!existsSync(store)) return undefined
  const encoded = packageName.replace('/', '+')
  const candidates = readdirSync(store)
    .filter((entry) => entry.startsWith(`${encoded}@`))
    .map((entry) => join(store, entry, 'node_modules', packageName, 'package.json'))
    .filter((path) => existsSync(path))
  const exact = candidates.find((path) => {
    try { return JSON.parse(readFileSync(path, 'utf8')).version === expectedDshVersion } catch { return false }
  })
  return exact ?? candidates[0]
}

function findRuntimePackageRoot(packageName) {
  const manifest = findRuntimePackageManifest(packageName)
  return manifest === undefined ? undefined : dirname(manifest)
}

async function copyDirectory(source, destination) {
  await mkdir(destination, { recursive: true })
  for (const entry of await readdir(source, { withFileTypes: true })) {
    const from = join(source, entry.name)
    const to = join(destination, entry.name)
    if (entry.isDirectory()) await copyDirectory(from, to)
    else if (entry.isFile()) await copyFile(from, to)
    else throw new Error(`无法复制运行时包中的非普通文件：${from}`)
  }
}
