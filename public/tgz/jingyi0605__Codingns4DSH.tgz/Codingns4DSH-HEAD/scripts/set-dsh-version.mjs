import { readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const nextVersion = process.argv[2]?.trim()
const requestedCompatibility = process.argv[3]?.trim()
const semver = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/u
const compatibilityPattern = /^>=\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/u

/**
 * 上游在某个 DSH 版本中删除、且本仓库无任何 import 的包。
 *
 * 值说明「从哪个版本开始不存在」，仅用于告警文案。这类包不能再被写进 manifest：
 * 版本同步门禁要求所有 `@deepseek-ai/dsh-*` 精确等于测试版本，而该版本在 npm
 * 上并不存在，写进去会让 pnpm install 直接失败。
 */
const UPSTREAM_REMOVED_DSH_PACKAGES = {
  '@deepseek-ai/dsh-invariants': '0.2.1-alpha.1 起上游不再发布，仓库内零引用',
}
if (!nextVersion || !semver.test(nextVersion)) throw new Error('用法: pnpm run version:set-dsh 0.2.1-alpha.1 [兼容范围]')
if (requestedCompatibility !== undefined && !compatibilityPattern.test(requestedCompatibility)) {
  throw new Error('DSH compatibility must declare only a minimum, for example ">=0.2.0-rc.2"; newer hosts receive warnings.')
}

const root = fileURLToPath(new URL('../', import.meta.url))
const readJson = async (relativePath) => JSON.parse(await readFile(join(root, relativePath), 'utf8'))
const writeJson = async (relativePath, value) => {
  await writeFile(join(root, relativePath), `${JSON.stringify(value, null, 2)}\n`)
}

const versionFile = await readJson('version.json')
const previousVersion = versionFile.dshTestedVersion
const previousCompatibility = versionFile.dshCompatibility
const nextCompatibility = requestedCompatibility ?? createDefaultCompatibility(nextVersion, previousCompatibility)
versionFile.dshTestedVersion = nextVersion
versionFile.dshCompatibility = nextCompatibility
await writeJson('version.json', versionFile)

const manifest = await readJson('package.json')
manifest.engines.dsh = nextCompatibility
manifest.peerDependencies ??= {}
manifest.peerDependencies['@deepseek-ai/dsh'] = nextCompatibility
const retiredPackages = []
for (const sectionName of ['dependencies', 'devDependencies']) {
  const section = manifest[sectionName] ?? {}
  for (const name of Object.keys(section)) {
    if (!name.startsWith('@deepseek-ai/dsh-')) continue
    // 上游删除的包不能跟着改版本号：改成一个不存在的版本会让 pnpm install 直接失败。
    // 这类包必须显式登记，由脚本从 manifest 移除并告警，避免每次升级都手工排查。
    if (UPSTREAM_REMOVED_DSH_PACKAGES[name] !== undefined) {
      delete section[name]
      retiredPackages.push(`${name}（${UPSTREAM_REMOVED_DSH_PACKAGES[name]}）`)
      continue
    }
    section[name] = nextVersion
  }
}
await writeJson('package.json', manifest)

const profile = await readJson('profile/package.json')
profile.engines.dsh = nextCompatibility
await writeJson('profile/package.json', profile)
const profileVersion = await readJson('profile/version.json')
profileVersion.dshTestedVersion = nextVersion
profileVersion.dshCompatibility = nextCompatibility
await writeJson('profile/version.json', profileVersion)

const versionPath = join(root, 'src/shared/contracts/version.ts')
const source = await readFile(versionPath, 'utf8')
const updated = source
  .replace(/^(export const DSH_VERSION = ')[^']+(' as const)$/mu, `$1${nextVersion}$2`)
  .replace(/^(export const DSH_COMPATIBILITY = ')[^']+(' as const)$/mu, `$1${nextCompatibility}$2`)
if (updated === source) throw new Error('没有找到 DSH_VERSION 或 DSH_COMPATIBILITY')
await writeFile(versionPath, updated)

for (const relativePath of ['src/dsh-capabilities/matrix.ts', 'src/dsh-capabilities/routes.ts']) {
  const filePath = join(root, relativePath)
  const document = await readFile(filePath, 'utf8')
  const updatedDocument = typeof previousCompatibility === 'string'
    ? document.replaceAll(previousCompatibility, nextCompatibility)
    : document
  if (updatedDocument !== document) await writeFile(filePath, updatedDocument)
}

for (const relativePath of ['README.md', 'README.en.md', 'profile/README.md']) {
  const documentPath = join(root, relativePath)
  const document = await readFile(documentPath, 'utf8')
  let updatedDocument = document
  if (typeof previousVersion === 'string' && previousVersion !== nextVersion) updatedDocument = updatedDocument.replaceAll(previousVersion, nextVersion)
  if (typeof previousCompatibility === 'string' && previousCompatibility !== nextCompatibility) updatedDocument = updatedDocument.replaceAll(previousCompatibility, nextCompatibility)
  if (updatedDocument !== document) await writeFile(documentPath, updatedDocument)
}

console.log(`已将 DSH 测试版本切换为 ${nextVersion}`)
console.log(`当前插件兼容范围: ${nextCompatibility}`)
if (retiredPackages.length > 0) console.log(`已移除上游不再发布的 DSH 包：${retiredPackages.join('、')}`)
console.log('请随后运行 pnpm install --lockfile-only 和 pnpm run version:check')

function createDefaultCompatibility(version, previousCompatibility) {
  const floor = /^>=([^ ]+)/u.exec(previousCompatibility ?? '')?.[1]
  // 未显式传入范围时沿用现有下界，避免版本切换悄悄收紧插件支持范围。
  if (floor !== undefined && semver.test(floor) && compareVersion(floor, version) <= 0) return `>=${floor}`
  return `>=${version}`
}

function compareVersion(left, right) {
  const parse = (value) => {
    const match = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/u.exec(value)
    return match ? [Number(match[1]), Number(match[2]), Number(match[3]), match[4] ?? ''] : undefined
  }
  const a = parse(left); const b = parse(right)
  if (!a || !b) return 0
  for (let index = 0; index < 3; index += 1) if (a[index] !== b[index]) return a[index] - b[index]
  if (!a[3] && b[3]) return 1
  if (a[3] && !b[3]) return -1
  const leftParts = a[3] ? a[3].split('.') : []
  const rightParts = b[3] ? b[3].split('.') : []
  for (let index = 0; index < Math.max(leftParts.length, rightParts.length); index += 1) {
    const leftPart = leftParts[index]
    const rightPart = rightParts[index]
    if (leftPart === undefined) return -1
    if (rightPart === undefined) return 1
    if (leftPart === rightPart) continue
    const leftNumber = /^\d+$/u.test(leftPart)
    const rightNumber = /^\d+$/u.test(rightPart)
    if (leftNumber && rightNumber) return Number(leftPart) - Number(rightPart)
    if (leftNumber) return -1
    if (rightNumber) return 1
    return leftPart < rightPart ? -1 : 1
  }
  return 0
}
