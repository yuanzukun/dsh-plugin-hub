#!/usr/bin/env bash
set -euo pipefail

# Stage0 owns a versioned runtime independent of other DSH installations.
repo_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
dsh_bin=${DSH_STAGE0_LAUNCHER:-"$HOME/.local/share/codingns/deepseek-harness/0.2.2-rc.2/node_modules/@deepseek-ai/dsh/lib/bin.js"}
# Preserve Stage0's existing home. New session events may prevent downgrade.
dsh_home=${DSH_STAGE0_HOME:-"$HOME/.dsh-stage0-020"}
state_dir=${CODINGNS4DSH_STAGE0_STATE_DIR:-"$HOME/.config/codingns4dsh/stage0-020"}
port=${DSH_STAGE0_PORT:-17891}
stage0_patch="$repo_root/dsh-stage0.patch.yml"

if [[ ! -f "$dsh_bin" ]]; then
  printf 'DSH 0.2.2-rc.2 launcher not found: %s\n' "$dsh_bin" >&2
  exit 1
fi

cd "$repo_root"
runtime_env=(
  "DSH_HOME=$dsh_home"
  "CODINGNS4DSH_STATE_DIR=$state_dir"
  "CODINGNS4DSH_PROFILE_NAME=stage0"
  "CODINGNS4DSH_LOGIN_COOKIE_NAME=dsh_codingns_stage0_021"
  "CODINGNS4DSH_STAGE0_REPO_ROOT=$repo_root"
  "CODINGNS4DSH_STAGE0_LAUNCHER=$dsh_bin"
)

# 有一次性迁移出的文件凭据时，stage0 使用它避免依赖 SSH 会话的 macOS 钥匙串；
# 文件不存在时保留 Cursor CLI 默认行为，避免破坏其他登录方式。
if [[ -f "$HOME/.cursor/auth.json" ]]; then
  runtime_env+=("AGENT_CLI_CREDENTIAL_STORE=file")
fi

# DSH 的启动器会在某些路径下自然结束，原来的 `exec` 让调用方只能看到
# shell 提示符，无法知道是正常结束、启动失败还是被信号终止。这里保留一层
# 很薄的等待器，既把信号转发给 DSH，也在退出时报告最终状态。
stage0_child_pid=''
stage0_received_signal=''

forward_stage0_signal() {
  local signal=$1
  stage0_received_signal=$signal
  if [[ -z "$stage0_child_pid" ]]; then return; fi
  if kill -0 "$stage0_child_pid" 2>/dev/null; then
    kill "-$signal" "$stage0_child_pid" 2>/dev/null || true
  fi
}

report_stage0_exit() {
  local exit_code=$1
  if [[ -n "$stage0_received_signal" ]]; then
    printf 'dsh-stage0: DSH 进程退出：退出码 %s（收到信号 SIG%s）\n' \
      "$exit_code" "$stage0_received_signal" >&2
    return
  fi
  if (( exit_code >= 128 )); then
    local signal_number=$((exit_code - 128))
    printf 'dsh-stage0: DSH 进程退出：退出码 %s（可能由信号 %s 终止）\n' \
      "$exit_code" "$signal_number" >&2
    return
  fi
  printf 'dsh-stage0: DSH 进程退出：退出码 %s\n' "$exit_code" >&2
}

trap 'forward_stage0_signal TERM' TERM
trap 'forward_stage0_signal INT' INT

dsh_args=()
# 只有普通启动会占用端口；--dump-config 与 plugin 子命令不监听，无需端口预检。
stage0_serves=1

# Bootstrap only a missing profile. In alpha.3 --from-default-profile can
# overwrite an existing profile, so it must never be repeated on normal startup.
bootstrap_args=()
if [[ ! -f "$dsh_home/profiles/stage0/package.json" ]]; then
  printf '首次启动：在 %s 初始化 stage0 profile（基于内置 web 模板）\n' "$dsh_home" >&2
  bootstrap_args=(--from-default-profile web)
fi

if [[ "${1-}" == "--dump-config" ||
  "${1-}" == "--dump-config-schema" ||
  "${1-}" == "--dump-default-config" ]]; then
  dsh_args=(--profile stage0 --patch "$stage0_patch" "$@")
  stage0_serves=0
  if (( ${#bootstrap_args[@]} > 0 )); then
    dsh_args=("${bootstrap_args[@]}" "${dsh_args[@]}")
  fi
fi

# 插件管理（dsh plugin --profile stage0 …）也必须在当前 Stage0 运行时上执行，参数原样转发。
if [[ "${1-}" == "plugin" ]]; then
  dsh_args=("$@")
  stage0_serves=0
fi

case "${1-}" in
  --help|-h|--version|-v|-V)
    dsh_args=("$@")
    stage0_serves=0 ;;
esac

if (( ${#dsh_args[@]} == 0 )); then
  dsh_args=(--profile stage0 --patch "$stage0_patch" --port "$port" --no-open "$@")
  if (( ${#bootstrap_args[@]} > 0 )); then
    dsh_args=("${bootstrap_args[@]}" "${dsh_args[@]}")
  fi
fi

# 普通启动托管编译监听；只读查询和插件管理不能触发编译。
stage0_watch=${DSH_STAGE0_WATCH:-1}
for argument in "$@"; do
  case "$argument" in
    plugin|--dump-config|--dump-config-schema|--dump-default-config|--help|-h|--version|-v|-V)
      stage0_watch=0 ;;
  esac
done
if [[ "$stage0_watch" != 0 && "$stage0_watch" != 1 ]]; then
  printf 'DSH_STAGE0_WATCH 只接受 0 或 1。\n' >&2
  exit 1
fi

# 端口预检：DSH 只在 webserver 插件监听失败时才抛出 EADDRINUSE，对外表现为
# “必选插件未激活”，并连带一串插件卡在等 webServer / connection 上，很难看出
# 真正原因是端口被上一个遗留实例占用。这里在编译前直接检查并打印占用者。
if (( stage0_serves == 1 )); then
  stage0_port_state=$(node -e '
    const net = require("node:net");
    const server = net.createServer();
    server.once("error", (error) => {
      process.stdout.write(error.code === "EADDRINUSE" ? "in-use" : "unknown");
      process.exit(0);
    });
    server.once("listening", () => server.close(() => {
      process.stdout.write("free");
      process.exit(0);
    }));
    server.listen(Number(process.argv[1]), "127.0.0.1");
  ' "$port" 2>/dev/null || printf 'unknown')

  if [[ "$stage0_port_state" == "in-use" ]]; then
    printf 'stage0 端口 %s 已被占用，DSH 启动后会在插件激活阶段以 EADDRINUSE 失败。\n' "$port" >&2
    stage0_port_owners=''
    if command -v lsof >/dev/null 2>&1; then
      stage0_port_owners=$(lsof -nP -iTCP:"$port" -sTCP:LISTEN 2>/dev/null |
        awk 'NR > 1 { print $2 }' | sort -u | tr '\n' ' ')
    fi
    if [[ -n "${stage0_port_owners// /}" ]]; then
      printf '占用进程 PID: %s\n' "${stage0_port_owners% }" >&2
      for stage0_owner_pid in $stage0_port_owners; do
        # 重定向顺序不能颠倒：先指向 stderr，再把 ps 自身的报错丢弃。
        ps -o pid=,lstart=,command= -p "$stage0_owner_pid" >&2 2>/dev/null || true
      done
      printf '确认该实例无用后终止：kill %s\n' "${stage0_port_owners% }" >&2
    else
      printf '无法识别占用进程，请自查：lsof -nP -iTCP:%s -sTCP:LISTEN\n' "$port" >&2
    fi
    printf '或改用其他端口启动：DSH_STAGE0_PORT=17892 dsh-stage0\n' >&2
    exit 1
  fi
fi

env "${runtime_env[@]}" "CODINGNS4DSH_STAGE0_WATCH=$stage0_watch" \
  node "$repo_root/scripts/stage0-runtime.mjs" "$dsh_bin" "${dsh_args[@]}" &
stage0_child_pid=$!
set +e
wait "$stage0_child_pid"
stage0_exit_code=$?
# wait 被 trap 打断时，仍须等待托管器完成子进程清理。
if [[ -n "$stage0_received_signal" ]]; then
  wait "$stage0_child_pid"
  stage0_exit_code=$?
fi
set -e
trap - TERM INT
report_stage0_exit "$stage0_exit_code"
exit "$stage0_exit_code"
