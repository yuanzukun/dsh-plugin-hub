import { Service, type Context } from '@deepseek-ai/cordis'
import type {
  CodingNsTerminalCreateRequest,
  CodingNsTerminalEnvironment,
  CodingNsTerminalFrame,
  CodingNsTerminalShellOption,
  CodingNsWebTerminalInfo,
  TerminalAttachmentId,
  WebTerminalId,
} from '../../shared/contracts/terminal.js'
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol'
import { debugInfo, debugWarn } from '../../shared/debug.js'
import { resolveCodingNsTranslator, type CodingNsTranslator } from '../locale.js'
import { stripTerminalDeviceAttributeResponses } from '../../shared/terminal-input.js'

export type { TerminalAttachmentId, WebTerminalId } from '../../shared/contracts/terminal.js'
export type TerminalEnvironment = CodingNsTerminalEnvironment
export type TerminalFrame = CodingNsTerminalFrame
export type TerminalShell = CodingNsTerminalShellOption
export type WebTerminalInfo = CodingNsWebTerminalInfo

/** 只描述自有 Client 实际调用的公开 terminal wire 接口。 */
export interface TerminalRemote {
  close(sessionId: string, id: WebTerminalId): Promise<RemoteResult<void>>
  create(sessionId: string, request: CodingNsTerminalCreateRequest, signal?: AbortSignal): Promise<RemoteResult<WebTerminalInfo>>
  environment(sessionId: string, signal?: AbortSignal): Promise<RemoteResult<TerminalEnvironment>>
  follow(sessionId: string, id: WebTerminalId, attachmentId: TerminalAttachmentId, signal?: AbortSignal): AsyncIterable<TerminalFrame>
  list(sessionId: string): Promise<RemoteResult<WebTerminalInfo[]>>
  rename(sessionId: string, id: WebTerminalId, title: string): Promise<RemoteResult<void>>
  resize(sessionId: string, id: WebTerminalId, attachmentId: TerminalAttachmentId, cols: number, rows: number): Promise<RemoteResult<void>>
  shells(sessionId: string, signal?: AbortSignal): Promise<RemoteResult<TerminalShell[]>>
  write(sessionId: string, id: WebTerminalId, attachmentId: TerminalAttachmentId, data: string): Promise<RemoteResult<void>>
}

export type TerminalRemoteSource = TerminalRemote | (() => TerminalRemote | undefined)

export interface TerminalRenderFrame {
  readonly revision: number
  readonly frame: Extract<TerminalFrame, { readonly type: 'snapshot' | 'output' }>
}

export interface TerminalViewState {
  readonly phase: 'idle' | 'loading' | 'creating' | 'connecting' | 'connected' | 'disconnected' | 'closing' | 'closed' | 'failed'
  readonly environment?: TerminalEnvironment
  readonly info?: WebTerminalInfo
  readonly title: string
  readonly writable: boolean
  readonly render?: TerminalRenderFrame
  readonly error?: string
}

export interface TerminalLaunchShells {
  readonly shells: readonly TerminalShell[]
  readonly selectedShell?: string
}

/** 工作区终端库存快照；同一工作区的所有会话共享这份列表。 */
export interface TerminalInventorySnapshot {
  readonly workspaceId: string
  readonly terminals: readonly WebTerminalInfo[]
  readonly revision: number
}

export interface TerminalCloseFailure {
  readonly sessionId: string
  readonly id: WebTerminalId
  readonly title: string
  readonly message: string
}

export interface TerminalObservable<T> {
  getSnapshot(): T
  subscribe(listener: () => void): () => void
}

class ObservableValue<T> implements TerminalObservable<T> {
  private readonly listeners = new Set<() => void>()
  constructor(private value: T) {}
  getSnapshot(): T { return this.value }
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }
  set(value: T): void {
    this.value = value
    for (const listener of [...this.listeners]) listener()
  }
}

interface PendingRender {
  readonly revision: number
  readonly resolve: () => void
}

interface WorkspaceBindingResolution {
  readonly id: WebTerminalId
  /** 是否来自已有工作区绑定；新建绑定仍允许本次 view 创建 Host 终端。 */
  readonly existing: boolean
}

interface TerminalInitialState {
  readonly environment?: TerminalEnvironment
  readonly info?: WebTerminalInfo
}

/** 工作区终端模型；旧单标签视图卸载只 detach，聚合视图常驻 follow 和屏幕。 */
export class CodingNsTerminalView {
  readonly state: TerminalObservable<TerminalViewState>
  id: WebTerminalId
  private readonly store: ObservableValue<TerminalViewState>
  private readonly lifetime = new AbortController()
  /** 屏幕与连接由模型拥有；React 卡片卸载不能结束它们的生命周期。 */
  readonly signal = this.lifetime.signal
  private followController: AbortController | undefined
  private pendingRender: PendingRender | undefined
  private mounted = 0
  private revision = 0
  private loading: Promise<void> | undefined
  private writes = Promise.resolve()
  private attachmentId: TerminalAttachmentId | undefined
  /** 最近一次已排队的尺寸；ResizeObserver 可能在同一布局周期内重复触发。 */
  private lastResize: { readonly attachmentId: TerminalAttachmentId; readonly cols: number; readonly rows: number } | undefined
  private reconnectTimer: ReturnType<typeof setTimeout> | undefined
  private reconnectAttempts = 0
  /**
   * 聚合终端由工作区库存拥有生命周期。
   *
   * 聚合页在切换右栏页签时可能会卸载 DOM，但 Host 里的终端仍然运行；
   * 这类视图不能因为一次 DOM 卸载就释放 follow，否则再次点开标签必然
   * 重新经历 environment/list/follow。显式 close 和 dispose 仍会强制释放。
   */
  private readonly keepAlive: boolean
  private readonly initialState: TerminalInitialState | undefined
  private initialStateConsumed = false

  constructor(
    /** 当前可见卡片的调用上下文；同工作区切换只更新此字段，不替换连接。 */
    public sessionId: string,
    id: WebTerminalId,
    private readonly remote: TerminalRemoteSource,
    private readonly createWhenMissing: boolean,
    private readonly shellPath?: string,
    private readonly onWorkspaceResolved?: (workspaceId: string, id: WebTerminalId) => WorkspaceBindingResolution | undefined,
    // 追加在末尾：既有调用方与测试按位置传 shellPath / onWorkspaceResolved，不能前移。
    private readonly t: CodingNsTranslator = resolveCodingNsTranslator(),
    keepAlive = false,
    initialState?: TerminalInitialState,
  ) {
    this.id = id
    this.keepAlive = keepAlive
    this.initialState = initialState
    // 标签兜底标题必须走词典：字段初始化阶段还取不到构造参数，因此在构造函数里建 store。
    this.store = new ObservableValue<TerminalViewState>({
      phase: initialState?.info === undefined ? 'idle' : 'disconnected',
      ...(initialState?.environment === undefined ? {} : { environment: initialState.environment }),
      ...(initialState?.info === undefined ? {} : { info: initialState.info }),
      title: initialState?.info?.title ?? t('terminal.title'),
      writable: false,
    })
    this.state = this.store
  }

  mount(): () => void {
    this.mounted += 1
    if (this.mounted === 1) {
      const initial = this.initialState
      if (!this.initialStateConsumed && initial?.info !== undefined) {
        this.initialStateConsumed = true
        // 库存快照已经证明终端仍在运行时，直接订阅 Host 常驻连接，
        // 不再为切换会话重新读取 environment/list。环境快照尚未到达时也
        // 可以 follow：environment 只影响输入上限和外观默认值，不能阻塞恢复。
        if (initial.info.state === 'running') this.connect()
        else void this.refresh()
      } else if (!this.resumeFollow()) {
        // 聚合视图在后台（会话或页签不可见）期间保持 follow 连接，重新可见时
        // 若重走 refresh()，load() 会先把状态降级成 loading，而 connect() 又会
        // 因为 followController 仍在而直接返回，终端就会停在“正在读取终端环境”
        // 且输入被禁用，直到恰好产生新输出。这里直接复用已有连接。
        void this.refresh()
      }
    }
    let active = true
    return () => {
      if (!active) return
      active = false
      this.mounted = Math.max(0, this.mounted - 1)
      if (this.mounted === 0 && !this.keepAlive) this.detach()
    }
  }

  /**
   * 重新加载终端环境与库存。
   *
   * 默认复用仍然活跃的 follow 连接：只有连接确实不存在时才向 Host 重新发起
   * environment/list。`force` 供“重新连接/刷新”这类显式动作使用，会先释放
   * 现有 follow 再重建，避免保活连接变成无法恢复的僵尸订阅。
   */
  async refresh(options?: { readonly force?: boolean }): Promise<void> {
    if (this.lifetime.signal.aborted) return
    if (this.loading !== undefined) return this.loading
    if (options?.force === true) {
      this.clearReconnect()
      this.releaseFollow()
    } else if (this.resumeFollow()) return
    this.loading = this.load().finally(() => { this.loading = undefined })
    return this.loading
  }

  /**
   * 运行时丢失后按当前绑定重建终端。
   *
   * 这是"进程已经不存在"时的显式恢复动作：沿用同一个 terminalId 与工作区绑定，
   * 让 Sidebar 标签、标题和尺寸都保持不变，而不是让用户去点"新建终端"。
   */
  async rebuild(): Promise<void> {
    if (this.loading !== undefined) return this.loading
    this.clearReconnect()
    this.reconnectAttempts = 0
    // 重建会替换 Host 终端进程，旧 follow 订阅必须释放；否则 connect() 会认为
    // 连接仍然活跃而直接返回，状态停在 loading。
    this.releaseFollow()
    this.patch({ phase: 'loading', writable: false })
    const task = this.loadWithRebuild().finally(() => { this.loading = undefined })
    this.loading = task
    return task
  }

  private async loadWithRebuild(): Promise<void> {
    try {
      const remote = resolveRemote(this.remote)
      const environment = unwrap(await this.request(remote.environment(this.sessionId, this.lifetime.signal)))
      this.patch({ phase: 'creating', environment })
      const info = unwrap(await this.request(remote.create(this.sessionId, {
        id: this.id,
        ...(this.shellPath === undefined ? {} : { shellPath: this.shellPath }),
        cols: Math.min(80, environment.maxCols),
        rows: Math.min(24, environment.maxRows),
      }, this.lifetime.signal)))
      debugInfo('codingns4dsh: client terminal rebuilt', { sessionId: this.sessionId, terminalId: info.id })
      const { error: _error, ...rest } = this.store.getSnapshot()
      this.store.set({ ...rest, environment, info, title: info.title })
      this.finishLoad()
    } catch (error) {
      if (!this.lifetime.signal.aborted) this.fail(error)
    }
  }

  acknowledge(revision: number): void {
    if (this.pendingRender?.revision !== revision) return
    this.pendingRender.resolve()
    this.pendingRender = undefined
  }

  write(data: string): void {
    data = stripTerminalDeviceAttributeResponses(data)
    if (data === '') return
    const state = this.store.getSnapshot()
    const attachmentId = this.attachmentId
    if (!state.writable || attachmentId === undefined || data === '') return
    const max = state.environment?.maxInputBytes ?? 64 * 1024
    if (new TextEncoder().encode(data).byteLength > max) {
      this.patch({ error: '终端输入超过允许上限' })
      return
    }
    this.writes = this.writes
      .then(async () => { unwrap(await resolveRemote(this.remote).write(this.sessionId, this.id, attachmentId, data)) })
      .catch((error: unknown) => this.fail(error))
  }

  resize(cols: number, rows: number, options?: { readonly force?: boolean }): void {
    const state = this.store.getSnapshot()
    const attachmentId = this.attachmentId
    if (!state.writable || attachmentId === undefined) return
    const nextCols = Math.max(1, Math.min(Math.floor(cols), state.environment?.maxCols ?? 500))
    const nextRows = Math.max(1, Math.min(Math.floor(rows), state.environment?.maxRows ?? 200))
    const request = { attachmentId, cols: nextCols, rows: nextRows }
    // force 用于视图重新可见（激活/回到前台）时夺回尺寸所有权：Host 记录的窗口
    // 尺寸可能已被其它客户端或本客户端更早的宽度改写，只有重发一次当前尺寸才能
    // 让 tmux 与当前视图一致，否则历史行按旧宽度排版，内容会超出容器被裁剪。
    if (options?.force !== true && sameResize(this.lastResize, request)) return
    this.lastResize = request
    this.writes = this.writes
      .then(async () => { unwrap(await resolveRemote(this.remote).resize(this.sessionId, this.id, attachmentId, nextCols, nextRows)) })
      .catch((error: unknown) => {
        if (sameResize(this.lastResize, request)) this.lastResize = undefined
        this.fail(error)
      })
  }

  async rename(title: string): Promise<void> {
    const normalized = title.trim()
    if (normalized === '' || normalized === this.store.getSnapshot().title) return
    try {
      unwrap(await resolveRemote(this.remote).rename(this.sessionId, this.id, normalized))
      const info = this.store.getSnapshot().info
      this.patch({ title: normalized, ...(info === undefined ? {} : { info: { ...info, title: normalized } }) })
    } catch (error) {
      this.fail(error)
    }
  }

  async close(): Promise<void> {
    if (this.store.getSnapshot().phase === 'closed') return
    debugInfo('codingns4dsh: client terminal close entered', { sessionId: this.sessionId, terminalId: this.id })
    this.patch({ phase: 'closing', writable: false })
    this.detach()
    unwrap(await resolveRemote(this.remote).close(this.sessionId, this.id))
    debugInfo('codingns4dsh: client terminal close success', { sessionId: this.sessionId, terminalId: this.id })
    this.patch({ phase: 'closed', writable: false })
  }

  async dispose(): Promise<void> {
    this.lifetime.abort(new Error('终端 Client 已卸载'))
    this.detach()
    await this.writes.catch(() => undefined)
  }

  private async load(): Promise<void> {
    this.patch({ phase: 'loading', writable: false })
    try {
      const remote = resolveRemote(this.remote)
      const environment = unwrap(await this.request(remote.environment(this.sessionId, this.lifetime.signal)))
      debugInfo('codingns4dsh: client terminal environment', { sessionId: this.sessionId, workspaceId: environment.workspaceId, cwd: environment.cwd })
      let createWhenMissing = this.createWhenMissing
      if (environment.workspaceId !== undefined) {
        const binding = this.onWorkspaceResolved?.(environment.workspaceId, this.id)
        debugInfo('codingns4dsh: client terminal workspace binding', { sessionId: this.sessionId, workspaceId: environment.workspaceId, requestedId: this.id, binding: binding ?? null })
        if (binding !== undefined) {
          if (binding.id !== this.id) this.id = binding.id
          // 工作区已有绑定时，恢复必须失败闭合，不能用新 ID 偷建替代终端。
          // 显式传入 terminalId 或读取到会话绑定时同样不能新建：工作区绑定
          // 可能刚被另一个会话的关闭动作删除，此时旧标签仍在卸载途中，不能
          // 把已经关闭的 ID 当成新终端重新 create。
          createWhenMissing = createWhenMissing && !binding.existing
        }
      }
      const listed = unwrap(await this.request(remote.list(this.sessionId)))
      debugInfo('codingns4dsh: client terminal list', { sessionId: this.sessionId, workspaceId: environment.workspaceId, terminalIds: listed.map((entry) => entry.id), requestedId: this.id, createWhenMissing })
      let info = listed.find((entry) => entry.id === this.id)
      if (info === undefined && createWhenMissing) {
        this.patch({ phase: 'creating', environment })
        info = unwrap(await this.request(remote.create(this.sessionId, {
          id: this.id,
          ...(this.shellPath === undefined ? {} : { shellPath: this.shellPath }),
          cols: Math.min(80, environment.maxCols),
          rows: Math.min(24, environment.maxRows),
        }, this.lifetime.signal)))
        debugInfo('codingns4dsh: client terminal created', { sessionId: this.sessionId, workspaceId: environment.workspaceId, terminalId: info.id })
      }
      if (info === undefined) throw new Error('Host 中不存在该终端，且恢复流程禁止自动创建替代进程')
      this.patch({ environment, info, title: info.title })
      this.finishLoad()
    } catch (error) {
      if (!this.lifetime.signal.aborted) this.fail(error)
    }
  }

  /**
   * 加载阶段的 Host 请求等待上限。
   *
   * 页面被浏览器冻结（切到后台）期间发出的请求可能永远不会返回；没有上限时
   * 视图会永久停在“正在读取终端环境”，用户点重试也只会复用同一个挂起 Promise。
   */
  private request<T>(task: Promise<T>): Promise<T> {
    return withLoadTimeout(task, TERMINAL_LOAD_TIMEOUT_MS, this.t('terminalView.loadTimeout'))
  }

  /**
   * 加载完成后的状态收敛。
   *
   * 可见时建立或复用 follow；不可见且没有保活连接时不能停在 loading，否则
   * 切回会话的瞬间会先渲染成“正在读取终端环境”。
   */
  private finishLoad(): void {
    if (this.mounted > 0) {
      this.connect()
      return
    }
    if (this.followController === undefined && this.store.getSnapshot().phase === 'loading') {
      this.patch({ phase: 'disconnected', writable: false })
    }
  }

  private connect(): void {
    if (this.followController !== undefined) {
      // 保活连接仍然存在（例如加载期间用户切回会话）：不重建 follow，但必须
      // 恢复可见状态，否则会停在 load() 设置好的 loading。
      this.resumeFollow()
      return
    }
    if (this.lifetime.signal.aborted || this.mounted === 0) return
    this.clearReconnect()
    const controller = new AbortController()
    this.followController = controller
    this.attachmentId = crypto.randomUUID() as TerminalAttachmentId
    this.lastResize = undefined
    this.patch({ phase: 'connecting', writable: false })
    void this.consume(controller.signal)
  }

  /**
   * 复用仍然活跃的 follow 连接，并恢复可见状态。
   *
   * 聚合视图在后台保活期间连接不会释放，重新可见只是显示层切换，不需要重新
   * 读取环境或库存；把它降级成 loading 会让终端变成只读，且只能等下一次
   * 输出帧才能恢复。
   *
   * @returns 是否复用了已有连接；false 表示必须重新加载。
   */
  private resumeFollow(): boolean {
    const controller = this.followController
    if (controller === undefined || controller.signal.aborted) return false
    const state = this.store.getSnapshot()
    if (state.phase === 'closed' || state.phase === 'failed') return false
    this.clearReconnect()
    if (state.render !== undefined) {
      // 收到过画面说明连接已经建立，重新可见只是显示层切换。
      if (state.phase !== 'connected' || !state.writable) this.patch({ phase: 'connected', writable: true })
    } else if (state.phase !== 'connecting') {
      // 仍在等待 Host 首帧：回到 connecting，避免停在 loading 或只读态。
      this.patch({ phase: 'connecting', writable: false })
    }
    return true
  }

  /** 只释放 follow 连接与附件，不改变对外状态；detach、重建和强制刷新共用。 */
  private releaseFollow(): void {
    this.pendingRender?.resolve()
    this.pendingRender = undefined
    this.followController?.abort(new Error('终端视图重新连接'))
    this.followController = undefined
    this.attachmentId = undefined
    this.lastResize = undefined
  }

  private async consume(signal: AbortSignal): Promise<void> {
    try {
      const attachmentId = this.attachmentId
      if (attachmentId === undefined) return
      for await (const frame of resolveRemote(this.remote).follow(this.sessionId, this.id, attachmentId, signal)) {
        if (signal.aborted) break
        if (frame.type === 'state') {
          this.patch({ info: frame.info, title: frame.info.title })
          continue
        }
        await this.deliver(frame)
      }
      if (!signal.aborted) {
        // 流正常结束但终端仍在运行：这是连接层断开（Host 重连、服务器短暂不可达），
        // 必须自动重连；只有真正结束的终端才停在终态。
        if (this.isRunning()) this.scheduleReconnect()
        else this.patch({ phase: 'disconnected', writable: false })
      }
    } catch (error) {
      if (!signal.aborted) {
        if (this.isRunning()) this.scheduleReconnect()
        else this.fail(error)
      }
    } finally {
      if (this.followController?.signal === signal) {
        this.followController = undefined
        this.attachmentId = undefined
      }
    }
  }

  private async deliver(frame: Extract<TerminalFrame, { readonly type: 'snapshot' | 'output' }>): Promise<void> {
    // 真正收到画面才算连接成功，退避计数在这里归零。
    this.reconnectAttempts = 0
    this.clearReconnect()
    this.pendingRender?.resolve()
    this.revision += 1
    let resolveWaiting = (): void => {}
    const waiting = new Promise<void>((resolve) => { resolveWaiting = resolve })
    this.pendingRender = { revision: this.revision, resolve: resolveWaiting }
    const currentError = this.store.getSnapshot().error
    // Host resident 重连期间的旧 attach 可能短暂拒绝一次输入。收到新连接的
    // 首帧后，控制权已经恢复，这条瞬态错误不能继续盖在可用终端底部；输入上限
    // 等真实校验错误仍保留，避免成功输出把用户的有效提示清掉。
    const recoveredControl = currentError?.includes('当前 attach 没有终端输入控制权') === true
    this.patch({
      phase: 'connected',
      writable: true,
      render: { revision: this.revision, frame },
    })
    if (recoveredControl) this.clearError()
    await waiting
  }

  private detach(): void {
    this.clearReconnect()
    this.releaseFollow()
    if (!this.lifetime.signal.aborted && this.store.getSnapshot().phase !== 'closed') {
      const { render: _render, ...state } = this.store.getSnapshot()
      this.store.set({ ...state, phase: 'disconnected', writable: false })
    }
  }

  /** 终端是否仍被认为在运行；终态（exited/failed/closed）不参与自动重连。 */
  private isRunning(): boolean {
    const state = this.store.getSnapshot()
    if (state.phase === 'closed' || state.phase === 'failed') return false
    if (state.info === undefined) return true
    return state.info.state === 'running'
  }

  /**
   * 恢复阶段 Host 列表为空时，判断当前标签是否仍有本地生命周期保护。
   * 新建终端在 create 完成前不能被恢复流程关闭；已连接且 Host 报告 running
   * 的终端也不能因为一次空列表响应被误判为残留。
   */
  isRecoveryProtected(): boolean {
    const state = this.store.getSnapshot()
    if (state.phase === 'closed' || state.phase === 'failed') return false
    if (this.createWhenMissing && (state.phase === 'idle' || state.phase === 'loading' || state.phase === 'creating')) return true
    return state.info?.id === this.id && state.info.state === 'running'
  }

  /**
   * 连接层断开后的自动重连。
   *
   * 指数退避到 5 秒封顶：DSH 重启、中继抖动或 tmux 服务器短暂不可达时，用户
   * 不需要手动点"重新连接"，也不会看到刷屏式的重试。
   */
  private scheduleReconnect(): void {
    if (this.reconnectTimer !== undefined || this.lifetime.signal.aborted || this.mounted === 0) return
    const delay = Math.min(500 * 2 ** this.reconnectAttempts, 5000)
    this.reconnectAttempts += 1
    this.patch({ phase: 'disconnected', writable: false })
    debugInfo('codingns4dsh: client terminal reconnect scheduled', { sessionId: this.sessionId, terminalId: this.id, delay, attempt: this.reconnectAttempts })
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = undefined
      if (this.lifetime.signal.aborted || this.mounted === 0) return
      void this.refresh()
    }, delay)
  }

  private clearReconnect(): void {
    if (this.reconnectTimer !== undefined) {
      clearTimeout(this.reconnectTimer)
      this.reconnectTimer = undefined
    }
  }

  private patch(patch: Partial<TerminalViewState>): void {
    this.store.set({ ...this.store.getSnapshot(), ...patch })
  }

  private clearError(): void {
    const { error: _error, ...state } = this.store.getSnapshot()
    this.store.set(state)
  }

  private fail(error: unknown): void {
    this.patch({ phase: 'failed', writable: false, error: errorMessage(error) })
  }
}

interface ViewRecord {
  readonly contentId: string
  readonly view: CodingNsTerminalView
  readonly keepAlive: boolean
}

interface CloseRequest {
  readonly sessionId: string
  readonly id: WebTerminalId
  readonly title: string
}

const BINDING_PREFIX = 'dsh.codingns.terminal.binding.v1.'
const CLOSE_REQUEST_KEY = 'dsh.codingns.terminal.close.v1'
const SHELL_KEY = 'dsh.codingns.terminal.shell.v1'
/** 旧版会话级选择记录，仅用于迁移到工作区。 */
const SELECTION_PREFIX = 'dsh.codingns.terminal.selection.v1.'
const WORKSPACE_STATE_PREFIX = 'dsh.codingns.terminal.workspace-state.v1.'

interface TerminalWorkspaceState {
  selectedId?: WebTerminalId
  cardOpen?: boolean
}

/** Codingns4DSH 自有的浏览器终端服务，不依赖官方 terminal-controller Client 实现。 */
export class CodingNsWebTerminals extends Service {
  private readonly views = new Map<string, ViewRecord>()
  private readonly workspaceIds = new Map<string, string>()
  private readonly recoveries = new Map<string, Promise<readonly WebTerminalInfo[]>>()
  private readonly closeFailureStore = new ObservableValue<readonly TerminalCloseFailure[]>([])
  readonly closeFailures: TerminalObservable<readonly TerminalCloseFailure[]> = this.closeFailureStore
  private readonly remoteReadyStore = new ObservableValue(false)
  readonly remoteReadyState: TerminalObservable<boolean> = this.remoteReadyStore
  private readonly inventoryRevisionStore = new ObservableValue(0)
  /** 任一工作区库存变化都会递增；聚合页用它触发跨会话刷新。 */
  readonly inventoryRevision: TerminalObservable<number> = this.inventoryRevisionStore
  private readonly inventories = new Map<string, TerminalInventorySnapshot>()
  /** 库存、选中标签和卡片开关都属于工作区；会话只提供调用上下文。 */
  private readonly workspaceStates = new Map<string, TerminalWorkspaceState>()
  private readonly selectionRevisionStore = new ObservableValue(0)
  readonly selectionRevision: TerminalObservable<number> = this.selectionRevisionStore
  private readonly cardRevisionStore = new ObservableValue(0)
  readonly cardRevision: TerminalObservable<number> = this.cardRevisionStore
  /** 工作区尚未解析时的显式开关意图；解析后必须覆盖旧工作区开关。 */
  private readonly pendingCardStates = new Map<string, boolean>()
  /** 已解析过的会话环境；切换回已有会话时无需再次请求 Host environment。 */
  private readonly environments = new Map<string, TerminalEnvironment>()
  /** 每个会话最近一次库存请求的序号；旧请求返回时不得覆盖新建结果。 */
  private readonly inventoryRequestIds = new Map<string, number>()
  /** 任意工作区刷新都会递增；尚未解析工作区的旧请求也必须随之失效。 */
  private inventoryEpoch = 0
  /** 同一工作区的关闭请求复用一次调用，避免连续点击重复释放同一个模型。 */
  private readonly closingTerminals = new Map<string, Promise<void>>()
  private readonly closeRequests = new Map<string, CloseRequest>()
  /** Remote 注入前不能执行关闭请求；就绪后统一冲刷，避免把启动竞态显示成永久错误。 */
  private cleanupQueued = false

  constructor(ctx: Context, private readonly remote: TerminalRemoteSource, private readonly t: CodingNsTranslator = resolveCodingNsTranslator()) {
    super(ctx, 'webTerminals')
    for (const request of readCloseRequests()) this.closeRequests.set(String(request.id), request)
    void this.flushCleanup()
  }

  view(sessionId: string, key: string, contentId: string, terminalId?: WebTerminalId, shellPath?: string, createFresh = false, persistBinding = true, keepAlive = false, initialState?: TerminalInitialState): CodingNsTerminalView {
    const mapKey = JSON.stringify([keepAlive ? this.scopeForSession(sessionId) : sessionId, key])
    const existing = this.views.get(mapKey)
    if (existing !== undefined) return existing.view
    // 首次创建时可能尚未解析工作区。解析后将原模型移入工作区键，不能再建一条 follow。
    if (keepAlive) {
      for (const [previousKey, record] of this.views) {
        if (!record.keepAlive || record.contentId !== contentId || record.view.id !== terminalId) continue
        if (this.scopeForSession(record.view.sessionId) !== this.scopeForSession(sessionId)) continue
        this.views.delete(previousKey)
        this.views.set(mapKey, record)
        return record.view
      }
    }
    const workspaceId = this.workspaceIds.get(sessionId)
    const sessionBinding = readBinding(sessionId, contentId)
    // “新建”是一次性动作：首次消费标记时忽略工作区单终端绑定，生成新的身份；
    // 标签重载后若已有会话绑定，则恢复刚创建的终端，避免再次创建重复进程。
    const fresh = createFresh && sessionBinding === undefined
    const saved = fresh
      ? terminalId
      : terminalId
        ?? sessionBinding
        ?? (workspaceId === undefined ? undefined : readWorkspaceBindingWithMigration(workspaceId, contentId))
    const id = saved ?? crypto.randomUUID() as WebTerminalId
    debugInfo('codingns4dsh: client terminal view', { sessionId, key, contentId, workspaceId: workspaceId ?? null, savedId: saved ?? null, terminalId: id, bindingSource: terminalId !== undefined ? 'argument' : workspaceId !== undefined && readWorkspaceBindingWithMigration(workspaceId, contentId) !== undefined ? 'workspace-storage' : readBinding(sessionId, contentId) !== undefined ? 'session-storage' : 'new' })
    if (persistBinding && (fresh || saved === undefined)) writeBinding(sessionId, contentId, id)
    const view = new CodingNsTerminalView(
      sessionId,
      id,
      this.remote,
      fresh || saved === undefined,
      shellPath,
      persistBinding
        ? (resolvedWorkspaceId, currentId) => this.rememberWorkspace(sessionId, contentId, currentId, resolvedWorkspaceId, !fresh && terminalId === undefined)
        : (resolvedWorkspaceId) => { this.rememberSessionWorkspace(sessionId, resolvedWorkspaceId); return undefined },
      this.t,
      keepAlive,
      initialState,
    )
    this.views.set(mapKey, { contentId, view, keepAlive })
    return view
  }

  /** 同工作区按 terminalId 复用模型、follow 和屏幕，会话只提供调用上下文。 */
  viewForTerminal(sessionId: string, terminalId: WebTerminalId, shellPath?: string): CodingNsTerminalView {
    const key = `aggregate:${terminalId}`
    const info = this.inventoryForSession(sessionId).find((item) => item.id === terminalId)
    const environment = this.environmentForSession(sessionId)
    const initialState: TerminalInitialState | undefined = info === undefined && environment === undefined
      ? undefined
      : {
        ...(info === undefined ? {} : { info }),
        ...(environment === undefined ? {} : { environment }),
      }
    return this.view(sessionId, key, key, terminalId, shellPath, false, false, true, initialState)
  }

  /** 返回某个 Sidebar 内容已经保存的 Host 终端身份，用于恢复时去重。 */
  boundTerminalId(sessionId: string, contentId: string): WebTerminalId | undefined {
    const workspaceId = this.workspaceIds.get(sessionId)
    return readBinding(sessionId, contentId)
      ?? (workspaceId === undefined ? undefined : readWorkspaceBindingWithMigration(workspaceId, contentId))
  }

  /**
   * 判断恢复阶段是否应保留某个标签。
   *
   * Host 列表为空有两种含义：新建终端的 create 还没有完成，或者 Host 已经
   * 关闭终端而 Sidebar 只剩残留标签。只有当前 Client 视图明确处于创建中或
   * 仍收到 Host 的 running 状态时，空列表才属于前一种情况。
   */
  isTerminalRecoveryProtected(sessionId: string, contentId: string, terminalId: WebTerminalId): boolean {
    for (const record of this.views.values()) {
      if (record.view.sessionId !== sessionId || record.contentId !== contentId) continue
      if (record.view.id !== terminalId) continue
      return record.view.isRecoveryProtected()
    }
    return false
  }

  async launchShells(sessionId: string, signal: AbortSignal): Promise<TerminalLaunchShells> {
    const shells = unwrap(await resolveRemote(this.remote).shells(sessionId, signal))
    const preferred = readString(SHELL_KEY)
    return {
      shells,
      ...(preferred !== null && shells.some((shell) => shell.path === preferred) ? { selectedShell: preferred } : {}),
    }
  }

  selectShell(path: string): void { writeString(SHELL_KEY, path) }

  /** 在聚合页内创建一个新的 Host 终端，并把它加入工作区库存。 */
  async createTerminal(sessionId: string, shellPath?: string): Promise<WebTerminalInfo> {
    // 新建入口表示显式打开；完成时不再写开关，避免覆盖创建期间的关闭动作。
    this.setTerminalCardOpen(sessionId, true)
    const terminalId = crypto.randomUUID() as WebTerminalId
    const view = this.view(sessionId, `aggregate:${terminalId}`, `aggregate:${terminalId}`, terminalId, shellPath, true, false, true)
    await view.refresh()
    const info = view.state.getSnapshot().info
    if (info === undefined) throw new Error(view.state.getSnapshot().error ?? '终端创建失败')
    await this.refreshInventory(sessionId)
    this.selectTerminal(sessionId, info.id)
    return info
  }

  /** 只关闭当前工作区的指定 terminalId，并释放它的常驻屏幕与 follow。 */
  closeTerminal(sessionId: string, terminalId: WebTerminalId): Promise<void> {
    const key = JSON.stringify([this.scopeForSession(sessionId), terminalId])
    const pending = this.closingTerminals.get(key)
    if (pending !== undefined) return pending
    const task = this.closeTerminalInScope(sessionId, terminalId).finally(() => { this.closingTerminals.delete(key) })
    this.closingTerminals.set(key, task)
    return task
  }

  private async closeTerminalInScope(sessionId: string, terminalId: WebTerminalId): Promise<void> {
    const primary = [...this.views.values()].find((record) => record.view.id === terminalId
      && this.scopeForSession(record.view.sessionId) === this.scopeForSession(sessionId))
    if (primary !== undefined) {
      primary.view.sessionId = sessionId
      await primary.view.close()
    } else unwrap(await resolveRemote(this.remote).close(sessionId, terminalId))
    this.finishClose(sessionId, terminalId)
  }

  /** Host 确认关闭即提交本地移除；资源收尾和后续列表查询不能阻塞子标签消失。 */
  private finishClose(sessionId: string, terminalId: WebTerminalId, detachedView?: CodingNsTerminalView): void {
    const records = [...this.views.entries()].filter(([, record]) => record.view.id === terminalId
      && this.scopeForSession(record.view.sessionId) === this.scopeForSession(sessionId))
    this.invalidateWorkspaceInventory(sessionId)
    // 先移除库存再释放屏幕：AbortSignal 会同步触发渲染者清理，不能让它读到旧列表。
    this.rememberInventory(sessionId, this.inventoryForSession(sessionId).filter((item) => item.id !== terminalId))
    const views = new Set(detachedView === undefined ? [] : [detachedView])
    for (const [mapKey, record] of records) {
      this.views.delete(mapKey)
      views.add(record.view)
    }
    // dispose 会同步取消屏幕与 follow，但其旧输入队列可能仍在等待网络响应。
    for (const view of views) void view.dispose().catch((error: unknown) => {
      debugWarn('codingns4dsh: client terminal dispose after close failed', { sessionId, terminalId, error: errorMessage(error) })
    })
    void this.recover(sessionId).catch((error: unknown) => {
      debugWarn('codingns4dsh: client terminal inventory refresh after close failed', { sessionId, terminalId, error: errorMessage(error) })
    })
  }

  close(sessionId: string, key: string, contentId: string, terminalId?: WebTerminalId): void {
    const mapKey = JSON.stringify([sessionId, key])
    const record = this.views.get(mapKey)
    const id = terminalId ?? record?.view.id ?? this.boundTerminalId(sessionId, contentId)
    if (id === undefined) return
    debugInfo('codingns4dsh: client terminal close request', { sessionId, key, contentId, workspaceId: this.workspaceIds.get(sessionId) ?? null, terminalId: id, hasView: record !== undefined })
    const request: CloseRequest = { sessionId, id, title: record?.view.state.getSnapshot().title ?? this.t('terminal.title') }
    this.closeRequests.set(String(id), request)
    persistCloseRequests(this.closeRequests.values())
    deleteBinding(sessionId, contentId)
    const workspaceId = this.workspaceIds.get(sessionId)
    if (workspaceId !== undefined) {
      deleteWorkspaceBindingIfMatches(workspaceId, id)
      deleteLegacyWorkspaceBinding(workspaceId, contentId)
    }
    this.views.delete(mapKey)
    void this.cleanup(request, record?.view)
  }

  async recover(sessionId: string): Promise<readonly WebTerminalInfo[]> {
    const pending = this.recoveries.get(sessionId)
    if (pending !== undefined) return pending
    const requestId = (this.inventoryRequestIds.get(sessionId) ?? 0) + 1
    this.inventoryRequestIds.set(sessionId, requestId)
    const inventoryEpoch = this.inventoryEpoch
    // 官方 list wire 只有 sessionId；先用 agent-scoped environment 让 Host 解析工作区。
    // 使用可选变量避免 TS 将闭包中的自引用判定为“赋值前使用”；
    // Promise 创建后才会执行异步主体，因此运行时仍能安全比较身份。
    let recovery: Promise<readonly WebTerminalInfo[]> | undefined
    recovery = (async () => {
      const environment = await this.resolveEnvironment(sessionId)
      if (environment.workspaceId !== undefined) this.rememberSessionWorkspace(sessionId, environment.workspaceId)
      const result = dedupeInventory(unwrap(await resolveRemote(this.remote).list(sessionId)))
      const currentRequestId = this.inventoryRequestIds.get(sessionId)
      if (currentRequestId !== requestId || this.inventoryEpoch !== inventoryEpoch) {
        // 工作区尚未解析时，刷新方无法提前把这个会话加入失效集合。
        // 旧 list 结果不能交给 Sidebar，否则关闭后的终端会被重新投影出来；
        // 让当前会话重新发起一轮查询，直到拿到刷新后的库存。
        debugInfo('codingns4dsh: client terminal recover stale retry', {
          sessionId,
          terminalIds: result.map((entry) => entry.id),
          requestId,
          currentRequestId,
          inventoryEpoch,
          currentInventoryEpoch: this.inventoryEpoch,
        })
        // 当前请求尚未进入 finally；先移除自身，才能让 retry 创建新一代
        // Promise，而不是再次命中这个仍在执行的旧请求。
        if (recovery !== undefined && this.recoveries.get(sessionId) === recovery) this.recoveries.delete(sessionId)
        return this.recover(sessionId)
      }
      debugInfo('codingns4dsh: client terminal recover', { sessionId, workspaceId: environment.workspaceId, terminalIds: result.map((entry) => entry.id) })
      this.rememberInventory(sessionId, result)
      return result
    })().finally(() => {
      if (recovery !== undefined && this.recoveries.get(sessionId) === recovery) this.recoveries.delete(sessionId)
    })
    this.recoveries.set(sessionId, recovery)
    return recovery
  }

  retryClose(id: WebTerminalId): void {
    const request = this.closeRequests.get(String(id))
    if (request !== undefined) void this.cleanup(request)
  }

  /** 由 Client 的 Remote 注入回调调用，完成启动阶段延迟的关闭请求。 */
  remoteReady(): void {
    debugInfo('codingns4dsh: client terminal remote ready notification')
    this.remoteReadyStore.set(true)
    void this.flushCleanup()
  }

  async dispose(): Promise<void> {
    await Promise.all([...this.views.values()].map((record) => record.view.dispose()))
    this.views.clear()
    this.workspaceIds.clear()
    this.recoveries.clear()
    this.inventories.clear()
    this.workspaceStates.clear()
    this.pendingCardStates.clear()
    this.environments.clear()
    this.inventoryRequestIds.clear()
    this.inventoryEpoch = 0
  }

  /** 强制刷新当前会话对应工作区的库存。 */
  async refreshInventory(sessionId: string): Promise<readonly WebTerminalInfo[]> {
    this.invalidateWorkspaceInventory(sessionId)
    return this.recover(sessionId)
  }

  private invalidateWorkspaceInventory(sessionId: string): void {
    this.inventoryEpoch += 1
    // 聚合页创建/关闭后必须绕过同一工作区所有会话的旧 list 请求；否则
    // 另一个会话的迟到响应仍可能把关闭后的终端写回共享库存。
    const workspaceId = this.workspaceIds.get(sessionId)
    const invalidated = new Set<string>()
    for (const [knownSessionId, knownWorkspaceId] of this.workspaceIds) {
      if (knownSessionId === sessionId || (workspaceId !== undefined && knownWorkspaceId === workspaceId)) {
        invalidated.add(knownSessionId)
      }
    }
    invalidated.add(sessionId)
    for (const knownSessionId of invalidated) this.invalidateRecovery(knownSessionId)
  }

  /** 令指定会话尚未完成的库存请求失效，并清掉可复用的旧 Promise。 */
  private invalidateRecovery(sessionId: string): void {
    this.inventoryRequestIds.set(sessionId, (this.inventoryRequestIds.get(sessionId) ?? 0) + 1)
    this.recoveries.delete(sessionId)
  }

  private async resolveEnvironment(sessionId: string): Promise<TerminalEnvironment> {
    const cached = this.environments.get(`session:${sessionId}`)
    if (cached !== undefined) return cached
    const environment = unwrap(await resolveRemote(this.remote).environment(sessionId))
    this.environments.set(`session:${sessionId}`, environment)
    if (environment.workspaceId !== undefined) this.environments.set(`workspace:${environment.workspaceId}`, environment)
    return environment
  }

  private rememberSessionWorkspace(sessionId: string, workspaceId: string): void {
    this.workspaceIds.set(sessionId, workspaceId)
    const pending = this.pendingCardStates.get(sessionId)
    if (pending === undefined) return
    this.pendingCardStates.delete(sessionId)
    this.setTerminalCardOpen(sessionId, pending)
  }

  private environmentForSession(sessionId: string): TerminalEnvironment | undefined {
    const session = this.environments.get(`session:${sessionId}`)
    if (session !== undefined) return session
    const workspaceId = this.workspaceIds.get(sessionId)
    return workspaceId === undefined ? undefined : this.environments.get(`workspace:${workspaceId}`)
  }

  /** 返回当前会话最近一次拿到的工作区库存；首次加载时为空。 */
  inventoryForSession(sessionId: string): readonly WebTerminalInfo[] {
    const workspaceId = this.workspaceIds.get(sessionId) ?? `session:${sessionId}`
    return this.inventories.get(workspaceId)?.terminals ?? []
  }

  /** 工作区状态使用显式作用域键，旧环境缺少 workspaceId 时才退回会话。 */
  scopeForSession(sessionId: string): string {
    const workspaceId = this.workspaceIds.get(sessionId)
    return JSON.stringify(workspaceId === undefined ? ['session', sessionId] : ['workspace', workspaceId])
  }

  /** 同工作区所有会话读取同一选择；组件卸载和页面刷新不清除记录。 */
  selectedTerminalId(sessionId: string): WebTerminalId | undefined {
    return this.workspaceStateForSession(sessionId).selectedId
  }

  /** 用户选择和库存回退都走同一个入口；存储不可用时仍保留内存记录。 */
  selectTerminal(sessionId: string, id: WebTerminalId | undefined): void {
    const state = this.workspaceStateForSession(sessionId)
    if (state.selectedId === id) return
    const next = { ...state }
    if (id === undefined) delete next.selectedId
    else next.selectedId = id
    this.saveWorkspaceState(sessionId, next)
    this.selectionRevisionStore.set(this.selectionRevisionStore.getSnapshot() + 1)
  }

  /** 卡片是否打开由工作区共享，不由某个会话的布局缺失推断。 */
  terminalCardOpen(sessionId: string): boolean | undefined {
    return this.workspaceStateForSession(sessionId).cardOpen
  }

  setTerminalCardOpen(sessionId: string, open: boolean): void {
    if (!this.workspaceIds.has(sessionId)) this.pendingCardStates.set(sessionId, open)
    const state = this.workspaceStateForSession(sessionId)
    if (state.cardOpen === open) return
    this.saveWorkspaceState(sessionId, { ...state, cardOpen: open })
    this.cardRevisionStore.set(this.cardRevisionStore.getSnapshot() + 1)
  }

  private workspaceStateForSession(sessionId: string): TerminalWorkspaceState {
    const scope = this.scopeForSession(sessionId)
    const current = this.workspaceStates.get(scope)
    if (current !== undefined) return current
    const sessionScope = JSON.stringify(['session', sessionId])
    const legacyKey = `${SELECTION_PREFIX}${JSON.stringify(sessionId)}`
    const legacyId = readString(legacyKey)
    // 工作区记录始终优先；首次解析工作区时迁移尚未绑定工作区的选择与开关。
    const state = readWorkspaceState(scope)
      ?? this.workspaceStates.get(sessionScope)
      ?? readWorkspaceState(sessionScope)
      ?? (legacyId === null ? {} : { selectedId: legacyId })
    this.saveWorkspaceState(sessionId, state)
    if (scope !== sessionScope) {
      this.workspaceStates.delete(sessionScope)
      removeString(`${WORKSPACE_STATE_PREFIX}${sessionScope}`)
      removeString(legacyKey)
    }
    return state
  }

  private saveWorkspaceState(sessionId: string, state: TerminalWorkspaceState): void {
    const scope = this.scopeForSession(sessionId)
    this.workspaceStates.set(scope, state)
    writeString(`${WORKSPACE_STATE_PREFIX}${scope}`, JSON.stringify(state))
  }

  private rememberWorkspace(sessionId: string, contentId: string, id: WebTerminalId, workspaceId: string, useWorkspaceBinding: boolean): WorkspaceBindingResolution {
    this.rememberSessionWorkspace(sessionId, workspaceId)
    // 显式恢复和“新建”都必须保留自己的 terminalId；只有普通无参数入口
    // 才使用旧的单终端工作区绑定兼容行为。
    const existing = useWorkspaceBinding ? readWorkspaceBindingWithMigration(workspaceId, contentId) : undefined
    const resolvedId = existing ?? id
    // 修正首次渲染时已经写入的会话键，避免第二个会话继续携带临时 ID。
    writeBinding(sessionId, contentId, resolvedId)
    if (useWorkspaceBinding) {
      // 旧版本的工作区键带 contentId；统一重写成只含 Workspace ID 的新键。
      writeWorkspaceBinding(workspaceId, contentId, resolvedId)
      deleteLegacyWorkspaceBinding(workspaceId, contentId)
    }
    return { id: resolvedId, existing: existing !== undefined }
  }

  private rememberInventory(sessionId: string, terminals: readonly WebTerminalInfo[]): void {
    const workspaceId = this.workspaceIds.get(sessionId) ?? `session:${sessionId}`
    const normalized = dedupeInventory(terminals)
    const previous = this.inventories.get(workspaceId)
    const changed = previous === undefined || !sameInventory(previous.terminals, normalized)
    const revision = this.inventoryRevisionStore.getSnapshot() + 1
    // 库存先落位再通知选择变化，所有同步订阅者都应看到同一份新列表。
    if (changed) this.inventories.set(workspaceId, { workspaceId, terminals: normalized, revision })
    // 选择与库存使用同一工作区边界；关闭当前终端只需修正一次共享选择。
    const selectedId = this.selectedTerminalId(sessionId)
    if (!normalized.some((item) => item.id === selectedId)) this.selectTerminal(sessionId, normalized[0]?.id)
    if (changed) this.inventoryRevisionStore.set(revision)
  }

  private async cleanup(request: CloseRequest, view?: CodingNsTerminalView): Promise<void> {
    try {
      debugInfo('codingns4dsh: client terminal cleanup begin', { sessionId: request.sessionId, terminalId: request.id, hasView: view !== undefined })
      if (view === undefined) unwrap(await resolveRemote(this.remote).close(request.sessionId, request.id))
      else await view.close()
      debugInfo('codingns4dsh: client terminal cleanup success', { sessionId: request.sessionId, terminalId: request.id })
      this.closeRequests.delete(String(request.id))
      persistCloseRequests(this.closeRequests.values())
      this.closeFailureStore.set(this.closeFailureStore.getSnapshot().filter((item) => item.id !== request.id))
      // 旧 Sidebar 路径也走同一收尾，确保共享库存与已移出缓存的模型一并清理。
      this.finishClose(request.sessionId, request.id, view)
    } catch (error) {
      if (isTerminalRemoteUnavailable(error)) {
        debugInfo('codingns4dsh: client terminal cleanup deferred', { sessionId: request.sessionId, terminalId: request.id })
        return
      }
      debugWarn('codingns4dsh: client terminal cleanup failed', { sessionId: request.sessionId, terminalId: request.id, error: errorMessage(error) })
      const failure: TerminalCloseFailure = { ...request, message: errorMessage(error) }
      this.closeFailureStore.set([...this.closeFailureStore.getSnapshot().filter((item) => item.id !== request.id), failure])
    }
  }

  private async flushCleanup(): Promise<void> {
    if (this.cleanupQueued || this.closeRequests.size === 0) return
    try {
      resolveRemote(this.remote)
    } catch (error) {
      if (isTerminalRemoteUnavailable(error)) {
        debugInfo('codingns4dsh: client terminal cleanup waiting for remote')
        return
      }
      throw error
    }
    this.cleanupQueued = true
    try {
      for (const request of [...this.closeRequests.values()]) await this.cleanup(request)
    } finally {
      this.cleanupQueued = false
    }
  }
}

/** 加载阶段单次 Host 请求的等待上限；超过后按失败处理，用户可以显式重试。 */
const TERMINAL_LOAD_TIMEOUT_MS = 20_000

/**
 * 给加载阶段的请求加等待上限。
 *
 * 页面被浏览器冻结（切到后台）期间发出的请求可能永远不会返回；没有上限时
 * 视图会永久停在“正在读取终端环境”，重试也只会复用同一个挂起的 Promise。
 * 底层请求不保证可取消，因此这里只结束等待，并先给原请求挂上拒绝处理器，
 * 避免它稍后失败时产生 unhandled rejection。
 */
async function withLoadTimeout<T>(task: Promise<T>, timeoutMs: number, message: string): Promise<T> {
  const guarded = task.then(
    (value) => ({ state: 'value' as const, value }),
    (error: unknown) => ({ state: 'error' as const, error }),
  )
  let timer: ReturnType<typeof setTimeout> | undefined
  const expired = new Promise<{ readonly state: 'timeout' }>((resolve) => {
    timer = setTimeout(() => resolve({ state: 'timeout' }), timeoutMs)
  })
  try {
    const outcome = await Promise.race([guarded, expired])
    if (outcome.state === 'value') return outcome.value
    if (outcome.state === 'error') throw outcome.error
    throw new Error(message)
  } finally {
    if (timer !== undefined) clearTimeout(timer)
  }
}

function unwrap<T>(result: RemoteResult<T>): T {
  if (typeof result !== 'object' || result === null || !('ok' in result)) {
    throw new Error('终端服务返回了无效响应')
  }
  if (result.ok) return result.value
  throw result.error
}

/**
 * 终端 Remote 尚未注入时的稳定错误。
 *
 * 调用方按类型判断可用性，不能比较本地化后的 message 文本。
 */
export class TerminalRemoteUnavailableError extends Error {
  constructor() {
    super('终端服务尚未就绪，请稍后重试')
    this.name = 'TerminalRemoteUnavailableError'
  }
}

function resolveRemote(source: TerminalRemoteSource): TerminalRemote {
  const remote = typeof source === 'function' ? source() : source
  if (remote === undefined) throw new TerminalRemoteUnavailableError()
  return remote
}

function sameResize(
  left: { readonly attachmentId: TerminalAttachmentId; readonly cols: number; readonly rows: number } | undefined,
  right: { readonly attachmentId: TerminalAttachmentId; readonly cols: number; readonly rows: number },
): boolean {
  return left?.attachmentId === right.attachmentId && left.cols === right.cols && left.rows === right.rows
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function isTerminalRemoteUnavailable(error: unknown): boolean {
  return error instanceof TerminalRemoteUnavailableError
}

function sameInventory(left: readonly WebTerminalInfo[], right: readonly WebTerminalInfo[]): boolean {
  if (left.length !== right.length) return false
  for (let index = 0; index < left.length; index += 1) {
    const a = left[index]!
    const b = right[index]!
    if (a.id !== b.id || a.title !== b.title || a.cwd !== b.cwd || a.cols !== b.cols || a.rows !== b.rows || a.state !== b.state || a.exitCode !== b.exitCode || a.shell.path !== b.shell.path || a.shell.name !== b.shell.name) return false
  }
  return true
}

/** Host 列表按 terminalId 去重，避免重复记录共享同一个关闭动作。 */
function dedupeInventory(terminals: readonly WebTerminalInfo[]): readonly WebTerminalInfo[] {
  const unique = new Map<WebTerminalId, WebTerminalInfo>()
  for (const terminal of terminals) unique.set(terminal.id, terminal)
  return [...unique.values()]
}

function bindingKey(sessionId: string, contentId: string): string {
  return `${BINDING_PREFIX}${JSON.stringify([sessionId, contentId])}`
}

function workspaceBindingKey(workspaceId: string): string {
  // 工作区模式的终端身份不能带 session、tab 或 contentId；这些值在每个
  // DSH 会话中都会重新生成，带进去就会把所谓的工作区绑定重新拆回会话绑定。
  return `${BINDING_PREFIX}${JSON.stringify(['workspace', workspaceId])}`
}

/** 0.1.7 早期构建把 contentId 写进了工作区键，读取它只用于一次迁移。 */
function legacyWorkspaceBindingKey(workspaceId: string, contentId: string): string {
  return `${BINDING_PREFIX}${JSON.stringify(['workspace', workspaceId, contentId])}`
}

function readBinding(sessionId: string, contentId: string): WebTerminalId | undefined {
  const value = readString(bindingKey(sessionId, contentId))
  return value !== null && /^[\w-]{1,128}$/u.test(value) ? value as WebTerminalId : undefined
}

function writeBinding(sessionId: string, contentId: string, id: WebTerminalId): void {
  writeString(bindingKey(sessionId, contentId), String(id))
}

function readWorkspaceBinding(workspaceId: string, _contentId?: string): WebTerminalId | undefined {
  const value = readString(workspaceBindingKey(workspaceId))
  return value !== null && /^[\w-]{1,128}$/u.test(value) ? value as WebTerminalId : undefined
}

function readWorkspaceBindingWithMigration(workspaceId: string, contentId: string): WebTerminalId | undefined {
  const current = readWorkspaceBinding(workspaceId)
  if (current !== undefined) return current
  const legacy = readString(legacyWorkspaceBindingKey(workspaceId, contentId))
  return legacy !== null && /^[\w-]{1,128}$/u.test(legacy) ? legacy as WebTerminalId : undefined
}

function writeWorkspaceBinding(workspaceId: string, _contentId: string, id: WebTerminalId): void {
  writeString(workspaceBindingKey(workspaceId), String(id))
}

function deleteWorkspaceBinding(workspaceId: string, _contentId?: string): void {
  try { localStorage.removeItem(workspaceBindingKey(workspaceId)) } catch { /* 浏览器禁用存储时仅失去跨刷新绑定。 */ }
}

function deleteWorkspaceBindingIfMatches(workspaceId: string, id: WebTerminalId): void {
  if (readWorkspaceBinding(workspaceId) !== id) return
  deleteWorkspaceBinding(workspaceId)
}

function deleteLegacyWorkspaceBinding(workspaceId: string, contentId: string): void {
  try { localStorage.removeItem(legacyWorkspaceBindingKey(workspaceId, contentId)) } catch { /* 浏览器禁用存储时仅失去跨刷新绑定。 */ }
}

function deleteBinding(sessionId: string, contentId: string): void {
  try { localStorage.removeItem(bindingKey(sessionId, contentId)) } catch { /* 浏览器禁用存储时仅失去跨刷新绑定。 */ }
}

function readCloseRequests(): readonly CloseRequest[] {
  const raw = readString(CLOSE_REQUEST_KEY)
  if (raw === null) return []
  try {
    const values: unknown = JSON.parse(raw)
    if (!Array.isArray(values)) return []
    return values.filter(isCloseRequest)
  } catch {
    return []
  }
}

function isCloseRequest(value: unknown): value is CloseRequest {
  if (typeof value !== 'object' || value === null) return false
  const record = value as Record<string, unknown>
  return typeof record.sessionId === 'string' && typeof record.id === 'string' && typeof record.title === 'string'
}

function persistCloseRequests(requests: Iterable<CloseRequest>): void {
  writeString(CLOSE_REQUEST_KEY, JSON.stringify([...requests]))
}

function readString(key: string): string | null {
  if (typeof localStorage === 'undefined') return null
  try { return localStorage.getItem(key) } catch { return null }
}

function readWorkspaceState(scope: string): TerminalWorkspaceState | undefined {
  const raw = readString(`${WORKSPACE_STATE_PREFIX}${scope}`)
  if (raw === null) return undefined
  try {
    const state: unknown = JSON.parse(raw)
    if (typeof state !== 'object' || state === null) return undefined
    const record = state as Record<string, unknown>
    return {
      ...(typeof record.selectedId === 'string' ? { selectedId: record.selectedId } : {}),
      ...(typeof record.cardOpen === 'boolean' ? { cardOpen: record.cardOpen } : {}),
    }
  } catch { return undefined }
}

function removeString(key: string): void {
  try { localStorage.removeItem(key) } catch { /* 受限环境继续使用内存记录。 */ }
}

function writeString(key: string, value: string): void {
  if (typeof localStorage === 'undefined') return
  try { localStorage.setItem(key, value) } catch { /* 无痕或受限环境继续使用内存状态。 */ }
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    /** Codingns4DSH 自有的浏览器终端模型服务。 */
    webTerminals: CodingNsWebTerminals
  }
}
