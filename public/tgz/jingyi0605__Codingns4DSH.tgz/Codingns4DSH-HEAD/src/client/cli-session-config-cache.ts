import type { CodingNsCliSessionConfig } from '../shared/contracts/cli-adapter.js'
import type { CodingNsRpcClient } from './features/types.js'
import { callCliRpc } from './cli-catalog.js'

/** 会话配置在一次导航期间由多个 Slot 共同读取；共享短期快照即可消除重复 RPC。 */
const SESSION_CONFIG_CACHE_TTL_MS = 5000

interface CacheEntry {
  readonly value: CodingNsCliSessionConfig
  readonly loadedAt: number
}

type Pending = Promise<CodingNsCliSessionConfig>

export interface LoadCliSessionConfigOptions {
  /** 选择器发生变化时跳过短期快照，确保读到当前 Provider/模型。 */
  readonly force?: boolean
}

const caches = new WeakMap<CodingNsRpcClient, Map<string, CacheEntry | Pending>>()
const pendingUpdates = new WeakMap<CodingNsRpcClient, Map<string, Promise<void>>>()

/**
 * 读取会话当前 Agent/模型配置。
 *
 * 同一 RPC 客户端和会话在短时间内只允许一个在途请求；完成后保留 5 秒，
 * 覆盖会话切换时同时挂载的 Agent、订阅和技能组件。写入方可调用 remember
 * 立即替换快照，避免短期缓存覆盖用户刚选择的模型。
 */
export function loadCliSessionConfig(
  rpc: CodingNsRpcClient,
  sessionId: string,
  options: LoadCliSessionConfigOptions = {},
): Promise<CodingNsCliSessionConfig> {
  const normalized = sessionId.trim()
  if (normalized === '') return Promise.resolve({ adapterId: 'dsh' })
  if (updateMapFor(rpc).has(normalized)) {
    return awaitPendingUpdates(rpc, normalized).then(() => loadCliSessionConfigImmediate(rpc, normalized, options))
  }
  return loadCliSessionConfigImmediate(rpc, normalized, options)
}

async function awaitPendingUpdates(rpc: CodingNsRpcClient, normalized: string): Promise<void> {
  const map = updateMapFor(rpc)
  while (true) {
    const pending = map.get(normalized)
    if (pending === undefined) return
    await pending
  }
}

function loadCliSessionConfigImmediate(
  rpc: CodingNsRpcClient,
  normalized: string,
  options: LoadCliSessionConfigOptions,
): Promise<CodingNsCliSessionConfig> {
  const cache = cacheFor(rpc)
  const existing = cache.get(normalized)
  // A forced read follows a model/provider change. Joining an older in-flight
  // request would return the pre-change route and make the first usage lookup
  // select the wrong account; the stale request is ignored by the identity
  // guard below when it eventually settles.
  if (existing instanceof Promise) {
    if (!options.force) return existing
  } else if (!options.force && existing !== undefined && Date.now() - existing.loadedAt < SESSION_CONFIG_CACHE_TTL_MS) {
    return Promise.resolve(existing.value)
  }
  const request = callCliRpc<CodingNsCliSessionConfig>(rpc, 'session/get', { sessionId: normalized })
    .then((value) => {
      // session/set 可能已经把更新后的配置写入缓存；较早的 session/get
      // 返回后不能把新选择回滚成旧 Provider。
      if (cache.get(normalized) === request) cache.set(normalized, { value, loadedAt: Date.now() })
      return value
    })
    .finally(() => {
      if (cache.get(normalized) === request) {
        const current = cache.get(normalized)
        if (current instanceof Promise) cache.delete(normalized)
      }
    })
  cache.set(normalized, request)
  return request
}

/** 登记在途的 session/set，避免强制读取抢先读到切换前的旧模型。 */
export function trackCliSessionConfigUpdate(
  rpc: CodingNsRpcClient,
  sessionId: string,
  promise: Promise<unknown>,
): void {
  const normalized = sessionId.trim()
  if (normalized === '') return
  const map = updateMapFor(rpc)
  const tracked: Promise<void> = promise.then(() => undefined, () => undefined).finally(() => {
    if (map.get(normalized) === tracked) map.delete(normalized)
  })
  map.set(normalized, tracked)
}

/** 用户刚写入 Agent/模型后立即更新共享快照。 */
export function rememberCliSessionConfig(rpc: CodingNsRpcClient, sessionId: string, value: CodingNsCliSessionConfig): void {
  const normalized = sessionId.trim()
  if (normalized === '') return
  cacheFor(rpc).set(normalized, { value, loadedAt: Date.now() })
}

function updateMapFor(rpc: CodingNsRpcClient): Map<string, Promise<void>> {
  let map = pendingUpdates.get(rpc)
  if (map === undefined) {
    map = new Map()
    pendingUpdates.set(rpc, map)
  }
  return map
}

function cacheFor(rpc: CodingNsRpcClient): Map<string, CacheEntry | Pending> {
  let cache = caches.get(rpc)
  if (cache === undefined) {
    cache = new Map()
    caches.set(rpc, cache)
  }
  return cache
}
