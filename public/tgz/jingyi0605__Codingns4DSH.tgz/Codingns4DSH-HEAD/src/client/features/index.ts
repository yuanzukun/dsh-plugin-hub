import type { FeatureRegistry } from '../../features/registry.js'
import type { FeatureUiDescriptor } from '../../shared/contracts/feature.js'
import { lanAccessFeature } from './lan-access.js'
import { reverseProxyFeature } from './reverse-proxy.js'
import { loginProtectionFeature } from './login-protection.js'
import { cliAdaptersFeature } from './cli-adapters.js'
import { magpieManagementFeature } from './magpie-management.js'
import { terminalEnhancementFeature } from './terminal-enhancement.js'
import { workspaceSessionEnhancementFeature } from './workspace-session-enhancement.js'
import { mobileAccessFeature } from './mobile-access.js'
import { debugFeature } from './debug.js'
import { gitManagementFeature } from '../git-management.js'
import { fileManagementFeature } from './file-management.js'
import { quickAppsFeature } from './quick-apps.js'
import { peerHostFeature } from './peer-host.js'
import { subagentCollapsedLineageFeature } from './subagent-collapsed-lineage.js'
import { sessionTranslationFeature } from './session-translation.js'
import { pluginUpdateFeature } from './plugin-update.js'
import { workspaceMcpFeature } from './workspace-mcp.js'
import { credentialsFeature } from './credentials.js'
import type { CodingNsClientFeatureModule, CodingNsClientServices } from './types.js'

/** Client 侧功能模块清单：新增模块在这里登记一行，不需要改动设置页和入口。 */
export const CLIENT_FEATURES: readonly CodingNsClientFeatureModule[] = [
  pluginUpdateFeature,
  workspaceMcpFeature,
  credentialsFeature,
  lanAccessFeature,
  loginProtectionFeature,
  reverseProxyFeature,
  cliAdaptersFeature,
  magpieManagementFeature,
  workspaceSessionEnhancementFeature,
  mobileAccessFeature,
  terminalEnhancementFeature,
  debugFeature,
  gitManagementFeature,
  fileManagementFeature,
  quickAppsFeature,
  peerHostFeature,
  subagentCollapsedLineageFeature,
  sessionTranslationFeature,
]

/** 设置页要显示的一个模块及其界面描述。 */
export interface CodingNsSettingsModule {
  readonly module: CodingNsClientFeatureModule
  readonly ui: FeatureUiDescriptor
}

/**
 * 汇总需要在设置页显示的模块，按 ui.order 升序。
 *
 * 归属 Host 的模块由 Host 侧配置承载，这里跳过；没有 ui 描述的模块不显示。
 */
export function settingsModules(
  registry: FeatureRegistry<CodingNsClientServices, CodingNsClientFeatureModule>,
): readonly CodingNsSettingsModule[] {
  const entries: CodingNsSettingsModule[] = []
  for (const module of registry.modules()) {
    if (module.descriptor.runtime === 'host') continue
    const ui = module.descriptor.ui
    if (ui === undefined) continue
    entries.push({ module, ui })
  }
  entries.sort((left, right) => (left.ui.order ?? 0) - (right.ui.order ?? 0))
  return entries
}

export { lanAccessFeature, loginProtectionFeature, reverseProxyFeature, cliAdaptersFeature, workspaceSessionEnhancementFeature, mobileAccessFeature, terminalEnhancementFeature, debugFeature, gitManagementFeature, fileManagementFeature, peerHostFeature, workspaceMcpFeature }
export { credentialsFeature } from './credentials.js'
export { magpieManagementFeature } from './magpie-management.js'
export { subagentCollapsedLineageFeature } from './subagent-collapsed-lineage.js'
export { sessionTranslationFeature } from './session-translation.js'
export { createPeerHostPageTransport, installPeerHostConnectionRouting } from './peer-host.js'
export { startBrowserRelayConnection } from './reverse-proxy.js'
export { LanAccessPanel } from './lan-access-panel.js'
export { startPeerHostConnectionButton, PEER_HOST_BUTTON_ATTRIBUTE, PEER_HOST_OPEN_EVENT } from '../peer-host-connection-button.js'
export { startPeerHostManagementPanel } from '../peer-host-management-panel.js'
export { createPeerHostManagementApi } from '../peer-host-management-api.js'
export { createPeerHostScopedClient } from '../peer-host-scoped-client.js'
export { createPeerHostWebSocketFactory } from '../peer-host-scoped-client.js'
export { PeerHostSessionController } from '../peer-host-session-controller.js'
export { LoginProtectionPanel } from './login-protection-panel.js'
export { ReverseProxyPanel } from './reverse-proxy-panel.js'
export { CliAdaptersPanel } from './cli-adapters.js'
export { TerminalEnhancementPanel } from './terminal-enhancement-panel.js'
export { WorkspaceSessionEnhancementPanel } from './workspace-session-enhancement-panel.js'
export { MobileAccessPanel } from './mobile-access-panel.js'
export { SubscriptionUsageSettingsDialog } from './subscription-usage-panel.js'
export type {
  CodingNsClientFeatureModule,
  CodingNsClientServices,
  CodingNsRpcClient,
  CodingNsRpcResult,
  FeaturePanelProps,
} from './types.js'
