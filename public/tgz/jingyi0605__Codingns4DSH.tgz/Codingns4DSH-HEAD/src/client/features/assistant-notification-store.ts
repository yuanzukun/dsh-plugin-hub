import type { AssistantNotification, AssistantNotificationClearAllResult, AssistantNotificationSessionTarget, AssistantNotificationSnapshot, AssistantNotificationStreamFrame, AssistantNotificationTarget } from '../../shared/assistant-notifications.js'
import { callCodingNsRpcResult } from '../rpc-call.js'
import type { CodingNsRpcClient } from './types.js'

export interface AssistantNotificationClientSnapshot {
  readonly frame?: AssistantNotificationSnapshot | undefined
  readonly error?: string | undefined
  readonly errorNoticeId?: string | undefined
  readonly errorGeneration?: number | undefined
  readonly loading: boolean
}

const ASSISTANT_NOTIFICATION_STREAM_ENDPOINT = 'codingnsAssistantNotifications/stream'
const STREAM_RETRY_MAX_MS = 30_000

/** 一个读取循环供网页与原生桥共享；所有通知 RPC 串行，配置变化使旧结果立即失效。 */
export class AssistantNotificationStore {
  private snapshot: AssistantNotificationClientSnapshot = { loading: false }
  private readonly listeners = new Set<() => void>()
  private lifetime = new AbortController()
  private epoch = 0
  private key: string | undefined
  private enabled = false
  private disposed = false
  private cursor: string | undefined
  private timer: ReturnType<typeof setTimeout> | undefined
  private deadlineTimer: ReturnType<typeof setTimeout> | undefined
  private chain: Promise<unknown> = Promise.resolve()
  private refreshPromise: Promise<void> | undefined
  private queuedRefresh: Promise<void> | undefined
  private streamMode = false
  private streamPromise: Promise<void> | undefined
  private clockOffset = 0
  private readonly presented = new Set<string>()
  private readonly opens = new Map<string, Promise<void>>()
  private readonly knownNotices = new Map<string, AssistantNotification>()
  /** 最近一次前台选择；串行队列执行前再次校验，避免旧选择晚到时误读新会话。 */
  private sessionSelectionKey: string | undefined

  constructor(private readonly rpc: CodingNsRpcClient,
    private readonly navigate: (target: AssistantNotificationTarget, signal: AbortSignal) => Promise<void>,
    private readonly intervalMs = 750,
    private readonly now: () => number = Date.now) {
    // 页面重新可见时立即校正：完成提示在前台静默，不等待下一次轮询。
    try { if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') document.addEventListener('visibilitychange', this.onVisibilityChange) } catch { /* 非浏览器环境不注册 */ }
  }

  /** 前台可见性只用于完成提示的静默消化，不参与配置 key 或读取循环。 */
  private readonly onVisibilityChange = (): void => { if (!this.disposed && this.enabled && this.pageVisible()) void this.refresh(true) }

  getSnapshot = (): AssistantNotificationClientSnapshot => this.snapshot
  subscribe = (listener: () => void): (() => void) => { this.listeners.add(listener); return () => this.listeners.delete(listener) }

  /** key 包含已创建状态、范围和类型配置；不依赖语音、前台选择或可见性。 */
  configure(enabled: boolean, key: string): void {
    if (this.disposed || (this.enabled === enabled && this.key === key)) return
    this.enabled = enabled; this.key = key; this.epoch++
    this.lifetime.abort(); this.lifetime = new AbortController()
    // 旧流可能要等底层迭代器响应 abort；先释放引用，避免新配置被旧 Promise 阻塞启动。
    this.streamPromise = undefined
    clearTimeout(this.timer); clearTimeout(this.deadlineTimer)
    this.cursor = undefined; this.presented.clear(); this.opens.clear(); this.knownNotices.clear(); this.sessionSelectionKey = undefined
    this.publish({ loading: enabled })
    if (enabled) {
      if (typeof this.rpc.open === 'function') {
        this.streamMode = true
        void this.startStream(this.epoch)
      } else void this.refresh(true)
    } else this.streamMode = false
  }

  /** 翻页与轮询共用读取链，游标失效时回到首页，禁止拼接不同修订的列表。 */
  async page(cursor?: string): Promise<void> {
    this.cursor = cursor
    await this.refresh(true)
  }

  refresh(force = false): Promise<void> {
    if (!this.enabled || this.disposed) return Promise.resolve()
    if (this.refreshPromise !== undefined) {
      if (!force) return this.refreshPromise
      // 多个保存/翻页操作只排一条后续读取；任务开始时使用最新游标与配置。
      this.queuedRefresh ??= this.refreshPromise.then(() => { this.queuedRefresh = undefined; return this.refresh(true) })
      return this.queuedRefresh
    }
    clearTimeout(this.timer)
    const epoch = this.epoch
    const operation = this.enqueue(async (signal) => {
      const previous = this.snapshot.frame
      let result = await this.call<AssistantNotificationSnapshot>('read', {
        ...(force || this.cursor !== undefined || previous === undefined ? {} : { revision: previous.revision }),
        ...(this.cursor === undefined ? {} : { cursor: this.cursor }), limit: 20,
      }, signal)
      this.assertCurrent(epoch, signal)
      // Host 重建可以复用修订号，但不能复用上一代的通知身份和分页内容。
      if (result.unchanged && previous?.generation !== result.generation) {
        result = await this.call<AssistantNotificationSnapshot>('read', { limit: 20 }, signal)
        this.assertCurrent(epoch, signal); this.cursor = undefined
      }
      this.clockOffset = result.serverNow - this.now()
      if (result.unchanged) {
        if (previous !== undefined) this.publishFrame(this.silenceVisibleCompletion({ ...result, items: previous.items }))
        this.scheduleDeadline()
        return
      }
      if (result.reset) this.cursor = undefined
      this.publishFrame(this.silenceVisibleCompletion(result))
      this.scheduleDeadline()
    }, epoch).catch((error: unknown) => {
      if (epoch === this.epoch && !this.disposed && this.enabled) this.publish({ ...this.snapshot, loading: false, error: message(error) })
    }).finally(() => {
      if (this.refreshPromise === operation) this.refreshPromise = undefined
      if (epoch === this.epoch && this.enabled && !this.disposed && !this.streamMode) this.timer = setTimeout(() => { void this.refresh() }, this.intervalMs)
    })
    this.refreshPromise = operation
    return operation
  }

  /** 连接代次内保持一条通知 Remote 流；断线只做一次完整 read 校准再退避重连。 */
  private async startStream(epoch: number): Promise<void> {
    if (this.streamPromise !== undefined) return this.streamPromise
    const operation = this.consumeStream(epoch).finally(() => {
      if (this.streamPromise === operation) this.streamPromise = undefined
    })
    this.streamPromise = operation
    await operation
  }

  private async consumeStream(epoch: number): Promise<void> {
    const open = this.rpc.open
    if (typeof open !== 'function') { this.streamMode = false; await this.refresh(true); return }
    let attempt = 0
    let received = false
    while (this.isCurrent(epoch)) {
      try {
        // DSH Remote 的流参数必须使用唯一的 args 对象；传空对象会被网关判为
        // 非法 payload，随后退回 read 重试，通知就会被退避延迟。
        const stream = open.call(this.rpc, '/api', ASSISTANT_NOTIFICATION_STREAM_ENDPOINT, { args: {} }, this.lifetime.signal)
        received = false
        for await (const raw of stream) {
          this.assertCurrent(epoch, this.lifetime.signal)
          const frame = readStreamFrame(raw)
          if (frame === undefined) continue
          received = true
          this.applyStreamFrame(frame)
        }
        this.assertCurrent(epoch, this.lifetime.signal)
        throw new Error('通知事件流已结束')
      } catch (error) {
        if (!this.isCurrent(epoch) || this.lifetime.signal.aborted) return
        if (!received && isUnsupportedStreamError(error)) {
          // 旧版 Host 没有通知流时保留旧 RPC 行为，避免升级 Client 后通知静默失效。
          this.streamMode = false
          await this.refresh(true)
          return
        }
        // 一次重连只做一次校准；校准期间不启动旧的定时器。
        await this.refresh(true)
        const delay = Math.min(STREAM_RETRY_MAX_MS, 1_000 * 2 ** Math.min(attempt++, 5))
        await wait(delay, this.lifetime.signal)
      }
    }
  }

  private applyStreamFrame(frame: AssistantNotificationStreamFrame): void {
    const previous = this.snapshot.frame
    if (previous !== undefined && frame.snapshot.generation === previous.generation && frame.snapshot.revision <= previous.revision) return
    this.cursor = undefined
    this.publishFrame(this.silenceVisibleCompletion(frame.snapshot))
    this.scheduleDeadline()
  }

  private isCurrent(epoch: number): boolean {
    return epoch === this.epoch && this.enabled && !this.disposed
  }

  async acknowledge(noticeId: string, generation: number, action: 'presented' | 'collapse' | 'dismiss', expectedKind?: AssistantNotification['kind'], expectedConnectionGeneration?: number): Promise<void> {
    const epoch = this.epoch
    this.requireFrame(generation)
    const notice = this.knownNotices.get(noticeId)
    // 同轮完成升级成错误时重新首展；旧原生帧的确认不能替新错误启动计时。
    if (action === 'presented' && expectedKind !== undefined && notice?.kind !== expectedKind) return
    const key = JSON.stringify([generation, noticeId, notice?.kind, notice?.createdAt])
    if (action === 'presented' && this.presented.has(key)) return
    await this.enqueue(async (signal) => {
      if (action === 'presented' && expectedKind !== undefined && this.knownNotices.get(noticeId)?.kind !== expectedKind) return
      if (action === 'presented' && this.presented.has(key)) return
      await this.call('ack', { noticeId, generation, action,
        ...((expectedConnectionGeneration ?? notice?.connectionGeneration) === undefined ? {} : { connectionGeneration: expectedConnectionGeneration ?? notice?.connectionGeneration }),
        ...(action === 'presented' && (expectedKind ?? notice?.kind) !== undefined ? { kind: expectedKind ?? notice?.kind } : {}) }, signal)
      this.assertCurrent(epoch, signal)
      if (action === 'presented') {
        this.presented.add(key)
        // 旧确认重试由 Host 首展记录保证幂等，客户端不需要无限保存历史 ID。
        while (this.presented.size > 256) this.presented.delete(this.presented.values().next().value!)
      }
      if (action === 'dismiss' && this.snapshot.errorNoticeId === noticeId) this.publish({ ...this.snapshot, error: undefined, errorNoticeId: undefined, errorGeneration: undefined })
    }, epoch).catch((error: unknown) => {
      if (epoch === this.epoch && this.enabled && !this.disposed) this.publish({ ...this.snapshot, error: message(error), errorNoticeId: noticeId, errorGeneration: generation })
      throw error
    })
    // 不复用写入前的在途快照。单条清理只修改提醒展示，从不提交原生问题或审批。
    await this.refresh(true)
  }

  /** 一键清理只清空当前代次的气泡展示；DSH 侧未读、待处理与请求身份都由 Host 原样保留。 */
  async clearAll(generation: number): Promise<void> {
    const epoch = this.epoch
    this.requireFrame(generation)
    await this.enqueue(async (signal) => {
      await this.call<AssistantNotificationClearAllResult>('clear-all', { generation }, signal)
      this.assertCurrent(epoch, signal)
    }, epoch).catch((error: unknown) => {
      if (epoch === this.epoch && this.enabled && !this.disposed) this.publish({ ...this.snapshot, error: message(error), errorNoticeId: undefined, errorGeneration: undefined })
      throw error
    })
    await this.refresh(true)
  }

  /** 当前会话一旦被 DSH 选中即提交会话级已读；空选择只取消尚未发出的旧选择。 */
  markSessionRead(target: AssistantNotificationSessionTarget | undefined): Promise<void> {
    const key = target === undefined ? undefined : JSON.stringify([target.hostId, target.workspaceId, target.sessionId])
    this.sessionSelectionKey = key
    if (target === undefined || !this.enabled || this.disposed) return Promise.resolve()
    if (this.snapshot.frame === undefined) {
      // 首次选择可能早于通知首帧；等首帧到达后仍确认这是最近一次选择，避免旧选择越过新选择。
      return this.refresh(true).then(() => this.sessionSelectionKey === key ? this.markSessionRead(target) : undefined)
    }
    const epoch = this.epoch
    const operation = this.enqueue(async (signal) => {
      if (this.sessionSelectionKey !== key) return
      const frame = this.snapshot.frame
      if (frame === undefined) return
      await this.call('read-session', { generation: frame.generation, ...target }, signal)
      this.assertCurrent(epoch, signal)
    }, epoch).then(() => this.refresh(true)).catch((error: unknown) => {
      if (epoch === this.epoch && this.enabled && !this.disposed) this.publish({ ...this.snapshot, error: message(error) })
      throw error
    })
    return operation
  }

  /** 查看由 Host 返回可信目标，公开导航成功后才标记已读。 */
  open(noticeId: string, generation: number, expectedConnectionGeneration?: number): Promise<void> {
    try { this.requireFrame(generation) } catch (error) { return Promise.reject(error) }
    const notice = this.knownNotices.get(noticeId)
    // 原生独立分页可能展示网页尚未缓存的 ID；目标存在与权限由认证接口复核。
    const connectionGeneration = expectedConnectionGeneration ?? notice?.connectionGeneration
    const key = JSON.stringify([generation, noticeId, connectionGeneration])
    const previous = this.opens.get(key)
    if (previous !== undefined) return previous
    const epoch = this.epoch
    const operation = this.enqueue(async (signal) => {
      const target = await this.call<AssistantNotificationTarget>('target', { noticeId, generation,
        ...(connectionGeneration === undefined ? {} : { connectionGeneration }) }, signal)
      this.assertCurrent(epoch, signal)
      await this.navigate(target, signal)
      this.assertCurrent(epoch, signal)
      await this.call('ack', { noticeId, generation, action: 'read',
        ...(target.connectionGeneration === undefined ? {} : { connectionGeneration: target.connectionGeneration }) }, signal)
      if (this.snapshot.errorNoticeId === noticeId) this.publish({ ...this.snapshot, error: undefined, errorNoticeId: undefined, errorGeneration: undefined })
    }, epoch).then(() => this.refresh(true)).catch((error: unknown) => {
      if (epoch === this.epoch && this.enabled && !this.disposed) this.publish({ ...this.snapshot, error: message(error), errorNoticeId: noticeId, errorGeneration: generation })
      throw error
    }).finally(() => { if (this.opens.get(key) === operation) this.opens.delete(key) })
    this.opens.set(key, operation)
    return operation
  }

  dispose(): void {
    this.disposed = true; this.enabled = false; this.epoch++
    this.lifetime.abort(); clearTimeout(this.timer); clearTimeout(this.deadlineTimer)
    try { if (typeof document !== 'undefined' && typeof document.removeEventListener === 'function') document.removeEventListener('visibilitychange', this.onVisibilityChange) } catch { /* 非浏览器环境未注册 */ }
    this.presented.clear(); this.opens.clear(); this.knownNotices.clear(); this.sessionSelectionKey = undefined; this.listeners.clear(); this.snapshot = { loading: false }
  }

  /** 页面在前台时完成提示静默记为已读：不弹气泡，也不保留未读；失败、审批与提问照常呈现。 */
  private silenceVisibleCompletion(frame: AssistantNotificationSnapshot): AssistantNotificationSnapshot {
    const primary = frame.primary
    if (primary === null || primary.kind !== 'completed' || !this.pageVisible()) return frame
    if (!primary.read) void this.ackRead(primary.noticeId, frame.generation).catch(() => undefined)
    return { ...frame, primary: null }
  }
  private pageVisible(): boolean { try { return typeof document !== 'undefined' && document.visibilityState === 'visible' } catch { return false } }
  private ackRead(noticeId: string, generation: number): Promise<void> {
    const epoch = this.epoch
    return this.enqueue(async (signal) => {
      await this.call('ack', { noticeId, generation, action: 'read' }, signal)
      this.assertCurrent(epoch, signal)
    }, epoch)
  }

  private requireFrame(generation: number): void {
    if (!this.enabled || this.disposed || this.snapshot.frame?.generation !== generation) throw new Error('提醒已失效，请刷新后重试')
  }
  private assertCurrent(epoch: number, signal: AbortSignal): void {
    signal.throwIfAborted()
    if (epoch !== this.epoch || !this.enabled || this.disposed) throw new Error('提醒配置已变化')
  }
  private enqueue<T>(task: (signal: AbortSignal) => Promise<T>, epoch: number): Promise<T> {
    const signal = AbortSignal.any([this.lifetime.signal, AbortSignal.timeout(8_000)])
    const operation = this.chain.then(() => { this.assertCurrent(epoch, signal); return task(signal) })
    this.chain = operation.catch(() => undefined)
    return operation
  }
  private async call<T>(action: 'read' | 'read-session' | 'ack' | 'clear-all' | 'target', payload: unknown, signal: AbortSignal): Promise<T> {
    const result = await callCodingNsRpcResult(this.rpc, `assistant/notifications/${action}`, payload, signal)
    signal.throwIfAborted()
    if (!result.ok) throw new Error(result.error.message)
    return result.value as T
  }
  private scheduleDeadline(): void {
    clearTimeout(this.deadlineTimer)
    const frame = this.snapshot.frame
    const primary = frame?.primary
    if (frame === undefined || primary === null || primary?.deadline === undefined) return
    const remaining = primary.deadline - (this.now() + this.clockOffset)
    if (remaining <= 0) { this.publish({ ...this.snapshot, frame: { ...frame, primary: null } }); return }
    // 截止时间只使用 Host 的首展确认；刷新、重连和快照重复都不创建新时长。
    this.deadlineTimer = setTimeout(() => {
      if (this.snapshot.frame?.generation !== frame.generation || this.snapshot.frame.primary?.noticeId !== primary.noticeId) return
      this.publish({ ...this.snapshot, frame: { ...this.snapshot.frame, primary: null } })
      void this.refresh(true)
    }, remaining)
  }
  private publishFrame(frame: AssistantNotificationSnapshot): void {
    if (this.snapshot.frame?.generation !== frame.generation) this.knownNotices.clear()
    // 在分页/抢占前已显示的原生点击仍可定位；只缓存安全通知，目标始终再次向 Host 查询。
    for (const notice of [...frame.items, ...(frame.primary === null ? [] : [frame.primary])]) {
      this.knownNotices.delete(notice.noticeId); this.knownNotices.set(notice.noticeId, notice)
    }
    while (this.knownNotices.size > 64) this.knownNotices.delete(this.knownNotices.keys().next().value!)
    const id = this.snapshot.errorNoticeId
    const keepError = id !== undefined && this.snapshot.errorGeneration === frame.generation
      && (frame.primary?.noticeId === id || frame.items.some((notice) => notice.noticeId === id))
    this.publish({ frame, loading: false, ...(keepError ? { error: this.snapshot.error, errorNoticeId: id, errorGeneration: frame.generation } : {}) })
  }
  private publish(value: AssistantNotificationClientSnapshot): void { this.snapshot = value; for (const listener of this.listeners) listener() }
}

function message(error: unknown): string { return error instanceof Error ? error.message : String(error) }

function readStreamFrame(value: unknown): AssistantNotificationStreamFrame | undefined {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return undefined
  const frame = value as { readonly type?: unknown; readonly snapshot?: unknown }
  if (frame.type !== 'snapshot' && frame.type !== 'delta') return undefined
  if (typeof frame.snapshot !== 'object' || frame.snapshot === null || Array.isArray(frame.snapshot)) return undefined
  const snapshot = frame.snapshot as { readonly generation?: unknown; readonly revision?: unknown }
  if (!Number.isSafeInteger(snapshot.generation) || !Number.isSafeInteger(snapshot.revision)) return undefined
  return { type: frame.type, snapshot: frame.snapshot as AssistantNotificationSnapshot }
}

function isUnsupportedStreamError(error: unknown): boolean {
  if (typeof error === 'object' && error !== null) {
    const code = String((error as { readonly code?: unknown }).code ?? '')
    if (['CODINGNS_RPC_NOT_FOUND', 'CODINGNS_RPC_UNSUPPORTED', 'UNSUPPORTED_CAPABILITY', 'PEER_HOST_UNSUPPORTED'].includes(code)) return true
  }
  return /(?:HTTP (?:404|405)|not found|unsupported|未知|不存在|未挂载|尚未装配|暂不支持)/iu.test(message(error))
}

function wait(ms: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve) => {
    const timer = setTimeout(done, ms)
    // 取消只结束当前退避，不应把 startStream 变成未处理拒绝。
    const abort = (): void => { clearTimeout(timer); cleanup(); resolve() }
    const cleanup = (): void => signal.removeEventListener('abort', abort)
    function done(): void { cleanup(); resolve() }
    signal.addEventListener('abort', abort, { once: true })
    if (signal.aborted) abort()
  })
}
