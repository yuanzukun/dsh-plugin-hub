import { createElement, useEffect, useState } from 'react'
import type { ReactElement } from 'react'
import type { LanAccessDshSnapshot } from '../../shared/contracts/lan-access-dsh.js'
import type { LanAccessDshSettings } from '../../shared/contracts/config.js'
import { CODINGNS_RPC_CHANNEL } from '../../shared/contracts/transport.js'
import { buildLanAccessUrls, copyTextToClipboard, resolveLanAccessStatus } from './lan-access-status.js'
import type { FeaturePanelProps, CodingNsRpcClient } from './types.js'
import {
  dshFormRootStyle,
  dshSettingsButtonStyle,
  dshSettingsFieldLabelStyle,
  dshSettingsFieldStyle,
  dshSettingsNoteStyle,
  dshSettingsPrimaryButtonStyle,
  dshSettingsRowStyle,
  dshThemeColor,
} from '../theme.js'
import { useCodingNsTranslator } from '../locale.js'
import { SettingsToggleRow } from '../settings-controls.js'
import { uiFontSize } from '../font-scale.js'

/** “局域网访问DSH”设置卡片：只配置一条监听并转发到当前 DSH Web。 */
export function LanAccessPanel({ services, enabled, snapshot: settingsSnapshot, notify }: FeaturePanelProps): ReactElement {
  const { rpc, settings } = services
  const t = useCodingNsTranslator(services.locale)
  const [savedSettings, setSavedSettings] = useState<LanAccessDshSettings | undefined>()
  const disabled = !enabled
  const controlsDisabled = disabled || settingsSnapshot.status === 'loading' || !settingsSnapshot.writable
  const [listenHosts, setListenHosts] = useState<string[]>(['0.0.0.0'])
  const [interfaceAddresses, setInterfaceAddresses] = useState<string[]>([])
  const [listenHost, setListenHost] = useState('0.0.0.0')
  const [listenPort, setListenPort] = useState('13080')
  const [dshPort, setDshPort] = useState('')
  const [autoStart, setAutoStart] = useState(false)
  const [detectedDshPorts, setDetectedDshPorts] = useState<number[]>([])
  const [snapshot, setSnapshot] = useState<LanAccessDshSnapshot | null>(null)
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (disabled) return
    void callRpc<string[]>(rpc, 'lanAccessDsh/addresses', {})
      .then((addresses) => {
        setListenHosts(addresses)
        setInterfaceAddresses(addresses)
        if (!addresses.includes(listenHost)) setListenHost(addresses[0] ?? '0.0.0.0')
      })
      .catch(() => undefined)
    void callRpc<LanAccessDshSnapshot | null>(rpc, 'lanAccessDsh/get', {})
      .then((current) => {
        if (!current) return
        setSnapshot(current)
      })
      .catch(() => undefined)
    void callRpc<LanAccessDshSettings>(rpc, 'lanAccessDsh/settings/get', {})
      .then(setSavedSettings)
      .catch(() => {
        const fallback = settings.getSnapshot().value?.lanAccessDsh
        if (fallback !== undefined) setSavedSettings(fallback)
      })
  }, [disabled, rpc, settings])

  useEffect(() => {
    if (savedSettings === undefined) return
    setAutoStart(savedSettings.autoStart)
    setListenHost(savedSettings.listenHost)
    setListenPort(String(savedSettings.listenPort))
    setDshPort(savedSettings.dshPort > 0 ? String(savedSettings.dshPort) : '')
  }, [savedSettings])

  // 复制反馈只保留两秒，避免地址行长期停在“已复制”。
  useEffect(() => {
    if (copiedUrl === null) return
    const timer = setTimeout(() => setCopiedUrl(null), 2000)
    return () => clearTimeout(timer)
  }, [copiedUrl])

  const run = async (operation: () => Promise<void>): Promise<void> => {
    setBusy(true)
    try {
      await operation()
    } catch (error) {
      notify({ kind: 'error', message: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy(false)
    }
  }

  const detect = (): Promise<void> => run(async () => {
    const result = await callRpc<{ ports: number[] }>(rpc, 'lanAccessDsh/detect', {})
    setDetectedDshPorts(result.ports)
    if (result.ports.length === 1) setDshPort(String(result.ports[0]))
    notify({ kind: 'info', message: result.ports.length === 0 ? t('lan.detectNone') : t('lan.detected', { ports: result.ports.join(t('common.listSeparator')) }) })
  })

  const saveMapping = async (nextAutoStart = autoStart): Promise<void> => {
    const saved = await callRpc<LanAccessDshSettings>(rpc, 'lanAccessDsh/settings/set', readMapping(listenHost, listenPort, dshPort, nextAutoStart, t))
    setSavedSettings(saved)
  }

  const saveMappingOnBlur = (): void => {
    if (!autoStart) return
    void saveMapping().catch((error: unknown) => {
      notify({ kind: 'error', message: error instanceof Error ? error.message : String(error) })
    })
  }

  const start = (): Promise<void> => run(async () => {
    const saved = readMapping(listenHost, listenPort, dshPort, autoStart, t)
    await saveMapping()
    const payload = {
      listenHost: saved.listenHost,
      listenPort: saved.listenPort,
      ...(saved.dshPort > 0 ? { dshPort: saved.dshPort } : {}),
    }
    const current = await callRpc<LanAccessDshSnapshot>(rpc, 'lanAccessDsh/start', payload)
    setSnapshot(current)
    setCopiedUrl(null)
    setDshPort(String(current.dshPort))
    setListenPort(String(current.listenPort))
    const url = buildLanAccessUrls(current, interfaceAddresses)[0]
      ?? `http://${current.listenHost}:${current.actualListenPort ?? current.listenPort}/`
    notify({ kind: 'success', message: t('lan.started', { url }) })
  })

  const stop = (): Promise<void> => run(async () => {
    await callRpc(rpc, 'lanAccessDsh/stop', {})
    setSnapshot(null)
    setCopiedUrl(null)
    notify({ kind: 'success', message: t('lan.stopped') })
  })

  const copyAccessUrl = async (url: string): Promise<void> => {
    try {
      await copyTextToClipboard(url)
      setCopiedUrl(url)
      notify({ kind: 'success', message: t('lan.copySuccess') })
    } catch (error) {
      setCopiedUrl(null)
      notify({ kind: 'error', message: error instanceof Error ? error.message : t('lan.copyFailed') })
    }
  }

  const handleAccessUrlKeyDown = (event: { key: string; preventDefault: () => void }, url: string): void => {
    if (event.key !== 'Enter' && event.key !== ' ') return
    event.preventDefault()
    void copyAccessUrl(url)
  }

  const toggleAutoStart = (): Promise<void> => run(async () => {
    const next = !autoStart
    await saveMapping(next)
    setAutoStart(next)
    notify({ kind: 'success', message: next ? t('lan.autoStartOn') : t('lan.autoStartOff') })
  })

  const fieldStyle = dshSettingsFieldStyle
  const buttonStyle = dshSettingsButtonStyle
  const status = resolveLanAccessStatus(snapshot)
  const accessUrls = buildLanAccessUrls(snapshot, interfaceAddresses)
  // 监听全部网卡时会有多个可用地址，用数量提示这不是唯一的入口。
  const statusLabel = status.listening && accessUrls.length > 1
    ? t('lan.statusListeningCount', { count: String(accessUrls.length) })
    : t(status.labelKey)

  return createElement(
    'div',
    { 'aria-disabled': controlsDisabled, style: { ...dshFormRootStyle, display: 'flex', flexDirection: 'column', gap: 14, opacity: controlsDisabled ? 0.5 : 1, pointerEvents: controlsDisabled ? 'none' : 'auto' } },
    createElement('p', { style: { margin: 0, color: dshThemeColor.labelSecondary, fontSize: uiFontSize(13), lineHeight: 1.5 } }, t('lan.description')),
    createElement('label', { style: { display: 'flex', flexDirection: 'column', gap: 6 } },
      createElement('span', { style: dshSettingsFieldLabelStyle }, t('lan.listenHost')),
      createElement('select', { value: listenHost, disabled: controlsDisabled || busy, onChange: (event: { currentTarget: { value: string } }) => setListenHost(event.currentTarget.value), onBlur: saveMappingOnBlur, style: fieldStyle },
        ...listenHosts.map((host) => createElement('option', { key: host, value: host }, host === '0.0.0.0' ? t('lan.allInterfaces') : host)),
      ),
    ),
    createElement('label', { style: { display: 'flex', flexDirection: 'column', gap: 6 } },
      createElement('span', { style: dshSettingsFieldLabelStyle }, t('lan.listenPort')),
      createElement('input', { type: 'number', min: 0, max: 65535, placeholder: t('lan.listenPort'), value: listenPort, disabled: controlsDisabled || busy, onChange: (event: { currentTarget: { value: string } }) => setListenPort(event.currentTarget.value), onBlur: saveMappingOnBlur, style: fieldStyle }),
    ),
    createElement('label', { style: { display: 'flex', flexDirection: 'column', gap: 6 } },
      createElement('span', { style: dshSettingsFieldLabelStyle }, t('lan.dshPort')),
      createElement('div', { style: dshSettingsRowStyle },
        createElement('input', { type: 'number', min: 1, max: 65535, placeholder: t('lan.dshPort'), value: dshPort, disabled: controlsDisabled || busy, onChange: (event: { currentTarget: { value: string } }) => setDshPort(event.currentTarget.value), onBlur: saveMappingOnBlur, style: { ...fieldStyle, flex: 1, minWidth: 0 } }),
        createElement('button', { type: 'button', disabled: controlsDisabled || busy, onClick: () => void detect(), style: buttonStyle }, t('lan.detect')),
      ),
    ),
    detectedDshPorts.length > 1 && createElement('div', { style: dshSettingsNoteStyle }, t('lan.detectMultiple', { ports: detectedDshPorts.join(t('common.listSeparator')) })),
    createElement(SettingsToggleRow, { label: t('lan.autoStart'), checked: autoStart, disabled: controlsDisabled || busy, onChange: () => void toggleAutoStart() }),
    createElement('div', { style: dshSettingsRowStyle },
      createElement('button', { type: 'button', disabled: controlsDisabled || busy || !listenPort, onClick: () => void start(), style: { ...dshSettingsPrimaryButtonStyle, flex: 1 } }, busy ? t('lan.processing') : snapshot ? t('lan.update') : t('lan.start')),
      snapshot && createElement('button', { type: 'button', disabled: controlsDisabled || busy, onClick: () => void stop(), style: buttonStyle }, t('lan.stop')),
    ),
    createElement('div', {
      role: 'status',
      'aria-live': 'polite',
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        padding: '12px 14px',
        border: `1px solid ${status.listening ? dshThemeColor.success : dshThemeColor.border}`,
        borderRadius: 8,
        background: dshThemeColor.surfaceSubtle,
      },
    },
      createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' } },
        createElement('span', { 'aria-hidden': true, style: { width: 9, height: 9, flex: '0 0 auto', borderRadius: '50%', background: status.color } }),
        createElement('span', { style: { color: status.color, fontSize: uiFontSize(13), fontWeight: 600 } }, statusLabel),
        snapshot !== null && createElement('span', { style: { color: dshThemeColor.labelTertiary, fontSize: uiFontSize(12) } }, t('lan.forwardTarget', { dshPort: String(snapshot.dshPort) })),
      ),
      status.state === 'error' && snapshot !== null && snapshot.error !== null && createElement('div', { style: { color: dshThemeColor.error, fontSize: uiFontSize(12), lineHeight: 1.5, overflowWrap: 'anywhere' } }, snapshot.error),
      accessUrls.length === 0
        ? createElement('div', { style: { color: dshThemeColor.labelTertiary, fontSize: uiFontSize(12), lineHeight: 1.5 } }, t('lan.accessUrlEmpty'))
        : createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 6 } },
          ...accessUrls.map((url) => createElement('div', {
            key: url,
            role: 'button',
            tabIndex: controlsDisabled || busy ? -1 : 0,
            'aria-disabled': controlsDisabled || busy,
            'aria-label': t('lan.copyAddressHint', { url }),
            title: t('lan.copyAddressHint', { url }),
            onClick: () => { if (!controlsDisabled && !busy) void copyAccessUrl(url) },
            onKeyDown: (event: { key: string; preventDefault: () => void }) => { if (!controlsDisabled && !busy) handleAccessUrlKeyDown(event, url) },
            style: {
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: 12,
              minWidth: 0,
              padding: '8px 10px',
              border: `1px solid ${copiedUrl === url ? dshThemeColor.success : dshThemeColor.border}`,
              borderRadius: 6,
              background: dshThemeColor.pageBackground,
              cursor: controlsDisabled || busy ? 'default' : 'copy',
              transition: 'border-color 160ms ease, background 160ms ease',
            },
          },
            createElement('span', { style: { minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: dshThemeColor.accent, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize: uiFontSize(13), fontWeight: 600 } }, url),
            createElement('span', { style: { flex: '0 0 auto', color: copiedUrl === url ? dshThemeColor.success : dshThemeColor.labelSecondary, fontSize: uiFontSize(12), fontWeight: 600 } }, copiedUrl === url ? t('lan.copied') : t('lan.copy')),
          )),
        ),
    ),
    // PWA 资产与通知配置已移到「移动端访问增强」卡片；这里只保留监听边界上的回环告警。
    createElement('div', { style: dshSettingsNoteStyle }, t('lan.pwa.loopbackWarning')),
  )
}

/** 局域网卡片只写监听映射：PWA 档位由「移动端访问增强」卡片单独写入 Host。 */
interface LanAccessMappingPayload {
  autoStart: boolean
  listenHost: string
  listenPort: number
  dshPort: number
}

function readMapping(
  listenHost: string,
  listenPort: string,
  dshPort: string,
  autoStart: boolean,
  t: ReturnType<typeof useCodingNsTranslator>,
): LanAccessMappingPayload {
  return {
    autoStart,
    listenHost,
    listenPort: parsePort(listenPort, t('lan.fieldListenPort'), true, t),
    dshPort: dshPort.trim() === '' ? 0 : parsePort(dshPort, t('lan.fieldDshPort'), false, t),
  }
}

function parsePort(value: string, field: string, allowZero: boolean, t: ReturnType<typeof useCodingNsTranslator>): number {
  if (!/^\d+$/u.test(value)) throw new Error(t('lan.fieldMustBeNumber', { field }))
  const port = Number(value)
  const minimum = allowZero ? 0 : 1
  if (!Number.isInteger(port) || port < minimum || port > 65535) throw new Error(t('lan.fieldMustBeInteger', { field, minimum }))
  return port
}

async function callRpc<T>(rpc: CodingNsRpcClient, endpoint: string, payload: unknown): Promise<T> {
  let response
  try {
    response = await rpc.call(CODINGNS_RPC_CHANNEL, endpoint, payload)
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    if (!/HTTP (?:404|405)\b/u.test(message)) throw error
    response = await rpc.call('/api', `codingns/${endpoint}`, payload)
  }
  if (!response.ok) throw new Error(response.error.message)
  return response.value as T
}
