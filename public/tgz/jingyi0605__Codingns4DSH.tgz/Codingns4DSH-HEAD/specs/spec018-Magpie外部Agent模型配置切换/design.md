# Design: Read-only Magpie metadata, usage, and route integration

Status: Usage/catalog recognition is implemented. This amendment adds bounded model metadata reads and a Codex context correction; the old selector, setter, read-back, and provenance design remains historical and out of scope.

## 1. Design decision

Magpie exposes configured provider/model choices through its Agent catalogs. CodingNS does not create a second model-selection UI or write Agent configuration. The Host enriches existing exact matches as before. Codex has one narrow catalog exception: exact model IDs from the validated `magpie models codex` output are added to the ordinary Codex group when Codex `model/list` omits them. `/v1/models` metadata enriches those rows when available; a validated CLI display label is the fallback.

CodingNS also uses the verified Magpie record to supply context-window and related metadata. The exact Codex Magpie model `auto/gpt-6.1-sol` must use Magpie's 500,000-token context window before usage anchoring and compaction. A missing or invalid record never disables the normal catalog or usage path.

## 2. Data flow

```text
Current DSH session
  -> Host reads adapter, model, providerSessionId
  -> Host resolves the explicit adapter -> Magpie Agent mapping
  -> Host runs bounded `magpie --version` and `magpie models <agent>`
  -> Host requires exact catalog membership and a loopback Gateway origin
  -> Host optionally reads bounded `/v1/models` and validates the exact model record
  -> Host merges safe model metadata into the Agent's existing model catalog
  -> Host reads aggregate usage
  -> Host optionally reads route for the distinct Provider session ID
  -> Client displays aggregate, session, and route data separately

No separate model-selector branch, Magpie setter, or session provenance is involved. Metadata is Host-derived; Client-supplied model properties are ignored.
```

The DSH session ID is never substituted for an Agent session ID. The Host only uses a `providerSessionId` that differs from the DSH session ID, and route data is requested only after the usage payload contains the exact Agent/session pair.

## 3. Host boundary

### 3.1 Explicit mapping

The mapping lives in `src/host/cli-adapters/magpie-usage.ts` and is not derived from names:

| CodingNS adapter | Magpie Agent |
| --- | --- |
| `dsh` | `dsh` |
| `claude-code` | `claude` |
| `codex` | `codex` |
| `command-code` | `commandcode` |
| `kimi` | `kimi` |
| `gemini` | `gemini` |
| `pi` | `pi` |
| `opencode` | `opencode` |
| `grok` | `grok` |
| `mcode` | `minimax-code` |
| `zcode` | `zcode` |
| `codebuddy` | `codebuddy` |
| `workbuddy` | `workbuddy` |
| `cursor-cli` | `cursor` |
| `qoder` | `qoder` |
| `qoder-cn` | `qoder-cn` |
| `antigravity` | `agy` |

The map authorizes read-only catalog recognition only. It does not authorize any configuration write.

### 3.2 CLI and parser

- `magpie --version` is accepted only at or above the verified minimum version.
- `magpie models <agent>` is executed with fixed argument arrays, bounded output, a timeout, and `shell: false` except the platform's required command-wrapper behavior. `MAGPIE_NO_ACCOUNTS` is removed from the child environment so account-backed entries remain visible; the command is still read-only.
- The parser requires the exact Agent footer, at least one model row, one loopback Gateway URL, and exact bounded model IDs. Unknown output fails closed.
- The parsed catalog stays Host-private. The Client receives no Magpie catalog and no raw CLI output.
- Catalog and version reads are cached briefly and share in-flight reads per Agent. A caller abort does not cancel a shared Host-lifetime read.

#### Antigravity child-process environment

Antigravity also reads `magpie agy env` through the Host's currently detected Magpie executable, including a custom executable selection. This read has a five-second timeout, a 64 KiB output limit, and cancellation tied to the operation and driver lifetime. The output is parsed as `KEY=value` data, never evaluated as shell code. Only `GEMINI_API_KEY`, `GOOGLE_GEMINI_BASE_URL`, `model`, and optional `settings` are accepted; the first three must be present before applying the result. A nonempty `settings` value is passed unchanged apart from outer whitespace as AGY's `--settings` argument, before the `models` subcommand during discovery and on each turn's invocation. Older Magpie versions without this field retain the environment-only behavior. The settings file is not read, copied, or persisted by the adapter.

The API key and endpoint are passed only to `agy models` and the current AGY turn's child process; explicit Host runtime environment overrides take precedence. An explicit selected model is retained; `provider-default` follows the model returned by Magpie, as its shell wrapper does. Each new turn reads the environment again. Read failures preserve native AGY behavior; cancellation propagates. No credentials enter the model catalog, settings, session index, logs, or Client response, and no configuration is written.

AGY's native model IDs keep their `magpie/` prefix when selected or sent to the CLI. Only verified catalog/metadata matching removes that prefix, so `magpie/hl/gpt-6-astra` can match the exact `hl/gpt-6-astra` row from `magpie models agy` without changing the selection ID.

AGY model recognition requires that exact ID match; its native Gemini names are not Magpie display-name aliases. Otherwise native `gemini-3.8-flash` and explicit `magpie/tlp/gemini-3.8-flash` would inherit the same provider label and metadata despite having different selection IDs. Keep both sources selectable, leave native metadata intact, and add a localized native-Antigravity suffix only in the conversation picker's display and tooltip. Explicit Magpie rows keep their verified provider label and badge.

The Antigravity conversation menu pins only `provider-default`, then uses the same provider-first, natural-name, context-variant and ID tie-break ordering as Claude Code. This is a copied presentation view; cached Host group order and exact selection IDs remain unchanged.

### 3.3 Gateway reads

`MagpieUsageService.read()` first confirms the current model in the current Agent catalog. It then reads:

- `GET /v1/magpie/usage?period=today` for aggregate totals and exact Agent/session rows.
- `GET /v1/magpie/route?session=<id>` only when the Client requests route details, the session row matched, and the session ID is bounded.

Responses are size-limited and normalized to the shared `MagpieUsageSnapshot` contract. Only safe counts, costs, route strings, attempt model IDs, and status fields cross the Host boundary.

### 3.4 Model metadata reads

- Add a bounded, read-only `GET /v1/models` reader on the Host, reusing the validated loopback origin and the existing response-size and timeout safeguards.
- Normalize only known public fields: `id`, `display_name`/`magpie_label`, `context_window`/`context_length`, `max_input_tokens`, `max_output_tokens`, `modalities.input`/`modalities.output`, `reasoning`, `reasoning_levels`, `supported_reasoning_levels`, `service_tiers`, and explicitly supported capability/description fields.
- Require the exact model ID in the mapped `magpie models <agent>` output, or a unique exact normalized display-label alias, and an exact matching `/v1/models` `id`. Antigravity requires the exact ID rather than a display-label alias. Command Code, Pi, and Antigravity normalize their native `magpie/` prefix for matching without changing the selection ID.
- Enrich existing Agent model entries; do not add models from unrelated records or change selection semantics. The Codex-only addition is limited to exact IDs in the validated Codex CLI catalog. On exact Magpie matches, Magpie's declared value wins. An absent field preserves the Agent's own known value; explicit `reasoning: false` removes stale efforts.
- Cache parsed metadata per Magpie Agent for a short bounded TTL and clear it when its catalog/origin changes. A failed metadata read leaves existing rows unchanged; Codex additions may still use their validated CLI labels without inferred metadata.
- Never return the raw Magpie document, ownership secrets, or unrecognized fields to the Client.

### 3.5 Codex model catalog additions

- Only `adapterId === 'codex'` uses this behavior; no Magpie model is copied into another Agent's catalog.
- Use the validated `magpie models codex` IDs as the allowlist. Add only IDs not already present in the Codex catalog and append them to its existing Codex group.
- Prefer the exact `/v1/models` display name and normalized metadata. If the metadata request is unavailable or has no row for an allowed ID, retain the Magpie CLI label (or the model ID when no label exists) and expose no inferred effort options.
- Do not change Codex-native rows, the current model, or the current effort. The existing model picker and `session/set` flow remain the only selection path.
- If Magpie catalog validation fails, return the original Codex catalog unchanged.

### 3.6 Codex context correction

- For an exact Codex model ID confirmed by both the `codex` CLI catalog and Magpie, the Host associates the validated Magpie `context_window` with the model before Codex usage events are stabilized.
- The trusted context value is carried through a Host-owned model metadata lookup or turn input, not a Client payload. `codexUsageChunk`/the Codex event boundary applies it before `stabilizeCodexUsage`; a contradictory `258400` event cannot become the anchor for `auto/gpt-6.1-sol`.
- Recompute `contextUsageRatio` using Magpie's value. The Codex compaction threshold and DSH projection then observe the same corrected context window.
- The static fallback for `gpt-6.1-sol` is corrected to `500000` for operation when the live Magpie record is unavailable. Do not apply it to other similarly named provider-qualified model IDs.

## 4. RPC and session behavior

The Host keeps the existing `cli/models`, `cli/session/set`, and ordinary subscription RPCs. There are no `cli/magpie/models` or `cli/magpie/set-model` actions.

For `cli/subscription`:

1. Read the current Host session by `sessionId`.
2. If the session adapter matches the request, call `magpieUsage.read(session, signal, includeRoute, dshSessionId)`.
3. If the result is non-null, return `{ providerUsage: null, magpie }`.
4. If the result is null, call the existing provider subscription service and return `{ providerUsage, magpie: null }`.

The Client does not send or receive model provenance. Old persisted records may contain obsolete fields; hydration ignores them and new records do not write them.

## 5. Client behavior

The model selector renders only the normal Agent model catalog. Selecting any model uses the existing `session/set` flow and never invokes Magpie.

The existing subscription slot understands the tagged snapshot response and retains compatibility with older Hosts that return provider usage directly. It includes the session/provider identity in its cache key, requests route details only while the Magpie panel is open, and cancels the open-panel route signal on close or session change.

The Magpie usage popover labels aggregate totals, current-session totals, and route status separately. It displays unavailable states instead of attributing aggregate usage to the current session or guessing a route.

### 5.1 Provider labels in ordinary model menus

After exact catalog recognition, the Host sets the optional transient `CodingNsCliModel.magpieProviderId` from the provider segment of the resolved Magpie ID. Reuse the existing provider-ID parser, which excludes `auto` and `group`; do not treat `owned_by` or an Agent alias prefix as the carrier. Set this field for existing matches and missing Codex additions even when Gateway metadata is unavailable. Keep the model display name separate from this field so the unique display-name matching contract still works on refresh.

The shared React/imperative Magpie model tag renders this provider ID before the logo. External Agent menus, delegation menus, and the native DSH catalog bridge pass the optional field through. Native decoration replaces an existing tag when its provider changes, without rewriting DSH-owned model labels or adding duplicate tags. Provider text can shrink within the row, with the complete ID retained in its title and accessible label. Older Hosts continue to show only the logo. The field is catalog presentation data, not part of any session-setting or provider-routing payload.

### 5.2 Claude context variants and metadata label precedence

The metadata parser prefers `magpie_label`, then `display_name`, then `name`, matching Claude Gateway discovery. This prevents later enrichment from replacing a provider-qualified label with the bare model name.

The shared Host catalog helper `claudeModelDisplayName` appends `[1m]` only when the exact Claude selection ID ends in that suffix and the chosen label does not already contain it. Claude discovery applies it while merging CLI, Gateway, and configured rows; Magpie enrichment reapplies it after choosing the metadata label. This preserves the distinction even when Gateway metadata is unavailable or a metadata label omits the context marker. Ordinary and long-context selection IDs remain separate; metadata matching may strip Claude's documented `[1m]` suffix but must never rewrite the selection ID. Other adapters' names receive no Claude context decoration.

Tests exercise the complete discovery/enrichment path with fake CLI/Gateway responses, repeat enrichment, and verify that the existing menu renders the distinct labels and sends each original ID through `cli/session/set`. No Client label-rewriting branch or new selector is introduced.

The Claude conversation menu sorts a copy of each group's models before the existing search-ranking step. Keep `provider-default`, `sonnet`, `opus`, `haiku`, and CLI-discovered `fable` first; pinning is presentation-only and does not add Fable to the static fallback catalog. Compare the remaining provider IDs first, then model names without the ` · provider` and `[1m]` decorations using an English natural numeric collator that ignores case and punctuation, then ordinary/long-context variants, and finally exact IDs for ties. Do not mutate the shared catalog, reorder other adapters, change group membership, or change the existing search relevance ranking or selected-model lookup.

## 6. Safety and compatibility

- No Magpie configuration file, provider file, credential store, or Desktop profile is read or written.
- No Magpie setter, current-model read-back, restore operation, or persistent switching state exists in source or RPC contracts.
- Remote PeerHost routing continues to handle the ordinary `cli/*` endpoints; it has no Magpie-specific configuration path.
- Ordinary provider usage is preserved when catalog recognition or Gateway reads fail.
- Tests use fixtures and fake fetch responses only. They do not start a Gateway, execute a model turn, or operate Desktop.

## 7. Verification mapping

| Behavior | Evidence |
| --- | --- |
| Exact catalog parsing and version gate | `tests/magpie-usage.spec.ts` |
| DSH and external Agent mapping, including Cursor | `tests/magpie-usage.spec.ts` |
| Aggregate/session/route separation and redaction | `tests/magpie-usage.spec.ts` |
| Host Magpie attempt and ordinary fallback | `tests/cli-adapters.spec.ts` |
| Ordinary model selector remains the only selector | `tests/cli-slots-translation.spec.ts` |
| Remote model/session routing without Magpie-specific RPCs | `tests/peer-host-model-navigation.spec.ts` |

## 8. Metadata amendment verification

| Behavior | Evidence |
| --- | --- |
| `/v1/models` response bounds, parser, metadata normalization, and exact Magpie catalog matching | Focused tests in `tests/magpie-usage.spec.ts` or a dedicated Magpie metadata test |
| Enrichment for each verified external Agent except Codex, including effort labels/modalities/token limits | Host catalog merge tests covering all fixed adapter mappings |
| Magpie-only Codex models appear in the ordinary Codex group without replacing native choices | `tests/magpie-usage.spec.ts` |
| Magpie metadata failures preserve the original Agent catalog | Fake API timeout/schema/ID-mismatch tests |
| `auto/gpt-6.1-sol` corrects stale Codex `258400` before stabilization and compaction | Codex and registry tests for ratio, anchored window, and exact-ID isolation |
| Read-only live model metadata evidence | `docs/20261021-Magpie模型元数据实机读取与上下文纠正验证.md` |

Historical switching evidence remains under the Spec `docs/` directory for traceability only; it does not define the current implementation.
