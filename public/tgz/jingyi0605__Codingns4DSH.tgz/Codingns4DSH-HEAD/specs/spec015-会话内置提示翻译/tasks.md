# Tasks

## 2026-11-09 isolated Stage0 acceptance

- [x] DONE: Build a branch snapshot and configure isolated DSH 0.2.2-rc.1 Stage0 for direct browser acceptance. Observable result: a working authenticated URL opens prepared sessions for Chinese technical-name skipping, custom rules, and four specific validation failures; records and localized details survive reload. Depends on the completed source fix, existing dependencies, and the user's Stage0/build authorization. Read the launcher, runtime manager, Stage0 patch, and previous isolated diagnostic evidence first. Change only local snapshot/profile/fixture/verifier files and this spec's evidence. Exclude Desktop/existing service changes, copied credentials, paid upstream requests, commits, and publishing. Verify snapshot source hashes, build and built-output tests, actual runtime persistence, isolated headless-browser interactions, and listener isolation.

The isolated environment is under `C:/Users/Administrator/.config/codingns4dsh/stage0-translation-validation-20261109`; its local `README.md` documents acceptance, startup, and scoped shutdown. DSH Home is `C:/Users/Administrator/.dsh-stage0-translation-validation-20261109`, profile `stage0`, with separate state and loopback port **17896**. Telemetry and watch mode are off. No credentials were copied. The existing 17890 listener remains PID 3004. The authenticated browser URL was supplied for manual acceptance; authentication tokens are not recorded in this spec. After the user confirmed acceptance, all running Stage0 processes were stopped, port 17896 was released, and the existing 17890 service remained unchanged. Local `shutdown-verification.json` records zero remaining Stage0 processes and the released acceptance port.

All **567 source files** in the snapshot match both the recorded SHA256 manifest and this working branch. The profile plugin junction points to that snapshot. The snapshot build passed using the equivalent direct Node steps in local `build.ps1`: version check, clean snapshot output, TypeScript emit, Client bundle, and H5 bundle. The initial package-script attempt hit pnpm 11's `ERR_PNPM_UNSAFE_MODULES_DIR` when it tried to synchronize the shared dependency junction; no deletion occurred. Direct Node build steps avoided dependency mutation. Repository output and Desktop were not rebuilt or installed. Local build/install logs retain existing bundler and upstream OpenTelemetry peer warnings.

Built-output verification passed **159/159 tests**, zero failures, cancellations, or skips, using this command from the snapshot (not the source loader):

```powershell
node --import ./tests/register-css-loader.mjs --test --test-concurrency=1 --test-reporter=spec tests/session-translation-language.spec.ts tests/session-translation-result.spec.ts tests/session-translation-protection.spec.ts tests/session-translation-rules.spec.ts tests/session-translation.spec.ts tests/session-translation-native.spec.ts tests/session-translation-chat.spec.ts
```

Actual DSH persistence passed **6/6 prepared native sessions**, each completed with zero tool calls. Chinese technical-name prose makes zero translator calls and retains its original text; unchanged successful native output intentionally has no redundant translation metadata. Custom rules apply to both Chinese reasoning and reply, preserve originals, and append an explicit fixture marker. The other four sessions each preserve two failed records with the correct `failure.validation` value (`format`, `language`, `completion`, or `protected-text`), original fallback, model, duration, and reported usage.

Isolated headless Chrome passed **44/44 browser assertions** across Chinese/English locales, initial display/reload, successful custom-rule details, and all four failure explanations for reasoning/reply. Both fresh browser contexts authenticated using the same launch URL supplied for manual acceptance. No page script errors occurred. Saved screenshots include every case; Chinese protected-text reply and English incomplete-response reasoning layouts were visually inspected. These checks assert retained code/command text and specific explanations, rather than the old generic explanation.

The clearly named `stage0-validation-fixture` is a local synthetic LLM adapter. It forces each response shape through the real validation, persistence and UI paths, reporting **1273 synthetic tokens per translation**; paid provider calls and real billed tokens are **zero**. Custom rules and fixture mode were restored after session preparation. One preliminary Chinese session is preserved alongside the six acceptance sessions; select the newer numbered 01 session. Preparation harness assumptions about the settings write contract, redundant native metadata, and localized language labels were corrected before the successful results; no product changes were needed during this Stage0 follow-up.

Local evidence: `build.log`, `built-tests.log`, `rpc-verification.json`, `browser-verification.json`, `isolation-verification.json`, `source-hashes.json`, `artifact-hashes.json`, and `browser-*.png`. After restarting the isolated environment, recheck it without new prompts using `node <environment>/verify-browser.mjs` and `node <environment>/verify-isolation.mjs`. The browser entry point is the root application; choose numbered sessions in the `translation-acceptance` workspace, expanding the remaining sessions to find 01.

This establishes built-output, native synthetic-provider runtime, and Chinese/English browser acceptance; the user confirmed manual acceptance before requesting shutdown and PR submission. Real upstream translation, live external CLI agents, full-suite execution, and migration of old failure records remain outside this acceptance. The historical rejected provider reply is still unavailable. No publishing or changes to an existing installation were performed.

## 2026-11-09 Chinese technical names and validation details

- [x] DONE: Recognize Chinese prose containing short capitalized product names, and retain the specific validation category in translation failures. Observable result: Chinese update summaries containing Claude Code / Magpie RPC skip model calls when no custom rules are active; custom rules still run on same-language text; failed responses show format, language, completion, or protected-text explanations after history serialization. Depends on the existing language detector, translator, diagnostic reader, and details popup. Read Requirements 5–9, Design / Data ownership, language/rules/result/native/chat tests, and frontend localization rules first. Change the translation service/runtime/protection, shared diagnostic contract, popup/locales, related tests, and this spec. Exclude relaxing validation, changing custom-rule priority, retry policy, historical-record migration, builds, running profiles, commits, and publishing. Verify failing-first regressions, affected source suites, TypeScript, version/capability/i18n checks, and final diff review.

Branch: `fix/translation-validation-details`, created from clean local `main` at `cfc7af63`. The reported session's final Chinese reply saved only `invalid-response`; its rejected provider response and detailed validation error were not retained. This work does not assign a guessed validation category to that historical record.

Failing-first verification: **16 failed, 5 passed** across the selected language, validation, serialization, and popup regressions before implementation. After implementation, the initial eight-file run passed **178/178**. The expanded run found one existing interaction assertion expecting the old failure shape; it now also checks the retained language-validation detail in interaction diagnostics.

Final source verification: **305/305 tests passed across 20 files**, zero failures, cancellations, or skips. Coverage includes native/external input, reasoning and replies, malformed JSON/envelopes, empty/wrong-language results, truncated/missing finish events, omitted/unknown/duplicated placeholders, model fallback and reported usage, sanitized history, legacy records, English/Chinese popup text, custom rules, and ambiguous foreign prose. Log: local `data/logs/translation-validation-details-20261109-003751.log`.

```powershell
$testFiles = @(rg --files tests -g 'session-translation*.spec.ts' -g 'interaction-translation*.spec.ts' | Sort-Object)
$testFiles += @('tests/session-prompt-translation.spec.ts', 'tests/dsh-message-projector.spec.ts', 'tests/cli-adapters-turn-status.spec.ts', 'tests/attachment-prompt-language.spec.ts')
node --import ./tests/register-source-loader.mjs --test --test-concurrency=1 --test-reporter=spec @testFiles
node ./node_modules/typescript/bin/tsc -p tsconfig.json --noEmit
node scripts/check-version-sync.mjs
node scripts/check-capability-retirement.mjs
node scripts/check-client-i18n.mjs
git diff --check
```

TypeScript, version, capability, localization, and whitespace checks pass. Localization reports zero blocking violations and 124 existing nonblocking warnings; React source tests retain the existing server-rendering `useLayoutEffect` warnings. The first TypeScript run found a missing local `@deepseek-ai/dsh-client-ui-context-menu` dependency. Synchronized local dependencies with `corepack pnpm@10.7.1 install --frozen-lockfile --ignore-scripts`, then reran TypeScript and all 305 source tests successfully. `package.json` and `pnpm-lock.yaml` are unchanged; no dependency lifecycle scripts were run.

A read-only replay of the reported session's complete 936-character final reply through the modified source and a local fake provider also passes: without custom rules, source language is Chinese, model calls are zero, and the original is returned unchanged; with a custom rule, source language remains Chinese, exactly one fixture call occurs, and all 16 protected spans remain unchanged. No upstream requests or billed tokens were used. The tracked language tests retain a reduced reproduction rather than copying the private session log.

At the end of source-only verification, no bundle build, installed-profile change, live-provider translation, browser/Stage0 operation, commit, push, or publishing had been performed. The separately authorized Stage0 follow-up above records the subsequent build and browser evidence. Real upstream-provider acceptance remains unperformed; an enabled custom rule still requires a model call and can encounter an invalid upstream response.

## Original implementation (2026-10-15)

Status: Complete, verified from source on 2026-10-15.

- [x] 1. Record approved scope, evidence, and design. DONE: attached JSONL and current source inspected; path-protection gap reproduced in memory.
- [x] 2. Implement language-specific attachment formatting and preserve attachment payloads. DONE. All five languages, file-only turns, unchanged paths, disabled defaults, late CLI arguments, and native image/unresolved-file preservation have source regressions. Native resolved files retain the existing text projection, preventing a second English-only DSH file notice.
- [x] 3. Extend literal protection and reject explicitly truncated translations. DONE. Known literals and recognized host wrappers are protected; ordinary HTML/code regression tests pass. Missing finish and max-token termination enter model fallback/recovery.
- [x] 4. Add prompt-assembly capability and injected-message translation with bounded caching and original-text fallback. DONE. Fake-version and real DSH assembly tests pass, including immutable schemas, complete-section enforcement, cache invalidation, and disposal. Real Cordis middleware verifies that prepended wrappers see catalogs appended by existing listeners after next().
- [x] 5. Run source regressions, type/version/capability checks, regenerate the capability report, and record results. DONE. The expanded source suite passed all 457 tests. After final identifier/path-boundary and cache-compatibility refinements, all 64 affected tests passed. Typecheck, version check, capability retirement check, report generation, and diff whitespace review passed.

## Verification

Expanded regression command (457 passed):

```bash
node --import ./tests/register-source-loader.mjs --test --test-reporter=spec \
  tests/session-translation*.spec.ts tests/session-prompt-translation.spec.ts \
  tests/attachment-prompt-language.spec.ts tests/cli-adapters-attachments.spec.ts \
  tests/cli-adapters-rpc.spec.ts tests/cli-adapters.spec.ts \
  tests/dsh-capability*.spec.ts tests/feature-wiring.spec.ts \
  tests/subagent-delegate.spec.ts tests/interaction-translation*.spec.ts
```

Final affected regression command (64 passed):

```bash
node --import ./tests/register-source-loader.mjs --test --test-reporter=spec \
  tests/session-translation-protection.spec.ts tests/session-prompt-translation.spec.ts \
  tests/session-translation-native.spec.ts tests/attachment-prompt-language.spec.ts
pnpm run typecheck
pnpm run version:check
pnpm run capability:check
pnpm run capability:report
git diff --check
```

Capability verification reports 76 routes, 53 active routes, and no overdue retirement errors. The report was regenerated by its script. Regression coverage includes actual in-memory DSH system-prompt assembly and Cordis middleware ordering, native/external dispatch, all five attachment languages, Windows/Unix paths with spaces, recovery, and legacy detached messages without IDs.

Verification used source-loaded tests and type checks. No build, running-session replay, live translation-provider call, server, Desktop operation, commit, or publishing was performed. DSH complete-section enforcement and runtime policy refresh remain authoritative; existing history is not migrated.

## 2026-10-15 failure-dialog regression

An invalid translation model exposed internal tool descriptions in the user-message recovery popup. Internal prompt translation incorrectly shared the interactive submission-recovery controller. Internal failures now retain original text without creating pending user decisions, and queued fields stop calling the failing model for that assembly. Failed results remain uncached; deactivation cancels active work even when a provider ignores abort. Genuine user submissions retain retry/send/cancel choices in a compact popup without duplicated source text or translation metrics.

All 50 focused source tests passed, including failed tool descriptions and injected catalogs, actual user recovery, compact popup rendering, AI retries, and cancellation:

```bash
node --import ./tests/register-source-loader.mjs --test --test-concurrency=1 \
  tests/session-prompt-translation.spec.ts tests/session-translation-chat.spec.ts \
  tests/session-translation-native.spec.ts tests/session-translation-recovery.spec.ts \
  tests/session-translation-pending-dom.spec.ts
```

Typecheck, version, capability, and locale checks passed. The locale check reported zero blocking violations and 200 warnings in existing log/error strings. Verification remained source-only; the running Stage0 was not rebuilt or restarted.

## 2026-10-20 translation latency optimization and live Stage0 comparison

Work is on `perf/translation-first-turn`; `main` remains at `713dfc1beec2a046c0cb17bb715eb5e557b68f3b`. No commit, merge, installation into Desktop, or restart of an existing service was performed.

Independent system sections, tool descriptions, and parameter descriptions now enter the existing four-slot queue together. Cache keys exclude unused literals and normalize literal order, allowing identical descriptions to reuse results across tools and workspaces. Queued requests check the cache again before calling the provider. Existing cancellation ownership, failure fallback, protected values, and settings invalidation remain covered by regressions.

Verification:

```powershell
node --import ./tests/register-source-loader.mjs --test tests/session-prompt-translation.spec.ts tests/session-translation-protection.spec.ts tests/session-translation-native.spec.ts tests/session-translation-recovery.spec.ts
node ./node_modules/typescript/bin/tsc -p tsconfig.json --noEmit
node scripts/check-version-sync.mjs
node scripts/check-capability-retirement.mjs
git diff --check
```

All 84 source tests passed, including five added regressions for parallel starts, cache reuse, literal protection, queued reuse, and cancellation. Type, version, and capability checks passed. The direct Node commands were used because `pnpm` was initially absent from PATH. A local `pnpm@10.7.1` was subsequently located and used for two complete `pnpm build` runs in separate temporary worktrees; both builds passed.

Live comparison used DSH `0.2.1-rc.2`, Node `v26.7.0`, and the real `deepseek-official / deepseek-flash` provider with reasoning off. The existing local Stage0 runtime (`0.2.1-alpha.2`) lacks the prompt-assembly capability, so a separate runtime was installed under a temporary benchmark directory. Baseline and optimized worktrees each had a separate Stage0 home, plugin state, workspace, and loopback port (`17892` / `17893`). Only the existing DeepSeek API credential reference was copied to the temporary Host credential stores; no credentials were placed in the repository or returned to the Client. The default Desktop and original Stage0 profiles were not modified.

Thirty native-session turns were measured: five samples per implementation for each of three scenarios. Implementation order alternated by sample; sessions ran sequentially. All used the same Chinese input asking for `BENCH_OK` without tools, file, or network operations. Output/reasoning translation was disabled to isolate input and internal-prompt preparation. The real default assembly contained 22 sections and 32 tools; no benchmark fixture tools or sections were injected. Every turn completed and all translation streams succeeded.

| Scenario | Baseline preparation median | Optimized preparation median | Translation requests per turn | Baseline full-turn median | Optimized full-turn median |
| --- | --- | --- | --- | --- | --- |
| Translation cache cleared, new session | 6.248 s | 6.006 s | 6 → 6 | 8.123 s | 7.892 s |
| Cache retained, new session in the same workspace | 2.016 s | 1.933 s | 1 → 1 | 3.941 s | 3.966 s |
| Cache retained, new session in a different workspace | 5.925 s | 2.053 s | 6 → 1 | 8.082 s | 4.113 s |

Preparation is measured from dispatching the native prompt RPC to the first main-model `llm/stream` event; it includes internal and user-input translation. Full-turn time ends when `turn/end` is observed in persisted session events, polled every 100 ms. Per-input `durationMs` remains only that input's translation time. The probe's downstream assembly timer does not cover the entire middleware chain and was excluded from these results.

Different-workspace preparation decreased by 3.872 s (65.35%); full-turn time decreased by 3.969 s (49.11%). Requests decreased deterministically from six to one in all five pairs. Cold-cache and same-workspace measurements do not establish a material improvement: the differences are small relative to live API variance. Clearing the translation module cache does not clear provider connections or process caches, so this is not a full process-cold benchmark. Browser rendering, actual send-button click latency, external CLI startup, and output translation latency were not measured.

Sanitized local evidence is in `C:/Users/Administrator/.config/codingns4dsh/translation-benchmark-20261020/`: `manifest.json`, `summary.json`, `results.json`, `results.csv`, the benchmark scripts, and the optimization patch. The temporary experiment root is recorded in the manifest. Both test listeners were stopped and their temporary credential/authentication files removed after the run. The temporary comparison worktrees were removed after preserving the patch and results. No release runtime was updated.

## 2026-10-20 fixed tool prose localization

The five cold-cache internal requests were traced to the plugin-owned `agent_subagent` description and four parameter descriptions. Their Chinese originals now share a catalog with reviewed English text. Only unchanged tool-owned fields, an English input target, and explicitly absent custom rules use the local path. Added schema/workspace literals must survive unchanged; otherwise the original placeholder-preserving model path applies. User input, other tools, other languages, custom rules, opt-in, exclusions, cancellation, and settings invalidation retain their existing behavior.

The benchmark baseline includes the earlier uncommitted queue/cache optimization; it is not bare `main`. Both variants are separate temporary worktrees and Stage0 profiles using DSH `0.2.1-rc.2`, Node `v26.7.0`, pnpm `10.7.1`, and `deepseek-official / deepseek-flash` with reasoning off. Default Desktop and existing Stage0 were not modified. No commit, merge, release, or installation was performed.

Verification of the final implementation:

- 124 targeted source tests passed: `session-prompt-translation`, `session-translation-protection`, `session-translation-native`, `session-translation-recovery`, `session-translation-rules`, `subagent-delegate`, and `native-subagent-followup`, using `node --import ./tests/register-source-loader.mjs --test`.
- Five new behavioral tests cover zero provider requests for fixed descriptions, custom-rule/other-language fallback, changed/foreign/human text, disabled/excluded/cancelled sessions, and additional protected schema literals.
- Typecheck, version, capability, and i18n checks passed (i18n: zero blocking violations, 200 existing warnings). Both isolated variants passed `pnpm build`; the optimized variant was rebuilt after the protected-literal regression was added.
- An expanded run exposed four failures in `tests/subagent-bridge.spec.ts`: a Windows command assertion and three MCP response timeouts. The same four failures reproduced in the pre-change snapshot (22/26 passed); no unrelated bridge changes were made.

The initial 30-turn trial preceded the final protected-literal check; its results are retained separately and are not the final benchmark. The final code is rebuilt and compared in another 30-turn run, five alternating samples per variant and scenario, after smoke turns warm both processes. Output/reasoning translation stays disabled. Cold clears only the module cache, not process/provider connections. Preparation measures native prompt RPC dispatch to the first main-model stream; total ends at persisted `turn/end` polled every 100 ms. Browser rendering, real external CLI execution, other-language/custom-rule latency, and output translation were not measured.

Final 30-turn results (all turns completed; zero failed translation streams):

| Scenario | Baseline preparation median | Optimized preparation median | Translation requests | Baseline full-turn median | Optimized full-turn median |
| --- | --- | --- | --- | --- | --- |
| Cold translation cache | 4.766 s | 2.496 s | 6 → 1 | 6.526 s | 4.371 s |
| Warm cache, new session | 1.943 s | 1.909 s | 1 → 1 | 3.893 s | 3.789 s |
| Warm cache, new workspace | 1.868 s | 1.828 s | 1 → 1 | 3.969 s | 3.763 s |

Cold preparation decreased 2.270 s (47.63%); full-turn median decreased 2.155 s (33.02%). Warm-cache differences do not establish a material improvement. The deterministic benefit is removal of all five fixed-description requests, leaving only the real user-input translation. No user-input/lifecycle overlap, concurrency change, or new persistent cache was needed for this result.

Sanitized evidence and reproducible scripts are saved in `C:/Users/Administrator/.config/codingns4dsh/translation-local-prose-20261020/`. The manifest includes the baseline definition and final normalized source hashes. The final patch and new catalog source are retained alongside the results. Both temporary test listeners were stopped. Automatic command policy rejected the combined stop/delete command without a specific reason; the process-only lifecycle script then succeeded. Temporary credential/authentication files were not deleted by another mechanism after that rejection.

Both temporary comparison worktrees were removed after preserving code and results; unrelated existing worktrees remain. Temporary Host profiles remain under `C:/Users/Administrator/AppData/Local/Temp/codingns-translation-local-9d93c955/`, including the credential/authentication files whose deletion was rejected. No benchmark listener remains on ports 17892/17893.

## 2026-10-24 path/prose boundary fix

- [x] DONE: Prevent unquoted paths from swallowing adjacent Chinese instructions. Observable result: a first-turn message beginning with a PPT path followed by a Chinese comma sends translated prose while preserving the path verbatim. Depends on the existing literal-protection and input-translation services; no new dependency. Read requirements 2/5/7, Design / Data ownership, and the protection/native translation suites first. Change `src/host/features/session-translation-protection.ts`, `tests/session-translation-protection.spec.ts`, `tests/session-translation-native.spec.ts`, and this spec's design/task records. Exclude UI changes, history migration, provider changes, builds, live-profile operations, commits, and publishing. Verify failing-first regressions, source-loaded translation/attachment suites, type/version/capability checks, and `git diff --check`.

Branch: `fix/translation-path-prose-boundary`, created from local `main` at `afc7bd66b4077bd421ac17e1bb9fb4de91f742b0`.

The new protection regressions failed before the source fix: 37 passed, 4 failed. The original message shape was mistaken for one protected path, causing an early return without a translation-provider call. Unquoted paths now stop at `，。；：！？、`; quoted/code/known-literal paths still preserve spaces and punctuation. Quoted relative and UNC paths use the same path-prefix recognition so punctuation-bearing names remain protected too. All 41 protection tests pass, including the reported first-turn wording for Claude Code and native DSH. Two additional first-turn integration tests exercise the real translation service through pre-step and native/external submission, preserving original audit text and checking the actual external-driver prompt with exactly one translation request.

Final source verification: **274/274 tests passed across 18 files**, zero failures or skips. The selection includes all `session-translation*.spec.ts`, all `interaction-translation*.spec.ts`, `session-prompt-translation.spec.ts`, and `attachment-prompt-language.spec.ts`:

```powershell
$tests = @(Get-ChildItem -LiteralPath 'tests' -File | Where-Object { $_.Name -like 'session-translation*.spec.ts' -or $_.Name -like 'interaction-translation*.spec.ts' } | Sort-Object Name | ForEach-Object { 'tests/' + $_.Name })
$tests += @('tests/session-prompt-translation.spec.ts', 'tests/attachment-prompt-language.spec.ts')
node --import ./tests/register-source-loader.mjs --test --test-concurrency=1 @tests
node ./node_modules/typescript/bin/tsc -p tsconfig.json --noEmit
node scripts/check-version-sync.mjs
node scripts/check-capability-retirement.mjs
git diff --check
```

Type, version, capability and whitespace checks pass. The source test log is local `data/logs/translation-path-prose-28756cce48124be9961315932eaea590.log`. React server-rendering tests emit existing `useLayoutEffect` warnings. No bundle build, live-provider translation, browser/Stage0 operation, installation, commit, or publishing was performed; installed-runtime verification remains unperformed.

An expanded 19-file run that also included `cli-adapters-attachments.spec.ts` passed 280/283 tests. Its three failures reproduce on unchanged `main` in a separate worktree (6/9 attachment tests pass): the Claude fake child lacks `.once`, and ACP/Gemini assertions construct Windows file URIs incorrectly. These baseline failures remain outside this fix. The temporary baseline worktree remains at `C:/Users/Administrator/AppData/Local/Temp/codingns-translation-baseline-a28fa387cc3a47b8b0fc553b4594a66f`, with a `node_modules` junction to this checkout. Automatic command policy rejected its cleanup command before execution; no alternate deletion was attempted.

Environment note: installed pnpm 11.22.0 automatically ran dependency synchronization before `pnpm run typecheck`, updated local `node_modules` from older DSH packages to the versions in `package.json`, and then stopped on `ERR_PNPM_IGNORED_BUILDS` for `@deepseek-ai/dsh-subprocess-local`. The generated `pnpm-workspace.yaml` and lockfile changes were removed/reverted to their initial state; no dependency metadata changes remain. Subsequent checks used the direct Node commands above, and the final 274-test run and baseline comparison used the synchronized dependencies. The local dependency synchronization was not undone; no dependency build scripts were approved.

## 2026-10-24 isolated Stage0 verification

- [x] DONE: Configure an isolated Stage0 and verify the path/prose fix with live translation. Observable result: three real first-turn sessions complete with translated prose and an unchanged full path, including Claude's actual provider input. Depends on the completed path-boundary fix and a working existing Stage0 DeepSeek API-key reference. Read `scripts/run-dsh-stage0.sh`, `scripts/stage0-runtime.mjs`, `dsh-stage0.patch.yml`, and the Stage0 development notes first. Change only local runtime/profile/verification files and this task evidence; no production source change. Exclude Desktop configuration, existing Stage0 state, original sessions, unrelated attachment fixes, release and publishing. Verify a successful build, built-output tests, authenticated Stage0 RPC, persisted DSH audit events, and Claude raw history. Browser UI remains outside the completed acceptance.

No existing Stage0 server or compiler watcher was running. Installed a dedicated DSH `0.2.1-rc.2` runtime using the existing local pnpm `10.7.1` with `--ignore-scripts`; no dependency build scripts were enabled. The runtime installation reports upstream OpenTelemetry peer-version warnings. Built the current branch successfully with `pnpm run build` using pnpm 10.7.1. The build reports existing dynamic-import/deprecated-option warnings. Built-output tests passed **43/43**, zero failures/skips:

```powershell
node --import ./tests/register-css-loader.mjs --test --test-concurrency=1 tests/session-translation-native.spec.ts tests/session-translation.spec.ts
```

The dedicated Stage0 runs on **127.0.0.1:17894** using Home `C:/Users/Administrator/.dsh-stage0-path-prose`, profile `stage0`, state `C:/Users/Administrator/.config/codingns4dsh/stage0-path-prose/state`, and a source junction to this checkout. Existing Desktop and `.dsh-stage0-020` profiles/sessions were not modified. Only the existing Stage0 `DEEPSEEK_API_KEY` ref was copied into the new Host credential store; browser authentication and Desktop credentials were not copied. Telemetry is disabled in this profile. Watch mode is off to retain a stable tested build; normal Stage0 HMR remains available. The server is left running for manual inspection.

Live verification passed **3/3** with real `deepseek-official / deepseek-flash` input translation:

| Case | Session | Evidence |
| --- | --- | --- |
| Native, unquoted Chinese PPT path immediately followed by a Chinese comma and prose | `session-stage0-path-prose-07425356-8158-425e-a8f9-b0e8941fac30` | Native persisted input is translated, audit original unchanged; translation 1284 ms |
| Claude Code, same path/prose shape, model `hl/claude-opus-5-5` | `session-stage0-path-prose-b9549c38-5519-457e-a2b4-e240e8a5dfb3` | Claude raw provider history contains the exact translated input; translation 828 ms |
| Native, quoted path whose filename contains Chinese comma/semicolon | `session-stage0-path-prose-9b5f47bc-4aee-4e72-9436-1a0f27e90127` | Complete punctuation-bearing path preserved exactly once, surrounding prose translated; translation 1188 ms |

Each session completed, returned `STAGE0_PATH_PROSE_OK`, and made zero tool calls. No actual courseware was read or modified. The test message uses the reported Chinese instructional wording with a synthetic path inside the isolated workspace and a no-tools regression-test instruction. Verification checks that no Chinese remains outside the preserved path, the original audit text is exact, the successful translation model is recorded, and the turn has a completed terminal outcome.

The first verifier attempt incorrectly required `rawStoreRef` to be persisted immediately for Claude; it is optional despite a valid `providerSessionId`. The test was corrected to locate that session ID's real Claude JSONL and reverify the already-completed sessions without sending duplicate turns. This was a verifier assumption, not a product-code change.

Local reproducible entry points and evidence (no credentials in JSON evidence):

```powershell
# Inspect persisted evidence without sending more prompts:
node "$env:USERPROFILE/.config/codingns4dsh/stage0-path-prose/stage0-path-prose-verify.mjs" --resume
# Create three new verification sessions:
node "$env:USERPROFILE/.config/codingns4dsh/stage0-path-prose/stage0-path-prose-verify.mjs"
# Start only when port 17894 is free; otherwise use the existing server:
pwsh.exe -NoLogo -NoProfile -File "$env:USERPROFILE/.config/codingns4dsh/stage0-path-prose/start.ps1"
```

`environment.json`, `verification.json`, `verification-attempt1.json`, `built-tests.log`, `launcher.pid`, and the saved RPC/verifier scripts are under `C:/Users/Administrator/.config/codingns4dsh/stage0-path-prose/`. `stdout.log` contains the private browser authentication URL and must not be shared. All configuration, sessions and credentials remain local, outside tracked source. Browser rendering/click behavior was not tested; HTTP/RPC and real provider verification do not establish UI acceptance. No commit, merge, push or release was performed.

## 2026-10-26 translation failure diagnostics

- [x] DONE: Preserve structured translation failures through native/external projections, input audit history, and client readers; show the saved failure category in translation details. Observable result: a failed translation retains its category, retryability, duration, and reported tokens after serialization, and the popup shows an English/Chinese explanation rather than only a generic failed status. Depends on the existing `SessionTranslationFailure` contract, classifier, projector, and popup. Read Requirements 5/6/8, Design / Data ownership, and the translation/native/chat tests first. Change `src/shared/contracts/session-translation.ts`, `src/host/cli-adapters/{feature,dsh-message-projector}.ts`, `src/client/{session-translation-chat,locales/panels}.ts`, the three corresponding translation test suites, and this spec. Exclude changes to translation validation, retry policy, token accounting, provider requests, raw-error logging, history migration, build output, running installations, commits, and publishing. Verify failing-first regressions, affected source suites, TypeScript, version/capability/i18n checks, and `git diff --check`.

Branch: `fix/translation-failure-diagnostics`, created from local `main` at `436e1e0`.

Failing-first evidence: all eight focused regressions failed before implementation: external/native reply and reasoning serialization dropped `failure`, exception fallbacks lacked a classified reason, client history dropped diagnostics, and the popup lacked a saved/unknown explanation. The same eight regressions pass after implementation.

Final source verification: **301/301 tests passed across 20 files**, zero failures or skips. Coverage includes English/Chinese explanations for every existing failure category, old records without diagnostics, sanitized history readers, input send/retry/cancel, native/external reply and reasoning projections, exception classification, and retained reported usage. Local log: `data/logs/translation-failure-diagnostics-20261026-035027.log`.

```powershell
$tests = @(Get-ChildItem -LiteralPath 'tests' -File | Where-Object { $_.Name -like 'session-translation*.spec.ts' -or $_.Name -like 'interaction-translation*.spec.ts' } | Sort-Object Name | ForEach-Object { 'tests/' + $_.Name })
$tests += @('tests/session-prompt-translation.spec.ts', 'tests/dsh-message-projector.spec.ts', 'tests/cli-adapters-turn-status.spec.ts', 'tests/attachment-prompt-language.spec.ts')
node --import ./tests/register-source-loader.mjs --test --test-concurrency=1 @tests
node ./node_modules/typescript/bin/tsc -p tsconfig.json --noEmit
node scripts/check-version-sync.mjs
node scripts/check-capability-retirement.mjs
node scripts/check-client-i18n.mjs
git diff --check
```

TypeScript, version, capability and whitespace checks pass. Localization reports zero blocking violations and 201 nonblocking warnings. Direct Node commands avoid the previously documented pnpm 11 automatic dependency synchronization; no dependency files changed.

An expanded 22-file source run, also including `cli-adapters-rpc.spec.ts` and `cli-adapters-stream.spec.ts`, passed 368/375 tests. The seven failures are six Claude mock-process/permission-argument assertions and a Codex MCP assertion expecting a POSIX executable path on Windows. Those two test files and the Claude/standard-stream/Codex drivers are byte-for-byte unchanged from `main` (`git diff --exit-code main -- ...` passed). A clean-main comparison command was rejected by execution policy before process creation; no baseline test or temporary worktree was created, and baseline execution remains unverified. These fixtures were not changed for this diagnostic fix. React server-rendering tests emit the existing `useLayoutEffect` warnings.

No bundle build, live provider call, application/profile change, installation, browser/Stage0 test, commit, push or release was performed. Installed-runtime/browser acceptance remains unperformed. Existing records without failure details cannot be repaired by this change.

## 2026-10-26 isolated Stage0 diagnostic verification

- [x] DONE: Configure a separate Stage0 and verify saved translation failure details in the actual runtime and browser. Observable result: native reply and reasoning retain `invalid-response`, retryability, original text, duration, and reported usage; the English details popup shows the explanation and usage before and after reload. Depends on the completed diagnostic fix, installed DSH `0.2.1-rc.3`, and the user's follow-up authorization for Stage0 setup/builds. Read this spec, `scripts/run-dsh-stage0.sh`, `scripts/stage0-runtime.mjs`, and `dsh-stage0.patch.yml` first. Change only local isolated profile/snapshot/fixture/verifier files and this task evidence. Exclude Desktop and existing Stage0 configuration, credentials, original sessions, upstream provider calls, production source changes, commits, and publishing. Verify a snapshot build, focused built-output tests, persisted runtime events, browser interactions/reload, source hashes, and existing listener identities.

An existing Stage0 and compiler watcher already owned the repository output. To avoid replacing their bundles, copied the current tracked working files (including the uncommitted fix) to a separate snapshot under `C:/Users/Administrator/.config/codingns4dsh/stage0-translation-diagnostics-20261026/workspace`. Only its dependencies are junction-linked to the repository. Built that snapshot successfully using pnpm `10.7.1`; the repository build output was not rebuilt for this verification. SHA256 checks confirm that all **704 source files** in the built snapshot match both the recorded source hashes and the current branch.

The new runtime uses Home `C:/Users/Administrator/.dsh-stage0-translation-diagnostics-20261026`, profile `stage0`, a separate plugin state directory, loopback **127.0.0.1:17895**, telemetry off, and watch mode off. No credentials were copied. Existing listeners on 17890 (PID 3004) and 17891 (PID 10512) remain unchanged. The new server is left running for inspection; no existing process was stopped.

Verification results:

- Snapshot `pnpm run build`: passed. Exact output is local `build.log`; existing build warnings remain in that log.
- Built-output tests: **64/64 passed**, zero failures/skips, using the command below in the snapshot. These load built modules, not the in-memory source loader.
- Native runtime persistence: **2/2 passed**, reply and reasoning, in session `session-stage0-synthetic-diagnostics-46c67bee-a14c-43a7-8cbf-4e048a1f6f63`. Both records preserve `failure: { code: 'invalid-response', retryable: false }`, duration, model, original text, and **1273 synthetic reported tokens per translation**. The turn completes and makes zero tool calls.
- Isolated headless Chrome: **4/4 passed**, reply/reasoning details before and after reload. Each shows the English validation-failure explanation, model, original/fallback text, and `1273 tok`; neither raw fixture responses nor the unknown-details fallback appear. No browser page errors occurred. Screenshots were saved, and the reply/reasoning layouts were visually inspected.
- Isolation/source-hash checks and `git diff --check`: passed.

```powershell
# Run from the isolated snapshot, not the repository:
node --import ./tests/register-css-loader.mjs --test --test-concurrency=1 tests/session-translation-native.spec.ts tests/session-translation.spec.ts tests/session-translation-chat.spec.ts
# Verify the running isolated server (creates a new synthetic session):
$root = Join-Path $HOME '.config/codingns4dsh/stage0-translation-diagnostics-20261026'
node (Join-Path $root 'verify-rpc.mjs')
node (Join-Path $root 'verify-browser.mjs')
```

The fixture is a clearly named local LLM adapter, not an upstream service. Its translator returns an invalid response shape with synthetic usage to exercise the real validation and history/UI paths; **paid provider requests and real billed tokens are zero**. Initial harness attempts lacked the fixture's bundle `insert` operation and therefore returned `NO_ADAPTER`; that local fixture configuration was corrected before successful acceptance. Browser setup also required explicit Workspace membership for RPC-created sessions; the verifier now creates them with `workspaceId`. No product code was changed during Stage0 setup.

Local evidence and reproducibility instructions are in the directory above: `README.md`, `environment.json`, `source-hashes.json`, `build.log`, `built-tests.log`, `rpc-verification.json`, `browser-verification.json`, `isolation-verification.json`, the verification scripts, and four `browser-*.png` screenshots. Startup logs contain private authentication URLs and must not be shared. `start.ps1` refuses an occupied port; the local README documents authenticated inspection, restart, and narrowly scoped shutdown.

This follow-up establishes native synthetic-provider runtime and English browser acceptance, not the cause of the original session's missing historical diagnostic. Real upstream providers, live external CLI agents, input-failure recovery, successful retry, Chinese browser rendering, and legacy-record browser behavior were not exercised here; their applicable source-test coverage remains separate. The earlier 301-test source results and seven expanded-suite fixture failures are unchanged. No full-suite run, Desktop installation, commit, push, or release was performed.
