/**
 * 断连保留 —— 纯逻辑探针:与官方 dsh-llm 的生产者/装配器逐例等价性验证。
 *
 * 验证的是「同一份持久化数据,两种重组途径必须产出同样的可见块序列」:
 * - 官方途径:AssistantStreamAccumulator(生产紧凑记录)→ BlockAssembler
 *   逐 chunk 组装 → interruptedBlocks()(服务端持久化用户中断内容时的口径);
 * - 插件途径:accumulator.snapshot()(= assistant/attempt.stream 的精确形态)
 *   → 我们的 partialBlocksFromAttemptStream(展开 + 重组)。
 *
 * 用例分两层:
 * 1. 手工构造的定向用例(GLM 断连形态、delta-only、工具调用、空流、坏记录…);
 * 2. 随机 fuzz:几百条随机合法 chunk 序列,逐条断言两边完全一致。
 *
 * 运行:node probe/attempt-keep.logic.test.mjs(在仓库根目录下)。
 */
import { build } from 'esbuild'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const HOST = '/home/yangzhe/.nvm/versions/node/v22.23.2/lib/node_modules/@deepseek-ai/dsh/node_modules'

// —— 把插件源码里的纯逻辑部分编成可 import 的 ESM(类型导入被擦除) ——
const tmp = mkdtempSync(join(tmpdir(), 'webe-attempt-'))
await build({
  entryPoints: [new URL('../src/client/attempt-keep.ts', import.meta.url).pathname],
  outfile: join(tmp, 'attempt-keep.mjs'),
  bundle: true,
  format: 'esm',
  platform: 'node',
  target: 'es2022',
  // react/cordis 等都不会出现在纯逻辑部分;以防万一按外部处理
  external: ['react', 'react/*', '@deepseek-ai/*'],
})
const { partialBlocksFromAttemptStream, assembleInterruptedBlocks } = await import(pathToFileURL(join(tmp, 'attempt-keep.mjs')).href)

// —— 官方 dsh-llm(宿主同一份实现):生产者 + 服务端装配器 ——
const llm = await import(pathToFileURL(join(HOST, '@deepseek-ai/dsh-llm/lib/index.js')).href)
const { AssistantStreamAccumulator, BlockAssembler } = llm

let failures = 0
let checks = 0

/** 官方块({type,text}) → 插件块({kind,text}),便于比较。 */
const officialToMine = (blocks) => blocks.map((b) => ({ kind: b.type, text: b.text }))

/**
 * 单条用例:chunks → 同时喂官方 accumulator+assembler 与(经 snapshot)插件重组,
 * 断言两边可见块序列一致。
 */
function expectEquivalent(name, chunks) {
  const accumulator = new AssistantStreamAccumulator()
  const assembler = new BlockAssembler()
  let time = 1_000
  for (const chunk of chunks) {
    const timed = accumulator.push({ time: ++time, chunk })
    assembler.push(timed.chunk)
  }
  const official = officialToMine(assembler.interruptedBlocks())
  const mine = partialBlocksFromAttemptStream(accumulator.snapshot())
  checks++
  const a = JSON.stringify(official)
  const b = JSON.stringify(mine)
  if (a !== b) {
    failures++
    console.error(`FAIL ${name}\n  official: ${a}\n  mine:     ${b}`)
    return false
  }
  console.log(`ok   ${name} (${mine.length} 块)`)
  return true
}

function expectDeepEqual(name, actual, expected) {
  checks++
  const a = JSON.stringify(actual)
  const b = JSON.stringify(expected)
  if (a !== b) {
    failures++
    console.error(`FAIL ${name}\n  actual:   ${a}\n  expected: ${b}`)
  } else {
    console.log(`ok   ${name}`)
  }
}

// ---------------------------------------------------------------------------
// 一、定向用例(chunk 形态抄自 dsh-llm 的流协议)
// ---------------------------------------------------------------------------

// 1. GLM 断连典型形态:思考块完整闭合 → 正文块开始、增量到一半被掐断(无 block-end)
expectEquivalent('glm-cut: closed reasoning + open text cut', [
  { type: 'block-start', index: 0, blockType: 'reasoning' },
  { type: 'reasoning-delta', index: 0, text: '用户要的是' },
  { type: 'reasoning-delta', index: 0, text: '保留断连前内容' },
  { type: 'block-end', index: 0, block: { type: 'reasoning', text: '用户要的是保留断连前内容' } },
  { type: 'block-start', index: 1, blockType: 'text' },
  { type: 'text-delta', index: 1, text: '我来分析这个' },
  { type: 'text-delta', index: 1, text: '问题,首先' },
  // —— 连接在此被掐断:没有 block-end、没有 finish ——
])

// 2. 思考被掐断:reasoning 块开着,一个字正文都没有
expectEquivalent('cut inside reasoning only', [
  { type: 'block-start', index: 0, blockType: 'reasoning' },
  { type: 'reasoning-delta', index: 0, text: '让我想想…敏感词出现' },
])

// 3. delta-only 协议(无 block-start/block-end)
expectEquivalent('delta-only stream', [
  { type: 'reasoning-delta', index: 0, text: 'think ' },
  { type: 'text-delta', index: 1, text: 'answer body' },
])

// 4. 工具调用中途断连:工具调用必须被丢弃,文本保留
expectEquivalent('tool-call dropped, text kept', [
  { type: 'block-start', index: 0, blockType: 'text' },
  { type: 'text-delta', index: 0, text: '我先查一下文件' },
  { type: 'block-end', index: 0, block: { type: 'text', text: '我先查一下文件' } },
  { type: 'block-start', index: 1, blockType: 'tool-call' },
  { type: 'tool-call-delta', index: 1, id: 'call_1', name: 'bash', argumentsDelta: '{"comm' },
  { type: 'tool-call-delta', index: 1, id: 'call_1', argumentsDelta: 'and":"ls"}' },
])

// 5. 断在工具调用之后、下一个文本块开头之前(工具调用闭合了但没派发)
expectEquivalent('closed tool-call before cut', [
  { type: 'block-start', index: 0, blockType: 'tool-call' },
  { type: 'tool-call-delta', index: 0, id: 'call_9', name: 'read', argumentsDelta: '{"path":"a"}' },
  { type: 'block-end', index: 0, block: { type: 'tool-call', id: 'call_9', name: 'read', arguments: { path: 'a' } } },
  { type: 'block-start', index: 1, blockType: 'text' },
  { type: 'text-delta', index: 1, text: '文件内容是…' },
])

// 6. 纯空白内容的块:不可见
expectEquivalent('whitespace-only invisible', [
  { type: 'block-start', index: 0, blockType: 'text' },
  { type: 'text-delta', index: 0, text: '  \n ' },
])

// 7. 空流
expectEquivalent('empty stream', [])

// 8. 只有 usage/finish(连接建立即失败)
expectEquivalent('usage/finish only', [
  { type: 'usage', usage: { input: 10, output: 2 } },
  { type: 'finish', finish: { kind: 'error', message: 'connection reset', code: 'NETWORK' } },
])

// 9. 多块交错(块序 ≠ index 序:index 1 先出现)
expectEquivalent('interleaved block order', [
  { type: 'block-start', index: 1, blockType: 'text' },
  { type: 'text-delta', index: 1, text: '先输出的正文' },
  { type: 'block-start', index: 0, blockType: 'reasoning' },
  { type: 'reasoning-delta', index: 0, text: '后输出的思考' },
])

// 10. block-end 携带的最终文本覆盖累计增量(闭合块以 end 为准)
expectEquivalent('block-end text wins', [
  { type: 'block-start', index: 0, blockType: 'text' },
  { type: 'text-delta', index: 0, text: '草稿' },
  { type: 'block-end', index: 0, block: { type: 'text', text: '最终文本' } },
])

// 11. 未知块类型:丢弃
expectEquivalent('unknown block type dropped', [
  { type: 'block-start', index: 0, blockType: 'video' },
  { type: 'block-end', index: 0, block: { type: 'video', url: 'x' } },
  { type: 'block-start', index: 1, blockType: 'text' },
  { type: 'text-delta', index: 1, text: '正文保留' },
])

// 12. 直接调组装器:闭合后的增量被忽略(畸形流防御)
expectDeepEqual(
  'delta after block-end ignored',
  assembleInterruptedBlocks([
    { type: 'block-start', index: 0, blockType: 'text' },
    { type: 'text-delta', index: 0, text: '完成' },
    { type: 'block-end', index: 0, block: { type: 'text', text: '完成' } },
    { type: 'text-delta', index: 0, text: '追加' },
  ]),
  [{ kind: 'text', text: '完成' }],
)

// 13. 直接调组装器:坏记录不致命(展开层跳过)
expectDeepEqual(
  'malformed records skipped',
  partialBlocksFromAttemptStream([
    null,
    'garbage',
    42,
    { type: 'text-chunks', time0: 1, index: 0, dt: [], texts: ['可见正文'] },
    { type: 'text-chunks', time0: 2, index: 'x', dt: [], texts: ['坏 index'] },
    { type: 'text-chunks', time0: 3, index: 1, dt: [], texts: [123] },
    { type: 'nonsense' },
  ]),
  [{ kind: 'text', text: '可见正文' }],
)

// ---------------------------------------------------------------------------
// 二、随机 fuzz:官方装配器 vs 插件重组,逐序列断言一致
// ---------------------------------------------------------------------------

let seed = 0x2f6e2b1
function rand() {
  // xorshift32,固定种子保证可复现
  seed ^= seed << 13
  seed ^= seed >>> 17
  seed ^= seed << 5
  return (seed >>> 0) / 0x1_0000_0000
}
const pick = (list) => list[Math.floor(rand() * list.length)]

/** 生成一条「协议合法」的随机 chunk 序列(块生命周期自洽)。 */
function randomChunkSequence() {
  const chunks = []
  const open = new Map() // index → kind
  let index = 0
  const nBlocks = 1 + Math.floor(rand() * 4)
  for (let b = 0; b < nBlocks; b++) {
    const kind = pick(['text', 'reasoning', 'tool-call', 'other'])
    const i = index++
    chunks.push({ type: 'block-start', index: i, blockType: kind })
    open.set(i, kind)
    const nDeltas = Math.floor(rand() * 4)
    for (let d = 0; d < nDeltas; d++) {
      const text = pick(['你好', 'world', ' ', '\n', '敏感词', 'x'])
      if (kind === 'text') chunks.push({ type: 'text-delta', index: i, text })
      else if (kind === 'reasoning') chunks.push({ type: 'reasoning-delta', index: i, text })
      else if (kind === 'tool-call') {
        chunks.push({
          type: 'tool-call-delta',
          index: i,
          id: rand() < 0.1 ? '' : `call_${i}`,
          ...(rand() < 0.5 ? { name: 'bash' } : {}),
          argumentsDelta: text,
        })
      }
    }
    if (rand() < 0.6) {
      // 闭合(携带最终块;text/reasoning 用累计语义生成)
      if (kind === 'text') chunks.push({ type: 'block-end', index: i, block: { type: 'text', text: pick(['完整正文', ' ', '最终文本']) } })
      else if (kind === 'reasoning') chunks.push({ type: 'block-end', index: i, block: { type: 'reasoning', text: pick(['思考完毕', ' ']) } })
      else if (kind === 'tool-call') chunks.push({ type: 'block-end', index: i, block: { type: 'tool-call', id: `call_${i}`, name: 'bash', arguments: {} } })
      else chunks.push({ type: 'block-end', index: i, block: { type: 'image', url: 'u' } })
      open.delete(i)
    }
    if (rand() < 0.2) chunks.push({ type: 'usage', usage: { input: 10, output: b } })
  }
  if (rand() < 0.3) chunks.push({ type: 'finish', finish: { kind: 'stop' } })
  return chunks
}

let fuzzPass = 0
for (let n = 0; n < 300; n++) {
  const chunks = randomChunkSequence()
  const accumulator = new AssistantStreamAccumulator()
  const assembler = new BlockAssembler()
  let time = 5_000
  for (const chunk of chunks) {
    const timed = accumulator.push({ time: ++time, chunk })
    assembler.push(timed.chunk)
  }
  const official = JSON.stringify(officialToMine(assembler.interruptedBlocks()))
  const mine = JSON.stringify(partialBlocksFromAttemptStream(accumulator.snapshot()))
  checks++
  if (official !== mine) {
    failures++
    console.error(`FAIL fuzz #${n}\n  official: ${official}\n  mine:     ${mine}\n  chunks:   ${JSON.stringify(chunks)}`)
    break
  }
  fuzzPass++
}
console.log(`ok   fuzz x${fuzzPass} (官方 BlockAssembler.interruptedBlocks ≡ 插件重组)`)

// ---------------------------------------------------------------------------
rmSync(tmp, { recursive: true, force: true })
console.log(`\n${failures === 0 ? 'PASS' : 'FAIL'}: ${checks - failures}/${checks} 项通过`)
process.exit(failures === 0 ? 0 : 1)
