/**
 * 断连保留 —— 装配链路探针:真实 ui-conversation 装配器 × 插件产物。
 *
 * 不 mock 任何装配逻辑:从宿主安装目录加载真实 dsh-client-ui-conversation
 * 浏览器 bundle(递归解析其 externals),构造真实的
 * ConversationEventRegistry / ConversationViewRegistry / ConversationNodeAssembler,
 * 再加载本插件真实构建产物 lib/client.js,走生产同款路径 apply() 注册定义;
 * 最后把「GLM 断连」场景的事件序列喂进装配器,断言:
 * - 透传 chat 视图里出现插件产出的 assistant-step 节点(kind/数据/锚点);
 * - 节点 location 解析到 step(过程分组的入场券);
 * - 事件行序:多次失败尝试按发生顺序排列、都在 turn 错误行之前;
 * - 空内容的 attempt 不占行;live 结算(settleAssistant)与历史重放
 *   (replaceWindow)两条路径行为一致;
 * - 官方同款约束不触发(节点 key 稳定、不撤回已产出节点)。
 *
 * 运行:node probe/attempt-keep.assembly.test.mjs(在仓库根目录下,先 npm run build)。
 */
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const HOST = '/home/yangzhe/.nvm/versions/node/v22.23.2/lib/node_modules/@deepseek-ai/dsh/node_modules'
const SCOPED = join(HOST, '@deepseek-ai')
const REPO = new URL('..', import.meta.url).pathname

// ---------------------------------------------------------------------------
// 一、浏览器 bundle 加载器:剥 __ModuleLoader__ 包装、解析 externals
// ---------------------------------------------------------------------------

/**
 * 官方 dsh-client-store.notifySubscribers 的逐字转写(从 web shell 资产的
 * 压缩源直接抄的语义:逐个调用、单订阅者异常只打日志)。
 * 装配链路(ConversationDefinitionRegistry.refresh)只用到这一个函数;
 * createSnapshotStore/defineStore 只被 React 组件路径引用,本探针不触及。
 */
function notifySubscribers(set, label, ...args) {
  for (const listener of [...set]) {
    try {
      listener(...args)
    } catch (error) {
      console.error(`${label} subscriber failed:`, error)
    }
  }
}

/** 惰性外部依赖占位:装配路径不应触碰组件级依赖,碰了就响亮报错。 */
function inertExternal(name) {
  return new Proxy(
    {},
    {
      get() {
        throw new Error(`装配探针不应依赖 ${name}(该 external 只被组件路径使用)`)
      },
    },
  )
}

/** 已加载的浏览器 bundle 模块表。 */
const clientModules = new Map()

async function loadClientBundle(name) {
  if (clientModules.has(name)) return clientModules.get(name)
  // name 形如 '@deepseek-ai/dsh-client-ui-conversation'(含 scope)
  const source = readFileSync(join(HOST, name, 'lib/client.js'), 'utf8')
  let captured
  const window = { __ModuleLoader__: { load(entry) { captured = entry } } }
  // bundle 顶层是 window.__ModuleLoader__.load({id, factory}) 调用
  const run = new Function('window', 'self', 'globalThis', source)
  run(window, window, globalThis)
  if (captured?.factory === undefined) throw new Error(`bundle ${name} 未注册工厂`)
  // 工厂自建 module 并返回 module.exports(签名只吃 require),用返回值
  const exports_ = captured.factory(makeRequire())
  clientModules.set(name, exports_)
  return exports_
}

const nodeRequire = createRequire(import.meta.url)
const hostRequire = createRequire(join(SCOPED, 'noop.js'))
const cordisNamespace = await import(pathToFileURL(join(SCOPED, 'cordis/lib/index.js')).href)

function makeRequire() {
  return (request) => {
    if (request === 'react') return nodeRequire('react')
    if (request === 'react/jsx-runtime') return nodeRequire('react/jsx-runtime')
    if (request === 'react-dom') return nodeRequire('react-dom')
    if (request === '@deepseek-ai/cordis') return cordisNamespace
    if (request === 'zod') return hostRequire('zod')
    if (request === '@deepseek-ai/dsh-client-store') {
      return { notifySubscribers, createSnapshotStore: undefined, defineStore: undefined, shallowEqual: undefined }
    }
    if (request === '@deepseek-ai/dsh-client-ui-slots' || request === '@deepseek-ai/dsh-client-ui-primitives') {
      return inertExternal(request)
    }
    throw new Error(`探针未实现的外部依赖: ${request}`)
  }
}

const uiConversation = await loadClientBundle('@deepseek-ai/dsh-client-ui-conversation')
const { ConversationEventRegistry, ConversationViewRegistry, ConversationNodeAssembler } = uiConversation

// ---------------------------------------------------------------------------
// 二、真实装配器 + 透传 chat 视图
// ---------------------------------------------------------------------------

/** cordis 上下文的最小替身:注册表只用 ctx.effect(立即执行、返回清理函数)。 */
function fakeEffectContext() {
  return {
    effect(fn) {
      let cleanup
      try {
        cleanup = fn()
      } catch (error) {
        throw error
      }
      return () => {
        try {
          cleanup?.()
        } catch {
          /* 忽略清理错误 */
        }
      }
    },
    on() {
      return () => {}
    },
  }
}

const eventRegistry = new ConversationEventRegistry(fakeEffectContext())
const viewRegistry = new ConversationViewRegistry(fakeEffectContext())

/** 透传 chat 视图:按 anchorSeq 排序返回全部节点(复刻官方 orderedVisibleChatNodes 的主序)。 */
viewRegistry.register({
  target: 'chat',
  create: () => ({
    empty: [],
    replace: (input) => [...input.nodes].sort((a, b) => a.anchorSeq - b.anchorSeq),
    apply: (input) => input.upserts,
  }),
})

const assembler = new ConversationNodeAssembler(eventRegistry, viewRegistry)
// 激活 chat 目标:未激活的视图不物化快照(生产由 UI 消费者激活)
assembler.activateTarget('chat')

// ---------------------------------------------------------------------------
// 三、加载插件真实产物,走生产同款 apply() 注册
// ---------------------------------------------------------------------------

/** 加载本插件的 lib/client.js(与浏览器同一份字节)。 */
async function loadPlugin() {
  const source = readFileSync(join(REPO, 'lib/client.js'), 'utf8')
  let captured
  const window = { __ModuleLoader__: { load(entry) { captured = entry } } }
  const run = new Function('window', 'self', 'globalThis', source)
  run(window, window, globalThis)
  return captured.factory(makeRequire())
}

const plugin = await loadPlugin()
if (typeof plugin.apply !== 'function' || !Array.isArray(plugin.inject)) {
  throw new Error('插件产物缺 apply/inject 导出')
}

/** 「什么都行」代理:applyAttemptKeep 之外的装配链路(notify/quota/native-open)在探针里没有真实服务,统一吞噬,避免它们的 TypeError 干扰本探针。 */
function anythingProxy() {
  const fn = function () {
    return proxy
  }
  const proxy = new Proxy(fn, {
    get(target, prop) {
      if (prop === Symbol.toPrimitive) return () => 'anything'
      if (prop === 'then') return undefined
      return proxy
    },
    apply() {
      return proxy
    },
  })
  return proxy
}

/** 插件 apply 需要的最小 ctx:inject 立即触发、effect 立即执行。 */
const pluginCtxSlots = {
  inject() {
    return () => {}
  },
  register() {
    return anythingProxy()
  },
  registerFactory() {
    return anythingProxy()
  },
}
const pluginCtxBase = {
  ...fakeEffectContext(),
  inject(names, callback) {
    // 生产语义:依赖齐了才触发。探针里 uiConversation 已在手上,直接同步给。
    callback({ ...fakeEffectContext(), uiConversation: { events: eventRegistry }, slots: pluginCtxSlots })
  },
  slots: pluginCtxSlots,
  on() {
    return () => {}
  },
}
const pluginCtx = new Proxy(pluginCtxBase, {
  get(target, prop) {
    if (prop in target) return target[prop]
    // 其余服务(locale/logger/configForms/remote…)一律给「什么都行」
    return anythingProxy()
  },
})
// 只关心 applyAttemptKeep 这条链路;notify/native-open/quota 等模块的装配
// 依赖更多服务,统一走吞噬代理(与生产「服务缺失即静默降级」等价)。
plugin.apply(pluginCtx)

// ---------------------------------------------------------------------------
// 四、事件工厂:构造 GLM 断连场景的事件序列
// ---------------------------------------------------------------------------

const llm = await import(pathToFileURL(join(HOST, '@deepseek-ai/dsh-llm/lib/index.js')).href)
const { AssistantStreamAccumulator } = llm

let seqCounter = 0
const nextSeq = () => ++seqCounter
let clock = 1_700_000_000_000

/** 用官方生产者把 chunk 序列压成 attempt 事件(与服务端持久化完全同构)。 */
function attemptEvent(turn, step, chunks) {
  const accumulator = new AssistantStreamAccumulator()
  let time = ++clock
  for (const chunk of chunks) {
    time = accumulator.push({ time: ++clock, chunk }).time
  }
  return {
    type: 'assistant/attempt',
    seq: nextSeq(),
    time,
    data: { turn, step, stream: [...accumulator.snapshot()] },
  }
}

const turnStart = (turn) => ({ type: 'turn/start', seq: nextSeq(), time: ++clock, data: { turn } })
const turnEnd = (turn, reason) => ({ type: 'turn/end', seq: nextSeq(), time: ++clock, data: { turn, reason } })
const stepStart = (turn, step) => ({ type: 'step/start', seq: nextSeq(), time: ++clock, data: { turn, step } })
const stepEnd = (turn, step) => ({ type: 'step/end', seq: nextSeq(), time: ++clock, data: { turn, step } })
const userMessage = (turn, text) => ({
  type: 'user/message',
  seq: nextSeq(),
  time: ++clock,
  surfaceOp: 'append',
  data: { turn, message: { role: 'user', content: [{ type: 'text', text }], source: { kind: 'user' } } },
})
const liveChunk = (attemptId, turn, step, chunk) => ({
  type: 'assistant/live-chunk',
  seq: 0,
  time: ++clock,
  data: { attemptId, turn, step, chunk },
})
const assistantMessage = (turn, step, text) => ({
  type: 'assistant/message',
  seq: nextSeq(),
  time: ++clock,
  surfaceOp: 'append',
  data: {
    turn,
    step,
    message: { role: 'assistant', content: [{ type: 'text', text }], source: { kind: 'assistant' } },
  },
})

const GLM_CUT_REASONING_THEN_TEXT = [
  { type: 'block-start', index: 0, blockType: 'reasoning' },
  { type: 'reasoning-delta', index: 0, text: '思考到敏感词' },
  { type: 'block-end', index: 0, block: { type: 'reasoning', text: '思考到敏感词' } },
  { type: 'block-start', index: 1, blockType: 'text' },
  { type: 'text-delta', index: 1, text: '正文输出到一半' },
]

// ---------------------------------------------------------------------------
// 五、场景断言
// ---------------------------------------------------------------------------

let failures = 0
let checks = 0
function check(name, condition, detail = '') {
  checks++
  if (condition) {
    console.log(`ok   ${name}`)
  } else {
    failures++
    console.error(`FAIL ${name}${detail ? ` :: ${detail}` : ''}`)
  }
}

/** 读当前 chat 视图快照(排序后的节点列表)。 */
function chatNodes() {
  assembler.flush()
  const snapshot = assembler.snapshot('chat')
  if (!Array.isArray(snapshot)) throw new Error('chat 快照不是数组(透传视图异常)')
  return snapshot
}

// —— 场景 A:live 结算路径(流式中途断连,transient 行被撤下换成 attempt 事件) ——
{
  seqCounter = 0
  const turn = 7
  const attemptId = 'session-x:1'
  const attempt = attemptEvent(turn, 0, GLM_CUT_REASONING_THEN_TEXT)
  assembler.replaceWindow(
    [
      { type: 'event', event: turnStart(turn) },
      { type: 'event', event: userMessage(turn, '继续') },
      { type: 'event', event: stepStart(turn, 0) },
    ],
    false,
  )
  // 流式期间:官方语义里 transient live-chunk 由 assistant-step 定义消费;
  // 本探针没注册官方定义,只有插件定义在听 attempt 事件 —— transient 喂进去
  // 不应产生任何插件节点(插件不订阅 live-chunk)。
  assembler.append({ type: 'transient', event: liveChunk(attemptId, turn, 0, { type: 'text-delta', index: 1, text: '正文输出到一半' }) })
  let nodes = chatNodes()
  check('A1 流式期间不产生插件节点', nodes.length === 0, JSON.stringify(nodes.map((n) => n.kind)))
  // 断连结算:transient 撤下 + attempt 事件进场(生产路径:ClientAssistantStream → settleAssistant)
  assembler.settleAssistant(attemptId, { type: 'event', event: attempt })
  nodes = chatNodes()
  check('A2 结算后产出 1 个节点', nodes.length === 1, JSON.stringify(nodes.map((n) => n.kind)))
  const node = nodes[0]
  check('A3 节点 kind 复用官方 assistant-step', node?.kind === 'assistant-step')
  check('A4 status=interrupted(官方「已停止」角标)', node?.data?.status === 'interrupted')
  check(
    'A5 块内容 = 中断前缀(思考+半截正文)',
    JSON.stringify(node?.data?.blocks) === JSON.stringify([
      { kind: 'reasoning', text: '思考到敏感词' },
      { kind: 'text', text: '正文输出到一半' },
    ]),
    JSON.stringify(node?.data?.blocks),
  )
  check('A6 anchorSeq = attempt 事件 seq', node?.anchorSeq === attempt.seq)
  check('A7 location 解析到 step', node?.location?.kind === 'step' && node?.location?.step?.step === 0 && node?.location?.turn?.turn === turn)
  check('A8 turn/step 回填', node?.data?.turn === turn && node?.data?.step === 0)
  // 追加 step/end + 错误 turn/end,断言行序:插件行在错误行之前
  assembler.append({ type: 'event', event: stepEnd(turn, 0) })
  const end = turnEnd(turn, { kind: 'error', error: { message: 'connection reset by peer', code: 'NETWORK' } })
  assembler.append({ type: 'event', event: end })
  nodes = chatNodes()
  const kinds = nodes.map((n) => n.kind)
  check('A9 断连保留行仍在(未被后续事件撤回)', kinds.includes('assistant-step'), JSON.stringify(kinds))
}

// —— 场景 B:历史重放路径(刷新页面后从持久化日志重放) ——
{
  seqCounter = 0
  const turn = 8
  const attempt = attemptEvent(turn, 0, GLM_CUT_REASONING_THEN_TEXT)
  const end = turnEnd(turn, { kind: 'error', error: { message: 'SSL routines: unexpected eof', code: 'NETWORK' } })
  assembler.replaceWindow(
    [
      { type: 'event', event: turnStart(turn) },
      { type: 'event', event: userMessage(turn, '重来') },
      { type: 'event', event: stepStart(turn, 0) },
      { type: 'event', event: attempt },
      { type: 'event', event: stepEnd(turn, 0) },
      { type: 'event', event: end },
    ],
    false,
  )
  const nodes = chatNodes()
  const mine = nodes.filter((n) => n.kind === 'assistant-step')
  check('B1 重放后节点重现', mine.length === 1, JSON.stringify(nodes.map((n) => n.kind)))
  check('B2 内容不随路径变化', JSON.stringify(mine[0]?.data?.blocks?.map((b) => b.text)) === JSON.stringify(['思考到敏感词', '正文输出到一半']))
}

// —— 场景 C:重试链(两次断连后第三次成功)——行序与共存 ——
{
  seqCounter = 0
  const turn = 9
  const cut1 = attemptEvent(turn, 0, [
    { type: 'block-start', index: 0, blockType: 'text' },
    { type: 'text-delta', index: 0, text: '第一次尝试,写到' },
  ])
  const cut2 = attemptEvent(turn, 0, [
    { type: 'block-start', index: 0, blockType: 'reasoning' },
    { type: 'reasoning-delta', index: 0, text: '重试的思考' },
    { type: 'block-start', index: 1, blockType: 'text' },
    { type: 'text-delta', index: 1, text: '第二次尝试' },
  ])
  const ok = assistantMessage(turn, 0, '第三次成功了')
  assembler.replaceWindow(
    [
      { type: 'event', event: turnStart(turn) },
      { type: 'event', event: userMessage(turn, '再试') },
      { type: 'event', event: stepStart(turn, 0) },
      { type: 'event', event: cut1 },
      { type: 'event', event: { type: 'llm/retry', seq: nextSeq(), time: ++clock, data: { turn, step: 0, provider: 'zai', mode: 'normal', retry: 1, delayMs: 1000, failure: { message: 'x', code: 'NETWORK' } } } },
      { type: 'event', event: cut2 },
      { type: 'event', event: { type: 'llm/retry', seq: nextSeq(), time: ++clock, data: { turn, step: 0, provider: 'zai', mode: 'normal', retry: 2, delayMs: 2000, failure: { message: 'x', code: 'NETWORK' } } } },
      { type: 'event', event: ok },
      { type: 'event', event: stepEnd(turn, 0) },
      { type: 'event', event: turnEnd(turn, { kind: 'completed' }) },
    ],
    false,
  )
  const nodes = chatNodes()
  const seqs = nodes.map((n) => n.anchorSeq)
  check('C1 两次失败尝试各占一行', nodes.filter((n) => n.data?.status === 'interrupted').length === 2, JSON.stringify(nodes.map((n) => [n.kind, n.data?.status])))
  check('C2 行序按发生顺序递增', seqs.every((s, i) => i === 0 || s > seqs[i - 1]), JSON.stringify(seqs))
  // 注意:探针没注册官方 assistant-step 定义,成功消息不产节点;行序断言用
  // 事件 seq 本身(视图行序的主键就是它),cut1 < cut2 < ok。
  check('C3 事件序:失败尝试都在成功消息之前', cut1.seq < cut2.seq && cut2.seq < ok.seq && seqs.indexOf(cut2.seq) > seqs.indexOf(cut1.seq))
}

// —— 场景 D:无可见内容的 attempt(连接建立即失败)不占行 ——
{
  seqCounter = 0
  const turn = 10
  const empty = attemptEvent(turn, 0, [{ type: 'finish', finish: { kind: 'error', message: 'blocked', code: 'PROVIDER' } }])
  assembler.replaceWindow(
    [
      { type: 'event', event: turnStart(turn) },
      { type: 'event', event: userMessage(turn, 'hi') },
      { type: 'event', event: stepStart(turn, 0) },
      { type: 'event', event: empty },
      { type: 'event', event: stepEnd(turn, 0) },
      { type: 'event', event: turnEnd(turn, { kind: 'error', error: { message: 'blocked', code: 'PROVIDER' } }) },
    ],
    false,
  )
  const nodes = chatNodes()
  check('D1 空内容 attempt 不占行', nodes.length === 0, JSON.stringify(nodes.map((n) => n.kind)))
}

// —— 场景 E:注册表约束(生产会抛错的路径)—— 同一窗口重放后节点 key 稳定 ——
{
  // 同一份窗口条目重放两次(seq 固定;重新生成会得到新 seq,那是另一个场景)
  const window11 = [
    { type: 'event', event: turnStart(11) },
    { type: 'event', event: userMessage(11, 'again') },
    { type: 'event', event: stepStart(11, 0) },
    { type: 'event', event: attemptEvent(11, 0, [{ type: 'text-delta', index: 0, text: '又一轮' }]) },
    { type: 'event', event: stepEnd(11, 0) },
    { type: 'event', event: turnEnd(11, { kind: 'error', error: { message: 'reset', code: 'NETWORK' } }) },
  ]
  // 第一次装载:窗口重建不得抛「unstable key / withdrew materialized node」
  let threw = null
  try {
    assembler.replaceWindow(window11, false)
    chatNodes()
  } catch (error) {
    threw = error
  }
  check('E1 窗口重建不触发装配器约束异常', threw === null, threw?.message)
  const before = chatNodes().map((n) => n.key)
  // 同一窗口再重放一次(模拟分页回填/注册表重建后的 replay),key 必须逐项一致
  try {
    assembler.replaceWindow(window11, false)
    chatNodes()
  } catch (error) {
    threw = error
  }
  const after = chatNodes().map((n) => n.key)
  check('E2 同窗口重放节点 key 稳定', JSON.stringify(before) === JSON.stringify(after), `${JSON.stringify(before)} → ${JSON.stringify(after)}`)
}

console.log(`\n${failures === 0 ? 'PASS' : 'FAIL'}: ${checks - failures}/${checks} 项通过`)
process.exit(failures === 0 ? 0 : 1)
