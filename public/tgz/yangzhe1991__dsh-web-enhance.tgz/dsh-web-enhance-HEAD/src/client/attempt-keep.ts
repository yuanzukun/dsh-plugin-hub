/**
 * 功能七:断连保留 —— 模型流式中途断开时,把已经输出的内容留在对话里。
 *
 * 背景:GLM 等提供方的敏感词审查会直接掐断流式连接。DSH 宿主侧(agent-loop)
 * 在流失败时会把已收到的 chunk 原样持久化为 `assistant/attempt` 事件(数据没丢),
 * 但 Web 前端把它当「不可见事件」:流式期间的临时行(assistant/live-chunk)被
 * 撤下、换成这条无人认领的 attempt 事件,于是界面上思考/正文都凭空消失。
 *
 * 修复思路:以插件自己的会话节点定义(ConversationNodeDefinition)认领
 * `assistant/attempt` 事件,从事件携带的紧凑流记录里重组「中断前安全可见前缀」
 * (与服务端 BlockAssembler.interruptedBlocks 同语义:按流序保留有非空白内容的
 * text/reasoning 块,工具调用一律丢弃),再产出一个 kind='assistant-step' 的视图
 * 节点 —— 直接复用官方 AssistantNodeView 渲染(markdown/思考折叠条原样),
 * status='interrupted' 还会自带官方「已停止」角标,视觉与用户手动中断一致。
 *
 * 三条关键事实(全部读自 dsh 0.2.1-rc.2 官方源码,勿凭印象改):
 * - agent-loop 流失败 → `session.append('assistant/attempt', { turn, step, stream })`,
 *   stream 是紧凑记录数组(见下方 StreamRecord);用户中断且无内容时也走这条。
 * - 官方 assistant-step 定义只认 step/start、live-chunk、assistant/message、
 *   llm/retry,不认 assistant/attempt;chat fallback 也只兜底 surface 事件,
 *   所以 attempt 事件当前完全无人渲染。
 * - 渲染分发按「视图节点的 kind」查 conversation.chat.node 槽位(官方注册了
 *   key='assistant-step' → AssistantNodeView),节点 kind 与定义 kind 是两回事,
 *   插件定义可以合法地产出官方 kind 的节点(节点 key 由 定义kind+id 保证唯一)。
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis'
// 触发 ConversationNodeDefinition / ctx.uiConversation 的声明合并,并把定义
// 直接对齐官方类型(编译期校验契约;类型导入 esbuild 会擦除,不进运行时依赖)。
import type {
  ConversationLocation,
  ConversationMatchResult,
  ConversationNodeContext,
  ConversationNodeDefinitionInput,
  ConversationViewNode,
} from '@deepseek-ai/dsh-client-ui-conversation/client'

// ---------------------------------------------------------------------------
// 一、紧凑流记录 → 逐 chunk 序列
// ---------------------------------------------------------------------------

/**
 * `assistant/attempt.stream` 的紧凑记录(生产端:dsh-llm AssistantStreamAccumulator)。
 * 连续同 index 的 text/reasoning/tool-call 增量被合并成一条 run,省掉逐 chunk 的
 * 重复字段;其余 chunk(block-start/block-end/usage/finish、以及空 id 的
 * tool-call-delta)原样内嵌为 `{type:'chunk'}`。
 */
type StreamRecord =
  | { type: 'text-chunks'; time0: number; index: number; dt: number[]; texts: string[] }
  | { type: 'reasoning-chunks'; time0: number; index: number; dt: number[]; texts: string[] }
  | { type: 'tool-call-chunks'; time0: number; index: number; dt: number[]; id: string; name?: string; args: string[] }
  | { type: 'chunk'; time: number; chunk: UnknownChunk }

/** 流 chunk 的宽松形状:这里只关心重组文本,不做全量校验。 */
interface UnknownChunk {
  type: string
  index?: number
  text?: string
  blockType?: string
  block?: { type?: string; text?: string }
  [key: string]: unknown
}

/** 重组视图块:只需要 text / reasoning 两种(与官方 interruptedBlocks 同口径)。 */
export interface PartialBlock {
  kind: 'text' | 'reasoning'
  text: string
}

/**
 * 展开紧凑记录为「按流序」的 chunk 列表。
 *
 * 语义照抄官方 expandAssistantStream(dsh-api-session-controller 内部实现,
 * 未导出,故在此复制):run 记录展开为逐条 delta,时间戳由 time0 + dt 前缀和
 * 重建(时间戳只用于排序展示,这里直接丢弃,重建只为保持结构一致)。
 * 与官方不同的是:官方在持久化边界做严格校验(抛 TypeError),这里按「展示
 * 用途」宽容处理 —— 单条记录畸形就跳过并打 warn,不让一条坏记录拖垮整个节点。
 */
function expandAttemptStream(stream: readonly unknown[]): UnknownChunk[] {
  const chunks: UnknownChunk[] = []
  for (const candidate of stream) {
    // 记录必须是普通对象;数组/null 都按畸形跳过
    if (typeof candidate !== 'object' || candidate === null || Array.isArray(candidate)) continue
    const record = candidate as Record<string, unknown>
    switch (record.type) {
      case 'text-chunks':
      case 'reasoning-chunks': {
        const texts = asStringArray(record.texts)
        const index = asIndex(record.index)
        if (texts === null || index === null) break
        for (const text of texts) {
          chunks.push({
            type: record.type === 'text-chunks' ? 'text-delta' : 'reasoning-delta',
            index,
            text,
          })
        }
        break
      }
      case 'tool-call-chunks': {
        // 工具调用参数增量:重组展示时统一丢弃(见 assembleInterruptedBlocks),
        // 但仍要消费掉,保证 chunk 序列完整 —— 这里直接不产出。
        break
      }
      case 'chunk': {
        const chunk = record.chunk
        if (typeof chunk === 'object' && chunk !== null && !Array.isArray(chunk)) {
          chunks.push(chunk as UnknownChunk)
        }
        break
      }
      default:
        break
    }
  }
  return chunks
}

function asStringArray(value: unknown): string[] | null {
  if (!Array.isArray(value) || value.some((member) => typeof member !== 'string')) return null
  return value as string[]
}

function asIndex(value: unknown): number | null {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 ? value : null
}

// ---------------------------------------------------------------------------
// 二、chunk 序列 → 中断前可见块
// ---------------------------------------------------------------------------

/** 单个 block 槽位的组装状态:open = 还没收到 block-end。 */
interface BlockSlot {
  kind: 'text' | 'reasoning' | 'dropped'
  text: string
  open: boolean
}

/**
 * 按「中断安全前缀」语义组装可见块。
 *
 * 服务端 BlockAssembler.interruptedBlocks 的口径(dsh-llm):
 * - 按块首次出现的流序输出;
 * - 只保留 text / reasoning(闭合或未闭合都行),要求 text.trim() 非空;
 * - 工具调用全部丢弃(中断发生时尚未派发,留着一个没有结果的调用只会误导);
 * - 未知块类型丢弃;
 * - block-end 之后到达的增量按畸形忽略(官方:delta 到已闭合槽位直接丢)。
 * 官方还兼容「无 block-start 直接来 delta」的协议,这里同样支持。
 */
export function assembleInterruptedBlocks(chunks: readonly UnknownChunk[]): PartialBlock[] {
  const slots = new Map<number, BlockSlot>()
  const order: number[] = []
  // 取槽位;ensure 为「无 block-start 的 delta」开一个新槽(永不返回 undefined:
  // 槽位不存在时当场创建)
  const slotAt = (index: number, kind: 'text' | 'reasoning'): BlockSlot => {
    const existing = slots.get(index)
    if (existing === undefined) {
      const created: BlockSlot = { kind, text: '', open: true }
      slots.set(index, created)
      order.push(index)
      return created
    }
    return existing
  }
  for (const chunk of chunks) {
    const index = asIndex(chunk.index)
    switch (chunk.type) {
      case 'block-start': {
        if (index === null) break
        // 重复 block-start(官方:已有槽位则忽略)与未知 blockType 都归入 dropped
        if (slots.has(index)) break
        const blockType = typeof chunk.blockType === 'string' ? chunk.blockType : ''
        const slot: BlockSlot =
          blockType === 'text' || blockType === 'reasoning'
            ? { kind: blockType, text: '', open: true }
            : { kind: 'dropped', text: '', open: true }
        slots.set(index, slot)
        order.push(index)
        break
      }
      case 'text-delta':
      case 'reasoning-delta': {
        if (index === null || typeof chunk.text !== 'string') break
        const slot = slotAt(index, chunk.type === 'text-delta' ? 'text' : 'reasoning')
        // 已闭合的槽位再收增量 = 畸形流,忽略(与官方一致,防脏数据覆盖完成块)
        if (!slot.open || slot.kind === 'dropped') break
        slot.text += chunk.text
        break
      }
      case 'block-end': {
        if (index === null) break
        const block = chunk.block
        const type = typeof block?.type === 'string' ? block.type : ''
        const existing = slots.get(index)
        if (type === 'text' || type === 'reasoning') {
          // 闭合块以 block-end 携带的最终文本为准(等价官方 assemble 的 final 分支);
          // 没有开过槽也照收(delta-only 协议的反向:只有 end 没有 delta)
          const text = typeof block?.text === 'string' ? block.text : ''
          const slot: BlockSlot = { kind: type, text, open: false }
          if (existing === undefined) order.push(index)
          slots.set(index, slot)
        } else {
          // 未知块 / 工具调用闭合:标记丢弃
          const slot: BlockSlot = { kind: 'dropped', text: '', open: false }
          if (existing === undefined) order.push(index)
          slots.set(index, slot)
        }
        break
      }
      default:
        // usage / finish / tool-call-delta(展开阶段已滤)/ 未知类型:与块无关
        break
    }
  }
  const blocks: PartialBlock[] = []
  for (const index of order) {
    const slot = slots.get(index)
    if (slot === undefined || slot.kind === 'dropped' || slot.text.trim() === '') continue
    blocks.push({ kind: slot.kind, text: slot.text })
  }
  return blocks
}

/** 从 attempt 事件的 stream 字段直接得到可见块(组合上面两步)。 */
export function partialBlocksFromAttemptStream(stream: readonly unknown[]): PartialBlock[] {
  return assembleInterruptedBlocks(expandAttemptStream(stream))
}

// ---------------------------------------------------------------------------
// 三、会话节点定义
// ---------------------------------------------------------------------------

/** attempt 事件 data 的最小结构形状(结构化收窄,不做全量校验)。 */
interface AttemptEventData {
  turn: number
  step: number
  stream: readonly unknown[]
}

/** 定义状态:一次失败尝试的可展示投影。 */
interface AttemptKeepState {
  seq: number
  time: number
  turn: number
  step: number
  blocks: PartialBlock[]
  /** 是否有可见内容(决定节点是否产出;空内容的中断不占行)。 */
  visible: boolean
}

/** 从事件收窄出 attempt 数据;形状不对返回 undefined。 */
function attemptDataOf(event: { type: string; data?: unknown }): AttemptEventData | undefined {
  if (event.type !== 'assistant/attempt') return undefined
  const data = event.data
  if (typeof data !== 'object' || data === null) return undefined
  const { turn, step, stream } = data as Record<string, unknown>
  if (typeof turn !== 'number' || typeof step !== 'number' || !Array.isArray(stream)) return undefined
  return { turn, step, stream }
}

/** 由一条 attempt 事件计算定义状态。 */
function stateFromAttempt(seq: number, time: number, data: AttemptEventData): AttemptKeepState {
  let blocks: PartialBlock[] = []
  try {
    blocks = partialBlocksFromAttemptStream(data.stream)
  } catch (error) {
    // 重组失败只影响这一行的展示,不允许影响会话视图其它部分
    console.warn('[dsh-web-enhance] 断连保留:attempt 流重组失败(该行不显示):', error)
  }
  return {
    seq,
    time,
    turn: data.turn,
    step: data.step,
    blocks,
    visible: blocks.length > 0,
  }
}

/** 官方 AssistantNodeView 消费的节点 data(status='interrupted' 自带「已停止」角标)。 */
interface AttemptKeepNodeData {
  status: 'interrupted'
  turn: number
  step: number
  blocks: PartialBlock[]
  time: number
}

/**
 * chat target 视图节点的完整形状。官方 ConversationViewNode 只是「目标中立
 * 身份」,chat 目标节点额外携带 anchorSeq(排序)/location(过程分组)/
 * visibility(占行与否)—— 官方 chatNode() 工厂同样返回这些扩展字段
 * (ui-chat 内部类型,未导出,这里按同一形状补齐)。
 */
interface AttemptKeepChatNode extends ConversationViewNode {
  anchorSeq: number
  location: ConversationLocation
  visibility: 'visible'
  data: AttemptKeepNodeData
}

/** state 缺席时(上下文重放的边界)从 matches 里就地重建 —— 官方定义同款 fallback。 */
function fallbackState(context: ConversationNodeContext<AttemptKeepState>): AttemptKeepState | undefined {
  for (const match of context.matches) {
    const data = attemptDataOf(match.event)
    if (data !== undefined) return stateFromAttempt(match.event.seq, match.event.time, data)
  }
  return undefined
}

/**
 * 断连保留节点定义。
 *
 * match 用表形式,只订阅 `assistant/attempt` 一种事件,不为其它事件增加分发
 * 开销;每个事件自带唯一 seq,一个事件 = 一个上下文 = 至多一行。
 * 注意绝不能用 exclusive 认领:exclusive 会把事件从同 target 的其它定义手里
 * 抢走,而 attempt 事件目前虽无人认领,官方未来若开始消费它不能被插件破坏。
 */
const attemptKeepDefinition: ConversationNodeDefinitionInput<AttemptKeepState> = {
  kind: 'web-enhance-attempt-keep',
  target: 'chat',
  match: {
    'assistant/attempt': (event): ConversationMatchResult | null => ({
      id: String(event.seq),
      role: 'start',
    }),
  },
  start: (_context, match): AttemptKeepState => {
    const data = attemptDataOf(match.event)
    if (data === undefined) {
      // 形状不对:给一个「不可见」状态,buildViewNode 返回 null 即可
      return { seq: match.event.seq, time: match.event.time, turn: 0, step: 0, blocks: [], visible: false }
    }
    return stateFromAttempt(match.event.seq, match.event.time, data)
  },
  update: (context): AttemptKeepState => context.state,
  publication: () => 'immediate',
  buildViewNode: (context): AttemptKeepChatNode | null => {
    const state = context.state ?? fallbackState(context)
    if (state === undefined || !state.visible) return null
    // 视图节点 kind 用官方 'assistant-step':renderSlot 按 kind 分发到官方
    // AssistantNodeView,markdown/思考折叠条/「已停止」角标全部复用,不自绘。
    // anchorSeq 用 attempt 事件的持久 seq:天然排在 step/end、turn/end(错误行)
    // 之前,多次失败尝试的行序 = 实际发生顺序。
    return {
      key: context.key,
      kind: 'assistant-step',
      id: context.id,
      target: 'chat',
      anchorSeq: state.seq,
      location: context.matches[0]?.location ?? { kind: 'unresolved' },
      visibility: 'visible',
      data: {
        status: 'interrupted',
        turn: state.turn,
        step: state.step,
        blocks: state.blocks,
        time: state.time,
      },
    }
  },
}

// ---------------------------------------------------------------------------
// 四、装配
// ---------------------------------------------------------------------------

/**
 * 装配断连保留:把节点定义注册进 uiConversation.events。
 *
 * 服务读取用 `ctx.inject([...], cb)` 软依赖模式(与本插件 native-open 同款):
 * uiConversation 缺失时只是这个功能静默缺席,不拖垮其它功能;依赖静默性
 * (不齐则回调永不触发)用「迟到重试 + DOM 状态打点」兜底,全部 try/catch
 * (cordis 会吞 effect 里的异常,不接住就完全无痕)。
 */
export function applyAttemptKeep(ctx: ClientContext): void {
  const state = { registered: false, error: '' }
  const publish = (): void => {
    try {
      document.documentElement.dataset.dshWebeAttemptKeep = JSON.stringify(state)
    } catch {
      // 非浏览器环境(探针)忽略
    }
  }
  publish()

  let done = false
  let disposed = false
  ctx.effect(() => () => {
    disposed = true
  }, 'web-enhance: attempt keep lifetime')

  const attempt = (): void => {
    if (done || disposed) return
    try {
      ctx.inject(['uiConversation'], (scoped: ClientContext) => {
        if (done || disposed) return
        try {
          const uiConversation = scoped.uiConversation
          if (typeof uiConversation?.events?.register !== 'function') {
            throw new Error(`uiConversation.events.register 不是函数 (${typeof uiConversation?.events?.register})`)
          }
          const dispose = uiConversation.events.register(attemptKeepDefinition)
          done = true
          state.registered = true
          state.error = ''
          publish()
          console.info('[dsh-web-enhance] 断连保留:已注册(流中断时保留已输出内容)')
          // 注册表把 effect 挂在自己的 ctx 上,插件卸载时要主动摘除定义
          scoped.effect(() => () => {
            dispose()
          }, 'web-enhance: attempt keep definition')
        } catch (error) {
          state.error = `注册失败: ${error instanceof Error ? error.message : String(error)}`
          publish()
          console.warn('[dsh-web-enhance] 断连保留注册失败:', error)
        }
      })
    } catch (error) {
      state.error = `ctx.inject 抛错 ${error instanceof Error ? error.message : String(error)}`
      publish()
      console.warn('[dsh-web-enhance] 断连保留 ctx.inject 抛错', error)
    }
  }

  attempt()
  // 自我修复:uiConversation 迟到时重试(清 done 标记避免被自己挡住)
  const retryDelays = [400, 1500, 4000]
  let retryIndex = 0
  const tryRetry = (): void => {
    if (done || disposed) return
    attempt()
    const delay = retryDelays[retryIndex]
    if (delay !== undefined) {
      retryIndex += 1
      setTimeout(tryRetry, delay)
    }
  }
  tryRetry()
  try {
    ctx.on('internal/service', () => {
      if (!done && !disposed) setTimeout(tryRetry, 0)
    })
  } catch (error) {
    // internal/service 事件不可用的环境(老版 cordis):有定时重试兜底,不致命
    console.debug('[dsh-web-enhance] 断连保留:internal/service 监听失败(仅有定时重试兜底):', error)
  }
  setTimeout(() => {
    if (!done && state.error === '') {
      state.error = 'uiConversation 一直未就绪;断连保留未生效(其余功能不受影响)'
      publish()
      console.warn('[dsh-web-enhance] 断连保留:', state.error)
    }
  }, 8000)
}
