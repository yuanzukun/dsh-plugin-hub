#!/usr/bin/env python3
"""Verification suite for the EditApart per-creator taste model.

Every assertion here is a checkable property, not a smoke test:

  * Newton-Schulz: bounded singular-value band + scale invariance (the reference
    Muon iteration is an APPROXIMATE orthogonalization — asserting exact
    orthogonality would test the wrong contract).
  * Optimizer split: Muon touches only 2D parameters, AdamW only 1D ones
    (including `z_u`), and each leaves the other's parameters untouched.
  * Gradients: the analytic backward pass matches finite differences.
  * GGUF: real container round-trips bit-exactly; metadata types survive; a
    digest mismatch (identity trained against a different style-brain) is
    refused rather than silently scoring with the wrong trunk.
  * Learning: on a synthetic hidden taste function the objective actually
    recovers held-out preferences (ranking accuracy vs. chance).
  * Identity semantics: `z_u` changes decisions, is required, and is
    interpolatable (midpoint latents score between the endpoints).
  * Engine wiring: the loop builds groups, logs them, folds critic rewards, and
    `group=1` still reproduces the legacy single-schema proposal.
  * Graceful degradation: the legacy engine path works with numpy unavailable.

Run:  <venv>/bin/python tests/test_taste_model.py -v
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
BIN = os.path.join(ROOT, "bin")
sys.path.insert(0, BIN)

import numpy as np  # noqa: E402

import edit_apart_core as eng  # noqa: E402
import taste_model as tm  # noqa: E402


def fixture_inventory(n_shots: int = 12, seed: int = 0) -> dict:
    rng = np.random.default_rng(seed)
    shots = []
    t = 0.0
    for i in range(n_shots):
        d = float(round(rng.uniform(0.5, 3.5), 3))
        shots.append({"shot": f"clip_{i + 1:03d}", "start": round(t, 3),
                      "end": round(t + d, 3), "duration": d, "src_idx": i + 1,
                      "features": {"lum_p50": float(rng.uniform(40, 200)),
                                   "lum_p95": float(rng.uniform(150, 250)),
                                   "motion": float(rng.uniform(0.2, 14.0)),
                                   "rms_db": float(rng.uniform(-40, -5)),
                                   "peak_db": float(rng.uniform(-10, 0))}})
        t += d
    return {"source": "/tmp/fixture.mp4", "shots": shots}


def fixture_rubric(**over) -> dict:
    r = {"intent": "punchy highlight", "pace": "brisk", "min_shot_dur": 0.9,
         "max_shot_dur": 4.0, "skip_short": True, "target_duration": 20.0,
         "no_shot_under_s": 0.9}
    r.update(over)
    return r


def synthetic_dataset(path: str, n_clips: int = 24, k: int = 5, seed: int = 0,
                      noise: float = 0.0) -> dict:
    """Groups whose reward is a hidden quadratic taste over the video feature
    layout. This is a ground truth the model can only get right by learning."""
    rng = np.random.default_rng(seed)
    names = tm.FEATURE_SPECS[tm.FEATURE_SPEC_VIDEO]
    theta = rng.normal(size=len(names))
    with open(path, "w", encoding="utf-8") as fh:
        for c in range(n_clips):
            X = rng.normal(size=(k, len(names)))
            r = -((X - theta) ** 2).sum(axis=1)
            if noise:
                r = r + rng.normal(scale=noise, size=k)
            cands = []
            for i in range(k):
                cands.append({"idx": i, "features": {n: float(x) for n, x in zip(names, X[i])},
                              "reward_obj": float(r[i]), "overall_obj": float(r[i]),
                              "dense_obj": 0.0, "knobs": {"i": i}})
            fh.write(json.dumps({"kind": "group", "group_id": f"c{c}", "clip_id": f"clip{c}",
                                 "feature_spec": tm.FEATURE_SPEC_VIDEO, "candidates": cands}) + "\n")
    return {"theta": theta.tolist(), "names": names}


class TestNewtonSchulz(unittest.TestCase):
    def test_shape_and_bounded_band(self):
        rng = np.random.default_rng(0)
        for shape in [(6, 6), (8, 6), (6, 8), (16, 4), (10, 24)]:
            G = rng.normal(size=shape)
            O = tm.newton_schulz(G, 5)
            self.assertEqual(O.shape, shape)
            sv = np.linalg.svd(O, compute_uv=False)
            self.assertGreater(sv.min(), 0.25, f"{shape}: min sv {sv.min()}")
            self.assertLess(sv.max(), 2.0, f"{shape}: max sv {sv.max()}")

    def test_scale_invariance(self):
        rng = np.random.default_rng(3)
        G = rng.normal(size=(12, 7))
        self.assertTrue(np.allclose(tm.newton_schulz(G, 5), tm.newton_schulz(G * 9.5, 5),
                                    atol=1e-9))

    def test_rejects_1d(self):
        with self.assertRaises(ValueError):
            tm.newton_schulz(np.zeros(5), 5)


class TestOptimizerSplit(unittest.TestCase):
    def setUp(self):
        self.model = tm.StyleBrain(d_in=8, d_h=6, d_z=5, seed=0)

    def all_grads(self, seed=0):
        rng = np.random.default_rng(seed)
        return {n: rng.normal(size=self.model.p[n].shape) for n in self.model.spec}

    def test_muon_only_2d(self):
        before = {n: self.model.p[n].copy() for n in self.model.spec}
        grads = self.all_grads()
        self.model.muon.step(grads)
        for name, (shape, opt) in self.model.spec.items():
            if opt == "muon":
                self.assertFalse(np.allclose(self.model.p[name], before[name]),
                                 f"Muon did not update 2D param {name}")
            else:
                self.assertTrue(np.array_equal(self.model.p[name], before[name]),
                                f"Muon touched 1D param {name}")
        self.assertEqual(self.model.muon.touched_1d, [])

    def test_adamw_only_1d(self):
        before = {n: self.model.p[n].copy() for n in self.model.spec}
        self.model.adamw.step(self.all_grads(1))
        for name, (shape, opt) in self.model.spec.items():
            if opt == "adamw":
                self.assertFalse(np.array_equal(self.model.p[name], before[name]),
                                 f"AdamW did not update {name}")
            else:
                self.assertTrue(np.array_equal(self.model.p[name], before[name]),
                                f"AdamW touched 2D param {name}")
        self.assertEqual(self.model.adamw.touched_2d, [])

    def test_z_u_is_adamw_and_gets_updated(self):
        _, opt = self.model.spec["z_u"]
        self.assertEqual(opt, "adamw")
        before = self.model.p["z_u"].copy()
        self.model.adamw.step({"z_u": np.ones(self.model.d_z)})
        self.assertFalse(np.array_equal(self.model.p["z_u"], before))
        self.assertGreater(np.linalg.norm(self.model.p["z_u"]), 0.0)

    def test_wrong_rank_is_refused(self):
        with self.assertRaises(AssertionError):
            self.model.muon.step({"W1": np.zeros(self.model.d_in)})
        with self.assertRaises(AssertionError):
            self.model.adamw.step({"z_u": np.zeros((self.model.d_z, 1))})


class TestGradients(unittest.TestCase):
    def test_analytic_matches_finite_difference(self):
        rng = np.random.default_rng(7)
        worst = 0.0
        for trial in range(3):
            m = tm.StyleBrain(d_in=6, d_h=5, d_z=4, seed=trial)
            X = rng.normal(size=(4, 6))
            dU = rng.normal(size=4)
            cache: dict = {}
            m._trunk(X, m.p["z_u"], cache)
            grads = m.backward(dU, cache)
            eps = 1e-6
            for name in m.spec:
                flat = m.p[name].ravel()
                for i in range(min(10, flat.size)):
                    old = flat[i]
                    flat[i] = old + eps
                    up = m.utilities(X)
                    flat[i] = old - eps
                    dn = m.utilities(X)
                    flat[i] = old
                    num = float(((up - dn) / (2 * eps)) @ dU)
                    ana = float(grads[name].ravel()[i])
                    worst = max(worst, abs(num - ana) / max(1e-9, abs(num) + abs(ana)))
        self.assertLess(worst, 1e-6, f"worst relative gradient error {worst:.3e}")


class TestObjectiveFidelity(unittest.TestCase):
    """The GRPO ratio must be a ratio.

    A review found `train()` storing raw standardised logits as the ratio
    baseline, so `rho = exp(log_softmax(s) - s) = 1/Z` — a per-group constant.
    Consequences: every negative-advantage candidate fell into the clipped branch
    and its downward gradient became independent of |A| (a -0.1 and a -8.0 pushed
    down identically), and the reported `clip_fraction` was a per-call sum divided
    by the batch count (5.9, i.e. 590%). These tests pin the corrected behaviour.
    """

    def _group(self, A, k=None):
        model = tm.StyleBrain(6, 6, 4, seed=0)
        X = np.array([[1.0, 0, 0, 0, 0, 1], [0, 1.0, 0, 0, 0, 1], [0, 0, 1.0, 0, 0, 1]])
        if k is not None:
            X = X[:k]
        s = tm.policy_logits(model, X, 0.5)["s"]
        return model, X, s, np.asarray(A, dtype=float)

    def test_baseline_must_be_log_probabilities(self):
        model, X, s, A = self._group([1.0, 0.0, -1.0])
        got = {}
        for label, old in (("log_probs", [tm.log_softmax(s)]), ("raw_logits", [s])):
            du = []
            tm.grpo_loss_and_grads(model, [{"X": X, "A": A, "chosen": None}], old,
                                   temperature=0.5, entropy_coef=0.0, pref_coef=0.0,
                                   utility_grads_out=du)
            got[label] = du[0]
        # log-probs: rho == 1, so the objective keeps a real magnitude
        self.assertGreater(abs(got["log_probs"][2]), 1.0)
        # raw logits: rho == 1/Z, the gradient collapses by ~the group size
        self.assertLess(abs(got["raw_logits"][2]), abs(got["log_probs"][2]) / 50)

    def test_negative_advantage_scales_with_magnitude(self):
        """A -2.0 advantage must push its candidate down harder than a -0.1 one.

        With the raw-logit baseline both were frozen at the same value
        (measured 0.026815 for -0.1, -2.0 AND -8.0), i.e. the objective had
        degenerated to positive-only REINFORCE.
        """
        pushes = {}
        for label, m in (("weak", 0.1), ("strong", 2.0)):
            model, X, s, _ = self._group([1.0, 0.0, -m])
            A = np.array([1.0, 0.0, -m])
            du = []
            tm.grpo_loss_and_grads(model, [{"X": X, "A": A, "chosen": None}],
                                   [tm.log_softmax(s)], temperature=0.5,
                                   entropy_coef=0.0, pref_coef=0.0, utility_grads_out=du)
            pushes[label] = du[0][2]
            self.assertGreater(pushes[label], 0.0, "negative advantage must push down")
        self.assertGreater(pushes["strong"], 5 * pushes["weak"],
                           f"downward push did not scale with |A|: {pushes}")

    def test_positive_advantage_pushes_up(self):
        model, X, s, A = self._group([1.0, 0.0, -1.0])
        du = []
        tm.grpo_loss_and_grads(model, [{"X": X, "A": A, "chosen": None}],
                               [tm.log_softmax(s)], temperature=0.5, entropy_coef=0.0,
                               pref_coef=0.0, utility_grads_out=du)
        self.assertLess(du[0][0], 0.0, "positive advantage must raise its utility")

    def test_two_candidate_groups_carry_no_gradient(self):
        """Documented limitation of group standardisation: for K=2 the standardised
        logits are exactly +-1/T whatever the utilities are, so the objective is
        constant in them and the group teaches nothing. Use group >= 3."""
        model, X, s, A = self._group([1.0, -1.0], k=2)
        du = []
        tm.grpo_loss_and_grads(model, [{"X": X, "A": A, "chosen": None}],
                               [tm.log_softmax(s)], temperature=0.5, entropy_coef=0.0,
                               pref_coef=0.0, utility_grads_out=du)
        self.assertLess(float(np.abs(du[0]).max()), 1e-5)

    def test_reported_ratio_telemetry_is_a_real_fraction(self):
        with tempfile.TemporaryDirectory() as d:
            ds = os.path.join(d, "s.jsonl")
            synthetic_dataset(ds, n_clips=30, k=5, seed=0)
            m = tm.train(ds, os.path.join(d, "i.gguf"), creator="c", epochs=1,
                         warm_start=False)
            h = m["history"][-1]
            self.assertGreaterEqual(h["clip_fraction"], 0.0)
            self.assertLessEqual(h["clip_fraction"], 1.0,
                                 "clip_fraction must be a fraction, not a per-batch sum")
            self.assertLess(abs(h["mean_abs_rho_minus_1"]), 1e-9,
                            "a frozen baseline must give rho == 1")
            self.assertAlmostEqual(h["groups"], 1.0, places=6,
                                   msg="one group per objective call")


class TestPreferenceProvenance(unittest.TestCase):
    """Only an EXTERNAL judgment may be logged as a revealed preference.

    A pick the system itself made — the objective critic (`chosen_by=critic`) or the
    identity's own selection (`chosen_by=taste`) — is not evidence about the creator.
    It must still shape learning through the group-relative advantage over
    critic-derived rewards, but it must not train the auxiliary preference term or
    take the revealed-preference reward bonus. This is the local form of the
    "guarded transmission" rule in group-relative preference learning (Crayotter,
    arXiv:2608.02694): a group's own judgment must not be fed back as that group's
    label. It is also why the loop has to record WHO picked, not just WHAT was picked.
    """

    #: Real feature names. `to_vector` silently ignores unknown keys, so a typo here
    #: would produce all-zero vectors and a vacuously passing test — hence the
    #: non-degeneracy assertion in `_dataset`.
    _FEATURES = ("mean_shot_dur", "min_shot_dur", "log_n_segments")

    def _dataset(self, path: str, judges: list[str]) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            for i, who in enumerate(judges):
                fh.write(json.dumps({
                    "kind": "group", "group_id": f"g{i}", "clip_id": f"c{i}",
                    "feature_spec": tm.FEATURE_SPEC_VIDEO, "chosen": 1, "chosen_by": who,
                    "candidates": [
                        {"features": {name: 1.0 + j * (k + 1)
                                      for k, name in enumerate(self._FEATURES)},
                         "reward_obj": 0.5 - 0.1 * j,
                         "overall_obj": 0.5 - 0.1 * j, "dense_obj": 0.0}
                        for j in range(3)],
                }) + "\n")

    def test_only_external_judgments_are_pref_eligible(self):
        judges = ["creator", "agent", "human", "critic", "taste"]
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "prov.jsonl")
            self._dataset(path, judges)
            prepared, stats = tm.build_training_arrays(path)
        self.assertEqual(len(prepared), len(judges))
        self.assertGreater(float(prepared[0]["X"].std()), 0.0,
                           "fixture features are degenerate — renamed feature?")
        for i, who in enumerate(judges):
            self.assertEqual(
                prepared[i]["pref_eligible"], who in tm.EXTERNAL_JUDGES,
                f"chosen_by={who} must be pref_eligible={who in tm.EXTERNAL_JUDGES}")
        self.assertEqual(stats["groups_pref_ineligible"], 2)
        self.assertEqual(stats["picks_by_taste"], 1)
        self.assertEqual(stats["picks_by_critic"], 1)

    def test_reward_bonus_is_external_only(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "bonus.jsonl")
            self._dataset(path, ["creator", "taste"])
            prepared, _ = tm.build_training_arrays(path)
        creator, taste = prepared[0], prepared[1]
        # the creator's pick is pushed above the group's best score (0.5 + bonus 1.0)
        self.assertAlmostEqual(float(creator["rewards"][1]), 1.5, places=6)
        # the identity's own pick is left exactly as the critic scored it
        self.assertAlmostEqual(float(taste["rewards"][1]), 0.4, places=6)

    def test_system_pick_does_not_train_the_preference_term(self):
        model = tm.StyleBrain(6, 6, 4, seed=0)
        X = np.array([[1.0, 0, 0, 0, 0, 1], [0, 1.0, 0, 0, 0, 1], [0, 0, 1.0, 0, 0, 1]])
        old = [tm.log_softmax(tm.policy_logits(model, X, 0.5)["s"])]
        A = np.array([1.0, 0.0, -1.0])

        def loss(pref_eligible, chosen):
            return tm.grpo_loss_and_grads(
                model, [{"X": X, "A": A, "chosen": chosen, "pref_eligible": pref_eligible}],
                old, temperature=0.5, entropy_coef=0.0, pref_coef=0.5)["loss"]

        external, system, no_pick = loss(True, 1), loss(False, 1), loss(False, None)
        self.assertNotAlmostEqual(external, system, places=6,
                                  msg="an external pick must move the objective")
        self.assertAlmostEqual(system, no_pick, places=12,
                               msg="a system pick must be indistinguishable from no pick at all")

    def test_system_pick_still_learns_from_the_group_advantage(self):
        """The guard narrows the preference term, not the learning: a group whose pick
        the identity made still trains on the critic-derived rewards."""
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "onlysystem.jsonl")
            self._dataset(path, ["taste", "taste"])
            prepared, _ = tm.build_training_arrays(path)
        self.assertTrue(all(not p["pref_eligible"] for p in prepared))
        self.assertTrue(all(float(np.abs(p["A"]).max()) > 0.0 for p in prepared),
                        "the group-relative advantage must survive the guard")


class TestEffectFeatures(unittest.TestCase):
    """The v1 layout is blind to multi-input effects; v2 is not.

    Everything v1 measures describes the resulting CUT SEQUENCE, so a taste model
    trained on it can choose *which selection* to use but cannot set a transition's
    duration, a duck depth or a grade. v2 adds the effect-parameter features under a
    NEW spec id — never an edit of v1 — because the layout list is part of an
    artifact's digest, so a v1 identity keeps loading (and keeps refusing a v2 trunk)
    instead of being silently reinterpreted with shifted columns.
    """

    @staticmethod
    def _schema(**over) -> dict:
        seg = {"trim": {"in": 0.0, "out": 2.0}, "retime": 0.0,
               "timeline": {"in": 0.0, "out": 2.0},
               "transition": {"type": "cut", "dur": 0.0, "params": {}},
               "transform": {"scale": 1.0, "crop": None, "position": None},
               "grade": {"lut": None, "eq": {}},
               "audio": {"level": 1.0, "duck": 0.0, "fade": 0.0},
               "overlay": []}
        seg.update(over)
        return {"structure": [dict(seg), dict(seg)]}

    def test_v1_cannot_see_effects_and_v2_can(self):
        schema = self._schema(
            transition={"type": "dissolve", "dur": 1.2, "params": {"alignment": "start"}},
            transform={"scale": 1.2, "crop": None, "position": None},
            grade={"lut": "warm", "eq": {"saturation": 1.3}},
            audio={"level": 0.5, "duck": 0.6, "fade": 0.0},
            overlay=[{"kind": "text", "text": "hi"}])
        v1 = tm.features_for(tm.FEATURE_SPEC_VIDEO, schema, {}, {})
        v2 = tm.features_for(tm.FEATURE_SPEC_VIDEO_V2, schema, {}, {})
        for name in tm.VIDEO_EFFECT_FEATURES:
            self.assertNotIn(name, v1, f"the v1 layout must not silently gain {name}")
            self.assertIn(name, v2)
        self.assertGreater(v2["transition_dur_mean"], 0.0)
        self.assertEqual(v2["transition_align_center_frac"], 0.0)
        self.assertGreater(v2["grade_dev_mean"], 0.0)
        self.assertEqual(v2["lut_frac"], 1.0)
        self.assertEqual(v2["reframe_frac"], 1.0)
        self.assertAlmostEqual(v2["duck_depth_mean"], 0.6, places=6)
        self.assertLess(v2["gain_db_mean"], 0.0)
        self.assertEqual(v2["overlay_frac"], 1.0)

    def test_v2_is_a_superset_under_its_own_spec_id(self):
        self.assertNotEqual(tm.FEATURE_SPEC_VIDEO, tm.FEATURE_SPEC_VIDEO_V2)
        self.assertEqual(
            tm.FEATURE_SPECS[tm.FEATURE_SPEC_VIDEO_V2],
            tm.FEATURE_SPECS[tm.FEATURE_SPEC_VIDEO] + tm.VIDEO_EFFECT_FEATURES)

    def test_mixed_spec_log_trains_on_the_majority_layout(self):
        """v1 and v2 groups coexist in one log; mixing vector layouts would either
        crash the first forward pass or silently mis-align columns."""
        def group(i, spec):
            return {"kind": "group", "group_id": f"g{i}", "clip_id": f"c{i}",
                    "feature_spec": spec,
                    "candidates": [{"features": {"mean_shot_dur": 0.2 * (j + 1)},
                                    "reward_obj": 0.2 * j,
                                    "overall_obj": 0.2 * j, "dense_obj": 0.0}
                                   for j in range(3)]}
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "mixed.jsonl")
            with open(path, "w", encoding="utf-8") as fh:
                for i in range(3):
                    fh.write(json.dumps(group(i, tm.FEATURE_SPEC_VIDEO)) + "\n")
                fh.write(json.dumps(group(9, tm.FEATURE_SPEC_VIDEO_V2)) + "\n")
            prepared, stats = tm.build_training_arrays(path)
        self.assertEqual(stats["train_spec"], tm.FEATURE_SPEC_VIDEO)
        self.assertEqual(stats["groups_other_spec"], 1)
        self.assertEqual(stats["specs_seen"], [tm.FEATURE_SPEC_VIDEO, tm.FEATURE_SPEC_VIDEO_V2])
        self.assertTrue(all(p["spec"] == tm.FEATURE_SPEC_VIDEO for p in prepared))


class TestEffectTaste(unittest.TestCase):
    """Taste applied to a MULTI-INPUT EFFECT's parameters, not only to picks.

    The data is synthetic; the mechanism is the real one. Groups are logged under
    the effect-aware layout with a reward that rises with the transition duration —
    a hidden preference expressed ONLY through an effect parameter — an identity is
    trained on it, and the refiner must then choose a longer transition than the seed
    carries. The control is the same call with no identity: no taste, no invention.
    """

    _DURS = (0.0, 0.2, 0.4, 0.8, 1.2)

    @classmethod
    def _schema(cls, dur: float) -> dict:
        transition = ({"type": "dissolve", "dur": dur, "params": {"alignment": "center"}}
                      if dur > 0 else {"type": "cut", "dur": 0.0, "params": {}})
        seg = {"trim": {"in": 0.0, "out": 2.0}, "retime": 0.0,
               "timeline": {"in": 0.0, "out": 2.0}, "transition": transition,
               "transform": {"scale": 1.0, "crop": None, "position": None},
               "grade": {"lut": None, "eq": {}},
               "audio": {"level": 1.0, "duck": 0.0, "fade": 0.0}, "overlay": []}
        return {"structure": [dict(seg) for _ in range(4)]}

    def _log(self, path: str, clips: int = 6) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            for clip in range(clips):
                cands = []
                for dur in self._DURS:
                    schema = self._schema(dur)
                    cands.append({
                        "features": tm.features_for(tm.FEATURE_SPEC_VIDEO_V2, schema, {}, {}),
                        "reward_obj": 10.0 * dur, "overall_obj": 10.0 * dur, "dense_obj": 0.0})
                fh.write(json.dumps({"kind": "group", "group_id": f"g{clip}",
                                     "clip_id": f"c{clip}",
                                     "feature_spec": tm.FEATURE_SPEC_VIDEO_V2,
                                     "candidates": cands}) + "\n")

    def test_identity_chooses_effect_parameters(self):
        import edit_apart_core as core
        with tempfile.TemporaryDirectory() as d:
            log = os.path.join(d, "eff.jsonl")
            self._log(log)
            identity = os.path.join(d, "identity.gguf")
            metrics = tm.train(log, identity, creator="c", epochs=120, seed=0)
            self.assertGreaterEqual(metrics["history"][-1]["train_rank_acc"], 0.8,
                                    "the identity did not fit a preference over an effect")
            scorer = tm.TasteScorer.load(identity)
        result = core.refine_effects(tm, self._schema(0.0), {}, {}, scorer, steps=6)
        durations = [float(seg["transition"]["dur"]) for seg in result["schema"]["structure"]]
        # `transition` is the transition INTO a segment, so segment 0 is a lead-in
        # and must carry none; the others must carry the chosen dissolve.
        self.assertEqual(durations[0], 0.0, "the lead-in must not carry a transition")
        self.assertTrue(all(d > 0 for d in durations[1:]),
                        f"the identity did not choose a transition at all: {durations}")
        self.assertGreater(max(durations), 0.8,
                           f"the identity did not push the duration up: {durations}")
        self.assertTrue(result["trace"], "no axis change was recorded")
        self.assertEqual(result["knobs"]["transition"], "dissolve")

    def test_no_identity_means_no_effect_taste(self):
        """The control: with no identity the refiner must change nothing. Maximising
        the objective critic here would silently turn a rubric rule into a taste
        claim — the same class of error as logging a system pick as a preference."""
        import edit_apart_core as core
        seed = self._schema(0.0)
        result = core.refine_effects(tm, seed, {}, {}, None, steps=6)
        self.assertIsNone(result["score"])
        self.assertEqual(result["trace"], [])
        self.assertEqual([seg["transition"]["type"] for seg in result["schema"]["structure"]],
                         ["cut", "cut", "cut", "cut"])


class TestEffectGrid(unittest.TestCase):
    """A group the engine can actually learn an effect from.

    The DEFAULT candidate grid varies shot selection only, so every candidate in a
    group agrees on every effect feature — nothing in the loop could ever teach an
    effect preference, and `refine` would have nothing to apply. `--effect-grid` pairs
    the selection grid with effect knobs, so a revealed pick between two effect
    settings becomes learnable. The default stays selection-only on purpose: changing
    it would silently invalidate every measurement already recorded against it.
    """

    INVENTORY = {"source": "synthetic",
                 "shots": [{"shot": f"clip_{i:03d}", "start": float(2 * i),
                            "end": float(2 * i + 2), "duration": 2.0,
                            "features": {"motion": 0.5, "lum": 0.5, "rms": -20.0}}
                           for i in range(8)]}
    RUBRIC = {"intent": "test", "pace": "medium", "min_shot_dur": 0.8,
              "max_shot_dur": 4.0, "target_duration": 16.0, "no_shot_under_s": 0.9}

    @staticmethod
    def _candidates(path: str) -> list[dict]:
        with open(path, encoding="utf-8") as fh:
            return json.loads(fh.readline())["candidates"]

    def test_effect_grid_spans_effect_parameters_and_logs_v2(self):
        import edit_apart_core as core
        with tempfile.TemporaryDirectory() as d:
            plain, effect = os.path.join(d, "plain.jsonl"), os.path.join(d, "effect.jsonl")
            out = core.cmd_propose(self.INVENTORY, self.RUBRIC, group=6,
                                   dataset=plain, clip_id="c1")
            self.assertEqual(out["group"]["feature_spec"], tm.FEATURE_SPEC_VIDEO)
            out2 = core.cmd_propose(self.INVENTORY, self.RUBRIC, group=6,
                                    dataset=effect, clip_id="c2", effect_grid=True)
            self.assertEqual(out2["group"]["feature_spec"], tm.FEATURE_SPEC_VIDEO_V2)
            plain_cands, effect_cands = self._candidates(plain), self._candidates(effect)
        # Only fields the RENDERER executes may appear in the grid: duck, LUT,
        # overlay and position are declared-but-unrendered and must stay constant.
        for name in ("transition_dur_mean", "transition_frac", "grade_dev_mean"):
            legacy = {round(c["features"].get(name, 0.0), 6) for c in plain_cands}
            spanned = {round(c["features"].get(name, 0.0), 6) for c in effect_cands}
            self.assertEqual(len(legacy), 1,
                             f"the legacy grid must not vary {name} (it is the layout v1 cannot see)")
            self.assertGreater(len(spanned), 1,
                               f"the effect grid must span {name} or nothing is learnable")
        self.assertTrue(any(c["knobs"].get("transition_dur") for c in effect_cands),
                        "no candidate carries an effect knob")
        for unrendered in ("duck_depth_mean", "lut_frac", "overlay_frac"):
            self.assertEqual({round(c["features"].get(unrendered, 0.0), 6)
                              for c in effect_cands}, {0.0},
                             f"{unrendered} is measured but not rendered — it must stay 0")


class TestRenderedEffectContract(unittest.TestCase):
    """A schema field the renderer does not execute may never carry a live value.

    The v2 layout measures `duck_depth_mean`, `lut_frac`, `overlay_frac` and part of
    `reframe_frac`; until those are rendered (sidechaincompress needs a music bed,
    lut3d a LUT file, an overlay an overlay source, position a canvas), writing them
    would train a preference with no observable consequence and log an edit decision
    the picture does not contain. `assert_renderable` refuses them, and the effect
    grid may not span them.
    """

    def _schema(self, **over):
        seg = {"trim": {"in": 0.0, "out": 2.0}, "retime": 0.0,
               "timeline": {"in": 0.0, "out": 2.0},
               "transition": {"type": "cut", "dur": 0.0, "params": {}},
               "transform": {"scale": 1.0, "crop": None, "position": None},
               "grade": {"lut": None, "eq": {}},
               "audio": {"level": 1.0, "duck": 0.0, "fade": 0.0}, "overlay": []}
        seg.update(over)
        return {"structure": [dict(seg), dict(seg)]}

    def test_unrendered_fields_are_refused(self):
        import edit_apart_core as core
        for over in ({"audio": {"level": 1.0, "duck": 0.6, "fade": 0.0}},
                     {"grade": {"lut": "warm.lut", "eq": {}}},
                     {"overlay": [{"kind": "text", "text": "hi"}]},
                     {"transform": {"scale": 1.0, "crop": None, "position": {"x": 0.1}}}):
            with self.assertRaises(RuntimeError, msg=f"{over} must be refused"):
                core.assert_renderable(self._schema(**over))

    def test_rendered_fields_pass_the_gate(self):
        import edit_apart_core as core
        core.assert_renderable(self._schema(
            transition={"type": "dissolve", "dur": 0.8, "params": {"alignment": "center"}},
            grade={"lut": None, "eq": {"saturation": 1.2}}))

    def test_an_unknown_transition_type_is_refused(self):
        import edit_apart_core as core
        with self.assertRaises(RuntimeError):
            core.assert_renderable(self._schema(
                transition={"type": "whip_pan", "dur": 0.4, "params": {}}))

    def test_apply_effects_leaves_the_lead_in_alone(self):
        """`transition` is the transition INTO a segment; segment 0 has none."""
        import edit_apart_core as core
        schema = self._schema()
        core.apply_effects(schema, {"transition": "dissolve", "transition_dur": 0.5})
        self.assertEqual(schema["structure"][0]["transition"]["type"], "cut")
        self.assertEqual(schema["structure"][1]["transition"]["type"], "dissolve")

    def test_a_transition_longer_than_its_shot_is_clamped_when_written(self):
        """The value WRITTEN must be one the renderer can realise."""
        import edit_apart_core as core
        base = self._schema()
        short = {"structure": [
            {**base["structure"][0], "trim": {"in": 0.0, "out": 0.4},
             "timeline": {"in": 0.0, "out": 0.4}},
            {**base["structure"][1], "trim": {"in": 0.0, "out": 0.4},
             "timeline": {"in": 0.0, "out": 0.4}}]}
        core.apply_effects(short, {"transition": "dissolve", "transition_dur": 1.2})
        self.assertLessEqual(float(short["structure"][1]["transition"]["dur"]), 0.4)

    def test_plan_groups_cuts_into_one_run_and_transitions_into_several(self):
        import edit_apart_core as core
        cut = core.transition_plan(self._schema()["structure"], [2.0, 2.0])
        self.assertEqual(len(cut["runs"]), 1,
                         "an all-cut edit must stay one run (plain concat, unchanged path)")
        self.assertEqual(cut["plan"], [])
        mixed = self._schema(
            transition={"type": "dissolve", "dur": 1.0, "params": {"alignment": "center"}})
        plan = core.transition_plan(mixed["structure"], [2.0, 2.0], fps=25.0)
        self.assertEqual(len(plan["runs"]), 2)
        step = plan["plan"][0]
        # frame-exact: 0.5 s is 12.5 frames at 25 fps, snapped to 12 (0.48 s), and the
        # rendered duration is sum(durations) - a
        self.assertAlmostEqual(step["a"], 0.48, places=9)
        self.assertAlmostEqual(step["b"], 0.52, places=9)
        self.assertAlmostEqual(step["offset"], 2.0 - step["a"], places=9)
        self.assertFalse(step["clamped"])

    def test_lead_in_is_not_counted_as_a_transition(self):
        """`transition_frac` must not exceed 1: it counts boundaries, not segments."""
        schema = self._schema(
            transition={"type": "dissolve", "dur": 0.4, "params": {"alignment": "center"}})
        feats = tm.features_for(tm.FEATURE_SPEC_VIDEO_V2, schema, {}, {})
        self.assertLessEqual(feats["transition_frac"], 1.0)
        self.assertAlmostEqual(feats["transition_frac"], 1.0, places=9)


class TestEffectCredit(unittest.TestCase):
    """Credit attributed to the decision that actually varied.

    Two properties make the difference between a real attribution and a plausible
    one. Rows are keyed by SHOT: candidates of a group can select different numbers
    of shots, so index 6 of one candidate is a different shot from index 6 of another
    and an index-keyed diff invents changes (a real value against None) and blames
    them on an effect. And the axis comes from the logged KNOBS, because a coupled
    decision — transition type/duration/alignment — legitimately moves together; a
    slot count would misreport it as three independent decisions.
    """

    INVENTORY = {"source": "synthetic",
                 "shots": [{"shot": f"clip_{i:03d}", "start": float(2 * i),
                            "end": float(2 * i + 2), "duration": 2.0,
                            "features": {"motion": 0.5, "lum": 0.5, "rms": -20.0}}
                           for i in range(8)]}
    RUBRIC = {"intent": "test", "pace": "medium", "min_shot_dur": 0.8,
              "max_shot_dur": 4.0, "target_duration": 16.0, "no_shot_under_s": 0.9}

    def _log(self, path, effect_grid=True, group=4, clip="c1"):
        import edit_apart_core as core
        core.cmd_propose(self.INVENTORY, self.RUBRIC, group=group, dataset=path,
                         clip_id=clip, effect_grid=effect_grid)
        with open(path, encoding="utf-8") as fh:
            return json.loads(fh.readline())

    def test_advantages_match_the_trainer(self):
        """The pure-Python attribution advantage must equal the training definition."""
        import edit_apart_core as core
        rewards = [0.2, -0.5, 1.1, 0.4]
        mine = core._advantages(rewards)
        theirs = [float(a) for a in tm.group_advantage(np.array(rewards))]
        # The same definition, evaluated in pure Python vs numpy: equal to floating-point
        # tolerance, which is what "the same" means for a magnitude.
        for got, expected in zip(mine, theirs):
            self.assertAlmostEqual(got, expected, places=7)

    def test_effect_grid_holds_the_selection_so_credit_is_attributable(self):
        import edit_apart_core as core
        with tempfile.TemporaryDirectory() as d:
            record = self._log(os.path.join(d, "eff.jsonl"))
            table = core.attribute_credit(record)
        shot_lists = {tuple(seg["shot"] for seg in c["schema"]["structure"])
                      for c in record["candidates"]}
        self.assertEqual(len(shot_lists), 1,
                         "an effect group must keep the same material for every candidate")
        self.assertFalse(table["selection_changed"])
        self.assertTrue(table["knob_axis"], "the varying knob set names the axis")
        self.assertTrue(table["attributable"])
        self.assertTrue(table["changed_rows"], "nothing was reported as changed")
        # rows are keyed by shot, and every shot id is a real one
        for row in table["rows"]:
            self.assertIn(row["shot"], {seg["shot"] for seg in
                                        record["candidates"][0]["schema"]["structure"]})
        # the advantages are zero-mean and unit-scale, like the training signal
        advantages = table["rows"][0]["advantages"]
        self.assertAlmostEqual(sum(advantages) / len(advantages), 0.0, places=6)

    def test_a_selection_varying_group_is_not_attributable(self):
        """Different material means the advantage cannot be blamed on an effect."""
        import edit_apart_core as core
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "sel.jsonl")
            record = self._log(path, effect_grid=False)
            table = core.attribute_credit(record)
            profile = core.effect_credit_profile(path)
        self.assertTrue(table["selection_changed"])
        self.assertFalse(table["attributable"])
        self.assertEqual(profile["attributed_groups"], 0)
        self.assertEqual(profile["selection_confounded_groups"], 1)

    def test_the_profile_separates_the_axis_values(self):
        import edit_apart_core as core
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "many.jsonl")
            for clip in range(3):
                self._log(path, clip=f"c{clip}")
            profile = core.effect_credit_profile(path)
        self.assertEqual(profile["groups"], 3)
        self.assertEqual(profile["attributed_groups"], 3)
        self.assertEqual(len(profile["axes"]), 1, "the grid varies one coupled decision")
        axis, buckets = next(iter(profile["axes"].items()))
        self.assertIn("transition_dur", axis)
        values = {json.dumps(b["value"]) for b in buckets.values()}
        self.assertGreaterEqual(len(values), 3, "the grid's values must be separated")
        for bucket in buckets.values():
            self.assertEqual(bucket["n"], 3)
            self.assertIn("reward_mean", bucket)

    def test_the_critic_cannot_see_a_transition(self):
        """Documents WHY the taste model has to learn effects from external picks: the
        objective critic scores duration/motion/target, so every transition value in a
        group earns the same reward. If this ever stops being flat, the critic grew a
        transition-aware leg and the attribution story changes."""
        import edit_apart_core as core
        with tempfile.TemporaryDirectory() as d:
            record = self._log(os.path.join(d, "flat.jsonl"))
            profile = core.effect_credit_profile(os.path.join(d, "flat.jsonl"))
        rewards = {c.get("reward_obj") for c in record["candidates"]}
        self.assertEqual(len(rewards), 1, f"the objective critic is transition-blind: {rewards}")
        for buckets in profile["axes"].values():
            self.assertEqual(len({b["reward_mean"] for b in buckets.values()}), 1)


class TestLutRendering(unittest.TestCase):
    """`grade.lut` is a RENDERED field: it resolves to a real `.cube` or it is refused.

    The LUTs are generated text, so the grade they apply is reviewable in a diff and
    reproducible; `--check` catches a hand-edited LUT that does not match its
    generator. A name that resolves to nothing is refused rather than silently
    ungraded, for the same reason as any other unrendered field.
    """

    def _schema(self, lut):
        seg = {"trim": {"in": 0.0, "out": 2.0}, "retime": 0.0,
               "timeline": {"in": 0.0, "out": 2.0},
               "transition": {"type": "cut", "dur": 0.0, "params": {}},
               "transform": {"scale": 1.0, "crop": None, "position": None},
               "grade": {"lut": lut, "eq": {}},
               "audio": {"level": 1.0, "duck": 0.0, "fade": 0.0}, "overlay": []}
        return {"structure": [dict(seg), dict(seg)]}

    def test_the_shipped_luts_match_their_generator(self):
        import subprocess
        r = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "make_luts.py"),
                            "--check"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, f"stale LUTs: {r.stderr}")

    def test_a_bare_name_resolves_and_an_unknown_one_does_not(self):
        import edit_apart_core as core
        warm = core.resolve_lut("warm")
        self.assertIsNotNone(warm)
        self.assertTrue(warm.endswith("warm.cube"))
        self.assertTrue(os.path.isfile(warm))
        self.assertIsNone(core.resolve_lut("definitely-not-a-lut"))

    def test_the_gate_accepts_a_resolvable_lut_and_refuses_an_unknown_one(self):
        import edit_apart_core as core
        core.assert_renderable(self._schema("warm"))
        core.assert_renderable(self._schema("cool"))
        with self.assertRaises(RuntimeError):
            core.assert_renderable(self._schema("definitely-not-a-lut"))

    def test_lut_frac_reflects_a_declared_lut(self):
        feats = tm.features_for(tm.FEATURE_SPEC_VIDEO_V2, self._schema("warm"), {}, {})
        self.assertEqual(feats["lut_frac"], 1.0)
        plain = tm.features_for(tm.FEATURE_SPEC_VIDEO_V2, self._schema(None), {}, {})
        self.assertEqual(plain["lut_frac"], 0.0)


class TestLogReplay(unittest.TestCase):
    """A logged group must be re-derivable from the record alone.

    The log used to keep only derived numbers — no rubric, no inventory, no timeline,
    no source identity — so a defect in the feature extractor or a change to the critic
    made the whole corpus un-remeasurable and would have forced a re-shoot. This
    project's own corrections log is a history of exactly that: three conclusions
    flipped after defects, and each had to be re-measured on the same data. Schema v3
    keeps the constraints, the evidence and the timelines; `replay` recomputes from
    them and compares. These tests are the acceptance criterion for "we keep the raws".
    """

    INVENTORY = {"source": "synthetic",
                 "shots": [{"shot": f"clip_{i:03d}", "start": float(2 * i),
                            "end": float(2 * i + 2), "duration": 2.0,
                            "features": {"motion": 0.5, "lum": 0.5, "rms": -20.0}}
                           for i in range(8)]}
    RUBRIC = {"intent": "test", "pace": "medium", "min_shot_dur": 0.8,
              "max_shot_dur": 4.0, "target_duration": 16.0, "no_shot_under_s": 0.9}

    def _log(self, path: str, inventory: dict | None = None):
        import edit_apart_core as core
        core.cmd_propose(inventory or self.INVENTORY, self.RUBRIC, group=4,
                         dataset=path, clip_id="c1", effect_grid=True)
        return core

    def test_a_logged_group_replays_exactly(self):
        import edit_apart_core as core
        with tempfile.TemporaryDirectory() as d:
            dataset = os.path.join(d, "v3.jsonl")
            self._log(dataset)
            report = core.cmd_replay(dataset)
        self.assertEqual(report["groups"], 1)
        self.assertEqual(report["not_replayable"], 0, "a fresh v3 record must be replayable")
        self.assertEqual(report["mismatches"], [])
        self.assertEqual(report["features_match"], report["candidates_checked"])
        self.assertEqual(report["rewards_match"], report["candidates_checked"])
        self.assertTrue(report["ok"])

    def test_the_record_carries_what_a_replay_needs(self):
        with tempfile.TemporaryDirectory() as d:
            dataset = os.path.join(d, "v3.jsonl")
            self._log(dataset)
            with open(dataset, encoding="utf-8") as fh:
                rec = json.loads(fh.readline())
        self.assertGreaterEqual(rec["dataset_schema_version"], 3)
        for key in ("rubric", "inventory", "rubric_hash", "inventory_hash",
                    "content_hash", "selected", "engine"):
            self.assertIn(key, rec, f"{key} is required to replay a group")
        for cand in rec["candidates"]:
            self.assertIsInstance(cand.get("schema"), dict,
                                  "the TIMELINE must be in the record, not just its knobs")

    def test_content_hash_is_deterministic_but_group_id_is_not(self):
        """The content hash is what a ledger keys annotations to — two runs of the same
        proposal must agree on it, while `group_id` stays instance-unique."""
        import edit_apart_core as core
        with tempfile.TemporaryDirectory() as d:
            first, second = os.path.join(d, "a.jsonl"), os.path.join(d, "b.jsonl")
            self._log(first)
            self._log(second)
            records = []
            for path in (first, second):
                with open(path, encoding="utf-8") as fh:
                    records.append(json.loads(fh.readline()))
        self.assertEqual(records[0]["content_hash"], records[1]["content_hash"])
        self.assertNotEqual(records[0]["group_id"], records[1]["group_id"])

    def test_replay_detects_feature_drift(self):
        """The negative control: a stale/incorrect stored vector must be caught."""
        import edit_apart_core as core
        with tempfile.TemporaryDirectory() as d:
            dataset = os.path.join(d, "v3.jsonl")
            self._log(dataset)
            with open(dataset, encoding="utf-8") as fh:
                rec = json.loads(fh.readline())
            rec["candidates"][0]["features"]["mean_shot_dur"] += 0.5      # corrupt the log
            with open(dataset, "w", encoding="utf-8") as fh:
                fh.write(json.dumps(rec) + "\n")
            report = core.cmd_replay(dataset)
        self.assertEqual(report["clean"], 0)
        self.assertTrue(report["mismatches"], "feature drift went undetected")
        self.assertIn("features[0]", report["mismatches"][0]["problems"])
        self.assertFalse(report["ok"])

    def test_source_media_is_identified_by_hash_and_drift_is_caught(self):
        """Keeping the raws only counts if we can tell they are the SAME raws."""
        import edit_apart_core as core
        with tempfile.TemporaryDirectory() as d:
            media = os.path.join(d, "source.mp4")
            with open(media, "wb") as fh:
                fh.write(b"not really an mp4, but a stable identity")
            inventory = {**self.INVENTORY, "source": media}
            good = os.path.join(d, "good.jsonl")
            self._log(good, inventory)
            report = core.cmd_replay(good)
            self.assertEqual(report["source_hash_checked"], 1)
            self.assertEqual(report["mismatches"], [])
            with open(media, "ab") as fh:                                  # the raw changed
                fh.write(b" ...edited")
            drifted = core.cmd_replay(good)
        self.assertTrue(drifted["mismatches"], "a changed source went undetected")
        self.assertIn("source_sha256", drifted["mismatches"][0]["problems"])

    def test_replay_reports_older_records_as_not_replayable(self):
        """No guessing: a record without the timeline/evidence says so explicitly."""
        import edit_apart_core as core
        legacy = {"kind": "group", "group_id": "g0", "clip_id": "c0",
                  "feature_spec": tm.FEATURE_SPEC_VIDEO,
                  "candidates": [{"idx": 0, "knobs": {}, "features": {"mean_shot_dur": 0.3},
                                  "reward_obj": 0.4, "overall_obj": 0.4, "dense_obj": 0.0}]}
        with tempfile.TemporaryDirectory() as d:
            dataset = os.path.join(d, "old.jsonl")
            with open(dataset, "w", encoding="utf-8") as fh:
                fh.write(json.dumps(legacy) + "\n")
            report = core.cmd_replay(dataset)
        self.assertEqual(report["groups"], 1)
        self.assertEqual(report["not_replayable"], 1)
        self.assertEqual(report["replayable"], 0)
        self.assertEqual(report["mismatches"], [], "an old record is not a failure")
        self.assertFalse(report["ok"], "but it is not a passing replay either")


class TestGGUF(unittest.TestCase):
    def test_round_trip_bit_exact(self):
        with tempfile.TemporaryDirectory() as d:
            m = tm.StyleBrain(d_in=7, d_h=5, d_z=4, seed=2)
            path = os.path.join(d, "sb.gguf")
            tm.write_gguf(path, {"general.architecture": "editapart-taste",
                                 "editapart.kind": "style_brain",
                                 "editapart.features": ["a", "b", "c"],
                                 "editapart.d_in": 7, "editapart.d_h": 5,
                                 "editapart.d_z": 4, "flag": True, "ratio": 0.25,
                                 "count": 9},
                          m.shared_tensors())
            back = tm.read_gguf(path)
            self.assertEqual(back["metadata"]["editapart.features"], ["a", "b", "c"])
            self.assertIs(back["metadata"]["flag"], True)
            self.assertEqual(back["metadata"]["count"], 9)
            self.assertAlmostEqual(back["metadata"]["ratio"], 0.25, places=6)
            for name, arr in m.shared_tensors().items():
                self.assertTrue(np.array_equal(back["tensors"][name], arr.astype(np.float32)),
                                f"{name} did not round-trip")
                self.assertEqual(back["tensors"][name].shape, arr.shape)

    def test_rejects_non_gguf(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "junk.gguf")
            with open(p, "wb") as fh:
                fh.write(b"not a gguf file at all")
            with self.assertRaises(ValueError):
                tm.read_gguf(p)

    def test_identity_load_refuses_digest_mismatch(self):
        with tempfile.TemporaryDirectory() as d:
            ident = os.path.join(d, "erkin.gguf")
            tm.init_identity(ident, creator="erkin")
            # A second, different style-brain must not be accepted.
            other = tm.StyleBrain(d_in=len(tm.VIDEO_FEATURES), d_h=24, d_z=16, seed=99)
            tm.write_gguf(os.path.join(d, "other.gguf"), {
                "general.architecture": "editapart-taste", "editapart.kind": "style_brain",
                "editapart.feature_spec": tm.FEATURE_SPEC_VIDEO,
                "editapart.model_layout": tm.MODEL_LAYOUT,
                "editapart.d_in": 16, "editapart.d_h": 24, "editapart.d_z": 16,
            }, other.shared_tensors())
            with self.assertRaises(ValueError) as cm:
                tm.TasteScorer.load(ident, style=os.path.join(d, "other.gguf"))
            self.assertIn("digest", str(cm.exception))

    def test_older_model_layout_is_refused_with_guidance(self):
        """A style-brain written by an older parameter layout must not be loaded
        silently — it has to say what to do about it."""
        with tempfile.TemporaryDirectory() as d:
            m = tm.StyleBrain(len(tm.VIDEO_FEATURES), 24, 16, seed=0)
            style = os.path.join(d, "style_brain_video_v1.gguf")
            tm.write_gguf(style, {"general.architecture": "editapart-taste",
                                  "editapart.kind": "style_brain",
                                  "editapart.feature_spec": tm.FEATURE_SPEC_VIDEO,
                                  "editapart.d_in": 16, "editapart.d_h": 24,
                                  "editapart.d_z": 16}, m.shared_tensors())
            with self.assertRaises(ValueError) as cm:
                tm.init_identity(os.path.join(d, "i.gguf"), creator="old")
            msg = str(cm.exception)
            self.assertIn("layout", msg)
            self.assertIn("train_identity", msg)

    def test_missing_style_brain_is_explicit(self):
        with tempfile.TemporaryDirectory() as d:
            ident = os.path.join(d, "erkin.gguf")
            tm.init_identity(ident, creator="erkin")
            os.remove(os.path.join(d, "style_brain_video_v1.gguf"))
            with self.assertRaises(FileNotFoundError):
                tm.TasteScorer.load(ident)


class TestDatasetFolding(unittest.TestCase):
    def test_group_reward_and_legacy_records(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "log.jsonl")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(json.dumps({"kind": "group", "group_id": "g1", "clip_id": "c1",
                                     "feature_spec": tm.FEATURE_SPEC_VIDEO,
                                     "candidates": [
                                         {"features": {"bias": 1.0}, "reward_obj": -1.0,
                                          "overall_obj": -0.5, "dense_obj": -0.5},
                                         {"features": {"bias": 1.0}, "reward_obj": -2.0,
                                          "overall_obj": -1.0, "dense_obj": -1.0}]}) + "\n")
                fh.write(json.dumps({"kind": "reward", "group_id": "g1", "candidate": 0,
                                     "reward": 0.25, "overall_obj": 0.5,
                                     "dense_obj": -0.25, "subjective": 0.9}) + "\n")
                fh.write(json.dumps({"features": [1, 0, 1], "score": 0.7,
                                     "deltas": [0.0, -0.2]}) + "\n")
            groups, stats = tm.load_groups(path)
            self.assertEqual(len(groups), 2)
            self.assertEqual(stats["legacy_singletons"], 1)
            self.assertEqual(stats["reward_records"], 1)
            g = groups[0]
            self.assertEqual(g["chosen"], 0)
            self.assertEqual(g["candidates"][0]["reward"], 0.25)
            self.assertEqual(g["candidates"][0]["reward_source"], "critic")

            # lambda_dense is applied to the separate overall/dense components.
            prepared, _ = tm.build_training_arrays(path, lambda_dense=1.0)
            g1 = next(p for p in prepared if p["group_id"] == "g1")
            self.assertAlmostEqual(float(g1["rewards"][0]), 0.5 - 0.25, places=6)
            prepared2, _ = tm.build_training_arrays(path, lambda_dense=2.0)
            g1b = next(p for p in prepared2 if p["group_id"] == "g1")
            self.assertAlmostEqual(float(g1b["rewards"][0]), 0.5 - 0.5, places=6)

    def test_null_rewards_do_not_crash_and_are_skipped(self):
        """The photo engine writes `"reward_obj": null` for unscored candidates.
        `float(None)` used to abort taste_status/train on the whole file."""
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "null.jsonl")
            with open(path, "w", encoding="utf-8") as fh:
                # a group with NO scored candidates
                fh.write(json.dumps({"kind": "group", "group_id": "allnull",
                                     "feature_spec": tm.FEATURE_SPEC_PHOTO,
                                     "candidates": [
                                         {"features": {"crop_area": 0.3}, "reward_obj": None},
                                         {"features": {"crop_area": 0.2}, "reward_obj": None}]}) + "\n")
                # a group with one scored candidate and one null
                fh.write(json.dumps({"kind": "group", "group_id": "partial",
                                     "feature_spec": tm.FEATURE_SPEC_PHOTO,
                                     "candidates": [
                                         {"features": {"crop_area": 0.3}, "reward_obj": 0.5},
                                         {"features": {"crop_area": 0.2}, "reward_obj": None}]}) + "\n")
            groups, stats = tm.load_groups(path)          # must not raise
            self.assertEqual(len(groups), 2)
            prepared, pstats = tm.build_training_arrays(path)
            self.assertEqual(pstats.get("candidates_unscored"), 3)
            self.assertEqual(len(prepared), 0,
                             "groups without enough scored candidates teach nothing")
            status = tm.dataset_status(path)              # must not raise either
            self.assertTrue(status["exists"])

    def test_hard_broken_record_is_counted_not_fatal(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "log.jsonl")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write("{not json}\n")
                fh.write(json.dumps({"kind": "group", "group_id": "g", "candidates": [
                    {"features": {}, "reward_obj": 1.0}]}) + "\n")
            groups, stats = tm.load_groups(path)
            self.assertEqual(stats["bad_lines"], 1)
            self.assertEqual(len(groups), 1)


class TestLearning(unittest.TestCase):
    """Can the objective recover a hidden preference it is never shown?

    Reward is a hidden linear taste over the feature layout; the model only ever
    sees group-relative rewards. Baseline for reference: a least-squares linear
    fit on the same features reaches 1.00 held-out ranking accuracy, and a
    supervised pairwise-ranking loss on this architecture reaches ~0.80. GRPO
    (no reward supervision at all) lands around 0.66-0.70, i.e. well above the
    0.20 chance level but below the supervised bound — the honest characterisation
    is "recovers a real preference signal, at the sample cost you expect from a
    policy-gradient objective".
    """

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix="tastelearn_")
        cls.dataset = os.path.join(cls.tmp, "synth.jsonl")
        synthetic_dataset(cls.dataset, n_clips=120, k=5, seed=0)
        cls.identity = os.path.join(cls.tmp, "synth.gguf")
        cls.metrics = tm.train(cls.dataset, cls.identity, creator="synth", epochs=150,
                               lr_muon=0.005, lr_adamw=0.005, temperature=0.5,
                               holdout_every=5, seed=0)

    @classmethod
    def tearDownClass(cls):
        import shutil
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def test_recovers_held_out_preferences(self):
        """The primary metric is within-group pairwise agreement (chance 0.5),
        because argmax accuracy is quantised by the group size and is far noisier:
        measured 0.53 vs 0.74 respectively on identical runs."""
        m = self.metrics
        self.assertGreaterEqual(m["eval_pair_agree_after"], 0.7,
                                f"held-out pairwise agreement {m['eval_pair_agree_after']} "
                                f"(chance {m['chance_pair_agree']})")
        self.assertGreater(m["eval_rank_acc_after"], 2 * m["chance_rank_acc"],
                           f"argmax accuracy {m['eval_rank_acc_after']} not above twice chance "
                           f"{m['chance_rank_acc']}")

    def test_learning_improves_over_initialisation(self):
        m = self.metrics
        self.assertGreater(m["eval_pair_agree_after"], m["eval_pair_agree_before"],
                           f"pair agreement before {m['eval_pair_agree_before']} "
                           f"after {m['eval_pair_agree_after']}")

    def test_recovers_preferences_across_seeds(self):
        scores = [self.metrics["eval_pair_agree_after"]]
        for seed in (1, 2):
            m = tm.train(self.dataset, os.path.join(self.tmp, f"seed{seed}.gguf"),
                         creator="synth", epochs=150, lr_muon=0.005, lr_adamw=0.005,
                         temperature=0.5, holdout_every=5, seed=seed, warm_start=False)
            self.assertGreater(m["eval_pair_agree_after"], m["eval_pair_agree_before"],
                               f"seed {seed}: no improvement")
            scores.append(m["eval_pair_agree_after"])
        mean = sum(scores) / len(scores)
        self.assertGreaterEqual(mean, 0.7, f"mean held-out pairwise agreement over 3 seeds {mean:.3f}")

    def test_latent_actually_moved(self):
        self.assertGreater(self.metrics["z_u_norm"], 1e-6,
                           "z_u never moved — AdamW is not reaching the identity")

    def test_artifacts_written_and_reloadable(self):
        scorer = tm.TasteScorer.load(self.identity)
        info = scorer.info()
        self.assertEqual(info["creator"], "synth")
        self.assertEqual(info["trained_groups"], self.metrics["train_groups"])
        self.assertTrue(os.path.getsize(self.metrics["style_brain"]) > 0)
        self.assertTrue(os.path.getsize(self.identity) > 0)
        # Per-creator artifact stays tiny compared with the shared trunk.
        self.assertLess(os.path.getsize(self.identity), os.path.getsize(self.metrics["style_brain"]))

    def test_determinism(self):
        again = tm.train(self.dataset, os.path.join(self.tmp, "synth2.gguf"), creator="synth",
                         epochs=150, lr_muon=0.005, lr_adamw=0.005, temperature=0.5,
                         holdout_every=5, seed=0, warm_start=False)
        self.assertEqual(again["eval_rank_acc_after"], self.metrics["eval_rank_acc_after"])
        self.assertEqual(again["z_u"], self.metrics["z_u"])

    def test_singleton_dataset_is_refused_with_a_reason(self):
        path = os.path.join(self.tmp, "singletons.jsonl")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"features": [1, 0, 1], "score": 0.7, "deltas": [0.0]}) + "\n")
        with self.assertRaises(SystemExit) as cm:
            tm.train(path, os.path.join(self.tmp, "x.gguf"), epochs=1)
        self.assertIn("group-relative", str(cm.exception))


class TestIdentitySemantics(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="tasteid_")
        self.dataset = os.path.join(self.tmp, "synth.jsonl")
        synthetic_dataset(self.dataset, n_clips=24, k=5, seed=1)
        self.identity = os.path.join(self.tmp, "a.gguf")
        tm.train(self.dataset, self.identity, creator="a", epochs=30, seed=0)
        self.scorer = tm.TasteScorer.load(self.identity)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_latent_is_required_for_the_scorer_and_is_nonzero(self):
        self.assertGreater(np.linalg.norm(self.scorer.model.p["z_u"]), 1e-6)

    def test_zeroing_the_latent_changes_scores(self):
        rng = np.random.default_rng(0)
        feats = [{n: float(v) for n, v in zip(tm.VIDEO_FEATURES, rng.normal(size=16))}
                 for _ in range(6)]
        before = self.scorer.score_many(feats)
        self.scorer.model.p["z_u"] = np.zeros_like(self.scorer.model.p["z_u"])
        after = self.scorer.score_many(feats)
        self.assertFalse(np.allclose(before, after),
                         "the identity latent has no effect on the taste score")

    def test_latent_is_interpolatable(self):
        """A midpoint latent must score between the two endpoints — this is the
        'nonlinear but interpolatable identity' property from the design."""
        rng = np.random.default_rng(1)
        z_a = self.scorer.model.p["z_u"].copy()
        z_b = rng.normal(size=z_a.shape)
        feats = [{n: float(v) for n, v in zip(tm.VIDEO_FEATURES, rng.normal(size=16))}
                 for _ in range(12)]
        self.scorer.model.p["z_u"] = z_a
        ua = np.array(self.scorer.score_many(feats))
        self.scorer.model.p["z_u"] = z_b
        ub = np.array(self.scorer.score_many(feats))
        self.scorer.model.p["z_u"] = 0.5 * (z_a + z_b)
        um = np.array(self.scorer.score_many(feats))
        lo, hi = np.minimum(ua, ub) - 1e-9, np.maximum(ua, ub) + 1e-9
        inside = ((um >= lo) & (um <= hi)).mean()
        # Per-candidate betweenness is NOT guaranteed by a nonlinear (tanh/FiLM)
        # score — the meaningful contract is: most candidates stay bracketed, the
        # aggregate moves monotonically, and the path is continuous.
        self.assertGreaterEqual(inside, 0.7,
                                f"only {inside:.0%} of midpoint scores lie between the endpoints")
        self.assertFalse(np.allclose(um, ua) or np.allclose(um, ub),
                         "midpoint is not a distinct identity")
        ma, mb, mm = float(ua.mean()), float(ub.mean()), float(um.mean())
        self.assertGreaterEqual(mm, min(ma, mb) - 1e-9)
        self.assertLessEqual(mm, max(ma, mb) + 1e-9)
        # Continuity: a 1% latent step may not move a score more than the whole path.
        total = np.abs(ub - ua).max() + 1e-9
        self.scorer.model.p["z_u"] = z_a + 0.01 * (z_b - z_a)
        near = np.array(self.scorer.score_many(feats))
        self.assertLess(np.abs(near - ua).max(), total,
                        "the score jumps discontinuously under a tiny latent step")


class TestEngineWiring(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.inv = fixture_inventory()
        cls.rubric = fixture_rubric()
        cls.tmp = tempfile.mkdtemp(prefix="tasteeng_")

    @classmethod
    def tearDownClass(cls):
        import shutil
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def test_group1_is_the_legacy_schema(self):
        legacy = eng._propose_variant(self.inv, self.rubric, 1.0, 1.0, True, True)
        out = eng.cmd_propose(self.inv, self.rubric, group=1)
        self.assertEqual(out["structure"], legacy["structure"])
        self.assertEqual(out["meta"], legacy["meta"])
        self.assertEqual(out["globals"], legacy["globals"])
        self.assertEqual(out["group"]["selected"], 0)
        self.assertEqual(out["group"]["select_by"], "only")

    def test_group_is_deterministic_and_selects_best_reward(self):
        a = eng.cmd_propose(self.inv, self.rubric, group=6, log=False)
        b = eng.cmd_propose(self.inv, self.rubric, group=6, log=False)
        self.assertEqual(a["structure"], b["structure"])
        self.assertEqual(a["group"]["size"], 6)
        rewards = [c["reward_obj"] for c in a["group"]["candidates"]]
        best = max(range(len(rewards)), key=lambda i: rewards[i])
        self.assertEqual(a["group"]["selected"], best)
        self.assertEqual(a["group"]["select_by"], "objective")

    def test_candidates_are_genuinely_different(self):
        out = eng.cmd_propose(self.inv, self.rubric, group=6, log=False)
        shapes = {len(c["knobs"]) and json.dumps(c["knobs"]) for c in out["group"]["candidates"]}
        self.assertEqual(len(shapes), 6)
        n_segs = {c["n_segments"] for c in out["group"]["candidates"]}
        self.assertGreater(len(n_segs), 1, "candidates do not differ in shot selection")

    def test_loop_logs_group_then_critic_refines_reward(self):
        ds = os.path.join(self.tmp, "loop.jsonl")
        out = eng.cmd_propose(self.inv, self.rubric, group=5, dataset=ds, clip_id="c1")
        gid = out["group"]["group_id"]
        crit = eng.cmd_critic(out, self.inv, self.rubric, subjective=0.8,
                              dataset=ds, group_id=gid, candidate=out["group"]["selected"])
        self.assertIn("logged", crit)
        groups, _ = tm.load_groups(ds)
        self.assertEqual(len(groups), 1)
        _, stats = tm.build_training_arrays(ds)
        self.assertEqual(stats["groups_usable"], 1)
        g = groups[0]
        self.assertEqual(g["chosen"], out["group"]["selected"])
        self.assertEqual(g["candidates"][g["chosen"]]["reward_source"], "critic")
        self.assertEqual(g["candidates"][g["chosen"]]["reward"], crit["reward"])
        # The group's own candidate metadata must include the logs' dense parts.
        for c in out["group"]["candidates"]:
            self.assertIn("overall_obj", c)

    def test_identity_changes_the_selection_toward_the_taste_model(self):
        ds = os.path.join(self.tmp, "train.jsonl")
        # Several distinct briefs give the group-relative objective real data.
        for i, pace in enumerate(["brisk", "medium", "slow", "brisk", "medium", "slow",
                                  "brisk", "medium", "slow", "brisk"]):
            rub = fixture_rubric(pace=pace, target_duration=8.0 + i)
            eng.cmd_propose(self.inv, rub, group=6, dataset=ds, clip_id=f"clip{i}")
        identity = os.path.join(self.tmp, "creator.gguf")
        metrics = eng.cmd_train(ds, identity, creator="test", epochs=150, seed=0)
        self.assertEqual(metrics["groups"]["groups_usable"], 10)
        scorer = tm.TasteScorer.load(identity)
        out = eng.cmd_propose(self.inv, self.rubric, group=6, identity=identity,
                              select="taste", log=False)
        self.assertEqual(out["group"]["select_by"], "taste")
        scores = [c["taste_score"] for c in out["group"]["candidates"]]
        self.assertEqual(out["group"]["selected"], max(range(len(scores)), key=lambda i: scores[i]))
        objective = eng.cmd_propose(self.inv, self.rubric, group=6, log=False)
        # The taste model and the objective reward are allowed to disagree; the
        # point is that the identity is actually consulted and can move the pick.
        self.assertIsNotNone(out["group"]["taste"])
        self.assertEqual(len(out["group"]["taste"]["scores"]), 6)
        self.assertEqual(objective["group"]["select_by"], "objective")

    def test_taste_status_reports_loop_state(self):
        ds = os.path.join(self.tmp, "status.jsonl")
        identity = os.path.join(self.tmp, "status.gguf")
        eng.cmd_propose(self.inv, self.rubric, group=4, dataset=ds, clip_id="c9")
        eng.cmd_identity_init(identity, creator="status")
        status = eng.cmd_taste_status(identity, ds)
        self.assertTrue(status["identity"]["exists"])
        self.assertEqual(status["identity"]["trained_groups"], 0)
        self.assertTrue(status["dataset"]["exists"])
        self.assertEqual(status["dataset"]["groups"], 1)
        self.assertTrue(status["dataset"]["ready_to_train"])
        self.assertIsNotNone(status["dataset"]["reward_mean"])


class TestGracefulDegradation(unittest.TestCase):
    """The legacy loop must not require numpy; the taste path must fail loudly
    (a clean JSON error) rather than silently doing something else."""

    def _run(self, args, block_numpy=True):
        env = dict(os.environ)
        if block_numpy:
            d = tempfile.mkdtemp(prefix="nonumpy_")
            with open(os.path.join(d, "numpy.py"), "w", encoding="utf-8") as fh:
                fh.write("raise ImportError('numpy blocked for this test')\n")
            env["PYTHONPATH"] = d + os.pathsep + env.get("PYTHONPATH", "")
        return subprocess.run([sys.executable, os.path.join(BIN, "edit_apart_core.py"), *args],
                              capture_output=True, text=True, env=env)

    def test_legacy_propose_works_without_numpy(self):
        inv = json.dumps(fixture_inventory())
        rub = json.dumps(fixture_rubric())
        r = self._run(["propose", inv, rub, "--group", "1", "--no-log"])
        self.assertEqual(r.returncode, 0, r.stderr)
        out = json.loads(r.stdout)
        self.assertEqual(out["group"]["size"], 1)
        self.assertIn("structure", out)

    def test_group_without_numpy_still_works(self):
        """Group + feature extraction is pure stdlib; only the learned scorer and
        the trainer need numpy. This is deliberate: `group=K` must keep producing
        and logging groups on a machine without numpy."""
        inv = json.dumps(fixture_inventory())
        rub = json.dumps(fixture_rubric())
        r = self._run(["propose", inv, rub, "--group", "4", "--no-log"])
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(json.loads(r.stdout)["group"]["size"], 4)

    def test_train_without_numpy_is_a_clean_error(self):
        with tempfile.TemporaryDirectory() as d:
            ds = os.path.join(d, "log.jsonl")
            with open(ds, "w", encoding="utf-8") as fh:
                fh.write(json.dumps({"kind": "group", "group_id": "g", "candidates": [
                    {"features": {}, "reward_obj": 1.0},
                    {"features": {}, "reward_obj": 0.0}]}) + "\n")
            r = self._run(["train", "--dataset", ds, "--identity", os.path.join(d, "i.gguf")])
            self.assertEqual(r.returncode, 2)
            self.assertIn("error", json.loads(r.stdout))

    def test_scoring_without_numpy_is_a_clean_error(self):
        r = self._run(["taste", "--identity", "/nonexistent.gguf"], block_numpy=True)
        self.assertEqual(r.returncode, 2)
        self.assertIn("error", json.loads(r.stdout))


class TestModuleImportIsNumpyFree(unittest.TestCase):
    def test_importing_taste_model_does_not_load_numpy(self):
        code = ("import sys; sys.path.insert(0, %r); import taste_model; "
                "print('numpy' in sys.modules)" % BIN)
        out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
        self.assertEqual(out.returncode, 0, out.stderr)
        self.assertEqual(out.stdout.strip(), "False")


if __name__ == "__main__":
    unittest.main(verbosity=2)
