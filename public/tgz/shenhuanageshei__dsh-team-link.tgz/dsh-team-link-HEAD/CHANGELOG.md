# Changelog

本文件记录 `dsh-team-link` 的变更史。版本号策略：`package.json` 的版本号**随发布统一 bump**——开发期累积的条目先记为「未发布」，发布时一次性收口（例如 0.3.1–0.3.6 的条目在 0.3.7 发布时一并落定）。

格式：每个版本按 **修了什么 → 为什么 → 怎么验证** 组织。凡涉及行为修复的条目都附**变异验证**证据（修复前必红 / 修复后全绿），这是本仓库的验收文化。

## 未发布 — 批 Z：撤销依据的「在飞 / 留存」读面区分（2026-11-05，t-12）

**一句话**：状态卡第 ② 段现在按「在飞 / 留存」两档列出撤销依据——用户一眼能分清哪条快照还在用、哪条只是历史；**两档都保留，不自动删除**。

**根因**：批 Q 的 `rotationBackups` 会因崩溃、手改 settings、旧版残留留下**无 pending 指向**的条目，而读面把在飞与留存混列（`rotationEntriesOf` 不区分）。

**做法**：① `lib/rotation.js` 新增纯函数 `classifyRotationBackups(team)`（按 `pendingRotationRid` 集合分档）；② 状态卡第 ② 段追加一行「撤销依据：<队> 共 N 条（在飞 X / 留存 Y）—— 留存条目属已完成或已取消的换届，读面保留、不自动删除」；③ 不删除任何条目（撤销依据是信任迁移的还原依据，t-12 要求不得丢快照）。

**验证**：定向脚本 `.investigations/rotation-hallucination-2026-11-04/z-backup-check.mjs` ⇒ `ALL PASS`（Z1 分档 + 旧读面红相自证）；套件新增 `批 Z · Z1`，总数 **1807 = 1806 + 1**（源码推算；用户禁跑全量，套件待跑）。

### 残余声明（如实）

- **未跑套件**（用户 2026-11-05 指令）；`批 Z · Z1` 尚未在套件里执行过。
- 不做自动清理：孤儿条目继续留在快照集合里（读面已区分）。若日后要清理，单开一批裁定。

## 未发布 — 批 Y：换届映射的歧义/缺失/去重回执（2026-11-05）

**一句话**：把批 X 留下的三条边界（映射歧义、映射目标缺失、映射撞车）补成**可测 + 回执可见**——行为不变，只多事实。

### 三段话（用户视角）

**① 现象与根因**：批 X 交付评审登记了两条 Deferred：①「一个旧会话出现在两个角色版本史 ⇒ 归属有歧义」与「映射目标不在候选 ⇒ 跳过」两条分支只有实现、没有判据；② 用户同时勾旧会话与新现任时，代码走**静默 `continue`**——行为对（不建重复通道），但回执里看不到这条被去重了。

**② 现在怎么做的**：① `mapRotationSelection` 去重分支改推一条 `skipped`（带目标会话与原因），回执可见；② 该纯函数加 `export`（与 `planRotationMigration` / `applyRotationTrust` 同模式），三条边界各一条纯函数判据（X7/X8/X9）；③ 不改任何「建不建通道」的结论。

**③ 怎么验证**：用户当前**禁止跑全量套件** ⇒ 本批给**定向脚本**实测：`.investigations/rotation-hallucination-2026-11-04/y-map-check.mjs` 直接 import 该函数跑 Y-X7/Y-X8/Y-X9，含一条**红相自证**（旧实现静默去重 ⇒ skipped 为空 ⇒ 判据会红）；读数 `ALL PASS` / `EXIT=0`。套件红/绿待用户放开后补跑（账本「批 Y」节如实登记）。

### 改了什么（逐面）

- `lib/rotation.js`：`mapRotationSelection` 去重分支推 `skipped`（`to` + 原因）；函数加 `export`。字节 162,497 → **162,962**。
- `host-half.test.mjs`：新增三条纯函数判据 `批 Y · X7/X8/X9`（放在批 X 块之后、`rmTestRoot()` 之前）；总数 **1806 = 1803 + 3**（按源码 `check()` 计数推算；套件尚未执行，见下方残余声明）。
- 文档：README 计数 `1806 + 310`；合规档 §五/§六 同批重测；设计/需求档 `docs/2026-11-05-rotation-mapping-receipt-*.md`；账本新增「批 Y」节。

### 残余声明（如实）

- **本批未跑套件**（用户 2026-11-05 指令：不允许跑全量 test）；判据 X7–X9 尚未在套件里执行过，红/绿读数待补。
- 真机未复验（映射逻辑只在换届确认框有勾选时触发，行为与批 X 一致）。

## 未发布 — 2026-11-05 真机生效登记（批 V / 批 W / 批 X）

**发生了什么**：用户 2026-11-05 重启 DSH；desktop profile 的 `node_modules/dsh-team-link` 是指向本仓的符号链接（`link:` 接线）⇒ 下面三批的源码**已在真机生效**（插件加载的就是本仓当前源码）。

- **批 V**（确认框布局合同 + 发起前自检 + 读数结论）：重启后换届确认框的 `question` 只留一行、正文进可滚动的 `detail`。真机行为待用户复验（台账 t-17）。
- **批 W**（旧协调者 auto 工作台提醒移交 + 退役者零投递 + 状态卡 120s 与耗时行）：重启后 `team_link_status` 标题行带「读卡耗时 N ms；工具预算 120s」。真机行为待用户复验（台账 t-17）。
- **批 X**（整队换届 claim 复读合并）：重启后 claim 在确认框结束后复读最新名册再写。真机行为待用户复验（台账 t-17）。

登记与交叉引用：`docs/verification-log.md` 的「2026-11-05 · 重启生效登记（批 V / 批 W / 批 X）」节；三份设计档状态行同批改为「2026-11-05 已随 DSH 重启在真机生效」；提交 `d534362`、`c9d8297`。

**未发布说明**：三批都未做版本号 bump（`package.json` 仍是 0.5.2），随下一次发布统一收口。

## 未发布 — 批 X：整队换届 claim 的复读合并（2026-11-04 用户裁定 A）

**一句话**：换届确认框关闭后，`claim` **重新读一遍最新名册**再写，只把本角色这一份改动叠上去 —— 整队换届时，先换完的角色不会再被后换的角色覆盖回老会话。

### 三段话（用户视角）

**① 现象与根因（前因）**：用户问「整队换届（1 协调者 + 4 worker）先后换，协调者的确认框会不会配到 4 个老 worker？第二个 worker 会不会新老混着？」。配对语义本身是收敛的（每个 claim 只换自己这一端），但 `claim` **只在弹框前读一次状态**（`lib/rotation.js`），而确认框可以停留几分钟、写盘又是整份 `pairs`/`teams` 替换 ⇒ 期间另一个角色若已落定，后写的一笔把它的落定**整笔覆盖回旧快照**：`current` 回退成老会话、已迁移的配对退回旧会话。单角色换届不会撞，整队换届最容易撞。

**② 现在怎么做的**：① 确认框结束后**复读**最新状态，并校验本次令牌与旧任未变（不满足 ⇒ fail-closed，零写入 + 可执行错误）；② 用最新名册重算候选，把用户勾选的**对端会话**映射到最新候选（对端已换届 ⇒ 按该角色版本史映射到它的新现任；一个旧会话出现在多个角色版本史 ⇒ 歧义，跳过并写明）；③ 只应用本角色这一份改动；④ 「复读 → 计算 → 写盘」由**单把进程内全局锁**包住（写的是全局数组，不同团队的 claim 也必须串行）；⑤ 收尾清 pending 那一笔同样复读、只清本角色本 rid；⑥ 回执新增「复读合并 / 已映射 / 跳过」读数行。

**③ 怎么验证**：判据 **`批 X · X1–X6`**（6 条，放在「批 W」之后、`rmTestRoot()` 之前）。**两次实测**：修复前（`git stash` 回旧 `lib/`）⇒ `1803 (failed: 4)`，红的恰为 X1/X2/X3/X4；修复后 ⇒ `ALL PASS / 1803 (failed: 0)`。**续做轮**在 `f3b21c0` 的干净工作树上串行复跑同值（`ALL PASS / 1803 (failed: 0)`；同轮 `client-half` ⇒ `310 (failed: 0)`；一次 `Aw5` 计时抖动已如实登记在账本）。日志在 `.investigations/rotation-hallucination-2026-11-04/`（`red-x.log` / `green-x-phase1.log` / `green-x.log` / `green-x-client.log`，`*.log` 入 `.gitignore`），账见 `docs/verification-log.md` 的「批 X」节。

### 改了什么（逐面）

- `lib/rotation.js`：新增 `withPolicyLock`（进程内全局锁）、`mapRotationSelection`（按对端会话映射 + 歧义跳过 + 回执数据）、`clearRotationOwn`（收尾只清本 rid）；claim 的落定与收尾两笔写都在锁内**复读后**计算；回执新增「复读合并 / 已映射 / 跳过」行；`factRows` 改用复读后的计划渲染迁移/清理读数。
- `host-half.test.mjs`：新增「批 X」6 条（X1 两 claim 交错 / X2 框内 pending 失效拒绝 / X3 对端换届映射 / X4 无人应答按最新候选 / X5 既有 1797 全绿 / X6 仍 2 笔写）。
- 文档：README 计数 `1803 + 310`；合规档 §五/§六 实测重测（`lib/rotation.js` **162,497**，入口 `lib/index.js` 仍 262,118、余量 26）；设计档 §九 登记「弹框时零候选、复读后出现候选」这一格；账本新增「批 X」节。

### 残余声明（如实）

- **只保证单进程**：锁在进程内有效；多进程同时写同一 settings 命名空间不在本批承诺内（本部署单实例）。
- **两笔写之间仍可能崩溃**：与现状同一条 replay 路径（既有判据覆盖）。
- 真机上**尚未复验**：插件跑在宿主进程里，需 DSH 重启才生效（时机由用户定）。

## 未发布 — 批 W：换届后旧自动提醒的移交 ＋ 状态卡 30s→120s（2026-11-04 用户裁定 A/A）

**一句话**：换届落定时，旧协调者的**自动工作台看门狗**在同一笔写盘里**移交给新任**（watcher/targets/租约），且非现任 watcher 的 auto 行**一条都不投递**；`team_link_status` 的预算从 30s 提到 **120s**，标题行给出「读卡耗时」读数。

### 三段话（用户视角）

**① 现象与根因（前因）**：用户报「换届后旧协调者会话还在收自动提醒，24h 才过期、去不掉」。查实：建队/attach 会给团队自动注册一条 `origin=auto` 的工作台看门狗（TTL 12h、随名册续期）；`lib/rotation.js` 对 watchdogs **零引用** ⇒ 换届不碰它；而 auto 行的名册门只在 `renewAutoRowIfStillValid` 里判「要不要**续期**」，**不判「要不要投递」** ⇒ 旧 watcher 只要会话还活着就继续收摘要/告警；`clear` 按设计拒绝清 auto 行、`mute` 最长 24h ⇒ 没有主动出口。另一条：`team_link_status` 注册时写死 `timeoutMs: 30000`，而它一次要读会话窗（≤12）＋逐会话 surface＋每团队 `tasks.md`＋形态探测＋第⑧段投影，忙工作区下被宿主中止（真机 2026-11-03 `seq=37`：`tool call timed out after 30000ms`）——协调者因此拿不到真读数。

**② 现在怎么做的**：① `lib/rotation.js` 新增 `transferAutoWatchdogs()`，claim 落定时把 `origin=auto ∧ team ∧ watcherSession=退役者` 的行**原地移交**（watcher→新任、targets 按落定后名册重算、`expiresAt` 顺延、`renewedAt` 记录，保 `id`/`createdAt`），并**并进与 roster 落定同一笔** `policy.update`（要么同时生效、要么都不生效）；新任外无人可盯 ⇒ 删该行。常量（origin/ttl）经 `rotationExtras().watchdogDefaults` 由入口注入（域档不导入入口；TTL 与 `planAutoWatchdog` 同源）。② `lib/watchdog.js` 的 `patrolOne`：到期门之后、投递之前加一道名册门 —— **团队仍在名册**且 watcher 非现任 ⇒ `return`（零投递、零目标 surface 读）；团队已删的孤儿行维持旧行为（等 TTL，不把「读不到名册」当「失效」）；manual 行不进。③ `lib/registration.js`：状态卡 `timeoutMs: 120000`，并在标题行追加 `（读卡耗时 N ms；工具预算 120s）`（仍纯读、零写盘）。

**③ 怎么验证**：判据 **`批 W · W1–W4`**（4 条，放在批 V 之后、`rmTestRoot()` 之前）。**两次实测**：修复前（`git stash` 回 `9e5e9a3` 的 `lib/`）⇒ `assertion total: 1797 (failed: 4)`，红项恰为 **W1 / W2 / W3 / W4**；修复后 ⇒ `ALL PASS / assertion total: 1797 (failed: 0)`、`EXIT=0`；`client-half` 同批 `310 (failed: 0)`。日志在本地 `.investigations/rotation-hallucination-2026-11-04/red-w.log` / `green-w.log`（`*.log` 入 `.gitignore`），账见 `docs/verification-log.md`。

### 改了什么（逐面）

- `lib/rotation.js`：`transferAutoWatchdogs()`（导出、纯函数）＋ claim 的 settle patch 合并 `watchdogs`（同一笔写）；`createRotation` 从 `extras.watchdogDefaults` 取常量（缺席 ⇒ 不移交，退回旧行为；生产恒注入）。
- `lib/index.js`：`rotationExtras()` 增 `watchdogDefaults: { originAuto, ttlMs }`（入口 262,118 B，仍 < 262,144，余量 26 B）。
- `lib/watchdog.js`：`patrolOne` 的 auto 行投递闸（团队在册 ∧ watcher 非现任 ⇒ 零投递）。
- `lib/registration.js`：状态卡 `timeoutMs: 120000` ＋ 标题行耗时读数。
- 测试：`host-half.test.mjs` 新增「批 W」4 条；README 计数 `1797 + 310`；合规档 §五/§六 全表重测（`index.js` 262,118 · `rotation.js` 147,955 · `registration.js` 73,193 · `watchdog.js` 56,790）；设计档 `docs/2026-11-04-rotation-watchdog-status-budget-design.md`。

### 残余声明（如实）

- **只加投递闸，不改 clear 语义**：auto 行仍不能被一句 `clear` 拿走（团队资产），换届的移交就是自动出口；团队已删的孤儿行仍靠 TTL。
- **状态卡只提预算、未缩读窗**：耗时读数是给下一批的判据输入；若真机仍超 120s，再按设计档 D3 的备选缩读窗。
- 真机上**尚未复验**：插件跑在宿主进程里，需 DSH 重启才生效（时机由用户定）。

## 未发布 — 批 V：换届确认框看不见按钮（question 布局合同）＋ 发起前自检（2026-11-04 真机）

**一句话**：确认框的 `question` 从此只能是**一行话** —— 正文一律进可滚动的 `detail`，动作底栏不再被挤出卡片（`/team_session` 之外 **12 个对话框**统一收口到 `askDialog`）；同时给模型立三条规矩：换届必须**先得到用户明确同意**、成员自述的上下文百分比**不可采信**、**换届不是重启手段**；并按用户 2026-11-04 追加裁定让**读数自带结论**——资源行与第 ⑧ 段段头都明写「上下文占用不是停工/换届判据」（sessions 档成员各自是独立 session、各有宿主压缩；agent-team 档成员是本会话子代理）。

### 三段话（用户视角）

**① 现象与根因（前因）**：2026-11-04 14:33，`server-line-1021` 的协调者收到 worker-1 自述「上下文接近用尽 / ~2%」（同一步插件真读数 **66.6%**，06:46 为 **68.4%**），**自行决定换届**并把 `team_link_rotate action=prepare successor:"auto"` 投给 worker 执行（协调者日志 `seq=5690`，角色名写错后重投 `seq=5721`）；确认框随后在 **worker 会话**弹出，用户能看到框、**看不到「创建并交班 / 取消」**（协调者自己记的读数：`seq=5749`）。根因在宿主布局：`question` 渲进**不滚、无高度钳制**的 `<header><h2>`，`detail` 与选项在 `.body{overflow-y:auto}` 内，动作底栏在滚动区外，而卡片 `max-height:min(60vh,520px);overflow:hidden` ⇒ `question` 一长就把按钮裁掉。这与 2026-09-21 `/team_session` 的「8 次够不着」是**同一形态**；当时只修了那一处，其余 **12 个对话框**仍把长正文交给 `question`（本次换届框正文 **15 行**）。协调者一侧还有第二个因素：它 2026-11-03 唯一一次 `team_link_status` **宿主 30s 超时**（`seq=37`），11-04 全程没有真读数；而状态卡第 ⑧ 段的轮换标记只给现成命令，没写「先问用户」。

**② 现在怎么做的**：新增 `lib/shared.js` 的 `askDialog()` —— 插件里**唯一**调用 `userQuestions.ask` 的地方（结构判据 `V5` 锁住「恰 1 处」）；它先用 `normalizeDialogQuestion()` 把每条问题归一成「第一行 headline（空白压平、≤160 码点）＋ 其余按原序进 `detail`」，**一个字不丢**。12 个调用点全部改走它（rotation auto / batch / claim · send · receive · retire-cleanup · revive · reappoint · set-mode · archive · delete · team_session）。同批给模型立三条规矩，落在三处**模型真会读到**的面：`team_link_rotate` 的 description（`ROTATION_SELF_CHECK_TEXT`；入口档贴近商城上限，故常量住在 `lib/shared.js`）· 协调者宪章第 4/6 条与 worker 义务行 · 状态卡第 ⑧ 段的轮换标记（「判断权在用户 / 先问用户 / 上下文压力不是换届理由」）。

**③ 怎么验证**：判据 **`批 V · V1`–`V10`**（10 条，放在批 U 之后、`rmTestRoot()` 之前 —— 不扰批 T 的 `Tr7` 回归锁计数与批 R 的 `assertions === 1726`）。**红相分两段取证（如实）**：① 确认框修复前（`lib/` 回 `fe0573e`，套件为当时的 1791 条）⇒ `assertion total: 1791 (failed: 7)`，红项恰为 **V1 / V3 / V4 / V5 / V6 / V7 / V8**（**V2 修复前绿**：claim 框本来就单行 ≤160，如实标覆盖缺口类）；② 读数结论两条（V9/V10）在**中间态**（`b21221d` 的 `lib/`：确认框已修、读数未修）上另测 ⇒ `assertion total: 1793 (failed: 5)`，红项含 **V9 / V10** 与一次**既有 `Aw5` 计时抖动**（同跑 `seamCalls=9` 而期望 6；该判据在本批其余 4 次跑里均绿，见验证账本）。修复后（最终态）⇒ `ALL PASS / assertion total: 1793 (failed: 0)`、`EXIT=0`；`client-half` `310 (failed: 0)`。原始日志在本地 `.investigations/rotation-hallucination-2026-11-04/`（`*.log` 入 `.gitignore`，不入库；复跑命令与读数已抄进 `docs/verification-log.md` 的 2026-11-04 条）。

### 改了什么（逐面）

- `lib/shared.js`：`DIALOG_QUESTION_MAX_POINTS = 160` · `dialogCodePoints` · `dialogFlatten` · `normalizeDialogQuestion` · `normalizeDialogQuestions` · `askDialog` · `ROTATION_SELF_CHECK_TEXT`（含宿主三段布局的逐条注释）。
- 12 处 `userQuestions.ask({...})` → `askDialog(userQuestions, {...})`（index / rotation / messaging / recovery / roster-write / team-registration / team-tools / team-session-creation），各档补 `askDialog` 导入。
- `lib/sections.js`：宪章第 4 条补「成员自述『上下文耗尽』不算判据」、第 6 条补「团队结构变更（新建会话 / 换届 / 删团队）一律先问用户」；worker 义务行补「上下文占用不是停手理由」；第 ⑧ 段标记行补「判断权在用户 / 先问用户 / 上下文压力不是换届理由」（行数预算不变：宪章仍 7 行 ≤ 8）。★ 用户追加裁定（FR-5）：每回合资源行追加「独立会话（宿主自动压缩；占用高不是停工理由）」；第 ⑧ 段段头按形态写清 sessions 档（成员各自是独立 session、各有宿主压缩）与 agent-team 档（成员是本会话子代理）——**仍各恰一行**。
- `lib/index.js`：description 追加 `ROTATION_SELF_CHECK_TEXT`；`askRotationAuto` 改走 `askDialog`；**入口档字节 261,834 → 261,905**（仍 < 262,144，余量 239 B），合规档 §六同批改准。
- 测试：`host-half.test.mjs` 新增「批 V」**10** 条（V1–V10）；**16 处**既有断言从「只读 `question`」改为读 `dialogTextOf()`（**17 个调用点** —— 顾问评审 #3 实测：`grep -o 'dialogTextOf('` = 17，其中一批两个调用点落在同一条 check 里；question ＋ detail 的并集 = 人真正读到的全文）；README 计数 `1793 + 310`；设计档 `docs/2026-11-04-rotation-dialog-hotfix-design.md`。

### 残余声明（如实）

- **V2 修复前绿**：claim 框本来就合规，它不是红相；它守的是「未来别把它改坏」。
- 真机上**尚未复验**：插件跑在宿主进程里，本机 `link:` 接线 ⇒ **需要 DSH 重启才生效**；重启时机由用户决定，本单不做。
- `team_link_status` 在协调者会话里 **30s 超时**（2026-11-03 `seq=37`）是本次「手上没有真读数」的放大器，属另一类问题（宿主 / 读面耗时），本批**不修**，如实记在这里。
- **过程偏离（如实）**：本批是真机热修，**实施先于用户发起的设计评审**——用户当面对此提出异议。已补 **advisor(type=code) 事后评审**（2026-11-04，`zai-coding-cn:glm-5.3`，job `advisor-dsh-25e70ae5e6124d49`）：结论 **VERDICT: PASS**、无 🔴；2 🟡（合规档计数收口 / 流程登记）＋ 2 🔵（注释级边界）已逐条处置。**后续 `lib/**`、`test/**` 恢复「先评审后实施」的常规门禁**，本档只登记这一笔偏离，不构成热修豁免先例。
- **一次既有 flake（如实）**：中间态红跑（1793 条）里 `批 L · Aw5` 偶发红（`[AW5-DIAG] seamCalls=9`，期望 6）——与本批改动无因果（本批未碰 policy 写面）；同判据在本批其余 4 次跑里均绿，按计时抖动登记，不在本批修。

## 未发布 — 批 U：看门狗运维面（update / mute / unmute）＋「提醒不许唤醒坏会话」（2026-10-23）

**一句话**：`team_link_watch` 不再只有「注册 → 等 TTL」两扇门 —— 注册后可**就地调整**间隔 / 静默阈 / TTL / 是否唤醒，可**临时静音**（auto 那一条也能由观察者本人按）；而投递在两种情况下改走 `inject`（只进收件箱、**不唤醒新回合**）：注册里 `wake:false`，或观察者上一拍 tick 之后**没有 assistant 回复**（会话可能已在错误循环里）。

### 三段话（用户视角）

**① 现象与根因（前因）**：用户反馈三件事 ——「注册完不能调整间隔」「只能等注册自动过期」「提醒消息可能把会话直接搞坏，一直报错」。前两条是工具面缺口（只有 register / clear；auto 那一档连 clear 都拿不走、租约还会随名册续期）。第三条实测定位：会话 400 的根因是**工具结果里的孤立代理项（lone surrogate）** —— `72d1b89b` 的 `seq 3622`、`1a253727` 的 `seq 131/132` 各有一处（全档扫描只命中这些），由 `String.slice` 在 UTF-16 码元边界切断代理对产生；请求序列化层未消毒 ⇒ DeepSeek 对**之后每一次请求**回 400 INVALID_REQUEST（细节被宿主折成通用文案）。插件自己的消息全部经 `wellFormed()`（`toWellFormed`），**不是污染源**；但 watchdog 的 `followup` 会**唤醒新回合** ⇒ 坏会话每 10 分钟被重新拉起、每拍都失败，用户看到的就是「一直报错」。

**② 现在怎么做的**：`team_link_watch` 新增三条动作 —— `update`（按 id 就地改 `silentMinutes` / `intervalMinutes` / `ttlHours` / `wake`；TTL 从**现在**起算续租；定时器按新间隔重挂）、`mute`（观察者本人给自己任一条注册按暂停键，默认 12h、上限 24h；auto 行也受理）、`unmute`。行上新增两个**加性**字段：`mutedUntil`（静音截止）与 `wake:false`（不唤醒）；两者都进 `watchdogList` 白名单（与 `renewedAt` 同一纪律），**不新增命名空间顶层键**。投递侧：`followup`（唤醒）与 `inject`（不唤醒）由 `deliverToWatcher` 统一分流；`patrolOne` 在本拍确实要投东西时多读一次**观察者自己的** surface，若末条 `slp-wd-` tick 之后没有 `assistant/message` ⇒ 判定「上一拍没跑起来」⇒ 本拍降级 `inject` 并留一行 warn（surface 读不到 ⇒ 证据不足 ⇒ **不降级**）。

**③ 怎么验证**：判据 `批 U · U1`–`U5`（12 条 `check()`）：update 落盘与定时器重挂 / 越界与空参数拒绝 / 只能调整自己的注册 / auto 行可调 · mute 零投递 ＋ list 可见 ＋ unmute 恢复 / auto 行可静音但 `clear` 仍拒绝 · `wake:false` 走 `inject` · 上一拍无回复 ⇒ 降级 `inject` ＋ warn（对照：有回复 ⇒ 正常 `followup`）。**两次实测**：修复前（`git stash` 回旧实现、测试先落盘）⇒ 套件在 `host-half.test.mjs:16210` 的第一条 `update` 调用处抛 `ToolArgsError: invalid arguments: "action" must be one of ["register","list","clear","arm-team"]`（旧 action 闭集）⇒ **直接中止、无 `assertion total` 行**（同跑先红了 `U22` 与 `Rr7`：枚举缺新动词 / 合规档写 261,834 而旧实现 261,720）；修复后 ⇒ `ALL PASS / assertion total: 1783 (failed: 0)`，`EXIT=0`。另有一条**定向红→绿**：`wake` 未接线时 `U3` 读数为 `{"f":1,"i":0}`（followup 1 / inject 0），接线后绿。

### 改了什么（逐面）

- `lib/watchdog-helpers.js`：`buildWatchdogRegistration` 接受 `wake`（只在 `false` 时写键）；新增纯函数 `buildWatchdogUpdate`（就地改四字段，边界与 register 共用）与 `buildWatchdogMute`（静音截止，默认 12h / 上限 24h）。
- `lib/watchdog.js`：`deliverToWatcher(watcher, wake, message)` 统一分流 `followup` / `inject`（tick / 摘要 / 两条告警四个出口）；`patrolOne` 增加静音门（静音 ⇒ 零投递、零目标读）与「上一拍没回复 ⇒ 降级 inject ＋ warn」；装配缝新增绑定 `WATCHDOG_TICK_ID_PREFIX`（判据用前缀，不抄常量）。
- `lib/registration.js`：`team_link_watch` 三条新动作与参数（`wake` / `hours`）、list 渲染静音与不唤醒状态、`clear` 对 auto 的拒绝文案补一句 mute 出口；描述面同批改准。
- `lib/policy-store.js`：`watchdogList` 白名单加入 `mutedUntil`（仅 >0）与 `wake`（仅 `false`）—— 与 `renewedAt` 同一纪律，读写循环不丢。
- `lib/index.js`：`watchdogExtras()` 增一名绑定、`registrationExtras()` 增两条出口、按名导入两条新构建器；**命名空间 schema 一字未改**（加性字段走 schemastery 的未声明键保留，与 `renewedAt` 同例）。
- 测试：`host-half.test.mjs` 的「批 U」块 **12 条** `check()`（放在 `rmTestRoot()` 之前）；`U22` 的 action 枚举期望同批改准。文档：本档、README（§二、§三、§八 schema 表、§十）、`docs/2026-10-15-store-compliance.md` §六字节读数（`lib/index.js` 261,720 → **261,834**，余量 310）。

## 未发布 — 批 T：黑板归档 / 回收（只搬不删，显式动词）

**一句话**：长期团队的 `decisions.md` / `tasks.md` 现在可以用**一个显式动词**把旧行**搬**进 `archive/`（只搬不删、归档文件**只写一次**），活跃文件留尾部 ＋ 一行指针；**阈值只提示、绝不自动搬**；而**序号与任务号永不回卷** —— 归档过的旧 `t-<n>` 仍被认、伪造的高号仍被拒。

### 三段话（用户视角）

**① 现象与根因（前因）**：黑板三档只增不减，`bac-1009` 这类长期团队的 `tasks` / `decisions` 已经千行；读面只给末 20 条、派生视图只扫 500 行 ⇒ 越攒越沉。命门不在「截断」本身，而在**计数器是从文件里扫出来的**：`seq` 由 `lastSeq` 扫全文取最大，任务号由 `registeredTaskIds` 扫全文件取最大，**「这个号登记过吗」也扫同一份文件** ⇒ 天真截断会重置序号、把用过号再发一次（claim 会指向歧义历史）。另有两个「彩蛋级耦合」（会诊 #66 四席独立命中的同一条）：**形态史行**被 `set-mode` 的幂等检查读取、**交接文档**按 `handoff-<role>-` 前缀扫目录。

**② 现在怎么做的**：新增**第 12 个工具** `team_link_team_archive`（不塞进 `team_link_team_append` 的 `file` 枚举 —— 一个是追加一行，一个是新建归档 + 原子重写整个活跃文件，破坏面不同）：
切点 = **min(位置切点 `keepTail`（默认 200）, 最新形态史行位置)**（最新形态史行**永不搬走**）；归档文件 = `archive/<file>-g<世代>-L<起>-L<止>.md`（`L` 是活跃文件 1-based **物理行号**、**不含墙钟**）且用 `wx` **只写一次**；**归档写之前**重读比对被搬前缀（变了 ⇒ 中止、零写入），**归档写之后、活跃重写之前**再读一次（前缀仍相等 ⇒ 用新读数的尾部，期间的 append 自然并入；前缀变了 ⇒ 中止并如实报孤儿归档）；活跃文件用**唯一临时名 + rename** 原子重写。分配与「已注册」校验改为扫**「活跃 ∪ `archive/`」**（只扩取值面，时机与格式一字不改）。世代只进**归档头**（各角色 `history` 条数快照），**不落 policy**。

**③ 怎么验证**：判据 **`Tr1`–`Tr13`**（共 **13 条** `check()`，落在 `host-half.test.mjs` 的「批 T」块、标识符 `Tr` 中缀，放在「批 S」块之后、`rmTestRoot()` 之前）—— 阈值只提示且零写盘 / 显式归档逐字搬、留尾部与指针 / 归档文件只写一次 / 序号与任务号不回卷 / 归档头 + 零新增顶层键 + 宿主说明符仍 8 条 / 对账与交接扫描不相交 / 既有判据族不回归（**回归锁：修复前绿**）/ 边界（空档 · 单行 · 恰 500 · 无确认服务 · `keepTail` 误用）/ 形态史行钉住 / 归档 id 仍认 / 伪造高号仍拒 / 崩溃幂等（回滚活跃文件重现「归档已写、活跃未重写」后用**新的 now** 重跑）/ 归档索引常驻读面。**两次实测**（本单，本地复跑）：**修复前** `node host-half.test.mjs` ⇒ `ALL PASS / assertion total: 1758 (failed: 0)`，**退出码 0**（红相说明：这 13 条在旧实现上没有归档动词、也没有并集扫描 ⇒ 首交付时逐条红）；**修复后** ⇒ `ALL PASS / assertion total: 1771 (failed: 0)`，**退出码 0**（`1771 = 1758 + 13`）。

### 改了什么（逐面）

- **归档核心（`lib/team-tools.js`）**：行级切分 `splitArchiveRows` / 切点 `archiveCutOf` / 世代 `generationOf` / 确定性命名 `archiveFileName` / 归档文档 `renderArchiveDocument` / 归档头时间 `archiveStampOf` / 读面两行 `archiveReadFaceLines` / 确认框 `askArchiveDialog` / 动词本体 `archiveBlackboard`（含 D7 的两次核对、D8 的 `wx` 与幂等跳过、唯一临时名原子重写）；`MODE_HISTORY_PREFIX` 让「写形态史行」与「钉形态史行」共用同一个前缀。
- **分配与注册面（`lib/ledger.js`）**：`lastSeq` / `registeredTaskIds` 扫「活跃 ∪ 归档」（同一判据喂两份正文）；新增 `BLACKBOARD_ARCHIVE_DIR` / `blackboardArchiveDir` / `readBlackboardArchive`（只读归档索引，零写入）。★ **取值面接缝如实声明**：分配与「已注册」的**调用点在 `lib/index.js`**（本批红线：入口一个字节都不改，它已顶到 256 KiB），它们只拿得到**正文**、拿不到路径 ⇒ 由**唯一读入口** `readBlackboardFile` 在读到台账档时，把「同目录 `archive/` 同族」的正文按文件路径登记进一张小表，取值助手按「正文逐字相等」取回并一并扫描；登记缺失 / 正文不等 / 归档读不出 ⇒ **只扫活跃档**（= 本批之前的行为），绝不猜别的队。
- **读面与工具注册（`lib/team-ledger-tools.js`）**：`team_link_team_read` 的正文行排除归档指针行（指针不算一条账）、每个文件段头之后追加**归档索引行**（`archive/` 非空时始终给）与**阈值提示行**（> 500 才给）；新增第 12 个工具 `team_link_team_archive` 的注册（`lib/index.js` **零改动**，仍在 261,720 B）。
- **文档面（同批）**：README 的徽标 / 稳定性行 / 当前读数行（**1758 → 1771**，`1771 = 1758 + 13`）· README 的架构图工具计数（**11 → 12 个工具**）与「覆盖全部 N 个工具」一句 · 能力清单与工具表新增该动词 · 黑板一节新增「归档 `archive/`」小节 · 本档 · 本批需求/设计两档的状态行与首步回读结论 · 合规档 §六 的逐档字节（`ledger.js` 26,070 → 32,556、`team-tools.js` 33,169 → 60,030、`team-ledger-tools.js` 17,366 → 22,742；入口仍 **261,720**，最大档余量 424 字节）。
- **判据面的两处同改（不是放宽）**：`README 工具计数` 那把锁与实际工具数（11 → 12），以及批 I U9 文档同步锁里钉的那个数字（同源、同改）；两处都只改数字与列表，判定面（计数 == 实际）一字未动。

### 已知边界（如实登记）

- **两次写之间的窗口**：归档文件已写、活跃文件未重写之间崩溃 ⇒ 重跑按**确定性文件名**识别并跳过归档写（原归档字节不改），活跃文件逐字节相同（指针行不含墙钟）；若在这两步之间**前缀被改**（极罕见）⇒ 中止并如实报**孤儿归档**（行同时存在于两处、不丢数据），不假装零写入。
- **归档与并发 append**：核对是「归档写之前一次、归档写之后一次」，只用**被搬前缀**做判据 ⇒ 归档窗口内的追加会自然并入尾部（不丢）；不用锁，黑板既有「无写门、无锁」的语义未改。
- **`discipline.md` 与 `handoff-<role>-` 不在归档面**：前者是可锁定文档，后者是换届取证的活源头（`listHandoffDocuments` 按前缀扫黑板目录本层；归档落在 `archive/` 子目录、文件名不以 `handoff-` 开头 ⇒ 结构上撞不上）。
- **不做**：自动归档（阈值只提示）· 删团队 / 删黑板 · 删除动词（**永远只有搬移**）· 跨团队批量归档 · 「世代」落 policy（只进归档头）· 改既有 append / read / set-mode 语义。

## 未发布 — 批 S：整队换届（批量准备 ＋ 各自认领）

**一句话**：现任协调者用**一条命令 ＋ 一道确认框**把整队 N 个角色的换届**准备阶段（Phase A）**一次做完 —— 每个角色各有一条 pending、各有一份撤销依据、各有一枚绑定三元组的令牌；**认领（Phase B）一个不省**，仍由每个继任者本人凭令牌 `claim`。

### 三段话（用户视角）

**① 现象与根因（前因）**：`team_link_rotate action=prepare` 的 `role` 必填，且 `prepareAdmission` → `rotateGate` 只承认**该角色的现任**发起 ⇒ 5 人队今天要 **5 个不同调用方会话各跑一次**；协调者**无权代 worker 发起**。批 Q 已把撤销依据从「团队级单槽」改成「按换届各存一份」⇒ 批量准备的**存储前置**成立，本批才有意义（会诊 #66 四席独立指认）。
**② 现在怎么做的**：在**既有** `team_link_rotate` 上加第三个动作 `action=prepare-batch`（不建新工具）—— 发起权 = **该队现任协调者** ＋ 既有 writer gate ＋ **一道**人类确认框；先做**预检（all-or-nothing）**：逐角色限速 / 继任者≠现任 / 显式继任者**在场**、auto 角色的交接文档由**插件从 roster 事实生成**（五硬节，读不到的如实标未知），任一不过 ⇒ 整批拒绝、零副作用；确认后**一次** `policy.update` 落下 N 条 pending（各带 `rotationId` ＋ `batchId` ＋ 批次清单）＋ N 份撤销依据，广播**一条**批次级 `rotation-freeze`；批量令牌 **2 小时**（单角色仍 30 分钟）。**协调者自己的角色排最后**（否则驱动批次的人先把自己换掉）。批次在飞期间：单角色 `prepare` 与再发 `prepare-batch` 都**具名拒绝 + 指路**。
**③ 怎么验证**：判据 **`Sr1`–`Sr15`**（首交付共 **15 条** `check()`，落在 `host-half.test.mjs` 的「批 S」块，标识符 `Sr` 中缀，紧跟「批 Q」块之后、`rmTestRoot()` 之前）—— 一次写盘 / 令牌三元组与 2h TTL / 确认失败零副作用 / auto 交接文档生成与预检拒绝 / 发起权两档 / 协调者排最后 / 部分认领只取消过期那个 / 批次互斥两条 / 零顶层键与零新依赖（**唯一真回归锁**）/ 每份撤销依据按 rid 可回 / 授权路径分开 / 写前重读指纹 / 限速按角色 / `batchId` 写→读→重启三面存活 / 显式继任者在场。**分歧修复轮**再补 **5 条**（`Sr16`–`Sr20`：批次级 freeze 恰一条并点名两角色 + batchId / 读面在 pending 时分组（roster get ＋ 镜像）/ 执行期失败回执点名失败角色自己的已建会话 / auto 投递的令牌与「120 分钟」＋ 意图先增后删 / 3 分钟未确认的超时档）⇒ **合计 20 条**（其中 `Sr18` 为修复前红，其余四条为覆盖缺口）。**实测**（本地复跑，`docs/verification-log.md` 的「批 S（整队换届）」节与其后的「批 S 分歧审计修复轮」节）：修复轮前 `node host-half.test.mjs` ⇒ `ALL PASS / assertion total: 1753 (failed: 0)`、`node client-half.test.mjs` ⇒ `310 (failed: 0)`；修复轮后 ⇒ **`ALL PASS / assertion total: 1758 (failed: 0)` / `310 (failed: 0)`**（EXIT=0）。

### 改了什么（逐面）

- **入口（`lib/index.js`）**：`team_link_rotate` 的 action 闭集扩到 `prepare` / `claim` / **`prepare-batch`**，参数面新增 `successors`（`角色=会话 id, …`，与 `successor:"auto"` 二选一 —— v1 不做混合批次），`role` 在批量动作下**不收**（另两个动作的必填性一字未改）；工具层先跑既有 `writerGate` 再交给换届域（发起权的第二道门在域内）。整队换届的**执行面**（建继任者会话 / 写交接文档 / 投递 / 在场读面 / 事实读数）经 `handoverDomain.batchRotationExtras()` 注入 —— 它住在交接域，因为换届域导入交接域会成**环**（`Rr4`）。
- **换届域（`lib/rotation.js`）**：`prepareAdmission` 现由 `rotateGate`（现任门，**只**属单角色动词）＋ `successorChecksOf`（门禁无关：限速 / 继任者≠现任）组合；批量入口 `prepareBatch` 走 `admissionChecks`（= `successorChecksOf` ＋ 可选的 `successorPresent` 在场探针）——「协调者代发起」与「只有该角色现任可发起」不再混在一个带开关的函数里（会诊 #101 [1]-①）；新增 `prepareBatch`、`askBatchDialog`（一道确认框，无服务 / 取消 / 超时一律 fail-closed）、`rosterFingerprint`（写前重读）、`batchHandoffBody`（五硬节正文，按注入的节名分派内容）、`batchFreezeNotice`（一条批次级 freeze）、`inFlightBatchOf` / `batchGroupsOf` / `batchStateLines`（批次互斥判定与读面三态）、`batchReceiptLines` / `batchExecutionFailureReading`（D11 的两段契约）。`sweep` 的取消行点名批次归属（**只**取消这一个角色）。
- **交接域（`lib/handover.js`）**：新增 `batchRotationExtras({ ctx, policy, teamSession })` —— 批量铸造的**执行面**（pending-create 意图 → 同一 `createRootAgent` 创建路径 → 审批档落位 → 交接文档 abort-before-prepare → followup 投递）。它与 `autoHandover` 共用**同一个创建落点**，所以 DEFECT-1/3/4 与批 P 的继承四件套在批量路径上同样成立。
- **归一化（`lib/policy-store.js`）**：`normalizePending` 的**固定键白名单**补 `batchId` 与 `batchRoles`（与批 G 的 `renewedAt`、批 Q 的 `rotationId` 同一坑：不补就会被「写 → 读」静默丢掉，重启后**批次互斥形同虚设**）。
- **读面与镜像（`lib/team-registration.js` / `lib/roster-write.js`）**：`team_link_roster action=get` 的详情与 `roster.md` 镜像按 `batchId` 分组报「已准备 / 已认领 / 已过期」逐角色三态（同一份渲染），pending 行带批次与清单规模；两处**都不新增工具**。
- **文档面（同批）**：README 的徽标 / 稳定性行 / 当前读数行（**1738 → 1753 → 1758**；末项为分歧修复轮 +5）· 本档 · 本批需求/设计两档的**实施状态行** · 合规档 §六 的逐档字节（入口 `254,947 → 261,720`、`lib/rotation.js` `93,422 → 140,582`（批 S 首交付实测；旧文写的 140,540 是差 42 B 的旧读数）`→ 143,899`（分歧修复轮后）、`lib/handover.js` `55,761 → 66,531`，仍 < 262,144，余量 424 字节）。

### 已知边界（如实登记）

- **批次分组只在「同批次仍有 pending」时归因**：`batchRoles` 清单落在 pending 行内（`NF-S4` 允许的两个落点之一）——claim 会清掉该角色自己的 pending，所以「已认领」只能靠同批次**其它** pending 的清单归因；整批全部落定/取消后分组自然消失（`D7`：批次标识只在 pending 行内，**不新增顶层键、不落团队行字段**）。设计与需求档都按这条口径实现，不假装更持久。
- **确认后执行期失败不再承诺零副作用**（`D11`）：已建会话**逐项点名**（含失败角色自己那个）、**pending / 撤销依据**零写入而 `pendingCreates` 意图按实数报出、给幂等重试指路；平台没有「删会话」原语 ⇒ **不做假补偿**。崩溃在 mint 循环之后、单次写盘之前留下的**孤儿会话**登记为已知窗口（设计档 §9）。
- **恢复路径不受批次互斥限制**：`team_link_recover` 的 `revive` / `reappoint` 是救场路径（设计档 `D8` / `FR-S6` 只说「单角色 prepare」），被一个在飞批次锁死会让「死的现任」无路可走。
- **不做** agent-team 档的 Lead 更换 / 「一把换完」/ 混合批次 / 交接文档格式变更 / claim 的信任迁移语义变更 / 黑板与台账改动 / 自动归档 —— 需求档 §五 的七条非目标全部保持。

## 未发布 — 批 Q：换届的「撤销依据」按换届各存一份

**一句话**：把换届的**撤销依据**（信任状态快照）从「每个团队一个槽」改成「**每一次换届各存一份**」—— 同一个团队里先后/连续换两个角色时，前一次的快照**不再被后一次的 prepare 抹掉**；旧格式的单槽**读取时无损折叠**、下一次写回收尾时**吸收为 null**（不复活），而 `policy.json` 的**顶层键一个没加**。

### 三段话（用户视角）

**① 现象与根因（前因）**：`rotationBackup` 原来是**团队级单槽**，而 prepare **整队覆写**它（`{ ...team, rotationBackup: backup, … }`）⇒ 换第二个角色时，第一个角色的撤销依据被**直接抹掉**。今天「一次只换一个」让这个洞不容易被看见；一旦批量（5 个角色连发 prepare），最后只剩**最后一个**的撤销依据 ⇒ 「不可还原」被放大到全队。★ 它**今天已经发生**：任何「先后换两个角色」的团队，前一次的快照此刻已经不在盘上。

**② 现在怎么做的**：团队行**内部**新增集合 `rotationBackups`（每条 `{ rid, at, backup }`，`rid` = 本次换届的稳定标识）。prepare **追加**本次条目（`rid` 由 `pending.rotationId` 承载，行内字段），**一次 `policy.update`**，不再整队覆写；四处读面（名册镜像 / roster get 详情 / claim 取撤销依据 / 过期清扫取前任何）全部改成「**按本次 pending 的 rid 取那一份**」；claim 成功与过期取消**只删自己那条**（与既有「清除 pending」同一笔写，并把旧槽吸收为 `null`）。**旧档升级窗口**（旧单槽 ＋ 升级前就存在的 pending，其内没有 `rotationId`）走**确定性推导** `legacy:<角色名>` —— 折叠侧与 claim 侧是**同一条推导**，所以那次在飞换届照样取得到自己那份；`0 个或多个` pending 时折叠成**独立条目**（`legacy:<at ISO>`；旧槽缺 `at` 时 `legacy:at-unknown`，绝不出现 `legacy:undefined`）—— **永不丢、也不猜归属**。

**③ 怎么验证**：判据 **`Qr1`–`Qr11`**（共 **11 条** `check()`，落在 `host-half.test.mjs` 的「批 Q」块，标识符 `Qr` 中缀；刻意放在「批 R」块 **Rr8 之后**，于是 Rr8 的判定面一个字符未动）。**两次实测**（本单，本地 Node 桥）：**修复前**（旧 `lib/` × 新判据，2026-10-18 在 `%TEMP%` 副本复现）`node host-half.test.mjs` ⇒ **`1738 (failed: 17)`**（`Qr1/2/3/4/5/7/9/10/11` 共 9 条 ＋ `Rr8` 连带 ＋ 7 条被本批改准的既有断言：`M4 prepare` / `U20` / `U27` / `Y1` / `U9 (c)` / `U10 (c)` / `B/U12`；`Qr6/Qr8` 属覆盖缺口类，修复前**绿**）；**修复后** ⇒ **`ALL PASS / assertion total: 1738 (failed: 0)`**，`node client-half.test.mjs` ⇒ **`310 (failed: 0)`**（不回归）。

### 改了什么（逐面）

- **形状与归一化**：`lib/policy-store.js` 新增 `normalizeRotationBackups`（无 `rid` 或快照读不出可还原字段的行丢弃 —— 不编造空壳），`normalizeTeams` 读时补齐 `rotationBackups`（旧行零迁移），`normalizePending` 的**固定键白名单**补 `rotationId`（不补就会被每次读写循环静默丢掉，与批 G 的 `renewedAt` 同一坑）。**`TeamConfig` 不加声明**：`schemastery` 保留未声明键（既有注释与实测都成立）。★ **2026-10-18 更正**：交付时写的是「入口档字节数不变 ⇒ `Rr1`/`Rr7` 不需要动」—— 该句在**分歧修复轮**之后**作废**：修复轮改了入口档 4 处描述/兜底文案（+145 B）⇒ `lib/index.js` **254,947 B**，`Rr1`/`Rr7` 的合规读数已重取（合规档 §六 同批改准）。**声明面仍是零新增**。
- **读视图与写回**：`lib/rotation.js` 新增 `pendingRotationRid` / `rotationEntriesOf`（旧槽**读取时折叠**，D3）/ `rotationEntryOf` / `appendRotationBackup` / `removeRotationBackup` / `clearRotation`。`append` 与 `remove` 都在**同一次写**里把旧槽置 `null`（§7 的唯一吸收形态，**不采用** `absorbedAt`），并把折叠出来的那一份**实体化**进集合（所以既不丢、也不复活）。
- **写面**：prepare 追加本次条目并生成 `rot-<base36 时间>-<uuid8>` 作为 `rid`；回执那一行改成「撤销依据（本次换届 rid=…）」＋「团队内另有 N 条在飞快照原样保留」。
- **读面**：`claim` 按 `pendingRotationRid(entry)` 取快照（回执新增「撤销依据（本次换届 rid=…）」一行，旧任取**本次快照的 roster**）；`replayClaim` 与过期清扫的 `snapshotIncumbent` 同样按 rid 取；`roster.md` 镜像与 `team_link_roster action=get` 的详情**列全部在飞条目**（两条在飞 ⇒ 两行）。
- **失败方向**：本次换届的撤销依据**读不出来、而团队里确实有别的换届的快照**（有东西可借）⇒ claim **具名拒绝**、零迁移零落定零写入（`fail-closed` 于信任）；团队里**一条快照都没有**（升级前的手写行 / 夹具）⇒ 没有可借的，照既有语义继续并在回执里如实写「本次换届的快照不在集合里」。**绝不回退到「团队第一条 / 最近一条」**。
- **结转两条（批 P 交付评审的 🔵）**：① `Pi7④` 补判据 —— 桩 `refuseSet: true` 时审批写面**被调恰 1 次**（新增 `calls` 账本，与「写成功」的 `sets` 分开记）、回执含**逐字**失败文案且不含成功分支那句；② `applyInheritedApprovalPolicy` 加 **`session` 在场守卫** —— handle 形状缺 `agent.session` ⇒ **不调写面**、返回具名「写面入参形状断层」行（拿 `undefined` 去调写面会把「没设成」变成假成功或无关的裸 TypeError）。
- **文档面（同批）**：README 的徽标 / 稳定性行 / 当前读数行（**1727 → 1738**，并把 `Rr4` 的旧「现读红」更正为**现读绿**）· 本档 · 本批需求/设计两档的状态行。

### 已知边界（如实登记）

- **并发不在本批判据面内**：宿主半边是单进程、`policy.update` 是既有单写点，**顺序两个角色**已经证明这个修复（`Qr1`）；「同时」按**串行写面口径**验收，本批不对并发做断言（设计评审 🔵#7 的口径）。
- **`Qr2` 的修复前红相**：设计档 §8 原把「旧档无损折叠」列为覆盖缺口类（修复前绿）。实测它**修复前红** —— 因为该判据读的是**新的读视图函数**（`rotationEntriesOf`），旧实现里这个名字根本不存在。如实登记，不假装修复前是绿的。
- **不做整队换届 / 不改 claim 的信任迁移语义 / 不改令牌机制 / 不改快照字段内容 / 不动黑板与台账** —— 需求档 §五 的六条非目标全部保持。
## 未发布 — 批 R：上架合规（拆分 + 声明）

**一句话**：把宿主半边从**单文件 1,093,629 字节**拆成**入口 ＋ 23 个域档**（最大单档 `lib/index.js` **254,802 字节**，**全部低于商城 262,144 字节**的单文件上限），补上 `engines.node >=22`，并把依赖 / 权限 / 外部服务 / 失败边界写成一份可审的合规档 —— **对外行为零变更**（工具面、参数、返回文案一条没动，既有判据文本也一条没改）。

### 三段话（用户视角）

**① 现象与根因（前因）**：DSH STORE 的上架自动检查（[issue #1380](https://github.com/AI-Scarlett/DSH-Store/issues/1380)）把本插件判成 `catalog-blocked`，三条确定性原因里唯一硬阻塞是**单文件过大**：`lib/index.js` 当时是 **1,093,629 字节**（**工作树**读数 = blob 1,077,286 B ＋ 16,343 个 CRLF），**越商城 262,144 字节上限 4.17 倍**；另两条是**声明缺失**（`package.json` 没有 `engines`；运行时依赖的用途 / 许可没有单独成文）。商城原文明确：这**不是安全漏洞指控，也不表示项目质量有问题**，只说明当前固定源码尚未满足可安装 / 自动更新契约。

**② 现在怎么做的**：按**领域**（名册与状态落点 / 换届与恢复 / 黑板与台账 / 投递与列表导出 / 看门狗与工作台 / 段渲染 / 工具注册…）做**纯机械搬运** —— 只「移动函数 ＋ 补 `export` / `import`」，**一行逻辑、一句文案都没改**；入口仍是 `lib/index.js`（`main` / `exports` 四项 / `dsh.bundle.patch` / `dsh.client` 逐字未动）。落地读数是 **24 档宿主半边**（入口 ＋ **23 个域档**）＋ 浏览器半边 `lib/client.js`，**最大单档 254,802 字节**（入口），余量 7,342 字节；逐档字节表见合规档 §六。同批补 `"engines": {"node": ">=22"}` —— **只写真跑过的下限**（本机宿主运行时是 Node **v24.14.1**；18/20 上一次都没跑过，所以不写），并把依赖 / 权限 / 外部服务 / 失败边界收进 [`docs/2026-10-15-store-compliance.md`](docs/2026-10-15-store-compliance.md)。

**③ 怎么验证**：判据 **Rr0①–④ / Rr1–Rr8**（共 **15 条** `check()`，落在 `host-half.test.mjs` 的「批 R」块）。`Rr1` 遍历 `lib/*.js` **逐档打印实数字节**（每档 < 262,144；文案里写明历史红相 1,093,629 与 1,092,693 这个旧读数差 936 B 的来历）；`Rr2` 把入口面与**写死的字面量**逐项比对（不读快照）；`Rr3①–④` 宿主说明符仍恰 8 个（范围写死、内部相对导入不计入）；`Rr4` 静态解析相对导入建图，并用**合成夹具**自证「A→B→A 必被检出」；`Rr5` `engines` 与 README「宿主版本支持」同区间；`Rr6` 零新依赖 / 零构建；`Rr7` 合规档 §六 的「最大单档字节」**等于** `Rr1` 实测；`Rr8` **既有判据全绿且条数对齐**（本轮之前 1722 条全绿；非 `Rr` 判据 `1712 = 1697`（设计日基线）`+ 15`（批 34 / FR-7 的 `A-7`，非批 R））。**实测读数**：`node host-half.test.mjs` ⇒ **`1727 (failed: 1)`**（唯一红项是 `Rr4`，见下「已知偏差」）· `node client-half.test.mjs` ⇒ **`310 (failed: 0)`**。

### 已知偏差（如实登记，不粉饰）

`Rr4`（模块图无环）**现读红**：`lib/shared.js` 与 `lib/rotation.js` **互导**（各有一条 `from "./…"`），静态导入图里有一个**真实的 2 环** —— 它自拆分第 5 小单 `R-5` 起就存在，且 `lib/shared.js` 档头当时把它论证成「不是环」。设计档 D3 / §6 不变量 ③ / §9 边界都要求**禁循环**，而本单的**写域不含 `lib/**`** ⇒ 判据**按设计原口径保持严格、不设例外**，因此它红。**修法（需另立单，改 `lib/**`）**：把 `ROTATION_TTL_MS` / `ROTATION_RATE_LIMIT_MS` / `ROTATION_TOKEN_LABEL` / `pairKey` / `fmtWindowRest` 从 `rotation.js` **下沉**到 `shared.js`（或一个新的低层档），`shared → rotation` 那条边随之消失。**在这一处修掉之前，本批不就「模块图无环」作任何声明。**

> **★ 2026-10-18 更正（批 Q 同批修正，B-5）**：这段「现读红」**已经不是事实** —— `fdfc832` 把上面点名的那 5 个符号下沉之后，`lib/shared.js` **没有** `from "./rotation.js"` 的任何一行、`lib/rotation.js` 只剩**单向** `import … from "./shared.js"` ⇒ `Rr4` **现读绿**（环 = `[]`）。本批按**实际读数**更正：`host-half.test.mjs` 的 Rr8 文案改成动态给出 `rrLibCycles`、档头那段「真实 2 环」的沿革注记同步改准；**Rr8 的判定面（既有断言全绿 ＋ 条数对齐）一个字符未动**。

## 未发布 — 批 34 / FR-7：台账写门（跨仓交付的 team-link 侧）

**一句话**：给 `tasks.md` 加一道**可机检**的结构门 —— `done` 必须该任务先有过 `claim`，`retract` 必须指向**本任务**真实存在的行；**默认 OFF**，开门 = **两侧各设一次**（本键归本插件，另一侧的 `anti_drift_config` 管不到它）。这一单同时**收掉盘上一个半成品**：门函数与接线早就在文件里，而 `PolicyConfig` 的声明面不在、验收腿也不在 ⇒ `policy.get()` 读的是一个**没人声明**的键，门**恒 OFF** 且零腿覆盖（「接线在、声明不在、腿不在」，比完全没做更危险：读者会以为门在工作）。

### 三段话（用户视角）

**① 现象与根因（前因）**：权威规格是套件仓 `dsh-thincoder-suite` 的 [`docs/2026-10-14-anti-drift-design.md`](../dsh-thincoder-suite/docs/2026-10-14-anti-drift-design.md) §5 **FR-7**（该档 §14 **L-9** 记录了这段来路：夜班轮实施过一次，被**并发会话的一次写入覆盖**；随后用户用 `87d215d` 把一批来路不明的改动回退出库，剩下的就是今天这个半成品）。根因有两条，都在**本仓**：**(a) 声明面缺位** —— `PolicyConfig` 里没有 `antiDrift`，而 `normalizePolicy` 是**固定键白名单**，所以无论盘上写了什么，`policy.get().antiDrift` 恒为 `undefined` ⇒ 门恒 OFF；**(b) 零验收腿** —— `host-half.test.mjs` 对 A-7 **0 命中**，也就是说「门在工作」这件事**从未被任何断言检查过**。

**② 现在怎么做的**：门本体是**一条函数 + 一处调用点**，位置在 `team_link_team_append` 的 `file="tasks"` 分支**内部**、**全部既有校验之后、`seq` 分配与追加之前** ⇒ **拒绝 = 零写入**（文件逐字节不变）。两条规则都只吃**可机检**的判据（零自然语言理解，本仓铁律）：**规则①** `done(t-N)` 要求本文件里已有一条 `r.task === t-N && kind === "claim"` 的行；**规则②** 把正文里所有 `t-<数字>` / `#<数字>` 抽出来，要求**至少一个命中「本文件可解析行里 `task` 等于本行 `task` 的行」**（`t-<n>` 面 = 命中本行的任务号；`#<seq>` 面 = 命中本任务某一行的 `seq`）。**失败朝向 = fail-closed**（台账读不出 / 行解析不了 ⇒ 拒写）。**刻意不做**三件事（设计档 §5 FR-7 的三条共识边界）：不判作者是否同一人、不判撤回是否真的驳倒了它、**不加 `kind` 白名单**（`retract` 在既有设计里**正是**用来消解 `dispute` 的，加白名单会把既有合法撤回打红）。开关落 **`antiDrift.ledgerTransitionGate`**（**嵌套**形态，会诊 #78 三家一致建议 ⇒ 将来加兄弟键不再动键集锁），**默认 `false`**。

**③ 怎么验证**：新增 **15 条**宿主判据（判据号 **A-7**，`grep -c 'check("A-7'` = **15**），全部走**真工具** `team_link_team_append`；**变异自证 5 处**（见下）；宿主机读 `node host-half.test.mjs` ⇒ **`ALL PASS / assertion total: 1722 (failed: 0)`**、`node client-half.test.mjs` ⇒ **`310 (failed: 0)`**。⇒ 构成 **`1722 = 1697（批 P 收口）＋ 15（批 34 / FR-7）`**。

### 改了什么（逐面）

- **门本体**（`lib/index.js` 的 `ledgerTransitionGate`）：规则①/② 如上。**这一单改正了一处实现偏差**：规则② 的 `t-<n>` 面此前读的是「**文件里任意**已登记的任务号」（`knownTasks.has(t)`），而规格要的是「**同任务**」——`#<seq>` 面一直是同任务的，两面口径不一致。现在两面共用同一谓词，且**放过它只需删掉那一个 `=== task`**（变异 C 正是这么做的，实测转红）。
- **声明面（三处同批，缺一即半成品）**：`DEFAULT_POLICY.antiDrift = { ledgerTransitionGate: false }`（缺省值的事实源）· `PolicyConfig.antiDrift = z.object({ ledgerTransitionGate: z.boolean().default(false) }).default(...)`（**非法值在 zod 层被拒**：`"yes"` ⇒ 抛 `expected boolean but got yes`）· `normalizePolicy` 固定键白名单里补 `antiDrift: antiDriftView(...)`（**非 `true` 即 `false`** —— 一个坏值绝不能把门凭空**打开**，朝向与 `sectionsView` 相反是刻意的）。
- **整份命名空间写入（第四处，漏了就是静默回归）**：`policyIsAtDefaults` 与 `adoptMemoryWindow` 的那笔 fold 补丁**各补一个键** —— 两半漏任何一半，一次晚挂折叠就会把用户**打开**的门悄悄翻回缺省 OFF（既有判据「U9 对照」咬的正是这两半，本单让它再咬一次同一颗钉子）。
- **开关键集 10 → 11**：本仓既有纪律是「键集变化必须与 README 的键集描述**同批**更新」（U17），所以 `host-half.test.mjs` 的 6 处硬编码键集、`U19_POLICY_KEYS` 权威读数与 README 第六节的键集表**同批**改成十一项（新行 `antiDrift`），所有「十项 / 十键 / ten keys」的措辞同步改准。
- **判据 A-7（15 条）**：规则① 正反相（无 `claim` 拒 + **字节级零写入** / 有 `claim` 过）· 规则② 正反相（不存在 ⇒ 拒 / 指向**别的任务**的真实行 ⇒ 拒，`t-<n>` 与 `#<seq>` **两面各一条** / 本任务 `#<seq>`、`t-<n>` ⇒ 过）· **射程**（`plan` 与 `decisions` 分支照旧 —— 不扩大既有拒绝面）· **默认 OFF 零回归**（不种键 ⇒ 真视图读回 `false` 且声明面在场；开关 OFF ⇒ 两条规则**一条都不生效**）· **开关可读可写**（真 store 写 true/false 读回；非法值被 zod 拒 + 归一化层不打开门）。
- **文档面**（同批，**不得只改代码不改档**）：README 新增「台账写门」一节（两条规则 / 三条边界 / **开门 = 两侧各设一次** / **已知的既有语料不一致**）＋ 键集表新增 `antiDrift` 行 ＋ 三处计数改到 1722；本档即 CHANGELOG 条目。

### 变异自证（5 处，各自在自己的**副本**上做，真仓未动）

| # | 变异 | 期望 | 实测（`assertion total (failed)` 与本批腿） |
|---|---|---|---|
| **A** | 把门关掉（开关读数改成常量 `false`） | A-7 ①/② 的**拒绝**腿转红 | 见下「实测读数」 |
| **B** | 去掉规则① 的 `claim` 前置（`hasClaim` 恒真） | A-7 ① 转红 | 同上 |
| **C** | 破坏「同任务」谓词（两面都放宽成「文件里任意真实存在的行」） | A-7 ② 的**同任务**两条腿转红 | 同上 |
| **D** | 从归一化视图里抽掉声明面（`policy.get().antiDrift` 恒 `undefined`） | ③ 缺省读数 ＋ ④ 可读可写转红，全部门相关腿转红 | 同上 |
| **F** | 把开关写成恒真（模拟「门默认 ON」） | ③ 的两条**零回归**腿转红（＝零回归的反证：差异完全由开关决定） | 同上 |

★ **诚实口径（级联，如实登记）**：A/B/C 三个变异会让**前一条腿写进去的行数变化**，于是后面几条**依赖 seq 编号**的腿**连带**转红 —— 那是夹具级联，**不是**各腿独立可红的证据。真正独立可红的靶子是：**A/B ⇒ A-7 ①**（无 claim 的 done 被拒）、**C ⇒ A-7 ② 的两条同任务腿**。变异 D/F 的读数见下。

## 未发布 — 批 P：换届继任者的设置继承（FR-P1…FR-P4）

**一句话**：**换届建出来的新会话，终于自带前任的设置** —— 预设与模型（以及可写时的审批档）都从前任会话自己存下的那一份读，而不是每次都退回宿主的全局缺省；**读不到的项一律如实说出口**，绝不假装。

### 三段话（用户视角）

- **你遇到的现象**（2026-10-13 原话）：「**换了之后新会话还得重新设置权限和模型，不能自动继承老的会话的**」。根因取证：**同一个插件里两条路口径相反** —— 创建面把 `preset/provider/model` 写死成 `undefined`（`lib/index.js:8134` / `:13981` 两处字面量），而**复活面早就在读**「这个会话自己存下来的预设」（`:11100`）。⇒ 修法本质是「让创建面读复活面**已经在读**的东西」，**零新增状态**。
- **现在怎么做的**：新增一个**继承读取器**（四项：`preset`/`provider`/`model`/`approvalPolicy`，**读不到一律 `null`、绝不抛**）＋ 两处调用点接线（**只有前三项进 plan**）＋ **创建返回之后**按读数设审批档（**共用函数一字未改**）＋ **三处逐项如实可见**（确认框正文 / prepare 回执 / 交接文档事实段：值是什么、没继承的原因是什么）。
- **怎么验证**：判据 `Pi1`–`Pi9`（**14 条 `check()`**，含双分支红相与「把审批档设置调用改成 no-op ⇒ 必红」的负向锁）；**三个宿主探针**（翻宿主 `app.asar`，只读、零写入）给出「模型对可读 / 审批档可写且是创建后设 / 已死前任可读预设」三条结论 ⇒ **三项都不必降级**；宿主机读 `node host-half.test.mjs` ⇒ **`ALL PASS / assertion total: 1697 (failed: 0)`**、`node client-half.test.mjs` ⇒ **`310 (failed: 0)`**。⇒ 构成 **`1697 = 1646（批 I）＋ 20（批 K）＋ 8（批 L）＋ 9（批 J）＋ 14（批 P）`**。

★ **两小单的交付形态如实登记**：本批拆成「探针＋读取器＋接线＋首批判据」与「三处可见＋审批档＋余下判据＋文档收口」两单；第二单以 `error` 终止（路由 `deepseek-flash`，子会话记录不可读、无法进一步归因），**其代码与判据已落盘并经父侧实测全绿**，**文档收口由父侧补齐**。

## 未发布 — 批 J：协调者的派工信号加固（FR-J1…FR-J4）

**一句话**：2026-10-13 凌晨真机 —— `bac-1009` 队的**三个队员全部空闲**，协调者却在自己做记账与文档，并在黑板上自认三次越界（R136 / R139）；而「你只做：管理 / 协调 / 决策 / 评审 / 设计；**不实施**」「实施一律派给团队成员」「成员『空闲』= 待派工」**早就逐字写在它的宪章里**（`renderCharterLines`）。⇒ 本批不是「补规则」，而是**把既有规则变得更难被忽略**，并给它一条**不必读别人历史的查活路**。设计见 [`docs/2026-10-13-coordinator-signal-design.md`](docs/2026-10-13-coordinator-signal-design.md)（§4 D1–D6 · §5 FR-J1…FR-J4 · §6 伪代码 · §7 状态与 schema · §8 判据 U1–U9 · §9 边界 · §10 第二轮评审折入），需求见 [`docs/2026-10-13-coordinator-signal-requirements.md`](docs/2026-10-13-coordinator-signal-requirements.md)（US-J1…US-J4 · NF-J1…NF-J5 · §五 非目标）。

### 三段话（用户视角）

**① 「有活没派」提成独立告警档（FR-J1）。** 此前「空闲待派」只是**摘要里的一行散文**，还被「有可行动内容才投」＋ 10 分钟去抖 ＋ 指纹去重三道门压着 ⇒ **最该刺眼的那种形态**（队员全闲着、没人在被派活）与「刚转空闲」同一档处理（根因 1）。现在触发条件是**空闲待派非空 ∧ 无人在跑**，走**自己的通道**：`[idle-unassigned]` 开场、自己的去抖与指纹（与摘要**互不抑制**），文案**陈述事实**「没有成员在被派活」并点名列出的成员（**不指控** —— 触发条件包含「团队确实没活干」这个超集，误报由去抖 ＋ 限量 ＋ 措辞一起兜住），且**只发给该队现任协调者**（派工本来就是它的活）。★ **口径（用户 2026-10-13 的评审裁定，取代「同一状态不重复」）**：窗口外**允许复投**（信号不许沉没 —— 那次持续了数小时，一次性告警错过就永久没了），但**每段至多 3 次**（`IDLE_ALERT_MAX_PER_EPISODE`；「段」＝同一组空闲成员的签名，签名一变即重置）；条件由真转假即**删掉本段状态** ⇒ 下次满足条件是**新的一段**。**刻意不做**：不试图拦「协调者自己干」（那一步走宿主子代理工具，插件拦不住，需求档非目标 1 已承认）· 不替协调者派活（D3）· 不动失联三态（`TICKABLE_VERDICTS` 仍恰三态）。

**② 协调者自身的上下文压力告警（FR-J2）。** 资源行此前只把「压力」渲染成一个**冷冰冰的百分比**，没有任何阈值告警，也没有任何地方写着「别去读别人的历史」（根因 2）⇒ 协调者为了「看队员在不在干活」去读队员的会话，把对方的窗口装进自己的窗口。现在：你是该队**现任协调者**、且你自己的上下文压力 **≥ 50%**（`LIAISON_PRESSURE_WARN_PERCENT`，**用户裁定 = 50**，具名常量 ⇒ 一行可调）时投一条 `[pressure-warn]`，**点名后果**（「再读别人的会话历史会把你自己的窗口读满」）。去抖与摘要同一个窗口，档位按 **每 10% 一档**（`bucketOf`）且只在**上升沿**再响（跨档振荡 59↔61 不重复打扰）；**读不到压力投影就不说**（绝不编造一个百分比）。**刻意不做**：不改既有那行资源读数（它是读数的唯一出口，有既有判据钉着 —— D6），告警**另起一行**。

**③ 事实源指路写两处 ＋ 文档面同批改准（FR-J3 / FR-J4）。** 宪章第 3 条尾部与**摘要脚注**各写一份**同一句**指路：「要看某位成员在干什么 ⇒ 读那个团队的黑板 `tasks.md`（`team_link_team_read`），**不要读它的会话历史**」（宪章是会话期内恒定的段、压缩后可能淡出，脚注每次摘要都到 ⇒ 两处覆盖两种时机 —— D5）；新句**加在脚注那一行内**，摘要的**四组正文一字未动、行数预算一行未增**。`team_link_watch` 的工具 description 与 `README.md` 的摘要段同批改准（两处**逐字一致**，判据 U9 咬），description 另补上两条新通道的一句话口径。★ **既有字节锁核查（§10-6）**：**已核 —— 仓内没有按字节钉死这两处文案的既有判据**（既有锁只钉**行数**：宪章 ≤ `CHARTER_MAX_LINES`、摘要脚注「恰一行」），所以本单只**新增**判据、无需改写既有期望值。

### 怎么验证

- **三个小单 ＋ 收尾单共新增 9 条宿主判据**（`host-half.test.mjs` 的「批 J」块，标识符统一 `Cj` 中缀；`grep -c '^check("批 J ·'` ⇒ **9**）：**J-1** `FR-J1` ⇒ **U1**（触发条件 ＋ 角色门，四态各自可红）· **U2**（自己的去抖 ＋ 窗口外复投 ＋ 每段限量 3 次 ＋ 条件转假即重置）· **U3**（与既有摘要互不抑制）；**J-2** `FR-J2` ⇒ **U4**（阈值 = 具名常量真值 50 · 同一档不重复 · **上升沿** · 角色门 · 读不到投影就不说 · 档位函数读真函数）；**J-3** `FR-J3`/`FR-J4` ⇒ **U5**（指路句在场：宪章 ＋ 摘要脚注）· **U7**（不回归：失联三态仍恰三态 · 摘要四组正文**逐行 `===`** 未动 · 行数恰 6 ＝ 表头 ＋ 四组 ＋ 脚注一行）· **U8**（零新依赖：顶层 `import` 仍恰 8 条且说明符是白名单 · 注册出去的命名空间仍恰十键）· **U9**（`team_link_watch` 的 description 与 README 摘要段的指路句**两边各自抽取后 `===` 互比**）；**收尾单** ⇒ **U6**（**反走私负向判据**：注册参数 `targets` 带毒**走真投递路径** ⇒ 两条新告警正文零控制字节、行数仍是 3，`[idle-unassigned]` 里**看得见**毒串的可见标记（载荷真进去了）；`[pressure-warn]` 里看不见它（那条通道只插值读数）；`team` 带毒的**另一半**如实锁住一条结构性结论 —— 毒团队名过不了名册（`^[a-z0-9-]+$`，团队名是黑板目录的路径段）⇒ 角色门恒假、两条告警**零投递**而摘要照投；再加**渲染面**直喂与 `renderPressureAlert` 的**结构免疫锁**；**负相自证**齐全：毒载荷本身带 `\t`/`\u0007`（4 处）与 2 枚 `\n`，不过消毒的对照拼串把它们原样带进正文（8 处控制字节 / 6 行）⇒ 「不含」不是恒真）。九条的红相逐条写在各自标题里。★ **覆盖缺口已补（2026-10-13 收尾单）**：设计档 §8 的 **U6** 此前如实登记为「没有单独立条 —— 已知覆盖缺口」，本单补列；同批把 **`renderIdleAlert` 补进批 E · U4 的消毒面清单**（`u4Faces`：8 面 ⇒ 9 面，实测 `9/9 面干净`）；**`renderPressureAlert` 不进那份清单** —— 它的正文只插值读数（数字或「未知」），结构上不可能出现该清单要求的「看得见的占位符」，进清单就是一个**恒假的假绿项**，改由 U6 第 ④ 段直接锁（该面的落点写进设计档 §8）。设计档 §10 的「Cj U1 … U9 ＝ 9 条」的落码口径此时才成立（三个小单那一轮是 **8 条**，见下一条的 as-of 标注）。
- ★ **两次实测读数（三个小单那一轮的读数，as-of：当时套件总数 = `1682`；本地 Node 桥执行 `node host-half.test.mjs`）**：**修复前必红** —— ① 把宪章 ＋ 脚注两处指路句**就地去掉**（＝ FR-J3 回退）⇒ `assertion total: 1682 (failed: 1)`（**U5** 红）；② 只把 **README** 那一份的一个词改掉（`黑板` → `台账`）⇒ `1682 (failed: 1)`（**U9** 红 —— 证明它咬的是「两处逐字一致」，不是恒真）；③ 顶层**加第 9 条 `import`** ⇒ `1682 (failed: 6)`（**U8** 红 ＋ 同源的既有锁 **U19 日志事件 / 批 H NF-H5 / 批 I U17 / 批 K U9 / 批 L Aw7** 一并红 —— 六道锁同源，一条越线全亮）；④ 往 `TICKABLE_VERDICTS` **多塞一态**（`idle-await`）⇒ `1682 (failed: 1)`（**U7** 红）。每次变异后都**逐字节还原**，并以同一份 `sha256` 自证（四次全部 `restoredByteExact: true`）。**修复后全绿**：`node host-half.test.mjs` ⇒ `ALL PASS / assertion total: 1682 (failed: 0)`（退出码 0）；`node client-half.test.mjs` ⇒ `ALL PASS / assertion total: 310 (failed: 0)`（退出码 0）。
- ★ **收尾单的实测读数（2026-10-13，本地 Node 桥）**：**修复前必红** —— 把 `renderIdleAlert` 里目标字段那处 `noticeField(...)` **就地去掉**（＝消毒出口被绕过）⇒ `assertion total: 1683 (failed: 1)`，**只红 U6**（批 E 那一面不红：它咬的是框定 token，不是控制字符）；**逐字节还原**后同一份 `sha256` 自证 `restoredByteExact: true`（`lib/index.js` = `73ee3d36…0fe2` / `host-half.test.mjs` = `0c9165fe…bc6b`）。**修复后全绿**：`node host-half.test.mjs` ⇒ `ALL PASS / assertion total: 1683 (failed: 0)`（退出码 0）· `node client-half.test.mjs` ⇒ `ALL PASS / assertion total: 310 (failed: 0)`（退出码 0）。★ **一处夹具纪律如实登记**：U6 的端到端毒**只下在注册参数上**（`targets` 走投递路径、`team` 走 ②′ 的零投递反相、渲染面另咬两个字段）—— 毒**会话 id** 会被会话桩当成路径名，本机实测收尾那次 `rmTestRoot()` 会以 `EPERM` 收尾（把 `assertion total` 那一行整个吞掉），故不进夹具（该 `EPERM` 本身是既有的 Windows 瞬时占用，改用一次干净写法后 5 次连跑只偶发 1 次、与本单改动无关）。
- ★ **口径如实（构成）**：宿主套件 **1683 = 1646**（批 I 收口的宿主实测值）**＋ 20**（批 K）**＋ 8**（批 L）**＋ 9**（批 J：J-1 三条 ＋ J-2 一条 ＋ **J-3 四条** ＋ **收尾单一条 `U6`**）。**客户端半边一字未改**（仍 **310**）。
- ★ **一处文档面同批改准（如实登记）**：`README.md` 的**徽标行 / 稳定性行 / 当前读数行**三处计数同批改到 1682，并在「三、跨会话看门狗」新增一节「工作台摘要与两条告警（批 J，2026-10-13）」——它就是 U9 咬的**摘要段**（此前 README 没有描述摘要内容的小节，本批随 FR-J4 一并立起来）；**收尾单**又把同样那三处同批改到 **1683**（判据 9 条 / 构成 `1683 = 1646 + 20 + 8 + 9`），两份批 J 档的头注与 §10 也同批改准。

## 未发布 — 批 L：名册文件的并发写保护（FR-L1…FR-L3）

**一句话**：2026-10-13 上午 `~/.dsh/team-link/policy.json` 被写坏（**841,905 字节的完整 JSON ＋ 尾部 73 字节垃圾** ⇒ 整份 `JSON.parse` 不动，10 个团队 / 68 组配对 / 12 条看门狗全部读不出来），根因是**所有写入者共用一个固定名的临时文件** —— 两个进程的 `open(tmp, "w")` 落在**同一个 inode** 上互相截断。本批把临时名改成**每次写唯一**，并给 `rename` 补**有界重试**与**可注入的接缝**。设计见 [`docs/2026-10-13-policy-atomic-write-design.md`](docs/2026-10-13-policy-atomic-write-design.md)（§4 D1–D6 · §5 FR-L1…FR-L3 · §6 伪代码 · §8 判据 Aw1–Aw8 · §9 边界），需求见 [`docs/2026-10-13-policy-atomic-write-requirements.md`](docs/2026-10-13-policy-atomic-write-requirements.md)（NF-L1…NF-L5 · §五 非目标）。

### 三段话（用户视角）

**① 病根只有一个：临时文件的名字是写死的（FR-L1）。** `writePolicyFileAtomic` 此前写 `const tmp = <目标>.tmp`（固定名）⇒ 两个 DSH 进程同时写名册时，乙的 `open(tmp, "w")` 会**截断甲正在写的那个文件**，两个 `writeFile` 在同一 inode 的不同期望长度上交错 ⇒ 目标文件里出现「甲的完整内容 ＋ 乙的一小段尾巴」。文件涨到 814 KB 之后写得越久、时间窗越容易重叠，所以是**文件长大了才开始坏**。改法是最小的一步：临时名 = 目标路径 + `.tmp-` + 进程号 + `-` + 8 位随机 hex（`createHash("sha256")` 取 `pid:Date.now():Math.random()` 的前 8 位）⇒ 两个写者**不可能**碰同一个 inode，撕裂的物理前提消失。★ **同一个病根还在另一处咬人**：批 K 的心跳（activation 首拍与首条巡逻拍并发）也被它咬出偶发红，当时只在测试侧用等待面绕过 —— 本批改完，**生产侧的根治点就在这一处**，心跳自动受益（测试侧的等待面按原样保留：它等的是 I/O 事实，与谁和谁并发无关）。

**② rename 补有界重试，并且改名只经一层薄接缝（FR-L2）。** Windows 上目标被占用时 `rename` 会抛 `EPERM`/`EBUSY`，而既有调用方**一次都不重试** ⇒ 一次偶发失败就是「这段状态没落盘」。现在：最多 **3 次**（含首次）、间隔 **25ms**、**末次不再多等**；仍失败 ⇒ best-effort 清掉自己那个临时文件、**保留原始 errno** 抛给调用方（既有 `persistPolicyFile` 的 catch 接管 ⇒ 落点行如实降级成 `⚠ …`，**绝不假装写成功**）。改名只有**一个出口** `renameThroughSeam(tmp, file)`（体内只一句真改名）—— 它是给判据留的**可注入接缝**：`node:fs/promises` 是内建模块、ESM 绑定在测试里不可改写，没有这层缝，「注入 EPERM」这条判据就只能靠真去占住文件（不确定、不可控）。`__testing.setRenameThroughSeam(fn)` 换缝、`renameThroughSeamIsDefault()` 自证已还原。

**③ 失败必须点名到写入者，且不搞告警风暴（FR-L3）。** 首次退避时留**一行**，内容**同时含**三要素：**目标文件路径 ＋ 错误码（errno）＋ 写入者函数名**（用户 2026-10-13 的裁定口径，取代原写的 `file:line` —— 行号会随代码漂移）。这道门与既有的「落点降级」那道门**各自独立**、都是**一段一行**（写成功即复位 ⇒ 成功之后新的一段失败会再报一行）。**刻意不做**：不做文件锁 / 跨进程协调（那要新依赖且跨平台行为不一）· 不做「启动时清扫残留临时文件」（它不解决本次故障，且引入新写面 —— 留作后续候选）· 不改 `policy.json` 的 schema 与键集（仍十键）· 不动损坏档守卫（读到损坏文件仍走「不覆盖 ＋ 人工处置」）· 不改各写点的调用语义 · 不碰黑板的 `appendFile`。

### 怎么验证

- **新增 8 条宿主判据**（`host-half.test.mjs` 的「批 L」块，标识符统一 `Aw` 中缀；`grep -c '^check("批 L ·'` ⇒ **8**），判据 **Aw1–Aw8** 逐条带红相构造：**Aw1** 唯一临时名（正向：函数体内含 `process.pid` ＋ 一次哈希调用 ＋ 不含那个固定名字面量）· **Aw2** 固定名不在场（**全文件**作用域的反向锁）· **Aw3** 重复写不撕裂（连续两次 `policy.update` ⇒ 恰等于第二次那一份；`Promise.all` 双写者并发 ⇒ 仍是**一份完整文档**、零 `.tmp-*` 残留、**两次都算落盘成功**；等价新进程读回 ⇒ 十键齐、不判损坏）· **Aw4** rename 失败有重试（注入「前两次抛、第 3 次放行」⇒ 文件最终正确、恰 2 次注入失败、留痕恰一行且三要素齐、成功之后没有落点降级行）· **Aw5** 重试耗尽后的失败方向（落点行降级 ⚠ ＋ 内存态照常可读 ＋ **目标逐字节未动** ＋ **零残留** ＋ **原始 errno 与注入原句都在留痕里** ＋ 两道门各恰一行 ＋ 接缝已还原自证）· **Aw6** 零 schema / 零形状变更（仍十键、`schema=1`）· **Aw7** 零新依赖（顶层 `import` 仍**恰 8 条**且说明符逐字是白名单）· **Aw8** 负向锁（必经 `renameThroughSeam`、不含直接 `rename` / 直接写目标、接缝体内恰一句）。★ 两条**墙钟判不了**的设计条款（**末次不再多等**、**间隔 25ms**）只能读源码，Aw4 因此另钉住循环形状（`attempt < 3` ＋ `sleep(25)`），行为面的「每次写恰 3 次尝试」由 Aw5 的 `seamCalls === 6`（两次写 × 3）钉住。
- **既有断言同批改写 2 处**（改写不是删除，语义一字未动、只跟**新名字口径**走）：`U2 原子写` 的「别人崩在中间留下的半写临时文件」改成 `.tmp-*` 形态，第二条断言从「`.tmp` 不存在」改成「`.tmp-*` 只剩**夹具自己种下的那一份**（插件不认领、也不删别人的残骸，D6）」；`🟡#1` 夹具的「回写在飞时不打开目标文件」守卫从「那个固定名在场」改成「目录里有以 `.tmp-` 前缀开头的条目」。
- ★ **口径如实（本次交付的读数）**：新增条数 **8** 取自**源码逐条计数**（`grep -c '^check("批 L ·'`）；宿主套件**实测** **1674 = 1666 + 8**（1666 是批 K 收口的**宿主实测**值）。**宿主实测回执已回填（2026-10-13，父侧实跑）**：`node host-half.test.mjs` ⇒ `ALL PASS / assertion total: 1674 (failed: 0)`（退出码 0）· `node client-half.test.mjs` ⇒ `310 (failed: 0)`（退出码 0）。★ **红相如实登记**：源码级三条（`Aw1`/`Aw2`/`Aw8`）已由父侧以**只读**方式对「旧实现 vs 新实现」的**函数体**取到（旧：固定 `` `${file}.tmp` ``、无 `process.pid`/无哈希、无接缝 ⇒ 三条全红；新 ⇒ 三条全绿）；**行为面三条（`Aw3`/`Aw4`/`Aw5`）的「修复前必红」读数未取** —— 它需要「就地变异 ＋ 反复跑套件」，而该动作在本沙箱**两次令子代理挂死**（一次超时、一次静默看门狗）⇒ **如实登记为缺口**，不冒充。红相配方逐条写在 `host-half.test.mjs` 的「批 L」块头注里（就地变异 → 跑 → **逐字节还原** ＋ `sha256` 自证）。客户端半边**一字未改**（仍 **310**）。
- ★ **一处实施口径（如实登记）**：`writePolicyFileAtomic` 是**模块级**函数、**没有 ctx**，而 FR-L3 的留痕必须走 `ctx.logger` ⇒ 它多了一个**可选第三参** `warn`（留痕出口，由调用方传入带自己那道门的闭包）。store 的 `persistPolicyFile` 传自己的「一段一行」门（`warnRenameFailureOnce`）；**批 K 的心跳仍按两参调用**（它有自己的单行 warn，那条路径的函数体**一字未动**）。`import` 面**一个字符未动**：随机后缀用既有的 `createHash`、残留清理用既有的 `rm`（批 K 已加进 `node:fs/promises` 那一行的解构列表）⇒ 设计档留的那条「确需 `unlink` 时只加在既有解构行里」的退路**最终没有用到**。

## 未发布 — 批 K：崩溃现场留证（心跳，FR-K1…FR-K5）

**一句话**：DSH 反复**非正常退出**（`non-graceful-end`，真机崩溃史 40 条），而**崩溃现场是零** —— 因为崩溃时进程**没有机会跑任何收尾代码**，「死的时候写」这种写**永远不会发生**；本批改成「**活着的时候持续写**」：每次启动开一个自己的目录、原子覆盖一份定长小 JSON 心跳（内存 / 磁盘 / 活会话 / 看门狗），**下一次启动**就能读出「死前那一刻」的读数与**死亡窗口**（真机那次 79 分钟的空白就是这一格）。设计见 [`docs/2026-10-13-crash-forensics-design.md`](docs/2026-10-13-crash-forensics-design.md)（§4 D1–D7 · §5 FR-K1…FR-K5 · §6 伪代码 · §7 状态与 schema · §8 判据 U1–U15 · §9 边界），需求见 [`docs/2026-10-13-crash-forensics-requirements.md`](docs/2026-10-13-crash-forensics-requirements.md)（NF-K1…NF-K5 · §五 非目标）。

### 三段话（用户视角）

**① 写在哪、写什么、留几份（FR-K1/FR-K2/D1–D5）。** 心跳写在**插件自己的根**下：`<DSH_HOME 或 ~/.dsh>/team-link/forensics/<bootId>/heartbeat.json`（`bootId` = `<ISO 时间戳，冒号与点换成 ->-<pid>`，与 `policy.json` **同级**、权限与生命周期一致）。**每次启动一个目录** —— 文件系统自带历史，崩溃后那个目录还在，不需要任何额外逻辑就能拿到上一拍。内容是一份**定长小 JSON**（`schema` / `bootId` / `pid` / `startedAt` / `lastBeatAt` / `seq` / `uptimeSeconds` / `memory{rss,heapUsed,heapTotal}` / `disk{free,total}` / `sessions{live,roster}` / `watchdogs`），写用**既有的原子写助手**（`writePolicyFileAtomic` —— 本批把它从 store 闭包里**原样上提**到模块级，好让心跳复用**同一个实现**，函数体一字未动）。保留**最近 10 次启动**，按**心跳内嵌的 `lastBeatAt`** 排序清理（**不是目录 mtime** —— 那是否随原子覆盖更新取决于实现细节，口径不稳），且**永不删本次**（本次若连心跳都没写成，它的 `lastBeatAt` 读不到，只按排序清就会把本次自己删掉）。**写频**：首拍在 activation，周期拍挂在**既有巡逻定时器**上 ⇒ **零新增常驻定时器**。

**② ★ 零注册兜底（FR-K5，评审 🟡#1 的处置）与「不双写」。** 巡逻定时器是**按注册建**的 ⇒ **一条看门狗都没有时根本不存在巡逻**，心跳会**静默停在首拍** —— 而一台没人注册看门狗的机器，正是最可能毫无征兆崩掉的那种。所以 activation 时若 `policy.watchdogs` 为空，**另起一个 `unref()` 的兜底定时器**（10 分钟）专写心跳；**一旦出现注册（巡逻开始跑）就把它停掉**，且它退场后再被 tick 也**不写第二遍**（不双写）。常见情形（本部署恒有自动注册）仍走复用路径、**零额外定时器**。★ **兜底是双向的（交付评审 🟡#1 的第二半）**：巡逻定时器**按注册**建 ⇒ **最后一条注册被删掉 / 过期清扫掉之后巡逻也不会再来**，只在启动时挂兜底等于把「静默冻结」从「启动时」换个入口 ⇒ 那条「归零时刻」**必须把兜底重新挂上**（幂等，不会挂出第二个定时器）；重挂点四处在 `createWatchdog`：收注册（`removeWatchdog`，含提前返回那一支）· clear 工具（`cancel`）· 重挂表（`rearm`）· **巡逻最末尾**（`patrolBeat` 刚把兜底收掉，而**同一轮**可能刚把最后一条注册收掉）。**读面**：既有 `team_link_status` 多一个**可选** `action=forensics`（**不加新工具** —— 工具数同改锁；**不带该参数时输出逐字不变**；闭集外的取值**如实拒绝**，不静默退回默认卡）。

**③ 三条硬边界，条条都有判据。** **纯自家**：只读写自家 `forensics/` 根下的东西，宿主那半个仪表（`~/.dsh/death-forensics/`）**一概不读、不写、不删**，代码里连那个目录名都**零出现**（U13 是这条的负向锁）。**不编造**：`statfs` 读不到 ⇒ `disk.free`/`disk.total` **就是 `null`**（不是 0、不是估算）；没有旧目录 ⇒ 如实说「**无（首次运行）**」；旧目录里心跳损坏 ⇒ **跳过该目录、视同无此份**；**「在飞作业数」本批不做**（插件读不到宿主的作业服务 ⇒ 读数里**没有这一格**，也不用猜测的 0 冒充）。**fail-open**：心跳是**观测**不是功能，任何失败只留**一行** warn、绝不抛进热路径。★ **免责句是硬约束（U11）**：心跳只证明「最后一次说话停在那一刻」，**正常退出与崩溃在这份数据上同形** ⇒ 本批**只留现场、不单独下崩溃结论**，区分二者要**由人**结合宿主 `crash.log` 的 `non-graceful-end` 记录。

### 怎么验证

- **新增 20 条宿主判据**（`host-half.test.mjs` 的「批 K」块，标识符统一 `Fk` 中缀），判据 **U1–U15** 逐条落地、每条带红相构造：**U1** 首拍在场（目录名恰等于 `bootId` · `pid`/`schema`/`seq=1` · 三个公开路径都在自家根下）· **U2** 周期心跳（注入时钟跑两轮巡逻 ⇒ `seq` 递增、`lastBeatAt` 跟着走、**不新开目录**）· **U3** 原子写（目录里恰一个 `heartbeat.json`、零 `.tmp*`、写前写后都 `JSON.parse` 得过、十一格齐）· **U4** 死亡窗口**双向**（预置旧目录 ⇒ 窗口 = `[其 lastBeatAt, 本次 startedAt]`；无旧目录 ⇒ 如实说「无（首次运行）」且**没有**任何 `- 窗口：` 行）· **U5** 保留上限（12 份旧目录 + 本次 ⇒ **恰 10 份**、删掉的恰是最旧的 3 份、**本次永不删**、最新的旧目录仍在）· **U6** 只读合同（settings 命名空间与**磁盘递归快照**逐字节不变、`seq` 不前进、目录数不变）· **U7** 输出面三点（不带 `action` ⇒ 首行仍是落点行、八段头按序在场、**零**崩溃现场痕迹；闭集外取值 ⇒ 如实拒绝；带 `action=forensics` ⇒ 含窗口与四类读数、**不含**「在飞作业」）· **U8** 失败方向（把现场根占成一个**文件** ⇒ 首拍失败、巡逻**不抛**、心跳失败**只留一行** warn、默认状态卡照出八段）＋ **负相自证**（那档夹具里心跳确实一个都没落盘）· **U9** 零新依赖（`lib/index.js` 顶层 `^import` 仍**恰 8 条**且说明符逐字是白名单）＋ `policy.json` 仍**十键** · **U10** 磁盘诚实路径（`statfs` 桩成 reject ⇒ 两格**恰为 `null`**、心跳照写、输出说「读不到（不编造）」；★ 跑完**必须还原**读盘器，`diskSpaceReaderIsDefault()` 当场自证）· **U11** 免责句（含「非正常退出不单独归因」＋「正常退出与崩溃…同形」＋ 指路由人结合宿主 `crash.log`）· **U12①②** 零注册兜底**双向**（`watchdogs === []` ⇒ 兜底在场且由**它自己那条缝**驱动两拍；种进一条注册并让巡逻跑起来 ⇒ 兜底**已退场**、那一窗口内 `seq` **只增一**、退场后再 tick **零写入**）· **U13** 写面只落在自家根下（一次「首拍 + 巡逻 + 清理 + 再写一拍」之后，**新增/改动的路径全部**在 `forensics/` 之下且非空集；`lib/index.js` 对宿主那个目录名**零命中**）· **U14** 兜底**双向②（中途归零必须重挂）**（两个夹具：最后一条注册被 `removeWatchdog` **删掉** / 被巡逻**过期清扫**收掉 ⇒ 兜底重新挂上、心跳**仍周期更新**、再触发一次归零路径与再显式挂一次都**不产生第二个定时器**；★ 过期那一档钉住**巡逻末尾**那处重挂）· **U15** 空串 `action` 的口径（参数描述逐字含「**空串视为省略**」∧ `""` 确实走省略支（首行落点行 + 八段头按序 + 零崩溃痕迹 + 无拒绝行）∧ 闭集外的 `"nope"` 仍**如实拒绝** —— 描述与实现**逐字一致**才绿）。
  夹具纪律：一律走既有工厂（`setup` / `teamRow`），**不依赖墙钟**（`activation` 的首拍走真墙钟，周期与兜底两处一律**注入时钟**）；判据读的是**真控制器**（`__testing.forensicsFor(ctx)`）与**真文件**，不抄一份进测试。为「把上一次启动的现场种在 `apply` **之前**」（FR-K3 的读发生在 activation 内），本批给 `setup` 加了一条**可选的**夹具缝 `policyHomeDir`（省略 ⇒ 历史行为逐字不变）。
- **既有断言同批改写 2 处**（改写不是删除，都是「同一份清单两处写、只改一处即红」那类**同改锁**）：`U6 只写一处`（原判「`<home>/team-link` 目录**不存在**」）与 `U9 迁移可核`（原判「`<home>/team-link` 条目数 === 1」）—— 批 K 的心跳根按设计（D1）与 `policy.json` **同级** ⇒ 那个目录从此**必然存在**；两条都改成**点名条目集**（比原来更强的布尔/计数判断，本意「状态**落点**一个都不建」一个字未变）。
- ★ **口径如实（本次交付的读数）**：新增条数 **20** 取自**源码逐条计数**（`grep -c '^check("批 K ·'`）；宿主套件**实测** **1666 = 1646 + 20**（1646 是批 I 收口的**宿主实测值**）。**宿主实测回执已回填（2026-10-13，父侧实跑 ＋ 交付评审处置轮实跑）**：`node host-half.test.mjs` ⇒ `ALL PASS / assertion total: 1666 (failed: 0)`（退出码 0）、`node client-half.test.mjs` ⇒ `310 (failed: 0)`（退出码 0）。★ **交付评审处置轮（同日，只修偏离不新增设计）**：判据 **18 → 20**（补 **U14** 中途归零重挂 · **U15** 空串 `action` 口径），并修三处偏离 —— ① 兜底心跳定时器**单向** ⇒ **双向**（最后一条注册被删/过期后必须**重新挂上**，否则只是把「静默冻结」从启动时换个入口）；② **空串 `action`** 的口径按 **(b) 支**定案 —— 取「**空串视为省略**」并把这句话**逐字写进参数描述**（判据同时咬住描述与实现两侧；闭集外的 `"nope"` 照旧如实拒绝）；③ `bootId` 目录形态正则**收紧**到与生成端 `startedAt.replace(/[:.]/gu, "-")` **严格互为镜像**（旧谓词会放过 `2026-10-13T--Z-1` 这类畸形名）。**红相读数（本轮实测）**：砍掉中途重挂 ⇒ `assertion total: 1666 (failed: 1)`（**U14** 红）· 只砍**巡逻末尾**那一处重挂 ⇒ 同样 `failed: 1`（U14 红 —— 过期清扫那条路径靠它）· 删掉参数描述里「空串视为省略」半句 ⇒ `failed: 1`（**U15** 红）。★ **修复轮补记（首轮交付）**：首轮交付的宿主验收 **6 个 stage 全红**（崩在 `host-half.test.mjs:13500`），根因＝判据直读 `ctl().previous` 而实现只在 `inspect()` 里暴露该字段；修复轮同时暴露并修掉既有判据 `U11 前置` 的实现缺陷（心跳读政策走了会**自发附着**的 `get()` ⇒ 新增非附着只读 `peek()`）。客户端半边**一字未改**（仍 **310**）。
- ★ **交付方自查（不是宿主的验收命令）**：本轮用一次**独立的、私有的** DSH_HOME 起过一次真 `apply`（不碰真实 `~/.dsh`、跑完即删），逐项读过首拍落盘 / 两轮巡逻递增 / 12 份旧目录清理到 10 / `statfs` 拒时两格为 `null` / 零注册兜底双向 / 「上一次」窗口与死前读数 / 免责句 / 默认卡零崩溃痕迹 —— 读数见交付报告（**宿主回执仍以 `node host-half.test.mjs` 为准**）。
- ★ **三处实施口径（交付方如实登记 ＋ 修复轮补第 ③ 条）**：① **首拍调用点**落在 `apply` 收尾、**不是** `policy.onAttach` 的后置链（设计档 §5 括号里的落点猜测）：本部署是 `no-register` ⇒ 文件后端，而那三个 `notifyAttached()` 全被 `scope !== null` 门住，**文件为空 / 无文件时那条链一次都不会跑** ⇒ 首拍挂在那里等于**静默零心跳**（正是本批要消灭的失效形态）；② `writePolicyFileAtomic` 从 store 闭包**原样上提**到模块级（同一实现、两处调用方），并在 `node:fs/promises` 的既有解构列表里加了两个名字 **`statfs`**（读磁盘余量）与 **`rm`**（清理旧目录 —— 设计档 §6 写的 `unlink` 删不掉目录，`rm` 才能按 `forensics/<bootId>/` 形态删）——**顶层 `import` 条数与说明符不变**（NF-K1）；③ **心跳的两处政策读数走 `policy.peek()`（非附着只读）而不是 §6 伪代码写的 `policy.get()`** —— `get()` 的首行是**惰性附着重试**，一次后台观测会**自发把晚挂的 settings 拉上来**（后端切换 + 窗口折叠 + 后置链 + `policy.json` 回写）、并让**既有判据 `U11 前置` 变红**；`peek()` 是 store 新增的只读面（不跑 `attachFrom`；已附着时读数与 `get()` 逐字相同）。



## 未发布 — 批 I：屏蔽的作用域（`team_link_block`，FR-I1…FR-I6）

**一句话**：点一次【屏蔽】此前等于把那个会话在**整个部署里拉黑** —— 屏蔽只按「发送方」一个键落盘（`policy.blockedSenders`），而策略是**一份部署级共享文件** ⇒ 别的会话读到同一条、按同一个键判断；而且**没有任何解除路径**（误点之后只能手改 `policy.json` + 重启，真机 2026-10-12 就是这么救回来的）。本批把屏蔽改成「**两个会话之间的一对**」（**双向**），并补上**解除出口**（工具动作 ＋ 拒绝文案里的指引）；**旧格式记录一条都不改写、不静默放开**。设计见 [`docs/2026-10-12-block-scope-design.md`](docs/2026-10-12-block-scope-design.md)（§4 决策 D1–D8 · §5 FR-I1…FR-I6 · §6 伪代码 · §8 判据 U1–U20），需求见 [`docs/2026-10-12-block-scope-requirements.md`](docs/2026-10-12-block-scope-requirements.md)。

### 三段话（用户视角）

**① 屏蔽只挡那一对，而且解得开（FR-I1…FR-I4）。** 新的 `blocks` 条目形状是 `{ a, b, by, since }`：`a` / `b` 是两个会话 id（写入时按字典序规范化 ⇒ A↔B 与 B↔A 是**同一条**），`by` 是**点屏蔽的那一方**，`since` 只作留痕。收件检查改成**接收方视角的一对**：`blocks` 里存在**同时含接收方与发送方**的条目 ⇒ 拒（**双向**），**不影响**它与其它会话的往来（真机缺陷正是「被屏蔽者对所有会话都发不出去」）。解除走新工具 `team_link_block`：`list`（看当前屏蔽，**配对屏蔽与旧格式分两组**，各带可执行的出口）· `unblock a=… b=…`（解一对，双向立刻恢复）· `clear-legacy sender=<id>`（按发送方**逐条**清一条旧格式记录）。**权限两条口径**（D7/D8，用户 2026-10-12 裁定）：配对屏蔽**只有发起屏蔽的那一方（`by`）能解**（被屏蔽方与第三方一律拒绝且零写入）；旧格式清条**被它挡住的发送方本人不得自清**（其余任何会话可清）。**刻意不做**：不做批量清（A1 否决：会一次放开全部旧保护）· 不改 roster / 换届 / 双门批准 · 不碰黑板文件 · 不做「屏蔽某个角色/团队」· 不做「投递目标过期」（那是**路由**的账，另立 [`docs/backlog.md`](docs/backlog.md) 的 B-3）。

**② 旧记录不静默放开（FR-I5 的另一半，NF-I3）。** 旧格式 `blockedSenders` 是**部署级全局名单**、**没有接收方维度** ⇒ 无法换算成配对；直接丢弃就是**静默解除保护**（安全向的坏方向）。所以它**原样保留、不再新增**，检查时与 `blocks` **并集**参与判定，出口只有显式的 `clear-legacy sender=<id>`；读面与拒绝文案都**标注「旧格式 / 范围偏大」**。手改出来的畸形条目也处置好了：缺 `a`/`b`/`by` 的**只丢那一条**（不带走整张表、不带进判定），整个键缺失读成 `[]`（**不需要 schema bump**）。两处拒绝文案（收件检查那一处与对话框「拒绝并屏蔽」那一处）现在都点名「**谁挡的**」（发起方会话 id，或「旧格式」）与「**怎么解**」（工具名 + 动作 + 参数示例）。

**③ 落点与判据。** 三个写路径（`blockSender` / `unblockPair` / `clearLegacy`）**各恰一笔** `policy.update`、补丁**只含那一个键**（`blocks` 或 `blockedSenders`）、**没有直接文件写**（U19）；`policyIsAtDefaults` 与晚挂折叠的整份写入同批带上新键（漏一个键会把窗口里点过的屏蔽在折叠时静默丢掉 —— 那是 ② 轮 `pendingCreates` 的同族坑）。**零新 import**（八模块白名单原样，U17）。

### 怎么验证

- **新增 27 条宿主判据**（`host-half.test.mjs` 的「批 I」块，标识符统一 `Bi` 中缀），判据 **U1–U20** 逐条落地、每条带红相构造与负相自证（★ 2026-10-12 **追加项 D3** 补第 27 条 **U20**）：**U1**（`blocks` 三点齐：声明面 / 写入面 / 旧档归一化补 `[]` + 落点首行仍三态，3 条）· **U2** 写入配对化（规范化形状 ＋ 旧名单一字未变）· **U13** 写入必记 `by`（＝当事接收方）· **U3** 幂等 + 规范化（**正向 + 反向**各写一遍仍只一条、**零**新增写）· **U4 ★** 只挡那一对（B 拒 A / A 拒 B / **C→B 与 B→C 照常**）· **U5** 旧格式仍挡 ＋ 标注「范围偏大」＋ 不挡住别的发送方 · **U6①③** 解除真的解开（两向判定都放行 ＋ 端到端重新投得出去）＋ 再屏蔽一次又能挡上 · **U7** 解一对不存在的 ⇒ 拒绝 + 零写入 + **列出当前全部屏蔽** · **U11/U18②** 逐条清只清那一条（其余旧记录与其它九个键**逐字节不变**、恰一笔单键补丁）· **U12/U18③** 旧名单里没有 ⇒ 拒绝 + 零写入 + 列出旧名单 · **U14①②③** 解除权限三态（`by` 那方能解 / 被屏蔽方拒 / 第三方拒，后两者零写入）· **U15** `list` 分组呈现（配对组在前、旧格式组标注「范围偏大（旧格式）」、两组各带指引）＋ 空集负相 · **U16** 单条畸形条目丢弃（缺 `a` / 缺 `by` / 非对象 / `null`）、其余原样保留、不带进判定 · **U20 ★**（追加项 D3）`by ∉ {a,b}` 的条目**同样归一化丢弃**（其余条目逐字节原样保留、不带进判定、也不出现在 `list` 面）· **U17** `lib/index.js` 顶层 import 仍恰 8 条且逐字是白名单 · **U18①** 受益方不能自清 · **U19** 三个写路径各恰一笔 `policy.update`、补丁单键、落点文件无直接写 · **U8** 两处拒绝文案点名「谁挡的 + 怎么解」（对话框那一处 ＋ 收件检查的配对/旧格式两分支）· **U9** 文档同步（工具 description / `README.md`（能力清单 ＋ 架构图计数行 11）· 本文件 · [`docs/backlog.md`](docs/backlog.md) 的 **B-2 ✅** 且 **B-3 仍在册**）· **U10** 不回归（屏蔽仍**优先于配对快路径**、一个对话框都不弹；未屏蔽路径上两道门的提问顺序与 id 逐字未动）。
  夹具纪律：一律走既有工厂（`setup` / `teamEnv`），**不依赖墙钟**（本块没有一处用 `Date.now()` 做判据；`since` 只作留痕）。「零写入」的读数面是**补丁笔数**（`settings.namespaces` 的 `updates`）＋ 相关键**逐字节**比对。
- **既有断言同批改写 9 处**（改写不是删除，逐条留证）：① `§11.9 文档面=实现面（工具计数同改锁）` 的硬常量 `registeredTools.length === 10 → 11`（**设计档 FR-I6 的 ★ 硬锁**，漏它当场红）＋ `README.md` 架构图行的「10 个工具 + 2 条 / 命令」→ 11 且名单加 `block`；② `U5`（fan-out 的屏蔽行）的期望串只钉到「…已屏蔽来自当前会话的消息」为止（FR-I5 在它后面接了「旧格式 / 范围偏大 / 可执行清除指引」）；③–⑧ 六处**键集同改锁**（`U29 schema` / `U9 对照 (pendingCreates)` 的折叠键集 / `U19 schema` 的 `U19_POLICY_KEYS` 与声明面计数 / `U1 文件后端` 的文件 schema 键集 / `U11 schema` / `U17 键集与 README 同批`）各加第十项 `blocks`，并把「八/九项」的计数与 `README.md` 的键集描述「十项」同批改准；⑨ `批 E · U2 ①`（工具全覆盖）的 `BE_TOOLS` 清单与它的两组计数 `10 → 11`（**不改不会红**，但不改就是「全部 10 个工具都过消毒收口点」的**覆盖面假声明**）。★ **如实登记**：设计档 FR-I6 只点名了 ① 与 README 架构图行，③–⑧ 与 ⑨ 是**实施时发现的同类锁**（「同一份清单两处写、只改一处即红」的形态），一并改准并写进账本。
- ★ **口径如实（本次交付的读数）**：新增条数 **27** 取自**源码逐条计数**（`grep -c '^check("批 I ·'`；第 27 条是 2026-10-12 **追加项 D3** 的 **U20**）；宿主套件期望值 **1646 = 1619 + 27**（1619 是批 H 收口的**宿主实测**回执值）。**本轮的交付方未执行任何命令**（验证命令由宿主执行：`node host-half.test.mjs` / `node client-half.test.mjs`；**不要**用 `node --test`），宿主实测回执待回填。客户端半边**一字未改**（仍 **310**）。红相 / 绿相与宿主回执见 [`docs/verification-log.md`](docs/verification-log.md) 的「2026-10-12 · 批 I」一节。



## 未发布 — 批 H：删团队（`team_link_roster action=delete`，FR-H1…FR-H5）

**一句话**：`team_link_roster` 此前只有 `retire`（停用）—— 它把 `current` 置空、**名册行仍在**，而 vacant 之后 `set-role` / `retire` 都要求「现任协调者」发起 ⇒ **已退役的队谁都清不掉**（真机两例：批 E 取证建的 `u9-verify-1012` / `u9b-verify-1012`，用毕退役后仍留在团队列表里；`AGENTS.md` §七 又记着「本部署设置 UI 直改 `teams` 键不生效」）。本批加上 `action=delete`：**一次显式人类确认**之后把那一行（连同它自己的版本史）从名册里**真正删掉**，而**磁盘上的黑板文件一个字节不动**。设计见 [`docs/2026-10-12-team-delete-design.md`](docs/2026-10-12-team-delete-design.md)（§5 FR-H1…H5 · §6 伪代码 · §8 判据 U1–U11），需求见 [`docs/2026-10-12-team-delete-requirements.md`](docs/2026-10-12-team-delete-requirements.md)。

### 三段话（用户视角）

**① 删什么、不删什么（FR-H2 / FR-H4，非目标都守着）。** 删的**只有** `teams` 里那一行（含它每个角色各自的 `history`）；`pairs` / `trustedSenders` / `rememberTargets`（那是**会话与会话之间**的信任，不属于团队名册）、`watchdogs`、**其它团队行**一个字节不写。**黑板文件不读不写不删**：`<workspace>/team/<队名>/` 下的 `tasks.md` / `decisions.md` … 原样留着（真机上 `2026-10-08` 那份 64 行真实台账正是要保住的东西），报告里**点出目录路径**（存在 / 不存在都如实说）—— 这是「不删文件」这个决定的可核出口。**刻意不做**：不做归档、不做批量删（一次一个，确认框也一次一个）、**不改 `retire` 的既有语义**（它仍是「停用」，不删行）、不动 `policy.writer` 的判定逻辑；**零新 import**（八模块白名单原样）、**零 schema 变更**（只是少一行数据）。

**② 谁都能删，但要有人点一下（FR-H3；D2 ＋ D3）。** `delete` **豁免写权限门** —— 这不是顺手放宽：US-H2 的核心场景就是**已退役、没有现任协调者**的队，沿用 gate 就等于功能对它的目标场景**完全不可用**；把关改由**人类确认框**承担（形制照既有的 `askRecoveryConfirm`：同一个 3 分钟超时、同一套「答案按 label 回读」）。**无确认服务 / 用户取消 / 超时**三态一律**拒绝且零写入**，且刻意**没有**无人值守变体（删名册行不可逆）。确认框逐项写清：删哪个队 · 会删什么（含版本史 N 条）· **不会删**磁盘上的黑板目录（路径原样保留）· 不会改信任数据 · **不可逆**。**其余动作的 gate 一个字都没放宽**：同一批夹具里 `set-role` / `retire` / `set-mode` / `upsert-team` 对**非现任**、以及 coordinator **空缺**时的拒绝文案逐字仍是既有那几句，且四笔零写入。

**③ 顺序就是判据（FR-H2，评审 🟡#2 的修复）。** 先**校验在册**（不在册 ⇒ 如实拒绝 ＋ **列出已知团队名**，**连确认框都不弹**、零写入）⇒ 弹确认框 ⇒ **★ 写前重读名册**（确认窗口是分钟级，期间别的会话可能做过 `set-role` / `upsert-team` / 删了另一个队 —— 拿弹框前那份**陈旧快照**过滤回写会把那些改动**静默回退**；若这一行已不在 ⇒ 幂等拒绝、零写入）⇒ **单笔** `policy.update({ teams })`。写盘抛错 ⇒ 行**仍在** ＋ 如实报错（绝不出现「报成功但没删」）。名册落定后与 `set-role` / `retire` / `upsert-team` 走**同一条钩子**调 `sections.sync()`（被删团队的段随之释放）。

### 怎么验证

- **新增 19 条宿主判据**（`host-half.test.mjs` 的「批 H」块，标识符统一 `Dh` 中缀；判据 **U1–U11** ＋ **NF-H5**）：**U1** 动作进枚举（enum / 参数说明 / 工具 description 三处同批；`delete` 真的走得到分支，而不是被参数校验当非法枚举值拒掉 —— 2 条）· **U2** 删除生效（存储视图与 `roster action=get` 两处都读不到该队，且**恰好一笔**写 teams 的补丁，1 条）· **FR-H3** 确认框（五项内容 + 选项逐字「确认删除 / 取消」+ 挂在调用方 agent 上，1 条）· **U3** 逐字段不误伤（其它团队行 / `watchdogs` / `pairs` / `trustedSenders` / `rememberTargets` **逐字节**不变；被删队的 `history` 与第二个角色零残留）＋ **版本史条数如实**（角色行上加总的真实条数，不是恒 0 —— 2 条）· **U4** 幂等 / 如实拒绝（列已知团队名 ＋ 零弹框 ＋ 零写入，1 条）· **U5** 确认门三态（无服务 / 取消 / 超时，各「名册逐字节不变 ＋ 零笔写 teams 的 update」，3 条）· **U6** 不碰黑板（目录**逐项逐字节不变**：条目集 ＋ 每个文件的 size/mtime/内容 ＋ 目录自己的 mtime；报告点出该路径并如实说「存在、原样未动」，1 条）· **U7** 文档同步（工具 description / `README.md` / 本文件 / `docs/backlog.md` 的 B-1 ✅，1 条）· **U8** 不回归（现任在册 ＋ 空缺**两半**夹具里四个既有动作的拒绝文案逐字不变且零写入，2 条）· **U9 ★**（`policy.writer=coordinator` 下**非现任**调用方也能删；**vacant** 的队照删不误 —— 本批存在的**全部理由**，2 条）· **U10** 写盘抛错 ⇒ 名册行仍在 ＋ 如实报错、零成功措辞（1 条）· **U11** 黑板目录不存在也如实说（照常成功、点出路径并说不存在、且**没有创建**它，1 条）· **NF-H5** 零新依赖（`lib/index.js` 顶层 import 仍恰 8 条且逐字是白名单，1 条）。
  夹具纪律：一律走既有 roster 夹具工厂（`teamEnv` / `setup` ＋ 规范化种行），**不依赖墙钟**；「零写入」的读数面是**名册逐字节不变 ＋ 零笔写 teams 的 `policy.update`**（链尾 / 巡逻的 auto 补挂会异步写 `watchdogs`，拿总写次数当读数会假红）。
- ★ **口径如实（本次交付的读数）**：新增条数 **19** 取自**源码逐条计数**（`grep -c '^check("批 H ·'`）；**宿主套件 1617 = 1598 + 19**（1598 是批 G 收口时的宿主回执实测值）。**再经上面的分歧修复轮（D1 补 2 条）⇒ 现行值 `1619 = 1617 + 2`**（同一 grep 现读数 **21**）。★ **口径已翻正（评审 🔵#3）**：上面那个 `1619` 已由**宿主实测回填** —— `node host-half.test.mjs` ⇒ **`ALL PASS / assertion total: 1619 (failed: 0)`**（退出码 0）、`node client-half.test.mjs` ⇒ **`310 (failed: 0)`**；两行原文见 [`docs/verification-log.md`](docs/verification-log.md) 的「2026-10-12 批 H **宿主回执**」一节（此前本行写的是「现行**期望值**」，那是交付方零命令执行时的推算口径）。**本轮的交付方未执行任何命令**（验证命令由宿主执行：`node host-half.test.mjs` / `node client-half.test.mjs`；**不要**用 `node --test`）；红相 / 绿相与宿主回执见 [`docs/verification-log.md`](docs/verification-log.md) 的「2026-10-12 批 H」一节与其 §七 / §八。客户端半边**一字未改**（仍 **310**）。
- **既有断言同批改写 1 条**（改写不是删除）：`B/宣传面=实现面` 那条锁的是 roster 的**共享** `action` 闭集（原期望串 `get,upsert-team,set-role,retire,set-mode`），批 H 往末位追加第六个动词 ⇒ 期望串改为 `…,delete`；该条另外两半（`description.includes("set-mode")`、`mode` / `leadSessionId` 参数在场）**逐字未动**。理由：闭集锁必须跟着枚举走，**不是** set-mode 的语义变更（U8 的另一半正是钉住这一点）。
- ★ **2026-10-12 批 H 分歧修复轮（1 条恒假红 ＋ 4 条分歧，实现零改动）**：只读审计给出 5 条，逐条处置 —— **D0 🔴 恒假红**：U3 的 ④ 要求「保留下来的那一行里不许出现夹具**刚刚亲手种进去**的**标记**」`dh-old-1`（夹具工厂对**每一行**都种同一个 legacy id，而保留队也走同一工厂）⇒ 该子句**恒假**；修法是给工厂形参加一个默认值 `legacy = "dh-old-1"`（**默认值逐字不动** ⇒ 其余调用点不受影响）并让保留队显式传自己的标记 —— **不是**实现缺陷（唯一能变绿的办法是去删**别的队**的历史，而那正是 NF-H1 禁止的误伤）。**D1 🟡 覆盖缺口**：评审 🟡#2 的「写前重读」此前**一条判据都没有**（`askScript` 只有「确认删除」/「取消」/ 超时三种，没有一条在对话框打开期间改名册）⇒ 新增 **2 条 TOCTOU 夹具**（`批 H · U12①②`）：①确认期间目标行被并发删掉 ⇒ 幂等拒绝 ＋ 零写入；②确认期间**别的行**被并发改动 ⇒ 删除成功后**那笔改动不被陈旧快照回写抹掉**（②才是「去掉写前重读」的真红相）。**D2 🔵** 证据账本 §六 的判据行号 5 处漂移 ⇒ 按**符号名**复核重取并写明口径。**D3 🔵** U3 的逐字节比对**纳入 `blockedSenders`**（连同 `receiveMode` / `pendingCreates` / `sections`），且**种成非空 / 非默认值**（空数组会让「未动」变成空真）。**D4 🔵** `README.md` §十 首行读数 `1598 → 1617`（1598 保留为上一批 as-of 说明）。⇒ 批 H 判据 **19 → 21**，宿主套件期望值 **1619 = 1617 + 2**（**本轮交付方同样未执行任何命令**，实测与宿主回执见 [`docs/verification-log.md`](docs/verification-log.md) §七）。

## 未发布 — 批 G：自动工作台注册的续期（FR-R1…FR-R5）

**一句话**：全队工作台那条自动注册此前有 **12 小时 TTL、却没有任何续期路径** —— 连续开机满 12 小时它就**静默熄灭**（用户原始投诉「工作台摘要没了」的复现路径），恢复只能靠重启 DSH 或手动 `team_link_watch action=arm-team`；本批把 `planAutoWatchdog` 里**已经写好、也已经被文案承诺过**的 refresh 语义，接到**进程里唯一还活着的周期路径**（每条注册自己的 10 分钟巡逻定时器）上。

### 三段话（用户视角）

**① 续期与门禁（FR-R1，承重墙是「名册门」）。** 巡逻遇到一条 `origin: auto` 的行时，只要它**还在名册依据上**（团队仍在名册 ∧ 观察者仍是该队**现任**协调者 ∧ 除观察者外还有人可盯）且距到期不足 **2 小时**（新常量 `WATCHDOG_RENEW_WINDOW_MS`），就把租约顺延到 `now + 12h`、在同一笔写里落 `renewedAt`（**加性**字段，旧数据零迁移）—— 身份字段 `id` / `createdAt` **一个都不改**，`targets` 按名册**当场重导**（顺手修掉「成员中途入队却从未被盯上」这个同源缺口）。判定**放在 `patrolOne` 的到期门之前、只对本条目、续成即 `return`**：放到外面做成「预扫全表」会拿快照里的旧对象走删除门，**把刚续的行删掉**。写盘成功后**必补一次 `rearm()`** —— 续期让某条行不再走删除，同队「该合法死掉」的过期行否则**永远没人碰**（清扫链断）。**刻意不看观察者会话是否开着**：工作台摘要是**团队资产**，不是那个窗口的属性；设了活性门就会重新引入「协调者窗口关着、机器长开 ⇒ 摘要静默熄灭」。**名册门与 ensure 的谓词抽成同一个共享 helper**（`autoWatchdogRosterGate`），复制两份会单边漂移。

**② 两个同源洞（FR-R2 冷启动 / FR-R3 运行期复活）。** 关机超过 12 小时再开机时盘上的行**已经过期**，此前被 `ensure` 当「在场」报 `present` 然后 `continue`、随即被清扫链逐条收掉 ⇒ 工作台**当场死透**（比 12h 慢死更快）；现在 `existing` 查找加一条**「未过期」谓词**，过期行落到 refresh 分支 ⇒ **同 id 原地刷新并重新挂表**。巡逻**循环体末尾**再去抖地（60 秒，**时钟可注入**，与 `patrol({ now })` 同一条缝）补挂一次缺失的注册 ⇒ 机器睡过「2h 窗口 + 到期点」之后行已被清扫也能醒来自动重铸，**换届后新协调者的行也不必等重启**。`ensure` 的 refresh 分支同批统一字段形状（**保 `createdAt`、写 `renewedAt`、重算 `targets`**）—— 该分支**今天有活调用方**（`/team_session` 建队那条无 `existing` 守卫的路径），旧行为会把它重写成 `createdAt: now`，与「续期不改 `createdAt`」正面矛盾。

**③ 留痕与「不回归」。** 归一化 `watchdogList` 是**固定键白名单** —— 不把 `renewedAt` 加进去，字段每次读写循环都被**静默丢掉**；现在它进白名单，`watch list` 与状态卡第 ③ 段渲染「上次续期 …」（未续期则「（从未续期）」）。`markWatcherDead` 的注释与 `watch list` 的 dead 文案同批改准（「保留至 TTL」→「随名册续期，名册失效时由 TTL 收尸」）。**不做的**：不改 12 小时 TTL 常量；**不给手工注册续期**（人工 TTL 是用户意志，本批**非目标**）；不动静默阈值 / 巡检间隔 / 投递条件；不做「熄灭时的主动告警」；`agent-team` 档不另设门（与现状同级，避免两条路径语义分叉）。**零新 import**（八模块白名单原样）、**零新写路径**（仍只有 `policy.update`）、**零新定时器**。

### 怎么验证

- **新增 24 条宿主判据**（`host-half.test.mjs` 的「批 G」块，`批 G · U1/U2/U3/U4/U5/U6/U7/U8/U9/U10/U11/U12` ＋ 一条快照陷阱判据），全部用**注入时钟**（`patrol({ now })` 的既有缝隙）驱动，而该注入时钟**锚真墙钟**（`const RG_NOW = Date.now()`）—— ★ **分歧修复轮 D7 更正**：原措辞写的是「**不依赖墙钟**」，**与事实相反**。为什么必须锚墙钟：这些夹具行的**第一个写者**不是测试体，而是 **attach 后置链的 `ensureTeamAutoWatchdogs`**（它**不注入 `now`** ⇒ 走真实 `Date.now()`），而 **`rearm()` 的过期判定同样走 `Date.now()`** ⇒ 把行种在 2023 的假时钟上（`WD_NOW` 那套），attach 会先把它们当「已过期」刷新一遍（`expiresAt` 被写成墙钟+12h、`renewedAt` 被写下、`createdAt` 保留），本批三条 U1 的失败子句（`expiresAt === now+1h` / `renewedAt === undefined` / 窗口判定）**全部落空**。每条红相判据同批给**负相自证**：U1（续期生效 ＋ 逐字段保真 ＋ ★ 活性档「观察者不 live 也照续」，3 条）· U2（四态负向：团队不在名册 / watcher 非现任 / 协调者空缺 / 零可盯成员，各一条 ＋ 一条正相对照，5 条）· U3（写频：窗口内连巡逻两次 ⇒ 第二次**零写**；窗口外 ⇒ 逐字节不动，2 条）· U4（清扫链不卡死：续有效的、删无效的，1 条）· U5（冷启动同 id 原地刷新并挂表 ＋ 第二趟 `/team_session` 的 refresh 字段形状，2 条）· U6（周期 ensure 重铸，1 条）· U7（`renewedAt` 在归一化后仍在、两处渲染都可见、从未续期的行如实渲染，3 条）· U8（manual 行逐字节旧行为，2 条）· U9（`targets` 按名册重导，1 条）· U10（名册有效但已过期 ⇒ 删而不复活，1 条）· U11（换届后新协调者的行，1 条）· U12（`policy.update` 抛错 ⇒ 巡逻不抛、保留旧 `expiresAt`，1 条）· 快照陷阱（不做外层预扫，1 条）。
- ★ **口径如实（本次交付的读数）**：新增条数 **24** 取自**源码逐条计数**（`grep -c '^check("批 G ·'`）；总条数 **1594** 是**修复前**工作树的实测基线 —— 审计侧跑 `node host-half.test.mjs` 得 `assertion total: 1594 (failed: 18)`（**红相读数**；18 条红全部落在批 G 的这 24 条里，逐条归因见下「分歧修复轮」）。**本轮的交付方未执行任何命令**（验证命令由宿主执行）。
- ★ **宿主回执已落账（2026-10-12 收口）**：**修复后**的实测读数已由宿主回填 —— `node host-half.test.mjs` ⇒ **`ALL PASS / assertion total: 1598 (failed: 0)`**（退出码 0）、`node client-half.test.mjs` ⇒ **`310 (failed: 0)`**（退出码 0）；全仓框定原串扫描 **0 命中**；`lib/index.js` 的 import 面仍 **8 条**。总数构成 **`1598 = 1570 ＋ 24（批 G 判据）＋ 1（收口轮新增「U12 前置自证」）＋ 3（既有 `U26 真机形状` 一条四子句拆成四条独立 `check()`）`**；输出原文见 [`docs/verification-log.md`](docs/verification-log.md) 的「批 G 宿主回执（收口）」一节。★ 评审 🟡#2 更正：上面那行「实测读数**由宿主回填**」的承诺**已兑现**，本行即回填处（此前本档读者看到的终值仍是 1594）。客户端半边**未触碰**（仍 **310**）。
- ★ **真机验证已落账（2026-10-12 09:43，重启后）**：昨夜 00:28 到期的 10 条 auto 注册**全部被自动救回** —— 其中 **9 条重建**（新 id ⇒ 旧行已被 TTL 清扫，走的是「重建」而不是「刷新」）、**1 条还活着的原样未动**（`wd-01226a42…`，id 未变 ⇒ `present` 幂等成立）；`team_link_watch action=list` 与 `team_link_status` 第 ③ 段**都**渲染出「**上次续期（从未续期）**」那一格。⇒ **FR-R2（冷启动复活）与 FR-R4（留痕可核）在真机上得到证实**；读数原文见 [`docs/verification-log.md`](docs/verification-log.md) 的「批 G 真机验证」一节。
- **既有断言迁移（设计档 §10.1 两族，改写不是删除、留原名锚）**：`:2083` 一族（「观察者死了注册保留到 TTL」）与 `:3181-3193` 一族（「过期行不挂定时器」）—— 本轮**只改注释口径与相邻文案**、**未改这两条断言本身**（两族的夹具是 `origin: manual` 与「队不在名册」的 auto 行 ⇒ 在新语义下**逐字仍成立**），如实入账见 [`docs/verification-log.md`](docs/verification-log.md) 的「2026-10-12 批 G」一节。★ **分歧修复轮复核（2026-10-12）**：这两族**仍然一字未改**（本轮只改批 G 新增的 24 条判据）。

### 分歧修复轮（2026-10-12，只改本批新增的那 24 条 ＋ 一处生产缺陷）

一份只读审计（`module.registerHooks` 打纯内存补丁跑真套件、零落盘）给出 **9 条分歧**，逐条处置：

- **D1 🔴（真实现缺陷，而非判据问题）**：`createWatchdog` 体内的 `runPatrolEnsure`（FR-R3）引用了**该函数作用域里不存在**的 `watchdog` 绑定（全仓唯一的 `const watchdog = createWatchdog(...)` 在 `apply` 体内）⇒ **每轮巡逻都抛 `ReferenceError`**，被它自己的 `try/catch` 吞成一行 warn，而本部署 `ctx.logger?.warn` 是**空操作** ⇒ 生产上完全不可见，**FR-R3 等于没做**（warn 原文：`dsh-team-link: 巡逻按队补挂工作台注册失败（watchdog is not defined）—— 巡逻不受影响（fail-open）`）。修法：`:3411` 的**匿名返回字面量具名为 `controller`**，`:3322` 传它。**同族自查**：`createWatchdog` 体内引用的**每一个**外部标识符都过了一遍作用域链，清单见 `docs/verification-log.md` 的「2026-10-12 批 G 分歧修复轮」一节。
- **D2 🔴（夹具）**：8 个夹具用 `setup()` 却驱动 `env.watchdog.*`（只有 `watchdogEnv` 挂控制器）⇒ 宿主只看到第 1 个崩溃。全部换回 `watchdogEnv`（`selfCwd`/`sessions`/`extraAgents`/`settingsSeed` 四个参数逐处翻译成它认的 `targets`/`teams`/`watchdogs` 形状）。
- **D3 🔴（判据级根因）**：夹具行活在 2023 的假时钟上，而 attach 后置链的 ensure 走真墙钟 ⇒ FR-R2 让 attach 成为这些行的**第一个写者**，测试体读基准之前行已被刷过。⇒ 本块加 `const RG_NOW = Date.now()`，`rgRow` 与所有 `patrol({ now })` 一律锚它。
- **D4 🟡**：U6 的 ③ 只比 ① 晚 1ms，被 **60s 去抖**（`PATROL_SWEEP_MIN_INTERVAL_MS`）挡住 ⇒ 改成跨过 60s（`+61s`）并保留「不足 60s ⇒ 零新增」的负相。
- **D5 🟡**：U4 / U8① / U11 三条与本批**有意语义**相抵 —— U4 改成「续期行身份不变 ＋ 该合法死掉的那条被收」（并把两行种在 attach 之后，让「续期后补 `rearm()`」**真的可观察**）；U8① 零写基线移到**补挂之后**（同队再种一条 auto 伴随行，让零写只咬手工行）；U11 中间态本就不存在 ⇒ 改成「旧行死 ∧ 新行**同轮**铸出」。
- **D6 🟡**：U5② 的第二趟 `/team_session` 命中**幂等早退**（从不调用 `armTeamWatchdog` ⇒ refresh 分支无人验证）⇒ 两趟改请求**尚未登记**的角色（worker-b / worker-c），批次非空才真的走到 refresh 分支（`id` 不变是「走的是 refresh 而不是新建」的判别式）；U10 同族 ⇒ 过期行改在 `waitForChain` **之后**种。
- **D7–D9（文档）**：本文件与 `docs/verification-log.md` 的「不依赖墙钟」措辞改准（见上）；`README.md` 的徽章与逐批枚举同步到 **1594**（含批 G 的 24 条）；设计档 §5 FR-R3 的「**不 await**」与落码对齐（落码是 `await runPatrolEnsure(now)`，其代码注释已自行重解释为「不阻塞投递」），§10.1 的两次读数如实登记为**未做**。
- ★ **本轮新增的一处判据面修正（不在原九条清单里，随 D1 的修复暴露）**：U1 活性档里那条**被续的 auto 行续成即 `return`**（设计档 §6 的硬约束）⇒ 它走不到 watcher 活性门，`deadWatchers.size === 1` 这个子句**永远红**。修法：同一次巡逻里再放一条**不在续期分支上**的手工行（它照旧走到活性门被标 dead）⇒ 两半在同一次巡逻里同时可读。

## 未发布 — 批 F：`team_link_team_append` 的长文本压力（FR-1…FR-4）

**一句话**：把黑板**单行的写入上限**从 **500** 提到 **2000** 码点（甲），让模型**不必再为「塞不下」反复删改** —— 而删改正是漏出框定 token 的高发动作（取证：29 次流级失败里 **15 次**出在这个工具上，失败前的思考逐字是「Need to trim the text to 500 characters or less.」）。

### 三段话（用户视角）

**① 上限 ×4，账本形态一个字节没变。** 只改一个常量（`BLACKBOARD_LINE_LIMIT`）：**恰 2000 收、2001 拒**（按**码点**计）；一条 639 码点的历史失败样本现在**一次写成**。取值依据是实测：失败样本长 **402–639** 码点 ⇒ 2000 ≈ 观测最大值 ×3，同时仍是「单行读得下去」的量级。为什么不是 1000：观测里已有 637/639 两例贴着 500，只翻一倍**长裁决仍会贴顶**。**非目标**：不动账本形态（乙=自动折行，记为后续项）、不拆多次调用（调用次数 = 暴露次数）、不改读取格式。

**② 描述面与判据面同批改准（批 D 的教训）。** 模型可见的 `description`、`line` 参数说明、`discipline` 说明、回执文案与 `README.md` 里的「500」全部改成 2000；`host-half.test.mjs` 里钉上限的 **7 处**断言（M2 块的 decisions / discipline **三条** ＋ `§9 U4` 两条 ＋ `§9 U14` 两条字节相同的期望串）**改写**成钉 2000 而**不删除**，原名锚（`§9 U4` / `§9 U14` / 批 E · U1 ⑦ ＋ 三条逐字英文原名）仍可 grep 到；批 E 修复轮那条「原文 ≤上限、消毒后 >上限」的红相夹具**本来就按上限现造**（由导出的 `readBlackboardLine` 二分读出，不写死 500）⇒ 它自动改瞄 2000，本轮只改它那句提到 500 的措辞。

**③ 长行不再撑大显示面（FR-4，用户 2026-10-11 拍板「保留，实施」）。** 黑板行会被**两处**显示面渲染（状态卡第 ⑥ 段 与 客户端团队面板的 `tasksTail`）⇒ 上限 ×4 后最长的行也 ×4。现在**两处共用**同一个**按码点**的显示截断（前 **300** 码点 ＋ `…（已截断，全文见 team_link_team_read）`）。**盘上的文件与 `team_link_team_read` 的返回一字不动**（读面保真优先）；按码点切（`[...s]`）而不是按 UTF-16 码元 —— 后者会把代理对切成两半，与本仓 astral 红线相抵。

### 怎么验证

- **新增 20 条宿主判据**（`host-half.test.mjs` 的「批 F」块，`批 F · U1/U2/U3/U4/U5/U7`）：上限常量＝2000（由导出的 `readBlackboardLine` 二分读出 ＋ 显式钉 2000）· 干净输入恰 2000 收 / 2001 拒且**盘上什么都没写** · 639 码点历史失败样本**被接受**且盘上与读面**逐字**相同 · 描述面（工具 `description` / `line` 参数 / `discipline` / `README`）不含「500」含「2000」 · **原名锚仍可 grep 到**（探针由两半拼出，避免自我满足）· 零污染对照（≤ 旧上限的干净短行写入路径逐字节未变）· 显示截断**只影响显示**（盘上、读面、状态卡、面板四处同时对照，且夹具让**行**的第 300 码点正好落在星界字符上 ⇒ 「按码元切」会切出半截代理对，本条真能区分两种切法）。
- ★ **口径如实（本次交付的读数）**：上面的条数取自**源码逐条计数**（`check(` 调用点），期望值 **1570 = 1550 + 20**；**本轮的交付方未执行任何命令**（该批的验证命令由宿主执行），所以 `node host-half.test.mjs` 的**实测读数由宿主回填**。客户端半边**未触碰**（仍 **310**）。
- 真机项 **U6**（按同一口径重跑 `.investigations/token-sanitize-2026-10-11/scripts/tally-malformed.mjs`：观测窗口**自落码之日起 ≥7 天 或 该工具累计 ≥20 次调用**，判据 = 窗口内该工具的 `MALFORMED_RESPONSE` **≤2 次**且不高于同期 `team_link_send`）**未做**，属父侧（需真实观测窗口）。若复测显示失败率**未降到与其它工具同阶** ⇒ 根因在「长参数本身」而不在「卡上限」⇒ 按设计档 §9 走**乙**（自动折行）另行立项。

## 未发布 — 批 E：框定 token 消毒面（FR-1…FR-7）

**一句话**：让 DeepSeek 的**框定 token**（全角竖线 `U+FF5C` 包夹一段短词的那种包裹结构）**不再经过本插件的任何出口，也不再落进黑板** —— 它碰到一次就留在对话里、模型接着复现（跨 4 个工作区实测 **11 会话 / 29 次** `tool input is invalid JSON`，其中 **15 次**发生在 `team_link_team_append`，且 **15/15** 的参数里都带它）。

### 三段话（用户视角）

**① 换了而不拒绝、改了就说。** 命中的包裹结构替换成 `[framing-token-removed]`；命中多处时占位符**带编号**（`[framing-token-removed 1/3]`…）—— 处数就是文本自己，**不需要任何累加器、执行上下文或回执追加**；**没有命中 ⇒ 输出逐字节与改前相同**。为什么不拒绝：黑板是「谁声称了什么」的账本，一次拒绝只会让调用方反复重试，而重试正是毒上加毒的动作；投递面拒绝还会让消息丢失。

**② 出口一处收口，入口也只管该管的。** 消毒只写在**一个**函数里，挂在既有的三个 `wellFormed*` 收口点（结构性覆盖全部 **10** 个工具），另加跨会话投递正文、六个渲染面（角色段 / 资源行上下文 / 资源行 / tick / 工作台摘要 / 状态卡看门狗段）与 deep-link 快照出口；**入口**（`team_link_team_append` 写 decisions / tasks / discipline）在**落盘前**过同一道 ⇒ **黑板文件里不会出现它**。范围如实：入口只覆盖黑板，「盘上永不出现」这句话**不外推**到 roster 备注 / `recoveries` note / 团队名（那些读回路已被出口覆盖，传播环仍断）。

**③ 失败方向 fail-open。** 消毒自身出错时**原样返回**（`removed=0`），绝不让任何工具调用失败；历史上已落盘的内容**不追溯**；流式解析器那一侧（真正的触发层）**不在本仓**，另出观测报告给平台侧。

### 怎么验证

- **新增 37 条宿主判据**（交付面 33 条 ＋ **交付评审修复轮 4 条**：decisions/tasks 的**消毒后长度复检**两档 ＋ `scrub-sources.mjs` 的**拒写口径**两条）（`host-half.test.mjs` 的「批 E」块，`批 E · U1/U2/U3/U4/U5/U6/U7/U8/U10/U11`，逐条清单见交付报告）：黑板**盘上**逐字读回零命中（decisions / tasks / discipline 三条写面）· 十个工具逐个喂带毒返回值 + 端到端（★ **批 I 起这一格扩到 `11 个工具`**：`BE_TOOLS` 清单加了 `team_link_block`，见上方批 I 条目 ⑨ —— 本行保留批 E 当时的 as-of 读数） · 投递 banner / 结构化卡片 / 发送方确认框正文 · 六个渲染面（含两支实现，合计 8 面）· 处数自带编号（1 处 / 2 处 / 3 处）＋ 真实回执上「不静默」· 零污染对照与边界（ASCII 竖线 / 半截包裹 / 单枚全角竖线 / `{0,20}` 的上界）· fail-open（注入必抛的桩 ⇒ 工具照常成功、返回原文本）· **裸包裹**（无 `<` 前缀）与两种前缀形态 · deep-link 快照 · 静态零残留（源码与套件）。**红相口径**：`__testing.setStripImpl` 是设计档 §6.5 保留的注入缝 —— 换成「直通」或「冒充干净文本」即本批的两种「未挂 / 挂错」红相；凡标红相的判据都在断言里**同批做一次变异自证**（先证明变异被观测到，再断言生产实现下不发生），所以敏感性是**实测的**，不是靠声称。
- **宿主回执已落账（2026-10-11 收口）**：上面 37 条的**实测读数**已由宿主执行侧回填 —— `node host-half.test.mjs` ⇒ `ALL PASS / assertion total: 1550 (failed: 0)`（退出码 0）、`node client-half.test.mjs` ⇒ `310 (failed: 0)`；输出原文与 U8 扫描原文见 [`docs/verification-log.md`](docs/verification-log.md) 的「2026-10-11 批 E 宿主回执」一节。★ 评审 🟡#2 更正：原写「本地未执行…待回填」（交付轮时点的属实读数，现已被上句取代）。
- 真机项 **U9**（真实会话里让一条含毒文本经 `team_link_team_append` 落盘 ⇒ 盘上无 token；再 `team_read` ⇒ **读回那一行里看得见占位符**，处数由编号自证）**未做**，属父侧步骤。★ 评审 🟡#6 措辞更正：原写「回执报数」是 v1.0 残留（v1.1 下回执不另加读数行）。
- ★ **口径如实（本次改写的一半）**：交到实施侧的那个半成品曾用 `AsyncLocalStorage` 做处数通道，而 `host-half.test.mjs` 把 `lib/index.js` 的导入面钉成**八个已审计模块**的白名单 ⇒ 新增任何 import 都判红（半成品实测 **`1513 (failed: 1)`**，红的正是白名单那条）。**本轮把那条路整条撤掉**（import ＋ 累加器 ＋ 存取器 ＋ 回执报数代码 ＋ 十个注册点上的包装），改走设计档 **§6.5 v1.1** 的「处数由文本自带」⇒ `lib/index.js` 的导入面**仍是那八个**。

## 未发布 — 批 D：注册生命周期与自动提示（FR-1…FR-4）

**一句话**：修三类注册（角色段 / 资源读数 / 工作台摘要）的**两头** —— 该在的时候没在（重启后要人肉跑命令才挂上）、不该丢的时候被丢了（协调者一句普通 `clear` 就把全队摘要清掉）。

### 三段话（用户视角）

**① 重启后自己长回来。** 角色段与资源行只对**活代理**注册 ⇒ 重启那一刻若没有任何团队会话活着，attach 注册 0 个，此后你**打开**某个团队会话也不会自动补（真机实测：23:02 重启、23:41 worker 跑了两步都没有义务行，直到 23:46 有人跑了一条名册写入才补上）。现在插件在**每一步**做一次 O(1) 检查（名册想要、而它还没挂上 ⇒ 就地对齐一次）：打开会话的**那一步或最迟下一步**，角色文本与资源读数就位，**不需要跑任何命令**。非团队会话零扫描；检查失败只留一行 warn，**绝不打断回合**。

**② 全队的工作台摘要拿不走。** `clear` 此前会连 `origin: auto` 的全队工作台注册一起清掉（真机实测两轮：17:43 建的那条 22:47 前就没了；23:32 建的那条 23:32:55 被一句无参 `clear` 清掉，且**还没到 TTL**）。现在 `clear` **只清你自己手工注册的那些**；点名要清 auto 那条 ⇒ **拒绝**并说明它属于全队工作台；摘要脚注也同批改准（它原来在教协调者做这件会坑掉全队的事）。

**③ 资源读数按回合门控（用户 2026-10-10 拍板 A）。** 资源行在**动态运行时上下文**通道上，此前其「累计」每步都变 ⇒ 每步追加一条持久化快照（批 C 实测 0.93 条/请求，越过批 C §9.2 的评估线）。现在**同一 `turns` 内返回上一条字符串**（回合号前进才现算），快照量级降一个量级。代价如实声明：**回合内读数会变陈**（长回合里压力增长看不见）；缓存是进程内的、只用于门控，随注册生命周期释放（代理消失即清）。

### 怎么验证

- **新增 16 条宿主判据**（`host-half.test.mjs`）：`批 D · U1/U1b/U2/U3`（自愈可达 · fail-open 恰一行 · O(1) 零扫描与「无失败闩锁」限定 · 边界不变）· `批 D · U4/U5/U6`（`clear` 拿不走 auto · 脚注口径一致 · 拒绝可见）· `批 D · U7/U8`（回合门同回合不变 / 跨回合跟随 · 门控缓存随注册释放）＋ `批 C · U4 资源行四项 ← 三个 key（批 D §5.2 第 1 行改写 · 回合门）`（原名 `批 C · U4 改写`，2026-10-11 分歧修复轮按审计 D3 改名；读数驱动渲染 ⇒ 同回合不变 / 跨回合跟随）。
- **改写 4 组既有判据（条数不变，逐条留证）**：`批 C · U1 对照`（⇒ 同回合必相同 / 跨回合必不同）· `批 C · U9` 的「资源行随读数变」子句（同上）· `U17 clear 前置` 与 `U17 清掉的 auto 注册同进程不自愈`（对象由 auto 换成**手工**，auto 那一档改成「根本拿不走」）· `U22 前置` / `U22 现任可用` / `U22 幂等` / `U22 拒绝①–④` 的零注册起点与「零写入」读数（改用 attach 之后建队 + 逐字节基线）。**这一族是设计档 §5.2 未列出的连带**（§5.2 只列了 FR-3 的相撞断言），如实登记在交付报告里。
- 真机项 **U9**（重启后不跑任何命令、打开团队会话即带角色文本与资源行；随后 `clear` 后 auto 注册仍在）**未做** —— 需重启与真实流量，属父侧步骤。
- ★ **口径如实（宿主已回填）**：本批的两次实测读数由**宿主在执行侧**跑出。交付轮源码逐条计数给出的**期望值**为 `1494 + 16 = 1510`，宿主实测 **`1510 (failed: 2)`**（两条红：`clear` 的拒绝回执缺「未清除」）；经**分歧修复轮**修掉并新增 3 条判据（U5 扩为三条）+ 落实审计 D1–D4 ⇒ **最终实测 `node host-half.test.mjs` → `ALL PASS / assertion total: 1513 (failed: 0)`（退出码 0）**、**`node client-half.test.mjs` → `ALL PASS / 310 (failed: 0)`**。命令与输出原文见 `docs/verification-log.md` 的「2026-10-11 批 D」一节。

## 未发布 — 批 C 分歧修复轮（差异审计 `DIVERGENCE: 6` 收口）

**一句话**：批 C 交付后的独立差异审计共判 **6 条分歧（🔴1 / 🟡4 / 🔵1）**；本轮**只修这 6 条**，不加新东西。其中唯一的 🔴 是**测试夹具自己撒谎**：U5 那条判据在夹具静默丢参的形态下**恒红**。

### 修了什么 → 为什么 → 怎么验证

**① 🔴 U5 夹具静默丢参（唯一真红）。** `wb2Env` 的形参没有 `sections`，`wb2Env({ sections: { resources: false } })` 的键被转发给 `setup()` —— 而 `setup()` **没有这个形参** ⇒ 键被**静默丢弃**、开关保持缺省 `true` ⇒ `env.systemPrompt.contexts.length === 0` **恒假**。修法照 `wb4Env` 的既有正确写法：加 `sections` 形参并嵌进 `settingsSeed["team-link"]`；另加一条**前置对照**（缺省时上下文确实注册了），使得「把形参再删掉」这个变异会**当场打红**。红相＝删掉形参 ⇒ `1494 (failed: 1)`，红的正是 U5 那条。

**② 🔵 §6.1 段渲染体抛错不留痕。** 设计档 §6.1 已按 v1.1 改成 `renderRoleText(plan, onError)`：抛错**仍吞掉并返回空串**（热路径绝不让装配失败），但必须经 `onError` **留一行痕** —— 原「静默 `catch {}`」与 §9 的 fail-visible 自相矛盾。生产侧传的是注册器里那道**一次性**门（`warnRender`，与上下文面共用），所以两面任何一侧抛错整个生命周期内也只留一行。红相＝改回静默 `catch {}` ⇒ `1494 (failed: 1)`，且**只红那一条**。

**③ 🔵 §6.3「两面都缺 ⇒ 至多两行」原先没有夹具。** U6 扩成**五段**：第 ⑤ 支输入 `sp` 在而 `section`/`getSectionOrder`/`context` 都不是函数 ⇒ **零注册** 且**两面各恰一行**（合计**至多两行**，不是一行）。红相＝两面**共用一个 warn 门** ⇒ `1494 (failed: 3)`（U6 ②/④/⑤ 三条一起红 —— 共用门会让上下文面那行在只缺 context 时也不出现）。

**④ 🟡 计数三方漂移。** `README.md` 两处写 1442、本档 0.5.2 条目写 1477、交付态实测 1491（failed: 1）—— 三处各说各话。本轮跑过套件后三处同改为**同一个数**：`1494 = 1491 + 3`（修夹具不改条数，只有新增判据才加：本轮新增 3 条 —— U5 夹具前置对照 1 条 ＋ §6.1 段面留痕 1 条 ＋ U6 ⑤ 1 条）。

**⑤ 🟡 注释与设计档同主题声明未同改。** `lib/index.js` 的 `sections` 注释仍写「提示段」，自治批设计档四处（§5 FR-9 行 / §9 边界表「零段注册」/ §10 批次表 / 实施计划 §2）同款陈述未随批 C 的落点变更一起改 —— 其中边界表的「`resources=false` ⇒ **零段注册**」是**实质错误**（那时**段仍注册**、只是资源行不挂 context 面）。四处全部就地改准。

### 怎么验证

- `node host-half.test.mjs` → **`assertion total: 1494 (failed: 0)`**；`node client-half.test.mjs` → **`ALL PASS / 310 (failed: 0)`**。
- **修复前必红（实测原文）**：`node host-half.test.mjs` → `1 FAILURE(S)` / `assertion total: 1491 (failed: 1)`，红的正是 `批 C · U5 resources=false: …` 那条。
- **定向变异（三条新判据逐条实跑）**：删 `wb2Env` 的 `sections` 形参 ⇒ `1494 (failed: 1)`（只红 U5）；`renderRoleText` 改回静默 `catch {}` ⇒ `1494 (failed: 1)`（只红段面留痕那条）；两面共用一个 warn 门 ⇒ `1494 (failed: 3)`（U6 ②/④/⑤）。三次变异后文件**逐字节还原**（写入前先把原文读进内存，跑完写回并比对）。
- 原始读数与逐条证据见 `docs/verification-log.md` 的「2026-10-10 批 C 分歧审计修复轮」一节。
- **仍如实未做**：真机四项（U0 宿主面预检 / U8 命中率双读数 / U10 快照账 / U11 压缩后仍在）与 **FR-7 撤止血**（`policy.sections.resources` 恢复 `true`）—— 都需重启与真实流量，属父侧步骤。

## 未发布 — 批 C：提示缓存保真（资源行改挂动态运行时上下文通道）

**一句话**：把「每一步都在变的那行资源读数」从**系统提示**里搬出去，改挂宿主的**动态运行时上下文**通道 —— 功能一条不减，缓存命中率回到同会话基线。

### 三段话（用户视角）

**① 问题：插件把会变的东西放在了必须不变的位置上。**
团队会话的系统提示里有一段「会话资源」行（窗口 / 压力 / 累计 / 第几轮），它是**每次装配现算**的。AI 服务商按「请求前缀有没有变」给缓存打折：前缀里有一个字变了，从那往后（几万到几十万 token）**全部按全价重算**。真机实测 10 个团队会话：带这一行时 glm-5.3 侧命中 **0.5%–8.7%**，同一批会话不带它时 **96%–99%**（glm 侧约 **3.6 亿 token** 从打折价变成全价）。诊断见 [`.investigations/prompt-cache-hit-rate-2026-10-10/结论.md`](.investigations/prompt-cache-hit-rate-2026-10-10/结论.md)。

**② 修法：落点搬家，语义不动。**
`team-link:role` 段现在只产**会话期内逐字节恒定**的文本（协调者宪章 / worker 义务行）；资源行改挂宿主的**动态运行时上下文**通道（`agent.ctx.systemPrompt.context()`，`name=team-link:resources`、`order=130`），落点是**尾部追加的 user 消息**、不在系统提示里。读数仍然每一步刷新、仍然在模型的上下文里，只是不再碰可复用前缀。

**③ 降级与开关逐字不变。**
`policy.sections.resources=false` ⇒ 段里没有资源行、上下文通道**也不注册**；`role=false` ⇒ 段不注册、资源行照常。两个面**各自探测、各自恰一行 warn、互不牵连** —— 宿主换代把 `context()` 改名或移除时，宪章段**不受牵连**（资源行退到状态卡第 ⑧ 段与工作台摘要脚注那两处兜底出口）。

### 怎么验证

- 新判据 **U1–U7 / U9**（`host-half.test.mjs`）：段文本跨步**逐字节恒定**（锚测试）· 段文本对「`[team-link 会话资源]` / 压力 / 累计 / 第 <数字> 轮」**零命中** · 资源行走 `context()` 且 `order === 130` · 四项展示值 ← 三个投影 key 且渲染为**单行** · `resources=false` 两面都不挂 · **四段降级**（无 sp / 有 section 无 context / 有 context 无 section / context 注册抛错）· 两个 disposer **各释放一次**（合计 2）· coordinator 与 worker **两类会话同覆盖**。**本轮（分歧审计修复轮）的修订**：U5 的夹具**静默丢参**（`wb2Env` 少了 `sections` 形参 ⇒ 开关从未落到 settings ⇒ 那条判据**恒红**）已修；**U6 扩成五段**（补第 ⑤ 支：两面都缺 ⇒ 零注册 且 **两面各恰一行**）；段面渲染体的 `onError` 留痕判据补回（§6.1 v1.1 签名 `renderRoleText(plan, onError)`）。
- 红相构造（每条判据一条）：把资源行塞回段渲染体 ⇒ U1/U2 红；不注册 context ⇒ U3/U4/U9 红；开关只接到一处 ⇒ U5 红；两面共用一个 warn 门、或让 context 缺失牵连段 ⇒ U6 红；只释放一个 disposer ⇒ U7 红；把 §6.1 的留痕改回**静默 `catch {}`** ⇒ 段面留痕那条红；把 `wb2Env` 的 `sections` 形参删掉 ⇒ U5 回到恒红（本轮三条**都实跑做过定向变异**，见 `docs/verification-log.md` 的本轮小节）。
- 夹具侧：`makeSystemPrompt` 桩**同时**提供 `section` 与 `context` 两面，外加 `getContextOrder()` —— 桩镜像的是**宿主面**、不是自家调用面（AGENTS.md §四）。
- 套件读数：`node host-half.test.mjs` → **1494 (failed: 0)**；`node client-half.test.mjs` → **310 (failed: 0)**（本轮的两次实测读数贴在本档 0.5.2 条目与本档末的本轮条目）。
- **真机待验（需重启）**：U8（coordinator 与 worker 各自命中率 **≥95%**，且被测会话的快照里**确实含** `team-link:resources`）· U10（每会话快照条数 ÷ 请求数）· U11（一次全量压缩后快照仍含该贡献）· U0（宿主面预检）。**跑之前必须先撤止血**（`policy.sections.resources` 恢复 `true`）—— 否则测的是「资源行缺席」，命中率天然 ~99%，U8 会**空转假绿**。

## 0.5.2 — 2026-10-10（热修：重启后真机复验抓到的三处）

**一句话**：0.5.1 让老团队「能」吃到自治那套；这一版修掉三处「**实际上吃不到、或者吃到了也看不见**」的缺陷 —— 全是只在真机上才暴露的那一类。

### 三段话（用户视角）

**① 判读行不再被行数上限吃掉。** 状态卡第 ⑧ 段有 12 行上限；当会话多到 10 行时，末尾的判读行（那段「本节只判上下文/预算…」）会被**静默裁掉** —— 也就是说**团队越忙，越看不到它**。现在先给判读行与轮换标记**留位**，被裁的只能是明细行，而且会明说 `（行数上限 12；已省略 N 行明细）`。

**② 重启后「按队补挂」真的会跑了。** 0.5.1 的补挂挂在插件挂载的后置链上，但那一刻策略数据**还没到位**（代码里原本就写着「activation 那一刻还是空的」）⇒ 补挂空转、**零写入而且一点声都不出**。现在数据一到位就补通知一次。重启后这类「配好了却没生效」不会再静默。

**③ 状态卡多了一行「attach 后置链」，失败不再无声。** 上面那处之所以要靠翻日志才发现，是因为后置链的失败**没有任何出口**（本部署 `ctx.logger?.warn?.` 是空操作）。现在 ③ 段末尾会报最近一次后置链的结果：`rearm 挂上 N 个定时器 · 段同步（计划变化 M 项；在场 S 个段） · 按队补挂：created X · present Y · skip Z（首因 …） · failed W`。四档都不静默：没记录就说「尚无记录」、还在飞就说「尚未落定」、整轮抛错报 failed。

### 顺带修 / 澄清

- **`skip` 与 `failed` 分家**：此前「没有观察者 / 没有可盯成员」（正常）与「**写入失败**」「定时器没挂上」（真失败）都记成 `skip` ⇒ 一次真的写入失败会**伪装成正常跳过**。现在后者进 `failed` 并报首因；`arm-team` 命令面的输出也随之分档。
- **判据两处补漏**：U26 原本「等一个 tick」在负载下**偶发红** ⇒ 改按墙钟有界等待；U27 的「纯读」断言原本摘掉那一行会**空真**（恒真断言永远绿）⇒ 加「该行真的在场」前置。

### 怎么验证

- `node host-half.test.mjs` → `ALL PASS / 1494 (failed: 0)`；`node client-half.test.mjs` → `ALL PASS / 310 (failed: 0)`（0.5.0 的 1442 → 0.5.1 的 1466 → 0.5.2 发布时的 **1477** → 批 C 交付 **1491 (failed: 1)** → **1494（本轮分歧修复后，全部全绿）**；**1494 是三处同改的当前值**。**为什么同一条目里的 `1477` 与 `1494` 不矛盾**：1477 是 0.5.2 的**发版时点**读数；其后批 5/6/7 与批 C 又各加了断言、且批 C 交付时留了 1 条恒红（见下方批 C 条目与本轮条目）⇒ 现值只能有一个。）。
- 每条判据都有「修复前必红」读数（U25 / U26 / U27 + 本轮三条）。
- **真机待验（需重启）**：那一行后置链读数会直接给出「补挂卡在哪一步」。

### 仍未验（承接 0.5.1）

1. ~~看门狗重挂的真机证据~~ ⇒ **本条已收口**：2026-10-10 **16:33:57** 探针 tick 到达（= 启动 16:23:55 + `intervalMinutes=10`，分秒吻合）。
2. **压缩阈值 0.45 的运行时读数**（阈值不外暴露；用首次压缩的触发压力旁证：≈**79%** 生效、≈**95%** 旧默认仍在）。

## 0.5.1 — 2026-10-10（发布收口：让**既有团队**也吃到自治那套 ＋ 判读行自证口径）

**一句话**：0.5.0 那套（工作台摘要 / 角色文本 / 资源读数）此前只对**新建的团队**生效；这一版补上「老团队也能吃到」，并让状态卡自己说清「我判的是哪一类问题」。

### 三段话（用户视角）

**① 按队补挂：老团队不用重建，重启就自动获得工作台摘要。**
0.5.0 的「工作台摘要」是在**建队那一刻**挂上的，所以 10 月 8 日之前建的团队**从来没有**这条推送 —— 协调者只能靠自己想起来去看谁闲着（真机后果：某 worker 12:32 干完就**停摆 87 分钟**，协调者自己承认「我 feeding 失职」）。现在改成**每次插件挂载都按名册检查一遍**：哪个队缺这条注册就补上（幂等、只在缺时写一次、补挂失败不影响挂载）。⇒ **重启一次，老团队也会被推着干活**。

**② `arm-team`：不想等重启，一条命令补。**
`team_link_watch` 新增 `action="arm-team"`：**现任协调者**自己跑一条，就能给自己带的那个队补上工作台摘要（同样幂等；非现任 / 队不在名册 / 现任空缺都会被拒并说明原因，理由按 `policy.writer` 档分别写）。⇒ 给「我现在就要它动起来」的场景一条即刻通道。

**③ 范围界定：状态卡会自己说清「这段读数担保什么」。**
第 ⑧ 段判读行末尾现在**固定**接一句：`（本节只判上下文/预算；宿主工具闸门——如写入自动评审 429——属另一类，见工具报错原文，不在本节口径内。）`
为什么加：真机发生过一次混淆 —— worker 的**写入**被宿主的自动评审配额拦下（原文 `429: 您已达到每周/每月使用上限…2026-10-14 00:27:38 重置`，且报错里写明「工具本体未执行」），而「预算/配额」这个词被拿去解释成「上下文要耗尽」。**两类是不同的东西**：本节只担保前者；混一次就会**既把真事当幻觉、也把真幻觉当真事**。

### 同版内还改了两处

- **巡逻开始兜「晚启动的协调者」**：段注册此前只在「插件挂载那一刻 + 名册写入」两个时机发生；协调者若在挂载时没在跑，它的岗位文本就一直空着。现在**每轮巡逻顺带对齐一次**（纯读名册 + 活代理表，只在有变化时才写进程内注册表）。
- **跨工作区读窗不再看错人**：状态卡的「会话面 / 活性 / 资源」三段此前按**调用方**所在工作区取窗口 —— 你在 A 工作区看 B 工作区的团队时，那三段列的是 **A 的人**。现在优先按**团队自己的 workspace** 取；取不到或宿主不支持时**如实标注**（例如「读窗=调用方工作区 xxx（回退：该队无 workspace 记录）」），并修掉一处「优先支恒不可达」的调用（`listSessions(workspace)` → 宿主真有的 `filterSessions([{kind:"cwd",values:[workspace]}])`）。

### 怎么验证

- 套件：`node host-half.test.mjs` → `ALL PASS / 1466 (failed: 0)`；`node client-half.test.mjs` → `ALL PASS / 310 (failed: 0)`（0.5.0 的 1442 → 1466，+24）。
- 每条新判据都附「修复前必红」的读数（U20–U24 各一组定向变异；两轮独立复核 task-25 / task-27 逐项复现，含程序化逐字比对与禁词指纹）。
- **真机待验（需重启）**：两个既有团队是否自动各补一条 `origin=auto` 注册；协调者是否开始收到摘要（不必等用户催）；判读行是否带范围句。

### 仍未验的两条（承接 0.5.0）

1. **看门狗重挂**的真机证据（需「先有注册 + 再重启」；取证注册 `wd-75e4e35f-…` 已就位）。
2. **压缩阈值 0.45 的运行时读数**（阈值不外暴露；用首次压缩的触发压力旁证：≈**79%** 说明生效、≈**95%** 说明旧默认仍在）。

## 0.5.0 — 2026-10-10（发布收口：团队自治三批 + 一次真机修复）

**一句话**：协调者不再"自己闷头干活"，也不再"不知道 worker 是死是活"；状态卡多了一段，能直接看到每个会话用了多少上下文、跑了多少轮、该不该换人。

### 你会看到的变化（按场景）

| 场景 | 以前 | 现在 |
| --- | --- | --- |
| **协调者开工** | 它可能自己动手写代码、跑命令，要靠人反复纠正「你是管理、不是实施」 | 它的**系统提示里就写着岗位边界**（只管理 / 协调 / 决策 / 评审 / 设计，不实施）；相关工具返回里也会重钉一遍 |
| **worker 干完一轮 or 闲着** | 协调者不知道，没人提醒就不派活、也不并派 | 建队时**自动**挂一条「工作台摘要」：把全队按 **运行中 / 空闲待派 / 刚干完 / 需处置** 四组报给协调者；**它自己正忙也照投**（失联告警那类提醒的忙时抑制不变），同一注册 10 分钟内不重复打扰 |
| **worker 说「预算耗尽」** | 没有读数可核，只能采信 | 状态卡**第 ⑧ 段**给出每个会话的真实读数（窗口 / 压力 / 累计 / 轮次），末尾一句**判读行**——"预算耗尽"这个词**只允许以否定式出现在那一行** |
| **会话跑太久，要不要换人** | 没有判据 | 超过 **100 轮**或 **2 亿 tokens** 的会话会被标 **⚠ 轮换候选**，并给出那句现成命令 —— **只标记，不自动换** |
| **DSH 重启之后** | 看门狗注册变成"哑的"：注册还在，但没人巡逻 | 每次策略挂载后**自动重挂定时器**；过期条目跳过，清扫一路推进到清空 |
| **想彻底关掉这些文本** | 没有开关 | 新增策略键 `sections.{role, resources}`：`role=false` 关角色/宪章文本（工具返回里的重钉一起关），`resources=false` 让资源行在三处全缺 |

### 为什么这么改

> 用户原话（2026-10-08）：「协调者三次被纠正『你只负责管理，不要自己实施』」「worker 报『预算耗尽，实现未动』，而它的实测用量是 131M token / 32 轮」。

三批围绕三件事收口：**职责写进提示**（不靠人反复纠正）、**状态自动播报**（不靠人提醒）、**用量有真值**（不靠 worker 自述）。

### 新依赖两个宿主服务（都做了降级）

- `sessionProjections` —— 资源读数（第 ⑧ 段 / 提示段资源行 / 摘要脚注）
- `agent.ctx.systemPrompt` —— 挂角色与资源文本段

两者都**晚挂取用 + 特征探测**：宿主没有时**零注册 + 一行警告**，功能回退到「工具返回重钉」，**不报错、不影响既有功能**。

### 发布前的真机修复（同版内）

第一次上线后实测发现：状态卡**第 ⑧ 段每一行都读不出数**，全部报 `session.snapshotEvents is not a function`。
根因是我们读投影时传了一个**自己拼的假会话对象**，而宿主只认真会话。已修：只取**活动会话真身**，取不到就如实标「非活动会话」（不再编数）。
**更要紧的是修了测试桩**：桩此前"来者不拒"，所以这个 bug 一路溜到真机（当时 1438 条断言全绿）。现在桩**照宿主的样子挑剔**——同类断层以后进不了套件。

### 怎么验证

- 套件：`node host-half.test.mjs` → `ALL PASS / 1442 (failed: 0)`；`node client-half.test.mjs` → `ALL PASS / 310 (failed: 0)`。
- **真机复跑**：第 ⑧ 段活会话给出真实读数（实测 `压力 45.7%（窗口 1.00M） · 累计 ≈149.22M · 第 48 轮`），非活动会话如实标「非活动会话」。
- 每条新判据都附**变异红相**（"修复前必红"的读数），逐条见 `docs/verification-log.md` 的批 1/2/3、批 4 与「2026-10-10 第二次重启后的复验」各节。

### 仍未验的两条（如实）

1. **看门狗重挂的真机验证**：需要「先有注册 + 再重启」；已注册一条取证用注册（`wd-75e4e35f-…`），等下次自然重启。
2. **压缩阈值 0.45 的运行时读数**：阈值不外暴露，用「首次压缩的触发压力」旁证 —— ≈**79%** 说明 0.45 生效；≈**95%** 说明旧默认仍在。

### DEFECT-5（真机 2026-09-30）：`revive` 复活出来的 worker 第一回合必死——resume 面漏了同一份「能跑起来」的组装时序

> 用户原话：「worker会话重启后报错 —— 处理失败 / 本轮运行失败 prompt variable "{{model}}" has no value for this assembly (section "deployment:persona-prefix") / UNKNOWN」。
>
> **取证链（每条都可复核）**：策略档 `~/.dsh/team-link/policy.json` 的 `recoveries` 行记着团队 `mal-analyze-cli-20260929` 的 worker-1..4 在本机 **12:47:46 / 12:50:28 / 12:50:33 / 12:50:38** 各被 `team_link_recover action=revive` 复活过；四个会话日志（`~/.dsh/sessions/--D-workspace-mal-analyze-cli--/team-link-…-worker-N-…/session.v4.jsonl.zstd`，逐帧解 zstd）里**复活后的第一回合**（turn 14 / 18 / 18 / 22，12:50:54 / :55 / :55 / :55）逐字报同一个错；同一晚**未被 revive 过**的 threat-intel 四条 worker 日志里，这个错 **0 命中**。
>
> **根因（与 DEFECT-1 / DEFECT-3 同一个缺陷类，只是换了一条路径）**：`recoverRevive` 调 `ctx.agents.resume({ resumeSessionId })`，一个键都没多给 —— ① 没有 `agentOptions` ⇒ 复活出来的 agent **没有任何模型选择**，而 `{{model}}` 的唯一来源就是 `context.agent?.options.model`（`dsh-agent-loop:1565`）⇒ 首回合死在 `deployment:persona-prefix`（**DEFECT-3 的机制原样复现，错误文案逐字相同**）；② 没有 `setup` ⇒ **preset 组装源没挂**，而 `standard` preset 正是这具 agent 的**工具面**（`dsh-web-app/presets/standard.patch.yml`：bash / pwsh / fs / jobs / skill / goal / plan-mode / compaction / delegation / web 全在组成里）⇒ **DEFECT-1 的机制**。宿主**自己**的 resume（`dsh-api-session-controller:399-410`，也就是人从侧边栏打开一个会话时走的那条路）给的正是三样：`resumeSessionId` + `agentOptions: agentDefaultModel.currentSelection()` + `setup: composeAgent(presetForObservation(obs)).setup`（存下来的 preset → `agentPresets.mount`）。
>
> **为什么 0.4.2 没拦住**：DEFECT-1 / DEFECT-3 两轮的修复**全部落在 `agents.create` 面**（`buildTeamSessionCreateOptions`），而 revive 走的是 `agents.resume`；更糟的是旧断言把缺陷**钉成了规格** —— `U26 revive` 原本断言 `Object.keys(resumeCalls[0]).length === 1`（**恰好一个键**）。**「会建 ≠ 能用」第三次以同一种形状出现**：同一份模板时序在插件里有两条入口，当时只对齐了一条。

#### ✨ 改了什么

- **新增 `buildTeamSessionResumeOptions(ctx, sessionId)`**（`lib/index.js`）：revive 面按宿主自己那条 resume 路径的时序组装三样 —— ① 模型选择走与 create 面**同一个**解析器（`resolveTeamSessionModelSelection(ctx, {}, sessionId)`；复活面没有调用方可以给 model，所以永远是「两侧都没给」那一支），解析不出来就**拒绝恢复**（fail-closed，与「宁可不建」同口径）；② preset 取**这个会话自己存下来的那一个**（`agent.session.header.agentPreset` —— 宿主 resume 的 `meta` 就是 `structuredClone(handle.header)`），读不到就显式传 `undefined` 交给 `resolve` 按宿主缺省解析（与 create 面「缺省也解析」同口径，**不是**「读不到就不挂」）；③ 模型选择钩子与 create 面**同一个**（`installTeamSessionModelSelection`），挂在复活这具 agent 自己的 setup 上下文上。
- **revive 调用点**改为 `ctx.agents.resume({ resumeSessionId, agentOptions, setup })`；组装失败 ⇒ **零复活、零写入**，报告点名原因、后果与出路。两档失败面**不是同一档**（如实区分）：模型选择解析不出 ⇒ 失败在调用**之前**（`resume` 一次都没被调）；存量 preset 解析不出 ⇒ 失败在 `setup` 里、`resume` 调用**已在飞**并在组装阶段回滚（真工厂是 setup 抛错即回滚发布，不留活代理）。
- **两处有意不降级（如实声明）**：`agentPresets` 服务缺席是**可服务降级**（恰一行具名 warn、复活照常，与 create 面同款）；而**存量 preset 解析不出来**是**显式失败**——绝不静默换成另一支组成源（一个顶着旧名字、跑着别的工具面的会话比一次可读的失败更难查），与 create 面「`preset=` 指了个解析不出来的 id ⇒ 拒绝创建、不静默降级」同口径。
- **一处与宿主的有意偏差（如实声明）**：宿主那条路的 selection 取值器会优先读「会话上次用的模型」（持久化的 request header）；本插件没有「每会话模型」这个概念，这里与 create 面一致地取**当时的缺省**。复活后若缺省已变，模型会跟着缺省走 —— 人设文本与实际路由仍然自洽，这也是本插件在创建时就有一贯的语义。
- **组装器不取 preset 租约**（`acquireScope`）：那是 `dsh-webhook` **create** 时序的一环（解析在前、create 在后，中间窗口要把该 generation 钉住）；resume 的参照物（宿主的 `composeAgent`）不取 —— `mount` 自己 `retain` → `bind` → 释放，窗口内不会漏。照抄 create 的租约只会多造一处「谁在什么时候还」的状态。
- **模型可见描述面同批同步**（revive 对话框的「这一步做什么」＋ `team_link_recover` 的工具描述）：写明 revive 现在会把模型选择与这个会话自己的 preset 组装源一起装上、组装不出来就拒绝恢复。

#### 为什么是这样修

修复的参照物不是「让报错消失」，而是**宿主自己那条 resume 路径**：插件与宿主对同一个会话 id 必须交出同一个「能跑起来的代理」，否则「插件复活」与「人在侧边栏打开」就是两种生命周期。DEFECT-1/3/5 是同一份清单上的同一种失误的三个爆点 —— 每次都是在**另一条入口**上重新漏一遍模板时序；因此这一轮把判据按**入口**钉（create 面已有，resume 面本轮补上），并顺手修了夹具里同款的盲区（见下）。

#### 🔍 代码评审修复轮（同批；1 条技术性驳回，6 条已处置）

- **🟡#1 README 三处读数滞后** → 已同批同步（徽章 / 稳定性行 / §十 当前读数 → **1324**，并把本轮红绿相与 `1324 = 1314 + 10` 的账目写进去；第 2 轮把复活面口径统一后又多一条断言，计数由 1323 改成 1324，同一处同步）。
- **🟡#2 「零 resume」言过其实** → 已按实现事实改写（见上「改了什么」第 2 条）：⑥ 档失败在调用前（零 resume 调用），⑦ 档失败在 `setup` 里（resume 在飞并回滚）；并新增 `DEFECT-5 ⑦ 口径` 断言把两档**分开钉住**。
- **🟡#3 复活面复用了创建面的「出路」** → 已修：`resolveTeamSessionModelSelection` 新增 `face` 参数，复活面用自己的判词与出路（`team_link_recover` 没有 `model=` 参数，「传 model=」那条指路在本工具里**执行不了** —— D8 那轮的裁定），**create 面文案逐字未改**。
- **🟡#4 「人设文本与实际路由自洽」被质疑** → **技术性驳回**（证据）：宿主每起一个 agent 实例时 `requestHeaderLogged` 都是 `false`（`dsh-agent-loop:761`），而 `prepareRequest` 的路由基线取的是 `this.options.provider` / `this.options.model`（同档 `:1167-1178`，持久化 request header 只在 provider/model 相同那一支里贡献 `reasoningEffort`）⇒ **路由 = `options.model` = `{{model}}` 的取值来源**，两者同源；`installTeamSessionModelSelection` 在已有 header 时早返回只是不再抹掉继承来的 effort，它不改路由。**该论断要求的「真机核对一枚缺省 != 上次模型的 worker」仍列为待验项**（见题末）。
- **🔵#5 新断言直取下标可能在 break 时炸套件** → 已修：`DEFECT-5 ②③④` 全部改成先判 `length === 1` 再取下标（与同组 ⑤ 同形）。
- **🔵#6 resume 桩先发布后 setup** → 已修：发布（进注册表 / 解除 hidden / 记进 `resumedAgents`）挪到 `setup` **成功之后**，并在 ⑦ 补「失败后不留活代理」的读数（`agentFor` 为 undefined + `agentIsLive === false`）。
- **🔵#7 create 面只判 `resolve` 就裸调 `mount`** → 已修：组成面守卫改为**双判**（`resolve` + `mount`），形状断层显式点名（两个读数都写进文案）并拒绝创建，不再是裸 `TypeError: agentPresets.mount is not a function`；新增 1 条断言 `组成面（mount 缺失·形状断层）`（夹具加 `omitMount` 开关）。**第 2 轮评审又指出复活面在同一断层上仍走降级**（同一形状断层两个面两种判词）→ 已同批统一：三分法现在是**服务缺席 ⇒ 降级（一行具名 warn）** / **服务在场但形状断层 ⇒ 两个面都显式拒绝** / 两方法都在 ⇒ 正常组装；新增断言 `DEFECT-5 ⑤b` 钉住复活面这一档。
- **第 2 轮评审的另一条 ≤🔵（文档措辞残留）** → 已清：证据账里那句「组装失败 ⇒ 零 resume、零写入」按两档事实重写。

#### 🧪 怎么验证

- **新增 10 条 + 改写 1 条宿主断言（可 grep）**：`U26 revive:`（改写的形状断言）· `DEFECT-5 ①`（resume 恰三键 + `agentOptions` 逐字等于 `currentSelection()`）· `DEFECT-5 ②`（挂的是**它自己存下来的** preset、恰一次、绑在它自己的 setup 上下文上）· `DEFECT-5 ③`（钩子的**行为**读数：同名路由抹掉继承来的 `reasoningEffort`）· `DEFECT-5 ④`（header 无 preset ⇒ 缺省也解析）· `DEFECT-5 ⑤`（服务缺席 ⇒ 降级 + 恰一行具名 warn）· `DEFECT-5 ⑤b`（服务在场但只有一半 ⇒ 与创建面同一句判词：显式拒绝）· `DEFECT-5 ⑥`（模型解析不出 ⇒ 拒绝恢复、零 resume 调用、零写入）· `DEFECT-5 ⑦`（存量 preset 解析不出 ⇒ 显式失败、点名那个 preset、**失败后不留活代理**）· `DEFECT-5 ⑦ 口径`（两档失败面不同：⑥ 零 resume 调用 vs ⑦ resume 在飞并回滚）· `组成面（mount 缺失·形状断层）`（见评审修复轮）。
- **夹具同批修复（这一课的重点）**：`agents.resume` 桩原先用 `options.sessionId` 当 setup 上下文的 `agentId`，而 resume 面**只有** `options.resumeSessionId` ⇒ 复活面上 `agentId` 恒为 `undefined`、桩的 `mount` 按「无 scope」拒绝，**恰好把 DEFECT-5 要钉的那一层挡在套件外**（与 DEFECT-1 那轮「桩只镜像自家实现的调用面」是同一个盲区）；同批两处保真修复：桩的复活 header 从**持久化记录**里取 `agentPreset`，且**发布挪到 `setup` 成功之后**（真工厂是 setup 抛错即回滚发布）——后者让「fail-closed 之后不留活代理」这半条变成可读的读数。
- **红相（实跑）**：`git checkout -- lib/index.js`（夹具不动）⇒ `host 1324 (failed: 11)` —— 恰是改写的 1 条 + 新增的 10 条，其余 1313 条全绿；还原后 `lib/index.js` sha256 `609F9D47A35BE7AFA07B3C6C31CC192E40209B7F86DDF7AFB4F1811E4F7941E0` byte-identical。
- **绿相（实跑）**：`node host-half.test.mjs` → `ALL PASS` / `assertion total: 1324 (failed: 0)`（1313 + 11）；`node client-half.test.mjs` → `ALL PASS` / `assertion total: 310 (failed: 0)`；退出码均 0。
- **真机复验（2026-10-01，重启窗口后）**：① **跑的是修复后的代码**有铁证 —— worker-1 的 `request/header` 事件里内嵌的 `team_link_recover` 工具描述，重启前那次不含本轮新增句、重启后那次（13:52:34）含「真机缺陷 #5」与「resumeSessionId + agentOptions + setup」；② **故障不再复发** —— 四个 worker 日志里该错误的**真失败**（`turn/end{kind=error}`）全部落在重启（13:34:17）**之前**，之后 0 条（之后仍命中该字符串的 8 处均为 `request/header` 内嵌文本，逐条按事件类型核对）；③ 四个 worker 重启后仍在持续跑（末次 `turn/start` 到本机 02:19–02:22），两个团队 5/5 有活代理。**④ 插件 revive 路径已在生产上走通（更正注记）**：`mal-analyze-cli-20260929` 那四个 worker 确实不是插件带回来的（协调者 13:50:19 连发的四次 revive 都被「该角色的现任……**有活动代理**」拒绝，它们由宿主自己的 resume 路径带回来）—— 但**同一台机器、同一次重启之后**，团队 `0930-threatintel` 的协调者用 `team_link_recover action=revive` **成功复活了 worker-1**：审计行落在 `2026-09-30T05:38:19.847Z`（本机 13:38:19，晚于 boot 13:34:17 ⇒ 执行者是修复后的代码），复活后 `request/header`（13:39:57，`reason=resume`）内嵌的工具描述含「真机缺陷 #5」；该会话 revive 之后的 14 个 `turn/end` **全部 `kind=completed`**（末个本机 03:39），整份日志里那类真失败 **0 条**。**仍未取得的那一格（不冒充）**：反事实（不带 `agentOptions` 时这批会话会不会死）无法在真机直接观测，那一层由套件的 `DEFECT-5 ①/③` 与修复前那四条错误原文共同支撑；🔵#4 登记的「缺省 ≠ 上次用的模型」那枚 worker 仍待验（已取 `0930-threatintel/worker-1` 复活前后 header 均为 `deepseek-official/deepseek-flash` ⇒ **同值、区分不了**，不冒充已验）。

## 0.4.2 — 2026-09-29（发布收口：DSH 0.2.0-rc.1 两处运行时换代断层 ＋ preset 租约释放 ＋ 客户端团队面板可读性重设计）

> 本版一次性收口下列 **3 个「未发布」条目**；package.json 已 bump 到 **0.4.2**。上一版为 **0.4.1（2026-09-29）**。
>
> 三条都来自同一天的真机反馈，且是同一条链：0.4.1 让插件在 0.2.0-rc.1 上**装得上**（peer 装载闸门），本版让它**用得了**（preset pin API 换代），并顺手把租约**还干净**（`acquireScope` 是租约，不是可以丢掉的返回值）；第三条来自 owner 对团队面板可读性的截图反馈。

### DSH 0.2.0-rc.1 宿主 API 换代：preset pin `standingKeyFor` → `acquireScope`（2026-09-29）

> 同一天的第二处 0.2.0-rc.1 换代断层：上午的 peer 区间闸门（0.4.1）让插件**装得上**，这一处让它**用得了** `/team_session`。真机两次失败（15:35:40 / 15:46:18，团队 mal-analyze-cli-20260929，`n=4 准备接手继续开发`）：回执「批量建队未全部成功」，命令输出逐字 `未创建（创建失败（agentPresets.standingKeyFor is not a function））`，worker-2/3/4 按失败即停未尝试、团队零落地（无 roster / 无黑板 / 无会话目录，仅两张 5 分钟 TTL 的 pendingCreate 孤儿票据由过期清扫自理）。取证链：调用方会话日志 `team_link_export` 取 `command/done` 原文 → 宿主 `app.asar` 文本检索 `standingKeyFor` **零命中**、官方模板同一时序已是 `acquireScope`（注册面签名 `async acquireScope(id?): Promise<{ key: ScopeKey } & AsyncDisposable>`）。

#### ✨ 改了什么

`lib/index.js` 的 `buildTeamSessionCreateOptions`（`/team_session` 与 `successor:"auto"` 共用的唯一创建路径）：pin preset 的调用改为**双代兼容**——`acquireScope` 在场优先现名；否则回退 `standingKeyFor`（0.1.x 宿主）；两个都没有 ⇒ 抛**显式**错误（点名两代已知形状与断层），批次报可行动的原因，不再让裸 TypeError 当错误文案。返回的 scope 沿既有形状只确认「取得到」、不提前 dispose（提前释放可能把仍在运行会话的 standing 组成拆掉）。改动面 = 1 个实现文件 + 宿主测试套件（夹具与断言）。

#### 为什么是兼容而不是只改成新名

peer 区间仍声明支持 `^0.1.0-rc.6 || ^0.1.5-rc.1`（0.4.1 的立场：老宿主装得上），运行时却只认新名会把「装得上」变成「一建队就死」——同一份声明两种真相。回退分支正是给还停在 0.1.x 的宿主的。

#### 🧪 怎么验证

- **夹具换代**：`makeAgentPresets` 默认建模 0.2.0-rc.1 真机形状（只有 `acquireScope`），新增 `pinSurface` 开关（`current` / `legacy` / `both` / `none`）＋ `setup` / `teamSessionEnv` 的 `agentPresetsOptions` 透传；`standings` 仍是两代合流的同一读数，DEFECT-1 既有断言口径不变。
- **新增 4 条宿主断言**：现名成立（旧名零调用、preset 绑定判据不变）/ 两名都在只走现名 / 只有旧名回退成立 / 双缺 ⇒ 显式点名（含两个方法名、零创建零 pairs、无 `is not a function`）。
- **变异验证（红相实跑）**：夹具先改、实现未动时套件以**真机同款文案**崩——多条 FAIL 后中止于 U16 端到端（`okEnv.store()[0]` undefined＝团队零落地的直接后果），可见逐字相同的 `创建失败（agentPresets.standingKeyFor is not a function）`；套件中止故未取得完整 failed 计数（自报计数只在结尾打印，如实登记）。
- **绿相（实跑）**：`node host-half.test.mjs` → `ALL PASS` / `assertion total: 1310 (failed: 0)`（1306 + 4，退出码 0）；`node client-half.test.mjs` → `ALL PASS` / `assertion total: 305 (failed: 0)`（退出码 0）。
- **真机待验（如实登记）**：插件代码随 DSH boot 加载，修复需**重启 DSH** 后由用户重发 `/team_session` 闭环；本轮真机验到的只有故障面本身（两次失败的完整输出）。

### preset 租约补丁：`acquireScope` 不是可以丢掉的返回值（2026-09-29，同批评审发现）

> 上面那条把 pin 调用改成了「双代兼容 ＋ 双缺显式报错」，方向对，但漏了一层：**`acquireScope` 不是 `standingKeyFor` 的纯改名**。宿主注册面的实现是 `retain(id)` ＋ 一个 `[Symbol.asyncDispose]` 句柄（`users--` ＋ `collect()`），文档原话「**A revision lease; dispose it after the scoped read completes**」；官方模板 `dsh-webhook` 是 `await using` 取（`lib/index.js:158`）、在 `finally` 释放（`:216`）。原修复 `await agentPresets.acquireScope(preset.id);` 把返回值丢掉、永不释放 ⇒ **每建一个会话泄一个租约**（该 generation 的 `users` 永不归零、`collect()` 永不执行）。原注释那句「宿主按会话生命周期持有、不提前 dispose」与宿主自己的文档和官方模板都相反，是补出来的理由。

- **修法**：照官方模板同一时序 —— 构建器只**取**，把可释放句柄经 Symbol 带外通道（`PRESET_SCOPE_RELEASE`）随 options 交给调用方；`createRootAgent` 在 `agents.create` 的 `finally` 里释放（`setup` 里那次 `mount` 在 create **期间**跑，租约必须活到那一刻）。释放失败只留一行 warn，绝不覆盖 create 的原始错误。旧代（`standingKeyFor` 返回纯值）**不伪造** dispose。Symbol 对宿主 `create` 不可见（它只读具名键）、对 `Object.keys` / 展开 / `JSON.stringify` 也不可见 ⇒ options 的**可见形状**与既有断言一字不变。
- **夹具同步（这一课的重点）**：桩的 `acquireScope` 原先只返回 `{ key }` —— **只镜像自家实现的调用面**，于是「永不释放」这层缺陷被永久挡在套件外（与上一轮「桩里只有自家在调的方法名」是同一个盲区，只是这次挡的是泄漏）。现在连句柄一起建模（`[Symbol.asyncDispose]` ＋ `released` 读数）。
- **新增 4 条宿主断言**：租约必须释放（取 N 次 ⇒ 还 N 次）/ 失败路径也还（`finally` 不是「建成功了才还」）/ 旧代不伪造释放 / 句柄幂等（★ 控制项，证明「恰好一次」不是靠重复计数凑的）。
- **变异验证（实测红 → 绿）**：摘掉调用方的释放（＝只改名不还租约）⇒ `FAIL pin 换代（租约必须释放）` ＋ `FAIL pin 换代（失败也要还）`，`host 1314 (failed: 2)`；另 2 条在两种状态下都该绿（旧代形状 / 幂等控制项），**如实记，不冒充 4/4**。还原后 sha256 `D078611F…` byte-identical；绿相 `host 1314 (failed: 0)`。

### 客户端团队面板可读性重设计：默认折叠 ＋ 高度上限 ＋ 层级（2026-09-29，owner 截图反馈）

> owner 原话：「超长文字弹窗超长，而且文字太密集太多根本不知道应该看哪里」。诊断（本地视觉夹具 ＋ 视觉桥独立复核）：不是没渲染，是**信息架构**——五段默认全展开、段标题与正文同为 12px、面板无高度上限（弹窗跟着长）、三行角色文本每行 ~120 字还把同一串 session id 写了两遍。

- **改了什么**（`lib/client.js`，纯呈现，**不解析任何宿主字节**）：面板加高度上限 ＋ 内部滚动；段标题升到 13px/600、独立一行、带 `▾` 标记并可点开合（`h3` ＋ `role="button"` ＋ `aria-expanded` ＋ Enter/Space）；**默认全部折叠**——这一屏先当索引用（`data-collapsed` ＋ 一条 CSS 规则，节点全在树里，只是不显示）；段间加分隔线；结论行加左侧色条；缺数段不折叠（藏起来等于把「这一段读不到」也藏了）。
- **读数**（本地视觉夹具，真实 payload，452px 宽）：弹窗 **941px → 406px**（展开态最多 425px）；**5 个板块标题一屏全可见**（改前只有 2 个）；面板 205px、无需滚动。视觉桥改前判「非常拥挤、有密集文字墙」，改后判「**没有密集文字墙，界面非常简洁**，5 个板块一眼列全」。
- **变异验证（实测红 → 绿）**：新增 **5** 条客户端断言（高度上限 / 段标题字号严格大于正文 / 默认全折叠 / 点标题即展开且展开前后 `panelLines` 逐字相同 / 缺数段不折叠）；换回修复前实现 ⇒ `client 310 (failed: 5)`，**五条全红且套件跑完不崩**（首版判据在旧实现上抛 `TypeError` 把套件炸在半路、只报 3 条 —— 正是 `client-half.test.mjs:32-42` 那条 Y7 纪律的坑，已给判据加兜底）。还原后 sha256 byte-identical；绿相 `client 310 (failed: 0)`。
- **已知剩余（如实登记）**：展开「团队与角色」后三行角色文本仍长（宿主给的字节，同一个 session id 出现两次；客户端不得重写）—— 要治得改宿主的行渲染，会同时影响 `team_link_status` 的工具输出，**不在本版**。

## 0.4.1 — 2026-09-29（发布收口：DSH 0.2.0-rc.1 兼容性闸门 ＋ 部署接线改 `link:` ＋ 策略持久化自持化 ＋ C 批客户端团队面板与形态可视化 ＋ 六轮代码评审/分歧审计修复）

> 本版一次性收口下列 **10 个「未发布」条目**（开发期累积、按时间倒序）；package.json 已 bump 到 **0.4.1**。上一版为 **0.4.0（2026-09-27）**。
>
> **宿主版本支持**：本版声明并实测 **DSH 0.2.0-rc.1**；peer 区间同时保留 `^0.1.0-rc.6 || ^0.1.5-rc.1` 两个历史分支（累加，不撤），故 0.1.x 宿主**仍能通过闸门**——但本版实现相对 0.4.0 有实质改动，而**只在 0.2.0-rc.1 上实测过**。支持矩阵与「低于 0.2.0-rc.1 怎么办」见 [`README.md`](README.md) 的「宿主版本支持」一节。

### DSH 0.2.0-rc.1 兼容性闸门：peer 区间补 `^0.2.0-rc.1`（2026-09-29）

> 桌面版 2026-09-29 自动升级到 **0.2.0-rc.1**，本插件当天**整个没被加载**：工具凭空消失、插件页零提示。根因不在插件代码，而在 `package.json` 的 peer 区间没跟上宿主换代。**改动面 = 1 个清单文件（`package.json`）＋ 文档（本文件 / [`docs/verification-log.md`](docs/verification-log.md) / `README.md` 依赖声明一节）；实现文件零改动。** 账本见同档的「2026-09-29 DSH 0.2.0-rc.1 兼容性闸门」一节。

### ✨ 改了什么

`package.json` 里 7 个 `@deepseek-ai/dsh-*` peer 的区间由 `^0.1.0-rc.6 || ^0.1.5-rc.1` 补为 `^0.1.0-rc.6 || ^0.1.5-rc.1 || ^0.2.0-rc.1`。`@deepseek-ai/cordis` **不动**：0.2.0-rc.1 里是 4.0.4，仍满足 `^4.0.1`，且闸门只查 `@deepseek-ai/dsh` / `@deepseek-ai/dsh-*` 名下的 peer。

**为什么是「整个没加载」而不是「报个 peer 警告」**：`dsh-desktop-host` 启动时用 `loadProfileDirectory()` 对 `dsh.profile.bundles` 里每个包跑 `@deepseek-ai/dsh-app-boot` 的 `evaluatePluginCompatibility()`；任一条 `@deepseek-ai/dsh*` peer 不满足 `semver.satisfies(运行时版本, 区间, { includePrerelease: true })` 就 `throw`，被同文件的 `catch` 吞掉后推入 `skippedBundles` ⇒ **该 bundle 的 patch 层完全不参与组合**（`layers.push` 在闸门之后），`cordis.patch.yml` 那条 `- id: team-link` 于是指向一个从未存在的 entry。这个跳过只经 `reportSkippedBundles()` 往宿主 stderr 打一行，而桌面壳只把宿主 stderr 留在内存里（64 KiB 环形缓冲），**仅在宿主异常退出时**才随崩溃报告落盘 ⇒ 用户侧零提示。

### 🧪 怎么验证

- **修复前（闸门复刻，实跑）**：逐字复刻 `@deepseek-ai/dsh-app-boot/lib/index.js` 的 `evaluatePluginCompatibility()`，运行时版本取 app-boot 自己的 `0.2.0-rc.1`，semver 用 profile 那份 —— `dsh-team-link@0.4.0` 落在 **SKIPPED**，理由 `peerDependencies {"@deepseek-ai/dsh-tools":"^0.1.0-rc.6 || ^0.1.5-rc.1", …}`（7 条）。
- **修复后（同一脚本，实跑）**：`dsh-team-link` 移到 **PASSED**；SKIPPED 由 **14 → 10**（其中 1 个是本条，另 3 个是 `dsh-better-sidebar` 0.24.1 / `dsh-config-manager` 0.1.66 / `dshmarket` 1.66.5 在本轮期间各自更新到 0.2.0 就绪版，与本条无关）。
- **semver 判据本身**：`semver.satisfies('0.1.7-rc.2', '^0.1.0-rc.6 || ^0.1.5-rc.1', { includePrerelease: true })` → `true`（所以旧宿主上一直是好的）；同一区间对 `'0.2.0-rc.1'` → `false`。
- **套件（实跑）**：`node host-half.test.mjs` → `ALL PASS` / `assertion total: 1306 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS` / `assertion total: 305 (failed: 0)`（退出码 0）。**断言总数不变**（本轮不新增断言，故 README §十 的两处读数不动）。
- **0.2.0-rc.1 上的兼容性复核（静态，逐项对源码行）**：四项硬注入服务全在 —— `tools`（`dsh-tools/lib/index.js:2704`；`register()` `:2878`）· `sessionQuery`（`dsh-session-query/lib/index.js:1046`；`listSessions` `:1070` / `readSession` `:1079` / `filterSessions` `:1094` / `readTitleSnapshots` `:1127` / `readSurface` `:1166`）· `sessionReferenceResolver`（`dsh-session-reference/lib/index.js:440`；`prepare(agent, content, references, signal)` `:606`，与调用点逐字同形）· `agents`（`dsh-agent/lib/index.js:332`；`create` `:451` / `resume` `:464` / `get` `:594` / `list` `:612` / `roots` `:621`）；晚挂服务同样在场（`settings` / `goals` / `webServer` / `connection` ＋ `requestRejection` / `workspaceRegistry` / `systemPrompt` / `agentDefaultModel`）；过滤描述符形状未变（`case "id": filter.values.includes(record.header.id)`，`dsh-session-query/lib/index.js:753`）。
- **真机读数（重启后，实调 —— 本节唯一一处非静态证据）**：DSH 以 0.2.0-rc.1 重启后，只读工具 `team_link_status` 成功返回整张状态卡（读数时点 **2026-09-29 15:01:24**）：**首行**是三态之一的 `存储：文件 C:\Users\huangchaowen\.dsh\team-link\policy.json`，名册读回 `threat-intel` 的 3 个角色（coordinator / worker-a / worker-b，与 2026-09-28 01:04 的登记一致），形态段读出 `形态=sessions`，宿主 `agentTeams` 投影可读 ⇒ **工具面回归 = 修复生效**（bundle 被跳过时工具根本不在表里，调不到）。
- **未做（如实登记）**：未 commit、未留临时文件；**客户端半边（侧栏团队面板）未做真机 DOM 冒烟** —— 本次验到的是宿主工具面。

### C 批代码评审修复轮：🟡#1/#2 ＋ 🔵#3/#4/#5/#6（2026-09-27）

> C 批交付**代码评审**（结论 **PASS、零 🔴**；6 条 = 2 🟡 ＋ 4 🔵）的逐条收口。**只闭环这 6 条，不夹带**：改动面 = 2 个实现文件（`lib/index.js` / `lib/client.js`）＋ 2 个套件（新增 **12** 条断言 —— host 6 / client 6）＋ 文档（本文件 / [`docs/verification-log.md`](docs/verification-log.md) / [`docs/client-panel-batch-design-2026-09-27.md`](docs/client-panel-batch-design-2026-09-27.md) §9 / `README.md` 的三处读数 —— 见下「同批文档」）。账本见同档的「C 批代码评审修复轮」一节。

### ✨ 改了什么

**🟡#1 面板的 13 个 `.dshsl-pn-*` 类此前一条 CSS 规则都没有**（正是本仓自己定性的「a class with no rule is appearance by luck, not by contract」，此前为 `.dshsl-st` / `.dshsl-st-label` 补过一次）。
实际后果不是外观洁癖：台账行与角色行是宿主渲染好的**多空格缩进**字节（`"    " + row` 的台账行、`teamRoleLines` 的四空格角色行），落在没有 `white-space:pre-wrap` 的 `<p>` 上会被浏览器折叠成一句话 ⇒ 直接削弱 R1「一屏可读」。
**修法**：`lib/client.js` 样式数组末尾补一组 `.dshsl-pn-*` 规则（13 个类各有规则；`.dshsl-pn-line` / `.dshsl-pn-placement` 给 `white-space:pre-wrap`，徽标与段落间距照 `.dshsl-relay*` 的既有做法）＋ **一条源码级对照判据**（`className:` 里出现的每一个 `dshsl-pn` 类都必须能在样式块里按选择器找到规则；两侧集合都要非空，防止「两边都空所以相等」）。徽标**只给一条规则、不按 `data-badge` 的值分色** —— 三态的区别由宿主给的标签文字承担，把宿主那一层的档位词汇写进 `lib/client.js` 会踩 W4 那条源码级代理锁（「客户端自己一个档位词都没有」）。

**🟡#2 「读更多」翻页在第二页起回卷。** 旧实现取 `firstUnread = shown.findIndex(!read.ids.has(id))` —— 第二页（`offset=12`）的第 0 行永远不在本页读窗里 ⇒ `nextOffset = 0` ⇒ 客户端唯一的翻页控件指回第一页（13–24 个会话两页循环；>24 个时第 25 行起在 UI 上不可达，客户端没有手输 offset 的口子）。
**修法**：`lib/index.js` 的 `sessionSegment.page.nextOffset` 改为「**当前页之后**」—— `windowEnd = 本页 offset + 本页读窗行数`，`windowEnd >= shown.length` 时置 **null**（客户端隐藏按钮）。列表工具段尾那句 `listReadTail` **一字未动**（它是提示不是载荷，且与工具面同源）。

**🔵#3 降级句在分页路径上不准。** `PANEL_LV_WINDOW_NOTE` 写死「本面板只读了前 12 行」，而 `offset=12` 那一页读的是 13–24 行 ⇒ 那句降级句与实况相反。
**修法**：新增 `panelWindowNote(offset)` —— 第一页逐字复用原常量（第一页字节一个都不动），分页那一页换成点名**本次这一页**的措辞（「本面板本次只读了 12 行，从第 13 行起」）。

**🔵#4 多团队时派生读数失去归属。** `tasksDerivedLines()` 的行原先被顺序拼进 `payload.tasksTail.derived`，**一个团队名都不带**（对照同一段 `- <team>/tasks.md：…` 的三处头）⇒ 两支队伍的「最后主张 / 未消解存疑」在面板上分不出谁是谁。
**修法**：新增 `teamDerivedLines(teamName, derivedLines)` —— 块首带 `- <team>/tasks.md：` 归属头、续行四空格缩进（与同段台账尾的排版同形）；**行体逐字仍是 `tasksDerivedLines()` 的字节**，面板一个字节都不改写。原有 W6「逐字同形」判据因此**改紧**：剥掉面板自己那一层归属头之后，行体仍必须逐字出现在 `team_read` 的输出里。

**🔵#5 面板行直入 DOM，没过 `wellFormed()`。** 落点行与段行直接 `createElement`，绕过了本仓对**孤立代理对**的整条纪律（§8 字符串安全）—— 卡片、发送行、纯文本行都过，面板不该是新缺口。
**修法**：面板的**每一个宿主字符串出口**都过 `wellFormed()`：落点行 / 段行 / 档位结论 / 徽标标签 / 台账尾 / 派生行 / 会话行 / 段尾 / 缺段句 / 整页降级句（后两处会回显宿主的 reason / error 字段）。判据用**半对代理**（孤立高代理、孤立低代理各一处）打进八处字节，断言渲染出的**每一段**文本都不含孤立代理项。

**🔵#6 面板子树里缺 React `key`。** 评审点名 5 处（`placement` / `fail` / `loading` / `refresh` / `more`，`lib/client.js` as-of 修复前 `:2214` / `:2216` / `:2218` / `:2220` / `:2228`）。
**修法**：补齐这 5 处，并**同一缺陷类**余下的 5 处一并补齐（段标题 `h3`、缺段句、档位结论、徽标 `span`、面板根 `div` —— 它们同属数组子节点，React 对每一个都会报「unique key」）⇒ 判据写成「**整棵面板子树 key 完备**」，比点名的 5 处更紧。评审给的 5 处与同一缺陷类的余下 5 处都在交付报告里点名列清，不当作夹带。

### 🧪 怎么验证

- **起点读数（实跑）**：`node host-half.test.mjs` → `ALL PASS` / `assertion total: 1300 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS` / `assertion total: 299 (failed: 0)`（退出码 0）。
- **红相（判据先写、实现后到，实跑）**：`node host-half.test.mjs` → `5 FAILURE(S)` / `assertion total: 1306 (failed: 5)`（退出码 1）—— 红的是 🟡#2 翻页不回卷 · 🟡#2 ★ 负相末页 · 🔵#3 降级句随页走 · 🔵#4 派生行带团队归属 · 🔵#4 归属头只是加的那一层；`node client-half.test.mjs` → `4 FAILURE(S)` / `assertion total: 305 (failed: 4)`（退出码 1）—— 红的是 🟡#1 类名↔规则 · 🟡#1 `pre-wrap` · 🔵#6 key 完备 · 🔵#5 `wellFormed`。
  **如实分解（不冒充红相）**：本轮 12 条新判据里 **9 条实测红**，另 **3 条是控制 / 对照项（★ 负相，本就绿）**：🔵#6 的 walker 控制项与 🔵#5 的「没有孤立代理项时逐字原样」对照项在修复前即绿；🟡#2 那条「沿**按钮链**走到第 25 行起」的判据是**实现之后补强**的（首跑红相里它还是旧版「三页读窗并集」形态、首跑即绿），**未取得红相读数，如实标注**。
- **绿相（实现后，实跑）**：`node host-half.test.mjs` → `ALL PASS` / `assertion total: 1306 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS` / `assertion total: 305 (failed: 0)`（退出码 0）。
- **本轮的断言账**：host `1306 = 1300 + 6`；client `305 = 299 + 6`。
- **同批文档**：`docs/verification-log.md`（本轮一节：起点/红/绿读数 ＋ 6 条闭环表 ＋ 同批文档）· `docs/client-panel-batch-design-2026-09-27.md`（W8 行读数 ＋ 新增 §9 本轮一节）· `README.md`（tests 徽章 / 稳定性格 / §十「当前读数」三处读数 `1300 → 1306`、`299 → 305`）· 本文件。
- **未做（如实登记）**：**未做真机 DOM 冒烟**（🔵#1 / 🔵#5 / 🔵#6 三条里，只有 🔵#1 的「类名 ↔ 规则」是源码级判据、🔵#5 / 🔵#6 判据走的是 stub 树；浏览器里的实际排版与 React「unique key」警告没有实测）；未重启、未 commit、未留临时文件。

---

### C 批分歧审计修复轮：🔵#2/#3/#4/#5（2026-09-27）

> C 批分歧审计（只读，审计 **0 🔴** / 4 条 🔵）的逐条收口。**只收这 4 条，别处一字不动**：改动面 = **1 条新判据** ＋ `agentStateLabel` 的「行为修正」标记与判据面（`__testing` 导出）＋ 文档四处（计数 / 口径 / 回填 / 声称）。设计档 = [`docs/client-panel-batch-design-2026-09-27.md`](docs/client-panel-batch-design-2026-09-27.md)；账本见 [`docs/verification-log.md`](docs/verification-log.md) 的「C 批分歧审计修复轮」一节。

### ✨ 改了什么

**① 🔵#2 账本「计数与列表不一致」。** C 批小节写「**三处**段体渲染器收敛为一处」，紧随其后却列了**六个**（`agentStateLabel` / `sessionFaceLine` / `teamRoleLines` / `pendingLines` / `watchdogLines` / `tasksDerivedLines`）—— 代码侧改写点确为 **6 处**。标题与正文同一次编辑改成「**六处**」。

**② 🔵#3 「4 条 🔵」与「3 条 🔵」同批并存。** 设计档**五处**写「4 条」（`:1` 标题 / `:3` 一句话 / `:105` §5 标题 / `:116` §6 分期 / `:131` §7.1，as-of 修复前），README / CHANGELOG / 账本写「3 条（C3-a/b/c）」，而设计档 §5 正文自己说 ① 已在上一批修完。口径统一为「**登记 4 条 / 本批执行 3 条（① 已在上一批修完）**」：设计档（标题 / §1 一句话 / §5 标题 / §6 分期 / §7.1）、README（§十「当前读数」与设计索引行）、CHANGELOG（本标题与 C 批 ④ 的标题）与账本标题同改。

**③ 🔵#4 设计 §8 第 2 问仍是问句，而代码已作答。** 面板的台账尾恒取 `rows.slice(-STATUS_TASKS_TAIL_DEFAULT)`（as-of 本轮 `lib/index.js:11313`，常量在同档 `:140` ＝ **5**），而面板路由只收 `session` / `offset` 两个参数（`:11519–11531`，**不收** `tasksTail`）⇒ **面板 = 状态卡的 5（同值）**。已回填进设计档 §8 第 2 问，并让「（已定）」这个标题与两问都已回填这一事实对齐（标题改为「**两问均已回填**」）。

**④ 🔵#5 「收敛后输出逐字不变」在 `agent === null` 一格不成立 —— 两件都做。**
**a) 补 null 判据（先红后绿）：** `host-half.test.mjs` 新增 **1** 条 —— 状态词对三种输入逐字（已定义 running / idle 与 `undefined` 保持原样，`null` ＝ 「✕ 未运行」），且「**行为修正**」这句标记钉在 `agentStateLabel` **自己的源码块**里（否则它只是一句无法复核的散文）。为了让判据读**真函数**而不是抄一份复制品，`__testing` 开放 `agentStateLabel`（纯函数，模型可见面一个字未变）。
**b) 标为行为修正 ＋ 把声称收窄：** `null` 一档**不是**静默漂移，是修正 —— 收敛前列表工具写 `running ? "▶ 运行中" : agent !== undefined ? "○ 空闲" : "✕ 未运行"`（`null` ⇒ 「○ 空闲」），状态卡那一份写 `agent === undefined ? … : agent.status === …`（`null` ⇒ 直接抛）；收敛后两种「没有这个代理」统一判「✕ 未运行」。账本那句「输出逐字不变」收窄为「**对 `ctx.agents.get` 实际会产生的输入（已定义 / `undefined`）逐字不变**；`null` 一档由旧码的『○ 空闲』改判为更正确的『✕ 未运行』」，`lib/index.js` 的 `agentStateLabel()` 注释里同批写下这四个字。

**⑤ 顺带登记（本批不做）：** 审计观察 ③（`tasksTail` 的两种「不可读」只降级到 lines 文本、`present` 仍 `true` 且无断言覆盖 —— 若将来给客户端结构化降级信号，那两支应改 `present: false`）记入设计档 **§8.1 后续项登记**；同处**新登记**一条本轮核实到的收敛残渣（列表工具里 `const running = …` 已是死局部，as-of 本轮 `:10826`，只登记不动手）。

### 🧪 怎么验证

- **起点读数（实跑）**：`node host-half.test.mjs` → `assertion total: 1299 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `assertion total: 299 (failed: 0)`（退出码 0）。
- **红相（判据先写、实现后到，实跑）**：`node host-half.test.mjs` → `1 FAILURE(S)` / `assertion total: 1300 (failed: 1)`（退出码 1），红的恰是 🔵#5 那一条。**如实分解（不冒充红相）**：该条的**行为半**在修复前**已经成立**（`agentStateLabel` 本就含 `null` 分支 ⇒ ★ 负相），真红的是另外两半 —— `typeof __testing.agentStateLabel` 为 `undefined`（**判据面**缺席）与源码块里没有「行为修正」**标记**；两半都在实现后转绿。
- **绿相（实现后，实跑）**：host `ALL PASS` / `1300 (failed: 0)`（退出码 0）；client `ALL PASS` / `299 (failed: 0)`（退出码 0）。
- **同批文档**：`docs/verification-log.md`（C 批小节的计数与口径 ＋ 🔵#5 的声称收窄 ＋ 新增本轮一节）· `README.md`（tests 徽章 / 稳定性格 / §十「当前读数」三处读数 `1299 → 1300`、设计索引行口径）· 设计档（口径**五处** ＋ W8 行的当前读数 ＋ §8 回填 ＋ §8.1 后续项登记）· 本文件。
- **未做（如实登记）**：`docs/policy-persistence-design-2026-09-27.md` 不在本批的可改文件清单内（父侧刚改完）—— 一字未动。

---

### C 批：客户端团队面板（跨半边取数通道）＋ 形态可视化 ＋ 🔵 登记 4 条 / 本批执行 3 条（① 已在上一批修完）（2026-09-27）

> 设计档 = [`docs/client-panel-batch-design-2026-09-27.md`](docs/client-panel-batch-design-2026-09-27.md)（评审 PASS）。本批**首次动客户端半边**：判据 W1–W9 ＋ C3-a/b/c；实现 2 个文件（`lib/index.js` 新增只读路由与面板载荷、`lib/client.js` 新增面板分区），新增断言 **65 条**（host +35 / client +30），另**改写既有期望值 4 条**（host 3 条路由计数断言、client 1 条段落类序断言 —— 都是「新增了一条路由/一个分区」逼出来的，断言本身照旧严格），**文档 5 个文件**（见下「同批文档」）。账本见 [`docs/verification-log.md`](docs/verification-log.md) 末节。

### ✨ 改了什么

**① 跨半边取数通道：`GET /team-link/panel`（只读，与导出路由同一道栅栏）。** 面板在浏览器半边、六段数据全在宿主半边 —— 此前 README §二 明确记着「本插件浏览器半边**没有任何跨半边取数通道**」（这正是状态点只做两态的原因）。通道其实一直在：`GET /team-link/export` 就是它。本批把**读路由**收成一对、**共用同一套门**：挂载期要 `webServer` ＋ `connection` 成对在场（缺一即一条路由都不注册），请求期一律先问 `connection.requestRejection`（无 token ⇒ 401 / Host-Origin 不符 ⇒ 403，裁决原样写回），**仅 GET**（其余 405 + `allow: GET`），被拒时**零数据外泄**（连一次 surface 读都不发生）。

**② 面板分区（六段只读 ＋ 落点行）：宿主渲染、客户端只显示。** 面板是**既有侧栏「会话工具」入口**里的一个分区（**不新造 Modal、不新造入口** —— 宿主 Modal 有独占交互契约），排在会话列表之后、底部之前。响应 `{ placementLine, form, teams, pending, watchdogs, tasksTail, sessions }`，每段是 `{ present, lines, unavailable? }`：**落点行**取 `policy.placementLine()`（与 roster / status 两个读面**同一个函数**）、**台账派生读数**取 `tasksDerivedLines()`（与 `team_link_team_read` **同一份字节**）、**活性 verdict** 取 `livenessLine()` —— 「同源」由构造保证，客户端一个字段都不重算。**一次渲染 = 一次路由调用**（与工具面同一个「≤12 次面读」不变量），只在打开 / 手动刷新时拉，**不轮询**（无定时器）。**降级（R4）**：整条路由不可用 ⇒ 面板照常打开并显示「⚠ 面板数据不可用：<原因>」；单段取不到 ⇒ 该段 `present:false` ＋ `unavailable.reason`。**零写（W9）**：读路径走状态卡那一套 ＋ 纯派生扫描，**绝不**调用 `team_read` 的惰性清扫（那条会清 pending、删过期 provisional）—— 夹具里带着**已过期**的换届令牌与**已过期**的 provisional 配对，渲染前后 `policy.json` 字节与 mtime 均不变。

**③ 形态可视化（C2）：三态徽标 ＋ 段顶档位结论，投影读不到「不冒充」。** 每个会话格一枚徽标：`agent-team·Lead`（取自 settings 的 Lead 指针 —— 与宿主投影**无关**，投影缺席时这一格照给）· `agent-team·成员`（取自宿主 `agentTeams` 投影）· `多会话`（投影**可读**且两处都不是 —— 这是读数，不是默认值）；投影**读不到**时给第四态 `档位未判定（成员名册读不到：<原因>）`，**绝不**写成「多会话」（把一个没读到的名册写成「不是成员」正是设计档禁止的编造）。「团队与角色」段顶部一句**档位结论**，措辞**复用** `TEAM_MODE_CONCLUSION`（「单会话兜底档」那句，同一个常量）。**不改**宿主会话列表 UI。

**④ 🔵 收尾：登记 4 条 / 本批执行 3 条（C3-a/b/c；① 已在上一批修完）。** **a) 快路径归档留痕条件化**：`adoptMemoryWindow` 的归档原本在 `update()` **之前**，于是「快路径 ＋ fold failed」会先留下一句「随后文件会被改写成合并结果并盖 foldedAt」，而那一支的链尾**根本不回写** —— 承诺与实况相反，还多一份冗余归档。现在归档挪到**折叠成功之后**（`archiveMergedFile`）：没有折叠落定就没有归档、也没有那句承诺；文件逐字节不变（无数据丢失）。归档本身永不抛（自己的 `try/catch`），所以挪位不会把一次已落定的折叠误报成 `fold failed`。**b)** 补「**快路径 ＋ fold failed**」夹具（此前只覆盖晚挂路径）：文件逐字节不变 ＋ `foldedAt` 不重盖 ＋ 归档数与留痕一致且都必须为 0。**c)** `host-half.test.mjs` 的 `setup()` 形参从一整行 1109 字符改为一行一个（纯排版，行为一字未动）。

### 🧪 怎么验证

- **红相（实现前，实跑）**：`node host-half.test.mjs` → `23 FAILURE(S)` / `assertion total: 1290 (failed: 23)`；`node client-half.test.mjs` → `4 FAILURE(S)` / `assertion total: 275 (failed: 4)`（红的是四条命名守卫：面板面**尚不存在** ⇒ W2/W3/W5/W6/W7 的正相断言整块未执行，按 **★ 覆盖缺口** 如实标注、不冒充红相）。C2 阶段：host `1295 (failed: 4)`（四条徽标/不冒充判据）；C3 阶段：host `1299 (failed: 3)`（C3-a/b/c 各一条）。
- **绿相（实现后，实跑）**：`node host-half.test.mjs` → `ALL PASS` / `assertion total: 1299 (failed: 0)`；`node client-half.test.mjs` → `ALL PASS` / `assertion total: 299 (failed: 0)`（基线 host 1264 / client 269 ⇒ 本批 +35 / +30）。
- **同批文档**：`docs/hardening-and-recovery-design-2026-09-21.md` §4.3.2 结构行 ＋ 新增 **§4.3.8 团队面板分区**（入口口径的唯一事实源）· README §二 行为表新增「团队面板分区」行、`:584` 的「没有任何跨半边取数通道」**前提更正**、架构图补两条读路由与面板、设计索引 W1–W8 → **W1–W9**、徽章 / 稳定性行 / §十读数三处 · 设计档 §3.0.1 回填**实际响应形状** · 账本末节新增本轮条目。
- **未做（如实登记）**：`docs/policy-persistence-design-2026-09-27.md` §8 表里 ②③④ 仍写着「⏳ 后续项」—— 该档不在本批的可改文件清单内，**需要父侧同批改准**（否则状态行与事实不同步）。

---

### 代码评审第 3 轮：`fold failed` 后链尾不回写 / `detach()` 同步置窗口判据（2026-09-27）

> 逐项收口代码评审第 3 轮的 2 条 🟡 ＋ 一条文档滞后（报告项）：实现 2 处、判据 2 条（先红后绿）、文档 4 处。账本见 [`docs/verification-log.md`](docs/verification-log.md) 末节。

### ✨ 改了什么

**① `fold failed` 之后链尾不再回写（🟡#1）。** `adoptMemoryWindow` 的 catch 支（`fold failed`）**不抛** ⇒ `.then` 链继续走到 `syncFileFromService`，其门在文件后端部署里全过 ⇒ 内存被整份替换成**服务视图**（折叠失败 ⇒ 服务里没有窗口数据）并写回文件 —— 窗口数据从内存与文件**两边同时消失**，且无归档、还盖新 `foldedAt`（与设计档 §3.4「宁可漏盖不冒盖」相反）。现在那一支**连回写都不做**：文件保留未并入的那一份，与折叠失败那一行留痕（「仍在落点里、本次未能并入」）逐字一致；`memoryDirty` 保持置位，下一次 attach 的折叠会重试；另留一行 info 说明回写被跳过（不静默）。**不用「先归档再覆盖」那条路** —— 归档救不回内存那份镜像。盖戳判据同批收紧为「**确已落定**的两个结局」（`folded into settings` / `not folded`）才为真。

**② `detach()` 同步置「未挂载窗口」判据（🟡#2）。** `detach()` 过去只复位 `attachWarned`；`unattachedWindowKind` / `enteredUnattachedWindow` 只在 activation 写一次。于是「provider 掉线触发 detach → 窗口内有写入 → provider 回来再 attach」这条链上，折叠留痕沿用 activation 那一次写下的措辞（对一个真实发生过的 detach 窗口是假陈述），归档判据 `!enteredUnattachedWindow` 读的也是旧值。现在 `detach()` 同步置 `unattachedWindowKind = "detached"` ＋ `enteredUnattachedWindow = true`（判据与 warn 门**同生命周期**）；折叠留痕的措辞随之从三支变四支，`detached` 支如实说「provider 被 detach 后又回来」—— 不是「服务从一开始就在场」的快路径措辞，也不是「服务还没来」的启动窗口；detach 窗口里本进程自己写进文件后端的镜像**不再多归档一份**（与 🔵#4 的 `refused` 窗口同一条裁定：只有真·快路径才存档）。

**③ 文档滞后（🟡#3，报告项）。** README 已写实第 2 轮（`1262 = 1255 + 7`），而设计档 §4 的红相账本与 §5 的 host-half 影响面止步于代码评审修复轮的 11 条 —— 本轮把两处补齐到第 2 轮，并同批写进第 3 轮。

### 🧪 怎么验证

- **红相（修复前，实跑）**：`node host-half.test.mjs` → `2 FAILURE(S)` / `assertion total: 1264 (failed: 2)`（退出码 1），红的正是两条新判据（基线 `1262` ⇒ 新增 2 条；控制条件并入同条断言，无单独负相项）。
- **绿相（修复后，实跑）**：`node host-half.test.mjs` → `ALL PASS` / `assertion total: 1264 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS` / `assertion total: 269 (failed: 0)`（退出码 0）。浏览器半边一字未改。
- **顺带修掉一处夹具竞速（本轮实测暴露、先于本轮存在，非插件缺陷）**：第 2 轮 h1 夹具（catch 支盖戳门）的文件轮询读与链尾回写的原子 `rename` 并发时，Windows 偶发把 rename 拒成 `EPERM` ⇒ 回写被拒、`savedAt` 永不刷新、两条断言假红（5 连跑中 2 次）。修法：轮询在 `policy.json.tmp` 在场（回写在飞）时不打开目标文件；修后 8 连跑全绿。
- **同批文档**：设计档 §3.4（新 bullet：`fold failed` 不回写 ＋ 盖戳判据收紧）· §4（两条新判据行 ＋ 红相账本补第 2/3 轮）· §5（host-half 影响面补第 2/3 轮，含本轮新加的 `settingsUpdateThrows` 夹具把手）；README 徽章 / 稳定性行 / §十「当前读数」三处读数 `1262 → 1264`；账本末节新增本轮条目。

---

### 代码评审第 2 轮：catch 支盖戳门 / 数组 policy 也判损坏 / 两因并存并陈（2026-09-27）

> 逐项收口代码评审第 2 轮的 3 条（1 🟡 ＋ 2 🔵）：实现 3 处、文档 4 处。判据（4 红 ＋ 3 ★ 负相）先于本轮写进 `host-half.test.mjs`（上一轮被 DSH 重启打断、未交付报告；本轮从工作区起点实测复核后**只补实现、不新增判据**）。账本见 [`docs/verification-log.md`](docs/verification-log.md) 末节。

### ✨ 改了什么

**① attach 后置链 catch 支不再盖新 `foldedAt`（🟡#1）。** 链在折叠结果产出**之前**断掉时，catch 那一支读不到 `memoryOutcome`，**没有资格**判定「本次链上确有折叠/裁决落定」；旧实现那里是无参的 `syncFileFromService()`，而盖戳门 `options.foldHappened !== false` 对 `undefined` 取真 ⇒ 照样盖新戳，把「最近一次 attach 时刻」冒充「折叠落定时刻」。现在 catch 支显式传 `{ foldHappened: false }`：**宁可漏盖不冒盖** —— 回写照跑（合并结果照旧落盘），只是文件里那个戳逐字节保留上一次真正落定的值。

**② `policy: []` 也判损坏档（🔵#2）。** 旧的损坏判据 `typeof doc.policy !== "object"` 对**数组**不设防（`typeof [] === "object"`），于是 `{"schema":1,"policy":[]}` 被当成一份合法空档：`fileUsable` 置真、落点行翻成「存储：文件 …」，**下一次任何写入**就用原子 rename 把它整个替换掉 —— 正是 U11 损坏档守卫要防的形状。现在判据补上 `Array.isArray(doc.policy)`（数组不是命名空间镜像，`normalizePolicy` 会把它读成一份全默认的空视图），与「缺失 / null」走**同一条**置坏分支，不复制逻辑。

**③ 两因并存时落点行并陈（🔵#3）。** `policyPlacement()` 里 `serviceObserved`（`no-register`）过去**独占**原因行：「服务在场却拒注册 **且** 文件损坏」时，用户看不到「你的文件坏了、需要人工处理」这条**唯一的行动信号**。现在两因并存时并陈 —— `⚠ 存储：仅进程内存（重启即失）—— 原因：no-register；另：文件损坏（不覆盖；请人工处理）`：主因仍取 `no-register`，文件侧那一因以 `；另：` 附后；**四种单因形态逐字不变**（单一原因时没有「另：」）。roster 与 status 两个读面逐字同形；状态卡段①「来源」三态不受影响（只随落点 `kind` 走）。

### 🧪 怎么验证

- **红相（修复前，实跑）**：`node host-half.test.mjs` → `4 FAILURE(S)` / `assertion total: 1262 (failed: 4)`（退出码 1），打在**本轮修复前**的实现上。红的 4 条 = 🟡#1 catch 支盖戳门 1 条 ＋ 🔵#2 数组 policy 2 条 ＋ 🔵#3 两因并存 1 条；另 3 条（🟡#1 / 🔵#2 / 🔵#3 各一条控制项）修复前即绿，按 **★ 负相** 如实标注 —— 分别钉住「夹具真的走了链的 catch 支」「数组档真的原样在盘上」「并陈只发生在两因并存时（四种单因逐字不变）」。
- **绿相（修复后，实跑）**：`node host-half.test.mjs` → `ALL PASS` / `assertion total: 1262 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS` / `assertion total: 269 (failed: 0)`（退出码 0）。判据上一轮已就位（`1262 = 1255 + 7`），本轮**未新增断言**、浏览器半边一字未改。
- **同批文档**：设计档 §3.4（损坏判据写明**含数组**；catch 支「宁可漏盖不冒盖」例外）· §3.5（两因并存的并陈形态与优先序）· §5 行号漂移两处（`:1181`→`:1182`、`:1198`→`:1199`）；README 徽章 / 稳定性行 / §十「当前读数」三处读数 → `1262`；账本末节新增本轮条目。

---

### 代码评审修复轮：损坏档守卫 / 写失败 warn 按段复位 / `foldedAt` 盖戳门 / `refused` 窗口（2026-09-27）

> 逐项收口代码评审列出的 6 条（2 🟡 ＋ 4 🔵）：代码侧 4 处，夹具整洁 2 处，文档 4 处。账本见 [`docs/verification-log.md`](docs/verification-log.md) 末节。

### ✨ 改了什么

**① 损坏的 `policy.json` 不再被覆盖（🟡#1）。** 此前 `loadPolicyFile()` 解析失败时只留了一行 warn 说「本次不会覆盖该文件」，而 `persistPolicyFile()` **毫无守卫** —— 文件后端下**下一次任何写入**都会用原子 rename 把它整个替换掉，落点行还会从「⚠ 仅进程内存」翻成「存储：文件」（`policyPlacement` 只看 `fileUsable`）。现在载入判定为损坏（读不出 / 非法 JSON / 没有 `policy` 对象）就置 `fileCorrupted`：此后**每一次写**都直接返回并**如实留痕**（不静默，也不吞掉第二次以后），落点行报**第 5 个原因码** `文件损坏（不覆盖；请人工处理）`。**人工处置是唯一出口**：修好或移走该文件后重启（每个 store 只读一次文件）。

**② 写失败的 warn 改成按段复位（🟡#2）。** `fileWriteWarned` 过去是**进程级一次性**门：第一段失败 warn 过之后，再下一次失败**完全静默**（与 `attachWarned` 按窗口复位的既有范式不一致）。现在由写入的**成功分支**复位 ⇒ 一段失败 = 一行，成功后新的一段失败再报一行；warn 文案里「此行不再重复」也改准成「**本段内**此行不再重复（写入一旦成功，本段告警复位，再失败会再报一行）」。

**③ `foldedAt` 只由折叠落定盖戳（🔵#3）。** `syncFileFromService()` 过去**无条件**盖新戳，于是「最近一次 attach 时刻」冒充「折叠落定时刻」。现在盖戳门挂在「**本次链上确有折叠/裁决落定**」上（判据取折叠那一步的结局，`: none (no writes while unattached)` 除外）；**回写本身不受影响**（合并结果照旧写回文件，U3/U4/U8/U10 逐字不动），只是没有折叠的那一段保留上一次真正落定的戳。

**④ `refused` 是一个真实的未挂载窗口（🔵#4）。** 判据从 `activationReason !== "attached" && activationReason !== "refused"` 收成 `!== "attached"` —— 「服务在场但**拒绝注册**、后来才挂上」那段时间里的写入**同样由文件后端支撑、同样要折叠并入**。折叠那一行的措辞随之分三支，`refused` 如实说「服务在场但拒绝注册」、**不再**说成「服务从一开始就在场」；由此也不再给本进程自己写的镜像多归档一份 `policy.superseded-*.json`。

**⑤⑤ 夹具整洁两处（🔵#5 / 🔵#6）。** 种子守卫由 `policyHome !== null` 改判 `policyDir !== null`（`policyHome: false` 那一支旧守卫为**真**，`path.join(null, …)` 会抛 TypeError）；另去掉 `host-half.test.mjs` 里一个对同步 `readdirSync` 的无效果 `await`。顺带给夹具加两个把手：`policySeed` 收**原文**字符串（U11 的坏 JSON 要在 `apply` 之前落盘）、settings stub 的 `stopRefusing()`（🔵#4 的「拒注册 → 后来才挂上」）。

### 🧪 怎么验证

- **红相（修复前，实跑）**：`node host-half.test.mjs` → `8 FAILURE(S)` / `assertion total: 1255 (failed: 8)`（退出码 1），打在**本轮修复前**的实现上。红的 8 条 = U11 四条 ＋ U12 一条 ＋ 🔵#3 一条 ＋ 🔵#4 两条；另 3 条（U12 控制项、🔵#3 对照项、🔵#4 对照项）修复前即绿，按 **★ 负相** 如实标注 —— 它们分别钉住「那两次写真的失败了」「那个夹具真的落在没有折叠的那一支」「那个夹具真的挂上并折叠了」，作用是让上面那几条红**不是空转的绿**。
- **绿相（修复后，实跑）**：`node host-half.test.mjs` → `ALL PASS / assertion total: 1255 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS / assertion total: 269 (failed: 0)`（退出码 0）。基线 `1244` / `269` ⇒ **新增 11 条宿主断言**（`1255 = 1244 + 11`）；**浏览器半边一字未改**。

---

### 分歧审计修复轮 `DIVERGENCE(10)`：快路径折叠 ＋ 状态卡「来源」跟随落点（2026-09-27）

> 逐项收口父侧审计列出的 10 条；代码侧只动 2 条（🟡#5 · 🔵#9），其余 8 条是文档层。账本见 [`docs/verification-log.md`](docs/verification-log.md) 末节。

### ✨ 改了什么

**① settings 从一开始就在场时，文件里那一份也会并入（唯一的语义改动）。** 此前 `loadPolicyFile()` 只有一个调用点（`if (scope === null)`）⇒ 设置服务在 activation 就在场时**文件从不被读**：纯设置部署里上一次跑写进 `policy.json` 的团队，在下一次启动里**不可见**。现在：命名空间**还是默认**时，文件里那一份照样折叠并入（并入**前**原样归档成 `policy.superseded-<ts>.json`，合并结果回写文件并盖 `foldedAt`）；命名空间**非默认**时仍按既有裁定**设置胜、文件连读都不读**（U6 那条断言逐字保留）。晚挂路径（服务后来才挂上）的折叠行为**一字未动**。

**② 状态卡里团队清单那一段的「来源」跟随实际落点。** 此前写死成「来源：设置 team-link 的 teams 键」，文件 / 内存落点下会说谎；现在三态各说一句：
`来源：设置 team-link 的 teams 键` / `来源：文件 <绝对路径> 的 teams 键` / `来源：进程内存的 teams 键（重启即失）`。首行「存储：…」那行本来就是真的，一处真一处假是最难发现的形状。

### 💡 为什么

① 是同一类缺陷的另一半：文件后端解决了「服务没挂上时团队活在一个进程里」，却留下了「服务一直在场时文件后端写的团队读不到」—— 用户侧的现象仍是「我建的团队不见了」。② 违反 R2 红线的可核性：落点行说真话、来源行说假话。

### 🧪 怎么验证（实跑原文）

- **绿相**：`node host-half.test.mjs` → `ALL PASS / assertion total: 1244 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS / assertion total: 269 (failed: 0)`（退出码 0）。基线 `1237` / `269` ⇒ **新增 7 条宿主断言**（`1244 = 1237 + 7`），浏览器半边一字未改。
- **红相**：`node host-half.test.mjs` → `6 FAILURE(S)` / `assertion total: 1244 (failed: 6)`（退出码 1），打在**本轮修复前**的实现上。红的 6 条 = U10 五条里的四条 ＋ U5 增补两条；第 7 条（折叠后落点是设置服务）修复前即绿，按 **★ 负相** 如实标注 —— 它断言的是折叠**之后**的落点，而缺陷是折叠压根没发生。
- **新增断言名**：`U10 快路径折叠:` ×5、`U5 落点行: 状态卡段①的「来源」` ×2。

---

### 策略持久化自持化：落点可核 ＋ settings 缺席时不再只活在一个进程里（2026-09-27）

> 设计档：[`docs/policy-persistence-design-2026-09-27.md`](docs/policy-persistence-design-2026-09-27.md)（评审 PASS）。证据账本：[`docs/verification-log.md`](docs/verification-log.md) 的「策略持久化自持化」一节。

### ✨ 改了什么

**① settings 不在场时，状态不再只活在一个进程里。** 此前 `settings` 服务没挂上时，团队注册表与信任数据只存在于**进程内存**（DSH 重启即失，`README.md` 第一张对照表里那一行「DSH 重启会清掉本插件的团队注册表」就是这个后果）。现在这一档落到**插件自己的文件** `<DSH_HOME 或 ~/.dsh>/team-link/policy.json`：路径优先取 `DSH_HOME`（实测 `C:\Users\magic\.dsh`），缺失才退回 `os.homedir()/.dsh`；两者都拿不到才退回进程内存 ＋ **一行**告警。文件落**全局目录**而非工作区 —— 团队是按名字**全局**寻址的，落工作区会造成「换个工作区团队就没了」。

**② 文档形状与写入语义。** `{ "schema": 1, "savedAt": "…", "foldedAt": null, "policy": { …与 settings 命名空间同键集… } }`：`policy` 与命名空间**同键**（8 个键，无损 —— 迁移型改动必须一次写全）；写入原子（`policy.json.tmp` → `fsync` → 覆盖，目录先建），**写失败保留内存态并告警、下次写入重试**。

**③ 落点可核（新红线）。** `team_link_roster action=get` 与 `team_link_status` 的**首行**现在永远说得出状态此刻存在哪，三态之一：`存储：设置服务（team-link 命名空间）` / `存储：文件 <绝对路径>` / `⚠ 存储：仅进程内存（重启即失）—— 原因：<not-active | no-register | 路径解析失败 | 文件不可写>`。

**④ settings 之后再挂上时会折叠。** 文件里的内容并入 settings（服务成为落点），**并立刻把合并结果写回文件、盖上 `foldedAt`** —— 服务下一次缺席（重启）读到的就是合并后的真值，不会表现为「折叠后新建的团队消失」。两边都有数据时按既有 legacy 迁移规则裁决：**服务胜**，文件那一份原样归档为 `policy.superseded-<时间戳>.json` **并留痕**，不做静默合并。回写刻意挂在 attach 后置链的**末尾**（旧命名空间迁移之后）：写早了，文件会缺迁移进来的那一份信任数据。

**⑤ 一个时刻只写一处。** settings 在场时**不建、不写**那个文件；读**有条件**：命名空间还是默认时读进来折叠并入（见上方「分歧审计修复轮 `DIVERGENCE(10)`」那节的 ①），命名空间已有数据时**连读都不读** —— 读了就会把文件那侧并进来，与 §3.3「服务胜」的裁定冲突。

### 💡 为什么

「状态存在哪」此前只能在**源码**里看见：用户看到的是「重启后团队没了」，而插件只留一行 `settings not active…` 的告警。文件后端把那一档从「活在一个进程里」变成「活在一个可读可备份的文件里」，首行落点把「它到底在哪儿」从推断变成**可核**。

### 🚫 明确不做

**不双写**（服务与文件各写一份）；**代码不读宿主配置文件**（`<profile>/cordis.patch.yml` 一次都不碰，迁移由父侧手工做一次，步骤见 `AGENTS.md` §七）；**不做文件锁**（`policy.json` 是全局单文件、插件跨进程，两进程同写可能丢更新 —— 缓解是原子写 ＋ 每次「读-改-写整份」，冲突窗口很小，且折叠/迁移路径都有留痕）；**不改 `session-link-pro` → `team-link` 的迁移**（一行未动）。

### 🧪 怎么验证

- **命令**：`node host-half.test.mjs`（宿主套件）／`node client-half.test.mjs`（客户端套件）。
- **绿相（实跑原文）**：`node host-half.test.mjs` → `ALL PASS / assertion total: 1237 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS / assertion total: 269 (failed: 0)`（退出码 0）。基线 `1203` / `269` ⇒ **新增 34 条宿主断言**（`1237 = 1203 + 34`）；**浏览器半边本轮一字未改**。
- **红相（文件后端档，测试先行）**：`7 FAILURE(S)` / `assertion total: 1214 (failed: 7)`（退出码 1）＝ 6 条新判据 ＋ 1 条 import 白名单锁；**另 4 条覆盖缺口类 ★ 负相**（纯解析器与恒真路径断言，两种实现上都绿，如实标负相不冒充红相）。
- **折叠/可核/迁移档的 23 条**：问题先于实现写出，但**红相改用变异验证** —— 8 次**单点**变异（写文件时不看 scope / 折叠后不回写 / 归档跳过 / 落点行说谎 / 载入不置可折叠位 / 链尾回写跳过 / 迁移次序颠倒 / 永不读文件）逐条证明这些判据**真会变红**，变异后源码按 sha256 校验**逐字节还原**。
- **一次性与真机可核**：无服务时的写入 → 重启（新进程读同一文件）→ 读回一致；迁移可核 = 导入后 `roster get` **看得见**迁移过来的团队 **且**首行 = `存储：文件 <绝对路径>`（`U9 迁移可核:` 三条断言即该路径的夹具等价物；真机执行步骤见 `AGENTS.md` §七，由父侧做并把两条读数抄进账本）。
### 部署接线改为 `link:`（2026-09-27）

### ✨ 改了什么

desktop profile 的 `dsh-team-link` 从 pnpm `file:`（整包**拷贝**进 `.pnpm/`，改完代码必须先刷新拷贝再重启）改为 **`link:`**：
`<profile>/node_modules/dsh-team-link` 成为**指向本仓目录**的 junction，**改完代码只需重启**。
0.4.0 引入的过渡脚本 `deploy-desktop.ps1` 随本条**退役删除**（它解决的是 `file:` 接线自带的拷贝问题）。

### ✅ 怎么验证

- 切换后经 junction 读 `lib/index.js`：sha256 与本仓**逐字节一致**（`A78C463D…`）。
- 改动前拍手动配置快照 `20260927-111821-07ef`，并另存 `package.json.bak-20260927-pre-link`；旧 `.pnpm` 拷贝**保留未删**（回滚＝改回 `file:` 后重跑 `pnpm install`）。
- 安全性核对：三个运行时依赖中 `schemastery` 两侧均为 3.18.0；`@deepseek-ai/dsh-tools` / `dsh-session-reference` 在 desktop profile 中**不存在**（由宿主 asar 提供）⇒ link 不引入版本错配。lockfile 中本就没有 `dsh-team-link` 条目 ⇒ 无「lockfile 与声明不一致」风险。

## 0.4.0 — 2026-09-27（发布收口：团队任务台账 ＋ 可观测批（A）＋ 形态批（B）＋ 三轮修复轮）

> 本版一次性收口下列 **8 个「未发布」条目**（开发期累积、按时间倒序）；package.json 已 bump 到 **0.4.0**。上一版为 **0.3.10（2026-09-22）**。

### 真机冒烟修复轮（L1 时基 / L2 镜像）（2026-09-27）

> 这一轮修的是**真机冒烟**抓到的两条：夹具与审计都抓不到，它们**只在真实运行环境里才看得见**。**不夹带新功能、不扩范围**：A 批设计 §7 与 B 档 §7「明确不做」继续有效；`docs/observability-batch-design-2026-09-26.md` 本轮一字未动；**不碰部署面**；**不动 `<repo>\team\smoke-test\`**（真机冒烟的数据，留着当证据）。逐条读数与红/负相拆分见 [`docs/verification-log.md`](docs/verification-log.md) 的同名一节。

### ✨ 修了什么

**① L1 —— 同屏混用两个时基且未标注**（真机实测：派生视图写 `最后主张 done（2026-09-27 01:45 · session-…）`，而**同一屏**末尾写 `（读数 2026-09-27 09:45:31，>2min 作废）` —— 差 8 小时；原始行是 `2026-09-27T01:45:31.010Z`）。根因：`taskStamp(iso)` 把 ISO 串**切前 16 位**（UTC），`readStamp(now)` 走 `localStamp(new Date(...))`（本地）。处置（父侧裁定：**渲染出来的时间统一到本地时基**）：派生视图的时间戳改走**同一套本地格式化**（`localStamp(date, withSeconds = false)`，分钟精度不变），时间的**瞬间**由 `new Date(<ISO 列>)` 解析而不再做字符串切分；**原始行**仍逐字保留 `toISOString()` 的 UTC 值（事实源不动）。时间列解析不出日期的手写行**单行化后回显该列**（`preview()` 折叠内部连续空白并 trim）—— 原先只切串、换成解析后必须显式兜住这一支，否则会打印出 `NaN-NaN-NaN NaN:NaN`（既不编造时间，也不吐「不是值的值」）。`taskStamp` 的调用点只有派生视图那一处（已核）。

**② L2 —— 镜像在「新建团队」这条路上渲染 `undefined`**（真机实测：`team_link_roster action=upsert-team` 新建的团队，其 `roster.md` 里两行是 `- 形态（mode）：undefined（闭集 sessions / agent-team；默认 sessions）` 与 `- Lead 会话（leadSessionId）：undefined`）。根因（本轮核实并如实报告）：镜像渲染器读的是**未归一化**的团队对象，而 `applyTeamUpsert` **新建**时构造的行**没把这两个新字段写进记录** —— 既有团队走归一化读面（`normalizeTeams` 每次读都补），所以旧团队看不出这个问题；`/team rotate` 的批量建队走同一个函数，属同一病灶。处置：① 渲染器**永不打印 `undefined`**（两字段按 `normalizeTeams` 的**同一套缺字段语义** —— 空串 / 非字符串 = 字段缺席 —— 加闭集规则归一化）；② `upsert-team` **显式写入**两个默认值（schema 的默认值只有**读面**会补，而镜像读的是**写进去**的那一行）；③ 断言补住**新建路径的镜像**与**两个读面（roster get 形态段 / 状态卡 ⑦ 段）的零 `undefined` 泄漏**（后者如实标 ★ 负相：它们本就读归一化行）。

### 💡 为什么

两条的共性是**同一份事实被两种方式算了两遍**：L1 里「同一个瞬间」被渲染器切串（UTC）、被同一屏的读数行本地格式化 —— 于是同屏两处可以相差一个时区；L2 里「字段缺席」在**写路径**没归一化、在**读路径**归一化 —— 于是同一个团队在 settings / 读面 / 镜像三处可以长得不一样。处置都收在同一个方向：**一处算、一处用**（L1 同出一套本地格式化；L2 写路径也写全 ＋ 渲染器自带兜底），并且**渲染面永不吐出 `undefined` / `NaN` 这类「不是值的值」**。

### 🚫 明确不做（本轮）

不加新工具 / 新参数 / 新事件类型 / 新持久状态；不改投递层与黑板三件套的语义；渲染面**只改时基与 `undefined` 两处**，不重排任何既有文案；不动 `docs/observability-batch-design-2026-09-26.md`；**不碰部署面**（`profile/profiles/web/...` 与用户目录里的插件副本）；**不动 `<repo>\team\smoke-test\`**。相邻发现的一条（`renderRosterMirror` 对**缺 `rotationBackup` 键**的裸对象会取 `undefined.at` 抛错）**本轮不改、仅留档**：该形状在所有调用点都不可达，且不属 L1/L2 的判据面。

### 🧪 怎么验证

- **命令**：`node host-half.test.mjs && node client-half.test.mjs`；
- **绿相（实跑两行原文）**：`node host-half.test.mjs` → `ALL PASS / assertion total: 1203 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS / assertion total: 269 (failed: 0)`（退出码 0）。基线 `1193` / `269` ⇒ **新增 10 条宿主断言**（`1203 = 1193 + 10`）＋ **改写 10 条**；**浏览器半边本轮一字未改**（仍 `269`）；
- **红相（本轮修复前的实现 ＋ 本轮的新断言/改写断言；测试先行）**：`assertion total: 1203 (failed: 17)`（`17 FAILURE(S)`，`nodeExit=1`）—— **17 条真红** ＝ **7 条新断言**（L1 三条 ＋ L2 四条）＋ **10 条改写的期望值**（9 条 `§9 U12/U13/U15/D5/D6` 的 `stampOfRow` 期望 ＋ TR 夹具那条把 UTC 截断值写死的 `U12 零回归`）；
- **★ 负相 3 条**（两种实现上都绿，**不冒充红相**）：`L1 坏时间戳原样回显` · `L1 原始行逐字 UTC ISO` · `L2 两个读面零 undefined 泄漏`（覆盖缺口类 / 反向护栏）；
- **夹具不再自证**：`stampOfRow` 从「切行里的 ISO 串」改为「把那个瞬间按**本地墙钟**独立算出来」⇒ 任何时基改动都会当场变红；判据的**机器无关性**见验证档（前 16 位相同的两行、相差 5 小时的两个瞬间必须渲染不同）。

### 🔁 同批同步的面

`lib/index.js`（`localStamp` / `taskStamp` / `applyTeamUpsert` / `renderRosterMirror`）；`host-half.test.mjs`（10 条新断言 ＋ 10 条改写的期望值）；`README.md`（三处读数 `1193 → 1203` · §四**时间基**一条 · 团队形态表的**镜像**行 · 实现约定里的时间戳条目）；`docs/team-mode-batch-design-2026-09-26.md`（状态行读数 · §4.1 镜像范围）；`docs/team-ledger-and-mode-design-2026-09-26.md`（§9.3.3 时间基 · 状态段与 §7 步 3 读数）；本条目；`docs/verification-log.md`（本轮一节）。

---

### 部署脚本与真机冒烟（2026-09-27）

### ✨ 新增

**部署脚本 `deploy-desktop.ps1`** —— 解决「改完代码重启却不生效」这个静默坑：profile 用 pnpm `file:` 依赖装本插件时，pnpm 会把整包**拷贝**进 `<profile>\node_modules\.pnpm\dsh-team-link@file+...\node_modules\dsh-team-link`，而 DSH 加载的是那份拷贝。脚本四步：从本仓库（本地路径，不依赖网络）fast-forward 部署克隆 → 覆盖 `lib/` + `package.json` + `cordis.patch.yml` 进 pnpm 拷贝 → 校验两边 `lib/index.js` sha256 一致 → 提示重启；`-DryRun` 只打印、不落盘、不改 git 状态。

### ✅ 怎么验证

- 两个壳各跑一遍：`powershell -File deploy-desktop.ps1 -DryRun`（exit 0，四文件报告 `already in sync`，两侧 sha256 打印一致）；坏路径参数 `-Clone C:\nope` ⇒ 明确报错 + exit 1（fail-fast）。
- 干跑前后：仓库 `git status` 与部署克隆 HEAD **未变**（零副作用）。

### 📌 同批记录（真机冒烟的两条发现 —— 修复见上面「真机冒烟修复轮（L1 时基 / L2 镜像）」一节）

在**运行中的壳**里对台账做写入冒烟（建临时团队 → `plan/claim/done/dispute` 四种行 → 读回派生视图）时，抓到两条**夹具测不出**的问题：① 派生视图的时间戳是 UTC（切 ISO 串）而同屏「读数」是本地时间，**同屏混用两个时基且未标注**（真机差 8 小时）；② `roster.md` 镜像在 `upsert-team` 新建那条路上把 `形态（mode）` / `Lead 会话（leadSessionId）` 渲染成 `undefined`。两条已另立修复条目（见上面「真机冒烟修复轮（L1 时基 / L2 镜像）」一节：L1 渲染统一到本地时基、L2 镜像与新建路径去 `undefined`）。

---

### B 批收尾修复轮（代码评审 R1–R6）（2026-09-27）

> 形态批（B 批）与分歧审计修复轮 `DIVERGENCE(8)` 之后的**收尾修复轮**：只取代码评审 7 条里的 6 条（R1–R6），**R7 仅留档、代码与夹具一字未动**（父侧裁定：接受顺序耦合，理由见验证档的「已知可接受项」）。**不夹带新功能、不扩范围**：A 批设计 §7 与 B 档 §7「明确不做」继续有效；**不动 `docs/observability-batch-design-2026-09-26.md`**；**不碰部署面**。逐条读数与红/负相拆分见 [`docs/verification-log.md`](docs/verification-log.md) 的「B 批收尾修复轮（R1–R6）」一节。

### ✨ 修了什么

**① R1 —— 诊断话术仍是断言式归因（D1 同类漏改的一处）** —— `probeAgentTeams` 的 service-absent 分支把原因写成因果断言「宿主没有提供 agentTeams 服务（**本次运行的 profile** 没有装载 …组合包）」。而 cordis 的 `ctx.get` 只返回**已激活**的 provider：一个尚未完成 `[Service.init]` 的 `agentTeams` 也会走到这一支 ⇒ 「profile 没装载」是**假阴性断言**（正是 D1 要消灭的那类错误归因）。现在该 reason 软化为「服务 `agentTeams` 当前不可见（可能未装载 …组合包，也可能尚未激活完成 —— 可稍后重试，或核对当前活动 profile 的 `dsh.profile.bundles`）」：写路径的拒绝照旧刺眼（拒绝 + 指路 + 零写入），**但不替宿主下结论**。引用该文案的既有断言（`D2 首行按分支准确化（反向锁）`）同批改写。

**② R2 —— 同一判据被探测两次** —— `set-mode` 的可用性门与确认框正文的投影各调一次 `probeAgentTeams`。现在「切到 agent-team」那一向的探测结果**直接复用**为确认框正文的投影（`probe ?? probeAgentTeams(...)`）；只有「切回 sessions」那一向没有前置探测，才现读一次。两条路的处置仍各自决定（可用性门 vs. 正文那一行），判据仍只此一处。

**③ R3 —— TOCTOU 复检后的不对称（账与镜像可能分家）** —— 写时复检之后，镜像用**复检后**的行，而形态史那行还用**对话框前**的 `team`：用户在确认框打开期间经设置 UI 改了 workspace 时，镜像写新路径、账写旧路径。现在两者**同源**（同一个 `teamWritten = nextTeams.find(...)` 行）。

**④ R4 —— 幂等放宽的语义噪音（文档侧 + 返回体措辞同批）** —— 从未切换过的团队第一次收到 `set-mode mode=sessions`（其默认档）会**补记一条「形态 → sessions」**：为一次从未发生的切换造一行史（属设计裁定的取舍，**行为不动**）。文档与返回体一律改准为：**首次声明也算一行** —— 形态史记的是「**声明过这一档**」，不是「档位发生变化」。旧措辞「形态史记的是「切换」，不是「重复声明」」在 B 档 / README / `lib/index.js` 三处**零残留**。

**⑤ R5 —— 无会话身份时诊断行会「猜」** —— `otherReachableSessions` 在调用方无会话身份时退化为按 `process.cwd()` 过滤 ⇒ 可能触发**基于猜测**的「⚠ 多会话通道看起来不可用」，与同文件「读不到 ⇒ `null` ⇒ 不判、不猜」的纪律不一致。现在 `selfId === undefined` ⇒ **返回 `null`（不判）**，与 `sessionIdSnapshot` 的失败语义对齐；状态卡 ⑦ 段（原先直接传 `pool`）随之收敛到同一个判据。

**⑥ R6 —— 状态行措辞过宽** —— B 档状态行写「**D8 是本轮唯一的行为改动**」，但 D2（读面首行按分支取）与 D3（镜像新增两行 + `set-mode` 落笔后重写镜像）都改了**可观测输出**。同批收窄为「唯一的**门 / 写路径语义**改动（D2 / D3 只改读面文案与镜像渲染）」，B 档 §4.2 与上一条 `DIVERGENCE(8)` 条目里的同句声明一起改准。

### 💡 为什么

R1 / R5 是同一个病：**把观测到的现象说成了因果结论**（R1：「服务看不见」⇒ 断言「profile 没装载」；R5：没有身份 ⇒ 拿 `process.cwd()` 过滤出来的空列表断言「多会话通道不可用」）。本仓的家规是「**读不到 ⇒ null ⇒ 不判、不猜**」，所以两处都改成只报现象、只在不猜的前提下下判据。R2 / R3 是同一个形状的另一面：**同一份事实被取了两次**（R2 探测、R3 行来源），于是两次取到的东西可以不一样 —— 一次取、一处用，分家就不可能。R4 / R6 是文档与实现的自相矛盾（R4：文档说「切换才记一行」而实现连首次声明也补记；R6：说「唯一的行为改动」而同轮还有两处可观测输出变更）。

### 🚫 明确不做（本轮）

**R7（测试夹具顺序耦合）不接受修复** —— 父侧裁定「可接受的顺序耦合（有注释、teardown 已清理）」，本轮只在验证档留一条「已知可接受项」并给出将来的做法（重排用例时给各用例独立 workspace；D8 的 `nbWs` / `fbWs` 已是该做法），**代码与夹具一字未动**。其余同 `DIVERGENCE(8)`：不加新工具 / 新参数 / 新事件类型 / 新持久状态；不动投递层与黑板三件套的语义；**不动 `docs/observability-batch-design-2026-09-26.md`**；**不碰部署面**（`profile/profiles/web/...` 与用户目录里的插件副本）。

### 🧪 怎么验证

- **命令**：`node host-half.test.mjs && node client-half.test.mjs`；
- **绿相（实跑两行原文）**：`node host-half.test.mjs` → `ALL PASS / assertion total: 1193 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS / assertion total: 269 (failed: 0)`（退出码 0）。基线 `1184` / `269` ⇒ **新增 9 条宿主断言**（`1193 = 1184 + 9`）＋ **改写 1 条**；**浏览器半边本轮一字未改**（仍 `269` —— 本轮只动宿主半边）；
- **红相（本轮修复前的实现 ＋ 本轮的新断言/改写断言；测试先行）**：`assertion total: 1193 (failed: 8)`（`nodeExit=1`）—— **8 条真红**（7 条新断言 ＋ 1 条改写的反向锁）；另 **2 条新断言在两种实现上都绿**，如实标 **★ 负相**（`R2 ★ 负相（切回方向）` = 覆盖缺口类；`R5 反面对照` = 反向锁），**不冒充红相**；
- **回归**：B 批 41 条、`DIVERGENCE(8)` 16 条与 A 批 / 台账批的既有断言**零回归**（本轮唯一改动的既有断言就是 `D2 首行按分支准确化（反向锁）` 的措辞）。

### 🔁 同批同步的面

`lib/index.js`（`probeAgentTeams` 的 reason · `set-mode` 的探测复用与 `teamWritten` 同源 · 两处形态史措辞 · `otherReachableSessions` 的 `selfId` 早返回 · 状态卡 ⑦ 段的判据）；`host-half.test.mjs`（9 条新断言 ＋ 1 条改写；新夹具各自一份 workspace）；`README.md`（三处读数 `1184 → 1193` · 幂等行 · 宿主探测 / 落笔 / 形态诊断行三行的口径）；本条目；`docs/verification-log.md`（本轮一节）；`docs/team-mode-batch-design-2026-09-26.md`（状态行 · §4.2 幂等口径）；`docs/team-ledger-and-mode-design-2026-09-26.md`（§7 步 3 行的本轮交付说明）。

---

### 分歧审计修复轮 `DIVERGENCE(8)`（2026-09-27）

> 只读分歧审计的 **8 条**结论（D1–D8）逐条闭环。**不夹带新功能、不扩范围**：A 批设计 §7 与 B 档 §7「明确不做」继续有效。逐条验证证据见 [`docs/verification-log.md`](docs/verification-log.md) 的「分歧审计修复轮 `DIVERGENCE(8)`」一节。

### ✨ 修了什么

**① D1 —— 文档把真机读反了（实证）：文案通用化 + 补设置 UI 兜底路** —— 旧文案断言「**本部署未装载** `@deepseek-ai/dsh-experimental-agent-team-profile` ⇒ `ctx.get("agentTeams")` 为 undefined ⇒ 切档被拒」。实测事实是：本部署跑的是 **desktop profile**（`DSH_PROFILE=desktop`），其 `dsh.profile.bundles` **含**该组合包；本会话系统提示词里同时有工具包 POLICY 常量与 `spawn_teammate` 工具声明（该工具只由 `@deepseek-ai/dsh-experimental-agent-team-tool-agent-team` 注册，其 `inject` 含 `agentTeams`）⇒ **服务已在运行实例中挂载** ⇒ 探针 `available:true` ⇒ **U11b 的拒绝路径在本部署不会触发、US1 可达**。于是：`AGENT_TEAMS_HOWTO` 改成**通用表述**（按**当前活动 profile** 的 `dsh.profile.bundles` 自查；已经在那里 ⇒ 拦住本次切换的是别的原因），拒绝文案里**补一行设置 UI 的兜底路**（`MODE_SETTINGS_FALLBACK`：形态就是 settings 的 `team-link.teams[].mode` / `leadSessionId`，用户经设置 UI 永远是超级写者）—— 防一次假阴性把用户卡死。读面首行同时按分支准确化（见 ②）。

**② D2 —— 首行与原因行自相矛盾（真机最常走到的那一支）+ 两条断言** —— 名册投影不可读时原先**无条件**先打常量「成员名册不可读（本部署未提供该投影）」，再打原因行；而探针有五条不可读分支（服务缺席 / 缺方法 / 无会话身份 / **调用方非成员** / 读取抛错），真机走的是「服务在场、调用方不是成员」那一支 ⇒ 首行与原因行**互相打脸**。现在探针回一个 `cause` 判别符，渲染器据此取首行：只有 `service-absent` 说「本部署未提供该投影」，其余四条用**中性首行**（`成员名册不可读 —— 仍可读 Lead 与形态（哪一条读不到，见下一行的原因）`）+ 紧随的`（不可读原因：…）`行。**补两条断言**：「调用方非成员」档与「读取抛错」档（此前**零断言**）。

**③ D3 —— roster.md 镜像补 mode / Lead 两行 + `set-mode` 落笔后重写镜像** —— 镜像文件自述「与**设置变更**同一事务内 best-effort 镜像」，但 `set-mode` 既不渲染这两个字段、也不重写镜像 ⇒ 那句自述对本字段是**假话**。现在镜像里出现`- 形态（mode）：…`与`- Lead 会话（leadSessionId）：…`两行，且 `set-mode` 落笔后与既有调用点（`upsert-team` / `set-role` / `retire`）**同形**地调用同一个 `writeRosterMirror`（best-effort 语义一字不差：镜像坏掉只告警，绝不把整次切换变成失败）。

**④ D4 —— 过期限定词统一（三处）** —— 父档 §2.3 矩阵第 7 行、`lib/index.js` 的能力矩阵常量、README 的同一张表此前仍写「成员部分要读宿主投影（**未复核**）」，而同批已把父档 §8 改成「✅ 已核」；B 批「逐行照抄」把它抄进了代码常量。三处统一为已核口径：`⚠️ 成员部分读宿主投影（2026-09-27 已核：本部署已挂载该服务 ⇒ 探针 available=true）`。

**⑤ D5 —— 补确认框「成员名册不可读」那一档的断言** —— §4.4 写死了两档（可读 ⇒ 列成员 / 不可读 ⇒ 写「（成员名册不可读）」），但套件只断言了可读档。现已补上（含「不会迁移的三件事」与「不阻断」两句的对照）。

**⑥ D6 —— 「只改这两个键」的表述改准 + 多团队夹具** —— README / CHANGELOG 原写「除这两个键以外**一个字不改**」，而实现是 `reopened.teams.map(...)` **整份数组回写** ⇒ 其余团队行也会被**补默认值**（`mode:"sessions"` / `leadSessionId:""`）。现在如实写成「只改**本团队行**的两个键；其余团队行**已有值不被覆盖、缺值被补默认**（与既有 `upsert-team` 同形，语义无变化）」，并补一条**多团队夹具断言**钉住这两半。

**⑦ D7 —— 测试加固三处** —— ① 能力矩阵断言由「4 个 ❌ ＋ 3 个 ⚠️ ＋ 其中两行原文」改为**逐行锁八行原文**（其余六行的文本漂移此前**不会红**，是真盲区）；② 删掉 `modeSetEnv({ tag: "rg" })` 的死参数（该函数没有 `tag` 形参）；③ 三道门的 `length` 断言在注释里**如实标注**为「函数元数变更探测器」，不是行为锁。

**⑧ D8 —— 唯一的门 / 写路径语义改动（D2 / D3 只改读面文案与镜像渲染）：让「补记」这条路真的可执行（原指路与幂等互斥）** —— `decisions.md` 写失败时给出的指路是「补写路径后**重发本次切换以补记**」，但幂等分支（同档同 Lead）会**先命中**并返回「已是该档」、**连 decisions 都不追加** ⇒ 该指路**不可执行**，US6「每次切换留一行」会被永久破坏。现在幂等判据放宽为「同档同 Lead **且账上已有这一档的形态史行** ⇒ 已是该档（零写）；**账上缺这一行 ⇒ 补记恰好一行**再返回（返回体如实说明这是补记）」。形态史行的识别走**共享常量函数** `modeHistoryBody`（写读同源：落笔与判据读同一个函数），只比正文、不看时间戳与作者；**读不出来 / 没有 workspace ⇒ 不补记**并在返回体如实说明（fail-closed，不猜）。

### 💡 为什么

这一轮的八条有同一个形状：**文档/文案断言了没有实测过的结论**（D1 把真机读反了 —— 它以为拒绝路径会被触发，真机其实根本走不到），或者**两条互相矛盾的话被并排写在一起**（D2 的首行与原因行、D6 的「一个字不改」与整份数组回写、D8 的指路与幂等）。处置原则沿用本仓家规：**能实测的就实测**（D1 四处改成真机事实，并让文案只说它在当前 profile 下该说的话）、**能标注的就不沉默**（D2 的中性首行 + 原因行、D8 的「不补记」）、**能红的断言不许留盲区**（D7 逐行锁 + D5 补档 + D8 两条新判据）。

### 🚫 明确不做（本轮）

不加新工具 / 新参数 / 新事件类型 / 新持久状态；不改投递层与黑板三件套的语义；**不动 `docs/observability-batch-design-2026-09-26.md`**；不做跨形态改投、不做自动切档、不代理宿主的派活/任务板（B 档 §7 继续有效）；**不碰部署面**（`profile/profiles/web/...` 与用户目录里的插件副本）。

### 🧪 怎么验证

- **命令**：`node host-half.test.mjs && node client-half.test.mjs`；
- **绿相（实跑两行原文）**：`node host-half.test.mjs` → `ALL PASS / assertion total: 1184 (failed: 0)`（退出码 0）；`node client-half.test.mjs` → `ALL PASS / assertion total: 269 (failed: 0)`（退出码 0）。基线（本轮修复前的工作树）`1168` / `269` ⇒ **新增 16 条宿主断言**（`1184 = 1168 + 16`）；**浏览器半边本轮一字未改**（仍 `269`）；
- **红相（本轮修复前的实现 ＋ 本轮新断言；测试先行）**：**`assertion total: 1184 (failed: 14)`**。逐条点名后**做了归因**：**13 条是真红**（D1 两条 · D2 两条分支 · D3 三条 · D8 三条 · U6 两条幂等 · U11 矩阵逐行锁一条），第 14 条（`D6 多团队夹具`）是**夹具假红**（那一版夹具漏了宿主替身 ⇒ 切换先被探测拒掉），补上替身后它**在两种实现上都绿**、改归 ★ 负相；另 **6 条在修复前本来就绿**，如实标 **★ 负相**（覆盖缺口类：`U6 账上已有该行`【改写】· `D2 首行反向锁` · `D5 不可读档` · `D5 两档对照` · `D8 前置（写失败）` · `D6 多团队夹具`）—— 不冒充红相；
- **本轮改写的既有断言 3 条**（同批同步，不留旧口径）：`U11 完整能力矩阵`（→ 逐行锁八行原文）· `U6 幂等（agent-team）`（→ 加上「账上已有该行」这一半）· `U6 幂等（sessions）`（→ 改成「账上缺该行 ⇒ 补记恰好一行」＋「补记之后 ⇒ 零写幂等」两条）；
- **回归**：B 批 41 条与 A 批 / 台账批的既有断言零回归（唯一的三处改动就是上面那三条改写）；模块级 `inject` 仍 4 项；`policy` 命名空间键集不变（零新增持久状态）；D8 的两个写路径都只碰 `decisions.md`（只追加一行，不重写）。

### 🔁 同批同步的面

`lib/index.js`（`AGENT_TEAMS_HOWTO` 通用化 + `MODE_SETTINGS_FALLBACK` + 拒绝文案 + 能力矩阵第 7 行 + `probeAgentTeams` 的 `cause` + `TEAM_MODE_ROSTER_UNREADABLE_NEUTRAL` + 渲染器按分支取首行 + `renderRosterMirror` 两行 + `set-mode` 的镜像调用 / 幂等放宽 / 形态史共享写入 `modeHistoryBody` / `decisionRowBody` / `decisionsHasModeHistory` / `appendModeHistoryRow` / `backfillModeHistoryRow` + roster 工具描述面）；`host-half.test.mjs`（16 条新断言 ＋ 3 条改写 ＋ `makeAgentTeams` 的 `listThrows` 与 `modeSetEnv` 的 `workspace` 两个夹具参数）；`README.md`（三处读数 `1168 → 1184` · 能力矩阵第 7 行 · 落笔 / 幂等 / 看形态 / `set-mode` 四行 · `agentTeams` 服务表）；本条目；`docs/verification-log.md`（本轮一节）；`docs/team-mode-batch-design-2026-09-26.md`（§3 未复核面行 · §4.2 幂等口径 · §4.3(3) 第三种文案 · §6 U6 · §8 A1 与 §8.1 A1 · §2.3 第 7 行）；`docs/team-ledger-and-mode-design-2026-09-26.md`（§2.3 第 7 行 · §8 已核那条）。

---
### 形态批（B 批：团队形态 · `set-mode` · 读面形态段 · teammate 交卷提示）（2026-09-27）

> 设计（唯一事实源）：[`docs/team-mode-batch-design-2026-09-26.md`](docs/team-mode-batch-design-2026-09-26.md)（§4.1 形态字段 / §4.2 `set-mode` / §4.3 读面形态段 / §4.4 交卷提示 / §5 红线六条 / §6 判据 **U1–U14 ＋ U11b** / §7 明确不做 / §8 假设 A1–A4）。来源是[《台账 + 形态设计》](docs/team-ledger-and-mode-design-2026-09-26.md) §7 的**步 3**（形态字段 + agent-team 档）与**步 5**（teammate 交卷提示）。逐条红相/绿相读数见 [`docs/verification-log.md`](docs/verification-log.md) 的「形态批（B 批）」一节。

### ✨ 修了什么

**① 形态字段（只落在 settings，§4.1）** —— `TeamConfig` 扩两字段：`mode`（闭集 `sessions`（默认）/ `agent-team`）与 `leadSessionId`（agent-team 档的 **Lead 指针**，不是名册）。**既有团队零迁移**：老 settings 行没有这两个键也照常读出 `sessions`；读到**闭集外**的 `mode` ⇒ 落默认档**并在读面留痕**（点名原值、闭集、以及「原值未被改写」），settings 里的原值一个字不动 —— 与「手改出来的行必须降成**可读状态**，绝不降成不可读命名空间」同一条范式。

**② `team_link_roster action=set-mode`（第五个封闭动词，§4.2）** —— 团队形态在多会话档 ↔ agent-team 档之间切换：

1. **闭集**：`mode` 不在闭集内 ⇒ 拒绝并**列出两个值**（拒绝文案渲染的就是校验用的那一个常量）；
2. **Lead**：`leadSessionId` **省略 ⇒ 默认取调用方自己的会话 id**，并在确认框正文里**明示该默认值**（人可见即可否决）；**显式空串 ⇒ 拒绝**；非空须过**形状**（`^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$`）与**在场校验**（能在本次会话列表快照里找到 —— 防转录错位）两道；
3. **宿主探测只对「切到 agent-team」这一向**：探测不到 ⇒ **拒绝 + 指路怎么开 + 零写入**（切回 `sessions` **不探测**）；
4. **双重门（缺一即 fail-closed、零写入）**：① `writer gate` **原样**（现任协调者；空缺 ⇒ 会话路径拒绝，设置 UI 仍是兜底）；② **人类确认框**（无确认服务 / 超时 / 取消 ⇒ 拒绝且零写入）；
5. **落笔**：settings 的团队行只改 `mode` / `leadSessionId` **两个键**（`teams` 是**整份数组回写**：其余团队行若缺这两个键会被**补默认值**、已有值不被覆盖 —— 与既有 `upsert-team` 同形）+ `decisions.md` 追加**恰好一行**形态史（`形态 → agent-team（Lead=<id>）` / `形态 → sessions`）+ best-effort 重写 `roster.md` 镜像；
6. **幂等**：同档同 Lead **且账上已有这一档的形态史行** ⇒ 「已是该档」，**不弹框、不写 settings、零写入**；账上**缺**那一行 ⇒ **补记恰好一行**再返回（否则那条「补上路径后重发以补记」的指路不可执行），账读不出来 / 没有 workspace ⇒ **不补记**并如实说明；另有写时复检（对话框横跨任意长的人工等待，落笔前的现任条件由宿主**重新观测**）。

**③ 读面形态段（§4.3，`roster get` 与状态卡⑦段同一个渲染器）** —— 形态 + Lead（Lead 为空标「**Lead 未知**」，不编造）+ 成员名册**投影**（**读时现算、一行不落 settings**；来源文案**写死两种**：`来源：宿主 agentTeams 投影（本部署可读）` / `成员名册不可读（本部署未提供该投影）—— 仍可读 Lead 与形态`）+ **完整能力矩阵**（逐行照抄父档 §2.3：四件 ❌ / 三件 ⚠️ / 一件与形态无关）+ 「**单会话兜底档**」那句结论 + **形态诊断行**（除自己外没有其他可达会话时只提示、**绝不自动切**）。

**④ teammate 交卷提示（§4.4，提示式、不阻断）** —— 切换确认框正文列出「**不会迁移的三件事**」（① 信任 ② 成员名册 ③ 任务归属）+ **当前 teammate**（可读则列，不可读如实说）+「请确认它们的结论已落到黑板或文件」。**不逐成员推断有没有交卷**（那要读子代理日志，§7 明确不做）。

### 💡 为什么

形态**不是功能开关，是通道选择**：多会话档给的是「平级会话之间的信任层」（投递 / 配对 / 换届 / 黑板），agent-team 档给的是「一个会话内部的子代理团队」。两档各有各的主人，所以本批只做四件事：**把选择写成 settings 里的一个字段**、**把切换做成一次由人点一下的动作**、**把「这一档下什么用不上」如实摆到读面上**、**把「切走会丢什么」在切之前说出来**。三条纪律贯穿全批：**只读宿主**（不 spawn / 不派活 / 不改宿主任务状态）、**不悄悄降级**（写路径刺眼报错 + 指路；读路径如实标注并保持其余能力 —— **两条路处置不同且不许混用**）、**指针不拷贝**（只存 Lead 会话 id，成员名册读时现算）。

### 🚫 明确不做（本批）

不代理宿主的 spawn / 派活 / 任务板；**不读子代理日志**（交卷只做提示式，不逐成员推断）；**不做自动切档**（切换永远由人触发）；不改 `pairs`/`trustedSenders` 的迁移语义（只**声明**不迁移）；不做客户端面板（数据面先行，与 A 批同一取舍）；**不做跨形态改投**（切档不改投在飞消息、不建桥 —— 要跨形态说话由模型自己用对应形态的手段说）。

### 🧪 怎么验证

- **命令**：`node host-half.test.mjs && node client-half.test.mjs`；
- **绿相（实跑两行原文）**：`node host-half.test.mjs` → `ALL PASS / assertion total: 1168 (failed: 0)`；`node client-half.test.mjs` → `ALL PASS / assertion total: 269 (failed: 0)`。基线 `1127` / `269` ⇒ **新增 41 条宿主断言**（`1168 = 1127 + 41`）；**浏览器半边本批一字未改**（仍 269 —— 设计档 §7 明确不做客户端面板）；
- **红相（本批 41 条判据 ＋ 实施前的 `lib/index.js`）**：**`assertion total: 1168 (failed: 34)`** —— 33 条 B 判据红 ＋ 1 条**既有锁**红（`U10` 的 roster 参数键集锁：临时状态下测试文件已按设计要求期望 `mode`/`leadSessionId`，而旧实现没有这两个参数 —— 那条红正是这条锁该红的理由，与 A 批的「工具计数同改锁」同源，不是回归）；
- **红相的安全方法**：把工作树版 `lib/index.js` **读进内存** → 用 `git show HEAD:lib/index.js` 覆写（**换来换去都有 sha 对照**：覆写后的 `git hash-object` == `git rev-parse HEAD:lib/index.js`，即换进去的就是实施前那一份）→ 跑 `node host-half.test.mjs` → **还原内存里的那一份** → **sha256 逐字节复核**（`restoreMatch: true`，工作树版 sha256 `4110893DC5F07C56909EE194B1E6BF0F20F5C674B8233007065CAE81A378FA3B`）。**不留备份文件、不留探针**，工作树零残留；
- **分阶段红相（测试先行，逐阶段实跑）**：阶段 1 `1137 (failed: 9)` · 阶段 2 `1157 (failed: 19)` · 阶段 3 `1168 (failed: 2)` —— 每一阶段的新断言都是在**该阶段实现之前**写进去并实测红的（逐条红/负相拆分见验证账本）；
- **回归**：既有四动词（`get`/`upsert-team`/`set-role`/`retire`）与 `team_link_rotate`/`team_link_recover` 的动词闭集与三道门函数**一字未动**；模块级 `inject` 仍 4 项；`policy` 顶层键集不变。**唯一改动的既有断言**是上面那条 roster 参数键集锁（它必须跟着参数面一起改，这是本仓「改一处即两处」的既有规矩）。

### 🔁 同批同步的面

`lib/index.js`（形态常量与渲染 / `normalizeTeams` 降级留痕 / 宿主探测 `probeAgentTeams` / 确认框 `askModeDialog` / `set-mode` 分支 / `roster get` 与 `team_link_status` 的形态段 / 两个工具的描述面）；`host-half.test.mjs`（41 条断言 ＋ 宿主 `agentTeams` 替身 ＋ `rosterCall` 的 Y7-safe 调用器 ＋ roster 参数键集锁）；`README.md`（三处读数 · roster 动词表与工具一览 · **新增「团队形态」段**（两档白话 + 三句要紧的话 + 能力矩阵）· 状态卡 ⑦ 段 · 设置键表与两处 yaml 样例 · 设计文档索引加本档一行）；本条目；`docs/verification-log.md`（本批一节）；`docs/team-mode-batch-design-2026-09-26.md`（状态行与 §8 假设 A1–A4 回填实测结论）；`docs/team-ledger-and-mode-design-2026-09-26.md`（§7 步 3 / 5 标 ✅ ＋ 指向本档的链接；提交哈希 `12f0874`（2026-09-27 由父会话回填））；`docs/observability-batch-design-2026-09-26.md`（§7 第 6 条改标「状态卡形态段由 B 批实施」）。

---

### 分歧审计修复轮 `DIVERGENCE(12)`（2026-09-27）

> 只读分歧审计的 **12 条**结论（D1–D12）逐条闭环。**不夹带新功能、不扩范围**：A 批设计 §7「明确不做」继续有效，B 档 `docs/team-mode-batch-design-2026-09-26.md` 一字未动。逐条读数见 `docs/verification-log.md` 的「分歧审计修复轮」一节。

### ✨ 修了什么

**① 唯一的行为改动：派生回执行标注「按当前名册解析」（D7）** —— 没有结构化回执时按**实参**兜底解析寻址表达式，其中 `team:<name>/<role>` / `team:<name>/*` 是**按读取时的名册**解析出来的；此前注释承诺了标注而实现没做（只特判了「回执截断」），换届之后可能把 ✅/⚠ 判给当时并非收件人的会话且**不告知**。现在这类行如实带上 ` · 按当前名册解析（该表达式按读取时的名册解析，未必是投递当时那一个）`（裸 id 是字面量，不带此标注），工具描述面同批同步。

**② 10 条断言补齐（D1 / D2 / D4 / D5 / D9 / D10 / D12）**：

1. **D1**：无时间戳 ⇒ 打「无法计算」那句、**不打**计数注记 —— 设计 §8.1 A5 与本档都曾写「三态都有断言」，而套件里 `grep 无法计算` = **0 命中**（补的是判据，不是行为）；
2. **D2**：读窗为空 ⇒ 注记**整段不打印**（连标题都不出现）；
3. **D4**（四条）：`run_code` 里发出的 `tool/ptc-dispatch` 那一类投递照样成行 · 实参兜底解析 `team:<name>/<role>` 时表达式与现任一并显示 · 回执被裁过时只报告**回执自己报的总数** · 逐行渲染上限恰 20 行 ＋ 一行「本次还有 N 行未显示」（N = 真实差额）；
4. **D5**：`team_read` 的 `readIds` **非数组** ⇒ 拒绝且**零读**（工具面硬形状）；
5. **D9**：`U13 零额外读` 那条原先有半边**恒真**（`slice(length).length === 0`），换成真计数 —— 打注记那次与不打注记那次，各自的 surface 读数逐次相等（各恰 12 = 同一个有界读窗）；
6. **D10**：聚合态 `M` = **所示各团队** `tasks.md` 同期新增行数之**和**（夹具 3 ＋ 2 = 5，两个团队的台账尾都在卡上）；
7. **D12**：归组面 = **任何消息文本里第一个** `ref=t-<n>` —— **非 banner** 的普通消息（本会话自己发的那条）同样归组，发送方如实回落标「（本会话）」。

**③ 设计与 README 口径回填（D1–D4 / D6 / D8 / D10–D12）** —— 设计档 §4.1 新增「点名读上限与超限行为」表（`list_sessions` ≤12 拒绝 / `team_read` ≤11 截断并逐个标注，同一不变量两种形态）· §4.2 注记补**三态**与**聚合口径**、成本列回填「单团队 1 次 / 聚合 N 次（N = 所示团队数）」、会话面来源订正为 `ctx.sessionQuery.listSessions`（与 `list_sessions` **同源同序**）· §4.3 写死**归组面**与点名读上限 · §4.4 写死投递事实的**两类事件载体**（`tool/call` ＋ `tool/ptc-dispatch`）、**`callId` 配对**、**窗口单位是「最近 20 次 `team_link_send`」而不是 20 条消息**，并补**第 4 态**「：未投递（outcome=…）」（措辞只陈述 `outcome`，不下结论）；README 同步这些口径，并修正设计文档索引里与父档矛盾的状态行（步 2 / 4 / 6 已实施；步 3 / 5 待实施）。账本 A 批一节 A5 行的「都有断言」也已订正。

### 💡 为什么

这一批的共性是**读面与描述面脱节**：行为大多已经存在，但（a）有两条断言是**空的**（一条恒真、一条根本不存在），(b) 有若干实现口径**没写进设计**（无锚时的三态、聚合口径、`team_read` 的读额边界、投递事实的载体与窗口、第 4 态、归组面、成本列），(c) 有一处注释**承诺了没实现的标记**（D7）——那才是唯一真会让人读错数的缺陷：换届之后按当前名册解析出来的收件人，会被当成投递当时的收件人来读。处置原则沿用本仓两条家规：**能标注的就不沉默**（无法计算 / 本次未读 / 按当前名册解析），**能红的断言不许恒真**。

### 🚫 明确不做（本轮）

不加新工具 / 新参数 / 新事件类型 / 新持久状态；不改 `list_sessions`、`team_link_status`、`team_link_send`、`team_link_team_append` 的任何行为；不动 `PREVIEW_SESSIONS`、不动三个 `timeoutMs`；B 档（形态）一字不碰。

### 🧪 怎么验证

- **命令**：`node host-half.test.mjs && node client-half.test.mjs`；
- **绿相（实跑两行原文）**：`node host-half.test.mjs` → `ALL PASS / assertion total: 1127 (failed: 0)`（宿主进程退出码 0）；`node client-half.test.mjs` → `ALL PASS / assertion total: 269 (failed: 0)`。基线 `1117` / `269` ⇒ **新增 10 条宿主断言**（`1127 = 1117 + 10`），浏览器半边**一字未改**；
- **红相 A（「本轮修复前」的实现 = 工作树、D7 尚未落码）**：`assertion total: 1127 (failed: 1)` —— 唯一红的那条就是 **D7**；其余 9 条在两种实现上都绿，**如实标为负相**（它们补的是判据覆盖缺口：旧实现没有这个 bug，只是没有这条锁）；
- **红相 B（A 批实施前的 `89074fe`）**：`assertion total: 1127 (failed: 65)` = A 批的 **55** 条（54 新 ＋ 1 既有工具计数锁，与账本的 A 批一节逐条相符）＋ **本轮 10 条全红**；安全方法同 A 批：工作树版读进内存 → `git show HEAD:lib/index.js` 覆写 → 跑 → **还原内存里的那份** → **sha256 逐字节复核**（`restoreMatch: true`，本轮工作树版 `d6ae2f78c1d6c13db8fb2d8ad0cc56cfd623702f7a675675d69c074211b9ab1a`），**不留备份 / 探针 / 残留**；
- **回归**：A 批 60 条断言全部仍绿（含 `U12` 既有四块零回归、`U7` 三条成本不变量、`§12.5` 跨半边 outcome 短语锁、工具计数锁 10），模块级 `inject` 仍 4 项，`policy` 命名空间键集不变。

### 🔁 同批同步的面

`lib/index.js`（`ROSTER_RESOLVED_NOTE` ＋ `receiptRowsOf` / `renderReceiptRow` 的标注 ＋ `team_link_team_read` 描述面）；`host-half.test.mjs`（10 条断言 ＋ 4 条夹具事件 ＋ 3 个新夹具 ＋ `trTruncatedResult` ＋ `U13 零额外读` 改真计数）；`README.md`（三处读数 ＋ 状态卡段 ＋ 收件视图/派生回执段 ＋ 回执四态表 ＋ 设计文档索引状态行）；本条目；`docs/verification-log.md`（本轮一节）；`docs/observability-batch-design-2026-09-26.md`（§4.1–§4.4 口径回填 ＋ §8.1 A5 订正 ＋ 状态行加「后续回填」）。**`docs/team-ledger-and-mode-design-2026-09-26.md` 与 B 档一字未动。**

---
### 可观测批（A 批：读窗扩展 · 团队状态卡 · 台账收件视图 ＋ 派生回执）

> 设计（唯一事实源）：`docs/observability-batch-design-2026-09-26.md`（§4.1 读窗 / §4.2 状态卡 / §4.3 收件视图 / §4.4 派生回执 / §5 红线五条 / §6 判据 **U1–U14** / §7 明确不做 / §8 假设 A1–A5）；来源是《台账 + 形态设计》§7 的**步 2 / 步 4 / 步 6**（步 6 的两半都在本批）。逐条红相/绿相读数见 `docs/verification-log.md` 的「可观测批（A 批）」一节。

### ✨ 修了什么

**① 读窗从「固定 12」变成「默认 12 ＋ 点名 ＋ 分页」（§4.1）** —— `team_link_list_sessions` 新增两个**可选且互斥**的参数：

1. `readIds?: string[]`（点名读）：去重后 ≤ **12** 个，超出即**拒绝且本次零读**；只接受**本次列表内**的 id，未知 / 不属于本列表的 id → 拒绝并**指出那个 id**；点名**优先占额**，其余按原顺序补足到 12；本就在默认窗内的 id 只占一个额、不重复读；与 `offset` 互斥；
2. `offset?: number`（分页）：从第 `offset+1` 行起读 12 行（默认 0）；非整数 / 负数 / 越界 → 拒绝并给出**有效区间** `0..行数-1`；
3. **成本不变量按工具分账**（断言锁死）：`list_sessions` 三条路径 ≤ **12**；`team_read` ≤ `min(12, 1+|readIds|)`（**自读占 1 个额**）；`team_link_status` ≤ **12**；
4. **列表末尾新增「未读 Y 行 ＋ 怎么读」提示段**（默认调用也带）：`未读 2 行（读窗 12/共 14 行）：读第 13–24 行 → offset=12；或点名 → readIds=["session-x", "session-y"]`。**既有行结构一字未改**——本次唯一的格式新增就是这一段（外加新参数）。**默认值 12 不动**（提高它等于把超时风险塞回每一个调用）。

**② 新工具 `team_link_status`：只读团队状态卡（§4.2）** —— 一次调用一屏，六段：① 团队与角色（在位 / 空缺 / **版本史末条**）② 换届 pending（在飞令牌，token **掩码**）③ 看门狗（`policy.watchdogs`）④ 会话面（id / 代理状态 / 创建时间 / provisional 标记，**不读日志**）⑤ 活性（**有界**：与列表工具同一顺序读前 12 行，超出如实标「本卡只读了前 12 行」）⑥ 台账尾（`tasksTail` 默认 **5**、上限 **20**，超出或非正 → 拒绝并给区间）。参数：`team?`（省略 = 聚合全部团队、每团队一段；给了但不存在 → 拒绝并**列出已知团队名**）、`tasksTail?`。**全只读**：不写设置、不写磁盘、不加缓存、**连换届过期清扫都不跑**（那会写）；无会话身份时照常出卡，「当前会话」处如实标 `（当前会话未知）`。**反面预警注记**（会诊提出）：锚 `T0` ＝ 本读窗内最旧的一条 surface 消息时间戳、`N` ＝ 其后本读窗内的消息条数、`M` ＝ 其后 `tasks.md` 的新增行数，**只有 `N == 0 且 M > 0` 才打注记**（「会话可能已停止说话只写行」），否则不打；两个计数都取自**已经读到**的数据 ⇒ **零额外读**；锚取不到时如实标「无法计算」，**不猜**；**它是读数，不是裁决**。

**③ 台账收件视图 ＋ 派生回执（§4.3 / §4.4）** —— `team_link_team_read` 新增**一块**（既有四块一字未动）：

- **收件视图**：读**调用方自己**的会话面，按 `ref=t-<n>` 分组给出「谁 · 什么时候 · 开头几个字符」；两个尺寸常量 `TASK_INBOX_MESSAGES=20` / `TASK_INBOX_PREVIEW=80`（越界截断**必标注**）；无 `ref` 的消息**如实计数**（不静默丢弃），**未登记的任务号照样分组并标注** `（该号在台账里未登记 —— 可能是笔误，也可能是先发后记）`；
- **派生回执**：投递事实从调用方**自己**会话面的既有事件取（`tool/call`，或 `run_code` 里发出的 `tool/ptc-dispatch`；有结构化回执时用**投递当时**解析出的目标与结果），三态写死：**未点名** ⇒ `未读`（**目标面零读**，断言锁死）／点名且 `t` 之后有 assistant 事件 ⇒ `✅ 有反应`／点名且其后无 assistant 事件 ⇒ `⚠ 无后续反应`；读不到的面一律标「未读」，**绝不用空数据算读数**；`≤ min(12, 1+|readIds|)`，超额的点名逐个标「本次未读」。**纯派生、零新增持久状态、零新增写路径**。

### 💡 为什么

「12」是**预算**（一行 surface ＝ 一次冷日志解压 ＋ 一次投影；真实工作区里串行读满 50 行会超掉 60s 工具预算），不是能力上限——所以**不提高默认值**，把「读哪些」的决定权交回调用方（点名 / 分页），并把上限定成不变量；同时把「未读」从终点变成**可执行的下一步**。另外两件事都是**只读地**把已经存在的事实摆到一屏里：状态卡回答「人想知道团队还活着没有」，收件视图回答「谁对我说了什么」，派生回执回答「我说出去之后对方动了没有」——后者是**纯派生**，不新增任何持久状态（会诊 Q4 采纳项）。**红线一寸未动**：成本不变量按工具分账、未读必标注、**全只读**（`send` / `team_append` / `roster` 的写面一行未动）、`list_sessions` 既有行结构逐字保持、措辞不出现「状态＝完成」这类把主张写成事实的词。

### 🚫 明确不做（本批，§7）

不做客户端面板渲染（本批只做数据面）· 不做缓存 / 索引 / 自动后台巡检 · 不做跨进程聚合 · **不提高 `PREVIEW_SESSIONS` 默认值** · 不定 agent-team 档下的状态卡行为（形态字段尚不存在，跨批接缝显式声明）。

### 🧪 怎么验证

- **命令**：`node host-half.test.mjs && node client-half.test.mjs`；
- **新增断言 60 条**（全部落在宿主套件；读数 `1117 = 1057 + 60`，基线取本批前的套件自报值 1057）：阶段 1（读窗 / 成本不变量 / 尾巴提示 / 三类边界拒绝）23 条 · 阶段 2（状态卡六段 + 参数边界 + U13 注记）20 条 · 阶段 3（收件视图 / 派生回执 / U12 回归）17 条；
- **两套件实跑自报读数**：`node host-half.test.mjs` → `assertion total: 1117 (failed: 0)`；`node client-half.test.mjs` → `assertion total: 269 (failed: 0)`（浏览器半边本批**未触碰**：本批只做数据面）；
- **红相（安全方法：备份 → 换实现 → 跑 → 还原 → sha256 复核）**：把 `lib/index.js` 换成 `git show HEAD:lib/index.js`（`89074fe`）后跑本批的测试 —— `assertion total: 1117 (failed: 55)`，其中**本批新断言 54 条红**（其余 6 条是刻意在两种实现上都应通过的**回归锁**：U1 的三条「行结构 / 读窗 / 窗口内 verdict 不变」、U12 的「派生读数与原始行窗口未动」、U3 的「本就在默认窗内的 id 不重复读」、以及 U9 的 settings 半边在红相上 trivially 成立——旧实现根本没有这个工具，自然不改设置），另 1 条是既有的 `§11.9 工具计数同改锁`（在那个临时状态下 README 写 10 个工具而旧实现注册 9 个——这正是它该红的原因）。**还原后 sha256 逐字节一致**（`fde1b78573f88d392cdf3666c38bf1f70132439209666d590bfc46bf546ff7c1`），工作树无残留；
- **回归锁**：`list_sessions` 的既有行结构 / 既有断言零回归；`team_read` 的**既有四块**（roster ＋ decisions ＋ discipline ＋ tasks）零回归，新块只追加；
- **红线回归**：模块级 `inject` 仍 4 项、**不新增任何日志事件类型**（新读全部走既有事件：`tool/call` / `tool/ptc-dispatch` / 既有 `tool/result.meta`）、`policy` 命名空间**键集不变**（零新增持久状态）、投递 `source` 仍恰三成员、`§12.5` 跨半边 outcome 短语锁与 README 工具计数锁同批更新后仍绿。

### 🔁 同批同步的面

`lib/index.js`（`readListReadWindow` / `listReadTail` / `readStatusTasksTail` / `ledgerRowTime` / `reverseWarningNote` / `readTaskReceiptTargets` / `surfaceMessageEvents` / `surfaceEventText` / `shortStamp` / `crossSessionBody` / `inboxOpening` / `readReceiptTargets` / `parseToolArguments` / `surfaceSendRecords` / `resolveSendTargets` / `taskMessageBlock` / `receiptRowsOf` / `renderReceiptRow` / `asText` 与两组常量；`team_link_list_sessions` 的参数面与尾巴、`team_link_status` 新工具、`team_link_team_read` 的 `readIds` 与新区块）；`host-half.test.mjs`（A 批 60 条断言 ＋ `listCall` / `statusCall` / `readCall` 三个 Y7-safe 调用器 ＋ `mkdir` 进导入 ＋ 工具计数 9 → 10）；`README.md`（§二 读窗参数与成本不变量表 · 新增「团队状态卡（只读）」一段 · §四 收件视图与派生回执 · 工具一览表两行 ＋ 新工具一行 · 设计文档索引 ＋ 目录 · 三处读数）；本条目；`docs/verification-log.md`（本节读数）；`docs/observability-batch-design-2026-09-26.md`（§8 假设 A1–A5 的实测结论 ＋ 状态行）；`docs/team-ledger-and-mode-design-2026-09-26.md`（§7 的步 2 / 4 / 6 标已实施并链接本档）。

---

### 团队任务台账 `tasks.md`（设计 §9 第一批：只追加台账 ＋ 读时投影）

> 设计（唯一事实源）：`docs/team-ledger-and-mode-design-2026-09-26.md` **§9**（§9.3.1 行格式 / §9.3.2 写入面 / §9.3.3 读面 / §9.3.4 派生规则 / §9.4 边界与红线 / §9.5 判据 **U1–U18** / §9.6 明确不做 / §9.9 跨文档同步六条）。

### ✨ 修了什么

**新增第三个黑板文件 `tasks.md`**（`<workspace>/team/<name>/tasks.md`）——只追加的任务台账，与 `decisions.md` 同构：只追加、每行带署名、seq 由插件单调分配、单行 500 码点。

1. **行格式（§9.3.1）**：`seq | ISO时间 | author-session-id | kind | task | 正文`。`kind` 是**闭集**：`plan` / `claim` / `done` / `block` / `dispute` / `retract`；`task` 形如 `t-<n>`。
2. **写入面（§9.3.2）**：`team_link_team_append` 的 `file` 白名单由两值扩为**三值**，新增 `kind` / `task` 两个参数。`kind=plan` 由插件**扫整个文件**分配 `t-<已登记最大号+1>`（调用方同时给 `task` 即拒绝）；其余 `kind` 必填 `task`，且**该号必须已在本文件登记过**——未登记的号一律拒绝并指路 `kind=plan`；`kind` / `task` 传给 `decisions` / `discipline` **一律拒绝且零写入**；`seq` **每文件独立计数**；写入走 `appendFile`（读-算 seq-追加），只追加不重写。
3. **读面（§9.3.3）**：`team_link_team_read` 在 discipline 块之后追加 tasks 块 ＝ **原始窗口**（末 20 条，逐字）＋ **派生视图**（扫描最近 500 行，逐任务给「最后主张」与「未消解存疑」）＋ `baseHash`（仅供参考/审计：tasks 只追加、不接受 baseHash 参数）＋ **三类边界如实标注**（文件不存在 / 超扫描上限「更早的 N 行未参与派生」/ 不可解析行「N 行无法解析，未参与派生」）。
4. **派生规则（§9.3.4）**：最后主张 ＝ 该任务最后一条 `claim` / `done` / `block`，一条都没有 → 「尚无主张（仅登记）」；`retract` **不抹历史**——被撤回的主张仍然显示（呈现「最后主张 done（… · 已由 #N 撤回 · 撤回者 …）」，**原主张者与撤回者两个 id 都在**）；`dispute` 之后**没有**新的主张 / 撤回才标 `⚠ 未消解存疑 N 条`，否则标「存疑已由 #N 消解」；**绝不自动裁决**（不比较正文、不按时间戳定胜负），措辞一律「最后主张 / 未消解存疑」，**不出现**「状态＝完成」这类把主张写成事实的词。

### 💡 为什么

主会话的上下文会被压缩，而「我们到底在干什么」过去只活在它脑子里；但**报告必须原话进上下文**这条红线又不能动（把报告换成「写张便条贴墙上、让主管自己看」，互核就死了）。台账补的正是中间那一格：**把「账」搬出上下文，把「事」留在上下文**，并且**在结构上无法成为事实源**——

- **只追加** ⇒ 不存在「谁有资格把 doing 改成 done」这个无仲裁者的问题（不抄 CAS 看板：那张板子上写着 done 就是「现实」，一个错被全员继承）；
- **每行带署名** ⇒ 板上永远只有「A **声称** T3 完成」，没有「T3 完成」；
- **反驳走同一条写入路径** ⇒ 存疑只是**又一行**，不需要任何新机制，也不需要新的授权类型；
- **「当前状态」是读的时候算出来的** ⇒ 显式标注「这是派生读数，不是事实」；删掉文件不影响任何写入路径，派生结果随时可从原始行重算。

### 🚫 明确不做（本批，§9.6）

不做状态机 / CAS / 自动裁决 / 自动推进（「送达即完成」禁止）· 不做写入权限门 · 不做跨会话物理队列 · 不做 12 窗口 / 形态切换 / 状态卡 / 交卷提示（§7 第 2–5 步不在本批）。**`decisions` / `discipline` 的语义与文案一字未改**，唯一例外是 `file` 白名单拒绝文案由两值改三值（§9.6⑤，已用**源码级**断言锁住）。

### 🧪 怎么验证

- **命令**：`node host-half.test.mjs && node client-half.test.mjs`；
- **新增断言 62 条**（全部落在宿主套件 `host-half.test.mjs`；U1–U18 逐条对应，读数 `1057 = 995 + 62`，基线取本批前的套件自报值 995）：**51 条**随第一批（台账本体）、**11 条**随同日分歧修复轮（D4 判据缺口 5 条：U4 的 `=500 码点收` · U12 的 `block 可作最后主张` · U18 的另两组组合与四组合总锁 3 条 · D5 1 条 · D6 2 条 · D9 2 条 · D1/D8 的描述面口径 1 条）。**两套件实跑自报读数**：`node host-half.test.mjs` → `assertion total: 1057 (failed: 0)`；`node client-half.test.mjs` → `assertion total: 269 (failed: 0)`。客户端半边本批**未触碰**；
- **红相（功能缺失，两次实跑）**：
  - **① 本批判据 ＋ 旧实现（`3eba6c1:lib/index.js`）**：`node host-half.test.mjs` **在 `host-half.test.mjs:2145` 当场抛错、整轮中止** —— `ToolArgsError: invalid arguments: "file" must be one of ["decisions","discipline"]`（`code: 'INVALID_ARGS'`），`nodeExit=1`，**`assertion total` 一行都没打印**（红相说不清自己的规模，与本仓 Y7 教训同形）。原因正是旧实现的 `file` 枚举里没有 `tasks`、`kind` / `task` 也还不是已声明参数（新判据打旧实现会**抛**，而不是返回 FAIL）；
  - **② 本批判据 ＋ 本轮修复前的 `lib/index.js`**（把 D1 / D5 / D8 / D9 四处改动逐字回退）：`assertion total: 1057 (failed: 8)`，8 条逐条点名 —— D9 1（`t-1e+22` 那条分配路径）· U13 三条**全行比对**（t-2 / t-4 / t-1，旧实现渲染成 `） · ⚠ …`）· D1/D8 的读面口径行 1 · D6①/② 2 · D5 1。U4 / U12 / U18 的 5 条在修复前**本来就绿**（补的是判据覆盖缺口，如实记、不算红相）；
  - **逐条读数、夹具与还原纪律见 [`docs/verification-log.md`](docs/verification-log.md) 的「团队任务台账 `tasks.md` 第一批（设计 §9）＋ 分歧修复轮」一节**；
- **U14 是回归锁**：`decisions` / `discipline` 的**整段返回文本**用 `===` 逐字比对（不是 `includes`），任何一处文案漂移当场变红；
- **红线回归**：导入面仍**六模块**（零新增依赖）、**不新增任何日志事件类型**、投递 `source` 仍**恰三成员**、`policy` 命名空间键集不变——本批只读写磁盘上的黑板文件，不碰投递层、不碰 settings 形状、不引入任何内存态。

### 🔁 同批同步的面

`lib/index.js`（常量 `TASKS_FILE` / `TASKS_WINDOW` / `TASKS_PROJECTION_SCAN` / `TASK_KINDS`、`blackboardPaths` 的 `tasks` 键、公共 `lastSeq`、`tasksRow` / `parseTasksRow` / `registeredTaskIds` / `deriveTasksView` / `taskView` / `taskStamp` / `renderTaskView`、`team_link_team_read` 与 `team_link_team_append` 的两个面；分歧修复轮的 D1 分隔符 / D5 删未申报段 / D8 描述面三件套口径 / D9 安全整数分配）；`host-half.test.mjs`（§9 的 **62 条**断言（51 ＋ 修复轮 11）＋ `tasksPath` / `tasksBlockOf` / `tasksHashOf` 三个夹具助手 ＋ 那条「三个 baseHash」既有断言的同批更新）；`README.md`（§四 目录树三件套 / 参数说明 / 任务台账小节 / 台账推荐用法 / 工具一览表 / **三处读数**（徽章 · 对照表 · §十））；`docs/verification-log.md`（本节读数：本批做了什么 / 红相两次实测 / 绿相 / 边界证据）；本条目；`docs/team-ledger-and-mode-design-2026-09-26.md`（§7 第 1 步与 §9 状态行标已实施并附实测读数；§1 / §4 的 `conflicted` 口径改成已实施的措辞；§9.3.4 规则 2 补两条子情形定义）。

---

---

## 0.3.10 — 2026-09-22（**发布收口：0.3.9 ＋ 0.3.10 一并落定**）（§10.2.8 `/team_session` 三条真机缺陷修订：输入文法 · 结果可见性 · 确认框边界）

> 设计（唯一事实源）：`docs/collab-enhancements-design-2026-09-19.md` **§10.2.8**（§10.2.8.0 现象与证据 / §10.2.8.2 修订后的文法 / §10.2.8.3 结果可见性 / §10.2.8.4 确认框边界 / §10.2.8.6 明确不做）与 **§10.4 的 U30–U34**；逐条**红相/绿相读数**见 `docs/verification-log.md` 的「§10.2.8 三条真机缺陷修订（U30–U34）」一节。
> **发布状态（2026-09-22 发布收口）**：本条目与 **0.3.9** 一并落定（当时为当前版本；其后由 **0.4.0** 接续）（`package.json` **0.3.10** · tag **v0.3.10**；0.3.9 段按本仓惯例标注「发布前收口于 0.3.10」）。①② 是宿主半边（需 DSH 重启才在真机生效）；③ 含**一号宿主半边**（换槽位）与**二号浏览器半边**（§10.2.8.3 通道 1 的客户端节点，需重建客户端 bundle + 刷新页面）。
> **真机状态（取代原先那句「本条目不声称已真机验证」）**：§10.2.8 的缺陷 ①②③ 与 §10.2.8.9 / §10.2.8.10 的四项裁定**均已真机验过** —— 含确认框在真机上的四条判据、通道 4 回执（GUI 渲染为「跨会话消息」卡片）、最小唤醒、侧边栏三个会话可见、结算时序读数；逐条读数与截图证据见 `docs/verification-log.md` 的「真机复验」一节。**U33 的「渲染高度不超视口」**这一条也已被动验到（框体紧凑、底部动作行全在视野内），但它依赖窗口宽度，**仍不作单测断言**。

### 🐞 三条真机缺陷与修法

**① 输入文法：正文被当成了参数（U30 / U31）**。真机现象：用 `/team_session team=0921-main ` 接一具 **3058 字**的交接正文，连发 5 次，界面「点了发送什么都不显示」、团队与会话一个都没建成；会话日志里是 **5 条 `command/run` + 5 条 `command/done kind=error`**，错误文案逐字相同：`N 必须是整数（会话个数，1..8）。`。**根因**：解析器在**整条输入**上做 token 扫描，**任何**「字母＋等号」都被当成 `key=value` —— 正文里的「同窗 `N=3）。`」被读成 `n=3）。` ⇒ **参数校验阶段即拒绝**，连「角色名」那一步都没走到。同族的第二个雷：正文里还有 **284 个**不含等号的 token，按当时文法**全是位置角色名** ⇒ 即便躲过 `N`，也会以「会话个数 284 超过硬顶 8」失败。⇒ **当时没有任何一种拼法，能把一具含「字母＋等号」的正文送进去**（`task=` 也会在第一个已知 `key=` 处断开）。

**修法（用户裁定 = 方案 A「参数可省」，§10.2.8.2 的 R1/R2/R3）**：**R1** 参数区**只在行首**且谓词闭合 —— 从行首连续取「形状合法（含 `=` 且 label 非空）、key 已知、**取值本地合法**」的 token 为参数；结束条件**恰两类**：**(a) 静默结束**（token 不含 `=`，或 `=` 在首字符 ⇒ 该 token 起全部算正文）· **(b) 报错**（形状合法而 key 未知，或 key 已知而取值不合法 ⇒ **整条命令拒绝**并**原样回显 offender**）。**R2** 正文不解析：进入正文后 `N=3` / `pid=384448` / `word=` 一律**逐字保留**。**R3** 失败必须点名：回显 offender + 给出路「想写正文就直接写…也可以用 `task=`」。**位置角色名废除**（本次的语义变更，已在设计、命令 description、`input.hint` 与报错文案里**显式宣布**）：裸 token 是**正文的起点**，声明角色的唯一拼法是 `roles=`（别名 `role=`）；旧的「位置参数写角色名」指引同批删除。**默认值**随之落定：`team` 省略 ⇒ 调用会话工作区目录名（不合 `[a-z0-9-]+` 回退 `default`）· `n` 省略 ⇒ 1（给了 `roles=` 时为角色数）· `roles` 省略 ⇒ 一个 `worker-1` · 既无正文也无 `task=` ⇒ 只建会话、不投启动任务。**既有语义一字不改**：N ≤ 8、每队 ≤ 24、按 role 幂等、两个别名、`model`/`preset` 规则、确认框、失败即停。

**② 结果可见性：命令结束了，界面上一行都没有（U32）**。真机现象：那 5 条错误**逐字写进了会话日志，界面上一行都没显示** —— `command/run` / `command/done` 是 **log-only** 事件（**不进模型面、也不保证在壳里渲染**），落点只在发命令的那个输入框里（§10.2.1 那条「顶层可见是免费的」被真机推翻）。**修法**：按 §10.2.8.3 的通道优先级取**可用的第一条** —— **通道 1（复用 §10.1.3 的 D 模式）经核实可用，即取通道 1，不降级**：客户端新增**独立 definition**（`kind: team-link-team-session`）与同一键控槽上的渲染面，match 既有 `command/run`（**按 `data.name` 过滤**）与 `command/done`（该事件**本身不带 name**，只能按**见过的 `commandId`** 认领 —— 有界 64、重放安全），**成功与失败走同一条通道**。**不新增任何日志事件类型**（只**读**既有事件）。

**③ 确认框无界、动作够不着（U33）**。真机现象：确认框终于弹出，但**框体高于可视区，底部的「创建 / 取消」够不着**（那次成功命令的 **27.4 秒全花在确认框上**；此前另有 **8 次** `kind=success` 的失败尝试走的是「取消则零创建」那一支）。**先修正归因（有代码依据）**：撑高框体的**不是** `task=`（那行早就是有界预览），而是**我们自己写的散文**。**修法（修法表第 0 行，首要、结构性）——换槽位**：披露正文从 `question` **整段移入 `detail`**，`question` 只留**一行话**。依据是壳的布局（逐条可复核）：`question` 被渲进**无高度钳制、且在滚动容器之外**的 `<header><h2>`，而 `detail` 在 `Mbwy4a_body{overflow-y:auto}` **之内**、底栏 `flex-shrink:0` 也在滚动区外 ⇒ **动作可达性与文本长度脱钩**。同批：任务预览**标注**（共 N 字 / 仅显示前 M 字 / **完整正文会原样投递**）· 正文两个硬预算（**码点 ≤ 600 且换行 ≤ 12**，两者都单测断言）· **不逐角色展开**（只列前 3 个 + 「…等 N 个」，**总数仍写全**）· **「只给 id 形状 ＋ 计数」**（`- 会话 id：team-link-<team>-<role>-<uuid8>（共 N 个…）` —— 修法表第 0 行换槽位时把这行连同逐角色 id 清单一起删了，§10.2.8.4 (b) 要求的这半句一度零实现；全量清单仍只出现在完成回报里）· DEFECT-4 与模型/预设两段自述各压到**一行** · 可变字段（团队名 / cwd / 会话 id / **model= / provider=**）逐字段封顶且裁剪留下省略号 · 按段落裁剪时**标注**（「已裁剪至 600 码点 / 12 行上限，省略 N 段自述；必备披露一字未少」）。§10.2.8.7 裁定 2 的**角色指引行**（「新会话是 worker；你自己（调用会话）是 coordinator；要交棒请用 `team_link_rotate`」）在**确认框与完成回报**里各一行，并**计入**上述预算。

**明确不做**（§10.2.8.6 / §10.2.8.4 (d)）：**不驱动调用会话**（`followup` 会花 token，且违背命令的 log-only 语义）· **不加**「建完即换座」（会绕开 M4 的信任快照 / 冻结广播 / 对称吊销 / 一次性令牌两阶段）· **分页杠杆已核实不适用**（壳的分页是**按问题**且每页须作答，拆散文不行）· **不改**模块级 `inject`（仍 4 项）· **不改**既有 schema key · **不新增任何日志事件类型**。

### 🧪 怎么验证（变异验证）

- **修复前必红**（隔离夹具 `.tmp-head/`：本轮的新测试 + `git show HEAD:lib/{index,client}.js` + HEAD 的 `README.md` / `package.json`）：`node host-half.test.mjs` → `assertion total: 951 (failed: 30)`；`node client-half.test.mjs` → `assertion total: 269 (failed: 22)`。
  - 宿主侧 30 条的**实际分布**（**逐条点名**，同夹具实跑）：**U30 7/9 · U31 4/4 · U33 8/9** ＋ 改写后的既有断言 **U16 10 条** ＋ **DEFECT-4 槽位 1 条** = 7 + 4 + 8 + 10 + 1 = **30** ✓。**其中 3 条在旧实现上本来就绿**（原记「本批新增的 U30 / U31 / U33 全红」是**计数不实**，2026-09-22 只读审计第 6 条纠正）：**U30 的 R1(b) 正相**（`n=abc` ⇒ 报错 —— 它断言的是**保留下来**的旧语义，不是本批引入的新语义）· **U30 的「既有 key 语义不变」** · **U33 的 `options` 一字未动**（换槽位只搬正文，不碰「创建 / 取消」这对授权面）。其中 U33「换槽位」那两条把**旧的槽位读数逐字留在案上**：修复前 `question` = **1068 码点 / 14 换行**（正是「长文放在 header」的形状），而 `detail` 只有 **63 码点的一行话** —— 换槽位把这两个数整个对调了。
  - 客户端侧 22 条里，**U32 的 10 条中 8 条红**；另 2 条是**负相**断言（「不认别的类型」「状态不可读时不抛错」）—— 它们断言的是**缺席**，在没有该 definition 的构建上**本来就会绿**，如实记，**不算**「修复前已通过」。
- **修复后全绿**：`node host-half.test.mjs` → `assertion total: 951 (failed: 0)`；`node client-half.test.mjs` → `assertion total: 269 (failed: 0)`。新增断言 **24 条宿主 ＋ 10 条客户端**（`951 − 927 = 24`、`269 − 259 = 10`，基线取 0.3.9 批次 4 收口时的两套件自报值，**不按「上一版 ± 本轮新增」反推**）。
- **U34 是回归守卫（§10.2.8.6）**：`/team_rotate` 的位置参数（角色名）**改前改后都应为绿** —— 隔离夹具里两条 U34 断言**当场全绿**（与 §11.2 的既有文法面同批复跑）。**红相另做单点变异**「把新文法搬到 `/team_rotate` 的解析器上」（`if (value.role !== undefined) continue;`）⇒ 套件在 `host-half.test.mjs:4646`（§11.2 的既有文法面）**当场崩**、整轮 30 条 FAIL —— **守卫是活的**。
- **红线回归**：`lib/` 内 `ctx.session`（**单数**）/ `appendEvent` / `session.log` / `.append(` **仍全部为 0**；模块级 `inject` **仍恰 4 项**（`sessionReferenceResolver / tools / sessionQuery / agents`）；投递门与 `source` 三成员语义未动；**未新增任何日志事件类型**。
- **同批改写（不是删除）的既有断言**：
  - 宿主侧 —— `input.hint` 那条（补「不得再有位置参数写角色名」）· 三条**位置角色名**断言（§10.2.8.2 的语义变更，改为「裸 token 归正文、`roles` 只由 `roles=` 声明」）· 「U16 端到端文法」那一组（输入行在新文法下读法不同，两条改写成 U30 的判据、一条改为 `roles=` 声明）· 以及 **5 处披露文案断言只把取值槽从 `question` 换成 `detail`**（**断言文本逐字不动** —— 换槽位把正文搬进了 `detail`，断言若还读 `question` 就是在测一个已经不承载正文的槽位）。
  - 客户端侧 —— 3 条 chat-node 槽位计数（2→3，新增 §10.2.8.3 通道 1 的渲染面）· 1 条「注册被拒只花顶层卡」的 warn 计数（1→2，两个 definition 各自留一行具名 console warn）· 若干 `fresh.length`（5→6）与 `names()` 清单 · `applyWith` 的 definition 计数改成**按 kind**（新增 `definitionCallsOf(kind)`，让「某一张面照常注册」的断言不再被另一张面合法地移动）。

### 📝 如实标注（设计未逐字规定 / 与实现现状有出入的地方）

- **原来那句「本命令是 §10.2.4 的批量动作：…」被**替换**，不是被删掉**：按修法表第 0 行，`detail` 现在整段承载披露正文；该句描述的批量范围由**必备披露块**「确认则：创建 → followup 投递启动任务 → 登记 roster 与 pairs；取消则零创建、零 pairs。」承接。**为什么两全不了（实测）**：正文预算在常规用例下已是 **591 / 600 码点**（另有 9 / 12 换行；**2026-09-22 修正批**把 id 形状行补回之后由 578 升到 591，见本条目末节），任何**必备**块的增加都会挤掉可选的自述块 —— 实测会先掉 DEFECT-4 的标题段，进而让「确认框说明设了什么标题」那条既有断言变红。
- **`question` 未加 `intent: plan-review`**：设计把它列为**可选**（「不必强求」），本批未启用 —— 壳的 plan-review 是一套**接管式**呈现面，为一句确认换面不划算。
- **逐字段裁剪只用省略号、不带计数**（只有**段落级**裁剪带「已裁剪至 …」标注）：给每个封顶字段加计数会让每处多约 8 码点，实测足以顶破 600 并挤掉上述标题段；字段级裁剪的诚实性由「省略号 ＋ 段落级标注」共同承担。
- **通道 1 的实机观察项**：壳可能**本来就**画出自己的 `kind:"command"` 通用行（`dsh-client-ui-chat` 也注册了一个），而本插件**无法查询「壳渲染了什么」** ⇒ 本批按设计实现通道 1 自带的顶层节点，**「是否与壳的通用行并存」留作真机观察项**。
- **未做真机验证**：本批全部读数来自两套单元套件 ＋ 隔离夹具的红相；宿主半边要等 DSH 重启窗口，§10.2.8.3 的客户端节点要重建客户端 bundle ＋ 刷新页面，**U33 的「渲染高度不超视口」依赖窗口宽度、刻意不作单测断言**。
- **`README.md` 的**两处**读数已由架构侧同批同步**（tests 徽章 → `951 + 269`、第 863 行「当前读数」→ `951` / `269`）✓。**原记「三处」是计数不实**（2026-09-22 只读审计第 7 条纠正）：被点名的第三处「第 880 行索引里的『判据 U30–U34，未落码』」**从未进过历史** —— `git log -S 未落码 --all` 只命中 `ee7c48a` 的**提交信息**一句，`git show ee7c48a^:README.md` 里 grep「未落码」**零命中** ⇒ 不存在一处「未同步的旧读数」，那句描述已删掉。

### 🔁 同批同步的面
`lib/index.js`（解析器 R1/R2/R3 与三个默认值、`teamSessionDialogQuestion`、`askTeamSessionBatch` 的两个槽位、`TEAM_SESSION_KEY_HINT` / `TEAM_SESSION_BODY_HINT`、命令 description 与 `input.hint`）；`lib/client.js`（§10.2.8.3 通道 1 的独立 definition ＋ 渲染面）；`host-half.test.mjs` / `client-half.test.mjs`（新增 U30–U34 与上述改写）；本条目；`docs/verification-log.md`。

### 🔧 2026-09-22 修正批 —— 只读发散审计 ＋ 代码评审的 **7 条**偏差收口

起因：一次**只读发散审计**（对 §10.2.8 的交付逐条对照）与一次**代码评审**各报出偏差，**去重后 7 条**。本批只修这 7 条，别处一字不动；其中**只有第 3 条是批次行为变更**，其余是渲染面（2 / 4）、断言（1）、注释（7）与文档读数（5 / 6）。

1. **审计 #3 / §10.2.8.4 (b) 的「只给 id 形状 ＋ 计数」零实现**：修法表第 0 行换槽位时，旧实现那行 `- 会话 id：team-link-<team>-<role>-<uuid8>`（`teamSessionIdPrefix()`，`git show ee7c48a^:lib/index.js`）**连同逐角色 id 清单一起被删掉**，于是「id 形状」在框里一处不剩。修：新增 `TEAM_SESSION_ID_SHAPE` 常量，把**形状 ＋ 总数**并进「会话」那一行（**不逐角色展开**照旧：仍只列前 3 个 ＋「…等 N 个」，全量清单仍只出现在完成回报里）。预算 **+35 码点**，按 §10.2.8.4 (b)「压缩只压自述段」从**可选**的 DEFECT-4 自述行里扣（删掉行内 `（DEFECT-4）` 标记与半句冗余），**必备披露一字未动**。
2. **评审 #1 / 审计 #2 的收尾：「同现 ⇒ 报错」两套件零断言**：§10.2.8.2 那句「正文与 `task=` 同现 ⇒ 报错」经**只读审计与代码评审两次独立认定可达**（反例 `team=t task=a model=m b`：`task=` 被后续已知 `key=` 截断、其后裸 token 走 R1(a) 成正文），而修法表第 0 行换槽位之后这条行为**零断言**。修：**行为一字不改**，只补两条断言 —— 反例 ⇒ 报「任务只能给一处」并点名正文起点 `b`；引号形 `task="q" 正文` ⇒ 同样被拒。
3. **审计 #4 / §10.2.8.2 默认值第 4 条：「既无正文也无 `task=`」却仍驱动会话**：`plan.task === undefined` 时实现仍然 `followup` 一具 kickoff（= 插件替人类编了一条他没写的任务）。修：该支**不投启动任务**（drive 循环只在有任务时跑），确认框与完成回报的措辞同批改准（框里「未给正文/task=，只建会话、不投启动任务」、回报里「已创建（未给正文/task=，不投启动任务）」）。
4. **评审 #2 / U33 的 600 码点被顶破**：`model=` / `provider=` 由用户给、解析器只定形状**不定长度**，而 `teamSessionModelLine` 把它们**原样内插** ⇒ 一句 300 字的 `model=` 就把 `detail` 顶到 **789 码点**（红相实测）。修：两者并入 `TEAM_SESSION_DIALOG_FIELD_CHARS`（`model: 40` / `provider: 24`），与团队名 / cwd / 会话 id 走**同一封顶**。
5. **审计 #6 / 红相逐条读数不实**：原记「U30（9 条）/ U31（4 条）/ U33（9 条）全红」，同夹具实跑的分布是 **U30 7/9 · U31 4/4 · U33 8/9**（＋ 改写的既有 U16 10 条 ＋ DEFECT-4 槽位 1 条 = **30**）；**旧实现上本来就绿的有 3 条**，已在本条目上一条与 `docs/verification-log.md` 里逐条点名。**红相总数 30 / 22 不变。**
6. **审计 #7 /「README 三处未同步」实为两处**：第三处（第 880 行「判据 U30–U34，未落码」）**从未进过历史**（`git log -S 未落码 --all` 只命中 `ee7c48a` 的提交信息；`ee7c48a^:README.md` 里 grep「未落码」零命中）⇒ 计数改为**两处**，不存在的第三处描述删除。
7. **评审 #4（低）/ 注释失真**：`TEAM_SESSION_KEYS` 的注释称「**按 hint 列出的顺序**」，而数组顺序（`n, count, team, roles, role, task, preset, model`）与 `TEAM_SESSION_KEY_HINT` 的书写顺序（`n / team / roles / preset / model / task`）并不一致 ⇒ **改注释措辞**（不改数组、不改行为）。

**怎么验证（变异验证，本批）**：

- **修复前必红**（隔离夹具 `.test-tmp-head/`：**本批的新测试** ＋ `git show HEAD:lib/{index,client}.js` ＋ 本树 `README.md` / `package.json`，在夹具目录里跑）：`node host-half.test.mjs` → **`957 (failed: 4)`**，4 条逐字点名 —— **U33 id 形状在场**（`hasShape:false`）· **U33 长 model= 封顶**（`{cp:789, nl:9}`，评审 #2 那句）· **U30 默认值第 4 条**（`{creates:2, followups:[1,1]}`，审计 #4 那句）· **U30 默认值第 4 条（措辞同步）**。`node client-half.test.mjs` → **`269 (failed: 0)`**（本批未触浏览器半边）。
- **修复后全绿**：`node host-half.test.mjs` → **`957 (failed: 0)`**；`node client-half.test.mjs` → **`269 (failed: 0)`**。新增 **6** 条宿主断言（id 形状 1 ＋ 同现 2 ＋ 默认值第 4 条 2 ＋ 长 model= 1），基线 `951`（`957 − 951 = 6`）。
- **两条「同现」断言是活锁（单点变异）**：撤掉「任务只能给一处」那处拒绝（`if (value.task !== undefined) {` → `if (false) {`）⇒ **`957 (failed: 1)`**，**恰是**那条新断言 —— 整轮 957 条里**没有第二条**断言发现这件事（= 修前它对这条行为确实零覆盖）；撤掉引号形的「闭引号之后不许再有内容」⇒ 套件在 `host-half.test.mjs:5070`（既有断言，该处读 `.error.includes` 没有 Y7 类型护栏）**当场崩**、连 `assertion total` 都不打印 ⇒ 该分支本来就被既有断言咬住，本批那条是**第二把锁**。
- **U33 重测读数（本批，逐用例，全部 9 / 12 换行）**：常规 **591 / 600 码点**、8 会话 ＋ 3000 字正文 **577**、长 cwd **593**、39 字团队名 **534**、团队名与 cwd 都长 **585**、DEFECT-4 槽位用例 **596**、无正文无 `task=` **563**、**300 字 `model=` 564**；`question` 一律单行（27 / 37 / 38 / 46 码点，上限 120）。
- **夹具输入的同批调整（判据文本一字未改）**：五具**原本既无正文也无 `task=`** 的夹具（DEFECT-1 降级 / DEFECT-2 降级 / DEFECT-4 服务缺席降级 / DEFECT-4 rename 抛错 / U17 保留）补上了 `task=` —— 它们断言的是「缺服务时**照建照驱动**」，而新默认下这一支**不再驱动**；补 `task=` 是**保住原有覆盖**，不是把断言改软（新默认自己有默认值第 4 条那两条断言）。

**如实标注（本批）**：

- **必备披露块在最极端的组合下仍可顶破 600 码点（设计缺口，可复现）**：per-field caps 那套「保证**每一个**输入都装得下」的说法**修前就已经不成立** —— 实测（20 字团队名 ＋ 8 个已登记角色 ＋ 300 字 `model=` ＋ 60 字 `preset=` ＋ 3000 字正文 ＋ 长 cwd ＋ 60 字协调者 id）**修前 633 码点**，补回 id 形状行之后 **668 码点**，而 `dialogFits` 的裁剪**只丢可选自述段**（设计明令必备披露永不裁剪）⇒ 这一组合下 `detail` 必然超预算。本批**不自行发明**「裁剪必备块」的机制（那是设计面的事），如实记为**残余**；U33 的单测覆盖的是上面枚举的那批用例（最大 596）。
- **本批未改设计档**（`docs/collab-enhancements-design-2026-09-19.md` 不在本批文件清单内）：§10.2.8.2 默认值第 4 条与 §10.2.8.4 (b) 本来就是本批实现的依据，**没有需要改写的设计语句**；唯一与设计现状有出入的是上一条残余（设计未规定「必备块超预算」的处置）。

**同批同步的面（本批）**：`lib/index.js`（`TEAM_SESSION_ID_SHAPE`、会话行的 id 形状、`teamSessionModelLine` 的两个封顶、`TEAM_SESSION_DIALOG_FIELD_CHARS` 的两个新键、`teamSessionTaskNote` 与「确认则」两支措辞、drive 循环的任务守卫、完成回报的第三种结果、`TEAM_SESSION_KEYS` 注释）；`host-half.test.mjs`（6 条新断言 ＋ 5 具夹具补 `task=`）；本条目末节；`docs/verification-log.md`（§10.2.8 一节的逐条读数与新增的本批小节）。

### 🔧 2026-09-22 收口批 —— 交付代码评审第 2 轮 PASS 后的 **3 条**小项（🟡#1 · 🔵#3 · 🔵#2）

起因：交付代码评审第 2 轮（窄范围：修复轮新增约 63 行）**PASS**，余下三条小项都不涉及结构。本批**只收这 3 条**，别处一字不动：改动面 = 对话框的**一处文本分支** ＋ **一个 per-field 上限键** ＋ **一处注释**。设计依据同批补进 `docs/collab-enhancements-design-2026-09-19.md` —— **§10.2.8.2 默认值第 4 条**下的「同支纪律」（🟡#1）· **§10.2.8.4 (b)** 的 per-field 上限清单（`preset 24`，🔵#3）· **§10.2.8.6** 的「无任务分支保留为防御」（🔵#2）。

1. **🟡#1 / 「成本口径（保守）」那行与同一张框的承诺自相矛盾**：`teamSessionDialogText` 无条件写「成本口径（保守）：N 个会话 × 至少一个完整回合（**followup 驱动一次**，按各自模型计费）。」，而同一张框的「确认则」上一批已按 `plan.task === undefined` 分支化（无任务支写「不投启动任务」）⇒ 一面说**不投启动任务**、一面说 **followup 驱动一次**，后者会被读成「已经派活了」。修：成本行**按同一支**改写 —— 无任务支为「成本口径（保守）：本次 0 次驱动（未给正文/task=，不投启动任务；后续派活时按各自模型计费）。」，有任务支**一字不改**。判据新增在 U30 的「措辞同步」组里（`host-half.test.mjs`），并且**两侧都咬**（有任务支必须保留原意）——见下「变异 A2」。
2. **🔵#3 / `preset=` 复用角色的 8 码点上限**：`TEAM_SESSION_DIALOG_FIELD_CHARS` 没有 `preset` 键，对话框那一行读 `cap.role` ⇒ 常见 preset id 被封成 `claude-c…` 这类认不出的形状，而「模型/预设」行是 §10.2.4 的**必备披露**。修：`preset: 24` 入表（与 `provider` 同级），那一行改读 `cap.preset`。
3. **🔵#2 / kickoff 的无任务分支是防御性死分支**：`teamSessionKickoffText` 里 `perRole === undefined` 那一支对 `/team_session` **不可达** —— 唯一的驱动路径在 drive 循环处就按 `plan.task === undefined ? [] : created` 把无任务那一支整个挡掉（as-of 本批 `lib/index.js:5122`）；该函数另有导出面（`__testing.teamSessionKickoffText`，as-of `:8915`，仅供测试读数），不经那道守卫。**行为一字不改**，只在函数体首行加注释写明「不可达 ＋ 守卫在哪 ＋ 为什么保留」：将来若再加一条驱动路径（或有人挪走/放宽那道守卫），少了这一行就会让 kickoff **静默丢掉「任务」行**。

**怎么验证（变异验证，本批）**：

- **修复前必红**（隔离夹具 `.test-tmp-r3pre/`：本批的新测试 ＋ `git show HEAD:lib/{index,client}.js` ＋ 本树的 `README.md` / `package.json`，在夹具目录里跑）：`node host-half.test.mjs` → **`959 (failed: 2)`**，恰是本批的**两条**新断言，逐字点名 —— **U33 长 preset= 封顶**（`{"cp":595,"nl":9,"presetLine":"… · preset=ppppppp…"}`：60 字取值被封成 **7 字 ＋ 省略号**，即复用了角色的 8 码点）· **U30 默认值第 4 条（措辞同步 · 成本行）**（`{"noTaskCostLine":"成本口径（保守）：2 个会话 × 至少一个完整回合（followup 驱动一次，按各自模型计费）。",…,"cp":563,"nl":9}`）。既有 957 条在夹具里全绿 ⇒ 两条新断言是**加锁**，不是改写既有判据。
- **修复后全绿**：`node host-half.test.mjs` → **`959 (failed: 0)`**；`node client-half.test.mjs` → **`269 (failed: 0)`**（本批未触浏览器半边）。新增 **2** 条宿主断言（`959 − 957 = 2`，基线取上一批自报的 957）。
- **两条新断言都是活锁（单点变异，三具）**：**A（🟡#1 回退：成本行改回无条件那一句）** ⇒ **`959 (failed: 1)`**，**恰是**新的成本行断言（整轮 959 条里没有第二条发现这件事）· **A2（假修法：把「followup 驱动一次」半句在**两支上**都抹掉）** ⇒ **`959 (failed: 2)`**，新断言仍在列（它**两侧都咬**：有任务支必须保留原意），另带一条既有断言（U16 确认框的成本口径）⇒ 这条锁住的是「**按支写准**」，不是「把话删掉」· **B（🔵#3 回退：`cap.preset` → `cap.role`）** ⇒ **`959 (failed: 1)`**，**恰是**新的 preset 断言。三具变异逐字回退后均复跑 `959 (failed: 0)`。
- **`preset` 上限直接量到**：60 字取值 ⇒ 框里 `preset=` 后是 **23 字 ＋ 省略号**（上限 24），不再是上一批的 **7 字 ＋ 省略号**（上限 8）。
- **U33 重测读数（本批，逐用例，`detail` 码点 / 换行）**：常规 **591/600**（9/12）· 8 会话 ＋ 3000 字正文 **577** · 39 字团队名 **535** · 110 字 cwd **594** · 两者都长 **585** · DEFECT-4 槽位用例 **597** · 既无正文也无 `task=` **564** · 300 字 `model=` **564** · **60 字 `preset=` 543（本轮新增用例；自述段被裁剪、标注在场）**。**无任务支那几条各 +1 码点**（成本行 49 → 50：改写后的措辞比原句更短，抵消了「0 次驱动」与「不投启动任务」两处新信息）。
- **同支纪律的代价（实测，如实）**：改成同支之后，无任务支的成本行**只许长到 53 码点** —— DEFECT-4 槽位用例（`n=2 team=title-dialog roles=worker-a,worker-b`，正是无任务支）的交付预算是 **597/600**，余量 3 码点。第一稿照父侧示例写满「后续由主会话派活时按各自模型计费」（59 码点）会让**正文（必备块 ＋ 标题段）**达到 **606 > 600** ⇒ **裁剪丢掉可选的自述段**、让既有的「DEFECT-4 ② 确认框说明设了什么标题」断言当场变红（本批实测复现）。故取**同义更短**的措辞（50 码点，净 +1）：既守住「不得自相矛盾」这条判据，**又不用**改那条既有断言、也不用给它补 `task=`。
- **红线回归（本批）**：`lib/` 内 `ctx.session`（**单数**）/ `appendEvent` / `session.log` / `.append(` 仍各 **0** 命中；模块级 `inject` 仍恰 **4** 项；既有 schema key、投递门与 `source` 三成员、`/team_rotate` 文法面、浏览器半边（`lib/client.js` 一字未改）**均未触碰**；**未新增任何日志事件类型**。

**同批同步的面（本批）**：`lib/index.js`（成本行的两支、`TEAM_SESSION_DIALOG_FIELD_CHARS` 的 `preset: 24` 与那一行的 `cap.preset`、`teamSessionKickoffText` 的防御性注释）；`host-half.test.mjs`（2 条新断言）；`README.md`（tests 徽章与「当前读数」）；`docs/collab-enhancements-design-2026-09-19.md`（§10.2.8.6 那条的两处行号按本批 as-of 更新）；`docs/verification-log.md`（本批小节）；本条目末节。

**如实标注（本批）**：

- **`README.md` 的两个读数此前落后一批**：0.3.10 修正批把套件自报值推到 **957**（`951 + 6`），但那一批的「同批同步的面」里**没有 README**（只列了 `lib/index.js` / `host-half.test.mjs` / 本条目末节 / `docs/verification-log.md`）⇒ README 停在**上上批**的 `951`。本批按实测把徽章与「当前读数」一并改成 **`959`**（`957 + 2`，本批新增 2 条），并把这次**跨越**写在这里 —— 不要读成「本批新增 8 条」。
- **无任务支成本行的具体措辞属实现定夺**：设计只给判据（不得自相矛盾、须与「确认则」同支），未逐字规定文案；本批取「本次 0 次驱动（未给正文/task=，不投启动任务；后续派活时按各自模型计费）。」，长度受上一条实测约束（≤ 53 码点）。
- **本批未做真机验证**（与前两批同口径）：全部读数来自两套单元套件与隔离夹具；本批两处改动都只影响**确认框文本**，宿主半边仍要等 DSH 重启窗口才在真机生效。
- **本批未动**「裁剪标注不参与预算」那条已知残余（§10.2.8.4 残余行的「第二机制」）：`teamSessionDialogText` 的裁剪/标注逻辑与 `TEAM_SESSION_DIALOG_MAX_*` 两个常量**一字未改**，该残余仍待裁。

### 🔧 2026-09-22 会诊 #68 批 —— 裁剪标注不参与预算（U33 口径定档：**交付 `detail`**）

起因：上一批的**如实标注**里记下的「第二机制」残余 —— **裁剪标注行不参与 600/12 预算**（父侧独立实测，两轮评审均未发现）。会诊 **#68**（四份意见一致）已裁定修法，父侧把裁定写进设计档 **§10.2.8.4 (b) 的 (b) 行 / 残余行**与 **§10.4 的 U33 行**（三处，**本批不改设计档**，以那三处为唯一规格）。改动面 = 对话框终态的**构造**（一处）＋ 标注的**文案与档位**（一处）＋ 一处注释；`TEAM_SESSION_DIALOG_MAX_CODE_POINTS` / `MAX_NEWLINES` 的**数值一字未动**，**必备披露块一字未裁**。

1. **修了什么（结构：终态真过预算）**：被弃路径的终态此前是 `let text = candidate(kept, dropped)`（as-of `0f77d0a`：`lib/index.js:4754`）—— body 装进 600/12 **之后**才贴上标注，**不再过 `dialogFits`** ⇒ 交付 = 必备 body ＋ 标注（旧文案 **41 码点 ＋ 1 换行**）⇒ **凡 body > 558 即溢出**（与其内容无关，故不靠「某个输入的读数」立论）。修：**拟合循环与终态走同一个构造** —— `candidate(list, stillDropped)` 现在**自己**带预算判定（在档位表上 `find` 第一个装得进 `dialogFits` 的档，取不到就用最窄那一档），终态就是调它，于是「装得下」这句话说的是**交付串**（含标注），不是标价前的正文。
2. **修了什么（标注档位化）**：两档写成**具名常量** `TEAM_SESSION_DIALOG_CROP_NOTE_FULL` / `TEAM_SESSION_DIALOG_CROP_NOTE_MINIMAL`（由 `__testing.TEAM_SESSION_DIALOG_CROP_NOTE_TIERS` 导出，供单测直接量长度），模板按**实际 `dropped` 位数**算 —— 一位数时**全档 21 码点**、**最小档 11 码点**（各另加 1 换行），两位数各 +1，代码里没有写死的 21／11。选择策略 = **取能装进 `dialogFits` 的最宽档**；**两档都装不下时仍挂最小档交付** —— 那是**如实标注的受限超额**，且此时超额**只**由不可裁的必备 body 引起（机制一残余）。**任何档位都不再写「已裁剪至 600 码点 / 12 行上限」**：交付串可能正是超 600 的那一条，那句话**自证矛盾**。
3. **改掉一句假注释**：`teamSessionDialogText` 的 docstring 曾称那组 per-field caps 「is what makes the required set fit the budget for **EVERY** input」—— 实测反例（body 693）已证伪 ⇒ 改成**如实口径**（caps 让**常规与已验证的极端**装得下，**不是**对任意输入成立的不变式），并指回设计档 **§10.2.8.4 的残余行（第一机制）**。同一句话说法的**另两处**同批改准（`TEAM_SESSION_DIALOG_FIELD_CHARS` 的注释、`host-half.test.mjs` 里引用该理由的注释）—— **三处由同一条事实驱动**。

**为什么**（会诊 #68 的裁定理由，父侧核实）：600 的用途是「**人读到的那一行有界**」，而标注**自己就写着 600** ⇒ **标注必须计价**；不修的话，「合法输入 ⇒ 交付超 600」与「框里写着已裁剪至 600 码点」并存 —— **输出物自述与事实相反**。不变量收敛为一条：**交付 ≤ max(600, 必备 body ＋ 12)**（12 = 最小档 11 ＋ 1 换行）——「**标注永不是首个破约者**」。

**怎么验证（变异验证）**：

- **修复前必红**（隔离夹具 `.test-tmp-u33pre/`：**本批的新测试** ＋ `git show HEAD:lib/{index,client}.js` ＋ 本树 `README.md` / `package.json`；`HEAD` = `8991fc8`，夹具里的 `lib/index.js` 与 `git show HEAD:lib/index.js` **逐字节相同**已核对）：`node host-half.test.mjs` → **`964 (failed: 6)`**，六条逐字点名 —— 改写后的既有 **U33 长团队名裁剪标注**（`{"cp":535,"nl":9,"note":false,"contradictory":true}`：新文案不在、旧文案还在）· 改写后的既有 **U33 两者都长**（`{"cp":585,"nl":9}`）· 新的 **U33 标注档位**（`{"tiers":0,…}`：旧树上这两个常量**根本没导出**）· 新的 **U33 (i)**（`{"bodyCp":582,"cp":624,"nl":9}`）· 新的 **U33 (ii)**（`{"bodyCp":592,"cp":634,"nl":9}`）· 新的 **U33 (iii)**（`{"bodyCp":693,"cp":735,"nl":9}`）。`node client-half.test.mjs` → **`269 (failed: 0)`**（本批未触浏览器半边）。
  - **其中一条新断言在旧树上本来就绿（如实记，沿用修正批的同一口径）**：**U33 (iii) 机制一的成因可读** —— 它量的是「3 个角色已登记 ⇒ `（已登记，跳过）` 后缀 ＋ 必备披露在场」这件**既有行为**，不是本批引入的语义。
- **修复后全绿**：`node host-half.test.mjs` → **`964 (failed: 0)`**；`node client-half.test.mjs` → **`269 (failed: 0)`**。新增 **5** 条宿主断言（`964 − 959 = 5`，基线取上一批自报的 959）；**改写 2 条既有断言**（强度只增：标注在场由「逐字等于**全档常量**的产物」咬住 ＋ 两个预算仍然都断言 ＋ 新增「不含那句自证矛盾的话」）。
- **两条单点变异（`(i)` 必须红，逐条读数）**：
  - **(a) 去掉终态的 `dialogFits` 检查**（`notes.find((note) => dialogFits(note)) ?? notes[notes.length - 1]` → `notes[0]`）⇒ **`964 (failed: 3)`**，**恰是 (i)** `{"bodyCp":582,"cp":604,"minimalTier":false}` **/ (ii)** `{"bodyCp":592,"cp":614}` **/ (iii)** `{"bodyCp":693,"cp":715}` —— **(i) 当场变红** ✓，整轮没有第四条断言发现这件事。
  - **(b) 只留全档（删掉最小档回退）**（档位表只剩 `…CROP_NOTE_FULL`）⇒ **`964 (failed: 4)`**，除上述三条外**多红一条**：新的 **U33 标注档位**（`{"tiers":1,…}`）。**两具变异逐字回退后均复跑 `964 (failed: 0)`。**
- **U33 逐用例重测（本批，读数取自交付串 `detail`，码点 / 600，换行 / 12）**：

  | 用例 | 本批 `detail` | 上一批（收口批） | 变动 |
  | --- | --- | --- | --- |
  | 常规 `n=2 team=night-shift roles=worker-a,worker-b task=做接口` | **591**，9 | 591 | 0（自述段全装下 ⇒ 本来就无标注）|
  | 8 会话 ＋ 3000 字正文 | **557**，9 | 577 | −20（全档 22 取代旧标注 42）|
  | 39 字团队名 | **515**，9 | 535 | −20 |
  | 110 字 cwd | **594**，9 | 594 | 0（无标注）|
  | 团队名与 cwd 都长 ＋ 8 会话 ＋ 500 字正文 | **565**，9 | 585 | −20 |
  | DEFECT-4 槽位 `n=2 team=title-dialog roles=worker-a,worker-b` | **597**，9 | 597 | 0（无标注）|
  | 既无正文也无 `task=`（`team=t n=2`） | **564**，9 | 564 | 0（无标注）|
  | 300 字 `model=` | **544**，9 | 564 | −20 |
  | 60 字 `preset=` | **523**，9 | 543 | −20 |
  | **(i) 装得下的最坏夹具（必备 body 582）** | **594**，9（**最小档**：全档 604 装不下）| — | 新增（改动前 **624** ✗）|
  | **(ii) 带内夹具（必备 body 592）** | **604**，9（＝ 必备 body ＋ 12）| — | 新增（改动前 **634** ✗）|
  | **(iii) 机制一夹具（必备 body 693）** | **705**，9（＝ 必备 body ＋ 12）| — | 新增（改动前 **735** ✗）|

  **超 600 的两行与为什么**：**(ii) 604** —— 必备 body 592 已落在 (588, 600] 这条带里，600 − 588 = 12 的余量装不下 21 码点的全档 ⇒ 交付**最多**超 **body ＋ 12 − 600 = 4**，且**必带标注**（这正是会诊 #68 定下的那条不变式）✓；**(iii) 705** —— 机制一残余：**必备块本身就 693**，而它**永不裁剪** ⇒ 超额**只**由必备 body 引起（设计档 §10.2.8.4 残余行 · 第一机制），本批**不**发明「裁剪必备块」的机制。其余十具**全部 ≤ 600**。**`question` 一律单行**（本批 27–46 码点，上限 120）。
- **红线回归（本批）**：`lib/` 内 `ctx.session`（**单数**）/`appendEvent`/`session.log`/`.append(` 仍各 **0** 命中；`sessionQuery` **8**、`commands.register` **3**（与上一批同读数）；模块级 `inject` 仍恰 **4** 项；**未新增任何日志事件类型**；既有 schema key、投递门与 `source` 三成员、`/team_rotate` 文法面、浏览器半边（`lib/client.js` **一字未改**）**均未触碰**。

**如实标注（本批）**：

- **历史读数不改**：本条目上两节（修正批 / 收口批）的 U33 读数表是**同一棵树不同时刻**的读数，按本仓「只追加、不重写历史」的纪律**一字未动**；凡**标注在场**的用例本轮各 **−20** 码点（41 → 21），**无标注**的用例**一字未变** —— 全量新表见本节「**U33 逐用例重测（本批，读数取自交付串 `detail`…）**」那张表。
- **(b) 行的「取最宽档」与残余行的「两档都装不下仍挂最小档」并不冲突**：前者的「装得下」指 `dialogFits`，后者是**两个承诺（有界 / 必带标注）不能同时成立**时选了「标注在场」（会诊 #68 的裁定），代价是**如实标注的超额**。
- **本批未做真机验证**（与前三批同口径）：全部读数来自两套单元套件与上述隔离夹具；本批只改**确认框文本的构造**，宿主半边仍要等 DSH 重启窗口才在真机生效；「渲染高度不超视口」照旧是设计显式降级的**真机项**。
- **本批未改设计档**：`docs/collab-enhancements-design-2026-09-19.md` 不在本批文件清单内 —— §10.2.8.4 (b) / 残余行与 §10.4 的 U33 行是**父侧刚写的规格**，本批逐字实现它。

**同批同步的面（本批）**：`lib/index.js`（终态构造 `candidate` 的预算判定、标注两档的具名常量与 `teamSessionDialogCropNote(dropped, tier)`、`__testing` 的档位导出、三处注释口径）；`host-half.test.mjs`（5 条新断言 ＋ 2 条既有断言的文案与强度 ＋ 一处理由注释）；`README.md`（tests 徽章与「当前读数」）；`docs/verification-log.md`（本批小节：夹具、病灶 `lib/index.js:4754`（as-of `0f77d0a`）、变异表、U33 逐用例重测表、红线复测）；本条目末节。

---

### 🔧 2026-09-22 裁定 A 批 —— 确认框收紧（U33c：参照夹具 **≤6 行 / ≤350 码点**）

> **判据后于同日放宽到 ≤380**（偏差修复轮把有任务支被漏删的「按各自模型计费」放回，+8 码点）：本节读数按「只追加、不重写历史」原样保留，凡与修复轮读数不一致处以下一节的「偏差修复轮」为准（参照夹具复算 **353 / 6 行**、28 码点 id **369 / 6 行**、机制一 **615**）。

**设计（唯一事实源）**：`docs/collab-enhancements-design-2026-09-19.md` **§10.2.8.4 修法表 (c) 行的「已裁（2026-09-22 用户裁定 = A）」**（父侧刚写入，本批**不碰设计档**）· 判据 **§10.4 U33** · 同表 §10.2.8.7 裁定 2（角色指引行）。逐条红相/绿相读数见 `docs/verification-log.md` 的「§10.2.8 裁定 A 批」一节。

**① 改了什么**（三处，全在本插件；宿主半边 ⇒ 需 DSH 重启才在真机生效）：**确认框正文从 10 行收到 6 行、参照夹具 569 → 345 码点**。

- **「- 会话标题：…」自述段整段移出框体**（它本来就是框里唯一的 `required: false` 段）。**读数没有丢**：它落在**完成回报**的 `- 标题（DEFECT-4）：…` 那一行（该行**改前就在**、本批一字未动）。
- **解释性括号与 § 号压掉**（用户点名要压的那几处，逐条见下表）：「（绕过发送方审批与接收方 ask 两道门，§10.2.3 预置配对）」「（保守）」「未给 model=/provider ⇒ 两半都解析并带上宿主缺省模型选择」「不设标题时它们会全都显示为工作区名；想改随时在壳里重命名」，另加两处同类的字数：`工作目录（cwd）：` → `cwd：`（同义 gloss）、**没被截断时**不再把「完整正文会原样作为启动任务投递」重复一遍（它已经显示在眼前）。
- **九件必备事实落进六行**（不是删事实，是并同族）：① 数量 ＋ 角色与 id 形状 · ② 模型/预设 ＋ cwd · ③ 启动任务 · ④ 角色指引（**单独一行**，§10.2.8.7 裁定 2 要求「各加一行」）· ⑤ 成本口径 ＋ 信任授予 · ⑥ 确认则。**§10.2.4 必备五件（数量 / 模型 / cwd / 成本 / 信任授予）一件不少**，`共 N 字` 标注、确认则两支、id 形状与计数全部在场（逐件点名断言，见下）。

| 位置 | 改前 | 改后 |
| --- | --- | --- |
| 标题自述段 | `- 会话标题：worker-1（标题：…）——不设标题时它们会全都显示为工作区名；想改随时在壳里重命名。` | **整段移出**（完成回报承载同一读数）|
| 数量 / id 形状 | 两行（`将创建 N 个…。` ＋ `- 会话 id：<形状>（共 N 个）：…`） | **一行** |
| 模型 / cwd | 两行，模型行含教学式说明 | **一行**：`- 模型/预设：宿主缺省；cwd：…` |
| 成本 / 信任授予 | 两行，含「（保守）」与「§10.2.3 预置配对」 | **一行**，虚词压掉、事实保留 |
| 角色指引 / 确认则 | 两行 | **两行**（角色指引单独一行不变）|

**② 为什么**：真机上确认框**动作可达**（缺陷③的原始症状未复现 ✓），但用户实测判「**有点大，文字也太多了，导致选项被积压**」✗ —— 同一输入的 `detail` 实测 **569 码点 / 10 行**（用户截图那次协调者 id 取满 28 码点 ⇒ **585**），用满 600 预算。用户裁定**方案 A**（收方向，不是只移标题段、也不是把披露全搬进回报）。

**③ 怎么验证**（两套件实测 `966 (failed: 0)` / `269 (failed: 0)`；基线 `964` / `269`）：

- **红相**（隔离夹具 `.test-tmp-u33a/`：本批新测试 ＋ `git show HEAD:lib/index.js`）：`966 (failed: 15)`，其中 **U33c 两条**（参照夹具 **569 码点 / 10 行** > 350/6 ⇒ 红；删除面 10 条**逐条全部还在** ⇒ 红）· **U33 必备披露逐件点名**（缺 cwd / 成本 / 信任授予 / 确认则（两支）——旧文案的字面与新判据不同）· **(i)/(ii)/(iii)** 三具夹具（旧实现 594 / 604 / 705）· 以及**改写措辞**影响的既有断言 **9** 条（2 ＋ 1 ＋ 1 ＋ 1 ＋ 1 ＋ 1 ＋ 1 ＋ 1；**计数勘误**：此处原写「8 条」，而右栏与 `.test-red-a.log` 的 15 行 FAIL 都指向 **9** 条，2026-09-22 偏差修复轮同批改准，构成见 `docs/verification-log.md`）。**客户端 269 (failed: 0)**（`lib/client.js` 本批一字未改，红相不该动它）。
- **变异验证两条**（新断言是不是活锁）：**(a) 把删掉的解释性文字加回一处**（信任行补回「（绕过发送方审批与接收方 ask 两道门，§10.2.3 预置配对）」）⇒ `966 (failed: 3)`：**U33c 参照夹具当场变红（379 > 350）** ＋ 删除面点名两条 ＋ U16 信任授予那条；**(b) 删掉一件必备披露**（整句「信任授予：…」）⇒ `966 (failed: 3)`：**U33 必备披露逐件点名当场变红，并逐件点名缺的是「信任授予」** ＋ 机制一夹具守卫（body 551 不再 > 600）＋ U16 信任授予那条。两具逐字回退后复跑 `966 (failed: 0)` ✓。
- **红线回归**：`lib/` 内 `ctx.session`（**单数**）/ `appendEvent` / `session.log` / `.append(` / `ctx.commands` 仍各 **0** 命中；`sessionQuery` / `commands.register` 仍 **8** / **3**；模块级 `inject` **仍恰 4 项**；`TEAM_SESSION_DIALOG_MAX_CODE_POINTS` / `MAX_NEWLINES` **数值一字未动**（600 / 12）；**必备块一字未裁**（裁剪机制只动可选段）；既有 schema key / 投递门 / `source` 三成员 / `/team_rotate` 文法面未触碰。

**④ 必须知道的一件事（如实标注，不是本批能决定的）**：移走「会话标题」段之后，框里**再没有** `required: false` 的段 ⇒ `dropped` 恒为 0，`dialogFits` 与两档裁剪标注**当前没有取用路径**（代码按用户裁定的「不许动：…两档标注与终态预算机制」**一字未改**地留着；两档文案的长度与「不含自证矛盾句」仍由一条**纯函数**断言咬住；一旦某段自述回到框里，取用路径立刻恢复）。同批把 U33 (i)/(ii)/(iii) 三具夹具改写成**现在真正成立的形状**：交付 `detail` **逐字等于必备 body**（不裁剪、不追加标注），机制一那一档（必备 body 607 > 600）**仍然必然超线**、超额只由不可裁的必备块引起。**此项已作为「需要父侧决定」的第一条写进交付报告。**

**⑤ 同批同步的面（本批）**：`lib/index.js`（`teamSessionDialogText` 的六行构造 ＋ `teamSessionModelLine` / `teamSessionTaskNote` 的措辞 ＋ 五处注释口径）；`host-half.test.mjs`（新增 U33c 两条断言 ＋ 必备披露**逐件点名**断言 ＋ 改写 13 条既有断言的文案/形状）；`README.md`（tests 徽章与「当前读数」→ `966`）；`docs/verification-log.md`（本节）；本条目。

### 🔧 2026-09-22 偏差修复轮 —— 独立发散审计 `DIVERGENCE(5)` 收口

**设计（唯一事实源）**：`docs/collab-enhancements-design-2026-09-19.md` §10.2.8.4 修法表 (c) 行的「落码读数 …… **判据定档**」与「**380 的来由**（审计 DIVERGENCE #4 后定档）」＋ §10.4 U33 行末的「裁定 A 落码后的口径更正」（父侧同批写入，本批**不碰设计档**）。**任务书就是偏差清单**：独立发散审计判 `DIVERGENCE(5)` —— 实现面的九个必备事实与裁剪机制**无偏差**，5 条全在读数/计数/规格口径/未申报删字/恒真断言上。逐条红相/绿相读数见 `docs/verification-log.md` 的「§10.2.8 偏差修复轮」一节。

**① 改了什么（五条偏差逐条 ＋ 一项附带）**：

1. **放回一条被漏删的必备事实**（偏差 4，**先修**）：有任务支成本行原为「成本：N 个会话 × 至少一个完整回合（followup 驱动一次，**按各自模型计费**）」，裁定 A 落码时把「按各自模型计费」**一并删掉**了 —— 它**不在裁定清单里**，且属**成本口径**（每队各按自己的模型计费；无任务支一直保留着它）。⇒ **放回**（`+8` 码点，行数仍 6）。
2. **判据口径写齐**（偏差 3）：设计档定档 **≤ 6 行（硬）且 ≤ 380 码点**，而实现注释与 U33c 断言仍写 ≤350 ⇒ 两处同批写到 **380**，并**如实留下 350 → 380 的放宽与理由**（换回一条必备事实；**不是**「本来就 380」）。
3. **删掉一条恒真断言、换成正面判定**（偏差 5，**选 (a)**）：`u33RequiredBodyOf(detail) === detail` 这类「右边从 `detail` 自己算出来」的写法在裁定 A 之后**结构上恒真**（注释却称它防「假绿」）⇒ 包装删除，改对**交付串本身**正面断言「框内**没有**段落级标注」（标注形状行数 = 0），两条同类反锁一并核过。
4. **文档读数复算**（偏差 1）＋ **计数勘误**（偏差 2）：「全夹具逐用例读数」表有 **7 行**用了 **14 码点 cwd**（真夹具的 cwd 字段封顶 **24**）⇒ 真夹具复算（该 7 行**两列各 +10**）；「既有断言 **8** 条」应为 **9**（`docs/verification-log.md` 病灶表与本节 ③ 同批改准，红相 15 的构成 = U33c 2 ＋ 逐件点名 1 ＋ (i)(ii)(iii) 3 ＋ 既有 **9**）。
5. **附带**：`lib/index.js` 里说 `dialogFits`「常规路径上不再被调用」的注释改为如实口径（**任何路径都不被调用**）。

**② 为什么**：这 5 条里有 3 条是**我们自己的账没记准**（读数、计数、规格口径），1 条是**没申报就删了用户要的事实**，1 条是**把恒真式说成守卫**。用户的裁定只授权「压掉解释性文字与整段自述」，**没有**授权删成本口径；判据从 350 放宽到 380 是**有代价的放宽**（换一条事实的回归），必须写明来由而不是悄悄改数。

**③ 怎么验证**（两套件实测 `966 (failed: 0)` / `269 (failed: 0)`，与修复前**同计数**）：

- **红相**（隔离夹具 `.test-tmp-fix/`：本批新测试 ＋ `git show HEAD:lib/index.js`）：**`966 (failed: 3)`**，三条全咬放回的那条事实 —— U33c 参照夹具（成本口径那半句）· U33 必备披露逐件点名（`（缺：["成本"]）`）· U30 成本行同支纪律。
- **变异验证两条**：**(A) 把段落级标注人为塞回** ⇒ `966 (failed: 6)`，6 条**全部**点出那行标注（U33 (i)(ii)(iii) · 长团队名 · 两者都长 · U33c 7 行）⇒ **新的正面断言可假、不是恒真** ✓；**(B) 把一处解释性文字加回**（+34 码点）⇒ `966 (failed: 3)`：**U33c `387 > 380`** ✓ ＋ 删除面点名 ＋ U16 信任授予。两具逐字回退后复跑 `966 (failed: 0)` ✓。
- **复算读数（真夹具，24 码点 cwd）**：参照夹具 **353 / 6 行**（12 码点 id）与 **369 / 6 行**（**28 码点 id = 真机那一次**；原 585 / 10 行）；机制一残余必备 body **607 → 615**（仍 > 600，永不裁剪）。
- **红线回归**：`ctx.session`（**单数**）/ `appendEvent` / `session.log` / `.append(` 仍各 **0**；`sessionQuery` / `commands.register` 仍 **8** / **3**；模块级 `inject` **仍恰 4 项**；`TEAM_SESSION_DIALOG_MAX_CODE_POINTS` / `MAX_NEWLINES` **数值一字未动**（600 / 12）；裁剪机制与必备块**未触碰**；既有 schema key / 投递门 / `source` 三成员 / `/team_rotate` 文法面未触碰；`lib/client.js` 与 `README.md` **一字未改**（断言总数未变 ⇒ 徽章与「当前读数」本就正确）。
- **同批同步的面（本批）**：`lib/index.js`（成本行放回半句 ＋ 四处注释口径：判据定档/380 的来由/块内判据/`dialogFits` 调用面）；`host-half.test.mjs`（U33c 判据 350→380 ＋ 放宽理由注释 ＋ 恒真包装换成正面判定 ＋ 成本口径三处判据改写，**断言条数不变**）；`docs/verification-log.md`（病灶表计数 8→9 ＋ 复算表 ＋ 新增「偏差修复轮」一节）；本条目。
- **如实标注**：**未新增/删除任何断言**（`966` / `269` 不变 ⇒ `README.md` 的两处读数不需要动，也没有动）；**未做真机验证**（宿主半边，需 DSH 重启）；**未改设计档**。

### 🆕 §10.2.8.9 / §10.2.8.10 三条新语义落码（2026-09-22 用户裁定）

> 设计（唯一事实源）：`docs/collab-enhancements-design-2026-09-19.md` **§10.2.8.9**（① 默认团队名带日期 · ② 现任失联则释放并认领团队名）与 **§10.2.8.10**（① 调用方回执 = 通道 4 · ② 无任务也投最小唤醒）。验收落在 `host-half.test.mjs` 的 **U35 / U36 / U37** 与「**U32 通道 4**」两组 ＋ U30 默认值第 4 条的**反转**三条。

**① 改了什么**

- **默认团队名带日期（§10.2.8.9 ①）**：`/team_session` 省略 `team=` ⇒ `<basename(cwd)>-YYYYMMDD`（本地时区，**一条命令只取一次**；目录名不合 `[a-z0-9-]+` 回退 `default-YYYYMMDD`）。**孤立后果如实**：**无日期的既有团队仍完全有效**，但只能用**显式 `team=`**（或设置 UI）触达 —— **默认名永不再解析到它们，且不做任何迁移**。`team` 字段封顶 **20 → 32**（带日期的默认名 29 码点必须完整显示）。
- **现任失联 ⇒ 释放并认领（§10.2.8.9 ②）**：**只有确证**「已归档」（`workspaceRegistry.archivedSessionIds` 含它）**或**「已不存在」（`sessionQuery.filterSessions([{kind:"id",values:[…]}])` 返回空）才放行；动作是**同一道命令里**把那一段任期收口（`until=now` ＋ 备注 `released: coordinator archived|gone`）→ `current := null` → 调用会话认领。**保留既有角色与版本史**，`policy.writer` **仍是 `coordinator`**（不放宽成 `any`）。**fail-safe 两情形互斥**：**(甲) 服务未提供** ⇒ 跳过归档信号、只按 `gone` 判；**(乙) 服务在但读不到** ⇒ `unknown` ⇒ **拒绝**。**落笔前复检一次**（现任复活 / 归档态变了 / 现任换人 ⇒ **中止且零写入，连 pairs 也不写**）。**只看现任**：换届换下的旧任归档**不**触发。
- **调用方回执（§10.2.8.10 ①，通道 4）**：命令**结算后**给**调用方会话**投一条**一行 ≤120 码点**的回执（**成功 / 失败 / 取消三态都算**），信封沿用 kickoff 那条**恰三成员**的 relay。**解析前失败**（如 `n=abc`）**不硬塞团队名**。
- **无任务也投最小唤醒（§10.2.8.10 ②，默认值第 4 条反转）**：既无正文也无 `task=` 时**不再「只建会话」**，改投一具**待命通知**（含①「本次命令未给任务」②「你已被创建为团队 X 的角色 Y」③「请等待主会话派活」；**不含任务内容、不要求它做事**）⇒ 每个新会话都有回合 ⇒ **在侧边栏可见**。
- **成本口径连带改写**：框内成本行由「N 个会话 × 至少一个完整回合（**followup 驱动一次**）」改写为**回合计数口径** `N＋1 个回合（N 个新会话 ＋ 1 条调用方回执；按各自模型计费）` —— 两支**逐字同形状**（有任务 N＋1、无任务也 N＋1），所以它**不再分支**，也就不可能与同一张框的「确认则」自相矛盾（🟡#1 的同支纪律由「不写任何 branch-specific 断言」满足）。**这是一次经申报的改写**：让位的是机制短语「followup 驱动一次」（机制由「确认则：创建 → 投递启动任务」承载），「**按各自模型计费**」**逐字保留**（DIVERGENCE #4 的回归）。

**② 为什么**

- 默认名带日期：用户原话「默认团队名 需要加上工作区目录+日期，这样好点」；同日重复发命令仍指向**同一个团队**（§10.2.6 幂等一字未动），跨天才自然另起一队。
- 释放并认领：用户原话「如果团队主管会话被归档（现任主管，被换届的老主管会话不算），应该自动释放团队名」——**没有这条**，一个被归档的现任会把团队名永久卡死（`writerGate` 只认现任，而现任回不来）。
- 调用方回执 ＋ 最小唤醒：真机观察 2/3/4 —— 壳只列「至少跑过一个回合」的会话 ⇒ **在空会话里发命令**、以及**不带任务建出的 worker**，都**在侧边栏隐身**。用户原话：「让插件给调用方会话投一条回执，这样才能把会话出来」＋「改回『投一具最小启动任务』」。

**③ 怎么验证**（两套件实测 `995 (failed: 0)` / `269 (failed: 0)`，基线 `971 (failed: 0)` / `269 (failed: 0)`；**+24 条断言**）

- **变异验证三条（逐条实跑，每条只红它该红的那条）**：**(A) 把 (乙) 的 `unknown` 改成「读不到就释放」** ⇒ `995 (failed: 1)`，恰好红「U37 (乙)」；**(B) 把「只看现任」改成「看任一历史任」** ⇒ 恰好红「U37 变异基线 2」（同跑另见一条**既有计时器夹具的偶发红**，见下）；**(C) 去掉写时复检里的活性那一半** ⇒ `995 (failed: 1)`，恰好红「U37 变异基线 3（TOCTOU）」。
- **红相（新测试 ＋ 旧实现，隔离夹具实跑）**：`995 (failed: 34)` —— 34 条逐条点名（U16 成本口径 1 · U33 2 · U33c 2 · U30 默认值 2 · U35 5 · U30 反转 4 · U32 通道 4 5 · U36 8 · U37 4），其中 3 条**负相**（`policy.writer` 边界 / 无新日志事件 / 只看现任）在旧实现上**本来就绿**，如实标注不算红相。**这次实跑还抓出我自己新测试的两个崩相**（未守卫的可测面读取 · 只在假分支求值的 `probe` 声明在后面 ⇒ `TypeError` / TDZ，`assertion total` 都不打印）—— 已按本仓 Y7 纪律修成「先取值再判类型」，教训记在 `docs/verification-log.md`。
- **逐具夹具读数**：**U35** 五条（格式 / 同日幂等纯函数 / 同日幂等命令级 / 跨日另起一队 / 无日期旧团队的孤立后果——**注入「当天」**，不靠墙钟）· **U36 (a)–(h)**（归档 / gone / 存活照旧拒 / 工具路径 / 保留既有角色 / 触发释放的框体 ≤6 行 ≤390 码点）· **U37 甲/乙两形状 ＋ 三条变异基线** · **U32 通道 4 六条**（成功 / 无任务形态 / 取消 / 解析前失败 / 解析后失败 / 无新日志事件）· **U30 反转三条**。**U33c 重测**：12 码点 id **355** · 28 码点 id **371** · 释放变体 **348 / 382**（28 码点 id ＋ 带日期团队名，最坏一具），判据 **≤390**（此前测试里写的 380 比设计档更严，本批与设计档对齐）。
- **真机已复验（2026-09-22 重启窗口；这一条取代原先的「未做真机验证」）**：工具面的「释放并认领」、`/team_session` 的**释放 / 回执 / 最小唤醒 / 确认框**四项、**侧边栏三会话可见**、以及**结算时序读数**（`command/done → 回执落盘 0.288 s`，回执花掉的模型回合在其后）都在真机上验到 —— 逐条读法与截图证据见 `docs/verification-log.md` 的「真机复验」一节。**这次复验还抓出一个我漏补的判据**：设计档 🟡#7 要求补一具「无任务形态」的框体读数，我漏了，而真机那一次命令恰好落在它上面 ⇒ **修前 399 码点 > 390**（重复文案所致）⇒ 压掉重复（−18）后 **381**，夹具已补（参照 F/G/H/I）。
- **如实标注**：**§10.2.8.10 的实现期兜底没被触发**（回执走的正是先试的 handler 内 `followup`）；**设计档的两处计数/读数勘误**已同批改（该披露句字面量逐字数 **11**，原写「12 码点」；§10.2.8.9 ② 的 `364 / 380` 是**改写成本行之前**的读数，重测后为 `348 / 382`）；**一次既有计时器夹具的偶发红**（「缺口1 超时读数自报真实后果（计时器到点）」，连续两次复跑均绿，与本批无关）如实记录、不计入本批证据。
- **真机收尾（同日）**：三个一次性探针团队按 `retire` 退役 —— `rm-probe-20260922` 与 `dsh-session-link-pro-20260922` 由本会话发起（后者**先经 §10.2.8.9 ② 把那具幽灵现任释放并认领，再退役**），`rm-release-20260922` 由用户在其测试会话里发起（`retire` 顺带**清掉 2 条 pairs** ⇒ 退役那一步的**信任清理**也在真机走过）；三行现均 `vacant`。**团队行本身的删除没有工具面路径**（只有用户设置 UI），本批未碰；盘上那三个黑板目录已随退役一并删除（工作区里 `team/` 是未跟踪文件 ⇒ 删除无 git 影响）。

---

## 0.3.9 — 2026-09-21（发布前收口于 0.3.10）（加固与恢复）— ① 导出路由信任栅栏 · ② 恢复能力加宽 · ③ 侧栏「会话工具」入口 · ④ 深链聚焦修复

> 设计（唯一事实源）：`docs/hardening-and-recovery-design-2026-09-21.md` §4.1–§4.4（含 §5 红线 B1–B9 与 §6 判据 U1–U14）；逐条**红相/绿相读数**见 `docs/verification-log.md`。四条工作面按 §11 分三批实施，本条目随批次追加。
> **发布状态**：①② 属宿主半边，需 DSH 重启才在真机生效；③④ 属浏览器半边（客户端 bundle 重建 + 刷新页面）。真机复验点 1 的**拒绝面已闭合**（2026-09-21 重启后复跑，原始读数见 `docs/verification-log.md`「批次 4 · H 真机复验点 1 · 绿相（重启后）」一节）；**仍未闭合的真机面**（如实列出）：① 点 1 的「**同源带 cookie → 200 全量**」正路径**无读数**；② **点 2**（`reappoint` 用 threat-intel 真实 roster 形演练）**从未执行** —— 现有判据都是单元夹具形；③ 点 3 的**标题栏收起态**未核对。而点 3 的**宽态**与**收起态**已由 owner 在 3080 页面上真机确认（宽态：位于消耗卡**右侧**、【设置】上方；收起态：56px 轨道下只剩图标、与使用卡同一行）。与 0.3.8 同口径，**不把未验的东西说成已验**。

### 批次 1 —— §4.1：导出路由接入平台信任栅栏（两层 fail-closed）

**修了什么**：`GET /team-link/export` 此前是一个**没有任何信任检查**的路由——任何能连上本机端口的请求（DNS rebinding / 跨站页面）都能拉走整份会话事件流。本批把它接上平台自己的栅栏 `connection.requestRejection`（Host/Origin → 403、浏览器鉴权 → 401），并**两层都 fail-closed**：

1. **挂载期**：路由只在**同时**拿到 `webServer` 与 `connection`（且后者有 `requestRejection`）时才注册；新增两个 reason code `no-connection` / `no-rejection`，与既有 `not-active` / `no-register` 一样——**不注册路由 + 一行 warn**（点名缺的是哪一个）。晚挂从 `ctx.inject(["webServer"])` 改成 `ctx.inject(["webServer", "connection"])`，两个提供方任意顺序到齐才挂载。
2. **请求期**：handler 的**第一句**实时复检栅栏；取不到（服务缺席、方法缺失、或**挂载之后被拆**）⇒ `503` + 不吐数据；取到则把它的状态码**原样写回**，响应体与官方 `client-connection` 的 RPC 通道一致（401 `unauthorized` / 403 `forbidden`）。这一层覆盖挂载期判不到的那个窗口。
3. **方法白名单**：非 `GET` ⇒ `405` + `allow: GET`（对齐官方路由写法），任何会话都不读。

**为什么**：平台契约明确「路由所有者自负其责」（`dsh-host-webserver`：不做 server-wide 认证/来源策略），栅栏由 `dsh-client-connection` 提供给**每个**路由所有者；本插件此前全库 0 处调用它——这是一处**未文档化的安全缺陷**，不是被记录下来的取舍。

**怎么验证（变异验证）**：

- **修复前必红**（本批新增 14 条断言，基线 889 不动）：`node host-half.test.mjs` → `assertion total: 903 (failed: 10)`。10 条 FAIL 恰是本次要修的每一面：U1 纯函数不存在 / 跨站请求真的拿到 200 + 会话正文且 `readSession` 被调用 / 路由从未把请求交给平台栅栏 / 401 分支无人写回 / 挂载后栅栏消失仍照常吐数据 / U6 非 GET 被当 GET 服务 / U2「webServer 在、connection 缺」仍然注册了路由（无门路由真实存在）/ `no-rejection` 分支不存在 / U4 只到 webServer 就挂载。
- **修复后全绿**：`node host-half.test.mjs` → `assertion total: 903 (failed: 0)`；`node client-half.test.mjs` → `170 (failed: 0)`（未触及浏览器半边）。
- **红线 B1**：`connection` **没有**进模块级 `inject`（仍恒为四项），仍走 `ctx.get` + `ctx.inject` 的可选服务缝；断言直接读导出数组。
- 新增可测面：`__testing.exportGateRejection(connection, req)` —— `connection + req → 状态码|null` 的**纯函数**判定（U1 不必依赖 HTTP 夹具；接受 `null` = 放行、`503` = 无栅栏可问）。

**如实标注（设计未规定的一处实现选择）**：`503` 这一支的响应体写的是 `unavailable`，而 401/403 严格照官方（`unauthorized` / `forbidden`）。理由写进了代码注释：403 的含义是「栅栏说了不」，503 的含义是「**没有栅栏来裁决**」——把后者写成 `forbidden` 等于报告一个从未发生过的信任判定。

**同批同步的面**：`README.md`（§二 导出段新增「下载路由走平台信任栅栏」一段、§七 契约的服务清单、依赖服务降级表新增 `connection` 行、架构图的导出路由节点）；本条目。

### 批次 2 —— §4.2：恢复能力加宽两格（(a) `revive` 放开角色门 · (c) `reappoint` 常驻「自建继任者」）

**修了什么**：

1. **(a) 删除 `reviveIncumbent` 的角色门**——`revive` 现在受理**任意角色**（所有权门、`resume` 可用性检查、在场确认框、两次写前复检**一律不动**）。
2. **(c) `reappoint` 的候选集改为「活成员 ∪ 插件自建继任者（常驻）」**——合成候选 `自建继任者（新建会话）` **始终在列**（不是「仅 0 活候选时才出现」：事故当场的候选长度是 **1 不是 0**）。选中它时逐条复用既有链路：能力闸门（**批次 4 收窄到这条支路**：宿主无 `agents.create` ⇒ 弹框照开、候选里**不出现**「自建继任者」；**仅当活成员候选也为 0** 时才 fail-closed 报告且零弹框——活成员改任那条路不需要该服务）→ 按 §10.2.2 铸 id（`team-link-<team>-<role>-<uuid8>`）→ 交接文档由**插件从 roster 事实**生成五硬节（读不到的项——前任的进行中工作与 goal、未提交的改动——**如实标未知**，不编造）→ `prepare` 逐字跑 → 审计行 `verb=reappoint`。原有的「候选集为空 ⇒ 一条死路」分支因此**不可达并被删除**。

**为什么**：(a) `revive` 是**身份不变**的操作（不写 roster、不铸令牌、不动 pairs/trustedSenders/rememberTargets、不碰 `policy`），放开角色面不向「通用 roster 编辑器」移动一寸；而重载拆掉的是**所有**插件自建会话，不只 coordinator 的——§11.9.1 只论证过「死的 coordinator 必须可救」，从未论证「死的 worker 不许救活」。(c) 候选用尽时原本**没有出口**：全队只剩协调者一个活人时，唯一可选路径是「把一个 worker 角色硬塞给协调者」。

**怎么验证（变异验证）**：

- **修复前必红**：把**本批的新测试**跑在**批次 1 的 `lib/index.js`** 上（隔离夹具 `.test-tmp/s2-red/`：新测试 + 新 README + 旧实现）⇒ `assertion total: 920 (failed: 21)`，21 条 FAIL 全部落在本批断言上：U7 两条（插件自建的死 worker 被角色门拒）、U8（**连所有权门的文案都读不到**——角色门先拒，这正是「角色门挡在适用域之前」的实证）、U9 **九条**（对话框里没有合成候选、没有创建、没有交接文档、没有三处留痕；同组那条「新建的会话是根会话、meta 无血统字段」在修复前**本来就为真**——旧实现从不 `create`，`creates` 为空——所以它**不在**红相里，批次 4 重跑实测定档）、U10（无 `agents.create` 时既没有闸门也没有零弹框）、U11 与收敛性两条，以及**六条被本批语义变更推翻的既有断言**（U26 角色面 / Y1 对照 / Y1 文档面=实现面（双向锁）/ Y2 宣传面 / U27 候选由插件算 / U27 全队皆死）= 2+1+9+1+2+6 = **21**，与 `920 (failed: 21)` 逐字对上（原文记「U9 十条 / 五条」是**计数勘误**，加总 22 与实测差一条，批次 4 已按实跑读数改准——见 `docs/verification-log.md` 批次 2 的「计数勘误」小节）——设计 §9 A7 点名的「既有断言可能把非 coordinator 一律拒钉死」**实测成立**，本批按新语义改写这六条而不是删除（每条都留了改写说明）。**红相是干净的**：套件跑到底并打印了 `assertion total`（首版红跑因直接调用尚未存在的 `__testing.selfBuiltHandoffBody` 而崩在那一行、连总数都不打印，已按本仓 Y7 纪律加类型护栏——那正是 Y7 存在的理由）。
- **修复后全绿**：`node host-half.test.mjs` → `assertion total: 920 (failed: 0)`（新增 **17** 条，`920 − 903`）；`node client-half.test.mjs` → `170 (failed: 0)`（未触碰）。
- **红线回归**：所有权门原样（U8）、`writerGate`/三道门本体未动、`policy.writer` 未动、`claim` 一字未改、不新增令牌类型、**不新增参数**（`handoff` 没有进 recover 的参数面——交接正文由插件生成）、模块级 `inject` 仍 4 项。

**如实标注（设计没有逐字规定、由实现定夺的两处）**：

- **自建继任者的工作目录**：优先用**团队自己的 `workspace`**（该队的 roster 镜像与交接文档就在它下面），团队没记录时回落**发起会话的 cwd**；两者都取不到绝对路径 ⇒ fail-closed（零创建）。`process.cwd()` 一律不用（与 `successor:"auto"` 同一条边界）。设计 §4.2 (c) 未规定 cwd 的取法。
- **交接文档与 `prepare` 的先后**：按 **§11.9.6 的 abort-before-prepare**（文档失败 ⇒ 不铸令牌）排在 `prepare` **之前**，也就是与 `successor:"auto"` 同序；§4.2 (c) 的编号（③ prepare → ④ 文档）是**元素清单**而不是时序，本批取了与既有 auto 路径一致的时序。

**同批同步的面**：`lib/index.js` 的 `team_link_recover` description（两个动词的角色面 + 候选集 + 合成候选链路 + 代价声明）、`action`/`role` 参数文案、诊断行；`README.md` 的工具表、§11.9.4 恢复叙述（角色面 + 自建继任者段）、八条硬约束的 ③；`docs/collab-enhancements-design-2026-09-19.md` §11.9.4/§11.9.5 的两处增补。

### 批次 3 —— §4.3 侧栏「会话工具」入口 · §4.4 深链聚焦修复

**修了什么**：

1. **§4.3 入口**：侧栏底部新增「会话工具」——注册进官方 list 槽位 `sidebar.footer.action`（`id: team-link-session-tools`、`order: 0`）⇒ 入口落在**同一 flex 行内、位于消耗卡片 `order: -10` 的右侧**（`order: 0` 升序 ⇒ 排在它之后、【设置】之前）；**不是「下方」**：官方 `.footerActions` 是 `display:flex`（方向默认 row），且官方 sidebar 全档 `flex-wrap` 出现 **0** 次 ⇒ **不换行**，而插件**无法从子元素侧改变父级换行**（改父级 = 改官方文件，违反设计 §1.3 的红线 N5），2026-09-21 真机读数（owner 截图）与之一致——**原稿把「排在后面」写成上下排布，是对官方布局的错误推断，本行按设计 §4.3.1 更正**。本入口**不改任何官方文件**。宽态 = 图标 + 文字「会话工具」，收起态（56px 轨道）**只渲染图标**（文字转 `aria-label`/`title`）；点击 / Enter / Space 打开官方 **`Modal`**（居中、挂 body——锚定面板会被 56px 轨道裁切）。
2. **弹窗（§4.3.2）**：标题 + 当前计数 → 搜索框 → 会话列表（可滚动）→ 有界呈现标注 → 底部（范围切换 + 关闭）。数据源 = `ctx.sessions.list` / `ctx.workspaces.list`：丢弃 `origin === 'subagent'`、丢弃已归档、blank 行只保留当前会话（官方会话浏览器同款规则），按 `updatedAt` 倒序；当前会话 = `retainedBy.mainView > 0` 的那一行；**默认范围 = 当前工作区**，可切「全部工作区」。
3. **列表行（§4.3.3）**：状态点 **恰两态**（运行中 / 空闲，唯一数据源 `SessionSummary.running`）+ 标题（超长省略）+ 相对时间（用官方 `relativeTime` 分桶、本插件字典给词；「全部工作区」时追加工作区名）；「复制链接」「导出会话」**默认隐藏，悬停该行或焦点落在该行内才浮现**（CSS `opacity` + `:focus-within`）；点行本身 = 打开该会话。
4. **三个动作（§4.3.4）**：复制 = 剪贴板 `dsh://session/<id>`（与会话头部按钮**同一格式**）+ 短暂「已复制 ✓」+ `aria-live` 播报；导出 = **导航** `GET /team-link/export?session=…&format=md`（同源自动带 cookie、天然过 §4.1 的栅栏、零 CORS 面；参数必须编码）；打开 = `ctx.uiWorkspace.openSession(id)`（**运行时**经 `ctx.inject(["uiWorkspace"], …)` 取用）。
5. **状态与边界（§4.3.6）**：三种空态**三句不同的话**（读取中… / 没有匹配「xx」的会话 / 暂无其他会话）；超过显示上限时末尾写明「**共 N 个，仅显示前 M 个（搜索可收窄）**」；`sessions` / `workspaces` / `uiWorkspace`（以及 seed 模块的 `Modal`）缺任一项 ⇒ **入口不注册 + 一行 warn**，绝不渲染假按钮。
6. **键盘与无障碍（§4.3.7）**：Tab / Enter / Space 可用；关闭（Esc / 关闭按钮 / 成功打开）**把焦点还给入口**；动作按钮带独立无障碍名（含会话标题）；尊重 `prefers-reduced-motion`。
7. **§4.4 深链聚焦**：把 `ctx.sessions.open(id)` 换成 `ctx.uiWorkspace.openSession(id)`，并**保留**「等会话出现在 `sessions.list` 再聚焦」的重试循环；服务缺席只丢「聚焦」这一步，失败只留一行痕。
8. **`package.json` 的 `dsh.client.inject`** 增三项：`@deepseek-ai/dsh-client-ui-workspace`、`@deepseek-ai/dsh-api-session-controller`、`@deepseek-ai/dsh-api-workspace-controller`。**seed 模块 `@deepseek-ai/dsh-client-ui-primitives` 刻意不声明**（与 `react` 同级由 shell 注入）。

**为什么**：官方会话行的「…」菜单**没有扩展槽位**、且硬编码在 `node_modules` 的构建产物里（设计 §2.3）——改它等于旁路官方文件且会被升级静默还原；侧栏底部那个 list 型槽位是官方**声明允许任意插件注册**的座位。而深链聚焦是一处**静默空调用**（§2.4）：`ISessions` 公开面**没有** `open` 方法（同名的 `Session.open()` 是历史加载，另一回事），调用抛出的 TypeError 被 `try/catch` 吞掉 ⇒ 列表轮询到了、界面却停在原地。

**怎么验证（变异验证）**：

- **修复前必红（整批）**：隔离夹具 `.test-tmp/s3-red/`（本批新测试 + `git show 8d40343:lib/client.js`）⇒ `node .test-tmp/s3-red/client-half.test.mjs` → `assertion total: 193 (failed: 27)`。27 条 FAIL 全部落在本批断言上：9 条 §4.3 红相守卫（入口未注册 / 入口与弹窗工厂不存在 / 五条纯规则不存在）+ `§4.3 可测面` + 9 条被新语义推翻的既有计数断言（`fresh.length` 4→5、`names()` 多一行）+ 7 条 U14。
- **U14 单独红相（设计 §6 点名的那条）**：`.test-tmp/s34-red/`（当前实现**只**把 §4.4 那一行还原成 `ctx.sessions.open(id)`）⇒ `257 (failed: 7)`，其中判据那条即「**深链打开后当前会话 id 不变**」——以 `retainedBy.mainView` 判定，主视图仍留在启动时那个会话上（另有 4 条 U14 与 1 条病灶锁同时红）。
- **修复后全绿**：`node client-half.test.mjs` → `assertion total: 257 (failed: 0)`（新增 **87** 条 = 257 − 170：10 条红相守卫/可测面 + 77 条 §4.3/§4.4 断言；另有 **9 条既有断言**在同一批里按新语义改写——`fresh.length` 4→5 与 `names()` 多一行，见下条变异验证）；`node host-half.test.mjs` → `920 (failed: 0)`（本批未触碰宿主半边）。
- **红线**：不改官方文件；本插件**模块级** `inject` 仍恒三项（`slots` / `sessions` / `locale`）——三个新依赖只进 `dsh.client.inject`（模块图）与运行时 `ctx.inject`（服务）；本入口的动作集恰为「复制链接 / 导出会话 / 打开会话」，**不做任何会话写操作**。

**同批同步的面**：`README.md`（§二 新增「侧栏「会话工具」入口」小节与三种空态表、深链段的聚焦修复指针、§九「浏览器半边的模块声明」、§十 读数与口径、设计文档索引登记本档并修正 ③b「未实施」的既有失真、版本徽章 0.3.7→0.3.8、测试徽章 889+170→920+257、架构图加侧栏入口节点与导出边）；本条目；`docs/verification-log.md` 的批次 3 条目。

**如实标注（设计未逐字规定、由实现定夺的地方）**：

> **后续变更（批次 4 G，2026-09-21）**：**列表已改为丢弃当前会话**（见下文「批次 4」第 7 条 / 设计 §4.3.2 的可见性规则）——下面这条「列表包含当前会话」的说明**已被取代**，**不再**是当前行为；**原文保留**（本文件不改写历史条目）。当前行为的验收点：工作区里只剩当前会话时显示「暂无其他会话」且一行都不画。（同批「弹窗」条目里那句「blank 行只保留当前会话」同属被取代的旧口径。）

- **列表包含当前会话**：§4.3.2 的可见性规则里没有任何"排除当前会话"的话，且它明确要求"blank 行只保留当前会话"（以当前会话**在列表里**为前提）⇒「暂无其他会话」这句出现在**可见集为空**时（例如整个工作区都已归档）；工作区里只剩当前会话时，列表如实显示那一行、不报空。
- **打开成功后关闭弹窗**：导航本身就是回答，且关闭会把焦点还给入口；只有打开**失败**（导航抛错）才保留弹窗并留一行痕。
- **行的结构**：行是 `<li>`，其可点面是一个真正 `<button>`（Enter/Space 免费可用），两个动作按钮是它的**兄弟**而不是嵌在它里面——`role="button"` 里嵌按钮是把交互内容套进交互内容；"焦点即浮现动作"由 `:focus-within` 承担，行为与设计一致。
- **当前工作区的取法**：设计没规定它从哪来。实现用"当前会话的工作区成员关系优先、其次 `cwd` 匹配"，两者都认不出时**回落到「全部工作区」**——按一个未知的工作区过滤会给出**假的**「暂无其他会话」。
- **列表上限 50**：设计只规定"有界必须标注"、没有给数；取 50（与 `team_link_list_sessions` 的 `LIST_LIMIT` 同量级）。
- **入口图标**用 seed 模块的 `IconLinkOutline16` / `IconLinkOutline14`（与【设置】行同一对尺寸）；设计只说「图标 + 文字」，未指定字形。
- **真机复验点 3（3080 页面上的宽态 / 收起态 / 标题栏收起态渲染，以及与消耗卡片、【设置】的相对位置）未执行**：本批只做单元面，客户端 bundle 需重建 + 刷新页面。与 0.3.8 及批次 1–2 同口径，**不把未验的说成已验**。

### 批次 4 —— 收口轮：闸门收窄 · 合成链路补投递 · `task-and-goal` 接数据源 · 列表丢弃当前会话 · 计数勘误 · 跨档同步

> 起因：一次**只读分歧审计**（对批次 1–3 的交付与文档做逐条对照）报出 10 条，本轮逐条落地其中可执行的部分。审计未改任何文件。

**修了什么**：

1. **A 能力闸门收窄到「自建继任者」支路**（审计第 5 条 / N1）：`reappoint` 的能力闸门原先在**动词入口**——无 `agents.create` 的宿主上，**连「改任给活成员」也一并被拒**（那是本批之前不存在的回归）。现在：无该服务 ⇒ **弹框照开，只是候选里不出现「自建继任者」**（只列活成员）；**仅当活成员候选也为 0** 时才 fail-closed 报告且**零弹框**。对话框里同步写明能力缺口（N1：只降级该面子面，并留痕）。
2. **B 恢复面文案与实现对齐**（审计第 3 条 / N3）：`recoveryBoundaryText()` 第 ③ 项由「候选由插件从**活成员**计算」改为「**活成员 ∪ 常驻的「自建继任者（新建会话）」**」；同批核过工具 `description` 的能力闸门段/合成链路段与 `recoveryDiagnosticLines` 的恢复入口行，三处一并改准。另修正交接正文 `mission` 节里一句**收窄之后就不成立**的话（原文「全队没有可改任的活成员」）。
3. **C 合成链路补投递**（审计第 9 条，功能性缺口）：`appointSelfBuiltSuccessor` 原先**止于审计留痕**——令牌铸了、文档写了、留痕三处齐全，**却从未交给刚建出的继任者**（对照 `successor:"auto"` 的结尾是 `handle.agent.followup(…)`，§11.4.5）⇒ 新建的继任者**空转**，30 分钟后被超时清扫取消。现在补上同一条投递（`followup`，不是 `inject`；消息 `source` 仍恰三成员），并在回执里如实报出投递结果（失败有自己的文案与出口）。
4. **D 五硬节的 `task-and-goal` 接数据源**（审计第 8 条）：`selfBuiltHandoffBody` 原先把该节**硬编码成「未知」**，而它算出的 goals 读数只落到 `in-flight` ⇒ **该节声明的数据源从未被消费**。现在该节渲染 goals 读数，**读不到才**标未知（§4.2 (c) ④）；`unknowns` 同步改为「读数覆盖不到的那一部分」，不再在读到读数时仍声称 goal 未知。
5. **E 计数勘误**（审计第 4 条，本仓红线）：批次 2 的红相明细**自相矛盾**——U9 记 10 但其中「新建的会话是根会话（meta 无血统字段）」在修复前**本来就为真**（旧实现从不 `create`，`creates` 为空 ⇒ 判据恒真），语义变更那一组列了 6 个名字却记 5 条，加总 22 与实测 21 差一条。**按重跑实测定档**为 U7 2 + U8 1 + U9 **9** + U10 1 + U11/收敛性 2 + 语义变更 **6** = **21**，计数与列表同一次编辑改准（`docs/verification-log.md` 批次 2 的「计数勘误」小节留原始读数与逐条名单）。
6. **F 跨档同步**（审计第 2、6 条 / 设计 §10 清单）：`docs/team-upgrade-design-2026-09-17.md` §9.1.3 增补**双服务 fail-closed 的挂载语义**（批次 1 要求做、当时未做）；`docs/collab-enhancements-design-2026-09-19.md` §11.9.5 ③ 的**条目本体**由旧规则（「候选由插件从 live 成员计算」）改为新规则，③ 的注解与 §11.9.4 增补第 2 条、验收表 U27 行同批对齐（同一条事实不再有两处口径）。
7. **G 客户端列表丢弃当前会话**（审计第 7 条 / owner 裁定 ③）：`visibleSessionRows` 现在**丢弃当前会话**——本面板的用途是「**其他**会话」（当前会话的复制/导出已在会话头部按钮上），把它列进来会让「暂无其他会话」这句话与实际行为不一致。副作用如实写明：官方那条「blank 行只在它是当前会话时保留」随之退化为「blank 行一律丢」。验收点：工作区里**只剩当前会话**时显示「暂无其他会话」且一行都不画。
8. **H 真机复验点 1**（审计第 10 条）：对运行中的 `127.0.0.1:3080` 重放了 §6 点名的三条请求 × 两种标记（无 token / `Host: evil.example:3080`），原始读数见 `docs/verification-log.md` 批次 4 · 客户端与文档收口一节的表。**结论：运行中的进程仍是修复前的宿主半边**（本插件路由在跨站标记下仍 200 + 5.48 MB 会话数据，而 `/` 与 `/open-in-app/apps` 同判 401/403）——批次 1 的栅栏**在树里，但需 DSH 重启才在真机生效**（本节开头的发布状态行早已如实声明）。故**真机点 1 的红相实测留证完成，绿相留待父侧在一次重启窗口里复跑同六条**。

**为什么**：A 是**回归**（闸门位置错，把不依赖该服务的那条路也拒了）；B/F 是**描述面与实现面分叉**（本仓 N3 红线）；C/D 是**功能缺口**（继任者收不到令牌 ⇒ 空转；一节声明的数据源从未实现）；E 是**计数与列表不一致**（本仓文档卫生红线）；G 是 owner 裁定 ③（列表口径）。

**怎么验证（变异验证）**：

- **修复前必红（宿主半边）**：隔离夹具 `.test-tmp/s1-red/`（**本轮测试文件** + `git show HEAD:lib/index.js` + 当前 `lib/client.js` + `README.md`，在夹具目录里跑）⇒ `node host-half.test.mjs` → **`927 (failed: 7)`**，7 条恰是本轮每一条判据，逐条读数：A 两条（`{"labels":[],"dialogs":0,"creates":0,"pending":null}` + 返回文案「本宿主没有可用的 agents.create……连确认框都不弹」= 整动词被拒）；C 三条（继任者 `followedup.length === 0`）；D 两条（`task-and-goal` 逐字为「**未知**」）。
- **修复前必红（浏览器半边）**：隔离夹具 = 当前 `client-half.test.mjs` + 当前 `lib/client.js` **只把 §4.3.2 的可见性那一行还原**（其余一字未动）⇒ **`259 (failed: 14)`**：其中 7 条是 G 的语义判据（核心读数 `{"empty":"","rows":["session-cur"]}`——修复前那一行真的被画出来了），另 7 条是**按行序号索引**的跟随断言（列表从 3 行变 2 行，索引随事实走）。
- **修复后全绿**：`node host-half.test.mjs` → **`927 (failed: 0)`**（净 +7 条断言，其中 1 条是改写旧 U10）；`node client-half.test.mjs` → **`259 (failed: 0)`**（基线 920 / 257；浏览器半边**净 +2 条**断言、另**改写 10 条**既有断言的表达式来跟上「列表 3 行变 2 行」这条事实）。
- **E 的实跑重算**：批次 2 的红相用原取法重跑（`.test-tmp/s2-red/` = `git show 8d40343:host-half.test.mjs` + `git show b48b34e:lib/index.js` + `git show 8d40343:lib/client.js` + `git show 8d40343:README.md`）⇒ `920 (failed: 21)`，并逐条点名了那 21 条 FAIL（U9 组里那条血统字段断言实测为 `PASS`）。

**如实标注（设计未逐字规定、由实现定夺的地方）**：

- **D 的「读到读数」那一支在生产里不可达**：本动词的前提就是前任**没有活动代理**，而 goals 按 agent 取读数 ⇒ `ctx.agents.get(incumbent)` 必为 `undefined`。这一支是按 §4.2 (c) ④ 的契约实现的（「读不到**才**标未知」），判据直接驱动**真函数**（与既有 U9 交接正文断言同一条纪律）。
- **投递在合成链路里的位置**：作为第 ⑧ 步排在审计留痕之后；§4.2 (c) 的编号是元素清单不是时序，`successor:"auto"` 的顺序是 prepare → 清 pending → followup，两种排法都不违反「令牌落盘之后才投递」。
- **真机复验点 1 的绿相未闭合**（需重启，本轮不重启）；**真机复验点 3**（收起态 / 标题栏收起态）仍未在真机核对，与批次 3 同口径留给父侧。

**同批同步的面**：`README.md`（§二 恢复段「选自建继任者时发生什么」、§4.3 数据源行、tests 徽章 927+259、§十 当前读数）；`docs/team-upgrade-design-2026-09-17.md` §9.1.3；`docs/collab-enhancements-design-2026-09-19.md` §11.9.4 增补第 2 条 / §11.9.5 ③ 及其注解 / U27 行；`docs/verification-log.md`（批次 2 计数勘误 + 批次 4 两小节）；本条目。
---

## 0.3.8 — 2026-09-20 — ① 发送方可见性（§10.1）· ② `/team_session` 自动建队（§10.2）· ③ 自动换届交接（§11）

> ① 让**发送方自己**也看到自己发出的跨会话消息卡片（此前只有接收方有卡片，发送方只看到一行藏在可折叠工具树里的灰字）。② 一条命令建 N 个 worker 根会话并登记进 roster。③ 让换届能自动建继任者并交接，另加一个**两动词、attended-only** 的团队恢复工具与活性诊断面。设计与裁决记录：`docs/collab-enhancements-design-2026-09-19.md` §10.1 / §10.2 / §11 / **§12（真机验证结果）**、`docs/consult-minutes/2026-09-19-consult-37-minutes.md`、`2026-09-20-consult-43-minutes.md`。
>
> **发布状态**：三项的宿主半边都需 DSH 重启才在真机生效。**演练 8（①）已通过真机验证**（§12.1）；**演练 9（②）/ 演练 10（③）/ H1 / H3** 待另一次重启窗口（DEFECT-1/2 的修复要重启才生效，见 §12.4）。

### ✨ 新增
- **A：`tool.call.toolview`（key 逐字 `team_link_send`）**——发送方的工具行从通用灰行变成与接收方同款的出站卡片。**逐目标行 = 目标身份 + `outcome` 短句 + （忙碌时）徽标**：`outcome` → 固定短语（走 locale，zh/en 两套键），**不再原样搬运模型可见的 `detail` 报告句**——那句含「已投递到 …」「目标处于空闲」「steer 注入当前回合」这类**投递机制电报**，让人看的卡片偏机制而非结论且一个目标占 2–3 行（例：80 字符 → 44 字符）；`detail` **仍留在 meta 里**（模型可见文本的事实源 + 降级兜底），只出现在**模型可见的报告**中。用户 2026-09-20 决定，见设计 §10.1.5 / §12.5。
- **D：自有 conversation node definition（kind `team-link-send`）+ 顶层摘要卡**——在会话流**顶层**多一条「发给谁 / 正文 / 汇总计数 / 时间」。**不写任何日志事件、不动模型上下文**。
- **数据链：`output.presentationMeta` → `tool/result.meta`**——卡片读**结构化回执**，不再 regex 解析工具返回文本；持久化后可回放重建同一张卡。
- **② `/team_session`（设计 §10.2）**——一条命令建 N 个 worker **根会话**（N ≤ 8、每队成员 ≤ 24，两个**代码常量**，刻意不进 settings schema）→ 逐个 create 后 `followup` 投递启动任务 → 按 role 幂等登记进 roster → 与主会话建立 pairs 双向免确认通道。批量动作前有**一次**写明「数量 / 模型 / 预设 / cwd / 保守成本口径 / 将建立的信任」的确认框，**取消即零创建零 pairs**，无确认服务即 fail-closed。命令走**可选** `ctx.inject(["commands"])`（模块级 `inject` 仍 4 项），**服务缺席 / 迟到 / 无 `register()`** 三种降级都只丢这条命令。会话 `meta` 恰 `{cwd, agentPreset}`（`origin` / `parentSession` / `delegationDepth` / `parentAgent` 一律不写 ⇒ 根会话），`AgentHandle` 由**插件根 ctx** 的控制器持有。
- **② schema 新增（唯一一处，已裁定）**：`PolicyConfig.pendingCreates`——§10.2.6 的 pending-create 意图必须持久化，否则重启后启动清扫扫不到任何东西。§10.3 原文「schema 均不改」措辞过宽，已改准为「**既有 key 的语义与形状不改；新增须为设计明确要求的闭环所需并在文档与 CHANGELOG 记录**」；既有八个 key 的名字、形状与语义一字未动。
- **② 生命周期（设计 §10.2.5，设计要求必须写进文档）**：**插件卸载/重载 = 全队 teardown**——`AgentHandle` 由插件持有，拆插件即拆掉这些代理，**而会话仍在盘上**。这不是事故，是生命周期事实。恢复路径三步、不新增机制：`team_link_list_sessions` 如实读成 `✕ 未运行` + `verdict=dead` → 在侧边栏**逐个打开**把会话拉回活的代理 → 用 `team_link_roster action=set-role` 重新登记。`/team_session` 的返回文案也带同一条提示。README 的 ② 段落与本条同批补齐。

### ✨ 新增（③ 自动换届交接 · 设计 §11）
- **③a 主路径**：`team_link_rotate action=prepare` 新增 **`successor:"auto"`**（+ 可选 `handoff` 正文）——插件自建**根会话**续任、写**三层交接文档**（头 YAML / 事实段（**与 claim 返回文案同一事实源**）/ 正文 **5 硬节** `mission`·`in-flight`·`commitments`·`unknowns`·`task-and-goal`），再把令牌与正文 **followup** 投给继任者、由它自行 **claim**（**claim 逐字未动**，未新增令牌类型）。**缺项阶梯**：auto + 空正文 → **拒绝于工具入口（零建会话 / 零令牌 / 零 freeze）**；硬节缺 → 拒绝并点名；软节缺 → 放行 + 警告；显式 successor 无正文 → 放行 + 警告；文档写失败 → **abort-before-prepare**。便捷命令 **`/team_rotate <role>`**（走可选 `commands` 注入，**只对现任开放**）。
- **③b 恢复工具 `team_link_recover`**——**恰两个封闭动词**：`revive`（复活**同一**会话：身份 / roster / 信任**零改动**；**只对插件自建会话**，人类自建只输出深链指引）与 `reappoint`（**人类对话授权的 prepare**：候选由**插件**从 live 成员算出、**模型不得指定** → 逐字走既有 prepare + claim）。**attended-only：刻意不设 provisional / 无人值守变体**（pair 迁移可被 sweep 自动回退，**incumbency 不可**），无确认服务 → fail-closed。**八条反后门约束全部落成断言**：封闭动词 / 候选插件算 / `revive` 只绑当前 `current` / `writerGate` 原样不动 / **绝不把 `writer` 降级为 `any`** / 限速 + 三处留痕 / 进入先跑过期清扫 / TOCTOU 双复检（对话框弹出时与落笔前各重查活性）。
- **③b 活性诊断面**：三道门（`writerGate` / `rotateGate` / `retireGate`）**本体仍是纯函数**，由**有 ctx 的工具层**富化拒绝文案（旧文案对死现任是误导性的）；`roster get` 现任行加注记；启动清扫新增「current 无活代理的角色」一行；**`roster.md` 刻意不加**（落盘文件不烙活性读数）。两个派生词 `vacant`（刻意空缺，`current=null`）与 `seated-dead`（悬空指针）**不落盘**。

### 🐞 真机验证暴露的三个缺陷（均已修，待复验窗口）
- **DEFECT-1（高）**：编程创建的会话**跑不起来**——`prompt variable "{{model}}" has no value for this assembly (section "deployment:persona-prefix")`。根因：`buildTeamSessionCreateOptions` 只在给了 `preset=` 时才写 `meta.agentPreset` 并 mount ⇒ **缺省时新建 agent 没有 persona-prefix 组装源**；而官方模板 `createWebhookSession` 是「**总是** resolve（缺省也解析）并 mount」。修法：对齐模板（缺省也解析 + 无条件 mount；服务缺席降级为一行 warn 且不阻断创建）。**H4 假设由此被真机推翻**（**会建 ≠ 能用**）。
- **DEFECT-2（中高）**：编程创建的会话**未挂进工作区** ⇒ 用户侧边栏看不到（须手动切工作区）。根因：模板在 `agents.create` 后调 `await workspace.attachSession(sessionId)`，我们**全库 0 处**。
- **两个缺陷是同一个模式**：**模板有一组「创建后必须做的事」，实现只做了一部分**（漏了 preset 解析/挂载、漏了 workspace 挂载）。
- **DEFECT-3（高）**：**DEFECT-1 只修了一半**——补上了 preset（组装源），却**没给装配里引用的 `{{model}}` 赋值**。**机制证明**：`{{model}}` 取的是 **agent 自己的 `options.model`**（`dsh-agent-loop/lib/index.js:1534` 的 `ctx.systemPrompt.variable("model", (context) => context.agent?.options.model)`）⇒ **宿主缺省根本不在那条路径上**；而 `buildTeamSessionCreateOptions` 在未给 model 时让 `agentOptions` 为空、`installTeamSessionModelSelection` 首行返回 ⇒ 编程创建的 agent **没有任何模型选择** ⇒ 首回合报 `prompt variable "{{model}}" has no value for this assembly (section "deployment:persona-prefix")`。**这一处「故意不做」是父侧批准的**（理由写的是「缺省时宿主自己的 defaultModel 已生效」）——**真机把它推翻了**。
  **修法**：对齐模板 `resolveRequest:30-36`——未给（或**只给了一半**）时用 `ctx.agentDefaultModel.currentSelection()` **解析/补齐**并写进 `agentOptions`，再把同一份选择交给 `installTeamSessionModelSelection`；服务缺席 ⇒ **拒绝创建**（fail-visible——宁可不建，也不建一个跑不起来的会话）。**② 与 ③a 两条路径各自断言**（`successor:"auto"` 建的继任者同样受影响，而那是**信任迁移路径**）。
  **教训（已写进设计 §10.2.2）**：凡列入「故意不做」清单的条目都是**判断**，必须**在真机上被证伪过**、否则显式标注为「未验证的假设」。**「我认为宿主会兜底」不是判据。** DEFECT-1 与 DEFECT-3 是**同一份清单上的同一次失误的两次爆发**。
- **DEFECT-4（中）**：编程创建的会话**全部叫工作区名**（真机原话：「会话名称都是 `dsh-session-link-pro`」）⇒ 侧边栏里**互相无法区分**。根因：把官方模板第 ⑧ 步 `sessionTitle.rename` 判成了「不做」，理由是「命名是**用户可见的交互决定**、设计没给就不自造」。**该理由不成立**——**不设标题不等于不替用户决定**：**默认值（工作区名）本身就是一次很糟的决定**。修法：按**已有的结构化信息**派生可区分的默认标题（`<team> · <role>`；只有 team ⇒ `<team>`；否则会话 id 前缀；**不读 cwd、不造随机数**），走 `ctx.get("sessionTitle")`；服务缺席或 rename 抛错 ⇒ **一行具名 warn、不阻断创建**——与 preset/模型选择那两处的 fail-fast **口径不同且是有意的**：那两处决定会话**能不能跑**，标题只决定它**长什么样**。**② 与 ③a 两条路径同批**（注入点仍只有一处）。判据含一条**可区分性**：同一批里不同 role 的标题**两两不同**。
  **派生边界（同日补）**：上游 `dsh-session-title` 按 `maxTitleBytes: 80`（字节）**剪尾巴、不追加标记、不拒绝**，而团队名只受 `[a-z0-9-]+` 约束、**没有长度上限** ⇒ 原样交出会**把 role 段剪没**、同队两 role 撞名（实测 `distinct: 1 of 2`）⇒ **团队段先截、role 段完整**（UTF-8 安全截断 + 省略号；团队段连前缀都放不住才退成「只有 role」，**不是**工作区名、也不留空的 `<team> · `）；**未给团队名新增任何长度约束**。边界如实：role 自身 >76 字节时任何方案都装不下，此时给非空省略号前缀。
- **无人值守 `claim` 的读数歧义（真机观测到、同日修）**：真机上 `claim` 的确认框**无人应答**（外层工具桥在 ~118.5s 以 `AbortError/ABORTED` 结算），**调用方只读到「tool call aborted」**，**而变更其实已经提交**（落在设计规定的「全部 provisional 迁移」分支）。**根因**：`abort` 被当成「对话框**失败**」（`timedOut` 只由插件自己的 3 分钟计时器置位）⇒ **超时与失败在读数上完全同形、后果却不同**（已换届 vs 未换届）。**修法（只改读数，不动 attended-only 本体）**：`ROTATION_DIALOG_CAUSES`（`unavailable`/`no-answer`/`timeout`/`failed`）+ `dialogNoAnswerError(error, signal)`（把 abort/timeout 归入「**无人应答**」，`signal.aborted` 是权威半）+ `unattendedClaimReading(...)`（**唯一**渲染点，`provisionalGuidance` 复用）；超时读数**自报真实后果**（未获应答 / **这不是「调用失败」** / 已按设计以 provisional 迁移**并已落盘** / 重试或等待都不会撤销它 / **具体到期时刻** / **批准路径**＝人类在设置 UI 置 `provisional: false`）。**真正的失败路径（无确认服务 fail-closed / 令牌无效 / 域外 / 写失败）文案逐字未改**，并由断言互不混淆地钉住；`team_link_rotate` 的 claim 描述另补「超时不是失败」，使调用方**调用前**即可读到。
- **教训（已写进设计 §12）**：① **模板引用必须带「时序清单」**，不能只引形状——§10.2.2 只写了 `meta` 的形状，实现逐字写对却漏了后续步骤；② **断言可能成为缺陷的同谋**——修复删掉的那条旧断言「无 `agentPresets` ⇒ 会话照常可用」正把缺陷固化成了期望行为；③ **探针的前置条件本身也要被验证**——H1 默认「会话已经能被看到」，而真机暴露的正是它根本不在该工作区的列表里。

### 🔧 修复（差异审计与代码评审发现）
- **F2（仓库自身良构红线）**：`targets[].sessionId` / `expr` / `senderSessionId` / 信封 `type|pri|ref` **未经 `wellFormed`**——会把孤立代理项写进会话日志。已全部过闸 + 6 条回归锁（此前代码注释与 README 的「永远良构」自述**不成立**，已改）。
- **F1**：A/D 两面曾逐字重复 head/body/summary/foot。已按「每块信息只准出现一次」分工（D = 标题+时间+正文+汇总；A = 标签+逐目标行）。
- **F3**：客户端**模块级** inject 新增 `uiConversation`，会把设计承诺的「只不渲染」放大成「整个客户端半边不加载」。已改回 3 项 + 动态注入。
- **B3 / 评审 #3**：四条客户端注册全部过 `guardedSlot`（一条抛错不影响其余）。
- **评审 #1**：文件头注释曾称空闲目标「queued without being woken (inject)」，实际是 `followup`；已改。
- **评审 #2**：客户端对 `targets` 行数设界（24）+ 显式截断标注（宿主侧同源缺口见下）。
- **差异审计修复轮 🟡-1（本轮的实质 bug）**：**启动窗口内的 pending-create 意图在并入设置命名空间时被丢掉**。起因是同源形状：许可「整份写入当前命名空间」的谓词 `policyIsAtDefaults` 在 ② 轮加上了 `pendingCreates`，而**兄弟写面**——`adoptMemoryWindow` 交给 `update()` 的那笔补丁——仍是先前七个 key（文件自己的注释就写着「Fields added to DEFAULT_POLICY belong here in the same change」，写面没跟）。后果：窗口内写下的 §10.2.6 意图并入后消失，**下一次启动的清扫清单里就没有这条本该交还给人的孤儿记录**（审计插桩读到 `pendingCreates=undefined`）。修法：补上第八个 key，并在谓词与写面的注释里把「两半必须同批同名」写死。**教训与 ① 的跨轮缺口同源**：新 key 加进了谓词，漏了兄弟写面。
- **差异审计修复轮 🟡-2（描述与实现不符）**：README 的 ② 段落此前声称本轮修掉了一个「旧命名空间迁移会**把当前命名空间整片抹掉**」的缺陷。审计逐行核对基线后判定**该机制不成立**：写**当前**命名空间的那笔补丁基线**就已只含**那五个信任字段，写「整份 `DEFAULT_POLICY`」的是**旧命名空间**那次重置（语义是「重置旧命名空间使迁移不重复」），且 `dsh-settings` 的 `update()` 是 **patch 合并**（另有独立 `replace`），缺 `teams` 的补丁不可能抹掉 roster。已把 README 改写成实际发生的事（谓词与写面覆盖新增的 `pendingCreates`），并为该改动补上断言与条目。
- **差异审计修复轮 🔵-1（证据措辞）**：此前 CHANGELOG / README / 测试注释称「插件对会话只有 `sessionQuery` 的三个读方法，故可静态证明无写入面」。实测是**四个**读方法（漏了 `listSessions`），且插件**确有**会话写入面（`ctx.agents.create` / `agent.followup`）。红线仍成立，但理由换成诚实的版本：那两条既有路径用的是**上游定义**的事件类型，本插件无从发明新类型；**静态正则证明不了这一点**——它锁的是「本模块不得自己长出写入面」（审计变异 M6：往模块里放一个日志写入 API → 1 红），运行时那条读的是**桩**、结构上观察不到新事件类型。断言本身保留，全部措辞已改。
- **差异审计修复轮 🔵-2（有意保留的偏差，已写入代码注释）**：§10.2.3 的模板是 `createUserMessage({content, source})`，实现是手写字面量。裁定：**保持手工构造**——`createUserMessage` 来自 `@deepseek-ai/dsh-llm`，而本模块导入面是**六项白名单**且经 U19 锁住；两条消息实体逐字相同，差别只在上游构造函数产出被**深冻结**（`brandString` 是恒等函数）。不为一行深冻结把导入面扩到 7 项。理由与该回退条件已写进 `teamSessionKickoffMessage` 的注释。
- **差异审计修复轮 🔵-3（状态行/条目不同步）**：README 的设计档索引行仍写「② `/team_session` 自动建队（未实施）」——已改为**已实现**（并标注与 ① 同样「未发布、未真机未验证」）；本小节此前标题只写「发送方可见性」且**没有 ② 的任何条目**——已补。
- **差异审计修复轮 🔵-4（计数）**：U19 一节的断言数是 **17**（此前写 16）；「② 收口轮的 WIP 实际是 640」被实推翻——那次 WIP 提交自带的 README 记的是 **639**（`506 + 133`，内部自洽），640 只是 `656 − 16` 的算术推演。本文件的计数一律以套件自报的那两行为准。

### 🧱 宿主侧行数界（设计 §10.1.2 修正后补）
- `buildSendCard` 对 `targets` 封顶 **24 行**，并写入 `targetsTruncated: {shown,total}`；裁的是**呈现**——`summary` 计数与文本报告仍**全量**（卡是有界呈现，报告是全量档案）。
- 背景：输入侧的 ≤8 只约束**表达式**，而一个 `team:<n>/*` 会在宿主侧展开成**全队成员的行**——所以「持久化卡片必须有界」这条原设计**在宿主侧并不成立**，本轮补上。

### 🔗 跨轮交互缺口（已定位并修复）
- **症状**：宿主先裁到 24 行并写 `targetsTruncated`，而客户端判超限是「自己数行数 > 24」——对**自产卡永远不触发**：A 面看不到截断标注，标签显示的是**已画出的 24 行**而不是真值 30。属**静默失真**（把有界呈现当成全量呈现）。
- **怎么发现的**：实施方在下一轮收尾时**主动对照自己上一轮的成果**上报；父代理用 `grep targetsTruncated lib/client.js`（**0 命中**）独立复现。两轮各自都正确，缺口只存在于两轮的**交互**里。
- **修法**：客户端新增 `readTargetsTruncated`（坏可选成员只丢该成员，不否决整张卡）+ `sendCardTargetTotal`（有标记取 `total`，无标记取实际行数）；A 面**两类超限都出标注**；标注里的 `{shown}` 取**实际画出的行数**——不采信外来 `mark.shown`，否则一张手改卡会在画着 24 行时宣称「仅显示前 5 行」。设计 §10.1.2 / U14 已把这条契约写死。

### 🧾 本期后续轮次（③ 的审计修复 · 真机缺陷 · A 面改人话）
- **③a 差异审计的修复轮**（审计 0 🔴 / 6 🟡 / 7 🔵）：令牌过期时的「额外报告插件自建继任者」**不再依赖内存态 handle**——那个判据在插件重载后恒为假，**恰是设计要防的「没人知道的孤儿」窗口里点名行静默消失**；改为**持久证据优先**（交接文档头部的 `successor:` 行 → 落盘的 `pending-create` 意图 → `hasHandle` 降为附加佐证），且点名行**自报判据来源**。同批：五硬节名收成**一个真源**（四处任一处改名而其余不跟**必红**）；命令键表改成**双向行为锁**（不在广告里的键必须被解析器拒绝）；改名不再让套件崩溃而是**干净地红**（并顺带发现另三处同类）。
- **③b 差异审计的修复轮**（审计 0 🔴 / 7 🟡 / 8 🔵）：**发起域落地**（{该角色最近一任前任} ∪ {团队现任成员}；域外拒绝**零副作用**，连确认框都不弹）；工具描述改准（`revive` 仅 coordinator、`reappoint` 任意角色——**授权从不源自 coordinator 身份**）；**两处空锁改成行为锁**（删掉身份复检 / 删掉入口过期清扫，都必须红）；补 `?? []` 护栏并收口 9 处深链访问（**任何 break 之后套件都能跑到底并打印 `assertion total`**）；死代码合并、候选对话框改**单选**（原多选却只取第一位 = 静默丢弃）、多处注释里一句**被实测推翻的信念**改准（schemastery 不 strip 未声明字段）。
- **合并代码评审（PASS：1 🟡 + 3 🔵）的收尾修复**：① **`revive` 侧的身份复检从「半空锁」落成与 `reappoint` 逐字对称的行为锁**（`Y3-sym` / `Y7-sym`，两条互不顶替）——**红相实测**：把该复检整段注释掉 → `835 (failed: 1)`，**唯一红的就是新锁、所有既有 revive 断言仍绿**，这正是「半空锁」的实证；② 四处机械拼接的排版残留清理，附**三层「纯空白」证明**（正则命中 4 → 0、逐处空白剥离后逐字相等、**全文件字节账** `478574（起始）+ 8（本项插入的 4 个 CRLF）+ 951（#4 那段净差）= 479533 = 实测字节数`）；③ `autoHandover` 的事实段计数改为**确认之后、写文档之前重读一次**再算（使「文档里的数目 == `prepare` 即将快照的那份状态」），并加行为断言（对话框期间往 pairs 加一条 ⇒ 文档必须写 **4 条**而非 3 条；删掉重读即回落成 3 ⇒ 红）。
- **A 面改从结构化字段渲染一句人话**（用户决定）：A 面**不再原样搬运模型可见的报告句**（含「已投递到 …」「目标处于空闲」「steer 注入当前回合」这类**投递机制电报**，让人看的卡片偏机制而非结论，且一个目标就占 2–3 行），改由 `outcome` / `busy` / 目标身份渲染短句；`detail` **仍留在 meta 里**（模型可见文本的事实源 + 降级兜底）。原「卡内行 == 报告首行」的字符串等式锁**作废**，换成**跨半边行为锁**（新增 `outcome` 枚举值而无客户端短语 → 必红）。

### 🧪 验证
- `node host-half.test.mjs` → **874**（failed: 0）；`node client-half.test.mjs` → **146**（failed: 0）（**0.3.8 收口时点**；合计 **1020**）。基线演进：host 506 → … → 675 → 831 → 848 → 855 → 868 → **874**；client 46 → … → 138 → **146**。
  > **计数口径**：一律以套件**自报的那两行**为准；本文件历轮的时点计数（如 675 / 813）保留原文不改，最新值见本行与 README 徽章、第十节。
- **U19 红线回归**（② 收口轮补，**17 条**断言——此前误记为 16，差异审计修复轮 🔵-4 已改；判据是在 U19 小节内逐个数 `check(` 调用点（修复轮**之外**另加的 7 条见下一条，两者不要相加））：① 无新增日志事件类型；② 投递 `source` 恰三成员；③ 模块级 `inject` 仍 4 项；④ 既有 schema 形状与投递双门零改动（含「整批恰弹一次对话框」）。① 的判据经差异审计修复轮 🔵-1 改写为**诚实版**：插件对会话的写入面**存在**（`ctx.agents.create` / `agent.followup`），`sessionQuery` 是**四个**读方法（`listSessions` / `readSession` / `readSurface` / `readTitleSnapshots`），所以那条源码断言锁的是「**本模块不得自己长出写入面**」（审计变异 M6：往模块里放一个日志写入 API → 1 红），而**不是**「静态正则证明了事件类型」——那两条路径的事件类型由**上游**定义，正则证明不了这一点；运行时那条读的是**桩**，结构上观察不到新事件类型，是旁证而非判据。
- **并发纪律**：§10.2.6 要求 create 与 followup 串行（或 ≤2）——实测**已在树上**（单条 `await` 串行循环、`agents.create(` 全模块恰一调用点），故未新增队列，只补断言：提供方侧在飞峰值 **实测 1 ≤ 2**。
- **schema 新增（唯一一处，已裁定）**：`PolicyConfig.pendingCreates`——§10.2.6 的 pending-create 意图必须持久化，否则重启后启动清扫扫不到任何东西。§10.3 原文「schema 均不改」措辞过宽，已改准为「**既有 key 的语义与形状不改；新增须为设计明确要求的闭环所需并在文档与 CHANGELOG 记录**」；既有八个 key 一个字未动。**差异审计修复轮 🟡-1 让这条从「声明」变成「被断言的行为」**：谓词与它许可的整份写入如今都点满八个 key，并入窗口时八个一起写。
- 变异证据（单点回退，修复前必红）：正文截断去掉 → 5 红；结构化 busy 去掉 → 3 红；槽位 key 改近形 → 3 红；不读回执 → 12 红；窗口截断回退去掉 → 2 红；**F2** 的 `sessionId` / `expr` 孤立代理项 → 各 1 红；**评审 #2** 渲染上限去掉 → 2 红；**评审 #3** header 注册去掉护栏 → 2 红；**宿主行数界**去掉 → 3 红；**客户端读标注**路径去掉 → 3 红；**🟡-1 的写面那一行**（`pendingCreates: [...memory.pendingCreates]` 去掉）→ 1 红。
- **差异审计修复轮（本轮实测，红→绿）**：新增 7 条断言（`U9 对照 (pendingCreates)` 一组）。**红相**：先插断言、`lib/index.js` 的写面**一字未改**跑一次 → `663 (failed: 3)`，三条同时红（「窗口内的意图并入后仍在」「并入的行逐字段完整」「并入恰是那八个 key」），而同一组的三条前置断言当场全绿（两个 provider 都迟到 ⇒ 整批在内存窗口内跑；commands 迟到挂载不额外留行；worker-b 的 create 失败 ⇒ 意图未被回填）——前置全绿是**关键对照**：它证明红色不是「路径没走到」。**绿相**：把 `pendingCreates` 补进 `adoptMemoryWindow` 的补丁后 → `663 (failed: 0)`（宿主侧唯一改动，客户端 `138 (failed: 0)` 同期无损）。审计侧另有独立复现（`%TEMP%` 副本插探针：`AUDIT after fold: teams=["night-shift"] pendingCreates=undefined`）。
- **② 收口轮的 WIP 断言数**：**639**（`506 + 133`，那次 WIP 提交自带的 README 记的就是 639，内部自洽）。此前「WIP 实际是 640」的说法是 `656 − 16` 的算术推演，已作废（差异审计修复轮 🔵-4）。
- **代码评审 round-1 收口轮（文法面，红→绿）**：评审发现 `/team_session` 的**位置参数（bare token）被解析却从未被消费**——而 `description` / `input.hint` / 解析器注释 / **plan 自己的报错文案**都在宣传这条路径，用户照报错提示输入仍会得到同一个报错；同时 `task=` 与自身注释矛盾（按空白切分 ⇒ 未加引号的多词任务把词**静默丢进被忽略的 `bare`**，而 `task="…"` 又把引号留进值里）。**修复**：位置参数真正折进 `roles`（`team=` 仍是**必需** key——「首个裸 token 兼作团队名」与「用户忘了 `team=`」无法区分，猜错的代价是把会话登记到别的团队名下）；`task=` 改为读到**下一个已知 `key=`**（保住既有 `task=做接口 model=… preset=…` 次序），`key="value"` 统一剥引号、**半引号一律拒绝**。**红相**（拿 `HEAD:lib/index.js` 原始字节对比）：修复前 `roles=undefined` / `task="fix"` / `bare=["the","bug"]` / `team="t"` 带引号；修复后 `roles=["worker-a","worker-b"]` / `task="fix the bug"` / `bare=[]`。**端到端**（真跑命令，不是只查解析层）：`team=night-shift worker-a worker-b task=fix the bug` → 创 2 会话、roster 落 `coordinator,worker-a,worker-b`、kickoff 正文含完整 `fix the bug`；缺 `team=` 时明确报错。**绿相**：`675 (failed: 0)`（新增 11 条）。同批：README 架构图「11 个工具」→「**8 个工具 + 1 条 `/team_session` 命令**」；死代码 helper `plannedId` 改为**真按 role 查**并投入使用（另删同一处零引用的死常量 `TEAM_SESSION_ROLES`）。
- **真机验证**：**演练 8（①）已通过**（2026-09-20，证据见设计 §12.1：A 面是卡片、D 面顶层摘要卡存在、F1 信息分工成立、导出 3611 事件无自创类型且 `source` 恰三成员）；宿主侧其余改动需 DSH 重启生效 ⇒ **演练 9 / 演练 10 / H1 / H3** 排在用户批准的**下一次重启窗口**（§12.4）。另：真机还暴露并修复了两个缺陷（DEFECT-1/2），其修复同样**需重启才生效**。

---

## 0.3.7 — 2026-09-18

> 收尾修复轮。修两个在**真实部署中实测到**的功能性阻塞，并收掉一轮代码评审的分歧。设计与裁决记录：`docs/team-upgrade-design-2026-09-17.md` §9、`docs/consult-minutes/2026-09-18-consult-36-minutes.md`。

### 🔴 ① settings 持久化静默失效：团队状态从不落盘

**症状**（真实部署实测）：`team_link_watch register` 返回成功、`list` 也能看到条目，但 `profile/settings.yaml` 的 mtime 与全文**毫无变化**；日志里也没有任何本插件的 warn。后果：teams / watchdogs / pairs / rotation **全部只活在进程内存里**，每次 DSH 重启清零。盘上从来没有 `team-link:` 段——也就是说**自 0.2.x 起信任数据从未落盘**，「改名迁移已完成」这个当时写进交付报告的结论是错的。

**根因**（源码链）：cordis 的 `ctx.get(name, strict = true)` 只返回**提供方 fiber 已 active** 的服务（`cordis/lib/index.js:762-771`：`if (strict && impl.fiber.state !== 2) return;`），而 settings provider 要先完成 `[Service.init]`（读盘 → publish）才 active。插件却在 `apply` 期**一次性**取服务，取不到就静默退回内存引擎——此后**无重试、无重绑定、无日志**（只有 `register` 抛错那条路径才 warn，而日志里从未出现该 warn，故该路径也被排除）。

**修法**（三件套）：

1. **快路**：立刻试一次 `ctx.get("settings")`——提供方已 active（或同步 stub）时零额外延迟挂载，既有测试语义不变；
2. **可选有序注入**：没拿到就留**一行 warn**，并登记 `ctx.inject(["settings"], cb)`——provider 转为 active 时回调 attach。它**不是硬依赖**（服务永远不出现时插件照常加载并降级）；`ctx.inject` 本身不可用时再留第二行 warn；
3. **运行期惰性重试**：`get()` / `update()` 每次发现未挂载就再试一次；成功即挂载并记一行 info（`policy store attached to settings namespace "team-link"`）。失败**不重复告警**——「未挂载告警」有**两条到达路径**（激活时未 active / active 但 `register()` 抛错），二者共用同一个一次性门，故**每个未挂载窗口有且仅有一行 warn**。

**同类第二处一并修**：`registerExportRoute` 原先同样在 apply 期取 `ctx.get("webServer")` 时点快照（它当时能用，只因 webServer 恰好先于本插件 active——日志里从未出现该处 warn 即为此反证）。改用同一「晚挂 + 重试」模式，**降级语义一字不变**：始终没有 webServer 就只有一行 warn、头部导出按钮不可用，而 `team_link_export` 工具照常工作。

**启动窗口的数据一致性**（防御性冗余）：attach 之前 `update()` 只能写进进程内存，而这个窗口理论上不可达。真发生时，attach 会把这些内存写入按与改名迁移同形的规则并入设置命名空间（**仅当**设置侧仍是默认值——settings 始终是事实源），并留一行 warn，不静默丢写；并入**先于**改名迁移执行，迁移的「当前命名空间已在用」判据因此看到最终状态。

**明确不采用**的做法：把 `settings` / `webServer` 加进 `inject` 数组：`inject` 是**硬依赖**，依赖缺失时 cordis 令整个插件 fiber 不激活，与「服务缺失时插件完整降级」这条红线相抵；而 `ctx.inject` 与 `inject` 在确定性上等价（同样等 provider 完成 `[Service.init]`），故取零功能回归者。

### 🔴 ② 建队引导死锁：团队建了却永远写不进首任协调者

**症状**：模型能成功 `upsert-team` 建出团队，但**永远**设不进首任协调者，团队到手即只读，M2–M4 全部功能不可达。

**根因**：`upsert-team` 的**创建**路径本就不该过写权限门（否则没人能建第一个团队），但 `set-role` **必然**过门——而门在「`writer=coordinator` 且现任空缺」时**拒绝一切会话路径**。于是创建路径与写权限门之间形成了一个死锁。工具文案当时把用户推向「设置 UI」，但插件并没有提供该设置段，人路径实际是手改 `settings.yaml`——而 ① 又让手改同样读不到。

**修法**：`upsert-team` 在**创建**路径把**调用会话**播种为该团队的 coordinator 现任（经 `roleRecord` 产出规范形状，`history` 记「创建者自举」）。已存在团队的 `roles` 一律不改（幂等契约与「非现任不能借 upsert-team 劫持」同时保住），**不新增任何工具参数**（种子只来自 `exec.agent.id`），`writerGate` / `retireGate` **一行未动**——**手写**的空缺行仍然全拒并指向设置 UI（那是用户显式表达的状态）。

### 配套修复

- **导出文件名安全不变式**：web 导出路由对 `sessionId` 有净化（`replace(/[^\w.-]/gu, "_")`），而 `exportSession` 把原始 id 直接拼进产物路径。抽成共享 helper `fileSafeSessionId()`，两条路径复用。
- **旧命名空间 register 失败必须留痕**：原先 `catch { legacyScope = null; }` 静默吞掉——best-effort ≠ 静默，现在留一行 warn 点名旧命名空间不可用、旧数据不会自动迁移。
- **两个记录项**：`host-half.test.mjs` 结尾输出断言总数（README 计数从此可对跑）；`team_link_list_sessions` 的 provisional 计数与投递侧口径对齐（过期记录不再计入「provisional 配对 N 条」——按投递侧判据它已不再是通道）。

### 代码评审加固（同日追加，仍属 0.3.7）

- **provider 生命周期归属**：晚挂拿到的 scope 与其**注入 fiber 同生共死**（`owner.effect(() => () => detach(), …)`，与 webServer 站点 `target.effect(…)` 同一条规则）。provider fiber 被 dispose 时 scope 归零并记一行 info，store 回到未挂载态、provider 回归时由惰性重试重挂。此前只有捕获没有归属：scope 非 null 却已死，`update()` 每次抛错、而 `get()` **静默改答陈旧内存**。
- **一次性门的单位是「窗口」**：`detach()` 同时**复位**该门——否则第二个未挂载窗口里的**拒绝**会零告警（与 ① 的原始缺陷同形）。窗口**内**的惰性重试仍被同一门挡住，不会成为告警风暴。
- **事后链留痕**：attach 之后的（内存窗口并入 → 改名迁移）两步各自返回结论，统一记一行 info（`post-attach policy chain finished — …`）；`migrateLegacyPolicy` 的早退分支不再一行日志都没有；`refused` 与「根本没有旧命名空间」从同形变为两个可区分取值。
- **内存窗口旗标**：结论记录后清零（避免后续窗口重复并入同一份已解决的内存态、重复记「该窗口理论不可达」warn）；只有 `fold failed` 保持置位——那些写入确实仍在内存里，下次挂载必须重试。
- **消除二次读**：激活分支的 warn 文案取自**第一次读**返回的理由码（`attached` / `refused` / `no-register` / `not-active`），不再第二次读服务（两次读之间服务可能出现，那样文案会描述一个已不成立的状态）；webServer 站点同样改理由码（`mounted` / `no-register` / `not-active`）。
- **死参数清理**：`attach()` 的第三参数 `unavailableDetail` 无人传，连同那条描述不存在路由的注释一并删除。

### 红线与不变量

`PolicyConfig` schema、投递门、`source` 三成员、`writerGate` / `retireGate`、`inject` 数组（仍 4 项）**全部零改动**；`goals.resume` 仍为**零调用**（换届只建议继任者自行 resume）。

### 验证

- `node host-half.test.mjs` → **506 项全绿**；`node client-half.test.mjs` → **46 项全绿**（基线 447 + 46 = 493）。
- **变异验证**：把 lib 的三处修复逐条回退 → `506 (failed: 4)`；把 `createPolicyStore` 换回真正的修复前形状（0.3.6 版：静默内存回退 + apply 当场跑迁移）→ `506 (failed: 16)`。还原即全绿（每次都按 sha256 校验还原）。
- **真机验证（重启后）**：`team_link_watch register` 后 `profile/settings.yaml` **首次出现 `team-link:` 段**（mtime 变化、10498 → 10838 字节），修复前同样操作 mtime 一动不动——这同时把根因链中原本标注为「推断」的一环变成实证；零手工建队 `drill-verify` → 返回「coordinator 已由创建会话认领」→ **紧接着 `set-role` 成功**（修复前这一步必被写权限门拒绝）。
- **独立复核**：一轮差异审计（explore 子代理，只读）独立复现了上述计数与红绿证据，并逐项核对了 inject 恰 4 项、`migrateLegacyPolicy` 唯一调用点在 attach 内、两个门一行未动、越界改动为零；三轮代码评审全部 PASS。

### 未验证 / 显式推迟（如实标注）

- **provider 在本插件 fiber 存活期间消失、而 scope 取自本插件自身 ctx 时不释放**——与 webServer 站点同形，不属红线，记为已知残留；
- **外部手改 `settings.yaml` 是否触发 watcher**：README 曾标为未验证，**2026-09-18 已实测**（外部删除 `team-link:` 段后 `roster get` 立刻回到 0 团队）；
- 两个 🔵 卫生项显式推迟并留档（store 返回对象里的死导出 `migrateLegacyPolicy`；webServer 站点的一次性门是进程寿命级），见设计 §9.6 ⑪；
- §7-4 的夜班日志历史取证（复核一次静默事件的具体触发器）未做——设计里本就标为可选取证。

---

## 0.3.6 — 2026-09-18（发布前收口于 0.3.7）

修两个真实使用缺陷。背景是一次协调者实测：把目标 id 打错一位（`75ae9099` → `75ae9095`），发送返回「没有活动代理」，于是 ① 调用方没有任何可核对的线索；② 该失败被当成普通回执、继续向上汇报「已发送」——而目标会话其实活着。

- **修 1 · no-agent 文案自愈化**（单目标 / fan-out / 插件内部通知三条路径共用 `deliverToTarget`）：拒绝文案首前缀改为 **`❌ 未投递`**（失败不许被读成已排队），保留原句「目标会话 `<id>` 没有活动代理」，并**新增同工作区存活会话列表**（`ctx.agents.list()` 纯注册表读取——零 surface 读取、无性能代价；过滤 = 根代理 + `origin !== "subagent"` + `cwd === 调用者 agentCwd` + 非自身；每行 `id（运行中/空闲）`，上限 **10** 个，超出时注明「共 N 个，仅列前 10 个」；无匹配输出「当前工作区无其他存活会话。」）与**核对提示行**（对照 id / 刚重启 DSH 时在侧边栏打开目标会话一次 / 先调 `team_link_list_sessions`）。执行上下文无会话身份时跳过 cwd 过滤、只排除自身。
- **修 2 · fan-out 失败领先**：只要存在任一目标 outcome ≠ `delivered`，返回文案**第一行**即为 `❌ N 个目标未投递（M 个已投递）`；**全部投递成功时文案形状一字不变**。no-holder 计入该行但汇总里仍保持独立桶、用词只说「未投递」不说「失败」。
- **行为面改动如实标注**：插件内部通知（rotation-freeze / -done / -cancelled / -expired）当收件人已无活动代理时同一行也会带 ❌ 前缀；`deliverToTarget` 是三条路径的共同出口，**未改动任何投递门与投递语义**。
- **验证**：`host-half` 431 → **447** 项（新增 16 项，当次实测），`client-half` 46 项不变（合计 477 → **493**）；既有断言仅 1 项随文案更新（no-agent 行前缀），其余 430 项零回归。

## 0.3.5 — 2026-09-18（发布前收口于 0.3.7）

修 `team_link_list_sessions` 在真实工作区的超时（生产实测：26 个会话的工作区里该工具超过 60s 工具预算；roster / watch 等其他工具正常）。

- **根因**：surface 读取对**列表每一行**（`LIST_LIMIT` = 50）逐个串行执行，而每个冷会话 = 一次 zstd 日志解压 + 一次表面投影。stub 实测（每次读 250ms）：26 会话串行 **6655ms**、修复后 **256ms**。
- **修法三件**：**有界**（恢复只读前 `PREVIEW_SESSIONS` = **12** 行，第 13 行起活性行降级为「未读（超出快照窗口 12）」，行本身照旧列出并经如实标注）；**并行**（这 12 次读取改 `Promise.allSettled`，一行不可读只降级该行）；**回归锁**（新增 7 项断言：调用次数恰为 12、12 次在首次 resolve 前已全部在飞、降级文案形状、窗口外行仍保留无 surface 的面等）。
- **代价（如实标注）**：窗口外的行不再给出 verdict——其中 `dead` 仍可从行首的「✕ 未运行」读出（运行状态来自 agent 注册表，不经日志），而 `goal-disarmed` 在窗口外不可得，需要时单读该会话（`team_link_export`）。
- **验证**：把 lib 改回串行无界的旧形状后 7 项中 3 项当场变红，还原即全绿；活性信号的计算逻辑（verdict 判定表）逐字未动。`host-half` 424 → **431** 项。

## 0.3.4 — 2026-09-18（发布前收口于 0.3.7）

两阶段换届 rotation（设计 §3.6 全节 + §3.6.1 四原则 + §4.1 + §5.1 U6 + §5.3 红线）。

- **`prepare`（Phase A，仅该角色现任会话）**：10 分钟速率限制防换届风暴；生成一次性令牌（`randomUUID()`，绑定 `(team, role, successor)`，30 分钟 TTL，成功认领即作废）；把 `pairs` / `trustedSenders` / `rememberTargets` / roster 全量快照进 `rotationBackup`；向全部在任成员广播 `[rotation-freeze]` 固定冻结清单；返回一次性明文令牌 + 掩码 + 交接指引。
- **`claim`（Phase B，仅 pending 指定的继任者凭令牌）**：单个多选对话框列出全部「退役者↔同 team 成员」候选 pairs 逐项勾选（对端在团队外的不进候选但点名）；在场确认 = ratified → 正式迁移；超时 / 无确认服务 / 失败 = 无人值守 → 全部域内候选以 provisional 迁移并开 **24h** 回退窗口；迁移 = 删旧 pair + 新建 `{a: 新任, b: 对端, provisional, expiresAt}`；**对称撤销** = 退役者持有的 pairs / trustedSenders / rememberTargets 同步清除；落定与迁移在**同一笔写入**，随后才清 pending——崩溃在两者之间时同一令牌重放只补收尾、不重复迁移。
- **到期清扫**（挂看门狗同一巡逻定时器 + 每次 roster / rotate / team_read 惰性检查）：30 分钟未认领 → 清 pending + `[rotation-cancelled]`（旧任仍为 current）；24h 未批准 → 删迁移出的 pairs + 版本史记 `provisional 未批准过期` + `[rotation-expired]`（新任保持 current，信任回退为过门）。
- **内部广播路径**：四种通知正文是**插件常量**（只插值团队/角色/会话 id/读数/状态词，且先过单行清洗）；免发送方审批但**照走接收方 inbound 策略与 `blockedSenders`**；一律不弹确认框。
- **令牌掩码**：镜像与 `roster get` 的 pending 一律渲染 `tok-<前4>…<后4>`，明文只在 prepare 的一次性返回里出现。
- **provisional 可见面**：send 返回文案后缀、`rotation-done` 状态词、roster get 的 pending/provisional 行、`list_sessions` 的「provisional 配对 N 条」标记；banner 与 `source`（仍恰好三成员）都不加字段。
- **补批准入口 = 设置 UI**：24h 内把该 pair 的 `provisional` 置 `false` 即转正式。
- **评审修复轮（7 项）**：**#1**（🔴）幂等判据从「迁移清单非空」改为 `current === pending.session`——域内无候选时标记本为空数组，旧判据会把已落定 roster 当未认领令牌，重放会走完整迁移、把继任者自己当退役者吊销其正式 pairs；**#2** 补批准后窗口静默关闭；**#3** 内部通知的 ask 分支改为逐目标 refused 行（不再 await 3 分钟确认）；**#4** claim 的镜像改用清 pending 后的数组渲染；**#5** 域内无候选时启用独立状态词 `无待迁移对`；**#6** `rotation-done` / `-cancelled` 的收件人并集加入 `rotationBackup.roster` 里的旧任；**#7** README 清扫措辞改条件表述 + `team_read` 加惰性 sweep。
- **第二修复轮（3 项）**：**#8**（🟡）过期 provisional pair 的 TTL 执行缺口——投递侧守门（`pairRecordBetween` 视过期记录为无 pair）+ 清扫侧把 doomed pairs 的计算与删除提到角色记账判据之前；**#9**（🟡）`set-role` 把角色交给 pending 继任者时清 pending（令牌随身份显式变更失效）；**#10**（🔵）`rotationStatus` 显式记状态词供重放直读；**R8** 顺带修掉一处既有墙钟竞态断言。
- **验证**：净增 74 项（311 → 385）→ 修复轮 +20（405）→ 第二修复轮 +19（424）；`client-half` 42 → 46。三轮修复共 22 项断言做过变异验证（挖洞后分别红 16 / 10 / 10 项，还原即全绿）。

## 0.3.3 — 2026-09-18（发布前收口于 0.3.7）

广播 fan-out + 结构化信封 banner + busy 预判（设计 §3.4 / §3.5 / §4.1 / §5.1 U5、U7）。

- **`targets`**（与 `targetSessionId` 互斥）：寻址优先级「会话 id 直达 > `team:<name>/<role>` > `team:<name>/*`」。`team:<name>/*` **仅该团队现任协调者可发**（策展理由）；角色空缺 → 类型化 `no-holder`（不算投递也不算失败）；团队不在 roster 或形状非法 → 整次调用拒绝（不做「半发」）；fan-out **不放宽任何门**；单次 ≤**8** 目标；重复 id 去重。
- **`meta` 信封**：`{type?, pri?, ref?}` 渲染进 banner 首行紧凑字段；`ref` 超 16 字符按码点截断并注明；枚举外的值 / 未定义字段 / 非对象 / 空 ref / 含换行 ref 一律明确参数错误；**`source` 仍是恰好三成员**。
- **busy 预判**：投递后追加目标忙碌状态（运行中 → 「目标回合已运行 N 分钟（steer 注入当前回合）；需新回合语义请等其空闲」，`N` 读不到时只给 steer 语义）。
- **顺带 4 项 M2 评审质量修复**：**R1** retire 信任清理改为对话框确认后**重新读再按最新视图过滤写回**（读-改-写窗口缩到毫秒级）；**R2** TTL 断言不再依赖墙钟；**R3** 补 `applyRetire` 两条错误分支断言；**R4** `team_read` 的 `decisions` baseHash 标注为「仅供参考/审计」。
- **验证**：`host-half` 净增 76 项（235 → 311），`client-half` 42 项不变（合计 353）。

## 0.3.2 — 2026-09-18（发布前收口于 0.3.7）

roster（团队身份注册表）+ 团队黑板（设计 §3.3 全节 + §4.1 + §5.1 U4）。

- 新增 `team_link_roster`（get / upsert-team / set-role / retire）、`team_link_team_read`、`team_link_team_append`；设置命名空间新增 `teams` 键。
- **写权限**：`writer=coordinator`（默认）时只有该团队 coordinator 现任会话可写，现任空缺时会话路径一律拒绝；`writer=any` 时任何会话可写；读永远开放。
- **`retire`**：current 置空 + 版本史记退役；随后可选**一个**确认对话框列出全部指向退役会话的 `pairs` / `trustedSenders` / `rememberTargets`，确认才清理（无确认服务则跳过清理、仅退役并说明）。
- **镜像**：每次 roster 变更在同一调用内 best-effort 写 `<workspace>/team/<name>/roster.md`（失败只告警——settings 始终是事实源）。
- **黑板**：`decisions.md` 只追加（`seq | ISO 时间 | author-session-id | 正文`，seq 单调递增）、`discipline.md` 整文件替换（必须携带 `baseHash`），两者单行上限 **500** 字符（按码点）；黑板**无写权限门**，写入者记在行内 author。团队名 `[a-z0-9-]+` 白名单 + file 枚举白名单（一律 `path.join`，防路径穿越）。
- **验证**：净增 67 项（168 → 235），`client-half` 42 项不变（合计 277）；变异验证：把写权限门与 baseHash 乐观锁各打一个洞后红 8 项，还原即全绿。

## 0.3.1 — 2026-09-18（发布前收口于 0.3.7）

活性面 + 跨会话看门狗最小版（设计 §3.1 / §3.2 / §3.7）。

- `list_sessions` 每个会话行新增 `活性：` 信号行（verdict 五态、goal phase/activation/轮次与 blockedReason、静默时长、读数时间戳）；goal 状态经 `ctx.get("goals")` **可选注入**（服务缺失显示 `?`，插件功能完整降级）。
- 新增 `team_link_watch`（register / list / clear）：只能给自己注册、拒绝自指、单会话 ≤3 个、`silentMinutes>=10` / `intervalMinutes>=5` / `ttlHours<=24`（默认 12，到点自清）。
- **四态巡逻**：观察者运行中或自身 armed-active 不 tick；目标 armed-active 不 tick；目标 active-but-disarmed **立即** tick 且载荷带诊断与合规 resume 回路；paused/blocked/complete 不 tick；无 goal 且静默超阈才 tick。
- tick 的 `source` 仍是恰好三成员（id 前缀 `slp-wd-`），正文是**插件常量模板**；去抖与「观察者=dead」为进程内状态、不持久化；巡逻定时器随 dispose 清理。
- **验证**：净增 93 项（75 → 168），`client-half` 42 项不变（合计 210）。

## 0.3.0 — 2026-09-17

**更名** `dsh-team-link`（原 `dsh-session-link-pro`）：包名 / cordis 名 / client bundle id / 工具名（`team_link_list_sessions` / `team_link_export` / `team_link_send`）/ 设置命名空间（`team-link`，含旧数据一次性迁移）/ 导出路由（`/team-link/export`）。

**不变量**：`slp-` 消息 id 前缀、`dsh://` 深链协议、上游深链解析行为、双门投递语义——一律保持。

**GitHub 仓库名**于 2026-09-18 一并改为 `dsh-team-link`（旧地址自动重定向）。

## 0.2.4 — 2026-09-17

修「孤立代理项」截断 bug（详见 README 第八节）：

- `preview()` / `truncate()` 改为**按码点截断**（原 `slice()` 按 UTF-16 code unit 切，emoji 落在刀口上只剩一半，会**永久毒死**调用方会话）；「已截断 N 字符」计数口径随之变为码点；
- 新增 `wellFormed()` 并消毒列表正文、export 的 md+JSON、send 的两处批准提问正文、投递到目标会话的 banner、拒绝文本里回显的 `targetId`、深链注入的会话快照与三个工具的 `output.render` 出口；
- 顺带修「resolver 省略可选 `additionalContext` 时把 `undefined` 塞进消息数组」；
- 客户端 `shortSessionId()` 改码点截断，卡片正文 / 发送方 id / 委托回退文本渲染前消毒。
- **验证**：`host-half` 新增 20 项、`client-half` 新增 11 项；把两个 lib 文件换回 0.2.3 时 host 红 13 项、client 红 5 项，换回修复版即 117 项全绿。

## 0.2.3 — 2026-09-17

适配 DSH 0.1.5 会话格式迁移：

- 投递消息 `source` 改为受审计的 `{ kind: "agent-message", form: "relay", senderSessionId }`（旧 `kind: "team-link"` 会让整份会话日志无法迁移/打不开）；
- 卡片判定改从 chat node 的 `node.id` 读消息 id（context 的 `data` 里没有 id），叠加 `slp-` 与正文 banner 双信号，避免把上游相邻代理消息误渲染成本插件卡片；
- 时间改为优先用 context node 的事件时间，正文 banner 承载投递时间兜底；
- 宿主包从 `dependencies` 移到 `peerDependencies`，区间补上 `^0.1.5-rc.1` 分支（`^0.1.0-rc.6` 按 semver 预发布规则匹配不到 `0.1.5-rc.1`）；
- 新增 `client-half.test.mjs`；导出路由文件名净化、策略写入去重。

## 0.2.2 — 2026-09-17

配对通道（双向免确认）；醒目 📡 消息卡片（keyed slot 影子渲染 + 委托回退）；消息 `source` 补 `form: relay` + `senderSessionId` 元数据。

## 0.2.1 — 2026-09-17

空闲目标投递改用 `followup` 唤醒（原 `inject` 只排队不唤醒，用户确认后目标无反应）。

## 0.2.0 — 2026-09-16

初版 fork：会话深链 + 会话列表 / 导出 + 批准式跨会话消息。
