/**
 * M1 gate, layer 2 (M0#4 leftover): crash-window reconciliation against the
 * ASSEMBLED runtime — real SessionStore, AgentRegistry, AgentLoop, and JSONL
 * persistence; only the LLM adapter is scripted.
 *
 * Each scenario drives a real agent to a chosen point, disposes the whole
 * fiber tree (the crash), remounts from disk, and asserts the verdict
 * {@link reconcileMessageFromLog} returns over the REAL persisted log — proving the
 * five-row table's inputs actually appear on disk the way the design assumes:
 *   A. followup durable-logged but crash before claim   → enqueued via inbox
 *   B. followup claimed into user/message before crash  → enqueued via user-message
 *   C. followup canceled (cancel clears inbox) pre-crash → rejected via canceled-splice
 *   D. messageId minted but crash BEFORE followup        → refollowup
 * plus E: re-followup after recovery is consumed normally (no duplicate).
 */
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { afterEach, describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import LlmRuntime from '@deepseek-ai/dsh-llm'
import SessionStore, { SessionId } from '@deepseek-ai/dsh-session'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import AgentRegistry from '@deepseek-ai/dsh-agent'
import * as JsonlSessionPersistence from '@deepseek-ai/dsh-session-persistence-jsonl'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'
import AgentLoop from '@deepseek-ai/dsh-agent-loop'
import { MockAdapter, textResponse } from './mock-adapter.ts'
import { reconcileMessage, reconcileMessageFromLog } from '../src/bridge/inbound.ts'
import {
  reconciliationProjectionDefinition,
  type ReconciliationState,
} from '../src/bridge/reconcile-projection.ts'

const dirs: string[] = []
afterEach(async () => { for (const d of dirs.splice(0)) await rm(d, { recursive: true, force: true }) })

async function mount(root: string, adapter: MockAdapter): Promise<Context> {
  const ctx = new Context()
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(SessionStore)
  await ctx.plugin(SessionProjectionRegistry)
  ctx.sessionProjections.register(reconciliationProjectionDefinition)
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(AgentRegistry)
  await ctx.plugin(AgentLoop, { agents: [] })
  await ctx.plugin(JsonlSessionPersistence, { root })
  ctx.llm.registerAdapter(['mock'], adapter)
  return ctx
}

function feishuMessage(text: string) {
  return createUserMessage({
    content: [{ type: 'text', text }],
    source: { kind: 'user' },
  })
}

const agentOptions = { provider: 'mock', model: 'm' }

/** Smallest resumable log: one balanced completed turn (upstream fixture shape). */
function balancedTurn(): SessionEvent[] {
  return [
    { type: 'turn/start', seq: 0, time: 1, data: { turn: 1 } },
    { type: 'turn/end', seq: 1, time: 2, data: { turn: 1, reason: { kind: 'completed' } } },
  ] as unknown as SessionEvent[]
}

async function newRoot(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), 'feishu-crash-'))
  dirs.push(root)
  return root
}

/**
 * Remount from disk, read the persisted log, and fold it through the REAL
 * projection registry. Returning both lets each scenario assert that the
 * projection's incremental verdict matches the batch reference over the same
 * on-disk history — the closest automated stand-in for a live recovery.
 */
async function persistedEvents(root: string, sessionId: SessionId) {
  const ctx = await mount(root, new MockAdapter([]))
  const handle = await ctx.sessionPersistence.open(sessionId, 'read')
  const events = [...(await handle.read()).events]
  await handle.close()
  // Resume the session so the registry has a Session to fold: the projection
  // then materializes over the restored log. `resume` (not `create`) because
  // the session already exists on disk.
  const resumed = await ctx.agents.resume({ resumeSessionId: sessionId, agentOptions })
  const state = ctx.sessionProjections.stateOf(
    resumed.agent.session, 'feishuReconciliation',
  ) as ReconciliationState | undefined
  await ctx.fiber.dispose()
  return { events, state }
}

/** Assert the projected verdict equals the batch reference for one message id. */
function expectAgrees(
  loaded: { events: SessionEvent[]; state: ReconciliationState | undefined },
  messageId: unknown,
): ReturnType<typeof reconcileMessageFromLog> {
  const batch = reconcileMessageFromLog({ messageId: messageId as never }, loaded.events)
  const projected = reconcileMessage({ messageId: messageId as never }, loaded.state)
  expect(projected).toEqual(batch)
  return batch
}

describe('assembled crash-window reconciliation (M1 gate)', () => {
  it('A: followup logged, crash before claim → enqueued via inbox', async () => {
    const root = await newRoot()
    const sessionId = SessionId('feishu-crash-a')
    const ctx = await mount(root, new MockAdapter([textResponse('never runs')]))
    const handle = await ctx.agents.create({ sessionId, agentOptions })
    // Suspend the driver so the splice stays unclaimed: cancel() parks the
    // loop, then followup with keepInbox semantics… simplest reliable hold:
    // do NOT await; dispose immediately after followup returns.
    const message = feishuMessage('hello from feishu')
    handle.agent.followup(message)
    await ctx.sessions.flush(handle.agent.session)
    await ctx.fiber.dispose() // crash

    const loaded = await persistedEvents(root, sessionId)
    const verdict = expectAgrees(loaded, message.id)
    // Depending on how far the loop ran before dispose, the message is either
    // still in the folded inbox or already claimed — both are 'enqueued'.
    expect(verdict.action).toBe('enqueued')
  })

  it('B: followup consumed into user/message, then crash → enqueued via user-message', async () => {
    const root = await newRoot()
    const sessionId = SessionId('feishu-crash-b')
    const ctx = await mount(root, new MockAdapter([textResponse('reply')]))
    const handle = await ctx.agents.create({ sessionId, agentOptions })
    const message = feishuMessage('consume me')
    handle.agent.followup(message)
    await handle.agent.whenIdle()
    await ctx.sessions.flush(handle.agent.session)
    await ctx.fiber.dispose() // crash after full consumption

    const loaded = await persistedEvents(root, sessionId)
    expect(expectAgrees(loaded, message.id))
      .toEqual({ action: 'enqueued', via: 'user-message' })
  })

  it('C (assembled finding): cancel after followup races the claim; every legal ordering recovers safely', async () => {
    // Assembled observation: a live driver claims a spliced followup faster
    // than cancel lands, so the discard-with-outcome-'canceled' row is a
    // narrow race window here, not the dominant path. The dominant ordering
    // is claim → abort BEFORE 'user/message', leaving no canceled splice —
    // reconcile then verdicts 'refollowup', which is safe: the message was
    // never consumed, and re-followup with a new id cannot duplicate.
    // The canceled-splice row itself is pinned by the layer-1 unit test and
    // the upstream discard contract (core/agent/src/inbox.ts:177-189).
    const root = await newRoot()
    const sessionId = SessionId('feishu-crash-c')
    const ctx = await mount(root, new MockAdapter([]))
    const handle = await ctx.agents.create({ sessionId, agentOptions })
    const message = feishuMessage('claimed then aborted')
    handle.agent.followup(message)
    await handle.agent.cancel({ kind: 'user' })
    await ctx.sessions.flush(handle.agent.session)
    await ctx.fiber.dispose()

    const loaded = await persistedEvents(root, sessionId)
    const consumed = loaded.events.some(e => e.type === 'user/message'
      && (e.data as { id: string }).id === message.id)
    const verdict = expectAgrees(loaded, message.id)
    if (consumed) {
      expect(verdict).toEqual({ action: 'enqueued', via: 'user-message' })
    } else {
      // Not consumed: whichever way the race fell, recovery must re-deliver
      // (refollowup) or explicitly reject (canceled discard) — never lose it.
      expect(['refollowup', 'rejected']).toContain(verdict.action)
    }
  })

  it('D: messageId minted, crash before followup → refollowup', async () => {
    // An empty session has no persistence artifact (upstream contract), so
    // seed the smallest resumable log first — matching the real bridge flow,
    // where the bound target session always has prior events.
    const root = await newRoot()
    const sessionId = SessionId('feishu-crash-d')
    const ctx = await mount(root, new MockAdapter([]))
    // AgentLoop owns the durable write handle, so the seeded log must be
    // created through the agent registry: `ctx.sessions.create()` alone
    // registers no persistence writer, which makes `sessions.flush()` a no-op.
    const handle = await ctx.agents.create({ sessionId, agentOptions, seed: balancedTurn() })
    await ctx.sessions.flush(handle.agent.session)
    const message = feishuMessage('never sent') // minted, never followed up
    await ctx.fiber.dispose()

    const loaded = await persistedEvents(root, sessionId)
    expect(expectAgrees(loaded, message.id))
      .toEqual({ action: 'refollowup' })
  })

  it('E: refollowup with a NEW id after recovery is consumed exactly once', async () => {
    const root = await newRoot()
    const sessionId = SessionId('feishu-crash-e')
    // Crash round: mint + nothing else (scenario D shape).
    let ctx = await mount(root, new MockAdapter([]))
    const seeded = await ctx.agents.create({ sessionId, agentOptions, seed: balancedTurn() })
    await ctx.sessions.flush(seeded.agent.session)
    await ctx.fiber.dispose()

    // Recovery round: resume, re-followup with a fresh id, consume, verify.
    ctx = await mount(root, new MockAdapter([textResponse('recovered reply')]))
    const resumed = await ctx.agents.resume({ resumeSessionId: sessionId, agentOptions })
    const retry = feishuMessage('hello again')
    resumed.agent.followup(retry)
    await resumed.agent.whenIdle()
    await ctx.sessions.flush(resumed.agent.session)
    const events = [...resumed.agent.session.snapshotEvents()]
    // Read the projection from the LIVE session before disposal, so agreement
    // is checked against the same log the batch reference sees.
    const state = ctx.sessionProjections.stateOf(
      resumed.agent.session, 'feishuReconciliation',
    ) as ReconciliationState | undefined
    await ctx.fiber.dispose()

    const consumed = events.filter(e => e.type === 'user/message'
      && (e.data as { id: string }).id === retry.id)
    expect(consumed).toHaveLength(1)
    expect(expectAgrees({ events, state }, retry.id))
      .toEqual({ action: 'enqueued', via: 'user-message' })
  })
})
