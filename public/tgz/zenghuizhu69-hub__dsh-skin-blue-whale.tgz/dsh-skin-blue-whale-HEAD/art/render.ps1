param([string]$Name = "whale-source")
$sharp = "C:\Users\Mr.white\AppData\Local\npm-cache\_npx\1e7f6d9597241db0\node_modules\sharp"
$src = "D:\其他文件\dsh-skin-blue-whale\art\$Name.svg"
$out = "D:\其他文件\dsh-skin-blue-whale\art\$Name.png"
$script = @"
const sharp = require(process.argv[1]);
sharp(process.argv[2]).png().toFile(process.argv[3]).then(() => console.log('ok'));
"@
node -e $script $sharp $src $out
