// ASCII silhouette analysis for the whale SVG preview.
// Prints a coarse character map of non-backdrop pixels so the shape can be reviewed as text.
const sharp = require("C:/Users/Mr.white/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/sharp");
const path = require("node:path");
const name = process.argv[2] ?? "whale-source";
const W = 96, H = 60; // character grid
(async () => {
  const src = path.join(__dirname, `${name}.svg`);
  const { data, info } = await sharp(src).resize(W, H).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  // backdrop colors: top sky #0A1124 (10,17,36), sea #071B36 (7,27,54), horizon glow #3E6FD8-ish
  const isBackdrop = (r, g, b) => {
    if (Math.abs(r - 10) < 14 && Math.abs(g - 17) < 16 && Math.abs(b - 36) < 18) return true; // sky
    if (Math.abs(r - 7) < 14 && Math.abs(g - 27) < 16 && Math.abs(b - 54) < 18) return true; // sea
    return false;
  };
  const rows = [];
  for (let y = 0; y < H; y++) {
    let line = "";
    for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 3;
      const [r, g, b] = [data[i], data[i + 1], data[i + 2]];
      if (isBackdrop(r, g, b)) line += " ";
      else if (r > 200 && g > 200 && b > 200) line += "*"; // splash / bright
      else if (b > r && b > g) line += "#"; // whale body / blue features
      else line += ".";
    }
    rows.push(line);
  }
  console.log(rows.join("\n"));
})();
