// Build the whale art SVGs from whale-path.json (single source of truth for the
// official DeepSeek whale path).
//
// Fill/stroke colors are applied through CSS CLASSES (not presentation
// attributes), so the live skin stylesheet can theme them per color scheme and
// var()-in-attribute fallback-to-black can never happen:
//   .dsw-p-body / .dsw-p-belly / .dsw-p-eye / .dsw-p-tail
//   .dsw-splash-dots / .dsw-splash-arcs / .dsw-ripples
//
// Writes:
//   whale-art.svg     — class-based production art (colors live in the skin CSS)
//   whale-preview2.svg — class-based + embedded <style> with dark literals
const fs = require("node:fs");
const path = require("node:path");
const { segs } = JSON.parse(fs.readFileSync(path.join(__dirname, "whale-path.json"), "utf8"));
if (segs.length !== 4) throw new Error("expected 4 path segments");

function whaleBody(withStyle) {
	const style = withStyle ? `  <style>
    .dsw-p-body { fill: #4D6BFE; }
    .dsw-p-belly { fill: #E2EBFF; opacity: 0.95; }
    .dsw-p-eye { fill: #DCE6FF; }
    .dsw-p-tail { fill: #B9CCFF; opacity: 0.55; }
    .dsw-splash-dots circle { fill: #E8F0FF; }
    .dsw-splash-arcs path { stroke: #E8F0FF; }
    .dsw-ripples ellipse { stroke: #9FBBFF; }
  </style>
` : "";
	return `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="128" viewBox="0 0 50 64" fill="none" aria-hidden="true">
${style}  <path class="dsw-p-body" d="${segs[0]}"/>
  <path class="dsw-p-belly" d="${segs[1]}"/>
  <path class="dsw-p-eye" d="${segs[2]}"/>
  <path class="dsw-p-tail" d="${segs[3]}"/>
  <g class="dsw-splash-dots">
    <circle cx="12" cy="44.2" r="0.9" opacity="0.9"/>
    <circle cx="20" cy="42.6" r="0.7" opacity="0.85"/>
    <circle cx="28" cy="43.4" r="0.9" opacity="0.9"/>
    <circle cx="36" cy="43" r="0.8" opacity="0.85"/>
    <circle cx="8" cy="45.6" r="0.7" opacity="0.7"/>
    <circle cx="24" cy="45.8" r="0.6" opacity="0.7"/>
    <circle cx="33" cy="45.6" r="0.7" opacity="0.7"/>
    <circle cx="43" cy="44.8" r="0.6" opacity="0.6"/>
    <circle cx="16" cy="41" r="0.5" opacity="0.6"/>
    <circle cx="30" cy="40.6" r="0.5" opacity="0.6"/>
  </g>
  <g class="dsw-splash-arcs" fill="none" stroke-linecap="round">
    <path d="M14 43.4 C12.5 41.4 13.4 39.4 16 38.4" stroke-width="0.9" opacity="0.8"/>
    <path d="M30 43.6 C31.5 41.6 33 40.2 36 39.6" stroke-width="0.8" opacity="0.7"/>
    <path d="M38 44.8 C40.5 43.6 42.5 42.8 44.5 42.6" stroke-width="0.7" opacity="0.6"/>
  </g>
  <g class="dsw-ripples" fill="none">
    <ellipse cx="25" cy="44.2" rx="16" ry="1.5" stroke-width="0.5" opacity="0.8"/>
    <ellipse cx="25" cy="45.4" rx="22" ry="2" stroke-width="0.4" opacity="0.55"/>
  </g>
</svg>
`;
}

fs.writeFileSync(path.join(__dirname, "whale-art.svg"), whaleBody(false));
fs.writeFileSync(path.join(__dirname, "whale-preview2.svg"), whaleBody(true));
console.log("whale-art.svg + whale-preview2.svg written (class-based colors)");
