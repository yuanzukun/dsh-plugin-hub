// Native-resolution ASCII dump (no resize) of an SVG render.
const sharp = require("C:/Users/Mr.white/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/sharp");
const path = require("node:path");
const name = process.argv[2] ?? "whale-official-preview";
const COLS = Number(process.argv[3] ?? 100);
(async () => {
	const src = path.join(__dirname, `${name}.svg`);
	const { data, info } = await sharp(src).resize(COLS, null).removeAlpha().raw().toBuffer({ resolveWithObject: true });
	const W = info.width, H = info.height;
	console.log(`grid ${W}x${H}, bytes ${data.length}`);
	const lines = [];
	for (let y = 0; y < H; y++) {
		let line = "";
		for (let x = 0; x < W; x++) {
			const i = (y * W + x) * 3;
			const [r, g, b] = [data[i], data[i + 1], data[i + 2]];
			const sky = Math.abs(r - 10) < 14 && Math.abs(g - 17) < 16 && Math.abs(b - 36) < 18;
			if (sky) line += " ";
			else if (r > 200 && g > 200 && b > 200) line += "*";
			else if (b > r && b > g) line += "#";
			else line += ".";
		}
		lines.push(line);
	}
	console.log(lines.join("\n"));
})();
