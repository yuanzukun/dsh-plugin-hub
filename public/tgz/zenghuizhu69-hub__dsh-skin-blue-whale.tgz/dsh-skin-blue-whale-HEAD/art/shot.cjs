// Screenshot the live dsh web skin (hero + work modes) with Edge headless.
// Writes screenshots/hero.png and screenshots/work.png under the plugin repo.
const puppeteer = require("D:/其他文件/.dsw-shot/node_modules/puppeteer-core");
const path = require("node:path");
const fs = require("node:fs");

const EDGE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const URL = "http://127.0.0.1:3080";
const OUT = path.join(__dirname, "..", "screenshots");
const SESSION_ID = process.env.DSW_SESSION_ID || "session-18488603-13e7-48dc-aa29-2905fbfc04b9";

(async () => {
	fs.mkdirSync(OUT, { recursive: true });
	const browser = await puppeteer.launch({
		executablePath: EDGE,
		headless: true,
		args: ["--disable-gpu", "--no-first-run", "--disable-extensions", "--hide-scrollbars"]
	});

	async function capture({ name, seedSession }) {
		const page = await browser.newPage();
		await page.setViewport({ width: 1600, height: 900, deviceScaleFactor: 1 });
		// 深色方案 + 关闭动效：确定性静态画面
		await page.emulateMediaFeatures([
			{ name: "prefers-color-scheme", value: "dark" },
			{ name: "prefers-reduced-motion", value: "reduce" }
		]);
		if (seedSession) {
			await page.evaluateOnNewDocument((sessionId) => {
				localStorage.setItem("dsh.sessions.current", JSON.stringify({ sessionId }));
			}, SESSION_ID);
		}
		await page.goto(URL, { waitUntil: "networkidle2", timeout: 60000 }).catch(() => {});
		// 等应用框架挂载（shell overlay 出现）
		await page.waitForSelector("[data-shell-overlay]", { timeout: 60000 }).catch(() => {});
		// 等皮肤层挂载 + 测量 + （会话模式）消息渲染
		await new Promise((r) => setTimeout(r, seedSession ? 9000 : 4000));
		// 折叠侧栏？不 —— 保持完整布局
		const file = path.join(OUT, `${name}.png`);
		await page.screenshot({ path: file });
		console.log(`saved ${file}`);
		await page.close();
	}

	await capture({ name: "hero" });
	await capture({ name: "work", seedSession: true });
	await browser.close();
	console.log("done");
})().catch((err) => {
	console.error(err);
	process.exit(1);
});
