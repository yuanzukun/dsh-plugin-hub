const sharp = require("C:/Users/Mr.white/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/sharp");
const path = require("node:path");
const name = process.argv[2] ?? "whale-preview";
const points = (process.argv[3] ?? "3,380 100,350 600,350 450,250 400,120 640,380 0,200 320,400 200,330 500,330")
  .split(" ").map((s) => s.split(",").map(Number));
(async () => {
  const src = path.join(__dirname, `${name}.svg`);
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  console.log(`size ${info.width}x${info.height}`);
  for (const [x, y] of points) {
    const i = (y * info.width + x) * 3;
    console.log(`(${x},${y}) = rgb(${data[i]},${data[i+1]},${data[i+2]})`);
  }
})();
