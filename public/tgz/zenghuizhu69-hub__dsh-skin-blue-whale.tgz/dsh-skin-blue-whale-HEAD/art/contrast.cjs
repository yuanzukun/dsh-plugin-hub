// WCAG contrast pre-check for the skin palette pairs.
function lin(c) { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
function lum(hex) {
	const n = parseInt(hex.slice(1), 16);
	return 0.2126 * lin((n >> 16) & 255) + 0.7152 * lin((n >> 8) & 255) + 0.0722 * lin(n & 255);
}
function ratio(a, b) {
	const [l1, l2] = [lum(a), lum(b)].sort((x, y) => y - x);
	return (l1 + 0.05) / (l2 + 0.05);
}
const pairs = [
	["label-primary / layer-1  light", "#101C36", "#FFFFFF"],
	["label-secondary / layer-1 light", "#46577D", "#FFFFFF"],
	["label-tertiary / layer-1 light", "#64759A", "#FFFFFF"],
	["label-caption / layer-1   light", "#7186AD", "#FFFFFF"],
	["button-foreground / primary light", "#FFFFFF", "#3D63DD"],
	["success / layer-1         light", "#16A34A", "#FFFFFF"],
	["warn-label / layer-1      light", "#B45309", "#FFFFFF"],
	["error / layer-1           light", "#DC2626", "#FFFFFF"],
	["label-primary / layer-1   dark ", "#EFF4FF", "#101C34"],
	["label-secondary / layer-1 dark ", "#A9B8D6", "#101C34"],
	["label-tertiary / layer-1  dark ", "#8BA0C4", "#101C34"],
	["label-caption / layer-1   dark ", "#7C8DB0", "#101C34"],
	["button-foreground / primary dark ", "#FFFFFF", "#3D63DD"],
	["button-foreground / hover dark   ", "#FFFFFF", "#4A66E6"],
	["success / layer-1         dark ", "#34D399", "#101C34"],
	["error / layer-1           dark ", "#F87171", "#101C34"],
	["brand-primary focus / base light", "#3D63DD", "#F4F8FE"],
	["label-primary on top band light", "#101C36", "#D6E4F3"],
	["label-tertiary on top band light", "#64759A", "#D6E4F3"],
	["label-caption on top band  light", "#7186AD", "#D6E4F3"],
	["label-tertiary on glow band dark", "#8BA0C4", "#122448"],
	["label-caption on glow band  dark", "#7C8DB0", "#122448"]
];
for (const [name, a, b] of pairs) console.log(`${ratio(a, b).toFixed(2).padStart(5)}  ${name}`);
