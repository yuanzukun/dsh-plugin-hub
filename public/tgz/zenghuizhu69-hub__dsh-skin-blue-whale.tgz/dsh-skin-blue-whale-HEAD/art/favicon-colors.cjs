// Parse the ICO container, extract the largest embedded image, and histogram
// the opaque pixels to recover the official whale palette.
const fs = require("node:fs");
const path = require("node:path");

const src = path.join(__dirname, "deepseek-favicon.ico");
const buf = fs.readFileSync(src);
const count = buf.readUInt16LE(4);
const entries = [];
for (let i = 0; i < count; i++) {
	const o = 6 + i * 16;
	const w = buf[o] || 256, h = buf[o + 1] || 256;
	entries.push({ w, h, size: buf.readUInt32LE(o + 8), offset: buf.readUInt32LE(o + 12) });
}
entries.sort((a, b) => b.w * b.h - a.w * a.h);
const best = entries[0];
console.log(`entries: ${entries.map((e) => `${e.w}x${e.h}`).join(", ")}; using ${best.w}x${best.h}`);
const data = buf.subarray(best.offset, best.offset + best.size);
if (data.subarray(0, 8).toString("hex") === "89504e470d0a1a0a") {
	console.log("frame is PNG; extracting via signature");
}

// BITMAPINFOHEADER (DIB) parse
function parseDib(d) {
	const size = d.readUInt32LE(0);
	const width = d.readInt32LE(4);
	const height = d.readInt32LE(8); // positive = bottom-up
	const bitcount = d.readUInt16LE(14);
	return { size, width, height, bitcount, pixelOffset: size };
}
const dib = parseDib(data);
console.log(`DIB: ${dib.width}x${dib.height} bpp=${dib.bitcount}`);
// ICO 32bpp DIB stores biHeight doubled (image + AND mask stacked).
const W = dib.width, H = Math.abs(dib.height) / 2, bottomUp = dib.height > 0;
const px = data.subarray(dib.pixelOffset, dib.pixelOffset + W * H * 4);

const counts = new Map();
let opaque = 0;
for (let y = 0; y < H; y++) {
	for (let x = 0; x < W; x++) {
		const row = bottomUp ? H - 1 - y : y;
		const i = (row * W + x) * 4;
		const b = px[i], g = px[i + 1], r = px[i + 2], a = px[i + 3];
		if (a < 200) continue;
		opaque++;
		const key = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4);
		counts.set(key, (counts.get(key) ?? 0) + 1);
	}
}
console.log(`opaque ${opaque}, distinct(4bit) ${counts.size}; top colors:`);
for (const [key, n] of [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 14)) {
	const r = ((key >> 8) & 15) * 17, g = ((key >> 4) & 15) * 17, b = (key & 15) * 17;
	console.log(`  #${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}  ~${(100 * n / opaque).toFixed(1)}%`);
}
