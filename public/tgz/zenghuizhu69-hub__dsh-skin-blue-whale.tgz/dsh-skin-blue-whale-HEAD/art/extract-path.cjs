// Extract the full official DeepSeek whale path segments and write them to whale-path.json
// for embedding into the skin's SVG.
const fs = require("node:fs");
const path = require("node:path");
const src = "C:/Users/Mr.white/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/@deepseek-ai/dsh-web-frontend/dist/favicon.svg";
const svg = fs.readFileSync(src, "utf8");
const m = svg.match(/<path id="path" d="([^"]+)"/);
if (!m) throw new Error("path not found");
const d = m[1];
const segs = d.split(/(?=M)/g).map((s) => s.trim());
console.log(`SEGMENTS: ${segs.length}, total length ${d.length}`);
segs.forEach((seg, i) => console.log(`seg${i} (${seg.length}): ${seg.slice(0, 120)}${seg.length > 120 ? "…" : ""}`));
fs.writeFileSync(path.join(__dirname, "whale-path.json"), JSON.stringify({ d, segs }, null, 2));
console.log("written whale-path.json");
