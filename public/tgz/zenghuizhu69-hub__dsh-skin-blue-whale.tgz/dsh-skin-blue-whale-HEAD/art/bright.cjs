// List bright-pixel clusters of an SVG render (spray/ripple verification).
const sharp = require("C:/Users/Mr.white/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/sharp");
const path = require("node:path");
const name = process.argv[2] ?? "whale-preview2";
(async () => {
	const src = path.join(__dirname, `${name}.svg`);
	const { data, info } = await sharp(src).resize(100, null).removeAlpha().raw().toBuffer({ resolveWithObject: true });
	const W = info.width, H = info.height;
	const bright = [];
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		const i = (y * W + x) * 3;
		if (data[i] > 200 && data[i + 1] > 200 && data[i + 2] > 200) bright.push([x, y]);
	}
	console.log(`${bright.length} bright pixels`);
	// cluster by proximity
	const clusters = [];
	for (const [x, y] of bright) {
		let found = null;
		for (const c of clusters) {
			if (Math.abs(c.cx - x) <= 4 && Math.abs(c.cy - y) <= 4) { found = c; break; }
		}
		if (found) { found.n++; found.x0 = Math.min(found.x0, x); found.x1 = Math.max(found.x1, x); found.y0 = Math.min(found.y0, y); found.y1 = Math.max(found.y1, y); }
		else clusters.push({ n: 1, x0: x, x1: x, y0: y, y1: y, cx: x, cy: y });
	}
	for (const c of clusters) console.log(`cluster n=${c.n} x=${c.x0}-${c.x1} (units ${(c.x0 / 2).toFixed(1)}-${(c.x1 / 2).toFixed(1)}) y=${c.y0}-${c.y1} (units ${(c.y0 / 2).toFixed(1)}-${(c.y1 / 2).toFixed(1)})`);
})();
