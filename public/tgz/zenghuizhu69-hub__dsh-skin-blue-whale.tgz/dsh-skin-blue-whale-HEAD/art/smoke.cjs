// Smoke-test the browser half without a browser:
// 1) load lib/client.js with a stubbed window.__ModuleLoader__;
// 2) run factory + apply against fake ctx/document;
// 3) assert every PALETTE token exists in the official design-platform.css
//    token set and every value is a {light, dark} string pair;
// 4) assert the dual-mode layer, measurement wiring, sessions subscription,
//    and cleanup all behave.
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.join(__dirname, "..");
const clientPath = path.join(root, "lib", "client.js");
const designPath = "C:/Users/Mr.white/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/@deepseek-ai/dsh-client-ui-theme/lib/styles/design-platform.css";

let captured = null;
const rafQueue = [];
const window = {
	__ModuleLoader__: { load: (handoff) => { captured = handoff; } },
	addEventListener() {},
	removeEventListener() {},
	requestAnimationFrame: (fn) => { rafQueue.push(fn); return rafQueue.length; }
};
const made = [];
const bodyChildren = [{ tagName: "div", isRoot: true }];
const document = {
	createElement: (tag) => {
		const el = {
			tagName: tag, dataset: {}, style: { props: {}, setProperty(k, v) { this.props[k] = v; } }, children: [],
			classList: { add() {}, remove() {} },
			attributes: {},
			setAttribute(k, v) { this.attributes[k] = v; },
			appendChild(c) { this.children.push(c); return c; },
			remove() { this.removed = true; },
			set textContent(v) { this._text = v; }, get textContent() { return this._text ?? ""; },
			set innerHTML(v) { this._html = v; }, get innerHTML() { return this._html ?? ""; }
		};
		made.push(el);
		return el;
	},
	querySelector() { return null; },
	head: { appendChild() {} },
	body: {
		get firstChild() { return bodyChildren[0]; },
		insertBefore(node) { bodyChildren.unshift(node); return node; },
		appendChild(node) { bodyChildren.push(node); return node; }
	}
};

const sandbox = { window, document, console, MutationObserver: undefined, requestAnimationFrame: window.requestAnimationFrame, setTimeout: (fn) => fakeTimers.setTimeout(fn), clearTimeout: (id) => fakeTimers.clearTimeout(id) };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(clientPath, "utf8"), sandbox, { filename: clientPath });

if (captured === null) throw new Error("bundle never called __ModuleLoader__.load");
if (captured.id !== "dsh-skin-blue-whale") throw new Error(`unexpected bundle id ${captured.id}`);

const plugin = captured.factory();
if (typeof plugin.apply !== "function" || !Array.isArray(plugin.inject)) throw new Error("factory must return { inject, apply }");
if (!plugin.inject.includes("theme") || !plugin.inject.includes("sessions")) throw new Error("inject must include theme and sessions");

let palette = null;
let tokenDisposed = false;
let subscribed = false;
let modeListener = null;
const sessionSnap = { current: void 0 };
// 可控假定时器：clearTimeout 真正移除条目，runTimers 依次执行存活回调
let timerSeq = 0;
const timers = new Map();
const fakeTimers = {
	setTimeout(fn) { const id = ++timerSeq; timers.set(id, fn); return id; },
	clearTimeout(id) { timers.delete(id); },
	runTimers() { for (const fn of [...timers.values()]) fn(); timers.clear(); },
	pendingCount() { return timers.size; }
};
const effects = [];
const ctx = {
	theme: {
		overrideTokens(source, tokens) {
			palette = tokens;
			return () => { tokenDisposed = true; };
		},
		getTheme() { return { active: { colorScheme: "dark" } }; }
	},
	sessions: {
		list: {
			getSnapshot() { return sessionSnap; },
			subscribe(fn) { subscribed = true; modeListener = fn; return () => {}; }
		}
	},
	effect(fn) {
		const dispose = fn();
		if (dispose !== undefined) effects.push(dispose);
	}
};
plugin.apply(ctx);
if (palette === null) throw new Error("apply never called theme.overrideTokens");
if (!subscribed) throw new Error("apply never subscribed to sessions.list");

// drain rAF-triggered measure()
while (rafQueue.length > 0) rafQueue.shift()();

// 1) every value is a {light, dark} string pair
for (const [name, modes] of Object.entries(palette)) {
	if (typeof modes !== "object" || modes === null || typeof modes.light !== "string" || typeof modes.dark !== "string") {
		throw new Error(`token ${name} must be a { light, dark } string pair, got ${JSON.stringify(modes)}`);
	}
}

// 2) every token name exists in the official design token sheet
const design = fs.readFileSync(designPath, "utf8");
const declared = new Set();
for (const m of design.matchAll(/(--dsw-alias-[a-z0-9-]+|--dsw-specific-[a-z0-9-]+)\s*:/g)) declared.add(m[1]);
for (const m of design.matchAll(/(--dsw-[a-z0-9-]+)\s*:/g)) declared.add(m[1]);
const unknown = Object.keys(palette).filter((name) => !declared.has(name));
if (unknown.length > 0) throw new Error(`unknown tokens: ${unknown.join(", ")}`);

// 3) DOM mounts: style + layer with stage/horizon/bubbles/whale svg
const style = made.find((el) => el.tagName === "style");
const layer = made.find((el) => el.tagName === "div" && el.className !== undefined && el.className === "dsw-whale-layer");
if (!style || !layer) throw new Error("apply should create a style tag and the art layer");
if (!style._text.includes("data-dsw-mode")) throw new Error("style tag missing dual-mode CSS");
if (!style._text.includes(".dsw-p-body { fill: #4D6BFE")) throw new Error("style tag missing official whale blue class");
if (!style._text.includes(".dsw-p-belly { fill: #E2EBFF")) throw new Error("style tag missing light belly class");
if (!layer._html.includes("dsw-whale-stage") || !layer._html.includes("dsw-horizon")) throw new Error("layer missing stage/horizon");
if (!layer._html.includes("dsw-flow")) throw new Error("layer missing flowing-water layer");
if (!style._text.includes("#b9d3ec")) throw new Error("style tag missing official DeepSeek blue-white gradient (lightened)");
if (!style._text.includes("dsw-flow-drift") || !style._text.includes("dsw-flow-current")) throw new Error("style tag missing flowing-water animations");
if (!layer._html.includes("M48.8354 10.0479") || !layer._html.includes("dsw-splash-dots")) throw new Error("layer missing official whale path or splash");
if (layer._html.includes("var(--")) throw new Error("svg must not carry var() presentation attributes (black-fill hazard)");
if (bodyChildren[0] !== layer) throw new Error("art layer must be inserted before #root (paint below the app frame)");
if (layer.dataset.dswMode !== "hero") throw new Error("initial mode must be hero");
if (style._text.includes("z-index")) throw new Error("art layer CSS must not carry a competing z-index");

// 3b) M1 竞态回归：快速 hero→work→hero 必须落在最后请求的模式，过期定时器必须被取消
sessionSnap.current = "s1";
modeListener(); // → work（pending）
if (layer.dataset.dswMode !== "hero") throw new Error("mode must not commit before the fade timer");
sessionSnap.current = void 0;
modeListener(); // → hero（应取消上一个定时器）
if (fakeTimers.pendingCount() !== 1) throw new Error(`stale mode timer must be cancelled, got ${fakeTimers.pendingCount()}`);
fakeTimers.runTimers();
if (layer.dataset.dswMode !== "hero") throw new Error("rapid-toggle race: final mode must be hero");
// work → hero 正向切换
sessionSnap.current = "s2";
modeListener();
fakeTimers.runTimers();
if (layer.dataset.dswMode !== "work") throw new Error("mode must commit to work after the fade timer");

// 4) cleanup removes everything
for (const dispose of effects) dispose();
if (!style.removed || !layer.removed) throw new Error("effect cleanup must remove style and layer");
if (!tokenDisposed) throw new Error("token layer must be disposed on unload");

console.log(`smoke OK: ${Object.keys(palette).length} tokens, dual-mode layer mounted, sessions wired, cleanup verified`);
