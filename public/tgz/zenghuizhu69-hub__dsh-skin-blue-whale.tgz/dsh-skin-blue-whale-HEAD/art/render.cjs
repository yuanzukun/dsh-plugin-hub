// Render art/*.svg previews to PNG via the DSH checkout's sharp.
// Usage: node render.cjs <name-without-ext>
const sharp = require("C:/Users/Mr.white/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/sharp");
const path = require("node:path");
const name = process.argv[2] ?? "whale-source";
const src = path.join(__dirname, `${name}.svg`);
const out = path.join(__dirname, `${name}.png`);
sharp(src).png().toFile(out).then((info) => console.log(`ok ${out} ${info.width}x${info.height}`));
