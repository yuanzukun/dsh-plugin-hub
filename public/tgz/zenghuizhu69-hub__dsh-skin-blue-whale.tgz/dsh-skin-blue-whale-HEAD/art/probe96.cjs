// Probe the same 96x60 render ascii.cjs uses, to reconcile the map with reality.
const sharp = require("C:/Users/Mr.white/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/sharp");
const path = require("node:path");
const name = process.argv[2] ?? "whale-official-preview";
const W = 96, H = 60;
(async () => {
	const src = path.join(__dirname, `${name}.svg`);
	const { data, info } = await sharp(src).resize(W, H).removeAlpha().raw().toBuffer({ resolveWithObject: true });
	console.log(`size ${info.width}x${info.height}`);
	const pts = (process.argv[3] ?? "10,4 30,4 70,4 90,10 20,15 50,20 80,20 30,40 60,45").split(" ").map((s) => s.split(",").map(Number));
	for (const [x, y] of pts) {
		const i = (y * W + x) * 3;
		console.log(`(${x},${y}) = rgb(${data[i]},${data[i + 1]},${data[i + 2]})`);
	}
})();
