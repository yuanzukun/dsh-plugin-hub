// Deeper verification: probe signature pixels + find the blue-dominant whale blob.
const sharp = require("C:/Users/Mr.white/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/sharp");
const path = require("node:path");
(async () => {
	for (const name of ["hero", "work"]) {
		const file = path.join(__dirname, "..", "screenshots", `${name}.png`);
		const { data, info } = await sharp(file).removeAlpha().raw().toBuffer({ resolveWithObject: true });
		const W = info.width, H = info.height;
		const px = (x, y) => {
			const i = (y * W + x) * 3;
			return [data[i], data[i + 1], data[i + 2]];
		};
		console.log(`${name}:`);
		console.log(`  sidebar(130,450) = rgb(${px(130, 450).join(",")})  [skin=19,34,63]`);
		console.log(`  sidebar(130,700) = rgb(${px(130, 700).join(",")})`);
		console.log(`  center(800,450)  = rgb(${px(800, 450).join(",")})`);
		// blue-dominant blob scan in the bottom-right quadrant (whale zone)
		let blue = 0;
		let minX = 1e9, maxX = -1, minY = 1e9, maxY = -1;
		for (let y = 300; y < 880; y += 2) for (let x = 700; x < 1580; x += 2) {
			const [r, g, b] = px(x, y);
			if (b > r + 28 && b > g + 12) {
				blue++;
				minX = Math.min(minX, x); maxX = Math.max(maxX, x);
				minY = Math.min(minY, y); maxY = Math.max(maxY, y);
			}
		}
		console.log(`  bottom-right blue-dominant px = ${blue}, bbox = (${minX},${minY})-(${maxX},${maxY})`);
	}
})();
