// Generate self-contained demo pages (docs/demo.html light + docs/demo-dark.html)
// for dsh-quota-panel. Each reproduces the real injected panel script captured
// from the actual plugin module, over a mock Harness-like chat surface.
// The light page defines the Harness design tokens (light values); the dark
// page adds data-ds-dark-theme with the dark token values, proving the card
// follows the product theme instead of carrying its own palette.
import { writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const plugin = await import(new URL('../lib/index.js', import.meta.url));

// Capture the injected script exactly as the plugin would produce it.
const taps = [];
const ctx = {
	credentials: { resolve: async () => ({ value: 'sk-mock', source: 'file' }) },
	webServer: {
		register: () => () => {},
		tapIndex: (fn) => { taps.push(fn); return () => {}; }
	},
	effect: (fn) => { fn(); return () => {}; }
};
plugin.apply(ctx, {
	refreshMs: 5000,
	providers: [
		{ id: 'deepseek', label: 'DeepSeek', credential: 'DEEPSEEK_API_KEY', endpoint: 'https://api.deepseek.com/user/balance', format: 'deepseek-balance', balanceTiers: { critical: 10, warn: 20, healthy: 50 } },
		{ id: 'opencode-go', label: 'OpenCode Go', credential: 'OPENCODE_GO_API_KEY', endpoint: 'https://opencode.ai/zen/go/v1/usage', format: 'opencode-usage', windowLabels: { rolling: '五', weekly: '周', monthly: '月' }, warnPercent: 70, errorPercent: 90 },
		{ id: 'command', label: 'Command Code', credential: 'COMMAND_API_KEY', endpoint: 'https://api.commandcode.ai', format: 'command-cost', windowLabels: { fiveHour: '五', weekly: '周' } }
	]
});
const injected = taps[0]('</body>');

// Mock provider routes, answering with the same normalized envelope the real
// host route produces. `window.__DSH_QUOTA_DEMO__.fail` lists route ids that
// should answer 502 instead — it can be preset from the page URL
// (`demo.html?fail=command`) to exercise the never-loaded error row, or
// toggled at runtime to prove a failed refresh keeps the last good reading.
// The Command Code numbers mirror a real /alpha/billing/credits +
// /alpha/usage/summary pair (GOAT plan: $70/month, $16.24 spent, 803M tokens).
const mockFetch = `<script>
window.__DSH_QUOTA_DEMO__ = { fail: (function () {
  var match = /[?&]fail=([^&]*)/.exec(location.search);
  return match && match[1] ? decodeURIComponent(match[1]).split(',') : [];
})() };
window.fetch = function (url) {
  var id = String(url).split('/').pop();
  var demo = window.__DSH_QUOTA_DEMO__;
  if ((demo.fail || []).indexOf(id) >= 0) {
    return Promise.resolve({ status: 502, ok: false, text: function () {
      return Promise.resolve(JSON.stringify({ ok: false, error: { code: 'upstream', status: 502, message: 'demo outage' } }));
    } });
  }
  var data;
  if (id === 'deepseek') {
    data = { is_available: true, balance_infos: [{ currency: 'CNY', total_balance: '58.36', granted_balance: '0.00', topped_up_balance: '58.36' }] };
  } else if (id === 'opencode-go') {
    data = { usage: {
      rolling: { status: 'ok', percent: 10, resetsAt: new Date(Date.now() + 4 * 3600e3).toISOString() },
      weekly:  { status: 'ok', percent: 45, resetsAt: new Date(Date.now() + 2 * 86400e3).toISOString() },
      monthly: { status: 'ok', percent: 86, resetsAt: new Date(Date.now() + 27 * 86400e3).toISOString() }
    } };
  } else {
    data = {
      credits: { monthlyCredits: 53.7672201717, purchasedCredits: 0, freeCredits: 0 },
      windowLimits: {
        limited: true, exceeded: null,
        fiveHour: { used: 0.1252328, cap: 14, exceeded: false, resetAt: Date.now() + 3 * 3600e3 },
        weekly: { used: 0.1252328, cap: 35, exceeded: false, resetAt: Date.now() + 5 * 86400e3 }
      },
      usage: { totalMonthlyCredits: 16.2385200429, totalCount: 2787, totalCost: 16.2385200429, averageCost: 0.005826523158557588, successRate: 100, totalTokensIn: 800696970, totalTokensOut: 2290409, totalTokens: 802987379, periodBasis: 'billing-period' }
    };
  }
  return Promise.resolve({ status: 200, ok: true, text: function () {
    return Promise.resolve(JSON.stringify({ ok: true, data: data }));
  } });
};
<\/script>`;

const TOKENS_LIGHT = `body {
  --dsw-alias-bg-layer-2: #ffffff;
  --dsw-alias-bg-overlay: #ebeef2;
  --dsw-alias-border-l1: rgba(0,0,0,.06);
  --dsw-alias-border-l2: rgba(0,0,0,.10);
  --dsw-alias-label-primary: #1b1b1c;
  --dsw-alias-label-secondary: #61666b;
  --dsw-alias-interactive-bg-hover: rgba(0,0,0,.05);
  --dsw-static-green-500: #22c55e;
  --dsw-static-amber-500: #f59e0b;
  --dsw-static-red-500: #ef4444;
  --dsw-static-deepseek-500: #4176e6;
  --dsw-static-neutral-bluish-400: #adb2b8;
  --dsw-shadow-lv3: 0 0 1px 0 rgba(0,0,0,.2), 0 0 4px 0 rgba(0,0,0,.02), 0 12px 32px 0 rgba(0,0,0,.08);
  --dsw-font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', 'Helvetica Neue', Helvetica, Arial, sans-serif;
}`;

const TOKENS_DARK = `body[data-ds-dark-theme] {
  --dsw-alias-bg-layer-2: #2c2c2e;
  --dsw-alias-bg-overlay: #434346;
  --dsw-alias-border-l1: rgba(255,255,255,.06);
  --dsw-alias-border-l2: rgba(255,255,255,.12);
  --dsw-alias-label-primary: #f2f2f2;
  --dsw-alias-label-secondary: #c6c8cc;
  --dsw-alias-interactive-bg-hover: rgba(255,255,255,.08);
  --dsw-static-green-500: #22c55e;
  --dsw-static-amber-500: #f59e0b;
  --dsw-static-red-500: #f87171;
  --dsw-static-deepseek-500: #4d82f0;
  --dsw-static-neutral-bluish-400: #9aa0a8;
  --dsw-shadow-lv3: 0 0 1px 0 rgba(0,0,0,.4), 0 0 4px 0 rgba(0,0,0,.1), 0 12px 32px 0 rgba(0,0,0,.35);
}`;

const PAGE = (title, darkAttr, tokens) => `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>${title}</title>
<style>
  html, body { margin: 0; height: 100%; }
  body { background: var(--dsw-alias-bg-layer-2, #ffffff); font-family: var(--dsw-font-family, system-ui, sans-serif); color: var(--dsw-alias-label-primary, #1b1b1c); }
  ${tokens}
  .chrome { display: flex; height: 100vh; }
  .sidebar { width: 220px; background: var(--dsw-alias-bg-layer-2, #ffffff); border-right: 1px solid var(--dsw-alias-border-l1, rgba(0,0,0,.06)); padding: 12px; }
  .brand { font-size: 13px; font-weight: 700; margin-bottom: 14px; }
  .nav { font-size: 12px; line-height: 2.2; color: var(--dsw-alias-label-secondary, #61666b); }
  .main { flex: 1; display: flex; flex-direction: column; }
  .chat { flex: 1; padding: 24px; overflow: hidden; background: var(--dsw-alias-bg-layer-2, #ffffff); }
  .msg { max-width: 640px; margin: 0 auto 14px; font-size: 13px; line-height: 1.6; }
  .msg .who { font-weight: 700; color: var(--dsw-static-deepseek-500, #4176e6); margin-bottom: 4px; }
  .msg p { margin: 4px 0; color: var(--dsw-alias-label-secondary, #61666b); }
  .composer { border-top: 1px solid var(--dsw-alias-border-l1, rgba(0,0,0,.06)); padding: 12px 24px; background: var(--dsw-alias-bg-layer-2, #ffffff); }
  .box { max-width: 640px; margin: 0 auto; background: var(--dsw-alias-bg-layer-2, #ffffff); border: 1px solid var(--dsw-alias-border-l2, rgba(0,0,0,.1)); border-radius: 10px; padding: 10px 14px; color: var(--dsw-alias-label-secondary, #61666b); font-size: 13px; }
</style>
</head>
<body${darkAttr}>
<div class="chrome">
  <div class="sidebar">
    <div class="brand">DeepSeek Harness</div>
    <div class="nav">新会话<br/>会话历史<br/>工作区<br/>设置</div>
  </div>
  <div class="main">
    <div class="chat">
      <div class="msg"><div class="who">助手</div><p>你好！我是运行在 DeepSeek Harness 里的编程智能体。</p></div>
      <div class="msg"><div class="who">用户</div><p>帮我看看账户余额和用量。</p></div>
      <div class="msg"><div class="who">助手</div><p>左下角是一行额度胶囊。点击展开、再次点击收起；展开后可锁定或解锁位置。这里使用示例数据，不连接真实账户。</p></div>
    </div>
    <div class="composer"><div class="box">输入消息…</div></div>
  </div>
</div>
${mockFetch}
${injected}
</body>
</html>
`;

const demoPage = (file) => fileURLToPath(new URL(`../docs/${file}`, import.meta.url));
await writeFile(demoPage('demo.html'), PAGE('dsh-quota-panel demo (light)', '', TOKENS_LIGHT + '\n' + TOKENS_DARK), 'utf8');
await writeFile(demoPage('demo-dark.html'), PAGE('dsh-quota-panel demo (dark)', ' data-ds-dark-theme', TOKENS_LIGHT + '\n' + TOKENS_DARK), 'utf8');
console.log('demo pages written; injected script bytes:', injected.length);
