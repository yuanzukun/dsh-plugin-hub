# 技术文档（docs/design.zh.md）· dsh-acp-v1

> 交付与使用（安装、Zed `settings.json`、冒烟）见仓库根 README；本文是**唯一
> 的技术/设计文档**，合并原 decisions 决策记录与安装手册中的技术部分。源码
> 注释里引用的 `design.zh.md §N` 即指本文对应小节。

## 1. 定位

dsh-acp-v1 **本质上是一个 dsh plugin**（dsh bundle 包，声明
`dsh.bundle.patch: [cordis.patch.yml, presets/*.patch.yml]`），目的：

- 补足 **dsh 原生 ACP 缺失的能力**：官方 `@deepseek-ai/dsh-acp` 是
  automation-only（fresh-only、committed-only、无交互面），与 Zed 的交互要求
  不兼容；本插件是其**交互档补充**。走廊基线 = `dsh 0.2.0-rc.2`（官方同版本
  仍为 automation-only：不注册 `session/load`/`delete`、不发布 live delta）。
- 把 DeepSeek Harness 作为 **Zed Editor 的自定义 agent server extension**
  提供（交互式 ACP v1 服务器，经 `dsh plugin --profile acp add <url|dir>`
  装入 profile、`dsh --profile acp` 启动，走 stdio + JSON-RPC）。
## 2. 组成与进程模型

### 2.1 bundle 组合

- profile `package.json` 的 `dsh.profile.bundles`：`@deepseek-ai/dsh-base` +
  `dsh-acp-v1`（按序作为补丁层）。
- `cordis.patch.yml` 一行一个补丁（`- insert:` 追加行 / `{id, config}` 替换整
  行 config）：
  - `system-prompt`：ACP 会话专属简洁编码 persona（含 sandbox 提示、验证工作
    的要求），**替换** dsh-base 默认 persona。0.1.5-rc.1 起该行 schema 为
    `personaPrefix`（首段，第一方指导之前）+ `personaSuffix`（环境说明），旧
    的单一 `persona` 键已移除；`{{model}}`/`{{cwd}}` 仍是严格插值变量；
  - `hmr.disabled: true`：ACP stdio 会话不能热重载（会撕断连接）；
  - **agent-plane 停用清单**（24 行）：dsh 0.2.0 起 dsh-base 为 TUI 默认启用
    agent 面的工具/命令/压缩/子代理行；preset 要在同一注册表里注册同名工具，
    因此本 bundle 先停用它们，再由每个会话的 preset 拥有该面（与官方
    `@deepseek-ai/dsh-web-app` 同法，去掉其浏览器行）；
  - `agent-preset-registry`（`@deepseek-ai/dsh-agent-preset-registry`，
    `default: standard`）：0.2.0 的预设注册表；**不再扫描目录**，预设是声明行；
  - `presets/{standard,ptc,minimal,cordis}.patch.yml`（`package.json`
    `dsh.bundle.patch` 数组，紧随 `cordis.patch.yml`）：四个
    `@deepseek-ai/dsh-agent-preset` 声明，逐字移植自官方 `dsh-web-app`
    0.2.0-rc.2 的同名文件；部署覆盖 `DSH_ACP_PRESET` 仍由桥在会话创建时解析/
    校验（见 §5，patch 层不写 `!!js`）；独立 dev boot 由 `src/dev-boot.ts`
    读同一 `dsh.bundle.patch` 列表，另可用 `DSH_ACP_DEV_PATCH` 追加一层
    （探针即以此声明测试预设）；
  - `subagent-model-selection-settings`：subagent 模型选择所需的 Host-scope
    seat（web-app bundle 自带，dsh-base 不含）；
  - `cordis-host-runner`（`@deepseek-ai/dsh-cordis-host-runner`）+
    `cordis-inspect-providers`（`@deepseek-ai/dsh-tool-cordis/host`）：
    `cordis`（创造模式）预置的 `tool-cordis` 注入 `cordisInspect` 注册表，
    这两个 host 行提供它并注册 inspect provider（进程内仅一次，重复注册会
    被 registry 拒绝）；与官方 web-app bundle 的两行同形；
  - `dsh-acp-v1`：bridge 行（provider `deepseek-official` / model
    `deepseek-v4-flash`，客户端可经 configOptions 逐会话切换）。
- dsh-base 提供全部宿主行（llm / agents / sessions / persistence /
  session-query / projection / approval / sandbox / commands / 工具注册 /
  llm-deepseek 默认路由…）；未含 preset 行与 `tool-ask-user` 行
  （后者由 elicitation 桥按需补 host 行 + `userQuestions` provider）。

### 2.2 进程与生命周期

- 单进程一条 `AgentSideConnection`（stdin/stdout），每 ACP 会话一个
  `SessionRecord`（cwd / agent / selection / inflight / 已发送折叠 / …），
  输出按会话**串行化**投递。
- **stdout 纪律**：只允许 JSON-RPC；一切诊断走 `ctx.logger`（stderr）；
  launcher 不写 stdout。
- **EOF/退出**：SDK 读流下 `process.stdin 'end'` 不触发；以 `conn.closed`
  （输入流结束即关闭连接）为准 → 每会话 quiesce（drain 在途请求）→
  `ctx.appExit(0)`（launcher 发布的退出请求，无 `cmdline` 服务）。
- 会话级 cancel/close：单会话 quiescent teardown（`requestStop` → drain →
  dispose → `sessions.flush` 落盘），绝不触碰兄弟会话。
- 未决 ACP 请求集合：客户端刚发请求就关 stdin 时，先回完再退出
  （immediate-EOF 冒烟约束）。

## 3. ACP ↔ dsh 映射

### 3.1 会话生命周期

| ACP | dsh | 备注 |
|---|---|---|
| `session/new` | `ctx.agents.create`（cwd + setup 内 `agentPresets.mount(standard)`） | 一次性建号，durable flush |
| `session/list` | `ctx.sessionQuery.listSessions` | 最新在前，header 摘要 |
| `session/load` | `agents.resume` + **回放历史通知流** | ACP 语义 = 把完整历史作为通知回放给客户端（见 §4） |
| `session/resume` | `agents.resume`（不回放） | 恢复上下文继续对话 |
| `session/close`/`delete`/`cancel` | 对应 quiescent teardown / 后端 `sessionPersistence.resolveCurrentLog` + 路径围栏删目录 | cancel 后回合以 `cancelled` 结束；delete 只删 `$DSH_HOME/sessions/<bucket>/<uuid>/` |

### 3.2 prompt 入口与内容

- 单飞（同一会话并发 prompt 拒绝）；文本/图片准入：
  `contentForPrompt`（文本块先过 **skill 归一化**：`/skill:<name>` → 裸
  `/name` 手势——因为 dsh `tool-skill` pre-step 只认裸 `/kebab-name`，归一后
  才会装载 skill 正文）、`scanPrompt`、`encodedImages`（附件落盘 + 识图能力
  门控）。
- **resource 块优雅降级**（`resourceText`，pi-acp 同款）：客户端忽略
  `embeddedContext:false` 通告硬塞 `resource` 块时不炸——text resource 的正文
  以 `[embedded context <uri> (<mime>)]` 折叠拼进相邻文本段；blob/未知 payload
  只留标记不倾倒解码字节；纯 resource 提示也算非空。audio 仍是唯一硬拒绝。
- 斜杠行（以 `/` 开头的整行）→ dsh 命令平面；未知命令回退为普通用户文本。
- 进入模型：`agent.followup`；取消走 agent cancel。

### 3.3 流式与回合结束

- live delta 源（0.1.5-rc.1）：Agent 事件 `agent/assistant-stream` 的
  start/chunk/end 帧（`AssistantStreamFrame`）。仅 **start 帧**携带
  turn/step，故 attemptId → (turn,step) 的映射存在 `SessionRecord` 上；新
  attempt（重试/替换）在 start 时清掉同一 `turn:step:` 前缀的累积，abandoned
  的 end 再清一次（否则提交块 `committedBlockRemainder` 会与已废弃 attempt 的
  文本比对失败而整段不发）。chunk 帧的 `chunk.index` 才是内容块下标，去重键
  仍是 `${turn}:${step}:${blockIndex}`（**不是** `frame.index`，那是 attempt
  内稠密帧序号）。映射本体是纯函数 `foldStreamFrame`（`updates.ts`），
  `session/event` 侧不再有 `assistant/chunk`（该 durable 事件已在 0.1.5 移除）。
- 折叠增量 → `agent_message_chunk` / `agent_thought_chunk`（只发新尾缀，杜绝
  重复）；提交块 `assistant/message` 只补缺失尾段。
- 回合结束按 `codec.ts` 表映射 stopReason（completed/aborted/blocked/error →
  `end_turn`，interrupted → `cancelled`，max-tokens → `max_tokens`）；
  **error 结尾不平账为 stopReason**，而是把在途 `session/prompt` 以 internal
  error 拒绝（`settledStopReason`）。
- `usage_update` 源：`sessionProjections.snapshot().values.contextPressure`。

### 3.4 工具卡片

- `tool/call` → `session_update: tool_call`（toolCallId/kind/status/title/
  name/rawInput/**locations**）；`tool/result` → `tool_call_update`
  （completed/failed + content ≤8000 字符截断 / **diff 卡**，见下）。
- 分类 `toolKindFor`：write/edit/str_replace…→edit、read/read_image→read、
  search 系→search、rm/delete 系→delete、其余（含 bash/pwsh）other。
- **标题自解释**（`tool-cards.ts`）：title 是每种卡片的 primary text，故
  命令类工具（bash/pwsh）标题 = `工具名 + description`（模型写的摘要，
  缺省回落命令行；400 字符截断 + `…`），与路径类同构；路径类工具
  （read/read_image/write/edit/str_replace_editor/rm）标题 = `工具名 +
  显示路径`（绝对路径在 cwd 下时显示为 cwd 相对；live/replay 语义一致）。
  str_replace_editor 自 0.1.5-rc.1 起不再由 base/standard preset 挂载
  （`tool-str-replace-editor` 行移除），其卡片/回放规则保留以复现旧日志；
  search 类 = `工具名 + pattern`（` in <path>` 作用域可选，与宿主自身搜索
  卡同款）；其余（todo_write、ask_user_question…）与解析不出参数的调用
  保持裸工具名。
- **bash 卡 read 化**（取代早期 terminal-echo 方案）：Zed 1.18 把
  `kind: execute` 卡渲染成终端式卡片，其文本 content 藏在一个没有任何事件
  会置位的 `is_open` 折叠后面（悬停才出现箭头），外部 agent 的输出实际不可
  见；曾用 `terminal/create` 内嵌客户端终端修复（terminal-echo），但终态卡
  默认自动展开、形态与其它工具割裂。现改为 bash/pwsh 不再标记 execute：
  标题即 `工具名 + description`（缺省回落命令行），输出以代码围栏包裹
  （`codeFence`，防围栏碰撞）作为普通文本 content 随 `tool_call_update`
  发出（≤8000 字符截断）——所有工具的输出统一围栏，Zed 按非 execute 卡
  渲染成默认折叠、点击展开的代码块，展开即见完整输出；read 结果先经
  `resultCardText` 只保留 `<content>` 标签正文（`<path>/<type>` 头部为卡片
  噪音，路径已在标题与 locations 里），无信封形状时原样透传。dsh 仍在自己
  的 sandbox/审批层执行命令，卡片只是展示已捕获的字节。
- **rawInput 展示形**（`displayRawInput`，live/replay 共用）：Zed 对
  字符串 rawInput 按 markdown 原样渲染（对象才包 JSON 围栏），故有可命名
  参数的工具都发围栏字符串：命令工具 = ```` ```sh ```` 的
  `<workdir> $ <command>`（execute 卡观感）；其余 = `<工具名> <路径|pattern>
  [offset=… limit=… …]`（与标题同源的参数片段 + 标题丢弃的窗口小参数）；
  参数命名不出任何东西的（todo_write、ask_user_question…）与解析失败的
  原样透传。标题的 description / diff 卡的 diff 源仍取自原始参数。
- **follow-along locations**（`toolCallLocation`，pi-acp 惯例）：工具参数里的
  `file_path`/`path` 按 cwd 绝对化后进 `tool_call.locations`，Zed 便随卡片实
  时高亮/跳转 agent 正在触碰的文件。行号按参数形状推断：`read` 的 `offset`、
  str_replace_editor 的 `view_range` 首行 / `insert` 的 `insert_line+1`、
  edit/str_replace 的 `old_string` 在**当前文件**中唯一匹配到的行（工具执行
  前同步读一次，pi-acp 同款；读不到/重复匹配只丢行号不丢路径）。不带文件参
  数的工具（bash/grep/todo…）不发 locations。
- **结构化 diff 卡**（`diffForToolCall` + `toolCallDiffContent`）：ACP
  `ToolCallContent {type:'diff'}` 让客户端渲染真正的 diff 视图而非 8KB 截断
  文本。来源两档：① 持久 `tool/result` 的 `meta.diffs`——dsh-tool-fs 的
  write/edit 本就把"应用后的上下文 hunk"投影进 meta；② 参数自描述——
  str_replace_editor 不产 meta，其 `old_str→new_str` / `create` 的
  `file_text` 即 diff；write 创建新文件时 meta 为空数组，同样回落到整文件新
  建 diff。失败/非变更调用不发 diff；确认文本仍随 diff 一起发，不支持 diff
  的客户端降级为纯文本卡。
- `ask_user_question` 的调用记录到 `askCall`（按会话），其结果→elicitation。
- live 与 replay（§4）共用同一批纯函数，卡片逐字节一致（replay 不做行号推
  断——文件早已变化，只发路径；call↔result 的 diff 配对在 replay 侧用
  callId map 重建）。

### 3.5 plan / 斜杠目录 / skills / 会话选项 / 权限

- **plan**：`todo/write` 整体替换 → `plan` 更新；`turn/start` 清空（曾显示过
  才发空表）。replay 折叠历史到最终一张 plan。
- **斜杠目录**（`available_commands_update`）：Zed 1.18 对 external ACP
  agent **只认 available_commands**（客户端 skill 不进 `/` 菜单，也没有 agent
  侧的 Commands/Skills/Actions 分组），故目录 = dsh 命令平面（`ctx.commands`）
  + **user-invocable skills**（`ctx.skills`，cwd=会话 cwd、scope=agent；根：
  `~/.agents/skills`、`$DSH_HOME/skills`、工程 `.agents/skills`/`.dsh/skills`）。
  命名沿用 pi-acp 惯例：skill 通告为 `skill:<name>`（弹窗 `/skill:find-skills`），
  命令保持原名；命令块 + skill 块分区、各自保序、命令赢同名。变更经
  `skills/change` / `commands/change` 实时重通告。
- **skill 执行**：prompt 文本归一化 `/skill:<name>` → `/name`（§3.2），进入
  dsh tool-skill pre-step 展开（与 dsh Web "/" 选 skill 同路径，非命令平面）。
- **configOptions**：Preset / Model / Thought Level / Write permission 四个
  select，数据源 `ctx.agentPresets.list/select` +
  `ctx.llm.listProviders/listModels/resolveModelInfo` +
  `ctx.permissionPresets.resolve/optionOf/set`；`permission` 写会话授权档
  （read-only / workspace-write / danger-full-access）。`preset` 只在会话尚未产生
  turn 时通告：dsh 的 `select` 是父作用域 re-link（`recompose` + `tools/change`），
  并且对已开始的会话抛 `agent-preset/locked`（读 `turnBoundary` 投影），所以桥在
  首个 `turn/start` 用全量替换的 `config_option_update` 撤下该项——通告面与实际可
  行能力一致；切换成功后重通告斜杠目录（skill/命令面随预设变化），load/resume 由
  日志里最后一条 `agent-preset/selected` 折叠出要挂载的预设（header 是创建事实，
  切换后不再代表当前组合）。0.2.0 起名册是**声明式**的：registry 不扫描目录，
  四个 shipped 组合随本包 `presets/*.patch.yml` 分发（见 §2.1）。
- **权限**：`approval/request`（带 callId 的桥内请求）→ ACP
  `session/request_permission`（allow-once / allow-always / reject-once 三个选项），
  结果映射 `allowed-once` / `rejected` / `cancelled`；allow-always 由桥记录在
  会话级 tool allowlist（dsh 审批词表是一次性的，持久授予存桥侧，内存态），后续
  同工具请求直接自动应答；外来或无 callId 的请求 next() 放行给宿主。
- **审批等待可见性**：`approval/request` 先把一条等待说明
  `agent_message_chunk`（`approvalPendingNote`，形如
  `Waiting for your approval: bash — escalate sandbox to …`）入队并**等它上线**，
  再发 `session/request_permission`——等待期的可见性落在会话流本身，宿主只在
  该 agent 视图内渲染权限卡片时也不会看起来像卡死（issue #1）。这里必须等
  record 的 `outputTail` 而**不能**用 `drainRecord`：后者 `await agent.whenIdle()`，
  而 driver 正在 `await` 本次审批本身 ⇒ 自等待死锁，请求根本发不出去
  （0.1.5-rc.1 实测；`tests/permission-note.test.ts` 为回归门禁）。
- **elicitation**：`ctx.userQuestions.registerProvider` + 表单
  `createElicitation`（绑定 session/tool_call_id），客户端声明
  `elicitation.form` 才启用。
- **认证**：`authenticate`（env `DEEPSEEK_API_KEY` 或 dsh Web 凭据），缺 key
  返回 `AUTH_REQUIRED` + sign-in 方法。

### 3.6 能力纪律与边界

先实现、后声明；未实现一律**不悬空声明**：session fork、terminal/fs 执行委托
（工具仍在 dsh 沙箱内跑）、`additionalDirectories`、audio/embeddedContext、
Windows。`embeddedContext` 虽不声明（embedded resource 不是一等 prompt 输
入），但 `resource` 块会**优雅降级**为纯文本继续跑（§3.2），而非拒绝整个
prompt。diff 卡片与 locations 属于 `tool_call`/`tool_call_update` 的可选字
段，无需能力声明（§3.4）。MCP：非空 `mcpServers` → **接受并忽略**（不挂载
任何 MCP 工具，stderr 记日志；真实客户端 Zed 会转发该字段，拒绝把"不支持"
升级成"不可用"，P1-6）。Zed 内置 agent tools 与本桥实际工具面的逐项对照
（含 ACP 可达性与结论）见 `docs/zed-agent-tools.zh.md`。

## 4. 会话历史与回放（durable history）

- 数据源：`ctx.sessionQuery`（listSessions / readSession events）+ 
  `ctx.sessions.flush` 在 close/dispose 时落盘。
- **load = resume + 回放**：只回放提交且模型可见的事实——
  `user/message` 中 `source: 'user'` 的直发提问以 `user_message_chunk`
  回放（带 messageId 供客户端分块合并；注入上下文/goal 轮/compaction
  checkpoint 等合成 user 角色事件不回放）、
  `assistant/message` 文本/思考块整体流出、`tool/call`+`tool/result` 卡片复现
  （同 live 纯函数，含 locations 路径与 meta/参数来源的 diff 卡；行号推断回
  放不做）、图片降级为 `[image: …]` 占位、todo 历史折叠为**一张**
  最终 plan；原始 delta / usage / 私有呈现数据不进回放。
- `session/resume` **不回放**（SDK 语义）。

## 5. 设计决策记录

| 项 | 决策 |
|---|---|
| 交付形态 | dsh bundle 插件（private，`dsh.bundle.patch`）；非独立 server，非 npm/ACP Registry 发布 |
| 安装（本地） | `dsh plugin --profile acp add <目录>`（pnpm `link:`，改后 `pnpm build` 即生效） |
| 安装（远程） | `dsh plugin --profile acp add https://github.com/dangpangch/dsh-acp.git`（HTTPS，纯拉取；升级 = remove + add） |
| 分发 | `lib/` 预构建产物入库提交：远程安装无 build 脚本，绕开 pnpm 11 `allowBuilds` 拦截；profile 只装运行时依赖（dsh-base 等由 CLI shipped root 提供） |
| Zed 接入 | Custom Agent：`agent_servers` 里 `command: "dsh"`（npm -g 全局安装进 PATH）、`args: ["--profile", "acp"]` |
| 组合 | dsh-base + preset `standard`（agent setup 内 mount）+ bridge 行（provider deepseek-official / model deepseek-v4-flash，会话可切） |
| stdout/EOF | 仅 JSON-RPC；`conn.closed` → quiesce → `appExit(0)` |
| 会话历史 | load=resume+回放提交事实；resume=不回放；delete 后 resume → invalidParams |
| 斜杠目录 | 命令平面 + user-invocable skills；`skill:<name>` 命名、分区保序、变更实时重通告（见 §3.5） |
| skill 执行 | prompt 归一 `/skill:<name>`→`/name`，tool-skill pre-step 装载（见 §3.2） |
| 工具卡标题 | execute 卡 title = 具体命令行；路径卡 = 工具名+显示路径；search 卡 = 工具名+pattern（见 §3.4） |
| follow-along | `tool_call.locations`：file_path/path 绝对化 + 行号推断（read offset / view_range / insert+1 / old_string 唯一匹配，见 §3.4） |
| diff 卡片 | `tool_call_update` 结构化 diff：优先持久 meta.diffs（write/edit hunk），回落参数自描述（str_replace_editor / 新建文件，见 §3.4） |
| resource 块 | 不声明 embeddedContext，但优雅降级为纯文本（pi-acp 同款，见 §3.2） |
| elicitation | userQuestions provider + createElicitation（client capability 门控） |
| 权限档 | config option `permission`（permissionPresets.set） |
| 预设/路由 | 部署默认：`DSH_ACP_PRESET`/`DSH_ACP_PROVIDER`/`DSH_ACP_MODEL` 由桥在会话/agent 创建时读取（改 env 需重启）。预设**是空白会话的会话选项**（config option `preset`，`agentPresets.select`）：首个 turn 前可切，`turn/start` 时撤下选择器、之后回 invalidParams（dsh `agent-preset/locked`）；新建会话对名册未提供的默认值回 invalidParams 并列出可用预设（P1-4）。patch 行保持字面量默认值——本走廊 loader 对 patch 行 `!!js` 的求值时机不可依赖（cnctem 的 `!!js` 写法属其 rc.2 走廊，未在本走廊复现），故由桥代码统一处理 env |
| MCP | 不挂载：非空 mcpServers → 接受并忽略（stderr 记录；拒绝会把 Zed 的正常请求变不可用，P1-6） |
| 能力纪律 | 先实现、后声明（list/load/delete/resume 随实现同步开启） |
| 走廊基线 | 精确钉 `0.2.0-rc.2`（单 cohort，无混合 peer）。迁移账本与证据见 `docs/compat-audit-0.2.0-rc.2.zh.md`；`scripts/standard-mounts.json` 随预设名册再基线化（−ralph：0.2.0 的 standard 声明里该工具 `disabled: true`）。0.1.5-rc.1→0.2.0-rc.2 段在本地升级技能里无版本卡（卡片止于 rc.1；该段 4102 commits），结论由 npm 物化双树 + 声明面对照 + 真实 profile 实测派生，属**已声明的缺口段** |

## 6. 验证与验收

### 6.1 离线验证

```bash
pnpm typecheck && pnpm build          # tsc --noEmit；tsdown -> lib/
pnpm test                             # vitest（175 项；含真实 spawn 的帧纯净、会话历史、elicitation 门控、审批等待可见性探针）
node scripts/conformance.mjs          # ACP v1 wire 一致性 + mount 审计（standard golden + 每个 shipped preset 各起一次探针比对）
node scripts/preset-smoke.mjs         # 部署字段 DSH_ACP_PRESET/PROVIDER/MODEL
node scripts/history-probe.mjs        # 会话历史端到端（隔离 DSH_HOME）
# dev boot smoke（隔离 DSH_HOME）
printf '…initialize…\n…session/new…' | node lib/dev-bin.js   # 2 result + exit 0
# CLI profile smoke（隔离 DSH_HOME）
DSH_HOME=$(mktemp -d) dsh plugin --profile acp add https://github.com/dangpangch/dsh-acp.git
printf '…' | DSH_HOME=$DSH_HOME dsh --profile acp            # 2 result + exit 0
```

### 6.2 真实 Zed 验收清单

> 依赖真实模型 key；排障看 `dev: Open Acp Logs` 与服务端 stderr（stdout 不应
> 有非协议输出）。

1. Custom Agent 线程建立，文本/思考流式可见；
2. 沙箱权限：写工程内成功、写工程外被拦并弹 Allow once / Reject once；
3. 工具卡片：标题自解释（execute 卡显示具体命令行；read/glob/edit 卡显示工
   具名 + 路径/pattern），有输出/退出码；
4. follow-along：read/edit 卡片让 Zed 实时高亮 agent 正在看的文件（含行
   号）；编辑卡片渲染真正的 diff 视图（非截断文本）；
5. 长回答增量流式；
6. 齿轮菜单切换 Model / Thought Level / Write permission 且下回合生效；
7. `/` 菜单：命令 + `/skill:find-skills` 式 skill 条目，选中即装载执行；
8. 关闭线程后从 recent threads 恢复（resume/load），上下文连贯（回放卡片与
   live 逐字节一致，diff 卡复现）；
9. ask 表单可作答；
10. 取消长任务 → 回合 cancelled、无残留子进程；
11. 缺 key → Authenticate 引导，配好即恢复；
12. 诊断：Acp Logs 有 JSON-RPC 记录、stderr 无协议帧泄漏。

### 6.3 诊断约束速记

| 现象 | 处置 |
|---|---|
| stdout 出现非 JSON 行 | 违反不变量 → 报告（launcher 不应写 stdout） |
| 进程秒退 | 看 stderr（多为组合/预设问题）；`dsh --profile acp </dev/null` 应 exit 0 |
| 工具卡只有工具名、没有命令 | 旧构建：`pnpm build` 后重启线程（execute 卡标题=命令） |
| 执行卡看不到命令输出 | 展开卡片的内容块即可（bash 卡已 read 化，输出随卡折叠；旧构建先 `pnpm build`） |
| 工具卡不带文件定位/没有 diff 视图 | 旧构建：`pnpm build` 后重启线程（locations/diff 卡随 §3.4 新增） |
| `/` 无 skill | skill 需 user-invocable 且位于 dsh 扫描根；装/删后本会话实时刷新 |
| `/skill:名` 不生效 | 看是否出现 `Load skill …` 工具卡（归一化→pre-step 装载路径） |

## 7. 布局

```
src/bridge/index.ts     插件入口：AgentSideConnection + 会话生命周期 + 事件映射
src/bridge/catalog.ts   斜杠目录合并（命令平面 + user-invocable skills；纯函数）
src/bridge/replay.ts    持久历史 → ACP 回放帧（纯函数）
src/bridge/tool-cards.ts 卡片分类/rawInput/标题/locations/diff（标题自解释：bash=工具名+description、路径类=工具名+路径、search=pattern；纯函数）
src/bridge/{codec,updates,content,config-options,session-store}.ts  纯映射/builder 模块（§3）
src/dev-bin.ts          独立 dev/test boot（dsh-base + 本包 dsh.bundle.patch 各层 + DSH_ACP_DEV_PATCH 覆盖）
cordis.patch.yml        bundle 补丁（§2.1）
presets/*.patch.yml     四个 shipped 预设声明（§2.1）
scripts/history-probe.mjs  会话历史端到端探针
scripts/conformance.mjs    ACP v1 wire 一致性 + 挂载审计（wire-probe.mjs 引导 + acp-client 驱动）
```
