// session-store: single-flight prompt slot, the registry identity guard, and
// the durable model-selection / agent-preset folds (design.zh.md
// §6.2/§6.3 primitives).
import { describe, expect, it } from 'vitest'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import { createInflight, hasStartedTurn, lastAgentPreset, lastModelSelection, lastSessionTitle, makeRecord, removeRecord, sessionDirForDelete, type PromptInflight, type SessionRecord } from '../src/bridge/session-store.js'

/** Minimal session event fixture (seq/time are irrelevant to the fold). */
const event = (type: string, data: unknown): SessionEvent => ({ type, seq: 0, time: 0, data }) as never

describe('sessionDirForDelete (durable-delete safety fence)', () => {
  const root = '/home/u/.dsh/sessions'
  const id = '23124675-8e8d-45e8-9cd3-1b1c474bec82'

  it('resolves the session directory of a current-generation artifact', () => {
    expect(sessionDirForDelete(`${root}/--ws-proj--/${id}/session.jsonl`, root)).toBe(`${root}/--ws-proj--/${id}`)
    expect(sessionDirForDelete(`${root}/--ws-proj--/session-${id}/session.v3.jsonl.zstd`, root))
      .toBe(`${root}/--ws-proj--/session-${id}`)
  })

  it('refuses an artifact outside the sessions root', () => {
    expect(sessionDirForDelete(`/tmp/${id}/session.jsonl`, root)).toBeUndefined()
    expect(sessionDirForDelete(`${root}-evil/${id}/session.jsonl`, root)).toBeUndefined()
  })

  it('refuses a directory that is not a session identity', () => {
    expect(sessionDirForDelete(`${root}/--ws-proj--/not-a-uuid/session.jsonl`, root)).toBeUndefined()
    expect(sessionDirForDelete(`${root}/--ws-proj--/${id}.bak/session.jsonl`, root)).toBeUndefined()
    // The artifact itself must sit one level below the session directory.
    expect(sessionDirForDelete(`${root}/session.jsonl`, root)).toBeUndefined()
  })
})

describe('removeRecord identity guard', () => {
  const recordFor = (id: string): SessionRecord => makeRecord(
    id as never,
    '/ws',
    { agent: {} as never, dispose: () => Promise.resolve() },
    { current: undefined, assembled: undefined },
  )

  it('deregisters the exact registered instance by its own id', () => {
    const store = new Map()
    const record = recordFor('a')
    store.set(record.id, record)
    removeRecord(store, record)
    expect(store.has('a')).toBe(false)
  })

  it('never removes a live entry on behalf of an impostor with the same id', () => {
    const store = new Map()
    const real = recordFor('a')
    store.set(real.id, real)
    // A superseded create racing a stale teardown carries the same id but a
    // different instance; the live record must survive.
    removeRecord(store, recordFor('a'))
    expect(store.get('a')).toBe(real)
  })
})

describe('PromptInflight (one prompt per session)', () => {
  it('resolves its stop-reason promise exactly once with the given reason', async () => {
    const inflight: PromptInflight = createInflight()
    const settled = inflight.promise.then((reason) => `ok:${reason}`)
    inflight.resolve('end_turn')
    expect(await settled).toBe('ok:end_turn')
  })

  it('rejects its promise on failure paths (admission/turn/output)', async () => {
    const inflight = createInflight()
    const failure = inflight.promise.then(
      () => 'unexpected resolve',
      (error: unknown) => `rejected:${(error as Error).message}`,
    )
    inflight.reject(new Error('turn failed'))
    expect(await failure).toBe('rejected:turn failed')
  })

  it('starts empty: no message, no turn, admission not finished, not cancelled', () => {
    const inflight = createInflight()
    expect(inflight.messageId).toBeUndefined()
    expect(inflight.messageQueued).toBe(false)
    expect(inflight.turn).toBeUndefined()
    expect(inflight.endKind).toBeUndefined()
    expect(inflight.cancelRequested).toBe(false)
    expect(inflight.settlementStarted).toBe(false)
    expect(inflight.outputError).toBeUndefined()
    expect(inflight.agentError).toBeUndefined()
  })

  it('admission completion gates settlement bookkeeping', async () => {
    const inflight = createInflight()
    let admitted = false
    void inflight.admissionDone.then(() => {
      admitted = true
    })
    await Promise.resolve()
    expect(admitted).toBe(false)
    inflight.finishAdmission()
    await inflight.admissionDone
    expect(admitted).toBe(true)
  })

  it('aborting the admission controller marks cancellation intent', () => {
    const inflight = createInflight()
    inflight.admissionController.abort(new Error('ACP prompt cancelled'))
    expect(inflight.admissionController.signal.aborted).toBe(true)
  })
})

describe('lastModelSelection (durable selection fold)', () => {
  it('returns undefined for logs without a selection snapshot', () => {
    expect(lastModelSelection([])).toBeUndefined()
    expect(lastModelSelection([
      event('turn/start', { turn: 0 }),
      event('todo/write', { todos: [] }),
    ])).toBeUndefined()
  })

  it('restores the latest snapshot, later writes winning over earlier ones', () => {
    const restored = lastModelSelection([
      event('model/selection', { provider: 'deepseek-official', model: 'deepseek-v4-flash' }),
      event('turn/start', { turn: 0 }),
      event('model/selection', { provider: 'pi-ai', model: 'claude-x', reasoningEffort: 'off' }),
    ])
    expect(restored).toEqual({ provider: 'pi-ai', model: 'claude-x', reasoningEffort: 'off' })
  })

  it('restores a provider-default snapshot without an effort key', () => {
    const restored = lastModelSelection([
      event('model/selection', { provider: 'pi-ai', model: 'claude-x', reasoningEffort: 'off' }),
      event('model/selection', { provider: 'pi-ai', model: 'claude-x' }),
    ])
    expect(restored).toEqual({ provider: 'pi-ai', model: 'claude-x' })
    expect('reasoningEffort' in restored!).toBe(false)
  })
})

describe('lastSessionTitle (durable title fold)', () => {
  it('returns undefined for a title-less log', () => {
    expect(lastSessionTitle([])).toBeUndefined()
    expect(lastSessionTitle([
      event('turn/start', { turn: 0 }),
      event('model/selection', { provider: 'pi-ai', model: 'claude-x' }),
    ])).toBeUndefined()
  })

  it('returns the latest title, later writes winning over earlier ones', () => {
    expect(lastSessionTitle([
      event('session/title', { title: 'first', messageSeqs: [1, 2], source: { kind: 'provider' } }),
      event('turn/start', { turn: 0 }),
      event('session/title', { title: 'renamed', messageSeqs: [], source: { kind: 'user' } }),
    ])).toBe('renamed')
  })
})

describe('lastAgentPreset (durable preset fold)', () => {
  it('returns undefined for logs without a preset selection', () => {
    expect(lastAgentPreset([])).toBeUndefined()
    expect(lastAgentPreset([
      event('turn/start', { turn: 0 }),
      event('model/selection', { provider: 'pi-ai', model: 'claude-x' }),
    ])).toBeUndefined()
  })

  it('restores the latest pick, later selections winning over earlier ones', () => {
    expect(lastAgentPreset([
      event('agent-preset/selected', { agentPreset: 'ptc' }),
      event('turn/start', { turn: 0 }),
      event('agent-preset/selected', { agentPreset: 'cordis' }),
    ])).toBe('cordis')
  })
})

describe('hasStartedTurn (preset lock boundary)', () => {
  it('is false for a blank session, where a preset switch is still allowed', () => {
    expect(hasStartedTurn([])).toBe(false)
    expect(hasStartedTurn([
      event('agent-preset/selected', { agentPreset: 'ptc' }),
      event('model/selection', { provider: 'pi-ai', model: 'claude-x' }),
    ])).toBe(false)
  })

  it('is true once any turn started, even after it ended', () => {
    expect(hasStartedTurn([
      event('turn/start', { turn: 0 }),
      event('turn/end', { turn: 0, reason: { kind: 'completed' } }),
    ])).toBe(true)
  })
})

describe('makeRecord (preset seeding)', () => {
  const build = (init?: { agentPreset?: string; turnStarted?: boolean }): SessionRecord => makeRecord(
    'id' as never,
    '/ws',
    { agent: {} as never, dispose: () => Promise.resolve() },
    { current: undefined, assembled: undefined },
    init,
  )

  it('defaults to no preset and no turn', () => {
    const record = build()
    expect(record.agentPreset).toBeUndefined()
    expect(record.turnStarted).toBe(false)
  })

  it('carries the mounted preset and the lock state of a resumed session', () => {
    const record = build({ agentPreset: 'cordis', turnStarted: true })
    expect(record.agentPreset).toBe('cordis')
    expect(record.turnStarted).toBe(true)
  })
})
