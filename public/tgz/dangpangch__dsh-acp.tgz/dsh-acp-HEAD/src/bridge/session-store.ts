// Per-session bridge records: the live registry plus teardown/quiescence
// primitives (docs/design.zh.md §2.2). Teardown invariant: stop new work ->
// cancel admission/agent -> drain ordered updates -> dispose the agent ->
// flush persistence, scoped to the addressed session only. The registry and
// inflight state transitions are unit-testable without a harness.
import type { Agent, AgentHandle, ModelSelection, ModelSelectionRef } from '@deepseek-ai/dsh-agent'
import type { AgentCancelCause, SessionEvent, SessionEventMap, SessionId } from '@deepseek-ai/dsh-session'
import { basename, dirname, sep } from 'node:path'
import type { AcpStopReason } from './codec.js'

/** A session directory name: a UUID, optionally `session-` prefixed. */
const SESSION_DIR_NAME = /^(session-)?[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

/**
 * Resolve the session directory one stored-log artifact belongs to, or
 * `undefined` when the path must not be deleted. The one safety gate for ACP
 * `session/delete`: the artifact must live under the harness sessions root and
 * its own directory must carry a session identity, so a backend returning an
 * unexpected path can never turn the RPC into a wider delete.
 */
export function sessionDirForDelete(artifactPath: string, sessionsRoot: string): string | undefined {
  // The separator boundary matters: a plain prefix test would admit a sibling
  // like `<sessionsRoot>-evil/`.
  const base = sessionsRoot.endsWith(sep) ? sessionsRoot : sessionsRoot + sep
  if (!artifactPath.startsWith(base)) return undefined
  const dir = dirname(artifactPath)
  return SESSION_DIR_NAME.test(basename(dir)) ? dir : undefined
}

/** One in-flight `session/prompt`: the exact settlement bookkeeping. */
export interface PromptInflight {
  /** The RPC's stop-reason settlement promise (resolved/rejected once). */
  readonly promise: Promise<AcpStopReason>
  /** Settle the RPC with a terminal stop reason. */
  resolve(stopReason: AcpStopReason): void
  /** Reject the RPC (failed admission/turn/output — never a stop reason). */
  reject(error: unknown): void
  /** Message id of the queued user message, once queued. */
  messageId: string | undefined
  /** Whether the user message reached the agent inbox (agent work may follow). */
  messageQueued: boolean
  /** Owning turn, correlated via `agent/inbox/claimed`. */
  turn: number | undefined
  /** Kind of the correlated `turn/end` reason, once observed. */
  endKind: string | undefined
  /** Failure message detail when the correlated turn ended in `error`. */
  endMessage: string | undefined
  /** Client asked to cancel this prompt (session/cancel or teardown). */
  cancelRequested: boolean
  /** Whether settlement has already begun (idempotence guard). */
  settlementStarted: boolean
  /** Admission/queue phase promise; settlement awaits it first. */
  admissionDone: Promise<void>
  /** Completes the admission phase. */
  finishAdmission(): void
  /** Abort signal for admission work (image persistence etc.). */
  admissionController: AbortController
  /** First failure while serializing assistant output to the wire. */
  outputError: Error | undefined
  /** First agent failure correlated to this prompt. */
  agentError: Error | undefined
  /** Whether a slash command executed (no user message was queued). */
  commandExecuted: boolean | undefined
}

/** Live record for one ACP session. */
export interface SessionRecord {
  readonly id: SessionId
  /** Validated absolute cwd (SessionHeader.cwd). */
  readonly cwd: string
  /** The live dsh agent this ACP session drives. */
  readonly agent: Agent
  /** Owner disposer from the agent factory handle. */
  dispose(): Promise<void>
  /** Serialized update-delivery tail; settlement and close await it. */
  outputTail: Promise<void>
  /** Mutable model selection installed on the agent scope (set_config_option). */
  selection: ModelSelectionRef
  /** Currently open prompt, if any (single-flight per session). */
  inflight: PromptInflight | undefined
  /** Closed once this record is torn down (guards late settlement). */
  closed: boolean
  /** Reasoning efforts the current model declares (undefined = unknown). */
  supportedEfforts: ReadonlySet<string> | undefined
  /** Effective write-permission preset name (config option + /permission). */
  permission: string | undefined
  /**
   * Agent preset this session is composed from: the deployment default at
   * creation, the last `agent-preset/selected` pick after a pre-turn switch.
   * The preset select's current value (undefined = no roster).
   */
  agentPreset: string | undefined
  /**
   * A turn has begun. dsh refuses a preset switch from here on
   * (`agent-preset/locked`: the composition decides the tool set, so a started
   * session's preset is fixed) — the bridge stops advertising the selector at
   * the same boundary.
   */
  turnStarted: boolean
  /** Whole-table plan fold most recently delivered on the wire. */
  sentPlanFold: string | undefined
  /** Whether a plan was ever sent (turn/start clearing only after one). */
  everSentPlan: boolean
  /** Accumulated streamed text per turn/step/block (delta dedupe). */
  streamedText: Map<string, string>
  /** Accumulated streamed reasoning per turn/step/block (delta dedupe). */
  streamedReasoning: Map<string, string>
  /**
   * Live `agent/assistant-stream` attempt bookkeeping: attempt id -> the
   * turn/step the attempt started. Only the start frame carries turn/step, so
   * chunk frames resolve them through this map; each attempt ends by removing
   * its own entry.
   */
  streamAttempts: Map<string, { turn: number; step: number }>
  /** True while the record streams historical replay (no live output yet). */
  replaying: boolean
  /** Session title most recently pushed on the wire (session_info_update dedupe). */
  lastPushedTitle: string | undefined
  /**
   * Tools the user granted "always allow" this session (bridge-owned: dsh's
   * approval vocabulary is one-shot, so the persistent grant lives here and
   * auto-answers later asks for the same tool). In-memory only — a reloaded
   * session asks again.
   */
  allowedTools: Set<string>
}

/**
 * Live-session registry keyed by shared agent/session id. A plain Map plus
 * one identity-guarded remove helper: only the exact record instance an
 * owner registered may deregister itself (an impostor with the same id — a
 * superseded create racing a stale teardown — never removes the live entry).
 */
export type SessionRegistry = Map<SessionId, SessionRecord>

/** Deregister `record` only when it is still the registered instance. */
export function removeRecord(store: SessionRegistry, record: SessionRecord): void {
  if (store.get(record.id) === record) store.delete(record.id)
}

/** Allocate a fresh single-flight prompt slot (factory keeps transitions honest). */
export function createInflight(): PromptInflight {
  const admission = Promise.withResolvers<void>()
  const completion = Promise.withResolvers<AcpStopReason>()
  return {
    promise: completion.promise,
    resolve: (stopReason: AcpStopReason) => completion.resolve(stopReason),
    reject: (error: unknown) => completion.reject(error),
    messageId: undefined,
    messageQueued: false,
    turn: undefined,
    endKind: undefined,
    endMessage: undefined,
    cancelRequested: false,
    settlementStarted: false,
    admissionDone: admission.promise,
    finishAdmission: () => admission.resolve(),
    admissionController: new AbortController(),
    outputError: undefined,
    agentError: undefined,
    commandExecuted: undefined,
  }
}

/** Build a live session record from a resolved agent factory handle. */
export function makeRecord(
  id: SessionId,
  cwd: string,
  handle: AgentHandle,
  selection: ModelSelectionRef,
  init: { agentPreset?: string | undefined; turnStarted?: boolean | undefined } = {},
): SessionRecord {
  return {
    id,
    cwd,
    agent: handle.agent,
    dispose: () => handle.dispose(),
    outputTail: Promise.resolve(),
    selection,
    inflight: undefined,
    closed: false,
    supportedEfforts: undefined,
    permission: undefined,
    agentPreset: init.agentPreset,
    turnStarted: init.turnStarted ?? false,
    sentPlanFold: undefined,
    everSentPlan: false,
    replaying: false,
    lastPushedTitle: undefined,
    allowedTools: new Set(),
    streamedText: new Map(),
    streamedReasoning: new Map(),
    streamAttempts: new Map(),
  }
}

/** Await the record's quiescence: admission, agent idle, and output drain. */
export async function drainRecord(record: SessionRecord): Promise<void> {
  await record.inflight?.admissionDone
  await record.agent.whenIdle()
  await record.outputTail
}

/** Cancel everything a record owns and request the agent stop. */
export function requestStop(record: SessionRecord, cause: AgentCancelCause): void {
  const inflight = record.inflight
  if (inflight !== undefined) {
    inflight.cancelRequested = true
    inflight.admissionController.abort(new Error(`ACP ${cause.kind} stop`))
  }
  record.agent.cancel(cause)
}

/**
 * The LAST payload of one event type in the durable log (later writes win), or
 * undefined when the log never carried one. The shared fold behind every
 * "restore the session's last X" read.
 */
function lastEventPayload<T extends keyof SessionEventMap>(
  events: readonly SessionEvent[],
  type: T,
): SessionEventMap[T] | undefined {
  for (let index = events.length - 1; index >= 0; index -= 1) {
    const event = events[index]!
    if (event.type === type) return event.data as SessionEventMap[T]
  }
  return undefined
}

/**
 * The model selection to restore for a reloaded session (LAST snapshot wins).
 * Sessions predating the snapshot never carry one — callers then keep their
 * configured defaults.
 */
export function lastModelSelection(events: readonly SessionEvent[]): ModelSelection | undefined {
  const selection = lastEventPayload(events, 'model/selection')
  return selection !== undefined ? { ...selection } : undefined
}

/**
 * The LAST `agent-preset/selected` snapshot, so a reloaded session is composed
 * from the preset its history actually ran under. dsh's own reconstruction
 * reads the `agentPreset` session projection, never the creation header alone:
 * a pre-turn switch leaves the header naming the ORIGINAL default. Sessions
 * predating the event return undefined and the caller keeps the stored header.
 */
export function lastAgentPreset(events: readonly SessionEvent[]): string | undefined {
  return lastEventPayload(events, 'agent-preset/selected')?.agentPreset
}

/**
 * Whether a session has already produced a turn, i.e. dsh will refuse a preset
 * switch (`agent-preset/locked`). dsh's lock reads the `turnBoundary`
 * projection — `lastTurn > 0 || openTurnStartSeq !== null` — which `turn/start`
 * sets and `turn/end` only half-clears, so "a `turn/start` exists" is exactly
 * that condition.
 */
export function hasStartedTurn(events: readonly SessionEvent[]): boolean {
  return events.some((event) => event.type === 'turn/start')
}

/**
 * The LAST `session/title` snapshot, so a reloaded session can push its own
 * title to the client — the firehose never re-delivers historical title
 * events. Title-less sessions return undefined and the client keeps its
 * provisional title.
 */
export function lastSessionTitle(events: readonly SessionEvent[]): string | undefined {
  return lastEventPayload(events, 'session/title')?.title
}
