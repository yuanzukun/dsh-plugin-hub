// dsh-acp-v1: interactive ACP (Agent Client Protocol) v1 plugin for
// the DeepSeek Harness (dsh). Runs as a dsh bundle plugin inside a dsh profile
// (dsh --profile acp), opened by Zed's Agent Panel over stdio. One
// AgentSideConnection per process; one session record per ACP session;
// quiescent teardown per session and on disconnect/dispose. stdout stays
// JSON-RPC-only — every diagnostic rides ctx.logger (stderr).
//
// Mapping highlights (docs/design.zh.md §3):
//   session/new     -> ctx.agents.create (cwd + selection install), durable flush
//   session/prompt  -> single-flight text/image admission -> agent.followup
//                      -> committed assistant text streams as agent_message_chunk
//                      -> correlated turn/end settles the RPC via codec
//   cancel/close    -> per-session quiescent teardown (never touches siblings)
//   config options  -> model + thought_level selects over the llm catalog
//   per-agent plane -> agentPresets.mount (default preset, when the roster is up)
import type { Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
import { randomUUID } from 'node:crypto'
import { isAbsolute, join } from 'node:path'
import { Writable } from 'node:stream'
import {
  AgentSideConnection,
  PROTOCOL_VERSION,
  RequestError,
  ndJsonStream,
  type AuthenticateRequest,
  type CancelNotification,
  type CloseSessionRequest,
  type DeleteSessionRequest,
  type InitializeRequest,
  type InitializeResponse,
  type ListSessionsRequest,
  type ListSessionsResponse,
  type LoadSessionRequest,
  type NewSessionRequest,
  type NewSessionResponse,
  type PromptRequest,
  type PromptResponse,
  type ResumeSessionRequest,
  type SessionNotification,
} from '@agentclientprotocol/sdk'
import { installModelSelection, type ModelSelection, type ModelSelectionRef } from '@deepseek-ai/dsh-agent'
import { createUserMessage, errorChain, ReasoningEffortId, type ContentBlock } from '@deepseek-ai/dsh-llm'
import type { Agent, AgentCancelCause, AgentHandle, AgentSetup, AssistantStreamFrame } from '@deepseek-ai/dsh-agent'
// Type-only dependency: registers dsh-user-approval's `approval/request`
// event on the cordis Events map so the typed ctx.on handler below compiles.
import type {} from '@deepseek-ai/dsh-user-approval'
import { SessionId as brandSessionId, type Session, type SessionEvent, type SessionId } from '@deepseek-ai/dsh-session'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import type { AskUserQuestionAnswer, AskUserQuestionRequest } from '@deepseek-ai/dsh-user-questions'
import { resolveDshHome } from '@deepseek-ai/dsh-home-paths'
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { readFile } from 'node:fs/promises'

import type { ContentBlock as AcpContentBlock } from '@agentclientprotocol/sdk'
import {
  AcpContentError,
  contentForPrompt,
  isImageMediaType,
  persistImages,
  scanPrompt,
  type AttachmentStoreSeam,
} from './content.js'
import { settledStopReason, type DshTurnEndKind } from './codec.js'
import {
  createInflight,
  drainRecord,
  hasStartedTurn,
  lastAgentPreset,
  lastModelSelection,
  lastSessionTitle,
  makeRecord,
  removeRecord,
  requestStop,
  sessionDirForDelete,
  type PromptInflight,
  type SessionRecord,
  type SessionRegistry,
} from './session-store.js'
import {
  approvalPendingNote,
  assistantTextChunk,
  assistantThoughtChunk,
  commandsUpdate,
  committedBlockRemainder,
  configOptionsUpdate,
  foldStreamFrame,
  foldTodoPlan,
  planUpdate,
  requestPermissionRequest,
  sessionInfoUpdate,
  streamTextDelta,
  usageUpdate,
} from './updates.js'
import { askViaForm, type ElicitationBridge } from './elicitation.js'
import { replayUpdatesForEvent } from './replay.js'
import { mergeSlashCatalog, normalizeSkillSlashText, type SlashCatalogEntry, type SlashCommandEntry, type SlashSkillEntry } from './catalog.js'
import { rawInputOf, toolCallCard, toolResultCall, toolResultCard } from './tool-cards.js'
import {
  guardReasoningEffort,
  modelSelectOptionList,
  permissionSelectOptions,
  presetChangeFailureDetail,
  PRESET_LOCKED_DETAIL,
  presetSelectOptionList,
  PROVIDER_DEFAULT_REASONING_EFFORT,
  thoughtLevelCurrentFor,
  thoughtLevelOptionOptions,
  type CatalogProvider,
  type ModelReasoning,
  type PresetChoice,
} from './config-options.js'

/** Stable cordis plugin name (design.zh.md §5). */
export const name = 'dsh-acp-v1'

/** Agent spine services this bridge programs (validated on the rc.2 baseline). */
export const inject = ['agents', 'sessions', 'sessionQuery', 'sessionPersistence']

/** Deployment route defaults; per-session config options may override. */
export interface BridgeConfig {
  provider?: string
  model?: string
}

export const Config: Schema<BridgeConfig> = Schema.object({
  provider: Schema.string(),
  model: Schema.string(),
})

const AGENT_NAME = 'dsh-acp-v1'
const AGENT_VERSION = '0.5.0'
const CONFIG_ID_MODEL = 'model'
const CONFIG_ID_THOUGHT_LEVEL = 'thought_level'
const CONFIG_ID_PERMISSION = 'permission'
const CONFIG_ID_PRESET = 'preset'
const AUTH_ENV_KEY = 'DEEPSEEK_API_KEY'

/** Deployment env overrides (P1-4): read at session/agent creation, change = restart. */
const ENV_PRESET = 'DSH_ACP_PRESET'
const ENV_PROVIDER = 'DSH_ACP_PROVIDER'
const ENV_MODEL = 'DSH_ACP_MODEL'

/** Test-only mount snapshot gate (P1-5): write the mounted tool/slash surface
 * of every new session to $DSH_HOME/snapshots/<sessionId>.json for the
 * conformance harness to diff against the golden baseline. Files, never
 * stdout — frame purity holds. */
const ENV_MOUNT_SNAPSHOT = 'DSH_ACP_SNAPSHOT_MOUNTS'

/** Canonical write-permission preset ids (mirrors the dsh-base permission row). */
const PERMISSION_PRESETS = ['read-only', 'workspace-write', 'danger-full-access'] as const

type WireConfigOptions = NonNullable<NewSessionResponse['configOptions']>

/** Agent-presets roster seam (default-preset join per session, best effort). */
interface AgentPresetsSeam {
  resolve(id?: string): Promise<{ readonly id: string }>
  mount(ctx: unknown, id: string): Promise<unknown>
  /** Optional roster listing: the preset select's options and default errors. */
  list?(): Promise<readonly PresetChoice[]>
  /**
   * Re-link one agent to another preset's standing composition. dsh refuses a
   * session that has already produced a turn (`agent-preset/locked`); optional
   * so a roster without the switch path never advertises the selector.
   */
  select?(agent: Agent, presetId: string): Promise<string>
}

/** The deployment default preset could not be resolved (P1-4). */
class PresetDefaultError extends Error {}

/** Session-history query engine seam (session/list + load replay + titles). */
interface SessionQuerySeam {
  listSessions(signal?: AbortSignal): Promise<Array<{
    header: { id: SessionId; cwd?: string; agentPreset?: string }
    live: boolean
    persisted: boolean
  }>>
  readSession(sessionId: SessionId): Promise<{
    session: { cwd?: string; agentPreset?: string }
    events: readonly SessionEvent[]
  }>
  readTitle(sessionId: SessionId, signal?: AbortSignal): Promise<{ title: string } | undefined>
  listEvents(sessionId: SessionId, signal?: AbortSignal): Promise<Array<{ time: number }>>
}

/**
 * Durable-session artifact locator (delete seam; the backend owns removal).
 * dsh 0.1.5-rc.1 dropped `SessionPersistence.locate()` in favour of the JSONL
 * backend's generation-aware `resolveCurrentLog(id)`: the artifact path is no
 * longer a pure function of the header (`cwd` buckets the directory, the
 * filename carries the format generation), so the backend resolves it. Only a
 * current-generation log resolves; a session still stored solely in an older
 * generation returns `undefined` (delete then degrades to a warning).
 */
interface PersistenceSeam {
  resolveCurrentLog(id: SessionId, signal?: AbortSignal): Promise<string | undefined>
}

/** Write-permission preset seam (permission config option + /permission). */
interface PermissionPresetsSeam {
  set(session: Session, name: string): void
}

/** The projection read face the bridge uses for usage_update (token-meter unit). */
interface UsageProjectionService {
  snapshot(session: { readonly id: SessionId }): {
    values: { contextPressure?: { pressureTokens?: number; projectedTokens?: number; contextWindow?: number } }
  }
}

/** The dsh command runtime seam (slash commands, design §6.6). */
interface CommandRuntimeSeam {
  list(agent: Agent): readonly { name: string; description: string; input?: { hint: string } | null }[]
  execute(
    agent: Agent,
    line: string,
    submittedAttachments: readonly { type: 'image'; mediaType: string; data: string }[],
    signal: AbortSignal,
  ): Promise<{ result: { kind: 'success' | 'error'; text?: string } } | undefined>
}

/**
 * The dsh skill registry read seam (user-invocable slash skills, design §6.6).
 * Skills are layered per agent scope, so the bridge lists through the live
 * record's agent (mirroring how dsh-tool-skill builds its lookup). Only
 * `userInvocable` skills are announced: they are the human-facing slash
 * surface whose `/name` gesture dsh's pre-step hook expands into the skill
 * body for the model.
 */
interface SkillRegistrySeam {
  list(options?: {
    cwd?: string | undefined
    scope?: unknown
    signal?: AbortSignal | undefined
  }): Promise<readonly {
    name: string
    description: string
    invocation: { readonly modelInvocable: boolean; readonly userInvocable: boolean }
  }[]>
}

/** Preserve invalid-parameter detail in the SDK wire error message. */
function invalidParams(detail: string): RequestError {
  return RequestError.invalidParams(undefined, detail)
}

/** Preserve failed-turn detail; plain handler errors become a generic wire internal error. */
function internalError(detail: string): RequestError {
  return RequestError.internalError(undefined, detail)
}

interface LlmCatalogService {
  listProviders(): Promise<Array<{ id: string; name?: string }>>
  listModels(providerId: string): Promise<Array<{ id: string; name?: string; description?: string | null }>>
  resolveModelInfo(
    providerId: string,
    modelId: string,
    signal?: AbortSignal,
  ): Promise<{
    inputModalities?: readonly string[]
    reasoning?: { efforts: readonly { id: string; name: string; description?: string | null }[]; defaultEffort?: string }
  }>
}

/** The slash-command line when the prompt starts with '/', else undefined. */
function slashLine(prompt: readonly AcpContentBlock[]): string | undefined {
  const line = prompt.flatMap((block) => (block.type === 'text' ? [block.text] : [])).join('').trimEnd()
  return line.startsWith('/') ? line : undefined
}

/** Original wire image blocks as encoded attachments for the command plane.
 * dsh 0.1.5-rc.1 narrowed the submission union to a tagged
 * `CommandSubmitAttachment` (`{type:'image'} & EncodedImageAttachment`), so the
 * type discriminator is part of the parameter's shape, not decoration. */
function encodedImages(prompt: readonly AcpContentBlock[]): { type: 'image'; mediaType: string; data: string }[] {
  return prompt.flatMap((block) =>
    block.type === 'image' ? [{ type: 'image' as const, mediaType: block.mimeType, data: block.data }] : [],
  )
}

/**
 * Apply the bridge. On a serving invocation the app already published
 * readiness (stdin is ours); open the AgentSideConnection over stdin/stdout
 * and route session/* to per-session agent records.
 */
export function apply(ctx: Context, config: BridgeConfig = {}): void {
  const agents = ctx.agents
  const logger = ctx.logger
  const sessions = ctx.sessions
  const llm = ctx.get('llm') as LlmCatalogService | undefined
  const attachments = ctx.get('attachments') as AttachmentStoreSeam | undefined
  const commands = ctx.get('commands') as CommandRuntimeSeam | undefined
  const skills = ctx.get('skills') as SkillRegistrySeam | undefined
  const projections = ctx.get('sessionProjections') as UsageProjectionService | undefined
  const presets = ctx.get('agentPresets') as AgentPresetsSeam | undefined
  const query = ctx.get('sessionQuery') as SessionQuerySeam | undefined
  const persistence = ctx.get('sessionPersistence') as PersistenceSeam | undefined
  const permissionPresets = ctx.get('permissionPresets') as PermissionPresetsSeam | undefined
  const userQuestions = ctx.get('userQuestions') !== undefined
  const store: SessionRegistry = new Map()
  let closed = false
  let imagePromptEnabled = false
  let clientCapabilities: NonNullable<InitializeRequest['clientCapabilities']> | undefined
  // In-flight ACP request handlers: quiescence awaits them so a client that
  // closes stdin right after its requests still receives every reply before
  // the process exits (design.zh.md §6.1 immediate-EOF smoke).
  const activeRequests = new Set<Promise<unknown>>()
  // Latest ask_user_question tool call per session (elicitation tool tie).
  const askCall = new Map<SessionId, string>()
  // Tool-call id -> (name, parsed arguments) for the diff card at result time:
  // the `tool/result` event carries only the call id, and the diff source is
  // the call's arguments (str_replace_editor) or its presentation meta
  // (write/edit hunks). Entries are pruned once the result lands. Same
  // pairing shape the replay path keeps (replay.ts `calls`).
  const liveCalls = new Map<string, { name: string; rawInput: unknown }>()
  const elicitationFormsEnabled = (): boolean => {
    const capabilities = clientCapabilities as { elicitation?: { form?: unknown } } | undefined
    return capabilities?.elicitation?.form !== undefined
  }

  const assertOpen = (): void => {
    if (closed) throw internalError('the ACP bridge has been disposed')
  }

  /** Deployment-preset id: `DSH_ACP_PRESET` when set, else the roster default. */
  const presetIdForEnv = (): string | undefined => {
    const preset = process.env[ENV_PRESET]
    return preset !== undefined && preset.trim() !== '' ? preset : undefined
  }

  /**
   * The preset to compose a session from: a persisted pick wins, else
   * `DSH_ACP_PRESET`, else the roster default. `strict` (new sessions, P1-4)
   * turns an unresolvable deployment default into a client-visible config
   * error listing the available ids; best-effort (reload) warns and keeps the
   * global-layer session. An absent roster degrades either way.
   */
  const presetForSpawn = async (persisted: string | undefined, strict: boolean): Promise<string | undefined> => {
    if (persisted !== undefined) return persisted
    if (presets === undefined) return undefined
    try {
      return (await presets.resolve(presetIdForEnv())).id
    } catch (error: unknown) {
      if (!strict) {
        logger.warn(`dsh-acp-v1: default agent preset unavailable: ${errorChain(error)}`)
        return undefined
      }
      const label = presetIdForEnv() !== undefined ? 'DSH_ACP_PRESET preset' : 'default agent preset'
      const message = `${label} unavailable: ${errorChain(error)}`
      const available = await availablePresetIds()
      throw new PresetDefaultError(available === undefined ? message : `${message} — available: ${available}`)
    }
  }

  /**
   * Preset roster rows, or undefined when no roster (or no listing) is
   * mounted. Best effort: a failed read is a warning, never a broken session —
   * the preset select then simply does not appear.
   */
  const rosterRows = async (): Promise<readonly PresetChoice[] | undefined> => {
    if (presets === undefined || presets.list === undefined) return undefined
    try {
      return await presets.list()
    } catch (error: unknown) {
      logger.warn(`dsh-acp-v1: preset list unavailable: ${errorChain(error)}`)
      return undefined
    }
  }

  /** Preset ids the configured roots supply, for readable error messages. */
  const availablePresetIds = async (): Promise<string | undefined> => {
    const rows = await rosterRows()
    return rows?.map((row) => row.id).join(', ')
  }

  const requireSession = (sessionId: SessionId): SessionRecord => {
    const record = store.get(sessionId)
    if (record === undefined) throw invalidParams(`unknown session: ${sessionId}`)
    return record
  }

  // ── output delivery (serialized per session) ──────────────────────────────
  let conn: AgentSideConnection | undefined
  const notify = async (notification: SessionNotification): Promise<void> => {
    if (conn === undefined) return
    try {
      await conn.sessionUpdate(notification)
    } catch (error: unknown) {
      logger.warn(`dsh-acp-v1: session/update failed: ${String(error)}`)
    }
  }

  /** Chain one wire update onto the record's ordered delivery tail. */
  const deliver = (record: SessionRecord, update: SessionNotification['update']): void => {
    record.outputTail = record.outputTail.then(async () => {
      if (record.closed) return
      await notify({ sessionId: record.id, update })
    }).catch((error: unknown) => {
      const inflight = record.inflight
      if (inflight !== undefined) inflight.outputError ??= new Error(String(error))
      logger.warn(`dsh-acp-v1: output delivery failed: ${errorChain(error)}`)
    })
  }

  /** Settle one prompt after admission, agent quiescence, and output drain. */
  const settleAfterQuiescence = (record: SessionRecord, inflight: PromptInflight): void => {
    if (inflight.settlementStarted) return
    inflight.settlementStarted = true
    void (async () => {
      await drainRecord(record)
      if (record.inflight !== inflight) return
      record.inflight = undefined
      if (inflight.cancelRequested) {
        inflight.resolve('cancelled')
        return
      }
      if (inflight.outputError !== undefined) {
        inflight.reject(internalError(`assistant output delivery failed: ${inflight.outputError.message}`))
        return
      }
      if (inflight.agentError !== undefined) {
        inflight.reject(internalError(`turn failed: ${inflight.agentError.message}`))
        return
      }
      const kind = inflight.endKind as DshTurnEndKind | undefined
      if (kind === undefined) {
        // A slash command that ran without a model turn has no turn/end to
        // correlate; it still settles end_turn once the agent is quiet.
        inflight.resolve(inflight.commandExecuted === true ? 'end_turn' : 'cancelled')
        return
      }
      const stop = settledStopReason(kind)
      if (stop === null) {
        inflight.reject(internalError(`turn failed: ${inflight.endMessage ?? 'unknown'}`))
        return
      }
      inflight.resolve(stop)
    })().catch((error: unknown) => {
      if (record.inflight !== inflight) return
      record.inflight = undefined
      inflight.reject(internalError(`prompt settlement failed: ${errorChain(error)}`))
    })
  }

  /**
   * Chain one serialization task onto the delivery tail. A closed or
   * replaying record sends nothing, so the tasks themselves need no precheck.
   */
  const serialize = (record: SessionRecord, task: () => Promise<void>): void => {
    record.outputTail = record.outputTail.then(async () => {
      if (record.closed || record.replaying) return
      await task()
    }).catch((error: unknown) => {
      const inflight = record.inflight
      if (inflight !== undefined) inflight.outputError ??= new Error(String(error))
      logger.warn(`dsh-acp-v1: output conversion failed: ${errorChain(error)}`)
    })
  }

  /** Push a usage_update ring whenever both sides of the window are known. */
  const pushUsage = (record: SessionRecord): void => {
    if (projections === undefined) return
    const pressure = projections.snapshot(record.agent.session).values.contextPressure
    if (pressure === undefined) return
    const used = pressure.projectedTokens ?? pressure.pressureTokens
    const size = pressure.contextWindow
    if (used === undefined || size === undefined) return
    deliver(record, usageUpdate(used, size))
  }

  /** Map a committed assistant message, resending only unstreamed remainders. */
  const deliverAssistantMessage = (record: SessionRecord, turn: number, step: number, blocks: readonly ContentBlock[]): void => {
    serialize(record, async () => {
      for (let index = 0; index < blocks.length; index += 1) {
        const block = blocks[index]!
        const key = `${turn}:${step}:${index}`
        if (block.type === 'text') {
          const remainder = committedBlockRemainder(record.streamedText, key, block.text)
          if (remainder !== undefined) await notify({ sessionId: record.id, update: assistantTextChunk(remainder) })
        } else if (block.type === 'reasoning') {
          const remainder = committedBlockRemainder(record.streamedReasoning, key, block.text)
          if (remainder !== undefined) await notify({ sessionId: record.id, update: assistantThoughtChunk(remainder) })
        }
      }
      pushUsage(record)
    })
  }

  /** Deliver streamed deltas (thought/message) as they arrive. */
  const deliverStreamChunk = (record: SessionRecord, turn: number, step: number, chunk: { type: string; index?: number; text?: string }): void => {
    if (chunk.type === 'text-delta' && chunk.index !== undefined && chunk.text !== undefined && chunk.text.length > 0) {
      const key = `${turn}:${step}:${chunk.index}`
      const wire = streamTextDelta(record.streamedText, key, chunk.text, assistantTextChunk)
      if (wire !== undefined) deliver(record, wire)
    } else if (chunk.type === 'reasoning-delta' && chunk.index !== undefined && chunk.text !== undefined && chunk.text.length > 0) {
      const key = `${turn}:${step}:${chunk.index}`
      const wire = streamTextDelta(record.streamedReasoning, key, chunk.text, assistantThoughtChunk)
      if (wire !== undefined) deliver(record, wire)
    }
  }

  /**
   * Fold one live `agent/assistant-stream` frame into wire deltas.
   *
   * dsh 0.1.5-rc.1 replaced the durable `assistant/chunk` session event with a
   * process-local Agent event carrying start/chunk/end frames: only the start
   * frame names the turn and step, so the attempt bookkeeping lives on the
   * record and the mapping itself is the pure `foldStreamFrame`.
   */
  const deliverStreamFrame = (record: SessionRecord, frame: AssistantStreamFrame): void => {
    const live = foldStreamFrame(
      { attempts: record.streamAttempts, text: record.streamedText, reasoning: record.streamedReasoning },
      frame,
    )
    if (live === undefined) return
    deliverStreamChunk(record, live.turn, live.step, live.chunk)
  }

  /** Deliver the whole-table todo plan (and its turn/start clear). */
  const deliverPlan = (record: SessionRecord, todos: readonly { content: string; status: 'pending' | 'in_progress' | 'completed' }[]): void => {
    const fold = JSON.stringify(todos)
    if (fold === record.sentPlanFold) return
    record.sentPlanFold = fold
    record.everSentPlan = true
    deliver(record, planUpdate(todos))
  }

  const deliverPlanClear = (record: SessionRecord): void => {
    if (!record.everSentPlan || record.sentPlanFold === '[]') return
    record.sentPlanFold = '[]'
    deliver(record, planUpdate([]))
  }

  /**
   * Stream one session-title change to the client as a `session_info_update`
   * so its session list shows the generated/renamed title live. Deduped per
   * record (the title service can write consecutive snapshots) and skipped
   * during replay — the load path pushes the persisted title explicitly.
   */
  const deliverSessionTitle = (record: SessionRecord, title: string): void => {
    if (record.closed || record.replaying || record.lastPushedTitle === title) return
    record.lastPushedTitle = title
    serialize(record, async () => {
      await notify({ sessionId: record.id, update: sessionInfoUpdate(title) })
    })
  }

  /** Deliver a generic tool card on call and its terminal update on result. */
  const deliverToolCall = (record: SessionRecord, call: { callId: string; name: string; rawInput: unknown }): void => {
    // Follow-along: the location must reach the client while the tool runs,
    // so an `edit`'s line is inferred from the file's CURRENT content (the
    // tool has not executed yet); the sync readText seam makes the read
    // synchronous with the call-time card, and a missing file just drops
    // the line, never the location.
    const update = toolCallCard(call, record.cwd, (path) => {
      try {
        return readFileSync(path, 'utf8')
      } catch {
        return undefined
      }
    })
    serialize(record, async () => {
      await notify({ sessionId: record.id, update })
    })
  }

  const deliverToolResult = (
    record: SessionRecord,
    result: { callId: string; text: string; isError: boolean; name: string; rawInput: unknown; meta: unknown },
  ): void => {
    serialize(record, async () => {
      await notify({ sessionId: record.id, update: toolResultCard(result, record.cwd) })
      pushUsage(record)
    })
  }

  /**
   * Announce the session's slash catalog as one `available_commands_update`.
   * The list merges the dsh command plane (`ctx.commands`, e.g. goal /
   * permission / plan / compact / feedback) with **user-invocable skills**
   * (`ctx.skills`, sourced from the same global/project roots Zed reads —
   * `~/.agents/skills` and `<project>/.agents/skills`), because Zed 1.18 only
   * surfaces slash entries for an external ACP agent through
   * `available_commands_update` and validates any typed `/name` against that
   * list. Commands win name collisions; skills the user may not invoke stay
   * out. Execution needs no extra bridge code: a picked skill reaches the
   * prompt as a plain `/name` user text, and dsh's `tool-skill` pre-step hook
   * expands that gesture into the skill body for the model — exactly the dsh
   * Web "/"-menu behavior.
   */
  const slashCatalogFor = async (record: SessionRecord): Promise<SlashCatalogEntry[]> => {
    const commandEntries: SlashCommandEntry[] = []
    if (commands !== undefined) {
      for (const descriptor of commands.list(record.agent)) {
        commandEntries.push({
          name: descriptor.name,
          description: descriptor.description,
          ...(descriptor.input?.hint !== undefined && descriptor.input.hint.length > 0
            ? { inputHint: descriptor.input.hint }
            : {}),
        })
      }
    }
    let skillEntries: SlashSkillEntry[] = []
    if (skills !== undefined) {
      try {
        const summaries = await skills.list({ cwd: record.cwd, scope: record.agent })
        skillEntries = summaries.map((skill) => ({
          name: skill.name,
          description: skill.description,
          userInvocable: skill.invocation.userInvocable,
        }))
      } catch (error: unknown) {
        logger.warn(`dsh-acp-v1: skill catalog unavailable for slash list: ${errorChain(error)}`)
      }
    }
    return mergeSlashCatalog(commandEntries, skillEntries)
  }

  /** Deferred slash-catalog announcement (Zed ignores unknown-session updates). */
  const announceSlashCatalog = (record: SessionRecord): void => {
    setTimeout(() => {
      void slashCatalogFor(record)
        .then((entries) => {
          if (entries.length === 0 || record.closed) return
          deliver(record, commandsUpdate(entries))
        })
        .catch((error: unknown) => {
          logger.warn(`dsh-acp-v1: slash catalog announcement failed: ${errorChain(error)}`)
        })
    }, 0)
  }

  // Keep every open session's slash popup fresh when either catalog source
  // changes (a skill installed into ~/.agents/skills or <project>/.agents/skills
  // while a Zed thread is open must appear without recreating the thread).
  // The registry change events ride the same host context the rows mount on.
  if (commands !== undefined || skills !== undefined) {
    const refreshAll = (): void => {
      for (const record of store.values()) announceSlashCatalog(record)
    }
    // `skills/change` and `commands/change` are declared on the host-plane
    // registry modules (@deepseek-ai/dsh-skill, @deepseek-ai/dsh-commands) that
    // this bundle does not import; subscribe through the untyped context.
    const host = ctx as unknown as { on(event: string, listener: () => void): unknown }
    host.on('skills/change', refreshAll)
    host.on('commands/change', refreshAll)
  }

  // ── P1-5 mount audit: env-gated snapshot of a new session's actual
  // mounted surface (tools via the registry's agent view, slash via the same
  // announce catalog), written to a sidecar file for the conformance harness.
  const snapshotMounts = async (record: SessionRecord): Promise<void> => {
    if (process.env[ENV_MOUNT_SNAPSHOT] === undefined) return
    try {
      const toolsService = ctx.get('tools') as
        | { schemas(scope?: unknown): readonly { readonly name: string }[] }
        | undefined
      const toolNames = [...(toolsService?.schemas(record.agent) ?? [])]
        .map((tool) => tool.name)
        .sort()
      // Command-plane names only: user skills under ~/.agents/skills are
      // host-environment content and would make the baseline machine-specific.
      const commandNames = [...(commands?.list(record.agent) ?? [])]
        .map((command) => command.name)
        .sort()
      const dir = join(resolveDshHome(), 'snapshots')
      mkdirSync(dir, { recursive: true })
      writeFileSync(
        join(dir, `${record.id}.json`),
        JSON.stringify({ sessionId: record.id, tools: toolNames, slash: commandNames }, null, 2),
      )
    } catch (error: unknown) {
      logger.warn(`dsh-acp-v1: mount snapshot failed: ${errorChain(error)}`)
    }
  }

  // ── dsh event firehose -> wire updates ────────────────────────────────────
  // Live assistant deltas ride their own Agent event since 0.1.5-rc.1: the
  // durable `assistant/chunk` session event is gone (the committed
  // `assistant/message`/`assistant/attempt` now carries the exact stream), and
  // `agent/assistant-stream` publishes transient start/chunk/end frames. An
  // unscoped listener receives every agent's frames (dsh-scope admits untagged
  // listeners globally), matching the session/event subscribe pattern below.
  ctx.on('agent/assistant-stream', ({ agent, frame }) => {
    const record = store.get(agent.session.id)
    if (record === undefined || record.agent !== agent) return
    deliverStreamFrame(record, frame)
  })

  ctx.on('session/event', (session, event) => {
    const record = store.get(session.header.id)
    if (record === undefined || record.agent.session !== session) return
    const inflight = record.inflight
    switch (event.type) {
      case 'assistant/message':
        deliverAssistantMessage(record, event.data.turn, event.data.step, event.data.message.content)
        break
      case 'tool/call': {
        const rawInput = rawInputOf(event.data.arguments)
        if (event.data.name === 'ask_user_question') askCall.set(record.id, String(event.data.callId))
        liveCalls.set(String(event.data.callId), { name: event.data.name, rawInput })
        deliverToolCall(record, { callId: event.data.callId, name: event.data.name, rawInput })
        break
      }
      case 'tool/result': {
        const call = toolResultCall(event.data.message)
        // The diff source pair: the call's arguments (parsed at call time; the
        // result event carries only the id) and the tool's presentation meta.
        const source = liveCalls.get(call.callId)
        deliverToolResult(record, {
          callId: call.callId,
          text: call.text,
          isError: event.data.error !== undefined,
          name: source?.name ?? '',
          rawInput: source?.rawInput,
          meta: event.data.meta,
        })
        liveCalls.delete(call.callId)
        break
      }
      case 'todo/write':
        deliverPlan(record, event.data.todos)
        break
      case 'session/title':
        deliverSessionTitle(record, event.data.title)
        break
      case 'turn/start':
        deliverPlanClear(record)
        // First turn: the composition is now fixed (dsh refuses a preset
        // switch from here), so the selector leaves the client's toolbar at
        // the same boundary dsh locks it.
        if (!record.turnStarted) {
          record.turnStarted = true
          dropPresetOption(record)
        }
        break
      case 'turn/end': {
        if (inflight !== undefined && inflight.turn === event.data.turn) {
          inflight.endKind = event.data.reason.kind
          if (event.data.reason.kind === 'error') {
            const failure = (event.data.reason as { error?: { message?: string } }).error
            inflight.endMessage = failure?.message ?? ''
          }
          settleAfterQuiescence(record, inflight)
        }
        pushUsage(record)
        break
      }
      default:
        break
    }
  })

  // One-shot permission answerer: bridge-owned approval requests become ACP
  // session/request_permission with allow-once / allow-always / reject-once
  // choices; foreign or call-less requests delegate (design §6.1). An
  // allow-always pick is honored bridge-side for the rest of the session —
  // dsh's approval vocabulary is one-shot, so the persistent grant lives on
  // the record and auto-answers later asks for the same tool.
  ctx.on('approval/request', (request, next) => {
    if (conn === undefined) return next()
    const record = store.get(request.agent.session.id)
    if (record === undefined || record.agent !== request.agent) return next()
    if (record.allowedTools.has(request.toolName)) return Promise.resolve('allowed-once')
    if (request.callId === undefined) return next()
    const callId = request.callId
    // Announce the wait on the conversation stream BEFORE asking, then await
    // that same tail so the chunk is on the wire ahead of the permission
    // request (a user who is not looking at this agent, or comes back later,
    // can see why it stalled — issue #1). The tail is `outputTail`, NOT
    // `drainRecord`: drainRecord awaits agent.whenIdle(), which waits on the
    // driver promise while the driver is awaiting THIS approval, i.e. a
    // self-wait deadlock that never sends the request at all.
    deliver(record, approvalPendingNote(request.toolName, request.reason))
    return record.outputTail.then(() =>
      conn!.requestPermission(requestPermissionRequest(record.id, callId)),
    ).then(({ outcome }) => {
      if (outcome.outcome === 'cancelled') return 'cancelled'
      if (outcome.optionId === 'allow-always') {
        record.allowedTools.add(request.toolName)
        return 'allowed-once'
      }
      return outcome.optionId === 'allow-once' ? 'allowed-once' : 'rejected'
    })
  })

  // Catalog hot updates: the model/thought/permission selects advertise a
  // snapshot of the dsh-llm topology, so when adapters register/replace under
  // live sessions every online record gets a fresh full-replacement
  // config_option_update (docs/model-config.zh.md §4). A failed rebuild keeps
  // the client's current dropdowns (warn, never break the session); replaying
  // or closing records are skipped.
  ctx.on('llm/adapters-updated', () => {
    for (const record of store.values()) {
      serialize(record, async () => {
        try {
          await notify({ sessionId: record.id, update: configOptionsUpdate(await refreshConfigOptions(record)) })
        } catch (error: unknown) {
          logger.warn(`dsh-acp-v1: config options hot refresh failed: ${errorChain(error)}`)
        }
      })
    }
  })

  ctx.on('agent/inbox/claimed', ({ agent, message, turn }) => {
    const record = store.get(agent.session.id)
    const inflight = record?.inflight
    if (inflight !== undefined && inflight.messageId === message.id) inflight.turn = turn
  })

  ctx.on('agent/error', ({ agent, turn, error }) => {
    const record = store.get(agent.session.id)
    const inflight = record?.inflight
    if (record === undefined || inflight === undefined || !inflight.messageQueued || inflight.turn === turn) return
    inflight.agentError = new Error(errorChain(error))
    settleAfterQuiescence(record, inflight)
  })

  // ── scoped teardown: stop, drain, dispose, flush; session-scoped only ─────
  const closing = new WeakMap<SessionRecord, Promise<void>>()
  const closeOne = (record: SessionRecord, cause: AgentCancelCause): Promise<void> => {
    const pending = closing.get(record)
    if (pending !== undefined) return pending
    const run = (async () => {
      if (record.closed) return
      requestStop(record, cause)
      await drainRecord(record)
      await record.dispose()
      try {
        await sessions.flush(record.agent.session)
      } catch (error: unknown) {
        logger.warn(`dsh-acp-v1: persistence flush failed on close: ${String(error)}`)
      }
      record.closed = true
    })()
    closing.set(record, run)
    return run
  }

  // ── config options (P1): model + thought_level selects ────────────────────
  /** Shipped route defaults: a model-selection ref plus the factory options bag.
   * Deployment env overrides (DSH_ACP_PROVIDER / DSH_ACP_MODEL) win over the
   * patch row's defaults; per-session config options still override both. */
  const routeDefaults = (): {
    selection: ModelSelectionRef
    agentOptions: { provider?: string; model?: string } | undefined
  } => {
    const provider = process.env[ENV_PROVIDER] ?? config.provider
    const model = process.env[ENV_MODEL] ?? config.model
    const selection: ModelSelectionRef = { current: undefined, assembled: undefined }
    if (provider !== undefined && model !== undefined) {
      selection.current = { provider, model }
    }
    const agentOptions = provider !== undefined || model !== undefined
      ? { provider, model }
      : undefined
    return { selection, agentOptions }
  }

  /**
   * Compose and spawn one agent, create or resume: the route defaults, the
   * preset join (strict for a new session, best-effort for a reload), the
   * shared model-selection + preset setup closure, and the mid-spawn close
   * guard. Returns the handle, the selection the record keeps, and the preset
   * actually mounted (undefined without a roster).
   */
  const spawnAgent = async (
    spawn: (ready: {
      agentOptions: { provider?: string; model?: string } | undefined
      setup: AgentSetup
      presetId: string | undefined
    }) => Promise<AgentHandle>,
    options: { presetFrom?: string | undefined; strict?: boolean; what: string },
  ): Promise<{ handle: AgentHandle; selection: ModelSelectionRef; presetId: string | undefined }> => {
    const { selection, agentOptions } = routeDefaults()
    const presetId = await presetForSpawn(options.presetFrom, options.strict === true)
    const setup: AgentSetup = async (agentCtx) => {
      installModelSelection(agentCtx, selection)
      if (presetId !== undefined && presets !== undefined) {
        // The roster is our own row; a broken default must fail this
        // session's creation loudly instead of half-composing it.
        await presets.mount(agentCtx, presetId)
      }
    }
    const handle = await spawn({ agentOptions, setup, presetId })
    if (closed) {
      await handle.dispose().catch(() => {})
      throw internalError(`connection closed during ${options.what}`)
    }
    return { handle, selection, presetId }
  }

  const reasoningFor = async (provider: string, model: string): Promise<ModelReasoning | undefined> => {
    if (llm === undefined) return undefined
    try {
      const resolved = await llm.resolveModelInfo(provider, model)
      // A RESOLVED model always yields a ModelReasoning — with an empty
      // efforts list when it declares none — which both hides the thinking
      // selector (the model honors no explicit effort) and lets the request
      // guard strip stale picks instead of letting the harness reject the
      // turn (UNSUPPORTED_REASONING_EFFORT). undefined is reserved for a
      // failed lookup, where support is genuinely unknown and the canonical
      // fallback table stays selectable.
      const reasoning = resolved.reasoning
      return {
        efforts: (reasoning?.efforts ?? []).map((effort) => ({
          id: effort.id,
          name: effort.name,
          description: effort.description ?? null,
        })),
        ...(reasoning?.defaultEffort !== undefined ? { defaultEffort: reasoning.defaultEffort } : {}),
      }
    } catch (error: unknown) {
      logger.warn(`dsh-acp-v1: reasoning catalog for ${provider}/${model} failed: ${String(error)}`)
      return undefined
    }
  }

  /**
   * Last full option snapshot per live session. The `turn/start` removal of the
   * preset select re-sends this list minus that one entry instead of rebuilding
   * the catalog mid-turn, where a failed catalog call would silently drop the
   * Model select. Weak-keyed: no teardown bookkeeping.
   */
  const configOptionsCache = new WeakMap<SessionRecord, WireConfigOptions>()

  const refreshConfigOptions = async (record: SessionRecord): Promise<WireConfigOptions> => {
    const out: WireConfigOptions = []
    // The preset select rides the session's own composition, not the model
    // route: it is advertised only while dsh would still accept a switch (no
    // turn yet). A started session's preset is fixed, so the option is dropped
    // at the first turn/start (dropPresetOption) instead of offering a pick
    // the harness must refuse with `agent-preset/locked`.
    if (!record.turnStarted && presets?.list !== undefined && presets.select !== undefined) {
      const rows = await rosterRows()
      const preset = rows !== undefined ? presetSelectOptionList(rows, record.agentPreset) : null
      if (preset !== null) {
        out.push({
          type: 'select',
          id: CONFIG_ID_PRESET,
          name: 'Preset',
          description: 'Agent composition for this session (tool set, prompt, skills); fixed once the first turn starts.',
          category: 'preset',
          currentValue: preset.currentValue,
          options: preset.options,
        })
      }
    }
    const current = record.selection.current
    if (llm !== undefined && current !== undefined && current.provider !== undefined && current.model !== undefined) {
      try {
        const providers = await llm.listProviders()
        const catalog: CatalogProvider[] = []
        for (const provider of providers) {
          let models: CatalogProvider['models'] = []
          try {
            models = (await llm.listModels(provider.id)) as CatalogProvider['models']
          } catch (error: unknown) {
            logger.warn(`dsh-acp-v1: model catalog for ${provider.id} failed: ${String(error)}`)
          }
          catalog.push({ id: provider.id, name: provider.name, models })
        }
        const flat = modelSelectOptionList(catalog, { provider: current.provider, model: current.model })
        if (flat !== null && flat.options.length > 0) {
          out.push({
            type: 'select',
            id: CONFIG_ID_MODEL,
            name: 'Model',
            description: 'Model used for new requests in this session.',
            category: 'model',
            currentValue: flat.currentValue,
            options: flat.options,
          })
        }
      } catch (error: unknown) {
        logger.warn(`dsh-acp-v1: provider catalog failed: ${String(error)}`)
      }
      const reasoning = await reasoningFor(current.provider, current.model)
      // Remember exactly which efforts the current model honors so a stale
      // pick never reaches request assembly (design §6.3 request guard). A
      // model that resolved but declares no efforts supports NONE of them —
      // an empty set strips any explicit pick back to provider/default
      // behavior at prompt time, and the selector below hides (offering
      // levels the model would refuse is advertising, not support). Only a
      // failed catalog lookup (reasoning undefined) keeps the pick: unknown,
      // not unsupported. Refreshed even when the selector hides so a model
      // switch can never leave a stale supported set behind.
      record.supportedEfforts = reasoning !== undefined
        ? new Set((reasoning.efforts ?? []).map((effort) => effort.id))
        : undefined
      // A reloaded session can carry a pick the current model no longer offers
      // (a snapshot from an older build, a catalog change). Heal it durably
      // BEFORE the select is built, so a reload never resurrects the stale pick
      // and the currentValue below can only name an offered id.
      guardCurrentEffort(record)
      const offered = thoughtLevelOptionOptions(reasoning)
      if (offered.length > 0) {
        const currentEffort = thoughtLevelCurrentFor(record.selection.current?.reasoningEffort, reasoning)
        out.push({
          type: 'select',
          id: CONFIG_ID_THOUGHT_LEVEL,
          name: 'Thought Level',
          description: 'Reasoning effort for models that support selectable levels.',
          category: 'thought_level',
          currentValue: currentEffort,
          options: offered.map((effort) => ({ value: effort.id, name: effort.name, description: effort.description })),
        })
      }
      if (permissionPresets !== undefined) {
        const names = PERMISSION_PRESETS as readonly string[]
        const currentValue = record.permission ?? 'workspace-write'
        out.push({
          type: 'select',
          id: CONFIG_ID_PERMISSION,
          name: 'Write permission',
          description: 'One-shot permission preset for this session (sandbox mode + approval policy).',
          category: 'permission',
          currentValue: names.includes(currentValue) ? currentValue : names[1]!,
          options: permissionSelectOptions(names),
        })
      }
    }
    configOptionsCache.set(record, out)
    return out
  }

  /**
   * Stop advertising the preset select once the session has started: dsh fixes
   * the composition there (`agent-preset/locked`), so the selector's absence is
   * the truthful surface. Full replacement from the cached snapshot — no
   * catalog I/O during a turn, and the other selectors cannot be disturbed.
   */
  const dropPresetOption = (record: SessionRecord): void => {
    if (presets?.list === undefined || presets.select === undefined) return
    const cached = configOptionsCache.get(record)
    if (cached === undefined || !cached.some((option) => option.id === CONFIG_ID_PRESET)) return
    const next = cached.filter((option) => option.id !== CONFIG_ID_PRESET)
    serialize(record, async () => {
      try {
        await notify({ sessionId: record.id, update: configOptionsUpdate(next) })
      } catch (error: unknown) {
        logger.warn(`dsh-acp-v1: preset selector removal failed: ${errorChain(error)}`)
      }
    })
  }

  /**
   * Commit one validated selection change: update the live ref AND append a
   * durable snapshot to the session log, so a reloaded session restores the
   * route (and picked effort) it actually used instead of reverting to the
   * configured default (design §6.3; the todo/write precedent for log-only
   * plugin events).
   */
  const setSelection = (record: SessionRecord, next: ModelSelection): void => {
    record.selection.current = next
    record.agent.session.append('model/selection', next)
  }

  /** Apply one validated config change; takes effect on the next turn. */
  const applyConfigOption = async (record: SessionRecord, configId: string, value: unknown): Promise<void> => {
    if (typeof value !== 'string') throw invalidParams(`config option "${configId}" expects a select value id`)
    // Preset first: it is independent of the model route and is the one option
    // that closes a window — dsh accepts the switch only while the session has
    // produced no turn (`agent-preset/locked` otherwise).
    if (configId === CONFIG_ID_PRESET) {
      if (presets?.select === undefined) throw invalidParams('agent presets are not mounted')
      if (record.turnStarted) throw invalidParams(PRESET_LOCKED_DETAIL)
      const rows = await rosterRows()
      const offered = rows !== undefined ? presetSelectOptionList(rows, record.agentPreset) : null
      if (offered === null || !offered.options.some((option) => option.value === value)) {
        throw invalidParams(`unknown agent preset: ${value}`)
      }
      try {
        record.agentPreset = await presets.select(record.agent, value)
      } catch (error: unknown) {
        throw invalidParams(presetChangeFailureDetail(error))
      }
      // The preset owns the skill/command surface: a switch changes what the
      // client's slash popup should offer.
      announceSlashCatalog(record)
      return
    }
    const current = record.selection.current
    if (current === undefined || current.provider === undefined || current.model === undefined) {
      throw invalidParams('config options are unavailable: the session has no model route')
    }
    if (configId === CONFIG_ID_MODEL) {
      const slash = value.indexOf('/')
      if (slash <= 0 || slash === value.length - 1) throw invalidParams(`unknown model value: ${value}`)
      // Switching models clears the effort: the new model's provider default
      // governs until the user picks another level.
      setSelection(record, { provider: value.slice(0, slash), model: value.slice(slash + 1) })
      return
    }
    if (configId === CONFIG_ID_THOUGHT_LEVEL) {
      const reasoning = await reasoningFor(current.provider, current.model)
      const offered = thoughtLevelOptionOptions(reasoning)
      if (!offered.some((effort) => effort.id === value)) throw invalidParams(`unknown thought_level value: ${value}`)
      if (value === PROVIDER_DEFAULT_REASONING_EFFORT) {
        const { reasoningEffort: _stripped, ...rest } = current
        setSelection(record, rest)
        return
      }
      setSelection(record, { ...current, reasoningEffort: ReasoningEffortId(value) })
      return
    }
    if (configId === CONFIG_ID_PERMISSION) {
      if (permissionPresets === undefined) throw invalidParams('permission presets are not mounted')
      if (!(PERMISSION_PRESETS as readonly string[]).includes(value)) throw invalidParams(`unknown permission preset: ${value}`)
      record.permission = value
      permissionPresets.set(record.agent.session, value)
      return
    }
    throw invalidParams(`unknown config option: ${configId}`)
  }

  /**
   * Strip a reasoning effort the current model cannot honor — durably, by
   * committing the corrected selection (a reload must not resurrect the stale
   * pick). Runs before the thought_level select is built and again before a
   * prompt is queued; an unknown supported set (no model metadata yet) keeps
   * the pick: unknown, not unsupported.
   */
  const guardCurrentEffort = (record: SessionRecord): void => {
    const current = record.selection.current
    if (current?.reasoningEffort === undefined) return
    const supported = record.supportedEfforts
    if (supported === undefined) return
    const guarded = guardReasoningEffort({ reasoningEffort: current.reasoningEffort }, supported)
    if (guarded.reasoningEffort === undefined) {
      const { reasoningEffort: _stripped, ...rest } = current
      setSelection(record, rest)
    }
  }

  // ── advertise images only when the attachment store and model agree ───────
  const supportsImages = async (): Promise<boolean> => {
    if (attachments === undefined || llm === undefined || config.provider === undefined || config.model === undefined) return false
    if (!attachments.imageLimits.mediaTypes.some((mediaType) => isImageMediaType(mediaType))) return false
    try {
      const info = await llm.resolveModelInfo(config.provider, config.model)
      return info.inputModalities?.includes('image') === true
    } catch {
      return false
    }
  }

  const validateWorkspaceParams = (params: {
    cwd: string
    additionalDirectories?: readonly unknown[] | null
    mcpServers?: readonly unknown[] | null
  }): void => {
    if (!isAbsolute(params.cwd)) throw invalidParams(`cwd must be an absolute path: ${params.cwd}`)
    // Unreachable defensive rejection in practice: Zed only fills
    // additional_directories when the agent advertises the
    // `session_capabilities.additional_directories` capability, which the
    // bridge deliberately does not (dsh scopes its file tools to the session
    // cwd). Keep the honest error should that ever change.
    if (params.additionalDirectories !== undefined && params.additionalDirectories !== null && params.additionalDirectories.length > 0) {
      throw invalidParams('additionalDirectories is not supported')
    }
    // Real clients (Zed) forward `mcpServers` unconditionally. The bridge
    // mounts no MCP tools, so the honest handling is accept-and-ignore with a
    // stderr note — rejecting turns 'not supported' into 'unusable' (P1-6).
    if (params.mcpServers !== undefined && params.mcpServers !== null && params.mcpServers.length > 0) {
      logger.warn(`dsh-acp-v1: mcpServers accepted but ignored (${params.mcpServers.length} server(s)); no MCP tools are mounted`)
    }
  }

  // ── session history: list / load / resume / delete helpers ─────────────────
  /** Look a persisted session up by id and return its stored header facts. */
  const persistedHeader = async (sessionId: SessionId): Promise<{ cwd: string; agentPreset?: string } | undefined> => {
    if (query === undefined) return undefined
    const records = await query.listSessions()
    const record = records.find((entry) => entry.header.id === sessionId && entry.persisted)
    if (record === undefined) return undefined
    const cwd = record.header.cwd
    return cwd !== undefined && cwd.length > 0 ? { cwd, agentPreset: record.header.agentPreset } : undefined
  }

  /** Latest activity time of one session as an ISO string (best effort). */
  const updatedAtFor = async (sessionId: SessionId): Promise<string | undefined> => {
    if (query === undefined) return undefined
    try {
      const events = await query.listEvents(sessionId)
      let latest = 0
      for (const event of events) if (event.time > latest) latest = event.time
      return latest > 0 ? new Date(latest).toISOString() : undefined
    } catch {
      return undefined
    }
  }

  /** Display title of one session (best effort; none -> undefined). */
  const titleFor = async (sessionId: SessionId): Promise<string | undefined> => {
    if (query === undefined) return undefined
    try {
      return (await query.readTitle(sessionId))?.title
    } catch {
      return undefined
    }
  }

  /** Dispose and deregister a live bridge record for the id, if any. */
  const releaseOnline = async (sessionId: SessionId): Promise<void> => {
    const record = store.get(sessionId)
    if (record === undefined) return
    removeRecord(store, record)
    await closeOne(record, { kind: 'disposed' })
  }

  /**
   * Publish a freshly built record (session/new and load/resume share the
   * tail): register, build config options, kick off the background durability
   * flush and the deferred slash-catalog announcement, and roll the record
   * back loudly on failure.
   */
  const registerRecord = async (
    record: SessionRecord,
    replay?: () => Promise<void>,
  ): Promise<WireConfigOptions> => {
    store.set(record.id, record)
    try {
      assertOpen()
      const configOptions = await refreshConfigOptions(record)
      assertOpen()
      // Durability for an empty session is a background concern: the
      // persistence checkpoint also runs at teardown (closeOne) and after
      // real turns. Flushing here would block the response on disk I/O and
      // lose the reply to a client that closes stdin right after its
      // requests (design.zh.md §6.1 immediate-EOF smoke).
      void sessions.flush(record.agent.session).catch((error: unknown) => {
        logger.warn(`dsh-acp-v1: background persistence flush failed: ${String(error)}`)
      })
      // Slash catalog (commands + user-invocable skills): deferred past the
      // session/new response — Zed ignores notifications for session ids it
      // does not know yet (design §6.6).
      announceSlashCatalog(record)
      if (replay !== undefined) await replay()
      return configOptions
    } catch (error: unknown) {
      if (store.get(record.id) === record) removeRecord(store, record)
      await closeOne(record, { kind: 'disposed' }).catch(() => {})
      throw error
    }
  }

  /**
   * Stream one persisted session's history to the client as wire updates
   * (session/load semantics). Committed assistant content and tool cards from
   * the raw log, ending with the todo history folded to one final plan update;
   * raw deltas and usage never replay. Each frame is awaited in order so the
   * load response never races it.
   */
  const replayHistory = async (record: SessionRecord, events: readonly SessionEvent[]): Promise<void> => {
    record.replaying = true
    try {
      // Call-id pairing for the result-time diff card, built as the log walks
      // (the same pairing shape the live firehose keeps in `liveCalls`).
      const calls = new Map<string, { name: string; rawInput: unknown }>()
      for (const event of events) {
        if (record.closed) return
        if (event.type === 'tool/call') {
          calls.set(String(event.data.callId), { name: event.data.name, rawInput: rawInputOf(event.data.arguments) })
        }
        for (const update of replayUpdatesForEvent(event, { cwd: record.cwd, calls })) {
          await notify({ sessionId: record.id, update })
        }
      }
      // One final plan state (last todo/write wins; turn/start clears); a log
      // that never rendered a plan gets nothing — replay never fabricates.
      const entries = foldTodoPlan(events)
      if (entries !== undefined && !record.closed) await notify({ sessionId: record.id, update: planUpdate(entries) })
    } finally {
      record.replaying = false
    }
  }

  /** One ordered "create-or-resume" agent handle for history loads. */
  const resumeAgentFor = async (
    sessionId: SessionId,
    agentPreset: string | undefined,
  ): Promise<{
    handle: AgentHandle
    selection: ModelSelectionRef
    presetId: string | undefined
  }> =>
    spawnAgent(
      ({ agentOptions, setup }) => agents.resume({ resumeSessionId: sessionId, agentOptions, setup }),
      { presetFrom: agentPreset, what: 'session load/resume' },
    )

  /**
   * Best-effort durable delete of one session artifact (idempotent).
   *
   * The backend resolves the artifact path (0.1.5-rc.1 no longer exposes the
   * header-addressed `locate()`); the two fences below still own the safety
   * decision: the resolved path must live under `$DSH_HOME/sessions`, and its
   * session directory must carry a UUID name. A path that only exists in an
   * older format generation is not current and stays undeleted.
   */
  const deletePersisted = async (id: SessionId): Promise<void> => {
    if (persistence === undefined) return
    let artifact: string | undefined
    try {
      artifact = await persistence.resolveCurrentLog(id)
    } catch (error: unknown) {
      logger.warn(`dsh-acp-v1: durable delete skipped: resolveCurrentLog failed: ${errorChain(error)}`)
      return
    }
    if (artifact === undefined) {
      logger.warn(`dsh-acp-v1: durable delete skipped: no current-generation log for ${id}`)
      return
    }
    const sessionDir = sessionDirForDelete(artifact, join(resolveDshHome(), 'sessions'))
    if (sessionDir === undefined) {
      logger.warn(`dsh-acp-v1: refusing to delete unexpected session artifact: ${artifact}`)
      return
    }
    try {
      rmSync(sessionDir, { recursive: true, force: true })
    } catch (error: unknown) {
      logger.warn(`dsh-acp-v1: durable delete failed: ${errorChain(error)}`)
    }
  }

  // ── Agent implementation (SDK 1.4.0 Agent interface) ──────────────────────
  const implementation = {
    async initialize(params: InitializeRequest): Promise<InitializeResponse> {
      clientCapabilities = params.clientCapabilities ?? undefined
      imagePromptEnabled = await supportsImages()
      // Truthful capability surface (design.zh.md §3.6): session history is
      // available whenever the session-query engine is composed; image prompts
      // only when the attachment store and the default route both accept them;
      // elicitation forms only when the client declared form support AND a
      // question provider can be bridged. Nothing un-implemented is advertised.
      const history = query !== undefined
      return {
        protocolVersion: PROTOCOL_VERSION,
        agentInfo: { name: AGENT_NAME, version: AGENT_VERSION },
        agentCapabilities: {
          loadSession: history,
          promptCapabilities: { image: imagePromptEnabled, audio: false, embeddedContext: false },
          sessionCapabilities: {
            close: {},
            ...(history ? { list: {}, delete: {}, resume: {} } : {}),
          },
        },
        authMethods: [{
          id: 'env-deepseek-api-key',
          name: 'DeepSeek API key',
          description:
            'Set the ' + AUTH_ENV_KEY + ' environment variable (or configure the key in the ' +
            'dsh web Models settings / ~/.dsh/.credentials.yaml) and restart the agent.',
        }],
      }
    },

    async authenticate(_params: AuthenticateRequest): Promise<void> {
      if (process.env[AUTH_ENV_KEY]?.trim()) return
      const homeKey = process.env.DSH_HOME ?? resolveDshHome()
      try {
        const credentials = await readFile(join(homeKey, '.credentials.yaml'), 'utf8')
        if (credentials.includes('apiKey') || credentials.includes('deepseek')) return
      } catch {
        /* missing credentials document — fall through to authRequired */
      }
      throw RequestError.authRequired(
        undefined,
        'no API key is configured: set ' + AUTH_ENV_KEY + ' in the agent environment, or add a ' +
          'DeepSeek API key through the dsh web Models settings (' + join(homeKey, '.credentials.yaml') + ') and restart.',
      )
    },

    async newSession(params: NewSessionRequest): Promise<NewSessionResponse> {
      assertOpen()
      validateWorkspaceParams(params)
      const sessionId = brandSessionId(randomUUID())
      let spawned: Awaited<ReturnType<typeof spawnAgent>>
      try {
        spawned = await spawnAgent(
          ({ agentOptions, setup, presetId }) => agents.create({
            sessionId,
            meta: { cwd: params.cwd, ...(presetId !== undefined ? { agentPreset: presetId } : {}) },
            agentOptions,
            setup,
          }),
          { strict: true, what: 'session/new' },
        )
      } catch (error: unknown) {
        // Deployment-preset join: an absent roster keeps the global-layer
        // session; a default no root supplies (DSH_ACP_PRESET typo) is a
        // config error surfaced as invalidParams, never a silent partial
        // session.
        if (error instanceof PresetDefaultError) throw invalidParams(error.message)
        // The mid-spawn close guard already produced its wire error.
        if (error instanceof RequestError) throw error
        // Agent creation failures are internal (composition/route issues).
        throw internalError(`session creation failed: ${errorChain(error)}`)
      }
      const record = makeRecord(sessionId, params.cwd, spawned.handle, spawned.selection, { agentPreset: spawned.presetId })
      const configOptions = await registerRecord(record)
      await snapshotMounts(record)
      return { sessionId, configOptions }
    },

    async listSessions(params: ListSessionsRequest): Promise<ListSessionsResponse> {
      assertOpen()
      if (query === undefined) throw invalidParams('session history is not available on this connection')
      const records = await query.listSessions()
      const want = params.cwd !== undefined && params.cwd !== null ? params.cwd : undefined
      const sessions = []
      for (const record of records) {
        const cwd = record.header.cwd
        if (cwd === undefined || cwd.length === 0) continue
        if (want !== undefined && cwd !== want) continue
        const id = record.header.id
        const [title, updatedAt] = await Promise.all([titleFor(id), updatedAtFor(id)])
        sessions.push({
          sessionId: id,
          cwd,
          ...(title !== undefined ? { title } : {}),
          ...(updatedAt !== undefined ? { updatedAt } : {}),
        })
      }
      return { sessions }
    },

    /** Shared admission for load/resume over a persisted session. */
    async prepareHistoryResume(params: { sessionId: string; cwd: string; replay: boolean }) {
      assertOpen()
      const sessionId = brandSessionId(params.sessionId)
      const header = await persistedHeader(sessionId)
      if (header === undefined) throw invalidParams(`unknown session: ${params.sessionId}`)
      if (header.cwd !== params.cwd) {
        throw invalidParams(`session ${params.sessionId} belongs to ${header.cwd}, not ${params.cwd}`)
      }
      await releaseOnline(sessionId)
      // The durable log decides BOTH the composition to resume and whether the
      // preset is still switchable: dsh reconstructs the preset from the
      // `agentPreset` projection (creation header first, then selection
      // events), so a pre-turn switch must be replayed here — the header alone
      // keeps naming the ORIGINAL default.
      const snapshot = query !== undefined ? await query.readSession(sessionId) : undefined
      const presetId = lastAgentPreset(snapshot?.events ?? []) ?? header.agentPreset
      const { handle, selection, presetId: mountedPreset } = await resumeAgentFor(sessionId, presetId)
      const record = makeRecord(sessionId, params.cwd, handle, selection, {
        agentPreset: mountedPreset,
        turnStarted: hasStartedTurn(snapshot?.events ?? []),
      })
      // Restore the session's durable model selection (route + picked effort)
      // BEFORE config options are built: a reloaded session must advertise the
      // thought levels of the route it actually used, not silently revert to
      // the configured default (the pi-acp pattern — the session is the source
      // of truth). Sessions predating the snapshot keep their defaults.
      const restored = snapshot !== undefined ? lastModelSelection(snapshot.events) : undefined
      if (restored !== undefined) selection.current = restored
      const configOptions = await registerRecord(record, params.replay && snapshot !== undefined
        ? async () => {
            await replayHistory(record, snapshot.events)
          }
        : undefined)
      // Sync the persisted title once after replay: the firehose never
      // re-delivers historical title events, and without this the client
      // keeps a provisional title for the reloaded session.
      const restoredTitle = snapshot !== undefined ? lastSessionTitle(snapshot.events) : undefined
      if (restoredTitle !== undefined) deliverSessionTitle(record, restoredTitle)
      return { configOptions }
    },

    async loadSession(params: LoadSessionRequest) {
      validateWorkspaceParams(params)
      return this.prepareHistoryResume({ sessionId: params.sessionId, cwd: params.cwd, replay: true })
    },

    async resumeSession(params: ResumeSessionRequest) {
      validateWorkspaceParams(params)
      return this.prepareHistoryResume({ sessionId: params.sessionId, cwd: params.cwd, replay: false })
    },

    async deleteSession(params: DeleteSessionRequest) {
      assertOpen()
      const sessionId = brandSessionId(params.sessionId)
      const online = store.get(sessionId)
      if (online !== undefined) {
        removeRecord(store, online)
        await closeOne(online, { kind: 'user' }).catch(() => {})
      }
      await deletePersisted(sessionId)
      return {}
    },

    async closeSession(params: CloseSessionRequest): Promise<Record<string, never>> {
      assertOpen()
      const sessionId = brandSessionId(params.sessionId)
      const record = requireSession(sessionId)
      try {
        await closeOne(record, { kind: 'user' })
      } catch (error: unknown) {
        throw internalError(`session close failed: ${errorChain(error)}`)
      } finally {
        removeRecord(store, record)
      }
      return {}
    },

    async setSessionConfigOption(params: {
      sessionId: string
      configId: string
      value: unknown
    }): Promise<{ configOptions: WireConfigOptions }> {
      assertOpen()
      const record = requireSession(brandSessionId(params.sessionId))
      await applyConfigOption(record, params.configId, params.value)
      return { configOptions: await refreshConfigOptions(record) }
    },

    async prompt(params: PromptRequest): Promise<PromptResponse> {
      assertOpen()
      const record = requireSession(brandSessionId(params.sessionId))
      if (record.inflight !== undefined) throw invalidParams('a prompt is already in flight for this session')
      guardCurrentEffort(record)
      const inflight = createInflight()
      record.inflight = inflight
      // Picked `/skill:<name>` entries arrive as literal prompt text; rewrite
      // each text block's word-bounded `skill:<name>` tokens back to the bare
      // `/name` gesture dsh's tool-skill pre-step expands (its gesture regex
      // accepts only `/kebab-name`), so a skill picked from the Zed popup
      // loads exactly like the dsh Web "/" menu one.
      const prompt = params.prompt.map((block) =>
        block.type === 'text' ? { ...block, text: normalizeSkillSlashText(block.text) } : block,
      )
      let admissionFailed = false
      let admissionFailure: unknown
      try {
        if (agents.get(record.agent.id) !== record.agent) {
          throw internalError('prompt was not queued: the agent was disposed outside the bridge')
        }
        // Slash commands run on the command plane and never enter the model
        // history (design §6.6); an unknown or malformed slash falls back to
        // an ordinary prompt below.
        const line = slashLine(prompt)
        if (line !== undefined) {
          if (commands === undefined) throw internalError('no command runtime is mounted')
          const exec = await commands.execute(
            record.agent,
            line,
            encodedImages(prompt),
            inflight.admissionController.signal,
          )
          if (exec !== undefined) {
            inflight.commandExecuted = true
            if (exec.result.text !== undefined && exec.result.text.length > 0) {
              deliver(record, assistantTextChunk(exec.result.text))
            }
          }
        }
        if (inflight.commandExecuted !== true) {
          const images = scanPrompt(prompt, imagePromptEnabled)
          inflight.admissionController.signal.throwIfAborted()
          let imageRefs: readonly ImageAttachmentRef[] = []
          if (images.length > 0) {
            if (attachments === undefined) throw invalidParams('no attachment store is mounted')
            imageRefs = await persistImages(attachments, images, inflight.admissionController.signal)
          }
          inflight.admissionController.signal.throwIfAborted()
          if (agents.get(record.agent.id) !== record.agent) {
            throw internalError('prompt was not queued: the agent was disposed outside the bridge')
          }
          const content = contentForPrompt(prompt, imageRefs)
          const message = createUserMessage({
            content: content as unknown as ContentBlock[],
            source: { kind: 'user' },
          })
          inflight.messageId = message.id
          inflight.messageQueued = true
          try {
            record.agent.followup(message)
          } catch (error: unknown) {
            inflight.messageQueued = false
            throw error
          }
        }
      } catch (error: unknown) {
        admissionFailed = true
        admissionFailure = error
      } finally {
        inflight.finishAdmission()
      }
      if (inflight.cancelRequested) {
        settleAfterQuiescence(record, inflight)
        return { stopReason: await inflight.promise }
      }
      if (admissionFailed) {
        record.inflight = undefined
        if (admissionFailure instanceof AcpContentError) {
          throw admissionFailure.kind === 'invalid' ? invalidParams(admissionFailure.message) : internalError(admissionFailure.message)
        }
        if (admissionFailure instanceof RequestError) throw admissionFailure
        const detail = (admissionFailure as Error | undefined)?.message ?? String(admissionFailure)
        throw internalError(`prompt was not queued: ${detail}`)
      }
      settleAfterQuiescence(record, inflight)
      return { stopReason: await inflight.promise }
    },

    cancel(params: CancelNotification): Promise<void> {
      const record = store.get(brandSessionId(params.sessionId))
      if (record === undefined) return Promise.resolve()
      const inflight = record.inflight
      if (inflight !== undefined) {
        inflight.cancelRequested = true
        inflight.admissionController.abort(new Error('ACP prompt cancelled'))
        settleAfterQuiescence(record, inflight)
      }
      if (inflight === undefined || inflight.messageQueued) record.agent.cancel({ kind: 'user' })
      return Promise.resolve()
    },
  }

  // Track started request handlers so quiescence can drain them (see quiesce).
  const trackedImplementation = new Proxy(implementation, {
    get(target, prop, receiver) {
      const value = Reflect.get(target, prop, receiver)
      if (typeof value !== 'function') return value
      return (...args: unknown[]) => {
        const result = value.apply(target, args as never[])
        if (result instanceof Promise) {
          activeRequests.add(result)
          void result.catch(() => undefined).finally(() => { activeRequests.delete(result) })
        }
        return result
      }
    },
  }) as typeof implementation

  // The SDK's close path aborts every outbound mailbox the moment its input
  // ends, so a reply to a request still in flight when the client closes
  // stdin would be dropped (reproduced: handler completes, session persists,
  // wire frame lost). The bridge therefore never forwards stdin end while
  // work may still be incoming or in flight: chunks flow through a gate, and
  // the gate's end is withheld until a full quiet window has passed with no
  // request in flight. Only then can the SDK's close be harmless — every
  // reply is already on the wire (design.zh.md §6.1 immediate-EOF contract).
  const STDIN_QUIET_MS = 150
  const inbound = new TransformStream<Uint8Array, Uint8Array>()
  const inboundWriter = inbound.writable.getWriter()
  let stdinEnded = false
  let quietTimer: ReturnType<typeof setTimeout> | undefined
  const tryQuietClose = (): void => {
    if (!stdinEnded || quietTimer !== undefined) return
    quietTimer = setTimeout(() => {
      quietTimer = undefined
      if (!stdinEnded) return
      if (activeRequests.size > 0) {
        // Requests dispatched inside the window: hold until they settle, then
        // re-arm — close only after a fully quiet window.
        void Promise.allSettled([...activeRequests]).then(tryQuietClose)
        return
      }
      void inboundWriter.close().catch(() => undefined)
    }, STDIN_QUIET_MS)
  }
  void (async () => {
    for await (const chunk of process.stdin) {
      await inboundWriter.write(chunk)
    }
    stdinEnded = true
    tryQuietClose()
  })().catch((error: unknown) => {
    logger.warn(`dsh-acp-v1: stdin read failed: ${errorChain(error)}`)
  })
  conn = new AgentSideConnection(
    (connection) => {
      conn = connection
      return trackedImplementation
    },
    ndJsonStream(
      Writable.toWeb(process.stdout) as WritableStream<Uint8Array>,
      inbound.readable,
    ),
  )

  let quiescing: Promise<void> | undefined
  const quiesce = (): Promise<void> => {
    if (quiescing !== undefined) return quiescing
    closed = true
    for (const record of store.values()) {
      const inflight = record.inflight
      if (inflight !== undefined) {
        inflight.cancelRequested = true
        inflight.admissionController.abort(new Error('ACP bridge disposed'))
        settleAfterQuiescence(record, inflight)
      }
      record.agent.cancel({ kind: 'disposed' })
    }
    quiescing = (async () => {
      // A client that closed stdin right after its requests still gets every
      // reply: drain the started handlers (prompts settle 'cancelled', other
      // handlers finish normally) before any record teardown begins.
      await Promise.allSettled([...activeRequests])
      const records = [...store.values()]
      const failures: unknown[] = []
      for (const record of records) {
        try {
          await closeOne(record, { kind: 'disposed' })
        } catch (error: unknown) {
          failures.push(error)
        }
        removeRecord(store, record)
      }
      if (failures.length > 0) {
        const detail = failures.map((failure) => errorChain(failure)).join('; ')
        throw new AggregateError(failures, `dsh-acp-v1: teardown failed for ${failures.length} session(s): ${detail}`)
      }
    })()
    return quiescing
  }

  // Connection end == serving session over: the gate above forwards stdin end
  // only after a quiet drain, so by the time the SDK closes, every reply is
  // already on the wire. Under the dsh CLI profile boot the composition owns
  // process lifetime (the launcher wires SIGINT/SIGTERM but nothing exits
  // when the client closes stdin), so once the quiescent teardown has run,
  // request a bounded tree shutdown through the launcher-published
  // `ctx.appExit` (immediate-EOF smoke: exit 0).
  const appExit = ctx.get('appExit') as ((code?: number) => void) | undefined
  let exitStarted = false
  void conn.closed.catch((error: unknown) => {
    logger.warn(`dsh-acp-v1: connection closed with an error: ${String(error)}`)
  }).then(async () => {
    await quiesce()
    if (appExit !== undefined && !exitStarted) {
      exitStarted = true
      appExit(0)
    }
  }).catch((error: unknown) => {
    logger.warn(`dsh-acp-v1: connection-close teardown failed: ${errorChain(error)}`)
  })
  ctx.effect(() => quiesce, 'dsh-acp-v1.connection')

  // ── elicitation: dsh ask_user_question <-> ACP form ───────────────────────
  // askViaForm lives in elicitation.ts (P0-3b: unit-testable five exits);
  // this listener only claims bridge-owned sessions and delegates the rest.
  if (userQuestions !== undefined) {
    const elicitation: ElicitationBridge = {
      store,
      askCall,
      getConn: () => conn,
      formsEnabled: elicitationFormsEnabled,
    }
    // Waterfall generation: claim our own sessions' questions and delegate
    // everything else (`next()`), so a foreign asker still reaches any local
    // answerer composed elsewhere in the host.
    ctx.on('user-questions/request' as never, ((
      request: AskUserQuestionRequest,
      next: () => Promise<AskUserQuestionAnswer>,
    ) => {
      const agent = request.agent
      const record = agent !== undefined ? store.get(agent.session.id) : undefined
      if (record === undefined) return next()
      return askViaForm(request, elicitation)
    }) as never)
  }
}
