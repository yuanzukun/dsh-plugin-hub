/**
 * ocr.test.mjs — 数字识别这一路（Python sidecar 协议 + 简报口径）。
 *
 * 这条测试**依赖真实的 winrt + Windows OCR**（这台机器上装了）：它验的是
 * 「帧从 Node 写进 stdin、JSON 一行回来、数字对得上」这条链，而不是某个 mock。
 * 没有 winrt 的机器上整组跳过 —— 那是环境缺依赖，不是代码坏了
 * （`status` 会写「OCR 不可用」，别把跳过当通过）。
 *
 * `timeoutMs: 10_000`：并发跑全量时 Python 冷启动 + sidecar 初始化偶尔超过生产默认的
 * 3 秒；这里验的是识别链，不是延迟，所以给测试单独放宽（运行时仍用 3 秒）。
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import { bloodbarBrief, pushTrack } from '../src/bloodbar.js';
import { resolveOcrPython, startOcr } from '../src/ocr.js';

const HERE = dirname(fileURLToPath(import.meta.url));
const FIXTURE = join(HERE, 'fixtures', 'bloodbar-2798x17638.bgra');
const FIXTURE_SHARP = join(HERE, 'fixtures', 'bloodbar-4177x16100.bgra');
const W = 421;
const H = 16;

const probe = resolveOcrPython();
const skip = probe.ok ? false : `没有能 import winrt 的 Python（${probe.reason}）`;

test('ocr：sidecar 真跑一帧，认出血条数字', { skip }, async () => {
  const frame = readFileSync(FIXTURE);
  assert.equal(frame.length, W * H * 4, 'fixture 必须是 421×16 的 BGRA');

  const o = startOcr({ w: W, h: H, python: probe.python, timeoutMs: 10_000 });
  try {
    const out = await o.recognize(frame);
    assert.equal(out.cur, 2798);
    assert.equal(out.max, 17638);
    assert.match(out.text, /2798/);
    assert.ok(out.ms >= 0);
  } finally {
    o.stop();
    await o.done.catch(() => {});
  }
});

test('ocr：plain 认不出的帧，靠锐化那一路救回来（36% 那帧）', { skip }, async () => {
  const frame = readFileSync(FIXTURE_SHARP);
  assert.equal(frame.length, W * H * 4, 'fixture 必须是 421×16 的 BGRA');

  const o = startOcr({ w: W, h: H, python: probe.python, timeoutMs: 10_000 });
  try {
    const out = await o.recognize(frame);
    // 这帧原图极性读不出，是先试 sharp 才认出来的——数字对不上就说明重试链断了
    assert.equal(out.cur, 4177);
    assert.equal(out.max, 16100);
    assert.equal(out.pre, 'sharp', '这帧应该由 sharp 那一路认出（pre 会告诉你是哪路）');
  } finally {
    o.stop();
    await o.done.catch(() => {});
  }
});

test('ocr：帧不够长直接拒，不许拿半帧去认', { skip }, async () => {
  const o = startOcr({ w: W, h: H, python: probe.python });
  try {
    await assert.rejects(() => o.recognize(Buffer.alloc(100)), /帧太小/);
  } finally {
    o.stop();
    await o.done.catch(() => {});
  }
});

test('ocr 数字进简报：比例是主读数，数字只在括号里附注', () => {
  const now = 1_000_000;
  const reading = { ok: true, ratio: 0.15, at: now, cur: 2798, max: 17638 };
  const brief = bloodbarBrief({ track: pushTrack([], reading), threshold: 0.3, now });
  assert.match(brief.text, /条上数字 2798\/17638/);
  assert.equal(brief.ratio, 0.15, '主读数必须是比例（别的游戏不一定印数字）');
});
