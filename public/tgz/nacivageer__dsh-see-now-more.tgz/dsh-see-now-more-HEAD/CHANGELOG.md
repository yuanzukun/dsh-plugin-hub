# Changelog

本文件从 `0.0.4` 起记录；更早的版本见 GitHub Releases。

## [0.1.1-more.35] - 2026-11-27

### Changed — 浮窗发图的源文件门槛 4MB → 32MB；回顾窗也能引用选中文字

- `src/index.js` 的 `RELAY_IMAGE_BYTES`：4MB → 32MB。原来的 4MB 是内联 base64 时代的保守值；
  现在走 `attachments.saveImage()`，DSH 的附件库自己会把图归一化到 2048² 像素 / ≤4MB
  （源图准入 50MB），插件不该抢在它前面把手机照片挡回一行路径。
- `examples/floating-chat/window.py`：回顾窗（回顾 / 收藏页）的气泡右键多了「引用选中文字」；
  点完会**关掉回顾窗、把主窗带到前面**、焦点进输入框 —— 回顾窗是独立 Toplevel 且同样
  topmost，不这样做 chip 会被它盖住。代价是回顾页的滚动位置会丢。
- 单测：`test/relay-image.test.mjs` 新增「>4MB 也交给 saveImage」；`scripts/check-quote.py`
  新增「回顾窗引用 → 关窗 + 主窗前置 + 焦点」。

## [0.1.1-more.34] - 2026-11-26

### Fixed — steer 时的插话说明迟到；纯图消息在主窗无文字可搜

- `src/index.js`：relay 的说明那条（「先说话，再干活」）改成**只在 `steer`（原话插进
  正在跑的一轮）时投**，`followup`（从空闲起一轮）不投 —— 说明原来跟着原话一起发，
  第二条会被宿主排到空闲才 splice，用户几分钟后突然收到一张旧卡片（23:04、23:29、23:39
  各一次）。`.31` 起正文会镜像进浮窗，从空闲起的那一轮不需要这条说明。
- `src/interject.js` 的 `relaySendText()`：纯图（拆完 markdown 没正文）改回补一行 `[图片]` ——
  `.33` 留空导致这条消息在主窗里没有文字，搜索 / 引用都抓不到。
- `src/timer.js` 的 `followupMessage()`：内容块顺序改成**图片在前、文字在后**（和浮窗原文
  的「图片 markdown 然后正文」一致），纯图补的 `[图片]` 就落在图片下面当图注。
- 单测：`relaySendText` 4 条按新口径；新增「图片排在文字前面」1 条。

## [0.1.1-more.33] - 2026-11-26

### Fixed — 浮窗纯图消息在主窗多出一行 `[图片]`；插话提示里「普通回复看不到」已过时

- `src/interject.js` 新增 `relaySendText()`：浮窗发**纯图**（拆完 markdown 没有正文）时，
  用户那条消息的正文留空 —— 主窗里只显示图，不再多一行 `[图片]` 排在图片上面。
  说明那条（`relayInstruction`）仍用 `[图片]` 占位，否则会写成「引用了一段内容，见上一条」。
- `INSTRUCTION`（插话提示）改写：正文从 `.31` 起也会镜像进浮窗，原句「普通回复悬浮窗里
  一个字都看不到」已经不成立；`say` 从「下一次调用必须带」放宽成「想让她听见就带」。
- `say` 的 README 口径同步：它是唯一**会被念**的通道，普通回复也会进窗；tool description
  没动（模型侧体积预算 7500 字符只剩 24 字余量，这句的「此刻」仍成立，改动放 instruction 里）。
- 单测：`relaySendText` 4 条；插话提示的逐字用例按新文案更新。

## [0.1.1-more.32] - 2026-11-26

### Added — 主窗发来的图片也进浮窗

- `src/mirror.js` 的 `mirrorTextOf()` 认得用户消息里的 `image` 块：按
  `attachment.attachmentId = "sha256:<hex>"` 找到附件对象
  `~/.dsh/attachments/v1/objects/<hex 前两位>/<hex>`，把 `![图片](<绝对路径>)` 写进
  `chat.jsonl` —— 浮窗本来就按绝对路径加载本地图（不看扩展名），所以**直接引用、不复制**。
  以前带文字的图文消息只同步了文字，浮窗里看不出这条发过图。
- 图文混排按原块顺序拼；纯图片就是一张图；对象被清理 / 不是 sha256 存储 → 退回一行
  `[图片]`（`.31` 的行为）。
- 新增 `imageMarkdownOf()` 与单测；`node --test` 全绿。

## [0.1.1-more.31] - 2026-11-26

### Added — 浮窗补齐会话里的模型正文（关窗也同步 + 回填）

- `src/mirror.js` 新增 `onAssistant()`：绑定会话的 `assistant/message` 正文（只取
  `type:"text"` 的块，3000 字截断）也写进 `~/.dsh/see-now/chat.jsonl`，条目带
  `origin:"dsh"` / `mid:"<sid>:<seq>"` / 会话事件时间。**窗关着也写** —— 以前
  `mirrorAssistantText` 在窗没开时直接返回，于是关窗一段再打开，回看只有用户半边。
  朗读仍只在窗开着时（关窗时排进语音队列，只会在下次开窗补念一堆旧话）。
- 回填加一条**独立游标** `assistantThroughSeq`（`session-mirror.json`）：用户游标被
  后面一条 user 推走时，「正文在它之前、当时窗没开」的那批仍补得到。30 天 / 最近
  500 条，跳 fork 继承前缀。
- 旧条目没有 `mid`：回填前按「同文 ≤10 秒」与「已被 `say` 覆盖、占比 ≥30%、≤120 秒」
  对 `chat.jsonl` 里已有的 assistant 条目去重，`say` 写过的句子不会再来第二条。
- `src/chat.js` 的 `pendingStartupEntries()`：`origin:"dsh"` 的 assistant / meta 跟镜像
  user 一样「跳过但不停」—— 会话镜像不是「浮窗这句话有人回了」的证据，否则回填的正文
  会把一条真没投出去的浮窗消息挡在 break 后面。
- 开关语义：`"mirror": {"users": false}` 现在停的是「会话内容同步」（用户消息 + 模型
  正文的实时 / 回填），窗里 `say` 的气泡不受影响；`"backfill": false` 只停回填。

## [0.1.1-more.30] - 2026-11-26

### Fixed — 浮窗发图把会话打成「DeepSeek Messages transport failed」

- `src/index.js` 的 `loadRelayImages()` 原来把浮窗正文里的本地图片读成 base64，拼成
  `{type:'image', data, mimeType}` 投进会话。**这不是 DSH 认的形状**（合法形状只有
  `{type:'image', attachment:{attachmentId,…}}`），而 `agent.followup()` 这条路上没有准入
  校验，坏块原样进了持久历史：DeepSeek adapter 准备请求时读 `block.attachment.width` 抛
  TypeError，被最外层兜底包成 `TRANSPORT` —— 界面上是「DeepSeek Messages transport
  failed」，重试 5 次全废，**并且之后每一轮连纯文本都失败**，会话被永久锁死
  （2026-11-26 实炸 `session-cb8c0785`）。
- `loadRelayImages()` 改成 async：逐张 `attachments.saveImage()` 换成附件引用再投；没有
  附件服务 / 读不了 / 超 4MB / 格式不认 / 超 4 张一律退回原 markdown（路径留在正文里，
  模型仍可沿路径自己读）。
- `src/timer.js` 的 `followupMessage()` 只接 `{attachment}`；遇到内联 `{data}` 直接抛错，
  让这一条投递失败（会出现在 `relay.log` 和窗口的「发送失败」上），不再静默把坏块塞进会话。
- `test/relay-image.test.mjs`（新）：5 条守门测试，其中一条专测「内联 base64 形状必须投不进去」。

## [0.1.1-more.29] - 2026-11-26

### Added — 浮窗同步主窗用户消息（功能 1）

- `src/mirror.js`（新）：绑定会话里用户亲手打的 `user/message` 实时写进 `~/.dsh/see-now/chat.jsonl`
  （条目带 `origin:"dsh"` + `mid:"<sid>:<seq>"` + 会话事件时间），并在插件启动 3 秒后 /
  换绑时回填最近 500 条 / 30 天。水位 `session-mirror.json` 只在写盘成功后推进；启动扫
  `chat.jsonl` 尾部 4000 行的 `mid`，补「写成功但水位没落盘」的崩溃窗口；跳过 fork 继承前缀。
- `src/chat.js`：`appendChat` 支持 `{sid, at, mid, origin}`；新增 `isFloatUserEntry()`
  （`role==="user" && origin!=="dsh"`）与 `pendingStartupEntries()`。
- 四个消费点改用 `isFloatUserEntry()`：启动补投、relay 增量、常驻循环、阻塞 watch ——
  镜像条目不会被重投，也不会让 watch 误判「用户插话」。
- 窗口侧：`ChatFeed` 去重键加 `mid`、按 `at` 稳定排序、截断保留最近 200 条；
  `_history_entries` 先按 `at` 排再取 500（回填的旧条目在文件尾，按写入顺序截会挑中最旧的）。
- 开关：`~/.dsh/see-now.json` 的 `"mirror": {"users": true, "backfill": true}`，缺省都开；
  `users:false` 一键停实时 + 回填。

### Added — 气泡选区「引用选中文字」（功能 2）

- 主聊天窗气泡有选区时，右键菜单多「引用选中文字」：输入区出现引号 chip（开 / 闭引号 +
  单行预览 + ×），可点 × 或光标在正文开头按退格 / Delete 删除；没有正文也能只发引用。
- 发送按 DSH `formatQuoteText` 编码（每行 `> `）+ 空行 + 正文；DSH 主窗渲染成引用，
  relay 的 200 字截断不作用于引用块，模型看到完整引用。单次引用上限 4000 字。
- 浮窗自己的气泡认同一套 `>` 行（只对 user 气泡）：左侧 2px 竖条 + `#a9c4e0` 文字；
  摘要态的 2 行预算把引用行也算进去；选中复制得到去掉 `>` 的原文，「复制全文」仍是原始 Markdown。
- `examples/floating-chat/quote_text.py`（新，纯函数）+ `scripts/check-quote.py` 无 GUI harness。
- 已知边界：v1 只有一条引用、只在主聊天窗（回顾窗不提供）；引用里的 `>` 会变成 `> > …`。

### Changed — 浮窗消息在主窗显示成用户气泡

- relay 原来把用户原话和「先说话再干活」说明包成一条 `source.kind:"see-now"` 消息，DSH
  客户端把它渲染成「收到执行请求」触发卡：主窗里看不到用户自己的气泡，引用也不按 Markdown
  渲染。现在拆两条：原话走 `source.kind:"user"`（主窗用户气泡、引用块正常），说明单独走
  `see-now`（仍是触发卡）。
- 新增 `~/.dsh/see-now/relay-user-ids.json`：relay 代投的消息 id 落盘（最近 200 条），
  mirror 的 live / 回填都跳过这些事件，避免浮窗刚发的话被镜像回灌成第二条。
- 浮窗里的本地图片（`![图片](路径)`）转成主窗的图片内容块（单张 ≤4MB、最多 4 张；
  超限 / 读不到保留原 markdown）；网络图不搬。

### Fixed

- `src/interject.js`：`interjectNote()` 在 `at=null` 时印出 `@08:00:00`（`Number(null)=0`）；
  带引用的插话现在把引用块原样放最前、说明只放引用之后的正文。

### 验证

- `node --test`：387 项 / 384 过 / 0 失败 / 3 skip（新增 `session-mirror` 14 条、
  `quote-text` 2 条、`interject-quote` 5 条）。
- `python -m py_compile` 三文件 OK；`python scripts/check-quote.py`、
  `python scripts/check-feed-order.py` 均 exit 0。
- 待补：装 profile 后重启 DSH 的 A/B/C 实机验收。

## [0.1.1-more.28] - 2026-11-26

### Fixed — 麦克风：回移上游 v0.2.9 的三处修复（issue #66）

- `examples/floating-chat/mic.py`：模型目录不再写死 `D:/asr-local/models-sherpa`；按
  `--models-dir` → `DSH_ASR_MODELS` → `<DSH_HOME>/asr-models/sherpa` → 旧开发机路径找。
  **显式目录缺文件直接退出 2**，报出缺哪几个，不再静默回退；`--engine http` 只校验
  `silero_vad.onnx`。`main()` 改成 `return run(args)`，退出码不再被吞。
- `examples/floating-chat/window.py`：`_poll_chat` 不再每 250ms 清麦克风状态，改由
  `_on_mic_exit` 接管；子进程 stderr 用 `PIPE` 泵进内存（最后 20 行、跳过 `识别` 开头的
  转写行、不落盘）。异常退出时状态行显示 `麦没起来：…`（模型缺文件 / 缺依赖 / 设备打不开），
  用户主动停才清空。
- 本仓额外适配：`_mic_models_from_asr()` 从 `~/.dsh/asr.json` 的 `--vad` / `--punct`
  反推 mic 的 sherpa 目录，设给子进程的 `DSH_ASR_MODELS`。该文件的 `--models` 是 ASR
  服务的 SenseVoice 目录，直接指给 mic 会被新校验判成「模型不完整」。
- 文档：README / INSTALL 的模型目录与排查路径同步；不再生成 `mic.log`（转写内容不落盘）。

### 验证

- `node --test`：366 项 / 363 过 / 0 失败 / 3 skip。
- `python -m py_compile` 两文件 OK；ASR venv 跑 `mic.py --from-file 0.wav --dry-run`
  出字、exit 0；空 `--models-dir` exit 2；无 Tk 探针把状态跑到
  `麦没起来：挂了：Error querying device -1`（本机无输入端点）。
- **未验证**：真实麦克风成功路径（本机没有可用输入端点）；GUI 状态行的实际渲染。

## [0.1.1-more.27] - 2026-11-26

### Added — 「屏幕读取」总开关：用户侧唯一按得下的闸（档 B）

- `~/.dsh/see-now.json` 加 `enabled`（默认 `true`）。关掉后 `watch` / `start` / `peek` / `region`
  一律硬拒（`reason:"disabled-by-user"`），**连显式 `source` 也不放行** —— 它表达的是
  「我不许你看屏幕」，不是「这一轮不想看」。闸在 `runner.guardReason()` 的第一判，
  比 `hung-up` / `file-ended` 都早。
- 入口只有一个：悬浮窗 →「本插件设置」→「屏幕读取」→「关」。**模型没有任何 action
  能打开它**。关掉时停采集、**窗不关**（入口就在窗里，关了等于把人锁在门外）；
  设置卡写盘后 1.5 秒内生效，不用重启。
- `status` 第一行报「总开关：开 / 关」，第二行报「关窗后」那一档；工具描述补了一段：
  `disabled-by-user` 不是故障、重试没用、换参数也绕不过去、只有用户能开。
- `enabled` 写成字符串（`"false"`）会报一条 warning 并回默认 —— 字符串是真值，
  静默当开等于用户以为自己关了、其实一直开着。

### Added — 「关窗后」四档：`onWindowClose`

- `stop`（默认，= 现在这套行为：停画面 + 停听觉 + 挂断）/ `ears` 留耳 / `rise` 可抬头 /
  `ghost` 隐身。**未配置时与 `0.1.1-more.26` 完全一致**。
- 循环按档位分流（`loop.js` 的窗判定）：`ears` / `rise` 停画面、循环继续听；
  `rise` 在下一次叫醒时自己把窗开回来；`ghost` 画面和听觉都不停，
  也不再把「窗没了 = 挂断」当判据。
- `ears` / `ghost` 下 `watch` / `peek` **不再自己支窗**（`runner.setAutoOpenWindow()`）——
  「关掉又被弹回来」正是社区抱怨的那条。
- 设置卡新增「屏幕读取」（布尔）与「关窗后」（四档）两行，四档每行下面一行小字写实际功能
  （「收工 / 隐身」这种短名单看不出区别）；这两项点完就生效，其余仍是重启生效。
- 窗没开着时 `say` 会在工具结果末尾明确说「没有气泡可投、只有会话记录」，
  不再让模型以为用户看见了。

### 验证

- `node --test`：366 项 / 363 过 / 3 skip（新增 `test/screen-gate.test.mjs` 7 条）。
- 实机 1→9 按 `docs/tasks/see-now-screen-gate-handoff.md` 的验收表逐条走，发版前做完。

## [0.1.1-more.26] - 2026-11-25

### Fixed — 连点两下会开出两个窗（抄上游 #75 的「单飞」闸）

- `src/window.js`：`openWindow()` 拆成「闸 + `openWindowOnce()`」。pid 要 spawn 之后 700ms 才写
  （那时才敢确认它没自己退出），这 700ms 里谁来问都是"没窗"；而直接调开窗的有三条路 ——
  左上角入口的路由（`open-window.js`）、`watch` 的 `window show`（`index.js:1963`）、
  常驻循环的 `ensureWindow()`（它自己那把锁管不到前两条）。两处挤进这 700ms 就各 spawn 一个：
  用户看到两个窗，pid 文件只记得后一个，前一个成了再也收不掉的孤儿。
  现在在飞期间后到的调用**共享同一个 promise**（`force` 也不例外），结束后放开。
- 实测（临时 `DSH_HOME` + 一个只 sleep 的假窗口脚本）：并发两次，修前起 **2 个进程**、
  修后 **1 个**；`test/window-single-flight.test.mjs` 两条，把闸撤掉会红
  （报「并发开窗起了 2 个进程（单飞没生效）」）。

### Fixed — `chat.jsonl` 撞权限错误时，窗里这句话写不进去

- `examples/floating-chat/window.py`：`append_user` / `append_notice` 的写入口抽成
  `_append_chat_line()`。`PermissionError` 时不再直接失败，而是**整份读出 + 临时文件 +
  `os.replace()`** 换掉 —— 新文件的 ACL 由目录继承，坏 ACL 随旧 inode 一起没了；
  重写也失败才抛**原始**错误。失败时输入框照旧不清空，状态行补一句
  「文件被占用或权限不足；关掉多余的窗再试」（上游 #75 同款）。
- 验证：用假 `open` 精确打两条分支 —— append 被拒时重写成功（两行，最后一行是新的），
  连临时文件也拒时抛的是指向 `chat.jsonl` 的原始 `PermissionError`，不是 tmp 的路径。

## [0.1.1-more.25] - 2026-11-20

### Docs — DSH 升级后要重装的依赖清单

- README 在「适用范围」下补一节「DSH 升级后要重装的依赖」：必须 `tkinter` / `Pillow` / `mss` / `numpy`；
  可选 `windows-capture`、`winrt-runtime` + `winrt-Windows.Media.Ocr`、`pyaudiowpatch`、`edge-tts`、
  `dxcam`、`sounddevice`。写明「装进托管 runtime 的包会被升级带走」，以及用独立 Python +
  `~/.dsh/see-window.json` 的 `python` / `listenPython` 避开的方式。
- `INSTALL.md` 同步：升级后先 `--check`，缺了按表补；`ffmpeg` 是 DSH 自带二进制，不在这个名单里。

## [0.1.1-more.24] - 2026-11-20

### Added — `action:"crop"`：原生 1:1 截一块

- `see_now({action:"crop", region:"x,y,w,h"})` 直接返回主屏物理像素的 1:1 PNG 块：不缩放、不拼图、不落盘。
  给「读小字 / 认桌面图标 / 定位后再画圈」用——块内 `(u,v)` 的屏幕坐标 = `region` 左上角 + `(u,v)`。
- 实现走已有的 ffmpeg gdigrab 区域路径（`-offset_x / -offset_y / -video_size`），不新增 Python 依赖；
  一块按面积 220 万像素封顶（约 1.3k token），不改 `region.json`。
- 文档：README / `docs/机制.md` 补「原生截块」，并写明定位顺序：`watch` 整屏找区域 → `crop`
  只裁那块读细节 → 算坐标 → `pointer` 画圈。

## [0.1.1-more.23] - 2026-11-20

### Added — `action:"pointer"`：指一个坐标并等信号（默认关）

- 在屏幕坐标画一个圈/箭头 + 标签，然后停住等：`click`（左键按下，回报 `inside:true/false`）、
  `change`（那个坐标上换了窗口，`WindowFromPoint` 句柄变化）、`none`（画完就返回）。
  到点 `timeout`；Esc / 右键 `cancelled`（`ok:false, reason:"cancelled"`，与 `region` 的取消约定一致）。
- **默认关**：`~/.dsh/see-now.json` 的 `pointer.enabled`，开发期 `DSH_SEE_POINTER=1`；
  不进设置页（设置页在共用的 `window.py` 里）。
- 实现：`examples/floating-chat/pointer.py`（一次性进程、DPI aware、鼠标穿透、`GetAsyncKeyState` 轮询）
  + `src/pointer.js`（校验 / 额度 / 超时）+ `src/index.js` 分支 + 7 个 schema 参数
  + `scripts/pointer-smoke.mjs` 人工验收脚本。不碰 `window.py`、不用全局热键。
- 已知边界：只支持主屏；D3D 独占全屏下覆盖层不显示（先切窗口化）；`change` 看不到翻页 / 滚动；
  同一会话每分钟 ≤6 次。

## [0.1.1-more.22] - 2026-11-20

### Fixed — 【关联变更】的预填对齐 DSH 主窗当前会话

- 预填改为读 **DSH 主窗当前打开的会话**（Electron Local Storage 的 `dsh.sessions.current`，
  见 `examples/floating-chat/session_hint.py`），不再猜「绑定之后新建的会话」。2026-11-20
  实报：主窗开的是 `b5a28c79`，输入框却预填了一个从没用过的空会话 `4c36066b`。
- 兜底（DSH 没开 / 读不到）仍按「最新未绑定会话」，但**空会话不算**：一条 user 消息都没有的
  会话以前永远最新，现在跳过。顺带修了多帧日志只解第一帧的问题（要 `read_across_frames=True`
  才看得到消息）。
- 新增 `test/session-hint.test.mjs`（5 条）。

## [0.1.1-more.21] - 2026-11-20（未单独发版，随 .22 发布）

### Fixed — SAPI / DeepSeek 的语音标记不再失配

- **SAPI**：`〔…〕` / `【…】` 单独出现也会触发 SSML（以前触发条件只有 `**` / `‖` / `~`，
  重读静默失效）；情绪前缀 `【急】/【柔】` 换成语速并从正文剥掉，不会再被当成正文念出来。
  加粗不再参与朗读（进 SSML 前剥掉），去掉已不用的 `splitEmphasis` 导入。
- **DeepSeek**：送合成前剥掉 `〔…〕` / `【…】` / `‖` / `~`（接口不收标记）；`**加粗**`
  不再折成「，…，」停顿，只剥掉。
- 新增 `test/voice-markers.test.mjs`：把两个适配器的「文本 → 要念的东西」钉住。

### Docs

- README 与 `see_now` 的 schema 跟上 .19/.20：加粗只排版、重读是 `〔…〕` / `【…】`、
  `【急】` 实际是语速 `+15%`（音量只在有重读段时生效）、`notify` / `reaction` 的新文案、
  `options.emphasis` 的键位与默认值，以及三个适配器各支持到哪一层。
- edge 适配器的过期注释同步（「加粗怎么念」「edge-tts 不支持 SSML」都已不成立）。

## [0.1.1-more.20] - 2026-11-20

### Added — 重读走 edge 原生 SSML（`〔…〕`）

- **`〔…〕` 标重读段**：`要一直〔顺〕时针搅拌药水` 只重读「顺」。实现是劫持 `edge_tts` 的 SSML
  （`examples/edge-ssml-synth.py`），一次合成、同一个嗓声，没有接缝。
- 重读段的 `pitch` 由**合成时**渲染（`+15Hz`），不是事后移调——所以不会换嗓声
  （事后移调的谱包络差 0.044，实测听感就是换人）。
- **服务端限制**：最多 2 段 `<prosody>`，第 3 段起 `NoAudioReceived`；所以重读只能是一段连续文本。
- 加粗仍只管排版；`‖` 换气口、`~` 拖音、`【急】/【柔】` 情绪前缀不变。


- **`【…】` 与 `〔…〕` 等价**：模型更顺手写方括号，两种都认（情绪前缀 `【急】/【柔】` 仍在开头）。
- **通知文案带重读**：`notify` 念「我发了【新】消息」，长消息提示念「我发了很【长】的一条消息，你暂停看看吧」；
  气泡里**不显示**这些语音标记（`saidShown` 剥掉 `〔〕【】‖~`，朗读仍用原文）。

### Fixed

- **主动停采不再写成 `lastError`**：以前 `stop()` / 关窗 / 重启都会留一条假的「ffmpeg 退出（N 帧 / Ms）」，
  看着像故障。现在 `spawnFrames` 的 resolve 带 `stopped: true`，runner 只把"真的自己没了"记成错误。
- **SAPI 适配器标记与 edge 对齐**：`〔…〕` 表示重读段、`**加粗**` 只管排版；`‖` → `<break>`、`~` → `x-slow`。

## [0.1.1-more.19] - 2026-11-20

### Changed — 语音不再跟着加粗走（2026-11-20）

- **加粗只管排版，不进语音**：排版的重音和口语的重音标准不一样，按 `**` 切词会让接缝
  落在词中间（「我要一直｜顺时针｜搅拌」），重音还会落错字（「顺时针」的重音在「顺」）。
  现在一条 `say` **整句一次合成**，没有接缝，也没有「几个人接力读」。
- 语音只剩两个标记：`‖` 换气口（换逗号合成、内部静音压到 200ms）、`~` 拖音（整句放慢）；
  外加 `【急】` / `【柔】` 情绪前缀。
- 随之作废：`absorbMax` / `absorbTailMax` / `maxStrongChars` / `shortUtteranceMax` / `gapMs` /
  `rate` / `pitch` / `pauseMs` 这些按词切段的参数（代码里还在，但已不参与朗读）。

### Changed — 语音表达（edge-tts 的重读）

- **重读以速度对比为主**：非重点 `+10%`、加粗处 `+0%` + 音量 `+15%`，音高不动。依据：实测移调会改
  音色（谱包络余弦距离 `+2` 个半音 0.044），变速不会（`--rate=-12%` 0.0001、`atempo` 0.0012）；
  音量只抬一点点：抬多了「快慢刀」这类词会发飘。
- **接缝留出固定气口**：每段首尾各裁到 50ms，中间补到 `gapMs`（默认 200ms）。
  太小像抢话、太大像顿号。
- **分段合成不再凭空多停顿**：edge 每段自带 0.65–0.9s 尾静音，拼接前先裁掉
  （一句 10.94s → 7.32s 的那次实测就是它）。
- **表演提示不念**：`（发抖）` 这类 ≤8 字、不含数字/拉丁、且贴着句子边界的括号内容先剔掉再念；
  `（第二阶段）` 这种前后都是字的真内容不动。
- **`~` = 拖音**：去掉波浪号、把含它的那一段放慢（-22%，每多一个再 -8%，封顶 -45%）。
  没加粗没标点时整句会一起慢——慢容易被听成撒娇，这句是格 2026-11-20 的实听。
- **新增 `‖` 换气口**：先把 `‖` 换成逗号、一次合成，再把内部静音压到 200ms。
  切段合成会让后半句带句尾下落 + 新起音，听起来是「重新开口」而不是换气。
- **接缝不落在词中间**：加粗词前缀若 ≤ `absorbMax` 个字（默认 6），并入重点段——
  「眼睛闪**红光**」按「眼睛闪红光」整体念，接缝退到上一个顿号。
- 段首标点会挪到上一段末尾：`‖` 变成逗号后常常正好落在段首，edge 对「逗号开头」的文本
  合成不出音频（synth failed）。
- **重点只标短词**：加粗超过 `maxStrongChars`（默认 4）个汉字就按普通念；焦点落在具体名词上，
  不落在副词 / 祈使词上（「千万别站在**红圈**里」）。
- **不拆词**：`小**心**` 会把词切成两半、像断字，被否；加粗的最小单位是一个词。
- **词内不落缝**：加粗词前面 ≤ `absorbMax` 字、后面 ≤ `absorbTailMax` 字（虚词）并进重点段。
- **段间气口** `gapMs`（默认 200ms）替代原来的 20ms 重叠；太小像抢话、太大像顿号。
- **情绪前缀** `【急】` / `【柔】`：映射到非重点速度、气口与音量；带前缀时短句也切段。
- **短句不切段**：`shortUtteranceMax`（默认 8 字）；**句末重点段尾部硬切** 0ms，不留淡出。
- `pauseMs` 默认 `0`；`baseRate` / `breathMs` / `gapMs` / `absorbMax` / `absorbTailMax` / `maxStrongChars` / `shortUtteranceMax` / `baseVolume` 新增。
  全部可由 `~/.dsh/voice.json` 的 `options.emphasis` 覆盖，热读。

## [0.1.1-more.18] - 2026-11-20

### Added — 朗读范围（`speakScope`）

设置页新增「朗读范围」一档（收起一行、点开才摊；**热读**，改完不用重启）：

| 档 | 什么时候念 | 念什么 |
|---|---|---|
| `off`（默认） | —— | 只有 `say` 会念，普通回复只有字 |
| `notify` | 有新回复 | 一句「有新消息」 |
| `reaction` | **陪看循环在跑时** | 模型的即时反应；超过 200 字改念「我发了一条很长的消息，需要你暂停看看」 |
| `full` | 任何回复 | 整条念完（不截断）；只对免费声音生效 |

`full` 撞上付费音色（DeepSeek 官方）时**自动按 `reaction` 念**；切到 DeepSeek 时窗口也会把 `speakScope=full` 落成 `reaction`。

### Added — 语音表达

- 念之前先抹 Markdown：代码块 →「（这里有一段代码）」，行内 `code` 去反引号，链接只留文字，标题/列表/引用去前缀；
- **加粗会重读**：edge-tts 按段合成（加粗段 `--rate=-12%`）再拼接；SAPI 用 `SpeakSsml` + `<emphasis level="strong">`；DeepSeek 接口不收 SSML，用「，…，」停顿代替。
- status 与【检查当前选项是否生效】都会报「朗读范围」，并标注付费音色下的降级。

### Fixed

- 检查行的「声音」按 spec 精确比对，`key 来源：environment / stored` 只对 DeepSeek 档显示（不再被路径里的 `deepseek-harness` 误判）；
- 展开/收起设置页不再整页闪一下（就地重画）。

## [0.1.1-more.17] - 2026-11-19

### Added — 声音（TTS）

- Windows 两个内置适配器：`examples/voice-edge-tts.mjs`（微软在线语音，默认 `zh-CN-XiaoxiaoNeural`）、
  `examples/voice-sapi-win.mjs`（系统 `System.Speech`，离线）；加上 `examples/voice-deepseek-tts.mjs`
  （DeepSeek 官方 `/v1/tools/tts`，音色 `stella` / `tide`）。
- 设置页「声音」一档：收起时一行（当前值 + ▾），点开才摊出 `关 / edge-tts / DeepSeek（海星）/ SAPI（系统）`，
  选完自动收起。`voice.json` 是热读的，换档不用重启 DSH。
- 【检查当前选项是否生效】多报一行「声音」：`已接上 ✓` / `✗（原因）`，DeepSeek 档还会带
  `（key 来源：environment / stored）`。

### Fixed — 声音链路

- **请求前先同步凭据**：插件启动时与每次工具调用前读一次 DSH 凭据库，让设置里填的 key 立刻可见。
- **凭据优先级**：`环境变量里的 sk-` > `凭据库里的 sk-` > `凭据库里的 ID`（ID 一律忽略）。
  之前是无条件用库里的值覆盖 `process.env`，用户 `setx` 会被一个 36 位 Tracking ID 盖掉。
- **错误按 spec 归属**：切过档之后，`edge-tts` 不会再背上 `DeepSeek` 的 401。
- **检查动作自己重挂声音**：检查由定时器触发，以前会看到"旧适配器还挂着"，现在先切到位再比对。

### Fixed — 设置页

- 展开/收起改成**就地重画**（复用同一个 Toplevel），不再整页闪一下。
- 胶囊按钮展开态衬底统一为 `#17324f`。

### Notes

- **不要填 Tracking ID。** 开放平台 key 列表里 `Tracking ID` 与 `Key` 两列相邻、Key 打码，很容易复制错；
  Tracking ID 拿去请求会稳定 `401`。认准 `sk-` 前缀。
- DSH 托管的那把 key 只把 ID 交给插件、secret 不落盘，所以插件仍需要自己的一份：
  `setx DEEPSEEK_API_KEY`（改完重启 DSH）或 `voice.json` 的 `options.apiKey`（热读）。
- `node --test`：325 通过 / 0 失败 / 3 跳过。

## [0.1.1-more.16] - 2026-11-19

### Added — 悬浮窗设置页

- 「关联变更」展开行右侧新增【本插件设置】胶囊（再点一次收起）；卡片可按住标题栏拖动；右上角 ✕ 放大到 18 号。
- 当前感官模式四选一：视听都开 / 仅看 / 仅听（使用黑听抬头机制）/ 无。点一行**即时生效**：前两档起采集 + 常驻循环，仅听进黑听（listen 循环），无则全停。
- 游戏模式开关：临时把节奏切到 `game-economic`（切点门槛 80、最多 20 秒叫一次），关掉恢复原档；**不写 `defaultPace`**。开关时在窗里落一条居中系统气泡，并给模型留一条 note（不额外起一轮模型调用）。
- 【检查当前选项是否生效】胶囊：宿主逐项比对「配置值 vs 本次 apply 真正用上的值」，结果落成系统气泡；按钮点下先变暗，气泡到达再恢复。
- 展开态胶囊衬底改为 `#17324f`（与「收藏/历史」一致）。

### Changed — 感官模式四档可持久化

- `mode` 现在允许 `audio` / `none` 写进 `see-now.json`；`watch` 显式看画面时 `none→vision`、`audio→both`，只改内存、不写回配置。
- 设置页的「当前感官模式」读 `focus.json` 的真实状态，不再只显示配置值。

### Fixed

- 设置卡被主窗 800ms 顶置看门狗盖住（表现为「点开只闪一下就不见」）。
- 设置卡 canvas 与 Toplevel 双绑 `<Button-1>`，一次点击跑两遍、看起来只能在两档间跳。
- 游戏模式开关只写配置、界面不刷新：`FOCUS_LIVE` 是类属性，方法里裸引用触发 `NameError`，被 `except Exception: pass` 吞掉。
- `readJson` 不剥 BOM：PowerShell 5.1 写出的 `see-window.json` 会让整份配置被静默忽略。
- 开窗前只探 `tkinter`：缺 `mss` 时 `window.py` 弹出阻塞 MessageBox，被 700ms 存活判定当成「开窗成功」、不再换候选；现在四个包（tkinter/mss/numpy/PIL）都探，并且开窗后 20 秒内只认 pid（启动期没有心跳不算死）。
- 积分阈值跟着采集 fps 漂：8fps（按窗口抓）阈值低 1/3，同样素材多留 33% 的帧；现在钉在基准 12fps（`INTEGRAL_BASE_FPS`）。
- 设置页的「清晰度」以前宿主根本不读——`tuning` 不解析 `quality`、`watch` 默认写死 `null`；现在由 `defaultQuality` 生效。

### Notes

- `pyaudiowpatch` / `mss` 会随 DSH 托管 runtime 的整体替换丢失（2026-11-19 实测过一次）；建议把 `listenPython` 指到独立 venv，别依赖托管 runtime。
- `node --test`：328 项，325 通过 / 0 失败 / 3 跳过（OCR 等环境依赖）。

## [0.1.1-more.15] - 2026-11-17

### Changed — `see_now` 的契约压掉 49%（12,072 → 6,122 字符，≈3,909 → ≈2,251 token）

这份定义每一步都在宿主的工具前缀里重发。按 345 个会话 / 43,333 步的历史折算，
它的前缀成本约 ¥9.4；压到现在的体积后约 ¥5.4（`SPEC_BUDGET_CHARS` 挡住了回涨）。
（本版后来又加了"按窗口抓"的说明，所以比最早那稿 5,707 字符多了 400 多。）

- 删掉的是**论证性长文**：`pace` 的射击游戏帧数对照与 `cutAbs` 的 F1 数字、`region` 的
  逐档 token 细账、`quality` 的像素表 —— 改成定性判据，实测数据留在 docs/README。
- 删掉重复：`say` 的「一次 2–3 句」原本在 description 和参数里各写一遍；带日期的
  用户引用（「2026-11-06 用户说过」）删掉，规则本身保留。
- 保留的是**决策点**：`say` 是当时唯一被看见/听见的通道、阻塞调用就是停顿、读不清要升档
  而不是猜、台词是机转、看视频走 `bilibili`。
- 每个参数补上 `default`（宿主只当注释，但省掉「默认 300」这类句子），
  `action` / `pace` / `quality` / `source` 补上 `enum`。

### Fixed — 三个参数「用了但没声明」

- `read`（`action:"bloodbar"` 里读一次比例）在 `index.js` 里读、在 `action` 的散文里教模型传，
  却没在 `parameters` 里声明。宿主不拒未声明参数（编译出的参数对象没有
  `additionalProperties:false`），所以它靠散文活着 —— 描述一压缩就会断。现在正式声明。
- `keep`（等价 `task`）和 `t0`（等价 `since`）是没有任何文档的别名，直接删掉读取：
  唤醒文案里给的一直是 `since`，没有东西在传 `t0`。
- `lift` 在 description 和唤醒文案里都有，却不在 `action` 的取值列表里；`index.js`
  认不出动作时的提示也只列了 5 个值。现在 `ACTION_VALUES` 一个真源，三处共用。
  新增 `test/tool-spec.test.mjs`：声明必须覆盖 `index.js` 读到的每个参数、
  `action` 每个值都要有分支、`pace`/`quality` 的 enum 必须在 `PACES`/`SIZES` 里、
  以及体积上限。

### Fixed — 血条框好后还在说「P1a 还没接采集」

`action:"bloodbar"` 框完后那句提示是 P1a 时期的，P1b/P2 早就接上了采集。改成
「进仅监听后每秒读一次，读数在唤醒文案和 `status` 里；要当场读就传 `read:true`」。

### Docs — README 减重：机制细节搬进 docs

README 从 680 行 / 39.3 KB 收到 493 行 / 31.5 KB，同时补上原本没有的两节（字幕带、血条）。

- 搬走：变化分的两条判据与守卫细节、黑听抬头的落地方式与留底环、听声音的延迟拆解与调参、
  token 成本口径 → `docs/机制.md`；采集开销、变化分刻度、macOS 开发期记录 → `docs/实测.md`。
- 合并重复：三处平台状态（适用范围 / 平台表 / 已知限制）、两处 License 各合成一处；
  「维护状态与上游关系」从开头挪到文末，长论证指向 `docs/决策记录.md`。
- 参数表补齐 `lift` / `preset` / `task` / `mode` / `read` 这些此前只写在工具 schema 里的项。
- 顺带改正：`source` 原来写成 `{kind:"obs"}` 对象（工具只吃字符串），`quality` 的分辨率。

### Changed — 血条框选明说「框自己角色那条常驻血条」

以前框血条时只说「别把数字、图标、队友血条带进去」，没说是哪一条；而「血条」默认指的是
**自己角色**那条常驻 UI 的条 —— 敌人血条只在交战时出现、位置随目标跳，框它得到的是忽有忽无的读数，
`gone` 会频繁触发。现在三处一起改：

- 取框窗顶部提示按用途变：框血条时显示「框住你自己角色那条常驻血条（不是敌人血条）」，
  框整屏仍是原来的文案。机制是 `DSH_PICK_HINT`（`pick_region.py` 读环境变量，不传就走默认）。
- 框完的结果文案、`action:"bloodbar"` 的参数说明、README 与 `docs/机制.md` 都补上这条口径。

### Fixed — 示例里不再写死某个游戏的窗口标题

`window` 参数的说明原来举例 `"云·鸣潮"`，于是模型会把它当成"该填的值"、在对话里照着说 ——
换台机器、不玩这个游戏的人读到的是一条与己无关的默认。现在：

- 说明里先写清**默认按屏幕抓**，`window` 只在确实要按窗口抓时才传，填「窗口标题里的一段」；
- `py/wgc_capture.py` 的用法示例同样换成占位符。

默认值没变（`window` 缺省为 null = 抓屏幕），变的只是示例与措辞。

### Docs — 写清 WGC 什么时候该开（血条优先按窗口抓；字幕条不改引擎）

- 血条的 `window` 参数原来只说"被遮挡也读得到"，读起来像可选的高级选项；实际全屏游戏里
  悬浮窗一压上去，按屏幕抓（`gdigrab`）读到的就是压上去的那块。现在写明：**优先按窗口抓**，
  WGC 抓窗口自己的表面，遮挡和拖动都不影响；窗口最小化、D3D 独占全屏抓不到。
- 字幕带 `preset` 补一句它**不改采集引擎**：仍是屏幕像素，条带被压住就只看到遮挡物，
  要稳得把悬浮窗拖开。`watch` 目前没有窗口源（WGC 只接在血条那一路）。

### Added — `watch` 也能按窗口抓：`source:"window"` + `window:"<标题里的一段>"`

以前 WGC 只接在血条那一路，看画面只能抓屏幕 —— 窗口化打游戏、时不时切到聊天窗的话，
抓到的是挡住游戏的那个窗口。现在主路也能按窗口抓（口径按 2026-11-17 定的）：

- **窗口化 / 被遮挡** → 走 WGC，抓窗口自己的表面；
- **最小化** → **不抓**。窗口停止渲染，WGC 只能等到超时；sidecar 的 `--check` 先探
  `IsIconic`，探到就直接报「最小化了」，连会话都不建；
- **D3D 独占全屏** → **改抓屏幕**。WGC 在独占全屏下会话能建、一帧不来，判不出来，
  所以用首帧超时兜底：6 秒没帧就切回屏幕抓，结果里说明「已改抓屏幕」；
- **这一路管线跑 10fps**（屏幕源仍是 12）：整窗缩放（1922×1126 → 798×450）用 PIL 的 BOX，
  约 67ms/帧。三组实测：侧车单跑 12.0 帧/秒、插件里带血条同窗口 9.5、只留画面 10.9 ——
  取 12 会在插件里差 ~8%（`t = i/fps` 按名义值算）。`dtFrames` 与 fps 同值；
- sidecar 改成**定频发射**：WGC 回调只登记最新帧（限频拷贝），另起线程按截止时间每 `1/fps`
  秒输出一帧（没更新就重复上一帧，重复帧的变化分接近 0 = "没变"）；
- 缩放优先用 PIL（C 实现），没装 Pillow 才退回 numpy 的面积平均（正确但每帧 ~700ms）；
  4K 源（3840×2160，游戏全屏时的窗口尺寸）另走三条优化：`frombuffer` 代替 `frombytes`、
  大倍率先最近邻再 BOX、回调里直接缩放（不复制整帧）—— 吐帧从 ~5fps 提到 ~9.5fps；
- `region` 现在也能叠在窗口源上（仍按屏幕物理像素写，sidecar 按窗口当前 rect 换算）。

新增 `test/window-source.test.mjs`：入口造源（缺标题 / `"off"` / 未知 source / region 配对）、
探针那行 JSON 的解析（正常 / 最小化 / 坏行）、sidecar 命令行拼装（钩子只在要求时才带）。
真机验证走 `py/wgc_capture.py --check`，以及 `--stats` 下的两组数
（`emitted` = 侧车吐帧频率，`calls` = 窗口真实更新次数）—— 12fps 请求实测 72 帧/6 秒、起手 1.2 秒。

**回退路径已实测**：sidecar 的 `--drop-frames` 钩子（建会话、一帧不吐，等价于独占全屏的表现）
让「首帧超时 → 改抓屏幕」真跑了一遍 —— 11 秒后 `source.kind` 变成 `screen`、画面继续出帧，
结果里带「按窗口抓 6 秒没拿到帧（多半是 D3D 独占全屏），已自动改抓屏幕」。

### Changed — 术语：不再写「三人队」

「血条为什么只报告不叫醒」原来写的是「鸣潮三人队，切人/奶妈/免死……」—— 不玩这个游戏的人
既看不懂，也看不出为什么偏偏是三个人。改成「一个人操控多个角色、战斗中随时把另一个切到前台
作战」这种按机制描述的说法，README 与 `loop.js` 的注释一起改。

## [0.1.1-more.14] - 2026-11-17

### Fixed — 黑听唤醒文案把「300 字」说成「最近十分钟」

`lift/pool.js` 的 `summary()` 以前从最新一句往回装到 300 字，越靠近现在的越可能留下；
唤醒文案却写「最近十分钟的台词」—— 话密时 300 字只装得下最后几十秒，标签在谎报跨度
（下游评估 §1「可借鉴经验」第 3 条指的就是这个）。

- 摘要改成**按时间铺开取代表句**：全装得下就全留；装不下就在**有台词的那一段**上分箱，
  每箱取离中点最近的一句，首尾必留；预算仍是 300 字硬上限。
- 新增 `summaryDetail()`：一并给出 `from`/`to`（实际覆盖的第一句/最后一句）、
  `lines`（摘了几句）、`speech`（窗口内共几句）。
- 唤醒文案改成「最近十分钟的台词（实际覆盖 08:00:10–08:02:30，12 句，窗口内共 40 句）」；
  窗口里没有台词时明说「只有声音/环境音」，不再留一个空行。
- 单测补齐：首尾必在、实际跨度不等于窗口起点、只有声音没有台词、极短预算。

### Changed — `install-dev` 补安全三件套（下游评估 §2）

原来是「先 `rm` 整个目录、再 `cp`」：中途失败会留下半份插件；`--check` 也只有「装了/没装」，
版本不一致、目录残缺、别人的同名包全靠人眼分辨。

- **原子替换**：先 `cp` 到 `node_modules/dsh-see-now-more.staging-*`，再把旧目录改名为
  `.trash-*`、stage 改名为正式目录；失败把旧目录改回来、stage 清掉。中途失败不再毁掉
  正在跑的那份。
- **包外备份**：替换前把旧副本整体复制到 `$DSH_HOME/backups/dsh-see-now-more/<时间戳>/`
  （带 `meta.json`，保留最近 3 份）——`node_modules` 被清也不会带走它。
- **五态检测**（新 `scripts/install-state.mjs`，纯函数 + 单测）：`absent / foreign / broken /
  stale / current`；`--check` 直接打印状态，遇到 `foreign` 拒绝覆盖（exit 2），残留的
  staging/trash 会列出来，重跑安装时清掉。
- 已查：本机 profile 副本不是 pnpm store 硬链接（整目录 `cp`），「写穿 store」不适用。

验收：临时 profile 上跑过首次安装 / 二次安装（备份）/ stale / foreign 拒绝 / broken /
残留目录 / 重装修复；`install-state` 单测覆盖五态与 `expectedName`。

### Added — `state().capabilities`：六个固定状态 + status 一行（下游评估 §1 #4）

以前每个能力自己发明词：`enabled` / `ok` / `available` / `ready` / `why` / `stale` / 没在采……
单看某个字段要猜「现在能不能用、为什么」。现在归成一套：

- 新 `src/capability.js`：`ready / degraded / disabled / unavailable / pending / skipped`，
  按能力从已有字段映射（视觉 / 听觉 / 留底 / 血条 / 数字识别 / 悬浮窗）；纯函数 + 单测。
- `runner.status().capabilities` 每个能力只报一个词 + 一句原因。
- `see_now status` 加一行：
  `能力：视觉 ready · 听觉 ready · 留底 disabled · 血条 disabled · 数字 skipped · 窗 ready`；
  ready 不带原因，非 ready 的原因截到 40 字。
- 血条没框时数字识别是 `skipped` 而不是 `unavailable` —— 这不是「依赖坏了」，
  不该让人去重装一个本来没问题的包（2026-11-16 误报过一次）。
- **没在仅监听时**留底/血条是 `disabled`（而不是 `pending`「正在起」）：`liftStatus` /
  `bloodbarStatus` 补 `wanted`；数字识别随之 `skipped`。2026-11-17 重启后第一次 status
  踩到「明明没在听，却显示正在起」。

### Fixed — 窗口进程没了，status 还写「显示中」

用户手动关掉悬浮窗后，`windowLine()` 仍按 `hidden` 配置拼出「显示中」——`hidden` 只是
配置里的可见性，进程退出后没有意义。现在：
- 进程不在 → 「没在跑」；
- 进程在但心跳过期 → 「进程在但没在画（心跳过期）」；
- 只有进程活着 + 心跳新鲜，才可能出现「显示中」或「藏起来的」。

### Added — 10 分钟低清留底：跨 30 秒也能回看（下游评估 §1 #1）

30 秒缓冲是裸 RGB（800×450×3 ≈ 1 MB/帧），10 分钟 ≈ 309 MB，直接加大不现实。
另起一条**磁盘低清环**：

- 新 `src/lift/archive.js`：每 5 秒留一帧、长边 480 的 PNG（10 分钟约 120 帧；实测
  480×270 约 150 KB/帧，十几 MB，看画面复杂度），按天分目录，`frames.jsonl` 当目录；
  PNG 与索引都 **tmp → rename**，崩溃不会留下半个索引。
- 30 秒精确缓冲不动；`framePng(t0)` 在缓冲滑走后回退到低清环，返回
  `degraded:'archive-low-res'` —— 调用方必须知道这是低清，不许假装和精确帧一样。
- `see_now({action:"lift"})` 的文案会写「10 分钟低清留底，长边 480」；`status().lift.archive`
  给帧数 / 跨度 / 体积；开始看画面或收工时 `clear`，上一场的帧不冒充现在。
- 单测：5 秒节流、长边 480、PNG 尺寸、索引正序、回取容差、10 分钟淘汰、clear，以及 runner
  里「31 秒后缓冲淘汰 → 回退低清」的整条链路。

## [0.1.1-more.13] - 2026-11-17

### Added — 覆盖率账按分钟落盘；第一次能算出「漏抬 / 误抬」

以前只有内存里最近 2000 段（十几分钟）的账，DSH 一关就没了，复盘一局/一天时
「漏抬那一刻到底听没听见」答不上来。

- `src/coverage-ledger.js`：一段音频 → 按**本地分钟**拆行（跨分钟按时间比例拆两行），
  每行是增量 `{day, minute, sentSec, speechSec, textSec, emptySegs, segs}`，追加到
  `~/.dsh/see-now/coverage/<YYYY-MM-DD>.jsonl`；同一分钟可以有多行，读的人求和。
  **增量而不是累计快照**：重启/重试/崩溃都幂等，不用回读旧账。
- `listen.js` 在 `covEntries.push` 处顺手落盘（**没出字的段也写**，那才是「像说话没字」的原料）；
  写失败只记一次日志、绝不抛 —— 账坏了不能让听停掉。
- `scripts/coverage.mjs --ledger [--minutes N] [--json]`：每 5 分钟一段 + 全天合计，
  并读 `lift/<日期>/log.jsonl` 对齐：同一分钟「有字却没抬」= 漏抬候选，
  「抬了但那分钟没出字」= 误抬候选；台账里没有的分钟（比如台账刚上线）单列、不判误抬。
- 归属分钟用**这段音频的开始时刻**（不是转写完的时刻）：转写晚约 1 秒，按完成时刻分桶
  会把 10:00:00 说的话记进 10:00:01，跨分钟时与 lift 的 `wall` 错开。
- **`speechSec: 0` 与「没回传」分开**（2026-11-17 重启后第一次真跑踩到）：服务端 VAD 判
  「这段没人说话」会回 `duration: 0`；以前 `httpTranscriber` 把它折成 `null`，`listen.js`
  再拿段长兜底 —— 纯 BGM 的 6 秒段于是被记成「语音 6 秒、像说话没字」，status 的覆盖率
  被刷成 0%（实测 60 秒 / 10 段全是音乐）。现在 0 原样保留：不进覆盖率分母、不算
  「像说话没字」；只有字段缺失（宿主转写器那种）才退回段长。`--ledger` 在「有段但语音 0 秒」
  时会明说「VAD 判所有段都没人说话」，不让人误读成采集坏了。

验收：新增 `test/coverage-ledger.test.mjs`（分分钟/跨分钟/落盘读取/坏行/写失败/对齐/
`createListener().drain()` 真跑一遍），全量测试通过。落盘要 `node scripts/install-dev.mjs`
＋重启 DSH 之后才开始写。

## [0.1.1-more.12] - 2026-11-16

### Fixed — 标题栏那颗点跟下面那行字不同色（用户实报）

现象：左上角的点还是**橙色**（仅开启视觉），分割线下面那行已经写着灰色「未启用感官聚焦」。
两张状态都出自同一个 `_focus_info()`，所以这纯是**刷新时机**的问题。

根因：`_draw_focus_line()` 里有一句 `self._focus_label = label`，而它会从**两个地方**被调 ——
`_poll_chat`（250ms）和 `_layout()`（聊天流重排时）。`_layout()` 走完把 `_focus_label`
更新成了新值，于是 `_poll_chat` 里那句「标签变了才重画」永远判 false，标题栏的点再也不刷新。
另一条同源路径：窗口藏着的时候 `_draw_focus_line()` 早退（只记标签不画），重新显示时
没人补画。

修法两条，都是"谁画这行，谁把点一起刷"：

- `_draw_focus_line()` 收尾调 `_refresh_header()` —— 点和字由**同一次读盘**决定，不可能再分叉；
- `_sync_visible()` 重新显示时补一次 `_draw_focus_line()`（藏起来期间错过的状态变化补上）。

验收：冷启窗口后逐像素数颜色 —— 标题栏带（y 20–58）与焦点行带（y 76–106）都只剩
`#8e9db2`（61 / 448 像素），橙色 `#ffa63d` 两处都是 0；改之前是上橙下灰。

## [0.1.1-more.11] - 2026-11-16

### Fixed — 隐藏之后窗口还在空转（`window.py` 本地补丁）

上游 0.2.4 的社区实报：**状态位早就是「关」，窗口还在全速抓屏，4 秒吃掉 5 秒的 CPU**。

**本机实测的病因和上游不一样，写在这里免得下次照抄**：我们这份 `window.py` 的
`self._plain = True` 是**硬编码**的（`window.py:913`，2026-11-05 为"不抓屏、纯色面板"改的），
所以 `_work()` 里那条 `mss` 分支根本不会跑 —— 抓屏这条在我们这里**本来就没开着**。
真正在空转的是 250Hz 主循环（`INTERVAL_MS = 4`）：窗口藏起来之后没人贴图，它照样每 4ms
醒一次做心跳 / 清理节流 / 绑定会话检查。

实测（同一进程、静态桌面、10 秒窗口）：

| | 改之前 | 改之后 |
|---|---|---|
| 窗口可见 | 1.25s CPU / 10s（≈13% 一个核） | 1.25s（不变，画面要贴） |
| 隐藏 | **1.33s**（和可见一样，等于没关） | **0.17s**（≈1.7%） |

两处改动：

1. `_tick()` 开头：`self._hidden` 时主循环从 4ms 放到 100ms 再返回。`_poll_chat` 是另一条
   独立链（250ms），读协议、读配置、检测"重新显示"、弹通知都不受影响。
2. `_work()` 的 `plain` 与 `mss` 两个分支都加第三道闸 `self._hidden`（隐藏期间 0.2 秒一拍）。
   `plain` 是当前真正在走的那条；`mss` 现在是**防御性**的 —— 哪天把 `_plain` 改回 live 玻璃，
   这道闸就接管。

顺带留两行现场证据（都只打一次，不刷日志）：`[work] start plain=… hidden=…`，以及
隐藏/恢复翻转时的 `[work] hidden → 暂停抓屏` / `[work] visible → 恢复抓屏`。

> **这是手改的生成文件**：`examples/floating-chat/window.py` 由 `scripts/sync-window.mjs`
> 从上游 `dsh-watch-together` 生成，文件头写着「请勿手改」。下次同步会覆盖掉这段，
> 届时要么跟着上游走（他们 0.2.4 的修法是隐藏时 `_stop_worker()`、恢复时 `_start_worker()`），
> 要么把这两处闸再补回来。上游那份已经拆成 `glass_*.py` 多文件（1920 行），
> 我们这份还是单体版（9900+ 行）——**不能直接换文件**，只能手工搬改动。

### Fixed — 用户在主窗口说话，不算「人在」（上游 #69）

常驻循环只盯悬浮窗那条 `chat.jsonl`：用户切回 DSH 主聊天窗跟 agent 聊十几分钟，
它一个字都看不见，照样按「连续 N 次叫醒没人理」收工 —— 采集停了、人还在看，
agent 却被反复空叫醒。

- 新增 `src/human.js` 的 `isHumanMessage(event)`：只认 `user/message` 且
  `source.kind` 是 `user` / `action-cards`。**`see-now` 明确排除** —— 那是本插件自己的
  叫醒 / 提词（`timer.js` 的 `userMessage()`），把它当成人说话会让
  `wakesSinceUser` 永远归零、兜底线等于没写（比不修更糟）。
- `loop.js` 新增 `noteUserSpoke(sid)`：把 `lastUserAt` / `lastUserSpokeAt` 一起刷新、
  `wakesSinceUser` 归零；**只续循环自己的投递目标**（别的会话里的对话不给这条命续命）。
- `index.js` 的 `session/event` 钩子里调用；`let loop` 的声明**挪到钩子之前** ——
  钩子注册完就可能被触发，晚声明会撞 TDZ。

`test/human-message.test.mjs` 5 条：两种人类 kind 认、`see-now` 不认（反向也认得出）、
其它 kind 与缺 `source` 一律不认、类型不对不认、字段在顶层也认、缺形状不抛。

**补了两条可观测证据**（原来的 `log()` 只进宿主 logger，桌面版**不落盘、谁都看不到**，
所以"修好了没有"当时无从验证）：

- `lift/debug.log`：每次成功叫醒写 `叫醒 #N（本轮连续 N 次没人理）`；每次人类开口写
  `续命 sid=… 清零 N 次空叫醒`；被会话过滤时写 `续命跳过 sid=…（本循环=…）`。
- `status` 的收工线一行加 `（本轮已 N 次）`。

2026-11-16 22:48 实测（新版本、视听都开、屏幕有台词）：

```text
14:48:06.094  叫醒 #1（本轮连续 1 次没人理）
14:48:42.468  续命 sid=f08564d2 清零 1 次空叫醒     ← 用户在主窗打了「打字」
```

之后 `status` 显示「收工线：连续 24 次叫醒没人理（本轮已 0 次）」——
① 人类消息触发清零、② 叫醒本身不触发（两条时间点对得上）、③ 清零发生在发言之后，三条判据全过。

## [0.1.1-more.10] - 2026-11-16

### Changed — 排布默认一格都不裁（`stretch: 0`），并把它做成配置

`pack.solve` 的 `stretch`（0.3）从来不只是「拉伸」：它把一行的格子拉成等高带，
渲染时 `coverIntoAt` 按短边铺满、长边居中裁掉 —— 最宽格**上下各裁 23%**、最窄格
**左右各裁 23%**。裁多少、往哪边裁由当行的档位组合决定，**图上没有任何标记**，
模型看不见自己丢了边缘。这跟上游 `dsh-see-now` 0.2.4 的取舍是同一件事
（他们把默认改成 `maxCrop: 0`），我们这边同步。

本机实测（新增 `scripts/pack-crop-curve.mjs`，4 种密度画像 × 4 档，每格 150 条序列）：

| 画像 | `stretch` | 帧/张 | 平均裁 | 最大裁 | 有裁的格子 |
|---|---|---|---|---|---|
| 静态（全 1 档） | 0 / 0.3 | 4.00 / 4.00 | 0% / 0% | 0% / 0% | 0% / 0% |
| 一般（1–3 档） | 0 / 0.3 | 4.65 / **5.20** | 0% / 5.0% | 0% / 22.8% | 0% / 30% |
| 快（1–8 档） | 0 / 0.3 | 7.72 / **8.66** | 0% / 8.7% | 0% / 23.1% | 0% / 68% |

两件事值得记住：

- **静态场景一秒不差**：全 1 档时任何 `stretch` 都是 4.00 帧/张、0% 裁切 —— 看视频、
  挂机那类用法不受影响，只有快剪 / 游戏战斗这种多档混排才真的差。
- **兑换率是线性的**：1% 均匀裁切换 1.3~2.4% 帧/张。快场景多 11% 张数 ≈ 每小时多几 k
  token（¥ 到分以下），**所以这不是省钱决策，是"要不要悄悄丢边缘"的决策**。

配套：

- `pack.js`：`DEFAULT_STRETCH` 改 0，新增 `STRETCH_MAX = 0.3`（配置上限 = 老默认）。
- `pipeline.js`：`DEFAULTS.stretch = 0`；四处 `solve` / `splitOneBin` 都显式传
  `o.stretch`（**必须同源**，两处几何不一致会造出"DP 以为没裁、渲染裁了 23%"的图）。
- `runner.js` / `index.js`：`packStretch` 从 `~/.dsh/see-now.json` 一路带进管线，
  显式传 `opts.stretch` 时以调用方为准（`scripts/sim.mjs` 做 A/B 用）。
- `tuning.js`：`packStretch` 默认 0，夹在 0–0.3；写 `30` / `-0.1` / `"abc"` 这种
  一律退回默认并记一条 warn（把百分比当小数是很自然的手滑）。

要回老行为就写 `{"packStretch": 0.2}`（0.3 = 完全老行为）。

`test/pack-stretch.test.mjs` 五条：默认每格必须是正方形、0.3 会裁且单格上限 23%、
裁切不许丢帧、全 1 档任何档位都不裁、配置读入与越界告警。

## [0.1.1-more.9] - 2026-11-16

### Fixed — 比例法低血时把数字当填充（`band` 模式重写）

`ratioFromPixels(mode:"band")` 原来先找「最亮的一行」当条带。低血时条变暗红、白字数字
比条更亮，条带落在数字上、数字列成了填充 —— 真机 `4.3%` 读成 **11%**、`4%` 读成 **25%**。

现在三件事一起改：

- **条带**按「左端亮 / 右端暗」的横向对比定，两端的窗口都按框宽取比例、不写死像素；
  满血白条没有横向对比时，退回「左端相对最亮行」。
- **填充**按左端填充色找连续列：先用「离填充色足够近」粗分，再从填充右侧找一段平坦的
  未填充背景色，最后用「离填充色比离背景色更近」细分。判定用**列内填充分数 + 短窗口中位数**，
  所以中央菱形 / 分段刻度这类 2–3 列孤立标记跨得过去，而数字后半截那种
  「一半列有白字、一半列是暗底」的纹理接不回去。
- **分母改成条自己的宽度**（回归集暴露出来的第二个错）：框里常带着右端 `Lv.90` 装饰
  （真机框 421px、条只有 ~333px），拿框宽当分母会把 62% 读成 49%、满血读成 79%。
  现在从右往左找「连续 10 列都接近未填充背景色」的一段，它的右端就是条尾；
  填充后面直接是装饰/底板时按满条算。
- 旧的亮色端点法保留为**兜底**（新法认不出填充时才接管，避免把亮条读回 0）。

回归（`test/fixtures/ratio-samples/`，7 帧真机 + 真值表，验收 ≤3 点）：

| 帧 | 真值 | 修复后 | 误差 |
|---|---|---|---|
| `2798-17638.png` / `-b` | 15.9% | 14.8 / 14.6% | 1.1 / 1.3 |
| `2494-17638.png` | 14.1% | 12.3% | 1.8 |
| `4177-16100.png` | 25.9% | 24.9% | 1.0 |
| `10974-17638.png` | 62.2% | 62.6% | 0.4 |
| `22515-22515.png` | 100% | 100.0% | 0.0 |

`unknown.png` 真值未记录，只做负例（不许报 gone）；它读 51.2%，和同帧印的
`9148/17638 = 51.9%` 对得上，但**没进验收**。新增 `test/bloodbar-ratio-fixtures.test.mjs`
（自带最小 PNG 解码器 `test/png-decode.mjs`，不引依赖）。

### 已知边界（这轮新量到的）

- 95% 以上的条：未填充段不足 10 列，条尾扫描会回落到填充端点，可能报成 100%（误差 ≤5 点）。
- 条背景本身是高饱和色（不是灰/黑）时，「填充后面是底板 → 按满条算」的判据会误判；
  换游戏要先拿 `ratio-samples` 同款真值帧回归一次。

## [0.1.1-more.8] - 2026-11-16

### Added — 血条数字识别（OCR）：读数从「比例」升级成「当前/最大」

像素法在低血时会读错——条从白变暗红，`V≥0.55` 的亮色门槛把它当背景；数字白字又抢端点。
2026-11-16 实测同一帧：屏幕 `882/20725 = 4.3%`，比例法给 **11%**。

现在同一帧再认一次数字（Windows.Media.Ocr，常驻 Python sidecar，实测 12–92ms/帧）：

- **数字优先、比例兜底**：认出来就写 `血条 16%（2798/17638）`，阈值判断也按数字走；
  读不出数字（`no-digits`）时照旧只报比例，不编。同一帧的比例与数字进同一条轨迹点。
- **`read:true` 单次读也带数字**，并在同一行里同时给出「比例法 N%」——两条读数可对照。
- **预处理**：4× Lanczos + 240px 黑底画布。16px 条直接放大 2–8× 都是 0 行；
  3× 丢一位、6× 带噪声（这是这轮唯一真卡住的地方，别再"简化"掉画布高度）。
- **失败不拖垮采集**：OCR 起不来（没装 winrt / 没有中文识别器）只记 `status().bloodbar.ocr.why`，
  比例照报；`status` 的血条行会写「OCR 不可用」。

### Fixed — `status` 把「OCR 未启动」误报成「OCR 不可用」

重启后第一次 `status` 时血条采集还没起，`bloodbar.ocr.ok` 自然是 false，于是血条行写了
「OCR 不可用（缺 winrt）」—— 用户会照着去重装一个其实装好的包。
现在分开两件事：`available`（依赖能不能用，探针）与 `ok`（这一路此刻在不在跑），
只有 `available:false` 才提示缺依赖。

### Fixed — 数字被切掉首尾（`2798/17638` 读成 `98/1763`）

画布宽度原来正好等于条宽，数字贴着 crop 边界时 OCR 会吃掉首尾字符，于是读出一个
「合法但错」的百分比（5.6% 当 15% 报）。现在**左右各留 60px 黑边**（4× 放大后），
`2798/17638`、`4177/16100` 都读对。上下留白给行检测、左右留白给首尾字符，两处都不能省。

### Added — 多极性重试：plain → sharp → invert

血条数字的极性随血量翻转（暗底上是白字、亮条上是深色描边字、挤在一起时笔画粘连），
单一预处理必然丢一种。现在同一帧按「原图 → 锐化（UnsharpMask 2/150）→ 反色」依次试，
**认出合法数字就停**；`pre` 字段写明是哪一路认出来的。实测 36% 那帧原图读不出、
锐化后读出 `4177/16100`。最坏 3 次约 80ms，1 fps 无感。

### 已知边界 — 数字跨在填充边界上时读不出

血量中等时（约 40%），`9148/17638` 这类数字一半压在白条上（深字描边）、一半压在暗底上
（白字），单一阈值救不了；反色 / 边缘 / 局部反差 / 膨胀全试过（2026-11-16 真机）。
**低血（数字完整落在暗底上）能读对**，那正是比例法开始失准的区间；中高血退回比例，
那时亮条本来就准。读不出就标 `no-digits`，不编。

### 依赖（DSH 升级后要重装，别再当新鲜事）

`winrt-runtime` + `winrt-Windows.{Media.Ocr,Graphics.Imaging,Storage,Storage.Streams,Globalization,Foundation,Foundation.Collections}`
装进 **DSH 的 runtime python**（与 `windows-capture` 同一个坑）。`status` 的 OCR 行就是自检入口。

## [0.1.1-more.7] - 2026-11-11

### Added — 黑听抬头四档闭环（警觉 / 瞥 / 看 / 追）+ 按台词取帧（P2-A + P2-B）

黑听（只开耳朵）以前只有两档：强命中**一律叫醒**（贵一档），弱命中**连记录都没有**。
现在按「值不值得打扰」分四档，安静看片时可以完全不花 token：

- **警觉**：弱命中只记账（`lift.jsonl` 一行），不取帧、不叫醒、不进窗。5 分钟内累计 3 次
  自动升一次「瞥」（蓄水池，取第 3 声那一刻的帧）；
- **瞥**（默认）：强命中取「那句话那一刻」的一帧 → PNG 落盘 3 天 + 窗内一行 meta，**不叫醒**；
- **看**：同一触发，但最近 5 分钟有活跃对话（用户说过话，或模型上一回合刚结束）→ 叫醒模型，
  唤醒里带时间码、那句台词和近十分钟的池子摘要；
- **追**：只能模型在「看」之后自己调 `watch`，插件不替它发起（`lift.jsonl` 记 `chase`）；
- **回落**：抬头后 `holdSec`（默认 15 秒）安静**且画面不动**才回警觉；判「画面不动」用缓冲里
  最近两帧的像素差，不是「没新台词」（纯音乐里静音但画面在动，按台词判就是错的）；
- **可关**：`see-now.json` 写 `{"lift":{"enabled":false}}` 一键全关，`status` 里连档位行都没有；
  基线可设 `alarm`（最省：有人说话也只瞥一眼、永不叫醒）。

配套：

- **留底环形缓冲**（P2-A）：仅监听时按 0.5 fps 留最近 30 秒（≈16 MB，只在内存），
  `runner.frameAt(t0)` 按台词时间戳取帧；`see_now({action:"lift", since})` 给模型取「那一刻」的单帧图，
  缓冲里没有就**明说没了**，不拿当前帧冒充；
- `status` 多一行「档位 / 今日 警觉 N · 瞥 N · 看 N」（从 `lift.jsonl` 现算，重启不丢）；
- 叫醒加了 10 秒超时：`sessions.flush()` 会等当前回合落定，模型跑长回合时能把钟卡住
  （黑听的表现就是"活着但不动"），超时只记一行、不算叫醒失败。

### Fixed

- `lift.jsonl` 把「没取到帧」写成 `frameAt:0`（`Number(null) === 0`），应为 `null`；
- `lift/debug.log` 的诊断账补全：心跳带 `lines=N` / `asr-err=`（分清"钟停了"还是"转写没出句"），
  有整句却没命中时记前 40 字（分清"转写错"还是"词表漏"），每次叫醒记一行结果。

## [0.1.1-more.6] - 2026-11-10

### Fixed — `source:"file"` 的 path 能拼出协议 URL（移植上游 `0.2.2` / PR #66）

`path` 是模型能填的参数，以前原样拼进 `ffmpeg -i`：填 `http://…` / `tcp://…` / `concat:…`
时 ffmpeg 真的会去连（那是协议前缀）。

- 入口只收**本机文件的绝对路径**：绝对、存在、普通文件，否则报一句能照做的话、不起采集
  （`meta.reason` 从写死的 `bad-region` 改成 `bad-path`）；
- Windows 上两个分隔符开头的一律在 `stat` 之前拒（UNC / `\\?\` / `\\.\`）——
  光 stat 一个 UNC 路径就已经在连网络了；映射成盘符的网络盘不受影响；
- 文件源的 ffmpeg 参数加 `-protocol_whitelist file` 兜底（直接调 `runner` / `spawnFrames`
  的调试脚本也走这里）；
- **兼容变化**：相对路径以前「碰巧能用」（按宿主 cwd 解析，结果不可预期），现在明确被拒；
- 测试 `test/file-source-path.test.mjs` 按上游搬（7 条）；本仓没有 `test/ffmpeg.mjs` 夹具，
  ffmpeg 改走 `binaries.js` 的 `resolveFfmpeg` 自己找。

### 没跟的部分

上游 `0.2.2` 另外三项与本仓无关：自动省略的会话归属（本仓没有 image-offload）、
弹幕推送（本仓窗口没有弹幕）、Linux portal 的 stride 斜切（本仓只有 gdigrab）。

## [0.1.1-more.5] - 2026-11-10

### Added — 标题栏左上角内置悬浮窗入口（原 `dsh-see-now-launcher` 合并进来）

以前「打开悬浮窗」只有一条路：让模型先调一次 `see_now`。窗关了、进程没了、或者被藏起来了，
用户自己想再看到它没有任何入口 —— 那个入口此前是一个**独立的私有包** `dsh-see-now-launcher`，
既没进发布仓，`private: true`，意味着别人装 `dsh-see-now-more` 永远拿不到按钮。

现在入口在本包里，装完就有：

- **Client 半侧** `client.js`：占 `conversation.header.leading`（标题栏最左、标题之前那一格），
  一个 window 图标 + `see-now` 文字，状态文字走 `--dsw-alias-*` token，不 import 任何 Harness
  Client 包。`package.json` 声明 `dsh.client.platform: "web"`。
- **Host 半侧** `src/open-window.js`：注册 `POST /dsh-see-now-window/open`，点一下覆盖三种状态 ——
  没起就拉起、被藏了就取消隐藏、心跳过期（进程卡死）就换一个。顺序**先取消隐藏再开窗**：
  窗口启动时读 `hidden` 标志，带着旧值起来就是「开了但看不见」。
- **Web 载体是可选的**：走 `ctx.inject(['webServer'], …)` 而不是模块级 `inject` —— 没有 Web
  载体的宿主里入口静默跳过，采集、听声音、`see_now` 工具照常，不会因为少一个服务整插件不启动。
- 路由挂在**工具注册成功之后**：装了重复副本时那一份会提前退出，不会再抢同一条路径。

不再需要 `dsh-see-now-launcher`。装了它的 profile 把它从 bundles 与依赖里去掉即可（两个入口
同时存在会并排画两个按钮）。老包里的 client 半侧按自己的包名注册，不会和本包冲突。

## [0.1.1-more.4] - 2026-11-10

### Added — 悬浮窗气泡文字可拖选 + 复制

主窗、回顾页、收藏页的气泡文字现在都能用鼠标拖选，`Ctrl+C` / `Ctrl+Shift+C` / `Ctrl+Insert` 复制；右键菜单在有选区时多一项「复制选中文字」。

- **拖选**：文字行上按下拖动 = 选字；气泡边缘、行间空隙、标题栏照旧拖窗。双击选词、三击选整条、`Shift+点` 扩选、`Esc` / 点空白清选区；拖到视口上下边缘自动滚，长消息展开后能一直选下去。
- **复制**：`Ctrl+C` 同时写纯文本 + HTML 两种格式。纯文本保留原始消息文本（本地图是 `![图片](路径)`，网络图是 URL）；HTML 按「文字 → 图 → 文字」原序内嵌 `file:///` 图片，粘到 Word / 邮件等支持 HTML 的目标才带图。纯文本剪贴板本身带不了位图，这是格式上限。
- **不丢**：选区按「消息 key + 展示文本偏移」存，滚动、缩放、图片加载完重排都不丢；换页 / 展开收回 / 换会话 / 关窗才清。
- **菜单**：原「复制内容」改名「复制全文」；图片右键的「复制」改名「复制图片」；「复制选中文字」只在有选区时出现。
- **回顾 / 收藏**：和主窗同一套偏移与绘制；收藏页跨会话的条目按页面顺序选，`Ctrl+C` 直接接管（那边没有输入框）。主窗焦点在输入栏时 `Ctrl+C` 仍交给输入栏自己。

隔离验收 34 项（主窗 A1–A15 / C1–C3、回顾收藏 H0–H8、文字-图-文字 I1–I4、复制全文 J1），dev 与 `see-now-more` 副本各跑一遍全过。对应本地开发线 `see-now` 第 115 条。

## [0.1.1-more.3] - 2026-11-10

### Added — 亮度归一 + 黑边补偿（移植上游 `a0ff4d5`）

`scorePair` 是绝对差，而门槛 `cutAbs: 12` 是常数 —— 暗场真切点只有约 5 分（永远够不着），
2.39:1 的片子上下黑边又把分数打了 75 折。这一版把分数换算到「参考亮度、无黑边」的刻度上：

- `gain = clamp(REF_V / meanV, 1, 1.85)`，`REF_V = 96`（实测影视素材有效行的 V 均值；
  按老口径 160 算会给出 1.67 倍，等于把 `cutAbs: 12` 的标定整体下调 40%）；
- 黑边按「整窗一直黑」判定（24 帧 ≈ 2 秒），分数再除以 `1 - 黑边占比`；
  占比 > 0.35 视为整段黑场、不补偿；**亮度只算有效行** —— 否则黑边既拉低 gain 又被除一次，补两遍；
- 噪声地板 `raw < 2` 不放大：暗场的编码噪声本来只有 0.00–0.13；
- **亮场是 no-op**：`V ≥ 96` 且无黑边时逐位返回原分数（安全阀，也是回滚线）；
- 开关 `scoreNormalize`（默认开，`~/.dsh/see-now.json` 可关）。关掉 = 完全回到旧行为；
  写成字符串 `"false"` 会按真值误判，所以只认布尔，类型不对会报 warn 并回默认；
- 变化日志多了 `raw` / `gain` / `bar` 三个量，离线标定能分清「门槛低」和「gain 顶上去」；
  `scripts/sim.mjs` 的 `--scoreNormalize=0/1` 可做 A/B；
- 状态行会写明「亮度归一开（暗场/黑边已补偿）」，免得门槛含义变了看不出来。

只影响 `scoreMode: 'abs'`；`mc` 是另一套刻度，不参与归一。测试 `test/score-normalize.test.mjs`。

> **标定出处**：实现对应上游 `a0ff4d5`，但常数（`REF_V = 96`、`GAIN_MAX = 1.85`、
> `NOISE_FLOOR = 2`、亮度只算有效行）来自该提交之后、0.1.4 发布前的标定修正。
> 对照 `a0ff4d5` 的原始 diff 会看到 160 / 3 / 6 —— 那是中间值，不是最终口径。

## [0.1.1-more.2] - 2026-11-10

> **版本号为什么是 `0.1.1-more.2`，以及为什么它排得比 `0.2.0-more.1` 低。**
>
> 本仓代码基线是上游 `v0.1.1`。上一版叫 `0.2.0-more.1`，当时的理由是
> 「版本号 = 上游 0.2.0 基线 + `-more.1`」。但对照代码树，上游 0.2.0 的招牌功能
> 一个都不在（托盘 / 弹幕 / tierCurve / tierMode / 设置页 / 图库 offload / Linux
> portal），这个名义会让人以为跟上了上游。所以改回与代码一致的编号：
> `0.1.1` = 与上游 `v0.1.1` 的分叉基线，`-more.2` = 本仓第 2 个预发布。
>
> 代价是 semver 序变低（`0.1.1-more.2 < 0.2.0-more.1`）。这是**纠正标注，不是回退
> 代码**：功能只增不减；tag / Release 的先后按时间与 commit 看，不看版本序。
> `v0.2.0-more.1` 保留不动，作为历史锚点。

### Added — 采集进程按进程树结束，并用 `listen.pid` 兜底（移植上游 `d2835d1`）

Windows 上 `spawn(python, …)` 拿到的 pid 是 venv 的 launcher，`child.kill()` 只杀它，
真正在录音的基座解释器活着 —— 关窗之后麦克风灯一直亮；而关窗走 `hangUp()` 时
`child` 引用可能已丢，连 pid 都拿不到。

- `listen.py` 启动时把 `{pid, script, at}` 写进 `<audioDir>/listen.pid`，退出时删掉；
- `stop()` 把**内存 pid** 与 **pid 文件**并起来各杀一次；
- `start()` 开工前先扫 pid 文件清孤儿（否则会两根管道同时录音，同一句话转两遍）；
- Windows 上先 `tasklist` 确认映像名含 python 再 `taskkill /T /F`，pid 被复用时不误杀；
  记录超过 6 小时视为不可信。
- 测试 `test/listen-kill.test.mjs`（7 条，用假的 `run` / `kill` 断言发出去的命令）。

## [0.2.0-more.1] - 2026-11-09

> **首个以本仓形式发布的版本。** 版本号 = 上游 `0.2.0` 基线 + `-more.1` 后缀：它既不是上游的
> `0.2.0`，也不打算和上游的版本号对齐。`0.1.1 → 0.2.0` 的主体来自上游，本文件没有逐条记；
> 下面只记**本仓相对上游 `0.2.0` 的改动**。

### Added

- **`INSTALL.md`**：给 AI 读的安装单，从 clone 到重启一条链，含 `install-dev` 的依赖探测。
- **麦克风测试反馈 issue 模板**：麦克风输入至今没在真机上验证过，公开目的之一就是收这条路径的反馈。
- **`showPriceChip` 开关**：悬浮窗底栏的「高峰期 / 半价期」标签可以关掉（默认开）。

### Changed

- **包名 / 插件名 `dsh-see-now` → `dsh-see-now-more`**：不和 npm 上的上游撞车；
  `dsh plugin add dsh-see-now` 装的仍然是上游，不含这里的聊天窗 / 插队 / 历史 / 收藏。
- **去掉 `prepack` 生成链**：`sync:window` 会用上游覆盖 `window.py`，而这里对它改动很大，禁跑这条链。
- **适用范围写死**：Windows 10 + DSH `0.2.2-rc.1`；麦克风输入标注为「完全没测过」。
- **`NOTICE` 明确 fork 关系**：本仓是 SAOS-3624 `dsh-see-now` 的修改版，保留上游版权声明。
- **署名与仓库地址**：作者改 `72NG`，仓库指向 `nacivageer/dsh-see-now-more`，移除上游赞赏码。

### Fixed

- **网络图下不下来时主窗画成空白**：裸 URL 不再当图处理，加 photo 守卫，并按实际排版量兜底。

## [0.1.1] - 2026-11-04

> 为什么跳过 0.1.0：这个版本号在 11-03 14:26 被误发过一次（内容不可用，已标废弃）。
> npm 的规则是「用过的 `package@version` 永远不能再用，即使你已经把它 unpublish」，
> 所以这一版记为 0.1.1。

### Changed — 台词早 1.3 秒出现：长句边说边出字幕

社区反馈"字幕比画面晚 5~10 秒"。拆开量了一遍，**转写本身只要 100~180ms**，
时间全花在"等断句"上：

```
开口 ──等静音 0.35s / 等强切 3.0s──▶ 落盘 ──轮询 200ms──▶ 转写 180ms ──▶ 可读
        └────────────── 这一段占了 90% ──────────────┘
```

实测（本机 paraformer-zh，真实旁白素材）：

| 音频长度 | 转写耗时 |
|---|---|
| 1.0s | 99ms |
| 1.5s | 139ms |
| 2.0s | 158ms |
| 3.0s | 174~181ms |

**等断句的时间是转写本身的 20 倍。** 所以不再等：

- **长句说到 1.8 秒就先转一版**（`live-<t0>.wav`，同名覆盖），整句落盘后用准确结果
  覆盖它。真机实测：快照在开口后 **2.08s** 落盘、整句 3.30s —— **首版字幕提前 1.2 秒**。
- **轮询 200 → 100ms**，净省 100ms。
- 快照是"说了一半"，只在句末加「还在说…」标记，**整句永远盖过快照**：
  `createLineBuffer.upsert()` 按 `t0`（句首墙上时间）认同一句，迟到的快照不许把整句改回去。

**出图前等最多 300ms**（`listener.settle()`）：台词的取数窗口是「上一张图的 wallTo →
这一张的 wallTo」，差几百毫秒没转完的那句会被推到**下一张** —— 那就是十几秒，
而 ASR 本身只有 0.7 秒。**边界效应才是"字幕晚十几秒"的主因之一。**
积压（`seg` ≥ 3 个）时不参与等待，免得拖慢出图。

**顺带修的**

- **本地转写服务自己睡了没人管**：`asr.json` 的 `manage.idleMs` 常配成几秒，视频安静
  一会儿服务就退出，再说话时第一个请求必然失败。旧逻辑要等 3 次失败才拉起（白丢 30 秒
  字幕），现在**第一次失败就 spawn**（不 await、60 秒内不重复拉）。
- `status` 里加了延迟诊断：`上一句开口→可读 X.Xs`、`临时字幕 N 次`。
  以后问"怎么半天不出字幕"直接看这两个数，不用猜。
- 快照转写失败**不静默**了（记一条 log），但**不计入连续失败** —— 它只是"提前给一版"，
  挂了不该把主链路暂停 30 秒。

参数走 `~/.dsh/see-now.json` 的 `listen` 段（改完重开 DSH）：

```json
{ "listen": { "live": true, "liveMin": 1.8, "liveStep": 1.2,
              "silence": 0.35, "maxSeg": 3.0, "pollMs": 100 } }
```

`live:false` 退回纯整句（省一半转写调用）；`liveMin` 别低于 1.2
（1.0 秒的片段实测会丢一半字）。

> ⚠️ **还有一段延迟不归 ASR 管**：一张图覆盖 15 秒（`maxWaitSec`），第 3 秒说的话
> 要等第 15 秒出图时才随图交付 —— 平均 7.5 秒。要更跟得上画面就压 `maxWaitSec`
> 或改用 `pace:"dense"`，代价是 token 按比例涨。

### Performance — 打分快一半、出图快四成，顺手清掉一批死代码

实时链路里最贵的两段都是纯 JS（打分每帧跑、出图每 15 秒跑一次）。这次把里面的
浪费拿回来，**画面逐字节不变**：同一批素材新旧实现输出的 PNG 完全一致，
打分分数逐帧相等。

| 环节（798×450，i9-12900HX） | 改前 | 改后 |
|---|---|---|
| 打分 · 每帧 | 1.84 ms | **0.95 ms**（-48%） |
| 打分 · 静止画面 | 1.30 ms | **0.50 ms**（-62%） |
| 出一张 4 帧图 | 73 ms | **42 ms**（-43%） |
| 出一张 1 帧图 | 62 ms | **39 ms**（-37%） |

> 出图那两行是同一进程内新旧实现交替跑、每次前强制 GC、取 15 次中位数 ——
> 绝对值会被 GC 放大，看比例就好。

**打分（`cuts.js`）**

- `mcStats`：**先测同位置**再扫邻域。旧写法 `dy` 从 `-radius` 开始，radius=4 时
  同位置排在第 41 个，静止画面每格白算 40 次才命中。屏幕最常见的状态就是"没变"，
  这一条单独省掉 90% 的静止帧开销。
- `bgStats`：每个格子原来都 `new [0,0,0]` 一次并调 `TypedArray#sort`
  （2304 格 × 12fps = 每秒 2.7 万个短命数组），改成复用缓冲 + 手写插入排序
  —— m ≤ 8 时插入排序比内建快一倍多。

**出图（`scale.js` / `sheet.js` / `pipeline.js`）**

- 帧**直接缩进画布**（`coverIntoAt`）：不再"每格 alloc 中间缓冲 → coverInto →
  blit 到画布"，一张 4 帧图省掉 4 次 267KB 分配 + 4 次等大拷贝。
- 1×1 / 2×2 内联：`SEAM` 会把"整幅铺一格"变成 797×449 这种差 1 像素的尺寸，
  旧代码让每个像素都进通用平均循环求 1 个点的"平均"（还带一次除法）。
- 轴映射表按 `(源长, 目标长, 裁切长)` 缓存，同一档清晰度的每格尺寸都一样。
- 画布底色从逐像素循环改成 `buf.fill(Buffer)` 一次原生填充。
- 空洞掩码**只在真有空洞时才建**：4 帧 2×2、单帧铺满都覆盖整张画布，扫 36 万像素是白干。
- 音轨条**就地画**（`drawAudioStrip`）：`composePacked` 直接把条高预留进画布，
  不再"分配一张 1.1MB 的新图 + 整图拷贝"。
- 点阵编号直写像素：旧版每个点亮像素都调一次 `fillRect`，一次要做 4 次 clamp +
  2 次边界判断，画一个两位数就是 200+ 次函数调用。

**采集（`capture.js`）**

- 拼帧从 `Buffer.concat([pending, chunk])` 改成"一次 `allocUnsafe(need)` +
  按需 `copy`"。旧写法 pipe 每给 64KB 就拼一次，一帧 1.03MB 要拼 16 次，
  累计拷贝约 8.5MB/帧（12fps 下 100MB/s），全是白干。

**顺手修的**

- **文件源放完被当成异常**（`capture.js`）。`source:"file"` 播完是 `code 0`，而
  `close` 里除了 `code === null`（我们自己 kill 的）一律 reject。后果不是"多一条日志"：
  `runner` 只在 `.then()` 里写 `endedSource`，走 reject 分支那个硬闸就永远不生效 ——
  下一次 `watch` 会把同一个文件**从头再放一遍**（社区实报的"24 秒解 1955 帧、
  刷几十张图、关窗也停不干净"）。`scripts/sim.mjs` 也因此在最后一步抛异常。
- `DEFAULTS` 补上 `floorMin` / `floorMax`。三档节奏都显式传了，但直接
  `createPipeline({floorGapK: 2})` 时它们是 undefined → 兜底间隔算出 `NaN` →
  `elapsed >= NaN` 永远 false → **画面静止时兜底帧一帧都不出**。静默坏死，最难查。
- `index.js` 的 `loopLine` / `cookieWarnLine` / `listenLine` 从 `route()` 函数体内部
  提到模块顶层（原来靠函数提升才没报错，缩进还是 0）。

**删掉的死代码**

`pack.bestPlan`、`sheet.headerHeight`、`capture.ENGINES`、`speech.speechObservers`、
`chat.lastSpoken` / `__resetSpokenLog` / `__resetChatWatcher`、`pipeline.plan0`、
`stats.msDecode` / `stats.msTotal` / `pipeline.dropped`，以及 `index.js` 里两个
从未使用的 import。

### Changed — 台词追得上画面了：断句窗口砍半，台词直接标帧号

用户实报"字幕比画面落后四五秒"。那不是转写慢（130~250ms），是**断句等太久**：
原来连续说话要攒到 **6 秒**才强切，加上静音判定 0.45 秒，最坏情况下台词要等
6.5 秒才出现 —— 画面早换了。

| 参数 | 改前 | 改后 | 效果 |
|---|---|---|---|
| `max_seg`（强切） | 6.0s | **3.0s** | 最坏延迟腰斩 |
| `silence`（判定说完） | 0.45s | **0.35s** | 短句更快落盘 |
| 扫目录 | 350ms | 200ms | 平均省 75ms |

从"说完最后一个字"到"模型能读到"：**约 0.6~0.7 秒**（静音判定 350 + 扫盘 100 + 转写 150）。
从"开口"到"能读到"：最长 3.35 秒（原 6.45）。

**台词直接标帧号**：每条前面加 `#n`，表示这句最接近第 n 格画面 ——
模型不用再拿时间码自己算，一眼知道"这句配那张图"。

```
台词（…）：
  #2  15:57:32 / 9.3s  评价一个镜头的好坏，一般来说有两个维度
  #2  15:57:36 / 13.4s 第二个维度是艺术维度
```

代价：3 秒强切比 6 秒更容易把一句话切成两半（"第一个维" / "度是技术"）。
实时场景下"追上画面"比"句子完整"重要 —— 碎句模型能自己拼，晚 6 秒就救不回来了。

### Changed — 插话不再被冷却挡住

自动唤醒的 3 秒冷却是防刷屏的，套在**人的输入**上就是画蛇添足：你说完一句、
3 秒内再补一句，第二句被静默吞掉，然后以"排队消息"的形式堆在宿主里 —— 比不叫醒还糟。

现在插话**完全不受冷却限制**，只有"同一拍连发"（500ms 内刚叫醒过）才放回队列等下一拍。

### Fixed — 本地转写服务从来不会自动拉起（"看不到字幕"的真因）

2026-11-04 实报：重启后模型说"一次都没收到台词"。查下来是三个 bug 叠在一起：

1. **`asrConfig()` 把 `manage` 丢了**。它只挑了 `baseUrl / key / model / language` 四个字段，
   而"服务没起时怎么拉起"全在 `manage.start` 里 —— 于是 `ensureService()` 永远报
   `asr.json 里没写 manage.start`，服务永远不会被拉起。
2. **`httpTranscriber` 把异常吞成空串**。`catch` 里 `return ''`，上层只当"这段没人说话"：
   失败计数永远是 0、不会停、`status` 永远显示"在听、0 句"。**服务根本没起的时候，
   界面上和"视频是默片"一模一样。**
3. **失败 3 次直接 `stop()`**。而最常见的失败（服务没起 / 正在冷启动 30 秒）本来会自己好，
   停掉等于永久放弃，还会连带 kill 采集进程、把音量条一起弄没。

修完的行为：

- 开始听时先探 `GET <origin>/health`，不通就按 `manage.start` 拉起（不 await，不挡采集；
  实测 5.1 秒就绪）。**只管拉不管关** —— 服务自己有 `idleMs`。
- 转写失败改成**暂停 30 秒后重试**，文件留着不删（服务起来后接着转），目录最多留 40 段。
- `status` 的「听声音」那行会直接写 `在听但转写停了：<原因>`，不再是含糊的"在听、0 句"。

### Added — 图底下长出音轨条，台词带上本机时钟

上一版能听见了，但"听见了什么"只在文本里。这一版画到图上、把时间码写在台词旁边。

- **音轨条**（`sheet.js` 的 `addAudioStrip`）：图底下接一条 `width×0.055` 高的带子
  （高度 = 画面占行后剩下的余量，默认档 12px）。三样东西：**响度柱**（青绿，一眼看出是安静旁白还是配乐轰鸣）、
  **静音灰块**（没人说话处铺深灰，柱子压在上面 —— 早先试过"静音不画柱子"，灰块会变成
  一根根实心竖条把波形切断）、**切点刻度**（顶部黄短线，`via==='cut'` 的时刻，和宫格编号对得上）。
  配色和 `dsh-video-storyboard` 逐字节一致。
- **音量数据是白捡的**：`listen.py` 的 `LevelMeter` 复用**断句已经在算的 RMS**，每秒写一次
  `levels.json`（0.1 秒一格、留 180 秒）。不像 storyboard 要再开一次 ffmpeg 跑 `ebur128`。
  纯音乐没人说话、甚至转写服务挂了，音量条照样有。
  关键：`levels.json` **按时间格子**存，静音格子显式补 `-120dB` —— WASAPI 静音时一个字节都不推，
  照"有数据才写"出来的序列在时间轴上是断的，画成条就是"柱子之间一片黑"。
- **台词两个时间都给**：`15:57:32 / 9.3s`。本机时钟给用户回头找（实时看屏幕没有"视频进度"，
  浏览器放到第几秒我们不知道）；相对秒和每帧那个 `24.1s` 同坐标系，模型才能把话对到格。

### Changed — 画布宽度对齐 42、音轨条改成"白捡的"，每张 254 → 222 token

两刀，都不损失东西：

**① 宽度向下对齐 42**（800→798、1066→1050、1280→1260、1600→1596）。
800 会被 pad 到 812 = 19.3 格，白算一整列；798 正好 19 列，**面积只少 0.25%**。

**② 音轨条不跨行**。token 是按 42px 一行的阶梯函数：450 高的画面占 11 行、上界 462，
底下**空着 12px 也照样收 11 行的钱**。所以条高取"这段余量"（450 余 12、600 余 30、720 余 36、900 余 24），
画面一点不少、条照样有、token 一行不涨。

| 档位 | 改前 | 改后 |
|---|---|---|
| `low`（默认） | 800×494 = **254** | 798×462 = **222**（-12.6%） |
| `standard` | 1066×659 = 434 | 1050×630 = **392** |
| `high` | 1280×790 = 610 | 1260×756 = **560** |
| `ultra` | 1600×988 = 962 | 1596×924 = **860** |

对齐 + 白捡之后，**222 比加条之前的 233 还低**（因为宽度省了一列）。

副作用：`low` 档的条只有 12px（柱子最高 9px）。看得出"哪里有声音、哪里安静、切点在哪"，
但看不出精细包络 —— 这是"不跨行"的硬约束，想要粗一点的条就得占一整行（+20 token）。

`LONG_EDGE`（region 模式的单格长边）**故意不动** —— 那个尺寸是 `cellSize()` 按区域比例算的，
本来就不是 42 的倍数，改它只会连带 2/4 帧拼图，收益是个位数 token。

### 想更干净就打掉音轨条（但不省钱）

`audioStrip: false` → 798×450 = **222 token**，和带条**一模一样**（450 和 462 都在 11 行里）。

### Fixed

- `flushNow` 补的"此刻那一帧"没带 `wall` → `sheet.wallTo` 是 null，最后一张图取不到台词。

### Added

- **按"上一句说了多长"排下一次叫醒**。固定间隔（calm 30s / normal 15s / dense 8s / 逐场景 4s）
  是从**叫醒那一刻**起算的，跟上一句说了多久没关系：上一句长的时候，下一轮会在它还在说时被叫起来。
  现在默认**跟随上一句**——下一轮最早落在「上一句说完 + 0.8 秒气口」，并保留 3 秒地板防连珠炮。
  想保持旧节奏写 `"speechPacing": "guard"`（取旧间隔与"说完+气口"更晚的那个），写 `false` 完全关掉。
  用户插话不受限制。时长按文本估（中文约 5 字/秒、英文约 14 字/秒，±20% 足够），
  不需要问 TTS 引擎要音频时长。有声音适配器时以 `spoken`（开始播放）为起点；
  没有声音时以 `due` 为起点，避免文字刷屏。`status` 的循环行会显示
  `上一句约 X.Xs` 和 `下一轮最早 Ns 后`。

## [0.0.10] - 2026-11-04

### Added — 它开始听得见了：视频里的台词跟画面一起交给模型

之前只看画面：视频里的人在说什么、旁白讲到哪，模型全靠猜。
`see_now` 返回的清单里现在多一段 `台词`，时间码和每帧那个 `24.1s` 是同一个坐标系，
模型能把"这句话"和"第几格画面"对上。

链路：`examples/floating-chat/listen.py`（WASAPI loopback → 16k 单声道 → 按静音断句
→ `seg-<epochMs>.wav`）→ Node 扫目录 → 宿主 `speechToText` 或 `~/.dsh/asr.json` 的
OpenAI 兼容服务 → 台词缓冲 → `runner.attachLines()` 挂到 sheet 上。

实测（i9-12900HX / Win11）：抓回环绕 **0.3% 单核**，转写 3 秒段 **130–160ms**、
10 秒段 400ms；按静音断句，一句话说完到文字可用约 1 秒。
对比画面侧 ddagrab 0.18 核 —— 音频是零头。

**三级降级，永远不会让"看屏幕"起不来**：宿主 `speechToText`（DSH 桌面版自带
SenseVoice，社区用户零安装）→ 本地 HTTP → 都没有就只出图不出字幕，
`status` 里写明原因（`听声音：没在听 —— …`）。关掉：`DSH_SEE_AUDIO=0`。

- **"只听"模式：循环收工之后，窗口里的输入不再扔进黑洞**。以前 idle 或连续叫不醒就
  `dispose()` 整条循环，可那扇窗还摆在屏幕上 —— 用户之后打的字没有任何人读，他当然
  以为自己在跟它说话。
  现在 idle 时先看窗还在不在（`idleAction()`）：窗开着就只停采集、**留着耳朵**（`mode: 'listen'`），
  窗没了才真收工。窗口里一开口立刻回到 active 唤醒模型。
  采集**不会**自动重启 —— 模型要看图会调 `peek`，那条路才按用户原来的 region / 清晰度起管道。
  为此加了 `pausedByListen` 标志：退出只听后的第一拍会看到 `!alive`，那本来是我们自己停的，
  没有标志就会被判成 `capture-stopped`，用户刚说一句话循环就整个收工。
  `status` 里也会显示「循环：只听（…）」。
- **缺 Python 包时打印安装命令**。窗口脚本要 Pillow / mss / numpy，缺任何一个都是
  "启动后 700ms 退出、code=1"，而插件以前只把 code 原样抛出去。现在启动全失败后会跑一次
  import 探测，把缺的包名和 `python -m pip install ...` 一起报出来。

- `test/pack.test.mjs`：四条排布测试（容差、flat 判据、缓存键、部分拉伸上限）。
  这套原来缺位 —— 三个新行为改回旧代码，138 条测试一条都不红。

### Changed

- `see_now` 返回的文本多一段台词，`status` 多一行「听声音」。
- `pipeline.js` 的帧多带一个 `wall`（epoch ms），sheet 多 `wallFrom` / `wallTo` ——
  台词只有时间码没有帧号，对齐只能靠同一个时钟（`t` 是"第几秒"，掉帧就漂）。

声音适配器和 `dsh-watch-together` **共用同一个模块**（`~/.dsh/voice.json` 只写一份），
所以那边把 `examples/voice-edge-tts` 换成常驻合成器之后，这里一起变快：

| 场景 | 之前 | 现在 |
|---|---|---|
| `say` 一句（`at: null`，没有预取窗口） | 2.4~2.5 秒 | **~230ms** |

`see_now` 的事件仍然发 `at: null` 的 `due` —— 它没有时间轴，本来也预取不了。
变快不是因为提前知道台词，是常驻进程省掉了"每句重付 python 启动 + import 建连 + ffplay 启动"
这四笔固定开销。协议和 `spoken` / `skipped` 的语义都没有变。




> 社区（Win10）报的 5 条。核心是**关窗后再也回不来**，以及**出了问题只给一个 exit code**。

- 跟 storyboard 0.6.6 对齐三个排布行为：`DEFAULT_STRETCH` 0.3、flat 判据改成 `(1+τ)²`、
  逐格部分拉伸。**实时性没受影响**：240 帧全流程 30.5 → 29.1ms（帧预算 83ms/帧），
  而且排布只在判"这张该封了"的时候跑一次，不是每帧。fill 77.3% → 83.8%，箱数 -5%。
- **画布仍是 800×450，没跟着对齐 42px**：本包的 `width` 同时是采集管道的 rawvideo 尺寸
  （ffmpeg 直接按它出帧），改它要动 scale / region / PNG 三处，收益只有每张 11 token。

### Fixed

- **手动重开悬浮窗之后仍然被"挂断"拦住，只能重启 DSH**。`hangUp()` 改的是本进程内存里的一个
  布尔值，而 `bin/see-window.mjs --force` 是**另一个 node 进程** —— 它只杀/重开 python 窗口，
  碰不到那个值。用户体感就是"窗明明回来了，它还说我把窗关掉了"。
  现在 `start()` 里会判断：挂断之后 **pid 文件被重写过**（= 有人主动开过窗）就解除挂断。
  判据刻意不用 `windowAlive()` —— 残留进程同样为真，那样会把窗重新弹出来（正是以前修过的问题）。
  新增 `resumeFromReopen()` 纯判据 + 4 条回归。
- **采集提前退出时看不出原因**。以前只有 `code !== 0 且 stderr 非空` 才算失败，`code === 0`
  会静默 resolve —— 上层看起来和"正常收工"一模一样。屏幕采集**不存在自然播完**，所以现在
  code 0 和非 0 一律报错，并且带上**运行时长与已收帧数**（12fps 下 141s/1686 帧说明是跑着跑着停的，
  不是启动就崩 —— 这正是区分"缺包秒退"和"中途掉线"的关键）。
- **`capture-stopped` 之后还在连发「有新画面了」，文案里「上一句 say N 秒前」的秒数越来越大**。
  `lastSaidNote()` 用 `Date.now()` 实时算，采集停了还在造新提词，那句当然是过期的。
  现在采集死后**只允许第一拍**把已经攒好的那张报出去，之后不再产生唤醒（队列里的图仍能 `peek` 到，不丢东西）。

- **`rowOptions` 缓存键只编码了 `stretch > 0.15` 这一个布尔**，0.2 和 0.3 共用同一份候选。
  改默认容差时踩到：先算 0.2 再算 0.3，后者拿到的是没有 flat 的候选，
  `[3,4,4,4,7,7,7,2,2]` 从 1 张装下变成 2 张。改成字符串键（档位|grow|stretch|fillRows）。

### 三个踩过的坑（都有回归）

- **静音段 WASAPI loopback 一个字节都不推**（实测 3 秒静音 callback 触发 0 次）。
  所以时间码只取每块到达的墙上时间，绝不累加样本数 —— 否则静音 10 秒后一开口，
  字幕整体漂 10 秒。另外**不能用阻塞 `stream.read()`**：静音时它会一直挂着
  （实测想读 4 秒、实际卡了 19 秒），断句判据根本没机会跑。改成回调 + 队列 + `tick()`。
- **立体声必须先混单声道再降采样**。`reshape(-1, 3).mean()` 一步做完会让两个声道
  相位抵消，ASR 只认出"嗯。"。正确顺序 `reshape(-1, ch).mean(1)` → 3 点箱式平均，
  纯 numpy 就够（不用 scipy / ffmpeg）。
- **它听得见自己**。TTS 念台词 → 音箱出声 → 回环收回去 → 变成"视频里的台词"，
  然后模型接着那句话往下聊，停不下来。

  修的时候才发现：**`quiet-until.json` 只有陪看在写**（`bin/watch.mjs` 拿它防两个 SAPI 抢话），
  see-now 从来没写过 —— 也就是说 `mic.py` 的 `tts_busy()` 在 see-now 下一直是空转。
  现在在 `say` 的 `due` 事件上挂了一个**只观察、不出声**的订阅者（`voice:false`，标 true 会顶高
  `speechSubscribers()`，展示层就会一直等一个不来的 `spoken`），按字数估一个保守窗口
  （中文 4 字/秒 × 1.5 余量 + 1.2 秒收尾）。**这是"闭嘴不听"，不是"屏蔽自己"** —— 窗口内整段丢弃，
  代价是用户正好在说话、或视频里正好有人说话时，那一段也没了。

  判据还必须按**段的时间窗**、不能按"落盘那一刻"：一句话跨过窗口末尾时，落盘时已经出窗口了，
  但它的前半段仍然是 AI 的声音 —— 实测窗口只剩 0.25 秒时，整段 6 秒被当成视频台词收了进去。

### 为什么是 pyaudiowpatch

`ffmpeg -f dshow` 在这台机器上枚举不到"立体声混音"（注册表里有、设备管理器也显示启用，
dshow 就是看不到）；`soundcard` 的 loopback 两个端点、四组采样率**恒返回 0**；
`sounddevice`（PortAudio 原生）的 WASAPI host API 里**根本没有 loopback 设备**
—— 官方 PortAudio 不暴露，只有 pyaudiowpatch 那个 fork 打了补丁。它也不需要虚拟声卡。
缺这个包就静默降级，`status` 里会说缺什么。

## [0.0.9] - 2026-11-03

> 自选一块屏幕给它看（框一下就行，不用报坐标）；接社区三条反馈：
> 抓屏失败不再变透明玻璃、对话记全、语音模型可以自定义。

### Added — 自选区域（`action:"region"`）

`region:"x,y,w,h"` 是 PR #9 加的，但**谁来量这四个数**没人管：让用户去截图软件里读像素
不现实，让模型猜更不行。现在补上交互那一半：

- `see_now({action:"region"})` 起一个全屏取框窗（`pick_region.py`，和悬浮窗共用同一个
  带 tkinter 的 python），屏幕变暗 → 拖一个框 → 松手，坐标自动落盘
- 落盘在 `~/.dsh/see-now/region.json`，之后每轮 `watch` **默认就用它** ——
  模型不用记数字，用户也不用每次再说一遍
- `region:"off"` 取消，回到整屏（顺手修了撤回不生效：原来"一边有一边没有"不触发重开，
  用户点了取消画面还在抓那一小块）
- 取框前声明 per-monitor v2 DPI 感知：Tk 的坐标是逻辑像素，150% 缩放下拿去做
  `-offset_x` 会偏（和 `window.py` 同一个坑）
- 只支持主屏：虚拟桌面起点可能是负坐标，Tk 的 `+x+y` 表达不了，gdigrab 也不接受负
  offset —— 与其给一个错的矩形，不如明确说"请在主屏里框"
- **能力边界要说清**：抓的是屏幕上正在显示的像素，被别的窗口挡住就只看到挡住它的东西；
  没接 OBS，抓不到后台 / 最小化窗口（这条写进了工具描述，模型会如实转述）

### Fixed — 悬浮窗被藏起来之后没有任何办法叫回来

`hidden` 是 `~/.dsh/watch-window.json` 里的**粘性**状态，由窗口进程每 250ms 读一次。
用户点过一次「藏起来」之后，下一次 `watch` 开出来的窗**带着 `hidden:true` 启动**：
进程活着、心跳在跳、日志一行不报，但屏幕上什么都没有。工具以前完全不碰这个文件，
也没有「显示」这条 action —— 模型只能去读配置，又没有写权限，于是答
"我这边只有读权限，发不了「显示」指令"（2026-11-03 社区反馈原话）。

- 新 action `see_now({action:"window", show:true|false})`：不传 `show` 只报状态；
  改的是窗口进程轮询的那份文件，**不用重启窗口**，一拍（250ms）生效；
- `watch` / `peek` / `start` 开出一个**新**进程时自动清掉 `hidden`（`already` 时不动 ——
  那是用户自己开着的窗，可能正故意藏着）；
- `watch` 的结果、`status` 都带上 `窗口：进程 N 活着 · 心跳 0s 前 · 藏起来的（用户看不见）`；
  藏着时 `watch` 会明说「用户看不到你的 `say`」并给出那条指令。

### Fixed — 抓屏失败时窗变成一块透明玻璃

BitBlt 会在锁屏 / UAC 安全桌面 / 远程桌面 / 某些 HDR 或全屏独占的机器上失败。
以前 `grab()` 把异常直接抛给渲染线程：每帧一条 `capture error`，一帧都画不出来，
窗口只剩文字浮在桌面上 ——「背景不知道为什么变成透明的了」（2026-11-03 社区反馈）。

- 抓不到就返回一块**纯色底板**的替身截图（同尺寸复用，不每帧分配），
  模糊 / 透镜 / 圆角 / 文字全都不受影响；
- 替身同时给 `.rgb`（CPU）和 `.bgra`（GPU）：只给 rgb 的话 `DSH_GLASS_GPU=1` 的机器
  会每帧在 GPU 路径 `AttributeError`；
- 失败日志 30 秒最多一条（每帧刷屏等于没有日志）。

### Fixed — 对话现在记全了

小窗原来只有 `say` 气泡和用户自己打的字，模型正常回的话一句都不在里面，
于是它只好跟用户解释"我们的对话不会记录在窗口"。现在每轮的**正文**也会追加进
`chat.jsonl`（不朗读 —— 只有 `say` 会念），并且：窗没开着不写、`say` 已经进过窗的跳过
（避免同一句出现两遍）、超长截到 600 字。工具描述里那句"你的正文永远不会到窗里"
也改掉了，模型不会再说反话。

### Added — 语音模型可以自定义（`voice.json` 的 `options`）

核心仍然不内置任何引擎，但以前除了"用哪个适配器"没有任何透传入口，适配器只能把模型
路径写死在自己代码里 —— 用户换一个自己训的模型就得改别人的源码（2026-11-03 社区反馈）。
现在：

```json
// ~/.dsh/voice.json
{ "adapter": "D:/my-voice/index.mjs", "options": { "model": "D:/my/models/xxx" } }
```

`options` 原样交给 `attach(api, options)`，并计入挂载指纹（改了就重挂，不用重启）。
老适配器不受影响：它们本来就只接一个参数。

### Fixed — 加载失败只写进 logger，用户那一侧完全无声

`apply()` 以前把异常吞成一行 `logger.error`（只在开发者工具里）。用户看到的现象是
"这个会话里根本没有 `see_now`" —— 模型只能靠读文件猜，还把猜出来的调用当正文吐出来。
现在同一份错误追加到 `~/.dsh/see-now/plugin-error.log`（超 64KB 自动截断），
注册成功也打一行 `已注册工具 see_now（v0.0.9）`：空日志 + 有注册行 = 插件没问题，
找宿主/沙箱；有错误行 = 看堆栈。装了两份时只记一行并**整份退出**，不留两套常驻循环
各叫一次模型。

### Changed — `install-dev.mjs --check` 报版本对账

以前只说"已安装 / 已注册"，装的是哪一版要靠自己翻文件。现在直接对：

```
源码版本  : 0.0.9
副本版本  : 0.0.3  ⚠️ 和源码不一致（跑的是旧代码）
  ⚠️ 副本里 dsh.plugin.json 写的是 0.0.2 —— 和 package.json 不一致
→ 跑 `node scripts/install-dev.mjs` 同步，然后**重启 DSH Desktop**。
  （新开一个会话不够：插件树是进程启动时组合的，已加载的代码不会换。）
```

### Tests

135 条通过（新增 `region-file` 5 条、`visibility` 5 条、`picker` 1 条；
`picker` 默认 skip —— 它会真的闪一个全屏罩子，`DSH_PICK_SELFTEST=1` 才跑）。

## [0.0.8] - 2026-11-03

> 跟上上游的悬浮窗重构：窗口从一个 1931 行的单文件拆成五层。

### Changed — 同步 `dsh-watch-together` 0.2.11 的窗口

`examples/floating-chat/` 是 `scripts/sync-window.mjs` 从上游生成的产物，这次跟着更新：

- `window.py` 1931 → 1218 行，玻璃拆成 `glass_geometry`（不可变 `Geometry`）/
  `glass_capture`（抓屏 + 运动判定，CPU/GPU 共用）/ `glass_cpu` / `glass_gpu` /
  `window_widgets`；
- GPU 路径修了三个真 bug：OpenGL context 建在主线程（每帧 `cannot create texture`）、
  录屏模式没挖掉自己（永不跳帧）、`DSH_GLASS_NATIVE=1` 是假开关。
  这台机器上实测 87.9% → 32.1% 单核；
- `capturable` 模式下桌面图标被沿上下 / 左右拉成条的问题修掉了（填充只用窗口外
  四角的中位色，不再沿边缘插值）。

细节见 `dsh-watch-together` 的 CHANGELOG 0.2.11。

### Fixed — 同步脚本会漏掉拆分后的玻璃模块

`scripts/sync-window.mjs` 原来只拷 `window.py` + `mic.py` + `window_protocol.py` +
`mic-dsh.png`。上游拆包之后，只装了 see-now 的机器会直接崩在
`ModuleNotFoundError: glass_geometry` —— 而且开发机上永远复现不了（兄弟仓库里
那几个文件一直都在）。ASSETS 补上 `glass_*.py` / `window_widgets.py`。

### Fixed — 包内窗口的守卫用「单文件大小」当代理，拆包后变成假失败

`test/packaged-window.test.mjs` 原来断言 `window.py` 大于 50000 字符。拆包后它从
78KB 掉到 43KB，这条直接红。而且它本来就没守住真正的问题（漏一个模块照样发得出去）。
改成逐文件存在性 + 单文件非空 + 总量 > 90k。

## [0.0.7] - 2026-11-03

### Fixed — 心跳抖一下就被当成"用户关窗"，会话再也回不来

社区 1 例反馈"会话自己结束了"。链路是：窗口心跳 6 秒没更新（机器睡一觉醒来、
窗口主线程被拖住几秒）→ `windowAlive()` 判否 → 常驻循环**第一拍**就
`stop('window-closed')` → 落挂断说明（"用户关掉了窗……不要再调 see_now"）+ `hangUp()`
→ 之后 `watch` 一律被硬闸拦，这个会话只能重开。

根因是**一个判据回答了两个问题**：`windowAlive()` 的语义是"这窗还能不能用"
（过期就该重开），而循环要的是"用户是不是不看了"。现在分开：

- 新增 `windowPidAlive()`：只看进程在不在，不看心跳。
- 新增纯函数 `windowVerdict()`：进程没了才算 `closed`（照旧挂断）；
  进程还在、只是心跳断了算 `stalled`，连续 `WINDOW_GONE_TICKS`（3 拍 = 6 秒）才停，
  而且**不挂断** —— 下一条 `watch` 能自己把窗重开起来。
- 停因照旧能从 `see_now({action:"status"})` 的 `循环：已停（…）` 看到，
  现在多了 `window-stalled` 这个值，正好用来区分"用户关的"和"它自己卡了"。

回归：`test/heartbeat.test.mjs`。

## [0.0.6] - 2026-11-02

> 主题：**macOS 能用**（avfoundation 移植），外加 issue #1 / #2 / #3 一起收掉。
> macOS 与声音适配器那两块来自 **布丁** 的补丁（`macos-port.patch`，13 文件 / +735−35）。

### Added — `avfoundation` 屏幕/摄像头源

- 屏幕：`-f avfoundation -framerate 12 -pixel_format nv12 -capture_cursor 0 -i "Capture screen 0:none"`。
  音频写 `none`，否则某些系统会去开麦克风、多弹一次权限。
- 摄像头 / OBS 虚拟摄像头：同样走 avfoundation，`-i "<设备名或索引>:none"`。
- 局部裁剪：avfoundation 没有 gdigrab 的 `-video_size`，改在滤镜里 `crop`（坐标按采集分辨率算）。
- `pickScreenEngine()` 按平台分派：macOS 探 avfoundation、Windows 探 ddagrab、其它平台**明确报错**，
  不再假装能用。

### Added — 像素格式探针

屏幕输入**不支持** ffmpeg 默认的 `yuv420p`，每个进程都会刷一行 "not supported" 到 stderr
（真出错时被截断的 300 字里全是它）。现在探针按 CPU 从省到费试
`nv12` → `uyvy422` → `bgr0` → 设备默认，挑第一个真能出帧的并缓存。

### Added — `binaries.js`：自己找 ffmpeg

DSH 桌面版把 ffmpeg 放在 `~/.dsh/tools/ffmpeg/bin`，**不进 PATH**。原来写死裸 `'ffmpeg'`，
在 macOS 上就是 ENOENT，而且看起来像"插件坏了"。现在按
`DSH_FFMPEG_PATH` → `FFMPEG_PATH` → `DSH_FFMPEG_DIR` → `$DSH_HOME/tools/ffmpeg/bin` → `$DSH_HOME/bin` → PATH 找。

### Added — 屏幕录制权限提示

macOS 没给「屏幕录制」权限时 ffmpeg **不报错**：exit 0、帧数正常、画面全黑。
探针算平均像素，全黑就在 `start` 的返回里带一句去系统设置的提示。

### Fixed — 每次 `stop` 都往 `lastError` 里写一条假错误

`stop()` 是 SIGKILL，子进程 `code` 是 `null`。原来的判断 `err.trim() && code !== 0`
把"我们主动杀的"也算成失败 —— 只要 stderr 有过任何一行输出（macOS 上就有），
每次收工都会盖一条 `ffmpeg exit null`。现在 `code === null` 一律按正常收尾处理。

### Fixed — 测试改成了平台无关

原来的采集参数断言全是 Windows 引擎行为，在 Mac 上跑会走 avfoundation 分支。
现在显式传 `platform`，并补了 macOS 屏幕/摄像头/裁剪三条和"其它平台明确报错"一条。
#### Added — 声音适配器（macOS / `say`）

`examples/voice-say-mac.mjs`：把「该念了」翻译成一次 `say`，音色语速读 `~/.dsh/tts.json`
（和 `dsh-watch-together` 共用）。核心仍然不内置引擎，只认 `~/.dsh/voice.json` 里的
`adapter` 路径。

三条实现上的决定：**不排队**（正在念时新句子直接 `skipped` —— 等它念完，画面早就过去了）、
**`spoken` 在进程起来那一刻发**（展示层"字跟着声音走"）、**detach 要杀进程**
（关窗时正在念的那句必须立刻停）。

#### Added — `ensureConfiguredVoice()`：每次调用前检查一次

原来只在插件启动时读一次 `~/.dsh/voice.json`，于是「配置文件是插件启动之后才写的」这种情况
必须重启整个 DSH。现在工具入口每次都过一遍：

- 没配 → 什么都不做；
- 配了指纹没变 → 一次读文件的代价就返回；
- 指纹变了（换了适配器，或改了 `tts.json` 内容）→ 卸载重挂。

指纹用 `tts.json` 的**内容摘要**而不是 mtime：mtime 只到毫秒，同一毫秒内两次等长写入会被判成
"没变"—— 写这个的单测里当场踩到，改成 sha256 前 16 位。代价是这个几十字节的文件每轮读一次。


### Fixed — 持续陪看链路（#1）

- **`peek` 不再丢弃已拼好的图**：它原来走 `flushNow()`（插话专用），会把 `sheets` 清空、
  再把"此刻那一帧"塞成一张新图 —— 后台喊"有新画面了"、模型调 peek，拿到的是当场截的一张，
  攒好的多帧摘要反而没了（复现：`queued [0,2,4]` → `[5.92]`、`pending 0`）。现在走 `take()`，
  取一张少一张；队列空就返回 `null`，不再凭空造图。
- **循环 owner 在 watch 开始前锁定**：`watch` 阻塞 15~40 秒，期间任何会话的 `session/event`
  都会改写 `lastSessionId`；循环是等它返回才建的，现取就会绑到"等待期间最后说话的那个会话"
  （复现：A 发起 watch，结束后 `loop.session === B`）。
- **`minFrames` 在正常返回路径也生效**：以前只有超时分支检查，队列先到的路会交一张 1 帧的图
  还报 `ok: true`。现在不够就丢掉接着等。顺带理清"逐帧模式 × minFrames"：逐帧一张图只有 1 帧，
  `minFrames > 1` 永远等不满，会让路并说明。

### Fixed — 悬浮窗可用性（#2）

- **关窗后能自己重开**：新增 `bin/see-window.mjs`（`npx dsh-see-window`，支持 `--status` /
  `--force` / `--close`）。原来只有模型调 `watch` 才能拉起来，点了 × 就只能重启 DSH。
- **高 DPI 下窗口不再变小**：进程声明了 per-monitor v2 DPI 感知，Tk 坐标因此全是物理像素 ——
  150% 屏上摆 760×560 观感只有 506×373。现在默认尺寸按 `GetDpiForSystem()/96` 放大，
  字号同步走 `tk scaling`。用户已有的 `geometry` 配置仍然优先，不会被强行改大。
- **spawn 失败不再"假成功"**：窗口每秒写一个心跳文件，`windowAlive()` 除了 pid 还会看它 ——
  pid 被复用、进程活着但界面卡死、或是一张全透明的空窗，都会判死，于是下次能重开。
  `--force` 现在真的会先收掉旧进程（原来会叠两个窗）。没有心跳文件的旧窗口不误杀。

### Changed — 安装方式规范化（#3）

README 的主路径改成 `dsh plugin --profile web add dsh-see-now`（DSH 自带的 profile 级 pnpm
包装器，装前预检 engines/peer、装后自动登记 `dsh.bundle`），`install-dev.mjs` 收进
"从源码装（改代码时用）"折叠块。

## [0.0.5] - 2026-11-02

`examples/floating-chat/window.py` 同步上游 `dsh-watch-together` **0.2.4**（生成产物，
`npm run sync:window` 自动更新）。0.0.4 带出去的那份窗口有两个问题，这个版本一起修掉：

### Fixed — 气泡里的字一直黑白闪

字色是按背景亮度选的（气泡透明，背后就是桌面/视频）。原来每 0.12 秒按
`p50 < 0.50` 硬切白/深两色，画面一动亮度就在阈值附近来回穿，字一秒能翻七八次。
现在改成**滞回**（白的暗到 0.38 才翻深、深的亮到 0.62 才翻白）+ **连续两次同向才切**，
同样 16 次抖动从翻 15 次降到 0 次。顶部细条同样处理。

### Changed — 玻璃合成与气泡布局（上游 PR #28）

- 小框（气泡/输入框）边缘改用 blur 1.45 的帧做 smoothstep 过渡，不再二值硬切。
- CPU 管线补齐外缘 R/B 色散与上一帧运动混合（原来只有 GPU 有）；移动帧跳过色散，
  拖动/滚动响应更快。
- 消息气泡改成按正文实测的自适应宽高，时间戳移到气泡上方不再占框内空间。
- 麦克风回到玻璃帧合成（`MIC_POS`），不再在 Canvas 上单独建图。

## [0.0.4] - 2026-11-02

> 主题两件：**协议换成 Apache-2.0**，以及**常驻循环学会自己收工**。

### License — 改成 Apache-2.0

- `PolyForm-Noncommercial-1.0.0` → **`Apache-2.0`**。个人、公司内部、闭源产品、SaaS、
  二次分发都不需要授权、不收费，保留 `LICENSE` 与 `NOTICE` 即可。
- **删掉 `CLA.md` 与 `COMMERCIAL.md`**：Apache-2.0 下不需要贡献者签 CLA，
  也没有"商业授权"这回事了。`package.json` 的 `files` 同步移除这两个文件。
- `NOTICE` 重写：标准 Apache 声明 + 保留原来那份"这个项目**不做什么**"（不上传屏幕、
  不连续录制、不内置采集驱动、不内置 TTS 引擎）。
- `README` 的「授权说明」与「协议」两节、`CONTRIBUTING.md` 第一节、PR 模板里的 CLA 勾选项
  全部同步；`examples/floating-chat/` 不再需要"单独 Apache"的例外说明 —— 整个包同一个协议。
- README 挂上**赞赏码**（`docs/images/reward-qr.png`）：纯自愿，**不解锁任何功能**，
  也不影响以后的授权方式。

### Fixed — 常驻循环不再"卡读图循环"

社区实报：装上之后会话会一轮一轮读图，用户什么都没问也不停。根因是常驻循环
**只有"采集停了"一个退出条件** —— 屏幕一直在动（放视频、刷网页）就会每 `wakeMinGapSec`
叫醒模型一次、模型看一眼图回一句、下一张再叫一次，永远不停，而且每次都是一轮模型调用。

- 新增 `shouldGoIdle()`，两条收工线互为兜底：
  - `IDLE_STOP_MS`（3 分钟）：**没开悬浮窗**且用户超过 3 分钟没说话 → 停。
    悬浮窗开着就不按这条判 —— 那是陪看场景，两小时的电影中途不说话是正常的。
  - `MAX_AUTONOMOUS_WAKES`（8 次）：连续自动唤醒都没人搭理 → 停，窗开着也算
    （防"窗开着但人走了"）。
  - 用户一说话，计数与时间戳都重置。
- 收工不是"突然哑掉"：会在窗口里留一行灰字（`（有一阵没人说话了，我先停一停；要看再说一声。）`），
  且不朗读。
- `test/idle.test.mjs` 三条用例钉住：上限到就停、没窗+久不说话就停、窗开着不按时间判。

### Changed — 悬浮窗同步到 `dsh-watch-together` 0.2.3

`examples/floating-chat/window.py` 是**生成产物**（`npm run sync:window` / `prepack` 自动同步），
这次带上游 0.2.3 的一整轮窗口修复：

- 气泡改成「时间头 + 两行正文」，88px 统一高度，超长按框高折行/截断，标点不落行首。
- 折叠不再重建整窗几何（原来会在 `rounded_mask` 抛 `y1 must be >= y0`）；折叠不跳回原位、
  折叠背景有圆角、配置存展开高度。
- 每 1.8 秒重新置顶一次，DSH 抢焦点后浮窗不再被压下去。
- 拖动/缩放越界钳位，抓屏前挡掉非正尺寸（`Region has zero or negative size` 每帧刷日志、
  背景永久花不了）。
- snapshot 模式不再被 `_tick` 重新打开 WDA；`window` 接口 hide/show 兼容只返回布尔的实现。
- 麦克风改 Canvas 矢量图标，不再往合成帧上贴第二层。

### Fixed — 版本号漂移

`dsh.plugin.json` 还写着 `0.0.2`，与 `package.json` 的 `0.0.3` 不一致。这次一起对齐到 `0.0.4`
（宿主按 `dsh.plugin.json` 认版本，漂着会让"装了新版但页面显示旧版"）。

## [0.0.3] - 2026-11-01

首个公开版本：让 AI 实时看见屏幕 —— 按画面变化量筛帧、拼成一张图推进会话。
