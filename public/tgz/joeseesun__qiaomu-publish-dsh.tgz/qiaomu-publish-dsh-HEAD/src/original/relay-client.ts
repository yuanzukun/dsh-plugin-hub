import { requestUrl, type RequestUrlParam } from '../harness-ui.ts';
import { normalizeBridgeUrl, type WechatAccount, type WechatDraftRequest, type WechatDraftResult } from "./bridge-client";
import type { WechatTransport } from "./transport";
import { QIAOMU_RELAY_EGRESS_IP, QIAOMU_RELAY_URL } from "./defaults";

export function knownRelayEgressIps(relayUrl: string): string[] {
  try { return normalizeBridgeUrl(relayUrl) === QIAOMU_RELAY_URL ? [QIAOMU_RELAY_EGRESS_IP] : []; }
  catch { return []; }
}

export async function relayEgressIps(relayUrl: string): Promise<string[]> {
  const baseUrl = normalizeBridgeUrl(relayUrl);
  if (!baseUrl) throw new Error("请填写中转地址");
  let response;
  try { response = await requestUrl({ url: `${baseUrl}/v2/egress-ip`, throw: false }); }
  catch (error) {
    const known = knownRelayEgressIps(baseUrl);
    if (known.length) return known;
    throw error;
  }
  if (response.status !== 200) {
    const known = knownRelayEgressIps(baseUrl);
    if (known.length) return known;
  }
  if (response.status === 503) throw new Error("乔木中转尚未开放，请稍后再试");
  if (response.status !== 200) throw new Error(`无法读取中转出口 IP（HTTP ${response.status}）`);
  const payload = response.json as { ips?: unknown };
  return Array.isArray(payload?.ips) ? payload.ips.filter((ip): ip is string => typeof ip === "string") : [];
}

/** An account uses the Qiaomu relay for every WeChat API call. */
export class WechatRelayClient implements WechatTransport {
  private readonly baseUrl: string;
  constructor(private readonly account: WechatAccount, private readonly appId: string, private readonly appSecret: string, private readonly inviteKey: string, relayUrl: string) {
    this.baseUrl = normalizeBridgeUrl(relayUrl);
    if (!this.baseUrl || !appId || !appSecret || !inviteKey) throw new Error("请填写中转地址、AppID 和 AppSecret");
  }

  private async call<T>(path: string, init: Omit<RequestUrlParam, "url"> = {}): Promise<T> {
    const response = await requestUrl({ ...init, url: `${this.baseUrl}${path}`, headers: {
      Authorization: `Bearer ${this.inviteKey}`,
      "X-Qiaomu-Appid": this.appId,
      "X-Qiaomu-Appsecret": this.appSecret,
      ...(init.headers ?? {}),
    }, throw: false });
    let payload: { error?: unknown; code?: unknown } | null = null;
    try {
      const json: unknown = response.json;
      if (json && typeof json === "object") payload = json as { error?: unknown; code?: unknown };
    } catch { /* A proxy can return an HTML error page; retain the HTTP diagnosis. */ }
    if (response.status < 200 || response.status >= 300) {
      const message = typeof payload?.error === "string" ? payload.error : `中转 HTTP ${response.status}`;
      if (response.status === 503) throw new Error("中转服务尚未配置完成或暂时不可用，请联系维护者；无需更换 AppID 或 AppSecret。");
      if (response.status === 401) throw new Error("中转未授权此连接，请联系中转服务维护者；此错误尚未验证 AppSecret。");
      if (response.status === 404) throw new Error("中转服务版本过旧或地址不匹配，缺少所需接口。请联系维护者更新服务。");
      if (response.status === 429) throw new Error(/过于频繁/.test(message) ? "请求过于频繁，请稍后再试。" : "今日中转请求额度已用完，请明天再试。");
      if (/errcode=40164/.test(message)) throw new Error("微信拒绝此中转服务器的出口 IP。请把上方显示的固定公网 IP 加入公众号 API 白名单。");
      if (/errcode=(40013|40125)/.test(message)) throw new Error("公众号 AppID 或 AppSecret 无效，请检查后重试。");
      if (/errcode=48001/.test(message)) throw new Error("此公众号没有调用该微信接口的权限，请在公众号后台检查接口权限。");
      const safeMessage = [this.appSecret, this.appId, this.inviteKey].reduce((text, value) => text.split(value).join("[已隐藏]"), message);
      throw new Error(safeMessage);
    }
    return payload as T;
  }

  async getEgressIps(): Promise<string[]> {
    return relayEgressIps(this.baseUrl);
  }

  async testConnection(): Promise<string[]> {
    const ips = await this.getEgressIps();
    await this.call("/v2/wechat/check");
    return ips;
  }

  async listAccounts(): Promise<WechatAccount[]> { return [this.account]; }

  async uploadImage(accountId: string, kind: "content" | "cover", fileName: string, contentType: string, data: ArrayBuffer): Promise<{ url?: string; media_id?: string }> {
    if (accountId !== this.account.id) throw new Error("公众号不匹配");
    const query = new URLSearchParams({ kind, filename: fileName });
    return this.call(`/v2/wechat/images?${query}`, { method: "POST", contentType, body: data });
  }

  async createDraft(body: WechatDraftRequest): Promise<WechatDraftResult> {
    if (body.account_id !== this.account.id || body.publish_now !== false) throw new Error("只允许为当前公众号创建草稿");
    const result = await this.call<{ media_id?: string }>("/v2/wechat/draft", { method: "POST", contentType: "application/json", body: JSON.stringify({ ...body, publish_now: false }) });
    if (!result.media_id) throw new Error("中转没有返回草稿 ID");
    return { media_id: result.media_id, account: this.account };
  }

  async getDraft(accountId: string, mediaId: string): Promise<{ title: string }> {
    if (accountId !== this.account.id) throw new Error("公众号不匹配");
    return this.call<{ title: string }>("/v2/wechat/draft/get", { method: "POST", contentType: "application/json", body: JSON.stringify({ media_id: mediaId }) });
  }

  async updateDraft(mediaId: string, body: WechatDraftRequest): Promise<WechatDraftResult> {
    if (body.account_id !== this.account.id || body.publish_now !== false) throw new Error("只允许更新当前公众号的草稿");
    const result = await this.call<{ media_id?: string }>("/v2/wechat/draft", { method: "POST", contentType: "application/json", body: JSON.stringify({ ...body, existing_media_id: mediaId, publish_now: false }) });
    if (result.media_id !== mediaId) throw new Error("中转更新草稿返回了不匹配的 ID");
    return { media_id: mediaId, account: this.account };
  }
}
