import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { describe, it } from 'node:test'
import { Context } from '@deepseek-ai/cordis'
import LlmRuntime, {
  createUserMessage,
  type GenerateOptions,
  type StreamChunk,
} from '@deepseek-ai/dsh-llm'
import WebServer from '@deepseek-ai/dsh-host-webserver'
import { SessionId } from '@deepseek-ai/dsh-session'
import { JSDOM } from 'jsdom'
import { analyzeInput, diagnosePrefix, stableJson } from '../src/analysis.ts'
import * as CacheScopePlugin from '../src/index.ts'
import { renderDashboardPage } from '../src/page.ts'
import type { DiagnosticsConfig } from '../src/types.ts'
import { normalizeUsage } from '../src/types.ts'

const CONFIG: DiagnosticsConfig = {
  captureInput: 'full',
  maxAttempts: 20,
  rawRetentionAttempts: 1,
  maxRawInputBytes: 100_000,
  refreshMs: 1000,
  logAttempts: false,
  includeAuxiliary: true,
  dashboard: false,
}

describe('installable bundle', () => {
  it('builds its exported entry point when installed from Git', async () => {
    const manifest = JSON.parse(
      await readFile(new URL('../package.json', import.meta.url), 'utf8'),
    ) as {
      exports?: { '.'?: { default?: string } }
      scripts?: Record<string, string>
    }

    assert.equal(manifest.exports?.['.']?.default, './lib/index.js')
    assert.equal(manifest.scripts?.prepare, 'npm run build')
  })

  it('captures bounded complete inputs across all model-call purposes', async () => {
    const patch = await readFile(new URL('../cordis.patch.yml', import.meta.url), 'utf8')

    assert.equal(patch, `- insert:
    - id: cachescope
      name: '@kober-basket/dsh-cachescope'
      config:
        captureInput: full
`)
  })
})

function message(text: string) {
  return createUserMessage({ content: [{ type: 'text', text }], source: { kind: 'user' } })
}

function request(overrides: Partial<GenerateOptions> = {}): GenerateOptions {
  return {
    provider: 'test-provider',
    model: 'test-model',
    sessionId: SessionId('session-test'),
    system: 'stable system',
    tools: [{ name: 'echo', description: 'Echo text', parameters: { type: 'object' } }],
    messages: [message('first')],
    ...overrides,
  }
}

async function setup(overrides: Partial<DiagnosticsConfig> = {}): Promise<Context> {
  const ctx = new Context()
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(CacheScopePlugin, { ...CONFIG, ...overrides })
  return ctx
}

function dispatch(
  ctx: Context,
  options: GenerateOptions,
  source: () => AsyncIterable<StreamChunk>,
): AsyncIterable<StreamChunk> {
  return ctx.waterfall(ctx.llm, 'llm/stream', options, source)
}

const DASHBOARD_RAW_INPUT = {
  provider: 'test-provider',
  model: 'test-model',
  messages: [
    { role: 'user', content: [{ type: 'text', text: 'first' }] },
    { role: 'assistant', content: [{ type: 'text', text: 'second' }] },
  ],
  system: 'stable system',
  tools: [{ name: 'echo', description: 'Echo text', parameters: { type: 'object' } }],
  options: { reasoningEffort: 'high', temperature: 0 },
  untrusted: '<img src=x onerror=alert(1)>',
}

const DASHBOARD_SNAPSHOT = {
  generatedAt: Date.now(),
  captureInput: 'full',
  includeAuxiliary: true,
  notes: {
    cacheEvidence: 'Cache evidence',
    prefixEvidence: 'Prefix evidence',
    timingEvidence: 'Timing evidence',
  },
  summary: {
    attemptCount: 1,
    reportedCacheAttempts: 1,
    inputTokens: 20,
    outputTokens: 2,
    cacheReadTokens: 80,
    cacheWriteTokens: 0,
    promptTokens: 100,
    cacheReadRatio: 0.8,
    medianFirstTokenMs: 42,
    p95FirstTokenMs: 42,
  },
  attempts: [{
    id: 'call-1',
    sequence: 1,
    startedAt: Date.now(),
    sessionId: 'session-test',
    purpose: 'conversation',
    provider: 'test-provider',
    model: 'test-model',
    status: 'completed',
    finishKind: 'stop',
    firstTokenMs: 42,
    durationMs: 57,
    usage: {
      inputTokens: 20,
      outputTokens: 2,
      cacheReadTokens: 80,
      cacheWriteTokens: 0,
      promptTokens: 100,
      cacheReadRatio: 0.8,
      cacheState: 'read-reported',
    },
    diagnosis: {
      kind: 'append-only',
      comparedTo: 'call-0',
      previousToolCount: 1,
      previousMessageCount: 1,
      configStable: true,
      systemStable: true,
      stableToolCount: 1,
      stableMessageCount: 1,
    },
    input: {
      messageCount: 2,
      toolCount: 1,
      systemBytes: 13,
      toolsBytes: 34,
      messagesBytes: 55,
      totalBytes: 102,
      overallFingerprint: '0123456789abcdef0123456789abcdef',
    },
    rawState: 'available',
  }],
}

async function renderTestDashboard(
  snapshot: typeof DASHBOARD_SNAPSHOT = DASHBOARD_SNAPSHOT,
  rawInput: typeof DASHBOARD_RAW_INPUT = DASHBOARD_RAW_INPUT,
): Promise<{
  dom: JSDOM
  poll: () => unknown
  requests: string[]
}> {
  let poll: (() => unknown) | undefined
  const requests: string[] = []
  const dom = new JSDOM(renderDashboardPage('test-nonce', 1000), {
    runScripts: 'dangerously',
    url: 'http://127.0.0.1/cachescope',
    beforeParse(window) {
      Object.defineProperty(window, 'fetch', {
        configurable: true,
        value: async (input: unknown) => {
          const url = String(input)
          requests.push(url)
          return {
            ok: true,
            json: async () => url.startsWith('/cachescope/api/input')
              ? {
                  id: 'call-1',
                  rawState: 'available',
                  overallFingerprint: '0123456789abcdef0123456789abcdef',
                  rawInput,
                }
              : snapshot,
          }
        },
      })
      Object.defineProperty(window, 'setInterval', {
        configurable: true,
        value: (callback: unknown) => {
          assert.equal(typeof callback, 'function')
          poll = callback as () => unknown
          return 1
        },
      })
    },
  })
  for (let attempt = 0; attempt < 10 && !dom.window.document.querySelector('[data-json-tree]'); attempt++) {
    await new Promise<void>(resolve => setImmediate(resolve))
  }
  assert.ok(dom.window.document.querySelector('tbody tr'))
  assert.ok(dom.window.document.querySelector('[data-json-tree]'))
  assert.ok(poll)
  return { dom, poll, requests }
}

describe('CacheScope input analysis', () => {
  it('fingerprints JSON-compatible optional fields without dropping the attempt', () => {
    const sparse = Array.from({ length: 3 })
    sparse[0] = 'kept'

    assert.equal(
      stableJson({ z: undefined, a: sparse, b: Number.NaN, c: () => 'ignored' }),
      '{"a":["kept",null,null],"b":null}',
    )
    assert.equal(stableJson({ b: 1, a: 2 }), '{"a":2,"b":1}')
    assert.throws(() => stableJson(1n), /unsupported input value: bigint/)
  })

  it('separates provider usage field absence from a reported zero', () => {
    const absent = normalizeUsage({ inputTokens: 10, outputTokens: 2 })
    const zero = normalizeUsage({ inputTokens: 10, outputTokens: 2, cacheReadTokens: 0 })
    assert.equal(absent.cacheState, 'no-read-reported')
    assert.equal(absent.cacheReadRatio, undefined)
    assert.equal(zero.cacheState, 'read-reported')
    assert.equal(zero.cacheReadRatio, 0)
  })

  it('distinguishes append-only context from changed stable prefix segments', () => {
    const first = analyzeInput(request(), false, 100_000)
    const identical = analyzeInput(request({ messages: [message('first')] }), false, 100_000)
    const appended = analyzeInput(request({ messages: [message('first'), message('second')] }), false, 100_000)
    const rewritten = analyzeInput(request({ messages: [message('changed')] }), false, 100_000)
    const changedSystem = analyzeInput(request({ system: 'changed system' }), false, 100_000)
    const changedTools = analyzeInput(request({ tools: [] }), false, 100_000)
    const baseline = { id: 'call-1', analysis: first }

    assert.equal(diagnosePrefix(identical, baseline).kind, 'identical-input')
    assert.equal(diagnosePrefix(appended, baseline).kind, 'append-only')
    assert.equal(diagnosePrefix(rewritten, baseline).kind, 'history-rewritten')
    assert.equal(diagnosePrefix(changedSystem, baseline).kind, 'system-changed')
    assert.equal(diagnosePrefix(changedTools, baseline).kind, 'tools-changed')
  })

  it('refuses a complete input above the configured per-request byte cap', () => {
    const analysis = analyzeInput(request({ system: 'x'.repeat(5000) }), true, 1024)
    assert.equal(analysis.rawState, 'too-large')
    assert.equal(analysis.rawInput, undefined)
  })
})

describe('dashboard interactions', () => {
  it('explains provider misses as cache-bucket evolution instead of logical input change', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const first = snapshot.attempts[0]!
    first.id = 'call-1'
    first.startedAt = 1_000
    first.usage = {
      inputTokens: 802,
      outputTokens: 144,
      cacheReadTokens: 7_680,
      cacheWriteTokens: 0,
      promptTokens: 8_482,
      cacheReadRatio: 7_680 / 8_482,
      cacheState: 'read-reported',
    }
    const second = structuredClone(first)
    second.id = 'call-2'
    second.sequence = 2
    second.startedAt = 2_000
    second.usage = {
      inputTokens: 156,
      outputTokens: 347,
      cacheReadTokens: 8_576,
      cacheWriteTokens: 0,
      promptTokens: 8_732,
      cacheReadRatio: 8_576 / 8_732,
      cacheState: 'read-reported',
    }
    second.diagnosis.comparedTo = 'call-1'
    second.diagnosis.previousMessageCount = 3
    second.diagnosis.stableMessageCount = 3
    second.input.messageCount = 7
    second.input.messagesBytes = 5_248
    second.input.totalBytes = 37_703
    snapshot.attempts.push(second)

    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    await new Promise<void>(resolve => setImmediate(resolve))
    const document = dom.window.document

    assert.equal(document.querySelector('#cacheRatio')?.textContent, '98.2%')
    assert.match(document.querySelector('#cacheRatioNote')?.textContent ?? '', /选中 call-2：Cache Read 8,576 \/ Prompt 8,732 = 98\.2%/)
    assert.equal(document.querySelector('#inputTokens')?.textContent, '156')
    assert.match(document.querySelector('#promptTokens')?.textContent ?? '', /本次 Prompt 8,732 · Cache Read 8,576/)
    assert.match(document.querySelector('#aggregateCacheRatio')?.textContent ?? '', /筛选范围加权：ΣRead 16,256 \/ ΣPrompt 17,214 = 94\.4%/)
    assert.match(document.querySelector('[data-cache-kpi="selected-attempt"]')?.textContent ?? '', /Output Token 不参与/)
    assert.doesNotMatch(document.querySelector('[data-cache-kpi="selected-attempt"]')?.textContent ?? '', /347/)
    assert.match(document.querySelector('#captureMode')?.textContent ?? '', /全部模型调用/)
    const provider = document.querySelector('[data-cache-evidence="normalized-usage"]')
    assert.match(provider?.textContent ?? '', /本次 Provider usage.*98\.2%/)
    const evolution = document.querySelector('[data-cache-evidence="cache-evolution"]')
    assert.ok(evolution)
    assert.match(evolution.textContent ?? '', /802.*250.*896.*156/)
    assert.match(evolution.textContent ?? '', /不是输入变化量/)
    assert.match(document.querySelector('.raw-head h3')?.textContent ?? '', /非 Provider wire payload/)

    document.querySelector<HTMLElement>('tr[data-attempt-id="call-1"]')?.click()
    await new Promise<void>(resolve => setImmediate(resolve))
    assert.equal(document.querySelector('#cacheRatio')?.textContent, '90.5%')
    assert.match(document.querySelector('#cacheRatioNote')?.textContent ?? '', /选中 call-1：Cache Read 7,680 \/ Prompt 8,482 = 90\.5%/)
    assert.match(document.querySelector('#aggregateCacheRatio')?.textContent ?? '', /筛选范围加权：ΣRead 16,256 \/ ΣPrompt 17,214 = 94\.4%/)
  })

  it('includes Cache Write deltas in adjacent-call reconciliation', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const first = snapshot.attempts[0]!
    first.id = 'call-write-1'
    first.startedAt = 1_000
    first.usage = {
      inputTokens: 40,
      outputTokens: 2,
      cacheReadTokens: 50,
      cacheWriteTokens: 10,
      promptTokens: 100,
      cacheReadRatio: 0.5,
      cacheState: 'read-reported',
    }
    const second = structuredClone(first)
    second.id = 'call-write-2'
    second.sequence = 2
    second.startedAt = 2_000
    second.diagnosis.comparedTo = first.id
    second.usage = {
      inputTokens: 20,
      outputTokens: 2,
      cacheReadTokens: 65,
      cacheWriteTokens: 15,
      promptTokens: 100,
      cacheReadRatio: 0.65,
      cacheState: 'read-reported',
    }
    snapshot.attempts.push(second)

    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const evolution = dom.window.document.querySelector('[data-cache-evidence="cache-evolution"]')
    assert.ok(evolution)
    assert.match(evolution.textContent ?? '', /40（上次未缓存） \+ 0（Prompt 变化） − 15（Cache Read 变化） − 5（Cache Write 变化） = 20/)
  })

  it('refuses reconciliation when only one call reports Cache Write', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const first = snapshot.attempts[0]!
    first.id = 'call-write-unknown-1'
    first.startedAt = 1_000
    Reflect.deleteProperty(first.usage!, 'cacheWriteTokens')
    const second = structuredClone(first)
    second.id = 'call-write-unknown-2'
    second.sequence = 2
    second.startedAt = 2_000
    second.diagnosis.comparedTo = first.id
    second.usage!.cacheWriteTokens = 5
    second.usage!.promptTokens += 5
    snapshot.attempts.push(second)

    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const evolution = dom.window.document.querySelector('[data-cache-evidence="cache-evolution"]')
    assert.ok(evolution)
    assert.match(evolution.textContent ?? '', /只有一次调用携带 Cache Write，不能用 0 补齐/)
    assert.doesNotMatch(evolution.textContent ?? '', /（本次未缓存）$/)
  })

  it('does not present route or generation-option changes as one cache evolution', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    snapshot.attempts[0]!.diagnosis.kind = 'route-or-options-changed'
    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })

    const evolution = dom.window.document.querySelector('[data-cache-evidence="cache-evolution"]')
    assert.ok(evolution)
    assert.match(evolution.textContent ?? '', /不把这两次调用作为同一缓存路径演进/)
    assert.doesNotMatch(evolution.textContent ?? '', /=/)
  })

  it('separates normalized usage totals from DSH-inferred input regions', async (t) => {
    const { dom } = await renderTestDashboard()
    t.after(() => { dom.window.close() })
    const document = dom.window.document

    const provider = document.querySelector('[data-cache-evidence="normalized-usage"]')
    assert.ok(provider)
    assert.match(provider.textContent ?? '', /Provider usage Cache Read\s*80/)
    assert.match(provider.textContent ?? '', /适配器归一化未缓存\s*20/)
    assert.ok(provider.querySelector('[data-cache-segment="hit"]'))
    assert.ok(provider.querySelector('[data-cache-segment="miss"]'))
    assert.equal(document.querySelector('#ttft')?.textContent, '42.0 ms / 42.0 ms')
    assert.equal(document.querySelector('#prefixRatio')?.textContent, '100.0%')
    assert.match(document.querySelector('#prefixRatioNote')?.textContent ?? '', /1 \/ 1 次可比较调用/)

    const inference = document.querySelector('[data-cache-evidence="dsh-inferred"]')
    assert.ok(inference)
    assert.match(inference.textContent ?? '', /不是供应商逐字段命中或未命中位置/)

    const expandTwoLevels = document.querySelector<HTMLButtonElement>('[data-json-action="expand-two"]')
    assert.ok(expandTwoLevels)
    expandTwoLevels.click()
    assert.ok(document.querySelector('[data-json-path="$.system"][data-cache-inference="stable"]'))
    assert.ok(document.querySelector('[data-json-path="$.tools[0]"][data-cache-inference="stable"]'))
    assert.ok(document.querySelector('[data-json-path="$.messages[0]"][data-cache-inference="stable"]'))
    assert.ok(document.querySelector('[data-json-path="$.messages[1]"][data-cache-inference="changed"]'))
  })

  it('keeps logical regions unknown without a local comparison even when the provider reports a hit', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const diagnosis = snapshot.attempts[0]!.diagnosis
    diagnosis.kind = 'first-observation'
    diagnosis.stableToolCount = 0
    diagnosis.stableMessageCount = 0
    Reflect.deleteProperty(diagnosis, 'comparedTo')
    Reflect.deleteProperty(diagnosis, 'previousToolCount')
    Reflect.deleteProperty(diagnosis, 'previousMessageCount')
    Reflect.deleteProperty(diagnosis, 'configStable')
    Reflect.deleteProperty(diagnosis, 'systemStable')
    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    const expandTwoLevels = document.querySelector<HTMLButtonElement>('[data-json-action="expand-two"]')
    assert.ok(expandTwoLevels)
    expandTwoLevels.click()

    assert.ok(document.querySelector('[data-json-path="$.system"][data-cache-inference="unknown"]'))
    assert.ok(document.querySelector('[data-json-path="$.tools[0]"][data-cache-inference="unknown"]'))
    assert.ok(document.querySelector('[data-json-path="$.messages[0]"][data-cache-inference="unknown"]'))
    assert.equal(document.querySelector('[data-json-path="$.messages[0]"][data-cache-inference="stable"]'), null)
    assert.match(document.querySelector('[data-cache-evidence="normalized-usage"]')?.textContent ?? '', /Provider usage Cache Read\s*80/)
    const facts = Array.from(document.querySelectorAll('dt'))
    const stableTools = facts.find(node => node.textContent === '稳定 Tools')
    const stableMessages = facts.find(node => node.textContent === '稳定消息')
    assert.equal(stableTools?.nextElementSibling?.textContent, '无法比较')
    assert.equal(stableMessages?.nextElementSibling?.textContent, '无法比较')
  })

  it('shows uncached and write buckets even when normalized usage omits Cache Read', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const usage = snapshot.attempts[0]!.usage!
    Reflect.deleteProperty(usage, 'cacheReadTokens')
    Reflect.deleteProperty(usage, 'cacheReadRatio')
    usage.cacheState = 'no-read-reported'
    usage.inputTokens = 95
    usage.cacheWriteTokens = 5
    usage.promptTokens = 100
    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const evidence = dom.window.document.querySelector('[data-cache-evidence="normalized-usage"]')
    assert.ok(evidence)
    assert.match(evidence.textContent ?? '', /Cache Read 未携带（不视为 0）/)
    assert.match(evidence.textContent ?? '', /适配器归一化未缓存\s*95/)
    assert.match(evidence.textContent ?? '', /Cache Write\s*5/)
    assert.ok(evidence.querySelector('[data-cache-segment="miss"]'))
    assert.ok(evidence.querySelector('[data-cache-segment="write"]'))
    assert.equal(evidence.querySelector('[data-cache-segment="hit"]'), null)
    assert.match(evidence.querySelector('svg')?.getAttribute('aria-label') ?? '', /Cache Write 5 Token/)
  })

  it('distinguishes a changed node from downstream nodes and marks an empty changed Tools collection', async (t) => {
    const systemSnapshot = structuredClone(DASHBOARD_SNAPSHOT)
    systemSnapshot.attempts[0]!.diagnosis.kind = 'system-changed'
    systemSnapshot.attempts[0]!.diagnosis.systemStable = false
    const systemResult = await renderTestDashboard(systemSnapshot)
    t.after(() => { systemResult.dom.window.close() })
    const systemDocument = systemResult.dom.window.document
    systemDocument.querySelector<HTMLButtonElement>('[data-json-action="expand-two"]')?.click()
    assert.ok(systemDocument.querySelector('[data-json-path="$.system"][data-cache-inference="changed"]'))
    assert.ok(systemDocument.querySelector('[data-json-path="$.tools"][data-cache-inference="downstream"]'))
    assert.ok(systemDocument.querySelector('[data-json-path="$.messages[0]"][data-cache-inference="downstream"]'))

    const toolsSnapshot = structuredClone(DASHBOARD_SNAPSHOT)
    toolsSnapshot.attempts[0]!.diagnosis.kind = 'tools-changed'
    toolsSnapshot.attempts[0]!.diagnosis.stableToolCount = 0
    toolsSnapshot.attempts[0]!.input.toolCount = 0
    const toolsInput = { ...DASHBOARD_RAW_INPUT, tools: [] }
    const toolsResult = await renderTestDashboard(toolsSnapshot, toolsInput)
    t.after(() => { toolsResult.dom.window.close() })
    const toolsDocument = toolsResult.dom.window.document
    toolsDocument.querySelector<HTMLButtonElement>('[data-json-action="expand-one"]')?.click()
    assert.ok(toolsDocument.querySelector('[data-json-path="$.tools"][data-cache-inference="changed"]'))
    assert.ok(toolsDocument.querySelector('[data-json-path="$.messages"][data-cache-inference="downstream"]'))
  })

  it('keeps the selected-call ratio primary and recomputes the filtered aggregate', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    snapshot.summary = {
      ...snapshot.summary,
      attemptCount: 2,
      reportedCacheAttempts: 2,
      inputTokens: 120,
      cacheReadTokens: 80,
      promptTokens: 200,
      cacheReadRatio: 0.4,
    }
    snapshot.attempts.push({
      ...structuredClone(snapshot.attempts[0]!),
      id: 'call-title',
      sequence: 2,
      purpose: 'session-title',
      usage: {
        inputTokens: 100,
        outputTokens: 2,
        cacheReadTokens: 0,
        cacheWriteTokens: 0,
        promptTokens: 100,
        cacheReadRatio: 0,
        cacheState: 'read-reported',
      },
    })
    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const document = dom.window.document

    assert.equal(document.querySelector('#purposeFilter')?.getAttribute('data-default-purpose'), 'conversation')
    assert.equal(document.querySelector('#cacheRatio')?.textContent, '80.0%')
    assert.match(document.querySelector('#cacheRatioNote')?.textContent ?? '', /选中 call-1：Cache Read 80 \/ Prompt 100 = 80\.0%/)
    assert.match(document.querySelector('#aggregateCacheRatio')?.textContent ?? '', /筛选范围加权：ΣRead 80 \/ ΣPrompt 100 = 80\.0%/)

    const purpose = document.querySelector<HTMLSelectElement>('#purposeFilter')
    assert.ok(purpose)
    purpose.value = ''
    purpose.dispatchEvent(new dom.window.Event('change', { bubbles: true }))
    assert.equal(document.querySelector('#cacheRatio')?.textContent, '80.0%')
    assert.match(document.querySelector('#aggregateCacheRatio')?.textContent ?? '', /筛选范围加权：ΣRead 80 \/ ΣPrompt 200 = 40\.0%/)

    document.querySelector<HTMLElement>('tr[data-attempt-id="call-title"]')?.click()
    await new Promise<void>(resolve => setImmediate(resolve))
    assert.equal(document.querySelector('#cacheRatio')?.textContent, '0.0%')
    assert.match(document.querySelector('#cacheRatioNote')?.textContent ?? '', /选中 call-title：Cache Read 0 \/ Prompt 100 = 0\.0%/)
    assert.match(document.querySelector('#aggregateCacheRatio')?.textContent ?? '', /筛选范围加权：ΣRead 80 \/ ΣPrompt 200 = 40\.0%/)
  })

  it('cross-tabulates provider Cache Read with comparable local prefix state', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const variants = [
      { id: 'call-2', kind: 'append-only', cacheReadTokens: 0 },
      { id: 'call-3', kind: 'system-changed', cacheReadTokens: 40 },
      { id: 'call-4', kind: 'history-rewritten', cacheReadTokens: 0 },
    ] as const
    for (const variant of variants) {
      const attempt = structuredClone(snapshot.attempts[0]!)
      attempt.id = variant.id
      attempt.sequence = snapshot.attempts.length + 1
      attempt.diagnosis.kind = variant.kind
      attempt.usage!.cacheReadTokens = variant.cacheReadTokens
      attempt.usage!.cacheReadRatio = variant.cacheReadTokens / attempt.usage!.promptTokens
      snapshot.attempts.push(attempt)
    }
    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const document = dom.window.document

    assert.equal(document.querySelector('#friendlyWithRead')?.textContent, '1')
    assert.equal(document.querySelector('#friendlyWithoutRead')?.textContent, '1')
    assert.equal(document.querySelector('#changedWithRead')?.textContent, '1')
    assert.equal(document.querySelector('#changedWithoutRead')?.textContent, '1')
    assert.match(document.querySelector('#correlationNote')?.textContent ?? '', /已交叉 4 次/)
  })

  it('filters attempts by text and evidence combination', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const changed = structuredClone(snapshot.attempts[0]!)
    changed.id = 'call-needle'
    changed.sequence = 2
    changed.provider = 'alternate-provider'
    changed.diagnosis.kind = 'system-changed'
    changed.usage!.cacheReadTokens = 0
    changed.usage!.cacheReadRatio = 0
    snapshot.attempts.push(changed)
    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    const query = document.querySelector<HTMLInputElement>('#queryFilter')
    const evidence = document.querySelector<HTMLSelectElement>('#evidenceFilter')
    assert.ok(query)
    assert.ok(evidence)

    query.value = 'alternate-provider'
    query.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
    await new Promise<void>(resolve => setImmediate(resolve))
    assert.equal(document.querySelectorAll('tbody tr').length, 1)
    assert.equal(document.querySelector('tbody tr')?.getAttribute('data-attempt-id'), 'call-needle')

    query.value = ''
    query.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
    evidence.value = 'friendly-read'
    evidence.dispatchEvent(new dom.window.Event('change', { bubbles: true }))
    await new Promise<void>(resolve => setImmediate(resolve))
    assert.equal(document.querySelectorAll('tbody tr').length, 1)
    assert.equal(document.querySelector('tbody tr')?.getAttribute('data-attempt-id'), 'call-1')
    assert.match(document.querySelector('#countText')?.textContent ?? '', /1 \/ 2 条记录/)
  })

  it('filters attempts by lifecycle status', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const failed = structuredClone(snapshot.attempts[0]!)
    failed.id = 'call-failed'
    failed.sequence = 2
    failed.status = 'failed'
    snapshot.attempts.push(failed)
    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    const status = document.querySelector<HTMLSelectElement>('#statusFilter')
    assert.ok(status)

    status.value = 'failed'
    status.dispatchEvent(new dom.window.Event('change', { bubbles: true }))
    await new Promise<void>(resolve => setImmediate(resolve))
    assert.equal(document.querySelectorAll('tbody tr').length, 1)
    assert.equal(document.querySelector('tbody tr')?.getAttribute('data-attempt-id'), 'call-failed')
    assert.match(document.querySelector('#countText')?.textContent ?? '', /1 \/ 2 条记录/)
  })

  it('filters attempts by provider and model route', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const alternate = structuredClone(snapshot.attempts[0]!)
    alternate.id = 'call-alternate-route'
    alternate.sequence = 2
    alternate.provider = 'alternate-provider'
    alternate.model = 'alternate-model'
    snapshot.attempts.push(alternate)
    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    const provider = document.querySelector<HTMLSelectElement>('#providerFilter')
    const model = document.querySelector<HTMLSelectElement>('#modelFilter')
    assert.ok(provider)
    assert.ok(model)
    assert.deepEqual(Array.from(provider.options, option => option.value), ['', 'test-provider', 'alternate-provider'])
    assert.deepEqual(Array.from(model.options, option => option.value), ['', 'test-model', 'alternate-model'])

    provider.value = 'alternate-provider'
    provider.dispatchEvent(new dom.window.Event('change', { bubbles: true }))
    model.value = 'alternate-model'
    model.dispatchEvent(new dom.window.Event('change', { bubbles: true }))
    await new Promise<void>(resolve => setImmediate(resolve))
    assert.equal(document.querySelectorAll('tbody tr').length, 1)
    assert.equal(document.querySelector('tbody tr')?.getAttribute('data-attempt-id'), 'call-alternate-route')
    assert.match(document.querySelector('#countText')?.textContent ?? '', /1 \/ 2 条记录/)
  })

  it('sorts attempts by time, cache-read ratio, and Call TTFT', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const baseStartedAt = snapshot.attempts[0]!.startedAt
    const lowCacheSlow = structuredClone(snapshot.attempts[0]!)
    lowCacheSlow.id = 'call-low-cache-slow'
    lowCacheSlow.sequence = 2
    lowCacheSlow.startedAt = baseStartedAt - 1_000
    lowCacheSlow.firstTokenMs = 300
    lowCacheSlow.usage!.cacheReadRatio = 0.1
    const highCacheFast = structuredClone(snapshot.attempts[0]!)
    highCacheFast.id = 'call-high-cache-fast'
    highCacheFast.sequence = 3
    highCacheFast.startedAt = baseStartedAt + 1_000
    highCacheFast.firstTokenMs = 10
    highCacheFast.usage!.cacheReadRatio = 0.95
    snapshot.attempts.push(lowCacheSlow, highCacheFast)
    const { dom } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    const sort = document.querySelector<HTMLSelectElement>('#sortOrder')
    assert.ok(sort)
    const rowIds = (): (string | null)[] => Array.from(document.querySelectorAll('tbody tr'), row => row.getAttribute('data-attempt-id'))

    assert.deepEqual(rowIds(), ['call-high-cache-fast', 'call-1', 'call-low-cache-slow'])
    sort.value = 'oldest'
    sort.dispatchEvent(new dom.window.Event('change', { bubbles: true }))
    assert.deepEqual(rowIds(), ['call-low-cache-slow', 'call-1', 'call-high-cache-fast'])
    sort.value = 'cache-desc'
    sort.dispatchEvent(new dom.window.Event('change', { bubbles: true }))
    assert.deepEqual(rowIds(), ['call-high-cache-fast', 'call-1', 'call-low-cache-slow'])
    sort.value = 'ttft-desc'
    sort.dispatchEvent(new dom.window.Event('change', { bubbles: true }))
    assert.deepEqual(rowIds(), ['call-low-cache-slow', 'call-1', 'call-high-cache-fast'])
  })

  it('renders complete input as a lazily disclosed JSON hierarchy', async (t) => {
    const { dom } = await renderTestDashboard()
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    const row = document.querySelector('tbody tr')
    assert.ok(row)
    row.dispatchEvent(new dom.window.MouseEvent('click', { bubbles: true }))

    const tree = document.querySelector('[data-json-tree]')
    assert.ok(tree)
    assert.equal(document.querySelector('#detailBody pre'), null)
    assert.equal(tree.querySelector('img'), null)
    assert.match(tree.textContent ?? '', /<img src=x onerror=alert\(1\)>/)
    const root = tree.querySelector('details[data-json-depth="0"]')
    assert.ok(root)
    assert.equal(root.hasAttribute('open'), true)
    const messages = tree.querySelector('details[data-json-path="$.messages"]')
    assert.ok(messages)
    assert.equal(messages.hasAttribute('open'), false)
    assert.equal(tree.querySelector('details[data-json-path="$.messages[0]"]'), null)

    const expandTwoLevels = document.querySelector<HTMLButtonElement>('[data-json-action="expand-two"]')
    assert.ok(expandTwoLevels)
    expandTwoLevels.click()
    assert.equal(messages.hasAttribute('open'), true)
    assert.ok(tree.querySelector('details[data-json-path="$.messages[0]"]'))

    const collapseAll = document.querySelector<HTMLButtonElement>('[data-json-action="collapse"]')
    assert.ok(collapseAll)
    collapseAll.click()
    assert.equal(root.hasAttribute('open'), false)
    assert.equal(messages.hasAttribute('open'), false)
  })

  it('uses one disclosure column and keeps the raw-input heading intact', async (t) => {
    const { dom } = await renderTestDashboard()
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    const leaf = document.querySelector<HTMLElement>('details[data-json-depth="0"] > .json-children > .json-leaf')
    const branchSummary = document.querySelector<HTMLElement>('details[data-json-path="$.messages"] > summary')
    const rawHead = document.querySelector<HTMLElement>('.raw-head')
    const heading = document.querySelector<HTMLElement>('.raw-head h3')
    assert.ok(leaf)
    assert.ok(branchSummary)
    assert.ok(rawHead)
    assert.ok(heading)

    const rules = Array.from(document.styleSheets[0]?.cssRules ?? [])
    const ruleStyle = (selector: string): CSSStyleDeclaration => {
      const rule = rules.find(candidate => 'selectorText' in candidate && candidate.selectorText === selector)
      assert.ok(rule && 'style' in rule)
      return rule.style as CSSStyleDeclaration
    }
    const leafStyle = ruleStyle('.json-leaf')
    const summaryStyle = ruleStyle('.json-tree summary')
    assert.equal(summaryStyle.display, 'grid')
    assert.equal(summaryStyle.gridTemplateColumns.split(' ')[0], leafStyle.gridTemplateColumns.split(' ')[0])
    assert.ok(branchSummary.querySelector(':scope > .json-summary-line'))
    assert.equal(ruleStyle('.raw-head').flexWrap, 'wrap')
    assert.equal(ruleStyle('.raw-head h3').whiteSpace, 'nowrap')
  })

  it('preserves the selected detail DOM when a poll returns unchanged input', async (t) => {
    const { dom, poll } = await renderTestDashboard()
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    const row = document.querySelector('tbody tr')
    assert.ok(row)
    row.dispatchEvent(new dom.window.MouseEvent('click', { bubbles: true }))
    const detail = document.querySelector('#detailBody')
    assert.ok(detail)
    const renderedTitle = detail.firstElementChild
    assert.ok(renderedTitle)

    await poll()

    assert.equal(detail.firstElementChild, renderedTitle)
  })

  it('follows the newest attempt during polling until the user pins a row', async (t) => {
    const snapshot = structuredClone(DASHBOARD_SNAPSHOT)
    const { dom, poll } = await renderTestDashboard(snapshot)
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    assert.equal(document.querySelector('tr.selected')?.getAttribute('data-attempt-id'), 'call-1')
    const sort = document.querySelector<HTMLSelectElement>('#sortOrder')
    assert.ok(sort)
    sort.value = 'oldest'
    sort.dispatchEvent(new dom.window.Event('change', { bubbles: true }))

    const second = structuredClone(snapshot.attempts[0]!)
    second.id = 'call-2'
    second.sequence = 2
    second.startedAt -= 1_000
    second.rawState = 'evicted'
    second.usage = {
      inputTokens: 10,
      outputTokens: 3,
      cacheReadTokens: 90,
      cacheWriteTokens: 0,
      promptTokens: 100,
      cacheReadRatio: 0.9,
      cacheState: 'read-reported',
    }
    snapshot.attempts.push(second)
    await poll()
    await new Promise<void>(resolve => setImmediate(resolve))

    assert.equal(document.querySelector('tr.selected')?.getAttribute('data-attempt-id'), 'call-2')
    assert.equal(document.querySelector('#cacheRatio')?.textContent, '90.0%')

    document.querySelector<HTMLElement>('tr[data-attempt-id="call-1"]')?.click()
    await new Promise<void>(resolve => setImmediate(resolve))
    const third = structuredClone(second)
    third.id = 'call-3'
    third.sequence = 3
    third.startedAt -= 1_000
    third.usage = {
      ...third.usage,
      inputTokens: 5,
      cacheReadTokens: 95,
      cacheReadRatio: 0.95,
    }
    snapshot.attempts.push(third)
    await poll()
    await new Promise<void>(resolve => setImmediate(resolve))

    assert.equal(document.querySelector('tr.selected')?.getAttribute('data-attempt-id'), 'call-1')
    assert.equal(document.querySelector('#cacheRatio')?.textContent, '80.0%')
  })

  it('loads only the selected complete input and does not refetch it during polling', async (t) => {
    const { dom, poll, requests } = await renderTestDashboard()
    t.after(() => { dom.window.close() })
    assert.equal(requests.filter(url => url === '/cachescope/api').length, 1)
    assert.equal(requests.filter(url => url.startsWith('/cachescope/api/input')).length, 1)

    await poll()

    assert.equal(requests.filter(url => url === '/cachescope/api').length, 2)
    assert.equal(requests.filter(url => url.startsWith('/cachescope/api/input')).length, 1)
  })

  it('pauses scheduled polling while keeping manual refresh available', async (t) => {
    const { dom, poll, requests } = await renderTestDashboard()
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    const toggle = document.querySelector<HTMLButtonElement>('#togglePolling')
    const refresh = document.querySelector<HTMLButtonElement>('#refreshNow')
    assert.ok(toggle)
    assert.ok(refresh)

    toggle.click()
    assert.equal(toggle.getAttribute('aria-pressed'), 'true')
    await poll()
    await new Promise<void>(resolve => setImmediate(resolve))
    assert.equal(requests.filter(url => url === '/cachescope/api').length, 1)

    refresh.click()
    await new Promise<void>(resolve => setImmediate(resolve))
    assert.equal(requests.filter(url => url === '/cachescope/api').length, 2)
    assert.match(document.querySelector('#liveState')?.textContent ?? '', /^已暂停/)

    toggle.click()
    await new Promise<void>(resolve => setImmediate(resolve))
    assert.equal(toggle.getAttribute('aria-pressed'), 'false')
    assert.equal(requests.filter(url => url === '/cachescope/api').length, 3)
  })

  it('copies filtered diagnostic metadata without complete prompt content', async (t) => {
    const { dom } = await renderTestDashboard()
    t.after(() => { dom.window.close() })
    let copied = ''
    Object.defineProperty(dom.window.navigator, 'clipboard', {
      configurable: true,
      value: { writeText: async (value: string) => { copied = value } },
    })

    const button = dom.window.document.querySelector<HTMLButtonElement>('#copyDiagnostics')
    assert.ok(button)
    button.click()
    await new Promise<void>(resolve => setImmediate(resolve))

    const payload = JSON.parse(copied) as {
      filter: string
      scope: { kind: string, includeAuxiliary: boolean, filteredAttemptCount: number }
      summary: { attemptCount: number, firstTokens?: unknown, cacheReadEligiblePromptTokens: number }
      attempts: Array<{ id: string, rawInput?: unknown }>
    }
    assert.equal(payload.filter, '对话')
    assert.deepEqual(payload.scope, {
      kind: 'process-local-retained-attempts',
      captureInput: 'full',
      includeAuxiliary: true,
      retainedAttemptCount: 1,
      filteredAttemptCount: 1,
    })
    assert.equal(payload.summary.attemptCount, 1)
    assert.equal(payload.summary.cacheReadEligiblePromptTokens, 100)
    assert.equal(payload.summary.firstTokens, undefined)
    assert.equal(payload.attempts[0]?.id, 'call-1')
    assert.equal(payload.attempts[0]?.rawInput, undefined)
    assert.match(
      dom.window.document.querySelector('#copyDiagnosticsStatus')?.textContent ?? '',
      /不包含完整输入正文/,
    )
  })

  it('keeps keyboard focus on the keyed attempt row across selection and polling', async (t) => {
    const { dom, poll } = await renderTestDashboard()
    t.after(() => { dom.window.close() })
    const document = dom.window.document
    const row = document.querySelector<HTMLElement>('tbody tr')
    assert.ok(row)
    row.focus()
    row.dispatchEvent(new dom.window.KeyboardEvent('keydown', { bubbles: true, key: 'Enter' }))
    assert.equal(document.activeElement, row)

    await poll()

    assert.equal(document.querySelector('tbody tr'), row)
    assert.equal(document.activeElement, row)
  })
})

describe('llm/stream observation', () => {
  it('recognizes the AgentLoop identity shared by a newer DSH package copy', async (t) => {
    const ctx = await setup()
    t.after(async () => { await ctx.root.fiber.dispose() })
    const input = request()
    const markerKey = Symbol.for('@deepseek-ai/dsh-llm/agent-loop-requests/v1')
    const markerGlobal = globalThis as unknown as Record<symbol, WeakSet<object> | undefined>
    const registry = markerGlobal[markerKey] ??= new WeakSet<object>()
    registry.add(input)

    const stream = dispatch(ctx, input, () => (async function*() {
      yield { type: 'usage', usage: { inputTokens: 20, outputTokens: 1, cacheReadTokens: 80 } } as const
      yield { type: 'finish', reason: { kind: 'stop' } } as const
    })())
    for await (const _chunk of stream) {
      // Exhaust the call so its purpose is available in the final snapshot.
    }

    assert.equal(ctx.cacheScope.snapshot().attempts[0]?.purpose, 'conversation')
  })

  it('keeps legacy session-bound calls in conversation scope when package copies cannot share identity', async (t) => {
    const ctx = await setup({ includeAuxiliary: false })
    t.after(async () => { await ctx.root.fiber.dispose() })
    const sessionBound = request()
    const sessionless = request({ messages: [message('standalone direct')] })
    Reflect.deleteProperty(sessionless, 'sessionId')

    for (const input of [sessionBound, sessionless]) {
      const stream = dispatch(ctx, input, () => (async function*() {
        yield { type: 'usage', usage: { inputTokens: 20, outputTokens: 1, cacheReadTokens: 80 } } as const
        yield { type: 'finish', reason: { kind: 'stop' } } as const
      })())
      for await (const _chunk of stream) {
        // Exhaust each call so the includeAuxiliary filter has run.
      }
    }

    assert.deepEqual(
      ctx.cacheScope.snapshot().attempts.map(attempt => attempt.purpose),
      ['conversation'],
    )
  })

  it('constructs next synchronously, starts on iteration, and preserves chunk identity and order', async (t) => {
    const ctx = await setup()
    t.after(async () => { await ctx.root.fiber.dispose() })
    const chunks: StreamChunk[] = [
      { type: 'text-delta', index: 0, text: 'ok' },
      { type: 'usage', usage: { inputTokens: 20, outputTokens: 1, cacheReadTokens: 80 } },
      { type: 'finish', reason: { kind: 'stop' } },
    ]
    let constructed = 0
    const stream = dispatch(ctx, request(), () => {
      constructed++
      return (async function*() { yield* chunks })()
    })

    assert.equal(constructed, 1)
    assert.equal(ctx.cacheScope.snapshot().attempts.length, 0)
    const seen: StreamChunk[] = []
    for await (const chunk of stream) seen.push(chunk)
    assert.deepEqual(seen, chunks)
    assert.ok(seen.every((chunk, index) => chunk === chunks[index]))
    const attempt = ctx.cacheScope.snapshot().attempts[0]
    assert.ok(attempt)
    assert.equal(attempt.status, 'completed')
    assert.equal(attempt.usage?.cacheReadRatio, 0.8)
    assert.equal(attempt.rawState, 'available')
    assert.equal(Reflect.has(attempt, 'rawInput'), false)
    assert.equal(ctx.cacheScope.input(attempt.id)?.rawInput?.provider, 'test-provider')
  })

  it('summarizes append-only requests as locally prefix-friendly', async (t) => {
    const ctx = await setup()
    t.after(async () => { await ctx.root.fiber.dispose() })
    const inputs = [
      request(),
      request({ messages: [message('first'), message('second')] }),
    ]
    for (const input of inputs) {
      const stream = dispatch(ctx, input, () => (async function*() {
        yield { type: 'usage', usage: { inputTokens: 20, outputTokens: 1, cacheReadTokens: 80 } } as const
        yield { type: 'finish', reason: { kind: 'stop' } } as const
      })())
      for await (const _chunk of stream) {
        // Exhaust each call so its summary status is final.
      }
    }

    const summary = ctx.cacheScope.snapshot().summary
    assert.equal(summary.comparablePrefixAttempts, 1)
    assert.equal(summary.prefixFriendlyAttempts, 1)
    assert.equal(summary.prefixFriendlyRatio, 1)
    assert.equal(summary.correlation.comparedAttempts, 1)
    assert.equal(summary.correlation.prefixFriendlyWithRead, 1)
  })

  it('keeps unrelated sessionless direct calls as independent observations', async (t) => {
    const ctx = await setup()
    t.after(async () => { await ctx.root.fiber.dispose() })
    for (const text of ['first direct', 'unrelated direct']) {
      const input = request({ messages: [message(text)] })
      Reflect.deleteProperty(input, 'sessionId')
      const stream = dispatch(ctx, input, () => (async function*() {
        yield { type: 'usage', usage: { inputTokens: 20, outputTokens: 1, cacheReadTokens: 80 } } as const
        yield { type: 'finish', reason: { kind: 'stop' } } as const
      })())
      for await (const _chunk of stream) {
        // Exhaust each independent direct call.
      }
    }

    const snapshot = ctx.cacheScope.snapshot()
    assert.deepEqual(snapshot.attempts.map(attempt => attempt.diagnosis.kind), [
      'first-observation',
      'first-observation',
    ])
    assert.equal(snapshot.summary.comparablePrefixAttempts, 0)
  })

  it('reports median and nearest-rank P95 Call TTFT', async (t) => {
    const ctx = await setup()
    t.after(async () => { await ctx.root.fiber.dispose() })
    for (let index = 1; index <= 20; index++) {
      const handle = ctx.cacheScope.begin(
        request({ messages: [message(`request-${index}`)] }),
        'conversation',
      )
      handle.record.firstTokenMs = index * 10
      ctx.cacheScope.complete(handle)
    }

    const summary = ctx.cacheScope.snapshot().summary
    assert.equal(summary.medianFirstTokenMs, 105)
    assert.equal(summary.p95FirstTokenMs, 190)
  })

  it('rethrows synchronous next and iteration failures without replacing their identity', async (t) => {
    const ctx = await setup()
    t.after(async () => { await ctx.root.fiber.dispose() })
    const constructionError = new Error('construction sentinel')
    assert.throws(
      () => dispatch(ctx, request(), () => { throw constructionError }),
      error => error === constructionError,
    )
    assert.equal(ctx.cacheScope.snapshot().attempts.length, 0)

    const iterationError = new Error('iteration sentinel')
    const stream = dispatch(ctx, request(), () => (async function*() {
      yield { type: 'text-delta', index: 0, text: 'before error' } as const
      throw iterationError
    })())
    await assert.rejects(async () => {
      for await (const _chunk of stream) {
        // Consume until the original source throws.
      }
    }, error => error === iterationError)
    const failedAttempt = ctx.cacheScope.snapshot().attempts[0]
    assert.ok(failedAttempt)
    assert.equal(failedAttempt.status, 'failed')
  })

  it('closes the source on consumer break and retains raw input for only the configured recent attempts', async (t) => {
    const ctx = await setup()
    t.after(async () => { await ctx.root.fiber.dispose() })
    let sourceClosed = 0
    const first = dispatch(ctx, request(), () => (async function*() {
      try {
        yield { type: 'text-delta', index: 0, text: 'one' } as const
        yield { type: 'finish', reason: { kind: 'stop' } } as const
      } finally {
        sourceClosed++
      }
    })())
    for await (const _chunk of first) break
    assert.equal(sourceClosed, 1)
    const stoppedAttempt = ctx.cacheScope.snapshot().attempts[0]
    assert.ok(stoppedAttempt)
    assert.equal(stoppedAttempt.status, 'consumer-stopped')

    const second = dispatch(ctx, request({ messages: [message('second')] }), () => (async function*() {
      yield { type: 'finish', reason: { kind: 'stop' } } as const
    })())
    for await (const _chunk of second) {
      // Exhaust the terminal stream.
    }
    const attempts = ctx.cacheScope.snapshot().attempts
    assert.ok(attempts[0])
    assert.ok(attempts[1])
    assert.equal(attempts[0].rawState, 'available')
    assert.equal(attempts[1].rawState, 'evicted')
    assert.equal(ctx.cacheScope.input(attempts[0].id)?.rawInput?.provider, 'test-provider')
    assert.equal(ctx.cacheScope.input(attempts[1].id)?.rawInput, undefined)
  })
})

describe('loopback dashboard', () => {
  it('serves captured attempts with security headers and rejects cross-site origins', async (t) => {
    const ctx = new Context()
    await ctx.plugin(LlmRuntime)
    await ctx.plugin(WebServer, { host: '127.0.0.1', port: 0 })
    await ctx.plugin(CacheScopePlugin, { ...CONFIG, dashboard: true })
    t.after(async () => { await ctx.root.fiber.dispose() })

    const stream = dispatch(ctx, request(), () => (async function*() {
      yield { type: 'text-delta', index: 0, text: 'ok' } as const
      yield { type: 'usage', usage: { inputTokens: 25, outputTokens: 2, cacheReadTokens: 75 } } as const
      yield { type: 'finish', reason: { kind: 'stop' } } as const
    })())
    for await (const _chunk of stream) {
      // Exhaust the attempt before querying its read model.
    }

    const base = `http://127.0.0.1:${ctx.webServer.port}`
    const page = await fetch(`${base}/cachescope`)
    assert.equal(page.status, 200)
    assert.match(page.headers.get('content-security-policy') ?? '', /default-src 'none'/)
    assert.match(await page.text(), /DSH CacheScope/)

    const response = await fetch(`${base}/cachescope/api`)
    assert.equal(response.status, 200)
    const body = await response.json() as {
      attempts: Array<{ id: string, rawInput?: unknown, usage?: { cacheReadRatio?: number } }>
    }
    assert.equal(body.attempts[0]?.usage?.cacheReadRatio, 0.75)
    assert.equal(body.attempts[0]?.rawInput, undefined)

    const inputResponse = await fetch(`${base}/cachescope/api/input?id=${body.attempts[0]?.id}`)
    assert.equal(inputResponse.status, 200)
    const input = await inputResponse.json() as { rawInput?: { provider?: string } }
    assert.equal(input.rawInput?.provider, 'test-provider')

    const crossSite = await fetch(`${base}/cachescope/api`, {
      headers: { origin: 'https://attacker.example' },
    })
    assert.equal(crossSite.status, 403)
  })
})
