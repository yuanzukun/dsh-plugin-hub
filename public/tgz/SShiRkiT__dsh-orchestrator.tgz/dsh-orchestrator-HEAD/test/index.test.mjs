import assert from 'node:assert/strict'
import { registerHooks } from 'node:module'
import test from 'node:test'
import { allowGuard } from '../lib/gate.js'

/**
 * `lib/index.js` is the DSH plugin entry, and it imports three packages the host
 * supplies at runtime (this repo installs none of them). They play no part in the
 * `agent/created` hook under test, so stand-ins let the real `apply` run and the
 * real hook fire. The hook itself, `installGate` and `isDelegatedChild` are the
 * production code; only the outer framework objects are fake.
 */
const dataUrl = (source) => 'data:text/javascript,' + encodeURIComponent(source)

const STUBS = {
  '@deepseek-ai/schemastery': `
    function chain() {
      const node = {}
      node.default = () => chain()
      node.volatile = () => chain()
      node.min = () => chain()
      node.max = () => chain()
      node.step = () => chain()
      node.description = () => chain()
      node.describe = () => chain()
      return node
    }
    const z = {
      boolean: () => chain(),
      string: () => chain(),
      number: () => chain(),
      array: () => chain(),
      object: () => chain(),
    }
    export default z
  `,
  '@deepseek-ai/dsh-tools': `
    export function defineTool(spec) { return spec }
  `,
  '@deepseek-ai/dsh-llm': `
    let seq = 0
    export function createUserMessage(input) {
      seq += 1
      return { id: 'stub-user-msg-' + seq, role: 'user', ...input }
    }
  `,
  zod: `
    const z = { object: () => ({ strict: () => ({}) }), enum: () => ({}), boolean: () => ({}) }
    export { z }
    export default z
  `,
}

registerHooks({
  resolve(specifier, context, nextResolve) {
    const stub = STUBS[specifier]
    if (stub !== undefined) return { url: dataUrl(stub), shortCircuit: true }
    return nextResolve(specifier, context)
  },
})

const mod = await import(new URL('../lib/index.js', import.meta.url).href)

/**
 * Every tool a host could register: the file/search/shell/web tools a main agent must not
 * touch, the native delegation tools, an MCP tool, and the `run_code` transport. The gate
 * hides all of them except the ones the whitelist names (and never `run_code`, which
 * `tools.restrict` refuses).
 */
const HOST_TOOLS = [
  'apply_patch',
  'bash',
  'create_goal',
  'decompress',
  'edit',
  'glob',
  'grep',
  'list_agents',
  'mcp__demo__ping',
  'ops_bash',
  'ops_read_files',
  'pwsh',
  'ralph',
  'read',
  'read_image',
  'run_code',
  'schedule_create',
  'search_context',
  'subagent',
  'update_goal',
  'web_fetch',
  'web_search',
  'workflow',
  ...mod.DEFAULT_ALLOWED_TOOLS,
]

/**
 * What `tools.definitions(scope)` hands back before the plugin wraps it: every name the
 * scope can see, global and scope-local alike. `run_code` is left out on purpose — a host
 * in native mode never lists the PTC transport, so the default surface models that; a test
 * that needs the PTC shape adds it explicitly.
 */
const SURFACE_TOOLS = HOST_TOOLS.filter((name) => name !== 'run_code')

/** The names one `definitions()` result carries. */
const namesOf = (list) => list.map((definition) => definition.name)

/** A minimal ctx: only the members `apply` touches, each recording what it got.
 *  `enabled` and the live `allowedTools` are mutable so a test can flip the switch or the
 *  whitelist after installation, the way a panel write does.
 */
function fakeCtx({
  enabled = true,
  allowed,
  agents,
  sessions,
  subagents,
  stateOf,
  catalogNames = HOST_TOOLS,
  surface = SURFACE_TOOLS,
} = {}) {
  const state = { enabled, allowed }
  const projections = []
  const tools = []
  const handlers = new Map()
  // The options each subscription was made with: a lifecycle edge of a child is dispatched
  // with the child's parent as carrier, so the retry listener has to be registered global.
  const handlerOptions = new Map()
  const effects = []
  const logs = { info: [], warn: [] }
  const emitted = []
  // The live tool catalog the plugin publishes, as a writable volatile reference.
  let catalog = []
  const catalogRef = {
    get: () => catalog,
    [Symbol.for('cosmokit.volatile.write')]: (next) => {
      catalog = next
    },
  }
  const ctx = {
    sessionProjections: {
      register: (projection) => projections.push(projection),
      stateOf,
    },
    tools: {
      register(tool) {
        tools.push(tool)
        return () => {}
      },
      // The context-global view the catalog reads: names plus an empty visible map.
      view: () => ({ knownNames: new Set(catalogNames), visible: new Map() }),
      // The one exit a model request is built from. `apply` wraps it, so a test reads back
      // exactly the declarations a main agent or a child would be offered.
      definitions: () => surface.map((name) => ({ name })),
    },
    subagents: subagents ?? {},
    agents: agents ?? { get: () => undefined },
    sessions: sessions ?? { get: () => undefined, flush: async () => true },
    effect(fn, label) {
      const dispose = fn()
      effects.push({ label, dispose })
      return () => {
        if (typeof dispose === 'function') dispose()
      }
    },
    on(event, handler, options) {
      handlers.set(event, handler)
      handlerOptions.set(event, options)
    },
    logger: {
      info: (message) => logs.info.push(message),
      warn: (message) => logs.warn.push(message),
    },
    emit: (event, ...args) => emitted.push([event, ...args]),
  }
  const config = {
    enabled: { get: () => state.enabled },
    allowedTools: { get: () => state.allowed },
    workerProvider: { get: () => '' },
    workerModel: { get: () => '' },
    workerReasoningEffort: { get: () => '' },
    superviseEnabled: { get: () => true },
    superviseIntervalSeconds: { get: () => 600 },
    superviseMaxNoticesPerChild: { get: () => 3 },
    superviseUnlimited: { get: () => false },
    superviseNotifyOnNoProgress: { get: () => false },
    toolCatalog: catalogRef,
  }
  return {
    ctx,
    config,
    state,
    projections,
    tools,
    handlers,
    handlerOptions,
    effects,
    logs,
    emitted,
    catalogNames,
    catalog: () => catalog,
    // The Loader commits a volatile field from the profile's raw value on every settings
    // write, which for an unset key means the empty array. Tests replay that.
    resetCatalog: () => {
      catalog = []
    },
  }
}

/**
 * A stand-in agent with its own tool registry. `restrict` only records calls — the plugin
 * is expected never to make one, which is what keeps `tools/change` quiet — and `guard`
 * hands back a disposer so the agent/disposed path is observable.
 */
function fakeAgent({ id = 'agent-1', depth, header = {} } = {}) {
  const restricted = []
  const guards = []
  const registered = []
  const agent = {
    id,
    options: { provider: 'p', model: 'm', ...(depth === undefined ? {} : { subagentDepth: depth }) },
    session: { header },
    ctx: {
      tools: {
        restrict({ deny }) {
          restricted.push(deny[0])
          return () => {}
        },
        guard(fn) {
          guards.push(fn)
          let live = true
          return () => {
            if (!live) return
            live = false
            const at = guards.indexOf(fn)
            if (at !== -1) guards.splice(at, 1)
          }
        },
        register(tool) {
          registered.push(tool)
          return () => {}
        },
      },
    },
  }
  return { agent, restricted, guards, registered }
}

/** Start the plugin and hand back its `agent/created` handler. */
function start(options) {
  const harness = fakeCtx(options)
  mod.apply(harness.ctx, harness.config)
  const created = harness.handlers.get('agent/created')
  assert.equal(typeof created, 'function', 'apply must subscribe to agent/created')
  return { ...harness, created }
}

test('a child with a persisted delegation depth is never gated', () => {
  // Regression: a cold-resumed child was gated as a main agent, losing every working
  // tool and keeping only delegate/orchestrate. Its depth lives in the session header.
  for (const { agent, restricted, guards } of [
    fakeAgent({ header: { delegationDepth: 1 } }),
    fakeAgent({ header: {}, depth: 1 }),
  ]) {
    const { created, ctx } = start()
    created({ agent, source: 'resume' })
    assert.deepEqual(restricted, [], 'a child triggers no restriction at all')
    assert.equal(guards.length, 0, 'no guard may be registered for a child')
    assert.equal(namesOf(ctx.tools.definitions(agent)).includes('read'), true, 'the child keeps its working tools')
  }
})

test('a delegated child loses the delegation tools and keeps the native ones', () => {
  // Workers inherit the global table, so the surface drops the plugin's own pair — their
  // descriptions are written for a planner. The host's `subagent`, `workflow` and every
  // scope-local `ops_*` tool stay untouched: nothing is restricted.
  const { created, ctx } = start()
  const { agent, restricted, registered } = fakeAgent({ header: { delegationDepth: 1 } })
  created({ agent, source: 'resume' })
  const names = namesOf(ctx.tools.definitions(agent))
  assert.deepEqual(restricted, [], 'a child is masked by the surface, not by restrict')
  assert.deepEqual(registered, [], 'a child gets no scoped tool registration')
  assert.equal(names.includes('delegate'), false)
  assert.equal(names.includes('orchestrate'), false)
  for (const name of ['subagent', 'workflow', 'ops_bash', 'ops_read_files', 'read', 'edit']) {
    assert.equal(names.includes(name), true, name)
  }
})

test('a child is masked on its very first request, and no restriction is ever installed', () => {
  // The surface derives the deny list from the scope, so the first `preStep` assembly of a
  // new worker already lacks the pair: no window, no `tools/change`, no cache churn.
  const { created, ctx } = start()
  const { agent, restricted } = fakeAgent({ depth: 1 })
  created({ agent, source: 'create' })
  assert.equal(namesOf(ctx.tools.definitions(agent)).includes('delegate'), false)
  assert.equal(namesOf(ctx.tools.definitions(agent)).includes('orchestrate'), false)
  assert.deepEqual(restricted, [])
})

test('a main agent gets the full rule and no scoped registration', () => {
  const { created, tools } = start()
  const { agent, registered } = fakeAgent()
  created({ agent, source: 'create' })
  assert.deepEqual(registered, [], 'the global pair is enough for a main agent')
  const delegate = tools.find((tool) => tool.name === 'delegate')
  const orchestrate = tools.find((tool) => tool.name === 'orchestrate')
  assert.match(delegate.description, /主代理规则：主代理只负责规划/)
  // The rule is rendered once: the batch brief only points back at it.
  assert.match(orchestrate.description, /^主代理规则同 delegate/)
  assert.equal(orchestrate.description.includes('主代理可用工具'), false)
  assert.equal(orchestrate.description.includes('【插件重试｜子代理 <id>】'), false)
})

test('a panel write reaches the next request without a re-mask or a new registration', () => {
  const { created, ctx, state, tools } = start()
  const delegated = tools.length
  const main = fakeAgent()
  created({ agent: main.agent, source: 'create' })
  assert.deepEqual(namesOf(ctx.tools.definitions(main.agent)), mod.DEFAULT_ALLOWED_TOOLS)
  assert.deepEqual(main.restricted, [], 'the surface needs no restriction')

  state.allowed = [...mod.DEFAULT_ALLOWED_TOOLS, 'read']
  assert.equal(namesOf(ctx.tools.definitions(main.agent)).includes('read'), true)
  state.allowed = mod.DEFAULT_ALLOWED_TOOLS
  assert.equal(namesOf(ctx.tools.definitions(main.agent)).includes('read'), false)
  assert.equal(tools.length, delegated, 'a whitelist change registers nothing')
  assert.deepEqual(main.restricted, [], 'and still restricts nothing')
})

test('a main agent is guarded, and the surface carries only the shipped whitelist', () => {
  const { created, ctx } = start()
  const { agent, restricted, guards } = fakeAgent()
  created({ agent, source: 'create' })
  // No mask any more: every name the whitelist leaves out is filtered at definitions(),
  // own-scope tools such as `ops_bash` and the native `subagent` included.
  assert.deepEqual(restricted, [])
  assert.equal(guards.length, 1)
  assert.deepEqual(namesOf(ctx.tools.definitions(agent)), mod.DEFAULT_ALLOWED_TOOLS)
  for (const name of ['read', 'edit', 'ops_bash', 'ops_read_files', 'subagent', 'workflow']) {
    assert.equal(namesOf(ctx.tools.definitions(agent)).includes(name), false, name)
  }
  for (const name of mod.DEFAULT_ALLOWED_TOOLS) assert.equal(guards[0]({ name }), undefined, name)
  assert.match(guards[0]({ name: 'edit' }), /"edit" is not available to the main agent/)
  assert.match(guards[0]({ name: 'subagent' }), /"subagent" is not available to the main agent/)
})

test('the shipped whitelist is twelve planning tools, and every other name is refused', () => {
  // The main agent keeps the delegation tools, the session read-only tools and `compress`:
  // the capabilities that make planning and review possible without touching the repo.
  const shipped = mod.DEFAULT_ALLOWED_TOOLS
  assert.equal(shipped.length, 12)
  for (const name of [
    'delegate',
    'orchestrate',
    'send_message',
    'interrupt_agent',
    'todo_write',
    'ask_user_question',
    'compress',
    'session_search',
    'session_trace',
    'session_event_search',
    'session_event_read',
    'session_event_trace',
  ]) {
    assert.equal(shipped.includes(name), true, name)
    assert.equal(allowGuard(shipped)({ name }), undefined, name)
  }
  for (const name of [
    'read',
    'edit',
    'write',
    'apply_patch',
    'grep',
    'glob',
    'bash',
    'pwsh',
    'ops_bash',
    'web_fetch',
    'web_search',
    'subagent',
    'workflow',
    'ralph',
    'decompress',
    'search_context',
    'acp_status',
    'mcp_custom_tool',
    // `wait_agent` is a host tool the default whitelist deliberately leaves out: a main
    // agent must not block on a wait, it dispatches and is woken by the completion notice.
    'wait_agent',
  ]) {
    assert.equal(shipped.includes(name), false, name)
    assert.match(allowGuard(shipped)({ name }), /is not available to the main agent/, name)
  }
  assert.equal(shipped.includes('wait_agent'), false)

  const { created, ctx } = start()
  const { agent, guards } = fakeAgent()
  created({ agent, source: 'create' })
  const names = namesOf(ctx.tools.definitions(agent))
  assert.equal(names.includes('compress'), true, 'compress is whitelisted, so it stays declared')
  assert.equal(guards[0]({ name: 'compress' }), undefined, 'compress must pass the guard')
  for (const name of ['ops_bash', 'read', 'decompress']) {
    assert.match(guards[0]({ name }), /is not available to the main agent/, name)
  }
  assert.equal(guards[0]({ name: 'delegate' }), undefined)
})

test('a resumed agent with a parentSession but no depth is gated and warns', () => {
  const { created, ctx, logs } = start()
  const { agent, restricted, guards } = fakeAgent({ id: 'cold-child', header: { parentSession: 'root-session' } })
  created({ agent, source: 'resume' })
  assert.deepEqual(restricted, [], 'the surface replaces the old mask entirely')
  assert.deepEqual(namesOf(ctx.tools.definitions(agent)), mod.DEFAULT_ALLOWED_TOOLS)
  assert.equal(guards.length, 1)
  assert.equal(logs.warn.length, 1)
  assert.match(logs.warn[0], /cold-child/)
  assert.match(logs.warn[0], /parentSession but no delegation depth/)
  // The warning must not leak the conversation itself.
  assert.equal(logs.warn[0].includes('root-session'), false)
})

test('the warning fires only for a resume that fell through the depth test', () => {
  // A normal creation is not a resume, and a resumed child does have a depth.
  const fresh = start()
  fresh.created({ agent: fakeAgent({ header: { parentSession: 'root' } }).agent, source: 'create' })
  assert.equal(fresh.logs.warn.length, 0)

  const resumedChild = start()
  resumedChild.created({ agent: fakeAgent({ header: { parentSession: 'root', delegationDepth: 1 } }).agent, source: 'resume' })
  assert.equal(resumedChild.logs.warn.length, 0)
})

test('the switch being off still installs the guard and restores host tools without delegate/orchestrate', () => {
  // The gate is installed even while dispatch mode is off, so flipping the switch on
  // in an open conversation takes effect without a restart; the info log follows the switch.
  const { created, ctx, state, logs, tools } = start({ enabled: false })
  const { agent, restricted, guards } = fakeAgent()
  const expectedOff = SURFACE_TOOLS.filter((name) => name !== 'delegate' && name !== 'orchestrate')
  const delegate = tools.find((tool) => tool.name === 'delegate')
  const orchestrate = tools.find((tool) => tool.name === 'orchestrate')
  created({ agent, source: 'create' })
  assert.deepEqual(restricted, [])
  assert.equal(guards.length, 1)
  assert.deepEqual(namesOf(ctx.tools.definitions(agent)), expectedOff, 'off restores host tools and hides dispatch pair')
  assert.equal(delegate.description.includes('主代理规则：主代理只负责规划'), false)
  assert.equal(orchestrate.description.includes('主代理规则同 delegate'), false)
  assert.equal(guards[0]({ name: 'edit' }), undefined)
  assert.match(guards[0]({ name: 'delegate' }), /"delegate" is disabled while dispatch mode is off/)
  assert.equal(logs.info.length, 0)
  assert.equal(logs.warn.length, 0)

  // Turning it on filters the next request even though nothing was re-installed.
  state.enabled = true
  assert.deepEqual(namesOf(ctx.tools.definitions(agent)), mod.DEFAULT_ALLOWED_TOOLS)
  assert.match(delegate.description, /^主代理规则：主代理只负责规划/)
  assert.match(orchestrate.description, /^主代理规则同 delegate/)
  assert.deepEqual(restricted, [], 'still no restriction')
})

test('a whitelist written in the panel reaches an open conversation, live', () => {
  // The whitelist is read per call, so a panel write lands in a conversation that was
  // already open: checking `read` lets it through at once, unchecking `delegate` blocks it.
  const { created, state } = start()
  const { agent, guards } = fakeAgent()
  created({ agent, source: 'create' })
  assert.match(guards[0]({ name: 'read' }), /not available to the main agent/)
  assert.equal(guards[0]({ name: 'delegate' }), undefined)

  state.allowed = [...mod.DEFAULT_ALLOWED_TOOLS, 'read']
  assert.equal(guards[0]({ name: 'read' }), undefined)

  state.allowed = mod.DEFAULT_ALLOWED_TOOLS.filter((name) => name !== 'delegate')
  assert.match(guards[0]({ name: 'delegate' }), /"delegate" is not available to the main agent/)
  assert.equal(guards[0]({ name: 'orchestrate' }), undefined)

  // Unchecking every box disables every tool: an empty whitelist is not "use the default".
  state.allowed = []
  for (const name of ['delegate', 'orchestrate', 'compress', 'read']) {
    assert.match(guards[0]({ name }), /is not available to the main agent/, name)
  }
})

test('the whitelist clause follows the live config without re-registering', () => {
  // The description is a getter, so the same registered tool renders the new list: a
  // settings change reaches the prompt without a restart or a new session. The clause is
  // rendered by `delegate` only — `orchestrate` points at it instead of repeating it.
  const { tools, state } = start()
  const delegate = tools.find((tool) => tool.name === 'delegate')
  const orchestrate = tools.find((tool) => tool.name === 'orchestrate')
  const allowedOf = (tool) =>
    /主代理可用工具（白名单驱动，其余全部禁用）: ([^。]+)。/.exec(tool.description)?.[1]
  assert.equal(allowedOf(delegate), mod.DEFAULT_ALLOWED_TOOLS.join(', '))
  assert.equal(allowedOf(orchestrate), undefined)

  state.allowed = ['delegate', 'orchestrate', 'read']
  assert.equal(allowedOf(delegate), 'delegate, orchestrate, read')
  assert.equal(orchestrate.description.includes('read'), false)

  // The rule has a second sentence for the case where the panel unchecks everything.
  state.allowed = []
  assert.match(delegate.description, /当前主代理无可用工具（白名单为空）。/)
  assert.equal(allowedOf(delegate), undefined)
})
/** Only the members supervision adapters use, with recording friendly defaults. */
function fakeSupervisionHost({ parents = new Map(), sessions = new Map(), stateOf, flush } = {}) {
  const logs = []
  const ctx = {
    agents: { get: (id) => parents.get(id) },
    sessions: {
      get: (id) => sessions.get(id),
      flush: flush ?? (async () => true),
    },
    sessionProjections: { stateOf },
    logger: { warn: (message) => logs.push(message) },
  }
  return { ctx, logs, parents, sessions }
}

test('apply installs a 5000 ms supervision timer and clears it when the effect unloads', () => {
  const timers = []
  const cleared = []
  const realSet = globalThis.setInterval
  const realClear = globalThis.clearInterval
  globalThis.setInterval = (fn, ms) => {
    const handle = { fn, ms, unref() {} }
    timers.push(handle)
    return handle
  }
  globalThis.clearInterval = (handle) => cleared.push(handle)
  try {
    const harness = start()
    // The scan period is fixed: a tick only compares clocks unless a child is due.
    assert.equal(timers.length, 1)
    assert.equal(timers[0].ms, 5000)
    const timerEffect = harness.effects.find(({ label }) => label === 'orchestrator: supervision timer')
    assert.ok(timerEffect, 'the timer must be owned by an effect')
    timerEffect.dispose()
    assert.deepEqual(cleared, [timers[0]])
  } finally {
    globalThis.setInterval = realSet
    globalThis.clearInterval = realClear
  }
})

test('onStarted tracks the child and forgets it once the receipt settles', async () => {
  const tracked = []
  const forgotten = []
  const hooks = mod.createSupervisionHooks({
    track: (entry) => tracked.push(entry),
    forget: (childId) => forgotten.push(childId),
  })

  const result = Promise.resolve('done')
  hooks.onStarted({ id: 'parent-1' }, { childId: 'child-1', result }, { description: '慢活' })
  assert.equal(tracked.length, 1)
  assert.equal(tracked[0].childId, 'child-1')
  assert.equal(tracked[0].parentId, 'parent-1')
  assert.equal(tracked[0].label, '慢活')
  assert.ok(tracked[0].startedAt > 0)
  await result
  await Promise.resolve()
  assert.deepEqual(forgotten, ['child-1'])

  // A rejected receipt is handled silently, never as an unhandled rejection.
  const failed = Promise.reject(new Error('boom'))
  hooks.onStarted({ id: 'parent-1' }, { childId: 'child-2', result: failed }, { description: '失败' })
  await failed.catch(() => {})
  await Promise.resolve()
  assert.deepEqual(forgotten, ['child-1', 'child-2'])
})

/** The supervisor surface the hooks touch, with real add/remove semantics. */
function recordingSupervisor() {
  const entries = new Map()
  const tracked = []
  return {
    entries,
    tracked,
    track: (entry) => {
      tracked.push(entry)
      entries.set(entry.childId, entry)
    },
    forget: (childId) => entries.delete(childId),
    has: (childId) => entries.has(childId),
  }
}

test('a cold-resumed worker is tracked again with the log head as its baseline', async () => {
  // Regression: interrupt settles the receipt, the receipt forgets the child, and the
  // send_message cold resume created it again without registering it — supervision was
  // silently lost for the rest of that worker's life.
  const registry = recordingSupervisor()
  const hooks = mod.createSupervisionHooks(registry, { headSeq: (childId) => (childId === 'child-1' ? 42 : 0) })
  let settle
  const result = new Promise((resolve) => {
    settle = resolve
  })
  hooks.onStarted({ id: 'parent-1' }, { childId: 'child-1', result }, { description: '慢活' })
  assert.equal(registry.entries.size, 1)

  settle('done')
  await result
  await Promise.resolve()
  assert.equal(registry.entries.size, 0, 'the settled receipt releases the child')

  hooks.onResumed({ id: 'child-1', session: { header: { parentSession: 'parent-1', delegationDepth: 1 } } })
  const entry = registry.entries.get('child-1')
  assert.ok(entry, 'the resumed worker must be supervised again')
  assert.equal(entry.parentId, 'parent-1', 'the dispatch record names the real parent')
  assert.equal(entry.label, '慢活', 'the task description survives the interrupt')
  assert.equal(entry.resumed, true)
  assert.equal(entry.sinceSeq, 42, 'pre-interrupt history is not reported as new')
  assert.ok(entry.startedAt > 0)
})

test('a resumed agent this plugin never dispatched stays unsupervised', () => {
  const registry = recordingSupervisor()
  const hooks = mod.createSupervisionHooks(registry, { headSeq: () => 7 })
  // The host's own subagent tool also creates delegated children; they never entered
  // supervision, so a resume of one must not start a notice timer on it.
  hooks.onResumed({ id: 'host-child', session: { header: { parentSession: 'parent-1', delegationDepth: 1 } } })
  assert.equal(registry.entries.size, 0)
  assert.equal(registry.tracked.length, 0)
})

test('a repeated resume event does not restart the clock', () => {
  const registry = recordingSupervisor()
  const hooks = mod.createSupervisionHooks(registry, { headSeq: () => 5 })
  hooks.onStarted({ id: 'p' }, { childId: 'c', result: null }, { description: 'job' })
  registry.forget('c')
  hooks.onResumed({ id: 'c' })
  const first = registry.entries.get('c')
  const count = registry.tracked.length

  hooks.onResumed({ id: 'c' })
  assert.equal(registry.tracked.length, count, 'no second registration')
  assert.equal(registry.entries.get('c'), first, 'the deadline and budget are untouched')
})

test('an unreadable log head falls back to the zero baseline and still tracks', () => {
  const registry = recordingSupervisor()
  const hooks = mod.createSupervisionHooks(registry, {
    headSeq: () => {
      throw new Error('session log unavailable')
    },
  })
  hooks.onStarted({ id: 'p' }, { childId: 'c', result: null }, { description: 'job' })
  registry.forget('c')
  assert.doesNotThrow(() => hooks.onResumed({ id: 'c' }))
  assert.equal(registry.entries.get('c').sinceSeq, 0)
})

test('the dispatch memory is bounded, so a very old worker is not re-armed', async () => {
  const registry = recordingSupervisor()
  const hooks = mod.createSupervisionHooks(registry, { headSeq: () => 0 })
  const total = 129
  for (let index = 0; index < total; index += 1) {
    hooks.onStarted({ id: 'p' }, { childId: `child-${index}`, result: null }, { description: 'job' })
  }
  // Every registration is released, as a batch of finished receipts would leave them.
  registry.entries.clear()
  // The oldest dispatch record is evicted; the newest is still remembered.
  hooks.onResumed({ id: 'child-0' })
  assert.equal(registry.entries.has('child-0'), false)
  hooks.onResumed({ id: `child-${total - 1}` })
  assert.equal(registry.entries.has(`child-${total - 1}`), true)
})

test('headSeq reads the highest seq in the child log, and 0 when it cannot', () => {
  const parent = { id: 'p', session: { id: 's' } }
  const child = { id: 'c', log: [{ seq: 3, type: 'x' }, { seq: 9, type: 'y' }, { type: 'no-seq' }] }
  const host = fakeSupervisionHost({
    parents: new Map([['p', parent]]),
    sessions: new Map([['c', child]]),
  })
  const supervision = mod.createSupervision({ ctx: host.ctx, config: {} })
  assert.equal(supervision.headSeq('c'), 9)
  // The baseline is a cold-resume detail; an unreadable log must never throw into the hook.
  assert.equal(supervision.headSeq('gone'), 0)
  assert.doesNotThrow(() => supervision.headSeq(undefined))
})

test('hasPendingNotice recognises its own source and tolerates a broken projection', () => {
  const parent = { id: 'p', session: { id: 's' } }
  const broken = fakeSupervisionHost({ parents: new Map([['p', parent]]) })
  const first = mod.createSupervision({ ctx: broken.ctx, config: {} })
  // The inbox state shape is not a public API: a failure is false, not a throw.
  assert.equal(first.hasPendingNotice('p'), false)
  assert.equal(first.hasPendingNotice('p'), false)
  assert.equal(broken.logs.filter((message) => /cannot read the parent inbox/.test(message)).length, 1)

  const good = fakeSupervisionHost({
    parents: new Map([['p', parent]]),
    stateOf: () => ({ 'next-turn': [{ source: { kind: mod.SUPERVISE_SOURCE_KIND } }], 'next-step': [] }),
  })
  const second = mod.createSupervision({ ctx: good.ctx, config: {} })
  assert.equal(second.hasPendingNotice('p'), true)

  const unrelated = fakeSupervisionHost({
    parents: new Map([['p', parent]]),
    stateOf: () => ({ 'next-turn': [{ source: { kind: 'schedule' } }], 'next-step': [] }),
  })
  assert.equal(mod.createSupervision({ ctx: unrelated.ctx, config: {} }).hasPendingNotice('p'), false)
})

test('deliver refuses an unknown parent and degrades safely when the llm import fails', async () => {
  const unknown = fakeSupervisionHost()
  const missing = mod.createSupervision({ ctx: unknown.ctx, config: {} })
  assert.equal(await missing.deliver('gone', 'text', ['child']), 'parent-gone')

  const parent = { id: 'p', session: {}, followup() {} }
  const host = fakeSupervisionHost({ parents: new Map([['p', parent]]) })
  let loads = 0
  const broken = mod.createSupervision({
    ctx: host.ctx,
    config: {},
    loadLlm: async () => {
      loads += 1
      throw new Error('package unavailable')
    },
  })
  // A missing host package must not throw, must not be retried every tick, and must
  // not consume the child's notice budget (the supervisor warns and reschedules).
  assert.equal(await broken.deliver('p', 'text', ['child']), 'unavailable')
  assert.equal(await broken.deliver('p', 'text', ['child']), 'unavailable')
  assert.equal(loads, 1)
  assert.equal(host.logs.filter((message) => /cannot load @deepseek-ai\/dsh-llm/.test(message)).length, 1)
})

test('deliver queues exactly one notice with followup, never steer', async () => {
  const calls = { followup: [], steer: 0, flush: [] }
  const parent = {
    id: 'p',
    session: { id: 'parent-session' },
    followup: (message) => calls.followup.push(message),
    steer: () => {
      calls.steer += 1
    },
  }
  const host = fakeSupervisionHost({
    parents: new Map([['p', parent]]),
    flush: async (session) => {
      calls.flush.push(session)
      return true
    },
  })
  const { deliver } = mod.createSupervision({
    ctx: host.ctx,
    config: {},
    loadLlm: async () => ({ createUserMessage: (input) => input }),
  })
  assert.equal(await deliver('p', '巡检正文', ['child-1', 'child-2']), 'queued')
  assert.equal(calls.followup.length, 1)
  assert.equal(calls.steer, 0)
  assert.equal(calls.followup[0].content[0].text, '巡检正文')
  assert.deepEqual(calls.followup[0].source, {
    kind: mod.SUPERVISE_SOURCE_KIND,
    form: 'notice',
    senderSessionId: 'child-1',
  })
  assert.equal(calls.flush.length, 1)
})

test('liveConfig reads superviseUnlimited on every tick, so the panel switch applies at once', async () => {
  const state = { unlimited: false, max: 0 }
  const config = {
    superviseEnabled: { get: () => true },
    superviseIntervalSeconds: { get: () => 600 },
    superviseMaxNoticesPerChild: { get: () => state.max },
    superviseNotifyOnNoProgress: { get: () => false },
    superviseUnlimited: { get: () => state.unlimited },
  }
  const queued = []
  const parent = { id: 'p', session: { id: 'parent-session' }, followup: (message) => queued.push(message) }
  const child = { id: 'child-1', log: [] }
  const host = fakeSupervisionHost({
    parents: new Map([
      ['p', parent],
      ['child-1', child],
    ]),
    sessions: new Map([['child-1', child]]),
  })
  const supervision = mod.createSupervision({
    ctx: host.ctx,
    config,
    loadLlm: async () => ({ createUserMessage: (input) => input }),
  })
  const base = Date.now()
  supervision.supervisor.track({
    childId: 'child-1',
    parentId: 'p',
    label: '慢活',
    startedAt: base - 11 * 60_000,
  })

  // A zero budget with the unlimited switch off is "supervision off": nothing is sent,
  // but the running child stays registered.
  await supervision.supervisor.tick(base)
  assert.equal(queued.length, 0)
  assert.equal(supervision.supervisor.size(), 1)

  // Flipping the switch on the live config is enough: no rebuild, no re-dispatch.
  state.unlimited = true
  await supervision.supervisor.tick(base + 600_000)
  assert.equal(queued.length, 1)
  assert.match(queued[0].content[0].text, /第 1 次/)
  assert.equal(queued[0].content[0].text.includes('/0'), false)

  // Turning it back off restores the numeric budget, which is already spent.
  state.unlimited = false
  state.max = 1
  await supervision.supervisor.tick(base + 1_200_000)
  assert.equal(queued.length, 1)
  assert.equal(supervision.supervisor.size(), 1)
})

test('a panel write reaches every live main agent on its next request, not by re-masking', () => {
  const main = fakeAgent()
  const child = fakeAgent({ id: 'child-1', depth: 1 })
  // `agents.list()` returns every live agent; the catalog keeps only the roots, so the
  // delegated child (depth 1) must be filtered out by `isDelegatedChild`.
  const { created, ctx, state } = start({
    agents: { get: () => undefined, list: () => [main.agent, child.agent] },
  })
  created({ agent: main.agent, source: 'create' })
  created({ agent: child.agent, source: 'create' })
  assert.equal(namesOf(ctx.tools.definitions(main.agent)).includes('read'), false)
  assert.equal(
    namesOf(ctx.tools.definitions(child.agent)).includes('read'),
    true,
    'a child keeps its working tools',
  )

  // The panel checks `read`: allowedTools gains it and the next request sees it, live.
  state.allowed = [...mod.DEFAULT_ALLOWED_TOOLS, 'read']
  assert.equal(namesOf(ctx.tools.definitions(main.agent)).includes('read'), true)
  assert.equal(
    namesOf(ctx.tools.definitions(main.agent)).includes('ops_bash'),
    false,
    'every other name stays out',
  )
  assert.equal(
    namesOf(ctx.tools.definitions(child.agent)).includes('delegate'),
    false,
    'the child deny list never moves',
  )

  state.allowed = mod.DEFAULT_ALLOWED_TOOLS
  assert.equal(namesOf(ctx.tools.definitions(main.agent)).includes('read'), false)
  assert.deepEqual(main.restricted, [], 'no restriction was ever installed')
  assert.deepEqual(child.restricted, [])
})

test('the enable switch flips the surface and rules in the open session through the same live read', () => {
  const main = fakeAgent()
  const { created, ctx, handlers, state, tools } = start({
    agents: { get: () => undefined, list: () => [main.agent] },
  })
  const expectedOff = SURFACE_TOOLS.filter((name) => name !== 'delegate' && name !== 'orchestrate')
  const delegate = tools.find((tool) => tool.name === 'delegate')
  const orchestrate = tools.find((tool) => tool.name === 'orchestrate')
  created({ agent: main.agent, source: 'create' })
  const volatile = handlers.get('loader/volatile-update')
  assert.equal(typeof volatile, 'function', 'apply must subscribe to loader/volatile-update')
  assert.deepEqual(namesOf(ctx.tools.definitions(main.agent)), mod.DEFAULT_ALLOWED_TOOLS)
  assert.match(delegate.description, /^主代理规则：主代理只负责规划/)
  assert.match(orchestrate.description, /^主代理规则同 delegate/)

  state.enabled = false
  volatile()
  assert.deepEqual(namesOf(ctx.tools.definitions(main.agent)), expectedOff, 'off restores host tools and hides dispatch pair')
  assert.equal(delegate.description.includes('主代理规则：主代理只负责规划'), false)
  assert.equal(orchestrate.description.includes('主代理规则同 delegate'), false)
  assert.equal(main.guards[0]({ name: 'edit' }), undefined, 'and lets regular host calls through')
  assert.match(main.guards[0]({ name: 'delegate' }), /"delegate" is disabled while dispatch mode is off/)
  assert.match(main.guards[0]({ name: 'orchestrate' }), /"orchestrate" is disabled while dispatch mode is off/)

  state.enabled = true
  volatile()
  assert.deepEqual(namesOf(ctx.tools.definitions(main.agent)), mod.DEFAULT_ALLOWED_TOOLS)
  assert.match(delegate.description, /^主代理规则：主代理只负责规划/)
  assert.match(orchestrate.description, /^主代理规则同 delegate/)
  assert.match(main.guards[0]({ name: 'edit' }), /not available to the main agent/)
  assert.equal(main.guards[0]({ name: 'delegate' }), undefined)
})

test('a disposed agent drops its guard, and a later write reinstalls nothing', () => {
  const main = fakeAgent()
  const live = [main.agent]
  const { created, handlers, state } = start({ agents: { get: () => undefined, list: () => live } })
  created({ agent: main.agent, source: 'create' })
  const volatile = handlers.get('loader/volatile-update')
  const disposed = handlers.get('agent/disposed')
  assert.equal(typeof disposed, 'function', 'apply must subscribe to agent/disposed')
  assert.equal(main.guards.length, 1)
  assert.deepEqual(main.restricted, [])

  disposed({ agent: main.agent })
  assert.equal(main.guards.length, 0, 'the guard is unregistered with the agent')

  // A later write with the agent gone has nothing to reinstall, and must not throw.
  live.length = 0
  state.allowed = [...mod.DEFAULT_ALLOWED_TOOLS, 'read']
  assert.doesNotThrow(() => volatile())
  assert.deepEqual(main.restricted, [])
})

test('an agent created before the plugin mounted is already covered by the surface', () => {
  // The wrapper reads the scope, not a registry of hooked agents: a missed creation hook
  // only means no guard for that agent, never an unfiltered request.
  const preExisting = fakeAgent({ id: 'pre-existing' })
  const { ctx, state } = start()
  assert.deepEqual(namesOf(ctx.tools.definitions(preExisting.agent)), mod.DEFAULT_ALLOWED_TOOLS)
  state.allowed = [...mod.DEFAULT_ALLOWED_TOOLS, 'read']
  assert.equal(namesOf(ctx.tools.definitions(preExisting.agent)).includes('read'), true)
})

test('a volatile write is never fatal, with or without a usable registry', () => {
  const { handlers } = start()
  const volatile = handlers.get('loader/volatile-update')
  assert.doesNotThrow(() => volatile())

  const broken = start({
    agents: {
      get: () => undefined,
      list: () => {
        throw new Error('registry gone')
      },
    },
  })
  assert.doesNotThrow(() => broken.handlers.get('loader/volatile-update')())
})

test('the surface is owned by one effect and hands the host method back on dispose', () => {
  const harness = start()
  const installed = harness.effects.find(({ label }) => label === 'orchestrator: tool surface')
  assert.equal(typeof installed?.dispose, 'function', 'apply must own the wrapper through an effect')
  const main = fakeAgent()
  assert.deepEqual(namesOf(harness.ctx.tools.definitions(main.agent)), mod.DEFAULT_ALLOWED_TOOLS)
  installed.dispose()
  assert.deepEqual(namesOf(harness.ctx.tools.definitions(main.agent)), SURFACE_TOOLS)
})

// ---- Automatic retry of a child that died without a closing message ---------------------

test('onStarted hands the dispatched child to the retry policy, and only for a real dispatch', () => {
  const tracked = []
  const retry = {
    track: (childId, record) => {
      tracked.push({ childId, ...record })
      return true
    },
  }
  const hooks = mod.createSupervisionHooks({ track() {}, forget() {} }, { retry })
  const result = Promise.resolve('done')
  hooks.onStarted({ id: 'parent-1' }, { childId: 'child-1', result }, { description: '慢活' })
  assert.deepEqual(tracked, [{ childId: 'child-1', parentId: 'parent-1', label: '慢活' }])
  // An event without the two ids is not a dispatch: nothing can be retried later.
  hooks.onStarted({}, { childId: 'child-2', result })
  hooks.onStarted({ id: 'parent-1' }, { result })
  assert.equal(tracked.length, 1)
})

test('a retry bookkeeping failure never breaks the dispatch', () => {
  const tracked = []
  const hooks = mod.createSupervisionHooks(
    { track: (entry) => tracked.push(entry), forget() {} },
    {
      retry: {
        track: () => {
          throw new Error('the policy is broken')
        },
      },
    },
  )
  assert.doesNotThrow(() => hooks.onStarted({ id: 'parent-1' }, { childId: 'child-1' }, {}))
  assert.equal(tracked.length, 1)
})

test('apply listens for the settlement edge globally, so a child-scoped emission reaches it', () => {
  const harness = start()
  const listener = harness.handlers.get('subagent/end')
  assert.equal(typeof listener, 'function', 'apply must subscribe to subagent/end')
  // The host dispatches this edge with the child's parent as carrier: a scoped listener is
  // filtered out, so the option is what makes the retry possible at all.
  assert.deepEqual(harness.handlerOptions.get('subagent/end'), { global: true })
  // A malformed event is ignored rather than thrown into the emitter.
  assert.doesNotThrow(() => listener(undefined))
  assert.doesNotThrow(() => listener({ id: '' }))
})

test('a delegate write lease blocks a second writer until the child settles', async () => {
  const started = []
  const harness = start({
    subagents: {
      resolveMaxDepth: () => 1,
      startActivation: async () => {
        const childId = `child-${started.length + 1}`
        started.push(childId)
        return { childId }
      },
    },
  })
  const tool = harness.tools.find(({ name }) => name === 'delegate')
  assert.equal(typeof tool?.execute, 'function', 'apply must register the delegate tool')
  const exec = { agent: { id: 'main-1' }, signal: new AbortController().signal }
  const claim = {
    description: 'edit',
    prompt: 'edit src/a.js',
    cwd: 'C:/repo',
    writeScope: ['src/a.js'],
    provider: 'p',
    model: 'm',
  }

  const first = await tool.execute(claim, exec)
  assert.equal(first.subagentId, 'child-1')
  assert.deepEqual(first.writeScope.scope, ['C:/repo/src/a.js'])
  await assert.rejects(
    () => tool.execute({ ...claim, description: 'overlap' }, exec),
    (error) => error?.code === 'write-scope-conflict',
  )
  assert.equal(started.length, 1, 'the overlapping dispatch never reached the host')

  harness.handlers.get('subagent/end')({ id: 'child-1', stopReason: 'completed' })
  const third = await tool.execute({ ...claim, description: 'after settle' }, exec)
  assert.equal(third.subagentId, 'child-2', 'settlement released the lease')
})

test('a disposed worker releases its write lease without a settlement edge', async () => {
  const started = []
  const harness = start({
    subagents: {
      resolveMaxDepth: () => 1,
      startActivation: async () => {
        const childId = `child-${started.length + 1}`
        started.push(childId)
        return { childId }
      },
    },
  })
  const tool = harness.tools.find(({ name }) => name === 'delegate')
  const exec = { agent: { id: 'main-1' }, signal: new AbortController().signal }
  const claim = {
    description: 'edit',
    prompt: 'edit src/a.js',
    cwd: 'C:/repo',
    writeScope: ['src/a.js'],
    provider: 'p',
    model: 'm',
  }

  const first = await tool.execute(claim, exec)
  const child = fakeAgent({ id: first.subagentId, depth: 1 })
  harness.handlers.get('agent/disposed')({ agent: child.agent })
  const next = await tool.execute({ ...claim, description: 'after dispose' }, exec)
  assert.equal(next.subagentId, 'child-2', 'disposal released the lease')
})

test('apply injects the one lease table into both tools, so delegate and orchestrate exclude each other', async () => {
  const started = []
  const harness = start({
    subagents: {
      resolveMaxDepth: () => 1,
      // `delegate` reads only the child id; a batch also reads the worker's result.
      startActivation: async (spec) => {
        const index = started.length
        started.push(spec)
        return {
          childId: `child-${index + 1}`,
          result: Promise.resolve({ output: [{ type: 'text', text: 'ok' }], stopReason: 'completed' }),
          dispose: async () => {},
        }
      },
    },
  })
  const delegate = harness.tools.find(({ name }) => name === 'delegate')
  const orchestrate = harness.tools.find(({ name }) => name === 'orchestrate')
  assert.equal(typeof orchestrate?.execute, 'function', 'apply must register the orchestrate tool')
  const exec = { agent: { id: 'main-1' }, signal: new AbortController().signal }
  const claim = {
    description: 'edit',
    prompt: 'edit src/a.js',
    cwd: 'C:/repo',
    writeScope: ['src/a.js'],
    provider: 'p',
    model: 'm',
  }
  const batch = {
    cwd: 'C:/repo',
    writeScope: ['src/a.js'],
    items: [1],
    stages: [{ name: 's', prompt: 'p' }],
    provider: 'p',
    model: 'm',
  }

  const held = await delegate.execute(claim, exec)
  assert.equal(held.subagentId, 'child-1')
  await assert.rejects(
    () => orchestrate.execute(batch, exec),
    (error) =>
      error?.code === 'write-scope-conflict' &&
      error.details[0].path === 'C:/repo/src/a.js' &&
      error.details[0].owner === 'child-1',
  )
  assert.equal(started.length, 1, 'the refused batch never reached the host')

  harness.handlers.get('subagent/end')({ id: 'child-1', stopReason: 'completed' })
  const result = await orchestrate.execute(batch, exec)
  assert.equal(result.agentsStarted, 1, 'settlement released the delegate lease for the batch')
})

test('disposing the plugin clears the lease table', async () => {
  const started = []
  const harness = start({
    subagents: {
      resolveMaxDepth: () => 1,
      startActivation: async () => {
        const childId = `child-${started.length + 1}`
        started.push(childId)
        return { childId }
      },
    },
  })
  const tool = harness.tools.find(({ name }) => name === 'delegate')
  const exec = { agent: { id: 'main-1' }, signal: new AbortController().signal }
  const claim = {
    description: 'edit',
    prompt: 'edit src/a.js',
    cwd: 'C:/repo',
    writeScope: ['src/a.js'],
    provider: 'p',
    model: 'm',
  }

  await tool.execute(claim, exec)
  const installed = harness.effects.find(({ label }) => label === 'orchestrator: write leases')
  assert.equal(typeof installed?.dispose, 'function', 'apply must own the lease table through an effect')
  installed.dispose()
  const next = await tool.execute({ ...claim, description: 'after reload' }, exec)
  assert.equal(next.subagentId, 'child-2', 'a plugin reload drops the old table')
})

test('the retry prompt goes through subagents.prompt, as a queued turn of the child', async () => {
  const calls = []
  const deliverPrompt = mod.deliverRetryPrompt
  const host = {
    subagents: {
      prompt: async (request, signal) => {
        calls.push({ request, signal })
        return { messageId: 'msg-1' }
      },
    },
  }
  assert.equal(await deliverPrompt(host, 'parent-1', 'child-1', '继续'), 'msg-1')
  assert.equal(calls.length, 1)
  const { request, signal } = calls[0]
  // The host hard-codes `source.kind = 'user'` on this path, so the request carries no
  // source at all; `requestId` is what ends up in `source.rpcId` for tracing.
  assert.equal(typeof request.requestId, 'string')
  assert.match(request.requestId, /^[0-9a-f-]{36}$/)
  assert.equal(request.childSessionId, 'child-1')
  assert.equal(request.delivery, 'queue', 'a retry is a new turn, not a steer into a dead one')
  assert.deepEqual(request.content, [{ type: 'text', text: '继续' }])
  assert.equal(typeof signal?.aborted, 'boolean')
  // The parent is no longer part of the request: `prompt()` takes the child session only.
  assert.equal('parentSessionId' in request, false)
  assert.equal('source' in request, false)
})

test('the retry prompt refuses a host without subagents.prompt', async () => {
  await assert.rejects(
    mod.deliverRetryPrompt({ subagents: {} }, 'parent-1', 'child-1', '继续'),
    /does not expose subagents\.prompt/,
  )
  await assert.rejects(mod.deliverRetryPrompt({}, 'parent-1', 'child-1', '继续'), /does not expose subagents\.prompt/)
})

test('the retry notice has its own source kind, so it cannot mask a supervision notice', async () => {
  const queued = []
  const parent = { id: 'p', session: { id: 'parent-session' }, followup: (message) => queued.push(message) }
  const host = fakeSupervisionHost({ parents: new Map([['p', parent]]) })
  const supervision = mod.createSupervision({
    ctx: host.ctx,
    config: {},
    loadLlm: async () => ({ createUserMessage: (input) => input }),
  })
  assert.equal(await supervision.deliverRetry('p', '重试正文', ['child-1']), 'queued')
  assert.equal(queued.length, 1)
  assert.equal(queued[0].content[0].text, '重试正文')
  assert.deepEqual(queued[0].source, { kind: 'orchestrator-retry', form: 'notice', senderSessionId: 'child-1' })
  // The supervision notice keeps the kind `hasPendingNotice` looks for.
  assert.equal(await supervision.deliver('p', '巡检正文', ['child-1']), 'queued')
  assert.deepEqual(queued[1].source, { kind: mod.SUPERVISE_SOURCE_KIND, form: 'notice', senderSessionId: 'child-1' })
})

// ---- Live tool catalog -----------------------------------------------------------------

test('the plugin publishes the tool catalog at start and refreshes it on tools/change', async () => {
  const harness = start({ catalogNames: ['read', 'delegate'] })
  const change = harness.handlers.get('tools/change')
  assert.equal(typeof change, 'function', 'apply must subscribe to tools/change')
  // The first read runs during apply, so a panel opened before any change has a catalog.
  assert.deepEqual(harness.catalog(), ['delegate', 'read'])
  assert.deepEqual(harness.emitted[0], ['settings/document-updated', 'orchestrator', 1])
  assert.equal(harness.logs.warn.length, 0)

  // An unchanged burst publishes nothing: no write, no announcement and no gate refresh.
  change()
  await new Promise((resolve) => setTimeout(resolve, 250))
  assert.equal(harness.emitted.length, 1)

  // A plugin registering a tool moves the catalog, with no plugin reload and no restart.
  harness.catalogNames.push('mcp__demo__ping')
  change()
  change()
  await new Promise((resolve) => setTimeout(resolve, 250))
  assert.deepEqual(harness.catalog(), ['delegate', 'mcp__demo__ping', 'read'])
  assert.equal(harness.emitted.length, 2)
  assert.deepEqual(harness.emitted[1], ['settings/document-updated', 'orchestrator', 2])
})

test('the write that empties the published catalog repairs it in the same event', () => {
  // A volatile field is re-committed from the profile's raw value on every settings write,
  // so a panel write lands with toolCatalog already empty. The write has announced
  // loader/volatile-update by then, so the repair rides that event: no timer, no polling.
  const harness = start({ catalogNames: ['read', 'delegate'] })
  assert.deepEqual(harness.catalog(), ['delegate', 'read'])

  harness.resetCatalog()
  assert.deepEqual(harness.catalog(), [], 'the loader wiped the field')
  harness.handlers.get('loader/volatile-update')()
  assert.deepEqual(harness.catalog(), ['delegate', 'read'], 'the catalog is back before the write returns')

  // The repair is not a one-off: every write repeats the same commit.
  harness.resetCatalog()
  harness.handlers.get('loader/volatile-update')()
  assert.deepEqual(harness.catalog(), ['delegate', 'read'])
  // And the panel is told to re-read, so its rows do not stay on the empty snapshot.
  assert.deepEqual(harness.emitted.at(-1), ['settings/document-updated', 'orchestrator', 3])
})

test('the published catalog includes tools a scope registers for a root agent', async () => {
  const scoped = {
    id: 'root',
    ctx: { tools: { view: () => ({ knownNames: new Set(['subagent']), visible: new Map() }) } },
  }
  const harness = start({
    catalogNames: ['read'],
    agents: { get: () => undefined, list: () => [scoped] },
  })
  assert.deepEqual(harness.catalog(), ['read', 'subagent'])
})

test('deferred switch notice: volatile flip records per main agent and appends once on the next pre-step', async () => {
  const main = fakeAgent({ id: 'main-1' })
  const child = fakeAgent({ id: 'child-1', depth: 1, header: { delegationDepth: 1 } })
  const { created, handlers, handlerOptions, state } = start({ enabled: true })

  const preStep = handlers.get('agent/pre-step')
  assert.equal(typeof preStep, 'function', 'apply must subscribe to agent/pre-step')
  assert.deepEqual(handlerOptions.get('agent/pre-step'), { global: true })

  created({ agent: main.agent, source: 'create' })
  created({ agent: child.agent, source: 'create' })
  const volatile = handlers.get('loader/volatile-update')

  // Baseline only: no change was made, so the first step carries only the user prompt.
  const userMsg1 = { id: 'u1', role: 'user', content: [{ type: 'text', text: 'hello' }], source: { kind: 'user' } }
  const d1 = await preStep(
    { agent: main.agent, messages: [userMsg1], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter', messages: [userMsg1] }),
  )
  assert.deepEqual(d1.messages, [userMsg1])

  // Flip dispatch mode off: nothing is pushed immediately; the notice rides with the next step.
  state.enabled = false
  volatile()

  const userMsg2 = { id: 'u2', role: 'user', content: [{ type: 'text', text: 'read file' }], source: { kind: 'user' } }
  const d2 = await preStep(
    { agent: main.agent, messages: [userMsg2], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter', messages: [userMsg2] }),
  )
  assert.equal(d2.messages.length, 2)
  assert.equal(d2.messages[0], userMsg2)
  assert.equal(d2.messages[1].role, 'user')
  assert.equal(d2.messages[1].source.kind, mod.SWITCH_SOURCE_KIND)
  assert.equal(d2.messages[1].source.form, 'notice')
  assert.match(d2.messages[1].content[0].text, /关闭/)

  // Consumed once: the following step must not repeat the notice.
  const userMsg3 = { id: 'u3', role: 'user', content: [{ type: 'text', text: 'next' }], source: { kind: 'user' } }
  const d3 = await preStep(
    { agent: main.agent, messages: [userMsg3], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter', messages: [userMsg3] }),
  )
  assert.deepEqual(d3.messages, [userMsg3])

  // Flip back on, then round-trip before the next turn: no notice is emitted.
  state.enabled = true
  volatile()
  state.enabled = false
  volatile()
  const d4 = await preStep(
    { agent: main.agent, messages: [userMsg3], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter', messages: [userMsg3] }),
  )
  assert.deepEqual(d4.messages, [userMsg3])

  // Children never receive switch notices.
  state.enabled = true
  volatile()
  const dChild = await preStep(
    { agent: child.agent, messages: [userMsg3], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter', messages: [userMsg3] }),
  )
  assert.deepEqual(dChild.messages, [userMsg3])
})

test('deferred switch notice survives rejected, aborted, and empty steps, and clears on dispose', async () => {
  const main = fakeAgent({ id: 'main-2' })
  const { created, handlers, state } = start({ enabled: true })
  const preStep = handlers.get('agent/pre-step')
  const volatile = handlers.get('loader/volatile-update')
  const disposed = handlers.get('agent/disposed')

  created({ agent: main.agent, source: 'create' })
  state.enabled = false
  volatile()

  const userMsg = { id: 'u1', role: 'user', content: [{ type: 'text', text: 'hi' }], source: { kind: 'user' } }

  // Rejected step leaves the pending notice intact.
  const rejected = await preStep(
    { agent: main.agent, messages: [userMsg], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'reject', reason: 'blocked' }),
  )
  assert.deepEqual(rejected, { kind: 'reject', reason: 'blocked' })

  // Aborted step leaves the pending notice intact.
  const abortedController = new AbortController()
  abortedController.abort()
  const aborted = await preStep(
    { agent: main.agent, messages: [userMsg], step: 1, signal: abortedController.signal },
    async () => ({ kind: 'enter', messages: [userMsg] }),
  )
  assert.deepEqual(aborted.messages, [userMsg])

  // Step 1 with zero messages (no-op turn) leaves the pending notice intact.
  const emptyStep1 = await preStep(
    { agent: main.agent, messages: [], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter', messages: [] }),
  )
  assert.deepEqual(emptyStep1.messages, [])

  // Now a real step runs and receives the notice.
  const delivered = await preStep(
    { agent: main.agent, messages: [userMsg], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter', messages: [userMsg] }),
  )
  assert.equal(delivered.messages.length, 2)
  assert.match(delivered.messages[1].content[0].text, /关闭/)

  // Flip again, then dispose: recreating the same id must start from a fresh baseline.
  state.enabled = true
  volatile()
  disposed({ agent: main.agent })
  created({ agent: main.agent, source: 'create' })
  const afterRecreate = await preStep(
    { agent: main.agent, messages: [userMsg], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter', messages: [userMsg] }),
  )
  assert.deepEqual(afterRecreate.messages, [userMsg])
})

test('createSwitchPreStep degrades gracefully without dropping the notice when dsh-llm fails to load', async () => {
  const { createSwitchNotices } = await import('../lib/switch-notice.js')
  let enabled = true
  const notices = createSwitchNotices({ readEnabled: () => enabled })
  notices.observe('main-x')
  enabled = false
  notices.observe('main-x')

  const warnings = []
  let loads = 0
  const preStep = mod.createSwitchPreStep({
    switchNotices: notices,
    loadLlm: async () => {
      loads += 1
      throw new Error('llm missing')
    },
    logger: { warn: (msg) => warnings.push(msg) },
  })

  const agent = fakeAgent({ id: 'main-x' }).agent
  const userMsg = { id: 'u1', role: 'user', content: [{ type: 'text', text: 'hi' }], source: { kind: 'user' } }
  const first = await preStep(
    { agent, messages: [userMsg], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter', messages: [userMsg] }),
  )
  const second = await preStep(
    { agent, messages: [userMsg], step: 1, signal: new AbortController().signal },
    async () => ({ kind: 'enter', messages: [userMsg] }),
  )
  assert.deepEqual(first.messages, [userMsg])
  assert.deepEqual(second.messages, [userMsg])
  assert.equal(loads, 1)
  assert.equal(warnings.length, 1)
  assert.match(warnings[0], /cannot load @deepseek-ai\/dsh-llm/)
  assert.equal(notices.hasPending('main-x'), true)
})
