import { describe, expect, it } from 'vitest'
import { ApprovalBroker } from '../src/approval.ts'

describe('ApprovalBroker', () => {
  it('答复 allow/reject 结算 wait', async () => {
    const b = new ApprovalBroker()
    const w = b.wait(1000)
    expect(b.hasPending).toBe(true)
    expect(b.answer(true)).toBe(true)
    expect(await w).toBe('allow')
    expect(b.hasPending).toBe(false)
  })

  it('无 pending 时 answer 返回 false', () => {
    expect(new ApprovalBroker().answer(true)).toBe(false)
  })

  it('超时返回 undefined（调用方应 next() 委托）', async () => {
    const b = new ApprovalBroker()
    expect(await b.wait(30)).toBeUndefined()
    expect(b.hasPending).toBe(false)
  })

  it('signal 中止返回 undefined', async () => {
    const b = new ApprovalBroker()
    const ac = new AbortController()
    const w = b.wait(1000, ac.signal)
    ac.abort()
    expect(await w).toBeUndefined()
  })

  it('已有 pending 时新 wait 立即 undefined（不排队）', async () => {
    const b = new ApprovalBroker()
    const w1 = b.wait(1000)
    expect(await b.wait(1000)).toBeUndefined()
    b.answer(false)
    expect(await w1).toBe('reject')
  })
})
