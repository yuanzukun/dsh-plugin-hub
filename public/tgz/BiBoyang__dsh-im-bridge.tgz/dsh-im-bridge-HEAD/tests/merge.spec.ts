import { describe, expect, it } from 'vitest'
import { chatControl, SessionMerger } from '../src/merge.ts'

describe('chatControl', () => {
  it('.. 后缀 = 还有后续', () => {
    expect(chatControl('等一下..')).toEqual({ kind: 'continue', body: '等一下' })
  })
  it('!! 后缀 = 立即提交', () => {
    expect(chatControl('马上做!!')).toEqual({ kind: 'commit', body: '马上做' })
  })
  it('裸 .. / !! 忽略', () => {
    expect(chatControl('..').kind).toBe('ignore')
    expect(chatControl('  !!  ').kind).toBe('ignore')
  })
  it('普通文本 pending', () => {
    expect(chatControl('你好')).toEqual({ kind: 'pending', body: '你好' })
  })
  it('整体 trim 后判断', () => {
    expect(chatControl('  文本..  ')).toEqual({ kind: 'continue', body: '文本' })
  })
})

describe('SessionMerger', () => {
  it('!! 立即 flush，合并多条为 \\n join', () => {
    const snaps: [string, string[]][] = []
    const m = new SessionMerger({ mergeTimeoutMs: 50, onTimeoutFlush: () => {}, onSnapshot: (u, b) => snaps.push([u, b]) })
    expect(m.ingest('u', '第一条').kind).toBe('buffered')
    expect(m.ingest('u', '第二条..').kind).toBe('buffered')
    const r = m.ingest('u', '第三条!!')
    expect(r).toEqual({ kind: 'flush', text: '第一条\n第二条\n第三条' })
    // flush 后快照清空
    expect(snaps.at(-1)).toEqual(['u', []])
    m.dispose()
  })

  it('超时 flush 走回调', async () => {
    const flushed: string[] = []
    const m = new SessionMerger({ mergeTimeoutMs: 30, onTimeoutFlush: (_u, t) => flushed.push(t), onSnapshot: () => {} })
    m.ingest('u', '你好')
    await new Promise((r) => setTimeout(r, 80))
    expect(flushed).toEqual(['你好'])
    m.dispose()
  })

  it('新消息重置超时窗口', async () => {
    const flushed: string[] = []
    const m = new SessionMerger({ mergeTimeoutMs: 60, onTimeoutFlush: (_u, t) => flushed.push(t), onSnapshot: () => {} })
    m.ingest('u', '一')
    await new Promise((r) => setTimeout(r, 40))
    m.ingest('u', '二')
    await new Promise((r) => setTimeout(r, 40))
    expect(flushed).toEqual([]) // 窗口被重置，尚未到 60ms
    await new Promise((r) => setTimeout(r, 50))
    expect(flushed).toEqual(['一\n二'])
    m.dispose()
  })

  it('restore 恢复的快照会被超时 flush', async () => {
    const flushed: string[] = []
    const m = new SessionMerger({ mergeTimeoutMs: 30, onTimeoutFlush: (_u, t) => flushed.push(t), onSnapshot: () => {} })
    m.restore('u', ['崩溃前', '的缓冲'])
    await new Promise((r) => setTimeout(r, 80))
    expect(flushed).toEqual(['崩溃前\n的缓冲'])
    m.dispose()
  })

  it('裸 marker 忽略且不污染缓冲', () => {
    const m = new SessionMerger({ mergeTimeoutMs: 50, onTimeoutFlush: () => {}, onSnapshot: () => {} })
    expect(m.ingest('u', '..').kind).toBe('ignored')
    expect(m.ingest('u', '!!').kind).toBe('ignored')
    m.dispose()
  })

  it('多用户缓冲互不影响', () => {
    const m = new SessionMerger({ mergeTimeoutMs: 1000, onTimeoutFlush: () => {}, onSnapshot: () => {} })
    m.ingest('u1', '甲')
    m.ingest('u2', '乙')
    expect(m.ingest('u1', '丙!!')).toEqual({ kind: 'flush', text: '甲\n丙' })
    m.dispose()
  })
})
