import { describe, expect, it } from 'vitest'
import { normalizeId, parseInbound } from '../src/ilink.ts'

describe('normalizeId', () => {
  it('接受 string/number/float/object', () => {
    expect(normalizeId('abc')).toBe('abc')
    expect(normalizeId(123)).toBe('123')
    expect(normalizeId(1.9)).toBe('1')
    expect(normalizeId({ id: 'x' })).toBe('x')
    expect(normalizeId({ value: 42 })).toBe('42')
    expect(normalizeId('')).toBeUndefined()
    expect(normalizeId(undefined)).toBeUndefined()
    expect(normalizeId({})).toBeUndefined()
  })
})

describe('parseInbound', () => {
  it('标准文本消息', () => {
    const m = parseInbound({
      message_id: 'm1',
      from_user_id: 'u1',
      message_type: 1,
      text: '你好',
      context_token: 'tok',
      create_time_ms: 1700000000000,
    })
    expect(m).toEqual({ messageId: 'm1', fromUserId: 'u1', contextToken: 'tok', text: '你好', createTimeMs: 1700000000000 })
  })

  it('嵌套一层 message 也能解析', () => {
    const m = parseInbound({ message: { msg_id: 777, from_user_id: 'u2', text: 'hi' } })
    expect(m?.messageId).toBe('777')
    expect(m?.text).toBe('hi')
  })

  it('text + item_list 拼接', () => {
    const m = parseInbound({
      message_id: 'm',
      from_user_id: 'u',
      text: 'a',
      item_list: [{ type: 1, text_item: { text: 'b' } }, { type: 2 }],
    })
    expect(m?.text).toBe('ab')
  })

  it('非文本消息（message_type!=1）丢弃', () => {
    expect(parseInbound({ message_id: 'm', from_user_id: 'u', message_type: 3, text: 'x' })).toBeNull()
  })

  it('缺 from_user_id / 空文本丢弃', () => {
    expect(parseInbound({ message_id: 'm', text: 'x' })).toBeNull()
    expect(parseInbound({ message_id: 'm', from_user_id: 'u', text: '  ' })).toBeNull()
  })

  it('无 id 时 fallback 到 from:create_time_ms', () => {
    const m = parseInbound({ from_user_id: 'u', text: 'x', create_time_ms: 123 })
    expect(m?.messageId).toBe('u:123')
  })

  it('异构输入不抛异常', () => {
    expect(parseInbound(null)).toBeNull()
    expect(parseInbound('str')).toBeNull()
    expect(parseInbound(42)).toBeNull()
    expect(parseInbound({ message: 'not-object', from_user_id: 'u', text: 'x' })).not.toBeNull()
  })
})
