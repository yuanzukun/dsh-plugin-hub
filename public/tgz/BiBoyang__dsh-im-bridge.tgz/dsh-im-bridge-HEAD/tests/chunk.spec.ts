import { describe, expect, it } from 'vitest'
import { splitReply } from '../src/chunk.ts'

describe('splitReply', () => {
  it('短文本不加分段前缀', () => {
    expect(splitReply('你好', 1200)).toEqual(['你好'])
  })

  it('恰好等于上限不拆', () => {
    const s = 'a'.repeat(1200)
    expect(splitReply(s, 1200)).toEqual([s])
  })

  it('按码点计数而非 UTF-16 单元（emoji 不被劈开）', () => {
    const emoji = '\u{1F642}' // 🙂，UTF-16 两个代码单元、一个码点
    const s = emoji.repeat(1199) + 'x'
    const parts = splitReply(s, 1200)
    for (const p of parts) expect([...p].length).toBeLessThanOrEqual(1200)
    expect(parts.map((p) => p.replace(/^（\d+\/\d+）/, '')).join('')).toBe(s)
  })

  it('多段带全角前缀且收敛（段号不超过总段数）', () => {
    const s = '汉'.repeat(5000)
    const parts = splitReply(s, 1200)
    expect(parts.length).toBeGreaterThan(1)
    const m = parts[0].match(/^（(\d+)\/(\d+)）/)
    expect(m).not.toBeNull()
    expect(Number(m![2])).toBe(parts.length)
    for (const p of parts) expect([...p].length).toBeLessThanOrEqual(1200)
    // 去掉前缀拼回原文
    expect(parts.map((p) => p.replace(/^（\d+\/\d+）/, '')).join('')).toBe(s)
  })

  it('前缀宽度变化触发段数变化时仍收敛（9999→10000 边界）', () => {
    // 让段数落在 9/10 边界附近：总段数从 1 位数变 2 位数时前缀变宽
    for (const len of [10790, 10791, 10799, 10800, 10810]) {
      const s = 'x'.repeat(len)
      const parts = splitReply(s, 1200)
      for (const p of parts) expect([...p].length).toBeLessThanOrEqual(1200)
      expect(parts.map((p) => p.replace(/^（\d+\/\d+）/, '')).join('')).toBe(s)
    }
  })

  it('极小 maxChars 退化不死循环', () => {
    const parts = splitReply('abcdef', 3)
    expect(parts.join('').replace(/（\d+\/\d+）/g, '')).toBe('abcdef')
  })
})
