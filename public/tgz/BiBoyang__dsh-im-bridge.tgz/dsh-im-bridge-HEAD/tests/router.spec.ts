import { describe, expect, it } from 'vitest'
import { routeText } from '../src/router.ts'

describe('routeText', () => {
  it('批准/拒绝词表（含英文与斜杠）', () => {
    expect(routeText('批准').kind).toBe('approve')
    expect(routeText('  同意 ').kind).toBe('approve')
    expect(routeText('yes').kind).toBe('approve')
    expect(routeText('/yes').kind).toBe('approve')
    expect(routeText('拒绝').kind).toBe('reject')
    expect(routeText('NO').kind).toBe('reject')
  })

  it('/bind 带参数', () => {
    expect(routeText('/bind abc-123')).toEqual({ kind: 'bind', sessionId: 'abc-123' })
  })

  it('/bind 裸命令落到 status', () => {
    expect(routeText('/bind').kind).toBe('status')
    expect(routeText('/bind ').kind).toBe('status')
    expect(routeText('/bind   ').kind).toBe('status')
  })

  it('/status /unbind /help 与中文艺名', () => {
    expect(routeText('/status').kind).toBe('status')
    expect(routeText('状态').kind).toBe('status')
    expect(routeText('/unbind').kind).toBe('unbind')
    expect(routeText('/help').kind).toBe('help')
    expect(routeText('帮助').kind).toBe('help')
  })

  it('普通文本与 .. / !! 后缀都走 chat（后缀归 merger 管）', () => {
    expect(routeText('帮我看看')).toEqual({ kind: 'chat', text: '帮我看看' })
    expect(routeText('等我..')).toEqual({ kind: 'chat', text: '等我..' })
    expect(routeText('提交!!')).toEqual({ kind: 'chat', text: '提交!!' })
  })

  it('正文里含"批准"不误判（精确匹配）', () => {
    expect(routeText('批准这个词怎么用').kind).toBe('chat')
  })
})
