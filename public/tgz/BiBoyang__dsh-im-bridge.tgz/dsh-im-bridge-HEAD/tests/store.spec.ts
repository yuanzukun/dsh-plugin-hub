import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { BridgeStore, MAX_SEEN_IDS, TRIM_SEEN_IDS_TO } from '../src/store.ts'

let dir: string | undefined
afterEach(() => {
  if (dir) rmSync(dir, { recursive: true, force: true })
  dir = undefined
})

function makeStore(): BridgeStore {
  dir = mkdtempSync(join(tmpdir(), 'dsh-im-bridge-test-'))
  return new BridgeStore(join(dir, 'state.json'))
}

describe('BridgeStore', () => {
  it('去重：见过返回 true，未见记录后返回 true', () => {
    const s = makeStore()
    expect(s.checkAndMark('a')).toBe(false)
    expect(s.checkAndMark('a')).toBe(true)
    expect(s.checkAndMark('b')).toBe(false)
  })

  it('去重跨重启有效（持久化）', () => {
    const s = makeStore()
    s.checkAndMark('persisted-id')
    s.flush()
    const s2 = new BridgeStore(join(dir!, 'state.json'))
    expect(s2.checkAndMark('persisted-id')).toBe(true)
  })

  it('超过 MAX_SEEN_IDS 裁剪到 TRIM_SEEN_IDS_TO', () => {
    const s = makeStore()
    for (let i = 0; i < MAX_SEEN_IDS + 10; i++) s.checkAndMark(`id-${i}`)
    s.flush()
    const raw = JSON.parse(readFileSync(join(dir!, 'state.json'), 'utf8'))
    // 第 1001 条触发裁剪到 500，之后又进来 9 条 → 509
    expect(raw.seenIds.length).toBe(TRIM_SEEN_IDS_TO + 9)
    // 最旧的已被裁掉，最新的还在
    const s2 = new BridgeStore(join(dir!, 'state.json'))
    expect(s2.checkAndMark('id-0')).toBe(false)
    expect(s2.checkAndMark(`id-${MAX_SEEN_IDS + 9}`)).toBe(true)
  })

  it('context_token 更新与读取', () => {
    const s = makeStore()
    expect(s.contextToken('u')).toBeUndefined()
    s.updateContextToken('u', 'tok1')
    s.updateContextToken('u', 'tok2')
    expect(s.contextToken('u')).toBe('tok2')
    s.flush()
    const s2 = new BridgeStore(join(dir!, 'state.json'))
    expect(s2.contextToken('u')).toBe('tok2')
  })

  it('白名单与绑定会话持久化', () => {
    const s = makeStore()
    s.setAllowedUserId('wx-user-1')
    s.setBoundSessionId('sess-1')
    s.flush()
    const s2 = new BridgeStore(join(dir!, 'state.json'))
    expect(s2.allowedUserId).toBe('wx-user-1')
    expect(s2.boundSessionId).toBe('sess-1')
  })

  it('损坏的状态文件不崩，从空状态开始', () => {
    const s = makeStore()
    s.flush()
    writeFileSync(join(dir!, 'state.json'), 'not json{{{')
    const s2 = new BridgeStore(join(dir!, 'state.json'))
    expect(s2.allowedUserId).toBe('')
  })
})
