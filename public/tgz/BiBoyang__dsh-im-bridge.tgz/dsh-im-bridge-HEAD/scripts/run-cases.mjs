#!/usr/bin/env node
/**
 * 用 dsh-eval-harness 的 runner 跑本仓库 cases/ 回归用例（M6）。
 * 用法：node scripts/run-cases.mjs
 * 需要 DEEPSEEK_API_KEY 在环境里；dsh 用源码 checkout 的 CLI。
 */
import { runEval } from '/Users/boyang/Desktop/dsh-eval-harness/lib/runner.js'
import { renderMarkdown } from '/Users/boyang/Desktop/dsh-eval-harness/lib/report.js'

const root = new URL('..', import.meta.url).pathname
const report = await runEval({
  casesDir: `${root}cases`,
  outputDir: `${root}.eval-out`,
  dshBin: `node /Users/boyang/deepseek-harness/apps/cli/lib/bin.js`,
})
console.log(renderMarkdown(report))
process.exit(report.cases.every((c) => c.status === 'pass') ? 0 : 1)
