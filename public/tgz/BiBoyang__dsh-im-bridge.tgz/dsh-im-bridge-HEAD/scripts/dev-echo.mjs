#!/usr/bin/env node
/**
 * M3 通道层独立验证：不依赖 DSH，直接跑 iLink 登录 + 长轮询 + Echo。
 * 用法：node scripts/dev-echo.mjs [statePath]
 * 扫码后从手机发消息，收到 Echo 回复即通道层验证通过。Ctrl-C 退出。
 */
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { runBridgeLoop } from '../lib/bridge.js'
import { ILinkClient } from '../lib/ilink.js'
import { BridgeStore } from '../lib/store.js'

const statePath = process.argv[2] ?? join(tmpdir(), 'dsh-im-bridge-dev', 'state.json')
const consoleLog = {
  debug: () => {},
  info: (m, ...a) => console.log('[info]', m, ...a),
  warn: (m, ...a) => console.log('[warn]', m, ...a),
}

const abort = new AbortController()
process.on('SIGINT', () => abort.abort())

console.log('state:', statePath)
await runBridgeLoop(
  {
    client: new ILinkClient(),
    store: new BridgeStore(statePath),
    log: consoleLog,
    pollTimeoutSecs: 70,
    chunkMaxChars: 1200,
    onMessage: async (msg) => {
      console.log(`[recv] ${msg.fromUserId}: ${msg.text}`)
      return `Echo: ${msg.text}`
    },
  },
  abort.signal,
)
console.log('bye')
