# 任务：开发 DSH 微信桥插件（dsh-wechat-bridge）

你是 Kimi Code CLI。用户（BiBoyang）要你开发一个 DeepSeek Harness（DSH）插件：把 DSH 桥接到微信，让用户在手机上远程驱动/监控/批准 agent。

## 背景（已完成的调研结论，直接用不要重做）

### 竞品现状（2026-08-13 核实）

IM 桥方向已有 9 个竞品，全是一天之内冒出来的：

- Jesse-njx/dsh-chatnode-wechat — iLink 网关 + 微信聊天/监控/批准（最直接竞品）
- wuyuanjiang1/dsh2wechat、wssfk12138/dsh-wechat-notify — 微信 ClawBot 桥/通知
- dbydd/dsh-onlyne — QQ/微信/飞书/Telegram 多平台网关
- Roy-oss1/dsh-lark、imetn/dsh-lark-bridge、PlutoKeating/dsh-lark-bot — 飞书
- congchuanling-dot/DSH-Telegram-Relay、LoserFox/telegram、ben7am1n/dsh-telegram — Telegram

**差异化策略**：不靠"先做出来"（已经晚了），靠质量取胜。用户的 AMClaw 项目在微信通道上踩过所有坑：iLink 扫码登录、长轮询、消息去重、context_token 缓存、`..`/`!!`/超时合并、长回复分段（1200 字符拆分）、会话持久化恢复。这些是竞品都没有或做得糙的地方。开工前先研究竞品 1-2 个（重点 dsh-chatnode-wechat），明确我们的差异点写进 README。

### 用户的可复用资产

- **AMClaw**（~/Desktop/AMClaw）：用户的 Rust 微信 bot，有完整的 iLink 登录/轮询/会话/去重/分段实现（src/chat_adapter、src/session_router.rs、src/command_router）。插件用 TypeScript 写，但协议细节和交互设计从这里抄。注意先读该仓库的 AGENTS.md 和 README.md。
- **dsh-eval-harness**（~/Desktop/dsh-eval-harness，已发布 github:BiBoyang/dsh-eval-harness）：用户刚做完的评测插件，桥插件的用例应该用它来写回归测试（cases_dir 指过来即可）。它也是 DSH 插件的完整参考实现。

## DSH 插件开发要点（已实测验证，别再猜）

### 形态与契约

- 分发形态 = npm 包（bundle 形态），无独立 manifest。package.json 关键字段：
  - `name`/`version`/`main`（→ lib/index.js）
  - `"dsh": { "bundle": { "patch": "./cordis.patch.yml" } }`
  - scripts 必须有 build/prepack/test
  - **dependencies 必须自包含**：`@deepseek-ai/dsh-tools` 等官方包已在 npm 公开发布（0.0.1-rc.1），放进 dependencies（不要依赖 profile 闭包注入，link: 安装会因 realpath 逃逸而解析失败）。`@deepseek-ai/cordis` 保持 peer(`>=0.0.1-0`)+dev(`4.0.1`)，只在类型层用，不要运行时 import（双副本坑）。
  - 注意 `@deepseek-ai/dsh-tools` 的运行时 import 闭包还包括 dsh-llm/dsh-scope/dsh-session/dsh-timeout，都要显式声明
- Cordis entry（src/index.ts）：具名导出 `name`/`inject`/`apply(ctx, config)`，**不能有 default export**；用到的服务必须在 `inject` 声明否则启动即抛
- cordis.patch.yml 用 `- insert:` 行挂自身，row id 用插件名，name 含 @ 要加引号
- tsconfig 三件套：allowImportingTsExtensions + rewriteRelativeImportExtensions + lib ES2024；src 内部相对导入用 `./x.js` 形式（tsc 不重写 d.ts 里的 .ts 导入）
- 构建失败必须非零退出；lib/ 产物提交入库（git 安装不跑构建）

### 关键事件点（桥的命脉，路径基于主仓库源码已核实）

- **turn 完成**：durable 事件 `turn/end`，payload `{ turn, reason }`，reason.kind = completed/aborted/blocked/error/max-tokens/interrupted（packages/core/session/src/types.ts:252）；live 拦截点 `agent/turn-stopping`（serial，无 next）
- **批准请求**：live waterfall 事件 `approval/request(req, next)`（packages/interaction/user-approval/src/index.ts:30）——桥插件在这里挂监听器，把批准请求推到微信，等用户回复后决定 allow/reject；durable 审计事件 `approval/asked` / `approval/decided`
- **工具调用**：`tools/pre-execute`（waterfall 可 allow/deny/ask）、`tools/post-execute`、`tools/result`（emit）
- **会话事件流**：`ctx.on('session/event', ...)` 拿全部 durable 事件（user/message、assistant/message、tool/call、tool/result）
- **后台任务**：长轮询循环应该挂在 `ctx.jobs`（后台任务缝）上，不要裸 setInterval
- waterfall 监听器**必须调 next()**，否则短路整条链

### 会话落盘（如需读 trace）

- 路径 `$DSH_HOME/sessions/--<cwd编码>--/<session-id>/session.jsonl.zstd`，默认多帧 zstd（每 200ms 一批追加一帧）
- 读真实用户会话要守纪律：只读、不打印内容、opt-in

### 安装与调试

- 本机没有全局 dsh 命令。两种方式：
  - `npx -y @deepseek-ai/dsh@0.1.0-rc.6 <args>`（npm 已公开发布）
  - 源码 checkout：~/deepseek-harness 已构建，`node /Users/boyang/deepseek-harness/apps/cli/lib/bin.js <args>`
- 装插件：`dsh plugin --profile web add <本地目录>`（link: 方式）；web 和 headless 是两个 profile 要分别装
- **改代码后必须 pnpm build + 重启 web 才生效**（ESM 缓存）。用户的 web 跑法：kill 掉 `pnpm dsh web` 进程后 `cd ~/deepseek-harness && nohup pnpm dsh web > /tmp/dsh-web.log 2>&1 &`，UI 在 http://127.0.0.1:3080
- 验证挂载：`dsh --profile web --dump-config | grep <row-id>`
- headless 端到端：`dsh --profile headless "任务"`（退出码 0=completed）；CLI 直跑需要 DEEPSEEK_API_KEY 在环境变量里，web 里调工具自带凭据
- `--patch <path>` overlay（可重复，空格形式不是=）可以最高优先级替换任何插件 config，评测/调试时用它替换 `session-persistence-jsonl` 行的 root/compression

### 权威参考资料（本地，先读再动手）

- ~/Desktop/dsh-research/deepseek-harness — 主仓库克隆（docs/architecture.md、docs/event-producer-consumer.md、apps/cli/README.md）
- ~/Desktop/dsh-research/plugin-registry/skills/make-dsh-plugin/ — 官方插件开发引导（SKILL.md + references/）
- ~/Desktop/dsh-research/dsh-plugin-dev/skills/dsh-plugin-dev/references/ — 踩坑档案（build-pitfalls.md、tool-plugin.md、testing.md、publish.md）
- ~/Desktop/dsh-eval-harness — 可跑的完整插件参考实现

## 产品定义

### 核心场景

1. 用户在电脑上用 DSH Web 跑长任务，离开电脑
2. agent turn 完成 / 需要批准 / 出错 → 微信推消息给用户
3. 用户在微信回复：批准/拒绝/追加指令/查看状态
4. 用户也可以主动在微信发起新任务，进指定 DSH 会话

### v0.1 范围（控制 scope，别贪多）

- iLink 扫码登录 + 长轮询收消息（协议细节抄 AMClaw src/chat_adapter）
- DSH → 微信：turn/end（completed/error/aborted）推送 + approval/asked 推送（含工具名和原因）
- 微信 → DSH：文本消息注入当前绑定会话作为用户消息；回复「批准/拒绝」应答 pending approval
- 消息去重、长回复分段（1200 字符）、`..`/`!!`/超时合并（全部抄 AMClaw 设计）
- 单用户白名单（只有绑定的 user_id 能驱动，安全第一）
- 会话绑定：默认绑定最近活跃会话，`/bind <session>` 命令切换

### 明确不做（v0.1）

- 多用户/群聊、图片/文件消息、多平台（QQ/飞书/Telegram）、Web UI 面板、定时任务调度

### 安全红线

- 微信通道等于绕过本机批准体系：approval 应答必须校验消息来自白名单 user_id + 对应 pending approval id
- 不打印/不落盘聊天内容明文以外的任何东西；token 不落库
- 默认 restricted：微信来的消息只能进会话流，不能直接执行任意 shell

## 里程碑

1. 读完参考资料 + 竞品（dsh-chatnode-wechat 至少读 README），写 README 的差异化段落
2. 插件骨架能 boot（dump-config 可见、web 加载无报错）
3. iLink 登录 + 收消息 + Echo 回复（纯通道层，不接 DSH 事件）
4. DSH → 微信推送（turn/end + approval/asked）
5. 微信 → DSH 注入 + approval 应答闭环
6. 用 dsh-eval-harness 写回归用例（桥插件的工具行为可评测）
7. 真机端到端：web 里跑一个会触发 approval 的任务，手机上批准，任务继续
8. 发布前检查名字可用（GitHub 搜 dsh-wechat-bridge / dsh-im-bridge，2026-08-13 时均无占用，但以当时搜索为准）

## 工作目录

~/Desktop/dsh-wechat-bridge（已建空目录）。git init，commit 走用户惯例。用户的 AGENTS.md 全局约定（~/AGENTS.md）先读，里面有 `收尾`/`o` 口令等工作流约定。
