// 生成一份带示例内容的 cardian 仓库，供 dsh web 知识中心 / Obsidian 直接查看。
// 用法：node examples/demo.mjs [vaultPath]   （默认 ./cardian-vault）
//
// 历史坑：旧版走 `apply(ctx, ...)` + `ctx.cardian`，依赖 cordis Proxy 才生效，
// 在纯 stub ctx 下 `ctx.cardian` 为 undefined 而崩溃。这里改用框架无关的
// createCardian 核心引擎，CLI / 测试 / 本示例共用同一入口，幂等可重复执行。
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createCardian } from '../core/index.js'

// 以本文件位置锚定包根，避免依赖调用方 cwd（从仓库根跑也不会解析错位）。
const rootDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..')
const vaultPath = process.argv[2] ?? path.join(rootDir, 'cardian-vault')

const cardian = createCardian({
  vaultPath,
  allowedRoots: [rootDir, process.cwd()],
  logger: { info() {}, warn() {}, error() {}, debug() {} },
})
await cardian.init()

// ---- 知识卡片：内容刻意覆盖 Markdown 渲染器的各类元素 --------------------
const cards = [
  {
    title: '闭包 Closure',
    category: 'frontend',
    tags: ['javascript', '基础', '作用域'],
    content: [
      '# 闭包',
      '',
      '闭包 = **函数** + 其 *词法环境*。函数可以捕获并访问定义时作用域里的变量。',
      '',
      '## 典型用途',
      '',
      '- 数据私有化（模块模式）',
      '- 函数工厂',
      '- 防抖 / 节流',
      '',
      '```js',
      'function counter() {',
      '  let n = 0',
      '  return () => ++n',
      '}',
      '```',
      '',
      '> 注意：循环里用 `var` 捕获会踩坑，改用 `let`。相关：[[React 状态不可变]]',
    ].join('\n'),
  },
  {
    title: 'React 状态不可变',
    category: 'frontend',
    tags: ['react', '基础', '状态管理'],
    content: [
      '# 状态不可变',
      '',
      '直接修改 state **不会**触发渲染，必须返回新引用。',
      '',
      '| 操作 | 是否触发渲染 |',
      '| --- | --- |',
      '| `state.x = 1` | 否 |',
      '| `setState({ ...s })` | 是 |',
      '',
      '延伸阅读见 [React 官方文档](https://react.dev)。',
    ].join('\n'),
  },
  {
    title: 'Rust 所有权',
    category: 'systems',
    tags: ['rust', '内存', '基础'],
    content: [
      '# 所有权系统',
      '',
      '每个值有**唯一**所有者；离开作用域即被 `drop`；借用规则保证内存安全。',
      '',
      '1. 移动（move）语义',
      '2. 不可变借用 `&T`',
      '3. 可变借用 `&mut T`（同一时刻仅一个）',
    ].join('\n'),
  },
  {
      title: '事件循环 Event Loop',
    category: 'frontend',
    tags: ['javascript', '异步', '运行时'],
    content: [
      '# 事件循环',
      '',
      '宏任务与微任务交替执行；`Promise.then` 属于**微任务**，优先于 `setTimeout`。',
      '',
      '- call stack',
      '- microtask queue',
      '- macrotask queue',
    ].join('\n'),
  },
  {
    title: 'LSM Tree 存储引擎',
    category: 'systems',
    tags: ['数据库', '存储', '进阶'],
    content: [
      '# LSM-Tree',
      '',
      '写优先结构：内存 memtable 顺序刷盘 → 分层 compaction。适合写多读少。',
      '',
      '与 *B+ Tree* 的取舍详见 [[Rust 所有权]] 所在系统的存储层讨论。',
    ].join('\n'),
  },
  {
    title: 'Typert 远端桥参数契约',
    category: 'dsh',
    tags: ['dsh', '网关', '契约'],
    content: [
      '# 三处同步铁律',
      '',
      '新增 Remote 方法必须同步：`typert.js` / `index.js` / `controller.ts`。',
      '',
      '其中 **零 wire 参数**方法（describe/status/doctor/schema）任何一处多传或缺传都会触发',
      '`expected N argument(s), got M`。',
    ].join('\n'),
  },
]
for (const c of cards) await cardian.cards.upsert(c)

// ---- 记忆 ----------------------------------------------------------------
await cardian.memory.upsert({
  title: '项目偏好',
  scope: 'project-x',
  tags: ['preference', '规范'],
  importance: 5,
  facts: ['TypeScript only', 'pnpm workspace', '中文注释'],
  content: '该用户偏好 TypeScript + pnpm workspace，注释统一用中文。',
})
await cardian.memory.upsert({
  title: '全局约定',
  scope: 'global',
  tags: ['规范'],
  importance: 3,
  content: '时间统一用 UTC，提交信息遵循 Conventional Commits。',
})
await cardian.memory.upsert({
  title: '排障线索：面板 API 报错',
  scope: 'project-x',
  tags: ['调试', 'dsh'],
  importance: 4,
  content: '面板报 `expected 1 argument(s), got 0` 时，先查三处清单的零 wire 集合是否漂移。',
})

// ---- RepoWiki：以 cardian 自身 core/ 为例，自动生成带 import 边的依赖图谱 ----
await cardian.wiki.ingest(path.join(rootDir, 'core'), { repoName: 'cardian-core', maxFiles: 14 })

const status = await cardian.status()
const doctor = await cardian.doctor()
const cloud = await cardian.tagCloud()
const repos = await cardian.wiki.listRepos()
const graph = repos.length ? await cardian.wiki.graph(repos[0]) : { edges: [] }

console.log('✅ 示例仓库已生成：', vaultPath)
console.log('   分区统计：', JSON.stringify(status.sections))
console.log('   RepoWiki 仓库：', repos.join(', ') || '(无)')
console.log('   标签数：', cloud.length, ' 依赖图谱边数：', graph.edges.length)
console.log('   健康：', doctor.healthy ? 'OK' : '有问题', ' 问题数：', (doctor.problems || []).length)
