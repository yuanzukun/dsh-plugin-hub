import { test, beforeEach } from 'node:test'
import { strict as assert } from 'node:assert'
import { mkdtemp, writeFile, mkdir, readFile, readdir, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import { createCardian } from '../core/index.js'
import { VaultStore } from '../core/store.js'
import { apply } from '../src/index.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

let vaultPath
let cardian

beforeEach(async () => {
  vaultPath = await mkdtemp(path.join(tmpdir(), 'cardian-test-'))
  cardian = createCardian({ vaultPath })
  await cardian.init()
})

test('init creates three sections and MOC indexes', async () => {
  const entries = await readdir(vaultPath)
  assert.ok(entries.includes('Cards') && entries.includes('Memory') && entries.includes('Repos'))
  for (const dir of ['Cards', 'Memory', 'Repos']) {
    const files = await readdir(path.join(vaultPath, dir))
    assert.ok(files.includes('README.md'), `${dir} has MOC`)
  }
})

test('card upsert is idempotent and stable', async () => {
  const a = await cardian.cards.upsert({ title: '闭包 Closure', content: '闭包 = 函数 + 词法环境。', tags: ['js'], category: 'frontend', source: 'MDN' })
  const b = await cardian.cards.upsert({ title: '闭包 Closure', content: '闭包更新后的定义。' })
  assert.equal(a.id, b.id, 'id stable across updates')
  assert.equal(a.created, b.created, 'created stable across updates')
  assert.equal(b.rel, a.rel, 'updates in place')
  const got = await cardian.cards.get('闭包 Closure')
  assert.equal(got.source, 'MDN')
  assert.ok(got.body.includes('更新后'))
})

test('editing by id with a renamed title updates in place (panel safe-save)', async () => {
  const a = await cardian.cards.upsert({ title: '初版标题', content: 'v1', category: 'frontend' })
  // 面板编辑：携带 id + 新标题 → 原地更新，不得重复建卡
  const b = await cardian.cards.upsert({ id: a.id, title: '改名后的标题', content: 'v2', category: 'frontend' })
  assert.equal(b.id, a.id, 'id preserved across rename')
  const cards = await cardian.cards.list()
  assert.equal(cards.length, 1, 'rename must not create a second card')
  assert.ok(cards.some((c) => c.title === '改名后的标题'))
  // 旧标题作为文件名 stem 别名仍可解析，且指向同一张卡（链接不断）
  const byOld = await cardian.cards.get('初版标题')
  assert.equal(byOld.id, a.id, 'old title still resolves to the same note (stem alias)')
  assert.equal(byOld.title, '改名后的标题')
})

test('slug collisions are disambiguated', async () => {
  const x = await cardian.cards.upsert({ title: 'Foo Bar!', content: 'x' })
  const y = await cardian.cards.upsert({ title: 'Foo-Bar', content: 'y' })
  assert.notEqual(x.rel, y.rel, 'distinct files for colliding slugs')
  assert.equal((await cardian.cards.list()).length, 2)
})

test('memory commit preserves facts and importance', async () => {
  await cardian.memory.upsert({
    title: '项目偏好',
    content: 'TS + pnpm。',
    scope: 'project-x',
    facts: ['TS only', 'pnpm workspace'],
    importance: 5,
  })
  const got = await cardian.memory.get('项目偏好')
  assert.equal(got.importance, 5)
  assert.deepEqual(got.facts, ['TS only', 'pnpm workspace'])
  assert.ok(got.body.includes('## Facts'))
})

test('wiki ingest skips node_modules and resolves by repo+path', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'cardian-repo-'))
  await mkdir(path.join(repo, 'src', 'lib'), { recursive: true })
  await writeFile(path.join(repo, 'README.md'), '# demo\n')
  await writeFile(path.join(repo, 'src', 'lib', 'store.js'), 'function createStore() {}\n')
  await mkdir(path.join(repo, 'node_modules', 'x'), { recursive: true })
  await writeFile(path.join(repo, 'node_modules', 'x', 'skip.js'), '// skip\n')

  const ingest = await cardian.wiki.ingest(repo, { repoName: 'demo' })
  assert.equal(ingest.count, 2, 'README.md + store.js only')

  const page = await cardian.wiki.getByPath('demo', 'src/lib/store.js')
  assert.ok(page)
  assert.equal(page.language, 'javascript')
  assert.ok(page.body.includes('代码摘录'))

  await cardian.wiki.upsert({ repo: 'demo', path: 'src/lib/store.js', content: '数据层唯一入口。', summary: '数据层' })
  const enriched = await cardian.wiki.getByPath('demo', 'src/lib/store.js')
  assert.equal(enriched.summary, '数据层')
  assert.deepEqual(await cardian.wiki.listRepos(), ['demo'])
})

test('keyword search ranks by relevance and scopes by type', async () => {
  await cardian.cards.upsert({ title: '闭包 Closure', content: '函数与词法环境。', tags: ['js'] })
  await cardian.cards.upsert({ title: 'React 状态', content: 'setState 返回新引用。', tags: ['react'] })
  await cardian.memory.upsert({ title: '全局约定', content: '统一 UTC。', tags: ['ops'] })

  const hits = await cardian.search('词法环境', { semantic: false })
  assert.equal(hits.length, 1)
  assert.equal(hits[0].title, '闭包 Closure')

  const cardOnly = await cardian.search('约定', { type: 'memory', semantic: false })
  assert.equal(cardOnly.length, 1)
  assert.equal(cardOnly[0].type, 'memory')
})

test('hybrid semantic search returns scored results', async () => {
  await cardian.cards.upsert({ title: '闭包', content: '函数可以捕获定义时作用域里的变量。' })
  await cardian.cards.upsert({ title: '对象', content: '键值对的集合。' })
  const hits = await cardian.search('函数 变量 捕获', { semantic: true })
  assert.ok(hits.length >= 1)
  assert.equal(hits[0].title, '闭包')
  assert.ok('semantic' in hits[0] && 'keyword' in hits[0])
})

test('tag cloud aggregates counts', async () => {
  await cardian.cards.upsert({ title: 'A', content: 'x', tags: ['js', '基础'] })
  await cardian.cards.upsert({ title: 'B', content: 'y', tags: ['js'] })
  const cloud = await cardian.tagCloud({ type: 'card' })
  const js = cloud.find((t) => t.tag === 'js')
  assert.equal(js.count, 2)
})

test('backlinks and related are computed from wikilinks and tags', async () => {
  const a = await cardian.cards.upsert({ title: '源头笔记', content: '基础概念。', tags: ['基础'] })
  await cardian.cards.upsert({
    title: '引用笔记',
    content: `参见 [[${a.rel.split('/').pop().replace('.md', '')}]] 和 [[${'源头笔记'}]]。`,
    tags: ['基础'],
  })
  const back = await cardian.backlinks('源头笔记')
  assert.equal(back.length, 1)
  assert.equal(back[0].title, '引用笔记')
  const related = await cardian.related('源头笔记')
  assert.ok(related.some((r) => r.title === '引用笔记'))
})

test('export/import round-trips the whole vault', async () => {
  await cardian.cards.upsert({ title: '持久化', content: '重要内容。', tags: ['keep'] })
  await cardian.memory.upsert({ title: '偏好', content: '记住这个。', scope: 'global' })
  const snapshot = await cardian.exportJson()
  assert.ok(snapshot.count >= 2)

  const fresh = createCardian({ vaultPath: vaultPath })
  const result = await fresh.importJson(snapshot)
  assert.equal(result.imported, snapshot.count)
  assert.ok(await fresh.cards.get('持久化'))
  assert.ok(await fresh.memory.get('偏好'))
})

test('importMarkdownFolder routes by frontmatter type', async () => {
  const dir = path.join(__dirname, 'fixtures', 'markdown-import')
  const result = await cardian.importMarkdownFolder(dir)
  assert.equal(result.count, 2)
  const card = await cardian.cards.get('Git 常用命令')
  assert.ok(card)
  const mem = await cardian.memory.get('部署约定')
  assert.equal(mem.scope, 'ops')
})

test('path traversal is rejected and no temp files remain', async () => {
  const store = new VaultStore(vaultPath)
  await assert.rejects(() => store.write('../escape.md', { frontmatter: {}, body: '' }))
  await store.write('Cards/x.md', { frontmatter: { title: 'x' }, body: 'y' })
  const all = await readdir(path.join(vaultPath, 'Cards'), { recursive: true })
  assert.ok(!all.some((f) => f.endsWith('.tmp')), 'no orphan temp files after atomic write')
})

test('adapter registers 30 tools with behavior hints', async () => {
  const tools = new Map()
  const ctx = {
    tools: { register: (def) => tools.set(def.name, def) },
    provide: (key, value) => { ctx[key] = value },
    logger: console,
  }
  apply(ctx, { vaultPath })
  await ctx.cardian.ready
  assert.ok(tools.size >= 36, "tool surface grew: " + tools.size)
  assert.equal(tools.get('cardian.status').readOnly, true)
  assert.equal(tools.get('cardian.card.upsert').idempotent, true)
  assert.equal(tools.get('cardian.card.delete').destructive, true)
  assert.equal(tools.get('cardian.card.delete').readOnly, false)

  const status = await tools.get('cardian.status').execute()
  assert.equal(status.vaultPath, path.resolve(vaultPath))
})

test('search does not return empty when topK is omitted (NaN fix)', async () => {
  await cardian.cards.upsert({ title: '闭包', content: '函数与词法环境。' })
  const hits = await cardian.search('词法', {}) // topK omitted entirely
  assert.ok(Array.isArray(hits) && hits.length === 1)
})

test('changing category relocates the note into the new folder', async () => {
  await cardian.cards.upsert({ title: '迁移卡', content: 'x', category: 'frontend' })
  await cardian.cards.upsert({ title: '迁移卡', content: 'y', category: 'backend' })
  assert.equal((await cardian.cards.list({ group: 'backend' })).length, 1)
  assert.equal((await cardian.cards.list({ group: 'frontend' })).length, 0)
  const got = await cardian.cards.get('迁移卡')
  assert.equal(got.category, 'backend')
  assert.ok(got.rel.startsWith('Cards/backend/'))
})

test('concurrent upserts of the same title do not lose updates', async () => {
  const results = await Promise.all(
    Array.from({ length: 8 }, (_, i) => cardian.cards.upsert({ title: '竞态', content: `v${i}` }))
  )
  const ids = new Set(results.map((r) => r.id))
  assert.equal(ids.size, 1, 'single stable id across concurrent upserts')
  assert.equal((await cardian.cards.list()).length, 1)
})

test('tags containing commas round-trip losslessly', async () => {
  await cardian.cards.upsert({ title: '逗号标签', content: 'x', tags: ['foo,bar', 'baz'] })
  const got = await cardian.cards.get('逗号标签')
  assert.deepEqual(got.tags, ['foo,bar', 'baz'])
})

test('numeric title is normalized to string on parse', async () => {
  const { parseFrontmatter } = await import('../core/frontmatter.js')
  const { frontmatter } = parseFrontmatter('---\ntitle: 2024\ntags: [42, 7]\n---\nbody')
  assert.equal(frontmatter.title, '2024')
  assert.deepEqual(frontmatter.tags, ['42', '7'])
})

test('recall ranks by importance and budgets results', async () => {
  await cardian.memory.upsert({ title: '重要部署', content: '生产用蓝绿发布。', importance: 5, tags: ['deploy'] })
  await cardian.memory.upsert({ title: '次要部署', content: '部署相关的小事。', importance: 1, tags: ['deploy'] })
  const recall = await cardian.recall('部署', { type: 'memory', topK: 2 })
  assert.equal(recall.count, 2)
  assert.equal(recall.results[0].title, '重要部署')
})

test('adapter tools return structured errors instead of throwing', async () => {
  const tools = new Map()
  const ctx = { tools: { register: (def) => tools.set(def.name, def) }, provide: (key, value) => { ctx[key] = value }, logger: console }
  apply(ctx, { vaultPath })
  await ctx.cardian.ready
  const res = await tools.get('cardian.card.upsert').execute({ title: '', content: '' })
  assert.equal(res.ok, false)
  assert.equal(res.error.code, 'VALIDATION')
})

test('config validation fails fast on invalid values', async () => {
  const { createCardian } = await import('../core/index.js')
  assert.throws(() => createCardian({ vaultPath: '' }), /非空/)
  assert.throws(() => createCardian({ embedderDim: -1 }), /正整数/)
  const c = createCardian({ vaultPath, searchAlpha: 9 })
  assert.equal(c.config.searchAlpha, 1, 'searchAlpha clamped to [0,1]')
})

test('tags with interior quotes and # in title round-trip losslessly', async () => {
  await cardian.cards.upsert({ title: 'Kubernetes #101', content: 'x', tags: ['a"b', 'c'] })
  const got = await cardian.cards.get('Kubernetes #101')
  assert.equal(got.title, 'Kubernetes #101')
  assert.deepEqual(got.tags, ['a"b', 'c'])
})

test('markdown starting with a horizontal rule is not treated as frontmatter', async () => {
  const { parseFrontmatter } = await import('../core/frontmatter.js')
  const { frontmatter, body, hasFrontmatter } = parseFrontmatter('---\nthis is not fm\n---\nreal body')
  assert.equal(hasFrontmatter, false)
  assert.ok(body.includes('real body') && body.includes('this is not fm'))
  assert.deepEqual(frontmatter, {})
})

test('importJson rejects traversal up-front without partial writes', async () => {
  await assert.rejects(
    () =>
      cardian.importJson({
        notes: [
          { rel: 'Cards/a.md', frontmatter: { title: 'ok' }, body: 'x' },
          { rel: 'Cards/../../evil.md', frontmatter: { title: 'bad' }, body: 'y' },
        ],
      }),
    /非法|非法的 rel/
  )
  assert.equal((await cardian.cards.list()).length, 0, 'no partial import')
})

test('importMarkdownFolder skips empty notes', async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'cardian-import-empty-'))
  await writeFile(path.join(dir, 'full.md'), '# full\ncontent here\n')
  await writeFile(path.join(dir, 'empty.md'), '')
  const result = await cardian.importMarkdownFolder(dir)
  assert.equal(result.count, 1)
})

test('wiki ingest captures imports and skips hidden dirs', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'cardian-deps-'))
  await mkdir(path.join(repo, '.github'), { recursive: true })
  await writeFile(path.join(repo, 'main.js'), "import x from './util'\nrequire('lodash')\n")
  await writeFile(path.join(repo, '.github', 'ci.js'), '// hidden\n')
  const ingest = await cardian.wiki.ingest(repo, { repoName: 'deps' })
  assert.equal(ingest.count, 1, 'hidden dir skipped')
  const page = await cardian.wiki.getByPath('deps', 'main.js')
  assert.ok(page.imports.includes('./util'))
  assert.ok(page.imports.includes('lodash'))
  assert.ok(page.body.includes('## 依赖'))
})

test('memory upsert appends revision history', async () => {
  await cardian.memory.upsert({ title: '偏好', content: '第一版。' })
  await cardian.memory.upsert({ title: '偏好', content: '第二版。' })
  const got = await cardian.memory.get('偏好')
  assert.equal(got.history.length, 1)
  assert.ok(got.history[0].includes('偏好'))
})

test('typed relations resolve in related()', async () => {
  await cardian.cards.upsert({ title: '源头', content: 'x' })
  await cardian.cards.upsert({ title: '关系方', content: 'y', relations: ['relates_to [[源头]]'] })
  const related = await cardian.related('关系方')
  assert.ok(related.some((r) => r.title === '源头' && r.relation === 'relates_to'))
})

test('status reports stale notes and MOC is not injectable', async () => {
  await cardian.cards.upsert({
    title: '过期卡',
    content: 'x',
    expires: '2000-01-01',
  })
  await cardian.cards.upsert({ title: 'foo]] [[evil|bar', content: 'y' })
  assert.ok((await cardian.status()).stale >= 1)
  const moc = await readFile(path.join(vaultPath, 'Cards', 'README.md'), 'utf8')
  assert.ok(!moc.includes('[[evil'), 'no link injection in MOC')
})

test('notes named index/moc are not mistaken for section MOC', async () => {
  await cardian.cards.upsert({ title: 'index', content: 'x' })
  await cardian.cards.upsert({ title: 'moc', content: 'y' })
  const list = await cardian.cards.list()
  assert.equal(list.length, 2)
  assert.ok(list.some((e) => e.title === 'index'))
  assert.ok(list.some((e) => e.title === 'moc'))
})

test('related() dedups the same target across multiple relations', async () => {
  await cardian.cards.upsert({ title: '目标', content: 'x' })
  await cardian.cards.upsert({
    title: '来源',
    content: 'y',
    relations: ['depends_on [[目标]]', 'relates_to [[目标]]'],
  })
  const related = await cardian.related('来源')
  const targets = related.filter((r) => r.title === '目标')
  assert.equal(targets.length, 1, 'no duplicate relation entries')
})

test('extractImports is language-aware and ignores comments', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'cardian-imports-'))
  await writeFile(path.join(repo, 'main.py'), 'import os\nfrom pathlib import Path\n')
  await writeFile(path.join(repo, 'util.js'), "// from 'fake-comment'\nimport x from './real'\n")
  await cardian.wiki.ingest(repo, { repoName: 'i' })
  const py = await cardian.wiki.getByPath('i', 'main.py')
  assert.ok(py.imports.includes('os'))
  assert.ok(py.imports.includes('pathlib'))
  const js = await cardian.wiki.getByPath('i', 'util.js')
  assert.ok(js.imports.includes('./real'))
  assert.ok(!js.imports.includes('fake-comment'), 'comment not mistaken for a dependency')
})

test('recall boosts by confidence when other signals are equal', async () => {
  await cardian.memory.upsert({ title: '低置信', content: '关于部署', importance: 5, confidence: 0.1 })
  await cardian.memory.upsert({ title: '高置信', content: '关于部署', importance: 5, confidence: 0.9 })
  const r = await cardian.recall('部署', { type: 'memory', topK: 2 })
  assert.equal(r.results[0].title, '高置信')
})

test('invalid expires is rejected', async () => {
  await assert.rejects(
    () => cardian.cards.upsert({ title: 'x', content: 'y', expires: 'not-a-date' }),
    /无效日期/
  )
})

test('flashcards support SM-2 review and due listing', async () => {
  await cardian.cards.upsert({
    title: '闪卡',
    content: 'q',
    front: '什么是闭包？',
    back: '函数+词法环境',
    deck: 'js',
  })
  const due0 = await cardian.cards.due()
  assert.equal(due0.length, 1, 'new card with no due is due immediately')
  const rev = await cardian.cards.review('闪卡', 3)
  assert.equal(rev.interval, 1)
  assert.ok(rev.due)
  const got = await cardian.cards.get('闪卡')
  assert.equal(got.reps, 1)
  assert.equal(got.deck, 'js')
  assert.equal((await cardian.cards.due()).length, 0, 'scheduled 1 day out')
})

test('doctor reports healthy vault and detects orphan tmp files', async () => {
  const d1 = await cardian.doctor()
  assert.equal(d1.healthy, true)
  await writeFile(path.join(vaultPath, 'Cards', 'x.md.dead.tmp'), 'junk')
  const d2 = await cardian.doctor()
  assert.equal(d2.healthy, false)
  assert.ok(d2.problems.some((p) => p.issue.includes('临时文件')))
})

test('schema introspects frontmatter fields', async () => {
  await cardian.cards.upsert({ title: 's', content: 'x', tags: ['t'] })
  const schema = await cardian.schema()
  const titleField = schema.find((f) => f.field === 'title')
  assert.ok(titleField)
  assert.ok(titleField.types.includes('string'))
})

test('describe() returns the knowledge-tree read model', async () => {
  await cardian.cards.upsert({ title: '卡片', content: 'x', category: 'frontend' })
  await cardian.memory.upsert({ title: '记忆', content: 'y', scope: 'global' })
  const tree = await cardian.describe()
  assert.equal(tree.sections.length, 3)
  assert.deepEqual(tree.sections.map((s) => s.key), ['cards', 'memory', 'wiki'])
  const cardsSection = tree.sections.find((s) => s.key === 'cards')
  assert.equal(cardsSection.count, 1)
  assert.ok(cardsSection.entries.some((e) => e.title === '卡片'))
})

test('re-ingest preserves semantically enriched wiki cards (clobber fix)', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'cardian-repo-'))
  await mkdir(path.join(repo, 'src'), { recursive: true })
  await writeFile(path.join(repo, 'src', 'store.js'), 'function createStore() {}\n')
  await writeFile(path.join(repo, 'README.md'), '# demo\n')

  // First ingest: skeleton cards.
  const first = await cardian.wiki.ingest(repo, { repoName: 'proj' })
  assert.equal(first.count, 2)

  // AI/user enrichment via upsert.
  await cardian.wiki.upsert({
    repo: 'proj',
    path: 'src/store.js',
    title: 'Store（状态仓库）',
    content: '## 职责\n\n管理全局状态，AI 凝练好的内容。',
    summary: '语义回填后的摘要',
  })

  // Second ingest (user clicks 凝练 again): must NOT clobber enriched card.
  const second = await cardian.wiki.ingest(repo, { repoName: 'proj' })
  assert.equal(second.skipped, 2, 'enriched + unchanged-skeleton both reserved')
  assert.equal(second.count, 0, 'nothing re-written when nothing changed')
  const kept = await cardian.wiki.getByPath('proj', 'src/store.js')
  assert.ok(kept.body.includes('AI 凝练好的内容'), 'enriched body survives re-ingest')
  assert.equal(kept.summary, '语义回填后的摘要', 'enriched summary survives re-ingest')
  assert.equal(kept.title, 'Store（状态仓库）', 'enriched title survives re-ingest')
  assert.ok(!kept.body.includes('## 待补充'), 'no skeleton marker in kept card')
})

test('sectionList carries path so the panel can build folder trees', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'cardian-repo-'))
  await mkdir(path.join(repo, 'src', 'deep'), { recursive: true })
  await writeFile(path.join(repo, 'src', 'deep', 'a.js'), 'export const a = 1\n')
  await writeFile(path.join(repo, 'README.md'), '# tree\n')
  await cardian.wiki.ingest(repo, { repoName: 'tree1' })

  const section = await cardian.sectionList({ key: 'wiki' })
  assert.ok(section.repos.includes('tree1'))
  const a = section.entries.find((e) => e.path === 'src/deep/a.js')
  assert.ok(a, 'entry has path')
  assert.equal(a.rel, 'Repos/tree1/src-deep-a.md')
  assert.equal(section.entries[0].group, 'tree1')
})

test('conversation hook refreshes memory for a known project', async () => {
  // Seed a repo with a real file so ingest produces a card the hook can match.
  const repo = await mkdtemp(path.join(tmpdir(), 'cardian-repo-'))
  await writeFile(path.join(repo, 'readme.md'), '# sample-app\n')
  await cardian.wiki.ingest(repo, { repoName: 'sample-app', maxFiles: 2 })

  let handler = null
  const captured = []
  const ctx = {
    tools: { register: (def) => captured.push(def) },
    provide: (key, value) => { ctx[key] = value },
    logger: {
      warn: (...a) => captured.push(['warn', ...a]),
      error: (...a) => captured.push(['error', ...a]),
    },
    on: (name, fn) => { handler = fn },
  }
  apply(ctx, { vaultPath, autoInit: false })
  await ctx.cardian.ready

  // Dispatch a user/message for a session whose cwd basename maps to sample-app.
  assert.equal(typeof handler, 'function', 'session/event listener registered')
  const projectCwd = path.join(path.dirname(repo), 'sample-app')
  await handler(
    { header: { cwd: projectCwd } },
    {
      type: 'user/message',
      data: { message: { content: [{ text: '帮我看看 sample-app 的架构' }] } },
    },
  )
  // Wait for the async refresh (memory upsert + refreshAll).
  await new Promise((r) => setTimeout(r, 300))
  const mem = await cardian.memory.list({ scope: 'sample-app' })
  assert.equal(mem.length, 1, 'project-scoped activity memory written')
  const detail = await cardian.memory.get(mem[0].title)
  assert.equal(detail.scope, 'sample-app')
  assert.ok(detail.body.includes('sample-app'))
  assert.ok(detail.body.includes('帮我看看'))
  assert.equal(detail.kind, 'episodic')

  // A second message updates the same memory in place (stable id).
  const before = detail.id
  await handler(
    { header: { cwd: projectCwd } },
    { type: 'user/message', data: { message: { content: [{ text: '再问一次' }] } } },
  )
  await new Promise((r) => setTimeout(r, 300))
  const again = await cardian.memory.get(mem[0].title)
  assert.equal(again.id, before, 'same memory updated in place')
  assert.ok(again.body.includes('再问一次'))
})

test('ingestProject runs AI condense via host llm stream after skeleton scan', async () => {
  const { CardianGateway } = await import('../src/index.js')
  const calls = [] // 每次 llm.stream 收到的 options
  const gwCtx = {
    reflect: { provide: () => {} },
    logger: { info: () => {}, warn: () => {}, error: () => {} },
    get: (key) => {
      if (key === 'llm') {
        return {
          async *stream(options) {
            calls.push(options)
            const last = options.messages?.at(-1)?.content?.[0]?.text ?? ''
            if (last.includes('总览 + 模块')) {
              // plan 阶段：返回层级 JSON（本项目根目录平铺，无模块）。
              yield {
                type: 'text-delta',
                text: JSON.stringify({ overview: { title: 'aiproj · 项目总览', summary: '测试项目' }, modules: [] }),
              }
            } else {
              // enrich 阶段：逐文件语义回填。
              yield {
                type: 'text-delta',
                text: JSON.stringify({
                  title: '源码卡',
                  summary: '一句话职责',
                  body: '## 职责\n职责说明。\n## 关键实现\n实现说明。\n## 依赖\n依赖说明。\n## 注意点\n注意说明。',
                }),
              }
            }
            yield { type: 'finish', reason: { kind: 'stop' } }
          },
        }
      }
      return null
    },
    on: () => () => {},
  }

  const repo = await mkdtemp(path.join(tmpdir(), 'cardian-ai-'))
  await writeFile(path.join(repo, 'readme.md'), '# ai repo\n')
  await writeFile(path.join(repo, 'src.js'), 'export const x = 1\n')

  const gw = new CardianGateway(gwCtx, cardian)
  const ret = gw.ingestProject({ dir: repo, repoName: 'aiproj', ai: true, model: { provider: 'mock', model: 'mock-1' } })
  assert.equal(ret.status, 'running')

  // 等 AI 流水线跑完（plan 1 次 + enrich 每个文件 1 次）。
  let job = null
  for (let i = 0; i < 100; i++) {
    job = gw.ingestStatus().jobs.find((j) => j.jobId === ret.jobId)
    if (job && job.status === 'done') break
    await new Promise((r) => setTimeout(r, 50))
  }
  assert.ok(job, 'job exists')
  assert.equal(job.status, 'done', 'skeleton scan + AI condense finished')
  assert.equal(job.aiStatus, 'done', 'AI condense completed via llm stream')
  assert.ok(job.enrichedCount > 0, 'files enriched via llm')
  assert.ok(calls.length >= 2, 'llm.stream called for plan + per-file enrich')

  // plan 调用：prompt 要求层级 JSON，携带模型选择与项目名。
  const planCall = calls.find((c) => JSON.stringify(c.messages).includes('总览 + 模块'))
  assert.ok(planCall, 'plan stage prompt sent')
  assert.equal(planCall.provider, 'mock', 'provider forwarded to llm')
  assert.equal(planCall.model, 'mock-1', 'model selection forwarded to llm')
  assert.ok(JSON.stringify(planCall.messages).includes('aiproj'), 'plan prompt names the repo')

  // enrich 调用：prompt 指向具体文件并要求四段式正文。
  // 每个被扫描文件各触发一次 enrich，逐个文件名断言（不得只查第一个）。
  const enrichCalls = calls.filter((c) => JSON.stringify(c.messages).includes('请说明这个文件在该项目里实际承担什么工作'))
  assert.ok(enrichCalls.length >= 1, 'enrich stage prompt sent')
  const srcCall = enrichCalls.find((c) => JSON.stringify(c.messages).includes('src.js'))
  assert.ok(srcCall, 'enrich prompt names the scanned file')
  assert.ok(JSON.stringify(srcCall.messages).includes('## 职责'), 'enrich prompt requires four sections')

  // 落盘卡片是 AI 语义卡（analysisLevel: ai，正文含语义小节）。
  const pages = (await cardian.wiki.entries()).filter((e) => e.group === 'aiproj')
  assert.ok(pages.length > 0, 'wiki pages written')
  assert.ok(pages.some((e) => e.frontmatter.analysisLevel === 'ai'), 'cards enriched with ai analysis level')
  assert.ok(pages.some((e) => e.body.includes('## 关键实现')), 'semantic body persisted')
})

test('ingestProject skips AI condense when ai:false or agents unavailable', async () => {
  const { CardianGateway } = await import('../src/index.js')
  const created = []
  const gwCtx = {
    reflect: { provide: () => {} },
    logger: { info: () => {}, warn: () => {}, error: () => {} },
    get: () => null, // 无 agents 服务
    on: () => () => {},
  }
  const repo = await mkdtemp(path.join(tmpdir(), 'cardian-ai-off-'))
  await writeFile(path.join(repo, 'readme.md'), '# no ai\n')

  const gw = new CardianGateway(gwCtx, cardian)
  const ret = gw.ingestProject({ dir: repo, repoName: 'noai', ai: false })
  let job = null
  for (let i = 0; i < 50; i++) {
    job = gw.ingestStatus().jobs.find((j) => j.jobId === ret.jobId)
    if (job && job.status === 'done') break
    await new Promise((r) => setTimeout(r, 50))
  }
  assert.ok(job, 'job exists')
  assert.equal(job.status, 'done')
  assert.equal(job.aiStatus, 'none', 'ai:false -> no spawn')
  assert.equal(created.length, 0, 'agents.create never called')

  // agents 缺失时（ai 默认 true）也降级：job done + aiStatus unavailable。
  const ret2 = gw.ingestProject({ dir: repo, repoName: 'noai2' })
  let job2 = null
  for (let i = 0; i < 50; i++) {
    job2 = gw.ingestStatus().jobs.find((j) => j.jobId === ret2.jobId)
    if (job2 && job2.status === 'done' && job2.aiStatus === 'unavailable') break
    await new Promise((r) => setTimeout(r, 50))
  }
  assert.ok(job2, 'second job exists')
  assert.equal(job2.aiStatus, 'unavailable', 'degrades gracefully without agents')
})


