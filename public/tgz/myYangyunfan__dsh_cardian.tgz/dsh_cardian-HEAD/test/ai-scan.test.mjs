// AI 扫盘建库回归：core 三件套（enumerateFiles 只读 / applyHierarchy 父子链 /
// changedSince diff）+ 网关任务控制（applyIngestControl 纯函数 + 真实暂停/继续）。
//
// 只读铁律：扫盘对目标仓库只能 readdir/stat/readFile，任何写盘都由本文件断言兜住。
import { test } from 'node:test'
import { strict as assert } from 'node:assert'
import { mkdtemp, writeFile, readFile, readdir, rm, mkdir, stat } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { createCardian } from '../core/index.js'
import { RepoWikiService } from '../core/repowiki.js'
import { CardianGateway, applyIngestControl } from '../src/index.js'

async function makeRepo(files) {
  const repo = await mkdtemp(path.join(tmpdir(), 'cardian-scan-'))
  for (const [rel, text] of Object.entries(files)) {
    const abs = path.join(repo, ...rel.split('/'))
    await mkdir(path.dirname(abs), { recursive: true })
    await writeFile(abs, text)
  }
  return repo
}

/** 递归快照（路径 → 字节数 + mtimeMs），用于证明扫盘没有碰过目标仓库。 */
async function snapshot(dir, base = dir) {
  const out = {}
  const entries = await readdir(dir, { withFileTypes: true })
  for (const e of entries) {
    const abs = path.join(dir, e.name)
    if (e.isDirectory()) {
      Object.assign(out, await snapshot(abs, base))
    } else {
      const st = await stat(abs)
      out[path.relative(base, abs).split(path.sep).join('/')] = `${st.size}:${st.mtimeMs}`
    }
  }
  return out
}

async function freshCardian() {
  const vaultPath = await mkdtemp(path.join(tmpdir(), 'cardian-vault-'))
  const cardian = createCardian({ vaultPath })
  await cardian.init()
  return { cardian, vaultPath }
}

// ── A. core 引擎 ────────────────────────────────────────────────────────

test('enumerateFiles 只读枚举：返回清单且不在目标仓库留下任何写入', async () => {
  const repo = await makeRepo({
    'readme.md': '# sample\n\n说明\n',
    'src/engine.js': "import { a } from './a'\nexport class Engine {}\n",
    'src/a.js': 'export const a = 1\n',
    'node_modules/junk/index.js': 'module.exports = 1\n',
  })
  const before = await snapshot(repo)
  const { cardian } = await freshCardian()

  const seen = []
  const listed = await cardian.wiki.enumerateFiles(repo, {
    repoName: 'sample-app',
    maxFiles: 20,
    onProgress: (p) => seen.push(p),
  })

  assert.equal(listed.repo, 'sample-app', 'slug 化后的 repo')
  assert.equal(listed.repoName, 'sample-app')
  assert.equal(listed.truncated, false, '未触顶')
  const rels = listed.files.map((f) => f.relPath).sort()
  assert.deepEqual(rels, ['readme.md', 'src/a.js', 'src/engine.js'], '跳过 node_modules，relPath 用 / 分隔')
  assert.ok(seen.length >= rels.length, '逐文件回调过进度')
  assert.equal(seen.at(-1).done, seen.at(-1).total, '收尾进度对齐 total')

  const engine = listed.files.find((f) => f.relPath === 'src/engine.js')
  assert.equal(engine.language, 'javascript')
  assert.ok(engine.contentHash && engine.contentHash.length >= 8, '内容指纹用于 diff 短路')
  assert.ok(engine.lines >= 2)
  assert.ok(engine.imports.includes('./a'), '抽取静态依赖')
  assert.ok(engine.symbols.includes('Engine'), '抽取静态符号')
  assert.ok(engine.excerpt.includes('class Engine'), '摘录供模型阅读')

  assert.deepEqual(await snapshot(repo), before, '目标仓库一字节未改、一文件未增')
})

test('applyHierarchy 落层级卡：总览 → 模块 parent 链 + 归属 assignments', async () => {
  const { cardian } = await freshCardian()
  const plan = await cardian.wiki.applyHierarchy('sample-app', {
    overview: { title: '示例项目 · 总览', summary: '一个用于测试的项目' },
    modules: [
      { id: 'core', title: '核心引擎', summary: '运行时与调度', paths: ['src', 'src/deep'] },
      { id: 'docs', title: '文档', paths: ['docs'] },
      { id: '', title: '', paths: [] }, // 无标题 → 丢弃
    ],
  })

  assert.equal(plan.modules.length, 2, '空标题模块被丢弃')
  assert.ok(plan.overview.id, '总览卡有 id')

  const all = await cardian.wiki.entries()
  const byPath = new Map(all.filter((e) => e.group === 'sample-app').map((e) => [e.frontmatter.path, e]))
  const ov = byPath.get('__OVERVIEW__')
  assert.ok(ov, '总览卡落盘')
  assert.equal(ov.frontmatter.level, 'project')
  assert.equal(ov.frontmatter.overview, true)
  assert.ok(ov.body.includes('[[核心引擎]]'), '总览正文回链模块')

  const core = byPath.get('__MODULE__/core')
  assert.ok(core, '模块卡落盘')
  assert.equal(core.frontmatter.level, 'module')
  assert.equal(core.frontmatter.parent, plan.overview.id, '模块卡 parent 指向总览')
  assert.deepEqual(core.frontmatter.modulePaths, ['src', 'src/deep'])

  // 归属：最长前缀优先；未命中模块的文件留在总览下。
  assert.equal(RepoWikiService.moduleOwnerOf(plan.assignments, 'src/deep/x.js').moduleId, plan.modules[0].id, '最长前缀命中 src/deep')
  assert.equal(RepoWikiService.moduleOwnerOf(plan.assignments, 'docs/a.md').moduleId, plan.modules[1].id)
  assert.equal(RepoWikiService.moduleOwnerOf(plan.assignments, 'readme.md'), null)
  assert.ok(plan.assignments.every((a, i) => i === 0 || a.pattern.length <= plan.assignments[i - 1].pattern.length), '按前缀长度倒序')
})

test('changedSince 比对磁盘与已存卡：added / changed / removed + targets 可直接喂回填', async () => {
  const repo = await makeRepo({
    'src/keep.js': 'export const keep = 1\n',
    'src/edit.js': 'export const edit = 1\n',
    'src/gone.js': 'export const gone = 1\n',
  })
  const { cardian } = await freshCardian()
  await cardian.wiki.ingest(repo, { repoName: 'diffapp', maxFiles: 20 })
  const before = await snapshot(repo)

  const first = await cardian.wiki.changedSince(repo, { repoName: 'diffapp', maxFiles: 20 })
  assert.equal(first.added.length, 0, '刚 ingest 完无新增')
  assert.equal(first.changed.length, 0, '内容指纹一致 → 无变更')
  assert.equal(first.removed.length, 0)
  assert.equal(first.unchanged.length, 3)
  assert.equal(first.unchanged.every((u) => u.enriched === false), true, '骨架卡标记为未回填')
  assert.equal(first.pruneSafe, true)

  await writeFile(path.join(repo, 'src', 'edit.js'), 'export const edit = 2\n// 改了一行\n')
  await writeFile(path.join(repo, 'src', 'new.js'), 'export const neo = 1\n')
  await rm(path.join(repo, 'src', 'gone.js'))

  const untouched = await snapshot(repo)
  const second = await cardian.wiki.changedSince(repo, { repoName: 'diffapp', maxFiles: 20 })
  assert.deepEqual(second.added, ['src/new.js'])
  assert.deepEqual(second.changed.map((c) => c.path), ['src/edit.js'])
  assert.deepEqual(second.removed, ['src/gone.js'])
  assert.deepEqual(
    second.targets.map((t) => t.relPath).sort(),
    ['src/edit.js', 'src/new.js'],
    'targets = added + changed 的完整元数据',
  )
  assert.ok(second.targets.every((t) => t.contentHash && t.excerpt != null), 'targets 含指纹与摘录')
  assert.deepEqual(await snapshot(repo), untouched, '比对本身不写目标仓库')
  assert.ok(before['src/keep.js'], '原有文件仍在清单里')
  assert.equal(second.unchanged.find((u) => u.path === 'src/keep.js').enriched, false)

  // 回填过了的卡：同一内容再比对 → enriched true，仍算未变更。
  await cardian.wiki.upsert({
    repoName: 'diffapp',
    path: 'src/keep.js',
    title: '保留卡',
    analysisLevel: 'ai',
    level: 'file',
    content: '# keep\n\n## 职责\n\n保留。\n\n## 关键实现\n\n常量。\n\n## 依赖\n\n无。\n\n## 注意点\n\n无。\n',
  })
  const third = await cardian.wiki.changedSince(repo, { repoName: 'diffapp', maxFiles: 20 })
  assert.equal(third.unchanged.find((u) => u.path === 'src/keep.js').enriched, true, '已回填卡被识别为 enriched')
})

// ── B. 任务控制纯函数 ────────────────────────────────────────────────────

test('applyIngestControl：pause / resume / cancel 的状态翻转与幂等', () => {
  const running = () => ({ status: 'running', paused: false, cancelled: false, done: 3, total: 9, current: 'x' })

  const a = running()
  assert.equal(applyIngestControl(a, 'pause'), true)
  assert.equal(a.status, 'paused')
  assert.equal(a.paused, true)
  assert.ok(a.current.includes('已暂停'))
  assert.equal(applyIngestControl(a, 'pause'), false, '重复 pause 幂等')
  assert.equal(a.status, 'paused')

  assert.equal(applyIngestControl(a, 'resume'), true)
  assert.equal(a.status, 'running')
  assert.equal(a.paused, false)
  assert.ok(a.current.includes('继续'))
  assert.equal(applyIngestControl(a, 'resume'), false, '重复 resume 幂等')

  const b = running()
  assert.equal(applyIngestControl(b, 'cancel'), true)
  assert.equal(b.cancelled, true)
  assert.equal(b.paused, false)
  assert.equal(applyIngestControl(b, 'cancel'), false, '已结束不再 cancel')

  // 终态不可复活：done / error 既不 pause 也不 resume；cancelled 不得 resume 回 running。
  for (const st of ['done', 'error', 'cancelled']) {
    const j = { ...running(), status: st, cancelled: st === 'cancelled' }
    assert.equal(applyIngestControl(j, 'pause'), false, `${st} 不能 pause`)
    assert.equal(applyIngestControl(j, 'resume'), false, `${st} 不能 resume`)
    assert.equal(j.status, st)
  }
  assert.equal(applyIngestControl(null, 'pause'), false)
  assert.equal(applyIngestControl(running(), 'bogus'), false)
})

// ── C. 网关流水线：真实暂停 / 继续 ───────────────────────────────────────

function mockLlm(hooks) {
  const calls = []
  return {
    calls,
    service: {
      async *stream(options) {
        calls.push(options)
        const last = options.messages?.at(-1)?.content?.[0]?.text ?? ''
        if (last.includes('总览 + 模块')) {
          yield {
            type: 'text-delta',
            text: JSON.stringify({
              overview: { title: 'pauseproj · 项目总览', summary: '测试暂停' },
              modules: [{ id: 'core', title: '核心', summary: '源码', paths: ['src'] }],
            }),
          }
        } else {
          hooks.onEnrich?.(calls.length)
          yield {
            type: 'text-delta',
            text: JSON.stringify({
              title: '文件卡',
              summary: '一句话',
              body: '## 职责\n职责。\n## 关键实现\n实现。\n## 依赖\n依赖。\n## 注意点\n注意。',
            }),
          }
        }
        yield { type: 'finish', reason: { kind: 'stop' } }
      },
      listProviders: () => [{ id: 'mock' }],
      listModels: () => [{ provider: 'mock', id: 'mock-1', name: 'Mock One' }],
    },
  }
}

function gatewayWithLlm(cardian, llm) {
  const ctx = {
    reflect: { provide: () => {} },
    logger: { info: () => {}, warn: () => {}, error: () => {} },
    get: (key) => (key === 'llm' ? llm : null),
    on: () => () => {},
  }
  return new CardianGateway(ctx, cardian)
}

async function waitJob(gw, jobId, predicate, tries = 200) {
  for (let i = 0; i < tries; i++) {
    const job = gw.ingestStatus().jobs.find((j) => j.jobId === jobId)
    if (job && predicate(job)) return job
    await new Promise((r) => setTimeout(r, 25))
  }
  throw new Error(`job ${jobId} 未在期限内达成条件`)
}

test('扫盘可实时暂停：中断在途回填并保留已落盘卡片', async () => {
  const repo = await makeRepo({
    'src/a.js': 'export const a = 1\n',
    'src/b.js': 'export const b = 2\n',
    'src/c.js': 'export const c = 3\n',
    'src/d.js': 'export const d = 4\n',
  })
  const { cardian } = await freshCardian()
  let enrichCount = 0
  const gwRef = { current: null }
  const { service, calls } = mockLlm({
    onEnrich: () => {
      enrichCount++
      if (enrichCount === 2) gwRef.current.pauseIngest({ jobId: gwRef.current.jobId })
    },
  })
  const gw = gatewayWithLlm(cardian, service)
  gwRef.current = gw
  const ret = gw.ingestProject({ dir: repo, repoName: 'pauseproj', model: { provider: 'mock', model: 'mock-1' } })
  gwRef.current.jobId = ret.jobId

  const paused = await waitJob(gw, ret.jobId, (j) => j.status === 'paused')
  assert.equal(paused.phase, 'enrich')
  assert.ok(paused.enrichedCount >= 1, '暂停前已有卡片落盘')
  assert.ok(paused.done < paused.total, `进度停在中间：${paused.done}/${paused.total}`)
  const enrichCallsAtPause = calls.length
  assert.ok(enrichCallsAtPause < 1 + 4, '没有把剩余文件全跑完')

  // 暂停后不得继续烧模型调用。
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(calls.length, enrichCallsAtPause, 'paused 后不再有 llm 调用')
  const still = gw.ingestStatus().jobs.find((j) => j.jobId === ret.jobId)
  assert.equal(still.status, 'paused')

  const pages = (await cardian.wiki.entries()).filter((e) => e.group === 'pauseproj')
  assert.ok(pages.some((e) => e.frontmatter.path === '__OVERVIEW__'), '层级卡在暂停前已可见')
  assert.ok(pages.some((e) => e.frontmatter.analysisLevel === 'ai'), '已回填卡保留 AI 成果')
})

test('暂停后继续：只补剩余项（已回填卡幂等跳过）并挂到所属模块', async () => {
  const repo = await makeRepo({
    'src/a.js': 'export const a = 1\n',
    'src/b.js': 'export const b = 2\n',
    'src/c.js': 'export const c = 3\n',
    'src/d.js': 'export const d = 4\n',
  })
  const { cardian } = await freshCardian()
  let enrichCount = 0
  const gwRef = {}
  const { service, calls } = mockLlm({
    onEnrich: () => {
      enrichCount++
      if (enrichCount === 2) gwRef.current.pauseIngest({ jobId: gwRef.current.jobId })
    },
  })
  const gw = gatewayWithLlm(cardian, service)
  gwRef.current = gw
  const ret = gw.ingestProject({ dir: repo, repoName: 'resumeproj', model: { provider: 'mock', model: 'mock-1' } })
  gwRef.current.jobId = ret.jobId
  await waitJob(gw, ret.jobId, (j) => j.status === 'paused')

  const beforeCalls = calls.length
  gw.resumeIngest({ jobId: ret.jobId })
  const done = await waitJob(gw, ret.jobId, (j) => j.status === 'done')

  assert.equal(done.aiStatus, 'done')
  assert.equal(done.pct, 100)
  assert.equal(done.enrichedCount, 4, '四个文件最终全部回填')
  assert.ok(done.skippedCount >= 1, '续跑时已回填卡被幂等跳过')
  assert.equal(done.diff, null, '全量任务无 diff')

  const pages = (await cardian.wiki.entries()).filter((e) => e.group === 'resumeproj')
  const fileCards = pages.filter((e) => e.frontmatter.level === 'file')
  assert.equal(fileCards.length, 4, '每张文件卡都在层级里')
  const overview = pages.find((e) => e.frontmatter.path === '__OVERVIEW__')
  const mod = pages.find((e) => e.frontmatter.path === '__MODULE__/core')
  assert.ok(overview && mod, '总览卡与模块卡齐备')
  assert.equal(mod.frontmatter.parent, overview.frontmatter.id, '模块挂在总览下')
  for (const e of fileCards) {
    assert.equal(e.frontmatter.parent, mod.frontmatter.id, `${e.frontmatter.path} 的 parent 指向模块卡`)
    assert.equal(e.frontmatter.analysisLevel, 'ai')
    assert.ok(e.body.includes('## 关键实现'))
  }
  // 续跑不得重跑 plan 阶段。
  assert.equal(calls.filter((c) => (c.messages?.at(-1)?.content?.[0]?.text ?? '').includes('总览 + 模块')).length, 1)
  assert.ok(calls.length > beforeCalls)
})

test('停止任务：cancelled 后不再处理剩余项，已落盘卡片保留', async () => {
  const repo = await makeRepo({
    'src/a.js': 'export const a = 1\n',
    'src/b.js': 'export const b = 2\n',
    'src/c.js': 'export const c = 3\n',
  })
  const { cardian } = await freshCardian()
  const { service } = mockLlm({})
  const gw = gatewayWithLlm(cardian, service)
  const ret = gw.ingestProject({ dir: repo, repoName: 'stopproj', model: { provider: 'mock', model: 'mock-1' } })
  const stopped = gw.cancelIngest({ jobId: ret.jobId })
  assert.equal(stopped.status, 'cancelled')
  assert.equal(gw.pauseIngest({ jobId: ret.jobId }).status, 'cancelled', '已停止不可再暂停')
  assert.equal(gw.resumeIngest({ jobId: ret.jobId }).status, 'cancelled', '已停止不可继续')
  const job = await waitJob(gw, ret.jobId, (j) => j.status === 'cancelled')
  assert.ok(job.current.includes('已停止'))
  assert.throws(() => gw.pauseIngest({ jobId: 'nope' }), /任务不存在/)
})

test('无 llm 服务 → 降级为仅骨架，并明确标注不可用', async () => {
  const repo = await makeRepo({ 'src/a.js': 'export const a = 1\n' })
  const { cardian } = await freshCardian()
  const gw = gatewayWithLlm(cardian, null)
  assert.deepEqual(await gw.listModels(), { available: false, models: [], default: null }, '无 llm 时模型目录为空')
  const ret = gw.ingestProject({ dir: repo, repoName: 'noai' })
  const job = await waitJob(gw, ret.jobId, (j) => j.status === 'done')
  assert.equal(job.aiStatus, 'unavailable')
  assert.equal(job.model, null)
  assert.equal(job.enrichedCount, 0)
  const pages = (await cardian.wiki.entries()).filter((e) => e.group === 'noai')
  assert.ok(pages.length >= 1)
  assert.ok(pages.every((e) => e.frontmatter.analysisLevel !== 'ai'), '降级后不冒充 AI 成果')
})

test('listModels 汇总 provider × model', async () => {
  const { cardian } = await freshCardian()
  const { service } = mockLlm({})
  const gw = gatewayWithLlm(cardian, service)
  const catalog = await gw.listModels()
  assert.equal(catalog.available, true)
  assert.deepEqual(
    catalog.models.map((m) => `${m.provider}/${m.model}`),
    ['mock/mock-1'],
  )
})

test('diff 重扫只处理变更项，并剪掉磁盘上已消失的孤儿卡', async () => {
  const repo = await makeRepo({
    'src/a.js': 'export const a = 1\n',
    'src/gone.js': 'export const gone = 1\n',
  })
  const { cardian } = await freshCardian()
  const { service, calls } = mockLlm({})
  const gw = gatewayWithLlm(cardian, service)
  const first = gw.ingestProject({ dir: repo, repoName: 'diffproj', model: { provider: 'mock', model: 'mock-1' } })
  await waitJob(gw, first.jobId, (j) => j.status === 'done')
  const callsAfterFull = calls.length

  await writeFile(path.join(repo, 'src', 'a.js'), 'export const a = 2\n// touched\n')
  await rm(path.join(repo, 'src', 'gone.js'))

  const ret = gw.rescanDiff({ dir: repo, repoName: 'diffproj', model: { provider: 'mock', model: 'mock-1' } })
  assert.equal(ret.kind, 'diff')
  const job = await waitJob(gw, ret.jobId, (j) => j.status === 'done')
  assert.ok(job.diff, '快照带 diff')
  assert.equal(job.diff.removedCount, 1)
  assert.equal(job.diff.changedCount, 1)
  assert.equal(job.diff.addedCount, 0)
  assert.equal(job.enrichedCount, 1, '只回填了变更的那个文件')
  assert.equal(calls.length - callsAfterFull, 1, 'diff 不再跑 plan 阶段')

  const pages = (await cardian.wiki.entries()).filter((e) => e.group === 'diffproj')
  assert.ok(!pages.some((e) => e.frontmatter.path === 'src/gone.js'), '孤儿卡被剪除')
})

test('扫盘提示词与正文装配为纯函数（层级 / 四段式 / 依赖兜底）', async () => {
  const { buildPlanPrompt, buildFilePrompt, enrichBody } = await import('../src/index.js')
  const plan = buildPlanPrompt({ repoName: 'demo', files: [{ relPath: 'src/a.js', language: 'javascript', lines: 3, symbols: ['A'] }], depth: 2 })
  const planText = Array.isArray(plan) ? plan.join('\n') : String(plan)
  assert.ok(planText.includes('总览 + 模块'))
  assert.ok(planText.includes('src/a.js'))

  const f = { relPath: 'src/a.js', language: 'javascript', lines: 3, imports: ['./b'], symbols: ['A'], excerpt: 'export const a = 1' }
  const filePrompt = buildFilePrompt({ repoName: 'demo' }, f, { moduleTitle: '核心' })
  const fileText = Array.isArray(filePrompt) ? filePrompt.join('\n') : String(filePrompt)
  assert.ok(fileText.includes('核心') && fileText.includes('## 职责'))

  const body = enrichBody({ title: 'A 模块', body: '## 职责\n\n做 A。' }, f, { moduleTitle: '核心' })
  assert.ok(body.startsWith('# A 模块'))
  assert.ok(body.includes('src/a.js') && body.includes('模块：核心'))
  assert.ok(body.includes('## 依赖'), '缺「依赖」小节时用静态 imports 兜底')
  assert.equal(enrichBody({ body: '' }, f, null), '', '空产出 → 空正文（上层回退骨架）')
  const fenced = enrichBody({ body: '```markdown\n## 职责\n\nx\n```' }, f, null)
  assert.ok(!fenced.includes('```'), '剥掉整段 fence')
})

test('repoWiki 层级 frontmatter 透传：level / parent 在重扫时不被打回平铺', async () => {
  const { cardian } = await freshCardian()
  const repo = await makeRepo({ 'src/a.js': 'export const a = 1\n' })
  const plan = await cardian.wiki.applyHierarchy('lvls', {
    overview: { title: '总览' },
    modules: [{ id: 'core', title: '核心', paths: ['src'] }],
  })
  const listed = await cardian.wiki.enumerateFiles(repo, { repoName: 'lvls' })
  const f = listed.files[0]
  await cardian.wiki.skeletonForFile(repo, f.absPath, f.relPath, { repo: 'lvls', repoName: 'lvls' }, { level: 'file', parent: plan.modules[0].id })
  const card = await cardian.wiki.getByPath('lvls', f.relPath)
  assert.equal(card.level, 'file')
  assert.equal(card.parent, plan.modules[0].id)
  assert.equal(card.contentHash, f.contentHash, '骨架卡带指纹，diff 才能短路')
  // 重扫（无 hint）不得把 AI 建好的父子关系打回平铺。
  await cardian.wiki.skeletonForFile(repo, f.absPath, f.relPath, { repo: 'lvls', repoName: 'lvls' }, { level: 'file', parent: plan.modules[0].id })
  const again = await cardian.wiki.getByPath('lvls', f.relPath)
  assert.equal(again.parent, plan.modules[0].id)
  assert.ok((await readFile(path.join(repo, 'src', 'a.js'), 'utf8')).includes('export const a = 1'), '目标文件原样')
})
