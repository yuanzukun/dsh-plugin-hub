// /cardian 斜杠命令约定注入 + vault 文件监听自动刷新（Obsidian 手工编辑场景）。
// watcher 的防环规则（README/_index/index/MOC 与点开头路径一律忽略）必须有
// 回归锁定——refreshAll() 重建的正是这些 MOC 文件，忽略规则一破就是死循环。
import { test } from 'node:test'
import { strict as assert } from 'node:assert'
import { mkdtemp, writeFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { apply, SLASH_GUIDE } from '../src/index.js'

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function boot(config = {}) {
  const vaultPath = await mkdtemp(path.join(tmpdir(), 'cardian-watch-'))
  const tools = new Map()
  let provided = null
  const promptSections = []
  const ctx = {
    tools: { register: (...args) => {
      const [def] = args
      if (typeof def === 'string') tools.set(def, args[1])
      else if (def && typeof def === 'object' && def.name) tools.set(def.name, def)
    } },
    provide: (name, svc) => {
      if (name === 'cardian') provided = svc
    },
    systemPrompt: { section: (fn) => promptSections.push(fn) },
    logger: { info() {}, warn() {}, error() {} },
  }
  const dispose = apply(ctx, { vaultPath, ...config })
  await provided.ready
  return { vaultPath, provided, promptSections, dispose }
}

async function waitFor(fn, ms = 10_000, step = 120) {
  const deadline = Date.now() + ms
  while (Date.now() < deadline) {
    try {
      if (await fn()) return true
    } catch {}
    await sleep(step)
  }
  return false
}

test('SLASH_GUIDE 注入 systemPrompt：含 /cardian 命令清单', async () => {
  const { promptSections, dispose } = await boot()
  try {
    assert.ok(promptSections.length >= 1, 'systemPrompt section registered')
    const txt = await promptSections[0]()
    assert.match(txt, /\/cardian search/)
    assert.match(txt, /\/cardian recall/)
    assert.match(txt, /\/cardian wiki list/)
    assert.match(txt, /cardian\.status/)
    // 常量本身也完整可用（供外部编排复用）。
    assert.match(SLASH_GUIDE, /\/cardian memory commit/)
  } finally {
    dispose()
  }
})

test('vault 新增笔记 → watcher 自动 reindex + MOC 刷新，检索即时可见', async () => {
  const { vaultPath, provided, dispose } = await boot()
  try {
    // init 后 watcher 应已挂上（ready 之后微任务）。
    assert.ok(await waitFor(() => provided.watcher != null, 4000), 'watcher attached')
    const before = provided.watcher.stats.rebuilds
    await writeFile(
      path.join(vaultPath, 'Cards', 'watcher-e2e-观测卡.md'),
      [
        '---',
        'id: watcher-e2e-card',
        'type: card',
        'title: watcher 观测卡',
        'tags: [test, watcher]',
        'category: test',
        'status: published',
        '---',
        '',
        '量子缠结观测的独特标记词 quasiflux。',
        '',
      ].join('\n'),
    )
    // 事件 → 1.2s debounce → reindex + refreshAll：rebuilds 计数是 watcher
    // 真干活的直接证据（search 自身的 mtime diff 兜底不算数）。
    assert.ok(
      await waitFor(() => provided.watcher.stats.rebuilds > before, 8000),
      'watcher rebuild fired',
    )
    // 端到端：新卡片内容无需任何手动 reindex 即可被检索命中。
    const hits = await provided.search('quasiflux')
    assert.ok(hits.some((h) => h.id === 'watcher-e2e-card'), 'new note searchable')
    // MOC 也应已含新条目（refreshAll 重建过 README）。
    const cards = await provided.cards.list()
    assert.ok(cards.some((c) => c.id === 'watcher-e2e-card' || c.title === 'watcher 观测卡'))
  } finally {
    dispose()
    await rm(vaultPath, { recursive: true, force: true })
  }
})

test('MOC 文件（README 等）变更被忽略，不触发刷新（防环）', async () => {
  const { vaultPath, provided, dispose } = await boot()
  try {
    assert.ok(await waitFor(() => provided.watcher != null, 4000), 'watcher attached')
    // init 刚写完三区 README；手改它绝不能引发自触发循环。
    await writeFile(path.join(vaultPath, 'Cards', 'README.md'), '---\ntitle: 知识卡片\ntype: moc\n---\n\n手改内容\n')
    await sleep(2000) // 超过 debounce 窗口
    assert.equal(provided.watcher.stats.rebuilds, 0, 'no rebuild for MOC edit')
    assert.ok(provided.watcher.stats.ignored >= 1, 'MOC edit counted as ignored')
    // 非 .md 文件同样不触发。
    await writeFile(path.join(vaultPath, 'Cards', 'note.txt'), 'x')
    await sleep(800)
    assert.equal(provided.watcher.stats.rebuilds, 0, 'no rebuild for non-md')
  } finally {
    dispose()
    await rm(vaultPath, { recursive: true, force: true })
  }
})

test('watchVault:false 时不挂监听', async () => {
  const { provided, dispose } = await boot({ watchVault: false })
  try {
    await sleep(400)
    assert.equal(provided.watcher ?? null, null, 'no watcher when disabled')
  } finally {
    dispose()
  }
})
