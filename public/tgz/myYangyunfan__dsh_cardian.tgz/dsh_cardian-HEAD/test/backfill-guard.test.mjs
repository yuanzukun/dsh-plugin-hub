// AI 回填看门狗回归：超时翻转 / 未超时保持，防止「凝练中」卡死回归。
import { test } from 'node:test'
import { strict as assert } from 'node:assert'
import { evaluateAiTimeouts } from '../src/index.js'

test('超时：running 超过 deadline → error；未超时保持 running', () => {
  const jobs = [
    { aiStatus: 'running', aiStartedAt: 0, aiDeadlineAt: 5_000 },
    { aiStatus: 'running', aiStartedAt: 0, aiDeadlineAt: 60_000 },
  ]
  const changed = evaluateAiTimeouts(jobs, 10_000, 300_000)
  assert.equal(changed, true)
  assert.equal(jobs[0].aiStatus, 'error')
  assert.equal(jobs[1].aiStatus, 'running')
})

test('非 running 状态不受看门狗影响', () => {
  const jobs = [{ aiStatus: 'done', aiStartedAt: 0, aiDeadlineAt: 1 }]
  assert.equal(evaluateAiTimeouts(jobs, 99_999), false)
  assert.equal(jobs[0].aiStatus, 'done')
})
