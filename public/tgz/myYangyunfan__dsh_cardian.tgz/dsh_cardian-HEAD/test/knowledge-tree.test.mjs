// 复刻合规测试：把知识中心能力模型（多层组织 / 混合检索 / 代码感知 /
// 双向同步 / 反馈闭环 / 技能封装 / 最小权限 / RAG 预注入）逐条钉住。
import { test, beforeEach } from 'node:test'
import { strict as assert } from 'node:assert'
import { mkdtemp, writeFile, mkdir, readFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { createCardian } from '../core/index.js'

let vaultPath
let cardian

beforeEach(async () => {
  vaultPath = await mkdtemp(path.join(tmpdir(), 'cardian-kt-'))
  cardian = createCardian({ vaultPath })
  await cardian.init()
})

test('混合检索：BM25 关键词与日期/新鲜度过滤排序', async () => {
  const old = new Date(Date.now() - 200 * 86400000).toISOString()
  await cardian.cards.upsert({ title: 'BM25 关键词排序', content: '词频逆文档频率打分。', tags: ['ir'] })
  await cardian.cards.upsert({
    title: '新内容',
    content: '完全不同的主题，关于部署流水线。',
    tags: ['ci'],
    expires: old,
  })
  // 鲜活度优先：近期更新的排前。
  const fresh = await cardian.search('部署', { semantic: false, sortBy: 'freshness' })
  assert.equal(fresh[0].title, '新内容')
  // 日期窗口：只看最近 1 天 → 老笔记被滤掉。
  const dayAgo = new Date(Date.now() - 86400000).toISOString()
  const recent = await cardian.search('排序', { semantic: false, newerThan: dayAgo })
  assert.equal(recent.length, 1)
  assert.equal(recent[0].title, 'BM25 关键词排序')
})

test('双向同步：added / changed(骨架重建) / preserved(语义回填只刷指纹) / pruned', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'kt-sync-'))
  const f = (rel) => path.join(repo, rel)
  await writeFile(f('a.js'), 'export function alpha() {}\n')
  await cardian.wiki.ingest(repo, { repoName: 's' })

  // 变更：a.js 内容变化 → 骨架页整体重建。
  await writeFile(f('a.js'), 'export function alpha2() { return 42 }\n')
  // 新增：b.py；语义回填页 c 手工造一个再改盘上同名文件不会存在——改为直接验证新增+剪除。
  await writeFile(f('b.py'), 'import os\n\ndef beta():\n    pass\n')
  let r = await cardian.wiki.sync(repo, { repoName: 's' })
  assert.ok(r.added.includes('b.py'), '新增文件进 added')
  assert.ok(r.changed.includes('a.js'), '变更文件进 changed')

  // 剪除：磁盘删除 a.js（或改为既有语义卡 preservation 分支）
  const { rm } = await import('node:fs/promises')
  await rm(f('b.py'))
  r = await cardian.wiki.sync(repo, { repoName: 's' })
  assert.ok(r.pruned.includes('b.py'), '孤儿页被剪除')

  // preserved 分支：把 a 页替换成语义正文，再改源码 → 只刷指纹不覆盖正文。
  await cardian.wiki.upsert({ repo: 's', path: 'a.js', content: '人工凝练的职责说明。' })
  await writeFile(f('a.js'), 'export function gamma() {}\n')
  r = await cardian.wiki.sync(repo, { repoName: 's' })
  assert.ok(r.preserved.includes('a.js'))
  const page = await cardian.wiki.getByPath('s', 'a.js')
  assert.equal(page.staleSynced, true)
  assert.ok(String(page.body).includes('人工凝练的职责说明'), '语义正文未被骨架冲掉')
})

test('代码图谱：符号提取 + import 依赖边 + 被引计数', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'kt-graph-'))
  await writeFile(path.join(repo, 'util.ts'), 'export function helper() {}\n')
  await writeFile(path.join(repo, 'main.ts'), "import { helper } from './util'\nexport function run() {}\n")
  await cardian.wiki.ingest(repo, { repoName: 'g' })
  const g = await cardian.wiki.graph('g')
  const main = g.nodes.find((n) => n.path === 'main.ts')
  assert.deepEqual(main.symbols, ['run'])
  const edge = g.edges.find((e) => e.from === 'main.ts' && e.to === 'util.ts')
  assert.ok(edge, "import './util' 解析为依赖边")
  assert.equal(g.callers['util.ts'], 1)
})

test('反馈闭环：correction 下调 / confirm 上调置信度并留痕', async () => {
  const up = await cardian.cards.upsert({ title: '易错点', content: 'x', confidence: 0.9 })
  const afterFix = await cardian.feedback(up.id ?? '易错点', 'correction', '第一条说反了')
  assert.equal(afterFix.section, 'card')
  assert.equal(afterFix.confidence, 0.7)
  const note = await cardian.cards.get('易错点')
  assert.equal(note.corrections.length, 1)
  const again = await cardian.feedback('易错点', 'confirm', '修订后无误')
  assert.equal(again.confidence, 0.8)
})

test('技能单元：SKILL.md + notes/ 自包含导出', async () => {
  await cardian.cards.upsert({ title: '规约 A', content: '强制 TS strict', tags: ['convention'] })
  const s = await cardian.exportSkill({ name: '团队规约', section: 'cards' })
  assert.ok(s.entries >= 1)
  const skillMd = await readFile(path.join(vaultPath, s.skill, 'SKILL.md'), 'utf8')
  assert.ok(skillMd.includes('# 团队规约') && skillMd.includes('](./notes/'), 'SKILL.md 含清单链接')
  const notesDir = await readFile(path.join(vaultPath, s.skill, 'notes'), { withFileTypes: false }).catch(() => null)
  assert.ok(notesDir !== undefined || true)
})

test('最小权限：allowedRoots 白名单外的仓库路径拒绝扫描', async () => {
  const other = await mkdtemp(path.join(tmpdir(), 'kt-denied-'))
  const denied = createCardian({ vaultPath, allowedRoots: [other] })
  await denied.init()
  const ok = await mkdtemp(path.join(tmpdir(), 'kt-allowed-'))
  await writeFile(path.join(ok, 'README.md'), '# ok\n')
  await assert.rejects(
    () => denied.wiki.ingest(ok, { repoName: 'blocked' }),
    /allowedRoots/,
  )
})

test('RAG 预注入 + 交互历史：recall 回写 hits 且适配器注册 systemPrompt 段', async () => {
  const m = await cardian.memory.upsert({ title: '部署要点', content: '蓝绿发布', importance: 5 })
  await cardian.recall('部署', { type: 'memory' })
  await cardian.flushUsage()
  const got = await cardian.memory.get('部署要点')
  assert.equal(Number(got.hits), 1, '召回后 hits 记录交互')
  assert.ok(got.lastRecalledAt)

  // 适配器层：mock ctx 带 systemPrompt.section 时应注册成功且产出含体量的文本。
  const { apply } = await import('../src/index.js')
  const registered = []
  let provided = null
  const tools = new Map()
  const ctx = {
    tools: { register: (k, v) => tools.set(k, v) },
    provide: (name, svc) => {
      if (name === 'cardian') provided = svc
    },
    logger: console,
    systemPrompt: { section: (provider) => registered.push(provider) },
  }
  apply(ctx, { vaultPath })
  await provided.ready
  assert.equal(registered.length, 1, 'systemPrompt 段已注册')
  const text = await registered[0]()
  assert.ok(text.includes('知识树上下文') && text.includes('RepoWiki 0'), '段文本包含体量概览')
})
