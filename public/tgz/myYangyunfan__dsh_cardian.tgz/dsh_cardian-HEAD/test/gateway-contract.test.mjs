// 网关三处清单同步契约回归测试。
//
// 铁律（见 src/typert.js 顶部注释）：新增 Remote 方法必须同步三处——
//   1) src/typert.js 的 TYPERT.invocations（loader 装配路径下生效）
//   2) src/index.js 的 TYPERT_MANIFEST（注入 entry 手动注册路径下生效）
//   3) src/client/controller.ts 的 remoteFaceDescriptor（客户端 $mount）
// 其中"零 wire 参数"的方法集合（describe/status/doctor/schema）若三处不一致，
// 会在客户端报 `expected 1 argument(s), got 0`、或在宿主报
// `args fields do not match the descriptor`。本测试锁定这三处必须完全一致。
import { test } from 'node:test'
import { strict as assert } from 'node:assert'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import { TYPERT } from '../src/typert.js'
import { GATEWAY_METHODS, TYPERT_MANIFEST, ZERO_WIRE_METHODS } from '../src/index.js'

const here = path.dirname(fileURLToPath(import.meta.url))

// 从 controller.ts 源码里抠出 ZERO_WIRE_METHODS 数组的字面量成员。
// 刻意不用正则（避免转义被破坏的已知坑），改走 indexOf + split 单引号。
function extractControllerZeroWire() {
  const src = readFileSync(path.join(here, '..', 'src', 'client', 'controller.ts'), 'utf8')
  // 用 `const ZERO_WIRE_METHODS` 定位声明行，避免命中顶部注释里的同名提及（注释里
  // 也写了 ZERO_WIRE_METHODS，裸 marker 会解析到注释导致抠出空数组）。
  const marker = 'const ZERO_WIRE_METHODS'
  const at = src.indexOf(marker)
  assert.ok(at !== -1, 'controller.ts 必须声明 ZERO_WIRE_METHODS')
  // 越过类型标注里的 `BridgeMethod[]`，定位赋值号 `=` 之后的数组字面量。
  const eq = src.indexOf('=', at)
  const open = src.indexOf('[', eq)
  const close = src.indexOf(']', open)
  assert.ok(eq !== -1 && open !== -1 && close > open, 'controller.ts ZERO_WIRE_METHODS 必须是数组字面量')
  const inner = src.slice(open + 1, close)
  return inner
    .split("'")
    .filter((_seg, i) => i % 2 === 1)
    .map((s) => s.trim())
    .filter(Boolean)
}

function zeroWireFromInvocations(invocations) {
  return invocations
    .filter((inv) => (inv.parameters?.length ?? 0) === 0)
    .map((inv) => inv.method)
    .sort()
}

const CANONICAL = ['describe', 'doctor', 'schema', 'status'] // 排序后

test('zero-wire call sites pass no params and the descriptor is ZERO_WIRE-driven', () => {
  const src = readFileSync(path.join(here, '..', 'src', 'client', 'controller.ts'), 'utf8')
  assert.ok(src.includes('ZERO_WIRE_METHODS.includes(method)'), 'controller 描述符必须由 ZERO_WIRE_METHODS 驱动')
  for (const m of ['describe', 'status', 'doctor', 'schema']) {
    assert.ok(!src.includes(`('${m}',`), `零 wire 方法 ${m} 的 callHost 调用点不得再传 params`)
  }
})

test('the three gateway manifests agree on the zero-wire method set', () => {
  const typertZero = zeroWireFromInvocations(TYPERT.invocations)
  const hostZero = zeroWireFromInvocations(TYPERT_MANIFEST.invocations)
  const clientZero = extractControllerZeroWire().slice().sort()
  const indexConstZero = Array.from(ZERO_WIRE_METHODS).sort()

  assert.deepEqual(typertZero, CANONICAL, 'src/typert.js 零 wire 集合漂移')
  assert.deepEqual(hostZero, CANONICAL, 'src/index.js TYPERT_MANIFEST 零 wire 集合漂移')
  assert.deepEqual(clientZero, CANONICAL, 'controller.ts 零 wire 集合漂移')
  assert.deepEqual(indexConstZero, CANONICAL, 'index.js ZERO_WIRE_METHODS 常量漂移')
})

test('every gateway method has a matching invocation in both host manifests', () => {
  const typertMethods = TYPERT.invocations.map((i) => i.method).sort()
  const hostMethods = TYPERT_MANIFEST.invocations.map((i) => i.method).sort()
  const gw = GATEWAY_METHODS.slice().sort()

  assert.deepEqual(typertMethods, gw, 'typert.js invocations 与 GATEWAY_METHODS 不一致')
  assert.deepEqual(hostMethods, gw, 'index.js TYPERT_MANIFEST 与 GATEWAY_METHODS 不一致')
})

test('per-method wire arity matches between typert.js and index.js manifests', () => {
  const hostByMethod = new Map(TYPERT_MANIFEST.invocations.map((i) => [i.method, i.parameters?.length ?? 0]))
  for (const inv of TYPERT.invocations) {
    const typertArity = inv.parameters?.length ?? 0
    assert.ok(hostByMethod.has(inv.method), `宿主清单缺少方法 ${inv.method}`)
    assert.equal(
      hostByMethod.get(inv.method),
      typertArity,
      `方法 ${inv.method} 的 wire 参数数量在 typert.js(${typertArity}) 与 index.js(${hostByMethod.get(inv.method)}) 间不一致`,
    )
  }
})

// 后经网关暴露的治理/导出方法：都带一个 params wire（不进零 wire 集合）。
// AI 扫盘建库新增的网关方法：同样带一个 params wire（listModels 无入参也走 params 占位）。
const PARAM_METHODS = ['promote', 'due', 'exportJson', 'exportSkill', 'listModels', 'pauseIngest', 'resumeIngest', 'cancelIngest', 'rescanDiff']

test('param-carrying governance/export methods are declared in all three manifests', () => {
  const typertByMethod = new Map(TYPERT.invocations.map((i) => [i.method, i.parameters?.length ?? 0]))
  const hostByMethod = new Map(TYPERT_MANIFEST.invocations.map((i) => [i.method, i.parameters?.length ?? 0]))
  const indexSrc = readFileSync(path.join(here, '..', 'src', 'index.js'), 'utf8')
  const clientSrc = readFileSync(path.join(here, '..', 'src', 'client', 'controller.ts'), 'utf8')

  for (const m of PARAM_METHODS) {
    assert.ok(GATEWAY_METHODS.includes(m), `GATEWAY_METHODS 缺少 ${m}`)
    assert.equal(typertByMethod.get(m), 1, `src/typert.js 的 ${m} 应声明 1 个 wire 参数`)
    assert.equal(hostByMethod.get(m), 1, `index.js 宿主清单的 ${m} 应声明 1 个 wire 参数`)
    assert.ok(!ZERO_WIRE_METHODS.has(m), `${m} 不是零 wire 方法，不得进 ZERO_WIRE_METHODS`)
    // 宿主侧必须有真实桥实现（把 params 转成引擎调用），否则 RPC 直达时找不到方法。
    assert.ok(indexSrc.includes('  ' + m + '(') || indexSrc.includes('  async ' + m + '('), `src/index.js 缺少 CardianGateway#${m} 桥实现`)
    // 客户端桥接清单必须有它，且调用点必须传 params（带 params 的方法绝不零传）。
    assert.ok(clientSrc.includes("  '" + m + "',"), `controller.ts BRIDGE_METHODS 缺少 ${m}`)
    assert.ok(clientSrc.includes("('" + m + "',"), `controller.ts 缺少 ${m} 的 callHost 调用点（需带 params）`)
  }
})

test('exposed gateway methods map onto real engine APIs (no invented engine calls)', () => {
  // 网关只能适配引擎已有能力：下面这些 core/ 签名一旦被删改，适配层就得同步调整。
  const core = readFileSync(path.join(here, '..', 'core', 'index.js'), 'utf8')
  const memory = readFileSync(path.join(here, '..', 'core', 'memory.js'), 'utf8')
  const cards = readFileSync(path.join(here, '..', 'core', 'cards.js'), 'utf8')
  assert.ok(memory.includes('async promote(ref'), 'core/memory.js 必须仍有 promote(ref, { target })')
  assert.ok(cards.includes('async due({ deck'), 'core/cards.js 必须仍有 due({ deck })')
  assert.ok(core.includes('async exportJson()'), 'core/index.js 必须仍有 exportJson()')
  assert.ok(core.includes('async exportSkill('), 'core/index.js 必须仍有 exportSkill(opts)')
})
