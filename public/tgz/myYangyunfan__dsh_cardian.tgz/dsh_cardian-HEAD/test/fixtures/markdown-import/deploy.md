---
type: memory
title: 部署约定
scope: ops
importance: 4
facts: [UTC, 蓝绿发布]
---
生产环境统一 UTC 时间，采用蓝绿发布。
