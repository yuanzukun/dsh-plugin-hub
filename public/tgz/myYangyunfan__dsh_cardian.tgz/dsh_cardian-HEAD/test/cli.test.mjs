import { test, beforeEach } from 'node:test'
import { strict as assert } from 'node:assert'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const execFileAsync = promisify(execFile)
const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

let vaultPath

beforeEach(async () => {
  vaultPath = await mkdtemp(path.join(tmpdir(), 'cardian-cli-'))
})

async function runCli(args) {
  try {
    const { stdout, stderr } = await execFileAsync(process.execPath, ['cli.mjs', ...args], {
      cwd: rootDir,
    })
    return { code: 0, stdout: String(stdout), stderr: String(stderr) }
  } catch (err) {
    return { code: err.code ?? 1, stdout: String(err.stdout ?? ''), stderr: String(err.stderr ?? '') }
  }
}

test('cli status and doctor work end-to-end', async () => {
  const status = await runCli(['status', '--vault', vaultPath])
  assert.equal(status.code, 0)
  const s = JSON.parse(status.stdout)
  assert.equal(s.vaultPath, path.resolve(vaultPath))
  assert.deepEqual(s.repos, [])

  const doctor = await runCli(['doctor', '--vault', vaultPath])
  assert.equal(doctor.code, 0)
  assert.equal(JSON.parse(doctor.stdout).healthy, true)
})

test('cli card add and search round-trip', async () => {
  const add = await runCli(['card', 'add', '闭包', '闭包=函数+词法环境', '--tags', 'js', '--vault', vaultPath])
  assert.equal(add.code, 0, add.stderr)
  const search = await runCli(['search', '词法', '--vault', vaultPath])
  const hits = JSON.parse(search.stdout)
  assert.ok(hits.some((h) => h.title === '闭包'))
})

test('cli --dry-run does not write and boolean flags are honored', async () => {
  const r = await runCli(['--dry-run', 'card', 'add', 'X', 'Y', '--vault', vaultPath])
  assert.equal(r.code, 0)
  assert.ok(JSON.parse(r.stdout)['dry-run'])
  const status = await runCli(['status', '--vault', vaultPath])
  assert.equal(JSON.parse(status.stdout).sections.cards, 0, 'dry-run wrote nothing')
})

test('cli unknown command and missing args return proper exit codes', async () => {
  const unknown = await runCli(['nope', '--vault', vaultPath])
  assert.equal(unknown.code, 1)
  const missing = await runCli(['card', 'add', '只有标题', '--vault', vaultPath])
  assert.equal(missing.code, 2, 'ValidationError maps to exit code 2')
})
