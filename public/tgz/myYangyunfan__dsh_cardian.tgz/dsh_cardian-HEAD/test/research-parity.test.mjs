// 调研复刻回归：图扩展召回 / 声明式清单 / 排除目录 / 哈希短路 /
// 分区配额与字符帽 / 晋升双落点 / 逐字摘录。
import { test, beforeEach } from 'node:test'
import { strict as assert } from 'node:assert'
import { mkdtemp, writeFile, readFile, stat, mkdir } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { createCardian } from '../core/index.js'
import { ValidationError } from '../core/errors.js'

let vaultPath
let cardian

beforeEach(async () => {
  vaultPath = await mkdtemp(path.join(tmpdir(), 'cardian-parity-'))
  cardian = createCardian({ vaultPath })
  await cardian.init()
})

test('图扩展召回：import 邻居随命中条目以低分并入', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'parity-g-'))
  await writeFile(path.join(repo, 'util.ts'), 'export function helper() {}\n')
  await writeFile(
    path.join(repo, 'main.ts'),
    "import { helper } from './util'\nexport function runPipeline() { /* 独有的流水线标记 */ }\n",
  )
  await cardian.wiki.ingest(repo, { repoName: 'gx' })
  const hits = await cardian.search('runPipeline 标记', { type: 'wiki', semantic: false })
  const neighbor = hits.find((h) => h.path.includes('util'))
  assert.ok(neighbor, '依赖邻居被图扩展拉入')
  assert.ok(neighbor.score < hits[0].score, '邻居分数低于直接命中')
  assert.ok(String(neighbor.viaGraph).includes('util'), '标注扩展来源')
})

test('声明式清单：wiki.plan.json 只按清单产出并携带标题/摘要提示', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'parity-plan-'))
  await mkdir(path.join(repo, 'src'), { recursive: true })
  await writeFile(path.join(repo, 'src', 'keep.ts'), 'export const KEEP = 1\n')
  await writeFile(path.join(repo, 'drop.md'), '# 不该进入 wiki\n')
  await writeFile(
    path.join(repo, 'wiki.plan.json'),
    JSON.stringify({ pages: [{ path: 'src/keep.ts', title: '核心常量模块', summary: '声明式清单项' }] }),
  )
  const r = await cardian.wiki.ingest(repo, { repoName: 'p' })
  assert.equal(r.count, 1, '仅清单内文件')
  const page = await cardian.wiki.getByPath('p', 'src/keep.ts')
  assert.equal(page.title, '核心常量模块')
  assert.equal(page.summary, '声明式清单项')
})

test('排除目录：excludes 子串匹配在 ingest/sync 双通道生效', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'parity-ex-'))
  await writeFile(path.join(repo, 'keep.js'), '// keep\n')
  const denied = createCardian({ vaultPath, excludes: ['generated'] })
  await denied.init()
  await writeFile(path.join(repo, 'gen', 'generated.js') && path.join(repo, 'generated.js'), '// skip me\n')
  // 直接把一个文件放进子目录名带 generated 的路径不可行（目录得真实存在），换简单形式：
  const r = await denied.wiki.ingest(repo, { repoName: 'ex' })
  assert.ok(!JSON.stringify(r.files).includes('generated.js'), '被排除文件不进结果')
})

test('哈希短路：重复 ingest 不再触碰骨架页文件（mtime 不变）', async () => {
  const repo = await mkdtemp(path.join(tmpdir(), 'parity-hash-'))
  await writeFile(path.join(repo, 'solo.ts'), 'export const A = 1\n')
  await cardian.wiki.ingest(repo, { repoName: 'h' })
  const page1 = await cardian.wiki.getByPath('h', 'solo.ts')
  const m1 = (await stat(path.join(vaultPath, page1.rel))).mtimeMs
  await cardian.wiki.ingest(repo, { repoName: 'h' })
  const vBefore = cardian.store.version
  await cardian.wiki.ingest(repo, { repoName: 'h' })
  const delta = cardian.store.version - vBefore
  assert.equal(delta, 1, '第二次 ingest 仅 MOC 刷新一次写；未变更骨架零重写')
})

test('配额治理：maxNotesPerSection 与 maxNoteChars 双帽 fail-fast', async () => {
  const capped = createCardian({
    vaultPath,
    limits: { maxNoteChars: 50, maxNotesPerSection: 2 },
  })
  await capped.init()
  await capped.cards.upsert({ title: '第一', content: 'short' })
  await assert.rejects(
    () => capped.cards.upsert({ title: '超长', content: 'x'.repeat(120) }),
    /字节上限/,
  )
  await capped.cards.upsert({ title: '第二', content: 'ok' })
  await assert.rejects(() => capped.cards.upsert({ title: '第三', content: 'ok' }), /条目配额/)
})

test('晋升双落点：shared → PROJECT.md，local → PERSONAL.md', async () => {
  await cardian.memory.upsert({ title: '共享约定', content: 'UTC 时间', importance: 4 })
  await cardian.memory.upsert({ title: '个人偏好', content: '浅色主题', importance: 2 })
  const s = await cardian.memory.promote('共享约定', { target: 'shared' })
  assert.equal(s.file, 'PROJECT.md')
  const l = await cardian.memory.promote('个人偏好', { target: 'local' })
  assert.equal(l.file, 'PERSONAL.md')
  const proj = await readFile(path.join(vaultPath, 'PROJECT.md'), 'utf8')
  const pers = await readFile(path.join(vaultPath, 'PERSONAL.md'), 'utf8')
  assert.ok(proj.includes('共享约定') && !proj.includes('个人偏好'))
  assert.ok(pers.includes('个人偏好'))
})

test('逐字摘录：recall 返回 excerpt 且包含查询词原文', async () => {
  await cardian.memory.upsert({ title: '发布节奏', content: '每周三进行蓝绿发布，回滚窗口 15 分钟。' })
  await cardian.flushUsage()
  cardian.indexer.version = -1 // 强制重建，确保 usage 回写后摘录来自最新文档
  const r = await cardian.recall('蓝绿发布', { type: 'memory' })
  assert.ok(r.results[0].excerpt.length > 0)
  assert.ok(r.results[0].excerpt.toLowerCase().includes('蓝绿发布'))
})
