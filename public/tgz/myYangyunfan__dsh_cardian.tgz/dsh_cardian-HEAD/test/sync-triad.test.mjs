// 链路同步守卫：网关清单 / typert 清单 / 客户端桥清单 三处必须一致。
// 这里直接读源文件做静态比对，防止多轮迭代后某一侧新增方法而另两侧遗漏。
import { test } from 'node:test'
import { strict as assert } from 'node:assert'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

test('three-way sync stays aligned (gateway ↔ typert ↔ bridge)', async () => {
  const gwSrc = await readFile(path.join(root, 'src', 'index.js'), 'utf8')
  const tySrc = await readFile(path.join(root, 'src', 'typert.js'), 'utf8')
  const clSrc = await readFile(
    path.join(root, 'src', 'client', 'controller.ts'),
    'utf8',
  )

  const gwNames = /GATEWAY_METHODS = \[([\s\S]*?)\]/.exec(gwSrc)?.[1] ?? ''
  const gwList = [...gwNames.matchAll(/'(\w+)'/g)].map((m) => m[1])

  const tyList = [...tySrc.matchAll(/inv\('(\w+)'/g)].map((m) => m[1])

  const bridge = /BRIDGE_METHODS = \[([\s\S]*?)\] as const/.exec(clSrc)?.[1] ?? ''
  const brList = [...bridge.matchAll(/'(\w+)'/g)].map((m) => m[1])

  assert.ok(gwList.length > 0, 'gateway list parsed')
  assert.ok(tyList.length > 0, 'typert list parsed')
  assert.ok(brList.length > 0, 'bridge list parsed')

  // 客户端每一项都必须在宿主网关与 wire 清单中存在。
  for (const name of brList) {
    assert.ok(gwList.includes(name), `gateway missing ${name}`)
    assert.ok(tyList.includes(name), `typert manifest missing ${name}`)
  }
  // 网关不得暴露客户端未接的方法（避免"幽灵能力"）。
  for (const name of gwList) {
    assert.ok(brList.includes(name), `client missing ${name}`)
  }
})
