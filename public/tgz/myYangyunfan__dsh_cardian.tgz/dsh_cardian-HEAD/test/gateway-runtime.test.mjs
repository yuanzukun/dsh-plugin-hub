// 网关运行时直连：不经过 wire，直接调用 CardianGateway 方法验证宿主半侧
// 的能力面（status/doctor/tagCloud）与注册名（cardianRemote）。
import { test } from 'node:test'
import { strict as assert } from 'node:assert'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { createCardian } from '../core/index.js'
import { CardianGateway } from '../src/index.js'

test('gateway methods delegate to the knowledge engine', async () => {
  const vaultPath = await mkdtemp(path.join(tmpdir(), 'cardian-gw-'))
  const cardian = createCardian({ vaultPath })
  await cardian.init()
  await cardian.cards.upsert({ title: 'gw 卡', content: 'x' })

  const provided = []
  const ctx = {
    provide: (name, svc) => {
      provided.push(name)
      return () => {}
    },
    reflect: {
      provide: (name, svc) => {
        provided.push(name)
        return () => {}
      },
    },
    logger: { warn() {}, error() {} },
    on: () => () => {},
    get: () => undefined,
  }
  const gw = new CardianGateway(ctx, cardian)
  assert.ok(provided.includes('cardianRemote'), 'gateway registers as cardianRemote')

  const st = await gw.status()
  assert.equal(st.sections.cards, 1)

  const d = await gw.doctor()
  assert.equal(typeof d.healthy, 'boolean')

  const cloud = await gw.tagCloud()
  assert.ok(Array.isArray(cloud))

  const s = await gw.search('gw 卡', { type: 'card' })
  assert.ok(Array.isArray(s))
})
