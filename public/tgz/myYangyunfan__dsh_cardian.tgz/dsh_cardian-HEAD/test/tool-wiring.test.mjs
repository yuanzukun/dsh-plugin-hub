// 端到端接线冒烟：直接通过 mock ctx 的 tools 句柄调用工具，
// 防止「服务方法存在但注册/参数链路静默失配」这类回归（本轮踩过）。
import { test } from 'node:test'
import { strict as assert } from 'node:assert'
import { mkdtemp, writeFile, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { apply } from '../src/index.js'

async function boot() {
  const vaultPath = await mkdtemp(path.join(tmpdir(), 'cardian-wire-'))
  const tools = new Map()
  let provided = null
  const ctx = {
    // 新契约：宿主以单对象调用 register（{ name, ... , execute }）
    tools: { register: (...args) => {
      const [def] = args
      if (typeof def === 'string') tools.set(def, args[1])
      else if (def && typeof def === 'object' && def.name) tools.set(def.name, def)
    } },
    provide: (name, svc) => {
      if (name === 'cardian') provided = svc
    },
    logger: console,
  }
  apply(ctx, { vaultPath })
  await provided.ready
  return { vaultPath, tools }
}

const T = (tools, name) => {
  assert.ok(tools.has(name), `tool registered: ${name}`)
  return tools.get(name)
}

test('runtime registers exactly 36 tools', async () => {
  const { tools } = await boot()
  assert.equal(tools.size, 36)
})

test('wiki.sync end-to-end: ingest → add/change → prune', async () => {
  const { tools } = await boot()
  const repo = await mkdtemp(path.join(tmpdir(), 'wire-repo-'))
  await writeFile(path.join(repo, 'a.js'), 'export function alpha() {}\n')
  await writeFile(path.join(repo, 'b.md'), '# doc\n')
  await T(tools, 'cardian.wiki.ingest').execute({ repoPath: repo, repoName: 'w' })
  await writeFile(path.join(repo, 'c.py'), 'import os\n\ndef gamma(): pass\n')
  let r = await T(tools, 'cardian.wiki.sync').execute({ repoPath: repo, repoName: 'w' })
  assert.ok(r.added.includes('c.py'), 'new file lands in added')
  await rm(path.join(repo, 'b.md'))
  r = await T(tools, 'cardian.wiki.sync').execute({ repoPath: repo, repoName: 'w' })
  assert.ok(r.pruned.includes('b.md'), 'orphan page pruned')
})

test('cardType flows through tool args → filtered list', async () => {
  const { tools } = await boot()
  await T(tools, 'cardian.card.upsert').execute({ title: '规范卡', content: 'x', cardType: 'convention' })
  await T(tools, 'cardian.card.upsert').execute({ title: '概览卡', content: 'y', cardType: 'overview' })
  const hits = await T(tools, 'cardian.card.list').execute({ cardType: 'convention' })
  assert.equal(hits.length, 1)
  assert.equal(hits[0].cardType, 'convention')
})

test('feedback / promote / overview / skill.export via tool handles', async () => {
  const { vaultPath, tools } = await boot()
  const c = await T(tools, 'cardian.card.upsert').execute({
    title: '待校',
    content: 'x',
    confidence: 0.9,
  })
  const fb = await T(tools, 'cardian.feedback').execute({
    ref: c.id ?? '待校',
    kind: 'correction',
    note: '说反了',
  })
  assert.equal(fb.confidence, 0.7)

  await T(tools, 'cardian.memory.commit').execute({
    title: '要点',
    content: '蓝绿发布',
    importance: 5,
  })
  const pr = await T(tools, 'cardian.memory.promote').execute({ ref: '要点' })
  assert.equal(pr.file, 'PROJECT.md')
  const proj = await readFile(path.join(vaultPath, 'PROJECT.md'), 'utf8')
  assert.ok(proj.includes('晋升自记忆库：要点'))

  const repo = await mkdtemp(path.join(tmpdir(), 'wire-ov-'))
  await writeFile(path.join(repo, 'util.ts'), 'export function helper() {}\n')
  await T(tools, 'cardian.wiki.ingest').execute({ repoPath: repo, repoName: 'ov' })
  const ov = await T(tools, 'cardian.wiki.overview').execute({ repo: 'ov' })
  assert.ok(ov.pages >= 1)
  const page = await T(tools, 'cardian.wiki.get').execute({ repo: 'ov', path: '__OVERVIEW__' })
  assert.ok(String(page.body).includes('# 项目概览'))

  const sk = await T(tools, 'cardian.skill.export').execute({ name: '规约包', section: 'cards' })
  assert.ok(sk.entries >= 1)
  const skillMd = await readFile(path.join(vaultPath, sk.skill, 'SKILL.md'), 'utf8')
  assert.ok(skillMd.includes('](./notes/'))
})
