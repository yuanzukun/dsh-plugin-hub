# 02 · manifest 与配置层细节

> 这一层是兼容性的"命门"。字段名写错、层级放错、插件分类错，都会直接导致 DSH 加载失败或启动崩溃。

## 1. `package.json` 的 `dsh` 字段

```jsonc
{
  "name": "dsh-my-plugin",
  "version": "0.1.0",
  "type": "module",
  "main": "index.js",
  "files": ["index.js", "cordis.patch.yml"],
  "dsh": {
    "bundle": { "patch": "./cordis.patch.yml" }   // bundle patch 入口（注意：dsh.bundle.patch，不是 bundlePatch）
    // "profile": { ... }                          // profile 列出堆叠的 bundles
    // "client": "./client"                        // 客户端插件入口（仅客户端插件声明）
  }
}
```

- `dsh.bundle.patch` 指向该 bundle 的 `cordis.patch.yml`。
- `dsh.profile` 列出其堆叠的 bundles。
- `dsh.client` + 导出 `./client`：客户端插件包。**这类插件不能放进 `dsh.profile.bundles`**，否则启动崩溃（见 §5）。

## 2. `cordis.patch.yml`（bundle 补丁）

```yaml
- insert:
    - id: my-plugin            # 稳定行标识，整行替换用
      name: dsh-my-plugin      # npm 包名（如 @deepseek-ai/dsh-llm-deepseek）
      config:                  # 该插件的完整配置
        apiKeyEnv: DEEPSEEK_API_KEY
```

要点：

- `insert:` 列表，每行含 `id`（稳定行标识）、`name`（npm 包名）、`config`（完整配置）。
- patch 按 `id` **整行替换（last-write-wins）**，**不做字段级 merge**——所以 patch 里要给完整 config，不能只给增量字段。

## 3. `cordis.yml`（用户/加载配置）

```yaml
- id: some-plugin
  name: "@deepseek-ai/dsh-llm-deepseek"
  config:
    apiKey: !!js process.env.DEEPSEEK_API_KEY   # !!js 注入表达式（双感叹号，不是 !js）
  disabled: !!js process.env.NODE_ENV === 'test' # 可条件化禁用
```

要点：

- 条目含 `id`、`name`、`config`、`disabled`。
- `!!js` 注入表达式（官方强调是 `!!js` 而非 `!js`）。
- `disabled` 可条件化（布尔或 `!!js` 表达式）。

## 4. 层级覆盖顺序

启动时组合为插件树的顺序：

```
1. profile 列出的各 bundle（按 profile 里声明的顺序）
2. profile 的 cordis.patch.yml
3. 用户 home 级 patch
4. --patch 覆盖层（最后覆盖）
```

调试/验证：`dsh --profile web --dump-config` 打印实际启动树。

## 5. bundle ↔ cordis 重分类（最高优先级自愈动作）

- `dsh.profile.bundles`：宿主侧插件集合。
- `dsh.client`：客户端插件（导出 `./client`）。
- **误把只有 `dsh.client` 的插件塞进 `dsh.profile.bundles` 会让 DSH 启动崩溃**。这是你 hotplug-hub 自愈闭环里应排第一的重分类动作。

## 6. profile 落点与拉起

- 真实 profile 目录：`~/.dsh/profiles/<id>`（内含 `package.json` + `cordis.patch.yml`）。
- 启动器以 `DSH_PROFILE=<id>` 拉起官方 DSH（DSH Desktop / CLI）。
- sandbox（编辑/自愈期）与真实 profile 分离：sandbox 只在编辑/自愈期存在，启动时同步为 `~/.dsh/profiles/<id>` 再拉起。

## 7. 一个完整的最小插件示例（官方 dsh-hello-plugin 风格）

`package.json`：

```json
{
  "name": "dsh-hello-plugin",
  "version": "0.1.0",
  "type": "module",
  "main": "index.js",
  "files": ["index.js", "cordis.patch.yml"],
  "dsh": { "bundle": { "patch": "./cordis.patch.yml" } }
}
```

`index.js`（插件契约）：

```js
export const name = 'hello'
export const inject = ['llm']                       // 依赖 llm，加载顺序由此决定
export const Config = Schema.object({ greeting: Schema.string().default('hi') })

export function apply(ctx, config) {
  ctx.tools.register('hello', {                      // 示例：注册一个模型可调用工具
    name: 'hello',
    description: 'say hello',
    parameters: { type: 'object', properties: {}, required: [] },
    async execute() { return config.greeting }
  })
}
```

`cordis.patch.yml`：

```yaml
- insert:
    - id: hello
      name: dsh-hello-plugin
      config:
        greeting: hello world
```

> 注：`Schema` 来自 schemastery（Cordis 生态）；具体工具注册签名以官方 `docs/tool-catalog.md` 与 `adding-a-tool.md` 为准，此处仅示意契约形态。
