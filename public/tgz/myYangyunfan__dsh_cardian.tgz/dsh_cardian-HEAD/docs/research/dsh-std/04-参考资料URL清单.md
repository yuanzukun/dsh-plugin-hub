# 04 · 参考资料 URL 清单

## 官方（权威）

- 主仓库：<https://github.com/deepseek-ai/deepseek-harness>
- 官网：<https://deepseek.com/harness>
- 官方文档站：<https://deepseek-harness.github.io/deepseek-harness/guide/quickstart>
- 插件发现 topic：<https://github.com/topics/dsh-plugin>
- DeepSeek API 文档：<https://api-docs.deepseek.com/>
- DeepSeek 工具调用指南：<https://api-docs.deepseek.com/guides/tool_calls>

仓库内关键文档（master 分支原始路径）：

- `docs/architecture.md` — 架构总纲（seam 映射表在这）
- `docs/cordis-primer.md` — Cordis 插件框架入门
- `docs/config-catalog.md` — 插件 Config 目录
- `docs/tool-catalog.md` — 工具目录
- `docs/cookbook/adding-an-llm-adapter.md` — 新增 LLM 适配器指南
- `docs/cookbook/adding-a-package.md` — 新增工作区包
- `docs/cookbook/adding-a-tool.md` — 新增工具
- `docs/user/develop/basic/publish.md` — `dsh.bundle` / `dsh.profile` 双 manifest 说明
- `docs/user/develop/practice/llm-adapter.md` — LLM adapter 实操
- `docs/cordis-tutorial/01-first-plugin.md` … `07-into-the-harness.md` — 插件协议教程

## 底层框架

- Cordis：<https://github.com/cordiverse/cordis>（"Meta-Framework of Spatiotemporal Composability"）
- Cordis 设计论文：<https://github.com/cordiverse/paper>

## 社区 dsh-std / 生态（非官方）

- `Yan-Zero/dsh-std`：<https://github.com/Yan-Zero/dsh-std>（`@dsh-std/core` + `@dsh-std/adapter-dsh` + `dsh-plugin.json` 提案，`docs/proposals/manifest.zh.md`、`adapter-dsh.zh.md`）
- `awesome-dsh-plugin`：<https://github.com/awesome-dsh-plugin/awesome-dsh-plugin>（社区插件精选列表）
- `bitterSmilezzz/dsh-plugins`：<https://github.com/bitterSmilezzz/dsh-plugins>（"dsh-std 协议契约" + 静态校验脚本）

## 跨框架协议参考

- MCP 规范：<https://modelcontextprotocol.io/specification/2025-06-18/> · schema 源：<https://github.com/modelcontextprotocol/specification/blob/main/schema/2025-06-18/schema.ts> · registry：<https://registry.modelcontextprotocol.io>
- A2A：<https://a2a-protocol.org/latest/> · proto：<https://github.com/google/A2A/blob/main/specification/a2a.proto> · AgentCard：<https://a2a-protocol.org/latest/topics/agent-card/>
- ACP（已并入 A2A，作历史参考）：<https://agentcommunicationprotocol.dev> · <https://github.com/i-am-bee/acp>
- OpenAI Plugin manifest：<https://platform.openai.com/docs/plugins/getting-started/plugin-manifest> · function calling：<https://platform.openai.com/docs/guides/function-calling> · OpenAPI 源：<https://github.com/openai/openai-openapi>
- LiteLLM：<https://docs.litellm.ai/docs/providers> · <https://docs.litellm.ai/docs/routing> · 架构：<https://github.com/BerriAI/litellm/blob/main/ARCHITECTURE.md>
- lm-evaluation-harness：<https://github.com/EleutherAI/lm-evaluation-harness/blob/main/docs/new_task_guide.md>
- vLLM 插件系统：<https://docs.vllm.ai/en/latest/design/plugin_system.html>
- Transformers pipeline：<https://huggingface.co/docs/transformers/main/en/pipeline_tutorial>
- Open-WebUI 插件：<https://docs.openwebui.com>

## 备注

- 版本号（`@deepseek-ai/dsh` npm 包、`dsh 0.1.x-rc`）在快速滚动，引用时以仓库实时值为准。
- star 数（研究时读到约 19.5 万）与仓库创建时间（2026-08）不匹配，属快速爆红/口径差异，核对时以仓库页实时值为准。
