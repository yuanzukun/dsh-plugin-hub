# 03 · 社区 dsh-std 与跨框架协议

> 这章是"前瞻参考"，不是官方标准。核心作用：如果你想将来让插件**跨 host**（TUI / Web / 桌面 / 远程通用），或想借鉴成熟协议设计自己的兼容层，这章给出可复用的要素。

## 1. 社区 dsh-std（非官方）

- `Yan-Zero/dsh-std`（~85 star，TypeScript，topic `dsh-plugin`）：
  - `@dsh-std/core`：**元协议**（管协议的协议），用 `apiVersion + kind` 坐标做发现/协商。
  - `@dsh-std/adapter-dsh`：**适配层**，专门吸收上游 DSH 的破坏性变更。
  - 定义静态 manifest **`dsh-plugin.json`（Community v0.15）**。
- `bitterSmilezzz/dsh-plugins`（伞仓库）：把"dsh-std 协议契约"列为强制契约，配 `scripts/validate-plugin.mjs` 静态校验。

**官方 vs 社区的关键区分**：

| | 官方 | 社区 dsh-std |
|---|---|---|
| manifest 位置 | `package.json` 的 `dsh` 键 | 根目录独立 `dsh-plugin.json` |
| 校验方式 | schemastery（运行时 Config） | 静态 JSON + 校验脚本 |
| 定位 | 面向真实 harness | 面向跨 host 互操作 |

`dsh-plugin.json` 建议字段（社区提案，非官方）：`$schema`、`manifestVersion`、`id`、`name`、`version`、`facets.host.entry` + `facets.host.apiVersion`、`requires.contracts`（`apiVersion + kind` 坐标）、`permissions`、`contributes`、`subscriptions`。

**核心原则**：manifest 是静态 JSON，**host 在读身份/兼容性时不得执行插件代码**。

## 2. 成熟协议提炼（用于设计"通用兼容协议"）

| 协议 | 可借鉴点 |
|---|---|
| **MCP**（Model Context Protocol） | `initialize` 握手 + `capabilities` 能力协商；JSON-RPC 2.0 消息信封；tools/resources/prompts 三原语；stdio / streamable HTTP 传输；分层整型错误码 |
| **A2A**（Agent-to-Agent，Google，Linux Foundation） | `AgentCard` 数字名片（name/description/version/skills[]/capabilities/securitySchemes）；`/.well-known/agent-card.json` 发现；任务状态机（submitted→working→completed/failed/canceled…） |
| **OpenAI plugin / function calling** | `ai-plugin.json` 清单（`api.url` 指向 OpenAPI）；工具 schema 事实标准 `{type:"function", function:{name,description,parameters,strict}}`；`tool_calls.arguments` 为 JSON 字符串 |
| **LiteLLM** | 每 provider 一个对称 adapter（`transform_request` / `transform_response`）；router（别名/策略路由）；`pass-through` 兜底 |
| **vLLM** | entry-points 插件系统（`vllm.general_plugins` 等）；`ModelRegistry.register_model`；文档化稳定接口 + 兼容承诺 |
| **EleutherAI lm-eval** | 任务 YAML + `--include_path` 外部目录注册；`metadata.version` 版本化 |
| **Open-WebUI** | `manifest.json`（id/name/version）+ `Pipe`/`Function`/`Filter` 三类扩展点 + `Valves` 动态配置 |

## 3. "通用兼容协议"核心要素清单（可直接作为 dsh-std 规范骨架）

1. **Manifest（元数据）**：`id`、`name`、`version`（SemVer）、`description_for_model` / `description_for_human`、`author`、`license`、`entrypoint`、`required_protocol_version`（支持范围）、`api/url`。
2. **能力声明与发现**：`capabilities`、`skills`、`input_modes` / `output_modes`、`extensions[]`；well-known URI（如 `/.well-known/dsh-plugin.json`）+ 中心 registry 两种发现。
3. **生命周期钩子**：`initialize`/`initialized` → `activate`/`deactivate` → `shutdown`；`ping/health`；`configure`（Valves/动态配置）。
4. **能力/版本协商**：握手交换 `protocolVersion` + `capabilities`，取最大共同交集；不匹配时明确报错，不静默。
5. **统一消息路由**：统一信封（`id` 关联请求/响应）+ Router；按能力/别名路由到 adapter；`pass-through` 兜底。
6. **统一接口抽象**：`ChatMessage`/`ModelResponse`/`ToolSchema` + adapter 接口（`transform_request`/`transform_response` 或 `preprocess/_forward/postprocess`）。
7. **工具/函数 schema**：业界事实标准 `{type:"function", function:{name, description, parameters(JSON Schema), strict}}`；`tool_choice` 支持 none/auto/required/指定。
8. **传输层**：stdio（本地）、streamable HTTP/SSE（远端）；HTTP 走 OAuth2/OIDC/APIKey，stdio 走环境变量凭证。
9. **错误码与状态机**：分层整型错误码（解析/请求/方法/参数/内部 + 协议扩展段）；任务/工具调用状态机。
10. **流式/异步/取消/进度**：SSE/分块流、异步 task、cancellation、进度通知。
11. **安全边界**：用户同意与授权、工具调用前审批、沙箱/最小权限、`roots` 作用域、标注（annotation）视为不可信。
12. **可观测性**：logging、tracing、成本/用量归因、telemetry hooks。
13. **版本与兼容策略**：SemVer + 保留命名空间（`_meta`、`x-` 前缀扩展）+ 插件兼容承诺 + 弃用/迁移路径。

> 两个被反复验证的"粘合点"：**（a）统一内部对象 + 每 provider 对称转换函数**；**（b）声明式 manifest + 握手期能力/版本协商**。这两点应作为任何 dsh-std 的一等公民。
