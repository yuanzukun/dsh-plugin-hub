# 03 · 跨框架 adapter 模式

> 目的：把"adapter"这个词在开源 AI 工具链里的成熟做法归纳成一套可复用的思维模型，帮你写 dsh adapter / 组合层 adapter 时少走弯路。

## 1. GoF Adapter 在 AI harness 里的落地

标准四元组：**Client（宿主）→ Target（统一接口）← Adapter（包装）← Adaptee（第三方后端）**。

在 AI harness 中的映射：

| 角色 | 例子 |
|---|---|
| Target（统一抽象） | `ChatMessage` / `ModelResponse` / `ToolSchema` + 统一方法名（`completion` / `call_tool` / `stream`） |
| Adapter | 每个 provider/插件一个类：`transform_request` / `transform_response`（LiteLLM 式）或 `preprocess/_forward/postprocess`（Transformers 式） |
| Adaptee | OpenAI / Anthropic / vLLM / Ollama / MCP Server 等具体后端 |
| Registry | 按 scheme/名字/entry point 注册：vLLM `ModelRegistry`、Transformers `PIPELINE_REGISTRY`、LiteLLM provider 表、dsh `ctx.llm.registerAdapter` |

## 2. 各框架的 adapter 形态速览

- **LiteLLM**：每个 provider 一个 `transformation.py`，实现 `transform_request()` / `transform_response()`，把统一 `ModelResponse` 与 provider 私有 wire 格式互转；`BaseLLMHTTPHandler` 负责 HTTP 层；`pass-through` 兜底未知模型。
- **vLLM**：Python entry points（`vllm.general_plugins` 等），`ModelRegistry.register_model(name -> module)`，插件对目标版本负责。
- **Transformers**：`pipeline(task, model)` 经 task→pipeline 映射表实例化，`Pipeline` 基类提供 `preprocess/_forward/postprocess` 钩子。
- **Open-WebUI**：`manifest.json` + `Pipe`/`Function`/`Filter` 三类扩展点 + `Valves` 配置。
- **MCP**：adapter = 把任意后端包装成 MCP Server，实现 `tools/list`、`tools/call`、`resources/list`、`prompts/list`，`initialize` 握手交换 capabilities。
- **A2A**：adapter = 生成 `AgentCard` + 实现 `message/send` / `message/stream`，把自有 agent 暴露为 A2A Server。

## 3. 三种最值得抄的"粘合"设计

1. **对称转换**（LiteLLM 式）：统一内部对象 ↔ provider 私有格式，各一个纯函数。这是 dsh `llm-deepseek` 里 `serialize.ts`（请求）+ `translate.ts`（响应）做的事。
2. **声明式 manifest + 握手协商**（MCP/A2A 式）：静态 manifest 描述能力，握手交换 `protocolVersion` + `capabilities`，取交集；不匹配就明确报错。
3. **注册表 + pass-through 兜底**（LiteLLM/vLLM 式）：按别名/路由注册 adapter，未知能力直接透传，宁可直通、不可阻断。

## 4. 落到 dsh 的建议

- 写模型 adapter：照 `llm-deepseek` 的 `serialize/translate/sse/adapter` 拆分，对称转换 + `StreamChunk` 顺序约束（见 `adapter/01`）。
- 写组合层 adapter（hotplug-hub）：把 pack/bundle 组合**映射**到 `dsh.bundle.patch` + `cordis.patch.yml` + `dsh.profile.bundles`，索引字段（apiLevel/provides/requires/conflicts）只存 `resolvedAssembly`，不写回 `package.json`。
- 跨 host 时：再叠加社区 `dsh-plugin.json` 静态 manifest 的思路（host 读身份/兼容性时不执行插件代码），见 `dsh-std/03`。
