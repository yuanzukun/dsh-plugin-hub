# 01 · LLM Adapter 协议（官方 seam）

> 来源：`docs/cookbook/adding-an-llm-adapter.md`、`docs/user/develop/practice/llm-adapter.md`、`packages/llm/llm`（领域基座）与 `packages/llm/llm-deepseek`（参考实现）。

## 1. 定位

- `packages/llm/llm` 提供 **provider 无关**的 `LlmAdapter` + `StreamChunk` 协议。
- 适配器通过 `ctx.llm.registerAdapter(providers, adapter)` 注册；`options.provider` 选路由，`options.model` 是 provider 的模型 id。
- 一个"seam" = Service Definition + Service Provider（你的 adapter）+ Consumer（通常是模型可调用工具）。

## 2. 必须实现的接口

```ts
class MyAdapter extends LlmAdapter {
  async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    // 1. 把 GenerateOptions 翻译成 provider 私有 wire 请求
    // 2. fetch + SSE 流式读取
    // 3. 把 provider 响应翻译成 StreamChunk 逐个 yield
    // 4. 结束时 yield finish（含 usage / kind / replayState）
  }
}
```

- `options.provider`：路由名（如 `deepseek-official`）。
- `options.model`：provider 侧的模型 id。

## 3. 硬性协议义务（写 adapter 必守）

1. **`arguments` 全程原始 JSON 字符串**：工具调用参数不对象化，端到端保留字符串；流式分片用 `argumentsDelta`。
2. **顺序约束**：`usage` 必须在 `finish` 之前发出；`finish` 之后不得再发任何东西。
3. **错误只有两条合法路径**：
   - `throw`：传输/协议错误，用带稳定 code 的 `LlmError`。
   - 流尾 `finish {kind:'error'|'aborted'}`：provider 带内错误/中止。
4. **不支持就显式报错**：无法支持的 `GenerateOptions` 字段要 `throw LlmError(..., 'UNSUPPORTED')`，**不能静默丢弃**。
5. **原生元数据回传**用 `finish.replayState`（最小无损 JSON 投影）。

## 4. 职责拆分（参考 `llm-deepseek` 的文件布局）

| 文件 | 职责 |
|---|---|
| `src/adapter.ts` | adapter 类：`class X extends LlmAdapter { async *stream() {...} }` |
| `src/index.ts` | 插件入口：`name/inject/Config/apply` + `ctx.llm.registerAdapter(providers, adapter)`；只导出插件契约 + Adapter 类 |
| `src/translate.ts` | provider 响应 → `StreamChunk` |
| `src/serialize.ts` | `GenerateOptions` → provider 请求 |
| `src/sse.ts` | SSE 流解析（`eventsource-parser` 帧化） |
| `src/types.ts` | wire 类型 |
| `src/invariant.ts` | 不变量/断言 |
| `tests/` | `adapter.spec.ts` / `adapter.e2e.ts` / `mock-server.ts` / `assemble.ts` / `fixtures/` |

> 原则：wire/sse/translate 这些实现细节**不进根契约**（不塞进 `index.ts` 的主导出），根只暴露插件契约 + Adapter 类。

## 5. 参考：DeepSeek 官方 adapter 的 wire 要点

- 路由名 `deepseek-official`，默认模型 `deepseek-v4-flash`。
- OpenAI 兼容：`https://api.deepseek.com/chat/completions`，`Authorization: Bearer`。
- `thinking` / `reasoning_effort`（off/low/high/max）→ 官方 `reasoning_effort` 字段。
- `stream_options.include_usage` 恒开；缓存命中 token 从 `prompt_cache_hit_tokens` 读取。
- 用 `eventsource-parser` 做 SSE 帧化。

## 6. 测试边界

- 用 `mock-server.ts` 模拟 provider，隔离真实 API。
- e2e 覆盖：正常流、错误路径（throw vs `finish{kind:'error'}`）、`usage` 先于 `finish`、`arguments` 字符串透传、`UNSUPPORTED` 报错。
