import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { randomUUID } from 'node:crypto'
import { once } from 'node:events'
import { access, copyFile, cp, mkdir, mkdtemp, readFile, rm, symlink, writeFile } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import { setTimeout as delay } from 'node:timers/promises'
import { fileURLToPath, pathToFileURL } from 'node:url'

// Load only as an explicit --patch row in an isolated DSH Web test profile.
export const name = 'drama-agent-fixture'
export const inject = ['agents', 'connection', 'llm', 'sessionController', 'tools', 'webServer', 'workspaceRegistry']

const provider = 'drama-fixture'
const model = 'scripted'
const sourceStage = 'content-analysis'
const restartStage = 'shooting-script'
const topicStage = 'topic-selection'
const kickoffPrefix = 'drama-workflow:'

export function apply(ctx) {
  const life = new AbortController()
  const run = verify(ctx, life.signal).catch(error => {
    if (!life.signal.aborted) console.error('[drama-agent-fixture] FAIL', error.stack)
  })
  ctx.effect(() => async () => {
    life.abort()
    await run
  }, name)
}

async function verify(ctx, signal) {
  assert.ok(process.env.DSH_HOME, 'The fixture requires an isolated DSH_HOME')
  const root = join(process.env.DSH_HOME, 'drama-agent-fixture')
  const statePath = join(root, 'restart.json')
  const workspacePath = join(root, 'project')
  const state = await readFile(statePath, 'utf8').then(JSON.parse, error => {
    if (error.code !== 'ENOENT') throw error
    return undefined
  })
  const origin = ctx.webServer.getOrigin()
  const loginURL = ctx.connection.authenticatedUrl(origin)
  async function login(url, redirect) {
    const response = await fetch(url, { redirect: 'manual', signal })
    const value = response.headers.get('set-cookie')
    return response.status === redirect && value ? value.split(';', 1)[0] : undefined
  }
  const cookie = await until(() => login(loginURL, 303), signal, 'DSH owner login')

  async function request(path, body, credential = cookie) {
    const headers = { 'content-type': 'application/json', origin }
    if (credential) headers.cookie = credential
    return fetch(new URL(`/api/drama/${path}`, origin), {
      method: 'POST', headers, body: JSON.stringify(body), signal,
    })
  }

  async function ok(response, label) {
    if (!response.ok) {
      const error = await response.json().catch(() => ({}))
      assert.fail(`${label}: HTTP ${response.status} ${error.error ?? ''}`)
    }
    return response.json()
  }

  const init = async sessionId => until(async () => {
    const response = await request('init', { sessionId })
    // Native Web can admit its owner while the plugin is still starting the kernel.
    if (response.status === 404 && !response.headers.get('content-type')?.includes('application/json')) {
      await response.body?.cancel()
      return undefined
    }
    return ok(response, 'init')
  }, signal, 'Studio Host routes')
  const op = async (ticket, action, data = {}) => ok(
    await request('operation', { ticket, action, data: { operationId: randomUUID(), ...data } }), action,
  )
  const readWorkflow = async ticket => ok(await request('operation', { ticket, action: 'workflow_get' }), 'workflow_get')

  const cli = process.env.DRAMA_DSH_CLI
  const lib = cli ? createRequire(cli).resolve('@deepseek-ai/dsh-llm')
    : join(dirname(process.execPath), 'resources', 'app.asar', 'dsh', 'node_modules', '@deepseek-ai', 'dsh-llm', 'lib', 'index.js')
  const { createUserMessage, LlmAdapter, LlmError } = await import(pathToFileURL(lib).href)
  const protocol = createRequire(lib).resolve('@deepseek-ai/dsh-typert-protocol')
  const { RemoteError } = await import(pathToFileURL(protocol).href)
  const script = []
  let offered = []
  ctx.llm.registerAdapter([provider], new class extends LlmAdapter {
    async listModels() {
      return [{ provider, id: model, name: model }]
    }

    async * stream(options) {
      const step = script.shift()
      assert.ok(step, 'Unexpected fixture model request')
      if (step.hold) {
        step.hold.entered = true
        await once(step.hold.release, 'release', { signal: options.signal })
        if (step.fail) throw new LlmError('Deliberate native fixture request error', 'AUTH')
      }
      if (step.call) {
        const { id, name, args } = step.call
        offered = options.tools?.map(tool => tool.name) ?? []
        assert.ok(offered.includes(name), `Tool not offered to native Agent: ${name}`)
        const block = { type: 'tool-call', id, name, arguments: JSON.stringify(args) }
        yield { type: 'block-start', index: 0, blockType: 'tool-call' }
        yield { type: 'block-end', index: 0, block }
        yield { type: 'usage', usage: { inputTokens: 10, outputTokens: 5 } }
        yield { type: 'finish', reason: { kind: 'tool-calls' } }
        return
      }
      const block = { type: 'text', text: 'Fixture done' }
      yield { type: 'block-start', index: 0, blockType: 'text' }
      yield { type: 'block-end', index: 0, block }
      yield { type: 'usage', usage: { inputTokens: 10, outputTokens: 5 } }
      yield { type: 'finish', reason: { kind: 'stop' } }
    }
  })

  const sessions = ctx.sessionController
  async function holdTurn(sessionId, { fail = false, owner, nodeId } = {}) {
    const agent = owner ?? (await sessions.resolveAgent(sessionId)).agent
    assert.equal(agent?.status, 'idle')
    const startSeq = agent.session.snapshotEvents().at(-1)?.seq ?? -1
    const hold = { release: new EventTarget(), entered: false }
    if (nodeId) script.push({ call: { id: randomUUID(), name: 'drama_query', args: { id: nodeId } } })
    script.push({ hold, fail })
    const content = [{ type: 'text', text: 'Hold this native turn for the Workspace edit check.' }]
    if (owner) {
      agent.followup(createUserMessage({ content, source: { kind: 'user' } }))
    } else {
      const admission = await sessions.prompt({ sessionId, requestId: randomUUID(), mode: 'queue', content }, signal)
      assert.equal(admission.accepted, true)
    }
    await until(() => hold.entered && agent.status === 'running', signal, 'held native turn')
    return {
      agent,
      finish: () => hold.release.dispatchEvent(new Event('release')),
      ending: () => until(() => {
        if (agent.status !== 'idle') return undefined
        return agent.session.snapshotEvents().find(event => event.seq > startSeq && event.type === 'turn/end')?.data.reason
      }, signal, 'native turn settlement'),
    }
  }
  let nativeCalls = 0
  async function call(sessionId, toolName, args) {
    const resolved = await sessions.resolveAgent(sessionId)
    assert.ok(resolved.agent, 'Native Agent did not resolve')
    const id = randomUUID()
    const startSeq = resolved.agent.session.snapshotEvents().at(-1)?.seq ?? -1
    offered = []
    script.push({ call: { id, name: toolName, args } }, {})
    const admission = await sessions.prompt({
      sessionId, requestId: randomUUID(), mode: 'queue', content: [{ type: 'text', text: 'Run the test step.' }],
    }, signal)
    assert.equal(admission.accepted, true)
    const events = await until(() => {
      const current = resolved.agent.session.snapshotEvents().filter(event => event.seq > startSeq)
      return resolved.agent.status === 'idle' && current.some(event => event.type === 'turn/end') ? current : undefined
    }, signal, `Agent turn ${toolName}`)
    const loggedCall = events.find(event => event.type === 'tool/call' && event.data.callId === id)
    const diagnostics = events.filter(event => event.type.includes('error') || event.type === 'turn/end')
      .map(({ type, data }) => ({ type, data }))
    assert.equal(loggedCall?.data.name, toolName,
      `No native tool/call for ${toolName}. Offered: ${offered.join(', ')}. Turn: ${JSON.stringify(diagnostics)}`)
    const result = events.find(event => event.type === 'tool/result' && event.data.message.toolCallId === id)
    assert.ok(result, `No native tool/result for ${toolName}`)
    assert.equal(script.length, 0, 'Native Agent did not finish the scripted turn')
    nativeCalls++
    const { message } = result.data
    return { isError: message.isError === true, text: message.content.map(block => block.text ?? '').join('\n') }
  }

  async function succeed(sessionId, toolName, args) {
    const result = await call(sessionId, toolName, args)
    assert.equal(result.isError, false, result.text)
    return JSON.parse(result.text)
  }

  async function reject(sessionId, toolName, args, reason) {
    const result = await call(sessionId, toolName, args)
    assert.equal(result.isError, true, `Expected ${toolName} to reject`)
    if (reason) assert.match(result.text, reason)
  }

  if (state) {
    const restored = await init(state.sessionId)
    assert.equal(restored.status.canvasId, state.canvasId)
    assert.equal(restored.status.connected, true)
    assert.equal(restored.status.autoGenerate, false)
    assert.equal(restored.status.aiRunning, false, 'An interrupted native turn was treated as a persistent lock')
    const workflow = await until(async () => {
      const view = await readWorkflow((await init(state.executorSessionId)).ticket)
      return view.session.status === 'failed' && view
    }, signal, 'interrupted Workflow recovery')
    assert.equal(workflow.id, state.workflowId)
    assert.equal(workflow.session.activeStageId, restartStage)
    assert.ok(workflow.session.error)
    assert.equal(workflow.stages[0].status, 'handed_off')
    assert.equal(workflow.stages[1].status, 'not_started')
    assert.ok(workflow.stages[1].files.harnessReady && workflow.stages[1].files.skillReady)
    assert.equal(workflow.handoffs.length, 1)
    assert.equal(workflow.handoffs[0].handoffId, state.handoffId)
    assert.equal(workflow.handoffs[0].sourceSessionId, state.executorSessionId)
    assert.equal(workflow.artifacts.find(item => item.artifactId === state.artifactId)?.content, 'Restart fixture: pinned analysis')
    const otherView = await readWorkflow(restored.ticket)
    assert.equal(otherView.session.status, 'normal')
    assert.equal(otherView.handoffs[0].handoffId, state.handoffId)
    const [note] = (await ok(await request('operation', {
      ticket: restored.ticket, action: 'query', data: { id: state.noteId },
    }), 'read note after restart')).nodes
    await op(restored.ticket, 'update_node', { id: note.id, revision: note.revision, content: { description: 'Editable after Harness restart' } })
    const staleTicket = await request('operation', {
      ticket: state.ticket, action: 'permission', data: { operationId: randomUUID(), enabled: true },
    })
    assert.equal(staleTicket.status, 403, 'Restart accepted an old authorization ticket')
    await sessions.selectModel({ sessionId: state.sessionId, provider, model })
    await reject(state.sessionId, 'drama_submit', { operationId: randomUUID(), nodeId: state.videoId }, /automatic generation is disabled/i)
    assert.equal((await succeed(state.sessionId, 'drama_query', { type: 'shot' })).nodes.length, 2)

    const { pending } = state
    const pendingTicket = (await init(pending.sessionId)).ticket
    const waiting = await readWorkflow(pendingTicket)
    assert.equal(waiting.workflowProfileId, 'short-video')
    assert.equal(waiting.session.activeStageId, sourceStage)
    assert.equal(waiting.session.pendingHandoffId, pending.handoffId)
    assert.equal(waiting.session.activation, pending.activation)
    assert.equal(waiting.session.status, 'failed')
    assert.match(waiting.session.error, /DSH 拒绝接收交接任务/u)
    assert.equal(waiting.handoffs.length, 1)
    const replay = await op(pendingTicket, 'workflow_handoff_confirm', { handoffId: pending.handoffId })
    assert.equal(replay.handoff.handoffId, pending.handoffId)
    assert.equal(replay.session.pendingHandoffId, pending.handoffId)

    await sessions.selectModel({ sessionId: pending.sessionId, provider, model })
    const { agent: pendingAgent } = await sessions.resolveAgent(pending.sessionId)
    const kickoffMessages = () => pendingAgent.session.snapshotEvents().filter(event => event.type === 'user/message' &&
      event.data.source?.rpcId?.startsWith(kickoffPrefix + pending.handoffId + ':'))
    assert.equal(kickoffMessages().length, 0, 'Host restart or receipt replay started the Agent without explicit retry')
    const callId = randomUUID()
    script.push({ call: { id: callId, name: 'drama_workflow_artifact', args: pending.artifact } }, {})
    const retryResults = await Promise.all([1, 2].map(() => request('operation', {
      ticket: pendingTicket, action: 'workflow_handoff_retry', data: { handoffId: pending.handoffId },
    })))
    assert.ok(retryResults.some(response => response.ok))
    assert.ok(retryResults.every(response => response.ok || response.status === 409))
    await Promise.all(retryResults.map(response => response.json()))
    const readResult = await until(async () => {
      const result = pendingAgent.session.snapshotEvents().find(event => event.type === 'tool/result' &&
        event.data.message.toolCallId === callId)
      const view = await readWorkflow(pendingTicket)
      return result && pendingAgent.status === 'idle' && view.session.status === 'active' && {
        message: result.data.message, view,
      }
    }, signal, 'pending Short Video kickoff settlement')
    assert.equal(readResult.message.isError ?? false, false)
    const pinned = JSON.parse(readResult.message.content.map(block => block.text ?? '').join('\n'))
    assert.equal(pinned.artifactId, pending.artifact.artifactId)
    assert.equal(pinned.version, pending.artifact.version)
    assert.equal(pinned.content, 'Short Video fixture: pinned topic plan')
    assert.equal(pinned.handedOff, true)
    assert.equal(readResult.view.session.pendingHandoffId ?? '', '')
    assert.equal(readResult.view.session.activation, pending.activation)
    assert.equal(readResult.view.handoffs.length, 1)
    assert.equal(readResult.view.handoffs[0].handoffId, pending.handoffId)
    assert.equal(kickoffMessages().length, 1, 'Concurrent retry created duplicate native prompt messages')
    assert.equal(script.length, 0)
    console.info(`[drama-agent-fixture] EVIDENCE pending receipt survived restart; explicit concurrent retry admitted one native prompt; target read ${pinned.artifactId} v${pinned.version} from ${pending.handoffId}`)
    console.info(`[drama-agent-fixture] PASS restart: pending Short Video retry recovered once, interrupted Workflow recovered, Canvas persisted, human edit restored, stale ticket and Agent submit rejected (${nativeCalls + 1} native tool calls)`)
    return
  }

  await mkdir(workspacePath, { recursive: true })
  const dataDir = join(workspacePath, '.drama-studio')
  await mkdir(dataDir)
  const { DatabaseSync } = await import('node:sqlite')
  const db = new DatabaseSync(join(dataDir, 'studio.db'))
  try {
    db.exec("CREATE TABLE canvas_meta (singleton INTEGER PRIMARY KEY, id TEXT NOT NULL); INSERT INTO canvas_meta VALUES(1,'legacy-canvas')")
  } finally {
    db.close()
  }
  for (const stage of [sourceStage, restartStage]) {
    const skill = 'drama-' + stage
    const skillPath = join(process.env.DSH_HOME, 'skills', skill)
    const harnessPath = join(process.env.DSH_HOME, 'drama-studio', 'workflows', 'drama-production', 'stages', stage)
    await mkdir(skillPath, { recursive: true })
    await mkdir(harnessPath, { recursive: true })
    await writeFile(join(skillPath, 'SKILL.md'), `---\nname: ${skill}\ndescription: Verify Workflow interruptions.\n---\nSave a draft.\n`)
    await writeFile(join(harnessPath, 'harness.md'), 'Keep the draft scoped to the current stage.')
  }
  const workspace = await ctx.workspaceRegistry.create(workspacePath)
  const a = (await sessions.create({ workspaceId: workspace.id })).sessionId
  const b = (await sessions.create({ workspaceId: workspace.id })).sessionId
  const otherPath = join(root, 'other-project')
  await mkdir(otherPath, { recursive: true })
  const otherWorkspace = await ctx.workspaceRegistry.create(otherPath)
  const c = (await sessions.create({ workspaceId: otherWorkspace.id })).sessionId
  assert.notEqual(a, b)
  for (const sessionId of [a, b, c]) await sessions.selectModel({ sessionId, provider, model })

  const unauthenticated = await request('init', { sessionId: a }, null)
  assert.ok([401, 403].includes(unauthenticated.status), 'Anonymous Browser reached init')
  const operatorURL = new URL(loginURL)
  operatorURL.pathname = '/connect'
  const operatorCookie = await login(operatorURL, 302)
  assert.ok(operatorCookie, 'DSH did not issue the API operator cookie')
  const operator = ctx.connection.admit({ headers: { host: operatorURL.host, cookie: operatorCookie } })
  assert.equal(operator.peer?.principal.kind, 'owner')
  assert.notEqual(operator.peer.id, ctx.connection.browserPeer.id)
  const operatorInit = await request('init', { sessionId: a }, operatorCookie)
  assert.equal(operatorInit.status, 403, 'A DSH API owner reached the Studio browser route')
  const first = await init(a)
  const second = await init(b)
  assert.equal(first.status.connected, false)
  assert.equal(second.status.autoGenerate, false)
  assert.equal((await succeed(a, 'drama_context', {})).connected, false)
  await reject(a, 'drama_query', {})
  await op(first.ticket, 'bind')
  await op(second.ticket, 'bind')
  await op((await init(c)).ticket, 'bind')
  const aBound = await init(a)
  const bBound = await init(b)
  const cBound = await init(c)
  assert.ok(aBound.status.canvasId)
  assert.equal(aBound.status.canvasId, bBound.status.canvasId)
  assert.notEqual(aBound.status.canvasId, cBound.status.canvasId)

  const forgedSession = await request('operation', {
    ticket: aBound.ticket, action: 'permission', sessionId: b,
    data: { operationId: randomUUID(), enabled: true },
  })
  assert.ok(forgedSession.status >= 400, 'Browser accepted a forged Session')
  const forgedPath = await request('operation', {
    ticket: aBound.ticket, action: 'permission', data: { operationId: randomUUID(), enabled: true, workspacePath: otherPath },
  })
  assert.ok(forgedPath.status >= 400, 'Browser accepted a forged Workspace path')
  const [scope, signature] = aBound.ticket.split('.')
  const changedSignature = (signature[0] === 'a' ? 'b' : 'a') + signature.slice(1)
  const forgedTicket = await request('operation', {
    ticket: `${scope}.${changedSignature}`, action: 'permission', data: { operationId: randomUUID(), enabled: true },
  })
  assert.equal(forgedTicket.status, 403, 'Browser accepted a forged authorization ticket')
  assert.equal((await init(b)).status.autoGenerate, false)
  assert.equal((await init(c)).status.autoGenerate, false)
  await op(bBound.ticket, 'permission', { enabled: true })
  assert.equal((await init(a)).status.autoGenerate, false)
  assert.equal((await init(b)).status.autoGenerate, true)

  const shot = description => ({ operationId: randomUUID(), nodes: [{ type: 'shot', content: { description } }] })
  await succeed(a, 'drama_append', shot('Native fixture A'))
  await succeed(b, 'drama_append', shot('Native fixture B'))
  const query = await succeed(a, 'drama_query', { type: 'shot' })
  assert.deepEqual(new Set(query.nodes.map(node => node.createdBySession)), new Set([a, b]))
  assert.ok(!offered.some(name => /^drama_(?:update|delete)/.test(name)), 'A native Agent was offered human mutation tools')
  for (const name of ['drama_update_node', 'drama_delete_node', 'drama_update_edge', 'drama_delete_edge']) {
    const result = await ctx.tools.execute({
      agent: (await sessions.resolveAgent(a)).agent, callId: randomUUID(), name,
      arguments: { id: query.nodes[0].id, revision: query.nodes[0].revision }, signal,
    })
    assert.equal(result.isError, true, `Unregistered human operation resolved through tools: ${name}`)
  }
  await reject(a, 'drama_append', {
    operationId: randomUUID(), nodes: [{ id: query.nodes[0].id, type: 'shot', content: { description: 'Attempted overwrite' } }],
  }, /节点 ID 已存在/u)
  await reject(a, 'drama_append', { ...shot('forged Session'), sessionId: b })
  await reject(a, 'drama_append', { ...shot('forged Canvas'), canvasId: cBound.status.canvasId })
  await reject(a, 'drama_append', { ...shot('forged Workspace'), workspacePath: otherPath })
  assert.equal((await succeed(b, 'drama_query', { type: 'shot' })).nodes.length, 2)
  assert.equal((await succeed(c, 'drama_query', { type: 'shot' })).nodes.length, 0)
  assert.equal((await succeed(b, 'drama_tasks', {})).tasks.length, 0)

  await succeed(b, 'drama_append', {
    operationId: randomUUID(), nodes: [{ type: 'video', content: { prompt: 'Locked wide shot of a quiet room. The actor enters from camera left and stops beside the window. Soft room tone, no music. Hold before the entrance and after the stop.' } }],
  })
  const video = (await succeed(a, 'drama_query', { type: 'video' })).nodes[0]
  assert.ok(video?.id)
  const submit = () => ({ operationId: randomUUID(), nodeId: video.id })
  await reject(a, 'drama_submit', submit(), /automatic generation is disabled/i)
  await reject(b, 'drama_submit', submit(), /no verified generation provider is configured/i)
  await op(bBound.ticket, 'permission', { enabled: false })
  await reject(b, 'drama_submit', submit(), /automatic generation is disabled/i)
  await op(bBound.ticket, 'disconnect')
  assert.equal((await init(b)).status.connected, false)
  await reject(b, 'drama_query', {})
  assert.equal((await succeed(a, 'drama_query', { type: 'shot' })).nodes.length, 2)

  const reconnect = await init(b)
  await op(reconnect.ticket, 'bind')
  const rebound = await init(b)
  assert.equal(rebound.status.autoGenerate, false)
  await op(rebound.ticket, 'permission', { enabled: true })
  assert.equal((await init(b)).status.aiRunning, false, 'Generation permission was mistaken for live AI activity')

  const noteId = randomUUID()
  const unrelatedId = randomUUID()
  const linkId = randomUUID()
  const archivedId = randomUUID()
  const otherId = randomUUID()
  const otherSource = randomUUID()
  const note = (id, description) => ({ id, type: 'note', content: { description } })
  const oldEdge = { source: unrelatedId, target: linkId }
  await op(rebound.ticket, 'append', { nodes: [note(noteId, 'Original manual note'),
    note(unrelatedId, 'Unread note'), note(linkId, 'Unread connected note'), note(archivedId, 'Archived note')], edges: [oldEdge] })
  await op(cBound.ticket, 'append', { nodes: [note(otherId, 'Isolated Workspace note'), note(otherSource, 'Independent source')],
    edges: [{ source: otherSource, target: otherId }] })
  const archived = await op(rebound.ticket, 'canvas_delete', { nodes: [{ id: archivedId, revision: 1 }] })
  const edit = (id, revision, description) => ({ id, revision, content: { description } })
  const change = (ticket, action, data) => request('operation', { ticket, action, data: { operationId: randomUUID(), ...data } })
  const read = async (ticket, data = {}) => ok(await request('operation', { ticket, action: 'query', data }), 'query')
  async function locked(ticket, action, data) {
    const response = await change(ticket, action, data)
    const body = await response.json()
    assert.equal(response.status, 423, JSON.stringify(body))
    assert.equal(typeof body.error, 'string')
  }
  await op(rebound.ticket, 'update_node', edit(noteId, 1, 'Manual edit while idle'))
  const turnA = await holdTurn(a, { nodeId: noteId })
  assert.equal((await init(b)).status.aiRunning, true)
  assert.equal((await init(c)).status.aiRunning, false)
  const beforeBlocked = await read(rebound.ticket)
  await locked(rebound.ticket, 'update_node', edit(noteId, 2, 'Blocked from Session B'))
  await locked(rebound.ticket, 'update_node', edit(unrelatedId, 1, 'Blocked even if no Agent used the node'))
  await locked(rebound.ticket, 'delete_node', { id: unrelatedId, revision: 1 })
  await locked(rebound.ticket, 'update_edge', { ...oldEdge, newSource: noteId, revision: 1 })
  await locked(rebound.ticket, 'delete_edge', { ...oldEdge, revision: 1 })
  await locked(rebound.ticket, 'canvas_delete', { nodes: [{ id: linkId, revision: 1 }] })
  await locked(rebound.ticket, 'canvas_restore', { nodes: archived.nodes, edges: archived.edges })
  const unchanged = await read(rebound.ticket)
  assert.equal(unchanged.status.eventSeq, beforeBlocked.status.eventSeq, 'A denied write published a canvas event')
  assert.ok(unchanged.edges.some(edge => edge.source === oldEdge.source && edge.target === oldEdge.target))
  assert.equal(unchanged.nodes.find(node => node.id === unrelatedId).content.description, 'Unread note')
  assert.equal((await read(rebound.ticket, { id: archivedId })).nodes[0].deleted, true)
  const duringId = randomUUID()
  await op(rebound.ticket, 'append', { nodes: [note(duringId, 'Manual append while AI is active')] })
  await op(rebound.ticket, 'append', { edges: [{ source: duringId, target: linkId }] })
  assert.ok((await read(rebound.ticket, { id: linkId })).edges.some(edge => edge.source === duringId))
  await op(cBound.ticket, 'update_node', edit(otherId, 1, 'Other Workspace still editable'))
  await op(cBound.ticket, 'delete_edge', { source: otherSource, target: otherId, revision: 2 })
  await op(cBound.ticket, 'delete_node', { id: otherId, revision: 3 })
  const otherNew = randomUUID()
  await op(cBound.ticket, 'append', { nodes: [note(otherNew, 'Other Workspace still accepts new nodes')],
    edges: [{ source: otherSource, target: otherNew }] })
  assert.equal((await read(cBound.ticket, { id: otherNew })).nodes[0].id, otherNew)
  const agentAppend = await ctx.tools.execute({ agent: turnA.agent, callId: randomUUID(), name: 'drama_append',
    arguments: { operationId: randomUUID(), edges: [{ source: noteId, target: unrelatedId }] }, signal })
  assert.equal(agentAppend.isError, false, JSON.stringify(agentAppend.content))
  assert.ok((await read(rebound.ticket, { id: unrelatedId })).edges.some(edge => edge.source === noteId))
  await locked(rebound.ticket, 'update_node', edit(duringId, 1, 'Already-created nodes cannot be edited'))
  const turnB = await holdTurn(b, { nodeId: duringId })
  turnA.finish()
  assert.equal((await turnA.ending()).kind, 'completed')
  assert.equal(turnB.agent.status, 'running')
  await locked(aBound.ticket, 'delete_node', { id: duringId, revision: 1 })
  assert.equal(sessions.cancel({ sessionId: b }).accepted, true)
  assert.deepEqual(await turnB.ending(), { kind: 'aborted', reason: { kind: 'user' } })
  assert.equal((await init(a)).status.aiRunning, false)
  await op(rebound.ticket, 'update_node', edit(duringId, 1, 'Independent edit after the last Agent stops'))
  await op(aBound.ticket, 'delete_node', { id: duringId, revision: 2 })
  await op(rebound.ticket, 'canvas_restore', { nodes: archived.nodes, edges: archived.edges })

  const binding = await holdTurn(a)
  await op(aBound.ticket, 'disconnect')
  assert.equal((await init(b)).status.aiRunning, false, 'An unbound Agent held the Workspace lock')
  await op(rebound.ticket, 'update_node', edit(archivedId, 3, 'Editable while the active Agent is unbound'))
  await op(aBound.ticket, 'bind')
  assert.equal((await init(b)).status.aiRunning, true, 'A newly connected active Agent was ignored')
  binding.finish()
  assert.equal((await binding.ending()).kind, 'completed')
  assert.equal((await init(b)).status.aiRunning, false)
  await op(rebound.ticket, 'update_node', edit(archivedId, 4, 'Editable after the last Agent completes normally'))

  const failed = await holdTurn(a, { fail: true, nodeId: noteId })
  await locked(rebound.ticket, 'update_node', edit(noteId, 2, 'Still blocked before failure'))
  failed.finish()
  assert.equal((await failed.ending()).kind, 'error')
  assert.equal((await init(b)).status.aiRunning, false)
  await op(rebound.ticket, 'update_node', edit(noteId, 2, 'Editable after failed turn'))

  const disposableId = randomUUID()
  const handle = await ctx.agents.create({
    sessionId: disposableId, meta: { cwd: workspace.path }, agentOptions: { provider, model },
  })
  try {
    await workspace.attachSession(disposableId)
    await op((await init(disposableId)).ticket, 'bind')
    await holdTurn(disposableId, { owner: handle.agent })
    const read = await ctx.tools.execute({
      agent: handle.agent, callId: randomUUID(), name: 'drama_query', arguments: { id: noteId }, signal,
    })
    assert.equal(read.isError, false, JSON.stringify(read.content))
    assert.equal((await init(b)).status.aiRunning, true)
    await locked(rebound.ticket, 'delete_node', { id: noteId, revision: 3 })
  } finally {
    await handle.dispose()
  }
  assert.equal(ctx.agents.get(disposableId), undefined)
  assert.equal((await init(b)).status.aiRunning, false)
  await op(rebound.ticket, 'update_node', edit(noteId, 3, 'Editable after Agent disposal'))

  await op(cBound.ticket, 'workflow_profile_select', { workflowProfileId: 'short-video' })
  await op(cBound.ticket, 'workflow_activate', { stageId: topicStage })
  const topic = await succeed(c, 'drama_save_artifact', {
    operationId: randomUUID(), title: 'Topic plan', content: 'Short Video fixture: pinned topic plan',
  })
  const brief = await succeed(c, 'drama_save_artifact', {
    operationId: randomUUID(), title: 'Topic handoff document',
    content: `# Handoff\nContinue from Topic plan ${topic.artifactId} v${topic.version}.`,
  })
  await until(async () => (await readWorkflow(cBound.ticket)).session.status === 'active', signal, 'topic draft settled')
  const topicPreview = await op(cBound.ticket, 'workflow_handoff_preview', { stageId: topicStage })
  assert.equal(topicPreview.targetStageId, sourceStage)
  assert.equal(topicPreview.artifacts.find(item => item.artifactId === brief.artifactId)?.version, brief.version)
  const nativeController = sessions[Symbol.for('cordis.original')] ?? sessions
  const nativePrompt = nativeController.prompt
  let kickoffAttempts = 0
  nativeController.prompt = function (input, abort) {
    // Only the first automatic dispatch for this freshly committed handoff is rejected.
    if (input.sessionId === c && input.requestId.startsWith(kickoffPrefix + topicPreview.handoffId + ':')) {
      kickoffAttempts++
      return Promise.reject(new RemoteError('session/agent-busy', 'Fixture refused prompt admission', { reason: 'fixture' }))
    }
    return nativePrompt.call(this, input, abort)
  }
  let pending
  try {
    const confirmArgs = { operationId: randomUUID(), handoffId: topicPreview.handoffId }
    const result = await op(cBound.ticket, 'workflow_handoff_confirm', confirmArgs)
    assert.equal(result.handoff.handoffId, topicPreview.handoffId)
    assert.ok(result.handoff.confirmedAt)
    assert.equal(result.session.pendingHandoffId, topicPreview.handoffId)
    assert.equal(result.session.activeStageId, sourceStage)
    assert.equal(result.session.status, 'failed')
    assert.match(result.session.error, /DSH 拒绝接收交接任务/u)
    for (const operationId of [confirmArgs.operationId, randomUUID()]) {
      const replay = await op(cBound.ticket, 'workflow_handoff_confirm', { ...confirmArgs, operationId })
      assert.deepEqual(replay.handoff, result.handoff)
      assert.equal(replay.session.activation, result.session.activation)
      assert.equal(replay.session.pendingHandoffId, topicPreview.handoffId)
    }
    assert.equal(kickoffAttempts, 1, 'Receipt replay resubmitted the pending native request')
    const current = await readWorkflow(cBound.ticket)
    assert.equal(current.handoffs.length, 1)
    assert.equal(current.handoffs[0].handoffId, topicPreview.handoffId)
    assert.equal(current.session.runId ?? '', '')
    assert.equal(current.stages[0].status, 'handed_off')
    pending = {
      sessionId: c, handoffId: topicPreview.handoffId, activation: result.session.activation,
      artifact: { artifactId: topic.artifactId, version: topic.version },
    }
    console.info(`[drama-agent-fixture] EVIDENCE Short Video pre-admission failure kept one confirmed receipt and pending ${pending.handoffId} at activation ${pending.activation}; both receipt replays kept native dispatch count ${kickoffAttempts}`)
  } finally {
    nativeController.prompt = nativePrompt
  }

  const saved = await readWorkflow(aBound.ticket)
  assert.equal(saved.session.status, 'normal')
  await op(aBound.ticket, 'workflow_activate', { stageId: sourceStage })
  await op(aBound.ticket, 'permission', { enabled: true })
  const artifact = await succeed(a, 'drama_save_artifact', {
    operationId: randomUUID(), title: 'Restart analysis', content: 'Restart fixture: pinned analysis',
  })
  await until(async () => (await readWorkflow(aBound.ticket)).session.status === 'active', signal, 'source turn settled')
  const preview = await op(aBound.ticket, 'workflow_handoff_preview', { stageId: sourceStage })
  const hold = { entered: false, release: new EventTarget() }
  script.push({ hold })
  await op(aBound.ticket, 'workflow_handoff_confirm', { handoffId: preview.handoffId })
  await until(() => hold.entered, signal, 'running native Workflow turn')
  const running = await readWorkflow(aBound.ticket)
  assert.equal(running.session.status, 'running')
  assert.equal(running.session.activeStageId, restartStage)
  assert.equal(running.stages[0].status, 'handed_off')
  assert.equal((await readWorkflow(rebound.ticket)).session.status, 'normal')
  const workflowAgent = ctx.agents.get(a)
  const workflowTool = (name, args) => ctx.tools.execute({ agent: workflowAgent, callId: randomUUID(), name,
    arguments: { operationId: randomUUID(), ...args }, signal })
  const oldTarget = await workflowTool('drama_append', { edges: [{ source: noteId, target: linkId }] })
  assert.equal(oldTarget.isError, true)
  assert.match(oldTarget.content[0].text, /阶段.*连线/u)
  const workflowSubmit = await workflowTool('drama_submit', { nodeId: video.id })
  assert.equal(workflowSubmit.isError, true)
  assert.match(workflowSubmit.content[0].text, /阶段.*生成/u)
  for (const action of ['approve', 'handoff', 'activate']) {
    assert.equal(ctx.tools.get('drama_workflow_' + action, workflowAgent), undefined)
  }
  await locked(rebound.ticket, 'delete_node', { id: noteId, revision: 4 })
  await writeFile(statePath, JSON.stringify({
    sessionId: b, canvasId: rebound.status.canvasId, ticket: rebound.ticket, videoId: video.id, noteId,
    workflowId: saved.id, executorSessionId: a, handoffId: preview.handoffId, artifactId: artifact.artifactId, pending,
  }))
  console.info(`[drama-agent-fixture] PASS native Agent: canvas-wide locks, append while active, overlapping turns, other Workspace isolation, cancel/error/dispose unlock, Agent update/delete rejected, Workflow submit rejected, confirmed handoff and held target turn at restart (${nativeCalls} native tool calls)`)
}

async function until(check, signal, label, timeout = 15_000) {
  const deadline = Date.now() + timeout
  while (Date.now() < deadline) {
    signal.throwIfAborted()
    const value = await check()
    if (value) return value
    await delay(100, undefined, { signal })
  }
  throw new Error(`Timed out: ${label}`)
}

async function runFixture() {
  assert.equal(process.platform, 'win32', 'Requires Windows x64 and the native DSH runtime')
  const file = fileURLToPath(import.meta.url)
  const repo = resolve(dirname(file), '..')
  const build = join(repo, 'dist')
  const sourceHost = join(build, 'host.js')
  const sourceKernel = process.env.DRAMA_UIUX_STUDIO_EXE ?? join(build, 'studio.exe')
  await access(sourceHost)
  await access(sourceKernel)
  const installation = join(process.env.LOCALAPPDATA, 'Programs', 'DeepSeek Harness')
  const npmCLI = process.env.DRAMA_DSH_CLI ? resolve(process.env.DRAMA_DSH_CLI) : undefined
  const executable = npmCLI ? process.execPath : join(installation, 'DeepSeek Harness.exe')
  const cli = npmCLI ? [npmCLI] : ['--expose-internals',
    join(installation, 'resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-desktop-host/lib/cli.js')]
  await access(executable)
  if (npmCLI) await access(npmCLI)
  const scratch = resolve(tmpdir())
  const root = await mkdtemp(join(scratch, 'drama-native-agent-'))
  if (npmCLI) {
    const schema = createRequire(npmCLI).resolve('@deepseek-ai/schemastery/package.json')
    await symlink(dirname(dirname(dirname(schema))), join(root, 'node_modules'), 'junction')
  }
  const output = join(root, 'dist')
  await mkdir(output)
  const host = join(output, 'host.js')
  await copyFile(sourceHost, host)
  await copyFile(join(build, 'client.js'), join(output, 'client.js'))
  await copyFile(sourceKernel, join(output, 'studio.exe'))
  await cp(join(repo, 'resources'), join(root, 'resources'), { recursive: true })
  const overlay = join(root, 'fixture.yml')
  const fixture = join(root, 'agent-fixture.mjs')
  await copyFile(file, fixture)
  await copyFile(join(repo, 'package.json'), join(root, 'package.json'))
  const yaml = path => JSON.stringify(path.replaceAll('\\', '/'))
  await writeFile(overlay, `- insert:\n    - id: my-drama-studio\n      name: ${yaml(host)}\n    - id: ${name}\n      name: ${yaml(fixture)}\n`)

  async function launch(expected) {
    const child = spawn(executable, [...cli, 'web', '--patch', overlay,
      '--host', '127.0.0.1', '--port', '0', '--no-open'], {
      windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'],
      env: {
        ...process.env, ...(npmCLI ? { DRAMA_DSH_CLI: npmCLI } : { ELECTRON_RUN_AS_NODE: '1' }), DSH_HOME: join(root, 'home'),
        DSH_AGENTS_HOME: join(root, 'agents'), DSH_TELEMETRY_DISABLED: '1', DSH_TOOLS_MODE: 'native', DEEPSEEK_API_KEY: '',
      },
    })
    const exited = once(child, 'exit')
    const waiting = new AbortController()
    let logs = ''
    const capture = chunk => { logs += chunk.toString() }
    child.stdout.on('data', capture)
    child.stderr.on('data', capture)
    try {
      await Promise.race([
        exited,
        until(() => logs.includes(expected) || logs.includes(`[${name}] FAIL`),
          waiting.signal, expected, 45_000),
      ])
      assert.ok(logs.includes(expected), `The fixture did not reach ${expected}`)
      for (const line of logs.split(/\r?\n/)) {
        if (line.includes(expected) || line.startsWith(`[${name}] EVIDENCE `)) console.info(line)
      }
    } catch (error) {
      console.error(logs.replace(/(https?:\/\/[^\s?'"<>]+)\?[^\s'"<>]+/g, '$1?[redacted]'))
      throw error
    } finally {
      waiting.abort()
      if (child.pid && child.exitCode === null) child.kill()
      await exited
    }
  }

  try {
    await launch(`[${name}] PASS native Agent`)
    await launch(`[${name}] PASS restart`)
  } finally {
    assert.equal(dirname(root), scratch)
    assert.ok(basename(root).startsWith('drama-native-agent-'))
    await rm(root, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 })
  }
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  await runFixture()
}
