package studio

import (
	"bytes"
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/json"
	"errors"
	"net/http"
	"net/netip"
	"net/url"
	"slices"
	"strings"
	"time"

	"github.com/google/uuid"
)

var automaticDisabled = &requestError{http.StatusForbidden, "Automatic generation is disabled"}
var providerUnavailable = &requestError{http.StatusServiceUnavailable, "No verified generation provider is configured"}

type mutationResult struct {
	EventSeq int64 `json:"eventSeq"`
}

func (p *project) permission(ctx context.Context, r Request) (any, error) {
	var args struct {
		operation
		Enabled *bool `json:"enabled"`
	}
	if err := decodeData(r.Data, &args); err != nil {
		return nil, err
	}
	if args.Enabled == nil {
		return nil, invalid("需要明确选择是否启用自动生成")
	}
	return p.write(ctx, r, args.ID, func(tx *sql.Tx, status Status) (any, error) {
		if status.AutoGenerate == *args.Enabled {
			return mutationResult{EventSeq: status.EventSeq}, nil
		}
		seq, err := setAutomaticPermission(ctx, tx, r.SessionID, *args.Enabled)
		return mutationResult{EventSeq: seq}, err
	})
}

type submitArgs struct {
	operation
	NodeID           string `json:"nodeId"`
	ProfileID        string `json:"profileId,omitempty"`
	ExpectedRevision *int64 `json:"expectedRevision,omitempty"`
}

func (p *project) submit(ctx context.Context, r Request, providers providerRegistry, expectedMode string) (any, error) {
	var args submitArgs
	var providerVersion string
	if r.Action != "submit" {
		var manual struct {
			submitArgs
			Confirmed       bool   `json:"confirmed"`
			ProviderVersion string `json:"providerVersion,omitempty"`
		}
		if err := decodeData(r.Data, &manual); err != nil {
			return nil, err
		}
		if !manual.Confirmed {
			return nil, invalid("手动生成需要明确确认")
		}
		args = manual.submitArgs
		providerVersion = manual.ProviderVersion
	} else if err := decodeData(r.Data, &args); err != nil {
		return nil, err
	}
	if err := args.operation.validate(); err != nil {
		return nil, err
	}

	settings, _ := providers.(*ProviderSettings)
	plan := func(tx *sql.Tx, status Status) (generationRequest, [sha256.Size]byte, error) {
		request, err := p.planSubmission(ctx, tx, status, r, args, providers, expectedMode, providerVersion)
		var credential [sha256.Size]byte
		if err == nil && settings != nil {
			credential = sha256.Sum256([]byte(settings.data.Keys[request.Profile.ChannelID]))
		}
		return request, credential, err
	}
	var request generationRequest
	var credential [sha256.Size]byte
	var baseline []byte
	old, err := func() (json.RawMessage, error) {
		if settings != nil {
			settings.mu.RLock()
			defer settings.mu.RUnlock()
		}
		tx, err := p.db.BeginTx(ctx, &sql.TxOptions{ReadOnly: true})
		if err != nil {
			return nil, err
		}
		defer tx.Rollback()
		status, err := getStatus(ctx, tx, r)
		if err != nil {
			return nil, err
		}
		if !status.Connected {
			return nil, notBound
		}
		if old, err := readOperation(ctx, tx, r, args.ID); err != nil || old != nil {
			return old, err
		}
		request, credential, err = plan(tx, status)
		if err == nil {
			baseline, err = json.Marshal(request)
		}
		return nil, err
	}()
	if err != nil || old != nil {
		return old, err
	}
	if request.Type == "video" {
		if err := p.prepareVideoMedia(ctx, args.NodeID, &request.GenerationInput); err != nil {
			return nil, err
		}
	}
	encoded, err := json.Marshal(request)
	if err != nil {
		return nil, err
	}

	// The settings lock covers only validation and commit. Media preflight and
	// hashing above leave both the database and settings available.
	if settings != nil {
		settings.mu.RLock()
		defer settings.mu.RUnlock()
	}
	return p.write(ctx, r, args.ID, func(tx *sql.Tx, status Status) (any, error) {
		current, currentCredential, err := plan(tx, status)
		if err != nil {
			var failure *requestError
			if errors.As(err, &failure) && (failure.code == http.StatusBadRequest || failure.code == http.StatusServiceUnavailable) {
				return nil, generationInputChanged
			}
			return nil, err
		}
		currentPlan, err := json.Marshal(current)
		if err != nil {
			return nil, err
		}
		if !bytes.Equal(baseline, currentPlan) || currentCredential != credential {
			return nil, generationInputChanged
		}
		now := time.Now().UTC().Format(time.RFC3339Nano)
		task := Task{ID: uuid.NewString(), NodeID: args.NodeID, CreatedBySession: r.SessionID, Type: request.Type,
			Status: "pending", CreatedAt: now, UpdatedAt: now,
			Mode: request.Mode, Provider: request.Profile.Provider, Model: request.Profile.Model, ChannelID: request.Profile.ChannelID}
		_, err = tx.ExecContext(ctx, `INSERT INTO tasks(id,node_id,session_id,type,status,input,created_at,updated_at)
  VALUES(?,?,?,?,?,?,?,?)`, task.ID, task.NodeID, task.CreatedBySession, task.Type, task.Status, string(encoded), now, now)
		if err != nil {
			return nil, err
		}
		seq, err := addEvent(ctx, tx, "task", []string{task.ID})
		return struct {
			Task     Task  `json:"task"`
			EventSeq int64 `json:"eventSeq"`
		}{task, seq}, err
	})
}

var generationInputChanged = &requestError{http.StatusConflict, "生成节点、素材连线或所用渠道已经变化，请核对当前输入后重新提交"}

func (p *project) planSubmission(ctx context.Context, tx *sql.Tx, status Status, r Request, args submitArgs,
	providers providerRegistry, expectedMode, providerVersion string) (generationRequest, error) {
	if r.Action == "submit" {
		if !status.AutoGenerate {
			return generationRequest{}, automaticDisabled
		}
		var stageRunning bool
		if err := tx.QueryRowContext(ctx, `SELECT EXISTS(SELECT 1 FROM workflow_turns WHERE session_id=? AND status='running')`,
			r.SessionID).Scan(&stageRunning); err != nil {
			return generationRequest{}, err
		}
		if stageRunning {
			return generationRequest{}, &requestError{http.StatusForbidden, "工作流阶段需要在 Canvas 手动授权生成"}
		}
	}
	kind, snapshot, revision, err := submissionNode(ctx, tx, args.NodeID)
	if err != nil {
		return generationRequest{}, err
	}
	if args.ExpectedRevision != nil && *args.ExpectedRevision != revision {
		return generationRequest{}, revisionConflict
	}
	if kind == "video" && r.Action == "submit" {
		if err := checkAutomaticVideoDraft(ctx, tx, snapshot, workflowRef{ID: args.NodeID, Revision: revision}); err != nil {
			return generationRequest{}, err
		}
	}
	input, pinned, sourceIDs, err := generationInput(ctx, tx, p.dir, args.NodeID, kind, snapshot)
	if err != nil {
		return generationRequest{}, err
	}
	if expectedMode != "" && (input.Type != "video" || input.Mode != expectedMode) {
		return generationRequest{}, invalid("当前视频节点的生成方式与请求不匹配")
	}
	if providers == nil {
		return generationRequest{}, providerUnavailable
	}
	id := args.ProfileID
	if id == "" {
		id = pinned
	}
	input.providerVersion = providerVersion
	prepare := providers.Prepare
	if settings, ok := providers.(*ProviderSettings); ok {
		prepare = settings.prepareLocked
	}
	if err := prepare(&input, id); err != nil {
		return generationRequest{}, err
	}
	group, err := readSourceGroup(ctx, tx, args.NodeID)
	if err != nil {
		return generationRequest{}, err
	}
	request := generationRequest{GenerationInput: input, SourceGroup: &group, SourceNodeIDs: sourceIDs,
		SourceNodeRevision: revision, ManualConfirmation: r.Action != "submit"}
	if kind == "video" {
		request.VideoInputContract = videoInputContractVersion
	}
	return request, nil
}

func submissionNode(ctx context.Context, tx *sql.Tx, id string) (kind, snapshot string, revision int64, err error) {
	err = tx.QueryRowContext(ctx, "SELECT type,content,revision FROM nodes WHERE id=? AND deleted=0", id).Scan(&kind, &snapshot, &revision)
	if errors.Is(err, sql.ErrNoRows) {
		return "", "", 0, invalid("待生成节点不存在于当前 Canvas")
	}
	if err != nil {
		return "", "", 0, err
	}
	var content struct {
		Mode   *string `json:"mode"`
		Path   string  `json:"path"`
		URL    string  `json:"url"`
		Prompt string  `json:"prompt"`
	}
	if (kind != "image" && kind != "video") || json.Unmarshal([]byte(snapshot), &content) != nil {
		return "", "", 0, invalid("请选择图片或视频生成节点")
	}
	if kind == "video" {
		if content.Mode != nil && *content.Mode == "" {
			return "", "", 0, invalid("请先选择视频生成方式")
		}
		if content.Mode != nil && *content.Mode == "asset" ||
			content.Mode == nil && (content.Path != "" || content.URL != "") {
			return "", "", 0, invalid("请选择视频生成草稿")
		}
		if strings.TrimSpace(content.Prompt) == "" {
			return "", "", 0, invalid("请先填写视频节点的完整提示词")
		}
	}
	return kind, snapshot, revision, nil
}

func (p *project) tasks(ctx context.Context, r Request) (any, error) {
	if err := decodeData(r.Data, &struct{}{}); err != nil {
		return nil, err
	}
	tx, err := p.db.BeginTx(ctx, &sql.TxOptions{ReadOnly: true})
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	status, err := getStatus(ctx, tx, r)
	if err != nil {
		return nil, err
	}
	if !status.Connected {
		return nil, notBound
	}
	rows, err := tx.QueryContext(ctx, "SELECT "+taskColumns+" FROM tasks ORDER BY rowid DESC LIMIT 100")
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	tasks := make([]Task, 0)
	for rows.Next() {
		task, _, err := scanTask(rows)
		if err != nil {
			return nil, err
		}
		tasks = append(tasks, task)
	}
	return map[string][]Task{"tasks": tasks}, rows.Err()
}

type Task struct {
	ID               string `json:"id"`
	NodeID           string `json:"nodeId"`
	CreatedBySession string `json:"createdBySession"`
	Type             string `json:"type"`
	Status           string `json:"status"`
	ProviderTaskID   string `json:"providerTaskId,omitempty"`
	ResultNodeID     string `json:"resultNodeId,omitempty"`
	Error            string `json:"error,omitempty"`
	CreatedAt        string `json:"createdAt"`
	UpdatedAt        string `json:"updatedAt"`
	CompletedAt      string `json:"completedAt,omitempty"`
	OutputPath       string `json:"outputPath,omitempty"`
	Mode             string `json:"mode,omitempty"`
	Provider         string `json:"provider,omitempty"`
	Model            string `json:"model,omitempty"`
	ChannelID        string `json:"channelId,omitempty"`
	outputDirectory  string
}

func (task Task) MarshalJSON() ([]byte, error) {
	status, phase := task.Status, ""
	switch task.Status {
	case "pending":
		status = "queued"
	case "submitting", "polling", "paused":
		status, phase = "processing", task.Status
	case "succeeded":
		status = "completed"
	case "uncertain":
		status, phase = "failed", "submission_unknown"
	}
	type fields Task
	return json.Marshal(struct {
		fields
		Status string `json:"status"`
		Phase  string `json:"phase,omitempty"`
	}{fields(task), status, phase})
}

const taskColumns = "id,node_id,session_id,type,status,provider_id,result_node_id,error,created_at,updated_at,completed_at,output_path,input"

func scanTask(row interface{ Scan(...any) error }) (Task, string, error) {
	var task Task
	var input string
	err := row.Scan(&task.ID, &task.NodeID, &task.CreatedBySession, &task.Type, &task.Status,
		&task.ProviderTaskID, &task.ResultNodeID, &task.Error, &task.CreatedAt, &task.UpdatedAt, &task.CompletedAt, &task.OutputPath, &input)
	if err == nil {
		var request GenerationInput
		if json.Unmarshal([]byte(input), &request) == nil {
			task.Mode, task.Provider, task.Model = request.Mode, request.Profile.Provider, request.Profile.Model
			task.ChannelID = request.Profile.ChannelID
		}
	}
	return task, input, err
}

func migrateTaskFields(ctx context.Context, tx *sql.Tx) error {
	rows, err := tx.QueryContext(ctx, "SELECT name FROM pragma_table_info('tasks')")
	if err != nil {
		return err
	}
	columns := make(map[string]bool)
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			rows.Close()
			return err
		}
		columns[name] = true
	}
	if err := errors.Join(rows.Err(), rows.Close()); err != nil {
		return err
	}
	if !columns["completed_at"] {
		if _, err := tx.ExecContext(ctx, `ALTER TABLE tasks ADD COLUMN completed_at TEXT NOT NULL DEFAULT '';
			UPDATE tasks SET completed_at=updated_at WHERE status IN ('succeeded','failed','cancelled','uncertain')`); err != nil {
			return err
		}
	}
	if !columns["output_path"] {
		if _, err := tx.ExecContext(ctx, `ALTER TABLE tasks ADD COLUMN output_path TEXT NOT NULL DEFAULT '';
			UPDATE tasks SET output_path=COALESCE((SELECT json_extract(content,'$.path') FROM nodes WHERE id=tasks.result_node_id),'')
			WHERE result_node_id<>''`); err != nil {
			return err
		}
	}
	return nil
}

func (p *project) controlTask(ctx context.Context, r Request) (any, error) {
	var args struct {
		operation
		TaskID string `json:"taskId"`
	}
	if err := decodeData(r.Data, &args); err != nil {
		return nil, err
	}
	return p.write(ctx, r, args.ID, func(tx *sql.Tx, _ Status) (any, error) {
		task, _, err := scanTask(tx.QueryRowContext(ctx, "SELECT "+taskColumns+" FROM tasks WHERE id=?", args.TaskID))
		if errors.Is(err, sql.ErrNoRows) {
			return nil, invalid("任务不存在")
		}
		if err != nil {
			return nil, err
		}
		next := "cancelled"
		if r.Action == "resume_task" {
			if task.Status != "paused" || task.ProviderTaskID == "" {
				return nil, invalid("只有已暂停且有上游 ID 的任务可以继续查询")
			}
			next = "polling"
		} else if task.Status != "pending" {
			return nil, invalid("只有尚未提交的任务可以从队列取消")
		}
		if err := updateTask(ctx, tx, task, next, task.ProviderTaskID, "", "", ""); err != nil {
			return nil, err
		}
		seq, err := addEvent(ctx, tx, "task", []string{task.ID})
		return mutationResult{EventSeq: seq}, err
	})
}

func generationInput(ctx context.Context, tx *sql.Tx, workspace, id, kind, snapshot string) (GenerationInput, string, []string, error) {
	if kind == "video" {
		return videoGenerationInput(ctx, tx, workspace, id, snapshot)
	}
	var content struct {
		Prompt    string          `json:"prompt"`
		PromptDoc json.RawMessage `json:"promptDoc"`
		Order     []string        `json:"mixedListOrder"`
		Mode      string          `json:"mode"`
		ProfileID string          `json:"profileId"`
		Params    json.RawMessage `json:"params"`
	}
	if err := json.Unmarshal([]byte(snapshot), &content); err != nil {
		return GenerationInput{}, "", nil, invalid("生成节点格式无效")
	}
	input := GenerationInput{Type: kind, Prompt: content.Prompt, Mode: content.Mode, WorkspacePath: workspace}
	params, err := decodeVideoParams(content.Params)
	if err != nil {
		return GenerationInput{}, "", nil, err
	}
	input.Params = params
	content.Order, err = imageReferenceOrder(ctx, tx, id, content.Order)
	if err != nil {
		return GenerationInput{}, "", nil, err
	}
	sourceIDs := []string{}
	var text []string
	for _, reference := range content.Order {
		var source Node
		var raw string
		err := tx.QueryRowContext(ctx, `SELECT nodes.type,nodes.content FROM nodes JOIN edges ON edges.source=nodes.id
			WHERE edges.target=? AND nodes.id=? AND nodes.deleted=0`, id, reference).Scan(&source.Type, &raw)
		if errors.Is(err, sql.ErrNoRows) {
			continue // Legacy archived image links do not participate in current generation.
		}
		if err != nil {
			return GenerationInput{}, "", nil, err
		}
		source.ID, source.Content = reference, json.RawMessage(raw)
		sourceIDs = append(sourceIDs, reference)
		if isTextNode(source.Type) {
			if context := nodeText(source.Content); context != "" {
				text = append(text, context)
			}
			continue
		}
		if source.Type != "image" {
			return GenerationInput{}, "", nil, invalid("生成节点包含不兼容的参考素材")
		}
		resolved, err := resolveMediaNode(ctx, tx, source)
		if err != nil {
			return GenerationInput{}, "", nil, err
		}
		if resolved.ID == "" {
			return GenerationInput{}, "", nil, invalid("等待上游节点产出素材")
		}
		if resolved.ID != source.ID {
			sourceIDs = append(sourceIDs, resolved.ID)
		}
		ref, err := mediaGenerationReference(resolved.NodeInput)
		if err != nil {
			return GenerationInput{}, "", nil, err
		}
		input.References = append(input.References, ref)
	}
	if doc, err := parsePromptDoc(content.PromptDoc); err != nil {
		return GenerationInput{}, "", nil, err
	} else if doc != nil {
		target := NodeInput{ID: id, Type: kind, Content: json.RawMessage(snapshot)}
		ids, err := compileAssetMentions(ctx, tx, workspace, target, &input, doc)
		if err != nil {
			return GenerationInput{}, "", nil, err
		}
		sourceIDs = append(sourceIDs, ids...)
	}
	if len(text) > 0 {
		prompt := append([]string{strings.TrimSpace(input.Prompt)}, text...)
		input.Prompt = strings.TrimSpace(strings.Join(prompt, "\n\n"))
	}
	if strings.TrimSpace(input.Prompt) == "" {
		return GenerationInput{}, "", nil, invalid("请填写生成提示词")
	}
	if input.Mode != "" && input.Mode != "t2i" {
		return GenerationInput{}, "", nil, invalid("图片生成需要 T2I 预设")
	}
	input.Mode = "t2i"
	return input, content.ProfileID, sourceIDs, nil
}

func mediaGenerationReference(asset NodeInput) (GenerationReference, error) {
	var media struct{ URL, Path string }
	if json.Unmarshal(asset.Content, &media) != nil || (media.Path == "" && !providerURL(media.URL)) {
		return GenerationReference{}, invalid("模型参考素材需要项目内媒体或可访问的外部 HTTP/HTTPS URL")
	}
	ref := GenerationReference{Type: asset.Type, Path: media.Path}
	// Match canvas previews, which prefer the project file when both are set.
	if ref.Path == "" {
		ref.URL = media.URL
	}
	return ref, nil
}

func nodeText(raw json.RawMessage) string {
	var data struct{ Text, Description, Prompt string }
	if json.Unmarshal(raw, &data) != nil {
		return ""
	}
	for _, candidate := range []string{data.Text, data.Description, data.Prompt} {
		if text := strings.TrimSpace(candidate); text != "" {
			return text
		}
	}
	return ""
}

func imageReferenceOrder(ctx context.Context, tx *sql.Tx, target string, order []string) ([]string, error) {
	rows, err := tx.QueryContext(ctx, `SELECT source,type FROM edges JOIN nodes ON source=nodes.id
		WHERE target=? AND deleted=0 ORDER BY edges.rowid`, target)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var connected []string
	for rows.Next() {
		var id, kind string
		if err := rows.Scan(&id, &kind); err != nil {
			return nil, err
		}
		if kind == "image" || isTextNode(kind) {
			connected = append(connected, id)
		}
	}
	var effective []string
	for _, source := range append(slices.Clone(order), connected...) {
		if slices.Contains(connected, source) && !slices.Contains(effective, source) {
			effective = append(effective, source)
		}
	}
	return effective, rows.Err()
}

func taskLockedNodes(ctx context.Context, tx *sql.Tx) ([]string, error) {
	rows, err := tx.QueryContext(ctx, `WITH RECURSIVE active AS (
		SELECT node_id,input FROM tasks WHERE status IN ('pending','submitting','polling','paused')
	), locked(id) AS (
		SELECT node_id FROM active
		UNION SELECT value FROM active,json_each(active.input,'$.sourceNodeIds') WHERE value IS NOT NULL
		UNION SELECT source FROM edges JOIN locked ON target=locked.id
	) SELECT id FROM locked ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	ids := []string{}
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}

func providerURL(value string) bool {
	parsed, err := url.Parse(value)
	if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.User != nil {
		return false
	}
	host := strings.TrimRight(strings.ToLower(parsed.Hostname()), ".")
	if host == "" || host == "localhost" || strings.HasSuffix(host, ".localhost") {
		return false
	}
	if ip, err := netip.ParseAddr(host); err == nil {
		ip = ip.Unmap()
		return ip.IsGlobalUnicast() && !ip.IsPrivate()
	}
	separator := strings.LastIndexByte(host, '.')
	if separator < 1 || strings.HasPrefix(host, "127.") {
		return false
	}
	last := host[separator+1:]
	return !strings.HasPrefix(last, "0x") && strings.IndexFunc(last, func(r rune) bool { return r < '0' || r > '9' }) >= 0
}
