import { existsSync } from 'node:fs'
import { stat, writeFile } from 'node:fs/promises'
import { basename, dirname, join } from 'node:path'
import { resolveConfig, trimItems, ZoteroClient, ZoteroError } from './zotero-client.js'
import { attachmentStoragePath, readFulltextCache, readFulltextFile, resolveStorageDir } from './storage.js'
import { fileUrlToPath, writeAttachment } from './files.js'
import { extractPdfPages } from './pdf.js'
import { queryFromTitle, scorePassages, splitPassages } from './retrieve.js'
import type { PassageInput, ScoredPassage } from './retrieve.js'
import type {
  ResultMode,
  ZoteroAnnotationsResult,
  ZoteroAttachmentPathResult,
  ZoteroBrowseResult,
  ZoteroCollectionsResult,
  ZoteroConfig,
  ZoteroDigestResult,
  ZoteroDownloadResult,
  ZoteroExportResult,
  ZoteroFulltextResult,
  ZoteroItemResult,
  ZoteroNoteAction,
  ZoteroNoteResult,
  ZoteroNotesResult,
  ZoteroPassage,
  ZoteroRecentArgs,
  ZoteroRetrieveResult,
  ZoteroRetrieveSource,
  ZoteroSearchArgs,
  ZoteroSearchResult,
} from './types.js'

export const name = 'tool-zotero'
export const inject = ['tools']
/** schemastery 配置 schema：加载器校验 config 并渲染设置表单（DSH 0.2.0-rc.x 插件规范）。 */
export { Config } from './config.js'

const MAX_LIMIT = 100
const KEY_PATTERN = /^[A-Z0-9]{8}$/i
const SORT_HINT = 'dateAdded | dateModified | date | title | creator'
const MODE_HINT = 'minimal（只留定位字段）| preview（附 400 字摘要，默认）| full（含完整摘要）'

type TextBlock = { type: 'text'; text: string }
function oneText(text: string): TextBlock[] {
  return [{ type: 'text', text }]
}

function messageOf(error: unknown, fallback: string): string {
  return error instanceof Error ? error.message : fallback
}

function clampInt(value: unknown, fallback: number, min: number, max: number): number {
  const n = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(max, Math.max(min, Math.round(n)))
}

function requireKey(value: string | undefined, label: string): string {
  const key = (value ?? '').trim()
  if (!KEY_PATTERN.test(key)) throw new Error(`${label} 必须是 Zotero 的 8 位 key（用 zotero_search / zotero_notes 获取）`)
  return key
}

function parseMode(value: unknown): ResultMode {
  return value === 'minimal' || value === 'full' ? value : 'preview'
}

const RETRIEVE_SOURCES = ['fulltext', 'notes', 'annotations'] as const

function parseSources(value: unknown): ZoteroRetrieveSource[] {
  if (!Array.isArray(value) || value.length === 0) return [...RETRIEVE_SOURCES]
  const picked = value.filter((s): s is ZoteroRetrieveSource => (RETRIEVE_SOURCES as readonly string[]).includes(s as string))
  return picked.length > 0 ? picked : [...RETRIEVE_SOURCES]
}

function describeItem(item: ZoteroItemResult['item'], index?: number): string {
  const parts = [item.itemType, item.date, item.publicationTitle].filter(Boolean).join(' | ')
  const prefix = index === undefined ? '' : `#${index} `
  return `${prefix}${item.title} [key=${item.key}${parts ? ' | ' + parts : ''}]`
}

function renderSearch(value: ZoteroSearchResult): TextBlock[] {
  if (value.items.length === 0) {
    return oneText(`检索完成，没有匹配的条目${value.totalResults !== undefined ? `（服务器匹配 ${value.totalResults} 条，均已按条件过滤）` : ''}。`)
  }
  const lines = value.items.map((item, i) => describeItem(item, i + 1))
  const total = value.totalResults !== undefined ? `，共匹配 ${value.totalResults} 条` : ''
  return oneText(
    `Zotero 检索结果（展示 ${value.items.length} 条${total}）：\n\n${lines.join('\n')}\n\n用 zotero_item 配合 key 查看条目详情和附件。`,
  )
}

function renderItem(value: ZoteroItemResult): TextBlock[] {
  const { item, attachments, childNotes } = value
  const fields = [
    ['类型', item.itemType],
    ['作者', item.creators],
    ['日期', item.date],
    ['出版物', item.publicationTitle],
    ['卷期页', [item.volume, item.issue, item.pages].filter(Boolean).join('/') || undefined],
    ['出版商', item.publisher],
    ['DOI', item.DOI],
    ['ISBN', item.ISBN],
    ['链接', item.url],
    ['标签', item.tags?.join(', ')],
    ['加入时间', item.dateAdded],
  ] as const
  const lines = fields.filter(([, v]) => v).map(([k, v]) => `${k}: ${v}`)
  let text = `条目 ${item.key}: ${item.title}\n${lines.join('\n')}`
  if (item.abstractNote) text += `\n\n摘要:\n${item.abstractNote}`
  if (attachments.length > 0) {
    text += '\n\n附件:\n' + attachments
      .map((a, i) => `#${i} [attachmentKey=${a.key}] ${a.title ?? a.filename ?? '(未命名)'} (${a.contentType ?? '未知类型'})`)
      .join('\n')
    text += '\n可用 zotero_fulltext 直接读全文，或 zotero_download 下载副本。'
  } else {
    text += '\n\n该条目没有附件。'
  }
  if (childNotes > 0) text += `\n另有 ${childNotes} 条子笔记（用 zotero_notes 查看）。`
  return oneText(text)
}

function renderCollections(value: ZoteroCollectionsResult): TextBlock[] {
  if (value.collections.length === 0) return oneText('文献库中没有任何分类。')
  const lines = value.collections.map(
    (c, i) => `#${i + 1} ${c.name} [collectionKey=${c.key}，${c.numberOfItems} 条]${c.parentCollection ? '（子分类）' : ''}`,
  )
  return oneText(`Zotero 分类（${value.collections.length} 个）：\n\n${lines.join('\n')}\n\n把 collectionKey 填进 zotero_search 的 collection 参数即可限定检索范围。`)
}

function renderDownload(value: ZoteroDownloadResult): TextBlock[] {
  return oneText(`已下载附件 "${value.filename}"（${value.contentType}，${value.size} 字节）到：\n${value.path}\n可用 read 工具读取该文件。`)
}

function renderNotes(value: ZoteroNotesResult): TextBlock[] {
  if (value.notes.length === 0) {
    return oneText('没有匹配的笔记。')
  }
  const lines = value.notes.map((n, i) => {
    const preview = n.text.length > 200 ? n.text.slice(0, 200) + '…' : n.text
    const parent = n.parentKey ? `，属于条目 ${n.parentKey}` : ''
    return `#${i + 1} [noteKey=${n.key}${parent}]\n${preview || '(空笔记)'}`
  })
  return oneText(`Zotero 笔记（${value.notes.length} 条）：\n\n${lines.join('\n\n')}\n\n用 zotero_note 配合 noteKey 可追加、更新或删除笔记。`)
}

function renderNote(value: ZoteroNoteResult): TextBlock[] {
  switch (value.action) {
    case 'create':
      return oneText(`已为条目 ${value.parentKey} 添加笔记（noteKey=${value.noteKey}）。`)
    case 'append':
      return oneText(`已把内容追加到笔记 ${value.noteKey} 末尾。`)
    case 'update':
      return oneText(`已更新笔记 ${value.noteKey} 的内容。`)
    case 'delete':
      return oneText(`已删除笔记 ${value.noteKey}。`)
  }
}

function renderFulltext(value: ZoteroFulltextResult): TextBlock[] {
  if (value.mode === 'file') {
    return oneText(`未命中 Zotero 全文缓存，附件本地文件路径：\n${value.path}\n（${value.filename}，${value.size} 字节）可用 read 工具直接读取。`)
  }
  const truncated = value.truncated ? `\n\n（正文超过上限已截断；需要完整内容可对附件用 zotero_attachment_path 拿路径后分段读取）` : ''
  return oneText(`条目 ${value.itemKey} 附件 ${value.attachmentKey}（${value.filename}）的全文：\n\n${value.text}${truncated}`)
}

function renderAttachmentPath(value: ZoteroAttachmentPathResult): TextBlock[] {
  if (value.exists) {
    return oneText(`附件 ${value.attachmentKey} 的本地原始路径：\n${value.path}\n可直接用 read 工具读取，无需下载副本。`)
  }
  if (value.linked) {
    return oneText(`附件 ${value.attachmentKey} 不在本机（记录的路径/URL 为 ${value.path}）。远程链接附件无法直接读取；存储在本机的附件请检查该路径是否可访问。`)
  }
  return oneText(`无法解析附件 ${value.attachmentKey} 的本地路径（storage 目录未找到或文件不在预期位置）。可在 cordis.patch.yml 配置 storageDir / dataDir，或改用 zotero_download。`)
}

const SOURCE_LABEL: Record<ZoteroRetrieveSource, string> = { fulltext: '全文', notes: '笔记', annotations: '批注' }

function renderPassages(passages: ZoteroPassage[]): string {
  return passages
    .map((p, i) => {
      const where = [
        SOURCE_LABEL[p.source] ?? p.source,
        p.page !== undefined ? `PDF 第 ${p.page} 页` : undefined,
        p.pageLabel ? `（文中页码 ${p.pageLabel}）` : undefined,
      ].filter(Boolean).join(' ')
      const anchor = [p.noteKey ? `noteKey=${p.noteKey}` : undefined, p.annotationKey ? `annKey=${p.annotationKey}` : undefined]
        .filter(Boolean).join(' ')
      const score = Number.isFinite(p.score) ? ` | 相关度 ${p.score.toFixed(2)}` : ''
      return `#${i + 1} [${where}${anchor ? ' | ' + anchor : ''}${score}]\n${p.text}`
    })
    .join('\n\n')
}

function renderExport(value: ZoteroExportResult): TextBlock[] {
  if (value.count === 0) {
    return oneText(`导出失败（0 条成功）：\n${(value.failed ?? ['原因未知']).join('\n')}`)
  }
  const failedNote = value.failed && value.failed.length > 0 ? `\n\n以下条目导出失败：\n${value.failed.join('\n')}` : ''
  const truncated = value.truncated ? '\n\n（内容超过上限已截断）' : ''
  return oneText(`Zotero 导出（${value.format}，成功 ${value.count} 条）：\n\n${value.text}${failedNote}${truncated}`)
}

function renderAnnotations(value: ZoteroAnnotationsResult): TextBlock[] {
  if (value.count === 0) return oneText('该条目（或指定附件）没有任何批注。')
  const lines = value.annotations.map((a, i) => {
    const where = [
      a.page !== undefined ? `PDF 第 ${a.page} 页` : undefined,
      a.pageLabel ? `（文中页码 ${a.pageLabel}）` : undefined,
    ].filter(Boolean).join('')
    const head = `#${i + 1} [annKey=${a.key}] ${a.annotationType ?? 'annotation'}${where ? ' @ ' + where : ''}`
    const body = [a.text, a.comment ? `评论: ${a.comment}` : undefined].filter(Boolean).join('\n')
    return body !== '' ? `${head}\n${body}` : head
  })
  return oneText(`Zotero 批注（${value.count} 条）：\n\n${lines.join('\n\n')}\n\n加 attachmentKey 参数可只看单个附件的批注。`)
}

function renderBrowse(value: ZoteroBrowseResult): TextBlock[] {
  if (value.type === 'tags') {
    if (value.count === 0) return oneText('文献库还没有任何用户标签。')
    const lines = (value.tags ?? []).map((t, i) => `#${i + 1} ${t}`)
    return oneText(`Zotero 标签（${value.count} 个）：\n\n${lines.join('\n')}\n\n把标签名填进 zotero_search 的 tag 参数即可筛选。`)
  }
  if (value.count === 0) return oneText('文献库没有保存的智能搜索。')
  const lines = (value.searches ?? []).map(
    (s, i) => `#${i + 1} ${s.name} [searchKey=${s.key}]${s.conditions ? `\n条件: ${s.conditions}` : ''}`,
  )
  return oneText(`Zotero 保存的搜索（${value.count} 个）：\n\n${lines.join('\n\n')}`)
}

function renderRetrieve(value: ZoteroRetrieveResult): TextBlock[] {
  const header = `条目 ${value.itemKey}${value.title ? `「${value.title}」` : ''} 中与「${value.query}」最相关的段落`
  if (value.count === 0) {
    const hint =
      value.sourcesUsed.length === 0
        ? '（该条目没有可检索的全文/笔记/批注——可能没有 PDF 附件，或全文尚未建立索引）'
        : '（来源内容里没有匹配的段落，试试更短或更具体的关键词）'
    return oneText(`${header}：没有找到。${hint}`)
  }
  const sources = value.sourcesUsed.map((s) => SOURCE_LABEL[s] ?? s).join('、')
  return oneText(`${header}（Top ${value.count}，来源：${sources}）：\n\n${renderPassages(value.passages)}`)
}

function renderDigest(value: ZoteroDigestResult): TextBlock[] {
  const item = value.item
  const fields = [
    ['作者', item.creators],
    ['日期', item.date],
    ['出版物', item.publicationTitle],
    ['卷期页', [item.volume, item.issue, item.pages].filter(Boolean).join('/') || undefined],
    ['出版商', item.publisher],
    ['DOI', item.DOI],
    ['链接', item.url],
    ['标签', item.tags?.join(', ')],
  ] as const
  let text = `条目 ${item.key}: ${item.title}\n${fields.filter(([, v]) => v).map(([k, v]) => `${k}: ${v}`).join('\n')}`
  if (item.abstractNote) text += `\n\n摘要:\n${item.abstractNote}`
  if (value.citation.trim() !== '') text += `\n\n引用（BibTeX）:\n${value.citation.trim()}`
  text += `\n\n附件: ${
    value.attachments.length === 0
      ? '无'
      : value.attachments.map((a, i) => `#${i} [attachmentKey=${a.key}] ${a.title ?? a.filename ?? '(未命名)'}`).join('，')
  }`
  if (value.childNotes > 0) text += `；子笔记 ${value.childNotes} 条`
  if (value.passages.length > 0) {
    text += `\n\n与「${value.query}」相关的段落（Top ${value.passages.length}）:\n\n${renderPassages(value.passages)}`
  } else {
    text += '\n\n（没有可提取的全文/笔记/批注段落——该条目可能没有 PDF，或全文尚未建立索引）'
  }
  return oneText(text)
}

export function apply(ctx: any, config: ZoteroConfig = {}): void {
  const resolved = resolveConfig(config)
  const client = new ZoteroClient(resolved)
  const storageDir = resolveStorageDir({ dataDir: resolved.dataDir, storageDir: resolved.storageDir })

  // Load-time nudge only: never break boot, tools report the details instead.
  void client.ping().catch((error: unknown) => {
    ctx.logger?.warn?.('[dsh-zotero] ' + messageOf(error, 'Zotero 本地 API 不可用'))
  })
  if (storageDir === null) {
    ctx.logger?.info?.('[dsh-zotero] 未找到 Zotero storage 目录，zotero_fulltext 将退化为下载附件；可在 cordis.patch.yml 配置 storageDir/dataDir')
  }

  type LoadedFulltext =
    | { mode: 'text'; attachmentKey: string; filename: string; text: string; truncated: boolean; pages: string[] | null }
    | { mode: 'file'; attachmentKey: string; filename: string; path?: string; size?: number; contentType?: string }

  /**
   * 取条目附件全文（全文缓存 → 现场解析 PDF → 兜底下载）。
   * zotero_fulltext 与 zotero_retrieve/zotero_digest 共用；
   * text 模式附带 pages（缓存含换页符 \f 或 pdfjs 分页时），供检索打页码锚点。
   * allowDownload=false（检索场景）不落盘下载，直接让调用方跳过全文源。
   */
  async function loadFulltext(
    itemKey: string,
    attachmentKey: string | undefined,
    cwd: string | undefined,
    allowDownload: boolean,
  ): Promise<LoadedFulltext | null> {
    const { attachments } = await client.item(itemKey)
    if (attachments.length === 0) return null
    const target = attachmentKey
      ? attachments.find((a) => a.key === attachmentKey)
      : attachments.find((a) => (a.contentType ?? '').includes('pdf')) ??
        attachments.find((a) => a.path?.startsWith('storage:')) ??
        attachments[0]
    if (!target) throw new Error(`附件 ${attachmentKey} 不属于条目 ${itemKey}。请用 zotero_item 查看附件列表。`)
    const label = target.filename ?? target.title ?? '(未知)'

    const cacheHit = (cache: string): LoadedFulltext => {
      const truncated = cache.length > resolved.maxFulltextChars
      // \f（换页符）存在时按页切分供页码锚点；没有就整体返回（pages=null 无页码）
      const pages = cache.includes('\f') ? cache.split('\f').map((p) => p.trim()) : null
      return {
        mode: 'text',
        attachmentKey: target.key,
        filename: label,
        text: truncated ? cache.slice(0, resolved.maxFulltextChars) : cache,
        truncated,
        pages: pages !== null && pages.length > 1 ? pages : null,
      }
    }

    // 首选：/file 端点 302 的 Location 就是附件本地路径，.zotero-ft-cache 与其同目录
    const location = await client.attachmentFilePath(target.key).catch(() => null)
    if (location?.startsWith('file:')) {
      const filePath = fileUrlToPath(location)
      const cache = await readFulltextFile(join(dirname(filePath), '.zotero-ft-cache'))
      if (cache) return cacheHit(cache)
      if (existsSync(filePath)) {
        const { size } = await stat(filePath)
        // 缓存未命中：现场解析 PDF（pdfjs-dist，按页解析保留页界），并写缓存加速下次
        if ((target.contentType ?? '').includes('pdf') || /\.pdf$/i.test(filePath)) {
          try {
            const pages = await extractPdfPages(filePath)
            const extracted = pages.filter((p) => p !== '').join('\n')
            if (extracted.trim() !== '') {
              await writeFile(join(dirname(filePath), '.zotero-ft-cache'), extracted, 'utf8').catch(() => {})
              const truncated = extracted.length > resolved.maxFulltextChars
              return {
                mode: 'text',
                attachmentKey: target.key,
                filename: basename(filePath),
                text: truncated ? extracted.slice(0, resolved.maxFulltextChars) : extracted,
                truncated,
                pages: pages.length > 1 ? pages : null,
              }
            }
          } catch (error) {
            ctx.logger?.warn?.('[dsh-zotero] PDF 解析失败，返回文件路径: ' + messageOf(error, 'unknown'))
          }
        }
        return { mode: 'file', attachmentKey: target.key, filename: basename(filePath), path: filePath, size }
      }
    }
    // 次选：storage 目录探测（dataDir/storageDir 配置）
    if (storageDir) {
      const cache = await readFulltextCache(storageDir, target.key)
      if (cache) return cacheHit(cache)
    }
    // 兜底：下载附件副本到工作区（远程链接附件等场景）；检索场景不落盘
    if (!allowDownload) {
      return { mode: 'file', attachmentKey: target.key, filename: label }
    }
    const { bytes, contentType, filename } = await client.downloadAttachment(target.key)
    const path = await writeAttachment(filename, bytes, resolved.downloadDir, cwd)
    return { mode: 'file', attachmentKey: target.key, filename, path, size: bytes.byteLength, contentType }
  }

  /** 按来源收集段落并针对 query 打分排序（zotero_retrieve / zotero_digest 共用） */
  async function gatherPassages(
    itemKey: string,
    query: string,
    sources: ZoteroRetrieveSource[],
    attachmentKey?: string,
  ): Promise<{ passages: ScoredPassage[]; sourcesUsed: ZoteroRetrieveSource[] }> {
    const raw: PassageInput[] = []
    const sourcesUsed: ZoteroRetrieveSource[] = []
    if (sources.includes('fulltext')) {
      const loaded = await loadFulltext(itemKey, attachmentKey, undefined, false).catch(() => null)
      if (loaded?.mode === 'text' && loaded.text.trim() !== '') {
        sourcesUsed.push('fulltext')
        const groups: Array<{ text: string; page?: number }> =
          loaded.pages !== null && loaded.pages.length > 1
            ? loaded.pages.map((pageText, idx) => ({ text: pageText, page: idx + 1 }))
            : [{ text: loaded.text }]
        for (const group of groups) {
          for (const segment of splitPassages(group.text)) {
            raw.push({ source: 'fulltext', text: segment, page: group.page, attachmentKey: loaded.attachmentKey })
          }
        }
      }
    }
    if (sources.includes('notes')) {
      const notes = await client.listNotes({ itemKey, limit: 50 }).catch(() => [])
      if (notes.length > 0) sourcesUsed.push('notes')
      for (const note of notes) {
        for (const segment of splitPassages(note.text)) {
          raw.push({ source: 'notes', text: segment, noteKey: note.key })
        }
      }
    }
    if (sources.includes('annotations')) {
      const annotations = await client.annotations(itemKey, attachmentKey).catch(() => [])
      if (annotations.length > 0) sourcesUsed.push('annotations')
      for (const annotation of annotations) {
        const combined = [annotation.text, annotation.comment].filter(Boolean).join('\n')
        if (combined.trim() === '') continue
        for (const segment of splitPassages(combined, 900, 120)) {
          raw.push({
            source: 'annotations',
            text: segment,
            page: annotation.page,
            pageLabel: annotation.pageLabel,
            annotationKey: annotation.key,
            attachmentKey: annotation.parentKey,
          })
        }
      }
    }
    return { passages: scorePassages(raw, query), sourcesUsed }
  }

  ctx.tools.register({
    name: 'zotero_collections',
    description:
      'List the collections (folders) of the Zotero library, with their keys and item counts. Use a returned collectionKey as the collection argument of zotero_search to scope a search. Requires Zotero 7+ (tested on 9.x) running locally with "Allow other applications on this computer" enabled.',
    parameters: {
      type: 'object',
      properties: {},
    },
    output: {
      schema: { type: 'object', properties: { collections: { type: 'array', items: { type: 'object', additionalProperties: true } } } },
      render: (_args: unknown, value: unknown) => renderCollections(value as ZoteroCollectionsResult),
    },
    async execute() {
      return { collections: await client.collections() }
    },
  })

  ctx.tools.register({
    name: 'zotero_search',
    description:
      'Search the local Zotero library by keyword (title/creator/year, Zotero quick-search), with filters for item type, collection, tag and publication year range, plus sorting and pagination. Control payload size with mode. Returns compact rows with item keys; use zotero_item with a key for full metadata and attachments.',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Quick-search keyword (title, creator, year...); omit to list items (with filters applied)' },
        itemType: { type: 'string', description: 'Zotero item type filter, e.g. "journalArticle", "book"' },
        collection: { type: 'string', description: 'collectionKey from zotero_collections to restrict the search' },
        tag: { type: 'string', description: 'Only items carrying this tag' },
        sinceYear: { type: 'integer', description: 'Only items published in this year or later' },
        beforeYear: { type: 'integer', description: 'Only items published in this year or earlier' },
        sort: { type: 'string', description: `Sort field: ${SORT_HINT}. Defaults to relevance when query is given` },
        direction: { type: 'string', description: 'Sort direction: asc | desc' },
        offset: { type: 'integer', description: 'Skip this many results first, default 0' },
        limit: { type: 'integer', description: 'Max rows to return, 1-100, default 20' },
        mode: { type: 'string', description: `Result verbosity: ${MODE_HINT}` },
      },
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          count: { type: 'integer' },
          totalResults: { type: 'integer' },
          items: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
      },
      render: (_args: unknown, value: unknown) => renderSearch(value as ZoteroSearchResult),
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as ZoteroSearchArgs
      const limit = clampInt(args.limit, 20, 1, Math.min(resolved.maxLimit, MAX_LIMIT))
      const offset = clampInt(args.offset, 0, 0, 10000)
      const { items, totalResults } = await client.search({
        query: args.query,
        itemType: args.itemType,
        collection: args.collection,
        tag: args.tag,
        sinceYear: args.sinceYear,
        beforeYear: args.beforeYear,
        sort: args.sort,
        direction: args.direction,
        start: offset,
        limit,
      })
      return { count: items.length, totalResults, items: trimItems(items, parseMode(args.mode)) }
    },
  })

  ctx.tools.register({
    name: 'zotero_recent',
    description:
      'List the most recently ADDED items of the Zotero library (newest first, attachments and notes excluded). Use it for "what did I just import" questions; use zotero_item with a key for details.',
    parameters: {
      type: 'object',
      properties: {
        limit: { type: 'integer', description: 'Max rows to return, 1-100, default 10' },
        mode: { type: 'string', description: `Result verbosity: ${MODE_HINT}` },
      },
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          count: { type: 'integer' },
          items: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
      },
      render: (_args: unknown, value: unknown) => {
        const result = value as { count: number; items: ZoteroItemResult['item'][] }
        if (result.items.length === 0) return oneText('文献库是空的。')
        const lines = result.items.map((item, i) => describeItem(item, i + 1))
        return oneText(`最近添加的条目（${result.items.length} 条）：\n\n${lines.join('\n')}\n\n用 zotero_item 配合 key 查看详情。`)
      },
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as ZoteroRecentArgs
      const limit = clampInt(args.limit, 10, 1, Math.min(resolved.maxLimit, MAX_LIMIT))
      const { items } = await client.recent(limit)
      const trimmed = trimItems(items, parseMode(args.mode))
      return { count: trimmed.length, items: trimmed }
    },
  })

  ctx.tools.register({
    name: 'zotero_item',
    description:
      'Read one Zotero item in full by its key (from zotero_search): authors, publication venue, DOI, abstract and tags, plus its child attachments (PDF keys) and note count.',
    parameters: {
      type: 'object',
      properties: {
        key: { type: 'string', description: 'Item key, 8 chars, from zotero_search or zotero_recent' },
      },
      required: ['key'],
    },
    output: {
      schema: { type: 'object', properties: { item: { type: 'object', additionalProperties: true } } },
      render: (_args: unknown, value: unknown) => renderItem(value as ZoteroItemResult),
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as { key?: string }
      const key = requireKey(args.key, 'key')
      return await client.item(key)
    },
  })

  ctx.tools.register({
    name: 'zotero_fulltext',
    description:
      'Read the full text of a Zotero item (its PDF or other main attachment) as plain text — from Zotero\'s own fulltext cache (.zotero-ft-cache) when available, otherwise parsed on the fly from the local PDF (pdfjs-dist) and cached. Only for remote-link-only attachments does it download a copy to the workspace and return its path. Prefer this over zotero_download when you only need the text.',
    parameters: {
      type: 'object',
      properties: {
        itemKey: { type: 'string', description: 'Item key (from zotero_search)' },
        attachmentKey: { type: 'string', description: 'Specific attachment key (from zotero_item); default picks the first PDF' },
      },
      required: ['itemKey'],
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          itemKey: { type: 'string' },
          attachmentKey: { type: 'string' },
          filename: { type: 'string' },
          mode: { type: 'string' },
          text: { type: 'string' },
          truncated: { type: 'boolean' },
          path: { type: 'string' },
          size: { type: 'integer' },
        },
      },
      render: (_args: unknown, value: unknown) => renderFulltext(value as ZoteroFulltextResult),
    },
    async execute(rawArgs: unknown, exec: any) {
      const args = rawArgs as { itemKey?: string; attachmentKey?: string }
      const itemKey = requireKey(args.itemKey, 'itemKey')
      const attachmentKey =
        args.attachmentKey && args.attachmentKey.trim() !== '' ? requireKey(args.attachmentKey, 'attachmentKey') : undefined
      const cwd = typeof exec?.agent?.session?.header?.cwd === 'string' ? exec.agent.session.header.cwd : undefined
      const loaded = await loadFulltext(itemKey, attachmentKey, cwd, true)
      if (!loaded) throw new Error(`条目 ${itemKey} 没有附件，无法读取全文。`)
      if (loaded.mode === 'text') {
        return {
          itemKey,
          attachmentKey: loaded.attachmentKey,
          filename: loaded.filename,
          mode: 'text' as const,
          text: loaded.text,
          truncated: loaded.truncated,
        }
      }
      if (loaded.path === undefined) {
        throw new Error(
          `无法获取附件 ${loaded.filename} 的内容：可能是链接型附件且目标文件不在本机，或文件尚未同步到本地。`,
        )
      }
      return {
        itemKey,
        attachmentKey: loaded.attachmentKey,
        filename: loaded.filename,
        mode: 'file' as const,
        path: loaded.path,
        size: loaded.size,
        contentType: loaded.contentType,
      }
    },
  })

  ctx.tools.register({
    name: 'zotero_download',
    description:
      'Download one attachment (typically a PDF) of a Zotero item to the local filesystem — by default into the session workspace so the model can read it. Use the attachmentKey values listed by zotero_item. If you only need the text, prefer zotero_fulltext. Size is capped by maxAttachmentBytes.',
    parameters: {
      type: 'object',
      properties: {
        itemKey: { type: 'string', description: 'Parent item key (from zotero_search)' },
        attachmentKey: { type: 'string', description: 'Attachment key (from zotero_item attachment list)' },
      },
      required: ['itemKey', 'attachmentKey'],
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          key: { type: 'string' },
          filename: { type: 'string' },
          contentType: { type: 'string' },
          size: { type: 'integer' },
          path: { type: 'string' },
        },
      },
      render: (_args: unknown, value: unknown) => renderDownload(value as ZoteroDownloadResult),
    },
    async execute(rawArgs: unknown, exec: any) {
      const args = rawArgs as { itemKey?: string; attachmentKey?: string }
      const itemKey = requireKey(args.itemKey, 'itemKey')
      const attachmentKey = requireKey(args.attachmentKey, 'attachmentKey')
      await client.attachmentInfo(itemKey, attachmentKey)
      const { bytes, contentType, filename } = await client.downloadAttachment(attachmentKey)
      const cwd = typeof exec?.agent?.session?.header?.cwd === 'string' ? exec.agent.session.header.cwd : undefined
      const path = await writeAttachment(filename, bytes, resolved.downloadDir, cwd)
      return { key: attachmentKey, filename, contentType, size: bytes.byteLength, path }
    },
  })

  ctx.tools.register({
    name: 'zotero_attachment_path',
    description:
      'Resolve the on-disk path of a stored attachment (zero-copy): returns the absolute path inside Zotero storage so the model can read the original file directly. Works for stored attachments; linked attachments report their recorded path.',
    parameters: {
      type: 'object',
      properties: {
        itemKey: { type: 'string', description: 'Parent item key (from zotero_search)' },
        attachmentKey: { type: 'string', description: 'Attachment key (from zotero_item attachment list)' },
      },
      required: ['itemKey', 'attachmentKey'],
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          itemKey: { type: 'string' },
          attachmentKey: { type: 'string' },
          path: { type: 'string' },
          exists: { type: 'boolean' },
          linked: { type: 'boolean' },
        },
      },
      render: (_args: unknown, value: unknown) => renderAttachmentPath(value as ZoteroAttachmentPathResult),
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as { itemKey?: string; attachmentKey?: string }
      const itemKey = requireKey(args.itemKey, 'itemKey')
      const attachmentKey = requireKey(args.attachmentKey, 'attachmentKey')
      const target = await client.attachmentInfo(itemKey, attachmentKey)
      const location = await client.attachmentFilePath(attachmentKey).catch(() => null)
      if (location?.startsWith('file:')) {
        const resolvedPath = fileUrlToPath(location)
        return { itemKey, attachmentKey, path: resolvedPath, exists: existsSync(resolvedPath) }
      }
      if (location?.startsWith('http')) {
        return { itemKey, attachmentKey, path: location, exists: false, linked: true }
      }
      if (storageDir) {
        const resolvedPath = attachmentStoragePath(storageDir, attachmentKey, target.path)
        if (resolvedPath) {
          return { itemKey, attachmentKey, path: resolvedPath, exists: existsSync(resolvedPath) }
        }
      }
      if (target.path?.startsWith('attachments:')) {
        return { itemKey, attachmentKey, path: target.path, exists: false, linked: true }
      }
      return { itemKey, attachmentKey, path: target.path ?? '', exists: false }
    },
  })

  ctx.tools.register({
    name: 'zotero_notes',
    description:
      'List or search the notes of the Zotero library: with itemKey, the child notes of that item; otherwise a library-wide keyword search over note text (newest first). Returns noteKeys for zotero_note (append/update/delete).',
    parameters: {
      type: 'object',
      properties: {
        itemKey: { type: 'string', description: 'Item key: list only this item\'s child notes' },
        query: { type: 'string', description: 'Keyword to search in note text (library-wide; omit with itemKey omitted to list recent notes)' },
        limit: { type: 'integer', description: 'Max notes to return, 1-50, default 10' },
      },
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          count: { type: 'integer' },
          notes: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
      },
      render: (_args: unknown, value: unknown) => renderNotes(value as ZoteroNotesResult),
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as { itemKey?: string; query?: string; limit?: number }
      const limit = clampInt(args.limit, 10, 1, Math.min(resolved.maxLimit, MAX_LIMIT))
      const itemKey = args.itemKey && args.itemKey.trim() !== '' ? requireKey(args.itemKey, 'itemKey') : undefined
      const notes = await client.listNotes({ itemKey, query: args.query, limit })
      return { count: notes.length, notes }
    },
  })

  ctx.tools.register({
    name: 'zotero_note',
    description:
      'Write notes to Zotero: create a child note under an item, or append to / update / delete an existing note (noteKeys from zotero_notes). Only write notes the user asked for; never invent content.',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', description: 'create (default) | append | update | delete' },
        itemKey: { type: 'string', description: 'Parent item key, required for create (from zotero_search)' },
        noteKey: { type: 'string', description: 'Note key, required for append/update/delete (from zotero_notes)' },
        text: { type: 'string', description: 'Note body; HTML tags allowed. Required for create/append/update' },
        tags: { type: 'array', items: { type: 'string' }, description: 'Optional tags (create/update)' },
      },
    },
    output: {
      schema: {
        type: 'object',
        properties: { action: { type: 'string' }, parentKey: { type: 'string' }, noteKey: { type: 'string' } },
      },
      render: (_args: unknown, value: unknown) => renderNote(value as ZoteroNoteResult),
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as { action?: string; itemKey?: string; noteKey?: string; text?: string; tags?: string[] }
      const action = (args.action ?? 'create') as ZoteroNoteAction
      if (!(['create', 'append', 'update', 'delete'] as const).includes(action)) {
        throw new Error(`action 只能是 create | append | update | delete（收到 "${args.action}"）`)
      }
      const text = (args.text ?? '').trim()
      const tags = Array.isArray(args.tags) ? args.tags : undefined
      if (action === 'create') {
        const itemKey = requireKey(args.itemKey, 'itemKey')
        if (text === '') throw new Error('text 不能为空')
        const noteKey = await client.addNote(itemKey, text, tags)
        return { action, parentKey: itemKey, noteKey }
      }
      const noteKey = requireKey(args.noteKey, 'noteKey')
      if (action === 'delete') {
        await client.deleteNote(noteKey)
        return { action, noteKey }
      }
      if (text === '') throw new Error(`action=${action} 时 text 不能为空`)
      if (action === 'append') await client.appendNote(noteKey, text)
      else await client.updateNote(noteKey, text, tags)
      return { action, noteKey }
    },
  })

  ctx.tools.register({
    name: 'zotero_export',
    description:
      'Export citation data for one or more Zotero items as BibTeX, RIS or CSL JSON. Keys are exported one by one (the local API ignores multi-key filters) and the results are concatenated. Use keys from zotero_search/zotero_item; paste results into .bib/.ris files or reference managers.',
    parameters: {
      type: 'object',
      properties: {
        keys: { type: 'array', items: { type: 'string' }, description: 'Item keys (8 chars each, from zotero_search or zotero_item), 1-25 per call' },
        format: { type: 'string', description: 'bibtex (default) | ris | csljson' },
      },
      required: ['keys'],
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          format: { type: 'string' },
          count: { type: 'integer' },
          text: { type: 'string' },
          truncated: { type: 'boolean' },
          failed: { type: 'array', items: { type: 'string' } },
        },
      },
      render: (_args: unknown, value: unknown) => renderExport(value as ZoteroExportResult),
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as { keys?: unknown; format?: unknown }
      if (!Array.isArray(args.keys) || args.keys.length === 0) {
        throw new Error('keys 必须是非空的条目 key 数组（用 zotero_search / zotero_item 获取）')
      }
      const keys = [...new Set(args.keys.map((k) => requireKey(typeof k === 'string' ? k : undefined, 'keys[]')))]
      if (keys.length > 25) throw new Error('keys 一次最多 25 个（本地 API 需逐条导出，太多会拖慢响应）')
      const format = args.format === 'ris' || args.format === 'csljson' ? args.format : 'bibtex'
      const chunks: string[] = []
      const failed: string[] = []
      for (const key of keys) {
        try {
          const text = await client.exportItem(key, format)
          chunks.push(format === 'csljson' ? JSON.stringify(JSON.parse(text)) : text.trim())
        } catch (error) {
          failed.push(`${key}: ${messageOf(error, '导出失败')}`)
        }
      }
      let text: string
      if (format === 'csljson') {
        const parsed = chunks.flatMap((chunk) => {
          try {
            const value = JSON.parse(chunk)
            return Array.isArray(value) ? value : [value]
          } catch {
            return []
          }
        })
        text = JSON.stringify(parsed, null, 2)
      } else {
        text = chunks.join('\n\n')
      }
      const truncated = text.length > resolved.maxFulltextChars
      return {
        format,
        count: keys.length - failed.length,
        text: truncated ? text.slice(0, resolved.maxFulltextChars) : text,
        truncated: truncated || undefined,
        failed: failed.length > 0 ? failed : undefined,
      }
    },
  })

  ctx.tools.register({
    name: 'zotero_annotations',
    description:
      'Read the PDF annotations (highlights, in-Zotero annotation notes, underlines) on a Zotero item\'s attachments, each with PDF page number, printed page label, quoted text and your comment. Call after zotero_item to pick a target item.',
    parameters: {
      type: 'object',
      properties: {
        itemKey: { type: 'string', description: 'Item key (from zotero_search)' },
        attachmentKey: { type: 'string', description: 'Limit to one attachment (from zotero_item); default reads all attachments' },
      },
      required: ['itemKey'],
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          count: { type: 'integer' },
          annotations: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
      },
      render: (_args: unknown, value: unknown) => renderAnnotations(value as ZoteroAnnotationsResult),
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as { itemKey?: string; attachmentKey?: string }
      const itemKey = requireKey(args.itemKey, 'itemKey')
      const attachmentKey =
        args.attachmentKey && args.attachmentKey.trim() !== '' ? requireKey(args.attachmentKey, 'attachmentKey') : undefined
      const annotations = await client.annotations(itemKey, attachmentKey)
      return { count: annotations.length, annotations }
    },
  })

  ctx.tools.register({
    name: 'zotero_browse',
    description:
      'List the library\'s user tags or saved (smart) searches. Feed a returned tag into zotero_search\'s tag parameter to filter; saved searches are listed with their conditions for awareness.',
    parameters: {
      type: 'object',
      properties: {
        type: { type: 'string', description: 'tags (default) | searches' },
        limit: { type: 'integer', description: 'Max tags to return (tags only), 1-100, default 50' },
      },
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          type: { type: 'string' },
          count: { type: 'integer' },
          tags: { type: 'array', items: { type: 'string' } },
          searches: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
      },
      render: (_args: unknown, value: unknown) => renderBrowse(value as ZoteroBrowseResult),
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as { type?: string; limit?: number }
      const type = args.type === 'searches' ? 'searches' : 'tags'
      if (type === 'tags') {
        const limit = clampInt(args.limit, 50, 1, 100)
        const tags = await client.tags(limit)
        return { type, count: tags.length, tags }
      }
      const searches = await client.savedSearches(100)
      return { type, count: searches.length, searches }
    },
  })

  ctx.tools.register({
    name: 'zotero_retrieve',
    description:
      'Retrieve the most query-relevant passages from one Zotero item, ranked across its PDF full text (with page anchors), child notes and PDF annotations. Use it for precise quoting with page numbers, or answering "where does this paper say X".',
    parameters: {
      type: 'object',
      properties: {
        itemKey: { type: 'string', description: 'Item key (from zotero_search)' },
        query: { type: 'string', description: 'What to look for, Chinese or English; e.g. "纳米载体的副作用" or "immune related adverse events"' },
        sources: { type: 'array', items: { type: 'string' }, description: 'Which sources to search: fulltext | notes | annotations (default: all three)' },
        topK: { type: 'integer', description: 'Max passages to return, 1-20, default 8' },
        attachmentKey: { type: 'string', description: 'Limit fulltext/annotations to one attachment (from zotero_item)' },
      },
      required: ['itemKey', 'query'],
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          itemKey: { type: 'string' },
          title: { type: 'string' },
          query: { type: 'string' },
          count: { type: 'integer' },
          sourcesUsed: { type: 'array', items: { type: 'string' } },
          passages: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
      },
      render: (_args: unknown, value: unknown) => renderRetrieve(value as ZoteroRetrieveResult),
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as { itemKey?: string; query?: string; sources?: unknown; topK?: number; attachmentKey?: string }
      const itemKey = requireKey(args.itemKey, 'itemKey')
      const query = (args.query ?? '').trim()
      if (query === '') throw new Error('query 不能为空（说明要找什么）')
      const attachmentKey =
        args.attachmentKey && args.attachmentKey.trim() !== '' ? requireKey(args.attachmentKey, 'attachmentKey') : undefined
      const { item } = await client.item(itemKey)
      const sources = parseSources(args.sources)
      const { passages, sourcesUsed } = await gatherPassages(itemKey, query, sources, attachmentKey)
      const topK = clampInt(args.topK, 8, 1, 20)
      const top = passages.slice(0, topK)
      return { itemKey, title: item.title, query, count: top.length, sourcesUsed, passages: top }
    },
  })

  ctx.tools.register({
    name: 'zotero_digest',
    description:
      'One-shot briefing for a Zotero item: full metadata, abstract, BibTeX citation, attachment list and the top query-relevant passages (full text + annotations + notes, with page anchors). Omit query to rank passages by title terms. Use it as the first call for "summarize this paper" tasks.',
    parameters: {
      type: 'object',
      properties: {
        itemKey: { type: 'string', description: 'Item key (from zotero_search)' },
        query: { type: 'string', description: 'Focus for passage ranking; defaults to title-derived terms' },
        sources: { type: 'array', items: { type: 'string' }, description: 'fulltext | notes | annotations (default: all three)' },
        topK: { type: 'integer', description: 'Max passages, 1-20, default 5' },
      },
      required: ['itemKey'],
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          item: { type: 'object', additionalProperties: true },
          attachments: { type: 'array', items: { type: 'object', additionalProperties: true } },
          childNotes: { type: 'integer' },
          citation: { type: 'string' },
          citationFormat: { type: 'string' },
          query: { type: 'string' },
          passages: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
      },
      render: (_args: unknown, value: unknown) => renderDigest(value as ZoteroDigestResult),
    },
    async execute(rawArgs: unknown) {
      const args = rawArgs as { itemKey?: string; query?: string; sources?: unknown; topK?: number }
      const itemKey = requireKey(args.itemKey, 'itemKey')
      const detail = await client.item(itemKey)
      const query = args.query && args.query.trim() !== '' ? args.query.trim() : queryFromTitle(detail.item.title)
      const sources = parseSources(args.sources)
      const { passages } = await gatherPassages(itemKey, query, sources)
      const topK = clampInt(args.topK, 5, 1, 20)
      const citation = await client.exportItem(itemKey, 'bibtex').catch(() => '')
      return {
        item: detail.item,
        attachments: detail.attachments,
        childNotes: detail.childNotes,
        citation,
        citationFormat: 'bibtex',
        query,
        passages: passages.slice(0, topK),
      }
    },
  })

  // Keep ZoteroError referenced so the error type survives bundling.
  void ZoteroError
}
