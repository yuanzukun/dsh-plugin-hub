# Changelog

本项目遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [Unreleased]

## [1.1.0] - 2026-09-29

### 修复

- **DSH 升级到 0.2.0-rc.1 后整个插件被跳过（`skipping profile bundle`）**：
  `dsh-app-boot` 的兼容性判定只检查插件 `peerDependencies` 里
  `@deepseek-ai/dsh` / `@deepseek-ai/dsh-*` 的 semver 范围
  （`semver.satisfies(runtime, range, { includePrerelease: true })`），原来那批
  `^0.1.0-rc.7` 在 0.2.0-rc.1 上全部不满足，于是整个 bundle 被
  `prepareProfileEntries` 跳过。其中 `@deepseek-ai/dsh-client-runtime` 在
  0.2.0-rc.1 已不再发布（npm 上最新为 0.1.1-rc.2，内容已拆到
  `dsh-client-ui-slots` / `dsh-client-ui-renderer` / `dsh-client-store` 等包），
  这条 peer 永远无法满足。现改为 `^0.2.0-rc.1` 并移除该条；`slots` 服务在
  0.2.0-rc.1 由 `@deepseek-ai/dsh-client-ui-renderer` 提供，据此更新
  `dsh.client.inject`；`@deepseek-ai/cordis` 对齐生态统一的 `~4.0.4`。
  插件自身的运行时依赖没有变化——客户端 bundle 只外部化 `react` /
  `react/jsx-runtime`，构建产物里不含任何 `@deepseek-ai/*` 导入。
- **输入框的三个弹层（快捷消息 / Skills / MCP）背景透明、下层文字透出**：
  0.2.0-rc.1 把宿主菜单底色 `--dsw-specific-menu` 改成了两级间接的磨砂底
  （`body` → `var(--dsw-menu-surface-fill)`，light `#f8f9fa94`≈58% /
  dark `#43454a73`≈45%，且只有 `html[data-platform=darwin]` 被覆盖成近不透明），
  宿主一律配 `backdrop-filter: var(--dsw-menu-backdrop-filter)` 兜底
  （16 处引用中 11 处如此）。弹层此前只抄了 `background` 没抄模糊，于是只剩
  半透明。现改用宿主不透明的层级底色 `--dsw-alias-bg-layer-1`（与
  `.skp-panel` / `.skp-modal` 同一 token）；三个弹层共用 `.skp-composer-pop`，
  一并修复。

### 破坏性变更

- `peerDependencies` 的 dsh 范围由 `^0.1.0-rc.7` 改为 `^0.2.0-rc.1`，插件不再在
  dsh 0.1.x 上加载。

## [1.0.2] - 2026-09-16

### 修复

- **同一应用里只有第一个会话能看到 MCP 工具，其余会话静默 `conflict`**：
  `mcp/loader.ts` 顶层静态 `import` 拿到的是本插件 `dependencies` 里那份
  `@deepseek-ai/dsh-mcp-client`（0.1.0-rc.8），它按 `ctx.root` 预留
  `serverName`——全应用只允许一个会话挂上同名 server，后开的会话拿不到任何
  `mcp__*` 工具，面板聚合显示「任一会话已挂载」因而看不出问题；宿主自己那份
  （0.1.5-rc.2 起）按 agent 作用域预留（`scopeOf(ctx) ?? ctx.root`），多会话
  才能各自挂载。注意**升级依赖版本解决不了**：插件自带的
  `@deepseek-ai/dsh-scope` 副本里 `kScope` 是每份模块实例独有的 Symbol，
  `scopeOf()` 读不到宿主打在 agent ctx 上的 scope tag，仍会回落 `ctx.root`。
  现改为挂载时按包名向宿主 loader 取实例
  （`ctx.get("loader").import(...)` + `unwrapExports`，解析基准是 profile
  目录），宿主没有 loader 时才回落到自带副本。

## [1.0.1] - 2026-09-16

### 修复

- **DSH 升级到 0.1.5-rc.2 后打开「能力面板」即报 `transport failure for
  /capability-panel/skills.list: HTTP 405`**：宿主端原先用
  `connection.rpc.handle("/capability-panel", …)` 挂通道，该 API 在当前版本内部
  执行 `owner.effect(() => owner.webServer.register(route))`，其中 `owner` 经
  cordis 的 shadow/origin 绑定解析成 **connection 插件自己的 ctx**（inject 里
  没有 `webServer`），于是恒定抛 `cannot get property "webServer" without
  inject`——异常发生在 `rpc.handle` 内部，通道静默不挂载，浏览器端的 POST 落到
  前端静态兜底路由上，返回 405。现改为用宿主公开 API 自行挂前缀路由：
  `ctx.inject(["connection", "webServer"], …)` 等两端服务就位 +
  `connection.requestRejection(req)` 过宿主/来源信任与浏览器会话认证 +
  `webServer.register({ kind: "prefix", path, handler })` 注册路由，并自行实现
  与 `dsh-client-connection` 客户端 `rpc.call` 一致的线上信封
  （`client-request` / `server-response`）。路由注册生命周期挂在插件自己的
  fiber 上，插件卸载 / 重载即摘除。

## [1.0.0] - 2026-09-08

### 新增

- **「在本项目禁用」全局 skill（shadow stub 屏蔽占位）**：全局区详情卡新增
  「在本项目禁用 / 在本项目恢复」。禁用会在项目 `.agents/skills` 生成一个
  同名占位文件（frontmatter 双向禁用 + `metadata: capability-panel:
  shadow-stub` 标记）——宿主 registry 按 frontmatter name 合并技能且项目根
  rank 恒高于全局根，占位文件于是顶掉同名全局条目：catalog 注入、`skill`
  工具调用、`/name` 用户注入三条链路都在本项目内被宿主**原生**拒绝（其它
  项目不受影响，也不写任何插件私有状态）。占位条目出现在项目区（灰点 +
  「屏蔽占位」徽标，删除即恢复）；被遮蔽的全局条目带「本项目已禁用」徽标；
  项目区已有同名真实条目的全局技能带「项目副本生效中」徽标。
- **Skills 快捷弹层与宿主解析口径对齐**：同名 skill 以项目区条目为准（rank
  语义）——项目副本 / 屏蔽占位 / 项目原生条目被禁用（含仅关闭「用户调用」）
  时，该名字整体从弹层排除，不再漏出全局同名的"死口令"（点了宿主也不会
  注入）；`.claude` 兼容根的条目同步排除（宿主 registry 不扫描该根）。
- **Skill 调用方式可按方向细调**：详情卡「调用方式」字段上，「模型调用」
  与「用户调用」两个方向各自独立开关（例如只希望用户 `/name` 手动触发、
  不需要 agent 自动注入的 skill，关闭「模型调用」即可）。frontmatter 只
  写入 `disable-model-invocation` / `user-invocable` 对应扁平键，另一个
  方向原样保留，正文与其它元数据不动。两个方向状态不一致时，整体按钮
  显示蓝色「部分禁用」。
- **Skills 域改为「全局 / 项目」两区分离 + 导入制**：Skills 域内不再混排
  全局与项目条目、也不再走"项目级禁用全局项"的叠层（旧
  `capability-overrides.json` 的 skills 声明不再读取）。每区只列该作用域的
  真实文件：
  - 全局区管理 `~/.agents/skills` 等全局根，**全局技能没有启停与调用方向
    开关**（会影响所有项目），只有「导入到本项目」/ 导出 / 删除；
  - 项目区管理 `<项目>/.agents/skills` 等项目根，**启用/禁用与模型/用户
    调用方向只作用于项目文件**（写 frontmatter 扁平调用键，宿主原生链路
    下一步即生效）；
  - 全局区详情卡新增「**导入到本项目**」：把全局 skill 物理复制到项目根
    （目录型连资源），此后在本项目内独立控制；同名冲突可确认覆盖；
  - 安装对话框的目标随区固定（全局区只装全局，项目区只装项目）；
  - Skills 列表行不再显示「部分禁用」等文字状态标签，只保留**项目区行的
    状态圆点**（绿=双开、蓝=部分禁用、灰=全禁用）；行内"项目/全局"标签
    与"本项目禁用"标记同时删除（区归属即作用域）；
  - 详情卡标题旁新增**归属徽标**（项目=蓝 / 全局=绿，按作用域着色）；
    删除按钮语义统一为「删除」（全局条目删全局文件，项目条目删项目文件）。
- **MCP / 快捷消息域同步改为「项目 / 全局」两区分离**：三域视图头部统一
  为项目/全局两区 Tab（取代 All/Project/Global 三档作用域过滤），每区
  只列该作用域配置文件里的真实条目；列表行不再渲染"项目/全局"标签（区
  归属即作用域），状态圆点只在项目区行显示；新增/安装对话框的默认作用域
  跟随当前区（全局区只见全局目标）。
- **「导入到本项目」（MCP / 快捷消息）= 登记引用而非物理复制**：全局区
  详情卡新增「导入到本项目」，写入
  `<项目根>/.agents/capability-imports.json`。引用内容实时取自同名全局
  条目（全局更新立即生效），启停是引用上的项目级 `disabled` 标记；引用
  与项目原生条目同级参与合并——MCP 挂载时遮蔽全局原版（启用态引用还会
  覆盖全局条目自身的 disabled 默认），快捷消息的全局原版被同名项目条目
  （原生或引用）遮蔽时标 `shadowed`，输入框弹层据此过滤。引用条目在项目
  区显示「全局」归属徽标，移除按钮为「移出」；项目内已有同名原生条目时
  报硬错误，已有同名引用时两击确认重登记（保留原启停状态）。旧版
  「导入 = 物理复制」写入的 `importedFromGlobal` 标记随读→写周期保留，
  这类副本同样显示「全局」徽标与「移出」按钮。

### 变更

- **配置文件位置改为 `.agents` 优先**：所有可写配置（项目级能力禁用声明、
  项目/全局快捷消息、全局 MCP、skills 安装目标）保存时优先写入 `.agents`
  目录（项目 `<项目根>/.agents/`，全局 `~/.agents/`）；读取兼容旧位置
  （项目 `.dsh` / `.claude`，全局 dsh home / `~/.claude`）。首次写入新位置
  时自动并入旧文件内容并删除旧文件，旧配置不丢失、不留两份。
- **Skills 只读兼容 `.claude/skills`**：项目与全局的 Claude Code 技能目录
  出现在面板中（只读徽标，不可写回）；skills 默认安装目标改为 `.agents`
  （项目）与 `~/.agents/skills`（全局）。
- **项目根判定标记新增 `.agents` 与 `.claude`**：与 `.git` / `.dsh` 同等
  参与 `findProjectRoot` 的向上探测（主目录护栏不变）。
- **三域详情卡移除「项目已启用 / 项目已禁用」覆写按钮**：项目级控制改用
  各域的导入制入口（skills = 物理副本 / 屏蔽占位，MCP / 快捷消息 = 引用
  启停）。`capability-overrides.json` 机制保留：MCP 弹层的「本项目」开关
  仍在使用；快捷消息域的既有声明仍被读取（弹层继续过滤），但面板不再
  提供开关入口（用引用启停替代）；skills 域声明不再读取。
- **代码重构**（行为不变）：三域头部 Tab 收敛为共用的 `ZoneTabs`
  （`scope-tabs.ts` 删除），`ProjectOverrideButton` 移除；skill 来源的
  项目/全局分类收敛到 `shared/skill-sources.ts`（宿主端与客户端共用）。

### 修复

- **Skills 项目区启停/调用方向现在真实生效**：此前「导入到本项目」登记的是
  引用（`capability-imports.json`），其启停状态只对插件面板可见——宿主的
  目录注入 / `skill` 工具 / `/name` 注入三条链路只读 skill 文件的
  frontmatter，而补偿用的注入守卫只能过滤**本步新注入**的消息，无法触及
  已持久化在会话里的旧目录消息，导致引用条目禁用后上下文仍始终注入。
  现在 skills 域彻底移除引用机制与注入守卫（`capability-imports.json` 里
  遗留的 skills 键读取时忽略、下次写盘自动清除），「导入到本项目」回归
  物理复制，启停与调用方向一律写项目副本的 frontmatter——由宿主的文件
  watcher + 目录重发布原生生效（实测下一步即剔除）。
- **MCP 多会话同名 server 冲突不再伪装成故障**：桥接层按 app（`ctx.root`）
  预留 `serverName`，同一 server 全应用只允许一个会话挂载，其余会话报
  `already in use` 属预期。此前面板按"最差状态"聚合（conflict 排最高），
  只要存在第二个会话，行上就永远显示「冲突」（删除后重加也一样），
  看起来像删除未生效。现在：
  - 聚合改为**任一会话已挂载即显示"已挂载"**，全部未挂载时才取最差状态；
  - 冲突状态的详情文案从桥接层的原始报错（误导性提示"pick a unique
    serverName in cordis.yml"）换成说明真实原因的中文说明。

## [0.8.0] - 2026-08-28

### 新增

- **项目级禁用全局能力**：全局的 skill / MCP server / 快捷消息默认对所有
  项目生效，现在可以在单个项目里关掉而不动全局配置。打开详情卡，点击
  **「项目已启用 / 项目已禁用」** 状态按钮（绿=生效，橙=禁用）即可。
  - 声明写入 `<项目根>/.dsh/capability-overrides.json`，全局配置原样保留，
    其他项目完全不受影响；
  - 效果真实生效：Skills / 快捷消息立刻从输入框弹层消失，MCP server 从
    本项目所有 session **热卸载**（恢复时自动重挂）。
- **MCP 快捷弹层改为「本项目」开关**：全局条目在弹层里只切换本项目
  启用/禁用（走项目级覆写，不翻全局配置）；全局已禁用的 server 不再列出。
- **输入框工具组三个弹层共享同一份列表数据**：按钮与弹层不再各拉一次
  同一份 RPC 数据（打开弹层时的重复请求被消除）。

### 变更

- **列表状态语义统一**：三个域的列表圆点统一为「绿=已启用 / 灰=已禁用 /
  橙=本项目禁用」；MCP 的挂载失败 / 冲突 / 未挂载改用行内标签与 tooltip
  呈现，详情卡「状态」字段保留完整挂载信息与错误，未再把挂载异常画进圆点。
- **代码重构**（行为不变）：
  - 输入框工具行三个弹层（快捷消息 / Skills / MCP）共用一套模块级开合
    存储 + Esc/外部点击关闭 + 锚点定位（`client/composer-common.ts`）；
  - 三个面板视图共用 `ScopeTabs` / `useAsyncList` / `ProjectOverrideButton`
    与工作区/来源判定小工具（`client/panel-common.tsx`）；
  - MCP 挂载状态按 key 聚合的"取最差"逻辑收敛到 `client/mcp-common.ts`；
  - JSON 配置文件读取脚手架、原子写入（临时文件 + rename）、错误文案
    归一收敛到 `shared/` 工具模块；file-lock 队列在 settle 后自动清理
    （长驻进程不再无界增长）；MCP 旧 fiber 改为并发释放。
- 详情卡项目级覆写按钮在**全局已禁用**时恒灰并禁用（本项目状态无意义）。

### 修复

- **安全：skill 名称路径穿越封堵**。`skills.read / remove / setEnabled /
  update / clone / export` 此前把 RPC 传入的 `name` 原样拼进文件路径
  （`join(root, name)`），恶意名称（如 `../x`）可越出受管根读写任意 `.md`
  文件；现在所有拼路径的入口强制 `isSkillName`（kebab-case）校验。
- **安全：ZIP 解压上限与越界防护**。宿主端与浏览器端解压均增加 64 MiB
  输出总量上限（对接入的压缩包上限之下再拦一层"膨胀内存"），并修复
  数据区越界被静默截断、短归档负面偏移读越界的问题（zip bomb 防护）。

[Unreleased]: https://github.com/chengdb/dsh-plugin-capability-panel/compare/v1.1.0...master
[1.1.0]: https://github.com/chengdb/dsh-plugin-capability-panel/compare/v1.0.2...v1.1.0
[1.0.2]: https://github.com/chengdb/dsh-plugin-capability-panel/compare/v1.0.1...v1.0.2
[1.0.1]: https://github.com/chengdb/dsh-plugin-capability-panel/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/chengdb/dsh-plugin-capability-panel/compare/v0.8.0...v1.0.0
[0.8.0]: https://github.com/chengdb/dsh-plugin-capability-panel/releases/tag/v0.8.0