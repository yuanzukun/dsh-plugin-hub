import { test } from 'node:test'
import assert from 'node:assert/strict'
import { apply, resolveConfig } from '../src/index.ts'

interface Listener {
  name: string
  callback: (...args: any[]) => any
  options: any
}

/** 最小 cordis Context 替身：记录监听器，手动派发。 */
function createContext() {
  const listeners: Listener[] = []
  const logs: string[] = []
  const ctx: any = {
    on(name: string, callback: (...args: any[]) => any, options?: any) {
      listeners.push({ name, callback, options })
      return () => {}
    },
    inject(_deps: string[], callback: (scoped: any) => void) {
      callback(ctx)
    },
    logger: {
      info: (...args: unknown[]) => logs.push(args.join(' ')),
      warn: (...args: unknown[]) => logs.push(args.join(' ')),
      error: (...args: unknown[]) => logs.push(args.join(' ')),
    },
  }
  return { ctx, listeners, logs }
}

/** 派发一个事件给所有监听器（模拟 cordis 的 emit/waterfall 注册表）。 */
async function fire(listeners: Listener[], name: string, ...args: any[]): Promise<any[]> {
  const targets = listeners.filter((listener) => listener.name === name)
  return Promise.all(targets.map((listener) => listener.callback(...args)))
}

interface AgentCall {
  kind: 'steer' | 'cancel'
  arg?: any
  options?: any
}

function createAgent(id = 'session-1') {
  const calls: AgentCall[] = []
  const agent = {
    id,
    steer(message: any) {
      calls.push({ kind: 'steer', arg: message })
    },
    cancel(cause: any, options?: any) {
      calls.push({ kind: 'cancel', arg: cause, options })
    },
  }
  return { agent, calls }
}

/** 逐片喂入流式文本（每片 8 字符，配合 minLen=64 正好每 8 片触发一轮检测）。 */
async function feed(listeners: Listener[], agent: object, times: number, text: string): Promise<void> {
  for (let i = 0; i < times; i++) {
    await fire(listeners, 'agent/assistant-stream', {
      agent,
      frame: { type: 'chunk', index: i, chunk: { type: 'text-delta', index: 0, text } },
    })
  }
}

const cancelCalls = (calls: AgentCall[]) => calls.filter((call) => call.kind === 'cancel')
const steerCalls = (calls: AgentCall[]) => calls.filter((call) => call.kind === 'steer')

test('配置校验：非法 action 明确报错', () => {
  assert.throws(() => resolveConfig({ action: 'kill' }), /action/)
  assert.throws(() => resolveConfig({ minLen: 0 }), /minLen/)
  assert.throws(() => resolveConfig({ noveltyThreshold: 2 }), /noveltyThreshold/)
})

test('配置校验：默认值可用，旧字段名保持兼容', () => {
  const settings = resolveConfig({ minLen: 256, maxRetries: 2, checkReasoning: false })
  assert.equal(settings.minLen, 256)
  assert.equal(settings.maxRetries, 2)
  assert.equal(settings.checkReasoning, false)
  assert.equal(settings.action, 'steer')
  assert.deepEqual(settings.intent.toolPatterns, ['web_search'])
})

test('监听的是新版 agent/assistant-stream，且显式声明全局接收', () => {
  const { ctx, listeners } = createContext()
  apply(ctx, {})
  const stream = listeners.find((listener) => listener.name === 'agent/assistant-stream')
  assert.ok(stream, '应当监听 agent/assistant-stream')
  assert.equal(stream.options?.global, true, 'agent 作用域事件必须用 { global: true } 才能观测所有 agent')
  assert.ok(listeners.some((listener) => listener.name === 'agent/pre-step'))
  assert.ok(listeners.some((listener) => listener.name === 'tools/post-execute'))
  // 默认不再依赖已废弃的 session/event 通道
  assert.equal(listeners.some((listener) => listener.name === 'session/event'), false)
})

test('文本死循环：第一次真正打断并引导，重试耗尽后强制中止', async () => {
  const { ctx, listeners } = createContext()
  apply(ctx, { minLen: 64, checkEvery: 1, cooldownMs: 0, maxRetries: 1 })
  const { agent, calls } = createAgent()

  await feed(listeners, agent, 8, 'abcdefgh') // 64 字符 = 8 周期 x8 → 命中

  assert.equal(cancelCalls(calls).length, 1, '应当打断一次')
  assert.equal(cancelCalls(calls)[0]!.options?.keepInbox, true, '打断时必须保留收件箱，引导消息才有落点')
  assert.equal(steerCalls(calls).length, 1, '应当注入一条引导消息')
  assert.match(steerCalls(calls)[0]!.arg.content[0].text, /loop-detector/)
  assert.equal(steerCalls(calls)[0]!.arg.role, 'user')

  await feed(listeners, agent, 8, 'abcdefgh') // 再次循环 → 重试已耗尽

  assert.equal(cancelCalls(calls).length, 2)
  assert.equal(cancelCalls(calls)[1]!.options, undefined, '重试耗尽后应当彻底中止（默认清空收件箱）')
  assert.equal(steerCalls(calls).length, 1, '不该再引导')
})

test('action=cancel 时直接中止，不做引导', async () => {
  const { ctx, listeners } = createContext()
  apply(ctx, { minLen: 64, checkEvery: 1, cooldownMs: 0, action: 'cancel' })
  const { agent, calls } = createAgent()

  await feed(listeners, agent, 8, 'abcdefgh')

  assert.equal(cancelCalls(calls).length, 1)
  assert.equal(cancelCalls(calls)[0]!.options, undefined)
  assert.equal(steerCalls(calls).length, 0)
})

test('真实用户输入让计数归零；我们自己注入的引导消息不算用户输入', async () => {
  const { ctx, listeners } = createContext()
  apply(ctx, { minLen: 64, checkEvery: 1, cooldownMs: 0, maxRetries: 1 })
  const { agent, calls } = createAgent()

  await feed(listeners, agent, 8, 'abcdefgh')
  const guided = steerCalls(calls)[0]!.arg
  const next = async () => ({ kind: 'enter', messages: [] })

  // pre-step 收到的是我们自己刚注入的引导消息 → 不应当重置
  await fire(listeners, 'agent/pre-step', { agent, messages: [guided] }, next)
  await feed(listeners, agent, 8, 'abcdefgh')
  assert.equal(cancelCalls(calls).length, 2, '注入的消息不该重置计数（否则重试永远耗不尽）')
  assert.equal(steerCalls(calls).length, 1)

  // 真正的用户输入 → 重置，下一次循环重新走"打断 + 引导"
  await fire(listeners, 'agent/pre-step', { agent, messages: [{ id: 'user-1', source: { kind: 'user' } }] }, next)
  await feed(listeners, agent, 8, 'abcdefgh')
  assert.equal(steerCalls(calls).length, 2, '新用户输入后应当重新引导')
})

test('思考内容默认也检测，可关闭', async () => {
  const withReasoning = createContext()
  apply(withReasoning.ctx, { minLen: 64, checkEvery: 1, cooldownMs: 0 })
  const first = createAgent('a')
  for (let i = 0; i < 8; i++) {
    await fire(withReasoning.listeners, 'agent/assistant-stream', {
      agent: first.agent,
      frame: { type: 'chunk', chunk: { type: 'reasoning-delta', text: 'abcdefgh' } },
    })
  }
  assert.equal(cancelCalls(first.calls).length, 1, 'reasoning-delta 默认参与检测')

  const withoutReasoning = createContext()
  apply(withoutReasoning.ctx, { minLen: 64, checkEvery: 1, cooldownMs: 0, checkReasoning: false })
  const second = createAgent('b')
  for (let i = 0; i < 8; i++) {
    await fire(withoutReasoning.listeners, 'agent/assistant-stream', {
      agent: second.agent,
      frame: { type: 'chunk', chunk: { type: 'reasoning-delta', text: 'abcdefgh' } },
    })
  }
  assert.equal(cancelCalls(second.calls).length, 0, '关闭后不再检测思考内容')
})

test('分片形状不认识时安静跳过，不抛错', async () => {
  const { ctx, listeners, logs } = createContext()
  apply(ctx, { minLen: 64, checkEvery: 1 })
  const { agent, calls } = createAgent()

  await fire(listeners, 'agent/assistant-stream', null)
  await fire(listeners, 'agent/assistant-stream', { agent })
  await fire(listeners, 'agent/assistant-stream', { agent, frame: { type: 'start' } })
  await fire(listeners, 'agent/assistant-stream', { agent, frame: { type: 'chunk', chunk: null } })
  await fire(listeners, 'agent/assistant-stream', { agent, frame: { type: 'chunk', chunk: { type: 'text-delta' } } })

  assert.equal(calls.length, 0)
  assert.equal(logs.length, 0, '未知分片不该产生告警噪声')
})

test('工具意图级重复：换措辞重搜两次后打断', async () => {
  const { ctx, listeners } = createContext()
  apply(ctx, { minLen: 1_000_000, toolPatterns: ['web_search'], cooldownMs: 0 })
  const { agent, calls } = createAgent()
  const next = async () => ({ kind: 'accept' })

  const search = (query: string) =>
    fire(listeners, 'tools/post-execute', { agent, name: 'web_search', arguments: { query } }, {}, next)

  await search('北京 天气 预报')
  await search('北京天气预报怎么样')
  assert.equal(calls.length, 0, '前两次不该打断')

  await search('查询北京天气预报')
  assert.equal(cancelCalls(calls).length, 1, '连续无新信息应当打断')
  assert.equal(cancelCalls(calls)[0]!.options?.keepInbox, true)
  assert.match(steerCalls(calls)[0]!.arg.content[0].text, /web_search/)
})

test('工具意图级重复：未纳入 toolPatterns 的工具不参与', async () => {
  const { ctx, listeners } = createContext()
  apply(ctx, { minLen: 1_000_000, toolPatterns: ['grep*'], cooldownMs: 0 })
  const { agent, calls } = createAgent()
  const next = async () => ({ kind: 'accept' })

  for (const query of ['北京 天气 预报', '北京天气预报怎么样', '查询北京天气预报']) {
    await fire(listeners, 'tools/post-execute', { agent, name: 'web_search', arguments: { query } }, {}, next)
  }
  assert.equal(calls.length, 0)
})

test('toolPatterns 为空数组时关闭意图级检测', () => {
  const { ctx, listeners } = createContext()
  apply(ctx, { toolPatterns: [] })
  assert.equal(listeners.some((listener) => listener.name === 'tools/post-execute'), false)
})

test('legacySessionEvents 打开后才挂载旧通道', () => {
  const { ctx, listeners } = createContext()
  apply(ctx, { legacySessionEvents: true })
  assert.ok(listeners.some((listener) => listener.name === 'session/event'))
})

test('冷却期内不重复触发', async () => {
  const { ctx, listeners } = createContext()
  apply(ctx, { minLen: 64, checkEvery: 1, cooldownMs: 60_000 })
  const { agent, calls } = createAgent()

  await feed(listeners, agent, 8, 'abcdefgh')
  await feed(listeners, agent, 8, 'abcdefgh')
  assert.equal(cancelCalls(calls).length, 1, '冷却期内不该再次打断')
})
