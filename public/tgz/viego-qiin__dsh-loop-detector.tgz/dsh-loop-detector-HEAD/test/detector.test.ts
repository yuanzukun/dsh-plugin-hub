import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  detectAnchor,
  detectNgram,
  detectPeriodic,
  detectRepetition,
  resolveDetectorOptions,
} from '../src/detector.ts'

const WORDS = ['alpha', 'bravo', 'charlie', 'delta', 'echo', 'foxtrot', 'golf', 'hotel']

/** 构造一段有变化（非周期）的长文本，用于锚段测试。 */
function variedText(rounds: number): string {
  let out = ''
  for (let i = 0; i < rounds; i++) out += `${i} ${WORDS[i % WORDS.length]} `
  return out
}

test('周期重复（英文）命中，并报出周期长度', () => {
  const hit = detectPeriodic('abcdefgh'.repeat(20))
  assert.ok(hit)
  assert.equal(hit.kind, 'periodic')
  assert.match(hit.detail, /period=8/)
})

test('周期重复（中文句子）命中', () => {
  const hit = detectPeriodic('这是一段重复的测试文本。'.repeat(12))
  assert.ok(hit, '中文整句重复应当被判定为周期循环')
})

test('重复的代码行属于真循环', () => {
  const line = '  console.log(values[index])\n'
  assert.ok(detectPeriodic(line.repeat(20)))
})

test('纯符号重复不误报（分隔线、涂抹）', () => {
  assert.equal(detectPeriodic('-'.repeat(200)), null)
  assert.equal(detectPeriodic('|:---|:---|'.repeat(20)), null)
  assert.equal(detectPeriodic('='.repeat(400)), null)
  assert.equal(detectRepetition('--------'.repeat(60)), null)
})

test('结构不同但重复的散文不误报', () => {
  const text =
    '在软件工程中，重复代码是一种常见的坏味道。' +
    '它让修改一处逻辑需要同时改动多个位置，也让阅读者难以判断哪一份才是权威实现。' +
    '更麻烦的是，重复往往随时间漂移，两份副本渐渐产生细微差异，缺陷就藏在这些差异里。' +
    '因此重构时常先提取公共函数，再用小步验证确保行为不变。' +
    '不过抽象本身也有成本：过早抽象会让代码难以理解。'
  assert.equal(detectRepetition(text), null)
})

test('短文本直接跳过', () => {
  assert.equal(detectRepetition('abc'), null)
  assert.equal(detectRepetition('abcdefgh'.repeat(3)), null)
})

test('n-gram：同一 64 字符块出现三次命中', () => {
  // 块必须明显长于 64 字符，块内部才会存在多个完全一致的 64 字符窗口
  const block = 'The quick brown fox jumps over the lazy dog while reading the documentation carefully.'
  const text = [block, '间隔一', block, '间隔二', block].join('\n')
  const options = resolveDetectorOptions({ ngramStep: 1 })
  const hit = detectNgram(text, options)
  assert.ok(hit)
  assert.equal(hit.kind, 'ngram')
})

test('n-gram：块只出现两次不命中', () => {
  const block = 'The quick brown fox jumps over the lazy dog while reading the documentation carefully.'
  const text = [block, '间隔一', block].join('\n')
  assert.equal(detectNgram(text, resolveDetectorOptions({ ngramStep: 1 })), null)
})

test('锚段：整段重复两遍命中', () => {
  const segment = variedText(60)
  assert.ok(segment.length > 512, '构造的段落应当长于锚段长度')
  const hit = detectAnchor(`${segment}中间插一句完全不同的话。${segment}`)
  assert.ok(hit)
  assert.equal(hit.kind, 'anchor')
})

test('锚段：内容各不相同不命中', () => {
  assert.equal(detectAnchor(variedText(60)), null)
})

test('resolveDetectorOptions 夹取自相矛盾的取值', () => {
  const options = resolveDetectorOptions({ minPeriod: 300, maxPeriod: 100, periodRepeats: 1, ngramStep: 0, minDistinctChars: 0 })
  assert.equal(options.maxPeriod, 300, 'maxPeriod 低于 minPeriod 时应当抬到 minPeriod')
  assert.equal(options.periodRepeats, 2, '重复次数至少为 2')
  assert.equal(options.ngramStep, 1, '步长至少为 1')
  assert.equal(options.minDistinctChars, 0, '显式传入的合法值应当保留')
})
