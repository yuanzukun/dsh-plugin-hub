import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  DEFAULT_INTENT,
  IntentTracker,
  extractKeywords,
  extractQueryText,
  matchesTool,
  resolveIntentOptions,
} from '../src/intent.ts'

test('中文关键词按 bigram 提取（旧实现会退化成整句单个 token）', () => {
  const tokens = extractKeywords('北京天气预报')
  assert.ok(tokens.has('北京'))
  assert.ok(tokens.has('天气'))
  assert.ok(tokens.has('预报'))
  assert.ok(tokens.size >= 5)
})

test('英文按词提取，忽略单字符', () => {
  const tokens = extractKeywords('DeepSeek Harness a plugin')
  assert.ok(tokens.has('deepseek'))
  assert.ok(tokens.has('harness'))
  assert.ok(tokens.has('plugin'))
  assert.equal(tokens.has('a'), false)
})

test('中文换措辞重问同一件事：连续两次后命中', () => {
  const tracker = new IntentTracker(DEFAULT_INTENT)
  assert.equal(tracker.observe('北京 天气 预报').repeat, false)
  assert.equal(tracker.observe('北京天气预报怎么样').repeat, false, '第一次相似应当只计停滞')
  assert.equal(tracker.observe('查询北京天气预报').repeat, true, '连续两次无新信息应当判定为意图级循环')
})

test('换了主题不误报', () => {
  const tracker = new IntentTracker(DEFAULT_INTENT)
  tracker.observe('北京 天气 预报')
  assert.equal(tracker.observe('上海 房价 走势 分析').repeat, false)
  assert.equal(tracker.observe('rust 所有权 生命周期').repeat, false)
})

test('带新维度的追问不误报（连续 7 次不同方向）', () => {
  const tracker = new IntentTracker(DEFAULT_INTENT)
  const queries = [
    '北京 天气 预报',
    '北京 空气质量 指数',
    '北京 地铁 线路 规划',
    '北京 高校 排名 计算机',
    '北京 房价 走势 2026',
    '北京 落户 政策 条件',
    '北京 医院 挂号 流程',
  ]
  for (const query of queries) {
    assert.equal(tracker.observe(query).repeat, false, `不该因换维度而误判: ${query}`)
  }
})

test('英文同主题换措辞命中', () => {
  const tracker = new IntentTracker(DEFAULT_INTENT)
  tracker.observe('deepseek harness plugin api')
  assert.equal(tracker.observe('deepseek harness plugin architecture').repeat, false)
  assert.equal(tracker.observe('deepseek harness plugin api design').repeat, true)
})

test('英文引入新维度不误报', () => {
  const tracker = new IntentTracker(DEFAULT_INTENT)
  tracker.observe('deepseek harness plugin api')
  tracker.observe('deepseek harness plugin architecture')
  assert.equal(tracker.observe('deepseek harness plugin interface design').repeat, false)
})

test('reset 之后重新计数', () => {
  const tracker = new IntentTracker(DEFAULT_INTENT)
  tracker.observe('北京 天气 预报')
  tracker.observe('北京天气预报怎么样')
  tracker.reset()
  assert.equal(tracker.observe('查询北京天气预报').repeat, false, 'reset 后不该立刻命中')
})

test('工具名通配符匹配', () => {
  assert.ok(matchesTool('web_search', ['web_search']))
  assert.ok(matchesTool('mcp__tavily__search', ['mcp__*']))
  assert.ok(matchesTool('any_tool', ['*']))
  assert.equal(matchesTool('read', ['web_search']), false)
  assert.equal(matchesTool('read', []), false, '空模式表表示关闭')
})

test('从工具参数里抽取比对文本', () => {
  assert.match(extractQueryText({ query: 'hello world' }), /hello world/)
  assert.match(extractQueryText({ options: { pattern: 'needle' }, list: ['haystack'] }), /needle/)
  assert.match(extractQueryText({ nested: { deeper: { value: 'value' } } }), /value/)
  assert.equal(extractQueryText({ count: 3, ok: true }), '')
  assert.equal(extractQueryText(undefined), '')
})

test('resolveIntentOptions 只接受合法覆盖', () => {
  const options = resolveIntentOptions({
    toolPatterns: ['grep', 'web_search'],
    historySize: 5,
    noveltyThreshold: 0.4,
    similarityThreshold: 0.7,
    stallLimit: 3,
  })
  assert.deepEqual(options.toolPatterns, ['grep', 'web_search'])
  assert.equal(options.historySize, 5)
  assert.equal(options.noveltyThreshold, 0.4)
  assert.equal(options.similarityThreshold, 0.7)
  assert.equal(options.stallLimit, 3)
})
