/**
 * 用真实的 cordis Context 与 dsh-agent 的作用域派发器验证插件接线，
 * 而不是自造的替身——这是防住"API 又变了"这一风险的关键一层。
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { Context } from '@deepseek-ai/cordis'
import { agentEvents } from '@deepseek-ai/dsh-agent'
import { apply } from '../src/index.ts'

interface AgentCall {
  kind: 'steer' | 'cancel'
  arg?: any
  options?: any
}

function createAgent(id: string) {
  const calls: AgentCall[] = []
  const agent: any = {
    id,
    steer(message: any) {
      calls.push({ kind: 'steer', arg: message })
    },
    cancel(cause: any, options?: any) {
      calls.push({ kind: 'cancel', arg: cause, options })
    },
  }
  return { agent, calls }
}

test('真实 cordis：插件注册后能收到 agent/assistant-stream 并在循环时打断', () => {
  const ctx = new Context()
  apply(ctx as any, { minLen: 64, checkEvery: 1, cooldownMs: 0, maxRetries: 1 })
  const { agent, calls } = createAgent('real-1')

  for (let i = 0; i < 8; i++) {
    ctx.emit('agent/assistant-stream', {
      agent,
      frame: { type: 'chunk', index: i, chunk: { type: 'text-delta', index: 0, text: 'abcdefgh' } },
    })
  }

  const cancels = calls.filter((call) => call.kind === 'cancel')
  assert.equal(cancels.length, 1, '应当通过真实 cordis 派发命中一次')
  assert.equal(cancels[0]!.options?.keepInbox, true)
  assert.equal(calls.filter((call) => call.kind === 'steer').length, 1)
})

test('真实 dsh-agent 作用域派发（带 scope carrier）同样能命中', () => {
  const ctx = new Context()
  apply(ctx as any, { minLen: 64, checkEvery: 1, cooldownMs: 0, maxRetries: 1 })
  const { agent, calls } = createAgent('real-2')
  const dispatcher = agentEvents(ctx as any, agent)

  for (let i = 0; i < 8; i++) {
    dispatcher.emit('agent/assistant-stream', {
      frame: { type: 'chunk', index: i, chunk: { type: 'text-delta', index: 0, text: 'abcdefgh' } },
    })
  }

  assert.equal(calls.filter((call) => call.kind === 'cancel').length, 1)
})

test('真实 cordis：waterfall 事件（agent/pre-step）不会被打断', async () => {
  const ctx = new Context()
  apply(ctx as any, { minLen: 64, checkEvery: 1, cooldownMs: 0 })
  const { agent, calls } = createAgent('real-3')

  const result = await (ctx as any).waterfall(
    'agent/pre-step',
    { agent, messages: [{ id: 'user-1', source: { kind: 'user' } }] },
    async () => ({ kind: 'enter', messages: [] }),
  )

  assert.deepEqual(result, { kind: 'enter', messages: [] }, '必须原样返回下游决策，不能干扰准入')
  assert.equal(calls.length, 0)
})

test('真实 cordis：tools/post-execute waterfall 原样返回下游决策', async () => {
  const ctx = new Context()
  apply(ctx as any, { minLen: 1_000_000, toolPatterns: ['web_search'], cooldownMs: 0 })
  const { agent, calls } = createAgent('real-4')
  const downstream = { kind: 'accept' }

  for (const query of ['北京 天气 预报', '北京天气预报怎么样', '查询北京天气预报']) {
    const result = await (ctx as any).waterfall(
      'tools/post-execute',
      { agent, name: 'web_search', arguments: { query } },
      {},
      async () => downstream,
    )
    assert.deepEqual(result, downstream, '不能改写工具决策')
  }

  assert.equal(calls.filter((call) => call.kind === 'cancel').length, 1, '连续同主题应当打断')
})
