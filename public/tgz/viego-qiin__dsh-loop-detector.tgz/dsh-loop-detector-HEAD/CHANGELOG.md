# 变更记录 / Changelog

## [2.0.0] - 2026-10-13

适配 dsh 0.2.x，并修掉 v1 在**新版本上完全失效**与**中文场景失效**两类问题。

### 破坏性变更（为什么必须升级）

- **事件源迁移**：v1 监听 `session/event` 的 `assistant/chunk`。在 dsh 0.2.x 的 v2 会话事件模型里，
  `assistant/chunk` 已不再是实时事件（只存在于旧格式迁移包中），改为监听
  **`agent/assistant-stream`**。这是 v1 在新版 dsh 上"装了却从不触发"的根因。
  *旧版 dsh 可通过 `legacySessionEvents: true` 找回 v1 通道（默认关闭）。*
- **硬中断真正生效**：新版 `agent.steer()` 在 agent 正在生成时**不会**中止当前这次生成，只是把消息
  排进下一步——模型仍会把整段循环文本吐完。现在改为
  `agent.cancel({kind:'hook',reason}, {keepInbox:true})` **先掐断**，再 `steer()` 投递引导消息。
- **计数重置时机修正**：v1 在 `turn/end` 归零计数，而 steer 每次都会开新 turn，导致重试次数永远
  耗不尽、`maxRetries` 形同虚设。现在由**真实用户输入**（`agent/pre-step` 且消息不是本插件注入的）
  归零；本插件注入的消息用 id 记录并排除。
- **意图级检测的挂载点**：`tools/execute` → `tools/post-execute`（被拒绝的调用同样计入，与官方
  guard 的计数位置一致），并原样透传下游决策。
- **配置改为 schemastery schema**（导出 `Config`），非法值启动即报错。

### Added

- **中文关键词提取**：v1 按非字母数字切词，一整句中文退化成单个 token，中文场景的"换措辞重搜"
  永远判不出来。现在用"停用字切分 + 中文 bigram"，并加入 Jaccard 相似度作为第二判据
  （`similarityThreshold`）。
- **工具范围可配**：`toolPatterns` 支持 `*` 通配符，可让 grep/bash 等任意工具参与意图级检测。
- **抗误报**：重复块需含 ≥ `minDistinctChars` 种字符且实义字符占比 ≥ `minSubstantiveRatio`，
  分隔线（`--------`、`|:---|:---|`）与排版噪声不再误判为死循环。
- **节流与有界缓冲**：`checkEvery` 控制每新增多少字符才跑一次检测（省 CPU），`bufferLimit`
  限制每个流保留的尾部长度（防长输出下内存与耗时增长）。
- **冷却期**：`cooldownMs` 避免中止过程中的残余分片连环触发。
- **可关闭正文/思考检测**：`checkText` / `checkReasoning`；`action: 'cancel'` 可直接中止不引导。
- **39 项离线测试**（`npm test`，node --test 原生跑 `.ts`），其中 4 项用**真实 cordis Context 与
  dsh-agent 作用域派发器**验证接线，防住"API 又变了"。
- 代码拆分：`src/detector.ts`（纯函数检测器）、`src/intent.ts`（意图级状态机），均可单独测试。
- **`dsh.bundle` 声明**：包自带 `dsh.bundle.patch`（指向 `cordis.patch.yml`，即自挂载 patch）。
  把包名加进 profile 的 `dsh.profile.bundles` 后，插件会出现在 GUI 的「已安装」列表里，
  并可用那里的开关启停。此前只往 profile 的 `cordis.patch.yml` 塞一条 insert——插件能跑，
  但**插件页看不到、也没法开关**，因为那个列表读的就是 `dsh.profile.bundles`。

### Changed

- 依赖与加载方式对齐 dsh 0.2.x：`engines.node >= 22.18`（原生 TypeScript 类型剥离）；
  运行时依赖（cordis / dsh-agent / dsh-llm / dsh-tools / **schemastery**）全部改为
  **peerDependencies**——dsh 的 profile 解析器只把出现在 `peerDependencies` 里的包名
  路由到 dsh 自带的安装副本，写进 `dependencies` 会让 `link:` 插件在解析阶段直接失败。
- README 双语文档重写，补充"为什么 v1 在新版不工作"、迁移说明与依赖解析约定。

## [1.0.0] - 2026-08-15

### Added
- 文本级死循环检测（周期扫描 8-256 / n-gram 64 块×3 / 大段锚段 512 扩展），监听 `assistant/chunk`（text-delta + reasoning-delta）。
- 工具调用意图级重复检测：监听 `tools/execute` 的 `web_search`，新词占比 <25% 连续 2 次判定"换措辞重搜同一主题"，steer/cancel 硬中断。
- 硬中断机制：`agent.steer()` 自动重试（`maxRetries` 可配置），耗尽后 `agent.cancel()` 强制中止；`turn/end` 自动重置计数。
- 双语文档（README.md / README.zh.md），MIT 协议。

### Published
- **v1.0.0 发布到 npm registry**（`dsh plugin --profile web add dsh-loop-detector` 可直接安装）。
- 推送到 GitHub：https://github.com/viego-qiin/dsh-loop-detector
