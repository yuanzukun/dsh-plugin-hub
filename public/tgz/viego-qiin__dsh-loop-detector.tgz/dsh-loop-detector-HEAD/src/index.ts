/**
 * dsh-loop-detector — DeepSeek Harness (dsh) 死循环 / 重复输出硬中断插件
 *
 * 面向 dsh 0.2.x：实时流监听走 `agent/assistant-stream`（旧的
 * `session/event` + `assistant/chunk` 已不再是 v2 会话事件，仅在
 * `legacySessionEvents: true` 时为旧版 dsh 保留一条兼容通道）。
 *
 * 检测：
 *   1. 文本级（正文本 + 可选思考）：三层重复检测，见 ./detector.ts
 *   2. 工具调用意图级：换措辞反复做同一件事，见 ./intent.ts
 *
 * 打断（关键区别）：
 *   新版 `agent.steer()` 在 agent 正在生成时**不会**中止当前这次生成——它只是把
 *   消息排进下一步。所以"硬中断"必须两步走：
 *       agent.cancel({ kind: 'hook', reason }, { keepInbox: true })   // 真正掐断当前流
 *       agent.steer(引导消息)                                          // 让模型立刻重来
 *   重试次数耗尽后改为单纯 cancel（默认清空收件箱），彻底停下来。
 *
 * 计数重置：由**真实用户输入**触发（`agent/pre-step` 里 source.kind === 'user'
 * 且不是本插件注入的消息），而不是 `turn/end`——否则我们自己的 steer 每次开新
 * turn 都会把计数清零，maxRetries 永远耗不尽。
 */

import z from '@deepseek-ai/schemastery'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { DEFAULT_DETECTOR, detectRepetition, resolveDetectorOptions, type DetectorOptions, type LoopHit } from './detector.ts'
import {
  DEFAULT_INTENT,
  IntentTracker,
  extractQueryText,
  matchesTool,
  resolveIntentOptions,
  type IntentOptions,
} from './intent.ts'

export const name = 'loop-detector'

export interface Config {
  /** 输出达到多少字符后才开始检测（防短文本误判）。默认 512 */
  minLen?: number
  /** 命中后 steer 引导重试几次；耗尽仍循环则强制中止。默认 1 */
  maxRetries?: number
  /** 命中时的动作：'steer' = 打断并引导重试（耗尽后中止）；'cancel' = 直接中止。默认 'steer' */
  action?: string
  /** 是否检测正文本（text-delta）。默认 true */
  checkText?: boolean
  /** 是否检测思考内容（reasoning-delta）。默认 true */
  checkReasoning?: boolean
  /** 每新增多少字符才跑一次检测（节流，防长输出下的重复全量扫描）。默认 64 */
  checkEvery?: number
  /** 每个流保留的尾部字符数（防缓冲无限增长）。默认 16384 */
  bufferLimit?: number
  /** 命中后的冷却时间（毫秒），避免中止过程中的残余分片连环触发。默认 1500 */
  cooldownMs?: number
  /** 旧版 dsh 兼容通道：监听 `session/event` 的 `assistant/chunk`。默认 false */
  legacySessionEvents?: boolean
  /** 工具名通配符；空数组关闭意图级检测。默认 ['web_search'] */
  toolPatterns?: string[]
  /** "主题词集"取最近几次调用。默认 3 */
  historySize?: number
  /** 新词占比低于该值算"没有新信息"。默认 0.25 */
  noveltyThreshold?: number
  /** 与主题词集的相似度高于该值也算"同一主题"（中文换措辞场景）。默认 0.5 */
  similarityThreshold?: number
  /** 连续几次"没有新信息"才判定为意图级循环。默认 2 */
  stallLimit?: number
  // ── 文本检测器参数（详见 detector.ts）────────────────────────────────
  minPeriod?: number
  maxPeriod?: number
  periodRepeats?: number
  ngramSize?: number
  ngramRepeats?: number
  ngramWindow?: number
  ngramStep?: number
  anchorSize?: number
  anchorWindow?: number
  minDistinctChars?: number
  minSubstantiveRatio?: number
}

export const Config = z.object({
  minLen: z.number().default(512),
  maxRetries: z.number().default(1),
  action: z.string().default('steer'),
  checkText: z.boolean().default(true),
  checkReasoning: z.boolean().default(true),
  checkEvery: z.number().default(64),
  bufferLimit: z.number().default(16384),
  cooldownMs: z.number().default(1500),
  legacySessionEvents: z.boolean().default(false),
  toolPatterns: z.array(z.string()).default(['web_search']),
  historySize: z.number().default(3),
  noveltyThreshold: z.number().default(0.25),
  similarityThreshold: z.number().default(DEFAULT_INTENT.similarityThreshold),
  stallLimit: z.number().default(2),
  minPeriod: z.number().default(DEFAULT_DETECTOR.minPeriod),
  maxPeriod: z.number().default(DEFAULT_DETECTOR.maxPeriod),
  periodRepeats: z.number().default(DEFAULT_DETECTOR.periodRepeats),
  ngramSize: z.number().default(DEFAULT_DETECTOR.ngramSize),
  ngramRepeats: z.number().default(DEFAULT_DETECTOR.ngramRepeats),
  ngramWindow: z.number().default(DEFAULT_DETECTOR.ngramWindow),
  ngramStep: z.number().default(DEFAULT_DETECTOR.ngramStep),
  anchorSize: z.number().default(DEFAULT_DETECTOR.anchorSize),
  anchorWindow: z.number().default(DEFAULT_DETECTOR.anchorWindow),
  minDistinctChars: z.number().default(DEFAULT_DETECTOR.minDistinctChars),
  minSubstantiveRatio: z.number().default(DEFAULT_DETECTOR.minSubstantiveRatio),
})

/** 规范化后的运行配置。 */
export interface ResolvedConfig {
  minLen: number
  maxRetries: number
  action: 'steer' | 'cancel'
  checkText: boolean
  checkReasoning: boolean
  checkEvery: number
  bufferLimit: number
  cooldownMs: number
  legacySessionEvents: boolean
  detector: DetectorOptions
  intent: IntentOptions
}

const DEFAULTS = {
  minLen: 512,
  maxRetries: 1,
  action: 'steer',
  checkText: true,
  checkReasoning: true,
  checkEvery: 64,
  bufferLimit: 16384,
  cooldownMs: 1500,
  legacySessionEvents: false,
}

/**
 * 合并默认值与用户配置，并对非法值**明确报错**（与官方 guard 一致的 fail-loud 约定），
 * 而不是静默回落——配置写错时用户应当立刻看见。
 */
export function resolveConfig(raw: Config = {}): ResolvedConfig {
  const minLen = pickNumber(raw.minLen, DEFAULTS.minLen, 'minLen', 1)
  const maxRetries = pickNumber(raw.maxRetries, DEFAULTS.maxRetries, 'maxRetries', 0)
  const checkEvery = pickNumber(raw.checkEvery, DEFAULTS.checkEvery, 'checkEvery', 1)
  const bufferLimit = pickNumber(raw.bufferLimit, DEFAULTS.bufferLimit, 'bufferLimit', 256)
  const cooldownMs = pickNumber(raw.cooldownMs, DEFAULTS.cooldownMs, 'cooldownMs', 0)

  const action = raw.action ?? DEFAULTS.action
  if (action !== 'steer' && action !== 'cancel') {
    throw new Error(`loop-detector: 非法 action "${String(action)}"，只能是 'steer' 或 'cancel'`)
  }

  const detector = resolveDetectorOptions({
    minPeriod: raw.minPeriod as number,
    maxPeriod: raw.maxPeriod as number,
    periodRepeats: raw.periodRepeats as number,
    ngramSize: raw.ngramSize as number,
    ngramRepeats: raw.ngramRepeats as number,
    ngramWindow: raw.ngramWindow as number,
    ngramStep: raw.ngramStep as number,
    anchorSize: raw.anchorSize as number,
    anchorWindow: raw.anchorWindow as number,
    minDistinctChars: raw.minDistinctChars as number,
    minSubstantiveRatio: pickRatio(raw.minSubstantiveRatio, DEFAULT_DETECTOR.minSubstantiveRatio, 'minSubstantiveRatio'),
  })

  const intent = resolveIntentOptions({
    toolPatterns: raw.toolPatterns ?? DEFAULT_INTENT.toolPatterns,
    historySize: raw.historySize as number,
    noveltyThreshold: pickRatio(raw.noveltyThreshold, DEFAULT_INTENT.noveltyThreshold, 'noveltyThreshold'),
    similarityThreshold: pickRatio(raw.similarityThreshold, DEFAULT_INTENT.similarityThreshold, 'similarityThreshold'),
    stallLimit: raw.stallLimit as number,
  })

  return {
    minLen,
    maxRetries,
    action,
    checkText: raw.checkText ?? DEFAULTS.checkText,
    checkReasoning: raw.checkReasoning ?? DEFAULTS.checkReasoning,
    checkEvery,
    bufferLimit,
    cooldownMs,
    legacySessionEvents: raw.legacySessionEvents ?? DEFAULTS.legacySessionEvents,
    detector,
    intent,
  }
}

function pickNumber(value: unknown, fallback: number, field: string, min: number): number {
  if (value === undefined || value === null) return fallback
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw new Error(`loop-detector: ${field} 必须是数字，收到 ${typeof value}`)
  }
  if (value < min) throw new Error(`loop-detector: ${field} 必须 >= ${min}，收到 ${value}`)
  return value
}

/** 校验 [0, 1] 区间的比例型配置。 */
function pickRatio(value: unknown, fallback: number, field: string): number {
  if (value === undefined || value === null) return fallback
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 1) {
    throw new Error(`loop-detector: ${field} 必须落在 [0, 1]，收到 ${String(value)}`)
  }
  return value
}

/** 插件只需要 agent 的这三个能力；其余交给运行时。 */
interface AgentLike {
  id: string
  steer(message: unknown): void
  cancel(cause: unknown, options?: unknown): void
}

/** 最小上下文接口（结构兼容 cordis Context）。 */
export interface PluginContext {
  on(name: string, listener: (...args: any[]) => any, options?: { global?: boolean }): unknown
  inject(deps: string[], callback: (ctx: any) => void): unknown
  logger: {
    info(...args: unknown[]): void
    warn(...args: unknown[]): void
    error(...args: unknown[]): void
  }
}

/** 一条流（正文或思考）的尾部缓冲。 */
interface Stream {
  value: string
  checked: number
}

interface AgentState {
  text: Stream
  reasoning: Stream
  /** 本回合内已命中的次数（真实用户输入时归零） */
  hits: number
  /** 冷却截止时间戳（毫秒） */
  cooldownUntil: number
  intent: IntentTracker
}

const GUIDANCE = (why: string): string =>
  '[loop-detector] 检测到你正在重复输出同一段内容（死循环）。请立即停止当前思路并重新组织回答：' +
  '不要重复任何已经输出的文字，不要再次做同一件事，直接给出简洁、完整、不重复的最终回答。' +
  `\n（触发原因：${why}）`

const TOOL_GUIDANCE = (tool: string, why: string): string =>
  `[loop-detector] 检测到你连续多次用 ${tool} 做同一件事（换了参数但没有新信息）。请立即停止继续调用，` +
  '基于已有信息直接回答或换个明确不同的方向。' +
  `\n（触发原因：${why}）`

/**
 * 安装监听器。
 * @param ctx - 插件上下文；监听器随它一起销毁
 * @param config - 用户配置（已由 Config schema 解析，仍需 fail-loud 复核）
 */
export function apply(ctx: PluginContext, config: Config = {}): void {
  const settings = resolveConfig(config)
  const states = new WeakMap<object, AgentState>()
  /** 本插件注入的消息 id：用来把自己发的引导消息和真实用户输入区分开 */
  const injected = new Set<string>()

  const now = (): number => Date.now()

  function stateFor(agent: object): AgentState {
    let state = states.get(agent)
    if (state === undefined) {
      state = {
        text: { value: '', checked: 0 },
        reasoning: { value: '', checked: 0 },
        hits: 0,
        cooldownUntil: 0,
        intent: new IntentTracker(settings.intent),
      }
      states.set(agent, state)
    }
    return state
  }

  function resetState(state: AgentState): void {
    state.text = { value: '', checked: 0 }
    state.reasoning = { value: '', checked: 0 }
    state.hits = 0
    state.cooldownUntil = 0
    state.intent.reset()
  }

  /** 注入一条引导消息，并记下它的 id。 */
  function steerGuidance(agent: AgentLike, text: string): void {
    const message = createUserMessage({
      content: [{ type: 'text', text }],
      source: { kind: 'user' },
    }) as { id: string }
    injected.add(String(message.id))
    if (injected.size > 256) injected.clear()
    agent.steer(message)
  }

  /**
   * 命中后的动作。'steer' 模式下先真正掐断当前生成，再把引导消息交给下一步；
   * 重试耗尽（或 action='cancel'）时只中止，让 agent 彻底停下来。
   */
  function act(agent: AgentLike, state: AgentState, why: string, guidance: string): void {
    const canRetry = settings.action === 'steer' && state.hits <= settings.maxRetries
    try {
      if (canRetry) {
        // keepInbox: true —— 中止当前回合但保留收件箱，随后 steer 的引导消息才有落点
        agent.cancel({ kind: 'hook', reason: `loop-detected: ${why}` }, { keepInbox: true })
        steerGuidance(agent, guidance)
        ctx.logger.warn(
          `[loop-detector] session ${agent.id} 检测到死循环（重试 ${state.hits}/${settings.maxRetries}）: ${why}；已打断并引导重试`,
        )
      } else {
        agent.cancel({ kind: 'hook', reason: `loop-detected: ${why}` })
        ctx.logger.error(
          `[loop-detector] session ${agent.id} 重试 ${settings.maxRetries} 次仍死循环，强制中止: ${why}`,
        )
      }
    } catch (error) {
      ctx.logger.warn(`[loop-detector] session ${agent.id} 打断失败: ${String(error)}`)
    }
  }

  /** 追加一段流式文本并按节流跑检测。 */
  function push(agent: AgentLike, state: AgentState, stream: Stream, text: string, why: string): void {
    stream.value = (stream.value + text).slice(-settings.bufferLimit)
    const buffer = stream.value
    if (buffer.length < settings.minLen) return
    if (buffer.length - stream.checked < settings.checkEvery) return
    stream.checked = buffer.length
    if (now() < state.cooldownUntil) return

    const hit: LoopHit | null = detectRepetition(buffer, settings.detector)
    if (!hit) return

    // 命中：清空缓冲并进入冷却，避免同一段重复内容连续触发
    state.text = { value: '', checked: 0 }
    state.reasoning = { value: '', checked: 0 }
    state.cooldownUntil = now() + settings.cooldownMs
    state.hits += 1
    ctx.logger.info(
      `[loop-detector] session ${agent.id} ${why}命中: ${hit.detail}｜片段 ${JSON.stringify(hit.evidence)}`,
    )
    act(agent, state, hit.detail, GUIDANCE(hit.detail))
  }

  /** 处理一个流分片（新旧通道共用）。 */
  function handleChunk(agent: unknown, chunk: unknown): void {
    if (!agent || typeof agent !== 'object') return
    if (!chunk || typeof chunk !== 'object') return
    const c = chunk as { type?: string; text?: unknown }
    if (typeof c.text !== 'string') return
    const state = stateFor(agent)
    if (c.type === 'text-delta' && settings.checkText) {
      push(agent as AgentLike, state, state.text, c.text, '正文本')
    } else if (c.type === 'reasoning-delta' && settings.checkReasoning) {
      push(agent as AgentLike, state, state.reasoning, c.text, '思考内容')
    }
  }

  // ── 实时流（dsh 0.2.x 正途）──────────────────────────────────────────
  // agent/* 事件是作用域派发的；`{ global: true }` 明确表示"观测所有 agent"。
  ctx.on(
    'agent/assistant-stream',
    (payload: any) => {
      try {
        const agent = payload?.agent
        const frame = payload?.frame
        if (!frame || frame.type !== 'chunk') return
        handleChunk(agent, frame.chunk)
      } catch (error) {
        ctx.logger.warn(`[loop-detector] 处理流分片失败: ${String(error)}`)
      }
    },
    { global: true },
  )

  // ── 真实用户输入 => 计数与状态归零 ──────────────────────────────────
  ctx.on(
    'agent/pre-step',
    (payload: any, next: any) => {
      try {
        const agent = payload?.agent
        const messages = payload?.messages
        if (agent && Array.isArray(messages)) {
          let freshUserInput = false
          for (const message of messages) {
            const id = message?.id === undefined ? undefined : String(message.id)
            // 注意顺序：先判断"是不是我们自己注入的"，不要先删——否则自己的引导消息会被当成用户输入
            const ours = id !== undefined && injected.has(id)
            if (message?.source?.kind === 'user' && !ours) freshUserInput = true
          }
          if (freshUserInput) {
            const state = states.get(agent)
            if (state) resetState(state)
          }
        }
      } catch (error) {
        ctx.logger.warn(`[loop-detector] 重置状态失败: ${String(error)}`)
      }
      return next()
    },
    { global: true },
  )

  // ── 工具调用意图级重复 ──────────────────────────────────────────────
  if (settings.intent.toolPatterns.length > 0) {
    ctx.on('tools/post-execute', async (exec: any, _result: unknown, next: any) => {
      const decision = await next()
      try {
        const agent = exec?.agent
        const toolName = exec?.name
        if (!agent || typeof toolName !== 'string') return decision
        if (!matchesTool(toolName, settings.intent.toolPatterns)) return decision

        const query = extractQueryText(exec.arguments, settings.intent.maxQueryChars)
        if (query.trim().length === 0) return decision

        const state = stateFor(agent)
        const verdict = state.intent.observe(query)
        if (!verdict.repeat || now() < state.cooldownUntil) return decision

        state.cooldownUntil = now() + settings.cooldownMs
        state.hits += 1
        const why = `repeated ${toolName} intent: novelty=${verdict.novelty.toFixed(2)} similarity=${verdict.similarity.toFixed(2)}`
        ctx.logger.info(`[loop-detector] session ${agent.id} 意图级重复: ${why}`)
        act(agent, state, why, TOOL_GUIDANCE(toolName, why))
      } catch (error) {
        ctx.logger.warn(`[loop-detector] 意图级检测失败: ${String(error)}`)
      }
      return decision
    })
  }

  // ── 旧版 dsh 兼容通道（默认关闭）────────────────────────────────────
  if (settings.legacySessionEvents) {
    ctx.inject(['agents'], (scoped: any) => {
      scoped.on('session/event', (session: any, event: any) => {
        try {
          if (!event || event.type !== 'assistant/chunk') return
          const agent = scoped.agents?.get?.(session?.id)
          if (!agent) return
          handleChunk(agent, event?.data?.chunk)
        } catch (error) {
          ctx.logger.warn(`[loop-detector] 旧通道处理失败: ${String(error)}`)
        }
      })
    })
  }
}
