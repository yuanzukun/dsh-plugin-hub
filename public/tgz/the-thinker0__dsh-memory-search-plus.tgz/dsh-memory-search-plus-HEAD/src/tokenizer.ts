/**
 * tokenizer — 中文分词 + 英文/数字切分 + CJK 二元组/单字。
 *
 * QA 契约（tests/README.md「QA 测试契约」）：
 *  - Intl.Segmenter('zh', {granularity:'word'}) 中文词；J 段中文词被单字/二元组规则覆盖
 *  - 英文/数字按 \p{L}+|\p{N}+ 切分，ASCII token 一律小写
 *  - CJK 单字 + 相邻二元组（对每个相邻 CJK 字符对）
 *  - token 不含标点/空白/FTS 元字符；不重复；空串/纯空白 → []
 */

import { MAX_FTS_SOURCE_CHARS } from './types.ts'

const CJK_RE = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/u

const SEGMENTER = new Intl.Segmenter('zh', { granularity: 'word' })

const isCjkOnly = (word: string): boolean => {
  for (const ch of word) {
    if (!CJK_RE.test(ch)) return false
  }
  return true
}

/**
 * 分词核心：索引侧与查询侧共用（includeSingles 区分）。
 *  - Segmenter('zh') 词（非纯 CJK，小写化；纯 CJK 词由单字/二元组规则覆盖）
 *  - 英文/数字 run：\p{L}+ | \p{N}+（小写化）
 *  - CJK 单字（可关）+ 相邻二元组（对每个相邻 CJK 字符对）
 *  - token 不含标点/空白/FTS 元字符；不重复；空串/纯空白 → []
 */
function collectTokens(input: string, includeCjkSingles: boolean): string[] {
  const seen = new Set<string>()
  const add = (token: string): void => {
    // FTS detail=none cannot evaluate multi-token phrases. A Segmenter may
    // return `search_events` as one word-like segment even though unicode61
    // splits it into two tokens; keeping the underscore would make the quoted
    // query a phrase and silently lose recall. The run pass below adds both
    // clean components.
    if (token.length > 0 && /^[\p{L}\p{N}]+$/u.test(token)) seen.add(token)
  }

  // 1. Segmenter('zh') 词（小写化；纯 CJK 词交给单字/二元组规则，避免重复）
  for (const seg of SEGMENTER.segment(input)) {
    if (!seg.isWordLike) continue
    const word = seg.segment
    if (isCjkOnly(word)) continue
    add(word.toLowerCase())
  }

  // 2. 英文/数字 run：\p{L}+ | \p{N}+
  for (const m of input.matchAll(/\p{L}+|\p{N}+/gu)) {
    const word = m[0]
    if (word === undefined || isCjkOnly(word)) continue
    add(word.toLowerCase())
  }

  // 3. CJK 单字（可选）+ 相邻二元组
  const chars = [...input]
  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i]
    if (ch === undefined || !CJK_RE.test(ch)) continue
    if (includeCjkSingles) add(ch)
    const next = chars[i + 1]
    if (next !== undefined && CJK_RE.test(next)) add(ch + next)
  }

  return [...seen]
}

/**
 * 索引侧分词：词 + 二元组 + 单字（保 1 字查询召回，FTS tokens 列写入）。
 */
export function tokenize(input: string): string[] {
  if (typeof input !== 'string' || input.length === 0) return []
  const bounded = input.length > MAX_FTS_SOURCE_CHARS ? input.slice(0, MAX_FTS_SOURCE_CHARS) : input
  return collectTokens(bounded, true)
}

/**
 * 查询侧分词：词 + 二元组，**去除 CJK 单字**——防止高频单字候选膨胀
 * （QA 实测含单体 p95 65ms@100k → 1M 外推 651ms 超 300ms 预算；船长/QA 裁定）。
 * 例外：查询本身为单个 CJK 字符时（如 "聊"），保留该单字以维持 1 字查询召回。
 */
export function queryTokens(input: string): string[] {
  if (typeof input !== 'string') return []
  const trimmed = input.trim()
  if (trimmed.length === 0) return []
  const chars = [...trimmed]
  const singleCjkChar = chars.length === 1 && CJK_RE.test(chars[0]!)
  const filtered = collectTokens(input, singleCjkChar)
  // ADR-10 终稿：去单字后为空（纯单字/混合单字查询，如 "3天"）→ 回退全 token，
  // 避免空 FTS 恒 0 命中的召回黑洞（A5 中英混合查询）。
  if (filtered.length === 0) return collectTokens(input, true)
  return filtered
}

/**
 * 查询侧 FTS5 查询串：**查询侧 token**（词 + 二元组，去 CJK 单字；单字仅当
 * 查询为单个 CJK 字符时保留——船长/QA 裁定，防高频单字候选膨胀）每个 token
 * 双引号包裹（转义 FTS 运算符/元字符）、空格连接（FTS5 隐式 AND）、全部小写。
 *
 * 定案（t11 采纳 REVIEW-architect L2 + ADR-9）：索引与查询使用同一 segmenter
 * 同一构造器（仅单字取舍不同），召回最全、候选最小；token 总数 ≤ 32
 * （MAX_FTS_TOKENS，防超长查询候选爆炸）。
 */
export const MAX_FTS_TOKENS = 32

export function buildFtsQuery(input: string): string {
  const trimmed = typeof input === 'string' ? input : ''
  return queryTokens(trimmed)
    .slice(0, MAX_FTS_TOKENS)
    .map((token) => `"${token}"`)
    .join(' ')
}
