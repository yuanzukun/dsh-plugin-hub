/**
 * indexer — SQLite FTS5 全文索引（含 node:sqlite 缺失时的内存降级）。
 *
 * QA 契约（tests/README.md）：
 *  - createSearchIndex({ dbPath?, sqliteModule? }) → SearchIndex
 *  - upsert 以 (sessionId, seq) 幂等；rebuildSessionIds 指定会话整会话重建
 *    （丢弃 surface==='shadowed'，保留 current/log-only）
 *  - ':memory:' 与文件路径；close 后重开同一路径数据仍在（WAL 持久化）
 *  - node:sqlite 仅以 try 包裹的动态导入（禁止静态 import）；sqliteModule:null
 *    或加载失败 → 内存索引降级：status.degraded=true，索引/搜索可用，不持久化
 *
 * schema v3：contentless/detail-none FTS 只存 postings，正文与元数据位于
 * docs；默认容量有界；查询自适应 top-k；大写入用可恢复 cooperative 微批。
 */

import { existsSync, mkdirSync, readdirSync, renameSync, statSync, unlinkSync } from 'node:fs'
import path from 'node:path'
import { tokenize, buildFtsQuery } from './tokenizer.ts'
import { boundIndexText } from './index-text.ts'
import { resolveIndexDbPath } from './db-path.ts'
import { composeHit, literalSearchTerms, parseSearchRole, typeMatchesRole, typesForRole } from './search.ts'
import {
  DEFAULT_MAX_INDEX_BYTES,
  DEFAULT_SEARCH_LIMIT,
  INITIAL_RECALL_LIMIT,
  MAX_INDEX_TEXT_CHARS,
  MAX_QUERY_CHARS,
  MAX_SEARCH_LIMIT,
  MAX_TEXT,
  RECALL_LIMIT,
  SCHEMA_VERSION,
  SEARCH_TIME_BUDGET_MS,
  type IndexRecord,
  type IndexStatus,
  type SearchHit,
  type SearchIndex,
  type SearchOptions,
  type SearchResult,
  type SessionStateRow,
} from './types.ts'

const FTS_SCHEMA =
  "CREATE VIRTUAL TABLE ftsevents USING fts5(" +
  "tokens, content='', contentless_delete=1, detail=none)"

const DOCS_SCHEMA =
  'CREATE TABLE docs(' +
  'rowid INTEGER PRIMARY KEY, session_id TEXT NOT NULL, seq INTEGER NOT NULL, ' +
  'type TEXT NOT NULL, time INTEGER NOT NULL, surface TEXT NOT NULL, anchor_key TEXT, ' +
  'text TEXT NOT NULL, text_truncated INTEGER NOT NULL DEFAULT 0, ' +
  'stored_bytes INTEGER NOT NULL DEFAULT 0, UNIQUE(session_id, seq))'

const HIT_COLUMNS =
  'd.session_id, d.seq, d.type, d.time, d.surface, d.anchor_key, d.text, d.text_truncated'

const STORAGE_TARGET_RATIO = 0.85
const PRUNE_BATCH_SIZE = 2_000
const SEARCH_CACHE_ENTRIES = 64
/** One chronological FTS docid bucket per minute. Dense docids keep posting
 * deltas compact while 65,536 slots absorb large multi-session imports. */
const TIME_BUCKET_MS = 60_000
const TIME_ROWID_SCALE = 65_536

// ---------------------------------------------------------------------------
// node:sqlite 动态加载（模块级；失败 → 内存降级）
// ---------------------------------------------------------------------------
let SQLITE_MODULE: { DatabaseSync?: unknown } | null = null
try {
  SQLITE_MODULE = (await import('node:sqlite')) as { DatabaseSync?: unknown }
} catch {
  SQLITE_MODULE = null
}

interface SqliteDatabase {
  exec(sql: string): void
  prepare(sql: string): {
    run(...params: unknown[]): { changes: number; lastInsertRowid: number | bigint }
    get(...params: unknown[]): Record<string, unknown> | undefined
    all(...params: unknown[]): Array<Record<string, unknown>>
  }
  close(): void
}

type DatabaseCtor = new (path: string) => SqliteDatabase

class UnsupportedSchemaVersionError extends Error {
  constructor(version: number) {
    super(`unsupported future schema version ${version}`)
    this.name = 'UnsupportedSchemaVersionError'
  }
}

/**
 * Transient contention/locking failures (another process holds the database)
 * are healthy behavior, not corruption: they must never trigger the
 * destructive "backup as corrupt and rebuild" path. Exported for fault-path
 * unit tests.
 */
export function isTransientSqliteError(error: unknown): boolean {
  if (!(error instanceof Error)) return false
  const code = String((error as { code?: unknown }).code ?? '').toUpperCase()
  if (code.includes('SQLITE_BUSY') || code.includes('SQLITE_LOCKED')) return true
  const message = error.message.toLowerCase()
  return (
    message.includes('database is locked') ||
    message.includes('database table is locked') ||
    message.includes('sqlite_busy') ||
    message.includes('sqlite_locked')
  )
}

/** Disk-full / permission / read-only: the file is not corrupt. Renaming it
 * to `.bak` would discard a healthy index and can make a full disk worse. */
export function isNonCorruptOpenError(error: unknown): boolean {
  if (isTransientSqliteError(error)) return true
  if (!(error instanceof Error)) return false
  const code = String((error as { code?: unknown }).code ?? '').toUpperCase()
  if (
    code.includes('SQLITE_FULL') ||
    code.includes('SQLITE_READONLY') ||
    code.includes('SQLITE_AUTH') ||
    code === 'ENOSPC' ||
    code === 'EACCES' ||
    code === 'EPERM' ||
    code === 'EROFS'
  ) {
    return true
  }
  const message = error.message.toLowerCase()
  return (
    message.includes('database or disk is full') ||
    message.includes('disk is full') ||
    message.includes('no space left') ||
    message.includes('permission denied') ||
    message.includes('read-only') ||
    message.includes('readonly') ||
    message.includes('sqlite_full') ||
    message.includes('sqlite_readonly')
  )
}

/** Maps a wall-clock `time` column onto the same minute bucket the live
 * allocator uses: epoch-adjacent minutes (CAST=0) share bucket 1 with the
 * first real minute, because bucket 0 is reserved unused. Crowding checks
 * and rowid assignment must use this expression together or UNIQUE collides. */
const LEGACY_TIME_BUCKET_SQL =
  `(CASE WHEN CAST(time/${TIME_BUCKET_MS} AS INTEGER)>0 THEN CAST(time/${TIME_BUCKET_MS} AS INTEGER) ELSE 1 END)`

/** One chronological FTS docid bucket per minute; dense docids keep posting
 * lists ordered by recency so `ORDER BY rowid DESC` streams top-k without a
 * sorter. Adjacent buckets are only used as overflow (see below). */
const ROWID_SPILL_BUCKETS = 8

/**
 * Pure core of chronological rowid allocation: probe the home minute bucket
 * outward from the event's millisecond position, then spill to adjacent
 * buckets when the whole home bucket is occupied (>65k events sharing one
 * minute — bulk imports, zeroed/skewed clocks). Spilling keeps writes
 * succeeding with approximately correct chronology; final hits are re-sorted
 * by exact time/seq in JS regardless. Exported for fault-path unit tests.
 */
export function probeChronologicalRowid(
  isFree: (rowid: number) => boolean,
  time: number,
  spillBuckets: number = ROWID_SPILL_BUCKETS,
): number {
  const maxBucket = Math.floor(Number.MAX_SAFE_INTEGER / TIME_ROWID_SCALE) - 1
  const millis = Math.max(1, Math.trunc(time))
  const homeBucket = Math.min(maxBucket, Math.floor(millis / TIME_BUCKET_MS))
  const preferred = millis % TIME_BUCKET_MS
  for (let offset = 0; offset <= spillBuckets; offset++) {
    const candidates = offset === 0 ? [homeBucket] : [homeBucket + offset, homeBucket - offset]
    for (const bucket of candidates) {
      if (bucket < 1 || bucket > maxBucket) continue
      const base = bucket * TIME_ROWID_SCALE
      for (let step = 0; step < TIME_ROWID_SCALE; step++) {
        const rowid = base + ((preferred + step) % TIME_ROWID_SCALE)
        if (isFree(rowid)) return rowid
      }
    }
  }
  throw new Error(`chronological rowid space exhausted around minute ${homeBucket}`)
}

function resolveDatabaseSync(sqliteModule: unknown): DatabaseCtor | null {
  if (sqliteModule === null || sqliteModule === undefined) return null
  const ctor = (sqliteModule as { DatabaseSync?: unknown })?.DatabaseSync
  if (typeof ctor === 'function') return ctor as DatabaseCtor
  // 兼容注入整个 DatabaseSync 类本身
  if (typeof sqliteModule === 'function') return sqliteModule as DatabaseCtor
  return null
}

function applySqlitePragmas(db: SqliteDatabase): void {
  // Wait out transient cross-process write locks (the web UI and a gateway may
  // open the same database) instead of surfacing immediate SQLITE_BUSY errors.
  // Applied first so even journal-mode switching waits rather than fails.
  db.exec('PRAGMA busy_timeout=3000')
  // Must be selected before journal/WAL initialization fixes the page layout;
  // otherwise SQLite accepts the statement but a fresh file remains mode 0.
  // Existing databases keep their current mode until a rebuild/VACUUM.
  db.exec('PRAGMA auto_vacuum=INCREMENTAL')
  db.exec('PRAGMA journal_mode=WAL')
  db.exec('PRAGMA synchronous=NORMAL')
  db.exec('PRAGMA temp_store=MEMORY')
  db.exec('PRAGMA cache_size=-16000')
  db.exec('PRAGMA secure_delete=FAST')
  try {
    db.exec('PRAGMA mmap_size=268435456')
  } catch {
    /* optional on some builds */
  }
}

function defaultDbPath(): string {
  return resolveIndexDbPath()
}

// ---------------------------------------------------------------------------
// SQLite 实现
// ---------------------------------------------------------------------------
function tableExists(db: SqliteDatabase, name: string): boolean {
  return db.prepare("SELECT 1 AS present FROM sqlite_master WHERE name = ?").get(name) !== undefined
}

function createV3Tables(db: SqliteDatabase, suffix = ''): void {
  const docs = `docs${suffix}`
  const fts = `ftsevents${suffix}`
  db.exec(DOCS_SCHEMA.replace('CREATE TABLE docs(', `CREATE TABLE ${docs}(`))
  db.exec(FTS_SCHEMA.replace('CREATE VIRTUAL TABLE ftsevents ', `CREATE VIRTUAL TABLE ${fts} `))
}

/** Preserve searchable rows during the one-time v1/v2 upgrade. The migration
 * is one transaction and does not need to reread/decompress every DSH log.
 * Returns `true` when a crowded legacy distribution forced an empty-v3 fresh
 * rebuild instead of a rowid-preserving copy. */
function migrateLegacySchema(db: SqliteDatabase): boolean {
  const columns = new Set(
    db.prepare('PRAGMA table_info(ftsevents)').all().map((row) => String(row.name ?? '')),
  )
  for (const column of ['tokens', 'text', 'session_id', 'seq', 'type', 'time', 'surface', 'anchor_key']) {
    if (!columns.has(column)) throw new Error(`incompatible legacy ftsevents schema: missing ${column}`)
  }
  db.exec('DROP TABLE IF EXISTS docs_v3')
  db.exec('DROP TABLE IF EXISTS ftsevents_v3')
  createV3Tables(db, '_v3')
  const crowded = db.prepare(
    `SELECT MAX(c) AS n FROM (SELECT COUNT(*) AS c FROM ftsevents GROUP BY ${LEGACY_TIME_BUCKET_SQL})`,
  ).get()
  if (Number(crowded?.n ?? 0) > TIME_ROWID_SCALE) {
    // Chronological rowids cannot represent >65k events sharing one minute
    // (bulk imports, zeroed/skewed clocks). The index is a rebuildable
    // derivative: swap in the empty v3 tables created above and let startup
    // reconcile refill them from the source sessions. A healthy database is
    // never renamed as a corrupt backup merely for its data distribution.
    db.exec('DROP TABLE ftsevents')
    db.exec('ALTER TABLE ftsevents_v3 RENAME TO ftsevents')
    db.exec('ALTER TABLE docs_v3 RENAME TO docs')
    db.exec('DELETE FROM session_state')
    return true
  }
  db.exec('DROP TABLE IF EXISTS temp.rowid_map_v3')
  db.exec(
    'CREATE TEMP TABLE rowid_map_v3(old_rowid INTEGER PRIMARY KEY,new_rowid INTEGER NOT NULL UNIQUE)',
  )
  db.exec(
    'INSERT INTO rowid_map_v3(old_rowid,new_rowid) ' +
      'SELECT rowid,' +
      `${LEGACY_TIME_BUCKET_SQL}*${TIME_ROWID_SCALE}+` +
      `(ROW_NUMBER() OVER (PARTITION BY ${LEGACY_TIME_BUCKET_SQL} ` +
      'ORDER BY CAST(time AS INTEGER),CAST(seq AS INTEGER),session_id,rowid)-1) FROM ftsevents',
  )
  db.exec(
    'INSERT INTO docs_v3(rowid,session_id,seq,type,time,surface,anchor_key,text,text_truncated,stored_bytes) ' +
      'SELECT m.new_rowid,f.session_id,CAST(f.seq AS INTEGER),f.type,CAST(f.time AS INTEGER),f.surface,f.anchor_key,f.text,' +
      `CASE WHEN length(text) >= ${MAX_INDEX_TEXT_CHARS} THEN 1 ELSE 0 END,` +
      'length(CAST(text AS BLOB))+length(CAST(tokens AS BLOB))+128 ' +
      'FROM ftsevents f JOIN rowid_map_v3 m ON m.old_rowid=f.rowid',
  )
  db.exec(
    'INSERT INTO ftsevents_v3(rowid,tokens) ' +
      'SELECT m.new_rowid,f.tokens FROM ftsevents f JOIN rowid_map_v3 m ON m.old_rowid=f.rowid',
  )
  db.exec('DROP TABLE rowid_map_v3')
  db.exec('DROP TABLE ftsevents')
  db.exec('ALTER TABLE ftsevents_v3 RENAME TO ftsevents')
  db.exec('ALTER TABLE docs_v3 RENAME TO docs')
  db.exec('DROP TABLE IF EXISTS event_keys')
  return false
}

function validateV3Schema(db: SqliteDatabase): void {
  const docsColumns = new Set(
    db.prepare('PRAGMA table_info(docs)').all().map((row) => String(row.name ?? '')),
  )
  for (const column of [
    'rowid', 'session_id', 'seq', 'type', 'time', 'surface', 'anchor_key',
    'text', 'text_truncated', 'stored_bytes',
  ]) {
    if (!docsColumns.has(column)) throw new Error(`incompatible docs schema: missing ${column}`)
  }
  const ftsColumns = db.prepare('PRAGMA table_info(ftsevents)').all()
  if (ftsColumns.length !== 1 || ftsColumns[0]?.name !== 'tokens') {
    throw new Error('incompatible v3 ftsevents schema')
  }
  const definition = String(
    db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='ftsevents'").get()?.sql ?? '',
  ).toLowerCase()
  if (!definition.includes("content=''".toLowerCase()) || !definition.includes('contentless_delete=1') || !definition.includes('detail=none')) {
    throw new Error('ftsevents must be contentless-delete with detail=none')
  }
}

function ensureSchema(db: SqliteDatabase): void {
  const versionRow = db.prepare('PRAGMA user_version').get()
  const existingVersion = Number(versionRow?.user_version ?? 0)
  if (Number.isFinite(existingVersion) && existingVersion > SCHEMA_VERSION) {
    throw new UnsupportedSchemaVersionError(existingVersion)
  }

  let migratedLegacy = false
  db.exec('BEGIN')
  try {
    db.exec(
      'CREATE TABLE IF NOT EXISTS session_state(' +
        'session_id TEXT PRIMARY KEY, max_seq INTEGER NOT NULL DEFAULT -1, ' +
        'dirty INTEGER NOT NULL DEFAULT 0, built_at INTEGER, docs INTEGER NOT NULL DEFAULT 0)',
    )
    db.exec('CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT)')

    if (!tableExists(db, 'ftsevents')) {
      createV3Tables(db)
    } else if (existingVersion < 3 || !tableExists(db, 'docs')) {
      const freshRebuild = migrateLegacySchema(db)
      migratedLegacy = true
      if (freshRebuild) {
        // Crowding fallback starts from empty v3 tables; force the
        // session_state repair pass to re-derive watermarks from docs.
        db.prepare(
          "INSERT INTO meta(key,value) VALUES('state_coverage_version','1') " +
            'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
        ).run()
      }
    }
    validateV3Schema(db)

    const stateColumns = new Set(
      db.prepare('PRAGMA table_info(session_state)').all().map((row) => String(row.name ?? '')),
    )
    const metaColumns = new Set(
      db.prepare('PRAGMA table_info(meta)').all().map((row) => String(row.name ?? '')),
    )
    for (const column of ['session_id', 'max_seq', 'dirty', 'built_at', 'docs']) {
      if (!stateColumns.has(column)) throw new Error(`incompatible session_state schema: missing ${column}`)
    }
    for (const column of ['key', 'value']) {
      if (!metaColumns.has(column)) throw new Error(`incompatible meta schema: missing ${column}`)
    }
    db.exec('CREATE INDEX IF NOT EXISTS docs_time_idx ON docs(time DESC, seq DESC, rowid DESC)')
    // Drop v3-development indexes superseded by the UNIQUE(session_id,seq)
    // autoindex and chronological FTS rowids. They increased disk without
    // participating in the chosen query plans.
    db.exec('DROP INDEX IF EXISTS docs_session_idx')
    db.exec('DROP INDEX IF EXISTS docs_surface_time_idx')
    db.exec('DROP INDEX IF EXISTS docs_type_time_idx')
    db.exec('DROP TABLE IF EXISTS event_keys')
    db.exec("INSERT INTO ftsevents(ftsevents, rank) VALUES('secure-delete', 1)")
    db.exec("INSERT INTO ftsevents(ftsevents, rank) VALUES('automerge', 4)")
    db.exec("INSERT INTO ftsevents(ftsevents, rank) VALUES('crisismerge', 16)")
    db.exec("INSERT INTO ftsevents(ftsevents, rank) VALUES('deletemerge', 10)")
    const rowidLayout = db.prepare("SELECT value FROM meta WHERE key='rowid_layout_version'").get()
    const docsPresent = Number(db.prepare('SELECT COUNT(*) AS n FROM docs').get()?.n ?? 0) > 0
    if (existingVersion >= 3 && docsPresent && rowidLayout?.value !== '3') {
      throw new Error('v3 index is missing its chronological rowid layout marker')
    }
    db.prepare(
      "INSERT INTO meta(key,value) VALUES('rowid_layout_version','3') " +
        'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
    ).run()

    const stateCoverage = db.prepare("SELECT value FROM meta WHERE key='state_coverage_version'").get()
    if (stateCoverage?.value !== '2') {
      // Repair legacy/partially migrated databases that contain logical rows
      // without a corresponding materialized session_state row.
      db.prepare(
        'INSERT INTO session_state(session_id, max_seq, dirty, built_at, docs) ' +
          'SELECT d.session_id, MAX(d.seq), 0, ?, COUNT(*) FROM docs d ' +
          'LEFT JOIN session_state s ON s.session_id = d.session_id ' +
          'WHERE s.session_id IS NULL GROUP BY d.session_id',
      ).run(Date.now())
      db.exec(
        'UPDATE session_state SET docs=(SELECT COUNT(*) FROM docs d WHERE d.session_id=session_state.session_id)',
      )
      db.prepare(
        "INSERT INTO meta(key, value) VALUES('state_coverage_version', '2') " +
          'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
      ).run()
    }
    db.exec(`PRAGMA user_version = ${SCHEMA_VERSION}`)
    db.prepare(
      "INSERT INTO meta(key, value) VALUES('schema_version', ?) " +
        'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
    ).run(String(SCHEMA_VERSION))
    if (migratedLegacy) {
      // The in-place copy temporarily contains both legacy and v3 pages. A
      // durable marker makes post-commit compaction retryable after a process
      // exit without repeating the logical migration.
      db.prepare(
        "INSERT INTO meta(key,value) VALUES('migration_vacuum_pending','1') " +
          'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
      ).run()
    }
    db.exec('COMMIT')
  } catch (error) {
    try {
      db.exec('ROLLBACK')
    } catch {
      /* no active transaction */
    }
    throw error
  }
}

/** Finish the only unbounded maintenance operation in schema v3. Legacy
 * migration copied rows before dropping the old FTS table, so a one-time
 * VACUUM removes that temporary high-water mark and converts the file to
 * incremental auto-vacuum. The durable marker retries after interruption. */
function finishLegacyMigrationCompaction(db: SqliteDatabase, warn: (msg: string) => void): void {
  const pending = db.prepare("SELECT value FROM meta WHERE key='migration_vacuum_pending'").get()?.value
  if (pending !== '1') return
  try {
    db.exec('PRAGMA wal_checkpoint(TRUNCATE)')
    db.exec('PRAGMA auto_vacuum=INCREMENTAL')
    db.exec('VACUUM')
    db.prepare("UPDATE meta SET value='0' WHERE key='migration_vacuum_pending'").run()
  } catch (error) {
    warn(
      `[memory-search] v3 迁移已完成，但一次性文件压实失败；下次启动重试: ` +
        `${error instanceof Error ? error.message : String(error)}`,
    )
  }
}

function rowToState(row: Record<string, unknown> | undefined, sessionId: string): SessionStateRow | undefined {
  if (row === undefined) return undefined
  return {
    sessionId,
    maxSeq: typeof row.max_seq === 'number' ? row.max_seq : -1,
    dirty: typeof row.dirty === 'number' ? row.dirty : 0,
    builtAt: typeof row.built_at === 'number' ? row.built_at : null,
    docs: typeof row.docs === 'number' ? row.docs : 0,
  }
}

function closeSqlite(db: SqliteDatabase | undefined): void {
  if (db === undefined) return
  try {
    db.close()
  } catch {
    /* already closed */
  }
}

/** 主库 + WAL sidecar 一起改名，避免新文件回放旧 -wal/-shm。 */
function backupSqliteFiles(dbPath: string): string {
  const backupPath = `${dbPath}.bak-${Date.now()}`
  renameSync(dbPath, backupPath)
  for (const suffix of ['-wal', '-shm'] as const) {
    const src = `${dbPath}${suffix}`
    if (!existsSync(src)) continue
    try {
      renameSync(src, `${backupPath}${suffix}`)
    } catch {
      /* sidecar 尽力而为；主文件已挪走 */
    }
  }
  return backupPath
}

/** Corrupt indexes are rebuildable caches. Retain only the newest backup set
 * so repeated recovery cannot silently consume unbounded disk or preserve
 * deleted private text forever. */
function pruneOldBackups(dbPath: string): void {
  const dir = path.dirname(dbPath)
  const prefix = `${path.basename(dbPath)}.bak-`
  let names: string[]
  try {
    names = readdirSync(dir).filter((name) => name.startsWith(prefix))
  } catch {
    return
  }
  const generations = [...new Set(names.map((name) => name.slice(prefix.length).split('-')[0]).filter(Boolean))]
    .sort((a, b) => Number(b) - Number(a))
  for (const old of generations.slice(1)) {
    for (const name of names) {
      if (name === `${prefix}${old}` || name.startsWith(`${prefix}${old}-`)) {
        try { unlinkSync(path.join(dir, name)) } catch { /* best effort */ }
      }
    }
  }
}

function physicalStorageBytes(dbPath: string): number {
  if (dbPath === ':memory:') return 0
  let total = 0
  for (const file of [dbPath, `${dbPath}-wal`, `${dbPath}-shm`]) {
    try { total += statSync(file).size } catch { /* absent sidecar */ }
  }
  return total
}

function createSqliteIndex(
  dbPath: string,
  DatabaseSync: DatabaseCtor,
  warn: (msg: string) => void,
  maxIndexBytes: number | null,
): SearchIndex {
  if (dbPath !== ':memory:') {
    try {
      mkdirSync(path.dirname(dbPath), { recursive: true })
    } catch {
      /* open 阶段统一失败降级 */
    }
  }

  let db: SqliteDatabase | undefined
  try {
    db = new DatabaseSync(dbPath)
    applySqlitePragmas(db)
    ensureSchema(db)
    finishLegacyMigrationCompaction(db, warn)
    if (dbPath !== ':memory:') pruneOldBackups(dbPath)
  } catch (error) {
    closeSqlite(db)
    db = undefined
    if (error instanceof UnsupportedSchemaVersionError) {
      warn(`[memory-search] ${error.message}；未修改数据库，暂时降级为内存索引`)
      return createMemoryIndex(warn, maxIndexBytes)
    }
    if (isNonCorruptOpenError(error)) {
      // Another process holding the database, a full disk, or a permission
      // problem is not corruption: never rename the files. Degrade to memory
      // and let the next startup retry the file index.
      warn(
        `[memory-search] SQLite 打开遇到瞬时锁冲突或环境限制（${error instanceof Error ? error.message : String(error)}）；未修改数据库文件，暂时降级为内存索引，下次启动自动重试`,
      )
      return createMemoryIndex(warn, maxIndexBytes)
    }
    if (dbPath !== ':memory:') {
      try {
        const backupPath = backupSqliteFiles(dbPath)
        warn(`[memory-search] SQLite 打开失败，坏库已备份为 ${backupPath}（含 wal/shm），重建文件库`)
        db = new DatabaseSync(dbPath)
        applySqlitePragmas(db)
        ensureSchema(db)
        finishLegacyMigrationCompaction(db, warn)
        pruneOldBackups(dbPath)
      } catch (retryError) {
        closeSqlite(db)
        warn(
          `[memory-search] SQLite 打开/建表失败（备份重建也失败），降级为内存索引: ` +
            `${retryError instanceof Error ? retryError.message : String(retryError)}（原错误: ` +
            `${error instanceof Error ? error.message : String(error)}）`,
        )
        return createMemoryIndex(warn, maxIndexBytes)
      }
    } else {
      warn(`[memory-search] 内存库打开/建表失败，降级为内存索引: ${error instanceof Error ? error.message : String(error)}`)
      return createMemoryIndex(warn, maxIndexBytes)
    }
  }

  if (db === undefined) {
    return createMemoryIndex(warn, maxIndexBytes)
  }
  const sqlite = db

  const selectState = sqlite.prepare('SELECT session_id, max_seq, dirty, built_at, docs FROM session_state WHERE session_id = ?')
  const insertState = db.prepare(
    'INSERT INTO session_state(session_id, max_seq, dirty, built_at, docs) VALUES (?,?,?,?,?) ' +
      'ON CONFLICT(session_id) DO UPDATE SET max_seq=excluded.max_seq, dirty=excluded.dirty, built_at=excluded.built_at, docs=excluded.docs',
  )
  const deleteState = db.prepare('DELETE FROM session_state WHERE session_id = ?')
  const listStateIds = db.prepare('SELECT session_id FROM session_state')

  const insertDoc = db.prepare(
    'INSERT INTO docs(rowid,session_id,seq,type,time,surface,anchor_key,text,text_truncated,stored_bytes) ' +
      'VALUES (?,?,?,?,?,?,?,?,?,?)',
  )
  const insertFts = db.prepare('INSERT INTO ftsevents(rowid,tokens) VALUES (?,?)')
  const selectKey = db.prepare('SELECT rowid, stored_bytes FROM docs WHERE session_id = ? AND seq = ?')
  const selectRowid = db.prepare('SELECT 1 AS present FROM docs WHERE rowid = ?')
  const listSessionKeys = db.prepare('SELECT rowid, stored_bytes FROM docs WHERE session_id = ?')
  const deleteFtsRow = db.prepare('DELETE FROM ftsevents WHERE rowid = ?')
  const deleteDocRow = db.prepare('DELETE FROM docs WHERE rowid = ?')
  const listOldestDocs = db.prepare(
    'SELECT rowid, session_id, stored_bytes, time FROM docs ORDER BY time ASC, rowid ASC LIMIT ?',
  )
  const sumStoredBytes = db.prepare('SELECT COALESCE(SUM(stored_bytes),0) AS n FROM docs')
  const minIndexedTime = db.prepare('SELECT MIN(time) AS n FROM docs')
  const readMeta = db.prepare('SELECT value FROM meta WHERE key = ?')
  const writeMeta = db.prepare(
    'INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
  )
  const listAllStateRows = db.prepare('SELECT session_id, max_seq, dirty, built_at, docs FROM session_state')
  const countState = db.prepare('SELECT COUNT(*) AS c FROM session_state')

  /** 兼容旧库（session_state 空但 ftsevents 有行）时一次性物化（启动一次，价格可接受）。 */
  function materializeStateOnce(): void {
    const states = countState.get()
    if (states !== undefined && Number(states.c) > 0) return
    const docs = sqlite.prepare('SELECT session_id, seq FROM docs').all()
    if (docs.length === 0) return
    const perSession = new Map<string, { maxSeq: number; docs: number }>()
    for (const row of docs) {
      const sid = row.session_id
      const seq = row.seq
      if (typeof sid !== 'string' || typeof seq !== 'number') continue
      let entry = perSession.get(sid)
      if (entry === undefined) {
        entry = { maxSeq: -1, docs: 0 }
        perSession.set(sid, entry)
      }
      entry.maxSeq = Math.max(entry.maxSeq, seq)
      entry.docs += 1
    }
    for (const [sid, entry] of perSession) {
      insertState.run(sid, entry.maxSeq, 0, Date.now(), entry.docs)
    }
  }
  materializeStateOnce()

  /**
   * 内存会话状态（与 session_state 同源，同事务写回）：
   *  - maxSeqBySession：upsert 幂等判定（FTS5 UNINDEXED 列不可索引，逐条
   *    SELECT 存在性 = 全表扫描 → 批量增量 O(N²)，实测挂起/分钟级）；
   *  - docCountBySession：refreshState 物化计数（原实现每会话 COUNT/MAX 全表
   *    扫描，1000 会话 × 100k 行 ≈ 10⁸ 行访问 ≈ 60s）。
   * 两者在每次 mutation 的同一事务内更新，避免任何按会话的全表聚合。
   */
  const maxSeqBySession = new Map<string, number>()
  const docCountBySession = new Map<string, number>()
  for (const row of listAllStateRows.all()) {
    if (typeof row.session_id === 'string') {
      if (typeof row.max_seq === 'number') maxSeqBySession.set(row.session_id, row.max_seq)
      if (typeof row.docs === 'number') docCountBySession.set(row.session_id, row.docs)
    }
  }
  let liveStoredBytes = Number(sumStoredBytes.get()?.n ?? 0)
  if (!Number.isFinite(liveStoredBytes) || liveStoredBytes < 0) liveStoredBytes = 0
  let prunedDocs = Number(readMeta.get('pruned_docs')?.value ?? 0)
  if (!Number.isFinite(prunedDocs) || prunedDocs < 0) prunedDocs = 0
  let generation = 0
  const searchCache = new Map<string, SearchResult>()
  let cacheBatchDepth = 0
  let pendingCacheInvalidation = false

  function readState(sessionId: string): SessionStateRow | undefined {
    return rowToState(selectState.get(sessionId), sessionId)
  }

  /** 重物化某会话的 session_state 行（max_seq/docs 取内存增量状态，无全表扫描）。 */
  function refreshState(sessionId: string, dirty: number): void {
    const maxSeq = maxSeqBySession.get(sessionId) ?? -1
    const docs = docCountBySession.get(sessionId) ?? 0
    if (maxSeq >= 0) maxSeqBySession.set(sessionId, maxSeq)
    else maxSeqBySession.delete(sessionId)
    const prev = selectState.get(sessionId)
    const prevBuiltAt = prev !== undefined && typeof prev.built_at === 'number' ? prev.built_at : Date.now()
    const prevDirty = prev !== undefined && typeof prev.dirty === 'number' ? prev.dirty : 0
    insertState.run(sessionId, maxSeq, dirty === 1 ? 1 : prevDirty, prevBuiltAt, docs)
  }

  function deleteSessionRows(sessionId: string): void {
    const keys = listSessionKeys.all(sessionId)
    for (const row of keys) {
      const rowid = row.rowid
      if (typeof rowid === 'number' || typeof rowid === 'bigint') {
        deleteFtsRow.run(rowid)
        deleteDocRow.run(rowid)
      }
      const bytes = Number(row.stored_bytes ?? 0)
      if (Number.isFinite(bytes) && bytes > 0) liveStoredBytes = Math.max(0, liveStoredBytes - bytes)
    }
  }

  function allocateChronologicalRowid(time: number): number {
    return probeChronologicalRowid((rowid) => selectRowid.get(rowid) === undefined, time)
  }

  function upsertOne(record: IndexRecord): void {
    const key = selectKey.get(record.sessionId, record.seq)
    const rowid = key?.rowid
    const replaced = typeof rowid === 'number' || typeof rowid === 'bigint'
    if (replaced) {
      deleteFtsRow.run(rowid)
      deleteDocRow.run(rowid)
      const previousBytes = Number(key?.stored_bytes ?? 0)
      if (Number.isFinite(previousBytes) && previousBytes > 0) {
        liveStoredBytes = Math.max(0, liveStoredBytes - previousBytes)
      }
    }
    if (!replaced) {
      docCountBySession.set(record.sessionId, (docCountBySession.get(record.sessionId) ?? 0) + 1)
    }
    if (record.seq > (maxSeqBySession.get(record.sessionId) ?? -1)) {
      maxSeqBySession.set(record.sessionId, record.seq)
    }
    const bounded = boundIndexText(record.text, record.type)
    const textTruncated = bounded.truncated || record.textTruncated === true
    const text = bounded.text
    const tokens = tokenize(text).join(' ')
    const storedBytes = Buffer.byteLength(text, 'utf8') + Buffer.byteLength(tokens, 'utf8') + 128
    const newRowid = allocateChronologicalRowid(record.time)
    insertDoc.run(
      newRowid,
      record.sessionId,
      record.seq,
      record.type,
      record.time,
      record.surface,
      record.anchorKey,
      text,
      textTruncated ? 1 : 0,
      storedBytes,
    )
    insertFts.run(newRowid, tokens)
    liveStoredBytes += storedBytes
  }

  function validateRecords(records: IndexRecord[], rebuildSessionIds: string[]): void {
    for (const sessionId of rebuildSessionIds) {
      if (typeof sessionId !== 'string' || sessionId.length === 0) {
        throw new TypeError('rebuild session id must be a non-empty string')
      }
    }
    for (const record of records) {
      if (record === null || typeof record !== 'object') throw new TypeError('index record must be an object')
      if (typeof record.sessionId !== 'string' || record.sessionId.length === 0) {
        throw new TypeError('index record sessionId must be a non-empty string')
      }
      if (!Number.isSafeInteger(record.seq) || record.seq < 0) {
        throw new TypeError('index record seq must be a non-negative safe integer')
      }
      if (typeof record.type !== 'string' || typeof record.text !== 'string') {
        throw new TypeError('index record type/text must be strings')
      }
      if (!Number.isFinite(record.time)) throw new TypeError('index record time must be finite')
      if (!['current', 'shadowed', 'log-only'].includes(record.surface)) {
        throw new TypeError(`invalid index record surface: ${String(record.surface)}`)
      }
      if (record.anchorKey !== null && typeof record.anchorKey !== 'string') {
        throw new TypeError('index record anchorKey must be a string or null')
      }
    }
  }

  function normalizeLimit(raw: number | undefined): number {
    if (raw === undefined) return DEFAULT_SEARCH_LIMIT
    if (!Number.isFinite(raw) || raw <= 0) return DEFAULT_SEARCH_LIMIT
    return Math.min(MAX_SEARCH_LIMIT, Math.max(1, Math.floor(raw)))
  }

  function cloneResult(result: SearchResult): SearchResult {
    return {
      ...result,
      hits: result.hits.map((hit) => ({ ...hit, spans: hit.spans.map(([start, end]) => [start, end]) })),
    }
  }

  function cacheResult(key: string, result: SearchResult): void {
    if (!result.ok) return
    if (searchCache.has(key)) searchCache.delete(key)
    searchCache.set(key, cloneResult(result))
    while (searchCache.size > SEARCH_CACHE_ENTRIES) {
      const oldest = searchCache.keys().next().value
      if (typeof oldest !== 'string') break
      searchCache.delete(oldest)
    }
  }

  function invalidateSearchCache(): void {
    if (cacheBatchDepth > 0) {
      pendingCacheInvalidation = true
      return
    }
    generation += 1
    searchCache.clear()
  }

  /** Enforce a logical payload budget using recency eviction. Physical SQLite
   * pages remain reusable even when an older non-incremental-vacuum database
   * cannot shrink immediately. Source conversations are never deleted. */
  function enforceStorageBudget(): void {
    if (maxIndexBytes === null || maxIndexBytes <= 0 || liveStoredBytes <= maxIndexBytes) return
    const target = Math.floor(maxIndexBytes * STORAGE_TARGET_RATIO)
    let removed = 0
    try {
      while (liveStoredBytes > target) {
        const rows = listOldestDocs.all(PRUNE_BATCH_SIZE)
        if (rows.length === 0) break
        let batchBytes = 0
        let batchRemoved = 0
        const batchAffected = new Map<string, number>()
        const nextPrunedDocs = (): number => prunedDocs + batchRemoved
        sqlite.exec('BEGIN')
        try {
          for (const row of rows) {
            const rowid = row.rowid
            if (typeof rowid !== 'number' && typeof rowid !== 'bigint') continue
            deleteFtsRow.run(rowid)
            deleteDocRow.run(rowid)
            const sid = typeof row.session_id === 'string' ? row.session_id : ''
            if (sid !== '') batchAffected.set(sid, (batchAffected.get(sid) ?? 0) + 1)
            const bytes = Number(row.stored_bytes ?? 0)
            if (Number.isFinite(bytes) && bytes > 0) batchBytes += bytes
            batchRemoved += 1
            if (liveStoredBytes - batchBytes <= target) break
          }
          for (const [sessionId, count] of batchAffected) {
            sqlite.prepare('UPDATE session_state SET docs=MAX(0,docs-?) WHERE session_id=?').run(count, sessionId)
          }
          writeMeta.run('pruned_docs', String(nextPrunedDocs()))
          sqlite.exec('COMMIT')
        } catch (error) {
          try { sqlite.exec('ROLLBACK') } catch { /* no active transaction */ }
          throw error
        }
        if (batchRemoved <= 0 || batchBytes <= 0) break
        liveStoredBytes = Math.max(0, liveStoredBytes - batchBytes)
        for (const [sessionId, count] of batchAffected) {
          docCountBySession.set(sessionId, Math.max(0, (docCountBySession.get(sessionId) ?? 0) - count))
        }
        prunedDocs += batchRemoved
        removed += batchRemoved
        if (rows.length < PRUNE_BATCH_SIZE) break
      }
    } finally {
      // A later pruning batch may fail after earlier batches committed. Never
      // leave the in-process cache pointing at rows already durably removed.
      if (removed > 0) invalidateSearchCache()
    }
    if (removed === 0) return
    const budgetLabel = (maxIndexBytes ?? 0) >= 1048576
      ? `${Math.round((maxIndexBytes ?? 0) / 1048576)} MiB`
      : `${maxIndexBytes ?? 0} bytes`
    warn(
      `[memory-search] 索引达到 ${budgetLabel} 逻辑预算，` +
        `已淘汰 ${removed} 条最旧派生文档；原始会话未删除`,
    )
  }

  function searchImpl(query: string, options: SearchOptions = {}): SearchResult {
    if (typeof query !== 'string' || query.trim() === '') {
      // L8/契约：空查询友好空结果（不报 E_EMPTY_QUERY；ADR 已记录）
      return { ok: true, hits: [], truncated: false }
    }
    const normalizedQuery = query.trim()
    if (normalizedQuery.length > MAX_QUERY_CHARS) {
      return {
        ok: false,
        hits: [],
        truncated: false,
        error: `query exceeds ${MAX_QUERY_CHARS} characters`,
      }
    }
    // Stage 2 verifies literal query chunks, not index tokens. Requiring only
    // CJK singles/bigrams would accept reordered fragments that never contain
    // the requested substring. Punctuation remains a separator so
    // `search, chat` retains multi-keyword AND semantics.
    const terms = literalSearchTerms(normalizedQuery)
    if (terms.length === 0) return { ok: true, hits: [], truncated: false }
    const limit = normalizeLimit(options.limit)
    const surface = options.surface ?? 'all'
    const role = parseSearchRole(options.role)
    const cacheKey = `${generation}\u0000${normalizedQuery}\u0000${surface}\u0000${role}\u0000${limit}`
    const cached = searchCache.get(cacheKey)
    if (cached !== undefined) {
      searchCache.delete(cacheKey)
      searchCache.set(cacheKey, cached)
      return cloneResult(cached)
    }

    const hits: SearchHit[] = []
    let exhausted = false
    let scanned = 0
    try {
      const fts = buildFtsQuery(normalizedQuery)
      if (fts === '') return { ok: true, hits: [], truncated: false }
      const types = typesForRole(role)
      let sql = `SELECT ${HIT_COLUMNS} FROM ftsevents JOIN docs d ON d.rowid=ftsevents.rowid ` +
        'WHERE ftsevents MATCH ?'
      const fixedParams: unknown[] = [fts]
      if (surface !== 'all') {
        sql += ' AND d.surface = ?'
        fixedParams.push(surface)
      }
      if (types !== null) {
        if (types.length === 1) {
          sql += ' AND d.type = ?'
          fixedParams.push(types[0])
        } else {
          sql += ` AND d.type IN (${types.map(() => '?').join(',')})`
          fixedParams.push(...types)
        }
      }
      // rowid encodes a chronological minute bucket plus an intra-bucket slot,
      // so FTS can walk each posting list backwards and stop at top-k without
      // sorting the entire match set.
      sql += ' ORDER BY ftsevents.rowid DESC LIMIT ? OFFSET ?'
      const statement = sqlite.prepare(sql)
      let candidateBudget = Math.min(RECALL_LIMIT, Math.max(INITIAL_RECALL_LIMIT, limit * 2))
      const deadline = Date.now() + SEARCH_TIME_BUDGET_MS

      while (scanned < candidateBudget && hits.length <= limit) {
        const requested = candidateBudget - scanned
        const rows = statement.all(...fixedParams, requested, scanned)
        if (rows.length < requested) exhausted = true
        scanned += rows.length
        for (const row of rows) {
          const text = typeof row.text === 'string' ? row.text : ''
          const lower = text.toLowerCase()
          if (!terms.every((term) => lower.includes(term))) continue
          const time = typeof row.time === 'number' ? row.time : 0
          const seq = typeof row.seq === 'number' ? row.seq : 0
          hits.push(
            composeHit(
              {
                sessionId: String(row.session_id ?? ''),
                seq,
                type: String(row.type ?? ''),
                time,
                anchorKey: (row.anchor_key as string | null) ?? null,
                text: text.slice(0, MAX_TEXT),
                textTruncated: Number(row.text_truncated ?? 0) === 1,
              },
              normalizedQuery,
            ),
          )
          if (hits.length > limit) break
        }
        if (exhausted || hits.length > limit) break
        if (candidateBudget >= RECALL_LIMIT || Date.now() >= deadline) break
        candidateBudget = Math.min(RECALL_LIMIT, candidateBudget * 2)
      }
    } catch (error) {
      return {
        ok: false,
        hits: [],
        truncated: false,
        error: `search failed: ${error instanceof Error ? error.message : String(error)}`,
      }
    }
    hits.sort((a, b) => b.time - a.time || b.seq - a.seq)
    const result: SearchResult = {
      ok: true,
      hits: hits.slice(0, limit),
      truncated: hits.length > limit || !exhausted,
    }
    cacheResult(cacheKey, result)
    return cloneResult(result)
  }

  try {
    enforceStorageBudget()
  } catch (error) {
    warn(`[memory-search] 启动容量维护失败，将在后续写入重试: ${error instanceof Error ? error.message : String(error)}`)
  }

  return {
    ready: true,
    degraded: false,
    status(): IndexStatus {
      let indexedDocs = 0
      let indexedSessions = 0
      for (const row of listAllStateRows.all()) {
        if (typeof row.session_id !== 'string') continue
        indexedSessions += 1
        indexedDocs += typeof row.docs === 'number' ? row.docs : 0
      }
      return {
        ready: true,
        indexedSessions,
        indexedDocs,
        building: false,
        degraded: false,
        storageBytes: physicalStorageBytes(dbPath),
        storageLimitBytes: maxIndexBytes,
        prunedDocs,
        coverageSince: (() => {
          const value = minIndexedTime.get()?.n
          return typeof value === 'number' && Number.isFinite(value) ? value : null
        })(),
      }
    },
    upsertRecords(records, rebuildSessionIds = []): void {
      const rebuildIds = rebuildSessionIds ?? []
      validateRecords(records, rebuildIds)
      const rebuild = new Set(rebuildIds)
      // Cooperative rebuilds set dirty before the first transaction. Preserve
      // that marker through the delete+insert commit so a process exit between
      // batches cannot make a partial replacement look complete.
      const preserveDirty = new Set(
        rebuildIds.filter((sessionId) => Number(selectState.get(sessionId)?.dirty ?? 0) === 1),
      )
      const affected = new Set<string>(rebuild)
      for (const record of records) affected.add(record.sessionId)
      const mapSnapshot = new Map<string, { max: number | undefined; docs: number | undefined }>()
      for (const sessionId of affected) {
        mapSnapshot.set(sessionId, {
          max: maxSeqBySession.get(sessionId),
          docs: docCountBySession.get(sessionId),
        })
      }
      const bytesSnapshot = liveStoredBytes
      db.exec('BEGIN')
      try {
        for (const sessionId of rebuild) {
          deleteSessionRows(sessionId)
          deleteState.run(sessionId)
          maxSeqBySession.delete(sessionId)
          docCountBySession.delete(sessionId)
        }
        // 整个批次单事务：实测每会话边界 COMMIT ≈62ms/次（WAL，1000 会话
        // 批次 61.9s vs 单事务 3.73s @100k 行）——L5 语义不变（每个重建会话的
        // "先删后插"仍在同一事务内原子完成），生产调用路径本就每批次单会话。
        for (const record of records) {
          if (rebuild.has(record.sessionId) && record.surface === 'shadowed') continue
          upsertOne(record)
        }
        // 受影响会话重物化 state；cooperative rebuild 保留 dirty 到末批清理。
        for (const sessionId of affected) {
          refreshState(sessionId, preserveDirty.has(sessionId) ? 1 : 0)
        }
        db.exec('COMMIT')
        invalidateSearchCache()
      } catch (error) {
        try {
          db.exec('ROLLBACK')
        } catch {
          /* 已回滚 */
        }
        // The SQLite transaction rolled back, so restore its in-memory mirror
        // too. Disk-full/corruption failures must not poison later counts.
        for (const [sessionId, previous] of mapSnapshot) {
          if (previous.max === undefined) maxSeqBySession.delete(sessionId)
          else maxSeqBySession.set(sessionId, previous.max)
          if (previous.docs === undefined) docCountBySession.delete(sessionId)
          else docCountBySession.set(sessionId, previous.docs)
        }
        liveStoredBytes = bytesSnapshot
        throw error
      }
      try {
        enforceStorageBudget()
      } catch (error) {
        warn(`[memory-search] 索引容量维护失败，将在后续写入重试: ${error instanceof Error ? error.message : String(error)}`)
      }
    },
    removeSession(sessionId: string): void {
      if (typeof sessionId !== 'string' || sessionId.length === 0) return
      const bytesSnapshot = liveStoredBytes
      db.exec('BEGIN')
      try {
        deleteSessionRows(sessionId)
        deleteState.run(sessionId)
        db.exec('COMMIT')
      } catch (error) {
        try {
          db.exec('ROLLBACK')
        } catch {
          /* no active transaction */
        }
        liveStoredBytes = bytesSnapshot
        throw error
      }
      maxSeqBySession.delete(sessionId)
      docCountBySession.delete(sessionId)
      invalidateSearchCache()
    },
    search: searchImpl,
    close(): void {
      try {
        db.close()
      } catch {
        /* 已关闭 */
      }
    },
    /** Bounded FTS merge + checkpoint + incremental vacuum. Unlike `optimize`,
     * merge has a page-work budget and is suitable for periodic idle work. */
    optimize(): void {
      try {
        enforceStorageBudget()
      } catch {
        /* later writes retry budget enforcement */
      }
      try {
        db.exec("INSERT INTO ftsevents(ftsevents, rank) VALUES('merge', 64)")
      } catch {
        /* merge 失败不致命 */
      }
      try {
        db.exec('PRAGMA wal_checkpoint(TRUNCATE)')
      } catch {
        /* checkpoint 失败不致命 */
      }
      try {
        db.exec('PRAGMA incremental_vacuum(256)')
      } catch {
        /* pre-v3 databases may not have incremental auto-vacuum enabled */
      }
    },
    sessionState(sessionId: string): SessionStateRow | undefined {
      return readState(sessionId)
    },
    markSessionDirty(sessionId: string): void {
      try {
        const prev = selectState.get(sessionId)
        if (prev === undefined) {
          insertState.run(sessionId, -1, 1, null, 0)
        } else {
          insertState.run(sessionId, prev.max_seq, 1, prev.built_at, prev.docs)
        }
      } catch {
        /* 幂等 */
      }
    },
    clearSessionDirty(sessionId: string): void {
      try {
        const prev = selectState.get(sessionId)
        if (prev !== undefined) insertState.run(sessionId, prev.max_seq, 0, prev.built_at, prev.docs)
      } catch {
        /* 幂等 */
      }
    },
    advanceSessionWatermark(sessionId: string, maxSeq: number): void {
      if (typeof sessionId !== 'string' || sessionId.length === 0) return
      if (!Number.isSafeInteger(maxSeq) || maxSeq < -1) return
      const previous = maxSeqBySession.get(sessionId)
      if (maxSeq > (previous ?? -1)) maxSeqBySession.set(sessionId, maxSeq)
      try {
        refreshState(sessionId, 0)
      } catch (error) {
        if (previous === undefined) maxSeqBySession.delete(sessionId)
        else maxSeqBySession.set(sessionId, previous)
        throw error
      }
    },
    listSessionIds(): string[] {
      try {
        return listStateIds
          .all()
          .map((row) => row.session_id)
          .filter((sid): sid is string => typeof sid === 'string')
      } catch {
        return []
      }
    },
    beginBatch(): void {
      cacheBatchDepth += 1
    },
    endBatch(): void {
      if (cacheBatchDepth > 0) cacheBatchDepth -= 1
      if (cacheBatchDepth === 0 && pendingCacheInvalidation) {
        pendingCacheInvalidation = false
        generation += 1
        searchCache.clear()
      }
    },
  }
}

// ---------------------------------------------------------------------------
// 内存降级实现（node:sqlite 不可用 / 注入 sqliteModule:null）
// ---------------------------------------------------------------------------
function createMemoryIndex(warn: (msg: string) => void, maxIndexBytes: number | null): SearchIndex {
  const docs = new Map<string, Map<number, IndexRecord>>()
  const state = new Map<string, SessionStateRow>()
  /** Mirrors the SQLite stored_bytes accounting (text + tokens + row overhead)
   * so the degraded path honors the same logical budget as the file index.
   * Without this bound a large history could OOM the host process. */
  const bytesBySession = new Map<string, Map<number, number>>()
  let liveStoredBytes = 0
  let prunedDocsTotal = 0

  function estimateStoredBytes(text: string): number {
    const tokens = tokenize(text).join(' ')
    return Buffer.byteLength(text, 'utf8') + Buffer.byteLength(tokens, 'utf8') + 128
  }

  function trackInsert(sessionId: string, seq: number, bytes: number): void {
    let sessionBytes = bytesBySession.get(sessionId)
    if (sessionBytes === undefined) {
      sessionBytes = new Map()
      bytesBySession.set(sessionId, sessionBytes)
    }
    sessionBytes.set(seq, bytes)
    liveStoredBytes += bytes
  }

  function removeDoc(sessionId: string, seq: number): void {
    const sessionBytes = bytesBySession.get(sessionId)
    const bytes = sessionBytes?.get(seq)
    if (sessionBytes !== undefined && bytes !== undefined) {
      sessionBytes.delete(seq)
      liveStoredBytes -= bytes
      if (sessionBytes.size === 0) bytesBySession.delete(sessionId)
    }
  }

  /** Same policy as the file-backed index: once the logical budget is exceeded,
   * evict oldest derived docs down to the target ratio; source sessions are
   * untouched and a later rebuild refills everything. */
  function enforceStorageBudget(): void {
    if (maxIndexBytes === null || maxIndexBytes <= 0 || liveStoredBytes <= maxIndexBytes) return
    const target = Math.floor(maxIndexBytes * STORAGE_TARGET_RATIO)
    const flat: Array<{ sessionId: string; seq: number; time: number }> = []
    for (const [sessionId, bucket] of docs) {
      for (const [seq, record] of bucket) flat.push({ sessionId, seq, time: record.time })
    }
    flat.sort((a, b) => a.time - b.time)
    let removed = 0
    for (const item of flat) {
      if (liveStoredBytes <= target) break
      const bucket = docs.get(item.sessionId)
      if (bucket === undefined || !bucket.has(item.seq)) continue
      removeDoc(item.sessionId, item.seq)
      bucket.delete(item.seq)
      if (bucket.size === 0) docs.delete(item.sessionId)
      refreshState(item.sessionId)
      removed += 1
    }
    if (removed > 0) {
      prunedDocsTotal += removed
      warn(
        `[memory-search] 内存降级索引达到 ${Math.round(maxIndexBytes / 1048576)} MiB 预算，已淘汰 ${removed} 条最旧派生文档；原始会话未删除`,
      )
    }
  }

  function status(): IndexStatus {
    let indexedDocs = 0
    for (const row of state.values()) indexedDocs += row.docs
    let coverageSince: number | null = null
    for (const bucket of docs.values()) {
      for (const record of bucket.values()) {
        if (coverageSince === null || record.time < coverageSince) coverageSince = record.time
      }
    }
    return {
      ready: true,
      indexedSessions: state.size,
      indexedDocs,
      building: false,
      degraded: true,
      storageBytes: liveStoredBytes,
      storageLimitBytes: maxIndexBytes,
      prunedDocs: prunedDocsTotal,
      coverageSince,
    }
  }

  function refreshState(sessionId: string): void {
    const bucket = docs.get(sessionId)
    if (bucket === undefined || bucket.size === 0) {
      state.delete(sessionId)
      return
    }
    let maxSeq = -1
    for (const seq of bucket.keys()) maxSeq = Math.max(maxSeq, seq)
    const prev = state.get(sessionId)
    state.set(sessionId, {
      sessionId,
      maxSeq: Math.max(prev?.maxSeq ?? -1, maxSeq),
      dirty: prev?.dirty ?? 0,
      builtAt: prev?.builtAt ?? Date.now(),
      docs: bucket.size,
    })
  }

  function searchImpl(query: string, options: SearchOptions = {}): SearchResult {
    if (typeof query !== 'string' || query.trim() === '') {
      return { ok: true, hits: [], truncated: false }
    }
    const normalizedQuery = query.trim()
    if (normalizedQuery.length > MAX_QUERY_CHARS) {
      return {
        ok: false,
        hits: [],
        truncated: false,
        error: `query exceeds ${MAX_QUERY_CHARS} characters`,
      }
    }
    const terms = literalSearchTerms(normalizedQuery)
    if (terms.length === 0) return { ok: true, hits: [], truncated: false }
    const rawLimit = options.limit
    const limit = rawLimit === undefined || !Number.isFinite(rawLimit) || rawLimit <= 0
      ? DEFAULT_SEARCH_LIMIT
      : Math.min(MAX_SEARCH_LIMIT, Math.max(1, Math.floor(rawLimit)))
    const surface = options.surface ?? 'all'
    const role = parseSearchRole(options.role)

    const candidates: IndexRecord[] = []
    for (const bucket of docs.values()) {
      for (const record of bucket.values()) {
        if (surface !== 'all' && record.surface !== surface) continue
        if (!typeMatchesRole(record.type, role)) continue
        const lower = record.text.toLowerCase()
        if (terms.every((term) => lower.includes(term))) candidates.push(record)
      }
    }
    candidates.sort((a, b) => b.time - a.time || b.seq - a.seq)
    const candidatesHit = candidates
      .slice(0, limit + 1)
      .map((record) => composeHit(record, normalizedQuery))
    return { ok: true, hits: candidatesHit.slice(0, limit), truncated: candidatesHit.length > limit }
  }

  return {
    ready: true,
    degraded: true,
    status,
    upsertRecords(records, rebuildSessionIds = []): void {
      const rebuildIds = rebuildSessionIds ?? []
      for (const sessionId of rebuildIds) {
        if (typeof sessionId !== 'string' || sessionId.length === 0) {
          throw new TypeError('rebuild session id must be a non-empty string')
        }
      }
      for (const record of records) {
        if (record === null || typeof record !== 'object') throw new TypeError('index record must be an object')
        if (typeof record.sessionId !== 'string' || record.sessionId.length === 0) {
          throw new TypeError('index record sessionId must be a non-empty string')
        }
        if (!Number.isSafeInteger(record.seq) || record.seq < 0) {
          throw new TypeError('index record seq must be a non-negative safe integer')
        }
        if (typeof record.type !== 'string' || typeof record.text !== 'string') {
          throw new TypeError('index record type/text must be strings')
        }
        if (!Number.isFinite(record.time)) throw new TypeError('index record time must be finite')
        if (!['current', 'shadowed', 'log-only'].includes(record.surface)) {
          throw new TypeError(`invalid index record surface: ${String(record.surface)}`)
        }
        if (record.anchorKey !== null && typeof record.anchorKey !== 'string') {
          throw new TypeError('index record anchorKey must be a string or null')
        }
      }
      const rebuild = new Set(rebuildIds)
      const preserveDirty = new Set(
        rebuildIds.filter((sessionId) => state.get(sessionId)?.dirty === 1),
      )
      for (const sessionId of rebuild) {
        const existing = docs.get(sessionId)
        if (existing !== undefined) {
          for (const seq of existing.keys()) removeDoc(sessionId, seq)
        }
        docs.delete(sessionId)
        bytesBySession.delete(sessionId)
        state.set(sessionId, {
          sessionId,
          maxSeq: -1,
          dirty: preserveDirty.has(sessionId) ? 1 : 0,
          builtAt: Date.now(),
          docs: 0,
        })
      }
      for (const record of records) {
        if (rebuild.has(record.sessionId) && record.surface === 'shadowed') continue
        let bucket = docs.get(record.sessionId)
        if (bucket === undefined) {
          bucket = new Map()
          docs.set(record.sessionId, bucket)
        }
        const bounded = boundIndexText(record.text, record.type)
        if (bucket.has(record.seq)) removeDoc(record.sessionId, record.seq)
        const stored: IndexRecord = {
          ...record,
          text: bounded.text,
          textTruncated: bounded.truncated || record.textTruncated === true,
        }
        bucket.set(record.seq, stored)
        trackInsert(record.sessionId, record.seq, estimateStoredBytes(stored.text))
        refreshState(record.sessionId)
      }
      enforceStorageBudget()
    },
    removeSession(sessionId: string): void {
      const bucket = docs.get(sessionId)
      if (bucket !== undefined) for (const seq of bucket.keys()) removeDoc(sessionId, seq)
      docs.delete(sessionId)
      state.delete(sessionId)
    },
    search: searchImpl,
    close(): void {
      docs.clear()
      state.clear()
      bytesBySession.clear()
      liveStoredBytes = 0
    },
    optimize(): void {
      /* 内存降级无可回收磁盘空间 */
    },
    sessionState(sessionId: string): SessionStateRow | undefined {
      return state.get(sessionId)
    },
    markSessionDirty(sessionId: string): void {
      const prev = state.get(sessionId)
      state.set(sessionId, {
        sessionId,
        maxSeq: prev?.maxSeq ?? -1,
        dirty: 1,
        builtAt: prev?.builtAt ?? null,
        docs: prev?.docs ?? 0,
      })
    },
    clearSessionDirty(sessionId: string): void {
      const prev = state.get(sessionId)
      if (prev !== undefined) state.set(sessionId, { ...prev, dirty: 0 })
    },
    advanceSessionWatermark(sessionId: string, maxSeq: number): void {
      if (typeof sessionId !== 'string' || sessionId.length === 0) return
      if (!Number.isSafeInteger(maxSeq) || maxSeq < -1) return
      const prev = state.get(sessionId)
      const bucket = docs.get(sessionId)
      state.set(sessionId, {
        sessionId,
        maxSeq: Math.max(prev?.maxSeq ?? -1, maxSeq),
        dirty: prev?.dirty ?? 0,
        builtAt: prev?.builtAt ?? Date.now(),
        docs: bucket?.size ?? 0,
      })
    },
    listSessionIds(): string[] {
      return [...state.keys()]
    },
    beginBatch(): void {
      /* in-memory fallback has no query cache */
    },
    endBatch(): void {
      /* in-memory fallback has no query cache */
    },
  }
}

// ---------------------------------------------------------------------------
// 工厂
// ---------------------------------------------------------------------------
export interface CreateSearchIndexOptions {
  dbPath?: string
  /** 测试注入：null 模拟 node:sqlite 不可用；缺省用模块级动态加载结果。 */
  sqliteModule?: unknown
  warn?: (msg: string) => void
  /** Logical payload budget. `0`/`null` disables pruning. Primarily exposed
   * for tests and embedders; end users normally use the MiB environment var. */
  maxIndexBytes?: number | null
}

export const COOPERATIVE_WRITE_BATCH = 256

/**
 * Production write path for large rebuilds. Each SQLite transaction stays
 * small enough to bound event-loop stalls; a persistent dirty marker makes
 * the non-atomic multi-batch replacement crash-recoverable and idempotent.
 * Direct `upsertRecords()` remains atomic for small batches and unit callers.
 */
export async function upsertRecordsCooperatively(
  index: SearchIndex,
  records: IndexRecord[],
  rebuildSessionIds: string[] = [],
  batchSize = COOPERATIVE_WRITE_BATCH,
): Promise<void> {
  const size = Number.isFinite(batchSize) ? Math.max(1, Math.floor(batchSize)) : COOPERATIVE_WRITE_BATCH
  if (records.length <= size) {
    await index.upsertRecords(records, rebuildSessionIds)
    return
  }
  index.beginBatch()
  try {
    for (const sessionId of rebuildSessionIds) index.markSessionDirty(sessionId)
    for (let offset = 0; offset < records.length; offset += size) {
      const first = offset === 0
      await index.upsertRecords(records.slice(offset, offset + size), first ? rebuildSessionIds : [])
      for (const sessionId of rebuildSessionIds) index.markSessionDirty(sessionId)
      await new Promise<void>((resolve) => { setImmediate(resolve) })
    }
    for (const sessionId of rebuildSessionIds) index.clearSessionDirty(sessionId)
  } finally {
    index.endBatch()
  }
}

function configuredMaxIndexBytes(override: number | null | undefined): number | null {
  if (override === null || override === 0) return null
  if (typeof override === 'number' && Number.isFinite(override) && override > 0) {
    return Math.max(1, Math.floor(override))
  }
  const raw = process.env.DSH_MEMORY_SEARCH_MAX_INDEX_MB
  if (raw === '0') return null
  if (raw !== undefined) {
    const mb = Number(raw)
    if (Number.isFinite(mb) && mb > 0) {
      return Math.floor(Math.min(16_384, Math.max(64, mb)) * 1048576)
    }
  }
  return DEFAULT_MAX_INDEX_BYTES
}

export function createSearchIndex(options: CreateSearchIndexOptions = {}): SearchIndex {
  const warn = options.warn ?? ((msg: string) => console.warn(msg))
  const dbPath = options.dbPath ?? defaultDbPath()

  const DatabaseSync = resolveDatabaseSync(
    options.sqliteModule !== undefined ? options.sqliteModule : SQLITE_MODULE,
  )

  if (DatabaseSync === null) {
    warn('[memory-search] node:sqlite 不可用，降级为内存索引（不持久化，仅本地搜索）')
    return createMemoryIndex(warn, configuredMaxIndexBytes(options.maxIndexBytes))
  }

  return createSqliteIndex(dbPath, DatabaseSync, warn, configuredMaxIndexBytes(options.maxIndexBytes))
}
