/**
 * Index database path resolution.
 *
 * The live SQLite file can move; the chosen location is stored separately at
 * `${DSH_HOME}/storages/memory-search/location.json` so the next startup can
 * still find it. Changing the path copies the live database (and WAL sidecars)
 * then deletes the old files. Resolution order:
 *   1. persisted location.json
 *   2. env DSH_MEMORY_SEARCH_DB
 *   3. plugin config `dbPath`
 *   4. `${DSH_HOME}/storages/memory-search/index.db`
 */

import { copyFileSync, existsSync, mkdirSync, readFileSync, statSync, unlinkSync, writeFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const INDEX_FILE_NAME = 'index.db'
const LOCATION_FILE_NAME = 'location.json'
const MAX_PATH_LENGTH = 4096
const SQLITE_SUFFIXES = ['', '-wal', '-shm'] as const

export type NormalizeDbPathResult =
  | { ok: true; path: string }
  | { ok: false; error: string }

export function dshHome(): string {
  const override = process.env.DSH_HOME
  if (typeof override === 'string' && override.trim().length > 0) return override
  return path.join(os.homedir(), '.dsh')
}

export function defaultIndexDbPath(): string {
  return path.join(dshHome(), 'storages', 'memory-search', INDEX_FILE_NAME)
}

export function indexLocationFilePath(): string {
  return path.join(dshHome(), 'storages', 'memory-search', LOCATION_FILE_NAME)
}

export function expandUserPath(input: string): string {
  const trimmed = input.trim()
  if (trimmed === '~') return os.homedir()
  if (trimmed.startsWith('~/') || trimmed.startsWith('~\\')) {
    return path.join(os.homedir(), trimmed.slice(2))
  }
  return trimmed
}

export function normalizeUserDbPath(input: string): NormalizeDbPathResult {
  if (typeof input !== 'string') return { ok: false, error: '路径必须是字符串' }
  const trimmed = input.trim()
  if (trimmed.length === 0) return { ok: false, error: '路径不能为空' }
  if (trimmed.includes('\0')) return { ok: false, error: '路径包含非法字符' }
  if (trimmed.length > MAX_PATH_LENGTH) return { ok: false, error: '路径过长' }
  const lowered = trimmed.toLowerCase()
  if (lowered === ':memory:' || lowered.startsWith('file:')) {
    return { ok: false, error: '请指定本地文件路径' }
  }
  const expanded = expandUserPath(trimmed)
  if (!path.isAbsolute(expanded)) {
    return { ok: false, error: '请使用绝对路径' }
  }
  const resolved = path.resolve(expanded)
  try {
    if (existsSync(resolved)) {
      const st = statSync(resolved)
      if (st.isDirectory()) return { ok: true, path: path.join(resolved, INDEX_FILE_NAME) }
      if (st.isFile()) return { ok: true, path: resolved }
      return { ok: false, error: '路径不是普通文件或目录' }
    }
  } catch {
    return { ok: false, error: '无法访问该路径' }
  }
  if (trimmed.endsWith('/') || trimmed.endsWith('\\') || trimmed.endsWith(path.sep)) {
    return { ok: true, path: path.join(resolved, INDEX_FILE_NAME) }
  }
  const ext = path.extname(resolved).toLowerCase()
  if (ext === '.db' || ext === '.sqlite' || ext === '.sqlite3') {
    return { ok: true, path: resolved }
  }
  return { ok: true, path: path.join(resolved, INDEX_FILE_NAME) }
}

export function readPersistedDbPath(): string | undefined {
  const file = indexLocationFilePath()
  try {
    if (!existsSync(file)) return undefined
    const parsed = JSON.parse(readFileSync(file, 'utf8')) as { dbPath?: unknown }
    if (typeof parsed.dbPath !== 'string') return undefined
    const normalized = normalizeUserDbPath(parsed.dbPath)
    return normalized.ok ? normalized.path : undefined
  } catch {
    return undefined
  }
}

export function writePersistedDbPath(dbPath: string): void {
  const file = indexLocationFilePath()
  mkdirSync(path.dirname(file), { recursive: true })
  if (path.resolve(dbPath) === path.resolve(defaultIndexDbPath())) {
    try {
      unlinkSync(file)
    } catch {
      /* no persisted override */
    }
    return
  }
  writeFileSync(file, `${JSON.stringify({ dbPath: path.resolve(dbPath) }, null, 2)}\n`, 'utf8')
}

export function ensureIndexDbDirectory(dbPath: string): NormalizeDbPathResult {
  try {
    mkdirSync(path.dirname(dbPath), { recursive: true })
    return { ok: true, path: dbPath }
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) }
  }
}

export function sameIndexPath(left: string, right: string): boolean {
  return path.resolve(left) === path.resolve(right)
}

export function indexSidecarPaths(dbPath: string): string[] {
  const resolved = path.resolve(dbPath)
  return SQLITE_SUFFIXES.map((suffix) => `${resolved}${suffix}`)
}

function ioError(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

export type CopyIndexResult =
  | { ok: true; path: string; copied: boolean }
  | { ok: false; error: string }

/**
 * Copy the SQLite main file and WAL/SHM sidecars to `toPath`. Source files
 * are left in place until the caller has opened and verified the destination.
 * Stale destination sidecars are removed so a leftover `-wal` cannot replay
 * against a different main file.
 */
export function copyIndexDatabase(fromPath: string, toPath: string): CopyIndexResult {
  const from = path.resolve(fromPath)
  const to = path.resolve(toPath)
  const prepared = ensureIndexDbDirectory(to)
  if (!prepared.ok) return prepared
  if (from === to) return { ok: true, path: to, copied: false }
  try {
    let copiedMain = false
    for (const suffix of SQLITE_SUFFIXES) {
      const src = `${from}${suffix}`
      const dest = `${to}${suffix}`
      if (existsSync(src)) {
        copyFileSync(src, dest)
        if (suffix === '') copiedMain = true
      } else if (suffix !== '' && existsSync(dest)) {
        unlinkSync(dest)
      }
    }
    if (copiedMain && !existsSync(to)) {
      return { ok: false, error: '复制后未找到目标数据库文件' }
    }
    return { ok: true, path: to, copied: copiedMain }
  } catch (error) {
    return { ok: false, error: ioError(error) }
  }
}

export function indexDatabaseFileExists(dbPath: string): boolean {
  return existsSync(path.resolve(dbPath))
}

export function removeIndexDatabaseFiles(dbPath: string): string[] {
  const remaining: string[] = []
  for (const file of indexSidecarPaths(dbPath)) {
    try {
      if (existsSync(file)) unlinkSync(file)
    } catch {
      if (existsSync(file)) remaining.push(file)
    }
  }
  return remaining
}

export function resolveIndexDbPath(options: { configPath?: string } = {}): string {
  const persisted = readPersistedDbPath()
  if (persisted !== undefined) return persisted
  const env = process.env.DSH_MEMORY_SEARCH_DB
  if (typeof env === 'string' && env.trim().length > 0) {
    const normalized = normalizeUserDbPath(env)
    if (normalized.ok) return normalized.path
  }
  const config = options.configPath
  if (typeof config === 'string' && config.trim().length > 0) {
    const normalized = normalizeUserDbPath(config)
    if (normalized.ok) return normalized.path
  }
  return defaultIndexDbPath()
}
