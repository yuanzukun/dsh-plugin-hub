import { MAX_INDEX_TEXT_CHARS, MAX_TOOL_INDEX_TEXT_CHARS } from './types.ts'

const OMITTED = '\n… [middle omitted from search index] …\n'
const OPAQUE_RUN = /[A-Za-z0-9+/=_-]{512,}/gu

export interface BoundedIndexText {
  text: string
  truncated: boolean
}

function budgetFor(type: string): number {
  return type.startsWith('tool/') || type === 'turn/end'
    ? MAX_TOOL_INDEX_TEXT_CHARS
    : MAX_INDEX_TEXT_CHARS
}

/**
 * Build the searchable representation of an event.
 *
 * Long payloads keep both ends: tool names/commands normally occur at the
 * front while compiler/runtime failures normally occur at the end. Opaque
 * base64/hash-like runs are replaced after sampling so a pasted binary blob
 * cannot dominate tokenization or the database.
 */
export function boundIndexText(input: string, type: string): BoundedIndexText {
  if (typeof input !== 'string' || input.length === 0) return { text: '', truncated: false }
  const budget = budgetFor(type)
  const normalized = input.replaceAll('\u0000', '\ufffd')
  let sampled = normalized
  let truncated = normalized.length > budget
  if (truncated) {
    const available = Math.max(0, budget - OMITTED.length)
    const head = Math.ceil(available / 2)
    const tail = available - head
    sampled = `${normalized.slice(0, head)}${OMITTED}${tail > 0 ? normalized.slice(-tail) : ''}`
  }
  const scrubbed = sampled.replace(OPAQUE_RUN, '[opaque payload omitted]')
  if (scrubbed !== sampled) truncated = true
  // Replacement can only shrink today, but keep the API safe if the marker is
  // changed in the future.
  return {
    text: scrubbed.length > budget ? scrubbed.slice(0, budget) : scrubbed,
    truncated,
  }
}
