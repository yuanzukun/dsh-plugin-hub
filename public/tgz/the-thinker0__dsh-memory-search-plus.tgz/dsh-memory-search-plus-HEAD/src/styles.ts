/**
 * dsh-memory-search-plus — plugin-owned styles.
 *
 * One manually installed `<style data-plugin-css="memory-search-plus">`
 * tag (installed via ensureStyles, disposer removes it). Colors and
 * surfaces use the shell's `--dsw-alias-*` theme variables so the UI
 * follows the active theme instead of hard-coding values.
 */

export const STYLES = `
/* ---------- sidebar entrance pill ---------- */
/* VISUAL-DIAGNOSIS §3(b)/(c): ChatGPT-style pseudo-input button (wide) and a
   36×36 centered icon square (rail). */
.msp-pill {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  gap: 8px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127,127,127,0.25));
  border-radius: 10px;
  background: var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.06));
  color: var(--dsw-alias-label-secondary, inherit);
  cursor: pointer;
  user-select: none;
}
.msp-pill-wide {
  flex: none;
  width: auto;
  align-self: stretch;
  margin: 0 2px 8px;
  padding: 0 12px;
  height: 38px;
  font: 14px/22px sans-serif;
  border-radius: 12px;
}
.msp-pill-wide:hover {
  border-color: var(--dsw-alias-brand-primary, #4c8dff);
  background: var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.1));
  color: var(--dsw-alias-label-secondary, inherit);
}
.msp-pill-icon { display: inline-flex; flex: none; color: var(--dsw-alias-label-secondary, inherit); }
.msp-pill-wide:hover .msp-pill-icon { color: var(--dsw-alias-label-secondary, inherit); }
.msp-pill-label {
  flex: 1;
  min-width: 0;
  text-align: left;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--dsw-alias-label-secondary, inherit);
}
.msp-pill-wide:hover .msp-pill-label { color: var(--dsw-alias-label-secondary, inherit); }
.msp-pill-kbd {
  flex: none;
  padding: 1px 5px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127,127,127,0.25));
  border-radius: 4px;
  font-size: 10px;
  line-height: 14px;
  color: var(--dsw-alias-label-secondary, inherit);
}
@media (max-width: 260px) {
  .msp-pill-wide .msp-pill-kbd { display: none; }
}
.msp-pill-rail {
  flex: none;
  width: 36px;
  height: 36px;
  margin: 0 auto 10px;
  justify-content: center;
}
.msp-pill-rail:hover {
  border-color: var(--dsw-alias-brand-primary, #4c8dff);
  color: var(--dsw-alias-brand-primary, #4c8dff);
}
/* Plugin-owned portal container beside the workspace region (created and
   removed by the pill itself; never inside React's managed subtree). */
.msp-pill-anchor { display: block; flex: none; align-self: stretch; }

/* §4c 弱化层：主题无第三级标签色 → 用第二级 label 色 + opacity .65
   （placeholder/辅助文字/时间戳等最弱层次）；hover 恢复全亮。 */
.msp-pill-icon,
.msp-pill-label,
.msp-pill-kbd,
.msp-close-btn,
.msp-search-icon,
.msp-search-input::placeholder,
.msp-status-searching,
.msp-empty,
.msp-group-time,
.msp-hit-static .msp-hit-text,
.msp-hit-time {
  opacity: 0.65;
}
.msp-pill-wide:hover .msp-pill-icon,
.msp-pill-wide:hover .msp-pill-label,
.msp-close-btn:hover { opacity: 1; }

/* ---------- floating panel (portaled to document.body) ---------- */
.msp-overlay-layer {
  position: fixed;
  inset: 0;
  z-index: 10000;
  pointer-events: none;
}
.msp-overlay-root {
  position: absolute;
  top: clamp(48px, 12vh, 96px);
  left: 50%;
  transform: translateX(-50%);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: min(560px, calc(100vw - 24px));
  max-height: min(70vh, calc(100vh - 96px));
  padding: 14px 16px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127,127,127,0.25));
  border-radius: 14px;
  background: var(--dsw-alias-bg-overlay, #1e1e24);
  color: var(--dsw-alias-label-primary, inherit);
  box-shadow: 0 16px 48px rgba(0, 0, 0, 0.45), 0 2px 8px rgba(0, 0, 0, 0.3);
  pointer-events: auto;
}
@media (max-width: 900px) {
  .msp-overlay-root { left: 12px; right: 12px; width: auto; transform: none; }
  .msp-overlay-root.msp-overlay-moved { right: auto; }
}
.msp-panel-header {
  display: flex; align-items: center; gap: 8px;
  cursor: grab; user-select: none; touch-action: none;
}
.msp-overlay-dragging,
.msp-overlay-dragging .msp-panel-header { cursor: grabbing; }
.msp-panel-title { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: 600 14px/20px sans-serif; }
.msp-close-btn {
  display: inline-flex; align-items: center; justify-content: center;
  width: 24px; height: 24px; padding: 0;
  border: 1px solid transparent; border-radius: 8px;
  background: transparent; color: var(--dsw-alias-label-secondary, inherit);
  cursor: pointer;
}
.msp-close-btn:hover { background: var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.08)); color: var(--dsw-alias-label-primary, inherit); }
.msp-search-row {
  display: flex; align-items: center; gap: 8px;
  padding: 8px 10px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127,127,127,0.25));
  border-radius: 10px;
  background: var(--dsw-alias-bg-layer-1, transparent);
}
.msp-search-row:focus-within { border-color: var(--dsw-alias-brand-primary, #4c8dff); }
.msp-search-icon { flex: none; color: var(--dsw-alias-label-secondary, inherit); }
.msp-search-input {
  flex: 1; min-width: 0;
  border: 0; outline: none; background: transparent;
  color: var(--dsw-alias-label-primary, inherit);
  font: 14px/20px sans-serif;
}
.msp-search-input::placeholder { color: var(--dsw-alias-label-secondary, inherit); }
.msp-banner { padding: 6px 10px; border-radius: 8px; font-size: 12px; line-height: 16px; }
.msp-banner-indexing { border: 1px solid var(--dsw-alias-border-l2, rgba(127,127,127,0.25)); background: var(--dsw-alias-bg-layer-1, transparent); color: var(--dsw-alias-label-secondary, inherit); }
.msp-banner-error { border: 1px solid var(--dsw-alias-state-error-primary, #e5484d); color: var(--dsw-alias-state-error-primary, #e5484d); }
.msp-banner-degraded { border: 1px solid var(--dsw-alias-state-warn-primary, #f5a623); color: var(--dsw-alias-state-warn-primary, #f5a623); }
.msp-status { flex: none; font-size: 12px; line-height: 16px; color: var(--dsw-alias-label-secondary, inherit); }
.msp-status-searching { color: var(--dsw-alias-label-secondary, inherit); }
.msp-status-error { color: var(--dsw-alias-state-error-primary, #e5484d); }
.msp-chips { flex: none; display: flex; gap: 6px; flex-wrap: wrap; }
.msp-chip {
  padding: 3px 10px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127,127,127,0.25));
  border-radius: 999px;
  background: var(--dsw-alias-bg-layer-1, transparent);
  color: var(--dsw-alias-label-secondary, inherit);
  font: 12px/18px sans-serif;
  cursor: pointer;
}
.msp-chip:hover { border-color: var(--dsw-alias-brand-primary, #4c8dff); color: var(--dsw-alias-label-primary, inherit); }
.msp-chip-active {
  border-color: var(--dsw-alias-brand-primary, #4c8dff);
  background: var(--dsw-alias-brand-primary, #4c8dff);
  color: var(--dsw-alias-bg-base, #ffffff);
}
.msp-toast {
  flex: none;
  padding: 8px 10px;
  border: 1px solid var(--dsw-alias-state-warn-primary, #f5a623);
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-1, transparent);
  color: var(--dsw-alias-state-warn-primary, #f5a623);
  font-size: 12px; line-height: 16px;
}
.msp-groups { flex: 1 1 auto; min-height: 0; overflow-y: auto; display: flex; flex-direction: column; gap: 12px; }
.msp-empty { padding: 24px 0; text-align: center; font-size: 13px; color: var(--dsw-alias-label-secondary, inherit); }
.msp-empty-error { color: var(--dsw-alias-state-error-primary, #e5484d); }
.msp-group { display: flex; flex-direction: column; gap: 6px; }
.msp-group-header { display: flex; align-items: baseline; gap: 10px; }
.msp-group-title { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: 600 13px/18px sans-serif; color: var(--dsw-alias-label-primary, inherit); }
.msp-group-time { flex: none; font-size: 11px; color: var(--dsw-alias-label-secondary, inherit); }
.msp-hit-list { margin: 0; padding: 0; list-style: none; display: flex; flex-direction: column; gap: 4px; }
.msp-hit {
  display: flex; align-items: flex-start; gap: 8px; width: 100%;
  padding: 7px 8px; text-align: left;
  border: 1px solid transparent; border-radius: 8px;
  background: transparent; color: var(--dsw-alias-label-primary, inherit);
  cursor: pointer;
}
.msp-hit:hover { background: var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.08)); border-color: var(--dsw-alias-border-l2, rgba(127,127,127,0.25)); }
.msp-hit-busy, .msp-hit:disabled { opacity: 0.55; cursor: default; }
.msp-hit-static { cursor: default; }
.msp-hit-static .msp-hit-role { opacity: 0.65; }
.msp-hit-static .msp-hit-text { color: var(--dsw-alias-label-secondary, inherit); }
.msp-hit-role {
  flex: none; margin-top: 1px; padding: 1px 6px;
  border-radius: 6px; font-size: 10px; line-height: 14px;
  background: var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.15));
  color: var(--dsw-alias-label-secondary, inherit);
}
.msp-role-user { color: var(--dsw-alias-brand-primary, #4c8dff); }
.msp-role-assistant { color: var(--dsw-alias-state-success-primary, #46a758); }
.msp-role-tool { color: var(--dsw-alias-state-warn-primary, #f5a623); }
.msp-role-other { color: var(--dsw-alias-brand-primary, #4c8dff); }
/* 用户验收反馈：用户/Agent 命中行加左侧色条，扫一眼即区分谁说的。 */
.msp-hit-user { box-shadow: inset 3px 0 0 0 var(--dsw-alias-brand-primary, #4c8dff); }
.msp-hit-assistant { box-shadow: inset 3px 0 0 0 var(--dsw-alias-state-success-primary, #46a758); }
.msp-hit-tool { box-shadow: inset 3px 0 0 0 var(--dsw-alias-state-warn-primary, #f5a623); }
.msp-hit-other { box-shadow: inset 3px 0 0 0 var(--dsw-alias-border-l2, rgba(127,127,127,0.35)); }
.msp-hit-text {
  flex: 1 1 auto; min-width: 0;
  display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 3; overflow: hidden;
  font-size: 12px; line-height: 18px;
  color: var(--dsw-alias-label-secondary, inherit);
  overflow-wrap: anywhere;
}
/* 用户验收反馈：实底 brand 高亮在深色主题下呈"白花花方块"——改为半透明
 * 品牌浸染 + 原文字色（label-primary），柔和且对比可读。 */
.msp-mark {
  padding: 0 1px; margin: 0 -1px; border-radius: 3px;
  background: color-mix(in srgb, var(--dsw-alias-brand-primary, #4c8dff) 32%, transparent);
  color: var(--dsw-alias-label-primary, inherit);
  outline: 1px solid color-mix(in srgb, var(--dsw-alias-brand-primary, #4c8dff) 45%, transparent);
}
.msp-hit-side { flex: none; display: flex; flex-direction: column; align-items: flex-end; gap: 2px; }
.msp-hit-time { font-size: 10px; color: var(--dsw-alias-label-secondary, inherit); white-space: nowrap; }
.msp-hit-matches { font-size: 10px; color: var(--dsw-alias-state-success-primary, #46a758); white-space: nowrap; }
.msp-hit-truncated { font-size: 10px; color: var(--dsw-alias-label-secondary, inherit); white-space: nowrap; }

/* ---------- in-conversation target flash + text marks ---------- */
[data-mhsp-target] { border-radius: 8px; animation: msp-target 1.2s ease-out; }
@keyframes msp-target {
  from { outline: 2px solid var(--dsw-alias-brand-primary, #4c8dff); outline-offset: 4px; background: color-mix(in srgb, var(--dsw-alias-brand-primary, #4c8dff) 12%, transparent); }
  to { outline: 2px solid transparent; outline-offset: 10px; background: transparent; }
}
/* CSS Custom Highlight for the in-conversation query match (jump.tsx):
   ranges live in the Highlight registry, no DOM nodes are touched. */
/* CSS Custom Highlight for the in-conversation query match (jump.tsx):
   ranges live in the Highlight registry, no DOM nodes are touched.
   同 .msp-mark：半透明品牌浸染，深色主题下不再"白花花"。 */
::highlight(dsh-msp) {
  background: color-mix(in srgb, var(--dsw-alias-brand-primary, #4c8dff) 32%, transparent);
  color: var(--dsw-alias-label-primary, inherit);
}
@media (prefers-reduced-motion: reduce) {
  [data-mhsp-target] { animation: none; outline: 2px solid var(--dsw-alias-brand-primary, #4c8dff); outline-offset: 4px; }
}

/* ---------- settings section ---------- */
.msp-settings { display: flex; flex-direction: column; gap: 10px; max-width: 640px; padding: 4px 0; }
.msp-settings-hint { margin: 0; color: var(--dsw-alias-label-secondary, inherit); font-size: 12px; line-height: 18px; }
.msp-settings-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
.msp-settings-status { font-size: 12px; line-height: 16px; }
.msp-settings-status-ready { color: var(--dsw-alias-state-success-primary, #46a758); }
.msp-settings-status-indexing { color: var(--dsw-alias-state-warn-primary, #f5a623); }
.msp-settings-status-degraded { color: var(--dsw-alias-state-warn-primary, #f5a623); }
.msp-settings-status-error { color: var(--dsw-alias-state-error-primary, #e5484d); }
.msp-settings-action {
  flex: none; padding: 5px 14px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127,127,127,0.25));
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.08));
  color: var(--dsw-alias-label-primary, inherit);
  font: inherit; cursor: pointer;
}
.msp-settings-action:hover:not(:disabled) { border-color: var(--dsw-alias-brand-primary, #4c8dff); }
.msp-settings-action:disabled { opacity: 0.5; cursor: default; }
.msp-settings-path { display: flex; flex-direction: column; gap: 6px; }
.msp-settings-path-label { font-size: 12px; line-height: 16px; color: var(--dsw-alias-label-primary, inherit); }
.msp-settings-path-row { display: flex; align-items: center; gap: 8px; }
.msp-settings-path-input {
  flex: 1; min-width: 0; padding: 5px 8px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127,127,127,0.25));
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.08));
  color: var(--dsw-alias-label-primary, inherit);
  font: inherit; font-size: 12px;
}
.msp-settings-path-input:focus {
  outline: none;
  border-color: var(--dsw-alias-brand-primary, #4c8dff);
}
.msp-settings-path-input:disabled { opacity: 0.5; }
.msp-settings-path-actions { display: flex; gap: 8px; flex-wrap: wrap; }
.msp-settings-progress {
  height: 4px; border-radius: 999px;
  background: var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.12));
  overflow: hidden;
}
.msp-settings-progress > span {
  display: block; height: 100%;
  background: var(--dsw-alias-brand-primary, #4c8dff);
  transition: width 0.2s ease-out;
}
.msp-settings-notice { margin: 0; font-size: 12px; color: var(--dsw-alias-state-success-primary, #46a758); }
.msp-settings-notice-failed { color: var(--dsw-alias-state-error-primary, #e5484d); }
`

/** Install plugin-owned styles (idempotent); returns the disposer. */
/**
 * Install plugin-owned styles (idempotent — repeated calls reuse the
 * existing tag) and return a disposer that only removes the tag when it is
 * still connected to the document, so an owner whose fiber outlives a
 * re-created tag never orphans or double-removes it.
 */
export function ensureStyles(): () => void {
  const tagId = 'memory-search-plus'
  const prior = document.querySelector<HTMLStyleElement>(`style[data-plugin-css=${JSON.stringify(tagId)}]`)
  const tag = prior ?? (() => {
    const created = document.createElement('style')
    created.dataset.plugin = tagId
    created.dataset.pluginCss = tagId
    created.textContent = STYLES
    document.head.appendChild(created)
    return created
  })()
  return () => {
    if (tag.isConnected) tag.remove()
  }
}
