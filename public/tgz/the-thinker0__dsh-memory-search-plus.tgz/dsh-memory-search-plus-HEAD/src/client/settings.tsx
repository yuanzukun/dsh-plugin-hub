/**
 * memory-search-plus — settings section (settings.section).
 *
 * Live index status (phase, sessions/messages, rebuild progress), the
 * index database path, and an explicit reindex action. Status is polled
 * while the page is mounted so a finished rebuild shows up without
 * navigating away.
 */

import { useCallback, useEffect, useRef, useState } from 'react'
import { callRemote, normalizeStatus, type IndexStatus, type RemoteMemorySearch } from './rpc.tsx'

interface SettingsProps {
  /** Bound locale translator for namespace `memorySearch`. */
  readonly t: (key: string, params?: Record<string, string | number>) => string
  /** Injected `ctx.remote.memorySearch` Remote face (static RPC path). */
  readonly remote: RemoteMemorySearch
}

type Phase =
  | { readonly kind: 'loading' }
  | { readonly kind: 'status'; readonly status: IndexStatus }
  | { readonly kind: 'error'; readonly message: string }

interface Notice {
  readonly text: string
  readonly failed: boolean
}

const STATUS_POLL_MS = 5_000
const STATUS_POLL_INDEXING_MS = 1_000

function rpcErrorMessage(payload: unknown, fallback: string): string | null {
  const record = payload !== null && typeof payload === 'object'
    ? payload as { ok?: unknown; error?: unknown; message?: unknown }
    : null
  if (record?.ok !== false) return null
  const error = record.error
  if (typeof error === 'string' && error.length > 0) return error
  if (error !== null && typeof error === 'object' && typeof (error as { message?: unknown }).message === 'string') {
    return (error as { message: string }).message
  }
  if (typeof record.message === 'string' && record.message.length > 0) return record.message
  return fallback
}

export function SearchSettings({ t, remote }: SettingsProps) {
  const [phase, setPhase] = useState<Phase>({ kind: 'loading' })
  const [rebuilding, setRebuilding] = useState(false)
  const [savingPath, setSavingPath] = useState(false)
  const [pathDraft, setPathDraft] = useState<string | null>(null)
  const [notice, setNotice] = useState<Notice | null>(null)
  const watchRebuild = useRef(false)

  const refresh = useCallback(async (silent = false) => {
    if (!silent) setPhase({ kind: 'loading' })
    try {
      const payload = await callRemote(remote, 'status')
      setPhase({ kind: 'status', status: normalizeStatus(payload) })
    } catch (error) {
      setPhase({ kind: 'error', message: error instanceof Error ? error.message : String(error) })
    }
  }, [remote])

  useEffect(() => { void refresh() }, [refresh])

  const indexing = phase.kind === 'status' && phase.status.phase === 'indexing'
  const busy = rebuilding || indexing || savingPath
  const livePath = phase.kind === 'status' ? phase.status.dbPath : null
  const defaultPath = phase.kind === 'status' ? phase.status.defaultDbPath : null
  const displayPath = pathDraft ?? livePath ?? ''

  useEffect(() => {
    let alive = true
    let inFlight = false
    const tick = async (): Promise<void> => {
      if (!alive || inFlight) return
      inFlight = true
      try {
        const payload = await callRemote(remote, 'status')
        if (!alive) return
        setPhase({ kind: 'status', status: normalizeStatus(payload) })
      } catch {
        /* keep last good status; the next tick retries */
      } finally {
        inFlight = false
      }
    }
    const ms = busy ? STATUS_POLL_INDEXING_MS : STATUS_POLL_MS
    const timer = window.setInterval(() => { void tick() }, ms)
    if (busy) void tick()
    return () => {
      alive = false
      window.clearInterval(timer)
    }
  }, [remote, busy])

  useEffect(() => {
    if (!watchRebuild.current) return
    if (phase.kind !== 'status') return
    if (phase.status.phase === 'indexing') return
    watchRebuild.current = false
    setRebuilding(false)
    if (phase.status.phase === 'ready' || phase.status.phase === 'degraded') {
      setNotice({ text: t('settings.reindexDone'), failed: false })
    } else if (phase.status.phase === 'error') {
      setNotice({ text: t('settings.rebuildFailed'), failed: true })
    }
  }, [phase, t])

  const rebuild = async (): Promise<void> => {
    if (busy) return
    setRebuilding(true)
    setNotice(null)
    try {
      const payload = await callRemote(remote, 'reindex')
      const message = rpcErrorMessage(payload, 'reindex failed')
      if (message !== null) throw new Error(message)
      const record = payload !== null && typeof payload === 'object'
        ? payload as { started?: unknown }
        : null
      watchRebuild.current = true
      setNotice({
        text: record?.started === false ? t('settings.reindexRunning') : t('settings.reindexStarted'),
        failed: false,
      })
      await refresh(true)
    } catch {
      watchRebuild.current = false
      setRebuilding(false)
      setNotice({ text: t('settings.rebuildFailed'), failed: true })
    }
  }

  const savePath = async (nextPath: string): Promise<void> => {
    if (busy) return
    const trimmed = nextPath.trim()
    if (trimmed.length === 0) {
      setNotice({ text: t('settings.dbPathFailed'), failed: true })
      return
    }
    setSavingPath(true)
    setNotice(null)
    try {
      const payload = await callRemote(remote, 'setDbPath', { path: trimmed })
      const message = rpcErrorMessage(payload, t('settings.dbPathFailed'))
      if (message !== null) throw new Error(message)
      const record = payload !== null && typeof payload === 'object'
        ? payload as { started?: unknown; unchanged?: unknown; dbPath?: unknown }
        : null
      setPathDraft(null)
      if (record?.unchanged === true) {
        setNotice({ text: t('settings.dbPathUnchanged'), failed: false })
      } else {
        if (record?.started !== false) {
          watchRebuild.current = true
          setRebuilding(true)
        }
        setNotice({ text: t('settings.dbPathSaved'), failed: false })
      }
      await refresh(true)
    } catch (error) {
      setNotice({
        text: error instanceof Error && error.message.length > 0 ? error.message : t('settings.dbPathFailed'),
        failed: true,
      })
    } finally {
      setSavingPath(false)
    }
  }

  const statusLine = (): string => {
    if (phase.kind === 'loading') return t('settings.loading')
    if (phase.kind === 'error') return `${t('settings.statusFailed')}: ${phase.message}`
    const status = phase.status
    if (status.phase === 'error') return `${t('settings.statusFailed')}${status.message !== null ? `: ${status.message}` : ''}`
    if (status.phase === 'indexing') {
      const current = status.rebuildCurrent
      const total = status.rebuildTotal
      const sessions = status.indexedSessions
      const messages = status.indexedMessages
      if (typeof current === 'number' && typeof total === 'number' && total > 0) {
        return t('settings.statusRebuildingProgress', { current, total, messages: messages ?? 0 })
      }
      if (sessions !== null && messages !== null) return t('settings.statusRebuildingCounts', { sessions, messages })
      return t('settings.rebuilding')
    }
    if (status.phase === 'degraded') return t('panel.degraded')
    const sessions = status.indexedSessions
    const messages = status.indexedMessages
    if (sessions !== null && messages !== null) return t('settings.statusReady', { sessions, messages })
    if (sessions !== null) return t('settings.statusSessions', { sessions })
    return t('settings.statusReadyNa')
  }

  const storageLine = (): string | null => {
    if (phase.kind !== 'status') return null
    const { storageBytes, storageLimitBytes, prunedDocs, coverageSince } = phase.status
    if (storageBytes === null && storageLimitBytes === null) return null
    const used = ((storageBytes ?? 0) / 1048576).toFixed(1)
    const limit = storageLimitBytes === null ? '∞' : (storageLimitBytes / 1048576).toFixed(0)
    const coverage = coverageSince === null ? '' : ` · ${t('settings.coverageSince', { date: new Date(coverageSince).toLocaleDateString() })}`
    const pruned = prunedDocs > 0 ? ` · ${t('settings.pruned', { n: prunedDocs })}` : ''
    return `${t('settings.storage', { used, limit })}${coverage}${pruned}`
  }

  const phaseClass = phase.kind === 'status' ? phase.status.phase : phase.kind
  const progress = phase.kind === 'status'
    && typeof phase.status.rebuildTotal === 'number'
    && phase.status.rebuildTotal > 0
    ? Math.min(100, Math.round(100 * (phase.status.rebuildCurrent ?? 0) / phase.status.rebuildTotal))
    : null
  const canResetDefault = defaultPath !== null && displayPath.trim() !== defaultPath

  return (
    <div className="msp-settings">
      <p className="msp-settings-hint">{t('settings.hint')}</p>
      <div className="msp-settings-row">
        <span className={`msp-settings-status msp-settings-status-${phaseClass}`}>
          {statusLine()}
        </span>
        <button type="button" className="msp-settings-action" disabled={busy} onClick={() => { void rebuild() }}>
          {busy && !savingPath ? t('settings.rebuilding') : t('settings.rebuild')}
        </button>
      </div>
      {storageLine() !== null ? <p className="msp-settings-notice">{storageLine()}</p> : null}
      {progress !== null ? (
        <div className="msp-settings-progress" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress}>
          <span style={{ width: `${progress}%` }} />
        </div>
      ) : null}
      <div className="msp-settings-path">
        <span className="msp-settings-path-label">{t('settings.dbPath')}</span>
        <p className="msp-settings-hint">{t('settings.dbPathHint')}</p>
        <div className="msp-settings-path-row">
          <input
            type="text"
            className="msp-settings-path-input"
            value={displayPath}
            placeholder={t('settings.dbPathPlaceholder')}
            spellCheck={false}
            autoComplete="off"
            disabled={busy}
            onChange={(event) => { setPathDraft(event.target.value) }}
            onKeyDown={(event) => {
              if (event.key === 'Enter') {
                event.preventDefault()
                void savePath(displayPath)
              }
            }}
          />
        </div>
        <div className="msp-settings-path-actions">
          <button
            type="button"
            className="msp-settings-action"
            disabled={busy || displayPath.trim().length === 0}
            onClick={() => { void savePath(displayPath) }}
          >
            {savingPath ? t('settings.dbPathSaving') : t('settings.dbPathSave')}
          </button>
          <button
            type="button"
            className="msp-settings-action"
            disabled={busy || !canResetDefault}
            onClick={() => {
              if (defaultPath === null) return
              setPathDraft(defaultPath)
              void savePath(defaultPath)
            }}
          >
            {t('settings.dbPathDefault')}
          </button>
        </div>
      </div>
      {notice !== null ? (
        <p className={`msp-settings-notice${notice.failed ? ' msp-settings-notice-failed' : ''}`}>{notice.text}</p>
      ) : null}
    </div>
  )
}
