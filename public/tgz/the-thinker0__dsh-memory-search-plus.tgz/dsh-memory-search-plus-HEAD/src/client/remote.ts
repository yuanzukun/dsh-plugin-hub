/**
 * Client-side Typert Remote contribution for this plugin.
 *
 * `remote.goals` exists because `dsh-api-remotes` $mounts a generated
 * artifact. Third-party plugins are not in that assembly, so this client
 * must $mount its own contribution — otherwise `inject: ['remote.memorySearch']`
 * waits forever (host indexing completing does not publish the client face).
 *
 * Codecs are passthrough: Host already returns plain JSON envelopes; the
 * gateway only requires `mode: 'strict'` + `schema.parse`.
 */

const json = {
  parse(value: unknown): unknown {
    return value
  },
}

function codec(typeSymbol: string): { mode: 'strict'; typeSymbol: string; schema: typeof json } {
  return { mode: 'strict', typeSymbol, schema: json }
}

function endpoint(method: string, parameters: ReadonlyArray<{ name: string; wire: string }>) {
  return {
    id: `dsh-memory-search-plus#memorySearch/${method}`,
    service: 'memorySearch',
    namespace: 'memorySearch',
    method,
    invocation: { kind: 'direct' as const },
    parameters: parameters.map((parameter) => ({
      name: parameter.name,
      wire: parameter.wire,
      source: 'json' as const,
      codec: codec(`dsh-memory-search-plus#memorySearch/${method}:${parameter.wire}`),
    })),
    result: codec(`dsh-memory-search-plus#memorySearch/${method}:result`),
  }
}

/** Mounted by the client `apply()` onto `ctx.remote`. */
export const MEMORY_SEARCH_REMOTE = {
  package: 'dsh-memory-search-plus',
  descriptors: [
    endpoint('search', [{ name: 'request', wire: 'request' }]),
    endpoint('status', []),
    endpoint('reindex', []),
    endpoint('setDbPath', [{ name: 'request', wire: 'request' }]),
  ],
}
