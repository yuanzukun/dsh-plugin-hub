/**
 * memory-search-plus — Client→Host RPC bridge.
 *
 * STATIC plugin path: the call goes through the @Remote Service namespace
 * (`remote.memorySearch`) after this client $mounts its own contribution
 * (see remote.ts). Methods resolve contract payloads (`{ok, …}` /
 * `{ok:false, error:{code,message}}`); the gateway client face may box the
 * Host JSON as `{ok:true, value}` and `callRemote` unwraps that. The old
 * dynamic-plugin global host bridge is intentionally NOT used.
 */

/** One search hit as returned by `memory-search/search`. */
export interface SearchHit {
  readonly sessionId: string
  readonly sessionTitle: string
  readonly seq: number
  readonly type: string
  readonly role: string
  /** Event time in epoch milliseconds (normalized). */
  readonly time: number
  /**
   * Precise anchor for message-level jump, or '' when the event is indexed
   * for text search but not locatable (todo/write, turn/end, …) — such hits
   * are displayed but never jump.
   */
  readonly anchorKey: string
  readonly text: string
  /** Host-provided display window of `text` (optional; rendering derives its
   * own window from text+spans — contract: spans are offsets INTO text). */
  readonly snippet: string
  /** Highlight ranges as [start, end) character offsets INTO `text`,
   * already merged; matchCount equals this array's length. */
  readonly spans: readonly (readonly [number, number])[]
  readonly matchCount: number
  readonly textTruncated: boolean
}

export interface SearchResult {
  readonly hits: SearchHit[]
  readonly error: string | null
  /** Contract error code (e.g. 'E_NOT_READY') when the host returned one. */
  readonly errorCode: string | null
  /** Whether the host capped the result set (truncated list). */
  readonly truncated: boolean
}

export interface IndexStatus {
  readonly phase: 'ready' | 'indexing' | 'degraded' | 'error' | 'unknown'
  readonly message: string | null
  readonly indexedSessions: number | null
  readonly indexedMessages: number | null
  /** Sessions finished in the current full rebuild; null when idle. */
  readonly rebuildCurrent: number | null
  /** Sessions queued for the current full rebuild; null when idle. */
  readonly rebuildTotal: number | null
  readonly storageBytes: number | null
  readonly storageLimitBytes: number | null
  readonly prunedDocs: number
  readonly coverageSince: number | null
  /** Absolute path of the live SQLite file; null when the host omitted it. */
  readonly dbPath: string | null
  /** Default path the plugin would use without an override. */
  readonly defaultDbPath: string | null
}

/**
 * The generated Remote namespace face for this plugin's host half
 * (injected as `ctx.remote.memorySearch`). Methods resolve the contract
 * payloads directly; errors surface as `{ok:false, error:{code,message}}`.
 * Structurally typed locally — the client must not depend on the host
 * package's own type module.
 */
export interface RemoteMemorySearch {
  search(args: { query: string; limit?: number; role?: 'all' | 'user' | 'assistant' | 'tool' }): Promise<unknown>
  status(): Promise<unknown>
  reindex(): Promise<unknown>
  setDbPath(args: { path: string }): Promise<unknown>
}

export type RemoteMethod = 'search' | 'status' | 'reindex' | 'setDbPath'

/**
 * The gateway client face returns `{ ok: true, value: <host json> }`. Host
 * methods already return `{ ok, hits|started|ready, … }`. Unwrap the box so
 * normalizeSearch/normalizeStatus see the contract payload. Direct Host-shaped
 * returns (unit tests, older carriers) pass through.
 */
export function unwrapRemotePayload(payload: unknown): unknown {
  if (payload === null || typeof payload !== 'object') return payload
  if (!Object.prototype.hasOwnProperty.call(payload, 'value')) return payload
  const record = payload as { ok?: unknown; value?: unknown }
  if (record.ok !== true) return payload
  if (Object.prototype.hasOwnProperty.call(payload, 'hits')) return payload
  return record.value
}

/** Dispatch one RPC call through the injected Remote face. */
export async function callRemote(remote: RemoteMemorySearch, method: RemoteMethod, args?: unknown): Promise<unknown> {
  switch (method) {
    case 'search':
      return unwrapRemotePayload(await remote.search(args as { query: string; limit?: number; role?: 'all' | 'user' | 'assistant' | 'tool' }))
    case 'status':
      return unwrapRemotePayload(await remote.status())
    case 'reindex':
      return unwrapRemotePayload(await remote.reindex())
    case 'setDbPath':
      return unwrapRemotePayload(await remote.setDbPath(args as { path: string }))
  }
}

/** Normalize an epoch value that may arrive as seconds, ms, or an ISO string. */
function toEpoch(value: unknown): number {
  if (typeof value === 'number' && Number.isFinite(value)) return value < 1e12 ? value * 1000 : value
  if (typeof value === 'string') {
    const parsed = Date.parse(value)
    if (Number.isFinite(parsed)) return parsed
  }
  return 0
}

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' ? value : fallback
}

/** Contract error envelope: `{ ok: false, error: { code: 'E_*', message } }` —
 * the `error` member may alternatively arrive as a plain string defensively. */
function errorOf(record: { error?: unknown; message?: unknown }): { code: string; message: string } {
  const error = record.error
  if (error !== null && typeof error === 'object') {
    const box = error as { code?: unknown; message?: unknown }
    return {
      code: asString(box.code, 'E_INTERNAL'),
      message: asString(box.message, asString(record.message, 'RPC failed')),
    }
  }
  const message = asString(error, asString(record.message, 'RPC failed'))
  return { code: message.startsWith('E_') ? message : 'E_INTERNAL', message }
}

function toSpans(value: unknown, maxEnd: number): readonly (readonly [number, number])[] {
  if (!Array.isArray(value)) return []
  const spans: [number, number][] = []
  for (const item of value) {
    if (!Array.isArray(item) || item.length < 2) continue
    const start = typeof item[0] === 'number' && Number.isFinite(item[0]) ? item[0] : -1
    const end = typeof item[1] === 'number' && Number.isFinite(item[1]) ? item[1] : -1
    if (start >= 0 && end > start && start < maxEnd) spans.push([start, Math.min(end, maxEnd)])
  }
  return spans
}

/** Normalize an arbitrary `memory-search/search` payload into a SearchResult. */
export function normalizeSearch(payload: unknown): SearchResult {
  if (payload === null || typeof payload !== 'object') {
    return { hits: [], error: 'search returned no payload', errorCode: 'E_INTERNAL', truncated: false }
  }
  const record = payload as { ok?: unknown; hits?: unknown; error?: unknown; message?: unknown; truncated?: unknown }
  if (record.ok === false) {
    const failure = errorOf(record)
    return { hits: [], error: failure.message, errorCode: failure.code, truncated: false }
  }
  const raw = Array.isArray(record.hits) ? record.hits.slice(0, 200) : []
  const hits: SearchHit[] = []
  for (const item of raw) {
    if (item === null || typeof item !== 'object') continue
    const h = item as Record<string, unknown>
    const sessionId = asString(h.sessionId, '')
    // `anchorKey` may be null/absent per contract: the event is indexed for
    // text search but is not precisely locatable — keep the hit (displayed,
    // never jumpable), normalized to ''.
    const anchorKey = asString(h.anchorKey, '')
    if (sessionId === '') continue
    const text = asString(h.text, '').slice(0, 8192)
    const spans = toSpans(h.spans, text.length)
    const rawMatchCount = h.matchCount
    hits.push({
      sessionId,
      sessionTitle: asString(h.sessionTitle, '').slice(0, 1000),
      seq: typeof h.seq === 'number' ? h.seq : 0,
      type: asString(h.type, ''),
      role: asString(h.role, ''),
      time: toEpoch(h.time),
      anchorKey,
      text,
      snippet: asString(h.snippet, text).slice(0, 4000),
      spans,
      matchCount: typeof rawMatchCount === 'number' && Number.isFinite(rawMatchCount) && rawMatchCount >= 0
        ? Math.floor(rawMatchCount)
        : spans.length,
      textTruncated: h.textTruncated === true,
    })
  }
  return { hits, error: null, errorCode: null, truncated: record.truncated === true }
}

export function emptyIndexStatus(overrides: Pick<IndexStatus, 'phase'> & Partial<IndexStatus> = { phase: 'unknown' }): IndexStatus {
  return {
    message: null,
    indexedSessions: null,
    indexedMessages: null,
    rebuildCurrent: null,
    rebuildTotal: null,
    storageBytes: null,
    storageLimitBytes: null,
    prunedDocs: 0,
    coverageSince: null,
    dbPath: null,
    defaultDbPath: null,
    ...overrides,
  }
}

function asDbPath(value: unknown): string | null {
  return typeof value === 'string' && value.length > 0 ? value : null
}

/** Normalize a `memory-search/status` payload into an IndexStatus.
 *
 * Contract §6.2 shape is resolved first:
 *   { ok, ready: boolean, indexedSessions: number, indexedDocs: number,
 *     building: boolean, degraded: boolean }
 *   - ok === false                  → 'error'
 *   - degraded === true             → 'degraded' (in-memory fallback, !ready)
 *   - ready && building             → 'indexing'
 *   - ready && !building            → 'ready'
 *   - !ready (no degraded flag)     → 'error'
 * The alternate `{ ok, phase|status, error|message }` spelling is kept as a
 * defensive fallback only (counts: indexedDocs → indexedMessages, with the
 * legacy `indexedMessages`/`messages` spellings as tertiary).
 */
export function normalizeStatus(payload: unknown): IndexStatus {
  if (payload === null || typeof payload !== 'object') {
    return emptyIndexStatus({ phase: 'unknown' })
  }
  const record = payload as {
    ok?: unknown; phase?: unknown; status?: unknown; message?: unknown; error?: unknown;
    ready?: unknown; building?: unknown; degraded?: unknown;
    sessions?: unknown; messages?: unknown;
    indexedSessions?: unknown; indexedMessages?: unknown; indexedDocs?: unknown;
    rebuildCurrent?: unknown; rebuildTotal?: unknown;
    storageBytes?: unknown; storageLimitBytes?: unknown; prunedDocs?: unknown; coverageSince?: unknown;
    dbPath?: unknown; defaultDbPath?: unknown;
  }
  if (record.ok === false) {
    const failure = errorOf(record)
    return emptyIndexStatus({ phase: 'error', message: failure.message })
  }
  // Contract-first boolean mapping; alternate shape only when the contract
  // keys are absent entirely.
  const hasContractFlags =
    typeof record.ready === 'boolean' ||
    typeof record.building === 'boolean' ||
    typeof record.degraded === 'boolean'
  let phase: IndexStatus['phase']
  if (record.degraded === true) {
    phase = 'degraded'
  } else if (record.building === true) {
    phase = 'indexing'
  } else if (record.ready === true) {
    phase = 'ready'
  } else if (record.ready === false) {
    // §6.2/§9: ready=false without degraded = services missing / not yet
    // ready — the client shows the "index initializing…" state.
    phase = 'indexing'
  } else if (hasContractFlags) {
    phase = 'unknown'
  } else {
    const rawPhase = asString(record.phase, asString(record.status, '')).toLowerCase()
    phase = rawPhase === 'ready' || rawPhase === 'indexing' || rawPhase === 'error' || rawPhase === 'degraded'
      ? rawPhase
      : 'unknown'
  }
  const sessions = typeof record.indexedSessions === 'number' ? record.indexedSessions
    : typeof record.sessions === 'number' ? record.sessions : null
  const messages = typeof record.indexedDocs === 'number' ? record.indexedDocs
    : typeof record.indexedMessages === 'number' ? record.indexedMessages
      : typeof record.messages === 'number' ? record.messages : null
  return {
    phase,
    message: typeof record.error === 'string' ? record.error : typeof record.message === 'string' ? record.message : null,
    indexedSessions: sessions,
    indexedMessages: messages,
    rebuildCurrent: typeof record.rebuildCurrent === 'number' ? record.rebuildCurrent : null,
    rebuildTotal: typeof record.rebuildTotal === 'number' ? record.rebuildTotal : null,
    storageBytes: typeof record.storageBytes === 'number' ? record.storageBytes : null,
    storageLimitBytes: typeof record.storageLimitBytes === 'number' ? record.storageLimitBytes : null,
    prunedDocs: typeof record.prunedDocs === 'number' ? Math.max(0, Math.floor(record.prunedDocs)) : 0,
    coverageSince: typeof record.coverageSince === 'number' ? record.coverageSince : null,
    dbPath: asDbPath(record.dbPath),
    defaultDbPath: asDbPath(record.defaultDbPath),
  }
}
