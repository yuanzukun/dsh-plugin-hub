/**
 * memory-search-plus — module-level overlay state.
 *
 * The sidebar pill and the shell.overlay panel are two independent slot
 * entries (two React roots). They share one tiny external store so either
 * side can open/close the panel and read transient toast state. The store
 * is intentionally framework-free: a stable snapshot object plus a
 * listener set, consumed with `useSyncExternalStore`.
 */

export interface OverlaySnapshot {
  /** Whether the search panel is open. */
  readonly open: boolean
  /** Transient panel message (toast), null when silent. */
  readonly toast: string | null
  /** Monotonic toast revision — a new toast even with identical text bumps it. */
  readonly toastSeq: number
}

let snapshot: OverlaySnapshot = { open: false, toast: null, toastSeq: 0 }

const listeners = new Set<() => void>()

function emit(): void {
  for (const listener of [...listeners]) listener()
}

function set(patch: Partial<OverlaySnapshot>): void {
  snapshot = { ...snapshot, ...patch }
  emit()
}

/** Open the search panel (idempotent). */
export function openOverlay(): void {
  if (snapshot.open) return
  set({ open: true })
}

/** Close the search panel. */
export function closeOverlay(): void {
  if (!snapshot.open) return
  set({ open: false })
}

/** Toggle the search panel (global shortcut handler). */
export function toggleOverlay(): void {
  set({ open: !snapshot.open })
}

/** Show a transient toast; a later `clearToast` / new toast supersedes it. */
export function setToast(message: string): void {
  set({ toast: message, toastSeq: snapshot.toastSeq + 1 })
}

/** Clear the current toast. */
export function clearToast(): void {
  if (snapshot.toast === null) return
  set({ toast: null })
}

export function subscribeOverlay(listener: () => void): () => void {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

export function getOverlaySnapshot(): OverlaySnapshot {
  return snapshot
}
