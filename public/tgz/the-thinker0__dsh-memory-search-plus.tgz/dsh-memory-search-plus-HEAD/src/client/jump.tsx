/**
 * memory-search-plus — precise message location & highlight.
 *
 * Clicking a hit must bring the original chat row into view in the live
 * conversation surface:
 *   1. open the target session and wait for its binding;
 *   2. wait until the history window is hydrated (`openState==='open'`) —
 *      a cold bind has empty chat + hasMore=false and would false-positive
 *      as compacted on the first click;
 *   3. page older messages until the anchor key is present (or the log is
 *      exhausted — the message was compacted);
 *   4. wait for the anchored row in ANY `[data-conversation-scroll]`
 *      (session switches leave the outgoing column mounted briefly);
 *   5. scroll the row into view, flash the row (`data-mhsp-target`, CSS
 *      animation) and wrap in-text occurrences of the query in transient
 *      `<mark class="msp-textmark">` nodes, restored ~2.5 s later (or on
 *      unmount).
 *
 * The mechanics mirror dsh-conversation-landmarks' proven walk; the
 * additional pieces are the session-open wait and the text-level marks.
 */

export interface JumpContext {
  /**
   * Resolve the live session face for an id, or undefined while the
   * session is not bound yet (wired to `ctx.sessions.binding(...)?.session`).
   */
  readonly bindingSession: (sessionId: string) => SessionFaceLike | undefined
  /** Select a session as current; may throw for unknown ids. */
  readonly openSession: (sessionId: string) => void
  /**
   * 子代理会话专用打开通道（可选）：`ctx.sessions.subagentAddress(id)` 解析直接父地址，
   * 命中子代理会话时必须走 `openSubagent(address)`——直接 `open(childId)` 对子代理
   * 不产生 binding，定位会永远失败（用户验收实测）。
   */
  readonly resolveSubagent?: ((sessionId: string) => { parentSessionId: string; childSessionId: string } | undefined) | undefined
  readonly openSubagent?: ((address: { parentSessionId: string; childSessionId: string }) => void) | undefined
}

export interface SessionFaceLike {
  getSnapshot(): SnapshotLike
  loadOlder(): Promise<void>
}

export interface SnapshotLike {
  readonly chat: { readonly nodes: { get(key: string): unknown }; readonly order: readonly string[] }
  readonly hasMore: boolean
  readonly loadingOlder: boolean
  /** dsh Session.openState: cold → loading → open | error. Absent on older faces. */
  readonly openState?: string
}

export type JumpOutcome =
  | { readonly ok: true }
  | { readonly ok: false; readonly reason: 'no-binding' | 'compacted' | 'not-rendered' | 'error' }

const TARGET_FLASH_MS = 1_200
const TEXT_MARK_MS = 2_500
const BINDING_WAIT_MS = 8_000
const OPEN_WAIT_MS = 8_000
const RENDER_WAIT_MS = 3_000
const PAGE_WAIT_MS = 8_000

function waitFrame(): Promise<void> {
  return new Promise((resolve) => {
    if (typeof window !== 'undefined' && typeof window.requestAnimationFrame === 'function') {
      window.requestAnimationFrame(() => resolve())
      return
    }
    setTimeout(resolve, 16)
  })
}

function findAnchor(root: ParentNode, key: string): HTMLElement | null {
  for (const element of root.querySelectorAll<HTMLElement>('[data-chat-anchor-key]')) {
    if (element.dataset.chatAnchorKey === key) return element
  }
  return null
}

/**
 * Locate the rendered row. Session switches keep the outgoing conversation
 * column mounted, so the first visible scrollport is often the WRONG one.
 */
export function findRenderedAnchor(key: string): { anchor: HTMLElement; scrollport: HTMLElement } | null {
  if (typeof document === 'undefined') return null
  for (const candidate of document.querySelectorAll<HTMLElement>('[data-conversation-scroll]')) {
    const anchor = findAnchor(candidate, key)
    if (anchor === null) continue
    return { anchor, scrollport: candidate }
  }
  const loose = findAnchor(document, key)
  if (loose === null) return null
  const scrollport = loose.closest('[data-conversation-scroll]')
  if (scrollport instanceof HTMLElement) return { anchor: loose, scrollport }
  return null
}

/** Wait up to `RENDER_WAIT_MS` for the anchor row to appear in a live scrollport. */
async function renderedAnchor(key: string): Promise<{ anchor: HTMLElement; scrollport: HTMLElement } | null> {
  const deadline = Date.now() + RENDER_WAIT_MS
  for (;;) {
    const found = findRenderedAnchor(key)
    if (found !== null) return found
    if (Date.now() >= deadline) return null
    await waitFrame()
  }
}

/** Wait until the session is bound after `openSession`, so its snapshot is live. */
async function waitForSession(
  sessionId: string,
  context: JumpContext,
): Promise<SessionFaceLike | null> {
  const deadline = Date.now() + BINDING_WAIT_MS
  for (;;) {
    const session = context.bindingSession(sessionId)
    if (session !== undefined) return session
    if (Date.now() >= deadline) return null
    await waitFrame()
  }
}

/**
 * Binding appears immediately, but the history window is still `cold`/`loading`
 * with empty chat and hasMore=false. Paging in that window looks identical to
 * a compacted hit. Wait until dsh flips openState to `open`.
 */
export async function waitForHydratedSession(
  session: SessionFaceLike,
  timeoutMs = OPEN_WAIT_MS,
): Promise<boolean> {
  const deadline = Date.now() + timeoutMs
  const started = Date.now()
  for (;;) {
    const snapshot = session.getSnapshot()
    const state = snapshot.openState
    if (state === 'error') return false
    if (state === 'open') return true
    if (state === undefined && snapshot.chat.order.length > 0) return true
    // Faces without openState: give history a short window, then proceed.
    if (state === undefined && Date.now() - started >= 1_000) return true
    if (Date.now() >= deadline) return state === 'open' || state === undefined
    await waitFrame()
  }
}

const HIGHLIGHT_NAME = 'dsh-msp'
const MAX_RANGES = 200

/** Shadowy face of the CSS Custom Highlight registry (guarded — the API is
 * absent in older engines; we never touch DOM text nodes either way). */
interface HighlightRegistryLike {
  set(name: string, highlight: unknown): unknown
  delete(name: string): boolean
}

class HighlightCtorProbe {
  constructor(..._ranges: Range[]) {}
}

function highlightRegistry(): HighlightRegistryLike | null {
  if (typeof CSS === 'undefined') return null
  const registry = (CSS as unknown as { highlights?: HighlightRegistryLike }).highlights
  if (registry === undefined || typeof registry.set !== 'function') return null
  const highlightCtor = (window as unknown as { Highlight?: typeof HighlightCtorProbe }).Highlight
  if (typeof highlightCtor !== 'function') return null
  return registry
}

let restoreTimer: number | undefined

/**
 * Remove the transient CSS text highlight (unload-safe). Never touches the
 * React-owned DOM — the highlight lives in the CSS Highlight registry.
 */
export function restoreTextMarks(): void {
  if (restoreTimer !== undefined) {
    window.clearTimeout(restoreTimer)
    restoreTimer = undefined
  }
  const registry = highlightRegistry()
  if (registry !== null) registry.delete(HIGHLIGHT_NAME)
}

/** Remove any leftover `data-mhsp-target` row-flash attributes. */
export function clearTargetFlash(): void {
  for (const element of document.querySelectorAll('[data-mhsp-target]')) {
    element.removeAttribute('data-mhsp-target')
  }
}

/**
 * Highlight case-insensitive occurrences of `needle` in text nodes under
 * `root` via the CSS Custom Highlight API (ranges over the EXISTING text
 * nodes — no node splitting, no DOM mutation, so React's tree is untouched;
 * same crash class as R1 is therefore impossible). When the API is absent,
 * the row flash (`data-mhsp-target`) is the only highlight and returns.
 * The registered highlight clears itself after ~2.5 s (or on unmount).
 */
function highlightText(root: HTMLElement, needle: string): void {
  restoreTextMarks()
  const trimmed = needle.trim()
  if (trimmed === '') return
  const registry = highlightRegistry()
  if (registry === null) return
  const lowerNeedle = trimmed.toLowerCase()
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT)
  const ranges: Range[] = []
  for (let node = walker.nextNode(); node !== null && ranges.length < MAX_RANGES; node = walker.nextNode()) {
    const text = node as Text
    const hay = text.nodeValue ?? ''
    const lowerHay = hay.toLowerCase()
    let index = lowerHay.indexOf(lowerNeedle, 0)
    while (index >= 0 && ranges.length < MAX_RANGES) {
      const range = document.createRange()
      range.setStart(text, index)
      range.setEnd(text, index + trimmed.length)
      ranges.push(range)
      index = lowerHay.indexOf(lowerNeedle, index + trimmed.length)
    }
  }
  if (ranges.length === 0) return
  const HighlightCtor = (window as unknown as { Highlight?: new (...ranges: Range[]) => unknown }).Highlight
  if (typeof HighlightCtor !== 'function') return
  registry.set(HIGHLIGHT_NAME, new HighlightCtor(...ranges))
  restoreTimer = window.setTimeout(() => restoreTextMarks(), TEXT_MARK_MS)
}

/** Page the session until the anchor is in the snapshot or the log ends. */
export async function pageToAnchor(session: SessionFaceLike, anchorKey: string): Promise<boolean> {
  const deadline = Date.now() + PAGE_WAIT_MS
  let stalled = 0
  for (;;) {
    let snapshot = session.getSnapshot()
    if (snapshot.chat.nodes.get(anchorKey) !== undefined) return true
    if (snapshot.loadingOlder) {
      if (Date.now() >= deadline) return false
      await waitFrame()
      continue
    }
    if (!snapshot.hasMore) return false
    const firstKey = snapshot.chat.order[0]
    await session.loadOlder()
    snapshot = session.getSnapshot()
    if (snapshot.chat.nodes.get(anchorKey) !== undefined) return true
    if (!snapshot.hasMore && snapshot.loadingOlder !== true) return false
    if (snapshot.chat.order[0] === firstKey && snapshot.loadingOlder !== true) {
      stalled += 1
      if (stalled > 8) return false
    } else {
      stalled = 0
    }
    if (Date.now() >= deadline) return snapshot.chat.nodes.get(anchorKey) !== undefined
    await waitFrame()
  }
}

/**
 * Locate a search hit in the live conversation: open the session, page to
 * the row, scroll it into view and flash it. Returns the outcome for the
 * caller to toast; the text marks restore themselves after ~2.5 s.
 */
export async function jumpToAnchor(
  sessionId: string,
  anchorKey: string,
  query: string,
  context: JumpContext,
): Promise<JumpOutcome> {
  if (sessionId === '' || anchorKey === '') return { ok: false, reason: 'error' }
  // 子代理会话（AgentTeams 成员等）必须经 openSubagent 打开，否则 binding 永不出现。
  const subagentAddress =
    typeof context.resolveSubagent === 'function' ? context.resolveSubagent(sessionId) : undefined
  try {
    if (subagentAddress !== undefined && typeof context.openSubagent === 'function') {
      context.openSubagent(subagentAddress)
    } else {
      context.openSession(sessionId)
    }
  } catch {
    return { ok: false, reason: 'no-binding' }
  }
  const session = await waitForSession(sessionId, context)
  if (session === null) {
    console.warn(`[memory-search] jump 诊断: 会话 ${sessionId} 打开后 ${BINDING_WAIT_MS}ms 内 binding 未就绪`)
    return { ok: false, reason: 'no-binding' }
  }
  const hydrated = await waitForHydratedSession(session)
  if (!hydrated) {
    console.warn(`[memory-search] jump 诊断: 会话 ${sessionId} 历史窗口未能打开`)
    return { ok: false, reason: 'no-binding' }
  }
  const present = await pageToAnchor(session, anchorKey)
  if (!present) {
    const snapshot = session.getSnapshot()
    console.warn(
      `[memory-search] jump 诊断: 锚点 ${anchorKey} 不在快照（hasMore=${String(snapshot.hasMore)}，` +
        `openState=${String(snapshot.openState)}，已加载 ${snapshot.chat.order.length} 行）。可能被压缩替换，或锚点公式与 UI 不一致`,
    )
    return { ok: false, reason: 'compacted' }
  }
  const rendered = await renderedAnchor(anchorKey)
  if (rendered === null) {
    console.warn(`[memory-search] jump 诊断: 锚点 ${anchorKey} 在快照中但 ${RENDER_WAIT_MS}ms 内未渲染成 DOM 行`)
    return { ok: false, reason: 'not-rendered' }
  }
  const { anchor, scrollport } = rendered
  scrollport.scrollTop += anchor.getBoundingClientRect().top - scrollport.getBoundingClientRect().top
  anchor.setAttribute('data-mhsp-target', '')
  window.setTimeout(() => anchor.removeAttribute('data-mhsp-target'), TARGET_FLASH_MS)
  highlightText(anchor, query)
  return { ok: true }
}
