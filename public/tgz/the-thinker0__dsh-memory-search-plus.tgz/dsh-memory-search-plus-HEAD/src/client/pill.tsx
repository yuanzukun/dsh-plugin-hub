/**
 * memory-search-plus — sidebar entrance pill.
 *
 * Registered into `sidebar.footer.action` (order 0), beside the Settings
 * row. The pill is PORTALED into a plugin-owned container next to the
 * workspace region instead of being physically moved:
 *
 *   - The container (`msp-pill-anchor`) is created by US with plain DOM,
 *     inserted right after the `[data-slot="sidebar.workspaces"]` outlet
 *     (a sibling in the sidebar column flow, OUTSIDE the region's
 *     React-managed subtree). React only ever owns the portal children
 *     INSIDE the container, and the container is removed by our own
 *     cleanup — so React unmount/removal always targets the real parent
 *     (`NotFoundError` crash class cannot occur).
 *   - NEVER physically relocate the component's own React-held node: the
 *     earlier insertAdjacentElement approach made fiber-remembered remove
 *     run against the OLD parent — an R1 transient crash that took the
 *     whole sidebar tree down.
 *   - Wide gate: shell `wide` prop AND region root rendered width > 120 px
 *     (the slot outlet wrapper is `display: contents`, so its own
 *     clientWidth is always 0). When the anchor is not ready, ONE retry
 *     observer waits for the region; afterwards the pill degrades to the
 *     footer seat (inline render, no portal).
 */

import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { openOverlay } from './store.tsx'

interface PillProps {
  /** Sidebar column state from the footer-action owner share. */
  readonly wide: boolean
  /** Bound locale translator for namespace `memorySearch`. */
  readonly t: (key: string) => string
}

const WORKSPACES_ANCHOR = '[data-slot="sidebar.workspaces"]'

export function SearchPill({ wide, t }: PillProps) {
  const containerRef = useRef<HTMLDivElement | null>(null)
  const retriedRef = useRef(false)
  const [placed, setPlaced] = useState(false)
  const [retryTick, setRetryTick] = useState(0)

  useLayoutEffect(() => {
    const container = containerRef.current
    const region = document.querySelector(WORKSPACES_ANCHOR)
    const regionArea = region instanceof HTMLElement ? region.parentElement : null
    const regionRoot = region === null ? null : region.firstElementChild
    const rootWidth = regionRoot instanceof HTMLElement ? regionRoot.getBoundingClientRect().width : 0
    const shouldPlace = wide && regionArea !== null && regionRoot !== null && rootWidth > 120

    if (shouldPlace && regionArea !== null) {
      const anchored =
        container !== null && container.isConnected && container.nextElementSibling === regionArea
      if (anchored) return
      if (container !== null) container.remove()
      const fresh = document.createElement('div')
      fresh.className = 'msp-pill-anchor'
      // Sibling of the workspaces region (same column as 「新会话」), not inside
      // the regionArea's negative-margin box — that box is wider/asymmetric.
      regionArea.insertAdjacentElement('beforebegin', fresh)
      containerRef.current = fresh
      setPlaced(true)
      return
    }

    // Not wide / anchor missing: remove any container and stay in the footer.
    if (container !== null) {
      container.remove()
      containerRef.current = null
      setPlaced(false)
    }
    // The region may mount late (shell boot order): observe ONCE, retry the
    // placement decision, then degrade permanently to the footer seat.
    if (!retriedRef.current && region === null) {
      retriedRef.current = true
      const observer = new MutationObserver(() => {
        observer.disconnect()
        setRetryTick((value) => value + 1)
      })
      observer.observe(document.body, { childList: true, subtree: true })
      return () => { observer.disconnect() }
    }
  }, [wide, retryTick])

  // Unmount: remove the plugin-owned container; React has already torn the
  // portal children out of it (its own parent), so removal is always legal.
  useEffect(
    () => () => {
      const container = containerRef.current
      if (container !== null) {
        container.remove()
        containerRef.current = null
      }
    },
    [],
  )

  const label = t('pill.label')
  const body = (rail: boolean) => (
    <div
      className={`msp-pill${rail ? ' msp-pill-rail' : ' msp-pill-wide'}`}
      role="button"
      tabIndex={0}
      data-msp-pill=""
      title={`${label} — ${t('pill.fullSearch')}`}
      onClick={() => openOverlay()}
      onKeyDown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault()
          openOverlay()
        }
      }}
    >
      <span className="msp-pill-icon" aria-hidden="true">
        <svg viewBox="0 0 16 16" width="16" height="16" fill="none" aria-hidden="true">
          <circle cx="7" cy="7" r="4.5" stroke="currentColor" strokeWidth="1.5" />
          <line x1="10.5" y1="10.5" x2="14" y2="14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      </span>
      {!rail ? <span className="msp-pill-label">{label}</span> : null}
      {!rail ? <span className="msp-pill-kbd">⌘⇧F</span> : null}
    </div>
  )

  if (placed && containerRef.current !== null) {
    return createPortal(body(false), containerRef.current)
  }
  return body(!wide)
}
