/**
 * memory-search-plus — ChatGPT/VSCode-style search panel (shell.overlay).
 *
 * A floating panel (≤560px wide, ≤70vh) anchored near the top of the
 * viewport and draggable from its title bar: search input (auto-focused, 300 ms debounce), result count,
 * role filter chips (all / user / assistant / tool), hits grouped by
 * session with relative session time, and per-hit snippet with `<mark>`
 * highlights. Clicking a hit jumps the live conversation to the exact
 * message and flash-highlights it (see jump.tsx).
 *
 * The entry renders null when closed; it stays mounted so query/results
 * survive close/reopen.
 */

import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { createPortal } from 'react-dom'
import type { PointerEvent, ReactNode } from 'react'
import {
  callRemote,
  emptyIndexStatus,
  normalizeSearch,
  normalizeStatus,
  type IndexStatus,
  type RemoteMemorySearch,
  type SearchHit,
} from './rpc.tsx'
import { clearTargetFlash, jumpToAnchor, restoreTextMarks, type SessionFaceLike } from './jump.tsx'
import {
  clearToast,
  closeOverlay,
  getOverlaySnapshot,
  setToast,
  subscribeOverlay,
} from './store.tsx'
import { MAX_SEARCH_LIMIT } from '../types.ts'

type RoleFilter = 'all' | 'user' | 'assistant' | 'tool'

type SearchState =
  | { readonly kind: 'idle' }
  | { readonly kind: 'searching'; readonly previous: readonly SearchHit[] }
  | { readonly kind: 'done'; readonly hits: readonly SearchHit[]; readonly truncated: boolean }
  | { readonly kind: 'error'; readonly message: string; readonly errorCode: string | null }

interface PanelProps {
  /** Bound locale translator for namespace `memorySearch`. */
  readonly t: (key: string, params?: Record<string, string | number>) => string
  /** Injected `ctx.sessions.binding(id)?.session` resolver. */
  readonly bindingSession: (sessionId: string) => SessionFaceLike | undefined
  /** Injected `ctx.sessions.open(id)` — selects the session as current. */
  readonly openSession: (sessionId: string) => void
  /** Injected `ctx.sessions.subagentAddress(id)` — resolve direct-parent address for subagent sessions. */
  readonly resolveSubagent?: ((sessionId: string) => { parentSessionId: string; childSessionId: string } | undefined) | undefined
  /** Injected `ctx.sessions.openSubagent(address)` — open catalog child through its parent address. */
  readonly openSubagent?: ((address: { parentSessionId: string; childSessionId: string }) => void) | undefined
  /** Injected `ctx.remote.memorySearch` Remote face (static RPC path). */
  readonly remote: RemoteMemorySearch
}

interface HitGroup {
  readonly sessionId: string
  readonly title: string
  /** Max hit time in this group (group ordering key, §5.4). */
  time: number
  readonly items: SearchHit[]
}

const DEBOUNCE_MS = 300
const STATUS_POLL_MS = 5_000
const TOAST_MS = 4_000
const SEARCH_LIMIT = MAX_SEARCH_LIMIT
const MAX_QUERY_CHARS = 1024

export type HitRole = 'user' | 'assistant' | 'tool' | 'other'

/** Contract role enum: user/assistant/tool/other (fallback: type prefix). */
export function roleOf(hit: SearchHit): HitRole {
  const raw = (hit.role !== '' ? hit.role : hit.type).toLowerCase()
  if (raw.startsWith('user')) return 'user'
  if (raw.startsWith('assistant')) return 'assistant'
  if (raw.startsWith('tool')) return 'tool'
  return 'other'
}

/**
 * §5.4: the host returns a FLAT hits array (sorted time DESC, seq DESC);
 * grouping is the client's job. Hits of one session need not be contiguous,
 * so group by sessionId and order groups by their max time DESC; per-session
 * items keep the global (time DESC) scan order.
 */
export function groupHits(hits: readonly SearchHit[]): HitGroup[] {
  const bySession = new Map<string, HitGroup>()
  for (const hit of hits) {
    const existing = bySession.get(hit.sessionId)
    if (existing !== undefined) {
      existing.items.push(hit)
      if (hit.time > existing.time) existing.time = hit.time
    } else {
      bySession.set(hit.sessionId, { sessionId: hit.sessionId, title: hit.sessionTitle, time: hit.time, items: [hit] })
    }
  }
  return [...bySession.values()].sort((a, b) => b.time - a.time || a.sessionId.localeCompare(b.sessionId))
}

/** Map character offsets [start,end) of `full` onto the `base`-shifted window. */
export function shiftSpans(
  spans: readonly (readonly [number, number])[],
  base: number,
  length: number,
): [number, number][] {
  const shifted: [number, number][] = []
  for (const span of spans) {
    const start = Math.max(0, span[0] - base)
    const end = Math.min(length, span[1] - base)
    if (end > start) shifted.push([start, end])
  }
  return shifted
}

/** Merge overlapping/adjacent ranges (also sorts and normalizes inverted spans). */
export function mergeRanges(ranges: [number, number][]): [number, number][] {
  if (ranges.length === 0) return []
  const sorted = ranges
    .map(([start, end]): [number, number] => start <= end ? [start, end] : [end, start])
    .sort((a, b) => a[0] - b[0] || a[1] - b[1])
  const merged: [number, number][] = []
  for (const [start, end] of sorted) {
    const last = merged[merged.length - 1]
    if (last !== undefined && start <= last[1]) {
      last[1] = Math.max(last[1], end)
    } else {
      merged.push([start, end])
    }
  }
  return merged
}

/**
 * Build the display window for a hit by slicing `text` + `spans` directly
 * (final contract: spans are offsets INTO text; the hit carries no snippet
 * window metadata). The window is centered on the FIRST span with ±120
 * characters — the same formula the host uses for its snippet — and extends
 * to cover the last span. Spans are then shifted onto the window and merged.
 * The host `snippet` is used only when there is nothing to slice (empty
 * text / no spans), never as an alignment basis.
 */
export function snippetView(hit: SearchHit): { text: string; spans: [number, number][] } {
  const full = hit.text
  if (full === '') return { text: hit.snippet, spans: [] }
  if (hit.spans.length === 0) return { text: hit.snippet !== '' ? hit.snippet : full, spans: [] }
  const firstSpan = hit.spans[0]
  const lastSpan = hit.spans[hit.spans.length - 1]
  if (firstSpan === undefined || lastSpan === undefined) return { text: hit.snippet !== '' ? hit.snippet : full, spans: [] }
  const start = Math.max(0, firstSpan[0] - 120)
  const end = Math.min(full.length, Math.max(firstSpan[0] + 120, lastSpan[1]))
  return {
    text: full.slice(start, end),
    spans: mergeRanges(shiftSpans(hit.spans, start, end - start)),
  }
}

/**
 * Keep a dragged overlay inside the viewport. If the panel is larger than
 * the viewport, pin it to the margin instead of letting it escape.
 */
export function clampOverlayPosition(
  left: number,
  top: number,
  width: number,
  height: number,
  viewportWidth: number,
  viewportHeight: number,
  margin = 8,
): { left: number; top: number } {
  const maxLeft = Math.max(margin, viewportWidth - width - margin)
  const maxTop = Math.max(margin, viewportHeight - height - margin)
  return {
    left: Math.min(maxLeft, Math.max(margin, left)),
    top: Math.min(maxTop, Math.max(margin, top)),
  }
}

function relativeTime(epochMs: number): string {
  const diff = Date.now() - epochMs
  const rtf = new Intl.RelativeTimeFormat(navigator.language, { numeric: 'auto' })
  if (diff < 60_000) return rtf.format(0, 'minute')
  if (diff < 3_600_000) return rtf.format(-Math.round(diff / 60_000), 'minute')
  if (diff < 86_400_000) return rtf.format(-Math.round(diff / 3_600_000), 'hour')
  if (diff < 14 * 86_400_000) return rtf.format(-Math.round(diff / 86_400_000), 'day')
  return new Date(epochMs).toLocaleDateString(navigator.language, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

function absoluteTime(epochMs: number): string {
  return new Date(epochMs).toLocaleString(navigator.language, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function MarkedText({ text, spans }: { text: string; spans: [number, number][] }) {
  if (spans.length === 0) return <>{text}</>
  const nodes: ReactNode[] = []
  let cursor = 0
  for (const [start, end] of spans) {
    if (start > cursor) nodes.push(text.slice(cursor, start))
    nodes.push(<mark key={`${start}-${end}`} className="msp-mark">{text.slice(start, end)}</mark>)
    cursor = end
  }
  if (cursor < text.length) nodes.push(text.slice(cursor))
  return <>{nodes}</>
}

// 用户验收二轮：工具文字重新纳入索引——筛选恢复 全部 / 用户 / Agent / 工具；
// 'other'（注入上下文等）不索引，不设标签。
const ROLE_CHIPS: readonly RoleFilter[] = ['all', 'user', 'assistant', 'tool']

export function SearchPanel({ t, bindingSession, openSession, resolveSubagent, openSubagent, remote }: PanelProps) {
  const overlay = useSyncExternalStore(subscribeOverlay, getOverlaySnapshot)
  const [query, setQuery] = useState('')
  const [state, setState] = useState<SearchState>({ kind: 'idle' })
  const [status, setStatus] = useState<IndexStatus>(emptyIndexStatus())
  const [roleFilter, setRoleFilter] = useState<RoleFilter>('user')
  const [busyKey, setBusyKey] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement | null>(null)
  const panelRef = useRef<HTMLDivElement | null>(null)
  const dragRef = useRef<{
    pointerId: number
    startX: number
    startY: number
    origLeft: number
    origTop: number
  } | null>(null)
  const seqRef = useRef(0)
  const debounceRef = useRef<number | undefined>(undefined)
  const [panelPos, setPanelPos] = useState<{ left: number; top: number } | null>(null)
  const [dragging, setDragging] = useState(false)
  const { open, toast } = overlay

  const runSearch = useCallback(async (q: string, seq: number, role: RoleFilter) => {
    try {
      const payload = await callRemote(remote, 'search', { query: q, limit: SEARCH_LIMIT, role })
      if (seqRef.current !== seq) return
      const result = normalizeSearch(payload)
      if (result.error !== null) setState({ kind: 'error', message: result.error, errorCode: result.errorCode })
      else setState({ kind: 'done', hits: result.hits, truncated: result.truncated })
    } catch (error) {
      if (seqRef.current !== seq) return
      setState({ kind: 'error', message: error instanceof Error ? error.message : String(error), errorCode: 'E_INTERNAL' })
    }
  }, [remote])

  // Debounced search on query / speaker-filter change (300 ms).
  useEffect(() => {
    const q = query.trim()
    if (q === '') {
      seqRef.current += 1
      setState({ kind: 'idle' })
      return
    }
    setState((previous) => ({ kind: 'searching', previous: previous.kind === 'done' ? previous.hits : [] }))
    debounceRef.current = window.setTimeout(() => {
      const seq = seqRef.current + 1
      seqRef.current = seq
      void runSearch(q, seq, roleFilter)
    }, DEBOUNCE_MS)
    return () => {
      if (debounceRef.current !== undefined) window.clearTimeout(debounceRef.current)
    }
  }, [query, roleFilter, runSearch])

  // Re-run a persisted query each time the panel opens (the entry stays
  // mounted, so `query` is read at open-time on purpose).
  useEffect(() => {
    if (!open) return
    const focus = (): void => { inputRef.current?.focus() }
    focus()
    const frame = window.requestAnimationFrame(focus)
    const timer = window.setTimeout(focus, 0)
    const q = query.trim()
    if (q !== '') {
      setState((previous) => ({ kind: 'searching', previous: previous.kind === 'done' ? previous.hits : [] }))
      const seq = seqRef.current + 1
      seqRef.current = seq
      void runSearch(q, seq, roleFilter)
    }
    return () => {
      window.cancelAnimationFrame(frame)
      window.clearTimeout(timer)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  // Index status banner + polling while indexing.
  useEffect(() => {
    if (!open) return
    let alive = true
    let inFlight = false
    let timer: number | undefined
    const poll = async (): Promise<void> => {
      if (inFlight) return
      inFlight = true
      try {
        const payload = await callRemote(remote, 'status')
        if (!alive) return
        const next = normalizeStatus(payload)
        setStatus(next)
      } catch {
        if (alive) setStatus(emptyIndexStatus())
      } finally {
        inFlight = false
      }
    }
    void poll()
    timer = window.setInterval(() => { void poll() }, STATUS_POLL_MS)
    return () => {
      alive = false
      if (timer !== undefined) window.clearInterval(timer)
    }
  }, [open, remote])

  // Transient toast auto-clear.
  useEffect(() => {
    if (toast === null) return
    const timer = window.setTimeout(() => clearToast(), TOAST_MS)
    return () => window.clearTimeout(timer)
  }, [toast, overlay.toastSeq])

  useEffect(() => {
    if (panelPos === null) return
    const onResize = (): void => {
      const panel = panelRef.current
      if (panel === null) return
      setPanelPos((current) => current === null ? current : clampOverlayPosition(
        current.left,
        current.top,
        panel.offsetWidth,
        panel.offsetHeight,
        window.innerWidth,
        window.innerHeight,
      ))
    }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [panelPos === null])

  useEffect(() => {
    if (open) return
    dragRef.current = null
    setDragging(false)
  }, [open])

  const onHeaderPointerDown = (event: PointerEvent<HTMLElement>): void => {
    if (event.button !== 0) return
    const target = event.target
    if (!(target instanceof Element) || target.closest('.msp-close-btn') !== null) return
    const panel = panelRef.current
    if (panel === null) return
    const rect = panel.getBoundingClientRect()
    dragRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      origLeft: rect.left,
      origTop: rect.top,
    }
    setPanelPos({ left: rect.left, top: rect.top })
    setDragging(true)
    event.preventDefault()
    event.currentTarget.setPointerCapture(event.pointerId)
  }

  const onHeaderPointerMove = (event: PointerEvent<HTMLElement>): void => {
    const drag = dragRef.current
    const panel = panelRef.current
    if (drag === null || panel === null || event.pointerId !== drag.pointerId) return
    setPanelPos(clampOverlayPosition(
      drag.origLeft + (event.clientX - drag.startX),
      drag.origTop + (event.clientY - drag.startY),
      panel.offsetWidth,
      panel.offsetHeight,
      window.innerWidth,
      window.innerHeight,
    ))
  }

  const endHeaderDrag = (event: PointerEvent<HTMLElement>): void => {
    if (dragRef.current === null || event.pointerId !== dragRef.current.pointerId) return
    dragRef.current = null
    setDragging(false)
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId)
    }
  }

  // Restore in-conversation <mark> nodes and flush timers on unmount.
  useEffect(
    () => () => {
      if (debounceRef.current !== undefined) window.clearTimeout(debounceRef.current)
      restoreTextMarks()
      clearTargetFlash()
    },
    [],
  )

  const jumpToHit = async (hit: SearchHit): Promise<void> => {
    const queryTrimmed = query.trim()
    if (busyKey !== null) return
    const key = `${hit.sessionId}:${hit.seq}`
    setBusyKey(key)
    try {
      // Binding may be undefined before the session is current; jumpToAnchor
      // opens the session first, then waits for the binding to appear.
      const outcome = await jumpToAnchor(hit.sessionId, hit.anchorKey, queryTrimmed, {
        bindingSession: (sessionId) => bindingSession(sessionId),
        openSession,
        resolveSubagent,
        openSubagent,
      })
      if (outcome.ok) {
        closeOverlay()
      } else if (outcome.reason === 'compacted') {
        setToast(t('toast.anchorMissing'))
      } else if (outcome.reason === 'not-rendered') {
        setToast(t('toast.anchorPending'))
      } else {
        setToast(t('toast.sessionUnavailable'))
      }
    } finally {
      setBusyKey(null)
    }
  }

  const flushSearch = (): void => {
    const q = query.trim()
    if (q === '') return
    if (debounceRef.current !== undefined) window.clearTimeout(debounceRef.current)
    const seq = seqRef.current + 1
    seqRef.current = seq
    void runSearch(q, seq, roleFilter)
  }

  const shownHits = state.kind === 'done'
    ? state.hits.filter((hit) => roleFilter === 'all' || roleOf(hit) === roleFilter)
    : state.kind === 'searching' && roleFilter === 'all'
      ? state.previous
      : []
  const groups = groupHits(shownHits)

  // ---- closed (but keep the entry mounted so state survives reopen) ----
  if (!open) return null

  const searching = state.kind === 'searching'
  const statusLine =
    state.kind === 'searching'
      ? t('panel.searching')
      : state.kind === 'error'
        ? state.errorCode === 'E_NOT_READY'
          ? t('panel.indexing')
          : `${t('panel.error')}: ${state.message}`
        : state.kind === 'done'
          ? state.hits.length === 0
            ? t('panel.notFound')
            : roleFilter === 'all'
              ? `${t('panel.count', { n: state.hits.length })}${state.truncated ? ` · ${t('panel.truncated')}` : ''}`
              : `${shownHits.length} / ${state.hits.length}`
          : t('panel.hint')

  return createPortal(
    <div className="msp-overlay-layer">
    <div
      ref={panelRef}
      className={`msp-overlay-root${dragging ? ' msp-overlay-dragging' : ''}${panelPos !== null ? ' msp-overlay-moved' : ''}`}
      role="dialog"
      aria-modal="true"
      aria-label={t('panel.title')}
      style={panelPos === null ? undefined : { left: panelPos.left, top: panelPos.top, right: 'auto', transform: 'none' }}
    >
      <header
        className="msp-panel-header"
        onPointerDown={onHeaderPointerDown}
        onPointerMove={onHeaderPointerMove}
        onPointerUp={endHeaderDrag}
        onPointerCancel={endHeaderDrag}
      >
        <span className="msp-panel-title" aria-hidden="true">{t('panel.title')}</span>
        <button type="button" className="msp-close-btn" aria-label={t('panel.close')} onClick={() => closeOverlay()} onPointerDown={(event) => event.stopPropagation()}>
          <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true">
            <line x1="4" y1="4" x2="12" y2="12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="12" y1="4" x2="4" y2="12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </button>
      </header>
      <div className="msp-search-row">
        <svg className="msp-search-icon" viewBox="0 0 16 16" width="15" height="15" fill="none" aria-hidden="true">
          <circle cx="7" cy="7" r="4.5" stroke="currentColor" strokeWidth="1.5" />
          <line x1="10.5" y1="10.5" x2="14" y2="14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
        <input
          ref={inputRef}
          className="msp-search-input"
          type="text"
          value={query}
          placeholder={t('panel.placeholder')}
          spellCheck={false}
          autoComplete="off"
          autoFocus
          maxLength={MAX_QUERY_CHARS}
          onChange={(event) => setQuery(event.target.value)}
          onKeyDown={(event) => {
            event.stopPropagation()
            if (event.key === 'Enter' && !event.nativeEvent.isComposing) flushSearch()
          }}
        />
      </div>

      {status.phase === 'indexing' ? (
        <div className="msp-banner msp-banner-indexing">{t('panel.indexing')}</div>
      ) : status.phase === 'degraded' ? (
        <div className="msp-banner msp-banner-degraded">{t('panel.degraded')}</div>
      ) : status.phase === 'error' ? (
        <div className="msp-banner msp-banner-error">{t('panel.indexError')}{status.message !== null ? `: ${status.message}` : ''}</div>
      ) : null}

      <div className={`msp-status${state.kind === 'error' ? ' msp-status-error' : ''}${searching ? ' msp-status-searching' : ''}`}>
        {statusLine}
      </div>

      <div className="msp-chips" role="tablist" aria-label={t('panel.filter')}>
        {ROLE_CHIPS.map((chip) => (
          <button
            key={chip}
            type="button"
            role="tab"
            aria-selected={roleFilter === chip || undefined}
            className={`msp-chip${roleFilter === chip ? ' msp-chip-active' : ''}`}
            onClick={() => setRoleFilter(chip)}
          >
            {chip === 'all' ? t('role.all') : t(`role.${chip}`)}
          </button>
        ))}
      </div>

      {toast !== null && <div className="msp-toast">{toast}</div>}

      <div className="msp-groups">
        {state.kind === 'idle' && <div className="msp-empty">{t('panel.hint')}</div>}
        {state.kind === 'done' && state.hits.length === 0 && <div className="msp-empty">{t('panel.notFound')}</div>}
        {groups.map((group) => (
          <section key={group.sessionId} className="msp-group">
            <header className="msp-group-header">
              <span className="msp-group-title" title={group.sessionId}>{group.title !== '' ? group.title : t('session.untitled')}</span>
              <span className="msp-group-time">{relativeTime(group.time)}</span>
            </header>
            <ul className="msp-hit-list">
              {group.items.map((hit) => {
                const view = snippetView(hit)
                // seq is the idempotent-unique per-session key: tool/call and
                // tool/result share an anchorKey and empty-anchor hits repeat
                // `${sessionId}:''` — both would collide on anchorKey.
                const key = `${hit.sessionId}:${hit.seq}`
                const busy = busyKey === key
                // Non-locatable hits (anchorKey null: todo/write, turn/end, …)
                // are shown but never jump — rendered as a static row.
                const locatable = hit.anchorKey !== ''
                // v1: snippet 为主视觉（最前、占满剩余宽度），badge（我/Agent）
                // 与时间收在右侧。
                const content = (
                  <>
                    <span className="msp-hit-text">
                      <MarkedText text={view.text} spans={view.spans} />
                    </span>
                    <span className={`msp-hit-role msp-role-${roleOf(hit)}`}>
                      {t(`role.${roleOf(hit)}`)}
                    </span>
                    <span className="msp-hit-side">
                      <span className="msp-hit-time">{absoluteTime(hit.time)}</span>
                      {hit.matchCount > 1 ? (
                        <span className="msp-hit-matches">{t('panel.matches', { n: hit.matchCount })}</span>
                      ) : null}
                      {hit.textTruncated ? (
                        <span className="msp-hit-truncated">{t('panel.textTruncated')}</span>
                      ) : null}
                    </span>
                  </>
                )
                return (
                  <li key={key}>
                    {locatable ? (
                      <button
                        type="button"
                        className={`msp-hit msp-hit-${roleOf(hit)}${busy ? ' msp-hit-busy' : ''}`}
                        onClick={() => { void jumpToHit(hit) }}
                        disabled={busy}
                      >
                        {content}
                      </button>
                    ) : (
                      <div className={`msp-hit msp-hit-static msp-hit-${roleOf(hit)}`} title={t('panel.notLocatable')}>
                        {content}
                      </div>
                    )}
                  </li>
                )
              })}
            </ul>
          </section>
        ))}
      </div>
    </div>
    </div>,
    document.body,
  )
}
