/**
 * dsh-memory-search-plus Host half — 插件入口（静态插件 RPC 标准路径）。
 *
 * Host→Client RPC 走 @Remote Service（与 dsh-goal 同构）：
 *   class MemorySearchRemoteService extends TypertRemoteService {
 *     constructor(ctx) { super(ctx, 'memorySearch') }   // ctx.reflect.provide 注册
 *     @Remote('search') async search(request) {...}
 *     ...
 *   }
 * 客户端经 inject ['remote','remote.memorySearch'] 以 ctx.remote.memorySearch.search(...) 调用。
 *
 * H2/H3（t11 采纳 REVIEW-architect）：
 *  - session_state 持久水印：upsert/重建回写 max_seq/dirty/built_at；压缩检查点置
 *    dirty=1 持久化；启动 = 空库才 rebuildAll，非空库只 reconcile（断点续建语义）；
 *  - reconcile：① 新会话补索引 ② max_seq 缺口 readFrom(max_seq+1) 补齐 ③ 孤儿删除；
 *  - H3：全量重建 worker 池并发（env DSH_MEMORY_SEARCH_REINDEX_CONCURRENCY，默认 8，clamp 1..16）。
 *  - 重建热路径只 readFrom/readSession 一次，surface 由本地 foldRawEventSurfaces 折叠；
 *    filterEvents 仅在原始日志读空时回退。
 *
 * - 可选服务：ctx.get('sessionQuery') / ctx.get('sessionPersistence')；缺失时插件可加载
 *   （ready=false，30s 探测重试），不硬 inject 避免进入 waiting。
 * - 事件：session/event 增量（300ms debounce 批量）；session/disposed → 删除；
 *   5 分钟 reconcile（上限 20 会话/周期）。
 * - 全部清理走 ctx.effect（事件订阅、定时器、debounce、索引 close）。
 *
 * 所有 JSON 往返仅含纯数据：无 Service/Session 对象，不序列化 live 对象。
 */

import type { Context } from '@deepseek-ai/cordis'
import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import { createSearchIndex, upsertRecordsCooperatively } from './indexer.ts'
import {
  copyIndexDatabase,
  defaultIndexDbPath,
  ensureIndexDbDirectory,
  indexDatabaseFileExists,
  normalizeUserDbPath,
  removeIndexDatabaseFiles,
  resolveIndexDbPath,
  sameIndexPath,
  writePersistedDbPath,
} from './db-path.ts'
import { boundIndexText } from './index-text.ts'
import { anchorKeyFor, buildIndexRecordsFromEvents, extractSessionEventText, isHumanUserMessage } from './extract.ts'
import { parseSearchRole } from './search.ts'
import {
  DEFAULT_REINDEX_CONCURRENCY,
  DEFAULT_SEARCH_LIMIT,
  MAX_REINDEX_CONCURRENCY,
  MAX_QUERY_CHARS,
  MAX_SEARCH_LIMIT,
  requiresSurfaceRebuild,
  isSubagentSession,
  type IndexRecord,
  type SearchHit,
  type SearchIndex,
  type SessionEvent,
  type SessionPersistenceLike,
  type SessionQueryLike,
  type Surface,
  type TitleObservation,
} from './types.ts'

export const name = 'memory-search'

export const inject: readonly string[] = []

/** Optional Cordis plugin config. Settings-page path overrides this. */
export interface PluginConfig {
  dbPath?: string
}

// 供基准脚本（scripts/bench.mjs --impl lib/index.js）直接驱动真实实现。
export { createSearchIndex, upsertRecordsCooperatively } from './indexer.ts'

const RECONCILE_INTERVAL_MS = 5 * 60_000
const MAINTENANCE_INTERVAL_MS = 30 * 60_000
const SERVICE_PROBE_INTERVAL_MS = 30_000
const DEBOUNCE_MS = 300
const RECONCILE_BATCH = 20
const MAX_PENDING_RECORDS_PER_SESSION = 5_000
const MAX_PENDING_TEXT_CHARS_PER_SESSION = 8_000_000
const TITLE_LOOKUP_TIMEOUT_MS = 1_500
const SESSION_GRAPH_TTL_MS = 60_000
const SESSION_GRAPH_TIMEOUT_MS = 2_000

/** H3：重建并发度（env 可配；默认 8，clamp 1..16）。 */
export function reindexConcurrency(): number {
  const raw = Number(process.env.DSH_MEMORY_SEARCH_REINDEX_CONCURRENCY)
  if (!Number.isFinite(raw) || raw <= 0) return DEFAULT_REINDEX_CONCURRENCY
  return Math.min(MAX_REINDEX_CONCURRENCY, Math.max(1, Math.floor(raw)))
}

interface RebuildDoc {
  sessionId: string
  seq: number
  type: string
  time: number
  surface: Surface
  text: string
}

interface PendingBatch {
  records: IndexRecord[]
  maxSeq: number
  textChars: number
}

// ---------------------------------------------------------------------------
// H1：标题观察 → hits 映射（导出的纯函数，RPC 层单测覆盖）
// ---------------------------------------------------------------------------
/**
 * 按真实形状解析 readTitleSnapshots 观察结果：
 * `[{sessionId, status, value?: {title?: {title?}}}]`，规则（ARCHITECTURE §0 事实表）：
 * `status === 'fulfilled' && value.title?.title` 为字符串且非空 → 替换 hit.sessionTitle；
 * rejected / 缺 value / 空标题 → 保留回退（会话 id 前 8 位）；单条 rejected 不抛错。
 * 旧扁平形状（{sessionId, title}）防御兼容保留（QA 测试锁定）。
 */
export function applyTitleObservations(hits: SearchHit[], observations: unknown[]): void {
  const byId = new Map<string, string>()
  for (const raw of observations ?? []) {
    if (raw === null || typeof raw !== 'object') continue
    const observation = raw as TitleObservation
    const sid = observation.sessionId
    if (typeof sid !== 'string' || sid.length === 0) continue
    const nested = observation.value?.title?.title
    if (
      observation.status === 'fulfilled' &&
      typeof nested === 'string' &&
      nested.length > 0
    ) {
      byId.set(sid, nested)
      continue
    }
    // 旧扁平形状防御兼容（无 status 字段）
    if (typeof observation.title === 'string' && observation.title.length > 0) {
      byId.set(sid, observation.title)
    }
  }
  for (const hit of hits) {
    const title = byId.get(hit.sessionId)
    if (title !== undefined) hit.sessionTitle = title
  }
}

/**
 * 子代理会话通常无自身标题。命中仍是 id 前 8 位回退时，用已缓存的父标题修饰为
 * 「父标题 › 子id前8位」。不查询 listSessions——那条路径在搜索热路径上可达十几秒。
 */
export function applyParentTitles(
  hits: SearchHit[],
  parentBySession: ReadonlyMap<string, string>,
  titleBySession: ReadonlyMap<string, string>,
): void {
  for (const hit of hits) {
    const fallback = hit.sessionId.slice(0, 8)
    if (!hit.sessionTitle.startsWith(fallback)) continue
    const parent = parentBySession.get(hit.sessionId)
    if (parent === undefined) continue
    const parentTitle = titleBySession.get(parent)
    if (parentTitle !== undefined && parentTitle.length > 0) {
      hit.sessionTitle = `${parentTitle} › ${hit.sessionTitle}`
    }
  }
}

function parentSessionOf(session: unknown): string | undefined {
  if (session === null || typeof session !== 'object') return undefined
  const rec = session as { parentSession?: unknown; header?: { parentSession?: unknown } }
  if (typeof rec.parentSession === 'string' && rec.parentSession.length > 0) return rec.parentSession
  const nested = rec.header?.parentSession
  if (typeof nested === 'string' && nested.length > 0) return nested
  return undefined
}

type SessionListRecord = {
  id?: string
  origin?: unknown
  header?: { id?: string; parentSession?: string; origin?: unknown }
}

function sessionListId(record: SessionListRecord): string | undefined {
  const id = record.header?.id
  return typeof id === 'string' && id.length > 0 ? id : undefined
}

/** Forked user chats have `parentSession` too. Only `origin === 'subagent'` is skipped. */
export function partitionListedSessions(sessions: SessionListRecord[]): {
  indexableIds: string[]
  subagentIds: string[]
  listed: number
} {
  const indexable: string[] = []
  const skipped: string[] = []
  const seen = new Set<string>()
  for (const record of sessions) {
    const id = sessionListId(record)
    if (id === undefined || seen.has(id)) continue
    seen.add(id)
    if (isSubagentSession(record)) skipped.push(id)
    else indexable.push(id)
  }
  return { indexableIds: indexable, subagentIds: skipped, listed: sessions.length }
}

function titleProbeHits(ids: Iterable<string>): SearchHit[] {
  const hits: SearchHit[] = []
  for (const id of ids) {
    hits.push({
      sessionId: id,
      sessionTitle: id.slice(0, 8),
      seq: 0,
      type: 'user/message',
      role: 'user',
      time: 0,
      anchorKey: null,
      text: '',
      snippet: '',
      spans: [],
      matchCount: 0,
      textTruncated: false,
    })
  }
  return hits
}

/**
 * RPC 层标题升级入口：readTitleSnapshots 拒绝/异常时保留回退（id 前 8 位）。
 */
export async function upgradeTitlesWith(
  hits: SearchHit[],
  readTitleSnapshots: (ids: string[]) => Promise<unknown[]>,
  timeoutMs = TITLE_LOOKUP_TIMEOUT_MS,
): Promise<void> {
  if (hits.length === 0 || typeof readTitleSnapshots !== 'function') return
  const ids = [...new Set(hits.map((hit) => hit.sessionId))]
  const deadline = Number.isFinite(timeoutMs) ? Math.min(10_000, Math.max(1, timeoutMs)) : TITLE_LOOKUP_TIMEOUT_MS
  let timer: ReturnType<typeof setTimeout> | undefined
  try {
    // Titles are decorative. A stuck title service must never hold the search
    // RPC open indefinitely; late completion is safely ignored.
    const observations = await Promise.race([
      readTitleSnapshots(ids),
      new Promise<unknown[]>((resolve) => {
        timer = setTimeout(() => resolve([]), deadline)
      }),
    ])
    applyTitleObservations(hits, observations)
  } catch {
    /* 标题升级失败不致命：保留回退 */
  } finally {
    if (timer !== undefined) clearTimeout(timer)
  }
}

/**
 * memory-search 远程服务：memory-search/search|status|reindex|setDbPath 纯 JSON 方法
 * （wire 命名空间默认 = serviceKey 'memorySearch'）。
 */
class MemorySearchRemoteService extends TypertRemoteService {
  static inject: readonly string[] = []

  private index: SearchIndex
  private dbPath: string
  private building = false
  private rebuildingAll = false
  private reconciling = false
  private started = false
  /** 全量重建进度（settings 轮询用）；空闲为 null。 */
  private rebuildProgress: { current: number; total: number } | null = null
  /** 防止 constructor 与 30s 探针重叠进入 startup。 */
  private starting = false
  private readonly dirtySessions = new Set<string>()
  /** 重建期间被 disposed 的会话：upsert 前再检查，避免删后写回。 */
  private readonly disposedSessions = new Set<string>()
  /** sessionId → 已抽取、已限长的增量记录与原始 seq 水印。避免在 debounce
   * 期间保留可能很大的完整事件对象。 */
  private readonly pendingEvents = new Map<string, PendingBatch>()
  private flushTimer: ReturnType<typeof setTimeout> | null = null
  private closed = false
  /** 搜索热路径标题/父会话图缓存。listSessions 很贵，绝不能跟在每次 search 后面。 */
  private readonly titleBySession = new Map<string, string>()
  private readonly parentBySession = new Map<string, string>()
  private readonly subagentSessions = new Set<string>()
  private sessionGraphAt = 0
  private sessionGraphInflight: Promise<void> | null = null

  constructor(ctx: Context, config: PluginConfig = {}) {
    super(ctx, 'memorySearch')
    this.dbPath = resolveIndexDbPath(
      typeof config.dbPath === 'string' ? { configPath: config.dbPath } : {},
    )
    this.index = createSearchIndex({ dbPath: this.dbPath })

    ctx.effect(() => {
      const subscribe = (
        event: string,
        listener: (...args: unknown[]) => void,
      ): (() => void) => {
        const raw = ctx.on as unknown as (name: string, fn: (...args: unknown[]) => void) => () => void
        return raw(event, listener)
      }
      const disposers: Array<() => void> = []

      try {
        disposers.push(
          subscribe('session/event', (session: unknown, rawEvent: unknown) => {
            const event = (rawEvent ?? {}) as SessionEvent & { sessionId?: string }
            const sessionId =
              (session !== null && typeof session === 'object' ? (session as { id?: string }).id : undefined) ??
              event.sessionId
            if (typeof sessionId !== 'string' || sessionId.length === 0) return
            if (isSubagentSession(session)) {
              this.subagentSessions.add(sessionId)
              return
            }
            this.subagentSessions.delete(sessionId)
            this.onSessionEvent(sessionId, event)
          }),
        )
      } catch (error) {
        console.warn(`[memory-search] session/event 订阅失败: ${error instanceof Error ? error.message : String(error)}`)
      }

      try {
        disposers.push(
          subscribe('session/disposed', (session: unknown) => {
            const sessionId =
              session !== null && typeof session === 'object' ? (session as { id?: string }).id : undefined
            if (typeof sessionId === 'string') this.onSessionDisposed(sessionId)
          }),
        )
      } catch (error) {
        console.warn(`[memory-search] session/disposed 订阅失败: ${error instanceof Error ? error.message : String(error)}`)
      }

      try {
        disposers.push(
          subscribe('session/created', (session: unknown) => {
            const sessionId =
              session !== null && typeof session === 'object' ? (session as { id?: string }).id : undefined
            if (typeof sessionId !== 'string') return
            this.disposedSessions.delete(sessionId)
            if (isSubagentSession(session)) this.subagentSessions.add(sessionId)
            else this.subagentSessions.delete(sessionId)
            const parent = parentSessionOf(session)
            if (parent !== undefined) this.parentBySession.set(sessionId, parent)
            else this.parentBySession.delete(sessionId)
          }),
        )
      } catch {
        /* 可选事件，订阅失败不致命 */
      }

      const reconcileTimer = setInterval(() => {
        this.runBackground('reconcile', () => this.reconcile())
      }, RECONCILE_INTERVAL_MS)
      disposers.push(() => clearInterval(reconcileTimer))

      const maintenanceTimer = setInterval(() => {
        if (this.closed || this.building || this.rebuildingAll) return
        try {
          this.index.optimize()
        } catch (error) {
          console.warn(`[memory-search] 空闲维护失败: ${error instanceof Error ? error.message : String(error)}`)
        }
      }, MAINTENANCE_INTERVAL_MS)
      disposers.push(() => clearInterval(maintenanceTimer))

      const probeTimer = setInterval(() => {
        if (this.servicesReady() && !this.started) {
          this.runBackground('startup probe', () => this.startup())
        }
      }, SERVICE_PROBE_INTERVAL_MS)
      disposers.push(() => clearInterval(probeTimer))

      let closePending = false
      disposers.push(() => {
        if (closePending) return
        closePending = true
        if (this.flushTimer !== null) {
          clearTimeout(this.flushTimer)
          this.flushTimer = null
        }
        this.closed = true
        try {
          this.index.close()
        } catch {
          /* 已关闭 */
        }
      })

      if (this.servicesReady() && !this.started) {
        this.runBackground('startup', () => this.startup())
      }

      return () => {
        for (const dispose of disposers) {
          try {
            dispose()
          } catch {
            /* 幂等 */
          }
        }
      }
    })
  }

  // -------------------------------------------------------------------------
  // 服务获取
  // -------------------------------------------------------------------------
  private queryService(): SessionQueryLike | undefined {
    const ctx = this.ctx
    return ctx.get('sessionQuery') as SessionQueryLike | undefined
  }

  private persistenceService(): SessionPersistenceLike | undefined {
    const ctx = this.ctx
    return ctx.get('sessionPersistence') as SessionPersistenceLike | undefined
  }

  private servicesReady(): boolean {
    return this.queryService() !== undefined && this.persistenceService() !== undefined
  }

  /** Fire-and-forget work must still terminate its rejection chain. */
  private runBackground(label: string, task: () => Promise<unknown>): void {
    void task().catch((error) => {
      console.warn(
        `[memory-search] ${label} 后台任务失败: ${error instanceof Error ? error.message : String(error)}`,
      )
    })
  }

  // -------------------------------------------------------------------------
  // H2 启动模型：空库 → 全量重建；非空库 → 只 reconcile（断点续建/不重复已建）
  // -------------------------------------------------------------------------
  private async startup(): Promise<void> {
    if (this.starting || this.closed) return
    this.starting = true
    try {
      const status = this.index.status()
      if (status.indexedDocs === 0 && status.indexedSessions === 0) {
        const ok = await this.rebuildAll()
        this.started = ok
        if (!ok) {
          console.warn('[memory-search] 首次全量重建未完成（listSessions 失败或服务未就绪，等待探针重试）')
        }
      } else {
        const ok = await this.reconcile()
        this.started = ok
        if (!ok) {
          console.warn('[memory-search] reconcile 未完成（服务未就绪或 listSessions 失败，等待探针重试）')
        }
      }
    } catch (error) {
      this.started = false
      console.warn(
        `[memory-search] startup 失败（等待后续重试）: ${error instanceof Error ? error.message : String(error)}`,
      )
    } finally {
      this.starting = false
    }
  }

  // -------------------------------------------------------------------------
  // 会话重建（filterEvents 为 surface 事实源；readSession/readFrom 提供锚点键）
  // -------------------------------------------------------------------------
  /** 正在重建的会话（并发守卫：同会话只跑一个重建，避免重复删除+重插）。 */
  private readonly rebuildingSessions = new Set<string>()

  /**
   * 锚点键原始事件来源（按实测读取成本选择，ARCHITECTURE §8：filterEvents 串行
   * 288s/109 会话，读取路径是建库瓶颈，必须避免每会话二次全量读）：
   *  1. 优先 sessionPersistence.readFrom(id, 0)——detached 物理后缀读（无 replay
   *     校验/无准备缓存），历史持久化会话全量日志一次到手，成本最低；船长实测
   *     32,898 条事件会话全量可取（{meta, events}，events 为 {type,seq,time,data}，
   *     无 surface 字段——surface 以 filterEvents 为事实源，此处仅取锚点）；
   *  2. 为空（活的会话尚无持久化日志）→ 回退 sessionQuery.readSession
   *     （live-preferred，含未持久化尾部；仅对少量活跃会话触发）；
   *  3. 仍失败 → 锚点 null（可搜索不跳转，不致命）。
   */
  private async loadRawEvents(sessionId: string): Promise<SessionEvent[]> {
    const persistence = this.persistenceService()
    if (persistence !== undefined) {
      try {
        const { events } = await persistence.readFrom(sessionId, 0)
        if (Array.isArray(events) && events.length > 0) return events
      } catch {
        /* 回退到 live 来源 */
      }
    }
    const sessionQuery = this.queryService()
    if (sessionQuery !== undefined && typeof sessionQuery.readSession === 'function') {
      try {
        const snapshot = await sessionQuery.readSession(sessionId)
        const events = snapshot?.events
        if (Array.isArray(events) && events.length > 0) return events
      } catch {
        /* 锚点缺失不致命：命中不可跳转但可搜索 */
      }
    }
    return []
  }

  private retainDirty(sessionId: string): void {
    if (this.closed || this.disposedSessions.has(sessionId)) return
    this.dirtySessions.add(sessionId)
    try {
      this.index.markSessionDirty(sessionId)
    } catch (error) {
      console.warn(
        `[memory-search] ${sessionId} dirty 标记持久化失败: ${error instanceof Error ? error.message : String(error)}`,
      )
    }
  }

  /**
   * Fast rebuild: one persistence read (readFrom / readSession). Surface is
   * folded locally from surfaceOp/sourceEventSeqs so compacted sessions do
   * not pay a second filterEvents load on the same per-id queue.
   * filterEvents is only the fallback when the raw log is empty.
   */
  private async collectRebuildRecords(sessionId: string): Promise<{ records: IndexRecord[]; maxSeq: number } | null> {
    const rawEvents = await this.loadRawEvents(sessionId)
    if (this.disposedSessions.has(sessionId) || this.closed) {
      return { records: [], maxSeq: -1 }
    }
    let maxSeq = -1
    for (const event of rawEvents) {
      if (Number.isSafeInteger(event.seq)) maxSeq = Math.max(maxSeq, event.seq!)
    }
    if (rawEvents.length > 0) {
      const records = buildIndexRecordsFromEvents(sessionId, rawEvents)
      for (const record of records) maxSeq = Math.max(maxSeq, record.seq)
      return { records, maxSeq }
    }
    const sessionQuery = this.queryService()
    if (sessionQuery === undefined) {
      this.retainDirty(sessionId)
      return null
    }
    let docs: RebuildDoc[] = []
    try {
      const result = await sessionQuery.filterEvents(sessionId, [])
      if (!Array.isArray(result)) throw new TypeError('filterEvents returned a non-array payload')
      docs = result as RebuildDoc[]
    } catch (error) {
      this.retainDirty(sessionId)
      console.warn(
        `[memory-search] filterEvents(${sessionId}) 失败: ${error instanceof Error ? error.message : String(error)}`,
      )
      return null
    }
    const anchorBySeq = new Map<number, string | null>()
    const skipUserInjection = new Set<number>()
    for (const event of rawEvents) {
      if (event === null || typeof event !== 'object') continue
      if (typeof event.seq !== 'number') continue
      anchorBySeq.set(event.seq, anchorKeyFor(event))
      if (event.type === 'user/message' && !isHumanUserMessage(event)) skipUserInjection.add(event.seq)
    }
    const records: IndexRecord[] = []
    for (const doc of docs) {
      if (skipUserInjection.has(doc.seq)) continue
      if (doc.surface === 'shadowed') continue
      records.push({
        sessionId,
        seq: doc.seq,
        type: doc.type,
        time: doc.time,
        surface: doc.surface,
        text: doc.text,
        anchorKey: anchorBySeq.get(doc.seq) ?? null,
      })
    }
    for (const doc of docs) {
      if (Number.isSafeInteger(doc.seq)) maxSeq = Math.max(maxSeq, doc.seq)
    }
    return { records, maxSeq }
  }

  private async rebuildSession(sessionId: string): Promise<boolean> {
    if (this.rebuildingSessions.has(sessionId)) return false
    if (this.disposedSessions.has(sessionId)) return true
    if (this.closed) return false
    this.rebuildingSessions.add(sessionId)
    try {
      // 每遍开始先清掉「触发本遍」的 dirty；若 await 期间又 compact/prune，
      // dirtySessions 会被重新 add，结束时 stillDirty → 再跑（上限 3 遍）。
      for (let pass = 0; pass < 3; pass++) {
        this.dirtySessions.delete(sessionId)
        if (this.disposedSessions.has(sessionId)) return true
        if (this.closed) return false
        const collected = await this.collectRebuildRecords(sessionId)
        if (collected === null) return false
        if (this.disposedSessions.has(sessionId)) return true
        if (this.closed) return false
        const { records, maxSeq } = collected
        await upsertRecordsCooperatively(this.index, records, [sessionId])
        if (this.disposedSessions.has(sessionId)) {
          // Handles asynchronous SearchIndex implementations too: disposal
          // may have happened after the delete but before the upsert resolved.
          try { this.index.removeSession(sessionId) } catch { /* next reconcile removes the orphan */ }
          return true
        }
        if (this.closed) return false
        this.index.advanceSessionWatermark(sessionId, maxSeq)
        const stillDirty = this.dirtySessions.has(sessionId)
        if (!stillDirty) {
          this.index.clearSessionDirty(sessionId)
          return true
        }
        this.index.markSessionDirty(sessionId)
        console.warn(`[memory-search] ${sessionId} 重建完成但期间再次变脏，重跑第 ${pass + 2} 遍`)
      }
      this.retainDirty(sessionId)
      console.warn(`[memory-search] ${sessionId} 连续 3 遍重建仍未收敛，保留 dirty 交 reconcile 处理`)
      return false
    } catch (error) {
      this.retainDirty(sessionId)
      console.warn(
        `[memory-search] rebuildSession(${sessionId}) 失败（保留状态供后续重试）: ` +
          `${error instanceof Error ? error.message : String(error)}`,
      )
      return false
    } finally {
      this.rebuildingSessions.delete(sessionId)
      if (!this.closed && !this.disposedSessions.has(sessionId)) await this.flushPending()
    }
  }

  // -------------------------------------------------------------------------
  // H3：并发构建池（默认 8，范围 1..16）。热路径只 readFrom/readSession 一次。
  // 并发不宜再加：readFrom 会把整份解压日志留在内存，16 路会把磁盘和 GC 打满。
  // -------------------------------------------------------------------------
  /**
   * 并发构建会话列表（每会话一次 raw log + 同事务 upsert）。
   * 期间 this.building=true：search 可查已索引部分并返回 partial:true，
   * 已建会话不重复读（断点续建依赖 session_state 行）。
   * 单会话失败记录 warn 并保留 dirty（下次 probe/reconcile 续建）。
   */
  private async buildSessions(ids: string[]): Promise<boolean> {
    if (ids.length === 0) return true
    if (this.building || this.closed) return false
    this.building = true
    let completed = 0
    let failed = 0
    try {
      const CONCURRENCY = reindexConcurrency()
      let cursor = 0
      const worker = async (): Promise<void> => {
        for (;;) {
          if (this.closed) return
          const slot = cursor++
          const sessionId = ids[slot]
          if (sessionId === undefined) return
          try {
            const ok = await this.rebuildSession(sessionId)
            if (!ok) failed++
          } catch (error) {
            // rebuildSession is defensive, but keep the worker pool alive if a
            // future implementation lets an unexpected rejection escape.
            console.warn(
              `[memory-search] ${sessionId} 重建任务异常: ${error instanceof Error ? error.message : String(error)}`,
            )
            failed++
          }
          completed++
          this.rebuildProgress = { current: completed, total: ids.length }
          if (completed % 10 === 0) {
            console.log(`[memory-search] 构建进度: ${completed}/${ids.length} 个会话`)
          }
          await new Promise<void>((resolve) => { setImmediate(resolve) })
        }
      }
      await Promise.all(Array.from({ length: Math.min(CONCURRENCY, ids.length) }, () => worker()))
      return failed === 0 && !this.closed
    } finally {
      this.building = false
    }
  }

  /** @returns false 当 listSessions 失败或服务未就绪（startup 据此不把 started 钉死）。 */
  private async rebuildAll(options?: { alreadyClaimed?: boolean }): Promise<boolean> {
    if (this.building || this.closed) {
      if (options?.alreadyClaimed === true) this.rebuildingAll = false
      return false
    }
    if (this.rebuildingAll && options?.alreadyClaimed !== true) return false
    this.rebuildingAll = true
    try {
      const sessionQuery = this.queryService()
      if (sessionQuery === undefined) return false
      let sessions: SessionListRecord[] = []
      try {
        const result = await sessionQuery.listSessions()
        if (!Array.isArray(result)) throw new TypeError('listSessions returned a non-array payload')
        sessions = result
        this.ingestSessionGraph(sessions)
      } catch (error) {
        console.warn(`[memory-search] listSessions 失败: ${error instanceof Error ? error.message : String(error)}`)
        return false
      }
      // 真子代理（origin=subagent）是 Agent 内部过程，不入用户搜索。
      // 分支/fork 会话也带 parentSession，必须索引——不能拿 parent 当子代理判别。
      const { indexableIds: ids, subagentIds } = partitionListedSessions(sessions)
      const sourceIds = new Set(ids)
      let consistent = true
      // Manual full reindex is authoritative too: remove sessions no longer
      // present at the source, including the valid empty-source case.
      for (const indexedId of this.index.listSessionIds()) {
        if (sourceIds.has(indexedId)) continue
        try {
          this.index.removeSession(indexedId)
        } catch (error) {
          consistent = false
          console.warn(
            `[memory-search] 删除孤儿会话 ${indexedId} 失败: ${error instanceof Error ? error.message : String(error)}`,
          )
        }
      }
      for (const id of ids) this.disposedSessions.delete(id)
      if (ids.length === 0) return consistent
      this.rebuildProgress = { current: 0, total: ids.length }
      console.log(
        `[memory-search] 开始全量索引: ${ids.length} 个会话（来源 ${sessions.length}，子代理跳过 ${subagentIds.length}），并发 ${reindexConcurrency()}` +
          '（平台读取路径实测 109 会话/49,595 文档串行 288s，并行+断点续建后分钟级）',
      )
      const built = await this.buildSessions(ids)
      const status = this.index.status()
      console.log(
        `[memory-search] 全量索引${built && consistent ? '完成' : '部分完成'}: ` +
          `${status.indexedDocs} 条文档 / ${status.indexedSessions} 个会话`,
      )
      if (!this.closed) {
        try {
          this.index.optimize()
        } catch (error) {
          console.warn(
            `[memory-search] 索引瘦身失败: ${error instanceof Error ? error.message : String(error)}`,
          )
        }
      }
      return built && consistent
    } finally {
      this.rebuildProgress = null
      this.rebuildingAll = false
    }
  }

  // -------------------------------------------------------------------------
  // 增量：session/event → debounce 批量 upsert；压缩/裁剪替换 → dirty=1 + 重建
  // -------------------------------------------------------------------------
  private onSessionEvent(sessionId: string, event: SessionEvent): void {
    // 真子代理不入索引。fork 会话虽有 parentSession，仍走增量写入。
    if (this.subagentSessions.has(sessionId)) return
    // 表面替换事件：① 压缩检查点（user/message+source.plugin='compact'）；
    // ② tool-result 裁剪（compaction/prune + 随后的替换 tool/result）。
    // 两者都会把旧节点置为 shadowed，必须整会话重建刷新 surface 分类。
    if (requiresSurfaceRebuild(event)) {
      // 丢掉压缩前的 pending，避免重建提交后再按 current 写回被 shadow 的旧事件。
      this.pendingEvents.delete(sessionId)
      this.disposedSessions.delete(sessionId)
      this.index.markSessionDirty(sessionId)
      this.dirtySessions.add(sessionId)
      this.runBackground(`rebuildSession(${sessionId})`, () => this.rebuildSession(sessionId))
      return
    }
    this.disposedSessions.delete(sessionId)
    if (!Number.isSafeInteger(event.seq) || event.seq! < 0) return
    const seq = event.seq!
    let bucket = this.pendingEvents.get(sessionId)
    if (bucket === undefined) {
      bucket = { records: [], maxSeq: seq, textChars: 0 }
      this.pendingEvents.set(sessionId, bucket)
    } else {
      bucket.maxSeq = Math.max(bucket.maxSeq, seq)
    }
    const text = extractSessionEventText(event)
    if (text.length > 0) {
      const boundedText = boundIndexText(text, event.type)
      bucket.records.push({
        sessionId,
        seq,
        type: event.type,
        time: typeof event.time === 'number' && Number.isFinite(event.time) ? event.time : Date.now(),
        surface: 'current',
        text: boundedText.text,
        textTruncated: boundedText.truncated,
        anchorKey: anchorKeyFor(event),
      })
      bucket.textChars += boundedText.text.length
    }
    if (
      bucket.records.length > MAX_PENDING_RECORDS_PER_SESSION ||
      bucket.textChars > MAX_PENDING_TEXT_CHARS_PER_SESSION
    ) {
      this.pendingEvents.delete(sessionId)
      this.index.markSessionDirty(sessionId)
      this.dirtySessions.add(sessionId)
      this.runBackground(`rebuildSession(${sessionId})`, () => this.rebuildSession(sessionId))
      return
    }
    if (this.flushTimer === null) {
      this.flushTimer = setTimeout(() => {
        this.flushTimer = null
        this.runBackground('flush pending', () => this.flushPending())
      }, DEBOUNCE_MS)
    }
  }

  private async flushPending(): Promise<void> {
    if (this.closed) return
    for (const [sessionId, batch] of this.pendingEvents) {
      // 重建中的会话先留在队列：deleteAll 会抹掉这期间 flush 的增量。
      if (this.rebuildingSessions.has(sessionId)) continue
      this.pendingEvents.delete(sessionId)
      try {
        if (batch.records.length > 0) await upsertRecordsCooperatively(this.index, batch.records)
        this.index.advanceSessionWatermark(sessionId, batch.maxSeq)
      } catch (error) {
        this.index.markSessionDirty(sessionId)
        this.dirtySessions.add(sessionId)
        this.runBackground(`rebuildSession(${sessionId})`, () => this.rebuildSession(sessionId))
        console.warn(
          `[memory-search] 增量写入失败(${sessionId})，已转整会话重建: ` +
            `${error instanceof Error ? error.message : String(error)}`,
        )
      }
    }
  }

  private onSessionDisposed(sessionId: string): void {
    this.disposedSessions.add(sessionId)
    this.dirtySessions.delete(sessionId)
    this.pendingEvents.delete(sessionId)
    this.titleBySession.delete(sessionId)
    this.parentBySession.delete(sessionId)
    this.subagentSessions.delete(sessionId)
    try {
      this.index.removeSession(sessionId)
    } catch {
      /* 幂等 */
    }
  }

  // -------------------------------------------------------------------------
  // 标题升级：upgradeTitlesWith（H1 修复；失败回退 id 前 8 位）。
  // 用户验收反馈：子代理会话（AgentTeams 成员等）通常无自身标题 → 显示 "session-xxxx"
  // 无意义。改为：子代理标题 = 「父会话标题 › 子标题/子 id 前 8 位」。
  // 搜索热路径禁止 listSessions：114 个会话全量列举可达十几秒，比 FTS 本身贵两个数量级。
  // -------------------------------------------------------------------------
  private ingestSessionGraph(sessions: SessionListRecord[]): void {
    for (const rec of sessions) {
      const id = rec?.header?.id
      if (typeof id !== 'string' || id.length === 0) continue
      const parent = rec?.header?.parentSession
      if (typeof parent === 'string' && parent.length > 0) this.parentBySession.set(id, parent)
      else this.parentBySession.delete(id)
      if (isSubagentSession(rec)) this.subagentSessions.add(id)
      else this.subagentSessions.delete(id)
    }
    this.sessionGraphAt = Date.now()
  }

  private refreshSessionGraph(): void {
    if (this.sessionGraphInflight !== null) return
    if (Date.now() - this.sessionGraphAt < SESSION_GRAPH_TTL_MS) return
    const sessionQuery = this.queryService()
    if (sessionQuery === undefined) return
    this.sessionGraphInflight = this.loadSessionGraph(sessionQuery).finally(() => {
      this.sessionGraphInflight = null
    })
    this.runBackground('session graph', () => this.sessionGraphInflight ?? Promise.resolve())
  }

  private async loadSessionGraph(sessionQuery: SessionQueryLike): Promise<void> {
    let timer: ReturnType<typeof setTimeout> | undefined
    try {
      const sessions = await Promise.race([
        sessionQuery.listSessions(),
        new Promise<null>((resolve) => {
          timer = setTimeout(() => resolve(null), SESSION_GRAPH_TIMEOUT_MS)
        }),
      ])
      if (Array.isArray(sessions)) {
        this.ingestSessionGraph(sessions as SessionListRecord[])
      }
    } catch {
      /* 父图失败不致命 */
    } finally {
      if (timer !== undefined) clearTimeout(timer)
    }
  }

  private rememberTitles(hits: SearchHit[]): void {
    for (const hit of hits) {
      const fallback = hit.sessionId.slice(0, 8)
      if (hit.sessionTitle.length > 0 && hit.sessionTitle !== fallback) {
        this.titleBySession.set(hit.sessionId, hit.sessionTitle)
      }
    }
  }

  private applyCachedSessionTitles(hits: SearchHit[]): void {
    for (const hit of hits) {
      const cached = this.titleBySession.get(hit.sessionId)
      if (cached !== undefined) hit.sessionTitle = cached
    }
  }

  private async upgradeTitles(hits: SearchHit[]): Promise<void> {
    const sessionQuery = this.queryService()
    if (sessionQuery === undefined || typeof sessionQuery.readTitleSnapshots !== 'function') return
    this.applyCachedSessionTitles(hits)
    applyParentTitles(hits, this.parentBySession, this.titleBySession)

    const missing = new Set<string>()
    for (const hit of hits) {
      if (!this.titleBySession.has(hit.sessionId)) missing.add(hit.sessionId)
      const parent = this.parentBySession.get(hit.sessionId)
      if (parent !== undefined && !this.titleBySession.has(parent)) missing.add(parent)
    }
    if (missing.size > 0) {
      const read = async (ids: string[]): Promise<unknown[]> =>
        (await sessionQuery.readTitleSnapshots(ids)) as unknown[]
      const probes = titleProbeHits(missing)
      await upgradeTitlesWith(probes, read)
      this.rememberTitles(probes)
      this.applyCachedSessionTitles(hits)
      applyParentTitles(hits, this.parentBySession, this.titleBySession)
      this.rememberTitles(hits)
    }
    this.refreshSessionGraph()
  }

  // -------------------------------------------------------------------------
  // H2 reconcile：① 新会话补索引 ② max_seq 缺口 readFrom(max_seq+1) 补齐 ③ 孤儿删除
  // -------------------------------------------------------------------------
  private async reconcile(): Promise<boolean> {
    if (this.reconciling || this.rebuildingAll) return this.started
    this.reconciling = true
    try {
      const sessionQuery = this.queryService()
      const persistence = this.persistenceService()
      if (sessionQuery === undefined || persistence === undefined || this.closed) return false
      let source: SessionListRecord[] = []
      try {
        const result = await sessionQuery.listSessions()
        if (!Array.isArray(result)) return false
        source = result
        this.ingestSessionGraph(source)
      } catch {
        return false
      }
      // 真子代理排除；fork 会话（有 parent、origin 不是 subagent）保留。
      const partitioned = partitionListedSessions(source)
      const subagentIds = new Set(partitioned.subagentIds)
      const sourceIds = new Set(partitioned.indexableIds)
      let complete = true

      // ③ 孤儿删除：DB 有而源列表无（含本轮被排除的子代理会话）
      for (const indexedId of this.index.listSessionIds()) {
        if (!sourceIds.has(indexedId)) {
          if (subagentIds.has(indexedId)) {
            try {
              this.index.removeSession(indexedId)
            } catch {
              complete = false
            }
            continue
          }
          try {
            this.index.removeSession(indexedId)
          } catch {
            complete = false
          }
        }
      }

      // 断点续建主路径（① + dirty）：未索引（无 state 行）与 dirty（压缩/裁剪替换）
      // 会话并发池整会话重建——不受 RECONCILE_BATCH 限制（那是稳态增量巡检的
      // 每周期配额）；中断/重启后剩余会话在此继续，已建会话不重读。
      const needsBuild: string[] = []
      const remaining: string[] = []
      for (const sessionId of sourceIds) {
        const row = this.index.sessionState(sessionId)
        if (row === undefined || row.dirty === 1) needsBuild.push(sessionId)
        else remaining.push(sessionId)
      }
      if (needsBuild.length > 0) {
        console.log(`[memory-search] 续建 ${needsBuild.length} 个会话（并发 ${reindexConcurrency()}）`)
        if (!(await this.buildSessions(needsBuild))) complete = false
      }

      // ② max_seq 缺口补齐（L4：readFrom(max_seq+1)；每周期上限 RECONCILE_BATCH，串行廉价后缀读）
      let scanned = 0
      for (const sessionId of remaining) {
        if (this.closed) return false
        if (scanned >= RECONCILE_BATCH) break
        scanned++
        const row = this.index.sessionState(sessionId)
        if (row === undefined) continue
        let events: SessionEvent[] = []
        try {
          const result = await persistence.readFrom(sessionId, row.maxSeq + 1)
          if (!Array.isArray(result?.events)) {
            complete = false
            continue
          }
          events = result.events
        } catch {
          complete = false
          continue
        }
        if (events.length > 0) {
          if (events.some((event) => requiresSurfaceRebuild(event))) {
            this.retainDirty(sessionId)
            if (!(await this.rebuildSession(sessionId))) complete = false
            continue
          }
          const records: IndexRecord[] = []
          let maxRawSeq = row.maxSeq
          for (const event of events) {
            if (event === null || typeof event !== 'object') continue
            if (!Number.isSafeInteger(event.seq) || event.seq! < 0) continue
            maxRawSeq = Math.max(maxRawSeq, event.seq!)
            const text = extractSessionEventText(event)
            if (text.length === 0) continue
            records.push({
              sessionId,
              seq: event.seq!,
              type: event.type,
              time: typeof event.time === 'number' && Number.isFinite(event.time) ? event.time : Date.now(),
              surface: 'current',
              text,
              anchorKey: anchorKeyFor(event),
            })
          }
          let writeSucceeded = true
          if (records.length > 0) {
            try {
              await upsertRecordsCooperatively(this.index, records)
            } catch {
              writeSucceeded = false
              complete = false
              /* 下一周期重试 */
            }
          }
          if (writeSucceeded) {
            try {
              this.index.advanceSessionWatermark(sessionId, maxRawSeq)
            } catch {
              complete = false
              /* 下一周期重试 */
            }
          }
        }
      }
      return complete
    } finally {
      this.reconciling = false
    }
  }

  // -------------------------------------------------------------------------
  // @Remote 方法（纯 JSON 往返；wire 命名 'memory-search/*' → 客户端 remote.memorySearch）
  // -------------------------------------------------------------------------
  async search(request: unknown): Promise<unknown> {
    const payload = (request ?? {}) as { query?: unknown; limit?: unknown; role?: unknown }
    const query = typeof payload.query === 'string' ? payload.query : ''
    const role = parseSearchRole(payload.role)
    const limit =
      typeof payload.limit === 'number' && Number.isFinite(payload.limit) && payload.limit > 0
        ? Math.min(Math.floor(payload.limit), MAX_SEARCH_LIMIT)
        : DEFAULT_SEARCH_LIMIT
    try {
      if (query.length > MAX_QUERY_CHARS) {
        return {
          ok: false,
          error: { code: 'E_QUERY_TOO_LONG', message: `搜索词不能超过 ${MAX_QUERY_CHARS} 个字符` },
          hits: [],
          truncated: false,
          partial: this.building || this.rebuildingAll,
        }
      }
      if (!this.servicesReady()) {
        return {
          ok: false,
          error: { code: 'E_NOT_READY', message: '会话查询服务不可用' },
          hits: [],
          truncated: false,
          partial: false,
        }
      }
      const result = this.index.search(query, { limit, role })
      if (result.ok && result.hits.length > 0) {
        await this.upgradeTitles(result.hits)
      }
      return { ...result, partial: this.building || this.rebuildingAll }
    } catch (error) {
      return {
        ok: false,
        error: {
          code: 'E_INTERNAL',
          message: error instanceof Error ? error.message : String(error),
        },
        hits: [],
        truncated: false,
        partial: false,
      }
    }
  }

  async status(): Promise<unknown> {
    try {
      const status = this.index.status()
      return {
        ok: true,
        ready: this.servicesReady(),
        indexedSessions: status.indexedSessions,
        indexedDocs: status.indexedDocs,
        building: this.building || this.rebuildingAll || status.building,
        degraded: status.degraded,
        storageBytes: status.storageBytes ?? null,
        storageLimitBytes: status.storageLimitBytes ?? null,
        prunedDocs: status.prunedDocs ?? 0,
        coverageSince: status.coverageSince ?? null,
        rebuildCurrent: this.rebuildProgress?.current ?? null,
        rebuildTotal: this.rebuildProgress?.total ?? null,
        dbPath: this.dbPath,
        defaultDbPath: defaultIndexDbPath(),
      }
    } catch (error) {
      return {
        ok: false,
        error: {
          code: 'E_INTERNAL',
          message: error instanceof Error ? error.message : String(error),
        },
      }
    }
  }

  async reindex(): Promise<unknown> {
    try {
      if (this.building || this.rebuildingAll) return { ok: true, started: false }
      if (!this.servicesReady()) {
        return {
          ok: false,
          error: { code: 'E_NOT_READY', message: '会话查询服务不可用' },
        }
      }
      this.rebuildingAll = true
      this.runBackground('manual reindex', () => this.rebuildAll({ alreadyClaimed: true }))
      return { ok: true, started: true }
    } catch (error) {
      return {
        ok: false,
        error: {
          code: 'E_INTERNAL',
          message: error instanceof Error ? error.message : String(error),
        },
      }
    }
  }

  async setDbPath(request: unknown): Promise<unknown> {
    try {
      if (this.closed) {
        return { ok: false, error: { code: 'E_NOT_READY', message: '索引服务已关闭' } }
      }
      if (this.building || this.rebuildingAll || this.starting || this.reconciling) {
        return { ok: false, error: { code: 'E_BUSY', message: '索引正在构建，请稍后再改路径' } }
      }
      const raw = request !== null && typeof request === 'object'
        ? (request as { path?: unknown }).path
        : request
      if (typeof raw !== 'string') {
        return { ok: false, error: { code: 'E_INVALID', message: '请提供路径' } }
      }
      const normalized = normalizeUserDbPath(raw)
      if (!normalized.ok) {
        return { ok: false, error: { code: 'E_INVALID', message: normalized.error } }
      }
      if (normalized.path === this.dbPath) {
        return { ok: true, dbPath: this.dbPath, started: false, unchanged: true, moved: false }
      }
      const prepared = ensureIndexDbDirectory(normalized.path)
      if (!prepared.ok) {
        return { ok: false, error: { code: 'E_IO', message: `无法创建目录: ${prepared.error}` } }
      }
      const previousPath = this.dbPath
      const previousIndex = this.index
      const wasDegraded = previousIndex.degraded
      let previousDocs = 0
      let previousSessions = 0
      try {
        const previousStatus = previousIndex.status()
        previousDocs = previousStatus.indexedDocs
        previousSessions = previousStatus.indexedSessions
      } catch {
        /* closed or degraded: treat as empty for the live-file check */
      }
      if (this.flushTimer !== null) {
        clearTimeout(this.flushTimer)
        this.flushTimer = null
      }
      this.pendingEvents.clear()
      try {
        previousIndex.optimize()
      } catch {
        /* checkpoint is best-effort before the file is copied */
      }
      try {
        previousIndex.close()
      } catch {
        /* 已关闭 */
      }

      const copied = copyIndexDatabase(previousPath, normalized.path)
      if (!copied.ok) {
        this.index = createSearchIndex({ dbPath: previousPath })
        this.started = false
        this.starting = false
        this.runBackground('startup after failed db copy', () => this.startup())
        return { ok: false, error: { code: 'E_IO', message: `无法复制索引: ${copied.error}` } }
      }

      const next = createSearchIndex({ dbPath: normalized.path })
      const nextStatus = next.status()
      const destMissing = !wasDegraded && previousDocs > 0 && !next.degraded
        ? nextStatus.indexedDocs !== previousDocs || nextStatus.indexedSessions !== previousSessions
        : false
      if ((next.degraded && !wasDegraded) || destMissing) {
        try {
          next.close()
        } catch {
          /* ignore */
        }
        this.index = createSearchIndex({ dbPath: previousPath })
        this.started = false
        this.starting = false
        this.runBackground('startup after failed db move', () => this.startup())
        return {
          ok: false,
          error: {
            code: 'E_IO',
            message: destMissing
              ? '新路径的索引文件无法使用（文档数不一致），已保持原位置'
              : '无法在该路径打开索引，已保持原位置',
          },
        }
      }

      try {
        writePersistedDbPath(normalized.path)
      } catch (error) {
        try {
          next.close()
        } catch {
          /* ignore */
        }
        this.index = createSearchIndex({ dbPath: previousPath })
        this.started = false
        this.starting = false
        this.runBackground('startup after failed db persist', () => this.startup())
        return {
          ok: false,
          error: {
            code: 'E_IO',
            message: error instanceof Error ? error.message : String(error),
          },
        }
      }

      if (!sameIndexPath(resolveIndexDbPath(), normalized.path)
        || (!wasDegraded && previousDocs > 0 && !indexDatabaseFileExists(normalized.path))) {
        try {
          writePersistedDbPath(previousPath)
        } catch {
          /* keep trying to restore the previous pointer */
        }
        try {
          next.close()
        } catch {
          /* ignore */
        }
        this.index = createSearchIndex({ dbPath: previousPath })
        this.started = false
        this.starting = false
        this.runBackground('startup after db path resolve mismatch', () => this.startup())
        return { ok: false, error: { code: 'E_IO', message: '新路径写入后无法解析到该位置，已保持原文件' } }
      }

      let moved = false
      if (!sameIndexPath(previousPath, normalized.path)) {
        moved = copied.copied
        const leftovers = removeIndexDatabaseFiles(previousPath)
        if (leftovers.length > 0) {
          console.warn(`[memory-search] 索引已可用，但旧文件删除未完成: ${leftovers.join(', ')}`)
        }
      }

      this.dbPath = normalized.path
      this.index = next
      this.started = false
      this.starting = false
      this.runBackground('startup after db path change', () => this.startup())
      return { ok: true, dbPath: this.dbPath, started: true, unchanged: false, moved }
    } catch (error) {
      return {
        ok: false,
        error: {
          code: 'E_INTERNAL',
          message: error instanceof Error ? error.message : String(error),
        },
      }
    }
  }
}

/**
 * tsdown/rolldown 不转换 TS 装饰器（产物含裸 @Remote 语法，Node 无法解析）。
 * 按标准装饰器协议手动应用：Remote("x") 返回 (method, context) 装饰器，
 * 其 addInitializer 在构造时把 method 标记进 typert markers 表。
 * 用探针实例执行 initializer（getPrototypeOf(probe) === 类原型 → mark 落到共享原型表）。
 */
type AnyMethod = (this: object, ...args: any[]) => any
type RemoteMethodDecorator = (method: AnyMethod | undefined, context: ClassMethodDecoratorContext<object, AnyMethod>) => void

function applyRemoteMark(exportName: string, methodName: string): void {
  const decorator = Remote(exportName) as unknown as RemoteMethodDecorator
  const initializers: Array<() => void> = []
  const context = {
    kind: 'method',
    name: methodName,
    static: false,
    private: false,
    addInitializer(fn: () => void) {
      initializers.push(fn)
    },
  } as unknown as ClassMethodDecoratorContext<object, AnyMethod>
  decorator(undefined, context)
  const probe = Object.create(MemorySearchRemoteService.prototype)
  for (const init of initializers) init.call(probe)
}

applyRemoteMark('search', 'search')
applyRemoteMark('status', 'status')
applyRemoteMark('reindex', 'reindex')
applyRemoteMark('setDbPath', 'setDbPath')

export function apply(ctx: Context, config: PluginConfig = {}): void {
  // Service 构造即完成 fiber-scope 注册（卸载时自动移除）；@Remote 方法经
  // Typert Gateway 暴露为客户端 ctx.remote.memorySearch.* 调用。
  new MemorySearchRemoteService(ctx, config)
}
