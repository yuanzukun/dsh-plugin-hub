/**
 * search — 二段式搜索的纯函数原语（spans/snippet）+ 命中组装配角。
 *
 * QA 契约（tests/README.md）：
 *  - computeSpans(text, query)：大小写不敏感、字符偏移、非重叠贪婪；
 *    多词 query 按空白分词后逐词定位再合并（与阶段 2 逐词校验一致）
 *  - buildSnippet(text, spans, radius=120)：以首 span ±120 为中心（延展覆盖
 *    尾 span）切窗口；返回值 spans 相对 snippet、start 为 snippet 在 text 中的偏移
 *  - 命中层 spans / snippet 语义：SearchHit.spans 相对 text（精确定位），
 *    片段由 buildSnippet 生成（ADR-6 两层语义）
 */

import type { SearchHit, SearchRoleFilter } from './types.ts'
import { MAX_TEXT, SNIPPET_RADIUS } from './types.ts'

/**
 * 排序 + 重叠合并（契约 §5.2/ADR-4：`next.start < prev.end` 才合并，相邻不合并）。
 * 内部使用；客户端另有等价实现。
 */
export function mergeRanges(ranges: Array<[number, number]>): Array<[number, number]> {
  if (ranges.length === 0) return []
  const sorted = ranges
    .map(([start, end]): [number, number] => (start <= end ? [start, end] : [end, start]))
    .sort((a, b) => a[0] - b[0] || a[1] - b[1])
  const merged: Array<[number, number]> = []
  for (const [start, end] of sorted) {
    const last = merged[merged.length - 1]
    // 仅重叠合并（start < prev.end）；相邻（start === prev.end）保持独立
    if (last !== undefined && start < last[1]) {
      last[1] = Math.max(last[1], end)
    } else {
      merged.push([start, end])
    }
  }
  return merged
}

/** 单个 needle 在 haystack 中的全部出现：大小写不敏感、字符偏移、非重叠贪婪。 */
function greedySpans(haystack: string, needle: string): Array<[number, number]> {
  const out: Array<[number, number]> = []
  if (needle.length === 0) return out
  let from = 0
  for (;;) {
    const idx = haystack.indexOf(needle, from)
    if (idx < 0) break
    out.push([idx, idx + needle.length])
    from = idx + needle.length // 非重叠贪婪
  }
  return out
}

/** Display-oriented fallback terms. Unlike whitespace splitting, this treats
 * punctuation as a separator, matching the tokenizer/FTS behavior for input
 * such as `search, chat`. A CJK run stays intact so highlights remain useful
 * phrases rather than a pile of overlapping single-character ranges. */
export function literalSearchTerms(query: string): string[] {
  return [...query.toLowerCase().matchAll(/[\p{L}\p{N}]+/gu)]
    .map((match) => match[0])
    .filter((term) => term.length > 0)
}

/**
 * 计算 query 在 text 中的全部出现（契约 §5.2 步骤 3 / ADR-4）：
 *  - V-primary：先做整串（trim 后）连续子串定位（短语/单关键词，大小写不敏感、
 *    字符偏移、非重叠贪婪）；
 *  - V-fallback：整串无命中且多 token（词间空白导致不连续）时，逐 token 定位，
 *    全部区间按 start 排序后仅合并重叠区间（相邻不合并）。
 * 返回排序后的 [start, end) 字符偏移。
 */
export function computeSpans(text: string, query: string): Array<[number, number]> {
  const lower = text.toLowerCase()
  const q = query.trim()
  if (q.length === 0) return []
  const primary = greedySpans(lower, q.toLowerCase())
  if (primary.length > 0) return primary
  const tokens = literalSearchTerms(q)
  if (tokens.length === 0) return []
  const out: Array<[number, number]> = []
  for (const token of tokens) {
    for (const span of greedySpans(lower, token)) out.push(span)
  }
  return mergeRanges(out)
}

/**
 * 构造 snippet 窗口：以首个 span ±radius 为中心，延展覆盖最后一个 span；
 * 返回 { snippet, spans: 相对 snippet, start: snippet 在 text 中的偏移 }。
 */
export function buildSnippet(
  text: string,
  spans: ReadonlyArray<readonly [number, number]>,
  radius: number = SNIPPET_RADIUS,
): { snippet: string; spans: Array<[number, number]>; start: number } {
  const first = spans[0]
  if (spans.length === 0 || first === undefined) {
    return { snippet: text.slice(0, 2 * radius), spans: [], start: 0 }
  }
  const last = spans[spans.length - 1]!
  const start = Math.max(0, first[0] - radius)
  // QA 裁定：窗口中心锚定首个匹配的结束位置（end = max(firstEnd+radius, lastEnd)）
  const end = Math.min(text.length, Math.max(first[1] + radius, last[1]))
  const snippet = text.slice(start, end)
  const shifted: Array<[number, number]> = []
  for (const [s, e] of spans) {
    const rs = Math.max(0, s - start)
    const re = Math.min(snippet.length, e - start)
    if (re > rs) shifted.push([rs, re])
  }
  return { snippet, spans: shifted, start }
}

/** 事件类型 → 命中 role（客户端另有展示级映射）。 */
export function hitRoleOf(type: string): string {
  if (type === 'user/message') return 'user'
  if (type === 'assistant/message') return 'assistant'
  if (type === 'tool/call' || type === 'tool/result') return 'tool'
  return 'other'
}

/** Coerce an RPC/option value; unknown → `all` (do not fail the query). */
export function parseSearchRole(raw: unknown): SearchRoleFilter {
  return raw === 'user' || raw === 'assistant' || raw === 'tool' || raw === 'all' ? raw : 'all'
}

/** Event types included in a speaker filter; `null` means no type constraint. */
export function typesForRole(role: SearchRoleFilter): readonly string[] | null {
  switch (role) {
    case 'user':
      return ['user/message']
    case 'assistant':
      return ['assistant/message']
    case 'tool':
      return ['tool/call', 'tool/result']
    default:
      return null
  }
}

export function typeMatchesRole(type: string, role: SearchRoleFilter): boolean {
  const types = typesForRole(role)
  return types === null || types.includes(type)
}

/**
 * 从一条索引记录组装命中（阶段 2 结果）：text 截断 ≤8192、spans 为 text
 * 相对偏移、snippet 由 buildSnippet 生成、matchCount = 合并后 span 数。
 */
export function composeHit(
  record: {
    sessionId: string
    seq: number
    type: string
    time: number
    anchorKey: string | null
    text: string
    textTruncated?: boolean
  },
  query: string,
): SearchHit {
  const text = record.text.length > MAX_TEXT ? record.text.slice(0, MAX_TEXT) : record.text
  const spans = computeSpans(text, query)
  return {
    sessionId: record.sessionId,
    sessionTitle: record.sessionId.slice(0, 8),
    seq: record.seq,
    type: record.type,
    role: hitRoleOf(record.type),
    time: record.time,
    anchorKey: record.anchorKey,
    text,
    snippet: buildSnippet(text, spans).snippet,
    spans,
    matchCount: spans.length,
    textTruncated: record.textTruncated === true,
  }
}
