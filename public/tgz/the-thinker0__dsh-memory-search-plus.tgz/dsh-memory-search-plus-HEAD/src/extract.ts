/**
 * extract — 事件文本抽取与锚点键。
 *
 * 索引范围（ADR-12，用户验收裁定）：索引会话可见正文与工具文字——
 *  - user/message → contentText(data.content)
 *  - assistant/message → contentText(data.message.content)
 *  - tool/call、tool/result → 有界工具预览；todo、turn 统计等跳过。
 * 锚点键公式（消息级定位，与 dsh-client-ui-conversation chat projection 的
 * conversationContextKey(kind,id)=`${kind.length}:${kind}${id}` 一致）：
 *  - user/message → "13:input-message"+id
 *  - assistant/message → "14:assistant-step"+turn+":"+step
 *  - 其余 → null。
 * joinText = trim → filter(Boolean) → join("\n")。
 */

import { boundIndexText } from './index-text.ts'
import { type IndexRecord, type SessionEvent, type Surface } from './types.ts'

/** trim → filter 空 → join("\n")。 */
export function joinText(parts: readonly string[]): string {
  const out: string[] = []
  for (const part of parts) {
    const trimmed = part.trim()
    if (trimmed.length > 0) out.push(trimmed)
  }
  return out.join('\n')
}

/** content 块 → 文本：text→text；reasoning→跳过；tool-call→[name, arguments]；
 * tool-result→content 递归；其余/非对象→跳过。 */
export function contentText(content: unknown): string {
  if (!Array.isArray(content)) return ''
  const parts: string[] = []
  for (const raw of content) {
    if (raw === null || typeof raw !== 'object') continue
    const block = raw as Record<string, unknown>
    switch (block.type) {
      case 'text':
        if (typeof block.text === 'string') parts.push(block.text)
        break
      case 'reasoning':
        break
      case 'tool-call':
        parts.push(typeof block.name === 'string' ? block.name : '')
        parts.push(typeof block.arguments === 'string' ? block.arguments : '')
        break
      case 'tool-result':
        parts.push(contentText(block.content))
        break
      default:
        break
    }
  }
  return joinText(parts)
}

/** 真人发言判定（用户验收实测裁定）：`user/message` 且 `source.kind === 'user'`
 * 严格相等。实测注入消息的 source 形状（全部排除）：
 *  - {kind:'subagent-settled', form:'notice'}  子代理完成通知
 *  - {kind:'plugin', plugin:'dsh-agent-teams'} 团队消息
 *  - {kind:'plugin', plugin:'@deepseek-ai/dsh-system-prompt'} 系统上下文快照
 *  - {kind:'skill-catalog'} / {kind:'plugin', plugin:'user-approval'} 等
 * 缺 source 的旧日志按真人发言处理（防御）。 */
export function isHumanUserMessage(event: SessionEvent): boolean {
  if (event.type !== 'user/message') return false
  const source = event.data?.source
  if (source === null || source === undefined || typeof source !== 'object') return true
  return (source as { kind?: unknown }).kind === 'user'
}

/** 单事件文本抽取。返回 "" 表示该事件应跳过索引。
 *
 * 索引范围（ADR-12 按用户验收两轮修订）：会话可见正文 + 工具文字——
 *  - user/message 且 source.kind==='user'（人发给 Agent 的可见文字；含 steering）
 *  - assistant/message（Agent 最终展示的可见文字，含正文中的代码块/Markdown/报错）
 *  - tool/call（工具名 + 参数）、tool/result（输出 + 错误名/码）——用户裁定纳入
 *    （筛选标签「工具」，命中行黄色左标）
 *  - 注入上下文、todo、turn 统计等**不进入索引**。 */
export function extractSessionEventText(event: SessionEvent): string {
  const data = event.data as Record<string, unknown> | null | undefined
  switch (event.type) {
    case 'user/message':
      if (!isHumanUserMessage(event)) return ''
      return contentText(data?.content)
    case 'assistant/message':
      return contentText((data?.message as Record<string, unknown> | undefined)?.content)
    case 'tool/call':
      return joinText([
        typeof data?.name === 'string' ? data.name : '',
        typeof data?.arguments === 'string' ? data.arguments : '',
      ])
    case 'tool/result': {
      const error = data?.error as Record<string, unknown> | undefined
      return joinText([
        contentText((data?.message as Record<string, unknown> | undefined)?.content),
        typeof error?.name === 'string' ? error.name : '',
        typeof error?.code === 'string' ? error.code : '',
      ])
    }
    default:
      return ''
  }
}

/** 锚点键公式（消息级定位）：
 *  user/message → "13:input-message"+id
 *  assistant/message → "14:assistant-step"+turn+":"+step
 *  tool/call → "9:tool-call"+callId
 *  tool/result → "9:tool-call"+message.source.callId
 *  其余 → null（可索引不可定位）。
 *  L3：id/turn/step/callId/source.callId 缺失时返回 null（不生成 '...undefined' 伪锚点）。 */
export function anchorKeyFor(event: SessionEvent): string | null {
  const data = event.data as Record<string, unknown> | null | undefined
  switch (event.type) {
    case 'user/message':
      return data?.id === undefined || data?.id === null
        ? null
        : '13:input-message' + String(data.id)
    case 'assistant/message': {
      const turn = data?.turn
      const step = data?.step
      if (turn === undefined || turn === null || step === undefined || step === null) return null
      return '14:assistant-step' + String(turn) + ':' + String(step)
    }
    case 'tool/call':
      return data?.callId === undefined || data?.callId === null
        ? null
        : '9:tool-call' + String(data.callId)
    case 'tool/result': {
      const message = data?.message as Record<string, unknown> | undefined
      const source = message?.source as Record<string, unknown> | undefined
      const callId = source?.callId
      return callId === undefined || callId === null ? null : '9:tool-call' + String(callId)
    }
    default:
      return null
  }
}

/**
 * Local equivalent of dsh `foldSurface` for a raw session log:
 * `surfaceOp.replace` / `sourceEventSeqs` mark the old range shadowed;
 * `tool/call` stays log-only (even inside a replaced range); everything
 * else is current. Lets rebuild skip the second `filterEvents` persistence
 * read, which serializes on the same session id.
 */
export function foldRawEventSurfaces(events: readonly SessionEvent[]): Map<number, Surface> {
  let maxSeq = -1
  for (const event of events) {
    if (event !== null && typeof event === 'object' && Number.isSafeInteger(event.seq)) {
      maxSeq = Math.max(maxSeq, event.seq!)
    }
  }
  const ranges: Array<[number, number]> = []
  const replaced = new Set<number>()
  for (const event of events) {
    if (event === null || typeof event !== 'object') continue
    const op = event.surfaceOp
    if (op !== null && typeof op === 'object') {
      const rec = op as { op?: unknown; start?: unknown; end?: unknown }
      if (
        rec.op === 'replace' &&
        Number.isSafeInteger(rec.start) &&
        Number.isSafeInteger(rec.end)
      ) {
        const lo = Math.min(rec.start as number, rec.end as number)
        const hi = Math.max(rec.start as number, rec.end as number)
        // start/end are event seqs. Never iterate lo..hi — a timestamp-like
        // span would lock the event loop for minutes.
        if (lo >= 0 && hi <= maxSeq) ranges.push([lo, hi])
      }
    }
    const seqs = event.sourceEventSeqs
    if (Array.isArray(seqs)) {
      for (const seq of seqs) {
        if (typeof seq === 'number' && Number.isSafeInteger(seq)) replaced.add(seq)
      }
    }
  }
  const inReplacedRange = (seq: number): boolean => {
    if (replaced.has(seq)) return true
    for (const [lo, hi] of ranges) {
      if (seq >= lo && seq <= hi) return true
    }
    return false
  }
  const surfaces = new Map<number, Surface>()
  for (const event of events) {
    if (event === null || typeof event !== 'object') continue
    if (!Number.isSafeInteger(event.seq) || event.seq! < 0) continue
    const seq = event.seq!
    if (event.type === 'tool/call') {
      surfaces.set(seq, 'log-only')
      continue
    }
    surfaces.set(seq, inReplacedRange(seq) ? 'shadowed' : 'current')
  }
  return surfaces
}

/**
 * Build index rows from a raw event log (readFrom / readSession).
 * Used by the fast rebuild path so we do not also call filterEvents —
 * those two persistence reads serialize on the same session id.
 * Surfaces are folded from the log unless an explicit override is passed
 * (incremental live events are always `current`).
 */
export function buildIndexRecordsFromEvents(
  sessionId: string,
  events: readonly SessionEvent[],
  surface?: Surface,
): IndexRecord[] {
  const folded = surface === undefined ? foldRawEventSurfaces(events) : null
  const records: IndexRecord[] = []
  for (const event of events) {
    if (event === null || typeof event !== 'object') continue
    if (!Number.isSafeInteger(event.seq) || event.seq! < 0) continue
    const eventSurface = folded?.get(event.seq!) ?? surface ?? 'current'
    // Shadowed rows are dropped on rebuild anyway; extracting their (often
    // huge) tool/assistant payloads is what made compacted-session rebuilds
    // slower than the old filterEvents path.
    if (eventSurface === 'shadowed') continue
    const text = extractSessionEventText(event)
    if (text.length === 0) continue
    const bounded = boundIndexText(text, event.type)
    records.push({
      sessionId,
      seq: event.seq!,
      type: event.type,
      time: typeof event.time === 'number' && Number.isFinite(event.time) ? event.time : Date.now(),
      surface: eventSurface,
      text: bounded.text,
      textTruncated: bounded.truncated,
      anchorKey: anchorKeyFor(event),
    })
  }
  return records
}
