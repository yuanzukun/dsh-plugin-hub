/**
 * dsh-memory-search-plus — web client half.
 *
 * Local, cross-session full-text search over chat history:
 *  - `sidebar.footer.action` (order 0): the "查找聊天记录" search pill; it
 *    physically relocates under the workspace region when the sidebar is
 *    wide (see pill.tsx for the mechanism).
 *  - `shell.overlay`: the ChatGPT/VSCode-style search panel — powered by
 *    the host RPC methods `memory-search/search` / `memory-search/status`,
 *    registered with id `memory-search-overlay`; closed by default.
 *  - `settings.section`: index status, database path, and reindex action.
 *
 * Global shortcut: Ctrl/Cmd+Shift+F toggles the panel (installed through
 * ctx.effect so the plugin fiber owns it).
 *
 * The bundle is built by the packager into `lib/client.js` wrapped in
 * `window.__ModuleLoader__.load({ id, factory })`.
 */

import { ensureStyles } from './styles.ts'
import { SearchPill } from './client/pill.tsx'
import { SearchPanel } from './client/panel.tsx'
import { MEMORY_SEARCH_REMOTE } from './client/remote.ts'
import type { RemoteMemorySearch } from './client/rpc.tsx'
import { SearchSettings } from './client/settings.tsx'
import { closeOverlay, getOverlaySnapshot, toggleOverlay } from './client/store.tsx'

const NS = 'memorySearch'

const zh = {
  'pill.label': '查找聊天记录',
  'pill.fullSearch': '全文搜索聊天内容（跨会话）',
  'panel.title': '搜索聊天记录',
  'panel.placeholder': '搜索会话内容…',
  'panel.searching': '搜索中…（阶段1/2）',
  'panel.notFound': '未找到匹配',
  'panel.error': '搜索失败',
  'panel.count': '{n} 条结果',
  'panel.truncated': '结果已截断',
  'panel.matches': '{n} 处匹配',
  'panel.textTruncated': '索引预览',
  'panel.hint': '输入关键词开始搜索',
  'panel.indexing': '索引初始化中…',
  'panel.degraded': '索引降级中（内存模式，仅索引已加载会话）',
  'panel.indexError': '索引不可用',
  'panel.filter': '按角色筛选',
  'panel.close': '关闭',
  'role.all': '全部',
  'role.user': '用户',
  'role.assistant': 'Agent',
  'role.tool': '工具',
  'role.other': '其他',
  'session.untitled': '未命名会话',
  'toast.anchorMissing': '目标消息已被压缩替换，已定位到会话',
  'toast.anchorPending': '会话已打开，正在定位到目标消息',
  'panel.notLocatable': '该消息不支持精准定位',
  'toast.sessionUnavailable': '目标会话不可用',
  'settings.title': '聊天记录搜索',
  'settings.hint': '本地 SQLite FTS5 有界索引：正文采用紧凑预览，超出容量时只淘汰最旧索引，原始会话不会被删除。',
  'settings.statusReady': '已索引 {sessions} 个会话 · {messages} 条消息',
  'settings.statusSessions': '已索引 {sessions} 个会话',
  'settings.statusReadyNa': '索引就绪',
  'settings.statusFailed': '状态获取失败',
  'settings.loading': '读取索引状态…',
  'settings.rebuild': '重建索引',
  'settings.rebuilding': '重建中…',
  'settings.reindexStarted': '正在重建索引…',
  'settings.reindexDone': '索引重建完成',
  'settings.rebuildFailed': '索引重建失败',
  'settings.reindexRunning': '索引重建已在进行中',
  'settings.statusRebuildingProgress': '重建中 {current}/{total} 个会话 · {messages} 条消息',
  'settings.statusRebuildingCounts': '重建中… 已索引 {sessions} 个会话 · {messages} 条消息',
  'settings.storage': '索引磁盘 {used} MiB · 逻辑预算 {limit} MiB',
  'settings.coverageSince': '覆盖自 {date}',
  'settings.pruned': '已淘汰 {n} 条旧索引',
  'settings.dbPath': '索引存放位置',
  'settings.dbPathHint': '填写目录或 .db 文件的绝对路径。保存后会把现有索引文件搬到新位置并删除旧文件。支持 ~。',
  'settings.dbPathPlaceholder': '/path/to/memory-search/index.db',
  'settings.dbPathSave': '保存路径',
  'settings.dbPathSaving': '切换中…',
  'settings.dbPathSaved': '已将索引文件移到新位置',
  'settings.dbPathUnchanged': '已是当前路径',
  'settings.dbPathFailed': '无法保存索引路径',
  'settings.dbPathDefault': '恢复默认',
} as const

const en = {
  'pill.label': 'Search chat history',
  'pill.fullSearch': 'full-text search across all sessions',
  'panel.title': 'Search chat history',
  'panel.placeholder': 'Search session content…',
  'panel.searching': 'Searching… (phase 1/2)',
  'panel.notFound': 'No matches found',
  'panel.error': 'Search failed',
  'panel.count': '{n} results',
  'panel.truncated': 'truncated',
  'panel.matches': '{n} matches',
  'panel.textTruncated': 'index preview',
  'panel.hint': 'Type to search',
  'panel.indexing': 'Index initializing…',
  'panel.degraded': 'Index degraded (in-memory mode, loaded sessions only)',
  'panel.indexError': 'Index unavailable',
  'panel.filter': 'Filter by role',
  'panel.close': 'Close',
  'role.all': 'All',
  'role.user': 'User',
  'role.assistant': 'Agent',
  'role.tool': 'Tool',
  'role.other': 'Other',
  'session.untitled': 'Untitled session',
  'toast.anchorMissing': 'The target message was compacted away; the session was opened instead',
  'toast.anchorPending': 'Session opened; still lining up the target message',
  'panel.notLocatable': 'This message cannot be located precisely',
  'toast.sessionUnavailable': 'The target session is unavailable',
  'settings.title': 'Chat History Search',
  'settings.hint': 'Local bounded SQLite FTS5 index. Compact previews are stored; only the oldest derived index entries are evicted at the budget, never source conversations.',
  'settings.statusReady': '{sessions} sessions · {messages} messages indexed',
  'settings.statusSessions': '{sessions} sessions indexed',
  'settings.statusReadyNa': 'Index ready',
  'settings.statusFailed': 'Status unavailable',
  'settings.loading': 'Reading index status…',
  'settings.rebuild': 'Rebuild index',
  'settings.rebuilding': 'Rebuilding…',
  'settings.reindexStarted': 'Rebuilding index…',
  'settings.reindexDone': 'Index rebuild complete',
  'settings.rebuildFailed': 'Index rebuild failed',
  'settings.reindexRunning': 'A rebuild is already running',
  'settings.statusRebuildingProgress': 'Rebuilding {current}/{total} sessions · {messages} messages',
  'settings.statusRebuildingCounts': 'Rebuilding… {sessions} sessions · {messages} messages indexed',
  'settings.storage': 'Index disk {used} MiB · logical budget {limit} MiB',
  'settings.coverageSince': 'coverage since {date}',
  'settings.pruned': '{n} old index entries evicted',
  'settings.dbPath': 'Index database location',
  'settings.dbPathHint': 'Absolute path to a directory or .db file. Saving moves the existing index files there and deletes the old ones. ~ is expanded.',
  'settings.dbPathPlaceholder': '/path/to/memory-search/index.db',
  'settings.dbPathSave': 'Save path',
  'settings.dbPathSaving': 'Switching…',
  'settings.dbPathSaved': 'Index files moved to the new location',
  'settings.dbPathUnchanged': 'Already using this path',
  'settings.dbPathFailed': 'Could not save the index path',
  'settings.dbPathDefault': 'Restore default',
} as const

/**
 * Required Client services. Do NOT inject `remote.memorySearch`: the loader
 * would wait forever, because that nested service is created only by
 * `ctx.remote.$mount(...)` inside apply(). Platform plugins like ui-goal can
 * inject `remote.goals` because `dsh-api-remotes` mounts them first.
 *
 * After $mount, read the face with `ctx.get('remote.memorySearch')` (bypasses
 * the inject gate) and close over it. Slot `inject()` callbacks run on the
 * renderer fiber; `ctx.remote.memorySearch` there throws
 * `cannot get property "remote.memorySearch" without inject`.
 */
export const inject = ['slots', 'sessions', 'locale', 'remote']

function mountedMemorySearch(ctx: { get?: (name: string) => unknown }): RemoteMemorySearch {
  const face = ctx.get?.('remote.memorySearch') as RemoteMemorySearch | undefined
  if (
    face === undefined
    || typeof face.search !== 'function'
    || typeof face.status !== 'function'
    || typeof face.reindex !== 'function'
    || typeof face.setDbPath !== 'function'
  ) {
    throw new Error('memorySearch remote did not mount')
  }
  return face
}

export async function apply(ctx: any): Promise<void> {
  await ctx.remote.$mount(MEMORY_SEARCH_REMOTE)
  const memorySearch = mountedMemorySearch(ctx)
  ctx.effect(() => ensureStyles(), 'memory-search: styles')
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'memory-search: locale')
  const t = ctx.locale.bind(NS)

  // Global shortcut: Ctrl/Cmd+Shift+F toggles the panel; Escape closes it.
  ctx.effect(() => {
    const onKeyDown = (event: KeyboardEvent): void => {
      if ((event.ctrlKey || event.metaKey) && event.shiftKey && (event.key === 'F' || event.key === 'f')) {
        event.preventDefault()
        toggleOverlay()
        return
      }
      if (event.key === 'Escape' && getOverlaySnapshot().open) {
        closeOverlay()
      }
    }
      window.addEventListener('keydown', onKeyDown, true)
      return () => window.removeEventListener('keydown', onKeyDown, true)
  }, 'memory-search: shortcuts')

  // Sidebar entrance pill (footer action; relocates under the workspace list).
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action',
    id: 'memory-search-search',
    order: 0,
    locale: NS,
  }, SearchPill))

  // Floating search panel (closed by default; renders null while closed).
  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'memory-search-overlay',
    order: 100,
    locale: NS,
    inject: () => ({
      openSession: (sessionId: string) => ctx.sessions.open(sessionId),
      bindingSession: (sessionId: string) => ctx.sessions.binding(sessionId)?.session,
      resolveSubagent: (sessionId: string) => ctx.sessions.subagentAddress(sessionId),
      openSubagent: (address: { parentSessionId: string; childSessionId: string }) =>
        ctx.sessions.openSubagent(address),
      remote: memorySearch,
    }),
  }, SearchPanel))

  // Settings page: index status, path, and rebuild.
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'memory-search-settings',
    order: 80,
    label: () => t('settings.title'),
    locale: NS,
    inject: () => ({ remote: memorySearch }),
  }, SearchSettings))
}
