/**
 * Shared Host types for dsh-memory-search-plus.
 *
 * These types are the QA contract surface (tests/README.md「QA 测试契约」):
 * every JSON crossing the plugin boundary is a plain data object — no
 * Service/Session/Cordis live references may appear inside.
 */

/** dsh surface classification of one event in a session log. */
export type Surface = 'current' | 'shadowed' | 'log-only'

/** One indexable document (one session event's extracted text). */
export interface IndexRecord {
  sessionId: string
  seq: number
  type: string
  time: number
  surface: Surface
  text: string
  /** Precise anchor for message-level jump; null when the event type is not
   * locatable (todo/write, turn/end, …) — such docs are searchable but the
   * client renders them non-jumpable. */
  anchorKey: string | null
  /** Internal/search-cache representation flag. Callers may omit it. */
  textTruncated?: boolean
}

/** One search hit as returned by `memory-search/search`. */
export interface SearchHit {
  sessionId: string
  sessionTitle: string
  seq: number
  type: string
  /** user | assistant | tool (host mapping; client derives display role). */
  role: string
  /** Event time in epoch milliseconds. */
  time: number
  anchorKey: string | null
  /** Searchable preview text, truncated to ≤ 8192 chars. */
  text: string
  /** Preview window centered on the first match (buildSnippet). */
  snippet: string
  /** Highlight ranges as [start, end) character offsets INTO `text`
   * (already merged; `matchCount === spans.length`). */
  spans: Array<[number, number]>
  matchCount: number
  /** The searchable preview omits part of the original event. The source
   * session remains authoritative and can still be opened through anchorKey. */
  textTruncated: boolean
}

export type SurfaceFilter = Surface | 'all'

/** Speaker filter for search. `all` keeps every indexed event type. */
export type SearchRoleFilter = 'all' | 'user' | 'assistant' | 'tool'

export interface SearchOptions {
  limit?: number
  /** Filters docs by their surface; default `all`. `shadowed` docs are
   * dropped at rebuild, so hits are effectively current/log-only. */
  surface?: SurfaceFilter
  /** Filters docs by speaker. Applied in recall (before LIMIT), not as a
   * post-cut of mixed hits — otherwise a user-only query can still be
   * dominated by Agent paraphrases of the same words. */
  role?: SearchRoleFilter
}

export interface SearchResult {
  ok: boolean
  hits: SearchHit[]
  truncated: boolean
  /** Present on failure (human-readable; no live objects). */
  error?: string
}

export interface IndexStatus {
  ready: boolean
  indexedSessions: number
  indexedDocs: number
  building: boolean
  degraded: boolean
  /** Physical main database + WAL/SHM bytes when file-backed. */
  storageBytes?: number
  /** Configured logical index budget. `null` means explicitly unlimited. */
  storageLimitBytes?: number | null
  /** Number of oldest derived documents evicted to respect the budget. */
  prunedDocs?: number
  /** Oldest event still searchable after budget enforcement. */
  coverageSince?: number | null
}

/** 每个会话的持久索引状态（session_state 行；ADR-3/H2 状态机）。 */
export interface SessionStateRow {
  sessionId: string
  /** 已索引的最大事件 seq；-1 表示未索引任何事件。 */
  maxSeq: number
  /** 1 = 压缩检查点后待整会话重建（持久化脏标记）。 */
  dirty: number
  /** 首次索引完成时间（epoch ms）或 null。 */
  builtAt: number | null
  /** 该会话当前文档数（session_state 物化计数，L6）。 */
  docs: number
}

/** readTitleSnapshots 观察结果（真实形状 status/value.title.title，扁平防御兼容）。 */
export interface TitleObservation {
  sessionId?: string
  id?: string
  status?: string
  value?: { session?: unknown; title?: { title?: unknown; messageSeqs?: unknown; source?: unknown; eventSeq?: unknown; updatedAt?: unknown } }
  title?: unknown
}

/** 增量回调：过滤后文档（filterEvents 结果）。 */
export type FilterEventsFn = (
  sessionId: string,
) => Promise<Array<{ sessionId: string; seq: number; type: string; time: number; surface: Surface; text: string }>>

/** The index facade created by `createSearchIndex` (QA test contract). */
export interface SearchIndex {
  readonly ready: boolean
  readonly degraded: boolean
  status(): IndexStatus
  upsertRecords(records: IndexRecord[], rebuildSessionIds?: string[]): void | Promise<void>
  removeSession(sessionId: string): void | Promise<void>
  search(query: string, options?: SearchOptions): SearchResult
  close(): void
  /** H2 状态机扩展（非破坏性）：session_state 读取/写脏/清脏/会话清单。 */
  sessionState(sessionId: string): SessionStateRow | undefined
  markSessionDirty(sessionId: string): void
  clearSessionDirty(sessionId: string): void
  /** Advance the raw-event watermark even when the suffix contains no
   * indexable text. This prevents structural-only tails from being reread on
   * every reconcile pass. */
  advanceSessionWatermark(sessionId: string, maxSeq: number): void
  listSessionIds(): string[]
  /** FTS segment merge + WAL checkpoint; memory fallback is a no-op. */
  optimize(): void
  /** Generation snapshot around cooperative multi-transaction writes. Search
   * cache invalidation is deferred until the outer batch finishes. */
  beginBatch(): void
  endBatch(): void
}

/** One raw session log event (shape of session.jsonl.zstd decompressed). */
export interface SessionEvent {
  type: string
  seq?: number
  time?: number
  data?: Record<string, unknown> | null
  surfaceOp?: string | { op?: string; start?: number; end?: number }
  sourceEventSeqs?: number[]
}

/** Narrow view of the dsh `sessionQuery` service the plugin uses. */
export interface SessionQueryLike {
  filterEvents(
    sessionId: string,
    filters: unknown[],
  ): Promise<Array<{ sessionId: string; seq: number; type: string; time: number; surface: Surface; text: string }>>
  listSessions(): Promise<Array<{ id?: string; header?: { id?: string } }>>
  readTitleSnapshots(
    sessionIds: string[],
  ): Promise<unknown[]>
  /**
   * Live-preferred full raw log read (dsh `readSession`); optional — used as
   * the primary anchor-key source when rebuilding a session, so live sessions
   * with an unpersisted tail still get precise anchors. Falls back to
   * `sessionPersistence.readFrom(id, 0)`.
   */
  readSession?(sessionId: string): Promise<{ session?: unknown; events: SessionEvent[] }>
}

/** Narrow view of the dsh `sessionPersistence` service the plugin uses. */
export interface SessionPersistenceLike {
  readFrom(
    id: string,
    fromSeq: number,
  ): Promise<{ meta?: unknown; events: SessionEvent[] }>
}

/** Compaction checkpoint predicate (dsh 0.1.1: user/message + plugin=compact). */
export function isCompactionCheckpoint(event: unknown): boolean {
  if (event === null || typeof event !== 'object') return false
  const candidate = event as SessionEvent
  const source = candidate.data?.source as Record<string, unknown> | undefined
  return (
    candidate.type === 'user/message' &&
    source !== undefined &&
    source.kind === 'plugin' &&
    source.plugin === 'compact'
  )
}

/** Events that rewrite the visible session surface and therefore require an
 * authoritative whole-session rebuild. Used by both the live event path and
 * offline reconcile so compactions that happened while the plugin was down
 * cannot leave ghost hits behind. */
export function requiresSurfaceRebuild(event: unknown): boolean {
  if (event === null || typeof event !== 'object') return false
  return isCompactionCheckpoint(event) || (event as SessionEvent).type === 'compaction/prune'
}

/** True subagent sessions (`origin === 'subagent'`). Forked user chats also
 * carry `parentSession` and must still be indexed — that field is not a
 * subagent discriminator. */
export function isSubagentOrigin(origin: unknown): boolean {
  if (origin === 'subagent') return true
  if (origin !== null && typeof origin === 'object' && (origin as { kind?: unknown }).kind === 'subagent') {
    return true
  }
  return false
}

export function isSubagentSession(session: unknown): boolean {
  if (session === null || typeof session !== 'object') return false
  const rec = session as { origin?: unknown; header?: { origin?: unknown } }
  return isSubagentOrigin(rec.origin) || isSubagentOrigin(rec.header?.origin)
}

export const MAX_TEXT = 8_192
/** Bound hostile/accidental paste-sized queries before Intl.Segmenter/FTS. */
export const MAX_QUERY_CHARS = 1024
/** Stored user/assistant preview cap. Tool payloads use the tighter cap below. */
export const MAX_INDEX_TEXT_CHARS = 8_192
/** Tool/diagnostic payloads dominate chat-index growth. Keep a balanced
 * head/tail preview so commands and terminal errors remain searchable. */
export const MAX_TOOL_INDEX_TEXT_CHARS = 4_096
/** FTS tokenize input cap. CJK singles + bigrams are O(n) unique tokens. */
export const MAX_FTS_SOURCE_CHARS = MAX_INDEX_TEXT_CHARS
export const SNIPPET_RADIUS = 120
/** FTS candidate cap. Must be ≥ MAX_SEARCH_LIMIT so older time-sorted hits
 * are not dropped by bm25's top-N before we sort by time. */
export const RECALL_LIMIT = 2_048
export const INITIAL_RECALL_LIMIT = 128
export const SEARCH_TIME_BUDGET_MS = 100
export const DEFAULT_SEARCH_LIMIT = 100
export const SCHEMA_VERSION = 3
export const DEFAULT_REINDEX_CONCURRENCY = 8
export const MAX_REINDEX_CONCURRENCY = 16
export const MAX_SEARCH_LIMIT = 200
/** Bounded by default because this database is a rebuildable derivative, not
 * the conversation source of truth. Set DSH_MEMORY_SEARCH_MAX_INDEX_MB=0 to
 * opt into an unlimited index. */
export const DEFAULT_MAX_INDEX_BYTES = 1_073_741_824
