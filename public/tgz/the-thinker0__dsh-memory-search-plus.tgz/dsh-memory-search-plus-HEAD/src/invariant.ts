/**
 * Package-owned invariant companion for `dsh-memory-search-plus`.
 * @module dsh-memory-search-plus/invariant
 *
 * Host-side companion mounted beside the plugin's main Cordis row (the
 * packager wires it through cordis.patch.yml, same convention as
 * first-party @deepseek-ai packages). It registers the package in the
 * `invariants` service and checks one owned relation: whenever the plugin
 * graph changes, the plugin's own client bundle path must resolve under
 * this id — otherwise the served `__DSH_BOOT__` advertises a URL that
 * 404s and the whole client half silently never mounts.
 *
 * Every service access is optional; a host without `clientModules` or
 * `invariants` makes the companion inert.
 */

const PACKAGE_NAME = 'dsh-memory-search-plus'
const PLUGIN_ID = 'dsh-memory-search-plus'

/** Cordis companion plugin name. */
export const name = 'memory-search-invariant'

/** Service required before the companion can reserve package ownership. */
export const inject = ['invariants']

interface ModulesHost {
  clientPath?(id: string): string | undefined
}

/**
 * Register this package's invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export const apply = (ctx: any): Promise<() => void> => {
  const invariants = ctx?.get?.('invariants')
  if (invariants === undefined) return Promise.resolve(() => {})
  const install = (scope: any, fail: (message: string) => void): void => {
    if (scope === null || typeof scope !== 'object') return
    scope.on?.('internal/plugin', () => {
      const clientModules = scope.get?.('clientModules') as ModulesHost | undefined
      if (clientModules === undefined || typeof clientModules.clientPath !== 'function') return
      if (clientModules.clientPath(PLUGIN_ID) === undefined) {
        fail(`plugin graph row "${PLUGIN_ID}" advertises no client bundle path — the served __DSH_BOOT__ would 404 on fetch`)
      }
    }, { global: true })
  }
  return Promise.resolve(invariants.register(PACKAGE_NAME, install))
}
