#!/usr/bin/env node
/**
 * dsh-memory-search-plus 基准脚本。
 *
 * 生成 10 万条（默认）模拟会话事件 → 按契约 schema 建 SQLite FTS5 索引 →
 * 测建库耗时与 100 次查询延迟（中文短语/中文单关键词/英文短语三组）→ 输出表格，
 * 并给出 1M 规模外推。
 *
 * 用法：
 *   node scripts/bench.mjs                       # 默认 100k 事件 / 1000 会话 / 100 查询
 *   node scripts/bench.mjs --rows 200000 --queries 50
 *   node scripts/bench.mjs --impl lib/index.js   # 如已构建，改用真实实现建索引/搜索
 *
 * 目标（验收）：1M 规模 <60s 建库、<300ms 查询；10 万规模应显著低于。
 * 结果确定性：mulberry32 固定种子 → 可复现。
 */
import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const args = process.argv.slice(2);
function opt(name, dflt) {
  const i = args.indexOf(name);
  return i >= 0 ? (i + 1 < args.length ? args[i + 1] : dflt) : dflt;
}
function boundedNumber(name, dflt, min, max) {
  const raw = Number(opt(name, dflt));
  if (!Number.isFinite(raw)) throw new TypeError(`${name} 必须是有限数字`);
  return Math.min(max, Math.max(min, Math.floor(raw)));
}
const ROWS_RAW = Number(opt('--rows', 100_000));
const ROWS_CAP = 200_000;
if (!Number.isFinite(ROWS_RAW)) throw new TypeError('--rows 必须是有限数字');
const ROWS = Math.min(ROWS_CAP, Math.max(1, Math.floor(ROWS_RAW)));
if (ROWS_RAW > ROWS_CAP) {
  console.error(`[bench] --rows ${ROWS_RAW} 超过安全顶 ${ROWS_CAP}，已截断。更大的 MATCH 压力请用 scripts/stress.mjs，不要靠堆行数。`);
}
const SESSIONS = boundedNumber('--sessions', 1_000, 1, 10_000);
const QUERIES = boundedNumber('--queries', 100, 1, 1_000);
const SEED = boundedNumber('--seed', 20260825, 0, 0xffff_ffff);
const IMPL = opt('--impl', null);

// ---------------- deterministic PRNG ----------------
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(SEED);
const pick = (arr) => arr[Math.floor(rand() * arr.length)];
const rint = (n) => Math.floor(rand() * n);

// ---------------- synthetic session events ----------------
const ZH_SENTENCES = [
  '请帮我查找聊天记录', '我们来优化索引构建的性能', '这个基准测试跑了多久',
  '会议安排已经更新', '增量索引非常重要', '今天完成了单元测试',
  '中文分词效果还不错', '搜索响应时间需要控制', '记住上次的对话上下文',
  '压缩检查点触发了重建', '本地化的搜索体验很好', '跨会话检索很有用',
];
const EN_SENTENCES = [
  'How to search chat history', 'the benchmark finished quickly',
  'incremental indexing works', 'FTS5 tokens are lowercase', 'performance matters a lot',
  'we should measure query latency', 'the snippet truncation is fine', 'no more missing records',
];
const TOOL_NAMES = ['search_chat', 'read_file', 'run_command', 'list_files', 'agent_teams_status'];
function randomText() {
  const n = 1 + rint(3);
  const parts = [];
  for (let i = 0; i < n; i++) parts.push(rand() < 0.65 ? pick(ZH_SENTENCES) : pick(EN_SENTENCES));
  return parts.join('，');
}
function genRows() {
  const rows = [];
  const perSession = Math.ceil(ROWS / SESSIONS);
  let seqBase = 0;
  let t = 1_700_000_000_000;
  const typeCycle = ['user/message', 'assistant/message', 'tool/call', 'tool/result', 'user/message', 'assistant/message'];
  for (let s = 0; s < SESSIONS && rows.length < ROWS; s++) {
    const sid = `ses-bench-${String(s).padStart(6, '0')}`;
    for (let i = 0; i < perSession && rows.length < ROWS; i++) {
      const type = typeCycle[i % typeCycle.length];
      const text = type === 'tool/call' ? `${pick(TOOL_NAMES)} {"query":"${pick(ZH_SENTENCES)}"}` : randomText();
      rows.push({
        sessionId: sid, seq: i, type, time: (t += 1000 + rint(50_000)),
        surface: type === 'tool/call' ? 'log-only' : 'current',
        text, anchorKey: type.startsWith('tool') ? null : `13:input-messagebench-${s}-${i}`,
      });
    }
  }
  return rows;
}

// ---------------- tokenizer (contract reference) ----------------
const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/;
const SEGMENTER = new Intl.Segmenter('zh', { granularity: 'word' });
function tokenize(input) {
  const tokens = new Set();
  for (const seg of SEGMENTER.segment(input)) {
    if (!seg.isWordLike) continue;
    const w = seg.segment;
    if ([...w].every((ch) => CJK.test(ch))) continue; // CJK covered by bigram/single rules
    tokens.add(w.toLowerCase());
  }
  for (const m of input.matchAll(/\p{L}+|\p{N}+/gu)) {
    if ([...m[0]].every((ch) => CJK.test(ch))) continue;
    tokens.add(m[0].toLowerCase());
  }
  const chars = [...input];
  for (let i = 0; i < chars.length; i++) {
    if (!CJK.test(chars[i])) continue;
    tokens.add(chars[i]);
    if (i + 1 < chars.length && CJK.test(chars[i + 1])) tokens.add(chars[i] + chars[i + 1]);
  }
  return tokens.size ? [...tokens] : [];
}
function buildFtsQuery(text) {
  return tokenize(text).map((t) => `"${t}"`).join(' ');
}

// ---------------- reference indexer (approach benchmark) ----------------
function openDb(path) {
  const db = new DatabaseSync(path);
  db.exec('PRAGMA journal_mode=WAL');
  db.exec('CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT)');
  db.exec(
    'CREATE VIRTUAL TABLE IF NOT EXISTS docs USING fts5(' +
    'tokens, text UNINDEXED, session_id UNINDEXED, seq UNINDEXED, type UNINDEXED, ' +
    'time UNINDEXED, surface UNINDEXED, anchor_key UNINDEXED)',
  );
  return db;
}

function referenceBuild(rows, db) {
  const ins = db.prepare(
    'INSERT INTO docs(tokens, text, session_id, seq, type, time, surface, anchor_key) VALUES(?,?,?,?,?,?,?,?)',
  );
  const t0 = performance.now();
  db.exec('BEGIN');
  let batch = 0;
  for (const r of rows) {
    const tokens = tokenize(r.text).join(' ');
    ins.run(tokens, r.text, r.sessionId, r.seq, r.type, r.time, r.surface, r.anchorKey);
    if (++batch % 5_000 === 0) { db.exec('COMMIT'); db.exec('BEGIN'); }
  }
  db.exec('COMMIT');
  return (performance.now() - t0) / 1000;
}

/**
 * 旧 v2 变体 A：SQL 侧 ORDER BY surface=current→time DESC→seq DESC（对全匹配集排序）。
 * 旧 v2 变体 B：SQL 仅 MATCH + LIMIT 300（有界候选窗），JS 侧对 ≤300 候选排序。
 * 注意：SQLite 未显式 ORDER BY 时不保证全局相关性/时间序；B 只保证候选窗内排序。
 */
function referenceSearchSql(db, q) {
  const fts = buildFtsQuery(q);
  const row = db.prepare(
    'SELECT session_id, seq, type, time, surface, anchor_key, text FROM docs ' +
    "WHERE docs MATCH ? ORDER BY surface='current' DESC, time DESC, seq DESC LIMIT 300",
  ).all(fts);
  return verifyPhase2(row, q);
}

function referenceSearchJs(db, q) {
  const fts = buildFtsQuery(q);
  const row = db.prepare(
    'SELECT session_id, seq, type, time, surface, anchor_key, text FROM docs ' +
    'WHERE docs MATCH ? LIMIT 300',
  ).all(fts);
  row.sort((a, b) => {
    const sa = a.surface === 'current' ? 1 : 0;
    const sb = b.surface === 'current' ? 1 : 0;
    if (sa !== sb) return sb - sa;
    if (a.time !== b.time) return b.time - a.time;
    return b.seq - a.seq;
  });
  return verifyPhase2(row, q);
}

function verifyPhase2(row, q) {
  const lower = [...q.toLowerCase().matchAll(/[\p{L}\p{N}]+/gu)].map((match) => match[0]);
  return row.filter((r) => lower.every((t) => r.text.toLowerCase().includes(t))).length;
}

// ---------------- real implementation (--impl) ----------------
// lib/index.js 为纯 ESM（tsdown 产物，无 top-level await）：统一用动态 import
// 加载（Node 22.23.2 对 require(esm) 虽放开，但 import 路径对所有协议一致可靠）。
async function loadImpl(path) {
  const resolved = path.startsWith('file:') ? path : pathToFileURL(join(process.cwd(), path)).href;
  const m = await import(resolved);
  const createSearchIndex = m.createSearchIndex
    ?? (m.default && m.default.createSearchIndex);
  if (!createSearchIndex) throw new Error(`--impl ${path} 未导出 createSearchIndex`);
  return createSearchIndex;
}

function fmtMs(x) { return x.toFixed(1); }
function pct(values, p) {
  const v = [...values].sort((a, b) => a - b);
  return v[Math.min(v.length - 1, Math.floor((p / 100) * v.length))];
}

async function main() {
  const rows = genRows();
  console.log(`\n=== dsh-memory-search-plus bench (rows=${rows.length}, sessions=${SESSIONS}, queries=${QUERIES}) ===\n`);
  console.log(`生成 ${rows.length} 条模拟事件 (${SESSIONS} 会话) 完成`);
  const tempRoot = mkdtempSync(join(tmpdir(), 'msp-bench-'));
  const dbPath = join(tempRoot, 'bench.db');

  let db;
  let implIndex;
  try {
  let buildTitle, buildSec, searchFn;
  if (IMPL) {
    const createSearchIndex = await loadImpl(IMPL);
    const idx = createSearchIndex({ dbPath });
    implIndex = idx;
    const t0 = performance.now();
    const records = rows.map((r) => ({ ...r, anchorKey: r.anchorKey }));
    await idx.upsertRecords(records);
    buildSec = (performance.now() - t0) / 1000;
    buildTitle = `真实实现 ${IMPL}`;
    searchFn = async (q) => (await idx.search(q)).hits.length;
    db = null;
  } else {
    db = openDb(dbPath);
    buildSec = referenceBuild(rows, db);
    buildTitle = '参考实现（动态 SQL 参考 schema）';
    searchFn = (q) => referenceSearchSql(db, q);
  }

  let dbBytes = 0;
  for (const file of [dbPath, `${dbPath}-wal`, `${dbPath}-shm`]) {
    try { dbBytes += statSync(file).size; } catch { /* absent */ }
  }
  const dbSizeMb = dbBytes / 1048576;
  const perRow = rows.length === 0 ? 0 : (buildSec * 1000) / rows.length;
  console.log(`建库：${buildSec.toFixed(2)}s（${buildTitle}；${perRow.toFixed(3)} ms/行；db ${dbSizeMb.toFixed(1)} MB）`);

  const groups = [
    { name: '中文短语', queries: ['查找聊天记录', '增量索引', '基准测试'] },
    { name: '中文单关键词', queries: ['索引', '聊天', '搜索'] },
    { name: '英文短语', queries: ['search chat history', 'incremental indexing', 'query latency'] },
    { name: '混合', queries: ['索引 performance', '聊天记录 benchmark'] },
  ];

  let totalMiss = 0;
  const table = [];
  const hasReference = db !== null;
  const measureGroup = async (fn, round) => {
    const lat = [];
    let miss = 0;
    for (let i = 0; i < QUERIES; i++) {
      // Punctuation does not change tokens/semantics, but creates a distinct
      // normalized cache key so the table reports cold-query cost rather than
      // mostly measuring the 64-entry LRU.
      const q = `${'!'.repeat(i + 1)}${round.queries[i % round.queries.length]}`;
      const t0 = performance.now();
      const n = await fn(q);
      lat.push(performance.now() - t0);
      if (n === 0) miss++;
    }
    return { lat, miss };
  };
  for (const g of groups) {
    const run = await measureGroup(searchFn, g);
    totalMiss += run.miss;
    const entry = {
      group: g.name,
      p50: pct(run.lat, 50), p95: pct(run.lat, 95), max: Math.max(...run.lat), miss: run.miss,
    };
    if (hasReference) {
      const sqlRun = await measureGroup((q) => referenceSearchSql(db, q), g);
      const jsRun = await measureGroup((q) => referenceSearchJs(db, q), g);
      entry.refSqlP95 = pct(sqlRun.lat, 95);
      entry.refJsP95 = pct(jsRun.lat, 95);
    }
    table.push(entry);
  }

  console.log('\n冷查询延迟（ms；以等价标点变体绕过 LRU；hits=0 为未命中；参考列 = 参考实现 ' + (hasReference ? 'A=SQL ORDER BY / B=JS 排序' : '--impl 真实实现') + '）');
  console.log('──────────────────────────────────────────────────────────────');
  if (hasReference) {
    console.log('组别               实测p50  实测p95  参考A p95  参考B p95  未命中');
    for (const r of table) {
      console.log(`${r.group.padEnd(14)}  ${fmtMs(r.p50).padStart(8)} ${fmtMs(r.p95).padStart(8)} ${fmtMs(r.refSqlP95).padStart(10)} ${fmtMs(r.refJsP95).padStart(10)}   ${r.miss}/${QUERIES}`);
    }
  } else {
    console.log('组别               p50      p95      max    未命中');
    for (const r of table) {
      console.log(`${r.group.padEnd(14)}  ${fmtMs(r.p50).padStart(7)} ${fmtMs(r.p95).padStart(8)} ${fmtMs(r.max).padStart(8)}   ${r.miss}/${QUERIES}`);
    }
  }
  console.log('──────────────────────────────────────────────────────────────');

  // 1M 外推（线性，保守）
  const mult = 1_000_000 / rows.length;
  console.log(`\n1M 规模外推（线性 ×${mult.toFixed(1)}）：建库 ≈ ${(buildSec * mult).toFixed(1)}s` +
    `，查询 p95 ≈ ${(table.reduce((a, r) => Math.max(a, r.p95), 0) * mult).toFixed(1)}ms`);
  console.log('目标：1M <60s 建库、<300ms 查询（p95）。' +
    (buildSec * mult < 60 && table.reduce((a, r) => Math.max(a, r.p95), 0) * mult < 300 ? ' ✅ 达标' : ' ⚠️ 未达标'));
  console.log(`\n抽样正确性：未命中 ${totalMiss}/${QUERIES * groups.length}（<2% 为合理，受合成数据影响）`);

  } finally {
    try { implIndex?.close(); } catch { /* ignore */ }
    try { db?.close(); } catch { /* ignore */ }
    rmSync(tempRoot, { recursive: true, force: true });
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
