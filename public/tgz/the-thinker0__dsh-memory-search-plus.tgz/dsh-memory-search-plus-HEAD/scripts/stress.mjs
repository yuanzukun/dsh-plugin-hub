#!/usr/bin/env node
/**
 * 有界压力测试：模拟 1M 规模的「贵路径」，不堆 TB 数据，不碰 ~/.dsh。
 *
 * 真正贵的是：
 *   1) 宽词 FTS MATCH 集 + 长文本阶段 2
 *   2) 重建时 filterEvents 的假 I/O
 *   3) 建库/重建期间并发查询（SQLite 同连接交织）
 *
 * 硬顶：rows ≤ 200k（--i-accept-risk 时 500k）；db ≤ 512MB；RSS ≤ 1.5GB。
 *
 *   node scripts/stress.mjs
 *   node scripts/stress.mjs --profile extreme --impl lib/index.js
 */
import { DatabaseSync } from 'node:sqlite'
import { mkdtempSync, rmSync, statSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const args = process.argv.slice(2)
function opt(name, dflt) {
  const i = args.indexOf(name)
  return i >= 0 ? (i + 1 < args.length ? args[i + 1] : dflt) : dflt
}
function flag(name) {
  return args.includes(name)
}

function boundedNumber(name, dflt, min, max) {
  const raw = Number(opt(name, dflt))
  if (!Number.isFinite(raw)) throw new TypeError(`${name} 必须是有限数字`)
  return Math.min(max, Math.max(min, Math.floor(raw)))
}

const ACCEPT_RISK = flag('--i-accept-risk')
const HARD_ROWS = ACCEPT_RISK ? 500_000 : 200_000
const HARD_DB_MB = 512
const HARD_RSS_MB = 1536
const PROFILE = opt('--profile', 'default') // default | extreme
if (!['default', 'extreme'].includes(PROFILE)) throw new TypeError(`未知 --profile ${PROFILE}`)
const EXTREME = PROFILE === 'extreme'

const DEFAULT_ROWS = EXTREME ? 200_000 : 50_000
const DEFAULT_SESSIONS = EXTREME ? 400 : 200
const DEFAULT_DOCS_PER = EXTREME ? 800 : 250
const DEFAULT_QUERIES = EXTREME ? 60 : 40
const DEFAULT_CONCURRENCY = EXTREME ? 8 : 4
const HOT_RATIO = EXTREME ? 0.8 : 0.3
const LONG_RATIO = EXTREME ? 0.2 : 0
const SEARCHERS = EXTREME ? 4 : 0
const FAKE_IO_MS = EXTREME ? 80 : 40
const REBUILD_SESSIONS = EXTREME ? 80 : Math.min(80, DEFAULT_SESSIONS)

const MODE = opt('--mode', 'all')
const REQUESTED_ROWS = boundedNumber('--rows', DEFAULT_ROWS, 1, Number.MAX_SAFE_INTEGER)
const ROWS = Math.min(HARD_ROWS, REQUESTED_ROWS)
const SESSIONS = boundedNumber('--sessions', DEFAULT_SESSIONS, 1, 800)
const DOCS_PER = boundedNumber('--docs-per', DEFAULT_DOCS_PER, 1, 2_000)
const QUERIES = boundedNumber('--queries', DEFAULT_QUERIES, 10, 120)
const SEED = boundedNumber('--seed', 20260826, 0, 0xffff_ffff)
const IMPL = opt('--impl', existsSync(join(process.cwd(), 'lib/index.js')) ? 'lib/index.js' : null)
const CONCURRENCY = boundedNumber('--concurrency', DEFAULT_CONCURRENCY, 1, 8)

if (REQUESTED_ROWS > HARD_ROWS) {
  console.error(
    `[stress] --rows 超过硬顶 ${HARD_ROWS}，已截断为 ${ROWS}。` +
      (ACCEPT_RISK ? '' : ' 真要更高请加 --i-accept-risk（绝对上限 500k）。'),
  )
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'msp-stress-'))
const dbPath = join(tmpRoot, 'stress.db')
let aborted = false
let peakRss = 0

function rssMb() {
  const n = process.memoryUsage().rss / 1048576
  if (n > peakRss) peakRss = n
  return n
}
function dbMb() {
  let bytes = 0
  for (const file of [dbPath, `${dbPath}-wal`, `${dbPath}-shm`]) {
    try {
      bytes += statSync(file).size
    } catch {
      /* absent sidecar */
    }
  }
  return bytes / 1048576
}
function abort(reason) {
  if (aborted) return
  aborted = true
  console.error(`\n[stress] ABORT: ${reason}  (rss=${rssMb().toFixed(0)}MB db=${dbMb().toFixed(1)}MB)`)
  cleanup()
  process.exit(2)
}
function cleanup() {
  try {
    rmSync(tmpRoot, { recursive: true, force: true })
  } catch {
    /* ignore */
  }
}
process.on('SIGINT', () => abort('SIGINT'))
process.on('SIGTERM', () => abort('SIGTERM'))
const watchdog = setInterval(() => {
  if (rssMb() > HARD_RSS_MB) abort(`RSS 超过 ${HARD_RSS_MB}MB`)
  if (dbMb() > HARD_DB_MB) abort(`DB 超过 ${HARD_DB_MB}MB`)
}, 500)
watchdog.unref()

function mulberry32(seed) {
  let a = seed >>> 0
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
const rand = mulberry32(SEED)
const pick = (arr) => arr[Math.floor(rand() * arr.length)]
const rint = (n) => Math.floor(rand() * n)

const ZH = [
  '请帮我查找聊天记录',
  '我们来优化索引构建的性能',
  '会议安排已经更新',
  '增量索引非常重要',
  '中文分词效果还不错',
  '搜索响应时间需要控制',
  '压缩检查点触发了重建',
  '跨会话检索很有用',
]
const EN = [
  'search chat history',
  'incremental indexing works',
  'query latency budget',
  'performance matters a lot',
]
const HOT = ['索引', '聊天', '搜索']
const LONG_PAD = '工具输出填充：路径/tmp/agent/run 日志片段与上下文。'.repeat(40) // ~1.2KB

function oneDoc(sessionId, seq, hot, longDoc = false) {
  const type = seq % 6 === 2 ? 'tool/call' : seq % 2 === 0 ? 'user/message' : 'assistant/message'
  let body = hot
    ? `${pick(HOT)}：${pick(ZH)} ${pick(EN)} ${pick(HOT)}`
    : `${pick(ZH)}，${pick(EN)}`
  if (longDoc) body = `${body}\n${LONG_PAD}\n${body}`
  return {
    sessionId,
    seq,
    type,
    time: 1_700_000_000_000 + seq * 1000 + rint(500),
    surface: type === 'tool/call' ? 'log-only' : 'current',
    text: body,
    anchorKey: type.startsWith('tool') ? null : `13:input-message${sessionId}-${seq}`,
  }
}

function* streamDocs(count, sessions) {
  for (let i = 0; i < count; i++) {
    const sid = `ses-stress-${String(i % sessions).padStart(4, '0')}`
    yield oneDoc(sid, Math.floor(i / sessions), rand() < HOT_RATIO, rand() < LONG_RATIO)
  }
}

function pct(values, p) {
  if (values.length === 0) return 0
  const v = [...values].sort((a, b) => a - b)
  return v[Math.min(v.length - 1, Math.floor((p / 100) * v.length))]
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms))
}
function fmtLat(lat) {
  if (lat.length === 0) return 'n/a'
  return `n=${lat.length} p50=${pct(lat, 50).toFixed(1)}ms p95=${pct(lat, 95).toFixed(1)}ms max=${Math.max(...lat).toFixed(1)}ms`
}

async function loadImpl(path) {
  const href = path.startsWith('file:') ? path : pathToFileURL(join(process.cwd(), path)).href
  const m = await import(href)
  const fn = m.createSearchIndex ?? m.default?.createSearchIndex
  if (!fn) throw new Error(`--impl ${path} 未导出 createSearchIndex`)
  return { createSearchIndex: fn, upsertRecordsCooperatively: m.upsertRecordsCooperatively }
}

function openRef(path) {
  const db = new DatabaseSync(path)
  db.exec('PRAGMA journal_mode=WAL')
  db.exec('PRAGMA synchronous=NORMAL')
  db.exec(
    'CREATE VIRTUAL TABLE IF NOT EXISTS ftsevents USING fts5(' +
      'tokens, text UNINDEXED, session_id UNINDEXED, seq UNINDEXED, type UNINDEXED, ' +
      'time UNINDEXED, surface UNINDEXED, anchor_key UNINDEXED)',
  )
  return db
}

const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/
const SEGMENTER = new Intl.Segmenter('zh', { granularity: 'word' })
function tokenize(input) {
  const tokens = new Set()
  for (const seg of SEGMENTER.segment(input)) {
    if (!seg.isWordLike) continue
    const w = seg.segment
    if ([...w].every((ch) => CJK.test(ch))) continue
    tokens.add(w.toLowerCase())
  }
  for (const m of input.matchAll(/\p{L}+|\p{N}+/gu)) {
    if ([...m[0]].every((ch) => CJK.test(ch))) continue
    tokens.add(m[0].toLowerCase())
  }
  const chars = [...input]
  for (let i = 0; i < chars.length; i++) {
    if (!CJK.test(chars[i])) continue
    tokens.add(chars[i])
    if (i + 1 < chars.length && CJK.test(chars[i + 1])) tokens.add(chars[i] + chars[i + 1])
  }
  return [...tokens]
}

async function makeBackend() {
  if (IMPL) {
    const { createSearchIndex, upsertRecordsCooperatively } = await loadImpl(IMPL)
    const idx = createSearchIndex({ dbPath })
    return {
      kind: `impl ${IMPL}`,
      async writeBatch(records, rebuildIds) {
        if (typeof upsertRecordsCooperatively === 'function') {
          await upsertRecordsCooperatively(idx, records, rebuildIds)
        } else {
          await idx.upsertRecords(records, rebuildIds)
        }
      },
      async search(q) {
        return (await idx.search(q, { limit: 60 })).hits.length
      },
      close() {
        idx.close()
      },
      status() {
        return idx.status()
      },
    }
  }
  const db = openRef(dbPath)
  const ins = db.prepare(
    'INSERT INTO ftsevents(tokens, text, session_id, seq, type, time, surface, anchor_key) VALUES(?,?,?,?,?,?,?,?)',
  )
  const del = db.prepare('DELETE FROM ftsevents WHERE session_id = ?')
  return {
    kind: 'inline sqlite',
    async writeBatch(records, rebuildIds = []) {
      db.exec('BEGIN')
      for (const id of rebuildIds) del.run(id)
      for (const r of records) {
        ins.run(tokenize(r.text).join(' '), r.text, r.sessionId, r.seq, r.type, r.time, r.surface, r.anchorKey)
      }
      db.exec('COMMIT')
    },
    async search(q) {
      const fts = tokenize(q)
        .slice(0, 32)
        .map((t) => `"${t}"`)
        .join(' ')
      if (fts === '') return 0
      const rows = db.prepare('SELECT text FROM ftsevents WHERE ftsevents MATCH ? LIMIT 300').all(fts)
      const terms = [...q.toLowerCase().matchAll(/[\p{L}\p{N}]+/gu)].map((match) => match[0])
      return rows.filter((row) => terms.every((t) => String(row.text).toLowerCase().includes(t))).length
    },
    close() {
      db.close()
    },
    status() {
      return null
    },
  }
}

function startSearchers(backend, stop) {
  const queries = ['索引', '聊天', '搜索', '查找聊天记录', '增量索引']
  return Array.from({ length: SEARCHERS }, async () => {
    const lat = []
    while (!stop.done) {
      const t0 = performance.now()
      try {
        await backend.search(queries[lat.length % queries.length])
      } catch {
        /* 建库早期空库可空命中 */
      }
      lat.push(performance.now() - t0)
      await sleep(0)
    }
    return lat
  })
}

async function scenarioWrite(backend) {
  console.log(
    `\n[write] 流式插入 ${ROWS} 行 / ${SESSIONS} 会话（hot=${HOT_RATIO} long=${LONG_RATIO} batch=2000` +
      (SEARCHERS > 0 ? `；${SEARCHERS} 路并发查询` : '') +
      '）',
  )
  const stop = { done: false }
  const searchers = SEARCHERS > 0 ? startSearchers(backend, stop) : []
  const t0 = performance.now()
  let n = 0
  let batch = []
  for (const doc of streamDocs(ROWS, SESSIONS)) {
    batch.push(doc)
    if (batch.length >= 2000) {
      await backend.writeBatch(batch)
      n += batch.length
      batch = []
      if (SEARCHERS > 0) await sleep(0)
      if (n % 20_000 === 0) {
        console.log(`  … ${n}/${ROWS}  rss=${rssMb().toFixed(0)}MB db=${dbMb().toFixed(1)}MB`)
      }
    }
  }
  if (batch.length) {
    await backend.writeBatch(batch)
    n += batch.length
  }
  const sec = (performance.now() - t0) / 1000
  stop.done = true
  const mixedLat = (await Promise.all(searchers)).flat()
  const docsPerSec = n / sec
  const status = backend.status()
  if (status !== null && status.indexedDocs !== n) {
    throw new Error(`写入后计数漂移: expected=${n} actual=${status.indexedDocs}`)
  }
  console.log(
    `[write] ${n} 行 ${sec.toFixed(2)}s  (${(docsPerSec / 1000).toFixed(1)}k docs/s)  db=${dbMb().toFixed(1)}MB rss=${rssMb().toFixed(0)}MB`,
  )
  if (mixedLat.length > 0) console.log(`[write] 建库期间并发查询  ${fmtLat(mixedLat)}`)
  return { n, sec, docsPerSec, mixedLat }
}

async function scenarioQuery(backend) {
  console.log(`\n[query] 窄词 / 宽词 / 多关键词 AND（各 ${QUERIES} 次冷查询；标点变体绕过 LRU）`)
  const groups = [
    { name: '窄短语', queries: ['查找聊天记录', '增量索引', 'query latency'] },
    { name: '宽单字/词', queries: ['索引', '聊天', '搜索'] },
    { name: '多词 AND', queries: ['聊天记录 会议', '索引 性能', 'search history'] },
  ]
  const out = []
  for (const g of groups) {
    const lat = []
    let hits = 0
    for (let i = 0; i < QUERIES; i++) {
      const q = `${'!'.repeat(i + 1)}${g.queries[i % g.queries.length]}`
      const t0 = performance.now()
      hits += await backend.search(q)
      lat.push(performance.now() - t0)
    }
    const row = { group: g.name, p50: pct(lat, 50), p95: pct(lat, 95), max: Math.max(...lat), avgHits: hits / QUERIES }
    if (row.avgHits <= 0) throw new Error(`${g.name} 压测语料意外零命中`)
    out.push(row)
    console.log(
      `  ${g.name.padEnd(10)}  p50=${row.p50.toFixed(1)}ms  p95=${row.p95.toFixed(1)}ms  max=${row.max.toFixed(1)}ms  均命中≈${row.avgHits.toFixed(0)}`,
    )
  }
  return out
}

async function scenarioRebuild(backend) {
  const sessionN = Math.min(SESSIONS, REBUILD_SESSIONS)
  const docs = DOCS_PER
  console.log(
    `\n[rebuild] ${sessionN} 会话 × ${docs} 文档，并发 ${CONCURRENCY}，每会话假 I/O ${FAKE_IO_MS}ms` +
      (SEARCHERS > 0 ? `；${SEARCHERS} 路并发查询` : '') +
      '（不读真日志）',
  )
  const ids = Array.from({ length: sessionN }, (_, i) => `ses-rebuild-${String(i).padStart(3, '0')}`)
  const stop = { done: false }
  const searchers = SEARCHERS > 0 ? startSearchers(backend, stop) : []
  let cursor = 0
  let done = 0
  const t0 = performance.now()
  const worker = async () => {
    for (;;) {
      const i = cursor++
      const id = ids[i]
      if (id === undefined) return
      await sleep(FAKE_IO_MS)
      const records = []
      for (let s = 0; s < docs; s++) records.push(oneDoc(id, s, s % 5 !== 0, s % 8 === 0))
      await backend.writeBatch(records, [id])
      done++
    }
  }
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, ids.length) }, () => worker()))
  const sec = (performance.now() - t0) / 1000
  stop.done = true
  const mixedLat = (await Promise.all(searchers)).flat()
  const serialEst = (sessionN * FAKE_IO_MS) / 1000
  console.log(
    `[rebuild] ${done} 会话 ${sec.toFixed(2)}s  （纯串行假 I/O 下界 ${serialEst.toFixed(1)}s）  rss=${rssMb().toFixed(0)}MB`,
  )
  if (mixedLat.length > 0) console.log(`[rebuild] 重建期间并发查询  ${fmtLat(mixedLat)}`)
  return { sessions: done, sec, serialEst, mixedLat }
}

async function main() {
  console.log(`=== dsh-memory-search-plus stress ===`)
  console.log(
    `profile=${PROFILE} mode=${MODE} rows=${ROWS} sessions=${SESSIONS} impl=${IMPL ?? '(inline sqlite)'}`,
  )
  console.log(
    `caps: rows≤${HARD_ROWS} db≤${HARD_DB_MB}MB rss≤${HARD_RSS_MB}MB  tmp ${tmpRoot}`,
  )
  if (!['write', 'query', 'rebuild', 'all'].includes(MODE)) abort(`未知 --mode ${MODE}`)
  const backend = await makeBackend()
  console.log(`backend: ${backend.kind}`)
  try {
    if (MODE === 'write' || MODE === 'query' || MODE === 'all') {
      await scenarioWrite(backend)
    }
    if (MODE === 'query' || MODE === 'all') {
      await scenarioQuery(backend)
    }
    if (MODE === 'rebuild' || MODE === 'all') {
      await scenarioRebuild(backend)
    }
    const scale = 1_000_000 / ROWS
    console.log(
      `\n[ok] 峰值 rss=${peakRss.toFixed(0)}MB  db=${dbMb().toFixed(1)}MB  （临时库将删除，不碰 ~/.dsh）`,
    )
    console.log(
      `读数：宽词 + 建库/重建期间并发查询才是这一档；线性 ×${scale.toFixed(1)} 只适用于建库吞吐，不适用于宽词 p95。`,
    )
  } finally {
    try {
      backend.close()
    } catch {
      /* ignore */
    }
    cleanup()
    if (existsSync(tmpRoot)) throw new Error(`临时目录清理失败: ${tmpRoot}`)
  }
}

main().catch((error) => {
  console.error(error)
  cleanup()
  process.exit(1)
})
