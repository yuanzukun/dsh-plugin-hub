import { existsSync } from 'node:fs'
import type { UserConfig } from 'tsdown'
import { defineConfig } from 'tsdown'

const PLUGIN_ID = 'dsh-memory-search-plus'

/**
 * Modules the Web client runtime already provides (bundled with
 * dsh-client-runtime / dsh-client-locale / dsh-client-ui-conversation and the
 * app shell). They must be left as `require(...)` calls so the
 * `window.__ModuleLoader__` factory `require` can resolve them; bundling them
 * would duplicate the app's own module instances.
 */
const CLIENT_EXTERNALS = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-runtime',
  '@deepseek-ai/dsh-client-runtime/client',
  '@deepseek-ai/dsh-client-locale',
  '@deepseek-ai/dsh-client-locale/client',
  '@deepseek-ai/dsh-client-ui-conversation',
  '@deepseek-ai/dsh-client-ui-slots',
] as const

/** Client entry candidates: `src/client/index.tsx` preferred, `src/client.tsx` fallback. */
const CLIENT_ENTRY_CANDIDATES = [
  'src/client/index.tsx',
  'src/client/index.ts',
  'src/client.tsx',
  'src/client.ts',
] as const

function resolveClientEntry(): string {
  for (const candidate of CLIENT_ENTRY_CANDIDATES) {
    if (existsSync(candidate)) return candidate
  }
  throw new Error(
    `[${PLUGIN_ID}] Client entry not found. Expected one of: ${CLIENT_ENTRY_CANDIDATES.join(', ')}`,
  )
}

const host: UserConfig = {
  name: PLUGIN_ID,
  entry: ['src/index.ts'],
  outDir: 'lib',
  format: 'esm',
  platform: 'node',
  target: 'es2024',
  dts: false,
  clean: true,
  outputOptions: {
    entryFileNames: 'index.js',
  },
}

const client: UserConfig = {
  name: `${PLUGIN_ID}/client`,
  entry: { client: resolveClientEntry() },
  outDir: 'lib',
  format: 'cjs',
  platform: 'browser',
  target: 'es2024',
  dts: false,
  sourcemap: true,
  clean: false,
  deps: {
    neverBundle: [...CLIENT_EXTERNALS],
    alwaysBundle: (id: string) => !CLIENT_EXTERNALS.some((external) => external === id),
  },
  outputOptions: {
    entryFileNames: 'client.js',
    // The Web runtime loads every plugin client through ModuleLoader; the
    // banner/footer/intro wrap the CJS bundle into the factory body.
    banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(PLUGIN_ID)}, factory: (require) => {`,
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
  },
}

export default defineConfig([host, client])
