# dsh-memory-search-plus 架构

状态：schema v3，实现与测试的长期说明。

## 1. 目标与边界

插件为 DSH Web 提供本地、跨会话、中文友好的消息级全文搜索。DSH 会话日志始终是事实源；SQLite 索引只是可删除、可迁移、可重建的派生缓存。

默认索引逻辑预算为 1 GiB。要同时满足“永久全量、任意词精确搜索”和“固定磁盘”在信息论上不可能，因此默认策略在达到预算时淘汰最旧的派生文档，并在设置页公开覆盖起点。用户可通过 `DSH_MEMORY_SEARCH_MAX_INDEX_MB=0` 显式选择不限量。

非目标：云同步、遥测、向量语义检索、修改原始会话、持久化会话标题。

## 2. 数据流

```text
session/event ──抽取/头尾预算──▶ cooperative micro-batch ──▶ SQLite WAL
                                                        ├─ docs（正文/元数据）
                                                        └─ contentless FTS（tokens）

query ──规范化──▶ FTS 自适应召回 ──▶ 字面 AND 复核 ──▶ top-k/highlight ──▶ Client

startup/reconcile ──水印/dirty──▶ 增量补齐或单会话重建
idle maintenance ──▶ bounded FTS merge + checkpoint + incremental vacuum
```

## 3. schema v3

```sql
CREATE TABLE docs(
  rowid INTEGER PRIMARY KEY,
  session_id TEXT NOT NULL,
  seq INTEGER NOT NULL,
  type TEXT NOT NULL,
  time INTEGER NOT NULL,
  surface TEXT NOT NULL,
  anchor_key TEXT,
  text TEXT NOT NULL,
  text_truncated INTEGER NOT NULL DEFAULT 0,
  stored_bytes INTEGER NOT NULL DEFAULT 0,
  UNIQUE(session_id, seq)
);

CREATE VIRTUAL TABLE ftsevents USING fts5(
  tokens,
  content='',
  contentless_delete=1,
  detail=none
);

CREATE TABLE session_state(
  session_id TEXT PRIMARY KEY,
  max_seq INTEGER NOT NULL DEFAULT -1,
  dirty INTEGER NOT NULL DEFAULT 0,
  built_at INTEGER,
  docs INTEGER NOT NULL DEFAULT 0
);
```

`docs.rowid === ftsevents.rowid`。FTS 不保存正文、元数据或位置；精确 spans 由已取回的有限正文计算。`docs(session_id,seq)` 提供幂等键，替代 v2 的 `event_keys`。

`UNIQUE(session_id,seq)` 的自动索引服务幂等/会话操作；`docs_time_idx` 服务容量淘汰。surface/type 的二级索引不会参与 FTS-first 查询计划，因此不创建。

### 迁移

v1/v2 在一个事务中建立 `docs_v3` 与 `ftsevents_v3`，复制现有搜索数据，随后替换旧表并删除 `event_keys`。提交后执行一次带持久重试标记的 `VACUUM`，移除新旧表并存造成的临时高水位并启用 incremental auto-vacuum。迁移失败时事务回滚；外层损坏恢复流程最多保留最近一代 `.bak-*`，再建立空 v3 库。源会话不受影响。

未来版本号高于当前 `SCHEMA_VERSION` 时不移动、不覆盖文件，临时降级到内存索引，避免旧插件破坏新格式。

## 4. 正文保留策略

`boundIndexText()` 是唯一正文预算入口：

- 用户与 Agent：最多 8,192 UTF-16 code units。
- 工具调用、工具结果与错误：最多 4,096。
- 超长正文各保留约一半头部和尾部，中间插入省略标记。
- 长度 ≥512 的 base64/hash-like 不透明 run 被替换，避免二进制粘贴污染分词和磁盘。
- NUL 转为替换字符。

命中携带 `textTruncated`，Client 显示“索引预览”。锚点仍跳回源会话；索引文本不冒充完整消息。

## 5. 分词

索引侧组合：`Intl.Segmenter('zh')` 的 word-like 非纯 CJK 词、英文/数字 run、CJK bigram、CJK single。token 去重并限制输入为 8,192 字符。

查询侧去掉多字查询中的 CJK single，减少高频 posting；单字查询保留 single。查询最多使用前 32 个 token，每个 token 单独加引号并以隐式 AND 连接。

Segmenter 可能把 `search_events` 视为一个 word-like segment，而 SQLite `unicode61` 会拆开它。tokenizer 只接受纯字母数字 token，并由 run pass 生成 `search`、`events`，避免 `detail=none` 下意外形成不可执行的多 token phrase。

## 6. 查询

1. 校验 query（空查询返回空结果；最长 1,024 字符）。
2. 构造 FTS token AND 查询，并在 SQL 内应用 surface/role 过滤。
3. FTS rowid 以“分钟桶＋桶内时间槽”编码，posting 可直接 `ORDER BY rowid DESC` 从尾部取最新候选，避免给宽匹配集做全局 SQL 排序；候选再按精确 `time DESC,seq DESC` 排序。
4. 候选预算从 `max(128, 2×limit)` 开始，不足时倍增；最多扫描 2,048 条，阶段时间预算 100 ms。
5. 对候选正文做逐查询片段的字面 AND 复核（中文连续串保持完整），计算 spans/snippet。
6. 默认返回 100 条、上限 200；候选未穷尽或命中多于 limit 时 `truncated=true`。

查询结果使用 64 项 generation LRU。每次逻辑写入使 generation 失效；cooperative multi-batch 写期间，已缓存查询继续读取上一代结果，未缓存查询可读取已提交部分，结束时统一失效。这避免重建期间对相同宽查询反复扫库，同时不宣称 SQLite 跨事务快照。

## 7. 写入、一致性与恢复

直接 `upsertRecords()` 对小批次保持单事务原子性。Host 的大重建与大增量使用 `upsertRecordsCooperatively()`：每 256 条一个事务并在批间 `setImmediate`，避免同步 `DatabaseSync` 长时间独占事件循环。

多事务会话重建通过 `session_state.dirty=1` 保证 crash recovery：完成前崩溃时，下次 reconcile 整会话重做；完成后清 dirty。`max_seq` 是原始事件水印，即使 suffix 只有结构事件也会推进。

整会话重建丢弃 `surface='shadowed'`，保留 `current`/`log-only`。`(session_id,seq)` 重放为替换，不增加计数。

节点缺少 `node:sqlite` 或文件库无法恢复时降级为内存实现；API 仍可搜索，但不持久化。

## 8. 容量与维护

`stored_bytes` 记录正文、预分词输入与行开销的保守逻辑估算。超过预算时：

1. 目标降至预算的 85%，防止每次写入都触发清理。
2. 按 `time ASC,rowid ASC` 删除最旧 `docs`/FTS 行。
3. `session_state` 行和 `max_seq` 保留，避免 reconcile 立刻把已淘汰历史重新建回。
4. 更新 `pruned_docs` 与覆盖起点；只影响派生索引。

SQLite 参数：WAL、`synchronous=NORMAL`、16 MiB page cache、256 MiB mmap（可用时）、`secure_delete=FAST`。FTS 开启 secure-delete、`automerge=4`、`crisismerge=16`、`deletemerge=10`。

每 30 分钟空闲维护执行最多 64 页的 FTS `merge`、WAL TRUNCATE checkpoint 和 256 页 incremental vacuum。禁止把全库 `VACUUM` 或无限 `optimize` 放入周期热路径。

## 9. RPC 与 Client

Host 暴露 `search`、`status`、`reindex`、`setDbPath` 四个纯 JSON Remote 方法。`status` 包含：文档/会话计数、构建进度、物理存储字节、逻辑预算、淘汰数、覆盖起点，以及当前/默认数据库路径。

索引路径解析顺序：设置页写入的 `${DSH_HOME}/storages/memory-search/location.json` → 环境变量 `DSH_MEMORY_SEARCH_DB` → 插件配置 `dbPath` → 默认 `${DSH_HOME}/storages/memory-search/index.db`。切换路径会先关闭旧库并 checkpoint，把主库与 `-wal`/`-shm` 复制到新位置，打开并核对文档数一致后再写入 location.json、删除旧文件。空库仍走启动重建；已有库走 reconcile，不另建一份。

标题仅在 RPC 返回前调用 `readTitleSnapshots` 升级并做短期内存缓存，不写数据库。Client 按 session 分组结果，通过 anchor key 打开目标消息；不可定位事件仍展示为静态命中。

## 10. 运维升级门槛

当前采用单文件 SQLite，因为默认 1 GiB 上限、单用户、单写者场景下，它比多段 catalog 或 Rust 原生搜索引擎更易安装、恢复和升级。

只有指标稳定触发以下任一条件，才应在相同 `SearchIndex` 契约后原型化 Tantivy：

- 明确选择不限量且进入数百万级文档/数 GiB；
- 100 ms 候选预算长期无法满足相关性或 p95 目标；
- 产品需要 BM25、位置短语或 WAND/Block-Max WAND 动态剪枝。

在触发前硬上分段文件或原生引擎不是优化，而是把复杂性提前支付。
