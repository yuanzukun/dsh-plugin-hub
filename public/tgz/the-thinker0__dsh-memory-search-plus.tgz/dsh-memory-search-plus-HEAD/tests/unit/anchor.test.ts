/**
 * anchorKey 单元测试（契约见 tests/README.md「QA 测试契约」）。
 *
 * 锚点键公式（t2 契约，与 dsh-conversation-landmarks 客户端一致）：
 *  `${kind.length}:${kind}${id}` ：
 *  - user/message     → "13:input-message" + String(data.id)
 *  - assistant/message→ "14:assistant-step" + String(data.turn) + ":" + String(data.step)
 *  - tool/call        → "9:tool-call" + String(data.callId)
 *  - tool/result      → "9:tool-call" + String(data.message.source.callId)
 *  - 其余 → null（不可精确定位；此类事件仍可索引文本，客户端命中不跳转）
 */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { loadModule, notLoaded } from '../helpers/load-module';

const here = dirname(fileURLToPath(import.meta.url));
const cases: Array<{ name: string; event: any; expectedText: string; expectedAnchorKey: string | null }> = JSON.parse(
  readFileSync(join(here, '..', 'fixtures', 'event-cases.json'), 'utf8'),
);

const loaded = await loadModule(join(here, '..', '..', 'src', 'extract.ts'));

// 模块缺失 → 显式失败（不静默）：test-first 契约信号，实现落地后必须转绿
describe.skipIf(!notLoaded(loaded))('extract 模块缺失（anchorKeyFor 契约）：违反 QA 测试契约', () => {
  it('模块必须可加载', () => {
    throw new Error('src/extract.ts 未实现或不可加载（见 tests/README.md 契约）');
  });
});

describe.skipIf(notLoaded(loaded))('anchorKeyFor (src/extract.ts)', () => {
  it('导出 anchorKeyFor', () => {
    expect(typeof loaded.mod!.anchorKeyFor).toBe('function');
  });

  describe('四类事件公式逐例一致', () => {
    for (const c of cases) {
      it(`${c.name} → ${JSON.stringify(c.expectedAnchorKey)}`, () => {
        const fn = loaded.mod!.anchorKeyFor as (e: any) => string | null;
        expect(fn(c.event)).toBe(c.expectedAnchorKey);
      });
    }
  });

  it('精确公式值（与 dsh 客户端锚点格式一致）', () => {
    const fn = loaded.mod!.anchorKeyFor as (e: any) => string | null;
    expect(
      fn({ type: 'user/message', seq: 0, time: 1, data: { id: '5f7c-9e31', content: [] } }),
    ).toBe('13:input-message5f7c-9e31');
    expect(
      fn({ type: 'assistant/message', seq: 0, time: 1, data: { turn: 7, step: 2, message: { content: [] } } }),
    ).toBe('14:assistant-step7:2');
    expect(
      fn({ type: 'tool/call', seq: 0, time: 1, data: { callId: 'abc-def', name: 'x', arguments: '' } }),
    ).toBe('9:tool-callabc-def');
    expect(
      fn({ type: 'tool/result', seq: 0, time: 1, data: { message: { source: { callId: 'abc-def' }, content: [] } } }),
    ).toBe('9:tool-callabc-def');
  });

  it('L3：id/turn/step/callId/source.callId 缺失 → null（不生成 ...undefined 伪锚点）', () => {
    const fn = loaded.mod!.anchorKeyFor as (e: any) => string | null;
    expect(fn({ type: 'user/message', seq: 0, time: 1, data: { content: [] } })).toBeNull();
    expect(fn({ type: 'assistant/message', seq: 0, time: 1, data: { turn: 1 } })).toBeNull();
    expect(fn({ type: 'assistant/message', seq: 0, time: 1, data: { step: 2 } })).toBeNull();
    expect(fn({ type: 'tool/call', seq: 0, time: 1, data: { name: 'x', arguments: '' } })).toBeNull();
    expect(fn({ type: 'tool/result', seq: 0, time: 1, data: { message: { content: [] } } })).toBeNull();
    expect(fn({ type: 'tool/result', seq: 0, time: 1, data: { message: { source: {}, content: [] } } })).toBeNull();
  });

  it('不可定位事件返回 null（step/start、assistant/chunk、todo/write、turn/end、compaction、未知类型）', () => {
    const fn = loaded.mod!.anchorKeyFor as (e: any) => string | null;
    for (const ev of [
      { type: 'step/start', seq: 0, time: 1, data: {} },
      { type: 'assistant/chunk', seq: 0, time: 1, data: {} },
      { type: 'todo/write', seq: 0, time: 1, data: { todos: [] } },
      { type: 'turn/end', seq: 0, time: 1, data: { reason: { kind: 'completed' } } },
      { type: 'compaction', seq: 0, time: 1, data: {} },
      { type: 'some/future', seq: 0, time: 1, data: {} },
    ]) {
      expect(fn(ev), ev.type).toBeNull();
    }
  });
});
