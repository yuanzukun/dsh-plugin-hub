/**
 * tokenizer 单元测试（契约见 tests/README.md「QA 测试契约」）。
 *
 * 规则断言（与 t2 契约一致）：
 *  - 中文：CJK 单字 + 相邻二元组；Segmenter('zh') 词（被二元组/单字规则覆盖）
 *  - 英文/数字：\p{L}+|\p{N}+ 切分，ASCII 一律小写
 *  - 输出 token 不得含标点/FTS 元字符（* / ^ : ( ) " 等），不得重复
 *  - 空串/纯空白 → []
 *  - buildFtsQuery：每个 token 双引号包裹、空格连接（隐式 AND）、引号外无运算符
 */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { loadModule, notLoaded, hasExport } from '../helpers/load-module';

const here = dirname(fileURLToPath(import.meta.url));
const cases: Array<{ input: string; expectTokens: string[]; expectEmpty: boolean }> = JSON.parse(
  readFileSync(join(here, '..', 'fixtures', 'tokenizer-cases.json'), 'utf8'),
);

const loaded = await loadModule(join(here, '..', '..', 'src', 'tokenizer.ts'));

// 模块缺失 → 显式失败（不静默）：test-first 契约信号，实现落地后必须转绿
describe.skipIf(!notLoaded(loaded))('tokenizer 模块缺失：违反 QA 测试契约', () => {
  it('模块必须可加载', () => {
    throw new Error('src/tokenizer.ts 未实现或不可加载（见 tests/README.md 契约）');
  });
});

const TOKEN_RE = /^[\p{L}\p{N}]+$/u;

describe.skipIf(notLoaded(loaded))('tokenizer (src/tokenizer.ts)', () => {
  it('导出 tokenize', () => {
    expect(typeof loaded.mod!.tokenize).toBe('function');
  });

  describe('tokenize 规则', () => {
    for (const c of cases) {
      it(`tokenize(${JSON.stringify(c.input)})`, () => {
        const fn = loaded.mod!.tokenize as (s: string) => string[];
        const tokens = fn(c.input);
        expect(Array.isArray(tokens)).toBe(true);
        if (c.expectEmpty) {
          expect(tokens).toEqual([]);
          return;
        }
        // 1. 必须包含契约要求的全部 token
        for (const t of c.expectTokens) {
          expect(tokens, `缺少 token ${JSON.stringify(t)}`).toContain(t);
        }
        // 2. 每个 token 只含字母/数字（无标点、无空白、无 FTS 元字符）
        const seen = new Set<string>();
        for (const tok of tokens) {
          expect(tok, `非法 token ${JSON.stringify(tok)}`).toMatch(TOKEN_RE);
          // 3. ASCII token 必须小写（大小写规范化）
          if (/^[A-Za-z0-9]+$/.test(tok)) {
            expect(tok, `token 未小写化: ${tok}`).toBe(tok.toLowerCase());
          }
          // 4. 不重复
          expect(seen.has(tok), `重复 token ${tok}`).toBe(false);
          seen.add(tok);
        }
        // 5. 输入中的每个字母数字字符都贡献了一个 token（无信息丢失）
        const chars = [...c.input].filter((ch) => /[\p{L}\p{N}]/u.test(ch));
        if (chars.length === 1) expect(tokens.length).toBeGreaterThanOrEqual(1);
      });
    }
  });

  it('tokenize 不抛异常且容错（非字符串入参不强制）', () => {
    const fn = loaded.mod!.tokenize as (s: string) => string[];
    expect(() => fn('')).not.toThrow();
    expect(() => fn('   \t\n ')).not.toThrow();
  });

  describe('buildFtsQuery（二段式搜索阶段 1 查询构造）', () => {
    const has = hasExport(loaded, 'buildFtsQuery');

    // 缺失时显式失败（合约必须导出），不能静默通过
    it.skipIf(has)('buildFtsQuery 缺失：违反 QA 测试契约', () => {
      throw new Error('tokenizer.ts 未导出 buildFtsQuery（见 tests/README.md 契约）');
    });

    describe.skipIf(!has)('导出时行为', () => {
      // 惰性访问：收集阶段不解析（模块可能缺失，套件已被 skip）
      const fts = (s: string) => (loaded.mod as any).buildFtsQuery(s);
      const tok = (s: string) => (loaded.mod as any).tokenize(s);

      it('每 token 双引号包裹、空格连接，引号外无运算符', () => {
        for (const input of ['聊天记录', 'Chat History 搜索', 'a*b/(c^d):"e"', 'Hello, World!']) {
          const q = fts(input);
          expect(typeof q).toBe('string');
          const outside = q.replace(/"([^"]*)"/g, '').replace(/\s/g, '');
          expect(outside, `引号外内容: ${JSON.stringify(q)}`).toBe('');
        }
      });

      it('≥2 字符的 token 全部进入查询（单字元允许实现取舍）', () => {
        for (const input of ['聊天记录', 'Hello World', '查找聊天记录']) {
          const q = fts(input);
          const quoted = new Set<string>();
          for (const m of q.matchAll(/"([^"]*)"/g)) quoted.add(m[1]);
          for (const t of tok(input)) {
            if (t.length >= 2) expect(quoted.has(t), `查询缺少 token ${t}: ${q}`).toBe(true);
          }
        }
      });

      it('空输入不抛异常', () => {
        expect(() => fts('')).not.toThrow();
      });
    });
  });

  it('超长输入只对前缀分词，尾部独有英文不会进入 token', () => {
    const tok = (s: string) => (loaded.mod as any).tokenize(s);
    const uniqueTail = 'uniquetailxyz';
    const tokens = tok('测'.repeat(12_000) + uniqueTail);
    expect(tokens).not.toContain(uniqueTail);
    expect(tokens).toContain('测');
    expect(tokens).toContain('测测');
  });
});
