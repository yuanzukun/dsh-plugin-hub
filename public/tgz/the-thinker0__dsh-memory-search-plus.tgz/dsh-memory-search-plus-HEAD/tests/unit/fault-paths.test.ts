/**
 * 故障路径回归测试（评审修复）：
 *  - busy_timeout 必须在 PRAGMA 序列中（多进程并发防护）；
 *  - 瞬时 SQLITE_BUSY/LOCKED 不得触发"坏库备份改名"，只降级内存索引；
 *  - legacy 分钟桶超限（>65536 条/分钟）不再抛错误杀健康库，而是原地空库重建；
 *  - rowid 分配器在整桶占满时向外溢出相邻分钟桶而不是写入失败；
 *  - 内存降级索引与文件索引共用同一逻辑预算（最旧淘汰），防止宿主 OOM。
 */
import { describe, it, expect } from 'vitest'
import { mkdtempSync, readdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { loadModule, notLoaded } from '../helpers/load-module'

const here = dirname(fileURLToPath(import.meta.url))
const indexerMod = await loadModule(join(here, '..', '..', 'src', 'indexer.ts'))
const sqliteMod = await import('node:sqlite').catch(() => null)

describe.skipIf(notLoaded(indexerMod))('故障路径：rowid 分配与错误分类（纯函数）', () => {
  const mod = indexerMod.mod as Record<string, any>
  const probeChronologicalRowid = mod.probeChronologicalRowid as (
    isFree: (rowid: number) => boolean,
    time: number,
    spillBuckets?: number,
  ) => number
  const isTransientSqliteError = mod.isTransientSqliteError as (error: unknown) => boolean

  const TIME_BUCKET_MS = 60_000
  const SCALE = 65_536

  it('瞬时锁错误被识别，普通损坏不被识别', () => {
    const busy = Object.assign(new Error('database is locked'), { code: 'SQLITE_BUSY' })
    expect(isTransientSqliteError(busy)).toBe(true)
    expect(isTransientSqliteError(new Error('database table is locked'))).toBe(true)
    expect(isTransientSqliteError(new Error('file is not a database'))).toBe(false)
    expect(isTransientSqliteError(null)).toBe(false)
  })

  it('磁盘满/权限错误视为非损坏，损坏文件不视为环境限制', () => {
    const isNonCorruptOpenError = mod.isNonCorruptOpenError as (error: unknown) => boolean
    expect(isNonCorruptOpenError(Object.assign(new Error('database or disk is full'), { code: 'SQLITE_FULL' }))).toBe(true)
    expect(isNonCorruptOpenError(Object.assign(new Error('permission denied'), { code: 'EACCES' }))).toBe(true)
    expect(isNonCorruptOpenError(new Error('file is not a database'))).toBe(false)
  })

  it('rowid 分配：正常落在分钟桶内', () => {
    const t = Date.parse('2026-01-01T00:00:00Z')
    const homeBucket = Math.floor(t / TIME_BUCKET_MS)
    const rowid = probeChronologicalRowid(() => true, t)
    expect(rowid).toBeGreaterThanOrEqual(homeBucket * SCALE)
    expect(rowid).toBeLessThan((homeBucket + 1) * SCALE)
  })

  it('rowid 分配：整桶占满时溢出到相邻分钟桶而不是抛错', () => {
    const t = Date.parse('2026-01-01T00:00:00Z')
    const homeBucket = Math.floor(t / TIME_BUCKET_MS)
    const low = homeBucket * SCALE
    // 主桶全部占用 → 应落到 home+1 桶
    const next = probeChronologicalRowid((r) => r < low || r > low + SCALE - 1, t)
    expect(next).toBeGreaterThanOrEqual((homeBucket + 1) * SCALE)
    expect(next).toBeLessThan((homeBucket + 2) * SCALE)
    // 主桶和右邻都满（谓词为"占用"，需取反传入）→ 左邻兜底（时间近似仍保持）
    const bothFull = (r: number): boolean => r >= low && r <= (homeBucket + 2) * SCALE - 1
    const prev = probeChronologicalRowid((r) => !bothFull(r), t)
    expect(prev).toBeLessThan(low)
  })
})

describe.skipIf(sqliteMod === null)('故障路径：真实 node:sqlite（busy/迁移拥挤/内存预算）', () => {
  const mod = indexerMod.mod as Record<string, any>
  const createSearchIndex = mod.createSearchIndex as (options?: unknown) => any
  const DatabaseSync = (sqliteMod as typeof import('node:sqlite')).DatabaseSync
  const SCALE = 65_536

  function makeWarn(): { warnings: string[]; warn: (msg: string) => void } {
    const warnings: string[] = []
    return { warnings, warn: (msg: string) => warnings.push(msg) }
  }

  it('PRAGMA 序列包含 busy_timeout=3000', () => {
    const execs: string[] = []
    class Wrapped extends DatabaseSync {
      exec(sql: string): void {
        execs.push(sql)
        super.exec(sql)
      }
    }
    const idx = createSearchIndex({ dbPath: ':memory:', sqliteModule: Wrapped })
    try {
      expect(idx.ready).toBe(true)
      expect(execs.some((sql) => sql.toLowerCase().includes('busy_timeout'))).toBe(true)
    } finally {
      idx.close()
    }
  })

  it('打开遇到 SQLITE_BUSY：不备份改名，降级内存索引', () => {
    const dir = mkdtempSync(join(tmpdir(), 'ms-busy-'))
    const dbPath = join(dir, 'index.db')
    class LockedDb {
      constructor() {
        throw Object.assign(new Error('database is locked'), { code: 'SQLITE_BUSY' })
      }
    }
    const { warnings, warn } = makeWarn()
    const idx = createSearchIndex({
      dbPath,
      sqliteModule: LockedDb,
      warn,
      maxIndexBytes: 1 << 20,
    })
    try {
      expect(idx.ready).toBe(true)
      expect(idx.degraded).toBe(true)
      expect(readdirSync(dir).filter((n) => n.startsWith('index.db.bak-'))).toHaveLength(0)
      expect(warnings.some((m) => m.includes('瞬时锁冲突'))).toBe(true)
    } finally {
      idx.close()
    }
  })

  it('打开遇到磁盘满：不备份改名，降级内存索引', () => {
    const dir = mkdtempSync(join(tmpdir(), 'ms-full-'))
    const dbPath = join(dir, 'index.db')
    class FullDiskDb {
      constructor() {
        throw Object.assign(new Error('database or disk is full'), { code: 'SQLITE_FULL' })
      }
    }
    const { warnings, warn } = makeWarn()
    const idx = createSearchIndex({
      dbPath,
      sqliteModule: FullDiskDb,
      warn,
      maxIndexBytes: 1 << 20,
    })
    try {
      expect(idx.degraded).toBe(true)
      expect(readdirSync(dir).filter((n) => n.startsWith('index.db.bak-'))).toHaveLength(0)
      expect(warnings.some((m) => m.includes('环境限制') || m.includes('disk is full'))).toBe(true)
    } finally {
      idx.close()
    }
  })

  it('legacy 单分钟超过 65536 条：原地空库重建，不误判坏库', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'ms-crowd-'))
    const dbPath = join(dir, 'index.db')
    const seed = new DatabaseSync(dbPath)
    try {
      seed.exec(
        'CREATE VIRTUAL TABLE ftsevents USING fts5(' +
          'tokens, text, session_id, seq, type, time, surface, anchor_key)',
      )
      const rows = SCALE + 16
      seed.exec(
        'INSERT INTO ftsevents(tokens,text,session_id,seq,type,time,surface,anchor_key) ' +
          `WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM c WHERE x < ${rows}) ` +
          "SELECT 'tok','body','legacy-session',x,'user/message',60000,'current',NULL FROM c",
      )
    } finally {
      seed.close()
    }
    const idx = createSearchIndex({ dbPath })
    try {
      const status = idx.status()
      expect(idx.ready).toBe(true)
      expect(idx.degraded).toBe(false)
      expect(status.indexedDocs).toBe(0)
      expect(readdirSync(dir).filter((n) => n.startsWith('index.db.bak-'))).toHaveLength(0)
      // 收敛性：空库重建后可继续增量写入并被搜到
      idx.upsertRecords([
        {
          sessionId: 's1',
          seq: 0,
          type: 'user/message',
          time: 60001,
          surface: 'current',
          anchorKey: null,
          text: 'hello crowded world',
        },
      ])
      expect(idx.search('crowded').hits.length).toBe(1)
    } finally {
      idx.close()
    }
  })

  it('legacy 0 分钟与 1 分钟合并进同一 rowid 桶时不 UNIQUE 冲突、不改名备份', () => {
    const dir = mkdtempSync(join(tmpdir(), 'ms-bucket0-'))
    const dbPath = join(dir, 'index.db')
    const seed = new DatabaseSync(dbPath)
    try {
      seed.exec(
        'CREATE VIRTUAL TABLE ftsevents USING fts5(' +
          'tokens, text, session_id, seq, type, time, surface, anchor_key)',
      )
      seed.exec(
        'INSERT INTO ftsevents(tokens,text,session_id,seq,type,time,surface,anchor_key) VALUES ' +
          "('alpha','alpha','s',1,'user/message',1000,'current',NULL)," +
          "('bravo','bravo','s',2,'user/message',60000,'current',NULL)",
      )
    } finally {
      seed.close()
    }
    const idx = createSearchIndex({ dbPath })
    try {
      expect(idx.degraded).toBe(false)
      expect(idx.status().indexedDocs).toBe(2)
      expect(readdirSync(dir).filter((n) => n.startsWith('index.db.bak-'))).toHaveLength(0)
      expect(idx.search('alpha').hits.length).toBe(1)
      expect(idx.search('bravo').hits.length).toBe(1)
    } finally {
      idx.close()
    }
  })

  it('同一秒大量事件不再导致写入失败（溢出到相邻桶）', () => {
    const dir = mkdtempSync(join(tmpdir(), 'ms-spill-'))
    const dbPath = join(dir, 'index.db')
    const idx = createSearchIndex({ dbPath })
    try {
      const burst = 900
      const records = Array.from({ length: burst }, (_, i) => ({
        sessionId: 'burst',
        seq: i,
        type: 'tool/result',
        time: 1000, // 全部挤进 bucket 1 的病态时间分布
        surface: 'current',
        anchorKey: null,
        text: `burst-${i}`,
      }))
      expect(() => idx.upsertRecords(records)).not.toThrow()
      expect(idx.status().indexedDocs).toBe(burst)
    } finally {
      idx.close()
    }
  })

  it('内存降级索引执行逻辑预算：最旧淘汰、最新可搜', () => {
    const { warnings, warn } = makeWarn()
    const idx = createSearchIndex({
      dbPath: ':memory:',
      sqliteModule: null,
      warn,
      maxIndexBytes: 4000,
    })
    try {
      const records = Array.from({ length: 60 }, (_, i) => ({
        sessionId: 's',
        seq: i,
        type: 'user/message',
        time: 1000 + i,
        surface: 'current',
        anchorKey: null,
        text: 'x'.repeat(300) + ` tail-${i}`,
      }))
      idx.upsertRecords(records)
      const status = idx.status()
      expect(status.storageLimitBytes).toBe(4000)
      expect(status.prunedDocs).toBeGreaterThan(0)
      expect(status.indexedDocs).toBeLessThan(60)
      expect(status.coverageSince).not.toBeNull()
      expect(status.storageBytes as number).toBeLessThanOrEqual(4000)
      expect(idx.search('tail-59').hits.length).toBe(1)
      expect(idx.search('tail-0').hits.length).toBe(0)
      expect(warnings.some((m) => m.includes('已淘汰'))).toBe(true)
    } finally {
      idx.close()
    }
  })

  it('内存降级整会话重建会扣回旧字节，不虚高预算', () => {
    const idx = createSearchIndex({
      dbPath: ':memory:',
      sqliteModule: null,
      warn: () => {},
      maxIndexBytes: 80_000,
    })
    try {
      const bulky = Array.from({ length: 20 }, (_, i) => ({
        sessionId: 's',
        seq: i,
        type: 'user/message',
        time: 1000 + i,
        surface: 'current' as const,
        anchorKey: null,
        text: 'y'.repeat(400) + ` old-${i}`,
      }))
      idx.upsertRecords(bulky)
      const before = idx.status().storageBytes as number
      idx.upsertRecords(
        [{
          sessionId: 's',
          seq: 0,
          type: 'user/message',
          time: 2000,
          surface: 'current',
          anchorKey: null,
          text: 'only-new-row',
        }],
        ['s'],
      )
      const after = idx.status().storageBytes as number
      expect(after).toBeLessThan(before)
      expect(idx.status().indexedDocs).toBe(1)
      expect(idx.search('only-new-row').hits.length).toBe(1)
      expect(idx.search('old-0').hits.length).toBe(0)
    } finally {
      idx.close()
    }
  })
})