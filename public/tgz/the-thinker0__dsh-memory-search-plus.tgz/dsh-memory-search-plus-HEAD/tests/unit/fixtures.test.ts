/**
 * Fixture integrity tests — always run, no implementation dependency.
 *
 * 夹具由 /tmp/gen-fixtures.mjs 生成，并对每个事件调用 dsh 真实实现
 * (dsh-session-query.extractSessionEventText / dsh-session.foldSurface)
 * 验证后落盘。本文件确保：
 *  1. fixtures 本身结构合法（seq 连续、surface 值合法、records 与 events 一一对应）
 *  2. 期表与 dsh 语义一致（records.text 非空、surface 分类覆盖 current/shadowed/log-only）
 *  3. 夹具内容是测试的可靠 ground truth
 */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const fx = (name: string) => JSON.parse(readFileSync(join(here, '..', 'fixtures', name), 'utf8'));

const SURFACE_VALUES = new Set(['current', 'shadowed', 'log-only']);
const SURFACE_ELIGIBLE = new Set(['user/message', 'assistant/message', 'tool/result']);
const ANCHORED_TYPES = new Set(['user/message', 'assistant/message', 'tool/call', 'tool/result']);

function assertSessionShape(session: any) {
  it(`session ${session.sessionId} 头与事件结构合法`, () => {
    expect(session.session.type).toBe('session');
    expect(session.session.id).toBe(session.sessionId);
    const events = session.events;
    // seq 从 0 连续编号（与解压后的 session.jsonl.zstd 一致：events[i].seq === i）
    events.forEach((e: any, i: number) => {
      expect(e.seq, `seq index ${i}`).toBe(i);
      expect(typeof e.type).toBe('string');
      expect(typeof e.time).toBe('number');
    });
    // surface 事件必须带 surfaceOp；非 surface 事件不得带
    events.forEach((e: any) => {
      if (SURFACE_ELIGIBLE.has(e.type)) {
        expect(e.surfaceOp, `${e.type} seq=${e.seq} 需要 surfaceOp`).toBeDefined();
      } else {
        expect(e.surfaceOp, `${e.type} seq=${e.seq} 不应带 surfaceOp`).toBeUndefined();
      }
    });
  });

  it(`session ${session.sessionId} records 与 events 一致`, () => {
    const bySeq = new Map(session.events.map((e: any) => [e.seq, e]));
    const seen = new Set<number>();
    for (const r of session.records) {
      expect(SURFACE_VALUES.has(r.surface), `surface=${r.surface}`).toBe(true);
      expect(r.text.length).toBeGreaterThan(0); // 空文本事件不应入索引
      expect(typeof r.sessionId).toBe('string');
      expect(bySeq.has(r.seq), `seq ${r.seq} 无对应事件`).toBe(true);
      expect(seen.has(r.seq), `seq ${r.seq} 重复`).toBe(false);
      seen.add(r.seq);
    }
    // 非空文本的事件必须全部入 records（用精简判断：type 属于可抽取类型时）
    for (const e of session.events) {
      const extractable =
        e.type === 'user/message' ||
        e.type === 'assistant/message' ||
        e.type === 'tool/call' ||
        e.type === 'tool/result' ||
        e.type === 'todo/write' ||
        e.type === 'turn/end';
      if (extractable) {
        // 只要该事件有实质内容（用户/助手消息内容非空等），必须被索引
        const hasContent =
          (e.type === 'user/message' && Array.isArray(e.data?.content) && e.data.content.some((b: any) => b?.type === 'text' && b.text.trim() !== '')) ||
          (e.type === 'assistant/message' && Array.isArray(e.data?.message?.content) && e.data.message.content.some((b: any) => b?.type === 'text' && b.text.trim() !== '')) ||
          e.type === 'tool/call' ||
          e.type === 'tool/result' ||
          e.type === 'todo/write';
        if (hasContent) expect(seen.has(e.seq), `seq ${e.seq}(${e.type}) 应被索引但缺失`).toBe(true);
      }
    }
    // records 按 seq 升序（时间降序搜索依赖 seq/time 语义一致）
    const seqs = session.records.map((r: any) => r.seq);
    expect([...seqs].sort((a: number, b: number) => a - b)).toEqual(seqs);
  });

  it(`session ${session.sessionId} anchorKey 覆盖四类索引事件`, () => {
    for (const r of session.records) {
      if (ANCHORED_TYPES.has(r.type)) {
        expect(typeof r.anchorKey, `seq ${r.seq} ${r.type} 应有 anchorKey`).toBe('string');
      } else {
        expect(r.anchorKey, `seq ${r.seq} ${r.type} 应为 null anchorKey`).toBeNull();
      }
    }
  });
}

describe('fixtures/session-basic.json', () => {
  const session = fx('session-basic.json');
  assertSessionShape(session);

  it('包含真实会话充分覆盖（turn/tool/todo/error/中英混合）', () => {
    expect(session.session.type).toBe('session'); // 会话头（不在 events 数组内）
    const types = new Set(session.events.map((e: any) => e.type));
    for (const t of ['user/message', 'assistant/message', 'tool/call', 'tool/result', 'todo/write', 'turn/end', 'turn/start', 'step/start', 'assistant/chunk', 'session/title', 'request/header']) {
      expect(types.has(t), `缺少类型 ${t}`).toBe(true);
    }
    // 中英混合文本存在（搜索用例）
    const allText = session.records.map((r: any) => r.text).join('\n');
    expect(allText).toContain('查找聊天记录');
    expect(allText).toMatch(/[Cc]hat [Hh]istory/);
  });

  it('surface 期望：全部 current（无压缩替换）', () => {
    const surfaces = new Set(session.records.map((r: any) => r.surface));
    expect(surfaces.has('current')).toBe(true);
    expect(surfaces.has('shadowed')).toBe(false);
  });
});

describe('fixtures/session-compaction.json', () => {
  const session = fx('session-compaction.json');
  assertSessionShape(session);

  it('存在压缩检查点（user/message + source.plugin=compact）', () => {
    const cp = session.events.find(
      (e: any) => e.type === 'user/message' && e.data?.source?.kind === 'plugin' && e.data?.source?.plugin === 'compact',
    );
    expect(cp).toBeDefined();
    expect(cp.surfaceOp).toMatchObject({ op: 'replace' });
  });

  it('surface 期望：替换后旧节点 shadowed、检查点与后续 current', () => {
    const surfaces = session.records.map((r: any) => `${r.seq}:${r.surface}`);
    expect(surfaces).toContain('2:shadowed');
    expect(surfaces).toContain('9:shadowed');
    expect(surfaces).toContain('12:current');
    expect(surfaces).toContain('13:current');
    // 检查点事件本身入索引（含摘要文本）
    const cpRec = session.records.find((r: any) => r.type === 'user/message' && r.text.includes('Compacted'));
    expect(cpRec).toBeDefined();
  });
});

describe('fixtures/event-cases.json', () => {
  const cases = fx('event-cases.json');
  it('覆盖要求的全部事件抽取分支', () => {
    const names = cases.map((c: any) => c.name);
    for (const n of [
      'user-text', 'user-empty', 'user-whitespace',
      'assistant-text', 'assistant-reasoning-skipped', 'assistant-mixed-blocks', 'assistant-tool-call-block',
      'tool-call', 'tool-result-ok', 'tool-result-error', 'tool-result-nested',
      'todo-write',
      'turn-end-completed', 'turn-end-error', 'turn-end-aborted', 'turn-end-max-tokens', 'turn-end-interrupted',
      'step-start', 'turn-start', 'assistant-chunk', 'session-title', 'request-header', 'unknown-type', 'compaction-event',
    ]) {
      expect(names.includes(n), `缺少用例 ${n}`).toBe(true);
    }
  });
  it('每个用例有 expectedText / expectedAnchorKey 字段', () => {
    for (const c of cases) {
      expect(typeof c.expectedText, c.name).toBe('string');
      expect('expectedAnchorKey' in c, c.name).toBe(true);
    }
  });
});

describe('fixtures/tokenizer-cases.json', () => {
  const cases = fx('tokenizer-cases.json');
  it('覆盖要求的分词场景', () => {
    const inputs = cases.map((c: any) => c.input);
    for (const s of ['查找聊天记录', 'Chat History 搜索', 'Hello, World!', '', 'a*b/(c^d):"e"', '中文English混合123', 'Hello 世界 hello WORLD']) {
      expect(inputs.includes(s), `缺少分词输入 ${JSON.stringify(s)}`).toBe(true);
    }
  });
  it('每个用例含 expectTokens / expectEmpty', () => {
    for (const c of cases) {
      expect(Array.isArray(c.expectTokens), c.input).toBe(true);
      expect(typeof c.expectEmpty, c.input).toBe('boolean');
      expect(c.expectEmpty === (c.expectTokens.length === 0), c.input).toBe(true);
    }
  });
});
