/**
 * 会话跳转：冷打开时 binding 先出现、历史窗口后就绪。
 * 空 chat + hasMore=false 不能立刻当成「已被压缩」。
 */
import { describe, it, expect } from 'vitest'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { loadModule, notLoaded } from '../helpers/load-module'

const here = dirname(fileURLToPath(import.meta.url))
const loaded = await loadModule(join(here, '..', '..', 'src', 'client', 'jump.tsx'))

describe.skipIf(notLoaded(loaded))('jump hydration (src/client/jump.tsx)', () => {
  const waitForHydratedSession = loaded.mod!.waitForHydratedSession as (
    session: { getSnapshot(): unknown; loadOlder(): Promise<void> },
    timeoutMs?: number,
  ) => Promise<boolean>
  const pageToAnchor = loaded.mod!.pageToAnchor as (
    session: { getSnapshot(): unknown; loadOlder(): Promise<void> },
    anchorKey: string,
  ) => Promise<boolean>

  it('loading 空快照等到 open 才算就绪', async () => {
    const nodes = new Map<string, object>()
    const face = {
      openState: 'loading' as string,
      getSnapshot() {
        return {
          chat: { nodes, order: this.openState === 'open' ? ['13:input-messageu1'] : [] },
          hasMore: false,
          loadingOlder: false,
          openState: this.openState,
        }
      },
      async loadOlder() {},
    }
    setTimeout(() => {
      face.openState = 'open'
      nodes.set('13:input-messageu1', {})
    }, 40)
    expect(await waitForHydratedSession(face, 800)).toBe(true)
    expect(await pageToAnchor(face, '13:input-messageu1')).toBe(true)
  })

  it('open 后锚点不在且没有更早页 → paging 失败（真压缩）', async () => {
    const face = {
      getSnapshot() {
        return {
          chat: { nodes: new Map([['other', {}]]), order: ['other'] },
          hasMore: false,
          loadingOlder: false,
          openState: 'open',
        }
      },
      async loadOlder() {},
    }
    expect(await waitForHydratedSession(face, 200)).toBe(true)
    expect(await pageToAnchor(face, '13:input-messageu1')).toBe(false)
  })

  it('hasMore 时会 loadOlder 直到锚点出现', async () => {
    const nodes = new Map<string, object>([['tail', {}]])
    let hasMore = true
    const face = {
      getSnapshot() {
        return {
          chat: { nodes, order: [...nodes.keys()] },
          hasMore,
          loadingOlder: false,
          openState: 'open',
        }
      },
      async loadOlder() {
        hasMore = false
        nodes.set('13:input-messageu1', {})
      },
    }
    expect(await pageToAnchor(face, '13:input-messageu1')).toBe(true)
  })
})
