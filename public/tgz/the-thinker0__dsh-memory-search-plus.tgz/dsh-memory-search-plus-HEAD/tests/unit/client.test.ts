/**
 * Client 纯函数单测（README 契约 §Client 纯函数；client-eng t3 提供，语义以
 * 当前 src/client 实现为准并已锁定）：
 *  - roleOf(hit)：role（空则回退 type）小写后 user/assistant/tool 前缀 → 对应，其余 'other'
 *  - groupHits(hits)：按 sessionId 分组；组序 = 组内 max time DESC，tie 按 sessionId 升序；组内保持全局顺序
 *  - shiftSpans(spans, base, length)：[max(0,s-base), min(length,e-base)]，end≤start 丢弃
 *  - mergeRanges(ranges)：倒置归一 → 排序 → 重叠/相邻合并
 *  - snippetView(hit)：spans∈text；窗口 = 首 span ±120（含尾 span）切片 text，spans 平移到窗口
 *  - normalizeSearch(payload)：ok=false→error；null/空 anchorKey 保留（''）；sessionId==='' 丢弃；span 畸形过滤
 *  - normalizeStatus(payload)：ok=false→error；degraded→degraded；building→indexing；ready→ready；
 *    ready=false 且非 degraded → indexing（“索引初始化中”）
 */
import { describe, it, expect } from 'vitest';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { loadModule, notLoaded } from '../helpers/load-module';

const here = dirname(fileURLToPath(import.meta.url));

const panelMod = await loadModule(join(here, '..', '..', 'src', 'client', 'panel.tsx'));
const rpcMod = await loadModule(join(here, '..', '..', 'src', 'client', 'rpc.tsx'));
const clientMod = await loadModule(join(here, '..', '..', 'src', 'client.tsx'));
const missing = notLoaded(panelMod) || notLoaded(rpcMod);

describe.skipIf(!missing)('client 纯函数模块缺失：违反 QA 测试契约', () => {
  it('模块必须可加载', () => {
    throw new Error(`src/client/panel.tsx 或 src/client/rpc.tsx 未实现或不可加载\n  panel: ${panelMod.error}\n  rpc: ${rpcMod.error}`);
  });
});

const roleOf = (h: any) => (panelMod.mod as any).roleOf(h);
const groupHits = (h: any) => (panelMod.mod as any).groupHits(h);
const shiftSpans = (s: any, b: number, l: number) => (panelMod.mod as any).shiftSpans(s, b, l);
const mergeRanges = (r: any) => (panelMod.mod as any).mergeRanges(r);
const snippetView = (h: any) => (panelMod.mod as any).snippetView(h);
const clampOverlayPosition = (l: number, t: number, w: number, h: number, vw: number, vh: number, m?: number) =>
  (panelMod.mod as any).clampOverlayPosition(l, t, w, h, vw, vh, m);
const normalizeSearch = (p: any) => (rpcMod.mod as any).normalizeSearch(p);
const normalizeStatus = (p: any) => (rpcMod.mod as any).normalizeStatus(p);
const callRemote = (r: any, m: string, a?: unknown) => (rpcMod.mod as any).callRemote(r, m, a);
const unwrapRemotePayload = (p: any) => (rpcMod.mod as any).unwrapRemotePayload(p);

describe.skipIf(missing)('client 纯函数 (src/client)', () => {
  describe('roleOf', () => {
    it('role 前缀映射', () => {
      expect(roleOf({ role: 'user' })).toBe('user');
      expect(roleOf({ role: 'assistant' })).toBe('assistant');
      expect(roleOf({ role: 'tool/call' })).toBe('tool');
    });
    it('role 为空回退 type；未知角色归 other', () => {
      expect(roleOf({ role: '', type: 'user/message' })).toBe('user');
      expect(roleOf({ role: '', type: 'assistant/message' })).toBe('assistant');
      expect(roleOf({ role: '', type: 'tool/call' })).toBe('tool');
      expect(roleOf({ role: 'weird-role' })).toBe('other');
    });
  });

  describe('groupHits', () => {
    const hit = (sessionId: string, seq: number, time: number) => ({ sessionId, seq, time, sessionTitle: 't' });
    it('非连续会话命中聚合为一组，组按 max time DESC、tie 按 sessionId 升序', () => {
      // 输入为全局时间降序（宿主返回序）；会话命中非连续
      const groups = groupHits([
        hit('sB', 3, 300), hit('sB', 1, 100), hit('sA', 4, 95), hit('sA', 2, 90),
      ]);
      expect(groups.map((g: any) => g.sessionId)).toEqual(['sB', 'sA']);
      expect(groups[0].time).toBe(300);
      expect(groups[1].time).toBe(95);
      // 组内保持全局（时间降序）扫描顺序
      expect(groups[0].items.map((i: any) => i.seq)).toEqual([3, 1]);
      expect(groups[1].items.map((i: any) => i.seq)).toEqual([4, 2]);
    });
    it('tie 时间按 sessionId 升序', () => {
      const groups = groupHits([hit('sB', 1, 50), hit('sA', 2, 50)]);
      expect(groups.map((g: any) => g.sessionId)).toEqual(['sA', 'sB']);
    });
    it('空输入', () => expect(groupHits([])).toEqual([]));
  });

  describe('shiftSpans（text 相对 → window 相对）', () => {
    it('基本平移', () => expect(shiftSpans([[2, 6]], 2, 10)).toEqual([[0, 4]]));
    it('窗口左侧越界裁剪/丢弃', () => {
      expect(shiftSpans([[0, 3]], 5, 12)).toEqual([]); // end<=start
      expect(shiftSpans([[0, 2], [5, 7]], 3, 4)).toEqual([[2, 4]]);
    });
    it('右侧按窗口长度截断', () => expect(shiftSpans([[8, 10]], 5, 4)).toEqual([[3, 4]]));
  });

  describe('mergeRanges', () => {
    it('空输入', () => expect(mergeRanges([])).toEqual([]));
    it('倒置归一', () => expect(mergeRanges([[3, 1]])).toEqual([[1, 3]]));
    it('重叠合并', () => expect(mergeRanges([[0, 3], [2, 5]])).toEqual([[0, 5]]));
    it('相邻合并', () => expect(mergeRanges([[0, 2], [2, 5]])).toEqual([[0, 5]]));
    it('乱序排序', () => expect(mergeRanges([[5, 7], [0, 2]])).toEqual([[0, 2], [5, 7]]));
    it('包含合并', () => expect(mergeRanges([[0, 5], [2, 3]])).toEqual([[0, 5]]));
  });

  describe('clampOverlayPosition', () => {
    it('在视口内不改', () => {
      expect(clampOverlayPosition(40, 50, 200, 100, 800, 600)).toEqual({ left: 40, top: 50 });
    });
    it('越出右下角钳回', () => {
      expect(clampOverlayPosition(700, 550, 200, 100, 800, 600)).toEqual({ left: 592, top: 492 });
    });
    it('越出左上角钳到边距', () => {
      expect(clampOverlayPosition(-20, -10, 200, 100, 800, 600)).toEqual({ left: 8, top: 8 });
    });
  });

  describe('snippetView（spans=text 相对；窗口=首 span ±120）', () => {
    const base = { sessionId: 's', sessionTitle: 't', seq: 1, type: 'user/message', role: 'user', time: 1, anchorKey: 'k', text: '', snippet: '', spans: [], matchCount: 1 };
    it('短文本：整段返回，spans 不变', () => {
      const r = snippetView({ ...base, text: '请帮我查找聊天记录。', snippet: '请帮我', spans: [[5, 9]] });
      expect(r.text).toBe('请帮我查找聊天记录。');
      expect(r.spans).toEqual([[5, 9]]);
    });
    it('长文本：首 span±120 窗口，spans 平移到窗口并指向同一子串', () => {
      const text = '前'.repeat(200) + '关键词XYZ出现处' + '后'.repeat(200);
      const first = 200; // 关键词起点（'前'*200 之后）
      const r = snippetView({ ...base, text, snippet: '', spans: [[first, first + 3]] });
      expect(r.text.length).toBeLessThan(text.length);
      expect(r.text.length).toBeLessThanOrEqual(240 + 9);
      expect(r.text.slice(r.spans[0][0], r.spans[0][1])).toBe('关键词');
    });
    it('空 text：返回 snippet 无 spans', () => {
      expect(snippetView({ ...base, text: '', snippet: 'x', spans: [[0, 1]] })).toEqual({ text: 'x', spans: [] });
    });
    it('spans 为空：返回 snippet（非空时）无 spans', () => {
      const r = snippetView({ ...base, text: 'abc', snippet: 'abc', spans: [] });
      expect(r).toEqual({ text: 'abc', spans: [] });
    });
  });

  describe('normalizeSearch', () => {
    const valid = { sessionId: 's1', type: 'user/message', text: '甲的文本', snippet: '甲的文本', spans: [[2, 4]], matchCount: 1, role: 'user', seq: 3, time: 1000, sessionTitle: '标题', anchorKey: '13:input-messagex' };
    it('无 payload → error', () => {
      const r = normalizeSearch(null);
      expect(r.hits).toEqual([]);
      expect(r.error).toBe('search returned no payload');
      expect(r.truncated).toBe(false);
    });
    it('ok=false → error 消息', () => {
      const r = normalizeSearch({ ok: false, error: 'boom' });
      expect(r.error).toBe('boom');
      expect(r.hits).toEqual([]);
    });
    it('null anchorKey 保留（显示不可跳转），sessionId 为空丢弃', () => {
      const r = normalizeSearch({ ok: true, hits: [
        { ...valid },
        { ...valid, anchorKey: null, seq: 9 },      // 保留，anchorKey 归一 ''
        { ...valid, sessionId: '', seq: 8 },        // 丢弃
      ] });
      expect(r.hits).toHaveLength(2);
      const hit = r.hits.find((h: any) => h.seq === 9);
      expect(hit.anchorKey).toBe('');
    });
    it('畸形 span 过滤；snippet/matchCount 缺省归一', () => {
      const r = normalizeSearch({ ok: true, hits: [
        { ...valid, spans: [[0, 2], [1], ['a', 'b'], [3, 1]], snippet: undefined, matchCount: undefined },
      ] });
      expect(r.hits).toHaveLength(1);
      const h = r.hits[0];
      expect(h.spans).toEqual([[0, 2]]);            // [1] 长度不足、['a','b'] 非数字、[3,1] end<start 被过滤
      expect(h.snippet).toBe(h.text);               // snippet 缺省回退 text
      expect(h.matchCount).toBe(1);
      expect(h.textTruncated).toBe(false);
    });
    it('正文截断标记透传', () => {
      const r = normalizeSearch({ ok: true, hits: [{ ...valid, textTruncated: true }] });
      expect(r.hits[0].textTruncated).toBe(true);
    });
  });

  describe('normalizeStatus', () => {
    it('无 payload → unknown', () => {
      expect(normalizeStatus(null).phase).toBe('unknown');
    });
    it('ok=false → error', () => {
      expect(normalizeStatus({ ok: false, error: 'x' }).phase).toBe('error');
    });
    it('degraded 优先 → degraded', () => {
      expect(normalizeStatus({ ready: false, degraded: true, building: false }).phase).toBe('degraded');
    });
    it('building → indexing', () => {
      expect(normalizeStatus({ ready: true, building: true, degraded: false }).phase).toBe('indexing');
    });
    it('ready → ready（含计数）', () => {
      const r = normalizeStatus({ ready: true, building: false, degraded: false, indexedSessions: 2, indexedDocs: 5 });
      expect(r.phase).toBe('ready');
      expect(r.indexedSessions).toBe(2);
      expect(r.indexedMessages).toBe(5);
      expect(r.rebuildCurrent).toBeNull();
      expect(r.rebuildTotal).toBeNull();
    });
    it('building 时带上 rebuildCurrent/rebuildTotal', () => {
      const r = normalizeStatus({
        ready: true, building: true, degraded: false,
        indexedSessions: 10, indexedDocs: 40, rebuildCurrent: 10, rebuildTotal: 114,
      });
      expect(r.phase).toBe('indexing');
      expect(r.rebuildCurrent).toBe(10);
      expect(r.rebuildTotal).toBe(114);
    });
    it('容量和覆盖状态归一', () => {
      const r = normalizeStatus({
        ready: true, building: false, degraded: false,
        storageBytes: 123, storageLimitBytes: 456, prunedDocs: 7, coverageSince: 1000,
        dbPath: '/data/index.db', defaultDbPath: '/home/u/.dsh/storages/memory-search/index.db',
      });
      expect(r).toMatchObject({
        storageBytes: 123, storageLimitBytes: 456, prunedDocs: 7, coverageSince: 1000,
        dbPath: '/data/index.db', defaultDbPath: '/home/u/.dsh/storages/memory-search/index.db',
      });
    });
    it('ready=false 且非 degraded → indexing（“索引初始化中”）', () => {
      expect(normalizeStatus({ ready: false, building: false, degraded: false }).phase).toBe('indexing');
    });
  });

  describe('callRemote（Remote face 分发；client-eng t2 切换后锁定）', () => {
    it('search 分发到 remote.search 并透传参数', async () => {
      const calls: Array<{ name: string; args: unknown }> = [];
      const remote = {
        search: async (args: unknown) => { calls.push({ name: 'search', args }); return { ok: true, hits: [], truncated: false }; },
        status: async () => { calls.push({ name: 'status', args: undefined }); return { ok: true }; },
        reindex: async () => { calls.push({ name: 'reindex', args: undefined }); return { ok: true, started: true }; },
        setDbPath: async (args: unknown) => { calls.push({ name: 'setDbPath', args }); return { ok: true, dbPath: '/tmp/x.db' }; },
      };
      const result = await callRemote(remote, 'search', { query: '聊天记录', limit: 5 });
      expect(calls).toEqual([{ name: 'search', args: { query: '聊天记录', limit: 5 } }]);
      expect(result).toEqual({ ok: true, hits: [], truncated: false });
    });

    it('status/reindex 分发到对应方法（无参调用）', async () => {
      const calls: Array<{ name: string; args: unknown }> = [];
      const remote = {
        search: async () => { throw new Error('unexpected'); },
        status: async () => { calls.push({ name: 'status', args: undefined }); return { ok: true, ready: true }; },
        reindex: async () => { calls.push({ name: 'reindex', args: undefined }); return { ok: true, started: true }; },
        setDbPath: async () => { throw new Error('unexpected'); },
      };
      await callRemote(remote, 'status');
      await callRemote(remote, 'reindex');
      expect(calls.map((c) => c.name)).toEqual(['status', 'reindex']);
    });

    it('远端拒绝原样传播（不吞错）', async () => {
      const remote = {
        search: async () => { throw new Error('boom'); },
        status: async () => ({ ok: true }),
        reindex: async () => ({ ok: true }),
        setDbPath: async () => ({ ok: true }),
      };
      await expect(callRemote(remote, 'search', { query: 'x' })).rejects.toThrow('boom');
    });

    it('解开 gateway 的 {ok:true, value} 信封，露出 Host 契约 payload', async () => {
      const host = { ok: true, hits: [], truncated: false, partial: false };
      const remote = {
        search: async () => ({ ok: true, value: host }),
        status: async () => ({ ok: true, value: { ok: true, ready: true, indexedSessions: 2, indexedDocs: 9, building: false, degraded: false } }),
        reindex: async () => ({ ok: true, value: { ok: true, started: true } }),
        setDbPath: async () => ({ ok: true, value: { ok: true, dbPath: '/tmp/x.db', started: true } }),
      };
      expect(await callRemote(remote, 'search', { query: 'x' })).toEqual(host);
      expect(await callRemote(remote, 'status')).toEqual({
        ok: true, ready: true, indexedSessions: 2, indexedDocs: 9, building: false, degraded: false,
      });
      expect(await callRemote(remote, 'reindex')).toEqual({ ok: true, started: true });
    });

    it('setDbPath 分发到 remote.setDbPath 并透传路径', async () => {
      const calls: Array<{ name: string; args: unknown }> = [];
      const remote = {
        search: async () => { throw new Error('unexpected'); },
        status: async () => ({ ok: true }),
        reindex: async () => ({ ok: true }),
        setDbPath: async (args: unknown) => { calls.push({ name: 'setDbPath', args }); return { ok: true, dbPath: '/data/index.db', started: true }; },
      };
      const result = await callRemote(remote, 'setDbPath', { path: '/data/index.db' });
      expect(calls).toEqual([{ name: 'setDbPath', args: { path: '/data/index.db' } }]);
      expect(result).toEqual({ ok: true, dbPath: '/data/index.db', started: true });
    });
  });

  describe('unwrapRemotePayload', () => {
    it('Host 形状原样通过（无 value 字段）', () => {
      const host = { ok: true, hits: [1], truncated: false };
      expect(unwrapRemotePayload(host)).toBe(host);
    });
    it('gateway 失败信封不拆 value', () => {
      const fail = { ok: false, error: { code: 'internal', message: 'x' }, value: { hidden: true } };
      expect(unwrapRemotePayload(fail)).toBe(fail);
    });
  });
});

describe.skipIf(notLoaded(clientMod))('client apply：槽位 inject 不得读 ctx.remote.memorySearch', () => {
  it('apply 经 ctx.get 拿到 face，槽位 inject 触发时不碰 ctx.remote.memorySearch', async () => {
    const face = {
      search: async () => ({ ok: true, hits: [] }),
      status: async () => ({ ok: true, ready: true }),
      reindex: async () => ({ ok: true, started: true }),
      setDbPath: async () => ({ ok: true, dbPath: '/tmp/index.db' }),
    };
    const injected: unknown[] = [];
    const ctx = {
      remote: {
        $mount: async () => {},
        get memorySearch() {
          throw new Error('cannot get property "remote.memorySearch" without inject');
        },
      },
      get(name: string) {
        return name === 'remote.memorySearch' ? face : undefined;
      },
      effect: () => () => {},
      locale: {
        register: () => () => {},
        bind: () => (key: string) => key,
      },
      sessions: { open: () => {}, binding: () => undefined },
      slots: {
        inject(_key: string, callback: () => unknown) {
          callback();
        },
        register(spec: { inject?: () => Record<string, unknown> }) {
          if (typeof spec.inject === 'function') injected.push(spec.inject());
          return spec;
        },
      },
    };
    const apply = (clientMod.mod as { apply: (ctx: unknown) => Promise<void> }).apply;
    await apply(ctx);
    expect(injected.some((props) => props !== null && typeof props === 'object' && (props as { remote?: unknown }).remote === face)).toBe(true);
  });
});
