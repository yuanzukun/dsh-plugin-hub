/**
 * 降级路径测试（t5 用例 6）：node:sqlite 不可用时插件不得崩。
 *
 * 契约（tests/README.md「QA 测试契约」）：
 *  - createSearchIndex 接受 `sqliteModule` 注入（默认内部动态导入 node:sqlite）；
 *    传入 null/undefined 时模拟不可用 → 返回 degraded 索引（内存 JSON 结构），
 *    索引/搜索可用但数据不持久化。
 *  - src/indexer.ts 不得静态 import 'node:sqlite'（必须 try 包裹动态导入）；
 *    src/index.ts 同样不得静态依赖。
 *
 * 运行时验证（Node 22.23.2，node:sqlite 可用）：degraded 路径由 sqliteModule:null
 * 触发而非真实删除内置模块；真实缺失时的行为由「无静态 import」静态守卫兜底。
 */
import { describe, it, expect } from 'vitest';
import { readFileSync, existsSync, mkdtempSync, writeFileSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { loadModule, notLoaded } from '../helpers/load-module';

const here = dirname(fileURLToPath(import.meta.url));
const basic = JSON.parse(readFileSync(join(here, '..', 'fixtures', 'session-basic.json'), 'utf8'));

const indexerMod = await loadModule(join(here, '..', '..', 'src', 'indexer.ts'));

// 模块缺失 → 显式失败（不静默）：test-first 契约信号，实现落地后必须转绿
describe.skipIf(!notLoaded(indexerMod))('indexer 模块缺失（降级契约）：违反 QA 测试契约', () => {
  it('模块必须可加载', () => {
    throw new Error('src/indexer.ts 未实现或不可加载（见 tests/README.md 契约）');
  });
});

describe.skipIf(notLoaded(indexerMod))('降级路径 (src/indexer.ts)', () => {
  it('sqliteModule=null → degraded 索引：建库/插入/搜索可用', async () => {
    const idx = (indexerMod.mod!.createSearchIndex as any)({
      dbPath: join(mkdtempSync(join(tmpdir(), 'msp-degrade-')), 'index.db'),
      sqliteModule: null,
    }) as any;
    try {
      expect(idx.degraded).toBe(true);
      expect(idx.ready).toBe(true);
      const st = idx.status();
      expect(st.degraded).toBe(true);
      expect(st.indexedDocs).toBe(0);
      await idx.upsertRecords(basic.records);
      expect(idx.status().indexedDocs).toBe(basic.records.length);
      expect(idx.status().indexedSessions).toBe(1);
      const r = await idx.search('聊天记录');
      expect(r.hits.length).toBeGreaterThanOrEqual(2);
      // 搜索语义在降级模式下依然成立（span 正确）
      const u = r.hits.find((h: any) => h.seq === 2);
      expect(u.spans).toEqual([[5, 9]]);
      const users = await idx.search('查找', { role: 'user' });
      expect(users.hits.length).toBeGreaterThan(0);
      expect(users.hits.every((h: any) => h.role === 'user')).toBe(true);
      const agents = await idx.search('查找', { role: 'assistant' });
      expect(agents.hits.length).toBeGreaterThan(0);
      expect(agents.hits.every((h: any) => h.role === 'assistant')).toBe(true);
    } finally {
      try { idx.close(); } catch { /* ignore */ }
    }
  });

  it('sqliteModule 缺失（不传）时默认走内置动态导入且不抛异常', async () => {
    const idx = (indexerMod.mod!.createSearchIndex as any)({
      dbPath: join(mkdtempSync(join(tmpdir(), 'msp-degrade2-')), 'index.db'),
    }) as any;
    try {
      expect(idx.degraded).toBe(false);
      await idx.upsertRecords(basic.records);
      expect(idx.status().indexedDocs).toBe(basic.records.length);
    } finally {
      try { idx.close(); } catch { /* ignore */ }
    }
  });
});

// ---------- 静态守卫：真实 node:sqlite 缺失场景 ----------
describe('静态守卫：node:sqlite 不得静态 import（真实缺失时不炸插件加载）', () => {
  const indexerSrc = join(here, '..', '..', 'src', 'indexer.ts');
  const pluginSrc = join(here, '..', '..', 'src', 'index.ts');

  it.skipIf(!existsSync(indexerSrc))('src/indexer.ts 对 node:sqlite 采用动态导入（try 包裹）', () => {
    const src = readFileSync(indexerSrc, 'utf8');
    const staticImport = /^\s*import\s+[^;]*from\s+['"]node:sqlite['"]/m.test(src);
    expect(staticImport, '存在静态 import node:sqlite').toBe(false);
    expect(src).toMatch(/node:sqlite/);
    expect(src).toMatch(/try\s*\{/);
  });

  it.skipIf(!existsSync(pluginSrc))('src/index.ts 不得静态依赖 node:sqlite', () => {
    const src = readFileSync(pluginSrc, 'utf8');
    const staticImport = /^\s*import\s+[^;]*from\s+['"]node:sqlite['"]/m.test(src);
    expect(staticImport, '存在静态 import node:sqlite').toBe(false);
  });
});

describe.skipIf(notLoaded(indexerMod))('G2 坏库备份重建（src/indexer.ts）', () => {
  it('非 SQLite 文件 + wal/shm sidecar → 改名备份后重建文件库，不降级内存', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'msp-g2-'));
    const dbPath = join(dir, 'index.db');
    writeFileSync(dbPath, 'this is not a sqlite database');
    writeFileSync(`${dbPath}-wal`, 'stale-wal');
    writeFileSync(`${dbPath}-shm`, 'stale-shm');
    const warnings: string[] = [];
    const idx = (indexerMod.mod!.createSearchIndex as any)({
      dbPath,
      warn: (msg: string) => warnings.push(msg),
    }) as any;
    try {
      expect(idx.degraded).toBe(false);
      await idx.upsertRecords(basic.records);
      expect(idx.status().indexedDocs).toBe(basic.records.length);
      const names = readdirSync(dir);
      expect(
        names.some((n: string) => /^index\.db\.bak-\d+$/.test(n)),
        `expected main bak, got ${names.join(', ')}`,
      ).toBe(true);
      const walAtLive = existsSync(`${dbPath}-wal`) ? readFileSync(`${dbPath}-wal`, 'utf8') : '';
      const shmAtLive = existsSync(`${dbPath}-shm`) ? readFileSync(`${dbPath}-shm`, 'utf8') : '';
      expect(walAtLive).not.toBe('stale-wal');
      expect(shmAtLive).not.toBe('stale-shm');
      expect(warnings.some((w) => w.includes('坏库已备份'))).toBe(true);
    } finally {
      try { idx.close(); } catch { /* ignore */ }
    }
  });
});
