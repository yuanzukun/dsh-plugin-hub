/**
 * RPC 层标题升级单测（H1，t11 修复后锁定）。
 *
 * 真实形状：readTitleSnapshots → [{sessionId, status, value?: {title?: {title?}}}]
 * 断言：
 *  1. 真实形状输入 → sessionTitle 被替换为真实标题；
 *  2. readTitleSnapshots rejected → 回退 id 前 8 位（值不变）；
 *  3. 观测缺失/空标题 → 保留回退；扁平旧形状防御兼容仍生效。
 */
import { describe, it, expect } from 'vitest';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { loadModule, notLoaded, hasExport } from '../helpers/load-module';

const here = dirname(fileURLToPath(import.meta.url));
const mod = await loadModule(join(here, '..', '..', 'src', 'index.ts'));

describe.skipIf(notLoaded(mod))('RPC 层标题升级 (src/index.ts)', () => {
  it('导出 applyTitleObservations / upgradeTitlesWith / applyParentTitles / partitionListedSessions', () => {
    expect(hasExport(mod, 'applyTitleObservations')).toBe(true);
    expect(hasExport(mod, 'upgradeTitlesWith')).toBe(true);
    expect(hasExport(mod, 'applyParentTitles')).toBe(true);
    expect(hasExport(mod, 'partitionListedSessions')).toBe(true);
  });

  const makeHit = (sessionId: string, fallback: string) => ({
    sessionId, sessionTitle: fallback, seq: 1, type: 'user/message', role: 'user',
    time: 1, anchorKey: 'k', text: 't', snippet: 't', spans: [], matchCount: 1,
  });

  it('真实形状输入 → sessionTitle = 真实标题', async () => {
    const hits = [makeHit('ses-aaaaaaaa', 'ses-aaaa'), makeHit('ses-bbbbbbbb', 'ses-bbbb')];
    const observations = [
      { sessionId: 'ses-aaaaaaaa', status: 'fulfilled', value: { session: {}, title: { title: '搜索插件会话', messageSeqs: [1], source: { kind: 'fallback' }, eventSeq: 1, updatedAt: 1 } } },
      { sessionId: 'ses-bbbbbbbb', status: 'rejected', value: undefined },
    ];
    await (mod.mod as any).upgradeTitlesWith(hits, async () => observations);
    expect(hits[0].sessionTitle).toBe('搜索插件会话');
    expect(hits[1].sessionTitle).toBe('ses-bbbb'); // rejected 观测 → 回退保留
  });

  it('readTitleSnapshots rejected → 全部回退 id 前 8 位（值不变）', async () => {
    const hits = [makeHit('ses-cccccccc', 'ses-cccc')];
    await (mod.mod as any).upgradeTitlesWith(hits, async () => { throw new Error('boom'); });
    expect(hits[0].sessionTitle).toBe('ses-cccc');
  });

  it('readTitleSnapshots 卡住时按时回退，不阻塞搜索 RPC', async () => {
    const hits = [makeHit('ses-timeout00', 'ses-time')];
    const started = performance.now();
    await (mod.mod as any).upgradeTitlesWith(hits, async () => new Promise(() => {}), 5);
    expect(performance.now() - started).toBeLessThan(200);
    expect(hits[0].sessionTitle).toBe('ses-time');
  });

  it('扁平旧形状防御兼容（title 字符串）仍生效', () => {
    const hits = [makeHit('ses-dddddddd', 'ses-dddd')];
    (mod.mod as any).applyTitleObservations(hits, [{ sessionId: 'ses-dddddddd', title: '扁平标题' }]);
    expect(hits[0].sessionTitle).toBe('扁平标题');
  });

  it('空标题/无观测 → 保留回退', () => {
    const hits = [makeHit('ses-eeeeeeee', 'ses-eeee')];
    (mod.mod as any).applyTitleObservations(hits, [
      { sessionId: 'ses-eeeeeeee', status: 'fulfilled', value: { title: { title: '' } } },
      { sessionId: 'other', status: 'fulfilled', value: { title: { title: '别家' } } },
    ]);
    expect(hits[0].sessionTitle).toBe('ses-eeee');
  });

  it('applyParentTitles 用缓存父标题修饰子会话回退名，不需要 listSessions', () => {
    const hits = [makeHit('ses-child000', 'ses-chil')];
    const parentBySession = new Map([['ses-child000', 'ses-parent00']]);
    const titleBySession = new Map([['ses-parent00', '主会话标题']]);
    (mod.mod as any).applyParentTitles(hits, parentBySession, titleBySession);
    expect(hits[0].sessionTitle).toBe('主会话标题 › ses-chil');
  });

  it('applyParentTitles 已有真实标题时不覆盖', () => {
    const hits = [makeHit('ses-child000', '子代理自己的标题')];
    const parentBySession = new Map([['ses-child000', 'ses-parent00']]);
    const titleBySession = new Map([['ses-parent00', '主会话标题']]);
    (mod.mod as any).applyParentTitles(hits, parentBySession, titleBySession);
    expect(hits[0].sessionTitle).toBe('子代理自己的标题');
  });

  it('partitionListedSessions 索引 fork，跳过 origin=subagent', () => {
    const partitioned = (mod.mod as any).partitionListedSessions([
      { header: { id: 'ses-root', parentSession: null, origin: { kind: 'default' } } },
      { header: { id: 'ses-fork', parentSession: 'ses-root', origin: { kind: 'default' } } },
      { header: { id: 'ses-agent', parentSession: 'ses-root', origin: { kind: 'subagent' } } },
    ]);
    expect(partitioned.indexableIds).toEqual(['ses-root', 'ses-fork']);
    expect(partitioned.subagentIds).toEqual(['ses-agent']);
    expect(partitioned.listed).toBe(3);
  });
});
