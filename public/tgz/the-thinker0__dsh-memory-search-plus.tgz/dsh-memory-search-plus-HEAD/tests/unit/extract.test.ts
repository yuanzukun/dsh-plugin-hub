/**
 * extract 单元测试（契约见 tests/README.md「QA 测试契约」）。
 *
 * expectedText 的 ground truth：直接调用 dsh 真实实现
 * `@deepseek-ai/dsh-session-query` 的 extractSessionEventText 生成
 * （见 /tmp/gen-fixtures.mjs），保证与 dsh 语义完全一致：
 *  - user/message → contentText(data.content)
 *  - assistant/message → contentText(data.message.content)
 *  - tool/call → joinText([data.name, data.arguments])
 *  - tool/result → joinText([contentText(message.content), error.name, error.code])
 *  - todo/write → joinText(todos.flatMap(t => [t.status, t.content]))
 *  - turn/end → turnEndText(reason)：error→joinText(["error",msg]) / aborted /
 *    max-tokens / interrupted / completed→""
 *  - 其余类型（step/start、assistant/chunk、session/title、request/header、
 *    compaction、未知类型）→ ""
 *  - 空文本/纯空白 → ""（跳过索引）
 */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { loadModule, notLoaded, hasExport } from '../helpers/load-module';

const here = dirname(fileURLToPath(import.meta.url));
const cases: Array<{ name: string; event: any; expectedText: string; expectedAnchorKey: string | null }> = JSON.parse(
  readFileSync(join(here, '..', 'fixtures', 'event-cases.json'), 'utf8'),
);

const loaded = await loadModule(join(here, '..', '..', 'src', 'extract.ts'));

// 模块缺失 → 显式失败（不静默）：test-first 契约信号，实现落地后必须转绿
describe.skipIf(!notLoaded(loaded))('extract 模块缺失：违反 QA 测试契约', () => {
  it('模块必须可加载', () => {
    throw new Error('src/extract.ts 未实现或不可加载（见 tests/README.md 契约）');
  });
});

describe.skipIf(notLoaded(loaded))('extract (src/extract.ts)', () => {
  it('导出 extractSessionEventText', () => {
    expect(typeof loaded.mod!.extractSessionEventText).toBe('function');
  });

  describe('抽取语义（ADR-12 v1 范围：仅 user/assistant 可见正文入索引）', () => {
    for (const c of cases) {
      // ADR-12 二轮修订：user/assistant/tool-call/tool-result 入索引；todo/turn-end 排除
      const inScope = ['user/message', 'assistant/message', 'tool/call', 'tool/result'].includes(c.event.type);
      it(`${c.name} → ${inScope ? JSON.stringify(c.expectedText) : '""（不索引运行统计）'}`, () => {
        const fn = loaded.mod!.extractSessionEventText as (e: any) => string;
        expect(fn(c.event)).toBe(inScope ? c.expectedText : '');
      });
    }
  });

  it('空文本与纯空白返回 ""（joinText trim+filter 语义）', () => {
    const fn = loaded.mod!.extractSessionEventText as (e: any) => string;
    expect(fn({ type: 'user/message', seq: 0, time: 1, data: { content: [{ type: 'text', text: '   ' }] } })).toBe('');
    expect(
      fn({ type: 'assistant/message', seq: 0, time: 1, data: { message: { content: [{ type: 'text', text: '\n\t ' }] } } }),
    ).toBe('');
  });

  it('多块 join 用换行分隔且块内文本 trim', () => {
    const fn = loaded.mod!.extractSessionEventText as (e: any) => string;
    const text = fn({
      type: 'assistant/message', seq: 0, time: 1,
      data: { message: { content: [{ type: 'text', text: ' A ' }, { type: 'text', text: 'B' }, { type: 'text', text: '' }] } },
    });
    expect(text).toBe('A\nB');
  });

  const hasContent = hasExport(loaded, 'contentText');
  const hasJoin = hasExport(loaded, 'joinText');
  describe.skipIf(!hasContent && !hasJoin)('辅助函数（导出时）', () => {
    it.skipIf(hasContent)('contentText 必须导出', () => {
      throw new Error('extract.ts 未导出 contentText（见 tests/README.md 契约）');
    });
    it.skipIf(hasJoin)('joinText 必须导出', () => {
      throw new Error('extract.ts 未导出 joinText（见 tests/README.md 契约）');
    });
    it.skipIf(!hasContent)('contentText：reasoning 块跳过、tool-call 展开 name+arguments、嵌套 tool-result 递归', () => {
      const fn = loaded.mod!.contentText as (c: any[]) => string;
      expect(fn([
        { type: 'reasoning', text: '思考' },
        { type: 'text', text: '结果' },
      ])).toBe('结果');
      expect(fn([{ type: 'tool-call', id: 't', name: 'ls', arguments: '{"p":"."}' }])).toBe('ls\n{"p":"."}');
      expect(fn([{
        type: 'tool-result', toolCallId: 't', isError: false,
        content: [{ type: 'text', text: 'A' }, { type: 'tool-result', toolCallId: 't', content: [{ type: 'text', text: 'B' }] }],
      }])).toBe('A\nB');
      expect(fn([{ type: 'unknown-block' }])).toBe('');
    });
    it.skipIf(!hasJoin)('joinText：trim → 过滤空 → 换行 join', () => {
      const fn = loaded.mod!.joinText as (p: string[]) => string;
      expect(fn([' a ', '', 'b', '  ', ' c '])).toBe('a\nb\nc');
      expect(fn([])).toBe('');
      expect(fn(['', '   '])).toBe('');
    });
  });

  it('buildIndexRecordsFromEvents 抽文本+锚点，跳过空文本', () => {
    const fn = loaded.mod!.buildIndexRecordsFromEvents as (id: string, events: any[]) => any[];
    const records = fn('ses-1', [
      { type: 'user/message', seq: 0, time: 10, data: { id: 'abc', content: [{ type: 'text', text: '你好' }] } },
      { type: 'turn/end', seq: 1, time: 11, data: { reason: { kind: 'completed' } } },
    ]);
    expect(records).toHaveLength(1);
    expect(records[0]).toMatchObject({
      sessionId: 'ses-1',
      seq: 0,
      text: '你好',
      surface: 'current',
      anchorKey: '13:input-messageabc',
    });
  });

  it('buildIndexRecordsFromEvents 保留提前截断标记供结果展示', () => {
    const fn = loaded.mod!.buildIndexRecordsFromEvents as (id: string, events: any[]) => any[];
    const records = fn('ses-long', [{
      type: 'user/message', seq: 1, time: 10,
      data: {
        id: 'long', source: { kind: 'user' },
        content: [{ type: 'text', text: `prefix ${'x'.repeat(9_000)} suffix` }],
      },
    }]);
    expect(records).toHaveLength(1);
    expect(records[0].text.length).toBeLessThanOrEqual(8_192);
    expect(records[0].text).toContain('prefix');
    expect(records[0].text).toContain('suffix');
    expect(records[0].textTruncated).toBe(true);
  });

  it('注入上下文（user/message 且 source.kind!==user）不进入索引', () => {
    const extract = loaded.mod!.extractSessionEventText as (e: any) => string;
    const build = loaded.mod!.buildIndexRecordsFromEvents as (id: string, events: any[]) => any[];
    const injected = {
      type: 'user/message',
      seq: 4,
      time: 20,
      data: {
        id: 'inj-1',
        source: { kind: 'plugin', plugin: 'subagent' },
        content: [{ type: 'text', text: '子 Agent 任务上下文：查找聊天记录' }],
      },
    };
    const compact = {
      type: 'user/message',
      seq: 5,
      time: 21,
      data: {
        id: 'c-1',
        source: { kind: 'plugin', plugin: 'compact' },
        content: [{ type: 'text', text: '压缩摘要：查找聊天记录' }],
      },
    };
    const human = {
      type: 'user/message',
      seq: 6,
      time: 22,
      data: {
        id: 'u-1',
        source: { kind: 'user' },
        content: [{ type: 'text', text: '查找聊天记录' }],
      },
    };
    expect(extract(injected)).toBe('');
    expect(extract(compact)).toBe('');
    expect(extract(human)).toBe('查找聊天记录');
    const records = build('ses-1', [injected, compact, human]);
    expect(records).toHaveLength(1);
    expect(records[0]).toMatchObject({ seq: 6, text: '查找聊天记录' });
  });

  it('压缩会话本地 fold surface，不把检查点注入上下文写入索引', () => {
    const fold = loaded.mod!.foldRawEventSurfaces as (events: any[]) => Map<number, string>;
    const build = loaded.mod!.buildIndexRecordsFromEvents as (id: string, events: any[]) => any[];
    const fx = JSON.parse(readFileSync(join(here, '..', 'fixtures', 'session-compaction.json'), 'utf8'));
    const surfaces = fold(fx.events);
    expect(surfaces.get(2)).toBe('shadowed');
    expect(surfaces.get(4)).toBe('log-only');
    expect(surfaces.get(9)).toBe('shadowed');
    expect(surfaces.get(12)).toBe('current');
    expect(surfaces.get(13)).toBe('current');
    const records = build(fx.sessionId, fx.events);
    const bySeq = new Map(records.map((r: any) => [r.seq, r]));
    expect(bySeq.has(2)).toBe(false);
    expect(bySeq.get(4)?.surface).toBe('log-only');
    expect(bySeq.has(12)).toBe(false);
    expect(bySeq.get(13)).toMatchObject({ surface: 'current', type: 'assistant/message' });
  });

  it('fold replace 按区间判断，超大 start/end 不会卡死', () => {
    const fold = loaded.mod!.foldRawEventSurfaces as (events: any[]) => Map<number, string>;
    const started = performance.now();
    const surfaces = fold([
      {
        type: 'user/message', seq: 0, time: 1, surfaceOp: 'append',
        data: { id: 'a', source: { kind: 'user' }, content: [{ type: 'text', text: '旧' }] },
      },
      {
        type: 'user/message', seq: 1, time: 2,
        surfaceOp: { op: 'replace', start: 0, end: Number.MAX_SAFE_INTEGER },
        sourceEventSeqs: [0],
        data: { id: 'b', source: { kind: 'user' }, content: [{ type: 'text', text: '新' }] },
      },
    ]);
    expect(performance.now() - started).toBeLessThan(50);
    expect(surfaces.get(0)).toBe('shadowed');
    expect(surfaces.get(1)).toBe('current');
  });
});
