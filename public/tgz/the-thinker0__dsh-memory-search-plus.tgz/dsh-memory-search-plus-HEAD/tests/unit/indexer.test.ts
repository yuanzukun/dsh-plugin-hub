/**
 * 索引器单元测试（契约见 tests/README.md「QA 测试契约」）。
 *
 * 用例覆盖（t5 用例 4）：
 *   内存/FTS 建库 → 插入 → 增量 → 压缩检查点重建 → 删除会话 → 持久化
 *
 * 所需 API（src/indexer.ts）：
 *   createSearchIndex(options?: { dbPath?: string; sqliteModule?: unknown }): SearchIndex
 *   SearchIndex {
 *     ready: boolean; degraded: boolean;
 *     status(): { ready; indexedSessions; indexedDocs; building; degraded };
 *     upsertRecords(records: IndexRecord[], rebuildSessionIds?: string[]): void|Promise<void>;
 *     removeSession(sessionId: string): void|Promise<void>;
 *     search(query, options?): SearchResult;
 *     close(): void;
 *   }
 *   IndexRecord = { sessionId; seq; type; time; surface; text; anchorKey }
 */
import { describe, it, expect, afterEach } from 'vitest';
import { readFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { loadModule, notLoaded } from '../helpers/load-module';

const here = dirname(fileURLToPath(import.meta.url));
const basic = JSON.parse(readFileSync(join(here, '..', 'fixtures', 'session-basic.json'), 'utf8'));
const comp = JSON.parse(readFileSync(join(here, '..', 'fixtures', 'session-compaction.json'), 'utf8'));

const loaded = await loadModule(join(here, '..', '..', 'src', 'indexer.ts'));

// 模块缺失 → 显式失败（不静默）：test-first 契约信号，实现落地后必须转绿
describe.skipIf(!notLoaded(loaded))('indexer 模块缺失：违反 QA 测试契约', () => {
  it('模块必须可加载', () => {
    throw new Error('src/indexer.ts 未实现或不可加载（见 tests/README.md 契约）');
  });
});

const openIndexes: Array<{ close(): void | Promise<void> }> = [];
afterEach(() => {
  for (const idx of openIndexes.splice(0)) {
    try { idx.close(); } catch { /* already closed */ }
  }
});

function dbPath(): string {
  return join(mkdtempSync(join(tmpdir(), 'msp-index-')), 'index.db');
}

describe.skipIf(notLoaded(loaded))('indexer (src/indexer.ts)', () => {
  it('导出 createSearchIndex', () => {
    expect(typeof loaded.mod!.createSearchIndex).toBe('function');
  });

  describe('建库', () => {
    it('文件 DB：空库状态 ready 且 0 文档', async () => {
      const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: dbPath() }) as any;
      openIndexes.push(idx);
      expect(idx.ready).toBe(true);
      const st = idx.status();
      expect(st.ready).toBe(true);
      expect(st.indexedDocs).toBe(0);
      expect(st.indexedSessions).toBe(0);
      expect(st.degraded).toBe(false);
      expect(st.building).toBe(false);
    });

    it('内存 DB（:memory:）可建库', async () => {
      const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: ':memory:' }) as any;
      openIndexes.push(idx);
      expect(idx.ready).toBe(true);
      expect(idx.status().indexedDocs).toBe(0);
    });
  });

  describe('插入与增量', () => {
    it('插入 session-basic 12 条 records', async () => {
      const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: dbPath() }) as any;
      openIndexes.push(idx);
      await idx.upsertRecords(basic.records);
      const st = idx.status();
      expect(st.indexedDocs).toBe(basic.records.length);
      expect(st.indexedSessions).toBe(1);
    });

    it('同 (sessionId,seq) 重放不重复计数（upsert 幂等）', async () => {
      const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: dbPath() }) as any;
      openIndexes.push(idx);
      await idx.upsertRecords(basic.records);
      await idx.upsertRecords(basic.records);
      expect(idx.status().indexedDocs).toBe(basic.records.length);
    });

    it('增量追加新事件（新 seq）计数 +1', async () => {
      const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: dbPath() }) as any;
      openIndexes.push(idx);
      await idx.upsertRecords(basic.records);
      const extra = {
        sessionId: basic.sessionId, seq: 23, type: 'user/message', time: 1787494700000,
        surface: 'current', text: '增量消息：补充一条记录', anchorKey: '13:input-messageu-9',
      };
      await idx.upsertRecords([extra]);
      expect(idx.status().indexedDocs).toBe(basic.records.length + 1);
    });
  });

  describe('压缩检查点重建', () => {
    it('rebuildSessionIds 重建：shadowed 记录被清除，仅保留 current/log-only', async () => {
      const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: dbPath() }) as any;
      openIndexes.push(idx);
      // 先插入（模拟压缩前：含将被替换的旧文本）
      const before = comp.records.length;
      await idx.upsertRecords(comp.records);
      expect(idx.status().indexedDocs).toBe(before);
      await idx.upsertRecords(comp.records, [comp.sessionId]);
      const keep = comp.records.filter((r: any) => r.surface !== 'shadowed').length;
      expect(idx.status().indexedDocs).toBe(keep);
      // 旧表面文本已消失
      const search = await idx.search('第一轮问题');
      expect(search.hits).toHaveLength(0);
      const cp = await idx.search('Compacted');
      expect(cp.hits.length).toBeGreaterThanOrEqual(1);
    });

    it('重建后 current 记录可检索', async () => {
      const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: dbPath() }) as any;
      openIndexes.push(idx);
      await idx.upsertRecords(comp.records, [comp.sessionId]);
      const r = await idx.search('增量');
      expect(r.hits.length).toBeGreaterThanOrEqual(1);
      for (const h of r.hits) expect(h.sessionId).toBe(comp.sessionId);
    });
  });

  describe('删除会话', () => {
    it('removeSession 后该会话文档清空', async () => {
      const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: dbPath() }) as any;
      openIndexes.push(idx);
      await idx.upsertRecords(basic.records);
      await idx.upsertRecords(comp.records, [comp.sessionId]);
      const keepComp = comp.records.filter((r: any) => r.surface !== 'shadowed').length;
      expect(idx.status().indexedSessions).toBe(2);
      expect(idx.status().indexedDocs).toBe(basic.records.length + keepComp);
      await idx.removeSession(basic.sessionId);
      const st = idx.status();
      expect(st.indexedSessions).toBe(1);
      expect(st.indexedDocs).toBe(keepComp);
      const r = await idx.search('会议安排');
      for (const h of r.hits) expect(h.sessionId).not.toBe(basic.sessionId);
    });
  });

  describe('持久化', () => {
    it('close 后重开同一 dbPath 数据仍在', async () => {
      const path = dbPath();
      const idx1 = (loaded.mod!.createSearchIndex as any)({ dbPath: path }) as any;
      await idx1.upsertRecords(basic.records);
      idx1.close();
      const idx2 = (loaded.mod!.createSearchIndex as any)({ dbPath: path }) as any;
      openIndexes.push(idx2);
      expect(idx2.status().indexedDocs).toBe(basic.records.length);
      const r = await idx2.search('聊天记录');
      expect(r.hits.length).toBeGreaterThanOrEqual(2);
    });
  });

  describe('session_state 状态机扩展（H2，t11）', () => {
    it('upsert 后 sessionState 反映 max_seq/docs/dirty=0，listSessionIds 含该会话', async () => {
      const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: dbPath() }) as any;
      openIndexes.push(idx);
      await idx.upsertRecords(basic.records);
      const row = idx.sessionState(basic.sessionId);
      expect(row).toBeDefined();
      expect(row!.docs).toBe(basic.records.length);
      expect(row!.maxSeq).toBe(Math.max(...basic.records.map((r: any) => r.seq)));
      expect(row!.dirty).toBe(0);
      expect(row!.builtAt).toBeTypeOf('number');
      expect(idx.listSessionIds()).toContain(basic.sessionId);
    });

    it('markSessionDirty/clearSessionDirty 持久化；rebuild 后 dirty 归 0；removeSession 清除行', async () => {
      const path = dbPath();
      const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: path }) as any;
      openIndexes.push(idx);
      await idx.upsertRecords(basic.records);
      idx.markSessionDirty(basic.sessionId);
      expect(idx.sessionState(basic.sessionId)!.dirty).toBe(1);
      idx.close();
      const idx2 = (loaded.mod!.createSearchIndex as any)({ dbPath: path }) as any;
      openIndexes.push(idx2);
      expect(idx2.sessionState(basic.sessionId)!.dirty).toBe(1); // 持久化
      idx2.clearSessionDirty(basic.sessionId);
      expect(idx2.sessionState(basic.sessionId)!.dirty).toBe(0);
      // rebuild 后 dirty 归 0 且计数正确
      await idx2.upsertRecords(basic.records, [basic.sessionId]);
      const row = idx2.sessionState(basic.sessionId)!;
      expect(row.docs).toBe(basic.records.length);
      expect(row.dirty).toBe(0);
      idx2.removeSession(basic.sessionId);
      expect(idx2.sessionState(basic.sessionId)).toBeUndefined();
      expect(idx2.listSessionIds()).not.toContain(basic.sessionId);
    });
  });

  it('indexedSessions 按 sessionId 去重', async () => {
    const idx = (loaded.mod!.createSearchIndex as any)({ dbPath: dbPath() }) as any;
    openIndexes.push(idx);
    await idx.upsertRecords(basic.records);
    await idx.upsertRecords([{ ...basic.records[0], sessionId: 'ses-other-0009' }]);
    expect(idx.status().indexedSessions).toBe(2);
  });
});
