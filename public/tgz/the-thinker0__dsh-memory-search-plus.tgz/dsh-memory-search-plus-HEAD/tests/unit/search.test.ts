/**
 * 二段式搜索单元测试（契约见 tests/README.md「QA 测试契约」）。
 *
 * 用例覆盖（t5 用例 5）：
 *   中文子串命中 / 英文大小写 / 短语 / 多关键词 AND / 时间降序 / surface 过滤 /
 *   spans 正确性 / snippet 截断 / limit 截断 / 命中字段与 role 映射 / 消息级定位
 *
 * 所需 API：
 *   src/search.ts:  computeSpans(text, query): [number,number][]
 *                   buildSnippet(text, spans, radius?): { snippet; spans; start }
 *   src/indexer.ts: SearchIndex.search(query, { limit?, surface? }): {
 *                     ok: boolean; hits: SearchHit[]; truncated: boolean }
 *   SearchHit = { sessionId; sessionTitle; seq; type; role; time; anchorKey;
 *                 text; snippet; spans; matchCount }
 */
import { describe, it, expect, afterEach } from 'vitest';
import { readFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { loadModule, notLoaded, hasExport } from '../helpers/load-module';

const here = dirname(fileURLToPath(import.meta.url));
const basic = JSON.parse(readFileSync(join(here, '..', 'fixtures', 'session-basic.json'), 'utf8'));
const comp = JSON.parse(readFileSync(join(here, '..', 'fixtures', 'session-compaction.json'), 'utf8'));

const searchMod = await loadModule(join(here, '..', '..', 'src', 'search.ts'));
const indexerMod = await loadModule(join(here, '..', '..', 'src', 'indexer.ts'));
const skip = notLoaded(indexerMod) || notLoaded(searchMod);

// 模块缺失 → 显式失败（不静默）：test-first 契约信号，实现落地后必须转绿
describe.skipIf(!skip)('search/indexer 模块缺失：违反 QA 测试契约', () => {
  it('模块必须可加载', () => {
      throw new Error('src/search.ts 或 src/indexer.ts 未实现或不可加载（见 tests/README.md 契约）');
  });
});

const openIndexes: Array<{ close(): void | Promise<void> }> = [];
afterEach(() => {
  for (const idx of openIndexes.splice(0)) {
    try { idx.close(); } catch { /* closed */ }
  }
});

async function makeIndex(extraRecords: any[] = []) {
  const idx = (indexerMod.mod!.createSearchIndex as any)({
    dbPath: join(mkdtempSync(join(tmpdir(), 'msp-search-')), 'index.db'),
  });
  openIndexes.push(idx);
  await idx.upsertRecords(basic.records);
  // 先灌入压缩前状态，再按压缩检查点重建（shadowed 被清除）
  await idx.upsertRecords(comp.records);
  await idx.upsertRecords(comp.records, [comp.sessionId]);
  if (extraRecords.length) await idx.upsertRecords(extraRecords);
  return idx;
}

const LONG_TEXT = (
  '这是很长的文本' + '用于测试摘要截断功能我们需要把内容撑到足够长。'.repeat(2) +
  ' '.repeat(1) + '中段包含一个关键词叫截断锚点。' + '后续继续填充足够的内容直到超过摘要半径。'.repeat(6) +
  '末尾再来一句收尾。'
);
const LONG_RECORD = {
  sessionId: 'ses-long-0003', seq: 0, type: 'user/message', time: 1787494800000,
  surface: 'current', text: LONG_TEXT, anchorKey: '13:input-messagelong-1',
};

// ---------- 纯函数：computeSpans ----------
describe('computeSpans (src/search.ts)', () => {
  const has = hasExport(searchMod, 'computeSpans');
  const compute = (t: string, q: string): [number, number][] =>
    (searchMod.mod as any).computeSpans(t, q);
  it.skipIf(has)('computeSpans 缺失：违反 QA 测试契约', () => {
    throw new Error('search.ts 未导出 computeSpans（见 tests/README.md 契约）');
  });
  describe.skipIf(!has)('行为', () => {
    it('英文多出现，全匹配', () => expect(compute('ABC abc abc', 'abc')).toEqual([[0, 3], [4, 7], [8, 11]]));
    it('中文子串偏移（字符级）', () => expect(compute('查找聊天记录', '聊天记录')).toEqual([[2, 6]]));
    it('不重叠贪婪：aaa 匹配 aa 只取第一处', () => expect(compute('aaa', 'aa')).toEqual([[0, 2]]));
    it('大小写不敏感', () => expect(compute('Hello, World', 'hello')).toEqual([[0, 5]]));
    it('无匹配返回空数组', () => expect(compute('no match here', 'xyz')).toEqual([]));
    it('多词查询按词分别定位', () => expect(compute('聊天记录搜索', '记录')).toEqual([[2, 4]]));
    it('空查询返回空数组', () => expect(compute('abc', '')).toEqual([]));
  });
});

// ---------- 纯函数：buildSnippet ----------
describe('buildSnippet (src/search.ts)', () => {
  const has = hasExport(searchMod, 'buildSnippet');
  const snippetOf = (t: string, spans: [number, number][], radius?: number) =>
    (searchMod.mod as any).buildSnippet(t, spans, radius);
  it.skipIf(has)('buildSnippet 缺失：违反 QA 测试契约', () => {
    throw new Error('search.ts 未导出 buildSnippet（见 tests/README.md 契约）');
  });
  describe.skipIf(!has)('行为', () => {
    it('短文本：整段返回，spans 偏移不变', () => {
      const r = snippetOf('查找聊天记录', [[2, 6]]);
      expect(r.snippet).toBe('查找聊天记录');
      expect(r.spans).toEqual([[2, 6]]);
    });

    it('长文本：以首个匹配为中心，snippet 内 spans 指向相同子串', () => {
      const spans = computeOf(LONG_TEXT, '截断锚点');
      const r = snippetOf(LONG_TEXT, spans, 120);
      expect(r.spans.length).toBeGreaterThan(0);
      const [s, e] = r.spans[0];
      expect(s >= 0 && e <= r.snippet.length).toBe(true);
      expect(r.snippet.slice(s, e)).toBe('截断锚点');
      // 摘要被截短了（未含首尾全部内容）
      expect(r.snippet.length).toBeLessThan(LONG_TEXT.length);
      expect(r.snippet.length).toBeLessThanOrEqual(2 * 120 + 32);
    });

    it('匹配在文本开头/结尾时边界裁剪不越界', () => {
      const r1 = snippetOf('锚点开头', [[0, 2]], 120);
      expect(r1.snippet.slice(r1.spans[0][0], r1.spans[0][1])).toBe('锚点');
      const r2 = snippetOf('结尾锚点', [[2, 4]], 120);
      expect(r2.snippet.slice(r2.spans[0][0], r2.spans[0][1])).toBe('锚点');
    });

    it('空文本/空 spans 不抛异常', () => {
      expect(() => snippetOf('', [], 120)).not.toThrow();
    });

    function computeOf(text: string, q: string): [number, number][] {
      return (searchMod.mod as any).computeSpans(text, q);
    }
  });
});

// ---------- 集成：indexer.search 二段式 ----------
describe.skipIf(skip)('search 集成 (indexer.search)', () => {
  it('中文子串命中（"聊天记录" 在 "请帮我查找聊天记录…" 中）', async () => {
    const idx = await makeIndex();
    const r = await idx.search('聊天记录');
    expect(r.ok).toBe(true);
    const seqs = r.hits.map((h: any) => h.seq);
    expect(seqs).toContain(2); // user/message
    expect(seqs).toContain(5); // assistant/message
    const userHit = r.hits.find((h: any) => h.seq === 2);
    expect(userHit.text).toBe('请帮我查找聊天记录，确认明天的会议安排。');
    expect(userHit.spans).toEqual([[5, 9]]);
    expect(userHit.matchCount).toBe(1);
  });

  it('英文大小写不敏感（CHAT HISTORY == chat history）', async () => {
    const idx = await makeIndex();
    const a = await idx.search('CHAT HISTORY');
    const b = await idx.search('chat history');
    expect(a.hits.map((h: any) => h.seq)).toEqual(b.hits.map((h: any) => h.seq));
    expect(a.hits.map((h: any) => h.seq)).toEqual(expect.arrayContaining([12, 13]));
  });

  it('短语命中（"fuzzy match"、"会议安排"）', async () => {
    const idx = await makeIndex();
    const r1 = await idx.search('fuzzy match');
    expect(r1.hits.map((h: any) => h.seq)).toEqual([12]);
    const r2 = await idx.search('会议安排');
    // seq8 是 todo/write（"汇总会议安排"），与 seq2 同会话真实命中；按 time DESC 排序
    expect(r2.hits.map((h: any) => h.seq)).toEqual([8, 2]);
  });

  it('多关键词 AND 语义（"聊天记录 会议"）', async () => {
    const idx = await makeIndex();
    const r = await idx.search('聊天记录 会议');
    // 阶段1 token AND 召回，阶段2 按词逐个精确校验
    expect(r.hits.length).toBeGreaterThanOrEqual(1);
    expect(r.hits.map((h: any) => h.seq)).toContain(2);
    for (const h of r.hits) expect(h.matchCount).toBeGreaterThanOrEqual(1);
  });

  it('时间降序（time DESC，同 time 按 seq DESC）', async () => {
    const idx = await makeIndex();
    const r = await idx.search('记录');
    const times = r.hits.map((h: any) => h.time);
    for (let i = 1; i < times.length; i++) {
      expect(times[i - 1] > times[i] || (times[i - 1] === times[i] && r.hits[i - 1].seq > r.hits[i].seq)).toBe(true);
    }
  });

  it('surface 过滤：默认含 log-only；surface=current 排除 tool/call；surface=log-only 只留 tool/call', async () => {
    const idx = await makeIndex();
    const all = await idx.search('search_events');
    expect(all.hits).toHaveLength(1);
    expect(all.hits[0].type).toBe('tool/call');
    const cur = await idx.search('search_events', { surface: 'current' });
    expect(cur.hits).toHaveLength(0);
    const log = await idx.search('search_events', { surface: 'log-only' });
    expect(log.hits).toHaveLength(1);
  });

  it('未命中：空 hits 且 ok=true', async () => {
    const idx = await makeIndex();
    const r = await idx.search('绝对不存在的关键词xyzqw');
    expect(r.ok).toBe(true);
    expect(r.hits).toHaveLength(0);
  });

  it('limit 截断与 truncated 标志', async () => {
    const idx = await makeIndex();
    const r = await idx.search('记录', { limit: 2 });
    expect(r.hits.length).toBe(2);
    expect(r.truncated).toBe(true);
  });

  it('默认搜索不在 60 条截断，更早的命中仍返回', async () => {
    const extra = Array.from({ length: 80 }, (_, i) => ({
      sessionId: 'ses-old-batch',
      seq: i,
      type: 'user/message',
      time: 1_600_000_000_000 + i,
      surface: 'current',
      text: `独有锚点词 zebraquark ${i}`,
      anchorKey: `old-${i}`,
    }));
    const idx = await makeIndex(extra);
    const r = await idx.search('zebraquark');
    expect(r.ok).toBe(true);
    expect(r.hits).toHaveLength(80);
    expect(r.truncated).toBe(false);
    expect(r.hits.some((h: { seq: number }) => h.seq === 0)).toBe(true);
  });

  it('命中字段完整：text≤8192、snippet 含匹配、sessionTitle 非空、matchCount≥1', async () => {
    const idx = await makeIndex();
    const r = await idx.search('聊天记录');
    for (const h of r.hits) {
      expect(typeof h.sessionId).toBe('string');
      expect(typeof h.sessionTitle).toBe('string');
      expect(h.sessionTitle.length).toBeGreaterThan(0);
      expect(typeof h.seq).toBe('number');
      expect(typeof h.time).toBe('number');
      expect(h.text.length).toBeLessThanOrEqual(8192);
      expect(Array.isArray(h.spans)).toBe(true);
      expect(typeof h.anchorKey === 'string' || h.anchorKey === null, `anchorKey=${String(h.anchorKey)}`).toBe(true);
      expect(h.matchCount).toBeGreaterThanOrEqual(1);
      // snippet 中匹配片段与 query 一致（大小写不敏感）
      const lower = h.snippet.toLowerCase();
      expect(lower).toContain('聊天记录');
      for (const [s, e] of h.spans as [number, number][]) {
        expect(h.text.slice(s, e).toLowerCase()).toBe('聊天记录');
      }
    }
  });

  it('role 映射：user/message→user，assistant/message→assistant，tool/call 与 tool/result→tool', async () => {
    const idx = await makeIndex();
    const u = await idx.search('查找聊天记录');
    expect(u.hits.find((h: any) => h.seq === 2)?.role).toBe('user');
    const a = await idx.search('好的，我来查找');
    expect(a.hits.find((h: any) => h.seq === 5)?.role).toBe('assistant');
    const t = await idx.search('search_events');
    expect(t.hits[0]?.role).toBe('tool');
    const tr = await idx.search('command failed');
    expect(tr.hits.find((h: any) => h.seq === 15)?.role).toBe('tool');
  });

  it('role 过滤在召回阶段生效：同词只返回该角色，不混入 Agent 复述', async () => {
    const idx = await makeIndex();
    const mixed = await idx.search('查找', { role: 'all' });
    expect(mixed.hits.some((h: any) => h.role === 'user')).toBe(true);
    expect(mixed.hits.some((h: any) => h.role === 'assistant')).toBe(true);
    const users = await idx.search('查找', { role: 'user' });
    expect(users.hits.length).toBeGreaterThan(0);
    expect(users.hits.every((h: any) => h.role === 'user')).toBe(true);
    const agents = await idx.search('查找', { role: 'assistant' });
    expect(agents.hits.length).toBeGreaterThan(0);
    expect(agents.hits.every((h: any) => h.role === 'assistant')).toBe(true);
  });

  it('消息级定位：anchorKey 精确（"13:input-messageu-1"）', async () => {
    const idx = await makeIndex();
    const r = await idx.search('查找聊天记录');
    const hit = r.hits.find((h: any) => h.seq === 2);
    expect(hit.anchorKey).toBe('13:input-messageu-1');
    const r2 = await idx.search('好的，我来查找');
    expect(r2.hits.find((h: any) => h.seq === 5)?.anchorKey).toBe('14:assistant-step1:1');
  });

  it('压缩后 shadowed 文本不再命中（重建语义）', async () => {
    const idx = await makeIndex();
    const r = await idx.search('第一轮问题');
    expect(r.hits).toHaveLength(0);
    const r2 = await idx.search('Compacted');
    expect(r2.hits.length).toBeGreaterThanOrEqual(1);
  });

  it('超长文本 snippet 截断：摘要短于原文且匹配可见', async () => {
    const idx = await makeIndex([LONG_RECORD]);
    const r = await idx.search('截断锚点');
    expect(r.hits.length).toBeGreaterThanOrEqual(1);
    const h = r.hits.find((x: any) => x.sessionId === 'ses-long-0003')!;
    expect(h.snippet.length).toBeLessThan(LONG_TEXT.length);
    const lower = h.snippet.toLowerCase();
    expect(lower).toContain('截断锚点');
    for (const [s, e] of h.spans as [number, number][]) {
      expect(h.text.slice(s, e)).toBe('截断锚点');
    }
  });
});
