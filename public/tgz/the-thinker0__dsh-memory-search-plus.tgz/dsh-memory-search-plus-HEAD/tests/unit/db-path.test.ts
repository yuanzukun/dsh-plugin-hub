/**
 * Index database path: normalize user input, persist independently of the
 * SQLite file, and resolve in persisted → env → config → default order.
 */
import { describe, it, expect, afterEach } from 'vitest'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import os from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { dirname } from 'node:path'
import { loadModule, notLoaded } from '../helpers/load-module'

const here = dirname(fileURLToPath(import.meta.url))
const loaded = await loadModule(join(here, '..', '..', 'src', 'db-path.ts'))
const indexerLoaded = await loadModule(join(here, '..', '..', 'src', 'indexer.ts'))
const basic = JSON.parse(readFileSync(join(here, '..', 'fixtures', 'session-basic.json'), 'utf8')) as {
  records: unknown[]
}

describe.skipIf(!notLoaded(loaded))('db-path 模块缺失', () => {
  it('模块必须可加载', () => {
    throw new Error(`src/db-path.ts 未实现或不可加载: ${loaded.error}`)
  })
})

const ORIGINAL_HOME = process.env.DSH_HOME
const ORIGINAL_DB = process.env.DSH_MEMORY_SEARCH_DB
const temps: string[] = []

function tempDir(): string {
  const dir = mkdtempSync(join(os.tmpdir(), 'msp-dbpath-'))
  temps.push(dir)
  return dir
}

afterEach(() => {
  if (ORIGINAL_HOME === undefined) delete process.env.DSH_HOME
  else process.env.DSH_HOME = ORIGINAL_HOME
  if (ORIGINAL_DB === undefined) delete process.env.DSH_MEMORY_SEARCH_DB
  else process.env.DSH_MEMORY_SEARCH_DB = ORIGINAL_DB
  while (temps.length > 0) {
    const dir = temps.pop()
    if (dir !== undefined) rmSync(dir, { recursive: true, force: true })
  }
})

describe.skipIf(notLoaded(loaded))('db-path', () => {
  const normalizeUserDbPath = loaded.mod!.normalizeUserDbPath as (input: string) =>
    { ok: true; path: string } | { ok: false; error: string }
  const defaultIndexDbPath = loaded.mod!.defaultIndexDbPath as () => string
  const resolveIndexDbPath = loaded.mod!.resolveIndexDbPath as (options?: { configPath?: string }) => string
  const writePersistedDbPath = loaded.mod!.writePersistedDbPath as (dbPath: string) => void
  const indexLocationFilePath = loaded.mod!.indexLocationFilePath as () => string
  const expandUserPath = loaded.mod!.expandUserPath as (input: string) => string
  const copyIndexDatabase = loaded.mod!.copyIndexDatabase as (from: string, to: string) =>
    { ok: true; path: string; copied: boolean } | { ok: false; error: string }
  const removeIndexDatabaseFiles = loaded.mod!.removeIndexDatabaseFiles as (dbPath: string) => string[]
  const indexDatabaseFileExists = loaded.mod!.indexDatabaseFileExists as (dbPath: string) => boolean

  describe('normalizeUserDbPath', () => {
    it('拒绝空路径、相对路径、:memory: 与 file: URI', () => {
      expect(normalizeUserDbPath('').ok).toBe(false)
      expect(normalizeUserDbPath('   ').ok).toBe(false)
      expect(normalizeUserDbPath('relative/index.db').ok).toBe(false)
      expect(normalizeUserDbPath(':memory:').ok).toBe(false)
      expect(normalizeUserDbPath('file:/tmp/index.db').ok).toBe(false)
    })

    it('已存在目录拼上 index.db；.db 文件保持原路径', () => {
      const dir = tempDir()
      const file = join(dir, 'custom.db')
      writeFileSync(file, '')
      expect(normalizeUserDbPath(dir)).toEqual({ ok: true, path: join(dir, 'index.db') })
      expect(normalizeUserDbPath(file)).toEqual({ ok: true, path: file })
    })

    it('尚不存在时：目录语义拼 index.db，.db 扩展名当文件', () => {
      const dir = tempDir()
      const nested = join(dir, 'store')
      expect(normalizeUserDbPath(nested + '/')).toEqual({ ok: true, path: join(nested, 'index.db') })
      expect(normalizeUserDbPath(join(dir, 'mine.sqlite'))).toEqual({ ok: true, path: join(dir, 'mine.sqlite') })
      expect(normalizeUserDbPath(join(dir, 'data'))).toEqual({ ok: true, path: join(dir, 'data', 'index.db') })
    })

    it('展开 ~', () => {
      const home = os.homedir()
      expect(expandUserPath('~/storages/x.db')).toBe(join(home, 'storages/x.db'))
      const normalized = normalizeUserDbPath('~/storages/x.db')
      expect(normalized).toEqual({ ok: true, path: join(home, 'storages/x.db') })
    })
  })

  describe('resolveIndexDbPath', () => {
    it('默认落在 DSH_HOME/storages/memory-search/index.db', () => {
      const home = tempDir()
      process.env.DSH_HOME = home
      delete process.env.DSH_MEMORY_SEARCH_DB
      expect(defaultIndexDbPath()).toBe(join(home, 'storages', 'memory-search', 'index.db'))
      expect(resolveIndexDbPath()).toBe(join(home, 'storages', 'memory-search', 'index.db'))
    })

    it('优先级：持久化 > env > config > 默认', () => {
      const home = tempDir()
      process.env.DSH_HOME = home
      const persisted = join(home, 'chosen', 'index.db')
      const envPath = join(home, 'env', 'index.db')
      const configPath = join(home, 'cfg', 'index.db')
      process.env.DSH_MEMORY_SEARCH_DB = envPath
      expect(resolveIndexDbPath({ configPath })).toBe(envPath)
      mkdirSync(join(home, 'storages', 'memory-search'), { recursive: true })
      writePersistedDbPath(persisted)
      expect(resolveIndexDbPath({ configPath })).toBe(persisted)
      expect(existsSync(indexLocationFilePath())).toBe(true)
      expect(JSON.parse(readFileSync(indexLocationFilePath(), 'utf8'))).toEqual({ dbPath: persisted })
    })

    it('写回默认路径会删除 location.json', () => {
      const home = tempDir()
      process.env.DSH_HOME = home
      delete process.env.DSH_MEMORY_SEARCH_DB
      const custom = join(home, 'elsewhere', 'index.db')
      writePersistedDbPath(custom)
      expect(existsSync(indexLocationFilePath())).toBe(true)
      writePersistedDbPath(defaultIndexDbPath())
      expect(existsSync(indexLocationFilePath())).toBe(false)
      expect(resolveIndexDbPath()).toBe(defaultIndexDbPath())
    })

    it('非法 env 回退到 config / 默认', () => {
      const home = tempDir()
      process.env.DSH_HOME = home
      process.env.DSH_MEMORY_SEARCH_DB = 'relative.db'
      const configPath = join(home, 'from-config.db')
      expect(resolveIndexDbPath({ configPath })).toBe(configPath)
    })
  })

  describe('copyIndexDatabase / removeIndexDatabaseFiles', () => {
    it('复制主库和 WAL，并清掉目标残留 shm', () => {
      const from = join(tempDir(), 'index.db')
      const to = join(tempDir(), 'index.db')
      writeFileSync(from, 'main')
      writeFileSync(`${from}-wal`, 'wal')
      writeFileSync(`${to}-wal`, 'stale-wal')
      writeFileSync(`${to}-shm`, 'stale-shm')
      const result = copyIndexDatabase(from, to)
      expect(result).toEqual({ ok: true, path: to, copied: true })
      expect(readFileSync(to, 'utf8')).toBe('main')
      expect(readFileSync(`${to}-wal`, 'utf8')).toBe('wal')
      expect(existsSync(`${to}-shm`)).toBe(false)
      expect(existsSync(from)).toBe(true)
      expect(removeIndexDatabaseFiles(from)).toEqual([])
      expect(existsSync(from)).toBe(false)
      expect(existsSync(`${from}-wal`)).toBe(false)
      expect(indexDatabaseFileExists(to)).toBe(true)
    })

    it('源不存在时不报错、不创建空主库', () => {
      const to = join(tempDir(), 'index.db')
      const result = copyIndexDatabase(join(tempDir(), 'missing.db'), to)
      expect(result).toMatchObject({ ok: true, copied: false })
      expect(existsSync(to)).toBe(false)
    })
  })
})

describe.skipIf(notLoaded(loaded) || notLoaded(indexerLoaded))('搬迁后的 SQLite 索引仍可搜索', () => {
  it('close → 复制 → 打开新路径 → 删除旧文件：文档数与搜索命中保持不变，且 location.json 能解析到新路径', async () => {
    const copyIndexDatabase = loaded.mod!.copyIndexDatabase as (from: string, to: string) =>
      { ok: true; path: string; copied: boolean } | { ok: false; error: string }
    const removeIndexDatabaseFiles = loaded.mod!.removeIndexDatabaseFiles as (dbPath: string) => string[]
    const writePersistedDbPath = loaded.mod!.writePersistedDbPath as (dbPath: string) => void
    const resolveIndexDbPath = loaded.mod!.resolveIndexDbPath as () => string
    const createSearchIndex = indexerLoaded.mod!.createSearchIndex as (options?: { dbPath?: string }) => {
      degraded: boolean
      status(): { indexedDocs: number; indexedSessions: number }
      upsertRecords(records: unknown[]): void | Promise<void>
      search(query: string): { hits: unknown[] }
      optimize(): void
      close(): void
    }

    const src = join(tempDir(), 'index.db')
    const dest = join(tempDir(), 'moved', 'index.db')
    const idx = createSearchIndex({ dbPath: src })
    try {
      expect(idx.degraded).toBe(false)
      await idx.upsertRecords(basic.records)
      idx.optimize()
      const before = idx.status()
      const hitsBefore = idx.search('聊天记录').hits.length
      expect(before.indexedDocs).toBeGreaterThan(0)
      expect(hitsBefore).toBeGreaterThanOrEqual(2)
      idx.close()

      const copied = copyIndexDatabase(src, dest)
      expect(copied).toEqual({ ok: true, path: dest, copied: true })
      expect(existsSync(dest)).toBe(true)

      const moved = createSearchIndex({ dbPath: dest })
      try {
        expect(moved.degraded).toBe(false)
        expect(moved.status().indexedDocs).toBe(before.indexedDocs)
        expect(moved.status().indexedSessions).toBe(before.indexedSessions)
        expect(moved.search('聊天记录').hits.length).toBe(hitsBefore)
      } finally {
        moved.close()
      }

      expect(removeIndexDatabaseFiles(src)).toEqual([])
      expect(existsSync(src)).toBe(false)
      expect(existsSync(dest)).toBe(true)

      const home = tempDir()
      process.env.DSH_HOME = home
      delete process.env.DSH_MEMORY_SEARCH_DB
      writePersistedDbPath(dest)
      expect(resolveIndexDbPath()).toBe(dest)
      expect(existsSync(dest)).toBe(true)
    } finally {
      try {
        idx.close()
      } catch {
        /* already closed */
      }
    }
  })
})
