/** Failure, drift, and bounded-resource regressions not covered by the original
 * happy-path contract suites. All file-backed cases live under os.tmpdir(). */
import { afterEach, describe, expect, it } from 'vitest'
import { DatabaseSync } from 'node:sqlite'
import { mkdtempSync, readdirSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { loadModule, notLoaded } from '../helpers/load-module'

const here = dirname(fileURLToPath(import.meta.url))
const indexer = await loadModule(join(here, '..', '..', 'src', 'indexer.ts'))
const types = await loadModule(join(here, '..', '..', 'src', 'types.ts'))
const skip = notLoaded(indexer) || notLoaded(types)
const roots: string[] = []
const open: Array<{ close(): void }> = []

afterEach(() => {
  for (const index of open.splice(0)) {
    try { index.close() } catch { /* already closed */ }
  }
  for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true })
})

function pathFor(name = 'index.db'): string {
  const root = mkdtempSync(join(tmpdir(), 'msp-robust-'))
  roots.push(root)
  return join(root, name)
}

function record(seq: number, text: string, sessionId = 'ses-robust') {
  return {
    sessionId,
    seq,
    type: 'user/message',
    time: 1_700_000_000_000 + seq,
    surface: 'current',
    text,
    anchorKey: null,
  }
}

function create(options: Record<string, unknown> = {}) {
  const index = (indexer.mod!.createSearchIndex as any)({ dbPath: pathFor(), ...options }) as any
  open.push(index)
  return index
}

describe.skipIf(skip)('robustness and drift guards', () => {
  it.each([
    ['sqlite', {}],
    ['memory fallback', { sqliteModule: null, warn: () => {} }],
  ])('%s: out-of-order gap insert keeps materialized counts exact', async (_name, options) => {
    const idx = create(options)
    await idx.upsertRecords([record(10, 'alpha')])
    await idx.upsertRecords([record(5, 'beta')])
    expect(idx.status().indexedDocs).toBe(2)
    expect(idx.search('alpha').hits).toHaveLength(1)
    expect(idx.search('beta').hits).toHaveLength(1)
  })

  it.each([
    ['sqlite', {}],
    ['memory fallback', { sqliteModule: null, warn: () => {} }],
  ])('%s: an indexed empty session gets a durable state row', async (_name, options) => {
    const idx = create(options)
    await idx.upsertRecords([], ['empty-session'])
    expect(idx.sessionState('empty-session')).toMatchObject({ maxSeq: -1, docs: 0, dirty: 0 })
    expect(idx.status()).toMatchObject({ indexedSessions: 1, indexedDocs: 0 })
  })

  it.each([
    ['sqlite', {}],
    ['memory fallback', { sqliteModule: null, warn: () => {} }],
  ])('%s: structural-only suffix can advance the raw-event watermark', async (_name, options) => {
    const idx = create(options)
    await idx.upsertRecords([], ['structural-session'])
    idx.advanceSessionWatermark('structural-session', 42)
    expect(idx.sessionState('structural-session')).toMatchObject({ maxSeq: 42, docs: 0 })
  })

  it.each([
    ['sqlite', {}],
    ['memory fallback', { sqliteModule: null, warn: () => {} }],
  ])('%s: punctuation separators agree with FTS recall and highlighting', async (_name, options) => {
    const idx = create(options)
    await idx.upsertRecords([record(1, 'search chat')])
    const result = idx.search('search, chat')
    expect(result.ok).toBe(true)
    expect(result.hits).toHaveLength(1)
    expect(result.hits[0].spans.map(([s, e]: [number, number]) => result.hits[0].text.slice(s, e)))
      .toEqual(['search', 'chat'])
  })

  it.each([
    ['sqlite', {}],
    ['memory fallback', { sqliteModule: null, warn: () => {} }],
  ])('%s: literal refinement rejects reordered CJK bigram false positives', async (_name, options) => {
    const idx = create(options)
    await idx.upsertRecords([record(1, '甲乙在前，乙丙在后')])
    expect(idx.search('甲乙丙').hits).toHaveLength(0)
  })

  it.each([
    ['sqlite', {}],
    ['memory fallback', { sqliteModule: null, warn: () => {} }],
  ])('%s: invalid batch is rejected before any partial mutation', async (_name, options) => {
    const idx = create(options)
    await idx.upsertRecords([record(1, 'stable')])
    expect(() => idx.upsertRecords([
      record(2, 'must-not-appear'),
      { ...record(3, 'invalid'), seq: Number.NaN },
    ])).toThrow(/seq/)
    expect(idx.status().indexedDocs).toBe(1)
    expect(idx.search('must-not-appear').hits).toHaveLength(0)
  })

  it('oversized queries fail fast with a bounded error', async () => {
    const idx = create()
    const max = types.mod!.MAX_QUERY_CHARS as number
    const result = idx.search('x'.repeat(max + 1))
    expect(result).toMatchObject({ ok: false, hits: [], truncated: false })
    expect(result.error).toContain(String(max))
  })

  it('an incompatible-but-openable schema is backed up and rebuilt', () => {
    const dbPath = pathFor()
    const broken = new DatabaseSync(dbPath)
    broken.exec('CREATE VIRTUAL TABLE ftsevents USING fts5(tokens)')
    broken.close()
    const warnings: string[] = []
    const idx = (indexer.mod!.createSearchIndex as any)({ dbPath, warn: (message: string) => warnings.push(message) }) as any
    open.push(idx)
    expect(idx.degraded).toBe(false)
    expect(idx.status().indexedDocs).toBe(0)
    expect(readdirSync(dirname(dbPath)).some((name) => /^index\.db\.bak-\d+$/.test(name))).toBe(true)
    expect(warnings.some((message) => message.includes('坏库已备份'))).toBe(true)
  })

  it('a future schema is never moved or overwritten by an older plugin', () => {
    const dbPath = pathFor()
    const future = new DatabaseSync(dbPath)
    future.exec('PRAGMA user_version=99')
    future.close()
    const warnings: string[] = []
    const idx = (indexer.mod!.createSearchIndex as any)({
      dbPath,
      warn: (message: string) => warnings.push(message),
    }) as any
    open.push(idx)
    expect(idx.degraded).toBe(true)
    expect(readdirSync(dirname(dbPath)).some((name) => /^index\.db\.bak-\d+$/.test(name))).toBe(false)
    const unchanged = new DatabaseSync(dbPath)
    expect(unchanged.prepare('PRAGMA user_version').get()).toMatchObject({ user_version: 99 })
    unchanged.close()
    expect(warnings.some((message) => message.includes('未修改数据库'))).toBe(true)
  })

  it('v3 migration no longer depends on a damaged legacy event_keys helper', () => {
    const dbPath = pathFor()
    const broken = new DatabaseSync(dbPath)
    broken.exec('CREATE VIRTUAL TABLE ftsevents USING fts5(tokens, text UNINDEXED, session_id UNINDEXED, seq UNINDEXED, type UNINDEXED, time UNINDEXED, surface UNINDEXED, anchor_key UNINDEXED)')
    broken.exec('CREATE TABLE session_state(session_id TEXT PRIMARY KEY, max_seq INTEGER NOT NULL DEFAULT -1, dirty INTEGER NOT NULL DEFAULT 0, built_at INTEGER, docs INTEGER NOT NULL DEFAULT 0)')
    broken.exec('CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT)')
    broken.exec('CREATE TABLE event_keys(broken TEXT PRIMARY KEY)')
    broken.prepare("INSERT INTO meta(key,value) VALUES('event_keys_version','1')").run()
    broken.exec('PRAGMA user_version=2')
    broken.close()
    const idx = (indexer.mod!.createSearchIndex as any)({ dbPath, warn: () => {} }) as any
    open.push(idx)
    expect(idx.degraded).toBe(false)
    expect(readdirSync(dirname(dbPath)).some((name) => /^index\.db\.bak-\d+$/.test(name))).toBe(false)
    const check = new DatabaseSync(dbPath)
    expect(check.prepare("SELECT 1 FROM sqlite_master WHERE name='event_keys'").get()).toBeUndefined()
    expect(check.prepare('PRAGMA user_version').get()).toMatchObject({ user_version: 3 })
    check.close()
  })

  it('v1 database migrates its rowid map and remains deletable/searchable', async () => {
    const dbPath = pathFor()
    const old = new DatabaseSync(dbPath)
    old.exec('CREATE VIRTUAL TABLE ftsevents USING fts5(tokens, text UNINDEXED, session_id UNINDEXED, seq UNINDEXED, type UNINDEXED, time UNINDEXED, surface UNINDEXED, anchor_key UNINDEXED)')
    old.exec('CREATE TABLE session_state(session_id TEXT PRIMARY KEY, max_seq INTEGER NOT NULL DEFAULT -1, dirty INTEGER NOT NULL DEFAULT 0, built_at INTEGER, docs INTEGER NOT NULL DEFAULT 0)')
    old.exec('CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT)')
    old.prepare('INSERT INTO ftsevents(tokens,text,session_id,seq,type,time,surface,anchor_key) VALUES(?,?,?,?,?,?,?,?)')
      .run('legacy', 'legacy payload', 'legacy-session', 7, 'user/message', 7, 'current', null)
    old.prepare('INSERT INTO session_state VALUES(?,?,?,?,?)').run('legacy-session', 7, 0, 1, 1)
    old.exec('PRAGMA user_version=1')
    old.close()

    const idx = (indexer.mod!.createSearchIndex as any)({ dbPath }) as any
    open.push(idx)
    expect(idx.search('legacy').hits).toHaveLength(1)
    const migrated = new DatabaseSync(dbPath)
    expect(migrated.prepare('PRAGMA auto_vacuum').get()).toMatchObject({ auto_vacuum: 2 })
    expect(migrated.prepare("SELECT value FROM meta WHERE key='migration_vacuum_pending'").get())
      .toMatchObject({ value: '0' })
    migrated.close()
    idx.removeSession('legacy-session')
    expect(idx.status()).toMatchObject({ indexedSessions: 0, indexedDocs: 0 })
  })

  it('v2 migration repairs a partially missing session_state row without duplicates', async () => {
    const dbPath = pathFor()
    const old = new DatabaseSync(dbPath)
    old.exec('CREATE VIRTUAL TABLE ftsevents USING fts5(tokens, text UNINDEXED, session_id UNINDEXED, seq UNINDEXED, type UNINDEXED, time UNINDEXED, surface UNINDEXED, anchor_key UNINDEXED)')
    old.exec('CREATE TABLE session_state(session_id TEXT PRIMARY KEY, max_seq INTEGER NOT NULL DEFAULT -1, dirty INTEGER NOT NULL DEFAULT 0, built_at INTEGER, docs INTEGER NOT NULL DEFAULT 0)')
    old.exec('CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT)')
    old.exec('CREATE TABLE event_keys(session_id TEXT NOT NULL, seq INTEGER NOT NULL, rowid INTEGER NOT NULL, PRIMARY KEY(session_id,seq)) WITHOUT ROWID')
    const inserted = old.prepare('INSERT INTO ftsevents(tokens,text,session_id,seq,type,time,surface,anchor_key) VALUES(?,?,?,?,?,?,?,?)')
      .run('partial', 'partial state payload', 'partial-session', 9, 'user/message', 9, 'current', null)
    old.prepare('INSERT INTO event_keys VALUES(?,?,?)').run('partial-session', 9, inserted.lastInsertRowid)
    old.prepare("INSERT INTO meta(key,value) VALUES('event_keys_version','1')").run()
    old.exec('PRAGMA user_version=2')
    old.close()

    const idx = (indexer.mod!.createSearchIndex as any)({ dbPath }) as any
    open.push(idx)
    expect(idx.status()).toMatchObject({ indexedSessions: 1, indexedDocs: 1 })
    idx.upsertRecords([record(9, 'partial state replacement', 'partial-session')])
    expect(idx.status()).toMatchObject({ indexedSessions: 1, indexedDocs: 1 })
    expect(idx.search('replacement').hits).toHaveLength(1)
    expect(idx.search('payload').hits).toHaveLength(0)
  })

  it('offline and live surface rewrite events share one predicate', () => {
    const requires = types.mod!.requiresSurfaceRebuild as (event: unknown) => boolean
    expect(requires({ type: 'compaction/prune' })).toBe(true)
    expect(requires({
      type: 'user/message',
      data: { source: { kind: 'plugin', plugin: 'compact' } },
    })).toBe(true)
    expect(requires({ type: 'user/message', data: {} })).toBe(false)
    expect(requires(null)).toBe(false)
    expect(requires('malformed')).toBe(false)
  })

  it('optimize() 段合并 + WAL 截断，sqlite 与内存降级都不抛', async () => {
    const sqliteIdx = create()
    await sqliteIdx.upsertRecords([record(1, 'optimize-guard')])
    expect(() => sqliteIdx.optimize()).not.toThrow()
    sqliteIdx.close()

    const memoryIdx = create({ sqliteModule: null, warn: () => {} })
    await memoryIdx.upsertRecords([record(1, 'optimize-guard')])
    expect(() => memoryIdx.optimize()).not.toThrow()
    memoryIdx.close()
  })

  it('长文本按头尾预算入库：尾部错误仍可查，中段被省略且结果透明标记', async () => {
    const idx = create()
    const longText = `prefix ${'x'.repeat(4_300)} middleunique ${'x'.repeat(4_300)} suffix`
    await idx.upsertRecords([record(1, longText)])
    expect(idx.search('prefix').hits).toHaveLength(1)
    const tail = idx.search('suffix')
    expect(tail.hits).toHaveLength(1)
    expect(tail.hits[0].textTruncated).toBe(true)
    expect(idx.search('middleunique').hits).toHaveLength(0)
  })

  it('schema v3 separates contentless FTS postings from stored documents', async () => {
    const dbPath = pathFor()
    const idx = (indexer.mod!.createSearchIndex as any)({ dbPath }) as any
    await idx.upsertRecords([record(1, 'schema-v3 searchable')])
    idx.close()
    const db = new DatabaseSync(dbPath)
    const ftsSql = String(db.prepare("SELECT sql FROM sqlite_master WHERE name='ftsevents'").get()?.sql ?? '').toLowerCase()
    expect(ftsSql).toContain("content=''")
    expect(ftsSql).toContain('contentless_delete=1')
    expect(ftsSql).toContain('detail=none')
    expect(db.prepare('SELECT text,text_truncated FROM docs').get()).toMatchObject({
      text: 'schema-v3 searchable', text_truncated: 0,
    })
    expect(db.prepare('SELECT tokens FROM ftsevents').get()?.tokens).toBeNull()
    expect(db.prepare('PRAGMA auto_vacuum').get()).toMatchObject({ auto_vacuum: 2 })
    db.close()
  })

  it('logical storage budget evicts oldest derived rows without deleting session watermarks', async () => {
    const idx = create({ maxIndexBytes: 40_000 })
    const rows = Array.from({ length: 20 }, (_, i) => record(
      i,
      `marker-${i} ${'bounded payload '.repeat(360)}`,
      'budget-session',
    ))
    await idx.upsertRecords(rows)
    const status = idx.status()
    expect(status.prunedDocs).toBeGreaterThan(0)
    expect(status.indexedDocs).toBeLessThan(rows.length)
    expect(status.storageLimitBytes).toBe(40_000)
    expect(idx.search('marker 0').hits).toHaveLength(0)
    expect(idx.search('marker 19').hits).toHaveLength(1)
    expect(idx.sessionState('budget-session')?.maxSeq).toBe(19)
  })

  it('query cache is invalidated by writes', async () => {
    const idx = create()
    expect(idx.search('cachefresh').hits).toHaveLength(0)
    await idx.upsertRecords([record(1, 'cachefresh')])
    expect(idx.search('cachefresh').hits).toHaveLength(1)
  })

  it('cooperative micro-batch converges with a clean durable state', async () => {
    const idx = create()
    const cooperative = indexer.mod!.upsertRecordsCooperatively as (
      index: any, records: any[], rebuildIds: string[], batchSize: number,
    ) => Promise<void>
    const rows = Array.from({ length: 600 }, (_, i) => record(i, `cooperative-${i}`, 'cooperative-session'))
    await cooperative(idx, rows, ['cooperative-session'], 64)
    expect(idx.status().indexedDocs).toBe(600)
    expect(idx.sessionState('cooperative-session')).toMatchObject({ maxSeq: 599, docs: 600, dirty: 0 })
    expect(idx.search('cooperative 599').hits).toHaveLength(1)
  })

  it.each([
    ['sqlite', {}],
    ['memory fallback', { sqliteModule: null, warn: () => {} }],
  ])('%s: a rebuild transaction preserves a pre-existing crash-recovery marker', async (_name, options) => {
    const idx = create(options)
    await idx.upsertRecords([record(1, 'old value', 'dirty-session')])
    idx.markSessionDirty('dirty-session')
    await idx.upsertRecords([record(2, 'new value', 'dirty-session')], ['dirty-session'])
    expect(idx.sessionState('dirty-session')).toMatchObject({ dirty: 1, maxSeq: 2, docs: 1 })
    idx.clearSessionDirty('dirty-session')
    expect(idx.sessionState('dirty-session')).toMatchObject({ dirty: 0 })
  })

  it('fork 会话带 parentSession 不是子代理；只认 origin=subagent', () => {
    const isSubagent = types.mod!.isSubagentSession as (session: unknown) => boolean
    expect(isSubagent({
      header: { id: 'ses-fork', parentSession: 'ses-parent', origin: { kind: 'default' } },
    })).toBe(false)
    expect(isSubagent({
      header: { id: 'ses-fork', parentSession: 'ses-parent', origin: 'default' },
    })).toBe(false)
    expect(isSubagent({
      header: { id: 'ses-child', parentSession: 'ses-parent', origin: { kind: 'subagent' } },
    })).toBe(true)
    expect(isSubagent({
      id: 'ses-child',
      origin: 'subagent',
      parentSession: 'ses-parent',
    })).toBe(true)
    expect(isSubagent(null)).toBe(false)
    expect(isSubagent({ header: { id: 'ses-root', parentSession: null, origin: { kind: 'default' } } })).toBe(false)
  })
})
