/**
 * QA contract loader.
 *
 * Unit tests target the Host module contract pinned in tests/README.md
 * (「QA 测试契约」). Because the implementation lands in a parallel task
 * (implement-host), suites that depend on `../src/*` skip themselves when the
 * module is absent, so `npx vitest run` never crashes on a not-yet-written
 * module — but a skipped suite MUST be treated as a review blocker until it
 * executes green (see REVIEW.md).
 */

export interface LoadedModule {
  mod: Record<string, unknown> | null;
  error: string | null;
  path: string;
}

const cache = new Map<string, LoadedModule>();

export async function loadModule(specifier: string): Promise<LoadedModule> {
  if (!cache.has(specifier)) {
    let mod: Record<string, unknown> | null = null;
    let error: string | null = null;
    try {
      // 注意：不能使用 /* @vite-ignore */ —— 那会走 Node 原生 import，
      // 无法加载 .ts/.tsx（且绕过 vite 转换）。绝对路径交由 vite-node 解析。
      const imported = await import(specifier);
      mod = imported as Record<string, unknown>;
    } catch (err) {
      error = err instanceof Error ? `${err.name}: ${err.message}` : String(err);
    }
    cache.set(specifier, { mod, error, path: specifier });
  }
  return cache.get(specifier)!;
}

/** Vitest-safe skip condition helper: `describe.skipIf(notLoaded(x))`. */
export function notLoaded(loaded: LoadedModule): boolean {
  return loaded.mod === null;
}

export function missingMessage(loaded: LoadedModule, exports: string[]): string | null {
  if (loaded.mod !== null) return null;
  return [
    `module "${loaded.path}" could not be loaded (${loaded.error}).`,
    `expected exports: ${exports.join(', ')}.`,
    'see tests/README.md「QA 测试契约」.',
  ].join(' ');
}

export function hasExport(loaded: LoadedModule, name: string): boolean {
  return loaded.mod !== null && typeof loaded.mod[name] === 'function';
}
