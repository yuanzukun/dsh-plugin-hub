# ocr.ps1 - Windows built-in OCR: extract all text from an image file (or a screen capture) verbatim.
# Zero model, zero GPU, instant. Use this for pure text extraction; use the vision model only for understanding.
# Usage:
#   powershell -NoProfile -ExecutionPolicy Bypass -File ocr.ps1 -Image C:\path\x.png
#   powershell -NoProfile -ExecutionPolicy Bypass -File ocr.ps1            (capture screen first)
# Output: ONE line JSON  {"text":"...","lines":[...]}  or  {"error":"..."}
param(
    [string]$Image = ""
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function Out-JsonLine($obj) {
    Write-Output ($obj | ConvertTo-Json -Compress -Depth 8)
}

try {
    $pngPath = $Image
    if ($pngPath -eq "") {
        Add-Type -AssemblyName System.Windows.Forms, System.Drawing
        $bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
        $bmp = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
        $g.Dispose()
        $pngPath = [System.IO.Path]::GetTempFileName() + ".png"
        $bmp.Save($pngPath, [System.Drawing.Imaging.ImageFormat]::Png)
        $bmp.Dispose()
    } else {
        $pngPath = (Resolve-Path $Image).Path
    }

    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
    $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType=WindowsRuntime]
    $null = [Windows.Storage.StorageFile, Windows.Foundation, ContentType=WindowsRuntime]
    $null = [Windows.Storage.Streams.RandomAccessStream, Windows.Foundation, ContentType=WindowsRuntime]

    $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
    })[0]
    function Await($WinRtTask, $ResultType) {
        $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
        $netTask = $asTask.Invoke($null, @($WinRtTask))
        $netTask.Wait(-1) | Out-Null
        $netTask.Result
    }

    $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($pngPath)) ([Windows.Storage.StorageFile])
    $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
    if (-not $engine) {
        $lang = New-Object Windows.Globalization.Language('zh-Hans-CN')
        $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
    }
    if (-not $engine) { throw 'no OCR engine available for the user languages' }

    $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    $lines = @($result.Lines | ForEach-Object { $_.Text })
    Out-JsonLine @{ text = ($lines -join "`n"); lines = $lines }

    if ($Image -eq "" -and (Test-Path $pngPath)) { Remove-Item $pngPath -Force -ErrorAction SilentlyContinue }
    exit 0
} catch {
    Out-JsonLine @{ error = $_.Exception.Message }
    exit 1
}
