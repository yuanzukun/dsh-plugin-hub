# capture.ps1 - screenshot (or -Image) -> local OpenAI-compatible vision endpoint -> ONE line JSON
# Output on success:  {"description":"...","thinking":"..."}
# Output on failure:  {"error":"..."}
param(
    [string]$Prompt = "Describe only what is actually visible in this image. Do NOT guess or name the game, app, website, characters, people or products unless their name is clearly shown on screen as a label, logo or text. Never invent names, titles or context. Report observable facts only: quote visible text verbatim, and describe layout, colors, UI elements, objects and actions. If you are not extremely certain about an identity or label, describe what you see instead of naming it.",
    [string]$Model = "",
    [string]$BaseUrl = "http://127.0.0.1:1235/v1",
    [string]$Image = ""
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -AssemblyName System.Windows.Forms, System.Drawing

# High-DPI awareness: without this, CopyFromScreen on a scaled display captures
# a blurred, mis-sized image. Declaring per-process DPI awareness makes the
# virtual-screen coordinates match physical pixels.
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class DpiHelper { [DllImport("user32.dll")] public static extern bool SetProcessDPIAware(); }'
try { [void][DpiHelper]::SetProcessDPIAware() } catch { }

function Out-JsonLine($obj) {
    Write-Output ($obj | ConvertTo-Json -Compress -Depth 6)
}

try {
    if ($Image -eq "") {
        $bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
        $bmp = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
        $g.Dispose()
        $ms = New-Object System.IO.MemoryStream
        $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
        $bytes = $ms.ToArray()
        $bmp.Dispose(); $ms.Dispose()
        $mime = "image/png"
    } else {
        $resolved = (Resolve-Path $Image).Path
        $bytes = [System.IO.File]::ReadAllBytes($resolved)
        $ext = [System.IO.Path]::GetExtension($resolved).ToLower()
        if ($ext -eq ".jpg" -or $ext -eq ".jpeg") { $mime = "image/jpeg" }
        elseif ($ext -eq ".webp") { $mime = "image/webp" }
        elseif ($ext -eq ".gif") { $mime = "image/gif" }
        else { $mime = "image/png" }
    }

    $b64 = [Convert]::ToBase64String($bytes)
    $content = @(
        @{ type = "image_url"; image_url = @{ url = "data:$mime;base64,$b64" } },
        @{ type = "text";      text      = $Prompt }
    )
    $body = @{
        messages  = @(@{ role = "user"; content = $content })
        max_tokens = 2048
    }
    if ($Model -ne "") { $body.model = $Model }

    $resp = Invoke-RestMethod -Uri "$BaseUrl/chat/completions" -Method Post -ContentType "application/json" -Body ($body | ConvertTo-Json -Depth 8) -TimeoutSec 280
    $msg = $resp.choices[0].message
    $desc  = if ($msg.content)          { $msg.content }          else { "" }
    $think = if ($msg.reasoning_content) { $msg.reasoning_content } else { "" }
    Out-JsonLine @{ description = $desc; thinking = $think }
    exit 0
} catch {
    Out-JsonLine @{ error = $_.Exception.Message }
    exit 1
}
