# dsh-tool-eyes

[DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) (DSH) 的本地视觉"眼睛"插件。

给纯文本 Agent 加上两个模型侧工具:

- **`screen`** — 截屏(或描述已有图片),通过本地 OpenAI 兼容视觉端点(llama.cpp `--mmproj` / LM Studio / Ollama 等)返回视觉模型的文字描述。
- **`ocr`** — 用 **Windows 内置 OCR 引擎**逐字提取全部文字:**零模型、零 GPU、零云端、毫秒级**。

```
screen  =  截图 / 图片  ->  本地视觉模型  ->  文字描述(理解)
ocr     =  截图 / 图片  ->  Windows OCR  ->  逐字原文        (提取)
```

## 为什么

DeepSeek 的 chat-completions 是纯文本的。与其把整个对话切到视觉模型,不如保留文本大脑、用工具加眼睛:

- **默认私有** — `screen` 指向本地端点,图片不出本机。
- **便宜** — 0.8B~4B 的本地视觉模型描述屏幕绰绰有余;`ocr` 则完全零成本。
- **默认诚实** — `screen` 的提示词要求视觉模型"只描述所见、除非画面中有明确标签否则不猜应用/游戏/角色名",实测能显著减少小模型的名称幻觉。

## 环境要求

- Windows 10/11(`ocr` 使用 WinRT OCR;`screen` 用 .NET 截图)
- Node.js >= 22.19,DeepSeek Harness >= 0.1.0-rc.6
- `screen` 额外需要一个 OpenAI 兼容视觉端点,例如:
  - llama.cpp:`llama-server -m model.gguf --mmproj mmproj.gguf --port 1235`
  - LM Studio(已加载视觉模型)、Ollama,或任意 OpenAI 兼容网关

## 安装

> 本包**仅发布在 GitHub**(未发布到 npm)。

```sh
dsh plugin --profile web add https://github.com/go-farther-and-farther/dsh-tool-eyes
```

然后重启 `dsh web`,`screen` / `ocr` 工具会自动出现在 Agent 工具集中。

### 手动安装(离线 / 源码方式)

把本包复制到 profile 的 `node_modules`,并在 `$DSH_HOME/profiles/<profile>/cordis.patch.yml` 注册:

```yaml
- insert:
    - id: tool-eyes
      name: 'dsh-tool-eyes'
      config:
        baseUrl: http://127.0.0.1:1235/v1
        model: ''
        timeoutMs: 180000
```

## 配置

插件配置(全部可选):

| 键 | 默认值 | 含义 |
|---|---|---|
| `baseUrl` | `http://127.0.0.1:1235/v1` | `screen` 使用的 OpenAI 兼容端点 |
| `model` | `''` | 发送的模型 id;留空由服务端决定(llama.cpp 单模型服务) |
| `timeoutMs` | `180000` | 单次截图+推理的超时上限 |
| `captureScript` | 内置 `capture.ps1` | 替换截图脚本的绝对路径 |

在 profile 的 `cordis.patch.yml` 里按 id 覆盖:

```yaml
- id: tool-eyes
  name: 'dsh-tool-eyes'
  config:
    baseUrl: http://127.0.0.1:1235/v1
    model: qwen3.5-4b
    timeoutMs: 120000
```

## 用法

对话中 Agent 可以直接:

- `screen` — "看看我屏幕"、"描述这张图片",可用 `prompt` 聚焦某区域或细节。
- `ocr` — "把屏幕上的字全读出来"、"转写这个报错弹窗"。

两者都支持可选 `image` 路径;不填则截屏。内置 PowerShell 脚本也可单独使用:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File lib\capture.ps1 -Prompt "..." -BaseUrl http://127.0.0.1:1235/v1
powershell -NoProfile -ExecutionPolicy Bypass -File lib\ocr.ps1 -Image C:\path\x.png
```

## 隐私

- `ocr` 完全本地(WinRT OCR,无网络)。
- `screen` 会把截图发送到配置的 `baseUrl`;指向本地端点(llama.cpp / LM Studio / Ollama)即可保证图片不出本机。

## 相关项目

- [dsh-vision-proxy](https://github.com/Flyvhidbwo/dsh-vision-proxy) — 聊天输入框**直接贴图自动转文字**(Chatbox 式),无需给路径,与本插件互补。

## 开发

```sh
npm test    # node --test tests/
```

## 许可证

MIT
