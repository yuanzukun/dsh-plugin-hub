import { test } from "node:test";
import assert from "node:assert/strict";
import { buildScreenArgs, buildOcrArgs, lastJsonLine, parseScriptOutput } from "../lib/index.js";

const config = { baseUrl: "http://127.0.0.1:1235/v1", model: "" };

test("buildScreenArgs: defaults to configured baseUrl, no model when unset", () => {
	assert.deepEqual(buildScreenArgs({}, config), ["-BaseUrl", "http://127.0.0.1:1235/v1"]);
});

test("buildScreenArgs: includes prompt, image and model when provided", () => {
	const args = buildScreenArgs(
		{ prompt: "describe", image: "C:\\shot.png", model: "qwen3.5-4b", baseUrl: "http://127.0.0.1:1236/v1" },
		config
	);
	assert.deepEqual(args, [
		"-Prompt", "describe",
		"-Image", "C:\\shot.png",
		"-BaseUrl", "http://127.0.0.1:1236/v1",
		"-Model", "qwen3.5-4b"
	]);
});

test("buildScreenArgs: configured model is applied when the call omits it", () => {
	const args = buildScreenArgs({}, { baseUrl: "http://x/v1", model: "m" });
	assert.deepEqual(args, ["-BaseUrl", "http://x/v1", "-Model", "m"]);
});

test("buildOcrArgs: empty by default, image path when given", () => {
	assert.deepEqual(buildOcrArgs({}), []);
	assert.deepEqual(buildOcrArgs({ image: "C:\\a.png" }), ["-Image", "C:\\a.png"]);
});

test("lastJsonLine: takes the final non-empty line, tolerates CRLF and trailing newlines", () => {
	assert.equal(lastJsonLine("{\"a\":1}\n"), "{\"a\":1}");
	assert.equal(lastJsonLine("noise\n{\"a\":1}\r\n"), "{\"a\":1}");
	assert.equal(lastJsonLine(""), "");
	assert.equal(lastJsonLine(undefined), "");
});

test("parseScriptOutput: maps a successful JSON payload", () => {
	const value = parseScriptOutput(
		{ code: 0, stdout: "{\"description\":\"hello\",\"thinking\":\"hmm\"}\n", stderr: "" },
		"screen capture",
		(p) => ({ description: p.description, thinking: p.thinking })
	);
	assert.deepEqual(value, { description: "hello", thinking: "hmm" });
});

test("parseScriptOutput: throws with the reported script error", () => {
	assert.throws(
		() => parseScriptOutput(
			{ code: 1, stdout: "{\"error\":\"connection refused\"}\n", stderr: "" },
			"screen capture",
			(p) => p
		),
		/screen capture failed: connection refused/
	);
});

test("parseScriptOutput: reports no JSON when the script exits non-zero with empty stdout", () => {
	assert.throws(
		() => parseScriptOutput(
			{ code: 2, stdout: "", stderr: "boom" },
			"ocr",
			(p) => p
		),
		/ocr produced no JSON.*exit=2/s
	);
});

test("parseScriptOutput: throws when stdout is not JSON", () => {
	assert.throws(
		() => parseScriptOutput(
			{ code: 0, stdout: "not json at all", stderr: "" },
			"ocr",
			(p) => p
		),
		/ocr produced no JSON/
	);
});
