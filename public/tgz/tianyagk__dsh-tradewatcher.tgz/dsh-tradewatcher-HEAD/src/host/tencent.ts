/**
 */
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

/**
 * 东财 secid → 腾讯代码。
 * 覆盖：沪市(1.)、深市(0.)、港股(116.)。美股(105/106/107)、国际指数(100.)、
 * 商品/期货(101/113/114) 无法稳定映射，返回 null（这些标的仍只有东财源）。
 */
export function tencentCode(secid: string): string | null {
  const [market, code] = secid.split('.')
  if (market === undefined || code === undefined || code === '') return null
  if (market === '1') return `sh${code}`
  if (market === '0') return `sz${code}`
  if (market === '116') return `hk${code.padStart(5, '0')}`
  return null
}

export interface TencentQuote {
  secid: string
  price: number | null
  prev: number | null
  pct: number | null
  /** 当日累计成交额（元） */
  amount: number | null
  /** 行情时间戳（epoch ms） */
  ts: number | null
}

/** ⚠ 字符串解析（腾讯把数字给成字符串）——与 shared 的 `numOrNull` 语义不同，不合并（S7） */
const num = (v: string | undefined): number | null => {
  if (v === undefined) return null
  const n = Number(v.trim())
  return Number.isFinite(n) ? n : null
}

/** 时间戳：A股/ETF/指数为 "20260924161456"，港股为 "2026/09/24 16:14:56" */
export function parseTencentStamp(text: string | undefined): number | null {
  if (text === undefined) return null
  const t = text.trim()
  if (t.includes('/')) {
    const parsed = Date.parse(t.replace(/\//g, '-'))
    return Number.isFinite(parsed) ? parsed : null
  }
  if (t.length < 14) return null
  const iso = `${t.slice(0, 4)}-${t.slice(4, 6)}-${t.slice(6, 8)}T${t.slice(8, 10)}:${t.slice(10, 12)}:${t.slice(12, 14)}`
  const parsed = Date.parse(iso)
  return Number.isFinite(parsed) ? parsed : null
}

export interface TencentQuoteFull extends TencentQuote {
  name: string
  open: number | null
  high: number | null
  low: number | null
  /** 成交量（手；港股为股） */
  vol: number | null
  /** 总市值（元）：腾讯 f45，原始单位为**亿元** */
  totalMv: number | null
  /** 流通市值（元）：腾讯 f44，原始单位为**亿元** */
  floatMv: number | null
}

/** 完整批量行情（含名称/开高低/量），供自选与持仓的行情链路兜底使用 */
export async function fetchTencentQuoteRows(secids: string[]): Promise<Record<string, TencentQuoteFull>> {
  const map = new Map<string, string>()
  for (const secid of secids) {
    const code = tencentCode(secid)
    if (code !== null) map.set(code, secid)
  }
  if (map.size === 0) return {}
  const res = await fetch(`https://qt.gtimg.cn/q=${[...map.keys()].join(',')}`, {
    headers: { 'user-agent': UA, referer: 'https://gu.qq.com/' },
    signal: AbortSignal.timeout(8000),
  })
  if (!res.ok) throw new Error(`HTTP ${res.status} from qt.gtimg.cn`)
  const buf = await res.arrayBuffer()
  let text: string
  try {
    text = new TextDecoder('gbk').decode(buf)
  } catch {
    text = new TextDecoder('latin1').decode(buf)
  }
  const out: Record<string, TencentQuoteFull> = {}
  for (const line of text.split(';')) {
    const eq = line.indexOf('=')
    if (eq < 0) continue
    const code = line.slice(0, eq).trim().replace(/^v_/, '')
    const secid = map.get(code)
    if (secid === undefined) continue
    const raw = line.slice(eq + 1).trim().replace(/^"/, '').replace(/"$/, '')
    const f = raw.split('~')
    const tri = (f[35] ?? '').split('/')
    out[secid] = {
      secid,
      name: (f[1] ?? '').trim(),
      price: num(f[3]),
      prev: num(f[4]),
      open: num(f[5]),
      pct: num(f[32]),
      high: num(f[33]),
      low: num(f[34]),
      vol: num(f[6]),
      amount: num(tri[2]) ?? (num(f[37]) !== null ? (num(f[37]) as number) * 1e4 : null),
      // 市值字段：腾讯给的是**亿元**（实测 f44/f45 对 sh600519 = 15445.76 亿），统一乘 1e8 转元；
      // 指数/ETF 也有值（ETF 为基金规模），期货/国际指数无该字段 → null
      totalMv: num(f[45]) !== null ? (num(f[45]) as number) * 1e8 : null,
      floatMv: num(f[44]) !== null ? (num(f[44]) as number) * 1e8 : null,
      ts: parseTencentStamp(f[30]),
    }
  }
  return out
}

/** smartbox 返回的是带 \uXXXX 转义的 JS 字符串字面量，需反转义才能显示中文 */
export function unescapeUnicode(text: string): string {
  return text.replace(/\\u([0-9a-fA-F]{4})/g, (_m, hex: string) => String.fromCharCode(parseInt(hex, 16)))
}

/** 腾讯类型词表 → 与东财 suggestKind 对齐的展示口径 */
export function suggestKindFromTencent(marketKey: string, rawKind: string): string {
  if (marketKey === 'hk') return '港股'
  if (/ETF/i.test(rawKind)) return 'ETF'
  if (/ZS/i.test(rawKind)) return '指数'
  if (/LOF|FUND|JJ/i.test(rawKind)) return '基金'
  return '股票'
}

/** 日线（腾讯 fqkline，前复权）；用于位置与底部概率回算 */
export async function fetchTencentDaily(secid: string, count = 320): Promise<Array<{ date: string; open: number; close: number; high: number; low: number; vol: number }>> {
  const code = tencentCode(secid)
  if (code === null) return []
  const res = await fetch(`https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=${code},day,,,${count},qfq`, {
    headers: { 'user-agent': UA, referer: 'https://gu.qq.com/' },
    signal: AbortSignal.timeout(15000),
  })
  if (!res.ok) throw new Error(`HTTP ${res.status} from web.ifzq.gtimg.cn`)
  const j = (await res.json()) as { data?: Record<string, { qfqday?: string[][]; day?: string[][] }> }
  const arr = j?.data?.[code]?.qfqday ?? j?.data?.[code]?.day ?? []
  const out: Array<{ date: string; open: number; close: number; high: number; low: number; vol: number }> = []
  for (const r of arr) {
    const bar = { date: String(r[0]), open: Number(r[1]), close: Number(r[2]), high: Number(r[3]), low: Number(r[4]), vol: Number(r[5]) }
    if (!Number.isFinite(bar.close) || !(bar.close > 0) || !(bar.vol > 0)) continue
    out.push(bar)
  }
  return out
}

/** 腾讯板块排行（t=01 行业 / 02 概念 / 03 地域） */
export interface TencentBoardRow {
  code: string
  name: string
  /** 板块指数涨跌幅（%） */
  pct: number | null
  /** 板块指数点位 */
  price: number | null
  leader: string | null
  leaderPct: number | null
}

/**
 * 腾讯板块排行。东财行情 CDN（push2 系列）被限流/封锁时，板块与概念排行用它兜底；
 * 注意：**没有主力净流入**（资金流排行仅东财提供），该列会显示为 —
 */
export async function fetchTencentBoards(kind: 'industry' | 'concept', limit = 40): Promise<TencentBoardRow[]> {
  const t = kind === 'industry' ? '01/averatio' : '02/averatio'
  const res = await fetch(`https://proxy.finance.qq.com/ifzqgtimg/appstock/app/mktHs/rank?l=${limit}&p=1&t=${t}&ordertype=&o=0`, {
    headers: { 'user-agent': UA, referer: 'https://stockapp.finance.qq.com/' },
    signal: AbortSignal.timeout(10000),
  })
  if (!res.ok) throw new Error(`HTTP ${res.status} from proxy.finance.qq.com`)
  const j = (await res.json()) as { code?: number; data?: Array<Record<string, unknown>> }
  if (j?.code !== 0 || !Array.isArray(j.data)) return []
  const out: TencentBoardRow[] = []
  for (const it of j.data) {
    const name = String(it.bd_name ?? '').trim()
    const code = String(it.bd_code ?? '').trim()
    if (name === '' || code === '') continue
    out.push({
      code,
      name,
      pct: num(it.bd_zdf as string | undefined),
      price: num(it.bd_zxj as string | undefined),
      leader: it.nzg_name === undefined || it.nzg_name === '' ? null : String(it.nzg_name),
      leaderPct: num(it.nzg_zdf as string | undefined),
    })
  }
  return out
}

export interface TencentSuggestRow {
  secid: string
  code: string
  name: string
  kind: string
  market: string
}

/** 腾讯市场前缀 → 东财市场号（只覆盖能稳定映射的：沪/深/港股） */
const SUGGEST_MARKET: Record<string, { secid: string; market: string }> = {
  sh: { secid: '1', market: '1' },
  sz: { secid: '0', market: '0' },
  hk: { secid: '116', market: '116' },
}

/**
 * 腾讯智慧搜索（东财 searchapi 不可用时的备用源）。
 * 响应形如 `v_hint="sh~510300~沪深300ETF华泰柏瑞~hs300etfhtbr~ETF^sz~159919~…"`
 * 字段：市场~代码~名称~拼音~类型；多行以 ^ 分隔。
 */
export async function fetchTencentSuggest(query: string, limit = 10): Promise<TencentSuggestRow[]> {
  const q = query.trim()
  if (q === '') return []
  const res = await fetch(`https://smartbox.gtimg.cn/s3/?v=2&q=${encodeURIComponent(q)}&t=all`, {
    headers: { 'user-agent': UA, referer: 'https://stockapp.finance.qq.com/' },
    signal: AbortSignal.timeout(8000),
  })
  if (!res.ok) throw new Error(`HTTP ${res.status} from smartbox.gtimg.cn`)
  const buf = await res.arrayBuffer()
  let text: string
  try {
    text = new TextDecoder('gbk').decode(buf)
  } catch {
    text = new TextDecoder('latin1').decode(buf)
  }
  return parseTencentSuggest(text, limit)
}

/** 解析 smartbox 响应（纯函数，便于自检） */
export function parseTencentSuggest(payload: string, limit = 10): TencentSuggestRow[] {
  const m = /v_hint="([^"]*)"/.exec(payload)
  if (m === null) return []
  const out: TencentSuggestRow[] = []
  const seen = new Set<string>()
  for (const raw of m[1].split('^')) {
    const f = raw.split('~')
    const marketKey = (f[0] ?? '').toLowerCase()
    const code = (f[1] ?? '').trim()
    const name = unescapeUnicode((f[2] ?? '').trim())
    const kind = suggestKindFromTencent(marketKey, (f[4] ?? '').trim())
    const mapped = SUGGEST_MARKET[marketKey]
    if (mapped === undefined || code === '' || name === '' || !/^[A-Za-z0-9]{1,10}$/.test(code)) continue
    const secid = `${mapped.secid}.${code}`
    if (seen.has(secid)) continue
    seen.add(secid)
    out.push({ secid, code, name, kind, market: mapped.market })
    if (out.length >= limit) break
  }
  return out
}

/**
 * 腾讯逐分钟点 → `TrendPoint`（**纯函数**，便于直接把"推导值"这件事断言死）。
 *
 * 关键映射（与上游实测结构对应）：
 *   - 上游每行 = `HHMM 价格 累计成交量(手) [累计成交额(元)]` —— **累计**，不是每分钟增量；
 *   - `TrendPoint.amount` 的口径是**每分钟**成交额（东财 trends2 就是每分钟）⇒ 这里做**差分**；
 *   - 每个带成交额的点都挂 `amountDerived: true` + `amountNote`：**这是推导值，不是上游直给的分钟额**；
 *   - 累计值回退/缺失 ⇒ 该点 `amount: null`（不编、不用 0 顶替）；
 *   - `vol` 同样改成每分钟手数（与东财口径一致）。
 *
 * 返回 `points`（可直接进 `TrendData.points`）与 `allDerived`（是否每个成交额点都是推导来的）。
 */
export function minuteTrendPointsOf(
  raw: readonly TencentMinutePoint[],
  tsLabel: (ts: number) => string,
): { points: Array<Record<string, unknown>>; allDerived: boolean } {
  const points: Array<Record<string, unknown>> = []
  let prevAmount = 0
  let prevVol = 0
  let amountPoints = 0
  let derivedPoints = 0
  for (const p of raw) {
    if (typeof p.price !== 'number' || !(p.price > 0)) continue
    const cumVol = typeof p.cumVol === 'number' && Number.isFinite(p.cumVol) ? p.cumVol : null
    const cumAmount = typeof p.amount === 'number' && Number.isFinite(p.amount) ? p.amount : null
    const minuteAmount = cumAmount !== null && cumAmount >= prevAmount
      ? Math.round((cumAmount - prevAmount) * 100) / 100
      : null
    const minuteVol = cumVol !== null && cumVol >= prevVol ? Math.round((cumVol - prevVol) * 100) / 100 : null
    if (cumAmount !== null && cumAmount >= prevAmount) prevAmount = cumAmount
    if (cumVol !== null && cumVol >= prevVol) prevVol = cumVol
    const avg = cumVol !== null && cumVol > 0 && cumAmount !== null ? cumAmount / (cumVol * 100) : null
    if (minuteAmount !== null) {
      amountPoints += 1
      derivedPoints += 1
      points.push({
        t: p.ts, label: tsLabel(p.ts), price: p.price, avg, vol: minuteVol, amount: minuteAmount,
        amountDerived: true,
        amountNote: '腾讯逐分钟只给累计成交额 ⇒ 每分钟成交额由相邻累计值差分得到（推导值，非上游直给的分钟额）',
      })
    } else {
      points.push({ t: p.ts, label: tsLabel(p.ts), price: p.price, avg, vol: minuteVol, amount: null })
    }
  }
  return { points, allDerived: amountPoints > 0 && amountPoints === derivedPoints }
}

export interface TencentMinutePoint {
  ts: number
  /** 当日累计成交额（元） */
  amount: number
  /** 该分钟价格（分时图兜底用） */
  price?: number
  /** 当日累计成交量（手） */
  cumVol?: number
}

/** 当日分钟线 → 累计成交额序列（HHmm 从 09:30 至 15:00） */
export async function fetchTencentMinutes(secid: string): Promise<TencentMinutePoint[]> {
  const code = tencentCode(secid)
  if (code === null) return []
  const res = await fetch(`https://web.ifzq.gtimg.cn/appstock/app/minute/query?code=${code}`, {
    headers: { 'user-agent': UA, referer: 'https://gu.qq.com/' },
    signal: AbortSignal.timeout(8000),
  })
  if (!res.ok) throw new Error(`HTTP ${res.status} from web.ifzq.gtimg.cn`)
  const j = (await res.json()) as { data?: Record<string, { data?: { date?: string; data?: string[] } }> }
  const body = j?.data?.[code]?.data
  const date = body?.date ?? ''
  const rows = Array.isArray(body?.data) ? body.data : []
  if (date.length < 8 || rows.length === 0) return []
  const day = `${date.slice(0, 4)}-${date.slice(4, 6)}-${date.slice(6, 8)}`
  const points: TencentMinutePoint[] = []
  for (const row of rows) {
    const parts = row.split(' ')
    const hhmm = parts[0] ?? ''
    if (hhmm.length < 4) continue
    if (hhmm < '0930' || hhmm > '1500') continue
    const amount = num(parts[3]) // 累计成交额（不是每分钟增量）
    if (amount === null || !(amount > 0)) continue
    const t = Date.parse(`${day}T${hhmm.slice(0, 2)}:${hhmm.slice(2, 4)}:00`)
    if (Number.isFinite(t)) points.push({ ts: t, amount, price: num(parts[1]), cumVol: num(parts[2]) })
  }
  return points
}
