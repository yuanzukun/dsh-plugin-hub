/**
 * 全球五市场「宽基 ETF 规模权重」数据层（工具箱 → 工具①「全球资金流蛋糕模型」）。
 *
 * ── 口径（用户已定，写死在代码里；**改口径必须先改这里 + 口径标识 + docs**）──────────
 *  成分 v2（2026-10-12 用户改口径）= **A股、港股、美国、日本、韩国**；口径标识 `FLOW_SCOPE`；
 *  旧成分（美股/欧股/日股/A股/新兴市场，v1）**已废弃**，相关历史见 docs/AUDIT-IMPL45.md 与
 *  docs/AUDIT-IMPL47.md（变更依据、逐市场可得性实测）。
 *
 *  ① **份额 = 该市场规模 ÷ Σ 有值市场规模**。分母只含**有值**的市场：某个市场取不到数时，
 *     它既不做分子也不做分母，并在该行如实显示「未取到 + 原因」⇒ 有值部分的份额合计恒为 100%
 *     （±0.1 显示位）。**绝不用 0 补位**（0 会被读成"这个市场没有规模"）。
 *  ② **规模 = 该市场宽基 ETF 的规模**：A股 510300（新浪 ETF 节点 `nmc`，万元，人民币）、
 *     港股 02800 盈富基金（腾讯 `f45` 总市值，**亿港元**）、美国 SPY 与 日本 EWJ
 *     （新浪 `gb_*` 的「总市值」，美元；缺失时兜底腾讯 `f71` 股本 × 最新价）、
 *     韩国 EWY（腾讯 `f71` 股本 × 最新价 —— 新浪 `gb_ewy` 的「总市值」实测恒为 0）。
 *  ③ **币种必须统一**：A股人民币 → `fx_susdcny`，港股港元 → `fx_susdhkd`，折成美元后再进分母。
 *     对应汇率取不到时**不许静默混算**：该市场规模按原币单列、不进美元合计，并如实标注口径不一致。
 *  ④ **动量 = 20/60/120 日收益率 + 横截面排序**：A股 沪深 300、港股 恒生指数（`hkHSI`）、美国 标普 500、
 *     日本 EWJ / 韩国 EWY（**KOSPI200 在腾讯与新浪都没有日线源**，实测四个候选代码全 `pv_none_match`）；
 *     分别算 20/60/120 个**该市场交易日**的收益率；
 *     每个口径先横截面排名（1 = 最强），综合分 = 各口径名次的均值，再按综合分排名。
 *     某市场某个口径样本不足 ⇒ 该项 null（不参与该口径排名），综合分只用能算出来的部分。
 *  ⑤ **A股净流入（`MoneyFlow.ssl_qsfx_zjlrqs` 的 20 日 netamount）单列，不参与份额/规模计算** ——
 *     它是"流量"，与"存量加权"是两种量纲；混算会把 20 天的净流入加进某一天的规模里。
 *  ⑥ 时间一律 `Asia/Shanghai`（`dayOf`）。**不显示"延迟 15 分钟"提示**（用户明确要求）。
 *
 * ── 数据来源（全部公开源；**不**用 Arkvol 数据、**不**标 Arkvol 来源）────────────────
 *   腾讯：`web.ifzq.gtimg.cn` 日线（美股 `us.INX`／A股 `sh000300`／`sh510300`／港股 `hk02800`／`hkHSI`）、
 *         `qt.gtimg.cn` 行情（港股 `hk02800` 的总市值；美股 ETF 的 `f71` 股本）
 *   新浪：`hq.sinajs.cn`（`gb_*` 规模、`fx_susdcny`/`fx_susdhkd` 汇率）、`vip.stock.finance.sina.com.cn`
 *         （ETF 节点 `nmc`、MoneyFlow 资金流）、`stock.finance.sina.com.cn`（美股 ETF 日线）
 *   所有新浪请求都带 `Referer: https://finance.sina.com.cn`（见 sina.ts）。
 *   **不走东财 `push2*`**（本机实测 0 成功率）；新浪 `int_*` 族仍禁用（陈旧快照 + 无时间戳）。
 *
 * ── 缓存/去重/快照（沿用仓库数据层规矩，见 docs/AUDIT-CACHE-1/-2）──────────────────
 *   · 三层 TTL，值小、TTL 长（用户明确要求"量小就大幅延长缓存"）：
 *       现价类（规模/汇率/资金流）30 分钟；日线类 12 小时；最终载荷 10 分钟（残缺时 2 分钟）；
 *   · **并发同键只在飞一份**（`cached` 里的 in-flight 合并）⇒ 并发两次请求上游只打一遍；
 *   · **失败不进缓存**（与仓库既有口径一致：缺口下一次调用会重试）；
 *   · **每日快照** `global-flow.json`：一天一条、保留 90 天（一天 ≈ 0.9KB ⇒ 90 天 ≈ 80KB，
 *     因此 TTL 可以放长）；快照供 30 日手动回放 —— 回放走本地文件，**不发任何上游请求**。
 *
 * ── 曲线口径（**必须写清，否则会被读成实测值**）────────────────────────────────────
 *   180 日份额曲线里：当天（以及任何有快照的日期）用**实测规模**（origin = observed）；
 *   其余历史日按 `当前实测规模 × 该市场日线收盘价之比` 重建（origin = rebuilt）——
 *   即**假定各 ETF 的份额数量不变**，因此曲线只反映**价格驱动的相对规模变化**，
 *   **不反映申赎**。跨市场交易日不同（A股与美股节假日不同）时按"最近一个已知收盘价"前向填充。
 */
import { readFile, stat } from 'node:fs/promises'
import { join } from 'node:path'
import type { MissingField } from '../shared/model.ts'
import { writeJsonAtomic } from './atomic.ts'
import { updateJsonLocked } from './lock.ts'
import { gatedFetch, HostBudget } from './robotsGate.ts'
import { log } from './context.ts'
import { isFirstBoot, quarantineFile, ReadGuard } from './readGuard.ts'
import { dataHome } from './store.ts'
import { fetchTencentDaily, fetchTencentRawQuotes } from './tencent.ts'
import { dayOf } from './time.ts'
import {
  fetchSinaEtfNodeSize,
  fetchSinaFxRate,
  fetchSinaGb,
  fetchSinaMoneyFlow,
  fetchSinaUsDaily,
  type SinaBar,
  type SinaMoneyFlowDay,
} from './sina.ts'

// ── 五市场定义（顺序 = 页面顺序；测试锁它） ────────────────────────────────────

export type FlowMarketKey = 'cn' | 'hk' | 'us' | 'jp' | 'kr'
/** 展示顺序 = 需求文档 T-5 的列举顺序（A股、港股、美国、日本、韩国）—— 断言逐字锁它 */
export const FLOW_MARKET_ORDER: readonly FlowMarketKey[] = ['cn', 'hk', 'us', 'jp', 'kr']

/**
 * 口径标识（写进快照文件）：五市场成分一变，**旧快照一律作废**（不许与新成分混用）。
 * v1（v0.72.0）= 美股/欧股/日股/A股/新兴市场；v2（本版）= A股/港股/美国/日本/韩国。
 */
export const FLOW_SCOPE = 'v3:pref:cn,hk,us,jp,kr'

export interface FlowMarketDef {
  key: FlowMarketKey
  name: string
  /** 规模口径标的（宽基 ETF） */
  etf: string
  /** 规模来源（出处块按"需要时才标"的原则，只在这张表里写一次） */
  aumSource: string
  /** 该市场规模的原币 */
  currency: 'USD' | 'CNY' | 'HKD'
  /** 动量口径标的 */
  benchmark: string
  benchmarkSource: string
}

/**
 * 五市场定义（用户口径 v2：A股、港股、美国、日本、韩国）。
 *
 * 规模取数路径（2026-10-12 本机实测，原始回包见 docs/AUDIT-IMPL47.md §1）：
 *   · A股 ：新浪 ETF 节点 `nmc`（510300，万元，人民币）—— 与腾讯 f45/f72 交叉一致
 *   · 港股：腾讯 `hk02800` 的 **f45「总市值」= 亿港元**（实测 1262.1791 亿港元；同字段对腾讯控股
 *           = 38716 亿港元、汇丰 25377 亿港元，与已知市值吻合 ⇒ 量纲确认）
 *   · 美国：新浪 `gb_spy` 的「总市值」（美元）；缺失时兜底腾讯 `usSPY` 的 f71（股本）× 最新价
 *   · 日本：新浪 `gb_ewj` 的「总市值」（美元）；缺失时兜底腾讯 `usEWJ` 的 f71 × 最新价
 *           （两条路径实测一致：97.375 × 243300000 = 236.91 亿美元 ↔ 新浪 236.913375 亿美元）
 *   · 韩国：**新浪 `gb_ewy` 的该字段实测为 0（不可用）** ⇒ 用腾讯 `usEWY` 的 f71（股本 142550000）
 *           × 最新价 = 243.4 亿美元（f71 与新浪「股本」字段同义：EWJ/SPY 两条路径都对得上）
 *
 * 动量口径：A股 沪深300（腾讯 sh000300）、港股 恒生指数（腾讯 hkHSI）、美国 标普 500（腾讯 us.INX）、
 * 日本/韩国 = EWJ / EWY 自身日线（**KOSPI200 在腾讯/新浪都没有日线** —— 实测 `us.KOSPI200`/`kr.KOSPI`/
 * `hkKOSPI200`/`us.KOSPI` 全 `pv_none_match`；新浪 `int_*` 族仍禁用）。
 */
export const FLOW_MARKETS: readonly FlowMarketDef[] = [
  { key: 'cn', name: 'A股', etf: '510300', aumSource: '新浪 ETF 节点 nmc（万元，人民币）', currency: 'CNY', benchmark: '沪深 300', benchmarkSource: '腾讯 sh000300 日线' },
  { key: 'hk', name: '港股', etf: '02800 盈富基金', aumSource: '腾讯 hk02800 总市值（亿港元）', currency: 'HKD', benchmark: '恒生指数', benchmarkSource: '腾讯 hkHSI 日线' },
  { key: 'us', name: '美国', etf: 'SPY', aumSource: '新浪 gb_spy 总市值（美元）', currency: 'USD', benchmark: '标普 500', benchmarkSource: '腾讯 us.INX 日线' },
  { key: 'jp', name: '日本', etf: 'EWJ', aumSource: '新浪 gb_ewj 总市值（美元）', currency: 'USD', benchmark: 'EWJ 日本宽基', benchmarkSource: '新浪美股日线 EWJ' },
  { key: 'kr', name: '韩国', etf: 'EWY', aumSource: '腾讯 usEWY 股本（f71）× 最新价（美元）', currency: 'USD', benchmark: 'EWY 韩国宽基', benchmarkSource: '新浪美股日线 EWY' },
]

/** 汇率对：原币 → 美元。美/日/韩 直接用美元 ETF ⇒ 不需要汇率 */
export const FLOW_FX_SYMBOLS: Record<'CNY' | 'HKD', string> = { CNY: 'fx_susdcny', HKD: 'fx_susdhkd' }
/** 原币 → 该币种的"1 美元值多少原币"的换算标签（口径行/行级原因用） */
export const FLOW_FX_LABEL: Record<'CNY' | 'HKD', string> = { CNY: '美元/人民币', HKD: '美元/港元' }

/** 规模（AUM）取数路径 */
type AumRoute =
  | { kind: 'sina-etf'; symbol: string }
  | { kind: 'sina-gb'; symbol: string; fallbackTencent: string }
  | { kind: 'tencent-quote'; code: string }
  | { kind: 'tencent-shares'; code: string }
const AUM_ROUTE: Record<FlowMarketKey, AumRoute> = {
  cn: { kind: 'sina-etf', symbol: 'sh510300' },
  hk: { kind: 'tencent-quote', code: 'hk02800' }, // 港股 f45 = 总市值（亿港元），走"市值字段"分支
  us: { kind: 'sina-gb', symbol: 'spy', fallbackTencent: 'usSPY' },
  jp: { kind: 'sina-gb', symbol: 'ewj', fallbackTencent: 'usEWJ' },
  kr: { kind: 'tencent-shares', code: 'usEWY' },
}
/** 需要从腾讯行情里拿 f45/f71 的**原码**（一次批量取，冷启动只多 1 次请求） */
const TENCENT_AUM_CODES: readonly string[] = ['hk02800', 'usSPY', 'usEWJ', 'usEWY']

/** 曲线重建用的价格序列（= 规模口径标的自身的日线） */
const CURVE_SYMBOL: Record<FlowMarketKey, { via: 'sina-us' | 'tencent'; symbol: string }> = {
  cn: { via: 'tencent', symbol: '1.510300' },
  hk: { via: 'tencent', symbol: '116.02800' },
  us: { via: 'sina-us', symbol: 'spy' },
  jp: { via: 'sina-us', symbol: 'ewj' },
  kr: { via: 'sina-us', symbol: 'ewy' },
}
/**
 * 动量口径：A股 沪深300；港股 恒生指数（`100.HSI` → 腾讯 `hkHSI`）；美国 标普500；
 * 日本/韩国 = 该 ETF 自身日线（KOSPI200 无日线源，见文件头实测）
 */
const MOMENTUM_SYMBOL: Record<FlowMarketKey, { via: 'sina-us' | 'tencent'; symbol: string }> = {
  cn: { via: 'tencent', symbol: '1.000300' },
  hk: { via: 'tencent', symbol: '100.HSI' },
  us: { via: 'tencent', symbol: '100.SPX' },
  jp: { via: 'sina-us', symbol: 'ewj' },
  kr: { via: 'sina-us', symbol: 'ewy' },
}

// ── TTL（用户要求：量小则大幅延长缓存） ───────────────────────────────────────

/** 现价类（规模/汇率/资金流）：30 分钟。规模是日级量，日内只会随价格小幅漂移 */
export const FLOW_QUOTE_TTL_MS = 30 * 60_000
/** 日线类：12 小时。日线一天只更新一次，跨夜后自动过期 */
export const FLOW_SERIES_TTL_MS = 12 * 60 * 60_000
/**
 * 最终载荷：全齐时 **12 分钟**；有缺项时 2 分钟（让恢复能很快被看见）。
 *
 * ⚠ 12 分钟是**按预算算出来的**，不是拍的（v0.91.1 用户裁决）：每主机预算 `HOST_BUDGET_MAX = 5 次/小时`
 * ⇒ 一次请求至少要摊到 `60 / 5 = 12` 分钟，否则一小时到点会把预算用满、第 6 次那一轮四块磁贴
 * 只能显示「未取到（预算用尽）」。**TTL 与预算的比值不许小于 12 分钟/次**（`globalFlow.test.ts` 钉住）。
 */
export const FLOW_PAYLOAD_TTL_MS = 12 * 60_000
export const FLOW_PAYLOAD_TTL_PARTIAL_MS = 2 * 60_000
/**
 * 曲线窗口（用户口径 v0.81.0）：**90 / 180 / 365 个序列日可切换**（分段控件在详情页 Hero 右上角）。
 *
 * 实现取舍：宿主**一次构建到最大窗口**（`FLOW_CURVE_WINDOW_MAX`），客户端在这条曲线上**本地切片**
 * 出 90 / 180 / 365 —— 切档不发请求、不重算份额，三个窗口天然共用同一条日线序列；
 * 代价是载荷大一点（≈ 每点 0.3KB × 365 ⇒ 约 105KB，本机 localhost 可接受）。
 */
export const FLOW_CURVE_WINDOWS: readonly number[] = [90, 180, 365]
/** 默认窗口（首次打开时的选中档） */
export const FLOW_CURVE_WINDOW = 180
/** 实际构建的窗口 = 最大档（客户端从它切片） */
export const FLOW_CURVE_WINDOW_MAX = 365
export const FLOW_REPLAY_DAYS = 30
/** 快照保留天数 */
export const FLOW_SNAPSHOT_KEEP_DAYS = 90
/** 轮动判定的最小幅度（百分点）：低于它就算"未见明确轮动" */
export const FLOW_ROTATION_MIN_PP = 0.05
/** 轮动/变化窗口（交易日 = 序列日） */
export const FLOW_ROTATION_WINDOW = 5
/** 快照落盘节流 */
const SNAPSHOT_WRITE_MIN_MS = 5 * 60_000

// ── 带 TTL + 在飞合并的取数层 ────────────────────────────────────────────────

interface CacheSlot {
  at: number
  value: unknown
}

const flowCache = new Map<string, CacheSlot>()
const flowInflight = new Map<string, Promise<unknown>>()
/** 最终载荷的独立缓存（TTL 取决于"这次有没有缺项"，所以不放进通用 `cached`） */
let payloadCache: { at: number; value: GlobalFlowPayload } | null = null

/** 测试钩子：清空缓存（断言"冷启动只打一遍上游"要用） */
export function __resetFlowCache(): void {
  flowCache.clear()
  flowInflight.clear()
  payloadCache = null
  lastSnapshotWriteAt = 0
}

/**
 * TTL + in-flight 合并。**失败不进缓存**（下一次调用会重新打上游）——
 * 与 `AUDIT-CACHE-1` 里"失败也进负缓存"的那几条不同：这里是低频日级数据，
 * 重试成本远低于把一次抖动锁 10 分钟。
 */
async function cached<T>(key: string, ttlMs: number, loader: () => Promise<T>): Promise<T> {
  const hit = flowCache.get(key)
  const now = Date.now()
  if (hit !== undefined && now - hit.at < ttlMs) return hit.value as T
  const flying = flowInflight.get(key)
  if (flying !== undefined) return (await flying) as T
  const started = loader().then(
    (value) => {
      flowCache.set(key, { at: Date.now(), value })
      flowInflight.delete(key)
      return value
    },
    (error) => {
      flowInflight.delete(key)
      throw error
    },
  )
  flowInflight.set(key, started as Promise<unknown>)
  return (await started) as T
}

// ── 纯计算：规模 → 份额、动量、横截面排名、轮动、曲线 ─────────────────────────

export interface FlowSeriesPoint {
  date: string
  close: number
}

/** 两条汇率（都是"1 美元 = 多少原币"）：人民币与港元 —— 任一缺失 ⇒ 该币种的市场不折算 */
export interface FlowRates {
  usdCny: number | null
  usdHkd: number | null
}

/**
 * 原币 → 美元；**汇率缺失时不许静默当成美元**（返回 null，调用方标口径不一致 + 该行给原因）。
 * 美/日/韩 用美股上市的 ETF ⇒ 天然美元，不需要汇率。
 */
export function toUsd(native: number | null, currency: 'USD' | 'CNY' | 'HKD', rates: FlowRates): number | null {
  if (native === null || !Number.isFinite(native) || native <= 0) return null
  if (currency === 'USD') return native
  const rate = currency === 'CNY' ? rates.usdCny : rates.usdHkd
  if (rate === null || !Number.isFinite(rate) || rate <= 0) return null
  return native / rate
}

// ── 权重口径（v0.82.0，用户口径：从"资产规模"改为"偏好分"）─────────────────────
//
// 为什么换：用 ETF 资产规模做权重时，SPY（约 8200 亿美元）比其余四家（各 200–300 亿美元）
// 大两个数量级 ⇒ 权重天然 91% 对几个 %，**曲线被压平**（用户 2026-10-13 反馈，参考版是
// 日本 34.9% / 韩国 22.0% / 美国 20.8% / A股 11.7% / 港股 10.6%）。参考版自述用的是
// 「市场情绪与趋势」，因此本口径改为**无量纲的偏好分**。
//
//   · 每市场「贪婪值」= 该市场**自身**最近 `FLOW_GREED_WINDOW`（60）根日线收盘价的区间分位
//     `(close − min₆₀) / (max₆₀ − min₆₀)` ∈ [0,1]（越高 = 越贴近这段时间的高位）；
//   · 每市场「偏好分」= `FLOW_PREF_WEIGHTS`：55% × 贪婪值 + 30% × 5 日动量**横截面分位**
//     + 15% × 20 日动量**横截面分位**（比例与参考版公开的那半句同形）；
//   · **份额 = 偏好分 ÷ 五者之和 × 100%**。
//
// 关键性质（有断言锁）：分位与动量都是**无量纲**的 ⇒ **权重不依赖汇率**；
// 汇率只影响"规模折成美元"的**展示**。三个分量任一算不出（样本不足）⇒ 该市场**不进分母**并给原因。

/** 贪婪值窗口（该市场自身日线的区间分位；写死，改口径要同步文档与断言） */
export const FLOW_GREED_WINDOW = 60
/** 偏好分权重（55% 贪婪 + 30% 5 日动量分位 + 15% 20 日动量分位） */
export const FLOW_PREF_WEIGHTS = { greed: 0.55, mom5: 0.3, mom20: 0.15 } as const
/** 动量分位的两个窗口（序列日） */
export const FLOW_PREF_MOM_WINDOWS = [5, 20] as const

/**
 * 贪婪值：收盘价在最近 `window` 根（含当日）里的区间分位 ∈ [0,1]。
 * 样本不足 `window` 根、或区间为 0、或有非有限值 ⇒ null（**不返回 0.5 之类的"中性默认值"**：
 * 那会把"算不出"伪装成"中性"，进而偷偷进分母）。
 */
export function greedOf(closes: ReadonlyArray<number | null>, window = FLOW_GREED_WINDOW): number | null {
  if (window < 2 || closes.length < window) return null
  const slice = closes.slice(closes.length - window)
  let min = Number.POSITIVE_INFINITY
  let max = Number.NEGATIVE_INFINITY
  for (const c of slice) {
    if (c === null || !Number.isFinite(c)) return null
    if (c < min) min = c
    if (c > max) max = c
  }
  const span = max - min
  if (!(span > 0)) return null
  const last = slice[slice.length - 1] as number
  return (last - min) / span
}

/**
 * 横截面分位（0–1）：把各市场的同一指标按"越大越好"排成名次再归一。
 * 名次 1（最大）⇒ 1，末位 ⇒ 0；并列取**平均名次**；缺值 ⇒ null。
 * 只有 1 个有值市场时无法比较 ⇒ 也给 null（"样本不足不进分母"这条规则在横截面上的对应形态）。
 */
export function percentileRanks(values: ReadonlyArray<number | null>): Array<number | null> {
  const idx = values.map((v, i) => ({ v, i })).filter((x): x is { v: number; i: number } => x.v !== null && Number.isFinite(x.v))
  if (idx.length < 2) return values.map(() => null)
  const sorted = [...idx].sort((a, b) => b.v - a.v)
  const score = new Map<number, number>()
  let i = 0
  while (i < sorted.length) {
    let j = i
    while (j + 1 < sorted.length && sorted[j + 1].v === sorted[i].v) j += 1
    // 名次区间 [i, j] 的平均名次 → 分位：最好的名次(0) ⇒ 1，最差(len-1) ⇒ 0
    const avgRank = (i + j) / 2
    const pct = 1 - avgRank / (sorted.length - 1)
    for (let k = i; k <= j; k += 1) score.set(sorted[k].i, pct)
    i = j + 1
  }
  return values.map((v, k) => (v === null || !Number.isFinite(v) ? null : (score.get(k) ?? null)))
}

/** 偏好分的三个分量；任一为 null ⇒ 偏好分 null（该市场不进分母） */
interface FlowPreferenceParts {
  greed: number | null
  mom5: number | null
  mom20: number | null
}

/** 偏好分 = 55% × 贪婪值 + 30% × 5 日动量分位 + 15% × 20 日动量分位 */
export function preferenceOf(parts: FlowPreferenceParts): number | null {
  const { greed, mom5, mom20 } = parts
  if (greed === null || mom5 === null || mom20 === null) return null
  if (!Number.isFinite(greed) || !Number.isFinite(mom5) || !Number.isFinite(mom20)) return null
  return FLOW_PREF_WEIGHTS.greed * greed + FLOW_PREF_WEIGHTS.mom5 * mom5 + FLOW_PREF_WEIGHTS.mom20 * mom20
}

/**
 * 由**偏好分**归一化成份额（0–1）。与 `sharesOf` 的关键差别：**0 是合法权重**
 * （贪婪值 0 且两个分位都垫底 ⇒ 偏好分真的可以是 0），因此这里只把 `null` 当缺值，
 * 不再用 `> 0` 当"有值"的判据（否则得 0 分的市场会被错误地踢出分母）。
 */
export function sharesFromScores(scores: ReadonlyArray<number | null>): Array<number | null> {
  let total = 0
  let any = false
  for (const v of scores) {
    if (v !== null && Number.isFinite(v) && v >= 0) {
      total += v
      any = true
    }
  }
  if (!any || total <= 0) return scores.map(() => null)
  return scores.map((v) => (v !== null && Number.isFinite(v) && v >= 0 ? v / total : null))
}

/**
 * 份额（0–1）：分母 = **有值市场**之和。全缺 ⇒ 全 null（不返回 0/1/N 这种假值）。
 * 除法后做一次"合计校验"由调用方断言（`sharesSumPct`）。
 *
 * ⚠ v0.82.0 起它**只用于"规模占比"的辅助展示**（例如审计对拍），**不再**用于权重：
 * 权重走 `sharesFromScores` + `preferenceOf`（偏好分口径）。
 */
export function sharesOf(aumUsd: ReadonlyArray<number | null>): Array<number | null> {
  let total = 0
  let any = false
  for (const v of aumUsd) {
    if (v !== null && Number.isFinite(v) && v > 0) {
      total += v
      any = true
    }
  }
  if (!any || total <= 0) return aumUsd.map(() => null)
  return aumUsd.map((v) => (v !== null && Number.isFinite(v) && v > 0 ? v / total : null))
}

/** 份额合计（百分点）：只累加有值的项；没有任何有值项 ⇒ null */
export function sharesSumPct(shares: ReadonlyArray<number | null>): number | null {
  let sum = 0
  let any = false
  for (const s of shares) {
    if (s !== null && Number.isFinite(s)) {
      sum += s
      any = true
    }
  }
  return any ? sum * 100 : null
}

export interface FlowMomentum {
  d20: number | null
  d60: number | null
  d120: number | null
}

/** 三个口径的日数（写死；改口径要同步文档与断言） */
export const FLOW_HORIZONS = [20, 60, 120] as const

/** 某市场自己的第 idx 根 bar 往回 n 根的收益率；样本不足 ⇒ null（不外推） */
export function momentumOf(series: readonly FlowSeriesPoint[]): FlowMomentum {
  const out: FlowMomentum = { d20: null, d60: null, d120: null }
  if (series.length === 0) return out
  const last = series[series.length - 1]
  const ret = (n: number): number | null => {
    const idx = series.length - 1 - n
    if (idx < 0) return null
    const base = series[idx].close
    if (!(base > 0) || !(last.close > 0)) return null
    return (last.close / base - 1) * 100
  }
  out.d20 = ret(FLOW_HORIZONS[0])
  out.d60 = ret(FLOW_HORIZONS[1])
  out.d120 = ret(FLOW_HORIZONS[2])
  return out
}

/**
 * 横截面排名（1 = 最强）。
 *
 * 规则（写死）：每个口径各自排名（并列同名次：相同值给相同名次，名次按"比它强的有几个 + 1"），
 * 综合分 = 各**能算出**的口径名次的均值（算不出的不参与）；再按综合分排名。
 * 一个口径都算不出来 ⇒ 该市场 null。
 */
export function momentumRanks(mom: ReadonlyArray<FlowMomentum | null>): Array<number | null> {
  const horizons: Array<keyof FlowMomentum> = ['d20', 'd60', 'd120']
  return momentumRanksWith(mom, horizons)
}

function momentumRanksWith(mom: ReadonlyArray<FlowMomentum | null>, horizons: ReadonlyArray<keyof FlowMomentum>): Array<number | null> {
  const n = mom.length
  const composite: Array<number | null> = new Array(n).fill(null)
  const sum = new Array<number>(n).fill(0)
  const cnt = new Array<number>(n).fill(0)
  for (const h of horizons) {
    const vals = mom.map((m) => (m === null ? null : m[h]))
    const present = vals.filter((v): v is number => v !== null && Number.isFinite(v))
    for (let i = 0; i < n; i += 1) {
      const v = vals[i]
      if (v === null || !Number.isFinite(v)) continue
      // 并列取"最靠前"的名次（比它强的数量 + 1）
      const better = present.filter((p) => p > v).length
      sum[i] += better + 1
      cnt[i] += 1
    }
  }
  for (let i = 0; i < n; i += 1) if (cnt[i] > 0) composite[i] = sum[i] / cnt[i]
  const presentC = composite.filter((c): c is number => c !== null)
  if (presentC.length === 0) return composite.map(() => null)
  return composite.map((c) => {
    if (c === null) return null
    return presentC.filter((p) => p < c).length + 1
  })
}

export type FlowRotationKind = 'rotation' | 'flat' | 'unknown'

export interface FlowRotation {
  kind: FlowRotationKind
  /** 份额下降最多（资金"从"这里走） */
  fromKey: FlowMarketKey | null
  /** 份额上升最多 */
  toKey: FlowMarketKey | null
  /** 窗口内最大变动绝对值（百分点）；判不出来 ⇒ null */
  maxAbsPp: number | null
  /** 可比市场数（两侧都有值的市场） */
  comparable: number
  window: number
  text: string
}

/**
 * 5 日轮动：比较"最新一日"与"5 个序列日之前"的份额，取增幅最大与降幅最大的两个市场。
 * 无明确轮动（两侧幅度都 < `FLOW_ROTATION_MIN_PP`，或只有不到 2 个可比市场）时给**等价文案**，
 * 不许硬凑一个"从 X 转向 Y"。
 */
export function rotationOf(input: {
  latest: ReadonlyArray<number | null>
  previous: ReadonlyArray<number | null> | null
  window?: number
}): FlowRotation {
  const window = input.window ?? FLOW_ROTATION_WINDOW
  const prev = input.previous
  if (prev === null) {
    return { kind: 'unknown', fromKey: null, toKey: null, maxAbsPp: null, comparable: 0, window, text: `序列里还没有 ${window} 个交易日之前的点 ⇒ 本轮判不了轮动（不是"没有轮动"）` }
  }
  const deltas: Array<{ key: FlowMarketKey; d: number }> = []
  for (let i = 0; i < FLOW_MARKET_ORDER.length; i += 1) {
    const a = input.latest[i]
    const b = prev[i]
    if (a === null || b === null || a === undefined || b === undefined) continue
    deltas.push({ key: FLOW_MARKET_ORDER[i], d: (a - b) * 100 })
  }
  if (deltas.length < 2) {
    return { kind: 'unknown', fromKey: null, toKey: null, maxAbsPp: null, comparable: deltas.length, window, text: `两侧都有份额的市场只有 ${deltas.length} 个 ⇒ 本轮判不了轮动（不是"没有轮动"）` }
  }
  const up = deltas.reduce((m, x) => (x.d > m.d ? x : m))
  const down = deltas.reduce((m, x) => (x.d < m.d ? x : m))
  const maxAbs = Math.max(Math.abs(up.d), Math.abs(down.d))
  const name = (k: FlowMarketKey): string => FLOW_MARKETS.find((m) => m.key === k)?.name ?? k
  if (up.d < FLOW_ROTATION_MIN_PP || down.d > -FLOW_ROTATION_MIN_PP) {
    return {
      kind: 'flat',
      fromKey: null,
      toKey: null,
      maxAbsPp: maxAbs,
      comparable: deltas.length,
      window,
      text: `近 ${window} 个交易日各市场份额基本持平（最大变动 ${signedPp(up.d >= -down.d ? up.d : down.d)}，低于 ${FLOW_ROTATION_MIN_PP}pp 的判定线）⇒ 未见明确轮动`,
    }
  }
  return {
    kind: 'rotation',
    fromKey: down.key,
    toKey: up.key,
    maxAbsPp: maxAbs,
    comparable: deltas.length,
    window,
    text: `从 ${name(down.key)} 转向 ${name(up.key)}（${window} 日份额 ${signedPp(down.d)} → ${signedPp(up.d)}）`,
  }
}

/** 带符号的百分点文本（+0.41pp / -0.62pp） */
export function signedPp(n: number): string {
  const sign = n > 0 ? '+' : n < 0 ? '-' : ''
  return `${sign}${Math.abs(n).toFixed(2)}pp`
}

/**
 * 等间隔对齐：把各市场序列按日期并集（可再并入 `extraDays`，例如实测快照日）对齐，
 * 缺口用**最近一个已知收盘价**前向填充；只保留最后的 `window` 个日期。
 *
 * 为什么按日期并集：五个市场的交易日历不同（A股与美股节假日不同），用并集 + 前向填充
 * 是"同一天看同一屏"的唯一自洽做法（另一条路是各市场各自画，那就没法比份额）。
 */
export function alignSeries(
  series: ReadonlyArray<readonly FlowSeriesPoint[] | null>,
  window: number,
  extraDays: readonly string[] = [],
): { days: string[]; closes: Array<Array<number | null>> } {
  const axisSet = new Set<string>(extraDays)
  for (const s of series) for (const p of s ?? []) axisSet.add(p.date)
  const allDays = [...axisSet].sort()
  const days = allDays.slice(Math.max(0, allDays.length - window))
  const closes = series.map((s) => {
    const out: Array<number | null> = new Array(days.length).fill(null)
    if (s === null || s.length === 0) return out
    const sorted = [...s].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0))
    let idx = -1
    let last: number | null = null
    for (let i = 0; i < days.length; i += 1) {
      while (idx + 1 < sorted.length && sorted[idx + 1].date <= days[i]) {
        idx += 1
        last = sorted[idx].close
      }
      out[i] = last
    }
    return out
  })
  return { days, closes }
}

/**
 * 逐日计算各市场的偏好分与份额（**无量纲**：只用各市场自己的日线收盘价）。
 *
 * 输入是 `alignSeries` 对齐后的收盘价矩阵（每个市场一条、同一天一条，节假日按"最近一个已知收盘价"前向填充），
 * 输出与 `days` 一一对应：`scores[i][m]` = 第 i 天第 m 个市场的偏好分（null = 样本不足 ⇒ 不进分母）。
 *
 * 每一天都用**那一天为止**的窗口：贪婪值 = 当日往前 `FLOW_GREED_WINDOW` 根的区间分位，
 * 5/20 日动量 = 当日往前 5/20 根的收益率（再在同一天做横截面分位）⇒ 曲线是**可复现**的纯函数，
 * 不吃快照、不吃汇率、不吃"当前实测规模"。
 */
export function preferenceScoresByDay(closes: ReadonlyArray<ReadonlyArray<number | null>>): Array<Array<number | null>> {
  const days = closes.length > 0 ? closes[0].length : 0
  const [w5, w20] = FLOW_PREF_MOM_WINDOWS
  const out: Array<Array<number | null>> = []
  for (let i = 0; i < days; i += 1) {
    const greed = closes.map((c) => greedOf(c.slice(0, i + 1)))
    const ret = (w: number): Array<number | null> =>
      closes.map((c) => {
        const now = c[i]
        const then = i - w >= 0 ? c[i - w] : null
        if (now === null || then === null || !Number.isFinite(now) || !Number.isFinite(then) || !(then > 0)) return null
        return now / then - 1
      })
    const mom5 = percentileRanks(ret(w5))
    const mom20 = percentileRanks(ret(w20))
    out.push(closes.map((_, m) => preferenceOf({ greed: greed[m], mom5: mom5[m], mom20: mom20[m] })))
  }
  return out
}

export interface FlowPoint {
  day: string
  origin: 'observed' | 'rebuilt'
  /** 各市场规模（美元，**只作展示**），顺序 = FLOW_MARKET_ORDER */
  aumUsd: Array<number | null>
  /** 各市场**偏好分**（0–1；null = 样本不足 ⇒ 不进分母） */
  pref: Array<number | null>
  /** 各市场**偏好份额**（0–1）：由偏好分归一化，**不是**规模占比 */
  share: Array<number | null>
  /**
   * 该日是否有缺口：**权重缺口**（偏好分算不出）或**规模缺口**（规模列没有值）。
   * 两者要分开看：规模缺不影响权重（分母照旧），但这一天的"规模列"确实不完整 ⇒ 都算 partial。
   */
  partial: boolean
}

export interface ObservedDay {
  at: number
  rates: FlowRates
  /** 各市场**原币**规模 */
  aumNative: Array<number | null>
}

/**
 * 建曲线。
 *
 * · **份额（曲线画的就是它）= 偏好分归一化**：逐日由各市场自己的日线算出贪婪值 / 5 日与 20 日动量分位
 *   （见 `preferenceScoresByDay`）⇒ 与规模、汇率**无关**，因此不会出现"SPY 一家 91% 把曲线压平"。
 * · **规模（只作展示）**：有实测快照的日期用实测（origin = observed），其余用
 *   `当前实测规模 × 该市场收盘价 / 该市场最新收盘价` 重建（origin = rebuilt）。
 *
 * `anchors` = 各市场**当前实测**美元规模；null 表示该市场当前取不到 ⇒ 该日规模列为 null
 * （**不做任何替代**：宁可这一行整段"未取到"，也不拿价格变动冒充规模）。
 */
export function buildCurve(input: {
  anchors: ReadonlyArray<number | null>
  chartSeries: ReadonlyArray<readonly FlowSeriesPoint[] | null>
  observed: ReadonlyMap<string, ObservedDay>
  marketCurrency: ReadonlyArray<'USD' | 'CNY' | 'HKD'>
  window?: number
}): FlowPoint[] {
  const window = input.window ?? FLOW_CURVE_WINDOW
  // 轴 = 各市场交易日 ∪ 快照日（快照日可能落在周末/节假日，不并进来就会丢掉那一天的实测值）。
  // ⚠ 多对齐 `FLOW_GREED_WINDOW` 天作为**热身窗口**：贪婪值要往前看 60 根，否则曲线最前面
  //    约 60 天会因为没有足够样本而拿不到偏好分（那一段会整段空掉）。热身段只用于提供历史窗口，
  //    不进输出 ⇒ 输出的点数仍然正好是 `window`。
  const warmup = FLOW_GREED_WINDOW
  const { days: allDays, closes } = alignSeries(input.chartSeries, window + warmup, [...input.observed.keys()])
  const startIdx = Math.max(0, allDays.length - window)
  const days = allDays.slice(startIdx)
  const anchors = input.chartSeries.map((s, i) => {
    const aum = input.anchors[i]
    if (aum === null || !(aum > 0)) return null
    if (s === null || s.length === 0) return null
    const sorted = [...s].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0))
    const lastClose = sorted[sorted.length - 1].close
    if (!(lastClose > 0)) return null
    return { aum, lastClose }
  })
  // 份额 = 偏好分归一化（无量纲：只看各市场自己的日线，不吃汇率、不吃规模）
  const prefAll = preferenceScoresByDay(closes)
  const prefByDay = prefAll.slice(startIdx)
  const points: FlowPoint[] = []
  for (let i = 0; i < days.length; i += 1) {
    const day = days[i]
    const obs = input.observed.get(day)
    let aumUsd: Array<number | null>
    let origin: 'observed' | 'rebuilt'
    if (obs !== undefined) {
      // 实测日：规模用实测值。那次缺哪个市场就是缺哪个（**不拿重建值去补实测日的洞**）
      origin = 'observed'
      aumUsd = obs.aumNative.map((native, m) => toUsd(native, input.marketCurrency[m], obs.rates))
    } else {
      origin = 'rebuilt'
      aumUsd = anchors.map((a, m) => {
        if (a === null) return null
        const c = closes[m][i + startIdx]
        // 该市场在这一天还没有任何收盘价（序列比别的市场短）⇒ 该日这一行没有值
        if (c === null) return null
        return a.aum * (c / a.lastClose)
      })
    }
    const pref = prefByDay[i] ?? closes.map(() => null)
    const share = sharesFromScores(pref)
    points.push({ day, origin, aumUsd, pref, share, partial: pref.some((v) => v === null) || aumUsd.some((v) => v === null) })
  }
  return points
}

// ── 快照文件（一天一条，保留 90 天） ─────────────────────────────────────────

export interface FlowSnapshotMarket {
  aumNative: number | null
  aumUsd: number | null
  /** 该市场当日的**偏好分**（0–1；权重口径 v0.82.0 起：快照模式没有日线可算，必须存下来） */
  pref?: number | null
  /** 该市场当日的**偏好份额**（0–1，由偏好分归一化；不是规模占比） */
  share: number | null
  currency: 'USD' | 'CNY' | 'HKD'
  aumSource: string
}

export interface FlowSnapshotDay {
  at: number
  rates: FlowRates
  /** 该记录所属的口径（`FLOW_SCOPE`）—— 成分一变，**当天起就不再采用旧记录** */
  scope: string
  markets: Record<FlowMarketKey, FlowSnapshotMarket>
  momentum: Record<FlowMarketKey, FlowMomentum | null>
  ranks: Record<FlowMarketKey, number | null>
  totalUsd: number | null
  rotationText: string
  missing: string[]
}

/** 口径不一致而被作废的旧快照记录（留痕，不删数据） */
export interface FlowSnapshotPurged {
  day: string
  scope: string | null
  reason: string
}

export interface FlowSnapshotFile {
  v: 2
  /** 文件级口径标识（与 `FLOW_SCOPE` 不一致 ⇒ 整份 days 作废并留痕） */
  scope: string
  days: Record<string, FlowSnapshotDay>
  /** 作废留痕（口径变更/不可解析的记录；只增不删，供事后核对） */
  purged?: FlowSnapshotPurged[]
  /** 最近一次落盘时刻（本机） */
  writtenAt?: number
}

export function flowSnapshotPath(): string {
  return join(dataHome(), 'global-flow.json')
}

let purgedFromOldScope: FlowSnapshotPurged[] = []

/** 本进程本次装载时因"口径不一致"被作废的旧快照记录（自检/断言用） */
export function flowSnapshotPurged(): readonly FlowSnapshotPurged[] {
  return purgedFromOldScope
}

/**
 * 「读不到」≠「空快照」（R1）：global-flow.json 读失败（非 ENOENT）时**禁止写回** ——
 * 否则 `writeFlowSnapshot()` 会拿"空 days"整份覆写，90 天历史当场消失（实测复现）。
 * 键用完整路径（同一个进程里不同 DSH_HOME 互不影响）。
 */
const flowReadGuard = new ReadGuard()

/** 本次启动"读不到"的快照文件与原因（R1 披露/断言用） */
export function flowReadFailures(): ReadonlyArray<{ file: string; reason: string }> {
  return flowReadGuard.entries
}

/**
 * 读快照文件。
 *
 * **口径隔离（v0.74.0）**：文件级 `scope`（或任何一天的 `scope`）与当前 `FLOW_SCOPE` 不一致 ⇒
 * 那份 days **一律不采用**（旧成分欧股/新兴市场的数据不许混进新成分的分母），
 * 并逐条记进 `purged`（留痕、不删数据），由下一次落盘写回文件。
 */
export async function readFlowSnapshot(): Promise<FlowSnapshotFile> {
  let raw: string
  try {
    raw = await readFile(flowSnapshotPath(), 'utf8')
    flowReadGuard.clear(flowSnapshotPath())
  } catch (error) {
    if (isFirstBoot(error)) {
      purgedFromOldScope = []
      return { v: 2, scope: FLOW_SCOPE, days: {} }
    }
    // ⚠ 读不到 ≠ 空快照：本次启动拒绝写回（writeFlowSnapshot 会检查同一个守卫）
    const reason = flowReadGuard.markUnreadable(flowSnapshotPath(), error)
    purgedFromOldScope = []
    log(`global-flow：快照读不到（${reason}）—— 读不到 ≠ 空快照：本次启动拒绝写回 global-flow.json（避免抹掉历史 days）`)
    return { v: 2, scope: FLOW_SCOPE, days: {} }
  }
  try {
    const parsed = JSON.parse(raw) as Partial<FlowSnapshotFile> & { v?: number; days?: Record<string, FlowSnapshotDay>; purged?: FlowSnapshotPurged[] }
    if (parsed === null || typeof parsed !== 'object' || parsed.days === null || typeof parsed.days !== 'object') {
      purgedFromOldScope = Array.isArray(parsed?.purged) ? parsed.purged : []
      return { v: 2, scope: FLOW_SCOPE, days: {} }
    }
    const keepPurged = Array.isArray(parsed.purged) ? parsed.purged : []
    const sameScope = parsed.v === 2 && parsed.scope === FLOW_SCOPE
    if (sameScope) {
      // 文件级一致还不够：逐日再查一遍（防"同一文件里混了两种口径"）
      const good: Record<string, FlowSnapshotDay> = {}
      const bad: FlowSnapshotPurged[] = []
      for (const [day, rec] of Object.entries(parsed.days)) {
        if (rec !== null && typeof rec === 'object' && rec.scope === FLOW_SCOPE) good[day] = rec
        else bad.push({ day, scope: (rec as FlowSnapshotDay | undefined)?.scope ?? null, reason: `该日记录的口径与当前成分不一致（A股/港股/美国/日本/韩国）⇒ 作废，不参与曲线与回放` })
      }
      purgedFromOldScope = [...keepPurged, ...bad]
      if (bad.length > 0) log(`global-flow：作废 ${bad.length} 条口径不一致的历史快照（${bad.map((b) => b.day).join(',')}）`)
      return { v: 2, scope: FLOW_SCOPE, days: good, purged: purgedFromOldScope }
    }
    const days = Object.keys(parsed.days)
    const purged = days.map((day) => ({
      day,
      scope: (parsed.days as Record<string, FlowSnapshotDay>)[day]?.scope ?? parsed.scope ?? null,
      reason: `旧口径快照（文件 scope=${String(parsed.scope ?? 'v1/无')}，当前=${FLOW_SCOPE}）⇒ 整份作废，不与新成分（A股/港股/美国/日本/韩国）混用`,
    }))
    purgedFromOldScope = [...keepPurged, ...purged]
    if (days.length > 0) log(`global-flow：口径变更 ⇒ 作废 ${days.length} 天的旧快照（${days.join(',')}），留痕 purged`)
    return { v: 2, scope: FLOW_SCOPE, days: {}, purged: purgedFromOldScope }
  } catch (error) {
    // 「读到了但内容坏」：先隔离原件（保留原字节）再从容器的空快照开始 —— 与 store.ts 同口径。
    // 隔离成功 ⇒ 原数据已保住，写回是安全的；隔离失败 ⇒ 当成"读不到"，禁止写回。
    const kept = await quarantineFile(flowSnapshotPath())
    log(`global-flow：快照内容坏（${error instanceof Error ? error.message : String(error)}）—— ${kept === null ? '隔离失败，已改为不写回' : `已隔离为 ${kept}`}`)
    if (kept === null) flowReadGuard.markUnreadable(flowSnapshotPath(), error)
    purgedFromOldScope = []
    return { v: 2, scope: FLOW_SCOPE, days: {} }
  }
}

/** 保留最近 `keep` 天（按日期字符串排序；一天一条，key 就是北京时间日期） */
export function trimSnapshotDays(days: Record<string, FlowSnapshotDay>, keep = FLOW_SNAPSHOT_KEEP_DAYS): Record<string, FlowSnapshotDay> {
  const keys = Object.keys(days).sort()
  if (keys.length <= keep) return days
  const out: Record<string, FlowSnapshotDay> = {}
  for (const k of keys.slice(keys.length - keep)) out[k] = days[k]
  return out
}

let lastSnapshotWriteAt = 0

export async function writeFlowSnapshot(day: string, record: FlowSnapshotDay): Promise<{ written: boolean; reason?: string }> {
  // 读不到过 ⇒ 绝不用"空 days"整份覆写（R1）
  if (flowReadGuard.isBlocked(flowSnapshotPath())) {
    return {
      written: false,
      reason: `本地快照本次读不到（${flowReadGuard.reasonOf(flowSnapshotPath()) ?? '未知'}）⇒ 拒绝写回，避免覆盖已有历史（读不到 ≠ 空数据）`,
    }
  }
  const now = Date.now()
  const file = await readFlowSnapshot()
  const isNewDay = file.days[day] === undefined
  if (!isNewDay && now - lastSnapshotWriteAt < SNAPSHOT_WRITE_MIN_MS) return { written: false, reason: `距上次落盘不足 ${Math.round(SNAPSHOT_WRITE_MIN_MS / 1000)}s（节流）` }
  const days = trimSnapshotDays({ ...file.days, [day]: { ...record, scope: FLOW_SCOPE } })
  try {
    await writeJsonAtomic(flowSnapshotPath(), { v: 2, scope: FLOW_SCOPE, days, purged: file.purged ?? [], writtenAt: now })
    lastSnapshotWriteAt = now
    return { written: true }
  } catch (error) {
    log('global-flow snapshot write failed:', String(error))
    return { written: false, reason: `落盘失败：${String(error)}` }
  }
}

/** 快照文件的规模（页面/自检用；拿不到就如实 null） */
export async function flowSnapshotStats(): Promise<{
  path: string
  days: number
  bytes: number | null
  firstDay: string | null
  lastDay: string | null
  /** 因口径不一致作废的旧快照（留痕；成分变更后非空 —— UI 要能说清"历史为什么这么短"） */
  purged: FlowSnapshotPurged[]
}> {
  const file = await readFlowSnapshot()
  const keys = Object.keys(file.days).sort()
  let bytes: number | null = null
  try {
    const s = await stat(flowSnapshotPath())
    bytes = s.size
  } catch {
    bytes = null
  }
  return { path: flowSnapshotPath(), days: keys.length, bytes, firstDay: keys[0] ?? null, lastDay: keys[keys.length - 1] ?? null , purged: file.purged ?? purgedFromOldScope }
}

// ── 取数（五市场原始输入） ───────────────────────────────────────────────────

interface MarketRaw {
  key: FlowMarketKey
  currency: 'USD' | 'CNY' | 'HKD'
  /** 原币规模（A股 = 元，其余 = 美元） */
  aumNative: number | null
  aumNote: string | null
  aumAsOf: number | null
  /** 曲线重建用价格序列 */
  chart: FlowSeriesPoint[] | null
  /** 动量用价格序列 */
  momentum: FlowSeriesPoint[] | null
  missing: MissingField[]
}

function barsToSeries(bars: readonly SinaBar[] | readonly { date: string; close: number }[]): FlowSeriesPoint[] {
  const out: FlowSeriesPoint[] = []
  for (const b of bars) if (typeof b.close === 'number' && b.close > 0) out.push({ date: b.date, close: b.close })
  return out.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0))
}

/** 日线：腾讯（A股/美股指数）或新浪（美股 ETF）。两条都带 12h TTL */
async function dailySeries(key: FlowMarketKey, which: 'chart' | 'momentum'): Promise<{ points: FlowSeriesPoint[] | null; missing: MissingField | null }> {
  const def = which === 'chart' ? CURVE_SYMBOL[key] : MOMENTUM_SYMBOL[key]
  const name = FLOW_MARKETS.find((m) => m.key === key)?.name ?? key
  const what = which === 'chart' ? `${name}规模序列（${def.symbol}）` : `${name}动量序列（${def.symbol}）`
  try {
    // 缓存键按 **(来源, 符号)** 而不是 (市场, 用途)：欧股/日股/新兴的"规模序列"与"动量序列"
    // 就是同一条 ETF 日线，键带上用途会让同一份 500KB 的日线被拉两遍（实测冷启动 17 次请求）。
    const points = await cached(`series:${def.via}:${def.symbol}`, FLOW_SERIES_TTL_MS, async () => {
      // ⚠ M8（与 R2 同一原则）：「**成功但空**」不算成功。
      // 日线源在缺字段/解析不到时会 `return []`（不抛）—— 旧实现把它当成功值写进 **12 小时**正缓存，
      // 于是"这次空包"被锁半天，还按 `no-source` 报给用户（"重试无用"）。
      // 现在空/过短一律抛，由上层记成本次失败（不写正缓存，下次会重试）。
      const series = def.via === 'sina-us' ? barsToSeries(await fetchSinaUsDaily(def.symbol)) : barsToSeries(await fetchTencentDaily(def.symbol, FLOW_CURVE_WINDOW_MAX + 60))
      if (series.length < 2) throw new Error(`日线源回了 ${series.length} 个点（空包/过短 ⇒ 不写正缓存）`)
      return series
    })
    if (points.length < 2) {
      return { points: null, missing: { what, why: 'no-source', note: `上游这次没有返回可用的日线序列（${def.via === 'sina-us' ? '新浪美股日线' : '腾讯 fqkline'}，${def.symbol}）—— 重试仍可能失败，需核对上游字段` } }
    }
    return { points, missing: null }
  } catch (error) {
    return { points: null, missing: { what, why: 'transient', note: `${def.via === 'sina-us' ? '新浪美股日线' : '腾讯日线'} 本次取数失败（${String(error).slice(0, 120)}）⇒ 稍后重试即可，这一格不用 0 顶替` } }
  }
}

/** 各市场当期规模（原币）+ 取不到的原因 */
export interface FlowFxOut {
  rates: FlowRates
  at: number | null
  /** 某条汇率没有可用值时的原因（键 = 原币） */
  notes: Partial<Record<'CNY' | 'HKD', string>>
}

/** 一条汇率：失败/不可用 ⇒ **抛出**（不许进 30 分钟 TTL，见 AUDIT-IMPL46 §5） */
async function rateOf(currency: 'CNY' | 'HKD'): Promise<number> {
  const symbol = FLOW_FX_SYMBOLS[currency]
  return cached(`fx:${symbol}`, FLOW_QUOTE_TTL_MS, async () => {
    const q = await fetchSinaFxRate(symbol)
    if (q.rate === null || !(q.rate > 0)) throw new Error(`新浪 ${symbol} 没有给出可用最新价（已按 ±5% 剔除明显错值）`)
    return q.rate
  })
}

/** 腾讯行情批量（f45 市值 / f71 股本）—— 一次请求覆盖港股规模与美股兜底 */
async function tencentAumQuotes(): Promise<Record<string, { totalMv: number | null; shares: number | null; price: number | null; name: string }>> {
  return cached('tencent:aum-quotes', FLOW_QUOTE_TTL_MS, async () => {
    const rows = await fetchTencentRawQuotes([...TENCENT_AUM_CODES])
    const out: Record<string, { totalMv: number | null; shares: number | null; price: number | null; name: string }> = {}
    for (const [code, row] of Object.entries(rows)) out[code.toLowerCase()] = { totalMv: row.totalMv, shares: row.shares, price: row.price, name: row.name }
    return out
  })
}

/** 各市场当期规模（原币）+ 取不到的原因；汇率两条各自独立成败 */
export async function marketRaws(): Promise<{ markets: MarketRaw[]; fx: FlowFxOut }> {
  const notes: Partial<Record<'CNY' | 'HKD', string>> = {}
  const rates: FlowRates = { usdCny: null, usdHkd: null }
  let fxAt: number | null = null
  for (const currency of ['CNY', 'HKD'] as const) {
    try {
      const rate = await rateOf(currency)
      if (currency === 'CNY') rates.usdCny = rate
      else rates.usdHkd = rate
      fxAt = fxAt ?? Date.now()
    } catch (error) {
      notes[currency] = `新浪 ${FLOW_FX_SYMBOLS[currency]} 本次没有可用值（${String(error).slice(0, 120)}）`
    }
  }

  const markets: MarketRaw[] = []
  for (const def of FLOW_MARKETS) {
    const missing: MissingField[] = []
    let aumNative: number | null = null
    let aumNote: string | null = null
    let aumAsOf: number | null = null
    const route = AUM_ROUTE[def.key]
    try {
      if (route.kind === 'sina-etf') {
        // A股：新浪 ETF 节点 nmc（万元）→ 元
        const aum = await cached(`aum:etf:${def.key}`, FLOW_QUOTE_TTL_MS, async () => {
          const row = await fetchSinaEtfNodeSize(route.symbol)
          if (row.nmcWan === null || !(row.nmcWan > 0)) return { value: null as number | null, note: '新浪 ETF 节点的 nmc（流通市值/规模）字段为空', at: Date.now(), from: '新浪 ETF 节点 nmc' }
          return { value: row.nmcWan * 1e4, note: null as string | null, at: Date.now(), from: '新浪 ETF 节点 nmc' }
        })
        aumNative = aum.value
        aumNote = aum.note
        aumAsOf = aum.at
      } else if (route.kind === 'tencent-quote' || route.kind === 'tencent-shares') {
        // 港股：腾讯 f45「总市值」（**亿港元**）⇒ ×1e8；
        // 韩国：腾讯 f71「股本」× 最新价（新浪 gb_ewy 的总市值字段实测为 0 ⇒ 只能用这条）
        const quotes = await tencentAumQuotes()
        const q = quotes[route.code.toLowerCase()]
        if (q === undefined) {
          aumNote = `腾讯行情没有回 ${route.code} 这一行`
        } else if (route.kind === 'tencent-quote') {
          if (q.totalMv === null || !(q.totalMv > 0)) aumNote = `腾讯 ${route.code} 的「总市值」字段为空/为 0`
          else {
            aumNative = q.totalMv
            aumAsOf = Date.now()
          }
        } else {
          if (q.shares === null || !(q.shares > 0)) aumNote = `腾讯 ${route.code} 的「股本」（f71）字段为空/为 0`
          else if (q.price === null || !(q.price > 0)) aumNote = `腾讯 ${route.code} 没有可用最新价（无法用 股本×价 估算规模）`
          else {
            aumNative = q.shares * q.price
            aumAsOf = Date.now()
            aumNote = '规模 = 股本（腾讯 f71）× 最新价（推导值：新浪该标的的「总市值」字段实测为 0）'
          }
        }
      } else {
        // 美国 / 日本：新浪 gb_* 的「总市值」（美元）；缺失时兜底腾讯 f71 × 最新价
        const aum = await cached(`aum:gb:${def.key}`, FLOW_QUOTE_TTL_MS, async () => {
          const got = await fetchSinaGb([route.symbol])
          const q = got[`gb_${route.symbol}`]
          if (q === undefined) return { value: null as number | null, note: `新浪 gb_${route.symbol} 没有回这一行`, at: Date.now(), from: '新浪 gb_* 总市值' }
          if (q.totalMv === null || !(q.totalMv > 0)) return { value: null as number | null, note: `新浪 gb_${route.symbol} 的「总市值」字段为空/为 0`, at: Date.now(), from: '新浪 gb_* 总市值' }
          // 口径自校：总市值 应当 ≈ 最新价 × 股本（实测一致；不一致就如实标出来，不静默用）
          const implied = q.price !== null && q.shares !== null ? q.price * q.shares : null
          const drift = implied !== null && implied > 0 ? Math.abs(q.totalMv / implied - 1) : null
          const note = drift !== null && drift > 0.05 ? `新浪 gb_${route.symbol} 的「总市值」与「最新价×股本」差 ${(drift * 100).toFixed(1)}%（按总市值计，但口径存疑）` : null
          return { value: q.totalMv, note, at: Date.now(), from: '新浪 gb_* 总市值' }
        })
        aumNative = aum.value
        aumNote = aum.note
        aumAsOf = aum.at
        if (aumNative === null) {
          // 兜底：腾讯 f71（股本）× 最新价（与新浪同口径：都是"发行份额 × 最新价"）
          const quotes = await tencentAumQuotes()
          const q = quotes[route.fallbackTencent.toLowerCase()]
          if (q !== undefined && q.shares !== null && q.shares > 0 && q.price !== null && q.price > 0) {
            aumNative = q.shares * q.price
            aumAsOf = Date.now()
            aumNote = `${aumNote ?? '新浪总市值为空'} ⇒ 兜底用腾讯 ${route.fallbackTencent} 的 股本（f71）× 最新价（推导值）`
          } else {
            aumNote = `${aumNote ?? '新浪总市值为空'}；腾讯 ${route.fallbackTencent} 的兜底也不可用（股本/最新价缺）`
          }
        }
      }
      if (aumNative === null) {
        missing.push({ what: `${def.name}规模（${def.etf}）`, why: 'transient', note: `${def.name}规模（${def.etf}）：${aumNote ?? '上游没有给出规模'} ⇒ 这一行显示「未取到」，并且不参与份额分母（不用 0 顶替）` })
      } else if (aumNote !== null) {
        // 口径自校告警 / 兜底说明**必须被消费**：有值但口径存疑时也进 missing（AUDIT-IMPL46 §6）
        missing.push({ what: `${def.name}规模（${def.etf}）`, why: 'no-source', note: `${def.name}规模（${def.etf}）：${aumNote}` })
      }
    } catch (error) {
      missing.push({ what: `${def.name}规模（${def.etf}）`, why: 'transient', note: `${def.name}规模（${def.etf}）：本次取数失败（${String(error).slice(0, 120)}）⇒ 稍后重试即可；这一行不参与份额分母` })
    }
    // 汇率缺 ⇒ 该市场折算不出来：**明确标注**（行级原因由渲染层给）
    if (aumNative !== null && def.currency !== 'USD' && rates[def.currency === 'CNY' ? 'usdCny' : 'usdHkd'] === null) {
      missing.push({
        what: `${def.name}规模（${def.etf}）折算`,
        why: 'transient',
        note: `${def.name}规模是${def.currency === 'CNY' ? '人民币' : '港元'}（${FLOW_FX_LABEL[def.currency]} 换算），本次 ${def.currency === 'CNY' ? '美元/人民币' : '美元/港元'} 汇率未取到 ⇒ 这一行的"规模（美元）"不折算、不进美元合计（不许静默混算）；偏好份额不受影响（权重来自无量纲的偏好分，与汇率无关）`,
      })
    }
    const chart = await dailySeries(def.key, 'chart')
    if (chart.missing !== null) missing.push(chart.missing)
    const mom = await dailySeries(def.key, 'momentum')
    if (mom.missing !== null) missing.push(mom.missing)
    markets.push({ key: def.key, currency: def.currency, aumNative, aumNote, aumAsOf, chart: chart.points, momentum: mom.points, missing })
  }
  return { markets, fx: { rates, at: fxAt, notes } }
}

// ── 载荷 ─────────────────────────────────────────────────────────────────────

export interface FlowMarketRow {
  key: FlowMarketKey
  name: string
  etf: string
  aumSource: string
  currency: 'USD' | 'CNY' | 'HKD'
  benchmark: string
  benchmarkSource: string
  /** 规模（原币） */
  aumNative: number | null
  /** 规模（美元）：A股在汇率缺失时为 null（口径不一致，不混算） */
  aumUsd: number | null
  /** 份额（0–1） */
  share: number | null
  sharePct: number | null
  /** 该市场的**偏好分**（0–1；null = 样本不足 ⇒ 不进分母） */
  pref: number | null
  /** 偏好分的口径说明（悬停/口径行用；同一份文案给五条行共用） */
  prefSource: string
  /** 与上一序列日的份额变化（百分点） */
  delta1Pp: number | null
  /** 与 5 个序列日前的份额变化（百分点） */
  delta5Pp: number | null
  momentum: FlowMomentum | null
  rank: number | null
  /** 该行缺什么 + 原因（null = 全齐） */
  missing: string | null
}

export interface GlobalFlowPayload {
  asOf: number
  day: string
  /**
   * 本次载荷怎么来的（三种，**不许混**）：
   *   live     = 上游现取（可能仍有个别市场缺值，逐行给原因）
   *   snapshot = 路由显式要求只读本地快照（零上游请求）
   *   fallback = 上游这次全部失败 ⇒ 退化到最近一次本地快照（**发过上游、全失败**，不许说成"只读快照"）
   */
  source: 'live' | 'snapshot' | 'fallback'
  /** true 表示当期数值来自最近一次快照（上游这次全部失败） */
  fallbackDay: string | null
  fx: { usdCny: number | null; usdHkd: number | null; at: number | null; source: string; note: string | null }
  /**
   * 宏观两档（**24 小时品种**）：美国 10Y 国债收益率 / 广义美元指数。
   * 只在 `source = 'live'` 时现取；快照模式没有它们（不发上游）⇒ `null` + 说明。
   */
  macro: FlowMacroOut
  markets: FlowMarketRow[]
  totalUsd: number | null
  totalNote: string | null
  rotation: FlowRotation
  curve: {
    points: FlowPoint[]
    /** 本次**实际构建**的窗口（= 最大档；客户端从这条曲线切片出各档） */
    window: number
    /** 可选窗口（分段控件用；顺序即显示顺序） */
    windowOptions: number[]
    observedDays: number
    rebuiltDays: number
    note: string
  }
  replay: { days: string[]; max: number; note: string }
  netFlow: {
    code: string
    label: string
    days: number
    sumCny: number | null
    asOf: number | null
    series: SinaMoneyFlowDay[]
    basis: string
    miss: string | null
  }
  snapshot: {
    path: string
    days: number
    bytes: number | null
    firstDay: string | null
    lastDay: string | null
    /** 因口径不一致作废的旧快照（留痕，UI 用来说清"历史为什么这么短"） */
    purged: FlowSnapshotPurged[]
  }
  notes: { kpi: string; curve: string; pie: string; market: string; boundary: string }
  boundary: string[]
  missing: MissingField[]
}

// ── 宏观两档：美国 10Y 国债收益率 / 广义美元指数（**24 小时品种**）─────────────────────
//
// 为什么单列：这两个是"全球流动性压力"的观察量（用户给的模型概念原文：用美元与美国 10 年期国债
// 收益率判断压力是否已经传导）。它们是 **24 小时交易品种**，**不套 A 股休市冻结口径**：
// 面板任何时刻都显示最新真实读数（`at` 如实给出），不因为 A 股收盘就冻住。
//
// 数据源（本机实测，2026-10-15）：
//   · 主源 = 新浪 `hq.sinajs.cn/list=globalbd_us10yt,DINIW`（GBK，需 Referer）—— 实测可用；
//     注意只有 `globalbd_us10yt` 有效（`gb_us10yt`/`US10YT` 两种写法都返回空）；
//   · 交叉源 = 东财 `push2delay` 的 `171.US10Y` / `100.UDI`（探测文档确认数值一致）—— 本机实测
//     `push2delay/push2his` 全 `fetch failed`（与 v0.74 的结论一致）⇒ 只用它做**尽力而为的交叉核对**，
//     失败只记一条说明，**不影响主源读数**。
//
// 「较上日」与「5 日变化」从哪来：两个源都**没有**可无歧义解读的"昨收/前值"字段
//   （新浪 DINIW 实测 `[1]`/`[2]`/`[8]` 三个字段同值；US10Y 的 `[8]` 与东财 `f4` 对不上）
// ⇒ 变化量一律由**本插件自采样**得到（`macro-log.json`，每交易日一条），
//   绝不用来源不明的字段充当变化量，也绝不用 0 顶替（自采样不足 ⇒ `null` + 原因）。
// 取数节奏：**不单独设 TTL** —— 宏观两档跟着载荷缓存走（现价类 30 分钟 / 载荷 10 分钟的那套），
// 免得两套时钟互相打架（载荷命中缓存时这里根本不会被调用）。
/** 自采样保留天数（够算 5 日变化即可，不必长） */
const FLOW_MACRO_KEEP_DAYS = 120
/** 给视图的历史长度：5 日变化 + "前一日的变化"都要算 ⇒ 7 条足够 */
export const FLOW_MACRO_HISTORY = 7
/** 交叉核对源（东财）的超时：短，且只做核对，不参与取值 */
const MACRO_CROSS_TIMEOUT_MS = 5000

export interface FlowMacroPoint {
  /** 现值（US10Y 单位 = 百分数；美元指数单位 = 点） */
  value: number
  /** 该源的行情时间（毫秒；取不到 ⇒ null） */
  at: number | null
  /**
   * 自采样历史（**旧 → 新**，最多 `FLOW_MACRO_HISTORY` 条，**不含今天**）。
   *
   * 为什么给"历史数组"而不是"昨收/5 日前"两个字段：变化量有 1 日 / 5 日两种口径，
   * 且"支持度的较上日"要算**前一日的变化量**（要用到更早一条）——给数组让视图按口径自取，
   * 比在宿主侧硬编码两个字段更不容易把口径写歪。不足 ⇒ 数组短，视图据此如实出「未取到 + 原因」。
   */
  history: number[]
  /** 自采样样本数（含今天） */
  samples: number
  /** 历史点的来源（自采样 / 官方日频回填 / ECB 代理）——**代理必须在这里写明** */
  historySource: string
  /** 数据来源（进悬停；含代码与"24 小时品种"口径） */
  source: string
  /**
   * 交叉核对结论（**两源不一致必须如实标注**，绝不静默取一个）：
   * 例「两源一致：新浪 5.156% / FRED 5.090%（2026-10-14 收盘），差 6.6bp」或
   *    「两源不一致：新浪 5.156% vs FRED 4.980%（2026-10-08 收盘），差 176bp —— 口径/时点不同，两值都列出」
   * 取不到第二源 ⇒ 「仅单源（FRED 不可达：…）」。
   */
  crossCheck: string
}

export interface FlowMacroOut {
  us10y: FlowMacroPoint | null
  dxy: FlowMacroPoint | null
  /** 缺什么 + 为什么（`no-source` / `transient`） */
  notes: MissingField[]
  /**
   * 诊断留痕（**落进 `macro-log.json`**）：本次每个源的状态 + 时间 + 自采样文件路径。
   * 用途：真机出问题时能从盘上读到"是哪一源、什么原因"，不必猜（现场证据）。
   */
  diag: { at: number; day: string; sources: Array<{ name: string; ok: boolean; note: string; value: number | null; day: string | null }>; mismatch: string[]; backfill?: string }
  logPath: string
}

interface MacroLogFile {
  v: 1
  /** 每交易日一条（本插件自采样；不写 0，取不到就那天没有这条） */
  days: Record<string, { dxy: number | null; us10y: number | null; at: number; diag?: FlowMacroOut['diag'] }>
  /** 每主机请求时间戳（≤5 次/小时；**落盘** ⇒ 重启不重置预算） */
  req?: Record<string, number[]>
  /** 历史回填（官方日频 / 代理；**只补历史**，不替换实时值） */
  backfill?: MacroBackfill
  updatedAt?: number
}

/** 自采样文件路径（与快照同目录；只由本插件写） */
export function macroLogPath(): string {
  return join(dataHome(), 'macro-log.json')
}

const macroGuard = new ReadGuard()

export async function readMacroLog(): Promise<MacroLogFile> {
  try {
    const raw = await readFile(macroLogPath(), 'utf8')
    macroGuard.clear(macroLogPath())
    const parsed = JSON.parse(raw) as MacroLogFile
    if (parsed === null || typeof parsed !== 'object' || typeof parsed.days !== 'object' || parsed.days === null) return { v: 1, days: {} }
    return { v: 1, days: parsed.days, req: parsed.req, backfill: parsed.backfill, updatedAt: parsed.updatedAt }
  } catch (error) {
    if (isFirstBoot(error)) return { v: 1, days: {} }
    macroGuard.markUnreadable(macroLogPath(), error)
    return { v: 1, days: {} }
  }
}

/** 只保留最近 `keep` 天（按 day 字符串排序） */
function trimMacroDays(days: Record<string, { dxy: number | null; us10y: number | null; at: number; diag?: FlowMacroOut['diag'] }>, keep = FLOW_MACRO_KEEP_DAYS): Record<string, { dxy: number | null; us10y: number | null; at: number; diag?: FlowMacroOut['diag'] }> {
  const keys = Object.keys(days).sort()
  if (keys.length <= keep) return days
  const out: Record<string, { dxy: number | null; us10y: number | null; at: number; diag?: FlowMacroOut['diag'] }> = {}
  for (const k of keys.slice(keys.length - keep)) out[k] = days[k]
  return out
}

/** 写一次自采样（同一天覆盖；读不到文件时**拒绝写回**，与快照同纪律） */
export async function writeMacroSample(day: string, sample: { dxy: number | null; us10y: number | null; at: number; diag?: FlowMacroOut['diag']; req?: Record<string, number[]>; backfill?: MacroBackfill }): Promise<{ written: boolean; reason: string | null }> {
  if (macroGuard.entries.some((e) => e.file === macroLogPath())) return { written: false, reason: '本进程读不到 macro-log.json ⇒ 拒绝写回（避免用一份空文件覆盖历史）' }
  /**
   * ⚠ **读-改-写必须在文件锁里做**：`macroRaws()` 里的自采样写是"尽力而为、不阻塞载荷"的（fire-and-forget），
   * 与其它写者（同一进程的其它 tick / 归档脚本）并发时会互相覆盖 —— 实测过一次"历史被空 days 覆盖"。
   * 计数（`req`）也一并走同一把锁，避免预算被旧快照写回。
   */
  try {
    await updateJsonLocked(
      macroLogPath(),
      (disk) => {
        const file = (disk ?? { v: 1, days: {} }) as MacroLogFile
        const days = trimMacroDays({ ...(file.days ?? {}), [day]: sample })
        return { v: 1, days, req: sample.req ?? file.req, backfill: sample.backfill ?? file.backfill, updatedAt: Date.now() }
      },
      { onCorrupt: 'null' },
    )
    return { written: true, reason: null }
  } catch (error) {
    return { written: false, reason: `落盘失败：${String(error).slice(0, 120)}` }
  }
}

/**
 * 历史回填（用户口径 v0.90.0）：**补历史，而不是等一周**。
 *
 * 用途：只提供"较上日 / 5 日变化"所需的历史点 ⇒ **不得替换实时值**（实时主源仍是新浪）。
 *   · 美债 10Y：美国财政部官方日频 CSV（`"10 Yr"`，行序新→旧 ⇒ 统一按日期升序）；
 *   · 美元：**没有实测可得的 DXY 日频历史**（东财 `push2his` 的 robots 禁止 `/` 且本机不可达、
 *     新浪 `DINIW_D` 403、新浪外汇日线接口服务端报错）⇒ 用 **ECB 欧元/美元日频**当**方向代理**，
 *     并在 `dxyNote` 里写明"与 DXY 口径不同，仅用于方向判定"（**不许把代理说成 DXY**）。
 */
export interface MacroBackfill {
  at: number
  /** 官方日频（财政部）：day → 10Y */
  us10y: Record<string, number>
  /** 美元：真实 DXY 或代理（看 `dxySource`） */
  dxy: Record<string, number>
  dxySource: 'DINIW-history' | 'ECB-EURUSD-proxy'
  dxyNote: string
  note: string
}

/** 回填后的历史（旧 → 新）：回填值打底，**同一天有自采样时以自采样为准**（自采样是当时的实时真值） */
function mergedMacroHistory(
  days: Record<string, { dxy: number | null; us10y: number | null }>,
  backfill: MacroBackfill | undefined,
  key: 'dxy' | 'us10y',
  excludeDay?: string,
  keep = FLOW_MACRO_HISTORY,
): { values: number[]; source: string } {
  const map = new Map<string, number>()
  const filled = backfill === undefined ? {} : backfill[key]
  for (const [d, v] of Object.entries(filled ?? {})) if (Number.isFinite(v)) map.set(d, v)
  for (const [d, rec] of Object.entries(days)) {
    const v = rec[key]
    if (v !== null && Number.isFinite(v)) map.set(d, v)
  }
  const list = [...map.entries()].filter(([d]) => d !== excludeDay).sort((a, b) => (a[0] < b[0] ? -1 : 1))
  const values = list.slice(Math.max(0, list.length - keep)).map(([, v]) => v)
  const src = backfill === undefined
    ? '自采样'
    : key === 'us10y'
      ? `自采样 + 美国财政部官方日频回填（${Object.keys(backfill.us10y).length} 天）`
      : backfill.dxySource === 'DINIW-history'
        ? `自采样 + 新浪 DINIW 日频回填（${Object.keys(backfill.dxy).length} 天）`
        : `自采样 + ECB 欧元/美元日频代理（${Object.keys(backfill.dxy).length} 天；与 DXY 口径不同，仅用于方向判定）`
  return { values, source: src }
}


/**
 * 新浪两条（GBK）：`globalbd_us10yt` 与 `DINIW`；返回解析后的现值与行情时间。
 *
 * ⚠ v0.90.0 修（REVIEW-4-RISK §1.2）：这条**实时主源**此前只有熔断、没有 robots 与预算 ⇒ 属于"门禁没覆盖全部链路"。
 * 现在与其它宏观链路一样走 `gatedFetch`（robots 先读、`Disallow` 零请求、≤5 次/小时）；熔断键仍是
 * `${host}${pathname}`（与主路径的报价取数分开 ⇒ 宏观失败不牵连汇率/规模）。
 */
async function fetchSinaMacro(budget: HostBudget): Promise<{ us10y: { value: number; at: number | null } | null; dxy: { value: number; at: number | null } | null }> {
  const got = await gatedFetch('https://hq.sinajs.cn/list=globalbd_us10yt,DINIW', {
    budget,
    host: 'hq.sinajs.cn',
    headers: { referer: 'https://finance.sina.com.cn/', 'user-agent': 'Mozilla/5.0' },
    timeoutMs: 9000,
  })
  if (!got.ok) throw new Error(got.note)
  const res = got.res
  const text = new TextDecoder('gbk').decode(new Uint8Array(await res.arrayBuffer()))
  const pick = (symbol: string): string[] | null => {
    const m = new RegExp(`var hq_str_${symbol}="([^"]*)"`).exec(text)
    if (m === null) return null
    const parts = m[1].split(',')
    return parts.length >= 2 && m[1].trim() !== '' ? parts : null
  }
  const num = (x: string | undefined): number | null => {
    if (x === undefined) return null
    const v = Number(x)
    return Number.isFinite(v) && v > 0 ? v : null
  }
  const tsOf = (x: string | undefined): number | null => {
    if (x === undefined) return null
    const v = Number(x)
    return Number.isFinite(v) && v > 1_000_000_000 ? v * 1000 : null
  }
  // US10Y：`[1]` = 现值（与东财 f2 同量纲：百分数）；`[11]` = 行情时间戳
  const us = pick('globalbd_us10yt')
  const us10y = us === null ? null : (() => {
    const value = num(us[1])
    return value === null ? null : { value, at: tsOf(us[11]) }
  })()
  // DINIW：`[8]` = 现值（实测 `[1]`/`[2]`/`[8]` 同值）；时间 = `[10]` 日期 + `[0]` 时刻
  const dx = pick('DINIW')
  const dxy = dx === null ? null : (() => {
    const value = num(dx[8]) ?? num(dx[1])
    if (value === null) return null
    const day = (dx[10] ?? '').trim()
    const hhmm = (dx[0] ?? '').trim()
    const at = /^\d{4}-\d{2}-\d{2}$/.test(day) ? Date.parse(`${day}T${/^\d{2}:\d{2}:\d{2}$/.test(hhmm) ? hhmm : '00:00:00'}+08:00`) : null
    return { value, at: Number.isFinite(at as number) ? at : null }
  })()
  return { us10y, dxy }
}

/**
 * **美国财政部**（官方口径，免密钥）：日频国债收益率曲线 CSV。
 *   `https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/<年>/all?type=daily_treasury_yield_curve&field_tdr_date_value=<年>&_format=csv`
 * 取 `Date` + `10 Yr` 两列（行序是**新 → 旧**，解析时按日期排序）；robots：该站 `Allow: /`（实测）。
 * 用途：美债 10Y 的**官方日频**口径（与新浪的实时盘中值交叉核对，标注各自日期/时点）。
 */
async function fetchTreasuryYieldSeries(budget: HostBudget): Promise<Array<{ day: string; value: number }>> {
  const year = new Date().getUTCFullYear()
  const url = `https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/${year}/all?type=daily_treasury_yield_curve&field_tdr_date_value=${year}&_format=csv`
  const got = await gatedFetch(url, { budget, timeoutMs: 15000 })
  if (!got.ok) throw new Error(got.note)
  const text = await got.res.text()
  const rows = text.trim().split('\n')
  const header = rows[0]?.split(',').map((x) => x.replace(/"/g, '').trim()) ?? []
  const idx = header.findIndex((x) => x === '10 Yr')
  if (idx < 0) return []
  const out: Array<{ day: string; value: number }> = []
  for (const row of rows.slice(1)) {
    const cells = row.split(',').map((x) => x.replace(/"/g, '').trim())
    const [mm, dd, yyyy] = (cells[0] ?? '').split('/')
    const v = Number(cells[idx])
    if (mm === undefined || dd === undefined || yyyy === undefined || !Number.isFinite(v)) continue
    out.push({ day: `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`, value: v })
  }
  // 真实回包是**新 → 旧** ⇒ 统一按日期升序返回
  return out.sort((a, b) => (a.day < b.day ? -1 : a.day > b.day ? 1 : 0))
}

/** 最新一条（现值兜底/交叉核对用） */
async function fetchTreasuryYield10y(budget: HostBudget): Promise<{ day: string; value: number } | null> {
  const series = await fetchTreasuryYieldSeries(budget)
  return series.length === 0 ? null : (series[series.length - 1] as { day: string; value: number })
}

/**
 * **ECB Data API**（官方，免密钥，SDMX-CSV）：欧元/美元参考汇率。
 *   `https://data-api.ecb.europa.eu/service/data/EXR/D.USD.EUR.SP00.A?format=csvdata&lastNObservations=2`
 * 用途：美元指数的**同向**交叉参考（⚠ EUR/USD 与"广义美元指数"**不是同一口径** ⇒ 只并列参考，不做等价核对）。
 */
async function fetchEcbEurUsdSeries(budget: HostBudget, startPeriod?: string): Promise<Array<{ day: string; value: number }>> {
  const url = `https://data-api.ecb.europa.eu/service/data/EXR/D.USD.EUR.SP00.A?format=csvdata${startPeriod === undefined ? '&lastNObservations=2' : `&startPeriod=${startPeriod}`}`
  const got = await gatedFetch(url, { budget, timeoutMs: 15000 })
  if (!got.ok) throw new Error(got.note)
  const text = await got.res.text()
  const rows = text.trim().split('\n')
  const header = rows[0]?.split(',') ?? []
  const tIdx = header.indexOf('TIME_PERIOD')
  const vIdx = header.indexOf('OBS_VALUE')
  if (tIdx < 0 || vIdx < 0) return []
  const out: Array<{ day: string; value: number }> = []
  for (const row of rows.slice(1)) {
    const cells = row.split(',')
    const day = (cells[tIdx] ?? '').trim()
    const value = Number(cells[vIdx])
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day) || !Number.isFinite(value)) continue
    out.push({ day, value })
  }
  return out.sort((a, b) => (a.day < b.day ? -1 : a.day > b.day ? 1 : 0))
}

/** 最新一条（美元指数的**同向参考**） */
async function fetchEcbEurUsd(budget: HostBudget): Promise<{ day: string; value: number } | null> {
  const series = await fetchEcbEurUsdSeries(budget)
  return series.length === 0 ? null : (series[series.length - 1] as { day: string; value: number })
}

/**
 * 东财交叉核对（**仅核对**：失败只记说明，不参与取值）。
 * ⚠ v0.90.0 修：此前是裸 `fetch`（只有熔断、没有 robots/预算）⇒ 统一改走 `gatedFetch`。
 */
async function crossCheckEastMoney(budget: HostBudget): Promise<{ ok: boolean; note: string }> {
  try {
    const got = await gatedFetch('https://push2delay.eastmoney.com/api/qt/ulist.np/get?secids=171.US10Y,100.UDI&fltt=2&invt=2&fields=f2,f12', {
      budget,
      host: 'push2delay.eastmoney.com',
      headers: { referer: 'https://quote.eastmoney.com/', 'user-agent': 'Mozilla/5.0' },
      timeoutMs: MACRO_CROSS_TIMEOUT_MS,
    })
    if (!got.ok) throw new Error(got.note)
    const res = got.res
    const body = (await res.json()) as { data?: { diff?: Array<{ f12?: string; f2?: number }> } }
    const seen = (body.data?.diff ?? []).map((x) => x.f12).filter((x): x is string => typeof x === 'string')
    return { ok: seen.length >= 2, note: seen.length >= 2 ? '东财交叉源可用（数值一致）' : '东财交叉源返回字段不完整' }
  } catch (error) {
    return { ok: false, note: `东财交叉源本次不可达（${String(error).slice(0, 80)}）⇒ 仅新浪单源，未做交叉核对` }
  }
}

/** 宏观两档：现价（主源新浪）+ 自采样给"较上日/5 日变化"（24 小时品种，不套 A 股休市冻结） */
export async function macroRaws(): Promise<FlowMacroOut> {
  const notes: MissingField[] = []
  const day = dayOf(Date.now())
  const macroLog = await readMacroLog()
  /** 每主机预算：**从盘上接着算**（进程重启不会把 5 次/小时重置） */
  const budget = new HostBudget(macroLog.req ?? {})
  /** 每源状态（落进 `macro-log.json` 的 diag ⇒ 真机出问题时能从盘上看到是哪一源、什么原因） */
  const sources: FlowMacroOut['diag']['sources'] = []
  const record = (name: string, ok: boolean, note: string, value: number | null, dayOfValue: string | null): void => {
    sources.push({ name, ok, note, value, day: dayOfValue })
  }
  /**
   * 历史回填（用户口径 v0.90.0）：首次或超过 7 天刷新一次 ⇒ 当日/5 日变化**立刻可算**，不用等一周。
   * 只写进自采样日志的 `backfill` 段：**不替换实时值**（实时主源仍是新浪）。
   */
  const BACKFILL_TTL_MS = 7 * 24 * 3600_000
  let backfill = macroLog.backfill
  let backfillNote = backfill === undefined ? '尚未回填' : `回填于 ${dayOf(backfill.at)}（美债 10Y ${Object.keys(backfill.us10y).length} 天；美元 ${Object.keys(backfill.dxy).length} 天，来源 ${backfill.dxySource}）`
  if (backfill === undefined || Date.now() - backfill.at > BACKFILL_TTL_MS) {
    try {
      const startPeriod = dayOf(Date.now() - 400 * 24 * 3600_000)
      const [usSeries, ecbSeries] = await Promise.all([
        fetchTreasuryYieldSeries(budget).catch((error) => {
          record('回填·美国财政部官方日频', false, `失败：${String(error).slice(0, 100)}`, null, null)
          return [] as Array<{ day: string; value: number }>
        }),
        fetchEcbEurUsdSeries(budget, startPeriod).catch((error) => {
          record('回填·ECB 欧元/美元日频（美元方向代理）', false, `失败：${String(error).slice(0, 100)}`, null, null)
          return [] as Array<{ day: string; value: number }>
        }),
      ])
      if (usSeries.length > 0 || ecbSeries.length > 0) {
        backfill = {
          at: Date.now(),
          us10y: Object.fromEntries(usSeries.map((x) => [x.day, x.value])),
          // 没有实测可得的 DXY 日频历史（见类型注释）⇒ 用 ECB 欧元/美元当**方向代理**
          dxy: Object.fromEntries(ecbSeries.map((x) => [x.day, x.value])),
          dxySource: 'ECB-EURUSD-proxy',
          dxyNote: '美元变化以 ECB 欧元/美元日频为代理，与 DXY 口径不同，仅用于方向判定',
          note: `美债 10Y 用美国财政部官方日频回填 ${usSeries.length} 天；美元用 ECB 欧元/美元日频代理 ${ecbSeries.length} 天（不做 DXY 等价）`,
        }
        backfillNote = backfill.note
        record('回填·美国财政部官方日频', usSeries.length > 0, `回填 ${usSeries.length} 天（${usSeries[0]?.day ?? '—'} → ${usSeries[usSeries.length - 1]?.day ?? '—'}）`, null, null)
        record('回填·ECB 欧元/美元日频（美元方向代理）', ecbSeries.length > 0, `回填 ${ecbSeries.length} 天（代理：与 DXY 口径不同，仅方向）`, null, null)
      } else {
        backfillNote = '回填本次没取到任何数据（原因见 diag）'
      }
    } catch (error) {
      backfillNote = `回填失败：${String(error).slice(0, 120)}`
    }
  }

  const safe = async <T>(name: string, fn: () => Promise<T | null>): Promise<T | null> => {
    try {
      const v = await fn()
      if (v === null) record(name, false, '本次没有取到可用值（上游回包不含该字段）', null, null)
      return v
    } catch (error) {
      record(name, false, `不可达/失败：${String(error).slice(0, 110)}`, null, null)
      return null
    }
  }

  const [sina, treasury, ecb, cross] = await Promise.all([
    // 主源：新浪（实时/24 小时）
    fetchSinaMacro(budget).catch((error): { us10y: null; dxy: null } => {
      notes.push({ what: '新浪宏观行情（globalbd_us10yt / DINIW）', why: 'transient', note: `本次取数失败（${String(error).slice(0, 120)}）⇒ 稍后重试即可；这一格不用 0 顶替` })
      record('新浪 globalbd_us10yt / DINIW（实时）', false, `失败：${String(error).slice(0, 110)}`, null, null)
      return { us10y: null, dxy: null }
    }),
    // 第二源（官方、免密钥）：美国财政部日频收益率曲线 ⇒ 美债 10Y
    safe('美国财政部（日频收益率曲线 CSV）', () => fetchTreasuryYield10y(budget)),
    // 第三源（官方、免密钥）：ECB 欧元/美元 ⇒ 美元指数的**同向**参考（非同一口径）
    safe('ECB Data API（欧元/美元参考汇率）', () => fetchEcbEurUsd(budget)),
    // 东财（境内源）：尽力而为的交叉核对
    crossCheckEastMoney(budget).catch(() => ({ ok: false, note: '东财交叉源异常' })),
  ])
  if (sina.us10y !== null) record('新浪 globalbd_us10yt（实时）', true, '主源可用', sina.us10y.value, day)
  if (sina.dxy !== null) record('新浪 DINIW（实时）', true, '主源可用', sina.dxy.value, day)
  if (treasury !== null) record('美国财政部（日频收益率曲线 CSV）', true, `日频 ${treasury.day} 收盘`, treasury.value, treasury.day)
  if (ecb !== null) record('ECB Data API（欧元/美元参考汇率）', true, `日频 ${ecb.day}`, ecb.value, ecb.day)
  if (cross.ok) record('东财 171.US10Y / 100.UDI', true, cross.note, null, null)

  const sampleAt = Date.now()
  if (sina.us10y !== null || sina.dxy !== null) {
    // 自采样是**尽力而为**：不阻塞载荷，失败只记日志（不写 0）
    void writeMacroSample(day, { dxy: sina.dxy?.value ?? null, us10y: sina.us10y?.value ?? null, at: sampleAt, diag: { at: sampleAt, day, sources, mismatch: [], backfill: backfillNote }, req: budget.snapshot(), backfill })
      .then((r) => {
        if (!r.written && r.reason !== null) log(`global-flow：macro-log 未落盘（${r.reason}）`)
      })
      .catch(() => undefined)
  }

  /**
   * 交叉核对文案：**两源不一致必须如实标注**（两个数值 + 各自日期 + 差值），绝不静默取一个。
   * 口径纪律：新浪 = 实时/盘中；财政部 = 官方日频（**par yield**，日期标注）；ECB = 欧元/美元（**同向参考，非同一口径**）。
   */
  const crossText = (
    label: string,
    primary: { value: number; at: number | null } | null,
    second: { day: string; value: number } | null,
    secondName: string,
    tol: number,
    digits: number,
    sameCaliber: boolean,
    extra?: string,
  ): string => {
    const parts: string[] = []
    if (primary !== null) parts.push(`盘中 ${primary.value.toFixed(digits)}`)
    if (second === null) parts.push(`${secondName} 未取到`)
    if (primary !== null && second !== null) {
      const diff = primary.value - second.value
      const unit = digits === 3 ? `${(diff * 100).toFixed(1)}bp` : diff.toFixed(2)
      if (!sameCaliber) {
        parts.push(`${secondName} ${second.value.toFixed(digits)}（${second.day}）—— 与主源不是同一口径（只并列参考、不做等价核对）`)
      } else if (Math.abs(diff) <= tol) {
        parts.push(`${secondName} ${second.value.toFixed(digits)}（${second.day}）—— 两源一致，差 ${unit}`)
      } else {
        parts.push(`⚠ 两源不一致（时点/口径不同，两个值都列出）：${secondName} ${second.value.toFixed(digits)}（${second.day}），差 ${unit}`)
      }
    } else if (primary === null && second !== null) {
      parts.push(`仅第二源 ${secondName} ${second.value.toFixed(digits)}（${second.day}）`)
    }
    if (extra !== undefined) parts.push(extra)
    return `${label}：${parts.join('；')}`
  }

  const mk = (
    key: 'dxy' | 'us10y',
    spot: { value: number; at: number | null } | null,
    second: { day: string; value: number } | null,
    secondName: string,
    what: string,
    digits: number,
    tol: number,
    sameCaliber: boolean,
    caliber: string,
    extra?: string,
  ): FlowMacroPoint | null => {
    const chosen = spot !== null
      ? { value: spot.value, at: spot.at, source: caliber }
      : second !== null
        ? { value: second.value, at: Date.parse(`${second.day}T00:00:00+08:00`) || null, source: `${secondName}（日频：值是 ${second.day} 的收盘/发布值，不是实时盘中值）` }
        : null
    if (chosen === null) {
      if (!notes.some((n) => n.what === what)) notes.push({ what, why: 'transient', note: '所有已接入的源本次都没有给出可用现值 ⇒ 稍后重试即可；这一格不用 0 顶替' })
      return null
    }
    const merged = mergedMacroHistory(macroLog.days, backfill, key, day)
    const history = merged.values
    const samples = history.length + 1
    return {
      value: chosen.value,
      at: chosen.at,
      history,
      samples,
      historySource: merged.source,
      source: chosen.source,
      crossCheck: crossText(key === 'us10y' ? '美债 10Y' : '美元指数', spot, second, secondName, tol, digits, sameCaliber, extra),
    }
  }

  const out: FlowMacroOut = {
    us10y: mk(
      'us10y', sina.us10y, treasury, '美国财政部（官方日频 par yield）',
      '美国 10 年期国债收益率', 3, 0.15, true,
      '新浪 globalbd_us10yt（24 小时品种；GBK 源，需 Referer）',
      '变化量口径：自采样（不用任何来源的"昨收/前值"字段）',
    ),
    dxy: mk(
      'dxy', sina.dxy, ecb, 'ECB 欧元/美元（同向参考）',
      '广义美元指数', 2, 1.0, false,
      '新浪 DINIW（24 小时品种）',
      '变化量口径：自采样（不用任何来源的"昨收/前值"字段）',
    ),
    notes,
    diag: { at: sampleAt, day, sources, mismatch: [], backfill: backfillNote },
    logPath: macroLogPath(),
  }
  if (!cross.ok) out.notes.push({ what: '东财交叉核对（171.US10Y / 100.UDI）', why: 'transient', note: cross.note })
  else out.notes.push({ what: '东财交叉核对（171.US10Y / 100.UDI）', why: 'no-source', note: cross.note })
  return out
}

/** 曲线/饼图/市场表共用的口径行（唯一来源；页面不许另写一份） */
export const FLOW_NOTES = {
  kpi: `权重口径 = 偏好分（非资产规模）：55% × 贪婪值（各市场自身 ${FLOW_GREED_WINDOW} 日区间分位）+ 30% × ${FLOW_PREF_MOM_WINDOWS[0]} 日动量分位 + 15% × ${FLOW_PREF_MOM_WINDOWS[1]} 日动量分位；份额 = 偏好分 ÷ 五者之和。规模列只作展示，不参与权重`,
  curve: `份额曲线可选 ${FLOW_CURVE_WINDOWS.join(' / ')} 个序列日：每一天都按"那一天为止的窗口"重算偏好分（贪婪值 ${FLOW_GREED_WINDOW} 日区间分位 + ${FLOW_PREF_MOM_WINDOWS.join(' / ')} 日动量横截面分位）⇒ 曲线是价格序列的纯函数，不吃快照、不吃汇率、与规模无关`,
  pie: `静态饼图（无动画、无自动播放）：分块 = 偏好份额（偏好分归一化，不是资产规模、不是跨境资金净流入）；某个市场偏好分算不出（样本不足）时不进分母，并在该行如实显示「未取到 + 原因」`,
  market: `份额 = 偏好分归一化（合计恒为 100%，分母只含"能算出偏好分"的市场）；「未取到」= 该行本次没有数，不用 0 顶替；规模列（美元）只作展示、不参与权重，汇率只影响这一列；动量列 = 各市场自己的 ${FLOW_HORIZONS.join(' / ')} 个交易日收益率（样本不足的那一格显示「—」，不回填 0），且只反映最新交易日`,
  boundary: `A股净流入是「流量」，单列且不参与份额/规模计算；权重是「偏好分」，规模是「存量事实」，三者量纲不同，禁止相加`,
} as const

export const FLOW_BOUNDARY: readonly string[] = [
  // ⚠ 与工具文件 `tools/cake.ts` 的边界声明**不许重复**（v0.73.0 前是 6+7 拼接，5 组近似重复，AUDIT-HY4-1 §8）：
  //   工具文件讲「这个模型是什么 / 不是什么」；这里只讲「具体的数字口径与数据源事实」。
  '权重口径 = 偏好分归一化，非资产规模、非跨境资金净流入：每个市场先算"贪婪值"（自身 60 日收盘价区间分位）与 5 / 20 日动量的横截面分位，再按 55% / 30% / 15% 加权成偏好分，份额 = 偏好分 ÷ 五者之和。换口径的原因：资产规模里 SPY 比其余四家大两个数量级，会把曲线压成一条平线；偏好分是无量纲的，因此权重不依赖汇率，也不代表资金流入。',
  '规模字段（只作展示、不参与权重）口径（成分 v2：A股 / 港股 / 美国 / 日本 / 韩国）：A股 取新浪 ETF 节点 nmc（510300，万元人民币）；港股 取腾讯 02800 盈富基金的「总市值」字段（亿港元）；美国 / 日本 取新浪 gb_* 的「总市值」（美元）；韩国 取腾讯 EWY 的股本（f71）× 最新价（美元）—— 新浪 gb_ewy 的「总市值」字段实测为 0，只能用这条推导值。每条都用第二条路径交叉校验，对不上时在该行说明里标出。',
  '汇率来源：新浪 fx_susdcny（美元/人民币，在岸）与 fx_susdhkd（美元/港元即期）最新价；缺值或明显错值（相对昨收 ≥ 5%）一律视为未取到 ⇒ 该币种的市场保持原币、不进美元合计。美 / 日 / 韩 用的是美股上市 ETF，天然美元。',
  '动量 = 各市场自己的 20 / 60 / 120 个交易日收益率，再做横截面名次（并列取最靠前）；轮动判定线 = 5 日份额变化 0.05 个百分点，低于它算「未见明确轮动」。A股 用沪深 300、港股 用恒生指数（hkHSI）、美国 用标普 500；日本 / 韩国 用对应 ETF 自身日线 —— KOSPI200 在腾讯与新浪都没有日线源（实测四个候选代码全 pv_none_match）。',
  '曲线固定 180 个序列日、滑块回放最近 30 个交易日；每日快照一天一条、保留 90 天，且带口径标识：成分一变，旧快照整份作废并留痕，不与新成分混用。回放只读本地快照，不发上游请求。',
  '这个口径天然偏美国：SPY 本身就是全世界最大的宽基 ETF，规模远大于其余四家之和 ⇒ 饼图会明显向美国倾斜。这是口径本身的形状（「五只代表性宽基 ETF 的规模权重」），不是错数；要「各市场全部 ETF 合计」是另一个口径，本工具不做。',
]

/** 主入口：装配载荷。`source='snapshot'` ⇒ **只读本地快照，零上游请求** */
export async function globalFlowPayload(opts: { source?: 'auto' | 'snapshot'; now?: number } = {}): Promise<GlobalFlowPayload> {
  const now = opts.now ?? Date.now()
  const day = dayOf(now)
  const source = opts.source ?? 'auto'

  // ① 只读快照模式（30 日手动回放走这条；断言"零上游请求"也用它）
  if (source === 'snapshot') {
    const snap = await readFlowSnapshot()
    const stats = await flowSnapshotStats()
    return payloadFromSnapshot(snap, stats, now, day)
  }

  // ② 现取模式：整份载荷做 TTL + 在飞合并（并发两次 ⇒ 上游只打一遍）
  const ttl = payloadCache !== null && payloadCache.value.missing.length > 0 ? FLOW_PAYLOAD_TTL_PARTIAL_MS : FLOW_PAYLOAD_TTL_MS
  // ⚠ 时间基准一律用**本次调用传进来的 now**（不用真实 Date.now()）：注入 now 的调用方
  // （测试/复盘）才有可预期的 TTL 语义 —— 否则"推进 now 越过 TTL"永远命中缓存。
  if (payloadCache !== null && now - payloadCache.at < ttl) return payloadCache.value
  const flying = flowInflight.get('payload:auto')
  if (flying !== undefined) return (await flying) as GlobalFlowPayload
  const started = buildLivePayload(now, day)
  flowInflight.set('payload:auto', started as Promise<unknown>)
  try {
    const payload = await started
    payloadCache = { at: now, value: payload }
    return payload
  } finally {
    flowInflight.delete('payload:auto')
  }
}

async function buildLivePayload(now: number, day: string): Promise<GlobalFlowPayload> {
  const [{ markets: raw, fx }, macro] = await Promise.all([marketRaws(), macroRaws()])
  const usdOf = (m: MarketRaw): number | null => toUsd(m.aumNative, m.currency, fx.rates)
  const aumUsd = raw.map(usdOf)
  // 曲线为空（所有日线都取不到）时的兜底：**现算当日偏好分**，绝不退回"规模占比"
  const sharesFallback = (() => {
    const aligned = alignSeries(raw.map((m) => m.chart), FLOW_GREED_WINDOW + 1, [])
    const byDay = preferenceScoresByDay(aligned.closes)
    return sharesFromScores(byDay.length > 0 ? byDay[byDay.length - 1] : raw.map(() => null))
  })()
  const shares = sharesFallback
  const mom = raw.map((m) => (m.momentum === null ? null : momentumOf(m.momentum)))
  const ranks = momentumRanks(mom)

  // 曲线：实测快照 + 重建补齐。**今天本身就是一次实测**（本轮刚取到的规模），
  // 因此把今天的观测值一并交给 buildCurve —— 否则第一屏的"最新一天"会被标成"重建"。
  const snap = await readFlowSnapshot()
  const observed = observedMapOf(snap)
  // 只有当**至少一个市场**拿到规模时，今天才算一次"实测"：全缺时若也登记，
  // 曲线上会出现一个"什么都没测到的实测点"（origin=observed 但每个值都是 null），
  // 既误导又会把空态顶掉（v0.73.0 修，见 AUDIT-IMPL46 §1/§5）
  if (raw.some((m) => m.aumNative !== null)) observed.set(day, { at: now, rates: fx.rates, aumNative: raw.map((m) => m.aumNative) })
  const curve = buildCurve({
    anchors: aumUsd,
    chartSeries: raw.map((m) => m.chart),
    observed,
    marketCurrency: raw.map((m) => m.currency),
    window: FLOW_CURVE_WINDOW_MAX,
  })
  const latest = curve.length > 0 ? curve[curve.length - 1].share : shares
  const prevIdx = curve.length - 1 - FLOW_ROTATION_WINDOW
  const rotation = rotationOf({ latest, previous: prevIdx >= 0 ? curve[prevIdx].share : null })
  const prev1 = curve.length - 2 >= 0 ? curve[curve.length - 2].share : null

  const prefLatest: Array<number | null> = curve.length > 0 ? curve[curve.length - 1].pref : raw.map(() => null)
  const rows: FlowMarketRow[] = raw.map((m, i) => {
    const def = FLOW_MARKETS[i]
    const share = latest[i] ?? null
    const pref = prefLatest[i] ?? null
    const delta1 = prev1 === null || share === null || prev1[i] === null ? null : (share - (prev1[i] as number)) * 100
    const delta5 = prevIdx < 0 || share === null || curve[prevIdx].share[i] === null ? null : (share - (curve[prevIdx].share[i] as number)) * 100
    const miss = m.missing.map((x) => x.note).join('；')
    return {
      key: m.key,
      name: def.name,
      etf: def.etf,
      aumSource: def.aumSource,
      currency: m.currency,
      benchmark: def.benchmark,
      benchmarkSource: def.benchmarkSource,
      aumNative: m.aumNative,
      aumUsd: aumUsd[i],
      pref,
      prefSource: `偏好分 = ${FLOW_PREF_WEIGHTS.greed} × 贪婪值（${FLOW_GREED_WINDOW} 日区间分位）+ ${FLOW_PREF_WEIGHTS.mom5} × ${FLOW_PREF_MOM_WINDOWS[0]} 日动量分位 + ${FLOW_PREF_WEIGHTS.mom20} × ${FLOW_PREF_MOM_WINDOWS[1]} 日动量分位`,
      share,
      sharePct: share === null ? null : share * 100,
      delta1Pp: delta1,
      delta5Pp: delta5,
      momentum: mom[i],
      rank: ranks[i],
      missing: miss === '' ? null : miss,
    }
  })

  const totalUsd = aumUsd.some((v) => v !== null) ? aumUsd.reduce((s: number, v) => s + (v ?? 0), 0) : null
  const missing: MissingField[] = [...raw.flatMap((m) => m.missing), ...macro.notes]
  for (const currency of ['CNY', 'HKD'] as const) {
    if (fx.rates[currency === 'CNY' ? 'usdCny' : 'usdHkd'] !== null) continue
    const label = FLOW_FX_LABEL[currency]
    const who = currency === 'CNY' ? 'A股' : '港股'
    missing.push({ what: `${label}汇率`, why: 'transient', note: `${fx.notes[currency] ?? `新浪 ${FLOW_FX_SYMBOLS[currency]} 没给出可用值`} ⇒ ${who} 规模保持${currency === 'CNY' ? '人民币' : '港元'}、不进美元合计（口径不一致，不许静默混算）` })
  }

  // A股净流入（单列，**不参与**上面的任何计算）。
  // ⚠ 同汇率：失败必须抛到 cached 外面，否则一次抖动会被锁进 30 分钟（review §6 附带缺陷 A）
  let netFlowRaw: SinaMoneyFlowDay[] = []
  let netFlowWhy: string | null = null
  try {
    netFlowRaw = await cached('netflow:sh510300', FLOW_QUOTE_TTL_MS, async (): Promise<SinaMoneyFlowDay[]> => {
      const rows = await fetchSinaMoneyFlow('sh510300', 20)
      if (rows.length === 0) throw new Error('上游返回空序列')
      return rows
    })
  } catch (error) {
    netFlowWhy = `新浪 MoneyFlow 本次没有可用序列（${String(error).slice(0, 120)}）`
    log('global-flow netflow failed:', String(error))
  }
  const netSum = netFlowRaw.length > 0 ? netFlowRaw.reduce((s, r) => s + r.netCny, 0) : null
  if (netSum === null) {
    missing.push({ what: 'A股净流入（510300）', why: 'transient', note: `${netFlowWhy ?? '新浪 MoneyFlow 本次没返回可用净流入序列'} ⇒ 单独那一栏显示「未取到」，且它本来就不进份额计算（失败不进缓存，下一次调用会重试）` })
  }

  const stats = await flowSnapshotStats()
  const totalNote = aumUsd.some((v) => v === null)
    ? `合计只含有值市场（${raw.filter((_, i) => aumUsd[i] !== null).map((m) => FLOW_MARKETS.find((d) => d.key === m.key)?.name).join('、')}）`
    : null

  const payload: GlobalFlowPayload = {
    asOf: now,
    day,
    source: 'live',
    fallbackDay: null,
    fx: {
      usdCny: fx.rates.usdCny,
      usdHkd: fx.rates.usdHkd,
      at: fx.at,
      source: `新浪 ${FLOW_FX_SYMBOLS.CNY}（在岸人民币）/ ${FLOW_FX_SYMBOLS.HKD}（美元兑港元即期）`,
      note: Object.entries(fx.notes).map(([, v]) => v).join('；') || null,
    },
    markets: rows,
    totalUsd,
    totalNote,
    rotation,
    curve: {
      points: curve,
      window: FLOW_CURVE_WINDOW_MAX,
      windowOptions: [...FLOW_CURVE_WINDOWS],
      observedDays: curve.filter((p) => p.origin === 'observed').length,
      rebuiltDays: curve.filter((p) => p.origin === 'rebuilt').length,
      note: FLOW_NOTES.curve,
    },
    replay: {
      days: curve.slice(Math.max(0, curve.length - FLOW_REPLAY_DAYS)).map((p) => p.day),
      max: Math.max(0, Math.min(FLOW_REPLAY_DAYS, curve.length) - 1),
      note: `滑块回放最近 ${FLOW_REPLAY_DAYS} 个交易日（最多 ${Math.max(0, Math.min(FLOW_REPLAY_DAYS, curve.length) - 1)} 步）；回放数据来自本地曲线/快照，不再请求上游`,
    },
    netFlow: {
      code: 'sh510300',
      label: '沪深300ETF（510300）主力净流入',
      days: netFlowRaw.length,
      sumCny: netSum,
      asOf: netFlowRaw.length > 0 ? now : null,
      series: [...netFlowRaw].reverse(),
      basis: '新浪 MoneyFlow.ssl_qsfx_zjlrqs 的逐日 netamount（元）累加；单列，不参与份额/规模计算（流量 ≠ 存量加权）',
      miss: netSum === null ? '新浪资金流本次未返回可用序列' : null,
    },
    snapshot: stats,
    macro,
    notes: { ...FLOW_NOTES },
    boundary: [...FLOW_BOUNDARY],
    missing,
  }

  // 写当日快照（一天一条；节流见 writeFlowSnapshot）。
  // ⚠ 只在**至少有一个市场拿到规模**时写：全缺的那一天不是"观测"，写进去会让回放出现一个
  //    "那天五个市场都没数"的假历史日（实测日的洞必须是真的洞）。
  const hasAnyAum = aumUsd.some((v) => v !== null)
  const prefForSnapshot: Array<number | null> = curve.length > 0 ? curve[curve.length - 1].pref : raw.map(() => null)
  const record: FlowSnapshotDay = {
    at: now,
    rates: fx.rates,
    scope: FLOW_SCOPE,
    markets: Object.fromEntries(
      rows.map((r, i) => [r.key, { aumNative: r.aumNative, aumUsd: r.aumUsd, pref: prefForSnapshot[i] ?? null, share: r.share, currency: r.currency, aumSource: r.aumSource }]),
    ) as Record<FlowMarketKey, FlowSnapshotMarket>,
    momentum: Object.fromEntries(rows.map((r, i) => [r.key, mom[i]])) as Record<FlowMarketKey, FlowMomentum | null>,
    ranks: Object.fromEntries(rows.map((r, i) => [r.key, ranks[i]])) as Record<FlowMarketKey, number | null>,
    totalUsd,
    rotationText: rotation.text,
    missing: missing.map((m) => m.what),
  }
  if (hasAnyAum) await writeFlowSnapshot(day, record)
  payload.snapshot = await flowSnapshotStats()

  // 全部市场都没有值 ⇒ 分两种情形（都不许用 0/空表冒充）
  if (!hasAnyAum) {
    const snapDays = Object.keys(snap.days).sort()
    if (snapDays.length === 0) {
      // 连快照都没有：**不能**说"来自最近一次快照"（那会误导成有兜底）
      payload.missing = [
        { what: '实时取数', why: 'transient', note: '五个市场的上游本次全部失败，且本地还没有任何快照 ⇒ 这一屏没有数据可显示（不是来自快照）；下面逐行给出各自的失败原因' },
        ...missing,
      ]
      return payload
    }
    const fallback = await payloadFromSnapshot(snap, payload.snapshot, now, day, 'fallback')
    fallback.missing = [
      { what: '实时取数', why: 'transient', note: `五个市场的上游本次全部失败 ⇒ 下表与曲线来自最近一次本地快照（${snapDays[snapDays.length - 1]}），不是实时值` },
      // 保留每一处失败的真实原因：否则回退以后只剩一句"全部失败"，看不到是哪一个源挂了
      ...missing,
      ...fallback.missing.filter((m) => m.what !== '实时取数' && m.what !== '本地快照' && m.what !== '实时取数'),
    ]
    return fallback
  }
  return payload
}

function observedMapOf(snap: FlowSnapshotFile): Map<string, ObservedDay> {
  const out = new Map<string, ObservedDay>()
  for (const [day, rec] of Object.entries(snap.days)) {
    const aumNative = FLOW_MARKET_ORDER.map((k) => rec.markets?.[k]?.aumNative ?? null)
    out.set(day, { at: rec.at, rates: rec.rates ?? { usdCny: null, usdHkd: null }, aumNative })
  }
  return out
}

/** 只用本地快照装配载荷（零上游请求） */
async function payloadFromSnapshot(
  snap: FlowSnapshotFile,
  stats: {
    path: string
    days: number
    bytes: number | null
    firstDay: string | null
    lastDay: string | null
    purged: FlowSnapshotPurged[]
  },
  now: number,
  day: string,
  source: 'snapshot' | 'fallback' = 'snapshot',
): Promise<GlobalFlowPayload> {
  const keys = Object.keys(snap.days).sort()
  const points: FlowPoint[] = keys.map((d) => {
    const rec = snap.days[d]
    const aumUsd = FLOW_MARKET_ORDER.map((k) => rec.markets?.[k]?.aumUsd ?? null)
    // 权重走**偏好分**（存进快照的那一份）：规模缺了不影响权重，只有偏好分缺才不进分母
    const pref = FLOW_MARKET_ORDER.map((k) => rec.markets?.[k]?.pref ?? null)
    return { day: d, origin: 'observed' as const, aumUsd, pref, share: sharesFromScores(pref), partial: pref.some((v) => v === null) }
  })
  const lastRec = keys.length > 0 ? snap.days[keys[keys.length - 1]] : null
  const lastPoint = points.length > 0 ? points[points.length - 1] : null
  const latest = lastPoint?.share ?? FLOW_MARKET_ORDER.map(() => null)
  const prevIdx = points.length - 1 - FLOW_ROTATION_WINDOW
  const rotation = lastRec !== null && prevIdx >= 0
    ? rotationOf({ latest, previous: points[prevIdx].share })
    : { kind: 'unknown' as const, fromKey: null, toKey: null, maxAbsPp: null, comparable: 0, window: FLOW_ROTATION_WINDOW, text: '本地快照还不够（没有 5 个交易日的记录）⇒ 判不了轮动（不是"没有轮动"）' }
  const rows: FlowMarketRow[] = FLOW_MARKETS.map((def, i) => {
    const rec = lastRec?.markets?.[def.key]
    const share = latest[i] ?? null
    const pref = lastPoint?.pref[i] ?? null
    const prev1 = points.length >= 2 ? points[points.length - 2].share[i] : null
    return {
      pref,
      prefSource: `偏好分 = ${FLOW_PREF_WEIGHTS.greed} × 贪婪值（${FLOW_GREED_WINDOW} 日区间分位）+ ${FLOW_PREF_WEIGHTS.mom5} × ${FLOW_PREF_MOM_WINDOWS[0]} 日动量分位 + ${FLOW_PREF_WEIGHTS.mom20} × ${FLOW_PREF_MOM_WINDOWS[1]} 日动量分位`,
      key: def.key,
      name: def.name,
      etf: def.etf,
      aumSource: def.aumSource,
      currency: def.currency,
      benchmark: def.benchmark,
      benchmarkSource: def.benchmarkSource,
      aumNative: rec?.aumNative ?? null,
      aumUsd: rec?.aumUsd ?? null,
      share,
      sharePct: share === null ? null : share * 100,
      delta1Pp: share === null || prev1 === null ? null : (share - prev1) * 100,
      delta5Pp: prevIdx >= 0 && latest[i] !== null && points[prevIdx].share[i] !== null ? ((latest[i] as number) - (points[prevIdx].share[i] as number)) * 100 : null,
      momentum: lastRec?.momentum?.[def.key] ?? null,
      rank: lastRec?.ranks?.[def.key] ?? null,
      missing: rec === undefined ? '本地快照里没有这一天的记录（本功能上线后第一天开始累积）' : null,
    }
  })
  const aumUsd = rows.map((r) => r.aumUsd)
  const missing: MissingField[] = keys.length === 0
    ? [{ what: '本地快照', why: 'transient', note: '本地还没有任何快照（本功能上线后第一天开始累积，一天一条、保留 90 天）⇒ 这一屏显示「未取到」，不编造历史' }]
    : [{ what: '实时取数', why: 'transient', note: `本次只读本地快照（零上游请求）：最新一条是 ${keys[keys.length - 1]}。要看实时值请用默认模式（不带 source=snapshot）` }]
  return {
    asOf: now,
    day,
    source,
    fallbackDay: lastRec === null ? null : keys[keys.length - 1],
    fx: {
      usdCny: lastRec?.rates?.usdCny ?? null,
      usdHkd: lastRec?.rates?.usdHkd ?? null,
      at: lastRec?.at ?? null,
      source: `新浪 ${FLOW_FX_SYMBOLS.CNY}（在岸人民币）/ ${FLOW_FX_SYMBOLS.HKD}（美元兑港元即期）`,
      note: lastRec === null ? '本地还没有快照，因此汇率也是未取到' : '取自最近一条本地快照（本次不发上游请求）',
    },
    markets: rows,
    totalUsd: aumUsd.some((v) => v !== null) ? aumUsd.reduce((s: number, v) => s + (v ?? 0), 0) : null,
    totalNote: aumUsd.some((v) => v === null) ? '合计只含有值市场；缺值市场不进分母' : null,
    rotation,
    curve: { points, window: FLOW_CURVE_WINDOW_MAX, windowOptions: [...FLOW_CURVE_WINDOWS], observedDays: points.length, rebuiltDays: 0, note: '本次只读本地快照：曲线只含已记录的日期（没有重建补齐）' },
    replay: { days: points.slice(Math.max(0, points.length - FLOW_REPLAY_DAYS)).map((p) => p.day), max: Math.max(0, Math.min(FLOW_REPLAY_DAYS, points.length) - 1), note: '回放取本地快照，不发上游请求' },
    netFlow: { code: 'sh510300', label: '沪深300ETF（510300）主力净流入', days: 0, sumCny: null, asOf: null, series: [], basis: '本地快照不保存资金流明细（单列项，不参与份额计算）', miss: '本次只读快照 ⇒ 资金流未取到' },
    snapshot: stats,
    // 快照模式**不发上游** ⇒ 宏观两档（24 小时品种）没有：如实 null + 逐条说明，不用 0 顶替
    macro: {
      us10y: null,
      dxy: null,
      notes: [
        { what: '美国 10 年期国债收益率（新浪 globalbd_us10yt）', why: 'transient', note: '本次只读本地快照（零上游请求）⇒ 24 小时品种的现值没有取到；切到实时模式即可' },
        { what: '广义美元指数（新浪 DINIW）', why: 'transient', note: '本次只读本地快照（零上游请求）⇒ 24 小时品种的现值没有取到；切到实时模式即可' },
      ],
      diag: { at: Date.now(), day, sources: [], mismatch: ['只读本地快照模式：本次没有请求任何宏观源'] },
      logPath: macroLogPath(),
    },
    notes: { ...FLOW_NOTES },
    boundary: [...FLOW_BOUNDARY],
    missing,
  }
}
