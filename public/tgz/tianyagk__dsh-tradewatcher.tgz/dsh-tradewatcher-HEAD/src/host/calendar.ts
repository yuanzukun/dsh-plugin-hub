/**
 */
import { mkdir, readFile } from 'node:fs/promises'
import { join } from 'node:path'
import type { CalCategory, CalEvent, CalImportance, MissingField } from '../shared/model.ts'
import { dataHome } from './store.ts'
import { calToday as shCalToday } from './time.ts'
import { MISSING_TIER_ADVICE } from '../shared/model.ts'
import { writeJsonAtomic } from './atomic.ts'
import { isFirstBoot, quarantineFile, ReadGuard, unreadableMissing } from './readGuard.ts'
import { log } from './context.ts'
import { withHostBreaker } from './breakerFetch.ts'

const AUTO_SYNC_TTL = 6 * 3600_000
/**
 * 同步失败后的重试冷却（P0-2）。
 *
 * 失败不再推进 `syncedAt`，因此"TTL 未到就直接返回"这条早退不再拦得住重试请求 ——
 * 没有冷却的话，上游全挂时每一次面板刷新都会重新打一遍四个源。冷却期内不重试，
 * 冷却过后再试（`force=1` 不受限制，用户手动刷新照旧）。
 */
const SYNC_FAIL_COOLDOWN = 5 * 60_000
const KEEP_PAST_DAYS = 60

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
const DC_HOST = 'datacenter-web.eastmoney.com'
/** 东财财经日历（H5 数据中心，国际/国内宏观数据公布 + 会议事件） */
const EMCAL_HOST = 'emdatah5.eastmoney.com'

/** 宏观日历覆盖窗口：过去 7 天 ~ 未来 92 天 */
const MACRO_PAST = 7
const MACRO_FUTURE = 92
const MACRO_PAGE_CAP = 26
const MACRO_PAGE_SIZE = 50
const MACRO_CONCURRENCY = 4

interface CalFile {
  v: number
  events: CalEvent[]
  hiddenAutoKeys: string[]
  /** 最近一次**成功**同步的时刻（epoch ms，0 = 从未成功）—— `asOf` 只认它 */
  syncedAt: number
  /**
   * 最近一次同步的**逐源结果**（H4：必须落盘）。
   *
   * 旧实现只放在内存（`lastSources`）⇒ 进程重启后 `syncStatus()` 看到的是"没有源失败"，
   * 于是**谎报一切正常**（`stale=false`、`missing=[]`），而这期间 UI/agent 读到的是旧事件。
   */
  lastSources?: CalSyncSourceResult[]
  /**
   * 最近一次**尝试**同步的时刻（不论成败，0 = 从未尝试）。
   *
   * 为什么必须与 `syncedAt` 分开：此前每个自动源各自 `catch {}` 吞错，然后**无条件**
   * 把 `syncedAt` 写成 `Date.now()`；断网时事件还是旧的，而界面/agent 读到"刚刚同步过、
   * 没有降级" —— 于是"没有新事件"被读成"确实没有新事件"。失败时刻不得改写数据时刻。
   */
  syncAttemptAt: number
}

/** 单个自动源在一次同步里的结果 */
export interface CalSyncSourceResult {
  key: 'ipo' | 'earnings' | 'dividend' | 'macro'
  label: string
  /**
   * ok=本次成功且有数据；failed=本次失败；skipped=本次未尝试（如没有自选 + 持仓标的时的财报/分红源）；
   * **empty=回包正常但 0 条**（H4 单列一档：与"真的没有"分不开，不算成功）
   */
  state: 'ok' | 'failed' | 'skipped' | 'empty'
  /** 本次该源写入的自动事件数（ok 时有效） */
  count: number
  error?: string
}

/**
 * 同步源的可注入入口（默认就是真实实现）。
 *
 * 存在的理由：`sync()` 里四个源此前各自 `catch {}`，因此"全挂时 asOf 会不会被改写"
 * 只能靠注入失败源来断言 —— 否则这条口径在实践中不可验证（正是它出问题的方式）。
 */
export interface CalSyncFetchers {
  /** 三类报表接口（新股申购/上市、财报预约披露、分红除权） */
  report: (reportName: string, params: Record<string, string>) => Promise<Array<Record<string, unknown>>>
  /** 东财财经日历（宏观数据/会议） */
  macroCal: (start: string, end: string) => Promise<EmCalRow[]>
}

const DEFAULT_FETCHERS: CalSyncFetchers = { report: fetchReport, macroCal: fetchEconomicCalendar }

/** 同步状态（工具与路由共用同一份判定，不各自解释） */
export interface CalSyncStatus {
  /** 最近一次成功同步时刻；从未成功过为 null */
  syncedAt: number | null
  /** 最近一次尝试时刻；从未尝试过为 null */
  attemptAt: number | null
  /** 是否有源失败（`skipped` 不算失败）——为真表示本次返回的事件里有"上次的旧值" */
  stale: boolean
  /** 失败源的缺失明细，可直接并入工具/路由的 `missing[]` */
  missing: MissingField[]
  /** 本次各源明细（成功/失败/未尝试） */
  sources: CalSyncSourceResult[]
  /** 四个源全部失败（本次尝试没换来任何新数据） */
  allFailed: boolean
}

/** 供路由使用：今天的 YYYY-MM-DD（可偏移天数） */
export function calToday(offsetDays = 0): string {
  return todayStr(offsetDays)
}

/** 北京时间的今天（可偏移）：财经日历的"今日/±N 天"与归档日期一律用该口径 */
function todayStr(offsetDays = 0): string {
  return shCalToday(offsetDays)
}

function dayOf(v: unknown): string | null {
  if (typeof v !== 'string' || v.length < 10) return null
  const s = v.slice(0, 10)
  return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null
}

async function fetchReport(reportName: string, params: Record<string, string>): Promise<Array<Record<string, unknown>>> {
  const q = new URLSearchParams({ reportName, columns: 'ALL', source: 'WEB', client: 'WEB', ...params })
  const url = `https://${DC_HOST}/api/data/v1/get?${q.toString()}`
  // H1：日历的数据中心主机此前是裸 fetch（不记账）⇒ 挂起时每次都付满超时、降级横幅也看不见
  const res = await withHostBreaker(DC_HOST, () =>
    fetch(url, {
      headers: { 'user-agent': UA, referer: 'https://data.eastmoney.com/' },
      signal: AbortSignal.timeout(12_000),
    }),
  )
  if (!res.ok) throw new Error(`HTTP ${res.status} from ${DC_HOST}`)
  const json = (await res.json()) as { result?: { data?: Array<Record<string, unknown>> } }
  const rows = json?.result?.data
  return Array.isArray(rows) ? rows : []
}

/** ── 东财财经日历（宏观）───────────────────────────────────────────────
 * 接口：https://emdatah5.eastmoney.com/dc/CJRL/GetIndexData
 *   参数 startDate/endDate（YYYY-MM-DD）、type、pIndex、pSize（服务端固定上限 50）
 *   返回 [{ Data: [{ STARTDATE, ENDDATE, FINCODE, FINNAME, TDATE, TOTALCOUNT }] }]
 * FINNAME 形如「美国:非农就业人数:季调(报告期:2026年08月)」「美联储议息会议」，
 * STARTDATE 为北京时间公布时刻。无 actual/forecast/previous 字段。
 */
interface EmCalRow {
  STARTDATE?: string
  ENDDATE?: string
  FINCODE?: string | number
  FINNAME?: string
}

/** 核心经济体归一化（其余经济体不入库，避免日历被小众数据淹没） */
const EM_ECONOMY: Record<string, string> = {
  美国: '美国',
  中国: '中国',
  中国香港: '中国香港',
  中国台湾: '中国台湾',
  中国澳门: '中国澳门',
  欧元区: '欧元区',
  欧盟: '欧盟',
  日本: '日本',
  英国: '英国',
  德国: '德国',
  法国: '法国',
  意大利: '意大利',
  加拿大: '加拿大',
  澳大利亚: '澳大利亚',
  瑞士: '瑞士',
  韩国: '韩国',
  印度: '印度',
  俄罗斯: '俄罗斯',
  巴西: '巴西',
  新加坡: '新加坡',
}

export function canonicalEconomy(key: string): string | null {
  if (EM_ECONOMY[key] !== undefined) return EM_ECONOMY[key]
  // 「美国EIA原油库存」「欧元区19国」「欧盟27国」等带后缀的写法归一
  if (key.startsWith('美国')) return '美国'
  if (key.startsWith('欧元区')) return '欧元区'
  if (key.startsWith('欧盟')) return '欧盟'
  if (key.startsWith('中国')) return '中国'
  return null
}

const MACRO_CN_ECONOMIES = new Set(['中国', '中国香港', '中国台湾', '中国澳门'])

const RE_MACRO_INTL = /(美联储|美国|欧央行|欧洲央行|欧元区|欧盟|日本央行|英国央行|鲍威尔|FOMC)/
const RE_MACRO_CN = /(中国|国务院|发改委|财政部|统计局|人民银行|央行|证监会|中央经济工作会议|两会|政治局|上交所|深交所|北交所)/

const RE_IMP3 = /(议息|利率决议|联邦基金利率|贷款市场报价利率|LPR|非农|CPI|消费者物价|PCE|GDP|国内生产总值|中央经济工作会议|两会|政治局|关税|加息|降息|上市首日)/
const RE_IMP2 = /(PPI|生产者价格|PMI|采购经理|零售|工业增加值|社会融资|M2|货币供应|新增人民币贷款|进出口|贸易帐|失业率|失业金|ADP|消费者信心|成屋|新屋|工业订单|库存|外汇储备|工业产出|通胀|价格指数|出口金额|进口金额|制造业)/

/** 重要性启发式：先命中高优先关键词，再中，最后低 */
export function macroImportance(text: string): CalImportance {
  // 「中国：库存:铁矿石:46港」这类高频库存分项降级
  if (/库存/.test(text) && /(48港|46港|45港|港口|保税区)/.test(text)) return 1
  if (RE_IMP3.test(text)) return 3
  if (RE_IMP2.test(text)) return 2
  return 1
}

export function macroCategory(economy: string | null, raw: string): CalCategory {
  if (economy !== null) return MACRO_CN_ECONOMIES.has(economy) ? 'macro-cn' : 'macro-intl'
  if (RE_MACRO_INTL.test(raw)) return 'macro-intl'
  if (RE_MACRO_CN.test(raw)) return 'macro-cn'
  return 'other'
}

/** 「2026/9/17 2:00:00」→ { date:'2026-09-17', time:'02:00', endDate? }；00:00 视为未定时刻 */
export function parseEmDate(start: unknown, end: unknown): { date: string; time?: string; endDate?: string } | null {
  const m = /^(\d{4})\/(\d{1,2})\/(\d{1,2})(?:\s+(\d{1,2}):(\d{2}))?/.exec(String(start ?? '').trim())
  if (m === null) return null
  const p = (n: number): string => String(n).padStart(2, '0')
  const date = `${m[1]}-${p(Number(m[2]))}-${p(Number(m[3]))}`
  const hh = m[4] === undefined ? 0 : Number(m[4])
  const mm = m[5] === undefined ? 0 : Number(m[5])
  const time = hh === 0 && mm === 0 ? undefined : `${p(hh)}:${p(mm)}`
  const e = /^(\d{4})\/(\d{1,2})\/(\d{1,2})/.exec(String(end ?? '').trim())
  const endDate = e === null ? undefined : `${e[1]}-${p(Number(e[2]))}-${p(Number(e[3]))}`
  return { date, time, endDate: endDate !== undefined && endDate > date ? endDate : undefined }
}

/** 把东财财经日历原始行转成日历事件（纯函数，便于自检） */
export function macroEventsFromEm(rows: EmCalRow[]): Array<Omit<CalEvent, 'id' | 'source'>> {
  const out = new Map<string, Omit<CalEvent, 'id' | 'source'>>()
  for (const row of rows) {
    const name = String(row.FINNAME ?? '').trim()
    if (name === '') continue
    const when = parseEmDate(row.STARTDATE, row.ENDDATE)
    if (when === null) continue
    let economy: string | null = null
    let body = name
    const prefix = /^([^:：]{1,14})[:：]\s*(.+)$/.exec(name)
    if (prefix !== null) {
      economy = canonicalEconomy(prefix[1])
      if (economy === null) continue // 非核心经济体：跳过
      body = prefix[2].trim()
    }
    const periodMatch = /\(报告期[:：]?\s*([^)]*)\)/.exec(body)
    const period = periodMatch === null ? '' : periodMatch[1].trim()
    body = body.replace(/\(报告期[:：]?[^)]*\)/g, '').replace(/\s{2,}/g, ' ').trim()
    if (body === '') continue
    const title = economy === null ? body : `${economy} ${body}`
    const code = String(row.FINCODE ?? '')
    const stamp = `${when.date.replace(/-/g, '')}${(when.time ?? '0000').replace(':', '')}`
    const autoKey = `macro:${code !== '' ? code : title}:${stamp}`
    if (out.has(autoKey)) continue
    out.set(autoKey, {
      date: when.date,
      endDate: when.endDate,
      time: when.time,
      title: title.slice(0, 80),
      category: macroCategory(economy, name),
      importance: macroImportance(name),
      autoKey,
      note: [period === '' ? '' : `报告期 ${period}`, '东方财富财经日历'].filter(Boolean).join(' · '),
    })
  }
  return [...out.values()]
}

/** 分页抓取东财财经日历（服务端 pSize 上限 50，按 TOTALCOUNT 决定页数）
 * 整体 20s 预算：超时后放弃剩余页，已有数据照常入库，避免单源拖慢日历请求。 */
async function fetchEconomicCalendar(start: string, end: string): Promise<EmCalRow[]> {
  const deadline = Date.now() + 20_000
  const page = async (pIndex: number): Promise<EmCalRow[]> => {
    const budget = deadline - Date.now()
    if (budget <= 0) return []
    const q = new URLSearchParams({
      startDate: start, endDate: end, type: 'economics', pIndex: String(pIndex), pSize: String(MACRO_PAGE_SIZE),
    })
    const res = await withHostBreaker(EMCAL_HOST, () =>
      fetch(`https://${EMCAL_HOST}/dc/CJRL/GetIndexData?${q.toString()}`, {
        headers: { 'user-agent': UA, referer: `https://${EMCAL_HOST}/dc/cjrl/index` },
        signal: AbortSignal.timeout(Math.min(8000, budget)),
      }),
    )
    if (!res.ok) throw new Error(`HTTP ${res.status} from ${EMCAL_HOST}`)
    const text = await res.text()
    const groups = JSON.parse(text) as Array<{ Data?: EmCalRow[] }>
    const rows = Array.isArray(groups) ? groups[0]?.Data : undefined
    return Array.isArray(rows) ? rows : []
  }
  const first = await page(1)
  if (first.length === 0) return []
  const total = Number((first[0] as { TOTALCOUNT?: string | number }).TOTALCOUNT ?? first.length)
  const pages = Math.min(MACRO_PAGE_CAP, Math.max(1, Math.ceil(total / MACRO_PAGE_SIZE)))
  const rest = Array.from({ length: pages - 1 }, (_, i) => i + 2)
  const out: EmCalRow[] = [...first]
  for (let i = 0; i < rest.length; i += MACRO_CONCURRENCY) {
    const batch = rest.slice(i, i + MACRO_CONCURRENCY)
    const got = await Promise.all(batch.map((p) => page(p).catch((): EmCalRow[] => [])))
    for (const rows of got) out.push(...rows)
  }
  return out
}

/**
 * 把改期/改名历史带进新一轮同步结果（P1-10，纯函数）。
 *
 * 上游（东财）会悄悄把上市日/披露日往后挪；只显示"最新日期"等于把变更事实抹掉 ——
 * 用户无法回答"我按 10-09 准备的怎么变成 10-16 了"。这里按 `autoKey` 对上一条，
 * 把 date/endDate/title 的变化记进 `changes`（最新在后，最多 5 条）。
 *
 * 为什么只留 5 条：改期历史再长也没有可操作性，反而把详情卡撑爆；真正要回答的是
 * "变过没有、从什么变成什么"。
 */
export function withChangeHistory(
  prevEvents: readonly CalEvent[],
  fresh: readonly CalEvent[],
  now: number,
): CalEvent[] {
  const prevByKey = new Map<string, CalEvent>()
  for (const e of prevEvents) {
    if (e.source === 'auto' && e.autoKey !== undefined) prevByKey.set(e.autoKey, e)
  }
  return fresh.map((e) => {
    const prev = e.autoKey === undefined ? undefined : prevByKey.get(e.autoKey)
    if (prev === undefined) return e
    const changes = [...(prev.changes ?? [])]
    const push = (field: 'date' | 'endDate' | 'title', from: string, to: string): void => {
      if (from === to) return
      changes.push({ at: now, field, from, to })
    }
    push('date', prev.date, e.date)
    push('endDate', prev.endDate ?? '', e.endDate ?? '')
    push('title', prev.title, e.title)
    if (changes.length === 0) return e
    return { ...e, changes: changes.slice(-5) }
  })
}

export class CalendarStore {
  private dir: string
  private file: CalFile = { v: 1, events: [], hiddenAutoKeys: [], syncedAt: 0, syncAttemptAt: 0 }
  private loaded: Promise<void> | null = null
  private writeChain: Promise<void> = Promise.resolve()
  private syncing: Promise<void> | null = null
  /** 最近一次尝试的各源明细（内存态：重启后由下一次同步重新填） */
  private lastSources: CalSyncSourceResult[] = []
  /** 最近一次调用 `sync()` 时同步过程本身抛出的错误（非逐源失败） */
  private lastThrown: string | null = null
  private seq = 0
  /**
   * 「读不到」≠「空库」（R1）：本地 calendar.json 读失败（非 ENOENT）时**禁止写回** ——
   * 否则自动同步拿到的"新库"会把用户手记的事件整份覆盖掉（实测：手记事件消失）。
   * 键用完整路径。
   */
  private readonly readGuard = new ReadGuard()

  constructor(dir: string = dataHome()) {
    this.dir = dir
  }

  private path(): string {
    return join(this.dir, 'calendar.json')
  }

  async init(): Promise<void> {
    if (this.loaded !== null) return this.loaded
    this.loaded = (async () => {
      await mkdir(this.dir, { recursive: true }).catch(() => undefined)
      let raw: string
      try {
        raw = await readFile(this.path(), 'utf8')
        this.readGuard.clear(this.path())
      } catch (error) {
        if (isFirstBoot(error)) return /* 首次：确实还没有这份文件 ⇒ 空库是真话 */
        // ⚠ 读不到 ≠ 空库：本次启动拒绝写回（否则同步一落盘就把用户手记的事件抹掉）
        const reason = this.readGuard.markUnreadable(this.path(), error)
        log(`calendar read failed: ${reason} —— 读不到 ≠ 空库：本次启动拒绝写回 calendar.json（避免覆盖用户手记的事件）`)
        return
      }
      try {
        const parsed = JSON.parse(raw) as Partial<CalFile>
        this.file = {
          v: 1,
          events: Array.isArray(parsed.events) ? parsed.events : [],
          hiddenAutoKeys: Array.isArray(parsed.hiddenAutoKeys) ? parsed.hiddenAutoKeys : [],
          syncedAt: typeof parsed.syncedAt === 'number' ? parsed.syncedAt : 0,
          // 旧文件没有该字段：当作"从未记录过尝试"，装载不因一个坏字段失败
          syncAttemptAt: typeof parsed.syncAttemptAt === 'number' ? parsed.syncAttemptAt : 0,
          // H4：上次的逐源结果也要恢复 —— 否则重启即"洗白"成 stale=false / missing=[]
          lastSources: Array.isArray(parsed.lastSources) ? (parsed.lastSources as CalSyncSourceResult[]) : [],
        }
        this.lastSources = this.file.lastSources ?? []
      } catch (error) {
        // 「读到了但内容坏」与「读不到」不同：先隔离原件（保留原字节）再从容器的空库开始，
        // 与 store.ts 的 quarantine 同口径 —— 绝不静默覆盖用户数据
        const kept = await quarantineFile(this.path())
        log(`corrupt calendar.json (bad JSON) — ${kept === null ? '隔离失败，已改为不写回' : `已隔离为 ${kept}`}`, error instanceof Error ? error.message : String(error))
        if (kept === null) this.readGuard.markUnreadable(this.path(), error)
      }
    })()
    return this.loaded
  }

  private persist(): Promise<void> {
    const run = this.writeChain.then(async () => {
      // 读不到过的本地文件一律拒绝整份覆写（R1）
      this.readGuard.assertWritable(this.path(), '写回日历事件')
      // 原子替换：既避免写入中途被读到半截文件，也不再残留 .tmp（旧实现是双写）
      await writeJsonAtomic(this.path(), this.file)
    })
    this.writeChain = run.catch(() => undefined)
    return run
  }

  private newId(): string {
    this.seq += 1
    return `ce${Date.now().toString(36)}${this.seq.toString(36)}`
  }

  /** 可见事件（隐藏的自动事件被过滤） */
  list(from: string, to: string): CalEvent[] {
    const hidden = new Set(this.file.hiddenAutoKeys)
    return this.file.events
      .filter((e) => {
        if (e.source === 'auto' && e.autoKey !== undefined && hidden.has(e.autoKey)) return false
        const start = e.date
        const end = e.endDate ?? e.date
        return start <= to && end >= from
      })
      .sort((a, b) => {
        if (a.date !== b.date) return a.date < b.date ? -1 : 1
        if (a.importance !== b.importance) return b.importance - a.importance
        return (a.time ?? '99:99').localeCompare(b.time ?? '99:99')
      })
  }

  /** 最近一次**成功**同步的时刻（0 = 从未成功）。`asOf` 只认它，失败时刻不得改写数据时刻 */
  get syncedAt(): number {
    return this.file.syncedAt
  }

  /** 最近一次**尝试**同步的时刻（0 = 从未尝试） */
  get syncAttemptAt(): number {
    return this.file.syncAttemptAt
  }

  /**
   * 同步状态（工具与路由共用这一份判定）。
   *
   * `asOf` = 最近一次成功同步时刻（从未成功过 ⇒ null，**不拿"现在"顶替**）；
   * `stale` = 最近一次尝试里有源失败；`missing[]` = 失败源及其原因。
   */
  syncStatus(): CalSyncStatus {
    const sources = this.lastSources
    const attempted = sources.filter((s) => s.state !== 'skipped')
    const failed = attempted.filter((s) => s.state === 'failed')
    const ok = attempted.filter((s) => s.state === 'ok')
    /** 「200 但 0 条」单列一档（H4）：既不算成功也不算失败 —— 它与"真的没有"分不开 */
    const empty = attempted.filter((s) => s.state === 'empty')
    const missing: MissingField[] = failed.map((s) => ({
      what: s.label,
      // 失败原因都是"这次没拿到"（上游超时/限流/不可达），稍后重试可恢复
      why: 'transient',
      note: `本次同步未取到（${s.error ?? '上游不可用'}）；该类别仍是上一次成功同步的事件（若有）—— ${MISSING_TIER_ADVICE.transient}`,
    }))
    for (const s of empty) {
      missing.push({
        what: s.label,
        why: 'no-source',
        note: `本次回包正常但这一档 0 条（无法与"窗口内确实没有"区分，也可能是上游结构变化/筛选失效）—— 重试通常无用，必要时核对上游字段`,
      })
    }
    if (this.lastThrown !== null) {
      missing.push({
        what: '日历同步',
        why: 'transient',
        note: `本次同步过程出错（${this.lastThrown}）；返回的是本地已有事件 + 手动事件 —— ${MISSING_TIER_ADVICE.transient}`,
      })
    }
    // 本地文件读不到（R1）：必须在**同步状态**里说清楚 —— 此时返回的事件可能不含用户手记的那些，
    // 而且本次启动不会写回（否则会把它们整份覆盖掉）
    missing.push(...unreadableMissing(this.readGuard.entries, '本地日历文件'))
    return {
      syncedAt: this.file.syncedAt > 0 ? this.file.syncedAt : null,
      attemptAt: this.file.syncAttemptAt > 0 ? this.file.syncAttemptAt : null,
      // 有源失败即视为降级（本次返回的事件里含上一次成功同步的旧值）；
      // 从未成功同步过也算降级 —— 那时根本没有可信的 asOf
      stale:
        this.file.syncedAt <= 0 ||
        failed.length > 0 ||
        empty.length > 0 ||
        this.lastThrown !== null ||
        this.readGuard.entries.length > 0,
      missing,
      sources,
      allFailed: sources.length > 0 && ok.length === 0,
    }
  }

  /** 本次启动"读不到"的本地文件与原因（R1 披露用） */
  readFailures(): ReadonlyArray<{ file: string; reason: string }> {
    return this.readGuard.entries
  }

  /** 手动事件 CRUD（自动事件只允许隐藏/恢复） */
  async mutate(body: Record<string, unknown>): Promise<CalEvent[]> {
    await this.init()
    const op = String(body.op ?? '')
    if (op === 'add' || op === 'update') {
      const date = String(body.date ?? '')
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('日期格式应为 YYYY-MM-DD')
      const title = String(body.title ?? '').trim()
      if (title === '' || title.length > 80) throw new Error('事件标题必填且 ≤ 80 字')
      const category = String(body.category ?? 'other') as CalCategory
      const importanceRaw = Number(body.importance ?? 2)
      const importance = (importanceRaw === 1 || importanceRaw === 2 || importanceRaw === 3 ? importanceRaw : 2) as CalImportance
      const note = body.note === undefined || body.note === null ? undefined : String(body.note).slice(0, 500)
      const symbol = body.symbol === undefined || body.symbol === null || body.symbol === '' ? undefined : String(body.symbol).slice(0, 24)
      const endDate = /^\d{4}-\d{2}-\d{2}$/.test(String(body.endDate ?? '')) ? String(body.endDate) : undefined
      if (op === 'add') {
        this.file.events.push({ id: this.newId(), date, endDate, title, category, importance, note, symbol, source: 'manual' })
      } else {
        const id = String(body.id ?? '')
        const hit = this.file.events.find((e) => e.id === id)
        if (hit === undefined) throw new Error('事件不存在')
        if (hit.source === 'auto') throw new Error('自动事件不可编辑，只能隐藏')
        Object.assign(hit, { date, endDate, title, category, importance, note, symbol })
      }
    } else if (op === 'remove') {
      const id = String(body.id ?? '')
      const idx = this.file.events.findIndex((e) => e.id === id)
      if (idx === -1) throw new Error('事件不存在')
      if (this.file.events[idx].source === 'auto') throw new Error('自动事件不可删除，只能隐藏')
      this.file.events.splice(idx, 1)
    } else if (op === 'hideAuto' || op === 'restoreAuto') {
      const key = String(body.autoKey ?? '')
      if (key === '') throw new Error('缺少 autoKey')
      const set = new Set(this.file.hiddenAutoKeys)
      if (op === 'hideAuto') set.add(key)
      else set.delete(key)
      this.file.hiddenAutoKeys = [...set]
    } else {
      throw new Error(`未知操作: ${op}`)
    }
    await this.persist()
    return this.file.events
  }

  /** 自动同步（TTL 内直接返回；并发去重）。symbols = 自选 + 持仓标的的 6 位代码 */
  async sync(symbols: string[], force = false, fetchers: CalSyncFetchers = DEFAULT_FETCHERS): Promise<void> {
    await this.init()
    // 成功过且还在 TTL 内 → 直接用本地；失败过则按冷却窗口重试，避免上游全挂时
    // 每次面板刷新都重打一遍（旧的"无条件写 syncedAt"其实充当了这个节流，但它同时损坏了 asOf）
    if (!force && Date.now() - this.file.syncedAt < AUTO_SYNC_TTL) return
    if (!force && Date.now() - this.file.syncAttemptAt < SYNC_FAIL_COOLDOWN) return
    if (this.syncing !== null) return this.syncing
    this.syncing = (async () => {
      const auto: CalEvent[] = []
      const push = (e: Omit<CalEvent, 'id' | 'source'>): void => {
        auto.push({ ...e, id: `auto:${e.autoKey ?? Math.random()}`, source: 'auto' })
      }
      /**
       * 逐源执行并**记录结果**（P0-2）。
       *
       * 此前四个源各自 `catch {}`：失败不可见，而且随后无条件把 `syncedAt` 写成"现在"，
       * 于是上游全挂时 agent/界面读到的是"刚刚同步过、无降级"。现在每个源的结果都进
       * `lastSources`，由 `syncStatus()` 统一翻译成 asOf/stale/missing。
       */
      const results: CalSyncSourceResult[] = []
      const run = async (key: CalSyncSourceResult['key'], label: string, body: () => Promise<void>): Promise<void> => {
        const before = auto.length
        try {
          await body()
          const count = auto.length - before
          // H4：**200 但 0 条**不许记成 ok —— 那与"真的没有"分不开（结构变化/筛选失效也会 0 条），
          // 旧实现记 ok 并推进 syncedAt ⇒ 界面读到"刚刚同步过、没有降级"（上游改字段时尤其危险）
          results.push({ key, label, state: count > 0 ? 'ok' : 'empty', count })
        } catch (error) {
          results.push({ key, label, state: 'failed', count: 0, error: error instanceof Error ? error.message : String(error) })
        }
      }
      // 1) 新股申购 / 上市
      await run('ipo', '新股申购/上市日历', async () => {
        const rows = await fetchers.report('RPTA_APP_IPOAPPLY', {
          pageSize: '200', pageNumber: '1', sortColumns: 'APPLY_DATE', sortTypes: '-1',
        })
        const from = todayStr(-KEEP_PAST_DAYS)
        const to = todayStr(150)
        for (const r of rows) {
          const code = String(r.SECURITY_CODE ?? '')
          const name = String(r.SECURITY_NAME_ABBR ?? r.SECURITY_NAME_FULL ?? r.SECURITY_NAME ?? code)
          const apply = dayOf(r.APPLY_DATE)
          const listing = dayOf(r.LISTING_DATE)
          const price = r.ISSUE_PRICE !== null && r.ISSUE_PRICE !== undefined && Number(r.ISSUE_PRICE) > 0 ? `发行价 ${r.ISSUE_PRICE}` : ''
          if (apply !== null && apply >= from && apply <= to) {
            push({
              date: apply, title: `${name} 申购`, category: 'ipo', importance: 1, symbol: code,
              autoKey: `ipo:${code}:apply`, note: [price, '新股网上/网下申购日'].filter(Boolean).join(' · '),
            })
          }
          if (listing !== null && listing >= from && listing <= to) {
            push({
              date: listing, title: `${name} 上市`, category: 'ipo', importance: 2, symbol: code,
              autoKey: `ipo:${code}:listing`, note: [price, '新股上市首日'].filter(Boolean).join(' · '),
            })
          }
        }
      })
      // 2) 自选 + 持仓标的的财报预约披露 + 3) 分红除权（没有自选 + 持仓标的时**未尝试**，不算失败）
      if (symbols.length === 0) {
        results.push({ key: 'earnings', label: '财报预约披露', state: 'skipped', count: 0 })
        results.push({ key: 'dividend', label: '分红除权除息', state: 'skipped', count: 0 })
      } else {
        const list = symbols.slice(0, 60).map((c) => `"${c}"`).join(',')
        const from = todayStr(-14)
        const to = todayStr(120)
        await run('earnings', '财报预约披露', async () => {
          const rows = await fetchers.report('RPT_PUBLIC_BS_APPOIN', {
            pageSize: '200', pageNumber: '1',
            filter: `(SECURITY_CODE in (${list}))`,
            sortColumns: 'APPOINT_PUBLISH_DATE', sortTypes: '-1',
          })
          for (const r of rows) {
            const code = String(r.SECURITY_CODE ?? '')
            const name = String(r.SECURITY_NAME_ABBR ?? code)
            const date = dayOf(r.APPOINT_PUBLISH_DATE) ?? dayOf(r.ACTUAL_PUBLISH_DATE)
            if (date === null || date < from || date > to) continue
            const period = String(r.REPORT_TYPE_NAME ?? '')
            const published = String(r.IS_PUBLISH ?? '') === '1'
            push({
              date, title: `${name} ${period}财报`, category: 'earnings',
              importance: published ? 1 : 2, symbol: code,
              autoKey: `earn:${code}:${String(r.REPORT_DATE ?? date).slice(0, 10)}`,
              note: published ? '已披露（实际披露日）' : '预约披露日期',
            })
          }
          })
        await run('dividend', '分红除权除息', async () => {
          const rows = await fetchers.report('RPT_SHAREBONUS_DET', {
            pageSize: '200', pageNumber: '1',
            filter: `(SECURITY_CODE in (${list}))`,
            sortColumns: 'PLAN_NOTICE_DATE', sortTypes: '-1',
          })
          for (const r of rows) {
            const code = String(r.SECURITY_CODE ?? '')
            const name = String(r.SECURITY_NAME_ABBR ?? code)
            const profile = String(r.IMPL_PLAN_PROFILE ?? '')
            const reportDate = String(r.REPORT_DATE ?? '').slice(0, 10)
            const ex = dayOf(r.EX_DIVIDEND_DATE)
            const rec = dayOf(r.EQUITY_RECORD_DATE)
            if (ex !== null) {
              push({
                date: ex, title: `${name} 除权除息`, category: 'dividend', importance: 2, symbol: code,
                autoKey: `div:${code}:ex:${reportDate || ex}`, note: profile,
              })
            }
            if (rec !== null) {
              push({
                date: rec, title: `${name} 股权登记`, category: 'dividend', importance: 1, symbol: code,
                autoKey: `div:${code}:rec:${reportDate || rec}`, note: profile,
              })
            }
          }
          })
      }
      // 4) 国际 / 国内宏观数据公布与会议事件（东财财经日历）
      await run('macro', '宏观数据/会议', async () => {
        const rows = await fetchers.macroCal(todayStr(-MACRO_PAST), todayStr(MACRO_FUTURE))
        for (const e of macroEventsFromEm(rows)) push(e)
      })
      // 合并：手动事件保留，自动事件按 autoKey upsert，清理过旧自动事件
      const manual = this.file.events.filter((e) => e.source === 'manual')
      const cutoff = todayStr(-KEEP_PAST_DAYS)
      const fresh = auto.filter((e) => e.date >= cutoff)
      const autoKeySet = new Set(fresh.map((e) => e.autoKey))
      const keptAuto = this.file.events.filter(
        (e) => e.source === 'auto' && e.date >= cutoff && e.autoKey !== undefined && !autoKeySet.has(e.autoKey),
      )
      this.file.events = [...manual, ...keptAuto, ...withChangeHistory(this.file.events, fresh, Date.now())]
      // 「尝试」无条件记录，「成功」只在真有源成功时才推进 —— 全挂时 asOf 必须停留在上次成功时刻
      this.file.syncAttemptAt = Date.now()
      // H4：`asOf`（syncedAt）只在**所有被尝试的源都成功**时推进 ——
      // 旧实现"任一源 ok 就推进"，于是四个源里挂一个也照样把数据时刻写成"现在"。
      // ⚠ `skipped`（没自选/持仓时的财报/分红源）既不算成功也不算失败 ⇒ 不能拦住 asOf
      const attempted = results.filter((r) => r.state !== 'skipped')
      const allOk = attempted.length > 0 && attempted.every((r) => r.state === 'ok')
      if (allOk) this.file.syncedAt = Date.now()
      this.lastSources = results
      this.file.lastSources = results // 落盘：重启后仍能如实报告降级
      this.lastThrown = null
      await this.persist()
    })()
    try {
      await this.syncing
    } catch (error) {
      // 同步过程本身出错（init/persist 等）：记录原因，但**不改写** syncedAt
      this.lastThrown = error instanceof Error ? error.message : String(error)
      this.file.syncAttemptAt = Date.now()
      throw error
    } finally {
      this.syncing = null
    }
  }
}
