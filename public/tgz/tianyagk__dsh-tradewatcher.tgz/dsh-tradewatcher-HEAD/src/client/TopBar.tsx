/** The three-strip TopBar with hover intraday/daily popups.
 *  The popup tracks the mouse cursor (flip/clamp vs viewport) and is measured
 *  after each content change so it never runs off screen. */
import React, { useCallback, useEffect, useRef, useState } from 'react'
import { TW_ROWS, stripKindOf, type QuoteRow, type TrendData, type KlineData } from '../shared/model.ts'
import { StripConfig } from './StripConfig.tsx'
import { toneBadgeView, visibleCards, type ToneRow } from './stripTone.ts'
import { chartCache } from './chartCache.ts'
import { fmtClock, fmtPct, fmtPrice, fmtSigned, dirClass } from './format.ts'
import { NO_SOURCE_LABEL, NO_SOURCE_TITLE, QUOTE_STATE_COLOR, QUOTE_STATE_LABEL, quoteStateOf, quoteStateTitle, summarizeQuoteStates, type QuoteState } from './quoteState.ts'
import { useNow } from './useNow.ts'
import { Sparkline } from './charts.tsx'
import { Btn, Modal } from './ui.tsx'
import { PANEL_OPACITY_MAX, PANEL_OPACITY_MIN, normalizePanelOpacity } from '../shared/model.ts'
import type { PortPrefs } from '../shared/model.ts'
import { isUsableBaseline } from './trendView.ts'
import { api } from './api.ts'

interface HoverState {
  secid: string
  name: string
}

type PopKind = 'loading' | 'trend' | 'kline' | 'none' | 'error'

function HoverCard(props: {
  hover: HoverState
  quote: QuoteRow | undefined
  prefs: PortPrefs
  popRef: { current: HTMLDivElement | null }
  onSized: () => void
  onOpen: () => void
  onEnter: () => void
  onLeave: () => void
}): React.ReactElement {
  const { hover, quote, prefs, popRef, onSized, onOpen, onEnter, onLeave } = props
  const [kind, setKind] = useState<PopKind>('loading')
  const [data, setData] = useState<TrendData | KlineData | null>(null)

  useEffect(() => {
    let alive = true
    setKind('loading')
    setData(null)
    // 与详情抽屉共用客户端图表缓存：同一只标的来回划过只发一次请求
    chartCache
      .get(hover.secid, 'trend')
      .then(async (p) => {
        if (!alive) return
        if (p !== null && p.kind === 'trend') {
          setKind('trend')
          setData(p.trend)
          return
        }
        const d = await chartCache.get(hover.secid, 'day')
        if (!alive) return
        if (d !== null && d.kind === 'kline') {
          setKind('kline')
          setData(d.kline)
        } else {
          setKind('none')
        }
      })
      .catch(() => {
        if (alive) setKind('error')
      })
    return () => {
      alive = false
    }
  }, [hover.secid])

  // 内容（加载→图表）尺寸变化后重新夹紧位置，避免溢出屏幕
  useEffect(() => {
    onSized()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, data])

  const upColor = prefs.redUp ? 'var(--tw-up)' : 'var(--tw-down)'
  const downColor = prefs.redUp ? 'var(--tw-down)' : 'var(--tw-up)'
  const price = quote?.price ?? null
  const dir = dirClass(quote?.chg ?? null, prefs.redUp)

  // points for SVG
  let sparkPoints: Array<{ t: number; value: number; label?: string }> = []
  let baseline: number | null = null
  let sub = ''
  if (kind === 'trend' && data !== null) {
    const t = data as TrendData
    baseline = isUsableBaseline(t.prePrice) ? t.prePrice : null
    sparkPoints = t.points.map((p) => ({ t: p.t, value: p.price, label: p.label.slice(11) }))
    const last = t.points[t.points.length - 1]
    sub = last !== undefined ? `${last.label.slice(5, 16)} 收盘` : ''
  } else if (kind === 'kline' && data !== null) {
    const k = data as KlineData
    const days = k.days
    if (days.length > 0) {
      const t0 = Date.parse(`${days[0].date}T00:00:00`)
      const step = days.length > 1 ? (Date.parse(`${days[1].date}T00:00:00`) - t0) : 86400000
      baseline = days.length > 1 ? days[days.length - 2].close : days[0].open
      sparkPoints = days.map((d, i) => ({
        t: t0 + step * i,
        value: d.close,
        label: d.date.slice(5).replace('-', '/'),
      }))
    }
    sub = '近5日收盘'
  }

  const lastUp = sparkPoints.length > 1
    ? (sparkPoints[sparkPoints.length - 1].value >= (baseline ?? sparkPoints[0].value))
    : null

  return React.createElement(
    'div',
    {
      ref: popRef,
      className: 'tw-pop tw-glass',
      'data-open': 'true',
      style: { left: 0, top: 0, visibility: 'hidden' },
      title: '点击查看详情（可切分时/五日/日K/周K/月K/年K）',
      role: 'button',
      onClick: onOpen,
      onMouseEnter: onEnter,
      onMouseLeave: onLeave,
    },
    React.createElement('div', { className: 'ph' },
      React.createElement('span', { className: 'nm' }, hover.name),
      React.createElement('span', { className: 'px ' + dir }, fmtPrice(price)),
      React.createElement('span', { className: 'tag ' + dir },
        `${fmtSigned(quote?.chg ?? null)}  ${fmtPct(quote?.pct ?? null)}`,
      ),
    ),
    kind === 'loading'
      ? React.createElement('div', { className: 'tw-loading', style: { height: 150 } }, '加载分时…')
      : kind === 'error'
        ? React.createElement('div', { className: 'tw-error', style: { height: 150 } }, '走势获取失败')
        : kind === 'none'
          ? React.createElement('div', { className: 'tw-loading', style: { height: 150 } }, '暂无当日走势数据')
          : React.createElement(Sparkline, {
              points: sparkPoints,
              baseline,
              width: 306,
              height: 150,
              up: lastUp !== false,
              upColor,
              downColor,
              timeLabels: true,
            }),
    React.createElement('div', { className: 'pl' },
      kind === 'trend' || kind === 'kline' ? React.createElement('span', null, sub) : null,
      quote?.time !== null && quote?.time !== undefined && quote.time > 0
        ? React.createElement('span', null, `行情 ${fmtClock(quote.time)}`)
        : null,
      quote?.amount !== null && quote?.amount !== undefined && quote.amount > 0
        ? React.createElement('span', null, `成交 ${(quote.amount / 1e8).toFixed(0)}亿`)
        : null,
      React.createElement('span', { className: 'tw-pop-hint' }, '点击查看详情'),
    ),
  )
}

export function TopBar(props: {
  quotes: Record<string, QuoteRow>
  /** 三个源都没有可用价格的标的（大写键） */
  missing?: Set<string>
  /** 请求被 160 项上限截断 */
  truncated?: boolean
  /** 数据被真实观测到的时刻（不是响应时刻） */
  asOf: number | null
  /** 至少一行是兜底/过期值 */
  stale: boolean
  /** 不新鲜行数 */
  staleCount: number
  /** 按来源计数（em/tencent/sina/lkg） */
  sources: Record<string, number>
  /** 整批是否休市定稿（P0-2 第三态） */
  cached?: boolean
  refreshing: boolean
  onRefresh: () => void
  prefs: PortPrefs
  setPrefs: (p: Partial<PortPrefs>) => void
  /** 点击行情卡片 → 打开详情抽屉（可切 分时/五日/日K/周K/月K/年K） */
  onOpenDetail?: (secid: string, name: string) => void
  /** 详情抽屉已打开时不再弹悬浮卡（否则遮住抽屉且与点击语义冲突） */
  popupDisabled?: boolean
  /** 当前视图模式（v0.91.1：它以前只在快捷键里，现在行情条上有可见控件） */
  viewMode: 'full' | 'compact' | 'incognito'
  /** 切换视图模式（与 Alt+M 共用 index.tsx 里的**同一个**实现） */
  onCycleViewMode: () => void
}): React.ReactElement {
  const { quotes, missing, truncated, asOf, stale, staleCount, sources, cached, refreshing, onRefresh, prefs, setPrefs } = props
  // 新鲜度必须随墙上时钟重算（否则一张卡会永远停在"实时"直到下一次取数）
  const now = useNow(Math.max(5, prefs.refreshSec) * 1000)
  const onOpenDetail = props.onOpenDetail
  const popupDisabled = props.popupDisabled === true
  const [hover, setHover] = useState<HoverState | null>(null)
  const hostRef = useRef<HTMLDivElement | null>(null)
  const popRef = useRef<HTMLDivElement | null>(null)
  const cursor = useRef({ x: 0, y: 0 })

  /**
   * 定位悬浮卡：以 TopBar 为定位上下文（absolute），跟随鼠标，必要时左右/
   * 上下翻转，并夹紧到"真实裁剪区"——视口与所有 overflow 祖先矩形的交集。
   * 这样无论面板是否带 transform（会把 position:fixed 的包含块改成面板，
   * 导致视口坐标失效）都能正确显示，不会被右缘裁掉。
   */
  const applyPos = useCallback((): void => {
    const el = popRef.current
    const host = hostRef.current
    if (el === null || host === null) return
    const hr = host.getBoundingClientRect()
    const W = 330
    const H = Math.max(el.offsetHeight, 240)
    // 裁剪区 = 视口 ∩ 所有 overflow 祖先
    let cl = 0
    let ct = 0
    let cr = window.innerWidth
    let cb = window.innerHeight
    for (let n: HTMLElement | null = host.parentElement; n !== null; n = n.parentElement) {
      const st = window.getComputedStyle(n)
      const ov = `${st.overflow}${st.overflowX}${st.overflowY}`
      if (/(auto|scroll|hidden|clip)/.test(ov)) {
        const r = n.getBoundingClientRect()
        if (r.width > 0 && r.height > 0) {
          cl = Math.max(cl, r.left)
          ct = Math.max(ct, r.top)
          cr = Math.min(cr, r.right)
          cb = Math.min(cb, r.bottom)
        }
      }
    }
    const x = cursor.current.x
    const y = cursor.current.y
    let left = x + 14
    if (left + W + 8 > cr) left = x - W - 12
    left = Math.min(Math.max(cl + 8, left), Math.max(cl + 8, cr - W - 8))
    let top = y + 18
    if (top + H + 8 > cb) top = y - H - 12
    top = Math.min(Math.max(ct + 8, top), Math.max(ct + 8, cb - H - 8))
    el.style.left = `${left - hr.left}px`
    el.style.top = `${top - hr.top}px`
    el.style.visibility = 'visible'
  }, [])

  // 内容尺寸变化（加载→图表）后重新夹紧
  useEffect(() => {
    if (hover === null) return
    const el = popRef.current
    if (el === null || typeof ResizeObserver === 'undefined') return
    const ro = new ResizeObserver(() => applyPos())
    ro.observe(el)
    return () => ro.disconnect()
  }, [hover, applyPos])

  // 打开延迟 120ms / 关闭宽限 100ms：鼠标扫过时不闪烁
  const openTimer = useRef<number | null>(null)
  const closeTimer = useRef<number | null>(null)
  const pending = useRef<HoverState | null>(null)
  const clearOpen = (): void => {
    if (openTimer.current !== null) {
      window.clearTimeout(openTimer.current)
      openTimer.current = null
    }
  }
  const clearClose = (): void => {
    if (closeTimer.current !== null) {
      window.clearTimeout(closeTimer.current)
      closeTimer.current = null
    }
  }

  const hide = useCallback((): void => {
    clearOpen()
    clearClose()
    setHover(null)
  }, [])

  // 详情抽屉打开时收起悬浮卡
  useEffect(() => {
    if (popupDisabled) hide()
  }, [popupDisabled, hide])

  // 卡片点击 = 打开详情。按下→抬起的位移超过 6px 视为横向拖动滚动条，不触发。
  const downAt = useRef<{ x: number; y: number } | null>(null)
  const openDetail = (secid: string, name: string): void => {
    if (onOpenDetail === undefined) return
    hide()
    onOpenDetail(secid, name)
  }
  const clickCard = (e: React.MouseEvent, secid: string, name: string): void => {
    const d = downAt.current
    downAt.current = null
    if (d !== null && (Math.abs(e.clientX - d.x) > 6 || Math.abs(e.clientY - d.y) > 6)) return
    openDetail(secid, name)
  }

  const scheduleOpen = (secid: string, name: string): void => {
    pending.current = { secid, name }
    if (hover !== null && hover.secid === secid) return
    if (openTimer.current !== null) return
    openTimer.current = window.setTimeout(() => {
      openTimer.current = null
      const p = pending.current
      if (p !== null) setHover(p)
    }, 120)
  }

  const scheduleClose = (): void => {
    clearOpen()
    if (closeTimer.current !== null) return
    closeTimer.current = window.setTimeout(() => {
      closeTimer.current = null
      setHover(null)
    }, 100)
  }

  const enterCard = (e: React.MouseEvent, secid: string, name: string): void => {
    cursor.current = { x: e.clientX, y: e.clientY }
    clearClose()
    scheduleOpen(secid, name)
  }

  const moveCard = (e: React.MouseEvent, secid: string, name: string): void => {
    cursor.current = { x: e.clientX, y: e.clientY }
    clearClose()
    if (hover !== null && hover.secid === secid) applyPos()
    else scheduleOpen(secid, name)
  }

  const focusCard = (e: React.FocusEvent, secid: string, name: string): void => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect()
    cursor.current = { x: r.left + r.width / 2, y: r.bottom }
    clearOpen()
    clearClose()
    setHover({ secid, name })
  }

  useEffect(() => {
    window.addEventListener('resize', hide)
    document.addEventListener('scroll', hide, true)
    return () => {
      window.removeEventListener('resize', hide)
      document.removeEventListener('scroll', hide, true)
      clearOpen()
      clearClose()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hide])

  // 打开后等 DOM 就绪再定位
  useEffect(() => {
    if (hover === null) return
    const raf = requestAnimationFrame(applyPos)
    return () => cancelAnimationFrame(raf)
  }, [hover, applyPos])

  // 逐卡四态（一次算好，供列表头汇总与卡片色点共用同一结果）
  const stateOf = (secid: string): QuoteState => quoteStateOf({
    row: quotes[secid],
    isMissing: missing?.has(secid.toUpperCase()) === true,
    cached: cached === true,
    refreshSec: prefs.refreshSec,
    now,
  })
  const summary = summarizeQuoteStates(
    TW_ROWS.flatMap((row) => (row.items as ReadonlyArray<{ secid: string }>).map((it) => stateOf(it.secid))),
  )

 // 当前值（缺省 1 / false，与宿主默认一致）
  const opacity = normalizePanelOpacity(prefs.panelOpacity, 1)
  const blurDigits = prefs.blurDigits === true
  const trendArchive = prefs.trendArchive !== false // 默认开：只有显式 false 才是关

  const themeBtn = (): void => {
    const next = prefs.theme === 'auto' ? 'light' : prefs.theme === 'light' ? 'dark' : 'auto'
    setPrefs({ theme: next as PortPrefs['theme'] })
  }

 // 截图/录屏设置（不透明度 + 数字模糊）
  /** 生效卡片（存隐藏集合：老 profile 缺键 ⇒ 全可见；整组全隐藏 ⇒ 不渲染空组头） */
  const stripRows = visibleCards(TW_ROWS, prefs.stripCfg?.hidden)
  const stripIds = stripRows.flatMap((r) => r.items.map((i) => i.secid))
  const stripKey = stripIds.join(',')
  useEffect(() => {
    if (stripKey === '') return
    let alive = true
    void api
      .tones(stripIds)
      .then((r) => {
        if (!alive) return
        const map: Record<string, ToneRow> = {}
        for (const row of r.rows) map[row.secid] = row as ToneRow
        setTones(map)
      })
      .catch(() => {
        /* 五档是增益信息：取不到就不显示 badge（绝不猜测），不打断行情 */
      })
    return () => {
      alive = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stripKey])

  const [shotOpen, setShotOpen] = useState(false)
  /** 配置窗开关（组件内 state，不上提、不落 prefs） */
  const [cfgOpen, setCfgOpen] = useState(false)
  /** 五档状态：**后到**（首屏先出卡片，badge 不拖慢行情） */
  const [tones, setTones] = useState<Record<string, ToneRow>>({})
  const gearRef = useRef<HTMLButtonElement | null>(null)
  const shotModal = shotOpen
    ? React.createElement(Modal, { title: '截图 / 录屏（面板不透明度与数字模糊）', onClose: () => setShotOpen(false) },
        React.createElement('div', { className: 'tw-hint', style: { marginBottom: 8 } },
          '这两项只影响「本插件面板的显示」：取数、告警、agent 工具返回都不受影响。' +
          '面板不透明度让面板不抢画面（录屏时压在下层内容之上）；数字模糊把价格/盈亏/成交额等数字糊住，' +
          '鼠标移到某一行或某张卡上时该行临时显形 —— 既能录进画面，又不泄露具体数值。',
        ),
        React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 10, margin: '6px 0' } },
          React.createElement('span', { style: { minWidth: 84, fontSize: 12 } }, '面板不透明度'),
          React.createElement('input', {
            type: 'range',
            min: Math.round(PANEL_OPACITY_MIN * 100),
            max: Math.round(PANEL_OPACITY_MAX * 100),
            step: 5,
            value: Math.round(opacity * 100),
            style: { flex: 1, border: 'none', padding: 0, background: 'none' },
            onChange: (e: React.ChangeEvent<HTMLInputElement>) => setPrefs({ panelOpacity: normalizePanelOpacity(Number(e.target.value) / 100) }),
          }),
          React.createElement('span', { style: { fontFamily: 'var(--tw-mono)', minWidth: 44, textAlign: 'right' } }, `${Math.round(opacity * 100)}%`),
        ),
        React.createElement('label', { style: { display: 'flex', alignItems: 'center', gap: 8, margin: '8px 0', fontSize: 12, cursor: 'pointer' } },
          React.createElement('input', {
            type: 'checkbox',
            checked: blurDigits,
            onChange: (e: React.ChangeEvent<HTMLInputElement>) => setPrefs({ blurDigits: e.target.checked }),
          }),
          '数字模糊（价格/涨跌/盈亏/成交额；hover 该行显形）',
        ),
        React.createElement('label', {
          style: { display: 'flex', alignItems: 'center', gap: 8, margin: '8px 0', fontSize: 12, cursor: 'pointer' },
          title: '把每天成功取到的分时按日归档（trends/<secid>/<日期>.json，保留最近 12 个交易日，单日/总量超限就不写）。' +
            '这是"五日"在没有真实多日源的市场（港股/国际指数/外盘商品/期货）能拼出多日的唯一途径：从本版起累积，今天只有 1 天。',
        },
          React.createElement('input', {
            type: 'checkbox',
            checked: trendArchive,
            onChange: (e: React.ChangeEvent<HTMLInputElement>) => setPrefs({ trendArchive: e.target.checked }),
          }),
          '归档每日分时（供"五日"本地拼接，从本版起累积）',
        ),
        React.createElement('div', { className: 'tw-hint' },
          '隐蔽性说明：数字模糊只覆盖「本插件渲染的数字」。表格里的名称、代码与提示文字不在模糊范围内（它们不是数字）；' +
          '若需要整屏不可读，请配合隐身视图（Alt+M）使用 —— 隐身会把金额替换为 ¥••••。',
        ),
        React.createElement('div', { style: { display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 10 } },
          React.createElement(Btn, {
            onClick: () => setPrefs({ panelOpacity: 1, blurDigits: false }),
          }, '恢复默认'),
          React.createElement(Btn, { primary: true, onClick: () => setShotOpen(false) }, '完成'),
        ),
      )
    : null

  return React.createElement(
    'div',
    { ref: hostRef, className: 'tw-topbar' },
    React.createElement('div', { className: 'tw-topmeta' },
      React.createElement('span', { className: 'tw-title', title: `dsh-tradewatcher v${__TW_VERSION__}` }, '实时行情'),
      React.createElement('span', { className: 'tw-uptime' },
        // 显示**数据时刻**而非响应时刻：上游全挂、整屏 read 旧值时，此前仍会显示
        // "更新 14:32:05"（那是响应生成时间），用户误以为刚拿到最新价
        asOf !== null ? `数据 ${fmtClock(asOf)} · 每 ${prefs.refreshSec}s` : '加载中…',
      ),
      // P0-2：四态汇总。数字必须**加得上**（live+delayed+settled+missing == total），
      // 因此这里用与逐卡完全相同的判定函数，而不是另算一套"滞后"。
      summary.total > 0
        ? React.createElement('span', {
            className: 'tw-badge',
            title:
              `本批 ${summary.total} 张卡片：实时 ${summary.live} · 延迟 ${summary.delayed} · 定稿复用 ${summary.settled} · 缺失 ${summary.missing}\n` +
              `最近一次成功行情 ${asOf === null ? '—' : fmtClock(asOf)}；来源明细：` +
              Object.entries(sources).map(([k, n]) => `${k} ${n}`).join(' / '),
            style: { fontSize: 12, color: stale && staleCount > 0 ? '#e0a94a' : undefined },
          }, `${summary.live}/${summary.total} 实时${summary.delayed > 0 ? ` · ${summary.delayed} 延迟` : ''}${summary.settled > 0 ? ` · ${summary.settled} 定稿` : ''}${summary.missing > 0 ? ` · ${summary.missing} 缺失` : ''}`)
        : null,
      // 无任何源可用的标的数：不能与"本轮还没数据"混为一谈
      (() => {
        const n = missing?.size ?? 0
        if (n === 0) return null
        return React.createElement('span', {
          className: 'tw-badge',
          title: `其中 ${n} 个${NO_SOURCE_LABEL}；这些卡片显示 —，明细见自选或持仓页\n${NO_SOURCE_TITLE}`,
          style: { fontSize: 12, color: '#e0a94a' },
        }, `无行情源 ${n}`)
      })(),
      truncated === true
        ? React.createElement('span', { className: 'tw-badge', title: '一次最多请求 160 个标的，超出部分未请求；必须减少自选数量，或分页查看', style: { fontSize: 12, color: '#e0a94a' } }, '已截断 160')
        : null,
      // 东财行情不可用时部分标的走腾讯/新浪备用源：如实标注，避免误以为是东财数据
      (() => {
        const alt = (sources.tencent ?? 0) + (sources.sina ?? 0)
        if (alt === 0) return null
        return React.createElement('span', {
          className: 'tw-badge',
          title: `其中 ${alt} 个标的来自备用源（腾讯 ${sources.tencent ?? 0} / 新浪 ${sources.sina ?? 0}）；` +
            '美股/国际指数/商品部分标的无备用源映射，仍显示最近一次成功数据',
          style: { fontSize: 12 },
        }, `备用源 ${alt}`)
      })(),
      // 视图模式：**可见控件**（以前只有 Alt+M 快捷键 ⇒ 用户找不到隐身视图）。
      // 文案 = 当前档位；鼠标与键盘两条路都写进悬停。
      React.createElement('button', {
        className: 'tw-iconbtn',
        onClick: props.onCycleViewMode,
        title: `视图：${{ full: '完整', compact: '紧凑', incognito: '隐身' }[props.viewMode]}（点击切换，快捷键 Alt+M）`,
        'aria-label': `切换视图模式（当前 ${{ full: '完整', compact: '紧凑', incognito: '隐身' }[props.viewMode]}，快捷键 Alt+M）`,
      }, `视图·${{ full: '完整', compact: '紧凑', incognito: '隐身' }[props.viewMode]}`),
      React.createElement('button', {
        ref: gearRef,
        className: 'tw-iconbtn',
        onClick: () => setCfgOpen((v) => !v),
        'aria-expanded': cfgOpen,
        'aria-haspopup': 'dialog',
        title: '配置实时行情卡片（Esc 关闭）',
        'aria-label': '行情卡片配置',
      }, '⚙'),
      React.createElement('button', {
        className: 'tw-iconbtn',
        onClick: () => setShotOpen(true),
        title: `截图/录屏：面板不透明度 ${Math.round(opacity * 100)}% · 数字模糊${blurDigits ? '已开' : '关'}`,
        'aria-label': '截图与录屏设置',
      }, '▣'),
      React.createElement('button', {
        className: 'tw-iconbtn',
        onClick: themeBtn,
        title: `主题：${prefs.theme === 'auto' ? '自动' : prefs.theme === 'light' ? '浅色' : '深色'}（点击切换）`,
        'aria-label': '切换主题',
      }, prefs.theme === 'auto' ? '◐' : prefs.theme === 'light' ? '☀' : '☾'),
      React.createElement('button', {
        className: 'tw-iconbtn',
        onClick: onRefresh,
        disabled: refreshing,
        title: refreshing ? '刷新中…' : '手动刷新行情',
        'aria-label': '刷新行情',
      }, '⟳'),
    ),
    stripRows.map(({ row, items }) =>
      React.createElement(
        'div',
        { key: row.key, className: 'tw-strip' },
        React.createElement('div', { className: 'tw-strip-label' }, row.label),
        React.createElement(
          'div',
          { className: 'tw-strip-cards', onMouseLeave: scheduleClose },
          items.map((it) => {
            const kind = stripKindOf(it.secid)
            const isYield = kind === 'yield'
            const tone = toneBadgeView(tones[it.secid])
            const q = quotes[it.secid]
            const price = q?.price ?? null
            const cls = dirClass(q?.chg ?? null, prefs.redUp)
            const pctText = q?.pct ?? null
            const st = stateOf(it.secid)
            /** 收益率：副值 ±bp（必带符号）；**不套红绿**（上行 ≠ 债券走强） */
            const bpText = q?.chg === null || q?.chg === undefined ? '—' : `${q.chg * 100 >= 0 ? '+' : ''}${(q.chg * 100).toFixed(1)}bp`
            return React.createElement(
              'div',
              {
                key: it.secid,
                className: 'tw-qcard',
                'data-state': st,
                // 有 badge 时才让位（.tw-qcard[data-tone] .nm 的内边距规则据此生效）
                'data-tone': tone.text === null ? undefined : tone.dataTone,
                tabIndex: 0,
                role: 'button',
                title: `${QUOTE_STATE_LABEL[st]} · ${it.name}：点击打开详情（分时/五日/日K/周K/月K/年K）\n${quoteStateTitle(st, q, prefs.refreshSec)}`,
                'aria-label': `${it.name} 实时行情，点击打开详情`,
                onMouseEnter: (e: React.MouseEvent) => enterCard(e, it.secid, it.name),
                onMouseMove: (e: React.MouseEvent) => moveCard(e, it.secid, it.name),
                onMouseDown: (e: React.MouseEvent) => {
                  downAt.current = { x: e.clientX, y: e.clientY }
                },
                onClick: (e: React.MouseEvent) => clickCard(e, it.secid, it.name),
                onKeyDown: (e: React.KeyboardEvent) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault()
                    openDetail(it.secid, it.name)
                  }
                },
                onFocus: (e: React.FocusEvent) => focusCard(e, it.secid, it.name),
                onBlur: scheduleClose,
              },
              React.createElement('span', {
                className: 'tw-qdot',
                style: { background: QUOTE_STATE_COLOR[st] },
                'aria-label': QUOTE_STATE_LABEL[st],
              }),
              // badge 在**卡片右上角**（绝对定位，不占布局、不改卡片尺寸）；口径长句已并入卡片 title/aria
              tone.text === null
                ? null
                : React.createElement('span', {
                    className: 'tw-tone', 'data-tone': tone.dataTone, 'aria-hidden': true, title: tone.detail,
                  }, tone.text),
              React.createElement('div', { className: 'nm' }, it.name,
                React.createElement('span', { className: 'tw-kind', title: isYield ? '收益率（上行＝债券价格下跌）' : '价格型（指数/ETF）' }, isYield ? '率' : '价')),
              React.createElement('div', { className: 'px ' + (price === null ? 'tw-flat' : isYield ? 'tw-flat' : cls) },
                isYield && price !== null ? `${price.toFixed(2)}%` : fmtPrice(price)),
              React.createElement('div', { className: 'chg' },
                isYield
                  ? React.createElement('span', { className: 'tw-flat', title: '收益率变动（bp）：上行＝债券价格下跌' }, bpText)
                  : React.createElement('span', { className: 'chg ' + (q?.chg === null ? 'tw-flat' : cls) }, fmtSigned(q?.chg ?? null)),
                isYield
                  ? null
                  : React.createElement('span', { className: `tw-chg-chip ${pctText === null ? 'tw-chip-flat' : pctText >= 0 ? (prefs.redUp ? 'tw-chip-up' : 'tw-chip-down') : (prefs.redUp ? 'tw-chip-down' : 'tw-chip-up')}` },
                      fmtPct(pctText),
                    ),
              ),
            )
          }),
        ),
      ),
    ),
    shotModal,
    cfgOpen
      ? React.createElement(StripConfig, {
          rows: TW_ROWS as unknown as Parameters<typeof StripConfig>[0]['rows'],
          hidden: prefs.stripCfg?.hidden,
          onChange: (next: string[]) => setPrefs({ stripCfg: { hidden: next } }),
          onClose: () => {
            setCfgOpen(false)
            // Esc/× 关闭后把焦点还给齿轮（键盘用户不会掉到文档开头）
            gearRef.current?.focus()
          },
        })
      : null,
    // 配置窗打开时不显示悬浮卡（`.tw-pop` 的 z-index 9999 会盖住窗口）
    hover !== null && !popupDisabled && !cfgOpen
      ? React.createElement(HoverCard, {
          hover,
          quote: quotes[hover.secid],
          prefs,
          popRef,
          onSized: applyPos,
          onOpen: () => openDetail(hover.secid, hover.name),
          onEnter: clearClose,
          onLeave: scheduleClose,
        })
      : null,
  )
}
