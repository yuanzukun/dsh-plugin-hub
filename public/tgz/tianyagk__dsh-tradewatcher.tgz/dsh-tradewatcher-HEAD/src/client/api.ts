// 筹码分布：与宿主 `chips.ts` 同形（客户端只消费）
export interface ChipDayDto {
  date: string
  buckets: number[]
  centers: number[]
  avgCost: number | null
  support: number | null
  resistance: number | null
  narrow: boolean
  /**
   * 该展示日的**盈亏边界价**（与 `profitRatio` 同源：最新日=现价、历史日=当日收盘价）。
   *
   * ⚠ **可选**：老宿主不带这个字段 ⇒ 客户端按 `chipsDayPriceOf` **如实回退**到顶层 `priceUsed`
   * 并留下原因（不静默）。
   */
  price?: number | null
  profitRatio: number | null
  samples: number
}
export interface ChipsPayload {
  secid: string
  asOf: number | null
  stale: boolean
  source: string
  days: ChipDayDto[]
  latest: ChipDayDto | null
  /** 累积窗口（递推用了几根日线） */
  window: number
  /** 展示窗口（滑杆覆盖的天数） */
  displayWindow: number
  bucketCount: number
  decay: 'turnover' | 'half-life'
  decayReason: string | null
  avgCost: number | null
  support: number | null
  resistance: number | null
  narrow: boolean
  profitRatio: number | null
  samples: number
  methodology: string
  why: string | null
  /** 盈利比例用到的现价（已换算到前复权空间）；null ⇒ 界面显示"未取到" */
  priceUsed: number | null
  priceSource: 'quote' | 'close' | null
  fqt: 1
  priceScale: number
  latestBarDate: string | null
  barAlignsWithDisplay: boolean
  disclaimer: string
  missing: Array<{ what: string; why: string; note: string }>
}

// 做T 视图：与宿主 `dayTrade.ts` 的返回同形（客户端只消费，不重算）
export interface DayTradeView {
  rounds: Array<{
    day: string
    direction: 'buy-first' | 'sell-first'
    qty: number
    buyPrice: number
    sellPrice: number
    grossPnl: number
    feeShare: number
    netPnl: number
  }>
  unmatched: Array<{ day: string; verb: string; qty: number; price: number | null; note: string }>
  summary: { count: number; winRate: number | null; netPnl: number; avgNet: number | null; days: number }
  methodology: string
}

// 全球五市场（工具箱 → 工具①「全球资金流蛋糕模型」）：与宿主 `globalFlow.ts` 同形（客户端只消费，不重算份额）
export interface GlobalFlowMarketDto {
  /** 成分 v2（A股、港股、美国、日本、韩国）—— 顺序即展示顺序 */
  key: 'cn' | 'hk' | 'us' | 'jp' | 'kr'
  name: string
  etf: string
  aumSource: string
  currency: 'USD' | 'CNY' | 'HKD'
  benchmark: string
  benchmarkSource: string
  aumNative: number | null
  aumUsd: number | null
  sharePct: number | null
  delta1Pp: number | null
  delta5Pp: number | null
  momentum: { d20: number | null; d60: number | null; d120: number | null } | null
  rank: number | null
  /** 该行缺什么 + 原因（null = 全齐）；页面必须原样显示，不许用 0 顶替 */
  missing: string | null
}

export interface GlobalFlowPointDto {
  day: string
  origin: 'observed' | 'rebuilt'
  aumUsd: Array<number | null>
  share: Array<number | null>
  partial: boolean
}

export interface GlobalFlowPayloadDto {
  asOf: number
  day: string
  /** live = 上游现取；snapshot = 本次只读本地快照（零上游请求）；fallback = 上游全失败、退化为最近一次快照 */
  source: 'live' | 'snapshot' | 'fallback'
  fallbackDay: string | null
  fx: { usdCny: number | null; usdHkd: number | null; at: number | null; source: string; note: string | null }
  markets: GlobalFlowMarketDto[]
  totalUsd: number | null
  totalNote: string | null
  rotation: { kind: 'rotation' | 'flat' | 'unknown'; fromKey: string | null; toKey: string | null; maxAbsPp: number | null; comparable: number; window: number; text: string }
  curve: { points: GlobalFlowPointDto[]; window: number; observedDays: number; rebuiltDays: number; note: string }
  replay: { days: string[]; max: number; note: string }
  netFlow: { code: string; label: string; days: number; sumCny: number | null; asOf: number | null; series: Array<{ day: string; netCny: number }>; basis: string; miss: string | null }
  snapshot: {
    path: string
    days: number
    bytes: number | null
    firstDay: string | null
    lastDay: string | null
    /** 因口径不一致而作废的旧快照（留痕；成分变更后非空） */
    purged: Array<{ day: string; scope: string | null; reason: string }>
  }
  notes: { kpi: string; curve: string; pie: string; market: string; boundary: string }
  boundary: string[]
  missing: Array<{ what: string; why: 'no-source' | 'transient'; note: string }>
}

import type { ToneRow as ToneRowDto } from './stripTone.ts'
/** Same-origin JSON calls to the /tradewatcher/* host routes. */
import type {
  BoardRow,
  CorporateAction,
  FqMode,
  KlineData,
  MissingField,
  MutatePortBody,
  MutateWatchBody,
  PortPrefs,
  PortfolioView,
  QuoteRow,
  RescueDaySummary,
  RescueIntradayPoint,
  RescueSignalEvent,
  RescueSnapshot,
  QuoteSource,
  StockDetail,
  SuggestItem,
  TrendData,
  WatchData,
  LedgerView,
  TradeMark,
  CalEvent,
  YtdPayload,
} from '../shared/model.ts'

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.status = status
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response
  try {
    res = await fetch(path, {
      ...init,
      headers: { 'content-type': 'application/json', ...(init?.headers ?? {}) },
      cache: 'no-store',
    })
  } catch (error) {
    throw new ApiError(`网络错误: ${error instanceof Error ? error.message : String(error)}`, 0)
  }
  let payload: { error?: string } & T
  try {
    payload = (await res.json()) as { error?: string } & T
  } catch {
    throw new ApiError(`响应解析失败 (HTTP ${res.status})`, res.status)
  }
  if (!res.ok || payload.error !== undefined) {
    throw new ApiError(payload.error ?? `HTTP ${res.status}`, res.status)
  }
  return payload
}

export const api = {
  /**
   * 全球五市场（工具箱 → 全球资金流蛋糕模型）。
   * `source='snapshot'` = 只读宿主本地快照（一天一条、保留 90 天），**宿主不会发上游请求**
   * —— 30 日手动回放走这条；默认 `auto` 走宿主的现取模式（三层 TTL + 在飞合并）。
   */
  globalFlow(source: 'auto' | 'snapshot' = 'auto'): Promise<GlobalFlowPayloadDto> {
    return request(`/tradewatcher/tools/global-flow${source === 'snapshot' ? '?source=snapshot' : ''}`)
  },
  /** 导出备份（P0-9）：GET /tradewatcher/backup */
  exportBackup(): Promise<{ ok: boolean; bundle: unknown; unreadable: string[] }> {
    return request('/tradewatcher/backup')
  },
  /** 导入备份（P0-9）：mode=preview 只校验，apply 才覆盖（覆盖前宿主写 .bak） */
  importBackup(mode: 'preview' | 'apply', bundle: unknown): Promise<{
    ok: boolean
    mode: string
    errors: string[]
    summary: Record<string, unknown>
    conflicts: string[]
    backedUp?: string[]
  }> {
    return request('/tradewatcher/backup', { method: 'POST', body: JSON.stringify({ mode, bundle }) })
  },
  /** 涨跌家数 + 历史分位（P1-8） */
  /**
   * 涨跌家数 + 历史分位（P1-8）。
   *
   * `dist: true` 会额外要一份【涨跌分布】直方图：那要多扫 ~56 页全市场涨跌幅，
   * 所以**默认不要**（其它调用方/工具保持原样、不付这个成本）。
   */
  breadth(opts: { dist?: boolean } = {}): Promise<{
    current: {
      up: number
      down: number
      even: number
      amount: number
      ratio: number | null
      /** 数字时刻：源 A = 行情时刻；自统计 = **统计完成时刻**（语义不同，界面要分别标） */
      asOf: number | null
      /** `em-index` = 上游直接给的；`em-clist` / `page-scan` = 本插件自行统计 */
      source: string
      /** 自统计时给出的统计口径（含哪些板块、平盘怎么界定）；源 A 为 null */
      caliber?: string | null
      /** 自统计的顺序不变量自检结论（排查用） */
      checks?: string[]
    } | null
    percentile: { metric: string; value: number | null; n: number; pct: number | null; sampleSmall: boolean; samples: number[] }
    window: number
    minDays: number
    storedDays: number
    storedThisCall: boolean
    /**
     * 昨日两市成交额（本地 `breadth.json` 的上一交易日快照）。没有那份快照 ⇒ `null`
     * —— 界面按"未取到 + 原因"显示，**不许**用今天的数顶替。
     */
    prevAmount: { day: string; amount: number; final: boolean } | null
    /** 只有 `dist: true` 时才出现；`counts: null` = 没扫全（原因在同项/`missing` 里），不给部分分布 */
    distribution?: {
      labels: string[]
      counts: number[] | null
      blank: number
      scanned: number
      total: number | null
      asOf: number
      reason: string | null
    }
    missing: Array<{ what: string; why: string; note: string }>
  }> {
    return request(opts.dist === true ? '/tradewatcher/breadth?dist=1' : '/tradewatcher/breadth')
  },
  /**
   * 年初至今（YTD）。口径写死在 `shared/model.ts` 的 `YTD_CALIBER`：
   * YTD =（现价 − 本年内第一个交易日收盘价）÷ 该收盘价 × 100%，前复权序列。
   * 缺失项在 `rows[].why` 与 `missing[]` 里都给出原因（不用 0 顶替）。
   */
  /** 五档状态 badge（宿主按日 memo；取不到/样本不足时 rows 里 level=null + why） */
  tones(secids: string[]): Promise<{ asOf: number | null; stale: boolean; source: string; day?: string; rows: ToneRowDto[]; missing: Array<{ what: string; why: string; note: string }>; requested: number; truncated: boolean; limit: number }> {
    const ids = [...new Set(secids)].join(',')
    if (ids === '') {
      return Promise.resolve({ asOf: null, stale: false, source: 'none', rows: [], missing: [], requested: 0, truncated: false, limit: 0 })
    }
    return request(`/tradewatcher/tones?ids=${encodeURIComponent(ids)}`)
  },
  ytd(secids: string[]): Promise<YtdPayload> {
    const ids = [...new Set(secids)].join(',')
    if (ids === '') {
      return Promise.resolve({ asOf: null, stale: false, source: 'none', rows: [], missing: [], requested: 0, truncated: false, limit: 0 })
    }
    return request(`/tradewatcher/ytd?ids=${encodeURIComponent(ids)}`)
  },
  /** 自选异动（P1-4）：放量/异动判定，含"为什么不判定"的原因 */  anomaly(secids: string[]): Promise<{
    rows: Array<{
      secid: string
      name: string
      kind: 'volume' | 'price' | 'both' | null
      mult: number | null
      samples: number
      pct: number | null
      reasons: string[]
      skip: string[]
    }>
    asOf: number
    missing: Array<{ what: string; why: 'no-source' | 'transient'; note: string }>
    source?: string
    stale?: boolean
  }> {
    const ids = [...new Set(secids)].join(',')
    if (ids === '') return Promise.resolve({ rows: [], asOf: Date.now(), missing: [] })
    return request(`/tradewatcher/anomaly?ids=${encodeURIComponent(ids)}`)
  },
  /** 侧栏徽标（P0-3）：与面板顶部同源的汇总数，不触发新采样 */
  badge(): Promise<{
    level: number
    levelLabel: string | null
    dayPnl: number
    dayPnlPct: number | null
    indexPoint: number | null
    indexPct: number | null
    indexName: string | null
    /** 非采样时段且原因是已收盘/周末 → 加后缀「收」 */
    settled: boolean
    asOf: number | null
    source: string
    missingCount: number
  }> {
    return request('/tradewatcher/badge')
  },
  quotes(secids: string[]): Promise<{
    /** 响应生成时刻（用于触发下游刷新），**不是**数据时刻 */
    ts: number
    items: Record<string, QuoteRow>
    /** 最新一次真实观测到行情的时间（epoch ms）；无有效行为 null */
    asOf: number | null
    /** 至少一行是兜底值/已过期（界面必须如实报警，而不是显示"刚刚更新"） */
    stale: boolean
    staleCount: number
    priced: number
    rows: number
    sources: Record<string, number>
    /** 请求了但没有任何源给出价格的标的（原样大小写）→ 界面显示「无行情源」 */
    missing: string[]
    /** 请求的标的数（含重复与超限项） */
    requested: number
    /** 是否因超过 160 项上限被截断 */
    truncated: boolean
    /** 休市定稿（非交易时段 + 无兜底行 + 有价）：卡片显示"定稿复用"灰点，未开盘不得显示绿色 */
    cached: boolean
  }> {
    const ids = [...new Set(secids)].join(',')
    if (ids === '') {
      return Promise.resolve({ ts: Date.now(), items: {}, asOf: null, stale: false, staleCount: 0, priced: 0, rows: 0, sources: {}, missing: [], requested: 0, truncated: false, cached: false })
    }
    return request(`/tradewatcher/quotes?ids=${encodeURIComponent(ids)}`)
  },
  /** `missing` 只在 `trend === null` 时给出：为什么没有（no-source / transient，见共享的 MissingField） */
  trend(secid: string, ndays = 1): Promise<{ trend: TrendData | null; missing?: MissingField[] }> {
    return request(`/tradewatcher/trend?secid=${encodeURIComponent(secid)}&ndays=${ndays}`)
  },
  /** fqt：0=不复权 1=前复权（默认）2=后复权；实际生效口径见回包 kline.fqt */
  kline(secid: string, klt: 101 | 102 | 103 | 104 = 101, lmt = 120, fqt: FqMode = 1): Promise<{ kline: KlineData | null; missing?: MissingField[] }> {
    return request(`/tradewatcher/kline?secid=${encodeURIComponent(secid)}&klt=${klt}&lmt=${lmt}&fqt=${fqt}`)
  },
  calendar(from: string, to: string, force = false): Promise<{
    events: CalEvent[]
    /** 最近一次**成功**同步时刻；从未成功过为 null（P0-2：失败时刻不改写数据时刻） */
    syncedAt: number | null
    /** 最近一次尝试时刻（不论成败） */
    syncAttemptAt: number | null
    /** 本次是否有源失败（含"从未成功同步"）→ 界面必须如实标注 */
    stale: boolean
    syncSources?: Array<{ key: string; label: string; state: 'ok' | 'failed' | 'skipped'; count: number; error?: string }>
    missing?: Array<{ what: string; why: string; note: string }>
    symbolCount: number
  }> {
    return request(`/tradewatcher/calendar?from=${from}&to=${to}${force ? '&force=1' : ''}`)
  },
  mutateCalendar(body: Record<string, unknown>): Promise<{
    ok: boolean
    events: CalEvent[]
    syncedAt: number | null
    syncAttemptAt: number | null
    stale: boolean
    syncSources?: Array<{ key: string; label: string; state: 'ok' | 'failed' | 'skipped'; count: number; error?: string }>
    missing?: Array<{ what: string; why: string; note: string }>
  }> {
    return request('/tradewatcher/calendar', { method: 'POST', body: JSON.stringify(body) })
  },
  trades(secid: string): Promise<{ trades: TradeMark[] }> {
    return request(`/tradewatcher/trades?secid=${encodeURIComponent(secid)}`)
  },
  industry(secid: string): Promise<{ industry: { name: string; pct: number | null } | null }> {
    return request(`/tradewatcher/industry?secid=${encodeURIComponent(secid)}`)
  },
  industries(secids: string[]): Promise<{ map: Record<string, { name: string; pct: number | null }> }> {
    const ids = [...new Set(secids)].join(',')
    if (ids === '') return Promise.resolve({ map: {} })
    return request(`/tradewatcher/industries?secids=${encodeURIComponent(ids)}`)
  },
  detail(secid: string): Promise<{ detail: StockDetail | null; missing?: MissingField[] }> {
    return request(`/tradewatcher/detail?secid=${encodeURIComponent(secid)}`)
  },
  suggest(q: string): Promise<{ hits: SuggestItem[] }> {
    return request(`/tradewatcher/suggest?q=${encodeURIComponent(q)}`)
  },
  board(scope: 'industry' | 'concept' | 'etf', sort: 'pct' | 'money' | 'amount', pn = 1): Promise<{
    total: number
    rows: BoardRow[]
    /** 上游不可用时回落上次成功结果 */
    stale?: boolean
    asOf?: number
    source?: QuoteSource
  }> {
    return request(`/tradewatcher/board?scope=${scope}&sort=${sort}&pn=${pn}&pz=40`)
  },
  rescue(force = false): Promise<{
    snapshot: RescueSnapshot
    history: RescueDaySummary[]
    calibration?: unknown
    breaker?: {
      open: boolean
      allOpen: boolean
      openHosts: number
      hosts: number
      minutesLeft: number
      allMinutesLeft: number
      lastError: string | null
      detail: Array<{ host: string; open: boolean; minutesLeft: number; trips: number; fails: number; lastError: string | null }>
    }
  }> {
    return request(`/tradewatcher/rescue${force ? '?force=1' : ''}`)
  },
  rescueDay(day: string): Promise<{ snapshot: RescueSnapshot; dayEvents: RescueSignalEvent[]; dayIntraday: RescueIntradayPoint[] }> {
    return request(`/tradewatcher/rescue?day=${encodeURIComponent(day)}`)
  },
  watch(): Promise<{ watch: WatchData }> {
    return request('/tradewatcher/watch')
  },
  mutateWatch(body: MutateWatchBody): Promise<{ watch: WatchData }> {
    return request('/tradewatcher/watch', { method: 'POST', body: JSON.stringify(body) })
  },
  /** 筹码分布（45 日 / 换手率衰减 / P5-P95）。宿主算好，界面只渲染 */
  chips(secid: string, days?: number): Promise<ChipsPayload> {
    const d = days === undefined ? '' : `&days=${Math.round(days)}`
    return request(`/tradewatcher/chips?secid=${encodeURIComponent(secid)}${d}`)
  },
  /** 活跃行清单（core 提供，永远可用）：tab gate 用；不可达时调用方**失败放行** */
  rows(): Promise<{ rows: string[]; asOf: number }> {
    return request('/tradewatcher/rows')
  },
  portfolio(): Promise<{
    view: PortfolioView
    stale: number
    /** 除权除息提示（P2-4），来自已同步的日历事件 */
    corporateActions?: CorporateAction[]
    /** 做T 同日往返配对（P1-3，宿主算好给界面用；与工具同一份实现） */
    dayTrades?: DayTradeView
  }> {
    return request('/tradewatcher/portfolio')
  },
  mutatePortfolio(body: MutatePortBody): Promise<{ view: PortfolioView; stale: number; corporateActions?: CorporateAction[]; dayTrades?: DayTradeView }> {
    return request('/tradewatcher/portfolio', { method: 'POST', body: JSON.stringify(body) })
  },
  ledger(groupId?: string, posId?: string, limit = 300): Promise<{ entries: LedgerView[] }> {
    const p = new URLSearchParams()
    if (groupId !== undefined) p.set('groupId', groupId)
    if (posId !== undefined) p.set('posId', posId)
    p.set('limit', String(limit))
    return request(`/tradewatcher/ledger?${p.toString()}`)
  },
  prefs(): Promise<{ prefs: PortPrefs }> {
    return request('/tradewatcher/prefs')
  },
  setPrefs(patch: Partial<PortPrefs>): Promise<{ prefs: PortPrefs }> {
    return request('/tradewatcher/prefs', { method: 'POST', body: JSON.stringify({ patch }) })
  },
}
