# Changelog

## 0.0.11 (2026-08-21)

- **适配 dsh 0.1.1-rc.2（最新版优先，放弃旧版兼容承诺）**：dsh 已升级至 0.1.1-rc.2（其全部子包 peer 声明为 `^0.1.1-rc.2`）。旧依赖区间 `>=0.1.0-rc.8 <2` 在 pnpm v11 下解析到**最低满足预发布版** `0.1.0-rc.8`，其 rc.8 时代 peer 子系统（`dsh-scope`/`dsh-invariants`/`dsh-agent`…）的 `^0.1.0-rc.8` 与新版主图 `^0.1.1-rc.2` 两类预发布 range 无法合并 → 全新安装 `dsh@0.1.1-rc.2 + dsh-migrate` 即报 `ERR_PNPM_NO_MATCHING_VERSION @deepseek-ai/dsh-*@>=0.1.1 <0.2.0-0`（实测矩阵：dsh 单独装 ✓ / dsh-migrate 单独装 ✓ / 合装 ✗ / override 强制 tools·home-paths=0.1.1-rc.2 后 ✓；pnpm 11.9 与 11.22 均复现）。已将 `@deepseek-ai/dsh-tools`、`@deepseek-ai/dsh-home-paths`、peer `@deepseek-ai/dsh-client-ui-slots` 全部收紧为 `^0.1.1-rc.2`，与新版 dsh 依赖基线对齐。
- 影响边界：仅影响**新装** dsh-migrate（或自携带后目标机安装）与新版 dsh 的搭配；已有安装（如 dsh 0.1.0-rc.7 主机）不受影响，但后续不再保证旧版 dsh 兼容。

## 0.0.10 (2026-08-21)

- **修复导出去重**：多个 profile 共享同一 vendor 包时，`scanHome` 会按 profile 逐个扫描，导致归档内 vendor 文件 / `links` / manifest 条目重复 N 倍（归档膨胀、导入警告与验证重复）。修复：`collectLinks` 按 `dep` 去重（同一依赖只记一条 link）+ 扫描结果按 `relPath` 去重（纵深防御，覆盖不同 dep 指向同一 vendor 目录的边角）。新增 `test/export-dedup.mjs` 回归（双 profile 共享 vendor：plan/manifest/归档均无重复、导入无重复警告）。

## 0.0.9 (2026-08-20)

- **自携带（体验修复）**：导出时自动把 dsh-migrate 自身附加进归档内 profile（`dependencies` 加 `dsh-migrate@^<版本>` + `dsh.profile.bundles` 追加），目标机导入后即自带迁移工具，无需手动安装——解决"迁移不带自己"（super-injector 运行时注入的工具不在 profile 依赖里，旧版不随迁移走）。幂等：profile 已显式依赖时不重复附加；dry-run 预览与导出报告会提示；源机文件只读不改。新增 `test/carry-self.mjs` 端到端回归。
- **修复 pnpm 全新安装 404（上游生态问题规避）**：依赖区间 `>=0.0.1-rc <2` 在 pnpm v11 下会解析到**最旧**预发布版（如 `@deepseek-ai/dsh-tools@0.0.1-rc.1`），其旧 peer 图（`@deepseek-ai/dsh-session@0.0.1-rc.1`）声明了从未发布的 peer `@deepseek-ai/dsh-type-meta` → 全新 `pnpm add dsh-migrate`（含自携带后的目标机安装）404。已将 `@deepseek-ai/dsh-tools` / `@deepseek-ai/dsh-home-paths` 收紧为 `>=0.1.0-rc.8 <2`（pnpm 对 `> <` 区间取最低满足版 → 精确解析到已验证可装的 0.1.0-rc.8 新图，实测通过）。
- 文档：FAQ 补充「重命名 profile 目录后 `dsh plugin` 报 `ERR_PNPM_UNEXPECTED_VIRTUAL_STORE`」——pnpm 把虚拟商店绝对路径写进 `node_modules/.modules.yaml`，目录改名/复制后失配即报错（pnpm 已知行为，运行时加载不受影响）；修复 = 删除该目录 `node_modules` 后重跑 `dsh plugin ... add`（按 `pnpm-lock.yaml` 重建）。「启动迁移后的 profile」引导处同步加了 ⚠ 提示。
- 文档：FAQ「迁移包里为什么没有 dsh-migrate 自己」更新为「迁移包会带 dsh-migrate 自己吗」——0.0.9 起自动携带；历史版本（≤0.0.8）不带的成因与手动安装命令仍记录在案。

## 0.0.8 (2026-08-19)

- **target-freshness 硬门禁 → `target-used` 软门禁**：目标机已使用（vendor/ 有包、已有非默认 profile、存在 `.dshmig-backup/` 迁移历史）不再拒绝导入，改为预检警告（⚠，不阻断）并逐项说明；导入安全性由既有机制保证（只新建 profile 不覆盖现有配置、settings.yaml 备份后覆盖且可取消勾选、vendor 冲突只报告、`--ignore-scripts` 默认）。
- host 工具 `dsh_migrate_import` 新增 `requireFresh: true` 严格模式：目标机必须为原生未动状态，否则拒绝（回归旧行为，供自动化/CI/演示等确定性场景）。
- UI 预检支持三态：✗（error 阻断）/ ⚠（warn 放行）/ ✓；确认框在目标机非原生时追加醒目提示。
- 测试：`freshness-check` 重写（原生通过 / 三类脏目标 warn 放行 / requireFresh 严格模式拒绝 / 严格模式+原生通过），全量回归绿。

## 0.0.7 (2026-08-19)

- 收录安全审查与核查文档：`docs/SECURITY_REVIEW.md` + `docs/VERIFICATION.md`（README / README_EN 双语加链接；tarball `files` 已含 `docs/`，发布物自带安全记录）。
- 修复 `package.json` description 的 GBK 乱码（npm 元数据）。npm 曾发布的 0.0.6 为旧构建（含乱码 description、缺安全文档），已撤回；GitHub Release v0.0.6 附件为正确构建，不受影响。npm 以 0.0.7 为准。

## 0.0.6 (2026-08-20)

安全审查（SECURITY_REVIEW.md F1–F10）修复：路径穿越、HTTP API 认证、导入代码执行边界、脱敏漏报、膨胀限制、信息泄漏与并发清理。

### 🔴 修复（Critical）

- **F1 导入链 manifest 路径穿越 → 任意目录写入**（实测复现）：`manifest.profiles[0]` / `links[].vendorPath` / `files[].path` 此前无校验直接进 `path.join()`，`../../evil` 可把 profile/vendor 写到 `<home>` 外、sha256 校验可被 `files: []` 整体跳过。修复：`parseManifest` 白名单校验三字段（拒绝 `..`/绝对路径/盘符/`\`/空白/空段）+ `ensureUnder` 落地断言（profile/vendor/presets/staging 读写均限根内，纵深防御）。新增故障注入用例 9–13（`test/fault-injection.mjs`，26 项全过）；修复前漏洞复现脚本见核查记录。

### 🟠 修复（High）

- **F2 HTTP API 无认证**：Host 白名单（仅 `127.0.0.1`/`localhost`/`[::1]`）+ CSRF token（先 `GET /dsh-migrate/api/session` 领取，写请求头 `x-dshmig-token`）+ `Sec-Fetch-Site: cross-site` 拒绝；新增 `test/http-reject.mjs`（10 项全过）。
- **F3 导入 = 执行不可信代码**：`pnpm install` 默认 `--ignore-scripts`（`allowScripts: true` 显式放开）；UI 导入确认框加「归档即代码，仅导入信任来源」警告；README/UI「可放心传输」措辞改为「尽力脱敏，请核对 secretReport（含 unscannedFiles）」。

### 🟡 修复（Medium）

- **F4 凭据脱敏漏报**（实测复现）：带空格引号值（`password: "correct horse battery staple"`）、`Bearer ` 前缀 token、YAML 块标量（PEM 私钥）此前零命中明文导出。修复：值捕获到闭合引号为止（允许空格/转义）；块标量按字段名 + base64/hex 内容启发式整体脱敏；vendor 配置文件（yaml/json/toml/ini/env）纳入扫描；`secretReport` 增加 `unscannedFiles`/`unscannedTotal` 随包导出，UI 展示。新增 `test/secret-cases.mjs` 回归表（21 项全过）。
- **F5 上传/解压无膨胀限制**：`readBody` 流式限长（8MB，超限 413 并断开）；解包预检条目数 ≤10k、总未压缩 ≤512MB、manifest 条目 ≤16MB；磁盘归档文件本体限 512MB。

### ⚪ 修复（Low）

- **F6** manifest `source.dshHome` 不再写绝对路径，改用官方 `dshHomeDisplay()`（`~/.dsh` / `$DSH_HOME`）。
- **F7** `settings.yaml` 为符号链接时预检拒绝（防备份/覆盖穿透写目标）。
- **F8** `dsh_migrate_export` dryRun 语义对齐描述：省略即预览（`args.dryRun !== false`）。
- **F10** staging 清理只删自己的 `staging/<stamp>` 子目录，不再清整根（并发导入互不干扰）。

### 测试

- `test/fault-injection.mjs` 19 → 26 项（新增恶意 manifest 拒绝 5 项）；`test/secret-cases.mjs`（21 项）；`test/http-reject.mjs`（10 项）；`npm test` 全量通过。

### 跟进修复（R1–R3，同版本）

- **R1（F5 引入的回归，Medium）** `readBody` promise 无 `.catch`：客户端发半请求后断开（`for-await` 抛 `aborted`）→ unhandled rejection → Node ≥15 崩溃整个 DSH web 进程（任意本机/局域网进程一个残缺请求即 DoS）。已补 `.catch` 兜底（尽力 500，socket 已断则忽略）；`test/http-reject.mjs` 新增"半请求断开"用例（无 unhandled rejection + 500）。
- **R2（F4 引入的过度脱敏，Medium-Low）** 块标量内容启发式不豁免 `KNOWN_SAFE_FIELDS`：`description:`/`command:` 等合法块恰含 base64/hex 单行时整块被替换，迁移后预设/配置损坏。已豁免：内容启发式仅对非豁免字段生效，字段名是 secret 类（password/privateKey 等）仍整块脱敏。
- **R3（F4 家族残留，Low）** 裸值捕获遇 `,;}{` 即断：`password: abc,defghi`（YAML 合法裸标量）零命中明文导出。已改裸值捕获到行尾或 ` #` 注释（顺带修 `#` 前空格丢失：`token: <redacted> # comment`）。
- **Nit** `manifest.links[].dep` 加入路径白名单（进入 `node_modules/<dep>` 路径，拒绝穿越）；README 补充"vendor 配置原地脱敏 → 迁移后需重配"说明。

- 测试增量：`test/secret-cases.mjs` 21 → 28（R2/R3 用例）；`test/fault-injection.mjs` 26 → 27（dep 白名单）；`test/http-reject.mjs` 10 → 12（R1 用例）。

## 0.0.5 (2026-08-19)

### 修复

- **package.json 混入 UTF-8 BOM**（0.0.4 发布时带出）：DSH `dsh plugin` 解析 bundle manifest 时 `JSON.parse` 崩溃（`Unexpected token '﻿'`）。已剥离 BOM 并全仓库复查无残留。

## 0.0.4 (2026-08-19)

### 改进

- **导入失败诊断**：`pnpm install` / `dsh --dump-config` 失败时，错误信息现在附带底层命令的 stderr/stdout 尾部（此前只报 `exit=1`，无法定位根因——测试机暴露）。

## 0.0.3 (2026-08-19)

### 修复

- **运行时依赖解析崩溃**（0.0.2 引入的装配后暴露）：`schemastery`/`@deepseek-ai/dsh-tools`/`@deepseek-ai/dsh-home-paths` 原声明为 peerDependencies，pnpm 隔离 node_modules 下宿主不保证提供 → DSH 启动即崩（`Cannot find package 'schemastery'`）。已移入 `dependencies` 由 pnpm 装入插件依赖树；顺带修正 `dsh-home-paths` 错误版本范围（`>=0.1.0-rc` 解析不到 `0.0.1-rc.3`）。

## 0.0.2 (2026-08-19)

### 修复

- **bundle 装配缺失**：声明 `dsh.bundle.patch`（`cordis.patch.yml`）并加入 files——此前 `dsh plugin add` 安装后只作为普通依赖、不激活为 profile 层（本机开发走注入器未暴露，npm 正式安装暴露）。0.0.2 起插件可被 DSH 正常装配加载。

## 0.0.1 (2026-08-19)

MVP — 首个可用版本（experimental）。

### 新增

- **导出**：`~/.dsh` 扫描（profiles 配置 / settings.yaml / `.agent-presets` / `vendor/` link 目录）；硬排除凭据与运行态数据；settings/presets 字段级凭据扫描 + 脱敏（`secretReport` 审计）
- **打包**：`.dshmig`（zip）单文件产物，manifest 含 sha256 校验清单、link 映射、排除清单
- **导入**：预检（同 OS / dsh 版本 allowlist / 磁盘提示）→ 备份目标机 → 默认新建 profile（重名递增）→ `link:` 路径重算（断言 vendor 内，防路径逃逸）→ vendor/presets/settings 还原 → `pnpm install` → 验证链（链接解析 → `dsh --dump-config`）→ 失败自动回滚（配置级完全恢复）
- **bundle 契约前置校验**：vendor 包须含 `package.json` 与 `dsh.bundle.patch`（`resolveBundleDir` 实测结论）
- **UI**：设置页「迁移」入口——导出向导（预览 → 执行）+ 导入向导（预检 → 步骤确认 → 执行 → 验证报告）；host HTTP API 4 端点（同源保护）
- **Host 工具**：`dsh_migrate_export` / `dsh_migrate_import`（dryRun 安全模式）
- **测试**：`test/smoke-import.mjs`（沙箱层）、`test/smoke-install.mjs`（完整链路）、`test/fault-injection.mjs`（19 项故障断言）

### 已知边界（MVP）

- 同 OS 迁移；跨 OS 预检拒绝
- 多 profile 归档只导入第一个（警告）
- `git+https://` 依赖目标机重新拉取（需网络）
- 验证链 L4（最小启动验证）v1.x

### 生态对齐

- 包名 `dsh-migrate`（npm 查重通过）、MIT、双语 README、`@deepseek-ai/dsh-home-paths` 官方路径 API
- 构建：`scripts/build.mjs`（无 bash/无 checkout 降级 `_npx` 官方包树）；`scripts/build.sh` 保留（bash + checkout 生态惯例入口）
