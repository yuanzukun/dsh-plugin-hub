/**
 * 构建脚本
 * ------------------------------------------------------------------
 * 把 src/ 下的模块按文件名顺序拼成一个浏览器可直接加载的 classic script，
 * 并把「素材库」与字体、标志一起以 base64 内嵌进去（插件零外部请求）。
 *
 *   node scripts/build.mjs
 *
 * 素材库：
 *   assets/manifest.json 声明所有车辆与声浪，build 时整体内嵌成
 *   BADGE.CARS / BADGE.SOUNDS。新增一辆车 = 放一张图 + 清单加一条，
 *   不需要改任何 JS 代码。
 *
 * 输出：lib/client.js
 */
import { readFileSync, writeFileSync, readdirSync, mkdirSync, existsSync } from 'node:fs';
import { dirname, join, resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const SRC = join(ROOT, 'src');
const ASSETS = join(ROOT, 'assets');

/* 命令行开关：
 *   --local      使用 assets/sounds-local/ 里的本地覆盖声浪（版权素材，仅本机）
 *   --out <路径> 把产物写到别处（例如直接写进 DSH 插件安装目录）
 */
const USE_LOCAL = process.argv.includes('--local');
const OUT_ARG = (() => {
  const i = process.argv.indexOf('--out');
  return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : null;
})();

const OUT = OUT_ARG || join(ROOT, 'lib', 'client.js');

const PKG = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'));

const MIME = {
  '.webp': 'image/webp',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.mp3': 'audio/mpeg',
  '.ogg': 'audio/ogg',
  '.wav': 'audio/wav',
  '.m4a': 'audio/mp4',
  '.woff2': 'font/woff2',
  '.svg': 'image/svg+xml',
};

/** 读 assets 下的文件并转 base64（相对 assets/ 的路径）。 */
function dataUri(rel) {
  const p = join(ASSETS, rel);
  if (!existsSync(p)) throw new Error(`素材不存在：assets/${rel}`);
  const mime = MIME[extname(p).toLowerCase()];
  if (!mime) throw new Error(`未知素材类型：assets/${rel}`);
  return `data:${mime};base64,${readFileSync(p).toString('base64')}`;
}

const FONT_B64 = readFileSync(join(ASSETS, 'rajdhani-700.woff2')).toString('base64');
const LOGO_B64 = readFileSync(join(ASSETS, 'mclaren-mark.webp')).toString('base64');

/* ---------------- 素材库 ---------------- */
const MANIFEST = JSON.parse(readFileSync(join(ASSETS, 'manifest.json'), 'utf8'));

const LOCAL_DIR = join(ASSETS, 'sounds-local');
const localSound = (id) => {
  if (!USE_LOCAL) return null;
  for (const ext of ['.mp3', '.ogg', '.wav', '.m4a']) {
    const p = join(LOCAL_DIR, `${id}${ext}`);
    if (existsSync(p)) {
      const mime = MIME[ext.toLowerCase()] || 'audio/mpeg';
      console.log(`  · 使用本地覆盖声浪：sounds-local/${id}${ext}`);
      return `data:${mime};base64,${readFileSync(p).toString('base64')}`;
    }
  }
  return null;
};

const sounds = (MANIFEST.sounds || []).map((s) => ({
  id: s.id,
  name: s.name || s.id,
  src: localSound(s.id) || (s.file ? dataUri(s.file) : null),
}));

/* 品牌标志：车身配色与 logo 随车辆切换 */
const BRANDS = {};
for (const [id, def] of Object.entries(MANIFEST.brands || {})) {
  BRANDS[id] = {
    src: def.src ? dataUri(def.src) : null,
    metal: Boolean(def.metal),
    metalGrad: def.metalGrad || null,
    text: def.text || null,
    logoW: def.logoW || null,
    logoH: def.logoH || null,
    accent: def.accent || null,
    accent2: def.accent2 || null,
  };
}

const cars = (MANIFEST.cars || []).map((c) => ({
  id: c.id,
  name: c.name || c.id,
  kind: ['plate', 'alpha'].includes(c.kind) ? c.kind : 'cutout',
  css: c.css || null,
  durationMs: c.durationMs || null,
  sound: c.sound || (sounds[0] && sounds[0].id) || null,
  brand: c.brand || 'mclaren',
  engine: c.engine || null,
  src: dataUri(c.file),
  wheels: (c.wheels || []).map((w) => ({
    src: dataUri(w.file),
    x: w.x,
    y: w.y,
    d: w.d,
    speed: w.speed || 0.16,
  })),
}));

if (cars.length === 0) throw new Error('assets/manifest.json 里一辆车都没有');

const assetsBlock = `
/* ---- 素材库（由 assets/manifest.json 生成，勿手改）---- */
BADGE.CARS = ${JSON.stringify(cars, null, 1)};

BADGE.BRANDS = ${JSON.stringify(BRANDS, null, 1)};

BADGE.SOUNDS = ${JSON.stringify(
  Object.fromEntries(sounds.filter((s) => s.src).map((s) => [s.id, s.src])),
  null,
  1,
)};

/** 按 id 找车；找不到返回全部清单（便于调试）。 */
BADGE.findCar = function findCar(id) {
  const list = BADGE.CARS || [];
  return list.find((c) => c.id === id) || null;
};
`;

const files = readdirSync(SRC)
  .filter((f) => f.endsWith('.js'))
  .sort();

if (files.length === 0) throw new Error('src/ 下没有找到模块');

const body = files
  /* 统一行尾为 LF：源码可能被不同工具写成 CRLF，
     产物行尾不一致会让 CI 的「产物 = 源码重建」校验失败 */
  .map((f) => `/* ---- ${f} ---- */\n${readFileSync(join(SRC, f), 'utf8').replace(/\r\n/g, '\n')}`)
  .join('\n\n')
  .replaceAll('__FONT_B64__', FONT_B64)
  .replaceAll('__LOGO_B64__', LOGO_B64);

const banner = `/**
 * ${PKG.name} v${PKG.version} — 由 scripts/build.mjs 生成，请勿直接编辑。
 * 改源码请编辑 src/，素材改 assets/（清单 manifest.json），然后 npm run build。
 */
`;

const output = `${banner}window.__ModuleLoader__.load({
	id: ${JSON.stringify(PKG.name)},
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });

${(body + '\n' + assetsBlock)
  .split('\n')
  .map((line) => (line ? `\t\t${line}` : ''))
  .join('\n')}

		exports.apply = BADGE.apply;
		exports.inject = BADGE.inject;
		return module.exports;
	},
});
`;

mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, output, 'utf8');
if (OUT_ARG) console.log('[build] 已写入 ' + OUT_ARG);

const kb = (n) => `${(n / 1024).toFixed(1)} KB`;
console.log(`已生成 ${OUT}`);
console.log(`  模块 ${files.length} 个：${files.join(', ')}`);
console.log(`  字体 ${kb(FONT_B64.length)} · 标志 ${kb(LOGO_B64.length)}（base64）`);
console.log(`  素材库：${cars.length} 辆车 [${cars.map((c) => `${c.id}/${c.kind}`).join(', ')}] · ${sounds.length} 段声浪`);
console.log(`  产物体积 ${kb(Buffer.byteLength(output))}`);
