import { describe, expect, it } from 'vitest'
import { resolveLearningConfig } from '../src/config.ts'
import { DEFAULT_LEARNING_SECTION } from '../src/guidance.ts'

describe('resolveLearningConfig', () => {
  it('defaults to the shipped Feynman guidance', () => {
    const resolved = resolveLearningConfig({})
    expect(resolved.section).toBe(DEFAULT_LEARNING_SECTION)
  })

  it('uses a provided section', () => {
    const resolved = resolveLearningConfig({ section: 'teach gently' })
    expect(resolved.section).toBe('teach gently')
  })

  it('rejects a blank section', () => {
    expect(() => resolveLearningConfig({ section: '   ' })).toThrow('non-empty')
  })

  it('rejects a non-string section', () => {
    expect(() => resolveLearningConfig({ section: 42 } as never)).toThrow('string')
  })

  it('rejects unknown keys', () => {
    expect(() => resolveLearningConfig({ nope: true } as never)).toThrow('unknown key(s) nope')
  })
})
