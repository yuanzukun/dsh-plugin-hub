import { existsSync, readFileSync } from 'node:fs'
import { mkdtemp, rm } from 'node:fs/promises'
import { homedir, tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import AgentLoop from '@deepseek-ai/dsh-agent-loop'
import { mountAgentLoopTestDependencies } from '@deepseek-ai/dsh-agent-loop-testkit'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import * as LlmDeepSeek from '@deepseek-ai/dsh-llm-deepseek'
import { SessionId } from '@deepseek-ai/dsh-session'
import UserQuestionService, {
  type AskUserQuestionRequest,
  type UserQuestionProvider,
} from '@deepseek-ai/dsh-user-questions'
import * as toolAskUser from '@deepseek-ai/dsh-tool-ask-user'
import { afterEach, describe, expect, it } from 'vitest'
import * as learnEverything from '../src/index.ts'

/**
 * M2 acceptance: with a real model, one learning round walks 讲解 (teach card)
 * → 复述 (ask_user_question) → 判定 (model judges the retelling) → 回讲
 * (gap-only second teach card), then closes. Key-gated: skips without
 * DEEPSEEK_API_KEY, mirroring the harness e2e suites.
 */

const SYSTEM_PROMPT = 'You are a teaching assistant. When the user asks to learn a concept, follow the learning-mode guidance exactly. Keep answers brief.'

/** The simulated user's first retelling: captures the nested-function idea but misses the key mechanism. */
const PARTIAL_RETELLING = '闭包就是一个函数嵌套在另一个函数里面，内层函数可以访问外层函数的变量。'

/** The simulated user's second retelling: names the captured lexical environment, so the loop can close. */
const CORRECT_RETELLING = '闭包是函数与它创建时所在词法作用域的组合：函数记住了创建时的作用域，即使外层函数已经返回，仍能访问其中的变量。'

/** Read DEEPSEEK_API_KEY (and friends) from `$DSH_HOME/.env`, mirroring the CLI's credential plane. */
function loadCredentialsIntoEnv(): void {
  if (process.env.DEEPSEEK_API_KEY !== undefined && process.env.DEEPSEEK_API_KEY !== '') return
  const home = process.env.DSH_HOME ?? join(homedir(), '.dsh')
  const envFile = join(home, '.env')
  if (!existsSync(envFile)) return
  for (const rawLine of readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const match = /^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/.exec(rawLine.trim())
    if (match === null) continue
    const name = match[1]
    const value = match[2]
    if (name === undefined || value === undefined) continue
    if (process.env[name] === undefined || process.env[name] === '') {
      process.env[name] = value.replace(/^["']|["']$/g, '')
    }
  }
}

loadCredentialsIntoEnv()
const hasKey = Boolean(process.env.DEEPSEEK_API_KEY)

/** One scripted human: answer #1 is a partial retelling, every later answer is correct. */
interface ScriptedHuman {
  provider: UserQuestionProvider
  seen: AskUserQuestionRequest[]
  askCount: number
}

function scriptedHuman(): ScriptedHuman {
  const human: ScriptedHuman = { provider: undefined as never, seen: [], askCount: 0 }
  human.provider = {
    async ask(request) {
      human.seen.push(request)
      human.askCount += 1
      const id = request.questions[0]?.id ?? 'teach-back'
      return {
        answers: [{
          id,
          selected: [],
          custom: human.askCount === 1 ? PARTIAL_RETELLING : CORRECT_RETELLING,
        }],
      }
    },
  }
  return human
}

/** Compose the plugin stack under test: agent loop, real DeepSeek adapter, ask-user seam, learn-everything. */
async function learningHarness(): Promise<Context> {
  const ctx = new Context()
  await mountAgentLoopTestDependencies(ctx, { systemPrompt: { persona: SYSTEM_PROMPT } })
  await ctx.plugin(AgentLoop, { agents: [] })
  await ctx.plugin(LlmDeepSeek)
  await ctx.plugin(UserQuestionService)
  await ctx.plugin(toolAskUser)
  await ctx.plugin(learnEverything, {})
  return ctx
}

/** Wait for the agent to go idle, cancelling it after `timeoutMs` so a runaway loop fails the test instead of hanging it. */
function waitForIdle(ctx: Context, agent: Agent, timeoutMs: number): Promise<void> {
  return new Promise((resolve, reject) => {
    let timer: ReturnType<typeof setTimeout> | undefined
    const dispose = ctx.on('agent/status', ({ agent: subject, status }) => {
      if (subject === agent && status === 'idle') {
        dispose()
        if (timer !== undefined) clearTimeout(timer)
        resolve()
      }
    })
    timer = setTimeout(() => {
      dispose()
      agent.cancel({ kind: 'hook', reason: 'learning-loop e2e timeout' })
      reject(new Error(`learning loop did not finish within ${timeoutMs}ms`))
    }, timeoutMs)
  })
}

/** One-line-per-event transcript for failure diagnostics. */
function summarize(events: readonly { type: string; data: Record<string, unknown> }[]): string {
  const lines: string[] = []
  for (const event of events) {
    if (event.type === 'learning/mode') lines.push(`mode ${JSON.stringify(event.data)}`)
    else if (event.type === 'tool/call') {
      const raw = String(event.data.arguments ?? '').replace(/\s+/g, ' ').slice(0, 220)
      lines.push(`call ${String(event.data.name)} ${raw}`)
    } else if (event.type === 'tool/result') {
      const content = JSON.stringify(event.data.message).replace(/\s+/g, ' ').slice(0, 160)
      lines.push(`result ${content}`)
    } else if (event.type === 'assistant/message') {
      const message = event.data.message as { content: { type: string; text?: string }[] }
      const text = message.content.filter(block => block.type === 'text').map(block => block.text ?? '').join('').replace(/\s+/g, ' ').slice(0, 160)
      lines.push(text === '' ? 'assistant (tool call)' : `assistant ${text}`)
    }
  }
  return lines.join('\n')
}

interface ToolCall {
  type: 'tool/call'
  data: { name: string; arguments: string }
}

interface LessonArgs {
  title: string
  sections: { heading: string; prose: string }[]
}

/** Tolerate the harness's invalid-JSON preservation: a malformed teach call is not a lesson. */
function parseLesson(raw: string): LessonArgs | undefined {
  try {
    const value = JSON.parse(raw) as Partial<LessonArgs>
    if (typeof value.title !== 'string' || !Array.isArray(value.sections) || value.sections.length === 0) return undefined
    return value as LessonArgs
  } catch {
    return undefined
  }
}

let ctx: Context | undefined
let workdir: string | undefined

afterEach(async () => {
  await ctx?.fiber.dispose()
  ctx = undefined
  if (workdir !== undefined) await rm(workdir, { recursive: true, force: true })
  workdir = undefined
})

describe.skipIf(!hasKey)('learning loop with a real model', () => {
  it('walks 讲解→复述→判定→回讲 in one round and closes', async () => {
    workdir = await mkdtemp(join(tmpdir(), 'dsh-learn-everything-e2e-'))
    ctx = await learningHarness()
    const agent = ctx.agentLoop.create(SessionId('learning-loop'), {
      provider: 'deepseek-official',
      model: 'deepseek-v4-flash',
    }, { cwd: workdir })

    expect(ctx.learningMode.set(agent, true)).toBe('committed')

    const human = scriptedHuman()
    ctx.userQuestions.registerProvider(human.provider)

    agent.followup(createUserMessage({
      content: [{ type: 'text', text: '请用费曼学习法教我"闭包（closure）"这个概念。' }],
      source: { kind: 'user' },
    }))
    await waitForIdle(ctx, agent, 240_000)

    const events = [...agent.session.events]
    try {
      assertLoop(events, human)
    } catch (error) {
      // Keep the transcript visible for guidance tuning.
      console.info(`learning-loop transcript:\n${summarize(events as { type: string; data: Record<string, unknown> }[])}`)
      throw error
    }
  }, 300_000)
})

/** Structural assertions for one completed 讲解→复述→判定→回讲 round. */
function assertLoop(
  events: readonly { type: string; data: unknown }[],
  human: ScriptedHuman,
): void {
    const calls = events.filter(event => event.type === 'tool/call') as ToolCall[]
    const teachCalls = calls.filter(call => call.data.name === 'teach')
    const askCalls = calls.filter(call => call.data.name === 'ask_user_question')
    // tool/result carries no tool name; the ask-user result is the one whose text is the answers JSON.
    // (JSON.stringify escapes inner quotes, so match the unquoted word.)
    const answerResults = events.filter(event => event.type === 'tool/result' && JSON.stringify((event.data as { message: unknown }).message).includes('answers'))
    const teaches = teachCalls.map(call => ({ call, lesson: parseLesson(call.data.arguments) }))
    const validTeaches = teaches.filter((entry): entry is { call: ToolCall; lesson: LessonArgs } => entry.lesson !== undefined)
    const modes = events.filter(event => event.type === 'learning/mode')

    // 讲解 + 回讲：至少两张 teach 卡片（允许一次畸形 JSON 被重试）
    expect(teachCalls.length).toBeGreaterThanOrEqual(2)
    expect(validTeaches.length).toBeGreaterThanOrEqual(2)
    const first = validTeaches[0]
    const last = validTeaches[validTeaches.length - 1]
    if (first === undefined || last === undefined) throw new Error('no valid lessons despite the length check')

    // 复述：至少一次 ask_user_question（模拟用户作答）；一次教学至多两次提问
    expect(askCalls.length).toBeGreaterThanOrEqual(1)
    expect(answerResults.length).toBeGreaterThanOrEqual(1)
    expect(human.askCount).toBeGreaterThanOrEqual(1)
    expect(human.askCount).toBeLessThanOrEqual(2)
    const firstAsk = askCalls[0]
    if (firstAsk !== undefined) {
      const question = JSON.parse(firstAsk.data.arguments) as { questions: { options?: unknown[] }[] }
      const options = question.questions[0]?.options
      expect(options === undefined ? 0 : options.length).toBeGreaterThanOrEqual(2)
    }

    // 判定驱动回讲：最后一张有效卡片出现在第一次复述答案之后，且只补缺口（标题不同、小节不更多，不重发整卡）
    let firstAnswerResultIndex = -1
    let lastTeachIndex = -1
    events.forEach((event, index) => {
      if (event.type === 'tool/result' && JSON.stringify((event.data as { message: unknown }).message).includes('answers') && firstAnswerResultIndex < 0) {
        firstAnswerResultIndex = index
      }
      if (event.type === 'tool/call' && (event.data as { name: string }).name === 'teach' && (event as ToolCall) === last.call) {
        lastTeachIndex = index
      }
    })
    expect(lastTeachIndex).toBeGreaterThan(firstAnswerResultIndex)
    expect(last.lesson.title).not.toBe(first.lesson.title)
    expect(last.lesson.sections.length).toBeLessThanOrEqual(first.lesson.sections.length)

    // 闭环收尾：存在非空的 assistant 文本（模型总结/简化后结束教学）
    const texts = events.filter(event => event.type === 'assistant/message').flatMap(event =>
      (event.data as { message: { content: { type: string; text?: string }[] } }).message.content
        .filter(block => block.type === 'text')
        .map(block => block.text ?? ''))
    expect(texts.join('').trim().length).toBeGreaterThan(0)

    // 模式状态入日志（model-visible ⟺ logged）
    expect(modes.some(event => (event.data as { active: boolean }).active)).toBe(true)
}
