import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

/**
 * The mermaid singleton's contracts: one-time initialize, serialized renders
 * (mermaid.render is not concurrency-safe), unique diagram ids, and a rejected
 * render that does not poison the queue for later diagrams.
 */

const renderMock = vi.fn()
const initializeMock = vi.fn()

vi.mock('mermaid', () => ({
  default: { initialize: initializeMock, render: renderMock },
}))

async function freshModule(): Promise<typeof import('../src/client/mermaid.ts')> {
  vi.resetModules()
  return import('../src/client/mermaid.ts')
}

beforeEach(() => {
  renderMock.mockReset()
  initializeMock.mockReset()
})

afterEach(() => {
  vi.restoreAllMocks()
})

describe('renderMermaidDiagram', () => {
  it('initializes mermaid once with a strict, non-auto-loading config', async () => {
    const { renderMermaidDiagram } = await freshModule()
    renderMock.mockResolvedValue({ svg: '<svg/>' })

    await renderMermaidDiagram('flowchart TD\nA-->B')
    await renderMermaidDiagram('flowchart TD\nA-->C')

    expect(initializeMock).toHaveBeenCalledTimes(1)
    expect(initializeMock).toHaveBeenCalledWith(expect.objectContaining({
      startOnLoad: false,
      securityLevel: 'strict',
    }))
  })

  it('serializes renders and hands each a unique diagram id', async () => {
    const { renderMermaidDiagram } = await freshModule()
    const order: string[] = []
    renderMock.mockImplementation(async (id: string) => {
      order.push(id)
      return { svg: `<svg>${id}</svg>` }
    })

    const first = renderMermaidDiagram('A')
    const second = renderMermaidDiagram('B')
    // Both start before the first settles; the queue forces A before B.
    const [a, b] = await Promise.all([first, second])

    expect(a).toBe('<svg>lxe-diagram-0</svg>')
    expect(b).toBe('<svg>lxe-diagram-1</svg>')
    expect(order).toEqual(['lxe-diagram-0', 'lxe-diagram-1'])
  })

  it('lets a later render proceed after an earlier one rejects', async () => {
    const { renderMermaidDiagram } = await freshModule()
    renderMock
      .mockRejectedValueOnce(new Error('bad diagram'))
      .mockResolvedValueOnce({ svg: '<svg>ok</svg>' })

    await expect(renderMermaidDiagram('broken')).rejects.toThrow('bad diagram')
    await expect(renderMermaidDiagram('fine')).resolves.toBe('<svg>ok</svg>')
  })
})
