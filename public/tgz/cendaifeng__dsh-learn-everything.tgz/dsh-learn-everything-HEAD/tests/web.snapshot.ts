import { execFileSync, spawn, type ChildProcessWithoutNullStreams } from 'node:child_process'
import { createServer } from 'node:net'
import { existsSync, realpathSync } from 'node:fs'
import { mkdir, mkdtemp, readFile, readdir, realpath, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { chromium, type Browser, type Locator, type Page } from 'playwright'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'

const REPOSITORY = fileURLToPath(new URL('..', import.meta.url))
const SNAPSHOT_DIRECTORY = join(REPOSITORY, 'tests/snapshots/lesson-card')
const SESSION_FIXTURE = join(SNAPSHOT_DIRECTORY, 'session.jsonl')
const UI_GOLDEN = join(SNAPSHOT_DIRECTORY, 'ui.expected.md')
const SESSION_ID = 'web-snapshot-session'

type SnapshotMode = 'replay' | 'refresh'

function snapshotMode(): SnapshotMode {
  const value = process.env.DSH_SNAPSHOT
  if (value === undefined || value === '' || value === 'replay') return 'replay'
  if (value === 'refresh') return value
  throw new Error(`DSH_SNAPSHOT must be replay or refresh; got ${JSON.stringify(value)}`)
}

function requireDshSource(): string {
  const value = process.env.DSH_SOURCE_DIR
  if (value === undefined || value.trim() === '') {
    throw new Error('test:web requires DSH_SOURCE_DIR pointing to a built deepseek-harness checkout')
  }
  const source = realpathSync(value)
  const cli = join(source, 'apps/cli/src/bin.ts')
  const frontend = join(source, 'apps/web/dist/index.html')
  if (!existsSync(cli)) throw new Error(`DSH CLI source is missing: ${cli}`)
  if (!existsSync(frontend)) throw new Error(`DSH Web dist is missing: ${frontend}; build DSH first`)
  return source
}

function dshEnvironment(dshHome: string): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = {
    ...process.env,
    DSH_HOME: dshHome,
    DSH_TELEMETRY_DISABLED: '1',
    DEEPSEEK_API_KEY: '',
  }
  // Strip harness-injected tsx overrides: TSX_TSCONFIG_PATH would point the
  // child tsx loader at another checkout's tsconfig and resolve
  // @deepseek-ai packages from a foreign tree.
  for (const key of Object.keys(env)) {
    if (key.startsWith('TSX_') || key.startsWith('TS_NODE_')) delete env[key]
  }
  return env
}

function runDsh(dshSource: string, dshHome: string, args: readonly string[]): void {
  execFileSync(process.execPath, [
    '--import', 'tsx/esm', join(dshSource, 'apps/cli/src/bin.ts'), ...args,
  ], {
    cwd: dshSource,
    env: dshEnvironment(dshHome),
    encoding: 'utf8',
    stdio: 'pipe',
  })
}

async function seedDshSession(
  dshSource: string,
  dshHome: string,
  workspace: string,
  sessionId: string,
): Promise<void> {
  execFileSync(process.execPath, [join(REPOSITORY, 'tests/seed-web-session.mjs')], {
    cwd: REPOSITORY,
    env: {
      ...dshEnvironment(dshHome),
      DSH_SOURCE_DIR: dshSource,
      DSH_WEB_FIXTURE: SESSION_FIXTURE,
      DSH_WEB_SESSION_ID: sessionId,
      DSH_WEB_WORKSPACE: workspace,
    },
    encoding: 'utf8',
    stdio: 'pipe',
  })
}

function freePort(): Promise<number> {
  return new Promise((resolvePort, reject) => {
    const probe = createServer()
    probe.once('error', reject)
    probe.listen(0, '127.0.0.1', () => {
      const address = probe.address()
      if (address === null || typeof address === 'string') {
        probe.close(() => { reject(new Error('port probe returned no address')) })
        return
      }
      probe.close(() => { resolvePort(address.port) })
    })
  })
}

async function startDsh(dshSource: string, dshHome: string, port: number): Promise<ChildProcessWithoutNullStreams> {
  const child = spawn(process.execPath, [
    '--import', 'tsx/esm', join(dshSource, 'apps/cli/src/bin.ts'), '--profile', 'web', '--port', String(port),
  ], {
    cwd: dshSource,
    env: dshEnvironment(dshHome),
    stdio: ['pipe', 'pipe', 'pipe'],
  })
  let output = ''
  child.stdout.on('data', (chunk: Buffer) => { output += chunk.toString() })
  child.stderr.on('data', (chunk: Buffer) => { output += chunk.toString() })
  await new Promise<void>((resolveReady, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`DSH Web did not start on port ${port}\n${output}`))
    }, 30_000)
    const poll = setInterval(() => {
      if (output.includes(`dsh web: http://127.0.0.1:${port}`)) {
        clearTimeout(timer)
        clearInterval(poll)
        resolveReady()
      }
    }, 25)
    child.once('exit', (code, signal) => {
      clearTimeout(timer)
      clearInterval(poll)
      reject(new Error(`DSH Web exited before readiness (${String(code ?? signal)})\n${output}`))
    })
  })
  return child
}

async function stopDsh(child: ChildProcessWithoutNullStreams | undefined): Promise<void> {
  if (child === undefined || child.exitCode !== null) return
  child.kill('SIGINT')
  if (await exitsWithin(child, 5_000)) return
  child.kill('SIGTERM')
  if (!await exitsWithin(child, 5_000)) throw new Error('DSH Web did not stop after SIGINT and SIGTERM')
}

function exitsWithin(child: ChildProcessWithoutNullStreams, timeoutMs: number): Promise<boolean> {
  if (child.exitCode !== null) return Promise.resolve(true)
  return new Promise(resolve => {
    const timer = setTimeout(() => {
      child.removeListener('exit', exited)
      resolve(false)
    }, timeoutMs)
    function exited(): void {
      clearTimeout(timer)
      resolve(true)
    }
    child.once('exit', exited)
  })
}

async function stableAria(locator: Locator): Promise<string> {
  let previous = await locator.ariaSnapshot()
  for (let attempt = 0; attempt < 20; attempt += 1) {
    await new Promise(resolve => { setTimeout(resolve, 100) })
    const current = await locator.ariaSnapshot()
    if (current === previous) return normalizeAria(current)
    previous = current
  }
  throw new Error('lesson-card aria snapshot did not stabilize')
}

function normalizeAria(value: string): string {
  return value
    .replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, '{{uuid}}')
    .replace(/\d{4}\/\d{1,2}\/\d{1,2} \d{2}:\d{2}:\d{2}/g, '{{clock}}')
}

async function compareOrRefresh(actual: string): Promise<void> {
  const payload = `${actual}\n`
  if (snapshotMode() === 'refresh') {
    await writeFile(UI_GOLDEN, payload)
    return
  }
  if (!existsSync(UI_GOLDEN)) {
    throw new Error(`missing ${UI_GOLDEN}; run pnpm run test:web:refresh`)
  }
  expect(payload).toBe(await readFile(UI_GOLDEN, 'utf8'))
}

describe('keyless assembled DSH Web lesson card', () => {
  let root: string
  let dshHome: string
  let workspace: string
  let host: ChildProcessWithoutNullStreams | undefined
  let browser: Browser | undefined
  let page: Page | undefined
  const pageErrors: string[] = []

  beforeAll(async () => {
    const dshSource = requireDshSource()
    root = await realpath(await mkdtemp(join(tmpdir(), 'dsh-learn-everything-web-snapshot-')))
    dshHome = join(root, 'home')
    workspace = join(root, 'workspace-primary')
    await mkdir(workspace, { recursive: true })
    runDsh(dshSource, dshHome, ['plugin', '--profile', 'web', 'add', REPOSITORY])
    await writeFile(join(dshHome, 'profiles/web/cordis.patch.yml'), [
      '- id: directory-picker',
      '  disabled: true',
      '- insert:',
      '    - id: directory-picker-browse',
      "      name: '@deepseek-ai/dsh-host-directory-picker-browse'",
      '',
    ].join('\n'))
    await seedDshSession(dshSource, dshHome, workspace, SESSION_ID)
    const port = await freePort()
    host = await startDsh(dshSource, dshHome, port)
    browser = await chromium.launch()
    page = await browser.newPage({
      viewport: { width: 1680, height: 1000 },
      locale: 'zh-CN',
      timezoneId: 'UTC',
    })
    page.on('pageerror', error => { pageErrors.push(String(error)) })
    await page.goto(`http://127.0.0.1:${port}`, { waitUntil: 'load' })
    // Onboarding is an ordered multi-step takeover whose steps can mount
    // asynchronously (the DeepSeek credential step appears only after its
    // store loads). Dismiss every visible step and require a stable 1-second
    // detachment before proceeding.
    const onboardingStage = page.locator('[class*="onboardingStage"]')
    const continueButton = page.getByRole('button', { name: '继续', exact: true })
    await continueButton.waitFor({ timeout: 15_000 })
    const onboardingDeadline = Date.now() + 30_000
    let detachedStreak = 0
    while (Date.now() < onboardingDeadline) {
      const visibleContinue = page.getByRole('button', { name: '继续', exact: true })
      const laterButton = page.getByRole('button', { name: /^稍后/ })
      // A completed step re-renders immediately and detaches its buttons
      // mid-click; swallow that expected detachment.
      if (await visibleContinue.isVisible().catch(() => false)) {
        await visibleContinue.click({ timeout: 2_000 }).catch(() => {})
      } else if (await laterButton.isVisible().catch(() => false)) {
        await laterButton.click({ timeout: 2_000 }).catch(() => {})
      } else if (await onboardingStage.count() === 0) {
        detachedStreak += 1
        if (detachedStreak >= 10) break
      } else {
        detachedStreak = 0
      }
      await new Promise(resolve => { setTimeout(resolve, 100) })
    }
    try {
      await onboardingStage.waitFor({ state: 'detached', timeout: 15_000 })
    } catch (error) {
      const buttons = await page.getByRole('button').allTextContents()
      throw new Error(
        `onboarding stage did not detach; visible buttons: ${JSON.stringify(buttons)}\n${await onboardingStage.ariaSnapshot()}`,
        { cause: error },
      )
    }
    const session = page.getByRole('treeitem', { name: /workspace-primary 刚刚/ })
    try {
      await session.waitFor({ timeout: 15_000 })
    } catch (error) {
      throw new Error(`seeded Session did not appear\n${await page.locator('body').ariaSnapshot()}`, { cause: error })
    }
    await session.click()
    await page.getByTestId('dsh-learn-everything-lesson').waitFor({ timeout: 15_000 })
  }, 120_000)

  afterAll(async () => {
    const failures: unknown[] = []
    await browser?.close().catch(error => { failures.push(error) })
    await stopDsh(host).catch(error => { failures.push(error) })
    if (root !== undefined) await rm(root, { recursive: true, force: true }).catch(error => { failures.push(error) })
    if (failures.length === 1) throw failures[0]
    if (failures.length > 1) throw new AggregateError(failures, 'web snapshot cleanup failed')
  })

  it('renders the teach lesson card as rich HTML', async () => {
    if (page === undefined) throw new Error('web page is not initialized')
    const card = page.getByTestId('dsh-learn-everything-lesson')
    // The mermaid first render (cold module init + layout) can outlast the
    // 2s stability window; wait for the ready SVG before snapshotting.
    await card.locator('.lxe-section__diagram[data-diagram-state="ready"] svg').waitFor({ timeout: 30_000 })
    const snapshot = await stableAria(card)
    await compareOrRefresh(snapshot)
    expect(snapshot).toContain('闭包（Closure）')
    expect(snapshot).toContain('闭包是函数与其词法作用域的捆绑')
    expect(snapshot).toContain('核心机制')
    expect(snapshot).toContain('function makeCounter()')
    expect(snapshot).toContain('保险箱')
    expect(snapshot).toContain('补充')
    // The shiki code surface keeps the language banner; the mermaid diagram
    // renders its node labels as SVG text (source block is replaced).
    expect(snapshot).toContain('javascript')
    expect(snapshot).toContain('定义时捕获作用域')
    expect(snapshot).toContain('外层返回后变量仍存活')
    // The diagram actually rendered: one SVG, no pending/error source block.
    expect(await card.locator('.lxe-section__diagram[data-diagram-state="ready"] svg').count()).toBe(1)
    expect(await card.locator('.lxe-section__diagram[data-diagram-state="pending"], .lxe-section__diagram[data-diagram-state="error"]').count()).toBe(0)
    expect(await card.getByRole('heading', { name: '闭包（Closure）' }).count()).toBe(1)
    expect(pageErrors).toEqual([])
  })

  it('keeps the fixture inventory closed', async () => {
    expect((await readdir(SNAPSHOT_DIRECTORY)).sort()).toEqual([
      'session.jsonl', 'ui.expected.md',
    ])
  })
})
