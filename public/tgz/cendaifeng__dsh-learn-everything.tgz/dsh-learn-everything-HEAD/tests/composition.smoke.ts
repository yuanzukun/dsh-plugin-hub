import { execFileSync } from 'node:child_process'
import { existsSync, realpathSync } from 'node:fs'
import { mkdtemp, realpath, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'

const REPOSITORY = fileURLToPath(new URL('..', import.meta.url))
const DRIVER = join(REPOSITORY, 'tests/fixtures/composition-driver.ts')
const CONFIG = join(REPOSITORY, 'tests/fixtures/composition.cordis.yml')
const BUILT_PLUGIN = join(REPOSITORY, 'lib/index.js')

function requireDshSource(): string {
  const value = process.env.DSH_SOURCE_DIR
  if (value === undefined || value.trim() === '') {
    throw new Error('composition smoke requires DSH_SOURCE_DIR pointing to a built deepseek-harness checkout')
  }
  const source = realpathSync(value)
  if (!existsSync(join(source, 'packages'))) throw new Error(`DSH source is missing packages: ${source}`)
  return source
}

function dshEnvironment(dshHome: string): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = {
    ...process.env,
    DSH_HOME: dshHome,
    DSH_TELEMETRY_DISABLED: '1',
    DEEPSEEK_API_KEY: '',
  }
  // Strip harness-injected tsx overrides so the child tsx loader resolves
  // @deepseek-ai packages from this repository's links, not a foreign tree.
  for (const key of Object.keys(env)) {
    if (key.startsWith('TSX_') || key.startsWith('TS_NODE_')) delete env[key]
  }
  return env
}

interface DriverResult {
  ok: boolean
  policyOff: string
  policyOnRendersGuidance: boolean
  teachOffError: string
  teachOnValue: { ok: boolean }
}

describe('keyless composition smoke', () => {
  let dshSource: string
  let root: string

  beforeAll(async () => {
    dshSource = requireDshSource()
    if (!existsSync(BUILT_PLUGIN)) {
      throw new Error(`missing ${BUILT_PLUGIN}; run \`pnpm build\` (or \`pnpm run test:smoke\`) first`)
    }
    root = await realpath(await mkdtemp(join(tmpdir(), 'dsh-learn-everything-composition-')))
  })

  afterAll(async () => {
    await rm(root, { recursive: true, force: true })
  })

  it('boots the plugin through the Loader and gates its model-visible surfaces', () => {
    const stdout = execFileSync(process.execPath, [
      '--import', 'tsx/esm', DRIVER, CONFIG,
    ], {
      cwd: dshSource,
      env: dshEnvironment(join(root, 'home')),
      encoding: 'utf8',
      stdio: 'pipe',
    })
    const result = JSON.parse(stdout.trim()) as DriverResult
    expect(result.ok).toBe(true)
    expect(result.policyOff).toBe('')
    expect(result.policyOnRendersGuidance).toBe(true)
    expect(result.teachOffError).toContain('only available in learning mode')
    expect(result.teachOnValue).toEqual({ ok: true })
  }, 30_000)
})
