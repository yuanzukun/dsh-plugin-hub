import { describe, expect, it } from 'vitest'
import { projectLesson } from '../src/client/project.ts'

describe('projectLesson', () => {
  it('projects a full lesson with all optional fields', () => {
    const lesson = projectLesson(JSON.stringify({
      title: '闭包',
      summary: '闭包是函数与其词法作用域的组合。',
      sections: [{
        heading: '定义',
        prose: '闭包让函数记住创建它的作用域。',
        code: { language: 'ts', text: 'function make() { const x = 1; return () => x }' },
        diagram: { type: 'mermaid', source: 'flowchart TD\nA-->B' },
        analogy: '闭包像随身带着记事本的朋友。',
      }],
      contentHtml: '<p>补充内容</p>',
    }))
    expect(lesson).toEqual({
      title: '闭包',
      summary: '闭包是函数与其词法作用域的组合。',
      sections: [{
        heading: '定义',
        prose: '闭包让函数记住创建它的作用域。',
        code: { language: 'ts', text: 'function make() { const x = 1; return () => x }' },
        diagram: { type: 'mermaid', source: 'flowchart TD\nA-->B' },
        analogy: '闭包像随身带着记事本的朋友。',
      }],
      contentHtml: '<p>补充内容</p>',
    })
  })

  it('projects a minimal lesson', () => {
    const lesson = projectLesson(JSON.stringify({
      title: '事件循环',
      summary: '事件循环是 JS 的调度核心。',
      sections: [{ heading: '概览', prose: '先看整体。' }],
    }))
    expect(lesson?.sections[0]?.code).toBeUndefined()
    expect(lesson?.contentHtml).toBeUndefined()
    expect(lesson?.title).toBe('事件循环')
  })

  it('drops a malformed optional code block instead of failing the lesson', () => {
    const lesson = projectLesson(JSON.stringify({
      title: 'T',
      summary: 'S',
      sections: [{ heading: 'H', prose: 'P', code: { language: 'ts' } }],
    }))
    expect(lesson?.sections[0]?.code).toBeUndefined()
    expect(lesson?.sections[0]?.prose).toBe('P')
  })

  it('drops a malformed diagram kind', () => {
    const lesson = projectLesson(JSON.stringify({
      title: 'T',
      summary: 'S',
      sections: [{ heading: 'H', prose: 'P', diagram: { type: 'dot', source: 'x' } }],
    }))
    expect(lesson?.sections[0]?.diagram).toBeUndefined()
  })

  it('returns undefined for malformed JSON', () => {
    expect(projectLesson('{not json')).toBeUndefined()
  })

  it('returns undefined for a non-object payload', () => {
    expect(projectLesson('"lesson"')).toBeUndefined()
  })

  it('returns undefined when required fields are missing', () => {
    expect(projectLesson(JSON.stringify({ summary: 'S', sections: [] }))).toBeUndefined()
    expect(projectLesson(JSON.stringify({ title: 'T', sections: [] }))).toBeUndefined()
    expect(projectLesson(JSON.stringify({ title: 'T', summary: 'S', sections: 'x' }))).toBeUndefined()
  })

  it('returns undefined when a section misses required fields', () => {
    const raw = JSON.stringify({ title: 'T', summary: 'S', sections: [{ heading: 'H' }] })
    expect(projectLesson(raw)).toBeUndefined()
  })

  it('returns undefined for an empty sections array', () => {
    const raw = JSON.stringify({ title: 'T', summary: 'S', sections: [] })
    expect(projectLesson(raw)).toBeUndefined()
  })
})
