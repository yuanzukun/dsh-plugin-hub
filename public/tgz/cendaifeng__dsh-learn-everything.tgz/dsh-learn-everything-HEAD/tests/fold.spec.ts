import { describe, expect, it } from 'vitest'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import { foldLearningMode } from '../src/fold.ts'

function mode(active: boolean, seq: number): SessionEvent {
  return { type: 'learning/mode', data: { active }, seq } as SessionEvent
}

describe('foldLearningMode', () => {
  it('folds to inactive with no learning/mode events', () => {
    expect(foldLearningMode([])).toBe(false)
  })

  it('folds to active after one on', () => {
    expect(foldLearningMode([mode(true, 1)])).toBe(true)
  })

  it('last event wins: on then off', () => {
    expect(foldLearningMode([mode(true, 1), mode(false, 2)])).toBe(false)
  })

  it('last event wins: off then on', () => {
    expect(foldLearningMode([mode(false, 1), mode(true, 2)])).toBe(true)
  })

  it('ignores unrelated event types', () => {
    const events = [
      { type: 'turn/start', seq: 1 } as SessionEvent,
      mode(true, 2),
      { type: 'assistant/message', seq: 3 } as SessionEvent,
    ]
    expect(foldLearningMode(events)).toBe(true)
  })

  it('honors the end bound over an exclusive prefix', () => {
    const events = [mode(true, 1), mode(false, 2)]
    expect(foldLearningMode(events, 1)).toBe(true)
    expect(foldLearningMode(events, 2)).toBe(false)
  })
})
