import type { Context } from '@deepseek-ai/cordis'
import { LlmAdapter, type StreamChunk } from '@deepseek-ai/dsh-llm'

/**
 * Keyless composition adapter. The smoke never drives a turn — it asserts the
 * plugin's model-visible and durable surfaces — so the adapter only registers
 * a provider the composed agent can name; no request reaches `stream`.
 */
class LearnMockAdapter extends LlmAdapter {
  async * stream(): AsyncIterable<StreamChunk> {
    yield { type: 'finish', reason: { kind: 'stop' } }
  }
}

export const name = 'learn-mock-llm'
export const inject = ['llm']

/** Register the test-only `learn-mock` adapter. */
export function apply(ctx: Context): void {
  ctx.llm.registerAdapter(['learn-mock'], new LearnMockAdapter())
}
