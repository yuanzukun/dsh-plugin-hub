#!/usr/bin/env node
/**
 * Keyless composition smoke driver: boots the real cordis.yml through the
 * Cordis Loader and asserts the model-visible/durable surfaces of
 * dsh-learn-everything — plugin load, conditional `learning:policy` rendering,
 * and the `teach` tool's learning-mode gate.
 */

import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { assembleContextFor, type Agent } from '@deepseek-ai/dsh-agent'
import { boot, installFailLoud, resolveConfigPath } from '@deepseek-ai/dsh-app-boot'
import type AgentLoop from '@deepseek-ai/dsh-agent-loop'
import { CallId } from '@deepseek-ai/dsh-llm'
import { SessionId } from '@deepseek-ai/dsh-session'
import type { PromptAssembly, SystemPrompt } from '@deepseek-ai/dsh-system-prompt'
import type { ToolRuntime } from '@deepseek-ai/dsh-tools'

const NAME = 'dsh-learn-everything-composition'
const [configPath] = process.argv.slice(2)
if (configPath === undefined || configPath.trim() === '') {
  throw new Error(`${NAME}: expected <config-path>`)
}

interface LearningModeControllerLike {
  set(agent: Agent, active: boolean): 'committed' | 'queued' | 'cancelled' | 'noop'
}

const TEACH_ARGS = {
  title: '闭包',
  summary: '闭包是函数与其词法作用域的组合。',
  sections: [{ heading: '定义', prose: '函数记住创建它的作用域。' }],
}

/** The rendered `learning:policy` text, failing the smoke if the section is absent. */
function policyText(assembly: PromptAssembly): string {
  const section = assembly.sections.find(entry => entry.name === 'learning:policy')
  if (section === undefined) throw new Error('learning:policy section is not registered')
  return section.text
}

const uninstallFailLoud = installFailLoud(NAME)
let ctx: Awaited<ReturnType<typeof boot>> | undefined
let workdir: string | undefined
try {
  ctx = await boot(NAME, resolveConfigPath(configPath, undefined))

  const learningMode = ctx.get('learningMode') as LearningModeControllerLike | undefined
  if (learningMode === undefined) throw new Error('learningMode service is missing — the plugin did not load')
  const tools = ctx.get('tools') as ToolRuntime | undefined
  const systemPrompt = ctx.get('systemPrompt') as SystemPrompt | undefined
  const agentLoop = ctx.get('agentLoop') as AgentLoop | undefined
  if (tools === undefined || systemPrompt === undefined || agentLoop === undefined) {
    throw new Error('composition is missing tools/systemPrompt/agentLoop')
  }
  if (tools.get('teach') === undefined) throw new Error('teach tool is not registered')

  workdir = await mkdtemp(join(tmpdir(), 'dsh-learn-everything-composition-'))
  const agent = agentLoop.create(
    SessionId('composition-smoke'), { provider: 'learn-mock', model: 'learn-mock' }, { cwd: workdir },
  )
  const signal = new AbortController().signal

  // Off state: the policy contributes nothing and teach rejects.
  const offText = policyText(await systemPrompt.assemble(assembleContextFor(agent)))
  if (offText !== '') throw new Error(`learning:policy rendered while off: ${JSON.stringify(offText)}`)
  const offResult = await tools.execute({
    callId: CallId('teach-off'), name: 'teach', arguments: TEACH_ARGS, agent, signal,
  })
  if (!offResult.isError || !offResult.error.message.includes('only available in learning mode')) {
    throw new Error(`teach did not reject outside learning mode: ${JSON.stringify(offResult)}`)
  }

  // On state: the policy renders the shipped guidance and teach accepts.
  learningMode.set(agent, true)
  const onText = policyText(await systemPrompt.assemble(assembleContextFor(agent)))
  if (!onText.includes('你在学习模式')) throw new Error('learning:policy did not render the guidance while on')
  const onResult = await tools.execute({
    callId: CallId('teach-on'), name: 'teach', arguments: TEACH_ARGS, agent, signal,
  })
  if (onResult.isError) throw new Error(`teach failed inside learning mode: ${onResult.error.message}`)
  if (JSON.stringify(onResult.value) !== JSON.stringify({ ok: true })) {
    throw new Error(`teach returned an unexpected value: ${JSON.stringify(onResult.value)}`)
  }

  process.stdout.write(`${JSON.stringify({
    ok: true,
    policyOff: offText,
    policyOnRendersGuidance: onText.includes('你在学习模式'),
    teachOffError: offResult.error.message,
    teachOnValue: onResult.value,
  })}\n`)
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`)
  process.exitCode = 1
} finally {
  await ctx?.fiber.dispose()
  if (workdir !== undefined) await rm(workdir, { recursive: true, force: true }).catch(() => {})
  uninstallFailLoud()
}
