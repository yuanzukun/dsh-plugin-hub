import { defineConfig } from 'vitest/config'

// Keyless REAL-composition smoke: boots the plugin through the Loader in a
// subprocess against a built DSH source tree. Requires DSH_SOURCE_DIR.
export default defineConfig({
  test: {
    environment: 'node',
    include: ['tests/**/*.smoke.ts'],
    testTimeout: 60_000,
    hookTimeout: 30_000,
    fileParallelism: false,
  },
})
