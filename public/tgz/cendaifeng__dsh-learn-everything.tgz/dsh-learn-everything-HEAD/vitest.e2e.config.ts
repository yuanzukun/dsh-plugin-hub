import { defineConfig } from 'vitest/config'

// Real-API suite, separate because it spends tokens. Each test self-skips
// without its provider credential for keyless CI. Runs serially: the shared
// internal API key hits concurrency quotas.
export default defineConfig({
  test: {
    environment: 'node',
    include: ['tests/**/*.e2e.ts'],
    testTimeout: 240_000,
    hookTimeout: 30_000,
    fileParallelism: false,
  },
})
