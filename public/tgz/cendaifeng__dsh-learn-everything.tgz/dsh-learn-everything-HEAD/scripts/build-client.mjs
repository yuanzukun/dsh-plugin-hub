#!/usr/bin/env node
import { build } from 'esbuild'
import { existsSync, readFileSync, rmSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'

const repository = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const output = resolve(repository, 'lib', 'client.js')
const pluginId = 'dsh-learn-everything'
const platformModules = [
  'react',
  'react/jsx-runtime',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-locale/client',
  '@deepseek-ai/dsh-client-runtime/client',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-ui-tool/client',
]

await build({
  absWorkingDir: repository,
  entryPoints: ['src/client/index.ts'],
  outfile: output,
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: ['es2022'],
  jsx: 'automatic',
  minify: true,
  legalComments: 'none',
  sourcemap: true,
  external: platformModules,
  banner: {
    js: `window.__ModuleLoader__.load({ id: "${pluginId}", factory: (require) => { var module = { exports: {} }; var exports = module.exports;`,
  },
  footer: { js: 'return module.exports; } });' },
  define: { 'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production') },
  logLevel: 'info',
})

const bundle = readFileSync(output, 'utf8')
if (
  !bundle.includes('window.__ModuleLoader__.load(')
  || !bundle.includes('var module = { exports: {} }')
  || !bundle.includes(pluginId)
) {
  throw new Error(`${pluginId}: client bundle is missing the ModuleLoader handoff`)
}
if (bundle.includes('import.meta') || /(^|\n)\s*(import|export)\s/.test(bundle)) {
  throw new Error(`${pluginId}: client bundle contains ESM syntax`)
}
if (bundle.includes('React.createElement')) {
  throw new Error(`${pluginId}: client bundle contains classic JSX without an in-scope React binding`)
}
for (const match of bundle.matchAll(/require\(\s*["'](@deepseek-ai\/[^"']+)["']\s*\)/g)) {
  if (!platformModules.includes(match[1])) {
    throw new Error(`${pluginId}: unsupported client runtime dependency ${match[1]}`)
  }
}

const require = createRequire(import.meta.url)
const tsc = require.resolve('typescript/bin/tsc')
rmSync(resolve(repository, 'lib', 'client'), { recursive: true, force: true })
const declarations = spawnSync(process.execPath, [tsc, '-p', 'tsconfig.client.json'], {
  cwd: repository,
  encoding: 'utf8',
})
if (declarations.status !== 0) {
  throw new Error(`client declaration build failed:\n${declarations.stdout}${declarations.stderr}`)
}
