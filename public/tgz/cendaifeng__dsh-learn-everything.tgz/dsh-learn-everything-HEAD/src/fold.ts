import type { SessionEvent } from '@deepseek-ai/dsh-session'

// The `learning/mode` event's declaring home: fold.ts is the canonical
// consumer of the event and is included by the host, controller, and spec
// programs alike, so the merge is visible wherever the event is read.
declare module '@deepseek-ai/dsh-session/types' {
  interface SessionEventMap {
    /**
     * Whether learning mode is in force from this point on: log-only,
     * non-surface, whole-value replace. The last `learning/mode` wins; a log
     * with none folds to inactive through {@link foldLearningMode}.
     */
    'learning/mode': { active: boolean }
  }
}

/**
 * Whether learning mode is active after the first `end` events. The last
 * `learning/mode` wins; a prefix with none is inactive.
 *
 * @param events The session log or any prefix of it.
 * @param end Fold `events[0, end)`; defaults to the whole log.
 * @returns Whether learning mode is active.
 */
export function foldLearningMode(events: readonly SessionEvent[], end = events.length): boolean {
  let active = false
  let index = 0
  for (const event of events) {
    if (index >= end) break
    index++
    if (event.type === 'learning/mode') active = event.data.active
  }
  return active
}
