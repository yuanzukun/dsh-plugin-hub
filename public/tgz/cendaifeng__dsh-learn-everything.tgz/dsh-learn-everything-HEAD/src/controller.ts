import { Context, Service } from '@deepseek-ai/cordis'
import type { Agent, PreStepDecision } from '@deepseek-ai/dsh-agent'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import type { Session, SessionEvent, UserMessage } from '@deepseek-ai/dsh-session'
// Type-only imports install the consumed service/event declarations on Context.
import type {} from '@deepseek-ai/dsh-commands'
import type {} from '@deepseek-ai/dsh-system-prompt'
import { resolveLearningConfig, type LearningConfig } from './config.ts'
import { foldLearningMode } from './fold.ts'
import { registerTeachTool } from './teach.ts'

declare module '@deepseek-ai/cordis' {
  interface Context {
    learningMode: LearningModeController
  }
}

/**
 * Learning mode is logged per-session collaboration state: while active, the
 * configured Feynman guidance renders as the `learning:policy` prompt section,
 * and the `teach` tool delivers structured lesson cards. The state in force is
 * folded from the session log (`learning/mode`, last one wins), so resume and
 * fork recover it without a live mirror. User selections remain pending until
 * the next accepted in-turn pre-step.
 *
 * The `/learn on|off` command switches the mode; the teach tool stays
 * registered while learning mode is inactive, so entering or leaving learning
 * mode changes only the prompt section, not the request tool catalog.
 */
export class LearningModeController extends Service {
  static inject = ['tools', 'systemPrompt']

  /** Validated learning-mode guidance. */
  private readonly section: string

  /**
   * Latest selection per session awaiting the next accepted in-turn pre-step.
   * `narrate` is true for user selections (the `/learn` command).
   */
  private readonly pendingIntents = new WeakMap<Session, { active: boolean; narrate: boolean }>()

  constructor(ctx: Context, config: LearningConfig = {}) {
    super(ctx, 'learningMode')
    this.section = resolveLearningConfig(config).section
    // Pre-step is outside Session.append publication, so it can append the
    // log-only mode event inside an open turn without re-entering the session.
    // A failed append remains pending for a later accepted in-turn pre-step,
    // and policy cannot block the step.
    ctx.on('agent/pre-step', async (
      { agent, signal },
      next,
    ): Promise<PreStepDecision> => {
      const decision = await next()
      const pending = this.pendingIntents.get(agent.session)
      if (decision.kind === 'reject' || signal.aborted || pending === undefined) return decision
      const narration = this.narration(agent.session, pending.active)
      try {
        this.onBoundary(agent.session)
      } catch (error) {
        ctx.logger.warn('dsh-learn-everything: failed to append selected learning mode at step start: %o', error)
        return decision
      }
      return !pending.narrate || narration === undefined
        ? decision
        : { ...decision, messages: [...decision.messages, narration] }
    })

    ctx.systemPrompt.section({
      name: 'learning:policy',
      order: 50,
      text: (context) => {
        if (context.agent === undefined) return ''
        const pending = this.pendingIntents.get(context.agent.session)
        return (pending?.active ?? foldLearningMode(context.agent.session.events)) ? this.section : ''
      },
    })

    // The command child activates only when a command registry is composed.
    ctx.inject(['commands'], (commandCtx) => {
      commandCtx.commands.register({
        name: 'learn',
        description: 'Enter or leave learning mode',
        input: { hint: '[on|off]' },
        handler: ({ agent, rawInput }) => {
          const action = rawInput.trim()
          if (action === 'off') {
            switch (this.set(agent, false)) {
              case 'committed':
                return { kind: 'success', text: 'Learning mode off.' }
              case 'queued':
                return { kind: 'success', text: 'Leaving learning mode (applies from the next step).' }
              case 'cancelled':
                return { kind: 'success', text: 'Learning mode entry cancelled.' }
              case 'noop':
                // Repeat the queued wording while an exit still awaits the
                // next accepted pre-step; only a truly inactive session reads
                // idempotent.
                return foldLearningMode(agent.session.events)
                  ? { kind: 'success', text: 'Leaving learning mode (applies from the next step).' }
                  : { kind: 'success', text: 'Learning mode is already inactive.' }
            }
          }
          const outcome = this.set(agent, true)
          return {
            kind: 'success',
            text: outcome === 'committed'
              ? 'Learning mode on. Use /learn off to leave.'
              : 'Entering learning mode (applies from the next step). Use /learn off to leave.',
          }
        },
      })
    })

    registerTeachTool(ctx)
  }

  /**
   * Read the logged learning state and any selected state awaiting the next
   * accepted in-turn pre-step.
   *
   * @param agent The agent to read.
   * @returns Current logged state plus a pending selection, when present.
   */
  get(agent: Agent): { active: boolean; pending?: boolean } {
    const active = foldLearningMode(agent.session.events)
    const pending = this.pendingIntents.get(agent.session)
    return pending === undefined ? { active } : { active, pending: pending.active }
  }

  /**
   * Select whether learning mode should be active. Between turns the method
   * appends the change immediately because no in-turn pre-step will run until
   * another prompt starts a turn. The open-turn fold is the idle signal:
   * agent status stays `running` through post-turn checkpointing, when no
   * further in-turn pre-step runs. During an open turn the selection remains
   * pending until the next accepted in-turn pre-step. Repeated selection of
   * the current or already-pending state is a no-op.
   *
   * @param agent The agent to switch.
   * @param active Whether learning mode should be active.
   * @returns what happened: `committed` (logged now), `queued` (awaiting the
   * next accepted in-turn pre-step), `cancelled` (an opposite pending selection
   * was cleared; the logged state already matches), or `noop` (already in that
   * state).
   */
  set(agent: Agent, active: boolean): 'committed' | 'queued' | 'cancelled' | 'noop' {
    const session = agent.session
    const pending = this.pendingIntents.get(session)
    const target = pending?.active ?? foldLearningMode(session.events)
    if (active === target) return 'noop'
    if (hasOpenTurn(session.events)) {
      this.pendingIntents.set(session, { active, narrate: true })
      return foldLearningMode(session.events) === active ? 'cancelled' : 'queued'
    }
    // No open turn: commit now. Delete only after append succeeds so a
    // failed durable write leaves the selection retryable, not dropped.
    if (active === foldLearningMode(session.events)) {
      this.pendingIntents.delete(session)
      return 'cancelled'
    }
    session.append('learning/mode', { active })
    this.pendingIntents.delete(session)
    const narration = this.narration(session, active)
    if (narration !== undefined) agent.inject(narration)
    return 'committed'
  }

  /** Append one pending selection before the next request assembly. */
  private onBoundary(session: Session): void {
    const pending = this.pendingIntents.get(session)
    if (pending === undefined) return
    const target = pending.active
    if (target === foldLearningMode(session.events)) {
      this.pendingIntents.delete(session)
      return
    }
    session.append('learning/mode', { active: target })
    // Delete only after append succeeds so a later accepted in-turn pre-step
    // can retry a failed durable write.
    this.pendingIntents.delete(session)
  }

  /** Build a user-switch notice when the last logged header described the other mode. */
  private narration(session: Session, target: boolean): UserMessage | undefined {
    const told = learningModeAtLastHeader(session.events)
    if (told === undefined || told === target) return
    const text = target
      ? 'The user switched this session to learning mode.'
      : 'The user switched this session back to the default mode.'
    return createUserMessage({
      content: [{ type: 'text', text }],
      // The narration is already one sentence, so it is its own summary.
      source: { kind: 'plugin', plugin: 'learn-everything', form: 'notice', summary: text },
    })
  }
}

/** Whether the log holds an opened turn without its closing `turn/end`. */
function hasOpenTurn(events: readonly SessionEvent[]): boolean {
  let open = false
  for (const event of events) {
    if (event.type === 'turn/start') open = true
    else if (event.type === 'turn/end') open = false
  }
  return open
}

/** Learning state at the last logged request header, or `undefined` before the first header. */
function learningModeAtLastHeader(events: readonly SessionEvent[]): boolean | undefined {
  let lastHeader = -1
  let index = 0
  for (const event of events) {
    if (event.type === 'request/header') lastHeader = index
    index++
  }
  if (lastHeader < 0) return undefined
  return foldLearningMode(events, lastHeader + 1)
}

export default LearningModeController
