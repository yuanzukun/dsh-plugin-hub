import { useEffect, useState, type ReactElement } from 'react'
import { renderMermaidDiagram } from './mermaid.ts'

type DiagramState = 'pending' | 'ready' | 'error'

/**
 * Render one mermaid diagram source as SVG. The pending and error states keep
 * the raw source block visible (deterministic replay; a malformed diagram
 * still reads as text), while the ready state swaps in the rendered SVG.
 *
 * @param source The mermaid diagram source text.
 */
export function LessonDiagram({ source }: { source: string }): ReactElement {
  const [state, setState] = useState<DiagramState>('pending')
  const [svg, setSvg] = useState('')
  useEffect(() => {
    let cancelled = false
    setState('pending')
    setSvg('')
    void renderMermaidDiagram(source).then(
      (rendered) => {
        if (cancelled) return
        setSvg(rendered)
        setState('ready')
      },
      () => {
        if (cancelled) return
        setState('error')
      },
    )
    return () => { cancelled = true }
  }, [source])
  if (state === 'ready') {
    return (
      <div
        className="lxe-section__diagram"
        data-diagram-kind="mermaid"
        data-diagram-state="ready"
        // Mermaid output with securityLevel 'strict'; only diagram-internal SVG.
        dangerouslySetInnerHTML={{ __html: svg }}
      />
    )
  }
  return (
    <pre
      className="lxe-section__diagram"
      data-diagram-kind="mermaid"
      data-diagram-state={state}
    >
      {source}
    </pre>
  )
}
