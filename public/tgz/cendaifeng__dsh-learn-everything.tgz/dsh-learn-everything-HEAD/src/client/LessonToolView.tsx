import type { ReactElement } from 'react'
import { CodeBlock } from '@deepseek-ai/dsh-client-ui-primitives'
import type { ToolCallViewProps } from '@deepseek-ai/dsh-client-ui-tool/client'
import { LessonDiagram } from './Diagram.tsx'
import { projectLesson } from './project.ts'
import { sanitizeLessonHtml } from './sanitize.ts'

/**
 * Keyed `teach` tool view: renders a structured lesson as a rich HTML card.
 * The card is a pure function of the logged `tool/call` arguments, so replay
 * reproduces it exactly; malformed arguments fall back to nothing, and the
 * caller keeps the generic tool card fallback behavior. Code blocks reuse the
 * shell's shiki `CodeBlock` surface; mermaid diagrams render client-side.
 *
 * @param props The toolview runtime share carrying the frozen call block.
 */
export function LessonToolView({ block }: ToolCallViewProps): ReactElement | null {
  const settled = 'kind' in block
  const argsRaw = (settled ? block.call?.argsRaw : block.argsRaw) ?? ''
  const lesson = projectLesson(argsRaw)
  if (lesson === undefined) return null
  return (
    <div className="lxe-lesson" data-testid="dsh-learn-everything-lesson">
      <h3 className="lxe-lesson__title">{lesson.title}</h3>
      <div className="lxe-lesson__summary">{lesson.summary}</div>
      {lesson.contentHtml !== undefined && (
        <div
          className="lxe-lesson__html"
          // Sanitized before injection; the allowlist rejects script and event handlers.
          dangerouslySetInnerHTML={{ __html: sanitizeLessonHtml(lesson.contentHtml) }}
        />
      )}
      {lesson.sections.map((section, index) => (
        <section className="lxe-section" key={index}>
          <h4 className="lxe-section__heading">{section.heading}</h4>
          <p className="lxe-section__prose">{section.prose}</p>
          {section.code !== undefined && (
            <CodeBlock
              className="lxe-section__code"
              code={section.code.text}
              lang={section.code.language}
            />
          )}
          {section.diagram !== undefined && <LessonDiagram source={section.diagram.source} />}
          {section.analogy !== undefined && (
            <blockquote className="lxe-section__analogy">{section.analogy}</blockquote>
          )}
        </section>
      ))}
    </div>
  )
}
