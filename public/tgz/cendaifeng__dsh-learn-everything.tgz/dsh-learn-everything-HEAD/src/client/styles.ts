/** Lesson card styles, injected as one document style element on plugin load. */
export const LESSON_VIEW_CSS = `
.lxe-lesson {
  border: 1px solid var(--dsw-border, #d0d7de);
  border-radius: 12px;
  padding: 16px 18px;
  margin: 4px 0;
  background: var(--dsw-surface, #ffffff);
  color: var(--dsw-text, #1f2328);
  line-height: 1.6;
  font-size: 14px;
}
.lxe-lesson__title {
  margin: 0 0 6px;
  font-size: 17px;
  font-weight: 700;
  letter-spacing: 0.01em;
}
.lxe-lesson__summary {
  margin: 0 0 12px;
  padding: 9px 12px;
  border-left: 3px solid var(--dsw-accent, #4f6ef2);
  background: var(--dsw-surface-muted, #f6f8fa);
  border-radius: 0 8px 8px 0;
  font-size: 14px;
}
.lxe-lesson__html {
  margin: 8px 0;
  font-size: 14px;
}
.lxe-section {
  margin: 14px 0 0;
  padding-top: 12px;
  border-top: 1px dashed var(--dsw-border, #d0d7de);
}
.lxe-section__heading {
  margin: 0 0 6px;
  font-size: 14.5px;
  font-weight: 600;
}
.lxe-section__prose {
  margin: 0 0 10px;
  font-size: 14px;
}
.lxe-section__code {
  margin: 10px 0;
}
.lxe-section__diagram {
  margin: 10px 0;
  padding: 10px 12px;
  border: 1px solid var(--dsw-border, #d0d7de);
  border-radius: 8px;
  background: #ffffff;
  overflow-x: auto;
  font-family: var(--dsw-font-mono, ui-monospace, SFMono-Regular, Menlo, monospace);
  font-size: 12px;
  white-space: pre-wrap;
}
.lxe-section__diagram svg {
  display: block;
  max-width: 100%;
  height: auto;
}
.lxe-section__analogy {
  margin: 10px 0 0;
  padding: 8px 12px;
  border-radius: 8px;
  background: var(--dsw-surface-muted, #f6f8fa);
  font-style: italic;
  font-size: 13.5px;
}
.lxe-section__analogy::before {
  content: '类比: ';
  font-style: normal;
  font-weight: 600;
}
`
