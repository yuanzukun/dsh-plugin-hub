import DOMPurify from 'dompurify'

/**
 * Sanitize model-supplied lesson HTML against DOMPurify's default HTML
 * profile before it reaches `dangerouslySetInnerHTML`. The structured lesson
 * fields render without this path; `contentHtml` is the escape hatch.
 *
 * @param html The raw model-supplied HTML.
 * @returns Sanitized HTML safe to inject into the document.
 */
export function sanitizeLessonHtml(html: string): string {
  return DOMPurify.sanitize(html, { USE_PROFILES: { html: true } })
}
