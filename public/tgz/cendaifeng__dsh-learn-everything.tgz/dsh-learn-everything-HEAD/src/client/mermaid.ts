/**
 * Lazy mermaid singleton for lesson diagrams. The whole mermaid bundle ships
 * inside `lib/client.js` (the plugin bundle route serves exactly one file), so
 * the ~3.4 MB raw cost is one-time download/parse per page; the dynamic import
 * defers only module evaluation to the first diagram render. Renders are
 * serialized through one chain: mermaid's `render` mutates shared internal
 * state and is not concurrency-safe.
 */

/** Mermaid module namespace as bundled (default export is the API object). */
type MermaidModule = typeof import('mermaid')

let mermaidPromise: Promise<MermaidModule> | undefined

function loadMermaid(): Promise<MermaidModule> {
  mermaidPromise ??= import('mermaid').then((module) => {
    module.default.initialize({
      startOnLoad: false,
      securityLevel: 'strict',
      theme: 'default',
    })
    return module
  })
  return mermaidPromise
}

let renderChain: Promise<unknown> = Promise.resolve()
let diagramCounter = 0

/**
 * Render one mermaid diagram source to SVG markup. Resolves with the SVG
 * string; rejects when the source is not a valid diagram or the render fails.
 * Diagram ids are unique per render so repeated renders of one source never
 * collide.
 *
 * @param source The mermaid diagram source text.
 * @returns The rendered SVG markup.
 */
export async function renderMermaidDiagram(source: string): Promise<string> {
  const run = renderChain.then(async () => {
    const { default: mermaid } = await loadMermaid()
    const { svg } = await mermaid.render(`lxe-diagram-${diagramCounter}`, source)
    diagramCounter += 1
    return svg
  })
  renderChain = run.then(
    () => undefined,
    () => undefined,
  )
  return run
}
