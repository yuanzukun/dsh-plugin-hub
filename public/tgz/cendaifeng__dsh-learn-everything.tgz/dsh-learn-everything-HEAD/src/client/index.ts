/**
 * Browser half: register the keyed `teach` tool view that renders structured
 * lessons as rich HTML. The lesson card replaces the generic tool card for
 * the `teach` wire tool name; all other tool names keep their existing views.
 */
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-ui-tool/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
import { TEACH_TOOL } from 'dsh-learn-everything/constants'
import { LessonToolView } from './LessonToolView.tsx'
import { LESSON_VIEW_CSS } from './styles.ts'

export const inject = ['slots']

export function apply(ctx: Context): void {
  ctx.effect(() => {
    const style = document.createElement('style')
    style.dataset.plugin = 'dsh-learn-everything'
    style.textContent = LESSON_VIEW_CSS
    document.head.append(style)
    return () => { style.remove() }
  }, 'dsh-learn-everything: lesson view styles')
  ctx.slots.inject('tool.call.toolview', () => ctx.slots.register({
    name: 'tool.call.toolview',
    key: TEACH_TOOL,
  }, LessonToolView))
}
