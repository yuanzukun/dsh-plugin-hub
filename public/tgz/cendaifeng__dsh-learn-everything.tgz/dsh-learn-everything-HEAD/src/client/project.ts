import type { Lesson, LessonSection } from 'dsh-learn-everything/types'

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function stringOf(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined
}

/** Project one raw section value; malformed optional blocks are dropped, required fields must hold. */
function projectSection(value: unknown): LessonSection | undefined {
  if (!isRecord(value)) return undefined
  const heading = stringOf(value.heading)
  const prose = stringOf(value.prose)
  if (heading === undefined || prose === undefined) return undefined
  const code = value.code
  const codeBlock = isRecord(code) && stringOf(code.language) !== undefined && stringOf(code.text) !== undefined
    ? { language: stringOf(code.language) as string, text: stringOf(code.text) as string }
    : undefined
  const diagram = value.diagram
  const diagramBlock = isRecord(diagram) && diagram.type === 'mermaid' && stringOf(diagram.source) !== undefined
    ? { type: 'mermaid' as const, source: stringOf(diagram.source) as string }
    : undefined
  const analogy = stringOf(value.analogy)
  return {
    heading,
    prose,
    ...(codeBlock === undefined ? {} : { code: codeBlock }),
    ...(diagramBlock === undefined ? {} : { diagram: diagramBlock }),
    ...(analogy === undefined ? {} : { analogy }),
  }
}

/**
 * Project raw teach tool arguments (the logged JSON string) onto a valid
 * Lesson, or `undefined` when the payload is malformed. The view falls back
 * to the generic card when projection fails.
 *
 * @param argsRaw The logged `tool/call` arguments JSON string.
 * @returns The projected lesson, or `undefined`.
 */
export function projectLesson(argsRaw: string): Lesson | undefined {
  let parsed: unknown
  try {
    parsed = JSON.parse(argsRaw)
  } catch {
    return undefined
  }
  if (!isRecord(parsed)) return undefined
  const title = stringOf(parsed.title)
  const summary = stringOf(parsed.summary)
  const sections = parsed.sections
  if (title === undefined || summary === undefined || !Array.isArray(sections)) return undefined
  const projected: LessonSection[] = []
  for (const section of sections) {
    const item = projectSection(section)
    if (item === undefined) return undefined
    projected.push(item)
  }
  if (projected.length === 0) return undefined
  const contentHtml = stringOf(parsed.contentHtml)
  return {
    title,
    summary,
    sections: projected,
    ...(contentHtml === undefined ? {} : { contentHtml }),
  }
}
