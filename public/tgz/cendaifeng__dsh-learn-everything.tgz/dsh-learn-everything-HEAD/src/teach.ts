import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { TEACH_TOOL } from './constants.ts'
import { foldLearningMode } from './fold.ts'

const TEACH_DESCRIPTION
  = 'Use only in learning mode. Deliver one structured, visually rendered teaching card for the concept you are explaining: '
  + 'a short title, a one-sentence summary, and sections with prose plus optional code, mermaid diagram, and analogy.'

/**
 * Register the model-facing teach tool. The tool stays registered while
 * learning mode is inactive, so entering or leaving learning mode changes
 * only the prompt section, never the request tool catalog; execution outside
 * learning mode fails.
 *
 * @param ctx The host context.
 */
export function registerTeachTool(ctx: Context): void {
  ctx.tools.register(defineTool({
    name: TEACH_TOOL,
    description: TEACH_DESCRIPTION,
    parameters: {
      title: { type: 'string', required: true, description: 'Short title of the concept being taught.' },
      summary: { type: 'string', required: true, description: 'One-sentence plain-language summary of the concept.' },
      sections: {
        type: 'array',
        required: true,
        description: 'Teaching sections of the lesson, in order.',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            heading: { type: 'string', required: true, description: 'Heading of this section.' },
            prose: { type: 'string', required: true, description: 'Explanation prose for this section.' },
            code: {
              type: 'object',
              additionalProperties: false,
              description: 'Optional minimal code example.',
              properties: {
                language: { type: 'string', required: true, description: 'Programming language of the code.' },
                text: { type: 'string', required: true, description: 'Code text.' },
              },
            },
            diagram: {
              type: 'object',
              additionalProperties: false,
              description: 'Optional mermaid diagram source.',
              properties: {
                type: { type: 'string', const: 'mermaid', required: true },
                source: { type: 'string', required: true, description: 'Mermaid diagram source text.' },
              },
            },
            analogy: { type: 'string', description: 'Optional plain-language analogy for this section.' },
          },
        },
      },
      contentHtml: {
        type: 'string',
        description: 'Optional raw HTML payload rendered client-side after sanitization; prefer the structured fields.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', const: true, required: true },
        },
      },
      render: () => [{
        type: 'text',
        text: 'Lesson delivered. Continue the Feynman loop: ask the user to teach the concept back, or answer their follow-up questions.',
      }],
    },
    execute: async (args, exec) => {
      const agent = exec.agent
      if (agent === undefined) {
        throw new Error('teach requires a calling agent (no session to teach in)')
      }
      if (!foldLearningMode(agent.session.events)) {
        throw new Error('teach is only available in learning mode (run /learn)')
      }
      if (args.sections.length === 0) {
        throw new Error('teach requires at least one section')
      }
      return { ok: true }
    },
    presentCall: args => ({
      card: 'generic',
      title: args.title,
      kind: 'other',
    }),
    presentResult: (_args, result) => ({
      card: 'generic',
      title: 'Lesson',
      content: result.content,
    }),
  }))
}
