/** One optional code block inside a lesson section. */
export interface LessonCode {
  /** Programming language of the code. */
  readonly language: string
  /** Code text. */
  readonly text: string
}

/** One optional diagram inside a lesson section. */
export interface LessonDiagram {
  /** Diagram kind; mermaid is the only supported kind. */
  readonly type: 'mermaid'
  /** Mermaid diagram source text. */
  readonly source: string
}

/** One teaching section of a lesson. */
export interface LessonSection {
  /** Section heading. */
  readonly heading: string
  /** Explanation prose for this section. */
  readonly prose: string
  /** Optional minimal code example. */
  readonly code?: LessonCode
  /** Optional diagram source. */
  readonly diagram?: LessonDiagram
  /** Optional plain-language analogy. */
  readonly analogy?: string
}

/** A structured lesson delivered through the teach tool. */
export interface Lesson {
  /** Short title of the taught concept. */
  readonly title: string
  /** One-sentence plain-language summary. */
  readonly summary: string
  /** Teaching sections, in order. */
  readonly sections: readonly LessonSection[]
  /** Optional raw HTML payload rendered client-side after sanitization. */
  readonly contentHtml?: string
}
