/** Wire tool name of the teach tool; also the keyed toolview slot key on the client. */
export const TEACH_TOOL = 'teach'
