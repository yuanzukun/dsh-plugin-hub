import { DEFAULT_LEARNING_SECTION } from './guidance.ts'

/** dsh-learn-everything plugin configuration. */
export interface LearningConfig {
  /**
   * Learning-mode guidance rendered as the `learning:policy` prompt section
   * while learning mode is active; defaults to the shipped Feynman guidance.
   */
  section?: string
}

/** The resolved config shape consumed by the controller. */
export type Config = LearningConfig

/**
 * Validate plugin config. Missing `section` uses the shipped guidance;
 * blank, non-string, or unknown keys fail at plugin load rather than being
 * ignored.
 *
 * @param config Raw plugin config.
 * @returns A detached validated config.
 */
export function resolveLearningConfig(config: LearningConfig): { section: string } {
  const section = (config as Partial<LearningConfig>).section ?? DEFAULT_LEARNING_SECTION
  if (typeof section !== 'string') {
    throw new Error('LearningConfig needs a string `section`')
  }
  if (section.trim() === '') {
    throw new Error('LearningConfig needs a non-empty `section`')
  }
  const unknown = Object.keys(config).filter(key => key !== 'section')
  if (unknown.length > 0) {
    throw new Error(`LearningConfig has unknown key(s) ${unknown.join(', ')} — config is { section? }`)
  }
  return { section }
}
