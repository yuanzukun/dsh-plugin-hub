/**
 * dsh-learn-everything host plugin: session-scoped Feynman learning mode.
 *
 * When learning mode is active (`/learn on`), the Feynman guidance renders as
 * the `learning:policy` prompt section, the `teach` tool delivers structured
 * lesson cards, and the model drives the teach-back loop through the shipped
 * `ask_user_question` tool. Mode state is a log-only `learning/mode` session
 * event; the Web client renders lessons through the keyed `teach` tool view.
 *
 * @module dsh-learn-everything
 */
import type { Context } from '@deepseek-ai/cordis'
import type { LearningConfig } from './config.ts'
import { LearningModeController } from './controller.ts'

export const name = 'dsh-learn-everything'

/** Required host services: tool registry and system-prompt assembly. */
export const inject = ['tools', 'systemPrompt']

export { resolveLearningConfig } from './config.ts'
export type { Config, LearningConfig } from './config.ts'
export { LearningModeController } from './controller.ts'
export { TEACH_TOOL } from './constants.ts'
export { foldLearningMode } from './fold.ts'
export type * from './types.ts'

/** Open the session-scoped learning-mode controller. */
export async function apply(ctx: Context, config: LearningConfig): Promise<void> {
  new LearningModeController(ctx, config)
}
