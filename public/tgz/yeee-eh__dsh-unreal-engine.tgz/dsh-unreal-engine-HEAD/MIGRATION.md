# 迁移手册：junction → 标准安装

> 目标：把 `dsh-unreal-engine` 从「用目录连接手动挂的」变成「真正通过包管理器安装的」。
>
> **为什么值得做**：只有自己先用标准方式装过，才能诚实地说「别人也能装」。
>
> 预计耗时 5 分钟。**大约 2 分钟 DSH 是不可用的**，所以选个方便的时间。

> **命令里的两个占位符**：`$env:DSH_HOME`（DSH 配置根目录）与
> `$RepoRoot`（本插件源码目录）。含义与设法见 [README.md](README.md#命令里的两个占位符)。
>
> ```powershell
> if (-not $env:DSH_HOME) { $env:DSH_HOME = "$env:USERPROFILE\.dsh" }
> $RepoRoot = 'C:\path\to\dsh-unreal-engine'
> ```

---

## 迁移前状态（已确认）

```
$env:DSH_HOME\profiles\node_modules\dsh-unreal-engine      → Junction  ← 要删
$env:DSH_HOME\profiles\web\node_modules\dsh-unreal-engine  → Junction  ← 要删
$env:DSH_HOME\profiles\web\package.json                    → bundles 已含 dsh-unreal-engine
$env:DSH_HOME\profiles\web\pnpm-lock.yaml                  → 存在，未提及本包
$env:DSH_HOME\cordis.patch.yml                             → []  （空，保持不动）
```

---

## ⚠️ 开始前：DSH 必须完全停掉

不是关浏览器标签页 —— **是要结束进程**。

先确认没在跑：

```powershell
Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
  Where-Object LocalPort -eq 3080 |
  Select-Object LocalPort, OwningProcess
```

- **没有任何输出** → 已停干净，继续
- **有输出** → 还有进程占着 3080，先关掉 DSH（或 `Stop-Process -Id <上面那个PID> -Force`）

> 为什么必须停：`pnpm add` 会重写 `node_modules`，运行中的进程正持有里面的文件，
> 在 Windows 上会报 `EBUSY` / `EPERM`，甚至留下半损坏的目录。

---

## 步骤 1：备份（10 秒，别省）

```powershell
Copy-Item '$env:DSH_HOME\profiles\web\package.json'    '$env:DSH_HOME\profiles\web\package.json.bak-migrate' -Force
Copy-Item '$env:DSH_HOME\profiles\web\pnpm-lock.yaml'  '$env:DSH_HOME\profiles\web\pnpm-lock.yaml.bak-migrate' -Force
```

**期望**：无输出。用下面确认：

```powershell
Test-Path '$env:DSH_HOME\profiles\web\package.json.bak-migrate',
          '$env:DSH_HOME\profiles\web\pnpm-lock.yaml.bak-migrate'
```

**期望输出**：两行 `True`

---

## 步骤 2：删掉两个 junction

```powershell
Remove-Item '$env:DSH_HOME\profiles\node_modules\dsh-unreal-engine' -Force
Remove-Item '$env:DSH_HOME\profiles\web\node_modules\dsh-unreal-engine' -Force
```

**期望**：无输出，无报错。

> ⚠️ `Remove-Item` 对 junction **默认只删链接，不删目标**。
> 但如果你用了 `-Recurse` 在某些 PowerShell 版本上会**递归进目标真实删除源文件**。
> **上面命令刻意没有 `-Recurse`** —— 不要加。
>
> 删完后确认源目录还在：
> ```powershell
> Test-Path '$RepoRoot\package.json'
> ```
> **期望**：`True`（如果是 `False`，源文件被误删了，见「故障 F」）

---

## 步骤 3：标准安装

```powershell
cd $env:DSH_HOME\profiles\web
pnpm add 'file:$RepoRoot'
```

**期望输出**（关键行）：
```
Packages: +3
Progress: resolved ... added 3
dependencies:
+ dsh-unreal-engine 0.1.0 <- $RepoRoot
```

**注意**：
- **`+3` 而不是 `+97`** —— 因为我们已经把 `react` / `@modelcontextprotocol/sdk` 改成了可选 peer，不会再重复装
- 如果看到 `+90` 以上 → 说明 `package.json` 的依赖声明没生效，停下来告诉我
- lock 文件有 54KB，可能要处理十几秒，**慢是正常的**
- 全程**不需要联网**（包在本地、无 dependencies）

---

## 步骤 4：验证安装（三项，缺一不可）

### 4.1 包落位了吗

```powershell
Get-Item '$env:DSH_HOME\profiles\web\node_modules\dsh-unreal-engine' -Force |
  Select-Object Name, LinkType
```

**期望**：`LinkType` 是**空的**（普通目录拷贝），不是 `Junction`
> pnpm 配了 `nodeLinker: hoisted`，所以是真实拷贝，不是符号链接。

### 4.2 三个入口能按包名解析吗

```powershell
cd $env:DSH_HOME\profiles\web
node -e "const{createRequire}=require('node:module');const r=createRequire('$env:DSH_HOME/profiles/web/x.cjs');for(const s of ['dsh-unreal-engine','dsh-unreal-engine/client','dsh-unreal-engine/cordis.patch.yml']){try{console.log('OK   '+s)}catch(e){console.log('FAIL '+s)}};try{r.resolve('dsh-unreal-engine');console.log('解析: '+r.resolve('dsh-unreal-engine'))}catch(e){console.log('解析失败: '+e.code)}"
```

**期望**：三行 `OK` + 一行 `解析: ...\node_modules\dsh-unreal-engine\lib\index.js`

### 4.3 插件树能加载吗（**最重要的验证**）

```powershell
dsh --profile sdk
```

**期望**：**立刻退出，屏幕上什么都没有**（exit code 0）
> 这就是「插件树加载成功」。有输出/报错就说明有问题。

---

## 步骤 5：启动并确认

```powershell
dsh --profile web
```

**期望**：
```
dsh web: http://127.0.0.1:3080/?token=...
```
浏览器打开 → **设置里能看到「虚幻引擎」**。

---

## 故障处理

### 故障 A：步骤 3 报 `EBUSY` / `EPERM`

**原因**：DSH 还在跑，或文件被占用。

```powershell
# 杀掉所有占 3080 的进程
Get-NetTCPConnection -State Listen -EA SilentlyContinue |
  Where-Object LocalPort -eq 3080 |
  ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }
Start-Sleep -Seconds 3
```

然后**重跑步骤 3**。pnpm 是幂等的，重跑安全。

---

### 故障 B：步骤 3 之后 DSH 起不来

**先看是哪一类错误**：

```powershell
dsh --profile sdk
```

| 报错 | 含义 | 处理 |
|---|---|---|
| `Cannot find package 'dsh-unreal-engine'` | 包没装成 | 见故障 C |
| `failed to apply loader entry` | bundle patch 有问题 | 见故障 D |
| 其它 | 贴给我 | — |

---

### 故障 C：包找不到

**最快的退路：重建 junction**（回到迁移前，保证能用）

```powershell
New-Item -ItemType Junction `
  -Path '$env:DSH_HOME\profiles\node_modules\dsh-unreal-engine' `
  -Target '$RepoRoot'

Test-Path '$env:DSH_HOME\profiles\node_modules\dsh-unreal-engine'
```

**期望**：`True`。然后 `dsh --profile web` 应该就能起来。

---

### 故障 D：`failed to apply loader entry`

先看完整错误：

```powershell
dsh --profile web --dump-config
```

**期望**：`exit=0`，且能看到 `# == dsh-unreal-engine` 来源段。
如果报 `not found` / `mismatch`，把输出贴给我。

**同时确认 home 补丁还是空的**：

```powershell
node -e "const y=require('<npx缓存>/node_modules/js-yaml');console.log('entries =',y.load(require('fs').readFileSync('$env:DSH_HOME/cordis.patch.yml','utf8')).length)"
```

**期望**：`entries = 0`（不是 0 说明有人往里面写了东西，那是冲突源）

---

### 故障 E：想完全撤销迁移

```powershell
# 1. 卸载
cd $env:DSH_HOME\profiles\web
pnpm remove dsh-unreal-engine

# 2. 还原配置
Copy-Item '$env:DSH_HOME\profiles\web\package.json.bak-migrate'   '$env:DSH_HOME\profiles\web\package.json' -Force
Copy-Item '$env:DSH_HOME\profiles\web\pnpm-lock.yaml.bak-migrate' '$env:DSH_HOME\profiles\web\pnpm-lock.yaml' -Force

# 3. 重建 junction
New-Item -ItemType Junction `
  -Path '$env:DSH_HOME\profiles\node_modules\dsh-unreal-engine' `
  -Target '$RepoRoot'
```

回到迁移前的可用状态。

---

### 故障 F：源文件被误删了

如果你不小心用了 `Remove-Item -Recurse`，源目录可能被删。检查：

```powershell
Test-Path '$RepoRoot\package.json'
```

**如果是 `False`**：告诉我，我按记录重建（所有源码我都有）。

---

### 故障 G：DSH 完全打不开（最坏情况）

按 `RECOVERY.md` 走。核心是：

```powershell
# 把 home 补丁清成空数组
'[]' | Set-Content '$env:DSH_HOME\cordis.patch.yml' -Encoding UTF8

# 把 bundles 里的本包去掉（手动编辑 package.json，删掉 "dsh-unreal-engine" 那一行）

# 重建 junction 或删掉残留
```

详见同目录的 `RECOVERY.md`。

---

## 一句话总结

| 步骤 | 命令 | 期望 |
|---|---|---|
| 0 | 确认 3080 没被占 | 无输出 |
| 1 | 备份 package.json + lock | 两行 True |
| 2 | 删两个 junction | 无输出，源目录仍在 |
| 3 | `pnpm add 'file:D:\...'` | **`+3`**，输出含 `+ dsh-unreal-engine` |
| 4 | `dsh --profile sdk` | **零输出，exit 0** |
| 5 | `dsh --profile web` | 出 `dsh web: http://127.0.0.1:3080/…` |
