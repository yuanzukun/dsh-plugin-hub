---
name: unreal-mcp
description: 通过 MCP 驱动 Unreal Engine 5.8+ 编辑器：查询项目状态、批量编辑资源与蓝图、驱动 PIE、读日志排障。当用户提到 UE、Unreal、蓝图、关卡、材质、打包、PIE，或要求操作 .uasset/.umap 时使用。
---

# 驱动 Unreal Engine 编辑器

你现在可以通过 `mcp__unreal__*` 系列工具直接读写用户的 UE5 编辑器。
**这些不是模拟，是真的在改用户的工程。** 按下面的规矩来。

## 工具是渐进式暴露的 —— 先这一层

UE 官方只暴露 **3 个 meta 工具**，真正的能力在 Toolset 注册表里
（实测一台 UE 5.8.2 上有 **53 个 Toolset**）：

| 工具 | 作用 |
|---|---|
| `mcp__unreal__list_toolsets` | 列出所有 Toolset 及其说明 |
| `mcp__unreal__describe_toolset` | 取某个 Toolset 里**确切的函数名、参数 schema** |
| `mcp__unreal__call_tool` | 真正执行 |

**正确用法是三步，不要跳步：**

1. `list_toolsets` —— 看有哪些能力域
2. `describe_toolset` —— 取你要用的那个 Toolset 的**确切 schema**
3. `call_tool` —— 传**确切的函数名和参数**执行

**不要凭猜测编造工具名或参数。** 必须先 `describe_toolset` 拿到权威 schema。
schema 可能随插件变化，需要时就重新 describe，别用记忆里的旧版本。

常用 Toolset 提示：

| 你要做的事 | 大致去哪个 Toolset |
|---|---|
| PIE 控制、视口、CVar、选择集、内容浏览器 | `EditorToolset.EditorAppToolset` |
| 读编辑器日志 | `EditorToolset.LogsToolset` |
| 跑自动化测试 | `AutomationTestToolset` |
| 驱动编辑器 UI、截图 | `SlateInspectorToolset` |
| 按语义搜资产 | `SemanticSearchToolset` |
| Niagara / GAS / PCG / 物理 / 配置 / 插件 | 对应同名 Toolset |

> `describe_toolset` 的内容会进入对话历史并占用上下文。
> 只为**当前真正要用的** Toolset 拉取，用完不要反复拉。

## 铁律

### 1. 先查证，再动手

UE 里的**标签、显示名、内容浏览器选中的东西都不是稳定标识**。
颜色、位置、选中态都会变，唯独**资源路径**（`/Game/...`）和**对象路径**是稳定的。

所以任何修改前：

1. 用工具查出**确切的对象或资源路径**
2. 如果匹配到多个候选 —— **停下来问用户**，不要自己挑一个
3. 改动前先记录当前状态（属性值、变换、图的形状）

### 2. 不要假设结果

UE 的很多操作是**异步**的：编译、保存、Cook、资源加载都要时间。
调用返回 ≠ 操作生效。

改完必须**回读**确认。比如改了属性，就读回那个属性比对；
改了蓝图，就看编译状态和错误列表。

### 3. 非幂等操作绝不盲目重试

`spawn`、`duplicate`、`add component`、创建资源、改名、移动 —— 这些**重复执行会产生多份**。

超时或无响应时，**先查再决定**：

- 按稳定路径/类名搜一遍，证明到底是 0 个、1 个还是多个
- 确认原操作确实没生效，且用户原本的授权仍覆盖这次重试，才重试
- 状态混乱就**停下报告**，清理是另一个独立操作，需要单独授权

### 4. 风险分级

| 操作 | 处理方式 |
|---|---|
| 搜索、只读查询 | 直接做，报告真实证据 |
| 建/改被明确指定的对象 | 可以做，但要验证前后状态 |
| 保存、编译、PIE 进出 | 确认这是任务所需，等它完成，读结果 |
| 移动/改名/删除、批量或跨资源改动 | 确认确切目标 + 恢复点；用户没明说就解释影响后再问 |
| **执行任意 Python**、改项目/插件设置、改源码 | **最高风险**。先展示要执行什么，拿到明确授权再动 |
| 删除 | 先证明目标确实还在、邻近对象没被动过；**绝不盲目重复** |

> DSH 外层的审批机制可能仍会对 `call_tool` 弹确认。
> **那张表不替代也不修改审批机制**，而且"审批通过"也不等于用户扩大了他要求的范围。

## 长任务

UE 的 Cook、全量编译、大体量资源导入可能跑十几分钟。
本插件的 `toolCallTimeoutMs` 已放宽到 10 分钟；仍超时就说明任务更重，
应该改用 UE 自己的命令行（`UnrealBuildTool` / `RunUAT`）而不是 MCP 调用。

**同一时刻只发一个 UE 调用**，包括看起来独立的查询。
UE 编辑器是单线程的，并发调用会互相干扰甚至死锁。

## 报错识别

| 现象 | 原因 | 处理 |
|---|---|---|
| `unable to bind to 127.0.0.1:<port>` | 端口被占 | 换端口，两边同步改 |
| connection refused / timeout | 编辑器没开，或没 `StartServer` | 让用户跑 `ModelContextProtocol.StartServer` |
| 找不到 meta 工具 | Tool Search 没开 | 让用户启用 `AllToolsets` 后 `RefreshTools` |
| 工具列表为空 | Toolset 未启用 | `ModelContextProtocol.RefreshTools` + 重连 |
| 未知工具或参数 | 工具集变了 | 重新跑 `describe_toolset`，用原始 schema |
| 新工具 schema 是旧的 | 需要重载 | `RefreshTools` + 重连；新增的 `UFUNCTION` 需要**重启编辑器** |
| 调用挂起/时断时续 | 着色器/C++/蓝图在编译，或 PIE 在跑 | 等状态稳定再调 |

排障细节见 `references/troubleshooting.md`。

## 边界

- **不要**声称做了实际没做的事。只在有工具返回证据时才说"已完成"。
- 最终文字看起来对、但**没有编辑器证据**，就当作**未验证**，去回读目标状态。
- 不确定就问。问一句的成本远低于改坏一个工程。

## 责任划分

- 如果错了的是**本插件的配置、Skill 内容或工作流规矩** → 改本插件
- 如果同样的失败**在非 UE 的 MCP server 上也能复现** → 那是 DSH 或 MCP 客户端的问题，
  记一个最小复现交给它们，**不要**在本插件里加通用的上下文管理、调度器、审批引擎或代理层
