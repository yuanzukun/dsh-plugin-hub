# 排障手册

先跑 `node ue5-dsh-doctor.mjs`。它会告诉你断在哪一段，再看对应章节。

---

## 症状 → 成因 速查

| 症状 | 最可能成因 | 处理 |
|---|---|---|
| `ECONNREFUSED 127.0.0.1:8000` | 编辑器没开，或没开服 | 跑 `ModelContextProtocol.StartServer` |
| `unable to bind to 127.0.0.1:<port>` | 端口被别的进程占了 | 换端口，UE 与 DSH 两边同步改 |
| HTTP 404 | 路径错 | 端点必须以 `/mcp` 结尾，不是 Remote Control 的路径 |
| HTTP 405 | **正常**（对 GET 而言） | 服务只接受 POST，405 说明端点存在且正确，无需处理 |
| HTTP 406 | `Accept` 头不被接受 | 服务端要求同时接受 SSE；确认用的是官方端点 |
| 握手超时（无响应） | 地址可达但不是 MCP，或防火墙拦截 | 换官方端口试；关掉中间的反向代理 |
| 工具数是 3 但 Toolset 为 0 | 工具集插件没启用 | 启用工具集插件 → `RefreshTools` → 重连 |
| `list_toolsets` 返回空 | 同上 | 同上（注意：工具数恒为 3，**不能**用它判断是否正常） |
| 「未知工具或参数」 | 工具集变了，schema 过期 | 重跑 `describe_toolset`，用它的原始 schema 和确切参数 |
| 新工具 schema 是旧的 | 未刷新 | `RefreshTools` + 重连；新增 `UFUNCTION` 需**重启编辑器** |
| 调用挂起 / 时断时续 | 着色器、C++ 或蓝图正在编译；或 PIE 在跑 | 等状态稳定再调，别并发 |
| 调用互相打架 | 并发调用 | **串行化所有 UE 调用**，包括只读查询 |
| 最终文字对但无编辑器证据 | 模型在臆测 | 当作**未验证**，去回读目标状态 |
| DSH 里根本看不到工具 | 配置没落位 / 没重启 | 跑 doctor 第 5 项，重启 DSH |
| 编辑器重启后工具没了 | 连接已断 | 本插件默认开启 `reconnect`，等它自动重连；或重启 DSH |

---

## 端口冲突

UE 里执行 `ModelContextProtocol.StartServer 8123`，然后把
`cordis.patch.yml` 的 `url` 改成 `http://127.0.0.1:8123/mcp`。

查谁占了端口：

```powershell
Get-NetTCPConnection -LocalPort 8000 -ErrorAction SilentlyContinue |
  Select-Object LocalAddress,LocalPort,State,OwningProcess
```

```powershell
Get-Process -Id <OwningProcess>
```

---

## 工具太少或太多

**太少** → 去 Plugins 里启用更多 Toolset，然后 `RefreshTools`。

**太多**（>80）→ 每个工具定义都会占用每次请求的 token。
只留当前需要的 Toolset。参考数量级：

| 工具数 | 影响 |
|---|---|
| < 40 | 舒适 |
| 40–80 | 可接受，注意上下文预算 |
| > 80 | 明显拖慢并变贵，应精简或改用 Tool Search |

---

## 连接是好的，但操作没生效

UE 的多数修改操作是**异步**的。调用返回只代表**请求已受理**，不代表已完成。

正确姿势：

1. 改
2. **回读**目标状态
3. 对比期望值
4. 不一致就查编译状态 / 错误列表 / 资源是否还在加载

**别直接重试。** 先查清楚到底是 0 个、1 个还是多个。
非幂等操作（spawn / duplicate / create / rename）盲目的重试会造出重复资产，
清理起来比重新做还麻烦。

---

## 状态混乱了怎么办

**停下，报告，不要自己"顺手清理"。**

清理本身是一次**独立的修改操作**，需要独立授权。
在没搞清楚当前实际状态前做任何删除，都可能让情况更糟。

告诉用户：

- 你原本想做什么
- 实际观察到什么（附工具返回的原始证据）
- 你认为现在处于什么状态
- 建议的恢复步骤，以及每一步的影响

---

## DSH 侧：配置合并出错

`cordis.patch.yml` 要**合并** `plugins:` 段，不是整文件替换。
若两个条目用了同一个 `serverName`，DSH 会在加载时**明确报错**（这是有意的，防止静默重命名工具）。

校验配置是否被 DSH 接受：

```bash
dsh --dump-config
```

找 `mcp-unreal` 和它的 `url` 是否出现在合成结果里。

---

## 还是不通

收集这些信息再提问：

1. `node ue5-dsh-doctor.mjs` 的完整输出
2. UE Output Log 里 `ModelContextProtocol` 相关的行
   （可先 `Log LogModelContextProtocol Verbose` 提高详细度）
3. UE 版本号
4. `dsh --dump-config` 里 `mcp-unreal` 那一段

判断责任归属：

- 换个**非 UE** 的 MCP server 也复现同样的失败 → 是 DSH 或 MCP 客户端的问题，
  给它们记最小复现
- 只有 UE 端点失败 → 是 UE 侧或本插件配置的问题
