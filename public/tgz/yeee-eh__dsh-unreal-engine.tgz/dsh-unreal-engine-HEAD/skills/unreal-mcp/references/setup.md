# UE 侧准备（详细）

## 版本要求

| UE 版本 | 官方 MCP | 本插件支持 |
|---|---|---|
| 5.8+ | ✅ 内置 `ModelContextProtocol` | ✅ 直接支持 |
| 5.3–5.7 | ❌ 无 | ⚠️ 需改用第三方 MCP server（见文末） |
| 5.2 及以下 | ❌ | ❌ 不建议 |

确认版本：编辑器 **Help → About Unreal Editor**。

---

## 第一步：启用插件

1. **Edit → Plugins**
2. 搜索 `ModelContextProtocol`
3. 勾选 **Enabled**
4. **重启编辑器**（必须）

若搜索不到：

- 确认版本确实是 5.8+
- 检查是否被项目级 `.uproject` 的插件限制禁用
- 编辑器安装不完整时该插件可能缺失，用 Epic Launcher 校验一次安装

---

## 第二步：启动 MCP 服务

打开 **Window → Output Log**，在命令行输入框执行：

```
ModelContextProtocol.StartServer
```

期望看到类似日志：

```
LogModelContextProtocol: Created new HttpListener for 127.0.0.1:8000/mcp
```

**把端口和路径记下来**，DSH 配置里的 `url` 必须完全一致。

### 可用的控制台命令

| 命令 | 作用 |
|---|---|
| `ModelContextProtocol.StartServer [port]` | 启动服务，可指定端口 |
| `ModelContextProtocol.StopServer` | 停止并关闭所有连接 |
| `ModelContextProtocol.RefreshTools` | 插件或工具集变化后重新轮询注册表 |
| `ModelContextProtocol.GenerateClientConfig <Client\|All>` | 生成其他客户端的配置（DSH 不用，我们用本插件） |
| `Log LogModelContextProtocol Verbose` | 打开详细日志，排查时有用 |

### 启动时自动开服（可选）

不想每次手动敲命令，可以用启动参数：

```
-ModelContextProtocolStartServer -ModelContextProtocolPort=8000
```

在编辑器的快捷方式目标后面追加，或写进项目配置。

---

## 第三步：启用需要的 Toolset

UE 的 MCP 工具是按 **Toolset（工具集）** 分组注册的。
默认可能只开了一部分，表现为「能连上但工具很少」。

在 Plugins 里检查并启用你需要的工具集插件，然后：

```
ModelContextProtocol.RefreshTools
```

> ⚠️ **新增的 `UFUNCTION` 声明需要重启编辑器**，只跑 `RefreshTools` 不够。

### 关于工具数量

每个工具的定义都会**占用每一次模型请求的 token**。
如果暴露了 400+ 个工具，光工具定义就可能压垮上下文，既慢又贵。

**建议只启用当前工作真正需要的 Toolset。**
若 UE 版本提供 Tool Search（渐进式暴露），优先用它而不是全量 `AllToolsets`。

---

## 第四步：验证

```bash
node ue5-dsh-doctor.mjs
```

全绿之后重启 DSH。

---

## ⚠️ 安全

**官方 MCP 默认只监听 loopback，且没有任何鉴权层。**

- **不要**把端口暴露到公网或局域网
- **不要**设成 `0.0.0.0`
- 不要在前面挂反向代理转发到外部
- 能访问该端口的人 = 能完全控制你的编辑器（含执行 Python）

DSH 的审批门禁是这里唯一的护栏，**不要关闭它**。

---

## 备选：UE 5.3–5.7（无官方 MCP）

官方 MCP 是 5.8 才有的。若你被版本卡住，两条路：

### A. Remote Control API + 编辑器 Python（无需编译 C++）

UE 5.3+ 自带 **Remote Control** 插件，走 HTTP（默认 `30010`），
配合编辑器内置 Python 可以做到大部分操作。社区有现成实现，例如
[unreal-engine-mcp](https://github.com/FFZackFair92/unreal-engine-mcp)。

配置改成 stdio 形态即可：

```yaml
- id: mcp-unreal
  name: '@deepseek-ai/dsh-mcp-client'
  config:
    serverName: unreal
    transport: stdio
    command: npx
    args: ['-y', 'unreal-engine-mcp']
    toolCallTimeoutMs: 600000
```

**代价**：工具覆盖面、稳定性、维护活跃度都不如官方版，
且 Remote Control 的能力边界比 MCP 窄。

### B. 自己写 C++ 编辑器插件

控制力最强，但要承担 UE 编译迭代成本。只有 A 明显不够时才走。

> ⚠️ 注意：`/mcp` 和 Remote Control 的 `/remote/object/call` **不是同一个端点**。
> 填错会得到 404 或 405，doctor 会明确指出。
