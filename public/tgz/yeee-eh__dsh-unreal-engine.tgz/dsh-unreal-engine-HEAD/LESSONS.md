# 事故复盘：这次开发踩过的 14 个 bug

按「谁的错」分三类，因为**每一类都对应一条 DSH 的认知**。
开发过程：从零做一个 DSH ↔ UE5 的插件（`dsh-unreal-engine`），约 3 天。

> 文中出现的 `$env:DSH_HOME` 指 DSH 配置根目录（通常 `C:\Users\<你>\.dsh`），
> 普通 PowerShell 里可能是空的 —— 详见 [README.md](README.md#命令里的两个占位符)。

---

# 一、DSH 的机制陷阱（不是 bug，是设计，但会咬人）

## 1. 挂载新插件不用 `- insert:` 会**静默跳过**

写成顶层插件行：

```yaml
- id: mcp-unreal          # ✘ 什么都不会发生
  name: '@deepseek-ai/dsh-mcp-client'
```

DSH 只打印 `patch: entry "mcp-unreal" not found`，然后**跳过它**。

**机制**（`dsh-app-boot/lib/index.js` 的 `applyEntryPatches`）：

```
有 insert 字段？ → 追加（没有 id 时加到顶层）
没有 insert    ？ → 按 id 找【已有行】改配置，找不到就警告并跳过
```

> **教训**：挂载**新**插件必须用 `- insert:` 嵌套形态。
> 这是**静默失败** —— 不报错退出，你以为配好了，实际什么都没发生。

## 2. `--dump-config` **不验证**任何东西

它只合成配置，**不 import 包、不求值 `!!js`**，更不会启动。

曾经把「dump-config 通过」当成「能启动」，结果用户打不开 DSH、修了一天。

> **教训**：真实验证只有两种 ——
> ① `dsh --profile sdk` 能安静退出（exit 0、无输出）
> ② 界时启动 + 真发一个 HTTP 请求

## 3. home 级补丁对**所有 profile** 生效，但包按 **profile** 解析

home 补丁装了一次，`web` 能用，`sdk` profile 报 `Cannot find package`。

> **教训**：需要跨 profile 的包放 `profiles/node_modules`（共享层），
> 而不是 `profiles/web/node_modules`。

## 4. 访问未声明的服务**抛异常**，写进 `inject` 又**挂起**

| 写法 | 结果 |
|---|---|
| 直接读 `ctx.webServer` | `cannot get property "webServer" without inject` |
| `inject: ['webServer']` | 在 sdk profile 永远 `pending` → `1 entry did not activate`，整树加载失败 |

> **教训**：可选依赖用 `ctx.inject(['webServer'], cb)` —— 服务出现才回调，不出现安静跳过。

## 5. 浏览器半和 Node 半是**两套完全不同的机制**

把客户端 bundle 当 Node 插件挂，得到
`invalid plugin, expect function or object with an "apply" method`。

| | Node 半 | 浏览器半 |
|---|---|---|
| 形态 | ESM 导出 `apply` | `window.__ModuleLoader__.load({id, factory})` |
| 怎么挂 | `- insert:` 一行 | **什么都不写** |
| 怎么被发现 | loader 条目 | `package.json` 的 `dsh.client` 声明 |
| 依赖怎么来 | `import` | `factory(require)` 从**冻结模块表**解析 |

## 6. `load({ id })` 必须**等于包名**

写成 `dsh-unreal-engine-client`，前端报：

```
bundle /plugins/…/client.js loaded without registering "dsh-unreal-engine"
   via __ModuleLoader__.load
```

**这句话很精确** —— 加载成功了，只是注册的名字对不上，名册匹配不到。

> **教训**：注册 id、导出的 `name`、包名，三者必须一致。
> 已加契约测试（`lib/client-bundle.test.mjs`）在本地拦住这类错误。

## 7. 「代码里有」≠「功能生效」（两次踩到）

| 函数 | 状态 |
|---|---|
| `reconcileProfilePlugins` | 有完整实现、被导出，但**在 0.1.5-rc 里从未被调用** |
| `!!js` 求值 | 文档说是表达式，实际是 `new Function("ctx","expr",...)` —— **同步、只有 ctx、没有 import** |

> **教训**：读源码，别读文档标题。第二个是真读了 `cordis-plugin-loader/lib/index.js:289` 才确认的。

---

# 二、实质代码 bug

## 8. `!!js` 里写了 `await import('file:///...')`

为了让 mcp 行的 url 动态读设置文件，在 YAML 里塞了动态 import。
**求值同步 → 直接崩。**

这也是用户看到的「mcp-unreal 配置里有 import 语法」。

## 9. 引用了一个**已不存在的包名**

`probe.mjs` 写 `@modelcontextprotocol/sdk/client/index.js`（v1 路径）。实际：

```
dsh-mcp-client 用的是 "@modelcontextprotocol/client"   ← v2.0.0，改名 + 拆成 client/core
```

**这个 bug 只在「干净环境装 tarball」时才暴露** —— 开发机上 v2 包在 npx 缓存里，
能被其它路径解析到，所以本地一直测不出来。**如果直接发出去，别人装上探测永远是坏的。**

**修法**：写 `lib/mcp-client-loader.mjs`，按「包名 × 子路径 × 解析根」逐个尝试。
关键突破是发现 **`process.argv[1]` 指向 DSH 自己的 `bin.js`** ——
顺着它向上就能找到 npx 缓存的 `node_modules`。

## 10. 自作聪明的「防呆守卫」反而是故障源

在客户端 bundle 顶部加了：

```js
if (typeof window === 'undefined' || typeof window.__ModuleLoader__?.load !== 'function') {
  console.error(...)      // ← 什么都没注册
} else {
  window.__ModuleLoader__.load({...})
}
```

守卫一旦命中就**什么都不注册**，而报错只说「没有注册」，**完全不指向真因**。
更糟的是它给的提示还是**错的**（教用户加客户端 loader 行 —— 那正是会导致插件树崩掉的做法）。

> **教训**：样板里都没有的「贴心设计」，很可能是负担。删掉它问题就解决了。

## 11. 迁移时 `pnpm remove` 留下**断链 junction**

```
profiles/node_modules/@modelcontextprotocol/sdk
   → Junction → npx缓存\...\sdk    ← 目标不存在
```

目录在、指向空。`require.resolve` 报 `MODULE_NOT_FOUND`，但 `Test-Path` 说存在。
现在没造成故障（v2 包从别的路径解析得到），但它是垃圾，且极具误导性。

---

# 三、工具误用（不是 DSH 的问题）

## 12. 沙箱策略来回切换

期间 `workspace-write` 与 `danger-full-access` 切了几次，有两次写
`$env:DSH_HOME\...` 被拦：

```
SetNamedSecurityInfoW failed (Win32 5): grantWrite(<工作区>)
```

**这是沙箱按设计工作** —— `workspace-write` 只允许写会话工作区。

> Windows 上如果遇到**意料之外**的沙箱拒绝（工作区写入/列目录失败，
> 或本该可读的路径读不到），DSH 有技能 `diagnose-windows-sandbox-acl`
> 可以一次跑完诊断并修复 ACL 问题。**本例是意料之中的限制，不适用。**

## 13. 自己的检查脚本报假阳性

用 `-match 'mcp-unreal'` 数行数 —— **子串匹配**把
`name: '@deepseek-ai/dsh-mcp-client'` 也算进去了，于是误判「有重复 id」。

> 同一个毛病后来在 `ue5-dsh-doctor.mjs` 里又犯了一次（见第 14 条）。

## 14. doctor 的配置检查会**命中注释文本**

```js
if (text.includes('mcp-unreal') || text.includes('dsh-mcp-client')) { ok('已配置') }
```

`text.includes` 不区分注释与有效配置。排查问题时把整块配置注释掉后，
**注释文本里仍然含有这些字符串** → doctor 报「已配置 ✅」。

**一个正好在最需要它的时候骗人的假阳性。**

**修法**（`ue5-dsh-doctor.mjs`）：先剥掉 YAML 注释再判断，并且把检查目标
从「home 补丁里有没有 insert」改成「profile 的 bundles 里有没有登记」
（架构已迁移，旧检查目标过时了）。

---

# 四条给 DSH 使用者的经验

| # | 经验 |
|---|---|
| 1 | **改 `cordis.patch.yml` 前必须备份**。而且 `$env:DSH_HOME` 在普通 PowerShell 里**是空的**（DSH 子进程内部注入），要用绝对路径 |
| 2 | **`--dump-config` 不是验证**。`dsh --profile sdk` 能安静退出才是 |
| 3 | **静默失败比报错危险**。`- insert:` 缺失、bundles 没登记，都是「看着没事其实没跑」 |
| 4 | **注释 `- insert:` 块时，缩进的子行必须一起注释**，否则 YAML 解析失败 = 又一次打不开 |

---

# 贯穿全程的一条方法论

> **把「配置看起来对」和「真的能跑」严格分开。**
>
> 这次 14 个 bug 里，有 5 个（第 1/2/3/8/9 条）的共同形态是：
> **某个环节「通过了」一个其实不验证任何东西的检查。**
>
> 所以现在这个项目的验证顺序是：
> ① 语法检查 → ② 单元测试 → ③ `dsh --profile sdk` 安静退出 →
> ④ 界时启动 → ⑤ 真发 HTTP 请求 →
> ⑥（客户端）mock `window.__ModuleLoader__` 执行 bundle，断言注册 id
