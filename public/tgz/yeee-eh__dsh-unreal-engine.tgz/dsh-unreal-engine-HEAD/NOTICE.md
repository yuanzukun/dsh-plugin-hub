# 第三方组件说明

本软件包（`dsh-unreal-engine`）本身以 [MIT 许可](LICENSE) 发布，
**不包含任何 Epic Games 或 DeepSeek 的代码**。

它只提供配置、文档与诊断脚本，用于把两者各自**已发布**的组件连接起来：

| 组件 | 提供方 | 许可 |
|---|---|---|
| Unreal Engine 的 `ModelContextProtocol` 插件 | Epic Games | [Unreal Engine EULA](https://www.unrealengine.com/eula)（含第 6(e) 节关于 LLM 训练输入的规定） |
| `@deepseek-ai/dsh-mcp-client` | DeepSeek | MIT |
| `@modelcontextprotocol/client`（或旧版 `@modelcontextprotocol/sdk`） | Anthropic / MCP 项目 | MIT |

## 这意味着什么

- 使用本软件包**不改变**上述任一组件的许可条款
- 你仍需自行遵守 Unreal Engine EULA —— 特别是 UE 官方 MCP 插件启动时会打印一条警告：
  通过它传给 LLM 的数据属于 UE EULA 定义的 **Licensed Technology**，
  你有责任确保所连接的 LLM 提供方不会把它用作训练输入
- 本包的 `package.json` **刻意没有 `dependencies`**：`react` 由 DSH 客户端模块系统提供，
  MCP SDK 随 DSH 自带。这样既避免重复安装，也避免把第三方代码打进本包

## 商标

Unreal、Unreal Engine 是 Epic Games, Inc. 的商标。
DeepSeek、DeepSeek Harness 是 DeepSeek 的商标。
本项目为第三方集成，与上述公司**无隶属或背书关系**。
