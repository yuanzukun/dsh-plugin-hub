/**
 * dsh-unreal-engine — 浏览器侧设置页
 *
 * 在「设置」里新增一个分区：「虚幻引擎」。
 * 可自动探测 UE 的 MCP 端点，探测不到时允许手动粘贴日志行或填端口。
 * 保存与探测都通过宿主侧注册的 /unreal-engine/* 精确路由完成。
 *
 * ---------------------------------------------------------------------------
 * 为什么是这个文件形态（重要）
 * ---------------------------------------------------------------------------
 * DSH 的客户端插件不是普通 ESM 模块，而是「动态 bundle」。
 * 依据 @deepseek-ai/dsh-client-modules 的约定：
 *
 *   - shell 预置一张**冻结的模块表**（PLATFORM_MODULES：React、Cordis、
 *     以及静态 UI 库），每个动态 bundle 的 external 都**只对这张表解析**；
 *   - 执行 bundle 只注册 factory，模块副作用在**物化时**才运行；
 *   - factory 拿到一个同步 `require`，用它取外部依赖。
 *
 * 所以客户端半侧必须是 window.__ModuleLoader__.load({ id, factory }) 形态，
 * 且 `require('react')` 必须写在 **factory 内部**（模块体里调用会太早）。
 * 手写源码不能直接 `import 'react'` —— 那样解析不到，且会拿到第二个 React 实例
 * 导致 hooks 崩溃。
 *
 * 注册形态（settings.section + locale.register + slots.inject）
 * 对照 dshmarket / dsh-ui-appearance / dsh-better-sidebar 的编译产物写成。
 *
 * ⚠️ 两个已经踩过、会直接让前端报「加载插件失败」的点：
 *
 *   1) `load({ id })` 必须是【包名】即 'dsh-unreal-engine'。
 *      写成别的（例如 'dsh-unreal-engine-client'）会导致报错：
 *        bundle …/client.js loaded without registering "dsh-unreal-engine"
 *         via __ModuleLoader__.load
 *      即：加载成功了，但注册的名字对不上 → 门册匹配不上。
 *
 *   2) 不要在这里加「如果不是浏览器环境就跳过」之类的守卫。
 *      试过，结果是：一旦守卫命中就什么都不注册，而报错信息只会说
 *      「没有注册」，完全不指向真正原因，极难排查。
 *      样板里都没有这种守卫 —— 无条件调用才是对的。
 */

window.__ModuleLoader__.load({
  id: 'dsh-unreal-engine',
  factory: (require) => {
    const module = { exports: {} };
    const exports = module.exports;

    // ---- 外部依赖：全部从 shell 的冻结模块表解析 ----
    const reactMod = require('react');
    const React = reactMod?.default ?? reactMod;

    // -------------------------------------------------------------------------
    // 常量
    // -------------------------------------------------------------------------

    const NS = 'unreal-engine';
    const ROUTE_CONFIG = '/unreal-engine/config';
    const ROUTE_DETECT = '/unreal-engine/detect';

    // -------------------------------------------------------------------------
    // 宿主通信
    // -------------------------------------------------------------------------

    /** 调宿主路由。同源 fetch，认证 cookie 由浏览器自动带上。 */
    async function callHost(path, body, timeoutMs = 30000) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const res = await fetch(path, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(body ?? {}),
          credentials: 'same-origin',
          signal: controller.signal,
        });
        const text = await res.text();
        let json;
        try {
          json = JSON.parse(text);
        } catch {
          throw new Error(`宿主返回了非 JSON 响应（HTTP ${res.status}）`);
        }
        if (!res.ok || json?.ok === false) {
          throw new Error(json?.error ?? `请求失败（HTTP ${res.status}）`);
        }
        return json;
      } catch (err) {
        if (err?.name === 'AbortError') throw new Error('请求超时：宿主没有及时响应');
        throw err;
      } finally {
        clearTimeout(timer);
      }
    }

    // -------------------------------------------------------------------------
    // 样式（内联，不依赖任何外部类名）
    // -------------------------------------------------------------------------

    const BORDER = 'var(--dsw-alias-border-secondary, rgba(127,127,127,0.4))';

    const S = {
      wrap: { display: 'flex', flexDirection: 'column', gap: '18px', maxWidth: '760px' },
      card: {
        border: `1px solid ${BORDER}`,
        borderRadius: '10px',
        padding: '16px',
        display: 'flex',
        flexDirection: 'column',
        gap: '12px',
      },
      h: { margin: 0, fontSize: '15px', fontWeight: 600 },
      p: { margin: 0, fontSize: '13px', lineHeight: 1.6, opacity: 0.75 },
      row: { display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' },
      input: {
        flex: '1 1 320px',
        minWidth: '240px',
        padding: '8px 10px',
        fontSize: '13px',
        fontFamily: 'inherit',
        color: 'inherit',
        background: 'transparent',
        border: `1px solid ${BORDER}`,
        borderRadius: '8px',
      },
      textarea: {
        width: '100%',
        minHeight: '64px',
        padding: '8px 10px',
        fontSize: '12px',
        fontFamily: 'ui-monospace, SFMono-Regular, Consolas, monospace',
        color: 'inherit',
        background: 'transparent',
        border: `1px solid ${BORDER}`,
        borderRadius: '8px',
        resize: 'vertical',
      },
      btn: {
        padding: '8px 14px',
        fontSize: '13px',
        fontFamily: 'inherit',
        cursor: 'pointer',
        color: 'inherit',
        background: 'transparent',
        border: `1px solid ${BORDER}`,
        borderRadius: '8px',
      },
      btnPrimary: {
        padding: '8px 14px',
        fontSize: '13px',
        fontFamily: 'inherit',
        cursor: 'pointer',
        border: 'none',
        borderRadius: '8px',
        background: 'var(--dsw-alias-brand-primary, #4d6bfe)',
        color: '#fff',
      },
      mono: { fontFamily: 'ui-monospace, SFMono-Regular, Consolas, monospace', fontSize: '12px' },
      ok: { color: 'var(--dsw-alias-status-success, #2e9e5b)', fontSize: '13px', lineHeight: 1.6 },
      err: { color: 'var(--dsw-alias-status-danger, #d94a4a)', fontSize: '13px', lineHeight: 1.6 },
      muted: { fontSize: '12px', opacity: 0.6 },
    };

    // -------------------------------------------------------------------------
    // 工具
    // -------------------------------------------------------------------------

    /** 把探测成功的结果整理成一句人话 + 细节。 */
    function describeSuccess(res, tried) {
      const bits = [];
      if (Number.isInteger(res?.toolsetCount)) bits.push(`${res.toolsetCount} 个 Toolset 可用`);
      if (Array.isArray(res?.tools) && res.tools.length) {
        bits.push(`meta 工具：${res.tools.join(', ')}`);
      }
      if (res?.protocolVersion) bits.push(`协议 ${res.protocolVersion}`);
      if (Number.isInteger(tried) && tried > 1) bits.push(`（第 ${tried} 个端口命中）`);
      return bits.join('　·　');
    }

    // -------------------------------------------------------------------------
    // 主组件
    // -------------------------------------------------------------------------

    function UnrealEngineSection(props) {
      const t = props?.t ?? ((k) => k);

      const [config, setConfig] = React.useState(null);
      const [manual, setManual] = React.useState('');
      const [status, setStatus] = React.useState(null);
      const [busy, setBusy] = React.useState(false);
      const [showManual, setShowManual] = React.useState(false);

      // 首次挂载：读当前配置
      React.useEffect(() => {
        let alive = true;
        callHost(ROUTE_CONFIG, { action: 'get' })
          .then((r) => {
            if (!alive) return;
            setConfig(r.config);
            setManual(r.config?.url ?? '');
          })
          .catch((err) => {
            if (alive) setStatus({ kind: 'err', text: `读取配置失败：${err.message}` });
          });
        return () => {
          alive = false;
        };
      }, []);

      const runDetect = React.useCallback(async () => {
        setBusy(true);
        setStatus({ kind: 'busy', text: '正在扫描本机 8000 起的端口…' });
        try {
          const r = await callHost(ROUTE_DETECT, {}, 60000);
          const res = r.result ?? {};
          if (r.mode === 'scan' && r.found) {
            setConfig((c) => ({ ...(c ?? {}), url: r.result.url, port: r.result.port }));
            setManual(r.result.url);
            setStatus({
              kind: 'ok',
              text: `探测成功：${r.result.url}`,
              detail: describeSuccess(res, r.tried),
            });
          } else if (r.mode === 'single') {
            if (res.ok) {
              setConfig((c) => ({ ...(c ?? {}), url: res.url }));
              setStatus({ kind: 'ok', text: `连接成功：${res.url}`, detail: describeSuccess(res) });
            } else {
              setStatus({ kind: 'err', text: res.message ?? '连接失败', detail: res.code });
            }
          } else {
            setStatus({
              kind: 'err',
              text: `扫描了 ${r.tried} 个端口都没找到 UE 的 MCP 服务。`,
              detail:
                '请确认：① 编辑器已打开 ② Output Log 里执行过 ModelContextProtocol.StartServer ' +
                '③ 若端口不在扫描范围，切到「手动输入」。最后一次报错：' +
                (res?.message ?? '无'),
            });
          }
        } catch (err) {
          setStatus({ kind: 'err', text: err.message });
        } finally {
          setBusy(false);
        }
      }, []);

      const testManual = React.useCallback(async () => {
        if (manual.trim() === '') {
          setStatus({ kind: 'err', text: '请先粘贴日志行或填入端口号。' });
          return;
        }
        setBusy(true);
        setStatus({ kind: 'busy', text: '正在用这段内容连接…' });
        try {
          const r = await callHost(ROUTE_DETECT, { url: manual }, 30000);
          const res = r.result ?? {};
          if (res.ok) {
            setConfig((c) => ({ ...(c ?? {}), url: res.url, port: res.port }));
            setManual(res.url);
            setStatus({ kind: 'ok', text: `连接成功：${res.url}`, detail: describeSuccess(res) });
          } else {
            setStatus({ kind: 'err', text: res.message ?? '连接失败', detail: res.code });
          }
        } catch (err) {
          setStatus({ kind: 'err', text: err.message });
        } finally {
          setBusy(false);
        }
      }, [manual]);

      const savedUrl = config?.url ?? '（读取中…）';

      return React.createElement(
        'div',
        { style: S.wrap },

        // ---- 当前配置 ----
        React.createElement(
          'div',
          { style: S.card },
          React.createElement('h3', { style: S.h }, t('current')),
          React.createElement(
            'div',
            { style: S.row },
            React.createElement('span', { style: S.muted }, 'MCP 端点'),
            React.createElement('code', { style: S.mono }, savedUrl),
          ),
          React.createElement(
            'p',
            { style: S.p },
            'DSH 启动时用这个地址连接 UE 5.8 内置的 MCP 服务。修改后需要重启 DSH 才会生效。',
          ),
        ),

        // ---- 自动探测 ----
        React.createElement(
          'div',
          { style: S.card },
          React.createElement('h3', { style: S.h }, t('detect')),
          React.createElement(
            'p',
            { style: S.p },
            '从 8000 端口开始逐个尝试真正的 MCP 握手（UE 5.8 默认端口就是 8000），' +
              '找到第一个能握手成功的服务。需要 UE 编辑器已打开并已启动 MCP 服务。',
          ),
          React.createElement(
            'div',
            { style: S.row },
            React.createElement(
              'button',
              { type: 'button', style: S.btnPrimary, disabled: busy, onClick: runDetect },
              busy ? t('working') : t('autoDetect'),
            ),
            React.createElement(
              'button',
              {
                type: 'button',
                style: S.btn,
                disabled: busy,
                onClick: () => setShowManual((v) => !v),
              },
              showManual ? t('hideManual') : t('showManual'),
            ),
          ),
        ),

        // ---- 手动输入 ----
        showManual &&
          React.createElement(
            'div',
            { style: S.card },
            React.createElement('h3', { style: S.h }, t('manual')),
            React.createElement(
              'p',
              { style: S.p },
              '把 UE Output Log 里的这一行整个粘进来即可，端口会被自动识别：',
            ),
            React.createElement(
              'code',
              { style: { ...S.mono, opacity: 0.7, wordBreak: 'break-all' } },
              'LogModelContextProtocol: Starting MCP server on port 8000 (override with -ModelContextProtocolPort=N)',
            ),
            React.createElement('textarea', {
              style: S.textarea,
              value: manual,
              placeholder: '粘贴日志行，或直接填端口号（例如 8000）',
              onChange: (e) => setManual(e.target.value),
              spellCheck: false,
            }),
            React.createElement(
              'div',
              { style: S.row },
              React.createElement(
                'button',
                { type: 'button', style: S.btnPrimary, disabled: busy, onClick: testManual },
                busy ? t('working') : t('testAndSave'),
              ),
            ),
          ),

        // ---- 结果 ----
        status &&
          React.createElement(
            'div',
            {
              style: {
                ...S.card,
                borderColor:
                  status.kind === 'ok'
                    ? 'var(--dsw-alias-status-success, #2e9e5b)'
                    : status.kind === 'err'
                      ? 'var(--dsw-alias-status-danger, #d94a4a)'
                      : undefined,
              },
            },
            React.createElement('h3', { style: S.h }, t('result')),
            React.createElement(
              'div',
              { style: status.kind === 'ok' ? S.ok : status.kind === 'err' ? S.err : S.p },
              status.text,
            ),
            status.detail &&
              React.createElement('div', { style: { ...S.p, ...S.mono } }, status.detail),
          ),
      );
    }

    // -------------------------------------------------------------------------
    // 本地化
    // -------------------------------------------------------------------------

    const zh = {
      nav: '虚幻引擎',
      current: '当前配置',
      detect: '自动探测',
      autoDetect: '自动探测并保存',
      working: '处理中…',
      showManual: '手动输入',
      hideManual: '收起手动输入',
      manual: '手动指定端点',
      testAndSave: '测试并保存',
      result: '结果',
    };

    const en = {
      nav: 'Unreal Engine',
      current: 'Current configuration',
      detect: 'Auto-detect',
      autoDetect: 'Auto-detect and save',
      working: 'Working…',
      showManual: 'Enter manually',
      hideManual: 'Hide manual entry',
      manual: 'Specify endpoint manually',
      testAndSave: 'Test and save',
      result: 'Result',
    };

    // -------------------------------------------------------------------------
    // 插件导出
    // -------------------------------------------------------------------------

    // 客户端半侧的插件名必须与【包名】一致，
    // 否则前端名册匹配不上（见文件头说明）。
    const name = 'dsh-unreal-engine';
    const inject = ['slots', 'locale'];

    function apply(ctx) {
      ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'unreal-engine: settings dictionaries');

      const t = ctx.locale.bind(NS);

      ctx.slots.inject('settings.section', () =>
        ctx.slots.register(
          {
            name: 'settings.section',
            id: 'unreal-engine',
            // 排在市场（40）之后，避免抢占已有分区位置
            order: 60,
            label: () => t('nav'),
            locale: NS,
            inject: () => ({ t }),
          },
          UnrealEngineSection,
        ),
      );
    }

    // 与样板一致：导出挂在 module.exports 上
    Object.assign(exports, { name, inject, apply, __esModule: true });
    return module.exports;
  },
});
