# 更新日志

本文件记录所有值得注意的变更。
格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [Unreleased]

### 修复

- **让 GitHub 正确识别 MIT 许可证**：原先 `LICENSE` 在 MIT 正文后附加了中文说明，
  导致 GitHub 的许可证识别器放弃解析（仓库侧栏不显示 license 徽章、
  按「MIT 许可」搜索时找不到本项目）。现拆分为：
  - `LICENSE` —— 纯 MIT 正文（逐字标准模板）
  - `NOTICE.md` —— 第三方组件归属、UE EULA 注意事项、商标声明

### 变更

- `LICENSE` 的版权行由 `ue5-dsh-plugin contributors` 改为 `yeee-eh`

## [0.1.0] — 2026-09-29

首个可用版本。**在 Windows + DSH 0.1.5-rc.2 + UE 5.8.2 上端到端验证通过。**

### 新增

- **设置页**（DSH 设置 → 虚幻引擎）
  - 自动探测：从 8000 端口起逐个尝试真正的 MCP 握手，不是只探端口
  - 手动输入：探测失败时可粘贴 UE Output Log 整行，或直接填端口号
  - 结果展示：Toolset 数量、meta 工具名、协议版本（都来自真实握手）
- **宿主路由**
  - `POST /unreal-engine/config` —— 读 / 写端点配置
  - `POST /unreal-engine/detect` —— 自动探测 / 单点测试
- **诊断脚本** `tools/ue5-dsh-doctor.mjs` —— 5 段链路逐项检查，零依赖
- **UE 操作规范** `skills/unreal-mcp/` —— 渐进式工具发现用法、风险分级、安全边界
- **文档**
  - `README.md` —— 安装 / 卸载 / 分发 / 架构 / 已知限制
  - `RECOVERY.md` —— 应急恢复卡（DSH 打不开时看这个）
  - `MIGRATION.md` —— junction → 标准安装的迁移手册
  - `LESSONS.md` —— 14 个 bug 的完整复盘 + DSH 机制认知

### 设计取舍

- **走 bundle 频道**（对齐 `dshmarket`）：插件自带 `cordis.patch.yml` 负责挂载，
  用户的 `~/.dsh/cordis.patch.yml` 保持为空 —— 卸载不需要动用户文件
- **零 `dependencies`**：`react` 由客户端模块系统的冻结模块表提供（避免第二份 React 实例），
  `@modelcontextprotocol/sdk` 随 DSH 自带 —— 两者都标为 optional peer
- **MCP SDK 兼容新旧两代**：v1 的 `@modelcontextprotocol/sdk` 与 v2 的
  `@modelcontextprotocol/client`（拆出 `core`），并覆盖四种安装位置

### 已知限制

- 改设置需重启 DSH（MCP 客户端只在启动时连接，没有运行时重配接口）
- 设置页保存的值与 `mcp-unreal` 那行**不联动** —— 探测到非 8000 端口时需设
  `DSH_UNREAL_MCP_URL` 环境变量
- `dsh.profile.bundles` 需手动登记（DSH 的 `reconcileProfilePlugins` 在当前版本从未被调用）
- 客户端渲染未在浏览器里逐项点过（有 boot graph 证据 + 9 个契约测试）
- 仅支持 UE 5.8+（官方 MCP 是 5.8 引入的）

### 未做

- 卸载按钮（决定不做：命令行的 `pnpm remove` 已足够干净，且使用者通常会借助 AI 操作）
