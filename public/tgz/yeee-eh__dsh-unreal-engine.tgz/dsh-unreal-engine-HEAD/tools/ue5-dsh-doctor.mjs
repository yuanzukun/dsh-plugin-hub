#!/usr/bin/env node
/**
 * ue5-dsh-doctor — UE5 ↔ DeepSeek Harness 连通性诊断
 *
 * 零依赖：只用 Node 内置模块，不需要 npm install。
 * 直接跑：  node ue5-dsh-doctor.mjs
 *
 * 它按链路顺序逐段检查，第一个断点会明确告诉你是哪一段坏了。
 */

import process from 'node:process';
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';

// ---------------------------------------------------------------------------
// 配置：与 cordis.patch.yml 保持一致
// ---------------------------------------------------------------------------
const MCP_URL = process.env.DSH_UNREAL_MCP_URL ?? 'http://127.0.0.1:8000/mcp';
const HTTP_TIMEOUT_MS = Number(process.env.DSH_UNREAL_DOCTOR_TIMEOUT_MS ?? 8000);

// ---------------------------------------------------------------------------
// 输出小工具
// ---------------------------------------------------------------------------
const C = process.stdout.isTTY
  ? { r: '\x1b[31m', g: '\x1b[32m', y: '\x1b[33m', b: '\x1b[36m', d: '\x1b[2m', x: '\x1b[0m' }
  : { r: '', g: '', y: '', b: '', d: '', x: '' };

let failures = 0;

/** 第 5 项检查的结果：配置是否找到 / 是否写法有误（供结论段使用）。 */
let configFound = false;
let configBroken = false;

const ok = (m) => console.log(`${C.g}  PASS${C.x}  ${m}`);
const bad = (m) => { failures++; console.log(`${C.r}  FAIL${C.x}  ${m}`); };
const warn = (m) => console.log(`${C.y}  WARN${C.x}  ${m}`);
const info = (m) => console.log(`${C.d}        ${m}${C.x}`);
const head = (m) => console.log(`\n${C.b}${m}${C.x}`);

// ---------------------------------------------------------------------------
// MCP Streamable HTTP 最小客户端
//
// 协议要点：
//  - 请求：POST 到 /mcp，Content-Type: application/json
//  - Accept 必须同时包含 application/json 和 text/event-stream
//  - 响应可能是 JSON，也可能是 SSE（text/event-stream），两种都要解
//  - initialize 之后应发 notifications/initialized 完成握手
// ---------------------------------------------------------------------------
let rpcId = 0;
let sessionId = null;

function rpcFrame(method, params) {
  const frame = { jsonrpc: '2.0', id: ++rpcId, method };
  if (params !== undefined) frame.params = params;
  return frame;
}

/** 从 SSE 文本里抽出最后一个 JSON-RPC 响应对象。 */
function parseSseBody(text) {
  const out = [];
  for (const line of text.split(/\r?\n/)) {
    if (!line.startsWith('data:')) continue;
    const payload = line.slice(5).trim();
    if (!payload) continue;
    try { out.push(JSON.parse(payload)); } catch { /* 忽略非 JSON 的 keepalive */ }
  }
  return out;
}

async function post(body, { expectReply = true } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
  try {
    const headers = {
      'content-type': 'application/json',
      accept: 'application/json, text/event-stream',
    };
    if (sessionId) headers['mcp-session-id'] = sessionId;

    const res = await fetch(MCP_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
      signal: controller.signal,
    });

    // 服务端在 initialize 响应里回传会话 id，后续请求必须带上
    const sid = res.headers.get('mcp-session-id');
    if (sid) sessionId = sid;

    const ctype = res.headers.get('content-type') ?? '';
    const text = await res.text();

    if (!res.ok) {
      const e = new Error(`HTTP ${res.status} ${res.statusText}`);
      e.status = res.status;
      e.body = text.slice(0, 400);
      throw e;
    }
    if (!expectReply) return null;

    const messages = ctype.includes('text/event-stream') ? parseSseBody(text) : [JSON.parse(text)];

    // 匹配本次请求 id 的响应
    for (const msg of messages) {
      if (msg && msg.id === body.id) {
        if (msg.error) {
          const e = new Error(`JSON-RPC ${msg.error.code}: ${msg.error.message}`);
          e.rpc = msg.error;
          throw e;
        }
        return msg.result;
      }
    }
    // 没有精确匹配时退回最后一个
    const last = messages[messages.length - 1];
    if (last?.result) return last.result;
    throw new Error('响应中没有匹配的 JSON-RPC 结果');
  } finally {
    clearTimeout(timer);
  }
}

// ---------------------------------------------------------------------------
// 检查项
// ---------------------------------------------------------------------------
function checkNode() {
  head('1/5  Node 运行时');
  const major = Number(process.versions.node.split('.')[0]);
  if (major >= 20) ok(`Node ${process.versions.node}`);
  else bad(`Node ${process.versions.node} 过低，需要 >= 20（fetch 与 AbortSignal 依赖它）`);
  info(`MCP 端点：${MCP_URL}`);
}

async function checkReachability() {
  head('2/5  UE 端点可达性');
  let res;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
    try {
      // 用 GET 探活：MCP 规范下若服务端不支持 SSE 会返回 405，
      // 那也证明「有东西在监听」，是有效证据。
      res = await fetch(MCP_URL, {
        method: 'GET',
        headers: { accept: 'text/event-stream' },
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timer);
    }
  } catch (err) {
    const code = err?.cause?.code ?? err?.code ?? '';
    if (code === 'ECONNREFUSED') {
      bad(`连接被拒绝：${MCP_URL}`);
      info('UE 编辑器没运行，或没有执行 ModelContextProtocol.StartServer');
      info('详见 skills/unreal-mcp/references/setup.md 的「UE 侧准备」');
    } else if (err.name === 'AbortError') {
      bad(`连接超时（${HTTP_TIMEOUT_MS}ms）`);
      info('端口被防火墙拦截，或地址填错');
    } else {
      bad(`无法连接：${err.message}`);
    }
    return false;
  }

  if (res.status === 404) {
    bad(`HTTP 404 —— 地址可达但没有 MCP 服务`);
    info('路径大概率写错了。MCP 端点应以 /mcp 结尾，');
    info('不是 Remote Control 的 /remote/object/call 之类。');
    return false;
  }
  ok(`端点有响应（HTTP ${res.status}）`);
  try { res.body?.cancel?.(); } catch { /* 忽略 */ }
  return true;
}

async function checkHandshake() {
  head('3/5  MCP 握手');

  // initialize 是协议强制的第一步
  let result;
  try {
    result = await post({
      jsonrpc: '2.0',
      id: ++rpcId,
      method: 'initialize',
      params: {
        protocolVersion: '2025-06-18',
        capabilities: {},
        clientInfo: { name: 'ue5-dsh-doctor', version: '1.0.0' },
      },
    });
  } catch (err) {
    bad(`initialize 失败：${err.message}`);
    if (err.status === 406 || /406/.test(err.message)) {
      info('406 通常是 Accept 头不被接受——服务端要求同时接受 SSE。');
    }
    if (err.body) info(`响应片段：${err.body.replace(/\s+/g, ' ').slice(0, 200)}`);
    info('若返回 405/404，说明这不是 MCP 端点。');
    return null;
  }

  const si = result?.serverInfo ?? {};
  ok(`握手成功：${si.name ?? '(未命名)'} ${si.version ?? ''}`.trim());
  if (result?.protocolVersion) info(`协议版本：${result.protocolVersion}`);
  if (sessionId) info(`会话 id：${sessionId}`);

  // 完成握手的通知（无 id，不期待回复）
  try {
    await post({ jsonrpc: '2.0', method: 'notifications/initialized' }, { expectReply: false });
  } catch (err) {
    warn(`notifications/initialized 未确认（多数实现可忽略）：${err.message}`);
  }
  return result;
}

async function checkTools() {
  head('4/5  工具枚举');
  let result;
  try {
    result = await post({ jsonrpc: '2.0', id: ++rpcId, method: 'tools/list', params: {} });
  } catch (err) {
    bad(`tools/list 失败：${err.message}`);
    return 0;
  }

  const tools = result?.tools ?? [];
  if (tools.length === 0) {
    bad('服务端返回了 0 个工具');
    info('在 UE 编辑器里执行 ModelContextProtocol.RefreshTools，再重跑本脚本。');
    info('同时确认编辑器已启用 Toolset（工具集）相关插件。');
    return 0;
  }

  ok(`发现 ${tools.length} 个工具`);
  const names = tools.map((t) => t?.name).filter(Boolean).sort();
  for (const n of names.slice(0, 12)) info(`· ${n}`);
  if (names.length > 12) info(`… 另有 ${names.length - 12} 个`);

  // UE 的官方实现走「渐进式工具发现」：meta 工具恒定只有 3 个，
  // 真正的能力藏在 ToolsetRegistry 里。因此必须再查一层，
  // 否则「3 个工具」在工具集为空时也会显示为通过。
  const metaOnly = tools.length <= 3 && names.includes('list_toolsets');
  if (metaOnly) {
    info('');
    info('这是渐进式工具发现：3 个 meta 工具恒定存在，真实能力在 Toolset 注册表里。');
    const tsCount = await checkToolsets();
    if (tsCount === 0) {
      bad('Toolset 注册表为空 —— 实际没有任何编辑器能力可用');
      info('在 UE 编辑器执行 ModelContextProtocol.RefreshTools，并确认相关插件已启用。');
      info('新增的 UFUNCTION 需要重启编辑器，仅 RefreshTools 不够。');
      return 0;
    }
    info('');
    info('接入 DSH 后，这 3 个工具会呈现为 mcp__unreal__list_toolsets 等');
    info(`实际可用的编辑器能力：${tsCount} 个 Toolset（按需展开，不占固定开销）`);
    return tsCount;
  }

  if (tools.length > 80) {
    warn(`工具数量偏多（${tools.length}）。每个工具定义都会占用每次请求的 token。`);
    info('建议在 UE 里只启用需要的 Toolset。');
  }
  info('');
  info('接入 DSH 后，这些工具会呈现为 mcp__unreal__<toolName>');
  return tools.length;
}

/** 调用 list_toolsets，数出注册表里实际有多少个 Toolset。 */
async function checkToolsets() {
  let result;
  try {
    result = await post({
      jsonrpc: '2.0',
      id: ++rpcId,
      method: 'tools/call',
      params: { name: 'list_toolsets', arguments: {} },
    });
  } catch (err) {
    bad(`list_toolsets 调用失败：${err.message}`);
    return 0;
  }

  const text = (result?.content ?? [])
    .filter((b) => b?.type === 'text')
    .map((b) => b.text ?? '')
    .join('\n');

  if (!text.trim()) return 0;

  // 每行形如 "- Namespace.ToolsetName: 描述"，描述之间可能有空行
  const names = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.startsWith('- '))
    .map((l) => {
      const m = l.match(/^-\s+([A-Za-z0-9_.]+)\s*:/);
      return m ? m[1] : null;
    })
    .filter(Boolean);

  const count = names.length;
  ok(`Toolset 注册表：${count} 个`);

  const preview = names.slice(0, 8);
  for (const n of preview) info(`· ${n}`);
  if (count > preview.length) info(`… 另有 ${count - preview.length} 个`);

  // 挑几个能证明「编辑器真的可控」的关键工具集点出来
  const notable = names.filter((n) =>
    /EditorApp|Logs|AutomationTest|SlateInspector|SemanticSearch/i.test(n),
  );
  if (notable.length) {
    info('');
    info('关键能力已就位：');
    for (const n of notable) {
      const what = /EditorApp/i.test(n) ? 'PIE 控制 / 视口 / CVar / 选择集'
        : /Logs/i.test(n) ? '读取编辑器日志'
        : /AutomationTest/i.test(n) ? '自动化测试发现与执行'
        : /SlateInspector/i.test(n) ? 'Slate UI 自动化（快照/截图/交互）'
        : '资产语义搜索（向量+BM25）';
      info(`· ${n} — ${what}`);
    }
  }
  return count;
}

/**
 * 去掉 YAML 注释行与行尾注释，只留真正的配置内容。
 *
 * 这一步是必须的：本文件的旧版本直接用 text.includes('mcp-unreal') 判断，
 * 而把整块配置注释掉之后（排查问题时很常见）注释文本里仍然含有这些字符串，
 * 于是 doctor 会报「已配置 ✅」—— 一个正好在最需要它的时候骗人的假阳性。
 */
function stripYamlComments(text) {
  return text
    .split(/\r?\n/)
    .map((line) => {
      // 去掉整行注释
      if (/^\s*#/.test(line)) return '';
      // 去掉行尾注释（保留 # 出现在引号内的情形：本插件的配置里没有，够用）
      const idx = line.indexOf('#');
      return idx === -1 ? line : line.slice(0, idx);
    })
    .join('\n');
}

function checkDshConfig() {
  head('5/5  DSH 配置落位');

  const dshHome = process.env.DSH_HOME ?? join(homedir(), '.dsh');
  const homePatch = join(dshHome, 'cordis.patch.yml');

  // ---------------------------------------------------------------------
  // 架构说明（本检查随架构改过）：本插件现在走 bundle 频道。
  //   挂载方式 = profile 的 dsh.profile.bundles 里出现包名
  //   挂载内容 = 包自己的 cordis.patch.yml
  //   home 补丁 = 应该是空的
  // 所以这里要查的是「bundles 有没有登记」，而不是「home 补丁里有没有 insert」。
  // ---------------------------------------------------------------------

  // --- 5a. 包能否被解析 ---
  const profilesDir = join(dshHome, 'profiles');
  const pkgCandidates = [
    join(profilesDir, 'node_modules', 'dsh-unreal-engine'),
    join(profilesDir, 'web', 'node_modules', 'dsh-unreal-engine'),
  ];
  const pkgDir = pkgCandidates.find((p) => existsSync(join(p, 'package.json')));
  if (pkgDir) {
    ok(`包已安装：${pkgDir}`);
  } else {
    bad('包未安装 —— 插件一定加载不了');
    info(`已查找：${pkgCandidates.join('  |  ')}`);
    info('装法二选一：');
    info('  cd $DSH_HOME\\profiles\\web');
    info('  pnpm add <路径或 .tgz>');
    info('或建目录连接（开发期）：');
    info('  New-Item -ItemType Junction -Path "$DSH_HOME\\profiles\\node_modules\\dsh-unreal-engine" -Target <源码目录>');
    configBroken = true;
    return false;
  }

  // --- 5b. bundles 里登记了吗 ---
  let registered = false;
  for (const profileName of ['web', 'sdk']) {
    const manifest = join(profilesDir, profileName, 'package.json');
    if (!existsSync(manifest)) continue;
    let parsed;
    try {
      parsed = JSON.parse(readFileSync(manifest, 'utf8'));
    } catch (err) {
      bad(`profile 清单不是合法 JSON：${manifest} —— ${err.message}`);
      configBroken = true;
      continue;
    }
    const bundles = parsed?.dsh?.profile?.bundles;
    if (!Array.isArray(bundles)) continue;
    if (bundles.includes('dsh-unreal-engine')) {
      ok(`已登记进 bundles：${profileName}`);
      registered = true;
    } else {
      info(`profile ${profileName} 的 bundles 里没有本包`);
    }
  }

  if (!registered) {
    bad('bundles 里没有 dsh-unreal-engine —— DSH 不会应用本插件的挂载补丁');
    info('编辑 $DSH_HOME\\profiles\\web\\package.json，把包名加进 dsh.profile.bundles：');
    info('  "bundles": [ ... 已有项 ..., "dsh-unreal-engine" ]');
    info('（DSH 的 reconcileProfilePlugins 本该自动登记，但当前版本从未调用它。）');
    configBroken = true;
  }

  // --- 5c. home 补丁应该为空（防止旧配置残留造成同 id 冲突） ---
  if (existsSync(homePatch)) {
    let raw;
    try { raw = readFileSync(homePatch, 'utf8'); } catch { raw = ''; }
    const active = stripYamlComments(raw).trim();

    // 去掉注释后如果只剩空数组/空内容，就是干净的
    const isEmpty = active === '' || active === '[]';
    if (isEmpty) {
      ok('home 补丁干净（空数组）—— 不会有 id 冲突');
    } else {
      // 有实质内容：检查是否还残留本插件的旧行
      if (/mcp-unreal|dsh-mcp-client|dsh-unreal-engine/.test(active)) {
        bad('home 补丁里残留了本插件的旧配置 —— 会与 bundle 层产生同 id 冲突');
        info('删掉那些 `- insert:` 块（注意：缩进的子行要一起删），或把整个文件清成 `[]`。');
        configBroken = true;
      } else {
        warn('home 补丁里有其它有效配置（与本插件无关，但改动它前请先备份）');
      }
    }
  } else {
    ok('没有 home 补丁文件 —— 等价于空配置');
  }

  return registered;
}

// ---------------------------------------------------------------------------
async function main() {
  console.log(`${C.b}ue5-dsh-doctor${C.x} — UE5 ↔ DSH 连通性诊断`);

  checkNode();
  const reachable = await checkReachability();
  let capabilityCount = 0;
  let handshakeOk = false;

  if (reachable) {
    const hs = await checkHandshake();
    handshakeOk = hs !== null;
    if (handshakeOk) capabilityCount = await checkTools();
  } else {
    head('3/5  MCP 握手');
    info('跳过 —— 端点不可达');
    head('4/5  工具枚举');
    info('跳过 —— 端点不可达');
  }

  configFound = checkDshConfig();

  head('结论');
  if (handshakeOk && capabilityCount > 0) {
    console.log(`${C.g}  UE 链路通畅${C.x} —— ${capabilityCount} 项编辑器能力可用。`);
    if (configFound && !configBroken) {
      console.log('  配置已就位 —— 重启 DSH 后即可使用 mcp__unreal__* 工具。');
    } else if (configBroken) {
      console.log(`  ${C.r}配置有问题${C.x} —— 见上面第 5 项，修好后重启 DSH。`);
    } else {
      console.log('  下一步：按第 5 项的提示把包装好并登记进 bundles，然后重启 DSH。');
    }
  } else if (handshakeOk) {
    console.log(`${C.r}  已连上但无可用的编辑器能力${C.x} —— 见上面第 4 项。`);
  } else if (failures === 0) {
    console.log(`${C.y}  链路可用但有待办项${C.x} — 见上面的 WARN。`);
  } else {
    console.log(`${C.r}  ${failures} 项检查失败${C.x} — 按上面的提示逐项修复后重跑。`);
  }
  console.log('');

  process.exit(failures > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error(`\n${C.r}doctor 自身崩溃${C.x}：${err?.stack ?? err}`);
  process.exit(2);
});
