# 应急恢复卡 — DSH 起不来 / 网页打不开

> 这张卡是为了在最坏情况下**不用思考也能恢复**。
> 所有内容都已实测验证。配置文件只有一个：`$env:DSH_HOME\cordis.patch.yml`

> **先把这一行粘进 PowerShell 再往下做**（`$env:DSH_HOME` 可能是空的）：
> ```powershell
> if (-not $env:DSH_HOME) { $env:DSH_HOME = "$env:USERPROFILE\.dsh" }
> ```
> `$RepoRoot` = 本插件源码目录。含义详见 [README.md](README.md#命令里的两个占位符)。

---

## 第 0 步：先分清是哪种故障（关键，别搞错）

| 症状 | 含义 | 该做什么 |
|---|---|---|
| **终端里有 `dsh web: http://…`** | ✅ **宿主起来了** | 别重启！网页层的问题，看第 1 步 |
| 终端里刷 `Error: …failed to apply loader entry` | ❌ 宿主起不来 | 跳到第 2 步 |
| 浏览器能开页面，但弹「加载插件失败」 | ⚠️ 前端某插件崩了 | **看第 1 步** |

**最重要的一条**：

> 网页里的「加载插件失败 / 未能导入加载器条目」是**前端安全带**。
> 它**通常意味着 DSH 宿主仍在正常运行** —— 你的会话、工具、数据都没事。
>
> **这种情况下不要急着重启**，因为重启反而会把你现在能用的东西也一起停掉。
> 正确做法是：恢复成能用的配置，**然后再决定何时重启**。

---

## 第 1 步：网页层故障（宿主还活着）

**先拿到真实错误**：浏览器按 `F12` → Console，看**第一条红色错误**。
安全带里那一大串 bundle 列表是汇总，不是原因；第一条错误才是。

**然后恢复配置**（改完需要重启才生效，所以你有时间慢慢来）：

打开 `$env:DSH_HOME\cordis.patch.yml`，找到**只有一行**的 `- insert:` 块，
在每行前面加 `#` 注释掉。当前你在用的相关行有这些：

```yaml
# 要注释掉的（前面加 #）
- insert:
    - id: unreal-engine
      name: 'dsh-unreal-engine'

- insert:
    - id: mcp-unreal
      name: '@deepseek-ai/dsh-mcp-client'
      config:
        ...
```

**注意**：注释掉 `- insert:` 之后，它下面**缩进的所有行**（`- id:`、`name:`、`config:` 及 config 的子项）
**都要一起注释掉**，否则 YAML 会因为悬空的缩进而解析失败。

## 第 2 步：宿主起不来

### 退路 A（最狠，保证能起）：整个文件清空

把 `$env:DSH_HOME\cordis.patch.yml` 的**全部内容**替换成两个字符：

```yaml
[]
```

（`[]` 是 YAML 的空数组，表示「没有任何补丁」。也可以留空文件，但 `[]` 更明确。）

**这一条已实测：`dsh --profile web` 干净启动，出 `dsh web: http://127.0.0.1:3080/…`。**

这是你的**保证兜底状态**。回到这里你就一定能用 DSH —— 只是暂时没有 unreal 工具。

### 退路 B：只开 MCP 工具，不要设置页

想保留「UE 工具可用」但怀疑是插件本体（`dsh-unreal-engine`）搞的鬼，就用这份：

```yaml
- insert:
    - id: mcp-unreal
      name: '@deepseek-ai/dsh-mcp-client'
      config:
        serverName: unreal
        transport: streamable-http
        url: 'http://127.0.0.1:8000/mcp'
        toolCallTimeoutMs: 600000
        failOnStartupError: false
        reconnect:
          enabled: true
          initialDelayMs: 500
          maxDelayMs: 30000
          maxAttempts: 10
```

这份**不含 `dsh-unreal-engine` 插件**，所以设置页不会出现，但 UE 工具照常可用。

**排查逻辑**：
- 退路 B 能起 → 问题在 `dsh-unreal-engine` 插件本体
- 退路 B 也起不来 → 问题在 `mcp-unreal` 那一行（或环境本身）

---

## 第 3 步：验证配置再启动（避免反复踩坑）

```powershell
dsh --profile web --dump-config
```

- `exit=0` + 无 `not found` 警告 → 配置语法正确
- ⚠️ **但它不验证包能否被 import、也不求值 `!!js`** —— 别把它当成"能启动"的证明

真正的最小验证（几秒就够）：

```powershell
dsh --profile sdk
```

能安静退出（`exit=0`、无输出）就说明插件树能加载。Ctrl+C 退出。

---

## ⚠️ 一个绝对不能删的东西

```
$env:DSH_HOME\profiles\node_modules\dsh-unreal-engine
```

这是指向 `$RepoRoot` 的**目录连接（junction）**。

**删了它，`name: 'dsh-unreal-engine'` 就解析不到，DSH 又会起不来。**

重新创建：

```powershell
New-Item -ItemType Junction `
  -Path '$env:DSH_HOME\profiles\node_modules\dsh-unreal-engine' `
  -Target '$RepoRoot'
```

> 为什么放 `profiles/node_modules`（而不是 `profiles/web/node_modules`）：
> home 级补丁对**所有** profile 生效，而包是按 profile 解析的。
> 放共享位置，web 和 sdk 都能解析到。

---

## 故障对照表（开发期踩过的坑，均已实测）

| 错误信息 | 原因 | 修法 |
|---|---|---|
| `Cannot find package 'dsh-unreal-engine'` | 包没装进 profile | 按 `README.md` 的「安装」装包（pnpm add 或 junction） |
| `invalid plugin, expect function or object with an "apply" method` | 把**浏览器半**当 Node 插件行挂了 | 删掉 `unreal-engine-client` 的 insert 行（浏览器半不需要 loader 条目） |
| `1 entry did not activate` / `pending (waiting for service: webServer)` | `inject: ['webServer']` 在非 web profile 挂起 | 已改用 `ctx.inject()` 可选注入 |
| `bundle …loaded without registering "dsh-unreal-engine"` | 客户端 bundle 的 `__ModuleLoader__.load({ id })` 与**包名**不一致 | 改为包名 `dsh-unreal-engine`；见 `LESSONS.md` 第 6 条 |
| `patch: entry xxx not found` | 用了 `- id:` 顶层写法挂新插件 | 必须用 `- insert:` 嵌套形态 |
| `cannot get property "webServer" without inject` | 直接读未声明的服务 | 用 `ctx.inject([...], cb)` |
| YAML 解析失败 | 注释 `- insert:` 时漏了缩进的子行 | 整块一起注释 |
| 探测报「无法解析 MCP 客户端模块」 | MCP SDK 改名（v1 `sdk` → v2 `client`）或不在预期位置 | 见 `README.md` 的「MCP SDK 的解析」；错误信息里会列出每次尝试的原因 |

> 完整的事故复盘（14 个 bug、分「DSH 机制陷阱 / 我的代码 bug / 工具误用」三类，
> 以及每条对应的 DSH 认知）在 [`LESSONS.md`](LESSONS.md)。

---

## 变更前的习惯（血泪教训）

改 `cordis.patch.yml` 之前，先备一份。

> ⚠️ **必须用绝对路径**。`$env:DSH_HOME` 在你的普通 PowerShell 里**是没有值的**
> （那是 DSH 子进程内部注入的变量），用了会静默失败。

```powershell
Copy-Item '$env:DSH_HOME\cordis.patch.yml' '$env:DSH_HOME\cordis.patch.yml.bak' -Force
```

出事了直接换回来：

```powershell
Move-Item '$env:DSH_HOME\cordis.patch.yml.bak' '$env:DSH_HOME\cordis.patch.yml' -Force
```

**一份能用的配置，比一份"应该能用的"配置值钱得多。**
