# 参与贡献

欢迎提交 Issue 与 Pull Request！

## 开发流程

1. Fork 本仓库并 clone 到本地
2. `npm install` 安装依赖
3. 修改代码（见下方约定）
4. `npm run build` 确认构建通过
5. 提交并推送，然后发起 Pull Request

## 约定

- 界面文案需同时维护 `zh` 与 `en` 两套字典（见 `src/client/index.tsx`）
- **不要提交任何真实站点数据**；示例数据请使用占位域名并放入 `examples/`
- 保持 `dsh.plugin.json` 与 `package.json` 的版本号一致
- 变更请同步更新 `CHANGELOG.md`
