# 更新日志

本项目遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 规范。

## [0.3.0] - 2026-08-21

### 新增

- **重新生成（全量覆盖）**：`/dsh-sitemap/regen` 扫描工作区侦察文件（`all_host_apis.json`、`urls_by_host.json`、`cvp_urls_by_host.json`、`hll_apis.json`、`sdp_apis.json`，`sources` 可配置）合成 `sitemap_data.json`，覆盖写、历史残留站点一次清空
- **清除能力**：单主机 🗑 删除（`/dsh-sitemap/host-remove`）与一键清空（`/dsh-sitemap/clear`）
- **站点配色**：主机名哈希到 14 色盘，主机圆点 / 展开态 / 接口选中描边统一用该站点色
- **Cookie 保险库**：支持 Cookie-Editor JSON / Header String / Netscape 三种格式导入（自动识别），按域名匹配标注覆盖站点（🍪 角标），详情页一键复制 Cookie header；存储于工作区 `dsh-sitemap-cookies.json`，不进仓库
- **src 工作流工具**：注册 `sitemap_query` / `sitemap_cookie` / `sitemap_regen` / `sitemap_import_cookie` 四个 agent 工具，工作流自取站点数据与 cookie（配合 dsh-tool-playwright 的 `browser_add_cookies` 注入浏览器）

### 变更

- 宿主半区注入 `tools` 服务，`@deepseek-ai/dsh-tools` 加入构建 external
- 接口元信息新增 `sources`（来源文件）字段并在详情页展示

## [0.2.0] - 2026-08-15

### 变更

- 通用化：移除描述中的站点特定字样与默认数据目录，`dataDir` 改为可配置（不配置时读取工作区根目录下的 `sitemap_data.json`）
- 浏览器半区统一为应用内弹窗实现，删除旧的 openPath 变体
- 构建脚本改为从 `src/client/index.tsx` 打包（jsx automatic）
- 依赖改为 npm 已发布版本（`@deepseek-ai/dsh-client-*`），移除本地 `link:` 引用
- 移除随仓库携带的静态数据资产，仓库内不含任何真实站点数据
- 新增 `cordis.patch.yml` bundle 声明（`dsh.bundle.patch`），符合社区装法规范
- 补充 README / LICENSE / CONTRIBUTING / 示例数据等开源规范文件

## [0.1.0] - 内部初版（未发布）

### 新增

- 侧边栏入口 + 主机树形接口地图 + 详情查看 / 复制 curl
