/**
 * dsh-sitemap cookie vault.
 *
 * Imports cookies exported by browser cookie managers (Cookie-Editor) and
 * matches them against sitemap hosts so the UI can badge which hosts are
 * reachable with the stored credentials, and the agent tools can hand the
 * right Cookie header to the SRC workflow for browser injection.
 *
 * Storage is a local sidecar file under the workspace data dir — never part
 * of the plugin repo.
 */
import { mkdir, readFile, unlink, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'

export interface VaultCookie {
  name: string
  value: string
  domain: string
  /** Cookie was issued without a domain attribute: matches its own host only. */
  hostOnly?: boolean
  path: string
  secure: boolean
  httpOnly: boolean
  sameSite?: string
  expires?: number
  source: 'json' | 'header' | 'netscape'
  addedAt: string
}

export interface ImportReceipt {
  format: 'json' | 'header' | 'netscape'
  total: number
  added: number
}

interface VaultFile {
  version: 1
  updatedAt: string
  cookies: VaultCookie[]
}

export function normalizeDomain(raw: string): string {
  return (raw ?? '').trim().toLowerCase().replace(/^\.+/, '').replace(/\/+$/, '')
}

/** Does a cookie apply to `host`? Domain match + hostOnly handling. */
export function cookieMatchesHost(cookie: VaultCookie, host: string): boolean {
  const d = normalizeDomain(cookie.domain)
  const h = normalizeDomain(host)
  if (!d || !h) return false
  if (cookie.hostOnly) return h === d
  return h === d || h.endsWith('.' + d)
}

/** Filter vault cookies matching a host (domain + path prefix sanity). */
export function cookiesForHost(cookies: VaultCookie[], host: string): VaultCookie[] {
  return cookies.filter(c => cookieMatchesHost(c, host))
}

export function buildCookieHeader(cookies: VaultCookie[]): string {
  return cookies.map(c => `${c.name}=${c.value}`).join('; ')
}

/* ---------------- parsers ---------------- */

function now(): string {
  return new Date().toISOString()
}

const TRUTHY = new Set(['true', '1', 'yes'])

function toBool(v: unknown): boolean {
  if (typeof v === 'boolean') return v
  return TRUTHY.has(String(v ?? '').trim().toLowerCase())
}

/** Cookie-Editor / Chrome export: JSON array of cookie descriptors. */
export function parseJson(text: string): VaultCookie[] {
  let data: unknown
  try {
    data = JSON.parse(text)
  } catch {
    throw new Error('JSON 解析失败：请粘贴 Cookie-Editor「Export → JSON」的内容')
  }
  const arr = Array.isArray(data) ? data : (data as { cookies?: unknown[] })?.cookies
  if (!Array.isArray(arr)) {
    throw new Error('JSON 格式不对：应为 cookie 数组，或含 cookies 数组的对象')
  }
  const out: VaultCookie[] = []
  for (const item of arr) {
    if (!item || typeof item !== 'object') continue
    const c = item as Record<string, unknown>
    const name = String(c.name ?? '')
    if (!name || !('value' in c)) continue
    const domain = normalizeDomain(String(c.domain ?? ''))
    if (!domain) continue
    out.push({
      name,
      value: String(c.value ?? ''),
      domain,
      hostOnly: toBool(c.hostOnly),
      path: String(c.path ?? '/') || '/',
      secure: toBool(c.secure),
      httpOnly: toBool(c.httpOnly),
      sameSite: c.sameSite ? String(c.sameSite) : undefined,
      expires: c.expirationDate !== undefined && c.expirationDate !== null && Number(c.expirationDate) > 0
        ? Number(c.expirationDate)
        : undefined,
      source: 'json',
      addedAt: now(),
    })
  }
  return out
}

/** "Cookie: a=1; b=2" header string. Needs a target domain — caller supplies it. */
export function parseHeaderString(text: string, domain?: string): VaultCookie[] {
  let body = text.trim()
  if (/^cookie\s*:/i.test(body)) body = body.replace(/^cookie\s*:/i, '').trim()
  const dom = normalizeDomain(domain ?? '')
  if (dom && !/^[a-z0-9._-]+$/i.test(dom)) throw new Error('域名格式不对，例如 example.com')
  const out: VaultCookie[] = []
  for (const part of body.split(';')) {
    const seg = part.trim()
    if (!seg) continue
    const idx = seg.indexOf('=')
    if (idx <= 0) continue
    const name = seg.slice(0, idx).trim()
    const value = seg.slice(idx + 1).trim()
    if (!name) continue
    out.push({
      name,
      value,
      domain: dom || '*',
      path: '/',
      secure: false,
      httpOnly: false,
      source: 'header',
      addedAt: now(),
    })
  }
  if (out.length === 0) throw new Error('没解析到任何 cookie（应为 name=value; name2=value2 形式）')
  return out
}

/** Netscape cookies.txt format (curl/wget compatible). */
export function parseNetscape(text: string): VaultCookie[] {
  const out: VaultCookie[] = []
  for (const rawLine of text.split(/\r?\n/)) {
    let line = rawLine
    if (!line.trim()) continue
    let httpOnly = false
    if (line.startsWith('#HttpOnly_')) {
      httpOnly = true
      line = line.slice('#HttpOnly_'.length)
    } else if (line.startsWith('#')) {
      continue
    }
    const cols = line.split('\t')
    if (cols.length < 7) continue
    const [domain, includeSubdomains, path, secure, expiresRaw, name, ...valueParts] = cols
    const value = valueParts.join('\t')
    const dom = normalizeDomain(domain)
    if (!name.trim() || !dom) continue
    const hostOnly = !toBool(includeSubdomains) && !String(domain).trimStart().startsWith('.')
    const expires = Number(expiresRaw)
    out.push({
      name: name.trim(),
      value: value ?? '',
      domain: dom,
      hostOnly,
      path: (path || '/').trim() || '/',
      secure: toBool(secure),
      httpOnly,
      ...(expires > 0 ? { expires } : {}),
      source: 'netscape',
      addedAt: now(),
    })
  }
  return out
}

export type CookieFormat = 'json' | 'header' | 'netscape'

export function detectFormat(text: string): CookieFormat {
  const t = text.trim()
  if (/^cookie\s*:/i.test(t)) return 'header'
  if (t.startsWith('# Netscape') || t.startsWith('#Netscape') || /^#HttpOnly_/.test(t)) return 'netscape'
  if (/^[^\s#]+\t(TRUE|FALSE)\t/.test(t)) return 'netscape'
  if (t.startsWith('[') || t.startsWith('{')) return 'json'
  // bare name=value pairs (single or semicolon-joined) without other structure
  if (/^[A-Za-z0-9_%$.-]+=/.test(t) && !t.includes('\n')) return 'header'
  return 'json'
}

export function parseCookies(text: string, format: CookieFormat, domain?: string): VaultCookie[] {
  switch (format) {
    case 'json': return parseJson(text)
    case 'header': return parseHeaderString(text, domain)
    case 'netscape': return parseNetscape(text)
  }
}

/* ---------------- vault file ---------------- */

export interface VaultOptions {
  workspace: string
  dataDir?: string
}

function vaultPath(opts: VaultOptions): string {
  const base = opts.dataDir ? join(opts.workspace, opts.dataDir) : opts.workspace
  return join(base, 'dsh-sitemap-cookies.json')
}

export async function loadVault(opts: VaultOptions): Promise<VaultCookie[]> {
  try {
    const raw = await readFile(vaultPath(opts), 'utf8')
    const parsed = JSON.parse(raw) as VaultFile
    return Array.isArray(parsed.cookies) ? parsed.cookies : []
  } catch {
    return []
  }
}

export async function saveVault(opts: VaultOptions, cookies: VaultCookie[]): Promise<void> {
  const p = vaultPath(opts)
  await mkdir(dirname(p), { recursive: true })
  const doc: VaultFile = { version: 1, updatedAt: now(), cookies }
  await writeFile(p, JSON.stringify(doc, null, 2), 'utf8')
}

export async function clearVault(opts: VaultOptions): Promise<boolean> {
  try {
    await unlink(vaultPath(opts))
    return true
  } catch {
    return false
  }
}

/** Merge newly parsed cookies into the existing vault (replace same domain+name+path). */
export function mergeCookies(existing: VaultCookie[], incoming: VaultCookie[]): { cookies: VaultCookie[]; added: number } {
  const map = new Map<string, VaultCookie>()
  for (const c of existing) map.set(key(c), c)
  let added = 0
  for (const c of incoming) {
    const k = key(c)
    if (!map.has(k)) added++
    map.set(k, c)
  }
  return { cookies: [...map.values()], added }
}

function key(c: VaultCookie): string {
  return `${normalizeDomain(c.domain)}|${c.name}|${c.path}`
}