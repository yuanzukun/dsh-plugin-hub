/**
 * dsh-sitemap collector — turns workspace recon artifacts into the map.
 *
 * "重新生成" semantics: the sitemap_data.json output file is OVERWRITTEN from
 * the recon sources listed below, so stale hosts disappear on the next regen.
 * Sources live at the workspace root (or a configured scanRoot) and are
 * strictly opt-in via the `sources` config — nothing outside that list is read.
 */
import { readFile } from 'node:fs/promises'
import { join } from 'node:path'

export interface EndpointMeta {
  methods: string[]
  count: number
  params: string[]
  sources: string[]
}

export type HostMap = Record<string, { endpoints: Record<string, EndpointMeta> }>

export type SourceType = 'host-path' | 'host-urls' | 'paths' | 'path-objects' | 'sitemap'

export interface SourceSpec {
  /** File name to look for under scanRoot. */
  file: string
  type: SourceType
  /** Label used as host when the source carries no host (paths / path-objects). */
  host?: string
}

export interface CollectStats {
  hosts: number
  endpoints: number
  sources: Array<{
    file: string
    matched: boolean
    hosts: number
    endpoints: number
    error?: string
  }>
}

export interface CollectResult {
  map: HostMap
  stats: CollectStats
}

export const DEFAULT_SOURCES: SourceSpec[] = [
  { file: 'all_host_apis.json', type: 'host-path' },
  { file: 'urls_by_host.json', type: 'host-urls' },
  { file: 'cvp_urls_by_host.json', type: 'host-urls' },
  { file: 'hll_apis.json', type: 'paths' },
  { file: 'sdp_apis.json', type: 'path-objects' },
]

interface Merger {
  host: string
  path: string
  methods: string[]
  count: number
  params: string[]
  source: string
}

function asStr(v: unknown): string {
  return typeof v === 'string' ? v : ''
}

function pushUnique(arr: string[], v: string): void {
  if (v && !arr.includes(v)) arr.push(v)
}

function parseUrlToPath(raw: unknown): { host: string; path: string } | null {
  const s = asStr(raw)
  if (!s) return null
  let u: URL
  try {
    u = new URL(s)
  } catch {
    return null
  }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return null
  return { host: u.hostname.toLowerCase(), path: u.pathname || '/' }
}

/** host → array of paths (or {path, method(s), count, params} objects). */
function walkHostPath(data: unknown, source: string, out: Merger[]): void {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return
  for (const [host, list] of Object.entries(data as Record<string, unknown>)) {
    if (!Array.isArray(list)) continue
    for (const item of list) {
      if (typeof item === 'string') {
        out.push({ host, path: item, methods: [], count: 1, params: [], source })
        continue
      }
      if (item && typeof item === 'object') {
        const o = item as Record<string, unknown>
        const path = asStr(o.path)
        if (!path) continue
        const methods = Array.isArray(o.methods) ? o.methods.map(asStr).filter(Boolean) : (o.method ? [asStr(o.method)] : [])
        out.push({
          host,
          path,
          methods,
          count: Number(o.count) > 0 ? Number(o.count) : 1,
          params: Array.isArray(o.params) ? o.params.map(asStr).filter(Boolean) : [],
          source,
        })
      }
    }
  }
}

/** host → array of full URLs. */
function walkHostUrls(data: unknown, source: string, out: Merger[]): void {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return
  for (const [host, list] of Object.entries(data as Record<string, unknown>)) {
    if (!Array.isArray(list)) continue
    for (const item of list) {
      const parsed = parseUrlToPath(item)
      if (!parsed) continue
      out.push({ host: parsed.host, path: parsed.path, methods: [], count: 1, params: [], source })
    }
  }
}

/** flat array of paths — grouped under the spec's host label (or file stem). */
function walkPaths(data: unknown, source: string, hostLabel: string, out: Merger[]): void {
  if (!Array.isArray(data)) return
  for (const item of data) {
    const p = asStr(item)
    if (!p) continue
    out.push({ host: hostLabel, path: p, methods: [], count: 1, params: [], source })
  }
}

/** flat array of {path, method(s), count, params} objects — grouped under the label. */
function walkPathObjects(data: unknown, source: string, hostLabel: string, out: Merger[]): void {
  if (!Array.isArray(data)) return
  for (const item of data) {
    if (!item || typeof item !== 'object') continue
    const o = item as Record<string, unknown>
    const path = asStr(o.path)
    if (!path) continue
    const methods = Array.isArray(o.methods) ? o.methods.map(asStr).filter(Boolean) : (o.method ? [asStr(o.method)] : [])
    out.push({
      host: hostLabel,
      path,
      methods,
      count: Number(o.count) > 0 ? Number(o.count) : 1,
      params: Array.isArray(o.params) ? o.params.map(asStr).filter(Boolean) : [],
      source,
    })
  }
}

/** Existing sitemap_data.json in final format → merge as-is. */
function walkSitemap(data: unknown, source: string, out: Merger[]): void {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return
  for (const [host, entry] of Object.entries(data as Record<string, unknown>)) {
    if (!entry || typeof entry !== 'object') continue
    const endpoints = (entry as Record<string, unknown>).endpoints
    if (!endpoints || typeof endpoints !== 'object') continue
    for (const [path, meta] of Object.entries(endpoints as Record<string, unknown>)) {
      const m = (meta ?? {}) as Record<string, unknown>
      out.push({
        host,
        path,
        methods: Array.isArray(m.methods) ? m.methods.map(asStr).filter(Boolean) : [],
        count: Number(m.count) > 0 ? Number(m.count) : 1,
        params: Array.isArray(m.params) ? m.params.map(asStr).filter(Boolean) : [],
        source,
      })
    }
  }
}

function mergeInto(map: HostMap, items: Merger[]): EndpointMeta[] {
  const touched: EndpointMeta[] = []
  for (const item of items) {
    const hostKey = item.host.trim().toLowerCase() || '(无主机)'
    const path = item.path.startsWith('/') ? item.path : '/' + item.path
    const entry = (map[hostKey] ??= { endpoints: {} })
    const ep = (entry.endpoints[path] ??= { methods: [], count: 0, params: [], sources: [] })
    for (const m of item.methods) pushUnique(ep.methods, m.toUpperCase())
    for (const p of item.params) pushUnique(ep.params, p)
    pushUnique(ep.sources, item.source)
    ep.count += item.count
    touched.push(ep)
  }
  return touched
}

export interface CollectInput {
  scanRoot: string
  sources: SourceSpec[]
}

/** Read and merge all configured source files. Missing files are skipped and reported. */
export async function collect(input: CollectInput): Promise<CollectResult> {
  const map: HostMap = {}
  const stats: CollectStats = { hosts: 0, endpoints: 0, sources: [] }
  const merged: Merger[] = []

  for (const spec of input.sources) {
    const filePath = join(input.scanRoot, spec.file)
    const statEntry: CollectStats['sources'][number] = {
      file: spec.file,
      matched: false,
      hosts: 0,
      endpoints: 0,
    }
    let rawText: string
    try {
      rawText = await readFile(filePath, 'utf8')
      statEntry.matched = true
    } catch (err) {
      statEntry.error = '文件不存在或不可读'
      stats.sources.push(statEntry)
      continue
    }
    let data: unknown
    try {
      data = JSON.parse(rawText)
    } catch (err) {
      statEntry.error = 'JSON 解析失败'
      stats.sources.push(statEntry)
      continue
    }
    const before = merged.length
    const label = spec.host ?? spec.file.replace(/\.json$/i, '')
    switch (spec.type) {
      case 'host-path': walkHostPath(data, spec.file, merged); break
      case 'host-urls': walkHostUrls(data, spec.file, merged); break
      case 'paths': walkPaths(data, spec.file, label, merged); break
      case 'path-objects': walkPathObjects(data, spec.file, label, merged); break
      case 'sitemap': walkSitemap(data, spec.file, merged); break
    }
    const items = merged.slice(before)
    const touched = mergeInto(map, items)
    statEntry.hosts = new Set(items.map(i => i.host.trim().toLowerCase())).size
    statEntry.endpoints = touched.length
    stats.sources.push(statEntry)
  }

  stats.hosts = Object.keys(map).length
  const sorted: HostMap = {}
  for (const host of Object.keys(map).sort()) {
    const endpoints: Record<string, EndpointMeta> = {}
    for (const path of Object.keys(map[host].endpoints).sort()) {
      endpoints[path] = map[host].endpoints[path]
    }
    sorted[host] = { endpoints }
  }
  stats.endpoints = Object.values(sorted).reduce((a, h) => a + Object.keys(h.endpoints).length, 0)
  return { map: sorted, stats }
}