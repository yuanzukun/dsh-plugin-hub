/**
 * Local type shims for optional DSH host packages that are provided by the
 * harness at runtime but not installed in this repo (build uses esbuild and
 * treats them as externals; type-checking stays possible via this shim).
 */
declare module '@deepseek-ai/dsh-tools' {
  export function defineTool(options: unknown): unknown
  export type JsonValue = unknown
  export type ToolDefinition = unknown
  export type ToolRunContext = unknown
}