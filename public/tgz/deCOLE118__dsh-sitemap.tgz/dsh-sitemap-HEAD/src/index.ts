/**
 * dsh-sitemap host half:
 * - webServer routes: map data, regen (collect+overwrite), clear, per-host
 *   removal, and the cookie vault (import/read/clear).
 * - Agent tools for the SRC workflow: sitemap_query / sitemap_cookie /
 *   sitemap_regen / sitemap_import_cookie.
 * - All file access stays inside the workspace data dir.
 */
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { isAbsolute, join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { defineTool } from '@deepseek-ai/dsh-tools'
import {
  buildCookieHeader,
  clearVault,
  cookieMatchesHost,
  cookiesForHost,
  detectFormat,
  loadVault,
  mergeCookies,
  parseCookies,
  saveVault,
  type CookieFormat,
  type VaultCookie,
} from './cookies.ts'
import { collect, DEFAULT_SOURCES, type SourceSpec } from './collect.ts'

export const name = 'dsh-sitemap'
export const inject = ['tools', 'webServer']

export interface Config {
  /** Absolute workspace root; defaults to $DSH_WORKSPACE or cwd. */
  workspace?: string
  /** Directory under the workspace that holds sitemap_data.json; defaults to the workspace root. */
  dataDir?: string
  /** Recon files merged by regen. Defaults cover the common SRC artifacts. */
  sources?: SourceSpec[]
}

/* ------------------------------------------------------------------ utils */

function json(res: ServerResponse, status: number, payload: unknown): void {
  const body = JSON.stringify(payload)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  })
  res.end(body)
}

function readBody(req: IncomingMessage, limit = 4 * 1024 * 1024): Promise<string> {
  return new Promise((resolve) => {
    let acc = ''
    let over = false
    req.on('data', (c) => {
      if (over) return
      acc += c
      if (acc.length > limit) {
        over = true
        acc = ''
      }
    })
    req.on('end', () => resolve(over ? '' : acc))
    req.on('error', () => resolve(''))
  })
}

function textBlock(text: string): Array<{ type: 'text'; text: string }> {
  return [{ type: 'text', text }]
}

interface MapEndpoint {
  methods: string[]
  count: number
  params: string[]
  sources: string[]
}
type MapFile = Record<string, { endpoints: Record<string, MapEndpoint> }>

/* ------------------------------------------------------------------ routes */

export function apply(ctx: Context, config?: Config): void {
  const cfg = config ?? {}
  const workspace = cfg.workspace && isAbsolute(cfg.workspace)
    ? cfg.workspace
    : (process.env.DSH_WORKSPACE || process.cwd())
  const dataDir = cfg.dataDir ? join(workspace, cfg.dataDir) : workspace
  const dataPath = join(dataDir, 'sitemap_data.json')
  const sources = Array.isArray(cfg.sources) && cfg.sources.length > 0 ? cfg.sources : DEFAULT_SOURCES

  const loadData = async (): Promise<{ ok: boolean; data?: MapFile; error?: string }> => {
    try {
      const raw = await readFile(dataPath, 'utf8')
      const parsed = JSON.parse(raw) as MapFile
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        return { ok: false, error: 'sitemap_data.json 结构不对' }
      }
      return { ok: true, data: parsed }
    } catch (err) {
      return { ok: false, error: '还没有站点地图数据（可点「重新生成」从工作区侦察文件合成）' }
    }
  }

  const runRegen = async () => {
    const result = await collect({ scanRoot: workspace, sources })
    await mkdir(dataDir, { recursive: true })
    await writeFile(dataPath, JSON.stringify(result.map, null, 2), 'utf8')
    return result
  }

  ctx.inject(['tools', 'webServer'], (scope: Context) => {
    const ws = (scope as unknown as { get?: (k: string) => unknown }).get?.('webServer') as unknown as {
      register(r: { kind: string; path: string; handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void> }): () => void
    } | undefined
    if (!ws?.register) {
      scope.logger.warn('[dsh-sitemap] webServer unavailable')
    }

    /* ---------------- map routes ---------------- */

    ws?.register({
      kind: 'exact',
      path: '/dsh-sitemap/data',
      handler: async (_req, res) => {
        const result = await loadData()
        if (result.ok) json(res, 200, { ok: true, data: result.data })
        else json(res, 404, { ok: false, error: result.error })
      },
    })

    ws?.register({
      kind: 'exact',
      path: '/dsh-sitemap/regen',
      handler: async (req, res) => {
        await readBody(req)
        const result = await runRegen()
        json(res, 200, { ok: true, data: result.map, stats: result.stats })
      },
    })

    ws?.register({
      kind: 'exact',
      path: '/dsh-sitemap/clear',
      handler: async (req, res) => {
        await readBody(req)
        try {
          await rm(dataPath, { force: true })
          json(res, 200, { ok: true, removed: true })
        } catch (err) {
          json(res, 500, { ok: false, error: String(err) })
        }
      },
    })

    ws?.register({
      kind: 'exact',
      path: '/dsh-sitemap/host-remove',
      handler: async (req, res) => {
        const body = await readBody(req)
        let host = ''
        try {
          host = String(JSON.parse(body).host ?? '').trim().toLowerCase()
        } catch { /* bad body */ }
        if (!host) {
          json(res, 400, { ok: false, error: '缺少 host 参数' })
          return
        }
        const result = await loadData()
        if (!result.ok || !result.data) {
          json(res, 404, { ok: false, error: result.error })
          return
        }
        const map = result.data
        if (!(host in map)) {
          json(res, 200, { ok: true, removed: false, data: map })
          return
        }
        delete map[host]
        await writeFile(dataPath, JSON.stringify(map, null, 2), 'utf8')
        json(res, 200, { ok: true, removed: true, data: map })
      },
    })

    /* ---------------- cookie routes ---------------- */

    const vaultOpts = { workspace, dataDir: cfg.dataDir }

    const coverageOf = async () => {
      const cookies = await loadVault(vaultOpts)
      const result = await loadData()
      const coverage: Record<string, number> = {}
      if (result.ok && result.data) {
        for (const host of Object.keys(result.data)) {
          const n = cookies.filter(c => cookieMatchesHost(c, host)).length
          if (n > 0) coverage[host] = n
        }
      }
      return { cookies, coverage }
    }

    ws?.register({
      kind: 'exact',
      path: '/dsh-sitemap/cookies',
      handler: async (_req, res) => {
        const { cookies, coverage } = await coverageOf()
        json(res, 200, { ok: true, total: cookies.length, cookies, coverage })
      },
    })

    ws?.register({
      kind: 'exact',
      path: '/dsh-sitemap/cookies-import',
      handler: async (req, res) => {
        const body = await readBody(req)
        let parsed: { text?: string; format?: string; domain?: string } = {}
        try {
          parsed = JSON.parse(body || '{}') as typeof parsed
        } catch { /* fall through */ }
        const text = (parsed.text ?? '').trim()
        if (!text) {
          json(res, 400, { ok: false, error: '缺少 text：粘贴 Cookie-Editor 导出的 JSON / Header String / Netscape 文本' })
          return
        }
        const format = (['json', 'header', 'netscape'].includes(parsed.format ?? '') ? parsed.format : detectFormat(text)) as CookieFormat
        let incoming: VaultCookie[]
        try {
          incoming = parseCookies(text, format, parsed.domain)
        } catch (err) {
          json(res, 400, { ok: false, error: String(err) })
          return
        }
        if (incoming.length === 0) {
          json(res, 400, { ok: false, error: '没解析到任何 cookie' })
          return
        }
        const existing = await loadVault(vaultOpts)
        const merged = mergeCookies(existing, incoming)
        await saveVault(vaultOpts, merged.cookies)
        const { coverage } = await coverageOf()
        json(res, 200, { ok: true, total: incoming.length, added: merged.added, vault: merged.cookies.length, format, coverage })
      },
    })

    ws?.register({
      kind: 'exact',
      path: '/dsh-sitemap/cookies-clear',
      handler: async (req, res) => {
        await readBody(req)
        const removed = await clearVault(vaultOpts)
        json(res, 200, { ok: true, removed })
      },
    })

    /* ---------------- agent tools (src workflow sync) ---------------- */

    const tools = (scope as unknown as { get?: (k: string) => unknown }).get?.('tools') as unknown as {
      register(t: unknown): unknown
    } | undefined
    if (!tools?.register) {
      scope.logger.warn('[dsh-sitemap] tools service unavailable — SRC workflow tools not registered')
      return
    }

    tools.register(defineTool({
      name: 'sitemap_query',
      description: [
        '查询站点地图（由 dsh-sitemap 插件维护）。不带参数返回全部主机与其接口数量；',
        '可按 q 子串过滤主机/路径、按 host 精确过滤某个主机，limit 控制返回条数。',
        'SRC 工作流可把它当作资产清单入口。',
      ].join(''),
      parameters: {
        q: { type: 'string', description: '子串过滤（主机名或路径，大小写不敏感）' },
        host: { type: 'string', description: '只看某个主机（精确匹配）' },
        limit: { type: 'integer', description: '最多返回多少条接口（默认 50）' },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            hosts: { type: 'integer', required: true },
            endpoints: { type: 'json', required: true },
          },
        },
        render: (_args: unknown, value: { ok: boolean; hosts: number; endpoints: Array<Record<string, unknown>> }) =>
          value.ok
            ? textBlock(`站点地图：${String(value.hosts)} 个主机，返回 ${String(value.endpoints.length)} 条接口\n`
              + value.endpoints.map(e => `${e.host ?? ''}${e.path ?? ''} [${(e.methods as string[]).join(',') || '?'}]`).join('\n'))
            : textBlock('站点地图暂无数据'),
      },
      async execute(args: { q?: string; host?: string; limit?: number }) {
        const result = await loadData()
        if (!result.ok || !result.data) return { ok: false, hosts: 0, endpoints: [] }
        const q = (args.q ?? '').trim().toLowerCase()
        const hostFilter = (args.host ?? '').trim().toLowerCase()
        const limit = Math.max(1, Math.min(200, args.limit ?? 50))
        const endpoints: Array<Record<string, unknown>> = []
        const hosts = hostFilter ? [hostFilter] : Object.keys(result.data).sort()
        const matchedHosts: string[] = []
        for (const h of hosts) {
          if (!result.data[h]) continue
          if (q && !h.toLowerCase().includes(q)) {
            /* host itself doesn't match; still check paths below */
          }
          let pushed = 0
          for (const p of Object.keys(result.data[h].endpoints).sort()) {
            if (q && !h.toLowerCase().includes(q) && !p.toLowerCase().includes(q)) continue
            if (endpoints.length >= limit) break
            const meta = result.data[h].endpoints[p]
            endpoints.push({ host: h, path: p, methods: meta.methods, count: meta.count, params: meta.params })
            pushed++
          }
          if (pushed > 0 || !q || h.toLowerCase().includes(q)) matchedHosts.push(h)
          if (endpoints.length >= limit) break
        }
        return { ok: true, hosts: matchedHosts.length, endpoints }
      },
    }))

    tools.register(defineTool({
      name: 'sitemap_cookie',
      description: [
        '从站点地图插件的 cookie 保险库取 cookie。给定 host 时返回该站点可用的 Cookie header、',
        '匹配的 cookie 明细（含 HttpOnly 标志），并附带注入浏览器的操作指引（先用 browser_add_cookies',
        '写入共享浏览器上下文，再 browser_navigate 即可带着身份访问目标）。不给 host 时返回保险库覆盖汇总。',
        'SRC 工作流用它自取凭据，不必再让用户在对话里粘贴 cookie。',
      ].join(''),
      parameters: {
        host: { type: 'string', description: '目标主机，例如 acme.example.com；省略则返回覆盖汇总' },
        format: { type: 'string', enum: ['header', 'json'], description: '返回形式：header 为 Cookie 请求头字符串，json 为 cookie 数组（默认 header）' },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            host: { type: 'string' },
            matched: { type: 'integer' },
            header: { type: 'string' },
            cookies: { type: 'json' },
            coverage: { type: 'json' },
            injectHint: { type: 'string' },
          },
        },
        render: (_args: unknown, value: Record<string, unknown>) => {
          if (!value.ok) return textBlock('cookie 保险库里没有匹配到该主机的 cookie')
          if (value.host && value.header) {
            const n = value.matched as number
            return textBlock(`目标 ${value.host} 匹配 ${String(n)} 个 cookie\nCookie: ${value.header}\n\n注入指引：${value.injectHint ?? ''}`)
          }
          const cov = value.coverage as Array<{ host: string; count: number }>
          return textBlock('cookie 覆盖汇总（host → cookie 数）：\n' + cov.map(c => `${c.host}  ${String(c.count)}`).join('\n'))
        },
      },
      async execute(args: { host?: string; format?: 'header' | 'json' }) {
        const { cookies, coverage } = await coverageOf()
        const host = (args.host ?? '').trim().toLowerCase()
        if (!host) {
          const cov = Object.entries(coverage).sort((a, b) => b[1] - a[1])
            .map(([h, count]) => ({ host: h, count }))
          return { ok: true, matched: 0, header: '', cookies: [], coverage: cov, injectHint: '' }
        }
        const matched = cookiesForHost(cookies, host)
        const header = buildCookieHeader(matched)
        return {
          ok: true,
          host,
          matched: matched.length,
          header,
          cookies: matched,
          coverage: [],
          injectHint: '调用 browser_add_cookies 把 cookies 数组写入共享浏览器，然后 browser_navigate 访问目标即可带着身份测试。',
        }
      },
    }))

    tools.register(defineTool({
      name: 'sitemap_regen',
      description: [
        '重新生成站点地图：从工作区侦察文件（all_host_apis.json、urls_by_host.json、',
        'cvp_urls_by_host.json、hll_apis.json、sdp_apis.json）全量覆盖合成 sitemap_data.json，',
        '历史残留站点会被清掉。返回生成统计，SRC 工作流开场可先调它刷新资产底图。',
      ].join(''),
      parameters: {},
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            hosts: { type: 'integer', required: true },
            endpoints: { type: 'integer', required: true },
            sources: { type: 'json', required: true },
          },
        },
        render: (_args: unknown, value: { ok: boolean; hosts: number; endpoints: number; sources: Array<Record<string, unknown>> }) =>
          textBlock(`站点地图已重新生成：${String(value.hosts)} 个主机 / ${String(value.endpoints)} 条接口\n来源：\n`
            + value.sources.map(s => `  ${s.file}${s.matched ? `  ✓ ${String(s.hosts)} hosts` : `  ✗ ${s.error ?? '跳过'}`}`).join('\n')),
      },
      async execute() {
        const result = await runRegen()
        return { ok: true, hosts: result.stats.hosts, endpoints: result.stats.endpoints, sources: result.stats.sources }
      },
    }))

    tools.register(defineTool({
      name: 'sitemap_import_cookie',
      description: [
        '把浏览器导出的 cookie 导入站点地图保险库：支持 Cookie-Editor 的 JSON、',
        'Header String、Netscape cookies.txt 三种格式（格式可自动识别）。导入后插件会自动',
        '计算每个站点被哪些 cookie 覆盖并标注。Header 形式没有域名，建议带上 domain 参数。',
      ].join(''),
      parameters: {
        text: { type: 'string', required: true, description: 'cookie 导出内容（JSON 数组 / Header 字符串 / Netscape 文本）' },
        format: { type: 'string', enum: ['json', 'header', 'netscape'], description: '显式指定格式；不传则自动识别' },
        domain: { type: 'string', description: 'Header 形式建议指定归属域名，例如 acme.example.com' },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            total: { type: 'integer', required: true },
            added: { type: 'integer', required: true },
            vault: { type: 'integer', required: true },
            format: { type: 'string', required: true },
            coverage: { type: 'json', required: true },
          },
        },
        render: (_args: unknown, value: { ok: boolean; total: number; added: number; vault: number; format: string; coverage: Record<string, number> }) =>
          textBlock(`已导入 ${String(value.total)} 个 cookie（${value.format}，新增 ${String(value.added)}），保险库共 ${String(value.vault)} 个\n`
            + `新覆盖站点：${Object.entries(value.coverage).map(([h, n]) => `${h} ×${String(n)}`).join('、') || '无'}`),
      },
      async execute(args: { text: string; format?: 'json' | 'header' | 'netscape'; domain?: string }) {
        const text = (args.text ?? '').trim()
        if (!text) throw new Error('text 不能为空')
        const format = args.format ?? detectFormat(text)
        const incoming = parseCookies(text, format, args.domain)
        if (incoming.length === 0) throw new Error('没解析到任何 cookie')
        const existing = await loadVault(vaultOpts)
        const merged = mergeCookies(existing, incoming)
        await saveVault(vaultOpts, merged.cookies)
        const { coverage } = await coverageOf()
        return { ok: true, total: incoming.length, added: merged.added, vault: merged.cookies.length, format, coverage }
      },
    }))

    scope.logger.info(`[dsh-sitemap] routes + SRC workflow tools ready (data dir: ${dataDir})`)
  })
}