/**
 * dsh-sitemap browser half — Yakit-style site map:
 *  - Sidebar footer action "🗺 站点地图" opens a full-screen Modal.
 *  - Left column: host tree (host → endpoint), collapsible, per-host colors.
 *  - Right column: endpoint details + copy-curl / open + matched-cookie section.
 *  - Header controls: 重新生成 / 清空 / Cookie 保险库 / 刷新 / 关闭.
 *  - Cookie vault: import (JSON / Header / Netscape), coverage badges 🍪.
 */
import { useState, useEffect, useCallback, useMemo } from 'react'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type { SidebarFooterActionOwnerProps } from '@deepseek-ai/dsh-client-ui-sidebar/client'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    sitemap: 'title' | 'hint' | 'error' | 'loading' | 'empty' | 'refresh' | 'regen' | 'regenDone' | 'clearMap' | 'close' | 'search' | 'cookies'
  }
}

const NS = 'sitemap'
const zh = {
  title: '站点地图', hint: '打开按主机分组的接口地图', error: '加载站点地图失败',
  loading: '加载中…', empty: '暂无接口数据（先点「重新生成」或导入 sitemap_data.json）',
  refresh: '刷新', regen: '重新生成', regenDone: '已重新生成', clearMap: '清空', close: '关闭', search: '搜索接口…', cookies: 'Cookie 保险库',
}
const en = {
  title: 'Site Map', hint: 'Open the host-grouped API map', error: 'Failed to load site map',
  loading: 'Loading…', empty: 'No endpoint data yet', refresh: 'Refresh', regen: 'Regenerate',
  regenDone: 'Regenerated', clearMap: 'Clear', close: 'Close', search: 'Search…', cookies: 'Cookie Vault',
}

export const inject = ['slots', 'locale']

interface EpMeta { methods?: string[]; count?: number; params?: string[]; sources?: string[] }
type HostMap = Record<string, { endpoints: Record<string, EpMeta> }>
interface VaultCookie {
  name: string; value: string; domain: string; hostOnly?: boolean; path: string;
  secure: boolean; httpOnly: boolean; sameSite?: string; source: string; addedAt: string;
}

/* ------------------------------------------------------------------ colors */

const HOST_PALETTE = [
  '#1f6feb', '#0ca678', '#d9480f', '#7048e8', '#c2255c', '#0b7285',
  '#66a80f', '#3b5bdb', '#e8590c', '#1098ad', '#8a2be2', '#2b8a3e',
  '#d6336c', '#5f3dc4',
]

function hashStr(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0
  return Math.abs(h)
}

function hostColor(host: string): string {
  return HOST_PALETTE[hashStr(host) % HOST_PALETTE.length]
}

/* ------------------------------------------------------------------ entry */

export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-sitemap: dictionaries')
  ctx.inject(['slots', 'locale'], (scope: ClientContext) => {
    scope.effect(
      () => scope.slots.register(
        { name: 'sidebar.footer.action', id: 'dsh-sitemap', order: 40, locale: NS },
        SitemapAction,
      ),
      'dsh-sitemap: sidebar action',
    )
  })
}

/* ------------------------------------------------------------------ action */

function SitemapAction(props: SidebarFooterActionOwnerProps & { t: (k: 'title' | 'hint') => string }): JSX.Element {
  const { t } = props
  const [open, setOpen] = useState(false)
  return (
    <>
      <button
        type="button"
        title={t('hint')}
        onClick={() => setOpen(true)}
        style={{
          display: 'flex', alignItems: 'center', gap: 8, width: '100%',
          padding: '6px 10px', background: 'none', border: 'none',
          color: 'inherit', cursor: 'pointer', fontSize: 13, textAlign: 'left',
        }}
      >
        <span role="img" aria-hidden="true">🗺</span>
        {props.wide ? <span>{t('title')}</span> : null}
      </button>
      {open ? <SitemapModal onClose={() => setOpen(false)} /> : null}
    </>
  )
}

/* ------------------------------------------------------------------ modal */

function SitemapModal({ onClose }: { onClose: () => void }): JSX.Element {
  const [data, setData] = useState<HostMap | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<{ host: string; ep: string } | null>(null)
  const [expanded, setExpanded] = useState<Set<string>>(new Set())
  const [cookieCache, setCookieCache] = useState<VaultCookie[]>([])
  const [coverage, setCoverage] = useState<Record<string, number>>({})
  const [regenNote, setRegenNote] = useState<string | null>(null)
  const [vaultOpen, setVaultOpen] = useState(false)
  const [busy, setBusy] = useState(false)

  const getData = useCallback(async () => {
    const res = await fetch('/dsh-sitemap/data', { cache: 'no-store' })
    if (!res.ok) throw new Error('HTTP ' + res.status)
    const payload = (await res.json()) as { ok: boolean; data?: HostMap; error?: string }
    if (!payload.ok) throw new Error(payload.error ?? 'bad payload')
    setData(payload.data ?? null)
  }, [])

  const getCookies = useCallback(async () => {
    try {
      const res = await fetch('/dsh-sitemap/cookies', { cache: 'no-store' })
      if (!res.ok) return
      const payload = (await res.json()) as { ok: boolean; cookies?: VaultCookie[]; coverage?: Record<string, number> }
      if (!payload.ok) return
      setCookieCache(payload.cookies ?? [])
      setCoverage(payload.coverage ?? {})
    } catch { /* vault route absent → ignore */ }
  }, [])

  const load = useCallback(async () => {
    setError(null)
    try {
      await getData()
    } catch (err) {
      setData(null)
      setError(String(err instanceof Error ? err.message : err))
    }
    void getCookies()
  }, [getData, getCookies])

  useEffect(() => { void load() }, [load])

  const refreshState = useCallback(async () => {
    await getData()
    await getCookies()
  }, [getData, getCookies])

  const doRegen = async (): Promise<void> => {
    setBusy(true)
    setRegenNote(null)
    try {
      const res = await fetch('/dsh-sitemap/regen', { method: 'POST', cache: 'no-store' })
      if (!res.ok) throw new Error('HTTP ' + res.status)
      const payload = (await res.json()) as { ok: boolean; data?: HostMap; stats?: { hosts: number; endpoints: number; sources: Array<{ file: string; matched: boolean }> } }
      if (!payload.ok) throw new Error('生成失败')
      setData(payload.data ?? null)
      setError(null)
      setSelected(null)
      setExpanded(new Set())
      const s = payload.stats
      const files = s ? s.sources.filter(x => x.matched).map(x => x.file).join('、') : ''
      setRegenNote(s ? `已生成 ${s.hosts} hosts · ${s.endpoints} eps（来源：${files || '无匹配文件'}）` : '已重新生成')
      setTimeout(() => setRegenNote(null), 8000)
      await getCookies()
    } catch (err) {
      setError('重新生成失败：' + String(err instanceof Error ? err.message : err))
    } finally {
      setBusy(false)
    }
  }

  const doClearMap = async (): Promise<void> => {
    if (!window.confirm('清空整个站点地图（sitemap_data.json 会被删除）？')) return
    setBusy(true)
    try {
      const res = await fetch('/dsh-sitemap/clear', { method: 'POST', cache: 'no-store' })
      if (!res.ok) throw new Error('HTTP ' + res.status)
      setData(null)
      setSelected(null)
      setError(null)
    } catch (err) {
      setError('清空失败：' + String(err instanceof Error ? err.message : err))
    } finally {
      setBusy(false)
    }
  }

  const doRemoveHost = async (host: string): Promise<void> => {
    if (!window.confirm(`从站点地图删除「${host}」？`)) return
    try {
      const res = await fetch('/dsh-sitemap/host-remove', {
        method: 'POST', cache: 'no-store',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ host }),
      })
      const payload = (await res.json()) as { ok: boolean; data?: HostMap }
      if (!payload.ok) throw new Error('删除失败')
      setData(payload.data ?? null)
      if (selected?.host === host) setSelected(null)
    } catch (err) {
      setError('删除站点失败：' + String(err instanceof Error ? err.message : err))
    }
  }

  const toggle = (key: string): void => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  const hosts = useMemo(() => (data ? Object.keys(data).sort() : []), [data])

  const filteredHosts = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return hosts
    return hosts.filter((h) => {
      const eps = data?.[h]?.endpoints ?? {}
      return h.toLowerCase().includes(q) || Object.keys(eps).some((e) => e.toLowerCase().includes(q))
    })
  }, [hosts, query, data])

  const selectedMeta = selected && data?.[selected.host]?.endpoints?.[selected.ep]
  const totalEps = data ? Object.values(data).reduce((a, h) => a + Object.keys(h.endpoints ?? {}).length, 0) : 0

  const overlay: React.CSSProperties = {
    position: 'fixed', inset: 0, zIndex: 9999,
    background: 'rgba(15,20,30,0.72)', display: 'flex', alignItems: 'center', justifyContent: 'center',
  }
  const panel: React.CSSProperties = {
    width: 'min(1180px, 94vw)', height: 'min(760px, 90vh)',
    background: '#fff', borderRadius: 10, display: 'flex', flexDirection: 'column',
    boxShadow: '0 18px 60px rgba(0,0,0,.35)', overflow: 'hidden',
  }
  const header: React.CSSProperties = {
    display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px',
    borderBottom: '1px solid #e6e8ec', background: '#fafbfc', flexWrap: 'wrap',
  }
  const input: React.CSSProperties = {
    flex: 1, maxWidth: 360, minWidth: 160, padding: '7px 10px', borderRadius: 6,
    border: '1px solid #d0d5dd', fontSize: 13,
  }
  const body: React.CSSProperties = { flex: 1, display: 'flex', minHeight: 0 }
  const left: React.CSSProperties = {
    width: 400, borderRight: '1px solid #e6e8ec', overflowY: 'auto', padding: '8px 6px', background: '#fcfcfd',
  }
  const right: React.CSSProperties = {
    flex: 1, overflowY: 'auto', padding: '14px 16px', fontFamily: 'Consolas, monospace',
    fontSize: 12.5, color: '#1f2937',
  }
  const btn: React.CSSProperties = {
    padding: '6px 12px', borderRadius: 6, border: '1px solid #d0d5dd',
    background: '#fff', cursor: 'pointer', fontSize: 12.5,
  }
  const primBtn: React.CSSProperties = { ...btn, background: '#1f6feb', borderColor: '#1f6feb', color: '#fff' }

  const copyText = async (text: string): Promise<boolean> => {
    try {
      await navigator.clipboard.writeText(text)
      return true
    } catch {
      return false
    }
  }

  return (
    <div style={overlay} onClick={vaultOpen ? undefined : onClose}>
      <div style={panel} onClick={(e) => e.stopPropagation()}>
        <div style={header}>
          <span style={{ fontSize: 15, fontWeight: 600 }}>🗺 站点地图</span>
          <input style={input} placeholder="搜索接口…" value={query} onChange={(e) => setQuery(e.target.value)} />
          <span style={{ fontSize: 12, color: '#98a2b3' }}>{hosts.length} hosts · {totalEps} eps</span>
          <span style={{ flex: 1 }} />
          <button onClick={() => void doRegen()} disabled={busy} style={primBtn}>重新生成</button>
          <button onClick={() => void doClearMap()} disabled={busy} style={btn}>清空</button>
          <button onClick={() => setVaultOpen(true)} style={btn}>🍪 保险库 ({cookieCache.length})</button>
          <button onClick={() => void refreshState()} style={btn}>刷新</button>
          <button onClick={onClose} style={btn}>关闭</button>
        </div>
        {regenNote ? (
          <div style={{ padding: '6px 14px', background: '#ecfdf3', color: '#067647', fontSize: 12.5, borderBottom: '1px solid #d1fadf' }}>
            ✓ {regenNote}
          </div>
        ) : null}
        <div style={body}>
          <div style={left}>
            {error ? <div style={{ padding: 16, color: '#d92d20', fontSize: 12.5 }}>{error}</div> : null}
            {!data && !error ? <div style={{ padding: 16, color: '#98a2b3' }}>加载中…</div> : null}
            {data && filteredHosts.length === 0 && !error ? (
              <div style={{ padding: 16, color: '#98a2b3' }}>
                暂无匹配
                <div style={{ marginTop: 10 }}>
                  <button onClick={() => void doRegen()} style={primBtn}>重新生成站点地图</button>
                </div>
              </div>
            ) : null}
            {!data && !error ? (
              <div style={{ padding: 16, color: '#98a2b3' }}>
                还没有站点地图数据。
                <div style={{ marginTop: 10 }}>
                  <button onClick={() => void doRegen()} style={primBtn}>从工作区侦察文件生成</button>
                </div>
              </div>
            ) : null}
            {data ? filteredHosts.map((h) => {
              const eps = data[h]?.endpoints ?? {}
              const keys = Object.keys(eps).sort()
              const openKey = 'h:' + h
              const isOpen = expanded.has(openKey)
              const color = hostColor(h)
              const cov = coverage[h] ?? 0
              return (
                <div key={h} style={{ marginBottom: 4 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, borderRadius: 6, padding: '4px 6px', background: isOpen ? color + '14' : 'transparent' }}>
                    <div
                      onClick={() => toggle(openKey)}
                      style={{ cursor: 'pointer', flex: 1, display: 'flex', alignItems: 'center', gap: 6, padding: '2px 2px', fontSize: 13, fontWeight: 600, minWidth: 0 }}
                    >
                      <span style={{ width: 9, height: 9, borderRadius: '50%', background: color, flexShrink: 0 }} />
                      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{isOpen ? '▾' : '▸'} {h}</span>
                      <span style={{ color: color, fontSize: 11, flexShrink: 0 }}>{keys.length}</span>
                      {cov > 0 ? <span style={{ fontSize: 10, background: '#12b76a', color: '#fff', borderRadius: 8, padding: '1px 6px', flexShrink: 0 }}>🍪 {cov}</span> : null}
                    </div>
                    <span
                      title={`删除站点 ${h}`}
                      onClick={(e) => { e.stopPropagation(); void doRemoveHost(h) }}
                      style={{ cursor: 'pointer', color: '#98a2b3', fontSize: 12, padding: '0 4px', flexShrink: 0 }}
                    >
                      🗑
                    </span>
                  </div>
                  {isOpen ? (
                    <div style={{ paddingLeft: 12 }}>
                      {keys.map((e) => {
                        const meta = eps[e] ?? {}
                        const isSel = selected?.host === h && selected?.ep === e
                        return (
                          <div
                            key={e}
                            onClick={() => setSelected({ host: h, ep: e })}
                            style={{
                              cursor: 'pointer', padding: '4px 8px', borderRadius: 4,
                              fontSize: 12, fontFamily: 'Consolas, monospace',
                              background: isSel ? color + '1a' : 'transparent',
                              borderLeft: isSel ? `2px solid ${color}` : '2px solid transparent',
                            }}
                          >
                            {e}
                            <span style={{ color: '#98a2b3', fontSize: 10, marginLeft: 6 }}>{(meta.methods ?? []).join(',') || '?'}</span>
                          </div>
                        )
                      })}
                    </div>
                  ) : null}
                </div>
              )
            }) : null}
          </div>
          <div style={right}>
            {selected && selectedMeta ? <EndpointDetail host={selected.host} ep={selected.ep} meta={selectedMeta} cookies={cookieCache} coverage={coverage} copyText={copyText} /> : (
              <div style={{ color: '#98a2b3' }}>← 选择左侧接口查看详情（含 cookie 覆盖标注）</div>
            )}
          </div>
        </div>
      </div>
      {vaultOpen ? (
        <CookieVault
          cookies={cookieCache}
          coverage={coverage}
          onClose={() => setVaultOpen(false)}
          onChanged={() => { void getCookies() }}
          copyText={copyText}
        />
      ) : null}
    </div>
  )
}

/* ------------------------------------------------------------------ detail */

function EndpointDetail(props: {
  host: string
  ep: string
  meta: EpMeta
  cookies: VaultCookie[]
  coverage: Record<string, number>
  copyText: (t: string) => Promise<boolean>
}): JSX.Element {
  const { host, ep, meta, cookies, copyText } = props
  const color = hostColor(host)
  const [copiedCurl, setCopiedCurl] = useState(false)
  const [copiedCookie, setCopiedCookie] = useState(false)

  const cookieMatches = useMemo(() => {
    const h = host.toLowerCase()
    return cookies.filter((c) => {
      const d = String(c.domain).replace(/^\.+/, '').toLowerCase()
      if (!h || !d) return false
      if (c.hostOnly) return h === d
      return h === d || h.endsWith('.' + d)
    })
  }, [cookies, host])

  const btn: React.CSSProperties = {
    padding: '6px 12px', borderRadius: 6, border: '1px solid #d0d5dd',
    background: '#fff', cursor: 'pointer', fontSize: 12.5, marginRight: 8,
  }
  const kv: React.CSSProperties = { padding: '6px 0', borderBottom: '1px solid #f0f1f3' }

  const copyCurl = async (): Promise<void> => {
    const ok = await copyText('curl -sk "https://' + host + ep + '"')
    if (ok) { setCopiedCurl(true); setTimeout(() => setCopiedCurl(false), 1200) }
  }

  const copyCookieHeader = async (): Promise<void> => {
    const ok = await copyText(cookieMatches.map(c => `${c.name}=${c.value}`).join('; '))
    if (ok) { setCopiedCookie(true); setTimeout(() => setCopiedCookie(false), 1200) }
  }

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: color, display: 'inline-block' }} />
        <span style={{ fontSize: 15, fontWeight: 600, wordBreak: 'break-all' }}>{ep}</span>
      </div>
      <div style={kv}>Host: <b style={{ color }}>{host}</b></div>
      <div style={kv}>Method: {(meta.methods ?? ['?']).join(', ') || '?'}</div>
      <div style={kv}>Params: {(meta.params ?? []).join(', ') || '—'}</div>
      <div style={kv}>Count: {String(meta.count ?? 1)}</div>
      {meta.sources?.length ? <div style={kv}>来源: {meta.sources.join('、')}</div> : null}
      <div style={{ marginTop: 14 }}>
        <button onClick={() => void copyCurl()} style={btn}>{copiedCurl ? '✓ 已复制' : '复制 curl'}</button>
        <button onClick={() => { window.open('https://' + host + ep, '_blank', 'noopener') }} style={btn}>打开</button>
      </div>
      <div style={{ marginTop: 18, borderTop: '1px solid #f0f1f3', paddingTop: 12 }}>
        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
          Cookie 覆盖：{cookieMatches.length > 0 ? <span style={{ color: '#12b76a' }}>✓ {cookieMatches.length} 个匹配</span> : <span style={{ color: '#98a2b3' }}>无</span>}
        </div>
        {cookieMatches.length > 0 ? (
          <>
            <div style={{ background: '#f8fafc', border: '1px solid #eef1f5', borderRadius: 6, padding: '8px 10px', maxHeight: 180, overflowY: 'auto' }}>
              {cookieMatches.map((c) => (
                <div key={c.domain + c.name + c.path} style={{ padding: '3px 0', fontSize: 12 }}>
                  <b>{c.name}</b> <span style={{ color: '#98a2b3' }}>=</span> <span>{c.value.slice(0, 48)}{c.value.length > 48 ? '…' : ''}</span>
                  <span style={{ color: '#98a2b3', fontSize: 10, marginLeft: 6 }}>{c.domain} {c.httpOnly ? '·HttpOnly' : ''}{c.secure ? '·Secure' : ''}</span>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 8 }}>
              <button onClick={() => void copyCookieHeader()} style={{ ...btn, background: '#ecfdf3', borderColor: '#abefc6' }}>
                {copiedCookie ? '✓ 已复制' : '复制 Cookie Header'}
              </button>
              <span style={{ fontSize: 11, color: '#98a2b3' }}>给 src 工作流：sitemap_cookie host={host} 自取，browser_add_cookies 注入浏览器</span>
            </div>
          </>
        ) : (
          <div style={{ fontSize: 12, color: '#98a2b3' }}>在「🍪 保险库」导入 Cookie-Editor 导出的 JSON / Header / Netscape，即可自动标注可访问站点。</div>
        )}
      </div>
    </div>
  )
}

/* ---------------------------------------------------------- cookie vault */

function CookieVault(props: {
  cookies: VaultCookie[]
  coverage: Record<string, number>
  onClose: () => void
  onChanged: () => void
  copyText: (t: string) => Promise<boolean>
}): JSX.Element {
  const { cookies, coverage, onClose, onChanged, copyText } = props
  const [text, setText] = useState('')
  const [format, setFormat] = useState<'auto' | 'json' | 'header' | 'netscape'>('auto')
  const [domain, setDomain] = useState('')
  const [note, setNote] = useState<string | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const doImport = async (): Promise<void> => {
    if (!text.trim()) { setErr('先粘贴 cookie 内容（JSON / Header / Netscape）'); return }
    setBusy(true)
    setErr(null)
    setNote(null)
    try {
      const res = await fetch('/dsh-sitemap/cookies-import', {
        method: 'POST', cache: 'no-store',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, format: format === 'auto' ? undefined : format, domain: domain.trim() || undefined }),
      })
      const payload = (await res.json()) as { ok: boolean; error?: string; total?: number; added?: number; vault?: number; coverage?: Record<string, number> }
      if (!payload.ok) throw new Error(payload.error ?? '导入失败')
      const cov = payload.coverage ?? {}
      const hosts = Object.keys(cov)
      setNote(`✓ 导入 ${payload.total} 个（新增 ${payload.added}），保险库共 ${payload.vault} 个${hosts.length ? `；新覆盖：${hosts.map(h => `${h} ×${cov[h]}`).join('、')}` : ''}`)
      setText('')
      onChanged()
    } catch (e) {
      setErr(String(e instanceof Error ? e.message : e))
    } finally {
      setBusy(false)
    }
  }

  const doClear = async (): Promise<void> => {
    if (!window.confirm('清空整个 cookie 保险库？')) return
    try {
      await fetch('/dsh-sitemap/cookies-clear', { method: 'POST', cache: 'no-store' })
      setNote('已清空保险库')
      onChanged()
    } catch (e) {
      setErr(String(e instanceof Error ? e.message : e))
    }
  }

  const overlay: React.CSSProperties = {
    position: 'fixed', inset: 0, zIndex: 10001,
    background: 'rgba(15,20,30,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center',
  }
  const panel: React.CSSProperties = {
    width: 'min(760px, 92vw)', maxHeight: '86vh', overflowY: 'auto',
    background: '#fff', borderRadius: 10, padding: 18, boxShadow: '0 18px 60px rgba(0,0,0,.35)',
  }
  const btn: React.CSSProperties = {
    padding: '6px 12px', borderRadius: 6, border: '1px solid #d0d5dd', background: '#fff', cursor: 'pointer', fontSize: 12.5,
  }
  const input: React.CSSProperties = {
    padding: '7px 10px', borderRadius: 6, border: '1px solid #d0d5dd', fontSize: 13,
  }

  return (
    <div style={overlay} onClick={onClose}>
      <div style={panel} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>
          <span style={{ fontSize: 15, fontWeight: 600 }}>🍪 Cookie 保险库</span>
          <span style={{ fontSize: 12, color: '#98a2b3', marginLeft: 10 }}>{cookies.length} 个 cookie · 覆盖 {Object.keys(coverage).length} 个站点</span>
          <span style={{ flex: 1 }} />
          <button onClick={() => void doClear()} style={btn}>清空</button>
          <button onClick={onClose} style={{ ...btn, marginLeft: 8 }}>关闭</button>
        </div>

        <div style={{ background: '#f8fafc', border: '1px solid #eef1f5', borderRadius: 8, padding: 12, marginBottom: 12 }}>
          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>导入浏览器 Cookie</div>
          <div style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <select value={format} onChange={(e) => setFormat(e.target.value as 'auto' | 'json' | 'header' | 'netscape')} style={input}>
              <option value="auto">自动识别格式</option>
              <option value="json">Cookie-Editor JSON</option>
              <option value="header">Header String</option>
              <option value="netscape">Netscape cookies.txt</option>
            </select>
            <input
              style={{ ...input, flex: 1, minWidth: 200 }}
              placeholder="适用域名（Header 形式建议填，如 acme.example.com）"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
            />
          </div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={'粘贴导出内容：\n· Cookie-Editor「Export → JSON」\n· Cookie: a=1; b=2 形式的 Header\n· Netscape cookies.txt'}
            style={{ width: '100%', minHeight: 110, borderRadius: 6, border: '1px solid #d0d5dd', padding: 8, fontSize: 12, fontFamily: 'Consolas, monospace', boxSizing: 'border-box' }}
          />
          <div style={{ display: 'flex', alignItems: 'center', marginTop: 8, gap: 10 }}>
            <button onClick={() => void doImport()} disabled={busy} style={{ ...btn, background: '#1f6feb', borderColor: '#1f6feb', color: '#fff' }}>
              {busy ? '导入中…' : '导入'}
            </button>
            {note ? <span style={{ fontSize: 12, color: '#067647' }}>{note}</span> : null}
            {err ? <span style={{ fontSize: 12, color: '#d92d20' }}>{err}</span> : null}
          </div>
          <div style={{ fontSize: 11, color: '#98a2b3', marginTop: 8 }}>
            导入后自动按域名匹配站点地图并打 🍪 标注；保险库存在工作区，不进插件仓库。向浏览器注入由 src 工作流调用 sitemap_cookie + browser_add_cookies 完成。
          </div>
        </div>

        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6 }}>已存 Cookie</div>
        {cookies.length === 0 ? (
          <div style={{ color: '#98a2b3', fontSize: 12 }}>保险库是空的</div>
        ) : (
          <div style={{ border: '1px solid #eef1f5', borderRadius: 8, overflow: 'hidden' }}>
            {cookies.slice(0, 300).map((c) => (
              <div key={c.domain + c.name + c.path} style={{ display: 'flex', gap: 8, padding: '5px 10px', borderBottom: '1px solid #f2f4f7', fontSize: 12, alignItems: 'center' }}>
                <b style={{ flexShrink: 0 }}>{c.name}</b>
                <span style={{ color: '#667085', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.value.slice(0, 40)}</span>
                <span style={{ color: '#98a2b3', flexShrink: 0, marginLeft: 'auto' }}>{c.domain}{c.hostOnly ? '·hostOnly' : ''}{c.httpOnly ? '·HttpOnly' : ''} · {c.source}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}