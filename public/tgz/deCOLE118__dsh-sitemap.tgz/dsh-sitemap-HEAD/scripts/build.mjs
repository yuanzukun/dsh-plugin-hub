/**
 * Build dsh-sitemap bundles:
 * - lib/index.js  — host cordis plugin (ESM, harness externals)
 * - lib/client.js — browser half in module-loader factory format
 */
import { build } from 'esbuild'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))

const HOST_EXTERNALS = ['@deepseek-ai/cordis', '@deepseek-ai/dsh-tools']

await build({
  absWorkingDir: root,
  bundle: true,
  entryPoints: ['src/index.ts'],
  outfile: 'lib/index.js',
  format: 'esm',
  platform: 'node',
  target: ['es2022'],
  external: HOST_EXTERNALS,
  logLevel: 'info',
  sourcemap: true,
})

await build({
  absWorkingDir: root,
  bundle: true,
  entryPoints: ['src/client/index.tsx'],
  outfile: 'lib/client.js',
  format: 'cjs',
  platform: 'browser',
  target: ['es2022'],
  jsx: 'automatic',
  external: ['@deepseek-ai/*', 'react', 'react/jsx-runtime'],
  banner: {
    js: [
      "window.__ModuleLoader__.load({ id: '@dsh-external/dsh-sitemap', factory: (require) => {",
      'var module = { exports: {} }; var exports = module.exports;',
    ].join('\n'),
  },
  footer: { js: 'return module.exports; } });' },
  define: { 'process.env.NODE_ENV': '"production"' },
  minify: true,
  logLevel: 'info',
  sourcemap: true,
})

console.log('dsh-sitemap: bundles built')
