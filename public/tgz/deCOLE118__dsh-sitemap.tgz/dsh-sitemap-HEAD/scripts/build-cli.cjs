// build via global esbuild CLI
const { execFileSync } = require('node:child_process')
const path = require('node:path')
const root = __dirname + '/..'
const esb = process.env.ESBUILD_BIN || 'esbuild'
const run = (args) => execFileSync(esb, args, { cwd: root, stdio: 'inherit' })

// host
run(['src/index.ts', '--bundle', '--format=esm', '--platform=node', '--target=es2022',
  '--external:@deepseek-ai/cordis', '--outfile=lib/index.js', '--sourcemap'])

// client with ModuleLoader wrapper
const banner = "window.__ModuleLoader__.load({ id: 'dsh-sitemap', factory: (require) => {\nvar module = { exports: {} }; var exports = module.exports;"
const footer = 'return module.exports; } });'
run(['src/client/index.tsx', '--bundle', '--format=cjs', '--platform=browser', '--target=es2022',
  '--jsx=automatic', '--external:@deepseek-ai/*', '--external:react', '--external:react/jsx-runtime',
  "--define:process.env.NODE_ENV='production'", '--minify',
  '--banner:js=' + banner, '--footer:js=' + footer,
  '--outfile=lib/client.js', '--sourcemap'])

console.log('dsh-sitemap: built')
