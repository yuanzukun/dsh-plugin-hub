# 星露谷操作参考（dsh-junimo）

> 这份文件是给模型按需读的长文档；常驻提示词里只有压缩过的纪律。
> 工具本体来自 [Junimo-MCP](https://github.com/mlkgrnt/Junimo-MCP)（OCaml 单 exe，37 个意图工具），
> 本插件只负责把它接进 DeepSeek Harness。

## 数据流

```
你 → mcp__junimo__<工具> → junimo-mcp.exe → HTTP(localhost:7850) → 执行器 mod（JunimoBridge）→ 游戏
```

时序等待、游戏侧校验、失败回滚都在 exe 内部完成。你不需要、**也不应该**自己加延时。

## 开工前 30 秒自检

1. **exe 在吗** → `junimo_doctor`
2. **游戏在跑吗** → `junimo_doctor` 会看 7850 端口；没起就 `junimo_game_launch`
3. **进档了吗** → `junimo_doctor` 报 `worldReady=false` 就 `junimo_load_save`
4. **工具齐吗** → 应有 37 个 `mcp__junimo__*`；少了说明 exe 是旧版或没挂上

## 十条铁律

1. **收尾必睡**。只有 `sleep` 落盘；不睡直接结束 = 当天所有操作回滚。 **v3.2.4 起 `sleep` 会核对存档文件 mtime：写不进去会直接报错——别忽略那个报错，它意味着当天进度丢了（再睡一觉通常就好）。**
2. **信任工具反馈，不要脑补**。报成功 = 游戏里真发生；报错 = 真没发生。失败大多无副作用（送礼失败退礼、吃东西失败不扣食物、取物放不下留在箱里），可以放心重试或换方法。
3. **工具是同步的，且内含等待**。按返回决定下一步，不要连发动作抢进度。
4. **长时间挂机先 `pause_time`**。现实约 12 分钟游戏内就走到凌晨 2:00，角色晕倒并扣钱。收尾 `resume_time`。
5. **移动失败别硬刚**。`go_to` 报寻路失败 = 真到不了（服务器拒绝穿墙回退）；报「已到达目标附近」= 目标格站不住、停在相邻格，**视为到达**。
6. **菜单/剧情基本不用操心**。无选项对话会自动按 confirm 推进（NPC 招呼 / 送礼答谢 / 提示框）；**剧情永不自动按掉**——要看就用 `story`，不想看才 `press_key skip`（不可回放）。带选项的问题框 / 商店 / 箱子会挡下来，报错里直接给原文和序号选项。
7. **背包容量**。`harvest` 或大量取物前先 `get_inventory`；背包满时收获物会掉地上。
8. **体力管理**。批量农活在体力 <15% 时主动中止；低了就 `eat` 或回家 `sleep`。
9. **「没有需要浇水的作物」不是错误**。雨天、洒水器覆盖、刚浇过都会这样回答，如实接受。
10. **节日查询用 `festival`**（今天/明天/下一个）；参加节日要走游戏原生入口，别 `warp` 到节日场地（不触发场景）。

## 工具速查（37 个）

| 我想… | 工具 | 关键说明 |
|---|---|---|
| 看状态（位置/时间/天气/钱/背包） | `get_state` | 返回末尾的 `── [..]` 行是**状态速报**，多数工具的返回都带它 |
| 看周围有什么（作物/物件/NPC） | `look` | 带半径参数 |
| 只看背包 | `get_inventory` | 水壶附余水量 |
| 看地图情报（建筑/传送点） | `map_info` | 导航规划用 |
| 走到某处 | `go_to` | 长距自动分段；≤1 格容差 |
| 换地图 | `warp` | 落点由游戏决定（安全落点） |
| 转向 | `face` | 0上/1右/2下/3左 |
| 锄地 / 播种 / 浇水 / 收割（批量） | `till` / `plant` / `water` / `harvest` | 支持区域与自动扫描，**别一格一格调** |
| 找东西在哪个箱子 | `chest_scan` | 全图箱子 + 内容 + 格号 |
| 从箱子取物 | `chest_take` | 按 `name` 或 `slot`；`count` 缺省=全部 |
| 跨箱凑一份清单 | `chest_take_list` | items 写 `"物品名 xN"`；只取 4 格内的箱子，够不着的会列坐标 |
| 存东西进箱子 | `chest_store` | 按名字存；工具默认不存 |
| 快速读某个箱子 | `chest_read` | 不用开箱 |
| 吃（回体力/HP/buff） | `eat` | 给 `name` 会自动选中；不给=吃当前手持 |
| 找 NPC | `find_npc` | 中英文名，全地图 |
| 查好感 | `friendship` | 点数/心数/本周与今日送礼数 |
| 送礼 | `gift` | 真实送礼流程；每天 1 次/每周 2 次，送满会明确报错并退礼 |
| 节日情报 | `festival` | 今天/明天/下一个 + 进行中活动状态 |
| 节日现场互动 / 问答 | `festival_interact` / `festival_answer` | 仅活动进行中可用 |
| 买东西 | `buy` | 远程购买（无商店界面，按售价×2 计价） |
| 卖东西（发货箱） | `ship` | 给 `name` 或 `all=true`；需在农场 |
| 睡觉（★落盘） | `sleep` | **唯一存档方式**；返回新一天状态 |
| 冻结 / 恢复时间 | `pause_time` / `resume_time` | 长任务与挂机必用 |
| 菜单操作 | `menu_read` / `menu_click` / `press_key` | 先读后点；press_key 可发 confirm/cancel/数字键 |
| 看剧情 / 推进剧情 | `story` | `read`/`next`/`choose option=N`/`skip`；`choose` 内部两段式 |
| 关菜单 | `menu_close` | 睡完的 SaveGameMenu、夜里的 ShippingMenu 必须关掉才能继续 |
| 选中物品 / 用手持 / 挥工具 / 与面前格交互 | `select_item` / `use_held` / `swing_tool` / `interact` | 播种放置用 `use_held`；对话 NPC 用 `interact` |

> 37 个工具**覆盖不到**的能力（按住输入=蓄力/抛竿、窗口与焦点探针、结构化菜单）见 [附录 A](#附录-a原始端点逃生通道工具覆盖不到时)。

## 一个标准工作日

1. `get_state` — 看日期、天气、体力、位置（速报行就够）
2. `look` — 哪些要浇水、哪些能收
3. `water` → `harvest`
4. 要扩种：`buy`（买种子）→ `till` → `plant` → `water`
5. 体力不足：`eat`；（真的累了才）`sleep`
6. 其它：社交 `find_npc`/`friendship`/`gift`；取物资 `chest_scan`/`chest_take(_list)`
7. 收尾：跑过 `pause_time` 就 `resume_time`，然后 **`sleep` 落盘**

## 常见错误 → 正确姿势

| ❌ 错误做法 | ✅ 正确做法 |
|---|---|
| 干完活直接结束回合 | 先 `sleep`，或明确告诉用户「尚未存档」 |
| `go_to` 失败后对同一目标反复重试 | 改 `warp`（跨图）/ 换目标格 / 如实报告 |
| 动作弹出菜单后继续发动作 | 按报错处理：带选项的 `menu_click {"option":N}` |
| 假设「应该成功了」 | 读返回文本；错误文案是中文人话，可直接转给用户 |
| 手动逐格移动干活 | 用批量工具的区域/自动扫描参数 |
| 给宠物起名（NamingMenu） | `/menu` 不暴露文本框 ⇒ `menu_click {"x":800,"y":352}` 接受默认名 |
| 连发多个动作抢进度 | 一等一，等返回再发下一个 |

## 已知边界（不是 bug，别去试）

- **`story choose` 是两段式，不要手动补点**：默认路径只把答案**登记**给游戏、不关闭问题框；`junimo-mcp.exe` 检测到界面未推进时会自动补发一次真实点击（`real=true`）。真机实测（宠物领养事件）选完即推进到下一幕「给宠物起名」。若仍未推进，先 `story action=read` 确认当前屏，再考虑 `menu_click` 按坐标点击，最后才 `skip`。
- **`skip` 不会把事件标记成已看**：未落盘的一天里，重新进入触发区会反复触发同一事件。要么走完，要么 `sleep` 翻日。
- **剧情不可回放**：`skip` 掉的内容不会补回来，游戏不提供重看。
- **`/buy` 按售价 ×2 计价**：没有商店界面的便利端点，不是正常价格。

## 附录 A：原始端点逃生通道（工具覆盖不到时）

执行器 mod 还有一批**工具层没暴露**的原语。直连 `http://localhost:7850`（必须 localhost，
`127.0.0.1` 会被拒），最短的调用方式是本仓库的 `node junimo-call.mjs --raw GET /screen`。

### A.1 按住输入（蓄力 / 抛竿）

| 端点 | body | 说明 |
|---|---|---|
| `POST /input/hold` | `{"buttons":["use"],"ms":800}` | 按住若干毫秒后自动松开；`buttons` 取值 `use`（=左键）、`left/right/up/down`（**语义方向**，由执行器解析成游戏内当前绑定，默认 WASD），可组合 |
| `POST /input/release` | — | 立刻全松 |
| `GET /input/state` | — | `holding` / `msLeft` / `keys`（我们按住的）/ `observedKeys`（**游戏实际读到的**）；0.1.1 起另有 `injectedKeys`（累计注入计数，在涨=补丁在工作）/ `hasKeyboardFocus` / `isMainInstance` |

**实测边界（2026-11-04，JunimoBridge 0.1.1）**：

- ✅ `use` 真生效：拿锄头 hold 500ms，目标格**真的被锄了**（`/surroundings` 里 HoeDirt 0→1）。
  这是**升级工具蓄力**（铜/钢/铱扩范围）和**钓鱼抛竿**的唯一途径。
- ✅ 走路也已成：`{"buttons":["left"],"ms":500}` 连按几次会**真的位移**（arm 到 Farm 40,32 实测
  left 2 格 → down 2 格 → down 2 格，朝向同步改）。前提是 `CanMove=true` 且没有菜单/对话。
- ⚠️ **两次 hold 之间务必 `POST /input/release`**，否则后续 hold 会被忽略。
- ⚠️ `left/right/up/down` 走的是**游戏内实际绑定**（默认 `A`/`D`/`W`/`S`）。
  **箭头键在 SDV 里默认没绑**，注入 `Keys.Up` 等于按空气 —— 详见 A.4。

### A.2 窗口 / 视口 / 菜单探针

| 端点 | 说明 |
|---|---|
| `GET /screen` | `viewport`（**物理像素**窗口矩形）、`uiViewport`、`mouse`、`foreground`/`isActive`、`menu{open,type,components,subMenu}` |
| `GET /probe/active_menu` | 只要菜单部分，返回 `{ok,open,menu}` |

- **「点了没反应」先查 `foreground`/`isActive`** —— SDV 失焦会暂停，此时坐标再准也没用。
- 截屏/点击换算用 `viewport`（物理像素），**别用 Win32 `GetWindowRect` 的逻辑坐标**（本机 DPI 175%，差 1.75 倍）。
- `menu.type` 直接给菜单类名（`DialogueBox` / `Chest` / `ShopMenu` / `null`），比 `menu_read` 的渲染文本更结构化。
- **0.1.1 起 `menu` 还带 `fields`**：菜单内部字段原样摊开（如 `GameMenu` 的 `currentTab` / `hoverText` / `xPositionOnScreen` / `width`），这是驱动**复杂 UI**（商店翻页、博物馆捐赠、制作菜单切标签）的关键 —— 以前只能靠坐标瞎点。
- ⚠️ 实测 `DialogueBox` 的 `components` 是**空数组**（对话不是控件型菜单）——选项仍走 `story` / `menu_read`。

### A.3 其它常用原始端点

| 端点 | 用途 | 工具层对应 |
|---|---|---|
| `GET /status` | `server`/`version`/`worldReady`/`tick`/`uptimeMs`/`pending` | `junimo_doctor` 内部用 |
| `POST /position {x,y}` | 瞬移（`warp` 落点不对劲时兜底） | 无 |
| `POST /stop` | 中止跨帧操作并结账等待中的请求 | 无 |
| `POST /refill` | 灌满水壶 | 无（工具只在水壶空时自动补） |
| `POST /key {key,count}` | `confirm`/`skip`/`escape`/`menu`/`cancel`/`up`/`down`/`left`/`right`/`w`…（见 A.4） | `press_key` |
| `POST /tool_area {operation,x1,y1,x2,y2}` | 矩形批量锄/浇 | `till` / `water` |

### A.4 0.1.1 之后的两条硬规矩（排查先看这里）

- **方向键在 SDV 里没有默认绑定。** `options.moveXButton` 默认只绑 `W`/`A`/`S`/`D`，
  `Game1.UpdateControlInput` 也只查这几个数组 —— 注入 `Keys.Up` 等于按空气，
  **连朝向都不会变**。所以任何"按方向"的地方都要走语义名（`up`/`down`/`left`/`right`），
  由执行器解析成实际绑定；直接写 `up`=箭头键的假设是错的。
  （此坑在 JunimoBridge v0.1.1 已修，`/key` 回执带 `resolvedKeys` 可核对。）
- **`press_key menu` 打不开菜单，八成是因为已经有界面开着。** 有菜单/事件时
  `menu`/`escape` 走的是「整段跳过」而不是「再按一次」；只想关掉当前这一层用 `cancel`。
  干净状态下 `press_key menu` 实测能开 `GameMenu`（0.1.1 复核）。
- `menu`/`escape`/`cancel` 都按 `Game1.options` 的实际绑定注入（默认 `menu = E+Esc`、
  `cancel` 走菜单键 —— `cancelButton` 默认是 `V`，对菜单是哑键）。
- 两处形状差异别混：无菜单时 `/screen` 的 `menu` 是 `{"open":false,"type":""}`，
  而 `/probe/active_menu` 是 `menu:null`。
- **`interact` 回执里的「交互面向格 (0,0)」不可信**：动作确实触发在正确格，
  只是回执把坐标算成了 0,0（未修，仅记录）。
- **角色转向但不位移**：先查 `CanMove` 与 `activeMenu`（进档/`warp` 后可能卡在起床动画
  或有 `DialogueBox` 是/否框）。这是游戏侧锁死，不是按键问题 —— `GET /debug/move`
  一次看全 `pauseTime` / `locationRequest` / 四个方向碰撞 / 按键绑定。