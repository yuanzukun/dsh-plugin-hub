import {svnCallerAncestors} from './svn-caller-safety.mjs';
import {checked} from './process.mjs';
import {xml} from './svn.mjs';
import {relativePath,hash} from './content.mjs';
import {validateCallerScopes} from './caller-index.mjs';
import {lstat} from 'node:fs/promises';
import path from 'node:path';
const canonical=v=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;
// Offline scoped status only, never svn list or repository-wide enumeration.
// Status XML has no node kind: bind local kinds and omit directories from body candidates.
// Links and other unsafe non-directory nodes still reach the strict source validator.
export async function svnCallerIndex(root,scopes,options={}){const approved=validateCallerScopes(scopes),entries=[],chunks=[];let bytes=0;const seen=new Set();for(const scope of approved){const ancestors=await svnCallerAncestors(root,scope,options);chunks.push(ancestors.fingerprint);let cursor=root;for(const part of scope.split('/')){cursor=path.join(cursor,part);const s=await lstat(cursor);if(s.isSymbolicLink()||!s.isDirectory())throw new Error('SVN caller scope requires real directories');}
 const raw=await checked('svn',['--non-interactive','status','--xml','--verbose','--ignore-externals','--',scope+'@'],{...options,cwd:root,maxBytes:64*1024});bytes+=raw.length;if(bytes>64*1024)throw new Error('SVN caller index byte limit exceeded');const found=(xml(raw).status?.target??[]).flatMap(t=>t.entry??[]);
 for(const e of found){const name=relativePath(e['@_path'].replaceAll('\\','/'));if(name!==scope&&!name.startsWith(scope+'/'))throw new Error('SVN caller index escaped scope');if(seen.has(name))throw new Error('Duplicate SVN caller index path');seen.add(name);if(seen.size>256)throw new Error('SVN caller index path limit exceeded');entries.push({...e,'@_path':name});}if(!found.some(e=>e['@_path'].replaceAll('\\','/')===scope))throw new Error('SVN caller scope missing from status');chunks.push(scope);}
 entries.sort((a,b)=>a['@_path']<b['@_path']?-1:1);const unsafe=s=>!s||s['@_item']!=='normal'||!['none','normal'].includes(s['@_props'])||['@_switched','@_copied','@_file-external','@_tree-conflicted'].some(k=>s[k]==='true');for(const scope of approved){const e=entries.find(e=>e['@_path']===scope);if(unsafe(e?.['wc-status']))throw new Error('Unsafe SVN caller directory state');}
 const nodes=[];for(const e of entries.filter(e=>!approved.includes(e['@_path'])&&!unsafe(e['wc-status']))){options.signal?.throwIfAborted();const stat=await lstat(path.join(root,e['@_path']));nodes.push({path:e['@_path'],kind:stat.isDirectory()?'dir':stat.isSymbolicLink()?'link':stat.isFile()?'file':'other'});}
 return {scopes:approved,paths:nodes.filter(n=>n.kind!=='dir').map(n=>n.path),entries,records:entries.length,bytes,fingerprint:hash(JSON.stringify(canonical({scopes:chunks,entries,nodes})))};}
