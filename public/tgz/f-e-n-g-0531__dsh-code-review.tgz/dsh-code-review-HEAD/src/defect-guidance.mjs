import {protocolGuidance} from './protocol-guidance.mjs';
// Original defect checklists, not executable rules or proof of a defect.
const common = ['Only report a concrete defect with trigger, impact and changed-code evidence.', 'Check before/after behavior and counterexamples; absent context means uncertainty, not an invented contract.'];
const checklists = {
 shader: ['Check coordinate spaces, matrix/vector order, normal transforms, UV units and screen/projection conventions against captured pipeline evidence.', 'Check division/normalization and precision near zero, NaN propagation, sampling/LOD behavior and bounds for changed input domains.', 'Check resource bindings, pass/keyword variants, depth/blend state and synchronization against actual consumers; do not invent platform/compiler behavior or include search paths.'],
 objc: ['Check ARC/manual ownership, retain cycles, weak/unowned callbacks and Objective-C++ lifetime crossings against captured contracts.', 'Check observer/block cancellation and queue affinity before teardown; message to nil is not proof that required work completed.', 'Check Core Data/URLSession/notification teardown and UI updates dispatched to the documented main/queue contract; do not infer thread-safety away.'],
 swift: ['Check optional force unwraps and unowned captures against actual object lifetime and failure paths.', 'Check actor isolation, task cancellation, continuation completion exactly once and resources surviving asynchronous work.', 'Check @MainActor/@preconcurrency isolation and strict-concurrency diagnostics against the actual compiler mode; do not assume actor isolation away.'],
 matlab: ['Check matrix dimensions, elementwise versus matrix operations and indexing against captured input contracts.', 'Check empty/NaN values, numeric precision, resource cleanup and changed output shapes with actual consumers.'],
 java: ['Check checked/unchecked exception exits, try-with-resources ownership and suppressed failures.', 'Check null/unboxing, equality/hash contracts and mutable keys; confirm the actual consumer contract.', 'Check synchronization/volatile publication, executor shutdown, interruption propagation and transaction rollback.', 'Check virtual-thread pinning, parallel-stream pool assumptions and version-gated APIs against the actual JDK; do not infer preview syntax as stable.'],
 go: ['Check error handling including typed-nil interfaces, deferred cleanup and panic paths.', 'Check goroutine/channel ownership, cancellation, close/send races and synchronization before shared-state teardown.', 'Check slice backing-array aliasing, map races and integer/bounds contracts with concrete callers.', 'Check build tags/constraints, go.mod and runtime version, and GC/finalizer assumptions against the actual build; do not infer memory or scheduling guarantees.'],
 python: ['Check exception paths, context manager cleanup, iterator exhaustion and mutable default/shared state.', 'Check async task exception observation, cancellation and blocking operations on the event loop.', 'Check untrusted serialization, subprocess/SQL interpolation and authorization boundaries against actual input flows.', 'Check version-gated syntax (async/await, walrus, match, positional-only, type hints) and keyword/positional call contracts against the runtime version; do not assume newer feature availability.'],
 rust: ['Check unsafe pointer validity, aliasing, initialization, alignment and lifetime obligations against the safety contract.', 'Check panic/error cleanup, lock guards across await and deadlocks or cancellation between state updates.', 'Check integer conversions, indexing, FFI ownership and Send/Sync assumptions without treating compiler acceptance as runtime proof.', 'Check edition/MSRV, cfg and proc-macro expansion, and panic/unwind versus abort mode against the declared build; do not treat hygiene or source order as evaluated runtime proof.'],
 kotlin: ['Check nullable/platform types, unsafe casts and Java interoperability at actual runtime boundaries.', 'Check structured coroutine lifetime, cancellation propagation, exception supervision and shared state synchronization.', 'Check use/close cleanup, collection mutation and transaction failure paths.', 'Check expect/actual and multiplatform specifics, @Volatile/@Synchronized interop and version-gated stdlib APIs against the actual target; do not infer JVM guarantees elsewhere.'],
 php: ['Check coercion and loose comparison at authentication or validation boundaries with concrete input.', 'Check SQL/command/template injection, deserialization and output escaping in the actual execution context.', 'Check exception/early-return cleanup, transactions and session/concurrent request state.'],
 cpp: ['Check ownership, dangling references, double release and allocator/object lifetime across all exits.', 'Check stop publication, synchronization, join completion and remaining users before teardown; source order alone is not a happens-before proof.', 'Check exception/early-return resource cleanup, iterator invalidation, bounds, integer conversion and undefined behavior.', 'Do not assume macro expansion, overload binding, build flags or virtual dispatch targets without evidence.'],
 csharp: ['Check IDisposable/async disposal, cancellation propagation and completion before releasing shared state.', 'Check nullability and actual runtime guards, event subscription lifetime, deferred enumeration and captured mutable state.', 'Check async exception observation, synchronization and thread-affinity; do not assume await establishes unrelated ordering.', 'Check ValueTask double-await, ConfigureAwait scheduling and .NET version nullable rollout against the actual runtime; do not infer marshaling or affinity.'],
 javascript: ['Check null/undefined contract changes, promise rejection handling and missing await or cleanup on failure.', 'Check event/timer/listener lifecycle, closure state, cancellation races and concurrent updates.', 'Check untrusted input at injection/authentication boundaries; do not report style or infer TypeScript runtime checks.'],
 configuration: ['Check changed configuration keys against consumer/schema evidence, type/unit/default mismatches and compatibility.', 'Check exposed secrets, privilege expansion and unsafe interpolation only with concrete supported evidence.'],
 arkts: ['Check UI-thread and component lifecycle, state immutability rules and task/coroutine cleanup against the actual framework contract.', 'Check restricted ArkTS and dynamic-eval boundaries, typed borrow/copy semantics and module strictness; do not infer behavior from plain TypeScript rules.'],
 hdl: ['Check scheduling/sensitivity lists, blocking versus nonblocking assignment, bit width, sign extension and truncation against actual values and consumers.', 'Check clock/reset domain crossings, metastability handling and combinational loops with concrete timing and tool-support evidence.', 'Check case exhaustiveness, inferred latches, x/z propagation and parameter/define overrides; do not assume simulator or synthesizer outcomes.'],
 solidity: ['Check state update ordering, reentrancy before external calls, balance/allowance accounting and storage layout across upgrades.', 'Check msg.sender/msg.value trust, delegatecall/selfdestruct exposure, overflow/underflow and access control against actual callers.', 'Check compiler/pragma version and deployed bytecode consumers; do not invent chain-specific behavior.'],
 vyper: ['Check reentrancy, external contract calls, integer bounds and payable/value handling against the actual call graph.', 'Check storage layout and compiler/version compatibility with deployed consumers; do not assume ABI or gas semantics.'],
 rego: ['Check undefined values, iteration over undefined, negation under open-world semantics and complete rules against actual inputs.', 'Check conflict resolution, package/import bindings and data-document mismatches; do not invent the document schema.'],
 jsonnet: ['Check self/object inheritance and lazy evaluation changes, array/object merges, and error paths for missing fields.', 'Check runtime/stdlib version and import paths against captured build evidence; do not assume evaluation order.'],
 nix: ['Check fetched/pinned sources (hash, revision), sandbox breaks, impurity and build-time network/download against actual derivations.', 'Check attribute/override precedence, fixed-output hashes and eval/builder versions; do not invent Nixpkgs defaults.'],
 zig: ['Check allocator ownership and leak paths, error cleanup with defer/errdefer, and pointers invalidated after reallocation.', 'Check integer overflow/wrapping intent, alignment, sentinel slices and build-mode differences tied to actual callers.'],
 fsharp: ['Check laziness, sequence/async resource cleanup, tail-call assumptions and partial application against actual evaluation.', 'Check null/option/Result handling, pattern-match exhaustiveness and disposal across all exits of the changed path.'],
 rlang: ['Check vector recycling/length, NA/NaN propagation, type coercion and factor levels against actual input contracts.', 'Check lazy evaluation, environment capture, connection/file cleanup and package or seed version effects.'],
 elm: ['Check model update handling, Decoder failures, impossible patterns and command/task cancellation or ordering.', 'Check state transitions and side-effect boundaries against the changed ports/flags contract.'],
 haskell: ['Check laziness, bottoms/exceptions, partial functions and strictness-driven space/time changes against callers.', 'Check IO/resource cleanup with bracket, async exception safety and pure/mutable boundaries in the changed transaction.'],
 julia: ['Do not report type instability without a measurement; check allocation, closure capture and dispatch changes only against evidence.', 'Check broadcast/scalar semantics, bounds, shared mutable state and task/coroutine cleanup with concrete callers.'],
 nim: ['Check nil/exception paths, gc versus manual memory ownership, generics/compile-time evaluation and proc mutation side effects.', 'Check integer overflow, indexing and FFI ownership against actual callers and backend; do not infer runtime checks from declarations.'],
 ocaml: ['Check option/result/exception paths, tail-recursion assumptions, physical versus structural equality and resource cleanup.', 'Check GADT/exhaustiveness and FFI lifetime; do not invent a module signature that is not captured.'],
 po: ['Check msgid/msgstr identity, plural-forms rules, format specifiers and their order, and encoding/NFC identity.', 'Check untranslated/fuzzy markers and placeholder mismatch against the actual extraction catalog.'],
 mybatis: ['Check parameter bound type, #{} versus ${}, collection iteration and NULL semantics in dynamic SQL against the mapper interface.', 'Check result map column/type, statement id uniqueness and cache invalidation; do not infer database behavior that is not captured.'],
 react: ['Check effect cleanup, stale closures over dependencies, and async setState after unmount or on cancelled requests.', 'Check list keys, event-handler reuse and render-phase side effects; do not classify a memo re-render as a defect without evidence.'],
  freemarker: ['Check ${...} reaching HTML without auto-escaping or the matching ?html/?url/?js_string builtin, and flag ?no_esc/<#noautoesc> as an escape hatch on user-controlled values; do not report missing escaping when <#ftl output_format> or .ftlh/.ftlx auto-activates it.', 'Check template source, names or bodies derived from request input (<#include>, <#import>, get_optional_template) and ?new()/?api/?eval exposure on untrusted values; do not infer a restricted TemplateClassResolver without captured configuration.', 'Check absent values rendered without a ! default or ?? guard, a bare ! masking required data, and ! precedence guarding only the last segment; report concrete render failures, not optional display values.'],
  handlebars: ['Check raw {{{value}}}/{{& value}} and double-braced values inside JS/CSS/URL/attribute/event contexts, requiring context-appropriate escaping or URL scheme validation; do not report ordinary {{value}} text the engine escapes by default.', 'Check dynamic partial names ({{> (lookup ...)}} or {{>*name}}) or helper/lambda reinterpretation of untrusted data without an allowlist, and recursive partial chains without data-dependent termination.', 'Check required values silently rendering empty, helper/context name collisions ({{name}} versus {{./name}}), and wrong section/context depth; report concrete output failures, not missing defaults for optional display values.'],
  jinja: ['Check |safe, Markup or {% autoescape false %} on untrusted values, and HTML-escaped values inside JS/CSS/URL/attribute contexts against the configured autoescaping; do not report every {{ value }} as unescaped.', 'Check template source, expression fragments, filter or macro bodies, or dynamic include/import/extends targets derived from request data without an allowlist, and attr-filter traversal toward sensitive host objects.', 'Check required values silently rendering empty, |default(..., true) swallowing valid 0/False/empty, deep undefined chains, and block overrides dropping {{ super() }} or leaking caller context; report concrete failures only.'],
  pug: ['Check !{value} / != value on untrusted HTML, escaped #{value} / = value in JS/CSS/JSON/URL/handler contexts, and &attributes(spread) or link/event attributes built from caller-controlled keys and values; do not report ordinary #{value} or = value HTML text.', 'Check script. blocks interpolating values without JS/JSON-safe serialization or without neutralizing </script>, and secrets or oversized objects serialized to client-visible markup.', 'Check attacker-authored template source (compile/render), request-controlled include/extends without an allowlist, and unbuffered code (-) performing filesystem/network/shared-state side effects; do not treat compile-time filters as runtime sanitizers of dynamic locals.'],
  astro: ['Check set:html on untrusted content, and non-PUBLIC_ env, cookies, headers, sessions or secrets reaching client HTML, scripts or hydrated islands unless the boundary is intentional.', 'Check client:* directives on non-framework components, missing fallback for client:only or server:defer, and over-hydration from large or unnecessary islands.', 'Check props or data crossing server:defer or define:vars boundaries for functions, circular objects, secrets or oversized payloads; do not assume frontmatter values are reactive in the browser.'],
  terraform: ['Check literal secrets (passwords, API keys, access keys, connection strings) assigned to arguments, variable/locals defaults or committed .tfvars, and credential-shaped variables missing sensitive = true.', 'Check 0.0.0.0/0, ::/0 or "*" sources on sensitive ports and wildcard IAM actions/resources or public ACLs without a public-content purpose stated in the diff.', 'Check committed .tfstate, removed prevent_destroy on stateful resources, stateful resources missing lifecycle where siblings have one, and unbounded provider/module versions where siblings pin; do not flag terraform fmt whitespace.'],
  bicep: ['Check literal secrets (passwords, connection strings, API keys) on resource properties, parameter defaults or variables, and credential-shaped parameters missing @secure().', 'Check broad roleAssignments (Owner/Contributor), NSG rules with */Internet/0.0.0.0 on sensitive ports, and publicNetworkAccess enabled without compensating networkAcls or private endpoints.', 'Check storage without a pinned minimumTlsVersion or with supportsHttpsTrafficOnly = false only when the diff shows the insecure value, stale api-version relative to siblings, and unpinned module references where siblings pin; do not flag omitted optional hardening alone.'],
  pom_xml: ['Check SNAPSHOT versions in newly added coordinates in production builds; a missing version is normally parent-POM-managed, and do not flag versions not on added lines.'],
  build_gradle: ['Check SNAPSHOT or floating versions in newly added dependencies; prefer a specific version number, and do not flag versions not on added lines.'],
  package_json: ['Check dependencies pinned to "latest" or "*" instead of a specific version, and do not flag versions not on added lines.', 'Check the same dependency declared in both dependencies and devDependencies, and tools named in scripts that are missing from devDependencies.'],
  cargo_toml: ['Check wildcard (*) dependency versions, unpinned git sources without rev/tag, and dependencies placed in the wrong section (dependencies versus dev-dependencies/build-dependencies); require reproducible sources only where a lock or policy demands it.', 'Check missing edition or rust-version where the workspace requires it, and feature flags that disable dependent behavior, leak internal optional dependency names, or enable heavy integrations by default; do not treat additive features as defects.', 'Check published crates missing license/repository/description metadata and packaged artifacts, credentials, local paths or secrets; report only when the crate is actually distributed.'],
  composer_json: ['Check wildcard or mutable VCS constraints without a committed lock for applications, changed constraints permitting an unintended major, and production packages available only through require-dev; do not flag compatible ranges in libraries or unverified vulnerability claims.', 'Check the php constraint against changed syntax/APIs/CI runtime, missing mandatory ext-* requirements, and config.platform that masks a production mismatch.', 'Check PSR-4/autoload mapping that cannot resolve a moved or renamed class, autoload.files side effects, and lifecycle scripts running destructive or interpolated commands without declared tool dependencies.', 'Check disabled secure-http, plaintext or credential-bearing repository URLs, and weakened minimum-stability without prefer-stable; report an exposed secret or internal source only with concrete evidence.'],
  github_workflows: ['Check pull_request_target workflows that run untrusted PR head code with write permissions, expressions interpolated directly into run: shell, and secrets printed or applied beyond the steps that need them.', 'Check hardcoded credentials and overly broad permissions (write-all or a missing permissions key); require least-privilege and a full-SHA pin for third-party actions, while actions/* at v4 is acceptable.', 'Check broken job dependencies, matrix coverage gaps and missing timeouts where the surrounding workflow shows them; do not report missing caching or first-party tag pinning as defects.'],
  github_config: ['Check issue/PR template completeness (name/description/body/id), valid input types and non-empty dropdown options where the schema requires them.', 'Check release configuration category labels, a catch-all default category, and misspelled configuration keys that would be silently ignored.'],
  yaml: ['Check spelling of YAML keys against the surrounding schema; ignore value content and do not infer a schema that is not captured.'],
  properties: ['Check duplicate keys, malformed key-value entries (missing separator or stray whitespace) and unescaped backslashes/unicode in the visible scope.', 'Check plaintext passwords, API keys or connection strings; report only concrete sensitive values, not every user-editable property.'],
  json: ['Check spelling of JSON keys against the surrounding schema; ignore value content and do not infer a schema that is not captured.']
};
// ─────────────────────────────────────────────────────────────
// Detection is declarative: priority-ordered tables, not nested ternaries.
// Each table entry is [pattern, value]; the first match wins.
const SNIFF_HEAD_BYTES = 8192;

const OBJC_SOURCE_HINT = /^(?:#(?:import|include|pragma|if|define)\b|@(?:import|interface|implementation|class|protocol)\b|\/\/|\/\*)/;
const MYBATIS_HINT = /<mapper\s+namespace\s*=|<!DOCTYPE\s+mapper\b|<(?:select|insert|update|delete)\s+id\s*=/;
const SOLIDITY_HINT = /\/\/\s*SPDX-License-Identifier|pragma\s+solidity|\b(?:contract|interface|library)\s+[A-Za-z_$][A-Za-z0-9_$]*|\b(?:function|constructor|fallback|receive|modifier)\s*\(/;
const FSHARP_HINT = /\blet\b|\bmodule\b|\bnamespace\b|\bopen\b|\btype\b|\[</;

const SHADER_FILE = /\.(shader|hlsl|glsl|cginc|hlsli|compute)$/;

const EXTENSION_LANGUAGE = [
  [/\.mm$/, 'objc'],
  [/\.swift$/, 'swift'],
  [/\.ets$/, 'arkts'],
  [/\.(vh|sv|svh|vhd|vhdl)$/, 'hdl'],
  [/\.vy$/, 'vyper'],
  [/\.rego$/, 'rego'],
  [/\.(jsonnet|libsonnet)$/, 'jsonnet'],
  [/\.nix$/, 'nix'],
  [/\.zig$/, 'zig'],
  [/\.r$/, 'rlang'],
  [/\.elm$/, 'elm'],
  [/\.(hs|lhs)$/, 'haskell'],
  [/\.jl$/, 'julia'],
  [/\.nim$/, 'nim'],
  [/\.(ml|mli)$/, 'ocaml'],
  [/\.po$/, 'po'],
  [/\.java$/, 'java'],
  [/\.go$/, 'go'],
  [/\.(py|pyi)$/, 'python'],
  [/\.rs$/, 'rust'],
  [/\.(kt|kts)$/, 'kotlin'],
  [/\.(php|phtml)$/, 'php'],
];

const BASE_LANGUAGE = [
  [/\.(c|cc|cpp|cxx|h|hh|hpp|hxx)$/, 'cpp'],
  [/\.cs$/, 'csharp'],
  [/\.(js|jsx|mjs|cjs|ts|tsx)$/, 'javascript'],
  [/\.(json|yaml|yml|toml|ini|xml|properties)$/, 'configuration'],
];

const TEMPLATE_FORMATS = [
  [/\.(ftl|ftlh|ftlx)$/, 'freemarker'],
  [/\.(hbs|mustache)$/, 'handlebars'],
  [/\.(jinja2|j2)$/, 'jinja'],
  [/\.pug$/, 'pug'],
  [/\.astro$/, 'astro'],
];

const INFRA_FORMATS = [
  [/\.(tf|hcl|tfvars)$/, 'terraform'],
  [/\.bicep$/, 'bicep'],
];

const MANIFEST_FORMATS = [
  [/(?:^|\/)package\.json$/, 'package_json'],
  [/(?:^|\/)cargo\.toml$/, 'cargo_toml'],
  [/(?:^|\/)pom\.xml$/, 'pom_xml'],
  [/(?:^|\/)build\.gradle$/, 'build_gradle'],
  [/(?:^|\/)composer\.json$/, 'composer_json'],
];

const PURPOSE_BY_EXTENSION = [
  [/\.(ftl|ftlh|ftlx|hbs|mustache|jinja2|j2|pug|astro)$/, 'template'],
  [/\.(tf|hcl|tfvars|bicep|nix)$/, 'infrastructure'],
  [/\.(proto|thrift|capnp|graphql|gql|prisma)$/, 'protocol-schema'],
];

const DEFAULT_TEMPLATE_CHECKS = [
  'Check escaping for the actual HTML/attribute/URL/script context, untrusted raw output and template execution boundaries.',
  'Check missing/null variables and changed conditional branches against captured callers; do not invent engine defaults.',
];

const DEFAULT_INFRA_CHECKS = [
  'Check privilege/network exposure, secret/state handling and untrusted interpolation against actual provider semantics.',
  'Check replacement/deletion, dependency order and changed defaults for concrete data loss or service disruption; configuration is not an applied plan.',
];

/** First matching table entry's value, otherwise null. Priority = array order. */
function firstMatch(table, lower) {
  for (const [pattern, value] of table) if (pattern.test(lower)) return value;
  return null;
}

/** Content sniffing for extensions whose meaning depends on the file body. */
function sniffContent(lower, head, first) {
  if (lower.endsWith('.m')) return OBJC_SOURCE_HINT.test(first) ? 'objc' : 'matlab';
  if (lower.endsWith('.xml') && MYBATIS_HINT.test(head)) return 'mybatis';
  if (lower.endsWith('.sol') && SOLIDITY_HINT.test(head)) return 'solidity';
  if (/\.(fs|fsi|fsx)$/.test(lower) && FSHARP_HINT.test(head)) return 'fsharp';
  return null;
}

export function defectGuidance(filePath, sourceText = '') {
  const lower = filePath.toLowerCase();
  const protocol = protocolGuidance(filePath);
  const head = typeof sourceText === 'string' ? sourceText.slice(0, SNIFF_HEAD_BYTES) : '';
  const first = head.split('\n').map(line => line.trim()).find(Boolean) ?? '';

  const sniffed = sniffContent(lower, head, first);

  // Priority: shader extension > content sniffing > plain extension lookup.
  const specialized =
    (SHADER_FILE.test(lower) ? 'shader' : null) ??
    sniffed ??
    firstMatch(EXTENSION_LANGUAGE, lower);

  const language =
    protocol?.language ??
    specialized ??
    (firstMatch(BASE_LANGUAGE, lower) ?? 'generic');

  const fileType =
    /^\.github\/workflows\/.+\.(yaml|yml)$/.test(lower) ? 'github-workflow'
    : /(?:^|\/)(package\.json|cargo\.toml|pom\.xml|build\.gradle|composer\.json)$/.test(lower) ? 'dependency-manifest'
    : undefined;

  const purposeCategory = firstMatch(PURPOSE_BY_EXTENSION, lower);
  const purpose = fileType ?? purposeCategory;

  const templateFormat = firstMatch(TEMPLATE_FORMATS, lower);
  const infraFormat = firstMatch(INFRA_FORMATS, lower);

  const purposeChecks =
    purpose === 'protocol-schema' ? protocol.checks
    : purpose === 'template' ? (checklists[templateFormat] ?? DEFAULT_TEMPLATE_CHECKS)
    : purpose === 'infrastructure' ? (checklists[infraFormat] ?? DEFAULT_INFRA_CHECKS)
    : [];

  const reactChecks = /\.(jsx|tsx)$/.test(lower) ? checklists.react : [];

  const manifestFormat = firstMatch(MANIFEST_FORMATS, lower);
  const configFormat =
    fileType === 'github-workflow' ? 'github_workflows'
    : /^\.github\/.+\.(yaml|yml)$/.test(lower) ? 'github_config'
    : /\.(yaml|yml)$/.test(lower) ? 'yaml'
    : /\.properties$/.test(lower) ? 'properties'
    : /\.(json|json5)$/.test(lower) ? 'json'
    : undefined;

  const format = manifestFormat ?? configFormat;

  return {
    version: 5,
    language,
    ...(sniffed ? { selection: 'bounded-first-nonblank-line-hint' } : {}),
    ...(purpose ? { fileType: purpose } : {}),
    ...(format || templateFormat || infraFormat ? { format: format ?? templateFormat ?? infraFormat } : {}),
    checks: [
      ...common,
      ...(format ? (checklists[format] ?? []) : (checklists[language] ?? [])),
      ...reactChecks,
      ...purposeChecks,
    ],
    notice: 'Guidance is not evidence, a semantic parser, a style rule or permission to read outside the snapshot.',
  };
}
