import { sourceSegments } from './source-segments.mjs';
import { primaryContextFocus } from './primary-context.mjs';
import { CONTEXT_SIDE_NOTICE } from './context-identity.mjs';
import { approvedCallerBindings } from './caller-binding-input.mjs';
import { REQUIREMENT_NOTICE } from './business-requirement.mjs';
import { defectGuidance } from './defect-guidance.mjs';
import { cppCallSites } from './cpp-call-sites.mjs';
import { inferCsharpContext } from './csharp-context.mjs';
import { inferImportRelations } from './import-relations.mjs';
import { inferContextRelations } from './context-relations.mjs';
import { prepareWindowSynthesis } from './window-synthesis.mjs';
import { planWindowBatches } from './window-batches.mjs';
import { changeWindows } from './change-windows.mjs';
import { reviewChangeMap } from './review-change-map.mjs';
import { initialInputBudget } from './input-budget.mjs';
import { changeScopeNotice } from './git-change-scope.mjs';
import { chooseRiskStrategy, riskPlanningMode as validateRiskPlanningMode } from './risk-strategy.mjs';

const CPP_FILE = /\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx)$/;
const RELATION_NOTICE = '命名和相对导入关系仅为源码线索，可能被同名局部变量遮蔽，不证明绑定、调用可达或因果；只报告主file的问题，不为relatedFiles重复生成发现。';
const optional = h => h.confidence === 'namespace-member-syntax-only' || h.confidence === 'instance-method-syntax-only';

// Pure preparation over already captured data. No model calls or new reads.
export function preparePrimaryInput(input, file, { instructions, scope, grouping, maxInputBytes, riskPlanningMode, enableRiskPlanning, skipSmallRiskPlans, round, focusPrimaryContext = false }) {
  validateRiskPlanningMode(riskPlanningMode);
  if (typeof focusPrimaryContext !== 'boolean') throw new Error('focusPrimaryContext must be boolean');
  const changes = reviewChangeMap(file.left.text, file.right.text);

  let base = {
    ...(input.projectScope ? { projectScope: input.projectScope, reviewNotice: 'Full current-file review; empty left is a sentinel, not a historical baseline. changes are transport coordinates only, do not infer introduced regression.' } : {}),
    ...(input.changeScope ? { changeScope: input.changeScope, changeScopeNotice: changeScopeNotice(input.changeScope) } : {}),
    ...(input.history ? { contextSideNotice: CONTEXT_SIDE_NOTICE } : {}),
    ...(input.businessRequirement !== undefined ? { businessRequirement: input.businessRequirement, requirementNotice: REQUIREMENT_NOTICE } : {}),
    defectGuidance: defectGuidance(file.path, file.rightExists === false ? file.left.text : file.right.text),
    snapshotId: input.id,
    file,
    changes,
    context: input.context ?? [],
    rules: input.rules ?? [],
  };

  const contextRelations = inferContextRelations(input, file);
  if (contextRelations.length) {
    base.contextRelations = contextRelations;
    base.contextRelationNotice = '导入/include/命名与调用位置仅为语法线索；可能被宏、构建搜索路径或同名局部变量影响，不证明绑定、可达性或因果。context.text为批准当前/目标侧文本；仅明确oldText/oldRevision字段是历史旧侧，禁止互换。';
  }

  if (CPP_FILE.test(file.path)) {
    const calls = ['old', 'new'].flatMap(side => cppCallSites((side === 'old' ? file.left : file.right).text).map(site => ({ ...site, side })));
    if (calls.length) {
      base.cppCallSites = calls;
      base.cppCallNotice = '最多20条零参语法位置/侧，仅导航子集；不表示全部调用覆盖，不证明宏展开、重载选择、动态分派或执行顺序。其他源码须在批准范围内读取。';
    }
  }

  const csharpHints = inferCsharpContext(input, file);
  if (csharpHints.length) {
    base.csharpContextHints = csharpHints;
    base.csharpContextNotice = '仅批准context的C#静态类型/方法语法位置；历史输入按contextSide/contextVersion区分正文，无旧正文不回退目标侧。不证明语义绑定或执行可达。歧义不推定，线索不增加审查覆盖。';
  }

  if (input.callerDiscovery) {
    const callerBindings = approvedCallerBindings(input, file);
    if (callerBindings.length) {
      base.callerBindings = callerBindings;
      base.callerBindingNotice = '调用方文件的导入行、调用行与目标声明行仅为语法位置线索，来源限于已批准上下文；历史side/revision要求调用方与目标声明同版本，缺侧不回退。仅导航，窗口中的原文须按相应版本catalog读取；不证明执行可达、动态分派、重载选择或完整调用覆盖，也不代表全部调用方。';
    }
  }

  const measure = value => initialInputBudget({ instructions, input: value }, scope, maxInputBytes);
  const focused = focusPrimaryContext ? primaryContextFocus(base, { scope, maxInputBytes, measure }) : { base, metadata: {} };
  base = focused.base;
  let payload = JSON.stringify(base);
  const metadata = { ...focused.metadata };

  // Optional member navigation must not block source review or force extra windows.
  if (base.contextRelations?.some(e => e.bindingHints?.some(optional)) && !measure(payload).fits) {
    metadata.optionalBindingFallback = 'input-budget';
    metadata.omittedOptionalBindingCount = base.contextRelations.reduce((n, e) => n + (e.bindingHints ?? []).filter(optional).length, 0);
    base.contextRelations = base.contextRelations.map(e => ({ ...e, bindingHints: (e.bindingHints ?? []).filter(h => !optional(h)) }));
    payload = JSON.stringify(base);
  }
  // Optional navigation must not block source review or force extra windows.
  if (base.callerBindings?.length && !measure(payload).fits) {
    metadata.callerBindingFallback = 'input-budget';
    metadata.omittedCallerBindingCount = base.callerBindings.reduce((count, c) => count + c.bindings.length, 0);
    delete base.callerBindings;
    delete base.callerBindingNotice;
    payload = JSON.stringify(base);
  }

  let batches, synthesis;
  const group = grouping?.groups.find(g => g.fileIds.includes(file.id));
  if (group) {
    metadata.groupId = group.id;
    const relatedFiles = input.files.filter(f => f.id !== file.id && f.eligibility === 'reviewable' && group.fileIds.includes(f.id));
    if (relatedFiles.length) {
      const relations = grouping.links.filter(link => !link.split && group.fileIds.includes(link.from) && group.fileIds.includes(link.to));
      const bindingRelations = inferImportRelations(input.files)
        .filter(edge => (edge.bindingHints?.length || edge.definitionHints?.length) && (edge.from === file.id || edge.to === file.id) && group.fileIds.includes(edge.from) && group.fileIds.includes(edge.to))
        .map(({ from, to, side, bindingHints, definitionHints }) => ({ from, to, side, bindingHints, ...(definitionHints?.length ? { definitionHints } : {}) }));
      const grouped = JSON.stringify({ ...base, relatedFiles, relations, bindingRelations, relationNotice: RELATION_NOTICE });
      if (measure(grouped).fits) {
        payload = grouped;
        metadata.relatedFileIds = relatedFiles.map(f => f.id);
      } else {
        // Optional member hints must not cost the grouped related sources either.
        const groupedOmitted = bindingRelations.reduce((n, e) => n + (e.bindingHints ?? []).filter(optional).length, 0);
        const trimmedRelations = bindingRelations.map(e => ({ ...e, bindingHints: (e.bindingHints ?? []).filter(h => !optional(h)) })).filter(e => e.bindingHints.length || e.definitionHints?.length);
        const trimmed = JSON.stringify({ ...base, relatedFiles, relations, bindingRelations: trimmedRelations, relationNotice: RELATION_NOTICE });
        if (groupedOmitted && measure(trimmed).fits) {
          payload = trimmed;
          metadata.relatedFileIds = relatedFiles.map(f => f.id);
          metadata.optionalBindingFallback = 'input-budget';
          metadata.omittedOptionalBindingCount = (metadata.omittedOptionalBindingCount ?? 0) + groupedOmitted;
        } else {
          metadata.groupFallback = 'input-budget';
        }
      }
    }
  }

  const strategy = chooseRiskStrategy(input, file, { changes, payload, metadata }, {
    instructions, scope, maxInputBytes, riskPlanningMode, enableRiskPlanning, skipSmallRiskPlans, round,
  });
  if (strategy.mode === 'inline') return {
    changes, payload, batches, synthesis, inlineRisk: true, instructions: strategy.instructions, budget: strategy.budget,
    metadata: { ...metadata, initialInputBytes: strategy.budget.bytes, riskPlanningMode: 'inline' },
  };

  if (!measure(payload).fits && scope) {
    const exactWindows = changeWindows(file, changes);
    const windows = exactWindows ? sourceSegments(exactWindows) : null;
    if (windows) {
      const compactFile = { ...file, left: { ...file.left, text: undefined }, right: { ...file.right, text: undefined } };
      const contextCatalog = scope.catalog().filter(source => ['context', 'context-old'].includes(source.side));
      if (contextCatalog.length) metadata.contextMode = 'approved-retrieval';
      const windowBase = { ...base };
      if (base.cppCallSites?.length) {
        windowBase.cppCallSites = base.cppCallSites.map(({ line, expression, side }) => ({ line, expression, side }));
        windowBase.cppCallNotice = '最多40条旧/新侧零参语法导航；统一confidence=syntax-only-unresolved，可能为宏/重载/动态分派，无绑定、可达性或顺序保证，不是证据或完整覆盖。原文仍须按批准catalog读取。';
      }
      const compact = JSON.stringify({
        ...windowBase, context: focusPrimaryContext ? base.context : [], contextCatalog, contextMode: 'approved-retrieval',
        contextNotice: focusPrimaryContext ? '部分聚焦上下文原文可在context中提供；其他来源仅目录，须按sourceId和版本侧read，不代表缺失或完整覆盖。' : '上下文全文仍在同一批准快照，仅目录进入窗口初始输入；必须按sourceId和版本侧read原文，不把目录视为证据或完整覆盖。',
        file: compactFile, windows, sourceMode: 'change-windows',
        windowNotice: '窗口可能为精确hunk的分段或粗粒度包络，精度以changes.precision为准；片段两侧不保证行对齐，不以片段证明精确编辑或回归因果。start/count为原始源码行号，不得重编号。完整源码未随初始输入发送，可在catalog批准范围内检索；缺少上下文时说明限制。',
      });
      if (!measure(compact).fits) {
        const envelope = JSON.parse(compact);
        const plan = planWindowBatches(windows, subset => JSON.stringify({ ...envelope, windows: subset, windowNotice: '本批仅审查windows包含的编辑，其他hunk另批；行号为原始行号，跨片段上下文不足说明限制。' }), measure);
        metadata.windowBlocked = plan.blocked;
        if (!plan.blocked.length && plan.batches.length) {
          batches = plan.batches;
          payload = batches[0].payload;
          metadata.sourceMode = 'change-windows';
          metadata.windowIds = windows.map(w => w.id);
          metadata.batchCount = batches.length;
        }
      }
      if (measure(compact).fits) {
        payload = compact;
        metadata.sourceMode = 'change-windows';
        metadata.windowIds = windows.map(w => w.id);
        metadata.windowEditIds = [...new Set(windows.flatMap(w => w.editIds))];
      }
    }
  }

  if (batches?.length > 1) {
    synthesis = prepareWindowSynthesis(batches.map(batch => batch.payload), measure);
    metadata.synthesisStatus = synthesis.status === 'ready' ? 'ready' : 'blocked';
    if (synthesis.reason) metadata.synthesisBlockedReason = synthesis.reason;
    if (synthesis.budget) metadata.synthesisInputBytes = synthesis.budget.bytes;
  }

  const finalStrategy = chooseRiskStrategy(input, file, { changes, payload, batches, synthesis, metadata }, {
    instructions, scope, maxInputBytes, riskPlanningMode, enableRiskPlanning, skipSmallRiskPlans, round,
  });
  if (finalStrategy.mode === 'inline') return {
    changes, payload, batches, synthesis, inlineRisk: true, instructions: finalStrategy.instructions, budget: finalStrategy.budget,
    metadata: { ...metadata, initialInputBytes: finalStrategy.budget.bytes, riskPlanningMode: 'inline' },
  };
  if (riskPlanningMode === 'auto' && finalStrategy.fallbackReason) metadata.riskPlanningFallbackReason = finalStrategy.fallbackReason;
  const budget = measure(payload);
  return { changes, payload, batches, synthesis, budget, metadata: { ...metadata, initialInputBytes: budget.bytes } };
}
