import test from 'node:test';
import assert from 'node:assert/strict';
import { buildResumeState, validateResumeState, resumePreview, RESUME_CHECKPOINT_CAPACITY_LIMITATION } from '../src/review-resume.mjs';
import { reviewSnapshot } from '../src/review.mjs';
import { stageKey } from '../src/review-stage-state.mjs';
import { createStageContinuation } from '../src/stage-continuation.mjs';
const snapshot=()=>({id:'s',files:['a','b'].map(id=>({id,path:id+'.js',eligibility:'reviewable',left:{text:'old();\n'},right:{text:'new();\n'},properties:[]})),context:[{path:'context.js',text:'context'}]});
const options=()=>({execution:{enableStageContinuation:true,rounds:1},route:{provider:'offline',model:'fake'}});
const machineOptions=()=>({rounds:1,maxInputBytes:98304,enableMigrationContracts:false,enableMigrationRegression:false});
const generation=(fileId='a',round=1)=>({key:stageKey(fileId,{phase:'primary',round}),fileId,phase:'primary',round,windowIds:[],generation:{findings:[{fileId,severity:'high',title:'Missing guard',evidence:'new call',trigger:'invalid state',impact:'failure',suggestion:'restore guard',anchor:{kind:'line',side:'new',start:1,end:1,snippet:'new();'},attribution:{editIds:['e1'],properties:[],beforeBehavior:'guard',afterBehavior:'none',reason:'removed'},verification:{status:'completed',evidence:[{receiptId:'OLD'}]}}],limitations:['limited']}});
const report=()=>({files:[{fileId:'a',path:'a.js',status:'pending'},{fileId:'b',path:'b.js',status:'completed',resumeEligible:true}],findings:[],limitations:[],interactions:[],stageGenerations:[generation()]});
function continuation(s=snapshot()) {const o=machineOptions(),m=createStageContinuation(s,o,{completedPrimary:['a'],units:[{id:'verify:a',kind:'verification',fileIds:['a'],dependencies:['primary:a']}],maxAttempts:2});return {o,m};}

test('default legacy schema one behavior remains opt-out and does not store stage payload',()=>{const r=report(),o={};const cp=buildResumeState(snapshot(),o,r);assert.equal(cp.schemaVersion,1);assert.equal(cp.stageGenerations,undefined);assert.deepEqual(validateResumeState(cp,snapshot(),o),cp);assert.equal(resumePreview(cp,'job').reusableGenerations,undefined);});

test('opt-in schema two preserves accepted pending primary without upgrading chain status or verifier',()=>{const s=snapshot(),o=options(),r=report(),cp=buildResumeState(s,o,r);assert.equal(cp.schemaVersion,2);assert.deepEqual(cp.completed.map(f=>f.fileId),['b']);assert.equal(cp.stageGenerations.length,1);assert.equal(cp.stageGenerations[0].fileId,'a');assert.doesNotMatch(JSON.stringify(cp),/OLD|receipt|verification/);assert.deepEqual(validateResumeState(cp,s,o),cp);assert.equal(cp.completed.some(f=>f.fileId==='a'),false);});

test('top-level opt-in works; default validator rejects schema two and changing execution identity fails',()=>{const o={enableStageContinuation:true};const cp=buildResumeState(snapshot(),o,report());assert.equal(cp.schemaVersion,2);assert.deepEqual(validateResumeState(cp,snapshot(),o),cp);assert.throws(()=>validateResumeState(cp,snapshot(),{}));const next=options(),state=buildResumeState(snapshot(),next,report());next.execution.rounds=2;assert.throws(()=>validateResumeState(state,snapshot(),next),/identity mismatch/);});

test('completed-chain duplicate generation filtered and secondary generation never crosses run boundary',()=>{const r=report();r.stageGenerations.push(generation('b'));r.stageGenerations.push({...generation(),phase:'window-synthesis',key:stageKey('a',{phase:'window-synthesis',windowIds:['h1']}),windowIds:['h1'],generation:{findings:[],limitations:[]}});const cp=buildResumeState(snapshot(),options(),r);assert.deepEqual(cp.stageGenerations.map(row=>row.fileId),['a']);const forged=structuredClone(cp);forged.stageGenerations.push(generation('b'));assert.throws(()=>validateResumeState(forged,snapshot(),options()));});

test('multiple rounds keep accepted generations separately and preview discloses fresh independent verification',()=>{const r=report();r.stageGenerations.push(generation('a',2));const cp=buildResumeState(snapshot(),options(),r),p=resumePreview(cp,'oldjob');assert.equal(p.reusableFiles,1);assert.equal(p.reusableGenerations,2);assert.deepEqual(p.stageFileIds,['a']);assert.match(p.notice,/fresh independent receipts/);assert.match(p.notice,/secondary stages restart/);assert.match(p.notice,/not completed reviews/);});

test('changed approved text context route or stage payload identity rejected during host import',()=>{const s=snapshot(),o=options(),cp=buildResumeState(s,o,report());for(const mutate of [s=>s.files[0].right.text='different',s=>s.context[0].text='changed']){const next=structuredClone(s);mutate(next);assert.throws(()=>validateResumeState(cp,next,o),/identity mismatch/);}for(const mutate of [c=>c.stageGenerations[0].fileId='b',c=>c.stageGenerations[0].path='foreign.js',c=>c.stageGenerations[0].generation.findings[0].anchor.start=99,c=>c.stageGenerations[0].generation.findings[0].attribution.editIds=['e404']]){const next=structuredClone(cp);mutate(next);assert.throws(()=>validateResumeState(next,s,o));}});

test('import rejects unknown top stage and continuation fields instead of dropping host-private receipts',()=>{const cp=buildResumeState(snapshot(),options(),report());for(const mutate of [c=>c.extra=true,c=>c.receipts=['OLD'],c=>c.stageGenerations[0].retrievalAudit=[],c=>c.stageGenerations[0].generation.findings[0].verification={receiptId:'OLD'}]){const next=structuredClone(cp);mutate(next);assert.throws(()=>validateResumeState(next,snapshot(),options()));}});

test('continuation checkpoint stored with exact local machine options while enclosing identity remains bound',()=>{const r=report(),{o,m}=continuation();m.start('verify:a');m.yield('verify:a','READER_CALL_BUDGET_EXCEEDED');r.continuationOptions=o;r.continuation=m.checkpoint();const cp=buildResumeState(snapshot(),options(),r);assert.deepEqual(cp.continuation,{options:o,state:m.checkpoint()});assert.deepEqual(validateResumeState(cp,snapshot(),options()),cp);assert.equal(cp.continuation.state.units[0].attempts,1);assert.equal(cp.continuation.state.units[0].status,'pending');assert.notEqual(cp.continuation.state.identityHash,cp.identityHash);});

test('past completed continuation stays bookkeeping only and cannot promote a pending primary chain',()=>{const r=report(),{o,m}=continuation();const token=m.start('verify:a');m.complete('verify:a',token.attempt);r.continuationOptions=o;r.continuation=m.checkpoint();const cp=buildResumeState(snapshot(),options(),r);assert.equal(cp.continuation.state.units[0].status,'completed');assert.equal(cp.completed.some(row=>row.fileId==='a'),false);assert.equal(cp.stageGenerations[0].generation.findings[0].verification,undefined);const fresh=createStageContinuation(snapshot(),o,{completedPrimary:['a'],units:[{id:'verify:a',kind:'verification',fileIds:['a'],dependencies:['primary:a']}],maxAttempts:2});assert.equal(fresh.ready()[0].attempts,0);});

test('continuation options identity state fields attempt and dependency mutations fail closed',()=>{const r=report(),{o,m}=continuation();r.continuationOptions=o;r.continuation=m.checkpoint();const cp=buildResumeState(snapshot(),options(),r);for(const mutate of [c=>c.continuation.options.extra=true,c=>c.continuation.options.rounds=2,c=>c.continuation.options.maxInputBytes=0,c=>c.continuation.state.units[0].attempts=999,c=>c.continuation.state.units[0].receiptId='OLD',c=>c.continuation.state.completedPrimary=['b'],c=>c.continuation.state.units[0].dependencies=['missing'],c=>c.continuation.state.units[0].status='completed']){const next=structuredClone(cp);mutate(next);assert.throws(()=>validateResumeState(next,snapshot(),options()));}});

test('schema two completed legacy chains retain verdict but never carry old receipt or raw delivery audit',()=>{const r=report();r.findings=[{fileId:'b',verification:{status:'completed',verdict:'refuted',evidence:[{receiptId:'OLD',sourceId:'s1'}]},retrievalAudit:[{text:'SECRET_BODY'}]}];const cp=buildResumeState(snapshot(),options(),r);assert.equal(cp.completed[0].findings[0].verification.verdict,'refuted');assert.doesNotMatch(JSON.stringify(cp),/receiptId|OLD|SECRET_BODY|retrievalAudit/);assert.deepEqual(validateResumeState(cp,snapshot(),options()),cp);});

test('eight MiB cap and unsafe host imports fail without evaluating getters or serialization hooks',()=>{const cp=buildResumeState(snapshot(),options(),report());const large=structuredClone(cp);large.extra='x'.repeat(8*1024*1024);assert.throws(()=>validateResumeState(large,snapshot(),options()));let ran=false;const accessor=structuredClone(cp);Object.defineProperty(accessor,'stageGenerations',{enumerable:true,get(){ran=true;return[];}});assert.throws(()=>validateResumeState(accessor,snapshot(),options()));assert.equal(ran,false);const hook=structuredClone(cp);hook.toJSON=()=>{ran=true;return{};};assert.throws(()=>validateResumeState(hook,snapshot(),options()));assert.equal(ran,false);});

test('host export omits optional undefined report fields but private import rejects undefined',()=>{const r=report();r.files[1].reason=undefined;r.files[1].optional={detail:undefined};const cp=buildResumeState(snapshot(),options(),r);assert.equal(Object.hasOwn(cp.completed[0].state,'reason'),false);assert.deepEqual(cp.completed[0].state.optional,{});assert.deepEqual(validateResumeState(cp,snapshot(),options()),cp);const forged=structuredClone(cp);forged.completed[0].state.reason=undefined;assert.throws(()=>validateResumeState(forged,snapshot(),options()));});


test('whole-result byte overflow keeps deterministic complete units and truthful saved counts', () => {
  const s = snapshot(), o = options(), r = report(), { o: machine, m } = continuation(s);
  r.stageGenerations = Array.from({ length: 6 }, (_, i) => ({ ...generation('a', i + 1), generation: { findings: [], limitations: Array(100).fill('x'.repeat(7990)) } }));
  r.files[1].detail = 'y'.repeat(4 * 1024 * 1024); r.continuationOptions = machine; r.continuation = m.checkpoint();
  const stagesOnly = buildResumeState(s, o, { ...r, files: [], continuation: undefined, continuationOptions: undefined });
  assert.equal(stagesOnly.stageGenerations.length, 6);
  const completedOnly = buildResumeState(s, o, { ...r, stageGenerations: [], continuation: undefined, continuationOptions: undefined });
  assert.equal(completedOnly.completed.length, 1);
  const cp = buildResumeState(s, o, r); assert.ok(Buffer.byteLength(JSON.stringify(cp)) <= 8 * 1024 * 1024);
  assert.equal(cp.completed.length, 1); assert.ok(cp.stageGenerations.length > 0 && cp.stageGenerations.length < 6); assert.equal(cp.continuation, undefined);
  assert.deepEqual(validateResumeState(cp, s, o), cp); assert.equal(resumePreview(cp, 'old').reusableGenerations, cp.stageGenerations.length);
  assert.equal(r.resumeLimitations.length, 1); assert.equal(r.resumeLimitations[0].omitted.stageGenerations, 6 - cp.stageGenerations.length);
  assert.equal(r.resumeLimitations[0].omitted.continuation, 1); assert.equal(r.limitations.filter(row => row.text === RESUME_CHECKPOINT_CAPACITY_LIMITATION).length, 1);
  const again = buildResumeState(s, o, r); assert.deepEqual(again, cp); assert.equal(r.resumeLimitations.length, 1);
  assert.equal(r.limitations.filter(row => row.text === RESUME_CHECKPOINT_CAPACITY_LIMITATION).length, 1);
});

test('aggregate node capacity drops whole completed chain and filters interactions and continuation', () => {
  const s = snapshot(), o = options(), r = report(), { o: machine, m } = continuation(s);
  r.files = s.files.map(f => ({ fileId: f.id, path: f.path, status: 'completed', resumeEligible: true, detail: [Array(80000).fill(0), Array(80000).fill(0)] }));
  r.stageGenerations = []; r.interactions = [{ groupId: 'g', fileIds: ['a', 'b'], status: 'completed' }];
  r.continuationOptions = machine; r.continuation = m.checkpoint();
  const cp = buildResumeState(s, o, r); assert.deepEqual(cp.completed.map(row => row.fileId), ['a']); assert.deepEqual(cp.interactions, []); assert.equal(cp.continuation, undefined);
  assert.equal(r.resumeLimitations[0].omitted.completed, 1); assert.equal(r.resumeLimitations[0].omitted.interactions, 1);
  assert.deepEqual(validateResumeState(cp, s, o), cp);
  const oversizedImport = structuredClone(cp); oversizedImport.completed.push({ ...cp.completed[0], fileId: 'b', path: 'b.js', state: { ...cp.completed[0].state, fileId: 'b', path: 'b.js' } });
  assert.throws(() => validateResumeState(oversizedImport, s, o), /Invalid stage resume/);
});

test('oversized optional chain cannot mask later malformed schema or execute accessors', () => {
  const s = snapshot(), o = options(); let ran = 0;
  for (const mutate of [
    r => { Object.defineProperty(r.files[1], 'hidden', { enumerable: true, get() { ran++; return 1; } }); },
    r => { r.stageGenerations.push({ ...generation('a', 2), generation: { findings: [], limitations: [], invented: true } }); },
    r => { r.stageGenerations.push(generation()); },
    r => { r.files[1].bad = Object.create({ inherited: true }); },
    r => { r.files[1].bad = { toJSON() { ran++; return {}; } }; },
    r => { Object.defineProperty(r, 'resumeLimitations', { enumerable: true, get() { ran++; return []; } }); },
    r => { r.resumeLimitations = {}; },
    r => { const row = {}; Object.defineProperty(row, 'code', { enumerable: true, get() { ran++; return 'unsafe'; } }); r.resumeLimitations = [row]; },
  ]) { const r = report(); r.files[1].detail = 'x'.repeat(9 * 1024 * 1024); mutate(r); assert.throws(() => buildResumeState(s, o, r)); }
  assert.equal(ran, 0);
  const getter = report(); Object.defineProperty(getter, 'files', { enumerable: true, get() { ran++; return []; } });
  assert.throws(() => buildResumeState(s, o, getter)); assert.equal(ran, 0);
  const hugeUnit = report(); hugeUnit.files[1].detail = 'x'.repeat(9 * 1024 * 1024);
  const cp = buildResumeState(s, o, hugeUnit); assert.deepEqual(cp.completed, []); assert.equal(hugeUnit.resumeLimitations[0].omitted.completed, 1);
});

test('persistence failure and cancellation identities are never swallowed as export capacity', async () => {
  const s = { ...snapshot(), vcs: 'git' }, io = Object.assign(new Error('disk write failed'), { code: 'EIO' });
  await assert.rejects(reviewSnapshot(s, async () => ({ findings: [], limitations: [] }), {
    enableStageContinuation: true, onResumeCheckpoint: async r => { buildResumeState(s, options(), r); throw io; },
  }), error => error === io);
  const controller = new AbortController(), cancelled = new Error('explicit cancel'); controller.abort(cancelled);
  let sends = 0;
  const stopped = await reviewSnapshot(s, async () => { sends++; throw new Error('must not send'); }, { signal: controller.signal, enableStageContinuation: true });
  assert.equal(stopped.status, 'cancelled'); assert.equal(sends, 0); assert.equal(controller.signal.reason, cancelled);
});

test('schema discriminator accessor is rejected before reading it for either opt-in or legacy imports',()=>{let hits=0;for(const opt of [options(),{}]){const value={};Object.defineProperty(value,'schemaVersion',{enumerable:true,get(){hits++;return 2;}});assert.throws(()=>validateResumeState(value,snapshot(),opt));}assert.equal(hits,0);const inherited=Object.create({get schemaVersion(){hits++;return 2;}});assert.throws(()=>validateResumeState(inherited,snapshot(),options()));assert.equal(hits,0);});
