/**
 * @dsh-external/dsh-plugin-rankings — client 配置/数据 store。
 * 读取 host 同源 API：榜单快照 + 用户设置；preview 立即推给 UI，保存走 PUT，
 * 手动刷新走 POST 并轮询直到整理完成。
 */
import {
  DATA_API_PATH,
  DEFAULT_SETTINGS,
  REFRESH_API_PATH,
  SETTINGS_API_PATH,
  normalizeSettings,
  type RankingsSettings,
  type RankingsSnapshot,
} from '../shared'

export type StoreStatus = 'loading' | 'ready' | 'saving' | 'refreshing' | 'error'

export interface StoreState {
  status: StoreStatus
  settings: RankingsSettings
  snapshot: RankingsSnapshot | null
  lastAttempt: string | null
  lastError: string | null
  error?: string
}

interface DataPayload {
  snapshot?: RankingsSnapshot | null
  refreshing?: boolean
  settings?: unknown
  lastError?: string | null
  lastAttempt?: string | null
}

const REFRESH_POLL_MS = 2500
const REFRESH_POLL_LIMIT = 72 // 3 分钟上限

export class RankingsStore {
  private state: StoreState = {
    status: 'loading',
    settings: DEFAULT_SETTINGS,
    snapshot: null,
    lastAttempt: null,
    lastError: null,
  }
  private listeners = new Set<() => void>()
  private tail: Promise<void> = Promise.resolve()

  getSnapshot = (): StoreState => this.state

  subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  private setState(patch: Partial<StoreState>): void {
    this.state = { ...this.state, ...patch }
    for (const listener of this.listeners) listener()
  }

  /** 立即把草稿推给 UI，不等待网络。 */
  preview(settings: RankingsSettings): void {
    this.setState({ settings })
  }

  private async fetchData(): Promise<DataPayload> {
    const response = await fetch(DATA_API_PATH, { cache: 'no-store' })
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    return (await response.json()) as DataPayload
  }

  private applyPayload(payload: DataPayload): void {
    this.setState({
      status: payload.refreshing ? 'refreshing' : 'ready',
      settings: normalizeSettings(payload.settings),
      snapshot: payload.snapshot ?? null,
      lastAttempt: payload.lastAttempt ?? null,
      lastError: payload.lastError ?? null,
    })
  }

  async load(): Promise<void> {
    try {
      const payload = await this.fetchData()
      this.applyPayload(payload)
    } catch {
      this.setState({ status: 'ready' })
    }
  }

  save(settings: RankingsSettings): Promise<void> {
    this.setState({ status: 'saving', settings })
    const task = this.tail
      .catch(() => undefined)
      .then(async () => {
        try {
          const response = await fetch(SETTINGS_API_PATH, {
            method: 'PUT',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(settings),
          })
          if (!response.ok) {
            const payload = (await response.json().catch(() => null)) as { message?: string } | null
            throw new Error(payload?.message ?? `HTTP ${response.status}`)
          }
          const saved = normalizeSettings(await response.json())
          this.setState({ status: 'ready', settings: saved })
        } catch (error) {
          this.setState({
            status: 'error',
            error: error instanceof Error ? error.message : String(error),
          })
        }
      })
    this.tail = task
    return task
  }

  /** 触发 host 手动整理并轮询至完成。 */
  async triggerRefresh(): Promise<void> {
    try {
      const response = await fetch(REFRESH_API_PATH, { method: 'POST' })
      if (!response.ok && response.status !== 202) {
        throw new Error(`HTTP ${response.status}`)
      }
    } catch (error) {
      this.setState({
        status: 'error',
        error: error instanceof Error ? error.message : String(error),
      })
      return
    }

    this.setState({ status: 'refreshing' })
    for (let attempt = 0; attempt < REFRESH_POLL_LIMIT; attempt += 1) {
      await new Promise<void>((resolve) => {
        window.setTimeout(resolve, REFRESH_POLL_MS)
      })
      try {
        const payload = await this.fetchData()
        this.applyPayload(payload)
        if (!payload.refreshing) return
      } catch {
        /* 轮询失败继续，直到超时 */
      }
    }
    this.setState({ status: 'error', error: '整理超时，请稍后重试' })
  }
}
