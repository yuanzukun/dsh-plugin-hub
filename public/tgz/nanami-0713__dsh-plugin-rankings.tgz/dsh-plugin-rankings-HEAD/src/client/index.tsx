/**
 * @dsh-external/dsh-plugin-rankings — client half（设置页「插件榜单」板块）。
 *
 * 挂在官方 `settings.section` 槽位（list slot，与其他插件设置并列）：
 * 每天由 host 整理的 dsh-plugin 生态 Top 10 / Top 100 榜单，
 * 按热度（Star）或下载量（npm 周下载）降序，默认热度。
 */
import { RankingsStore } from './config-store'
import { RANKINGS_SETTINGS_CSS, RankingsSettingsSection } from './settings-section'

interface ClientContext {
  effect(fn: () => (() => void) | void, label?: string): void
  slots: {
    inject(slot: string, factory: () => unknown): unknown
    register(options: {
      name: string
      id: string
      order?: number
      label?: () => string
      inject?: () => unknown
    }, component: unknown): unknown
  }
}

export const inject = ['slots']

export function apply(ctx: ClientContext): void {
  const store = new RankingsStore()
  void store.load()

  ctx.effect(() => {
    // 注入 <style>：slot 重挂载时由 effect 清理，避免样式重复。
    const style = document.createElement('style')
    style.id = '@dsh-external/dsh-plugin-rankings-style'
    style.textContent = RANKINGS_SETTINGS_CSS
    document.head.appendChild(style)
    return () => {
      style.remove()
    }
  }, '@dsh-external/dsh-plugin-rankings: style')

  ctx.slots.inject('settings.section', () =>
    ctx.slots.register(
      {
        name: 'settings.section',
        id: 'plugin-rankings',
        order: 19,
        label: () => '插件榜单',
        inject: () => ({ store }),
      },
      RankingsSettingsSection,
    ),
  )
}
