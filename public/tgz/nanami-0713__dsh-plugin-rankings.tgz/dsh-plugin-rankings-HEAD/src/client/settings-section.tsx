/**
 * @dsh-external/dsh-plugin-rankings — 设置页「插件榜单」（settings.section）。
 * Top 10 / Top 100 切换；按热度（Star，默认）或下载量（npm 周下载）降序；
 * 展示排名徽章、来源、分类、活跃度与 GitHub/npm 链接；支持手动整理。
 */
import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'
import {
  DEFAULT_SETTINGS,
  SOURCE_LABELS,
  formatCount,
  normalizeSettings,
  type PluginEntry,
  type PluginSource,
  type RankingsSettings,
  type SortKey,
} from '../shared'
import type { RankingsStore } from './config-store'

export const RANKINGS_SETTINGS_CSS = `
.drp-root{display:flex;flex-direction:column;gap:12px;max-width:760px;font-size:13px;line-height:1.5;color:var(--dsw-alias-label-primary)}
.drp-card{display:flex;flex-direction:column;gap:12px;padding:14px;border-radius:14px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1)}
.drp-card h3{margin:0;font-size:13px;font-weight:600}
.drp-muted{color:var(--dsw-alias-label-secondary);font-size:12px;margin:0;line-height:1.55}
.drp-error{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 12px;border-radius:10px;border:1px solid var(--dsw-alias-state-error-secondary);background:var(--dsw-alias-state-error-tertiary);color:var(--dsw-alias-state-error-primary);font-size:12px}
.drp-btn{font:inherit;font-size:12px;line-height:18px;padding:5px 12px;border-radius:9px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-button-elevated-fill);color:var(--dsw-alias-label-primary);cursor:pointer}
.drp-btn:hover{background:var(--dsw-alias-button-floating-hover)}
.drp-btn:disabled{opacity:.55;cursor:not-allowed}
.drp-seg{display:flex;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;overflow:hidden;width:fit-content;flex-wrap:wrap}
.drp-seg button{font:inherit;font-size:12px;padding:6px 12px;border:none;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-secondary);cursor:pointer}
.drp-seg button.active{background:var(--dsw-alias-interactive-bg-active);color:var(--dsw-alias-label-primary);font-weight:600}
.drp-controls{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
.drp-controls-group{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.drp-check{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--dsw-alias-label-secondary);cursor:pointer;user-select:none}
.drp-check input{accent-color:var(--dsw-alias-brand-primary-new-colorprimary-new-color)}
.drp-select{font:inherit;font-size:12px;padding:4px 8px;border-radius:8px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary)}
.drp-status{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:11px;color:var(--dsw-alias-label-tertiary)}
.drp-spin{display:inline-block;width:11px;height:11px;border:2px solid var(--dsw-alias-border-l2);border-top-color:var(--dsw-alias-brand-primary-new-colorprimary-new-color);border-radius:50%;animation:drp-rotate .8s linear infinite}
@keyframes drp-rotate{to{transform:rotate(360deg)}}
.drp-list{display:flex;flex-direction:column;gap:8px}
.drp-row{display:flex;gap:12px;align-items:flex-start;padding:10px 12px;border-radius:12px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1)}
.drp-row:hover{border-color:var(--dsw-alias-border-l3);background:var(--dsw-alias-interactive-bg-hover)}
.drp-rank{flex:none;width:26px;height:26px;border-radius:8px;display:grid;place-items:center;font-size:12px;font-weight:700;font-variant-numeric:tabular-nums;background:var(--dsw-alias-interactive-bg-active);color:var(--dsw-alias-label-secondary)}
.drp-rank.top1{background:linear-gradient(135deg,#F7D774,#C79A2E);color:#fff}
.drp-rank.top2{background:linear-gradient(135deg,#D8DEE8,#8FA0B3);color:#fff}
.drp-rank.top3{background:linear-gradient(135deg,#E0A675,#A5642E);color:#fff}
.drp-main{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.drp-title-line{display:flex;align-items:center;gap:6px;flex-wrap:wrap;min-width:0}
.drp-name{font-size:13px;font-weight:650;color:var(--dsw-alias-label-primary);text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.drp-name:hover{text-decoration:underline}
.drp-badges{display:flex;align-items:center;gap:4px;flex-wrap:wrap}
.drp-badge{flex:none;font-size:10px;line-height:16px;padding:0 6px;border-radius:5px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-tertiary);white-space:nowrap}
.drp-badge.cat{color:var(--dsw-alias-state-business-primary);border-color:color-mix(in srgb, var(--dsw-alias-state-business-primary) 30%, transparent)}
.drp-badge.src-awesome-dsh{color:var(--dsw-alias-state-success-primary);border-color:color-mix(in srgb, var(--dsw-alias-state-success-primary) 30%, transparent)}
.drp-desc{margin:0;font-size:12px;line-height:1.5;color:var(--dsw-alias-label-secondary);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;word-break:break-word}
.drp-meta{display:flex;align-items:center;gap:10px;flex-wrap:wrap;font-size:11px;color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}
.drp-meta a{color:var(--dsw-alias-label-secondary);text-decoration:none}
.drp-meta a:hover{text-decoration:underline}
.drp-score{flex:none;display:flex;flex-direction:column;align-items:flex-end;gap:1px;min-width:64px}
.drp-score-value{font-size:15px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-primary)}
.drp-score-label{font-size:10px;color:var(--dsw-alias-label-tertiary)}
.drp-empty{display:flex;flex-direction:column;align-items:center;gap:8px;padding:28px 12px;color:var(--dsw-alias-label-tertiary);font-size:12px}
@media (max-width:640px){.drp-score{display:none}}
`

function Segmented<T extends string | number>(props: {
  options: ReadonlyArray<{ label: string; value: T }>
  value: T
  onChange: (value: T) => void
}): JSX.Element {
  return (
    <div className="drp-seg" role="tablist">
      {props.options.map((option) => (
        <button
          type="button"
          key={option.value}
          role="tab"
          aria-selected={option.value === props.value}
          className={option.value === props.value ? 'active' : undefined}
          onClick={() => props.onChange(option.value)}
        >
          {option.label}
        </button>
      ))}
    </div>
  )
}

const TOPN_OPTIONS: ReadonlyArray<{ label: string; value: number }> = [
  { label: 'Top 10', value: 10 },
  { label: 'Top 100', value: 100 },
]

const SORT_OPTIONS: ReadonlyArray<{ label: string; value: SortKey }> = [
  { label: '热度', value: 'popularity' },
  { label: '下载量', value: 'downloads' },
]

const REFRESH_HOURS_OPTIONS: ReadonlyArray<{ label: string; value: number }> = [
  { label: '每 12 小时', value: 12 },
  { label: '每 24 小时', value: 24 },
  { label: '每 48 小时', value: 48 },
  { label: '每 72 小时', value: 72 },
]

const CATEGORY_LABELS: Record<string, string> = {
  webui: 'Web UI 增强',
  skin: '皮肤与娱乐',
  code: '编码开发',
  agent: 'Agent 能力',
  message: '消息通讯',
  vision: '视觉与多模态',
  browser: '浏览器与网络',
  file: '文件与数据',
  devtools: '开发工具与教程',
  collection: '精选合集',
  eco: '生态项目',
}

const SOURCE_BADGE_CLASS: Record<PluginSource, string> = {
  'github-topic': '',
  'oh-my-dsh': '',
  'awesome-dsh': 'src-awesome-dsh',
  npm: '',
}

function categoryLabel(category: string | undefined): string {
  if (!category) return ''
  return CATEGORY_LABELS[category] ?? category
}

function fmtDate(iso: string | undefined): string {
  if (!iso) return ''
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return ''
  return date.toISOString().slice(0, 10)
}

function compareEntries(sortKey: SortKey): (a: PluginEntry, b: PluginEntry) => number {
  return (a, b) => {
    if (sortKey === 'downloads') {
      const byDownloads = b.downloads - a.downloads
      if (byDownloads !== 0) return byDownloads
      const byStars = b.stars - a.stars
      if (byStars !== 0) return byStars
    } else {
      const byStars = b.stars - a.stars
      if (byStars !== 0) return byStars
      const byDownloads = b.downloads - a.downloads
      if (byDownloads !== 0) return byDownloads
    }
    return a.name.localeCompare(b.name)
  }
}

function RankRow(props: { rank: number; entry: PluginEntry; sortKey: SortKey }): JSX.Element {
  const { rank, entry, sortKey } = props
  const rankClass = rank === 1 ? 'drp-rank top1' : rank === 2 ? 'drp-rank top2' : rank === 3 ? 'drp-rank top3' : 'drp-rank'
  const scoreValue = sortKey === 'downloads' ? formatCount(entry.downloads) : formatCount(entry.stars)
  const scoreLabel = sortKey === 'downloads' ? '周下载' : 'Star'
  // Oh-My-DSH 人工编目备注优先于原始仓库描述。
  const description = entry.note ?? entry.description
  return (
    <div className="drp-row">
      <span className={rankClass}>{rank}</span>
      <div className="drp-main">
        <div className="drp-title-line">
          <a className="drp-name" href={entry.url} target="_blank" rel="noopener noreferrer" title={entry.repo ?? entry.npm ?? entry.name}>
            {entry.name}
          </a>
          <span className="drp-badges">
            {entry.type && <span className="drp-badge">{entry.type}</span>}
            {categoryLabel(entry.category) && <span className="drp-badge cat">{categoryLabel(entry.category)}</span>}
            {entry.activity && <span className="drp-badge">{entry.activity}</span>}
            {entry.sources.map((source) => (
              <span key={source} className={`drp-badge ${SOURCE_BADGE_CLASS[source]}`} title={`来源：${SOURCE_LABELS[source]}`}>
                {SOURCE_LABELS[source]}
              </span>
            ))}
          </span>
        </div>
        {description && <p className="drp-desc">{description}</p>}
        <div className="drp-meta">
          <span>⭐ {formatCount(entry.stars)}</span>
          <span>⬇ {formatCount(entry.downloads)}/周</span>
          {entry.language && <span>{entry.language}</span>}
          {entry.license && <span>{entry.license}</span>}
          {entry.pushedAt && <span>更新于 {fmtDate(entry.pushedAt)}</span>}
          {entry.repo && (
            <a href={`https://github.com/${entry.repo}`} target="_blank" rel="noopener noreferrer">
              GitHub ↗
            </a>
          )}
          {entry.npm && entry.npmUrl && (
            <a href={entry.npmUrl} target="_blank" rel="noopener noreferrer">
              npm ↗
            </a>
          )}
        </div>
      </div>
      <div className="drp-score">
        <span className="drp-score-value">{scoreValue}</span>
        <span className="drp-score-label">{scoreLabel}</span>
      </div>
    </div>
  )
}

export function RankingsSettingsSection(props: { store: RankingsStore }): JSX.Element {
  const { store } = props
  const state = useSyncExternalStore(store.subscribe, store.getSnapshot)
  const [draft, setDraft] = useState<RankingsSettings>(() => state.settings)
  const draftRef = useRef(draft)
  const dirtyRef = useRef(false)
  const initializedRef = useRef(false)

  useEffect(() => {
    if (!initializedRef.current && state.status !== 'loading') {
      initializedRef.current = true
      draftRef.current = state.settings
      setDraft(state.settings)
    }
  }, [state.status, state.settings])

  useEffect(() => {
    if (!initializedRef.current || !dirtyRef.current) return
    const timer = window.setTimeout(() => {
      void store.save(draftRef.current)
    }, 300)
    return () => window.clearTimeout(timer)
  }, [draft, store])

  useEffect(
    () => () => {
      if (dirtyRef.current) void store.save(draftRef.current)
    },
    [store],
  )

  const commit = (next: RankingsSettings): void => {
    const normalized = normalizeSettings(next)
    draftRef.current = normalized
    dirtyRef.current = true
    store.preview(normalized)
    setDraft(normalized)
  }

  const mutate = (mutator: (previous: RankingsSettings) => RankingsSettings): void => {
    commit(mutator(draftRef.current))
  }

  const sorted = useMemo(() => {
    const entries = state.snapshot?.entries ?? []
    return [...entries].sort(compareEntries(draft.sortKey)).slice(0, draft.topN)
  }, [state.snapshot, draft.sortKey, draft.topN])

  const refreshing = state.status === 'refreshing'
  const loading = state.status === 'loading'
  const updatedText = state.snapshot
    ? new Date(state.snapshot.generatedAt).toLocaleString([], {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      })
    : null

  return (
    <div className="drp-root">
      <p className="drp-muted">
        每天自动整理一次 dsh-plugin 生态榜单。热度 = GitHub Star；下载量 = npm 最近一周下载。
        数据聚合自 GitHub dsh-plugin 主题、Oh-My-DSH 聚合目录、awesome-dsh 精选清单与 npm 统计，均来自公开只读接口。
      </p>

      {state.status === 'error' && (
        <div className="drp-error">
          <span>{state.error ?? '操作失败'}</span>
          <button type="button" className="drp-btn" onClick={() => void store.load()}>
            重试
          </button>
        </div>
      )}

      <div className="drp-card">
        <h3>榜单设置</h3>
        <div className="drp-controls">
          <div className="drp-controls-group">
            <span className="drp-muted">范围</span>
            <Segmented
              options={TOPN_OPTIONS}
              value={draft.topN}
              onChange={(topN) => mutate((previous) => ({ ...previous, topN }))}
            />
            <span className="drp-muted">排序</span>
            <Segmented
              options={SORT_OPTIONS}
              value={draft.sortKey}
              onChange={(sortKey) => mutate((previous) => ({ ...previous, sortKey }))}
            />
          </div>
          <button
            type="button"
            className="drp-btn"
            disabled={refreshing}
            onClick={() => void store.triggerRefresh()}
          >
            {refreshing ? '整理中…' : '立即整理'}
          </button>
        </div>
        <div className="drp-controls-group">
          <label className="drp-check">
            <input
              type="checkbox"
              checked={draft.autoRefresh}
              onChange={(event) =>
                mutate((previous) => ({ ...previous, autoRefresh: event.target.checked }))
              }
            />
            每天自动整理
          </label>
          <select
            className="drp-select"
            value={draft.refreshHours}
            onChange={(event) =>
              mutate((previous) => ({ ...previous, refreshHours: Number(event.target.value) }))
            }
            disabled={!draft.autoRefresh}
          >
            {REFRESH_HOURS_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        <div className="drp-status">
          {refreshing && (
            <>
              <span className="drp-spin" aria-hidden="true" />
              <span>正在从各数据源整理榜单…</span>
            </>
          )}
          {!refreshing && updatedText && <span>上次整理：{updatedText}</span>}
          {state.snapshot && <span>收录 {state.snapshot.counts.total} 个插件</span>}
          {state.lastError && <span style={{ color: 'var(--dsw-alias-state-error-primary)' }}>上次失败：{state.lastError}</span>}
          {state.snapshot && state.snapshot.warnings.length > 0 && (
            <span title={state.snapshot.warnings.join('\n')}>⚠ {state.snapshot.warnings.length} 条采集告警</span>
          )}
        </div>
      </div>

      <div className="drp-card">
        <h3>
          插件榜单{draft.sortKey === 'popularity' ? ' · 按热度' : ' · 按下载量'}（Top {draft.topN}）
        </h3>
        {loading && <p className="drp-muted">正在加载榜单数据…</p>}
        {!loading && sorted.length === 0 && (
          <div className="drp-empty">
            <span>暂无榜单数据</span>
            <button type="button" className="drp-btn" onClick={() => void store.triggerRefresh()}>
              立即整理
            </button>
          </div>
        )}
        {!loading && sorted.length > 0 && (
          <div className="drp-list">
            {sorted.map((entry, index) => (
              <RankRow key={entry.id} rank={index + 1} entry={entry} sortKey={draft.sortKey} />
            ))}
          </div>
        )}
      </div>

      <div className="drp-status">
        <span>配置保存在 ~/.dsh/plugins/dsh-plugin-rankings/，修改实时生效并自动保存。</span>
      </div>
    </div>
  )
}
