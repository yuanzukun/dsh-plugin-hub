/**
 * @dsh-external/dsh-plugin-rankings — host half（数据聚合 + 每日整理）。
 *
 * 每天自动整理一次 dsh-plugin 生态榜单，聚合四个数据源：
 *   1. GitHub `dsh-plugin` 主题仓库搜索（star = 热度主指标）；
 *   2. Oh-My-DSH 聚合目录 data/plugins.json（分类/备注/活跃度/类型）；
 *   3. awesome-dsh-plugin 精选清单 README（精选徽标）；
 *   4. npm 关键字搜索 + 每包周下载量（下载量指标）。
 *
 * 快照落盘 ~/.dsh/plugins/dsh-plugin-rankings/data.json，经同源 HTTP API
 * 提供给设置页 client；支持手动触发刷新。全部请求仅限公开只读 API。
 */
import { appendFileSync, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import {
  DATA_API_PATH,
  DEFAULT_SETTINGS,
  PLUGIN_ID,
  REFRESH_API_PATH,
  SETTINGS_API_PATH,
  normalizeSettings,
  type PluginEntry,
  type PluginSource,
  type RankingsSettings,
  type RankingsSnapshot,
} from './shared.js'

export const name = PLUGIN_ID
export const inject = ['webServer']

/** loader 层旧配置（部署默认），最终以用户设置为准。 */
export interface RankingsConfig {
  refreshHours?: number
}

/* ─────────────────────────── 数据源常量 ─────────────────────────── */

const GITHUB_SEARCH = 'https://api.github.com/search/repositories'
const GITHUB_ACCEPT = 'application/vnd.github+json'
const OMD_PLUGINS = 'https://cdn.jsdelivr.net/gh/like-study1/Oh-My-DSH@main/data/plugins.json'
const AWESOME_README = 'https://cdn.jsdelivr.net/gh/awesome-dsh-plugin/awesome-dsh-plugin@HEAD/README.md'
const NPM_SEARCH = 'https://registry.npmjs.org/-/v1/search'
const NPM_DOWNLOADS = 'https://api.npmjs.org/downloads/point/last-week'

/** 下载量回填的并发与上限（npm 无批量接口，逐包查询；Cloudflare 限流故低并发+重试）。 */
const DOWNLOAD_CONCURRENCY = 4
const DOWNLOAD_LOOKUP_CAP = 120
const DOWNLOAD_RETRY_DELAYS = [0, 2500, 6000]
/** 快照最大条目数（榜单最多展示 100，留余量给去重与合并）。 */
const SNAPSHOT_ENTRY_CAP = 600

interface GithubRepo {
  full_name: string
  html_url: string
  description: string | null
  stargazers_count: number
  forks_count: number
  language: string | null
  license: { spdx_id: string } | null
  pushed_at: string | null
  created_at: string | null
  fork: boolean
  archived: boolean
}

interface OmdItem {
  full_name?: string
  url?: string
  description?: string
  stars?: number
  forks?: number
  language?: string
  topics?: string[]
  archived?: boolean
  fork?: boolean
  pushed_at?: string
  created_at?: string
  license?: string
  owner?: string
  category?: string
  note?: string
  source?: string
  activity?: string
  type?: string
}

interface NpmSearchPackage {
  name: string
  description?: string
  links?: { repository?: string; npm?: string; homepage?: string }
}

interface AwesomeEntry {
  repo: string
  description: string
}

/* ─────────────────────────── 通用工具 ─────────────────────────── */

let logger: ((line: string) => void) | null = null

function log(message: string): void {
  logger?.(message)
}

function errorText(error: unknown): string {
  if (error instanceof Error) return error.message
  return String(error).slice(0, 200)
}

async function fetchJson<T>(url: string, headers: Record<string, string> = {}, timeoutMs = 30_000): Promise<T> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      headers: {
        'user-agent': 'dsh-plugin-rankings (DSH plugin; daily public-data aggregation)',
        accept: 'application/json',
        ...headers,
      },
      signal: controller.signal,
    })
    if (!response.ok) {
      throw new Error(`HTTP ${response.status} ${url}`)
    }
    return (await response.json()) as T
  } finally {
    clearTimeout(timer)
  }
}

async function fetchText(url: string, timeoutMs = 30_000): Promise<string> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      headers: { 'user-agent': 'dsh-plugin-rankings (DSH plugin; daily public-data aggregation)' },
      signal: controller.signal,
    })
    if (!response.ok) throw new Error(`HTTP ${response.status} ${url}`)
    return await response.text()
  } finally {
    clearTimeout(timer)
  }
}

/** 从 npm repository 链接提取 GitHub owner/repo。 */
function repoFromNpm(repository: string | undefined): string | undefined {
  if (!repository) return undefined
  const match = repository.match(/github\.com[/:]([^/]+\/[^/#?]+?)(?:\.git)?$/i)
  if (!match) return undefined
  return decodeURIComponent(match[1]).replace(/\.git$/i, '').toLowerCase()
}

/** 从 GitHub 链接提取 owner/repo（小写）。 */
function repoFromUrl(url: string): string | undefined {
  const match = url.match(/github\.com[/:]([^/]+\/[^/#?]+?)(?:\.git)?(?:[/#?].*)?$/i)
  if (!match) return undefined
  return decodeURIComponent(match[1]).replace(/\.git$/i, '').toLowerCase()
}

/* ─────────────────────────── 数据源采集 ─────────────────────────── */

/** 1. GitHub dsh-plugin 主题搜索，按 star 降序（热度权威来源）。 */
async function fetchGithubTopic(warnings: string[]): Promise<GithubRepo[]> {
  const repos: GithubRepo[] = []
  try {
    for (const page of [1, 2]) {
      const url = `${GITHUB_SEARCH}?q=topic:dsh-plugin&sort=stars&order=desc&per_page=100&page=${page}`
      const data = await fetchJson<{ items?: GithubRepo[] }>(url, { accept: GITHUB_ACCEPT })
      const items = Array.isArray(data.items) ? data.items : []
      if (items.length === 0) break
      repos.push(...items.filter((repo) => !repo.fork))
    }
    log(`github topic 采集完成：${repos.length} 个仓库`)
  } catch (error) {
    const hint = /403|429/i.test(errorText(error))
      ? '（GitHub 搜索接口限流，本轮沿用上一轮快照数据）'
      : ''
    warnings.push(`GitHub 主题搜索失败${hint}：${errorText(error)}`)
  }
  return repos
}

/** 2. Oh-My-DSH 聚合目录（分类/备注/活跃度）。 */
async function fetchOmdCatalog(warnings: string[]): Promise<Map<string, OmdItem>> {
  const map = new Map<string, OmdItem>()
  try {
    const data = await fetchJson<{ items?: OmdItem[] }>(OMD_PLUGINS, {}, 60_000)
    for (const item of Array.isArray(data.items) ? data.items : []) {
      const key = (item.full_name ?? repoFromUrl(item.url ?? '') ?? '').toLowerCase()
      if (!key) continue
      const existing = map.get(key)
      if (!existing || (item.stars ?? 0) > (existing.stars ?? 0)) map.set(key, item)
    }
    log(`oh-my-dsh 目录采集完成：${map.size} 条`)
  } catch (error) {
    warnings.push(`Oh-My-DSH 目录采集失败：${errorText(error)}`)
  }
  return map
}

/** 3. awesome-dsh-plugin 精选清单（README 逐行解析）。 */
async function fetchAwesomeList(warnings: string[]): Promise<AwesomeEntry[]> {
  const entries: AwesomeEntry[] = []
  try {
    const text = await fetchText(AWESOME_README, 60_000)
    const lineRe = /^\s*-\s*\[([^\]]+)\]\(([^)]+)\)\s*-\s*(.+)$/
    for (const line of text.split(/\r?\n/)) {
      const match = line.match(lineRe)
      if (!match) continue
      const label = match[1].trim()
      const url = match[2].trim()
      const description = match[3].trim()
      const repo = repoFromUrl(url) ?? (/^[\w.-]+\/[\w.-]+$/.test(label) ? label.toLowerCase() : undefined)
      if (!repo) continue
      entries.push({ repo, description })
    }
    log(`awesome-dsh 清单采集完成：${entries.length} 条精选`)
  } catch (error) {
    warnings.push(`awesome-dsh 清单采集失败：${errorText(error)}`)
  }
  return entries
}

/** 4. npm 关键字搜索（下载量来源与 npm 元数据）。 */
async function fetchNpmPackages(warnings: string[]): Promise<Map<string, NpmSearchPackage>> {
  const map = new Map<string, NpmSearchPackage>()
  try {
    const url = `${NPM_SEARCH}?text=keywords:dsh-plugin&size=250`
    const data = await fetchJson<{ objects?: Array<{ package: NpmSearchPackage }> }>(url)
    for (const object of Array.isArray(data.objects) ? data.objects : []) {
      const pkg = object.package
      if (pkg?.name) map.set(pkg.name, pkg)
    }
    log(`npm 搜索采集完成：${map.size} 个包`)
  } catch (error) {
    warnings.push(`npm 搜索失败：${errorText(error)}`)
  }
  return map
}

/** 逐包查询 npm 周下载量（并发受限 + 限流重试退避）。 */
async function fillDownloads(names: string[], warnings: string[]): Promise<Map<string, number>> {
  const downloads = new Map<string, number>()
  const queue = names.slice(0, DOWNLOAD_LOOKUP_CAP)
  let index = 0
  let failed = 0

  const queryWithRetry = async (pkg: string): Promise<number | null> => {
    for (let attempt = 0; attempt < DOWNLOAD_RETRY_DELAYS.length; attempt += 1) {
      if (attempt > 0) {
        await new Promise((resolve) => setTimeout(resolve, DOWNLOAD_RETRY_DELAYS[attempt]))
      }
      try {
        const data = await fetchJson<{ downloads?: number }>(
          `${NPM_DOWNLOADS}/${encodeURIComponent(pkg)}`,
          {},
          20_000,
        )
        return typeof data.downloads === 'number' ? data.downloads : 0
      } catch (error) {
        // 包不存在/已下架 = 没有下载数据，按 0 处理；其余（限流/网络）退避重试。
        if (/404/i.test(errorText(error))) return 0
        if (attempt < DOWNLOAD_RETRY_DELAYS.length - 1) continue
        failed += 1
        return null
      }
    }
    return null
  }

  const worker = async (): Promise<void> => {
    while (index < queue.length) {
      const current = index++
      const pkg = queue[current]
      const value = await queryWithRetry(pkg)
      if (value !== null) downloads.set(pkg, value)
      // 请求间留 300ms 间隔，避免触发 Cloudflare 突发限流。
      await new Promise((resolve) => setTimeout(resolve, 300))
    }
  }

  await Promise.all(Array.from({ length: DOWNLOAD_CONCURRENCY }, () => worker()))
  if (failed > 0) warnings.push(`npm 下载量查询失败 ${failed}/${queue.length} 个包`)
  log(`npm 下载量回填完成：${downloads.size} 个包`)
  return downloads
}

/* ─────────────────────────── 合并与快照 ─────────────────────────── */

function entryFromRepo(repo: GithubRepo, sources: PluginSource[]): PluginEntry {
  return {
    id: repo.full_name.toLowerCase(),
    name: repo.full_name.split('/')[1] ?? repo.full_name,
    repo: repo.full_name.toLowerCase(),
    description: repo.description ?? '',
    stars: repo.stargazers_count,
    forks: repo.forks_count,
    downloads: 0,
    language: repo.language ?? undefined,
    license: repo.license?.spdx_id,
    pushedAt: repo.pushed_at ?? undefined,
    createdAt: repo.created_at ?? undefined,
    url: repo.html_url,
    sources,
  }
}

function applyOmd(entry: PluginEntry, item: OmdItem): void {
  if (item.stars !== undefined && item.stars > entry.stars) entry.stars = item.stars
  if (item.forks !== undefined && item.forks > entry.forks) entry.forks = item.forks
  if (!entry.description && item.description) entry.description = item.description
  if (item.category) entry.category = item.category
  if (item.type) entry.type = item.type
  if (item.note) entry.note = item.note
  if (item.activity) entry.activity = item.activity
  if (!entry.language && item.language) entry.language = item.language
  if (!entry.license && item.license) entry.license = item.license
  if (!entry.pushedAt && item.pushed_at) entry.pushedAt = item.pushed_at
  if (!entry.createdAt && item.created_at) entry.createdAt = item.created_at
}

function addSource(entry: PluginEntry, source: PluginSource): void {
  if (!entry.sources.includes(source)) entry.sources.push(source)
}

async function aggregate(previous: RankingsSnapshot | null): Promise<RankingsSnapshot> {
  const warnings: string[] = []
  const [githubRepos, omd, awesome, npmPackages] = await Promise.all([
    fetchGithubTopic(warnings),
    fetchOmdCatalog(warnings),
    fetchAwesomeList(warnings),
    fetchNpmPackages(warnings),
  ])

  const byRepo = new Map<string, PluginEntry>()
  const byNpm = new Map<string, PluginEntry>()

  // 第零层：上一轮快照作底账——某数据源暂时限流/失败时保留旧数据，保证榜单可用。
  if (previous) {
    for (const seed of previous.entries) {
      const clone: PluginEntry = { ...seed, sources: [...seed.sources] }
      if (seed.repo) byRepo.set(seed.repo, clone)
      else if (seed.npm) byNpm.set(seed.npm, clone)
    }
  }

  // 第一层：GitHub 主题（热度主来源）。
  for (const repo of githubRepos) {
    const existing = byRepo.get(repo.full_name.toLowerCase())
    const entry = entryFromRepo(repo, ['github-topic'])
    if (existing) {
      // 保留底账里的 npm 关联与下载量，避免限流轮次丢数据。
      entry.npm = existing.npm
      entry.npmUrl = existing.npmUrl
      entry.downloads = existing.downloads
      entry.sources = existing.sources
    }
    const omdItem = omd.get(repo.full_name.toLowerCase())
    if (omdItem) {
      applyOmd(entry, omdItem)
      addSource(entry, 'oh-my-dsh')
    }
    addSource(entry, 'github-topic')
    byRepo.set(entry.id, entry)
  }

  // 第二层：awesome 精选清单（补充未进 Top200 但被精选的仓库）。
  for (const item of awesome) {
    let entry = byRepo.get(item.repo)
    if (!entry) {
      const omdItem = omd.get(item.repo)
      entry = {
        id: item.repo,
        name: item.repo.split('/')[1] ?? item.repo,
        repo: item.repo,
        description: omdItem?.note ?? item.description,
        stars: omdItem?.stars ?? 0,
        forks: omdItem?.forks ?? 0,
        downloads: 0,
        url: `https://github.com/${item.repo}`,
        sources: ['awesome-dsh'],
      }
      if (omdItem) {
        applyOmd(entry, omdItem)
        addSource(entry, 'oh-my-dsh')
      }
      byRepo.set(item.repo, entry)
    } else {
      addSource(entry, 'awesome-dsh')
    }
  }

  // 第三层：npm 包（下载量 + npm 元数据；能对应仓库的并入仓库条目）。
  for (const [pkgName, pkg] of npmPackages) {
    const repo = repoFromNpm(pkg.links?.repository)
    if (repo && byRepo.has(repo)) {
      const entry = byRepo.get(repo)!
      if (!entry.npm) entry.npm = pkgName
      if (!entry.npmUrl) entry.npmUrl = pkg.links?.npm ?? `https://www.npmjs.com/package/${pkgName}`
      if (!entry.description && pkg.description) entry.description = pkg.description
      addSource(entry, 'npm')
      byNpm.set(pkgName, entry)
      continue
    }
    if (byNpm.has(pkgName)) continue
    byNpm.set(pkgName, {
      id: pkgName,
      name: pkgName,
      npm: pkgName,
      description: pkg.description ?? '',
      stars: 0,
      forks: 0,
      downloads: 0,
      url: pkg.links?.npm ?? `https://www.npmjs.com/package/${pkgName}`,
      npmUrl: pkg.links?.npm ?? `https://www.npmjs.com/package/${pkgName}`,
      sources: ['npm'],
    })
  }

  // 下载量回填：优先榜单条目中的 npm 包。
  const npmNames = [...byNpm.keys()]
  const downloads = await fillDownloads(npmNames, warnings)
  for (const [pkgName, value] of downloads) {
    const entry = byNpm.get(pkgName)
    if (entry) entry.downloads = value
  }

  const entries = [...new Set(new Map([...byRepo, ...byNpm]).values())]
    .filter((entry) => entry.stars > 0 || entry.downloads > 0 || entry.sources.includes('awesome-dsh'))
    .sort(
      (a, b) =>
        b.stars - a.stars ||
        b.downloads - a.downloads ||
        a.name.localeCompare(b.name),
    )
    .slice(0, SNAPSHOT_ENTRY_CAP)

  const counts = {
    total: entries.length,
    withStars: entries.filter((entry) => entry.stars > 0).length,
    withDownloads: entries.filter((entry) => entry.downloads > 0).length,
    bySource: {
      'github-topic': entries.filter((entry) => entry.sources.includes('github-topic')).length,
      'oh-my-dsh': entries.filter((entry) => entry.sources.includes('oh-my-dsh')).length,
      'awesome-dsh': entries.filter((entry) => entry.sources.includes('awesome-dsh')).length,
      npm: entries.filter((entry) => entry.sources.includes('npm')).length,
    } as Record<PluginSource, number>,
  }

  return {
    version: 1,
    generatedAt: new Date().toISOString(),
    counts,
    warnings,
    entries,
  }
}

/* ─────────────────────────── 持久化与调度 ─────────────────────────── */

export function apply(ctx: Context, raw: RankingsConfig = {}): void {
  const dshHome = process.env.DSH_HOME || join(homedir(), '.dsh')
  const pluginDir = join(dshHome, 'plugins', 'dsh-plugin-rankings')
  const dataFile = join(pluginDir, 'data.json')
  const settingsFile = join(pluginDir, 'settings.json')
  const logFile = join(dshHome, 'super-injector', 'dsh-plugin-rankings.log')

  logger = (line: string): void => {
    try {
      mkdirSync(dirname(logFile), { recursive: true })
      appendFileSync(logFile, `[${new Date().toISOString()}] ${line}\n`)
    } catch {
      /* 日志失败不影响主流程 */
    }
    ctx.logger?.info?.(`[${PLUGIN_ID}] ${line}`)
  }

  const readSnapshot = (): RankingsSnapshot | null => {
    try {
      const parsed = JSON.parse(readFileSync(dataFile, 'utf8')) as RankingsSnapshot
      if (parsed && parsed.version === 1 && Array.isArray(parsed.entries)) return parsed
      return null
    } catch {
      return null
    }
  }

  const writeSnapshot = (snapshot: RankingsSnapshot): void => {
    mkdirSync(pluginDir, { recursive: true })
    const tmp = `${dataFile}.tmp`
    writeFileSync(tmp, JSON.stringify(snapshot), 'utf8')
    renameSync(tmp, dataFile)
  }

  const readUserSettings = (): RankingsSettings => {
    try {
      const parsed = JSON.parse(readFileSync(settingsFile, 'utf8')) as unknown
      return normalizeSettings(parsed)
    } catch {
      return normalizeSettings({})
    }
  }

  const saveUserSettings = (settings: RankingsSettings): void => {
    mkdirSync(pluginDir, { recursive: true })
    writeFileSync(settingsFile, JSON.stringify(settings, null, 2) + '\n', 'utf8')
  }

  // loader 旧配置只影响「整理间隔」的部署默认，其余以用户设置为准。
  let settings = readUserSettings()
  if (!existsSync(settingsFile) && raw.refreshHours !== undefined) {
    settings = normalizeSettings({ ...settings, refreshHours: raw.refreshHours })
  }

  let snapshot: RankingsSnapshot | null = readSnapshot()
  let refreshing = false
  let lastError: string | null = null

  const refresh = async (): Promise<void> => {
    if (refreshing) return
    refreshing = true
    const startedAt = Date.now()
    log('开始每日榜单整理…')
    try {
      const next = await aggregate(snapshot)
      snapshot = next
      lastError = null
      writeSnapshot(next)
      log(`榜单整理完成：${next.counts.total} 个条目，耗时 ${((Date.now() - startedAt) / 1000).toFixed(1)}s`)
    } catch (error) {
      lastError = errorText(error)
      log(`榜单整理失败：${lastError}`)
      // 已有快照时保留旧数据，界面继续可用。
      if (snapshot) {
        snapshot = {
          ...snapshot,
          warnings: [...snapshot.warnings.slice(-9), `最近一次整理失败：${lastError}`],
        }
        writeSnapshot(snapshot)
      }
    } finally {
      refreshing = false
    }
  }

  /* ─────────── HTTP API（设置页 client 使用） ─────────── */

  ctx.inject(['webServer'], (httpCtx) => {
    const web = (httpCtx as typeof httpCtx & {
      webServer: { register: (route: {
        kind: 'exact'
        path: string
        handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>
      }) => () => void }
    }).webServer

    httpCtx.effect(() => {
      const disposers: Array<() => void> = []
      disposers.push(web.register({
        kind: 'exact',
        path: DATA_API_PATH,
        handler: (req, res) => {
          sendJson(res, 200, {
            snapshot,
            refreshing,
            settings,
            lastError,
            lastAttempt: snapshot?.generatedAt ?? null,
          })
        },
      }))
      disposers.push(web.register({
        kind: 'exact',
        path: SETTINGS_API_PATH,
        handler: async (req, res) => {
          if (req.method === 'GET') {
            sendJson(res, 200, settings)
            return
          }
          if (req.method === 'PUT') {
            try {
              const parsed: unknown = JSON.parse(await readBody(req, MAX_CONFIG_BODY_BYTES))
              settings = normalizeSettings(parsed)
              saveUserSettings(settings)
              sendJson(res, 200, settings)
            } catch (error) {
              sendJson(res, 400, {
                error: 'INVALID_CONFIG',
                message: error instanceof Error ? error.message : '配置不是合法 JSON',
              })
            }
            return
          }
          res.setHeader('allow', 'GET, PUT')
          res.writeHead(405)
          res.end('method not allowed')
        },
      }))
      disposers.push(web.register({
        kind: 'exact',
        path: REFRESH_API_PATH,
        handler: (req, res) => {
          if (req.method !== 'POST') {
            res.setHeader('allow', 'POST')
            res.writeHead(405)
            res.end('method not allowed')
            return
          }
          if (refreshing) {
            sendJson(res, 200, { started: false, reason: 'busy' })
            return
          }
          void refresh()
          sendJson(res, 202, { started: true })
        },
      }))
      return () => {
        for (const dispose of disposers) dispose()
      }
    }, `${PLUGIN_ID}: http api`)
  })

  /* ─────────── 每日调度：启动补漏 + 周期检查 ─────────── */

  ctx.effect(() => {
    let disposed = false
    let running = false

    const staleHours = (): number => {
      if (!snapshot) return Infinity
      const age = Date.now() - Date.parse(snapshot.generatedAt)
      if (!Number.isFinite(age)) return Infinity
      return age / 3_600_000
    }

    const tick = async (): Promise<void> => {
      if (disposed || running || refreshing) return
      if (!settings.autoRefresh) return
      if (staleHours() < settings.refreshHours) return
      running = true
      await refresh()
      running = false
    }

    // 启动时若数据缺失或过期则立即补一次；然后每 6 小时检查一次。
    void tick()
    const timer = setInterval(() => {
      void tick()
    }, 6 * 3_600_000)
    timer.unref?.()

    return () => {
      disposed = true
      clearInterval(timer)
    }
  }, `${PLUGIN_ID}: daily scheduler`)

  log(
    `host half 已启动（autoRefresh=${settings.autoRefresh}, refreshHours=${settings.refreshHours}, ` +
    `已缓存条目=${snapshot?.entries.length ?? 0}）`,
  )
}

/* ─────────────────────────── HTTP 小工具 ─────────────────────────── */

const MAX_CONFIG_BODY_BYTES = 64 * 1024

function readBody(req: IncomingMessage, limit: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    let size = 0
    req.on('data', (chunk: Buffer) => {
      size += chunk.length
      if (size > limit) {
        reject(new Error('请求体超过 64KB 上限'))
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

function sendJson(res: ServerResponse, status: number, payload: unknown): void {
  const body = JSON.stringify(payload)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
  })
  res.end(body)
}
