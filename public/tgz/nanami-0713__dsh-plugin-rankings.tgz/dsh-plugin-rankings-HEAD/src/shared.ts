/**
 * @dsh-external/dsh-plugin-rankings — 共享数据模型（host 与 client 共用）。
 *
 * host 每天聚合一次 dsh-plugin 生态数据（GitHub dsh-plugin 主题、
 * Oh-My-DSH 聚合目录、awesome-dsh 精选清单、npm 搜索 + 周下载量），
 * 落盘到 ~/.dsh/plugins/dsh-plugin-rankings/data.json；
 * 用户设置持久化在 settings.json，经同源 HTTP API 读写。
 */

export const PLUGIN_ID = '@dsh-external/dsh-plugin-rankings'

export const DATA_API_PATH = '/api/dsh-plugin-rankings/data'
export const SETTINGS_API_PATH = '/api/dsh-plugin-rankings/settings'
export const REFRESH_API_PATH = '/api/dsh-plugin-rankings/refresh'

/** 数据来源。 */
export type PluginSource = 'github-topic' | 'oh-my-dsh' | 'awesome-dsh' | 'npm'

/** 排序键：热度（GitHub Star，默认）或下载量（npm 周下载）。 */
export type SortKey = 'popularity' | 'downloads'

export interface PluginEntry {
  /** 稳定 key：repo 小写全名或 npm 包名。 */
  id: string
  /** 展示名（npm 包名或仓库短名）。 */
  name: string
  /** GitHub owner/repo。 */
  repo?: string
  /** npm 包名。 */
  npm?: string
  description: string
  /** 热度：GitHub Star 数。 */
  stars: number
  /** GitHub Fork 数。 */
  forks: number
  /** 下载量：npm 最近一周下载数（无 npm 包时为 0）。 */
  downloads: number
  /** Oh-My-DSH 分类（webui/skin/code/…）。 */
  category?: string
  /** Oh-My-DSH 类型（插件/工具/项目/…）。 */
  type?: string
  /** 人工编目备注。 */
  note?: string
  /** 活跃度信号（🟢 活跃 / 🟡 关注 / …）。 */
  activity?: string
  language?: string
  license?: string
  pushedAt?: string
  createdAt?: string
  /** 主链接（GitHub 优先，否则 npm）。 */
  url: string
  npmUrl?: string
  sources: PluginSource[]
}

export interface RankingsSnapshot {
  version: 1
  /** 快照生成时间（ISO）。 */
  generatedAt: string
  counts: {
    total: number
    withStars: number
    withDownloads: number
    bySource: Record<PluginSource, number>
  }
  /** 采集过程中的非致命告警（如 GitHub 限流）。 */
  warnings: string[]
  /** 按热度（Star）降序预排好的全量条目；客户端再按所选排序键重排。 */
  entries: PluginEntry[]
}

export interface RankingsSettings {
  version: 1
  /** 榜单条数：10 或 100。 */
  topN: number
  /** 排序键，默认热度。 */
  sortKey: SortKey
  /** 是否每天自动整理（默认 true）。 */
  autoRefresh: boolean
  /** 自动整理间隔（小时，默认 24）。 */
  refreshHours: number
}

export const DEFAULT_SETTINGS: RankingsSettings = Object.freeze({
  version: 1,
  topN: 10,
  sortKey: 'popularity',
  autoRefresh: true,
  refreshHours: 24,
})

export const SOURCE_LABELS: Record<PluginSource, string> = {
  'github-topic': 'GitHub',
  'oh-my-dsh': 'Oh-My-DSH',
  'awesome-dsh': 'awesome',
  npm: 'npm',
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function clampNumber(value: unknown, min: number, max: number, fallback: number): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return fallback
  return Math.min(max, Math.max(min, value))
}

function boolValue(value: unknown, fallback: boolean): boolean {
  return typeof value === 'boolean' ? value : fallback
}

function oneOf<T extends string>(value: unknown, options: readonly T[], fallback: T): T {
  if (typeof value === 'string' && (options as readonly string[]).includes(value)) return value as T
  return fallback
}

export function normalizeSettings(input: unknown): RankingsSettings {
  const root = isRecord(input) ? input : {}
  const topN = Math.round(clampNumber(root.topN, 10, 100, DEFAULT_SETTINGS.topN))
  return {
    version: 1,
    topN: topN === 100 ? 100 : 10,
    sortKey: oneOf<SortKey>(root.sortKey, ['popularity', 'downloads'], DEFAULT_SETTINGS.sortKey),
    autoRefresh: boolValue(root.autoRefresh, DEFAULT_SETTINGS.autoRefresh),
    refreshHours: Math.round(clampNumber(root.refreshHours, 6, 168, DEFAULT_SETTINGS.refreshHours)),
  }
}

/** 数字友好格式化：≥1 万显示「x.x万」，≥1 千显示「x.xk」，否则原样。 */
export function formatCount(value: number): string {
  if (!Number.isFinite(value) || value < 0) return '0'
  if (value >= 100_000_000) return `${(value / 100_000_000).toFixed(1)}亿`
  if (value >= 10_000) return `${(value / 10_000).toFixed(1)}万`
  if (value >= 1000) return `${(value / 1000).toFixed(1)}k`
  return String(value)
}
