# @dsh-external/dsh-plugin-rankings

DSH 插件榜单：每天整理一次 dsh-plugin 生态 **Top 10 / Top 100**，支持按
**热度**（GitHub Star）或 **下载量**（npm 最近一周下载）降序排序，默认按热度。
入口集成在 DSH Web 设置页，与其他插件设置并列。

## 数据来源

| 来源 | 用途 | 接口 |
|---|---|---|
| GitHub `dsh-plugin` 主题 | 热度主指标（Star/Fork）、仓库元数据 | `api.github.com/search/repositories` |
| [Oh-My-DSH](https://github.com/like-study1/Oh-My-DSH) 聚合目录 | 分类、人工备注、活跃度信号、类型 | `data/plugins.json`（jsDelivr CDN） |
| [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin) 精选清单 | 精选徽标与补录条目 | README 逐行解析（jsDelivr CDN） |
| npm 关键字搜索 + 周下载量 | 下载量指标、npm 包链接 | `registry.npmjs.org` / `api.npmjs.org` |

全部为公开只读接口，无鉴权；host 每天（默认 24 小时，可调 12–72 小时）
自动整理一次，也可在设置页点击「立即整理」手动触发。

## 功能

- 榜单范围：Top 10 / Top 100 一键切换
- 排序：热度（默认）/ 下载量，均降序；显示排名徽章（前三金银铜）
- 每个条目展示：Star、周下载、分类、活跃度、语言、License、更新时间、
  来源徽标（GitHub / Oh-My-DSH / awesome / npm），可点击直达 GitHub 与 npm
- 自动整理开关与间隔设置；采集告警与失败状态可见；旧快照保留，采集失败不影响展示

## 架构

标准 DSH 双端 bundle 插件：

- **host 半**（`lib/index.js`）：多源聚合管线 + 快照落盘
  `~/.dsh/plugins/dsh-plugin-rankings/data.json` + 每日调度（启动补漏 +
  每 6 小时检查） + 同源 HTTP API：
  - `GET  /api/dsh-plugin-rankings/data` 快照、设置与整理状态
  - `GET/PUT /api/dsh-plugin-rankings/settings` 用户设置
  - `POST /api/dsh-plugin-rankings/refresh` 手动触发整理
- **client 半**（`lib/client.js`）：注册 `settings.section` 槽位
  「插件榜单」，React 组件渲染榜单与设置控件

## 开发

```bash
npm install
npm run build:all   # tsc 编译 host + tsdown 打包 client
npm run typecheck
```

## 安装

```bash
dsh plugin add /path/to/dsh-plugin-rankings
# 或热装配：改 profile package.json（link 依赖 + bundles）后重启
```

## License

MIT
