import { afterEach, describe, expect, it, vi } from 'vitest'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { Config as ConfigSchema, resolveConfig, type Config } from '../../src/config.ts'

const valid: Config = { binaryPath: '/opt/md2wechat' }

afterEach(() => vi.unstubAllEnvs())

describe('resolveConfig', () => {
  it('rejects unknown fields through the exported configuration schema', () => {
    expect(() => ConfigSchema({ ...valid, unexpected: true } as unknown as Config)).toThrow('unknown configuration field')
  })

  it('rejects a relative binary path', () => {
    expect(() => resolveConfig({ ...valid, binaryPath: './md2wechat' })).toThrow('absolute executable path')
  })

  it('rejects an artifacts directory outside the session workspace', () => {
    expect(() => resolveConfig({ ...valid, artifactsDir: '../outside' })).toThrow('session workspace')
  })

  it('rejects a relative external state directory', () => {
    expect(() => resolveConfig({ ...valid, stateDir: '.dsh/state' })).toThrow('stateDir must be an absolute path')
  })

  it('uses an absolute DSH_HOME for the plugin-specific default and rejects a relative one', () => {
    vi.stubEnv('DSH_HOME', '/srv/dsh-home')
    expect(resolveConfig(valid).stateDir).toBe('/srv/dsh-home/plugins/dsh-md2wechat')
    vi.stubEnv('DSH_HOME', 'workspace-home')
    expect(() => resolveConfig(valid)).toThrow('DSH_HOME must be an absolute path')
  })

  it('does not evaluate DSH_HOME when an explicit absolute state directory is supplied', () => {
    vi.stubEnv('DSH_HOME', 'workspace-home')
    expect(resolveConfig({ ...valid, stateDir: '/var/lib/dsh-md2wechat' }).stateDir).toBe('/var/lib/dsh-md2wechat')
  })

  it('rejects a non-positive foreground timeout', () => {
    expect(() => resolveConfig({ ...valid, foregroundTimeoutMs: 0 })).toThrow('positive integer')
  })

  it.each([
    ['imageMaxBytes', 0],
    ['imageMaxRedirects', -1],
    ['imageAcquisitionTimeoutMs', 0],
  ] as const)('rejects invalid %s', (field, value) => {
    expect(() => resolveConfig({ ...valid, [field]: value })).toThrow('integer')
  })

  it('caps image acquisition below the artifact-store maximum', () => {
    expect(() => resolveConfig({ ...valid, imageMaxBytes: 64 * 1024 * 1024 + 1 })).toThrow('maximum')
  })

  it('rejects unsupported credential environment names', () => {
    expect(() => resolveConfig({
      ...valid,
      credentialRefs: { BAD_SECRET: 'env:BAD_SECRET' },
    } as unknown as Config)).toThrow('not supported')
  })

  it.each([
    ['previewFontSize', 'huge'],
    ['previewBackgroundType', 'paper'],
  ] as const)('rejects an unsupported %s', (field, value) => {
    expect(() => resolveConfig({ ...valid, [field]: value })).toThrow('supported')
  })

  it('rejects unknown runtime configuration fields', () => {
    expect(() => resolveConfig({ ...valid, unexpected: true } as unknown as Config)).toThrow('unknown configuration field')
  })

  it('returns the supplied absolute binary path and safe defaults', () => {
    expect(resolveConfig(valid)).toEqual({
      binaryPath: '/opt/md2wechat',
      artifactsDir: '.dsh/md2wechat',
      stateDir: join(process.env.DSH_HOME?.trim() || join(homedir(), '.dsh'), 'plugins', 'dsh-md2wechat'),
      layoutBaseUrl: 'https://www.md2wechat.cn',
      previewTheme: 'default',
      previewFontSize: 'medium',
      previewBackgroundType: 'none',
      enableWechatWriteTools: true,
      enableFallbackImageTool: true,
      safeReadRetries: 1,
      safeReadRetryDelayMs: 500,
      foregroundTimeoutMs: 120000,
      imageJobTimeoutMs: 900000,
      imageMaxBytes: 20971520,
      imageMaxRedirects: 3,
      imageAcquisitionTimeoutMs: 60000,
      credentialRefs: { MD2WECHAT_API_KEY: 'MD2WECHAT_API_KEY' },
    })
  })
})
