import { execFile } from 'node:child_process'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { promisify } from 'node:util'
import { describe, expect, it } from 'vitest'

const exec = promisify(execFile)
const repositoryRoot = resolve(import.meta.dirname, '../..')

describe('installed acceptance harness', () => {
  it('fails loud before doing work when absolute acceptance inputs are absent', async () => {
    const execution = exec(process.execPath, ['scripts/installed-acceptance.mjs'], {
      cwd: repositoryRoot,
      env: { PATH: process.env.PATH ?? '' },
      timeout: 10_000,
    })

    await expect(execution).rejects.toMatchObject({
      stderr: expect.stringContaining('DSH_CHECKOUT must be an absolute path'),
    })
  })

  it('uses the Web child scrubbed environment for both normal and failure tree cleanup', async () => {
    const source = await readFile(resolve(repositoryRoot, 'scripts/installed-acceptance.mjs'), 'utf8')
    expect(source.match(/stopProcessTreeBounded\(child, exited, \{\n\s+environment: webEnvironment,/gu)).toHaveLength(2)
    expect(source).not.toContain('await exited.catch')
  })

  it('routes a supplied archive to the published-host acceptance without rebuilding a source checkout', async () => {
    const execution = exec(process.execPath, ['scripts/installed-acceptance.mjs', '--package', '/missing-fixture.tgz'], {
      cwd: repositoryRoot,
      env: { PATH: process.env.PATH ?? '' },
      timeout: 10_000,
    })
    await expect(execution).rejects.toMatchObject({
      stderr: expect.stringContaining('--host absolute path required'),
    })
  })
})
