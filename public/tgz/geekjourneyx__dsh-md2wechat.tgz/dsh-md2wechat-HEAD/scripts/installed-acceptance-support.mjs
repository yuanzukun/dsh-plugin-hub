import { spawn } from 'node:child_process'
import { lstat, realpath, stat } from 'node:fs/promises'
import { dirname, isAbsolute, relative, resolve, sep, win32 } from 'node:path'


export function createChildEnvironment({ ambient, taskRoot, dshHome, cliPath, extra = {} }) {
  const environment = {
    PATH: ambient.PATH ?? '',
    LANG: 'C',
    LC_ALL: 'C',
    HOME: resolve(taskRoot, 'home'),
    TMPDIR: resolve(taskRoot, 'tmp'),
    XDG_CONFIG_HOME: resolve(taskRoot, 'xdg', 'config'),
    XDG_CACHE_HOME: resolve(taskRoot, 'xdg', 'cache'),
    XDG_DATA_HOME: resolve(taskRoot, 'xdg', 'data'),
    PNPM_HOME: resolve(taskRoot, 'pnpm-home'),
    COREPACK_HOME: resolve(taskRoot, 'corepack-home'),
    npm_config_userconfig: resolve(taskRoot, 'npmrc'),
    NPM_CONFIG_USERCONFIG: resolve(taskRoot, 'npmrc'),
    npm_config_cache: resolve(taskRoot, 'npm-cache'),
    pnpm_config_store_dir: resolve(taskRoot, 'pnpm-store'),
    npm_config_update_notifier: 'false',
    NO_UPDATE_NOTIFIER: '1',
    CI: '1',
    DSH_HOME: dshHome,
    DSH_TELEMETRY_DISABLED: '1',
    DSH_PERMISSION_MODE: 'workspace-write',
    MD2WECHAT_BINARY_PATH: cliPath,
  }
  for (const name of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT']) {
    if (process.platform === 'win32' && ambient[name] !== undefined) environment[name] = ambient[name]
  }
  for (const [name, value] of Object.entries(extra)) {
    if (value === undefined) delete environment[name]
    else environment[name] = value
  }
  return environment
}

export function expectedWorkflowPrompt(writeEnabled, fallbackEnabled) {
  const lines = [
    'For an article, open md2wechat_open_workspace first. The native workspace owns theme selection, exact suggestions, image choices, final review and delivery; do not ask the author to orchestrate a tool chain.',
    'Only propose changes for a pending workspace request. Never silently rewrite source files. Treat the displayed signed preview as the review boundary; after final material preparation, review that exact final HTML again.',
    'Legacy low-level tools are retained for explicit compatibility or diagnostics, not the default creator experience.',
  ]
  if (writeEnabled) {
    lines.push('Saving a WeChat draft requires explicit native confirmation and approval. It creates an unpublished draft and never publishes or mass-sends.')
    if (fallbackEnabled) lines.push('Prefer the current host image capability. md2wechat_generate_creator_images is fallback only and uploads every generated candidate to WeChat material storage; disclose this and obtain its one-time approval.')
  }
  return lines.join('\n')
}

export function assertWorkflowPrompt(sections, writeEnabled, fallbackEnabled) {
  const matches = sections.filter(section => section.name === 'tool:md2wechat')
  if (matches.length !== 1) throw new Error('expected exactly one md2wechat workflow prompt section')
  if (matches[0].text !== expectedWorkflowPrompt(writeEnabled, fallbackEnabled)) {
    throw new Error('md2wechat prompt does not contain the exact workflow text')
  }
}

export async function createTaskRootGuard(taskRoot, options) {
  if (!isAbsolute(taskRoot)) throw new Error('task root must be absolute')
  const resolvedRoot = resolve(taskRoot)
  const entry = await lstat(resolvedRoot)
  if (entry.isSymbolicLink()) throw new Error('task root must not be a symbolic link')
  if (!entry.isDirectory()) throw new Error('task root must be a directory')
  const canonicalRoot = await realpath(resolvedRoot)
  const native = await stat(canonicalRoot)
  const canonicalOptions = {
    ...options,
    userHome: options.userHome === undefined ? undefined : await canonicalOrResolved(options.userHome),
    forbiddenRoots: await Promise.all(options.forbiddenRoots.map(canonicalOrResolved)),
  }
  assertSafeCanonicalRoot(canonicalRoot, canonicalOptions)
  const identity = nativeIdentity(native)

  const assertCurrent = async () => {
    let currentEntry
    try {
      currentEntry = await lstat(resolvedRoot)
    } catch {
      throw new Error('task root identity changed')
    }
    if (currentEntry.isSymbolicLink() || !currentEntry.isDirectory()) throw new Error('task root identity changed')
    const currentCanonical = await realpath(resolvedRoot)
    const currentNative = await stat(currentCanonical)
    if (currentCanonical !== canonicalRoot || nativeIdentity(currentNative) !== identity) {
      throw new Error('task root identity changed')
    }
    assertSafeCanonicalRoot(currentCanonical, canonicalOptions)
  }

  const assertCleanupTarget = async (target) => {
    await assertCurrent()
    const resolvedTarget = resolve(target)
    if (!inside(resolvedTarget, canonicalRoot) || resolvedTarget === canonicalRoot) {
      throw new Error(`refusing to clean unsafe task path: ${resolvedTarget}`)
    }
    try {
      const targetEntry = await lstat(resolvedTarget)
      if (targetEntry.isSymbolicLink()) throw new Error(`refusing to clean symbolic-link task path: ${resolvedTarget}`)
      const canonicalTarget = await realpath(resolvedTarget)
      if (!inside(canonicalTarget, canonicalRoot) || canonicalTarget === canonicalRoot) {
        throw new Error(`refusing to clean escaped task path: ${resolvedTarget}`)
      }
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
      const canonicalParent = await realpath(dirname(resolvedTarget))
      if (!inside(canonicalParent, canonicalRoot)) throw new Error(`refusing to clean escaped task path: ${resolvedTarget}`)
    }
  }

  return { canonicalRoot, assertCurrent, assertCleanupTarget }
}

async function canonicalOrResolved(path) {
  try {
    return await realpath(resolve(path))
  } catch (error) {
    if (error?.code === 'ENOENT') return resolve(path)
    throw error
  }
}

function assertSafeCanonicalRoot(canonicalRoot, options) {
  const root = resolve(canonicalRoot)
  const parsedParts = root.split(sep).filter(Boolean)
  if (root === resolve(root, sep) || parsedParts.length < 3) throw new Error('task root is dangerously broad')
  const platformTempRoot = resolve(options.platformTempRoot)
  if (inside(root, platformTempRoot)) throw new Error('task root must stay outside the platform temporary directory')
  const userHome = options.userHome === undefined ? undefined : resolve(options.userHome)
  if (userHome !== undefined && (root === userHome || inside(userHome, root))) {
    throw new Error('task root must not be the user home or its ancestor')
  }
  for (const forbidden of options.forbiddenRoots) {
    const forbiddenRoot = resolve(forbidden)
    if (root === forbiddenRoot || inside(root, forbiddenRoot) || inside(forbiddenRoot, root)) {
      throw new Error(`task root overlaps protected source or state path: ${forbiddenRoot}`)
    }
  }
}

function nativeIdentity(value) {
  return `${String(value.dev)}:${String(value.ino)}`
}

function inside(candidate, parent) {
  const offset = relative(resolve(parent), resolve(candidate))
  return offset === '' || (!offset.startsWith(`..${sep}`) && offset !== '..' && !isAbsolute(offset))
}

export async function runBounded(command, args, options) {
  const child = spawn(command, args, {
    cwd: options.cwd,
    env: options.env,
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: process.platform !== 'win32',
  })
  let stdout = ''
  let stderr = ''
  child.stdout.setEncoding('utf8')
  child.stderr.setEncoding('utf8')
  child.stdout.on('data', chunk => { stdout += chunk })
  child.stderr.on('data', chunk => { stderr += chunk })

  const exit = new Promise((resolveExit, rejectExit) => {
    child.once('error', rejectExit)
    child.once('exit', (code, signal) => resolveExit({ code, signal }))
  })
  let timer
  const timeout = new Promise(resolveTimeout => {
    timer = setTimeout(() => resolveTimeout({ timedOut: true }), options.timeoutMs)
  })
  let first
  try {
    first = await Promise.race([exit, timeout])
  } finally {
    clearTimeout(timer)
  }
  if (first.timedOut !== true) return { ...first, stdout, stderr }

  const error = new Error(`${options.label} timed out after ${options.timeoutMs} ms`)
  error.stdout = stdout
  error.stderr = stderr
  try {
    await stopProcessTreeBounded(child, exit, {
      environment: options.env,
      killGraceMs: options.killGraceMs,
      exitTimeoutMs: options.killGraceMs,
      label: options.label,
    })
  } catch (cleanupError) {
    throw new AggregateError([error, cleanupError], `${options.label} timed out and cleanup failed`)
  }
  throw error
}

export async function stopProcessTreeBounded(child, exit, options) {
  const failures = []
  const terminate = options.terminate ?? terminateProcessTree
  try {
    await withDeadline(
      terminate(child, exit, options.killGraceMs, { environment: options.environment }),
      options.exitTimeoutMs,
      `${options.label} process-tree termination timed out after ${options.exitTimeoutMs} ms`,
    )
  } catch (error) {
    failures.push(error)
  }
  let outcome
  try {
    outcome = await withDeadline(
      exit,
      options.exitTimeoutMs,
      `${options.label} exit observation timed out after ${options.exitTimeoutMs} ms`,
    )
  } catch (error) {
    failures.push(error)
  }
  if (failures.length > 0) throw new AggregateError(failures, `${options.label} cleanup failed`)
  return outcome
}

async function withDeadline(promise, timeoutMs, message) {
  let timer
  const timeout = new Promise((_, rejectTimeout) => {
    timer = setTimeout(() => rejectTimeout(new Error(message)), timeoutMs)
  })
  try {
    return await Promise.race([promise, timeout])
  } finally {
    clearTimeout(timer)
  }
}

export async function terminateProcessTree(child, exit, killGraceMs, options = {}) {
  if (child.pid === undefined) return
  const platform = options.platform ?? process.platform
  if (platform === 'win32') {
    const cleanup = resolveWindowsCleanup(options.environment ?? {})
    await taskkillProcessTree(child.pid, killGraceMs, cleanup.command, cleanup.environment, options.spawnProcess ?? spawn)
    return
  }

  const signalProcessGroup = options.signalProcessGroup ?? process.kill
  signalPosixGroup(child.pid, 'SIGTERM', signalProcessGroup)
  if (await waitForGroupExit(child.pid, killGraceMs, signalProcessGroup)) {
    return
  }
  signalPosixGroup(child.pid, 'SIGKILL', signalProcessGroup)
  const killed = await waitForGroupExit(child.pid, killGraceMs, signalProcessGroup)
  if (!killed) throw new Error(`process group ${child.pid} survived SIGKILL`)
}

function signalPosixGroup(pid, signal, signalProcessGroup) {
  try {
    signalProcessGroup(-pid, signal)
  } catch (error) {
    if (error?.code !== 'ESRCH') throw error
  }
}

async function waitForGroupExit(pid, timeoutMs, signalProcessGroup) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (!isProcessGroupAlive(pid, signalProcessGroup)) return true
    await delay(10)
  }
  return !isProcessGroupAlive(pid, signalProcessGroup)
}

function isProcessGroupAlive(pid, signalProcessGroup) {
  try {
    signalProcessGroup(-pid, 0)
    return true
  } catch (error) {
    if (error?.code === 'ESRCH') return false
    if (error?.code === 'EPERM') return true
    throw error
  }
}

function resolveWindowsCleanup(environment) {
  const systemRoot = validWindowsAbsolute(environment.SystemRoot) ? environment.SystemRoot : undefined
  const windowsDirectory = validWindowsAbsolute(environment.WINDIR) ? environment.WINDIR : undefined
  const commandInterpreter = validWindowsAbsolute(environment.ComSpec) ? environment.ComSpec : undefined
  const root = systemRoot ?? windowsDirectory
  const command = root === undefined
    ? commandInterpreter === undefined
      ? undefined
      : win32.join(win32.dirname(commandInterpreter), 'taskkill.exe')
    : win32.join(root, 'System32', 'taskkill.exe')
  if (command === undefined) {
    throw new Error('cannot locate Windows taskkill from an absolute SystemRoot, WINDIR, or ComSpec')
  }
  return {
    command,
    environment: {
      ...(systemRoot === undefined ? {} : { SystemRoot: systemRoot }),
      ...(windowsDirectory === undefined ? {} : { WINDIR: windowsDirectory }),
      ...(commandInterpreter === undefined ? {} : { ComSpec: commandInterpreter }),
    },
  }
}

function validWindowsAbsolute(value) {
  return typeof value === 'string'
    && value.length > 0
    && !value.includes('\0')
    && !value.includes('\r')
    && !value.includes('\n')
    && win32.isAbsolute(value)
}

async function taskkillProcessTree(pid, timeoutMs, command, environment, spawnProcess) {
  const killer = spawnProcess(command, ['/PID', String(pid), '/T', '/F'], {
    env: environment,
    stdio: 'ignore',
    windowsHide: true,
  })
  const exit = new Promise((resolveExit, rejectExit) => {
    killer.once('error', rejectExit)
    killer.once('exit', code => resolveExit(code))
  })
  let timer
  const timeout = new Promise(resolveTimeout => {
    timer = setTimeout(() => resolveTimeout('timeout'), timeoutMs)
  })
  let outcome
  try {
    outcome = await Promise.race([exit, timeout])
  } finally {
    clearTimeout(timer)
  }
  if (outcome === 'timeout') {
    killer.kill('SIGKILL')
    await exit.catch(() => undefined)
    throw new Error(`taskkill timed out after ${timeoutMs} ms`)
  }
  if (outcome !== 0 && isProcessAlive(pid)) throw new Error(`taskkill failed with exit code ${String(outcome)}`)
}

function delay(milliseconds) {
  return new Promise(resolveDelay => setTimeout(resolveDelay, milliseconds))
}

export function isProcessAlive(pid) {
  try {
    process.kill(pid, 0)
    return true
  } catch (error) {
    if (error?.code === 'ESRCH') return false
    throw error
  }
}
