---
name: canvas-cards
version: 1.0.0
description: "自己拼卡（开放画布）：对话里的 layout 卡和页面主卡的 hero.layout 共用一套零件——大数字、字段、柱图、饼图、作息条、倒计时、散点、清单……共 50 多个。要在对话里发一张 layout 卡、编排页面时写 hero.layout、Psir 要看某个数的图或想要某种卡片样子（「画个饼图」「用几个数字告诉我」「主卡放恢复和 HRV」）、或拿不准该用哪种图时，先读这个 skill。"
---

# 自己拼卡：零件、选法、排法

App 只给画布（对话卡宽 312、最高 520；主卡宽 354、最高 400，主卡的标题行 label + 档位由 App 画）和设计规范。里面怎么排你定。**样式没法写**——颜色、字号、线宽都由 App 按规范画，你只选零件和档位。

零件的写法、限制、数从哪来都在代码里，用命令查，不要凭记忆写：
```sh
./pivis-health parts                         # 全部零件，每个一行：名字、中文名、什么时候用、输入示例
./pivis-health parts --group 趋势             # 只看一组：基础 / 占比 / 时间 / 趋势 / 进度
./pivis-health parts --name sleep_window     # 一个零件的全文：限制、数据来源、高度、能用的 bind
./pivis-health canvas --json '<零件树>'        # 预览 + 校验（主卡加 --slot hero）
```

## 怎么做
1. **先想这张卡回答什么问题**，用一句话说出来（「这周是不是整体少睡了一截」）。这句就是卡的标题。
2. **按下面「选哪种」挑 1–3 个零件**，拿不准就 `./pivis-health parts --name <零件>` 看全文。
3. **写树**：`{"t":"v","gap":12,"children":[标题, 主图或主数, 支撑的一两样]}`。
4. **预览**：`./pivis-health canvas --json '<树>'`（主卡加 `--slot hero`）。返回内核现算后的样子和估算高度；不合规范会直接说哪里不对，照着改再跑。某一格变成「这里的数暂时算不出来（…）」说明那项现在没数据：换一个零件或换个 bind，**不要把缺格的卡发出去**。
5. **发**：对话里 ` ```phealth-ui ` 代码块写 `{"type":"layout","layout":<树>}`，发之前把整条回复过一遍 `./pivis-health card-check`（ok 了再发）；主卡写进编排输出的 `hero.layout`（Psir 要改主卡的样子，按 AGENTS.md 里「两轮」的流程：先预览、他点头再记）。

## 选哪种
| 想讲什么 | 用 |
|---|---|
| 一个最重要的数 | `value`（xl 只放一个）；支撑的数用 `stat` 横排 2–3 个；还想看方向用 `stat_spark` / `sparkline` |
| 每天各多少（每晚睡了多久、每天步数） | `columns`（从 0 起画）；每晚里面深睡 / 快速眼动 / 浅睡各多少用 `stack_columns` |
| 小幅波动、常态带、警戒线（HRV、静息心率、呼吸） | `chart` 的 trend（柱子从 0 起，几个 ms 的差别在柱上看不出来） |
| 今天在自己平时的范围里处在哪 | `spread`；放进 差 / 一般 / 好 三段再标目标用 `bullet` |
| 一个数离目标多远 | `bar` 或 `ring` |
| 变了多少 | `delta`（写清和谁比：前 3 天 / 上一周 / 30 天平均）；按星期对齐这周和上周用 `compare`；两项一起动才算数用 `dual_line` |
| 和一条线比，多了还是少了（欠觉、步数差） | `diverging`；每天一个小量 + 目标（放松几分钟）用 `lollipop` |
| 每天达没达标 | 几天用 `dots`；一个月用 `calendar`；几成做到用 `waffle`；连续几天用 `streak`；本周计划和完成用 `weekgrid` |
| 几样各占多少（睡眠分期、训练强度） | `pie` / `donut`（最多 5 块）；放在大数下面省地方用 `stack`；一次训练在各强度停了多久用 `zones` |
| 两件事有没有关系 | `scatter`（样本少于 14 个画不了；只说相关，不说因果） |
| 平时落在哪（几点睡着、步数） | `histogram` |
| 几点、多久 | 一个时间段用 `time_range`；离某个钟点还有多久用 `countdown`；每晚几点上床几点起用 `sleep_window`；昨晚各阶段怎么走用 `hypnogram`；今天一天的安排用 `clock24` |
| 计划走到哪 | 第几周用 `segments`；阶段少用 `stepper`；开始、复盘、结束用 `milestones`；几个项目各做到多少用 `progress_list`；第几天 / 共几天用 `ring` |
| 几样一起看强弱 | `radar`（睡眠、恢复、运动、压力、习惯，五维固定，换算规则见 `parts --name radar`） |
| 规则、设置、事实 | 一行一条用 `kv`；几晚几样数对齐着看用 `table`；一条规则单独放大用 `quote`；给信息加状态用 `tag`；几条做法用 `list` |
| 今天的待办 | 做没做用 `checklist`；接下来要做的用 `timeline`（主卡里不能放） |
| 练习视频、背景声、照片 | `media`（素材库 id；练习只放 `plannable:true` 的 follow 视频，音频只放白噪音、雨声这类）；Psir 拍的照片加你的点评用 `photo` |

## 怎么排才好看
- **一张卡只讲一件事**：一句 title（`text` role=title，说判断）+ 一个主图或主数 + 最多两样支撑。图选一样就够，别堆。
- 文字只写判断和提示，数字交给 `value` / `stat` / 图。字数：title ≤18、label ≤14、caption ≤40、body ≤60；窄格子（tag、stepper、kv、table）英文和数字算半个字。
- 上下用 `gap` 拉开（一般 12，只能 0/4/8/12/16/24），别连用两条 `rule`；横排 `h` 最多 4 个，两头对齐加 `"justify":"between"`，数字底对齐加 `"align":"baseline"`。
- 一张卡最多 40 个零件、嵌套 5 层；高度超了 `canvas` 会报估算高度，删一样或把图改成 `height:"s"`。
- **数字优先用 bind**（内核现算，永远最新）。手写的数字只能抄工具输出（facts、sleep-week、project-stats、viz…），主卡里抄不到证据的数会被拒；不要自己加减乘除算新数。
- **主卡（hero.layout）里不能放 `timeline`**：页面主卡下面已经列了「接下来」的待办和「坚持习惯」那一行；`checklist` 同理别放，也别重复项目名，除非 Psir 的偏好里明确要。
- 项目 id 用 `./pivis-health project-list` 查；素材 id 用 `./pivis-health media-library` 查。

## Psir 要的样子零件里没有
不要只回「画不了」。用最接近的零件拼一张先给他看，一句话说清哪里不一样（例如「还没有按小时的步数，先用进度条和节奏标记代替」「没有体重的饼图，用 kv 列出来」）。

拼好的整卡例子（都在演示数据上预览过）：`references/examples.md`。
