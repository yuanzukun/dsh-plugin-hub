# 开发说明

## 目录结构

```
dsh-continue/
├── src/
│   ├── index.js            # 插件入口:宿主半,apply 为空(仅为挂 profile 行)
│   └── client.js           # 浏览器半 ModuleLoader bundle:两个快捷按钮
├── docs/                   # 文档与截图
├── cordis.patch.yml        # bundle patch(注入插件行)
└── package.json            # exports + dsh.bundle/dsh.client 清单
```

## 本地装配调试

```bash
dsh plugin --profile web add .   # 在本仓库根目录
# 重启 dsh web 后:输入栏「发送」按钮右侧出现「继续」「讲人话」
```

修改 `src/client.js` 后刷新浏览器即可看到效果(无需重新装配)。

## 设计约定

- **不改 dsh 源码**:一切接入走官方扩展点(bundle patch / client slot)
- **宿主半留白**:node 半无任何逻辑,避免引入安全与维护面
- **按钮语义单一**:只发送固定文本,不覆盖用户草稿(草稿非空时另起一行追加)

## 发布

```bash
git tag v<版本> && git push origin v<版本>   # 打标签发布
```

发布前注意:

- `package.json` 的 `repository.url` 指向真实仓库地址
- 同步更新 [CHANGELOG.md](CHANGELOG.md) 与 README
