# dsh-continue

> **在 dsh 输入栏「发送」按钮右侧,一键「继续」、一键「讲人话」。**
> 长会话跑起来后,最常打的那句指令是「继续」。这个插件把它变成按钮——代替程序员重复的体力活,一点即发。

[English](README.en.md) | 中文

---

## 这是什么

**dsh-continue** 是面向 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)(dsh) 的极简开源插件。

写代码到一半,AI 干到一半停了,你大概率要打「继续」。一次两次没关系,几百轮下来,你其实只是在替 AI 完成打字这件体力活。这个插件在输入栏「发送」按钮右侧加两个快捷按钮:

![dsh-continue 快捷按钮](docs/screenshot.png)

| 按钮 | 发送内容 |
| --- | --- |
| **继续** | `继续` |
| **讲人话** | `请讲人话，简洁生动的解释一遍` |

全部行为只有这些:点了就发,不覆盖你已经打好的草稿(草稿非空时另起一行追加)。插件**不修改 dsh 任何源码**,只挂一行浏览器插件,可随 dsh 平滑升级。

## 安装

```bash
git clone https://github.com/flg1217/dsh-continue.git
cd dsh-continue
pnpm install          # 无第三方依赖,基本是空操作
dsh plugin --profile web add <dsh-continue 目录>
```

安装完成后**重启 dsh web**,输入栏「发送」按钮右侧即出现「继续」「讲人话」两个按钮。

> 本地开发也可以直接在本仓库根目录 `dsh plugin --profile web add .` 装配,行为相同。

## 兼容性与权限

- 兼容 dsh web profile(npx 版或源码版均可);验证于 dsh rc.8。
- **权限范围**:插件仅浏览器端两个按钮,宿主半无逻辑,不访问文件、网络或环境变量。

## 卸载

```bash
dsh plugin --profile web remove dsh-continue
```

或手工清理:移除 profile(`~/.dsh/profiles/web`)中 `dsh-continue` 的 insert 行与 package.json dependencies 条目,重启 dsh web 即完全移除。

## 工作原理

插件为双面结构——浏览器半干活,宿主半留白:

```
┌─────────────── 宿主进程(node 半)─────────────────────┐
│ src/index.js   插件入口(apply 为空,仅为挂 profile 行) │
└───────────────────────────────────────────────────────┘
┌─────────────── 浏览器(web 半)────────────────────────┐
│ src/client.js  conversation.input.right 插槽         │
│                「继续」「讲人话」两个按钮             │
└──────────────────────────────────────────────────────┘
```

- **装配**:`cordis.patch.yml`(bundle patch)注入插件行;package.json 的 `dsh.client` 声明把浏览器半加载进 GUI
- **按钮**:挂在 `conversation.input.right` 插槽(order:100),渲染在发送按钮右侧
- **发送**:草稿为空直接发送按钮文本;草稿非空则另起一行追加,不覆盖你正在输入的内容

## 参与开发

```bash
git clone https://github.com/flg1217/dsh-continue.git
cd dsh-continue
dsh plugin --profile web add .   # 本地装配,改 src/client.js 后刷新即生效
```

详见 [docs/CONTRIBUTING.zh.md](docs/CONTRIBUTING.zh.md)。

## 许可证

[MIT](LICENSE)
