# 支持

## 获取帮助

- 阅读 [README](README.md) 与 [README.en.md](README.en.md)
- 搜索仓库 [Issues](https://github.com/flg1217/dsh-continue/issues) 是否已有相同问题
- 排查步骤:
  1. `dsh plugin --profile web add <本仓库目录>` 确认装配
  2. 重启 dsh web
  3. 查看输入栏「发送」按钮右侧是否出现「继续」「讲人话」两个按钮

## 常见问题

### 按钮没有出现

- 确认已重启 dsh web(插件装配后必须重启)
- 确认 profile(`~/.dsh/profiles/web`)的 `cordis.patch.yml` 中存在 `dsh-continue` 的 insert 行

### 点了「继续」没有效果

按钮只是发送一条消息,效果取决于当前模型/任务状态;若任务已结束,自然不会再继续。

## 问题反馈

请通过 [Issues](https://github.com/flg1217/dsh-continue/issues) 提交问题,并附上:

- dsh 版本与 profile
- 插件版本
- 复现步骤与截图
