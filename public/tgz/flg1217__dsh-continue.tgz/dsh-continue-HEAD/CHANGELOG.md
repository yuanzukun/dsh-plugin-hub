# Changelog

本项目遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 与 [Semantic Versioning](https://semver.org/lang/zh-CN/)。

## [0.1.0] - 2026-09-17

### 新增

- **「继续」快捷按钮**:输入栏「发送」按钮右侧,点击即发送 `继续`——长会话里最常打的一句指令,一键完成
- **「讲人话」快捷按钮**:点击发送 `请讲人话，简洁生动的解释一遍`,让 AI 用通俗语言重新解释
- **不覆盖草稿**:草稿为空直接发送;草稿非空则另起一行追加,不打断用户正在输入的内容
- **双面插件结构**:`src/client.js`(浏览器半,挂 `conversation.input.right` 插槽)+ `src/index.js`(宿主半,仅挂 profile 行),零源码改动 dsh
