// dsh-continue 浏览器半:在输入栏「发送」按钮右侧加两个快捷按钮。
//   「继续」   → 发送 "继续"
//   「讲人话」 → 发送 "请讲人话，简洁生动的解释一遍"
//
// 挂 conversation.input.right(list slot):条目落在 composer 工具行
// (.trailing)里、发送按钮之前。条目自己 order:1,越过默认 order:0 的
// 模型选择/上下文表/发送按钮,排在发送按钮右侧。list slot 的条目直接
// 渲染为 .trailing 的子元素(无包裹 div),所以 order 生效。
window.__ModuleLoader__.load({
  id: 'dsh-continue',
  factory: (require) => {
    const module = { exports: {} }
    const exports = module.exports
    const react = require('react')
    const { Button } = require('@deepseek-ai/dsh-client-ui-primitives')

    // 按钮顺序即渲染顺序;text 是点下去要发出去的内容。
    const ACTIONS = [
      { id: 'continue', label: '继续', text: '继续' },
      { id: 'plain', label: '讲人话', text: '请讲人话，简洁生动的解释一遍' },
    ]

    function ContinueButtons(props) {
      const inputActions = props.inputActions
      const draft = props.useInput(state => state.draft)

      const send = (text) => {
        // 不覆盖用户已输入的内容:草稿非空时另起一行追加。
        // setDraft 是编辑器的 discrete 更新(同步落盘),紧接着 submit
        // 读到的是新草稿,不需要等 React 重渲染。
        const current = draft.trim()
        inputActions.setDraft(current === '' ? text : `${draft}\n${text}`)
        inputActions.submit()
      }

      return react.createElement(
        'div',
        { style: { display: 'flex', alignItems: 'center', gap: 8, order: 1 } },
        ACTIONS.map(action => react.createElement(
          Button,
          {
            key: action.id,
            variant: 'outline',
            size: 'sm',
            onClick: () => { send(action.text) },
          },
          action.label,
        )),
      )
    }

    function apply(ctx) {
      // inject 等 conversation 包把 slot 声明放上账本后再注册。
      ctx.slots.inject('conversation.input.right', () => ctx.slots.register({
        name: 'conversation.input.right',
        id: 'continue-buttons',
        order: 100,
      }, ContinueButtons))
    }

    exports.apply = apply
    exports.inject = ['slots']
    exports.name = 'continue-client'
    return module.exports
  },
})
