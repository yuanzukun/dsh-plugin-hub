/**
 * dsh-continue host 半:无 host 逻辑。
 *
 * 插件的全部行为在浏览器半(src/client.js)。这一半存在只为让 profile 能挂一行
 * 插件(cordis 要求插件导出 apply),`dsh.client` 声明据此把浏览器半加载进 GUI。
 * @module dsh-continue
 */

export const name = 'dsh-continue'

/** cordis 插件入口;host 侧无事可做。 */
export function apply() {}
