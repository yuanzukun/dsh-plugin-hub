# dsh-continue

> **One-click "Continue" and "Plain talk" buttons right next to the send button in dsh.**
> In a long session, "继续" (continue) is the phrase you type the most. This plugin turns it into a button — replacing the repetitive busywork, sent with a single click.

English | [中文](README.md)

---

## What it is

**dsh-continue** is a minimal open-source plugin for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)(dsh).

Halfway through a task, the agent stalls and you type "continue". Once or twice is fine — but after a few hundred rounds you're just doing typing work for the AI. This plugin adds two quick buttons next to the send button:

![dsh-continue quick buttons](docs/screenshot.png)

| Button | Sends |
| --- | --- |
| **继续** | `继续` |
| **讲人话** | `请讲人话，简洁生动的解释一遍` |

That's the whole plugin: click to send. It never overwrites your draft (when the draft is non-empty it appends on a new line). The plugin **modifies no dsh source** — it is a single client-side line, so it keeps working across dsh upgrades.

## Install

```bash
git clone https://github.com/flg1217/dsh-continue.git
cd dsh-continue
pnpm install          # no third-party deps, basically a no-op
dsh plugin --profile web add <dsh-continue directory>
```

**Restart dsh web** after installing — the "继续" and "讲人话" buttons appear to the right of the send button.

> For local development you can also mount the repo root directly: `dsh plugin --profile web add .` in this directory.

## Compatibility & permissions

- Works with the dsh web profile (npx or source build); verified on dsh rc.8.
- **Permission scope**: the plugin is two client-side buttons only — the host half has no logic and touches no files, network, or environment variables.

## Uninstall

```bash
dsh plugin --profile web remove dsh-continue
```

Or clean up manually: remove the `dsh-continue` insert entry from the profile's `cordis.patch.yml` and its dependency line in `package.json`, then restart dsh web.

## How it works

The plugin is dual-faced — the browser half does the work, the host half stays empty:

```
┌─────────────── Host process (node half) ─────────────┐
│ src/index.js   plugin entry (empty apply, just mounts │
│                a profile line)                        │
└───────────────────────────────────────────────────────┘
┌─────────────── Browser (web half) ───────────────────┐
│ src/client.js  conversation.input.right slot         │
│                "继续" and "讲人话" buttons            │
└───────────────────────────────────────────────────────┘
```

- **Assembly**: `cordis.patch.yml` (bundle patch) inserts the plugin line; the `dsh.client` manifest in package.json loads the browser half into the GUI
- **Buttons**: mounted on the `conversation.input.right` slot (order: 100), rendered right of the send button
- **Send**: sends the button text when the draft is empty; otherwise appends on a new line without touching your draft

## Development

```bash
git clone https://github.com/flg1217/dsh-continue.git
cd dsh-continue
dsh plugin --profile web add .   # local mount; refresh after editing src/client.js
```

## License

[MIT](LICENSE)
