# -*- coding: utf-8 -*-
"""灵枢 · 信息分层处理（v1.16）

设计：先语义识别分流——简单知识查询/判断/情感走智慧之书自处理；
智慧之书无法完成的走 LLM；无法判断时把智慧之书的回答放入上下文给 LLM 续答。

路由判定（route）：
  self         智慧之书已处理（高置信）
  llm          智慧之书没把握 → LLM 续答（智慧之书回答作上下文）
  self_fallback LLM 不可用 → 回退智慧之书回答

LLM 接入：DeepSeek API（DEEPSEEK_API_KEY 环境变量），openai 客户端。
"""
import os
import re as _re

# 知识检索高置信阈值（实测：饿 0.72/串联 0.64/1+1 0.64/熵 0.38 均过；
# 低置信噪声远低于 0.30）
SELF_CONFIDENCE = 0.30

# 诚实边界硬编码词（已知边界快路径，v1.16）：
# 与智慧之书「不知道就说不知道」原则冲突的敏感主张词。
# 注意：这是词表不是识别卡动态匹配——137 卡 counters 克制条款格式不统一
# （协议层卡有「克制『X』」，学科卡多是其他格式），动态匹配见 _counters_conflict。
HONEST_BOUNDARY_WORDS = ["外星人", "超光速", "能保证", "你懂吗", "长什么样"]

# counters 克制条款缓存（name → counters 全文）
_COUNTERS_CACHE = {}
# 全卡名缓存（句子中提到的卡名也参与 counters 检测）
_CARD_NAMES_CACHE = None


def _bigram_set(text):
    """二元组集合（去非中文/字母数字）。"""
    t = _re.sub(r"[^\u4e00-\u9fffA-Za-z0-9]", "", text or "")
    return {t[i:i + 2] for i in range(len(t) - 1)}


def _card_counters(dex, name):
    """取知识卡 response.counters 全文（克制条款，格式不统一：
    协议层卡有「克制『X』」/「以X替代Y的越界主张」/「把X当作Y的越界主张」…）。"""
    if name in _COUNTERS_CACHE:
        return _COUNTERS_CACHE[name]
    full = ""
    try:
        from aeis.core import MemoryLayer as _ML
        for n in dex.store.query_nodes(layer=_ML.KNOWLEDGE, limit=500):
            sa = n.state_attributes
            if sa.get("name") != name:
                continue
            full = (sa.get("response") or {}).get("counters", "") or ""
            break
    except Exception:
        pass
    _COUNTERS_CACHE[name] = full
    return full


def _counters_conflict(dex, sentence, card_names):
    """动态克制条款冲突（诚实边界 2.0）：句子 vs counters 全文。
    协议层卡 counters 是「越界主张」描述（替代/当作/克制…），
    句子与 counters 二元组交集 ≥4 视为触发克制。
    候选卡 = 检索命中的卡 ∪ 句子中直接提到的知识卡名（「信息论就是…」
    检索可能命中语言学而非信息论，但句子含「信息论」→ 仍查信息论卡）。
    """
    global _CARD_NAMES_CACHE
    qb = _bigram_set(sentence)
    names = set(card_names)
    # 句子中直接提到的卡名
    if _CARD_NAMES_CACHE is None:
        try:
            from aeis.core import MemoryLayer as _ML
            _CARD_NAMES_CACHE = [n.state_attributes.get("name")
                                 for n in dex.store.query_nodes(
                                     layer=_ML.KNOWLEDGE, limit=500)
                                 if n.state_attributes.get("name")]
        except Exception:
            _CARD_NAMES_CACHE = []
    for n in _CARD_NAMES_CACHE:
        if n and n in sentence:
            names.add(n)
    for name in names:
        full = _card_counters(dex, name)
        if not full:
            continue
        inter = len(qb & _bigram_set(full))
        if inter >= 4:
            return full[:40]
    return None

# LLM 配置已移除（纯白箱化）：无 DeepSeek 接入、无 openai 客户端、无续答层


def _env_user(name):
    """从 Windows 环境变量注册表读——当前进程环境可能未加载
    （dsh/MCP 启动早于变量设置）。先 User 再 Machine（HKLM）。
    """
    try:
        import winreg
        for root, path in ((winreg.HKEY_CURRENT_USER, "Environment"),
                           (winreg.HKEY_LOCAL_MACHINE,
                            r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment")):
            try:
                with winreg.OpenKey(root, path) as k:
                    v, _ = winreg.QueryValueEx(k, name)
                    if v:
                        return v
            except Exception:
                continue
    except Exception:
        pass
    return ""


# _get_llm_client：DeepSeek 客户端已移除（纯白箱化）


def _decide_route(result):
    """路由判定（纯白箱）：一律 self——无 LLM 续答层，智慧之书即最终回答。

    智慧之书自带的诚实边界（无命中/低置信 → 「不确定就说出来」）
    保证不硬答；路由字段保留供调用方消费。
    """
    return "self"


# llm_complete：LLM 续答已移除（纯白箱化）


def _claim_anchor(dex, sentence):
    """单主张图谱锚定：一句 → (status, anchor, card_names) 或 (unverified, None, [])。"""
    hits = []
    try:
        import semantic_translate as _st
        hits = _st.graph_retrieve(dex, sentence, limit=2)
    except Exception:
        hits = []
    top = hits[0] if hits else None
    card_names = [h.get("name") for h in hits if h.get("name")]
    if not top:
        return "unverified", None, card_names
    score = top.get("score") or 0
    matched = top.get("matched") or []
    strong = [m for m in matched if m not in ("语义", "字面")]
    if score >= 0.30 and strong:
        return ("anchored",
                {"name": top.get("name"), "score": round(score, 3),
                 "domain": top.get("domain"), "edu_level": top.get("edu_level")},
                card_names)
    return "unverified", None, card_names


def whitebox_check(dex, reply, question=None):
    """白箱后验校验（纯白箱）：回答 → 主张级图谱锚定 + 诚实边界冲突。

    v1.16 升级为主张级（Kimi 评审：整段打分会被词面包裹骗过——「量子纠缠可超光速」
    混在物理词面里 D_norm 整体通过；逐主张锚定才能区分「正确句✓ / 越界句✗」）：
      - 按句切分回答 → 每句 graph_retrieve 锚定
      - anchored：该句与图谱一致，附卡可溯源
      - unverified：该句超出图谱 → 「图谱外补充」
      - warning：该句含诚实边界词（超光速/外星人/能保证…）→ 「⚠️ 条件偏差警告」
    回答级汇总：全 anchored → anchored；部分 → partial；全无 → unverified。
    用 graph_retrieve 而非 dex_auto_verify——后者做知识归属（K 算哪个学科），
    前者做主张锚定（回答与图谱是否一致）。实测：错误主张「超光速可通信」
    在图谱仅 0.009 锚定（词面重叠骗不过语义层）。
    """
    import re as _re
    # 1. 主张级：按句切分（中文句号/感叹/问号/分号/换行/项目符号）
    raw_sents = _re.split(r"[。！？；\n•\-]+", reply or "")
    claims = []
    for s in raw_sents:
        s = s.strip().strip("#* ")
        if len(s) < 4:
            continue
        status, anchor, card_names = _claim_anchor(dex, s)
        warn = None
        # 硬编码边界词（已知边界快路径）
        if any(w in s for w in HONEST_BOUNDARY_WORDS):
            warn = "诚实边界词"
        # 动态克制条款（协议层卡 counters · 诚实边界 2.0）
        if warn is None:
            cc = _counters_conflict(dex, s, card_names)
            if cc:
                warn = f"触发克制条款：{cc[:24]}"
        claims.append({"sentence": s[:50], "status": status,
                       "anchor": anchor, "warning": warn})
    # 2. 回答级汇总
    if not claims:
        return {"status": "unverified", "claims": [], "anchor": None,
                "warning": None}
    anchored_n = sum(1 for c in claims if c["status"] == "anchored")
    warned = [c for c in claims if c["warning"]]
    if anchored_n == len(claims) and not warned:
        status = "anchored"
    elif anchored_n > 0:
        status = "partial"
    else:
        status = "unverified"
    warning = None
    if warned:
        warning = ("回答含诚实边界词（超光速/外星人/能保证…），与智慧之书"
                   "『不知道就说不知道』原则可能冲突——请核对越界主张")
    anchor = next((c["anchor"] for c in claims if c["anchor"]), None)
    # 元标注（回应 Kimi「幻觉传染」问题）：标注是检索结果，不是认知声明。
    # 防止下游系统/人类把「图谱外」误读为「系统知道自己不知道」——
    # 阈值是设计者参数，宁缺毋滥是策略选择，不是系统对自身局限性的感知。
    meta_note = ("此标注为图谱检索结果（阈值+词表+克制条款匹配），非认知声明："
                 "anchored=与图谱一致，unverified=图谱未覆盖，warning=触发边界词/克制条款；"
                 "『图谱外』≠系统知道自己的盲区，只是检索未命中。")
    return {"status": status, "claims": claims, "anchor": anchor,
            "warning": warning, "meta_note": meta_note}


def route_reply(question, wisdom_result, session_id="default", dex=None):
    """分层入口（纯白箱）：智慧之书结果 → 回答 + 白箱校验。

    无 LLM 续答层——智慧之书即最终回答；白箱校验（主张级图谱锚定 +
    诚实边界冲突）覆盖所有回答，结果写入 whitebox_verify 字段。
    """
    result = dict(wisdom_result)
    result["route"] = "self"
    result["wisdom_reply"] = result.get("reply", "")
    # 白箱校验：回答 → 主张级图谱锚定 + 诚实边界冲突
    if dex is not None and result.get("reply"):
        try:
            verify = whitebox_check(dex, result["reply"], question)
            result["whitebox_verify"] = verify
            # 回答尾部标注（白箱给回答戴条件论缰绳 · 主张级）
            marks = []
            if verify["status"] == "anchored" and verify["anchor"]:
                a = verify["anchor"]
                marks.append(f"✓ 图谱锚定：{a['name']}（{a.get('edu_level') or '通用'}条件）")
            elif verify["status"] == "partial":
                a = verify["anchor"]
                part = [c["sentence"][:14] for c in verify["claims"]
                        if c["status"] == "anchored"][:2]
                marks.append("✓ 部分图谱锚定：" +
                             (f"{a['name']}（{'、'.join(part)}…）"
                              if a else "多句命中"))
            if verify["warning"]:
                marks.append("⚠️ 条件偏差警告：含诚实边界词，越界主张请谨慎采信")
            if not marks:
                marks.append("图谱外补充：未在图谱锚定，基于已有知识")
            result["reply"] += "\n（" + "；".join(marks) + "）"
        except Exception:
            pass
    return result
