import assert from "node:assert/strict";
import { test } from "node:test";
import {
  advertiseImage,
  advertiseImageIfNeeded,
  collectImageRefs,
  modelAcceptsImage,
  rewriteMessages,
} from "../dist/rewrite.js";
import { chatCompletionsUrl, resolveVisionConfig, visionReady } from "../dist/config.js";

test("advertiseImage adds image without dropping text", () => {
  const next = advertiseImage({ inputModalities: ["text"] as const });
  assert.deepEqual(next.inputModalities, ["text", "image"]);
});

test("native vision models stay untouched", () => {
  const vision = { inputModalities: ["text", "image"] as const };
  assert.equal(modelAcceptsImage(vision), true);
  assert.equal(advertiseImageIfNeeded(vision, true), vision);
});

test("text-only models are advertised only when sidecar is ready", () => {
  const text = { inputModalities: ["text"] as const };
  assert.equal(modelAcceptsImage(text), false);
  assert.equal(advertiseImageIfNeeded(text, false), text);
  assert.deepEqual(advertiseImageIfNeeded(text, true).inputModalities, [
    "text",
    "image",
  ]);
});

test("rewriteMessages replaces image blocks with sidecar text", () => {
  const messages = [
    {
      role: "user",
      content: [
        { type: "text", text: "what is this" },
        { type: "image", attachment: { attachmentId: "att-1", name: "err.png" } },
      ],
    },
  ];
  const out = rewriteMessages(messages, new Map([["att-1", "[Image (err.png)]\nred button"]]));
  assert.deepEqual(out[0].content, [
    { type: "text", text: "what is this" },
    { type: "text", text: "[Image (err.png)]\nred button" },
  ]);
});

test("collectImageRefs walks tool results and de-dupes", () => {
  const refs = collectImageRefs([
    {
      role: "tool",
      content: [
        {
          type: "tool-result",
          content: [
            { type: "image", attachment: { attachmentId: "a" } },
            { type: "image", attachment: { attachmentId: "a" } },
          ],
        },
      ],
    },
  ]);
  assert.equal(refs.length, 1);
  assert.equal(refs[0].attachmentId, "a");
});

test("vision URL and readiness", () => {
  assert.equal(
    chatCompletionsUrl("https://example/v1"),
    "https://example/v1/chat/completions",
  );
  assert.equal(visionReady(resolveVisionConfig({})), false);
});
