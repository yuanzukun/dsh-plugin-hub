# 宣发稿

一句定位：**官方贴图会被拒。这个插件让纯文本主模型先看图再答。不是视觉工具箱。**

仓库：`https://github.com/shinjiyu/dsh-plugin-multimodal`  
安装：`dsh plugin --profile web add github:shinjiyu/dsh-plugin-multimodal`  
对着：[Discussions #588](https://github.com/deepseek-ai/deepseek-harness/discussions/588)  
已发：[#588 回复](https://github.com/deepseek-ai/deepseek-harness/discussions/588#discussioncomment-18025308) · [Show and tell #1709](https://github.com/deepseek-ai/deepseek-harness/discussions/1709)

发之前：重启过 dsh、sidecar 是真视觉模型、自己贴过一张图。

---

## 1. GitHub Discussions #588 回复

标题不用新开帖，回 #588。

```
This is the GUI admission gap in #588: text-only main model + a separate vision helper.

dsh-plugin-multimodal sits in the adapter layer, not as a vision_* toolbox.

- If the routed model already accepts images, attachments pass through unchanged.
- If it is text-only, the plugin advertises image input so the Web UI accepts the paste, then a vision sidecar describes the image and the main model only sees text.
- see_image covers screenshots already on disk.

It does not replace Anionex/dsh-vision-toolkit. That package is tools the agent must call. This one is so paste is not rejected.

Install:

    dsh plugin --profile web add github:shinjiyu/dsh-plugin-multimodal

Then restart dsh. Set DSH_VISION_BASE_URL / DSH_VISION_API_KEY / DSH_VISION_MODEL to a real vision model (not deepseek-v4-flash / GLM-5.2-FP8).

Repo: https://github.com/shinjiyu/dsh-plugin-multimodal
```

---

## 2. V2EX（短帖）

标题：`DeepSeek Harness 官方模型贴图会被拒，做了个 sidecar 插件`

```
官方线路 inputModalities 只有 text，Web 贴图直接 MODEL_DOES_NOT_SUPPORT_IMAGES。
Discussions #588 要的是：纯文本主模型 + 旁边一个视觉模型。

这个插件补的是「贴图不被拒」，不是 vision_* 工具箱（那个 Anionex 已经做了）。

- 主模型能看图：原样转发
- 主模型是纯文本：sidecar 转成字再发给主模型
- 磁盘截图用 see_image

安装：
dsh plugin --profile web add github:shinjiyu/dsh-plugin-multimodal
重启 dsh。DSH_VISION_MODEL 必须是真能看图的，别填 GLM-5.2-FP8。

仓库：https://github.com/shinjiyu/dsh-plugin-multimodal
```

---

## 3. 微信群首条（deepseek harness 交流群）

码在 `docs/community/wechat-group.png`，本张到 **2026-08-22**。群里直接发下面这段，需要图时把码一起贴。

```
官方 DeepSeek 贴图会被拒。
这个插件让图先被收下来，旁边的视觉模型写成字，再交给主模型。
不是工具箱，是贴图准入。

安装：
dsh plugin --profile web add github:shinjiyu/dsh-plugin-multimodal
重启 dsh web。
配 DSH_VISION_BASE_URL / KEY / MODEL（必须真能看图）。

进群条件：跑通过「贴一张报错图，问红字说了什么」，或带着仍被拒的截图。
仓库：https://github.com/shinjiyu/dsh-plugin-multimodal
```

---

## 4. 朋友圈 / 公众号 120 字

```
DeepSeek Harness 官方模型不能贴图，GUI 直接拒。
做了个 dsh 插件：纯文本主模型也能把图收进来，旁边的视觉模型先看，再把字交给主模型。真能看图的模型不误伤。
不是视觉工具箱。
github.com/shinjiyu/dsh-plugin-multimodal
微信群：deepseek harness 交流群（码见仓库 README，8 月 22 日前有效）
```

---

## 不要说

- 「我们做了多模态 / 视觉工具箱」
- 「已经自动自进化」（那是另一件货）
- 「比 Claude 更能看图」
- sidecar 用了哪家 key
