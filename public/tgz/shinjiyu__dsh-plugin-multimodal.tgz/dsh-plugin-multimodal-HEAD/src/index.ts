import { resolveVisionConfig, visionReady, type PluginConfig } from "./config.js";
import {
  advertiseImageIfNeeded,
  collectImageRefs,
  messagesHaveImage,
  modelAcceptsImage,
  rewriteMessages,
  type ChatMessage,
  type ImageRef,
} from "./rewrite.js";
import { describeImage, wrapDescription } from "./vision.js";

export const name = "dsh-plugin-multimodal";
export const inject = ["llm", "tools", "attachments", "systemPrompt"];

type Json = Record<string, unknown>;

interface AttachmentStore {
  readImage(
    ref: ImageRef,
    signal?: AbortSignal,
  ): Promise<{ data: Uint8Array; ref?: ImageRef }>;
}

interface LlmService {
  resolveModelInfo: (...args: unknown[]) => Promise<Json>;
  listModels: (provider: string) => Promise<Json[]>;
  streamWithRegistration: (
    options: Json,
    prepared?: unknown,
  ) => AsyncIterable<unknown>;
}

interface DshContext {
  llm: LlmService;
  attachments: AttachmentStore;
  tools: {
    register(definition: Json): unknown;
  };
  systemPrompt?: {
    section(section: { name: string; order?: number; text: string }): unknown;
  };
  logger?: {
    warn?(...args: unknown[]): void;
    info?(...args: unknown[]): void;
  };
  effect?(fn: () => () => void): unknown;
}

const cache = new Map<string, string>();

async function describeRef(
  ctx: DshContext,
  config: ReturnType<typeof resolveVisionConfig>,
  ref: ImageRef,
  question: string,
  signal?: AbortSignal,
): Promise<string> {
  const key = `${ref.attachmentId}:${question}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const stored = await ctx.attachments.readImage(ref, signal);
  const body = await describeImage(
    config,
    {
      ref,
      data: stored.data,
      mediaType: stored.ref?.mediaType || ref.mediaType,
    },
    question,
    signal,
  );
  const text = wrapDescription(ref, body);
  cache.set(key, text);
  return text;
}

async function rewriteOptions(
  ctx: DshContext,
  config: ReturnType<typeof resolveVisionConfig>,
  options: Json,
): Promise<Json> {
  const messages = (options.messages as ChatMessage[] | undefined) ?? [];
  if (!messagesHaveImage(messages)) return options;
  const descriptions = new Map<string, string>();
  for (const ref of collectImageRefs(messages)) {
    try {
      descriptions.set(
        ref.attachmentId,
        await describeRef(ctx, config, ref, config.prompt, options.signal as AbortSignal | undefined),
      );
    } catch (error) {
      descriptions.set(
        ref.attachmentId,
        wrapDescription(
          ref,
          `vision sidecar failed: ${error instanceof Error ? error.message : error}`,
        ),
      );
    }
  }
  return { ...options, messages: rewriteMessages(messages, descriptions) };
}

export function apply(ctx: DshContext, raw: PluginConfig = {}): void {
  const config = resolveVisionConfig(raw);
  const llm = ctx.llm;
  const origResolve = llm.resolveModelInfo.bind(llm);
  const origList = llm.listModels.bind(llm);
  const origStream = llm.streamWithRegistration.bind(llm);

  const ready = visionReady(config);
  llm.resolveModelInfo = async (...args) =>
    advertiseImageIfNeeded(await origResolve(...args), ready);
  llm.listModels = async (provider) =>
    (await origList(provider)).map((model) => advertiseImageIfNeeded(model, ready));
  llm.streamWithRegistration = (options, prepared) => {
    const stream = (async function* () {
      const native = await origResolve(options.provider, options.model, options.signal);
      const next =
        modelAcceptsImage(native) || !messagesHaveImage((options.messages as ChatMessage[]) ?? [])
          ? options
          : await rewriteOptions(ctx, config, options);
      yield* origStream(next, prepared);
    })();
    return stream;
  };

  ctx.effect?.(() => () => {
    llm.resolveModelInfo = origResolve;
    llm.listModels = origList;
    llm.streamWithRegistration = origStream;
  });

  ctx.systemPrompt?.section({
    name: "multimodal-sidecar",
    order: 40,
    text: [
      "If the selected model already accepts images, attachments go to that model unchanged.",
      "If it is text-only, a vision sidecar describes each image as text first.",
      "You can also call see_image on a workspace file path.",
      ready
        ? `Sidecar model: ${config.model}.`
        : "Sidecar is not configured. Set DSH_VISION_BASE_URL, DSH_VISION_API_KEY, and DSH_VISION_MODEL.",
    ].join(" "),
  });

  ctx.tools.register({
    name: "see_image",
    description:
      "Describe an image file for the text-only main model. Use when the user points at a screenshot or picture on disk.",
    parameters: {
      type: "object",
      additionalProperties: false,
      properties: {
        path: { type: "string", description: "Absolute or workspace-relative image path" },
        question: {
          type: "string",
          description: "What to look for. Defaults to a full description plus OCR.",
        },
      },
      required: ["path"],
    },
    output: {
      schema: { type: "object", additionalProperties: true },
      render(_args: unknown, value: unknown) {
        const text =
          value && typeof value === "object" && "text" in value
            ? String((value as { text?: string }).text || "")
            : JSON.stringify(value);
        return [{ type: "text", text }];
      },
    },
    async execute(args: unknown, exec: { signal?: AbortSignal }) {
      const { readFile } = await import("node:fs/promises");
      const path = await import("node:path");
      const asked = (args ?? {}) as { path?: string; question?: string };
      if (!asked.path) throw new Error("path is required");
      const abs = path.resolve(asked.path);
      const data = await readFile(abs);
      const ext = path.extname(abs).toLowerCase();
      const mediaType =
        ext === ".jpg" || ext === ".jpeg"
          ? "image/jpeg"
          : ext === ".webp"
            ? "image/webp"
            : ext === ".gif"
              ? "image/gif"
              : "image/png";
      const text = await describeImage(
        config,
        {
          ref: { attachmentId: abs, mediaType, name: path.basename(abs) },
          data,
          mediaType,
        },
        asked.question || config.prompt,
        exec?.signal,
      );
      return { ok: true, path: abs, text };
    },
  });
}
