export interface VisionConfig {
  baseURL: string;
  apiKey: string;
  model: string;
  prompt: string;
  maxTokens: number;
}

export interface PluginConfig {
  baseURL?: string;
  apiKeyEnv?: string;
  model?: string;
  prompt?: string;
  maxTokens?: number;
}

const DEFAULT_PROMPT =
  "Describe this image for a text-only coding agent. Transcribe visible text exactly. Name UI labels, errors, file paths, and layout. Be concrete. Do not guess unseen details.";

export function resolveVisionConfig(raw: PluginConfig = {}): VisionConfig {
  const baseURL = String(
    raw.baseURL ||
      process.env.DSH_VISION_BASE_URL ||
      process.env.OPENAI_BASE_URL ||
      "",
  ).replace(/\/+$/, "");
  const apiKeyEnv = raw.apiKeyEnv || "DSH_VISION_API_KEY";
  const apiKey = String(
    process.env[apiKeyEnv] || process.env.OPENAI_API_KEY || "",
  ).trim();
  return {
    baseURL,
    apiKey,
    model: String(
      raw.model || process.env.DSH_VISION_MODEL || "glm-4.5v",
    ).trim(),
    prompt: String(raw.prompt || process.env.DSH_VISION_PROMPT || DEFAULT_PROMPT),
    maxTokens: Number(raw.maxTokens || process.env.DSH_VISION_MAX_TOKENS || 800),
  };
}

export function visionReady(config: VisionConfig): boolean {
  return Boolean(config.baseURL && config.apiKey && config.model);
}

export function chatCompletionsUrl(baseURL: string): string {
  if (/\/chat\/completions$/i.test(baseURL)) return baseURL;
  if (/\/v1$/i.test(baseURL)) return `${baseURL}/chat/completions`;
  return `${baseURL}/v1/chat/completions`;
}
