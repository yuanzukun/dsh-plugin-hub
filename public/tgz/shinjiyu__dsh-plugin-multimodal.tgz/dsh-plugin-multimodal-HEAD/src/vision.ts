import { chatCompletionsUrl, type VisionConfig, visionReady } from "./config.js";
import type { ImageRef } from "./rewrite.js";

export interface StoredImage {
  ref: ImageRef;
  data: Uint8Array;
  mediaType?: string;
}

export async function describeImage(
  config: VisionConfig,
  image: StoredImage,
  question: string,
  signal?: AbortSignal,
): Promise<string> {
  if (!visionReady(config)) {
    return "[vision sidecar not configured. Set DSH_VISION_BASE_URL, DSH_VISION_API_KEY, DSH_VISION_MODEL to an OpenAI-compatible vision endpoint.]";
  }
  const mediaType = image.mediaType || image.ref.mediaType || "image/png";
  const b64 = Buffer.from(image.data).toString("base64");
  const res = await fetch(chatCompletionsUrl(config.baseURL), {
    method: "POST",
    signal,
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${config.apiKey}`,
    },
    body: JSON.stringify({
      model: config.model,
      max_tokens: config.maxTokens,
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: question || config.prompt },
            {
              type: "image_url",
              image_url: { url: `data:${mediaType};base64,${b64}` },
            },
          ],
        },
      ],
    }),
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`vision ${res.status}: ${text.slice(0, 400)}`);
  }
  const json = JSON.parse(text) as {
    choices?: Array<{ message?: { content?: unknown } }>;
  };
  const content = json.choices?.[0]?.message?.content;
  if (typeof content === "string" && content.trim()) return content.trim();
  if (Array.isArray(content)) {
    const joined = content
      .map((part) =>
        part && typeof part === "object" && "text" in part
          ? String((part as { text?: string }).text || "")
          : "",
      )
      .join("\n")
      .trim();
    if (joined) return joined;
  }
  throw new Error("vision endpoint returned empty content");
}

export function wrapDescription(ref: ImageRef, body: string): string {
  const name = ref.name ? ` (${ref.name})` : "";
  const size =
    ref.width && ref.height ? ` ${ref.width}x${ref.height}` : "";
  return `[Image${name}${size}]\n${body}`;
}
