export interface ImageRef {
  attachmentId: string;
  mediaType?: string;
  name?: string;
  width?: number;
  height?: number;
}

export interface ContentBlock {
  type: string;
  text?: string;
  attachment?: ImageRef;
  content?: ContentBlock[];
}

export interface ChatMessage {
  role?: string;
  content?: ContentBlock[] | string;
}

export function contentHasImage(blocks: ContentBlock[] | string | undefined): boolean {
  if (!blocks || typeof blocks === "string") return false;
  for (const block of blocks) {
    if (block.type === "image") return true;
    if (block.type === "tool-result" && contentHasImage(block.content)) return true;
  }
  return false;
}

export function messagesHaveImage(messages: ChatMessage[]): boolean {
  return messages.some((message) => contentHasImage(message.content));
}

export function modelAcceptsImage(info: {
  inputModalities?: readonly string[];
}): boolean {
  return Boolean(info.inputModalities?.includes("image"));
}

/** Only lie to the GUI when the real adapter is text-only. */
export function advertiseImageIfNeeded<T extends { inputModalities?: readonly string[] }>(
  info: T,
  sidecarReady: boolean,
): T {
  if (modelAcceptsImage(info) || !sidecarReady) return info;
  return advertiseImage(info);
}

export function advertiseImage<T extends { inputModalities?: readonly string[] }>(
  info: T,
): T {
  const current = info.inputModalities ? [...info.inputModalities] : ["text"];
  if (!current.includes("text")) current.unshift("text");
  if (!current.includes("image")) current.push("image");
  return { ...info, inputModalities: current };
}

export function replaceImages(
  blocks: ContentBlock[],
  descriptions: Map<string, string>,
): ContentBlock[] {
  const out: ContentBlock[] = [];
  for (const block of blocks) {
    if (block.type === "image") {
      const id = block.attachment?.attachmentId || "unknown";
      const text = descriptions.get(id) || `[image ${id}: description unavailable]`;
      out.push({ type: "text", text });
      continue;
    }
    if (block.type === "tool-result" && Array.isArray(block.content)) {
      out.push({ ...block, content: replaceImages(block.content, descriptions) });
      continue;
    }
    out.push(block);
  }
  return out;
}

export function collectImageRefs(
  messages: ChatMessage[],
): ImageRef[] {
  const seen = new Set<string>();
  const refs: ImageRef[] = [];
  const walk = (blocks: ContentBlock[] | string | undefined) => {
    if (!blocks || typeof blocks === "string") return;
    for (const block of blocks) {
      if (block.type === "image" && block.attachment?.attachmentId) {
        const id = block.attachment.attachmentId;
        if (seen.has(id)) continue;
        seen.add(id);
        refs.push(block.attachment);
      }
      if (block.type === "tool-result") walk(block.content);
    }
  };
  for (const message of messages) walk(message.content);
  return refs;
}

export function rewriteMessages(
  messages: ChatMessage[],
  descriptions: Map<string, string>,
): ChatMessage[] {
  return messages.map((message) => {
    if (!contentHasImage(message.content)) return message;
    const content = replaceImages(message.content as ContentBlock[], descriptions);
    return { ...message, content };
  });
}
