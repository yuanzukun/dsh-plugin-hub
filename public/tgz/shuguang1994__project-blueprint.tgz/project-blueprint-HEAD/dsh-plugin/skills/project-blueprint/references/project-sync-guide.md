# Agent 文档同步操作指南

> 版本: v2.0 | 更新: 2026-10-14
> Skill `project-blueprint` Step 7 参考。Agent 如何在项目开发过程中持续维护文档。

---

## 何时同步

Agent 在完成以下操作后，应检查并同步相关文档：

| 触发场景 | 检查方法 | 同步动作 | 目标文件 |
|---------|---------|---------|---------|
| 新增模块 | `ls src/modules/` 对比 AGENTS.md 模块表 | 追加行：`\| new_module \| dir/ \| 职责 \|` | AGENTS.md 模块速查表 |
| 移除/重命名模块 | 同上对比 | 更新/删除对应行 | AGENTS.md |
| 新增 npm/pip/go 依赖 | 对比 package.json dependencies vs AGENTS.md 技术栈行 | 追加新工具到技术栈行 | AGENTS.md 项目身份 |
| 新增架构模式 | 发现使用了新的事件/策略/管道模式 | 追加到关键架构决策表 | AGENTS.md |
| 发现新代码规范 | 在 review 中反复出现同样的纠正 | 追加到强制规范章节 | AGENTS.md |
| 修复典型 Bug | Bug 有通用参考价值 | 写入根因+方案+预防 | docs/B/B-04-BUG知识库.md |
| 做出架构决策 | 涉及技术选型/模块拆分/性能优化 | 写入决策+理由+日期 | docs/C/C-03-项目长期记忆.md |
| 文档膨胀/模块超职责 | Service 承担多个职责域 | 按架构原则拆分：高内聚低耦合 / 单一职责 | 更新模块表和 docs 引用 |
| CI 流程变更 | `.github/workflows/ci.yml` 有变更 | 更新 docs 中 CI 描述 | docs/B/B-02-部署指南.md |
| 新增/删除测试框架 | package.json devDependencies 测试库变更 | 更新测试命令 | AGENTS.md Commands |
| 新增/移除 MCP 工具 | 检查 `docs/B/B-05-MCP工具清单.md` 是否存在 | 追加/移除工具条目（含安装命令），同步技术栈行 | docs/B/B-05-MCP工具清单.md + AGENTS.md |
| **修复了一个缺陷** | 判定该缺陷是否可机检（四问：可机检？零新依赖？真发生过？误报可控？） | 可机检 → 写检查脚本 + `scripts/gates.json` 追加一条；不可机检 → 标注 `[无门禁]` 并归入 BUG 知识库模式 | `scripts/gates.json` + `docs/B/B-04-BUG知识库.md` |
| **发现 AI 重复被纠正 / 新增了一条阻断级红线** | 该规则是否有对应可执行检查 | 有 → 登记门禁；无 → 补检查或标注 `[无门禁]` + 写明原因 | `scripts/gates.json` + `AGENTS.md` 门禁清单与装配 |
| **规范漂移（spec 与代码不一致）** | 漂移门报出差异（`references/drift-check.mjs` 参考实现，对应门禁 `spec-drift`） | 按差异类型回写：依赖清单变化 → 更新 AGENTS.md 技术栈行；源码目录变化 → 更新模块速查表；导出物 / spec 与代码不一致 → 同步导出物或更新对应 spec；收尾复跑 `scripts/verify.*` 并留证（命令 + 实际输出） | `AGENTS.md` + `.trae/specs/<change-id>/` + `scripts/gates.json` |

---

## 同步原则

- **主动而非被动**：完成操作后主动检查，不要等用户提醒
- **增量而非覆盖**：追加新内容，保留历史（除非明确过时）
- **精简而非膨胀**：每个更新控制在 1-3 行，避免文档膨胀
- **先确认再修改**：如果变更影响较大（如删除模块），先告知用户再更新
- **门禁与规范同步**：新增/修改阻断级红线时，必须同步 `scripts/gates.json`，否则宪法自校验会报 error

---

## 门禁生长登记流程

> 门禁从缺陷/红线中"生长"出来，而非一次性设计。每次触发走完 6 步：

```
① 触发  修完一个缺陷 / 发现 AI 重复被纠正 / 新增了一条阻断级红线
   ↓
② 判定  四问（缺一不进）：可机检？ 零新依赖（只用项目已装工具）？ 真发生过或有明确证据？ 误报率可控？
   ↓ 可机检 → 建门禁        ↓ 不可机检 → 只写规范 + 标 [无门禁] + 归入 BUG 知识库模式
③ 生成  取配方：跨语言门禁配方表 → 组件 Gate 段 → 联网搜索（三层递进，与组件分类同机制）
   ↓
④ 注册  ① 写具体检查（scripts/checks/<id>.*）  ② 往 gates.json 追加一条（含 source / level / stage）
   ↓
⑤ 验证  负向验证：故意制造一次违规 → 确认门禁能拦住（拦不住则不得登记为 blocking）
   ↓
⑥ 登记  BUG 知识库 新增/归类模式 + docs/B/B-06 记录 + CHANGELOG（如发版）
```

**现实预期**：真实工程中约 1/4 的缺陷模式最终会固化为门禁（其余多不可机检或误报率高）——**"不是每个坑都要门禁"**。

---

## BUG 知识库升级要点

`docs/B/B-04-BUG知识库.md` 需具备以下 4 个要素（**schema 唯一源 = `references/docs-skeleton.md` 的 B-04 条目定义**；条目内部结构模板见 `references/ai-work-protocol.md` 第六章）：

1. **编号唯一**：采用 `## BUG-<NNN> | <标题>` 形式（三位补零），编号不重复、不复用；新增前先查是否已有条目可归类
2. **症状速查表**：以表格形式按「现象」而非「技术原因」索引，列为 `关键词（用户/开发者可观察到的现象） | 条目`，例：`下拉框空的、Select 无选项 | → BUG-003`
3. **六段式条目**：症状 / 根因（含 `文件:行号`）/ ❌ 错误写法 / ✅ 正确写法 / **预防措施（必须绑定门禁：写明对应检查命令或脚本路径）** / 实例（文件链接 + 日期），末尾附「是否规范缺失 / 规范反哺」
4. **是否新增条目的判定**：现有条目能覆盖 → 归入并补实例；不能覆盖 → 新增编号 + 评估是否需要补门禁

> ⚠️ **不得改用其它写法**（如 `### 模式 XX：…` 或 `§2.NN 模式 XX`）：`references/eval-baseline.md` 的「缺陷 → 门禁转化率」分母按 `## BUG-` 标题计数，换写法会让分母归零、指标不可复现。

---

## 同步示例

### 示例 1: 新增 payment 模块

```
Agent 完成了 src/modules/payment/ 的创建
    ↓
读取 AGENTS.md 模块速查表 → 发现无 payment 行
    ↓
追加: | payment | payment/ | 支付处理：微信/支付宝集成 |
    ↓
输出: "已将 payment 模块添加到 AGENTS.md 模块速查表"
```

### 示例 2: 修复了 coupon 超发 Bug

```
Agent 修复了 coupon.claim 的悲观锁超发问题
    ↓
判断：此 Bug 有通用参考价值（事务+锁模式）
    ↓
追加到 docs/B/B-04-BUG知识库.md:
  ## coupon.claim 超发
  **根因**: claim 未加悲观锁，并发请求同时通过库存校验
  **修复**: 添加 pessimistic_write 锁
  **模式**: 库存扣减类操作一律加悲观锁
```

### 示例 3: 引入 Redis 依赖

```
Agent 在 package.json 中新增了 ioredis 依赖
    ↓
检查 AGENTS.md 技术栈行 → 无 Redis
    ↓
更新: 技术栈: NestJS + TypeORM + MySQL + Redis + ...
```

### 示例 4: 规范漂移修复

```
漂移门报出差异（references/drift-check.mjs 参考实现，对应门禁 spec-drift）
    ↓ 判定差异类型
依赖清单变化（package.json / go.mod 新增依赖）
    → 更新 AGENTS.md 技术栈行
源码目录变化（新增 / 重命名模块目录）
    → 更新 AGENTS.md 模块速查表
导出物 / spec 与代码不一致
    → 同步导出物（契约唯一源随代码一同提交）或更新对应 spec（.trae/specs/<change-id>/）
    ↓ 收尾
复跑 scripts/verify.* → blocking 全绿后留证（命令 + 实际输出）
```
