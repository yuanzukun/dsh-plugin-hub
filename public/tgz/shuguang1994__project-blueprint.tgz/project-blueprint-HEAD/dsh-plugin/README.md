# Project Blueprint — DSH 插件包 (DSH Plugin)

[English](../README.md) | 中文

将 Project Blueprint 技能包（`SKILL.md` + `references/`）打包为 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（缩写 `dsh`）插件。DSH 采用"一切皆插件"架构，本插件以自定义 skill 根目录的形式把技能注册进 `ctx.skills`，由官方 `@deepseek-ai/dsh-skill-filesystem` 提供方加载 —— **零构建、零依赖、纯 Markdown 技能内容**。

## 安装

需要 DSH `0.1.0-rc.x` 及以上（已 `npx @deepseek-ai/dsh web` 启动过 Web UI）。已实测兼容至 `0.1.1-rc.2`（2026-08-22，见下方「兼容性」）。

```bash
# 方式一：GitHub 仓库 tag（推荐，固定版本，任何机器可用）
dsh plugin --profile web add 'github:shuguang1994/project-blueprint#v2.0.0'
# 也可不指定 tag 安装最新 main（v1.6.1 起根目录已声明 dsh.bundle，可直接激活）

# 方式二：本地路径（仅限开发调试）
dsh plugin --profile web add <项目克隆路径>\dsh-plugin
# 注意：file: 为绝对路径硬编码，换机器/移动目录后失效，需重新安装；正式使用请用方式一

# 方式三：从 git 下载的 tarball（固定版本）
dsh plugin --profile web add <path-to>/project-blueprint-dsh-2.0.0.tgz
```

> 安装方式差异：**GitHub 地址（方式一）** 与 **tarball（方式三）** 不依赖安装地址，任何机器均可安装；**本地路径（方式二）** 依赖绝对路径，仅适合本机开发调试。插件内部通过包内相对路径定位 `skills/` 目录，与 dsh 本体的安装位置无关。

安装后重启 `dsh web`，在会话输入 `/` 或描述"初始化新项目/建立开发规范"即可触发 Project Blueprint 技能。

## 兼容性

- **已验证至 DSH `0.1.1-rc.2`（2026-08-22）**：dsh 升级包含破坏性变更（v0.1.0-rc.8 SQLite 会话存储格式不兼容、Session Projection API 迁移），实测本插件 **无需适配**：
  - `ctx.skills.registerProvider`（`@deepseek-ai/dsh-skill@0.1.1-rc.2`）、`FileSystemSkillProvider(ctx, control, {providerName, includeDefaultRoots, customSkillDirs})`（`@deepseek-ai/dsh-skill-filesystem@0.1.1-rc.2`）、`ctx.effect`（`@deepseek-ai/cordis@4.0.1`）签名均未变
  - 安装机制 `dsh.bundle.patch` 判定与 `dsh.profile.bundles` 合成逻辑在 0.1.1-rc.2 原样保留（dsh 主包 plugin 模块核对）
  - 隔离环境运行时验证：0.1.1-rc.2 依赖 + 官方 `LocalFileSystem` 加载本插件，provider 正常发现 `project-blueprint` 技能 ✅
  - 官方破坏性变更均不触及本插件：SQLite 会话存储不兼容仅影响旧会话数据迁移；Session Projection API 迁移影响 dsh-billing 等会话统计类插件

## 原理

- `package.json` 声明 `dsh.bundle.patch: ./cordis.patch.yml`，安装时把插件挂进当前 profile。
- `cordis.patch.yml` 以包名挂载本插件（`- insert: [{ id: project-blueprint, name: project-blueprint }]`）。
- `lib/index.js` 复用官方 `FileSystemSkillProvider`，把包内 `skills/` 目录注册为 custom skill 根（rank 300，项目根之后、用户根之前）。
- `skills/project-blueprint/SKILL.md` + `references/` 为标准 Agent Skills 格式（`name`/`description` frontmatter），DSH 原生加载，`/` 命令与 description 自动触发均可用。

## 维护

技能内容的**唯一事实来源是仓库根** `SKILL.md` + `references/`。改动后发版前运行：

```bash
node dsh-plugin/scripts/sync-skill.mjs
```

它会把根目录内容同步到 `dsh-plugin/skills/project-blueprint/`，确保插件包与主技能一致。

## 通用分发（Agent Plugins v1.0.0）

仓库同时提供 `plugin.json`（Agent Plugins v1.0.0 清单）+ `skills/` 目录，任何符合该标准的客户端（如 Claude Code、Cursor、Codex 的插件机制）可将本仓库根作为便携插件包安装。

## 文件结构

```
dsh-plugin/
├── package.json        # npm 包元数据 + dsh.bundle.patch
├── cordis.patch.yml    # profile 挂载配置
├── plugin.json         # Agent Plugins v1.0.0 便携清单（跨宿主）
├── lib/                # 零构建 ESM 插件（直接加载）
│   ├── index.js
│   └── types/index.d.ts
├── skills/             # 打包的技能内容（由 sync-skill.mjs 同步）
│   └── project-blueprint/
│       ├── SKILL.md
│       └── references/
└── scripts/
    └── sync-skill.mjs  # 同步脚本
```

## 许可证

MIT。技能内容与仓库根保持一致，变更请同步更新 `README.md` / `README_CN.md` / `CHANGELOG.md`。
