# dsh-setting-manager
中文 | [English](docs/README.en.md)

DSH 插件：右键设置页的分区导航，弹出勾选菜单，控制各设置分区的显示与隐藏。
隐藏是纯视觉的（`display:none`），不影响任何功能；显隐状态经 DSH 设置服务
持久化到 profile 配置，跨重启 / 跨浏览器共享。

| 版本 | 0.2.0 |
|---|---|
| 形态 | 纯 JS（`"type": "module"`），`lib/` 即源码，无构建步骤 |
| 端 | Host（settings service）+ Client（浏览器菜单），各一个入口 |

## 效果
![预览图](docs/images/preview.png)

## 功能

- **右键勾选菜单**：在设置分区导航上任意位置（含标题区）右键，弹出「设置菜单」
  浮层，按序列出全部设置分区，每行带勾选标记。`✓` 表示该分区可见，空白表示已隐藏；
  点击行立即切换，菜单保持打开，可以连续点几行，每点一下即生效并持久化。
  菜单只在点击它之外或按 `Escape` 时关闭。
  菜单文案随 DSH 语言环境（中/英）显示。
- **显示全部 / 隐藏全部**：菜单底部两个按钮，批量操作；点击同样不关菜单。
- **全隐藏提示**：允许隐藏任意分区，包括全部。导航里没有任何可见分区时，
  菜单即时显示一行居中的「当前已全部隐藏」（DSH 警示色）；恢复一个分区后
  提示即时消失。导航标题区仍可右键唤回菜单。
- **跨浏览器持久化**：显隐状态经 DSH 设置服务（remote.settings 的
  describe / update）读写，持久化到 profile 配置。多个浏览器、标签页共享
  同一份状态；每次打开菜单都读回并与当前分区校准。
- **主题跟随**：浮层的字体、间距、圆角、阴影、背景、勾选、悬停全部使用 DSH
  主题变量（`--dsw-alias-*` / `--dsw-font-family` / `--dsw-elevation-*`），
  亮 / 暗主题自动跟随；宽度随内容自适应，长分区名不截断。
- **自动重新应用**：分区增减、语言切换、导航重建时自动重新匹配标签并重新
  应用隐藏态（文本匹配为主，下标兜底）。

## 安装

```powershell
dsh plugin --profile web add github:coderHeJiyu/dsh-setting-manager
```

从 GitHub 仓库直接安装，拉取默认分支的最新提交。前提（DSH / Node.js /
pnpm）、验证、本地源码挂载、更新与卸载详见 [安装指南](docs/installation.zh.md)

## 使用

1. 打开 DSH web GUI → 设置页。
2. 在左侧分区导航上任意位置右键。
3. 点行切换分区显隐；底部「显示全部」/「隐藏全部」批量操作。
4. 刷新页面、换浏览器，状态不变。

## 持久化

状态经 DSH 设置服务持久化到 profile 配置：命名空间为插件 entry id
`setting-manager`（见 `cordis.patch.yml`），唯一的 volatile 字段是
`hidden`（见 Host 端 `lib/index.js` 导出的 `Config`）。Client 端经
`remote.settings` 的 `describe` / `update` 读写该命名空间。

数据形状：

```json
{
  "hidden": [
    "models"
  ]
}
```

- `hidden` 是被隐藏分区的 id 数组（`settings.section` 条目的 `options.id`，
  如 `general` / `models` / `plugins` / `agent-presets`）。
- 读回退：settings / remote 缺席、非 ok、命名空间缺失、`value.hidden` 非数组，
  一律按 `[]` 处理（全显示）。任何情况都不报错。
- profile 配置随 DSH 持久化，跨重启保留；多个浏览器、标签页共享同一份状态。

## 通道与安全

状态不经过任何自造的网络入口：Client 端经 DSH 的 **remote.settings**
（describe / update）读写 profile 配置，走宿主核心的远端通道。

- **桌面安全（核心远端通道，无 Origin 依赖）**：持久化通道由 DSH 宿主
  统一管理，跨浏览器共享即由这一通道提供，插件无需自造安全层。
- **不暴露网络入口**：插件自身不注册任何 HTTP 路由或 `webServer` 端点，
  唯一的持久化路径是 settings service。
- `hidden` 数组中的非字符串元素在写入前被过滤（Client 端）。
- settings / remote 缺席（如 headless profile）时读取按 `[]` 处理，
  写入静默 no-op，UI 不崩。

## 依赖

- `@deepseek-ai/schemastery`（`^3.0.0`）：Host 端用其定义 volatile `Config`
  投影（`hidden` 字段），由宿主基线提供，optional peer。
- `@deepseek-ai/cordis`（`^4.0.1`）：可选 peer，由宿主提供。
- `package.json` 的 `dsh.client.inject` 为空：自 DSH 0.1.5 起，
  Client 端依赖由宿主基线提供，清单不再声明。分区标签解析经
  按当前语言求值的语言 thunk，优先取宿主基线实现，不可解析时
  回退到语义等价的本地实现。

## 项目结构

```
dsh-setting-manager/
├── lib/
│   ├── index.js      # Host：注入 settings 面（auto:false）+ 导出 volatile Config
│   └── client.js     # Client：右键菜单、display:none 应用器、remote.settings 同步、主题样式
├── cordis.patch.yml  # 插件注册 patch（insert id: setting-manager）
├── package.json
└── .gitignore
```

纯 JS，`lib/` 直接入库；没有 tsconfig、构建产物和测试框架。

本地开发热更（`dsh web` 运行中）：源码用 `link:` 软链安装
（`dsh plugin --profile web add link:/path/to/checkout`）后，client-hmr
每 500 ms（默认）stat 轮询一次 client bundle，变化经 SSE 广播，浏览器重新
执行 client 入口，无需手动刷新。

- 改 `lib/client.js`：按上述机制自动重载。
- 改 `lib/index.js`：Host 在启动时加载，需重启 `dsh web`。

## 已知限制

- 隐藏是纯视觉的：被隐藏分区仍挂载在 React 树中，其快捷键与编程入口照常有效
  （对齐 VS Code 的 Hide View 口径）。
- 状态按 profile 区分（存于各自 profile 配置）：多个 profile 安装本插件时，
  各 profile 拥有独立的显隐列表。
- 右键识别依赖 nav 按钮文本与分区标签的匹配（压缩空白后按多重集比对）；
  对不上时（如自定义分区没有标签）不弹菜单，保留默认右键行为。
- 只管 `settings.section` 分区导航，设置页内部的子控件不在控制范围。
