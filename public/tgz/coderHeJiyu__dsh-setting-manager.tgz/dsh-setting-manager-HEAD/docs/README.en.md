# dsh-setting-manager
[中文](../README.md) | English

A DSH plugin that hides or shows settings sections. Right-click the section
navigation on the settings page to open a check menu; click rows to toggle
sections. Hiding is purely visual (`display:none`) and does not change any
behavior. Show/hide state is persisted to the profile configuration via the
DSH settings service, and is shared across restarts and across browsers.

| Version | 0.2.0 |
|---|---|
| Form | Pure JS (`"type": "module"`); `lib/` is the source, no build step |
| Sides | Host (settings service) + Client (browser menu), one entry each |

## Preview
![Preview](images/preview-en.png)

## What it does

- **Right-click check menu.** Right-click anywhere on the settings section
  navigation (title area included) to open the 设置菜单 ("Settings Menu")
  popup. It lists
  every settings section in order, one row each, with a check mark: `✓` means
  the section is visible, blank means hidden. Clicking a row toggles it at
  once. The menu stays open, so you can keep clicking; every click applies
  and persists immediately. It closes only when you click outside it or press
  `Escape`. Menu strings follow the DSH locale (zh/en).
- **Show all / Hide all.** The 显示全部 / 隐藏全部 buttons at the bottom of
  the menu cover batch operations. Clicking them does not close the menu
  either.
- **All-hidden hint.** Any section can be hidden, including all of them. When
  no section is visible, the menu shows a centered 当前已全部隐藏 line (DSH
  warning color) right away; it disappears as soon as one section is restored.
  The navigation title area still right-clicks back to the menu.
- **Cross-browser persistence.** Show/hide state travels through the DSH
  settings service (remote.settings describe / update) and is persisted to
  the profile configuration. Multiple browsers and tabs share the same
  state; every menu open reads it back and reconciles against the current
  sections.
- **Theme follow.** The popup's font, spacing, corner radius, shadow,
  background, checks, and hover state all use DSH theme variables
  (`--dsw-alias-*` / `--dsw-font-family` / `--dsw-elevation-*`), so light and
  dark themes follow automatically. Width adapts to content; long section
  names are not truncated.
- **Automatic re-application.** When sections are added or removed, the
  language changes, or the navigation is rebuilt, labels are re-matched and
  the hidden state is re-applied (text matching first, index alignment as
  fallback).

## Installation

```powershell
dsh plugin --profile web add github:coderHeJiyu/dsh-setting-manager
```

Install directly from the GitHub repository, pulling the latest commit of the
default branch. Prerequisites (DSH / Node.js / pnpm), verification,
from-source mount, updating, and uninstalling are covered in the
[installation guide](./installation.en.md).

## Usage

1. Open the DSH web GUI → settings page.
2. Right-click anywhere on the section navigation on the left.
3. Click rows to toggle sections; use 显示全部 / 隐藏全部 at the bottom for
   batch operations.
4. State survives page refresh and browser switches.

## Persistence

State is persisted to the profile configuration via the DSH settings service:
the namespace is the plugin entry id `setting-manager` (see `cordis.patch.yml`),
and the only volatile field is `hidden` (see the `Config` exported from the
Host's `lib/index.js`). The Client reads and writes that namespace through
`remote.settings` describe / update.

Data shape:

```json
{
  "hidden": [
    "models"
  ]
}
```

- `hidden` is an array of section ids (the `options.id` of `settings.section`
  entries, e.g. `general` / `models` / `plugins` / `agent-presets`).
- Read fallback: an absent settings / remote, a non-ok result, a missing
  namespace, or a non-array `value.hidden` all yield `[]` (everything visible).
  Nothing errors out.
- The profile configuration is persisted by DSH across restarts; multiple
  browsers and tabs share the same state.

## Channel and security

State does not travel through any self-made network entry: the Client reads
and writes the profile configuration through DSH's **remote.settings**
(describe / update), over the host's core remote channel.

- **Desktop security (core remote channel, no Origin dependency):** the
  persistence channel is managed uniformly by the DSH host; cross-browser
  sharing is provided by this channel, so the plugin needs no self-made
  security layer.
- **No network entry point:** the plugin registers no HTTP route or
  `webServer` endpoint of its own; the only persistence path is the settings
  service.
- Non-string entries in `hidden` are filtered out before the write (Client side).
- If settings / remote is absent (e.g. a headless profile), reads yield `[]`
  and writes are a silent no-op; the UI does not crash.

## Dependencies

- `@deepseek-ai/schemastery` (`^3.0.0`): the Host uses it to define the
  volatile `Config` projection (`hidden` field); provided by the host
  baseline, optional peer.
- `@deepseek-ai/cordis` (`^4.0.1`): optional peer, provided by the host.
- `dsh.client.inject` in `package.json` is empty: since DSH 0.1.5, client-side
  dependencies are provided by the host baseline, so the manifest no longer
  declares them. Section labels are resolved as language thunks evaluated in
  the current language; the host-baseline implementation is preferred, and a
  local implementation with identical semantics takes over if it cannot be
  resolved.

## Project layout

```
dsh-setting-manager/
├── lib/
│   ├── index.js      # Host: injects the settings face (auto:false) + exports volatile Config
│   └── client.js     # Client: right-click menu, display:none applier, remote.settings sync, theme styles
├── cordis.patch.yml  # plugin registration patch (inserts id: setting-manager)
├── package.json
└── .gitignore
```

Pure JS, `lib/` checked in as-is; no tsconfig, build output, or test
framework.

Local development (with `dsh web` running): install the checkout as a
symlink (`dsh plugin --profile web add link:/path/to/checkout`); client-hmr
stat-polls the client bundle every 500 ms (default) and broadcasts changes
over SSE, so the browser re-runs the client entry without a manual refresh.

- `lib/client.js` changes: reloaded automatically (the mechanism above).
- `lib/index.js` changes: loaded by the Host at boot; restart `dsh web`.

## Known limitations

- Hiding is purely visual: hidden sections stay mounted in the React tree,
  and their keyboard shortcuts and programmatic entry points keep working
  (same stance as VS Code's Hide View).
- State is per profile (stored in each profile's configuration): multiple
  profiles with this plugin installed each keep their own hidden list.
- Right-click detection matches the navigation button texts against section
  labels (whitespace-squashed, multiset comparison). When they do not match
  (e.g. a custom section without a label), the menu does not open and the
  default right-click behavior is preserved.
- Only the `settings.section` navigation is controlled; controls inside the
  settings page itself are out of scope.
