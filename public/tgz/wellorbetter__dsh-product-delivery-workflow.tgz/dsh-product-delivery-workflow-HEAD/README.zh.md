<h1 align="center">产品交付工作流</h1>

<p align="center">
  <a href="README.md">English</a>&nbsp;|&nbsp;<a href="README.zh.md">中文</a>
</p>

<p align="center">
  <a href="https://github.com/wellorbetter/dsh-product-delivery-workflow/blob/main/LICENSE"><img alt="License MIT" src="https://img.shields.io/badge/License-MIT-blue.svg?style=flat-square"></a>
  <a href="https://github.com/deepseek-ai/deepseek-harness"><img alt="For DeepSeek Harness" src="https://img.shields.io/badge/For-DeepSeek%20Harness-8257D0.svg?style=flat-square"></a>
  <a href="https://github.com/topics/dsh-plugin"><img alt="dsh-plugin" src="https://img.shields.io/badge/topic-dsh--plugin-0969da.svg?style=flat-square"></a>
</p>

<p align="center">
  <strong>面向 DeepSeek Harness 的产品交付工作流插件：一条从产品到发布的全流程流水线，自带闭环，专为高质量自主完成长难任务设计。</strong><br>
  <em>睡前启动，醒来收货。</em><br>
  <strong>100% AI 原生</strong> —— 全程无人值守：自主调研、架构、实现、评审、测试与发布审计，端到端闭环。
</p>

## 插件提供了什么

安装本 bundle 后，目标 dsh profile 的每个会话都会获得**1 个工作流技能 + 9 个角色智能体技能**（通过面向模型的 `skill` 工具和 `ctx.skills` 提供），无需任何额外配置。

| 技能 | 角色 |
|---|---|
| `product-delivery-workflow` | 总编排：从需求到发布的 10 道关卡，产物驱动、含评审循环，必须输出最终报告。 |
| `product-agent` | 产品经理：基于证据做决策（`BUILD` / `REFINE` / `REJECT`），产出含验收标准与指标的 PRD。 |
| `architect-agent` | 资深架构师：OpenSpec 提案、组件边界、接口、契约与依赖排序的任务图。 |
| `senior-dev-agent` | 资深开发者：按契约做有界实现，写确定性测试，显式错误处理。 |
| `agent-team` | 多智能体团队/群体：有界 subagent、并行工作流、互不重叠的文件所有权、独立评审。 |
| `perf-reviewer-agent` | 只读性能评审，对照 PRD 预算。 |
| `test-agent` | 自动化测试与人工平台/设备验证，对照契约与验收标准。 |
| `memory-curator` | 仅从已批准产物中提炼安全的跨会话项目记忆。 |
| `evolution-agent` | 以证据支撑的提案形式提出可量测的工作流改进。 |
| `release-audit-agent` | 提交前 / GitHub 发布前的只读审计（密钥、隐私、卫生）。 |

## 工作流一览

```text
需求 → 调研 → 产品决策 → PRD → OpenSpec 架构
      → 并行实现（每个任务一个有界智能体）
      → 独立评审循环（正确性 / 架构 / 性能）
      → 测试与验收 → 记忆与进化 → 发布审计
      → 强制最终报告 ──┐
                       └── 评审发现回流给对应 worker → 循环直到全部 PASS
```

闭环是关键：每条评审发现都会回流给对应 worker 并反复迭代，直到所有评审通过（最多 5 轮，之后请求人工指示）。没有产物或验证结果，绝不宣称某角色或关卡已执行。

## 为什么适合睡前执行

- **闭环自驱** — 评审 → 修复 → 再评审无需人工盯着；只在关卡通过或遇到需要你的硬阻塞时停下。
- **产物持久化** — 全部落在 `.opencode/workflow/<slug>/`（`01-research.md` → `10-*`），睡醒后可完整审计整次运行。
- **有界委派** — 并行波次 + 互不重叠的文件所有权 + 明确契约；worker 从不 commit、push 或改契约。
- **安全护栏** — 任何 `git commit` / PR / push 前都会跑发布审计；记忆提炼从不存密钥或对话原文。
- **自我进化** — `evolution-agent` + `memory-curator` 把每次运行的证据变成下一次的提案与持久记忆。

## 安装

需要 `dsh` CLI（[安装 DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)）。

```sh
# 从 GitHub（推荐）
dsh plugin --profile web add github:wellorbetter/dsh-product-delivery-workflow

# 或本地 checkout
dsh plugin --profile web add ./dsh-product-delivery-workflow
```

安装后重启目标 profile（`dsh web` / `dsh --profile <name>`）。本插件是 [bundle](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.zh.md)：声明了 `dsh.bundle.patch`，`dsh plugin` 会自动把它对账进 profile 的 `dsh.profile.bundles` 层列表。插件是纯 JavaScript（`lib/index.js`），GitHub 安装无需构建步骤、也无需 `allowBuilds` 授权。

## 使用

在 profile 的任意会话中直接要求执行工作流即可，编排器会自行加载各角色技能：

> 对 `<需求>` 运行产品交付工作流。产出完整流水线与最终报告。你可以自主运行，直到关卡全部通过。

也可以单独调用某个角色做有界任务：

> 用 product-agent 对照交付结果评审这份 PRD，并报告差距。

睡前长跑建议配合 goal / headless 模式：用 brief 启动会话，让它循环执行，早上查看 `.opencode/workflow/<slug>/` 产物与最终报告。

## 开发

```sh
pnpm install
pnpm verify     # 通过内置 provider 发现并加载全部 10 个打包技能
```

## License

MIT
