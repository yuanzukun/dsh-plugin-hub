// verify.mjs — package-level smoke test for dsh-product-delivery-workflow.
//
// Loads the bundle's provider module, mounts it against a minimal in-memory
// `ctx.skills` registry stand-in, and asserts that every packaged skill is
// discovered and loadable with correct frontmatter. Run with:
//
//   pnpm verify        (or)   node scripts/verify.mjs
//
// It needs the `yaml` dependency resolvable; from a fresh checkout run
// `npm install` or `pnpm install` first.

import { createRequire } from "node:module";
import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";

const require = createRequire(import.meta.url);
const { parse } = require("yaml");

const { apply } = await import("../lib/index.js");

const EXPECTED = [
	["agent-team", "Multi-agent team"],
	["architect-agent", "Senior software architect"],
	["evolution-agent", "Analyze completed workflows"],
	["memory-curator", "Curate safe cross-session project memory"],
	["perf-reviewer-agent", "Read-only performance reviewer"],
	["product-agent", "Senior product manager"],
	["product-delivery-workflow", "Full product-to-release workflow"],
	["release-audit-agent", "Read-only pre-commit and pre-GitHub release audit"],
	["senior-dev-agent", "Senior Rust developer"],
	["test-agent", "Focused automated testing"]
];

/** Minimal stand-in for the pieces of `ctx.skills` the plugin consumes. */
function makeRegistry() {
	const providers = [];
	return {
		registerProvider(create) {
			const control = { signal: new AbortController().signal, invalidate() {} };
			providers.push(create(control));
		},
		providers
	};
}

const ctx = { skills: makeRegistry() };
apply(ctx);
assert.equal(ctx.skills.providers.length, 1, "expected exactly one provider registered");
const provider = ctx.skills.providers[0];

const candidates = await provider.list({});
assert.equal(candidates.length, EXPECTED.length, `expected ${EXPECTED.length} skills, got ${candidates.length}`);

for (const [name, descriptionPrefix] of EXPECTED) {
	const candidate = candidates.find((c) => c.name === name);
	assert.ok(candidate, `missing skill ${name}`);
	assert.ok(
		candidate.description.startsWith(descriptionPrefix),
		`unexpected description for ${name}: ${candidate.description}`
	);
	assert.equal(candidate.rank, 600, `${name} should use the bundled rank`);
	assert.equal(candidate.source, "bundled", `${name} should be sourced as bundled`);
	assert.equal(candidate.invocation.modelInvocable, true, `${name} should be model-invocable`);

	const definition = await provider.get(candidate, {});
	assert.ok(definition, `failed to load ${name}`);
	assert.ok(definition.content.length > 100, `${name} body looks too short`);
	assert.equal(definition.name, name, `${name} definition name mismatch`);
}

// Ensure the workflow skill (the orchestrator) is present and references its roles.
const workflow = candidates.find((c) => c.name === "product-delivery-workflow");
const workflowDef = await provider.get(workflow, {});
for (const role of ["product-agent", "architect-agent", "senior-dev-agent", "test-agent", "release-audit-agent"]) {
	assert.ok(workflowDef.content.includes(role), `workflow should reference ${role}`);
}

console.log(`OK: ${candidates.length} skills discovered and loaded through the bundled provider.`);
