import type { Context } from "@deepseek-ai/cordis";

export const name: string;
export const inject: readonly string[];

export interface Config {
	/** Reserved for future configuration; the bundled provider currently needs none. */
	[key: string]: unknown;
}

export function apply(ctx: Context, config?: Config): void;
