<h1 align="center">Product Delivery Workflow</h1>

<p align="center">
  <a href="README.md">English</a>&nbsp;|&nbsp;<a href="README.zh.md">中文</a>
</p>

<p align="center">
  <a href="https://github.com/wellorbetter/dsh-product-delivery-workflow/blob/main/LICENSE"><img alt="License MIT" src="https://img.shields.io/badge/License-MIT-blue.svg?style=flat-square"></a>
  <a href="https://github.com/deepseek-ai/deepseek-harness"><img alt="For DeepSeek Harness" src="https://img.shields.io/badge/For-DeepSeek%20Harness-8257D0.svg?style=flat-square"></a>
  <a href="https://github.com/topics/dsh-plugin"><img alt="dsh-plugin" src="https://img.shields.io/badge/topic-dsh--plugin-0969da.svg?style=flat-square"></a>
</p>

<p align="center">
  <strong>A product delivery workflow plugin for DeepSeek Harness: a full product-to-release pipeline with loop closure, built for high-quality autonomous completion of long, hard tasks.</strong><br>
  <em>Kick it off before you sleep; wake up to the final report.</em><br>
  <strong>100% AI-native</strong> — no human in the loop: autonomous research, architecture, implementation, review, testing, and release audit, end to end.
</p>

## What this plugin provides

Installing this bundle adds **one workflow skill + nine role-agent skills** to every session of the target dsh profile (via the model-facing `skill` tool and `ctx.skills`). No other configuration is needed.

| Skill | Role |
|---|---|
| `product-delivery-workflow` | The orchestrator: 10 stage gates from brief to release, artifact-driven, with review loops and a required final report. |
| `product-agent` | Product manager: evidence-backed decisions (`BUILD` / `REFINE` / `REJECT`), PRDs with acceptance criteria and metrics. |
| `architect-agent` | Senior architect: OpenSpec proposals, component boundaries, interfaces, contracts, and dependency-ordered task graphs. |
| `senior-dev-agent` | Senior developer: bounded implementation from contracts, deterministic tests, explicit error handling. |
| `agent-team` | Multi-agent team/swarm: bounded subagents, parallel workflows, disjoint ownership, independent review. |
| `perf-reviewer-agent` | Read-only performance reviewer against PRD budgets. |
| `test-agent` | Automated testing and manual platform/device verification against contracts and acceptance criteria. |
| `memory-curator` | Safe cross-session memory candidates from approved evidence only. |
| `evolution-agent` | Measurable workflow improvements as evidence-backed proposals. |
| `release-audit-agent` | Read-only pre-commit / pre-GitHub release audit (secrets, privacy, hygiene). |

## The workflow in one picture

```text
Brief → Research → Product Decision → PRD → OpenSpec Architecture
      → Parallel Implementation (one bounded agent per task)
      → Independent Review Loop (correctness / architecture / performance)
      → Tests & Acceptance → Memory & Evolution → Release Audit
      → Required Final Report ──┐
                                └── findings route back to workers → loop until PASS
```

The loop is the point: every review finding routes back to the responsible worker and repeats until all reviewers pass (5 cycles max, then it asks for human direction). Nothing is claimed unless its artifact or verification result exists.

## Why run it overnight

- **Loop closure** — review → fix → re-review continues without human babysitting; it stops only when gates pass or a hard blocker needs you.
- **Artifact persistence** — everything lands under `.opencode/workflow/<slug>/` (`01-research.md` → `10-*`), so you can audit the whole run after sleeping.
- **Bounded delegation** — parallel waves with disjoint file ownership and explicit contracts; workers never commit, push, or redesign contracts.
- **Safety rails** — the release audit runs before any `git commit` / PR / push, and memory curation never stores secrets or transcripts.
- **Self-improving** — `evolution-agent` + `memory-curator` turn each run's evidence into proposals and durable memory for the next one.

## Install

Requires the `dsh` CLI ([install DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)).

```sh
# from GitHub (recommended)
dsh plugin --profile web add github:wellorbetter/dsh-product-delivery-workflow

# or from a local checkout
dsh plugin --profile web add ./dsh-product-delivery-workflow
```

Restart the profile (`dsh web` / `dsh --profile <name>`) after installing. The plugin is a [bundle](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.md): it declares `dsh.bundle.patch`, so `dsh plugin` reconciles it into the profile's `dsh.profile.bundles` layer list automatically. It ships plain JavaScript (`lib/index.js`), so a GitHub install needs no build step or `allowBuilds` permission.

## Use

In any session of the profile, ask for the workflow — the orchestrator loads the role skills itself:

> Run the product delivery workflow on `<brief>`. Produce the full pipeline and the final report. You may work autonomously; loop until the gates pass.

Or invoke a single role for a bounded task:

> Use product-agent to review this PRD against the delivery results and report gaps.

For overnight runs, pair it with the goal/headless mode: start a session with the brief, let it loop, and check the `.opencode/workflow/<slug>/` artifacts and final report in the morning.

## Development

```sh
pnpm install
pnpm verify     # discovers + loads all 10 packaged skills through the provider
```

## License

MIT
