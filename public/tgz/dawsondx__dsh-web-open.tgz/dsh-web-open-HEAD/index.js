/**
 * dsh-web-open — a DeepSeek Harness bundle.
 *
 * When the web profile finishes booting, print the full GUI URL and open it
 * in the default browser. Modeled on the official web-app `printUrl` row
 * (packages/bundle/web-app/src/index.ts), but cross-platform and fail-safe:
 *
 *   - apply() never throws. Every step is wrapped; missing services degrade
 *     to a console warning, never a boot failure.
 *   - It waits for the Loader to settle, then polls the webServer service
 *     (bounded retry) so it works even if mount order changes.
 *   - `webServer.port` is the real bound port, so `dsh web --port 0`
 *     (OS-assigned) opens the correct URL too.
 *
 * Runtime dependencies: none (only node:child_process). The only peer is
 * `@deepseek-ai/cordis` (the stable 4.x plugin core), deliberately NOT any
 * rc-versioned dsh internal package.
 */

import { openBrowser } from "./opener.js";

const name = "web-open";

/**
 * @param {import("@deepseek-ai/cordis").Context} ctx
 * @param {{open?: boolean, printUrl?: boolean, url?: string, retryAttempts?: number, retryIntervalMs?: number}} config
 */
function apply(ctx, config = {}) {
	const open = config.open !== false && process.env.DSH_OPEN_BROWSER !== "0";
	const printUrl = config.printUrl !== false;
	const attempts = Number.isInteger(config.retryAttempts) ? config.retryAttempts : 40; // 40 * 250ms
	const intervalMs = Number.isInteger(config.retryIntervalMs) ? config.retryIntervalMs : 250;
	const get = typeof ctx.get === "function" ? (key) => ctx.get(key) : () => undefined;

	/** @returns {boolean} true when the server is bound and the URL was handled */
	function openOnce() {
		try {
			const ws = get("webServer");
			if (!ws || typeof ws.port !== "number") return false;
			const url = typeof config.url === "string" && config.url.length > 0
				? config.url
				: `http://127.0.0.1:${ws.port}/`;
			if (printUrl) console.log(`[web-open] Web GUI ready: ${url}`);
			if (open) internals.openBrowser(url);
			return true;
		} catch (error) {
			console.warn("[web-open] skipped:", error?.message ?? error);
			return true; // 处理过了（虽然失败），不再重试
		}
	}

	let count = 0;
	function tick() {
		if (openOnce()) return;
		if (++count < attempts) setTimeout(tick, intervalMs);
		else console.warn(`[web-open] webServer not available after ${attempts} tries; giving up silently`);
	}

	try {
		const loader = get("loader");
		const settled = loader && typeof loader.await === "function" ? loader.await() : undefined;
		if (settled && typeof settled.then === "function") settled.then(tick, tick);
		else tick();
	} catch (error) {
		console.warn("[web-open] disabled:", error?.message ?? error);
	}
}

/** Test seam, mirroring the official web-app `internals` pattern. */
const internals = { openBrowser };

export { apply, internals, name };
