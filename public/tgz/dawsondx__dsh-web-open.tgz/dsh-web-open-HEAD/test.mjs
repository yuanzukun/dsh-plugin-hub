import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { apply, internals, name } from "./index.js";
import { buildOpenCommand, resolveExecutable, findLauncher, spawnDetached, openBrowser } from "./opener.js";

let passed = 0;
const ok = (label) => { passed++; console.log("  ok -", label); };

// 1) 插件名
assert.equal(name, "web-open");
ok("plugin name is web-open");

// 2) 各平台首选命令形状（纯函数，任何平台可测）
{
  const w = buildOpenCommand("win32", "http://127.0.0.1:3080/");
  assert.equal(w[0], "cmd.exe");
  // URL 带引号（JSON.stringify 生成带双引号的字面量），防止 config.url 含 & 时被 cmd 分隔
  assert.deepEqual(w[1], ["/d", "/c", "start", "", JSON.stringify("http://127.0.0.1:3080/")]);
  ok("win32 -> cmd start with quoted URL");
  assert.equal(buildOpenCommand("darwin", "u")[0], "open");
  assert.equal(buildOpenCommand("linux", "u")[0], "xdg-open");
  ok("darwin/linux first candidate");
  assert.throws(() => buildOpenCommand("plan9", "u"));
  ok("unsupported platform throws in buildOpenCommand (pure fn)");
}

// 3) resolveExecutable：PATH 查找
{
  assert.equal(resolveExecutable("definitely-not-a-real-binary-xyz-123"), null);
  ok("resolveExecutable returns null for missing binary");
  if (process.platform === "win32") {
    assert.ok(resolveExecutable("cmd") !== null, "cmd resolvable on win32");
  } else {
    assert.ok(resolveExecutable("sh") !== null, "sh resolvable on unix");
  }
  ok("resolveExecutable finds a real shell");
}

// 4) findLauncher：合法形状或 null，绝不抛错
{
  const launcher = findLauncher(process.platform);
  assert.ok(launcher === null || (Array.isArray(launcher) && launcher.length === 2 && typeof launcher[1] === "function"));
  ok("findLauncher returns valid shape or null");
}

// 5) 【崩溃回归】spawn 不存在的命令：内部 error 监听吞掉，进程不崩（无 xdg-open 的 Linux 同理）
{
  const warnings = [];
  const oldWarn = console.warn;
  console.warn = (s) => { warnings.push(String(s)); };
  try {
    const child = spawnDetached("definitely-not-a-real-binary-xyz-123", ["a", "b"], "http://127.0.0.1:3080/");
    assert.ok(child !== null, "spawnDetached returns a child handle (error is async)");
    await new Promise((r) => setTimeout(r, 400)); // 给异步 error 事件时间触发
    assert.ok(warnings.some((s) => s.includes("definitely-not-a-real-binary-xyz-123")), "warned about missing launcher");
    assert.ok(warnings.some((s) => s.includes("http://127.0.0.1:3080/")), "warning includes the clickable URL");
    ok("missing launcher does NOT crash the process (ENOENT swallowed)");
  } finally {
    console.warn = oldWarn;
  }
}

// 6) openBrowser 与 spawnDetached 均已导出且可安全组合（不在测试里真弹浏览器）
{
  assert.equal(typeof openBrowser, "function");
  assert.equal(typeof spawnDetached, "function");
  ok("openBrowser/spawnDetached exported");
}

// 7) 敌意 ctx：apply 永不抛错
{
  const ctx = { get: () => undefined };
  assert.doesNotThrow(() => apply(ctx, { retryAttempts: 1, retryIntervalMs: 1 }));
  ok("apply does not throw with hostile ctx");
}

// 8) webServer 就绪：打印链接并调用 opener
{
  const opened = [];
  const logged = [];
  const realOpen = internals.openBrowser;
  internals.openBrowser = (u) => { opened.push(u); };
  const oldLog = console.log;
  console.log = (s) => { logged.push(s); };
  try {
    const loader = { await: () => Promise.resolve() };
    const ctx = { get: (k) => k === "loader" ? loader : k === "webServer" ? { port: 3080 } : undefined };
    apply(ctx, {});
    await new Promise((r) => setTimeout(r, 50));
    assert.deepEqual(opened, ["http://127.0.0.1:3080/"]);
    assert.ok(logged.some((s) => s.includes("http://127.0.0.1:3080/")));
    ok("opens browser + prints URL after server ready");
  } finally {
    internals.openBrowser = realOpen;
    console.log = oldLog;
  }
}

// 9) open:false 抑制；--port 0 用真实绑定端口
{
  const opened = [];
  const realOpen = internals.openBrowser;
  internals.openBrowser = (u) => { opened.push(u); };
  try {
    const loader = { await: () => Promise.resolve() };
    const ctx1 = { get: (k) => k === "loader" ? loader : k === "webServer" ? { port: 3099 } : undefined };
    apply(ctx1, { open: false });
    await new Promise((r) => setTimeout(r, 50));
    assert.deepEqual(opened, []);
    const ctx2 = { get: (k) => k === "loader" ? loader : k === "webServer" ? { port: 41234 } : undefined };
    apply(ctx2, {});
    await new Promise((r) => setTimeout(r, 50));
    assert.deepEqual(opened, ["http://127.0.0.1:41234/"]);
    ok("open:false suppresses; real bound port used (--port 0)");
  } finally {
    internals.openBrowser = realOpen;
  }
}


// 10) 包契约：bundle 清单 / exports / patch 文件必须完整（防止误删导致插件无法加载）
{
  const pkg = JSON.parse(readFileSync(new URL("./package.json", import.meta.url), "utf8"));
  assert.equal(pkg.type, "module");
  assert.equal(pkg.dsh.bundle.patch, "./cordis.patch.yml");
  assert.equal(pkg.exports["./cordis.patch.yml"], "./cordis.patch.yml");
  assert.equal(typeof pkg.exports["."], "string");
  const patchText = readFileSync(new URL("./cordis.patch.yml", import.meta.url), "utf8");
  assert.ok(patchText.includes("id: web-open"));
  assert.ok(patchText.includes("name: @dawsondx/dsh-web-open"));
  ok("bundle manifest contract intact (dsh.bundle.patch + exports + patch file)");
}
console.log(`\nall ${passed} checks passed`);