# Changelog

## 0.1.2

- Released to npm as `@dawsondx/dsh-web-open`.

- README: Chinese-first bilingual layout; "Before vs After" + terminal demo at the top; badges.
- CI: test matrix across Windows / macOS / Linux × Node 20 / 22.
- Manifest: `engines.node`; `.gitattributes` (CRLF for `contrib/windows/*.cmd`).
- Tests: bundle-manifest contract check (13 checks).

## 0.1.1

- **Fix**: never crash when no browser launcher exists (spawn error listener + PATH probing + Linux fallback chain); quote the URL on win32.
- Tests: 12 checks including the ENOENT crash regression.

## 0.1.0

- Initial: auto-open the browser and print the full URL when `dsh web` is ready.