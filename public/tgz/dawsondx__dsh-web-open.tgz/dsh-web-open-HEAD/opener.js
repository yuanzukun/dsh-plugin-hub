import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import { join } from "node:path";

/**
 * 每个平台的候选启动器。win32 用绝对路径（GUI 启动时 PATH 可能不含 System32），
 * darwin 用固定 /usr/bin/open，linux 依次回退多个常见浏览器启动器。
 * argsFor 生成参数；URL 在 win32 上额外加引号，避免 config.url 含 & 等字符时
 * 被 cmd 当成命令分隔符。
 */
const CANDIDATES = {
	win32: [["cmd.exe", (url) => ["/d", "/c", "start", "", `"${url}"`]]],
	darwin: [["open", (url) => [url]]],
	linux: [
		["xdg-open", (url) => [url]],
		["sensible-browser", (url) => [url]],
		["google-chrome", (url) => [url]],
		["chromium", (url) => [url]],
		["firefox", (url) => [url]],
	],
};

/**
 * 纯函数：某平台的首选命令形状（用于文档与测试；不探测 PATH）。
 * @param {string} platform
 * @param {string} url
 * @returns {[string, string[]]}
 */
export function buildOpenCommand(platform, url) {
	const list = CANDIDATES[platform];
	if (!list) throw new Error(`[web-open] unsupported platform: ${platform}`);
	const [command, argsFor] = list[0];
	return [command, argsFor(url)];
}

/**
 * 在 PATH 中查找可执行文件（类 which；win32 支持 PATHEXT）。
 * @param {string} command
 * @param {string} [platform]
 * @returns {string|null} 绝对路径
 */
export function resolveExecutable(command, platform = process.platform) {
	const pathEntries = (process.env.PATH ?? "").split(platform === "win32" ? ";" : ":");
	const exts = platform === "win32" ? (process.env.PATHEXT ?? ".COM;.EXE;.BAT;.CMD").split(";") : [""];
	for (const dir of pathEntries) {
		if (!dir) continue;
		for (const ext of exts) {
			const candidate = join(dir, command + ext);
			if (existsSync(candidate)) return candidate;
		}
	}
	return null;
}

/**
 * 探测当前平台实际可用的启动器。
 * @param {string} [platform]
 * @returns {[string, Function]|null} [command, argsFor]
 */
export function findLauncher(platform = process.platform) {
	const sysRoot = process.env.SystemRoot ?? "C:\\Windows";
	if (platform === "win32") {
		const cmd = join(sysRoot, "System32", "cmd.exe");
		return existsSync(cmd) ? [cmd, CANDIDATES.win32[0][1]] : null;
	}
	if (platform === "darwin") {
		return existsSync("/usr/bin/open") ? ["/usr/bin/open", (url) => [url]] : null;
	}
	if (platform === "linux") {
		for (const [name, argsFor] of CANDIDATES.linux) {
			const resolved = resolveExecutable(name, platform);
			if (resolved) return [resolved, argsFor];
		}
		return null;
	}
	return null;
}

/**
 * 分离式启动一个进程，并挂上 error 监听。
 *
 * 关键：spawn 一个不存在的可执行文件时，Node 会异步触发 'error' 事件；
 * 若不监听，将抛 "Unhandled 'error' event" 直接崩掉整个 dsh 进程。
 * 这里在内部吞掉错误并给出可点击链接，保证任何平台上都不会因为
 * "没有 xdg-open / PATH 被裁剪" 而让 dsh web 崩溃。
 * @param {string} command
 * @param {string[]} args
 * @param {string} [urlForMessage]
 */
export function spawnDetached(command, args, urlForMessage) {
	let child;
	try {
		child = spawn(command, args, { detached: true, stdio: "ignore", windowsHide: true });
	} catch (error) {
		console.warn(`[web-open] failed to launch "${command}": ${error.message}${urlForMessage ? `; open manually: ${urlForMessage}` : ""}`);
		return null;
	}
	child.unref();
	child.on("error", (error) => {
		console.warn(`[web-open] cannot launch "${command}" (${error.code ?? error.message})${urlForMessage ? `; open manually: ${urlForMessage}` : ""}`);
	});
	return child;
}

/**
 * 在默认浏览器打开 url；找不到任何启动器时只警告，绝不抛错。
 * @param {string} url
 */
export function openBrowser(url) {
	const launcher = findLauncher(process.platform);
	if (!launcher) {
		console.warn(`[web-open] no browser launcher found on ${process.platform}; open manually: ${url}`);
		return null;
	}
	const [command, argsFor] = launcher;
	return spawnDetached(command, argsFor(url), url);
}
