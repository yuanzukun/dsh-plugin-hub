# 把下面这段加到 ~/.bashrc 或 ~/.zshrc：
# 裸 `dsh` = dsh web（配合 dsh-web-open 插件自动打开浏览器）；带参数原样转发
dsh() {
  if [ $# -eq 0 ]; then command dsh web; else command dsh "$@"; fi
}
