@echo off
setlocal EnableExtensions
title DSH Updater
set "NOPAUSE=0"
if "%~1"=="--nopause" set "NOPAUSE=1"
set "EXITCODE=0"

echo.
echo  [DSH] Checking for official dsh updates ...

set "LATEST="
for /f "usebackq delims=" %%v in (`npm view @deepseek-ai/dsh version --no-update-notifier 2^>nul`) do set "LATEST=%%v"
if not defined LATEST (
  echo  [DSH] Cannot reach the npm registry - offline? Nothing changed.
  set "EXITCODE=1"
  goto :end
)

set "CUR=unknown"
if exist "%APPDATA%\npm\dsh.cmd" (
  for /f "delims=" %%v in ('"%APPDATA%\npm\dsh.cmd" --version 2^>nul') do set "CUR=%%v"
)
echo  [DSH] Installed: %CUR%    Latest: %LATEST%

if "%LATEST%"=="%CUR%" (
  echo  [DSH] Already up to date.
  goto :end
)

echo.
echo  [DSH] Updating launcher to %LATEST% ...
call npm install -g "@deepseek-ai/dsh@%LATEST%" --no-fund --no-audit
if errorlevel 1 (
  echo  [DSH] Launcher update FAILED. See npm output above.
  set "EXITCODE=1"
  goto :end
)

echo  [DSH] Launcher updated. Refreshing profile plugin state ...
call "%APPDATA%\npm\dsh.cmd" plugin --profile web update
echo.
echo  [DSH] Done. The next "dsh web" will use %LATEST%.
echo  [DSH] Note: the currently running GUI keeps its old version until restarted.
echo.

:end
if "%NOPAUSE%"=="0" pause
endlocal & exit /b %EXITCODE%
