@echo off
setlocal EnableExtensions
title DSH Web Launcher
set "PORT=3080"
if defined DSH_PORT set "PORT=%DSH_PORT%"
set "URL=http://127.0.0.1:%PORT%/"

rem ===== 0) optional: check for official dsh updates =====  (DSH_SKIP_UPDATE_CHECK=1 to skip)
if defined DSH_SKIP_UPDATE_CHECK goto :boot
set "LATEST="
for /f "usebackq delims=" %%v in (`npm view @deepseek-ai/dsh version --no-update-notifier 2^>nul`) do set "LATEST=%%v"
if not defined LATEST goto :boot
set "CUR=unknown"
if exist "%APPDATA%\npm\dsh.cmd" (
  for /f "delims=" %%v in ('"%APPDATA%\npm\dsh.cmd" --version 2^>nul') do set "CUR=%%v"
)
if "%LATEST%"=="%CUR%" goto :boot
echo.
echo  [DSH] A new official version is available: %CUR% -^> %LATEST%
if defined DSH_AUTO_UPDATE (
  echo  [DSH] DSH_AUTO_UPDATE=1 - updating now ...
  call "%~dp0dsh-update.cmd" --nopause
  echo  [DSH] Update finished.
) else (
  echo  [DSH] To update: run "dsh-update" or double-click the "DSH Update" shortcut.
)
echo.
:boot

rem ===== 1) if the port is already listening, the server is running =====
powershell -NoProfile -ExecutionPolicy Bypass -Command "$c = Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue; if ($c) { exit 0 } else { exit 1 }"
if "%errorlevel%"=="0" (
  echo.
  echo  [DSH] Web server is already running.
  echo  [DSH] Opening: %URL%
  echo.
  if not defined DSH_NO_BROWSER start "" "%URL%"
  endlocal & exit /b 0
)

rem ===== 2) start the server in its own window (close that window to stop) =====
echo.
echo  [DSH] Starting dsh web, please wait ...
echo  [DSH] Server logs stay in the "DSH Web Server" window. Close it to stop the server.
echo.
set "BOOT=dsh"
if exist "%APPDATA%\npm\dsh.cmd" set "BOOT=%APPDATA%\npm\dsh.cmd"
set "BOOTARGS=web"
if defined DSH_PORT set "BOOTARGS=web --port %PORT%"
start "DSH Web Server" cmd /k "%BOOT% %BOOTARGS%"

rem ===== 3) wait for the port (up to 90 seconds) =====
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; for ($i = 0; $i -lt 90; $i++) { $c = New-Object System.Net.Sockets.TcpClient; try { $c.Connect('127.0.0.1', %PORT%); $c.Close(); exit 0 } catch { Start-Sleep -Seconds 1 } }; exit 1"
if "%errorlevel%"=="0" (
  echo.
  echo  [DSH] Server is ready!
  echo  [DSH] Opening: %URL%
  echo.
  if not defined DSH_NO_BROWSER start "" "%URL%"
) else (
  echo.
  echo  [DSH] Server did not start within 90s. Check the "DSH Web Server" window for errors.
  echo  [DSH] You can also open it manually: %URL%
  echo.
)
endlocal
