# Windows 启动器（可选）

把 `dsh-web.cmd` 复制到任意已在 PATH 的目录（例如 `C:\Users\<你>\AppData\Roaming\npm`），或在桌面建一个指向它的快捷方式。

功能：
- 端口 3080 已被占用（服务已在跑）→ 直接打印链接并打开浏览器，退出；
- 未运行 → 开一个 "DSH Web Server" 窗口启动 `dsh web`，等待就绪（最多 90 秒）→ 打印链接并自动打开浏览器。

可选环境变量：
- `DSH_PORT=8080`：改用其他端口（会同时透传给 `dsh web --port`）
- `DSH_NO_BROWSER=1`：跳过自动打开浏览器
## 一键更新（dsh-update.cmd）

直接双击本文件运行；或先把它复制到 PATH 目录（如 `%APPDATA%\npm`），之后终端执行 `dsh-update`：
- 对比 npm 最新版与当前安装版本；
- 有新版本 → `npm install -g @deepseek-ai/dsh@<最新版>`，然后刷新 profile 插件状态；
- 无新版本 → 提示 Already up to date。

配合 `dsh-web.cmd` 的自动检查：启动器发现新版会提示，设 `DSH_AUTO_UPDATE=1` 可自动更新后再启动。