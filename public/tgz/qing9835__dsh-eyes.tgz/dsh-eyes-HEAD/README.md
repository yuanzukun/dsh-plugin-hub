# dsh-eyes 👁️

给 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 的纯文本聊天装上一双外置"眼睛"：
粘贴 / 拖入 / 导入的图片被插件拦截，交给 OpenAI 兼容视觉模型识别成文字，自动发送进对话。

<p align="center">
  <img src="demo/00-main-interface.png" alt="dsh-eyes 集成界面" width="820">
  <br>
  <em>同时上传 6 张图片，回车即可识别并自动发送进对话</em>
</p>

## 功能

- 图片拦截可开关（默认开启）：开启时拦截后显示缩略图、不进输入框，回车识别并自动发送（一次最多 9 张）
- 关闭拦截后，图片正常进入输入框、随消息直接发送给多模态模型（实时生效，选择会被记住）
- 输入框写了要求时，把【我的要求 + 识别结果】一起发给主模型
- 主模型用 `vision_ask` 工具自行判断是否追问，逐轮修正细节
- `vision_ask` 支持 `paths` 参数直读本地图片文件（PDF 渲染图、网页截图等）
- 内置 OpenCode / ModelScope 预设，也可添加任意 OpenAI 兼容模型；保存直接生效，「测试连接」为独立按钮，Key 持久化

## 安装

```sh
# npx（本机未装 DSH 也可用）
npx @deepseek-ai/dsh plugin --profile web add github:qing9835/dsh-eyes#v0.4.0

# 或本机已装 DSH
dsh plugin --profile web add github:qing9835/dsh-eyes#v0.4.0
```

装完**重启 DSH**，再**强制刷新浏览器页面**（Ctrl+Shift+R）。首次使用请在「配置」弹窗填写 API Key。

> 卸载：`dsh plugin --profile web remove dsh-vision-bridge`（包名，非仓库名）

## 适配

| 版本 | DSH |
| --- | --- |
| v0.4.0 | ≥ v0.1.2-alpha.1（新增图片拦截开关） |
| v0.3.0 | ≥ v0.1.2-alpha.1（Lexical 输入框） |
| v0.1.0 | < v0.1.2（textarea） |

数据存放于 `<DSH 进程目录>/.vision-images/`（图片、会话历史、配置/密钥）。

## 开发

- `index.js`：Host 半体（路由、`vision_ask` 工具、提示词段）
- `client.js`：浏览器 bundle（手构建，无构建链；协议见文件头注释）

MIT License
