# 更新日志

## [v0.4.2] — 2026-09-01

修复「视觉 API 返回空响应（choices 为 null）」：当 `paths` 传入的路径指向插件 `.vision-images/` 里**已保存的图片文件**时，读取到的是 dataUrl 文本，又被二次 base64 编码成无效图片，导致网关整批拒绝。现在 `dataUrlFromPath` 会自动识别并复用 dataUrl 文本；发送前还会做**图片魔数校验**（PNG/JPEG/GIF/WebP/BMP/AVIF），双重编码或非图片内容一律剔除，不再进入请求。

## [v0.4.1] — 2026-09-01

修复「回车识别」在旧版 GUI（textarea 输入框，DSH < 0.1.2-alpha.1）完全失效：回车拦截原来只认 Lexical 输入框的 `[data-composer-input]` 标记，textarea 版 GUI 里该标记不存在，导致回车从不被插件接管、图片无法自动发送。现在输入区判定同时兼容两种前端（`[data-composer-input]` / `[data-composer-card]` / `[data-input-scroll]` / `<textarea>`），新老 DSH 均可回车识别。

## [v0.4.0] — 2026-08-29

新增「开启图片拦截」配置开关（默认开启；关闭后粘贴/拖入的图片不再被插件捕获，而是正常进入输入框、随消息直接发送给多模态模型——保存后实时生效并持久化）。「保存」不再先测试连接、直接保存，「测试连接」保留为独立按钮。

## [v0.3.0] — 2026-08-29

客户端半体按官方 bundle 协议重构：factory 导出 `exports.apply` + `exports.inject: ['slots']`（修复静态版客户端槽位静默不注册）；package.json 保持 `exports["./client"]` + `dsh.client.platform: "web"` + `dsh.bundle.patch` 三件套。适配 DSH ≥ v0.1.2-alpha.1（Lexical 输入框、新版 slots 标准 kit）。

## [v0.2.x] — 2026-08-29

DSH ≥ v0.1.2-alpha.1 适配：回车拦截改 `[data-composer-input]`、读 owner 快照 `props.input.draft`、大图降采样（>4MB → 2048px JPEG）、无效/过小图过滤、`choices: null` 精确诊断。

## [v0.1.0] — 2026-08-15

首个公开版本（textarea 输入框时代）：图片拦截识别、多套 OpenAI 兼容模型预设、配置持久化。
