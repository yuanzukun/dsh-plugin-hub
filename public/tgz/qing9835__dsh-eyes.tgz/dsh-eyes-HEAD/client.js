// dsh-vision-bridge —— 静态 bundle 客户端半体（v0.4.2）
// 手构建，格式与官方 tsdown 产物完全一致：
//   window.__ModuleLoader__.load({ id, factory }) → factory(require) 返回 module.exports
// 插件导出形状 = Cordis 客户端插件：{ inject: ['slots'], apply(ctx) }。
//   inject 声明必须存在：loader 靠它让本 entry 等待 slots 服务并正确注入 ctx.slots。
// 槽位注册：ctx.slots.inject(name, () => ctx.slots.register({name, id, order}, Comp))
//   —— 与官方 ui-attachment / ui-input-trigger 完全同构。
// 运行环境：浏览器（React 来自平台模块表 require('react')；fetch/document 为原生能力）。
var module = { exports: {} }; var exports = module.exports;
window.__ModuleLoader__.load({ id: 'dsh-vision-bridge', factory: (require) => {
const React = require('react')

const MAX_IMAGES = 9
// 视觉 API 单图上限通常 5MB（5242880 字节）：4MB 触发压缩，留余量
const NORMALIZE_TRIGGER_BYTES = 4 * 1024 * 1024
const MAX_EDGE = 2048
// 无效占位图阈值：base64 过小（<512 字节 ≈ 384 字节原图）或尺寸 <8px 视为无效
// （ModelScope 会因整批中一张 1×1/极小 PNG 让整个请求返回空 choices）
const MIN_DATAURL_BYTES = 512
const MIN_EDGE_PX = 8

// 插件自有会话状态（草稿与发送动作来自标准 kit，不在此存）
const store = {
  sessions: new Map(),
  listeners: new Set(),
  configOpen: false,
  // 图片拦截开关（客户端缓存，来自 Host 配置；false = 不拦截，图片正常进入输入框）
  intercept: true,
}
function notify() {
  for (const fn of [...store.listeners]) fn()
}
function useStore() {
  const [, force] = React.useState(0)
  React.useEffect(() => {
    const fn = () => force(x => x + 1)
    store.listeners.add(fn)
    return () => store.listeners.delete(fn)
  }, [])
}
function sessionState(sid) {
  let s = store.sessions.get(sid)
  if (!s) {
    s = { images: [], busy: false, error: null }
    store.sessions.set(sid, s)
  }
  return s
}
function useVision(sid) {
  useStore()
  return sessionState(sid)
}
function isImageFile(f) {
  if (!f) return false
  if (f.type) return f.type.startsWith('image/')
  return /\.(png|jpe?g|gif|webp|bmp|avif|svg)$/i.test(f.name || '')
}
function fileToDataUrl(file) {
  return new Promise((res, rej) => {
    const r = new FileReader()
    r.onload = () => res(String(r.result))
    r.onerror = rej
    r.readAsDataURL(file)
  })
}
// 大图降采样 + 无效图过滤（与动态版验证一致的逻辑）：
//   * base64 < MIN_DATAURL_BYTES 或解码后尺寸 < MIN_EDGE_PX → resolve(null)
//   * 超过阈值 → canvas 缩到最长边 MAX_EDGE 转 JPEG（白底）
//   * 小图 / 压缩失败 → 原样返回
function normalizeImage(dataUrl) {
  return new Promise((resolve) => {
    try {
      const approxBytes = dataUrl.length * 3 / 4
      if (approxBytes < MIN_DATAURL_BYTES) {
        resolve(null)
        return
      }
      if (approxBytes <= NORMALIZE_TRIGGER_BYTES) {
        resolve(dataUrl)
        return
      }
      const img = new Image()
      img.onload = () => {
        try {
          const w0 = img.naturalWidth || 0
          const h0 = img.naturalHeight || 0
          if (w0 < MIN_EDGE_PX || h0 < MIN_EDGE_PX) {
            resolve(null)
            return
          }
          const max = Math.max(w0, h0)
          const scale = Math.min(1, MAX_EDGE / max)
          const w = Math.max(1, Math.round(w0 * scale))
          const h = Math.max(1, Math.round(h0 * scale))
          const canvas = document.createElement('canvas')
          canvas.width = w
          canvas.height = h
          const c = canvas.getContext('2d')
          c.fillStyle = '#fff'
          c.fillRect(0, 0, w, h)
          c.drawImage(img, 0, 0, w, h)
          resolve(canvas.toDataURL('image/jpeg', 0.9))
        } catch (e) {
          resolve(dataUrl)
        }
      }
      img.onerror = () => resolve(dataUrl)
      img.src = dataUrl
    } catch (e) {
      resolve(dataUrl)
    }
  })
}
// Client→Host RPC：HTTP 路由（/vision-bridge/*），JSON 信封 {ok, data|error}
function rpc(method, body) {
  return fetch('/vision-bridge/' + method, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  }).then(r => r.json()).then(envelope => {
    if (!envelope || envelope.ok !== true) {
      throw new Error((envelope && envelope.error) || 'vision-bridge: RPC 失败')
    }
    return envelope.data
  })
}
function saveToHost(sid, items) {
  const st = sessionState(sid)
  const room = MAX_IMAGES - st.images.length
  if (room <= 0) {
    st.error = '最多同时 ' + MAX_IMAGES + ' 张图片'
    notify()
    return
  }
  const batch = items.slice(0, room)
  if (batch.length === 0) return
  st.busy = true
  notify()
  rpc('save', { images: batch.map(it => ({ dataUrl: it.dataUrl, name: it.name })), sessionId: sid })
    .then(saved => {
      const byId = {}
      ;(saved.images || []).forEach((it, i) => { byId[it.id] = batch[i] })
      const existing = new Set(st.images.map(i => i.id))
      const fresh = (saved.images || []).filter(it => !existing.has(it.id))
      st.images = st.images.concat(fresh.map(it => ({
        id: it.id,
        dataUrl: (byId[it.id] && byId[it.id].dataUrl) || '',
        name: it.name,
        sent: false,
      })))
      st.busy = false
      st.error = null
      notify()
    })
    .catch(e => {
      st.busy = false
      st.error = '图片保存失败: ' + String((e && e.message) || e)
      notify()
    })
}
function addFiles(sid, files) {
  const batch = files.filter(isImageFile)
  if (batch.length === 0) {
    const st = sessionState(sid)
    st.error = '没有找到图片文件'
    notify()
    return
  }
  Promise.all(batch.map((file, i) =>
    fileToDataUrl(file)
      .then(dataUrl => ({ dataUrl, name: file.name || 'image-' + i }))
      .then(item => normalizeImage(item.dataUrl).then(dataUrl => ({ dataUrl, name: item.name })))
  ))
    .then(items => {
      const valid = items.filter(it => it && it.dataUrl)
      const skipped = items.length - valid.length
      const st = sessionState(sid)
      if (skipped > 0) {
        st.error = '已跳过 ' + skipped + ' 张无效或过小的图片（如 1×1 占位图）'
        notify()
      }
      if (valid.length > 0) saveToHost(sid, valid)
    })
    .catch(e => {
      const st = sessionState(sid)
      st.error = String((e && e.message) || e)
      notify()
    })
}
function removeImage(sid, id) {
  const st = sessionState(sid)
  st.images = st.images.filter(i => i.id !== id)
  notify()
}
function clearAll(sid) {
  const st = sessionState(sid)
  st.images = []
  st.error = null
  st.busy = false
  rpc('reset', { sessionId: sid }).catch(() => {})
  notify()
}
// 识别并发送：识别结果通过标准 inputActions.setDraft + submit 送进对话
async function runRound(sid, actions, draft) {
  const st = sessionState(sid)
  if (st.busy) return
  const fresh = st.images.filter(i => !i.sent)
  if (fresh.length === 0) {
    st.error = '请先粘贴 / 拖入 / 导入图片'
    notify()
    return
  }
  st.busy = true
  st.error = null
  notify()
  try {
    const requirement = (draft || '').trim()
    const res = await rpc('ask', {
      sessionId: sid,
      images: fresh.map(i => ({ id: i.id })),
      prompt: requirement,
    })
    st.busy = false
    st.images = []
    if (actions && res.text) {
      const text = requirement
        ? '我的要求：' + requirement + '\n\n图片识别结果：\n' + res.text
        : res.text
      actions.setDraft(text)
      actions.submit()
    }
    notify()
  } catch (e) {
    st.busy = false
    st.error = String((e && (e.message || e)) || e)
    notify()
  }
}
const ICONS = {
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>',
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
  alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
}
function Icon({ name, spin }) {
  return React.createElement('span', {
    className: 'dynv-ic' + (spin ? ' dynv-spin' : ''),
    dangerouslySetInnerHTML: { __html: ICONS[name] || '' },
  })
}
// 输入框 dock（conversation.input.dock，session 作用域）。
// 草稿直接读 owner 快照 props.input.draft（作曲家每帧传入最新 InputState）。
// 注意：标准 kit 的 useInput 是 SnapshotSelectorHook，必须传选择器（useInput(s => s.draft)），空调用会崩。
function VisionDock(props) {
  const sid = props.sessionId
  const st = useVision(sid)
  const draft = (props.input && props.input.draft) || ''
  const actions = props.inputActions
  const live = React.useRef({ draft, actions })
  live.current.draft = draft
  live.current.actions = actions
  React.useEffect(() => {
    const onPasteCapture = (e) => {
      if (!store.intercept) return
      const files = []
      if (e.clipboardData && e.clipboardData.items) {
        for (const item of e.clipboardData.items) {
          if (item.kind === 'file') {
            const f = item.getAsFile()
            if (f && isImageFile(f)) files.push(f)
          }
        }
      }
      if (files.length === 0) return
      e.preventDefault()
      e.stopPropagation()
      addFiles(sid, files)
    }
    const onDropCapture = (e) => {
      if (!store.intercept) return
      const dt = e.dataTransfer
      if (!dt) return
      const types = Array.from(dt.types || [])
      if (!types.includes('Files')) return
      const files = Array.from(dt.files || []).filter(isImageFile)
      if (files.length === 0) return
      e.preventDefault()
      e.stopPropagation()
      addFiles(sid, files)
    }
    // 回车识别：仅在输入区内且有待识别图片时接管 Enter。
    // 输入区判定兼容两种 DSH 前端：
    //   Lexical 版（DSH ≥ 0.1.2-alpha.1）：输入区带 [data-composer-input]
    //   textarea 版（旧 GUI）：composer 卡片 [data-composer-card] / 滚动区 [data-input-scroll] / <textarea>
    const onKeyCapture = (e) => {
      if (!store.intercept) return
      if (e.key !== 'Enter' || e.shiftKey || e.isComposing || e.keyCode === 229) return
      const cur = sessionState(sid)
      if (cur.busy) {
        e.preventDefault()
        e.stopPropagation()
        return
      }
      if (cur.images.length === 0) return
      const t = e.target
      if (!t || !t.closest) return
      const inComposer = t.closest('[data-composer-input]')
        || t.closest('[data-composer-card]')
        || t.closest('[data-input-scroll]')
        || t.tagName === 'TEXTAREA'
      if (!inComposer) return
      e.preventDefault()
      e.stopPropagation()
      runRound(sid, live.current.actions, live.current.draft)
    }
    document.addEventListener('paste', onPasteCapture, true)
    document.addEventListener('drop', onDropCapture, true)
    document.addEventListener('keydown', onKeyCapture, true)
    return () => {
      document.removeEventListener('paste', onPasteCapture, true)
      document.removeEventListener('drop', onDropCapture, true)
      document.removeEventListener('keydown', onKeyCapture, true)
    }
  }, [sid])

  if (st.images.length === 0 && !st.error && !st.busy) return null
  const thumbs = st.images.map(img => React.createElement('span', { key: img.id || img.name, className: 'dynv-thumb' },
    React.createElement('img', { src: img.dataUrl, alt: img.name, className: 'dynv-thumb-img', title: img.name }),
    React.createElement('button', {
      className: 'dynv-x',
      title: '移除',
      onClick: () => removeImage(sid, img.id),
    }, '×'),
  ))
  let status
  if (st.busy) {
    status = React.createElement('span', { className: 'dynv-status dynv-busy' },
      React.createElement(Icon, { name: 'refresh', spin: true }),
      '识别中…',
    )
  } else if (st.error) {
    status = React.createElement('span', { className: 'dynv-status dynv-error' },
      React.createElement(Icon, { name: 'image' }),
      st.error,
    )
  } else {
    status = React.createElement('span', { className: 'dynv-status' },
      React.createElement(Icon, { name: 'image' }),
      st.images.length + '/' + MAX_IMAGES + ' 张 · 回车识别并发送 · 复核由 AI 判断',
    )
  }
  return React.createElement('div', { className: 'dynv-dock-wrap' },
    React.createElement('div', { className: 'dynv-dock' },
      React.createElement('div', { className: 'dynv-dock-row' },
        React.createElement('div', { className: 'dynv-thumbs' }, thumbs),
        React.createElement('button', { className: 'dynv-clear', onClick: () => clearAll(sid) },
          React.createElement(Icon, { name: 'trash' }),
          '清空',
        ),
      ),
      React.createElement('div', { className: 'dynv-info' }, status),
    ),
  )
}
function ImportButton(props) {
  const sid = props.sessionId
  const fileRef = React.useRef(null)
  return React.createElement('span', { className: 'dynv-left' },
    React.createElement('button', {
      className: 'dynv-btn',
      title: '选择图片文件（可多选）',
      onClick: () => { if (fileRef.current) fileRef.current.click() },
    },
      React.createElement(Icon, { name: 'image' }),
      '导入图片',
    ),
    React.createElement('input', {
      ref: fileRef,
      type: 'file',
      accept: 'image/*',
      multiple: 'true',
      style: { display: 'none' },
      onChange: (e) => { addFiles(sid, Array.from(e.target.files || [])); e.target.value = '' },
    }),
  )
}
function ConfigButton(props) {
  return React.createElement('span', { className: 'dynv-left' },
    React.createElement('button', { className: 'dynv-btn', title: '视觉识别配置', onClick: () => { store.configOpen = !store.configOpen; notify() } },
      React.createElement(Icon, { name: 'gear' }),
      '配置',
    ),
  )
}
function ConfigDialog() {
  useStore()
  const [view, setView] = React.useState(null)
  const [form, setForm] = React.useState(null)
  const [status, setStatus] = React.useState({ phase: 'idle', text: '' })
  React.useEffect(() => {
    if (store.configOpen && view === null) {
      rpc('configGet', {})
        .then(r => {
          const cfg = (r && r.config) || {}
          const providers = (r && r.providers) || []
          const keys = (r && r.keys) || {}
          const customs = (r && r.customProviders) || []
          const matched = providers.find(p => p.baseUrl === cfg.baseUrl) || null
          const matchedCustom = customs.find(c => 'custom-' + c.id === cfg.provider) || null
          setView({ providers, keys, customs })
          setForm(matchedCustom ? {
            provider: 'custom-' + matchedCustom.id,
            label: matchedCustom.label || '自定义模型',
            baseUrl: matchedCustom.baseUrl || '',
            model: matchedCustom.model || '',
            apiKey: matchedCustom.apiKey || cfg.apiKey || '',
            systemPrompt: matchedCustom.systemPrompt || cfg.systemPrompt || '',
            interceptImages: cfg.interceptImages !== false,
          } : {
            provider: matched ? matched.id : '__new_custom__',
            label: '',
            baseUrl: cfg.baseUrl || '',
            model: cfg.model || '',
            apiKey: (matched && keys[matched.id]) || cfg.apiKey || '',
            systemPrompt: cfg.systemPrompt || '',
            interceptImages: cfg.interceptImages !== false,
          })
        })
        .catch(() => {
          setView({ providers: [], keys: {}, customs: [] })
          setForm({ provider: '__new_custom__', label: '', baseUrl: '', model: '', apiKey: '', systemPrompt: '', interceptImages: true })
        })
    }
  }, [store.configOpen, view])
  if (!store.configOpen || view === null || form === null) return null
  const close = () => {
    setView(null)
    setForm(null)
    setStatus({ phase: 'idle', text: '' })
    store.configOpen = false
    notify()
  }
  const isCustomEntry = typeof form.provider === 'string' && (form.provider === '__new_custom__' || form.provider.startsWith('custom-'))
  const current = view.providers.find(p => p.id === form.provider) || null
  const models = current ? current.models : []
  const change = (key, value) => setForm({ ...form, [key]: value })
  const pickProvider = (id) => {
    if (id === '__new_custom__') {
      setForm({ ...form, provider: '__new_custom__', label: '', baseUrl: '', model: '', apiKey: '', systemPrompt: form.systemPrompt })
      setStatus({ phase: 'idle', text: '' })
      return
    }
    const p = view.providers.find(x => x.id === id) || null
    const remembered = view.keys && view.keys[id]
    if (p) {
      setForm({
        ...form,
        provider: id,
        label: '',
        baseUrl: p.baseUrl,
        model: p.models[0],
        apiKey: remembered || form.apiKey,
      })
    } else {
      const c = view.customs.find(x => 'custom-' + x.id === id) || null
      setForm({
        ...form,
        provider: id,
        label: c ? (c.label || '自定义模型') : '',
        baseUrl: c ? c.baseUrl : form.baseUrl,
        model: c ? c.model : form.model,
        apiKey: (c && c.apiKey) || remembered || form.apiKey,
      })
    }
    setStatus({ phase: 'idle', text: '' })
  }
  const runTest = async () => {
    setStatus({ phase: 'testing', text: '正在测试连接…' })
    try {
      const res = await rpc('configValidate', { baseUrl: form.baseUrl, model: form.model, apiKey: form.apiKey })
      if (res && res.ok) setStatus({ phase: 'ok', text: res.note || '连接成功' })
      else setStatus({ phase: 'error', text: (res && res.error) || '测试失败' })
    } catch (e) {
      setStatus({ phase: 'error', text: String((e && e.message) || e) })
    }
  }
  const save = async () => {
    // 直接保存：不再先测试连接（「测试连接」按钮保留，需要时手动点）
    if (!(form.baseUrl || '').trim()) { setStatus({ phase: 'error', text: '请填写 API Base URL' }); return }
    if (!(form.model || '').trim()) { setStatus({ phase: 'error', text: '请填写模型名' }); return }
    setStatus({ phase: 'saving', text: '正在保存…' })
    try {
      const intercept = form.interceptImages !== false
      let saved
      if (isCustomEntry) {
        const cid = form.provider.startsWith('custom-') ? form.provider.slice('custom-'.length) : ''
        const entry = await rpc('customSave', {
          id: cid || undefined,
          label: (form.label || '').trim() || '自定义模型',
          baseUrl: form.baseUrl,
          model: form.model,
          apiKey: form.apiKey,
        })
        saved = await rpc('configSet', {
          provider: 'custom-' + entry.id,
          baseUrl: form.baseUrl,
          model: form.model,
          apiKey: form.apiKey,
          systemPrompt: form.systemPrompt,
          interceptImages: intercept,
        })
      } else {
        saved = await rpc('configSet', {
          provider: form.provider,
          baseUrl: form.baseUrl,
          model: form.model,
          apiKey: form.apiKey,
          systemPrompt: form.systemPrompt,
          interceptImages: intercept,
        })
      }
      store.intercept = !(saved && saved.interceptImages === false)
      notify()
      close()
    } catch (e) {
      setStatus({ phase: 'error', text: String((e && e.message) || e) })
    }
  }
  const removeCustom = async () => {
    if (!(typeof form.provider === 'string' && form.provider.startsWith('custom-'))) return
    const cid = form.provider.slice('custom-'.length)
    try {
      await rpc('customRemove', { id: cid })
      const cfg = await rpc('configGet', {})
      const customs = (cfg && cfg.customProviders) || []
      const providers = (cfg && cfg.providers) || []
      const keys = (cfg && cfg.keys) || {}
      const first = providers[0] || null
      setView({ ...view, customs })
      setForm({
        provider: first ? first.id : '__new_custom__',
        label: '',
        baseUrl: first ? first.baseUrl : '',
        model: first && first.models ? first.models[0] : '',
        apiKey: (first && keys[first.id]) || '',
        systemPrompt: form.systemPrompt,
      })
      setStatus({ phase: 'ok', text: '已删除该自定义模型' })
    } catch (e) {
      setStatus({ phase: 'error', text: String((e && e.message) || e) })
    }
  }
  const statusCls = 'dynv-dialog-status' + (status.phase === 'ok' ? ' dynv-ok' : status.phase === 'error' ? ' dynv-error' : (status.phase === 'testing' || status.phase === 'saving') ? ' dynv-busy' : '')
  const statusEl = status.phase === 'idle' ? null : React.createElement('span', { className: statusCls },
    status.phase === 'testing' ? React.createElement(Icon, { name: 'refresh', spin: true }) : status.phase === 'ok' ? React.createElement(Icon, { name: 'check' }) : React.createElement(Icon, { name: 'alert' }),
    status.text,
  )
  return React.createElement('div', { className: 'dynv-overlay' },
    React.createElement('div', { className: 'dynv-dialog' },
      React.createElement('div', { className: 'dynv-dialog-title' }, '视觉识别配置'),
      React.createElement('label', { className: 'dynv-field' },
        React.createElement('span', { className: 'dynv-field-label' }, '服务商'),
        React.createElement('select', { className: 'dynv-input', value: form.provider, onChange: (e) => pickProvider(e.target.value) },
          view.providers.map(p => React.createElement('option', { key: p.id, value: p.id }, p.label)),
          view.customs.map(c => React.createElement('option', { key: 'custom-' + c.id, value: 'custom-' + c.id }, c.label + '（自定义）')),
          React.createElement('option', { key: 'new', value: '__new_custom__' }, '＋ 新建自定义模型…'),
        ),
      ),
      isCustomEntry ? React.createElement('label', { className: 'dynv-field' },
        React.createElement('span', { className: 'dynv-field-label' }, '自定义名称'),
        React.createElement('input', {
          className: 'dynv-input',
          type: 'text',
          value: form.label || '',
          onChange: (e) => change('label', e.target.value),
          placeholder: '如：GLM-4.6V / 豆包 / Kimi',
        }),
      ) : null,
      React.createElement('label', { className: 'dynv-field' },
        React.createElement('span', { className: 'dynv-field-label' }, 'API Base URL'),
        React.createElement('input', {
          className: 'dynv-input',
          type: 'text',
          value: form.baseUrl,
          onChange: (e) => change('baseUrl', e.target.value),
          placeholder: 'https://.../v1',
        }),
      ),
      React.createElement('label', { className: 'dynv-field' },
        React.createElement('span', { className: 'dynv-field-label' }, '模型'),
        React.createElement('input', {
          className: 'dynv-input',
          type: 'text',
          value: form.model,
          list: 'dynv-model-list',
          onChange: (e) => change('model', e.target.value),
          placeholder: '可从列表选择或自行输入',
        }),
        React.createElement('datalist', { id: 'dynv-model-list' }, models.map(m => React.createElement('option', { key: m, value: m }))),
      ),
      React.createElement('label', { className: 'dynv-field' },
        React.createElement('span', { className: 'dynv-field-label' }, 'API Key'),
        React.createElement('input', {
          className: 'dynv-input',
          type: 'password',
          value: form.apiKey,
          onChange: (e) => change('apiKey', e.target.value),
          placeholder: '输入 API Key（ModelScope 可带 ms- 前缀，自动去除）',
        }),
      ),
      React.createElement('div', { className: 'dynv-note' }, current ? current.note : '自定义配置：手动填写 Base URL、模型名与 API Key，可保存为命名条目。'),
      React.createElement('label', { className: 'dynv-field dynv-check' },
        React.createElement('input', {
          type: 'checkbox',
          checked: form.interceptImages !== false,
          onChange: (e) => change('interceptImages', e.target.checked),
        }),
        React.createElement('span', { className: 'dynv-check-label' }, '开启图片拦截'),
      ),
      React.createElement('div', { className: 'dynv-note' }, '开启：粘贴/拖入的图片被本插件捕获识别，不进入输入框（纯视觉工作流）。关闭：图片正常进入输入框、随消息直接发送（适合多模态模型）。'),
      React.createElement('details', { className: 'dynv-details' },
        React.createElement('summary', null, '高级选项（系统提示词）'),
        React.createElement('textarea', { className: 'dynv-input', value: form.systemPrompt, onChange: (e) => change('systemPrompt', e.target.value) }),
      ),
      statusEl,
      React.createElement('div', { className: 'dynv-dialog-actions' },
        React.createElement('button', { className: 'dynv-btn', onClick: runTest, disabled: status.phase === 'testing' || status.phase === 'saving' }, '测试连接'),
        React.createElement('button', { className: 'dynv-btn dynv-btn-primary', onClick: save, disabled: status.phase === 'testing' || status.phase === 'saving' }, '保存'),
        typeof form.provider === 'string' && form.provider.startsWith('custom-')
          ? React.createElement('button', { className: 'dynv-btn dynv-danger', onClick: removeCustom, disabled: status.phase === 'testing' || status.phase === 'saving' }, '删除')
          : null,
        React.createElement('button', { className: 'dynv-btn', onClick: close }, '取消'),
      ),
    ),
  )
}

const CSS = `
.dynv-ic{display:inline-flex;align-items:center;justify-content:center;width:14px;height:14px;flex:none}
.dynv-ic svg{width:100%;height:100%}
.dynv-spin{animation:dynv-spin 0.9s linear infinite}
@keyframes dynv-spin{to{transform:rotate(360deg)}}
.dynv-dock-wrap{box-sizing:border-box;display:flex;justify-content:flex-start;width:calc(100% - var(--dsh-composer-side-clearance) - var(--dsh-composer-side-clearance) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset));max-width:calc(var(--dsh-composer-card-max-width) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset));margin:6px auto 0;padding:0 var(--dsh-composer-dock-inset)}
.dynv-dock{display:inline-flex;flex-direction:column;gap:6px;padding:8px 12px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:10px;color:var(--dsw-alias-label-primary);font-size:12px;box-shadow:0 1px 3px rgba(0,0,0,.08);width:fit-content;max-width:100%}
.dynv-dock-row{display:flex;align-items:center;gap:12px;min-width:0}
.dynv-thumbs{display:flex;gap:8px;align-items:center;overflow-x:auto;max-width:560px;padding:2px 0}
.dynv-thumb{position:relative;display:inline-flex;flex:none}
.dynv-thumb-img{width:42px;height:42px;object-fit:cover;border-radius:6px;border:1px solid var(--dsw-alias-border-l2);transition:transform .12s ease}
.dynv-thumb-img:hover{transform:scale(1.06)}
.dynv-x{position:absolute;top:-7px;right:-7px;width:17px;height:17px;line-height:15px;padding:0;border:none;border-radius:9px;background:var(--dsw-alias-state-error-primary);color:#fff;cursor:pointer;font-size:11px;box-shadow:0 1px 2px rgba(0,0,0,.25)}
.dynv-info{display:flex;min-width:0}
.dynv-status{display:inline-flex;align-items:center;gap:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--dsw-alias-label-secondary)}
.dynv-busy{color:var(--dsw-alias-brand-primary)}
.dynv-error{color:var(--dsw-alias-state-error-primary)}
.dynv-ok{color:var(--dsw-alias-brand-primary)}
.dynv-clear{flex:none;display:inline-flex;align-items:center;gap:4px;background:transparent;border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary);border-radius:6px;cursor:pointer;font-size:12px;padding:4px 10px;transition:background .15s,color .15s,border-color .15s}
.dynv-clear:hover{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-border-l2)}
.dynv-btn{display:inline-flex;align-items:center;gap:5px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary);border-radius:6px;cursor:pointer;font-size:12px;padding:4px 10px;line-height:18px;transition:background .15s,color .15s,border-color .15s}
.dynv-btn:hover{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-border-l2);color:var(--dsw-alias-label-primary)}
.dynv-btn:disabled{opacity:.55;cursor:default}
.dynv-btn-primary{color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary)}
.dynv-btn-primary:hover{background:var(--dsw-alias-bg-layer-2)}
.dynv-danger{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}
.dynv-danger:hover{background:var(--dsw-alias-bg-layer-2)}
.dynv-left{position:relative;display:inline-flex;align-items:center}
.dynv-overlay{position:fixed;inset:0;z-index:200;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.16);pointer-events:auto}
.dynv-dialog{width:460px;max-width:92vw;padding:14px 16px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.12);display:flex;flex-direction:column;gap:10px;color:var(--dsw-alias-label-primary);font-size:12px}
.dynv-dialog-title{font-weight:600;font-size:13px}
.dynv-field{display:flex;flex-direction:column;gap:4px}
.dynv-field-label{color:var(--dsw-alias-label-secondary);font-size:12px}
.dynv-check{flex-direction:row;align-items:center;gap:8px;cursor:pointer;margin-top:2px}
.dynv-check input{width:14px;height:14px;margin:0;accent-color:var(--dsw-alias-brand-primary);cursor:pointer;flex:none}
.dynv-check-label{color:var(--dsw-alias-label-primary);font-size:12px;user-select:none}
.dynv-input{background:var(--dsw-alias-bg-base);border:1px solid var(--dsw-alias-border-l1);border-radius:6px;color:var(--dsw-alias-label-primary);padding:6px 9px;font-size:12px;font-family:inherit;width:100%;box-sizing:border-box}
.dynv-input:focus{outline:none;border-color:var(--dsw-alias-brand-primary)}
.dynv-note{color:var(--dsw-alias-label-secondary);font-size:11px;line-height:1.5}
.dynv-dialog-status{display:inline-flex;align-items:center;gap:6px;min-height:18px;color:var(--dsw-alias-label-secondary)}
.dynv-dialog-actions{display:flex;gap:8px;justify-content:flex-end}
.dynv-details summary{cursor:pointer;color:var(--dsw-alias-label-secondary);font-size:12px;user-select:none}
.dynv-details textarea{min-height:56px;resize:vertical}
`

// 标准 Cordis 客户端插件形状：inject + apply（官方同构）
const inject = ['slots']

function apply(ctx) {
  // CSS 注入（官方 bundle 由 tsdown 内联，手构建自行管理）
  if (typeof document !== 'undefined' && document.querySelector('style[data-plugin-css="dsh-vision-bridge/styles"]') === null) {
    const tag = document.createElement('style')
    tag.dataset.plugin = 'dsh-vision-bridge'
    tag.dataset.pluginCss = 'dsh-vision-bridge/styles'
    tag.textContent = CSS
    document.head.appendChild(tag)
  }
  // 预载配置：图片拦截开关（粘贴/拖入/回车按最新配置实时判定；保存后即时生效）
  rpc('configGet', {}).then(r => {
    const cfg = (r && r.config) || {}
    store.intercept = cfg.interceptImages !== false
    notify()
  }).catch(() => {})
  const slots = ctx.slots
  slots.inject('conversation.input.left', () => slots.register(
    { name: 'conversation.input.left', id: 'vision-import', order: 5 },
    ImportButton,
  ))
  slots.inject('conversation.input.left', () => slots.register(
    { name: 'conversation.input.left', id: 'vision-config', order: 6 },
    ConfigButton,
  ))
  slots.inject('conversation.input.dock', () => slots.register(
    { name: 'conversation.input.dock', id: 'vision-dock', order: 15 },
    VisionDock,
  ))
  slots.inject('shell.overlay', () => slots.register(
    { name: 'shell.overlay', id: 'vision-config-dialog' },
    ConfigDialog,
  ))
}

exports.apply = apply
exports.inject = inject
return module.exports; } });
