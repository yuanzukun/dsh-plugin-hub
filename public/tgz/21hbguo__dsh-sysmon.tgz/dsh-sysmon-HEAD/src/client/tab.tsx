/**
 * @dsh-external/dsh-sysmon — sidebar-right 性能 tab 的 body 组件。
 *
 * 官方 pane 提供标题栏/关闭/拖拽/分栏/浮出；本组件只承载 {@link SysmonView}
 * 内容视图：插件 enabled 开关决定挂载或显示提示，tab.visible 经
 * {@link SysmonView.setActive} 暂停/恢复轮询。
 * @module @dsh-external/dsh-sysmon/client/tab
 */

import { useEffect, useRef, useState, type ReactNode } from 'react'
import type { TranslateNS } from '@deepseek-ai/dsh-client-locale/client'
import type { UseSidebarRightTabInfo } from '@deepseek-ai/dsh-client-ui-sidebar-right/client'
import { SysmonView } from './view.js'

/** The sysmon tab body's props: the framework-bound tab information hook. */
export interface SysmonTabProps {
  useTabInfo: UseSidebarRightTabInfo
}

/** Bind the plugin-scoped dependencies into the tab body component. */
export function makeSysmonTab(opts: {
  /** Current enabled state from the settings scope. */
  enabled: () => boolean
  /** Subscribe to settings-scope changes; returns unsubscribe. */
  subscribe: (fn: () => void) => () => void
  /** Namespace-bound translate for the disabled hint. */
  t: TranslateNS<'sysmon'>
}): (props: SysmonTabProps) => ReactNode {
  const { enabled, subscribe, t } = opts
  return function SysmonTab({ useTabInfo }: SysmonTabProps): ReactNode {
    const { tab } = useTabInfo()
    const hostRef = useRef<HTMLDivElement>(null)
    const viewRef = useRef<SysmonView | null>(null)
    const [on, setOn] = useState(enabled)

    useEffect(() => subscribe(() => setOn(enabled())), [subscribe])

    useEffect(() => {
      if (!on) return
      const host = hostRef.current
      if (host === null) return
      const view = new SysmonView()
      viewRef.current = view
      host.appendChild(view.bodyEl)
      view.mount()
      view.setActive(tab.visible)
      return () => {
        viewRef.current = null
        view.dispose()
      }
    }, [on])

    useEffect(() => {
      viewRef.current?.setActive(tab.visible)
    }, [tab.visible])

    return (
      <div ref={hostRef} className="sysmon-tab-host">
        {on ? null : <span className="sysmon-tab-hint">{t('tab.disabled')}</span>}
      </div>
    )
  }
}
