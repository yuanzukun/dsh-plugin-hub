/**
 * @dsh-external/dsh-sysmon — 浏览器半区：sidebar-right 性能 tab + 设置卡片。
 *
 * The performance surface is a sidebar-right tab type ('sysmon'): the body
 * registers under the type id on the keyed `sidebar.right.pane.tab` seat and
 * hosts the {@link SysmonView} content view; the official dockkit owns the
 * container, title chip, close, drag, split and float. A guide entry opens
 * the tab from the right bar's guide page. Plus a small
 * `settings.plugin.item` card in the plugin-configuration section.
 *
 * Failure policy: DOM/transport problems are logged and swallowed, never
 * thrown — the web shell fails the whole boot when a plugin apply throws.
 * @module @dsh-external/dsh-sysmon/client
 */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
// Type-only: pulls the slots SlotMap merge table for the settings card seat.
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the settings-surface Context merge (ctx.settingsScope).
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
// Type-only: pulls the sidebar-right Context merge (ctx.sidebarRightTabs).
import type {} from '@deepseek-ai/dsh-client-ui-sidebar-right/client'
import { SysmonSettingsCard, SysmonSettingsCardController, type SysmonSettings } from './SysmonSettingsCard.js'
import { makeSysmonTab } from './tab.js'
import { zh, en, type SysmonLocaleKey } from './locales.js'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** sysmon settings-card copy. */
    'sysmon': SysmonLocaleKey
  }

  interface SlotMap {
    /** The official plugin-card seat this package registers into. */
    'settings.plugin.item': { kind: 'keyed'; scope: 'root'; owner: SysmonCardOwnerProps }
  }
}

/** Owner share of the sysmon card (the section supplies nothing). */
export interface SysmonCardOwnerProps {
  /** Marker field: card owner props are intentionally empty. */
  children?: never
}

/** The tab type's implementation id — the key its body registers under. */
const SYSMON_TAB_ID = '@dsh-external/dsh-sysmon/tab'

/** Required services: slots + settingsScope + locale + sidebarRightTabs. */
export const inject = ['slots', 'settingsScope', 'locale', 'connection', 'sidebarRightTabs']

/** Dictionary namespace owned by this package. */
const NS = 'sysmon'

/** Settings namespace the sysmon settings card edits (the Host plugin registers it). */
const SYSMON_NS = 'sysmon'

/**
 * Client plugin body: register the settings card and the sidebar-right
 * performance tab type.
 * @param ctx - client root context (slots + settingsScope + sidebarRightTabs + cordis base).
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'sysmon: dictionaries')
  const t = ctx.locale.bind(NS)

  const settingsScope = ctx.settingsScope.bind<SysmonSettings>({ namespace: SYSMON_NS })
  const enabled = (): boolean => {
    const snapshot = settingsScope.getSnapshot()
    return snapshot.status === 'ready'
      ? snapshot.value?.enabled ?? true
      : snapshot.status === 'unavailable'
  }

  // Plugin configuration card: one staged form over the `sysmon` settings
  // namespace, contributed to the plugin-configuration section.
  const sysmonSettings = new SysmonSettingsCardController(settingsScope)
  ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
    name: 'settings.plugin.item',
    key: 'sysmon',
    locale: NS,
    inject: () => sysmonSettings.inject(),
  }, SysmonSettingsCard))

  // Stage one: the tab type. The guide entry opens it from the right bar's
  // guide page — no sidebar button needed.
  const disposeType = ctx.sidebarRightTabs.register({
    id: SYSMON_TAB_ID,
    kind: 'sysmon',
    title: () => t('tab.title'),
    guide: [{
      order: 60,
      title: () => t('guide.title'),
      description: () => t('guide.description'),
    }],
  })
  // Stage two: the body on the keyed pane seat, after the seat is declared.
  const disposeBody = ctx.slots.inject('sidebar.right.pane.tab', () => ctx.slots.register({
    name: 'sidebar.right.pane.tab',
    key: SYSMON_TAB_ID,
    locale: NS,
  }, makeSysmonTab({
    enabled,
    subscribe: (fn) => settingsScope.subscribe(fn),
    t,
  })))
  ctx.effect(() => () => {
    disposeBody()
    disposeType()
  }, 'sysmon: sidebar-right tab')
}
