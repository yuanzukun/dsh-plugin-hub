/**
 * @dsh-external/dsh-sysmon — 内容视图（sidebar-right pane 承载）。
 *
 * 从原小悬浮窗抽出的纯内容半区：只渲染指标行 + 底部负载/运行时长行 +
 * 进程网络 TOP10 tooltip 与 2s 轮询。容器、标题栏、拖拽、关闭、折叠、
 * 召回按钮与位置持久化全部由官方 dockkit pane/tab 接管；tab.visible
 * 经 {@link SysmonView.setActive} 暂停轮询。
 * @module @dsh-external/dsh-sysmon/client/view
 */

import type { SysmonSnapshot } from '../types.js'

/** One rendered metric row: label, value text, percent bar (0-100 or null). */
interface MetricRow {
  /** Group heading this row belongs under (计算 / 存储 / 网络). */
  group: string
  label: string
  value: string
  percent: number | null
  /** Hover tooltip explaining the row's numbers (optional). */
  title?: string
  /** Fixed bar color (overrides the percent-based color); used to tell the
   *  network direction bars apart at a glance (下载蓝 / 上传橙). */
  barColor?: string
  /** Marks the download/upload rate rows: hovering them shows the per-process
   *  TOP10 network tooltip for the given direction. */
  netDir?: 'down' | 'up'
}

/** Poll interval (ms) while the tab is visible. */
const POLL_MS = 2000

/** Decay factor per poll tick for the network-bar scale (bytes/s): the scale
 *  snaps up to the current peak instantly and decays slowly, so the rate bars
 *  stay proportional to the *recent* peak instead of a fixed cap. */
const NET_SCALE_DECAY = 0.9

/** View styles, injected once into <head>. */
const VIEW_CSS = `
.sysmon-view {
  font: 12px/1.6 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  color: #e6e6e6;
  background: rgba(17, 17, 20, 0.82);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 8px;
  padding: 8px 10px;
  margin: 8px;
  user-select: none;
  cursor: default;
}
.sysmon-group {
  font-size: 10px;
  font-weight: 600;
  color: #7d8790;
  letter-spacing: 0.04em;
  padding: 3px 0 1px;
  margin-top: 2px;
}
.sysmon-group:first-child { margin-top: 0; padding-top: 0; }
.sysmon-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 1px 0;
  white-space: nowrap;
}
.sysmon-row-label {
  flex: none;
  width: 44px;
  overflow: hidden;
  text-overflow: ellipsis;
  color: #9ba1a6;
}
.sysmon-row-value {
  flex: none;
  color: #f0f0f0;
  width: 92px;
  text-align: right;
  overflow: hidden;
  text-overflow: ellipsis;
}
.sysmon-bar-wrap {
  flex: none;
  width: 64px;
  height: 6px;
  border-radius: 3px;
  background: rgba(255, 255, 255, 0.1);
  overflow: hidden;
  display: block;
}
.sysmon-bar {
  display: block;
  height: 100%;
  border-radius: 3px;
  transition: width 0.4s ease;
}
.sysmon-foot {
  margin-top: 4px;
  padding-top: 4px;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  font-size: 11px;
  color: #9ad0ff;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.sysmon-tooltip {
  position: fixed;
  z-index: 2147483647;
  font: 11px/1.6 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  color: #e6e6e6;
  background: rgba(17, 17, 20, 0.95);
  border: 1px solid rgba(255, 255, 255, 0.14);
  border-radius: 8px;
  padding: 6px 8px;
  min-width: 210px;
  max-width: 280px;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.45);
  pointer-events: none;
  white-space: nowrap;
}
.sysmon-tooltip-header {
  font-size: 10px;
  font-weight: 600;
  color: #7d8790;
  letter-spacing: 0.04em;
  padding-bottom: 3px;
  margin-bottom: 3px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}
.sysmon-tooltip-row {
  display: flex;
  align-items: baseline;
  gap: 8px;
}
.sysmon-tooltip-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  color: #9ba1a6;
}
.sysmon-tooltip-rate {
  width: 66px;
  text-align: right;
  flex: none;
}
.sysmon-tooltip-rx { color: #4f8cff; }
.sysmon-tooltip-tx { color: #f5a524; }
.sysmon-tooltip-conns { color: #9ad0ff; }
.sysmon-tooltip-empty {
  color: #7d8790;
  padding: 2px 0;
}
.sysmon-tab-host { display: contents; }
.sysmon-tab-hint {
  display: block;
  margin: 8px;
  padding: 8px 10px;
  font-size: 12px;
  color: #9ba1a6;
}
`

/** Inject the view styles once. */
function ensureStyles(): void {
  if (document.getElementById('dsh-sysmon-style') !== null) return
  const style = document.createElement('style')
  style.id = 'dsh-sysmon-style'
  style.textContent = VIEW_CSS
  document.head.appendChild(style)
}

/** Format a byte count compactly (B / KB / MB / GB). */
function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let value = bytes
  let unit = 0
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024
    unit += 1
  }
  return `${value >= 100 ? Math.round(value) : Math.round(value * 10) / 10} ${units[unit]}`
}

/** Compact byte format for narrow rows: `7.8G`, `412G`, `1.8T`. */
function formatBytesShort(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0B'
  const units = ['B', 'K', 'M', 'G', 'T']
  let value = bytes
  let unit = 0
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024
    unit += 1
  }
  return `${value >= 100 ? Math.round(value) : Math.round(value * 10) / 10}${units[unit]}`
}

/** Format a rate per second. */
function formatRate(bytesPerSec: number | null): string {
  if (bytesPerSec === null) return '--'
  return `${formatBytes(bytesPerSec)}/s`
}

/** Network bar percent: current rate relative to the view's decaying peak
 *  scale, clamped to 0-100 (null when the rate or the scale is unavailable). */
function ratePercent(rate: number | null, scale: number): number | null {
  if (rate === null || scale <= 0) return null
  return Math.round(Math.min(100, Math.max(0, (rate / scale) * 100)) * 10) / 10
}

/** Format seconds as d h m. */
function formatUptime(seconds: number): string {
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const mins = Math.floor((seconds % 3600) / 60)
  if (days > 0) return `${days}d ${hours}h`
  if (hours > 0) return `${hours}h ${mins}m`
  return `${mins}m`
}

/** Build the metric rows for one snapshot. `netScale` (bytes/s) drives the
 *  network rate bars — see {@link NET_SCALE_DECAY}. */
function rowsOf(s: SysmonSnapshot, netScale: number): MetricRow[] {
  const cpu: MetricRow = {
    group: '计算',
    label: 'CPU',
    value: s.cpu === null ? '--' : `${s.cpu}%`,
    percent: s.cpu,
    title: 'CPU 使用率（近 2 秒均值）',
  }
  const mem: MetricRow = {
    group: '计算',
    label: 'MEM',
    value: `${formatBytesShort(s.mem.used)}/${formatBytesShort(s.mem.total)}`,
    percent: s.memPercent,
    title: `内存使用率 ${s.memPercent}% · 已用 ${formatBytes(s.mem.used)} / 共 ${formatBytes(s.mem.total)}`,
  }
  // One row per physical disk mount (root first, then by used bytes).
  const disks: MetricRow[] = s.disks.length === 0
    ? [{ group: '存储', label: 'DSK', value: '--', percent: null, title: '磁盘信息不可用' }]
    : s.disks.map((d) => ({
        group: '存储',
        label: d.mount,
        value: `${formatBytesShort(d.used)}/${formatBytesShort(d.total)}`,
        percent: d.percent,
        title: `${d.mount} 使用率 ${d.percent}% · 已用 ${formatBytes(d.used)} / 共 ${formatBytes(d.total)}`,
      }))
  // Download / upload as two separate rate rows, each with its own bar
  // (percent = rate / recent-peak scale; color tells the direction apart).
  const down: MetricRow = {
    group: '网络',
    label: '↓下载',
    value: formatRate(s.netRxRate),
    percent: ratePercent(s.netRxRate, netScale),
    barColor: '#4f8cff',
    netDir: 'down',
    title: `下行速率（接收）${formatRate(s.netRxRate)}`,
  }
  const up: MetricRow = {
    group: '网络',
    label: '↑上传',
    value: formatRate(s.netTxRate),
    percent: ratePercent(s.netTxRate, netScale),
    barColor: '#f5a524',
    netDir: 'up',
    title: `上行速率（发送）${formatRate(s.netTxRate)}`,
  }
  const gpu: MetricRow | null = s.gpuPercent === null && s.gpuMem === null
    ? null
    : {
        group: '计算',
        label: 'GPU',
        value: s.gpuPercent === null
          ? `VRAM ${formatBytesShort(s.gpuMem?.used ?? 0)}/${formatBytesShort(s.gpuMem?.total ?? 0)}`
          : s.gpuMem === null ? '--' : `${formatBytesShort(s.gpuMem.used)}/${formatBytesShort(s.gpuMem.total)}`,
        percent: s.gpuPercent,
        title: s.gpuPercent === null
          ? `显存 已用 ${s.gpuMem === null ? '--' : formatBytes(s.gpuMem.used)} / 共 ${s.gpuMem === null ? '--' : formatBytes(s.gpuMem.total)}`
          : `GPU 使用率 ${s.gpuPercent}% · 显存 已用 ${s.gpuMem === null ? '--' : formatBytes(s.gpuMem.used)} / 共 ${s.gpuMem === null ? '--' : formatBytes(s.gpuMem.total)}`,
      }
  // 分组顺序：计算 → 存储 → 网络；每组内部保持原相对顺序。
  const groups: MetricRow[] = []
  for (const row of [cpu, gpu, mem, ...disks, down, up]) {
    if (row === null) continue
    groups.push(row)
  }
  return groups
}

/** The content view — owns its DOM subtree and the poll timer. */
export class SysmonView {
  /** 内容视图根：挂进官方 pane 的宿主 div（无定位、无自带标题栏）。 */
  readonly bodyEl: HTMLDivElement
  private readonly rowsEl: HTMLDivElement
  private readonly footEl: HTMLDivElement
  private timer: number | undefined
  /** True while a snapshot fetch is in flight (skips overlapping polls). */
  private fetching = false
  /** Whether the owning tab is visible; false pauses the poll interval. */
  private active = true
  private visibilityCleanup: (() => void) | null = null
  /** Decaying network-rate scale (bytes/s) the rate bars are drawn against. */
  private netScale = 0
  /** Last rendered snapshot (drives the per-process TOP10 hover tooltip). */
  private lastSnapshot: SysmonSnapshot | null = null
  /** Network direction row currently hovered (null = tooltip hidden). */
  private hoveredNet: 'down' | 'up' | null = null
  private tooltipEl: HTMLDivElement | null = null

  constructor() {
    this.rowsEl = document.createElement('div')
    this.rowsEl.className = 'sysmon-rows'

    this.footEl = document.createElement('div')
    this.footEl.className = 'sysmon-foot'
    this.footEl.title = '负载（1/5/15 分钟均值）· 系统运行时长'

    this.bodyEl = document.createElement('div')
    this.bodyEl.className = 'sysmon-view'
    this.bodyEl.appendChild(this.rowsEl)
    this.bodyEl.appendChild(this.footEl)
  }

  /** Start polling (respecting active + document visibility). */
  mount(): void {
    ensureStyles()
    this.poll()
    this.start()
  }

  /** Remove from the DOM and stop the timer. */
  dispose(): void {
    this.stop()
    this.hideNetTooltip()
    this.bodyEl.remove()
  }

  /** Pause/resume polling with the owning tab's visibility. */
  setActive(active: boolean): void {
    if (this.active === active) return
    this.active = active
    if (active) this.resume()
    else this.pause()
  }

  /** One poll cycle: fetch the snapshot and render (skips inactive/overlapping). */
  private poll(): void {
    if (!this.active || this.fetching) return
    this.fetching = true
    void fetch('/api/sysmon/snapshot', { cache: 'no-store', signal: AbortSignal.timeout(8000) })
      .then((res) => {
        if (!res.ok) throw new Error(`snapshot ${res.status}`)
        return res.json() as Promise<SysmonSnapshot>
      }).then((snapshot) => {
        this.render(snapshot)
      }).catch((error: unknown) => {
        // A timeout (host busy) keeps the last rendered frame; transport
        // errors (host restarting, route not yet registered) show the offline
        // placeholder and retry on the next tick.
        if (error instanceof DOMException && error.name === 'AbortError') return
        this.renderOffline()
        console.warn('[sysmon] snapshot fetch failed:', error)
      }).finally(() => {
        this.fetching = false
      })
  }

  /** Render a live snapshot into the rows, grouped with headings. */
  private render(s: SysmonSnapshot): void {
    // Update the network-bar scale: snap up to this tick's peak, decay slowly
    // so the bars shrink as traffic drops (relative-to-recent-peak display).
    const peak = Math.max(s.netRxRate ?? 0, s.netTxRate ?? 0)
    this.netScale = Math.max(peak, this.netScale * NET_SCALE_DECAY)
    this.lastSnapshot = s
    const rows = rowsOf(s, this.netScale)
    this.rowsEl.textContent = ''
    let lastGroup: string | undefined
    for (const row of rows) {
      if (row.group !== lastGroup) {
        const heading = document.createElement('div')
        heading.className = 'sysmon-group'
        heading.textContent = row.group
        this.rowsEl.appendChild(heading)
        lastGroup = row.group
      }
      this.rowsEl.appendChild(this.rowEl(row))
    }

    // Footer line carries load averages + uptime; hover explains the numbers.
    const loadText = s.load.map((v) => (Number.isFinite(v) ? Math.round(v * 100) / 100 : 0)).join(' / ')
    this.footEl.textContent = `负载 ${loadText} · 运行 ${formatUptime(s.uptime)}`

    // The rows were just rebuilt — re-anchor a still-open TOP10 tooltip.
    this.refreshNetTooltip()
  }

  /** Render the offline placeholder (keeps the view alive across restarts). */
  private renderOffline(): void {
    this.rowsEl.textContent = ''
    const row = document.createElement('div')
    row.className = 'sysmon-row'
    const label = document.createElement('span')
    label.className = 'sysmon-row-label'
    label.textContent = '--'
    const value = document.createElement('span')
    value.className = 'sysmon-row-value'
    value.textContent = 'offline'
    row.appendChild(label)
    row.appendChild(value)
    this.rowsEl.appendChild(row)
  }

  /** Build one metric row DOM node. */
  private rowEl(row: MetricRow): HTMLElement {
    const line = document.createElement('div')
    line.className = 'sysmon-row'

    const label = document.createElement('span')
    label.className = 'sysmon-row-label'
    label.textContent = row.label

    const value = document.createElement('span')
    value.className = 'sysmon-row-value'
    value.textContent = row.value
    if (row.title !== undefined) value.title = row.title
    if (row.value === '') value.style.display = 'none'

    const barWrap = document.createElement('span')
    barWrap.className = 'sysmon-bar-wrap'
    if (row.percent !== null) {
      const bar = document.createElement('span')
      bar.className = 'sysmon-bar'
      const pct = Math.max(0, Math.min(100, row.percent))
      bar.style.width = `${pct}%`
      bar.style.background = row.barColor ?? (pct >= 90 ? '#e5484d' : pct >= 70 ? '#f5a524' : '#30a46c')
      barWrap.appendChild(bar)
    }

    line.appendChild(label)
    line.appendChild(value)
    line.appendChild(barWrap)

    // Network rate rows get the per-process TOP10 hover tooltip.
    if (row.netDir !== undefined) {
      line.classList.add(`sysmon-row-net-${row.netDir}`)
      line.addEventListener('mouseenter', () => {
        this.hoveredNet = row.netDir!
        this.showNetTooltip()
      })
      line.addEventListener('mouseleave', () => {
        this.hoveredNet = null
        this.hideNetTooltip()
      })
    }
    return line
  }

  /** Show the per-process TOP10 tooltip anchored to the hovered rate row. */
  private showNetTooltip(): void {
    if (this.tooltipEl !== null) return
    const el = document.createElement('div')
    el.className = 'sysmon-tooltip'
    document.body.appendChild(el)
    this.tooltipEl = el
    this.refreshNetTooltip()
  }

  /** Remove the TOP10 tooltip (if open). */
  private hideNetTooltip(): void {
    if (this.tooltipEl !== null) {
      this.tooltipEl.remove()
      this.tooltipEl = null
    }
  }

  /** Rebuild + reposition the open TOP10 tooltip from the latest snapshot. */
  private refreshNetTooltip(): void {
    if (this.hoveredNet === null || this.tooltipEl === null) return
    const el = this.tooltipEl
    el.textContent = ''

    const s = this.lastSnapshot
    const mode = s?.netTopMode ?? 'rate'
    const header = document.createElement('div')
    header.className = 'sysmon-tooltip-header'
    if (mode === 'rate') {
      header.textContent = this.hoveredNet === 'down' ? '进程网络 TOP10 · 下行 ↓' : '进程网络 TOP10 · 上行 ↑'
      header.title = '近 3s 均值 · 仅 TCP · 同用户进程（ss -tinp 采样）'
    } else {
      header.textContent = '进程网络 TOP10 · 活跃连接'
      header.title = '本机 ss 无字节计数 · 按活跃 TCP 连接数排序 · 同用户进程'
    }
    el.appendChild(header)

    const top = s?.netTop ?? []
    if (top.length === 0) {
      const empty = document.createElement('div')
      empty.className = 'sysmon-tooltip-empty'
      empty.textContent = mode === 'rate' ? '暂无进程流量（空闲或数据不足）' : '暂无可见 TCP 连接'
      el.appendChild(empty)
    } else if (mode === 'rate') {
      const dir = this.hoveredNet
      for (const p of top) {
        const row = document.createElement('div')
        row.className = 'sysmon-tooltip-row'
        const name = document.createElement('span')
        name.className = 'sysmon-tooltip-name'
        name.textContent = p.name
        name.title = `pid ${p.pid} · 连接 ${p.conns} · 队列 ${formatBytes(p.queue)}`
        const rx = document.createElement('span')
        rx.className = 'sysmon-tooltip-rate sysmon-tooltip-rx'
        rx.textContent = `↓${formatBytesShort(p.rxRate)}/s`
        const tx = document.createElement('span')
        tx.className = 'sysmon-tooltip-rate sysmon-tooltip-tx'
        tx.textContent = `↑${formatBytesShort(p.txRate)}/s`
        // Emphasize the hovered direction's rate.
        if (dir === 'down') rx.style.fontWeight = '700'
        else tx.style.fontWeight = '700'
        row.appendChild(name)
        row.appendChild(rx)
        row.appendChild(tx)
        el.appendChild(row)
      }
    } else {
      // Connections mode: rank by active sockets, show the connection count.
      for (const p of top) {
        const row = document.createElement('div')
        row.className = 'sysmon-tooltip-row'
        const name = document.createElement('span')
        name.className = 'sysmon-tooltip-name'
        name.textContent = p.name
        name.title = `pid ${p.pid} · 队列 ${formatBytes(p.queue)}`
        const conns = document.createElement('span')
        conns.className = 'sysmon-tooltip-rate sysmon-tooltip-conns'
        conns.textContent = `${p.conns} 连接`
        row.appendChild(name)
        row.appendChild(conns)
        el.appendChild(row)
      }
    }
    this.positionNetTooltip()
  }

  /** Anchor the tooltip just left of the hovered rate row (clamped to viewport). */
  private positionNetTooltip(): void {
    const el = this.tooltipEl
    if (el === null || this.hoveredNet === null) return
    const anchor = this.rowsEl.querySelector<HTMLElement>(`.sysmon-row-net-${this.hoveredNet}`)
    if (anchor === null) return
    const rect = anchor.getBoundingClientRect()
    const tw = el.offsetWidth
    const th = el.offsetHeight
    let left = rect.left - tw - 8
    if (left < 8) left = Math.min(rect.right + 8, Math.max(8, window.innerWidth - tw - 8))
    const top = Math.max(8, Math.min(rect.top, window.innerHeight - th - 8))
    el.style.left = `${Math.round(left)}px`
    el.style.top = `${Math.round(top)}px`
  }

  /** Attach the visibility listener and start the interval when appropriate. */
  private start(): void {
    const onVisibility = (): void => {
      if (document.visibilityState === 'visible') this.resume()
      else this.pause()
    }
    document.addEventListener('visibilitychange', onVisibility)
    onVisibility()
    this.visibilityCleanup = () => document.removeEventListener('visibilitychange', onVisibility)
  }

  /** Start the interval if the view is active and the document is visible. */
  private resume(): void {
    if (this.timer !== undefined || !this.active) return
    if (document.visibilityState !== 'visible') return
    this.timer = window.setInterval(() => this.poll(), POLL_MS)
  }

  /** Clear the poll interval. */
  private pause(): void {
    if (this.timer !== undefined) {
      window.clearInterval(this.timer)
      this.timer = undefined
    }
  }

  /** Stop the poll interval and detach the visibility listener. */
  private stop(): void {
    this.pause()
    if (this.visibilityCleanup !== null) {
      this.visibilityCleanup()
      this.visibilityCleanup = null
    }
  }
}
