#!/usr/bin/env node
// Synthesises docs/promo/score.wav (28.6 s, 48 kHz stereo) with no dependencies.
import { writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const out = resolve(here, '..', 'score.wav');
const SR = 48000;
const DUR = 28.6;
const N = Math.round(SR * DUR);
const left = new Float32Array(N);
const right = new Float32Array(N);

let seed = 0x9e3779b9;
function noise() {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return ((seed >>> 8) / 0xffffff) * 2 - 1;
}

function mix(i, l, r) {
  if (i < 0 || i >= N) return;
  left[i] += l;
  right[i] += r;
}

function burst(t0, dur, amp, pan, nz, freq, decay) {
  const start = Math.floor(t0 * SR);
  const count = Math.floor(dur * SR);
  for (let n = 0; n < count; n++) {
    const dt = n / SR;
    const env = Math.exp(-dt / decay);
    const v = (Math.sin(2 * Math.PI * freq * dt) + noise() * nz) * env * amp;
    mix(start + n, v * (1 - pan), v * pan);
  }
}

function swoosh(t0, dur, f0, f1, amp) {
  const start = Math.floor(t0 * SR);
  const count = Math.floor(dur * SR);
  let phase = 0;
  for (let n = 0; n < count; n++) {
    const p = n / count;
    phase += (2 * Math.PI * (f0 + (f1 - f0) * p)) / SR;
    const v = Math.sin(phase) * Math.sin(p * Math.PI) * amp;
    mix(start + n, v * 0.6, v * 0.4);
  }
}

// Pad: four slow sines with independent tremolo.
const notes = [196, 247, 294, 98];
const amps = [0.055, 0.045, 0.036, 0.062];
const trem = [0.12, 0.11, 0.13, 0.1];
for (let i = 0; i < N; i++) {
  const t = i / SR;
  let l = 0, r = 0;
  for (let k = 0; k < 4; k++) {
    const v = Math.sin(2 * Math.PI * notes[k] * t) * (1 + 0.5 * Math.sin(2 * Math.PI * trem[k] * t)) * amps[k];
    if (k === 0) l += v; else if (k === 1) r += v; else { l += v * 0.7; r += v * 0.7; }
  }
  left[i] += l;
  right[i] += r;
}

// Typing clicks (same cadence as the picture).
const first = '帮我把这个接口重构一下，再补上测试'.length;
const second = '第一，接口先拆开，再补上测试'.length;
for (let i = 0; i < first; i++) burst(3.45 + i * 0.105, 0.035, 0.055, 0.62, 2.4, 2100, 0.006);
for (let i = 0; i < second; i++) burst(6.65 + i * 0.115, 0.035, 0.05, 0.62, 2.4, 2100, 0.006);

// Key thocks, send whooshes, cancel sweep, tap tick.
for (const t of [5.5, 8.0]) burst(t, 0.16, 0.11, 0.45, 0.8, 118, 0.035);
swoosh(10.62, 0.3, 300, 900, 0.09);
swoosh(15.68, 0.28, 340, 980, 0.09);
swoosh(12.42, 0.24, 520, 180, 0.07);
burst(17.0, 0.09, 0.06, 0.5, 1.4, 1400, 0.012);

// Outro chime.
burst(24.05, 1.5, 0.07, 0.36, 0, 523.25, 0.5);
burst(24.05, 1.4, 0.05, 0.64, 0, 783.99, 0.45);
burst(24.32, 1.1, 0.035, 0.5, 0, 1046.5, 0.35);

// Fades, limiter, normalise.
const fadeIn = Math.floor(2.6 * SR);
const fadeOutStart = Math.floor(25.8 * SR);
let peak = 0;
for (let i = 0; i < N; i++) {
  const gIn = i < fadeIn ? i / fadeIn : 1;
  const gOut = i >= fadeOutStart ? 1 - Math.pow((i - fadeOutStart) / (N - fadeOutStart), 0.8) : 1;
  left[i] *= gIn * gOut;
  right[i] *= gIn * gOut;
  peak = Math.max(peak, Math.abs(left[i]), Math.abs(right[i]));
}
const gain = peak > 0.001 ? 0.86 / peak : 1;

const data = Buffer.alloc(N * 4);
for (let i = 0; i < N; i++) {
  const l = Math.tanh(left[i] * gain) * 0.95;
  const r = Math.tanh(right[i] * gain) * 0.95;
  data.writeInt16LE(Math.round(l * 32767), i * 4);
  data.writeInt16LE(Math.round(r * 32767), i * 4 + 2);
}
const header = Buffer.alloc(44);
header.write('RIFF', 0);
header.writeUInt32LE(36 + data.length, 4);
header.write('WAVEfmt ', 8);
header.writeUInt32LE(16, 16);
header.writeUInt16LE(1, 20);
header.writeUInt16LE(2, 22);
header.writeUInt32LE(SR, 24);
header.writeUInt32LE(SR * 4, 28);
header.writeUInt16LE(4, 32);
header.writeUInt16LE(16, 34);
header.write('data', 36);
header.writeUInt32LE(data.length, 40);
writeFileSync(out, Buffer.concat([header, data]));
console.log(`score: ${out}`);
