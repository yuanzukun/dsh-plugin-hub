# Promo video

`hold-on-promo.mp4` — 28.6 seconds, 1920×1080, 30 fps. Animated typing, a stray `Enter`,
a mistaken newline, hold-to-send on the keyboard and the button, hold-to-stop, and the
plugin's page inside the DSH Settings dialog.

The animation is a web page. [`web/index.html`](web/index.html) draws every frame on a
1080p canvas with the 2D API; open it in a browser to watch the loop live. To record it,
[`web/render.mjs`](web/render.mjs) launches headless Edge (or Chrome), seeks the page to
each frame over the DevTools protocol, captures a JPEG screenshot, and hands the sequence
to ffmpeg — H.264 via `h264_qsv` (Intel Quick Sync) when the encoder starts, otherwise
`libx264`. No npm packages, no Python, no screen recording.

The soundtrack is synthesised by [`web/score.mjs`](web/score.mjs): four detuned sine pads
with slow tremolo, typing ticks timed to the picture, key thocks, send whooshes, a cancel
sweep and an outro chime, written as a 48 kHz stereo WAV.

## Regenerate

```bash
node docs/promo/web/render.mjs               # frames + score + encode
node docs/promo/web/render.mjs --poster-only # just hold-on-poster.png
node docs/promo/web/render.mjs --skip-frames # re-encode existing frames
```

A full rebuild takes about two minutes; only the encode is needed after an audio change.
Intermediate frames land in `docs/promo/frames/` (git-ignored) as JPEG q88. The poster is
captured at t = 1.75 s.

Requirements: Node 22+ (global `fetch` and `WebSocket`), Edge or Chrome, `ffmpeg` on
`PATH`, and the Windows fonts already installed (`Microsoft YaHei`, `Segoe UI`).

## Scenes

| Time | Scene |
| --- | --- |
| 0.0–3.2 | Logo, `按住再说` / `HOLD ON` |
| 3.2–9.6 | Typing; a stray `Enter` sends half a prompt; then `想换行` but `Enter` sends it |
| 9.6–14.4 | Holding `Enter`: bar fills, sends; released early — nothing happens |
| 14.4–18.6 | Holding the send button: ring fills; a tap does nothing |
| 18.6–23.6 | The `设置 → 按住再说` page: switches, styles, duration |
| 23.6–28.6 | Repo, licence and where to find the page |
