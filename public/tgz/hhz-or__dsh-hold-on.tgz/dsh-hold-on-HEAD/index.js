/**
 * Host half of dsh-hold-on.
 *
 * The plugin is purely a Web client enhancement: it registers an entry in the
 * conversation composer overlay and asks for no Host services, no routes and no
 * persistent state. Keeping `apply` empty guarantees the Host side stays inert
 * and the bundle installs cleanly on every platform.
 */
export function apply() {}
