# Hold On

[English](README.md) | [简体中文](README.zh-CN.md)

A DeepSeek Harness Web plugin that turns the composer's **send** and **stop**
actions into **hold to confirm** gestures, so a stray `Enter` keypress or an
accidental click on the send button no longer sends a half-written prompt, and
stopping a running turn is just as deliberate.

## Repository

Source and releases: <https://github.com/hhz-or/dsh-hold-on>.

## What it does

- **Click and hold the send button**: a progress ring grows around the button.
  Release early and nothing is sent. Hold to the end and the button is
  activated exactly as a normal click would be.
- **Press and hold `Enter`** in the draft editor (or hold `Space` / `Enter`
  while the send button has keyboard focus): a thin progress bar fills along
  the bottom of the composer. Releasing the key early cancels the send.
- **Click and hold the stop control** (the interrupt button, or the primary
  button while it shows the stop action): the same ring/bar treatment before
  the running turn actually stops.
- Both gestures respect the composer's own state: nothing is armed while the
  draft is empty, while the action button is disabled, while a command popup
  or the `/` menu is open, while IME composition is in progress, or while a
  message is being submitted.
- Every duration and every indicator style is adjustable from **Settings →
  按住再说 / Hold On**, the plugin's own page in the DSH Settings dialog. The name plays on *hold* — press and keep pressing — and *hold on*: wait for the progress to finish.

## Gestures and states

| Input | Result |
| --- | --- |
| Tap the send button | Nothing is sent; the click is swallowed |
| Hold the send button until the indicator completes | Sends through the host's own action handler |
| `Enter` (quick press), or `Space` on the focused send button | Nothing is sent |
| Hold `Enter` or `Ctrl/⌘+Enter` until the bar fills | Sends through the host's own keymap (`Enter` keeps the host's busy behavior, `Ctrl/⌘+Enter` keeps its complementary action) |
| Hold `Space` on the focused send button until the indicator completes | Activates the send button once |
| Tap the stop control | Nothing stops; the click is swallowed |
| Hold the stop control until the indicator completes | Stops through the host's own stop handler |
| Drag away from the pressed button (more than 24 px) | Cancels the hold |
| `Esc` during any hold | Cancels the hold immediately |
| `Shift+Enter`, IME composition, `/` menu open, command popup focused | Not intercepted; the composer behaves normally |
| Empty draft, disabled or frozen composer | Not intercepted |

Progress indicators are drawn inside the composer card, as children of the
plugin's own overlay anchor; nothing is appended to `document.body`. The
indicator fades/scales in when a hold starts, keeps a short full-value flash
when it completes, and fades out on cancel.

## Settings page

`settings.section` page plus a matching `settings.section.icon`, so the plugin
appears in the DSH Settings dialog's left navigation with its own page:

- a live preview at the top showing the ring and the bar at the configured
  duration;
- a master switch that suspends every hold and restores the host's instant
  activation without uninstalling the plugin;
- **Sending**: on/off for `Enter`, an indicator style for it, on/off for the
  send button, its style, and the send hold duration;
- **Stopping**: on/off, style, and the stop hold duration;
- **Other**: `Esc`-to-cancel on/off, plus the read-only DSH bindings the plugin
  follows (`Enter` send, `Ctrl/⌘+Enter` complementary, `Shift+Enter` newline,
  `Esc Esc` stop) read from the running app rather than hardcoded;
- **Restore defaults**.

Styles are `bar`, `ring`, `both` and `none`; `none` keeps the hold requirement
but draws nothing. Durations range from 0.15 s to 3 s in 25 ms steps (default
0.7 s). Every change applies immediately and is stored in the browser under
`dsh-hold-on:settings:v1` (migrated once from the earlier `dsh:hold-to-send:settings:v1`), so it survives reloads. The indicators use the
theme tokens `--dsw-alias-button-info-fill` and `--dsw-alias-border-l2`, and
the page uses the Settings dialog's own card/typography tokens, so both follow
the active theme. The page text follows the app's active locale (English and
Chinese).

The bindings are read through the `shortcuts` service's fixed catalog when it
is reachable from a third-party client plugin; otherwise the plugin falls back
to the platform defaults and says so in the same rows.

## How activation works

The plugin never calls the composer's submit action directly. For pointer
holds it clicks the real action button; for keyboard holds it clicks the
button (`Enter`, `Space`) or re-dispatches the complementary keydown on the
editor (`Ctrl/⌘+Enter`). Either way the composer's own decision (send, stop,
retry, steer or queue, including the current submit mode and the "Enter 键行为"
setting) is the one that runs. Everything else about the pressed gesture is
left native — the press is not cancelled, so focus, text selection and the
pressed look keep working; only the release click is filtered, and a completed
hold lets exactly one activation through.

## Known limits

- The gesture is only armed while the action button is enabled; a hold that
  starts and then loses its target (the composer is re-rendered, the draft is
  cleared elsewhere, or the button becomes disabled) ends without acting.
- Autocomplete menus that claim `Enter` (the `/` menu, the command popup) keep
  their own keyboard handling.
- Disabling the plugin, or the master switch, immediately restores instant
  activation.

## Files

- `index.js` — inert Host half (`apply()` does nothing; the plugin is a Web
  client enhancement).
- `client.js` — the client entry: the settings store and page, the
  `conversation.input.overlay` progress anchor, the shortcut-binding bridge and
  the gesture engine.
- `cordis.patch.yml` — inserts the bundle row.
- `locale/en.json`, `locale/zh.json` — title and description for the plugin
  manager.
- `icon.svg` — a send button with an in-progress ring; also drawn in the
  Settings navigation.

## Performance

The hold indicator is drawn on the compositor as much as possible:

- React renders the ring/bar once per hold; each animation frame only writes
  two style properties on already-mounted nodes, so a 60fps hold never
  reconciles the tree or re-renders the composer.
- Geometry (button and card rects) is measured once per hold and re-measured
  only on resize or scroll, so the frame loop never forces layout.
- The bar fill animates `transform: scaleX()` instead of `width`, keeping it
  off the layout path.
- Settings writes are debounced (150 ms), so dragging a duration slider does
  not perform one synchronous `localStorage` write per input event, and the
  preview loop keeps running instead of restarting on every tick.
- `prefers-reduced-motion` disables the enter/exit transitions.

## License

MIT © 2026 hhz-or. See [LICENSE](LICENSE).
