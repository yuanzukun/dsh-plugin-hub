/**
 * Hold to send — a composer guard for DeepSeek Harness.
 *
 * A deliberate hold is required before the composer sends (Enter, the send
 * button, or Space on the focused button) and before it stops a running turn.
 * The hold is drawn either as a thin bar inside the composer, a ring around
 * the action button, both, or nothing.
 *
 * Two slots are filled:
 * - `conversation.input.overlay` hosts the invisible anchor the indicators are
 *   drawn from; the composer ancestors are resolved from it on every event, so
 *   a hero ↔ docked remount keeps working.
 * - `settings.section` (plus `settings.section.icon`) hosts the real settings
 *   page inside the app's Settings dialog.
 *
 * Activation still goes through the host: a hold either clicks the real action
 * button (send / stop) or, for the complementary chord, replays that keydown on
 * the editor — so DSH decides queue/steer/retry and nothing is hardcoded.
 *
 * All settings live in localStorage under `dsh-hold-on:settings:v1`.
 * The client plugin receives no patch config: edit this file and refresh.
 */
window.__ModuleLoader__.load({
  id: 'dsh-hold-on',
  factory(require) {
    'use strict'

    const React = require('react')
    const h = React.createElement

    /* ------------------------------------------------------------------ */
    /* Settings store                                                      */
    /* ------------------------------------------------------------------ */

    const STORAGE_KEY = 'dsh-hold-on:settings:v1'
    /** Previous package name; migrated once into STORAGE_KEY. */
    const LEGACY_STORAGE_KEY = 'dsh:hold-to-send:settings:v1'
    const STYLE_VALUES = ['bar', 'ring', 'both', 'none']
    const MS_MIN = 150
    const MS_MAX = 3000
    const MS_STEP = 25
    const DRAG_CANCEL_PX = 24
    const SUPPRESS_MS = 1500
    const RING = { gap: 4, width: 2.5 }
    const BAR = { height: 3, inset: 14, bottom: 5 }
    const TRACK = 'var(--dsw-alias-border-l2, rgba(128,128,128,0.35))'
    const TRACK_SOFT = 'var(--dsw-alias-border-l4, rgba(128,128,128,0.22))'
    const FILL = 'var(--dsw-alias-button-info-fill, #3964fe)'

    const DEFAULTS = {
      enabled: true,
      sendHoldMs: 700,
      enterEnabled: true,
      enterStyle: 'bar',
      clickEnabled: true,
      clickStyle: 'ring',
      stopEnabled: true,
      stopHoldMs: 700,
      stopStyle: 'ring',
      escCancel: true,
    }

    const clampMs = (value) => {
      const number = Number(value)
      if (!Number.isFinite(number)) return DEFAULTS.sendHoldMs
      const clamped = Math.min(MS_MAX, Math.max(MS_MIN, number))
      return Math.round(clamped / MS_STEP) * MS_STEP
    }

    const styleValue = (value, fallback) => (STYLE_VALUES.indexOf(value) >= 0 ? value : fallback)

    const normalizeSettings = (raw) => {
      const source = raw !== null && typeof raw === 'object' ? raw : {}
      return {
        enabled: typeof source.enabled === 'boolean' ? source.enabled : DEFAULTS.enabled,
        sendHoldMs: clampMs(source.sendHoldMs === undefined ? DEFAULTS.sendHoldMs : source.sendHoldMs),
        enterEnabled: typeof source.enterEnabled === 'boolean' ? source.enterEnabled : DEFAULTS.enterEnabled,
        enterStyle: styleValue(source.enterStyle, DEFAULTS.enterStyle),
        clickEnabled: typeof source.clickEnabled === 'boolean' ? source.clickEnabled : DEFAULTS.clickEnabled,
        clickStyle: styleValue(source.clickStyle, DEFAULTS.clickStyle),
        stopEnabled: typeof source.stopEnabled === 'boolean' ? source.stopEnabled : DEFAULTS.stopEnabled,
        stopHoldMs: clampMs(source.stopHoldMs === undefined ? DEFAULTS.stopHoldMs : source.stopHoldMs),
        stopStyle: styleValue(source.stopStyle, DEFAULTS.stopStyle),
        escCancel: typeof source.escCancel === 'boolean' ? source.escCancel : DEFAULTS.escCancel,
      }
    }

    const storageOf = () => {
      try {
        const storage = typeof window === 'undefined' ? null : window.localStorage
        return storage !== null && typeof storage.getItem === 'function' ? storage : null
      } catch (error) {
        return null
      }
    }

    const readSettings = () => {
      const storage = storageOf()
      if (storage === null) return { ...DEFAULTS }
      try {
        let raw = storage.getItem(STORAGE_KEY)
        if (typeof raw !== 'string' || raw === '') {
          raw = storage.getItem(LEGACY_STORAGE_KEY)
          if (typeof raw === 'string' && raw !== '') {
            try {
              storage.setItem(STORAGE_KEY, raw)
            } catch (error) {
              /* keep reading the legacy value even when it cannot be copied */
            }
          }
        }
        if (typeof raw !== 'string' || raw === '') return { ...DEFAULTS }
        return normalizeSettings(JSON.parse(raw))
      } catch (error) {
        return { ...DEFAULTS }
      }
    }

    const store = {
      value: readSettings(),
      listeners: new Set(),
      subscribe(listener) {
        this.listeners.add(listener)
        return () => {
          this.listeners.delete(listener)
        }
      },
      pendingTimer: 0,
      persistNow() {
        const storage = storageOf()
        if (storage === null) return
        try {
          storage.setItem(STORAGE_KEY, JSON.stringify(this.value))
        } catch (error) {
          /* A full or disabled storage must not break the composer. */
        }
      },
      schedulePersist() {
        if (this.pendingTimer !== 0) return
        const win = typeof window === 'undefined' ? null : window
        if (win === null || win === undefined || typeof win.setTimeout !== 'function') {
          this.persistNow()
          return
        }
        this.pendingTimer = win.setTimeout(() => {
          this.pendingTimer = 0
          this.persistNow()
        }, 150)
      },
      update(patch) {
        this.value = normalizeSettings({ ...this.value, ...patch })
        // Dragging a slider fires many updates; one deferred write keeps the
        // drag smooth instead of a synchronous localStorage write per frame.
        this.schedulePersist()
        for (const listener of [...this.listeners]) {
          try {
            listener()
          } catch (error) {
            console.error('dsh-hold-on: settings listener failed', error)
          }
        }
      },
      reset() {
        this.update({ ...DEFAULTS })
      },
    }

    function useSettings() {
      const [value, setValue] = React.useState(store.value)
      React.useEffect(() => store.subscribe(() => {
        setValue(store.value)
      }), [])
      return value
    }

    /* ------------------------------------------------------------------ */
    /* Locale and copy                                                     */
    /* ------------------------------------------------------------------ */

    let pluginCtx = null

    const serviceNow = (name) => {
      const ctx = pluginCtx
      if (ctx === null || typeof ctx.get !== 'function') return undefined
      try {
        return ctx.get(name)
      } catch (error) {
        return undefined
      }
    }

    const localeIdNow = () => {
      try {
        const face = serviceNow('locale')
        if (face !== null && typeof face.getSnapshot === 'function') {
          const snapshot = face.getSnapshot()
          if (snapshot !== null && typeof snapshot.active === 'string') return snapshot.active
        }
      } catch (error) {
        /* fall through */
      }
      try {
        return typeof navigator === 'undefined' ? '' : String(navigator.language || '')
      } catch (error) {
        return ''
      }
    }

    const isZh = (id) => /^zh/i.test(String(id || ''))

    const COPY = {
      zh: {
        title: '按住再说',
        intro: '按 Enter、发送按钮或停止按钮时先按住，进度走满才执行，避免误触和误按。“按住再说”就是这个意思：先按住，也是在等一下。设置自动保存在本机。',
        preview: '进度效果预览',
        master: '需要长按',
        masterHint: '关闭后恢复即时发送和停止，设置会保留。',
        sending: '发送',
        enter: '回车键 (Enter)',
        enterHint: '按住 Enter，进度走满才发送。',
        click: '发送按钮',
        clickHint: '按住发送按钮，进度走满才发送。',
        style: '进度样式',
        styleBar: '条',
        styleRing: '环',
        styleBoth: '两者',
        styleNone: '无',
        duration: '长按时长',
        stopping: '停止输出',
        stop: '停止按钮',
        stopHint: '运行中按住停止按钮，进度走满才中断。',
        stopDuration: '停止长按时长',
        other: '其他',
        esc: 'Esc 取消长按',
        escHint: '长按途中按 Esc 会立即取消，不会执行。',
        shortcuts: 'DSH 快捷键',
        shortcutsHint: '这些键位来自 DSH 的快捷键设置，插件只读取，不能在这里修改。',
        keySend: '发送',
        keyComplementary: '补充发送（队列 / 引导）',
        keyNewline: '换行',
        keyStop: '停止输出',
        reset: '恢复默认',
        autosave: '修改会自动保存',
        seconds: (ms) => `${(ms / 1000).toFixed(2)} 秒`,
      },
      en: {
        title: 'Hold On',
        intro: 'Hold Enter, the send button, or the stop button until the progress completes. Hold On — press, and wait. Settings are saved on this device.',
        preview: 'Indicator preview',
        master: 'Require a hold',
        masterHint: 'When off, send and stop react immediately; your settings stay saved.',
        sending: 'Sending',
        enter: 'Enter key',
        enterHint: 'Hold Enter until the bar fills.',
        click: 'Send button',
        clickHint: 'Hold the button until the ring closes.',
        style: 'Indicator',
        styleBar: 'Bar',
        styleRing: 'Ring',
        styleBoth: 'Both',
        styleNone: 'None',
        duration: 'Hold time',
        stopping: 'Stopping',
        stop: 'Stop button',
        stopHint: 'While a turn runs, hold the stop button until the ring closes.',
        stopDuration: 'Stop hold time',
        other: 'More',
        esc: 'Escape cancels a hold',
        escHint: 'Press Escape while holding to release without acting.',
        shortcuts: 'DSH shortcuts',
        shortcutsHint: 'These come from DSH and are read-only here.',
        keySend: 'Send',
        keyComplementary: 'Complementary submit (queue / steer)',
        keyNewline: 'Line break',
        keyStop: 'Stop output',
        reset: 'Restore defaults',
        autosave: 'Changes save automatically',
        seconds: (ms) => `${(ms / 1000).toFixed(2)} s`,
      },
    }

    const copyFor = (id) => (isZh(id) ? COPY.zh : COPY.en)

    function useActiveLocale() {
      const [id, setId] = React.useState(localeIdNow())
      React.useEffect(() => {
        let face
        try {
          face = serviceNow('locale')
        } catch (error) {
          face = undefined
        }
        if (face === null || face === undefined || typeof face.subscribe !== 'function') return undefined
        return face.subscribe(() => setId(localeIdNow()))
      }, [])
      return id
    }

    /* ------------------------------------------------------------------ */
    /* DSH shortcut bindings (read-only)                                   */
    /* ------------------------------------------------------------------ */

    const detectPlatform = () => {
      try {
        const data = typeof navigator === 'undefined' ? undefined : navigator.userAgentData
        const name = String((data && data.platform) || (typeof navigator === 'undefined' ? '' : navigator.platform) || '')
        if (/mac/i.test(name)) return 'macos'
        if (/win/i.test(name)) return 'windows'
        return 'linux'
      } catch (error) {
        return 'windows'
      }
    }

    const FALLBACK_PLATFORM = detectPlatform()

    const modifierLabel = (platform) => (platform === 'macos' ? '⌘' : 'Ctrl')

    /**
     * Read the fixed shortcut rows DSH publishes (read-only for the user) and
     * fall back to the known defaults when the shortcuts service is not
     * reachable from a third-party client plugin.
     */
    const shortcutRows = () => {
      const platform = (() => {
        try {
          const face = serviceNow('shortcuts')
          if (face !== null && (face.platform === 'macos' || face.platform === 'windows' || face.platform === 'linux')) return face.platform
        } catch (error) {
          /* fall through */
        }
        return FALLBACK_PLATFORM
      })()
      const rows = {
        send: { keys: ['Enter'], binding: { code: 'Enter', modifiers: [] } },
        complementary: { keys: [modifierLabel(platform), 'Enter'], binding: { code: 'Enter', modifiers: [platform === 'macos' ? 'meta' : 'control'] } },
        newline: { keys: ['Shift', 'Enter'], binding: { code: 'Enter', modifiers: ['shift'] } },
        stop: { keys: ['Esc', 'Esc'], binding: { code: 'Escape', modifiers: [] } },
      }
      let snapshot = null
      try {
        const face = serviceNow('shortcuts')
        if (face !== null && face.fixedCatalog !== null && typeof face.fixedCatalog.getSnapshot === 'function') {
          const value = face.fixedCatalog.getSnapshot()
          if (Array.isArray(value)) snapshot = value
        }
      } catch (error) {
        snapshot = null
      }
      if (snapshot === null) return { platform, ...rows }
      const byId = {}
      for (const row of snapshot) {
        if (row !== null && typeof row === 'object' && typeof row.id === 'string') byId[row.id] = row
      }
      const take = (key, id) => {
        const row = byId[id]
        if (row === undefined) return
        if (Array.isArray(row.keys)) {
          const keys = row.keys.filter((entry) => typeof entry === 'string' && entry !== '')
          if (keys.length > 0) rows[key].keys = keys
        }
        if (Array.isArray(row.bindings)) {
          const binding = row.bindings[0]
          if (binding !== null && typeof binding === 'object' && typeof binding.code === 'string') rows[key].binding = binding
        }
      }
      take('send', 'fixed.send')
      take('complementary', 'fixed.complementary')
      take('newline', 'fixed.newline')
      take('stop', 'response.stop')
      return { platform, ...rows }
    }

    const bindingMatches = (binding, event) => {
      if (binding === null || typeof binding !== 'object') return false
      if (binding.code !== event.code) return false
      if (binding.secondCode !== undefined) return false
      const modifiers = Array.isArray(binding.modifiers) ? binding.modifiers : []
      const active = []
      if (event.ctrlKey === true) active.push('control')
      if (event.altKey === true) active.push('alt')
      if (event.shiftKey === true) active.push('shift')
      if (event.metaKey === true) active.push('meta')
      if (active.length !== modifiers.length) return false
      for (const modifier of modifiers) if (active.indexOf(modifier) < 0) return false
      return true
    }

    /* ------------------------------------------------------------------ */
    /* Composer helpers                                                    */
    /* ------------------------------------------------------------------ */

    const SELECT_SNAPSHOT = (snapshot) => snapshot
    const NO_SNAPSHOT = { draft: '', attachmentIds: [], phase: 'plain' }

    const hasDraftContent = (snapshot) => {
      if (snapshot === null || typeof snapshot !== 'object') return false
      if (typeof snapshot.draft === 'string' && snapshot.draft.trim() !== '') return true
      return Array.isArray(snapshot.attachmentIds) && snapshot.attachmentIds.length > 0
    }

    const isFrozen = (snapshot) => {
      const phase = snapshot === null || typeof snapshot !== 'object' ? 'plain' : snapshot.phase
      return phase === 'adjudicating' || phase === 'submitting' || phase === 'sending'
    }

    const clockOf = (win) => {
      if (win !== null && win !== undefined && win.performance !== undefined && typeof win.performance.now === 'function') {
        return () => win.performance.now()
      }
      return () => Date.now()
    }

    const CIRCLE_MIN = 20
    const CIRCLE_DELTA = 4

    const isCircle = (element) => {
      if (element === null || element === undefined || typeof element.getBoundingClientRect !== 'function') return false
      const rect = element.getBoundingClientRect()
      if (rect === null || rect === undefined) return false
      if (!(rect.width >= CIRCLE_MIN) || !(rect.height >= CIRCLE_MIN)) return false
      return Math.abs(rect.width - rect.height) <= CIRCLE_DELTA
    }

    const isPrimaryLike = (element, cardRect) => {
      if (!isCircle(element)) return false
      const rect = element.getBoundingClientRect()
      const tolerance = Math.max(48, cardRect.width * 0.3)
      return Math.abs(cardRect.right - rect.right) <= tolerance
    }

    const iconCount = (element, selector) => {
      try {
        if (element === null || element === undefined || typeof element.querySelector !== 'function') return null
        const svg = element.querySelector('svg')
        if (svg === null || svg === undefined || typeof svg.querySelectorAll !== 'function') return null
        return svg.querySelectorAll(selector).length
      } catch (error) {
        return null
      }
    }

    const looksLikeStopIcon = (element) => iconCount(element, 'rect') === 1 && iconCount(element, 'path') === 0

    const findActionButtons = (card) => {
      if (card === null || card === undefined || typeof card.getBoundingClientRect !== 'function') return null
      const cardRect = card.getBoundingClientRect()
      if (cardRect === null || cardRect === undefined) return null
      const scope = card.lastElementChild || card
      const all = typeof scope.querySelectorAll === 'function' ? Array.from(scope.querySelectorAll('button')) : []
      const main = all.length > 0 ? all[all.length - 1] : null
      if (main === null || !isPrimaryLike(main, cardRect)) return null
      if (looksLikeStopIcon(main) === true) return { primary: null, stop: main, card }
      const primaryRect = main.getBoundingClientRect()
      let stop = null
      const last = all.length - 2
      for (let index = last; index >= Math.max(0, last - 3); index -= 1) {
        const candidate = all[index]
        if (!isCircle(candidate) || looksLikeStopIcon(candidate) !== true) continue
        const rect = candidate.getBoundingClientRect()
        const gap = primaryRect.left - rect.right
        if (gap >= -2 && gap <= 40) {
          stop = candidate
          break
        }
      }
      return { primary: main, stop, card }
    }

    /* ------------------------------------------------------------------ */
    /* Styles                                                              */
    /* ------------------------------------------------------------------ */

    const CSS = `
.h2s-layer{position:absolute;left:0;top:0;pointer-events:none;transform:translateZ(0);backface-visibility:hidden;animation:h2sIn .15s cubic-bezier(.2,.8,.2,1) both}
.h2s-layer[data-flash]{animation:h2sFlash .16s ease-out both}
.h2s-ring{position:absolute;overflow:visible;will-change:transform;animation:h2sPop .18s cubic-bezier(.2,.8,.2,1) both}
.h2s-barTrack{position:absolute;border-radius:999px;background:${TRACK_SOFT};overflow:hidden}
.h2s-barFill{height:100%;width:100%;border-radius:999px;background:${FILL};transform-origin:left center;transform:scaleX(0);will-change:transform}
@keyframes h2sIn{from{opacity:0}to{opacity:1}}
@keyframes h2sFlash{0%,55%{opacity:1}100%{opacity:0}}
@keyframes h2sPop{from{opacity:0;transform:scale(.94)}to{opacity:1;transform:scale(1)}}
.h2s-page{display:flex;flex-direction:column;gap:12px;max-width:720px;color:var(--dsw-alias-label-primary);animation:h2sPage .2s cubic-bezier(.2,.8,.2,1) both;padding-bottom:8px}
@keyframes h2sPage{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
.h2s-title{margin:0;font-size:16px;line-height:24px;font-weight:500;color:var(--dsw-alias-label-primary)}
.h2s-intro{margin:0;font-size:14px;line-height:22px;color:var(--dsw-alias-label-tertiary)}
.h2s-preview{position:relative;display:flex;flex-direction:column;gap:8px;padding:16px;border:0.5px solid var(--dsw-alias-settings-card-stroke);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-xl)}
.h2s-previewCard{position:relative;display:flex;align-items:center;justify-content:space-between;gap:12px;height:72px;padding:0 16px;border:0.5px solid var(--dsw-alias-settings-card-stroke);border-radius:var(--dsw-radius-lg);background:var(--dsw-alias-settings-card-fill)}
.h2s-previewText{display:flex;flex-direction:column;gap:7px;flex:1;min-width:0}
.h2s-previewLine{display:block;height:7px;width:58%;border-radius:999px;background:${TRACK_SOFT}}
.h2s-previewLine.h2s-previewShort{width:34%}
.h2s-previewAction{position:relative;flex:none;width:34px;height:34px;display:flex;align-items:center;justify-content:center}
.h2s-previewRing{position:absolute;left:-6.5px;top:-6.5px;overflow:visible}
.h2s-previewSend{width:34px;height:34px;border-radius:999px;background:${FILL};display:inline-flex;align-items:center;justify-content:center;box-shadow:0 1px 3px rgba(0,0,0,.18)}
.h2s-previewBar{position:absolute;left:14px;right:14px;bottom:5px;height:3px;border-radius:999px;background:${TRACK_SOFT};overflow:hidden}
.h2s-previewBarFill{height:100%;width:100%;border-radius:999px;background:${FILL};transform-origin:left center;transform:scaleX(0)}
.h2s-previewTag{font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary)}
.h2s-group{display:flex;flex-direction:column;gap:6px;margin-top:4px}
.h2s-groupTitle{margin:0;font-size:14px;line-height:22px;font-weight:500;color:var(--dsw-alias-label-primary)}
.h2s-groupHint{margin:0;font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary)}
.h2s-card{border:0.5px solid var(--dsw-alias-settings-card-stroke);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-xl);padding:4px 14px}
.h2s-row{display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:48px;padding:8px 0}
.h2s-row + .h2s-row{border-top:0.5px solid var(--dsw-alias-settings-card-stroke)}
.h2s-rowText{display:flex;flex-direction:column;gap:2px;min-width:0}
.h2s-rowLabel{font-size:14px;line-height:22px;color:var(--dsw-alias-label-primary)}
.h2s-rowHint{font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary)}
.h2s-rowControl{flex:none;display:flex;align-items:center;gap:8px;min-width:0}
.h2s-dim{opacity:.45}
.h2s-switch{position:relative;flex:none;width:36px;height:20px;padding:0;border:0;border-radius:999px;background:var(--dsw-alias-border-l4,rgba(128,128,128,.35));cursor:pointer;transition:background-color .18s cubic-bezier(.2,.8,.2,1)}
.h2s-switch[data-on]{background:var(--dsw-alias-state-business-primary,#3964fe)}
.h2s-switch:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary,#3964fe);outline-offset:2px}
.h2s-knob{position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.28);transition:transform .18s cubic-bezier(.2,.8,.2,1)}
.h2s-switch[data-on] .h2s-knob{transform:translateX(16px)}
.h2s-seg{display:inline-flex;padding:2px;gap:2px;border-radius:999px;background:var(--dsw-alias-interactive-bg-hover,rgba(128,128,128,.14))}
.h2s-segItem{padding:3px 10px;border:0;border-radius:999px;background:transparent;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;cursor:pointer;transition:background-color .16s ease,color .16s ease,box-shadow .16s ease}
.h2s-segItem[aria-pressed="true"]{background:var(--dsw-alias-settings-card-fill,#fff);color:var(--dsw-alias-label-primary);box-shadow:0 1px 2px rgba(0,0,0,.16)}
.h2s-segItem:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary,#3964fe);outline-offset:1px}
.h2s-duration{display:flex;align-items:center;gap:10px}
.h2s-range{width:170px;accent-color:var(--dsw-alias-state-business-primary,#3964fe);cursor:pointer}
.h2s-range:disabled{cursor:default}
.h2s-durationValue{min-width:52px;text-align:right;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums}
.h2s-keys{display:inline-flex;align-items:center;gap:4px;flex-wrap:wrap;justify-content:flex-end}
.h2s-kbd{display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border:0.5px solid ${TRACK};border-radius:var(--dsw-radius-sm,6px);background:var(--dsw-alias-interactive-bg-hover,rgba(128,128,128,.1));font-family:inherit;font-size:11px;line-height:1;color:var(--dsw-alias-label-secondary)}
.h2s-footer{display:flex;align-items:center;gap:12px;padding-top:4px}
.h2s-reset{padding:5px 12px;border:0.5px solid ${TRACK};border-radius:999px;background:transparent;color:var(--dsw-alias-label-primary);font-size:12px;line-height:18px;cursor:pointer;transition:background-color .16s ease}
.h2s-reset:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(128,128,128,.12))}
.h2s-reset:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary,#3964fe);outline-offset:2px}
.h2s-saved{font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary)}
@media (prefers-reduced-motion: reduce){.h2s-layer,.h2s-ring,.h2s-page{animation:none}.h2s-knob,.h2s-switch{transition:none}}
`

    const Styles = () => h('style', { dangerouslySetInnerHTML: { __html: CSS } })

    /* ------------------------------------------------------------------ */
    /* The gesture host (conversation.input.overlay)                       */
    /* ------------------------------------------------------------------ */

    function HoldToSend(props) {
      const settings = useSettings()
      const settingsRef = React.useRef(settings)
      settingsRef.current = settings
      const snapshot = typeof props.useInput === 'function' ? props.useInput(SELECT_SNAPSHOT) : NO_SNAPSHOT
      const live = React.useRef({ snapshot })
      live.current.snapshot = snapshot
      const anchorRef = React.useRef(null)
      const [visual, setVisual] = React.useState(null)
      const ringRef = React.useRef(null)
      const fillRef = React.useRef(null)
      const paintRef = React.useRef(null)

      React.useEffect(() => {
        const anchor = anchorRef.current
        if (anchor === null || anchor === undefined) return undefined
        const doc = anchor.ownerDocument || null
        if (doc === null || typeof doc.addEventListener !== 'function') return undefined
        const win = doc.defaultView || (typeof window === 'undefined' ? null : window)
        if (win === null || win === undefined || typeof win.requestAnimationFrame !== 'function') return undefined
        const clock = clockOf(win)

        const state = {
          gesture: null,
          raf: 0,
          guard: null,
          synthetic: 0,
          blocked: false,
          flashUntil: 0,
          geo: null,
          value: 0,
        }

        const setVisualSafe = (next) => {
          try {
            setVisual(next)
          } catch (error) {
            /* a torn-down fiber must not throw from a frame */
          }
        }

        const currentCard = () => {
          try {
            return typeof anchor.closest === 'function' ? anchor.closest('[data-composer-card]') : null
          } catch (error) {
            return null
          }
        }

        const stopFrame = () => {
          if (state.raf === 0) return
          try {
            win.cancelAnimationFrame(state.raf)
          } catch (error) {
            /* ignore */
          }
          state.raf = 0
        }

        const geometryOf = (style, action, card) => {
          if (style === 'none') return null
          let origin = null
          try {
            origin = anchor.getBoundingClientRect()
          } catch (error) {
            origin = null
          }
          if (origin === null || origin === undefined) return null
          let ring = null
          if ((style === 'ring' || style === 'both') && action !== null && typeof action.getBoundingClientRect === 'function') {
            const rect = action.getBoundingClientRect()
            if (rect !== null && rect.width > 0) {
              const size = rect.width + (RING.gap + RING.width) * 2
              ring = {
                left: rect.left + rect.width / 2 - size / 2 - origin.left,
                top: rect.top + rect.height / 2 - size / 2 - origin.top,
                size,
                cx: size / 2,
                cy: size / 2,
                radius: size / 2 - RING.width / 2,
              }
            }
          }
          let bar = null
          if ((style === 'bar' || style === 'both') && card !== null && typeof card.getBoundingClientRect === 'function') {
            const rect = card.getBoundingClientRect()
            if (rect !== null && rect.width > BAR.inset * 2) {
              bar = {
                left: rect.left + BAR.inset - origin.left,
                top: rect.bottom - BAR.bottom - BAR.height - origin.top,
                width: rect.width - BAR.inset * 2,
                height: BAR.height,
              }
            }
          }
          return { style, ring, bar }
        }

        const mountIndicator = (style, action, card, value) => {
          const geometry = geometryOf(style, action, card)
          if (geometry === null) return
          const signature = JSON.stringify(geometry)
          if (state.geo === signature) {
            if (value >= 1) setVisualSafe({ style: geometry.style, ring: geometry.ring, bar: geometry.bar, value: 1 })
            return
          }
          state.geo = signature
          setVisualSafe({ style: geometry.style, ring: geometry.ring, bar: geometry.bar, value })
        }

        const paintProgress = (value) => {
          state.value = value
          paintRef.last = value
          const ringNode = ringRef.current
          if (ringNode !== null && ringNode !== undefined && typeof ringNode.setAttribute === 'function') {
            ringNode.setAttribute('stroke-dashoffset', String(1 - value))
          }
          const fillNode = fillRef.current
          if (fillNode !== null && fillNode !== undefined && fillNode.style !== undefined) {
            fillNode.style.transform = `scaleX(${value})`
          }
        }

        const durationOf = (kind) => {
          const current = settingsRef.current
          return kind === 'stop' ? current.stopHoldMs : current.sendHoldMs
        }

        const styleOf = (kind, via) => {
          const current = settingsRef.current
          if (kind === 'stop') return current.stopStyle
          return via === 'enter' || via === 'complementary' ? current.enterStyle : current.clickStyle
        }

        let collectFrame = null

        const scheduleFrame = () => {
          if (state.raf !== 0) return
          state.raf = win.requestAnimationFrame(collectFrame)
        }

        const hideIndicator = () => {
          setVisualSafe(null)
        }

        const cancel = () => {
          const active = state.gesture
          state.gesture = null
          stopFrame()
          state.flashUntil = 0
          state.geo = null
          state.value = 0
          hideIndicator()
          if (active !== null && active.mode === 'pointer') {
            state.guard = { allowNext: false, suppressUntil: clock() + SUPPRESS_MS }
          }
        }

        const resolveTarget = (active, card) => {
          const recorded = active.button
          if (recorded !== null && recorded !== undefined && recorded.isConnected !== false && recorded.disabled !== true) return recorded
          const found = findActionButtons(card)
          if (found === null) return null
          const next = active.kind === 'stop' ? found.stop : found.primary
          if (next === null || next === undefined || next.disabled === true) return null
          return next
        }

        const dispatchSynthetic = (editor, rows) => {
          try {
            const Ctor = win.KeyboardEvent
            if (typeof Ctor !== 'function' || typeof editor.dispatchEvent !== 'function') return false
            const binding = rows.complementary.binding
            const modifiers = Array.isArray(binding.modifiers) ? binding.modifiers : []
            state.synthetic += 1
            const event = new Ctor('keydown', {
              key: binding.code === 'Enter' ? 'Enter' : binding.code,
              code: binding.code,
              bubbles: true,
              cancelable: true,
              ctrlKey: modifiers.indexOf('control') >= 0,
              metaKey: modifiers.indexOf('meta') >= 0,
              shiftKey: modifiers.indexOf('shift') >= 0,
              altKey: modifiers.indexOf('alt') >= 0,
            })
            editor.dispatchEvent(event)
            return true
          } catch (error) {
            state.synthetic = Math.max(0, state.synthetic - 1)
            return false
          }
        }

        const complete = (active) => {
          state.gesture = null
          stopFrame()
          const card = active.card
          mountIndicator(active.style, active.button, card, 1)
          paintProgress(1)
          state.flashUntil = clock() + 160
          state.guard = null
          if (active.mode === 'keyboard' && active.complementary === true && active.editor !== null) {
            if (dispatchSynthetic(active.editor, shortcutRows()) === true) {
              scheduleFrame()
              return
            }
          }
          const target = resolveTarget(active, card)
          if (target === null) {
            state.guard = { allowNext: false, suppressUntil: clock() + SUPPRESS_MS }
            scheduleFrame()
            return
          }
          if (active.mode === 'pointer') {
            state.guard = { allowNext: true, suppressUntil: clock() + SUPPRESS_MS }
          }
          try {
            target.click()
          } catch (error) {
            /* ignore */
          }
          scheduleFrame()
        }

        collectFrame = () => {
          state.raf = 0
          const active = state.gesture
          if (active === null) {
            if (state.flashUntil === 0) return
            if (clock() >= state.flashUntil) {
              state.flashUntil = 0
              hideIndicator()
              return
            }
            scheduleFrame()
            return
          }
          const current = settingsRef.current
          if (current.enabled !== true) {
            cancel()
            return
          }
          const elapsed = clock() - active.startedAt
          const duration = Math.max(MS_MIN, active.duration)
          const value = Math.min(1, elapsed / duration)
          if (state.geo === null) mountIndicator(active.style, active.button, active.card, value)
          paintProgress(value)
          if (value >= 1) {
            complete(active)
            return
          }
          scheduleFrame()
        }

        const begin = (init) => {
          state.gesture = init
          state.flashUntil = 0
          state.geo = null
          mountIndicator(init.style, init.button, init.card, 0)
          paintProgress(0)
          scheduleFrame()
        }

        /* ------------------------------ pointer ------------------------- */

        const onPointerDown = (event) => {
          const current = settingsRef.current
          if (current.enabled !== true) return
          if (event.button !== undefined && event.button !== 0) return
          if (state.gesture !== null || state.blocked === true) return
          const card = currentCard()
          if (card === null) return
          const found = findActionButtons(card)
          if (found === null) return
          const target = event.target
          if (target === null || target === undefined) return
          const onPrimary = found.primary !== null && (target === found.primary || (typeof found.primary.contains === 'function' && found.primary.contains(target)))
          const onStop = found.stop !== null && found.stop !== undefined && (target === found.stop || (typeof found.stop.contains === 'function' && found.stop.contains(target)))
          if (onPrimary !== true && onStop !== true) return
          const kind = onStop === true ? 'stop' : (looksLikeStopIcon(found.primary) === true ? 'stop' : 'send')
          const button = kind === 'stop' ? (found.stop || found.primary) : found.primary
          if (button === null || button === undefined || button.disabled === true) return
          const snapshotNow = live.current.snapshot
          if (isFrozen(snapshotNow) === true) return
          if (kind === 'send') {
            if (hasDraftContent(snapshotNow) !== true) return
            if (current.clickEnabled !== true) return
          } else if (current.stopEnabled !== true) {
            return
          }
          state.guard = { allowNext: false, suppressUntil: Number.POSITIVE_INFINITY }
          begin({
            kind,
            mode: 'pointer',
            via: 'press',
            button,
            card,
            duration: durationOf(kind),
            style: styleOf(kind, 'press'),
            startedAt: clock(),
            originX: typeof event.clientX === 'number' ? event.clientX : undefined,
            originY: typeof event.clientY === 'number' ? event.clientY : undefined,
            editor: null,
            complementary: false,
          })
        }

        const onPointerUp = () => {
          if (state.gesture !== null && state.gesture.mode === 'pointer') cancel()
        }

        const onPointerMove = (event) => {
          const active = state.gesture
          if (active === null || active.mode !== 'pointer') return
          const x = typeof event.clientX === 'number' ? event.clientX : null
          const y = typeof event.clientY === 'number' ? event.clientY : null
          if (x === null || y === null) return
          if (active.originX === undefined) {
            active.originX = x
            active.originY = y
            return
          }
          if (Math.hypot(x - active.originX, y - active.originY) > DRAG_CANCEL_PX) cancel()
        }

        const onPointerCancel = () => {
          if (state.gesture !== null && state.gesture.mode === 'pointer') cancel()
        }

        const onClickCapture = (event) => {
          const guard = state.guard
          if (guard === null) return
          if (guard.allowNext === true) {
            guard.allowNext = false
            return
          }
          if (clock() <= guard.suppressUntil) {
            event.preventDefault()
            event.stopPropagation()
            if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation()
            return
          }
          state.guard = null
        }

        const onContextMenu = (event) => {
          if (state.gesture === null || state.gesture.mode !== 'pointer') return
          event.preventDefault()
          event.stopPropagation()
        }

        /* ------------------------------ keyboard ------------------------ */

        const onKeyDown = (event) => {
          if (state.synthetic > 0) {
            state.synthetic -= 1
            return
          }
          if (event.code === 'Escape' || event.key === 'Escape') {
            if (state.gesture === null) return
            if (settingsRef.current.escCancel === false) return
            event.preventDefault()
            event.stopPropagation()
            cancel()
            return
          }
          if (state.gesture !== null || state.blocked === true) return
          const current = settingsRef.current
          if (current.enabled !== true) return
          if (event.repeat === true) return
          if (event.isComposing === true || event.keyCode === 229) return
          const card = currentCard()
          if (card === null) return
          if (typeof card.querySelector === 'function') {
            if (card.querySelector('[data-trigger-menu]') !== null) return
            if (card.querySelector('[data-composer-composing]') !== null) return
          }
          const found = findActionButtons(card)
          if (found === null) return
          const target = event.target
          const isEditor = target !== null && target !== undefined && typeof target.closest === 'function' && target.closest('[data-composer-input]') !== null
          const lastAction = found.primary !== null ? found.primary : found.stop
          const onAction = lastAction !== null && target !== null && target !== undefined && (target === lastAction || (typeof lastAction.contains === 'function' && lastAction.contains(target)))
          const rows = shortcutRows()
          let kind = null
          let via = 'enter'
          let complementary = false
          if (bindingMatches(rows.send.binding, event) === true && (isEditor === true || onAction === true)) {
            kind = 'send'
          } else if (bindingMatches(rows.complementary.binding, event) === true && (isEditor === true || onAction === true)) {
            kind = 'send'
            complementary = true
            via = 'complementary'
          } else if (event.code === 'Space' && event.ctrlKey !== true && event.metaKey !== true && event.altKey !== true && event.shiftKey !== true && onAction === true && lastAction !== null) {
            kind = found.primary === null || looksLikeStopIcon(found.primary) === true ? 'stop' : 'send'
            via = 'space'
          }
          if (kind === null) return
          const button = kind === 'stop' ? (found.stop || found.primary) : found.primary
          if (button === null || button === undefined || button.disabled === true) return
          const snapshotNow = live.current.snapshot
          if (kind === 'send') {
            if (hasDraftContent(snapshotNow) !== true) return
            if (isFrozen(snapshotNow) === true) return
            if (via === 'space') {
              if (current.clickEnabled !== true) return
            } else if (current.enterEnabled !== true) {
              return
            }
          } else if (current.stopEnabled !== true) {
            return
          }
          event.preventDefault()
          event.stopPropagation()
          state.blocked = true
          begin({
            kind,
            mode: 'keyboard',
            via,
            button,
            card,
            duration: durationOf(kind),
            style: styleOf(kind, via),
            startedAt: clock(),
            editor: isEditor === true ? target.closest('[data-composer-input]') : null,
            complementary,
          })
        }

        const onKeyUp = (event) => {
          if (state.blocked === true && (event.code === 'Enter' || event.key === 'Enter' || event.code === 'Space' || event.key === ' ')) {
            state.blocked = false
          }
          const active = state.gesture
          if (active === null || active.mode !== 'keyboard') return
          if (event.code === 'Enter' || event.code === 'Space' || event.key === 'Enter' || event.key === ' ') cancel()
        }

        const onBlur = () => {
          if (state.gesture !== null) cancel()
          state.blocked = false
        }

        const onVisibility = () => {
          if (doc.visibilityState === 'hidden' && state.gesture !== null) cancel()
        }

        /* ------------------------------ wiring -------------------------- */

        const onViewportChange = () => {
          const active = state.gesture
          if (active === null) return
          state.geo = null
          mountIndicator(active.style, active.button, active.card, state.value)
        }

        doc.addEventListener('keydown', onKeyDown, true)
        doc.addEventListener('keyup', onKeyUp, true)
        doc.addEventListener('pointerdown', onPointerDown, true)
        doc.addEventListener('pointerup', onPointerUp, true)
        doc.addEventListener('pointermove', onPointerMove, true)
        doc.addEventListener('pointercancel', onPointerCancel, true)
        doc.addEventListener('scroll', onViewportChange, true)
        doc.addEventListener('click', onClickCapture, true)
        doc.addEventListener('contextmenu', onContextMenu, true)
        doc.addEventListener('visibilitychange', onVisibility, true)
        win.addEventListener('blur', onBlur, true)
        win.addEventListener('resize', onViewportChange, true)

        paintRef.current = paintProgress
        return () => {
          stopFrame()
          try {
            doc.removeEventListener('keydown', onKeyDown, true)
            doc.removeEventListener('keyup', onKeyUp, true)
            doc.removeEventListener('pointerdown', onPointerDown, true)
            doc.removeEventListener('pointerup', onPointerUp, true)
            doc.removeEventListener('pointermove', onPointerMove, true)
            doc.removeEventListener('pointercancel', onPointerCancel, true)
            doc.removeEventListener('scroll', onViewportChange, true)
            doc.removeEventListener('click', onClickCapture, true)
            doc.removeEventListener('contextmenu', onContextMenu, true)
            doc.removeEventListener('visibilitychange', onVisibility, true)
          } catch (error) {
            /* ignore */
          }
          try {
            win.removeEventListener('blur', onBlur, true)
            win.removeEventListener('resize', onViewportChange, true)
          } catch (error) {
            /* ignore */
          }
        }
      }, [])

      // React rewrites inline styles on every commit; repaint the live value
      // so an unrelated re-render cannot snap a running hold back to 0.
      React.useEffect(() => {
        const paint = paintRef.current
        if (typeof paint === 'function') paint(paint.last === undefined ? 0 : paint.last)
      })

      const children = [h('style', { key: 'css', dangerouslySetInnerHTML: { __html: CSS } })]
      if (visual !== null && visual !== undefined) {
        children.push(h('div', { key: 'indicator', className: 'h2s-layer', 'data-flash': visual.value >= 1 ? '' : undefined },
          visual.ring !== null && visual.ring !== undefined
            ? h('svg', {
              key: 'ring',
              className: 'h2s-ring',
              width: visual.ring.size,
              height: visual.ring.size,
              viewBox: `0 0 ${visual.ring.size} ${visual.ring.size}`,
              style: { left: visual.ring.left, top: visual.ring.top },
              'aria-hidden': 'true',
            },
            h('circle', {
              cx: visual.ring.cx,
              cy: visual.ring.cy,
              r: visual.ring.radius,
              fill: 'none',
              stroke: TRACK,
              strokeWidth: RING.width,
            }),
            h('circle', {
              key: 'value',
              ref: ringRef,
              cx: visual.ring.cx,
              cy: visual.ring.cy,
              r: visual.ring.radius,
              fill: 'none',
              stroke: FILL,
              strokeWidth: RING.width,
              strokeLinecap: 'round',
              pathLength: 1,
              strokeDasharray: '1',
              strokeDashoffset: String(1 - (visual.value ?? 0)),
              transform: `rotate(-90 ${visual.ring.cx} ${visual.ring.cy})`,
            }))
            : null,
          visual.bar !== null && visual.bar !== undefined
            ? h('div', {
              key: 'bar',
              className: 'h2s-barTrack',
              style: { left: visual.bar.left, top: visual.bar.top, width: visual.bar.width, height: visual.bar.height },
            },
            h('div', { ref: fillRef, className: 'h2s-barFill', style: { transform: `scaleX(${visual.value ?? 0})` } }))
            : null))
      }

      return h('div', {
        ref: anchorRef,
        'data-dsh-hold-on': '',
        style: { position: 'absolute', left: 0, top: 0, width: '100%', height: 0, pointerEvents: 'none', zIndex: 1 },
      }, ...children)
    }

    /* ------------------------------------------------------------------ */
    /* Settings page (settings.section)                                    */
    /* ------------------------------------------------------------------ */

    const stylesFor = (copy) => [
      { value: 'bar', label: copy.styleBar },
      { value: 'ring', label: copy.styleRing },
      { value: 'both', label: copy.styleBoth },
      { value: 'none', label: copy.styleNone },
    ]

    function Switch(props) {
      return h('button', {
        type: 'button',
        role: 'switch',
        'aria-checked': props.checked === true,
        'aria-label': props.label,
        'data-on': props.checked === true ? '' : undefined,
        className: 'h2s-switch',
        onMouseDown: (event) => event.preventDefault(),
        onClick: () => props.onChange(props.checked !== true),
      }, h('span', { className: 'h2s-knob' }))
    }

    function Segmented(props) {
      return h('div', { className: 'h2s-seg', role: 'group', 'aria-label': props.label },
        props.options.map((option) => h('button', {
          key: option.value,
          type: 'button',
          'aria-pressed': props.value === option.value ? 'true' : 'false',
          className: 'h2s-segItem',
          onMouseDown: (event) => event.preventDefault(),
          onClick: () => props.onChange(option.value),
        }, option.label)))
    }

    function Slider(props) {
      return h('div', { className: 'h2s-duration' },
        h('input', {
          type: 'range',
          className: 'h2s-range',
          min: MS_MIN,
          max: MS_MAX,
          step: MS_STEP,
          value: props.value,
          'aria-label': props.label,
          onMouseDown: (event) => event.preventDefault(),
          onChange: (event) => props.onChange(clampMs(event.target.value)),
        }),
        h('span', { className: 'h2s-durationValue' }, props.copy.seconds(props.value)))
    }

    function Row(props) {
      return h('div', { className: 'h2s-row' },
        h('div', { className: 'h2s-rowText' },
          h('span', { className: 'h2s-rowLabel' }, props.label),
          props.hint === undefined ? null : h('span', { className: 'h2s-rowHint' }, props.hint)),
        h('div', { className: 'h2s-rowControl' }, props.children))
    }

    function Group(props) {
      return h('div', { className: 'h2s-group' },
        h('h3', { className: 'h2s-groupTitle' }, props.title),
        props.hint === undefined ? null : h('p', { className: 'h2s-groupHint' }, props.hint),
        props.children)
    }

    function Keys(props) {
      const list = Array.isArray(props.keys) ? props.keys : []
      return h('span', { className: 'h2s-keys' },
        list.map((key, index) => h('kbd', { key: `${key}-${index}`, className: 'h2s-kbd' }, key)))
    }

    function Preview(props) {
      const ringRef = React.useRef(null)
      const fillRef = React.useRef(null)
      const duration = Math.max(400, props.sendMs)
      const durationRef = React.useRef(duration)
      durationRef.current = duration
      React.useEffect(() => {
        const win = typeof window === 'undefined' ? null : window
        if (win === null || win === undefined || typeof win.requestAnimationFrame !== 'function') return undefined
        const clock = clockOf(win)
        const startedAt = clock()
        const cycle = duration + 1100
        let alive = true
        let raf = 0
        const step = () => {
          if (alive !== true) return
          const hold = durationRef.current
          const phase = (clock() - startedAt) % cycle
          let value = 0
          if (phase < hold) value = phase / hold
          else if (phase < hold + 240) value = 1
          else value = 0
          const ringNode = ringRef.current
          if (ringNode !== null && ringNode !== undefined && typeof ringNode.setAttribute === 'function') {
            ringNode.setAttribute('stroke-dashoffset', String(1 - value))
          }
          const fillNode = fillRef.current
          if (fillNode !== null && fillNode !== undefined && fillNode.style !== undefined) {
            fillNode.style.transform = `scaleX(${value})`
          }
          raf = win.requestAnimationFrame(step)
        }
        raf = win.requestAnimationFrame(step)
        return () => {
          alive = false
          try {
            win.cancelAnimationFrame(raf)
          } catch (error) {
            /* ignore */
          }
        }
      }, [])

      const ringStyle = props.clickStyle
      const barStyle = props.enterStyle
      const showRing = ringStyle === 'ring' || ringStyle === 'both'
      const showBar = barStyle === 'bar' || barStyle === 'both'
      const size = 34 + (RING.gap + RING.width) * 2
      const radius = size / 2 - RING.width / 2
      return h('div', { className: 'h2s-preview' },
        h('div', { className: 'h2s-previewCard' },
          h('div', { className: 'h2s-previewText' },
            h('span', { className: 'h2s-previewLine' }),
            h('span', { className: 'h2s-previewLine h2s-previewShort' })),
          h('div', { className: 'h2s-previewAction' },
            showRing
              ? h('svg', { className: 'h2s-previewRing', width: size, height: size, viewBox: `0 0 ${size} ${size}`, 'aria-hidden': 'true' },
                h('circle', { cx: size / 2, cy: size / 2, r: radius, fill: 'none', stroke: TRACK, strokeWidth: RING.width }),
                h('circle', {
                  key: 'value',
                  ref: ringRef,
                  cx: size / 2,
                  cy: size / 2,
                  r: radius,
                  fill: 'none',
                  stroke: FILL,
                  strokeWidth: RING.width,
                  strokeLinecap: 'round',
                  pathLength: 1,
                  strokeDasharray: '1',
                  strokeDashoffset: '1',
                  transform: `rotate(-90 ${size / 2} ${size / 2})`,
                }))
              : null,
            h('span', { className: 'h2s-previewSend' },
              h('svg', { width: 14, height: 14, viewBox: '0 0 24 24', fill: 'none', 'aria-hidden': 'true' },
                h('path', {
                  d: 'M12 19V5m0 0-5.5 5.5M12 5l5.5 5.5',
                  stroke: 'var(--dsw-alias-label-on-color, #fff)',
                  strokeWidth: 2,
                  strokeLinecap: 'round',
                  strokeLinejoin: 'round',
                })))),
          showBar
            ? h('div', { className: 'h2s-previewBar' },
              h('div', { key: 'fill', ref: fillRef, className: 'h2s-previewBarFill', style: { transform: 'scaleX(0)' } }))
            : null),
        h('span', { className: 'h2s-previewTag' }, props.copy.preview))
    }

    function HoldSettingsPage(props) {
      const settings = useSettings()
      const locale = useActiveLocale()
      const copy = copyFor(locale)
      const rows = shortcutRows()
      const off = settings.enabled !== true
      const disabledRow = off ? ' h2s-dim' : ''
      const update = (patch) => store.update(patch)
      return h('div', { className: 'h2s-page' },
        h(Styles, { key: 'css' }),
        h('h2', { key: 'title', className: 'h2s-title' }, copy.title),
        h('p', { key: 'intro', className: 'h2s-intro' }, copy.intro),
        h(Preview, {
          key: 'preview',
          copy,
          sendMs: settings.sendHoldMs,
          enterStyle: settings.enterStyle,
          clickStyle: settings.clickStyle,
        }),
        h('div', { key: 'master', className: 'h2s-card' },
          h('div', { className: 'h2s-row' },
            h('div', { className: 'h2s-rowText' },
              h('span', { className: 'h2s-rowLabel' }, copy.master),
              h('span', { className: 'h2s-rowHint' }, copy.masterHint)),
            h('div', { className: 'h2s-rowControl' },
              h(Switch, {
                checked: settings.enabled,
                label: copy.master,
                onChange: (next) => update({ enabled: next }),
              })))),
        h(Group, { key: 'sending', title: copy.sending },
          h('div', { className: 'h2s-card' },
            h(Row, {
              label: copy.enter,
              hint: copy.enterHint,
            }, h(Switch, {
              checked: settings.enterEnabled,
              label: copy.enter,
              onChange: (next) => update({ enterEnabled: next }),
            })),
            h('div', { className: `h2s-row${disabledRow}${settings.enterEnabled !== true ? ' h2s-dim' : ''}` },
              h('div', { className: 'h2s-rowText' }, h('span', { className: 'h2s-rowLabel' }, copy.style)),
              h('div', { className: 'h2s-rowControl' },
                h(Segmented, {
                  value: settings.enterStyle,
                  label: copy.style,
                  options: stylesFor(copy),
                  onChange: (next) => update({ enterStyle: next }),
                }))),
            h(Row, {
              label: copy.click,
              hint: copy.clickHint,
            }, h(Switch, {
              checked: settings.clickEnabled,
              label: copy.click,
              onChange: (next) => update({ clickEnabled: next }),
            })),
            h('div', { className: `h2s-row${settings.clickEnabled !== true ? ' h2s-dim' : ''}` },
              h('div', { className: 'h2s-rowText' }, h('span', { className: 'h2s-rowLabel' }, copy.style)),
              h('div', { className: 'h2s-rowControl' },
                h(Segmented, {
                  value: settings.clickStyle,
                  label: copy.style,
                  options: stylesFor(copy),
                  onChange: (next) => update({ clickStyle: next }),
                }))),
            h(Row, { label: copy.duration },
              h(Slider, {
                value: settings.sendHoldMs,
                label: copy.duration,
                copy,
                onChange: (next) => update({ sendHoldMs: next }),
              })))),
        h(Group, { key: 'stopping', title: copy.stopping },
          h('div', { className: 'h2s-card' },
            h(Row, { label: copy.stop, hint: copy.stopHint },
              h(Switch, {
                checked: settings.stopEnabled,
                label: copy.stop,
                onChange: (next) => update({ stopEnabled: next }),
              })),
            h('div', { className: `h2s-row${settings.stopEnabled !== true ? ' h2s-dim' : ''}` },
              h('div', { className: 'h2s-rowText' }, h('span', { className: 'h2s-rowLabel' }, copy.style)),
              h('div', { className: 'h2s-rowControl' },
                h(Segmented, {
                  value: settings.stopStyle,
                  label: copy.style,
                  options: stylesFor(copy),
                  onChange: (next) => update({ stopStyle: next }),
                }))),
            h(Row, { label: copy.stopDuration },
              h(Slider, {
                value: settings.stopHoldMs,
                label: copy.stopDuration,
                copy,
                onChange: (next) => update({ stopHoldMs: next }),
              })))),
        h(Group, { key: 'other', title: copy.other },
          h('div', { className: 'h2s-card' },
            h(Row, { label: copy.esc, hint: copy.escHint },
              h(Switch, {
                checked: settings.escCancel,
                label: copy.esc,
                onChange: (next) => update({ escCancel: next }),
              })),
            h(Row, { label: copy.keySend },
              h(Keys, { keys: rows.send.keys })),
            h(Row, { label: copy.keyComplementary },
              h(Keys, { keys: rows.complementary.keys })),
            h(Row, { label: copy.keyNewline },
              h(Keys, { keys: rows.newline.keys })),
            h(Row, { label: copy.keyStop },
              h(Keys, { keys: rows.stop.keys })),
            h('div', { className: 'h2s-row' },
              h('div', { className: 'h2s-rowText' },
                h('span', { className: 'h2s-rowLabel' }, copy.shortcuts),
                h('span', { className: 'h2s-rowHint' }, copy.shortcutsHint))))),
        h('div', { key: 'footer', className: 'h2s-footer' },
          h('button', {
            type: 'button',
            className: 'h2s-reset',
            onMouseDown: (event) => event.preventDefault(),
            onClick: () => store.reset(),
          }, copy.reset),
          h('span', { className: 'h2s-saved' }, copy.autosave)))
    }

    function SectionIcon(props) {
      const size = typeof props.size === 'number' && props.size > 0 ? props.size : 16
      const active = props.active === true
      const stroke = active ? 'var(--dsw-alias-label-primary)' : 'var(--dsw-alias-label-secondary, var(--dsw-alias-label-tertiary))'
      return h('svg', {
        width: size,
        height: size,
        viewBox: '0 0 16 16',
        fill: 'none',
        'aria-hidden': 'true',
        style: { color: stroke },
      },
      h('circle', { cx: 8, cy: 8, r: 5.9, stroke: 'currentColor', strokeWidth: 1.4, strokeOpacity: active ? 0.4 : 0.32 }),
      h('path', {
        d: 'M8 2.1a5.9 5.9 0 0 1 5.2 3.1',
        stroke: 'currentColor',
        strokeWidth: 1.6,
        strokeLinecap: 'round',
      }),
      h('path', {
        d: 'M8 5.2 10.4 8.4 9 8.4 9 11 7 11 7 8.4 5.6 8.4Z',
        fill: 'currentColor',
      }))
    }

    /* ------------------------------------------------------------------ */
    /* Plugin entry                                                        */
    /* ------------------------------------------------------------------ */

    function apply(ctx) {
      pluginCtx = ctx
      ctx.slots.inject('conversation.input.overlay', () => ctx.slots.register({
        name: 'conversation.input.overlay',
        id: 'dsh-hold-on',
        order: 20,
      }, HoldToSend))
      ctx.slots.inject('settings.section', () => ctx.slots.register({
        name: 'settings.section',
        id: 'dsh-hold-on',
        order: 85,
        label: () => copyFor(localeIdNow()).title,
      }, HoldSettingsPage))
      ctx.slots.inject('settings.section.icon', () => ctx.slots.register({
        name: 'settings.section.icon',
        id: 'dsh-hold-on',
        order: 85,
      }, SectionIcon))
    }

    return { inject: ['slots'], apply }
  },
})
