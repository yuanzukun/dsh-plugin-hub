# StyleVault 配置包 Schema

用于导入 / 导出 / 分享。目标：人能读、机可解析、方便社区传播。

## 顶层结构

```json
{
  "stylevault": "1.0",
  "name": "My Nord Soft",
  "description": "Nord base with softer accent for long sessions",
  "author": "optional-name",
  "createdAt": "2026-08-16T01:00:00.000Z",
  "basePreset": "nord",
  "colorScheme": "dark",
  "tokens": {
    "--dsw-alias-bg-base": "#2e3440",
    "--dsw-alias-bg-elevated": "#3b4252",
    "--dsw-alias-fg": "#eceff4",
    "--dsw-alias-accent": "#88c0d0"
  },
  "fonts": {
    "ui": "Inter, \"PingFang SC\", system-ui, sans-serif",
    "code": "\"JetBrains Mono\", ui-monospace, monospace",
    "uiSize": "14px",
    "codeSize": "13px"
  },
  "options": {
    "sidebarOpacity": 0.92,
    "contrast": 70,
    "radius": "8px"
  },
  "tags": ["nord", "soft", "long-session"]
}
```

## 字段说明

| 字段 | 必填 | 说明 |
|------|------|------|
| `stylevault` | 是 | Schema 版本，当前 `"1.0"` |
| `name` | 是 | 方案显示名 |
| `description` | 否 | 一句话描述，便于分享 |
| `author` | 否 | 作者昵称 |
| `createdAt` | 否 | ISO 时间 |
| `basePreset` | 推荐 | 基于哪个内置预设（用于「重置」参考） |
| `colorScheme` | 是 | `"light"` \| `"dark"` |
| `tokens` | 是 | CSS 变量覆盖表，只写需要覆盖的 key |
| `fonts` | 否 | UI/代码字体与字号 |
| `options` | 否 | 透明度、对比度、圆角等非 token 或映射项 |
| `tags` | 否 | 便于检索 |

## 导入规则

1. `stylevault` 版本不识别 → 提示升级/不兼容。
2. `tokens` 中未知 key → 忽略并 console.warn，不阻断。
3. 导入成功后：立即 `theme` 应用 + 可选「另存为我的方案」。
4. 空 `tokens` + 仅有 `basePreset` → 等同切换到该预设。

## 导出规则

- 导出**当前生效**状态（预设 + 所有 override），而不是原始预设。
- 自动填 `createdAt`；`name` 若为内置预设可生成为 `Nord (custom)` 等。

## 分享文案模板（一键复制）

```
🎨 StyleVault 配置：{name}
{description}

基于：{basePreset} · {colorScheme}

```json
{json}
```

导入：打开 DSH → Settings → StyleVault → 导入
```

---

此 Schema 为 Phase 1 锁定版本。后续只做向后兼容扩展，不随意破坏字段。
