# StyleVault Phase 1 — 高标准首发任务清单

> 目标：第一版就是完整主题系统，不是半成品。  
> 成功标准：社区愿意主动分享配置、真正满足长会话需求、具备被 awesome 推荐的品质。

---

## 0. 身份与基建

| ID | 任务 | 验收标准 | 状态 |
|----|------|----------|------|
| 0.1 | 正式命名 StyleVault / `dsh-stylevault` | package.json、README、PRD、cordis 一致 | ✅ |
| 0.2 | 客户端 `__ModuleLoader__` 正确注册 | 无 “loaded without registering” 错误 | ✅ 基本完成，需回归 |
| 0.3 | 真实 token 探测与映射表 | 在当前 rc 上 `theme.register` 后 body 上可见对应 CSS 变量变化 | ✅ |

---

## 1. 调色板层（内容资产）

| ID | 任务 | 验收标准 | 状态 |
|----|------|----------|------|
| 1.1 | 30 套忠实经典调色板 | 在 11 套基础上扩展 Dracula/One Dark/Rose Pine/Kanagawa/GitHub/OLED 等 | ✅ |
| 1.2 | 每套具备 name / nameEn / colorScheme / accent / tokens / tags | 结构统一，可被选择器与导出复用 | ✅ |
| 1.3 | 可读性专项检查 | 代码区、Diff、思考流、状态色在深/浅色下对比度可接受 | ✅ 已覆盖 code/bubble/sidebar/state tokens |
| 1.4 | 预览色块数据 | 每个预设导出 4～6 个关键色，供 UI 卡片使用 | ✅ swatches + 卡片网格 |

---

## 2. Style Settings 面板（核心体验）

| ID | 任务 | 验收标准 | 状态 |
|----|------|----------|------|
| 2.1 | 独立 Settings 页或高质量插槽入口 | 用户能在 2 次点击内进入 StyleVault 面板 | ✅ |
| 2.2 | 预设选择器（卡片网格） | 显示名称 + 主色预览；点击立即切换；当前项高亮 | ✅ |
| 2.3 | Live 可调项（见 IA 文档） | 拖动/改色后即时生效，无需刷新 | ✅ 颜色 + 字体 + 质感 |
| 2.4 | 重置为预设默认 | 一键丢弃当前微调，回到所选预设原值 | ✅ |
| 2.5 | 「另存为我的方案」 | 输入名称后写入本地方案列表，可再次选中 | ✅ |
| 2.6 | 方案管理 | 重命名、删除、设为默认（至少删除 + 选中） | ✅ 改名/删除/设默认 |

### Style Settings 可调项分组（信息架构）

**A. 预设**
- 预设卡片列表（系统内置）
- 我的方案列表

**B. 颜色**
- Accent
- 背景 Base / Elevated / Overlay
- 前景 Primary / Muted
- 边框
- Success / Warning / Error

**C. 字体与排版**
- UI 字体族
- 代码字体族
- UI 字号基准
- 代码字号基准（若 token 支持）

**D. 布局与质感**
- 侧栏透明度（或 fill 透明度）
- 整体对比度（若可映射）
- 圆角（若有对应 token）

**E. 操作**
- 重置当前预设
- 另存为我的方案
- 导出配置
- 导入配置
- 一键复制分享文案

---

## 3. 配置包与分享飞轮

| ID | 任务 | 验收标准 | 状态 |
|----|------|----------|------|
| 3.1 | 配置 JSON Schema 定稿 | 见 `docs/CONFIG-SCHEMA.md` | ✅ |
| 3.2 | 导出当前状态为 JSON | 包含预设 id、所有 override、元数据 | ✅ |
| 3.3 | 导入 JSON 并应用 | 非法结构有明确提示；合法则立即生效并可选另存 | ✅ |
| 3.4 | 一键复制分享文本 | 剪贴板包含简短说明 + 配置 JSON 或链接占位 | ✅ |
| 3.5 | localStorage 结构稳定 | 预设选择、用户方案、当前 override 分区清晰 | ✅ active/overrides/fonts/options/schemes/defaultScheme |

---

## 4. 增长与传播资产

| ID | 任务 | 验收标准 | 状态 |
|----|------|----------|------|
| 4.1 | README 重写为 StyleVault 叙事 | 30 秒看懂价值 + 安装 + 分享 | ✅ |
| 4.2 | 预览图（至少 3 张） | 深色预设对比、浅色、Style Settings 面板 | 🔲（可后补） |
| 4.3 | awesome / 社区发布文案模板 | 一键可发的短帖 + 长说明 | 🔲 |
| 4.4 | 控制台试用 API 保留 | `window.__STYLEVAULT__.set / list / export / import` | ✅ |

---

## 5. 质量与兼容

| ID | 任务 | 验收标准 | 状态 |
|----|------|----------|------|
| 5.1 | 与官方 Appearance 不冲突 | 切换官方主题后行为可预期；文档说明关系 | ✅ 面板底部说明 |
| 5.2 | 无主题时优雅降级 | `ctx.theme` 不存在时 console 警告，不白屏 | ✅ 已有 |
| 5.3 | 首屏/注册性能可接受 | 注册 11+ 方案不造成明显卡顿 | ✅ 轻量 register |
| 5.4 | 中英文基础文案 | 面板关键标签双语或跟随 locale | ✅ 中英并列关键标签 |

---

## Phase 1 完成定义（Definition of Done）

- [x] 用户可在设置中打开 StyleVault 完整面板
- [x] 可切换全部内置预设，并 live 调整颜色/字体等
- [x] 可另存为我的方案，并再次选中
- [x] 可导出 JSON、导入 JSON、复制分享文案
- [x] 核心区域（对话、代码、状态）在常见预设下可读（token 覆盖）
- [x] README + 控制台 API 可用
- [x] 无阻断性加载错误（已 link 安装 + 浏览器回归：Settings→StyleVault / set/export/import 通过）

达到以上即可作为 **v0.1.0 公开发布候选**。
