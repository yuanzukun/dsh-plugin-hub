#!/usr/bin/env bash
# StyleVault 本机一键安装脚本
# 用法：
#   chmod +x install.sh && ./install.sh
# 可选：
#   ./install.sh --no-start          # 只安装，不启动 web
#   ./install.sh --path /path/to/dir # 指定插件目录（默认脚本所在目录）

set -euo pipefail

NO_START=0
PLUGIN_DIR=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --no-start) NO_START=1; shift ;;
    --path) PLUGIN_DIR="$2"; shift 2 ;;
    -h|--help)
      echo "Usage: $0 [--no-start] [--path /path/to/dsh-stylevault]"
      exit 0
      ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

# 默认：脚本所在目录即插件根目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_DIR="${PLUGIN_DIR:-$SCRIPT_DIR}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'
info()  { echo -e "${GREEN}[StyleVault]${NC} $*"; }
warn()  { echo -e "${YELLOW}[StyleVault]${NC} $*"; }
error() { echo -e "${RED}[StyleVault]${NC} $*"; exit 1; }

echo ""
info "=== StyleVault 本机一键安装 ==="
info "插件目录: $PLUGIN_DIR"
echo ""

# ---- 1. Node.js ----
if ! command -v node >/dev/null 2>&1; then
  error "未检测到 Node.js。请先安装 Node.js ≥ 22：https://nodejs.org/"
fi

NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]")"
if [[ "$NODE_MAJOR" -lt 22 ]]; then
  error "当前 Node $(node -v)，需要 ≥ 22。请升级后重试。"
fi
info "Node $(node -v) OK"

# ---- 2. npm / corepack / pnpm ----
if ! command -v npm >/dev/null 2>&1; then
  error "未检测到 npm（通常随 Node 安装）。"
fi

if command -v corepack >/dev/null 2>&1; then
  info "启用 Corepack + pnpm…"
  corepack enable 2>/dev/null || true
  corepack prepare pnpm@latest --activate 2>/dev/null || true
else
  warn "无 corepack，尝试 npm i -g pnpm"
  npm install -g pnpm 2>/dev/null || warn "pnpm 安装失败，dsh 插件管理可能受影响"
fi

if command -v pnpm >/dev/null 2>&1; then
  info "pnpm $(pnpm -v) OK"
else
  warn "仍无 pnpm，继续尝试（dsh 可能自行处理）"
fi

# ---- 3. 安装 dsh CLI ----
if command -v dsh >/dev/null 2>&1; then
  info "已安装 dsh: $(dsh --version 2>/dev/null || echo present)"
else
  info "安装 @deepseek-ai/dsh 全局包…"
  npm install -g @deepseek-ai/dsh
  command -v dsh >/dev/null 2>&1 || error "dsh 安装后仍不在 PATH，请检查 npm 全局 bin 目录"
  info "dsh $(dsh --version) 安装完成"
fi

# ---- 4. 检查插件文件 ----
if [[ ! -f "$PLUGIN_DIR/package.json" ]]; then
  error "目录下没有 package.json：$PLUGIN_DIR
请确认已把 StyleVault 项目放到本机，并在该目录运行本脚本。"
fi

PKG_NAME="$(node -p "require('$PLUGIN_DIR/package.json').name" 2>/dev/null || echo dsh-stylevault)"
if [[ ! -f "$PLUGIN_DIR/lib/client.js" ]]; then
  error "缺少 lib/client.js。请使用完整项目目录。"
fi
info "检测到插件包: $PKG_NAME"

# ---- 5. link 到 web profile ----
info "将插件加入 dsh web profile（link 本地目录）…"
dsh plugin --profile web add "link:$PLUGIN_DIR"
info "插件已注册"

# ---- 6. 完成提示 / 启动 ----
echo ""
info "=== 安装完成 ==="
echo ""
echo "  启动命令:  dsh web"
echo "  浏览器:    http://127.0.0.1:3080"
echo ""
echo "  进入后: Settings → StyleVault"
echo "  或控制台:"
echo "    __STYLEVAULT__.list()"
echo "    __STYLEVAULT__.set('nord')"
echo ""

if [[ "$NO_START" -eq 1 ]]; then
  info "已跳过启动（--no-start）。需要时请手动执行: dsh web"
  exit 0
fi

info "正在启动 dsh web …"
echo "  （按 Ctrl+C 可停止）"
echo ""
exec dsh web
