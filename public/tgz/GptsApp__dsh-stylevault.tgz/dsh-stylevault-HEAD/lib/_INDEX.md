# lib/

StyleVault 运行时：服务端入口 + web client 注入。

| 文件 | 地位 | 功能 |
|------|------|------|
| `index.js` | 服务端入口 | 插件注册 / cordis 绑定（no-op host，呈现全部在客户端） |
| `client.js` | 客户端主模块 | 30 套预设主题、Style Settings 面板、统一字号阶梯、多源 webfont 加载、agent 表面 CSS；设置面板中英双语（跟随 `navigator.language`，v0.3.0） |

自指：本目录文件增删或 `client.js` 公开 API 变更时更新此文件。
