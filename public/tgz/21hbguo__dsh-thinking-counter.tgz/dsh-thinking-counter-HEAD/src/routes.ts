/**
 * dsh-thinking-counter HTTP routes — the browser half polls one same-origin
 * JSON endpoint for the live snapshot, subscribes to one SSE endpoint for
 * instant "data changed" signals (poll stays as fallback/reconnect), and
 * posts config changes (enable/stop/matchers/reset) to the host. It also
 * serves the whale-girl state GIFs from `/thinking-counter/whale/*`.
 * `POST /api/thinking-counter/config`, `GET /api/thinking-counter/snapshot`,
 * `GET /api/thinking-counter/stream`.
 * @module @dsh-external/dsh-thinking-counter/routes
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import { readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import {
  setEnabled,
  setMatchers,
  snapshot,
  type EngineState,
  type MatcherInput,
} from './counting.js'

/** Browser-facing base path of the thinking-counter API. */
export const THINKING_COUNTER_API_PREFIX = '/api/thinking-counter'

/** Browser-facing base path of the whale-girl state images. */
export const THINKING_COUNTER_ASSET_PREFIX = '/thinking-counter/whale'

/** Static whale-girl state images served from package assets (MIT, see THIRD_PARTY_NOTICES.md). */
const WHALE_ASSET_FILES = [
  { name: 'idle.webp', mime: 'image/webp' },
  { name: 'slack.webp', mime: 'image/webp' },
  { name: 'deadline.webp', mime: 'image/webp' },
  { name: 'celebrate.webp', mime: 'image/webp' },
] as const

/** Absolute package root, resolved from this module's own location (src/ → lib/). */
const PACKAGE_ROOT = fileURLToPath(new URL('../', import.meta.url))

/** Max request body accepted by the config endpoint. */
const MAX_BODY_BYTES = 16 * 1024

/** Write one JSON response. */
function json(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(body))
}

/** Read a bounded JSON request body. */
async function readJsonBody(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += buffer.length
    if (size > MAX_BODY_BYTES) throw new Error('body-too-large')
    chunks.push(buffer)
  }
  if (chunks.length === 0) return {}
  return JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown
}

/** Validate one config field and apply it to the engine state. */
function applyConfigField(
  state: EngineState,
  field: string,
  value: unknown,
): void {
  switch (field) {
    case 'enabled':
      if (typeof value !== 'boolean') throw new Error('enabled must be boolean')
      setEnabled(state, value, Date.now())
      return
    case 'matchers':
      if (!isMatcherList(value)) throw new Error('matchers must be (string | { pattern, caseSensitive? })[]')
      setMatchers(state, value as MatcherInput[])
      return
    case 'matchVisible':
      if (typeof value !== 'boolean') throw new Error('matchVisible must be boolean')
      state.matchVisible = value
      return
    default:
      throw new Error(`unknown field: ${field}`)
  }
}

/** Wire-form matcher list check: strings or `{ pattern, caseSensitive?, group? }`. */
function isMatcherList(value: unknown): boolean {
  if (!Array.isArray(value)) return false
  return value.every(item => {
    if (typeof item === 'string') return true
    if (item === null || typeof item !== 'object') return false
    const record = item as Record<string, unknown>
    return typeof record.pattern === 'string'
      && (record.caseSensitive === undefined || typeof record.caseSensitive === 'boolean')
      && (record.group === undefined
        || record.group === 'neutral' || record.group === 'negative' || record.group === 'positive')
  })
}

/** Build the full route family for one thinking-counter engine. */
export function makeThinkingCounterRoutes(deps: {
  state: EngineState
  /** SSE 客户端集合：连接注册/注销由路由管理，心跳与信号帧由宿主写入。 */
  sseClients: Set<ServerResponse>
  /** 配置变更后落盘（词表/开关持久化到 DSH 插件专属数据目录）。 */
  persist: () => void
  /** 显式清空计数器（保留 enabled/matchers 配置）。 */
  reset: () => void
}): WebRoute[] {
  const { state, sseClients, persist, reset } = deps
  return [
    {
      kind: 'exact',
      path: `${THINKING_COUNTER_API_PREFIX}/snapshot`,
      handler: (req: IncomingMessage, res: ServerResponse): void => {
        if (req.method !== 'GET') {
          json(res, 405, { ok: false, error: 'method-not-allowed' })
          return
        }
        json(res, 200, snapshot(state, Date.now()))
      },
    },
    {
      kind: 'exact',
      path: `${THINKING_COUNTER_API_PREFIX}/config`,
      handler: (req: IncomingMessage, res: ServerResponse): void => {
        if (req.method !== 'POST') {
          json(res, 405, { ok: false, error: 'method-not-allowed' })
          return
        }
        void (async () => {
          try {
            const body = await readJsonBody(req)
            if (body === null || typeof body !== 'object' || Array.isArray(body)) {
              json(res, 400, { ok: false, error: 'body must be an object' })
              return
            }
            const record = body as Record<string, unknown>
            // 显式清空优先应用；随后按字段顺序应用其余配置。
            if (record.reset === true) reset()
            for (const [field, value] of Object.entries(record)) {
              if (field === 'reset') continue
              applyConfigField(state, field, value)
            }
            // 任何配置变更（开关/词表/含可见文本/重置）都落盘，保证重启后可恢复。
            persist()
            json(res, 200, { ok: true, ...snapshot(state, Date.now()) })
          } catch (error) {
            const message = error instanceof Error ? error.message : String(error)
            json(res, message === 'body-too-large' ? 413 : 400, { ok: false, error: message })
          }
        })()
      },
    },
    {
      kind: 'exact',
      path: `${THINKING_COUNTER_API_PREFIX}/stream`,
      handler: (req: IncomingMessage, res: ServerResponse): void => {
        if (req.method !== 'GET') {
          json(res, 405, { ok: false, error: 'method-not-allowed' })
          return
        }
        res.writeHead(200, {
          'content-type': 'text/event-stream; charset=utf-8',
          'cache-control': 'no-cache',
          connection: 'keep-alive',
          'x-accel-buffering': 'no',
        })
        res.write(': connected\n\n')
        sseClients.add(res)
        req.on('close', () => { sseClients.delete(res) })
      },
    },
    ...WHALE_ASSET_FILES.map((file): WebRoute => ({
      kind: 'exact',
      path: `${THINKING_COUNTER_ASSET_PREFIX}/${file.name}`,
      handler: (req: IncomingMessage, res: ServerResponse): void => {
        if (req.method !== 'GET' && req.method !== 'HEAD') {
          res.writeHead(405)
          res.end()
          return
        }
        void readFile(join(PACKAGE_ROOT, 'assets', 'whale', file.name)).then((body) => {
          res.writeHead(200, {
            'content-type': file.mime,
            'content-length': String(body.byteLength),
            'cache-control': 'public, max-age=3600',
          })
          if (req.method === 'HEAD') {
            res.end()
            return
          }
          res.end(body)
        }, () => {
          res.writeHead(404)
          res.end()
        })
      },
    })),
  ]
}
