/**
 * dsh-thinking-counter — host 半区：thinking（reasoning）短语检测统计。
 *
 * 从浏览器面板「启动」的时刻起，对**所有**正在运行/新运行的会话（含子代理）
 * 的 session 事件流做实时记账：结构化思考块数、思考字符数、以及用户自定义
 * 短语（如 `let me` / `we should`）在思考段文本内的出现次数（跨 chunk 边界
 * 不丢、与最终消息去重）。未开启期间的事件一律不计；每次开启 = 清零重开；
 * 关闭 = 冻结保留；另有显式 reset。
 *
 * 提供三条浏览器端点：
 *   POST /api/thinking-counter/config   —— 启动/停止/匹配词/清空
 *   GET  /api/thinking-counter/snapshot —— 快照（轮询）
 *   GET  /api/thinking-counter/stream   —— SSE changed 信号（500ms 节流）
 * @module @dsh-external/dsh-thinking-counter
 */
import type { Context } from '@deepseek-ai/cordis'
import Schema from 'schemastery'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import type {} from '@deepseek-ai/dsh-host-webserver'
import {
  createEngine,
  setEnabled,
  setMatchers,
  applyEvent,
  disposeSession,
  resetCounters,
  snapshot,
  type EngineState,
  type MatcherInput,
  type SessionEventLike,
} from './counting.js'
import { makeThinkingCounterRoutes } from './routes.js'

/** Services required by the host half. */
export const inject = ['webServer'] as const

/** Host session-event hook faces (declared here like agent-board does; the
 *  session plugin's own augmentation lives outside this program's graph). */
declare module '@deepseek-ai/cordis' {
  interface Events {
    'session/event'(session: { id: string }, event: SessionEventLike): void
    'session/disposed'(session: { id: string }): void
  }
}

/** Plugin configuration (composition entry; runtime control is client-driven). */
export interface Config {
  /** Master switch: when false the listener and routes are not registered. */
  enabled?: boolean
}

/** Runtime schema for {@link Config}. */
export const Config: Schema<Config> = Schema.object({
  enabled: Schema.boolean().default(true),
})

/**
 * 持久化配置文件路径：词表/开关/含可见文本 的权威存储。
 * 放在插件自己的数据空间 `~/.dsh/plugins/<plugin>/` 下，不散落到
 * `~/.dsh` 根目录（他人使用插件时只有一个专属子目录）。
 * 解决浏览器 localStorage 丢失/换 origin/隐私模式下「检测词看不见」——
 * host 重启或热重载后从磁盘恢复，client bootSync 再从 host 回填本地。
 */
const PERSIST_DIR = join(homedir(), '.dsh', 'plugins', 'dsh-thinking-counter')
const PERSIST_PATH = join(PERSIST_DIR, 'config.json')
/** 旧版根目录散落文件（v0.1.0 之前），自动迁移后清理。 */
const LEGACY_PERSIST_PATH = join(homedir(), '.dsh', 'dsh-thinking-counter.json')

/** 磁盘上保存的配置面（MatcherInput 兼容旧格式）。 */
interface PersistedConfig {
  enabled?: boolean
  matchers?: MatcherInput[]
  matchVisible?: boolean
}

/** 读磁盘配置（容错：文件缺失/损坏返回空；含旧路径一次性迁移）。 */
function loadPersistedConfig(): PersistedConfig {
  const read = (path: string): PersistedConfig | null => {
    try {
      if (!existsSync(path)) return null
      const parsed = JSON.parse(readFileSync(path, 'utf8')) as PersistedConfig
      return parsed !== null && typeof parsed === 'object' ? parsed : null
    } catch {
      return null
    }
  }
  const current = read(PERSIST_PATH)
  if (current !== null) return current
  const legacy = read(LEGACY_PERSIST_PATH)
  if (legacy !== null) {
    // 旧版根目录文件 → 迁移到插件专属空间，并清理散落文件。
    try {
      mkdirSync(PERSIST_DIR, { recursive: true })
      const body = JSON.stringify(legacy)
      const tmp = `${PERSIST_PATH}.tmp`
      writeFileSync(tmp, body, 'utf8')
      renameSync(tmp, PERSIST_PATH)
      rmSync(LEGACY_PERSIST_PATH, { force: true })
    } catch {
      /* 迁移失败不致命：下次 persist 仍会写新位置 */
    }
    return legacy
  }
  return {}
}

/** 写磁盘配置（临时文件 + rename 原子替换；失败静默，统计不中断）。 */
function persistConfig(state: EngineState): void {
  try {
    mkdirSync(PERSIST_DIR, { recursive: true })
    const body = JSON.stringify({
      enabled: state.enabled,
      matchers: state.matchers.map(m => ({
        pattern: m.pattern,
        caseSensitive: m.caseSensitive,
        group: m.group,
      })),
      matchVisible: state.matchVisible,
    })
    const tmp = `${PERSIST_PATH}.tmp`
    writeFileSync(tmp, body, 'utf8')
    renameSync(tmp, PERSIST_PATH)
  } catch {
    /* 写盘失败静默：面板仍可用，只是重启后不回恢复词表 */
  }
}

/**
 * Mount the counting listener and browser routes.
 * @param ctx - host plugin context carrying webServer.
 * @param config - resolved plugin config (schema defaults applied by the loader).
 */
export function apply(ctx: Context, config: Config = {}): void {
  if ((config.enabled ?? true) === false) {
    ctx.logger.info('[thinking-counter] disabled by config')
    return
  }

  const state: EngineState = createEngine()

  // 从磁盘恢复上次的开关/词表/含可见文本（host 重启、热重载都不丢词表）。
  const saved = loadPersistedConfig()
  if (saved.enabled === true) setEnabled(state, true, Date.now())
  if (saved.matchVisible === true) state.matchVisible = true
  if (Array.isArray(saved.matchers)) setMatchers(state, saved.matchers)

  /** SSE 客户端集合：连接注册/注销由路由管理，心跳与信号帧由宿主写入。 */
  const sseClients = new Set<ServerResponse>()

  /** SSE changed-signal broadcaster (throttled 500ms for streaming bursts). */
  let notifyTimer: NodeJS.Timeout | undefined
  const notifyChanged = (): void => {
    if (notifyTimer !== undefined) return
    notifyTimer = setTimeout(() => {
      notifyTimer = undefined
      for (const res of sseClients) {
        try { res.write('data: changed\n\n') } catch { /* 已断开连接忽略 */ }
      }
    }, 500)
  }

  // Global session-event tap: every live session (root + subagents) flows
  // through here regardless of which session the browser has open.
  ctx.on('session/event', (session: { id: string }, event: SessionEventLike) => {
    try {
      applyEvent(state, session.id, event)
      notifyChanged()
    } catch (error) {
      ctx.logger.warn(
        '[thinking-counter] applyEvent failed: %s',
        error instanceof Error ? error.message : String(error),
      )
    }
  })

  ctx.on('session/disposed', (session: { id: string }) => {
    disposeSession(state, session.id)
    notifyChanged()
  })

  // SSE 心跳：30s 注释帧防代理断连。
  ctx.effect(() => {
    const heartbeat = setInterval(() => {
      for (const res of sseClients) {
        try { res.write(': ping\n\n') } catch { /* 已断开连接忽略 */ }
      }
    }, 30_000)
    return () => clearInterval(heartbeat)
  }, 'dsh-thinking-counter: sse heartbeat')

  ctx.effect(() => {
    const disposers = makeThinkingCounterRoutes({
      state,
      sseClients,
      persist: () => persistConfig(state),
      reset: () => {
        resetCounters(state)
        // 重置 = 从当前时刻重新起算统计窗口（匹配词保留）。
        if (state.enabled) state.since = Date.now()
      },
    }).map(route => ctx.webServer.register(route))
    return () => { for (const dispose of disposers) dispose() }
  }, 'dsh-thinking-counter: routes')

  ctx.logger.info('[thinking-counter] armed (waiting for panel start)')
}

export type { IncomingMessage } from 'node:http'
export { snapshot } from './counting.js'
export type {
  EngineState, Matcher, RecentHit, SessionCounter, SessionStat, ThinkingSnapshot, ThinkingTotals,
} from './counting.js'
