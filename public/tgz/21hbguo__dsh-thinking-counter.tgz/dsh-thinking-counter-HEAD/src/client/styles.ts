/**
 * dsh-thinking-counter panel styles. Single injected <style>; shell theme
 * tokens (--dsw-alias-*) with dark/light fallbacks (agent-board precedent).
 * The visual language stays inside the panel itself: a few local design
 * tokens, restrained radii/spacing, and clear hover/active/empty states.
 * @module @dsh-external/dsh-thinking-counter/client/styles
 */

/** Full CSS for the popover panel, chips, session rows, and button badge. */
export const PANEL_CSS = `
.tc-action {
  display: flex; align-items: center; justify-content: center; gap: 6px; cursor: pointer;
  color: inherit; border: none; background: none; padding: 6px 8px; width: 100%;
  font: inherit; text-align: left; border-radius: 8px;
  transition: color 0.18s ease, background-color 0.18s ease, transform 0.12s ease;
}
.tc-action:hover { color: #4ade80; background: rgba(74, 222, 128, 0.08); }
.tc-action:active { transform: scale(0.97); }
/* wide 双行：上行名称 + 下行聪明程度进度条 */
.tc-action-wide { flex-direction: column; align-items: stretch; gap: 3px; text-align: left; }
.tc-action-name {
  display: flex; align-items: center; gap: 6px; min-width: 0;
  flex-wrap: nowrap; white-space: nowrap; overflow: hidden;
}
.tc-action-name > span { flex: none; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.tc-action-pct {
  flex: none; margin-left: auto; font-size: 10px; font-weight: 800; font-variant-numeric: tabular-nums;
}
.tc-action-bar {
  display: block; height: 4px; border-radius: 999px; overflow: hidden; width: 100%;
  background: rgba(128, 128, 128, 0.25);
}
.tc-action-fill {
  display: block; height: 100%; border-radius: 999px;
  transition: width 0.4s ease;
}

.tc-panel {
  --tc-space-1: 4px;
  --tc-space-2: 8px;
  --tc-space-3: 12px;
  --tc-space-4: 16px;
  --tc-radius-sm: 6px;
  --tc-radius-md: 10px;
  --tc-radius-lg: 14px;
  --tc-success: #4ade80;
  --tc-warning: #fbbf24;
  --tc-danger: #f87171;
  --tc-accent: var(--dsw-alias-brand-primary, #9ad0ff);
  --tc-text-primary: var(--dsw-alias-label-primary, #e6e6e6);
  --tc-text-secondary: var(--dsw-alias-label-secondary, #9aa0a6);
  --tc-text-tertiary: var(--dsw-alias-label-tertiary, #8b93a1);
  --tc-border: var(--dsw-alias-border-l2, rgba(255, 255, 255, 0.14));
  --tc-border-soft: var(--dsw-alias-border-l1, rgba(255, 255, 255, 0.08));
  --tc-bg: var(--dsw-alias-bg-overlay, rgba(17, 17, 20, 0.92));
  --tc-layer-1: var(--dsw-alias-bg-layer-1, rgba(255, 255, 255, 0.04));
  --tc-layer-2: var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.06));

  margin: 8px; height: calc(100% - 16px);
  display: flex; flex-direction: column; overflow: hidden;
  font: 12px/1.6 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  color: var(--tc-text-primary);
  background: var(--tc-bg);
  -webkit-backdrop-filter: blur(14px) saturate(1.1);
  backdrop-filter: blur(14px) saturate(1.1);
  border: 1px solid var(--tc-border);
  border-radius: var(--tc-radius-lg);
  box-shadow: 0 8px 28px rgba(0, 0, 0, 0.45), 0 2px 8px rgba(0, 0, 0, 0.24);
}
.tc-panel * { box-sizing: border-box; }

.tc-head {
  display: flex; align-items: center; gap: 8px; padding: 8px 12px;
  border-bottom: 1px solid var(--tc-border-soft);
  background: linear-gradient(135deg, rgba(154, 208, 255, 0.08), transparent 55%);
  user-select: none;
}
.tc-title {
  flex: 1; font-weight: 800; font-size: 13px; letter-spacing: 0.01em;
  color: var(--dsw-alias-brand-primary, #9ad0ff);
  display: flex; align-items: center; gap: 6px; min-width: 0;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.tc-status {
  flex: none; display: inline-flex; align-items: center; gap: 5px;
  padding: 2px 8px; border-radius: 999px; font-size: 10px; font-weight: 700;
  color: var(--tc-text-secondary); background: var(--tc-layer-2);
  border: 1px solid var(--tc-border-soft);
}
.tc-status::before {
  content: ''; width: 6px; height: 6px; border-radius: 50%;
  background: currentColor; opacity: 0.7;
}
.tc-status.on { color: var(--tc-success); border-color: rgba(74, 222, 128, 0.3); background: rgba(74, 222, 128, 0.08); }
.tc-status.off { color: var(--tc-text-tertiary); }
.tc-visible {
  display: flex; align-items: center; gap: 4px; cursor: pointer;
  color: var(--tc-text-secondary); font-size: 11px; user-select: none;
  padding: 2px 6px; border-radius: 6px; transition: background-color 0.18s ease, color 0.18s ease;
}
.tc-visible:hover { background: var(--tc-layer-1); color: var(--tc-text-primary); }
.tc-visible input { accent-color: var(--tc-success); cursor: pointer; }
.tc-body { flex: 1; min-height: 0; overflow-y: auto; padding: 10px 12px; }
.tc-body::-webkit-scrollbar, .tc-hits::-webkit-scrollbar { width: 6px; }
.tc-body::-webkit-scrollbar-thumb, .tc-hits::-webkit-scrollbar-thumb {
  background: var(--tc-layer-2); border-radius: 999px;
}
.tc-body::-webkit-scrollbar-thumb:hover, .tc-hits::-webkit-scrollbar-thumb:hover {
  background: var(--tc-text-tertiary);
}

.tc-switch-row { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.tc-switch {
  flex: none; width: 96px; padding: 5px 0; border-radius: 8px; cursor: pointer;
  background: var(--tc-layer-1); font: inherit; font-weight: 800; font-size: 12px;
  color: var(--tc-text-secondary);
  border: 1px solid var(--tc-border);
  transition: color 0.18s ease, background-color 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease, transform 0.12s ease;
}
.tc-switch:hover { color: var(--tc-text-primary); border-color: var(--tc-text-tertiary); }
.tc-switch:active { transform: scale(0.96); }
.tc-switch.on {
  color: #0f172a; background: var(--tc-success); border-color: var(--tc-success);
  box-shadow: 0 0 12px rgba(74, 222, 128, 0.35);
}
.tc-since { color: var(--tc-text-tertiary); font-size: 11px; }

.tc-cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 12px; }
.tc-card {
  display: flex; flex-direction: column; align-items: center; gap: 3px; padding: 8px 2px;
  border-radius: var(--tc-radius-md); background: var(--tc-layer-1);
  border: 1px solid transparent; transition: transform 0.15s ease, border-color 0.15s ease, background-color 0.15s ease;
}
.tc-card:hover { transform: translateY(-1px); border-color: var(--tc-border-soft); background: var(--tc-layer-2); }
.tc-card-icon { font-size: 14px; line-height: 1; }
.tc-card b { font-size: 16px; font-weight: 800; font-variant-numeric: tabular-nums; }
.tc-card span:last-child { font-size: 10px; color: var(--tc-text-tertiary); }

/* 大胖鲸聪明程度行：独立醒目容器（进度条 + 判定） */
.tc-smart {
  margin-bottom: 12px; padding: 10px 12px; border-radius: var(--tc-radius-lg);
  border: 1px solid var(--tc-border);
  background: linear-gradient(135deg, rgba(154, 208, 255, 0.10), rgba(255, 255, 255, 0.03));
}
.tc-smart-head { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; margin-bottom: 6px; }
.tc-smart-title { font-weight: 800; font-size: 12px; color: var(--tc-text-primary); }
.tc-whale {
  display: flex; justify-content: center; align-items: center;
  margin: 2px 0 8px; min-height: 60px;
}
.tc-whale-img {
  height: 92px; width: auto; max-width: 140px; object-fit: contain;
  filter: drop-shadow(0 4px 12px rgba(0, 0, 0, 0.35));
}
.tc-smart-verdict { font-size: 11px; font-weight: 700; color: var(--tc-text-tertiary); }
.tc-smart.good .tc-smart-verdict { color: var(--tc-success); }
.tc-smart.mid .tc-smart-verdict { color: var(--tc-warning); }
.tc-smart.weak .tc-smart-verdict { color: var(--tc-danger); }
.tc-smart-bar {
  height: 8px; border-radius: 999px; overflow: hidden;
  background: var(--tc-layer-2);
}
.tc-smart-fill {
  height: 100%; width: 0; border-radius: 999px;
  background: linear-gradient(90deg, #6b7280, #9aa0a6);
  transition: width 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}
.tc-smart.good .tc-smart-fill { background: linear-gradient(90deg, #22c55e, var(--tc-success)); box-shadow: 0 0 10px rgba(74, 222, 128, 0.6); }
.tc-smart.mid .tc-smart-fill { background: linear-gradient(90deg, #d97706, var(--tc-warning)); box-shadow: 0 0 8px rgba(251, 191, 36, 0.4); }
.tc-smart.weak .tc-smart-fill { background: linear-gradient(90deg, #dc2626, var(--tc-danger)); box-shadow: 0 0 8px rgba(248, 113, 113, 0.4); }
.tc-smart-foot { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; margin-top: 6px; }
.tc-smart-pct { font-size: 20px; font-weight: 800; font-variant-numeric: tabular-nums; color: var(--tc-text-primary); }
.tc-smart-hint { font-size: 10px; color: var(--tc-text-tertiary); }

/* 可折叠分区：details/summary 原生折叠，保留展开状态 */
.tc-section { display: block; margin-bottom: 12px; }
.tc-section-title {
  display: flex; align-items: center; gap: 6px;
  font-size: 11px; font-weight: 700; color: var(--tc-text-secondary);
  margin-bottom: 4px; padding: 3px 4px; border-radius: 6px; cursor: pointer;
  user-select: none; list-style: none;
  transition: color 0.18s ease, background-color 0.18s ease;
}
.tc-section-title::-webkit-details-marker { display: none; }
.tc-section-title:hover { color: var(--tc-text-primary); background: var(--tc-layer-1); }
.tc-caret {
  display: inline-block; font-size: 10px; color: var(--tc-text-tertiary);
  transition: transform 0.18s ease;
}
details[open] > .tc-section-title .tc-caret { transform: rotate(90deg); }

.tc-chips { display: block; }
.tc-group {
  margin-bottom: 6px; padding: 6px 8px; border-radius: var(--tc-radius-md);
  border: 1px solid var(--tc-border-soft);
  background: var(--tc-layer-1);
  transition: border-color 0.18s ease, background-color 0.18s ease;
}
.tc-group.drag-over {
  border-color: var(--tc-accent);
  background: rgba(154, 208, 255, 0.08);
}
.tc-group-head {
  display: flex; align-items: center; justify-content: space-between; gap: 6px;
  font-size: 11px; margin-bottom: 4px; color: var(--tc-text-secondary);
}
.tc-group-head::before {
  content: ''; width: 6px; height: 6px; border-radius: 50%;
  background: #6ba4ff; margin-right: 2px;
}
.tc-group[data-group='negative'] .tc-group-head::before { background: var(--tc-danger); }
.tc-group[data-group='positive'] .tc-group-head::before { background: var(--tc-success); }
.tc-group-head .tc-group-sum {
  margin-left: auto; font-size: 10px; color: var(--tc-text-tertiary);
  font-variant-numeric: tabular-nums;
}
.tc-group[data-group='negative'] .tc-group-head { color: var(--tc-danger); }
.tc-group[data-group='positive'] .tc-group-head { color: var(--tc-success); }
.tc-group-chips { display: flex; flex-wrap: wrap; gap: 5px; min-height: 20px; }

.tc-chip {
  display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px;
  border-radius: 999px; font-size: 11px; cursor: grab;
  background: var(--tc-layer-2); border: 1px solid var(--tc-border);
  transition: transform 0.12s ease, border-color 0.15s ease, background-color 0.15s ease, box-shadow 0.15s ease;
}
.tc-chip:hover { transform: translateY(-1px); box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25); }
.tc-chip:active { cursor: grabbing; transform: translateY(0); }
.tc-group[data-group='neutral'] .tc-chip { border-color: rgba(96, 165, 250, 0.32); background: rgba(96, 165, 250, 0.08); }
.tc-group[data-group='negative'] .tc-chip { border-color: rgba(248, 113, 113, 0.32); background: rgba(248, 113, 113, 0.08); }
.tc-group[data-group='positive'] .tc-chip { border-color: rgba(74, 222, 128, 0.32); background: rgba(74, 222, 128, 0.08); }
.tc-chip b { font-variant-numeric: tabular-nums; font-weight: 700; }
.tc-chip.zero { opacity: 0.55; }
.tc-chip .del {
  cursor: pointer; border: none; background: none; padding: 0 2px; font-size: 13px;
  color: var(--tc-text-tertiary); border-radius: 4px; line-height: 1;
  transition: color 0.15s ease, background-color 0.15s ease;
}
.tc-chip .del:hover { color: var(--tc-danger); background: rgba(248, 113, 113, 0.12); }
/* 大小写模式徽标：aa = 不区分（默认），Aa = 区分；点击切换 */
.tc-chip .mode {
  cursor: pointer; border: 1px solid transparent; background: none; padding: 0 3px;
  border-radius: 4px; font-size: 10px; line-height: 1.5;
  color: var(--tc-text-tertiary); transition: color 0.15s ease, border-color 0.15s ease;
}
.tc-chip .mode:hover { border-color: var(--tc-border); }
.tc-chip .mode.cs {
  color: var(--tc-accent); border-color: rgba(154, 208, 255, 0.4);
  background: rgba(154, 208, 255, 0.08);
}
.tc-mode-btn {
  flex: none; padding: 4px 9px; border-radius: var(--tc-radius-sm); cursor: pointer; font: inherit;
  border: 1px solid var(--tc-border); background: var(--tc-layer-1);
  color: var(--tc-text-secondary); transition: color 0.18s ease, border-color 0.18s ease, background-color 0.18s ease;
}
.tc-mode-btn:hover { color: var(--tc-text-primary); border-color: var(--tc-text-tertiary); }
.tc-mode-btn.cs {
  color: var(--tc-accent); border-color: rgba(154, 208, 255, 0.45);
  background: rgba(154, 208, 255, 0.08);
}
/* 添加行分组选择器 */
.tc-group-select {
  flex: none; padding: 4px 6px; border-radius: var(--tc-radius-sm); font: inherit; color: inherit;
  border: 1px solid var(--tc-border); background: var(--tc-layer-1);
  cursor: pointer;
}
.tc-group-select option { color: #111827; }
.tc-empty { color: var(--tc-text-tertiary); font-size: 11px; padding: 4px 2px; }
.tc-add-row { display: flex; gap: 6px; margin-top: 6px; }
.tc-add-input {
  flex: 1; min-width: 0; padding: 4px 9px; border-radius: var(--tc-radius-sm); font: inherit; color: inherit;
  border: 1px solid var(--tc-border); background: transparent;
  transition: border-color 0.18s ease, box-shadow 0.18s ease;
}
.tc-add-input:focus {
  outline: none; border-color: var(--tc-accent);
  box-shadow: 0 0 0 2px rgba(154, 208, 255, 0.18);
}
.tc-add-btn {
  flex: none; padding: 4px 12px; border-radius: var(--tc-radius-sm); cursor: pointer; font: inherit;
  border: 1px solid var(--tc-border); background: var(--tc-layer-1); color: var(--tc-text-secondary);
  transition: color 0.18s ease, border-color 0.18s ease, background-color 0.18s ease, transform 0.12s ease;
}
.tc-add-btn:hover { color: var(--tc-accent); border-color: var(--tc-accent); background: rgba(154, 208, 255, 0.08); }
.tc-add-btn:active { transform: scale(0.96); }
.tc-add-hint { color: var(--tc-danger); font-size: 11px; min-height: 15px; padding-top: 2px; }

.tc-hits { max-height: 180px; overflow-y: auto; }
.tc-hit {
  display: flex; flex-direction: column; gap: 2px; padding: 5px 8px; margin-bottom: 5px;
  border-radius: var(--tc-radius-sm); background: var(--tc-layer-1);
  border-left: 3px solid var(--tc-text-tertiary);
  transition: background-color 0.15s ease, transform 0.15s ease;
}
.tc-hit:hover { background: var(--tc-layer-2); transform: translateX(1px); }
.tc-hit.group-neutral { border-left-color: #6ba4ff; }
.tc-hit.group-negative { border-left-color: var(--tc-danger); }
.tc-hit.group-positive { border-left-color: var(--tc-success); }
.tc-hit .top { display: flex; gap: 6px; align-items: baseline; }
.tc-hit .m { color: var(--tc-accent); font-weight: 800; }
.tc-hit .meta {
  margin-left: auto; flex: none; font-size: 10px; color: var(--tc-text-tertiary);
  font-variant-numeric: tabular-nums;
}
.tc-hit .snip {
  font-size: 11px; word-break: break-all; color: var(--tc-text-secondary);
  line-height: 1.5;
}

.tc-sess {
  display: flex; align-items: center; gap: 7px; padding: 4px 6px; border-radius: var(--tc-radius-sm);
  transition: background-color 0.15s ease;
}
.tc-sess:hover { background: var(--tc-layer-1); }
.tc-dot { width: 8px; height: 8px; border-radius: 50%; flex: none; background: #6b7280; }
.tc-dot.live {
  background: var(--tc-success); box-shadow: 0 0 6px rgba(74, 222, 128, 0.7);
  animation: tc-pulse 1.2s ease-in-out infinite;
}
@keyframes tc-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.35; } }
.tc-sess .name {
  flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  font-size: 11px;
}
.tc-sess .meta {
  flex: none; font-size: 10px; color: var(--tc-text-tertiary);
  font-variant-numeric: tabular-nums;
}
.tc-sess.current .name { color: var(--tc-accent); font-weight: 700; }

.tc-foot {
  display: flex; align-items: center; gap: 10px; padding: 8px 12px;
  border-top: 1px solid var(--tc-border-soft);
  background: var(--tc-layer-1);
}
.tc-clear {
  cursor: pointer; border: none; background: none; padding: 2px 6px; font: inherit;
  color: var(--tc-text-tertiary); border-radius: var(--tc-radius-sm);
  transition: color 0.18s ease, background-color 0.18s ease;
}
.tc-clear:hover { color: var(--tc-danger); background: rgba(248, 113, 113, 0.1); }
.tc-offline { margin-left: auto; color: var(--tc-warning); font-weight: 700; font-size: 11px; }

@media (prefers-color-scheme: light) {
  .tc-panel {
    --tc-success: #16a34a;
    --tc-warning: #d97706;
    --tc-danger: #dc2626;
    --tc-accent: var(--dsw-alias-brand-primary, #2563eb);
    --tc-text-primary: var(--dsw-alias-label-primary, #1f2937);
    --tc-text-secondary: var(--dsw-alias-label-secondary, #6b7280);
    --tc-text-tertiary: var(--dsw-alias-label-tertiary, #9ca3af);
    --tc-border: var(--dsw-alias-border-l2, rgba(0, 0, 0, 0.12));
    --tc-border-soft: var(--dsw-alias-border-l1, rgba(0, 0, 0, 0.08));
    --tc-bg: var(--dsw-alias-bg-overlay, rgba(255, 255, 255, 0.94));
    --tc-layer-1: var(--dsw-alias-bg-layer-1, rgba(0, 0, 0, 0.04));
    --tc-layer-2: var(--dsw-alias-bg-layer-2, rgba(0, 0, 0, 0.06));
  }
  .tc-head { background: linear-gradient(135deg, rgba(37, 99, 235, 0.06), transparent 55%); }
  .tc-switch.on { color: #fff; }
  .tc-smart { background: linear-gradient(135deg, rgba(37, 99, 235, 0.06), rgba(0, 0, 0, 0.02)); }
  .tc-chip .mode.cs, .tc-mode-btn.cs {
    background: rgba(37, 99, 235, 0.08);
  }
  .tc-add-input:focus { box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.14); }
}
`

let injected = false

/** Inject the panel CSS into <head> once. */
export function ensureStyles(): void {
  if (injected) return
  injected = true
  const style = document.createElement('style')
  style.textContent = PANEL_CSS
  document.head.appendChild(style)
}