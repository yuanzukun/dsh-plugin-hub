/**
 * dsh-thinking-counter — sidebar-right 智商面板 tab 的 body 组件。
 *
 * 官方 pane 提供标题栏/关闭/拖拽/分栏/浮出；本组件把 {@link ThinkingCounterApp}
 * 的单例面板元素挂进宿主 div（attach/detach，元素跨宿主复用）。
 * @module @dsh-external/dsh-thinking-counter/client/tab
 */

import { useEffect, useRef, type ReactNode } from 'react'
import type { UseSidebarRightTabInfo } from '@deepseek-ai/dsh-client-ui-sidebar-right/client'
import type { ThinkingCounterApp } from './panel.js'

/** The thinking-counter tab body's props: the framework-bound tab information hook. */
export interface ThinkingCounterTabProps {
  useTabInfo: UseSidebarRightTabInfo
}

/** Bind the app singleton accessor into the tab body component. */
export function makeThinkingCounterTab(getApp: () => ThinkingCounterApp | null): (props: ThinkingCounterTabProps) => ReactNode {
  return function ThinkingCounterTab({ useTabInfo }: ThinkingCounterTabProps): ReactNode {
    useTabInfo()
    const hostRef = useRef<HTMLDivElement>(null)

    useEffect(() => {
      const host = hostRef.current
      const app = getApp()
      if (host === null || app === null) return
      host.appendChild(app.attach())
      return () => app.detach()
    }, [])

    return <div ref={hostRef} className="tc-tab-host" />
  }
}
