/**
 * dsh-thinking-counter browser half — popover panel + data flow.
 *
 * The window is plain DOM (agent-board precedent): a fixed floating window
 * opened by the sidebar 🐳 button, rendering the host snapshot. Data flow: poll
 * `GET /api/thinking-counter/snapshot` (1.5s, paused when the tab is hidden)
 * plus SSE `GET /api/thinking-counter/stream` for instant refresh while the
 * panel is open; config changes (enable/stop/matchers/reset) go through
 * `POST /api/thinking-counter/config`.
 *
 * Failure policy: transport errors render an "offline" hint and keep the
 * loops alive; nothing throws (the web shell fails boot on apply throw).
 * @module @dsh-external/dsh-thinking-counter/client/panel
 */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-api-session-controller/client'
import type { ThinkingSnapshot } from '../counting.js'
import { STORAGE_KEY, loadState, saveState, emitButtonUpdate, type MatcherGroup, type PersistedMatcher, type PersistedState } from './state.js'
import { ensureStyles } from './styles.js'

/** API base path (must match the host routes). */
const API = '/api/thinking-counter'
/** Whale-girl state image base path (host static assets). */
const WHALE_ASSET_BASE = '/thinking-counter/whale'
/** Snapshot poll interval while counting is on or the panel is open. */
const POLL_MS = 1500

/** Render a Unix ms time as HH:MM:SS (local). */
function clockOf(ms: number): string {
  const d = new Date(ms)
  const pad = (n: number): string => String(n).padStart(2, '0')
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
}

/** Short display name for a session: title, else id tail. */
function displayName(session: { title?: string; sessionId: string }): string {
  if (session.title !== undefined && session.title.trim() !== '') return session.title
  const tail = session.sessionId.slice(-8)
  return `#${tail}`
}

/**
 * Panel DOM (single, reused across pane hosts) + snapshot loop. One instance
 * per client boot, owned by the plugin apply(); the sidebar-right tab body
 * hosts the element via {@link ThinkingCounterApp.attach}/{@link ThinkingCounterApp.detach}.
 */
export class ThinkingCounterApp {
  private readonly ctx: ClientContext
  private readonly persisted: PersistedState
  private panel: HTMLDivElement | null = null
  private timer: number | undefined
  private sse: EventSource | null = null
  private lastSnapshot: ThinkingSnapshot | null = null
  private fetching = false
  private failedStreak = 0
  private disposed = false
  private addHint = ''
  private lastChipsSig = ''
  private lastHitsSig = ''
  private lastSessionsSig = ''
  private unsubscribeList: (() => void) | null = null
  private unsubscribeStorage: (() => void) | null = null
  private visibilityCleanup: (() => void) | null = null
  /** 面板元素当前是否挂在某个 pane 宿主里（detached ≠ 销毁：单例 DOM 复用）。 */
  private hosted = false

  constructor(ctx: ClientContext) {
    this.ctx = ctx
    this.persisted = loadState()
  }

  // ------------------------------------------------------------------ lifecycle

  mount(): void {
    if (this.disposed) return
    ensureStyles()
    // 会话切换（current 变化）时重渲染明细的「当前」高亮。
    this.unsubscribeList = this.ctx.sessions.list.subscribe(() => {
      if (this.panel !== null) this.render()
    })
    // 其它标签页写入 localStorage 时同步本标签页，避免旧标签页用过期词表覆盖宿主。
    const onStorage = (event: StorageEvent): void => {
      if (event.key !== STORAGE_KEY) return
      const next = loadState()
      this.persisted.matchers = this.mergedMatchers({
        matchers: next.matchers.map(m => ({ pattern: m.pattern, caseSensitive: m.caseSensitive, group: m.group })),
      } as ThinkingSnapshot)
      this.persisted.enabled = next.enabled
      this.persisted.matchVisible = next.matchVisible
      saveState(this.persisted)
      this.render()
    }
    window.addEventListener('storage', onStorage)
    this.unsubscribeStorage = () => window.removeEventListener('storage', onStorage)
    if (this.persisted.enabled) this.startLoop()
    void this.syncConfig()
  }

  dispose(): void {
    if (this.disposed) return
    this.disposed = true
    this.destroyPanel()
    this.stopLoop()
    this.unsubscribeList?.()
    this.unsubscribeList = null
    this.unsubscribeStorage?.()
    this.unsubscribeStorage = null
    emitButtonUpdate({ active: false, smart: null, open: false })
  }

  /**
   * 挂进 sidebar-right pane 宿主：构建（或复用）面板元素并返回供宿主 append。
   * 面板 DOM 为单例：detach 后元素存活、数据循环继续喂它，再 attach 直接复用。
   * @returns the hosted panel element.
   */
  attach(): HTMLDivElement {
    if (this.panel === null) {
      const panel = this.buildPanel()
      this.panel = panel
      this.bindPanelEvents(panel)
      this.ensureSse()
      if (this.persisted.enabled) this.startLoop()
      // 新 DOM 上先清渲染指纹，强制 render 把数据填进来（防旧签名跳过填充）。
      this.lastChipsSig = ''
      this.lastHitsSig = ''
      this.lastSessionsSig = ''
      this.render()
    }
    this.hosted = true
    emitButtonUpdate({ active: this.persisted.enabled, smart: this.smartPct(), open: true })
    return this.panel
  }

  /** 宿主卸载：面板离屏但存活（单例 DOM，下次 attach 复用）。 */
  detach(): void {
    this.hosted = false
    this.panel?.remove()
    emitButtonUpdate({ active: this.persisted.enabled, smart: this.smartPct(), open: false })
  }

  /** 销毁面板 DOM（dispose 用）。 */
  private destroyPanel(): void {
    this.panel?.remove()
    this.panel = null
    this.hosted = false
    this.closeSse()
    if (!this.persisted.enabled) this.stopLoop()
    this.lastChipsSig = ''
    this.lastHitsSig = ''
    this.lastSessionsSig = ''
  }

  // ------------------------------------------------------------------ data flow

  /** Boot/recovery sync: reconcile host state with the persisted config. */
  private async syncConfig(): Promise<void> {
    try {
      const res = await fetch(`${API}/snapshot`)
      if (!res.ok) throw new Error(String(res.status))
      const snap = await res.json() as ThinkingSnapshot
      this.lastSnapshot = snap
      // 合并宿主词表到本地：无论本地是否为空都做并集保留，避免「另一标签页/API/磁盘
      // 已添加的词在本面板看不见」，也避免本地旧词表把宿主新增词覆盖掉。
      this.persisted.matchers = this.mergedMatchers(snap)
      saveState(this.persisted)
      const patch: Record<string, unknown> = {
        matchers: this.persisted.matchers,
        matchVisible: this.persisted.matchVisible,
      }
      // 只在对不上时动 enabled：页面刷新不重置已开着的计数（宿主重启才重开）。
      if (snap.enabled !== this.persisted.enabled) patch.enabled = this.persisted.enabled
      await this.postConfig(patch)
      this.render()
    } catch { /* 宿主未就绪：保活，轮询/恢复路径会重试 */ }
  }

  /**
   * 合并本地与宿主词表（按小写去重，本地属性优先；宿主导入缺失项）。
   * 用于渲染与同步，保证任一来源添加的词都能显示、不会互相覆盖。
   */
  private mergedMatchers(snap: ThinkingSnapshot | null): PersistedMatcher[] {
    const merged = new Map<string, PersistedMatcher>()
    for (const m of this.persisted.matchers) {
      merged.set(m.pattern.toLowerCase(), { ...m })
    }
    for (const m of snap?.matchers ?? []) {
      const key = m.pattern.toLowerCase()
      if (!merged.has(key)) {
        merged.set(key, { pattern: m.pattern, caseSensitive: m.caseSensitive, group: m.group })
      }
    }
    return Array.from(merged.values())
  }

  /** 渲染用词表 = 本地 + 宿主并集（面板未及同步时也能显示宿主已有词）。 */
  private displayMatchers(): PersistedMatcher[] {
    return this.mergedMatchers(this.lastSnapshot)
  }

  /** 把当前宿主快照中的词合并进本地并落盘，供增删改前保留其它来源新增的词。 */
  private mergeSnapshotMatchersIntoLocal(): void {
    this.persisted.matchers = this.mergedMatchers(this.lastSnapshot)
    saveState(this.persisted)
  }

  /**
   * 操作前实时拉取最新宿主快照并合并到本地，避免用过期 lastSnapshot 覆盖掉
   * 其它标签页/刷新期间新增的词。失败时保留现有数据（操作仍可继续，由 postConfig 兜底）。
   */
  private async refreshSnapshotAndMerge(): Promise<void> {
    try {
      const res = await fetch(`${API}/snapshot`)
      if (!res.ok) throw new Error(String(res.status))
      const snap = await res.json() as ThinkingSnapshot
      this.lastSnapshot = snap
      this.persisted.matchers = this.mergedMatchers(snap)
      saveState(this.persisted)
    } catch { /* 保活：沿用现有 lastSnapshot/persisted */ }
  }

  /** POST a config patch; apply the returned snapshot on success. */
  private async postConfig(patch: Record<string, unknown>): Promise<void> {
    try {
      const res = await fetch(`${API}/config`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(patch),
      })
      if (!res.ok) throw new Error(String(res.status))
      this.lastSnapshot = await res.json() as ThinkingSnapshot
      this.failedStreak = 0
      this.render()
    } catch { /* 保活 */ }
  }

  private poll(): void {
    if (this.fetching || this.disposed) return
    if (document.hidden) return
    this.fetching = true
    const wasFailing = this.failedStreak > 0
    void fetch(`${API}/snapshot`)
      .then(res => {
        if (!res.ok) throw new Error(String(res.status))
        return res.json() as Promise<ThinkingSnapshot>
      })
      .then(snap => {
        this.failedStreak = 0
        this.lastSnapshot = snap
        // 失败后恢复：宿主可能重启过 → 重新对账配置（enabled 不一致才重开）。
        if (wasFailing && this.persisted.enabled) void this.syncConfig()
        this.render()
      })
      .catch(() => {
        this.failedStreak += 1
        this.render()
      })
      .finally(() => { this.fetching = false })
  }

  private startLoop(): void {
    if (this.timer !== undefined) return
    this.timer = window.setInterval(() => this.poll(), POLL_MS)
    this.visibilityCleanup = this.watchVisibility()
  }

  private stopLoop(): void {
    if (this.timer !== undefined) {
      window.clearInterval(this.timer)
      this.timer = undefined
    }
    this.visibilityCleanup?.()
    this.visibilityCleanup = null
  }

  /** 标签页隐藏时暂停轮询（后台标签零请求）。 */
  private watchVisibility(): () => void {
    const onVisibility = (): void => {
      if (document.hidden) {
        this.stopLoop()
      } else {
        this.startLoop()
        this.poll()
      }
    }
    document.addEventListener('visibilitychange', onVisibility)
    return () => document.removeEventListener('visibilitychange', onVisibility)
  }

  private ensureSse(): void {
    if (this.sse !== null) return
    this.sse = new EventSource(`${API}/stream`)
    this.sse.onmessage = () => this.poll()
  }

  private closeSse(): void {
    this.sse?.close()
    this.sse = null
  }

  // ------------------------------------------------------------------ panel actions

  private async toggleCounting(): Promise<void> {
    const next = !this.persisted.enabled
    this.persisted.enabled = next
    saveState(this.persisted)
    this.addHint = ''
    if (next) {
      await this.refreshSnapshotAndMerge()
      await this.postConfig({
        enabled: true,
        matchers: this.persisted.matchers,
        matchVisible: this.persisted.matchVisible,
      })
      this.startLoop()
    } else {
      await this.postConfig({ enabled: false })
      this.stopLoop()
    }
    this.render()
  }

  /** 添加输入行的当前大小写模式（默认不区分）。 */
  private pendingCaseSensitive = false
  /** 添加输入行的当前分组（默认吃瓜词）。 */
  private pendingGroup: MatcherGroup = 'neutral'

  private async addMatcher(raw: string): Promise<void> {
    await this.refreshSnapshotAndMerge()
    const pattern = raw.trim()
    if (pattern === '') return
    if (pattern.length > 64) {
      this.addHint = '词太长，鱼嘴装不下（≤64）'
      this.render()
      return
    }
    const existing = this.displayMatchers().find(m => m.pattern.toLowerCase() === pattern.toLowerCase())
    if (existing !== undefined) {
      this.addHint = `已存在：${existing.pattern}（${groupLabel(existing.group)}），去下方分组里就能看到`
      this.render()
      return
    }
    if (this.persisted.matchers.length >= 20) {
      this.addHint = '鱼塘满员（最多 20 个）'
      this.render()
      return
    }
    this.persisted.matchers.push({
      pattern,
      caseSensitive: this.pendingCaseSensitive,
      group: this.pendingGroup,
    })
    this.pendingCaseSensitive = false
    saveState(this.persisted)
    this.addHint = ''
    await this.postConfig({ matchers: this.persisted.matchers })
    this.render()
  }

  private async removeMatcher(pattern: string): Promise<void> {
    await this.refreshSnapshotAndMerge()
    this.persisted.matchers = this.persisted.matchers.filter(m => m.pattern !== pattern)
    saveState(this.persisted)
    await this.postConfig({ matchers: this.persisted.matchers })
    this.render()
  }

  /** 点击 chip 上的模式徽标：切换该词的大小写模式。 */
  private async toggleMatcherCase(pattern: string): Promise<void> {
    await this.refreshSnapshotAndMerge()
    const matcher = this.persisted.matchers.find(m => m.pattern === pattern)
    if (matcher === undefined) return
    matcher.caseSensitive = !matcher.caseSensitive
    saveState(this.persisted)
    await this.postConfig({ matchers: this.persisted.matchers })
    this.render()
  }

  /** 拖动/移动 chip 到新分组：吃瓜 / 偷吃 / 头脑大开词。 */
  private async moveMatcherGroup(pattern: string, group: MatcherGroup): Promise<void> {
    await this.refreshSnapshotAndMerge()
    const matcher = this.persisted.matchers.find(m => m.pattern === pattern)
    if (matcher === undefined || matcher.group === group) return
    matcher.group = group
    saveState(this.persisted)
    await this.postConfig({ matchers: this.persisted.matchers })
    this.render()
  }

  private async setMatchVisible(visible: boolean): Promise<void> {
    this.persisted.matchVisible = visible
    saveState(this.persisted)
    await this.postConfig({ matchVisible: visible })
  }

  private async clearData(): Promise<void> {
    await this.postConfig({ reset: true })
  }

  // ------------------------------------------------------------------ panel DOM

  private buildPanel(): HTMLDivElement {
    const root = document.createElement('div')
    root.className = 'tc-panel'
    root.innerHTML = `
      <div class="tc-head">
        <span class="tc-title">🐳 蓝色大肥鱼 · 智商鉴定中心</span>
        <span class="tc-status off">待命</span>
        <label class="tc-visible" title="同时统计可见文本中的检测词">
          <input type="checkbox" class="tc-visible-input"> 含可见文本
        </label>
      </div>
      <div class="tc-body">
        <div class="tc-switch-row">
          <button class="tc-switch" type="button"></button>
          <span class="tc-since"></span>
        </div>
        <div class="tc-smart none">
          <div class="tc-smart-head">
            <span class="tc-smart-title">🐳 肥鱼瞳孔检测</span>
            <span class="tc-smart-verdict"></span>
          </div>
          <div class="tc-whale"><img class="tc-whale-img" alt="" draggable="false"></div>
          <div class="tc-smart-bar"><div class="tc-smart-fill"></div></div>
          <div class="tc-smart-foot">
            <span class="tc-smart-pct">—</span>
            <span class="tc-smart-hint">智力滑动变阻器 · 良性命中占比</span>
          </div>
        </div>
        <div class="tc-cards">
          <div class="tc-card"><span class="tc-card-icon">🧠</span><b class="tc-c-blocks">0</b><span>思考块</span></div>
          <div class="tc-card"><span class="tc-card-icon">🔡</span><b class="tc-c-chars">0</b><span>思考字符</span></div>
          <div class="tc-card"><span class="tc-card-icon">🎯</span><b class="tc-c-hits">0</b><span>总命中</span></div>
          <div class="tc-card"><span class="tc-card-icon">🐟</span><b class="tc-c-sessions">0</b><span>会话数</span></div>
        </div>
        <details class="tc-section" open>
          <summary class="tc-section-title"><span class="tc-caret">▶</span>检测词（拖去偷吃/头脑大开词/吃瓜）</summary>
          <div class="tc-chips">
            <div class="tc-group" data-group="neutral">
              <div class="tc-group-head"><span>吃瓜词（默认）</span><span class="tc-group-sum"></span></div>
              <div class="tc-group-chips"></div>
            </div>
            <div class="tc-group" data-group="negative">
              <div class="tc-group-head"><span>偷吃词</span><span class="tc-group-sum"></span></div>
              <div class="tc-group-chips"></div>
            </div>
            <div class="tc-group" data-group="positive">
              <div class="tc-group-head"><span>头脑大开词</span><span class="tc-group-sum"></span></div>
              <div class="tc-group-chips"></div>
            </div>
          </div>
          <div class="tc-add-row">
            <input class="tc-add-input" placeholder="埋个检测词，比如 let me、we should" maxlength="64" spellcheck="false">
            <select class="tc-group-select" title="新检测词的默认鱼池">
              <option value="neutral">吃瓜词</option>
              <option value="negative">偷吃词</option>
              <option value="positive">头脑大开词</option>
            </select>
            <button class="tc-mode-btn" type="button" title="Aa=区分大小写 / aa=不区分（当前添加模式）">aa</button>
            <button class="tc-add-btn" type="button">添加</button>
          </div>
          <div class="tc-add-hint"></div>
        </details>
        <details class="tc-section" open>
          <summary class="tc-section-title"><span class="tc-caret">▶</span>当场逮到摸鱼</summary>
          <div class="tc-hits"></div>
        </details>
        <details class="tc-section" open>
          <summary class="tc-section-title"><span class="tc-caret">▶</span>会话鱼塘</summary>
          <div class="tc-sessions"></div>
        </details>
      </div>
      <div class="tc-foot">
        <button class="tc-clear" type="button" title="仅清零统计数据（总量/按会话/最近命中），检测词保留">清空战绩，肥鱼失忆</button>
        <span class="tc-offline"></span>
      </div>
    `
    return root
  }

  private bindPanelEvents(root: HTMLDivElement): void {
    root.querySelector<HTMLImageElement>('.tc-whale-img')!.addEventListener('error', () => {
      root.querySelector<HTMLImageElement>('.tc-whale-img')!.style.display = 'none'
    })
    const switchBtn = root.querySelector<HTMLButtonElement>('.tc-switch')!
    switchBtn.addEventListener('click', () => void this.toggleCounting())
    const visibleInput = root.querySelector<HTMLInputElement>('.tc-visible-input')!
    visibleInput.checked = this.persisted.matchVisible
    visibleInput.addEventListener('change', () => void this.setMatchVisible(visibleInput.checked))
    const input = root.querySelector<HTMLInputElement>('.tc-add-input')!
    const addBtn = root.querySelector<HTMLButtonElement>('.tc-add-btn')!
    const modeBtn = root.querySelector<HTMLButtonElement>('.tc-mode-btn')!
    const submit = (): void => {
      void this.addMatcher(input.value)
      input.value = ''
      input.focus()
    }
    const syncModeBtn = (): void => {
      modeBtn.textContent = this.pendingCaseSensitive ? 'Aa' : 'aa'
      modeBtn.classList.toggle('cs', this.pendingCaseSensitive)
      modeBtn.title = this.pendingCaseSensitive
        ? '当前添加模式：区分大小写（点击切换为不区分）'
        : '当前添加模式：不区分大小写（点击切换为区分）'
    }
    syncModeBtn()
    modeBtn.addEventListener('click', () => {
      this.pendingCaseSensitive = !this.pendingCaseSensitive
      syncModeBtn()
    })
    addBtn.addEventListener('click', submit)
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit() })
    const groupSelect = root.querySelector<HTMLSelectElement>('.tc-group-select')!
    groupSelect.value = this.pendingGroup
    groupSelect.addEventListener('change', () => {
      this.pendingGroup = (groupSelect.value === 'negative' || groupSelect.value === 'positive')
        ? groupSelect.value
        : 'neutral'
    })
    root.querySelector<HTMLButtonElement>('.tc-clear')!.addEventListener('click', () => void this.clearData())

    // 拖动分组：chip draggable，三个分组区为放置目标。
    const zones = root.querySelectorAll<HTMLElement>('.tc-group')
    const clearZoneHighlight = (): void => {
      for (const zone of zones) zone.classList.remove('drag-over')
    }
    for (const zone of zones) {
      zone.addEventListener('dragover', (e) => {
        e.preventDefault()
        zone.classList.add('drag-over')
      })
      zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'))
      zone.addEventListener('drop', (e) => {
        e.preventDefault()
        clearZoneHighlight()
        const pattern = e.dataTransfer?.getData('text/plain')
        const group = zone.dataset.group
        if (pattern !== undefined && pattern !== '' && (group === 'neutral' || group === 'negative' || group === 'positive')) {
          void this.moveMatcherGroup(pattern, group)
        }
      })
    }
  }

  // ------------------------------------------------------------------ render

  private render(): void {
    const snap = this.lastSnapshot
    const active = this.persisted.enabled
    const blocks = snap?.totals.thinkingBlocks ?? 0
    const groupHits = this.groupHits(snap)
    const totalHitsAll = groupHits.neutral + groupHits.negative + groupHits.positive
    const positivePct = totalHitsAll > 0 ? Math.round(groupHits.positive / totalHitsAll * 100) : null

    if (this.panel !== null) {
      const root = this.panel
      const switchBtn = root.querySelector<HTMLButtonElement>('.tc-switch')!
      switchBtn.textContent = active ? '收鱼！' : '放鱼！'
      switchBtn.classList.toggle('on', active)
      root.querySelector<HTMLSpanElement>('.tc-since')!.textContent = active && snap !== null
        ? `自 ${clockOf(snap.since)} 下水`
        : '鱼还没下水，开了才算'
      root.querySelector<HTMLElement>('.tc-c-blocks')!.textContent = String(blocks)
      root.querySelector<HTMLElement>('.tc-c-chars')!.textContent = formatCount(snap?.totals.reasoningChars ?? 0)
      root.querySelector<HTMLElement>('.tc-c-hits')!.textContent = formatCount(totalHitsAll)
      root.querySelector<HTMLElement>('.tc-c-sessions')!.textContent = String(snap?.totals.sessions ?? 0)
      root.querySelector<HTMLInputElement>('.tc-visible-input')!.checked = this.persisted.matchVisible
      root.querySelector<HTMLElement>('.tc-add-hint')!.textContent = this.addHint
      const offline = root.querySelector<HTMLElement>('.tc-offline')!
      offline.textContent = this.failedStreak > 0 ? '离线（宿主不可达）' : ''
      const status = root.querySelector<HTMLElement>('.tc-status')!
      status.className = `tc-status ${active ? 'on' : 'off'}`
      status.textContent = active ? '统计中' : '待命'

      // 肥鱼瞳孔检测行：良性命中占比 + 判定。
      const verdict = verdictOf(positivePct)
      const smartEl = root.querySelector<HTMLElement>('.tc-smart')!
      smartEl.className = `tc-smart ${verdict.tone}`
      root.querySelector<HTMLElement>('.tc-smart-verdict')!.textContent = verdict.label
      root.querySelector<HTMLElement>('.tc-smart-pct')!.textContent = positivePct === null ? '—' : `${positivePct}%`
      root.querySelector<HTMLElement>('.tc-smart-fill')!.style.width = `${positivePct ?? 0}%`
      const whaleImg = root.querySelector<HTMLImageElement>('.tc-whale-img')!
      whaleImg.src = whaleAssetFor(verdict.tone)
      whaleImg.alt = verdict.label
      whaleImg.style.display = ''

      this.renderChips(root)
      this.renderHits(root)
      this.renderSessions(root)
    }

    emitButtonUpdate({ active, smart: positivePct, open: this.hosted })
  }

  /** 按分组汇总命中次数（当前匹配词 × 各自命中数）。 */
  private groupHits(snap: ThinkingSnapshot | null): { neutral: number; negative: number; positive: number } {
    const counts = snap?.totals.matchHits ?? {}
    const out = { neutral: 0, negative: 0, positive: 0 }
    for (const matcher of this.displayMatchers()) {
      out[matcher.group] += this.matcherHitCount(counts, matcher.pattern)
    }
    return out
  }

  /** 命中计数按原样读取，兼容 host 大小写与本地大小写不一致（按小写兜底）。 */
  private matcherHitCount(counts: Record<string, number>, pattern: string): number {
    if (counts[pattern] !== undefined) return counts[pattern]
    const lower = pattern.toLowerCase()
    const found = Object.entries(counts).find(([key]) => key.toLowerCase() === lower)
    return found !== undefined ? found[1] : 0
  }

  /** 当前肥鱼成绩（良性命中占比 %）；无命中数据时为 null（徽标不显示）。 */
  private smartPct(): number | null {
    const groupHits = this.groupHits(this.lastSnapshot)
    const total = groupHits.neutral + groupHits.negative + groupHits.positive
    if (total <= 0) return null
    return Math.round(groupHits.positive / total * 100)
  }

  private renderChips(root: HTMLDivElement): void {
    const container = root.querySelector<HTMLElement>('.tc-chips')!
    const snap = this.lastSnapshot
    const counts = snap?.totals.matchHits ?? {}
    const displayMatchers = this.displayMatchers()
    const sig = JSON.stringify(displayMatchers.map(m => [m.pattern, m.caseSensitive, m.group, this.matcherHitCount(counts, m.pattern)]))
    if (sig === this.lastChipsSig) return
    this.lastChipsSig = sig
    // 三个分组区为静态骨架，只重建 chip 内容与组内合计。
    const groups = container.querySelectorAll<HTMLElement>('.tc-group')
    for (const zone of groups) {
      const group = zone.dataset.group as MatcherGroup
      const members = displayMatchers.filter(m => m.group === group)
      const zoneChips = zone.querySelector<HTMLElement>('.tc-group-chips')!
      zoneChips.textContent = ''
      const sum = members.reduce((acc, m) => acc + this.matcherHitCount(counts, m.pattern), 0)
      zone.querySelector<HTMLElement>('.tc-group-sum')!.textContent = sum > 0 ? `${sum} 次` : ''
      if (members.length === 0) {
        const empty = document.createElement('div')
        empty.className = 'tc-empty'
        empty.textContent = group === 'neutral'
          ? '🐟 空（吃瓜位虚位以待）'
          : group === 'negative'
            ? '🍽️ 空（鱼还没来偷吃）'
            : '💡 空（头脑还没大开）'
        zoneChips.appendChild(empty)
        continue
      }
      const sorted = [...members].sort((a, b) => this.matcherHitCount(counts, b.pattern) - this.matcherHitCount(counts, a.pattern))
      for (const matcher of sorted) {
        const hit = this.matcherHitCount(counts, matcher.pattern)
        const chip = document.createElement('span')
        chip.className = `tc-chip${hit === 0 ? ' zero' : ''}`
        chip.draggable = true
        chip.title = '拖去别的鱼池'
        chip.addEventListener('dragstart', (e) => {
          e.dataTransfer?.setData('text/plain', matcher.pattern)
          e.dataTransfer!.effectAllowed = 'move'
        })
        chip.addEventListener('dragend', () => {
          for (const z of groups) z.classList.remove('drag-over')
        })
        const label = document.createElement('span')
        label.textContent = matcher.pattern
        const count = document.createElement('b')
        count.textContent = String(hit)
        const mode = document.createElement('button')
        mode.type = 'button'
        mode.className = `mode${matcher.caseSensitive ? ' cs' : ''}`
        mode.textContent = matcher.caseSensitive ? 'Aa' : 'aa'
        mode.title = matcher.caseSensitive
          ? `「${matcher.pattern}」区分大小写（点击切换为不区分）`
          : `「${matcher.pattern}」不区分大小写（点击切换为区分）`
        mode.addEventListener('click', () => void this.toggleMatcherCase(matcher.pattern))
        const del = document.createElement('button')
        del.type = 'button'
        del.className = 'del'
        del.textContent = '×'
        del.title = '放生'
        del.addEventListener('click', () => void this.removeMatcher(matcher.pattern))
        chip.append(label, count, mode, del)
        zoneChips.appendChild(chip)
      }
    }
  }

  private renderHits(root: HTMLDivElement): void {
    const container = root.querySelector<HTMLElement>('.tc-hits')!
    const hits = this.lastSnapshot?.recentHits ?? []
    const sig = hits.length === 0 ? '' : hits.map(h => `${h.matcher}|${h.sessionId}|${h.time}`).join(';')
    if (sig === this.lastHitsSig) return
    this.lastHitsSig = sig
    container.textContent = ''
    if (hits.length === 0) {
      const empty = document.createElement('div')
      empty.className = 'tc-empty'
      empty.textContent = '🐟 还没摸到鱼，鱼很安全'
      container.appendChild(empty)
      return
    }
    for (const hit of hits) {
      const matcher = this.displayMatchers().find(m => m.pattern === hit.matcher)
      const row = document.createElement('div')
      row.className = `tc-hit${matcher !== undefined ? ` group-${matcher.group}` : ''}`
      const top = document.createElement('div')
      top.className = 'top'
      const m = document.createElement('span')
      m.className = 'm'
      m.textContent = hit.matcher
      const meta = document.createElement('span')
      meta.className = 'meta'
      meta.textContent = `${clockOf(hit.time)} · #${hit.sessionId.slice(-8)}`
      const snip = document.createElement('div')
      snip.className = 'snip'
      snip.textContent = hit.snippet
      top.append(m, meta)
      row.append(top, snip)
      container.appendChild(row)
    }
  }

  private renderSessions(root: HTMLDivElement): void {
    const container = root.querySelector<HTMLElement>('.tc-sessions')!
    const sessions = this.lastSnapshot?.sessions ?? []
    const current = this.ctx.sessions.list.getSnapshot().current
    const sig = sessions.length === 0 ? ''
      : sessions.map(s => `${s.sessionId}|${s.turn}|${s.thinkingBlocks}|${s.thinkingNow ? 1 : 0}|${s.lastActivity}`).join(';')
    if (sig === this.lastSessionsSig) return
    this.lastSessionsSig = sig
    container.textContent = ''
    if (sessions.length === 0) {
      const empty = document.createElement('div')
      empty.className = 'tc-empty'
      empty.textContent = '🌊 鱼塘空空，等会话进来'
      container.appendChild(empty)
      return
    }
    for (const session of sessions) {
      const row = document.createElement('div')
      row.className = `tc-sess${session.sessionId === current ? ' current' : ''}`
      const dot = document.createElement('span')
      dot.className = `tc-dot${session.thinkingNow ? ' live' : ''}`
      const name = document.createElement('span')
      name.className = 'name'
      name.textContent = displayName(session)
      const hits = Object.values(session.matchHits).reduce((a, b) => a + b, 0)
      const meta = document.createElement('span')
      meta.className = 'meta'
      meta.textContent = `t${session.turn} · ${session.thinkingBlocks}块 · ${hits}次 · ${clockOf(session.lastActivity)}`
      row.append(dot, name, meta)
      container.appendChild(row)
    }
  }
}

/** 分组内部值 → 面板显示名。 */
function groupLabel(group: MatcherGroup): string {
  switch (group) {
    case 'negative': return '偷吃词'
    case 'positive': return '头脑大开词'
    default: return '吃瓜词'
  }
}

/** 智商判定 → 鲸鱼娘状态图（透明 WebP，host 静态资源）。 */
function whaleAssetFor(tone: 'good' | 'mid' | 'weak' | 'none'): string {
  switch (tone) {
    case 'good': return `${WHALE_ASSET_BASE}/celebrate.webp`
    case 'mid': return `${WHALE_ASSET_BASE}/deadline.webp`
    case 'weak': return `${WHALE_ASSET_BASE}/slack.webp`
    default: return `${WHALE_ASSET_BASE}/idle.webp`
  }
}

/** Compact count formatting (k for thousands). */
function formatCount(n: number): string {
  if (n < 1000) return String(n)
  if (n < 1_000_000) return `${Math.round(n / 100) / 10}k`
  return `${Math.round(n / 100_000) / 10}M`
}

/** 聪明信号判定（阈值默认值，可调）。 */
function verdictOf(positivePct: number | null): { label: string; tone: 'good' | 'mid' | 'weak' | 'none' } {
  if (positivePct === null) return { label: '肥鱼打盹中：等你的检测词', tone: 'none' }
  if (positivePct >= 60) return { label: '梁圣附体，全网封神', tone: 'good' }
  if (positivePct >= 30) return { label: '肥鱼歪头：还行，勉强及格', tone: 'mid' }
  return { label: '梁子，这波和智商结下梁子', tone: 'weak' }
}
