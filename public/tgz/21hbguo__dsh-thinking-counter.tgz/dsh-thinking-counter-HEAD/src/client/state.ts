/**
 * Client-side persistence + button event bus for the thinking-counter panel.
 * The persisted config (enabled / matchers / matchVisible) is the browser's
 * source of truth; the host keeps the counters and the runtime config copy.
 * @module @dsh-external/dsh-thinking-counter/client/state
 */

/** localStorage key for the persisted panel config. */
export const STORAGE_KEY = 'dsh.thinkingCounter.v1'

/** Matcher sentiment group (neutral default / negative / positive). */
export type MatcherGroup = 'neutral' | 'negative' | 'positive'

/** One persisted matcher with its case mode and sentiment group. */
export interface PersistedMatcher {
  pattern: string
  /** True = 区分大小写；false（默认）= 不区分。 */
  caseSensitive: boolean
  /** 中性（默认）/ 恶性 / 良性。 */
  group: MatcherGroup
}

/** Persisted panel configuration. */
export interface PersistedState {
  /** Counting on (synced to the host at boot and on change). */
  enabled: boolean
  /** User phrase matchers (deduped case-insensitively by phrase). */
  matchers: PersistedMatcher[]
  /** Also scan visible text blocks (default false: thinking content only). */
  matchVisible: boolean
}

/** Defaults when nothing is stored yet (词表默认为空，由用户自行添加). */
const DEFAULTS: PersistedState = {
  enabled: false,
  matchers: [],
  matchVisible: false,
}

/** Coerce one stored matcher entry (legacy string → neutral, case-insensitive). */
function toPersistedMatcher(entry: unknown): PersistedMatcher | undefined {
  if (typeof entry === 'string') {
    const pattern = entry.trim()
    return pattern === '' ? undefined : { pattern, caseSensitive: false, group: 'neutral' }
  }
  if (entry !== null && typeof entry === 'object') {
    const record = entry as Record<string, unknown>
    if (typeof record.pattern !== 'string') return undefined
    const pattern = record.pattern.trim()
    if (pattern === '') return undefined
    return {
      pattern,
      caseSensitive: record.caseSensitive === true,
      group: record.group === 'negative' || record.group === 'positive' ? record.group : 'neutral',
    }
  }
  return undefined
}

/** Load persisted state (tolerant of missing/corrupt storage). */
export function loadState(): PersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw === null) return { ...DEFAULTS }
    const parsed = JSON.parse(raw) as Partial<PersistedState>
    const matchers: PersistedMatcher[] = []
    const seen = new Set<string>()
    if (Array.isArray(parsed.matchers)) {
      for (const entry of parsed.matchers) {
        const matcher = toPersistedMatcher(entry)
        if (matcher === undefined) continue
        const lower = matcher.pattern.toLowerCase()
        if (seen.has(lower)) continue
        seen.add(lower)
        matchers.push(matcher)
        if (matchers.length >= 20) break
      }
    }
    return {
      enabled: typeof parsed.enabled === 'boolean' ? parsed.enabled : DEFAULTS.enabled,
      matchers,
      matchVisible: typeof parsed.matchVisible === 'boolean' ? parsed.matchVisible : DEFAULTS.matchVisible,
    }
  } catch {
    return { ...DEFAULTS }
  }
}

/** Persist state (storage failures are swallowed — counting must not break). */
export function saveState(state: PersistedState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  } catch { /* 存储不可用（隐私模式等）时静默降级 */ }
}

/** Custom event name carrying button badge/active state. */
export const BUTTON_EVENT = 'dsh-thinking-counter:button'

/** Button badge state published on every snapshot/render. */
export interface ButtonUpdate {
  active: boolean
  /** 聪明程度 = 良性命中占比（%）；无命中数据时为 null（不显示徽标）。 */
  smart: number | null
  open: boolean
}

/** Broadcast a button state update (React sidebar button listens). */
export function emitButtonUpdate(update: ButtonUpdate): void {
  document.dispatchEvent(new CustomEvent(BUTTON_EVENT, { detail: update }))
}
