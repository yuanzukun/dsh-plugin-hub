/**
 * dsh-thinking-counter — browser 半区：侧边栏 🐳 按钮 + sidebar-right 智商面板。
 *
 * 面板是 sidebar-right tab 类型（'thinking-counter'）：body 按类型 id 注册进
 * keyed `sidebar.right.pane.tab` 槽位，承载 {@link ThinkingCounterApp} 的单例
 * 面板元素；容器/关闭/拖拽归官方 dockkit。侧边栏按钮 = openTab 触发器，徽标
 * 与高亮态仍通过 `dsh-thinking-counter:button` 自定义事件同步（App 每次快照发布）。
 *
 * 配置（开关/匹配词/含可见文本）持久化于 localStorage；host 计数器随启动
 * 同步。全部网络失败静默降级，apply 绝不抛出（web shell boot 安全底线）。
 * @module @dsh-external/dsh-thinking-counter/client
 */

import { useEffect, useState } from 'react'
import type { Context as ClientContext } from '@deepseek-ai/cordis'
// Type-only: pulls ui-slots' SlotMap merge into this program.
import type {} from '@deepseek-ai/dsh-api-session-controller/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: pulls ui-sidebar's 'sidebar.footer.action' declaration.
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
// Type-only: pulls the sidebar-right Context merge (ctx.sidebarRight/Tabs).
import type {} from '@deepseek-ai/dsh-client-ui-sidebar-right/client'
import { ThinkingCounterApp } from './panel.js'
import { makeThinkingCounterTab } from './tab.js'
import { BUTTON_EVENT, type ButtonUpdate } from './state.js'

/** Services required by this plugin. */
export const inject = ['slots', 'sessions', 'sidebarRight', 'sidebarRightTabs'] as const

/** The tab type's implementation id — the key its body registers under. */
const TC_TAB_ID = '@dsh-external/dsh-thinking-counter/tab'

/** Sidebar footer action props (column state only). */
interface FooterActionProps {
  wide: boolean
}

/** 徽标背景按聪明程度着色（与面板判定阈值一致）。 */
function badgeColor(smart: number): string {
  if (smart >= 60) return '#4ade80'
  if (smart >= 30) return '#fbbf24'
  return '#f87171'
}

/** 侧边栏底部按钮：打开/聚焦智商面板 tab；wide 双行（名称+%与进度条）；rail 仅图标。 */
function makeThinkingCounterAction(ctx: ClientContext) {
  return function ThinkingCounterAction(props: FooterActionProps) {
    const [update, setUpdate] = useState<ButtonUpdate>({ active: false, smart: null, open: false })
    const [failed, setFailed] = useState(false)
    useEffect(() => {
      const onUpdate = (event: Event): void => {
        setUpdate((event as CustomEvent<ButtonUpdate>).detail)
      }
      document.addEventListener(BUTTON_EVENT, onUpdate)
      return () => document.removeEventListener(BUTTON_EVENT, onUpdate)
    }, [])
    const showSmart = update.active && update.smart !== null
    const color = showSmart ? badgeColor(update.smart!) : undefined
    return (
      <button
        type="button"
        className={props.wide ? 'tc-action tc-action-wide' : 'tc-action'}
        title={failed ? '打开一个会话后再试' : '蓝色大肥鱼 · 智商鉴定中心（肥鱼智商）'}
        style={failed ? { color: '#f87171' } : update.active ? { color: '#4ade80' } : undefined}
        onClick={() => {
          try {
            ctx.sidebarRight.openTab('thinking-counter')
            setFailed(false)
          } catch {
            setFailed(true)
          }
        }}
      >
        {props.wide ? (
          <>
            <span className="tc-action-name">
              <span>🐳</span>
              <span>肥鱼智商</span>
              {showSmart && <b className="tc-action-pct" style={{ color }}>{update.smart}%</b>}
            </span>
            <span className="tc-action-bar">
              <span
                className="tc-action-fill"
                style={{ width: `${showSmart ? update.smart : 0}%`, background: color ?? 'rgba(128, 128, 128, 0.35)' }}
              />
            </span>
          </>
        ) : (
          <span>🐳</span>
        )}
      </button>
    )
  }
}

/** Panel app singleton (created by apply; the tab body attaches its element). */
let app: ThinkingCounterApp | null = null

/** 面板单例元素访问器（tab body 经它 attach/detach）。 */
export function thinkingCounterApp(): ThinkingCounterApp | null {
  return app
}

/**
 * Register the sidebar footer action, the sidebar-right tab type + body,
 * and mount the panel data app.
 * @param ctx - client root context (slots + sessions + sidebarRight/Tabs).
 */
export function apply(ctx: ClientContext): void {
  // 父槽声明晚于本插件加载时 register 会抛错；inject 等声明就绪后再注册。
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action',
    id: 'dsh-thinking-counter',
    order: 110,
    inject: () => ({}),
  }, makeThinkingCounterAction(ctx)))

  // Stage one: the tab type（guide 页入口胶囊）。
  const disposeType = ctx.sidebarRightTabs.register({
    id: TC_TAB_ID,
    kind: 'thinking-counter',
    title: () => '肥鱼智商',
    guide: [{
      order: 70,
      title: () => '肥鱼智商',
      description: () => '思考检测词命中统计与聪明程度判定',
    }],
  })
  // Stage two: the body on the keyed pane seat, after the seat is declared.
  const disposeBody = ctx.slots.inject('sidebar.right.pane.tab', () => ctx.slots.register({
    name: 'sidebar.right.pane.tab',
    key: TC_TAB_ID,
  }, makeThinkingCounterTab(thinkingCounterApp)))
  ctx.effect(() => () => {
    disposeBody()
    disposeType()
  }, 'dsh-thinking-counter: sidebar-right tab')

  ctx.effect(() => {
    const instance = new ThinkingCounterApp(ctx)
    app = instance
    instance.mount()
    return () => {
      instance.dispose()
      app = null
    }
  }, 'dsh-thinking-counter: app')
}
