/**
 * dsh-thinking-counter counting engine — pure host-side fold over session
 * events. Counts, from the moment the user toggles counting on:
 *   - thinking blocks: structural reasoning content blocks (deduped per
 *     {turn}:{step}:{index} across live `assistant/chunk` block-start/end
 *     and the final `assistant/message`);
 *   - reasoning characters observed;
 *   - per-matcher phrase hits inside reasoning text (optionally visible text
 *     too), with cross-chunk boundary safety via a rolling tail buffer.
 *
 * Everything here is pure and testable; the plugin entry owns the listener,
 * routes, and enable/reset semantics.
 *
 * Note: events are typed structurally (not via @deepseek-ai/dsh-session) on
 * purpose — importing the host session package drags its `sessions:
 * SessionStore` Context merge into the client type graph, which shadows the
 * client runtime's `ISessions` under skipLibCheck.
 * @module @dsh-external/dsh-thinking-counter/counting
 */

// ---------------------------------------------------------------------------
// Limits (bounded memory)
// ---------------------------------------------------------------------------

/** Max matcher count per user config. */
export const MAX_MATCHERS = 20
/** Max matcher pattern length (chars). */
export const MAX_MATCHER_LEN = 64
/** Rolling tail length kept per active block: MAX_MATCHER_LEN - 1. */
export const TAIL_LEN = MAX_MATCHER_LEN - 1
/** Per-session block accounting cap (oldest keys evicted). */
export const BLOCKS_PER_SESSION_CAP = 1024
/** Session detail rows kept in the snapshot (oldest activity evicted). */
export const SESSIONS_CAP = 200
/** Recent-hit log cap (ring buffer, newest first). */
export const RECENT_HITS_CAP = 50
/** Snippet context width around a hit (chars each side). */
export const SNIPPET_RADIUS = 20

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Matcher sentiment group: neutral (default) / negative / positive. */
export type MatcherGroup = 'neutral' | 'negative' | 'positive'

/** All matcher groups in display order. */
export const MATCHER_GROUPS: readonly MatcherGroup[] = ['neutral', 'negative', 'positive']

/** One user-configured phrase matcher (display casing preserved). */
export interface Matcher {
  /** Display pattern (original casing). */
  pattern: string
  /** Lowercased pattern used for case-insensitive matching. */
  lower: string
  /** True = match exactly as typed; false = case-insensitive (default). */
  caseSensitive: boolean
  /** Sentiment group; defaults to 'neutral'. */
  group: MatcherGroup
}

/** Wire form of a matcher: legacy plain string (= case-insensitive, neutral)
 *  or `{ pattern, caseSensitive?, group? }`. */
export type MatcherInput = string | { pattern: string; caseSensitive?: boolean; group?: MatcherGroup }

/** Per-block streaming accounting keyed by `${turn}:${step}:${index}`. */
export interface BlockAcc {
  /** Block kind observed so far ('reasoning' or 'text'). */
  kind: 'reasoning' | 'text'
  /** Chars of block text already scanned into matcher counts. */
  scannedChars: number
  /** Whether this block already contributed to the thinking-block count. */
  blockCounted: boolean
  /** Rolling tail (last TAIL_LEN chars of the scanned portion). */
  tail: string
}

/** Per-session counters. */
export interface SessionCounter {
  id: string
  title?: string
  /** Latest turn observed. */
  turn: number
  /** Unix epoch ms of the latest event observed. */
  lastActivity: number
  /** Session ended (session/disposed): row frozen, excluded from new events. */
  inactive: boolean
  /** In-flight reasoning blocks (pulse indicator); clamped ≥ 0. */
  thinkingNow: number
  thinkingBlocks: number
  reasoningChars: number
  matchHits: Record<string, number>
  /** Block accounting (capped). */
  blocks: Map<string, BlockAcc>
}

/** One recent phrase hit (newest first, capped). */
export interface RecentHit {
  matcher: string
  sessionId: string
  time: number
  /** Context around the hit, single line. */
  snippet: string
}

/** Aggregate totals across all sessions (survives detail-row eviction). */
export interface ThinkingTotals {
  thinkingBlocks: number
  reasoningChars: number
  matchHits: Record<string, number>
}

/** The whole engine state (single source of truth for the snapshot). */
export interface EngineState {
  enabled: boolean
  /** Unix epoch ms when the current counting window started. */
  since: number
  matchers: Matcher[]
  /** Also scan visible text blocks (default false: thinking content only). */
  matchVisible: boolean
  totals: ThinkingTotals
  sessions: Map<string, SessionCounter>
  recentHits: RecentHit[]
}

/** Snapshot delivered to the browser half. */
export interface ThinkingSnapshot {
  enabled: boolean
  since: number
  /** Active matchers with case mode and group (display order). */
  matchers: { pattern: string; caseSensitive: boolean; group: MatcherGroup }[]
  matchVisible: boolean
  totals: ThinkingTotals & { sessions: number; lastUpdate: number }
  recentHits: RecentHit[]
  sessions: SessionStat[]
}

/** One session detail row. */
export interface SessionStat {
  sessionId: string
  title?: string
  turn: number
  thinkingBlocks: number
  reasoningChars: number
  matchHits: Record<string, number>
  lastActivity: number
  inactive?: boolean
  thinkingNow: boolean
}

/** Assistant chunk payload shape (discriminated structural view; the cast at
 *  the event boundary is unchecked, so a `default` arm tolerates any other
 *  chunk type). */
type ChunkLike =
  | { type: 'reasoning-delta'; index: number; text: string }
  | { type: 'text-delta'; index: number; text: string }
  | { type: 'block-start'; index: number; blockType: string }
  | { type: 'block-end'; index: number; block: { type: string; text?: string } }

/** Assistant message content block shape (structural view). */
interface ContentBlockLike {
  type: string
  text?: string
}

/** Minimal structural session event face (see module note). */
export interface SessionEventLike {
  readonly type: string
  readonly seq: number
  readonly time: number
  readonly data: unknown
}

// ---------------------------------------------------------------------------
// Pure helpers
// ---------------------------------------------------------------------------

/** Normalize a user-supplied pattern: trim, reject empty/too long. */
export function normalizeMatcher(raw: string): string | undefined {
  const pattern = raw.trim()
  if (pattern === '') return undefined
  if (pattern.length > MAX_MATCHER_LEN) return undefined
  return pattern
}

/** Build the matcher list from raw inputs (trim, dedupe by lowercase phrase, cap). */
export function buildMatchers(raw: readonly MatcherInput[] | undefined): Matcher[] {
  const seen = new Set<string>()
  const out: Matcher[] = []
  for (const entry of raw ?? []) {
    const source = typeof entry === 'string' ? { pattern: entry } : entry
    if (typeof source.pattern !== 'string') continue
    const pattern = normalizeMatcher(source.pattern)
    if (pattern === undefined) continue
    const lower = pattern.toLowerCase()
    if (seen.has(lower)) continue
    seen.add(lower)
    out.push({
      pattern,
      lower,
      caseSensitive: source.caseSensitive === true,
      group: source.group === 'negative' || source.group === 'positive' ? source.group : 'neutral',
    })
    if (out.length >= MAX_MATCHERS) break
  }
  return out
}

/**
 * Count matcher hits in one text window, counting only matches whose END
 * falls beyond `bufferLen` (the already-scanned prefix). Callers feed
 * `tail + newText` and the previous tail length, so boundary-straddling
 * matches are counted exactly once and never double-counted.
 * Case mode is per matcher: case-sensitive matchers match the raw window,
 * case-insensitive ones match the lowercased window.
 */
export function countMatchesIn(
  window: string,
  bufferLen: number,
  matchers: readonly Matcher[],
  hits: Record<string, number>,
  onHit: ((matcher: string, position: number, snippet: string) => void) | undefined,
): void {
  if (window.length <= bufferLen) return
  const lower = window.toLowerCase()
  for (const matcher of matchers) {
    const needle = matcher.caseSensitive ? matcher.pattern : matcher.lower
    if (needle.length === 0) continue
    const haystack = matcher.caseSensitive ? window : lower
    // A hit ending within the already-scanned prefix was counted before.
    const minStart = bufferLen - needle.length + 1
    let from = 0
    let count = 0
    for (;;) {
      const at = haystack.indexOf(needle, from)
      if (at < 0 || at > window.length - needle.length) break
      if (at >= minStart) {
        count += 1
        if (onHit !== undefined) {
          onHit(matcher.pattern, at, snippetOf(window, at, needle.length))
        }
      }
      from = at + 1
    }
    if (count > 0) hits[matcher.pattern] = (hits[matcher.pattern] ?? 0) + count
  }
}

/** Single-line context around a hit. */
export function snippetOf(text: string, position: number, length: number): string {
  const start = Math.max(0, position - SNIPPET_RADIUS)
  const end = Math.min(text.length, position + length + SNIPPET_RADIUS)
  return text.slice(start, end).replace(/\s+/g, ' ').trim()
}

/** Append a hit to the ring buffer (newest first). */
export function pushHit(log: RecentHit[], hit: RecentHit): void {
  log.unshift(hit)
  if (log.length > RECENT_HITS_CAP) log.length = RECENT_HITS_CAP
}

/** Block key for {turn}:{step}:{index}. */
function blockKey(turn: number, step: number, index: number): string {
  return `${turn}:${step}:${index}`
}

// ---------------------------------------------------------------------------
// Engine
// ---------------------------------------------------------------------------

/** Create the initial engine state (counting off). */
export function createEngine(): EngineState {
  return {
    enabled: false,
    since: 0,
    matchers: [],
    matchVisible: false,
    totals: { thinkingBlocks: 0, reasoningChars: 0, matchHits: {} },
    sessions: new Map(),
    recentHits: [],
  }
}

/** Drop matcher keys that are no longer configured (from totals + sessions). */
function pruneMatcherKeys(state: EngineState): void {
  const keep = new Set(state.matchers.map(m => m.pattern))
  for (const key of Object.keys(state.totals.matchHits)) {
    if (!keep.has(key)) delete state.totals.matchHits[key]
  }
  for (const session of state.sessions.values()) {
    for (const key of Object.keys(session.matchHits)) {
      if (!keep.has(key)) delete session.matchHits[key]
    }
  }
}

/** Reset counters (used on enable transition and explicit reset). */
export function resetCounters(state: EngineState): void {
  state.totals = { thinkingBlocks: 0, reasoningChars: 0, matchHits: {} }
  state.sessions.clear()
  state.recentHits.length = 0
}

/** Turn counting on/off. Turning on clears the previous window (fresh start). */
export function setEnabled(state: EngineState, enabled: boolean, now: number): void {
  if (enabled === state.enabled) return
  if (enabled) {
    resetCounters(state)
    state.since = now
  }
  state.enabled = enabled
}

/** Replace the matcher configuration; removed matchers drop their counts. */
export function setMatchers(state: EngineState, raw: readonly MatcherInput[] | undefined): void {
  state.matchers = buildMatchers(raw)
  pruneMatcherKeys(state)
}

/** Ensure a session row exists and return it. */
function ensureSession(state: EngineState, id: string, now: number): SessionCounter {
  let session = state.sessions.get(id)
  if (session !== undefined) return session
  session = {
    id,
    turn: 0,
    lastActivity: now,
    inactive: false,
    thinkingNow: 0,
    thinkingBlocks: 0,
    reasoningChars: 0,
    matchHits: {},
    blocks: new Map(),
  }
  state.sessions.set(id, session)
  // Bound memory: evict the oldest inactive row, or the globally oldest row.
  if (state.sessions.size > SESSIONS_CAP) {
    let victim: SessionCounter | undefined
    for (const row of state.sessions.values()) {
      if (row.inactive && (victim === undefined || row.lastActivity < victim.lastActivity)) victim = row
    }
    if (victim === undefined) {
      for (const row of state.sessions.values()) {
        if (victim === undefined || row.lastActivity < victim.lastActivity) victim = row
      }
    }
    if (victim !== undefined) state.sessions.delete(victim.id)
  }
  return session
}

/** Ensure a block acc exists; evict oldest keys past the cap. */
function ensureBlock(session: SessionCounter, key: string, kind: 'reasoning' | 'text'): BlockAcc {
  let acc = session.blocks.get(key)
  if (acc !== undefined) {
    if (acc.kind === 'text' && kind === 'reasoning') acc.kind = 'reasoning'
    return acc
  }
  acc = { kind, scannedChars: 0, blockCounted: false, tail: '' }
  session.blocks.set(key, acc)
  if (session.blocks.size > BLOCKS_PER_SESSION_CAP) {
    const oldest = session.blocks.keys().next().value
    if (oldest !== undefined) session.blocks.delete(oldest)
  }
  return acc
}

/** Scan one text chunk with boundary safety; returns appended tail state. */
function scanChunk(
  state: EngineState,
  session: SessionCounter,
  acc: BlockAcc,
  text: string,
  now: number,
): void {
  if (text === '') return
  const window = acc.tail + text
  countMatchesIn(window, acc.tail.length, state.matchers, session.matchHits, (pattern, at, snippet) => {
    state.totals.matchHits[pattern] = (state.totals.matchHits[pattern] ?? 0) + 1
    pushHit(state.recentHits, { matcher: pattern, sessionId: session.id, time: now, snippet })
  })
  acc.scannedChars += text.length
  acc.tail = window.slice(-TAIL_LEN)
}

/** Apply one stream chunk to the session. */
function applyChunk(
  state: EngineState,
  session: SessionCounter,
  turn: number,
  step: number,
  chunk: ChunkLike,
  now: number,
): void {
  session.turn = Math.max(session.turn, turn)
  switch (chunk.type) {
    case 'reasoning-delta': {
      if (chunk.text === '') return
      const acc = ensureBlock(session, blockKey(turn, step, chunk.index), 'reasoning')
      acc.kind = 'reasoning'
      session.reasoningChars += chunk.text.length
      state.totals.reasoningChars += chunk.text.length
      scanChunk(state, session, acc, chunk.text, now)
      return
    }
    case 'text-delta': {
      if (chunk.text === '' || !state.matchVisible) return
      const acc = ensureBlock(session, blockKey(turn, step, chunk.index), 'text')
      scanChunk(state, session, acc, chunk.text, now)
      return
    }
    case 'block-start': {
      if (chunk.blockType !== 'reasoning') return
      const acc = ensureBlock(session, blockKey(turn, step, chunk.index), 'reasoning')
      if (!acc.blockCounted) {
        acc.blockCounted = true
        session.thinkingBlocks += 1
        state.totals.thinkingBlocks += 1
      }
      session.thinkingNow += 1
      return
    }
    case 'block-end': {
      const block = chunk.block
      if (block.type === 'reasoning') {
        const acc = ensureBlock(session, blockKey(turn, step, chunk.index), 'reasoning')
        if (!acc.blockCounted) {
          acc.blockCounted = true
          session.thinkingBlocks += 1
          state.totals.thinkingBlocks += 1
        }
        // Scan the not-yet-scanned remainder of the assembled block text.
        const text = block.text ?? ''
        if (acc.scannedChars < text.length) {
          const remainder = text.slice(acc.scannedChars)
          session.reasoningChars += remainder.length
          state.totals.reasoningChars += remainder.length
          scanChunk(state, session, acc, remainder, now)
        }
        session.thinkingNow = Math.max(0, session.thinkingNow - 1)
      } else if (block.type === 'text' && state.matchVisible) {
        const acc = ensureBlock(session, blockKey(turn, step, chunk.index), 'text')
        const text = block.text ?? ''
        if (acc.scannedChars < text.length) {
          scanChunk(state, session, acc, text.slice(acc.scannedChars), now)
        }
      }
      return
    }
    default:
      return
  }
}

/** Apply one finalized assistant message to the session. */
function applyMessage(
  state: EngineState,
  session: SessionCounter,
  turn: number,
  step: number,
  content: readonly ContentBlockLike[],
  now: number,
): void {
  session.turn = Math.max(session.turn, turn)
  content.forEach((block, index) => {
    if (block.type === 'reasoning') {
      const acc = ensureBlock(session, blockKey(turn, step, index), 'reasoning')
      if (!acc.blockCounted) {
        acc.blockCounted = true
        session.thinkingBlocks += 1
        state.totals.thinkingBlocks += 1
      }
      const text = block.text ?? ''
      if (acc.scannedChars < text.length) {
        const remainder = text.slice(acc.scannedChars)
        session.reasoningChars += remainder.length
        state.totals.reasoningChars += remainder.length
        scanChunk(state, session, acc, remainder, now)
      }
    } else if (block.type === 'text' && state.matchVisible) {
      const acc = ensureBlock(session, blockKey(turn, step, index), 'text')
      const text = block.text ?? ''
      if (acc.scannedChars < text.length) {
        scanChunk(state, session, acc, text.slice(acc.scannedChars), now)
      }
    }
  })
}

/**
 * Fold one session event into the engine (no-op unless enabled).
 * @param state - engine state.
 * @param sessionId - owning session.
 * @param event - the session event.
 */
export function applyEvent(state: EngineState, sessionId: string, event: SessionEventLike): void {
  if (!state.enabled) return
  const now = event.time
  const session = ensureSession(state, sessionId, now)
  if (session.inactive) return
  session.lastActivity = now
  switch (event.type) {
    case 'assistant/chunk': {
      const data = event.data as { turn?: number; step?: number; chunk?: ChunkLike }
      const turn = data.turn ?? 0
      const step = data.step ?? 0
      if (data.chunk !== undefined) applyChunk(state, session, turn, step, data.chunk, now)
      return
    }
    case 'assistant/message': {
      const data = event.data as { turn?: number; step?: number; message?: { content?: ContentBlockLike[] } }
      const content = data.message?.content
      if (content !== undefined) applyMessage(state, session, data.turn ?? 0, data.step ?? 0, content, now)
      return
    }
    case 'step/end':
    case 'turn/end': {
      session.thinkingNow = 0
      return
    }
    default: {
      // SessionEventMap is merge-extensible: `session/title` (dsh-session-title)
      // arrives through here without being a core event type.
      if (event.type === 'session/title') {
        const title = (event.data as { title?: unknown }).title
        if (typeof title === 'string' && title !== '') session.title = title
      }
      return
    }
  }
}

/** Mark a session ended (session/disposed): row frozen, stays in the list. */
export function disposeSession(state: EngineState, sessionId: string): void {
  const session = state.sessions.get(sessionId)
  if (session === undefined) return
  session.inactive = true
  session.thinkingNow = 0
}

/** Build the browser-facing snapshot. */
export function snapshot(state: EngineState, now: number): ThinkingSnapshot {
  const rows: SessionStat[] = []
  for (const session of state.sessions.values()) {
    rows.push({
      sessionId: session.id,
      ...(session.title === undefined ? {} : { title: session.title }),
      turn: session.turn,
      thinkingBlocks: session.thinkingBlocks,
      reasoningChars: session.reasoningChars,
      matchHits: session.matchHits,
      lastActivity: session.lastActivity,
      ...(session.inactive ? { inactive: true } : {}),
      thinkingNow: session.thinkingNow > 0,
    })
  }
  rows.sort((a, b) => b.lastActivity - a.lastActivity)
  return {
    enabled: state.enabled,
    since: state.since,
    matchers: state.matchers.map(m => ({ pattern: m.pattern, caseSensitive: m.caseSensitive, group: m.group })),
    matchVisible: state.matchVisible,
    totals: {
      ...state.totals,
      sessions: state.sessions.size,
      lastUpdate: now,
    },
    recentHits: state.recentHits.slice(),
    sessions: rows,
  }
}
