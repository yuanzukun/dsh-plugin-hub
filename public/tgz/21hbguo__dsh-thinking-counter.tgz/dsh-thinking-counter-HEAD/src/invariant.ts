/**
 * Registration invariant for @dsh-external/dsh-thinking-counter.
 * The plugin is a pure bolt-on: it mounts its own session-event listener,
 * in-memory counter store, and /api/thinking-counter/* routes. It owns no
 * service keys and asserts no global invariants, so the installer is empty.
 * @module @dsh-external/dsh-thinking-counter/invariant
 */

/** Register the package's invariant (no-op by design; see module doc). */
export function registerInvariant(): void {}
