#!/usr/bin/env bash
# Publish dsh-thinking-counter to the public npm registry as
# `@21hbguo/dsh-thinking-counter` (scoped public package).
#
# The repo's own package name stays `@dsh-external/dsh-thinking-counter` so the
# local dev profile can keep its `link:` bundle without churn; only the
# published manifest is rewritten to the public scope. Install on any machine:
#
#   dsh plugin --profile web add @21hbguo/dsh-thinking-counter
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

STAGE="$(mktemp -d "${TMPDIR:-/tmp}/dsh-tc-publish.XXXXXX")"
trap 'rm -rf "$STAGE"' EXIT

echo "=== Packing source files ==="
TGZ="$(npm pack --pack-destination "$STAGE" 2>/dev/null | tail -1)"
echo "packed: $STAGE/$TGZ"

echo "=== Preparing public manifest (@21hbguo/dsh-thinking-counter) ==="
tar -xzf "$STAGE/$TGZ" -C "$STAGE"
node -e '
  const fs = require("fs");
  const p = process.argv[1] + "/package/package.json";
  delete require.cache[p];
  const m = JSON.parse(fs.readFileSync(p, "utf8"));
  m.name = "@21hbguo/dsh-thinking-counter";
  delete m.private;
  m.publishConfig = { access: "public" };
  fs.writeFileSync(p, JSON.stringify(m, null, 2) + "\n");
' "$STAGE"

echo "=== Publishing ==="
cd "$STAGE/package"
npm publish --access public
echo "Published @21hbguo/dsh-thinking-counter@$(node -p 'require("./package.json").version')"
