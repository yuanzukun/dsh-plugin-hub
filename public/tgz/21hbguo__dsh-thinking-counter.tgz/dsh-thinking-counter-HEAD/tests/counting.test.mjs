/**
 * dsh-thinking-counter 计数引擎自动化测试（Node 内置 test runner，零依赖）。
 * 运行：npm test（= node --test tests/）
 * 覆盖：开关边界、跨 chunk 匹配、块去重、大小写模式、分组解析、命中日志、
 *       冻结/重置、会话上限等核心行为。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  createEngine, setEnabled, setMatchers, applyEvent, snapshot,
} from '../lib/counting.js'

const ev = (type, data, time = 1000) => ({ type, seq: 0, time, data })

test('disabled 时不计数（开启前消息不算）', () => {
  const s = createEngine()
  setEnabled(s, false, 0)
  setMatchers(s, ['let me'])
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 1, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'let me think' } }))
  assert.equal(snapshot(s, 0).totals.thinkingBlocks, 0)
  assert.deepEqual(snapshot(s, 0).totals.matchHits, {})
})

test('跨 chunk 边界匹配不丢（let me 拆成两段）', () => {
  const s = createEngine()
  setEnabled(s, true, 100)
  setMatchers(s, ['let me'])
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 1, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'ok let ' } }))
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 1, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'me do it, let me' } }))
  const snap = snapshot(s, 200)
  assert.equal(snap.totals.matchHits['let me'], 2)
  assert.equal(snap.totals.reasoningChars, 'ok let me do it, let me'.length)
})

test('流式块 + block-end 补扫：块数/命中/字符不双计', () => {
  const s = createEngine()
  setEnabled(s, true, 100)
  setMatchers(s, ['we should'])
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 2, step: 1, chunk: { type: 'block-start', index: 0, blockType: 'reasoning' } }))
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 2, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'we sho' } }))
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 2, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'uld do it now' } }))
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 2, step: 1, chunk: { type: 'block-end', index: 0, block: { type: 'reasoning', text: 'we should do it now' } } }))
  const snap = snapshot(s, 200)
  assert.equal(snap.totals.thinkingBlocks, 1)
  assert.equal(snap.totals.matchHits['we should'], 1)
  assert.equal(snap.totals.reasoningChars, 'we should do it now'.length)
})

test('assistant/message 未见过的 reasoning 块整块计数', () => {
  const s = createEngine()
  setEnabled(s, true, 100)
  setMatchers(s, ['maybe'])
  applyEvent(s, 's1', ev('assistant/message', { turn: 3, step: 1, message: { content: [{ type: 'reasoning', text: 'maybe maybe not' }] } }))
  const snap = snapshot(s, 200)
  assert.equal(snap.totals.thinkingBlocks, 1)
  assert.equal(snap.totals.matchHits['maybe'], 2)
})

test('流式块 + 最终消息去重（不双计）', () => {
  const s = createEngine()
  setEnabled(s, true, 100)
  setMatchers(s, ['ok'])
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 4, step: 1, chunk: { type: 'block-start', index: 0, blockType: 'reasoning' } }))
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 4, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'ok fine' } }))
  applyEvent(s, 's1', ev('assistant/message', { turn: 4, step: 1, message: { content: [{ type: 'reasoning', text: 'ok fine' }] } }))
  const snap = snapshot(s, 200)
  assert.equal(snap.totals.thinkingBlocks, 1)
  assert.equal(snap.totals.matchHits['ok'], 1)
})

test('大小写模式：区分 vs 不区分', () => {
  const s = createEngine()
  setEnabled(s, true, 100)
  setMatchers(s, [{ pattern: 'Let Me', caseSensitive: true }, 'we should'])
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 8, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'Let Me go, let me stay. We should go, WE SHOULD go.' } }))
  const snap = snapshot(s, 200)
  assert.equal(snap.totals.matchHits['Let Me'], 1)
  assert.equal(snap.totals.matchHits['we should'], 2)
  assert.deepEqual(snap.matchers, [
    { pattern: 'Let Me', caseSensitive: true, group: 'neutral' },
    { pattern: 'we should', caseSensitive: false, group: 'neutral' },
  ])
})

test('分组解析：默认中性、非法分组回退中性、命中照常', () => {
  const s = createEngine()
  setEnabled(s, true, 100)
  setMatchers(s, [
    'let me',
    { pattern: 'I think', group: 'positive' },
    { pattern: 'maybe', group: 'negative' },
    { pattern: 'bad group', group: 'unknown' },
  ])
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 10, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'let me think maybe I think maybe' } }))
  const snap = snapshot(s, 200)
  assert.equal(snap.matchers.find(m => m.pattern === 'let me').group, 'neutral')
  assert.equal(snap.matchers.find(m => m.pattern === 'I think').group, 'positive')
  assert.equal(snap.matchers.find(m => m.pattern === 'maybe').group, 'negative')
  assert.equal(snap.matchers.find(m => m.pattern === 'bad group').group, 'neutral')
  assert.deepEqual(snap.totals.matchHits, { 'let me': 1, 'I think': 1, maybe: 2 })
})

test('命中日志带上下文片段（环形上限）', () => {
  const s = createEngine()
  setEnabled(s, true, 100)
  setMatchers(s, ['Let Me'])
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 5, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'LET ME go' } }))
  const snap = snapshot(s, 200)
  assert.equal(snap.recentHits.length, 1)
  assert.equal(snap.recentHits[0].snippet, 'LET ME go')
})

test('停止冻结、再启动清零重开', () => {
  const s = createEngine()
  setEnabled(s, true, 100)
  setMatchers(s, ['x'])
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 6, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'x' } }))
  setEnabled(s, false, 200)
  assert.equal(snapshot(s, 300).totals.reasoningChars, 1)
  applyEvent(s, 's1', ev('assistant/chunk', { turn: 7, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'y' } }))
  assert.equal(snapshot(s, 400).totals.reasoningChars, 1)
  setEnabled(s, true, 500)
  const reset = snapshot(s, 600)
  assert.equal(reset.totals.reasoningChars, 0)
  assert.equal(reset.since, 500)
})

test('会话上限：超过 200 行逐出最旧（总量保留）', () => {
  const s = createEngine()
  setEnabled(s, true, 100)
  setMatchers(s, ['x'])
  for (let i = 0; i < 205; i++) {
    applyEvent(s, `s${i}`, ev('assistant/chunk', { turn: 1, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'x' } }))
  }
  const snap = snapshot(s, 1000)
  assert.equal(snap.sessions.length, 200)
  assert.equal(snap.totals.reasoningChars, 205)
})
