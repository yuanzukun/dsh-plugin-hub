import { useState } from 'react'
import type { LocalSnapshot } from '../../workbench/schema.ts'
import { NodeExplorer } from './completion.tsx'
import { Field, type Text } from './parts.tsx'
import { OFFLINE_KEY, readOffline, saveOffline, removeOffline } from './offline-cache.ts'

/** Opt-in local metadata storage is visible even when Host settings or the session index is unavailable. */
export function OfflineReceipts({ snapshot, t }: { snapshot: LocalSnapshot | undefined; t: Text }) {
  const [items, setItems] = useState<LocalSnapshot[]>([]), [evicted, setEvicted] = useState(0), [selected, setSelected] = useState<LocalSnapshot>(), [error, setError] = useState(''), [confirmed, setConfirmed] = useState(false)
  const operate = (run: () => { snapshots: LocalSnapshot[]; evicted: number }) => {
    try { const value = run(); setItems(value.snapshots); setEvicted(value.evicted); setError('') } catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)) }
  }
  return <details className="wbOffline"><summary>{t('离线收据缓存（无需 Host）','Offline receipts (no Host required)')}</summary>
    <p>{t('仅在你点击保存时把当前页的事件元数据保存在本浏览器，不保存提示词或工具正文。最多 8 页、1 MB；旧页淘汰数量可见。缓存是过去的快照，不会更新。','Only explicit saving stores this page’s event metadata in this browser, never prompts or tool bodies. Up to eight pages and 1 MB, with visible evictions. Cached snapshots do not update.')}</p>
    <div className="wbActions"><button disabled={!snapshot} onClick={() => snapshot && operate(() => saveOffline(localStorage,snapshot))}>{t('保存当前页供离线查看','Save current page offline')}</button><button onClick={() => operate(() => readOffline(localStorage))}>{t('读取离线缓存','Load offline cache')}</button></div>
    {error && <p role="alert">{error}</p>}
    <p>{t('缓存页数 / 淘汰页数','Cached / evicted pages')}: {items.length} / {evicted}</p>
    {items.map(value => <div key={value.revision+value.offset} className="wbActions"><button onClick={() => setSelected(value)}>{value.generatedAt} · {t('页偏移','Page offset')} {value.offset}</button><button onClick={() => { operate(() => removeOffline(localStorage,value.revision,value.offset)); setSelected(undefined) }}>{t('删除缓存页','Delete cached page')}</button></div>)}
    {selected && <section><h3>{t('离线历史快照','Offline historical snapshot')}</h3><p>{selected.generatedAt} · {selected.reconciliation} · {t('仅此缓存页可浏览，不能离线加载其他页或重新定价。','Only this cached page is available; offline mode cannot load other pages or reprice.')}</p><NodeExplorer snapshot={selected} t={t}/></section>}
    <Field label={t('确认清除本浏览器的全部离线收据','Confirm clearing all offline receipts in this browser')}><input type="checkbox" checked={confirmed} onChange={event => setConfirmed(event.target.checked)}/></Field><button disabled={!confirmed} onClick={() => { try { localStorage.removeItem(OFFLINE_KEY); setItems([]); setSelected(undefined); setEvicted(0); setConfirmed(false); setError('') } catch (error) { setError(String(error)) } }}>{t('清除离线收据','Clear offline receipts')}</button>
  </details>
}
