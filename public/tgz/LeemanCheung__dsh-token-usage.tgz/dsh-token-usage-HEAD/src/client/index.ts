/** Token usage dashboard registered into Web Settings. */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-api-session-controller/client'
import type { SessionId } from '@deepseek-ai/dsh-session'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {
  TokenUsageAnalysisInput,
  TokenUsageAnalysisModelSelection,
  TokenUsageAnalysisProgress,
  TrajectoryAnalysis,
} from '../types.ts'
import { TokenUsageSection } from './TokenUsageSection.tsx'
import { registerWorkbench } from './workbench/register.tsx'
import { AllSessionsThroughput, CurrentSessionThroughput } from './TokenThroughput.tsx'
import { TrajectoryAnalysisAction } from './TrajectoryAnalysisAction.tsx'
import { TokenUsageBudgetController } from './budget-controller.ts'
import { TokenThroughputController } from './throughput-controller.ts'
import { browserDownload } from './export.ts'
import { requestTrajectoryAnalysis } from './trajectory-analysis-client.ts'
import { TrajectoryHistoryController } from './trajectory-history.ts'
import { requestAnalysisModels, requestTokenUsageAnalysis } from './usage-analysis-client.ts'
import { en, NS, zh, type TokenUsageLocaleKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Token usage dashboard copy. */
    'settings.tokenUsage': TokenUsageLocaleKey
  }
}

/** Client services required by the Settings contribution. */
export const inject = ['slots', 'locale', 'connection', 'sessions']

/** Contribute a localized Token usage page to Settings. */
export function apply(ctx: ClientContext): void {
  const connection = ctx.get('connection') as ConnectionHandle | undefined
  if (connection === undefined) throw new Error('dsh-token-usage requires the Client connection service')
  const budget = new TokenUsageBudgetController(connection)
  const trajectoryHistory = new TrajectoryHistoryController()
  const throughput = new TokenThroughputController(ctx.sessions.list)
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'token-usage: dictionaries')
  ctx.effect(() => throughput.start(), 'token usage: sample confirmed output rate')
  ctx.effect(() => {
    trajectoryHistory.load()
    void budget.load()
    return () => { budget.dispose() }
  }, 'token usage: load persistent budget')
  registerWorkbench(ctx, connection, throughput)
  const t = ctx.locale.bind(NS)
  const throughputFace = () => ({
    hooks: { throughput },
    observeProjection: throughput.setScopedCounter,
  })
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action',
    id: 'token-usage-throughput-all',
    order: 100,
    locale: NS,
    inject: throughputFace,
  }, AllSessionsThroughput))
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions',
    id: 'token-usage-throughput-current',
    order: 50,
    locale: NS,
    inject: throughputFace,
  }, CurrentSessionThroughput))
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'token-usage',
    order: 30,
    label: () => t('nav'),
    locale: NS,
    inject: () => ({
      hooks: { budget: budget.store },
      setBudget: (value: number) => budget.setBudget(value),
      setRouteBudget: (provider: string, model: string, value: number) => budget.setRouteBudget(provider, model, value),
      download: browserDownload,
      saveTrajectoryAnalysis: (analysis: TrajectoryAnalysis) => { trajectoryHistory.save(analysis) },
      openSession: (sessionId: SessionId) => { ctx.sessions.open(sessionId) },
      listAnalysisModels: (signal: AbortSignal) => requestAnalysisModels(connection, signal),
      analyzeTokenUsage: (
        input: TokenUsageAnalysisInput,
        model: TokenUsageAnalysisModelSelection,
        signal: AbortSignal,
        onProgress?: (progress: TokenUsageAnalysisProgress) => void,
      ) => requestTokenUsageAnalysis(
        connection,
        input,
        model,
        ctx.locale.getLocale().active,
        signal,
        onProgress,
      ),
      analyzeTrajectory: (
        sessionId: string,
        model: TokenUsageAnalysisModelSelection,
        signal: AbortSignal,
        onProgress?: (progress: TokenUsageAnalysisProgress) => void,
      ) => requestTrajectoryAnalysis(
        connection,
        sessionId,
        model,
        ctx.locale.getLocale().active,
        signal,
        onProgress,
      ),
    }),
  }, TokenUsageSection))
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions',
    id: 'token-usage-trajectory-analysis',
    order: 40,
    locale: NS,
    inject: () => ({
      hooks: { trajectoryHistory: trajectoryHistory.store },
      download: browserDownload,
      listAnalysisModels: (signal: AbortSignal) => requestAnalysisModels(connection, signal),
      analyzeTrajectory: (
        sessionId: string,
        model: TokenUsageAnalysisModelSelection,
        signal: AbortSignal,
        onProgress?: (progress: TokenUsageAnalysisProgress) => void,
      ) => requestTrajectoryAnalysis(
        connection,
        sessionId,
        model,
        ctx.locale.getLocale().active,
        signal,
        onProgress,
      ),
      saveTrajectoryAnalysis: (analysis: TrajectoryAnalysis) => { trajectoryHistory.save(analysis) },
      removeTrajectoryAnalysis: (id: string) => { trajectoryHistory.remove(id) },
    }),
  }, TrajectoryAnalysisAction))
}
