import { describe, expect, it, vi } from 'vitest'
import {
  analysisModelCatalogOf,
  requestAnalysisModels,
  requestTokenUsageAnalysis,
  tokenUsageAnalysisOf,
} from '../src/client/usage-analysis-client.ts'

const input = {
  usage: { uncachedInputTokens: 10, outputTokens: 2, cacheReadTokens: 4, cacheWriteTokens: 1 },
  assistantRequests: 1,
  compactionRequests: 0,
  compactionUsage: { uncachedInputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 },
  models: [],
  days: [],
}

describe('usage analysis client', () => {
  it('accepts only catalog defaults that belong to its selectable models', () => {
    expect(analysisModelCatalogOf({
      models: [{ provider: 'deepseek', providerName: 'DeepSeek', model: 'chat', modelName: 'Chat' }],
      default: { provider: 'deepseek', model: 'chat' },
    })).toEqual({
      models: [{ provider: 'deepseek', providerName: 'DeepSeek', model: 'chat', modelName: 'Chat' }],
      failures: [],
      default: { provider: 'deepseek', model: 'chat' },
    })
    expect(analysisModelCatalogOf({
      models: [{ provider: 'deepseek', providerName: 'DeepSeek', model: 'chat', modelName: 'Chat' }],
      default: { provider: 'other', model: 'other' },
    })).toEqual({
      models: [{ provider: 'deepseek', providerName: 'DeepSeek', model: 'chat', modelName: 'Chat' }],
      failures: [],
    })
  })

  it('keeps healthy routes when the Host reports a provider list failure', () => {
    expect(analysisModelCatalogOf({
      models: [{ provider: 'healthy', providerName: 'Healthy', model: 'model', modelName: 'Model' }],
      failures: [{ provider: 'offline', providerName: 'Offline provider' }],
    })).toEqual({
      models: [{ provider: 'healthy', providerName: 'Healthy', model: 'model', modelName: 'Model' }],
      failures: [{ provider: 'offline', providerName: 'Offline provider' }],
    })
  })

  it('rejects an unrenderable report timestamp', () => {
    expect(tokenUsageAnalysisOf({
      schema: 'dsh-token-usage/usage-analysis-v1',
      generatedAt: 'not-a-date',
      model: { provider: 'deepseek', model: 'chat' },
      report: '# Report',
    })).toBeUndefined()
  })

  it('uses loopback RPC endpoints with a selected route and aggregate payload', async () => {
    const call = vi.fn(async (_channel: string, endpoint: string) => {
      if (endpoint === 'analysis/models') {
        return { ok: true as const, value: { models: [{ provider: 'deepseek', providerName: 'DeepSeek', model: 'chat', modelName: 'Chat' }] } }
      }
      if (endpoint === 'analysis/progress') return { ok: true as const, value: { available: false } }
      return {
        ok: true as const,
        value: {
          schema: 'dsh-token-usage/usage-analysis-v1',
          generatedAt: '2026-08-14T00:00:00.000Z',
          model: { provider: 'deepseek', model: 'chat' },
          report: '# Report',
        },
      }
    })
    const connection = { isLoopback: true, rpc: { call } } as never

    await expect(requestAnalysisModels(connection, new AbortController().signal)).resolves.toMatchObject({ models: [{ model: 'chat' }] })
    await expect(requestTokenUsageAnalysis(
      connection,
      input,
      { provider: 'deepseek', model: 'chat' },
      'en',
      new AbortController().signal,
    )).resolves.toMatchObject({ report: '# Report' })
    expect(call).toHaveBeenNthCalledWith(1, '/token-usage', 'analysis/models', {}, expect.any(AbortSignal))
    const progressId = (call.mock.calls[1]?.[2] as { progressId: string }).progressId
    expect(call).toHaveBeenNthCalledWith(2, '/token-usage', 'analysis/progress', { progressId }, expect.any(AbortSignal))
    expect(call).toHaveBeenNthCalledWith(3, '/token-usage', 'usage/analyze', {
      input,
      model: { provider: 'deepseek', model: 'chat' },
      language: 'en',
      progressId,
    }, expect.any(AbortSignal))
  })
})
