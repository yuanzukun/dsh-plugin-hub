import type { Translate } from './contracts.js'
import type { AutomationLocaleKey } from './locales.js'
import type {
  AutomationSchedule,
  AutomationRunStatus,
  AutomationRunViewModel,
  AutomationSnapshot,
  AutomationViewModel,
  CreateAutomationInput,
  ModelCatalog,
  ModelReasoningEffort,
  UpdateAutomationInput,
} from './protocol.js'

export type ScheduleKind = 'once' | 'interval' | 'daily' | 'weekly'

export interface DayAutomationCounts {
  readonly active: number
  readonly paused: number
}

const DRAFT_SCHEDULE_KINDS = new Set<ScheduleKind>(['once', 'interval', 'daily', 'weekly'])

/** 读取本地草稿；缺失、损坏或非表单结构时返回 undefined。 */
export function readDraft(storage: SortPreferenceStorage | undefined, key: string): AutomationFormState | undefined {
  if (storage === undefined) return undefined
  try {
    const raw = storage.getItem(key)
    if (raw === null) return undefined
    const value = JSON.parse(raw) as Partial<AutomationFormState> | null
    if (typeof value !== 'object' || value === null) return undefined
    if (typeof value.name !== 'string' || typeof value.prompt !== 'string') return undefined
    if (typeof value.scheduleKind !== 'string' || !DRAFT_SCHEDULE_KINDS.has(value.scheduleKind as ScheduleKind)) return undefined
    const base = defaultFormState()
    return { ...base, ...value, weekdays: Array.isArray(value.weekdays) ? value.weekdays : base.weekdays }
  } catch {
    return undefined
  }
}

export function writeDraft(storage: SortPreferenceStorage | undefined, key: string, form: AutomationFormState): boolean {
  if (storage === undefined) return false
  try {
    storage.setItem(key, JSON.stringify(form))
    return true
  } catch {
    // Draft persistence is best-effort; storage denial must not unmount the form.
    return false
  }
}

export function clearDraft(storage: SortPreferenceStorage | undefined, key: string): void {
  if (storage === undefined) return
  try {
    const removable = storage as SortPreferenceStorage & { readonly removeItem?: (key: string) => void }
    if (removable.removeItem !== undefined) removable.removeItem(key)
    else storage.setItem(key, '')
  } catch {
    // Keep form close/submit paths usable when browser storage is unavailable.
  }
}

export interface AutomationFormState {
  readonly name: string
  readonly prompt: string
  readonly scheduleKind: ScheduleKind
  readonly onceAt: string
  readonly everyMinutes: string
  readonly intervalAnchor?: string
  readonly time: string
  readonly weekdays: readonly number[]
  readonly timeZone: string
  readonly provider: string | null
  readonly model: string | null
  readonly reasoningEffort: string | null
  readonly permission: CreateAutomationInput['permission']
}

export type FormErrorKey =
  | 'form.error.name'
  | 'form.error.prompt'
  | 'form.error.once'
  | 'form.error.interval'
  | 'form.error.weekdays'
  | 'form.error.model'

export class AutomationFormError extends Error {
  constructor(readonly key: FormErrorKey) {
    super(key)
  }
}

export function localDateTimeValue(date = new Date()): string {
  const future = new Date(date.getTime() + 60 * 60 * 1000)
  future.setMinutes(0, 0, 0)
  const offset = future.getTimezoneOffset() * 60_000
  return new Date(future.getTime() - offset).toISOString().slice(0, 16)
}

/** Create a fresh form state; the schedule defaults to a single future run. */
export function defaultFormState(now = new Date()): AutomationFormState {
  return {
    name: '',
    prompt: '',
    scheduleKind: 'once',
    onceAt: localDateTimeValue(now),
    everyMinutes: '60',
    time: '09:00',
    weekdays: [1, 2, 3, 4, 5],
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    provider: null,
    model: null,
    reasoningEffort: null,
    permission: 'read-only',
  }
}

function exactLocalDateTimeValue(iso: string): string {
  const date = new Date(iso)
  const offset = date.getTimezoneOffset() * 60_000
  return new Date(date.getTime() - offset).toISOString().slice(0, 16)
}

/** Refresh stale create-only dates while retaining the user's future choice and draft. */
export function freshCreateForm(initial: AutomationFormState | undefined, now = new Date()): AutomationFormState {
  const form = initial ?? defaultFormState(now)
  const at = new Date(form.onceAt).getTime()
  return Number.isFinite(at) && at > now.getTime()
    ? form
    : { ...form, onceAt: localDateTimeValue(now) }
}

/** Build an editable draft from the complete durable definition, not its card preview. */
export function formStateFromAutomation(automation: AutomationViewModel): AutomationFormState {
  const defaults = defaultFormState()
  const schedule = automation.schedule
  return {
    ...defaults,
    name: automation.name,
    prompt: automation.prompt,
    scheduleKind: schedule.kind,
    onceAt: schedule.kind === 'once' ? exactLocalDateTimeValue(schedule.at) : defaults.onceAt,
    everyMinutes: schedule.kind === 'interval' ? String(schedule.everyMinutes) : defaults.everyMinutes,
    ...(schedule.kind === 'interval' && schedule.anchor !== undefined
      ? { intervalAnchor: schedule.anchor }
      : {}),
    time: schedule.kind === 'daily' || schedule.kind === 'weekly' ? schedule.time : defaults.time,
    weekdays: schedule.kind === 'weekly' ? [...schedule.weekdays] : defaults.weekdays,
    timeZone: automation.timeZone,
    provider: automation.provider,
    model: automation.model,
    reasoningEffort: automation.reasoningEffort,
    permission: automation.permission,
  }
}

function validateModelTarget(form: AutomationFormState): void {
  if ((form.provider === null) !== (form.model === null)) {
    throw new AutomationFormError('form.error.model')
  }
  if (form.reasoningEffort !== null && form.provider === null) {
    throw new AutomationFormError('form.error.model')
  }
}

export function buildCreateInput(form: AutomationFormState, now = new Date()): CreateAutomationInput {
  const name = form.name.trim()
  const prompt = form.prompt.trim()
  if (name === '') throw new AutomationFormError('form.error.name')
  if (prompt === '') throw new AutomationFormError('form.error.prompt')
  validateModelTarget(form)

  let schedule: CreateAutomationInput['schedule']
  switch (form.scheduleKind) {
    case 'once': {
      const at = new Date(form.onceAt)
      if (!Number.isFinite(at.getTime()) || at.getTime() <= now.getTime()) {
        throw new AutomationFormError('form.error.once')
      }
      schedule = { kind: 'once', at: at.toISOString(), timeZone: form.timeZone }
      break
    }
    case 'interval': {
      const everyMinutes = Number(form.everyMinutes)
      if (!Number.isInteger(everyMinutes) || everyMinutes < 5 || everyMinutes > 43_200) {
        throw new AutomationFormError('form.error.interval')
      }
      schedule = {
        kind: 'interval',
        everyMinutes,
        anchor: form.intervalAnchor ?? now.toISOString(),
        timeZone: form.timeZone,
      }
      break
    }
    case 'daily':
      schedule = { kind: 'daily', time: form.time, timeZone: form.timeZone }
      break
    case 'weekly':
      if (form.weekdays.length === 0) throw new AutomationFormError('form.error.weekdays')
      schedule = { kind: 'weekly', time: form.time, weekdays: [...form.weekdays].sort((a, b) => a - b), timeZone: form.timeZone }
      break
  }
  return {
    name,
    prompt,
    schedule,
    timeZone: form.timeZone,
    provider: form.provider,
    model: form.model,
    reasoningEffort: form.reasoningEffort,
    permission: form.permission,
  }
}

function scheduleMatchesDraft(form: AutomationFormState, automation: AutomationViewModel): boolean {
  const schedule = automation.schedule
  if (form.scheduleKind !== schedule.kind || form.timeZone !== automation.timeZone) return false
  switch (schedule.kind) {
    case 'once':
      return form.onceAt === exactLocalDateTimeValue(schedule.at)
    case 'interval':
      return form.everyMinutes === String(schedule.everyMinutes)
        && form.intervalAnchor === schedule.anchor
    case 'daily':
      return form.time === schedule.time
    case 'weekly':
      return form.time === schedule.time
        && [...form.weekdays].sort((a, b) => a - b).join(',') === [...schedule.weekdays].sort((a, b) => a - b).join(',')
  }
}

/** Return only changed fields so editing a completed one-shot does not resubmit its past schedule. */
export function buildUpdateInput(
  form: AutomationFormState,
  automation: AutomationViewModel,
  now = new Date(),
): UpdateAutomationInput {
  const name = form.name.trim()
  const prompt = form.prompt.trim()
  if (name === '') throw new AutomationFormError('form.error.name')
  if (prompt === '') throw new AutomationFormError('form.error.prompt')
  validateModelTarget(form)

  const scheduleChanged = !scheduleMatchesDraft(form, automation)
  const routeChanged = form.provider !== automation.provider || form.model !== automation.model
  const replacement = scheduleChanged ? buildCreateInput(form, now) : undefined
  return {
    ...(name === automation.name ? {} : { name }),
    ...(prompt === automation.prompt ? {} : { prompt }),
    ...(replacement === undefined ? {} : {
      schedule: replacement.schedule,
      timeZone: replacement.timeZone,
    }),
    ...(routeChanged
      ? {
          provider: form.provider,
          model: form.model,
          reasoningEffort: form.reasoningEffort,
        }
      : form.reasoningEffort === automation.reasoningEffort
        ? {}
        : { reasoningEffort: form.reasoningEffort }),
    ...(form.permission === automation.permission ? {} : { permission: form.permission }),
  }
}

export interface ModelRouteChoice {
  readonly provider: string
  readonly providerName: string
  readonly model: string
  readonly modelName: string
  readonly description?: string
  readonly unavailable: boolean
}

/** Flatten successful groups and retain the current pinned route when it disappeared. */
export function modelRouteChoices(
  catalog: ModelCatalog,
  currentProvider: string | null,
  currentModel: string | null,
): readonly ModelRouteChoice[] {
  const choices = catalog.groups.flatMap(group => group.models.map(model => ({
    provider: group.id,
    providerName: group.name,
    model: model.id,
    modelName: model.name,
    ...(model.description === undefined ? {} : { description: model.description }),
    unavailable: false,
  })))
  if (currentProvider === null || currentModel === null
    || choices.some(choice => choice.provider === currentProvider && choice.model === currentModel)) {
    return choices
  }
  return [{
    provider: currentProvider,
    providerName: currentProvider,
    model: currentModel,
    modelName: currentModel,
    unavailable: true,
  }, ...choices]
}

export interface ReasoningEffortChoice extends ModelReasoningEffort {
  readonly unavailable: boolean
}

/** Use exact-model opaque effort ids and retain an unavailable current pin. */
export function reasoningEffortChoices(
  catalog: ModelCatalog,
  provider: string | null,
  model: string | null,
  currentEffort: string | null,
): readonly ReasoningEffortChoice[] {
  const catalogModel = provider === null || model === null
    ? undefined
    : catalog.groups
      .find(group => group.id === provider)
      ?.models.find(item => item.id === model)
  const choices = (catalogModel?.reasoning?.efforts ?? []).map(effort => ({
    ...effort,
    unavailable: false,
  }))
  if (currentEffort === null || choices.some(choice => choice.id === currentEffort)) return choices
  return [{ id: currentEffort, name: currentEffort, unavailable: true }, ...choices]
}

/** Problem statuses that count as needs-action until the user marks them reviewed. */
export function runNeedsAttention(run: AutomationRunViewModel): boolean {
  return ATTENTION_STATUSES.has(run.status)
}

const ATTENTION_STATUSES = new Set<AutomationRunStatus>(['failed', 'interrupted', 'skipped', 'cancelled'])

export interface OverviewStats {
  readonly total: number
  readonly active: number
  readonly attention: number
  readonly nextRunAt?: string
}

export function startOfLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate())
}

/** 周一作为一周的开始，与 dsh-personal-workbench 的周视图一致。 */
export function startOfLocalWeek(date: Date): Date {
  const start = startOfLocalDay(date)
  const offset = (start.getDay() + 6) % 7
  return addLocalDays(start, -offset)
}

export function addLocalDays(date: Date, days: number): Date {
  const next = new Date(date)
  next.setDate(next.getDate() + days)
  return next
}

export function isSameLocalDay(left: Date, right: Date): boolean {
  return left.getFullYear() === right.getFullYear()
    && left.getMonth() === right.getMonth()
    && left.getDate() === right.getDate()
}

/** 统计 nextRunAt 落在某个本地日期的自动化任务数量。 */
export function countAutomationsOnDay(
  automations: readonly AutomationViewModel[],
  day: Date,
): number {
  let count = 0
  for (const automation of automations) {
    if (automation.nextRunAt !== undefined && isSameLocalDay(new Date(automation.nextRunAt), day)) {
      count += 1
    }
  }
  return count
}

/** 统计 nextRunAt 落在某个本地日期的任务数，按启用/暂停状态分开。 */
export function countAutomationsByStatusOnDay(
  automations: readonly AutomationViewModel[],
  day: Date,
): DayAutomationCounts {
  let active = 0
  let paused = 0
  for (const automation of automations) {
    if (automation.nextRunAt !== undefined && isSameLocalDay(new Date(automation.nextRunAt), day)) {
      if (automation.status === 'active') active += 1
      else paused += 1
    }
  }
  return { active, paused }
}

/** 客户端近似计算计划的下次运行时间：主机快照缺失 nextRunAt 时（旧主机或
 * 刚暂停的任务）用它兜底，保证暂停任务在排序和日历中的位置与启用任务一致。 */
export function plannedNextRun(schedule: AutomationSchedule, createdAt: string, now: Date): string | undefined {
  switch (schedule.kind) {
    case 'once': {
      const at = Date.parse(schedule.at)
      return Number.isFinite(at) && at > now.getTime() ? schedule.at : undefined
    }
    case 'interval': {
      const anchorMs = Date.parse(schedule.anchor ?? createdAt)
      if (!Number.isFinite(anchorMs)) return undefined
      const step = schedule.everyMinutes * 60_000
      const k = Math.floor((now.getTime() - anchorMs) / step) + 1
      return new Date(anchorMs + k * step).toISOString()
    }
    case 'daily': {
      const [hour, minute] = schedule.time.split(':').map(Number)
      const next = new Date(now)
      next.setHours(hour ?? 0, minute ?? 0, 0, 0)
      if (next.getTime() <= now.getTime()) next.setDate(next.getDate() + 1)
      return next.toISOString()
    }
    case 'weekly': {
      const [hour, minute] = schedule.time.split(':').map(Number)
      const days = [...schedule.weekdays].sort((left, right) => left - right)
      if (days.length === 0) return undefined
      const today = now.getDay() === 0 ? 7 : now.getDay()
      const target = days.find(day => day > today)
      const delta = target === undefined ? 7 - today + (days[0] ?? 1) : target - today
      const next = new Date(now)
      next.setDate(next.getDate() + delta)
      next.setHours(hour ?? 0, minute ?? 0, 0, 0)
      return next.toISOString()
    }
  }
}

/** 生成周视图的 7 个本地日期（周一起始）。 */
export function buildWeekCalendarDays(cursor: Date): readonly Date[] {
  const start = startOfLocalWeek(cursor)
  return Array.from({ length: 7 }, (_, index) => addLocalDays(start, index))
}

/** 生成月视图的 6x7 日期网格，覆盖该月所在的所有周。 */
export function buildMonthCalendarGrid(cursor: Date): readonly Date[] {
  const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1)
  const start = startOfLocalWeek(first)
  return Array.from({ length: 42 }, (_, index) => addLocalDays(start, index))
}

export function deriveOverview(snapshot: AutomationSnapshot): OverviewStats {
  const next = snapshot.automations
    .filter(item => item.status === 'active' && item.nextRunAt !== undefined)
    .map(item => item.nextRunAt as string)
    .sort((a, b) => Date.parse(a) - Date.parse(b))[0]
  return {
    total: snapshot.automations.length,
    active: snapshot.automations.filter(item => item.status === 'active').length,
    attention: snapshot.attentionCount ?? snapshot.runs.filter(runNeedsAttention).length,
    ...(next === undefined ? {} : { nextRunAt: next }),
  }
}

/** 已完成的一次性任务：仍启用、最近一次成功执行、且没有待执行的后续计划。 */
export function isFulfilledAutomation(automation: AutomationViewModel): boolean {
  return automation.status === 'active'
    && automation.nextRunAt === undefined
    && automation.lastRunStatus === 'succeeded'
}

/** 统计某个本地日期当天完成（lastRunAt 落在此日）的已执行任务数。 */
export function countExecutedOnDay(
  automations: readonly AutomationViewModel[],
  day: Date,
): number {
  let count = 0
  for (const automation of automations) {
    if (!isFulfilledAutomation(automation)) continue
    if (automation.lastRunAt !== undefined && isSameLocalDay(new Date(automation.lastRunAt), day)) {
      count += 1
    }
  }
  return count
}

export function formatRelativeTime(iso: string, now: Date, t: Translate): string {
  const value = Date.parse(iso)
  if (!Number.isFinite(value)) return iso
  const deltaMinutes = Math.round((value - now.getTime()) / 60_000)
  const abs = Math.abs(deltaMinutes)
  if (abs < 1) return t('time.now')
  const future = deltaMinutes > 0
  if (abs < 60) return t(future ? 'time.inMinute' : 'time.minuteAgo', { count: abs })
  const hours = Math.round(abs / 60)
  if (hours < 24) return t(future ? 'time.inHour' : 'time.hourAgo', { count: hours })
  const days = Math.round(hours / 24)
  return t(future ? 'time.inDay' : 'time.dayAgo', { count: days })
}

export function shortSessionId(sessionId: string): string {
  return sessionId.length <= 12 ? sessionId : `${sessionId.slice(0, 8)}…${sessionId.slice(-4)}`
}

export function formatSchedule(schedule: AutomationSchedule, t: Translate): string {
  switch (schedule.kind) {
    case 'once':
      return t('schedule.onceAt', {
        time: new Date(schedule.at).toLocaleString(undefined, {
          month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
        }),
      })
    case 'interval':
      return t('schedule.everyMinutes', { count: schedule.everyMinutes })
    case 'daily':
      return t('schedule.dailyAt', { time: schedule.time })
    case 'weekly':
      return t('schedule.weeklyAt', {
        days: schedule.weekdays.map(day => t(`day.${day}` as AutomationLocaleKey)).join(' · '),
        time: schedule.time,
      })
  }
}

export type AutomationSortKey = 'created' | 'planned'
export type AutomationSortDirection = 'asc' | 'desc'

function sortStamp(value: string): number {
  const parsed = Date.parse(value)
  return Number.isFinite(parsed) ? parsed : 0
}

/** 工作区任务列表排序：计划时间 = nextRunAt，无计划的任务固定排最后。 */
export function sortAutomations(
  items: readonly AutomationViewModel[],
  key: AutomationSortKey,
  direction: AutomationSortDirection,
): AutomationViewModel[] {
  const factor = direction === 'asc' ? 1 : -1
  return items.slice().sort((left, right) => {
    if (key === 'planned') {
      const leftNext = left.nextRunAt
      const rightNext = right.nextRunAt
      if (leftNext === undefined || rightNext === undefined) {
        if (leftNext === undefined && rightNext === undefined) {
          return left.name.localeCompare(right.name) || left.id.localeCompare(right.id)
        }
        return leftNext === undefined ? 1 : -1
      }
      const primary = sortStamp(leftNext) - sortStamp(rightNext)
      if (primary !== 0) return primary * factor
      return left.name.localeCompare(right.name) || left.id.localeCompare(right.id)
    }
    const primary = sortStamp(left.createdAt) - sortStamp(right.createdAt)
    if (primary !== 0) return primary * factor
    return left.id.localeCompare(right.id)
  })
}

export interface SortPreferenceStorage {
  getItem(key: string): string | null
  setItem(key: string, value: string): void
}

export function resolveSortPreferenceStorage(
  owner: { readonly localStorage: SortPreferenceStorage } | undefined,
): SortPreferenceStorage | undefined {
  if (owner === undefined) return undefined
  try {
    return owner.localStorage
  } catch {
    return undefined
  }
}

export const WORKSPACE_SORT_DEFAULT_KEY = 'dsh-automation.sort-default.workspace'

/** 读取已保存的默认排序；缺失、损坏或无存储时返回 undefined，由调用方用自身默认值。 */
export function readSortDefault(
  storage: SortPreferenceStorage | undefined,
  storageKey: string,
): { readonly key: AutomationSortKey; readonly direction: AutomationSortDirection } | undefined {
  if (storage === undefined) return undefined
  try {
    const raw = storage.getItem(storageKey)
    if (raw === null) return undefined
    const parsed = JSON.parse(raw) as { readonly key?: unknown; readonly direction?: unknown }
    if (parsed.key !== 'created' && parsed.key !== 'planned') return undefined
    if (parsed.direction !== 'asc' && parsed.direction !== 'desc') return undefined
    return { key: parsed.key, direction: parsed.direction }
  } catch {
    return undefined
  }
}

export function writeSortDefault(
  storage: SortPreferenceStorage,
  storageKey: string,
  key: AutomationSortKey,
  direction: AutomationSortDirection,
): void {
  try {
    storage.setItem(storageKey, JSON.stringify({ key, direction }))
  } catch {
    // Preference persistence is best-effort; storage denial must not break sorting.
  }
}


/** Preference reads also tolerate browsers that expose storage but deny getItem. */
export function readRangeDefault(storage: SortPreferenceStorage | undefined, key: string): 'week' | 'month' | 'list' {
  try {
    const value = storage?.getItem(key)
    return value === 'month' || value === 'list' ? value : 'week'
  } catch { return 'week' }
}
