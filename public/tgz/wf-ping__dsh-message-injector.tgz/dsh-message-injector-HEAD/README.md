# dsh-message-injector

> English: [README_EN.md](README_EN.md)

dsh（DeepSeek Harness）插件：预设常用"消息注入内容"组合（任意文本 / 技能调用），**每条消息自动注入**到输入框首行，一键启用、切换、停止——不需要每条消息手动输入固定的指令前缀或格式要求。

## 功能

- **预设组管理**：输入框左下角「预设」→ 菜单底部「配置」→ 弹窗里增删改查、启用/禁用、组排序、组折叠（配置存 dsh 配置系统，即时生效）
- **一键选择**：输入框左下角的「预设」选择器，点击选中，再点反选
- **配置入口**：选择器菜单底部「配置」，直接弹出管理弹窗
- **自动注入**：空输入框 ~500ms 自动注入内容（如 `/grill-me /domain-modeling ` 或 "请用中文回答"）
- **技能校验**：以 `/` 开头的内容视为技能调用，缺失时配置卡警告、注入时跳过
- **智能守卫**：输入框已有内容时不注入，绝不打扰已有内容
- **全局持久化**：选择状态跨会话、刷新、标签页保持，终端 `dsh web` 与 VS Code 面板共享

## 配置存储位置

预设组与选中状态存在 **dsh 配置系统**（settings 命名空间 `dsh-message-injector`，落盘在当前 profile 的 `cordis.patch.yml`）。因为存在宿主侧，终端 `dsh web` 和 VS Code 面板读到的是同一份，换浏览器也不丢。

宿主没有该命名空间时（老版本 dsh / 未挂 settings）自动退回浏览器 localStorage（键 `dsh-message-injector:config`）。升级后首次加载会把旧 localStorage 的预设并进宿主：同名组以宿主为准，旧数据独有的组补进去，不会丢组。

> 0.1.x 的旧数据在 `$DSH_HOME/settings.yaml.imported` 的 `message-injector:` 段，dsh 0.2 已不再读取；升级后需在弹窗里重新录入一次。

## 快速安装

```bash
dsh plugin --profile web add github:wf-ping/dsh-message-injector        # 从 GitHub 安装（默认 = 最新，跟随 main）
dsh plugin --profile web add github:wf-ping/dsh-message-injector#v0.2.1  # 固定版本安装（可选）
dsh plugin --profile web add <本仓库路径>                # 本地/开发时安装
```

> 首次安装均无需构建（`lib/` 产物已提交）。详见[安装文档](docs/zh/安装.md)。

## 重新构建

改代码后需要重新生成 `lib/` 并重启生效：

```bash
pnpm install      # 安装运行环境
pnpm build        # 生成产物
dsh web           # 启动服务
```

## 更新

**本地路径安装（软链接）** —— 更新 = 改代码 + 重新构建，无需重装：

```bash
pnpm build        # 重新生成 lib/
# 重启 dsh web 生效
```

**GitHub 安装（克隆副本）** —— 已装副本与本地代码无关，更新需重新拉取：

```bash
dsh plugin --profile web add github:wf-ping/dsh-message-injector    # 重新拉取最新版本
# 重启 dsh web 生效
```

> 若重新 add 后仍未更新，先卸载再重装（见[卸载](#卸载)）。

## 卸载

```bash
dsh plugin --profile web remove dsh-message-injector    # 卸载
# 或在仓库目录内：pnpm uninstall:plugin
```

## 文档

- [安装](docs/zh/安装.md)
- [使用说明](docs/zh/使用说明.md)
- [架构](docs/zh/架构.md)
- [迭代记录](docs/zh/迭代记录.md)
- [更新日志](CHANGELOG.md)

> 开发者：需求文档见 `docs/zh/需求.md`，开发经验（踩坑记录）见 `docs/zh/开发经验.md`，术语表见 `CONTEXT.md`。
