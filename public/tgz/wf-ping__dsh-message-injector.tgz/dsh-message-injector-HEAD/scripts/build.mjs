/**
 * 构建插件两端（产物提交在 lib/，安装即用，无需用户构建）：
 *   1. 后端：src/host/index.ts    → lib/index.js   （ESM；schemastery/dsh-settings 保持外部解析）
 *   2. 前端：src/client/index.tsx → lib/client.js （__ModuleLoader__.load 形态，浏览器端标准格式）
 *
 * 目录约定：src/ 按官方 half 分法分 host（后端）/ client（前端）两个目录。
 * 用法：pnpm build
 */
import { build } from 'esbuild'
import { mkdirSync, writeFileSync } from 'node:fs'

// ─── 1. 后端（host half）────────────────────────────────────────────
const host = await build({
  entryPoints: ['src/host/index.ts'],
  bundle: true,
  format: 'esm',
  platform: 'node',
  target: 'node20',
  // schemastery 由 dsh 运行时提供（与 dsh 版本绑定），不内联
  external: ['@deepseek-ai/schemastery'],
  write: false,
  logLevel: 'info',
})
mkdirSync('lib', { recursive: true })
writeFileSync('lib/index.js', host.outputFiles[0].text)
console.log('built lib/index.js (' + host.outputFiles[0].text.length + ' bytes)')

// ─── 2. 前端（client half）──────────────────────────────────────────
const external = [
  'react',
  'react-dom',
  'react/jsx-runtime',
  '@deepseek-ai/dsh-client-ui-primitives',
]
const client = await build({
  entryPoints: ['src/client/index.tsx'],
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  jsx: 'automatic',
  external,
  write: false,
  logLevel: 'info',
})

const code = client.outputFiles[0].text
const wrapped = `window.__ModuleLoader__.load({
\tid: "dsh-message-injector",
\tfactory: (require) => {
\t\tvar module = { exports: {} };
\t\tvar exports = module.exports;
${code}
\t\treturn module.exports;
\t}
});
`

writeFileSync('lib/client.js', wrapped)
console.log('built lib/client.js (' + wrapped.length + ' bytes)')
