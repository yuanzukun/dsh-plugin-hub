/**
 * `zhihu_global_search` —— 知乎全网搜索工具。
 *
 * 为什么它必须与站内搜索分成两个工具，而不是一个工具的开关：
 * 两者的 `Filter` 语法**互不兼容** —— 站内只认 `publish_time`，
 * 全网才认 `host`。合成一个工具意味着模型要记住「哪个参数在哪个模式下非法」，
 * 那是必然出错的负担。拆开后每个工具的参数集合都是自洽的。
 *
 * 实测补充：`SortBy` 在本端点**疑似被忽略**（返回顺序不随排序字段变化），
 * 因此刻意不暴露 `sortField`，避免给模型一个看起来有用但无效的旋钮。
 */

import { defineTool, type ToolDefinition } from '@deepseek-ai/dsh-tools';
import { compileFilter } from '../utils/compiler.js';
import {
  presentSearchCall,
  presentSearchResult,
  renderSearch,
  searchMetaFromValue,
} from '../present/search.js';
import { GLOBAL_SEARCH_MAX_COUNT } from '../transport.js';
import {
  executeSearch,
  rawRequestedCount,
  resolveRequestedCount,
  SEARCH_OUTPUT_SCHEMA,
} from './search-shared.js';
import type { ToolDeps } from './deps.js';

/** 工具名。 */
export const ZHIHU_GLOBAL_SEARCH_TOOL = 'zhihu_global_search';

/**
 * 全网搜索的 `Count` 上限（实测：比站内搜索宽，可达 20）。
 *
 * 与站内搜索同理：数字只住在传输层的端点契约常量里，这里取别名。
 */
const MAX_COUNT = GLOBAL_SEARCH_MAX_COUNT;
/** 未指定时使用的条数。 */
const DEFAULT_COUNT = 8;

/**
 * 参数白名单。
 *
 * 与站内搜索同理：宿主参数 schema 是开放的（DSL 不接受 `additionalProperties: false`），
 * 未知键会被静默丢弃 —— 模型传 `page=2` 会拿到第一页却以为翻页成功。
 * 与参数定义的一致性由 `test/tool.test.ts` 断言守着。
 */
const PARAM_NAMES = [
  'query',
  'count',
  'site',
  'publishedAfter',
  'publishedBefore',
  'searchDb',
] as const;

/** 协作式超时预算。 */
const TIMEOUT_MS = 20_000;

/**
 * 构造 `zhihu_global_search` 工具。
 *
 * @param deps - 运行期依赖。
 * @returns 可直接注册的工具定义。
 */
export function createZhihuGlobalSearchTool(deps: ToolDeps): ToolDefinition {
  return defineTool({
    name: ZHIHU_GLOBAL_SEARCH_TOOL,
    description:
      '知乎全网索引搜索：检索知乎索引收录的公开网页，结果里会混入部分知乎站内内容。' +
      '适合按站点域名或发布时间找资料；要专搜知乎的问答和文章、且要更贴题的排序，用 zhihu_search。' +
      // 不重复 count / site 的取值（那两处归参数说明，schema 每次都随描述进上下文）；
      // 结果形态槽只写模型拿得到什么、拿不到什么。
      '结果含标题、链接、摘要、作者与时间，知乎来源另带点赞数与评论数，不含图片；没有翻页参数。',

    parameters: {
      query: { type: 'string', required: true, description: '搜索关键词。' },
      count: {
        type: 'integer',
        description: `返回条数，1–${String(MAX_COUNT)}，默认 ${String(DEFAULT_COUNT)}。`,
        default: DEFAULT_COUNT,
      },
      site: {
        type: 'string',
        description:
          '只搜索该域名，例如 github.com；传完整 URL 会被剥成主机名并去掉开头的 www.。域名是精确匹配（子站要单独写），不支持知乎域名。',
      },
      publishedAfter: {
        type: 'string',
        description: '只要该日期之后发布的内容，格式 YYYY-MM-DD。',
      },
      publishedBefore: {
        type: 'string',
        description: '只要该日期之前发布的内容，格式 YYYY-MM-DD。',
      },
      searchDb: {
        type: 'string',
        enum: ['all', 'realtime', 'static'],
        description: '索引库，默认 all。realtime 偏最新，static 偏长期收录。',
        default: 'all',
      },
    },

    output: {
      schema: SEARCH_OUTPUT_SCHEMA,
      render: (args, value) =>
        renderSearch(value, {
          // 必须传**原始**请求值：传夹取后的值会让到顶提示永远不触发。
          requestedCount: rawRequestedCount(args.count, DEFAULT_COUNT),
          maxCount: MAX_COUNT,
          filtered:
            args.site !== undefined ||
            args.publishedAfter !== undefined ||
            args.publishedBefore !== undefined ||
            (args.searchDb !== undefined && args.searchDb !== 'all'),
          scope: 'global',
        }),
      presentationMeta: (_args, value) => searchMetaFromValue(value),
    },

    timeoutMs: TIMEOUT_MS,
    isConcurrencySafe: () => true,
    presentCall: (args) => presentSearchCall(args),
    presentResult: (args, result) => presentSearchResult(args, result),

    async execute(args, exec) {
      return executeSearch({
        deps,
        args,
        paramNames: PARAM_NAMES,
        toolName: ZHIHU_GLOBAL_SEARCH_TOOL,
        signal: exec.signal,
        plan: (query) => {
          const count = resolveRequestedCount(args.count, {
            max: MAX_COUNT,
            fallback: DEFAULT_COUNT,
          });

          // 全网作用域：允许 host；编译器会拦下知乎域名并给出「请用站内搜索」的提示。
          const filter = compileFilter(
            {
              ...(args.site === undefined ? {} : { site: args.site }),
              ...(args.publishedAfter === undefined ? {} : { publishedAfter: args.publishedAfter }),
              ...(args.publishedBefore === undefined
                ? {}
                : { publishedBefore: args.publishedBefore }),
            },
            'global',
          );

          const searchDb = args.searchDb ?? 'all';
          return {
            cacheArgs: { query, count, filter, searchDb },
            fetch: (signal) =>
              deps.client.searchGlobal(
                {
                  query,
                  count,
                  ...(filter === undefined ? {} : { filter }),
                  ...(searchDb === 'all' ? {} : { searchDb }),
                },
                signal,
              ),
            // 全网不扩池、不截断：缓存里存什么就返回什么。
            onReturn: (value) => value,
          };
        },
      });
    },
  });
}
