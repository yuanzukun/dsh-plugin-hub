# present/ — 纯函数呈现层

- 职责：模型可见 Markdown、可持久化元数据、UI 卡片。三者严格分离。
- 硬性特征：**没有任何运行时依赖**（DSH 类型全部 `import type`），因此可被单元测试直接调用。

## 文件索引

- `search.ts`：搜索类工具共用。导出 `renderSearch`（第二参数 `SearchRenderContext` 携带请求条数、下限、端点上限、是否有筛选条件、工具作用域 —— 四条诚实渲染不变量都靠它：到顶提示、来源构成分流、空态条件限定、下限只筛候选）、`searchMetaFromValue`、`searchMetaFromResult`、`presentSearchCall`、`presentSearchResult` 与 `SearchMeta` / `SearchRenderContext` 类型。被 `tools/search.ts` 与 `tools/global-search.ts` 依赖。
- `error-block.ts`：搜索与直答共用的失败分支渲染。导出 `errorBlock(prefix, error)` —— 两处错误文本原本逐字重复，只有前缀文案不同；`error` 用 `utils/errors` 的 `CanonicalError` 收窄，纯类型导入。
- `zhida.ts`：直答专用。导出 `renderZhida`、`presentZhidaCall`、`presentZhidaResult` —— **刻意不声明 `presentationMeta`**：直答没有可持久化的结构化元数据，为此凑一个空壳只会把「三者严格分离」变成形式主义。

## 变更影响路由

- 改任一导出 → 跑 `test/presentation.test.ts` 与 `test/redlines.test.ts`（红线 2 与红线 3 的守卫）。

## 参考

- 三层分离的设计理由 → 见 [docs/ARCHITECTURE.md](../../docs/ARCHITECTURE.md) 的「不可破坏的约束」
- 模型可见文本怎么写才算诚实 → 见同一文档的「模型可见文本的诚实性」
- 使用约束与工作偏好 → 见 [AGENTS.md](AGENTS.md)
