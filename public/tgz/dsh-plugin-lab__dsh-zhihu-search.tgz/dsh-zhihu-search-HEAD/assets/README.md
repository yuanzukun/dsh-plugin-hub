# assets/ — 展示图

两份 README 引用的展示图都住在这里；触发判据、截图步骤与验收见 [AGENTS.md](AGENTS.md)。

## 文件与引用面

- `banner.svg`：头图，双语共用，被 [README.md](../README.md) 与 [README_en.md](../README_en.md) 引用。
- `zhihu-daily-quota.jpg`：知乎开放平台「各接口剩余配额」面板的截图，双语 README 共用（**额度**按自然日刷新，这张图是静态截图、不随日更换）。
- `logo.svg`：523×346 的横版**字标**，本身未被引用，但它是包根 [icon.svg](../icon.svg) 的**来源** ——
  图标取的是它三块里的**两支**（`fill="#0084FF"` 那只鲸鱼 + `fill="black"` 那个「知」方标），
  **丢掉底部那行 `dsh-zhihu-search` 小字**，两支同填知乎蓝，按官方留白等比缩进 36×36 画布。
  **两者不是同一份东西**：改 logo 不自动改图标，改图标也不必动 logo → [图标记录](../.agents/notes/2026-09-22-plugin-icon.md)。
- `banner.jpg`、`logo.jpg`、`slogan.jpg`、`slogan.svg`：未引用。
- `settings-card.png`：配置卡片所在页面的整屏实拍（中文，2026-09-22 重截，2449×1223；图里版本 tag `v2.0.0-alpha.1`），被 [README.md](../README.md) 引用。
- `settings-card_en.png`：同一画面的英文版（同日重截，2449×1223），被 [README_en.md](../README_en.md) 引用。

> **两张卡片图已于 2026-09-22 重截完毕，与当前界面一致**（第二轮重截：发布流程改成版本驱动、
> 版本号 bump 到 `2.0.0-alpha.1` 之后拍的）。这一次它们同时追上了四处改动：
> ① 配置入口回到 bundle 详情页内联（点插件名进去就是配置区，行上没有 Configure 步骤）；
> ② 页面上的**显示名与描述**改读包根 [locale/](../locale/) 的 `meta`（中文 `知乎检索`、英文 `Zhihu Search`，
> 标题下方那句描述从空变成一句话）；③ 左上角那格**图标**换成包根 [icon.svg](../icon.svg)
> （`#0084FF` 的「鲸鱼 + 知」双拼）；④ **版本 tag 是 `v2.0.0-alpha.1`** ——
> 上一轮拍到的是**已发布的旧号**（`v2.0.0-alpha.0`），因为那时发布流程自己 bump、工作树停在旧号上。
> 顺序因此定死：**bump → 提交 → 再截图 → 最后发布**（见 [docs/PUBLISHING.md](../docs/PUBLISHING.md) 的「发版前确认」）。
> 两张只有界面语言不同，其余（开关 / 徽标现状）都按拍摄当时的真实状态拍。
> 拍摄路径与**判废项**见 [AGENTS.md](AGENTS.md) 第 3 步与「验收」一节。

两份 README 都以 `width=600` 展示。
`assets/` **不进 npm 包**：npm 会把 README 的相对图片路径改写到默认分支的 raw 地址，线上展示跟的是 `main` 上的图 —— **改图等于同时改所有历史版本的展示**。

## 风格基准

新图与现有图保持一致；要不要换风格是维护者的决定，截图的人不自行改。

| 项 | 基准 |
| --- | --- |
| 尺寸 | 整屏图**不设 viewport**，用自然视口拍 —— 物理产物自然就是 **2449x1223**（CSS 1484x741 × dpr 1.65）；**别调 `setViewportSize`**，那会压掉 dpr、界面缩到约 60%。中英两张一致；见 [AGENTS.md](AGENTS.md) |
| 侧边栏 | **按快门前必须收起**（导航时先展开，否则点不到 `Plugins`）：展开的左侧栏带出维护者真实的会话标题与工作区名，理由与顺序见 [AGENTS.md](AGENTS.md) 第 4 步 |
| 背景 | 空会话 |
| 主题 | 浅色 |
| 配置区 | 完整可见，底部唯一保存按钮在图内（原生表单不可折叠） |
| 两张的关系 | 只有界面语言不同 |

**侧栏为什么必须收起**：展开的左侧栏列的是维护者真实的会话标题与工作区名 —— 那是别人的工作内容，不是装饰；门面图是给外人看的，带出去就是泄露。
收起状态下点不到 `Plugins`，所以顺序也是死的：**展开导航 → 走到目标画面 → 收起侧栏 → 按快门**。
收起侧栏**是动画**，等固定时长不算保证：点完要轮询到侧栏宽度**连续两次采样相同**再按快门，超时按报错重来；拍到中间帧的图**判废重拍**。切语言、切视图、展开折叠区之后同理（[AGENTS.md](AGENTS.md) 第 4 步）。

开关状态**不属基准** —— 规则与理由见 [AGENTS.md](AGENTS.md)。

## 与发版的关系

`assets/` 是非产物（[release-guard.mjs](../scripts/release-guard.mjs) 的 `NON_ARTIFACT_PREFIXES`）。
重截图不触发发版，搭引起它的那次 UI 改动一起走；只含 assets 的区间会被守卫拦下（需 `force`）。
判例：`d0a3adb` 只改 assets + 两处 `.md`，未发版，`git tag --contains d0a3adb` → `v1.4.0`（搭车）。

## 变更影响路由

- 改卡片渲染面 → **必须同批重截**两张卡片图，判据与步骤见 [AGENTS.md](AGENTS.md)。
- 改包根 [icon.svg](../icon.svg) → 同上**必须重截**（它就是卡片左上角那格图）；改 [../assets/logo.svg](logo.svg)
  **不**自动改图标，但两份 README 的头图引用面要一起看。
- 改包根 [locale/](../locale/) 的 `meta.title` / `meta.description` → 图里的**页面标题与描述**跟着变
  （卡片本体不变，但它画在详情页里）。按 [AGENTS.md](AGENTS.md) 的「拿不准时按必须重截办」处理；
  这一条也顺带挪动两份根 README 的「配置」节与 [assets/AGENTS.md](AGENTS.md) 的判废项。
- 换图本身 → 两份 README 无需改（路径与 `width` 不变）；只有文件改名才要同步两份 README 与本目录两份文档。
