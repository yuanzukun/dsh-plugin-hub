/**
 * Host-half build for the installable bundle: the two Node plugin rows
 * `cordis.patch.yml` names.
 *
 * A profile bundle is resolved from the profile's `node_modules` and imported
 * by plain Node, so the `.ts` sources under `src/` have to arrive as `.js`
 * before the launcher can load them. The browser half is a separate artifact
 * built by `src/debate-client/tsdown.config.ts`.
 *
 * Every bare specifier stays external, which covers `node:` builtins as well.
 * The orchestrator's only runtime package imports are `@deepseek-ai/dsh-tools`
 * and `@deepseek-ai/schemastery`, and both must be the running installation's
 * instances — a `defineTool` or schema from a second copy is a different class
 * to every registry that receives it. Node resolves them by walking out of the
 * profile into the launcher's dependency closure at
 * `$DSH_HOME/profiles/node_modules`, which is why this package declares them as
 * optional peers rather than dependencies.
 */
import { defineConfig } from 'tsdown'

/**
 * Anything that is not a path, i.e. every package import. `tsdown` feeds the
 * resolved absolute path to `neverBundle`, so the pattern must reject every
 * filesystem path, not just relative ones: `.` for relative, `/` for
 * POSIX-absolute, and a drive letter or `\` for Windows-absolute. A bare
 * specifier that matched by mistake (e.g. `C:\…\types.ts` under the drive
 * letter) is left external and never emitted.
 */
const BARE_SPECIFIER = /^(?![./\\]|[a-zA-Z]:)/

export default defineConfig({
  name: '@shlouai/dsh-debate',
  entry: {
    'debate/plugin': 'src/debate/plugin.ts',
    'debate-client/index': 'src/debate-client/index.ts',
  },
  outDir: 'lib',
  format: 'esm',
  platform: 'node',
  target: 'es2024',
  deps: {
    neverBundle: (specifier: string) => BARE_SPECIFIER.test(specifier),
  },
  dts: false,
  clean: true,
  sourcemap: true,
  // `cordis.patch.yml` names these files; the default esm extension is `.mjs`.
  outputOptions: {
    entryFileNames: '[name].js',
  },
})
