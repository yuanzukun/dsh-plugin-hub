/**
 * Runs a formal debate for the calling agent, as a dsh plugin row mounted
 * through a `--patch` overlay on top of a shipped profile.
 *
 * Three tools split one debate across several model turns. `debate_open` fixes
 * the motion and the round count. `debate_round` spends one round: it starts a
 * one-shot child for the FOR side, then a second child for the AGAINST side
 * that has already read the first speech, and returns both speeches. The judge
 * says nothing to the debaters while the debate runs; it rules once, after the
 * last round, with `debate_verdict`, which carries both its assessment of the
 * debate and the ruling. One round per call bounds a single call's spend at two
 * children, shows the debate as it happens, and lets a failed round be retried
 * without re-arguing the rounds before it.
 *
 * Debaters are ordinary one-shot subagents with a per-child persona and a
 * read-only research set: by default a debater may read the workspace and
 * search the web, so a claim about this repository or about the world can be
 * checked before it is made rather than recalled, while nothing it is given can
 * write or execute.
 *
 * That set is resolved per speech rather than trusted from config, against two
 * facts a profile decides. A tool this deployment does not mount is dropped —
 * `tools.restrict()` rejects an unknown name outright, and the default set
 * deliberately names tools that only some profiles carry. Web search is
 * additionally withheld until its credential resolves, because the tool is
 * mounted whether or not its backend can authenticate a query; a debater given
 * it unconfigured would spend its one turn discovering that.
 *
 * A debater keeps no conversation of its own — each speech is a fresh child
 * handed the whole transcript — so a debate has exactly one durable record,
 * this parent's log.
 *
 * Each tool projects its part of that record through `output.presentationMeta`,
 * which the tools plane persists verbatim as the `meta` of the `tool/result`
 * event the call already writes. So the debate is display input carried by an
 * event type the harness itself declares, and this plugin contributes no event
 * type of its own: persistence refuses a log holding a type outside the
 * catalog it generates from `packages/`, which a downstream plugin's own event
 * never enters, and a session that held a debate would then be unreadable.
 *
 * A projection is pure over one call's arguments and its validated output
 * value, since the tools plane replays it on a stored log as well as running it
 * live. It therefore cannot consult the live debate below, and the `meta` of a
 * call nested inside a `run_code` program is not projected at all — a debate
 * driven from a program argues normally and simply shows no card.
 *
 * @module debate
 */

import { randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { SessionId } from '@deepseek-ai/dsh-session'
// Type-only: it declares `ctx.credentials` and brands the reference this plugin
// asks about. Nothing is imported at runtime, so the bundle's dependency
// closure is unchanged and a deployment without the plane still loads.
import type { CredentialRef } from '@deepseek-ai/dsh-credentials'
// The index, not `/types`: it declares the `subagents` service this
// orchestrator drives, which the payload-only `/types` entry does not carry.
import type { SubagentResult } from '@deepseek-ai/dsh-subagent'
import type {
  DebateId, DebateOpenMeta, DebateOutcome, DebateRoundMeta, DebateSide, DebateVerdictMeta,
} from './types.ts'
import { DEBATE_META_KIND } from './types.ts'

/** Cordis plugin name. */
export const name = 'debate'

/** The tool registry this plugin contributes to and the backend it runs debaters on. */
export const inject = ['tools', 'subagents']

/**
 * Plugin config. Every field but `provider` carries a schema default, so the
 * default value has one home — the schema below — and `apply` reads the
 * resolved value directly.
 */
export interface Config {
  /**
   * Subagent provider the debaters run on. It must support `persona` and
   * `toolFilter`; the shipped `spawn` backend does.
   */
  provider: string
  /**
   * Largest round count a debate may open with. Each round costs two child
   * agents, so the ceiling bounds one `debate_open` call's total spend rather
   * than any single request.
   */
  maxRounds: number
  /**
   * Maximum characters of one speech. Every later speech reads every earlier
   * one, so an unbounded speech would grow the next prompt quadratically.
   */
  maxSpeechLength: number
  /**
   * Global tool names a debater may use, as an allow list; empty denies all of
   * them, leaving a debater with argument alone. The default is read-only —
   * the workspace and the web, nothing that writes or executes — because a
   * debater researches its own case rather than doing work for the judge. A
   * name this deployment does not mount is skipped, so the list may name tools
   * only some profiles carry.
   */
  debaterTools: string[]
  /**
   * Names from {@link debaterTools} that stay out of a debater's hands unless
   * {@link searchCredential} resolves. Web search is the whole reason this
   * exists: the search tool is mounted whether or not its backend has a key,
   * so an unconfigured deployment would otherwise hand every debater a tool
   * that fails on contact and let it spend the speech finding that out.
   * Emptying this list offers everything in `debaterTools` unconditionally.
   */
  searchTools: string[]
  /**
   * Credential reference {@link searchTools} require: an environment-variable
   * name resolved through the credential plane — the inherited process
   * environment, then `$DSH_HOME/.credentials.yaml`, then the `.env` layers.
   * Only its presence is ever read here; the value stays in the plane.
   *
   * `DEEPSEEK_API_KEY` is what `dsh-base` wires its search backend to. A
   * deployment that points `web`'s `searchProvider` at Exa or Perplexity names
   * that backend's variable instead, since those read no managed store.
   */
  searchCredential: string
  /**
   * Persona shadowing the deployment's for both debaters. It states the shared
   * craft only: the assigned side, the motion, and the transcript are per-debate
   * facts and reach the child through its prompt. Interpolated strictly against
   * the registered persona variables, so `{{…}}` here must name one.
   */
  debaterPersona: string
}

const DEFAULT_DEBATER_PERSONA = [
  'You are a competitive debater in a judged formal debate.',
  'You argue the side you are assigned, whatever you privately believe, and you argue it to win.',
  'Make your own case concretely, attack the strongest version of your opponent\'s case rather than a weak paraphrase, and concede a point only when conceding it buys you a larger one.',
  'Where a claim can be checked, check it and say what you checked; never invent a quotation, a number, or a source, because a fabrication your opponent catches costs you more than the point it was meant to win.',
  'Never break character, never comment on the debate format, and never address the judge as anything but the judge.',
].join(' ')

/**
 * Read-only research set a debater gets unless the profile says otherwise: the
 * workspace through `read`, with `glob` and `grep` to find what is worth
 * reading — a debater is handed the motion, never a path — and the open web
 * through `web_search` and `web_fetch`. Nothing here writes or executes, so a
 * debater can support a claim without acting on the judge's behalf.
 *
 * `dsh-base` mounts all of these but `web_fetch`, which the `standard` agent
 * preset turns on; a profile carrying neither loses that name alone rather than
 * the whole set.
 */
const DEFAULT_DEBATER_TOOLS = ['read', 'glob', 'grep', 'web_search', 'web_fetch']

/**
 * Tools withheld until the search credential resolves. `web_search` is the only
 * default that needs one: its backends authenticate every query, while
 * `web_fetch` retrieves a URL anonymously and `read`, `glob`, and `grep` never
 * leave the workspace.
 */
const DEFAULT_SEARCH_TOOLS = ['web_search']

/** The credential `dsh-base` wires its search backend to. */
const DEFAULT_SEARCH_CREDENTIAL = 'DEEPSEEK_API_KEY'

/**
 * Grammar of a credential reference, as the credential plane brands one. This
 * plugin casts a configured name instead of importing the branding helper — a
 * type-only dependency keeps the bundle's runtime closure to the two peers it
 * already declares — so the check the helper would have made is made here,
 * where a typo fails at mount rather than mid-debate.
 */
const CREDENTIAL_REF_PATTERN = /^[A-Za-z_][A-Za-z0-9_]*$/

export const Config: z<Config> = z.object({
  provider: z.string().required(),
  maxRounds: z.natural().min(1).default(8),
  maxSpeechLength: z.natural().min(1).default(2000),
  debaterTools: z.array(z.string()).default(DEFAULT_DEBATER_TOOLS),
  searchTools: z.array(z.string()).default(DEFAULT_SEARCH_TOOLS),
  searchCredential: z.string().default(DEFAULT_SEARCH_CREDENTIAL),
  debaterPersona: z.string().default(DEFAULT_DEBATER_PERSONA),
})

/** How a side is named to the debaters and in the transcript they read. */
const SIDE_LABEL: Record<DebateSide, string> = { pro: 'FOR', con: 'AGAINST' }

/** How the final ruling is named back to the judging agent. */
const OUTCOME_LABEL: Record<DebateOutcome, string> = { pro: 'FOR', con: 'AGAINST', draw: 'a draw' }

/** One committed speech, as the next speaker reads it. */
interface TranscriptLine {
  /** One-based round this line belongs to. */
  readonly round: number
  /** Which side spoke; the judge never contributes a line. */
  readonly speaker: DebateSide
  /** The speech, already bounded by the orchestrator's limit. */
  readonly text: string
}

/** One live debate. Process-local: a debate does not survive a restart. */
interface DebateRecord {
  readonly id: DebateId
  /** The session allowed to advance this debate; no other may name its id. */
  readonly owner: SessionId
  readonly topic: string
  readonly rounds: number
  /** Rounds fully committed. The next round is `completed + 1`. */
  completed: number
  /** Committed lines in speaking order, the next speaker's whole input. */
  transcript: readonly TranscriptLine[]
  /** Set by the final ruling; a closed debate accepts no further call. */
  closed: boolean
}

/** One debater's finished speech before the round commits it. */
interface Speech {
  readonly text: string
  readonly truncated: boolean
}

/**
 * Concatenate a child's text blocks.
 * @param content - the child's final assistant output.
 * @returns the trimmed text, or no value when it produced none.
 */
function speechText(content: readonly ContentBlock[]): string | undefined {
  let text = ''
  for (const block of content) {
    if (block.type === 'text') text += block.text
  }
  const trimmed = text.trim()
  return trimmed.length > 0 ? trimmed : undefined
}

/**
 * Build one debater's complete input. A speech is one turn of a fresh child, so
 * everything it must know — motion, side, position in the debate, and every
 * earlier contribution — is stated here rather than remembered.
 * @param record - the debate being argued.
 * @param side - the side this child argues.
 * @param round - the one-based round this speech belongs to.
 * @param transcript - every committed speech, plus this round's earlier speech.
 * @param limit - character budget for the speech.
 * @param tools - tool names this child was actually given, empty when it has none.
 * @returns the child's prompt text.
 */
function speechPrompt(
  record: DebateRecord,
  side: DebateSide,
  round: number,
  transcript: readonly TranscriptLine[],
  limit: number,
  tools: readonly string[],
): string {
  const lines = [
    `Motion: ${record.topic}`,
    '',
    `You argue ${SIDE_LABEL[side]} the motion. This is round ${round} of ${record.rounds}.`,
    '',
  ]
  if (transcript.length === 0) {
    lines.push('Nobody has spoken yet. You open the debate.')
  } else {
    lines.push('The debate so far:')
    for (const line of transcript) {
      lines.push('', `[Round ${line.round}] ${SIDE_LABEL[line.speaker]}: ${line.text}`)
    }
  }
  if (tools.length > 0) {
    // The opponent-checking clause is held back until there is a speech to
    // check: the debate's first speaker would read it as an instruction to
    // rebut something nobody has said.
    const checkOpponent = transcript.length > 0
      ? ' Check what the other side rested on as well — an argument standing on something its own source does not say is the cheapest point in the debate to take.'
      : ''
    lines.push(
      '',
      `Before you speak you may research, using these tools: ${tools.join(', ')}. Establish the claims this speech rests on rather than arguing from memory.${checkOpponent}`,
      'Cite what you found precisely enough for the judge to check it: the path, and the line, for a file; the title and the URL for a page. A tool that fails or finds nothing is a dead end rather than a reason to stall — say what you could not establish and argue the point on its merits.',
      'Research serves this one speech and nothing after it. Stop as soon as you have what it needs.',
    )
  }
  lines.push(
    '',
    `Deliver your round ${round} speech. Advance your own case and rebut the strongest point standing against you. The judge rules only after the last round and says nothing until then, so argue to the transcript.`,
    tools.length > 0
      ? `Stay under ${limit} characters. Your final message is the speech itself — no headings, no stage directions, no meta-commentary, and no report of how you researched it.`
      : `Stay under ${limit} characters. Reply with the speech itself — no headings, no stage directions, no meta-commentary.`,
  )
  return lines.join('\n')
}

/**
 * Render one committed round the way the judging agent reads it.
 * @param round - the round just argued.
 * @param rounds - total rounds in the debate.
 * @param pro - the FOR speech.
 * @param con - the AGAINST speech.
 * @returns the model-facing round report.
 */
function roundReport(round: number, rounds: number, pro: string, con: string): string {
  const closing = round < rounds
    ? 'Keep your assessment to yourself for now and call debate_round again for the next round.'
    : 'That was the last round. Assess the whole debate and rule with debate_verdict.'
  return [
    `Round ${round} of ${rounds}.`,
    '',
    `${SIDE_LABEL.pro}: ${pro}`,
    '',
    `${SIDE_LABEL.con}: ${con}`,
    '',
    closing,
  ].join('\n')
}

/**
 * Register the three debate tools. Live debates are held in this plugin
 * instance, so unloading it ends every debate in progress.
 * @param ctx - the mounting context.
 * @param config - resolved plugin config.
 */
export function apply(ctx: Context, config: Config): void {
  const { provider, maxRounds, debaterTools, debaterPersona } = config
  const { searchTools, searchCredential } = config
  const speechLimit = config.maxSpeechLength
  const debates = new Map<DebateId, DebateRecord>()
  /** Configured names already reported absent, so one missing tool warns once rather than twice a round. */
  const reportedMissing = new Set<string>()
  /** Whether the withheld-search notice has been given; the gate is re-read every speech, the notice is not. */
  let reportedSearchGate = false

  if (searchTools.length > 0 && !CREDENTIAL_REF_PATTERN.test(searchCredential)) {
    throw new Error(`debate: searchCredential "${searchCredential}" is not an environment-variable name (${String(CREDENTIAL_REF_PATTERN)})`)
  }

  /**
   * Whether the search credential currently resolves to a value.
   *
   * Asked per speech rather than once at mount, because the managed store
   * publishes an external edit as it happens: a key added while a debate is
   * running reaches the next round without restarting the profile. The `.env`
   * layers are a boot snapshot and do need one, which is the launcher's
   * property rather than this plugin's.
   *
   * Only presence is read. `describe` answers whether resolution WOULD return a
   * value, so the secret itself never enters this plugin.
   * @returns true when a value is configured in any credential layer.
   */
  async function searchCredentialConfigured(): Promise<boolean> {
    const credentials = ctx.get('credentials')
    if (credentials === undefined) {
      // No credential plane mounted: the launcher's environment is the whole of
      // it, and the boot sequence has already materialized its `.env` layers.
      const ambient = process.env[searchCredential]
      return ambient !== undefined && ambient.length > 0
    }
    return (await credentials.describe(searchCredential as CredentialRef)).configured
  }

  /**
   * Resolve the tools one debater may use: the configured list, narrowed to
   * what this deployment mounts, then to what it can actually authenticate.
   *
   * The mounting check exists because the child inherits the judging agent's
   * surface and `tools.restrict()` rejects a name it cannot see there, so an
   * absent tool has to be dropped before the spawn rather than caught after it:
   * the default set names `web_fetch`, which a bare `dsh-base` profile leaves
   * unmounted, and a debate whose every round failed over one missing tool is
   * worse than a debate argued without it.
   *
   * The credential check exists because being mounted and being usable are
   * different things for a search tool. It is offered only when its key
   * resolves — a debater handed a tool that fails on contact would spend its
   * one turn discovering that instead of arguing.
   * @param parent - the judging agent whose visible tools the child inherits.
   * @returns the allow list for the child, in configured order.
   */
  async function resolveDebaterTools(parent: Agent): Promise<string[]> {
    if (debaterTools.length === 0) return []
    const visible = new Set(ctx.tools.schemas(parent).map(schema => schema.name))
    const missing = debaterTools.filter(name => !visible.has(name) && !reportedMissing.has(name))
    if (missing.length > 0) {
      for (const name of missing) reportedMissing.add(name)
      ctx.logger.warn(`debate: this deployment mounts no ${missing.map(name => `"${name}"`).join(', ')}; debaters argue without ${missing.length > 1 ? 'them' : 'it'}`)
    }
    const mounted = debaterTools.filter(name => visible.has(name))
    const gated = mounted.filter(name => searchTools.includes(name))
    // Nothing gated survived the mounting check, so the credential is nobody's
    // business: asking would risk a notice about a tool this profile lacks.
    if (gated.length === 0) return mounted
    if (await searchCredentialConfigured()) return mounted
    if (!reportedSearchGate) {
      reportedSearchGate = true
      ctx.logger.warn(`debate: no ${searchCredential} is configured, so debaters argue without ${gated.map(name => `"${name}"`).join(', ')}; they keep the tools that need no credential`)
    }
    return mounted.filter(name => !gated.includes(name))
  }

  /**
   * Resolve a model-named debate the calling agent is allowed to advance.
   * @param parent - the agent that made the call.
   * @param id - the debate id as the model named it.
   * @returns the open debate that agent owns.
   * @throws when no such debate exists, another session owns it, or it is closed.
   */
  function claim(parent: Agent, id: string): DebateRecord {
    const record = debates.get(id as DebateId)
    // A debate id reaches here from model JSON, and the store spans every
    // session in the process, so ownership is checked rather than assumed.
    if (record === undefined || record.owner !== parent.session.id) {
      throw new Error(`no open debate has id "${id}"`)
    }
    if (record.closed) throw new Error(`debate "${id}" is already closed by its verdict`)
    return record
  }

  /**
   * Run one child to produce one speech. The child is disposed either way: a
   * debater has no work left once it has spoken.
   * @param parent - the judging agent delegating this speech.
   * @param signal - the calling tool's cancellation.
   * @param record - the debate being argued.
   * @param side - the side this child argues.
   * @param round - the one-based round this speech belongs to.
   * @param transcript - every line the child should have read.
   * @returns the bounded speech.
   * @throws when the child ends abnormally or produces no text.
   */
  async function speak(
    parent: Agent,
    signal: AbortSignal,
    record: DebateRecord,
    side: DebateSide,
    round: number,
    transcript: readonly TranscriptLine[],
  ): Promise<Speech> {
    // Resolved per speech rather than once at mount: the tools an agent sees
    // are the agent plane's, so a preset switched mid-session changes them, and
    // the search credential may be stored while the debate is running.
    const tools = await resolveDebaterTools(parent)
    const run = await ctx.subagents.start(provider, {
      label: `debate ${SIDE_LABEL[side]} round ${round}`,
      prompt: [{ type: 'text', text: speechPrompt(record, side, round, transcript, speechLimit, tools) }],
      parent,
      signal,
      persona: debaterPersona,
      toolFilter: { allow: tools },
    })
    let result: SubagentResult
    try {
      result = await run.result
    } finally {
      await run.dispose()
    }
    if (result.stopReason !== 'completed') {
      throw new Error(`the ${SIDE_LABEL[side]} debater ended with "${result.stopReason}"${result.diagnostic === undefined ? '' : `: ${result.diagnostic}`}`)
    }
    const text = speechText(result.output)
    if (text === undefined) throw new Error(`the ${SIDE_LABEL[side]} debater produced no speech`)
    return { text: text.slice(0, speechLimit), truncated: text.length > speechLimit }
  }

  ctx.tools.register(defineTool({
    name: 'debate_open',
    description: [
      'Open a formal debate on one motion, to be argued by two debaters while you judge it.',
      'Use this when the user asks for an answer reached by debate rather than by your own reasoning.',
      'This call only fixes the motion and the length: run each round with debate_round, then rule with debate_verdict.',
    ].join(' '),
    parameters: {
      topic: {
        type: 'string',
        required: true,
        description: 'The motion, stated so that one side can argue for it and the other against it.',
      },
      rounds: {
        type: 'integer',
        required: true,
        description: 'How many rounds each side speaks. Prefer 2 or 3 unless the user asked for a longer debate.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          debate_id: { type: 'string', required: true, description: 'Identifies this debate in later calls.' },
          topic: { type: 'string', required: true, description: 'The motion as recorded.' },
          rounds: { type: 'integer', required: true, description: 'Rounds each side will speak.' },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: [
          `Debate ${value.debate_id} is open on: ${value.topic}`,
          `Each side speaks ${String(value.rounds)} time${value.rounds === 1 ? '' : 's'}.`,
          'Call debate_round to hear round 1.',
        ].join('\n'),
      }],
      presentationMeta: (_args, value): DebateOpenMeta => ({
        kind: DEBATE_META_KIND,
        version: 1,
        debateId: value.debate_id,
        phase: 'open',
        topic: value.topic,
        rounds: value.rounds,
      }),
    },
    execute(args, exec) {
      const parent = exec.agent
      if (!parent) throw new Error('debate_open requires a calling agent')
      const topic = args.topic.trim()
      if (topic.length === 0) throw new Error('the motion cannot be empty')
      if (args.rounds < 1 || args.rounds > maxRounds) {
        throw new Error(`rounds must be between 1 and ${maxRounds}, received ${String(args.rounds)}`)
      }
      // Minted rather than counted: this id keys the debate's card in a durable
      // log, and a counter restarts at 1 with the process, so a debate opened
      // after a restart would fold into the card of one opened before it in the
      // same reloaded session. Short enough for the judge to quote back exactly
      // in the two calls that advance the debate.
      const id = `debate-${randomUUID().slice(0, 8)}` as DebateId
      debates.set(id, {
        id,
        owner: parent.session.id,
        topic,
        rounds: args.rounds,
        completed: 0,
        transcript: [],
        closed: false,
      })
      return Promise.resolve({ debate_id: id, topic, rounds: args.rounds })
    },
    presentCall: args => ({
      card: 'generic',
      title: `Open debate: ${args.topic}`,
      kind: 'other',
      rawInput: `${String(args.rounds)} rounds`,
    }),
  }))

  ctx.tools.register(defineTool({
    name: 'debate_round',
    description: [
      'Spend one round of an open debate: both debaters speak and you get both speeches.',
      'Call it once per round until the last one, then rule with debate_verdict.',
      'Say nothing about who is winning until then — the debaters never hear you, and the user reads your assessment once, with the ruling.',
    ].join(' '),
    parameters: {
      debate_id: { type: 'string', required: true, description: 'The debate to advance, from debate_open.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          round: { type: 'integer', required: true, description: 'The round just argued.' },
          rounds: { type: 'integer', required: true, description: 'Total rounds in this debate.' },
          final: { type: 'boolean', required: true, description: 'Whether this was the last round.' },
          pro: { type: 'string', required: true, description: 'The FOR speech.' },
          con: { type: 'string', required: true, description: 'The AGAINST speech.' },
          pro_truncated: { type: 'boolean', description: 'Present when the FOR speech reached the length limit and lost its ending.' },
          con_truncated: { type: 'boolean', description: 'Present when the AGAINST speech reached the length limit and lost its ending.' },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: roundReport(value.round, value.rounds, value.pro, value.con),
      }],
      presentationMeta: (args, value): DebateRoundMeta => ({
        kind: DEBATE_META_KIND,
        version: 1,
        debateId: args.debate_id,
        phase: 'round',
        round: value.round,
        pro: { text: value.pro, truncated: value.pro_truncated === true },
        con: { text: value.con, truncated: value.con_truncated === true },
      }),
    },
    async execute(args, exec) {
      const parent = exec.agent
      if (!parent) throw new Error('debate_round requires a calling agent')
      const record = claim(parent, args.debate_id)
      const round = record.completed + 1
      if (round > record.rounds) {
        throw new Error(`all ${String(record.rounds)} rounds of debate "${record.id}" are argued; rule with debate_verdict`)
      }
      // Nothing is committed and the round does not advance until both sides
      // have spoken, so a failed debater leaves the debate exactly where it was
      // and the same call can be retried.
      const pending: TranscriptLine[] = [...record.transcript]
      // Sequential, not parallel: the AGAINST speech is an answer, so it reads
      // the FOR speech of its own round.
      const pro = await speak(parent, exec.signal, record, 'pro', round, pending)
      pending.push({ round, speaker: 'pro', text: pro.text })
      const con = await speak(parent, exec.signal, record, 'con', round, pending)
      pending.push({ round, speaker: 'con', text: con.text })

      record.transcript = pending
      record.completed = round

      return {
        round,
        rounds: record.rounds,
        final: round === record.rounds,
        pro: pro.text,
        con: con.text,
        ...pro.truncated ? { pro_truncated: true } : {},
        ...con.truncated ? { con_truncated: true } : {},
      }
    },
    presentCall: args => ({
      card: 'generic',
      title: 'Debate round',
      kind: 'other',
      rawInput: args.debate_id,
    }),
  }))

  ctx.tools.register(defineTool({
    name: 'debate_verdict',
    description: [
      'Close a debate whose rounds are all argued by ruling on it.',
      'This is the only place you assess the debate: review it round by round in `judgement`, then say which side prevailed and why.',
    ].join(' '),
    parameters: {
      debate_id: { type: 'string', required: true, description: 'The debate to close, from debate_open.' },
      judgement: {
        type: 'string',
        required: true,
        description: 'Your assessment of the debate, round by round: who carried each round, on which points, and what each side left unanswered.',
      },
      winner: {
        type: 'string',
        required: true,
        enum: ['pro', 'con', 'draw'],
        description: 'Which side prevailed over the whole debate: `pro` for it, `con` against it, `draw` when neither did.',
      },
      rationale: {
        type: 'string',
        required: true,
        description: 'Why that side prevailed, decided on the arguments actually made rather than on the motion\'s merits.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          topic: { type: 'string', required: true, description: 'The motion as recorded.' },
          rounds: { type: 'integer', required: true, description: 'Rounds argued.' },
          winner: { type: 'string', required: true, enum: ['pro', 'con', 'draw'], description: 'The ruling.' },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: [
          `Debate closed after ${String(value.rounds)} round${value.rounds === 1 ? '' : 's'} on: ${value.topic}`,
          `Ruled for ${OUTCOME_LABEL[value.winner]}.`,
          'Report the ruling and its reasoning to the user.',
        ].join('\n'),
      }],
      // The assessment and its reasoning are the judge's own words, so they
      // come from the call rather than the result: the model reads the ruling
      // back, never the essay it just wrote.
      presentationMeta: (args, value): DebateVerdictMeta => ({
        kind: DEBATE_META_KIND,
        version: 1,
        debateId: args.debate_id,
        phase: 'verdict',
        judgement: args.judgement.trim(),
        winner: value.winner,
        rationale: args.rationale.trim(),
      }),
    },
    execute(args, exec) {
      const parent = exec.agent
      if (!parent) throw new Error('debate_verdict requires a calling agent')
      const record = claim(parent, args.debate_id)
      if (record.completed < record.rounds) {
        throw new Error(`debate "${record.id}" has argued ${String(record.completed)} of ${String(record.rounds)} rounds; run the rest with debate_round first`)
      }
      const judgement = args.judgement.trim()
      const rationale = args.rationale.trim()
      if (judgement.length === 0) throw new Error('the debate still needs your assessment')
      if (rationale.length === 0) throw new Error('the ruling needs its reasoning')
      record.closed = true
      return Promise.resolve({ topic: record.topic, rounds: record.rounds, winner: args.winner })
    },
    presentCall: args => ({
      card: 'generic',
      title: `Debate verdict: ${OUTCOME_LABEL[args.winner]}`,
      kind: 'other',
      rawInput: args.debate_id,
    }),
  }))
}
