/**
 * Durable presentation payloads for the debate orchestrator. The producer owns
 * them, so the browser half imports these types and merges its own view data on
 * top.
 *
 * Each of the three tools projects one of these through its
 * `output.presentationMeta`, which the tools plane persists verbatim as the
 * `meta` of the `tool/result` event that call already writes. That is the whole
 * durable record of a debate: the orchestrator declares no session event type
 * of its own, so a session that held a debate reloads on a stock harness (an
 * event type outside the harness's generated `KNOWN_SESSION_EVENT_TYPES` would
 * make persistence refuse the log). The judging agent reads every speech
 * through the same tool result, so nothing here reaches model history twice.
 *
 * A projection is pure over one call's arguments and its validated output
 * value, because the tools plane replays it: it can name no live debate the
 * orchestrator is holding in memory.
 *
 * All three carry the same three opening fields — `kind` and `version` identify
 * the projection to a reader folding a stored log, and `debateId` names the
 * debate the call belongs to. Each type spells them out rather than
 * intersecting a shared one in: a projection is assigned to the tools plane's
 * `JsonValue`, and TypeScript grants the implicit index signature that requires
 * only to a plain object type, never to an intersection.
 *
 * @module debate/types
 */

import type { Branded } from '@deepseek-ai/dsh-brand'

/** Identifies one debate across its three tool calls, inside this process. */
export type DebateId = Branded<'DebateId'>

/** Which side of the motion a speech argues. */
export type DebateSide = 'pro' | 'con'

/** Who the judging agent ruled for, `draw` when neither side prevailed. */
export type DebateOutcome = DebateSide | 'draw'

/**
 * Discriminator every projection carries, so a reader folding one debate can
 * tell this orchestrator's `tool/result` metadata from any other tool's.
 */
export const DEBATE_META_KIND = 'debate'

/** One debater's speech in one round, bounded by the orchestrator's limit. */
export type DebateSpeechMeta = {
  /** The debater's text, bounded by the orchestrator's configured limit. */
  readonly text: string
  /** Whether the limit dropped trailing text, so the view can say so. */
  readonly truncated: boolean
}

/** A debate opened on one motion, fixing how many rounds each side gets. */
export type DebateOpenMeta = {
  readonly kind: typeof DEBATE_META_KIND
  readonly version: 1
  /** The debate this projection opens, as a plain post-JSON string. */
  readonly debateId: string
  readonly phase: 'open'
  /** The motion, verbatim as the judging agent stated it. */
  readonly topic: string
  /** How many rounds each side speaks; fixed when the debate opens. */
  readonly rounds: number
}

/** One fully argued round: both speeches, in speaking order. */
export type DebateRoundMeta = {
  readonly kind: typeof DEBATE_META_KIND
  readonly version: 1
  readonly debateId: string
  readonly phase: 'round'
  /** One-based round these speeches belong to; never above `DebateOpenMeta.rounds`. */
  readonly round: number
  readonly pro: DebateSpeechMeta
  readonly con: DebateSpeechMeta
}

/**
 * The judging agent's assessment and final ruling, closing the debate. The
 * judge contributes nothing before this call: it reads every round in silence
 * and speaks once, after the last one.
 */
export type DebateVerdictMeta = {
  readonly kind: typeof DEBATE_META_KIND
  readonly version: 1
  readonly debateId: string
  readonly phase: 'verdict'
  /** The round-by-round assessment, verbatim as the judging agent wrote it. */
  readonly judgement: string
  /** Which side prevailed over the whole debate. */
  readonly winner: DebateOutcome
  /** Why that side prevailed, verbatim as the judging agent wrote it. */
  readonly rationale: string
}

/**
 * One debate's ordered record, as the three tool results carry it: `open`
 * states the motion and the agreed round count, `round` fills each round, and
 * `verdict` carries the judge's only assessment and closes it.
 */
export type DebateMeta = DebateOpenMeta | DebateRoundMeta | DebateVerdictMeta
