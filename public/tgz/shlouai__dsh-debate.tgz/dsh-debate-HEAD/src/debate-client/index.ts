/**
 * Host half of the debate feature's browser plugin. It contributes no host
 * behavior; the row exists so `dsh-client-modules` has a Loader entry to scan,
 * finds this directory's `package.json`, and serves the `dsh.client` bundle
 * named by `exports["./client"]` to the browser.
 *
 * The orchestrator that produces the `debate/*` events is the separate `debate`
 * row; both are inserted by
 * [`../debate/cordis.patch.yml`](../debate/cordis.patch.yml).
 *
 * @module debate-client
 */

/** Cordis plugin name. */
export const name = 'debate-client'

/** Host plugin body — no host-side behavior for this browser plugin. */
export function apply(): void {}
