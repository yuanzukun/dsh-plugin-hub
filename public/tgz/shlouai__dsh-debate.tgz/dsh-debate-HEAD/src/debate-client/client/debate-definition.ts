/**
 * Conversation Node folding one debate into a Chat card.
 *
 * The debate is read from the `meta` of the three `tool/result` events its
 * tools write, which is where their `output.presentationMeta` projections are
 * persisted. The orchestrator declares no session event type of its own — one
 * outside the harness's generated catalog would make persistence refuse the
 * whole log — so this card is assembled from an event type the harness itself
 * owns, on a live feed and a reloaded session alike.
 *
 * That metadata arrives as stored JSON rather than as a typed value, so every
 * field is validated here before it reaches the card.
 */

import type { SessionEventLike } from '@deepseek-ai/dsh-api-session-controller/client'
import type {
  ConversationNodeDefinition,
} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { ChatConversationViewNode } from '@deepseek-ai/dsh-client-ui-chat/client'
// The producer owns the payloads; importing them is what types the card below.
import type { DebateMeta, DebateOutcome, DebateSpeechMeta } from '../../debate/types.ts'
import { DEBATE_META_KIND } from '../../debate/types.ts'

/** One debater's speech as the card reads it. */
export interface DebateSpeechView {
  /** The speech text, already bounded by the orchestrator's limit. */
  readonly text: string
  /** Present when the orchestrator dropped trailing text. */
  readonly truncated?: true
}

/**
 * One round of the debate. Every field is optional because a parent window that
 * begins mid-debate may never receive some of them.
 */
export interface DebateRoundView {
  /** One-based round number, the card's stable ordering key. */
  readonly round: number
  /** The FOR speech, once argued. */
  readonly pro?: DebateSpeechView
  /** The AGAINST speech, once argued. */
  readonly con?: DebateSpeechView
}

/**
 * The judge's assessment and ruling, present only once the debate is closed.
 * The judge is silent while the rounds run, so nothing of it renders before.
 */
export interface DebateVerdictView {
  readonly judgement: string
  readonly winner: DebateOutcome
  readonly rationale: string
}

/** Final keyed Chat payload for one debate. */
export interface DebateChatData {
  /** The motion under debate. */
  readonly topic: string
  /** How many rounds the debate opened with, so the card can show progress. */
  readonly plannedRounds: number
  /** Rounds in ascending order; a round appears as soon as it has any content. */
  readonly rounds: readonly DebateRoundView[]
  /** Absent while the debate is still running. */
  readonly verdict?: DebateVerdictView
}

declare module '@deepseek-ai/dsh-client-ui-chat/client' {
  interface ChatNodeDataMap {
    /** One complete debate the calling agent opened, judged, and closed. */
    debate: DebateChatData
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function asOutcome(value: unknown): DebateOutcome | undefined {
  return value === 'pro' || value === 'con' || value === 'draw' ? value : undefined
}

function asSpeech(value: unknown): DebateSpeechMeta | undefined {
  if (!isRecord(value)) return undefined
  const { text, truncated } = value
  if (typeof text !== 'string' || typeof truncated !== 'boolean') return undefined
  return { text, truncated }
}

/**
 * Read one debate projection out of a stored `tool/result` payload.
 *
 * Every tool's result may carry `meta`, and this one comes from a log rather
 * than from the producer, so the discriminator, the version, and each field a
 * phase needs are all checked: an unrelated tool, a newer projection, or a
 * truncated record reads as no debate instead of a half-built card.
 * @param event - one history or live event offered to this Definition.
 * @returns the validated projection, or no value when this is not one.
 */
function debateMeta(event: SessionEventLike): DebateMeta | undefined {
  if (event.type !== 'tool/result') return undefined
  const value: unknown = event.data.meta
  if (!isRecord(value)) return undefined
  if (value.kind !== DEBATE_META_KIND || value.version !== 1) return undefined
  const debateId = value.debateId
  if (typeof debateId !== 'string' || debateId.length === 0) return undefined
  const base = { kind: DEBATE_META_KIND, version: 1, debateId } as const
  switch (value.phase) {
    case 'open': {
      const { topic, rounds } = value
      if (typeof topic !== 'string' || typeof rounds !== 'number' || !Number.isSafeInteger(rounds)) {
        return undefined
      }
      return { ...base, phase: 'open', topic, rounds }
    }
    case 'round': {
      const round = value.round
      const pro = asSpeech(value.pro)
      const con = asSpeech(value.con)
      if (typeof round !== 'number' || !Number.isSafeInteger(round)) return undefined
      if (pro === undefined || con === undefined) return undefined
      return { ...base, phase: 'round', round, pro, con }
    }
    case 'verdict': {
      const { judgement, rationale } = value
      const winner = asOutcome(value.winner)
      if (typeof judgement !== 'string' || typeof rationale !== 'string') return undefined
      if (winner === undefined) return undefined
      return { ...base, phase: 'verdict', judgement, winner, rationale }
    }
    default:
      return undefined
  }
}

/**
 * Replace one round's entry, appending it in ascending order when this is its
 * first event. Bounded by the debate's round count, not the event window.
 */
function withRound(
  rounds: readonly DebateRoundView[],
  round: number,
  patch: (current: DebateRoundView) => DebateRoundView,
): readonly DebateRoundView[] {
  const index = rounds.findIndex(entry => entry.round === round)
  if (index !== -1) return rounds.map((entry, at) => at === index ? patch(entry) : entry)
  return [...rounds, patch({ round })].sort((a, b) => a.round - b.round)
}

function speechView(speech: DebateSpeechMeta): DebateSpeechView {
  return {
    text: speech.text,
    ...speech.truncated ? { truncated: true as const } : {},
  }
}

/**
 * One Chat card per debate. The `open` projection is the single start, so a
 * parent window that begins mid-debate never starts a Context and renders
 * nothing, rather than opening a card whose motion and round count are missing.
 */
export const debateDefinition: ConversationNodeDefinition<DebateChatData> = {
  kind: 'debate',
  target: 'chat',
  match: (event) => {
    const meta = debateMeta(event)
    if (meta === undefined) return null
    return { id: meta.debateId, role: meta.phase === 'open' ? 'start' : 'update' }
  },
  start: (_context, match) => {
    const meta = debateMeta(match.event)
    if (meta?.phase !== 'open') throw new Error('debate start requires an open projection')
    return { topic: meta.topic, plannedRounds: meta.rounds, rounds: [] }
  },
  update: (context, match) => {
    const meta = debateMeta(match.event)
    if (meta?.phase === 'round') {
      return {
        ...context.state,
        rounds: withRound(context.state.rounds, meta.round, current => ({
          ...current,
          pro: speechView(meta.pro),
          con: speechView(meta.con),
        })),
      }
    }
    if (meta?.phase === 'verdict') {
      const { judgement, winner, rationale } = meta
      return { ...context.state, verdict: { judgement, winner, rationale } }
    }
    return context.state
  },
  buildViewNode: (context): ChatConversationViewNode | null => {
    if (context.start === undefined || context.state === undefined) return null
    return {
      key: context.key,
      kind: 'debate',
      id: context.id,
      target: 'chat',
      anchorSeq: context.start.event.seq,
      location: context.start.location,
      visibility: 'visible',
      data: context.state,
    }
  },
}
