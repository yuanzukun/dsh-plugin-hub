/** Browser plugin for debate Conversation Nodes. */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-chat/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import { DebateCard } from './DebateCard.tsx'
import { en, NS, type DebateKey, zh } from './locales.ts'
import { debateDefinition } from './debate-definition.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Debate card copy. */
    debate: DebateKey
  }
}

/** Required services for the Definition, keyed renderer, and copy. */
export const inject = ['uiConversation', 'slots', 'locale']

/** Register the debate Definition, dictionary, and keyed Chat renderer. */
export function apply(ctx: ClientContext): void {
  ctx.uiConversation.events.register(debateDefinition)
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'debate-client: dictionaries')
  ctx.slots.inject('conversation.chat.node', () => ctx.slots.register({
    name: 'conversation.chat.node',
    key: 'debate',
    locale: NS,
  }, DebateCard))
}
