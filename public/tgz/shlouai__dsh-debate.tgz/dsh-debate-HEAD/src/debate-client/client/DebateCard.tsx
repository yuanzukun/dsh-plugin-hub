import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
// Declares the `conversation.chat.node` member of `SlotMap` that the props below key into.
import type {} from '@deepseek-ai/dsh-client-ui-chat/client'
import type { DebateOutcome } from '../../debate/types.ts'
import type { DebateRoundView, DebateSpeechView } from './debate-definition.ts'
import type { DebateKey } from './locales.ts'
import css from './DebateCard.module.css'

/** Complete keyed Chat renderer props. */
export type DebateCardProps =
  PropsRuntime<'conversation.chat.node', 'debate'>
  & PropsLocale<'debate'>

/** Copy key naming each possible ruling. */
const WINNER_KEY: Record<DebateOutcome, DebateKey> = {
  pro: 'verdict.winner.pro',
  con: 'verdict.winner.con',
  draw: 'verdict.winner.draw',
}

/**
 * Print one debate in the judging agent's transcript: the motion, every round
 * as a pair of speeches, and — once the debate closes — the judge's assessment
 * of it and the ruling. Reads only `node.data`, which the Definition already
 * folded.
 * @param props - keyed Chat renderer props.
 * @returns the card element.
 */
export function DebateCard({ node, t }: DebateCardProps) {
  const { topic, plannedRounds, rounds, verdict } = node.data
  return (
    <section className={css.root} data-debate={node.id}>
      <header className={css.header}>
        <span className={css.title}>{t('card.title')}</span>
        <span className={css.progress}>
          {t('card.progress', { done: rounds.length, total: plannedRounds })}
        </span>
        {verdict === undefined ? <span className={css.running}>{t('card.running')}</span> : null}
      </header>
      <p className={css.topic}>{topic}</p>
      {rounds.map(round => (
        <DebateRound key={round.round} round={round} t={t} />
      ))}
      {verdict === undefined ? null : (
        <div className={css.verdict}>
          <div className={css.judgement}>
            <span className={css.speaker}>{t('judge.label')}</span>
            <p className={css.body}>{verdict.judgement}</p>
          </div>
          <div className={css.verdictHead}>
            <span className={css.verdictLabel}>{t('verdict.label')}</span>
            <span className={css.winner} data-winner={verdict.winner}>{t(WINNER_KEY[verdict.winner])}</span>
          </div>
          <p className={css.body}>{verdict.rationale}</p>
        </div>
      )}
    </section>
  )
}

/** One round: the two speeches, with nothing from the judge between them. */
function DebateRound({ round, t }: { round: DebateRoundView } & PropsLocale<'debate'>) {
  return (
    <div className={css.round}>
      <div className={css.roundLabel}>{t('round.label', { round: round.round })}</div>
      <Speech side="pro" speech={round.pro} t={t} />
      <Speech side="con" speech={round.con} t={t} />
    </div>
  )
}

/** One side's speech, or a placeholder while that side has not spoken yet. */
function Speech({ side, speech, t }: {
  side: 'pro' | 'con'
  speech: DebateSpeechView | undefined
} & PropsLocale<'debate'>) {
  return (
    <div className={css.speech} data-side={side}>
      <span className={css.speaker}>{t(side === 'pro' ? 'side.pro' : 'side.con')}</span>
      {speech === undefined
        ? <p className={css.pending}>{t('side.pending')}</p>
        : (
            <>
              <p className={css.body}>{speech.text}</p>
              {speech.truncated ? <p className={css.truncated}>{t('speech.truncated')}</p> : null}
            </>
          )}
    </div>
  )
}
