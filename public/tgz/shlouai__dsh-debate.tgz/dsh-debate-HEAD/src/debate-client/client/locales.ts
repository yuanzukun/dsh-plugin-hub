/** `debate` namespace dictionaries. */

/** Dictionary namespace owned by this plugin. */
export const NS = 'debate'

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'card.title': '辩论',
  'card.progress': '第 {done}/{total} 轮',
  'card.running': '进行中',
  'round.label': '第 {round} 轮',
  'side.pro': '正方',
  'side.con': '反方',
  'side.pending': '等待发言…',
  'speech.truncated': '发言过长，已截断',
  'judge.label': '裁判点评',
  'verdict.label': '最终评定',
  'verdict.winner.pro': '正方胜',
  'verdict.winner.con': '反方胜',
  'verdict.winner.draw': '平局',
}

/** English dictionary (same key set). */
export const en: Record<DebateKey, string> = {
  'card.title': 'Debate',
  'card.progress': 'Round {done} of {total}',
  'card.running': 'In progress',
  'round.label': 'Round {round}',
  'side.pro': 'For',
  'side.con': 'Against',
  'side.pending': 'Waiting to speak…',
  'speech.truncated': 'Truncated',
  'judge.label': 'Judge\'s assessment',
  'verdict.label': 'Verdict',
  'verdict.winner.pro': 'For wins',
  'verdict.winner.con': 'Against wins',
  'verdict.winner.draw': 'Draw',
}

/** Union of this namespace's dictionary keys. */
export type DebateKey = keyof typeof zh
