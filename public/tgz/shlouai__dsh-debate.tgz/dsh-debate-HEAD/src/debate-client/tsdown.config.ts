/**
 * Standalone browser-bundle build for this out-of-tree overlay package.
 *
 * `packages/client/tsdown.client.ts` is the in-tree preset for the same
 * artifact, but it resolves a package's externals by globbing
 * `packages/*​/*​/package.json` and throws on a name it does not find there, so
 * an overlay outside the workspace cannot call it. This config reproduces the
 * parts of that artifact the runtime depends on:
 *
 * - a CJS closure factory that hands itself to `window.__ModuleLoader__`, whose
 *   `id` must equal the `package.json` name the client-module scan reads;
 * - `lib/client.js` exactly, because `exports["./client"]` names that path;
 * - the shell-seeded platform modules left external and everything else
 *   inlined, since a `require` the module table cannot answer throws at boot.
 *
 * Unlike the preset this compiles `client/` sources directly rather than a tsc
 * `lib/types` emit, so `tsc --noEmit` and the bundle are independent passes.
 */
import { readFile } from 'node:fs/promises'
import { basename, dirname, resolve } from 'node:path'
import { transform } from 'lightningcss'
import { defineConfig } from 'tsdown'
import { PLATFORM_MODULES, PRELOADED_CLIENT_EXTERNALS } from '../../packages/client/web/src/platform.ts'

/** Browser module id; must match `package.json` `name`. */
const ID = '@shlouai/dsh-debate-client'

/** Specifiers the loader module table answers; everything else must inline. */
const EXTERNAL = new Set<string>([...PLATFORM_MODULES, ...PRELOADED_CLIENT_EXTERNALS])

/**
 * Virtual-id wrapper keeping module CSS away from tsdown's own css pipeline
 * (which requires @tsdown/css). The suffix matters: tsdown's guard matches ids
 * ending in `.css`, so the virtual id must not.
 */
const CSS_VIRTUAL_PREFIX = '\0dsh-css:'
const CSS_VIRTUAL_SUFFIX = '.mjs'

export default defineConfig({
  name: `${ID}/client`,
  entry: { client: 'client/index.ts' },
  outDir: 'lib',
  format: 'cjs',
  platform: 'browser',
  target: 'es2024',
  dts: false,
  clean: false,
  sourcemap: true,
  deps: {
    neverBundle: (specifier: string) => EXTERNAL.has(specifier),
    alwaysBundle: (specifier: string) => !EXTERNAL.has(specifier),
  },
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
  },
  plugins: [{
    name: 'dsh-css-modules-inline',
    resolveId(source: string, importer: string | undefined) {
      if (!source.endsWith('.module.css')) return null
      const file = importer === undefined ? source : resolve(dirname(importer), source)
      return CSS_VIRTUAL_PREFIX + file + CSS_VIRTUAL_SUFFIX
    },
    async load(this: { addWatchFile(id: string): void }, virtualId: string) {
      if (!virtualId.startsWith(CSS_VIRTUAL_PREFIX)) return null
      const file = virtualId.slice(CSS_VIRTUAL_PREFIX.length, -CSS_VIRTUAL_SUFFIX.length)
      // The virtual id otherwise hides the physical stylesheet from Rolldown's watch graph.
      this.addWatchFile(file)
      const { code, exports } = transform({
        filename: file,
        code: await readFile(file),
        cssModules: { pattern: '[hash]_[local]' },
        minify: true,
      })
      const classMap: Record<string, string> = {}
      for (const [local, exported] of Object.entries(exports ?? {}).sort()) {
        classMap[local] = exported.name
      }
      return [
        `const css = ${JSON.stringify(code.toString())};`,
        `const tagId = ${JSON.stringify(`${ID}/${basename(file)}`)};`,
        'if (document.querySelector(\'style[data-plugin-css=\' + JSON.stringify(tagId) + \']\') === null) {',
        '  const tag = document.createElement(\'style\');',
        `  tag.dataset.plugin = ${JSON.stringify(ID)};`,
        '  tag.dataset.pluginCss = tagId;',
        '  tag.textContent = css;',
        '  document.head.appendChild(tag);',
        '}',
        `export default ${JSON.stringify(classMap)};`,
      ].join('\n')
    },
  }],
  outputOptions: {
    entryFileNames: 'client.js',
    sourcemapExcludeSources: false,
    banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(ID)}, factory: (require) => {`,
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
  },
})
