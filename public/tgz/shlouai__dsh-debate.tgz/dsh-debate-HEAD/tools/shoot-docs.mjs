/**
 * Re-shoot the README's card screenshots and hero GIF from a real debate.
 *
 *   pnpm run shoot:docs
 *   pnpm run shoot:docs -- --session 'Debate: Are Long'
 *   DSH_URL='http://127.0.0.1:3080/?token=…' pnpm run shoot:docs
 *
 * Every asset under `docs/` is a capture of the live Web UI, so a change to
 * `DebateCard.module.css` invalidates all of them at once. This drives that
 * capture end to end: it starts the profile, opens a recorded debate, and
 * writes the five files the two READMEs reference.
 *
 * Two things about the capture are not obvious.
 *
 * **The card is cloned, not scrolled.** The conversation pins itself to the
 * bottom and ignores wheel, `scrollTop` and `scrollIntoView` alike, and the
 * list is virtualized, so neither an element screenshot nor a scripted scroll
 * of the real node holds still. Both the stills and the GIF instead clone the
 * rendered card into a fixed layer on the same page — same stylesheets, same
 * theme, same content — and move that.
 *
 * **The GIF is a still sequence, not a recording.** A recording of the same
 * tour has to encode ~2200px of travel, which at any GIF-sized frame rate puts
 * several lines of body text between neighbouring frames and reads as a
 * strobe. This walks the distance in discrete pages and screenshots each one,
 * so every hold is pixel-identical and the encoder has nothing to shimmer.
 * The holds also cost almost nothing: identical frames delta-compress away,
 * which is why the result is both larger on screen and smaller on disk than a
 * recording of the same length.
 *
 * @module tools/shoot-docs
 */

import { execFileSync, spawn } from 'node:child_process'
import { mkdirSync, mkdtempSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { REPO_ROOT, resolveDshLauncher } from './harness.mjs'

/** Profile that renders the debate card; the browser half is inert elsewhere. */
const DEFAULT_PROFILE = 'web'

/** Session title to open. The debate tool names a session after the motion it was asked to stage. */
const DEFAULT_SESSION = '^Debate'

/** Where the READMEs expect the assets. */
const OUT_DIR = join(REPO_ROOT, 'docs')

/** Window the GIF is framed in. The stills use their own, taller, viewport. */
const TOUR_VIEWPORT = { width: 1280, height: 820 }

/** Viewport for the stills: tall enough that the whole card lays out in one pass. */
const STILL_VIEWPORT = { width: 1500, height: 4200 }

/** Rendered width of the cloned card. */
const CARD_WIDTH = 900

/** Seconds a page of the tour is held still. */
const HOLD_SECONDS = 2

/** Frames a transition spends between two holds, and how long each lasts. */
const TWEENS = 2
const TWEEN_SECONDS = 0.16

/** Most pages the tour walks, however tall the card is. */
const MAX_PAGES = 6

/** Rows of text carried over from the previous page, so a jump stays legible. */
const PAGE_OVERLAP = 90

/** Palette size for the GIF and for the fallback still quantizer. */
const GIF_COLORS = 128
const PNG_COLORS = 200

/** Locales to shoot the stills in, and the suffix each one's files carry. */
const LOCALES = [
  { locale: 'en-US', suffix: 'en' },
  { locale: 'zh-CN', suffix: 'zh' },
]

/**
 * Read the arguments this script accepts.
 * @param argv - arguments after the script name.
 * @returns the target profile and the session-title pattern to open.
 * @throws on an unknown flag or a flag missing its value.
 */
function parseArgs(argv) {
  let profile = DEFAULT_PROFILE
  let session = DEFAULT_SESSION
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index]
    const value = () => {
      index += 1
      if (index >= argv.length) throw new Error(`${argument} needs a value`)
      return argv[index]
    }
    // pnpm 11 forwards the separator instead of consuming it.
    if (argument === '--') continue
    else if (argument === '--profile') profile = value()
    else if (argument === '--session') session = value()
    else throw new Error(`unknown argument ${JSON.stringify(argument)} — expected --profile <name> or --session <pattern>`)
  }
  return { profile, session }
}

/**
 * Assert an external binary is callable.
 * @param binary - the executable to probe.
 * @param flag - the flag it answers a version to; ffmpeg rejects the long form.
 * @returns whether it answered.
 */
function hasBinary(binary, flag = '--version') {
  try {
    execFileSync(binary, [flag], { stdio: 'ignore' })
    return true
  } catch {
    return false
  }
}

/** Run one command quietly, failing on a non-zero exit. */
function run(command, args) {
  execFileSync(command, args, { stdio: ['ignore', 'ignore', 'pipe'] })
}

/**
 * Load `playwright-core`, which drives the system Chrome through
 * `channel: 'chrome'` and so installs no browsers of its own.
 * @returns the `chromium` launcher.
 * @throws when the optional dependency is absent.
 */
async function loadChromium() {
  try {
    const { chromium } = await import('playwright-core')
    return chromium
  } catch {
    throw new Error('playwright-core is not installed — run `pnpm install` in this repository')
  }
}

/**
 * Start the profile and read the URL it serves.
 *
 * `--no-open` keeps the launcher from opening a real browser window over the
 * headless one this script drives.
 * @param profile - the profile to start.
 * @returns the served URL and a function that stops the launcher.
 * @throws when no URL is printed before the timeout.
 */
async function startProfile(profile) {
  const { command, args } = resolveDshLauncher()
  process.stdout.write(`> ${command} … --profile ${profile} --no-open\n`)
  // Its own process group: the launcher runs behind `pnpm exec`, so signalling
  // the child we spawned would leave the Node process serving the profile.
  const child = spawn(command, [...args, '--profile', profile, '--no-open'], {
    cwd: REPO_ROOT,
    detached: true,
    stdio: ['ignore', 'pipe', 'pipe'],
  })
  const stop = () => {
    try {
      process.kill(-child.pid, 'SIGTERM')
    } catch {
      // Already gone, which is the outcome this wanted.
    }
  }

  try {
    const url = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(`${profile} printed no URL within 90s:\n${log}`)), 90_000)
      let log = ''
      const scan = (chunk) => {
        log += chunk
        const match = /(http:\/\/\S+?\?token=[\w-]+)/.exec(log)
        if (match === null) return
        clearTimeout(timer)
        resolve(match[1])
      }
      child.stdout.setEncoding('utf8').on('data', scan)
      child.stderr.setEncoding('utf8').on('data', scan)
      child.on('exit', code => reject(new Error(`${profile} exited with ${code} before serving:\n${log}`)))
    })
    return { url, stop }
  } catch (error) {
    stop()
    throw error
  }
}

/**
 * Open the recorded debate and clone its card into a fixed layer.
 *
 * The clone is taken before the live flow is hidden, and the layer is placed
 * below the Chat/Trajectory tabs: the flow is taller than the layer, so its own
 * text would otherwise show above the top edge and collide with the clone.
 * @param page - a page already pointed at the profile.
 * @param session - a pattern matching the session title in the sidebar.
 * @param bounded - whether to clip the layer to the conversation area (the GIF) or fill the window (the stills).
 * @returns the cloned card's height and the layer's visible height.
 * @throws when no session matches, or the one that does carries no debate card.
 */
async function openCard(page, session, bounded) {
  const title = page.getByText(new RegExp(session)).first()
  if (await title.count() === 0) {
    const seen = await page.evaluate(() => [...document.querySelectorAll('a, button')]
      .map(el => (el.textContent ?? '').trim()).filter(text => text.length > 3).slice(0, 30))
    throw new Error(`no session title matched /${session}/ — the page offers:\n  ${seen.join('\n  ')}`)
  }
  await title.click()
  await page.waitForTimeout(4000)

  const collapse = page.locator('button[aria-label="Collapse sidebar"]')
  if (await collapse.count() > 0) {
    await collapse.first().click()
    await page.waitForTimeout(800)
  }
  await page.waitForTimeout(1500)

  const geometry = await page.evaluate(({ width, clip }) => {
    const card = document.querySelector('section[data-debate]')
    if (card === null) return null
    const background = getComputedStyle(document.body).backgroundColor

    document.getElementById('shot-layer')?.remove()
    const layer = document.createElement('div')
    layer.id = 'shot-layer'
    layer.style.cssText = [
      'position:fixed',
      ...(clip ? ['top:76px', 'left:46px', 'right:0', 'bottom:92px'] : ['inset:0']),
      `background:${background}`, 'z-index:2147483000', 'overflow:hidden',
    ].join(';')

    const frame = document.createElement('div')
    frame.id = 'shot-frame'
    frame.style.cssText = `position:absolute;top:14px;left:50%;width:${width}px;margin-left:${-width / 2}px`
    frame.appendChild(card.cloneNode(true))
    layer.appendChild(frame)
    document.body.appendChild(layer)

    for (const flow of document.querySelectorAll('[data-chat-flow]')) {
      flow.style.visibility = 'hidden'
    }

    const rect = frame.getBoundingClientRect()
    const blocks = [...frame.firstElementChild.children].map(el => {
      const box = el.getBoundingClientRect()
      return { classes: String(el.className || ''), top: box.y, bottom: box.y + box.height }
    })
    return {
      cardHeight: Math.round(rect.height),
      viewHeight: layer.clientHeight,
      left: rect.x,
      width: rect.width,
      top: rect.y,
      blocks,
    }
  }, { width: CARD_WIDTH, clip: bounded })

  if (geometry === null) throw new Error(`the session matching /${session}/ carries no debate card`)
  return geometry
}

/**
 * Screenshot the card as a page-by-page still sequence.
 * @param page - a page with the card already cloned into a clipped layer.
 * @param geometry - what {@link openCard} measured.
 * @param dir - scratch directory for the stills.
 * @returns the path of an ffmpeg `concat` script naming each still and its on-screen duration.
 */
async function shootTour(page, geometry, dir) {
  const travel = Math.max(0, geometry.cardHeight - geometry.viewHeight + 28)
  const pages = Math.min(MAX_PAGES, Math.max(2, Math.ceil(travel / (geometry.viewHeight - PAGE_OVERLAP)) + 1))
  const step = travel / (pages - 1)
  process.stdout.write(`  card ${geometry.cardHeight}px, ${pages} pages of ${Math.round(step)}px\n`)

  const timeline = []
  const shoot = async (offset, seconds) => {
    const file = join(dir, `${String(timeline.length).padStart(3, '0')}.png`)
    await page.evaluate((y) => {
      const frame = document.getElementById('shot-frame')
      if (frame !== null) frame.style.transform = `translateY(${-y}px)`
    }, offset)
    // One paint before the shutter, or the transform lands mid-capture.
    await page.waitForTimeout(90)
    await page.screenshot({ path: file })
    timeline.push({ file, seconds })
  }

  for (let index = 0; index < pages; index += 1) {
    if (index > 0) {
      for (let tween = 1; tween <= TWEENS; tween += 1) {
        // Eased, so a jump reads as a move rather than a cut.
        const ratio = tween / (TWEENS + 1)
        const eased = ratio < 0.5 ? 2 * ratio ** 2 : 1 - 2 * (1 - ratio) ** 2
        await shoot(step * (index - 1 + eased), TWEEN_SECONDS)
      }
    }
    // The ruling is the payoff, so the last page sits a beat longer.
    await shoot(step * index, index === pages - 1 ? HOLD_SECONDS + 0.8 : HOLD_SECONDS)
  }

  const script = join(dir, 'frames.txt')
  const entries = timeline.map(frame => `file '${frame.file}'\nduration ${frame.seconds}`).join('\n')
  // The concat demuxer drops the last entry's duration, so the final still is named twice.
  writeFileSync(script, `${entries}\nfile '${timeline.at(-1).file}'\n`)
  return script
}

/**
 * Encode the still sequence into the hero GIF.
 *
 * One palette is generated across every frame (`stats_mode=full`). A per-frame
 * palette re-quantizes the same text differently each time, which shimmers
 * even where nothing moved — the flicker that reads as shake alongside the
 * scroll itself.
 * @param script - the `concat` script from {@link shootTour}.
 * @param destination - where to write the GIF.
 */
function encodeGif(script, destination) {
  const filter = [
    `[0:v]scale=${CARD_WIDTH}:-1:flags=lanczos,split[a][b]`,
    `[a]palettegen=max_colors=${GIF_COLORS}:stats_mode=full[p]`,
    '[b][p]paletteuse=dither=none',
  ].join(';')
  run('ffmpeg', [
    '-v', 'error', '-f', 'concat', '-safe', '0', '-i', script,
    '-filter_complex', filter, '-fps_mode', 'vfr', '-loop', '0', '-y', destination,
  ])
  // Lossless regrouping of the frames; worth ~7%, and skipped rather than required.
  if (hasBinary('gifsicle')) run('gifsicle', ['-O3', destination, '-o', destination])
}

/**
 * Screenshot one region of the card at full resolution.
 * @param page - a page with the card cloned into a full-window layer.
 * @param geometry - what {@link openCard} measured.
 * @param bounds - the top and bottom of the region to clip.
 * @param destination - where to write the still.
 */
async function shootStill(page, geometry, bounds, destination) {
  const pad = 24
  await page.screenshot({
    path: destination,
    clip: {
      x: Math.max(0, geometry.left - pad),
      y: Math.max(0, bounds.top - pad),
      width: geometry.width + pad * 2,
      height: Math.min(bounds.bottom - bounds.top + pad * 2, STILL_VIEWPORT.height - bounds.top + pad),
    },
  })
}

/**
 * Shrink a still to a palette.
 *
 * pngquant is a little under half the size ffmpeg's own quantizer reaches, so
 * it is used when present and ffmpeg answers for it when not. Either way the
 * only hard requirement stays ffmpeg.
 * @param file - the still to quantize in place.
 */
function quantize(file) {
  if (hasBinary('pngquant')) {
    run('pngquant', ['--quality', '60-88', '--speed', '1', '--force', '--output', file, file])
    return
  }
  const filter = `split[a][b];[a]palettegen=max_colors=${PNG_COLORS}:stats_mode=full[p];[b][p]paletteuse=dither=none`
  const scratch = `${file}.tmp.png`
  run('ffmpeg', ['-v', 'error', '-i', file, '-vf', filter, '-y', scratch])
  renameSync(scratch, file)
}

const { profile, session } = parseArgs(process.argv.slice(2))

if (!hasBinary('ffmpeg', '-version')) {
  throw new Error('ffmpeg is not on PATH — install it (`brew install ffmpeg`) and run this again')
}

const chromium = await loadChromium()
// A profile already serving lets a re-shoot skip the 30s startup.
const reuse = process.env.DSH_URL
const started = reuse === undefined || reuse === '' ? await startProfile(profile) : { url: reuse, stop: () => {} }
const scratch = mkdtempSync(join(tmpdir(), 'dsh-debate-docs-'))
mkdirSync(OUT_DIR, { recursive: true })

const browser = await chromium.launch({ channel: 'chrome', headless: true })
try {
  process.stdout.write(`shooting the hero GIF\n`)
  const tourContext = await browser.newContext({
    viewport: TOUR_VIEWPORT,
    deviceScaleFactor: 2,
    locale: LOCALES[0].locale,
  })
  const tourPage = await tourContext.newPage()
  await tourPage.goto(started.url, { waitUntil: 'networkidle' })
  await tourPage.waitForTimeout(2500)
  const tourGeometry = await openCard(tourPage, session, true)
  const script = await shootTour(tourPage, tourGeometry, scratch)
  encodeGif(script, join(OUT_DIR, 'demo.gif'))
  await tourContext.close()

  for (const { locale, suffix } of LOCALES) {
    process.stdout.write(`shooting the ${suffix} stills\n`)
    const context = await browser.newContext({ viewport: STILL_VIEWPORT, deviceScaleFactor: 2, locale })
    const page = await context.newPage()
    await page.goto(started.url, { waitUntil: 'networkidle' })
    await page.waitForTimeout(3000)
    const geometry = await openCard(page, session, false)

    // The motion through the first round: the card as it looks mid-debate.
    const round = geometry.blocks.find(block => /round/i.test(block.classes))
    if (round === undefined) throw new Error('the card has no round block to clip')
    await shootStill(page, geometry, { top: geometry.top, bottom: round.bottom }, join(OUT_DIR, `card-round-${suffix}.png`))

    // The ruling on its own, which is always the last block.
    const verdict = geometry.blocks.at(-1)
    await shootStill(page, geometry, verdict, join(OUT_DIR, `card-verdict-${suffix}.png`))
    await context.close()

    quantize(join(OUT_DIR, `card-round-${suffix}.png`))
    quantize(join(OUT_DIR, `card-verdict-${suffix}.png`))
  }
} finally {
  await browser.close()
  started.stop()
  rmSync(scratch, { recursive: true, force: true })
}

process.stdout.write(`\nwrote the READMEs' five assets to ${OUT_DIR}\n`)
