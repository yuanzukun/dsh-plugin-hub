/**
 * Install the built bundle into a dsh profile, in one command.
 *
 *   pnpm run install:profile             # into the `web` profile
 *   pnpm run install:profile -- --profile headless
 *   pnpm run install:profile -- --profile web --no-build
 *
 * The bundle is packed first and installed from the tarball rather than from
 * this directory. A directory install links the profile back to this checkout,
 * so Node would resolve `@deepseek-ai/dsh-tools` and `@deepseek-ai/schemastery`
 * by walking out of *this* repository, where they are absent by design. Packing
 * puts a real directory under the profile's `node_modules`, whose parent walk
 * reaches the launcher's dependency closure at `$DSH_HOME/profiles/node_modules`
 * and hands the plugin the running installation's own instances.
 *
 * `dsh plugin` forwards to pnpm inside the profile and then reconciles
 * `dsh.profile.bundles` against what is installed, so the `dsh.bundle.patch`
 * declaration in `package.json` is what activates the layer. Nothing in the
 * harness checkout or the installation is touched.
 *
 * An install of the same version is removed before it is added again, because
 * pnpm identifies this tarball by a path and a version that never change and
 * would otherwise keep the extraction it already has. See {@link dropExisting}.
 *
 * @module tools/install
 */

import { existsSync, mkdirSync, readFileSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { REPO_ROOT, execCommand, resolveDshLauncher } from './harness.mjs'

/** Profile that renders the debate card; the browser half is inert elsewhere. */
const DEFAULT_PROFILE = 'web'

/** Scratch directory holding the packed tarball between `pnpm pack` and `dsh plugin add`. */
const PACK_DIR = join(REPO_ROOT, '.pack')

/**
 * Read the launcher arguments this script accepts.
 * @param argv - arguments after the script name.
 * @returns the target profile and whether to build first.
 * @throws on an unknown flag or a `--profile` without a value.
 */
function parseArgs(argv) {
  let profile = DEFAULT_PROFILE
  let build = true
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index]
    if (argument === '--') {
      // pnpm 11 forwards the separator instead of consuming it, so the
      // documented `pnpm run install:profile -- --no-build` arrives with it.
      continue
    } else if (argument === '--no-build') {
      build = false
    } else if (argument === '--profile') {
      index += 1
      if (index >= argv.length) throw new Error('--profile needs a profile name')
      profile = argv[index]
    } else {
      throw new Error(`unknown argument ${JSON.stringify(argument)} — expected --profile <name> or --no-build`)
    }
  }
  return { profile, build }
}

/**
 * Render a command as one shell-pasteable line.
 * @param command - the executable.
 * @param args - its arguments; those holding whitespace are quoted.
 * @returns the joined line.
 */
function formatCommand(command, args) {
  const quoted = args.map(argument => (/\s/.test(argument) ? `'${argument.replaceAll("'", `'\\''`)}'` : argument))
  return [command, ...quoted].join(' ')
}

/** Run one command, streaming its output and failing on a non-zero exit. */
function run(command, args, cwd = REPO_ROOT) {
  process.stdout.write(`> ${formatCommand(command, args)}\n`)
  execCommand(command, args, { cwd, stdio: 'inherit' })
}

/**
 * Drop any existing install of this bundle from the profile, so the `add` that
 * follows resolves the tarball again.
 *
 * pnpm identifies a `file:` dependency by its path and its version, and neither
 * moves here: repacking `0.1.0` over the previous tarball leaves the spec
 * already satisfied, so `dsh plugin add` reports success while the profile goes
 * on serving the `lib/` it extracted the first time. Removing first is what
 * makes a rebuild reach a profile at all.
 *
 * A profile that does not carry the bundle yet fails this with pnpm's
 * missing-dependency code, having changed nothing — the expected first-install
 * path rather than an error worth reporting. Any other failure is the profile's
 * own and is raised with the output that explains it.
 * @param command - the resolved launcher.
 * @param args - the launcher's leading arguments.
 * @param spec - the package name to remove.
 * @param target - the profile to remove it from.
 */
function dropExisting(command, args, spec, target) {
  const argv = [...args, 'plugin', '--profile', target, 'remove', spec]
  process.stdout.write(`> ${formatCommand(command, argv)}\n`)
  try {
    execCommand(command, argv, { cwd: REPO_ROOT, stdio: ['ignore', 'pipe', 'pipe'] })
    process.stdout.write(`removed the previous install, so the add below re-extracts the tarball\n`)
  } catch (error) {
    const output = `${error.stdout ?? ''}${error.stderr ?? ''}`
    if (!output.includes('ERR_PNPM_CANNOT_REMOVE_MISSING_DEPS')) {
      process.stderr.write(output)
      throw error
    }
    process.stdout.write(`${spec} was not installed in the ${target} profile yet\n`)
  }
}

/**
 * Pack this package into {@link PACK_DIR}.
 * @returns the absolute path of the tarball.
 */
function pack() {
  rmSync(PACK_DIR, { recursive: true, force: true })
  mkdirSync(PACK_DIR, { recursive: true })
  process.stdout.write(`> pnpm pack --pack-destination ${PACK_DIR}\n`)
  const stdout = execCommand('pnpm', ['pack', '--pack-destination', PACK_DIR], {
    cwd: REPO_ROOT,
    encoding: 'utf8',
  })
  const tarball = stdout.trim().split('\n').at(-1)?.trim()
  if (tarball === undefined || !existsSync(tarball)) {
    throw new Error(`pnpm pack did not report a tarball path (got ${JSON.stringify(stdout)})`)
  }
  return tarball
}

const { profile, build } = parseArgs(process.argv.slice(2))
const { name } = JSON.parse(readFileSync(join(REPO_ROOT, 'package.json'), 'utf8'))

if (build) run('node', [join(REPO_ROOT, 'tools', 'build.mjs')])
else if (!existsSync(join(REPO_ROOT, 'lib'))) throw new Error('--no-build was passed but lib/ does not exist')

const tarball = pack()
const { command, args } = resolveDshLauncher()
dropExisting(command, args, name, profile)
// Absolute, so `dsh plugin`'s relative-spec anchoring leaves it alone.
run(command, [...args, 'plugin', '--profile', profile, 'add', tarball])

process.stdout.write(`\ninstalled ${name} into the ${profile} profile\n`)
// The same launcher that just installed: naming `dsh` unconditionally would
// hand a `command not found` to anyone whose checkout supplied the fallback.
process.stdout.write(`start it with: ${formatCommand(command, [...args, '--profile', profile])}\n`)
