/**
 * Locating the DeepSeek Harness checkout this repository builds against, and
 * the `dsh` launcher used to install into a profile.
 *
 * The debate sources are carried verbatim from the harness checkout they were
 * written in, so their relative paths (`../../tsconfig.base.json`,
 * `../../packages/client/web/src/platform.ts`, `../../vendor/cordis`) still
 * point two levels up from `src/<pkg>/`. `tools/link-harness.mjs` satisfies
 * them by making this repository root a shadow of the harness root; every
 * consumer of that arrangement resolves the checkout through here.
 *
 * @module tools/harness
 */

import { execFileSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

/** Absolute root of this repository. */
export const REPO_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')

/** Files that together identify a directory as a harness checkout rather than any other tree. */
const HARNESS_MARKERS = [
  'tsconfig.base.json',
  'tsconfig.base.client.json',
  join('packages', 'client', 'web', 'src', 'platform.ts'),
  join('apps', 'cli', 'src', 'bin.ts'),
]

/** Checkout locations tried in order when `DSH_HARNESS` is unset. */
const HARNESS_FALLBACKS = [
  resolve(REPO_ROOT, '..', 'deepseek-harness'),
  resolve(REPO_ROOT, '..', '..', 'deepseek-harness'),
]

/** Return whether `dir` holds every marker of a harness checkout. */
function isHarness(dir) {
  return HARNESS_MARKERS.every(marker => existsSync(join(dir, marker)))
}

/**
 * Resolve the harness checkout to build against.
 * @returns the absolute checkout root.
 * @throws when `DSH_HARNESS` names a directory that is not a checkout, or when no fallback is one.
 */
export function resolveHarnessRoot() {
  const declared = process.env.DSH_HARNESS
  if (declared !== undefined && declared !== '') {
    const dir = resolve(declared)
    if (!isHarness(dir)) {
      throw new Error(`DSH_HARNESS=${dir} is not a deepseek-harness checkout (missing ${HARNESS_MARKERS.join(', ')})`)
    }
    return dir
  }
  for (const candidate of HARNESS_FALLBACKS) {
    if (isHarness(candidate)) return candidate
  }
  throw new Error(
    'cannot find a deepseek-harness checkout — set DSH_HARNESS to its root, '
    + `or place one at ${HARNESS_FALLBACKS.join(' or ')}`,
  )
}

/**
 * Run a command that may be an npm-installed CLI, resolving Windows shims.
 *
 * npm puts its CLIs on PATH as `.cmd` shims, which `execFileSync` cannot start
 * directly (CreateProcess runs only native executables), so a bare command that
 * is not found as-is is retried through `cmd.exe`, whose own PATHEXT search
 * finds the shim. Native executables, paths, explicit extensions and every
 * non-Windows host run unchanged.
 *
 * @param command - the executable to run.
 * @param args - its arguments.
 * @param options - options passed through to `execFileSync`.
 * @returns `execFileSync`'s result.
 */
export function execCommand(command, args, options) {
  if (process.platform !== 'win32') return execFileSync(command, args, options)
  try {
    return execFileSync(command, args, options)
  } catch (error) {
    if (error.code !== 'ENOENT') throw error
    return execFileSync(process.env.ComSpec ?? 'cmd.exe', ['/d', '/s', '/c', command, ...args], options)
  }
}

/**
 * Resolve how to run the `dsh` launcher: an installed CLI on PATH, otherwise
 * the harness checkout's own source launch — the same one `pnpm dsh` runs, so
 * a checkout needs nothing built to install a bundle. `DSH_BIN` names a
 * launcher explicitly.
 * @returns the command and its leading arguments, ready to receive `dsh` arguments.
 */
export function resolveDshLauncher() {
  const declared = process.env.DSH_BIN
  if (declared !== undefined && declared !== '') return { command: declared, args: [] }
  try {
    execCommand('dsh', ['--version'], { stdio: 'ignore' })
    return { command: 'dsh', args: [] }
  } catch {
    // `dsh --version` answers before the CLI parses anything else, so the only
    // way here is that no `dsh` is on PATH.
    const args = ['--dir', resolveHarnessRoot(), 'exec', 'node', '--import', 'tsx/esm', 'apps/cli/src/bin.ts']
    return { command: 'pnpm', args }
  }
}
