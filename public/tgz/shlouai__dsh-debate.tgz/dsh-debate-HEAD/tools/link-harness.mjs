/**
 * Make this repository root a shadow of the DeepSeek Harness root, so the
 * verbatim debate sources under `src/` compile where they stand.
 *
 * `src/debate` and `src/debate-client` sit two levels below this root exactly
 * as `tmp/debate` and `tmp/debate-client` sat below the harness root, so their
 * unmodified `../../…` references resolve once these links exist:
 *
 * - `tsconfig.base.json`, `tsconfig.base.client.json` — the configs both
 *   `tsconfig.json` files extend, whose `paths` and `typeRoots` are relative to
 *   the root holding them;
 * - `packages`, `vendor` — the targets of those `paths`, of every leaf
 *   `references` entry, and of `src/debate-client/tsdown.config.ts`'s import of
 *   `packages/client/web/src/platform.ts`;
 * - `scripts` — the first `typeRoots` entry of the client base config.
 *
 * React resolves through `src/debate-client/node_modules` because no package
 * manager installs that directory; the targets track whatever the harness
 * workspace resolved for an in-tree client package, as
 * `src/debate-client/tsconfig.json` documents.
 *
 * Every link is rewritten on each run and removed by `tools/clean.mjs`, so a
 * moved or rebuilt checkout is picked up by re-running `pnpm run setup`.
 *
 * @module tools/link-harness
 */

import { copyFileSync, existsSync, linkSync, lstatSync, mkdirSync, realpathSync, rmSync, statSync, symlinkSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { REPO_ROOT, resolveHarnessRoot } from './harness.mjs'

/** Harness-root entries the verbatim sources reach through `../../`. */
export const SHADOW_ENTRIES = [
  'packages',
  'vendor',
  'scripts',
  'tsconfig.base.json',
  'tsconfig.base.client.json',
]

/** Where the browser half finds React, and the in-tree client package whose resolution it copies. */
const REACT_LINKS = [
  { link: join('src', 'debate-client', 'node_modules', 'react'), from: 'react' },
  { link: join('src', 'debate-client', 'node_modules', '@types', 'react'), from: '@types/react' },
]

/** The harness package whose installed React the browser half borrows. */
const REACT_DONOR = join('packages', 'client', 'ui-chat', 'node_modules')

/** Windows shells without elevation cannot create real symlinks; use link kinds that need no rights. */
const IS_WINDOWS = process.platform === 'win32'

/**
 * Replace one link with a fresh link to `target`.
 *
 * On Windows an ordinary account cannot make real symlinks (they require
 * Developer Mode or elevation), so the kind is chosen to stay within what an
 * unprivileged shell allows: directories become junctions and files become
 * hard links, both of which need no special rights on one NTFS volume. Other
 * platforms keep plain symlinks. Junctions read back as symbolic links, so the
 * re-run guard and `tools/clean.mjs` already handle them; hard links read back
 * as plain files and are accepted only for file targets on Windows.
 *
 * @param linkPath - absolute path of the link to write.
 * @param target - absolute path the link should resolve to.
 * @throws when a non-link already occupies `linkPath`.
 */
function relink(linkPath, target) {
  const targetIsDir = statSync(target).isDirectory()
  let existing
  try {
    existing = lstatSync(linkPath)
  } catch {
    existing = undefined // nothing at linkPath yet
  }
  if (existing !== undefined) {
    const isShadowLink = existing.isSymbolicLink() || (IS_WINDOWS && !targetIsDir && existing.isFile())
    if (!isShadowLink) {
      throw new Error(`${linkPath} exists and is not a link — remove it before running setup`)
    }
    rmSync(linkPath, { force: true })
  }
  mkdirSync(dirname(linkPath), { recursive: true })
  if (!IS_WINDOWS) {
    symlinkSync(target, linkPath)
  } else if (targetIsDir) {
    symlinkSync(target, linkPath, 'junction')
  } else {
    try {
      linkSync(target, linkPath)
    } catch (err) {
      // Hard links need both ends on one volume; fall back to a copy so a
      // checkout on another drive still links (rewritten each run anyway).
      if (err?.code !== 'EXDEV') throw err
      copyFileSync(target, linkPath)
    }
  }
}

/**
 * Create every link the verbatim sources depend on.
 * @param harnessRoot - the checkout to shadow; defaults to {@link resolveHarnessRoot}.
 * @returns the checkout that was linked.
 */
export function linkHarness(harnessRoot = resolveHarnessRoot()) {
  for (const entry of SHADOW_ENTRIES) {
    relink(join(REPO_ROOT, entry), join(harnessRoot, entry))
  }
  const donor = join(harnessRoot, REACT_DONOR)
  for (const { link, from } of REACT_LINKS) {
    const source = join(donor, from)
    if (!existsSync(source)) {
      throw new Error(
        `${source} is missing — run 'pnpm install' in ${harnessRoot} so its client packages resolve React`,
      )
    }
    // The donor entry is itself a pnpm symlink into the virtual store; copying
    // its target rather than the link keeps this link valid from another depth.
    relink(join(REPO_ROOT, link), realpathSync.native(source))
  }
  return harnessRoot
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const harnessRoot = linkHarness()
  process.stdout.write(`shadowing harness checkout ${harnessRoot}\n`)
  for (const entry of SHADOW_ENTRIES) process.stdout.write(`  ${entry} -> ${join(harnessRoot, entry)}\n`)
}
