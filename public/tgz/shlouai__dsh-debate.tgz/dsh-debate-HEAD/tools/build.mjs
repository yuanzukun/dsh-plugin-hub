/**
 * Build the installable bundle into `lib/`.
 *
 * The output mirrors the source layout rather than flattening it, because the
 * browser half is discovered by walking up from its host row to the nearest
 * `package.json`: `lib/debate-client/` reproduces `src/debate-client/` closely
 * enough that its manifest can be copied verbatim and its
 * `exports["./client"]` — `./lib/client.js` — still names the bundle sitting
 * beside it.
 *
 *   lib/debate/plugin.js         the orchestrator row (three debate tools)
 *   lib/debate-client/index.js   the empty host half of the browser row
 *   lib/debate-client/package.json   `dsh.client` + `exports["./client"]`
 *   lib/debate-client/lib/client.js  the browser bundle
 *
 * @module tools/build
 */

import { copyFileSync, existsSync, mkdirSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { REPO_ROOT, execCommand, resolveHarnessRoot } from './harness.mjs'
import { linkHarness } from './link-harness.mjs'

/** Source directory of the browser half, which owns its own tsdown config. */
const CLIENT_SRC = join(REPO_ROOT, 'src', 'debate-client')

/** Where the built bundle's browser half is assembled. */
const CLIENT_OUT = join(REPO_ROOT, 'lib', 'debate-client')

/** Files the browser half contributes, relative to its source and output directories. */
const CLIENT_ARTIFACTS = [
  join('lib', 'client.js'),
  join('lib', 'client.js.map'),
]

/** Run one command in `cwd`, streaming its output and failing the build on a non-zero exit. */
function run(command, args, cwd) {
  process.stdout.write(`> ${command} ${args.join(' ')}  (${cwd})\n`)
  execCommand(command, args, { cwd, stdio: 'inherit' })
}

const harnessRoot = linkHarness(resolveHarnessRoot())
process.stdout.write(`building against harness checkout ${harnessRoot}\n`)

// Host rows first: this pass owns `clean`, so the browser artifacts copied
// below must land after it.
run('pnpm', ['exec', 'tsdown'], REPO_ROOT)

rmSync(join(CLIENT_SRC, 'lib'), { recursive: true, force: true })
run('pnpm', ['exec', 'tsdown'], CLIENT_SRC)

mkdirSync(join(CLIENT_OUT, 'lib'), { recursive: true })
// Verbatim: the manifest's `dsh.client` declaration and its `./client` export
// are what `dsh-client-modules` reads, and the layout above keeps both true.
copyFileSync(join(CLIENT_SRC, 'package.json'), join(CLIENT_OUT, 'package.json'))
for (const artifact of CLIENT_ARTIFACTS) {
  const from = join(CLIENT_SRC, artifact)
  if (!existsSync(from)) throw new Error(`browser bundle did not emit ${artifact}`)
  copyFileSync(from, join(CLIENT_OUT, artifact))
}

process.stdout.write(`built ${join(REPO_ROOT, 'lib')}\n`)
