/**
 * Remove the build outputs and the harness shadow links. `pnpm run setup`
 * recreates the links, so cleaning is also how a repository is repointed at a
 * moved checkout.
 *
 * `.pack/` survives: a profile that installed this bundle records the tarball's
 * path as its dependency spec, and deleting it would leave that profile unable
 * to reinstall. `node_modules` survives too — it is a package-manager artifact,
 * not a build output.
 *
 * @module tools/clean
 */

import { lstatSync, rmSync, unlinkSync } from 'node:fs'
import { join } from 'node:path'
import { REPO_ROOT } from './harness.mjs'
import { SHADOW_ENTRIES } from './link-harness.mjs'

/** Generated paths, relative to the repository root. */
const GENERATED = [
  'lib',
  join('src', 'debate', 'tsconfig.tsbuildinfo'),
  join('src', 'debate-client', 'lib'),
  join('src', 'debate-client', 'tsconfig.tsbuildinfo'),
  join('src', 'debate-client', 'node_modules'),
  ...SHADOW_ENTRIES,
]

for (const entry of GENERATED) {
  const path = join(REPO_ROOT, entry)
  let stat
  try {
    stat = lstatSync(path)
  } catch {
    continue // already absent
  }
  // A recursive delete must never follow a shadow link into the harness checkout.
  if (stat.isSymbolicLink()) unlinkSync(path)
  else rmSync(path, { recursive: true, force: true })
  process.stdout.write(`removed ${entry}\n`)
}
