/**
 * 项目级持久记忆插件 (Project-level persistent memory) — v3（零外部依赖）.
 *
 * 让模型跨会话读写“当前项目”目录下的 `memory/` 记忆文件，记忆持久化、可审计，
 * 而不是落在模型内部上下文里。不新开项目：记忆落在“会话工作区”的 `memory/` 下。
 *
 * 文件布局（默认）：
 *   <workspace>/memory/MEMORY.md    — 索引文件，只存一行一条的索引
 *   <workspace>/memory/*.md         — 正文文件，每条记忆一个文件
 *   <workspace>/memory/reference.md — 收尾沉淀的 reference 类正文（固定文件，追加）
 *
 * 索引行格式（MEMORY.md 只存索引，不存长正文）：
 *   - [类别] 主题：一句话摘要 → 文件名.md
 *
 * 边界：本插件只读写 memory/ 下单段 `.md` 文件，不跟随、不读取跨目录引用
 * （如 `../docs/*.md`）；索引 upsert / 删除只增删/替换自己那一行，其余行逐字保留。
 *
 * v3 变化：改为**零外部依赖**。不再 `import { defineTool } from '@deepseek-ai/dsh-tools'`：
 * 该包在 user preset 目录下无法解析（preset 目录没有 node_modules，部署又是 pnpm/捆绑
 * 布局）。本文件内联一个最小的 `defineTool`（schema DSL → 标准 JSON Schema + 轻量参数
 * 校验），`Context`/`ToolExecution` 等类型也本地化。运行时只依赖 node:fs / node:path，
 * 因此可在任何 deployment / preset 里直接加载，也便于对外发布。
 *
 * 加载方式（user preset 的 agent.cordis.yml）：
 *   - id: project-memory
 *     name: './memory-plugin.ts'
 *     # config:
 *     #   memoryRoot: ./memory           # 显式覆盖（可绝对/相对，相对按会话工作区解析）
 *     #   toolPrefix: ''                 # 例如 'proj_' → proj_memory_load_context
 *     #   maxReferenceEntries: 200       # reference.md 最多保留条数
 */
import { promises as fs } from 'node:fs';
import { isAbsolute, join, resolve } from 'node:path';
/** 递归把一段（对象/数组/叶子）schema DSL 转成标准 JSON Schema。 */
function schemaSpecToJsonSchema(spec) {
    const out = {};
    for (const key of Object.keys(spec)) {
        if (key === 'properties' || key === 'items' || key === 'required')
            continue;
        out[key] = spec[key];
    }
    if (spec.properties !== undefined) {
        const props = {};
        const required = [];
        for (const name of Object.keys(spec.properties)) {
            const sub = spec.properties[name];
            props[name] = schemaSpecToJsonSchema(sub);
            if (sub.required === true)
                required.push(name);
        }
        out.properties = props;
        if (required.length > 0)
            out.required = required;
    }
    if (spec.items !== undefined)
        out.items = schemaSpecToJsonSchema(spec.items);
    return out;
}
/** parameters 是“属性名 → 属性 schema”的映射，包成开放 object 根（不加 additionalProperties:false）。 */
function paramsSpecToJsonSchema(spec) {
    const properties = {};
    const required = [];
    for (const name of Object.keys(spec)) {
        const sub = spec[name];
        properties[name] = schemaSpecToJsonSchema(sub);
        if (sub.required === true)
            required.push(name);
    }
    const out = { type: 'object', properties };
    if (required.length > 0)
        out.required = required;
    return out;
}
/** 轻量校验：只查 object 根的必填项是否缺失、以及已给参数的基础类型是否匹配。 */
function validateArgs(parameters, args) {
    const errors = [];
    if (parameters.type !== 'object')
        return errors;
    if (typeof args !== 'object' || args === null || Array.isArray(args)) {
        errors.push('expected an object of arguments');
        return errors;
    }
    const obj = args;
    const required = parameters.required ?? [];
    for (const key of required) {
        if (obj[key] === undefined)
            errors.push(`missing required argument "${key}"`);
    }
    const props = parameters.properties ?? {};
    for (const key of Object.keys(props)) {
        const value = obj[key];
        if (value === undefined)
            continue;
        const t = props[key].type;
        if (t === 'string' && typeof value !== 'string')
            errors.push(`"${key}" must be a string`);
        else if (t === 'number' && typeof value !== 'number')
            errors.push(`"${key}" must be a number`);
        else if (t === 'boolean' && typeof value !== 'boolean')
            errors.push(`"${key}" must be a boolean`);
        else if (t === 'array' && !Array.isArray(value))
            errors.push(`"${key}" must be an array`);
        else if (t === 'object' && (typeof value !== 'object' || value === null || Array.isArray(value))) {
            errors.push(`"${key}" must be an object`);
        }
    }
    return errors;
}
/** 与 `@deepseek-ai/dsh-tools` 的 defineTool 等价的最小实现：编译 schema + 校验后调用 execute。 */
function defineTool(options) {
    const parameters = paramsSpecToJsonSchema(options.parameters);
    const outputSchema = schemaSpecToJsonSchema(options.output.schema);
    const userExecute = options.execute;
    const userRender = options.output.render;
    if (options.timeoutMs !== undefined && (!Number.isFinite(options.timeoutMs) || options.timeoutMs <= 0)) {
        throw new Error(`defineTool(${options.name}): timeoutMs must be a positive finite number`);
    }
    return {
        name: options.name,
        description: options.description,
        parameters,
        output: {
            schema: outputSchema,
            render: (args, value) => userRender(args, value),
        },
        ...(options.timeoutMs !== undefined ? { timeoutMs: options.timeoutMs } : {}),
        async execute(args, exec) {
            const violations = validateArgs(parameters, args);
            if (violations.length > 0) {
                throw new Error(`Invalid arguments for ${options.name}: ${violations.join('; ')}`);
            }
            return userExecute(args, exec);
        },
    };
}
export const name = 'project-memory';
export const inject = ['tools', 'systemPrompt'];
/**
 * 索引行格式：`- [类别] 主题：一句话摘要 → 文件名.md`
 * 兼容半角冒号 `:` 与箭头 `->`。
 */
const INDEX_LINE_RE = /^-\s*\[([^\]]*)\]\s*([^:：]+)[:：]\s*(.+?)\s*(?:→|->)\s*(\S+\.md)\s*$/i;
/** 只允许 memory/ 下的单段 `.md` 文件名：无路径分隔符、不以 `.` 开头。 */
function isSafeFile(file) {
    return file.length > 0
        && file.endsWith('.md')
        && !file.includes('/')
        && !file.includes('\\')
        && !file.startsWith('.');
}
/** 从一行原始索引里抽出“安全”文件字段，用于按文件名去重 upsert/删除。 */
function fileOfLine(line) {
    const m = INDEX_LINE_RE.exec(line.trim());
    if (m === null)
        return null;
    return isSafeFile(m[4]) ? m[4] : null;
}
/** 生成一条规范索引行（主题：摘要 → 文件）。 */
function formatIndexLine(entry) {
    return `- [${entry.category}] ${entry.topic}：${entry.summary} → ${entry.file}`;
}
/** 敏感关键词共用的非捕获组（中英文）。 */
const SECRET_KEYWORD_SOURCE = '(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?key|private[_-]?key|secret[_-]?key|token|cookie|authorization|jwt|credential|口令|密码|密钥|令牌|凭据|凭证)';
/** 关键词 + 赋值形状：`password=…`、`token: …`、`cookie: session=…`、`密钥=…`。 */
const SECRET_ASSIGN_RE = new RegExp(`${SECRET_KEYWORD_SOURCE}\\s*[:：=]\\s*\\S+`, 'i');
/** `.env` 命中时，还须伴随赋值或敏感关键词才算凭据引用。 */
const SECRET_ENV_REF_RE = new RegExp(`(?:${SECRET_KEYWORD_SOURCE}|[:=]\\s*\\S)`, 'i');
/**
 * 敏感信息检测。命中即拒绝保存，返回一个人类可读的原因；否则返回 null。
 * 覆盖：token / cookie / password / 密钥 / JWT / .env 以及常见云凭据形状。
 */
export function detectSensitive(text) {
    if (text === null || text === undefined)
        return null;
    const t = String(text);
    if (t.trim() === '')
        return null;
    if (/-----BEGIN\s+(RSA\s+|EC\s+|OPENSSH\s+|DSA\s+)?PRIVATE\s+KEY-----/i.test(t)) {
        return 'Private key material';
    }
    if (/\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/.test(t)) {
        return 'JWT token';
    }
    if (/\bAKIA[0-9A-Z]{16}\b/.test(t))
        return 'AWS access key';
    if (/\bgh[pousr]_[A-Za-z0-9]{20,}\b/.test(t))
        return 'GitHub token';
    if (/\bBearer\s+[A-Za-z0-9._~+/=-]{16,}/i.test(t))
        return 'Bearer token';
    if (/\bxox[baprs]-[A-Za-z0-9-]{10,}/.test(t))
        return 'Slack token';
    if (/\bsk-(?:live-)?[A-Za-z0-9_-]{20,}\b/.test(t))
        return 'API secret key';
    if (/\btcp_[A-Za-z0-9]{16,}\b/.test(t))
        return 'Cloud API token';
    if (SECRET_ASSIGN_RE.test(t)) {
        return 'Secret/credential assignment';
    }
    if (/\.env\b/i.test(t) && SECRET_ENV_REF_RE.test(t)) {
        return '.env credentials reference';
    }
    return null;
}
/** 从主题派生一个安全的文件名（保留中英文与数字，其余转 `-`）。 */
export function slugifyFile(topic) {
    const base = topic
        .trim()
        .toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\p{Letter}\p{Number}_-]+/gu, '')
        .replace(/^-+|-+$/g, '')
        .slice(0, 64);
    return `${base || 'memory'}.md`;
}
/** 清洗显式传入的文件名：只允许单段文件名、去路径穿越、强制 `.md`。 */
export function sanitizeFile(file) {
    const cleaned = file
        .trim()
        .replace(/[\\/]+/g, '_')
        .replace(/^\.+/, '');
    const base = cleaned.replace(/\.md$/i, '').slice(0, 64);
    return `${base || 'memory'}.md`;
}
/** 解析一条索引行；只认规格格式、且文件必须是 memory/ 下单段 `.md`。 */
export function parseIndexLine(line) {
    const m = INDEX_LINE_RE.exec(line.trim());
    if (m === null)
        return null;
    const file = m[4];
    if (!isSafeFile(file))
        return null;
    return {
        line,
        category: (m[1] ?? '').trim() || 'general',
        topic: (m[2] ?? '').trim() || 'untitled',
        summary: (m[3] ?? '').trim(),
        file,
    };
}
/** 读取并解析索引；索引不存在时返回空数组。 */
export async function readIndex(indexPath) {
    let raw;
    try {
        raw = await fs.readFile(indexPath, 'utf8');
    }
    catch (error) {
        if (error.code === 'ENOENT')
            return [];
        throw error;
    }
    return raw
        .split(/\r?\n/)
        .map(parseIndexLine)
        .filter((entry) => entry !== null);
}
/**
 * 按文件名 upsert 一条索引：命中则原位替换该行，否则追加到末尾，其余行逐字保留。
 */
export async function upsertIndex(indexPath, entry) {
    let raw = '';
    try {
        raw = await fs.readFile(indexPath, 'utf8');
    }
    catch (error) {
        if (error.code !== 'ENOENT')
            throw error;
    }
    const lines = raw.trim() === '' ? [] : raw.split(/\r?\n/);
    while (lines.length > 0 && lines[lines.length - 1].trim() === '')
        lines.pop();
    const newLine = formatIndexLine(entry);
    const idx = lines.findIndex(line => fileOfLine(line) === entry.file);
    let created = false;
    if (idx >= 0) {
        lines[idx] = newLine;
    }
    else {
        lines.push(newLine);
        created = true;
    }
    await fs.writeFile(indexPath, `${lines.join('\n')}\n`, 'utf8');
    return created;
}
/**
 * 从索引里删除指定文件名（集合）对应的行；其余行逐字保留。
 * @returns 是否有行被删除。
 */
export async function removeIndexLines(indexPath, files) {
    let raw = '';
    try {
        raw = await fs.readFile(indexPath, 'utf8');
    }
    catch (error) {
        if (error.code === 'ENOENT')
            return false;
        throw error;
    }
    const lines = raw.split(/\r?\n/);
    const kept = lines.filter(line => {
        const file = fileOfLine(line);
        return file === null || !files.has(file);
    });
    if (kept.length === lines.length)
        return false;
    while (kept.length > 0 && kept[kept.length - 1].trim() === '')
        kept.pop();
    await fs.writeFile(indexPath, kept.length > 0 ? `${kept.join('\n')}\n` : '', 'utf8');
    return true;
}
/** 把 query 拆成可匹配的关键词：ASCII 词 + 中文字符 + 中文二元组。 */
export function keywordTokens(query) {
    const tokens = new Set();
    const lower = query.toLowerCase();
    for (const word of lower.match(/[a-z0-9]+/g) ?? [])
        tokens.add(word);
    const han = (lower.match(/\p{Script=Han}+/gu) ?? []).join('');
    for (const ch of han)
        tokens.add(ch);
    for (let i = 0; i + 1 < han.length; i++)
        tokens.add(han.slice(i, i + 2));
    return [...tokens];
}
/**
 * 对一个字段打分：整段命中给 `base * 3`（最强信号，命中即返回，避免子 token
 * 重复计分），否则按分词 token 逐个命中各给 `base`。较 `includes` 整串匹配
 * 更能容忍多词/分词差异。
 */
function fieldScore(field, query, base) {
    const q = query.toLowerCase().trim();
    if (q === '')
        return 0;
    const f = field.toLowerCase();
    if (f.includes(q))
        return base * 3;
    let score = 0;
    for (const token of keywordTokens(q)) {
        if (f.includes(token))
            score += base;
    }
    return score;
}
/** 对一条索引按 query 打分（topic 权重最高）。 */
export function scoreEntry(entry, query) {
    return fieldScore(entry.topic, query, 3)
        + fieldScore(entry.summary, query, 2)
        + fieldScore(entry.category, query, 1);
}
/** 从正文头部解析 `- updated: <iso>` 时间戳。 */
export function parseUpdated(body) {
    const m = /^-\s*updated:\s*(\S+)\s*$/im.exec(body);
    return m?.[1];
}
/** 新鲜度加权：越近越高，最多 +3。 */
export function recencyBoost(updated, now) {
    if (!updated)
        return 0;
    const t = Date.parse(updated);
    if (!Number.isFinite(t))
        return 0;
    const days = (now - t) / 86_400_000;
    if (days < 0)
        return 1;
    if (days <= 7)
        return 3;
    if (days <= 30)
        return 2;
    if (days <= 90)
        return 1;
    return 0;
}
/** 在正文里截取围绕首个命中的片段，便于返回“摘要级”匹配结果。 */
export function extractSnippet(body, query, radius = 90) {
    const lower = body.toLowerCase();
    const q = query.toLowerCase().trim();
    let at = -1;
    let span = q.length;
    if (q !== '' && lower.includes(q)) {
        at = lower.indexOf(q);
    }
    else {
        for (const token of keywordTokens(query)) {
            const i = lower.indexOf(token);
            if (i >= 0) {
                at = i;
                span = token.length;
                break;
            }
        }
    }
    const text = body.replace(/\s+/g, ' ').trim();
    if (at < 0 || text.length <= radius * 2)
        return text.slice(0, 240);
    const search = text.toLowerCase();
    const hit = search.indexOf(q !== '' ? q : (keywordTokens(query)[0] ?? ''));
    const start = Math.max(0, hit < 0 ? 0 : hit - radius);
    const end = Math.min(text.length, (hit < 0 ? radius : hit) + span + radius);
    return `${start > 0 ? '…' : ''}${text.slice(start, end)}${end < text.length ? '…' : ''}`;
}
/** 会话工作区根：优先取会话 cwd，回退到 process.cwd()。 */
function workspaceBase(policy, exec) {
    if (policy) {
        try {
            const resolvedPolicy = policy.resolve({ ...exec?.agent ? { session: exec.agent.session } : {} });
            if (resolvedPolicy?.workspaceRoot)
                return resolvedPolicy.workspaceRoot;
        }
        catch {
            // 服务不可用/无会话时回退。
        }
    }
    return process.cwd();
}
/** 按配置 + 工作区根解析路径。 */
function resolveConfig(config, baseDir) {
    const explicit = config?.memoryRoot?.trim();
    const memoryRoot = explicit
        ? (isAbsolute(explicit) ? explicit : resolve(baseDir, explicit))
        : join(baseDir, 'memory');
    const indexFilename = config?.indexFilename?.trim() || 'MEMORY.md';
    const referenceFilename = config?.referenceFilename?.trim() || 'reference.md';
    return {
        memoryRoot,
        indexFilename,
        indexPath: join(memoryRoot, indexFilename),
        referenceFilename,
        referencePath: join(memoryRoot, referenceFilename),
    };
}
/** 读写前确保目录存在。 */
async function ensureDir(dir) {
    await fs.mkdir(dir, { recursive: true });
}
/** 生成一行审计用时间戳。 */
function nowIso() {
    return new Date().toISOString();
}
/**
 * reference.md 是纯 `## 标题` 块序列，此函数按块裁剪，保留最新的 `max` 块。
 */
export function trimReference(content, max) {
    const blocks = content.trim().split(/(?=^## )/m).filter(block => block.trim() !== '');
    if (blocks.length <= max)
        return content;
    return `${blocks.slice(-max).join('\n').replace(/\n+$/, '')}\n`;
}
/**
 * 记忆工具的使用时机规则，作为系统提示一节注入。工具名随前缀动态生成。
 */
function memoryRules(load, upsert, finalize, forget) {
    return [
        'Project memory (the memory/ directory in the current project) is durable, auditable memory shared across sessions — it is separate from this conversation.',
        `- At the start of a session, or before starting a task whose conventions you do not already know, call ${load} with a short keyword query and follow any relevant memory it returns (the returned catalog lists every memory when you need the full picture).`,
        `- Write memory only for durable, project-level knowledge. When the user explicitly asks you to remember or persist something ("记住…", "以后都按这个来…", "以后都这样做…"), call ${upsert} with a short topic, a one-line summary, and the details.`,
        `- Before you report a non-trivial task as finished, call ${finalize} to distill the outcome into one reference memory. Skip it only for trivial single-turn replies with nothing durable.`,
        `- Drop stale or superseded memory with ${forget}. Never store secrets — tokens, cookies, passwords, API keys, JWTs, or .env values — in memory; the write tools refuse and return ok=false.`,
        '- Store finished, reviewable facts and decisions, not in-progress scratch.',
    ].join('\n');
}
/**
 * 注册四个工具：memory_load_context / memory_upsert / memory_finalize / memory_forget
 * （名称都可经 config.toolPrefix 加前缀）。与 harness 现有插件对齐：
 * `export const name` + `export const inject` + `export function apply(ctx, config)`。
 */
export function apply(ctx, config = {}) {
    const policy = ctx.get('sandboxPolicy');
    const prefix = (config.toolPrefix ?? '').trim();
    const loadName = `${prefix}memory_load_context`;
    const upsertName = `${prefix}memory_upsert`;
    const finalizeName = `${prefix}memory_finalize`;
    const forgetName = `${prefix}memory_forget`;
    const maxReferenceEntries = config.maxReferenceEntries;
    ctx.systemPrompt.section({
        name: `${prefix}tool:project-memory`,
        order: 113,
        text: memoryRules(loadName, upsertName, finalizeName, forgetName),
    });
    const LOAD_OUTPUT = {
        schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
                ok: { type: 'boolean', required: true },
                matched: {
                    type: 'array',
                    required: true,
                    items: {
                        type: 'object',
                        additionalProperties: false,
                        properties: {
                            category: { type: 'string', required: true },
                            topic: { type: 'string', required: true },
                            summary: { type: 'string', required: true },
                            file: { type: 'string', required: true },
                            score: { type: 'number', required: true },
                            snippet: { type: 'string' },
                        },
                    },
                },
                catalog: {
                    type: 'array',
                    required: true,
                    items: {
                        type: 'object',
                        additionalProperties: false,
                        properties: {
                            category: { type: 'string', required: true },
                            topic: { type: 'string', required: true },
                            summary: { type: 'string', required: true },
                            file: { type: 'string', required: true },
                            updated: { type: 'string' },
                        },
                    },
                },
                message: { type: 'string' },
            },
        },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    };
    ctx.tools.register(defineTool({
        name: loadName,
        description: 'Read the project memory index (memory/MEMORY.md) plus matching body files, '
            + 'match by keyword against the query, and return concise matched fragments '
            + '(prefer the one-line summary plus a short snippet; do not dump whole files). '
            + 'Also returns the full catalog of every memory so the model can list what exists. '
            + 'Only reads memory files that live directly under memory/.',
        parameters: {
            query: {
                type: 'string',
                required: true,
                description: 'Keywords/topic to search memory for. A short phrase or a few words. Leave empty just to list the catalog.',
            },
            limit: {
                type: 'number',
                description: 'Maximum matched fragments to return. Defaults to 5.',
            },
        },
        output: LOAD_OUTPUT,
        async execute(args, exec) {
            try {
                const resolved = resolveConfig(config, workspaceBase(policy, exec));
                const entries = await readIndex(resolved.indexPath);
                const limit = Number.isFinite(args.limit) && args.limit > 0
                    ? Math.min(Math.floor(args.limit), 20)
                    : 5;
                if (entries.length === 0) {
                    return {
                        ok: true,
                        matched: [],
                        catalog: [],
                        message: `No memory yet. Index ${resolved.indexPath} does not exist or is empty.`,
                    };
                }
                const query = String(args.query ?? '').trim();
                const now = Date.now();
                const rows = [];
                for (const entry of entries) {
                    let body = '';
                    try {
                        body = await fs.readFile(join(resolved.memoryRoot, entry.file), 'utf8');
                    }
                    catch {
                        body = '';
                    }
                    const updated = parseUpdated(body);
                    const ts = updated ? Date.parse(updated) : Number.NaN;
                    const idx = scoreEntry(entry, query);
                    const bodyScore = query === '' ? 0 : fieldScore(body.slice(0, 8000), query, 1);
                    const recency = Number.isFinite(ts) ? recencyBoost(updated, now) : 0;
                    rows.push({ entry, body, updated, ts, total: idx + bodyScore * 0.5 + recency });
                }
                const catalog = rows
                    .slice()
                    .sort((a, b) => (Number.isFinite(b.ts) ? b.ts : 0) - (Number.isFinite(a.ts) ? a.ts : 0))
                    .map(row => ({
                    category: row.entry.category,
                    topic: row.entry.topic,
                    summary: row.entry.summary,
                    file: row.entry.file,
                    ...(row.updated ? { updated: row.updated } : {}),
                }));
                if (query === '') {
                    return { ok: true, matched: [], catalog, message: 'No query given; returned the full catalog.' };
                }
                const matched = rows
                    .filter(row => row.total > 0)
                    .sort((a, b) => b.total - a.total)
                    .slice(0, limit)
                    .map(row => ({
                    category: row.entry.category,
                    topic: row.entry.topic,
                    summary: row.entry.summary,
                    file: row.entry.file,
                    score: Math.round(row.total * 10) / 10,
                    snippet: extractSnippet(row.body, query),
                }));
                return {
                    ok: true,
                    matched,
                    catalog,
                    ...(matched.length === 0
                        ? { message: `No match for ${JSON.stringify(query)}; the catalog lists all memory.` }
                        : {}),
                };
            }
            catch (error) {
                return { ok: false, matched: [], catalog: [], message: error.message };
            }
        },
    }));
    const UPSERT_OUTPUT = {
        schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
                ok: { type: 'boolean', required: true },
                file: { type: 'string' },
                topic: { type: 'string' },
                category: { type: 'string' },
                indexUpdated: { type: 'boolean' },
                reason: { type: 'string' },
            },
        },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    };
    ctx.tools.register(defineTool({
        name: upsertName,
        description: 'Write or update one project memory only when the user has explicitly asked to '
            + 'remember or persist something ("记住…", "以后都按这个来…"). Writes the body to '
            + 'memory/<file>.md and upserts the one-line index entry in memory/MEMORY.md. '
            + 'Refuses to save any sensitive material (token/cookie/password/keys/JWT/.env).',
        parameters: {
            topic: {
                type: 'string',
                required: true,
                description: 'Short topic title for this memory.',
            },
            summary: {
                type: 'string',
                required: true,
                description: 'One-line summary. This is what the index stores; keep it short.',
            },
            content: {
                type: 'string',
                required: true,
                description: 'Full body of the memory (the details). Written to the body file.',
            },
            category: {
                type: 'string',
                description: 'Category label for the index, e.g. "decision", "convention", "context". Defaults to "general".',
            },
            file: {
                type: 'string',
                description: 'Optional explicit filename. Defaults to a slug derived from the topic.',
            },
        },
        output: UPSERT_OUTPUT,
        async execute(args, exec) {
            const category = args.category?.trim() || 'general';
            const topic = args.topic.trim();
            const summary = args.summary.trim();
            const content = args.content;
            const file = args.file ? sanitizeFile(args.file) : slugifyFile(topic);
            const sensitive = detectSensitive(`${category}\n${topic}\n${summary}\n${content}\n${file}`);
            if (sensitive !== null) {
                return { ok: false, reason: `Refused to save sensitive material: ${sensitive}` };
            }
            try {
                const resolved = resolveConfig(config, workspaceBase(policy, exec));
                await ensureDir(resolved.memoryRoot);
                const body = [
                    `# ${topic}`,
                    '',
                    '- category: ' + category,
                    '- topic: ' + topic,
                    '- updated: ' + nowIso(),
                    '',
                    content,
                    '',
                ].join('\n');
                await fs.writeFile(join(resolved.memoryRoot, file), body, 'utf8');
                const created = await upsertIndex(resolved.indexPath, {
                    line: '',
                    category,
                    topic,
                    summary,
                    file,
                });
                return { ok: true, file, topic, category, indexUpdated: created };
            }
            catch (error) {
                return { ok: false, reason: error.message };
            }
        },
    }));
    const FINALIZE_OUTPUT = {
        schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
                ok: { type: 'boolean', required: true },
                file: { type: 'string' },
                entry: { type: 'string' },
                reason: { type: 'string' },
            },
        },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    };
    ctx.tools.register(defineTool({
        name: finalizeName,
        description: 'At task wrap-up, distill the outcome into one reference memory. Appends to the '
            + 'fixed memory/reference.md file (fixed topic/reference file, so it never explodes '
            + 'into many files) and refreshes its single index line in memory/MEMORY.md. '
            + 'Refuses to save sensitive material.',
        parameters: {
            summary: {
                type: 'string',
                required: true,
                description: 'One-line distillation of what was decided/finished.',
            },
            content: {
                type: 'string',
                required: true,
                description: 'The reference-style distilled body.',
            },
            label: {
                type: 'string',
                description: 'Optional tag for the appended entry heading, e.g. a feature name.',
            },
        },
        output: FINALIZE_OUTPUT,
        async execute(args, exec) {
            const summary = args.summary.trim();
            const content = args.content;
            const label = args.label?.trim();
            const sensitive = detectSensitive(`${summary}\n${content}\n${label ?? ''}`);
            if (sensitive !== null) {
                return { ok: false, reason: `Refused to save sensitive material: ${sensitive}` };
            }
            try {
                const resolved = resolveConfig(config, workspaceBase(policy, exec));
                await ensureDir(resolved.memoryRoot);
                const stamp = nowIso();
                const heading = label ? `${stamp} · ${label} · ${summary}` : `${stamp} · ${summary}`;
                const block = `## ${heading}\n\n${content}\n`;
                let existing = '';
                try {
                    existing = await fs.readFile(resolved.referencePath, 'utf8');
                }
                catch (error) {
                    if (error.code !== 'ENOENT')
                        throw error;
                }
                let next = `${existing.replace(/\s+$/, '')}${existing.trim() === '' ? '' : '\n\n'}${block}\n`;
                if (maxReferenceEntries !== undefined && maxReferenceEntries > 0) {
                    next = trimReference(next, maxReferenceEntries);
                }
                await fs.writeFile(resolved.referencePath, next, 'utf8');
                await upsertIndex(resolved.indexPath, {
                    line: '',
                    category: 'reference',
                    topic: 'reference',
                    summary,
                    file: resolved.referenceFilename,
                });
                return { ok: true, file: resolved.referenceFilename, entry: heading };
            }
            catch (error) {
                return { ok: false, reason: error.message };
            }
        },
    }));
    const FORGET_OUTPUT = {
        schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
                ok: { type: 'boolean', required: true },
                removed: { type: 'array', required: true, items: { type: 'string' } },
                reason: { type: 'string' },
            },
        },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    };
    ctx.tools.register(defineTool({
        name: forgetName,
        description: 'Forget (delete) one or more project memories. Give either an exact memory '
            + 'filename (e.g. "conventions.md") or a topic substring; matching body files are '
            + 'removed and their index lines dropped from memory/MEMORY.md. The fixed '
            + 'reference file and the index itself are protected and cannot be deleted this way.',
        parameters: {
            target: {
                type: 'string',
                required: true,
                description: 'Exact filename (must end in .md) or a topic substring to match. Matching is case-insensitive for topic.',
            },
        },
        output: FORGET_OUTPUT,
        async execute(args, exec) {
            const target = String(args.target ?? '').trim();
            if (target === '') {
                return { ok: false, removed: [], reason: 'target is required: give a filename or a topic substring.' };
            }
            try {
                const resolved = resolveConfig(config, workspaceBase(policy, exec));
                let candidates;
                if (/\.md$/i.test(target) && isSafeFile(target)) {
                    candidates = [target];
                }
                else {
                    const entries = await readIndex(resolved.indexPath);
                    const q = target.toLowerCase();
                    candidates = entries
                        .filter(entry => entry.topic.toLowerCase().includes(q))
                        .map(entry => entry.file);
                }
                const protectedFiles = new Set([resolved.indexFilename, resolved.referenceFilename]);
                const removable = [...new Set(candidates.filter(f => isSafeFile(f) && !protectedFiles.has(f)))];
                if (removable.length === 0) {
                    return { ok: false, removed: [], reason: `No forgettable memory matched ${JSON.stringify(target)} (or it is protected).` };
                }
                const removed = [];
                for (const file of removable) {
                    try {
                        await fs.unlink(join(resolved.memoryRoot, file));
                    }
                    catch (error) {
                        if (error.code !== 'ENOENT')
                            throw error;
                    }
                    removed.push(file);
                }
                await removeIndexLines(resolved.indexPath, new Set(removable));
                return { ok: true, removed };
            }
            catch (error) {
                return { ok: false, removed: [], reason: error.message };
            }
        },
    }));
}
