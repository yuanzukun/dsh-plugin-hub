/**
 * Tier-2 context files: AGENTS.md / CLAUDE.md injected as project context.
 *
 * **Check first — don't double-inject.** DSH's native `dsh-agent-instructions`
 * plugin already injects AGENTS.md and CLAUDE.md into the project context
 * (standard/code presets). Skillport only takes over when that plugin is NOT
 * mounted, so a composition without native context files still gets the
 * cross-tool convention.
 *
 * @module dsh-skillport/context-files
 */

import type { Context } from '@deepseek-ai/cordis'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import type {} from '@deepseek-ai/dsh-system-prompt'

/** Max bytes of context-file content injected per file (safety cap). */
const MAX_CONTEXT_BYTES = 65536

/** Candidate context files, lowest-precedence first (AGENTS.md wins). */
const CANDIDATES = ['CLAUDE.md', 'AGENTS.md']

/**
 * Inject AGENTS.md / CLAUDE.md as a system-prompt context section, unless the
 * native agent-instructions plugin is mounted. The section is re-evaluated per
 * assembly with the session cwd, so switching projects swaps the injected
 * context.
 */
export function applyContextFiles(ctx: Context, warn: (message: string) => void): void {
  const nativeMounted = [...ctx.registry.values()].some(
    (runtime) => runtime.name === 'agent-instructions' || runtime.name === '@deepseek-ai/dsh-agent-instructions',
  )
  if (nativeMounted) {
    ctx.logger.info('[skillport] AGENTS.md / CLAUDE.md are injected natively by dsh-agent-instructions — not double-injecting')
    return
  }
  const systemPrompt = ctx.reflect.get('systemPrompt')
  if (systemPrompt === undefined) {
    warn('systemPrompt service absent — context files not injected')
    return
  }
  systemPrompt.context({
    name: 'skillport:context-files',
    order: 30,
    text: (context: { agent?: { session?: { header?: { cwd?: string } } } }) => {
      const cwd = context.agent?.session?.header?.cwd
      if (cwd === undefined) return ''
      const sections: string[] = []
      for (const candidate of CANDIDATES) {
        const path = join(cwd, candidate)
        let content: string
        try {
          content = readFileSync(path, 'utf8')
        } catch {
          continue
        }
        if (content.length > MAX_CONTEXT_BYTES) content = content.slice(0, MAX_CONTEXT_BYTES)
        sections.push(`<context-file path="${candidate}">\n${content}\n</context-file>`)
      }
      return sections.join('\n\n')
    },
  })
  ctx.logger.info('[skillport] dsh-agent-instructions absent — injecting AGENTS.md / CLAUDE.md as project context')
}
