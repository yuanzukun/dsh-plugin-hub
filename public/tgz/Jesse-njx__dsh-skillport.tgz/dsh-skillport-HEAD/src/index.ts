/**
 * dsh-skillport — every skill you already have works in DSH.
 *
 * A DSH bundle (`dsh plugin add @dsh-skillport/bundle`): registers a skill
 * provider on `ctx.skills` that discovers Agent Skills `SKILL.md` files in
 * every mainstream location (Claude Code, Gemini, extraPaths — plus DSH and
 * Codex fallback when the native filesystem provider is absent), converts
 * Tier-2 formats (cursor rules, claude commands) into skills, and ships a
 * `find_skill` search tool plus a `/skills doctor` command. Registrations are
 * Cordis effects, so disabling the plugin unloads every imported skill.
 *
 * @module @dsh-skillport/bundle
 */

import type { Context } from '@deepseek-ai/cordis'
import { homedir } from 'node:os'
import { resolve } from 'node:path'
import z from '@deepseek-ai/schemastery'
import type {} from '@deepseek-ai/dsh-skill'
import type {} from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-system-prompt'
import type {} from '@deepseek-ai/dsh-commands'
import type {} from '@deepseek-ai/dsh-fs'
import { SkillportProvider, ioFromContext } from './provider.ts'
import { applyFindSkillTool } from './find-skill.ts'
import { applySkillsDoctorCommand } from './skills-command.ts'
import { applyContextFiles } from './context-files.ts'
import { SPEC_REVISION } from './spec.ts'
import type { SourceSet } from './discover.ts'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'dsh-skillport'

/** Services required to load: the skill registry (the whole point). */
export const inject = ['skills']

/** Plugin config — all optional; defaults match the pinned spec behavior. */
export const Config: z<{
  sources?: SourceSet[]
  extraPaths?: string[]
  convert?: {
    cursorRules?: boolean
    contextFiles?: boolean
    claudeCommands?: boolean
  }
  maxIndexEntries?: number
  providerName?: string
  home?: string
}> = z.object({
  sources: z.array(z.union(['dsh', 'claude', 'agents', 'gemini'])).default(['dsh', 'claude', 'agents', 'gemini']),
  extraPaths: z.array(z.string()).default([]),
  convert: z.object({
    cursorRules: z.boolean().default(true),
    contextFiles: z.boolean().default(true),
    claudeCommands: z.boolean().default(true),
  }).default({ cursorRules: true, contextFiles: true, claudeCommands: true }),
  maxIndexEntries: z.number().default(100),
  providerName: z.string().default('skillport'),
  home: z.string(),
})

type ResolvedConfig = {
  sources: SourceSet[]
  extraPaths: string[]
  convert: { cursorRules: boolean; contextFiles: boolean; claudeCommands: boolean }
  maxIndexEntries: number
  providerName: string
  home: string
}

/** Register the skillport provider + tooling. */
export function apply(ctx: Context, rawConfig: unknown): void {
  const config = rawConfig as Partial<ResolvedConfig>
  const resolved: ResolvedConfig = {
    sources: config.sources ?? ['dsh', 'claude', 'agents', 'gemini'],
    extraPaths: (config.extraPaths ?? []).map((p) => resolve(p)),
    convert: {
      cursorRules: config.convert?.cursorRules ?? true,
      contextFiles: config.convert?.contextFiles ?? true,
      claudeCommands: config.convert?.claudeCommands ?? true,
    },
    maxIndexEntries: config.maxIndexEntries ?? 100,
    providerName: config.providerName ?? 'skillport',
    home: config.home !== undefined ? resolve(config.home) : homedir(),
  }

  const warn = (message: string): void => ctx.logger.warn(`[skillport] ${message}`)
  const io = ioFromContext(ctx)

  // "Check first — don't double-inject": when the native
  // @deepseek-ai/dsh-skill-filesystem provider is mounted (standard/code
  // presets), it already scans .dsh/skills + .agents/skills, so skillport
  // drops those sets and only adds the locations the platform does not cover.
  const nativeProviderMounted = [...ctx.registry.values()].some(
    (runtime) => runtime.name === 'skill-filesystem' || runtime.name === '@deepseek-ai/dsh-skill-filesystem',
  )
  if (nativeProviderMounted) {
    const skipped = resolved.sources.filter((s) => s === 'dsh' || s === 'agents')
    if (skipped.length > 0) {
      ctx.logger.info(`[skillport] sources ${skipped.join(', ')} are scanned natively by dsh-skill-filesystem — not re-scanning (no double-injection)`)
    }
  }

  ctx.skills.registerProvider((control) => {
    const provider = new SkillportProvider(
      {
        sources: resolved.sources,
        extraPaths: resolved.extraPaths,
        convert: { cursorRules: resolved.convert.cursorRules, claudeCommands: resolved.convert.claudeCommands },
        providerName: resolved.providerName,
        maxIndexEntries: resolved.maxIndexEntries,
      },
      io,
      resolved.home,
      control,
      warn,
      nativeProviderMounted,
    )
    // Invalidate the catalog when a model-facing write/edit touches any path
    // (mirrors the native skill-filesystem provider's mutation hook).
    ctx.on('fs/observed', (_target, _observation, actor) => {
      if (actor === undefined || !('name' in actor)) return
      const value = (actor as { name?: unknown }).name
      if (value !== 'edit' && value !== 'write') return
      provider.observeHostMutation()
    })
    return provider
  })

  if (resolved.convert.contextFiles) {
    applyContextFiles(ctx, warn)
  }

  applyFindSkillTool(ctx, resolved.maxIndexEntries, warn)
  applySkillsDoctorCommand(ctx, warn)

  ctx.logger.info(`[skillport] loaded (spec revision: ${SPEC_REVISION}; sources: ${resolved.sources.join(', ')}; extraPaths: ${resolved.extraPaths.length})`)
}

// Re-exported for consumers that want to build on the loader directly.
export { parseSkillSpec, isValidSkillName, SPEC_REVISION } from './spec.ts'
export { testFire, renderTestFire, renderDoctorList, type DoctorSkill, type TestFireMatch } from './doctor.ts'
export { findSkill, renderFindSkillResults, type SearchableSkill, type FindSkillResult } from './search.ts'
export { SkillportProvider, ioFromContext, ioFromNode, type SkillLocator } from './provider.ts'
