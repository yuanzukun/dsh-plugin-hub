/**
 * `skills doctor` — the debuggability surface for skill trigger quality.
 * Pure TS: builds a report of loaded skills (with sources) and scores how
 * well each skill's description matches a user-supplied description
 * ("test-fire"), turning a fuzzy trigger mismatch into a ranked, inspectable
 * list. Shared by the DSH `/skills doctor` command and the `skills-doctor`
 * CLI.
 *
 * @module dsh-skillport/doctor
 */

/** Minimal skill summary the doctor renders (registry-agnostic). */
export interface DoctorSkill {
  name: string
  description: string
  whenToUse?: string
  source: string
  provider: string
  path?: string
}

/** One test-fire match with its relevance score. */
export interface TestFireMatch {
  skill: DoctorSkill
  /** 0..1 similarity between the probe description and the skill description. */
  score: number
  /** The words from the probe that matched the skill's description/name. */
  hits: string[]
}

const STOPWORDS = new Set([
  'a', 'an', 'the', 'and', 'or', 'of', 'to', 'for', 'in', 'on', 'with', 'is', 'are',
  'i', 'you', 'we', 'it', 'this', 'that', 'these', 'those', 'my', 'your', 'our',
  'please', 'can', 'could', 'would', 'should', 'will', 'do', 'does', 'did', 'be',
  'use', 'using', 'used', 'want', 'need', 'help', 'me', 'about', 'at', 'by', 'from',
])

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .split(/[^a-z0-9]+/u)
    .filter((word) => word.length > 2 && !STOPWORDS.has(word))
}

/** A ranked list of skills whose descriptions best match a probe description. */
export function testFire(probe: string, skills: DoctorSkill[]): TestFireMatch[] {
  const probeTokens = tokenize(probe)
  if (probeTokens.length === 0) return []
  const matches: TestFireMatch[] = []
  for (const skill of skills) {
    const corpus = [skill.name, skill.description, skill.whenToUse ?? ''].join(' ').toLowerCase()
    const hits = [...new Set(probeTokens.filter((token) => corpus.includes(token)))]
    if (hits.length === 0) continue
    // Score = matched-probe coverage weighted by name hits (names are the
    // strongest trigger signal).
    const nameBoost = skill.name.split('-').some((part) => probeTokens.includes(part)) ? 0.25 : 0
    const score = Math.min(1, hits.length / probeTokens.length + nameBoost)
    matches.push({ skill, score: round(score), hits })
  }
  return matches.sort((a, b) => b.score - a.score).slice(0, 10)
}

function round(value: number): number {
  return Math.round(value * 100) / 100
}

/** Render the test-fire result as plain text (command/CLI output). */
export function renderTestFire(probe: string, matches: TestFireMatch[]): string {
  const lines = [`Test-fire: "${probe}"`, '']
  if (matches.length === 0) {
    lines.push('No loaded skill description matched this probe.')
    lines.push('Check the skill catalog with `skills doctor list` — the description may be missing or too vague.')
    return lines.join('\n')
  }
  for (const match of matches) {
    const source = match.skill.source
    const path = match.skill.path !== undefined ? `  (${match.skill.path})` : ''
    lines.push(`- ${match.skill.name} [${match.skill.provider}/${source}] score=${match.score}${path}`)
    lines.push(`    "${match.skill.description}"`)
  }
  return lines.join('\n')
}

/** Render a full doctor report (list form): every loaded skill by source. */
export function renderDoctorList(skills: DoctorSkill[]): string {
  if (skills.length === 0) return 'No skills are loaded.'
  const bySource = new Map<string, DoctorSkill[]>()
  for (const skill of skills) {
    const bucket = bySource.get(skill.source) ?? []
    bucket.push(skill)
    bySource.set(skill.source, bucket)
  }
  const lines: string[] = []
  for (const [source, bucket] of [...bySource.entries()].sort()) {
    lines.push(`## ${source} (${bucket.length})`)
    for (const skill of bucket) {
      lines.push(`- ${skill.name} — ${skill.description}`)
    }
  }
  return lines.join('\n')
}
