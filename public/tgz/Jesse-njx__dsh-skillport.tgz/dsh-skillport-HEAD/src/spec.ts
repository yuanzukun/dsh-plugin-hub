/**
 * Agent Skills `SKILL.md` parsing + validation, per the pinned spec revision
 * (see docs/spec-revision.md). Pure TS — no DSH imports — so the same parser
 * serves the DSH provider, the standalone doctor CLI, and the conformance
 * tests.
 *
 * @module dsh-skillport/spec
 */

import { parse as parseYaml } from 'yaml'

/** Pinned Agent Skills spec revision tag (see docs/spec-revision.md). */
export const SPEC_REVISION = 'agentskills@5d4c1fda / dsh-base@0.1.0-rc.6'

/** Max name length per the pinned spec. */
export const MAX_NAME_LENGTH = 64
/** Max description length per the pinned spec. */
export const MAX_DESCRIPTION_LENGTH = 1024
/** Max compatibility field length per the pinned spec. */
export const MAX_COMPATIBILITY_LENGTH = 500

/** Raw parsed frontmatter + body of one SKILL.md. */
export interface ParsedSkillFile {
  /** Frontmatter data as a plain object (already YAML-parsed). */
  data: Record<string, unknown>
  /** The Markdown body after the frontmatter, trimmed of trailing newlines. */
  body: string
}

/**
 * A validated skill as the spec defines it. `invocation` is the DSH-native
 * policy surface derived from `disable-model-invocation` / `user-invocable`
 * (absent fields default to allowed).
 */
export interface SkillSpec {
  name: string
  description: string
  license?: string
  compatibility?: string
  metadata?: Record<string, unknown>
  /** Space-separated pre-approved tool list (experimental spec field). */
  allowedTools?: string
  /** DSH-native extra guidance shown in catalogs. */
  whenToUse?: string
  invocation: {
    modelInvocable: boolean
    userInvocable: boolean
  }
  content: string
}

/** Why a SKILL.md file was rejected during parsing/validation. */
export class SkillSpecError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'SkillSpecError'
  }
}

/** Split a file into YAML frontmatter + body; returns undefined when no `---` fence. */
export function splitFrontmatter(raw: string): { data: string; body: string } | undefined {
  const firstLineEnd = raw.indexOf('\n')
  if (firstLineEnd < 0) return undefined
  if (raw.slice(0, firstLineEnd).replace(/\r$/, '') !== '---') return undefined
  const start = firstLineEnd + 1
  let lineStart = start
  while (lineStart <= raw.length) {
    const nextNewline = raw.indexOf('\n', lineStart)
    const lineEnd = nextNewline < 0 ? raw.length : nextNewline
    if (raw.slice(lineStart, lineEnd).replace(/\r$/, '') === '---') {
      return {
        data: raw.slice(start, lineStart),
        body: nextNewline < 0 ? '' : raw.slice(nextNewline + 1),
      }
    }
    if (nextNewline < 0) return undefined
    lineStart = nextNewline + 1
  }
  return undefined
}

/** Parse raw SKILL.md text into frontmatter data + body. Throws SkillSpecError on malformed YAML. */
export function parseSkillFile(raw: string): ParsedSkillFile {
  const split = splitFrontmatter(raw)
  if (split === undefined) {
    throw new SkillSpecError('missing YAML frontmatter (must start with a "---" fence)')
  }
  let data: unknown
  try {
    data = parseYaml(split.data)
  } catch (error) {
    throw new SkillSpecError(`invalid YAML frontmatter: ${error instanceof Error ? error.message : String(error)}`)
  }
  if (typeof data !== 'object' || data === null || Array.isArray(data)) {
    throw new SkillSpecError('frontmatter must be a YAML mapping')
  }
  return { data: data as Record<string, unknown>, body: split.body.trim() }
}

/**
 * Validate a skill name against the pinned spec grammar: 1–64 chars, lowercase
 * alphanumerics and hyphens only, no leading/trailing/consecutive hyphens.
 */
export function isValidSkillName(name: string): boolean {
  return /^[a-z0-9]+(?:-[a-z0-9]+)*$/u.test(name) && name.length <= MAX_NAME_LENGTH
}

/** Read a required string field, rejecting empty/missing values. */
function requiredString(data: Record<string, unknown>, key: string, max: number, label: string): string {
  const value = data[key]
  if (typeof value !== 'string' || value.length === 0) {
    throw new SkillSpecError(`frontmatter field "${key}" is required and must be a non-empty string (${label})`)
  }
  if (value.length > max) {
    throw new SkillSpecError(`frontmatter field "${key}" exceeds ${max} characters (${label})`)
  }
  return value
}

/** Read an optional bounded string field. */
function optionalString(data: Record<string, unknown>, key: string, max: number): string | undefined {
  const value = data[key]
  if (value === undefined) return undefined
  if (typeof value !== 'string') {
    throw new SkillSpecError(`frontmatter field "${key}" must be a string`)
  }
  if (value.length > max) {
    throw new SkillSpecError(`frontmatter field "${key}" exceeds ${max} characters`)
  }
  return value
}

/** Parse DSH-native invocation flags, mirroring the native filesystem provider's semantics. */
function parseInvocation(data: Record<string, unknown>): { modelInvocable: boolean; userInvocable: boolean } {
  const disableModelInvocation = data['disable-model-invocation']
  const userInvocable = data['user-invocable']
  const asBoolean = (value: unknown): boolean | undefined => {
    if (typeof value === 'boolean') return value
    if (value === 1 || value === '1') return true
    if (value === 0 || value === '0') return false
    if (typeof value === 'string') {
      const normalized = value.toLowerCase()
      if (normalized === 'true' || normalized === 'yes' || normalized === 'on') return true
      if (normalized === 'false' || normalized === 'no' || normalized === 'off') return false
    }
    throw new SkillSpecError(`frontmatter field must be a boolean`)
  }
  const disabled = disableModelInvocation === undefined ? undefined : asBoolean(disableModelInvocation)
  const userOnly = userInvocable === undefined ? undefined : asBoolean(userInvocable)
  return {
    modelInvocable: disabled !== true,
    userInvocable: userOnly !== false,
  }
}

/** Parse + validate one SKILL.md into a SkillSpec. Throws SkillSpecError. */
export function parseSkillSpec(raw: string): SkillSpec {
  const { data, body } = parseSkillFile(raw)
  const name = requiredString(data, 'name', MAX_NAME_LENGTH, 'lowercase letters, numbers, hyphens')
  if (!isValidSkillName(name)) {
    throw new SkillSpecError(
      `invalid skill name "${name}": 1-64 chars, lowercase a-z0-9 with single hyphens, no leading/trailing/consecutive hyphens`,
    )
  }
  const description = requiredString(data, 'description', MAX_DESCRIPTION_LENGTH, 'what the skill does and when to use it')
  const compatibility = optionalString(data, 'compatibility', MAX_COMPATIBILITY_LENGTH)
  const whenToUse = optionalString(data, 'whenToUse', MAX_DESCRIPTION_LENGTH)
  const license = optionalString(data, 'license', MAX_COMPATIBILITY_LENGTH)
  const metadataValue = data.metadata
  const metadata = typeof metadataValue === 'object' && metadataValue !== null && !Array.isArray(metadataValue)
    ? metadataValue as Record<string, unknown>
    : metadataValue === undefined
      ? undefined
      : (() => { throw new SkillSpecError('frontmatter field "metadata" must be a mapping') })()
  const allowedTools = optionalString(data, 'allowed-tools', MAX_DESCRIPTION_LENGTH)
  const invocation = parseInvocation(data)
  return {
    name,
    description,
    ...(license !== undefined ? { license } : {}),
    ...(compatibility !== undefined ? { compatibility } : {}),
    ...(metadata !== undefined ? { metadata } : {}),
    ...(allowedTools !== undefined ? { allowedTools } : {}),
    ...(whenToUse !== undefined ? { whenToUse } : {}),
    invocation,
    content: body,
  }
}
