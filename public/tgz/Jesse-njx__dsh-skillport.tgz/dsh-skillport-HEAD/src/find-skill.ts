/**
 * `find_skill` — keyword search over the full loaded skill catalog. This is
 * the prompt-bloat overflow surface: when a user has hundreds of skills, the
 * injected model index is capped (`maxIndexEntries`) and find_skill becomes
 * the searchable index. Skills beyond the cap are registered user-invocable
 * only, so they never bloat the model catalog — but find_skill can still
 * search and load them. Registered only when a tools service is present.
 *
 * @module dsh-skillport/find-skill
 */

import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-skill'
import { findSkill, renderFindSkillResults, type SearchableSkill } from './search.ts'

/** Register the find_skill tool (no-op when tools service is absent). */
export function applyFindSkillTool(ctx: Context, _maxIndexEntries: number, warn: (message: string) => void): void {
  const tools = ctx.reflect.get('tools')
  if (tools === undefined) {
    warn('tools service absent — find_skill tool not registered')
    return
  }
  const tool = defineTool({
    name: 'find_skill',
    description: 'Search the loaded skill catalog by keyword (name, description, when-to-use). Use this when the available-skills list is large, a task does not clearly match a listed skill, or you suspect a skill exists that is not in the visible index. Returns the top matching skills with their sources and providers; pass `name` to load a specific skill\'s full instructions (including skills not in the visible index).',
    parameters: {
      query: { type: 'string', description: 'Free-text search query describing the capability or task. Ignored when `name` is given.' },
      name: { type: 'string', description: 'Exact skill name to load in full. When given, `query` is ignored.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          text: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: String(value.text) }],
    },
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const raw = args as { query?: unknown; name?: unknown }
      const lookup = {
        cwd: exec.agent?.session.header.cwd,
        signal: exec.signal,
        scope: exec.agent,
      }
      const name = typeof raw.name === 'string' && raw.name.length > 0 ? raw.name : undefined
      if (name !== undefined) {
        const skill = await ctx.skills.get(name, lookup)
        if (skill === undefined) return { text: `skill "${name}" is unknown or no longer available.` }
        const header = `## ${skill.name} [${skill.provider}/${skill.source}]\n\n${skill.description}\n`
        return { text: `${header}${skill.content}` }
      }
      const query = String(raw.query ?? '')
      if (query.trim() === '') return { text: 'find_skill needs a non-empty `query`, or a `name` to load.' }
      const summaries = await ctx.skills.list(lookup)
      const searchable: SearchableSkill[] = summaries.map((skill) => ({
        name: skill.name,
        description: skill.description,
        whenToUse: skill.whenToUse,
        source: skill.source,
        provider: skill.provider,
      }))
      const results = findSkill(query, searchable)
      return { text: renderFindSkillResults(results) }
    },
  })
  tools.register(tool)
}
