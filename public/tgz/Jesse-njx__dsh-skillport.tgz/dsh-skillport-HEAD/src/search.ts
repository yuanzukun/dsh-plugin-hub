/**
 * Keyword search over the loaded skill catalog — the prompt-bloat overflow
 * surface. When a user has hundreds of skills, the injected index is capped
 * (`maxIndexEntries`) and `find_skill` becomes the searchable index. Pure TS.
 *
 * @module dsh-skillport/search
 */

/** Searchable skill summary. */
export interface SearchableSkill {
  name: string
  description: string
  whenToUse?: string
  source: string
  provider: string
}

export interface FindSkillResult {
  skill: SearchableSkill
  score: number
}

function tokens(text: string): string[] {
  return text.toLowerCase().split(/[^a-z0-9]+/u).filter((word) => word.length > 1)
}

/** Rank skills by keyword overlap against a free-text query. */
export function findSkill(query: string, skills: SearchableSkill[], limit = 8): FindSkillResult[] {
  const queryTokens = tokens(query)
  if (queryTokens.length === 0) return []
  const results: FindSkillResult[] = []
  for (const skill of skills) {
    const nameTokens = tokens(skill.name)
    const descriptionTokens = tokens(skill.description)
    const whenTokens = skill.whenToUse !== undefined ? tokens(skill.whenToUse) : []
    let score = 0
    for (const token of queryTokens) {
      if (nameTokens.includes(token)) score += 2
      else if (descriptionTokens.includes(token)) score += 1
      else if (whenTokens.includes(token)) score += 0.5
    }
    if (score > 0) results.push({ skill, score })
  }
  return results.sort((a, b) => b.score - a.score).slice(0, limit)
}

/** Render find_skill results as text for the tool result / CLI. */
export function renderFindSkillResults(results: FindSkillResult[]): string {
  if (results.length === 0) return 'No skills matched the query.'
  return results.map(({ skill, score }) => (
    `- ${skill.name} [${skill.provider}/${skill.source}] score=${score}\n  ${skill.description}`
  )).join('\n')
}
