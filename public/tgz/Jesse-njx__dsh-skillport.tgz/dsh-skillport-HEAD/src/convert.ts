/**
 * Tier-2 conversions — adjacent formats mapped best-effort onto skill-style
 * trigger + body. Pure TS; the DSH provider feeds the results to the native
 * skill registry (`ctx.skills.register`), the CLI uses them directly.
 *
 * @module dsh-skillport/convert
 */

import { join } from 'node:path'
import { parse as parseYaml } from 'yaml'
import { nameFromFile, type SkillIo } from './discover.ts'
import type { SkillSpec } from './spec.ts'

/** One converted skill ready to register. */
export interface ConvertedSkill {
  spec: SkillSpec
  /** Source label: `cursor` or `claude-command`. */
  source: 'cursor' | 'claude-command'
  /** Absolute path of the source file. */
  path: string
  /** Directory to resolve relative resources against. */
  directory: string
}

function parseFrontmatter(raw: string): { data: Record<string, unknown>; body: string } | undefined {
  const firstLineEnd = raw.indexOf('\n')
  if (firstLineEnd < 0 || raw.slice(0, firstLineEnd).replace(/\r$/, '') !== '---') {
    return { data: {}, body: raw.trim() }
  }
  let lineStart = firstLineEnd + 1
  while (lineStart <= raw.length) {
    const nextNewline = raw.indexOf('\n', lineStart)
    const lineEnd = nextNewline < 0 ? raw.length : nextNewline
    if (raw.slice(lineStart, lineEnd).replace(/\r$/, '') === '---') {
      let data: unknown
      try {
        data = parseYaml(raw.slice(firstLineEnd + 1, lineStart))
      } catch {
        return undefined
      }
      const record = typeof data === 'object' && data !== null && !Array.isArray(data)
        ? data as Record<string, unknown>
        : {}
      return { data: record, body: nextNewline < 0 ? '' : raw.slice(nextNewline + 1).trim() }
    }
    if (nextNewline < 0) return undefined
    lineStart = nextNewline + 1
  }
  return undefined
}

function stringField(data: Record<string, unknown>, key: string): string | undefined {
  const value = data[key]
  return typeof value === 'string' && value.length > 0 ? value : undefined
}

/**
 * Convert one `.cursor/rules/*.mdc` file into a model-invocable skill.
 * Cursor frontmatter (`description`, `globs`, `alwaysApply`) maps onto the
 * skill's description / whenToUse; the rule body becomes the instructions.
 * Returns undefined when the file has no usable name or description.
 */
export function convertCursorRule(filePath: string, raw: string, warn: (message: string) => void): ConvertedSkill | undefined {
  const name = nameFromFile(filePath)
  if (name === undefined) {
    warn(`cursor rule ${filePath} ignored: could not derive a valid skill name`)
    return undefined
  }
  const parsed = parseFrontmatter(raw)
  if (parsed === undefined) {
    warn(`cursor rule ${filePath} ignored: invalid frontmatter`)
    return undefined
  }
  const description = stringField(parsed.data, 'description')
  if (description === undefined || description.length > 1024) {
    warn(`cursor rule ${filePath} ignored: frontmatter requires a description (<= 1024 chars)`)
    return undefined
  }
  const globs = stringField(parsed.data, 'globs')
  const alwaysApply = parsed.data.alwaysApply === true
  const whenToUse = alwaysApply
    ? 'Applies to all files (alwaysApply).'
    : globs !== undefined
      ? `Applies when files match: ${globs}`
      : undefined
  return {
    spec: {
      name,
      description,
      ...(whenToUse !== undefined ? { whenToUse } : {}),
      invocation: { modelInvocable: true, userInvocable: false },
      content: parsed.body,
    },
    source: 'cursor',
    path: filePath,
    directory: dirnameOf(filePath),
  }
}

/**
 * Convert one `.claude/commands/*.md` file into a user-invokable skill.
 * Claude Code slash-command frontmatter (`description`, `argument-hint`,
 * `allowed-tools`) is accepted; the command body becomes the skill body.
 * Returns undefined when the file has no usable name or description.
 */
export function convertClaudeCommand(filePath: string, raw: string, warn: (message: string) => void): ConvertedSkill | undefined {
  const name = nameFromFile(filePath)
  if (name === undefined) {
    warn(`claude command ${filePath} ignored: could not derive a valid skill name`)
    return undefined
  }
  const parsed = parseFrontmatter(raw)
  if (parsed === undefined) {
    warn(`claude command ${filePath} ignored: invalid frontmatter`)
    return undefined
  }
  const description = stringField(parsed.data, 'description')
  if (description === undefined || description.length > 1024) {
    warn(`claude command ${filePath} ignored: frontmatter requires a description (<= 1024 chars)`)
    return undefined
  }
  const argumentHint = stringField(parsed.data, 'argument-hint')
  const allowedTools = stringField(parsed.data, 'allowed-tools')
  return {
    spec: {
      name,
      description,
      ...(argumentHint !== undefined ? { whenToUse: `User-invoked slash command; optional argument hint: ${argumentHint}` } : {}),
      ...(allowedTools !== undefined ? { allowedTools } : {}),
      invocation: { modelInvocable: false, userInvocable: true },
      content: parsed.body,
    },
    source: 'claude-command',
    path: filePath,
    directory: dirnameOf(filePath),
  }
}

/** Scan `.cursor/rules/*.mdc` under a project root. */
export async function discoverCursorRules(projectRoot: string, io: SkillIo, warn: (message: string) => void): Promise<ConvertedSkill[]> {
  const rulesDir = join(projectRoot, '.cursor', 'rules')
  let entries: Array<{ name: string; isDirectory: boolean }>
  try {
    entries = await io.listDir(rulesDir)
  } catch {
    return []
  }
  const converted: ConvertedSkill[] = []
  for (const entry of entries) {
    if (entry.isDirectory || !entry.name.endsWith('.mdc')) continue
    const filePath = join(rulesDir, entry.name)
    const raw = await readOptional(io, filePath)
    if (raw === undefined) continue
    const skill = convertCursorRule(filePath, raw, warn)
    if (skill !== undefined) converted.push(skill)
  }
  return converted
}

/** Scan `.claude/commands/*.md` under a project root or user home. */
export async function discoverClaudeCommands(root: string, io: SkillIo, warn: (message: string) => void): Promise<ConvertedSkill[]> {
  const commandsDir = join(root, '.claude', 'commands')
  let entries: Array<{ name: string; isDirectory: boolean }>
  try {
    entries = await io.listDir(commandsDir)
  } catch {
    return []
  }
  const converted: ConvertedSkill[] = []
  for (const entry of entries) {
    if (entry.isDirectory || !entry.name.endsWith('.md')) continue
    const filePath = join(commandsDir, entry.name)
    const raw = await readOptional(io, filePath)
    if (raw === undefined) continue
    const skill = convertClaudeCommand(filePath, raw, warn)
    if (skill !== undefined) converted.push(skill)
  }
  return converted
}

async function readOptional(io: SkillIo, path: string): Promise<string | undefined> {
  try {
    return await io.readText(path)
  } catch {
    return undefined
  }
}

function dirnameOf(path: string): string {
  const index = path.lastIndexOf('/')
  return index < 0 ? '.' : path.slice(0, index)
}

/** Context-file candidates (AGENTS.md / CLAUDE.md) for the fallback injector. */
export async function discoverContextFiles(projectRoot: string, io: SkillIo): Promise<Array<{ path: string; content: string }>> {
  const found: Array<{ path: string; content: string }> = []
  for (const name of ['AGENTS.md', 'CLAUDE.md']) {
    const filePath = join(projectRoot, name)
    const content = await readOptional(io, filePath)
    if (content !== undefined) found.push({ path: filePath, content })
  }
  return found
}

/** Re-exported for convenience: names must be valid kebab-case skills. */
export { isValidSkillName } from './spec.ts'
