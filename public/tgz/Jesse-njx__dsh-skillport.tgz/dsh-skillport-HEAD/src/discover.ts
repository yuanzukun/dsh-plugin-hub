/**
 * Skill source discovery: roots for every mainstream skill location, SKILL.md
 * scanning, rank-based dedup with shadow logging. Pure TS — the DSH provider
 * supplies a `SkillIo` backed by `ctx.fs`, the CLI supplies one over node:fs.
 *
 * @module dsh-skillport/discover
 */

import { join, dirname, basename, resolve } from 'node:path'
import { parseSkillSpec, isValidSkillName, type SkillSpec } from './spec.ts'

/** Rank constants (lower wins) — see docs/spec-revision.md. */
export const RANKS = {
  projectDsh: 100,
  projectClaude: 150,
  projectAgents: 200,
  custom: 300,
  userDsh: 400,
  userClaude: 450,
  userAgents: 500,
  userGemini: 550,
  extra: 650,
} as const

/** Source set identifiers from the plugin config (`sources`). */
export type SourceSet = 'dsh' | 'claude' | 'agents' | 'gemini'

/** One discovery root: where to look and how to rank what we find. */
export interface SkillRoot {
  /** The directory to scan for skill entries. */
  path: string
  /** Stable label for diagnostics: which ecosystem this root belongs to. */
  source: string
  /** Precedence rank; lower wins a duplicate name. */
  rank: number
}

/** Filesystem facade the discovery needs (kept minimal + pure). */
export interface SkillIo {
  listDir(path: string): Promise<Array<{ name: string; isDirectory: boolean }>>
  readText(path: string): Promise<string>
}

/** A discovered candidate before registry projection. */
export interface DiscoveredSkill {
  spec: SkillSpec
  /** Absolute path of the SKILL.md (or flat .md) that defined it. */
  path: string
  /** Absolute directory the skill's relative resources resolve against. */
  directory: string
  source: string
  rank: number
}

/** Roots for the DSH-native + Codex sets, honoring user/project split. */
export function nativeRoots(projectRoot: string | undefined, home: string): SkillRoot[] {
  const roots: SkillRoot[] = []
  if (projectRoot !== undefined) {
    roots.push(
      { path: join(projectRoot, '.dsh', 'skills'), source: 'project-dsh', rank: RANKS.projectDsh },
      { path: join(projectRoot, '.agents', 'skills'), source: 'project-agents', rank: RANKS.projectAgents },
    )
  }
  roots.push(
    { path: join(home, '.dsh', 'skills'), source: 'user-dsh', rank: RANKS.userDsh },
    { path: join(home, '.agents', 'skills'), source: 'user-agents', rank: RANKS.userAgents },
  )
  return roots
}

/** Roots for the Claude Code sets (`.claude/skills`). */
export function claudeRoots(projectRoot: string | undefined, home: string): SkillRoot[] {
  const roots: SkillRoot[] = []
  if (projectRoot !== undefined) {
    roots.push({ path: join(projectRoot, '.claude', 'skills'), source: 'project-claude', rank: RANKS.projectClaude })
  }
  roots.push({ path: join(home, '.claude', 'skills'), source: 'user-claude', rank: RANKS.userClaude })
  return roots
}

/** Roots for the Gemini CLI set (`~/.gemini/antigravity/skills`). */
export function geminiRoots(home: string): SkillRoot[] {
  return [{ path: join(home, '.gemini', 'antigravity', 'skills'), source: 'user-gemini', rank: RANKS.userGemini }]
}

/** Roots for configured extra paths (lowest precedence). */
export function extraRoots(extraPaths: string[]): SkillRoot[] {
  return extraPaths.map((path) => ({ path: resolve(path), source: 'extra', rank: RANKS.extra }))
}

/**
 * Compose the full discovery root list for a workspace. `sets` filters which
 * mainstream locations to scan; the native sets (`dsh`, `agents`) are
 * included for the provider's fallback path (when no native filesystem
 * provider is mounted) — the plugin decides that and calls with the narrowed
 * list.
 */
export function rootsFor(sets: SourceSet[], projectRoot: string | undefined, home: string, extraPaths: string[]): SkillRoot[] {
  const roots: SkillRoot[] = []
  if (sets.includes('dsh')) roots.push(...nativeRoots(projectRoot, home).filter((r) => r.source.startsWith('project-dsh') || r.source.startsWith('user-dsh')))
  if (sets.includes('agents')) roots.push(...nativeRoots(projectRoot, home).filter((r) => r.source.startsWith('project-agents') || r.source.startsWith('user-agents')))
  if (sets.includes('claude')) roots.push(...claudeRoots(projectRoot, home))
  if (sets.includes('gemini')) roots.push(...geminiRoots(home))
  roots.push(...extraRoots(extraPaths))
  return roots
}

/** Scan one root directory for skill entries (dir-with-SKILL.md, or flat .md). */
export async function discoverRoot(root: SkillRoot, io: SkillIo, warn: (message: string) => void): Promise<DiscoveredSkill[]> {
  let entries: Array<{ name: string; isDirectory: boolean }>
  try {
    entries = await io.listDir(root.path)
  } catch {
    return [] // absent or unreadable root is not an error
  }
  const skills: DiscoveredSkill[] = []
  for (const entry of entries) {
    if (entry.name === '.system') continue
    const entryPath = join(root.path, entry.name)
    if (entry.isDirectory) {
      const skillPath = join(entryPath, 'SKILL.md')
      const raw = await readOptional(io, skillPath)
      if (raw === undefined) continue
      const parsed = parseOne(raw, skillPath, warn)
      if (parsed === undefined) continue
      skills.push({ spec: parsed, path: skillPath, directory: entryPath, source: root.source, rank: root.rank })
    } else if (entry.name.endsWith('.md')) {
      const raw = await readOptional(io, entryPath)
      if (raw === undefined) continue
      const parsed = parseOne(raw, entryPath, warn)
      if (parsed === undefined) continue
      skills.push({ spec: parsed, path: entryPath, directory: root.path, source: root.source, rank: root.rank })
    }
  }
  return skills
}

async function readOptional(io: SkillIo, path: string): Promise<string | undefined> {
  try {
    return await io.readText(path)
  } catch {
    return undefined
  }
}

function parseOne(raw: string, path: string, warn: (message: string) => void): SkillSpec | undefined {
  try {
    return parseSkillSpec(raw)
  } catch (error) {
    warn(`skill file ${path} ignored: ${error instanceof Error ? error.message : String(error)}`)
    return undefined
  }
}

/**
 * Dedup discovered skills by name across all roots, keeping the lowest rank
 * (lower wins) and first-in-source-order on ties. Shadowed duplicates are
 * reported through `warn`.
 */
export function dedup(skills: DiscoveredSkill[], warn: (message: string) => void): DiscoveredSkill[] {
  const winners = new Map<string, DiscoveredSkill>()
  for (const skill of skills) {
    const existing = winners.get(skill.spec.name)
    if (existing === undefined) {
      winners.set(skill.spec.name, skill)
      continue
    }
    if (skill.rank < existing.rank || (skill.rank === existing.rank && skill.source < existing.source)) {
      warn(`skill "${skill.spec.name}" from ${existing.source} shadowed by ${skill.source} (rank ${skill.rank})`)
      winners.set(skill.spec.name, skill)
    } else {
      warn(`skill "${skill.spec.name}" from ${skill.source} shadowed by ${existing.source} (rank ${existing.rank})`)
    }
  }
  return [...winners.values()].sort((a, b) => a.spec.name.localeCompare(b.spec.name))
}

/** Find the project root by walking up to a `.git` directory. */
export async function findProjectRoot(cwd: string, io: SkillIo): Promise<string> {
  let current = resolve(cwd)
  while (true) {
    const entries = await listOptional(io, current)
    if (entries.some((entry) => entry.name === '.git')) return current
    const parent = dirname(current)
    if (parent === current) return cwd
    current = parent
  }
}

async function listOptional(io: SkillIo, path: string): Promise<Array<{ name: string; isDirectory: boolean }>> {
  try {
    return await io.listDir(path)
  } catch {
    return []
  }
}

/** Validate + normalize a candidate skill name derived from a file (flat .md / command / cursor rule). */
export function nameFromFile(filePath: string): string | undefined {
  const base = basename(filePath, '.md').replace(/\.mdc$/u, '')
  const normalized = base
    .toLowerCase()
    .replace(/\s+/gu, '-')
    .replace(/_+/gu, '-')
    .replace(/[^a-z0-9-]/gu, '')
    .replace(/-+/gu, '-')
    .replace(/^-|-$/gu, '')
  return isValidSkillName(normalized) ? normalized : undefined
}
