/**
 * Skillport skill provider: Agent Skills SKILL.md discovery across every
 * mainstream location (Claude Code, Gemini, extras; plus DSH/Codex fallback
 * when the native filesystem provider is not mounted) plus Tier-2 conversions
 * (cursor rules, claude commands) — registered on `ctx.skills` so the native
 * catalog injection and `skill` tool surface them.
 *
 * @module dsh-skillport/provider
 */

import type { Context } from '@deepseek-ai/cordis'
import type {
  SkillCandidate,
  SkillDefinition,
  SkillLookupOptions,
  SkillProvider,
  SkillProviderControl,
} from '@deepseek-ai/dsh-skill'
import {
  discoverRoot,
  dedup,
  rootsFor,
  findProjectRoot,
  type DiscoveredSkill,
  type SkillIo,
  type SourceSet,
} from './discover.ts'
import {
  discoverCursorRules,
  discoverClaudeCommands,
  convertCursorRule,
  convertClaudeCommand,
  type ConvertedSkill,
} from './convert.ts'
import { parseSkillSpec, SPEC_REVISION } from './spec.ts'

/** Opaque locator handed back to `get()` so it can reload the source file. */
export type SkillLocator =
  | { kind: 'skill'; path: string; directory: string }
  | { kind: 'cursor'; path: string }
  | { kind: 'claude-command'; path: string }

/** Config consumed by the provider (subset of the plugin config). */
export interface SkillportProviderConfig {
  sources: SourceSet[]
  extraPaths: string[]
  /** Convert Tier-2 formats (cursor rules / claude commands). */
  convert: { cursorRules: boolean; claudeCommands: boolean }
  providerName: string
  /** Cap on model-invocable candidates; overflow becomes user-invocable only (find_skill surfaces it). */
  maxIndexEntries: number
}

/** Default ranks for converted Tier-2 skills (between project 200 and custom 300). */
const CURSOR_RANK = 260
const CLAUDE_COMMAND_RANK = 270

/** Wrap a SkillIo implementation for ctx.fs or node fs. */
export function ioFromContext(ctx: Context): SkillIo {
  const fs = ctx.reflect.get('fs') as { resolve(path: string, opts?: { cwd?: string; signal?: AbortSignal }): Promise<unknown>; listDir(target: unknown): Promise<Array<{ name: string; type: string }>>; stat(target: unknown): Promise<{ type: string } | undefined>; readText(target: unknown): Promise<string> } | undefined
  if (fs === undefined) return ioFromNode()
  return {
    async listDir(path) {
      const target = await fs.resolve(path)
      const entries = await fs.listDir(target)
      return entries.map((entry: { name: string; type: string }) => ({ name: entry.name, isDirectory: entry.type === 'directory' }))
    },
    async readText(path) {
      const target = await fs.resolve(path)
      const info = await fs.stat(target)
      if (info === undefined || info.type !== 'file') throw new Error('not a file')
      return await fs.readText(target)
    },
  }
}

/** Node-fs SkillIo for contexts without a filesystem service (tests/CLI). */
export function ioFromNode(): SkillIo {
  return {
    async listDir(path) {
      const { readdir } = await import('node:fs/promises')
      const entries = await readdir(path, { withFileTypes: true })
      return entries.map((entry) => ({ name: entry.name, isDirectory: entry.isDirectory() }))
    },
    async readText(path) {
      const { readFile } = await import('node:fs/promises')
      return await readFile(path, 'utf8')
    },
  }
}

/** The skillport provider instance (registered once per plugin mount). */
export class SkillportProvider implements SkillProvider {
  readonly name: string
  private readonly config: SkillportProviderConfig
  private readonly io: SkillIo
  private readonly home: string
  private readonly warn: (message: string) => void
  private readonly invalidate: () => void
  private readonly skipNativeSets: boolean

  constructor(
    config: SkillportProviderConfig,
    io: SkillIo,
    home: string,
    control: SkillProviderControl,
    warn: (message: string) => void,
    skipNativeSets: boolean,
  ) {
    this.name = config.providerName
    this.config = config
    this.io = io
    this.home = home
    this.warn = warn
    this.invalidate = control.invalidate
    this.skipNativeSets = skipNativeSets
  }

  /** Discovery sets to scan: drop natively-covered sets when the native provider is mounted. */
  private effectiveSets(): SourceSet[] {
    if (!this.skipNativeSets) return this.config.sources
    return this.config.sources.filter((set) => set !== 'dsh' && set !== 'agents')
  }

  async list(options: SkillLookupOptions): Promise<SkillCandidate[]> {
    const cwd = options.cwd
    const projectRoot = cwd !== undefined ? await findProjectRoot(cwd, this.io) : undefined
    const sets = this.effectiveSets()
    const roots = rootsFor(sets, projectRoot, this.home, this.config.extraPaths)

    const discovered: DiscoveredSkill[] = []
    for (const root of roots) {
      discovered.push(...await discoverRoot(root, this.io, this.warn))
    }

    const converted: ConvertedSkill[] = []
    if (projectRoot !== undefined) {
      if (this.config.convert.cursorRules && sets.includes('claude')) {
        converted.push(...await discoverCursorRules(projectRoot, this.io, this.warn))
      }
      if (this.config.convert.claudeCommands && sets.includes('claude')) {
        converted.push(...await discoverClaudeCommands(projectRoot, this.io, this.warn))
      }
    }
    if (this.config.convert.claudeCommands && sets.includes('claude')) {
      converted.push(...await discoverClaudeCommands(this.home, this.io, this.warn))
    }

    const winners = dedup(discovered, this.warn)

    const candidates: SkillCandidate[] = winners.map((skill) => {
      const { spec, path, directory, source, rank } = skill
      return {
        name: spec.name,
        description: spec.description,
        ...(spec.whenToUse !== undefined ? { whenToUse: spec.whenToUse } : {}),
        ...(spec.metadata !== undefined ? { metadata: spec.metadata } : {}),
        invocation: spec.invocation,
        source,
        provider: this.name,
        rank,
        locator: { kind: 'skill', path, directory } satisfies SkillLocator,
        resourceBase: { kind: 'directory', path: directory } as const,
        path,
      }
    })

    for (const skill of converted) {
      const rank = skill.source === 'cursor' ? CURSOR_RANK : CLAUDE_COMMAND_RANK
      const locator: SkillLocator = skill.source === 'cursor'
        ? { kind: 'cursor', path: skill.path }
        : { kind: 'claude-command', path: skill.path }
      candidates.push({
        name: skill.spec.name,
        description: skill.spec.description,
        ...(skill.spec.whenToUse !== undefined ? { whenToUse: skill.spec.whenToUse } : {}),
        ...(skill.spec.allowedTools !== undefined ? { metadata: { 'allowed-tools': skill.spec.allowedTools } } : {}),
        invocation: skill.spec.invocation,
        source: skill.source,
        provider: this.name,
        rank,
        locator,
        resourceBase: { kind: 'directory', path: skill.directory } as const,
        path: skill.path,
      })
    }

    return this.applyIndexCap(candidates)
  }

  /**
   * Prompt-bloat cap: keep at most `maxIndexEntries` model-invocable
   * candidates in the injected model index; overflow becomes user-invocable
   * only, so it never bloats the catalog while `find_skill` (which reads the
   * invocation-neutral registry) still surfaces + loads it.
   */
  private applyIndexCap(candidates: SkillCandidate[]): SkillCandidate[] {
    const max = this.config.maxIndexEntries
    if (max <= 0) return candidates
    const modelInvocable = candidates.filter((c) => c.invocation.modelInvocable).sort((a, b) => a.name.localeCompare(b.name))
    const overflow = modelInvocable.slice(max)
    if (overflow.length === 0) return candidates
    const overflowNames = new Set(overflow.map((c) => c.name))
    return candidates.map((c) => (
      overflowNames.has(c.name)
        ? { ...c, invocation: { modelInvocable: false, userInvocable: true } }
        : c
    ))
  }

  async get(candidate: SkillCandidate, _options: SkillLookupOptions): Promise<SkillDefinition | undefined> {
    const locator = candidate.locator as SkillLocator
    if (locator.kind === 'skill') {
      const raw = await this.io.readText(locator.path).catch(() => undefined)
      if (raw === undefined) return undefined
      let spec
      try {
        spec = parseSkillSpec(raw)
      } catch {
        return undefined
      }
      if (spec.name !== candidate.name) return undefined
      return {
        name: spec.name,
        description: spec.description,
        ...(spec.whenToUse !== undefined ? { whenToUse: spec.whenToUse } : {}),
        ...(spec.metadata !== undefined ? { metadata: spec.metadata } : {}),
        invocation: spec.invocation,
        source: candidate.source,
        provider: this.name,
        resourceBase: { kind: 'directory', path: locator.directory },
        path: locator.path,
        content: spec.content,
      }
    }
    // Converted skills: reload + reconvert so body edits are picked up.
    const raw = await this.io.readText(locator.path).catch(() => undefined)
    if (raw === undefined) return undefined
    const converted = locator.kind === 'cursor'
      ? convertCursorRule(locator.path, raw, this.warn)
      : convertClaudeCommand(locator.path, raw, this.warn)
    if (converted === undefined || converted.spec.name !== candidate.name) return undefined
    return {
      name: converted.spec.name,
      description: converted.spec.description,
      ...(converted.spec.whenToUse !== undefined ? { whenToUse: converted.spec.whenToUse } : {}),
      invocation: converted.spec.invocation,
      source: converted.source,
      provider: this.name,
      resourceBase: { kind: 'directory', path: converted.directory },
      path: converted.path,
      content: converted.spec.content,
    }
  }

  /** Invalidate catalog caches when a model-facing write/edit touches any path. */
  observeHostMutation(): void {
    this.invalidate()
  }
}

/** Spec revision marker surfaced for diagnostics. */
export const SKILLPORT_SPEC_REVISION = SPEC_REVISION
