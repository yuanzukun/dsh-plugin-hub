/**
 * `/skills doctor` — the human-facing doctor for skill trigger quality.
 * Lists loaded skills by source and test-fires descriptions against the
 * catalog, turning a fuzzy trigger mismatch into a ranked, debuggable list.
 * Registered only when a commands service is present.
 *
 * @module dsh-skillport/skills-command
 */

import type { Context } from '@deepseek-ai/cordis'
import type { CommandInvocation, CommandResult } from '@deepseek-ai/dsh-commands'
import type {} from '@deepseek-ai/dsh-skill'
import { testFire, renderTestFire, renderDoctorList, type DoctorSkill } from './doctor.ts'

/** Collect the agent-visible skill summaries as doctor entries. */
async function collect(ctx: Context, invocation: CommandInvocation): Promise<DoctorSkill[]> {
  const lookup = {
    cwd: invocation.agent.session.header.cwd,
    scope: invocation.agent,
    signal: invocation.signal,
  }
  const summaries = await ctx.skills.list(lookup)
  return summaries.map((skill) => ({
    name: skill.name,
    description: skill.description,
    whenToUse: skill.whenToUse,
    source: skill.source,
    provider: skill.provider,
    path: (skill as { path?: string }).path,
  }))
}

/** Register the /skills doctor command (no-op when commands service is absent). */
export function applySkillsDoctorCommand(ctx: Context, warn: (message: string) => void): void {
  const commands = ctx.reflect.get('commands')
  if (commands === undefined) {
    warn('commands service absent — /skills doctor command not registered')
    return
  }
  commands.register({
    name: 'skills',
    description: 'List loaded skills or test-fire a description against the skill catalog.',
    input: { hint: 'doctor [<description>] | list' },
    async handler(invocation: CommandInvocation): Promise<CommandResult> {
      const raw = invocation.rawInput.trim()
      const rest = raw.replace(/^doctor\b/u, '').trim()
      const skills = await collect(ctx, invocation)
      if (raw === '' || raw === 'list') {
        return { kind: 'success', text: renderDoctorList(skills) }
      }
      if (rest !== '') {
        const matches = testFire(rest, skills)
        return { kind: 'success', text: renderTestFire(rest, matches) }
      }
      return { kind: 'success', text: renderDoctorList(skills) }
    },
  })
}
