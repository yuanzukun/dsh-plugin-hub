/**
 * End-to-end plugin tests: real Cordis + SkillRegistry + SystemPrompt +
 * ToolRuntime + LocalFileSystem, with @dsh-skillport/bundle mounted. Verifies
 * discovery through ctx.skills, dedup precedence, converted Tier-2 skills,
 * the find_skill tool, the /skills doctor command, and clean unload.
 */

import { test, beforeEach, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { Context } from '@deepseek-ai/cordis'
import SkillRegistry from '@deepseek-ai/dsh-skill'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import { LocalFileSystem } from '@deepseek-ai/dsh-fs-local'
import { CallId } from '@deepseek-ai/dsh-llm'
import { mkdtempSync, rmSync, cpSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import * as Skillport from '../src/index.ts'

const fixtures = join(dirname(fileURLToPath(import.meta.url)), 'fixtures')
const signal = new AbortController().signal

let dir: string
let ctx: Context

beforeEach(async () => {
  dir = mkdtempSync(join(tmpdir(), 'dsh-skillport-test-'))
  // Project tree with .git marker so project-root discovery engages.
  mkdirSync(join(dir, 'project', '.git'), { recursive: true })
  cpSync(join(fixtures, 'project'), join(dir, 'project'), { recursive: true })
  mkdirSync(join(dir, 'home'))
  cpSync(join(fixtures, 'home'), join(dir, 'home'), { recursive: true })
  mkdirSync(join(dir, 'extra'))
  cpSync(join(fixtures, 'extra'), join(dir, 'extra'), { recursive: true })

  ctx = new Context()
  await ctx.plugin(SkillRegistry)
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(LocalFileSystem, { cwd: join(dir, 'project') })
  await ctx.plugin(Skillport, {
    sources: ['dsh', 'claude', 'agents', 'gemini'],
    extraPaths: [join(dir, 'extra')],
    home: join(dir, 'home'),
    convert: { cursorRules: true, contextFiles: true, claudeCommands: true },
  })
})

afterEach(async () => {
  rmSync(dir, { recursive: true, force: true })
})

function cwd(): string {
  return join(dir, 'project')
}

test('discovers skills from every mainstream source through ctx.skills', async () => {
  const listed = await ctx.skills.list({ cwd: cwd() })
  const names = listed.map((s) => `${s.name}@${s.source}`).sort()
  // .dsh/.agents are NOT double-scanned here: the native filesystem provider
  // is absent in this composition, so skillport scans them (fallback) — the
  // check-first behavior is covered by the provider-detection unit path.
  assert.ok(names.includes('deploy@project-dsh'), `names: ${names.join(', ')}`)
  assert.ok(names.includes('commit-helper@project-claude'))
  assert.ok(names.includes('code-review@project-agents'))
  assert.ok(names.includes('summarize@user-gemini'))
  assert.ok(names.includes('custom-skill@extra'))
  assert.ok(names.includes('user-skill@user-claude'))
})

test('loads a full skill body with directory resourceBase', async () => {
  const skill = await ctx.skills.get('deploy', { cwd: cwd() })
  assert.ok(skill !== undefined)
  assert.equal(skill.name, 'deploy')
  assert.ok(skill.content.includes('scripts/deploy.sh'))
  assert.deepEqual(skill.resourceBase, { kind: 'directory', path: join(dir, 'project', '.dsh', 'skills', 'deploy') })
})

test('converted Tier-2 skills are registered (cursor + claude command)', async () => {
  const listed = await ctx.skills.list({ cwd: cwd() })
  const byName = new Map(listed.map((s) => [s.name, s]))
  const cursor = byName.get('typescript')
  assert.ok(cursor !== undefined, 'cursor rule converted to a skill')
  assert.equal(cursor.source, 'cursor')
  const command = byName.get('review')
  assert.ok(command !== undefined, 'claude command converted to a skill')
  assert.equal(command.source, 'claude-command')
  assert.deepEqual(command.invocation, { modelInvocable: false, userInvocable: true })
  // User-invokable-only skills are loadable through the registry.
  const loaded = await ctx.skills.get('review', { cwd: cwd() })
  assert.ok(loaded !== undefined)
  assert.ok(loaded.content.includes('careful review'))
})

test('dedup: DSH-native wins a same-name clash at lower rank', async () => {
  // Create a clashing skill in .claude (rank 150) and .dsh (rank 100).
  const claudeDir = join(dir, 'project', '.claude', 'skills', 'deploy')
  mkdirSync(claudeDir, { recursive: true })
  const { writeFileSync } = await import('node:fs')
  writeFileSync(join(claudeDir, 'SKILL.md'), '---\nname: deploy\ndescription: Claude version of deploy.\n---\n\nClaude body.')
  const listed = await ctx.skills.list({ cwd: cwd() })
  const deploy = listed.find((s) => s.name === 'deploy')
  assert.equal(deploy!.source, 'project-dsh')
  const loaded = await ctx.skills.get('deploy', { cwd: cwd() })
  assert.ok(loaded!.content.includes('scripts/deploy.sh'), 'dsh body wins over the claude clash')
})

let callCounter = 0
async function callTool(name: string, args: Record<string, unknown>) {
  return await ctx.tools.execute({
    signal,
    callId: CallId(`call-${++callCounter}`),
    name,
    arguments: args,
    agent: { session: { id: 's-test', header: { cwd: cwd() }, events: [] } } as never,
  })
}

test('find_skill tool searches the catalog and loads by name', async () => {
  const result = await callTool('find_skill', { query: 'deploy' })
  assert.equal(result.isError, false, textOf(result))
  const t = textOf(result)
  assert.ok(t.includes('deploy'), t)

  const loaded = await callTool('find_skill', { name: 'deploy' })
  assert.equal(loaded.isError, false, textOf(loaded))
  const lt = textOf(loaded)
  assert.ok(lt.includes('scripts/deploy.sh'), lt)
})

test('find_skill reports an unknown name', async () => {
  const result = await callTool('find_skill', { name: 'does-not-exist' })
  assert.equal(result.isError, false)
  assert.ok(textOf(result).includes('unknown or no longer available'))
})

test('maxIndexEntries caps model-invocable candidates; overflow stays user-invocable', async () => {
  const { writeFileSync } = await import('node:fs')
  for (let i = 0; i < 5; i++) {
    const skillDir = join(dir, 'extra', `bulk-skill-${i}`)
    mkdirSync(skillDir, { recursive: true })
    writeFileSync(join(skillDir, 'SKILL.md'), `---\nname: bulk-skill-${i}\ndescription: Bulk skill number ${i}.\n---\n\nBody ${i}.`)
  }
  // Fresh context with a tiny cap.
  const capped = new Context()
  await capped.plugin(SkillRegistry)
  await capped.plugin(SystemPrompt)
  await capped.plugin(ToolRuntime)
  await capped.plugin(LocalFileSystem, { cwd: join(dir, 'project') })
  await capped.plugin(Skillport, {
    sources: ['claude'],
    extraPaths: [join(dir, 'extra')],
    home: join(dir, 'home'),
    maxIndexEntries: 2,
  })
  const listed = await capped.skills.list({ cwd: cwd() })
  const modelInvocable = listed.filter((s) => s.invocation.modelInvocable)
  const userOnly = listed.filter((s) => !s.invocation.modelInvocable && s.invocation.userInvocable)
  assert.equal(modelInvocable.length, 2, `model-invocable capped to 2, got ${modelInvocable.length}`)
  assert.ok(userOnly.length >= 3, `overflow demoted to user-invocable, got ${userOnly.length}`)
})

test('disable-plugin unloads every imported skill (Cordis effects)', async () => {
  const before = await ctx.skills.list({ cwd: cwd() })
  assert.ok(before.length > 0)
  // Dispose the plugin fiber: registry providers + tools + commands all unload.
  const runtime = ctx.registry.get(Skillport)
  assert.ok(runtime !== undefined)
  for (const fiber of runtime.fibers) await fiber.dispose()
  const after = await ctx.skills.list({ cwd: cwd() })
  assert.equal(after.length, 0, `no skills after unload, got ${after.length}`)
  // The find_skill tool is gone too.
  const names = ctx.tools.schemas().map((s) => s.name)
  assert.ok(!names.includes('find_skill'), 'find_skill tool unregistered')
})

function textOf(result: { content: Array<{ type: string; text?: string }> }): string {
  return result.content.filter((b) => b.type === 'text').map((b) => b.text ?? '').join('')
}
