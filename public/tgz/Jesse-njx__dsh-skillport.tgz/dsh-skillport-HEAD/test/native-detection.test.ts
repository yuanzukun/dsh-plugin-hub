/**
 * Check-first behavior: when the native @deepseek-ai/dsh-skill-filesystem
 * provider is mounted (standard/code presets), skillport must NOT re-scan the
 * dsh/agents sets (no double-injection). When it is absent, skillport scans
 * them itself so the full discovery table holds in any composition.
 */

import { test, beforeEach, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { Context } from '@deepseek-ai/cordis'
import SkillRegistry from '@deepseek-ai/dsh-skill'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import { LocalFileSystem } from '@deepseek-ai/dsh-fs-local'
import { mkdtempSync, rmSync, cpSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import * as Skillport from '../src/index.ts'
import * as NativeSkillFilesystem from '@deepseek-ai/dsh-skill-filesystem'

const fixtures = join(dirname(fileURLToPath(import.meta.url)), 'fixtures')

let dir: string

beforeEach(async () => {
  dir = mkdtempSync(join(tmpdir(), 'dsh-skillport-native-'))
  mkdirSync(join(dir, 'project', '.git'), { recursive: true })
  cpSync(join(fixtures, 'project'), join(dir, 'project'), { recursive: true })
  mkdirSync(join(dir, 'home'))
  cpSync(join(fixtures, 'home'), join(dir, 'home'), { recursive: true })
  mkdirSync(join(dir, 'extra'))
  cpSync(join(fixtures, 'extra'), join(dir, 'extra'), { recursive: true })
})

afterEach(async () => {
  rmSync(dir, { recursive: true, force: true })
})

test('with the native provider mounted, dsh/agents are not double-scanned', async () => {
  const ctx = new Context()
  await ctx.plugin(SkillRegistry)
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(LocalFileSystem, { cwd: join(dir, 'project') })
  // Native provider is mounted under the same registry layer.
  await ctx.plugin(NativeSkillFilesystem, { dshHome: join(dir, 'home'), agentsHome: join(dir, 'home') })
  await ctx.plugin(Skillport, {
    sources: ['dsh', 'claude', 'agents', 'gemini'],
    extraPaths: [join(dir, 'extra')],
    home: join(dir, 'home'),
  })

  const listed = await ctx.skills.list({ cwd: join(dir, 'project') })
  const names = listed.map((s) => `${s.name}@${s.source}`).sort()
  // dsh/agents skills come from the NATIVE provider only — skillport must not
  // re-scan them, so each name appears exactly once.
  assert.ok(names.includes('deploy@project-dsh'), names.join(', '))
  assert.ok(names.includes('code-review@project-agents'), names.join(', '))
  assert.equal(names.filter((n) => n.startsWith('deploy@')).length, 1, 'no duplicate deploy')
  assert.equal(names.filter((n) => n.startsWith('code-review@')).length, 1, 'no duplicate code-review')
  // Skillport's own sources are still present.
  assert.ok(names.includes('commit-helper@project-claude'), names.join(', '))
  assert.ok(names.includes('summarize@user-gemini'), names.join(', '))
  assert.ok(names.includes('custom-skill@extra'), names.join(', '))
})

test('without the native provider, skillport scans dsh/agents itself (fallback)', async () => {
  const ctx = new Context()
  await ctx.plugin(SkillRegistry)
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(LocalFileSystem, { cwd: join(dir, 'project') })
  await ctx.plugin(Skillport, {
    sources: ['dsh', 'claude', 'agents', 'gemini'],
    extraPaths: [join(dir, 'extra')],
    home: join(dir, 'home'),
  })

  const listed = await ctx.skills.list({ cwd: join(dir, 'project') })
  const names = listed.map((s) => `${s.name}@${s.source}`).sort()
  assert.ok(names.includes('deploy@project-dsh'), names.join(', '))
  assert.ok(names.includes('code-review@project-agents'), names.join(', '))
  assert.ok(names.includes('commit-helper@project-claude'), names.join(', '))
  assert.ok(names.includes('summarize@user-gemini'), names.join(', '))
  assert.ok(names.includes('custom-skill@extra'), names.join(', '))
})
