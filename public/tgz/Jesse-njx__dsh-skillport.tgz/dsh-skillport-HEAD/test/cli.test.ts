/**
 * skills-doctor CLI: standalone scan of the discovery roots (no DSH session).
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const bin = join(here, '..', 'src', 'bin', 'skills-doctor.ts')
const fixtures = join(here, 'fixtures')
const project = join(fixtures, 'project')
const home = join(fixtures, 'home')
const extra = join(fixtures, 'extra')

function run(args: string[]): { stdout: string; code: number } {
  try {
    const stdout = execFileSync(process.execPath, [bin, ...args], { encoding: 'utf8' })
    return { stdout, code: 0 }
  } catch (error) {
    const e = error as { stdout?: string; status?: number }
    return { stdout: e.stdout ?? '', code: e.status ?? 1 }
  }
}

test('list scans every source and groups by origin', () => {
  const { stdout, code } = run(['--cwd', project, '--home', home, '--extra', extra, 'list'])
  assert.equal(code, 0)
  assert.ok(stdout.includes('## project-dsh (1)'), stdout)
  assert.ok(stdout.includes('- deploy — Deploy the application'))
  assert.ok(stdout.includes('## user-gemini (1)'), stdout)
  assert.ok(stdout.includes('- summarize — Summarize long documents'))
  assert.ok(stdout.includes('## extra (1)'), stdout)
  assert.ok(stdout.includes('- custom-skill — A skill from a user-configured extra path.'))
})

test('test-fire ranks matching skills', () => {
  const { stdout, code } = run(['--cwd', project, '--home', home, '--extra', extra, 'test-fire', 'deploy the application to production'])
  assert.equal(code, 0)
  assert.ok(stdout.includes('deploy'), stdout)
  assert.ok(stdout.includes('score='), stdout)
})

test('test-fire with no matches is honest about it', () => {
  const { stdout, code } = run(['--cwd', project, '--home', home, '--extra', extra, 'test-fire', 'quantum chromodynamics lattice gauge theory'])
  assert.equal(code, 0)
  assert.ok(stdout.includes('No loaded skill description matched'))
})

test('list on an empty tree reports no skills', () => {
  const { stdout, code } = run(['--cwd', fixtures, '--home', join(fixtures, 'nonexistent-home'), 'list'])
  assert.equal(code, 0)
  assert.ok(stdout.includes('No skills are loaded.'))
})
