/**
 * /skills doctor command tests: registers through the commands service and
 * lists/test-fires the catalog.
 */

import { test, beforeEach, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { Context } from '@deepseek-ai/cordis'
import SkillRegistry from '@deepseek-ai/dsh-skill'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import CommandRuntime from '@deepseek-ai/dsh-commands'
import { LocalFileSystem } from '@deepseek-ai/dsh-fs-local'
import { mkdtempSync, rmSync, cpSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import * as Skillport from '../src/index.ts'

const fixtures = join(dirname(fileURLToPath(import.meta.url)), 'fixtures')

let dir: string
let ctx: Context

beforeEach(async () => {
  dir = mkdtempSync(join(tmpdir(), 'dsh-skillport-cmd-'))
  mkdirSync(join(dir, 'project', '.git'), { recursive: true })
  cpSync(join(fixtures, 'project'), join(dir, 'project'), { recursive: true })
  mkdirSync(join(dir, 'home'))
  cpSync(join(fixtures, 'home'), join(dir, 'home'), { recursive: true })
  mkdirSync(join(dir, 'extra'))
  cpSync(join(fixtures, 'extra'), join(dir, 'extra'), { recursive: true })

  ctx = new Context()
  await ctx.plugin(SkillRegistry)
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(CommandRuntime)
  await ctx.plugin(LocalFileSystem, { cwd: join(dir, 'project') })
  await ctx.plugin(Skillport, {
    sources: ['dsh', 'claude', 'agents', 'gemini'],
    extraPaths: [join(dir, 'extra')],
    home: join(dir, 'home'),
  })
})

afterEach(async () => {
  rmSync(dir, { recursive: true, force: true })
})

function agent(): never {
  return {
    session: {
      id: 's-cmd',
      header: { cwd: join(dir, 'project') },
      events: [],
      append: () => Promise.resolve(),
    },
  } as never
}

test('/skills doctor command is registered', () => {
  const command = ctx.commands.find(agent(), 'skills')
  assert.ok(command !== undefined)
  assert.ok(command.description.includes('test-fire'))
})

test('/skills lists loaded skills grouped by source', async () => {
  const result = await ctx.commands.execute(agent(), '/skills', new AbortController().signal)
  assert.ok(result !== undefined)
  assert.equal(result.result.kind, 'success')
  const text = result.result.kind === 'success' ? result.result.text ?? '' : ''
  assert.ok(text.includes('## project-dsh (1)'), text)
  assert.ok(text.includes('- deploy — Deploy the application'))
  assert.ok(text.includes('## user-gemini (1)'), text)
})

test('/skills doctor test-fire ranks matching skills', async () => {
  const result = await ctx.commands.execute(agent(), '/skills doctor deploy the app to production', new AbortController().signal)
  assert.ok(result !== undefined)
  assert.equal(result.result.kind, 'success')
  const text = result.result.kind === 'success' ? result.result.text ?? '' : ''
  assert.ok(text.includes('deploy'), text)
  assert.ok(text.includes('score='), text)
})
