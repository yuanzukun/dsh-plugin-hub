/**
 * Golden tests: the injected index (what the catalog shows the model) and the
 * doctor report must match checked-in goldens. This is the spec's "goldens for
 * the injected index" — a change to discovery/precedence/description handling
 * that alters the model-facing index fails loudly here.
 */

import { test, before } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, mkdirSync } from 'node:fs'
import { readFile, readdir } from 'node:fs/promises'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { rootsFor, discoverRoot, dedup, findProjectRoot, type SkillIo, type DiscoveredSkill } from '../src/discover.ts'
import { discoverCursorRules } from '../src/convert.ts'
import { renderDoctorList, type DoctorSkill } from '../src/doctor.ts'

const fixtures = join(dirname(fileURLToPath(import.meta.url)), 'fixtures')
const project = join(fixtures, 'project')
const home = join(fixtures, 'home')
const extra = join(fixtures, 'extra')
const goldens = join(fixtures, 'goldens')

// A `.git` directory is the project-root marker, but git itself does not track
// nested `.git` directories — recreate it at test runtime so the fixture tree
// works from a fresh clone.
before(() => {
  mkdirSync(join(project, '.git'), { recursive: true })
})

const io: SkillIo = {
  async listDir(path) {
    const entries = await readdir(path, { withFileTypes: true })
    return entries.map((entry) => ({ name: entry.name, isDirectory: entry.isDirectory() }))
  },
  async readText(path) {
    return await readFile(path, 'utf8')
  },
}

/** The model-facing index: name + description lines for model-invocable winners. */
function renderIndex(skills: DiscoveredSkill[]): string {
  return skills
    .filter((s) => s.spec.invocation.modelInvocable)
    .sort((a, b) => a.spec.name.localeCompare(b.spec.name))
    .map((s) => `- ${s.spec.name}: ${s.spec.description}`)
    .join('\n') + '\n'
}

test('injected index matches the golden', async () => {
  const projectRoot = await findProjectRoot(project, io)
  const roots = rootsFor(['dsh', 'claude', 'agents', 'gemini'], projectRoot, home, [extra])
  const all = []
  for (const root of roots) all.push(...await discoverRoot(root, io, () => {}))
  all.push(...await discoverCursorRules(projectRoot, io, () => {}))
  const winners = dedup(all, () => {})
  const index = renderIndex(winners)
  const golden = readFileSync(join(goldens, 'injected-index.txt'), 'utf8')
  assert.equal(index, golden)
})

test('doctor report matches the golden', async () => {
  const projectRoot = await findProjectRoot(project, io)
  const roots = rootsFor(['dsh', 'claude', 'agents', 'gemini'], projectRoot, home, [extra])
  const all = []
  for (const root of roots) all.push(...await discoverRoot(root, io, () => {}))
  const winners = dedup(all, () => {})
  const doctorSkills: DoctorSkill[] = winners.map((s) => ({
    name: s.spec.name,
    description: s.spec.description,
    whenToUse: s.spec.whenToUse,
    source: s.source,
    provider: 'filesystem',
    path: s.path,
  }))
  const report = renderDoctorList(doctorSkills) + '\n'
  const golden = readFileSync(join(goldens, 'doctor-report.txt'), 'utf8')
  assert.equal(report, golden)
})

test('golden files exist and are non-empty', () => {
  for (const name of ['injected-index.txt', 'doctor-report.txt']) {
    const content = readFileSync(join(goldens, name), 'utf8')
    assert.ok(content.trim().length > 0, `${name} golden is non-empty`)
  }
})
