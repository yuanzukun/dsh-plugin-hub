/**
 * Agent Skills spec conformance: frontmatter edge cases from the pinned spec
 * revision — missing fields, unicode names, invalid grammar, nested resources.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { parseSkillSpec, isValidSkillName, splitFrontmatter, SkillSpecError } from '../src/spec.ts'

const conformance = join(dirname(fileURLToPath(import.meta.url)), 'fixtures', 'conformance')

function skillDir(name: string): string {
  return join(conformance, name)
}

test('accepts a minimal valid skill', () => {
  const spec = parseSkillSpec('---\nname: pdf-processing\ndescription: Extract PDF text.\n---\n\nBody.')
  assert.equal(spec.name, 'pdf-processing')
  assert.equal(spec.description, 'Extract PDF text.')
  assert.equal(spec.content, 'Body.')
  assert.deepEqual(spec.invocation, { modelInvocable: true, userInvocable: true })
})

test('parses every optional spec field', () => {
  const spec = parseSkillSpec(readFileSync(join(skillDir('full-fields'), 'SKILL.md'), 'utf8'))
  assert.equal(spec.name, 'full-fields')
  assert.equal(spec.license, 'Apache-2.0')
  assert.equal(spec.compatibility, 'Requires Python 3.14+ and uv')
  assert.deepEqual(spec.metadata, { author: 'example-org', version: '1.0' })
  assert.equal(spec.allowedTools, 'Bash(git:*) Read')
  assert.ok(spec.content.includes('Full field body'))
})

test('rejects a skill missing its description', () => {
  const raw = readFileSync(join(skillDir('missing-description'), 'SKILL.md'), 'utf8')
  assert.throws(() => parseSkillSpec(raw), SkillSpecError)
})

test('rejects uppercase names', () => {
  const raw = readFileSync(join(skillDir('uppercase-name'), 'SKILL.md'), 'utf8')
  assert.throws(() => parseSkillSpec(raw), SkillSpecError)
})

test('rejects consecutive hyphens', () => {
  const raw = readFileSync(join(skillDir('consecutive-hyphens'), 'SKILL.md'), 'utf8')
  assert.throws(() => parseSkillSpec(raw), SkillSpecError)
})

test('rejects a leading hyphen', () => {
  const raw = readFileSync(join(skillDir('leading-hyphen'), 'SKILL.md'), 'utf8')
  assert.throws(() => parseSkillSpec(raw), SkillSpecError)
})

test('rejects a name longer than 64 chars', () => {
  const raw = readFileSync(join(skillDir('long-name'), 'SKILL.md'), 'utf8')
  assert.throws(() => parseSkillSpec(raw), SkillSpecError)
})

test('rejects unicode names (a-z0-9 + hyphens only per pinned spec)', () => {
  const raw = readFileSync(join(skillDir('unicode-name'), 'SKILL.md'), 'utf8')
  assert.throws(() => parseSkillSpec(raw), SkillSpecError)
})

test('rejects a file with no frontmatter', () => {
  const raw = readFileSync(join(skillDir('no-frontmatter'), 'SKILL.md'), 'utf8')
  assert.throws(() => parseSkillSpec(raw), SkillSpecError)
})

test('rejects invalid YAML in frontmatter', () => {
  const raw = readFileSync(join(skillDir('invalid-yaml'), 'SKILL.md'), 'utf8')
  assert.throws(() => parseSkillSpec(raw), SkillSpecError)
})

test('nested resources stay as relative references in the body', () => {
  const spec = parseSkillSpec(readFileSync(join(skillDir('nested-resources'), 'SKILL.md'), 'utf8'))
  assert.ok(spec.content.includes('scripts/run.sh'))
  assert.ok(spec.content.includes('references/REFERENCE.md'))
  assert.ok(spec.content.includes('assets/template.txt'))
  for (const rel of ['scripts/run.sh', 'references/REFERENCE.md', 'assets/template.txt']) {
    const full = join(skillDir('nested-resources'), rel)
    assert.ok(statSync(full).isFile(), `${rel} exists as a bundled resource`)
  }
})

test('name grammar matches the spec (valid + invalid samples)', () => {
  for (const valid of ['pdf-processing', 'data-analysis', 'code-review', 'a', 'a1-b2']) {
    assert.ok(isValidSkillName(valid), `${valid} is valid`)
  }
  for (const invalid of ['PDF-Processing', '-pdf', 'pdf-', 'pdf--processing', '', 'a'.repeat(65), '数据科学']) {
    assert.ok(!isValidSkillName(invalid), `${invalid} is invalid`)
  }
})

test('splitFrontmatter handles CRLF and missing fences', () => {
  const split = splitFrontmatter('---\r\nname: x\r\ndescription: y\r\n---\r\n\r\nBody')
  assert.ok(split !== undefined)
  assert.ok(split.data.includes('name: x'))
  assert.ok(split.body.includes('Body'))
  assert.equal(splitFrontmatter('no fence at all'), undefined)
})

test('flat .md skills are accepted (DSH-native extension)', () => {
  const raw = readFileSync(join(conformance, 'flat-skill.md'), 'utf8')
  const spec = parseSkillSpec(raw)
  assert.equal(spec.name, 'flat-skill')
  assert.equal(spec.content, 'Flat body.')
})

test('frontmatter flags map to invocation policy', () => {
  const disabled = parseSkillSpec('---\nname: x\ndescription: y\ndisable-model-invocation: true\n---\n')
  assert.deepEqual(disabled.invocation, { modelInvocable: false, userInvocable: true })
  const userOnly = parseSkillSpec('---\nname: x\ndescription: y\nuser-invocable: false\n---\n')
  assert.deepEqual(userOnly.invocation, { modelInvocable: true, userInvocable: false })
})

test('fixture dirs are all present for the conformance suite', () => {
  const expected = [
    'missing-description', 'uppercase-name', 'consecutive-hyphens', 'leading-hyphen',
    'long-name', 'unicode-name', 'full-fields', 'nested-resources', 'no-frontmatter',
    'invalid-yaml', 'flat-skill.md',
  ]
  for (const name of expected) {
    assert.ok(readdirSync(conformance).includes(name), `${name} fixture exists`)
  }
})
