---
name: pdf--processing
description: Consecutive hyphens are invalid per the spec.
---
