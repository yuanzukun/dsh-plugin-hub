# No frontmatter at all

This file has no YAML frontmatter and must be rejected.
