---
name: flat-skill
description: A flat .md skill (DSH-native extension) at the root of a skills dir.
---

Flat body.
