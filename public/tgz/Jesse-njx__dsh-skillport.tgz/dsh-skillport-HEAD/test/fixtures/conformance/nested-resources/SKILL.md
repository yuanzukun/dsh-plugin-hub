---
name: nested-resources
description: Skill referencing bundled resources at several depths.
---

See [scripts/run.sh](scripts/run.sh), [references/REFERENCE.md](references/REFERENCE.md), and [assets/template.txt](assets/template.txt).
