---
name: missing-description
---
No description field — must be rejected.
