---
name: user-skill
description: A user-level skill from Claude Code's global directory.
---

# User skill

Global skill body.
