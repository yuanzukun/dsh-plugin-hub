---
name: summarize
description: Summarize long documents into concise bullet points. Use when the user asks for a summary.
---

# Summarize

Read the full text, then produce a bullet summary under 10 lines.
