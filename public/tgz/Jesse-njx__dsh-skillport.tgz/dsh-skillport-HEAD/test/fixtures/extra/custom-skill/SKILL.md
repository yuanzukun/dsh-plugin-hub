---
name: custom-skill
description: A skill from a user-configured extra path.
---

# Custom skill

Extra path body.
