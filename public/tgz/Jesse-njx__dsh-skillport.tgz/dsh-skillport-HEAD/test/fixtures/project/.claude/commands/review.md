---
description: Review the current changes
argument-hint: [optional PR number]
---

Run a careful review of the current diff and summarize findings.
