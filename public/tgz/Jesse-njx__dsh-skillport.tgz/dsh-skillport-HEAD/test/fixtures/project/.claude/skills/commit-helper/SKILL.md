---
name: commit-helper
description: Craft conventional-commit messages from staged changes. Use when writing a git commit.
license: MIT
metadata:
  author: skillport-fixtures
  version: "1.0"
---

# Commit helper

Inspect `git diff --cached` and write a conventional commit.
