---
name: code-review
description: Review a pull request for correctness, style, and security. Use when asked to review code.
---

# Code review

Read the diff, check for bugs, suggest improvements.
