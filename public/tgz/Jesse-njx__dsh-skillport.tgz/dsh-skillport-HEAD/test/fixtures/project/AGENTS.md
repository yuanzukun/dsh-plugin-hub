# Project conventions

Use pnpm. Run tests with `pnpm test`.
