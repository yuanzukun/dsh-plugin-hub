/**
 * Discovery + dedup: multi-path roots, SKILL.md scanning, rank precedence with
 * shadow logging, project-root walking.
 */

import { test, before } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  rootsFor,
  discoverRoot,
  dedup,
  findProjectRoot,
  claudeRoots,
  geminiRoots,
  nativeRoots,
  extraRoots,
  nameFromFile,
  RANKS,
} from '../src/discover.ts'
import type { SkillIo } from '../src/discover.ts'
import { readFile, readdir } from 'node:fs/promises'

const fixtures = join(dirname(fileURLToPath(import.meta.url)), 'fixtures')
const project = join(fixtures, 'project')
const home = join(fixtures, 'home')
const extra = join(fixtures, 'extra')

// A `.git` directory is the project-root marker, but git itself does not track
// nested `.git` directories — recreate it at test runtime so the fixture tree
// works from a fresh clone.
before(() => {
  mkdirSync(join(project, '.git'), { recursive: true })
})

const io: SkillIo = {
  async listDir(path) {
    const entries = await readdir(path, { withFileTypes: true })
    return entries.map((entry) => ({ name: entry.name, isDirectory: entry.isDirectory() }))
  },
  async readText(path) {
    return await readFile(path, 'utf8')
  },
}

const noop = (): void => {}

test('rootsFor composes every mainstream location with correct ranks', () => {
  const roots = rootsFor(['dsh', 'claude', 'agents', 'gemini'], project, home, [extra])
  const table = roots.map((r) => `${r.source}:${r.rank}:${r.path}`)
  assert.ok(table.includes(`project-dsh:${RANKS.projectDsh}:${join(project, '.dsh', 'skills')}`))
  assert.ok(table.includes(`project-claude:${RANKS.projectClaude}:${join(project, '.claude', 'skills')}`))
  assert.ok(table.includes(`project-agents:${RANKS.projectAgents}:${join(project, '.agents', 'skills')}`))
  assert.ok(table.includes(`user-gemini:${RANKS.userGemini}:${join(home, '.gemini', 'antigravity', 'skills')}`))
  assert.ok(table.includes(`extra:${RANKS.extra}:${extra}`))
})

test('rank precedence: DSH-native > Claude > Codex > Gemini > extras', () => {
  assert.ok(RANKS.projectDsh < RANKS.projectClaude)
  assert.ok(RANKS.projectClaude < RANKS.projectAgents)
  assert.ok(RANKS.projectAgents < RANKS.userDsh)
  assert.ok(RANKS.userDsh < RANKS.userClaude)
  assert.ok(RANKS.userClaude < RANKS.userAgents)
  assert.ok(RANKS.userAgents < RANKS.userGemini)
  assert.ok(RANKS.userGemini < RANKS.extra)
})

test('discoverRoot finds directory-per-skill and flat .md entries', async () => {
  const skills = await discoverRoot(
    { path: join(project, '.dsh', 'skills'), source: 'project-dsh', rank: RANKS.projectDsh },
    io,
    noop,
  )
  assert.equal(skills.length, 1)
  assert.equal(skills[0]!.spec.name, 'deploy')
  assert.equal(skills[0]!.source, 'project-dsh')
})

test('discovery across all fixture sources', async () => {
  const roots = rootsFor(['dsh', 'claude', 'agents', 'gemini'], project, home, [extra])
  const all = []
  for (const root of roots) all.push(...await discoverRoot(root, io, noop))
  const names = all.map((s) => `${s.spec.name}@${s.source}`).sort()
  assert.deepEqual(names, [
    'code-review@project-agents',
    'commit-helper@project-claude',
    'custom-skill@extra',
    'deploy@project-dsh',
    'summarize@user-gemini',
    'user-skill@user-claude',
  ])
})

test('dedup keeps the lowest-rank winner and reports shadows', async () => {
  // Same skill name in .dsh (rank 100) and .claude (rank 150): dsh wins.
  const dshSkill = {
    spec: { name: 'deploy', description: 'dsh version', invocation: { modelInvocable: true, userInvocable: true }, content: 'x' },
    path: '/p/.dsh/skills/deploy/SKILL.md',
    directory: '/p/.dsh/skills/deploy',
    source: 'project-dsh',
    rank: RANKS.projectDsh,
  }
  const claudeSkill = {
    spec: { name: 'deploy', description: 'claude version', invocation: { modelInvocable: true, userInvocable: true }, content: 'y' },
    path: '/p/.claude/skills/deploy/SKILL.md',
    directory: '/p/.claude/skills/deploy',
    source: 'project-claude',
    rank: RANKS.projectClaude,
  }
  const shadows: string[] = []
  const winners = dedup([claudeSkill, dshSkill], (m) => shadows.push(m))
  assert.equal(winners.length, 1)
  assert.equal(winners[0]!.source, 'project-dsh')
  assert.equal(shadows.length, 1)
  assert.match(shadows[0]!, /shadowed/)
})

test('findProjectRoot walks up to a .git directory', async () => {
  const root = await findProjectRoot(join(project, '.claude', 'skills', 'commit-helper'), io)
  assert.equal(root, project)
})

test('claudeRoots / geminiRoots / nativeRoots / extraRoots shapes', () => {
  const claude = claudeRoots(project, home)
  assert.equal(claude.length, 2)
  assert.equal(claude[0]!.source, 'project-claude')
  assert.equal(claude[1]!.source, 'user-claude')
  const gemini = geminiRoots(home)
  assert.equal(gemini.length, 1)
  assert.equal(gemini[0]!.source, 'user-gemini')
  const native = nativeRoots(project, home)
  assert.deepEqual(native.map((r) => r.source), ['project-dsh', 'project-agents', 'user-dsh', 'user-agents'])
  const extras = extraRoots([extra])
  assert.equal(extras[0]!.source, 'extra')
  assert.equal(extras[0]!.rank, RANKS.extra)
})

test('nameFromFile derives valid kebab names', () => {
  assert.equal(nameFromFile('/x/My Rule.md'), 'my-rule')
  assert.equal(nameFromFile('/x/foo.mdc'), 'foo')
  assert.equal(nameFromFile('/x/under_score.md'), 'under-score')
  assert.equal(nameFromFile('/x/!!.md'), undefined)
})
