/**
 * Doctor report + test-fire scoring, and find_skill search.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { testFire, renderTestFire, renderDoctorList, type DoctorSkill } from '../src/doctor.ts'
import { findSkill, renderFindSkillResults, type SearchableSkill } from '../src/search.ts'

const skills: DoctorSkill[] = [
  { name: 'deploy', description: 'Deploy the application to staging or production with rollback.', source: 'project-dsh', provider: 'filesystem' },
  { name: 'commit-helper', description: 'Craft conventional-commit messages from staged changes.', source: 'project-claude', provider: 'skillport' },
  { name: 'summarize', description: 'Summarize long documents into concise bullet points.', source: 'user-gemini', provider: 'skillport' },
]

const searchable: SearchableSkill[] = skills.map((s) => ({ name: s.name, description: s.description, source: s.source, provider: s.provider }))

test('test-fire ranks the best-matching skill first', () => {
  const matches = testFire('please deploy the application to production', skills)
  assert.ok(matches.length > 0)
  assert.equal(matches[0]!.skill.name, 'deploy')
  assert.ok(matches[0]!.score > 0)
  assert.ok(matches[0]!.hits.includes('deploy'))
})

test('test-fire returns empty for an unrelated probe', () => {
  const matches = testFire('calculate the quarterly tax deduction', skills)
  assert.deepEqual(matches, [])
})

test('test-fire handles empty probes and stopwords', () => {
  assert.deepEqual(testFire('', skills), [])
  assert.deepEqual(testFire('please can you help me', skills), [])
})

test('renderTestFire formats matches with scores', () => {
  const matches = testFire('deploy the app', skills)
  const text = renderTestFire('deploy the app', matches)
  assert.ok(text.includes('deploy'))
  assert.ok(text.includes('score='))
})

test('renderDoctorList groups by source', () => {
  const text = renderDoctorList(skills)
  assert.ok(text.includes('## project-dsh (1)'))
  assert.ok(text.includes('## project-claude (1)'))
  assert.ok(text.includes('## user-gemini (1)'))
  assert.ok(text.includes('- deploy — Deploy the application'))
})

test('renderDoctorList handles the empty catalog', () => {
  assert.equal(renderDoctorList([]), 'No skills are loaded.')
})

test('findSkill ranks name matches above description matches', () => {
  // "deploy" appears in deploy's name (2) and description (1); only the name
  // match lands in commit-helper's description text ("staged changes") → deploy
  // must lead and score higher than any other match.
  const results = findSkill('deploy', searchable)
  assert.equal(results[0]!.skill.name, 'deploy')
  const others = results.filter((r) => r.skill.name !== 'deploy')
  assert.ok(others.every((r) => r.score < results[0]!.score))
})

test('findSkill matches whenToUse text', () => {
  const withWhen = [...searchable, { name: 'docs', description: 'Write docs', whenToUse: 'release notes', source: 'extra', provider: 'skillport' }]
  const results = findSkill('release', withWhen)
  assert.equal(results[0]!.skill.name, 'docs')
})

test('renderFindSkillResults handles empty results', () => {
  assert.equal(renderFindSkillResults([]), 'No skills matched the query.')
})

test('renderFindSkillResults lists matches', () => {
  const text = renderFindSkillResults([{ skill: searchable[0]!, score: 3 }])
  assert.ok(text.includes('deploy'))
  assert.ok(text.includes('score=3'))
})
