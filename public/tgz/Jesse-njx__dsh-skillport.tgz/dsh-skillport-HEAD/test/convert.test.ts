/**
 * Tier-2 converters: cursor rules (.mdc) and claude commands (.md).
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { convertCursorRule, convertClaudeCommand, discoverCursorRules, discoverClaudeCommands } from '../src/convert.ts'
import type { SkillIo } from '../src/discover.ts'

const fixtures = join(dirname(fileURLToPath(import.meta.url)), 'fixtures')
const project = join(fixtures, 'project')

const io: SkillIo = {
  async listDir(path) {
    const { readdir } = await import('node:fs/promises')
    const entries = await readdir(path, { withFileTypes: true })
    return entries.map((entry) => ({ name: entry.name, isDirectory: entry.isDirectory() }))
  },
  async readText(path) {
    return await readFile(path, 'utf8')
  },
}

const noop = (): void => {}

test('cursor rule converts to a model-invocable skill with globs as whenToUse', () => {
  const raw = '---\ndescription: TypeScript style rules\nglobs: "**/*.ts"\n---\n\nAlways use explicit types.'
  const converted = convertCursorRule('/p/.cursor/rules/typescript.mdc', raw, noop)
  assert.ok(converted !== undefined)
  assert.equal(converted.spec.name, 'typescript')
  assert.equal(converted.spec.description, 'TypeScript style rules')
  assert.equal(converted.spec.whenToUse, 'Applies when files match: **/*.ts')
  assert.equal(converted.source, 'cursor')
  assert.deepEqual(converted.spec.invocation, { modelInvocable: true, userInvocable: false })
  assert.ok(converted.spec.content.includes('explicit types'))
})

test('alwaysApply cursor rule is flagged in whenToUse', () => {
  const raw = '---\ndescription: Always-on rule\nalwaysApply: true\n---\n\nBody'
  const converted = convertCursorRule('/p/.cursor/rules/always.mdc', raw, noop)
  assert.ok(converted !== undefined)
  assert.equal(converted.spec.whenToUse, 'Applies to all files (alwaysApply).')
})

test('claude command converts to a user-invokable skill', () => {
  const raw = '---\ndescription: Review the current changes\nargument-hint: "[optional PR number]"\n---\n\nRun a careful review.'
  const converted = convertClaudeCommand('/p/.claude/commands/review.md', raw, noop)
  assert.ok(converted !== undefined)
  assert.equal(converted.spec.name, 'review')
  assert.equal(converted.source, 'claude-command')
  assert.deepEqual(converted.spec.invocation, { modelInvocable: false, userInvocable: true })
  assert.ok(converted.spec.whenToUse?.includes('argument hint'))
})

test('claude command without description is rejected', () => {
  const raw = '---\n---\n\nBody only'
  const warnings: string[] = []
  const converted = convertClaudeCommand('/p/.claude/commands/nodesc.md', raw, (m) => warnings.push(m))
  assert.equal(converted, undefined)
  assert.ok(warnings.length > 0)
})

test('discoverCursorRules scans the fixture project', async () => {
  const rules = await discoverCursorRules(project, io, noop)
  assert.equal(rules.length, 1)
  assert.equal(rules[0]!.spec.name, 'typescript')
})

test('discoverClaudeCommands scans the fixture project', async () => {
  const commands = await discoverClaudeCommands(project, io, noop)
  assert.equal(commands.length, 1)
  assert.equal(commands[0]!.spec.name, 'review')
})
