# Shipping dsh-skillport

**Deliberate scope: GitHub only — npm publishing is deferred** (see §4).
Everything below is verified locally except the push itself. **Do not create
or push GitHub repos or publish to npm without explicit instruction.**

## 0. Preflight (verified locally)

- `pnpm test` — 60 tests green (spec conformance, discovery, dedup, Tier-2
  converters, doctor, find_skill, plugin integration, CLI, goldens).
- `pnpm typecheck` (clean under `--noUnusedLocals/--noUnusedParameters`) and
  `pnpm build` — clean.
- `pnpm pack` — tarball contains `lib/` (including the `skills-doctor` bin
  with its shebang intact), `cordis.patch.yml`, `README.md`, `README.zh.md`,
  `LICENSE`, `docs/spec-revision.md`; manifest carries `dsh.bundle.patch`,
  the `skills-doctor` bin, and repository metadata.
- **Consumer simulation**: the packed tarball installs into a scratch npm
  project (with the `@deepseek-ai/*` peer deps) and the installed
  `skills-doctor` bin runs standalone against a fixture tree; the packed
  plugin also mounts against the real SkillRegistry and lists 8 skills across
  every source, loads bodies, and answers `/skills doctor`.
- **Profile simulation**: the packed tarball installs into a scratch DSH
  headless profile; `dsh --profile skillport-headless --dump-config` shows the
  bundle row composed with the user patch, and a full tree boot lists 9 skills
  — DSH-native sources served by the native `filesystem` provider (no
  double-scan) and skillport sources (`project-claude`, `user-gemini`,
  `extra`, `cursor`, `claude-command`) served by skillport.
- **Dependency pattern**: all `@deepseek-ai/*` packages are
  `peerDependencies` (the ecosystem convention — regular deps would install
  duplicate copies into DSH profiles and break tool dispatch). The only
  runtime dependency is `yaml` (generic, not a DSH package).

## 1. Create + push the GitHub repo

```sh
gh repo create Jesse-njx/dsh-skillport --public --source . --push
```

Repo settings:

- **Topics**: `dsh-plugin` (required by deepseek-harness CONTRIBUTING.md)
  plus `deepseek-harness`, `skills`, `agent-skills`, `SKILL.md`, `plugin`.
- **Description**: "Every skill you already have — Claude Code, Codex, Cursor,
  Gemini CLI — works in DSH: Agent Skills SKILL.md discovery, Tier-2
  conversions, find_skill search, and a skills doctor."

## 2. Live DSH verification

With a real provider configured (your DSH web profile):

```sh
dsh plugin --profile web add @dsh-skillport/bundle   # from the repo checkout
```

Then in a session:

- create `~/work/demo/.claude/skills/hello/SKILL.md` with a name + description;
- confirm the skill appears in the session's available-skills catalog;
- ask the model to load `hello` — the `skill` tool returns the SKILL.md body
  and the bundled-resources base directory;
- `/skills doctor` lists it with source `project-claude`;
- `skills-doctor --cwd ~/work/demo list` matches from the terminal;
- `dsh plugin remove @dsh-skillport/bundle` → the skill disappears from the
  catalog (Cordis-effect unload).

## 3. Post-push follow-ups

- Add the repo to the awesome-dsh-plugin list (one line under
  **🛠️ Tools & Capabilities** in `README.md` and `README.zh.md`).
- Post a short note on deepseek-harness Discussions (the ecosystem channel
  CONTRIBUTING.md points at) announcing the bundle.

## 4. npm publish (deferred, needs your accounts)

The package is publishable as-is (`pnpm publish --access public`) once the
scope exists; publishing is intentionally out of scope for this pass.
