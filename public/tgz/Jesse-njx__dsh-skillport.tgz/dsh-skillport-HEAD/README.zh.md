# dsh-skillport

**你在 Claude Code、Codex、Cursor、Gemini CLI 里已有的每一个 skill，都能在 DSH 里直接用。**

`dsh-skillport` 是 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 的插件 bundle，让 DSH 成为开放 **Agent Skills** 标准（`SKILL.md`）的下一个实现者。Anthropic 在 2025 年 12 月发布该规范后，30+ 个 harness（Codex CLI、Cursor、Gemini CLI、Copilot/VS Code、Goose、Windsurf）都在读取它；DSH 之前不支持。Skillport 让你**零迁移**导入整个既有生态：你的 `.claude/skills/` 技能库、Cursor 规则、Claude Code 斜杠命令，在插件加载的瞬间全部变成 DSH skill。

## 你得到什么

| 格式 | 来源 | 在 DSH 中的形态 |
|---|---|---|
| Agent Skills `SKILL.md` | `.claude/skills/`、`~/.claude/skills/`（Claude Code） | 模型可调用的 skill |
| Agent Skills `SKILL.md` | `~/.gemini/antigravity/skills/`（Gemini CLI） | 模型可调用的 skill |
| Agent Skills `SKILL.md` | `extraPaths`（配置） | 模型可调用的 skill |
| Agent Skills `SKILL.md` | `.dsh/skills/`、`.agents/skills/`（含用户级目录） | DSH 原生扫描 —— skillport 绝不重复扫描 |
| Cursor 规则 | `.cursor/rules/*.mdc` | 转换为模型可调用的 skill（来源 `cursor`） |
| Claude Code 命令 | `.claude/commands/*.md` | 转换为**用户可调用**的 skill（`/name`） |
| 上下文文件 | `AGENTS.md`、`CLAUDE.md` | 仅当 DSH 未原生处理时注入为项目上下文（原生 `dsh-agent-instructions` 优先 —— 不双重注入） |

技能汇入原生 skill 注册表（`ctx.skills`），平台自带的目录注入、渐进式披露索引和 `skill` 加载工具会自动承载它们。**所有注册都是 Cordis effect：`dsh plugin remove @dsh-skillport/bundle` 会干净地卸载每一个导入的 skill** —— 这是平台卸载模型的现场演示。

## 为什么是这个形态

DSH 自带完整的 skill 技术栈：带 rank 去重的 provider 注册表、目录注入（系统提示里的名字 + 描述）、以及加载正文并解析捆绑文件路径的 `skill` 工具。Skillport 的职责更窄、更诚实：**发现 DSH 未覆盖的位置、转换相邻格式、让结果可调试**。这正是规范里「先检查 —— 不要双重注入」原则在整个面上的落实：

- `.dsh/skills` + `.agents/skills` 由 DSH 原生的 `dsh-skill-filesystem` 扫描；skillport 检测到该 provider 就跳过这两组（仅当原生 provider 缺失时才自行扫描兜底，保证任何组合下完整覆盖）。
- 规范里的「注入」（名字 + 描述）和「use_skill」（加载正文 + 解析资源）就是原生 `dsh-tool-skill` 的目录与 `skill` 工具 —— skillport 为它们供料，而不是重复造轮子。
- `AGENTS.md`/`CLAUDE.md` 由 `dsh-agent-instructions` 原生注入；只有在该插件缺失时 skillport 才接管。

## 安装

```sh
dsh plugin --profile web add @dsh-skillport/bundle
```

然后在会话里：让模型加载一个你以前在 Claude Code 里用过的 skill —— 目录会列出它，`skill` 工具会加载它，捆绑资源一并可用。

## 配置

所有字段均可选（profile patch 或 `cordis.patch.yml`）：

```yaml
plugins:
  dsh-skillport:
    sources: [dsh, claude, agents, gemini]   # 扫描哪些发现组
    extraPaths: []                            # 额外的 SKILL.md 目录
    convert:
      cursorRules: true                       # .cursor/rules/*.mdc → skill
      contextFiles: true                      # AGENTS.md / CLAUDE.md（DSH 原生处理时跳过）
      claudeCommands: true                    # .claude/commands/*.md → 用户可调用 skill
    maxIndexEntries: 100                      # 提示词膨胀上限：超过后模型可调用候选降为用户可调用，
                                              # 由 find_skill 承载
    providerName: skillport                   # 注册表中的 provider 名
```

## Skills doctor

触发质量是最大的模糊失败模式：为 Claude 触发习惯调优的 skill，在 DeepSeek 模型上可能触发方式不同。Skillport 把它变成可调试的表面。

会话内（`/skills doctor [<描述>]`）：

```
/skills doctor
## project-claude (1)
- commit-helper — Craft conventional-commit messages from staged changes.
## project-dsh (1)
- deploy — Deploy the application to staging or production with rollback.

/skills doctor deploy the app to production
Test-fire: "deploy the app to production"
- deploy [skillport/project-dsh] score=0.83
    "Deploy the application to staging or production with rollback."
```

终端（无需 DSH 会话）：

```sh
skills-doctor --cwd ~/work/projectx list
skills-doctor --cwd ~/work/projectx test-fire "deploy the app to production"
```

## 固定规范修订版

Agent Skills 格式还很年轻且有版本。Skillport 固定它实现的修订版 —— 见 [docs/spec-revision.md](docs/spec-revision.md) —— 并附带一致性 fixture 套件（缺字段、unicode 名、嵌套资源），让规范漂移在 CI 中响亮失败。

## 非目标（有意为之）

- **Claude Code 插件 / hooks / subagents** —— 可执行的主机特定语义；移植文字与脚本是诚实的，假装移植 hook 系统是 bug 工厂。
- **MCP 配置转换** —— 不在范围内。
- **Codex / Cursor 扩展二进制** —— 不在范围内。
- Skillport 永远没有自己的执行路径：带脚本的 skill 通过 DSH 常规 shell 工具在其沙箱内运行，沙箱策略始终是唯一执行点。

## 开发

```sh
pnpm install
pnpm build
pnpm test        # 60 个测试：规范一致性、发现、去重、转换、doctor、
                 # find_skill、插件集成、CLI、goldens
```

Fixture：`test/fixtures/` 里每种来源格式一个 skill、一致性边界用例，以及注入索引与 doctor 报告的已入库 golden。

## 许可证

MIT
