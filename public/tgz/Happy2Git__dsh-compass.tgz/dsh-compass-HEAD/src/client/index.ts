/**
 * Web context-and-files panel plugin, browser half: one list-slot entry into
 * `shell.overlay` (the frame-wide floating layer — additive by id, and the
 * shipped seat for a surface of your own). The entry declares the panel's
 * viewing-state store and injects plain callbacks closed over the runtime
 * services; components never see ctx.
 *
 * Export discipline: packages/client/AGENTS.md — nothing beyond the cordis
 * loading contract leaves this module.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls ui-layout's SlotMap declaration (the shell.overlay seat)
// and its package-identity edge into this compilation.
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
// Type-only: the command/executed event shape the export observer listens to.
import type {} from '@deepseek-ai/dsh-client-ui-commands/client'
import type { SessionId } from '@deepseek-ai/dsh-api-remotes/client'
import type { DirectoryListing, DirectoryRead } from '../directory-types.ts'
import type { GitFileDiff, GitStatusFile, GitWorkspaceStatus } from '../git-seam.ts'
import { PanelRoot } from './PanelRoot.tsx'
import { installPanelDropIntake } from './drop-intake.ts'
import { SessionLogDownloadController } from './export/controller.ts'
import type { SessionLogDownloadDialogInjected } from './export/Dialog.tsx'
import { SessionLogDownloadHeaderAction } from './export/HeaderAction.tsx'
import { en, NS, zh } from './export/locales.ts'
import { docsStreamFor } from './docs-stream.ts'
import { compactionBoundary, foldDocEvents, hasMoreDocs, loadOlderDocs, readInjectedDocs } from './read-context.ts'
import { createPanelStore } from './store.ts'
import type { ContextDoc, InjectedFace } from './types.ts'
import type { FoldedDocEvent } from './read-context.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface SlotMap {
    /**
     * Right-aligned utilities in the panel's header row (the panel owns the
     * collapse toggle on the left). Root scope: a registrant reads the current
     * session through the standard `useSessions` seat.
     */
    'panel.header.utilities': { kind: 'list'; scope: 'root' }
  }
}

/**
 * POST one JSON request to a plugin-owned HTTP route and decode its JSON body.
 * The git backend and the directory-routes backend each serve their own routes
 * (`/git/*`, `/dir/*`), so the panel never touches the core API gateway for
 * git or directory data.
 * @param path - the backend's route pathname.
 * @param body - the request payload.
 * @param signal - aborts the fetch on caller supersession.
 * @returns the decoded value.
 */
async function routeFetch<T>(path: string, body: unknown, signal: AbortSignal): Promise<T> {
  const response = await fetch(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  })
  if (!response.ok) {
    const payload = await response.json().catch(() => null) as { error?: { message?: string } } | null
    throw new Error(payload?.error?.message ?? `请求失败 (${response.status})`)
  }
  return await response.json() as T
}

/** Required services: the slot registry, the session service the injected face reads, and the export dialog's locale. */
export const inject = ['slots', 'sessions', 'locale']

/**
 * Client plugin body: register the panel entry into the layout-declared
 * `shell.overlay` list slot. `slots.inject` waits for the declaration, so the
 * contribution installs regardless of sibling load order and leaves with this
 * plugin's fiber.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  // Shells without a composer-side panel-path intake (upstream) get the
  // window-level drop receiver here; fork builds' own intake claims the drag
  // first and this install stays passive (see drop-intake.ts).
  ctx.effect(() => installPanelDropIntake(), 'dsh-compass: panel-path drop intake')
  // One source per plugin (never per inject call): the renderer caches the
  // bound hook per source object, so the identity must outlive renders.
  const docsStream = docsStreamFor(ctx)
  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'context-files',
    store: createPanelStore,
    children: {
      'panel.header.utilities': { kind: 'list', scope: 'root' },
    },
    inject: (): InjectedFace => ({
      listDirectory: (path, signal): Promise<DirectoryListing> => routeFetch<DirectoryListing>('/dir/list', { path }, signal),
      readText: (path, signal): Promise<DirectoryRead> => routeFetch<DirectoryRead>('/dir/read-text', { path }, signal),
      openPath: (path): Promise<void> => routeFetch('/dir/open-path', { path }, new AbortController().signal).then(() => undefined),
      gitGraph: (cwd, count, skip, signal) => routeFetch('/git/graph', { cwd, count, skip }, signal),
      gitShowCommit: (cwd, hash, signal) => routeFetch('/git/show-commit', { cwd, hash }, signal),
      workspaceStatus: (cwd, signal): Promise<GitWorkspaceStatus> => routeFetch<GitWorkspaceStatus>('/git/workspace', { cwd }, signal),
      showFileDiff: (cwd, hash, path, signal): Promise<GitFileDiff> => routeFetch<GitFileDiff>('/git/show-diff', { cwd, hash, path }, signal),
      showWorkspaceDiff: (cwd, path, signal): Promise<GitFileDiff> => routeFetch<GitFileDiff>('/git/workspace-diff', { cwd, path }, signal),
      gitStatusFor: (dir, signal): Promise<GitStatusFile[]> => routeFetch<{ files: GitStatusFile[] }>('/git/status', { dir }, signal).then(value => value.files),
      readInjectedDocs: (sessionId: SessionId): ContextDoc[] => readInjectedDocs(ctx, sessionId),
      compactionBoundary: (sessionId: SessionId): number | null => compactionBoundary(ctx, sessionId),
      fetchDocEvents: async (sessionId, signal) => {
        try {
          const value = await routeFetch<{ events: FoldedDocEvent[] }>('/dir/injected-docs', { sessionId }, signal)
          return foldDocEvents(value.events)
        } catch {
          // Fail soft: the live-window fold still renders; the complete
          // history simply waits for the next session activation.
          return { docs: [], boundary: -1 }
        }
      },
      hasMoreDocs: (sessionId: SessionId): boolean => hasMoreDocs(ctx, sessionId),
      loadOlderDocs: (sessionId: SessionId): Promise<void> => loadOlderDocs(ctx, sessionId),
      sessionCwd: (sessionId: SessionId): string | undefined =>
        ctx.sessions.list.getSnapshot().byId[sessionId]?.cwd,
      hooks: { docsStream },
    }),
  }, PanelRoot))

  // Session-log export, browser half (absorbed from the fork's
  // session-log-export client): the download controller, its locale
  // namespace, the `/export` command observation that triggers the download,
  // and the header-utilities action + shared dialog. The ZIP endpoint itself
  // (/api/session.export) belongs to ApiProxy, which every web composition
  // mounts — only the command/dialog row was plugin territory.
  const exportController = new SessionLogDownloadController()
  ctx.effect(() => async () => { await exportController.dispose() }, 'dsh-compass: session export download lifecycle')
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-compass: session export locale')
  ctx.on('command/executed', (sessionId, commandName, result) => {
    if (commandName === 'export' && result.kind === 'success') void exportController.download(sessionId)
  })
  ctx.slots.inject('panel.header.utilities', () => ctx.slots.register({
    name: 'panel.header.utilities',
    id: 'compass-session-export',
    locale: NS,
    inject: (): SessionLogDownloadDialogInjected => ({
      hooks: { sessionLogDownload: exportController.store },
      request: (sessionId) => exportController.download(sessionId),
      dismiss: (sessionId) => exportController.dismiss(sessionId),
    }),
  }, SessionLogDownloadHeaderAction))
}
