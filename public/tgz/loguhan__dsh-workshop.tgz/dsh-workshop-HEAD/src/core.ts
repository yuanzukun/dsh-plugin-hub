/**
 * dsh-workshop 共享核心：插件目录读取、已安装检测、dsh CLI 执行。
 * 被 host 工具半与 web API 半共同使用（tsdown 分别内联）。
 */
import { spawn } from 'node:child_process'
import { readFileSync } from 'node:fs'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { homedir } from 'node:os'
import descData from './data/desc-zh.json'

interface DescEntry {
  name: string
  owner: string
  category?: string
  description?: { en?: string; zh?: string }
  install?: string
}

const DESC_MAP = new Map<string, DescEntry>()
for (const entry of (descData as { plugins: DescEntry[] }).plugins ?? []) {
  DESC_MAP.set(entry.name, entry)
}

/** awesome 精选分类 → 中文分区标签。 */
const CURATED_CATEGORIES: Record<string, string> = {
  ui: 'UI 增强',
  session: '会话与记忆',
  tools: '工具与能力',
  workflow: '工作流与自动化',
  notify: '通知与集成',
  dev: '开发与运行时',
  fun: '趣味娱乐',
}

export interface RegistryPlugin {
  name: string
  owner: string
  fullName: string
  url: string
  description?: string | null
  stars?: number
  license?: string | null
  language?: string | null
  topics?: string[]
  category?: string | null
  score?: number
  signals?: { maintenance?: number; popularity?: number; quality?: number; ecosystem?: number }
  curated?: boolean
  homepage?: string | null
  excluded?: string | null
  createdAt?: string | null
  pushedAt?: string | null
  archived?: boolean
  fork?: boolean
  awesomeLists?: string[]
}

export interface RegistryDoc {
  meta: { generatedAt?: string; total?: number }
  plugins: RegistryPlugin[]
}

/** 精选双语描述增强后的目录条目（buildCatalogView 输出）。 */
export interface EnrichedPlugin extends RegistryPlugin {
  descZh?: string
  curatedCategory?: string
}

export interface InstalledEntry {
  id: string
  kind: 'bundle' | 'insert'
}

export interface RunResult {
  code: number
  output: string
  /** 热挂载说明（安装成功后尝试免重启加载）。 */
  hotMount?: string
  /** 是否需要重启服务（bundle 插件安装/卸载后）。 */
  hotMountRestart?: boolean
  /** 失败原因分类（网页展示用）。 */
  failReason?: FailReason
  /** 失败原因的用户可读建议。 */
  failHint?: string
}

export interface CoreConfig {
  dataUrl: string
  backupUrl?: string
  cachePath: string
  profileName?: string
}

export function dshHome(): string {
  return process.env.DSH_HOME ?? join(homedir(), '.dsh')
}

export function profileDir(profileName = 'web'): string {
  return join(dshHome(), 'profiles', profileName)
}

/** 插件 npm 包名与 GitHub 源候选（npm 惯例 = 仓库名；特例补常见映射）。 */
export function installSources(p: RegistryPlugin): { npm?: string; github: string } {
  const special: Record<string, string> = {
    'deepseek-harness': '@deepseek-ai/dsh',
    'modlens': 'modlens',
  }
  const npm = special[p.name] ?? (p.name.startsWith('@') ? p.name : p.name)
  return { npm, github: `github:${p.fullName}` }
}

/** 分类规则（关键词 → Steam 风格分区），顺序优先。 */
const CATEGORY_RULES: Array<[string, RegExp]> = [
  ['UI 增强', /ui|skin|theme|tui|sidebar|panel|navbar|nav|visual|web-ui|webui|frontend|status-label|focus-chat|layout|diff-viewer|command-palette|spotlight|drag|deep-link/i],
  ['会话与记忆', /memory|session|conversation|share|rewind|import|message|chat-import|mnem|mneme|crosstalk|distill|explain|prompt-studio/i],
  ['工具与能力', /tool|mcp|terminal|bash|browser|search|vision|docker|git|excel|pdf|doc|sql|data|image|video|voice|computer-use|skillport|openpencil/i],
  ['工作流与自动化', /workflow|automation|schedule|cron|loop|agent-team|plan|task|routines|sentinel|research|advisor|specflow/i],
  ['通知与集成', /notification|notify|telegram|wechat|weixin|wechat|desktop|im-bridge|vscode|bitfun|acp|webbridge/i],
  ['开发与运行时', /sandbox|llm|model|oauth|auth|provider|runtime|debug|audit|security|hmr|health|manager|updater|plugin-manager|registry/i],
  ['趣味娱乐', /pet|game|emoji|sticker|whale|fun|mini|chess|stock|ads|douyin/i],
]

export function categorize(p: RegistryPlugin): string {
  const haystack = `${p.name} ${p.fullName} ${p.description ?? ''} ${(p.topics ?? []).join(' ')} ${p.category ?? ''}`
  for (const [label, re] of CATEGORY_RULES) {
    if (re.test(haystack)) return label
  }
  return '其他'
}

/** 目录分类计数（用于侧栏）。 */
export function categoryCounts(plugins: RegistryPlugin[]): Array<{ label: string; count: number }> {
  const map = new Map<string, number>()
  for (const p of plugins) {
    const c = categorize(p)
    map.set(c, (map.get(c) ?? 0) + 1)
  }
  return [...map.entries()].sort((a, b) => b[1] - a[1]).map(([label, count]) => ({ label, count }))
}

/** 读取本地缓存的目录；缺失/损坏返回 null。 */
export async function readCachedCatalog(cachePath: string): Promise<RegistryDoc | null> {
  try {
    const doc = JSON.parse(await readFile(cachePath, 'utf8')) as RegistryDoc
    if (!Array.isArray(doc.plugins)) return null
    return doc
  } catch {
    return null
  }
}

/** 删除本地缓存（强制刷新用）。 */
export async function clearCatalogCache(cachePath: string): Promise<void> {
  try {
    const { rm } = await import('node:fs/promises')
    await rm(cachePath, { force: true })
  } catch { /* ignore */ }
}

/** 拉取目录（dataUrl 失败回退 backupUrl / dsh-recommend 已有缓存），写入本地缓存。 */
export async function fetchCatalog(cfg: CoreConfig): Promise<RegistryDoc> {
  const cached = await readCachedCatalog(cfg.cachePath)
  if (cached) return cached
  const recommendCache = join(dshHome(), 'dsh-recommend', 'registry.json')
  try {
    const doc = JSON.parse(await readFile(recommendCache, 'utf8')) as RegistryDoc
    if (Array.isArray(doc.plugins)) {
      await mkdir(dirname(cfg.cachePath), { recursive: true })
      await writeFile(cfg.cachePath, JSON.stringify(doc), 'utf8')
      return doc
    }
  } catch { /* ignore */ }
  let lastErr: unknown = null
  for (const url of [cfg.dataUrl, cfg.backupUrl, ...RAW_BACKUPS.map((b) => b.build('data/registry.json'))].filter(Boolean)) {
    try {
      const res = await fetch(url!, { signal: AbortSignal.timeout(20000) })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const text = await res.text()
      const doc = JSON.parse(text) as RegistryDoc
      if (!Array.isArray(doc.plugins)) throw new Error('catalog 结构异常')
      await mkdir(dirname(cfg.cachePath), { recursive: true })
      await writeFile(cfg.cachePath, text, 'utf8')
      return doc
    } catch (e) {
      lastErr = e
    }
  }
  throw new Error(`插件目录下载失败: ${String(lastErr)}`)
}

/** 官方核心包（非插件，已含于 base/web-app 层），不在已安装列表中展示。 */
const CORE_PACKAGES = new Set([
  '@deepseek-ai/dsh',
  '@deepseek-ai/dsh-base',
  '@deepseek-ai/dsh-web-app',
])

/** 读取 profile 已安装插件（package.json 依赖 + patch insert 行）。 */
export async function readInstalled(profile = 'web'): Promise<InstalledEntry[]> {
  const dir = profileDir(profile)
  const out: InstalledEntry[] = []
  try {
    const pkg = JSON.parse(await readFile(join(dir, 'package.json'), 'utf8')) as {
      dependencies?: Record<string, string>
      dsh?: { profile?: { bundles?: string[] } }
    }
    const bundles = new Set(pkg.dsh?.profile?.bundles ?? [])
    for (const name of Object.keys(pkg.dependencies ?? {})) {
      if (CORE_PACKAGES.has(name)) continue
      out.push({ id: name, kind: bundles.has(name) ? 'bundle' : 'insert' })
    }
  } catch { /* profile 未初始化 */ }
  try {
    const patch = await readFile(join(dir, 'cordis.patch.yml'), 'utf8')
    for (const m of patch.matchAll(/^\s*- id:\s*([^\s]+)/gm)) {
      const id = m[1]!
      if (!out.some((e) => e.id === id)) out.push({ id, kind: 'insert' })
    }
  } catch { /* 无 patch */ }
  return out
}

/** 按 npm 包名（目录名）查 GitHub fullName，用于安装回退。 */
export async function lookupPluginFullName(cfg: CoreConfig, name: string): Promise<string | null> {
  try {
    const doc = await fetchCatalog(cfg)
    const hit = doc.plugins.find((p) => p.name === name)
    return hit?.fullName ?? null
  } catch {
    return null
  }
}

//#region GitHub 镜像加速（自动测速选最快）
export interface MirrorInfo {
  name: string
  base: string
  latencyMs: number | null
  ok: boolean
}

/** git 智能协议代理镜像（ghproxy 系），直连排第一作为基准。 */
const GIT_MIRRORS: Array<{ name: string; base: string }> = [
  { name: 'github.com 直连', base: 'https://github.com/' },
  { name: 'ghfast.top', base: 'https://ghfast.top/https://github.com/' },
  { name: 'gh-proxy.com', base: 'https://gh-proxy.com/https://github.com/' },
  { name: 'ghproxy.net', base: 'https://ghproxy.net/https://github.com/' },
  { name: 'ghproxy.cc', base: 'https://ghproxy.cc/https://github.com/' },
  { name: 'gh.llkk.cc', base: 'https://gh.llkk.cc/https://github.com/' },
  { name: 'github.moeyy.xyz', base: 'https://github.moeyy.xyz/https://github.com/' },
]

/** 目录/文件下载备份源（raw 系）。 */
const RAW_BACKUPS: Array<{ name: string; build: (path: string) => string }> = [
  { name: 'jsdelivr', build: (p) => `https://cdn.jsdelivr.net/gh/zp-home/dsh-recommend@main/${p}` },
  { name: 'raw.githubusercontent', build: (p) => `https://raw.githubusercontent.com/zp-home/dsh-recommend/main/${p}` },
  { name: 'gh-proxy raw', build: (p) => `https://gh-proxy.com/https://raw.githubusercontent.com/zp-home/dsh-recommend/main/${p}` },
  { name: 'ghfast.top raw', build: (p) => `https://ghfast.top/https://raw.githubusercontent.com/zp-home/dsh-recommend/main/${p}` },
]

let mirrorCache: { at: number; chosen: MirrorInfo; repo: string } | null = null

/** 对单个镜像做 git 智能协议连通性/时延探测。 */
async function testMirror(m: { name: string; base: string }, repo: string): Promise<MirrorInfo> {
  const url = `${m.base}${repo}.git/info/refs?service=git-upload-pack`
  const start = Date.now()
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(10000) })
    return { ...m, latencyMs: Date.now() - start, ok: res.status === 200 || res.status === 401 }
  } catch {
    return { ...m, latencyMs: null, ok: false }
  }
}

/** 并行测速全部镜像，选延迟最低的可达镜像（结果缓存 10 分钟）。 */
export async function pickFastestMirror(repo: string): Promise<MirrorInfo> {
  if (mirrorCache && mirrorCache.repo === repo && Date.now() - mirrorCache.at < 10 * 60 * 1000) {
    return mirrorCache.chosen
  }
  const results = await Promise.all(GIT_MIRRORS.map((m) => testMirror(m, repo)))
  const ok = results.filter((r) => r.ok).sort((a, b) => (a.latencyMs ?? Infinity) - (b.latencyMs ?? Infinity))
  const chosen = ok[0] ?? results[0]
  mirrorCache = { at: Date.now(), chosen, repo }
  return chosen
}

/** 查询当前生效镜像（未测速时为直连默认）。 */
export function currentMirror(): MirrorInfo {
  return mirrorCache?.chosen ?? { name: 'github.com 直连', base: 'https://github.com/', latencyMs: null, ok: true }
}

/** 清空测速缓存（重新测速）。 */
export function clearMirrorCache(): void {
  mirrorCache = null
}

/** 测速并返回全部镜像结果（供 UI 展示）。 */
export async function testAllMirrors(repo: string): Promise<MirrorInfo[]> {
  const results = await Promise.all(GIT_MIRRORS.map((m) => testMirror(m, repo)))
  const ok = results.filter((r) => r.ok).sort((a, b) => (a.latencyMs ?? Infinity) - (b.latencyMs ?? Infinity))
  mirrorCache = { at: Date.now(), chosen: ok[0] ?? results[0] ?? GIT_MIRRORS[0], repo }
  return [...ok, ...results.filter((r) => !r.ok)]
}

/** 定位用户全局 git 配置文件路径。 */
async function globalGitConfigPath(): Promise<string | null> {
  try {
    const { execFile } = await import('node:child_process')
    const path = await new Promise<string | null>((resolvePromise) => {
      execFile('git', ['config', '--global', '--list', '--show-origin'], (err, stdout) => {
        if (err) { resolvePromise(null); return }
        const m = stdout.split('\n').find((l) => l.startsWith('file:'))
        resolvePromise(m ? m.slice(5, m.indexOf('\t')) : null)
      })
    })
    return path
  } catch {
    return null
  }
}

/** 生成带镜像重写的临时 git 配置（GIT_CONFIG_GLOBAL 注入，不改用户全局配置）。 */
async function buildMirrorGitConfig(mirror: MirrorInfo): Promise<string | null> {
  const globalPath = await globalGitConfigPath()
  const lines: string[] = []
  if (globalPath) lines.push(`[include]\n\tpath = ${globalPath.replace(/\\/g, '/')}`)
  lines.push(`[url "${mirror.base}"]\n\tinsteadOf = https://github.com/`)
  const file = join(dshHome(), 'dsh-workshop', 'gitconfig-mirror')
  await mkdir(dirname(file), { recursive: true })
  await writeFile(file, lines.join('\n') + '\n', 'utf8')
  return file
}

/** 用最快镜像执行 pnpm/dsh 操作（仅本次进程 env 注入，不动全局配置）。 */
export async function runWithFastestMirror<T>(repo: string, fn: (env: NodeJS.ProcessEnv | undefined) => Promise<T>): Promise<{ result: T; mirror: MirrorInfo }> {
  const mirror = await pickFastestMirror(repo)
  if (mirror.base === 'https://github.com/') {
    return { result: await fn(undefined), mirror }
  }
  const cfg = await buildMirrorGitConfig(mirror)
  const env = cfg ? { ...process.env, GIT_CONFIG_GLOBAL: cfg } : undefined
  return { result: await fn(env), mirror }
}

/** 取最快镜像对应的环境（供 install/uninstall 直传 runDsh）。 */
export async function mirrorEnvFor(repo: string): Promise<{ env?: NodeJS.ProcessEnv; mirror: MirrorInfo }> {
  const mirror = await pickFastestMirror(repo)
  if (mirror.base === 'https://github.com/') return { env: undefined, mirror }
  const cfg = await buildMirrorGitConfig(mirror)
  return { env: cfg ? { ...process.env, GIT_CONFIG_GLOBAL: cfg } : undefined, mirror }
}
//#endregion

/** 与 web profile 冲突的已知插件（TUI / 独立发行版 / 依赖 web 不存在的服务）。 */
const WEB_PROFILE_BLOCKLIST = new Set([
  'dsh-cc-tui', 'dsh-TUI', 'dsh-tianshu-tui', 'deepseek-harness-tui', 'oh-dsh', 'dsh-cc',
  'dsh-vision-toolkit',
])

/** DSH 本体 / 官方核心仓库：不是可安装的插件，禁止安装。 */
const CORE_REPO_BLOCKLIST = new Set([
  'deepseek-ai/deepseek-harness',
  'deepseek-ai/dsh',
  'deepseek-ai/deepseek-cli',
])

/** patch 中出现即视为「接管核心配置」的危险行（web profile 下拒绝安装）。 */
const DANGER_PATCH_IDS = ['- id: agent-presets', '- id: agent-loop', '- id: cc-tui', '- id: agent-instructions']

/** 拉取仓库 cordis.patch.yml（jsdelivr 优先，raw 兜底）。 */
async function fetchRepoPatch(fullName: string): Promise<string | null> {
  for (const url of [
    `https://cdn.jsdelivr.net/gh/${fullName}@main/cordis.patch.yml`,
    `https://cdn.jsdelivr.net/gh/${fullName}@master/cordis.patch.yml`,
    `https://raw.githubusercontent.com/${fullName}/main/cordis.patch.yml`,
  ]) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(15000) })
      if (!res.ok) continue
      return await res.text()
    } catch { /* 换下一个源 */ }
  }
  return null
}

/** 安装前的 web 兼容性预检。 */
export async function checkWebCompatible(name: string, fullName: string | null): Promise<{ ok: boolean; reason?: string }> {
  if (CORE_REPO_BLOCKLIST.has(fullName ?? '') || name === 'deepseek-harness' || name === 'dsh-root') {
    return { ok: false, reason: `${fullName ?? name} 是 DSH 本体 / 官方核心仓库，不是可安装的插件，无需安装` }
  }
  if (WEB_PROFILE_BLOCKLIST.has(name)) {
    return { ok: false, reason: `${name} 是终端 TUI / 独立发行版插件，会接管 agent 配置，与 Web 界面冲突，禁止安装` }
  }
  if (!fullName) return { ok: true }
  const patch = await fetchRepoPatch(fullName)
  if (patch) {
    for (const id of DANGER_PATCH_IDS) {
      if (patch.includes(id)) {
        return { ok: false, reason: `检测到冲突配置（${id.trim()}）：该插件会覆盖核心 agent 配置，仅适合独立 profile（如 tui），装进 Web 会破坏启动` }
      }
    }
  }
  return { ok: true }
}

/** 从 pnpm 输出解析实际安装的依赖键（取最后一次「+ key」行，github 源可能被重命名）。 */
function parseInstalledKey(output: string): string | null {
  const matches = [...output.matchAll(/\+ ([^\s]+)/g)]
  const last = matches.pop()?.[1]
  return last ?? null
}

/** 按目录名解析 profile 中实际的依赖键（兼容 @dsh-external/ 前缀与任意 scope 键名）。 */
async function resolveDependencyKey(name: string, profile: string): Promise<string | null> {
  try {
    const pkg = JSON.parse(await readFile(join(profileDir(profile), 'package.json'), 'utf8')) as {
      dependencies?: Record<string, string>
    }
    const hit = Object.keys(pkg.dependencies ?? {}).find((k) => {
      if (k.toLowerCase() === name.toLowerCase() || k === `@dsh-external/${name}`) return true
      const seg = k.split('/').pop() ?? ''
      return seg.toLowerCase() === name.toLowerCase()
    })
    return hit ?? null
  } catch {
    return null
  }
}

/** 校验依赖键对应的包目录存在且可解析，否则自动回滚。优先按 package.json 依赖键匹配。 */
async function verifyInstalledAndRollback(key: string, name: string, profile: string, output: string, env?: NodeJS.ProcessEnv): Promise<RunResult> {
  const depKey = (await resolveDependencyKey(name, profile)) ?? key
  const candidates = [depKey, key, name, `@dsh-external/${name}`]
  let ok = false
  for (const cand of candidates) {
    if (!cand) continue
    try {
      await readFile(join(profileDir(profile), 'node_modules', cand, 'package.json'), 'utf8')
      ok = true
      break
    } catch { /* 下一个候选 */ }
  }
  if (ok) {
    let hotMount = ''
    let hotMountRestart = false
    try {
      const hm = await hotMountBundle(depKey, profile)
      hotMount = hm.note
      hotMountRestart = hm.restart ?? false
      if (hotMountRestart) markPendingRestart(depKey)
    } catch { /* 热挂载失败不影响安装结果 */ }
    return { code: 0, output, hotMount, hotMountRestart }
  }
  const probe = candidates.map((c) => `${c}:${(() => { try { readFileSync(join(profileDir(profile), 'node_modules', c ?? '', 'package.json'), 'utf8'); return 'ok' } catch { return 'missing' } })()}`).join(', ')
  await uninstallPlugin(depKey, profile, env)
  return { code: -1, output: `${output}\n---\n安装产物校验失败：${name} 未正确安装到 profile（候选检查: ${probe}），已自动回滚。` }
}

/** git 源插件构建被 pnpm 阻止时，自动写入 allowBuilds 并重装一次。 */
async function fixBlockedBuilds(key: string, profile: string, installArgs: string[], env?: NodeJS.ProcessEnv): Promise<RunResult | null> {
  const wsPath = join(profileDir(profile), 'pnpm-workspace.yaml')
  let ws: string
  try {
    ws = await readFile(wsPath, 'utf8')
  } catch {
    return null
  }
  const retry = await (async () => {
    try {
      if (!/allowBuilds/.test(ws)) {
        ws += `\nallowBuilds:\n  '${key}': true\n`
      } else if (!ws.includes(key)) {
        ws = ws.replace(/allowBuilds:/, `allowBuilds:\n  '${key}': true`)
      }
      await writeFile(wsPath, ws, 'utf8')
      return await installPlugin(installArgs[installArgs.length - 1], profile, env)
    } catch {
      return null
    }
  })()
  return retry
}

/** npm 包是否存在（registry.npmjs.org 优先，npmmirror 兜底；兼容小写包名），返回可用的包名。 */
async function npmPackageExists(name: string): Promise<string | null> {
  const candidates = [name, name.toLowerCase()]
  for (const cand of [...new Set(candidates)]) {
    for (const reg of ['https://registry.npmjs.org', 'https://registry.npmmirror.com']) {
      try {
        const res = await fetch(`${reg}/${encodeURIComponent(cand)}`, { method: 'HEAD', signal: AbortSignal.timeout(8000) })
        if (res.status === 200) return cand
      } catch { /* 换源 */ }
    }
  }
  return null
}

/** 探测 GitHub 仓库中的 dsh 子包（monorepo），返回子包相对路径（如 packages/foo）。 */
async function probeMonorepoSubpackage(fullName: string): Promise<string | null> {
  try {
    const res = await fetch(`https://data.jsdelivr.com/v1/packages/gh/${fullName}@main?structure=flat`, {
      signal: AbortSignal.timeout(15000),
    })
    if (!res.ok) return null
    const doc = await res.json() as { files?: Array<{ name: string }> }
    const files = doc.files?.map((f) => f.name) ?? []
    const candidates = files
      .filter((f) => /^\/[^/]+\/package\.json$/.test(f) || /^\/packages\/[^/]+\/package\.json$/.test(f))
      .filter((f) => f !== '/package.json')
    for (const f of candidates) {
      try {
        const pkgRes = await fetch(`https://cdn.jsdelivr.net/gh/${fullName}@main${f}`, { signal: AbortSignal.timeout(10000) })
        if (!pkgRes.ok) continue
        const pkg = await pkgRes.json() as { dsh?: unknown; cordis?: unknown }
        if (pkg.dsh || pkg.cordis) return f.replace(/\/package\.json$/, '').replace(/^\//, '')
      } catch { /* 下一个候选 */ }
    }
    return null
  } catch {
    return null
  }
}

/** 安装/更新插件（npm 失败自动回退 GitHub 源）。source: npm 包名或 github:owner/repo。 */
export async function installPluginSmart(source: string, cfg: CoreConfig, profile = 'web'): Promise<RunResult & { fallback?: boolean; usedSource?: string }> {
  const s = source.trim()
  const isGit = s.startsWith('github:') || s.startsWith('git:') || s.includes('/')
  const name = s.replace(/^github:[^/]+\//, '').replace(/^@[^/]+\//, '').split('/')[0]
  const full = isGit ? (s.startsWith('github:') ? s.slice(7) : s) : await lookupPluginFullName(cfg, s)
  if (profile === 'web') {
    const check = await checkWebCompatible(name, full)
    if (!check.ok) {
      finishProgress(false, '安装被安全策略拒绝')
      return { code: -1, output: `⛔ 已阻止安装：${check.reason}` }
    }
  }
  const probeRepo = full && full.includes('/') ? full : 'deepseek-ai/deepseek-harness'
  const { env, mirror } = await mirrorEnvFor(probeRepo)
  const mirrorSuffix = mirror.base === 'https://github.com/' ? '' : `（镜像：${mirror.name}）`
  if (isGit) {
    setProgressStage(`正在安装（GitHub 源 ${full}）${mirrorSuffix}…`, s)
    const res = await installPlugin(s, profile, env)
    if (res.code === 0) {
      let key = parseInstalledKey(res.output) ?? s
      const verified = await verifyInstalledAndRollback(key, name, profile, res.output, env)
      if (verified.code === 0 && /allowBuilds|Failed to create bin/i.test(res.output)) {
        // 构建脚本被 pnpm 阻止：写入 allowBuilds 后重装一次
        key = (await resolveDependencyKey(name, profile)) ?? key
        setProgressStage('构建脚本被阻止，正在解锁并重装…', s)
        const retry = await fixBlockedBuilds(key, profile, ['plugin', '--profile', profile, 'add', s], env)
        if (retry && retry.code === 0) {
          const key2 = parseInstalledKey(retry.output) ?? key
          const verified2 = await verifyInstalledAndRollback(key2, name, profile, retry.output, env)
          finishProgress(verified2.code === 0, verified2.code === 0 ? '安装完成（含构建）' : '安装完成（构建仍异常）')
          return { ...verified2 }
        }
        finishProgress(true, '安装完成（构建可能未执行，可稍后重试）')
        return { ...verified }
      }
      finishProgress(verified.code === 0, verified.code === 0 ? '安装完成' : '安装失败')
      return { ...verified }
    }
    finishProgress(false, '安装失败')
    return { ...res, failReason: classifyFailReason(res.output, false, true), failHint: failReasonHint(classifyFailReason(res.output, false, true)) }
  }
  setProgressStage('检查 npm 源…', s)
  const npmName = await npmPackageExists(s)
  let npmOut: RunResult | null = null
  if (npmName) {
    setProgressStage(`正在安装（npm 源：${npmName}）…`, s)
    npmOut = await installPlugin(npmName, profile, env)
    if (npmOut.code === 0) {
      const key = parseInstalledKey(npmOut.output) ?? npmName
      const verified = await verifyInstalledAndRollback(key, name, profile, npmOut.output, env)
      finishProgress(verified.code === 0, verified.code === 0 ? '安装完成' : '安装失败')
      return { ...verified }
    }
  }
  if (!full || full === s) {
    finishProgress(false, 'npm 未找到，且无可用 GitHub 回退源')
    const reason: FailReason = npmName && npmOut ? 'npm-install-failed' : 'npm-not-found'
    return { code: -1, failReason: reason, failHint: failReasonHint(reason), output: `${npmName && npmOut ? 'npm 安装失败' : `npm 上不存在 ${s}`}，且目录中无对应 GitHub 仓库，无法安装。${npmOut ? `\n${npmOut.output.slice(-500)}` : ''}` }
  }
  const gitSource = `github:${full}`
  setProgressStage(`npm 未找到，正在回退 GitHub 源（${full}）${mirrorSuffix}…`, s)
  const second = await installPlugin(gitSource, profile, env)
  if (second.code === 0) {
    let key = parseInstalledKey(second.output) ?? gitSource
    const verified = await verifyInstalledAndRollback(key, name, profile, second.output, env)
    if (verified.code === 0 && /allowBuilds|Failed to create bin/i.test(second.output)) {
      key = (await resolveDependencyKey(name, profile)) ?? key
      setProgressStage('构建脚本被阻止，正在解锁并重装…', s)
      const retry = await fixBlockedBuilds(key, profile, ['plugin', '--profile', profile, 'add', gitSource], env)
      if (retry && retry.code === 0) {
        const key2 = parseInstalledKey(retry.output) ?? key
        const verified2 = await verifyInstalledAndRollback(key2, name, profile, retry.output, env)
        finishProgress(verified2.code === 0, verified2.code === 0 ? 'GitHub 源安装完成（含构建）' : 'GitHub 源安装完成（构建仍异常）')
        return { ...verified2, fallback: true, usedSource: gitSource }
      }
      finishProgress(true, '安装完成（构建可能未执行，可稍后重试）')
      return { ...verified, fallback: true, usedSource: gitSource }
    }
    finishProgress(verified.code === 0, verified.code === 0 ? 'GitHub 源安装完成' : '安装失败')
    return { ...verified, fallback: true, usedSource: gitSource }
  }
  // monorepo 探测：根目录没有 bundle 时，尝试 packages/<name> 等子包
  const sub = await probeMonorepoSubpackage(full)
  if (sub) {
    setProgressStage(`检测到 monorepo，尝试子包 ${sub}…`, s)
    const third = await installPlugin(`github:${full}#main&path=/${sub}`, profile, env)
    if (third.code === 0) {
      const key3 = parseInstalledKey(third.output) ?? s
      const verified3 = await verifyInstalledAndRollback(key3, name, profile, third.output, env)
      finishProgress(verified3.code === 0, verified3.code === 0 ? '子包安装完成' : '子包安装失败')
      return { ...verified3, fallback: true, usedSource: `github:${full}#main&path=/${sub}` }
    }
  }
  const prepareFailed = /ERR_PNPM_PREPARE_PACKAGE|prepare\s*Failed|Failed to prepare/i.test(second.output)
  const reason = classifyFailReason(
    `${npmOut?.output ?? ''}\n${second.output}`,
    Boolean(npmName),
    true,
  )
  finishProgress(false, '安装失败')
  return {
    code: -1,
    failReason: reason,
    failHint: failReasonHint(reason),
    output: `${npmName && npmOut ? `npm 安装失败：${npmOut.output.slice(-800)}` : `npm 上不存在 ${s}`}\n---\n[GitHub 回退失败]\n${second.output}${prepareFailed ? '\n\n提示：该仓库需要源码构建（prepare），构建脚本在上游仓库即失败（常见为 tsdown/unrun 依赖缺失）。可先确认 npm 上是否有同名小写包，或联系插件作者修复构建。' : ''}`,
  }
}

/** 运行 dsh CLI（通过 npx），返回退出码与合并输出。env 覆盖环境（镜像 git 配置注入）。 */
export function runDsh(args: string[], timeoutMs = 300000, env?: NodeJS.ProcessEnv): Promise<RunResult> {
  return new Promise((resolvePromise) => {
    const isWin = process.platform === 'win32'
    const npxPath = join(dirname(process.execPath), isWin ? 'npx.cmd' : 'npx')
    const fullArgs = isWin
      ? ['/c', npxPath, '-y', '@deepseek-ai/dsh', ...args]
      : ['-y', '@deepseek-ai/dsh', ...args]
    let child
    try {
      child = spawn(isWin ? 'cmd.exe' : 'npx', fullArgs, {
        env: env ?? process.env,
        windowsHide: true,
        shell: false,
      })
    } catch (e) {
      resolvePromise({ code: -1, output: String(e) })
      return
    }
    let out = ''
    const timer = setTimeout(() => {
      child.kill()
      resolvePromise({ code: -1, output: `${out}\n[超时 ${Math.round(timeoutMs / 1000)}s，已终止]` })
    }, timeoutMs)
    child.stdout.on('data', (d: Buffer) => {
      const text = d.toString()
      out += text
      for (const line of text.split('\n')) pushProgressLine(line)
    })
    child.stderr.on('data', (d: Buffer) => {
      const text = d.toString()
      out += text
      for (const line of text.split('\n')) pushProgressLine(line)
    })
    child.on('error', (e) => { clearTimeout(timer); resolvePromise({ code: -1, output: `${out}\n${String(e)}` }) })
    child.on('close', (code) => {
      clearTimeout(timer)
      resolvePromise({ code: code ?? -1, output: out.slice(-40000) })
    })
  })
}

/** 安装/更新插件。source: npm 包名或 github:owner/repo。 */
export async function installPlugin(source: string, profile = 'web', env?: NodeJS.ProcessEnv): Promise<RunResult> {
  return runDsh(['plugin', '--profile', profile, 'add', source], 300000, env)
}

/** 卸载插件（按目录名或实际依赖键匹配）；dsh remove 后清理 bundle 层栈残留。走最快镜像。 */
export async function uninstallPlugin(id: string, profile = 'web', env?: NodeJS.ProcessEnv): Promise<RunResult> {
  const dir = profileDir(profile)
  let rawId = id
  let probeRepo = 'deepseek-ai/deepseek-harness'
  try {
    const pkg = JSON.parse(await readFile(join(dir, 'package.json'), 'utf8')) as {
      dependencies?: Record<string, string>
    }
    const hit = Object.keys(pkg.dependencies ?? {}).find(
      (k) => k === id || normalizeInstalledId(k) === id)
    if (hit) {
      rawId = hit
      const spec = pkg.dependencies?.[hit] ?? ''
      const m = spec.match(/^github:([^/]+\/[^/#]+)/)
      if (m) probeRepo = m[1]
    }
  } catch { /* 无 profile 包信息 */ }
  setProgressStage('正在卸载…', rawId)
  let res: RunResult
  if (env) {
    res = await runDsh(['plugin', '--profile', profile, 'remove', rawId], 300000, env)
  } else {
    const { env: mirrorEnv } = await mirrorEnvFor(probeRepo)
    res = await runDsh(['plugin', '--profile', profile, 'remove', rawId], 300000, mirrorEnv)
  }
  let wasBundle = false
  try {
    const pkgPath = join(dir, 'package.json')
    const pkg = JSON.parse(await readFile(pkgPath, 'utf8'))
    const bundles: string[] = pkg.dsh?.profile?.bundles ?? []
    const bundleHit = bundles.includes(rawId) || bundles.some((b) => normalizeInstalledId(b) === id)
    if (bundleHit) {
      wasBundle = true
      pkg.dsh.profile.bundles = bundles.filter((b) => normalizeInstalledId(b) !== id)
      if (pkg.dependencies?.[rawId]) delete pkg.dependencies[rawId]
      await writeFile(pkgPath, `${JSON.stringify(pkg, null, 2)}\n`, 'utf8')
    } else if (pkg.dependencies?.[rawId]) {
      delete pkg.dependencies[rawId]
      await writeFile(pkgPath, `${JSON.stringify(pkg, null, 2)}\n`, 'utf8')
    }
  } catch { /* 清理失败不影响主结果 */ }
  finishProgress(res.code === 0, res.code === 0 ? '卸载完成' : '卸载失败（package.json 已尽力清理）')
  if (res.code === 0 && wasBundle) {
    markPendingRestart(rawId)
    return { ...res, hotMountRestart: true, hotMount: 'bundle 插件：重启后完全卸载' }
  }
  return res
}

export interface CatalogView {
  meta: { generatedAt?: string; total?: number }
  plugins: RegistryPlugin[]
  installed: string[]
  /** 已安装但不在目录中的依赖键（如未收录的插件）。 */
  installedOther: string[]
  categories: Array<{ label: string; count: number }>
}

/** github: 源安装会被 pnpm 重命名为 @dsh-external/<name>，匹配时归一化。 */
export function normalizeInstalledId(id: string): string {
  return id.replace(/^@dsh-external\//, '')
}

/** 已知依赖键 → 目录名的别名表（仓库名与发布名不一致的情况）。 */
const INSTALL_ALIASES: Record<string, string> = {
  '@linxin666/dsh-web-ui-all': 'dsh-web-ui',
  '@linxin666/dsh-skins': 'dsh-web-ui',
  '@linxin666/dsh-ssh': 'dsh-ssh',
  '@linxin666/dsh-pet': 'dsh-pet',
  '@liustack/modlens': 'modlens',
  '@zseven-w/dsh-openpencil': 'dsh-openpencil',
}

//#region 安装进度追踪（单例，web API 轮询读取）
export interface ProgressState {
  active: boolean
  source: string
  stage: string
  lines: string[]
  ok: boolean
}

const progress: ProgressState = { active: false, source: '', stage: 'idle', lines: [], ok: false }

export function getProgress(): ProgressState {
  return { ...progress, lines: [...progress.lines] }
}

export function setProgressStage(stage: string, source = ''): void {
  progress.active = true
  progress.source = source || progress.source
  progress.stage = stage
}

export function pushProgressLine(line: string): void {
  const t = line.replace(/\r/g, '').trim()
  if (!t) return
  progress.lines.push(t)
  if (progress.lines.length > 20) progress.lines.splice(0, progress.lines.length - 20)
}

export function finishProgress(ok: boolean, stage: string): void {
  progress.active = false
  progress.ok = ok
  progress.stage = stage
}

export function resetProgress(): void {
  progress.active = false
  progress.source = ''
  progress.stage = 'idle'
  progress.lines = []
  progress.ok = false
}
//#endregion

/** 组装前端视图：目录 + 已安装 + 分类计数（合并精选中文描述/分类）。 */
export async function buildCatalogView(cfg: CoreConfig): Promise<CatalogView> {
  const doc = await fetchCatalog(cfg)
  const installedRaw = await readInstalled(cfg.profileName ?? 'web')
  const byName = new Map<string, { name: string }>()
  for (const p of doc.plugins) {
    if (p.excluded) continue
    byName.set(p.name.toLowerCase(), p)
    byName.set(p.fullName.toLowerCase(), p)
    const seg = p.name.split('/').pop() ?? ''
    byName.set(seg.toLowerCase(), p)
  }
  const matchPlugin = (key: string): { name: string } | undefined => {
    const norm = normalizeInstalledId(key)
    const alias = INSTALL_ALIASES[key] ?? INSTALL_ALIASES[norm]
    if (alias) {
      const hit = doc.plugins.find((p) => !p.excluded && p.name.toLowerCase() === alias.toLowerCase())
      if (hit) return hit
    }
    return byName.get(norm.toLowerCase())
      ?? byName.get(key.toLowerCase())
      ?? byName.get((key.split('/').pop() ?? '').toLowerCase())
  }
  const installed: string[] = []
  const installedOther: string[] = []
  for (const entry of installedRaw) {
    if (entry.id === 'dsh-workshop') continue
    const hit = matchPlugin(entry.id)
    if (hit && hit.name !== 'dsh-workshop') installed.push(hit.name)
    else installedOther.push(entry.id)
  }
  const plugins = doc.plugins
    .filter((p) => !CORE_REPO_BLOCKLIST.has(p.fullName) && !WEB_PROFILE_BLOCKLIST.has(p.name) && p.name !== 'deepseek-harness' && p.name !== 'dsh-root')
    .map((p): EnrichedPlugin => {
    const curated = DESC_MAP.get(p.name)
    return {
      ...p,      descZh: curated?.description?.zh,
      curatedCategory: curated?.category ? CURATED_CATEGORIES[curated.category] : undefined,
    }
  })
  return {
    meta: doc.meta,
    plugins,
    installed,
    installedOther,
    categories: categoryCounts(plugins.filter((p) => !p.excluded)),
  }
}

/** 从 bundle patch 原文中提取顶层 `- insert:` 块（保持原始 YAML 文本，含 !!js 表达式）。 */
function extractInsertBlocks(patch: string): string[] {
  const blocks: string[] = []
  const lines = patch.split('\n')
  let current: string[] | null = null
  for (const line of lines) {
    if (/^- insert:\s*$/.test(line)) {
      if (current) blocks.push(current.join('\n'))
      current = [line]
    } else if (current) {
      if (/^\S/.test(line) && !line.startsWith('- insert:')) {
        blocks.push(current.join('\n'))
        current = null
      } else {
        current.push(line)
      }
    }
  }
  if (current) blocks.push(current.join('\n'))
  return blocks
}

/**
 * 安装后热挂载：把已安装 bundle 的 insert 行写入 profile cordis.patch.yml，
 * 借助配置 HMR 实时挂载（免重启）。返回说明文案。
 */
export async function hotMountBundle(depKey: string, profile: string): Promise<{ ok: boolean; note: string; restart?: boolean }> {
  try {
    const pkgDir = join(profileDir(profile), 'node_modules', depKey)
    let pkgJson = ''
    try {
      pkgJson = await readFile(join(pkgDir, 'package.json'), 'utf8')
    } catch {
      return { ok: true, note: '包未就绪' }
    }
    const pkg = JSON.parse(pkgJson) as { dsh?: { bundle?: unknown } }
    // bundle 插件由 bundle 层在启动时统一挂载；热挂载 insert 行会与 bundle 层重复，
    // 且客户端 manifest 在启动时扫描——需要重启服务才能完整加载（含 UI）。
    if (pkg.dsh?.bundle) {
      return { ok: true, note: 'bundle 插件：需要重启服务加载', restart: true }
    }
    let patch = ''
    try {
      patch = await readFile(join(pkgDir, 'cordis.patch.yml'), 'utf8')
    } catch {
      return { ok: true, note: '纯 cordis 插件，无需热挂载' }
    }
    const blocks = extractInsertBlocks(patch)
    if (blocks.length === 0) return { ok: true, note: '无 insert 行，无需热挂载' }

    const profilePatchPath = join(profileDir(profile), 'cordis.patch.yml')
    let profilePatch = ''
    try {
      profilePatch = await readFile(profilePatchPath, 'utf8')
    } catch { /* 首次写入 */ }

    const existingIds = new Set<string>()
    for (const m of profilePatch.matchAll(/^\s*- id:\s*([^\s]+)/gm)) {
      const id = m[1]
      if (id) existingIds.add(id)
    }

    const fresh: string[] = []
    for (const block of blocks) {
      const idMatch = block.match(/^\s*- id:\s*([^\s]+)/m)
      if (!idMatch) continue
      if (existingIds.has(idMatch[1]!)) continue
      fresh.push(block)
      existingIds.add(idMatch[1]!)
    }
    if (fresh.length === 0) return { ok: true, note: 'insert 行已挂载' }

    const root = profilePatch.trim().length === 0 || /^\[\]\s*$/.test(profilePatch.trim())
    let next: string
    if (root) {
      next = fresh.join('\n\n') + '\n'
    } else {
      next = profilePatch.replace(/\s*$/, '') + '\n\n' + fresh.join('\n\n') + '\n'
    }
    await writeFile(profilePatchPath, next, 'utf8')
    return { ok: true, note: `已热挂载 ${fresh.length} 行（配置 HMR 实时生效，免重启）` }
  } catch (e) {
    return { ok: false, note: `热挂载失败：${String(e)}（可重启 dsh web 生效）` }
  }
}

/** 单例串行队列：安装/卸载互斥执行（pnpm 锁）。 */
let queue: Promise<unknown> = Promise.resolve()
export function serial<T>(fn: () => Promise<T>): Promise<T> {
  const next = queue.then(fn, fn)
  queue = next.catch(() => undefined)
  return next
}

//#region 待重启清单（bundle 插件安装/卸载后需要重启才能完整生效）
const pendingRestart = new Set<string>()

export function markPendingRestart(id: string): void {
  pendingRestart.add(id)
}

export function getPendingRestart(): string[] {
  return [...pendingRestart]
}

export function clearPendingRestart(): void {
  pendingRestart.clear()
}
//#endregion

/** 安装失败原因分类（网页展示用）。 */
export type FailReason =
  | 'blocked'
  | 'npm-not-found'
  | 'npm-install-failed'
  | 'github-network'
  | 'github-prepare-failed'
  | 'github-install-failed'
  | 'verify-failed'
  | 'unknown'

/** 从 pnpm/git 输出中推断失败原因。 */
export function classifyFailReason(output: string, npmTried: boolean, githubTried: boolean): FailReason {
  if (/ERR_PNPM_PREPARE_PACKAGE|prepare\s*Failed|Failed to prepare/i.test(output)) return 'github-prepare-failed'
  if (/git ls-remote|fatal:|Unable to access|Could not connect|Connection (refused|reset|timed out)|Failed to connect|ETIMEDOUT|ECONNREFUSED|ENOTFOUND/i.test(output)) return 'github-network'
  if (/ERR_PNPM_FETCH_404|not in the npm registry|404 - Not Found/i.test(output) && !githubTried) return 'npm-not-found'
  if (npmTried && !githubTried && /ERR_PNPM_FETCH_404|not in the npm registry/.test(output)) return 'npm-not-found'
  if (npmTried) return 'npm-install-failed'
  if (githubTried) return 'github-install-failed'
  if (/安装产物校验失败/.test(output)) return 'verify-failed'
  return 'unknown'
}

/** 失败原因 → 用户可读的建议。 */
export function failReasonHint(reason: FailReason): string {
  switch (reason) {
    case 'blocked': return '该插件与 Web 环境不兼容，已安全拦截'
    case 'npm-not-found': return 'npm 上不存在该包名，已尝试 GitHub 源但仍失败'
    case 'npm-install-failed': return 'npm 安装失败，可检查网络后重试，或换 GitHub 源'
    case 'github-network': return 'GitHub 网络连接失败（镜像也不可用），请稍后重试或检查网络'
    case 'github-prepare-failed': return 'GitHub 源码安装时构建脚本失败（上游仓库问题），可尝试安装 npm 版本或联系作者'
    case 'github-install-failed': return 'GitHub 源安装失败，可稍后重试'
    case 'verify-failed': return '安装产物校验失败，已自动回滚'
    default: return '未知错误，可查看日志或重试'
  }
}
