/**
 * 中央列挂载：把创意工坊 React 树挂进 [data-pane="conversation]，
 * 激活时隐藏会话内容（会话子树保持挂载、有状态）。
 */
import { createRoot, type Root } from 'react-dom/client'
import type { ReactNode } from 'react'
import { PANEL_NAME, WorkshopController, SIDEBAR_ROW_SELECTOR } from './controller.ts'

export const VIEW_SELECTOR = '[data-dsh-workshop-view]'

const CONVERSATION_COLUMN_SELECTOR = '[data-pane="conversation"]'
const ACTIVE_ATTR = 'data-dsh-workshop-active'
const ACTIVATE_EVENT = 'dsh-panel-activate'

const TAKEOVER_STYLE = `
[data-pane='conversation'] {
  position: relative;
}
[data-dsh-workshop-view] {
  position: absolute;
  inset: 0;
  display: none;
  z-index: 5;
}
html[data-dsh-workshop-active]:not([data-dsh-taskboard-active]):not([data-dsh-ssh-active]) [data-dsh-workshop-view] {
  display: block;
}
html[data-dsh-workshop-active]:not([data-dsh-taskboard-active]):not([data-dsh-ssh-active]) [data-pane='conversation'] > :not([data-dsh-workshop-view]) {
  display: none;
}
`

function conversationColumn(): HTMLElement | undefined {
  return document.querySelector<HTMLElement>(CONVERSATION_COLUMN_SELECTOR) ?? undefined
}

/** 挂载面板视图 + 全局互斥逻辑。 */
export function mountWorkshopView(controller: WorkshopController, renderView: () => ReactNode): () => void {
  const style = document.createElement('style')
  style.dataset.dshWorkshopViewStyle = ''
  style.textContent = TAKEOVER_STYLE
  document.head.appendChild(style)

  let root: Root | undefined
  let container: HTMLDivElement | undefined

  const ensure = (): void => {
    if (container !== undefined) return
    const column = conversationColumn()
    if (column === undefined) return
    container = document.createElement('div')
    container.dataset.dshWorkshopView = ''
    column.appendChild(container)
    root = createRoot(container)
    root.render(renderView())
  }

  const waitObserver = new MutationObserver(() => { ensure() })
  waitObserver.observe(document.body, { childList: true, subtree: true })

  const onClickSidebarRow = (event: MouseEvent): void => {
    if (!controller.isOpen()) return
    const target = event.target as HTMLElement | null
    if (target === null) return
    if (target.closest(SIDEBAR_ROW_SELECTOR) !== null) controller.setOpen(false)
  }

  document.addEventListener('click', onClickSidebarRow, true)
  document.addEventListener(ACTIVATE_EVENT, controller.onOtherActivate)

  ensure()

  return () => {
    document.removeEventListener('click', onClickSidebarRow, true)
    document.removeEventListener(ACTIVATE_EVENT, controller.onOtherActivate)
    waitObserver.disconnect()
    document.documentElement.removeAttribute(ACTIVE_ATTR)
    root?.unmount()
    root = undefined
    container?.remove()
    container = undefined
    style.remove()
  }
}
