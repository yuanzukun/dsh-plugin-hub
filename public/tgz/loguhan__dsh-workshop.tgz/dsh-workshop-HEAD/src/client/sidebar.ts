/**
 * 侧边栏独立入口：在「新会话」按钮下方注入「创意工坊」入口行。
 * 与 dsh-web-ui 的 task-board / ssh 同构（DOM 级注入 + MutationObserver 自愈），
 * 现代风格图标按钮，激活态高亮。
 */
import type { WorkshopController } from './controller.ts'

export const ENTRY_SELECTOR = '[data-dsh-workshop-entry]'

/** 现代商店风格图标（与 shell 16px nav-icon 一致）。 */
const ICON = `<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.5 4.5 3.2 2h9.6l.7 2.5"/><path d="M2.5 4.5a1.75 1.75 0 0 0 3.5 0 1.75 1.75 0 0 0 3.5 0 1.75 1.75 0 0 0 3.5 0"/><path d="M3 6.5v7a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-7"/><path d="M6.2 14v-3h3.6v3"/></svg>`

const ENTRY_STYLE = `
[data-dsh-workshop-entry] {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 32px;
  padding: 0 12px;
  background: transparent;
  border: none;
  border-radius: 8px;
  color: var(--dsw-alias-label-secondary);
  cursor: pointer;
  font-size: 13px;
  white-space: nowrap;
  transition: background-color 120ms ease, color 120ms ease;
}
[data-dsh-workshop-entry]:hover {
  background: var(--dsw-specific-sidebar-nav-item-hover);
  color: var(--dsw-alias-label-primary);
}
[data-dsh-workshop-entry][data-active] {
  background: var(--dsw-specific-sidebar-nav-item-active);
  color: var(--dsw-alias-label-primary);
  font-weight: 600;
}
[data-dsh-workshop-entry] .dsw2-entry-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
}
[data-dsh-workshop-entry][data-active] .dsw2-entry-icon {
  color: var(--dsw-alias-state-business-primary);
}
[data-dsh-workshop-entry] .dsw2-entry-label {
  overflow: hidden;
  text-overflow: ellipsis;
}
[data-dsh-frame][data-sidebar-collapsed] [data-dsh-workshop-entry] {
  justify-content: center;
  padding: 0;
  width: 100%;
}
[data-dsh-frame][data-sidebar-collapsed] [data-dsh-workshop-entry] .dsw2-entry-label {
  display: none;
}
[data-dsh-workshop-entry]:focus-visible {
  outline: 2px solid var(--dsw-alias-state-business-primary);
  outline-offset: 2px;
}
`

/** 与 task-board / ssh 共享的「家族」选择器：注入行按相对顺序排布，互不挤占。 */
const FAMILY_SELECTOR = '[data-dsh-taskboard-entry], [data-dsh-ssh-entry], [data-dsh-workshop-entry]'

/** 侧边栏外壳根元素。 */
function sidebarRoot(): HTMLElement | undefined {
  const column = document.querySelector<HTMLElement>('[data-pane="sidebar"], [class*="sidebarCol"]')
  if (column === null) return undefined
  const logoOwner = column.querySelector<HTMLElement>('[class*="logoRow"]')?.parentElement
  return logoOwner ?? (column.firstElementChild as HTMLElement | undefined)
}

/** 「新会话」按钮：当前 shell 嵌套在 logo 行，旧 shell 为直接子元素。 */
function newSessionButton(root: HTMLElement): HTMLButtonElement | undefined {
  const nested = root.querySelector<HTMLButtonElement>('button[class*="newSession"]')
  if (nested !== null) return nested
  for (const child of root.children) {
    if (child.tagName === 'BUTTON') return child as HTMLButtonElement
  }
  return undefined
}

function createEntry(controller: WorkshopController): HTMLButtonElement {
  const entry = document.createElement('button')
  entry.type = 'button'
  entry.dataset.dshWorkshopEntry = ''
  entry.setAttribute('aria-label', '创意工坊')
  entry.innerHTML = `<span class="dsw2-entry-icon">${ICON}</span><span class="dsw2-entry-label">创意工坊</span>`
  entry.addEventListener('click', () => { controller.toggle() })
  return entry
}

/** 插入到「新会话」行之后（家族块之前）。 */
function placeEntry(root: HTMLElement, entry: HTMLButtonElement): boolean {
  const button = newSessionButton(root)
  if (button === undefined) return false
  if (entry.parentElement !== root) {
    const row = button.closest('[class*="logoRow"]')
    const base = (row !== null && row.parentElement === root) ? row : button
    const family = Array.from(root.children).filter(
      (el): el is HTMLElement => el instanceof HTMLElement && el.matches(FAMILY_SELECTOR),
    )
    const anchor = family.length > 0 ? family[0] : base.nextElementSibling
    root.insertBefore(entry, anchor)
  }
  return true
}

/** 挂载侧边栏入口；React 重渲染被挤掉后自愈重插。 */
export function mountSidebarEntry(controller: WorkshopController, styleInjected: boolean): () => void {
  if (styleInjected) {
    const style = document.createElement('style')
    style.dataset.dshWorkshopEntryStyle = ''
    style.textContent = ENTRY_STYLE
    document.head.appendChild(style)
  }
  const entry = createEntry(controller)
  let root: HTMLElement | undefined
  let placed = false

  const tryPlace = (): void => {
    if (root !== undefined && !root.isConnected) {
      rootObserver.disconnect()
      root = undefined
      placed = false
    }
    if (placed) {
      if (document.body.contains(entry)) return
      rootObserver.disconnect()
      root = undefined
      placed = false
    }
    root ??= sidebarRoot()
    if (root === undefined) return
    placed = placeEntry(root, entry)
    if (placed) rootObserver.observe(root, { childList: true, subtree: true })
  }

  const waitObserver = new MutationObserver(() => { tryPlace() })
  waitObserver.observe(document.body, { childList: true, subtree: true })

  const rootObserver = new MutationObserver(() => {
    if (root === undefined || !root.isConnected) {
      placed = false
      tryPlace()
      return
    }
    if (!root.contains(entry)) placed = placeEntry(root, entry)
  })

  const unsubscribe = controller.subscribe(() => {
    entry.dataset.active = controller.isOpen() ? 'true' : undefined
  })
  entry.dataset.active = controller.isOpen() ? 'true' : undefined

  tryPlace()

  return () => {
    waitObserver.disconnect()
    rootObserver.disconnect()
    unsubscribe()
    entry.remove()
  }
}
