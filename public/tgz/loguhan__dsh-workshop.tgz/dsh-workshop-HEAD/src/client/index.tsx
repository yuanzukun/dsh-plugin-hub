/**
 * dsh-workshop 浏览器半入口：独立侧边栏按钮 + 中央列创意工坊面板。
 * 纯 DOM 注入（与 dsh-web-ui 的 task-board / ssh 同构），不依赖 slots/locale。
 */

export const inject: string[] = []

export interface WorkshopApi {
  loadCatalog(): Promise<{
    meta: { generatedAt?: string; total?: number }
    plugins: Plugin[]
    installed: string[]
    installedOther?: string[]
    categories: Array<{ label: string; count: number }>
    pendingRestart?: string[]
  }>
  install(source: string): Promise<{ ok: boolean; output: string; fallback?: boolean; usedSource?: string | null; hotMount?: string | null; restarting?: boolean; failReason?: string | null; failHint?: string | null }>
  uninstall(id: string): Promise<{ ok: boolean; output: string; restarting?: boolean; hotMount?: string | null; failReason?: string | null; failHint?: string | null }>
  refresh(): Promise<{ ok: boolean; total?: number }>
  progress(): Promise<{ active: boolean; source: string; stage: string; lines: string[]; ok: boolean }>
  mirror(): Promise<{ name: string; base: string; latencyMs: number | null; ok: boolean }>
  retestMirrors(): Promise<{ ok: boolean; chosen: { name: string; latencyMs: number | null } }>
  restart(): Promise<{ ok: boolean; restarting?: boolean }>
}

interface MirrorInfo {
  name: string
  base: string
  latencyMs: number | null
  ok: boolean
}

//#region 组件
import { useState, useEffect, useMemo, useCallback } from 'react'
import type { ReactNode } from 'react'
import { WorkshopController } from './controller.ts'
import { mountSidebarEntry } from './sidebar.ts'
import { mountWorkshopView } from './mount.tsx'
/* eslint-disable @typescript-eslint/no-explicit-any */

interface Plugin {
  name: string
  owner: string
  fullName: string
  url: string
  description?: string | null
  descZh?: string
  curatedCategory?: string
  stars?: number
  license?: string | null
  language?: string | null
  topics?: string[]
  score?: number
  homepage?: string | null
  pushedAt?: string | null
  createdAt?: string | null
  excluded?: string | null
}

interface ProgressInfo {
  active: boolean
  source: string
  stage: string
  lines: string[]
  ok: boolean
}

interface Catalog {
  meta: { generatedAt?: string; total?: number }
  plugins: Plugin[]
  installed: string[]
  installedOther?: string[]
  categories: Array<{ label: string; count: number }>
  pendingRestart?: string[]
}

interface Toast {
  id: number
  kind: 'ok' | 'err' | 'info'
  text: string
}

const SORTS = [
  { key: 'score', label: '综合分' },
  { key: 'stars', label: '★ 星标' },
  { key: 'hot30', label: '近30天热门' },
  { key: 'hot7', label: '近7天热门' },
  { key: 'updated', label: '最近更新' },
  { key: 'created', label: '最新发布' },
  { key: 'name', label: '名称 A-Z' },
] as const

/** 中文关键词 → 英文检索词映射（搜索时自动补充英文关键词）。 */
const ZH_EN_MAP: Array<[string, string]> = [
  ['通知', 'notification'], ['提醒', 'notification'], ['微信', 'wechat'], ['电报', 'telegram'],
  ['记忆', 'memory'], ['会话', 'session'], ['分享', 'share'], ['聊天', 'chat'],
  ['皮肤', 'skin'], ['主题', 'theme'], ['侧边栏', 'sidebar'], ['面板', 'panel'],
  ['终端', 'terminal'], ['tui', 'tui'], ['界面', 'ui'], ['美化', 'ui'],
  ['游戏', 'game'], ['宠物', 'pet'], ['表情', 'emoji'], ['贴纸', 'sticker'],
  ['搜索', 'search'], ['浏览器', 'browser'], ['工具', 'tool'], ['工作流', 'workflow'],
  ['自动化', 'automation'], ['定时', 'schedule'], ['定时任务', 'cron'], ['循环', 'loop'],
  ['导出', 'export'], ['导入', 'import'], ['报告', 'report'], ['数据库', 'sql'],
  ['图片', 'image'], ['视频', 'video'], ['下载', 'download'], ['渗透', 'pentest'],
  ['审计', 'audit'], ['安全', 'security'], ['监控', 'monitor'], ['同步', 'sync'],
  ['备份', 'backup'], ['文档', 'doc'], ['表格', 'excel'], ['代码', 'code'],
  ['逆向', 'reverse'], ['漏洞', 'vuln'], ['抓包', 'proxy'], ['翻译', 'translate'],
  ['语音', 'voice'], ['音色', 'voice'], ['git', 'git'], ['终端', 'bash'],
  ['快捷', 'shortcut'], ['命令', 'command'], ['提示词', 'prompt'], ['模型', 'model'],
  ['令牌', 'token'], ['统计', 'stats'], ['排行', 'rank'], ['推荐', 'recommend'],
]

/** 展开搜索词：原始词 + 中英映射补充词。 */
function expandQuery(q: string): string[] {
  const terms = [q]
  for (const [zh, en] of ZH_EN_MAP) {
    if (q.includes(zh) && !terms.includes(en)) terms.push(en)
    if (q.includes(en) && !terms.includes(zh)) terms.push(zh)
  }
  return terms
}

const PALETTE = ['#66c0f4', '#a4d007', '#f5c518', '#e56c6c', '#b48fe2', '#5bc8af', '#f08c5a', '#8ab8ff']

function hashHue(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i += 1) h = (h * 31 + s.charCodeAt(i)) >>> 0
  return h
}

function fmtStars(n?: number): string {
  if (!n) return '0'
  return n >= 10000 ? `${(n / 1000).toFixed(1)}k` : String(n)
}

function fmtTime(iso?: string | null): string {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  return d.toLocaleDateString('zh-CN')
}

function categorize(p: Plugin): string {
  const hay = `${p.name} ${p.fullName} ${p.description ?? ''} ${(p.topics ?? []).join(' ')}`
  const rules: Array<[string, RegExp]> = [
    ['UI 增强', /ui|skin|theme|tui|sidebar|panel|navbar|nav|visual|web-ui|webui|frontend|status-label|focus-chat|layout|diff-viewer|spotlight|drag|deep-link/i],
    ['会话与记忆', /memory|session|conversation|share|rewind|import|message|chat-import|mnem|mneme|crosstalk|distill|explain|prompt-studio/i],
    ['工具与能力', /tool|mcp|terminal|bash|browser|search|vision|docker|git|excel|pdf|doc|sql|data|image|video|voice|computer-use|skillport|openpencil/i],
    ['工作流与自动化', /workflow|automation|schedule|cron|loop|agent-team|plan|task|routines|sentinel|research|advisor|specflow/i],
    ['通知与集成', /notification|notify|telegram|wechat|weixin|desktop|im-bridge|vscode|bitfun|acp|webbridge/i],
    ['开发与运行时', /sandbox|llm|model|oauth|auth|provider|runtime|debug|audit|security|hmr|health|manager|updater|plugin-manager|registry/i],
    ['趣味娱乐', /pet|game|emoji|sticker|whale|fun|mini|chess|stock|ads|douyin/i],
  ]
  for (const [label, re] of rules) if (re.test(hay)) return label
  return '其他'
}

const CSS = `
.dsw2-wrap {
  height: 100%;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 16px 18px 24px;
  font-size: 14px;
  line-height: 1.5;
  background: var(--dsw-alias-bg-base, #16202d);
  color: var(--dsw-alias-label-primary, #c7d5e0);
  font-family: var(--dsw-font-family, inherit);
  --dsw2-accent: var(--dsw-alias-state-business-primary, #66c0f4);
  --dsw2-green: var(--dsw-alias-state-success-primary, #75b022);
  --dsw2-red: var(--dsw-alias-state-error-primary, #e56c6c);
  --dsw2-panel: var(--dsw-alias-bg-layer-2, #2a475e);
  --dsw2-panel3: var(--dsw-alias-bg-layer-3, #1f3347);
  --dsw2-text: var(--dsw-alias-label-primary, #c7d5e0);
  --dsw2-text-strong: var(--dsw-alias-label-primary, #ffffff);
  --dsw2-muted: var(--dsw-alias-label-tertiary, #8f98a0);
  --dsw2-mid: var(--dsw-alias-label-secondary, #c7d5e0);
  --dsw2-border: var(--dsw-alias-border-l2, rgba(255,255,255,.09));
  --dsw2-border-hi: var(--dsw-alias-border-l3, rgba(255,255,255,.18));
}
.dsw2-head { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; }
.dsw2-title { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.dsw2-title h3 { margin: 0; font-size: 19px; font-weight: 800; letter-spacing: .3px; color: var(--dsw2-text-strong); }
.dsw2-title span { font-size: 12.5px; color: var(--dsw2-muted); }
.dsw2-search { display: flex; gap: 8px; margin-left: auto; align-items: center; flex-wrap: wrap; }
.dsw2-search input {
  width: 220px; padding: 8px 12px; font-size: 13.5px;
  color: var(--dsw2-text); background: var(--dsw-specific-input-major, var(--dsw2-panel));
  border: 1px solid var(--dsw2-border); border-radius: 8px; outline: none;
  transition: border-color .15s ease;
}
.dsw2-search input:focus { border-color: var(--dsw2-accent); }
.dsw2-btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  padding: 7px 14px; font-size: 13px; font-weight: 700; cursor: pointer; user-select: none;
  color: var(--dsw-alias-label-primary-foreground, #0e151d);
  background: var(--dsw-alias-button-info-fill, #66c0f4);
  border: 1px solid transparent; border-radius: 8px;
  transition: background-color 120ms ease, filter 120ms ease, opacity .15s ease;
}
.dsw2-btn:hover:not(:disabled) { background: var(--dsw-alias-button-info-hover, #4a9fd8); filter: brightness(1.05); }
.dsw2-btn:active:not(:disabled) { filter: brightness(.95); }
.dsw2-btn:disabled { opacity: .55; cursor: not-allowed; filter: none; }
.dsw2-btn.ghost {
  background: transparent; color: var(--dsw2-accent);
  border: 1px solid var(--dsw2-border-hi);
}
.dsw2-btn.ghost:hover:not(:disabled) { background: var(--dsw-alias-interactive-bg-hover, rgba(255,255,255,.06)); }
.dsw2-btn.green { background: var(--dsw2-green); color: #fff; }
.dsw2-btn.green:hover:not(:disabled) { filter: brightness(1.08); }
.dsw2-btn.red { background: var(--dsw2-red); color: #fff; }
.dsw2-btn.small { padding: 4px 10px; font-size: 12px; border-radius: 6px; }
.dsw2-select {
  padding: 8px 10px; font-size: 13px; color: var(--dsw2-text); cursor: pointer;
  background: var(--dsw2-panel); border: 1px solid var(--dsw2-border); border-radius: 8px; outline: none;
}
.dsw2-body { display: grid; grid-template-columns: 168px 1fr; gap: 14px; align-items: start; }
.dsw2-rail {
  display: flex; flex-direction: column; gap: 2px;
  background: var(--dsw2-panel); border: 1px solid var(--dsw2-border); border-radius: 10px; padding: 8px;
  position: sticky; top: 0;
}
.dsw2-rail-item {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 7px 10px; font-size: 13px; border-radius: 7px; cursor: pointer;
  color: var(--dsw2-mid); border: 1px solid transparent; background: transparent;
  transition: background-color 120ms ease;
}
.dsw2-rail-item:hover { background: var(--dsw2-panel3); }
.dsw2-rail-item.active { background: var(--dsw2-panel3); color: var(--dsw2-accent); font-weight: 700; border-color: var(--dsw2-border-hi); }
.dsw2-rail-item .n { font-size: 11.5px; color: var(--dsw2-muted); }
.dsw2-rail-sep { height: 1px; background: var(--dsw2-border); margin: 6px 2px; }
.dsw2-main { display: flex; flex-direction: column; gap: 12px; min-width: 0; }
.dsw2-carousel { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 10px; }
.dsw2-featured {
  position: relative; overflow: hidden; min-height: 96px; border-radius: 10px; cursor: pointer;
  border: 1px solid var(--dsw2-border-hi);
  background: linear-gradient(135deg, var(--dsw2-panel3), var(--dsw2-panel));
  display: flex; flex-direction: column; justify-content: flex-end; padding: 12px 14px; gap: 4px;
  transition: transform .15s ease, box-shadow .15s ease;
}
.dsw2-featured:hover { transform: translateY(-2px); box-shadow: var(--dsw-shadow-lv2, 0 6px 18px rgba(0,0,0,.25)); }
.dsw2-featured .tag { position: absolute; top: 8px; left: 10px; font-size: 10.5px; font-weight: 800; letter-spacing: 1px; color: var(--dsw2-accent); }
.dsw2-featured .big { font-size: 15px; font-weight: 800; color: var(--dsw2-text-strong); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dsw2-featured .sub { font-size: 11.5px; color: var(--dsw2-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dsw2-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 10px; }
.dsw2-card {
  display: flex; flex-direction: column; gap: 8px; padding: 12px 13px;
  background: var(--dsw2-panel); border: 1px solid var(--dsw2-border); border-radius: 10px;
  cursor: pointer; transition: border-color .15s ease, transform .15s ease, box-shadow .15s ease;
  min-width: 0;
}
.dsw2-card:hover { border-color: var(--dsw2-accent); transform: translateY(-1px); box-shadow: var(--dsw-shadow-lv1, none); }
.dsw2-card-top { display: flex; align-items: center; gap: 10px; min-width: 0; }
.dsw2-avatar {
  flex: 0 0 auto; width: 40px; height: 40px; border-radius: 9px;
  display: inline-flex; align-items: center; justify-content: center;
  font-size: 19px; font-weight: 800; color: #0e151d;
}
.dsw2-card-name { min-width: 0; display: flex; flex-direction: column; gap: 1px; }
.dsw2-card-name .nm { font-size: 14px; font-weight: 700; color: var(--dsw2-text-strong); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dsw2-card-name .ow { font-size: 11.5px; color: var(--dsw2-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dsw2-card-desc {
  font-size: 12.5px; color: var(--dsw2-mid); display: -webkit-box;
  -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; min-height: 36px;
}
.dsw2-card-tags { display: flex; flex-wrap: wrap; gap: 5px; }
.dsw2-tag {
  font-size: 10.5px; padding: 2px 7px; border-radius: 5px;
  background: var(--dsw-alias-interactive-bg-hover, rgba(255,255,255,.06));
  border: 1px solid var(--dsw2-border); color: var(--dsw2-muted); white-space: nowrap;
}
.dsw2-tag.lang { color: var(--dsw2-accent); }
.dsw2-card-bottom { display: flex; align-items: center; gap: 8px; margin-top: auto; }
.dsw2-stars { font-size: 12.5px; font-weight: 700; color: #f5c518; white-space: nowrap; display: inline-flex; align-items: center; gap: 3px; }
.dsw2-score { font-size: 11px; color: var(--dsw2-muted); white-space: nowrap; }
.dsw2-card-bottom .dsw2-btn { margin-left: auto; }
.dsw2-empty {
  padding: 40px 20px; text-align: center; color: var(--dsw2-muted); font-size: 13.5px;
  background: var(--dsw2-panel); border: 1px dashed var(--dsw2-border-hi); border-radius: 10px;
}
.dsw2-pager { display: flex; align-items: center; justify-content: center; gap: 12px; }
.dsw2-pager span { font-size: 12.5px; color: var(--dsw2-muted); }
.dsw2-modal-mask {
  position: fixed; inset: 0; z-index: 9999; display: flex; align-items: center; justify-content: center;
  background: var(--dsw-alias-bg-mask-1, rgba(8, 12, 18, .62)); backdrop-filter: blur(3px); padding: 24px;
}
.dsw2-modal {
  width: min(620px, 92vw); max-height: 82vh; overflow: auto;
  background: var(--dsw-alias-bg-base, #16202d); border: 1px solid var(--dsw2-border-hi); border-radius: 14px;
  padding: 20px 22px; display: flex; flex-direction: column; gap: 14px;
  box-shadow: var(--dsw-shadow-lv3, 0 18px 60px rgba(0,0,0,.5));
  color: var(--dsw2-text);
}
.dsw2-modal-head { display: flex; gap: 12px; align-items: flex-start; }
.dsw2-modal-title { display: flex; flex-direction: column; gap: 3px; min-width: 0; }
.dsw2-modal-title .nm { font-size: 17px; font-weight: 800; color: var(--dsw2-text-strong); word-break: break-all; }
.dsw2-modal-title .ow { font-size: 12.5px; color: var(--dsw2-muted); }
.dsw2-modal-desc { font-size: 13.5px; color: var(--dsw2-text); }
.dsw2-modal-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 16px; font-size: 12.5px; color: var(--dsw2-muted); }
.dsw2-modal-meta b { color: var(--dsw2-mid); font-weight: 600; }
.dsw2-modal-links { display: flex; gap: 8px; flex-wrap: wrap; }
.dsw2-modal-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; padding-top: 4px; border-top: 1px solid var(--dsw2-border); }
.dsw2-src { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.dsw2-src-code {
  font-family: var(--dsw-font-markdown-code-block-small, ui-monospace, Consolas, monospace);
  font-size: 12px; padding: 6px 10px;
  background: var(--dsw-alias-bg-layer-2, rgba(255,255,255,.06));
  border: 1px solid var(--dsw2-border); border-radius: 6px; color: var(--dsw2-accent);
}
.dsw2-modal-close { margin-left: auto; }
.dsw2-toast-zone { position: fixed; right: 18px; bottom: 18px; z-index: 10000; display: flex; flex-direction: column; gap: 8px; max-width: 420px; }
.dsw2-toast {
  padding: 10px 14px; border-radius: 9px; font-size: 13px; color: var(--dsw-alias-label-primary, #fff);
  background: var(--dsw-alias-bg-layer-3, #1f3347); border: 1px solid var(--dsw2-border-hi);
  box-shadow: var(--dsw-shadow-lv2, 0 8px 24px rgba(0,0,0,.35));
  white-space: pre-wrap; word-break: break-all;
}
.dsw2-toast.ok { border-color: var(--dsw2-green); }
.dsw2-toast.err { border-color: var(--dsw2-red); }
.dsw2-toast.info { border-color: var(--dsw2-accent); }
.dsw2-spinner {
  width: 14px; height: 14px; border-radius: 50%; display: inline-block;
  border: 2px solid currentColor; border-top-color: transparent; animation: dsw2spin .7s linear infinite;
}
@keyframes dsw2spin { to { transform: rotate(360deg); } }
.dsw2-foot { font-size: 11.5px; color: var(--dsw2-muted); }
.dsw2-panel-other { display: flex; flex-direction: column; gap: 0; margin-top: 4px; }
.dsw2-restart-banner {
  display: flex; align-items: center; gap: 12px; flex-wrap: wrap;
  padding: 10px 14px;
  background: linear-gradient(135deg, var(--dsw2-panel3), var(--dsw2-panel));
  border: 1px solid var(--dsw2-accent); border-radius: 10px;
  font-size: 13px; color: var(--dsw2-text);
}
.dsw2-restart-banner .tip { flex: 1; min-width: 200px; }
.dsw2-progress {
  position: sticky; bottom: 0;
  display: flex; flex-direction: column; gap: 6px;
  padding: 10px 14px;
  background: var(--dsw-alias-bg-layer-3, #1f3347);
  border: 1px solid var(--dsw2-border-hi); border-radius: 10px;
  box-shadow: var(--dsw-shadow-lv2, 0 8px 24px rgba(0,0,0,.35));
}
.dsw2-progress-head { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600; color: var(--dsw2-text-strong); }
.dsw2-progress-stage { font-size: 12px; color: var(--dsw2-mid); }
.dsw2-progress-lines {
  margin: 0; padding: 8px 10px; max-height: 150px; overflow-y: auto;
  font-family: var(--dsw-font-markdown-code-block-small, ui-monospace, Consolas, monospace);
  font-size: 11.5px; line-height: 1.5; white-space: pre-wrap; word-break: break-all;
  color: var(--dsw2-muted);
  background: var(--dsw-alias-bg-base, rgba(0,0,0,.25));
  border: 1px solid var(--dsw2-border); border-radius: 8px;
}
.dsw2-progress.ok .dsw2-progress-head { color: var(--dsw2-green); }
.dsw2-progress.fail .dsw2-progress-head { color: var(--dsw2-red); }
`

function Avatar({ name }: { name: string }) {
  const c = PALETTE[hashHue(name) % PALETTE.length]
  const letter = name.startsWith('@') ? name.slice(1, 2).toUpperCase() : name.slice(0, 1).toUpperCase()
  return <span className="dsw2-avatar" style={{ background: c }}>{letter}</span>
}

function Modal({ children, onClose }: { children: ReactNode; onClose: () => void }) {
  return (
    <div className="dsw2-modal-mask" onClick={onClose}>
      <div className="dsw2-modal" onClick={(e) => e.stopPropagation()}>{children}</div>
    </div>
  )
}

function ScoreBar({ score }: { score?: number }) {
  if (score == null) return null
  return <span className="dsw2-score" title={`综合分 ${score.toFixed(2)}`}>{Math.round(score * 100)}</span>
}

export function WorkshopTab(props: WorkshopApi): JSX.Element {
  const api = props
  const [cat, setCat] = useState<Catalog | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('全部')
  const [view, setView] = useState<'all' | 'installed'>('all')
  const [sort, setSort] = useState<(typeof SORTS)[number]['key']>('score')
  const [page, setPage] = useState(1)
  const [busy, setBusy] = useState<string | null>(null)
  const [detail, setDetail] = useState<Plugin | null>(null)
  const [toasts, setToasts] = useState<Toast[]>([])
  const [progress, setProgress] = useState<ProgressInfo | null>(null)
  const [mirror, setMirror] = useState<MirrorInfo | null>(null)

  const PAGE_SIZE = 18

  const pushToast = useCallback((kind: Toast['kind'], text: string) => {
    const id = Date.now() + Math.random()
    setToasts((t) => [...t, { id, kind, text }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 6000)
  }, [])

  const load = useCallback(async (refresh = false) => {
    setLoading(true)
    try {
      if (refresh) {
        const r = await api.refresh()
        if (!r.ok) pushToast('err', '刷新失败')
        if (r.total != null) pushToast('ok', `目录已刷新，共 ${r.total} 个插件`)
      }
      const c = await api.loadCatalog()
      setCat(c)
      setErr(null)
    } catch (e) {
      setErr(String(e))
    } finally {
      setLoading(false)
    }
  }, [api, pushToast])

  useEffect(() => { void load() }, [load])
  useEffect(() => { setPage(1) }, [query, category, sort, view])

  useEffect(() => {
    let stop = false
    void api.mirror().then((m) => { if (!stop) setMirror(m) }).catch(() => undefined)
    return () => { stop = true }
  }, [api])

  const retest = useCallback(async () => {
    pushToast('info', '正在测速全部镜像…')
    try {
      const r = await api.retestMirrors()
      if (r.ok && r.chosen) {
        setMirror({ ...r.chosen, base: '', ok: true })
        pushToast('ok', `已切换到最快镜像：${r.chosen.name}（${r.chosen.latencyMs ?? '—'}ms）`)
      } else {
        pushToast('err', '测速失败')
      }
    } catch (e) {
      pushToast('err', `测速出错：${String(e)}`)
    }
  }, [api, pushToast])

  // 安装/卸载期间轮询进度
  useEffect(() => {
    if (busy === null) { setProgress(null); return }
    let stop = false
    const tick = async () => {
      try {
        const p = await api.progress()
        if (stop) return
        setProgress(p)
        // 仅在服务端确实报告「非空闲且有产出」时判定完成；
        // active=false 且 stage=idle（安装请求尚未开始处理）时继续轮询。
        // 完成后延迟收起进度卡片，让用户看到结果状态。
        if (!p.active && (p.lines.length > 0 || p.stage !== 'idle')) {
          setTimeout(() => setBusy(null), 2500)
          void load()
        }
      } catch { /* 轮询失败忽略 */ }
    }
    void tick()
    const timer = setInterval(() => void tick(), 1200)
    return () => { stop = true; clearInterval(timer) }
  }, [busy, api, load])

  const rows = useMemo(() => {
    if (!cat) return []
    let list = cat.plugins.filter((p) => !p.excluded)
    if (view === 'installed') list = list.filter((p) => cat.installed.includes(p.name))
    if (category !== '全部') list = list.filter((p) => categorize(p) === category)
    const q = query.trim().toLowerCase()
    if (q) {
      const terms = expandQuery(q)
      list = list.filter((p) => {
        const hay = `${p.fullName} ${p.name} ${p.owner} ${p.description ?? ''} ${p.descZh ?? ''} ${categorize(p)}`.toLowerCase()
        return terms.some((t) => hay.includes(t))
      })
    }
    const hot30 = Date.now() - 30 * 24 * 3600 * 1000
    const hot7 = Date.now() - 7 * 24 * 3600 * 1000
    const sorters: Record<string, (a: Plugin, b: Plugin) => number> = {
      score: (a, b) => (b.score ?? 0) - (a.score ?? 0),
      stars: (a, b) => (b.stars ?? 0) - (a.stars ?? 0),
      updated: (a, b) => (b.pushedAt ?? '').localeCompare(a.pushedAt ?? ''),
      created: (a, b) => (b.createdAt ?? '').localeCompare(a.createdAt ?? ''),
      name: (a, b) => a.name.localeCompare(b.name),
      hot30: (a, b) => {
        const an = new Date(a.pushedAt ?? '').getTime()
        const bn = new Date(b.pushedAt ?? '').getTime()
        const av = an >= hot30 ? (a.stars ?? 0) : -1
        const bv = bn >= hot30 ? (b.stars ?? 0) : -1
        return bv - av
      },
      hot7: (a, b) => {
        const an = new Date(a.pushedAt ?? '').getTime()
        const bn = new Date(b.pushedAt ?? '').getTime()
        const av = an >= hot7 ? (a.stars ?? 0) : -1
        const bv = bn >= hot7 ? (b.stars ?? 0) : -1
        return bv - av
      },
    }
    return [...list].sort(sorters[sort])
  }, [cat, query, category, sort, view])

  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE))
  const safePage = Math.min(page, totalPages)
  const pageRows = rows.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE)
  const featured = useMemo(
    () => (cat ? [...cat.plugins.filter((p) => !p.excluded)].sort((a, b) => (b.score ?? 0) - (a.score ?? 0)).slice(0, 4) : []),
    [cat],
  )

  const installedSet = useMemo(() => new Set(cat?.installed ?? []), [cat])
  const installedTotal = (cat?.installed.length ?? 0) + (cat?.installedOther?.length ?? 0)

  const doInstall = async (plugin: Plugin, source?: string) => {
    setBusy(plugin.name)
    try {
      const r = await api.install(source ?? plugin.name)
      if (r.ok) {
        if (r.hotMount && r.hotMount.includes('重启')) {
          pushToast('ok', `已安装 ${plugin.name}\n顶部横幅可一键重启使其生效（也可稍后再重启）`)
        } else {
          pushToast('ok', r.fallback
            ? `已安装 ${plugin.name}\n自动回退 GitHub 源：${r.usedSource}\n${r.hotMount ?? ''}`
            : `已安装 ${plugin.name}\n${r.hotMount ?? ''}`)
        }
        await load()
      } else {
        const tail = r.output.slice(-220)
        pushToast('err', `安装失败（${r.failReason ?? 'unknown'}）：${r.failHint ?? tail}\n${tail}`)
      }
    } catch (e) {
      pushToast('err', `安装出错：${String(e)}`)
    } finally {
      setBusy(null)
    }
  }

  const doUninstall = async (plugin: Plugin) => {
    setBusy(plugin.name)
    try {
      const r = await api.uninstall(plugin.name)
      if (r.ok) {
        pushToast('ok', `已卸载 ${plugin.name}\n${r.hotMount ?? '重启 dsh web 后完全生效'}`)
        await load()
      } else {
        pushToast('err', `卸载失败：${r.output.slice(-300)}`)
      }
    } catch (e) {
      pushToast('err', `卸载出错：${String(e)}`)
    } finally {
      setBusy(null)
    }
  }

  /** 手动重启服务（用户选择）。 */
  const doRestart = useCallback(async () => {
    pushToast('info', '正在重启服务（约 10 秒），页面将自动刷新…')
    try {
      const r = await api.restart()
      if (r.ok && r.restarting) {
        setTimeout(() => window.location.reload(), 10000)
      } else {
        pushToast('err', '重启请求失败')
      }
    } catch (e) {
      pushToast('err', `重启出错：${String(e)}`)
    }
  }, [api, pushToast])

  if (loading && !cat) {
    return (
      <div className="dsw2-wrap">
        <style>{CSS}</style>
        <div className="dsw2-empty"><span className="dsw2-spinner" /> 正在加载创意工坊…</div>
      </div>
    )
  }
  if (err && !cat) {
    return (
      <div className="dsw2-wrap">
        <style>{CSS}</style>
        <div className="dsw2-empty">
          <div>目录加载失败：{err}</div>
          <div style={{ marginTop: 10 }}>
            <button className="dsw2-btn" onClick={() => void load(true)}>重试并刷新</button>
          </div>
        </div>
      </div>
    )
  }
  if (!cat) return <div className="dsw2-wrap"><style>{CSS}</style><div className="dsw2-empty">无数据</div></div>

  const renderCard = (p: Plugin) => {
    const isInstalled = installedSet.has(p.name)
    return (
      <div key={p.fullName} className="dsw2-card" onClick={() => setDetail(p)}>
        <div className="dsw2-card-top">
          <Avatar name={p.name} />
          <div className="dsw2-card-name">
            <span className="nm" title={p.name}>{p.name}</span>
            <span className="ow">{p.owner}</span>
          </div>
        </div>
        <div className="dsw2-card-desc">{p.descZh ?? p.description ?? '暂无描述'}</div>
        <div className="dsw2-card-tags">
          {p.language ? <span className="dsw2-tag lang">{p.language}</span> : null}
          {p.license ? <span className="dsw2-tag">{p.license}</span> : null}
          <span className="dsw2-tag">{p.curatedCategory ?? categorize(p)}</span>
        </div>
        <div className="dsw2-card-bottom">
          <span className="dsw2-stars">★ {fmtStars(p.stars)}</span>
          <ScoreBar score={p.score} />
          <button
            className={`dsw2-btn small ${isInstalled ? 'green' : ''}`}
            disabled={busy === p.name}
            onClick={(e) => { e.stopPropagation(); isInstalled ? setDetail(p) : void doInstall(p) }}
          >
            {busy === p.name ? <span className="dsw2-spinner" /> : isInstalled ? '已安装 ✓' : '安装'}
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="dsw2-wrap">
      <style>{CSS}</style>

      <div className="dsw2-head">
        <div className="dsw2-title">
          <h3>DSH 创意工坊</h3>
          <span>
            {cat.plugins.filter((p) => !p.excluded).length} 个插件 · 数据更新于 {fmtTime(cat.meta.generatedAt)} · 收录 ≠ 安全背书
          </span>
        </div>
        <div className="dsw2-search">
          <input
            type="search"
            placeholder="搜索插件…（如 通知 / TUI / 记忆）"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <select className="dsw2-select" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)}>
            {SORTS.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
          </select>
          <button className="dsw2-btn ghost" disabled={loading} onClick={() => void load(true)}>
            {loading ? <span className="dsw2-spinner" /> : '刷新'}
          </button>
        </div>
      </div>

      <div className="dsw2-body">
        {((cat.pendingRestart?.length ?? 0) > 0) && (
          <div className="dsw2-restart-banner" style={{ gridColumn: '1 / -1' }}>
            <span className="tip">
              ⚠ {cat.pendingRestart?.length ?? 0} 个插件（{cat.pendingRestart?.join(', ') ?? ''}）已安装/卸载，需要重启服务才能完整生效。
            </span>
            <button className="dsw2-btn" onClick={() => void doRestart()}>立即重启</button>
            <button className="dsw2-btn ghost small" onClick={() => void load()}>稍后</button>
          </div>
        )}
        <div className="dsw2-rail">
          <button
            className={`dsw2-rail-item ${view === 'all' && category === '全部' ? 'active' : ''}`}
            onClick={() => { setView('all'); setCategory('全部') }}
          >
            <span>全部</span>
            <span className="n">{cat.plugins.filter((p) => !p.excluded).length}</span>
          </button>
          {cat.categories.map((c) => (
            <button
              key={c.label}
              className={`dsw2-rail-item ${view === 'all' && category === c.label ? 'active' : ''}`}
              onClick={() => { setView('all'); setCategory(c.label) }}
            >
              <span>{c.label}</span>
              <span className="n">{c.count}</span>
            </button>
          ))}
          <div className="dsw2-rail-sep" />
          <button
            className={`dsw2-rail-item ${view === 'installed' ? 'active' : ''}`}
            onClick={() => setView('installed')}
          >
            <span>已安装</span>
            <span className="n">{installedTotal}</span>
          </button>
        </div>

        <div className="dsw2-main">
          {view === 'all' && !query && category === '全部' && sort === 'score' && featured.length > 0 && (
            <div className="dsw2-carousel">
              {featured.map((p, i) => (
                <div key={p.fullName} className="dsw2-featured" onClick={() => setDetail(p)}>
                  <span className="tag">FEATURED {i + 1}</span>
                  <span className="big">{p.name}</span>
                  <span className="sub">{p.description}</span>
                </div>
              ))}
            </div>
          )}

          {pageRows.length === 0 ? (
            <div className="dsw2-empty">
              {view === 'installed'
                ? '还没有安装任何插件 —— 去浏览并点击安装吧'
                : '没有匹配的插件，换个关键词试试'}
            </div>
          ) : (
            <div className="dsw2-grid">{pageRows.map(renderCard)}</div>
          )}

          {view === 'installed' && (cat.installedOther?.length ?? 0) > 0 && (
            <div className="dsw2-panel-other">
              <div className="dsw2-foot" style={{ marginBottom: 6 }}>
                其他已安装（不在目录中，共 {cat.installedOther.length} 个）：
              </div>
              <div className="dsw2-grid">
                {cat.installedOther.map((key) => (
                  <div key={key} className="dsw2-card" style={{ cursor: 'default' }}>
                    <div className="dsw2-card-top">
                      <Avatar name={key} />
                      <div className="dsw2-card-name">
                        <span className="nm" title={key}>{key}</span>
                        <span className="ow">未收录于目录</span>
                      </div>
                    </div>
                    <div className="dsw2-card-tags">
                      <span className="dsw2-tag lang">手动/其他来源</span>
                    </div>
                    <div className="dsw2-card-bottom">
                      <button
                        className="dsw2-btn red small"
                        style={{ marginLeft: 'auto' }}
                        disabled={busy === key}
                        onClick={() => void (async () => {
                          setBusy(key)
                          try {
                            const r = await api.uninstall(key)
                            if (r.restarting) {
                              pushToast('ok', `已卸载 ${key}\n服务自动重启中（约 10 秒），页面将自动刷新…`)
                              setTimeout(() => window.location.reload(), 10000)
                              return
                            }
                            pushToast(r.ok ? 'ok' : 'err', r.ok ? `已卸载 ${key}` : `卸载失败：${r.output.slice(-300)}`)
                            await load()
                          } catch (e) {
                            pushToast('err', `卸载出错：${String(e)}`)
                          } finally {
                            setBusy(null)
                          }
                        })()}
                      >
                        {busy === key ? <span className="dsw2-spinner" /> : '卸载'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {totalPages > 1 && (
            <div className="dsw2-pager">
              <button className="dsw2-btn ghost small" disabled={safePage <= 1} onClick={() => setPage(safePage - 1)}>« 上一页</button>
              <span>{safePage} / {totalPages} · 共 {rows.length} 条</span>
              <button className="dsw2-btn ghost small" disabled={safePage >= totalPages} onClick={() => setPage(safePage + 1)}>下一页 »</button>
            </div>
          )}

          {view === 'installed' && (
            <div className="dsw2-foot">
              已安装的 bundle 插件在卸载或更新后需要重启 dsh web 生效；非 bundle 插件实时生效。
            </div>
          )}

          <div className="dsw2-foot" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span>
              ⚡ 加速镜像：{mirror?.name ?? '检测中…'}
              {mirror?.latencyMs != null ? `（${mirror.latencyMs}ms）` : ''}
            </span>
            <button className="dsw2-btn ghost small" onClick={() => void retest()}>重新测速</button>
            <span style={{ marginLeft: 'auto' }}>
              目录更新于 {fmtTime(cat.meta.generatedAt)} · 收录 ≠ 安全背书
            </span>
          </div>

          {progress && (progress.active || progress.lines.length > 0) && (
            <div className={`dsw2-progress ${progress.ok ? 'ok' : 'fail'}`}>
              <div className="dsw2-progress-head">
                {progress.active ? <span className="dsw2-spinner" /> : <span>{progress.ok ? '✓' : '✕'}</span>}
                <span>{progress.active ? `正在处理：${progress.source || '—'}` : (progress.ok ? '操作完成' : '操作失败')}</span>
              </div>
              <div className="dsw2-progress-stage">{progress.stage}</div>
              {progress.lines.length > 0 && (
                <pre className="dsw2-progress-lines">{progress.lines.slice(-8).join('\n')}</pre>
              )}
            </div>
          )}
        </div>
      </div>

      {detail && (() => {
        const p = detail
        const isInstalled = installedSet.has(p.name)
        return (
          <Modal onClose={() => setDetail(null)}>
            <div className="dsw2-modal-head">
              <Avatar name={p.name} />
              <div className="dsw2-modal-title">
                <span className="nm">{p.name}</span>
                <span className="ow">{p.owner} · ★ {fmtStars(p.stars)} · 综合分 {p.score != null ? p.score.toFixed(2) : '—'}</span>
              </div>
              <button className="dsw2-btn ghost small dsw2-modal-close" onClick={() => setDetail(null)}>✕</button>
            </div>
            <div className="dsw2-modal-desc">
              {p.descZh ?? p.description ?? '暂无描述'}
              {p.descZh && p.description ? <div style={{ marginTop: 6, fontSize: 12.5, color: 'var(--dsw2-muted)' }}>{p.description}</div> : null}
            </div>
            <div className="dsw2-modal-meta">
              <span>语言：<b>{p.language || '—'}</b></span>
              <span>协议：<b>{p.license || '—'}</b></span>
              <span>创建：<b>{fmtTime(p.createdAt)}</b></span>
              <span>最近更新：<b>{fmtTime(p.pushedAt)}</b></span>
              <span>分类：<b>{p.curatedCategory ?? categorize(p)}</b></span>
              <span>标签：<b>{(p.topics ?? []).slice(0, 4).join(', ') || '—'}</b></span>
            </div>
            <div className="dsw2-modal-links">
              <a className="dsw2-btn ghost small" href={p.url} target="_blank" rel="noreferrer">打开 GitHub</a>
              {p.homepage ? (
                <a className="dsw2-btn ghost small" href={p.homepage} target="_blank" rel="noreferrer">官网 / 文档</a>
              ) : null}
            </div>
            <div className="dsw2-modal-actions">
              {isInstalled ? (
                <>
                  <span className="dsw2-tag lang">已安装</span>
                  <button className="dsw2-btn red small" disabled={busy === p.name} onClick={() => { setDetail(null); void doUninstall(p) }}>
                    {busy === p.name ? <span className="dsw2-spinner" /> : '卸载'}
                  </button>
                  <button className="dsw2-btn small" disabled={busy === p.name} onClick={() => void doInstall(p)}>
                    重新安装 / 更新
                  </button>
                </>
              ) : (
                <>
                  <button className="dsw2-btn green" disabled={busy === p.name} onClick={() => void doInstall(p)}>
                    {busy === p.name ? <span className="dsw2-spinner" /> : '一键安装（自动选源）'}
                  </button>
                  <button className="dsw2-btn" disabled={busy === p.name} onClick={() => void doInstall(p, `github:${p.fullName}`)}>
                    从 GitHub 安装
                  </button>
                </>
              )}
            </div>
            <div className="dsw2-src">
              <span style={{ fontSize: 12, color: 'var(--dsw2-muted)' }}>等效命令：</span>
              <code className="dsw2-src-code">dsh plugin --profile web add {p.name}</code>
            </div>
          </Modal>
        )
      })()}

      <div className="dsw2-toast-zone">
        {toasts.map((t) => (
          <div key={t.id} className={`dsw2-toast ${t.kind}`}>{t.text}</div>
        ))}
      </div>
    </div>
  )
}
//#endregion

/** 组装浏览器 API（同源 REST 调用）。 */
function buildApi(): WorkshopApi {
  return {
    loadCatalog: async () => {
      const res = await fetch('/dsh-workshop/catalog', { cache: 'no-store' })
      if (!res.ok) throw new Error(`目录加载失败：HTTP ${res.status}`)
      return res.json()
    },
    install: async (source) => {
      const res = await fetch('/dsh-workshop/install', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ source }),
      })
      const body = await res.json().catch(() => ({ ok: false, output: `HTTP ${res.status}` }))
      return { ok: !!body.ok, output: String(body.output ?? body.error ?? ''), fallback: !!body.fallback, usedSource: body.usedSource ?? null, hotMount: body.hotMount ?? null, restarting: !!body.restarting }
    },
    uninstall: async (id) => {
      const res = await fetch('/dsh-workshop/uninstall', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ id }),
      })
      const body = await res.json().catch(() => ({ ok: false, output: `HTTP ${res.status}` }))
      return { ok: !!body.ok, output: String(body.output ?? body.error ?? ''), restarting: !!body.restarting, hotMount: body.hotMount ?? null }
    },
    restart: async () => {
      const res = await fetch('/dsh-workshop/restart', { method: 'POST' })
      const body = await res.json().catch(() => ({ ok: false }))
      return { ok: !!body.ok, restarting: !!body.restarting }
    },
    refresh: async () => {
      const res = await fetch('/dsh-workshop/refresh', { method: 'POST' })
      const body = await res.json().catch(() => ({ ok: false }))
      return { ok: !!body.ok, total: body.total }
    },
    progress: async () => {
      const res = await fetch('/dsh-workshop/progress', { cache: 'no-store' })
      const body = await res.json().catch(() => ({ active: false, source: '', stage: '', lines: [], ok: false }))
      return { active: !!body.active, source: String(body.source ?? ''), stage: String(body.stage ?? ''), lines: Array.isArray(body.lines) ? body.lines.map(String) : [], ok: !!body.ok }
    },
    mirror: async () => {
      const res = await fetch('/dsh-workshop/mirror', { cache: 'no-store' })
      const body = await res.json().catch(() => ({ name: 'github.com 直连', base: '', latencyMs: null, ok: true }))
      return { name: String(body.name ?? '—'), base: String(body.base ?? ''), latencyMs: body.latencyMs ?? null, ok: !!body.ok }
    },
    retestMirrors: async () => {
      const res = await fetch('/dsh-workshop/mirror/retest', { method: 'POST' })
      const body = await res.json().catch(() => ({ ok: false }))
      return { ok: !!body.ok, chosen: body.chosen ?? null }
    },
  }
}

/** 挂载侧边栏入口 + 中央列面板（自愈 DOM 注入，异常只降级不炸 GUI）。 */
export function apply(): void {
  let disposers: Array<() => void> = []
  try {
    const controller = new WorkshopController()
    const api = buildApi()
    disposers.push(mountSidebarEntry(controller, true))
    disposers.push(mountWorkshopView(controller, () => <WorkshopTab {...api} />))
  } catch (error) {
    console.error('[dsh-workshop] mount failed:', error)
  }
}
