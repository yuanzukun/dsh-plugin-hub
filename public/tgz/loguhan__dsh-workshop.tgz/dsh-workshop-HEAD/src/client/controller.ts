/**
 * 创意工坊面板控制器：打开/关闭状态 + 中央列独占切换（与 task-board / ssh 互斥）。
 */

const ACTIVE_ATTR = 'data-dsh-workshop-active'
/** 其它面板的激活属性（打开时移除，保证中央列单占用）。 */
const OTHER_ACTIVE_ATTRS = ['data-dsh-taskboard-active', 'data-dsh-ssh-active'] as const
/** 跨插件激活事件（task-board / ssh 同协议）。 */
const ACTIVATE_EVENT = 'dsh-panel-activate'
export const PANEL_NAME = 'workshop'

export class WorkshopController {
  private open = false
  private listeners = new Set<() => void>()

  isOpen(): boolean {
    return this.open
  }

  toggle(): void {
    this.setOpen(!this.open)
  }

  setOpen(v: boolean): void {
    if (this.open === v) return
    this.open = v
    if (v) {
      for (const attr of OTHER_ACTIVE_ATTRS) document.documentElement.removeAttribute(attr)
      document.documentElement.setAttribute(ACTIVE_ATTR, '')
    } else {
      document.documentElement.removeAttribute(ACTIVE_ATTR)
    }
    document.dispatchEvent(new CustomEvent(ACTIVATE_EVENT, { detail: PANEL_NAME }))
    for (const fn of this.listeners) fn()
  }

  /** 其它面板激活时本面板自动关闭。 */
  onOtherActivate = (event: Event): void => {
    if ((event as CustomEvent).detail !== PANEL_NAME && this.open) this.setOpen(false)
  }

  subscribe(fn: () => void): () => void {
    this.listeners.add(fn)
    return () => { this.listeners.delete(fn) }
  }
}

/** 点击侧边栏会话/项目行时归还中央列（捕获阶段）。 */
export const SIDEBAR_ROW_SELECTOR =
  '[class*="sessionRow"], [class*="projectRow"], [class*="searchResultRow"], [class*="searchResultWorkspace"], [class*="newSession"]'
