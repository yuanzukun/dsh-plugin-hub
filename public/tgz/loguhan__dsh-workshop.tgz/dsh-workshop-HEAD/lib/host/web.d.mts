import { t as CoreConfig } from "./core-C2tWw7De.mjs";
import { Context } from "@deepseek-ai/cordis";
//#region src/host/web.d.ts
declare const name = "dsh-workshop-web";
declare const inject: string[];
type Config = Pick<CoreConfig, 'cachePath' | 'dataUrl' | 'backupUrl'> & {
  profileName?: string;
};
declare function apply(ctx: Context, config: Config): void;
//#endregion
export { Config, apply, inject, name };
//# sourceMappingURL=web.d.mts.map