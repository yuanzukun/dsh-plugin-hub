import { t as CoreConfig } from "./core-C2tWw7De.mjs";
//#region src/host/index.d.ts
declare const name = "dsh-workshop";
declare const inject: string[];
type Config = CoreConfig;
declare function apply(ctx: {
  tools: {
    register: (t: unknown) => unknown;
  };
}, config: Config): void;
//#endregion
export { Config, apply, inject, name };
//# sourceMappingURL=index.d.mts.map