//#region src/core.d.ts
interface CoreConfig {
  dataUrl: string;
  backupUrl?: string;
  cachePath: string;
  profileName?: string;
}
//#endregion
export { CoreConfig as t };
//# sourceMappingURL=core-C2tWw7De.d.mts.map