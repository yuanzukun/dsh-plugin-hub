/**
 * 部署同步：把构建产物同步到本地 profile 的 node_modules/dsh-workshop 拷贝。
 * nodeLinker: hoisted 会把 link: 依赖硬拷贝进 profile，构建后必须同步，
 * 否则运行中的 dsh web 加载的是旧代码。
 */
import { cpSync, mkdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { homedir } from 'node:os'

const dshHome = process.env.DSH_HOME ?? join(homedir(), '.dsh')
const profile = process.argv[2] ?? 'web'
const dest = join(dshHome, 'profiles', profile, 'node_modules', 'dsh-workshop')

mkdirSync(dest, { recursive: true })
cpSync('lib', join(dest, 'lib'), { recursive: true, force: true })
for (const f of ['package.json', 'cordis.patch.yml', 'README.md', 'LICENSE']) {
  try {
    cpSync(f, join(dest, f), { force: true })
  } catch { /* 文件不存在则跳过 */ }
}
const pkg = JSON.parse(readFileSync('package.json', 'utf8'))
console.log(`[deploy] synced dsh-workshop@${pkg.version} -> ${dest}`)
console.log('[deploy] restart dsh web to load the new code')
