import { pathToFileURL } from 'node:url'

const [, , playwrightPath, htmlPath, outputPath, browserPath] = process.argv
if (!playwrightPath || !htmlPath || !outputPath) {
  throw new Error('usage: node render-preview.mjs <playwright-entry> <html> <output>')
}
const { chromium } = await import(pathToFileURL(playwrightPath).href)
const browser = await chromium.launch({ headless: true, ...(browserPath ? { executablePath: browserPath } : {}) })
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 })
  await page.goto(pathToFileURL(htmlPath).href)
  await page.evaluate(() => document.fonts.ready)
  const bundledFontsReady = await page.evaluate(() => ({
    exo: document.fonts.check('600 16px "Arc Exo"', 'MEMORY'),
    noto: document.fonts.check('400 16px "Arc Noto Sans CJK SC"', '字体已内置')
  }))
  if (!bundledFontsReady.exo || !bundledFontsReady.noto) {
    throw new Error(`bundled fonts failed to load: ${JSON.stringify(bundledFontsReady)}`)
  }
  const settingsOverlay = page.locator('[data-settings-overlay]')
  if (await settingsOverlay.count() > 0) {
    const bounds = await settingsOverlay.boundingBox()
    const viewport = page.viewportSize()
    const fillsViewport = bounds !== null && viewport !== null
      && Math.abs(bounds.x) < 1 && Math.abs(bounds.y) < 1
      && Math.abs(bounds.width - viewport.width) < 1
      && Math.abs(bounds.height - viewport.height) < 1
    if (!fillsViewport) throw new Error(`settings overlay is clipped: ${JSON.stringify({ bounds, viewport })}`)
  }
  await page.waitForTimeout(650)
  await page.screenshot({ path: outputPath, fullPage: true })
} finally {
  await browser.close()
}
