import assert from 'node:assert/strict'
import { mkdir, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

// Install the theme into an isolated DSH_HOME with Desktop's bundled CLI
// first. This test creates drafts and changes preferences only in that home.
const [, , playwrightPath, executablePath, testHome, outputPath] = process.argv
if (!playwrightPath || !executablePath || !testHome || !outputPath) {
  throw new Error('usage: node inspect-desktop.mjs <playwright-entry> <desktop-exe> <isolated-dsh-home> <output-dir>')
}
const home = resolve(testHome)
assert.notEqual(home.toLowerCase(), resolve(homedir(), '.dsh').toLowerCase(), 'Never test against the user profile')
const output = resolve(outputPath)
await mkdir(output, { recursive: true })
const { _electron } = await import(pathToFileURL(playwrightPath).href)
const env = { ...process.env, DSH_HOME: home }
delete env.ELECTRON_RUN_AS_NODE
const report = { checks: [], errors: [] }
const app = await _electron.launch({
  executablePath,
  args: [`--user-data-dir=${home}/electron`, '--disable-backgrounding-occluded-windows', '--disable-renderer-backgrounding'],
  env,
  timeout: 60000
})
let page
const check = (name, details = {}) => {
  report.checks.push({ name, ...details })
  console.log(`PASS ${name}`)
}
async function capture(name) {
  // Native capture requests a fresh frame even while the test window is
  // hidden. CDP screenshots can stall on hidden Electron windows on Windows.
  const png = await app.evaluate(async ({ BrowserWindow }) => {
    const win = BrowserWindow.getAllWindows().find(w => w.webContents.getURL().startsWith('dsh-app://app/'))
    win.setPosition(-10000, -10000)
    win.showInactive()
    win.webContents.invalidate()
    await new Promise(resolve => setTimeout(resolve, 180))
    return (await win.webContents.capturePage(undefined, { stayHidden: true, stayAwake: true })).toPNG().toString('base64')
  })
  await writeFile(resolve(output, `${name}.png`), Buffer.from(png, 'base64'))
}
async function bounds(locator, name) {
  await locator.waitFor({ state: 'visible' })
  const result = await locator.evaluate(e => {
    const r = e.getBoundingClientRect()
    const x = r.left + r.width / 2
    const y = r.top + r.height / 2
    return {
      rect: r.toJSON(), viewport: { width: innerWidth, height: innerHeight },
      hit: e.contains(document.elementFromPoint(x, y))
    }
  })
  const { rect: r, viewport: v } = result
  assert.ok(r.width > 0 && r.height > 0, `${name} has no size`)
  assert.ok(r.left >= -1 && r.top >= -1 && r.right <= v.width + 1 && r.bottom <= v.height + 1, `${name} leaves viewport: ${JSON.stringify(result)}`)
  assert.ok(result.hit, `${name} is covered at its center`)
  return result
}
async function settings() {
  await page.getByRole('button', { name: '账号菜单', exact: true }).click()
  await page.getByRole('menuitem', { name: /设置/ }).click()
  await bounds(page.getByRole('dialog'), 'settings')
}
async function closeSettings() {
  await page.getByRole('dialog').getByRole('button', { name: '关闭', exact: true }).click()
  await page.getByRole('dialog').waitFor({ state: 'hidden' })
}
async function resize(width, height) {
  const actual = await app.evaluate(({ BrowserWindow }, size) => {
    const win = BrowserWindow.getAllWindows().find(w => w.webContents.getURL().startsWith('dsh-app://app/'))
    win.setSize(size.width, size.height)
    return win.getContentSize()
  }, { width, height })
  await page.waitForFunction(([width, height]) => Math.abs(innerWidth - width) <= 2 && Math.abs(innerHeight - height) <= 2, actual)
  report.checks.push({ name: 'native resize', requested: { width, height }, actual: await page.evaluate(() => ({ width: innerWidth, height: innerHeight })) })
}
try {
  report.desktop = await app.evaluate(({ app, BrowserWindow }) => {
    for (const win of BrowserWindow.getAllWindows()) {
      win.webContents.setBackgroundThrottling(false)
      win.hide()
    }
    return { version: app.getVersion(), userData: app.getPath('userData') }
  })
  for (let attempt = 0; attempt < 160; attempt++) {
    page = app.windows().find(win => win.url().startsWith('dsh-app://app/'))
    if (page) break
    await new Promise(r => setTimeout(r, 250))
  }
  assert.ok(page, 'Desktop main window did not open')
  page.setDefaultTimeout(10000)
  page.on('pageerror', error => report.errors.push(error.message))
  await page.waitForSelector('style[data-plugin="dsh-arcaea-theme"]', { state: 'attached', timeout: 45000 })
  await page.waitForFunction(() => getComputedStyle(document.body).getPropertyValue('--dsw-alias-label-primary').trim() === '#241d29')
  await page.locator('[class*="_composerStack"]').waitFor()
  const openSidebar = page.getByRole('button', { name: '打开侧边栏', exact: true })
  if (await openSidebar.isVisible()) await openSidebar.click()
  report.surfaces = await page.evaluate(() => [...document.querySelectorAll('[class*="_centerCol"], [data-slot="main.conversation"] > div')].map(e => ({
    class: e.className, background: getComputedStyle(e).backgroundColor,
    hasBackgroundImage: getComputedStyle(e).backgroundImage !== 'none'
  })))
  assert.equal(report.surfaces[0].hasBackgroundImage, true, 'desktop chrome must not reset the background artwork')
  check('official Desktop loads the installed plugin')

  const fonts = await page.evaluate(async () => {
    await Promise.all([
      document.fonts.load('600 16px "Arc Exo"', 'MEMORY'),
      ...[300, 400, 700].map(w => document.fonts.load(`${w} 16px "Arc Noto Sans CJK SC"`, '中文字体测试'))
    ])
    return [...document.fonts].filter(f => f.family.startsWith('Arc ')).map(f => ({ family: f.family, weight: f.weight, status: f.status }))
  })
  assert.equal(fonts.length, 4)
  assert.ok(fonts.every(f => f.status === 'loaded'))
  check('all four bundled font faces load', { fonts })

  const artwork = await page.evaluate(async () => {
    const targets = [
      ['main', '[class*="_centerCol"]'],
      ['sidebar', '[class*="_sidebarCol"]'],
      ['new-session', 'button[class$="_newSession"]']
    ]
    return Promise.all(targets.map(async ([name, selector]) => {
      const background = getComputedStyle(document.querySelector(selector)).backgroundImage
      const url = background.match(/url\("(data:image\/[^\"]+)"\)/)?.[1]
      if (!url) throw new Error(`${name} artwork is not embedded`)
      const image = new Image()
      image.src = url
      await image.decode()
      return { name, width: image.naturalWidth, height: image.naturalHeight }
    }))
  })
  assert.equal(artwork.length, 3)
  assert.ok(artwork.every(image => image.width > 0 && image.height > 0))
  check('all three bundled Arcaea images decode without external URLs', { artwork })
  const sidebarSurface = await page.locator('[class*="_sidebarCol"] [class*="_root"]:has(> [class*="_logoRow"])').evaluate(e => getComputedStyle(e).backgroundColor)
  assert.equal(sidebarSurface, 'rgba(0, 0, 0, 0)', 'sidebar content must not cover its artwork')

  const composer = page.locator('[class*="_composerStack"] :is([class$="_card"], [class*="_card "])')
  const editor = composer.getByRole('textbox')
  const geometry = await composer.evaluate(e => ({
    clip: getComputedStyle(e).clipPath,
    border: getComputedStyle(e).borderWidth,
    edgeClip: getComputedStyle(e, '::after').clipPath,
    childCards: e.querySelectorAll('[class*="_card"]').length
  }))
  assert.equal(geometry.clip, 'none')
  assert.equal(geometry.border, '0px')
  assert.match(geometry.edgeClip, /^polygon\(/)
  await editor.fill('桌面端主题测试 / Arcaea\n第二行光标测试')
  assert.match(await editor.innerText(), /第二行光标测试/)
  await editor.press('End')
  assert.ok(await editor.evaluate(e => e.contains(getSelection().anchorNode)))
  await editor.press('Control+A')
  await editor.press('Backspace')
  await page.waitForFunction(() => !document.querySelector('[role="textbox"][contenteditable]').textContent.trim())
  check('angular composer preserves editing, multiline caret and unclipped content', geometry)

  for (const [name, label] of [
    ['permissions', '访问模式，当前：工作区内修改'],
    ['attachments', '添加文件或调用指令'],
    ['models', '请选择模型'],
    ['workspace', '选择工作区']
  ]) {
    await page.getByRole('button', { name: label, exact: true }).click()
    const popup = page.locator('[role="menu"], [role="listbox"], [role="dialog"], [data-menu-material]').filter({ visible: true }).last()
    await bounds(popup, name)
    await capture(`menu-${name}`)
    await page.keyboard.press('Escape')
    await popup.waitFor({ state: 'hidden' })
    check(`${name} popup fits and receives pointer hits`)
  }

  await settings()
  await capture('settings')
  const dialog = page.getByRole('dialog')
  for (const name of ['模型', '内置插件', 'Agent 预设', '通用设置']) {
    await dialog.getByRole('button', { name, exact: true }).click()
    await bounds(dialog, name)
    assert.ok((await dialog.innerText()).length > 60, `${name} has no content`)
    check(`settings / ${name} opens`)
  }
  await dialog.getByRole('button', { name: '更多字体设置', exact: true }).click()
  const family = dialog.getByRole('textbox', { name: '正文字体', exact: true })
  await family.fill('Arc Noto Sans CJK SC')
  await family.press('Tab')
  await page.waitForFunction(() => getComputedStyle(document.body).getPropertyValue('--dsh-font-family-text').includes('Arc Noto'))
  await page.waitForFunction(() => getComputedStyle(document.querySelector('[role="textbox"][contenteditable]')).fontFamily.startsWith('"Arc Noto'))
  await family.fill('')
  await family.press('Tab')
  await page.waitForFunction(() => getComputedStyle(document.querySelector('[role="textbox"][contenteditable]')).fontFamily.startsWith('"Arc Exo'))
  await dialog.getByRole('button', { name: '增大字号', exact: true }).click()
  await page.waitForFunction(() => getComputedStyle(document.querySelector('[role="textbox"][contenteditable]')).fontSize === '15px')
  await dialog.getByRole('button', { name: '减小字号', exact: true }).click()
  await page.waitForFunction(() => getComputedStyle(document.querySelector('[role="textbox"][contenteditable]')).fontSize === '14px')
  assert.equal(await page.locator('style[data-plugin="dsh-arcaea-theme"]').count(), 1)
  await page.waitForFunction(() => getComputedStyle(document.body).getPropertyValue('--dsw-alias-label-primary').trim() === '#241d29')
  check('font preferences and size updates preserve the enabled palette')
  await closeSettings()

  await page.getByRole('button', { name: '收起侧边栏', exact: true }).click()
  await page.locator('[data-sidebar-collapsed]').waitFor()
  await bounds(page.getByRole('button', { name: '打开侧边栏', exact: true }), 'collapsed toggle')
  const compactNew = page.locator('button[class$="_newSession"]')
  await bounds(compactNew, 'collapsed new session')
  assert.equal(await compactNew.evaluate(e => getComputedStyle(e).clipPath), 'none')
  await capture('collapsed')
  await page.getByRole('button', { name: '打开侧边栏', exact: true }).click()
  check('collapsed sidebar controls remain usable in native titlebar')

  await page.getByRole('button', { name: '打开右侧边栏', exact: true }).click()
  await bounds(page.locator('[data-rightbar-col]'), 'right panel')
  await capture('right-panel')
  await page.getByRole('button', { name: '收起右侧边栏', exact: true }).click()
  check('right panel opens without covering composer controls')

  await page.getByRole('button', { name: '插件', exact: true }).click()
  await page.getByText('dsh-arcaea-theme', { exact: false }).first().waitFor()
  await capture('plugins')
  check('plugin manager displays the installed theme')
  await page.locator('button[class$="_newSession"]').click()
  await composer.waitFor()

  for (const [width, height] of [[1440, 900], [1024, 700], [520, 600]]) {
    await resize(width, height)
    await bounds(composer, `composer ${width}`)
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1)
    assert.equal(overflow, false, `horizontal overflow at ${width}`)
    await capture(`desktop-${width}`)
    const expand = page.getByRole('button', { name: '打开侧边栏', exact: true })
    if (await expand.isVisible()) await expand.click()
    await settings()
    await bounds(page.getByRole('dialog'), `settings ${width}`)
    await capture(`settings-${width}`)
    await closeSettings()
    check(`${width}×${height} composer and settings fit`)
  }
  assert.deepEqual(report.errors, [], 'Renderer exceptions')
  check('no renderer exceptions during interaction tests')
} catch (error) {
  report.failure = error.stack
  if (page) {
    await capture('failure').catch(() => {})
    await writeFile(resolve(output, 'failure.txt'), await page.locator('body').innerText().catch(() => ''))
  }
  throw error
} finally {
  await writeFile(resolve(output, 'report.json'), JSON.stringify(report, null, 2))
  await app.close()
}
