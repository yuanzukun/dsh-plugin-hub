import assert from 'node:assert/strict'
import { mkdir, writeFile } from 'node:fs/promises'
import { pathToFileURL } from 'node:url'

const [, , playwrightPath, baseUrl, outputDir, browserPath] = process.argv
if (!playwrightPath || !baseUrl || !outputDir || !browserPath) {
  throw new Error('usage: node inspect-live-ui.mjs <playwright-entry> <base-url> <output-dir> <browser>')
}

const { chromium } = await import(pathToFileURL(playwrightPath).href)
await mkdir(outputDir, { recursive: true })
const browser = await chromium.launch({ headless: true, executablePath: browserPath })
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 })
  const consoleErrors = []
  const failedRequests = []
  page.on('console', (message) => {
    if (message.type() === 'error') consoleErrors.push(message.text())
  })
  page.on('pageerror', (error) => { consoleErrors.push(error.message) })
  page.on('requestfailed', (request) => {
    failedRequests.push({ url: request.url(), error: request.failure()?.errorText })
  })

  await page.goto(baseUrl, { waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(2500)
  await page.screenshot({ path: `${outputDir}/main.png`, fullPage: true })
  const snapshot = await page.evaluate(() => {
    const visible = (element) => {
      const rect = element.getBoundingClientRect()
      const style = getComputedStyle(element)
      return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none'
    }
    const composer = document.querySelector('[class*="_composerStack"] [class*="_card"]')
    const textarea = document.querySelector('textarea')
    const composerStyle = composer ? getComputedStyle(composer) : null
    const loadedFonts = [...document.fonts].map(font => ({
      family: font.family,
      status: font.status,
      weight: font.weight,
    })).filter(font => /Arc (?:Exo|Noto)/.test(font.family))
    return ({
    title: document.title,
    bodyClass: document.body.className,
    viewport: { width: innerWidth, height: innerHeight },
    documentWidth: document.documentElement.scrollWidth,
    hasHorizontalOverflow: document.documentElement.scrollWidth > innerWidth + 1,
    loadedFonts,
    composer: composer && composerStyle ? {
      rect: composer.getBoundingClientRect().toJSON(),
      clipPath: composerStyle.clipPath,
      borderWidth: composerStyle.borderWidth,
      outlineClipPath: getComputedStyle(composer, '::after').clipPath,
      overflow: composerStyle.overflow,
      borderRadius: composerStyle.borderRadius,
      textareaInside: textarea ? composer.contains(textarea) : false,
      visible: visible(composer),
    } : null,
    themeStyle: [...document.querySelectorAll('style')].map((style) => ({
      plugin: style.dataset.plugin,
      css: style.dataset.pluginCss,
      length: style.textContent?.length ?? 0,
    })).filter((style) => style.plugin || style.css),
    visualLayers: [...document.querySelectorAll('[data-arcaea-theme-layer]')].map((node) => ({
      parentClass: node.parentElement?.className,
      rect: node.getBoundingClientRect().toJSON(),
    })),
    buttons: [...document.querySelectorAll('button')].map((button) => ({
      text: button.textContent?.trim().replace(/\s+/g, ' ').slice(0, 100),
      aria: button.getAttribute('aria-label'),
      title: button.getAttribute('title'),
      className: button.className,
      rect: button.getBoundingClientRect().toJSON(),
    })),
    textareas: [...document.querySelectorAll('textarea')].map((textarea) => ({
      placeholder: textarea.placeholder,
      className: textarea.className,
      rect: textarea.getBoundingClientRect().toJSON(),
      ancestors: [...function* () {
        let node = textarea.parentElement
        for (let depth = 0; node && depth < 6; depth += 1, node = node.parentElement) {
          yield { tag: node.tagName, className: node.className }
        }
      }()],
    })),
    dialogs: [...document.querySelectorAll('[role="dialog"]')].map((dialog) => ({
      hidden: dialog.getAttribute('aria-hidden'),
      className: dialog.className,
      rect: dialog.getBoundingClientRect().toJSON(),
    })),
  })})

  const inspectPopup = async (trigger, name) => {
    assert.equal(await trigger.count(), 1, `${name} trigger was not found`)
    await trigger.click()
    await page.waitForTimeout(200)
    await page.screenshot({ path: `${outputDir}/${name}.png`, fullPage: true })
    const popup = await page.evaluate(() => {
      const candidates = [...document.querySelectorAll(
        '[role="menu"], [role="listbox"], [class*="_portal"], [class*="_popup"], [class*="_popover"]',
      )].filter((element) => {
        const rect = element.getBoundingClientRect()
        const style = getComputedStyle(element)
        return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden'
      })
      const element = candidates.at(-1)
      if (!element) return null
      const rect = element.getBoundingClientRect()
      const x = rect.left + rect.width / 2
      const y = rect.top + Math.min(rect.height / 2, 24)
      const top = document.elementFromPoint(x, y)
      return {
        tag: element.tagName,
        role: element.getAttribute('role'),
        className: element.className,
        rect: rect.toJSON(),
        withinViewport: rect.left >= 0 && rect.top >= 0 && rect.right <= innerWidth && rect.bottom <= innerHeight,
        unobscured: top === element || element.contains(top),
      }
    })
    await page.keyboard.press('Escape')
    return popup
  }

  const settingsButton = page.getByRole('button', { name: '设置', exact: true })
  await settingsButton.click()
  const dialog = page.getByRole('dialog')
  await dialog.waitFor({ state: 'visible' })
  await page.waitForTimeout(200)
  await page.screenshot({ path: `${outputDir}/settings.png`, fullPage: true })
  const settings = await dialog.evaluate((element) => {
    const rect = element.getBoundingClientRect()
    const x = rect.left + rect.width / 2
    const y = rect.top + rect.height / 2
    const top = document.elementFromPoint(x, y)
    return {
      rect: rect.toJSON(),
      withinViewport: rect.left >= 0 && rect.top >= 0 && rect.right <= innerWidth && rect.bottom <= innerHeight,
      unobscured: top === element || element.contains(top),
      topClass: top?.className ?? null,
    }
  })
  const settingsSections = []
  const settingsNavButtons = dialog.locator('nav button')
  const settingsNavCount = await settingsNavButtons.count()
  for (let index = 0; index < settingsNavCount; index += 1) {
    const button = settingsNavButtons.nth(index)
    const label = (await button.textContent())?.trim() ?? `section-${index}`
    await button.click()
    await page.waitForTimeout(60)
    settingsSections.push({
      label,
      active: await button.getAttribute('aria-current') === 'true',
      visible: await button.isVisible(),
    })
  }
  await page.screenshot({ path: `${outputDir}/settings-sections.png`, fullPage: true })
  await page.keyboard.press('Escape')
  await dialog.waitFor({ state: 'detached' })

  const workspacePopup = await inspectPopup(
    page.getByRole('button', { name: '选择工作区', exact: true }),
    'workspace-menu',
  )
  const presetPopup = await inspectPopup(
    page.locator('button[title*="Agent 预设"]'),
    'preset-menu',
  )
  const permissionPopup = await inspectPopup(
    page.locator('button[aria-label^="访问模式"]'),
    'permission-menu',
  )
  const modelPopup = await inspectPopup(
    page.locator('button[aria-label^="选择模型"]'),
    'model-menu',
  )

  await page.setViewportSize({ width: 1024, height: 700 })
  await settingsButton.click()
  await dialog.waitFor({ state: 'visible' })
  await page.waitForTimeout(150)
  await page.screenshot({ path: `${outputDir}/settings-compact.png`, fullPage: true })
  const compactSettings = await dialog.evaluate((element) => {
    const rect = element.getBoundingClientRect()
    return {
      rect: rect.toJSON(),
      withinViewport: rect.left >= 0 && rect.top >= 0 && rect.right <= innerWidth && rect.bottom <= innerHeight,
    }
  })

  const result = {
    snapshot,
    settings,
    settingsSections,
    compactSettings,
    workspacePopup,
    presetPopup,
    permissionPopup,
    modelPopup,
    consoleErrors,
    failedRequests,
  }
  await writeFile(`${outputDir}/snapshot.json`, JSON.stringify(result, null, 2))
  process.stdout.write(JSON.stringify(result, null, 2))

  assert.ok(snapshot.themeStyle.some(style => style.plugin === 'dsh-arcaea-theme'), 'theme stylesheet was not mounted')
  assert.equal(snapshot.visualLayers.length, 0, 'background artwork must not insert nodes into host layout')
  assert.equal(snapshot.hasHorizontalOverflow, false, 'page has horizontal overflow')
  assert.ok(snapshot.composer?.visible, 'composer is not visible')
  assert.equal(snapshot.composer?.clipPath, 'none', 'composer must not use a clipped rectangular border')
  assert.equal(snapshot.composer?.borderWidth, '0px', 'composer root must not draw a rectangular border')
  assert.notEqual(snapshot.composer?.outlineClipPath, 'none', 'composer angular outline is missing')
  assert.equal(settings.withinViewport, true, 'settings dialog is clipped outside the viewport')
  assert.equal(settings.unobscured, true, 'settings dialog is obscured')
  assert.ok(settingsSections.length >= 3, 'settings navigation sections are missing')
  assert.equal(settingsSections.every(section => section.active && section.visible), true, 'a settings section cannot be opened')
  assert.equal(compactSettings.withinViewport, true, 'compact settings dialog is clipped outside the viewport')
  for (const [name, popup] of Object.entries({ workspacePopup, presetPopup, permissionPopup, modelPopup })) {
    assert.ok(popup, `${name} did not open`)
    assert.equal(popup.withinViewport, true, `${name} is clipped outside the viewport`)
    assert.equal(popup.unobscured, true, `${name} is obscured`)
  }
} finally {
  await browser.close()
}
