import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const source = await readFile(resolve(root, 'src/client.js'), 'utf8')
let factoryBody = source
  .replace('export const inject =', 'const inject =')
  .replace('export function apply(ctx)', 'function apply(ctx)')

const embeddedFonts = [
  ['__ARC_FONT_EXO__', 'Exo-Variable.ttf', 'font/ttf'],
  ['__ARC_FONT_NOTO_LIGHT__', 'NotoSansCJKsc-Light.otf', 'font/otf'],
  ['__ARC_FONT_NOTO_REGULAR__', 'NotoSansCJKsc-Regular.otf', 'font/otf'],
  ['__ARC_FONT_NOTO_BOLD__', 'NotoSansCJKsc-Bold.otf', 'font/otf'],
]
for (const [token, filename, mime] of embeddedFonts) {
  const bytes = await readFile(resolve(root, 'assets/fonts', filename))
  if (!factoryBody.includes(token)) throw new Error(`client source is missing font token ${token}`)
  factoryBody = factoryBody.replaceAll(token, `data:${mime};base64,${bytes.toString('base64')}`)
}

if (factoryBody === source || /^(?:export|import)\s/m.test(factoryBody)) {
  throw new Error('client source contains an unsupported ESM declaration')
}

const bundle = `window.__ModuleLoader__.load({
  id: "dsh-arcaea-theme",
  factory: (_require) => {
    var module = { exports: {} };
    var exports = module.exports;
${indent(factoryBody, 4)}
    exports.inject = inject;
    exports.apply = apply;
    return module.exports;
  }
});
`

await mkdir(resolve(root, 'dist'), { recursive: true })
await copyFile(resolve(root, 'src/index.js'), resolve(root, 'dist/index.js'))
await writeFile(resolve(root, 'dist/client.js'), bundle, 'utf8')

function indent(value, spaces) {
  const prefix = ' '.repeat(spaces)
  return value.split('\n').map(line => line === '' ? '' : prefix + line).join('\n')
}
