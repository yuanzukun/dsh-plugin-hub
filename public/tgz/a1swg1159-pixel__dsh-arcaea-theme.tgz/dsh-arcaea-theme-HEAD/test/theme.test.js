import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'
import { fileURLToPath } from 'node:url'
import { runInNewContext } from 'node:vm'
import { apply, inject } from '../src/client.js'

test('declares the theme service dependency', () => {
  assert.deepEqual(inject, ['theme'])
})

test('installs paired tokens and disposes them', () => {
  const originalDocument = globalThis.document
  delete globalThis.document
  let cleanup
  let disposed = false
  let received
  let preference = 'dark'
  const ctx = {
    effect(effect) { cleanup = effect() },
    on() { return () => {} },
    theme: {
      getTheme() { return { preference } },
      register() { return () => {} },
      setTheme(value) { preference = value },
      overrideTokens(source, tokens) {
        received = { source, tokens }
        return () => { disposed = true }
      }
    }
  }

  try {
    apply(ctx)
    assert.equal(received.source, 'dsh-arcaea-theme')
    assert.equal(preference, 'arcaea-light')
    assert.equal(typeof received.tokens['--dsw-alias-bg-base'].light, 'string')
    assert.equal(typeof received.tokens['--dsw-alias-bg-base'].dark, 'string')
    cleanup()
    assert.equal(disposed, true)
    assert.equal(preference, 'dark')
  } finally {
    if (originalDocument !== undefined) globalThis.document = originalDocument
  }
})

test('mounts and removes the prismatic memory visual layer', () => {
  const originalDocument = globalThis.document
  const mounted = []
  const createNode = (tag) => ({
    tag,
    dataset: {},
    textContent: '',
    innerHTML: '',
    setAttribute() {},
    remove() { this.removed = true }
  })
  globalThis.document = {
    querySelector() { return null },
    createElement: createNode,
    head: { appendChild(node) { mounted.push(node) } },
    body: { appendChild(node) { mounted.push(node) } }
  }
  let cleanup
  const ctx = {
    effect(effect) { cleanup = effect() },
    on() { return () => {} },
    theme: {
      getTheme() { return { preference: 'light' } },
      register() { return () => {} },
      setTheme() {},
      overrideTokens() { return () => {} }
    }
  }

  try {
    apply(ctx)
    assert.equal(mounted.length, 2)
    assert.match(mounted[0].textContent, /@font-face/)
    assert.match(mounted[0].textContent, /assets\/fonts\/Exo-Variable\.ttf/)
    assert.match(mounted[0].textContent, /assets\/fonts\/NotoSansCJKsc-Regular\.otf/)
    assert.doesNotMatch(mounted[0].textContent, /__ARC_FONT_BASE__/)
    assert.match(mounted[0].textContent, /button\[class\*="_newSession"\]/)
    assert.doesNotMatch(mounted[0].textContent, /\n\[class\*="_newSession"\]/)
    assert.doesNotMatch(mounted[0].textContent, /_sidebarCol[^}]*>\s*\*[^}]*backdrop-filter/s)
    assert.match(mounted[0].textContent, /_sidebarCol[^}]*\[role="dialog"\][^{]*\{[^}]*--dsw-alias-label-primary/s)
    assert.match(mounted[1].innerHTML, /dsh-memory-architecture/)
    assert.match(mounted[1].innerHTML, /dsh-memory-prisms/)
    assert.doesNotMatch(mounted[1].innerHTML, /SKY INPUT/)
    cleanup()
    assert.equal(mounted[0].removed, true)
    assert.equal(mounted[1].removed, true)
  } finally {
    if (originalDocument === undefined) delete globalThis.document
    else globalThis.document = originalDocument
  }
})

test('built client uses the DSH module-loader handoff', async () => {
  const path = fileURLToPath(new URL('../dist/client.js', import.meta.url))
  const bundle = await readFile(path, 'utf8')
  assert.match(bundle, /window\.__ModuleLoader__\.load/)
  assert.match(bundle, /id: "dsh-arcaea-theme"/)
  assert.match(bundle, /Exo-Variable\.ttf/)
  assert.match(bundle, /NotoSansCJKsc-Regular\.otf/)
  assert.match(bundle, /data:font\/ttf;base64,/)
  assert.match(bundle, /data:font\/otf;base64,/)
  assert.doesNotMatch(bundle, /__ARC_FONT_(?:EXO|NOTO_(?:LIGHT|REGULAR|BOLD))__/)
  assert.doesNotMatch(bundle, /\bexport\s/)

  let handoff
  const window = { __ModuleLoader__: { load(value) { handoff = value } } }
  runInNewContext(bundle, { window })
  assert.equal(handoff.id, 'dsh-arcaea-theme')
  const plugin = handoff.factory(() => { throw new Error('bundle must be self-contained') })
  assert.deepEqual([...plugin.inject], ['theme'])
  assert.equal(typeof plugin.apply, 'function')
})
