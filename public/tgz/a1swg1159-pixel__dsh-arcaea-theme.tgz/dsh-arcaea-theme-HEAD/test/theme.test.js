import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'
import { fileURLToPath } from 'node:url'
import { runInNewContext } from 'node:vm'
import { apply, inject } from '../src/client.js'

test('declares the theme service dependency', () => {
  assert.deepEqual(inject, ['theme'])
})

function harness() {
  const listeners = new Set()
  const themes = [{ id: 'system' }, { id: 'dark' }, { id: 'light' }]
  let preference = 'dark'
  let cleanup
  const snapshot = () => ({ preference, themes })
  const ctx = {
    effect(effect) { cleanup = effect() },
    on(event, fn) {
      assert.equal(event, 'theme/change')
      listeners.add(fn)
      return () => listeners.delete(fn)
    },
    theme: {
      getTheme: snapshot,
      register(definition) {
        themes.push(definition)
        return () => themes.splice(themes.indexOf(definition), 1)
      },
      setTheme(value) {
        preference = value
        for (const listener of listeners) listener(snapshot())
      }
    }
  }
  return { ctx, themes, listeners, dispose: () => cleanup() }
}

test('registers light tokens and restores the prior preference on disposal', () => {
  const host = harness()
  apply(host.ctx)
  assert.equal(host.ctx.theme.getTheme().preference, 'arcaea-light')
  const palette = host.themes.find(theme => theme.id === 'arcaea-light')
  assert.equal(palette.colorScheme, 'light')
  assert.equal(palette.tokens['--dsw-alias-label-primary'], '#241d29')
  assert.equal(palette.tokens['--dsw-specific-sidebar-fill'], '#eee9ef')
  assert.ok(Object.values(palette.tokens).every(value => typeof value === 'string'))
  host.dispose()
  assert.equal(host.ctx.theme.getTheme().preference, 'dark')
  assert.equal(host.themes.some(theme => theme.id === 'arcaea-light'), false)
  assert.equal(host.listeners.size, 0)
})

test('survives desktop preference adoption and font updates without remounting styles', async () => {
  const originalDocument = globalThis.document
  const mounted = []
  globalThis.document = {
    querySelector() { return null },
    createElement(tag) {
      assert.equal(tag, 'style')
      return { dataset: {}, textContent: '', remove() { this.removed = true } }
    },
    head: { appendChild(node) { mounted.push(node) } }
  }
  const host = harness()
  try {
    apply(host.ctx)
    const presented = []
    const stopPresenter = host.ctx.on('theme/change', snapshot => presented.push(snapshot.preference))
    assert.equal(mounted.length, 1)
    assert.match(mounted[0].textContent, /@font-face/)
    assert.match(mounted[0].textContent, /assets\/fonts\/NotoSansCJKsc-Regular\.otf/)
    assert.doesNotMatch(mounted[0].textContent, /__ARC_FONT_/)
    assert.match(mounted[0].textContent, /assets\/arcaea\/bg_select_light\.jpg/)
    assert.doesNotMatch(mounted[0].textContent, /__ARC_IMAGE_/)
    host.ctx.theme.setTheme('light')
    await Promise.resolve()
    assert.equal(presented.at(-1), 'arcaea-light', 'the last presenter must not paint a stale host snapshot')
    assert.equal(host.ctx.theme.getTheme().preference, 'arcaea-light')
    assert.equal(mounted[0].removed, undefined)
    assert.equal(mounted.length, 1)
    host.ctx.theme.setTheme('dark')
    await Promise.resolve()
    host.dispose()
    assert.equal(mounted[0].removed, true)
    assert.equal(host.ctx.theme.getTheme().preference, 'dark')
    stopPresenter()
  } finally {
    if (originalDocument === undefined) delete globalThis.document
    else globalThis.document = originalDocument
  }
})

test('restores system if the previously selected custom theme was removed', () => {
  const host = harness()
  host.themes.push({ id: 'temporary-theme' })
  host.ctx.theme.setTheme('temporary-theme')
  apply(host.ctx)
  host.themes.splice(host.themes.findIndex(theme => theme.id === 'temporary-theme'), 1)
  host.dispose()
  assert.equal(host.ctx.theme.getTheme().preference, 'system')
})

test('built client uses the DSH module-loader handoff', async () => {
  const path = fileURLToPath(new URL('../dist/client.js', import.meta.url))
  const bundle = await readFile(path, 'utf8')
  assert.match(bundle, /window\.__ModuleLoader__\.load/)
  assert.match(bundle, /id: "dsh-arcaea-theme"/)
  assert.match(bundle, /Exo-Variable\.ttf/)
  assert.match(bundle, /NotoSansCJKsc-Regular\.otf/)
  assert.match(bundle, /data:font\/ttf;base64,/)
  assert.match(bundle, /data:font\/otf;base64,/)
  assert.match(bundle, /data:image\/jpeg;base64,/)
  assert.match(bundle, /data:image\/png;base64,/)
  assert.doesNotMatch(bundle, /__ARC_IMAGE_(?:SELECT_LIGHT|SELECT_DARK|TITLE_MARKER)__/)
  assert.doesNotMatch(bundle, /__ARC_FONT_(?:EXO|NOTO_(?:LIGHT|REGULAR|BOLD))__/)
  assert.doesNotMatch(bundle, /\bexport\s/)

  let handoff
  const window = { __ModuleLoader__: { load(value) { handoff = value } } }
  runInNewContext(bundle, { window })
  assert.equal(handoff.id, 'dsh-arcaea-theme')
  const plugin = handoff.factory(() => { throw new Error('bundle must be self-contained') })
  assert.deepEqual([...plugin.inject], ['theme'])
  assert.equal(typeof plugin.apply, 'function')
})
