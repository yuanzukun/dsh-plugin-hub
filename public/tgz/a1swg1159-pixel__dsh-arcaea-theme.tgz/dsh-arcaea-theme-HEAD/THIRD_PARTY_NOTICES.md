# Third-party notices

The plugin code is MIT licensed. The font software below is distributed under the SIL Open Font License 1.1 and is not relicensed under MIT.

## Exo

- Packaged file: `assets/fonts/Exo-Variable.ttf`
- Upstream: https://github.com/google/fonts/tree/main/ofl/exo
- Copyright 2017 The Exo Project Authors
- License: `assets/fonts/OFL-Exo.txt`

## Noto Sans CJK SC

- Packaged files: `assets/fonts/NotoSansCJKsc-Light.otf`, `NotoSansCJKsc-Regular.otf`, and `NotoSansCJKsc-Bold.otf`
- Upstream project: https://github.com/notofonts/noto-cjk
- Copyright 2014-2021 Adobe, with Reserved Font Name “Source”
- License: `assets/fonts/OFL-NotoSansSC.txt`

The Noto binaries are compact Simplified Chinese builds selected from the local reference set. The OFL permits modified or subset font software to be bundled with software when its copyright notice and license accompany it. The plugin identifies these web faces internally as `Arc Noto Sans CJK SC` and does not use the reserved name “Source”.
