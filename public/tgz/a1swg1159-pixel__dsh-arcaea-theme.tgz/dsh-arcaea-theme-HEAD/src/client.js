/** Browser half of the Arcaea desktop and web theme. */

const PLUGIN_ID = 'dsh-arcaea-theme'
const STYLE_ID = `${PLUGIN_ID}/theme.css`
const THEME_ID = 'arcaea-light'
const FONT_ASSET_BASE_URL = resolveAssetBaseUrl('fonts')
const IMAGE_ASSET_BASE_URL = resolveAssetBaseUrl('arcaea')

const TOKENS = Object.freeze({
  '--dsw-alias-bg-base': pair('rgba(248, 247, 248, 0.90)', 'rgba(248, 247, 248, 0.90)'),
  '--dsw-alias-bg-layer-1': pair('rgba(255, 255, 255, 0.91)', 'rgba(255, 255, 255, 0.91)'),
  '--dsw-alias-bg-layer-2': pair('rgba(245, 242, 246, 0.94)', 'rgba(245, 242, 246, 0.94)'),
  '--dsw-alias-bg-layer-3': pair('rgba(235, 230, 239, 0.94)', 'rgba(43, 30, 61, 0.94)'),
  '--dsw-alias-bg-overlay': pair('rgba(255, 255, 255, 0.98)', 'rgba(255, 255, 255, 0.98)'),
  '--dsw-alias-bg-module-platform': pair('rgba(242, 237, 246, 0.90)', 'rgba(41, 28, 58, 0.92)'),
  '--dsw-alias-bg-multi-select': pair('rgba(61, 209, 238, 0.15)', 'rgba(93, 226, 255, 0.14)'),
  '--dsw-alias-border-l1': pair('rgba(72, 126, 169, 0.12)', 'rgba(167, 214, 255, 0.10)'),
  '--dsw-alias-border-l2': pair('rgba(54, 37, 65, 0.20)', 'rgba(205, 184, 224, 0.18)'),
  '--dsw-alias-border-l2-darkmode-thin': pair('rgba(66, 39, 78, 0.26)', 'rgba(216, 190, 235, 0.23)'),
  '--dsw-alias-border-l3': pair('rgba(72, 39, 83, 0.36)', 'rgba(221, 190, 238, 0.34)'),
  '--dsw-alias-border-l4': pair('rgba(92, 43, 103, 0.52)', 'rgba(232, 195, 244, 0.50)'),
  '--dsw-alias-brand-primary': pair('#291832', '#f2eafa'),
  '--dsw-alias-brand-primary-invert': pair('#f5fbff', '#0c1529'),
  '--dsw-alias-brand-text': pair('#76506f', '#76506f'),
  '--dsw-alias-label-primary': pair('#241d29', '#f4eff8'),
  '--dsw-alias-label-primary-bluish': pair('#31243b', '#eee3f5'),
  '--dsw-alias-label-primary-dimmed': pair('#65586b', '#c9bbd2'),
  '--dsw-alias-label-secondary': pair('#6c6071', '#bbaec5'),
  '--dsw-alias-label-tertiary': pair('#8d8291', '#8f809b'),
  '--dsw-alias-label-caption': pair('#8a7b90', '#74677f'),
  '--dsw-alias-state-business-primary': pair('#9b3b84', '#9b3b84'),
  '--dsw-alias-state-business-tertiary': pair('rgba(155, 59, 132, 0.13)', 'rgba(155, 59, 132, 0.13)'),
  '--dsw-alias-state-success-primary': pair('#00a998', '#5eead4'),
  '--dsw-alias-state-error-primary': pair('#d94683', '#ff78ae'),
  '--dsw-alias-state-warn-primary': pair('#b77800', '#ffd166'),
  '--dsw-alias-state-warn-label': pair('#b82f91', '#ff69c9'),
  '--dsw-alias-interactive-bg-hover': pair('rgba(31, 180, 221, 0.10)', 'rgba(91, 217, 255, 0.10)'),
  '--dsw-alias-interactive-bg-hover-accent': pair('rgba(26, 190, 225, 0.16)', 'rgba(94, 227, 255, 0.16)'),
  '--dsw-alias-interactive-bg-hover-solid': pair('#dff7fc', '#213b50'),
  '--dsw-alias-interactive-bg-active': pair('rgba(0, 169, 210, 0.18)', 'rgba(87, 221, 255, 0.18)'),
  '--dsw-alias-button-elevated-fill': pair('rgba(255, 255, 255, 0.70)', 'rgba(31, 39, 69, 0.86)'),
  '--dsw-alias-button-floating-fill': pair('rgba(255, 255, 255, 0.88)', 'rgba(26, 33, 60, 0.94)'),
  '--dsw-alias-button-floating-hover': pair('rgba(218, 248, 255, 0.96)', 'rgba(41, 61, 88, 0.96)'),
  '--dsw-alias-button-info-fill': pair('#00a9d2', '#35c8ee'),
  '--dsw-alias-button-info-hover': pair('#008db7', '#66ddf9'),
  '--dsw-alias-button-tool-bar-fill': pair('rgba(232, 247, 255, 0.86)', 'rgba(28, 39, 65, 0.90)'),
  '--dsw-alias-button-tool-bar-hover': pair('rgba(208, 242, 252, 0.96)', 'rgba(42, 61, 88, 0.96)'),
  '--dsw-alias-scrollbar-bg-l1': pair('rgba(35, 140, 178, 0.20)', 'rgba(112, 203, 239, 0.18)'),
  '--dsw-alias-scrollbar-bg-l2': pair('rgba(35, 140, 178, 0.28)', 'rgba(112, 203, 239, 0.25)'),
  '--dsw-alias-scrollbar-hover-l1': pair('rgba(0, 169, 210, 0.44)', 'rgba(87, 221, 255, 0.40)'),
  '--dsw-alias-scrollbar-hover-l2': pair('rgba(0, 169, 210, 0.56)', 'rgba(87, 221, 255, 0.52)'),
  '--dsw-alias-markdown-inline-code': pair('rgba(111, 93, 190, 0.10)', 'rgba(172, 151, 255, 0.14)'),
  '--dsw-alias-markdown-code-block': pair('rgba(240, 247, 255, 0.94)', 'rgba(7, 12, 28, 0.92)'),
  '--dsw-alias-markdown-code-block-banner': pair('rgba(221, 239, 250, 0.92)', 'rgba(20, 30, 53, 0.94)'),
  '--dsw-specific-sidebar-fill': pair('#eee9ef', '#eee9ef'),
  '--dsw-specific-sidebar-nav-item-active': pair('rgba(236, 213, 229, 0.14)', 'rgba(236, 213, 229, 0.14)'),
  '--dsw-specific-sidebar-nav-item-hover': pair('rgba(255, 255, 255, 0.07)', 'rgba(255, 255, 255, 0.07)'),
  '--dsw-specific-input-major': pair('rgba(255, 255, 255, 0.93)', 'rgba(24, 15, 39, 0.94)'),
  '--dsw-specific-selector': pair('rgba(213, 243, 251, 0.90)', 'rgba(36, 53, 77, 0.92)'),
  '--dsw-specific-menu': pair('#fcfafd', '#fcfafd'),
  '--dsw-specific-bubble': pair('rgba(239, 231, 238, 0.96)', 'rgba(239, 231, 238, 0.96)'),
  '--dsw-specific-bubble-highlight': pair('rgba(229, 213, 228, 0.98)', 'rgba(229, 213, 228, 0.98)'),
  '--dsw-shadow-lv2': pair('0 18px 48px rgba(48, 126, 174, 0.14)', '0 18px 52px rgba(0, 0, 0, 0.38)'),
  '--dsw-shadow-lv3': pair('0 24px 70px rgba(44, 103, 157, 0.20)', '0 26px 80px rgba(0, 0, 0, 0.50)')
})

const STYLE_TEXT = String.raw`
@font-face {
  font-family: "Arc Exo";
  src: url("__ARC_FONT_EXO__") format("truetype");
  font-style: normal;
  font-weight: 100 900;
  font-display: swap;
}

@font-face {
  font-family: "Arc Noto Sans CJK SC";
  src: url("__ARC_FONT_NOTO_LIGHT__") format("opentype");
  font-style: normal;
  font-weight: 300;
  font-display: swap;
}

@font-face {
  font-family: "Arc Noto Sans CJK SC";
  src: url("__ARC_FONT_NOTO_REGULAR__") format("opentype");
  font-style: normal;
  font-weight: 400 600;
  font-display: swap;
}

@font-face {
  font-family: "Arc Noto Sans CJK SC";
  src: url("__ARC_FONT_NOTO_BOLD__") format("opentype");
  font-style: normal;
  font-weight: 700 900;
  font-display: swap;
}

:root {
  --arc-body-font: "Arc Exo", "Arc Noto Sans CJK SC", sans-serif;
  --arc-ink: #312a35;
  --arc-mauve: #bda6b7;
}

/* DSH 0.2 has independent text, code and terminal font preferences.
   Change the text fallback only, so explicit user font choices still work. */
body {
  --dsh-font-family-text-default: var(--arc-body-font);
  --dsw-font-family: var(--dsh-font-family-text, var(--arc-body-font)), var(--arc-body-font);
  font-family: var(--dsw-font-family);
  background: #f8f7f8;
}

/* Backgrounds belong to the shell itself. No extra DOM, stacking contexts,
   transforms or filters on layout ancestors: native drag regions, fixed
   controls, overlays and resize handles retain their host geometry. */
html [class*="_frame"] > [class*="_centerCol"] {
  background-color: #faf9fb !important;
  --arc-artwork-veil: linear-gradient(90deg, rgba(252,249,253,.20), rgba(252,249,253,.54) 30%, rgba(252,249,253,.62) 65%, rgba(252,249,253,.20));
  background-image: var(--arc-artwork-veil), url("__ARC_IMAGE_SELECT_LIGHT__");
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

/* More quiet space behind conversation text; the artwork stays visible at
   the edges. This is paint only, with no new overlay or pointer target. */
html [class*="_frame"] > [class*="_centerCol"]:has([data-phase="active"]),
html [class*="_frame"] > [class*="_centerCol"]:has([data-phase="settling"]),
html [class*="_frame"] > [class*="_centerCol"]:has([class*="_bubble"]) {
  --arc-artwork-veil: linear-gradient(90deg, rgba(252,249,253,.55), rgba(252,249,253,.92) 22%, rgba(252,249,253,.94) 78%, rgba(252,249,253,.55));
}

[class*="_centerCol"] > [data-slot="main"] > [class*="_root"],
[class*="_centerCol"] [data-slot="main.conversation"] > [class*="_root"],
[class*="_centerCol"] > [class*="_root"] {
  background-color: transparent;
}

/* Dark navigation, with its own palette. The desktop titlebar uses the
   light global sidebar token so native window buttons retain contrast. */
[class*="_sidebarCol"] {
  --dsw-alias-label-primary: #f8f4f7;
  --dsw-alias-label-primary-bluish: #f2eaf0;
  --dsw-alias-label-primary-dimmed: #e0d4dc;
  --dsw-alias-label-secondary: #d1c2cf;
  --dsw-alias-label-tertiary: #b6a7b5;
  --dsw-alias-label-caption: #b0a0af;
  --dsw-alias-border-l1: rgba(255,255,255,.08);
  --dsw-alias-border-l2: rgba(255,255,255,.16);
  --dsw-alias-button-elevated-fill: rgba(255,255,255,.075);
  --dsw-alias-interactive-bg-hover: rgba(255,255,255,.07);
  --dsw-alias-interactive-bg-active: rgba(221,188,211,.20);
  --dsw-specific-sidebar-fill: #3b3340;
  --dsw-specific-sidebar-nav-item-active: rgba(236,213,229,.15);
  --dsw-specific-sidebar-nav-item-hover: rgba(255,255,255,.07);
  color: #f8f4f7;
  background:
    linear-gradient(180deg, rgba(30,23,43,.22), rgba(30,23,43,.66)),
    url("__ARC_IMAGE_SELECT_DARK__") 24% center / auto 100%, #342a42 !important;
}

/* Only the sidebar root is transparent; nested panels keep their surfaces. */
[class*="_sidebarCol"] > [class*="_root"] {
  background: transparent;
}

/* Desktop inserts display:contents slot wrappers around SidebarRoot. */
[class*="_sidebarCol"] [class*="_root"]:has(> [class*="_logoRow"]) {
  background: transparent;
}

[class*="_sidebarCol"] :is([class$="_active"], [class*="_active "], [aria-current="page"]) {
  background: linear-gradient(100deg, rgba(221,188,211,.22), rgba(255,255,255,.06));
  box-shadow: inset 3px 0 0 #d7a9c8;
}

[class*="_sidebarCol"] button:is([class$="_newSession"], [class*="_newSession "]) {
  border: 0;
  border-radius: 0;
  color: #fff;
  background: url("__ARC_IMAGE_TITLE_MARKER__") center / 100% 100% no-repeat, #594362;
  clip-path: polygon(8px 0, 100% 0, calc(100% - 8px) 100%, 0 100%);
}
[class*="_sidebarCol"] button:is([class$="_newSession"], [class*="_newSession "]):hover {
  background-color: rgba(224,190,215,.14);
}
[class*="_sidebarCol"] button:is([class$="_newSession"], [class*="_newSession "]):focus-visible {
  outline-offset: -3px;
}

/* Both the legacy SVG lockup and the new split brand slots. */
[class*="_sidebarCol"] [class*="_brand"] {
  --dsw-alias-label-primary-inverted: #493d4d;
}
[class*="_sidebarCol"] [class*="_buildVersion"] {
  color: #493d4d;
  background: #eee3ef;
}

/* The collapsed Windows buttons sit in the native titlebar, outside the
   zero-width sidebar. Preserve fixed position, no-drag and host dimensions. */
html[data-windows-titlebar] [class*="_sidebarCol"] button[class*="_toggle"],
html[data-windows-titlebar] [data-sidebar-collapsed] button:is([class$="_newSession"], [class*="_newSession "]) {
  color: #514157;
  background: transparent;
  clip-path: none;
  border-radius: 6px;
}

/* Old Web settings were nested in the sidebar; newer Desktop portals are
   siblings of #root. Both receive a complete, opaque light surface. */
[role="dialog"], [role="menu"], [role="listbox"], [data-menu-material] {
  --dsw-alias-label-primary: #312a35;
  --dsw-alias-label-primary-bluish: #3b303e;
  --dsw-alias-label-primary-dimmed: #675b69;
  --dsw-alias-label-secondary: #746a76;
  --dsw-alias-label-tertiary: #918793;
  --dsw-alias-label-caption: #918793;
  --dsw-alias-border-l1: rgba(73,59,77,.10);
  --dsw-alias-border-l2: rgba(73,59,77,.18);
  --dsw-alias-bg-layer-1: #ffffff;
  --dsw-alias-bg-layer-2: #f5f2f6;
  --dsw-alias-bg-layer-3: #ebe6ef;
  --dsw-specific-sidebar-nav-item-active: rgba(184,139,172,.18);
  --dsw-specific-sidebar-nav-item-hover: rgba(117,87,111,.08);
  --dsw-specific-menu: #fcfafd;
  color: var(--dsw-alias-label-primary);
}
[role="dialog"] {
  border-color: rgba(116,86,123,.22);
}
[role="dialog"] :is([class$="_active"], [class*="_active "]) {
  background: rgba(184,139,172,.18);
  box-shadow: inset 3px 0 0 #b66f9d;
}

/* Match complete CSS-module names, never cardWorkspaceTrigger, cardBody,
   headerActions, etc. Menus and editor stay outside the decorative cut. */
[class*="_composerStack"] :is([class$="_card"], [class*="_card "]) {
  position: relative;
  isolation: isolate;
  overflow: visible;
  border: 0 !important;
  border-radius: 0 !important;
  background: transparent !important;
  box-shadow: none !important;
  clip-path: none;
}
[class*="_composerStack"] :is([class$="_card"], [class*="_card "])::before,
[class*="_composerStack"] :is([class$="_card"], [class*="_card "])::after {
  position: absolute;
  pointer-events: none;
  content: "";
}
[class*="_composerStack"] :is([class$="_card"], [class*="_card "])::before {
  inset: 1px;
  z-index: -1;
  background: linear-gradient(116deg, #fff, #f6f0f6 73%, #e8d9e6);
  clip-path: polygon(13px 0, 100% 0, 100% calc(100% - 13px), calc(100% - 13px) 100%, 0 100%, 0 13px);
}
[class*="_composerStack"] :is([class$="_card"], [class*="_card "])::after {
  inset: 0;
  z-index: -2;
  border: 0;
  border-radius: 0;
  background: linear-gradient(100deg, #8dbec8, #c495b8 67%, #a197a5);
  clip-path: polygon(14px 0, 100% 0, 100% calc(100% - 14px), calc(100% - 14px) 100%, 0 100%, 0 14px);
}
[class*="_composerStack"] :is([class$="_card"], [class*="_card "]):focus-within::after {
  background: linear-gradient(100deg, #589eae, #ad6195 67%, #83708e);
}
[class*="_composerStack"] :is([class$="_cardWorkspaceTrigger"], [class*="_cardWorkspaceTrigger "])::after {
  background: repeating-linear-gradient(120deg, #ab95b2 0 6px, #f4eef6 6px 10px);
}
/* The editor's own caret/composition rules remain in charge, including IME
   and selected @ chips. Only the legacy textarea needs a caret fallback. */
[class*="_composerStack"] textarea {
  caret-color: #8d4d7c;
  font-family: var(--dsw-font-family);
}
[class*="_composerStack"] button:is([class$="_primary"], [class*="_primary "]) {
  border-radius: 4px;
  background: linear-gradient(135deg, #a26891, #6b5674);
  clip-path: polygon(6px 0, 100% 0, calc(100% - 6px) 100%, 0 100%);
}
[class*="_composerStack"] button:is([class$="_primary"], [class*="_primary "]):focus-visible {
  outline-offset: -3px;
}

:is([class$="_bubble"], [class*="_bubble "]) {
  border: 1px solid rgba(101,78,103,.18);
  border-radius: 3px 12px 3px 12px;
  background: linear-gradient(112deg, #f0e7ef, #e2cfdf) !important;
}
:is([class$="_tabActive"], [class*="_tabActive "]) {
  color: #8d3b77 !important;
  font-weight: 600;
}
:is([class$="_tabActive"], [class*="_tabActive "])::after {
  background: linear-gradient(90deg, #705574, #c876ac) !important;
}
:where(button, input, textarea, select, [role="button"]):focus-visible {
  outline-color: #a56992;
}
::selection {
  color: #2f2732;
  background: rgba(205,161,191,.40);
}

@media (forced-colors: active) {
  [class*="_centerCol"], [class*="_sidebarCol"] {
    background: Canvas !important;
    color: CanvasText;
  }
  [class*="_composerStack"] :is([class$="_card"], [class*="_card "]) {
    border: 1px solid CanvasText !important;
    background: Canvas !important;
  }
  [class*="_composerStack"] :is([class$="_card"], [class*="_card "])::before,
  [class*="_composerStack"] :is([class$="_card"], [class*="_card "])::after {
    display: none;
  }
  button { clip-path: none !important; }
}
`

/** Required DSH browser services (Desktop uses the web client platform too). */
export const inject = ['theme']

/** Register the plugin palette and clean up only resources owned by it. */
export function apply(ctx) {
  ctx.effect(() => {
    let previousTheme = ctx.theme.getTheme().preference
    const disposeTheme = ctx.theme.register({
      id: THEME_ID,
      colorScheme: 'light',
      tokens: Object.fromEntries(Object.entries(TOKENS).map(([key, modes]) => [key, modes.light]))
    })
    // Desktop 0.2 adopts persisted built-in preferences asynchronously, also
    // after font changes. Custom ids are not persisted by the host yet. Keep
    // this enabled palette selected, remembering the latest underlying choice
    // to restore on disable. setTheme(customId) does not write host settings.
    let disposed = false
    let pending = false
    const offThemeChange = ctx.on('theme/change', (snapshot) => {
      if (snapshot.preference === THEME_ID) return
      previousTheme = snapshot.preference
      if (pending) return
      pending = true
      // Finish delivering the host snapshot before publishing ours. Nested
      // synchronous events let later presenters paint the stale host palette.
      queueMicrotask(() => {
        pending = false
        if (!disposed && ctx.theme.getTheme().preference !== THEME_ID) ctx.theme.setTheme(THEME_ID)
      })
    })
    ctx.theme.setTheme(THEME_ID)
    const style = installStyle()
    return () => {
      disposed = true
      offThemeChange()
      style?.remove()
      if (ctx.theme.getTheme().preference === THEME_ID) {
        const themes = ctx.theme.getTheme().themes
        const canRestore = previousTheme === 'system' || !themes || themes.some(theme => theme.id === previousTheme)
        ctx.theme.setTheme(canRestore ? previousTheme : 'system')
      }
      disposeTheme()
    }
  }, `${PLUGIN_ID}: palette and stylesheet`)
}

function pair(light, dark) {
  return Object.freeze({ light, dark })
}

function resolveAssetBaseUrl(directory) {
  if (typeof document === 'undefined') return `./assets/${directory}/`
  const scriptUrl = document.currentScript?.src
  if (!scriptUrl) return `./assets/${directory}/`
  return new URL(`../assets/${directory}/`, scriptUrl).href
}

function resolveAssetUrls(css) {
  const fontUrl = (filename) => `${FONT_ASSET_BASE_URL}${filename}`
  const token = (name) => `__ARC_FONT_${name}__`
  const imageToken = (name) => `__ARC_IMAGE_${name}__`
  return css
    .replaceAll(token('EXO'), fontUrl('Exo-Variable.ttf'))
    .replaceAll(token('NOTO_LIGHT'), fontUrl('NotoSansCJKsc-Light.otf'))
    .replaceAll(token('NOTO_REGULAR'), fontUrl('NotoSansCJKsc-Regular.otf'))
    .replaceAll(token('NOTO_BOLD'), fontUrl('NotoSansCJKsc-Bold.otf'))
    .replaceAll(imageToken('SELECT_LIGHT'), `${IMAGE_ASSET_BASE_URL}bg_select_light.jpg`)
    .replaceAll(imageToken('SELECT_DARK'), `${IMAGE_ASSET_BASE_URL}bg_select_dark.jpg`)
    .replaceAll(imageToken('TITLE_MARKER'), `${IMAGE_ASSET_BASE_URL}title-marker.png`)
}

function installStyle() {
  if (typeof document === 'undefined') return undefined
  const previous = document.querySelector(`style[data-plugin-css="${STYLE_ID}"]`)
  if (previous !== null) previous.remove()
  const style = document.createElement('style')
  style.dataset.plugin = PLUGIN_ID
  style.dataset.pluginCss = STYLE_ID
  style.textContent = resolveAssetUrls(STYLE_TEXT)
  document.head.appendChild(style)
  return style
}
