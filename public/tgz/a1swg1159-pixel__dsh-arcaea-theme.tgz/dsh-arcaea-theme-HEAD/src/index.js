/**
 * Host half of the visual theme. The browser half owns all behavior; this
 * empty Cordis plugin only gives the DSH loader an installable package entry.
 */
export function apply() {}
