# Arcaea artwork

Selected from the user-provided local Arcaea asset collection. The original files are copied unchanged; contrast and cropping are applied with CSS at runtime.

| Packaged file | Local source | Placement |
| --- | --- | --- |
| `bg_select_light.jpg` | `img/img/1080/bg_select_light.jpg` | Main workspace background |
| `bg_select_dark.jpg` | `img/img/1080/bg_select_dark.jpg` | Sidebar background |
| `title-marker.png` | `img/img/dialog_v2/title-marker.png` | New Session button |

The build embeds all three images into `dist/client.js`, so the desktop renderer does not need network access or a separate image route.

Arcaea artwork belongs to lowiro and its respective rights holders. The plugin's MIT license applies to its code, not these images. See `THIRD_PARTY_NOTICES.md`.
