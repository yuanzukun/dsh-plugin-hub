# Bundled fonts

These are runtime assets required by `dsh-arcaea-theme`; they are included in the npm package.

| File | Runtime weight | SHA-256 |
| --- | --- | --- |
| `Exo-Variable.ttf` | 100–900 | `2F08F818F1135AC5798030C0BCA252C0845AF5C54DFE172A5C74FBDD68843445` |
| `NotoSansCJKsc-Light.otf` | 300 | `F675C5A2DC58F42797FDD771EE81F1D93B41DB550BA9D03FD789D70AA63A2436` |
| `NotoSansCJKsc-Regular.otf` | 400–600 | `EC5CE413F79BA4CC547799B5EA3047831571E2260A6DF4FC7B533A73C81368D2` |
| `NotoSansCJKsc-Bold.otf` | 700–900 | `538D82617451733B7A331F4AE6AC891C74DB457B5F34C6F09A282F9BDE61A9C0` |

See `OFL-Exo.txt`, `OFL-NotoSansSC.txt`, and the repository-level `THIRD_PARTY_NOTICES.md` for source and license details.
