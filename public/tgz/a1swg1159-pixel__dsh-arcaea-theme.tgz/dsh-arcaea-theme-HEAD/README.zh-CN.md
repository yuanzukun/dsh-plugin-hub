# dsh-arcaea-theme

[English](./README.md) | 简体中文

![dsh-arcaea-theme 仓库横幅](./assets/repository-banner.png)

`dsh-arcaea-theme` 是面向 DeepSeek Harness Web UI 的原创高曝光棱镜记忆主题。主题以本地视觉研究为参考，用纯 CSS 与内联 SVG 重新设计，不包含游戏图片、角色、商标、谱面或其他官方资源。

![主题预览](./preview.png)

## 视觉效果

- 高曝光象牙白中心空间，叠加低对比建筑线稿、细密纹理和远景网格；
- 低饱和紫灰侧栏，使用斜向网点纹理、切角和更清晰的选中状态；
- 克制的粉灰、珠光蓝棱镜碎片，不再让大型装饰线条穿过聊天内容；
- 输入框、消息气泡与主要操作使用锐利切角和轻量阴影；
- 标题使用随包提供的 Exo 可变字体，正文使用随包提供的 Noto Sans CJK SC Light / Regular / Bold，并保留系统字体回退。

插件启用时会选择专用的高曝光 `arcaea-light` 配色；卸载或禁用后恢复之前的主题偏好。它不替换聊天组件、不修改会话数据，也不发起网络请求。

## 本地参考目录

原始 `Fonts/` 与 `img/` 目录仍然只用于本地视觉研究，不会整目录发布。运行必需的 Exo 与 Noto Sans CJK SC 已筛选复制到 `assets/fonts/`，并在构建时以内联 data URL 写入 `dist/client.js`；这是因为 DSH 的插件 Web 路由只提供 `client.js`，不会单独提供插件静态资源。字体仍以独立文件列入插件包并附带 SIL Open Font License 1.1。其他来源或许可不明确的字体和全部游戏图片不会打包。详见 `THIRD_PARTY_NOTICES.md`。

## 安装

在插件目录构建：

```powershell
pnpm run build
```

然后从 DeepSeek Harness 仓库调用其脚本安装。不要直接运行 `pnpm dsh`，因为 `dsh` 不是当前项目的可执行命令：

```powershell
pnpm --dir D:\deepseek-harness run dsh -- plugin --profile web remove dsh-arcaea-theme
pnpm --dir D:\deepseek-harness run dsh -- plugin --profile web add D:\zhuomian\dsh-plugin\dsh-arcaea-theme
pnpm --dir D:\deepseek-harness run dsh -- web
```

启动后在浏览器执行强制刷新（`Ctrl+F5`）。

## 验证

```powershell
pnpm run check
pnpm pack --dry-run
```

## 许可

插件代码采用 MIT 许可。本项目与 lowiro 或 Arcaea 无关联；参考目录中的第三方文件不属于本插件许可范围，也不会被打包。
