# dsh-arcaea-theme

[English](./README.md) | 简体中文

![dsh-arcaea-theme 仓库横幅](./assets/repository-banner.png)

`dsh-arcaea-theme` 是面向 DeepSeek Harness **桌面端与 Web UI** 的 Arcaea 主题。0.7.1 在 Windows 桌面端 **0.2.1-rc.3** 适配基础上，加入本地提供的 Arcaea 选曲背景与界面装饰素材，并内置所需字体。

![主题预览](./preview.png)

## 视觉效果

- 主界面使用浅色选曲背景，保留建筑、悬浮碎片、弧线和蝴蝶细节；
- 侧栏使用深色选曲背景，新会话按钮使用原有标题装饰素材；
- 新会话页展示背景，进入聊天后自动加深浅色遮罩，保证正文可读；
- 输入框与新会话按钮保留斜切设计，装饰边缘不会裁剪菜单、编辑器和光标；
- 浅紫灰桌面标题栏、深色侧栏，保留窗口拖动、折叠、分栏与原生窗口按钮；
- 标题使用随包提供的 Exo 可变字体，正文使用随包提供的 Noto Sans CJK SC Light / Regular / Bold，并保留系统字体回退。

插件启用时固定使用专用 `arcaea-light` 配色；如需切回内置明暗主题，请禁用插件，届时恢复底层主题偏好。新版设置中的正文字体和字号仍然有效；留空字体时默认使用随包字体，代码与终端字体保持独立。插件不替换聊天组件、不修改会话数据，也不发起网络请求。

## 本地参考目录

原始 `Fonts/` 与 `img/` 不会整目录打包。运行字体放在 `assets/fonts/`，本次选用的三张 Arcaea 图片放在 `assets/arcaea/`；构建时全部以内联 data URL 写入 `dist/client.js`，不依赖外部图床或字体服务。字体附带 SIL Open Font License 1.1，图片来源和使用位置见 `assets/arcaea/README.md`。第三方素材归属见 `THIRD_PARTY_NOTICES.md`。

## 桌面端安装

在插件目录构建：

```powershell
node scripts/build.mjs
```

先从托盘**完全退出 DeepSeek Harness**。使用桌面程序自带的 CLI，目标配置是 `desktop`。下面以桌面端安装在 `D:\DSH` 为例；其他位置请修改第一行：

```powershell
$dshDesktopCli = 'D:\DSH\resources\runtime\cli\bin\dsh.cmd'
& $dshDesktopCli plugin --profile desktop add 'D:\zhuomian\dsh-plugin\dsh-arcaea-theme'
```

重新启动桌面端即可。安装目录可替换为下载后解压的本插件目录，也可传入打包后的 `.tgz` 文件。桌面端使用 `web` 客户端插件入口，因此包内 `dsh.client.platform: "web"` 是正确的；`desktop` 指安装配置，不是客户端平台。

卸载（同样先完全退出桌面端）：

```powershell
& $dshDesktopCli plugin --profile desktop remove dsh-arcaea-theme
```

## Web 版安装

使用 Web CLI 安装到 `web` 配置，然后重启 Web 服务并强制刷新浏览器。不要在主题目录运行 `pnpm dsh`，该项目没有提供这个可执行命令：

```powershell
pnpm --dir D:\deepseek-harness dsh plugin --profile web add D:\zhuomian\dsh-plugin\dsh-arcaea-theme
pnpm --dir D:\deepseek-harness dsh web
```

## 验证

```powershell
node scripts/build.mjs
node --test
npm pack --dry-run
```

桌面回归脚本：`scripts/inspect-desktop.mjs`。先使用桌面 CLI 将插件安装到独立的 `DSH_HOME` 测试目录，再执行：

```powershell
node scripts/inspect-desktop.mjs '<Playwright 的 index.mjs 路径>' 'D:\DSH\DeepSeek Harness.exe' '<隔离的 DSH_HOME>' '.local\desktop-check'
```

脚本检查实际桌面程序中的字体加载、输入编辑、四类菜单、设置页面、侧栏折叠、右侧面板和三种窗口尺寸，并输出截图与 `report.json`。测试只使用隔离配置，不调用模型。已实测 Windows 0.2.1-rc.3；macOS / Linux 尚未实机验证。旧 Web 布局另有浏览器预览测试。

## 许可

插件代码采用 MIT 许可，Arcaea 图片属于 lowiro 及相应权利人，不属于 MIT 许可范围。本项目为非官方主题，不代表 lowiro 或 Arcaea。
