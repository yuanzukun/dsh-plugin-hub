# dsh-arcaea-theme

English | [简体中文](./README.zh-CN.md)

![dsh-arcaea-theme repository banner](./assets/repository-banner.png)

`dsh-arcaea-theme` is an original high-key prismatic memory theme for the DeepSeek Harness Web UI. It turns local visual research into a fresh implementation made from CSS and inline SVG; no game image, character, trademark, chart, or other official asset is included.

![Theme preview](./preview.png)

## Visual treatment

- A high-exposure ivory workspace with restrained architectural linework, fine texture, and a distant perspective grid.
- A desaturated aubergine sidebar with diagonal halftone texture, clipped shapes, and clearer selection states.
- Subtle blush and pearl-blue prisms that stay behind the conversation instead of crossing the content.
- Sharp clipped corners and quiet shadows for the composer, bubbles, and primary actions.
- A bundled Exo variable display face and bundled Noto Sans CJK SC Light / Regular / Bold body faces, with system fallbacks.

While enabled, the plugin selects its dedicated high-exposure `arcaea-light` palette. Removing or disabling it restores the previous theme preference. It does not replace chat components, modify session data, or make network requests.

## Local reference directories

The original `Fonts/` and `img/` directories remain local visual research and are not distributed wholesale. Required Exo and Noto Sans CJK SC faces are selected into `assets/fonts/` and embedded as data URLs in `dist/client.js` at build time because DSH's plugin web route serves `client.js`, not arbitrary package assets. The standalone font files and their SIL Open Font License 1.1 texts remain in the package. Other fonts with unclear provenance and all game images remain excluded. See `THIRD_PARTY_NOTICES.md`.

## Install

Build from the plugin directory:

```powershell
pnpm run build
```

Run the DeepSeek Harness script from its repository. Do not use `pnpm dsh` directly because this project does not expose a `dsh` executable:

```powershell
pnpm --dir D:\deepseek-harness run dsh -- plugin --profile web remove dsh-arcaea-theme
pnpm --dir D:\deepseek-harness run dsh -- plugin --profile web add D:\zhuomian\dsh-plugin\dsh-arcaea-theme
pnpm --dir D:\deepseek-harness run dsh -- web
```

Then hard-refresh the browser with `Ctrl+F5`.

## Verify

```powershell
pnpm run check
pnpm pack --dry-run
```

## License

Plugin code is MIT licensed. This project is not affiliated with lowiro or Arcaea. Third-party files in the local reference directories are outside this plugin's license and are not packaged.
