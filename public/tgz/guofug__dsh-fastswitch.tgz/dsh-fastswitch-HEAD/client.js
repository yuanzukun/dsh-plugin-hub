/**
 * dsh-fastswitch — Client half.
 *
 * Two independent optimizations for switching Sessions in the browser UI:
 *
 *   1. First-screen history window (WebSocket.send rewrite)
 *      DSH's Session controller asks the Host for the opening history page with
 *      a hard-coded `turnWindow.minMessages` of 50. On a long conversation that
 *      single snapshot can be megabytes. The Host only validates
 *      `0 < minMessages <= maxMessages`, so lowering it is a supported request,
 *      not a hack. We rewrite the outgoing frame on its way out and leave every
 *      other request untouched (notably the 200-message "load earlier" page).
 *
 *   2. Read-only RPC dedupe + cache (window.fetch wrapper)
 *      Building the page shells several components that each fetch the same
 *      catalog on mount: `session/modelCatalog` x6, `credentials/describe` x7,
 *      `agentPresets/list` x6, `cotTranslation/limits` x3. Those RPCs are
 *      read-only, so the answer is reused for 5 minutes and concurrent callers
 *      share one flight.
 *
 *      Subtlety that makes or breaks it: `api/*` is an RPC envelope transported
 *      over POST, and every request carries a fresh `rpcId`. Caching on the raw
 *      body therefore never hits. We key on the body with `rpcId` removed, and
 *      on replay we rewrite the response's `rpcId` back to the caller's, so
 *      correlation still works.
 *
 * Everything is guarded and reversible:
 *   localStorage['dsh-fastswitch']        = 'off'  → disable both halves
 *   localStorage['dsh-fastswitch-window'] = 20     → minMessages, 0 = leave alone
 *   localStorage['dsh-fastswitch-ttl']    = 300000 → cache TTL in ms, 0 = disable
 *   localStorage['dsh-fastswitch-merge']  = 800    → concurrent-flight window, ms
 *   window.__dshFastswitch                         → counters
 */
window.__ModuleLoader__.load({
  id: 'dsh-fastswitch',
  factory() {
    const NS = 'dsh-fastswitch'
    const DEFAULTS = { window: 20, ttl: 300000, merge: 800 }
    const STATIC = /^\/?api\/(?:session\/modelCatalog|agentPresets\/list|commands\/list|skills\/list|permissionPresets\/catalog|cotTranslation\/limits)(?:[?#]|$)/
    const MERGE = /^\/?api\/(?:credentials\/describe|schedule\/list|dsh-context\/detail|session\/canOpenWorkspacePath|task-board\/state)(?:[?#]|$)/

    const stats = {
      installed: false,
      ws: { rewritten: 0, untouched: 0 },
      fetch: { calls: 0, hits: 0, dedup: 0, bypass: 0 },
    }
    window.__dshFastswitch = stats

    const readSetting = (key, fallback) => {
      try {
        const raw = window.localStorage.getItem(`${NS}-${key}`)
        if (raw === null || raw.trim() === '') return fallback
        const value = Number(raw)
        return Number.isFinite(value) && value >= 0 ? value : fallback
      } catch {
        return fallback
      }
    }
    const isOff = () => {
      try {
        return window.localStorage.getItem(NS) === 'off'
      } catch {
        return false
      }
    }

    // ---------------------------------------------------------------- 1. window

    const patchWebSocketSend = () => {
      const proto = window.WebSocket && window.WebSocket.prototype
      if (!proto || typeof proto.send !== 'function' || proto.__dshFastswitchWrapped) return false
      const original = proto.send
      proto.send = function (data) {
        try {
          if (typeof data === 'string' && !isOff()) {
            const target = readSetting('window', DEFAULTS.window)
            if (target > 0 && data.indexOf('session/follow') !== -1) {
              const message = JSON.parse(data)
              const request = message?.payload?.args?.request
              const turnWindow = request?.turnWindow
              // Only the opening page: the "load earlier" page asks for 200
              // messages and must keep doing so.
              if (message.type === 'open' && message.endpoint === 'session/follow'
                && turnWindow && typeof turnWindow.minMessages === 'number'
                && turnWindow.minMessages <= 50 && turnWindow.minMessages > target) {
                turnWindow.minMessages = target
                stats.ws.rewritten += 1
                return original.call(this, JSON.stringify(message))
              }
            }
          }
        } catch {
          // fall through: send the original payload untouched
        }
        stats.ws.untouched += 1
        return original.call(this, data)
      }
      proto.__dshFastswitchWrapped = true
      return true
    }

    // ----------------------------------------------------------------- 2. fetch

    const patchFetch = () => {
      if (typeof window.fetch !== 'function' || window.fetch.__dshFastswitchWrapped) return false
      const original = window.fetch
      const cache = new Map()
      const inflight = new Map()

      const urlOf = (input) => {
        if (typeof input === 'string') return input
        if (input && typeof input.url === 'string') return input.url
        return ''
      }
      const parseBody = (init) => {
        if (init == null || init.body == null) return { key: '', rpcId: null }
        if (typeof init.body !== 'string') return null
        try {
          const parsed = JSON.parse(init.body)
          if (parsed !== null && typeof parsed === 'object') {
            const rpcId = typeof parsed.rpcId === 'string' ? parsed.rpcId : null
            const stripped = Object.assign({}, parsed)
            delete stripped.rpcId
            return { key: JSON.stringify(stripped), rpcId }
          }
        } catch {}
        return { key: init.body, rpcId: null }
      }
      const respond = (record, rpcId) => {
        let text = record.text
        if (rpcId !== null) {
          try {
            const parsed = JSON.parse(text)
            if (parsed !== null && typeof parsed === 'object' && typeof parsed.rpcId === 'string') {
              parsed.rpcId = rpcId
              text = JSON.stringify(parsed)
            }
          } catch {}
        }
        const headers = new Headers()
        headers.set('content-type', record.contentType || 'application/json')
        return new Response(text, { status: record.status, statusText: record.statusText || '', headers })
      }

      const wrapped = function (input, init) {
        stats.fetch.calls += 1
        const url = urlOf(input)
        const cacheable = STATIC.test(url)
        const mergeable = MERGE.test(url)
        const ttl = readSetting('ttl', DEFAULTS.ttl)
        if (isOff() || ttl <= 0 || (!cacheable && !mergeable)) {
          stats.fetch.bypass += 1
          return original.apply(this, arguments)
        }
        const body = parseBody(init)
        if (body === null) {
          stats.fetch.bypass += 1
          return original.apply(this, arguments)
        }
        const method = String((init && init.method) || 'GET').toUpperCase()
        const key = `${method} ${url.split('?')[0].split('#')[0]}|${body.key}`

        if (cacheable) {
          const hit = cache.get(key)
          if (hit !== undefined && Date.now() - hit.at < ttl) {
            stats.fetch.hits += 1
            return Promise.resolve(respond(hit, body.rpcId))
          }
        }
        const pending = inflight.get(key)
        if (pending !== undefined) {
          stats.fetch.dedup += 1
          return pending.then((record) => respond(record, body.rpcId))
        }

        const flight = original.apply(this, arguments).then((response) =>
          response.clone().text().then((text) => ({
            text,
            status: response.status,
            statusText: response.statusText,
            contentType: response.headers.get('content-type') || '',
          })))
        inflight.set(key, flight)
        const mergeWindow = readSetting('merge', DEFAULTS.merge)
        flight.then((record) => {
          if (cacheable) cache.set(key, Object.assign({ at: Date.now() }, record))
          if (mergeable && mergeWindow > 0) setTimeout(() => inflight.delete(key), mergeWindow)
          else inflight.delete(key)
        }, () => inflight.delete(key))
        return flight.then((record) => respond(record, body.rpcId))
      }
      wrapped.__dshFastswitchWrapped = true
      window.fetch = wrapped
      return true
    }

    // ------------------------------------------------------------------- install

    const install = () => {
      const ws = patchWebSocketSend()
      const fetch = patchFetch()
      stats.installed = ws || fetch
      return stats.installed
    }

    // Never let a patch failure escape into the host's module loader: a thrown
    // factory can poison every later `require` of this bundle. Swallow it, keep
    // the counters honest, and stay inert.
    try {
      install()
    } catch (error) {
      stats.installed = false
      stats.error = String((error && error.message) || error)
    }

    return {
      name: 'dsh-fastswitch',
      inject: [],
      apply() {
        // The module factory already ran install(); apply stays as the cordis
        // lifecycle seam so the bundle behaves like any other client plugin.
        if (!stats.installed) install()
      },
      __stats: stats,
    }
  },
})
