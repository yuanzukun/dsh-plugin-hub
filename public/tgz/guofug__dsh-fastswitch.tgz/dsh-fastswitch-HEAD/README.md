# dsh-fastswitch

Makes **switching Sessions** in DeepSeek Harness fast. Two things, each independently switchable.

> 中文：[README.zh.md](./README.zh.md)

## What it fixes

When you switch a Session, DSH asks the Host for the opening history page. That page has a hard-coded window — at least 50 messages — which on a long conversation arrives as a **2 MB** frame. That frame is the wait you feel.

Separately, while the page shells itself, several components each fetch the same read-only catalogs on mount: `session/modelCatalog` 6 times, `credentials/describe` 7 times, `agentPresets/list` 6 times, `cotTranslation/limits` 3 times. No deduplication, no cache.

dsh-fastswitch makes one change for each, in the browser:

1. **Configurable opening window** — rewrites `turnWindow.minMessages` (50 → 20 by default) on the outgoing `session/follow` request. The Host validates `0 < minMessages <= maxMessages`, so this is a supported request, not a patch. "Load earlier" pages (200 messages) are left untouched.
2. **Read-only RPC dedupe + cache** — wraps `window.fetch`, caching read-only catalog calls for 5 minutes and collapsing concurrent ones into a single flight.

## Measured

Same machine, same page, same conversation:

| | default | with dsh-fastswitch |
|---|---|---|
| Opening snapshot (one long Session) | 2,040,432 B | **1,054,070 B** |
| `session/modelCatalog` | 6 calls | **1 call** |
| `credentials/describe` | 7 calls | **1 call** |
| `agentPresets/list` | 6 calls | **1 call** |
| Total requests on first paint | 52 | **33** |

These come from a single measurement; they depend on conversation length and browser cache state, and are not constants.

## Install

Search **fastswitch** in the plugin market, or:

```sh
dsh plugin --profile web add github:guofug/dsh-fastswitch
```

Restart once (or let HMR reload) afterwards.

## Configuration

All through `localStorage` — no config files:

| Key | Default | Meaning |
|---|---|---|
| `dsh-fastswitch` | — | set to `off` to disable everything |
| `dsh-fastswitch-window` | `20` | opening window size; `0` leaves it alone |
| `dsh-fastswitch-ttl` | `300000` | cache TTL in ms; `0` disables caching |
| `dsh-fastswitch-merge` | `800` | concurrent-flight window in ms |

```js
localStorage.setItem('dsh-fastswitch-window', '10')   // more aggressive
localStorage.setItem('dsh-fastswitch', 'off')          // turn it all off
```

## Checking that it works

```js
window.__dshFastswitch
// { installed: true,
//   ws: { rewritten: 3, untouched: 40 },
//   fetch: { calls: 51, hits: 10, dedup: 8, bypass: 33 } }
```

- `ws.rewritten` should increment once per Session switch;
- `fetch.hits + fetch.dedup` is the number of requests saved.

## Scope

- **Browser only.** Terminals, the SDK, ACP and other clients are unaffected.
- **Modifies no DeepSeek Harness file and no Host behaviour.** The window is a rewritten outgoing request; the cache is a browser-side `fetch` wrapper. Uninstall and everything is back to stock.
- **No Session parking cache.** Keeping opened Sessions in memory for instant switch-back would mean operating on Session lifecycle internals, which breaks across versions. Deliberately out of scope.
- Caching covers **read-only** catalogs only. No writes, no streaming responses, no auth endpoints.

## Compatibility

- Targets `dsh ^0.2.1-rc.2` (see `engines.dsh`).
- Both wrappers are idempotent, so HMR reloads do not stack wrappers.
- If either wrapper cannot be installed it is skipped; the page degrades to stock behaviour instead of breaking.

## License

MIT
