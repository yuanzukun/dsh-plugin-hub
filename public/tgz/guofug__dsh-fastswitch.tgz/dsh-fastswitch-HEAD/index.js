/**
 * dsh-fastswitch — Host half.
 *
 * The optimization itself lives in the browser (see client.js): the first-screen
 * history window is set by rewriting the outgoing `session/follow` frame, and
 * the RPC cache is a `window.fetch` wrapper. Neither needs a Host service, so
 * this half exists only so that the profile's layer stack has a row to insert —
 * `dsh.bundle.patch` is what makes the package installable, and the client
 * bundle is what does the work.
 */
export const name = 'dsh-fastswitch'
export const inject = []
export function apply() {}
