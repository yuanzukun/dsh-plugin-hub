// src/consolidate.mjs — Background consolidation（P1-4，决策 2B/3A）。
//
// turn/end → enqueue（单全局串行队列，fire-and-forget，不阻塞下一轮）。
// 节流（决策 2B）：未消化 active 证据 ≥ minEvidence 条 或 距上次 ≥ minTurns turn 才跑；
//   水位存 meta 表（consolidation_watermark_ts / consolidation_turn_count）。
// 派生（决策 3A）：从未消化证据批量 LLM 提取 Observation（LLM 主，规则兜底）：
//   - LLM 可用：prompt 强制 JSON {observations:[...]}，解析失败重试 1 次后丢弃该批；
//   - LLM 不可用（llmCall 为 null）：每证据确定性生成一条 Observation（规则兜底）。
// 纪律：本模块零 dsh-llm 依赖——真实 LLM 调用由 index.mjs 注入（llmCall），测试传 mock。

import {
  CLAIM_DOMAINS,
  CONSOLIDATION_MIN_EVIDENCE,
  CONSOLIDATION_MIN_TURNS,
  CONSOLIDATION_META_WATERMARK_TS,
  CONSOLIDATION_META_TURN_COUNT,
  CONSOLIDATION_MAX_BATCH,
  CONSOLIDATION_MAX_CONTENT_CHARS,
  CONSOLIDATION_MAX_RUNS_PER_DAY,
  CONSOLIDATION_META_FAIL_COUNT,
  CONSOLIDATION_META_LAST_FAILURE,
  CONSOLIDATION_META_RUN_DAY,
  CONSOLIDATION_META_RUN_COUNT,
  CONSOLIDATION_SKIP_AGENT_EXPERIENCE,
  CONSOLIDATION_SKIP_ACK_ONLY,
  ACK_ONLY_MAX_CHARS,
  MAX_OBSERVATION_SUBJECT_CHARS,
  MAX_OBSERVATION_TEXT_CHARS,
  CONSOLIDATION_SKIP_EXTERNAL_TOOL,
} from './constants.mjs'
import { PENDING_PROMOTION } from './expression.mjs'
import { isActionFlowObservation } from './governance.mjs'
import { machineTemplateOf } from './ingest-noise.mjs'

// ===================== 源头过滤（P0，2026-09-09） =====================

/**
 * 该条证据是否应跳过蒸馏。
 * agent 自产 + experience 域 = 会话过程流水（"xxx 全绿"），prompt 契约本就要求
 * 这类批输出空数组——送进 LLM 只消耗配额，不产出 observation。
 * @param {object} ev - evidence 行（camelCase）
 * @param {boolean} [skipAgentExperience] - false = 关闭过滤（测试/回溯用）
 * @returns {boolean}
 */
export function isConsolidationSkippable(ev, skipAgentExperience = CONSOLIDATION_SKIP_AGENT_EXPERIENCE) {
  // 机器模板永不蒸馏（2026-09-24）：这一道**不受开关控制** —— 它不是「省配额」，
  // 而是「这类文本根本不该变成关于用户的结论」（实测：子代理任务书被蒸成"用户的要求"）。
  // 覆盖历史漏网：命中集里 T1a 的 user_correction / T1c 的 user_explicit 正是绕过下面
  // agent_authored+experience 判据进来的。
  if (machineTemplateOf(ev?.content)) return true
  if (!skipAgentExperience) return false
  return ev?.sourceClass === 'agent_authored' && ev?.claimDomain === 'experience'
}

// ===================== 工具输出过滤（2026-10-04 审计 P0-1） =====================

/**
 * 该条证据是否是**工具输出转写**（应跳过蒸馏）。
 *
 * sourceClass='external_tool' = 命令输出 / 文件内容 / 检索结果这类**转写**，
 * 不是「关于用户的事实」。它是队列积压的主体：7,773 条里 7,156 条（92%）。
 * 与上面那道（agent 自产 experience）同构：**仍在账本内**（append-only 不删），
 * 只是不参与蒸馏。
 *
 * **默认不过滤**（CONSOLIDATION_SKIP_EXTERNAL_TOOL = false）——先 shadow：
 * 这道比前两道狠得多，要能先看「打开后会怎样」再决定。
 *
 * @param {object} ev - evidence 行（camelCase）
 * @param {boolean} [skipExternalTool] - false = 不过滤（默认）
 * @returns {boolean}
 */
export function isExternalToolSkippable(ev, skipExternalTool = CONSOLIDATION_SKIP_EXTERNAL_TOOL) {
  if (!skipExternalTool) return false
  return ev?.sourceClass === 'external_tool'
}

// ===================== 纯应答过滤（2026-09-22） =====================

/**
 * 应答词（剥离后剩不下实义字符 → 纯应答）。
 * **保守取向**：只收明确的寒暄/续跑/确认词；不收数字、拉丁字母、任何实义名词——
 * 「可以push」「B+C吧」「行，那就2吧」「1.2.3.按顺序来吧」剥离后都还剩实义字符，必须留住。
 */
export const ACK_FILLERS = Object.freeze([
  '继续', '接着', '重启', '重试', '再试', '再尝试', '尝试', '试试', '测试',
  '可以', '不用', '不必', '好的', '好', '行', '嗯', '啊', '哦', '啦', '呗',
  '的', '了', '吧', '呢', '吗', '呀', '嘛',
  '再', '一次', '一下', '下', '次',
  '我们', '我', '你', '先', '就', '都', '把', '那', '这', '样',
  '完', '搞定', '完成', '结束', '开始', '推进', '来', '已经',
])

/**
 * 文本是否为「纯应答」（零信息）。
 * 判据两步：① 归一化后长度 <= ACK_ONLY_MAX_CHARS；② 剥掉 ACK_FILLERS 与全部空白/标点后为空。
 * 纯函数，可测。
 * @param {string} text
 * @returns {boolean}
 */
export function isAckText(text, maxChars = ACK_ONLY_MAX_CHARS) {
  const raw = String(text ?? '').trim()
  if (!raw) return true
  if (raw.length > maxChars) return false
  let rest = raw
  for (const f of ACK_FILLERS) rest = rest.split(f).join('')
  rest = rest.replace(/[\s\p{P}\p{S}]/gu, '')
  return rest.length === 0
}

/**
 * 该条证据是否因「纯应答」而跳过蒸馏。
 * 只作用于 user_input——纠正（user_correction）按定义有信息，不参与判定。
 * @param {object} ev - evidence 行（camelCase）
 * @param {boolean} [skipAckOnly] - false = 关闭过滤（测试/回溯用）
 * @returns {boolean}
 */
export function isAckOnlySkippable(ev, skipAckOnly = CONSOLIDATION_SKIP_ACK_ONLY) {
  if (!skipAckOnly) return false
  if (ev?.sourceClass !== 'user_input') return false
  return isAckText(ev?.content)
}

// ===================== 规则兜底（LLM 不可用） =====================

/** 单条证据 → 一条 Observation（确定性兜底；subject=内容前 40 字符） */
export function ruleObservationFor(ev) {
  return {
    subject: String(ev.content ?? '').slice(0, MAX_OBSERVATION_SUBJECT_CHARS),
    predicate: 'states',
    claimDomain: ev.claimDomain,
    text: String(ev.content ?? '').slice(0, MAX_OBSERVATION_TEXT_CHARS),
    evidenceIds: [ev.id],
  }
}

export function ruleObservations(evidences) {
  return evidences.map(ruleObservationFor)
}

// ===================== LLM 输出解析 =====================

/** 从模型回复里挖出最外层 JSON 对象（容忍 markdown fence / 前后杂文） */
function extractJsonObject(text) {
  let t = String(text ?? '').trim()
  const fence = t.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i)
  if (fence) t = fence[1].trim()
  const start = t.indexOf('{')
  const end = t.lastIndexOf('}')
  if (start === -1 || end === -1 || end <= start) return '{}'
  return t.slice(start, end + 1)
}

/**
 * 解析 LLM 强制 JSON → 合法 Observation 列表。
 * 护栏（2026-09-25 方案 3 的 B 部分）：模型可以输出 `evidenceIds: []`（解析层**不拒绝**——
 * 拒绝会让整批判失败、水位卡死重试烧 LLM，那是更贵的错）。但**必须出声**：
 * 空回链的条目逐条进 `warnings`，由调用方落日志。今天 W 上 `local & active & empty = 0`，
 * 可这条路此前敞开着且无日志无测试拦截。
 * @param {string} text - 模型原始回复
 * @returns {{ok: boolean, observations: object[], warnings: string[]}} 非法/空则 ok:false
 */
export function parseObservations(text) {
  if (typeof text !== 'string' || text.trim().length === 0) return { ok: false, observations: [], warnings: [] }
  let data
  try {
    data = JSON.parse(extractJsonObject(text))
  } catch {
    return { ok: false, observations: [], warnings: [] }
  }
  if (!data || typeof data !== 'object' || !Array.isArray(data.observations)) {
    return { ok: false, observations: [], warnings: [] }
  }
  const observations = []
  const warnings = []
  for (const o of data.observations) {
    if (!o || typeof o !== 'object') continue
    const subject = String(o.subject ?? '').trim()
    const predicate = String(o.predicate ?? '').trim()
    const claimDomain = String(o.claimDomain ?? '')
    const text2 = String(o.text ?? '').trim()
    if (!subject || !predicate || !text2) continue
    if (!CLAIM_DOMAINS.includes(claimDomain)) continue
    const evidenceIds = Array.isArray(o.evidenceIds)
      ? o.evidenceIds.map(String).filter((id) => id.length > 0)
      : []
    // 护栏：无回链的观测**合法但可疑**——它会是读侧认不出的那种「本机缺回链」行
    // （src/backlink.mjs 的 missing_backlink），且 authority 会被兜底成最弱的 single_observation。
    if (evidenceIds.length === 0) {
      warnings.push('observation[' + observations.length + '] ' + subject + ' ' + predicate + '：'
        + text2.slice(0, 30) + ' —— 无 evidenceIds 回链（authority 将兜底 single_observation）')
    }
    observations.push({
      subject,
      predicate,
      claimDomain,
      text: text2.slice(0, MAX_OBSERVATION_TEXT_CHARS),
      evidenceIds,
    })
  }
  // P1-4 修复（2026-09-08）：显式空数组是**合法的模型决策**，不是解析失败。
  // prompt 契约（T2.5，2026-09-07）明确要求「批内只有动作流水时输出 {"observations":[]}」；
  // 旧实现把空数组合法产出判成 ok:false → 同批证据永不消化、水位卡死、每轮重试烧 LLM
  // （实例实证：fail_count 57 连败，watermark 停滞 2026-09-07T04:19Z）。
  // 语义：observations 数组存在即 schema 合法——显式空 = 空产成功；
  // 仅当模型给出非空条目却全部字段非法（偏离契约）时判失败并保留重试。
  if (data.observations.length > 0 && observations.length === 0) {
    return { ok: false, observations: [], warnings: [] }
  }
  return { ok: true, observations, warnings }
}

// ===================== LLM prompt =====================

/**
 * 构造 consolidation prompt（system + user JSON-framed evidence）。
 * @param {object[]} evidences - { id, claimDomain, content }
 * @returns {{system: string, userText: string}}
 */
export function buildConsolidationPrompt(evidences, maxContentChars = CONSOLIDATION_MAX_CONTENT_CHARS) {
  const system = [
    'You consolidate evidence records into durable observations for a user-context ledger.',
    'Return ONLY one JSON object with exactly this shape:',
    '{"observations":[{"subject":"...","predicate":"...","claimDomain":"...","text":"...","evidenceIds":["..."]}]}',
    `claimDomain must be one of: ${CLAIM_DOMAINS.join(', ')}.`,
    'Domain guidance: style = tone/format/presentation preferences (e.g. 简洁/详细/亲切的语气, 先结论后展开, 中文回复); user_preference = substantive preferences (e.g. 用 pnpm, 用 Bun). 表达风格偏好一律标 style，不要标 user_preference。',
    'subject is a short noun phrase (<= 20 chars); predicate is a short relation verb; text is a very concise fact (<= 120 characters, 中文 <= 60 字); evidenceIds reference the supporting evidence ids.',
    // 2026-09-09（non-amplification）：observation 的权威 = 支撑证据中最弱的一条，
    // 所以把弱证据塞进 evidenceIds 只会稀释结论的可信度。写清规则，让模型自己精确。
    'An observation inherits the WEAKEST authority among its supporting evidenceIds — list only the evidence that genuinely supports the claim; adding weak or unrelated evidence weakens the result.',
    // 2026-09-25（方案 3）：此前这里只「劝阻」（别列弱证据），**从未要求 ≥1 条**——
    // 于是 evidenceIds: [] 是一个完全合法的输出，读侧无从核验、authority 还会被兜底成最弱。
    // 改成显式硬要求：没有支撑证据的主张**不要输出这条 observation**（而不是输出空数组）。
    'Every observation MUST list at least one supporting evidenceId copied from the given evidence records. If no evidence record supports a claim, do NOT emit that observation (an observation without evidenceIds is invalid).',
    // P0-7（2026-09-02）：输出收敛——模型曾按每条 evidence 机械输出一条完整 observation
    // （20 条 × ~700 token 超 maxTokens 截断 → 连败）。改为显式引导合并 + 短文本。
    // P3 修复（2026-09-06）：batch8 × 800 字输入实测仍 ~12K token 机械输出（55 连败，
    // last failure finish=length）。输出预算改为**硬约束**：整批至多 3 条 + 禁止逐条展开。
    'Output AT MOST 3 observations for the whole batch, no matter how many evidence records are given.',
    'Merge related evidence into the fewest high-value observations; NEVER emit one observation per evidence record; do not copy evidence text verbatim.',
    'Do not invent facts absent from the evidence. Do not output anything except the JSON.',
    // T2.5（2026-09-07）：会话动作流水转写禁令——模型曾把用户消息流写成
    // 「用户 询问/确认/审批/使用/处于/从事…」第三人称动作句，authority 虚高为 user_explicit，
    // 每轮注入流水账（实测 86 条）。动作流水无跨会话价值，不得成为 observation。
    'NEVER emit action transcripts of the current session such as subject=用户 with predicates like 询问/确认/审批/使用/回复/报告/处于/从事/完成 (or User asked/confirmed/used/...).',
    'Only durable, reusable conclusions qualify: user preferences (偏好/喜欢/倾向/希望/需要), corrections, stable facts, project conventions, environment facts.',
    'If a batch contains only such action logs, output {"observations":[]}.',
  ].join('\n')
  // P0-4：单条正文截断（默认 800 字符），避免长证据把 prompt 撑爆。
  // 截断保留可回溯性——observation 里带 evidenceIds，需要全文时按 id 回查。
  const cap = Number.isFinite(maxContentChars) && maxContentChars > 0
    ? maxContentChars
    : CONSOLIDATION_MAX_CONTENT_CHARS
  const userText = 'Evidence records (JSON):\n'
    + JSON.stringify(evidences.map((ev) => {
      const raw = String(ev.content ?? '')
      const content = raw.length > cap ? raw.slice(0, cap) + '…[truncated ' + raw.length + ' chars]' : raw
      return { id: ev.id, claimDomain: ev.claimDomain, content }
    }))
  return { system, userText }
}

/**
 * 最多 2 次 LLM 尝试（初次 + 1 次重试）。
 * P0-1（2026-09-02）：返回 { ok, observations, error }——**失败必须与「成功但产出 0 条」区分**。
 * 旧实现两种情况都返回 []，调用方无条件推进水位，导致失败批被永久标记已消化、永不重试
 * （实例实证：2026-09-01 一次 run 处理 209 条证据、产出 0 条，水位照常推进 → 209 条永久跳过）。
 */
async function deriveViaLlm(evidences, llmCall, logger, maxContentChars) {
  const { system, userText } = buildConsolidationPrompt(evidences, maxContentChars)
  let lastError = 'unknown'
  for (let attempt = 0; attempt < 2; attempt++) {
    let text
    try {
      text = await llmCall(userText, system)
    } catch (err) {
      lastError = 'llm_call_failed: ' + (err && err.message)
      logger?.warn?.('[acp] consolidation llm call failed (attempt ' + (attempt + 1) + '/2): ' + (err && err.message))
      continue
    }
    const parsed = parseObservations(text)
    if (parsed.ok) return { ok: true, observations: parsed.observations, warnings: parsed.warnings }
    lastError = 'parse_failed'
    logger?.warn?.('[acp] consolidation llm output parse failed (attempt ' + (attempt + 1) + '/2)')
  }
  return { ok: false, observations: [], warnings: [], error: lastError }
}

// ===================== M3 B3：style 候选 → policy（guarded auto promotion） =====================
// 流程（M3-PLAN §6.4）：
//   consolidation 产出 style 候选 → evaluateCandidate（evidenceRows=候选证据+相关证据）
//     → decision=promote 且 config.autoPromote=true → autoPromote 路径（候选行 promote +
//       reviewStatus 同步 + audit + view 重写，由 index 注入的 autoPromote 执行）
//     → 否则维持现状（pending_promotion → manual approval 路径）
// 方向性（B2 报告集成点 1）：候选证据默认 supports；同键 superseded 旧证据标 opposes
// （反向纠正 → policy 走 hold → 留人工）。

/** 标 pending 标记（幂等 + 不降级已 promoted 证据）；失败静默（fail-open） */
function markPending(ledger, evId, logger) {
  try {
    const row = ledger.getById(evId)
    if (row && row.state === 'active'
      && row.metadata?.reviewStatus !== PENDING_PROMOTION
      && row.metadata?.reviewStatus !== 'promoted') {
      ledger.updateMetadata(evId, { reviewStatus: PENDING_PROMOTION })
    }
  } catch (err) {
    logger?.warn?.('[acp] style pending mark error: ' + (err && err.message))
  }
}

/** 同证据集（无序）匹配已有 style 候选（reuse-or-create 的去重依据） */
function findCandidateForEvidenceIds(candidateStore, scopeId, evidenceIds) {
  const want = new Set(evidenceIds)
  for (const c of candidateStore.listCandidates({ scopeId, limit: 200 })) {
    if (c.domain !== 'style') continue
    const ids = c.evidenceIds ?? []
    if (ids.length === want.size && ids.every((id) => want.has(id))) return c
  }
  return null
}

/**
 * 处理一条 style 观察派生：
 *  - 无 B3 依赖（candidateStore/policyEvaluate 缺失）→ 维持 M2 行为：仅标 pending_promotion；
 *  - 有依赖 → reuse-or-create 候选 → 装配证据行（含方向）→ evaluateCandidate：
 *      promote → autoPromote；否则 → pending_promotion（manual 路径）。
 * @returns {'pending'|'auto-promoted'|'promoted'|string} 处理结果（测试/日志用）
 */
// auditStore：调用方仍按此键传入（保留键位兼容），本函数当前不使用 → 绑定加下划线前缀。
function handleStyleCandidate({ obs, ledger, candidateStore, auditStore: _auditStore, policyEvaluate, autoPromote, scopeId, logger }) {
  const evidenceIds = Array.isArray(obs.evidenceIds) ? obs.evidenceIds : []
  if (!candidateStore || typeof policyEvaluate !== 'function') {
    for (const evId of evidenceIds) markPending(ledger, evId, logger)
    return 'pending'
  }
  // reuse-or-create：同证据集已有候选则复用；终态候选尊重既有决策（不再新建/复活）
  let candidate = findCandidateForEvidenceIds(candidateStore, scopeId, evidenceIds)
  if (candidate && candidate.state !== 'proposed') {
    return candidate.state === 'promoted' ? 'promoted' : 'decided-' + candidate.state
  }
  if (!candidate) {
    candidate = candidateStore.createCandidate({ scopeId, domain: 'style', evidenceIds })
  }
  // 证据行装配（B2 集成点 1）：候选证据默认 supports；同键 superseded 旧证据标 opposes
  const evidenceRows = []
  for (const evId of evidenceIds) {
    const ev = ledger.getById(evId)
    if (!ev) continue
    evidenceRows.push({ ...ev, direction: 'supports' })
    for (const prevId of ev.supersedes ?? []) {
      const prev = ledger.getById(prevId)
      if (prev) evidenceRows.push({ ...prev, direction: 'opposes' })
    }
  }
  // 冲突候选（B2 集成点 2）：同 scope+domain、非自身、proposed/promoted
  const conflictingCandidates = candidateStore.listCandidates({ scopeId, limit: 200 })
    .filter((c) => c.domain === 'style' && c.id !== candidate.id
      && (c.state === 'proposed' || c.state === 'promoted'))
    .map((c) => c.id)
  // policy 评估（纯函数零副作用；评估失败不阻断 → 落人工）
  let policyResult = null
  try {
    policyResult = policyEvaluate({ candidate: { ...candidate, conflictingCandidates }, evidenceRows })
  } catch (err) {
    logger?.warn?.('[acp] style policy evaluate error: ' + (err && err.message))
  }
  if (policyResult && policyResult.decision === 'promote' && typeof autoPromote === 'function') {
    try {
      autoPromote(candidate, policyResult)
      return 'auto-promoted'
    } catch (err) {
      logger?.warn?.('[acp] style auto promote error: ' + (err && err.message))
      // 自动路径失败 → 落人工（pending），不丢候选
    }
  }
  for (const evId of evidenceIds) markPending(ledger, evId, logger)
  return policyResult ? policyResult.decision : 'pending'
}

// ===================== Consolidator（队列 + 节流 + 派生） =====================

/**
 * 创建后台 consolidation 协调器。
 * @param {object} opts
 * @param {object} opts.ledger - openEvidenceLedger() 返回的 Provider
 * @param {string} [opts.scopeId] - 默认 'user-global'
 * @param {(userText: string, system: string) => Promise<string>} [opts.llmCall] - null 则走规则兜底
 * @param {number} [opts.minEvidence] - 默认 CONSOLIDATION_MIN_EVIDENCE
 * @param {number} [opts.minTurns] - 默认 CONSOLIDATION_MIN_TURNS
 * @param {object} [opts.logger] - 默认 console
 * @returns {object} 协调器句柄
 */
export function createConsolidator(opts = {}) {
  const {
    ledger,
    scopeId = 'user-global',
    llmCall = null,
    minEvidence = CONSOLIDATION_MIN_EVIDENCE,
    minTurns = CONSOLIDATION_MIN_TURNS,
    // P0-4（2026-09-02）：批次/正文/日频三重上限，关掉唯一的成本放大面
    maxBatch = CONSOLIDATION_MAX_BATCH,
    maxContentChars = CONSOLIDATION_MAX_CONTENT_CHARS,
    maxRunsPerDay = CONSOLIDATION_MAX_RUNS_PER_DAY,
    // P0 源头过滤（2026-09-09）：agent 自产 experience 动作流水不进队列
    skipAgentExperience = CONSOLIDATION_SKIP_AGENT_EXPERIENCE,
    // 2026-09-22：纯应答短消息（「继续」「重启好了」）不进队列
    skipAckOnly = CONSOLIDATION_SKIP_ACK_ONLY,
    // 2026-10-04 审计 P0-1：工具输出转写（external_tool）不进队列。**默认 false = 不过滤**（先 shadow）
    skipExternalTool = CONSOLIDATION_SKIP_EXTERNAL_TOOL,
    logger = console,
    // M3 B3：guarded auto promotion 依赖（index.mjs 装配；缺省 null = M2 行为）
    candidateStore = null,
    auditStore = null,
    policyEvaluate = null, // (args) => evaluateCandidate({...args, config})，index 注入
    autoPromote = null,    // (candidate, policyResult) => expression.autoPromote(...)，index 注入
  } = opts

  let pending = false
  let running = false
  let runPromise = null
  let currentLlmCall = llmCall // 可被 setLlmCall 更新（withService 模式：internal/service 重解析）

  function readMeta(key) {
    return typeof ledger.getMeta === 'function' ? ledger.getMeta(key) : null
  }
  function writeMeta(key, value) {
    if (typeof ledger.setMeta === 'function') ledger.setMeta(key, value)
  }

  function readTurnCount() {
    const v = readMeta(CONSOLIDATION_META_TURN_COUNT)
    const n = v == null ? 0 : Number(v)
    return Number.isFinite(n) ? n : 0
  }

  /** 未消化 = active 且 observedAt > 上次 consolidation 水位（按 observedAt 升序，保证分批可续）。
   *  源头过滤两道：P0（2026-09-09）agent 自产 experience 动作流水；
   *  纯应答（2026-09-22）零信息的续跑/确认短句。
   *  工具输出转写（2026-10-04）external_tool —— **默认关**，见 constants 里的 shadow 说明。 */
  function undigestedEvidence() {
    const watermark = readMeta(CONSOLIDATION_META_WATERMARK_TS)
    const active = typeof ledger.listActive === 'function'
      ? ledger.listActive(scopeId)
      : ledger.query({ scopeId, state: 'active' }).items
    const pendingRows = watermark
      ? active.filter((ev) => (ev.observedAt ?? '') > watermark)
      : [...active]
    return pendingRows
      .filter((ev) => !isConsolidationSkippable(ev, skipAgentExperience))
      .filter((ev) => !isAckOnlySkippable(ev, skipAckOnly))
      .filter((ev) => !isExternalToolSkippable(ev, skipExternalTool))
      .sort((a, b) => String(a.observedAt ?? '').localeCompare(String(b.observedAt ?? '')))
  }

  /** P0-4：本次实际送进 LLM 的批（最早的 maxBatch 条）；剩余留给下一轮 */
  function nextBatch() {
    const all = undigestedEvidence()
    const cap = Number.isFinite(maxBatch) && maxBatch > 0 ? maxBatch : all.length
    return all.length > cap ? all.slice(0, cap) : all
  }

  /** 节流判定：未消化 ≥ minEvidence 或 距上次 ≥ minTurns turn */
  function shouldRun() {
    return undigestedEvidence().length >= minEvidence || readTurnCount() >= minTurns
  }

  /** P0-4：日频上限（UTC 日切）。超限直接跳过，不消耗 LLM。 */
  function dailyRunsExceeded() {
    if (!Number.isFinite(maxRunsPerDay) || maxRunsPerDay <= 0) return false
    const today = new Date().toISOString().slice(0, 10)
    if (readMeta(CONSOLIDATION_META_RUN_DAY) !== today) return false
    const n = Number(readMeta(CONSOLIDATION_META_RUN_COUNT) ?? 0)
    return Number.isFinite(n) && n >= maxRunsPerDay
  }

  function recordRun() {
    const today = new Date().toISOString().slice(0, 10)
    const sameDay = readMeta(CONSOLIDATION_META_RUN_DAY) === today
    const n = sameDay ? Number(readMeta(CONSOLIDATION_META_RUN_COUNT) ?? 0) : 0
    writeMeta(CONSOLIDATION_META_RUN_DAY, today)
    writeMeta(CONSOLIDATION_META_RUN_COUNT, String((Number.isFinite(n) ? n : 0) + 1))
  }

  /** P0-1：失败留痕——meta 计数 + 可 grep 日志 + audit（op=consolidate, actor=consolidation） */
  function readFailCount() {
    const n = Number(readMeta(CONSOLIDATION_META_FAIL_COUNT) ?? 0)
    return Number.isFinite(n) ? n : 0
  }

  /**
   * 成功留痕（2026-09-10）。
   * 此前 fail_count 只增不减：58 连败后即便蒸馏已恢复，计数仍停在 58，
   * 看板无法区分「此刻仍在失败」与「早已恢复」；成功也不写 audit，
   * 历史里只剩 58 条 failure 行，无从判断最近一次蒸馏发生在何时。
   * 现值语义 = 连续失败次数：成功即归零并清除 last_failure。
   */
  function recordSuccess(batch, observations) {
    const failuresBefore = readFailCount()
    if (failuresBefore > 0) writeMeta(CONSOLIDATION_META_FAIL_COUNT, '0')
    if (failuresBefore > 0) writeMeta(CONSOLIDATION_META_LAST_FAILURE, '')
    try {
      auditStore?.appendAudit?.({
        op: 'consolidate',
        scopeId,
        actor: 'consolidation',
        reason: 'consolidation ok; watermark advanced',
        // 2026-09-11：payload 补批次区间与首尾 id。原先只记 batchSize，导致
        // 「处理过但零产出 observation」与「被水位线跳过」在数据上不可区分，
        // 体检脚本无法判定欠账真伪（2026-09-11 误报 56% 欠账的根因）。
        payload: {
          batchSize: batch.size, observations, failuresBefore,
          batchFrom: batch.from, batchTo: batch.to,
          batchFirstId: batch.firstId, batchLastId: batch.lastId,
        },
      })
    } catch (err) {
      logger?.warn?.('[acp] consolidation success audit write error: ' + (err && err.message))
    }
    return failuresBefore
  }

  function recordFailure(batch, error) {
    const batchSize = batch.size
    const n = Number(readMeta(CONSOLIDATION_META_FAIL_COUNT) ?? 0)
    writeMeta(CONSOLIDATION_META_FAIL_COUNT, String((Number.isFinite(n) ? n : 0) + 1))
    writeMeta(CONSOLIDATION_META_LAST_FAILURE, JSON.stringify({
      at: new Date().toISOString(), batchSize, error: String(error ?? 'unknown'),
    }))
    logger?.warn?.('[acp] acp:degraded consolidation_failed batch=' + batchSize
      + ' reason=' + String(error ?? 'unknown') + ' watermark_kept=true')
    try {
      auditStore?.appendAudit?.({
        op: 'consolidate',
        scopeId,
        actor: 'consolidation',
        reason: 'consolidation failed; watermark not advanced',
        // 失败批次同样记录区间与首尾 id：这批会被原样重试，留痕才能对账
        payload: {
          batchSize, error: String(error ?? 'unknown'),
          batchFrom: batch.from, batchTo: batch.to,
          batchFirstId: batch.firstId, batchLastId: batch.lastId,
        },
      })
    } catch (err) {
      logger?.warn?.('[acp] consolidation failure audit write error: ' + (err && err.message))
    }
  }

  /**
   * 推进水位线到本批最大 observedAt，返回 {from, to, advanced}。
   * 2026-09-11：空批次**绝不**再写 now（旧实现是 writeMeta(max || new Date().toISOString())）。
   * 那会把水位线盖到当下，任何 observedAt 早于 now 的证据（回填、时钟偏移、时区边界）
   * 都会被永久静默跳过，事后还无法从审计里看出来。
   */
  function advanceWatermark(evidences) {
    const from = readMeta(CONSOLIDATION_META_WATERMARK_TS) || ''
    let max = ''
    for (const ev of evidences) {
      const t = ev.observedAt ?? ''
      if (t > max) max = t
    }
    if (!max) return { from, to: from, advanced: false }
    writeMeta(CONSOLIDATION_META_WATERMARK_TS, max)
    return { from, to: max, advanced: true }
  }

  function resetTurns() {
    writeMeta(CONSOLIDATION_META_TURN_COUNT, '0')
  }

  function incrementTurns() {
    writeMeta(CONSOLIDATION_META_TURN_COUNT, String(readTurnCount() + 1))
  }

  /**
   * 执行一次 consolidation（awaitable，供测试与 dispose drain）。
   * @returns {{ran: boolean, digested: number, observations: number, reason?: string}}
   */
  async function runOnce() {
    if (running) return { ran: false, reason: 'running', digested: 0, observations: 0 }
    running = true
    try {
      if (dailyRunsExceeded()) {
        logger?.warn?.('[acp] acp:degraded consolidation_skipped reason=daily_cap max=' + maxRunsPerDay)
        return { ran: false, reason: 'daily_cap', digested: 0, observations: 0 }
      }
      const evidences = nextBatch()
      resetTurns() // 已消费本次触发的 turn 计数
      if (evidences.length === 0) {
        // 空批次不写水位线（旧行为会盖成 now，见 advanceWatermark 注释）
        return { ran: true, digested: 0, observations: 0 }
      }
      recordRun()

      /** 本批的可追溯描述：供审计留痕，并区分「已处理」与「被跳过」 */
      const batch = {
        size: evidences.length,
        from: readMeta(CONSOLIDATION_META_WATERMARK_TS) || '',
        to: '',
        firstId: evidences[0]?.id ?? null,
        lastId: evidences[evidences.length - 1]?.id ?? null,
      }

      let observations
      if (currentLlmCall) {
        const derived = await deriveViaLlm(evidences, currentLlmCall, logger, maxContentChars)
        if (!derived.ok) {
          // P0-1：LLM 失败 → **不推进水位**，这批留给下一轮重试；失败留痕可 grep。
          recordFailure(batch, derived.error)
          return { ran: true, digested: 0, observations: 0, reason: 'llm_failed' }
        }
        observations = derived.observations
        // 护栏留痕（2026-09-25 方案 3）：模型给了无回链的观测 → 照写（append-only、fail-open），
        // 但必须有一条可 grep 的降级日志。没有它，这条路今天只是「敞开着且没人知道」。
        for (const w of derived.warnings ?? []) {
          logger?.warn?.('[acp] acp:degraded observation_without_backlink ' + w)
        }
      } else {
        observations = ruleObservations(evidences)
      }

      let wrote = 0
      let flowSkipped = 0
      for (const obs of observations) {
        // T2.5（2026-09-07）：动作流水形态不落库（双保险——prompt 禁令之外的硬过滤；
        // 模型不听话时由这里兜底，防「用户 询问/确认…」再次以 user_explicit 入账）
        if (isActionFlowObservation(obs.subject, obs.predicate)) {
          flowSkipped += 1
          continue
        }
        const res = ledger.upsertObservation({ scopeId, ...obs })
        if (res.inserted || res.row) wrote += 1
        // style 候选（M3 B3）：policy 达标且 auto_promote=true → 自动提升；
        // 否则维持 M2 架构修正（后台任务无 agent → 标 pending_promotion，
        // 下个 turn 的 pre-step 有 agent 时统一发起面板审批）。
        if (obs.claimDomain === 'style') {
          handleStyleCandidate({ obs, ledger, candidateStore, auditStore, policyEvaluate, autoPromote, scopeId, logger })
        }
      }

      // T2.5 硬过滤命中数：此前只累加不落地（死变量），改为 debug 留痕便于观测
      if (flowSkipped > 0) {
        logger?.debug?.('[acp] consolidation 丢弃动作流水 observation ' + flowSkipped + ' 条（T2.5 硬过滤）')
      }
      batch.to = advanceWatermark(evidences).to
      const failuresBefore = recordSuccess(batch, wrote)
      return { ran: true, digested: evidences.length, observations: wrote, failuresBefore }
    } finally {
      running = false
      pending = false
    }
  }

  /**
   * turn/end 入队（fire-and-forget，不 await）。
   * 背压：已有 pending 任务时丢弃本次；节流不满足时跳过。
   * @returns {{queued: boolean, reason?: 'backpressure'|'throttle'|'error'}}
   */
  function enqueue() {
    try {
      incrementTurns()
      if (pending || running) return { queued: false, reason: 'backpressure' }
      if (!shouldRun()) return { queued: false, reason: 'throttle' }
      pending = true
      runPromise = runOnce()
        .catch((err) => { logger?.warn?.('[acp] consolidation error: ' + (err && err.message)) })
        .finally(() => { runPromise = null })
      return { queued: true }
    } catch (err) {
      logger?.warn?.('[acp] consolidate enqueue error: ' + (err && err.message))
      return { queued: false, reason: 'error' }
    }
  }

  /** 等待在途 run 完成（测试用）；无在途任务立即 resolve */
  function awaitIdle() {
    return runPromise ?? Promise.resolve()
  }

  /** 更新 LLM 调用（withService 模式：internal/service 事件触发时重解析） */
  function setLlmCall(fn) {
    currentLlmCall = fn ?? null
  }

  return {
    enqueue,
    runOnce,
    shouldRun,
    isPending: () => pending || running,
    awaitIdle,
    undigestedEvidence,
    readTurnCount,
    setLlmCall,
  }
}
