// src/store.mjs — Evidence Ledger 本地 SQLite Provider。
//
// append-only：evidence 表只 INSERT / UPDATE state（不物理删除）。
// 幂等：id 由 sourceRef + contentHash 派生（evidenceIdOf），重放同一事件自然得到
// 相同 id → INSERT OR IGNORE 即幂等；重复摄入返回 inserted:false。
// Provider 不做治理裁决（那是 governance.mjs 职责），也不做派生（那是 consolidation 职责）。
//
// schema v3（M3 B1，2026-08-28）：新增 candidate / candidate_events / audit 三表；
// store 层写操作（append / supersede / observation-upsert）内置 audit 行（actor='system'），
// 数据写 + audit 写同事务提交（写后即审）。
// v4（2026-08-30，feature/injection-isolation）：evidence 表新增 session_id 列
// （会话分层注入/隔离用）；存量库 ALTER TABLE + 从 source_ref.sessionEventId 解析回填。
// v5（2026-09-07，PLAN-S2 P3）：observation 表新增 authority 列（溯源权威聚合），见 constants。

import { DatabaseSync } from 'node:sqlite'
import { mkdirSync, existsSync } from 'node:fs'
import path from 'node:path'
import { resolveDshHome } from './home.mjs'
import {
  SCHEMA_VERSION, EVIDENCE_STATES, OBSERVATION_STATES, AUTHORITIES, SOURCE_CLASSES,
  CLAIM_DOMAINS, SENSITIVITIES, SCOPES, SESSION_TYPES,
  MAX_OBSERVATION_TEXT_CHARS, CANDIDATE_MEMORY_STATES,
  evidenceIdOf, hashHex,
} from './constants.mjs'
import { assertAuthorityConsistent } from './governance.mjs'
// 回链档位（2026-09-25 方案 3）：读侧判「本机缺回链」还是「外机不可核验」，靠的就是
// id 与自身字段的自洽性 —— 所以 observationIdOf 必须与写入路径**同一份实现**，不能各写一份。
import { observationIdOf, classifyBacklink } from './backlink.mjs'
import { createAuditStore } from './audit.mjs'
import { createCandidateStore } from './candidate.mjs'
import { createRuleStore } from './rule.mjs'

const PRAGMAS = 'PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;'

/** metadata 固定键集（2026-08-25 决策）：写路径只接受这些键 */
const METADATA_ALLOWED_KEYS = new Set([
  'ttlDays',
  'reviewStatus',
  'scenarioTags',
  'sourceVersion',
])

function assertMetadataKeys(metadata) {
  if (!metadata) return {}
  if (typeof metadata !== 'object' || Array.isArray(metadata)) {
    throw new TypeError('metadata must be an object')
  }
  for (const key of Object.keys(metadata)) {
    if (!METADATA_ALLOWED_KEYS.has(key)) {
      throw new TypeError(`metadata key '${key}' not allowed (allowed: ${[...METADATA_ALLOWED_KEYS].join(', ')})`)
    }
  }
  return metadata
}


const SCHEMA = `
CREATE TABLE IF NOT EXISTS acp_meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS evidence (
  id            TEXT PRIMARY KEY,      -- evidenceIdOf(sourceRef, contentHash)
  scope_id      TEXT NOT NULL,
  session_id    TEXT NOT NULL DEFAULT '',  -- 来源会话（v4；存量从 source_ref 回填）
  agent_key     TEXT NOT NULL DEFAULT '',
  session_type  TEXT NOT NULL,
  source_class  TEXT NOT NULL,
  authority     TEXT NOT NULL,
  confidence    REAL NOT NULL,
  durability    REAL NOT NULL,
  sensitivity   TEXT NOT NULL,
  claim_domain  TEXT NOT NULL,
  content       TEXT NOT NULL,
  content_hash  TEXT NOT NULL,
  source_ref    TEXT NOT NULL,          -- JSON
  observed_at   TEXT NOT NULL,
  valid_from    TEXT,
  valid_until   TEXT,
  state         TEXT NOT NULL DEFAULT 'active',
  supersedes    TEXT NOT NULL DEFAULT '[]',  -- JSON array
  metadata      TEXT NOT NULL DEFAULT '{}',  -- JSON
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_evidence_scope_state ON evidence (scope_id, state);
CREATE INDEX IF NOT EXISTS idx_evidence_content_hash ON evidence (content_hash);
CREATE INDEX IF NOT EXISTS idx_evidence_observed_at ON evidence (observed_at);

CREATE TABLE IF NOT EXISTS observation (
  id            TEXT PRIMARY KEY,
  scope_id      TEXT NOT NULL,
  subject       TEXT NOT NULL,
  predicate     TEXT NOT NULL,
  claim_domain  TEXT NOT NULL,
  authority     TEXT,                    -- 溯源权威（v5，PLAN-S2 P3；NULL=旧行，读侧回退 single_observation）
  text          TEXT NOT NULL,
  evidence_ids  TEXT NOT NULL DEFAULT '[]',  -- JSON array
  supersedes    TEXT NOT NULL DEFAULT '[]',  -- JSON array（方案甲：直接前驱）
  state         TEXT NOT NULL DEFAULT 'active',
  observed_at   TEXT NOT NULL,
  created_at    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_observation_scope ON observation (scope_id);
CREATE INDEX IF NOT EXISTS idx_observation_claim_domain ON observation (claim_domain);
CREATE INDEX IF NOT EXISTS idx_observation_key ON observation (scope_id, subject, predicate, claim_domain);

CREATE TABLE IF NOT EXISTS candidate (
  id              TEXT PRIMARY KEY,
  scope_id        TEXT NOT NULL,
  domain          TEXT NOT NULL,
  evidence_ids    TEXT NOT NULL DEFAULT '[]',  -- JSON array
  state           TEXT NOT NULL DEFAULT 'proposed',
  policy          TEXT,                          -- JSON（B2 评估快照，创建时为 NULL）
  decision_reason TEXT,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_candidate_scope_state ON candidate (scope_id, state);

CREATE TABLE IF NOT EXISTS candidate_events (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,  -- 重放顺序 = 插入顺序
  candidate_id TEXT NOT NULL,
  ts           INTEGER NOT NULL,
  event        TEXT NOT NULL,
  reason       TEXT NOT NULL DEFAULT '',
  actor        TEXT NOT NULL,
  payload      TEXT                                -- JSON（create 事件携带静态属性）
);

CREATE INDEX IF NOT EXISTS idx_candidate_events_candidate ON candidate_events (candidate_id, id);

CREATE TABLE IF NOT EXISTS audit (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  ts        INTEGER NOT NULL,
  op        TEXT NOT NULL,
  target_id TEXT,
  scope_id  TEXT NOT NULL,
  actor     TEXT NOT NULL,
  reason    TEXT NOT NULL DEFAULT '',
  payload   TEXT                                -- JSON
);

CREATE INDEX IF NOT EXISTS idx_audit_op ON audit (op);
CREATE INDEX IF NOT EXISTS idx_audit_scope ON audit (scope_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit (actor);

-- v6（2026-09-07，T4 M4.1）：rule 表——反馈通道规则（一等对象，与 evidence 互链）。
-- 状态机：draft（沉淀草案）→ active（审批通过）/ rejected（用户拒绝）；修订 = 新行 supersedes 旧行。
CREATE TABLE IF NOT EXISTS rule (
  id            TEXT PRIMARY KEY,      -- ruleIdOf(scope_id, domain, text)
  scope_id      TEXT NOT NULL DEFAULT 'user-global',
  domain        TEXT NOT NULL,          -- 规则域（workflow/habit/communication/security/...自由文本≤24）
  title         TEXT NOT NULL,          -- 短标题（≤60）
  text          TEXT NOT NULL,          -- 规则正文（铁律候选 ≤200 字）
  gates         TEXT NOT NULL DEFAULT '[]',   -- JSON：触发闸门 ['explicit-prefix','repeated-2x','security',...]
  evidence_ids  TEXT NOT NULL DEFAULT '[]',   -- JSON：支撑证据 id 列表（与 ledger 互链）
  supersedes    TEXT NOT NULL DEFAULT '',     -- 直接前驱 rule id（修订链，同 observation 方案甲）
  state         TEXT NOT NULL DEFAULT 'draft',-- draft/active/rejected/superseded
  source        TEXT NOT NULL DEFAULT 'consolidation', -- consolidation|manual
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL,
  active_from   INTEGER,                -- 审批通过时间戳
  active_until  INTEGER                 -- 失效时间戳（superseded/rejected 时记录）
);
CREATE INDEX IF NOT EXISTS idx_rule_scope_state ON rule (scope_id, state);
CREATE INDEX IF NOT EXISTS idx_rule_domain ON rule (scope_id, domain);

-- v7（2026-09-22，Dreaming 第一增量）：candidate_memory —— 离线巩固的候选池。
-- **物理分离**是硬要求：候选绝不直接变成 observation（「错误知识被自动晋升」的唯一硬防线，
-- 见 docs/design/DREAMING.md §3）。状态机 candidate→observed→consensus→approved/rejected。
CREATE TABLE IF NOT EXISTS candidate_memory (
  id              TEXT PRIMARY KEY,           -- 由 (scope, clusterKey, memberIds) 派生 → 幂等重跑
  scope_id        TEXT NOT NULL DEFAULT 'user-global',
  state           TEXT NOT NULL DEFAULT 'candidate',
  claim_domain    TEXT NOT NULL,
  subject         TEXT NOT NULL,              -- 簇代表主体（成员中最常见者）
  text            TEXT NOT NULL,              -- 簇代表正文（取成员原文，不新造语义）
  observation_ids TEXT NOT NULL DEFAULT '[]', -- JSON：簇成员 observation id
  evidence_ids    TEXT NOT NULL DEFAULT '[]', -- JSON：成员溯源证据并集（可回溯到 session/时间）
  sessions        TEXT NOT NULL DEFAULT '[]', -- JSON：出现过的 session 集合（复现计数）
  days            INTEGER NOT NULL DEFAULT 0, -- 出现的不同自然日数
  occurrences     INTEGER NOT NULL DEFAULT 0,
  first_seen      TEXT NOT NULL DEFAULT '',
  last_seen       TEXT NOT NULL DEFAULT '',
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_candidate_memory_scope_state ON candidate_memory (scope_id, state);
CREATE INDEX IF NOT EXISTS idx_candidate_memory_domain ON candidate_memory (claim_domain);

-- v7：dream_run —— 每次离线跑批的台账（可审计、可解释：为什么这次没晋升）
CREATE TABLE IF NOT EXISTS dream_run (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  ts          INTEGER NOT NULL,
  window_from TEXT,
  window_to   TEXT,
  scanned     INTEGER NOT NULL DEFAULT 0,
  clustered   INTEGER NOT NULL DEFAULT 0,
  promoted    INTEGER NOT NULL DEFAULT 0,
  archived    INTEGER NOT NULL DEFAULT 0,
  dry_run     INTEGER NOT NULL DEFAULT 0,
  note        TEXT NOT NULL DEFAULT ''
);
`

function assertChoice(value, allowed, label) {
  if (!allowed.includes(value)) {
    throw new TypeError(`${label} must be one of ${allowed.join('|')}, got ${JSON.stringify(value)}`)
  }
}

/**
 * @param {object} opts
 * @param {string} [opts.dir]       默认 $DSH_HOME 下 acp 目录
 * @returns {object} LedgerProvider 句柄
 */
export function openEvidenceLedger(opts = {}) {
  // 回落链：显式 dir > $DSH_HOME/acp > ~/.dsh/acp（见 src/home.mjs）
  const dir = opts.dir ?? path.join(resolveDshHome(), 'acp')
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
  const dbPath = path.join(dir, opts.dbName ?? 'acp-ledger.db')
  const db = new DatabaseSync(dbPath)
  db.exec(PRAGMAS)
  db.exec(SCHEMA)
  const existing = db.prepare('SELECT value FROM acp_meta WHERE key = ?').get('schema_version')
  const existingVersion = existing ? Number(existing.value) : 0
  if (existingVersion > SCHEMA_VERSION) {
    db.close()
    throw new Error(`ACP ledger schema mismatch: db=${existing.value} expected=${SCHEMA_VERSION}`)
  }
  // 迁移始终尝试（migrateSessionId 幂等：列已存在即 no-op）——版本号相同也可能是
  // 旧版本代码建的库（如 v3 库升级前已写入 version 3），不能只靠版本号差异触发。
  // 历史迁移：v1 → v2 新增 observation 表；v2 → v3 新增 candidate / candidate_events / audit 表；
  // v3 → v4 evidence 加 session_id 列并从 source_ref 回填。
  // SCHEMA 全部 CREATE TABLE IF NOT EXISTS，不破坏既有表；新库亦走此路径写入当前版本号。
  migrateSessionId(db)
  migrateObservationAuthority(db)
  if (existingVersion !== SCHEMA_VERSION) {
    db.prepare('INSERT OR REPLACE INTO acp_meta (key, value) VALUES (?, ?)').run('schema_version', String(SCHEMA_VERSION))
  }

  // M3 B1：candidate / audit 操作层装配（表 DDL 已在 SCHEMA，工厂只操作同一 db 句柄）
  const auditStore = createAuditStore({ db })
  const candidateStore = createCandidateStore({ db })
  const ruleStore = createRuleStore({ db }) // v6（T4 M4.1）：反馈通道规则操作层

  const insertStmt = db.prepare(`
    INSERT OR IGNORE INTO evidence (
      id, scope_id, session_id, agent_key, session_type, source_class, authority,
      confidence, durability, sensitivity, claim_domain, content, content_hash,
      source_ref, observed_at, valid_from, valid_until, state, supersedes, metadata,
      created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `)

  const updateStateStmt = db.prepare('UPDATE evidence SET state = ?, updated_at = ? WHERE id = ?')
  const updateSupersedesStmt = db.prepare('UPDATE evidence SET supersedes = ?, state = ?, updated_at = ? WHERE id = ?')

  /**
   * 追加一条 Evidence（幂等）。
   * @param {object} input
   * @returns {{inserted: boolean, id: string, row?: object}}
   */
  function append(input) {
    // --- validate（先 validate 后 write，DSH 插件核心规则）---
    assertChoice(input.sourceClass, SOURCE_CLASSES, 'sourceClass')
    assertChoice(input.authority, AUTHORITIES, 'authority')
    assertChoice(input.sensitivity, SENSITIVITIES, 'sensitivity')
    assertChoice(input.claimDomain, CLAIM_DOMAINS, 'claimDomain')
    assertChoice(input.scopeId ?? 'user-global', SCOPES, 'scopeId')
    assertChoice(input.sessionType ?? 'root', SESSION_TYPES, 'sessionType')
    if (input.state && !EVIDENCE_STATES.includes(input.state)) {
      throw new TypeError(`state must be one of ${EVIDENCE_STATES.join('|')}`)
    }
    if (typeof input.content !== 'string' || input.content.length === 0) {
      throw new TypeError('content must be a non-empty string')
    }
    if (typeof input.confidence !== 'number' || input.confidence < 0 || input.confidence > 1) {
      throw new TypeError('confidence must be in [0, 1]')
    }
    if (typeof input.durability !== 'number' || input.durability < 0 || input.durability > 1) {
      throw new TypeError('durability must be in [0, 1]')
    }
    // authority 与 sourceClass 一致性校验（2026-08-25 决策）
    assertAuthorityConsistent(input.sourceClass, input.authority)
    // metadata 固定键集校验
    assertMetadataKeys(input.metadata)

    const contentHash = input.contentHash ?? hashHex(input.content)
    const sourceRef = input.sourceRef ?? {}
    const id = input.id ?? evidenceIdOf({ sourceRef, contentHash })
    const now = Date.now()
    const state = input.state ?? 'active'

    const scopeId = input.scopeId ?? 'user-global'
    // sessionId：显式传入优先；否则从 sourceRef 的 sessionEventId（"sessionId:seq"）派生
    const sessionId = input.sessionId ?? sessionIdOfSourceRef(sourceRef)

    // 数据写 + audit 写同事务（M3 B1：写后即审，原子提交）
    db.exec('BEGIN IMMEDIATE')
    try {
      insertStmt.run(
        id,
        scopeId,
        sessionId,
        input.agentKey ?? '',
        input.sessionType ?? 'root',
        input.sourceClass,
        input.authority,
        input.confidence,
        input.durability,
        input.sensitivity,
        input.claimDomain,
        input.content,
        contentHash,
        JSON.stringify(sourceRef),
        input.observedAt ?? new Date().toISOString(),
        input.validFrom ?? null,
        input.validUntil ?? null,
        state,
        JSON.stringify(input.supersedes ?? []),
        JSON.stringify(input.metadata ?? {}),
        now,
        now,
      )

      const changes = db.prepare('SELECT changes() AS c').get().c
      const inserted = changes > 0
      if (inserted) {
        auditStore.appendAudit({
          op: 'append',
          targetId: id,
          scopeId,
          actor: 'system',
          reason: 'evidence appended',
          payload: { contentHash },
        })
      }
      db.exec('COMMIT')
      const row = inserted ? getById(id) : null
      return { inserted, id, row }
    } catch (err) {
      db.exec('ROLLBACK')
      throw err
    }
  }

  function getById(id) {
    const r = db.prepare('SELECT * FROM evidence WHERE id = ?').get(id)
    return r ? toEvidence(r) : null
  }

  /** 状态迁移（supersede / quarantine / redact / 恢复 active）。
   * supersede 时内置 audit（actor='system'）；其余状态迁移不产生内置 audit（上层另行显式审计）。 */
  function setState(id, state, opts = {}) {
    assertChoice(state, EVIDENCE_STATES, 'state')
    const existing = getById(id) // 需要 scope_id 供 audit；不存在时 UPDATE 本为空操作
    db.exec('BEGIN IMMEDIATE')
    try {
      updateStateStmt.run(state, Date.now(), id)
      if (opts.supersedes) {
        updateSupersedesStmt.run(JSON.stringify(opts.supersedes), state, Date.now(), id)
      }
      if (state === 'superseded' && existing) {
        auditStore.appendAudit({
          op: 'supersede',
          targetId: id,
          scopeId: existing.scopeId,
          actor: 'system',
          reason: 'evidence superseded',
          payload: { supersedes: opts.supersedes ?? [] },
        })
      }
      db.exec('COMMIT')
    } catch (err) {
      db.exec('ROLLBACK')
      throw err
    }
    return getById(id)
  }

  /**
   * 局部更新 metadata（固定键集校验后合并，2026-08-25 决策）。
   * @param {string} id
   * @param {object} patch - metadata 增量（只允许 METADATA_ALLOWED_KEYS 内键）
   * @returns {object} 更新后的证据行
   */
  function updateMetadata(id, patch) {
    assertMetadataKeys(patch)
    const row = db.prepare('SELECT * FROM evidence WHERE id = ?').get(id)
    if (!row) throw new Error(`evidence '${id}' not found`)
    const merged = { ...JSON.parse(row.metadata), ...patch }
    db.prepare('UPDATE evidence SET metadata = ?, updated_at = ? WHERE id = ?')
      .run(JSON.stringify(merged), Date.now(), id)
    return getById(id)
  }

  /**
   * 查询（read-only）。支持 scope/state/claimDomain/authority/sourceClass 过滤 + 子串。
   * @param {object} q
   * @returns {{items: object[], total: number}}
   */
  function query(q = {}) {
    const conds = []
    const params = []
    if (q.scopeId) { conds.push('scope_id = ?'); params.push(q.scopeId) }
    if (q.sessionId === '') { conds.push("session_id = ''") }
    else if (typeof q.sessionId === 'string') { conds.push('session_id = ?'); params.push(q.sessionId) }
    else if (q.sessionId && typeof q.sessionId === 'object' && typeof q.sessionId.not === 'string') {
      conds.push('session_id != ?'); params.push(q.sessionId.not)
    }
    if (q.agentKey !== undefined) { conds.push('agent_key = ?'); params.push(q.agentKey) }
    if (q.state) { conds.push('state = ?'); params.push(q.state) }
    if (q.claimDomain) { conds.push('claim_domain = ?'); params.push(q.claimDomain) }
    if (q.authority) { conds.push('authority = ?'); params.push(q.authority) }
    if (q.sourceClass) { conds.push('source_class = ?'); params.push(q.sourceClass) }
    if (q.contentSubstr) { conds.push('content LIKE ? ESCAPE \'\\\''); params.push(`%${escapeLike(q.contentSubstr)}%`) }
    if (Array.isArray(q.contentAnySubstr) && q.contentAnySubstr.length > 0) {
      // OR 语义召回：任一子串命中即候选（CJK bigram / token 召回用）
      const ors = q.contentAnySubstr.map(() => "content LIKE ? ESCAPE '\\'")
      conds.push('(' + ors.join(' OR ') + ')')
      for (const sub of q.contentAnySubstr) params.push(`%${escapeLike(sub)}%`)
    }
    if (q.validAt) { conds.push('(valid_from IS NULL OR valid_from <= ?) AND (valid_until IS NULL OR valid_until >= ?)'); params.push(q.validAt, q.validAt) }
    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : ''
    const limit = Math.min(q.limit ?? 50, 200)
    const rows = db.prepare(`SELECT * FROM evidence ${where} ORDER BY observed_at DESC LIMIT ?`).all(...params, limit)
    const total = db.prepare(`SELECT COUNT(*) AS c FROM evidence ${where}`).get(...params).c
    return { items: rows.map(toEvidence), total }
  }

  /** 去重候选：同 contentHash 的已有证据（供 idempotency 审计） */
  function byContentHash(contentHash) {
    return db.prepare('SELECT * FROM evidence WHERE content_hash = ?').all(contentHash).map(toEvidence)
  }

  /** 全部 active 证据（供快照/导出） */
  function listActive(scopeId) {
    const rows = scopeId
      ? db.prepare('SELECT * FROM evidence WHERE state = ? AND scope_id = ? ORDER BY observed_at DESC').all('active', scopeId)
      : db.prepare('SELECT * FROM evidence WHERE state = ? ORDER BY observed_at DESC').all('active')
    return rows.map(toEvidence)
  }

  function stats() {
    const r = db.prepare(`
      SELECT COUNT(*) AS total,
             SUM(CASE WHEN state = 'active' THEN 1 ELSE 0 END) AS active,
             SUM(CASE WHEN state = 'quarantined' THEN 1 ELSE 0 END) AS quarantined,
             SUM(CASE WHEN state = 'superseded' THEN 1 ELSE 0 END) AS superseded
      FROM evidence
    `).get()
    return { total: r.total ?? 0, active: r.active ?? 0, quarantined: r.quarantined ?? 0, superseded: r.superseded ?? 0 }
  }

  // ===================== meta 水位（consolidation 节流用） =====================

  function getMeta(key) {
    const r = db.prepare('SELECT value FROM acp_meta WHERE key = ?').get(key)
    return r ? r.value : null
  }

  function setMeta(key, value) {
    db.prepare('INSERT OR REPLACE INTO acp_meta (key, value) VALUES (?, ?)').run(key, String(value))
  }

  // ===================== Observation（可版本化派生认知） =====================
  // 冲突检测键 = scope_id + subject + predicate + claim_domain。
  // 冲突 supersede 语义（方案甲，CONTRACTS.md §8）：
  //   同键新 Observation 写入 → 旧行 state='superseded'，新行 supersedes=[旧 id]。
  //   supersedes 属于替代者一侧——"新 observation 替代了谁"，不是被替代者记新 id。
  //   getObservationLineage(id) 沿 supersedes 回溯得到 [最旧 ... 最新]。

  const insertObservationStmt = db.prepare(`
    INSERT OR IGNORE INTO observation (
      id, scope_id, subject, predicate, claim_domain, authority, text, evidence_ids, supersedes, state, observed_at, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `)

  // 稳定派生 id：同键 + 同正文 + 同证据集重派生天然幂等（重复写不产生新行）。
  // **实现已搬到 src/backlink.mjs**（2026-09-25 方案 3）并在此 import —— 读侧回链档位判据
  // 的核心就是「id 与自身字段是否自洽」，两处各写一份必然漂移、判据静默失效。
  // 口径不变：'obs_' + sha256(scope|subject|predicate|domain|text|JSON(evidenceIds)) 前 24 位。

  /** 行 → 回链档位（只标注，不参与任何校验/写入决策） */
  function backlinkOf(row) {
    if (!row) return null
    const v = classifyBacklink(row)
    return { tier: v.tier, label: v.label, foreign: v.foreign, reason: v.reason, alert: v.tier === 'missing_backlink' }
  }

  /**
   * 写入/更新一条 Observation（冲突 supersede）。
   * @param {object} input - { scopeId?, subject, predicate, claimDomain, text, evidenceIds?, id?, observedAt? }
   * @returns {{inserted: boolean, id: string, row: object|null, supersededId: string|null}}
   */
  function upsertObservation(input) {
    assertChoice(input.claimDomain, CLAIM_DOMAINS, 'claimDomain')
    const scopeId = input.scopeId ?? 'user-global'
    assertChoice(scopeId, SCOPES, 'scopeId')
    if (input.state && !OBSERVATION_STATES.includes(input.state)) {
      throw new TypeError(`observation state must be one of ${OBSERVATION_STATES.join('|')}`)
    }
    const subject = String(input.subject ?? '').trim()
    const predicate = String(input.predicate ?? '').trim()
    if (!subject || !predicate) {
      throw new TypeError('observation subject and predicate must be non-empty')
    }
    let text = String(input.text ?? '')
    if (!text) throw new TypeError('observation text must be non-empty')
    if (text.length > MAX_OBSERVATION_TEXT_CHARS) text = text.slice(0, MAX_OBSERVATION_TEXT_CHARS)
    const claimDomain = input.claimDomain
    const evidenceIds = Array.isArray(input.evidenceIds) ? input.evidenceIds.map(String) : []
    // P3（PLAN-S2 §8.3）：observation 的权威来自溯源证据（蒸馏产物 ≠ 原始 evidence）。
    // 显式 authority（import 恢复等）优先；缺省按 evidenceIds 聚合（deterministic）。
    let authority = null
    if (input.authority !== undefined && input.authority !== null) {
      assertChoice(input.authority, AUTHORITIES, 'authority')
      authority = input.authority
    } else {
      authority = resolveObservationAuthority(db, evidenceIds)
    }
    const id = input.id ?? observationIdOf({ scopeId, subject, predicate, claimDomain, text, evidenceIds })

    // 幂等：同 id（同键+同正文+同证据）重写直接返回，不自 supersede
    const byId = db.prepare('SELECT * FROM observation WHERE id = ?').get(id)
    if (byId) {
      // 幂等命中：档位按**库里那一行**判，不按入参判 —— 外机导入行（显式 id + 空回链）
      // 再走一次 upsert 时，不能被误报成本机缺回链。
      const existing = toObservation(byId)
      return { inserted: false, id, row: existing, supersededId: null, backlink: backlinkOf(existing) }
    }

    // 冲突：同键且 active 的旧行（事务内：冲突翻转 + 插入 + audit 原子提交）
    db.exec('BEGIN IMMEDIATE')
    try {
      const conflict = db.prepare(`
        SELECT id FROM observation
        WHERE scope_id = ? AND subject = ? AND predicate = ? AND claim_domain = ? AND state = 'active'
      `).get(scopeId, subject, predicate, claimDomain)

      let supersedes = []
      let supersededId = null
      if (conflict) {
        db.prepare(`UPDATE observation SET state = 'superseded' WHERE id = ?`).run(conflict.id)
        supersedes = [conflict.id]
        supersededId = conflict.id
      }

      insertObservationStmt.run(
        id, scopeId, subject, predicate, claimDomain, authority,
        text,
        JSON.stringify(evidenceIds), JSON.stringify(supersedes), 'active',
        input.observedAt ?? new Date().toISOString(), Date.now(),
      )
      auditStore.appendAudit({
        op: 'observation-upsert',
        targetId: id,
        scopeId,
        actor: 'system',
        reason: 'observation upserted',
        payload: { supersededId },
      })
      db.exec('COMMIT')
      const row = getObservationById(id)
      // 护栏（方案 3 的 B 部分）：本机写入路径产出无回链的 observation 时**不拒绝**
      // （账本 append-only、fail-open），但把档位与告警随结果返回，让调用方必须看见。
      return { inserted: true, id, row, supersededId, backlink: backlinkOf(row) }
    } catch (err) {
      db.exec('ROLLBACK')
      throw err
    }
  }

  function getObservationById(id) {
    const r = db.prepare('SELECT * FROM observation WHERE id = ?').get(id)
    return r ? toObservation(r) : null
  }

  /**
   * 查询 Observation（read-only）。支持 scope/state/claimDomain/subject/predicate 过滤。
   * @param {object} q
   * @returns {{items: object[], total: number}}
   */
  function queryObservation(q = {}) {
    const conds = []
    const params = []
    if (q.scopeId) { conds.push('scope_id = ?'); params.push(q.scopeId) }
    if (q.state) { conds.push('state = ?'); params.push(q.state) }
    if (q.claimDomain) { conds.push('claim_domain = ?'); params.push(q.claimDomain) }
    if (q.subject) { conds.push('subject = ?'); params.push(q.subject) }
    if (q.predicate) { conds.push('predicate = ?'); params.push(q.predicate) }
    // 2026-09-07（maid P0-1）：authority 过滤（IN 列表，供 PIN 钉扎只取高权威轨）
    if (Array.isArray(q.authorities) && q.authorities.length > 0) {
      const marks = q.authorities.map(() => '?').join(', ')
      conds.push('authority IN (' + marks + ')')
      params.push(...q.authorities)
    }
    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : ''
    const limit = Math.min(q.limit ?? 50, 200)
    const orderDir = q.order === 'desc' ? 'DESC' : 'ASC'
    const rows = db.prepare('SELECT * FROM observation ' + where + ' ORDER BY observed_at ' + orderDir + ', id ' + orderDir + ' LIMIT ?').all(...params, limit)
    const total = db.prepare(`SELECT COUNT(*) AS c FROM observation ${where}`).get(...params).c
    return { items: rows.map(toObservation), total }
  }

  /** 全部 active Observation（供快照/导出） */
  function listObservations(scopeId) {
    const rows = scopeId
      ? db.prepare('SELECT * FROM observation WHERE state = ? AND scope_id = ? ORDER BY created_at ASC').all('active', scopeId)
      : db.prepare('SELECT * FROM observation WHERE state = ? ORDER BY created_at ASC').all('active')
    return rows.map(toObservation)
  }

  /** 演进历史：[最旧 ... 最新]（沿 supersedes 直接前驱回溯，含 id 自己） */
  function getObservationLineage(id) {
    if (!getObservationById(id)) throw new Error(`observation '${id}' not found`)
    const collected = []
    const seen = new Set()
    const walk = (obs) => {
      if (seen.has(obs.id)) return
      seen.add(obs.id)
      for (const prevId of obs.supersedes ?? []) {
        const prev = getObservationById(prevId)
        if (!prev) continue // 悬挂引用容忍
        walk(prev)
      }
      collected.push(obs.id)
    }
    walk(getObservationById(id))
    const createdAt = new Map(collected.map((oid) => [oid, getObservationById(oid).createdAt]))
    return collected.slice().sort((a, b) => createdAt.get(a) - createdAt.get(b))
  }

  // ── Dreaming（v7，2026-09-22）：候选记忆池 ────────────────────────────────

  function toCandidateMemory(r) {
    return {
      id: r.id, scopeId: r.scope_id, state: r.state, claimDomain: r.claim_domain,
      subject: r.subject, text: r.text,
      observationIds: JSON.parse(r.observation_ids || '[]'),
      evidenceIds: JSON.parse(r.evidence_ids || '[]'),
      sessions: JSON.parse(r.sessions || '[]'),
      days: r.days, occurrences: r.occurrences,
      firstSeen: r.first_seen, lastSeen: r.last_seen,
      createdAt: r.created_at, updatedAt: r.updated_at,
    }
  }

  /**
   * 幂等写入候选记忆。
   * **不覆盖人的决定**：库里已是 approved/rejected 时只更新统计字段，state 原样保留
   * （否则每天重跑 dreaming 会把人工审批结果冲掉）。
   * @param {object} input
   * @returns {{inserted: boolean, id: string, startedState: string, row: object}}
   */
  function upsertCandidateMemory(input) {
    const scopeId = input.scopeId ?? 'user-global'
    const claimDomain = input.claimDomain
    if (!claimDomain) throw new TypeError('candidateMemory.claimDomain required')
    if (!input.id) throw new TypeError('candidateMemory.id required')
    assertChoice(input.state ?? 'candidate', CANDIDATE_MEMORY_STATES, 'candidateMemory.state')

    const existing = db.prepare('SELECT * FROM candidate_memory WHERE id = ?').get(input.id)
    const now = Date.now()
    if (existing) {
      // 人工已裁决的状态不受重跑影响
      const locked = existing.state === 'approved' || existing.state === 'rejected'
      const nextState = locked ? existing.state : (input.state ?? existing.state)
      db.prepare(`UPDATE candidate_memory SET
        state = ?, subject = ?, text = ?, observation_ids = ?, evidence_ids = ?,
        sessions = ?, days = ?, occurrences = ?, first_seen = ?, last_seen = ?, updated_at = ?
        WHERE id = ?`).run(
        nextState, input.subject ?? existing.subject, input.text ?? existing.text,
        JSON.stringify(input.observationIds ?? JSON.parse(existing.observation_ids)),
        JSON.stringify(input.evidenceIds ?? JSON.parse(existing.evidence_ids)),
        JSON.stringify(input.sessions ?? JSON.parse(existing.sessions)),
        input.days ?? existing.days, input.occurrences ?? existing.occurrences,
        input.firstSeen ?? existing.first_seen, input.lastSeen ?? existing.last_seen,
        now, input.id,
      )
      return { inserted: false, id: input.id, startedState: existing.state, row: getCandidateMemoryById(input.id) }
    }
    db.prepare(`INSERT INTO candidate_memory (
      id, scope_id, state, claim_domain, subject, text, observation_ids, evidence_ids,
      sessions, days, occurrences, first_seen, last_seen, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
      input.id, scopeId, input.state ?? 'candidate', claimDomain,
      input.subject ?? '', input.text ?? '',
      JSON.stringify(input.observationIds ?? []), JSON.stringify(input.evidenceIds ?? []),
      JSON.stringify(input.sessions ?? []), input.days ?? 0, input.occurrences ?? 0,
      input.firstSeen ?? '', input.lastSeen ?? '', now, now,
    )
    return { inserted: true, id: input.id, startedState: input.state ?? 'candidate', row: getCandidateMemoryById(input.id) }
  }

  function getCandidateMemoryById(id) {
    const r = db.prepare('SELECT * FROM candidate_memory WHERE id = ?').get(id)
    return r ? toCandidateMemory(r) : null
  }

  /** 查询候选记忆（read-only） */
  function queryCandidateMemory(q = {}) {
    const conds = []
    const params = []
    if (q.scopeId) { conds.push('scope_id = ?'); params.push(q.scopeId) }
    if (q.state) { conds.push('state = ?'); params.push(q.state) }
    if (q.claimDomain) { conds.push('claim_domain = ?'); params.push(q.claimDomain) }
    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : ''
    const limit = Math.min(q.limit ?? 50, 500)
    const rows = db.prepare('SELECT * FROM candidate_memory ' + where
      + ' ORDER BY occurrences DESC, last_seen DESC, id ASC LIMIT ?').all(...params, limit)
    const total = db.prepare(`SELECT COUNT(*) AS c FROM candidate_memory ${where}`).get(...params).c
    return { items: rows.map(toCandidateMemory), total }
  }

  /** 记一次 dreaming 跑批（台账，供审计与「为什么这次没晋升」的解释） */
  function recordDreamRun(input = {}) {
    const info = db.prepare(`INSERT INTO dream_run
      (ts, window_from, window_to, scanned, clustered, promoted, archived, dry_run, note)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
      input.ts ?? Date.now(), input.windowFrom ?? null, input.windowTo ?? null,
      input.scanned ?? 0, input.clustered ?? 0, input.promoted ?? 0, input.archived ?? 0,
      input.dryRun ? 1 : 0, input.note ?? '',
    )
    return Number(info.lastInsertRowid)
  }

  function listDreamRuns(limit = 20) {
    return db.prepare('SELECT * FROM dream_run ORDER BY ts DESC, id DESC LIMIT ?')
      .all(Math.min(limit, 200))
      .map((r) => ({
        id: r.id, ts: r.ts, windowFrom: r.window_from, windowTo: r.window_to,
        scanned: r.scanned, clustered: r.clustered, promoted: r.promoted,
        archived: r.archived, dryRun: r.dry_run === 1, note: r.note,
      }))
  }

  let closed = false
  function close() {
    if (closed) return // 幂等：重复 close 是 no-op
    closed = true
    db.close()
  }

  return {
    db, dbPath,
    append, getById, setState, updateMetadata, query, byContentHash, listActive, stats,
    getMeta, setMeta,
    upsertObservation, getObservationById, queryObservation, listObservations, getObservationLineage,
    candidateStore, auditStore, ruleStore,
    upsertCandidateMemory, getCandidateMemoryById, queryCandidateMemory, recordDreamRun, listDreamRuns,
    close,
  }
}

/**
 * 从 sourceRef 解析来源会话 id（v4 session_id 列派生）。
 * 解析顺序：sessionId → conversationId → sessionEventId（"sessionId:seq" 取前段）→ ''。
 * @param {object} ref - sourceRef（JSON.parse 后）
 * @returns {string}
 */
export function sessionIdOfSourceRef(ref) {
  if (!ref || typeof ref !== 'object') return ''
  const sid = ref.sessionId ?? ref.session_id
  if (typeof sid === 'string' && sid) return sid
  const cid = ref.conversationId ?? ref.conversation_id
  if (typeof cid === 'string' && cid) return cid
  const sev = ref.sessionEventId ?? ref.session_event_id
  if (typeof sev === 'string' && sev) {
    const i = sev.lastIndexOf(':')
    return i > 0 ? sev.slice(0, i) : sev
  }
  return ''
}

/**
 * v3 → v4 迁移：evidence 表加 session_id 列 + 从 source_ref 回填存量行。
 * 幂等：列已存在（新库 SCHEMA 直建）则 no-op；回填只处理可解析的会话。
 * @param {object} db - DatabaseSync 句柄
 */
function migrateSessionId(db) {
  const cols = db.prepare('PRAGMA table_info(evidence)').all()
  if (!cols.some((c) => c.name === 'session_id')) {
    // 旧库（v1-v3）无 session_id 列：加列 + 从 source_ref 回填
    db.exec("ALTER TABLE evidence ADD COLUMN session_id TEXT NOT NULL DEFAULT ''")
    const rows = db.prepare('SELECT id, source_ref FROM evidence').all()
    const upd = db.prepare('UPDATE evidence SET session_id = ? WHERE id = ?')
    for (const r of rows) {
      let ref = {}
      try { ref = JSON.parse(r.source_ref) } catch { /* 解析失败保持 '' */ }
      const sid = sessionIdOfSourceRef(ref)
      if (sid) upd.run(sid, r.id)
    }
  }
  // 索引必须在加列之后建（旧库 SCHEMA 阶段建会失败）；新库此处幂等
  db.exec('CREATE INDEX IF NOT EXISTS idx_evidence_session ON evidence (session_id, state)')
}

/**
 * v4 → v5 迁移：observation 表加 authority 列（溯源权威）。
 * 幂等：列已存在（新库 SCHEMA 直建）则 no-op；存量行保持 NULL（读侧回退 single_observation）。
 * @param {object} db - DatabaseSync 句柄
 */
function migrateObservationAuthority(db) {
  const cols = db.prepare('PRAGMA table_info(observation)').all()
  if (!cols.some((c) => c.name === 'authority')) {
    db.exec('ALTER TABLE observation ADD COLUMN authority TEXT')
  }
}

/**
 * Observation 溯源权威聚合（P3，PLAN-S2 §8.3；2026-09-09 改为非放大）。
 *
 * 秩序 = authority 的"用户确定性"排序：纠正 > 用户显式声明 > 系统策略 > 外部信息
 * > 单次观察 > agent 推断 > agent 自评。
 *
 * **取最低秩（non-amplification firewall）**：蒸馏后的 observation 不得比它最弱的那条
 * 支撑证据更可信——否则「用户显式声明 + agent 推断」合并出来的结论会顶着 user_explicit
 * 的名义进入注入，等于用弱证据洗白强权威（参见 arXiv 2607.29167：漏洞态合并记忆
 * ASR 实测可达 1.000）。旧实现取最高秩，正是这条放大路径。
 *
 * 推论：模型想让一条 observation 拿到高权威，只能只列真正支撑它的强证据。
 * @param {string[]} authorities - 溯源 evidence 的 authority 值集合
 * @returns {string} AUTHORITIES 之一
 */
export function deriveObservationAuthority(authorities) {
  const rank = {
    user_correction: 6,
    user_explicit: 5,
    system_policy: 4,
    external_information: 3,
    single_observation: 2,
    agent_inference: 1,
    agent_self_evaluation: 0,
  }
  if (!Array.isArray(authorities) || authorities.length === 0) return 'single_observation'
  let worst = null
  let worstRank = Number.POSITIVE_INFINITY
  for (const a of authorities) {
    const r = rank[a]
    if (r === undefined) continue
    if (r < worstRank) { worstRank = r; worst = a }
  }
  // 全部为未知值（旧行/脏数据）→ 回到保守默认
  return worst ?? 'single_observation'
}

/** 按 evidenceIds 查库聚合溯源权威（分块防变量上限；无匹配/空 → single_observation 兜底） */
function resolveObservationAuthority(db, evidenceIds) {
  if (!Array.isArray(evidenceIds) || evidenceIds.length === 0) return 'single_observation'
  const found = []
  for (let i = 0; i < evidenceIds.length; i += 400) {
    const chunk = evidenceIds.slice(i, i + 400)
    const marks = chunk.map(() => '?').join(',')
    const rows = db.prepare('SELECT authority FROM evidence WHERE id IN (' + marks + ')').all(...chunk)
    for (const r of rows) found.push(r.authority)
  }
  return deriveObservationAuthority(found)
}

function toEvidence(r) {
  return {
    id: r.id,
    scopeId: r.scope_id,
    sessionId: r.session_id,
    agentKey: r.agent_key,
    sessionType: r.session_type,
    sourceClass: r.source_class,
    authority: r.authority,
    confidence: r.confidence,
    durability: r.durability,
    sensitivity: r.sensitivity,
    claimDomain: r.claim_domain,
    content: r.content,
    contentHash: r.content_hash,
    sourceRef: JSON.parse(r.source_ref),
    observedAt: r.observed_at,
    validFrom: r.valid_from,
    validUntil: r.valid_until,
    state: r.state,
    supersedes: JSON.parse(r.supersedes),
    metadata: JSON.parse(r.metadata),
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  }
}

function escapeLike(s) {
  return s.replace(/[\\%_]/g, (m) => '\\' + m)
}

function toObservation(r) {
  return {
    id: r.id,
    scopeId: r.scope_id,
    subject: r.subject,
    predicate: r.predicate,
    claimDomain: r.claim_domain,
    authority: r.authority ?? null,
    text: r.text,
    evidenceIds: JSON.parse(r.evidence_ids),
    supersedes: JSON.parse(r.supersedes),
    state: r.state,
    observedAt: r.observed_at,
    createdAt: r.created_at,
  }
}