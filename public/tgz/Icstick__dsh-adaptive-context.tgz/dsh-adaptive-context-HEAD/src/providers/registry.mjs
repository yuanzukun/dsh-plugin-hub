// src/providers/registry.mjs — Recall Provider 注册表（M3 A1）。
//
// 多记忆源召回：注册表持有 N 个 recall provider 描述符，recallAll 并行召回，
// 各自超时 + fail-open（单 provider 故障不阻断，返回其余结果）。
//
// 缺省语义（2026-10-01 行为变更）：未提供 recallProviders → **无 provider**，
// 此时 listRecallProviders() 返回 []、recallAll 返回 []，与显式写 [] 完全等价。
// M2 时代的「缺省自动造默认 memos 项（127.0.0.1:18801）」兼容垫已拆除：memos
// 在本机/云端已摘除，缺省指向一个不存在的后端没有意义。要启用 memos 必须显式配置：
//   recallProviders: [{ id: 'memos', baseUrl: 'http://host:18801' }]（工厂仍在 memos.mjs）
//
// 描述符形状（kind 固定 'recall'）：
//   { id, enabled, timeoutMs, weight, baseUrl? }
//   可选 create() 工厂（自定义 provider 实例）；未知 id 且无工厂 → 视为不可用（fail-open）。
//
// 纪律：
//   - 只做召回编排，不做评分/排序（融合归 composer，M3 A3）
//   - 候选统一打 sourceProvider = 描述符 id（多源归一）
//   - 候选通过 recall-contract 校验（id/content/score/sourceProvider 齐全）
//   - 无 provider / 全部 provider 禁用 → recallAll 返回 []（hasProvider=false 由调用方从
//     listRecallProviders() 判定，走无 provider 权重行为）

import { createMemosProvider, MEMOS_DEFAULT_TIMEOUT_MS } from './memos.mjs'
import { isValidRecallCandidate } from './recall-contract.mjs'

/** 内置 provider 工厂（id → factory）。M3 MVP 只有 memos；v0.2 扩展 Reflect/Profile 等。 */
const DEFAULT_FACTORIES = Object.freeze({
  memos: (desc, hooks = {}) => createMemosProvider({
    baseUrl: desc.baseUrl,
    timeoutMs: desc.timeoutMs,
    onError: hooks.onError, // P0-2：失败上报给 registry 做健康跟踪（provider 仍 fail-open）
  }),
})

/**
 * 创建 Recall Provider 注册表。
 * @param {object} [opts]
 * @param {object[]} [opts.recallProviders] - 描述符数组（缺省/undefined 与显式 [] 等价：无 provider）
 * @param {object} [opts.defaults] - 跨 provider 缺省值（当前仅 timeoutMs）
 * @param {object} [opts.factories] - 额外 provider 工厂 { id: (desc) => provider }（测试注入用）
 * @returns {{
 *   listRecallProviders: () => object[],
 *   recallAll: ({text, limit}) => Promise<object[]>,
 * }}
 */
export function createProviderRegistry({ recallProviders, defaults = {}, factories = {}, logger = console } = {}) {
  const allFactories = { ...DEFAULT_FACTORIES, ...factories }
  const instances = new Map()
  // P0-2（2026-09-02）：provider 召回健康状态。
  // 旧实现失败完全静默返回 []，而调用方的 hasProvider 只看描述符 → composer 仍走
  // 「有语义 provider」的权重分支，语义召回实际为空却按有结果配权：**检索质量系统性下降且不可见**。
  const health = new Map() // id → { ok, error, at, consecutiveFailures }

  function recordSuccess(id) {
    health.set(id, { ok: true, error: null, at: new Date().toISOString(), consecutiveFailures: 0 })
  }
  function recordFailure(id, err) {
    const prev = health.get(id)
    const n = (prev?.consecutiveFailures ?? 0) + 1
    health.set(id, { ok: false, error: String(err?.message ?? err ?? 'unknown'), at: new Date().toISOString(), consecutiveFailures: n })
    logger?.warn?.('[acp] acp:degraded provider_recall_failed id=' + id
      + ' consecutive=' + n + ' reason=' + String(err?.message ?? err ?? 'unknown'))
  }

  /** 本轮/最近一次召回的 provider 健康快照（供 hasProvider 判定与 doctor 用） */
  function getHealth() {
    const out = {}
    for (const [id, h] of health) out[id] = { ...h }
    return out
  }

  /** 是否存在「已启用且最近一次召回没有失败」的 provider（未召回过视为可用） */
  function hasHealthyProvider() {
    const enabled = resolveDescriptors().filter((d) => d.enabled && canBuild(d))
    if (enabled.length === 0) return false
    return enabled.some((d) => {
      const h = health.get(d.id)
      return !h || h.ok === true
    })
  }

  /** 描述符 → 规范化副本（缺省字段补齐） */
  function normalizeDescriptor(desc) {
    if (!desc || typeof desc !== 'object') return null
    if (typeof desc.id !== 'string' || desc.id.length === 0) return null
    return {
      id: desc.id,
      kind: 'recall',
      enabled: desc.enabled !== false,
      timeoutMs: desc.timeoutMs ?? defaults.timeoutMs ?? MEMOS_DEFAULT_TIMEOUT_MS,
      weight: typeof desc.weight === 'number' && desc.weight >= 0 ? desc.weight : 1,
      baseUrl: desc.baseUrl,
      create: desc.create, // 自定义工厂透传（canBuild/getProvider 用）
    }
  }

  /** 最终描述符列表：recallProviders 缺省/非数组 → 无 provider；显式数组 → 原样（空数组同样无 provider） */
  function resolveDescriptors() {
    const list = Array.isArray(recallProviders) ? recallProviders : []
    return list
      .map(normalizeDescriptor)
      .filter((d) => d !== null)
  }

  /** 描述符能否实例化（内置工厂或自定义 create） */
  function canBuild(desc) {
    return typeof desc.create === 'function' || typeof allFactories[desc.id] === 'function'
  }

  /** 惰性实例化并缓存 provider */
  function getProvider(desc) {
    if (!instances.has(desc.id)) {
      const factory = typeof desc.create === 'function' ? desc.create : allFactories[desc.id]
      if (typeof factory !== 'function') return null
      // P0-2：第二参数是 hooks（onError）——自定义 create 忽略它不受影响
      instances.set(desc.id, factory(desc, { onError: (err) => recordFailure(desc.id, err) }))
    }
    return instances.get(desc.id)
  }

  /** 单 provider 召回：超时 + fail-open */
  async function recallOne(desc, { text, limit }) {
    const provider = getProvider(desc)
    if (!provider || typeof provider.recall !== 'function') return []
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), desc.timeoutMs)
    const recallPromise = Promise.resolve().then(() => provider.recall({ text, limit }, controller.signal))
    try {
      const hits = await Promise.race([
        recallPromise,
        new Promise((_, reject) => {
          controller.signal.addEventListener('abort', () => reject(new Error('acp recall timed out: ' + desc.id)), { once: true })
        }),
      ])
      if (!Array.isArray(hits)) {
        recordFailure(desc.id, 'provider returned non-array')
        return []
      }
      recordSuccess(desc.id)
      return hits
        .map((h) => (h !== null && typeof h === 'object' ? { ...h, sourceProvider: desc.id } : h))
        .filter(isValidRecallCandidate)
    } catch (err) {
      recordFailure(desc.id, err) // fail-open：单 provider 故障/超时不阻断其余，但**必须留痕**
      return []
    } finally {
      clearTimeout(timer)
    }
  }

  /**
   * 已启用的 recall provider 描述符列表（含 weight，供 composer providerWeights 装配）。
   * @returns {object[]} 规范化描述符副本
   */
  function listRecallProviders() {
    return resolveDescriptors()
      .filter((d) => d.enabled && canBuild(d))
      .map((d) => ({ ...d }))
  }

  /**
   * 并行召回全部启用 provider，合并候选（fail-open：单 provider 故障不阻断）。
   * @param {object} [query]
   * @param {string} [query.text] - 召回查询文本
   * @param {number} [query.limit] - 每 provider 上限
   * @returns {Promise<object[]>} RecallCandidate[]（sourceProvider 已按描述符 id 打标）
   */
  async function recallAll({ text, limit } = {}) {
    const providers = listRecallProviders()
    if (providers.length === 0) return []
    const results = await Promise.all(providers.map((desc) => recallOne(desc, { text, limit })))
    return results.flat()
  }

  return { listRecallProviders, recallAll, getHealth, hasHealthyProvider }
}
