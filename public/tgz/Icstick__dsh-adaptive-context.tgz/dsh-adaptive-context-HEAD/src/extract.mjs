// src/extract.mjs — SessionEvent → Evidence 规范化。
//
// 职责：把 DSH 的 durable session events 转成 Evidence 写入候选。
// 关键：sourceClass / authority / claimDomain 全部**确定性赋值**（不依赖 LLM）——
// 由事件类型 + 内容特征决定，保证写入时权威声明可信。
// 幂等：contentHash = sha256(规范化文本)，sourceRef = { sessionEventId }，
// 同一事件重放必然得到同一 Evidence id。
//
// 2026-08-26 真实契约校准：DSH 的真实事件是
//   agent/inbox/spliced（用户/工具/插件消息，data.inserted[]）
//   turn/start、turn/end、permission/*、sandbox/* 等
// 同时保留 synthetic 测试类型（user/message、tool/result、assistant/message）。

import { hashHex } from './constants.mjs'
import { agentAuthoredAuthority } from './governance.mjs'
import { machineTemplateOf } from './ingest-noise.mjs'

/**
 * 可摄入的 DSH session event 类型前缀/名称（兜底白名单）。
 *
 * A1（2026-09-22）：**移除 assistant/**。模型输出不是证据——此前经 agent/inbox/spliced
 * 且 kind=assistant 的已被 7f12557 挡住，但以 assistant/message 事件形态到来的模型自述
 * 走的正是这条兜底分支，照单全收。W 机实测：7f12557 落地之后新入账的证据里仍有 85.6%
 * 是 agent 自产（169+4 条 vs 用户 27+2 条），主会话内 agent 自产占比 88.2%。
 * 账本 append-only（ADR-0001），误入的噪声删不掉 → 取 fail-closed；漏掉的真内容在会话日志里
 * 仍有原文，可由 turn/end consolidation 事后补捞（与 7f12557 同一取舍）。
 * tool/ 暂留：它对应 external_information「工具输出补充工作经验」的设计意图，是否收掉单独论证。
 */
const WORTHY_PREFIXES = ['user/', 'tool/', 'turn/', 'agent/inbox/spliced']

/**
 * agent/inbox/spliced 的**可摄入** source.kind 白名单（fail-closed）。
 *
 * 枚举取自 DSH 官方持久化目录（deepseek-harness/docs/persistence-catalog.md 的 inbox source）：
 *   user / plugin / assistant / agent-message / team-message / subagent-settled / goal
 * 其中只有 user 是真人输入，其余全部由机器生成。
 *
 * 为什么用白名单而不是补黑名单：账本 append-only（ADR-0001），误入的噪声**删不掉**；
 * 而漏掉的真内容在会话日志里仍有原文，可由 turn/end consolidation 事后补捞。
 * 因此新增 kind 应当由本文件显式放行，而不是默认放行。
 *
 * 实测依据（2026-09-21，A 机 323 份会话日志 / 162,266 事件）：
 *   入账 spliced 消息的 kind 分布 = user 1007 / subagent-settled 38 / agent-message 56 / team-message 8 / goal 23。
 */
const INSERTABLE_INBOX_KINDS = new Set(['user'])

/** 用户明确纠正的标记（事件类型或内容特征）。
 *
 *  2026-09-25 拆分强/弱两组，并加疑问句闸门 —— 修一个**子串匹配**缺陷：
 *  旧实现用 `text.includes(marker)`，于是
 *    「是不是」里含「不是」、「要不要」里含「不要」
 *  让纯提问被判成 user_correction，再经 claimDomainOf 映射进 user_preference 域。
 *  实测后果：账本 active 的 user_preference evidence 19 条里绝大多数根本不是偏好，
 *  而是"要不要精炼 ACP 里的内容？""是不是可以从上下文占比调整为费用占比"这类疑问句。
 *
 *  「错了」已整条移出：它最常出现在"报错了？""报错了，帮忙修一下"这类**报障**中；
 *  而真正的纠正几乎都会带上「改成 / 改为 / 更正」。本仓取向一贯是**宁可少判纠正**。 */
const CORRECTION_MARKERS = [
  '更正', '纠正', '不对', '不是', '改成', '改为', '不要',
  'correction', 'actually', 'instead',
]

/** 疑问句特征：整句是在提问，不是在纠正。命中则不判纠正（显式「更正：」前缀除外）。 */
const QUESTION_FORM = /(?:是不是|要不要|是否|有没有|能不能|可不可以|行不行|对不对|好不好|了吗|呢|吗)/

/** 显式自我标注的纠正前缀（"更正：…""纠正，…"）—— 疑问句不会这么写，命中即判 */
const CORRECTION_EXPLICIT = /^\s*(?:更正|纠正|correction)\s*[:：,，]?/i

/**
 * 从 agent/inbox/spliced 事件的 data.inserted[] 提取文本
 * （真实 DSH 事件：inserted = [{ content: [{type:'text',text}], source:{kind}, role, id }]）。
 * @param {object} event
 * @returns {string}
 */
/** content 块数组 → 文本（type==='text' 块拼接；与 DSH 消息 content 形状同构） */
export function blocksToText(blocks) {
  if (!Array.isArray(blocks)) return ''
  const parts = []
  for (const block of blocks) {
    if (block?.type === 'text' && typeof block.text === 'string') parts.push(block.text)
  }
  return parts.join(' ').trim()
}

/**
 * 从 agent/inbox/spliced 事件的 data.inserted[] 提取文本
 * （真实 DSH 事件：inserted = [{ content: [{type:'text',text}], source:{kind}, role, id }]）。
 * @param {object} event
 * @returns {string}
 */
export function textOfInboxMessage(event) {
  const inserted = event?.data?.inserted
  if (!Array.isArray(inserted)) return ''
  const parts = []
  for (const msg of inserted) {
    const t = blocksToText(msg?.content)
    if (t) parts.push(t)
  }
  return parts.join(' ').trim()
}

/**
 * 是否为压缩重建消息（compaction checkpoint）。
 * 官方引擎压缩后 append 一条 user/message 摘要消息，事件顶层带
 * surfaceOp={op:'replace',...} + sourceEventSeqs——这是系统重建产物，
 * 不是用户输入（用户真实消息 surfaceOp='append' 或无该字段）。
 * 原始被压内容在 append 实时流中已被摄取，跳过 checkpoint 不丢语义。
 * （2026-09-03 防御：防「已压缩 N 条」这类消息冒充 user_fact 入 ledger。）
 * @param {object} event
 * @returns {boolean}
 */
export function isCompactionCheckpoint(event) {
  const sop = event?.surfaceOp
  return !!sop && typeof sop === 'object' && sop.op === 'replace'
}

export function isEvidenceWorthy(event) {
  const type = event?.type ?? ''
  const text = extractText(event)
  if (isSystemInjected(text)) return false
  if (isCompactionCheckpoint(event)) return false // 压缩重建消息非用户输入（2026-09-03 防御）
  if (type === 'agent/inbox/spliced') {
    // E2（2026-09-07 审计 T3）：assistant 输出经 inbox 派发时 inserted[0].source.kind==='assistant'。
    // 模型输出不是"证据"——agent 自产内容全量入账曾致 5200+/6062 条（85.8%）账本噪声。
    // 经验沉淀走：用户确认 → user 消息；或 turn/end → consolidation（候选蒸馏）。
    // E2+（2026-09-21 复核 T4）：黑名单 → 白名单（fail-closed）。原条件只挡 assistant/agent/plugin，
    // 实测漏进四类机器消息（323 份会话日志实测 125 条）：
    //   subagent-settled 38（Background subagent … finished 横幅）/ agent-message 56 / team-message 8 / goal 23
    // 详见 INSERTABLE_INBOX_KINDS 注释。
    const kind = event?.data?.inserted?.[0]?.source?.kind ?? ''
    if (!INSERTABLE_INBOX_KINDS.has(kind)) return false
    return !!text
  }
  return WORTHY_PREFIXES.some((p) => type.startsWith(p)) && !!text
}

/**
 * 是否系统注入内容（system-reminder：AGENTS.md 等指令文件以 user 角色注入模型 context）。
 * 这类内容是系统/项目指令的逐轮重复注入，不是用户输入；摄入会污染 ledger 并跨 session
 * 扩散项目内部指令（2026-08-30 问题记录 F3）。
 * @param {string} text
 * @returns {boolean}
 */
export function isSystemInjected(text) {
  return typeof text === 'string' && text.includes('<system-reminder>')
}

/**
 * 会话类型派生（C，2026-09-22）。
 *
 * 依据：DSH session header 的 origin 唯一取值为 "subagent"
 * （deepseek-harness docs/persistence-catalog.md 的 session header 节；UI 侧 fork 子会话同样带
 * origin: "subagent"，见 packages/client/ui-workspace/tests/tree.client.spec.ts）。
 *
 * 修的是什么：index.mjs 原先读的是**事件**上的 sessionType——事件没有这个字段，于是账本里
 * session_type 恒为 root（W 机实测 2400/2400、subagent 零条），按会话类型做读侧隔离无从下手。
 * SESSION_TYPES 里的 fork 在这条链路上不可达（header 表达不了），保留枚举不动。
 *
 * @param {object} session - DSH session（含 header）
 * @returns {'root'|'subagent'}
 */
export function sessionTypeOf(session) {
  return session?.header?.origin === 'subagent' ? 'subagent' : 'root'
}

/**
 * 从事件提取规范化文本（content）。
 * @param {object} event
 * @returns {string}
 */
// P0-1（2026-09-03）：超长事件文本（如巨型 tool/result）入库前截断，保幂等（同一文本截断一致）
const MAX_EVENT_TEXT_CHARS = 4000

/**
 * P1-4.2（2026-09-21）：截断必须是**可见**的。
 *
 * 此前 4 处 slice 静默丢尾巴——账本里那 180 多行超长 evidence 没有任何标记，
 * 下游（consolidation 蒸馏、视图重建、人肉排查）无法区分「原文就这么长」与「被砍到 4000」。
 * 标记写进正文本身，因此 contentHash 随之变化——这正是想要的语义：
 * 「这条是不是被截过」是内容的一部分，不是元数据。
 *
 * 幂等：纯函数，同一输入恒得同一输出（extract.mjs 头部的幂等契约不受影响）。
 * 长度：结果比 4000 多约 30 字符，仍远低于写入校验上限 MAX_EVIDENCE_CONTENT_CHARS=8000。
 * 措辞与 consolidate.mjs:164 既有标记保持一致。
 * @param {string} t
 * @returns {string}
 */
function clampText(t) {
  const s = String(t ?? '')
  if (s.length <= MAX_EVENT_TEXT_CHARS) return s
  return s.slice(0, MAX_EVENT_TEXT_CHARS) + '…[truncated ' + s.length + ' chars]'
}

/**
 * 从事件提取规范化文本（content）。
 * 提取顺序：
 *   1. 事件顶层 content/text/message.content（synthetic 测试形态，content 可为字符串或块数组）
 *   2. agent/inbox/spliced → data.inserted[].content（用户/插件/协调者消息）
 *   3. P0-1：真实事件的 data.message.content[]（assistant/message、tool/result、user/message
 *      —— 真实文本全在 data 层，2026-09-03 校准；与 inbox inserted[].content 同构）
 * @param {object} event
 * @returns {string}
 */
export function extractText(event) {
  const direct = event?.content ?? event?.text ?? event?.message?.content
  if (typeof direct === 'string' && direct.trim()) return clampText(direct.trim())
  if (Array.isArray(direct)) {
    const t = blocksToText(direct)
    if (t) return clampText(t)
  }
  const inboxText = textOfInboxMessage(event)
  if (inboxText) return clampText(inboxText)
  const dm = event?.data?.message
  if (dm && Array.isArray(dm.content)) {
    const t = blocksToText(dm.content)
    if (t) return clampText(t)
  }
  return ''
}

/**
 * 从事件提取消息来源 kind（agent/inbox/spliced 取 inserted[0].source.kind；
 * 其余按事件类型前缀推断）。取不到 → ''（不可判定）。
 * @param {object} event
 * @returns {string}
 */
export function eventKindOf(event) {
  const type = event?.type ?? ''
  if (type === 'agent/inbox/spliced') {
    return event?.data?.inserted?.[0]?.source?.kind ?? ''
  }
  // 2026-09-03 防御：事件自带 source.kind 且非 'user' → 按该 kind 归类，
  // 防插件/系统以 user 角色 append 的消息冒充真实用户（如压缩 checkpoint）。
  const sourceKind = event?.data?.source?.kind ?? ''
  if (sourceKind && sourceKind !== 'user') return sourceKind
  if (type.startsWith('user/')) return 'user'
  if (type.startsWith('tool/')) return 'tool'
  if (type.startsWith('system/')) return 'system'
  if (type.startsWith('assistant/')) return 'assistant'
  return ''
}

/**
 * 从事件确定性推导 sourceClass。
 *
 * DSH harness 实际 source.kind 映射（2026-08-30 校准，见 ISSUES-INJECTION-ISOLATION.md §2.1）：
 *   user              → user_input / user_correction（真实用户；子代理 prompt 派发也走
 *                       kind='user'，由调用方用 opts.subagent 在候选层降权，见 toEvidenceCandidate）
 *   tool              → external_tool
 *   plugin / agent    → agent_authored
 *   coordinator       → agent_authored（send_message 续派，tool-subagent-control）
 *   subagent-settled  → agent_authored（子代理完成通知，subagent/continuation）
 *   未知 kind         → agent_authored（保守：宁可不冒充用户，也不 fallback 到 user_input）
 * @param {object} event
 * @returns {'system'|'user_input'|'user_correction'|'external_tool'|'agent_authored'}
 */
export function sourceClassOf(event) {
  const kind = eventKindOf(event)
  if (kind === 'user') return isCorrection(event) ? 'user_correction' : 'user_input'
  if (kind === 'tool') return 'external_tool'
  if (kind === 'plugin' || kind === 'agent'
    || kind === 'coordinator' || kind === 'subagent-settled') return 'agent_authored'
  const type = event?.type ?? ''
  if (type.startsWith('system/')) return 'system'
  return 'agent_authored'
}

/**
 * 任务书特征前缀：父 agent 派发给子代理的完整任务书（含"不要改 X"等措辞，
 * 会被纠正标记词误判为 user_correction——2026-08-30 问题记录 F2）。
 * 保守判定：前缀命中且文本足够长（≥30 字符）才视为任务书；短句不受影响。
 */
const TASK_BRIEF_PREFIXES = ['你是', 'You are', '任务：', '项目：']
const TASK_BRIEF_MIN_LEN = 30

/**
 * 是否判定为明确纠正。
 * 规则：仅 user 来源消息 + 包含纠正标记词 → user_correction。
 * 排除：非 user 来源（tool/coordinator/subagent-settled/plugin/agent 永不判纠正）；
 *       任务书特征文本（父 agent 派发指令，非用户反馈）。
 * （保守：宁可少判纠正，也不把普通陈述/任务书当纠正。）
 * @param {object} event
 * @returns {boolean}
 */
export function isCorrection(event) {
  const text = extractText(event)
  if (!text) return false
  // 仅 user 来源可判纠正
  if (eventKindOf(event) !== 'user') return false
  // 任务书负向排除（前缀 + 长度；短句不误伤）
  if (text.length >= TASK_BRIEF_MIN_LEN) {
    for (const p of TASK_BRIEF_PREFIXES) {
      if (text.startsWith(p)) return false
    }
  }
  // 显式自我标注的纠正：疑问句不会这么写，命中即判。
  if (CORRECTION_EXPLICIT.test(text)) return true
  // 疑问句闸门（2026-09-25）：整句在问 → 不判纠正。
  // 这一条挡住的是「是不是…」「要不要…」这类被**子串**误触的提问，
  // 以及"报错了？"这类带问号的报障句。
  if (QUESTION_FORM.test(text) || /[?？]\s*$/.test(text)) return false
  // 至少 2 个汉字 + 含标记词；单字"不/对"太宽松
  return CORRECTION_MARKERS.some((m) => text.includes(m)) && text.length >= 2
}

/**
 * 从事件确定性推导 authority（通过 sourceClass）。
 * @param {object} event
 * @returns {string} authority（7 值之一）
 */
export function authorityOf(event) {
  const sc = sourceClassOf(event)
  if (sc === 'agent_authored') {
    // 子规则：tool 内部自评？这里 MVP 简化为单次观察；
    // agent 自评/推断由上层显式传入 kind 覆盖。
    return agentAuthoredAuthority('observation')
  }
  switch (sc) {
    case 'system': return 'system_policy'
    case 'user_input': return 'user_explicit'
    case 'user_correction': return 'user_correction'
    case 'external_tool': return 'external_information'
    default: return 'single_observation'
  }
}

/**
 * 从事件确定性推导 claimDomain。
 * @param {object} event
 * @returns {string} claimDomain（6 值之一）
 */
export function claimDomainOf(event) {
  const sc = sourceClassOf(event)
  if (sc === 'user_correction') return 'user_preference'
  if (sc === 'external_tool') return 'external_fact'
  if (sc === 'user_input') return 'user_fact'
  if (sc === 'system') return 'external_fact'
  return 'experience'
}

/**
 * 事件 → Evidence 写入候选（完整规范化）。
 * @param {object} event - DSH session event
 * @param {object} [opts]
 * @param {string} [opts.scopeId]
 * @param {string} [opts.sessionId] - session id（真实事件用 sessionId:seq 作 sourceRef）
 * @param {string} [opts.agentKey]
 * @param {string} [opts.sessionType]
 * @param {boolean} [opts.subagent] - 子代理会话降权（session.header.origin==='subagent'）：
 *   kind='user' 的消息无法与真实用户区分（父 agent 派发 prompt 也走 kind='user'），
 *   统一降权为 agent_authored/agent_inference/experience——记录但 quarantine
 *   （agent_inference 在 readGuard 全 ✗，不进任何会话注入），
 *   避免父任务书冒充用户指令（2026-08-30 问题记录 F4，决策 D2-A）。
 * @returns {object|null} Evidence candidate 或 null（不可摄入时）
 */
export function toEvidenceCandidate(event, opts = {}) {
  if (!isEvidenceWorthy(event)) return null
  const text = extractText(event)
  // 机器模板不摄入（2026-09-24）：源头拦截。判据固定在 src/ingest-noise.mjs，
  // 只做前缀 / 整行锚定匹配 —— 子串会误伤「引用模板串的分析文」。
  if (machineTemplateOf(text)) return null
  const sc = sourceClassOf(event)
  // sourceRef：真实 DSH 事件有 seq（session 内唯一）无 id；synthetic 测试事件有 id
  const eventRef = opts.sessionId && event.seq != null
    ? opts.sessionId + ':' + event.seq
    : (event.id ?? event.sessionEventId ?? String(event.seq ?? ''))
  const cand = {
    sourceClass: sc,
    authority: authorityOf(event),
    claimDomain: claimDomainOf(event),
    confidence: sc === 'user_correction' ? 1 : sc === 'user_input' ? 0.9 : 0.5,
    durability: sc === 'user_correction' ? 0.9 : 0.5,
    sensitivity: 'private',
    content: text,
    contentHash: hashHex(text),
    sourceRef: { sessionEventId: eventRef },
    scopeId: opts.scopeId ?? 'user-global',
    agentKey: opts.agentKey ?? '',
    sessionType: opts.sessionType ?? 'root',
    observedAt: new Date().toISOString(),
  }
  // 子代理会话降权：user 消息（含父 prompt）→ agent_inference（记录但 quarantine）
  if (opts.subagent && (sc === 'user_input' || sc === 'user_correction')) {
    cand.sourceClass = 'agent_authored'
    cand.authority = 'agent_inference'
    cand.claimDomain = 'experience'
    cand.confidence = 0.5
    cand.durability = 0.5
  }
  return cand
}