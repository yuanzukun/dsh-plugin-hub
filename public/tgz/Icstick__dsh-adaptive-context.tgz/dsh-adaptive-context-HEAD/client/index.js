// client/index.js — dsh-adaptive-context 设置页（bundle-ready CJS 风格源码）。
//
// 构建：node scripts/build-client.mjs → lib/client.js（window.__ModuleLoader__.load 闭包）。
// dsh.client.inject 声明包关系；Cordis 服务依赖由下方 exports.inject 声明并控制激活。
// react 由平台预加载，ui-slots 提供 ctx.slots，ui-settings 提供 ctx.settingsScope。
// 自包含：字段渲染 + staged 草稿 + 保存自实现。
// 注册为设置面板顶层 section（settings.section「自适应上下文」，与费用/Vision Router 同层）。
// 文案写死中文（v1 不做 i18n）。

// React 无顶层 h（那是 preact 的 API）——createElement 起别名 h 供组件使用
const { createElement: h, useState, useSyncExternalStore } = require('react')

/** 设置页 namespace（与 host 侧 SETTINGS_NAMESPACE 一致） */
const NS = 'adaptive-context'
/** 0.1.7：configForms / describe 用的 profile entry id（cordis.patch.yml 的 id） */
const ENTRY_ID = 'adaptive-context'
/** 0.1.7：「插件」页的 slot key —— 必须是 bundle 包名 */
const BUNDLE_KEY = 'dsh-adaptive-context'

/** 顶层 section 标题/描述 */
const TITLE = '自适应上下文（ACP）'
const DESC = '证据账本 · 上下文注入 · 会话隔离'

/** 空值语义提示（2026-09-17）：本页是覆盖层，留空不代表没配置 */
const EMPTY_HINT = '未填写的项由插件采用设计默认；填写后覆盖配置文件，重启生效。'

/**
 * 字段定义（顺序即渲染顺序）。
 * type: text | number | select | toggle
 * options: select 的可选项
 */
const FIELDS = [
  { name: 'ledgerDir', label: '数据目录', hint: '证据账本 SQLite 所在目录（重启生效）', type: 'text' },
  { name: 'hotTokens', label: '热路径注入预算', hint: '每轮注入 token 上限（默认 900）', type: 'number' },
  { name: 'observationInjection', label: 'observation 注入', hint: '蒸馏观察轨注入开关（默认关=冻结；开闸范围见权威白名单）', type: 'toggle' },
  { name: 'observationAuthorities', label: '观察注入权威白名单', hint: '逗号分隔，如 user_explicit,user_correction（T2 闸门）', type: 'list' },
  { name: 'recallLimit', label: '召回上限', hint: '每个记忆源的候选上限', type: 'number' },
  {
    name: 'targetDomain', label: '目标领域（已弃用）', hint: '不再影响注入，保留仅为兼容存量配置', type: 'select',
    options: ['work', 'user_fact', 'user_preference', 'experience', 'style', 'external_fact'],
  },
  {
    name: 'crossSessionPolicy', label: '跨会话注入策略', type: 'select',
    hint: 'non-instructional=跨会话只注入非指令性内容；all=全类别+降权；none=不注入跨会话',
    options: ['non-instructional', 'all', 'none'],
  },
  { name: 'subagentDowngrade', label: '子代理会话降权', hint: '父 agent 派发的 prompt 不冒充用户指令', type: 'toggle' },
  { name: 'consolidationProvider', label: '沉淀模型服务商', type: 'text' },
  { name: 'consolidationModel', label: '沉淀模型', type: 'text' },
  { name: 'autoPromote', label: '自动提升', hint: '风格候选策略达标后自动晋升', type: 'toggle' },
  { name: 'debug', label: '调试日志', type: 'toggle' },
]

/** 字段值 → 草稿文本（渲染初始值） */
function draftOf(value) {
  if (value === true) return 'true'
  if (value === false) return 'false'
  if (value === null || value === undefined) return ''
  return String(value)
}

/** 草稿文本 → 写入值；空 → null（表示 unset） */
function parseDraft(field, text) {
  const trimmed = String(text ?? '').trim()
  if (field.type === 'number') {
    if (trimmed === '') return null
    const n = Number(trimmed)
    return Number.isFinite(n) ? n : undefined // undefined = 非法，阻止保存
  }
  if (field.type === 'list') {
    return trimmed === '' ? null : trimmed.split(',').map((s) => s.trim()).filter(Boolean)
  }
  if (field.type === 'toggle') return trimmed === 'true'
  if (trimmed === '') return null
  return trimmed
}

const rowStyle = {
  display: 'flex', flexDirection: 'column', gap: '4px',
  padding: '10px 0', borderBottom: '1px solid var(--dsw-alias-border-l2, #e5e7eb)',
}
const labelStyle = { fontSize: '13px', color: 'var(--dsw-alias-label-primary, #1f2937)' }
const hintStyle = { fontSize: '12px', color: 'var(--dsw-alias-label-secondary, #6b7280)' }
const inputStyle = {
  fontSize: '13px', padding: '4px 8px', borderRadius: '6px',
  border: '1px solid var(--dsw-alias-border-l2, #d1d5db)',
  background: 'var(--dsw-alias-bg-module-platform)', color: 'var(--dsw-alias-label-primary, #111827)',
}
const badgeStyle = {
  fontSize: '11px', color: '#b45309', background: '#fef3c7',
  borderRadius: '999px', padding: '1px 8px', marginLeft: '8px',
}
const resetBtnStyle = {
  fontSize: '12px', color: '#b45309', background: 'none', border: 'none',
  cursor: 'pointer', textDecoration: 'underline', padding: 0,
}

/**
 * 单字段控件：label + hint + 覆盖徽标 + 输入控件 + 重置。
 * @param {object} p - { field, value, draft, overridden, disabled, onDraft, onReset }
 */
function FieldControl(p) {
  const { field, value, draft, overridden, disabled, onDraft, onReset } = p
  const text = draft !== undefined ? draft : draftOf(value)
  const common = {
    id: 'acp-field-' + field.name,
    disabled,
    style: inputStyle,
    value: field.type === 'toggle' ? (text === 'true') : text,
  }
  let control
  if (field.type === 'toggle') {
    control = h('input', {
      ...common,
      type: 'checkbox',
      checked: text === 'true',
      onChange: (e) => onDraft(String(e.target.checked)),
    })
  } else if (field.type === 'select') {
    control = h('select', {
      ...common,
      onChange: (e) => onDraft(e.target.value),
    }, (field.options ?? []).map((opt) =>
      h('option', { key: opt, value: opt }, opt)))
  } else {
    control = h('input', {
      ...common,
      type: field.type === 'number' ? 'number' : 'text',
      onChange: (e) => onDraft(e.target.value),
    })
  }
  return h('div', { style: rowStyle },
    h('div', { style: { display: 'flex', alignItems: 'center', gap: '4px' } },
      h('label', { htmlFor: common.id, style: labelStyle }, field.label),
      overridden ? h('span', { style: badgeStyle }, '已覆盖') : null),
    h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, control,
      overridden ? h('button', { type: 'button', style: resetBtnStyle, disabled, onClick: onReset }, '重置') : null),
    field.hint ? h('div', { style: hintStyle }, field.hint) : null)
}

/**
 * 设置 section 面板组件（自包含：闭包捕获 bound scope）。
 * @param {object} scope - ctx.settingsScope.bind({namespace}) 结果
 */
function makeSection(scope) {
  return function Section() {
    const snapshot = useSyncExternalStore(
      (cb) => scope.subscribe(cb),
      () => scope.getSnapshot(),
    )
    const value = snapshot?.value && typeof snapshot.value === 'object' ? snapshot.value : {}
    const userLayer = snapshot?.user && typeof snapshot.user === 'object' ? snapshot.user : {}
    const writable = snapshot?.writable === true
    const [drafts, setDrafts] = useState(null) // null=无编辑；{name: text}
    const [saving, setSaving] = useState(false)
    const [failed, setFailed] = useState(false)

    const dirty = drafts !== null
    const invalid = dirty && FIELDS.some((f) =>
      drafts[f.name] !== undefined && parseDraft(f, drafts[f.name]) === undefined)

    async function save() {
      if (!dirty || invalid || saving) return
      setSaving(true); setFailed(false)
      try {
        const writes = []
        for (const field of FIELDS) {
          if (!(field.name in drafts)) continue
          const parsed = parseDraft(field, drafts[field.name])
          if (parsed === undefined) continue
          // 0.1.6 的 settingsScope 有 unset；0.1.7 的 configForms form 只有 set（写 undefined 即回继承值）
          if (parsed === null) {
            if (typeof scope.unset === 'function') writes.push(scope.unset(field.name))
            else writes.push(scope.set(field.name, undefined))
          } else writes.push(scope.set(field.name, parsed))
        }
        await Promise.all(writes)
        setDrafts(null)
      } catch {
        setFailed(true)
      } finally {
        setSaving(false)
      }
    }

    function discard() { setDrafts(null); setFailed(false) }
    function onDraft(name, text) {
      setFailed(false)
      setDrafts((prev) => {
        const next = { ...prev }
        next[name] = text
        return next
      })
    }
    function onReset(name) {
      setFailed(false)
      setDrafts((prev) => {
        const next = { ...prev }
        next[name] = '' // 空草稿 = unset
        return next
      })
    }

    return h('div', { style: { display: 'flex', flexDirection: 'column', gap: '2px' } },
      h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '10px', padding: '2px 2px 10px', borderBottom: '1px solid var(--dsw-alias-border-l2, #e5e7eb)' } },
        h('span', { style: { fontWeight: 600, fontSize: '15px', color: 'var(--dsw-alias-label-primary, #111827)' } }, TITLE),
        h('span', { style: { fontSize: '12px', color: 'var(--dsw-alias-label-secondary, #6b7280)' } }, DESC),
        dirty ? h('span', { style: badgeStyle }, '未保存') : null),
      h('p', { style: { ...hintStyle, padding: '0 2px 8px' } }, EMPTY_HINT),
      h('div', { style: { padding: '2px 2px 8px' } },
        !writable ? h('p', { role: 'status', style: hintStyle }, '当前文档不可写（只读模式）') : null,
        FIELDS.map((field) => h(FieldControl, {
          key: field.name,
          field,
          value: value[field.name],
          draft: drafts ? drafts[field.name] : undefined,
          overridden: userLayer[field.name] !== undefined,
          disabled: !writable || saving,
          onDraft: (text) => onDraft(field.name, text),
          onReset: () => onReset(field.name),
        })),
        h('div', { style: { display: 'flex', gap: '8px', justifyContent: 'flex-end', paddingTop: '12px' } },
          failed ? h('p', { role: 'status', style: { ...hintStyle, color: '#b91c1c', marginRight: 'auto', alignSelf: 'center' } }, '保存失败，请重试') : null,
          h('button', {
            type: 'button', disabled: !dirty || saving,
            style: { ...inputStyle, background: 'none', color: '#6b7280', cursor: 'pointer' },
            onClick: discard,
          }, '放弃'),
          h('button', {
            type: 'button', disabled: !dirty || invalid || saving,
            style: {
              ...inputStyle, cursor: 'pointer', fontWeight: 600,
              background: 'var(--dsw-alias-accent, #2563eb)', color: '#fff', borderColor: 'transparent',
            },
            onClick: save,
          }, saving ? '保存中…' : '保存')))
    )
  }
}

/**
 * client 插件入口：注册为设置面板顶层 section。
 *
 * 双版本兼容（2026-09-23）：
 *   dsh ≤0.1.6 —— ui-settings 提供 ctx.settingsScope，卡片照旧渲染、读写 settings.yaml；
 *   dsh ≥0.1.7 —— settingsScope 已删除（设置表单改由平台按 host 侧 Config 的 volatile 字段生成）。
 *     静态 `exports.inject` 列 'settingsScope' 会让本条目在 0.1.7 上一直 pending
 *     （顶栏 "Failed to load plugins … waiting for service: settingsScope"），
 *     故改为命令式 ctx.inject(['settingsScope'], …)：服务不存在时回调不触发，
 *     条目照常激活，0.1.7 上不注册自绘卡片。全程 fail-open，绝不抛出。
 */
function apply(ctx) {
  // ---- 0.1.7：侧栏「插件」页的 bundle 配置卡 ----
  // 宿主按 host 侧 Config 的 .volatile() 字段投影出 form；slot key 必须是 bundle 包名。
  // 命令式注入：0.1.6 没有 configForms → 回调不触发，条目照常激活（fail-open）。
  try {
    ctx.inject(['configForms'], (formsCtx) => {
      try {
        const forms = formsCtx.configForms
        if (!forms || typeof forms.whileServed !== 'function' || typeof forms.get !== 'function') return
        const form = forms.get(ENTRY_ID)
        if (!form || typeof form.subscribe !== 'function' || typeof form.getSnapshot !== 'function') return
        formsCtx.effect(() => forms.whileServed([ENTRY_ID], () => formsCtx.slots.inject('plugins.bundle.config', () => formsCtx.slots.register(
          { name: 'plugins.bundle.config', key: BUNDLE_KEY },
          makeSection(form),
        ))), 'adaptive-context: bundle settings page')
      } catch { /* fail-open：插件页卡片注册失败不影响条目激活 */ }
    })
  } catch { /* fail-open：configForms 命令式注入本身失败也不外抛 */ }

  // ---- 0.1.6 兼容：设置面板顶层 section（0.1.7 无 settingsScope，回调不触发）----
  try {
    ctx.inject(['settingsScope'], (scopeCtx) => {
      try {
        const scope = scopeCtx.settingsScope.bind({ namespace: NS })
        if (!scope || typeof scope.getSnapshot !== 'function') return
        scopeCtx.slots.inject('settings.section', () => scopeCtx.slots.register(
          { name: 'settings.section', id: 'adaptive-context', order: 165, label: '自适应上下文' },
          makeSection(scope),
        ))
      } catch { /* fail-open：卡片注册失败不影响条目激活 */ }
    })
  } catch { /* fail-open：注入声明本身失败也不外抛 */ }
}

// 'settingsScope' 不在静态 inject 里 —— 它在 0.1.7 不存在，列上会 gate 掉整个条目。
exports.inject = ['slots']
// build.mjs 模板注入 exports.apply
exports.apply = apply