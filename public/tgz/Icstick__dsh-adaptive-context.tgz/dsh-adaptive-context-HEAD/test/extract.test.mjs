// test/extract.test.mjs — extract 规范化测试
import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  isEvidenceWorthy, extractText, sourceClassOf, authorityOf,
  claimDomainOf, isCorrection, toEvidenceCandidate, isSystemInjected,
  isCompactionCheckpoint, sessionTypeOf,
} from '../src/extract.mjs'
import { evidenceIdOf } from '../src/constants.mjs'

test('user 普通消息 → user_input / user_explicit / user_fact', () => {
  const ev = { type: 'user/message', id: 'e1', content: '我们这个项目用 pnpm' }
  assert.equal(isEvidenceWorthy(ev), true)
  assert.equal(sourceClassOf(ev), 'user_input')
  assert.equal(claimDomainOf(ev), 'user_fact')
})

test('user 纠正消息 → user_correction / user_correction / user_preference', () => {
  const ev = { type: 'user/message', id: 'e2', content: '更正：这个项目之后统一用 Bun' }
  assert.equal(isCorrection(ev), true)
  assert.equal(sourceClassOf(ev), 'user_correction')
  assert.equal(authorityOf(ev), 'user_correction')
  assert.equal(claimDomainOf(ev), 'user_preference')
})

test('tool 结果 → external_tool / external_information / external_fact', () => {
  const ev = { type: 'tool/result', id: 'e3', content: 'package.json 显示 packageManager: pnpm@10' }
  assert.equal(sourceClassOf(ev), 'external_tool')
  assert.equal(authorityOf(ev), 'external_information')
  assert.equal(claimDomainOf(ev), 'external_fact')
})

test('空内容不摄入', () => {
  assert.equal(isEvidenceWorthy({ type: 'user/message', id: 'e4', content: '' }), false)
  assert.equal(isEvidenceWorthy({ type: 'unknown/x', id: 'e5', content: 'hi' }), false)
})

test('toEvidenceCandidate 幂等：同事件两次同 id', () => {
  const ev = { type: 'user/message', id: 'e6', content: '默认用 pnpm' }
  const a = toEvidenceCandidate(ev)
  const b = toEvidenceCandidate(ev)
  assert.equal(a.contentHash, b.contentHash)
  assert.deepEqual(a.sourceRef, b.sourceRef)
  // 写入 store 后同 id（靠 evidenceIdOf 派生）
  assert.equal(evidenceIdOf({ sourceRef: a.sourceRef, contentHash: a.contentHash }),
               evidenceIdOf({ sourceRef: b.sourceRef, contentHash: b.contentHash }))
})

test('agent 消息 → agent_authored / single_observation / experience', () => {
  // 注：本用例只校验归类映射。assistant/message 自 A1（2026-09-22）起**不再摄入**，
  // 见下面的 isEvidenceWorthy 用例；映射函数本身保持可用（其它路径仍需要它）。
  const ev = { type: 'assistant/message', id: 'e7', content: '我检查了配置文件' }
  assert.equal(sourceClassOf(ev), 'agent_authored')
  assert.equal(authorityOf(ev), 'single_observation')
  assert.equal(claimDomainOf(ev), 'experience')
})

// ---------------------------------------------------------------
// A1（2026-09-22）：assistant 模型输出不再摄入。
// 账本 append-only，误入的噪声删不掉 → fail-closed（与 7f12557 同一取舍）。
// tool/ 暂留（external_information 设计意图），此处一并钉住免得被顺手改掉。
// ---------------------------------------------------------------
test('A1：assistant/message 不摄入；user/tool/turn 仍摄入', () => {
  assert.equal(isEvidenceWorthy({ type: 'assistant/message', id: 'a1', content: '我检查了配置文件' }), false)
  assert.equal(isEvidenceWorthy({ type: 'user/message', id: 'a2', content: '用 pnpm' }), true)
  assert.equal(isEvidenceWorthy({ type: 'tool/result', id: 'a3', content: 'exit 0' }), true)
  assert.equal(isEvidenceWorthy({ type: 'turn/end', id: 'a4', content: 'x' }), true)
})

test('A1：toEvidenceCandidate 对 assistant/message 返回 null', () => {
  assert.equal(toEvidenceCandidate({ type: 'assistant/message', id: 'a5', content: '过程叙述' }, { sessionId: 's1' }), null)
})

// ---------------------------------------------------------------
// C（2026-09-22）：会话类型从 session.header.origin 派生。
// 修之前 index.mjs 读事件上的 sessionType（不存在）→ 账本 session_type 恒为 root。
// ---------------------------------------------------------------
test('C：sessionTypeOf 从 header.origin 派生 root/subagent', () => {
  assert.equal(sessionTypeOf({ header: { origin: 'subagent' } }), 'subagent')
  assert.equal(sessionTypeOf({ header: {} }), 'root')
  assert.equal(sessionTypeOf({}), 'root')
  assert.equal(sessionTypeOf(undefined), 'root')
  // 事件上的 sessionType 不再参与判定（旧实现读的就是这个，永远是 undefined）
  assert.equal(sessionTypeOf({ header: {}, sessionType: 'subagent' }), 'root')
})

test('真实 DSH 事件：agent/inbox/spliced 用户消息 → user_input', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 4,
    time: 1787669403035,
    data: {
      target: 'next-turn',
      inserted: [{ content: [{ type: 'text', text: '这个项目用 pnpm' }], source: { kind: 'user', rpcId: 'r1' }, role: 'user', id: 'msg-1' }],
    },
  }
  assert.equal(isEvidenceWorthy(ev), true)
  assert.equal(extractText(ev), '这个项目用 pnpm')
  assert.equal(sourceClassOf(ev), 'user_input')
  assert.equal(authorityOf(ev), 'user_explicit')
  const cand = toEvidenceCandidate(ev, { sessionId: 'session-a' })
  assert.deepEqual(cand.sourceRef, { sessionEventId: 'session-a:4' })
  // 幂等：同一事件两次同 sourceRef
  const cand2 = toEvidenceCandidate(ev, { sessionId: 'session-a' })
  assert.deepEqual(cand.sourceRef, cand2.sourceRef)
  assert.equal(cand.contentHash, cand2.contentHash)
})

test('真实 DSH 事件：agent/inbox/spliced 工具结果 → external_tool', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 9,
    data: {
      inserted: [{ content: [{ type: 'text', text: 'package.json 显示 packageManager: pnpm' }], source: { kind: 'tool' }, role: 'user', id: 'msg-2' }],
    },
  }
  assert.equal(sourceClassOf(ev), 'external_tool')
  assert.equal(authorityOf(ev), 'external_information')
  assert.equal(claimDomainOf(ev), 'external_fact')
})

test('真实 DSH 事件：turn/start 无文本不摄入', () => {
  const ev = { type: 'turn/start', seq: 5, data: { turn: 1 } }
  assert.equal(isEvidenceWorthy(ev), false)
})
test('send_message 续派（coordinator relay）→ agent_authored（不再 fallback user_input）', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 11,
    data: {
      inserted: [{
        content: [{ type: 'text', text: '继续完成剩余的部分，不要改动已有代码' }],
        source: { kind: 'coordinator', form: 'relay', senderSessionId: 'parent-1' },
        role: 'user', id: 'msg-3',
      }],
    },
  }
  assert.equal(sourceClassOf(ev), 'agent_authored')
  assert.equal(authorityOf(ev), 'single_observation')
  assert.equal(claimDomainOf(ev), 'experience')
  assert.equal(isCorrection(ev), false) // 非 user 来源永不判纠正
})

test('子代理完成通知（subagent-settled）→ agent_authored', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 12,
    data: {
      inserted: [{
        content: [{ type: 'text', text: 'Background subagent child-1 finished and will do no further work unless you send it more.' }],
        source: { kind: 'subagent-settled', form: 'notice', senderSessionId: 'child-1' },
        role: 'user', id: 'msg-4',
      }],
    },
  }
  assert.equal(sourceClassOf(ev), 'agent_authored')
  assert.equal(isCorrection(ev), false)
})

test('未知 source.kind → agent_authored（保守，不再冒充 user_input）', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 13,
    data: {
      inserted: [{ content: [{ type: 'text', text: '来自未知来源的消息' }], source: { kind: 'mystery-kind' }, role: 'user', id: 'msg-5' }],
    },
  }
  assert.equal(sourceClassOf(ev), 'agent_authored')
  assert.equal(authorityOf(ev), 'single_observation')
  assert.equal(claimDomainOf(ev), 'experience')
})

test('子代理任务书（含纠正词）不判 correction → user_input', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 14,
    data: {
      inserted: [{
        content: [{ type: 'text', text: '你是 dsh-desktop-shell 项目的 M4-C 子代理 C1。任务：实现 crates/browser-provider（纯逻辑 crate）。不要改动其他 crate 的接口。' }],
        source: { kind: 'user' }, role: 'user', id: 'msg-6',
      }],
    },
  }
  assert.equal(isCorrection(ev), false) // 任务书特征负向排除
  assert.equal(sourceClassOf(ev), 'user_input')
  assert.equal(authorityOf(ev), 'user_explicit')
  assert.equal(claimDomainOf(ev), 'user_fact')
})

test('短纠正句不受任务书排除影响（"你是对的，不要用那个方案"）', () => {
  const ev = { type: 'user/message', id: 'e8', content: '你是对的，不要用那个方案' }
  assert.equal(isCorrection(ev), true)
  assert.equal(sourceClassOf(ev), 'user_correction')
})

test('tool 结果含纠正词不判 correction', () => {
  const ev = { type: 'tool/result', id: 'e9', content: 'lint 输出：不要使用 console.log，改用 logger' }
  assert.equal(isCorrection(ev), false)
  assert.equal(sourceClassOf(ev), 'external_tool')
})

// ===================== 2026-09-25：疑问句被子串误判为纠正 =====================
// 实测背景：账本 active 的 user_preference evidence 19 条里，绝大多数是下面这类
// **疑问句**。根因是 CORRECTION_MARKERS 用 includes 做子串匹配 ——
//   「是不是」里含「不是」、「要不要」里含「不要」，于是"要不要精炼 ACP 里的内容？"
//   被判成 user_correction，再按 claimDomainOf 映射进 user_preference 域。
// 修复方向是**提高精度**（本仓既有取向：宁可少判纠正，也不误判）。

test('疑问句「是不是…？」不判 correction → user_input / user_fact', () => {
  const ev = { type: 'user/message', id: 'q1', content: '那我们这里是不是可以从上下文占比调整为费用占比' }
  assert.equal(isCorrection(ev), false)
  assert.equal(sourceClassOf(ev), 'user_input')
  assert.equal(authorityOf(ev), 'user_explicit')
  assert.equal(claimDomainOf(ev), 'user_fact')
})

test('疑问句「要不要…呢？」不判 correction', () => {
  const ev = { type: 'user/message', id: 'q2', content: '好呢好呢，要不要在设置页增加插件配置呢？' }
  assert.equal(isCorrection(ev), false)
  assert.equal(claimDomainOf(ev), 'user_fact')
})

test('「要不要精炼 ACP 里的内容？」不判 correction', () => {
  const ev = { type: 'user/message', id: 'q3', content: '要不要精炼ACP里的内容？' }
  assert.equal(isCorrection(ev), false)
})

test('报障句「报错了？」不判 correction（「错了」已移出标记词）', () => {
  const ev = { type: 'user/message', id: 'q4', content: '报错了？' }
  assert.equal(isCorrection(ev), false)
})

test('报障句「刚刚有个会话报错了，帮忙修一下呜呜」不判 correction', () => {
  const ev = { type: 'user/message', id: 'q5', content: '刚刚有个会话报错了，帮忙修一下呜呜' }
  assert.equal(isCorrection(ev), false)
  assert.equal(claimDomainOf(ev), 'user_fact')
})

test('「…是不是我们的 acp 和仓库不同步呢？」不判 correction', () => {
  const ev = { type: 'user/message', id: 'q6', content: '我总觉得之前在澪姐那里这些都有处理过，是不是我们的acp和仓库不同步呢？' }
  assert.equal(isCorrection(ev), false)
})

test('真纠正句不受影响：「不对，应该用 Bun」→ 仍判 correction', () => {
  const ev = { type: 'user/message', id: 'q7', content: '不对，应该用 Bun' }
  assert.equal(isCorrection(ev), true)
  assert.equal(sourceClassOf(ev), 'user_correction')
})

test('真纠正句不受影响：「不要用 npm」→ 仍判 correction', () => {
  const ev = { type: 'user/message', id: 'q8', content: '不要用 npm' }
  assert.equal(isCorrection(ev), true)
})

test('system-reminder 内容不摄入', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 15,
    data: {
      inserted: [{
        content: [{ type: 'text', text: '<system-reminder> Additional instructions from: AGENTS.md  T...' }],
        source: { kind: 'user' }, role: 'user', id: 'msg-7',
      }],
    },
  }
  assert.equal(isEvidenceWorthy(ev), false)
  assert.equal(isSystemInjected('<system-reminder> x'), true)
  assert.equal(isSystemInjected('普通用户消息'), false)
})

test('子代理会话降权：kind=user 消息 → agent_authored / agent_inference / experience（quarantine）', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 16,
    data: {
      inserted: [{ content: [{ type: 'text', text: '你是子代理。任务：实现 feature X。不要改其他部分。' }], source: { kind: 'user' }, role: 'user', id: 'msg-8' }],
    },
  }
  const cand = toEvidenceCandidate(ev, { sessionId: 'child-session', subagent: true })
  assert.equal(cand.sourceClass, 'agent_authored')
  assert.equal(cand.authority, 'agent_inference')
  assert.equal(cand.claimDomain, 'experience')
  assert.equal(cand.confidence, 0.5)
  assert.equal(cand.durability, 0.5)
  // sourceRef 仍保留原会话与 seq（审计可回溯）
  assert.deepEqual(cand.sourceRef, { sessionEventId: 'child-session:16' })
})

test('非子代理会话不降权（opts.subagent 缺省）', () => {
  const ev = { type: 'user/message', id: 'e10', content: '这个项目用 pnpm' }
  const cand = toEvidenceCandidate(ev, { sessionId: 'root-session' })
  assert.equal(cand.sourceClass, 'user_input')
  assert.equal(cand.authority, 'user_explicit')
  assert.equal(cand.claimDomain, 'user_fact')
})

test('compaction checkpoint（user/message + surfaceOp replace）→ 不摄入', () => {
  // 官方引擎压缩后重建的 checkpoint 消息（surfaceOp replace 顶层特征）
  const checkpoint = {
    type: 'user/message',
    seq: 500,
    content: '已压缩 761 条历史记录（约 372810 tokens）',
    surfaceOp: { op: 'replace', start: 10, end: 480 },
    sourceEventSeqs: [499, 500, 1, 2, 3],
  }
  assert.equal(isCompactionCheckpoint(checkpoint), true)
  assert.equal(isEvidenceWorthy(checkpoint), false, '压缩重建消息不摄入——原始被压内容已实时摄入')
  // 对照：真实用户消息 surfaceOp='append' 或缺失 → 正常摄入
  assert.equal(isEvidenceWorthy({ type: 'user/message', content: '我们用 pnpm' }), true)
  assert.equal(isEvidenceWorthy({ type: 'user/message', content: '继续', surfaceOp: 'append' }), true)
})

test('eventKindOf：事件自带 source.kind（非 user）不冒充 user_input', () => {
  // 插件以 user 角色 append 但显式标注 source.kind='plugin' → agent_authored
  const pluginMsg = {
    type: 'user/message',
    data: { source: { kind: 'plugin', plugin: 'some-plugin' } },
    content: '插件注入的说明文本',
  }
  assert.equal(sourceClassOf(pluginMsg), 'agent_authored')
  assert.equal(claimDomainOf(pluginMsg), 'experience')
  // source.kind='user' 显式标注 → 仍判 user
  const userMsg = { type: 'user/message', data: { source: { kind: 'user' } }, content: '真实用户消息' }
  assert.equal(sourceClassOf(userMsg), 'user_input')
})

// E2（2026-09-07 审计 T3）：assistant 输出经 inbox spliced 派发不摄入——agent 自产内容
// 全量入账曾致 85.8% 账本噪声（5200+/6062）。经验沉淀走用户确认或 turn/end consolidation。
test('E2：agent/inbox/spliced + kind=assistant → 不摄入（isEvidenceWorthy false）', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 999,
    data: {
      inserted: [{
        id: 'm1',
        role: 'assistant',
        source: { kind: 'assistant' },
        content: [{ type: 'text', text: '我完成了任务，结论是 X' }],
      }],
    },
  }
  assert.equal(isEvidenceWorthy(ev), false, 'assistant 输出不应作为证据摄入')
})

test('E2：agent/inbox/spliced + kind=user → 仍摄入（用户消息不受影响）', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 1000,
    data: {
      inserted: [{
        id: 'm2',
        role: 'user',
        source: { kind: 'user' },
        content: [{ type: 'text', text: '记住：之后统一用 pnpm' }],
      }],
    },
  }
  assert.equal(isEvidenceWorthy(ev), true, '用户消息应照常摄入')
  assert.equal(sourceClassOf(ev), 'user_input') // '记住：' 非纠正标记词（显式前缀收紧后）
})

// E2+（2026-09-21 复核 T4）：黑名单 → 白名单（fail-closed）。
// DSH 官方 inbox source 枚举（deepseek-harness/docs/persistence-catalog.md）里，
// 除 user 以外全部是机器消息。A 机 323 份会话日志实测这四类曾进账共 125 条。
// 判据：账本 append-only（ADR-0001），误入的噪声删不掉 → 取 fail-closed。
const NON_USER_INBOX_KINDS = ['subagent-settled', 'agent-message', 'team-message', 'goal', 'assistant', 'plugin']

for (const kind of NON_USER_INBOX_KINDS) {
  test('E2+：agent/inbox/spliced + kind=' + kind + ' → 不摄入（机器消息）', () => {
    const ev = {
      type: 'agent/inbox/spliced',
      seq: 1001,
      data: {
        inserted: [{
          id: 'm3',
          role: 'user',
          source: { kind },
          content: [{ type: 'text', text: 'Background subagent abc finished' }],
        }],
      },
    }
    assert.equal(isEvidenceWorthy(ev), false, kind + ' 是机器消息，不应作为证据摄入')
  })
}

test('E2+：agent/inbox/spliced + kind 缺失 → 不摄入（来源不可判定取 fail-closed）', () => {
  const ev = {
    type: 'agent/inbox/spliced',
    seq: 1002,
    data: { inserted: [{ id: 'm4', role: 'user', content: [{ type: 'text', text: '来源未知' }] }] },
  }
  assert.equal(isEvidenceWorthy(ev), false)
})

// —— P1-4.2（2026-09-21）：4000 截断必须是可见的 ——

test('P1-4.2：超长文本截断后带可见标记', () => {
  const t = extractText({ content: 'x'.repeat(4500) })
  assert.ok(t.endsWith('…[truncated 4500 chars]'), t.slice(-40))
  assert.equal(t.slice(0, 4000), 'x'.repeat(4000), '前 4000 字符原样保留')
})

test('P1-4.2：未超限文本不加标记', () => {
  const t = extractText({ content: 'short text' })
  assert.equal(t, 'short text')
  assert.ok(!t.includes('truncated'))
})

test('P1-4.2：边界——恰好 4000 不加，4001 加', () => {
  assert.equal(extractText({ content: 'z'.repeat(4000) }), 'z'.repeat(4000))
  const t = extractText({ content: 'z'.repeat(4001) })
  assert.ok(t.endsWith('…[truncated 4001 chars]'), t.slice(-40))
})

test('P1-4.2：截断确定性——同一事件恒得同一结果（幂等契约）', () => {
  const ev = { content: 'y'.repeat(4200) }
  assert.equal(extractText(ev), extractText(ev))
  // 且截断结果仍低于 evidence 写入校验上限 8000
  assert.ok(extractText(ev).length < 8000)
})
