// test/acp-command.test.mjs — T4 M4.3：/acp rule review 命令验收。
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { openEvidenceLedger } from '../src/store.mjs'
import { handleRuleReviewCommand, RULE_CMD_USAGE } from '../src/index.mjs'

function fresh(t) {
  const dir = mkdtempSync(path.join(tmpdir(), 'acp-cmd-'))
  const ledger = openEvidenceLedger({ dir })
  t.after(() => { try { ledger.close() } catch { /* closed */ } rmSync(dir, { recursive: true, force: true }) })
  return ledger
}

const seedDraft = (ledger, over = {}) => ledger.ruleStore.createRule({
  domain: 'workflow',
  title: '测试先行',
  text: '改代码前先跑测试',
  gates: ['explicit-prefix'],
  evidenceIds: ['ev_seed'],
  ...over,
})

test('空库 list → 空态提示', (t) => {
  const ledger = fresh(t)
  const res = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule list')
  assert.equal(res.kind, 'success')
  assert.ok(res.text.includes('无规则草案'))
})

test('list 展示草案与生效规则', (t) => {
  const ledger = fresh(t)
  seedDraft(ledger)
  const act = seedDraft(ledger, { title: '生效规则', text: '生效规则文本', id: undefined })
  ledger.ruleStore.transitionRule(act.row.id, 'approve')
  const res = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule list')
  assert.ok(res.text.includes('[draft] 1 条'))
  assert.ok(res.text.includes('测试先行'))
  assert.ok(res.text.includes('[active] 1 条'))
  assert.ok(res.text.includes('生效规则'))
})

test('B15：pin/unpin 切换常驻标记（gates always）+ audit + onChanged', (t) => {
  const ledger = fresh(t)
  const a = seedDraft(ledger, { title: '生效A', text: '规则A文本', gates: [] })
  ledger.ruleStore.transitionRule(a.row.id, 'approve')
  let changed = 0
  const pin = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule pin 1', { onChanged: () => { changed += 1 } })
  assert.equal(pin.kind, 'success')
  assert.ok(pin.text.includes('always'), pin.text)
  assert.deepEqual(ledger.ruleStore.getRule(a.row.id).gates, ['always'])
  assert.equal(changed, 1)
  assert.equal(
    ledger.db.prepare("SELECT COUNT(*) n FROM audit WHERE op='rule_gates_updated' AND target_id=?").get(a.row.id).n, 1,
  )
  const unpin = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule unpin 1', { onChanged: () => { changed += 1 } })
  assert.equal(unpin.kind, 'success')
  assert.deepEqual(ledger.ruleStore.getRule(a.row.id).gates, [])
  assert.equal(changed, 2)
  const again = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule unpin 1')
  assert.equal(again.kind, 'success', '重复 unpin 幂等（gates 已空）')
})

test('B15：pin 越界/非法序号 → error；list 显示序号与常驻标记', (t) => {
  const ledger = fresh(t)
  assert.equal(handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule pin 9').kind, 'error')
  assert.equal(handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule pin x').kind, 'error')
  const a = seedDraft(ledger, { title: '常驻规则', text: '不可逆操作前先备份', gates: [] })
  ledger.ruleStore.transitionRule(a.row.id, 'approve')
  ledger.ruleStore.updateRuleGates(a.row.id, ['always'])
  const res = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule list')
  assert.ok(res.text.includes('1. ['), 'active 带序号: ' + res.text)
  assert.ok(res.text.includes('📌常驻'), '常驻标记显示')
})

test('B14-4：list 展示字数与超安全线警示（可注入性提示）', (t) => {
  const ledger = fresh(t)
  seedDraft(ledger, { title: '短规则', text: '不可逆操作前先备份', gates: [] })
  const long = '很长的规则文本'.repeat(10) // 70 字 > 40 字安全线
  seedDraft(ledger, { title: '长规则', text: long, gates: [] })
  const res = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule list')
  assert.ok(res.text.includes(String('不可逆操作前先备份'.length) + '字'), '短规则显示字数标记: ' + res.text)
  assert.ok(res.text.includes('70字'), '长规则显示字数标记')
  assert.ok(res.text.includes('⚠超40字安全线'), '长规则带超线警示')
})

test('accept 1 → active + audit rule_approved + onChanged 回调', (t) => {
  const ledger = fresh(t)
  const d = seedDraft(ledger)
  let changed = 0
  const res = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule accept 1', { onChanged: () => { changed += 1 } })
  assert.equal(res.kind, 'success')
  assert.ok(res.text.includes('active'))
  assert.equal(ledger.ruleStore.getRule(d.row.id).state, 'active')
  assert.equal(changed, 1)
  const aud = ledger.db.prepare("SELECT COUNT(*) n FROM audit WHERE op='rule_approved' AND target_id=?").get(d.row.id)
  assert.equal(aud.n, 1)
})

test('reject 1 → rejected + audit rule_rejected；重复 reject 报错', (t) => {
  const ledger = fresh(t)
  const d = seedDraft(ledger)
  const res = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule reject 1')
  assert.equal(res.kind, 'success')
  assert.ok(res.text.includes('rejected'))
  assert.equal(ledger.ruleStore.getRule(d.row.id).state, 'rejected')
  const again = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule reject 1')
  assert.equal(again.kind, 'error', '终态不可再操作')
})

test('越界序号 / 非法输入 → error + usage', (t) => {
  const ledger = fresh(t)
  const res1 = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule accept 9')
  assert.equal(res1.kind, 'error')
  const res2 = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule accept xyz')
  assert.equal(res2.kind, 'error')
  const usage = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'bogus')
  assert.equal(usage.text, RULE_CMD_USAGE)
})

test('rebuild → 调 onChanged 重建视图；onChanged 失败返回 error 不抛', (t) => {
  const ledger = fresh(t)
  let changed = 0
  const ok = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule rebuild', {
    onChanged: () => { changed += 1; return true },
  })
  assert.equal(ok.kind, 'success')
  assert.ok(ok.text.includes('已重建'))
  assert.equal(changed, 1, 'rebuild 必须触发视图重建回调')
  const fail = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule rebuild', { onChanged: () => false })
  assert.equal(fail.kind, 'error')
  assert.ok(fail.text.includes('失败'))
  const bare = handleRuleReviewCommand(ledger.ruleStore, ledger.auditStore, 'rule rebuild')
  assert.equal(bare.kind, 'success', '未接线 onChanged 时也不抛')
})
