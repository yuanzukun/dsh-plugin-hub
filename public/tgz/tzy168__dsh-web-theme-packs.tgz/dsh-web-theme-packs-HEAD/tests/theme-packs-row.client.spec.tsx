// @vitest-environment jsdom
/** ThemePacksRow: default plus pack cards; clicks drive selectPack. */
import { afterEach, describe, expect, it, vi } from 'vitest'
import { act, cleanup, fireEvent, render, screen } from '@testing-library/react'
import { createSnapshotStore, type SessionListState, type WorkspaceListState } from '@deepseek-ai/dsh-client-runtime/client'
import { bindSnapshotSelector } from '@deepseek-ai/dsh-client-web-react'
import { ThemePacksRow } from '../src/client/ThemePacksRow.tsx'
import type { ThemePacksRowComponentProps } from '../src/client/ThemePacksRow.tsx'
import { createThemePacksRowStore } from '../src/client/settings-store.ts'

afterEach(cleanup)

const COPY: Record<string, string> = {
  'packs.title': 'Theme packs',
  'packs.default': 'Default',
  'packs.empty': 'No theme packs yet.',
  'packs.hint': 'Choose an installed pack.',
}

function emptySessions() {
  const store = createSnapshotStore<SessionListState>(
    { ids: [], byId: {}, current: undefined, phase: 'ready', subagentsByParent: {}, jobsBySession: {}, currentAddress: undefined })
  return bindSnapshotSelector(store)
}
function emptyWorkspaces() {
  const store = createSnapshotStore<WorkspaceListState>({
    items: [], archivedSessionIds: [], state: 'idle', phase: 'ready', error: null,
    baselinesReady: true, recentWorkspaceId: undefined,
  })
  return bindSnapshotSelector(store)
}

function mount(preference: string, packs = [{ id: 'aero-blue', name: 'Aero Blue' }]) {
  const store = createThemePacksRowStore().create()
  store.actions.sync(packs, preference, 0)
  const selectPack = vi.fn()
  const props: ThemePacksRowComponentProps = {
    useSessions: emptySessions(),
    useWorkspaces: emptyWorkspaces(),
    useStore: bindSnapshotSelector(store),
    actions: store.actions,
    t: (key: string) => COPY[key] ?? key,
    selectPack,
  }
  render(<ThemePacksRow {...props} />)
  return { store, selectPack }
}

const pressed = (name: string): string | null =>
  screen.getByRole('button', { name }).getAttribute('aria-pressed')

describe('ThemePacksRow', () => {
  it('selects Default when the preference is a built-in value', () => {
    mount('system')
    expect(screen.getByText('Theme packs')).toBeDefined()
    expect(pressed('Default')).toBe('true')
    expect(pressed('Aero Blue')).toBe('false')
  })

  it('selects the pack card when the preference is that pack id', () => {
    mount('aero-blue')
    expect(pressed('Default')).toBe('false')
    expect(pressed('Aero Blue')).toBe('true')
  })

  it('click drives selectPack; selection follows the store mirror', () => {
    const b = mount('system')
    fireEvent.click(screen.getByRole('button', { name: 'Aero Blue' }))
    expect(b.selectPack).toHaveBeenCalledWith('aero-blue')
    expect(pressed('Default')).toBe('true')
    act(() => { b.store.actions.sync([{ id: 'aero-blue', name: 'Aero Blue' }], 'aero-blue', 1) })
    expect(pressed('Aero Blue')).toBe('true')
  })

  it('shows the empty copy when no packs are loaded', () => {
    mount('system', [])
    expect(screen.getByText('No theme packs yet.')).toBeDefined()
    expect(screen.queryByRole('button', { name: 'Default' })).toBeNull()
  })
})
