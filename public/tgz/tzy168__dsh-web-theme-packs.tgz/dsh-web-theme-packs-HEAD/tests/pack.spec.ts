/** Pack JSON validation and relative url() rewriting. */
import { describe, expect, it } from 'vitest'
import { parseThemePackManifest, rewritePackUrls, toCatalog } from '../src/pack.ts'

describe('parseThemePackManifest', () => {
  it('accepts a minimal valid pack', () => {
    const parsed = parseThemePackManifest({
      id: 'aero-blue',
      name: 'Aero Blue',
      colorScheme: 'light',
    })
    expect(parsed).toMatchObject({ id: 'aero-blue', name: 'Aero Blue', colorScheme: 'light', tokens: {}, fonts: [] })
  })

  it('rejects built-in Appearance ids', () => {
    expect(parseThemePackManifest({ id: 'dark', name: 'X', colorScheme: 'dark' }))
      .toMatch(/cannot be light/)
  })

  it('rejects a non-custom-property token name', () => {
    expect(parseThemePackManifest({
      id: 'x', name: 'X', colorScheme: 'light', tokens: { color: 'red' },
    })).toMatch(/custom property/)
  })

  it('rejects a parent-relative css path', () => {
    expect(parseThemePackManifest({
      id: 'x', name: 'X', colorScheme: 'light', css: '../evil.css',
    })).toMatch(/pack-relative/)
  })
})

describe('rewritePackUrls', () => {
  it('rewrites relative urls and leaves data, absolute, and parent-relative urls', () => {
    const css = 'a{background:url(assets/bg.svg)} b{background:url("/abs.png")} c{background:url(data:image/svg+xml,x)} d{background:url(../x.png)}'
    expect(rewritePackUrls(css, '/dsh-theme-packs/aero-blue')).toBe(
      'a{background:url(/dsh-theme-packs/aero-blue/assets/bg.svg)} b{background:url("/abs.png")} c{background:url(data:image/svg+xml,x)} d{background:url(../x.png)}',
    )
  })
})

describe('toCatalog', () => {
  it('rewrites token urls and font paths onto the pack prefix', () => {
    const catalog = toCatalog([{
      manifest: {
        id: 'aero-blue',
        name: 'Aero',
        colorScheme: 'light',
        tokens: { '--dsw-alias-bg-base': 'url(assets/bg.svg)' },
        fonts: [{ family: 'PackSans', file: 'fonts/a.woff2', weight: 400 }],
        preview: 'preview.svg',
        css: 'theme.css',
      },
      dir: '/tmp/aero-blue',
      cssText: 'body{background:url(/dsh-theme-packs/aero-blue/assets/bg.svg)}',
    }], '/dsh-theme-packs', 3)
    expect(catalog.revision).toBe(3)
    expect(catalog.packs[0]).toMatchObject({
      id: 'aero-blue',
      cssUrl: '/dsh-theme-packs/aero-blue/theme.css',
      previewUrl: '/dsh-theme-packs/aero-blue/preview.svg',
      tokens: { '--dsw-alias-bg-base': 'url(/dsh-theme-packs/aero-blue/assets/bg.svg)' },
    })
    expect(catalog.packs[0]?.fonts[0]).toMatchObject({
      family: 'PackSans',
      url: '/dsh-theme-packs/aero-blue/fonts/a.woff2',
      weight: 400,
    })
  })
})
