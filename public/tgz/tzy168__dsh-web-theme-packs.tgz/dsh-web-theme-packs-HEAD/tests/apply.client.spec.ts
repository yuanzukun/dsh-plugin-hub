// @vitest-environment jsdom
/** Client apply: catalog fetch registers packs; fiber dispose unregisters them. */
import { Context } from '@deepseek-ai/cordis'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { SlotRegistry } from '@deepseek-ai/dsh-client-runtime/client'
import { LocaleRuntime } from '@deepseek-ai/dsh-client-locale/client'
import { TestRemote, stubSettingsScope, usePinnedBrowserLanguages } from '@deepseek-ai/dsh-client-test-runtime'
import { SettingsScopeBinder } from '@deepseek-ai/dsh-client-ui-settings/client'
import { ThemeRuntime } from '@deepseek-ai/dsh-client-ui-theme/client'
import type { ThemeSettings } from '@deepseek-ai/dsh-client-ui-theme/client'
import { apply, inject, SETTINGS_NS } from '../src/client/index.ts'
import { ThemePacksRow } from '../src/client/ThemePacksRow.tsx'
import { THEME_PACKS_NAMESPACE } from '../src/settings-contract.ts'
import { ThemePacksSettingsSchema } from '../src/settings.ts'

usePinnedBrowserLanguages('zh-CN')

const SLOT = 'settings.general.item'
const CATALOG = {
  revision: 1,
  prefix: '/dsh-theme-packs',
  packs: [{
    id: 'aero-blue',
    name: 'Aero Blue',
    colorScheme: 'light' as const,
    tokens: { '--dsw-alias-bg-base': '#c5e4f7' },
    fonts: [],
  }],
}

afterEach(() => {
  vi.unstubAllGlobals()
})

function declareItems(slots: SlotRegistry): () => void {
  return slots.register(
    { name: 'root', children: { [SLOT]: { kind: 'list', scope: 'root' } } } as never,
    () => null,
  )
}

async function bench() {
  vi.stubGlobal('fetch', vi.fn(async () => ({
    ok: true,
    json: async () => CATALOG,
  })))
  vi.stubGlobal('EventSource', class {
    onmessage: ((ev: MessageEvent) => void) | null = null
    close(): void { /* tests do not keep the stream */ }
  })
  const ctx = new Context()
  await ctx.plugin(SlotRegistry).await()
  const locale = new LocaleRuntime(ctx)
  ctx.provide('locale', locale)
  const themeHost = stubSettingsScope<ThemeSettings>()
  const theme = new ThemeRuntime(ctx, themeHost.scope)
  ctx.provide('theme', theme)
  let active = ''
  const namespace = () => ({
    ns: THEME_PACKS_NAMESPACE,
    schema: ThemePacksSettingsSchema.toJSON(),
    value: { active },
    applies: 'live' as const,
    secrets: [],
    revision: 0,
  })
  const describe = vi.fn(() => Promise.resolve({
    rpcId: 'packs-describe' as never,
    result: {
      ok: true as const,
      value: { writable: true, hasDocument: true, namespaces: [namespace()] },
    },
  }))
  const mutate = vi.fn((request: { ops: { value: string }[] }) => {
    active = request.ops[0]!.value
    return Promise.resolve({
      rpcId: 'packs-mutate' as never,
      result: { ok: true as const, value: namespace() },
    })
  })
  ctx.provide('connection', { api: { settings: { describe, mutate } }, isLoopback: true } as never)
  new TestRemote(ctx)
  await ctx.plugin(SettingsScopeBinder).await()
  return { ctx, slots: ctx.get('slots') as SlotRegistry, locale, theme }
}

describe('web-theme-packs apply', () => {
  it('declares the slot and locale services', () => {
    expect(inject).toEqual(['slots', 'locale', 'theme', 'connection', 'remote', 'settingsScope'])
  })

  it('registers catalog packs with ThemeRuntime and the picker row', async () => {
    const b = await bench()
    declareItems(b.slots)
    await b.ctx.plugin({ inject: [...inject], apply }).await()
    await vi.waitFor(() => {
      expect(b.theme.getTheme().themes.some(theme => theme.id === 'aero-blue')).toBe(true)
    })
    expect(b.locale.bind(SETTINGS_NS)('packs.title')).toBe('主题包')
    expect(b.slots.entries(SLOT).some(entry => entry.component === ThemePacksRow)).toBe(true)
  })

  it('unregisters packs when the fiber disposes', async () => {
    const b = await bench()
    declareItems(b.slots)
    const fiber = b.ctx.plugin({ inject: [...inject], apply })
    await fiber.await()
    await vi.waitFor(() => {
      expect(b.theme.getTheme().themes.some(theme => theme.id === 'aero-blue')).toBe(true)
    })
    await fiber.dispose()
    expect(b.theme.getTheme().themes.some(theme => theme.id === 'aero-blue')).toBe(false)
    expect(b.slots.entries(SLOT)).toHaveLength(0)
  })
})
