/** Directory scan: later roots win, invalid packs are skipped. */
import { mkdirSync, mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import { scanThemePacks } from '../src/scan.ts'

function writePack(root: string, id: string, extra: Record<string, unknown> = {}): void {
  const dir = join(root, id)
  mkdirSync(dir, { recursive: true })
  writeFileSync(join(dir, 'theme.json'), JSON.stringify({
    id,
    name: id,
    colorScheme: 'light',
    ...extra,
  }))
}

describe('scanThemePacks', () => {
  it('loads valid packs and lets a later root replace a duplicate id', () => {
    const first = mkdtempSync(join(tmpdir(), 'theme-packs-a-'))
    const second = mkdtempSync(join(tmpdir(), 'theme-packs-b-'))
    writePack(first, 'aero-blue', { name: 'First' })
    writePack(second, 'aero-blue', { name: 'Second' })
    writePack(second, 'ink-night', { name: 'Ink', colorScheme: 'dark' })
    const warnings: string[] = []
    const packs = scanThemePacks([first, second], '/dsh-theme-packs', { warn: m => { warnings.push(m) } })
    expect(packs.map(pack => [pack.manifest.id, pack.manifest.name])).toEqual([
      ['aero-blue', 'Second'],
      ['ink-night', 'Ink'],
    ])
    expect(warnings).toEqual([])
  })

  it('skips a pack whose theme.json is invalid and keeps the rest', () => {
    const root = mkdtempSync(join(tmpdir(), 'theme-packs-c-'))
    writePack(root, 'aero-blue')
    const bad = join(root, 'broken')
    mkdirSync(bad)
    writeFileSync(join(bad, 'theme.json'), '{')
    const warnings: string[] = []
    const packs = scanThemePacks([root], '/p', { warn: m => { warnings.push(m) } })
    expect(packs.map(pack => pack.manifest.id)).toEqual(['aero-blue'])
    expect(warnings.some(line => line.includes('not valid JSON'))).toBe(true)
  })

  it('skips a pack that names a missing css file', () => {
    const root = mkdtempSync(join(tmpdir(), 'theme-packs-d-'))
    writePack(root, 'ghost', { css: 'missing.css' })
    const warnings: string[] = []
    const packs = scanThemePacks([root], '/p', { warn: m => { warnings.push(m) } })
    expect(packs).toEqual([])
    expect(warnings.some(line => line.includes('missing.css'))).toBe(true)
  })
})
