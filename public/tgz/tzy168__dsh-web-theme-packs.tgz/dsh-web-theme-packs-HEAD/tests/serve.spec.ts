/** Prefix handler: catalog JSON, rewritten CSS, assets, and traversal rejection. */
import { createServer } from 'node:http'
import type { AddressInfo } from 'node:net'
import { mkdirSync, mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import { handleThemePackRequest, type ThemePackHttpState } from '../src/serve.ts'
import { scanThemePacks } from '../src/scan.ts'

async function withServer(state: ThemePackHttpState, run: (base: string) => Promise<void>): Promise<void> {
  const server = createServer((req, res) => { handleThemePackRequest(state, req, res) })
  await new Promise<void>(resolve => { server.listen(0, '127.0.0.1', resolve) })
  const { port } = server.address() as AddressInfo
  try {
    await run(`http://127.0.0.1:${String(port)}`)
  } finally {
    await new Promise<void>((resolve, reject) => {
      server.close(error => { error ? reject(error) : resolve() })
    })
  }
}

describe('handleThemePackRequest', () => {
  it('serves catalog, rewritten css, and pack files, and rejects traversal', async () => {
    const root = mkdtempSync(join(tmpdir(), 'theme-packs-http-'))
    const dir = join(root, 'aero-blue')
    mkdirSync(join(dir, 'assets'), { recursive: true })
    writeFileSync(join(dir, 'theme.json'), JSON.stringify({
      id: 'aero-blue',
      name: 'Aero',
      colorScheme: 'light',
      css: 'theme.css',
      preview: 'preview.svg',
    }))
    writeFileSync(join(dir, 'theme.css'), 'body{background:url(assets/bg.svg)}')
    writeFileSync(join(dir, 'preview.svg'), '<svg xmlns="http://www.w3.org/2000/svg"/>')
    writeFileSync(join(dir, 'assets', 'bg.svg'), '<svg xmlns="http://www.w3.org/2000/svg"/>')
    const packs = scanThemePacks([root], '/dsh-theme-packs', { warn: () => {} })
    const state: ThemePackHttpState = {
      prefix: '/dsh-theme-packs',
      revision: 4,
      packs,
      listeners: new Set(),
    }
    await withServer(state, async (base) => {
      const catalog = await (await fetch(`${base}/dsh-theme-packs/catalog.json`)).json() as {
        revision: number
        packs: { id: string; cssUrl: string }[]
      }
      expect(catalog.revision).toBe(4)
      expect(catalog.packs[0]?.id).toBe('aero-blue')
      const css = await (await fetch(`${base}${catalog.packs[0]!.cssUrl}`)).text()
      expect(css).toContain('url(/dsh-theme-packs/aero-blue/assets/bg.svg)')
      const asset = await fetch(`${base}/dsh-theme-packs/aero-blue/assets/bg.svg`)
      expect(asset.status).toBe(200)
      expect(asset.headers.get('content-type')).toBe('image/svg+xml')
      const missing = await fetch(`${base}/dsh-theme-packs/aero-blue/nope.svg`)
      expect(missing.status).toBe(404)
    })
  })
})
