/**
 * Theme-pack JSON and catalog records. File contents are data only: the
 * loader never evaluates JavaScript from a pack.
 */

/** One webfont declared by a pack. */
export interface ThemePackFont {
  /** CSS font-family name. */
  family: string
  /** Pack-relative font file path. */
  file: string
  /** CSS font-weight; omitted when the file is a variable font or the default. */
  weight?: number
  /** CSS font-style. */
  style?: 'normal' | 'italic'
}

/** On-disk `theme.json` after validation. */
export interface ThemePackManifest {
  /** Registrable ThemeRuntime id; also the HTTP path segment. */
  id: string
  /** Settings-row label. */
  name: string
  /** Optional one-line description shown under the name. */
  description?: string
  /** Base palette the pack builds on. */
  colorScheme: 'light' | 'dark'
  /** `--dsw-*` (or other custom property) overrides applied as inline variables. */
  tokens: Record<string, string>
  /** Pack-relative extra stylesheet, rewritten so relative `url()` values hit the pack HTTP prefix. */
  css?: string
  /** Pack-relative preview image for the settings row. */
  preview?: string
  /** Optional webfonts loaded while the pack is registered. */
  fonts: readonly ThemePackFont[]
}

/** One pack as published to the browser. */
export interface ThemePackCatalogEntry {
  /** ThemeRuntime id. */
  id: string
  /** Settings-row label. */
  name: string
  /** Optional one-line description. */
  description?: string
  /** Base palette. */
  colorScheme: 'light' | 'dark'
  /** Rewritten token map (relative `url()` values already point at the pack prefix). */
  tokens: Record<string, string>
  /** Absolute-from-origin extra stylesheet, when the pack shipped one. */
  cssUrl?: string
  /** Absolute-from-origin preview image, when the pack shipped one. */
  previewUrl?: string
  /** Webfonts with absolute-from-origin file URLs. */
  fonts: readonly {
    family: string
    url: string
    weight?: number
    style?: 'normal' | 'italic'
  }[]
}

/** Catalog document served at `{prefix}/catalog.json`. */
export interface ThemePackCatalog {
  /** Monotonic rescan counter; EventSource messages carry the same number. */
  revision: number
  /** HTTP prefix used to form asset URLs (no trailing slash). */
  prefix: string
  /** Packs in registration order (later scan roots win on duplicate ids). */
  packs: readonly ThemePackCatalogEntry[]
}

/** A pack loaded from disk, including the filesystem home used to serve assets. */
export interface LoadedThemePack {
  /** Validated manifest. */
  manifest: ThemePackManifest
  /** Absolute directory that contains `theme.json`. */
  dir: string
  /** Rewritten extra CSS text, when the pack shipped a stylesheet. */
  cssText?: string
}

const ID_PATTERN = /^[a-z][a-z0-9-]*$/
const TOKEN_NAME_PATTERN = /^--[A-Za-z0-9-]+$/

/**
 * Rewrite relative `url(...)` values so they resolve under `baseUrl`.
 * Absolute, data, and blob URLs are left unchanged.
 * @param css - CSS text or a single token value that may contain `url()`.
 * @param baseUrl - origin-absolute prefix for this pack, no trailing slash.
 * @returns the rewritten text.
 */
export function rewritePackUrls(css: string, baseUrl: string): string {
  return css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/g, (whole, quote: string, spec: string) => {
    const trimmed = spec.trim()
    if (trimmed === '' || isAbsoluteOrDataUrl(trimmed)) return whole
    const rel = trimmed.replace(/^\.\//, '')
    if (rel.startsWith('../') || rel.includes('\\') || rel.includes('\0')) return whole
    return `url(${quote}${baseUrl}/${rel}${quote})`
  })
}

/**
 * Parse and validate one `theme.json` document.
 * @param raw - parsed JSON value.
 * @returns the manifest, or a teaching error string.
 */
export function parseThemePackManifest(raw: unknown): ThemePackManifest | string {
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
    return 'theme.json must be a JSON object'
  }
  const value = raw as Record<string, unknown>
  if (typeof value.id !== 'string' || !ID_PATTERN.test(value.id)) {
    return 'theme.json "id" must match /^[a-z][a-z0-9-]*$/'
  }
  if (value.id === 'light' || value.id === 'dark' || value.id === 'system') {
    return 'theme.json "id" cannot be light, dark, or system (those are built-in Appearance values)'
  }
  if (typeof value.name !== 'string' || value.name.trim() === '') {
    return 'theme.json "name" must be a non-empty string'
  }
  if (value.colorScheme !== 'light' && value.colorScheme !== 'dark') {
    return 'theme.json "colorScheme" must be "light" or "dark"'
  }
  if (value.description !== undefined && typeof value.description !== 'string') {
    return 'theme.json "description" must be a string when present'
  }
  if (value.css !== undefined && !isPackRelativePath(value.css)) {
    return 'theme.json "css" must be a pack-relative path'
  }
  if (value.preview !== undefined && !isPackRelativePath(value.preview)) {
    return 'theme.json "preview" must be a pack-relative path'
  }
  const tokens = parseTokens(value.tokens)
  if (typeof tokens === 'string') return tokens
  const fonts = parseFonts(value.fonts)
  if (typeof fonts === 'string') return fonts
  return {
    id: value.id,
    name: value.name.trim(),
    colorScheme: value.colorScheme,
    tokens,
    fonts,
    ...(value.description !== undefined ? { description: value.description } : {}),
    ...(value.css !== undefined ? { css: value.css } : {}),
    ...(value.preview !== undefined ? { preview: value.preview } : {}),
  }
}

/**
 * Build the browser catalog from loaded packs.
 * @param packs - packs in the order they should appear.
 * @param prefix - HTTP prefix, no trailing slash.
 * @param revision - catalog generation.
 * @returns JSON-safe catalog.
 */
export function toCatalog(
  packs: readonly LoadedThemePack[],
  prefix: string,
  revision: number,
): ThemePackCatalog {
  return {
    revision,
    prefix,
    packs: packs.map((pack) => {
      const base = `${prefix}/${pack.manifest.id}`
      const tokens: Record<string, string> = {}
      for (const [name, value] of Object.entries(pack.manifest.tokens)) {
        tokens[name] = rewritePackUrls(value, base)
      }
      const fonts = pack.manifest.fonts.map(font => ({
        family: font.family,
        url: `${base}/${font.file.replace(/^\.\//, '')}`,
        ...(font.weight !== undefined ? { weight: font.weight } : {}),
        ...(font.style !== undefined ? { style: font.style } : {}),
      }))
      return {
        id: pack.manifest.id,
        name: pack.manifest.name,
        colorScheme: pack.manifest.colorScheme,
        tokens,
        fonts,
        ...(pack.manifest.description !== undefined ? { description: pack.manifest.description } : {}),
        ...(pack.cssText !== undefined ? { cssUrl: `${base}/theme.css` } : {}),
        ...(pack.manifest.preview !== undefined
          ? { previewUrl: `${base}/${pack.manifest.preview.replace(/^\.\//, '')}` }
          : {}),
      }
    }),
  }
}

function parseTokens(raw: unknown): Record<string, string> | string {
  if (raw === undefined) return {}
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
    return 'theme.json "tokens" must be an object of CSS custom-property names to strings'
  }
  const tokens: Record<string, string> = {}
  for (const [name, value] of Object.entries(raw as Record<string, unknown>)) {
    if (!TOKEN_NAME_PATTERN.test(name)) {
      return `theme.json token "${name}" must be a CSS custom property (--name)`
    }
    if (typeof value !== 'string') {
      return `theme.json token "${name}" must be a string`
    }
    tokens[name] = value
  }
  return tokens
}

function parseFonts(raw: unknown): ThemePackFont[] | string {
  if (raw === undefined) return []
  if (!Array.isArray(raw)) return 'theme.json "fonts" must be an array'
  const fonts: ThemePackFont[] = []
  for (const [index, entry] of raw.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      return `theme.json fonts[${String(index)}] must be an object`
    }
    const font = entry as Record<string, unknown>
    if (typeof font.family !== 'string' || font.family.trim() === '') {
      return `theme.json fonts[${String(index)}].family must be a non-empty string`
    }
    if (!isPackRelativePath(font.file)) {
      return `theme.json fonts[${String(index)}].file must be a pack-relative path`
    }
    if (font.weight !== undefined && (typeof font.weight !== 'number' || !Number.isFinite(font.weight))) {
      return `theme.json fonts[${String(index)}].weight must be a number when present`
    }
    if (font.style !== undefined && font.style !== 'normal' && font.style !== 'italic') {
      return `theme.json fonts[${String(index)}].style must be "normal" or "italic"`
    }
    fonts.push({
      family: font.family.trim(),
      file: font.file,
      ...(typeof font.weight === 'number' ? { weight: font.weight } : {}),
      ...(font.style === 'normal' || font.style === 'italic' ? { style: font.style } : {}),
    })
  }
  return fonts
}

function isPackRelativePath(value: unknown): value is string {
  return typeof value === 'string'
    && value !== ''
    && !value.startsWith('/')
    && !value.includes('..')
    && !value.includes('\\')
    && !value.includes('\0')
}

function isAbsoluteOrDataUrl(spec: string): boolean {
  return spec.startsWith('/')
    || spec.startsWith('data:')
    || spec.startsWith('blob:')
    || /^[a-z][a-z0-9+.-]*:/i.test(spec)
}
