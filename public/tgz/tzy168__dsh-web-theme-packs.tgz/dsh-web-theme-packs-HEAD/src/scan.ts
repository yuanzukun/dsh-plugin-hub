/**
 * Scan configured roots for `theme.json` packs. Later roots win on duplicate
 * ids. A pack that fails validation is skipped with a warning so one broken
 * drop-in folder cannot take down the Web UI.
 */

import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { join } from 'node:path'
import type { LoadedThemePack, ThemePackManifest } from './pack.ts'
import { parseThemePackManifest, rewritePackUrls } from './pack.ts'

/** Logger face used while skipping invalid packs. */
export interface PackScanLogger {
  /** Record a skipped pack. */
  warn(message: string): void
}

/**
 * Load every immediate subdirectory of `roots` that contains a valid `theme.json`.
 * @param roots - absolute directories to scan, in override order.
 * @param prefix - HTTP prefix used to rewrite relative `url()` values.
 * @param logger - destination for skip warnings.
 * @returns loaded packs, later roots winning on id.
 */
export function scanThemePacks(
  roots: readonly string[],
  prefix: string,
  logger: PackScanLogger,
): LoadedThemePack[] {
  const byId = new Map<string, LoadedThemePack>()
  for (const root of roots) {
    if (!existsSync(root) || !statSync(root).isDirectory()) continue
    let entries: string[]
    try {
      entries = readdirSync(root)
    } catch (error) {
      logger.warn(`theme-packs: cannot read "${root}": ${errorMessage(error)}`)
      continue
    }
    for (const name of entries) {
      const dir = join(root, name)
      let isDir = false
      try {
        isDir = statSync(dir).isDirectory()
      } catch {
        continue
      }
      if (!isDir) continue
      const loaded = loadPack(dir, prefix, logger)
      if (loaded === undefined) continue
      byId.set(loaded.manifest.id, loaded)
    }
  }
  return [...byId.values()]
}

function loadPack(dir: string, prefix: string, logger: PackScanLogger): LoadedThemePack | undefined {
  const manifestPath = join(dir, 'theme.json')
  if (!existsSync(manifestPath)) return undefined
  let raw: unknown
  try {
    raw = JSON.parse(readFileSync(manifestPath, 'utf8')) as unknown
  } catch (error) {
    logger.warn(`theme-packs: "${manifestPath}" is not valid JSON: ${errorMessage(error)}`)
    return undefined
  }
  const parsed = parseThemePackManifest(raw)
  if (typeof parsed === 'string') {
    logger.warn(`theme-packs: "${manifestPath}": ${parsed}`)
    return undefined
  }
  return materializePack(dir, parsed, prefix, logger)
}

function materializePack(
  dir: string,
  manifest: ThemePackManifest,
  prefix: string,
  logger: PackScanLogger,
): LoadedThemePack | undefined {
  const missing = missingRelative(dir, manifest)
  if (missing !== undefined) {
    logger.warn(`theme-packs: "${join(dir, 'theme.json')}" references missing file "${missing}"`)
    return undefined
  }
  const base = `${prefix}/${manifest.id}`
  let cssText: string | undefined
  if (manifest.css !== undefined) {
    cssText = rewritePackUrls(readFileSync(join(dir, manifest.css), 'utf8'), base)
  }
  return {
    manifest,
    dir,
    ...(cssText !== undefined ? { cssText } : {}),
  }
}

function missingRelative(dir: string, manifest: ThemePackManifest): string | undefined {
  const paths = [
    ...(manifest.css !== undefined ? [manifest.css] : []),
    ...(manifest.preview !== undefined ? [manifest.preview] : []),
    ...manifest.fonts.map(font => font.file),
  ]
  for (const rel of paths) {
    if (!existsSync(join(dir, rel))) return rel
  }
  return undefined
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
