/**
 * HTTP handler for the theme-pack prefix: catalog JSON, SSE revision stream,
 * rewritten extra CSS, and pack-relative assets.
 */

import { createReadStream, existsSync, statSync } from 'node:fs'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { extname, relative, resolve, sep } from 'node:path'
import type { LoadedThemePack, ThemePackCatalog } from './pack.ts'
import { toCatalog } from './pack.ts'

const MIME: Record<string, string> = {
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
}

/** Live pack table plus SSE fan-out owned by the Host apply. */
export interface ThemePackHttpState {
  /** HTTP prefix, no trailing slash. */
  prefix: string
  /** Current generation. */
  revision: number
  /** Loaded packs. */
  packs: readonly LoadedThemePack[]
  /** Open SSE responses. */
  listeners: Set<ServerResponse>
}

/**
 * Derive the catalog document from the live state.
 * @param state - current packs and revision.
 * @returns catalog JSON value.
 */
export function catalogOf(state: ThemePackHttpState): ThemePackCatalog {
  return toCatalog(state.packs, state.prefix, state.revision)
}

/**
 * Notify SSE listeners that the catalog revision moved.
 * @param state - live state whose listeners are written.
 */
export function broadcastCatalogRevision(state: ThemePackHttpState): void {
  const body = `data: ${String(state.revision)}\n\n`
  for (const res of state.listeners) {
    try {
      res.write(body)
    } catch {
      state.listeners.delete(res)
    }
  }
}

/**
 * Handle one request under the theme-pack prefix.
 * @param state - live packs, prefix, and SSE listeners.
 * @param req - incoming request.
 * @param res - response to own.
 */
export function handleThemePackRequest(
  state: ThemePackHttpState,
  req: IncomingMessage,
  res: ServerResponse,
): void {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405)
    res.end()
    return
  }
  const pathname = new URL(req.url ?? '/', 'http://x').pathname
  if (pathname === `${state.prefix}/catalog.json`) {
    writeJson(res, req.method, catalogOf(state))
    return
  }
  if (pathname === `${state.prefix}/events`) {
    attachSse(state, req, res)
    return
  }
  const rest = pathname.startsWith(`${state.prefix}/`)
    ? pathname.slice(state.prefix.length + 1)
    : ''
  const slash = rest.indexOf('/')
  if (slash <= 0) {
    res.writeHead(404)
    res.end()
    return
  }
  const id = decodeURIComponent(rest.slice(0, slash))
  const rel = decodeURIComponent(rest.slice(slash + 1))
  const pack = state.packs.find(entry => entry.manifest.id === id)
  if (pack === undefined) {
    res.writeHead(404)
    res.end()
    return
  }
  if (rel === 'theme.css' && pack.cssText !== undefined) {
    writeText(res, req.method, 'text/css; charset=utf-8', pack.cssText)
    return
  }
  servePackFile(pack.dir, rel, req.method === 'HEAD', res)
}

function attachSse(state: ThemePackHttpState, req: IncomingMessage, res: ServerResponse): void {
  res.writeHead(200, {
    'content-type': 'text/event-stream',
    'cache-control': 'no-cache',
    connection: 'keep-alive',
  })
  res.write(`data: ${String(state.revision)}\n\n`)
  state.listeners.add(res)
  const drop = (): void => {
    state.listeners.delete(res)
  }
  req.on('close', drop)
  res.on('close', drop)
}

function servePackFile(dir: string, rel: string, head: boolean, res: ServerResponse): void {
  const target = resolve(dir, rel)
  const root = resolve(dir)
  const relToRoot = relative(root, target)
  if (relToRoot === '' || relToRoot.startsWith('..') || relToRoot.split(sep).includes('..')) {
    res.writeHead(403)
    res.end()
    return
  }
  if (!existsSync(target) || !statSync(target).isFile()) {
    res.writeHead(404)
    res.end()
    return
  }
  const type = MIME[extname(target).toLowerCase()] ?? 'application/octet-stream'
  res.writeHead(200, { 'content-type': type })
  if (head) {
    res.end()
    return
  }
  createReadStream(target).pipe(res)
}

function writeJson(res: ServerResponse, method: string | undefined, body: unknown): void {
  const text = JSON.stringify(body)
  writeText(res, method, 'application/json; charset=utf-8', text)
}

function writeText(res: ServerResponse, method: string | undefined, type: string, body: string): void {
  res.writeHead(200, { 'content-type': type })
  if (method === 'HEAD') {
    res.end()
    return
  }
  res.end(body)
}
