/** Shared theme-pack settings field names. Safe for the browser bundle. */

/** Settings namespace owned by this plugin. */
export const THEME_PACKS_NAMESPACE = 'theme-packs'

/** Field carrying the selected pack id; empty means no pack (built-in Appearance). */
export const THEME_PACKS_ACTIVE_FIELD = 'active'

/** Durable theme-pack section. */
export interface ThemePacksSettings {
  /** Selected pack id, or `''` when Appearance owns the preference. */
  active: string
}
