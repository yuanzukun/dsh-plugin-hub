/**
 * Browser half: fetch the Host catalog, register each pack with ThemeRuntime,
 * inject extra CSS/fonts while a pack is active, and contribute the picker row.
 */

import type { BoundActions } from '@deepseek-ai/dsh-client-ui-slots'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { ThemeRuntime, ThemeSnapshot } from '@deepseek-ai/dsh-client-ui-theme/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-connection/client'
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type { ThemePackCatalog, ThemePackCatalogEntry } from '../pack.ts'
import {
  THEME_PACKS_ACTIVE_FIELD, THEME_PACKS_NAMESPACE, type ThemePacksSettings,
} from '../settings-contract.ts'
import { ThemePacksRow, type ThemePacksRowInjected } from './ThemePacksRow.tsx'
import { createThemePacksRowStore } from './settings-store.ts'
import { en, zh, type ThemePacksKey } from './locales.ts'

export type { ThemePacksRowComponentProps, ThemePacksRowInjected } from './ThemePacksRow.tsx'
export type { ThemePacksRowState } from './settings-store.ts'
export type { ThemePacksKey } from './locales.ts'

/** Namespace owning this feature's settings-row copy. */
export const SETTINGS_NS = 'settings.theme-packs'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The theme-pack settings row's copy. */
    'settings.theme-packs': ThemePacksKey
  }
}

const BUILTIN_PREFERENCES = new Set(['light', 'dark', 'system'])
const FONT_STYLE_ID = 'dsh-theme-packs-fonts'
const SHEET_ATTR = 'data-dsh-theme-pack-css'
const BODY_ATTR = 'data-dsh-theme-pack'

/** Required services: theme registry plus settings/locale/slots for the picker. */
export const inject = ['slots', 'locale', 'theme', 'connection', 'remote', 'settingsScope']

/**
 * Client plugin body: register discovered packs and the General-section picker.
 * @param ctx - client cordis context.
 */
export function apply(ctx: ClientContext): void {
  const theme = ctx.get('theme') as ThemeRuntime
  const host = ctx.settingsScope.bind<ThemePacksSettings>({ namespace: THEME_PACKS_NAMESPACE })
  ctx.effect(() => ctx.locale.register(SETTINGS_NS, { zh, en }), 'web-theme-packs: settings row dictionaries')

  const store = createThemePacksRowStore()
  let bound: BoundActions<typeof store> | undefined
  let catalog: ThemePackCatalog = { revision: 0, prefix: '/dsh-theme-packs', packs: [] }
  const disposers: (() => void)[] = []

  const syncStore = (snapshot: ThemeSnapshot): void => {
    bound?.sync(
      catalog.packs.map(pack => ({
        id: pack.id,
        name: pack.name,
        ...(pack.description !== undefined ? { description: pack.description } : {}),
        ...(pack.previewUrl !== undefined ? { previewUrl: pack.previewUrl } : {}),
      })),
      snapshot.preference,
      catalog.revision,
    )
  }

  const applyExtras = (snapshot: ThemeSnapshot): void => {
    const pack = catalog.packs.find(entry => entry.id === snapshot.preference)
    applyPackExtras(pack)
  }

  const adoptActive = (snapshot: ThemeSnapshot): void => {
    const active = host.getSnapshot().value?.active ?? ''
    if (active !== '' && catalog.packs.some(pack => pack.id === active) && snapshot.preference !== active) {
      theme.setTheme(active)
    }
  }

  const installCatalog = (next: ThemePackCatalog): void => {
    for (const dispose of disposers.splice(0)) dispose()
    catalog = next
    for (const pack of catalog.packs) {
      disposers.push(theme.register({
        id: pack.id,
        colorScheme: pack.colorScheme,
        tokens: pack.tokens,
      }))
    }
    const snapshot = theme.getTheme()
    adoptActive(snapshot)
    applyExtras(theme.getTheme())
    syncStore(theme.getTheme())
  }

  ctx.on('theme/change', (snapshot) => {
    if (BUILTIN_PREFERENCES.has(snapshot.preference) && (host.getSnapshot().value?.active ?? '') !== '') {
      void host.set(THEME_PACKS_ACTIVE_FIELD, '')
    }
    applyExtras(snapshot)
    syncStore(snapshot)
  })

  ctx.effect(() => host.subscribe(() => {
    adoptActive(theme.getTheme())
  }), 'web-theme-packs: settings adoption')

  let loadGen = 0
  const reload = async (): Promise<void> => {
    const gen = ++loadGen
    const prefix = catalog.prefix
    const response = await fetch(`${prefix}/catalog.json`)
    if (!response.ok) {
      throw new Error(`theme-packs: catalog ${String(response.status)}`)
    }
    const next = await response.json() as ThemePackCatalog
    if (gen !== loadGen) return
    installCatalog(next)
  }

  void reload().catch((error: unknown) => {
    ctx.logger.warn(error instanceof Error ? error : new Error(String(error)))
  })

  if (typeof EventSource !== 'undefined') {
    const source = new EventSource(`${catalog.prefix}/events`)
    source.onmessage = () => { void reload().catch((error: unknown) => {
      ctx.logger.warn(error instanceof Error ? error : new Error(String(error)))
    }) }
    ctx.effect(() => () => { source.close() }, 'web-theme-packs: catalog events')
  }

  ctx.effect(() => () => {
    loadGen += 1
    for (const dispose of disposers.splice(0)) dispose()
    applyPackExtras(undefined)
  }, 'web-theme-packs: registered themes')

  const injected = (actions: BoundActions<typeof store>): ThemePacksRowInjected => {
    bound = actions
    syncStore(theme.getTheme())
    return {
      selectPack: (id) => {
        if (id === '') {
          void host.set(THEME_PACKS_ACTIVE_FIELD, '')
          theme.setTheme('system')
          return
        }
        void host.set(THEME_PACKS_ACTIVE_FIELD, id)
        theme.setTheme(id)
      },
    }
  }
  ctx.slots.inject('settings.general.item', () => ctx.slots.register({
    name: 'settings.general.item',
    id: 'theme-packs',
    order: 15,
    store,
    locale: SETTINGS_NS,
    inject: injected,
  }, ThemePacksRow))
}

function applyPackExtras(pack: ThemePackCatalogEntry | undefined): void {
  const body = document.body
  if (pack === undefined) body.removeAttribute(BODY_ATTR)
  else body.setAttribute(BODY_ATTR, pack.id)
  document.getElementById(FONT_STYLE_ID)?.remove()
  document.querySelector(`link[${SHEET_ATTR}]`)?.remove()
  if (pack === undefined) return
  if (pack.fonts.length > 0) {
    const style = document.createElement('style')
    style.id = FONT_STYLE_ID
    style.textContent = pack.fonts.map((font) => {
      const extras = [
        font.weight !== undefined ? `font-weight:${String(font.weight)};` : '',
        font.style !== undefined ? `font-style:${font.style};` : '',
      ].join('')
      return `@font-face{font-family:${JSON.stringify(font.family)};src:url(${JSON.stringify(font.url)});${extras}}`
    }).join('')
    document.head.append(style)
  }
  if (pack.cssUrl !== undefined) {
    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href = pack.cssUrl
    link.setAttribute(SHEET_ATTR, '')
    document.head.append(link)
  }
}
