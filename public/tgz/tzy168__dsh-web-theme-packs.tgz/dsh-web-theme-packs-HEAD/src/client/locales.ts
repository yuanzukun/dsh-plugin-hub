/** `settings.theme-packs` namespace dictionaries. */

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'packs.title': '主题包',
  'packs.default': '默认',
  'packs.empty': '尚未发现主题包。将含 theme.json 的文件夹放入主题目录后会自动出现。',
  'packs.hint': '选择已安装的主题包。外观中的浅色、深色或跟随系统会退出主题包。',
} satisfies Record<string, string>

/** The settings.theme-packs namespace key union. */
export type ThemePacksKey = keyof typeof zh

/** English dictionary, checked complete against the zh key set. */
export const en = {
  'packs.title': 'Theme packs',
  'packs.default': 'Default',
  'packs.empty': 'No theme packs yet. Folders that contain theme.json appear here automatically.',
  'packs.hint': 'Choose an installed pack. Light, Dark, or System under Appearance leaves the pack.',
} satisfies Record<ThemePacksKey, string>
