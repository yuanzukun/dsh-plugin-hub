/**
 * Theme-pack picker registered into the General section item slot, below
 * Appearance. Selection follows the live ThemeRuntime preference.
 */

import clsx from 'clsx'
import type { PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { createThemePacksRowStore } from './settings-store.ts'
import css from './ThemePacksRow.module.css'

/** Injected business face: pack selection (t rides the standard locale seat). */
export interface ThemePacksRowInjected {
  /** Activate a pack id, or `''` to return to the built-in Appearance preference. */
  selectPack: (id: string) => void
}

/** Full component props: runtime share + store share + locale seat + injected face. */
export type ThemePacksRowComponentProps =
  PropsRuntime<'settings.general.item'> & PropsStore<ReturnType<typeof createThemePacksRowStore>>
  & PropsLocale<'settings.theme-packs'> & ThemePacksRowInjected

/**
 * Render the theme-pack row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export function ThemePacksRow({ t, selectPack, useStore }: ThemePacksRowComponentProps) {
  const packs = useStore(s => s.packs)
  const preference = useStore(s => s.preference)
  const packSelected = packs.some(pack => pack.id === preference)
  return (
    <div className={css.group}>
      <div className={css.title}>{t('packs.title')}</div>
      <div className={css.hint}>{t('packs.hint')}</div>
      {packs.length === 0
        ? <div className={css.empty}>{t('packs.empty')}</div>
        : (
            <div className={css.cubeRow}>
              <button
                type="button"
                className={clsx(css.themeCube, !packSelected && css.selected)}
                aria-pressed={!packSelected}
                onClick={() => { selectPack('') }}
              >
                <span className={css.swatch} />
                {t('packs.default')}
              </button>
              {packs.map(pack => (
                <button
                  key={pack.id}
                  type="button"
                  className={clsx(css.themeCube, preference === pack.id && css.selected)}
                  aria-pressed={preference === pack.id}
                  title={pack.description}
                  onClick={() => { selectPack(pack.id) }}
                >
                  {pack.previewUrl === undefined
                    ? <span className={css.swatch} />
                    : <img className={css.preview} src={pack.previewUrl} alt="" />}
                  {pack.name}
                </button>
              ))}
            </div>
          )}
    </div>
  )
}
