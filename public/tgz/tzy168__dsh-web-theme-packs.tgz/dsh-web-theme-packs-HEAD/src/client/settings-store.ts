/**
 * Theme-pack settings row store: catalog summaries plus the live preference
 * used for selection. The apply-world change listener is the only writer.
 */

import { defineStore, type EngineStoreHandle } from '@deepseek-ai/dsh-client-runtime/client'

/** One pack as shown in the settings row. */
export interface ThemePackSummary {
  /** ThemeRuntime id. */
  id: string
  /** Visible name. */
  name: string
  /** Optional one-line description. */
  description?: string
  /** Optional preview image URL. */
  previewUrl?: string
}

/** Store state mirrored from the catalog and theme snapshot. */
export interface ThemePacksRowState {
  /** Discovered packs in catalog order. */
  packs: readonly ThemePackSummary[]
  /** Live ThemeRuntime preference (built-in or pack id). */
  preference: string
  /** Catalog revision; -1 until the first sync. */
  revision: number
}

/** Declared action shape giving the exported factory a stable return type. */
type ThemePacksRowActions = {
  sync: (
    draft: ThemePacksRowState,
    packs: readonly ThemePackSummary[],
    preference: string,
    revision: number,
  ) => void
}

/**
 * Declares the theme-pack row state and write surface.
 * @returns the store handle.
 */
export function createThemePacksRowStore(): EngineStoreHandle<ThemePacksRowState, ThemePacksRowActions> {
  return defineStore({
    init: (): ThemePacksRowState => ({ packs: [], preference: 'system', revision: -1 }),
    actions: {
      sync: (d, packs, preference, revision) => {
        if (revision < d.revision) return
        d.packs = packs
        d.preference = preference
        d.revision = revision
      },
    },
  })
}
