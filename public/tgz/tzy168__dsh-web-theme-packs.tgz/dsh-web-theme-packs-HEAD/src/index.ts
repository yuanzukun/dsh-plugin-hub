/**
 * Host half: scan theme-pack folders, serve their catalog and assets, persist
 * the selected pack id, and watch drop-in directories for rescans.
 */

import { mkdirSync, watch } from 'node:fs'
import type { FSWatcher } from 'node:fs'
import { dirname, isAbsolute, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { dshHomePath } from '@deepseek-ai/dsh-home-paths'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { scanThemePacks } from './scan.ts'
import {
  broadcastCatalogRevision, handleThemePackRequest, type ThemePackHttpState,
} from './serve.ts'
import { THEME_PACKS_SETTINGS_NS, ThemePacksSettingsSchema } from './settings.ts'

/** Stable Cordis plugin name. */
export const name = 'web-theme-packs'

/** Plugin configuration supplied through cordis.yml. */
export interface Config {
  /**
   * Absolute directories scanned for pack folders. An empty list uses the
   * bundled `themes/` directory plus `$DSH_HOME/theme-packs` (created if missing).
   */
  roots: string[]
  /** HTTP pathname prefix for catalog, SSE, and assets; no trailing slash. */
  routePrefix: string
}

/** Configuration schema; empty `roots` selects the default pair of directories. */
export const Config: z<Config> = z.object({
  roots: z.array(z.string()).default([]),
  routePrefix: z.string().default('/dsh-theme-packs'),
})

const PACKAGE_ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const BUNDLED_THEMES = join(PACKAGE_ROOT, 'themes')
const USER_THEMES_SEGMENT = 'theme-packs'
const WATCH_DEBOUNCE_MS = 200

/**
 * Register the settings namespace, scan packs, serve them, and watch roots.
 * @param ctx - Host context; `settings` and `webServer` attach when composed.
 * @param config - validated {@link Config}.
 */
export function apply(ctx: Context, config: Config): void {
  ctx.inject(['settings'], (settingsCtx) => {
    settingsCtx.settings.register(THEME_PACKS_SETTINGS_NS, ThemePacksSettingsSchema)
  })
  ctx.inject(['webServer'], (httpCtx) => {
    const roots = resolveRoots(config.roots)
    const prefix = normalizePrefix(config.routePrefix)
    const state: ThemePackHttpState = {
      prefix,
      revision: 0,
      packs: [],
      listeners: new Set(),
    }
    const rescan = (): void => {
      state.packs = scanThemePacks(roots, prefix, httpCtx.logger)
      state.revision += 1
      broadcastCatalogRevision(state)
    }
    rescan()
    httpCtx.effect(
      () => httpCtx.webServer.register({
        kind: 'prefix',
        path: prefix,
        handler: (req, res) => { handleThemePackRequest(state, req, res) },
      }),
      'web-theme-packs: asset route',
    )
    const watchers: FSWatcher[] = []
    let debounce: ReturnType<typeof setTimeout> | undefined
    const schedule = (): void => {
      if (debounce !== undefined) clearTimeout(debounce)
      debounce = setTimeout(() => {
        debounce = undefined
        rescan()
      }, WATCH_DEBOUNCE_MS)
    }
    for (const root of roots) {
      try {
        watchers.push(watch(root, { recursive: true }, schedule))
      } catch (error) {
        httpCtx.logger.warn(
          `theme-packs: not watching "${root}": ${error instanceof Error ? error.message : String(error)}`,
        )
      }
    }
    httpCtx.effect(() => () => {
      if (debounce !== undefined) clearTimeout(debounce)
      for (const watcher of watchers) watcher.close()
      for (const res of state.listeners) res.end()
      state.listeners.clear()
    }, 'web-theme-packs: root watches')
  })
}

function resolveRoots(configured: readonly string[]): string[] {
  if (configured.length > 0) {
    return configured.map(root => (isAbsolute(root) ? root : join(PACKAGE_ROOT, root)))
  }
  const userRoot = dshHomePath(USER_THEMES_SEGMENT)
  mkdirSync(userRoot, { recursive: true })
  return [BUNDLED_THEMES, userRoot]
}

function normalizePrefix(prefix: string): string {
  if (!prefix.startsWith('/') || prefix === '/' || prefix.endsWith('/')) {
    throw new Error('theme-packs: routePrefix must start with "/", must not be "/", and must not end with "/"')
  }
  return prefix
}
