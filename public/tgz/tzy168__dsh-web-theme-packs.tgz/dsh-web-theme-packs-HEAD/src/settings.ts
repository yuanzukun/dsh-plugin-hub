/** Host schema for the selected-pack settings section. */

import z from '@deepseek-ai/schemastery'
import { settingsNamespace } from '@deepseek-ai/dsh-settings'
import {
  THEME_PACKS_ACTIVE_FIELD, THEME_PACKS_NAMESPACE, type ThemePacksSettings,
} from './settings-contract.ts'

export {
  THEME_PACKS_ACTIVE_FIELD, THEME_PACKS_NAMESPACE, type ThemePacksSettings,
} from './settings-contract.ts'

/** Schema for the Host settings document and the browser scope. */
export const ThemePacksSettingsSchema: z<ThemePacksSettings> = z.object({
  [THEME_PACKS_ACTIVE_FIELD]: z.string().default(''),
})

/** Branded namespace passed to `settings.register`. */
export const THEME_PACKS_SETTINGS_NS = settingsNamespace(THEME_PACKS_NAMESPACE)
