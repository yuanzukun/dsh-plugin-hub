/**
 * Dual-face build: Node apply from `src/index.ts`, browser bundle from
 * `src/client/index.ts`. Uses the harness client-bundle preset so the
 * ModuleLoader banner, CSS Modules, and purity gate match in-tree plugins.
 * When this folder becomes its own repository, copy `packages/client/tsdown.client.ts`
 * (or the turtle-ui prepare config) beside this file and point the import here.
 */
import { clientBundle } from '../packages/client/tsdown.client.ts'

export default clientBundle(
  'dsh-web-theme-packs',
  ['src/index.ts'],
)
