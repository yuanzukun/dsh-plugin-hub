# AGENTS.md — Web theme packs

Out-of-tree optional Web plugin: drop-in folders of tokens, extra CSS, fonts, and images, registered through [`ThemeRuntime`](../packages/client/ui-theme/README.md) so the existing layout presenter applies `--dsw-*` aliases. Pack format, install, and config live in [README.md](README.md); client slot/props rules live in [packages/client/AGENTS.md](../packages/client/AGENTS.md); token ownership lives in [docs/web-styling.md](../docs/web-styling.md).

This directory is a standalone bundle that will move to its own repository. Do not add it to `packages/bundle/web-app` or any shipped roster; users attach it with `dsh plugin --profile web add`.

## What a pack may do

A DSH pack overrides semantic tokens and may add CSS/assets on the three-column Web client. It cannot replace React icon components, window chrome, or column layout. Do not grow this plugin into that format.

Pack JSON and CSS are data. The loader never evaluates JavaScript from a pack. Do not add a script field or import a pack module.

A broken drop-in folder is skipped with a warning; the rest of the catalog still loads. Do not fail Host apply because one `theme.json` is invalid. Pack `id` must not be `light`, `dark`, or `system`.

## Persistence

Pack selection is this plugin's `theme-packs.active` field. Custom ids stay outside `ui-theme.preference`. Choosing Light / Dark / System under Appearance clears `active`; removing the plugin drops the pack selection without rewriting the last Appearance preference.

## Host and client halves

`src/index.ts` is the Host apply: scan roots, register the settings schema, serve `{prefix}/catalog.json`, `{prefix}/events` (SSE), rewritten `{prefix}/{id}/theme.css`, and pack files, and watch roots. `src/client/index.ts` is the browser apply: fetch the catalog, `theme.register` each pack's tokens, inject fonts/extra CSS/`body[data-dsh-theme-pack]` only while that pack is the live preference, and contribute the General-section picker.

Asset paths in a pack are pack-relative: no `..`, no absolute paths, no NUL or backslash. The HTTP handler must refuse any resolved path that leaves the pack directory. Relative `url(...)` values are rewritten to `{prefix}/{id}/...`; absolute, `data:`, and `blob:` URLs stay unchanged.

An empty `roots` list scans bundled `themes/` then `$DSH_HOME/theme-packs`. Later roots win on duplicate ids. `routePrefix` must start with `/`, must not be `/`, and must not end with `/`.

Partial token maps are valid; unspecified aliases keep the built-in sheet. Do not completeness-check third-party token sets. Extra CSS may target `body[data-dsh-theme-pack="<id>"]` only. Inspect live names with `theme.exportInspectTokens` or [`design-platform.css`](../packages/client/ui-theme/src/styles/design-platform.css).

## Client UI

Compose the picker through `ctx.slots.inject('settings.general.item', ...)`. Components never see `ctx`; they read the four props shares and write only through injected callbacks. The apply-world `theme/change` listener is the only store writer.

Picker styles are a CSS Module using `--dsw-alias-*` tokens. Product copy is Chinese (`src/client/locales.ts` `zh` is the key-set source); comments are English. The `/client` entry exports only what cordis loading needs (`apply` / `inject`) plus types the slot component requires; tests import internals with relative paths.

## Build and checks

`tsdown.config.ts` uses the in-tree `clientBundle` helper so the ModuleLoader banner, CSS Modules, and purity gate match shipped client plugins. Rebuild `lib/` before probing a live `dsh web`; the registry serves `lib/`, not sources. When this folder becomes its own repository, copy `packages/client/tsdown.client.ts` beside that config.

Tests live in `tests/`. Client specs use `// @vitest-environment jsdom`. Nothing here reaches a model request.
