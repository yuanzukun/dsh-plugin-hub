/**
 * Office preview: renderers for Word / PPT / Excel. Word, PPT and editable
 * .xlsx files are served as self-contained HTML by the host-side OfficeCLI
 * binary and embedded in an iframe (read-only; `officecli view <file> html`
 * renders original styling — fills, date/currency formats, merges — faithfully).
 * Legacy xls/ods stay read-only HTML tables decoded with SheetJS. Streamed tabs
 * carry the /filemgr/raw route URL in `content`; the bytes are fetched once and
 * handed to the renderer. Any render error degrades to the download hint.
 * @module dsh-filemgr/client/preview/office
 */
import { type ReactElement } from 'react';
import type { PreviewTabState } from '../store.ts';
/**
 * Dispatch an office tab to its format renderer. `content` is the streamed
 * raw-route URL; the bytes arrive before the renderer mounts, so each child
 * sees a complete file.
 */
export declare function OfficeViewer({ tab, onInsertSheetReference }: {
    tab: PreviewTabState;
    /** Insert a 文件!Sheet!Range reference chip into the composer. */
    onInsertSheetReference: (path: string, sheetName: string, range: string) => boolean;
}): ReactElement;
//# sourceMappingURL=office.d.ts.map