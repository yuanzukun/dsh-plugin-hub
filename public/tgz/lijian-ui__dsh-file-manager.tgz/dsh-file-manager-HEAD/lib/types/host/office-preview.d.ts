/**
 * /filemgr/office-preview: render Office documents (docx/pptx) to HTML via
 * the installed officecli binary (server-side rendering with Microsoft Open XML SDK).
 * The result is a self-contained HTML with base64 images, suitable for iframe embedding.
 *
 * This provides higher fidelity rendering than pure JS client-side libraries for
 * complex PPTX documents (charts, 3D models, animations, advanced formatting).
 * @module dsh-filemgr/host/office-preview
 */
import type { Context } from '@deepseek-ai/cordis';
/** Register the /filemgr/office-preview route on the web server. */
export declare function registerOfficePreviewRoute(ctx: Context): () => void;
//# sourceMappingURL=office-preview.d.ts.map