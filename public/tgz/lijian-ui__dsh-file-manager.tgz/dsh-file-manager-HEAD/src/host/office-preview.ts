/**
 * /filemgr/office-preview: render Office documents (docx/pptx) to HTML via
 * the installed officecli binary (server-side rendering with Microsoft Open XML SDK).
 * The result is a self-contained HTML with base64 images, suitable for iframe embedding.
 *
 * This provides higher fidelity rendering than pure JS client-side libraries for
 * complex PPTX documents (charts, 3D models, animations, advanced formatting).
 * @module dsh-filemgr/host/office-preview
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import { stat } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { Context } from '@deepseek-ai/cordis'
import type { WebServer } from '@deepseek-ai/dsh-host-webserver'
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess'
import { isLoopbackRequest } from './loopback.ts'
import type { PanelError } from '../core/types.ts'

const OK = (value: unknown): string => JSON.stringify({ ok: true, value })
const FAIL = (error: PanelError): string => JSON.stringify({ ok: false, error })

/**
 * Check if officecli is available.
 * In production (packaged) the binary is bundled via electron-builder extraResources
 * and injected into PATH by dsh-process.ts addOfficecliPath().
 * In development we check the vendor/officecli/ directory first, then fall back to PATH.
 * Cached to avoid repeated probing.
 */
let officecliAvailable: boolean | null = null
let officecliPath: string | null = null

function resolveBundledOfficecli(): string | null {
  const isWin = process.platform === 'win32'
  const binName = isWin ? 'officecli.exe' : 'officecli'
  const os = process.platform === 'win32' ? 'win' : process.platform === 'darwin' ? 'mac' : 'linux'
  const arch = process.arch === 'arm64' ? 'arm64' : 'x64'

  // Check vendor/officecli/<os>-<arch>/ (development mode)
  // lib/index.js is at extensions/dsh-file-manager/lib/index.js → project root is ../../..
  try {
    const dirname = fileURLToPath(new URL('.', import.meta.url))
    const vendorPath = join(dirname, '..', '..', '..', 'vendor', 'officecli', `${os}-${arch}`, binName)
    if (existsSync(vendorPath)) return vendorPath
  } catch {
    // import.meta.url not available (rare edge case)
  }

  return null
}

async function probeOfficecli(ctx: Context): Promise<boolean> {
  if (officecliAvailable !== null) return officecliAvailable

  // 1. Check bundled path first (works in both dev and production)
  const bundled = resolveBundledOfficecli()
  if (bundled !== null) {
    officecliPath = bundled
    officecliAvailable = true
    ctx.logger.info(`[dsh-filemgr] officecli found at ${bundled}, OfficeCLI preview enabled`)
    return true
  }

  // 2. Fall back to PATH
  const subprocess = ctx.get('subprocess') as SubprocessRuntime
  try {
    const handle = subprocess.spawn({
      argv: ['officecli', '--version'],
      cwd: process.cwd(),
      stdio: {
        stdin: 'ignore',
        stdout: { maxBytes: 1024 },
        stderr: { maxBytes: 1024 },
      },
      graceMs: 5000,
    })
    const outcome = await handle.done
    officecliAvailable = outcome.exitCode === 0
    if (officecliAvailable) {
      officecliPath = 'officecli'
      ctx.logger.info('[dsh-filemgr] officecli found on PATH, OfficeCLI preview enabled')
    } else {
      ctx.logger.warn('[dsh-filemgr] officecli not available, OfficeCLI preview disabled')
    }
  } catch {
    officecliAvailable = false
    ctx.logger.warn('[dsh-filemgr] officecli probe failed, OfficeCLI preview disabled')
  }
  return officecliAvailable
}

/** Write JSON response. */
function json(res: ServerResponse, status: number, body: string): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-cache' })
  res.end(body)
}

/** Write HTML response. */
function html(res: ServerResponse, body: string): void {
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache' })
  res.end(body)
}

/**
 * Inject a bootstrap that turns OfficeCLI's full-document HTML into a single-
 * slide browse view that KEEPS the thumbnail sidebar. OfficeCLI ships a
 * fullscreen engine (`enterFullscreen()` + ←/→/space + thumbnail jumps) but its
 * `.fullscreen` CSS hides the sidebar (pure presentation mode) — so we:
 *   1. auto-enter fullscreen after first paint (single page at a time), and
 *   2. override the fullscreen CSS to restore the sidebar and shrink `.main`
 *      so the thumbnail column stays clickable for page jumps.
 */
/**
 * Injected frame/patch add-ons on top of the raw OfficeCLI HTML.
 *
 * OfficeCLI colours its chrome (body, sidebar, borders, counter) with hard-coded
 * dark values and does not follow the dsh light/dark theme. The preview is
 * rendered inside an isolated blob iframe, so the outer document's
 * `body[data-ds-dark-theme]` token is NOT visible here — the host sends the
 * current theme via postMessage and we react by toggling a data attribute that
 * this stylesheet consumes.
 *
 * The slide artwork itself (`.slide`, `.thumb-slide`, `--slide-*`) is authored
 * by the deck and intentionally left untouched.
 */
function injectSlideShowMode(htmlContent: string): string {
  const patch = `
<style data-dsh-officecli-fullscreen>
/* Restore the thumbnail sidebar in single-slide (fullscreen) mode and give the
   slide stage a wider initial viewport by narrowing the sidebar. */
body.fullscreen .sidebar { display: flex; width: 140px; min-width: 140px; }
body.fullscreen .main { width: calc(100vw - 140px); }
body.fullscreen .slide-container { width: 100%; }
/* Scale the single slide down so it fits within the stage without being clipped.
   Using zoom (not transform) because zoom changes both rendering AND layout size,
   so the parent container adapts naturally. transform:scale() only changes visual
   size but keeps the original layout footprint, causing overflow clipping. */
body.fullscreen .slide {
  zoom: 0.85;
}

/* Light-theme chrome (host sends theme via postMessage; default stays dark). */
body[data-dsh-theme="light"] { background: #f7f7f8; }
body[data-dsh-theme="light"] .sidebar {
  background: #eef0f3;
  border-right: 1px solid rgba(0,0,0,0.09);
}
body[data-dsh-theme="light"] .sidebar-title,
body[data-dsh-theme="light"] .thumb-num,
body[data-dsh-theme="light"] .sidebar-toggle { color: #5f6368; }
body[data-dsh-theme="light"] .thumb:hover { border-color: #b9bdc6; }
body[data-dsh-theme="light"] .page-counter { background: rgba(0,0,0,0.55); color: #f1f3f4; }
</style>
<script data-dsh-officecli-fullscreen>
(function () {
  // --- single-slide browsing mode (F) ---
  function boot() {
    // Only decks carry the fullscreen machinery; skip docs/sheets.
    if (!document.querySelector('.main .slide-container')) return;
    if (document.body.classList.contains('fullscreen')) return;
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'F', code: 'KeyF', bubbles: true }));
  }
  function onReady(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once: true });
    else fn();
  }
  onReady(boot);

  // --- follow the host light/dark theme via postMessage (blob iframe isolation) ---
  window.addEventListener('message', function (event) {
    if (!event.data || event.data.source !== 'dsh-filemgr' || event.data.type !== 'dsh-theme') return;
    document.body.setAttribute('data-dsh-theme', event.data.dark ? 'dark' : 'light');
  });
})();
</script>
<style data-dsh-officecli-sheet>
  .dsh-sheet-selected { outline: 1px solid #2e7df6 !important; outline-offset: -1px; background: rgba(46, 125, 246, 0.12) !important; }
</style>
<script data-dsh-officecli-sheet-select>
(function () {
  // Excel selection -> host reference. OfficeCLI annotates every cell with
  // data-path="/<sheet>/<A1>" (column headers use col[A], row headers row[1]).
  // Some renderers set user-select:none, so a native text selection cannot span
  // cells; instead we track a pointer drag ourselves (cell under pointerdown ->
  // cell under the pointer), highlight the bounding rectangle, and postMessage
  // the sheet + A1 range up. The host turns that into a "引用到对话" chip
  // (相对路径!Sheet!Range). Docs/slides have no .sheet-content, so this block
  // is inert for Word/PPT.
  var MAX_HIGHLIGHT_CELLS = 4000;
  function isSheetDoc() { return !!document.querySelector('.sheet-content'); }
  function colToNum(letters) {
    var n = 0;
    for (var i = 0; i < letters.length; i++) n = n * 26 + (letters.charCodeAt(i) - 64);
    return n;
  }
  function numToCol(n) {
    var s = '';
    while (n > 0) { var r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = (n - r - 1) / 26 | 0; }
    return s;
  }
  function parsePath(el) {
    var p = el && el.getAttribute && el.getAttribute('data-path'); if (!p) return null;
    var parts = p.split('/'); // ['', sheet, ref]
    if (parts.length < 3) return null;
    var m = /^([A-Z]+)([0-9]+)$/.exec(parts[2]); if (!m) return null;
    return { sheet: parts[1], col: colToNum(m[1]), row: +m[2] };
  }
  // Walk from a DOM node up to the nearest data cell (or null).
  function pickCell(node) {
    var el = node;
    while (el && el !== document) {
      if (el.nodeType === 1 && el.hasAttribute('data-path')) {
        var p = parsePath(el); if (p) return p;
      }
      el = el.parentElement;
    }
    return null;
  }
  function clearHighlight() {
    var els = document.querySelectorAll('.dsh-sheet-selected');
    for (var i = 0; i < els.length; i++) els[i].classList.remove('dsh-sheet-selected');
  }
  function applyHighlight(r) {
    clearHighlight();
    if (!r) return;
    if ((r.c2 - r.c1 + 1) * (r.r2 - r.r1 + 1) > MAX_HIGHLIGHT_CELLS) return; // skip huge ranges
    var els = document.querySelectorAll('td[data-path], th[data-path]');
    for (var i = 0; i < els.length; i++) {
      var p = parsePath(els[i]);
      if (p && p.sheet === r.sheet && p.row >= r.r1 && p.row <= r.r2 && p.col >= r.c1 && p.col <= r.c2) {
        els[i].classList.add('dsh-sheet-selected');
      }
    }
  }
  function send(payload) {
    parent.postMessage(Object.assign({ source: 'dsh-filemgr', type: 'dsh-sheet-select' }, payload), '*');
  }
  function update(from, to) {
    var refs = [from, to].filter(Boolean);
    if (!refs.length) { send({ sheet: null, range: null, x: 0, y: 0 }); applyHighlight(null); return; }
    if (refs[0].sheet !== (refs[1] ? refs[1].sheet : refs[0].sheet)) { send({ sheet: null, range: null, x: 0, y: 0 }); applyHighlight(null); return; }
    var sheet = refs[0].sheet;
    var c1 = 1e9, c2 = 0, r1 = 1e9, r2 = 0;
    refs.forEach(function (p) { c1 = Math.min(c1, p.col); c2 = Math.max(c2, p.col); r1 = Math.min(r1, p.row); r2 = Math.max(r2, p.row); });
    var corner = numToCol(c1) + r1, corner2 = numToCol(c2) + r2;
    var range = corner === corner2 ? corner : corner + ':' + corner2;
    var anchorEl = to ? findCellEl(sheet, refs[1].col, refs[1].row) : findCellEl(sheet, from.col, from.row);
    var rect = anchorEl ? anchorEl.getBoundingClientRect() : null;
    applyHighlight({ sheet: sheet, c1: c1, c2: c2, r1: r1, r2: r2 });
    send({ sheet: sheet, range: range, x: rect ? rect.left : 0, y: rect ? rect.bottom + 6 : 0 });
  }
  function findCellEl(sheet, col, row) {
    var els = document.querySelectorAll('td[data-path], th[data-path]');
    for (var i = 0; i < els.length; i++) {
      var p = parsePath(els[i]);
      if (p && p.sheet === sheet && p.col === col && p.row === row) return els[i];
    }
    return null;
  }
  var origin = null, dragging = false;
  document.addEventListener('pointerdown', function (e) {
    if (!isSheetDoc()) return;
    var p = pickCell(e.target);
    if (!p) return; // corner / header / outside — leave selection as-is
    dragging = true; origin = p; update(p, p);
  }, true);
  document.addEventListener('pointermove', function (e) {
    if (!dragging || !origin) return;
    var cur = pickCell(document.elementFromPoint(e.clientX, e.clientY));
    if (cur) update(origin, cur);
  }, true);
  window.addEventListener('pointerup', function () {
    if (!dragging) return;
    dragging = false; origin = null;
  }, true);
})();
</script>
</body>`
  return htmlContent.replace('</body>', patch)
}

/** Forbidden (non-loopback request). */
function writeForbidden(res: ServerResponse): void {
  json(res, 403, FAIL({ code: 'internal', message: 'forbidden: loopback-only' }))
}

/**
 * Handle one GET /filemgr/office-preview request.
 * Query params: root=workspace/root&path=relative/to/root/file.pptx, probe=1 for mtime check.
 * Uses the same root+path convention as /filemgr/raw.
 */
async function handleOfficePreview(
  ctx: Context,
  req: IncomingMessage,
  res: ServerResponse,
): Promise<void> {
  if (!isLoopbackRequest(req)) {
    writeForbidden(res)
    return
  }

  const url = new URL(req.url ?? '/', 'http://x')
  const root = url.searchParams.get('root')
  const path = url.searchParams.get('path')

  if (root === null || root === '' || path === null || path === '') {
    json(res, 400, FAIL({ code: 'internal', message: 'missing root or path parameter' }))
    return
  }

  // Resolve absolute path: root + path
  const absPath = join(root, path)

  // Cheap mtime probe for auto-reload (client polling)
  if (url.searchParams.get('probe') === '1') {
    try {
      const info = await stat(absPath)
      json(res, 200, OK({ mtime: info.mtimeMs }))
    } catch {
      json(res, 404, FAIL({ code: 'not-found', message: 'file not found' }))
    }
    return
  }

  // Check if officecli is available
  const available = await probeOfficecli(ctx)
  if (!available || officecliPath === null) {
    json(res, 501, FAIL({ code: 'internal', message: 'officecli not installed or not on PATH' }))
    return
  }

  const subprocess = ctx.get('subprocess') as SubprocessRuntime
  let timeoutMs = 60000 // 60s timeout for rendering

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    // officecli view <file> html → outputs raw HTML to stdout
    const handle = subprocess.spawn({
      argv: [officecliPath, 'view', absPath, 'html'],
      cwd: process.cwd(),
      stdio: {
        stdin: 'ignore',
        stdout: { maxBytes: 10 * 1024 * 1024 }, // 10MB max HTML
        stderr: { maxBytes: 1 << 20 },
      },
      graceMs: 5000,
      signal: controller.signal,
    })

    const outcome = await handle.done
    clearTimeout(timer)

    if (controller.signal.aborted) {
      json(res, 504, FAIL({ code: 'internal', message: 'officecli rendering timed out after 60s' }))
      return
    }

    // collected.stdout/stderr are SubprocessOutputReader — read from offset 0.
    const readStdout = (): string =>
      (handle as { collected?: { stdout?: { readFrom: (n: number) => { text: string } } } }).collected?.stdout?.readFrom(0).text ?? ''
    const readStderr = (): string =>
      (handle as { collected?: { stderr?: { readFrom: (n: number) => { text: string } } } }).collected?.stderr?.readFrom(0).text ?? ''

    if (outcome.exitCode !== 0) {
      const stderr = readStderr()
      const stdout = readStdout()
      const error = `officecli exited with code ${String(outcome.exitCode)}\n${stderr}\n${stdout}`.slice(0, 1000)
      json(res, 422, FAIL({ code: 'read-failed', message: error.trim() }))
      return
    }

    const htmlContent = readStdout()
    if (htmlContent === '') {
      json(res, 422, FAIL({ code: 'read-failed', message: 'officecli returned empty output' }))
      return
    }
    html(res, injectSlideShowMode(htmlContent))
  } catch (error) {
    clearTimeout(timer)
    const msg = error instanceof Error ? error.message : String(error)
    json(res, 500, FAIL({ code: 'internal', message: `officecli invocation failed: ${msg}` }))
  }
}

/** Register the /filemgr/office-preview route on the web server. */
export function registerOfficePreviewRoute(ctx: Context): () => void {
  // Probe officecli availability eagerly on route registration
  void probeOfficecli(ctx)

  return ctx.webServer.register({
    kind: 'prefix',
    path: '/filemgr/office-preview',
    handler: (req, res) => handleOfficePreview(ctx, req, res),
  })
}
