# dsh-sticky-notes — 便签（DSH Web 客户端插件）
[English](./README.en.md) | 中文

记下想法，让agent落盘！

<p align="center">
  <img src="assets/cover.png" alt="dsh-sticky-notes 封面" width="720">
</p>

浮在 DeepSeek Harness WebUI 上的便签，随手记录文字、待办和图片。可自由拖拽、缩放、折叠、归档。支持**绑定到会话**，打开对应会话，会自动显示相关便签。

## 功能预览

<p align="center">
  <img src="assets/001.png" alt="功能截图 1" width="360">
  <img src="assets/002.png" alt="功能截图 2" width="360">
  <img src="assets/003.png" alt="功能截图 3" width="360">
</p>

## 安装

```sh
# 从 GitHub 安装（无需构建授权，纯 JS）
dsh plugin --profile web add github:hufang360/dsh-sticky-notes
```

首次安装，需要重启dsh才能生效。如未提示重启，请**硬刷新浏览器**（macOS `Cmd+Shift+R`）。便签入口出现在侧边栏底部、设置按钮上方。

> 本包是标准 dsh bundle：自带 `cordis.patch.yml`（声明 `dsh.bundle`），`dsh plugin add` 一条命令即可完成依赖 + 层注册。

## 数据与存储

- 便签、偏好与设置存于浏览器 `localStorage`：
  - `dsh.web.sticky-notes.v5.notes`（便签数组）
  - `dsh.web.sticky-notes.v5.prefs`（hidden / entryPos）
  - `dsh.web.sticky-notes.v5.settings`（设置面板过滤）
- 图片以压缩后的 DataURL 存储。
- 数据仅在浏览器本地，不同设备 / 浏览器之间不同步。

> 注意：更换webui端口，或访问地址从 localhost:3080 和 127.0.0.1:3080 将看不到以前的数据，因为他们是单独记录的


## 开发与打包

```sh
node --check lib/client.js   # 语法检查
git commit -am "..."         # 常规提交
pnpm pack                    # 产出 sticky-notes-<version>.tgz
npm publish                  # （可选）发布到 npm
```

- `lib/client.js` — 唯一逻辑文件（浏览器 bundle）。
- `lib/index.js` — host 侧 no-op 入口。
- `cordis.patch.yml` — bundle 的 patch 层（注册 `sticky-notes` 插件行）。

## License

MIT