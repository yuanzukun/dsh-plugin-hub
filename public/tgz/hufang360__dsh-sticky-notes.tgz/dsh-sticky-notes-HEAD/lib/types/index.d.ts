/**
 * Type declarations for the sticky-notes dsh web client bundle.
 * The host-side entry (`lib/index.js`) provides no host behavior.
 */
export declare function apply(): void;