import { describe, it, expect } from 'vitest'
import { countTokens, prefixWithinBudget } from '../src/chunker/tokens.ts'

describe('token counter (bge 近似)', () => {
  it('CJK 一字一 token', () => {
    expect(countTokens('知识库')).toBe(3)
    expect(countTokens('检索增强生成')).toBe(6)
  })
  it('ASCII 单词一 token', () => {
    expect(countTokens('hello world')).toBe(2)
    expect(countTokens('deepseek-harness')).toBeGreaterThanOrEqual(2)
  })
  it('中英混合', () => {
    expect(countTokens('用 vector 检索')).toBe(4) // 用(1) vector(1) 检(1) 索(1)
  })
  it('空白不计', () => {
    expect(countTokens('  a \n b\tc ')).toBe(3)
  })
  it('prefixWithinBudget 不超预算', () => {
    const text = '一二三四五六七八九十'
    const cut = prefixWithinBudget(text, 4)
    expect(countTokens(text.slice(0, cut))).toBeLessThanOrEqual(4)
    expect(cut).toBeGreaterThan(0)
  })
  it('空文本 0', () => {
    expect(countTokens('')).toBe(0)
    expect(prefixWithinBudget('', 10)).toBe(0)
  })
})
