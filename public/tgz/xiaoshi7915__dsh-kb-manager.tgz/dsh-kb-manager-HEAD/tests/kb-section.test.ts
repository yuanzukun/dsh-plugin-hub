/**
 * KbSection 组件测试（react-test-renderer，node 环境）。
 *
 * 用假 `remote.kbManager` 句柄驱动真实组件，覆盖：
 * 列表 / 空态 / 错误态、详情（stats + 文档表）、搜索（有/无结果）、
 * 建库表单、KB 两步删除、文档删除提示、导入 → job 横幅 → 轮询到 done。
 *
 * 组件使用 window.setTimeout / window.setInterval，这里用 no-op 仿真
 * 注入（记录 interval 回调以便手动推进轮询，不引入真实定时器）。
 */
import { describe, it, expect, beforeAll, afterEach } from 'vitest'
import React from 'react'
import { act, create, type ReactTestRenderer, type ReactTestInstance } from 'react-test-renderer'
import { KbSection } from '../src/web/KbSection.tsx'
import { zh } from '../src/web/locales.ts'
import type { KbLocaleKey } from '../src/web/locales.ts'
import type { KbRemoteApi } from '../src/remote-types.ts'
import type {
  Envelope,
  KbListItem,
  KbMeta,
  DocInfo,
  SearchResponse,
  Job,
} from '../src/contracts/types.ts'
import type { KbStats, DocListData } from '../src/remote-types.ts'

// ---------- window 仿真（no-op 定时器 + interval 回调收集） ----------

const intervalCbs: Array<() => void> = []

beforeAll(() => {
  const g = globalThis as Record<string, unknown>
  if (g.window === undefined) {
    g.window = {
      setTimeout: (_cb: () => void, _ms?: number): number => 0,
      clearTimeout: (_id: number): void => {},
      setInterval: (cb: () => void, _ms?: number): number => {
        intervalCbs.push(cb)
        return intervalCbs.length
      },
      clearInterval: (_id: number): void => {},
    }
  }
})

afterEach(() => {
  intervalCbs.length = 0
})

// ---------- 数据与句柄 ----------

const NOW = '2026-07-07T12:00:00.000Z'

const KB1: KbMeta = {
  kb_id: 'kb-1',
  name: '产品文档',
  description: '产品文档库',
  domain_tags: ['产品'],
  embedding: { model: 'bge-small-zh-v1.5', provider: 'onnx', dim: 512 },
  backend: 'sqlite-vec',
  status: 'ready',
  schema_version: 1,
  created_at: NOW,
  updated_at: NOW,
}

const KB_LIST: KbListItem[] = [
  { kb_id: 'kb-1', name: '产品文档', doc_count: 3, index_status: 'ready', last_updated: NOW },
  { kb_id: 'kb-2', name: '空库', doc_count: 0, index_status: 'empty', last_updated: NOW },
]

const STATS: KbStats = {
  doc_count: 3,
  chunk_count: 42,
  index_size_bytes: 20480,
  avg_chunk_tokens: 180,
  embedding: KB1.embedding,
  backend: 'sqlite-vec',
  deleted_ratio: 0,
}

const DOCS: DocInfo[] = [
  { doc_id: 'doc-1', file_name: 'a.md', source_type: 'md', source_key: 'p:a.md', content_hash: 'h1', status: 'ok', chunk_count: 10, size_bytes: 5000, metadata_json: '{}', imported_at: NOW, updated_at: NOW },
  { doc_id: 'doc-2', file_name: 'b.pdf', source_type: 'pdf', source_key: 'p:b.pdf', content_hash: 'h2', status: 'failed', chunk_count: 0, size_bytes: 900, metadata_json: '{}', imported_at: NOW, updated_at: NOW },
]

function searchResp(query: string, hits: SearchResponse['results']): SearchResponse {
  return {
    query,
    top_k: 5,
    results: hits,
    total_candidates: 12,
    total_hits: hits.length,
    rerank: 'applied',
    elapsed_ms: 12,
  }
}

const HIT = {
  chunk_id: 'c-1',
  score: 0.81,
  score_kind: 'rerank' as const,
  text: '命中片段',
  has_more: false,
  source_doc: 'a.md',
  page_num: null,
  heading_path: '介绍',
  untrusted: true as const,
}

const DONE_JOB: Job = {
  job_id: 'job-1',
  type: 'import',
  kb_id: 'kb-1',
  status: 'done',
  progress: { done: 1, total: 1, stage: 'indexing', stage_label: 'indexed' },
  created_at: NOW,
  started_at: NOW,
  finished_at: NOW,
}

type Rr<T> = {
  ok: true
  value: Envelope<T>
} | {
  ok: false
  error: { code: string; message: string; details: object }
}

function okR<T>(data: T): Rr<T> {
  return { ok: true, value: { ok: true, data } }
}
function errR<T>(code: string, message: string): Rr<T> {
  return { ok: true, value: { ok: false, error: { code, message } } }
}
function failR<T>(code: string, message: string): Rr<T> {
  return { ok: false, error: { code, message, details: {} } }
}

type Over = {
  list?: () => Promise<Rr<{ total: number; kbs: KbListItem[] }>>
  detail?: (kbId: string) => Promise<Rr<KbMeta>>
  stats?: (kbId: string) => Promise<Rr<KbStats>>
  docs?: (kbId: string) => Promise<Rr<DocListData>>
  search?: (kbId: string, query: string) => Promise<Rr<SearchResponse>>
  create?: (name: string, description?: string, tags?: string[]) => Promise<Rr<KbMeta>>
  importDoc?: (kbId: string, source: string) => Promise<Rr<{ job_id: string; status: 'queued' }>>
  deleteDoc?: (kbId: string, docId: string) => Promise<Rr<{ success: true; removed_chunks: number }>>
  job?: (jobId: string) => Promise<Rr<Job>>
  deleteKb?: (kbId: string, token?: string) => Promise<Rr<unknown>>
  rebuild?: (kbId: string) => Promise<Rr<{ job_id: string; status: 'queued' }>>
}

function mkApi(over: Over = {}, calls: string[] = []): KbRemoteApi {
  const base = {
    list: async () => okR({ total: KB_LIST.length, kbs: KB_LIST }),
    detail: async (kbId: string) =>
      okR(kbId === 'kb-new' ? { ...KB1, kb_id: 'kb-new', name: '新库', status: 'empty' as const } : KB1),
    stats: async () => okR(STATS),
    docs: async () => okR({ total: DOCS.length, docs: DOCS }),
    search: async (_kb: string, q: string) => okR(searchResp(q, [HIT])),
    create: async (name: string, description?: string, tags?: string[]) => {
      calls.push(`create:${name}:${description ?? ''}:${(tags ?? []).join('|')}`)
      return okR({ ...KB1, kb_id: 'kb-new', name, status: 'empty' as const })
    },
    importDoc: async () => okR({ job_id: 'job-1', status: 'queued' as const }),
    deleteDoc: async () => okR({ success: true as const, removed_chunks: 10 }),
    job: async () => okR(DONE_JOB),
    cancelJob: async (id: string) => okR({ job_id: id, status: 'cancelled' as const }),
    deleteKb: async (_kb: string, token?: string) =>
      token
        ? okR({ success: true as const, deleted_docs: 3, freed_bytes: 20480 })
        : okR({ requires_confirm: true as const, confirm_token: 'tk', impact: { docs: 3, chunks: 42, bytes: 20480 } }),
    rebuild: async () => okR({ job_id: 'job-r', status: 'queued' as const }),
    configure: async (patch: Record<string, unknown>) => okR({ updated: Object.keys(patch), restart_required: [] as string[] }),
  }
  const merged = { ...base, ...over } as unknown as Record<string, (...a: unknown[]) => Promise<unknown>>
  for (const [k, v] of Object.entries(over)) {
    merged[k] = (v as (...a: unknown[]) => Promise<unknown>).bind(null)
  }
  const wrapped = {} as Record<string, unknown>
  for (const [k, fn] of Object.entries(merged)) {
    wrapped[k] = async (...a: unknown[]) => {
      calls.push(`${k}:${a.slice(0, 2).join(',')}`)
      return (fn as (...a: unknown[]) => Promise<unknown>)(...a)
    }
  }
  return wrapped as unknown as KbRemoteApi
}

// ---------- 渲染工具 ----------

const t = (k: KbLocaleKey) => zh[k] ?? k

let root: ReactTestRenderer | null = null
afterEach(() => {
  if (root) {
    root.unmount()
    root = null
  }
})

function mount(api: KbRemoteApi): ReactTestRenderer {
  root = create(React.createElement(KbSection, { kb: () => api, t, close: () => {} }))
  return root
}

function textOf(inst: ReactTestInstance): string {
  let s = ''
  for (const c of inst.children) {
    if (typeof c === 'string') s += c
    else s += textOf(c)
  }
  return s
}

function fullText(r: ReactTestRenderer): string {
  return textOf(r.root)
}

function clickButton(r: ReactTestRenderer, label: string): void {
  const insts = r.root.findAll((n) => n.type === 'button')
  const hit = insts.find((b) => textOf(b).trim() === label)
  expect(hit, `button "${label}"`).toBeTruthy()
  act(() => {
    void (hit?.props.onClick as () => unknown)?.()
  })
}

function clickRow(r: ReactTestRenderer, name: string): void {
  const insts = r.root.findAll(
    (n) => n.type === 'div' && typeof n.props.onClick === 'function' && textOf(n).includes(name),
  )
  expect(insts[0], `kb row "${name}"`).toBeTruthy()
  act(() => {
    void (insts[0]!.props.onClick as () => unknown)()
  })
}

function setPlaceholderInput(r: ReactTestRenderer, placeholder: string, value: string): void {
  const inst = r.root.findAll((n) => n.type === 'input' && n.props.placeholder === placeholder)[0]
  expect(inst, `input placeholder "${placeholder}"`).toBeTruthy()
  act(() => {
    void (inst?.props.onChange as (e: { target: { value: string } }) => unknown)?.({ target: { value } })
  })
}

function inputs(r: ReactTestRenderer): ReactTestInstance[] {
  return r.root.findAll((n) => n.type === 'input')
}

/** 等待当前微任务 + effect 稳定（组件内部所有 await 的 promise 都是同步 resolve）。 */
async function settle(): Promise<void> {
  await act(async () => {})
}

/** 挂载组件并进入 '产品文档' 详情视图。 */
async function openDetail(over: Over = {}, calls: string[] = []): Promise<{ r: ReactTestRenderer; calls: string[] }> {
  const r = mount(mkApi(over, calls))
  await settle()
  clickRow(r, '产品文档')
  await settle()
  return { r, calls }
}

// ---------- 用例 ----------

describe('KbSection 列表视图', () => {
  it('渲染列表：标题 / 行数 / 文档数 / 状态徽标', async () => {
    const r = mount(mkApi())
    await settle()
    const text = fullText(r)
    expect(text).toContain('本地知识库')
    expect(text).toContain('文档导入、智能分块、向量索引与混合检索')
    expect(text).toContain('产品文档')
    expect(text).toContain('空库')
    expect(text).toContain('3 文档')
    expect(text).toContain('0 文档')
    expect(text).toContain('ready') // index_status 未收录词条 → 回退原值
    clickButton(r, '新建知识库')
    expect(fullText(r)).toContain('名称')
    expect(fullText(r)).toContain('领域标签，逗号分隔（可选）')
  })

  it('空列表显示 empty 文案', async () => {
    const r = mount(mkApi({ list: async () => okR({ total: 0, kbs: [] }) }))
    await settle()
    expect(fullText(r)).toContain('还没有知识库')
  })

  it('列表失败显示错误码与消息', async () => {
    const r = mount(mkApi({ list: () => Promise.resolve(errR('KB.LIST_FAILED', '磁盘故障')) }))
    await settle()
    const text = fullText(r)
    expect(text).toContain('出错')
    expect(text).toContain('KB.LIST_FAILED')
    expect(text).toContain('磁盘故障')
  })

  it('remote 层失败（ok:false）显示传输错误', async () => {
    const r = mount(mkApi({ list: () => Promise.resolve(failR('REMOter_TIMEOUT', '远程超时')) }))
    await settle()
    const text = fullText(r)
    expect(text).toContain('REMOter_TIMEOUT')
    expect(text).toContain('远程超时')
  })
})

describe('KbSection 详情视图', () => {
  it('点入详情：stats / 文档表 / 状态翻译 / 搜索输入框', async () => {
    const { r } = await openDetail()
    const text = fullText(r)
    expect(text).toContain('产品文档')
    expect(text).toContain('文档: 3')
    expect(text).toContain('分块: 42')
    expect(text).toContain('索引大小: 20.0 KB')
    expect(text).toContain('bge-small-zh-v1.5 / onnx / 512d')
    expect(text).toContain('a.md')
    expect(text).toContain('b.pdf')
    expect(text).toContain('正常')
    expect(text).toContain('失败')
    const searchInput = r.root.findAll((n) => n.type === 'input')[0]
    expect(searchInput?.props.placeholder).toBe('搜索这个知识库…')
    expect(fullText(r)).toContain('重建索引')
    expect(fullText(r)).toContain('删除知识库')
  })

  it('detail 传输失败 → 错误提示（flash）', async () => {
    const r = mount(mkApi({ detail: () => Promise.resolve(failR('REMOTE_TIMEOUT', '网关超时')) }))
    await settle()
    clickRow(r, '产品文档')
    await settle()
    const text = fullText(r)
    expect(text).toContain('REMOTE_TIMEOUT')
    expect(text).toContain('网关超时')
  })
})

describe('KbSection 搜索', () => {
  it('输入并搜索：渲染命中 / 分数 / 来源 / rerank 徽标', async () => {
    const { r } = await openDetail()
    setPlaceholderInput(r, '搜索这个知识库…', '混合检索')
    clickButton(r, '搜索')
    await settle()
    const text = fullText(r)
    expect(text).toContain('1 hits')
    expect(text).toContain('rerank')
    expect(text).toContain('12ms')
    expect(text).toContain('0.810')
    expect(text).toContain('a.md')
    expect(text).toContain('介绍')
    expect(text).toContain('命中片段')
  })

  it('无结果 → noResults 文案', async () => {
    const { r } = await openDetail({ search: async (_kb, q) => okR(searchResp(q, [])) })
    setPlaceholderInput(r, '搜索这个知识库…', '不存在')
    clickButton(r, '搜索')
    await settle()
    expect(fullText(r)).toContain('没有结果')
  })

  it('空查询时搜索按钮禁用', async () => {
    const { r } = await openDetail()
    const btn = r.root.findAll((n) => n.type === 'button' && textOf(n).trim() === '搜索')[0]
    expect(btn?.props.disabled).toBe(true)
  })
})

describe('KbSection 建库', () => {
  it('填表创建：参数传递 + 跳转详情 + 通知', async () => {
    const calls: string[] = []
    const r = mount(mkApi({}, calls))
    await settle()
    clickButton(r, '新建知识库')
    const ins = inputs(r)
    expect(ins).toHaveLength(3)
    act(() => void (ins[0]!.props.onChange as (e: { target: { value: string } }) => unknown)({ target: { value: '新库' } }))
    act(() => void (ins[1]!.props.onChange as (e: { target: { value: string } }) => unknown)({ target: { value: '测试描述' } }))
    act(() => void (ins[2]!.props.onChange as (e: { target: { value: string } }) => unknown)({ target: { value: 'a, b ,c' } }))
    const createBtn = r.root.findAll((n) => n.type === 'button' && textOf(n).trim() === '创建')[0]
    expect(createBtn?.props.disabled).toBe(false)
    await act(async () => {
      void (createBtn!.props.onClick as () => unknown)?.()
    })
    await settle()
    expect(calls).toContain('create:新库:测试描述:a|b|c')
    // openDetail('kb-new')：detail 返回 新库
    const text = fullText(r)
    expect(text).toContain('新库')
    expect(text).toContain('empty') // 状态回退原值
  })

  it('名称为空时创建按钮禁用', async () => {
    const r = mount(mkApi())
    await settle()
    clickButton(r, '新建知识库')
    const createBtn = r.root.findAll((n) => n.type === 'button' && textOf(n).trim() === '创建')[0]
    expect(createBtn?.props.disabled).toBe(true)
    clickButton(r, '返回')
  })
})

describe('KbSection 删除与导入', () => {
  it('KB 两步删除：pending 显示影响面 → 取消 → 再删 → 确认成功回列表', async () => {
    const calls: string[] = []
    const r = mount(mkApi({}, calls))
    await settle()
    clickRow(r, '产品文档')
    await settle()
    clickButton(r, '删除知识库')
    await settle()
    let text = fullText(r)
    expect(text).toContain('确定删除该知识库？全部文档与索引将被删除。')
    expect(text).toContain('3 篇文档、42 个分块、20.0 KB')
    // 取消
    clickButton(r, '取消')
    await settle()
    expect(fullText(r)).not.toContain('确定删除该知识库')
    // 再删 → 确认
    clickButton(r, '删除知识库')
    await settle()
    expect(fullText(r)).toContain('确定删除该知识库')
    await act(async () => {
      const btn = r.root!.findAll((n) => n.type === 'button' && textOf(n).trim() === '确认')[0]
      void (btn?.props.onClick as () => unknown)?.()
    })
    await settle()
    expect(calls.some((c) => c.startsWith('deleteKb:kb-1,tk'))).toBe(true)
    // 回到列表 + 成功通知
    text = fullText(r)
    expect(text).toContain('本地知识库')
    expect(text).toContain('已删除')
  })

  it('文档删除：pending 行内确认 → 成功通知', async () => {
    const { r } = await openDetail()
    clickButton(r, '删除文档')
    await settle()
    expect(fullText(r)).toContain('删除该文档？软删除，重导同路径可恢复。')
    await act(async () => {
      const btn = r.root!.findAll((n) => n.type === 'button' && textOf(n).trim() === '确认')[0]
      void (btn?.props.onClick as () => unknown)?.()
    })
    await settle()
    expect(fullText(r)).toContain('a.md 已删除')
  })

  it('导入文档 → job 横幅 → 轮询到 done 后刷新', async () => {
    const { r } = await openDetail()
    setPlaceholderInput(r, '文件路径或 URL', '/tmp/a.md')
    await act(async () => {
      const btn = r.root!.findAll((n) => n.type === 'button' && textOf(n).trim() === '导入')[0]
      void (btn?.props.onClick as () => unknown)?.()
    })
    await settle()
    expect(fullText(r)).toContain('任务: import — queued')
    // 手动推进一次轮询（no-op interval，取最后一个回调）
    const cb = intervalCbs[intervalCbs.length - 1]
    expect(cb, 'polling interval callback').toBeTruthy()
    await act(async () => {
      void (cb as () => unknown)()
    })
    await settle()
    const text = fullText(r)
    expect(text).toContain('任务: import — done')
  })
})
