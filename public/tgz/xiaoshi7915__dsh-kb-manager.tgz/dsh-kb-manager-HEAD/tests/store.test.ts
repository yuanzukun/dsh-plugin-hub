import { describe, it, expect, beforeAll, afterAll } from 'vitest'
import { mkdtempSync, rmSync, existsSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { openKbStore, tx, readMeta, writeMeta, createSnapshot, listSnapshots, readSnapshotManifest, restoreSnapshotDb, KB_SCHEMA_VERSION, type KbStore } from '../src/store/store.ts'
import type { KbMeta } from '../src/contracts/types.ts'
import { tokenizeForFts } from '../src/index/bm25.ts'

const root = mkdtempSync(join(tmpdir(), 'kb-store-'))
let store: KbStore

const META: KbMeta = {
  kb_id: 'kb-test', name: '测试库', domain_tags: ['t'],
  embedding: { model: 'bge-small-zh-v1.5', provider: 'mock', dim: 512 },
  backend: 'sqlite-vec', status: 'ready', schema_version: KB_SCHEMA_VERSION,
  created_at: '2026-01-01T00:00:00Z', updated_at: '2026-01-01T00:00:00Z',
}

beforeAll(() => {
  store = openKbStore(join(root, 'kbs', 'kb-test'))
  writeMeta(store, META)
  store.db.prepare("INSERT INTO documents(doc_id, file_name, source_type, source_key, content_hash, status, chunk_count, size_bytes, metadata_json, imported_at, updated_at) VALUES ('doc-1','t.txt','txt','t','h','ok',0,1,'{}','2026','2026')").run()
})
afterAll(() => {
  store?.close()
  rmSync(root, { recursive: true, force: true })
})

function addChunk(id: string, text: string, deleted = 0) {
  store.db.prepare(
    'INSERT INTO chunks (chunk_id, doc_id, ord, text, bm25_text, deleted, heading_path, heading_level, page_num, char_start, char_end, token_count, table_detected, metadata_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
  ).run(id, 'doc-1', 0, text, tokenizeForFts(text), deleted, '', null, null, 0, text.length, countLike(text), 0, '{}')
}
function countLike(t: string): number { return t.length }

describe('store', () => {
  it('schema 迁移到当前版本', () => {
    expect(store.db.pragma('user_version', { simple: true })).toBe(KB_SCHEMA_VERSION)
  })

  it('meta 读写', () => {
    expect(readMeta(store)?.name).toBe('测试库')
  })

  it('事务回滚', () => {
    const before = (store.db.prepare('SELECT COUNT(*) c FROM chunks').get() as { c: number }).c
    try {
      tx(store, (db) => {
        db.prepare('INSERT INTO chunks (chunk_id, doc_id, ord, text, bm25_text, token_count, metadata_json) VALUES (?,?,?,?,0,?,?)')
          .run('tx:1', 'doc-1', 0, 'x', 'x', 1, '{}')
        throw new Error('boom')
      })
    } catch { /* expected */ }
    const after = (store.db.prepare('SELECT COUNT(*) c FROM chunks').get() as { c: number }).c
    expect(after).toBe(before)
  })

  it('FTS5 全文匹配', () => {
    addChunk('f:1', '向量数据库存储引擎测试')
    const rows = store.db.prepare(
      "SELECT c.chunk_id FROM chunks_fts JOIN chunks c ON c.rowid = chunks_fts.rowid WHERE chunks_fts MATCH ? AND c.deleted = 0",
    ).all('向量') as Array<{ chunk_id: string }>
    expect(rows.map((r) => r.chunk_id)).toContain('f:1')
  })

  it('快照创建/列表/manifest/恢复', async () => {
    addChunk('f:2', '快照前标记内容')
    await createSnapshot(store, 'snap-1', '测试快照')
    const list = listSnapshots(store)
    expect(list.length).toBe(1)
    expect(list[0]!.snapshot_id).toBe('snap-1')
    const manifest = readSnapshotManifest(store, 'snap-1')
    expect(manifest?.doc_count).toBe(1)

    // 制造"未来"，恢复应回到旧状态
    addChunk('f:3', '快照后新增内容')
    restoreSnapshotDb(store, 'snap-1')
    const ids = (store.db.prepare('SELECT chunk_id FROM chunks').all() as Array<{ chunk_id: string }>).map((r) => r.chunk_id)
    expect(ids).toContain('f:2')
    expect(ids).not.toContain('f:3')
    // 恢复后的备份文件仍在
    expect(existsSync(join(store.kbDir, 'snapshots', 'snap-1', 'kb.db'))).toBe(true)
    expect(existsSync(join(store.kbDir, 'snapshots', 'snap-1', 'manifest.json'))).toBe(true)
  })
})
