import { describe, it, expect, beforeAll, afterAll } from 'vitest'
import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { KbManager, runTool } from '../src/index.ts'
import { executeTool, TOOL_SPECS, TOOLS_PREAMBLE } from '../src/agent-tools/tools.ts'

const root = mkdtempSync(join(tmpdir(), 'kb-tools-'))
let m: KbManager
let kbId: string

async function waitForJob(id: string, tries = 100): Promise<void> {
  for (let i = 0; i < tries; i++) {
    const job = m.jobs.get(id)
    if (job && (job.status === 'done' || job.status === 'failed')) return
    await new Promise((r) => setTimeout(r, 50))
  }
  throw new Error(`job ${id} did not finish`)
}

beforeAll(async () => {
  m = new KbManager(join(root, 'store'), {
    storage_path: join(root, 'store'),
    workspace: root,
    embedding: { model: 'mock', provider: 'mock' },
    chunk_size: 80, chunk_overlap: 16,
  })
  const r = (await runTool(() => m.kbs.createKb('工具测试库', 't', ['t']))) as any
  kbId = r.data.kb_id
})
afterAll(() => {
  m?.close()
  rmSync(root, { recursive: true, force: true })
})

describe('工具层信封', () => {
  it('成功返回 ok:true 信封', async () => {
    const env = await executeTool(m, 'list_kbs', {})
    expect(env.ok).toBe(true)
    expect((env as any).data.total).toBeGreaterThanOrEqual(1)
  })

  it('未知工具返回错误信封', async () => {
    const env = await executeTool(m, 'no_such_tool', {})
    expect(env.ok).toBe(false)
    expect((env as any).error.code).toBe('CFG.KEY.INVALID')
  })

  it('业务错误映射为稳定 code（KB_NOT_FOUND）', async () => {
    const env = await executeTool(m, 'get_kb', { kb_id: '不存在' })
    expect(env.ok).toBe(false)
    expect((env as any).error.code).toBe('KB.NOT_FOUND')
    expect(typeof (env as any).error.hint).toBe('string')
  })
})

describe('工具行为', () => {
  it('MVP 工具集 = 13 个', () => {
    expect(TOOL_SPECS.length).toBe(13)
    const names = TOOL_SPECS.map((t) => t.name)
    for (const n of [
      'create_kb', 'list_kbs', 'get_kb', 'delete_kb', 'list_documents',
      'import_document', 'delete_document', 'search_kb', 'get_chunk',
      'get_kb_stats', 'rebuild_index', 'get_job', 'configure',
    ]) expect(names).toContain(n)
  })

  it('全局 preamble 提示异步轮询契约', () => {
    expect(TOOLS_PREAMBLE).toContain('get_job')
    expect(TOOLS_PREAMBLE).toContain('hint')
  })

  it('import_document 异步：立即 queued，完成后 searchable', async () => {
    mkdirSync(join(root, 'in'), { recursive: true })
    const p = join(root, 'in', 'tool.md')
    writeFileSync(p, '# 工具测试\n\n工具层验证段落：导入走 job，检索需等 job 完成。')
    const env = await executeTool(m, 'import_document', { kb_id: kbId, source: p })
    expect((env as any).data.status).toBe('queued')
    const jobId = (env as any).data.job_id
    await waitForJob(jobId)
    const job = await executeTool(m, 'get_job', { job_id: jobId })
    expect((job as any).data.status).toBe('done')
    const search = await executeTool(m, 'search_kb', { kb_id: kbId, query: '工具层验证', top_k: 3 })
    expect((search as any).data.results.length).toBeGreaterThan(0)
  })

  it('delete_kb 两步确认：无 token 返回 impact，错误 token 拒绝，有效 token 成功', async () => {
    const env1 = await executeTool(m, 'delete_kb', { kb_id: kbId })
    expect((env1 as any).data.requires_confirm).toBe(true)
    const token = (env1 as any).data.confirm_token
    expect((env1 as any).data.impact.docs).toBeGreaterThanOrEqual(1)
    const env2 = await executeTool(m, 'delete_kb', { kb_id: kbId, confirm_token: 'bad-token' })
    expect(env2.ok).toBe(false)
    expect((env2 as any).error.code).toBe('SEC.CONFIRM_REQUIRED')
    const env3 = await executeTool(m, 'delete_kb', { kb_id: kbId, confirm_token: token })
    expect((env3 as any).data.success).toBe(true)
    const env4 = await executeTool(m, 'get_kb', { kb_id: kbId })
    expect(env4.ok).toBe(false)
  })

  it('get_job 未知 id → JOB.NOT_FOUND', async () => {
    const env = await executeTool(m, 'get_job', { job_id: 'no-such-job' })
    expect(env.ok).toBe(false)
    expect((env as any).error.code).toBe('JOB.NOT_FOUND')
  })

  it('search_kb top_k 越界 → SRCH.TOPK_OUT_OF_RANGE', async () => {
    const env = await executeTool(m, 'create_kb', { name: '越界库' })
    const kbId2 = (env as any).data.kb_id
    const env2 = await executeTool(m, 'search_kb', { kb_id: kbId2, query: 'x', top_k: 99 })
    expect(env2.ok).toBe(false)
    expect((env2 as any).error.code).toBe('SRCH.TOPK_OUT_OF_RANGE')
  })

  it('configure 拒绝白名单外配置键', async () => {
    const env = await executeTool(m, 'configure', { patch: { storage_path: '/tmp/other' } })
    expect((env as any).data.updated).toContain('storage_path')
    expect((env as any).data.restart_required).toContain('storage_path')
    const env2 = await executeTool(m, 'configure', { patch: { import_allowed_dirs: ['/etc'] } })
    expect(env2.ok).toBe(false)
    expect((env2 as any).error.code).toBe('CFG.KEY.INVALID')
  })
})
