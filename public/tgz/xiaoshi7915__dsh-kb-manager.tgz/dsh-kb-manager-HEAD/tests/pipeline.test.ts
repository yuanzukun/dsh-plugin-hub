import { describe, it, expect, beforeAll, afterAll } from 'vitest'
import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { KbManager } from '../src/index.ts'
import { KbError } from '../src/contracts/errors.ts'

const root = mkdtempSync(join(tmpdir(), 'kb-e2e-'))
let m: KbManager
let kbId: string
let jobId: string

async function waitForJob(id: string, tries = 100): Promise<any> {
  for (let i = 0; i < tries; i++) {
    const job = m.jobs.get(id)!
    if (job.status === 'done' || job.status === 'failed') return job
    await new Promise((r) => setTimeout(r, 50))
  }
  throw new Error(`job ${id} did not finish`)
}

function docPath(name: string, body: string): string {
  mkdirSync(join(root, 'in'), { recursive: true })
  const p = join(root, 'in', name)
  writeFileSync(p, body)
  return p
}

beforeAll(async () => {
  m = new KbManager(join(root, 'store'), {
    storage_path: join(root, 'store'),
    workspace: root,
    embedding: { model: 'mock', provider: 'mock' },
    chunk_size: 80, chunk_overlap: 16, max_file_size_mb: 10,
  })
  const created = m.kbs.createKb('管线测试库', 'e2e', ['test'])
  kbId = created.kb_id
  const job = m.enqueue(kbId, 'import', m.docs.importWork(kbId, docPath('alpha.md',
    [
      '# 部署手册',
      '## 向量引擎',
      '我们的向量存储引擎采用 sqlite-vec 扩展，在 20 万块以下性能足够，超过则切换 usearch。',
      '## 检索融合',
      '混合检索使用 RRF 融合，k=60，向量路与 FTS5 BM25 路并行执行后合并。',
      '## 安全边界',
      '导入路径必须落在白名单目录内，SSRF 防护拒绝私网地址与云元数据端点。',
    ].join('\n\n')), 'auto', { tag: 'alpha' }))
  jobId = job.job_id
  await waitForJob(jobId)
})
afterAll(() => {
  m?.close()
  rmSync(root, { recursive: true, force: true })
})

describe('e2e 管线', () => {
  it('导入 job 完成且块数合理', () => {
    const job = m.jobs.get(jobId)!
    expect(job.status).toBe('done')
    const r = job.result as any
    expect(r.status).toBe('ok')
    expect(r.chunk_count).toBeGreaterThanOrEqual(2)
  })

  it('search_kb 命中最相关块', async () => {
    const res = await m.search.searchKb(kbId, '向量存储引擎什么时候切 usearch', { topK: 3 })
    expect(res.results.length).toBeGreaterThan(0)
    expect(res.results[0]!.text).toContain('usearch')
    expect(res.rerank).toBe('fallback_rrf')
    expect(res.results[0]!.score_kind).toBe('rrf')
    expect(res.results[0]!.score).toBe(1)
    for (const h of res.results) {
      expect(h.untrusted).toBe(true)
      expect(h.text.length).toBeLessThanOrEqual(300)
    }
  })

  it('BM25 路独立命中（纯关键词查询）', async () => {
    const res = await m.search.searchKb(kbId, '白名单目录 SSRF', { topK: 5 })
    expect(res.results.length).toBeGreaterThan(0)
    expect(res.results.some((h) => h.text.includes('白名单'))).toBe(true)
  })

  it('filters: doc 精确过滤生效', async () => {
    const res = await m.search.searchKb(kbId, 'RRF 融合', { topK: 5, filters: { docs: ['不存在的文件.md'] } })
    expect(res.results).toEqual([])
  })

  it('get_chunk 全文 + 前后相邻', async () => {
    const res = await m.search.searchKb(kbId, '混合检索 RRF 融合 k=60', { topK: 2 })
    const c = m.search.getChunk(kbId, res.results[0]!.chunk_id)
    expect(c.text.length).toBeGreaterThan(10)
    expect(typeof c.prev_chunk_id).toBe('string')
    expect(typeof c.next_chunk_id).toBe('string')
  })

  it('幂等重导入 → restored/unchanged', async () => {
    const job = m.enqueue(kbId, 'import', m.docs.importWork(kbId, join(root, 'in', 'alpha.md'), 'auto', { tag: 'alpha' }))
    await waitForJob(job.job_id)
    expect((m.jobs.get(job.job_id)!.result as any).status).toBe('unchanged')
    expect((m.jobs.get(job.job_id)!.result as any).deduplicated).toBe(true)
  })

  it('内容变化 → 就地替换（dedup 后块数一致）', async () => {
    const before = m.kbs.stats(kbId).chunk_count
    const p = docPath('beta.md', '# Beta\n\nbeta 独有事实：部署脚本使用 pnpm 工作区管理。')
    const job1 = m.enqueue(kbId, 'import', m.docs.importWork(kbId, p, 'auto', {}))
    await waitForJob(job1.job_id)
    docPath('beta.md', '# Beta\n\nbeta 更新后的事实：部署脚本改用 npm 工作区管理。')
    const job2 = m.enqueue(kbId, 'import', m.docs.importWork(kbId, p, 'auto', {}))
    await waitForJob(job2.job_id)
    expect((m.jobs.get(job2.job_id)!.result as any).status).toBe('ok')
    const after = m.kbs.stats(kbId).chunk_count
    expect(after).toBeGreaterThanOrEqual(before)
    // 旧事实不可检索，新事实可检索
    const hitOld = await m.search.searchKb(kbId, 'beta 部署脚本 pnpm 工作区', { topK: 3 })
    expect(hitOld.results.every((h) => !h.text.includes('pnpm 工作区'))).toBe(true)
    const hitNew = await m.search.searchKb(kbId, 'beta 部署脚本 npm 工作区', { topK: 3 })
    expect(hitNew.results.some((h) => h.text.includes('npm 工作区'))).toBe(true)
  })

  it('delete_document 软删立即生效；重导恢复', async () => {
    const docs = m.docs.listDocuments(kbId, {})
    const beta = docs.docs.find((d) => d.file_name === 'beta.md')!
    const del = m.docs.deleteDocument(kbId, beta.doc_id)
    expect(del.success).toBe(true)
    expect((await m.search.searchKb(kbId, 'beta 部署脚本 npm 工作区', { topK: 3 })).results.every((h) => !h.text.includes('beta'))).toBe(true)
    // 重新导入同路径 → 恢复
    const job = m.enqueue(kbId, 'import', m.docs.importWork(kbId, join(root, 'in', 'beta.md'), 'auto', {}))
    await waitForJob(job.job_id)
    const res = await m.search.searchKb(kbId, 'beta 部署脚本 npm 工作区', { topK: 3 })
    expect(res.results.some((h) => h.text.includes('npm 工作区'))).toBe(true)
  })

  it('KB_NAME_CONFLICT 非幂等', () => {
    expect(() => m.kbs.createKb('管线测试库')).toThrow(KbError)
  })

  it('top_k 越界拒绝', async () => {
    await expect(m.search.searchKb(kbId, 'x', { topK: 0 })).rejects.toThrow(KbError)
    await expect(m.search.searchKb(kbId, 'x', { topK: 51 })).rejects.toThrow(KbError)
  })

  it('stats 与 get_kb', () => {
    const s = m.kbs.stats(kbId)
    expect(s.doc_count).toBeGreaterThanOrEqual(2)
    expect(s.chunk_count).toBeGreaterThan(0)
    expect(s.embedding.provider).toBe('mock')
    const meta = m.kbs.getKb(kbId)
    expect(meta.name).toBe('管线测试库')
  })

  it('configure 白名单：合法键生效，安全键拒绝', () => {
    const r = m.applyConfigPatch({ top_k: 8, chunk_overlap: 20 })
    expect(r.updated).toContain('top_k')
    expect(m.cfg.top_k).toBe(8)
    expect(() => m.applyConfigPatch({ import_allowed_dirs: ['/'] })).toThrow(KbError)
  })

  it('get_job 未知 id 抛 JOB.NOT_FOUND', () => {
    expect(() => {
      const job = m.jobs.get('no-such-job')
      if (!job) throw new KbError('JOB.NOT_FOUND', '任务不存在', 'x')
    }).toThrow(KbError)
  })
})
