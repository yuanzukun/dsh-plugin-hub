/**
 * host-entry 冒烟测试：fake ctx 验证插件接线（工具注册 / preamble / 清理），
 * 并经注册出的 definition.execute 跑真实 KbManager（create_kb → get_kb）。
 * 真实宿主集成见 DESIGN §13.3（需 dsh profile 装载）。
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest'
import { mkdtempSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { apply } from '../src/host-entry.ts'
import { TOOL_SPECS, TOOLS_PREAMBLE } from '../src/agent-tools/tools.ts'

interface FakeDef {
  name: string
  description: string
  parameters: Record<string, unknown>
  output: {
    schema: { type: string }
    render: (args: unknown, value: unknown) => { type: string; text: string }[]
  }
  execute: (args: unknown, exec: unknown) => Promise<unknown>
}

function makeCtx() {
  const registered: FakeDef[] = []
  const sections: { name: string; order: number; text: string }[] = []
  const services = new Map<string, unknown>()
  let unregistered = 0
  const cleanupFns: Array<() => void> = []
  const ctx = {
    logger: () => ({ debug: () => {}, info: () => {}, warn: () => {}, error: () => {} }),
    tools: {
      register(def: FakeDef) {
        registered.push(def)
        return () => { unregistered++ }
      },
    },
    systemPrompt: {
      section(s: { name: string; order: number; text: string }) {
        sections.push(s)
        return () => {}
      },
    },
    reflect: {
      // cordis Service 构造经 ctx.reflect.provide 注册（KbManagerRemote 等）
      provide(name: string, value: unknown, _check?: unknown) {
        services.set(name, value)
      },
    },
    effect(execute: () => () => void, _label?: string) {
      cleanupFns.push(execute())
    },
  }
  return { ctx, registered, sections, services, cleanupFns, unregistered: () => unregistered }
}

let root: string
let ws: string
let fake: ReturnType<typeof makeCtx>
let defs: Map<string, FakeDef>

beforeAll(() => {
  root = mkdtempSync(join(tmpdir(), 'kb-hostentry-'))
  ws = join(root, 'workspace')
  fake = makeCtx()
  apply(fake.ctx as never, { storagePath: root, logLevel: 'info', workspace: ws })
  defs = new Map(fake.registered.map(d => [d.name, d]))
})

afterAll(() => {
  for (const fn of fake.cleanupFns) fn()
  rmSync(root, { recursive: true, force: true })
})

describe('host-entry 接线', () => {
  it('注册 13 个 MVP 工具，名称与 TOOL_SPECS 一致', () => {
    expect(fake.registered).toHaveLength(13)
    expect(fake.registered.map(d => d.name)).toEqual(TOOL_SPECS.map(s => s.name))
    for (const d of fake.registered) {
      expect(d.description.length).toBeGreaterThan(10)
      expect(d.parameters).toBeTruthy()
      expect(typeof d.output.render).toBe('function')
    }
  })

  it('注册 system prompt preamble（tool:kb-manager）', () => {
    expect(fake.sections).toHaveLength(1)
    expect(fake.sections[0]?.name).toBe('tool:kb-manager')
    expect(fake.sections[0]?.text).toBe(TOOLS_PREAMBLE)
  })

  it('definition.execute 走真实 KbManager：create_kb → get_kb', async () => {
    const env = (await defs.get('create_kb')!.execute({ name: 'smoke-kb' }, null)) as {
      ok: boolean
      data?: { kb_id: string }
      error?: { code: string; message: string }
    }
    expect(env.ok).toBe(true)
    const kbId = env.data!.kb_id
    expect(typeof kbId).toBe('string')
    const g = (await defs.get('get_kb')!.execute({ kb_id: kbId }, null)) as {
      ok: boolean
      data?: { name: string }
      error?: { code: string; message: string }
    }
    expect(g.ok).toBe(true)
    expect(g.data!.name).toBe('smoke-kb')
  })

  it('render 把信封映射为文本块（ok → JSON，error → 可读错误行）', () => {
    const d = defs.get('get_kb')!
    const okBlocks = d.output.render({}, { ok: true, data: { x: 1 } })
    expect(okBlocks).toHaveLength(1)
    expect(okBlocks[0]!.type).toBe('text')
    expect(JSON.parse(okBlocks[0]!.text)).toEqual({ x: 1 })
    const errBlocks = d.output.render({}, { ok: false, error: { code: 'KB.NOT_FOUND', message: '不存在', hint: '先 list_kbs' } })
    expect(errBlocks[0]!.text).toBe('ERROR KB.NOT_FOUND: 不存在 | hint: 先 list_kbs')
  })

  it('清理 disposer 注销全部工具', () => {
    expect(fake.cleanupFns).toHaveLength(1)
    // 工具已注册 13 个；执行前 cleanup 尚未触发
    expect(fake.unregistered()).toBe(0)
    // 注：afterAll 会调用 cleanup；此处只断言 disposer 已登记且可调
    expect(typeof fake.cleanupFns[0]).toBe('function')
  })
})
