/**
 * Remote 层测试：
 * 1) 清单形状（host TYPERT / client TYPERT_REMOTE 同源 + loader 校验等价断言）
 * 2) KbManagerRemote 行为（真实 cordis Context + 真实 KbManager + mock embedder，
 *    直接调用 wire 方法验证信封 / 错误码 / 两步确认 / 任务轮询）
 * 3) client bundle 产物（wrapper 形状 + factory 导出面 + external 审计）
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest'
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { Context } from '@deepseek-ai/cordis'
import { KbManager, runTool } from '../src/index.ts'
import { KB_INVOCATIONS, KB_NAMESPACE, KB_PACKAGE } from '../src/remote.ts'
import { TYPERT } from '../src/typert.ts'
import { TYPERT_REMOTE } from '../src/remote-client.ts'
import { KbManagerRemote } from '../src/remote-service.ts'

// ---------- 1) 清单形状 ----------

describe('wire 契约同源', () => {
  it('TYPERT 与 TYPERT_REMOTE 共享同一 KB_INVOCATIONS 数组', () => {
    expect(TYPERT.invocations).toBe(KB_INVOCATIONS)
    expect(TYPERT_REMOTE.descriptors).toBe(KB_INVOCATIONS)
    expect(TYPERT_REMOTE.package).toBe(KB_PACKAGE)
  })

  it('host 清单通过 loader 等价校验', () => {
    expect(TYPERT.package).toBe('dsh-kb-manager')
    expect(TYPERT.face).toBe('host')
    expect(Array.isArray(TYPERT.schemas)).toBe(true)
    expect(TYPERT.model.events).toEqual([])
    expect(TYPERT.model.objects).toEqual([])
    const [hostSvc] = TYPERT.model.services
    expect(hostSvc?.key).toBe(KB_NAMESPACE)
    expect(hostSvc?.exportName).toBe('KbManagerRemote')
    expect(Array.isArray(hostSvc?.tags)).toBe(true)
    expect(hostSvc?.members).toHaveLength(KB_INVOCATIONS.length)
    for (const m of hostSvc?.members ?? []) {
      expect(typeof m.name).toBe('string')
      expect(typeof m.signature).toBe('string')
      expect(['method', 'property', 'getter']).toContain(m.kind)
    }
  })

  it('每个调用描述符满足 gateway 严格校验（strict codec + zod + 唯一 wire）', () => {
    expect(KB_INVOCATIONS).toHaveLength(13)
    for (const inv of KB_INVOCATIONS) {
      expect(inv.id).toBe(`${KB_PACKAGE}#${KB_NAMESPACE}/${inv.method}`)
      expect(inv.service).toBe(KB_NAMESPACE)
      expect(inv.namespace).toBe(KB_NAMESPACE)
      expect(inv.invocation).toEqual({ kind: 'direct' })
      const wires = inv.parameters.map((p) => p.wire)
      expect(new Set(wires).size).toBe(wires.length)
      for (const p of inv.parameters) {
        expect(p.source).toBe('json')
        const codec = p.codec as { mode: string; typeSymbol: string; schema: { _zod: unknown; parse(v: unknown): unknown } }
        expect(codec.mode).toBe('strict')
        expect(typeof codec.typeSymbol).toBe('string')
        expect(codec.schema).toHaveProperty('_zod')
        expect(typeof codec.schema.parse).toBe('function')
      }
      const result = inv.result as { mode: string; schema: { _zod: unknown; parse(v: unknown): unknown } }
      expect(result.mode).toBe('strict')
      expect(result.schema).toHaveProperty('_zod')
      expect(typeof result.schema.parse).toBe('function')
    }
  })

  it('KbManagerRemote 原型方法名与 wire 方法一一对应', () => {
    const proto = KbManagerRemote.prototype as unknown as Record<string, unknown>
    for (const inv of KB_INVOCATIONS) {
      expect(typeof proto[inv.method]).toBe('function')
    }
  })
})

// ---------- 2) 行为 ----------

const root = mkdtempSync(join(tmpdir(), 'kb-remote-'))
let m: KbManager
let svc!: KbManagerRemote
let ctx: Context
let kbId: string

function asOk(env: { ok: boolean }): asserts env is { ok: true; data: never } {
  expect(env.ok).toBe(true)
}

beforeAll(async () => {
  m = new KbManager(join(root, 'store'), {
    workspace: root,
    embedding: { model: 'mock', provider: 'mock' },
    chunk_size: 80,
    chunk_overlap: 16,
  })
  ctx = new Context()
  svc = new KbManagerRemote(ctx, m)
  const created = await svc.create('远程测试库', 'remote test', ['tag'])
  asOk(created)
  kbId = (created as { data: { kb_id: string } }).data.kb_id
  // 导入一篇文档用于 search/docs 断言
  writeFileSync(join(root, 'hello.md'), '# 标题\n\n知识库远程测试正文内容，向量与全文双通道检索。')
  const imp = await svc.importDoc(kbId, join(root, 'hello.md'))
  asOk(imp)
  const jobId = (imp as { data: { job_id: string } }).data.job_id
  for (let i = 0; i < 200; i++) {
    const j = await svc.job(jobId)
    asOk(j)
    const job = (j as { data: { status: string } }).data
    if (job.status === 'done' || job.status === 'failed') break
    await new Promise((r) => setTimeout(r, 50))
  }
})

afterAll(() => {
  m?.close()
  rmSync(root, { recursive: true, force: true })
})

describe('KbManagerRemote 行为', () => {
  it('list / detail / stats 返回 ok 信封', async () => {
    const l = await svc.list()
    asOk(l)
    expect((l as { data: { total: number; kbs: unknown[] } }).data.total).toBeGreaterThanOrEqual(1)

    const d = await svc.detail(kbId)
    asOk(d)
    expect((d as { data: { name: string } }).data.name).toBe('远程测试库')

    const s = await svc.stats(kbId)
    asOk(s)
    const st = (s as { data: { chunk_count: number } }).data
    expect(st.chunk_count).toBeGreaterThan(0)
  })

  it('docs 列出导入的文档', async () => {
    const r = await svc.docs(kbId)
    asOk(r)
    const docs = (r as { data: { docs: Array<{ file_name: string }> } }).data.docs
    expect(docs.some((d) => d.file_name === 'hello.md')).toBe(true)
  })

  it('search 命中导入内容', async () => {
    const r = await svc.search(kbId, '向量与全文双通道检索')
    asOk(r)
    const res = (r as { data: { results: unknown[] } }).data.results
    expect(res.length).toBeGreaterThan(0)
  })

  it('未知 kb 返回 KB.NOT_FOUND 错误信封', async () => {
    const r = await svc.detail('kb_missing_123')
    expect(r.ok).toBe(false)
    expect((r as { error: { code: string } }).error.code).toBe('KB.NOT_FOUND')
  })

  it('deleteKb 两步确认：首次签发 token，二次携带 token 才删', async () => {
    const tmp = await svc.create('待删库')
    asOk(tmp)
    const victim = (tmp as { data: { kb_id: string } }).data.kb_id

    const first = await svc.deleteKb(victim)
    asOk(first)
    const pending = (first as unknown as {
      data: { requires_confirm: boolean; confirm_token: string }
    }).data
    expect(pending.requires_confirm).toBe(true)
    expect(pending.confirm_token.length).toBeGreaterThan(0)

    const r = await svc.deleteKb(victim, pending.confirm_token)
    asOk(r)
    expect((r as unknown as { data: { success: boolean } }).data.success).toBe(true)

    const gone = await svc.detail(victim)
    expect(gone.ok).toBe(false)
  })

  it('cancelJob 对不存在的 job 返回 JOB.NOT_FOUND', async () => {
    const r = await svc.cancelJob('job_missing_123')
    expect(r.ok).toBe(false)
    expect((r as { error: { code: string } }).error.code).toBe('JOB.NOT_FOUND')
  })

  it('configure 热更白名单键', async () => {
    const r = await svc.configure({ top_k: 8 })
    asOk(r)
    const data = (r as { data: { updated: string[]; restart_required: string[] } }).data
    expect(data.updated).toContain('top_k')
    expect(data.restart_required).toEqual([])
  })

  it('服务随 fiber 注册，兄弟 plugin fiber 可读（gateway 跨插件分发前提）', async () => {
    const seen: unknown[] = []
    const reader = ctx.plugin({
      name: 'kb-remote-reader-test',
      apply: (c: Context) => {
        const get = (c as unknown as { get(name: string): unknown }).get
        const s = get('kbManager') as { name?: string } | undefined
        seen.push(s ? s.name : undefined)
      },
    })
    await reader
    expect(seen).toHaveLength(1)
    expect(seen[0]).toBe('kbManager')
  })
})

// ---------- 3) client bundle 产物 ----------

/** 在模块表 stub（react 代理）下执行 bundle factory，返回模块导出。 */
function loadBundleExports(): { apply?: (ctx: unknown) => Promise<() => Promise<void>>; inject?: unknown } {
  const src = readFileSync(join(__dirname, '..', 'lib', 'client.js'), 'utf8')
  const factoryMatch = /factory: \(require\) => \{([\s\S]*)\n\} \}\);\s*$/.exec(src.trimEnd())
  expect(factoryMatch).not.toBeNull()
  const body = factoryMatch![1] ?? ''
  const fakeRequire = (spec: string): Record<string, unknown> => {
    expect(['react', 'react/jsx-runtime']).toContain(spec)
    // 所有 react 导出统一返回可调用占位（顶层模块初始化不触发真实渲染）
    return new Proxy({} as Record<string, unknown>, {
      get: (_t, prop: string) => {
        if (prop === '__esModule') return true
        if (prop === 'default') return fakeRequire(spec)
        return (..._a: unknown[]) => null
      },
    })
  }
  // eslint-disable-next-line no-new-func
  const factory = new Function('require', `"use strict"; var module = { exports: {} }; var exports = module.exports; ${body} return module.exports;`)
  return factory(fakeRequire) as { apply?: (ctx: unknown) => Promise<() => Promise<void>>; inject?: unknown }
}

describe('client bundle', () => {
  it('产物存在且是模块表闭包包装', () => {
    const p = join(__dirname, '..', 'lib', 'client.js')
    expect(existsSync(p)).toBe(true)
    const src = readFileSync(p, 'utf8')
    expect(src.startsWith('/* dsh-kb-manager client bundle')).toBe(true)
    expect(src).toContain('window.__ModuleLoader__.load({ id: "dsh-kb-manager", factory: (require) => {')
    expect(src.trimEnd().endsWith('} });')).toBe(true)
    // external 审计：bundle 内只允许 require react / react/jsx-runtime
    const requires = [...src.matchAll(/require\("([^"]+)"\)/g)].map((x) => x[1] ?? '')
    for (const r of requires) {
      expect(['react', 'react/jsx-runtime']).toContain(r)
    }
  })

  it('factory 在模块表 stub 下执行并导出 apply + inject', () => {
    const out = loadBundleExports()
    expect(typeof out.apply).toBe('function')
    expect(Array.isArray(out.inject)).toBe(true)
    expect(out.inject).toEqual(['slots', 'locale', 'remote'])
  })

  it('apply 在 fake ctx 下执行：locale 注册 + $mount + settings.section 注入', async () => {
    const out = loadBundleExports()
    const calls: {
      localeRegister: string[]
      mounts: Array<Record<string, unknown>>
      injected: string[]
      registered?: { opts: Record<string, unknown>; comp: unknown }
    } = { localeRegister: [], mounts: [], injected: [] }
    const kbManagerHandle = { __handle: true }
    const fakeCtx = {
      effect: (fn: () => void) => { fn() },
      locale: {
        register(ns: string, _dicts: unknown) { calls.localeRegister.push(ns) },
        bind(_ns: string) { return (k: string) => k },
      },
      slots: {
        inject(slot: string, cb: () => void) { calls.injected.push(slot); cb() },
        register(opts: Record<string, unknown>, comp: unknown) { calls.registered = { opts, comp } },
      },
      remote: {
        $mount: async (c: Record<string, unknown>) => { calls.mounts.push(c); return async () => {} },
        kbManager: kbManagerHandle,
      },
    }
    const disposer = await out.apply!(fakeCtx)
    // 文案命名空间注册
    expect(calls.localeRegister).toEqual(['settings.kbManager'])
    // typert 贡献挂载一次，且指向同源描述符
    expect(calls.mounts).toHaveLength(1)
    expect(calls.mounts[0]?.package).toBe('dsh-kb-manager')
    const descriptors = calls.mounts[0]?.descriptors as Array<Record<string, unknown>>
    expect(Array.isArray(descriptors)).toBe(true)
    expect(descriptors).toHaveLength(13)
    // settings.section 注入 + 行属性
    expect(calls.injected).toEqual(['settings.section'])
    const reg = calls.registered
    expect(reg).toBeDefined()
    expect(reg!.opts.id).toBe('kb-manager')
    expect(reg!.opts.order).toBe(90)
    expect(typeof reg!.opts.label).toBe('function')
    expect(typeof reg!.comp).toBe('function')
    // inject face 提供 kb（取命名空间句柄）与 t
    const face = (reg!.opts.inject as () => { kb: () => unknown; t: (k: string) => string })()
    expect(typeof face.kb).toBe('function')
    expect(face.kb()).toBe(kbManagerHandle)
    expect(face.t('nav')).toBe('nav')
    // disposer 可调用（remote 卸载器）
    expect(typeof disposer).toBe('function')
    await expect(disposer()).resolves.toBeUndefined()
  })
})
