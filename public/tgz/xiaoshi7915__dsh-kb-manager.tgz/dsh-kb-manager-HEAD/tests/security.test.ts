import { describe, it, expect } from 'vitest'
import { mkdtempSync, writeFileSync, symlinkSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { assertPathAllowed } from '../src/security/path-guard.ts'
import { isPrivateIp, isPrivateIPv4 } from '../src/security/ssrf-guard.ts'
import { KbError } from '../src/contracts/errors.ts'

describe('路径白名单守卫', () => {
  const dir = mkdtempSync(join(tmpdir(), 'kb-sec-'))
  const secret = join(dir, 'secret.txt')
  writeFileSync(secret, 'top secret')

  it('白名单内路径通过并返回 realpath', () => {
    expect(assertPathAllowed(secret, [dir])).toBe(secret)
  })
  it('拒绝 .. 穿越', () => {
    expect(() => assertPathAllowed(join(dir, 'sub', '..', 'secret.txt'), [join(dir, 'sub')])).toThrow(KbError)
  })
  it('拒绝符号链接逃逸（realpath 校验）', () => {
    const link = join(dir, 'link.txt')
    symlinkSync(secret, link)
    const outside = join(tmpdir(), 'kb-outside-')
    expect(() => assertPathAllowed(link, [outside])).toThrow(/outside the allowed/)
  })
  it('拒绝相对路径', () => {
    expect(() => assertPathAllowed('relative/path.txt', [dir])).toThrow(KbError)
  })
  it('空白名单一律拒绝', () => {
    expect(() => assertPathAllowed(secret, [])).toThrow(KbError)
  })
  it('非白名单目录拒绝', () => {
    expect(() => assertPathAllowed('/etc/hostname', [dir])).toThrow(KbError)
  })
  it('白名单目录本身允许（作为导出目标目录）', () => {
    expect(assertPathAllowed(dir, [dir])).toBe(dir)
  })
})

describe('SSRF IP 判定', () => {
  it.each([
    '127.0.0.1', '10.1.2.3', '172.16.0.1', '172.31.255.255',
    '192.168.1.1', '169.254.169.254', '0.0.0.0', '100.64.0.1',
  ])('私有/保留 IPv4 %s', (ip) => {
    expect(isPrivateIPv4(ip)).toBe(true)
    expect(isPrivateIp(ip)).toBe(true)
  })
  it.each(['8.8.8.8', '1.1.1.1', '93.184.216.34'])('公网 IPv4 %s', (ip) => {
    expect(isPrivateIp(ip)).toBe(false)
  })
  it.each(['::1', '::', 'fc00::1', 'fd12::3', 'fe80::1'])('私有 IPv6 %s', (ip) => {
    expect(isPrivateIp(ip)).toBe(true)
  })
  it('IPv4-mapped 私有地址', () => {
    expect(isPrivateIp('::ffff:127.0.0.1')).toBe(true)
  })
  it('非法 IP 一律拒绝', () => {
    expect(isPrivateIp('not-an-ip')).toBe(true)
  })
  it('存在性辅助', () => {
    expect(existsSync('/definitely/not/here/x')).toBe(false)
  })
})
