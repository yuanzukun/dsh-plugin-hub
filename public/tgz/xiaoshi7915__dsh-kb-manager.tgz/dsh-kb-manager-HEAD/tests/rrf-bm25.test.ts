import { describe, it, expect } from 'vitest'
import { rrfFusion, topFromMap, normalizeForDisplay } from '../src/index/rrf.ts'
import { tokenizeZh, queryTokens, InMemoryBm25 } from '../src/index/bm25.ts'

describe('RRF', () => {
  it('双路共同命中的条目得分更高', () => {
    const lists = [
      { ids: ['a', 'b', 'c'] },
      { ids: ['a', 'd', 'e'] },
    ]
    const fused = rrfFusion(lists, 60)
    const top = topFromMap(fused, 5)
    expect(top[0]![0]).toBe('a')
    expect(fused.get('a')).toBeGreaterThan(fused.get('b')!)
  })

  it('单路出现按 rank 计分', () => {
    const fused = rrfFusion([{ ids: ['x', 'y'] }], 60)
    expect(fused.get('x')).toBeCloseTo(1 / 61)
    expect(fused.get('y')).toBeCloseTo(1 / 62)
  })

  it('normalizeForDisplay top-1 = 1', () => {
    const scored: Array<[string, number]> = [['a', 0.5], ['b', 0.25], ['c', 0.1]]
    const n = normalizeForDisplay(scored)
    expect(n.get('a')).toBe(1)
    expect(n.get('b')).toBeCloseTo(0.5)
    expect(n.get('c')).toBeCloseTo(0.2)
    expect(normalizeForDisplay([]).size).toBe(0)
  })
})

describe('Intl.Segmenter 分词', () => {
  it('中文词边界', () => {
    const toks = tokenizeZh('知识库检索增强')
    expect(toks.length).toBeGreaterThan(2)
    expect(toks.every((t) => t.length >= 1)).toBe(true)
  })
  it('英文小写化', () => {
    expect(tokenizeZh('Vector Search')).toEqual(['vector', 'search'])
  })
  it('queryTokens 去重保序', () => {
    expect(queryTokens('检索 检索 召回 vector 检索')).toEqual(['检索', '召回', 'vector'])
  })
})

describe('InMemoryBm25', () => {
  it('相关文档排前', () => {
    const bm25 = new InMemoryBm25()
    bm25.addDoc('d1', tokenizeZh('知识库的向量检索使用嵌入模型把文本映射到向量空间'))
    bm25.addDoc('d2', tokenizeZh('今天天气不错适合出去散步'))
    bm25.addDoc('d3', tokenizeZh('检索系统通过倒排索引与向量近邻搜索混合召回'))
    const hits = bm25.search(queryTokens('向量检索'), 3)
    expect(hits[0]!.id).toBe('d1')
    expect(hits.map((h) => h.id)).not.toContain('d2')
  })
  it('removeDoc 后不再命中', () => {
    const bm25 = new InMemoryBm25()
    bm25.addDoc('d1', tokenizeZh('向量检索'))
    bm25.addDoc('d2', tokenizeZh('向量检索与排序'))
    bm25.removeDoc('d1')
    expect(bm25.search(queryTokens('向量检索')).map((h) => h.id)).toEqual(['d2'])
  })
})
