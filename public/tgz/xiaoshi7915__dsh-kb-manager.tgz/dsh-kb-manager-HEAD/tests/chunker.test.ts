import { describe, it, expect } from 'vitest'
import { countTokens } from '../src/chunker/tokens.ts'
import { chunkDocument, previewText } from '../src/chunker/index.ts'
import { parseMarkdown } from '../src/parsers/markdown.ts'
import type { ChunkingParams } from '../src/contracts/types.ts'

const P: ChunkingParams = {
  chunkSize: 60, chunkOverlap: 12, strategy: 'recursive', tableChunkMaxTokens: 30, csvRowsPerChunk: 50,
}

describe('recursive chunker', () => {
  it('所有块不超 chunkSize 预算', () => {
    const doc = parseMarkdown(
      [
        '# 标题一',
        ...Array.from({ length: 60 }, (_, i) => `这是第${i}行段落内容，包含一些中文文本用于分块测试。`),
      ].join('\n'),
      't.md',
    )
    const chunks = chunkDocument(doc, P)
    expect(chunks.length).toBeGreaterThan(3)
    for (const c of chunks) {
      expect(countTokens(c.text)).toBeLessThanOrEqual(60 + 12) // 预算 + overlap 前缀余量
    }
  })

  it('heading 进入块首且 heading_path 随层级维护', () => {
    const doc = parseMarkdown('# 部署\n## 架构\n第一段。\n## 运维\n第二段。\n### 日志\n第三段。', 'h.md')
    const chunks = chunkDocument(doc, { ...P, chunkSize: 40 })
    const arch = chunks.find((c) => c.heading_path.includes('架构'))
    expect(arch).toBeDefined()
    expect(arch!.heading_path).toBe('部署 > 架构')
    const logs = chunks.find((c) => c.heading_path.includes('日志'))
    expect(logs!.heading_path).toBe('部署 > 运维 > 日志')
  })

  it('大表格按行切分且每段重复表头', () => {
    const header = '| a | b | c |\n|---|---|---|\n'
    const rows = Array.from({ length: 20 }, (_, i) => `| 数据行${i} | 内容${i} | 备注${i} |`).join('\n')
    const doc = parseMarkdown(header + rows, 'table.md')
    const chunks = chunkDocument(doc, P)
    const tables = chunks.filter((c) => c.table_detected)
    expect(tables.length).toBeGreaterThan(1)
    for (const t of tables) {
      expect(t.text.startsWith('| a | b | c |')).toBe(true)
      expect(t.text).toContain('|---|---|---|')
    }
  })

  it('内容无丢失：所有块文本均出自原文', () => {
    const body = Array.from({ length: 30 }, (_, i) => `段落${i}：这是用于验证分块完整性的独立句子，编号为${i}。`).join('\n\n')
    const doc = parseMarkdown('# 根\n' + body, 'full.md')
    const chunks = chunkDocument(doc, { ...P, chunkSize: 48 })
    const all = chunks.map((c) => c.text.replace(/^.*?\n/, '')).join('')
    for (let i = 0; i < 30; i++) {
      expect(all).toContain(`编号为${i}`)
    }
  })
})

describe('fixed chunker', () => {
  it('纯滑窗，不保留 heading 结构', () => {
    const doc = parseMarkdown('# A\n\n' + ('x '.repeat(250)) + '\n\n# B\n\n' + ('y '.repeat(250)), 'f.md')
    const chunks = chunkDocument(doc, { ...P, strategy: 'fixed' })
    expect(chunks.length).toBeGreaterThan(2)
    expect(chunks.every((c) => c.heading_level === null)).toBe(true)
  })
})

describe('previewText', () => {
  it('超过 2 万字符截断', () => {
    expect(previewText('a'.repeat(25000)).length).toBe(20000)
    expect(previewText('短文本')).toBe('短文本')
  })
})
