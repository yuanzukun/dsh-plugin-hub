import { describe, it, expect } from 'vitest'
import { BertTokenizer } from '../src/embedder/bert-tokenizer.ts'

const VOCAB = [
  '[PAD]', '[UNK]', '[CLS]', '[SEP]', '[MASK]',
  'a', 'b', '##b', 'hello', '##world',
  '中', '文', '知识', '##库', '检索',
  '0', '1',
].join('\n')

function tok(maxLen = 16) {
  return new BertTokenizer(VOCAB, maxLen)
}

describe('BertTokenizer', () => {
  it('基础 encode：CLS+SEP+padding+mask', () => {
    const t = tok()
    const e = t.encode('hello')
    // hello(8) → [CLS](2) hello(8) [SEP](3) PAD(0)...
    expect(e.inputIds[0]).toBe(2) // [CLS]
    expect(e.inputIds[1]).toBe(8) // hello
    expect(e.inputIds[2]).toBe(3) // [SEP]
    expect(e.inputIds.slice(3)).toEqual(Array(13).fill(0)) // [PAD]
    expect(e.attentionMask.slice(0, 3)).toEqual([1, 1, 1])
    expect(e.attentionMask.slice(3)).toEqual(Array(13).fill(0))
    expect(e.tokenTypeIds).toEqual(Array(16).fill(0))
  })

  it('中文逐字（CJK 加空格 → 单字 token）', () => {
    const t = tok()
    const e = t.encode('中文')
    // 中(10) 文(11)
    expect(e.inputIds.slice(0, 4)).toEqual([2, 10, 11, 3])
  })

  it('WordPiece 子词切分（首 piece 不带 ##）', () => {
    const t = tok()
    // "helloworld" 不在 vocab → hello + ##world
    const e = t.encode('helloworld')
    const ids = e.inputIds.filter((_, i) => e.attentionMask[i] === 1)
    // [CLS](2) hello(8) ##world(9) [SEP](3)
    expect(ids).toEqual([2, 8, 9, 3])
  })

  it('完整中文词在 vocab 直接命中', () => {
    const t = tok()
    const e = t.encode('知识库')
    // 知识(12) ##库(13)
    const ids = e.inputIds.filter((_, i) => e.attentionMask[i] === 1)
    expect(ids).toEqual([2, 12, 13, 3])
  })

  it('OOV 单词 → [UNK]', () => {
    const t = tok()
    const e = t.encode('zzzz')
    const ids = e.inputIds.filter((_, i) => e.attentionMask[i] === 1)
    expect(ids).toEqual([2, 1, 3]) // [CLS] [UNK] [SEP]
  })

  it('maxLen 截断（预留 [SEP]）', () => {
    const t = tok(8)
    const e = t.encode('a'.repeat(50))
    expect(e.inputIds.length).toBe(8)
    expect(e.inputIds[7]).toBe(3) // 末尾 [SEP]
  })

  it('英文标点拆分', () => {
    const t = tok()
    // "hello,world" → hello , world
    const e = t.encode('hello,world')
    const ids = e.inputIds.filter((_, i) => e.attentionMask[i] === 1)
    // hello(8) ,(?) world... — 逗号不在小 vocab → [UNK]；world 单词在 → 单 token? vocab 无 "world" → [UNK] 或 hello+? 
    // 断言结构：CLS + 3+ 个有效 + SEP
    expect(ids[0]).toBe(2)
    expect(ids[ids.length - 1]).toBe(3)
    expect(ids.length).toBeGreaterThanOrEqual(5)
  })

  it('数字 token 命中', () => {
    const t = tok()
    const e = t.encode('0 1')
    const ids = e.inputIds.filter((_, i) => e.attentionMask[i] === 1)
    expect(ids).toEqual([2, 14, 15, 3])
  })
})
