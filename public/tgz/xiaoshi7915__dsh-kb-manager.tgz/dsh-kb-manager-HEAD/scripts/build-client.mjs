/**
 * 客户端 bundle 构建（esbuild → 模块表闭包包装）。
 *
 * 输入  : src/web/index.tsx（浏览器半入口，模块级 export inject + apply）
 * 输出  : lib/client.js（CJS + window.__ModuleLoader__.load 包装）
 *
 * 包装器与 harness 内置客户端包（packages/client/tsdown.client.ts 的 tsdown preset）
 * 产物同构：
 *   window.__ModuleLoader__.load({ id: '<包名>', factory: (require) => { ... } })
 * factory 收到的 require 由客户端模块表解析 external（react / react/jsx-runtime 等
 * PLATFORM_MODULES），其余依赖（zod、本包 wire 契约）全部内联。
 *
 * 运行：node scripts/build-client.mjs（npm run build 的第二步）
 */
import { build } from 'esbuild'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'))
const entry = resolve(root, 'src/web/index.tsx')
const outdir = resolve(root, 'lib')
const outfile = resolve(outdir, 'client.js')

await build({
  entryPoints: [entry],
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  outfile,
  jsx: 'automatic',
  // 模块表 external（PLATFORM_MODULES 子集）：其余全部内联。
  external: ['react', 'react/jsx-runtime'],
  logLevel: 'warning',
  metafile: false,
  define: {
    'process.env.NODE_ENV': JSON.stringify('production'),
  },
})

// 模块表闭包包装（tsdown.client.ts 的 banner/intro/footer 同构）
const raw = readFileSync(outfile, 'utf8')
mkdirSync(dirname(outfile), { recursive: true })
const wrapped = `/* dsh-kb-manager client bundle (esbuild + module-loader wrapper) */
window.__ModuleLoader__.load({ id: ${JSON.stringify(pkg.name)}, factory: (require) => {
var module = { exports: {} };
var exports = module.exports;
${raw}
return module.exports;
} });
`
writeFileSync(outfile, wrapped)
console.log(`[build-client] ${pkg.name} -> lib/client.js (${wrapped.length} bytes)`)
