export declare const TYPERT: {
    package: string;
    face: string;
    schemas: unknown[];
    invocations: import("@deepseek-ai/dsh-typert-protocol").InvocationDescriptor[];
    model: {
        services: {
            tags: never[];
            description: string;
            summary: string;
            key: string;
            exportName: string;
            members: {
                kind: string;
                name: string;
                signature: string;
            }[];
            types: never[];
        }[];
        events: never[];
        objects: never[];
    };
};
export default TYPERT;
