/**
 * Agent 工具定义（DESIGN §7 + 附录 C 定稿 docstring）。
 * 纯数据形态（name/description/parameters/execute），由 host-entry 映射到 DSH defineTool。
 * 返回值为 data 部分；统一信封由 runTool 包装。
 */
import type { KbManager } from '../index.ts';
import type { Envelope } from '../contracts/types.ts';
export interface ToolSpec {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
    execute: (args: Record<string, any>, m: KbManager) => unknown;
}
export declare const TOOLS_PREAMBLE: string;
export declare const TOOL_SPECS: ToolSpec[];
/** 统一执行入口：ToolSpec → 信封 */
export declare function executeTool<T = unknown>(m: KbManager, name: string, args: Record<string, any>): Promise<Envelope<T>>;
