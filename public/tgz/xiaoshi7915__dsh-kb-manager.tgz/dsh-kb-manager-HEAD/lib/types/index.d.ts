import type { DeepPartial, EmbeddingIdentity, Envelope, Job, KbConfig } from './contracts/types.ts';
import { ConfirmTokens } from './contracts/errors.ts';
import { type KbStore } from './store/store.ts';
import { JobQueue, type JobWork } from './jobs/queue.ts';
import { KbService } from './services/kb-service.ts';
import { DocService } from './services/doc-service.ts';
import { SearchService } from './services/search-service.ts';
import { SnapshotService } from './services/snapshot-service.ts';
import { ExportService } from './services/export-service.ts';
import type { JobType } from './contracts/types.ts';
export declare class KbManager {
    readonly root: string;
    cfg: KbConfig;
    readonly kbs: KbService;
    readonly docs: DocService;
    readonly search: SearchService;
    readonly snapshots: SnapshotService;
    readonly exports: ExportService;
    readonly jobs: JobQueue;
    readonly confirms: ConfirmTokens;
    workspace?: string;
    private embedderPromise;
    readonly stores: Map<string, KbStore>;
    storesAll(): KbStore[];
    constructor(root?: string, config?: DeepPartial<KbConfig> & {
        onJobEvent?: (job: Job) => void;
        workspace?: string;
    });
    /** 显式 kbId 的入队入口（export / import_kb / compact / rebuild 用；job 记在目标 KB 的 db 里） */
    enqueue(kbId: string, type: JobType, work: JobWork): Job;
    private loadConfigFile;
    saveConfig(): void;
    /** configure 白名单应用（DESIGN §8.5）：仅 12 项用户配置；storage_path 重启生效 */
    applyConfigPatch(patch: Record<string, unknown>): {
        updated: string[];
        restart_required: string[];
    };
    issueConfirm(scope: string): string;
    consumeConfirm(token: string, scope: string): boolean;
    close(): void;
}
/** 由当前配置推导默认 embedding 身份（建库时未显式指定则用）。
 *  MVP：onnx(bge-small-zh)/mock 固定 512；外部模型若维度不同，首次检索身份校验会报 EMB.DIMENSION_MISMATCH。 */
export declare function identityFromCfg(cfg: KbConfig): EmbeddingIdentity;
/** 统一执行包装：任何异常 → 错误信封（DESIGN §7.1） */
export declare function runTool<T>(fn: () => T | Promise<T>): Promise<Envelope<T>>;
