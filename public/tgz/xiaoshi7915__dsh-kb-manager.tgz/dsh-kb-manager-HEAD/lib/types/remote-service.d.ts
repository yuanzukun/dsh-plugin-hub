/**
 * KbManagerRemote —— dsh-kb-manager 的 Host Remote 服务（DESIGN §13.2 Web 数据面）。
 *
 * 继承 @deepseek-ai/dsh-typert-protocol 的 TypertRemoteService：
 * - 构造即 `ctx.reflect.provide('kbManager', this)`（fiber effect，随宿主条目卸载自动注销）
 * - `this.typertRemote` 绑定（serviceKey='kbManager', namespace='kbManager'）供 Gateway 校验
 * - 每个 @Remote 方法是 wire 描述符（src/remote.ts）的服务端实现：
 *   位置参数与描述符 parameters 顺序一一对应；返回值经 Gateway 的 strict result codec 后
 *   原样过线（z.unknown()），因此直接返回 runTool 信封即可
 *
 * 除 cancelJob 外的方法全部复用 executeTool（与 13 个 agent 工具同一执行入口，
 * 错误码 / 信封 / 审计完全一致）；cancelJob 在 MVP 无同名 agent 工具，直接走 JobQueue。
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { Envelope, Job, KbMeta, SearchResponse, DocChunkItem } from './contracts/types.ts';
import type { KbManager } from './index.ts';
import type { CancelJobResult, ConfigureResult, DeleteDocResult, DeleteKbDone, DeleteKbPending, DocListData, JobAccepted, KbListData, KbStats, MultiKbResult, ImportTextResult, RenameResult, RestorePending, SnapshotData, SnapshotListData } from './remote-types.ts';
export declare class KbManagerRemote extends TypertRemoteService {
    private readonly manager;
    constructor(ctx: Context, manager: KbManager);
    /** list_kbs：列出知识库（domain_tag 过滤 + 分页）。 */
    list(domain_tag?: string, limit?: number, offset?: number): Promise<Envelope<KbListData>>;
    /** get_kb：单库详情（含 embedding 身份）。 */
    detail(kb_id: string): Promise<Envelope<KbMeta>>;
    /** get_kb_stats：库统计。 */
    stats(kb_id: string): Promise<Envelope<KbStats>>;
    /** rename_kb：改库名（embedding 身份不变）。 */
    renameKb(kb_id: string, name: string): Promise<Envelope<RenameResult>>;
    /** multi_kb_search：跨库合并检索（同 embedding 硬校验）。 */
    multiKbSearch(kb_ids?: string[], query?: string, top_k?: number): Promise<Envelope<MultiKbResult>>;
    /** create_snapshot：快照恢复点。 */
    createSnapshot(kb_id: string, note?: string): Promise<Envelope<SnapshotData>>;
    /** list_snapshots：快照分页列表。 */
    listSnapshots(kb_id: string, limit?: number, offset?: number): Promise<Envelope<SnapshotListData>>;
    /** restore_snapshot：两步确认恢复（首次返回 token + impact）。 */
    restoreSnapshot(kb_id: string, snapshot_id: string, confirm_token?: string): Promise<Envelope<RestorePending | JobAccepted>>;
    /** export_kb：导出 kbpack（含向量）/ json（元数据+文本）。 */
    exportKb(kb_id: string, format?: string, output_path?: string, include_index?: boolean): Promise<Envelope<JobAccepted>>;
    /** import_kb：导入（create_new 建库 / merge 合入，kb_id 必填）。 */
    importKb(file_path: string, merge_strategy?: string, kb_id?: string): Promise<Envelope<JobAccepted>>;
    /** compact_index：整理碎片回收空间（异步）。 */
    compactIndex(kb_id: string): Promise<Envelope<JobAccepted>>;
    /** list_documents：文档分页列表（status 过滤）。 */
    docs(kb_id: string, status?: string, limit?: number, offset?: number): Promise<Envelope<DocListData>>;
    /** list_doc_chunks：按文档列出已入库分块（Web 面板“查看分块”）。 */
    listDocChunks(kb_id: string, doc_id: string): Promise<Envelope<DocChunkItem[]>>;
    /** search_kb：混合检索（top_k 1..50，默认走配置）。 */
    search(kb_id: string, query: string, top_k?: number): Promise<Envelope<SearchResponse>>;
    /** create_kb：建库（embedding 身份建后不可变）。 */
    create(name: string, description?: string, domain_tags?: string[]): Promise<Envelope<KbMeta>>;
    /** import_document：异步导入（立即返回 job_id，UI 轮询 job）。 */
    importDoc(kb_id: string, source: string, metadata?: Record<string, unknown>): Promise<Envelope<JobAccepted>>;
    /** importText：浏览器文件上传导入（Web 面板 input[type=file] 读文本 → 内容直达宿主，同步导入）。 */
    importText(kb_id: string, file_name: string, source_type: string, text: string, source_key?: string, metadata?: Record<string, unknown>): Promise<Envelope<ImportTextResult>>;
    /** delete_document：软删文档（重导同路径可恢复）。 */
    deleteDoc(kb_id: string, doc_id: string): Promise<Envelope<DeleteDocResult>>;
    /** get_job：任务状态轮询（只读幂等）。 */
    job(job_id: string): Promise<Envelope<Job>>;
    /** cancel_job：批边界协作式取消（MVP 独有，无同名 agent 工具）。 */
    cancelJob(job_id: string): Promise<Envelope<CancelJobResult>>;
    /** delete_kb：两步确认删库（token 由首次调用签发）。 */
    deleteKb(kb_id: string, confirm_token?: string): Promise<Envelope<DeleteKbPending | DeleteKbDone>>;
    /** rebuild_index：全量重建索引（异步；换引擎/换模型唯一合法路径）。 */
    rebuild(kb_id: string, target_engine?: string): Promise<Envelope<JobAccepted>>;
    /** configure：白名单配置热更。 */
    configure(patch: Record<string, unknown>): Promise<Envelope<ConfigureResult>>;
}
