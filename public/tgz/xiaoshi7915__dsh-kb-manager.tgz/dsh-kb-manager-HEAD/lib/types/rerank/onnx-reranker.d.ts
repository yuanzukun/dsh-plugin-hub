import type { Reranker, RerankCandidate } from '../index/rerank.ts';
export declare class OnnxReranker implements Reranker {
    private readonly modelDir;
    private readonly model;
    private session;
    private tokenizer;
    private ort;
    constructor(modelDir: string, model?: string);
    available(): boolean;
    /** 懒加载：onnxruntime → 确保模型/tokenizer 文件（自动下载 + sha256）→ session；失败向上抛 */
    ensureReady(): Promise<void>;
    /** 下载到临时文件 → sha256 校验 → 原子替换；失败清理（不落脏数据） */
    private ensureFile;
    rerank(query: string, candidates: RerankCandidate[], topN: number): Promise<Array<{
        chunk_id: string;
        score: number;
    }>>;
}
