/**
 * XLM-RoBERTa Unigram 分词器（bge-reranker-base，DESIGN §5.4）。
 * 对齐 transformers.js 的 XLM-R fast tokenizer（tokenizer.json）：
 * - 归一化：NFKC（JS 内置，近似 sentencepiece Precompiled charsmap 主体）+ 空格类/控制字符清理
 * - 预分词：Metaspace（add_prefix_space → 前缀空格；空格 → ▁）
 * - 模型：Unigram Viterbi（词表 log-score 上 DP + 回溯；<unk> 兜底）
 * - pair 编码：<s> A </s></s> B </s> → [0, A, 2, 2, B, 2]（XLM-R 无 token_type_ids）
 */
export interface XlmrEncoding {
    inputIds: number[];
    attentionMask: number[];
}
export declare class XlmrUnigramTokenizer {
    private readonly vocab;
    private readonly specialIds;
    readonly bosId = 0;
    readonly padId = 1;
    readonly eosId = 2;
    readonly unkId = 3;
    private readonly maxLen;
    private readonly maxTokenLen;
    constructor(tokenizerJson: {
        model?: {
            vocab?: Array<[string, number]>;
        };
        added_tokens?: Array<{
            id: number;
            special?: boolean;
        }>;
    }, maxLen?: number);
    vocabSize(): number;
    /** 近似 sentencepiece 归一化：NFKC + 全角空格→空格 + 控制字符清理（不 lowercase） */
    private normalize;
    /** Metaspace：add_prefix_space → 前缀空格；所有空格 → ▁ */
    private metaspace;
    /** Unigram Viterbi：最小负对数似然切分，返回 token 字符串数组 */
    private unigramSplit;
    /** pair 编码：<s> A </s></s> B </s>，截断 maxLen（为 2×</s> 预留），不 pad（ONNX 动态长度） */
    encodePair(query: string, passage: string): XlmrEncoding;
    /** 调试：输出 token 字符串 */
    debugPair(query: string, passage: string): string[];
}
