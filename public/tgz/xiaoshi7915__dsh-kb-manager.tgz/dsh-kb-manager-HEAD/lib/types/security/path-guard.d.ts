/** 解析并校验绝对路径在 allowedDirs 内；返回 realpath。 */
export declare function assertPathAllowed(rawPath: string, allowedDirs: string[], label?: string): string;
/** 校验文件存在且大小在限内（DESIGN: max_file_size_mb 硬上限） */
export declare function assertFileWithinLimit(realPath: string, maxFileBytes: number, label?: string): void;
