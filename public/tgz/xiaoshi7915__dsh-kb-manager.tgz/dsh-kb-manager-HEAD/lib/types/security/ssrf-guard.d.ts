/** 判断 IPv4 是否私网/环回/保留。覆盖设计列出的段 + 常见补充。 */
export declare function isPrivateIPv4(ip: string): boolean;
export declare function isPrivateIp(ip: string): boolean;
export interface SsrfOptions {
    allowlist?: string[];
    maxRedirects?: number;
}
/** 解析主机名的所有 IP 并逐一校验。 */
export declare function assertHostSafe(hostname: string, allowlist?: string[]): Promise<void>;
/**
 * 安全 fetch：协议限制 + 首跳与每次重定向逐跳校验。
 * 返回最终 Response（调用方负责读取 body）。
 */
export declare function safeFetch(url: string, opts?: SsrfOptions & {
    timeoutMs?: number;
}): Promise<Response>;
