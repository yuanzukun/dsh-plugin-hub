/**
 * 审计日志（DESIGN §8.6）：写入 kv.audit，环形保留最近 1000 条。
 */
import type Database from 'better-sqlite3';
type Db = Database.Database;
export interface AuditEntry {
    at: string;
    actor: string;
    action: string;
    target: string;
    detail?: string;
    ok: boolean;
}
export declare function audit(db: Db, entry: Omit<AuditEntry, 'at'> & {
    at?: string;
}): void;
export declare function recentAudits(db: Db, limit?: number): AuditEntry[];
export {};
