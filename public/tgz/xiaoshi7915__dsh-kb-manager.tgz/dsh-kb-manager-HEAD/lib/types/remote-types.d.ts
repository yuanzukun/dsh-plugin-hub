/**
 * dsh-kb-manager Remote 消费侧类型（浏览器安全，纯类型，无运行时导出）。
 *
 * `KbRemoteApi` 描述 `remote.kbManager` 命名空间句柄上已安装方法的行为：
 * 每个方法把描述符 parameters 按位置映射到实参，返回
 * `Promise<RemoteResult<T>>`（RemoteResult 来自 @deepseek-ai/dsh-typert-protocol，
 * 仅类型导入，不进 bundle）。
 */
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { DocInfo, DocChunkItem, EmbeddingIdentity, Envelope, Job, KbListItem, KbMeta, SearchResponse } from './contracts/types.ts';
/** list 的 data：{ total, kbs } */
export type KbListData = {
    total: number;
    kbs: KbListItem[];
};
/** stats 的 data（与 KbService.stats 返回同构） */
export type KbStats = {
    doc_count: number;
    chunk_count: number;
    index_size_bytes: number;
    avg_chunk_tokens: number;
    embedding: EmbeddingIdentity;
    backend: string;
    deleted_ratio: number;
};
/** docs 的 data：{ total, docs } */
export type DocListData = {
    total: number;
    docs: DocInfo[];
};
/** importDoc / rebuild 的 data：{ job_id, status: 'queued' } */
export type JobAccepted = {
    job_id: string;
    status: 'queued';
};
/** importText（浏览器文件上传）的 data：同步导入结果 */
export type ImportTextResult = {
    doc_id: string;
    file_name: string;
    chunk_count: number;
    status: 'ok' | 'unchanged' | 'restored' | 'unparseable';
    deduplicated: boolean;
    errors: string[];
};
/** deleteKb 首次调用的 data */
export type DeleteKbPending = {
    requires_confirm: true;
    confirm_token: string;
    impact: {
        docs: number;
        chunks: number;
        bytes: number;
    };
};
/** deleteKb 携带 token 的 data */
export type DeleteKbDone = {
    success: true;
    deleted_docs: number;
    freed_bytes: number;
};
/** deleteDoc 的 data */
export type DeleteDocResult = {
    success: true;
    removed_chunks: number;
};
/** configure 的 data */
export type ConfigureResult = {
    updated: string[];
    restart_required: string[];
};
/** cancelJob 的 data */
export type CancelJobResult = {
    job_id: string;
    status: Job['status'];
};
/** renameKb 的 data */
export type RenameResult = {
    kb_id: string;
    name: string;
};
/** multi_kb_search 的 data（results 带 source_kb / source_doc） */
export type MultiKbResult = {
    query: string;
    top_k: number;
    results: Array<{
        chunk_id: string;
        score: number;
        score_kind: 'rerank' | 'rrf';
        text: string;
        has_more: boolean;
        source_kb: string;
        source_doc: string;
    }>;
    total_candidates: number;
    total_hits: number;
    rerank: 'applied' | 'fallback_rrf' | 'disabled';
    cross_kb_comparable: boolean;
    elapsed_ms: number;
};
/** create_snapshot 的 data */
export type SnapshotData = {
    snapshot_id: string;
    created_at: string;
    note?: string;
    doc_count: number;
    size_bytes: number;
};
/** list_snapshots 的 data */
export type SnapshotListData = {
    total: number;
    snapshots: SnapshotData[];
};
/** restore_snapshot 首次调用（无 token）的 data */
export type RestorePending = {
    requires_confirm: true;
    confirm_token: string;
    impact: {
        restored_docs: number;
        removed_chunks: number;
        freed_bytes: number;
    };
};
/**
 * `remote.kbManager` 命名空间上的方法面。
 * 可省略实参直接传 undefined（描述符 acceptsUndefined）。
 */
export interface KbRemoteApi {
    list(domainTag?: string, limit?: number, offset?: number): Promise<RemoteResult<Envelope<KbListData>>>;
    detail(kbId: string): Promise<RemoteResult<Envelope<KbMeta>>>;
    stats(kbId: string): Promise<RemoteResult<Envelope<KbStats>>>;
    renameKb(kbId: string, name: string): Promise<RemoteResult<Envelope<RenameResult>>>;
    docs(kbId: string, status?: string, limit?: number, offset?: number): Promise<RemoteResult<Envelope<DocListData>>>;
    /** 按文档列出已入库分块（Web 面板“查看分块”）。 */
    listDocChunks(kbId: string, docId: string): Promise<RemoteResult<Envelope<DocChunkItem[]>>>;
    search(kbId: string, query: string, topK?: number): Promise<RemoteResult<Envelope<SearchResponse>>>;
    multiKbSearch(kbIds?: string[], query?: string, topK?: number): Promise<RemoteResult<Envelope<MultiKbResult>>>;
    create(name: string, description?: string, domainTags?: string[]): Promise<RemoteResult<Envelope<KbMeta>>>;
    createSnapshot(kbId: string, note?: string): Promise<RemoteResult<Envelope<SnapshotData>>>;
    listSnapshots(kbId: string, limit?: number, offset?: number): Promise<RemoteResult<Envelope<SnapshotListData>>>;
    restoreSnapshot(kbId: string, snapshotId: string, confirmToken?: string): Promise<RemoteResult<Envelope<RestorePending | JobAccepted>>>;
    importDoc(kbId: string, source: string, metadata?: Record<string, unknown>): Promise<RemoteResult<Envelope<JobAccepted>>>;
    /** 浏览器文件上传导入：传文本内容（file_name + source_type 决定解析器），同步导入返回 ImportResult */
    importText(kbId: string, fileName: string, sourceType: string, text: string, sourceKey?: string, metadata?: Record<string, unknown>): Promise<RemoteResult<Envelope<ImportTextResult>>>;
    deleteDoc(kbId: string, docId: string): Promise<RemoteResult<Envelope<DeleteDocResult>>>;
    job(jobId: string): Promise<RemoteResult<Envelope<Job>>>;
    cancelJob(jobId: string): Promise<RemoteResult<Envelope<CancelJobResult>>>;
    deleteKb(kbId: string, confirmToken?: string): Promise<RemoteResult<Envelope<DeleteKbPending | DeleteKbDone>>>;
    rebuild(kbId: string, targetEngine?: string): Promise<RemoteResult<Envelope<JobAccepted>>>;
    compactIndex(kbId: string): Promise<RemoteResult<Envelope<JobAccepted>>>;
    exportKb(kbId: string, format?: string, outputPath?: string, includeIndex?: boolean): Promise<RemoteResult<Envelope<JobAccepted>>>;
    importKb(filePath: string, mergeStrategy?: string, kbId?: string): Promise<RemoteResult<Envelope<JobAccepted>>>;
    configure(patch: Record<string, unknown>): Promise<RemoteResult<Envelope<ConfigureResult>>>;
}
