import type { Job, JobStage, JobType } from '../contracts/types.ts';
import type { KbStore } from '../store/store.ts';
export declare function stageLabel(stage: JobStage): string;
export type JobWork = (report: (done: number, total: number, stage: JobStage) => void, signal: AbortSignal) => Promise<unknown>;
interface QueueOpts {
    getStore: (kbId: string) => KbStore;
    listStores: () => KbStore[];
    onEvent?: (job: Job) => void;
    maxGlobal?: number;
}
export declare class JobQueue {
    private readonly getStore;
    private readonly listStores;
    private readonly onEvent?;
    private readonly maxGlobal;
    private readonly perKb;
    private readonly running;
    private readonly jobIndex;
    private processing;
    constructor(opts: QueueOpts);
    /** 启动时重建 job 索引 + 崩溃恢复；返回恢复的 Job 列表 */
    recover(): Job[];
    enqueue(kbId: string, type: JobType, work: JobWork): Job;
    /** get_job 入口：不携带 kb_id，经 jobIndex 定位 */
    get(jobId: string): Job | null;
    /** 返回 status：cancelled（已取消）/ 当前状态；终态由调用方按 JOB_ALREADY_TERMINAL 处理 */
    cancel(jobId: string): {
        job_id: string;
        status: Job['status'];
    };
    markNonInterruptible(jobId: string, on: boolean): void;
    private persist;
    private pump;
    private nextQueued;
    private run;
    private finish;
    static fromRow(r: {
        job_id: string;
        kb_id: string;
        type: string;
        status: string;
        progress_json: string;
        result_json: string | null;
        error_json: string | null;
        created_at: string;
        started_at: string | null;
        finished_at: string | null;
    }): Job;
}
export {};
