/**
 * 解析器注册表（DESIGN §3.1：统一 parse()→ParsedDoc 边界）。
 * PDF/DOCX：MVP 先标记为暂不可解析（parser 接入 pdfjs-dist / mammoth 在实现期，见 §12）。
 */
import type { ParsedDoc } from '../contracts/types.ts';
export interface Parser {
    parse(text: string, fileName: string): ParsedDoc;
}
export declare const parsers: Record<string, Parser>;
export declare function extOf(fileName: string): string;
export declare function isSupported(fileName: string, sourceType?: string): boolean;
/** 解析入口；不支持的类型抛 DOC.UNSUPPORTED_TYPE（doc-service 转 unparseable 处理） */
export declare function parseDocument(text: string, fileName: string, sourceType?: string): ParsedDoc;
