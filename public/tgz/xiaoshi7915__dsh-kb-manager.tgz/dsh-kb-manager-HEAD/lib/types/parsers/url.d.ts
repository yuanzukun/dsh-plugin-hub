export interface FetchResult {
    text: string;
    finalUrl: string;
    fromCache: boolean;
}
/** 白名单内抓取；缓存 key = sha256(规范化 URL) */
export declare function fetchUrl(url: string, cacheDir: string, opts?: {
    allowlist?: string[];
    maxBytes?: number;
    timeoutMs?: number;
}): Promise<FetchResult>;
