/**
 * JSON 解析器（DESIGN §5.1）：递归拍平为 "path: value" 行后按段落切块。
 */
import type { ParsedDoc } from '../contracts/types.ts';
export declare function parseJson(text: string, fileName: string): ParsedDoc;
