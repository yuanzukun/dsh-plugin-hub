/**
 * CSV 解析器（DESIGN §5.1）：每 csv_rows_per_chunk 行一块 + 表头重复。
 * 实现为：整表按行切成 para 块（每块 = 表头 + N 行，Markdown 表格表达），
 * 行数分块由 chunker 的 table 单元逻辑统一处理——此处按行组产出 table 块。
 */
import type { ParsedDoc } from '../contracts/types.ts';
/** 极简 CSV 行解析（支持双引号转义） */
export declare function parseCsvLine(line: string): string[];
export declare function parseCsv(text: string, fileName: string, rowsPerChunk?: number): ParsedDoc;
