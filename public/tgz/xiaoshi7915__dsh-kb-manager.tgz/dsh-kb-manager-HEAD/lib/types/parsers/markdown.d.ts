/**
 * Markdown 解析器：heading 层级 / 段落 / 表格（GFM）。
 * 表格转 Markdown 表格文本（供 chunker 整表/按行切，DESIGN §5.1）。
 */
import type { ParsedDoc } from '../contracts/types.ts';
export declare function parseMarkdown(text: string, fileName: string): ParsedDoc;
