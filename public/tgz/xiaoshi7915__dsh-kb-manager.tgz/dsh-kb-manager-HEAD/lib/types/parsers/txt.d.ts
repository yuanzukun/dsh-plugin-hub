/**
 * 纯文本解析器：按空行分段。
 */
import type { ParsedDoc } from '../contracts/types.ts';
export declare function parseTxt(text: string, fileName: string): ParsedDoc;
