/**
 * 最小 HTML → 文本（MVP）：去 script/style、块级标签换行、解码实体。
 * 升级路径：换 turndown 获得标题/表格结构（v1.1 评估）。
 */
import type { ParsedDoc } from '../contracts/types.ts';
export declare function htmlToText(html: string): string;
export declare function parseHtml(html: string, fileName: string): ParsedDoc;
