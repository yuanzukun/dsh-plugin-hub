/**
 * kb.db 存储层（DESIGN §4）。每 KB 一个 SQLite 库：
 * documents / chunks / chunks_fts / vec_chunks / snapshots / jobs / kv。
 * 原子性 = 单库单事务；快照 = online backup 副本 + manifest（§4.3）。
 */
import Database from 'better-sqlite3';
import type { Job, KbMeta } from '../contracts/types.ts';
export declare const KB_SCHEMA_VERSION = 1;
export interface KbStore {
    db: Database.Database;
    kbDir: string;
    metaPath: string;
    close(): void;
}
/** 打开（或创建）一个 KB 库；加载 sqlite-vec 扩展并迁移到当前 schema。 */
export declare function openKbStore(kbDir: string): KbStore;
/** 事务封装：fn 抛错即整体回滚（§4.3 原子性根因） */
export declare function tx<T>(store: KbStore, fn: (db: Database.Database) => T): T;
export declare function readMeta(store: KbStore): KbMeta | null;
export declare function writeMeta(store: KbStore, meta: KbMeta): void;
export declare function createSnapshot(store: KbStore, snapshotId: string, note?: string): Promise<{
    snapshot_id: string;
    created_at: string;
    size_bytes: number;
    doc_count: number;
}>;
export declare function listSnapshots(store: KbStore, limit?: number, offset?: number): Array<{
    snapshot_id: string;
    created_at: string;
    note: string | null;
    doc_count: number;
    size_bytes: number;
}>;
export declare function readSnapshotManifest(store: KbStore, snapshotId: string): Record<string, unknown> | null;
/** 恢复：替换 kb.db（调用方须先自动备份当前状态，见 doc-service） */
export declare function restoreSnapshotDb(store: KbStore, snapshotId: string): void;
export declare function persistJob(store: KbStore, job: Job): void;
/** 进程重启后：遗留 running → failed(JOB.INTERRUPTED, retryable) */
export declare function recoverInterruptedJobs(store: KbStore): Job[];
