/**
 * dsh-kb-manager 核心契约：类型、错误码、配置默认值。
 * 依据 DESIGN.md v2.1 §4/§5/§6/§7/§11。本文件无任何实现依赖。
 */
export interface EmbeddingIdentity {
    model: string;
    provider: string;
    dim: number;
}
export type KbBackend = 'sqlite-vec' | 'usearch';
/** KB 数据态四态（DESIGN §4/§9；rerank 不可用是 UI 叠加态，不是数据态） */
export type KbStatus = 'empty' | 'building' | 'ready' | 'error';
export interface KbMeta {
    kb_id: string;
    name: string;
    description?: string;
    domain_tags: string[];
    embedding: EmbeddingIdentity;
    backend: KbBackend;
    status: KbStatus;
    schema_version: number;
    created_at: string;
    updated_at: string;
}
export interface KbListItem {
    kb_id: string;
    name: string;
    doc_count: number;
    index_status: KbStatus;
    last_updated: string;
}
export type DocSourceType = 'pdf' | 'docx' | 'html' | 'md' | 'txt' | 'csv' | 'json' | 'url';
/** 软删是独立状态：deleted 文档默认不列出、检索不可见，可经重导恢复 */
export type DocImportStatus = 'importing' | 'ok' | 'unparseable' | 'failed' | 'deleted';
export interface DocInfo {
    doc_id: string;
    file_name: string;
    source_type: DocSourceType;
    source_key: string;
    content_hash: string;
    status: DocImportStatus;
    chunk_count: number;
    size_bytes: number;
    metadata_json: string;
    imported_at: string;
    updated_at: string;
}
export type ParsedBlock = {
    kind: 'heading';
    level: number;
    text: string;
    page_num?: number;
} | {
    kind: 'para';
    text: string;
    page_num?: number;
} | {
    kind: 'table';
    markdown: string;
    page_num?: number;
    rows: number;
    cols: number;
};
export interface ParsedDoc {
    source_type: DocSourceType;
    file_name: string;
    blocks: ParsedBlock[];
    page_count?: number;
}
export type ChunkStrategy = 'fixed' | 'recursive' | 'semantic';
export interface ChunkingParams {
    chunkSize: number;
    chunkOverlap: number;
    strategy: ChunkStrategy;
    tableChunkMaxTokens: number;
    csvRowsPerChunk: number;
}
/** chunker 产出；doc-service 负责落库时补 id */
export interface ChunkDraft {
    text: string;
    heading_path: string;
    heading_level: number | null;
    page_num: number | null;
    char_start: number;
    char_end: number;
    token_count: number;
    table_detected: boolean;
    metadata: Record<string, unknown>;
}
export interface ChunkRow extends ChunkDraft {
    chunk_id: string;
    doc_id: string;
    ord: number;
    deleted: 0 | 1;
}
/** 按文档列出分块的轻量条目（Web 面板“查看分块”用）。 */
export interface DocChunkItem {
    chunk_id: string;
    ord: number;
    text: string;
    heading_path: string;
    page_num: number | null;
    token_count: number;
}
export type RerankStatus = 'applied' | 'fallback_rrf' | 'disabled';
export type ScoreKind = 'rerank' | 'rrf';
export interface SearchHit {
    chunk_id: string;
    score: number;
    score_kind: ScoreKind;
    text: string;
    has_more: boolean;
    source_doc: string;
    page_num: number | null;
    heading_path: string;
    source_kb?: string;
    untrusted: true;
}
export interface SearchFilters {
    docs?: string[];
    doc_globs?: string[];
    headings?: string[];
    page_range?: [number, number];
}
export interface SearchResponse {
    query: string;
    top_k: number;
    results: SearchHit[];
    total_candidates: number;
    total_hits: number;
    rerank: RerankStatus;
    /** multi_kb_search 专属：跨库分数是否可比（DESIGN §5.5） */
    cross_kb_comparable?: boolean;
    elapsed_ms: number;
}
export type JobType = 'import' | 'import_kb' | 'rebuild' | 'reindex' | 'restore' | 'export' | 'compact' | 'delete_kb';
export type JobStatus = 'queued' | 'running' | 'done' | 'failed' | 'cancelled';
export type JobStage = 'reading' | 'parsing' | 'chunking' | 'embedding' | 'indexing' | 'copying' | 'restoring';
export interface JobProgress {
    done: number;
    total: number;
    stage: JobStage;
    stage_label: string;
}
export interface Job {
    job_id: string;
    type: JobType;
    kb_id: string;
    status: JobStatus;
    progress: JobProgress;
    result?: unknown;
    error?: {
        code: string;
        message: string;
        hint?: string;
    };
    created_at: string;
    started_at?: string;
    finished_at?: string;
}
export interface ToolError {
    code: string;
    message: string;
    hint?: string;
}
export type Envelope<T> = {
    ok: true;
    data: T;
} | {
    ok: false;
    error: ToolError;
};
export type DeepPartial<T> = {
    [K in keyof T]?: T[K] extends (infer U)[] ? T[K] : T[K] extends object ? DeepPartial<T[K]> : T[K];
};
export interface KbConfig {
    storage_path: string;
    embedding: {
        model: string;
        /** 'mock' 仅开发/测试用（3-gram 弱语义向量），不开放给 configure 工具 */
        provider: 'onnx' | 'ollama' | 'openai-compat' | 'mock';
        base_url: string;
        api_key_ref: string;
        instruction: string;
    };
    chunk_size: number;
    chunk_overlap: number;
    chunk_strategy: ChunkStrategy;
    chunker_tokenizer: 'segmenter';
    table_chunk_max_tokens: number;
    csv_rows_per_chunk: number;
    top_k: number;
    result_text_max_chars: number;
    enable_rerank: boolean;
    rerank_model: string;
    rerank_min_score: number;
    rrf_k: number;
    candidate_mult: number;
    index_backend: 'auto' | 'sqlite-vec' | 'usearch';
    engine_upgrade_threshold: number;
    compact_threshold: number;
    snapshots_max: number;
    auto_sync_dir: string;
    auto_sync_interval: number;
    max_file_size_mb: number;
    import_allowed_dirs: string[];
    import_url_allowlist: string[];
    config_version: number;
}
/** configure 工具白名单 = 12 项用户配置（embedding 计一组，DESIGN §11） */
export declare const CONFIG_WHITELIST: ReadonlyArray<string | readonly string[]>;
export declare const DEFAULT_CONFIG: KbConfig;
export declare const DEFAULT_EMBEDDING_IDENTITY: EmbeddingIdentity;
