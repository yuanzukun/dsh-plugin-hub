/**
 * 三层错误码 + 统一信封（DESIGN §7.1）。
 * 错误码以 DESIGN v2.1 附录 C docstring 中出现的形式为权威拼写。
 */
import type { Envelope, ToolError } from './types.ts';
export declare const ErrorCodes: {
    readonly CFG_EMBEDDING_NOT_CONFIGURED: "CFG.EMBEDDING.NOT_CONFIGURED";
    readonly CFG_KEY_INVALID: "CFG.KEY.INVALID";
    readonly KB_NOT_FOUND: "KB.NOT_FOUND";
    readonly KB_NAME_CONFLICT: "KB_NAME_CONFLICT";
    readonly KB_BUSY: "KB.BUSY";
    readonly DOC_NOT_FOUND: "DOC.NOT_FOUND";
    readonly DOC_TOO_LARGE: "DOC.TOO_LARGE";
    readonly DOC_UNSUPPORTED_TYPE: "DOC.UNSUPPORTED_TYPE";
    readonly DOC_PARSE_FAILED: "DOC.PARSE_FAILED";
    readonly SEC_PATH_DENIED: "SEC.PATH.DENIED";
    readonly SEC_URL_DENIED: "SEC.URL.DENIED";
    readonly SEC_CONFIRM_REQUIRED: "SEC.CONFIRM_REQUIRED";
    readonly EMB_MODEL_UNREACHABLE: "EMB.MODEL_UNREACHABLE";
    readonly EMB_DIMENSION_MISMATCH: "EMB.DIMENSION_MISMATCH";
    readonly EMB_NOT_READY: "EMB.NOT_READY";
    readonly IDX_NOT_READY: "IDX.NOT_READY";
    readonly IDX_CORRUPT: "IDX.CORRUPT";
    readonly IDX_ENGINE_BUSY: "IDX.ENGINE_BUSY";
    readonly SRCH_BAD_FILTER: "SRCH.BAD_FILTER";
    readonly SRCH_TOPK_OUT_OF_RANGE: "SRCH.TOPK_OUT_OF_RANGE";
    readonly JOB_NOT_FOUND: "JOB.NOT_FOUND";
    readonly JOB_ALREADY_TERMINAL: "JOB.ALREADY_TERMINAL";
    readonly JOB_INTERRUPTED: "JOB.INTERRUPTED";
    readonly FS_DISK_FULL: "FS.DISK_FULL";
    readonly FS_IO: "FS.IO";
};
export type ErrorCode = (typeof ErrorCodes)[keyof typeof ErrorCodes];
export declare class KbError extends Error {
    readonly code: string;
    readonly hint?: string;
    constructor(code: string, message: string, hint?: string);
    get retryable(): boolean;
    toToolError(): ToolError;
}
export declare function ok<T>(data: T): Envelope<T>;
/** 把任意异常归一为错误信封：KbError 保留 code/hint，其余归 FS.IO 兜底 */
export declare function err(e: unknown): Envelope<never>;
/** 两步确认 token（DESIGN §8.4）：5 分钟有效，单用 */
export declare class ConfirmTokens {
    private readonly ttlMs;
    private readonly tokens;
    constructor(ttlMs?: number);
    issue(scope: string): string;
    consume(token: string, scope: string): boolean;
}
