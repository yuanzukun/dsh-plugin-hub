import type { KbRemoteApi } from '../remote-types.ts';
import type { KbLocaleKey } from './locales.ts';
export interface KbSectionInjected {
    /** 取 remote.kbManager 命名空间句柄（挂载期已 $mount）。 */
    kb: () => KbRemoteApi;
    /** 取 remote.directoryPicker（宿主原生目录选择器；未挂载时为 undefined）。 */
    pickDir: () => DirPickerRemote | undefined;
    /** 本命名空间翻译函数（locale 切换时经壳层重注册保持新鲜）。 */
    t: (key: KbLocaleKey) => string;
}
/**
 * DSH 系统 remote 命名空间 remote.directoryPicker（宿主原生选择器）。
 * 仅声明本插件实际使用的 pick()；运行时不 import 任何 @deepseek-ai 客户端包。
 */
export interface DirPickerRemote {
    pick(): Promise<{
        ok: boolean;
        value?: string | null;
        error?: {
            code?: string;
            message?: string;
        };
    }>;
}
export type KbSectionProps = {
    close: () => void;
} & KbSectionInjected;
export declare function KbSection({ kb, t }: KbSectionProps): import("react").JSX.Element;
