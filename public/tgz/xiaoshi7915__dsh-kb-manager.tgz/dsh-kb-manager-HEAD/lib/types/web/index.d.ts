/**
 * dsh-kb-manager 浏览器半（settings.section 注册 + KB 管理页）。
 *
 * 装配方式与 harness 内置插件一致（参见 ui-settings-models）：
 * - 模块级 `inject` 声明 DI 依赖（slots / locale / remote），boot 据此排定激活顺序
 * - apply()：注册文案命名空间 → $mount typert Remote 贡献（安装 remote.kbManager
 *   命名空间，客户端侧纯本地安装，无 host 往返）→ 注入 settings.section 条目
 *   （id 'kb-manager'，order 90）
 * - 不注入 'remote.kbManager' 服务本身：它由本插件 $mount 安装，避免自引用死锁
 *
 * 类型策略：npm 上发布的 @deepseek-ai 客户端包（dsh-client-* / dsh-api-gateway）
 * 硬依赖若干未发布的内部包（dsh-paths / dsh-type-meta），无法作为 devDependency
 * 安装；本文件因此按运行时行为声明所需结构类型（ctx-types），不 import 任何
 * @deepseek-ai 客户端包。wire 契约类型仍来自 dsh-typert-protocol（已发布）。
 *
 * 本文件是 esbuild 入口（scripts/build-client.mjs）；产物 lib/client.js 由客户端
 * 模块表加载（window.__ModuleLoader__.load 包装）。运行时值依赖仅 react（external，
 * 模块表解析）+ zod/本包 wire 契约（内联）——无其他 @deepseek-ai 值导入。
 */
import type { RemoteResult, TypertRemoteContribution, TypertRemoteNamespace } from '@deepseek-ai/dsh-typert-protocol';
import type { Envelope, Job, KbMeta, SearchResponse } from '../contracts/types.ts';
import type { CancelJobResult, ConfigureResult, DeleteDocResult, DeleteKbDone, DeleteKbPending, DocListData, JobAccepted, KbListData, KbStats } from '../remote-types.ts';
/**
 * 本插件的 Remote 消费面：与 host 清单（src/remote.ts KB_INVOCATIONS）同源，
 * 使 `remote.kbManager.<method>` 获得完整类型。
 */
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface TypertRemoteMap {
        'kbManager/list': (domainTag?: string, limit?: number, offset?: number) => Promise<RemoteResult<Envelope<KbListData>>>;
        'kbManager/detail': (kbId: string) => Promise<RemoteResult<Envelope<KbMeta>>>;
        'kbManager/stats': (kbId: string) => Promise<RemoteResult<Envelope<KbStats>>>;
        'kbManager/docs': (kbId: string, status?: string, limit?: number, offset?: number) => Promise<RemoteResult<Envelope<DocListData>>>;
        'kbManager/search': (kbId: string, query: string, topK?: number) => Promise<RemoteResult<Envelope<SearchResponse>>>;
        'kbManager/create': (name: string, description?: string, domainTags?: string[]) => Promise<RemoteResult<Envelope<KbMeta>>>;
        'kbManager/importDoc': (kbId: string, source: string, metadata?: Record<string, unknown>) => Promise<RemoteResult<Envelope<JobAccepted>>>;
        'kbManager/deleteDoc': (kbId: string, docId: string) => Promise<RemoteResult<Envelope<DeleteDocResult>>>;
        'kbManager/job': (jobId: string) => Promise<RemoteResult<Envelope<Job>>>;
        'kbManager/cancelJob': (jobId: string) => Promise<RemoteResult<Envelope<CancelJobResult>>>;
        'kbManager/deleteKb': (kbId: string, confirmToken?: string) => Promise<RemoteResult<Envelope<DeleteKbPending | DeleteKbDone>>>;
        'kbManager/rebuild': (kbId: string, targetEngine?: string) => Promise<RemoteResult<Envelope<JobAccepted>>>;
        'kbManager/configure': (patch: Record<string, unknown>) => Promise<RemoteResult<Envelope<ConfigureResult>>>;
    }
    interface TypertRemoteNamespaceMap {
        kbManager: TypertRemoteNamespace<'kbManager'>;
    }
}
/**
 * 客户端 ctx 的运行时结构面（等价于 dsh-client-runtime 的 ClientContext，
 * 按实际使用的成员声明，避免依赖未完整发布的客户端包类型）。
 */
interface LocaleFace {
    register(namespace: string, dicts: Record<string, Record<string, string>>): void;
    bind(namespace: string): (key: string) => string;
}
interface SlotEntryOptions {
    name: string;
    id?: string;
    order?: number;
    label?: string | (() => string);
    locale?: string;
    inject?: () => object;
    children?: Record<string, unknown>;
}
interface SlotsFace {
    inject(slot: string, factory: () => void): void;
    register(options: SlotEntryOptions, component: (props: unknown) => unknown): void;
}
interface ClientCtx {
    effect(fn: () => void | (() => void), label?: string): void;
    get(name: string): unknown;
    locale: LocaleFace;
    slots: SlotsFace;
    remote: {
        $mount(contribution: TypertRemoteContribution): Promise<() => Promise<void>>;
        kbManager: TypertRemoteNamespace<'kbManager'>;
    };
}
/**
 * DSH 系统 remote 命名空间 remote.directoryPicker（宿主原生目录选择器）。
 * 类型定义见 KbSection.tsx（避免 index→KbSection→index 循环引用）。
 */
/** DI 依赖（boot graph 据此推导激活顺序；remote 是 client 基线服务）。 */
export declare const inject: string[];
export declare function apply(ctx: ClientCtx): Promise<() => Promise<void>>;
export {};
