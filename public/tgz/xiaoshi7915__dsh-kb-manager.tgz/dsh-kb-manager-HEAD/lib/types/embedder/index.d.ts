/**
 * Embedding 工厂（DESIGN §5.2）：按 provider 构造；onnx 默认，其余可选。
 * 组合磁盘缓存（sha256(model|provider|dim|text)）。
 */
import type { KbConfig } from '../contracts/types.ts';
import type { Embedder } from './embedder.ts';
export type { Embedder } from './embedder.ts';
export type EmbedderFactory = (cfg: KbConfig, storagePath: string) => Promise<Embedder>;
export declare const embedderFactory: EmbedderFactory;
/** 开发/测试入口：mock provider 显式声明（不出现在生产配置里） */
export declare function devEmbedder(dim?: number): Embedder;
