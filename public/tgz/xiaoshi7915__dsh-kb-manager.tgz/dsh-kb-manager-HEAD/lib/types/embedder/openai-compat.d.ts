/**
 * openai-compat provider：任意兼容 /v1/embeddings 的本地/远端服务（DESIGN §5.2）。
 * 加 provider 是配置项不是架构变更。
 */
import type { EmbeddingIdentity } from '../contracts/types.ts';
import type { Embedder } from './embedder.ts';
export interface CompatConfig {
    baseUrl: string;
    apiKeyRef: string;
    model: string;
    dim: number;
}
export declare class OpenAiCompatEmbedder implements Embedder {
    private cfg;
    constructor(cfg: CompatConfig);
    identity(): EmbeddingIdentity;
    embed(texts: string[], signal?: AbortSignal): Promise<number[][]>;
    private callBatch;
}
