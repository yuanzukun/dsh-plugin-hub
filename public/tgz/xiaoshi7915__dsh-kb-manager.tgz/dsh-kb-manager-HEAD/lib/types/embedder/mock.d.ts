import type { EmbeddingIdentity } from '../contracts/types.ts';
import type { Embedder } from './embedder.ts';
export declare class MockNgramEmbedder implements Embedder {
    private readonly dim;
    constructor(dim?: number);
    identity(): EmbeddingIdentity;
    embed(texts: string[], _signal?: AbortSignal): Promise<number[][]>;
    private encode;
}
