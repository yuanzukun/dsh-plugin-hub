export declare class EmbeddingCache {
    private readonly dir;
    constructor(dir: string);
    private pathFor;
    get(key: string, dim: number): Float32Array | null;
    set(key: string, vec: number[]): void;
    /** 批量命中检测：返回 [cacheKey 命中?, 未命中 index 列表] */
    probe(keys: string[], dim: number): {
        cached: Array<Float32Array | null>;
        misses: number[];
    };
}
export declare function cacheKeyOf(key: string): string;
