/**
 * BERT WordPiece 分词器（bge-small-zh-v1.5，DESIGN §5.2 拍板⑤'）。
 * 对齐 transformers BertTokenizer 的 BasicTokenizer + WordPieceTokenizer：
 * - clean_text：空白归一、控制字符移除
 * - tokenize_chinese_chars：CJK 两侧加空格（中文逐字）
 * - 按空白/标点切分；WordPiece 最长前缀匹配，首 piece 不带 ##、后续带 ##
 * - 组装 [CLS]…[SEP]，截断 maxLen，[PAD] 补齐，输出 input_ids / attention_mask / token_type_ids
 */
export interface BertEncoding {
    inputIds: number[];
    attentionMask: number[];
    tokenTypeIds: number[];
}
export declare class BertTokenizer {
    private readonly vocab;
    readonly unkId: number;
    readonly clsId: number;
    readonly sepId: number;
    readonly padId: number;
    private readonly maxLen;
    constructor(vocabText: string, maxLen?: number);
    vocabSize(): number;
    private cleanText;
    private tokenizeChineseChars;
    private runSplitOnPunc;
    private basicTokenize;
    /** WordPiece：首 piece 原 token，后续 ## 前缀；任一字缺失 → null（整体 [UNK]） */
    private wordPiece;
    encode(text: string): BertEncoding;
    /** 调试：输出 token 序列（[CLS]…[SEP] 不含 padding） */
    debugTokens(text: string): string[];
}
