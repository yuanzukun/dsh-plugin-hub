import type { EmbeddingIdentity } from '../contracts/types.ts';
import type { Embedder } from './embedder.ts';
export declare class OnnxEmbedder implements Embedder {
    private readonly modelDir;
    private readonly model;
    private readonly dim;
    private session;
    private tokenizer;
    private ort;
    constructor(modelDir: string, model?: string, dim?: number);
    identity(): EmbeddingIdentity;
    /** 懒加载：加载 onnxruntime → 确保模型/vocab 文件（首次自动下载 + sha256 校验）→ WordPiece → session */
    ensureReady(confirmDownload: (url: string) => Promise<boolean>): Promise<void>;
    /** 下载到临时文件 → sha256 校验 → 原子替换；失败清理临时文件（不落脏数据） */
    private ensureModelFile;
    embed(texts: string[], signal?: AbortSignal): Promise<number[][]>;
}
