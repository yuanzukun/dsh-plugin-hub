import type { EmbeddingIdentity } from '../contracts/types.ts';
export interface Embedder {
    identity(): EmbeddingIdentity;
    /** 返回与 texts 等长的向量数组（已 L2 归一化） */
    embed(texts: string[], signal?: AbortSignal): Promise<number[][]>;
}
export declare const EMBED_BATCH = 32;
export declare function embedKey(model: string, provider: string, dim: number, text: string): string;
export declare function assertSameIdentity(a: EmbeddingIdentity, b: EmbeddingIdentity, where?: string): void;
/** 指数退避重试（3 次，仅对可重试错误） */
export declare function withRetry<T>(fn: () => Promise<T>, what: string): Promise<T>;
