/** 分块策略注册（DESIGN §5.1）：fixed / recursive 在 MVP；semantic 在 v1.2。 */
import type { ChunkDraft, ChunkingParams, ParsedDoc } from '../contracts/types.ts';
import { countTokens } from './tokens.ts';
export type Chunker = (doc: ParsedDoc, p: ChunkingParams) => ChunkDraft[];
export declare const chunkers: Record<string, Chunker>;
export declare function chunkDocument(doc: ParsedDoc, p: ChunkingParams): ChunkDraft[];
/** 预览采样（DESIGN §9：前 2 万字符） */
export declare function previewText(text: string, maxChars?: number): string;
export { countTokens };
