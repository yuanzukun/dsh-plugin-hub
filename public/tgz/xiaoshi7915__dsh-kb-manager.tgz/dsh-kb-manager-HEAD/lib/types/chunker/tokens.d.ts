/**
 * token 计数（DESIGN §5.1：分块以 token 为单位）。
 * MVP 近似器：面向 bge 系分词器（WordPiece）的启发式估计——
 *   CJK 字符 ≈ 1 token/字；ASCII 单词 ≈ 1 token/词（多音节词实际 1-2，偏保守取 1）；
 *   其它非空白连续段 ≈ 1 token/段。
 * 略高估英文是安全的方向（宁可早切、不超窗口）。
 * 接口隔离在 countTokens()：接入真实 bge tokenizer（随 ONNX 模型词表）只改此文件。
 */
export declare function countTokens(text: string): number;
/** 按 token 预算从 text 的 [0, len) 找到不超预算的前缀长度（字符级） */
export declare function prefixWithinBudget(text: string, budget: number): number;
