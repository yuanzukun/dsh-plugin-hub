/**
 * 分块核心（DESIGN §5.1）。
 * - recursive（默认）：block 优先；超预算块按分隔符层级 \n\n → \n → 。！？；!?; → 空格 拆分
 * - heading 感知：标题进入当前块首行，heading_path 栈随 level 维护
 * - 表格：≤ table_chunk_max_tokens 整表一块；超预算按行切 + 表头重复 + table_detected
 * - 贪心合并；仅当块因预算溢出被强制刷新时，尾部回卷 chunk_overlap 个 token 作下一块前缀
 */
import type { ChunkDraft, ChunkingParams, ParsedDoc } from '../contracts/types.ts';
interface Unit {
    text: string;
    isTable: boolean;
    page_num: number | null;
    heading_path: string;
    heading_level: number | null;
    /** 块起始时的文档字符偏移（近似，按单元顺序累计） */
    char_start: number;
}
/** ParsedDoc blocks → 带 heading 上下文的单元序列（表格已按预算预切）。 */
export declare function blocksToUnits(doc: ParsedDoc, tableMax: number): Unit[];
/** 超预算文本按分隔符层级贪心拆分。 */
export declare function splitLongText(text: string, budget: number): string[];
/** 取 text 尾部约 n 个 token 的原文（从词边界回卷）。 */
export declare function tailFromTokens(text: string, tokens: number): string;
/** recursive 主流程：缓冲 + 边界刷新 + 溢出回卷。 */
export declare function chunkRecursive(doc: ParsedDoc, p: ChunkingParams): ChunkDraft[];
/** fixed 策略：纯 token 滑窗（无结构感知），仅用于对比评测。 */
export declare function chunkFixed(doc: ParsedDoc, p: ChunkingParams): ChunkDraft[];
export {};
