import type { DocInfo, DocChunkItem, DocSourceType, KbConfig } from '../contracts/types.ts';
import { previewText } from '../chunker/index.ts';
import type { Embedder } from '../embedder/embedder.ts';
import type { JobStage } from '../contracts/types.ts';
import type { KbService } from './kb-service.ts';
export interface ImportResult {
    doc_id: string;
    file_name: string;
    chunk_count: number;
    status: 'ok' | 'unchanged' | 'restored' | 'unparseable';
    deduplicated: boolean;
    errors: string[];
}
export declare class DocService {
    private readonly kbs;
    private readonly embedder;
    private readonly cfg;
    private readonly workspace?;
    constructor(kbs: KbService, embedder: () => Promise<Embedder>, cfg: () => KbConfig, workspace?: string | undefined);
    /** 默认导入白名单：会话 workspace + 存储 inbox（DESIGN §12 路径白名单） */
    private defaultAllowedDirs;
    /** 文档状态 → WHERE 白名单（B3：防非法状态拼 SQL 崩库/注入；DESIGN §7.3） */
    private static readonly DOC_STATUS_WHERE;
    listDocuments(kbId: string, opts?: {
        status?: string;
        limit?: number;
        offset?: number;
    }): {
        total: number;
        docs: DocInfo[];
    };
    getDocument(kbId: string, docId: string): DocInfo;
    /** 按文档列出已入库分块（deleted=0，按 ord 排序），供 Web 面板“查看分块”。 */
    listDocChunks(kbId: string, docId: string): DocChunkItem[];
    /** 同步软删（DESIGN §4.4）：毫秒级；检索立即可见性消失；物理回收走 compact_index。 */
    deleteDocument(kbId: string, docId: string): {
        success: boolean;
        removed_chunks: number;
    };
    /**
     * 导入工作函数（由 JobQueue 调度执行）。
     * report 回调推进 job 进度（stage 序列：reading → parsing → chunking → embedding → indexing）。
     */
    importWork(kbId: string, source: string, sourceType: DocSourceType | 'auto', metadata?: Record<string, unknown>): (report: (done: number, total: number, stage: JobStage) => void, signal: AbortSignal) => Promise<ImportResult>;
    /**
     * 从包内文本导入单文档（import_kb 的 onImported 复用管线）。
     * source_key 幂等：同 key 未变 → unchanged；变化 → 就地替换（旧块 tombstone）。
     * 解析失败登记 unparseable（原文可溯源，不阻断包导入）。
     */
    importText(kbId: string, doc: {
        file_name: string;
        source_type: string;
        text: string;
        source_key: string;
        metadata: Record<string, unknown>;
    }): Promise<ImportResult>;
    /** 原文持久化：documents/{docId}/raw（export_kb json/kbpack 文档 text 溯源；kbpack 逐文件 sha256 依赖） */
    private writeRaw;
    /** 共享管线：分块 → 嵌入（身份校验 + 批处理）→ 单事务写入 + meta empty→ready（§4.3 原子性） */ private indexParsed;
    /** 重建索引/换引擎/换模型（DESIGN §7.3 rebuild_index） */
    rebuildWork(kbId: string, opts: {
        targetEngine?: 'sqlite-vec' | 'usearch';
        embedding?: {
            model: string;
            provider: string;
            dim: number;
        };
    }): (report: (done: number, total: number, stage: JobStage) => void, signal: AbortSignal) => Promise<{
        success: boolean;
        chunk_count: number;
        elapsed_ms: number;
    }>;
    /** compact：物理回收 tombstone（DESIGN §4.4） */
    compactWork(kbId: string): (report: (done: number, total: number, stage: JobStage) => void, signal: AbortSignal) => Promise<{
        removed_chunks: number;
    }>;
    /** 预览采样（DESIGN §9：前 2 万字符） */
    previewChunks(kbId: string, docPath: string): string[];
}
export { previewText };
