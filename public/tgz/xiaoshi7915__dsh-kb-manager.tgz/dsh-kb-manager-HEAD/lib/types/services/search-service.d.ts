/**
 * 检索服务（DESIGN §5/§7.3）：
 * - 向量 KNN 与 BM25 并行，各取 top_k×candidate_mult 初筛
 * - RRF(k=60) 融合归一化
 * - rerank：applied / fallback_rrf（显式降级，不静默）/ disabled
 * - multi_kb_search：同 embedding 身份硬校验；跨库可比性依赖 rerank
 */
import type { KbConfig, SearchFilters, SearchResponse } from '../contracts/types.ts';
import type { Reranker } from '../index/rerank.ts';
import type { KbService } from './kb-service.ts';
import type { Embedder } from '../embedder/embedder.ts';
export declare class SearchService {
    private readonly kbs;
    private readonly embedder;
    private readonly cfg;
    private readonly reranker;
    constructor(kbs: KbService, embedder: () => Promise<Embedder>, cfg: () => KbConfig, reranker: () => Reranker);
    searchKb(kbId: string, query: string, opts?: {
        topK?: number;
        filters?: SearchFilters;
        rerank?: boolean;
    }): Promise<SearchResponse>;
    multiKbSearch(kbIds: string[], query: string, opts?: {
        topK?: number;
    }): Promise<SearchResponse>;
    /** get_chunk（DESIGN §7.3）：全文 + 前后相邻块（id + 截断预览），按文档内 ord 顺序 */
    getChunk(kbId: string, chunkId: string): {
        chunk_id: string;
        text: string;
        prev_chunk_id: string | null;
        next_chunk_id: string | null;
        prev_text: string | null;
        next_text: string | null;
        metadata: Record<string, unknown>;
    };
    private logRerank;
    private validateFilters;
    private chunkText;
    private buildHit;
    /** 向量初筛：线性 KNN（sqlite-vec），过滤 tombstone；1 万块 <10ms，10 万块 <50ms */
    private vectorQuery;
    /** BM25 初筛：FTS5 匹配 + bm25() 排序；tombstone 由 JOIN 过滤；有 filter 时超取 3× 再后过滤 */
    private bm25Query;
    /** filter 所需的块元信息（仅在有 filters 时加载） */
    private loadFilterInfo;
    private passFilters;
}
