import type { KbStore } from '../store/store.ts';
import { ConfirmTokens } from '../contracts/errors.ts';
export declare class SnapshotService {
    private readonly getStore;
    private readonly enqueue;
    private readonly confirms?;
    constructor(getStore: (kbId: string) => KbStore, enqueue: (kbId: string, work: (report: (done: number, total: number, stage: 'copying' | 'indexing') => void, signal: AbortSignal) => Promise<unknown>) => {
        job_id: string;
    }, confirms?: ConfirmTokens | undefined);
    create(kbId: string, note?: string): Promise<{
        snapshot_id: string;
        created_at: string;
        size_bytes: number;
        doc_count: number;
    }>;
    list(kbId: string, limit?: number, offset?: number): {
        total: number;
        snapshots: Array<{
            snapshot_id: string;
            created_at: string;
            note: string | null;
            doc_count: number;
            size_bytes: number;
        }>;
    };
    /** 无 token：dry-run（impact + token，不入队）；带有效 token：入队执行。token 经 ConfirmTokens 签发/校验（§8.4，5 分钟单用）。 */
    restore(kbId: string, snapshotId: string, confirmToken?: string): {
        requires_confirm: true;
        confirm_token: string;
        impact: {
            restored_docs: number;
            removed_chunks: number;
            freed_bytes: number;
        };
    } | {
        requires_confirm: false;
        job_id: string;
        status: 'queued';
    };
    private restoreWork;
}
