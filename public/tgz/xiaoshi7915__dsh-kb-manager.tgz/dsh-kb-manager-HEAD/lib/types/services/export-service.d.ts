import type { KbStore } from '../store/store.ts';
export declare class ExportService {
    private readonly getStore;
    constructor(getStore: (kbId: string) => KbStore);
    /** 导出工作函数（job 内执行） */
    exportWork(kbId: string, format: 'kbpack' | 'json', outputPath: string, includeIndex?: boolean, allowedDirs?: string[]): (report: (done: number, total: number, stage: "copying" | "indexing") => void, _signal: AbortSignal) => Promise<{
        file_path: string;
        size_bytes: number;
        format: "json";
        include_index?: undefined;
    } | {
        file_path: string;
        size_bytes: number;
        format: string;
        include_index: boolean;
    }>;
    /** 导入工作函数 */
    importWork(filePath: string, mergeStrategy: 'create_new' | 'merge', kbId: string | null, allowedDirs: string[], onImported: (kbId: string, doc: {
        file_name: string;
        source_type: string;
        text: string;
        source_key: string;
        metadata: Record<string, unknown>;
    }) => Promise<void>): (report: (done: number, total: number, stage: "copying" | "indexing") => void, _signal: AbortSignal) => Promise<{
        kb_id: string;
        imported_docs: number;
        conflicts: string[];
    }>;
    /** 读取迁移包的 meta（import_kb create_new 未给 kb_id 时取名建库用；只读不导入） */
    peekPackMeta(filePath: string, allowedDirs: string[]): {
        name?: string;
        kb_id?: string;
    };
    private readRawText;
}
