import type { EmbeddingIdentity, KbListItem, KbMeta } from '../contracts/types.ts';
import { type KbStore } from '../store/store.ts';
export declare class KbService {
    private readonly root;
    private stores;
    private defaultIdentity;
    constructor(root: string);
    /** 由 manager 注入当前配置推导出的默认 embedding 身份 */
    setDefaultIdentity(identity: EmbeddingIdentity): void;
    private kbDir;
    /** 存储根路径（缓存/白名单兜底用） */
    rootPath(): string;
    getStore(kbId: string): KbStore;
    /** 启动恢复用：列出已有 KB 目录 id（含 meta.json 的） */
    kbIds(): string[];
    /** B1/B2：返回 { total（过滤后全量）, kbs（分页后） }；doc_count 每库实查（不再恒 0） */
    listKbs(domainTag?: string, limit?: number, offset?: number): {
        total: number;
        kbs: KbListItem[];
    };
    /** doc_count 直接查询 documents 表；只读直开（不加载 sqlite-vec/迁移），失败降级 0 */
    private docCountOf;
    createKb(name: string, description?: string, domainTags?: string[], embedding?: {
        model?: string;
        provider?: EmbeddingIdentity['provider'];
        dim?: number;
    }): KbMeta;
    getKb(kbId: string): KbMeta;
    renameKb(kbId: string, name: string): {
        kb_id: string;
        name: string;
    };
    /**
     * 两步删除（DESIGN §8.4）。
     * confirmToken=null → 返回 impact + token（SEC.CONFIRM_REQUIRED）
     * confirmToken 有效 → 执行：小库同步删，大库返回 job（queue 由 manager 注入）
     */
    /** 两步删除（DESIGN §8.4）：无 token → impact（不入执行）；有效 token → 同步执行 */
    deleteKb(kbId: string, confirmToken: string | null, isTokenValid: (t: string) => boolean): {
        confirm: true;
        impact: {
            docs: number;
            chunks: number;
            bytes: number;
        };
    } | {
        confirm: false;
        deleted: {
            docs: number;
            chunks: number;
            bytes: number;
        };
    };
    stats(kbId: string): {
        doc_count: number;
        chunk_count: number;
        index_size_bytes: number;
        avg_chunk_tokens: number;
        embedding: KbMeta['embedding'];
        backend: string;
        deleted_ratio: number;
    };
    dispose(): void;
}
