/**
 * Rerank 接口（DESIGN §5.4，引擎 v1.1 交付）。
 * MVP 提供 NoopReranker：显式降级为 RRF-only（rerank: 'fallback_rrf'），绝不静默。
 */
import type { RerankStatus } from '../contracts/types.ts';
export interface RerankCandidate {
    chunk_id: string;
    text: string;
}
export interface Reranker {
    /** 触发加载（下载模型/建 session）；不可用/失败时应静默（applyRerank 据此降级） */
    ensureReady(): Promise<void>;
    /** 引擎是否可用（模型已加载/已下载） */
    available(): boolean;
    /** 返回降序排序后的 [{chunk_id, score}]，score ∈ [0,1]（ONNX 推理异步） */
    rerank(query: string, candidates: RerankCandidate[], topN: number): Promise<Array<{
        chunk_id: string;
        score: number;
    }>>;
}
export declare class NoopReranker implements Reranker {
    ensureReady(): Promise<void>;
    available(): boolean;
    rerank(): never;
}
export interface RerankOutcome {
    status: RerankStatus;
    ranked: Array<{
        chunk_id: string;
        score: number;
        score_kind: 'rerank' | 'rrf';
    }>;
}
/**
 * 统一降级出口：
 * - enable_rerank=false            → 'disabled'（用户配置，不提示异常）
 * - 引擎不可用                      → 'fallback_rrf'（显式降级，UI 黄灯 + "重排序不可用"）
 * - 引擎可用且打分成功              → 'applied'
 */
export declare function applyRerank(enableRerank: boolean, reranker: Reranker, query: string, candidates: RerankCandidate[], topK: number, minScore: number, rrfFallback: Array<{
    chunk_id: string;
    score: number;
}>): Promise<RerankOutcome>;
