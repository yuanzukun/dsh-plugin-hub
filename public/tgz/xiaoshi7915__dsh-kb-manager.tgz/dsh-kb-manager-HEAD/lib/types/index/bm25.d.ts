/**
 * 中文 BM25 通道（DESIGN §5.3 + 拍板⑥'）。
 * - 分词：Intl.Segmenter（granularity 'word'，零依赖、无 node-gyp）
 * - 入库前预分词写入 chunks.bm25_text（空格分隔），FTS5 用 unicode61 分词器索引空格串
 * - 纯 JS BM25 评分器供测试/降级使用；生产查询走 FTS5 bm25() 排名
 * - 若评测显示 BM25 路明显拖后腿 → 换 jieba-wasm（仍不碰 native）
 */
/** 预分词：输出空格分隔的小写 token 串（写 chunks.bm25_text 与查询前共用） */
export declare function tokenizeZh(text: string): string[];
export declare function tokenizeForFts(text: string): string;
/** 查询词：去重保序（FTS5 查询串 / JS 评分共用） */
export declare function queryTokens(text: string): string[];
export interface Bm25Params {
    k1?: number;
    b?: number;
}
/**
 * 内存 BM25 评分器（k1=1.5, b=0.75）。
 * 生产路径用 FTS5 的 bm25()；此实现用于单测、降级路径与 eval 对齐。
 */
export declare class InMemoryBm25 {
    private df;
    private tf;
    private docLen;
    private N;
    private avgdl;
    private readonly k1;
    private readonly b;
    constructor(params?: Bm25Params);
    addDoc(docId: string, tokens: string[]): void;
    removeDoc(docId: string): void;
    search(query: string[], topN?: number): Array<{
        id: string;
        score: number;
    }>;
}
