/**
 * RRF 融合（DESIGN §5.3/§5.6）：score = Σ 1/(k + rank)，k 默认 60。
 * 只消费各路"有界初筛 top-K"的序，零跨库/跨模型可比性问题。
 */
export interface RankedIds {
    ids: string[];
    scores?: number[];
}
export declare function rrfFusion(lists: RankedIds[], k?: number): Map<string, number>;
export declare function topFromMap(map: Map<string, number>, n: number): Array<[string, number]>;
/** 展示分归一化：top-1 = 1.0（DESIGN §5.6） */
export declare function normalizeForDisplay(scored: Array<[string, number]>): Map<string, number>;
