/**
 * dsh-kb-manager Host 入口（DESIGN §3/§13.2）。
 * bundle patch 行（cordis.patch.yml 的 kb-manager 行）→ Cordis 插件：
 * - 注册 13 个 MVP Agent 工具（docstring 见 DESIGN 附录 C / agent-tools/tools.ts）
 * - system prompt preamble（工具协作约定）
 * - fiber 卸载时自动注销全部工具与 prompt section 并关闭所有 store
 *
 * Job 事件：MVP 仅记日志（Web 端经 get_job 轮询，DESIGN §6.2）。
 * 插件形态与 harness 内置工具插件一致：模块具名导出即 Plugin.Object。
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "dsh-kb-manager";
export declare const inject: string[];
export interface Config {
    /** 存储根目录；空 = ~/.dsh/kb-manager/ */
    storagePath?: string;
    logLevel?: 'debug' | 'info' | 'warn' | 'error';
    /** 导入白名单目录（宿主侧安全配置，经 profile 层注入；缺省 = 会话 workspace + storage/inbox） */
    importAllowedDirs?: string[];
    /** 会话 workspace（默认导入白名单的一部分） */
    workspace?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
