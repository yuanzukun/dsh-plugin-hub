import type { InvocationDescriptor } from '@deepseek-ai/dsh-typert-protocol';
export declare const KB_PACKAGE = "dsh-kb-manager";
export declare const KB_NAMESPACE = "kbManager";
/**
 * 21 个 wire 方法（与 agent 工具同名映射，见 src/agent-tools/tools.ts）：
 * list / detail / stats / docs / search / create / importDoc / job / cancelJob /
 * deleteKb / deleteDoc / rebuild / configure
 * + v1.1：renameKb / multiKbSearch / createSnapshot / listSnapshots / restoreSnapshot /
 *   exportKb / importKb / compactIndex
 */
export declare const KB_INVOCATIONS: InvocationDescriptor[];
