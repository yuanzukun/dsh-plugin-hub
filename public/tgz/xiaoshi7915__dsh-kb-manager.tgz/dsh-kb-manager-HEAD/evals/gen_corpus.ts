/**
 * 评测语料生成（DESIGN §10.5）：可复现的小规模合成语料。
 * 正式验收语料（100 份 ≈10k chunks）到位后本脚本退化为 smoke 用。
 * 词表刻意使用分词器独立词（避免 Segmenter 切分歧义，如"向量化"→"向|量化"）。
 */
import { mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

export interface CorpusDoc {
  /** 文件名（即 source_doc） */
  file: string
  /** Markdown 正文 */
  text: string
}

interface Theme {
  file: string
  title: string
  /** 3-5 个该文档独有的区分关键词（BM25 命中锚点） */
  keywords: string[]
  extra: string
}

const THEMES: Theme[] = [
  {
    file: 'sqlite-basics.md',
    title: 'SQLite 基础',
    keywords: ['数据库', '事务', '提交'],
    extra: 'SQLite 是嵌入式的关系型数据库，所有数据保存在单个文件里。事务保证多个写入要么全部生效，要么全部回滚。提交是事务结束的标志。',
  },
  {
    file: 'vector-search.md',
    title: '向量检索原理',
    keywords: ['相似度', '余弦', '距离'],
    extra: '向量检索通过计算查询向量与文档向量的相似度来排序。余弦距离衡量方向差异，是检索系统常用的距离度量。',
  },
  {
    file: 'bm25-rank.md',
    title: 'BM25 排序',
    keywords: ['词频', '逆文档', '饱和'],
    extra: 'BM25 是一种统计排序函数，核心思想是词频越高得分越高，但存在饱和现象。逆文档频率让罕见词获得更高权重。',
  },
  {
    file: 'rag-pipeline.md',
    title: 'RAG 流程',
    keywords: ['提示词', '上下文', '生成'],
    extra: 'RAG 把检索到的段落拼进提示词，作为上下文交给模型。生成的回答应当引用上下文中的事实，而不是凭空编造。',
  },
  {
    file: 'tokenize-cjk.md',
    title: '中文分词',
    keywords: ['分词器', '段落', '空格'],
    extra: '处理中文文本需要分词器把连续汉字切成词。段落边界是天然的切分点，词与词之间常用空格连接后再交给索引。',
  },
  {
    file: 'snapshot-backup.md',
    title: '快照与备份',
    keywords: ['副本', '一致性', '回滚'],
    extra: '快照是数据库在某一时刻的一致性副本，用于灾备与回滚。热备份不需要停止写入，读取的副本依然完整可用。',
  },
  {
    file: 'prompt-security.md',
    title: '提示词安全',
    keywords: ['注入', '越权', '白名单'],
    extra: '提示词注入是攻击者借文档内容篡改指令的行为。白名单可以限制导入来源，防止越权读取敏感文件。',
  },
  {
    file: 'chunking-strategy.md',
    title: '分块策略',
    keywords: ['重叠', '段落', '标题'],
    extra: '分块把长文档切成小块，相邻块之间保留重叠以避免信息被切断。标题层级帮助定位每个块所属的章节。',
  },
  {
    file: 'rerank-model.md',
    title: '重排序模型',
    keywords: ['打分', '截断', '阈值'],
    extra: '重排序模型对候选块逐个打分，再按分数截断并过滤低于阈值的条目。交叉编码器比双塔模型更准但更慢。',
  },
  {
    file: 'index-engine.md',
    title: '索引引擎',
    keywords: ['线性', '倒排', '构建'],
    extra: '小规模索引适合线性扫描，倒排索引让关键词检索达到毫秒级。索引构建是一次全量过程，增量更新更轻量。',
  },
]

/**
 * 生成 10 篇合成 Markdown 文档到 dir。
 * 每篇 = 标题 + 3 节，每节包含该文档的全部关键词，保证 BM25 可区分。
 */
export function generateCorpus(dir: string): CorpusDoc[] {
  mkdirSync(dir, { recursive: true })
  const docs: CorpusDoc[] = THEMES.map((t, i) => {
    const kwLine = t.keywords.join('、')
    const text =
      `# ${t.title}\n\n` +
      `## 概述\n\n${t.extra}本篇文档讨论${t.title}，核心概念包括${kwLine}。\n\n` +
      `## 细节一\n\n${t.keywords[0]}与${t.keywords[1]}的组合决定了行为边界。理解${t.keywords[2] ?? t.keywords[0]}是掌握${t.title}的关键。\n\n` +
      `## 细节二\n\n实际部署时，先固定${kwLine}的参数，再逐步调整。文档编号 ${i + 1}，其余关键词为${t.keywords.join('，')}。\n`
    writeFileSync(join(dir, t.file), text, 'utf8')
    return { file: t.file, text }
  })
  return docs
}
