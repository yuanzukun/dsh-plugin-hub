/**
 * 检索评测 harness（DESIGN §10.5 骨架）。
 * 一条命令：`npm run eval`。
 *
 * MVP 阶段：合成语料（gen_corpus）+ 文档级 GT（golden.v1.json），
 * mock embedder（identity 向量，向量路径仅贡献 RRF 排序，召回靠 BM25）。
 * 正式验收（100 份真实语料 + ONNX bge-small-zh + 块级 GT）替换本文件的
 * 语料来源与判定单位即可，指标口径不变：recall@5（macro）/ MRR / P95。
 */
import { mkdtempSync, rmSync, readFileSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { KbManager } from '../src/index.ts'
import { executeTool } from '../src/agent-tools/tools.ts'
import type { Envelope, Job, SearchResponse } from '../src/contracts/types.ts'
import { generateCorpus } from './gen_corpus.ts'

const HERE = dirname(fileURLToPath(import.meta.url))
const TOP_K = 5
const POLL_MS = 150
const JOB_TIMEOUT_MS = 60_000

function unwrap<T>(env: Envelope<T>, tool: string): T {
  if (!env.ok) throw new Error(`eval: 工具 ${tool} 失败: ${env.error.code} ${env.error.message}`)
  return env.data
}

async function pollJob(m: KbManager, jobId: string, tool: string): Promise<Job> {
  const t0 = Date.now()
  for (;;) {
    const job = unwrap<Job>(await executeTool(m, 'get_job', { job_id: jobId }), `get_job(${tool})`)
    if (job.status === 'done' || job.status === 'failed' || job.status === 'cancelled') return job
    if (Date.now() - t0 > JOB_TIMEOUT_MS) throw new Error(`eval: job ${jobId} (${tool}) 超时`)
    await new Promise(r => setTimeout(r, POLL_MS))
  }
}

export async function main(): Promise<void> {
  const root = mkdtempSync(join(tmpdir(), 'kb-eval-'))
  const workspace = join(root, 'workspace')
  try {
    const m = new KbManager(root, { workspace, embedding: { provider: 'mock', model: 'mock' } })

    const kbId = unwrap(await executeTool<{ kb_id: string }>(m, 'create_kb', { name: 'eval-kb' }), 'create_kb').kb_id
    const files = generateCorpus(workspace)
    for (const f of files) {
      const job = unwrap(await executeTool<{ job_id: string; status: string }>(m, 'import_document', {
        kb_id: kbId, source: join(workspace, f.file), source_type: 'md',
      }), 'import_document')
      const done = await pollJob(m, job.job_id, `import ${f.file}`)
      if (done.status !== 'done') throw new Error(`eval: 导入 ${f.file} 失败: ${JSON.stringify(done.error)}`)
    }

    const stats = unwrap<{ doc_count: number; chunk_count: number }>(await executeTool(m, 'get_kb_stats', { kb_id: kbId }), 'get_kb_stats')
    const golden = JSON.parse(readFileSync(join(HERE, 'golden.v1.json'), 'utf8')) as {
      version: number
      queries: { query: string; source_doc: string }[]
    }

    console.log(`\n=== dsh-kb-manager 评测（${golden.version}） ===`)
    console.log(`语料: ${files.length} 份 md；KB: ${kbId}；stats: doc_count=${(stats as { doc_count: number }).doc_count}, chunks=${(stats as { chunk_count: number }).chunk_count}`)
    console.log(`provider: mock（identity 向量；正式验收需 ONNX bge-small-zh-v1.5）\n`)

    let recallHits = 0
    let mrrSum = 0
    const latencies: number[] = []
    for (const q of golden.queries) {
      const t0 = process.hrtime.bigint()
      const res = unwrap(await executeTool<SearchResponse>(m, 'search_kb', {
        kb_id: kbId, query: q.query, top_k: TOP_K,
      }), 'search_kb')
      const ms = Number(process.hrtime.bigint() - t0) / 1e6
      latencies.push(ms)
      const ranks = res.results
        .map((h, i) => (h.source_doc === q.source_doc ? i + 1 : 0))
        .filter((r): r is number => r > 0)
      const hit = ranks.length > 0
      const mrr = ranks.length > 0 ? 1 / Math.min(...ranks) : 0
      if (hit) recallHits++
      mrrSum += mrr
      const top = res.results.slice(0, 3).map(h => `${h.source_doc}@${h.chunk_id.slice(-1)}`).join(', ')
      console.log(`${hit ? '✓' : '✗'} ${q.query}  →  期望 ${q.source_doc}  top: ${top}  [${ms.toFixed(1)}ms, rerank=${res.rerank}]`)
    }

    latencies.sort((a, b) => a - b)
    const p95 = latencies[Math.min(latencies.length - 1, Math.ceil(0.95 * latencies.length) - 1)] ?? 0
    const recall = recallHits / Math.max(1, golden.queries.length)
    const mrr = mrrSum / Math.max(1, golden.queries.length)
    console.log('\n=== 汇总 ===')
    console.log(`recall@${TOP_K}(文档级, macro): ${(recall * 100).toFixed(1)}%   (${recallHits}/${golden.queries.length})`)
    console.log(`MRR(文档级): ${mrr.toFixed(3)}`)
    console.log(`检索 P95: ${p95.toFixed(1)}ms  (n=${latencies.length})`)
    m.close()
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
}

main().catch((e) => {
  console.error('EVAL FAILED:', e)
  process.exit(1)
})
