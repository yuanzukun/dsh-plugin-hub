/**
 * KB 生命周期服务（DESIGN §7.3 同步 10 工具 + get_kb_stats）。
 */
import { mkdirSync, rmSync, existsSync, readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { randomUUID } from 'node:crypto'
import Database from 'better-sqlite3'
import type { EmbeddingIdentity, KbListItem, KbMeta } from '../contracts/types.ts'
import { DEFAULT_EMBEDDING_IDENTITY, DEFAULT_CONFIG } from '../contracts/types.ts'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import { openKbStore, readMeta, writeMeta, type KbStore } from '../store/store.ts'

export class KbService {
  private stores = new Map<string, KbStore>()
  private defaultIdentity: EmbeddingIdentity = DEFAULT_EMBEDDING_IDENTITY

  constructor(private readonly root: string) {}

  /** 由 manager 注入当前配置推导出的默认 embedding 身份 */
  setDefaultIdentity(identity: EmbeddingIdentity): void {
    this.defaultIdentity = identity
  }

  private kbDir(kbId: string): string {
    return join(this.root, 'kbs', kbId)
  }

  /** 存储根路径（缓存/白名单兜底用） */
  rootPath(): string {
    return this.root
  }

  getStore(kbId: string): KbStore {
    let s = this.stores.get(kbId)
    if (!s) {
      const dir = this.kbDir(kbId)
      if (!existsSync(dir) || !existsSync(join(dir, 'kb.db'))) {
        throw new KbError(ErrorCodes.KB_NOT_FOUND, `KB 不存在: ${kbId}`, '用 list_kbs 查看现有知识库')
      }
      s = openKbStore(dir)
      this.stores.set(kbId, s)
    }
    return s
  }

  /** 启动恢复用：列出已有 KB 目录 id（含 meta.json 的） */
  kbIds(): string[] {
    const base = join(this.root, 'kbs')
    if (!existsSync(base)) return []
    return readdirSync(base).filter((id) => existsSync(join(base, id, 'meta.json')))
  }

  /** B1/B2：返回 { total（过滤后全量）, kbs（分页后） }；doc_count 每库实查（不再恒 0） */
  listKbs(domainTag?: string, limit = 100, offset = 0): { total: number; kbs: KbListItem[] } {
    const base = join(this.root, 'kbs')
    if (!existsSync(base)) return { total: 0, kbs: [] }
    const out: KbListItem[] = []
    for (const id of readdirSync(base)) {
      const metaPath = join(base, id, 'meta.json')
      if (!existsSync(metaPath)) continue
      const meta = JSON.parse(readFileSync(metaPath, 'utf8')) as KbMeta
      if (domainTag && !meta.domain_tags.includes(domainTag)) continue
      out.push({
        kb_id: meta.kb_id,
        name: meta.name,
        doc_count: this.docCountOf(id),
        index_status: meta.status,
        last_updated: meta.updated_at,
      })
    }
    out.sort((a, b) => (a.last_updated < b.last_updated ? 1 : -1))
    return { total: out.length, kbs: out.slice(offset, offset + limit) }
  }

  /** doc_count 直接查询 documents 表；只读直开（不加载 sqlite-vec/迁移），失败降级 0 */
  private docCountOf(kbId: string): number {
    const dbPath = join(this.kbDir(kbId), 'kb.db')
    if (!existsSync(dbPath)) return 0
    try {
      const db = new Database(dbPath, { readonly: true })
      try {
        const r = db.prepare("SELECT COUNT(*) c FROM documents WHERE status != 'deleted'").get() as { c: number }
        return r.c
      } finally {
        db.close()
      }
    } catch {
      return 0
    }
  }

  createKb(name: string, description?: string, domainTags: string[] = [], embedding?: { model?: string; provider?: EmbeddingIdentity['provider']; dim?: number }): KbMeta {
    if (!name || !name.trim()) throw new KbError(ErrorCodes.CFG_KEY_INVALID, 'name 不能为空')
    // B6：MVP 仅支持 512 维（vec0 列 float[512] 固定）；非 512 维显式拒绝并文档化（v1.1 放开）
    if (embedding?.dim !== undefined && embedding.dim !== this.defaultIdentity.dim) {
      throw new KbError(
        ErrorCodes.EMB_DIMENSION_MISMATCH,
        `维度 ${embedding.dim} 不受支持（MVP 仅支持 ${this.defaultIdentity.dim} 维）`,
        '当前版本仅支持 bge-small-zh-v1.5/512 维；非 512 维在 v1.1 放开。',
      )
    }
    // KB_NAME_CONFLICT（拍板④'）：非幂等，同名报错
    for (const kb of this.listKbs().kbs) {
      if (kb.name === name.trim()) {
        throw new KbError(
          ErrorCodes.KB_NAME_CONFLICT,
          `知识库名已存在: "${name.trim()}"`,
          '先 list_kbs 查重；已存在则 get_kb 取 kb_id 直接使用，勿重复建库',
        )
      }
    }
    const kbId = randomUUID()
    const dir = this.kbDir(kbId)
    mkdirSync(join(dir, 'documents'), { recursive: true })
    const store = openKbStore(dir)
    const now = new Date().toISOString()
    const meta: KbMeta = {
      kb_id: kbId,
      name: name.trim(),
      description,
      domain_tags: domainTags,
      embedding: {
        model: embedding?.model ?? this.defaultIdentity.model,
        provider: (embedding?.provider ?? this.defaultIdentity.provider) as EmbeddingIdentity['provider'],
        dim: embedding?.dim ?? this.defaultIdentity.dim,
      },
      backend: DEFAULT_CONFIG.index_backend === 'auto' ? 'sqlite-vec' : DEFAULT_CONFIG.index_backend,
      status: 'empty',
      schema_version: 1,
      created_at: now,
      updated_at: now,
    }
    writeMeta(store, meta)
    store.close()
    return meta
  }

  getKb(kbId: string): KbMeta {
    const store = this.getStore(kbId)
    const meta = readMeta(store)
    if (!meta) throw new KbError(ErrorCodes.KB_NOT_FOUND, `KB 不存在: ${kbId}`)
    return meta
  }

  renameKb(kbId: string, name: string): { kb_id: string; name: string } {
    if (!name || !name.trim()) throw new KbError(ErrorCodes.CFG_KEY_INVALID, 'name 不能为空')
    for (const kb of this.listKbs().kbs) {
      if (kb.kb_id !== kbId && kb.name === name.trim()) {
        throw new KbError(ErrorCodes.KB_NAME_CONFLICT, `知识库名已存在: "${name.trim()}"`, '换一个名字')
      }
    }
    const store = this.getStore(kbId)
    const meta = readMeta(store)!
    meta.name = name.trim()
    meta.updated_at = new Date().toISOString()
    writeMeta(store, meta)
    return { kb_id: kbId, name: meta.name }
  }

  /**
   * 两步删除（DESIGN §8.4）。
   * confirmToken=null → 返回 impact + token（SEC.CONFIRM_REQUIRED）
   * confirmToken 有效 → 执行：小库同步删，大库返回 job（queue 由 manager 注入）
   */
  /** 两步删除（DESIGN §8.4）：无 token → impact（不入执行）；有效 token → 同步执行 */
  deleteKb(kbId: string, confirmToken: string | null, isTokenValid: (t: string) => boolean):
    | { confirm: true; impact: { docs: number; chunks: number; bytes: number } }
    | { confirm: false; deleted: { docs: number; chunks: number; bytes: number } } {
    const store = this.getStore(kbId)
    const impact = {
      docs: (store.db.prepare("SELECT COUNT(*) c FROM documents WHERE status != 'deleted'").get() as { c: number }).c,
      chunks: (store.db.prepare('SELECT COUNT(*) c FROM chunks WHERE deleted = 0').get() as { c: number }).c,
      bytes: 0,
    }
    for (const f of ['kb.db', 'kb.db-wal', 'kb.db-shm']) {
      const p = join(this.kbDir(kbId), f)
      if (existsSync(p)) impact.bytes += readFileSync(p).byteLength
    }
    if (!confirmToken || !isTokenValid(confirmToken)) {
      return { confirm: true, impact }
    }
    store.close()
    this.stores.delete(kbId)
    rmSync(this.kbDir(kbId), { recursive: true, force: true })
    return { confirm: false, deleted: impact }
  }

  stats(kbId: string): {
    doc_count: number; chunk_count: number; index_size_bytes: number
    avg_chunk_tokens: number; embedding: KbMeta['embedding']; backend: string; deleted_ratio: number
  } {
    const meta = this.getKb(kbId)
    const store = this.getStore(kbId)
    const docCount = (store.db.prepare("SELECT COUNT(*) c FROM documents WHERE status NOT IN ('deleted')").get() as { c: number }).c
    const chunkCount = (store.db.prepare('SELECT COUNT(*) c FROM chunks WHERE deleted = 0').get() as { c: number }).c
    const deletedCount = (store.db.prepare('SELECT COUNT(*) c FROM chunks WHERE deleted = 1').get() as { c: number }).c
    const avgTokens = (store.db.prepare('SELECT AVG(token_count) a FROM chunks WHERE deleted = 0').get() as { a: number | null }).a ?? 0
    const dbPath = join(this.kbDir(kbId), 'kb.db')
    return {
      doc_count: docCount,
      chunk_count: chunkCount,
      index_size_bytes: existsSync(dbPath) ? readFileSync(dbPath).byteLength : 0,
      avg_chunk_tokens: Math.round(avgTokens),
      embedding: meta.embedding,
      backend: meta.backend,
      deleted_ratio: chunkCount + deletedCount > 0 ? deletedCount / (chunkCount + deletedCount) : 0,
    }
  }

  dispose(): void {
    for (const s of this.stores.values()) s.close()
    this.stores.clear()
  }
}
