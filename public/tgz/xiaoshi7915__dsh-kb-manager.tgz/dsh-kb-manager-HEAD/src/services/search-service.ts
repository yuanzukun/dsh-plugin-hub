/**
 * 检索服务（DESIGN §5/§7.3）：
 * - 向量 KNN 与 BM25 并行，各取 top_k×candidate_mult 初筛
 * - RRF(k=60) 融合归一化
 * - rerank：applied / fallback_rrf（显式降级，不静默）/ disabled
 * - multi_kb_search：同 embedding 身份硬校验；跨库可比性依赖 rerank
 */
import type {
  KbConfig, SearchFilters, SearchHit, SearchResponse, RerankStatus,
} from '../contracts/types.ts'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import { tx, type KbStore } from '../store/store.ts'
import { rrfFusion, topFromMap, normalizeForDisplay, type RankedIds } from '../index/rrf.ts'
import { queryTokens } from '../index/bm25.ts'
import type { Reranker } from '../index/rerank.ts'
import { applyRerank } from '../index/rerank.ts'
import type { KbService } from './kb-service.ts'
import type { Embedder } from '../embedder/embedder.ts'
import { assertSameIdentity } from '../embedder/embedder.ts'
import { bgeQueryPrefix } from './bge-instruction.ts'

export class SearchService {
  constructor(
    private readonly kbs: KbService,
    private readonly embedder: () => Promise<Embedder>,
    private readonly cfg: () => KbConfig,
    private readonly reranker: () => Reranker,
  ) {}

  async searchKb(
    kbId: string,
    query: string,
    opts: { topK?: number; filters?: SearchFilters; rerank?: boolean } = {},
  ): Promise<SearchResponse> {
    const t0 = Date.now()
    const cfg = this.cfg()
    const topK = opts.topK ?? cfg.top_k
    if (!Number.isInteger(topK) || topK < 1 || topK > 50) {
      throw new KbError(ErrorCodes.SRCH_TOPK_OUT_OF_RANGE, `top_k 超范围: ${topK}`, 'top_k 取值 1..50')
    }
    this.validateFilters(opts.filters)
    const store = this.kbs.getStore(kbId)
    const meta = this.kbs.getKb(kbId)
    if (meta.status === 'building') {
      throw new KbError(ErrorCodes.IDX_NOT_READY, 'KB 正在构建中', '等待当前 job 完成后再检索')
    }

    const emb = await this.embedder()
    assertSameIdentity(meta.embedding, emb.identity(), 'KB 绑定身份与当前 provider')
    const qVec = (await emb.embed([bgeQueryPrefix(cfg, query)]))[0]!

    const cand = topK * cfg.candidate_mult
    const [vecRanked, bm25Ranked] = await Promise.all([
      this.vectorQuery(store, qVec, cand, opts.filters),
      this.bm25Query(store, query, cand, opts.filters),
    ])
    const totalCandidates = new Set([...vecRanked.ids, ...bm25Ranked.ids]).size
    const enableRerank = opts.rerank ?? cfg.enable_rerank
    if (vecRanked.ids.length === 0 && bm25Ranked.ids.length === 0) {
      // B12：空结果也如实标注 rerank 状态（启用但引擎不可用 → fallback_rrf），不静默降为 disabled
      return { query, top_k: topK, results: [], total_candidates: 0, total_hits: 0, rerank: enableRerank ? 'fallback_rrf' : 'disabled', elapsed_ms: Date.now() - t0 }
    }
    const fused = rrfFusion([vecRanked, bm25Ranked], cfg.rrf_k)
    const top = topFromMap(fused, topK)
    const displayed = normalizeForDisplay(top)

    const reranker = this.reranker()
    const candidates = top.map(([id]) => ({ chunk_id: id, text: this.chunkText(store, id) }))
    const rrfFallback = top.map(([id, s]) => ({ chunk_id: id, score: displayed.get(id) ?? 0 }))
    const outcome = await applyRerank(
      enableRerank, reranker, query, candidates, topK, cfg.rerank_min_score, rrfFallback,
    )
    if (reranker.available() && enableRerank) this.logRerank(outcome.status)

    const results: SearchHit[] = []
    for (const { chunk_id, score, score_kind } of outcome.ranked) {
      const hit = this.buildHit(store, chunk_id, score, score_kind)
      if (hit) results.push(hit)
    }
    return {
      query, top_k: topK, results, total_candidates: totalCandidates, total_hits: results.length,
      rerank: outcome.status, elapsed_ms: Date.now() - t0,
    }
  }

  async multiKbSearch(
    kbIds: string[],
    query: string,
    opts: { topK?: number } = {},
  ): Promise<SearchResponse> {
    const t0 = Date.now()
    const cfg = this.cfg()
    const topK = opts.topK ?? cfg.top_k
    if (!Number.isInteger(topK) || topK < 1 || topK > 50) {
      throw new KbError(ErrorCodes.SRCH_TOPK_OUT_OF_RANGE, `top_k 超范围: ${topK}`, 'top_k 取值 1..50')
    }
    if (kbIds.length < 2) {
      throw new KbError(ErrorCodes.SRCH_BAD_FILTER, 'multi_kb_search 至少需要 2 个知识库', '单库用 search_kb')
    }
    // 同 embedding 身份硬校验
    const identities = kbIds.map((id) => this.kbs.getKb(id).embedding)
    for (const id of identities.slice(1)) {
      assertSameIdentity(identities[0]!, id, `KB ${kbIds[0]} 与 ${id} 的 embedding 身份`)
    }
    const partial = await Promise.all(kbIds.map((kbId) =>
      this.searchKb(kbId, query, { topK: topK * 2 }).catch(() => null)))
    const merged = partial.filter((r): r is SearchResponse => r !== null)
    if (merged.length === 0) {
      throw new KbError(ErrorCodes.KB_NOT_FOUND, '无可检索的知识库', '检查 kb_id 是否正确')
    }
    const all = merged.flatMap((r) => r.results)
    const reranker = this.reranker()
    // 触发加载（失败静默 → available()=false → 降级路径）
    try { await reranker.ensureReady() } catch { /* 引擎不可用 */ }
    const comparable = cfg.enable_rerank && reranker.available()
    let final: Array<{ chunk_id: string; score: number; score_kind: 'rerank' | 'rrf' }>
    let status: RerankStatus
    if (comparable) {
      const candidates = all.map((h) => ({ chunk_id: h.chunk_id, text: h.text }))
      const out = await applyRerank(true, reranker, query, candidates, topK, cfg.rerank_min_score,
        all.map((h) => ({ chunk_id: h.chunk_id, score: h.score })))
      final = out.ranked
      status = out.status
    } else {
      // 降级：RRF 秩合并（分数跨库不可比，标 cross_kb_comparable=false）
      const lists: RankedIds[] = merged.map((r) => ({ ids: r.results.map((h) => h.chunk_id) }))
      const fused = rrfFusion(lists, cfg.rrf_k)
      const top = topFromMap(fused, topK)
      const displayed = normalizeForDisplay(top)
      final = top.map(([id, s]) => ({ chunk_id: id, score: displayed.get(id) ?? 0, score_kind: 'rrf' as const }))
      status = cfg.enable_rerank ? 'fallback_rrf' : 'disabled'
    }
    const byChunk = new Map(all.map((h) => [h.chunk_id, h]))
    const results: SearchHit[] = []
    for (const f of final) {
      const src = byChunk.get(f.chunk_id)
      if (!src) continue
      results.push({ ...src, score: f.score, score_kind: f.score_kind, text: src.text, has_more: src.has_more })
    }
    return {
      query: '', top_k: topK, results, total_candidates: all.length, total_hits: results.length,
      rerank: status, cross_kb_comparable: comparable, elapsed_ms: Date.now() - t0,
    }
  }

  /** get_chunk（DESIGN §7.3）：全文 + 前后相邻块（id + 截断预览），按文档内 ord 顺序 */
  getChunk(kbId: string, chunkId: string): {
    chunk_id: string; text: string
    prev_chunk_id: string | null; next_chunk_id: string | null
    prev_text: string | null; next_text: string | null
    metadata: Record<string, unknown>
  } {
    const cfg = this.cfg()
    const store = this.kbs.getStore(kbId)
    const row = store.db.prepare('SELECT * FROM chunks WHERE chunk_id = ? AND deleted = 0').get(chunkId) as Record<string, unknown> | undefined
    if (!row) throw new KbError(ErrorCodes.DOC_NOT_FOUND, `块不存在: ${chunkId}`, '块可能已被删除；重新执行 search_kb')
    const docId = String(row.doc_id)
    const prev = store.db.prepare('SELECT * FROM chunks WHERE doc_id = ? AND ord < ? ORDER BY ord DESC LIMIT 1').get(docId, Number(row.ord)) as Record<string, unknown> | undefined
    const next = store.db.prepare('SELECT * FROM chunks WHERE doc_id = ? AND ord > ? ORDER BY ord ASC LIMIT 1').get(docId, Number(row.ord)) as Record<string, unknown> | undefined
    const clip = (r: Record<string, unknown> | undefined): string | null =>
      r ? String(r.text).slice(0, cfg.result_text_max_chars) : null
    return {
      chunk_id: String(row.chunk_id),
      text: String(row.text),
      prev_chunk_id: prev ? String(prev.chunk_id) : null,
      next_chunk_id: next ? String(next.chunk_id) : null,
      prev_text: clip(prev),
      next_text: clip(next),
      metadata: JSON.parse(String(row.metadata_json ?? '{}')),
    }
  }

  private logRerank(_s: RerankStatus): void { /* 宿主日志桥接点 */ }

  private validateFilters(f?: SearchFilters): void {
    if (!f) return
    for (const key of Object.keys(f)) {
      if (!['docs', 'doc_globs', 'headings', 'page_range'].includes(key)) {
        throw new KbError(ErrorCodes.SRCH_BAD_FILTER, `未知过滤字段: ${key}`, '可选: docs / doc_globs / headings / page_range')
      }
    }
    if (f.page_range && (f.page_range.length !== 2 || f.page_range.some((n) => !Number.isInteger(n) || n < 1))) {
      throw new KbError(ErrorCodes.SRCH_BAD_FILTER, 'page_range 需为 [起页,止页] 正整数')
    }
  }

  private chunkText(store: KbStore, chunkId: string): string {
    const row = store.db.prepare('SELECT text FROM chunks WHERE chunk_id = ?').get(chunkId) as { text: string } | undefined
    return row?.text ?? ''
  }

  private buildHit(store: KbStore, chunkId: string, score: number, scoreKind: 'rerank' | 'rrf'): SearchHit | null {
    const row = store.db.prepare(`
      SELECT c.*, d.file_name, d.source_type FROM chunks c JOIN documents d ON d.doc_id = c.doc_id
      WHERE c.chunk_id = ? AND c.deleted = 0`).get(chunkId) as Record<string, unknown> | undefined
    if (!row) return null
    const cfg = this.cfg()
    const text = String(row.text)
    return {
      chunk_id: String(row.chunk_id),
      score,
      score_kind: scoreKind,
      text: text.slice(0, cfg.result_text_max_chars),
      has_more: text.length > cfg.result_text_max_chars,
      source_doc: String(row.file_name),
      page_num: row.page_num === null ? null : Number(row.page_num),
      heading_path: String(row.heading_path),
      untrusted: true,
    }
  }

  /** 向量初筛：线性 KNN（sqlite-vec），过滤 tombstone；1 万块 <10ms，10 万块 <50ms */
  private async vectorQuery(store: KbStore, qVec: number[], topN: number, filters?: SearchFilters): Promise<RankedIds> {
    // sqlite-vec KNN 操作符（O(k)，不拉全量向量；embedding 列读回是 4N 字节 blob，内存重算不可靠）
    const qBlob = Buffer.from(new Float32Array(qVec).buffer)
    const k = filters ? topN * 3 : topN
    const rows = tx(store, (db) => {
      const stmt = db.prepare(
        `SELECT v.chunk_id AS chunk_id, v.distance AS distance
         FROM vec_chunks v
         JOIN chunks c ON c.chunk_id = v.chunk_id
         WHERE v.embedding MATCH ? AND k = ? AND c.deleted = 0
         ORDER BY v.distance`,
      )
      const all = stmt.all(qBlob, k) as Array<{ chunk_id: string; distance: number }>
      if (!filters) return all
      const info = this.loadFilterInfo(store)
      return all.filter((r) => this.passFilters(info, r.chunk_id, filters))
    })
    return { ids: rows.map((r) => r.chunk_id), scores: rows.map((r) => -r.distance) }
  }

  /** BM25 初筛：FTS5 匹配 + bm25() 排序；tombstone 由 JOIN 过滤；有 filter 时超取 3× 再后过滤 */
  private async bm25Query(store: KbStore, query: string, topN: number, filters?: SearchFilters): Promise<RankedIds> {
    const toks = queryTokens(query)
    if (toks.length === 0) return { ids: [] }
    const ftsQuery = toks.map((t) => `"${t.replaceAll('"', '""')}"`).join(' OR ')
    const info = filters ? this.loadFilterInfo(store) : null
    const over = info ? topN * 3 : topN
    try {
      const rows = store.db.prepare(`
        SELECT c.chunk_id AS chunk_id, bm25(chunks_fts) AS score
        FROM chunks_fts
        JOIN chunks c ON c.rowid = chunks_fts.rowid
        WHERE chunks_fts MATCH ? AND c.deleted = 0
        ORDER BY score LIMIT ?`).all(ftsQuery, over) as Array<{ chunk_id: string; score: number }>
      const kept = info ? rows.filter((r) => this.passFilters(info, r.chunk_id, filters!)) : rows
      return { ids: kept.slice(0, topN).map((r) => r.chunk_id), scores: kept.slice(0, topN).map((r) => r.score) }
    } catch {
      // FTS5 MATCH 语法边缘情况（纯标点等）：返回空而非整体失败
      return { ids: [] }
    }
  }

  /** filter 所需的块元信息（仅在有 filters 时加载） */
  private loadFilterInfo(store: KbStore): Map<string, { file_name: string; heading_path: string; page_num: number | null }> {
    const m = new Map<string, { file_name: string; heading_path: string; page_num: number | null }>()
    const rows = store.db.prepare(`
      SELECT c.chunk_id, d.file_name, c.heading_path, c.page_num
      FROM chunks c JOIN documents d ON d.doc_id = c.doc_id
      WHERE c.deleted = 0`).all() as Array<{ chunk_id: string; file_name: string; heading_path: string; page_num: number | null }>
    for (const r of rows) m.set(r.chunk_id, { file_name: r.file_name, heading_path: r.heading_path ?? '', page_num: r.page_num })
    return m
  }

  private passFilters(info: Map<string, { file_name: string; heading_path: string; page_num: number | null }>, chunkId: string, f: SearchFilters): boolean {
    const it = info.get(chunkId)
    if (!it) return false
    if (f.docs && f.docs.length > 0 && !f.docs.includes(it.file_name)) return false
    if (f.doc_globs && f.doc_globs.length > 0 && !f.doc_globs.some((g) => globToRegex(g).test(it.file_name))) return false
    if (f.headings && f.headings.length > 0 && !f.headings.some((h) => it.heading_path.includes(h))) return false
    if (f.page_range && f.page_range.length === 2) {
      const [lo, hi] = f.page_range
      if (it.page_num === null || it.page_num < (lo ?? 0) || it.page_num > (hi ?? Infinity)) return false
    }
    return true
  }
}

function globToRegex(g: string): RegExp {
  const escaped = g.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.')
  return new RegExp(`^${escaped}$`)
}
