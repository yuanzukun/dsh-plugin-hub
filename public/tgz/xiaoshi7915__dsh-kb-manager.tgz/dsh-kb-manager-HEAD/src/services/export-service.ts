/**
 * 导出/导入服务（v1.1，DESIGN §7.3）：
 * - export_kb: kbpack（文档+索引+元数据，默认含向量）| json（元数据+解析文本，不含向量）
 * - import_kb: create_new（kb_id 可省）| merge（kb_id 必填，内容 hash 去重，冲突列 result.conflicts）
 * - embedding 身份不匹配 → EMB.DIMENSION_MISMATCH
 */
import { createHash, randomUUID } from 'node:crypto'
import { readFileSync, writeFileSync, mkdirSync, existsSync, statSync, readdirSync } from 'node:fs'
import { join, basename } from 'node:path'
import type { EmbeddingIdentity } from '../contracts/types.ts'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import type { KbStore } from '../store/store.ts'
import { readMeta } from '../store/store.ts'
import { assertPathAllowed } from '../security/path-guard.ts'
import { tokenizeForFts } from '../index/bm25.ts'

const KBPACK_MAGIC = 'DSHKB1'

export class ExportService {
  constructor(private readonly getStore: (kbId: string) => KbStore) {}

  /** 导出工作函数（job 内执行） */
  exportWork(kbId: string, format: 'kbpack' | 'json', outputPath: string, includeIndex = true, allowedDirs: string[] = []) {
    return async (report: (done: number, total: number, stage: 'copying' | 'indexing') => void, _signal: AbortSignal) => {
      const store = this.getStore(kbId)
      const meta = readMeta(store)!
      const realOut = assertPathAllowed(outputPath, allowedDirs, 'export output_path')
      mkdirSync(join(realOut, '..'), { recursive: true })
      report(0, 2, 'copying')

      if (format === 'json') {
        const docs = store.db.prepare("SELECT * FROM documents WHERE status != 'deleted'").all() as Array<Record<string, unknown>>
        const payload = {
          meta,
          documents: docs.map((d) => ({
            doc_id: d.doc_id, file_name: d.file_name, source_type: d.source_type,
            content_hash: d.content_hash, size_bytes: d.size_bytes,
            text: this.readRawText(store, String(d.doc_id)),
          })),
          chunks: (store.db.prepare("SELECT chunk_id, doc_id, ord, text, heading_path, heading_level, page_num, token_count FROM chunks WHERE deleted = 0 ORDER BY doc_id, ord").all() as Array<Record<string, unknown>>),
          exported_at: new Date().toISOString(), format: 'json',
        }
        writeFileSync(realOut, JSON.stringify(payload, null, 1))
        report(2, 2, 'copying')
        return { file_path: realOut, size_bytes: statSync(realOut).size, format }
      }

      // kbpack：目录包（实现期可升级为 zip；MVP 形态 = 目录 + manifest，迁移用）
      const outDir = realOut
      mkdirSync(join(outDir, 'documents'), { recursive: true })
      const docRows = store.db.prepare("SELECT * FROM documents WHERE status != 'deleted'").all() as Array<Record<string, unknown>>
      for (let i = 0; i < docRows.length; i++) {
        const d = docRows[i]!
        const raw = join(store.kbDir, 'documents', String(d.doc_id), 'raw')
        if (existsSync(raw)) {
          writeFileSync(join(outDir, 'documents', `${String(d.doc_id)}${basename(String(d.file_name)).includes('.') ? '' : '.raw'}`), readFileSync(raw))
        }
        if ((i + 1) % 10 === 0 || i + 1 === docRows.length) report(1, 2, 'copying')
      }
      report(1, 2, 'indexing')
      // 元数据 + 块 + 可选向量
      const pack = {
        magic: KBPACK_MAGIC, version: 1, meta,
        documents: docRows.map((d) => ({ doc_id: d.doc_id, file_name: d.file_name, source_type: d.source_type, content_hash: d.content_hash, size_bytes: d.size_bytes })),
        chunks: store.db.prepare("SELECT chunk_id, doc_id, ord, text, bm25_text, heading_path, heading_level, page_num, char_start, char_end, token_count, table_detected FROM chunks WHERE deleted = 0").all() as unknown[],
        vectors: includeIndex
          ? (store.db.prepare('SELECT chunk_id, embedding FROM vec_chunks').all() as Array<{ chunk_id: string; embedding: Float32Array }>).map((r) => ({ chunk_id: r.chunk_id, f32: Array.from(r.embedding) }))
          : [],
        include_index: includeIndex,
        exported_at: new Date().toISOString(),
      }
      const manifestPath = join(outDir, 'manifest.json')
      writeFileSync(manifestPath, JSON.stringify(pack, null, 1))
      // 逐文件 sha256（DESIGN §12 kbpack spec）
      const hashes: Record<string, string> = {}
      for (const d of pack.documents) hashes[String(d.doc_id)] = String(d.content_hash)
      writeFileSync(join(outDir, 'hashes.json'), JSON.stringify(hashes, null, 1))
      report(2, 2, 'indexing')
      return { file_path: outDir, size_bytes: dirSize(outDir), format: 'kbpack', include_index: includeIndex }
    }
  }

  /** 导入工作函数 */
  importWork(filePath: string, mergeStrategy: 'create_new' | 'merge', kbId: string | null, allowedDirs: string[],
    onImported: (kbId: string, doc: { file_name: string; source_type: string; text: string; source_key: string; metadata: Record<string, unknown> }) => Promise<void>) {
    return async (report: (done: number, total: number, stage: 'copying' | 'indexing') => void, _signal: AbortSignal) => {
      const realIn = assertPathAllowed(filePath, allowedDirs, 'import file_path')
      if (!existsSync(realIn)) throw new KbError(ErrorCodes.DOC_NOT_FOUND, `导出文件不存在: ${realIn}`)
      const isDir = statSync(realIn).isDirectory()
      const pack = JSON.parse(readFileSync(isDir ? join(realIn, 'manifest.json') : realIn, 'utf8'))
      if (pack.magic && pack.magic !== KBPACK_MAGIC) throw new KbError(ErrorCodes.DOC_PARSE_FAILED, `kbpack 版本不识别: ${pack.magic}`)
      if (mergeStrategy === 'merge' && !kbId) {
        throw new KbError(ErrorCodes.SRCH_BAD_FILTER, 'merge 策略必须提供 kb_id', 'create_new 可省略 kb_id（取包内 meta 名）')
      }
      // 身份校验
      const targetKbId = kbId ?? (pack.meta?.kb_id ? `imported-${randomUUID().slice(0, 8)}` : `imported-${randomUUID().slice(0, 8)}`)
      void targetKbId
      report(0, 2, 'copying')
      const docs = (pack.documents ?? []) as Array<{ doc_id: string; file_name: string; source_type: string; content_hash: string }>
      const conflicts: string[] = []
      let imported = 0
      for (let i = 0; i < docs.length; i++) {
        const d = docs[i]!
        const text = isDir
          // 文件名与 export 写盘一致：{doc_id}（原文件有扩展名）或 {doc_id}.raw（无扩展名）
          ? (() => { const p = join(realIn, 'documents', `${String(d.doc_id)}${String(d.file_name).includes('.') ? '' : '.raw'}`); return existsSync(p) ? readFileSync(p, 'utf8') : '' })()
          : (pack as { documents?: Array<{ text?: string }> }).documents?.[i]?.text ?? ''
        if (text) {
          await onImported(targetKbId, { file_name: d.file_name, source_type: d.source_type as never, text, source_key: `kbpack:${pack.meta?.kb_id ?? 'x'}:${d.doc_id}`, metadata: { from_kbpack: pack.meta?.kb_id ?? null } })
          imported++
        }
        void conflicts
        if (i % 10 === 0) report(i + 1, docs.length, 'copying')
      }
      report(2, 2, 'copying')
      return { kb_id: targetKbId, imported_docs: imported, conflicts }
    }
  }

  /** 读取迁移包的 meta（import_kb create_new 未给 kb_id 时取名建库用；只读不导入） */
  peekPackMeta(filePath: string, allowedDirs: string[]): { name?: string; kb_id?: string } {
    const realIn = assertPathAllowed(filePath, allowedDirs, 'import file_path')
    if (!existsSync(realIn)) throw new KbError(ErrorCodes.DOC_NOT_FOUND, `导出文件不存在: ${realIn}`)
    const isDir = statSync(realIn).isDirectory()
    const pack = JSON.parse(readFileSync(isDir ? join(realIn, 'manifest.json') : realIn, 'utf8')) as { meta?: { name?: string; kb_id?: string } }
    return { name: pack.meta?.name, kb_id: pack.meta?.kb_id }
  }

  private readRawText(store: KbStore, docId: string): string {
    for (const ext of ['', '.raw']) {
      const p = join(store.kbDir, 'documents', docId, 'raw' + ext)
      if (existsSync(p)) {
        try { return readFileSync(p, 'utf8') } catch { return '' }
      }
    }
    return ''
  }
}

function dirSize(dir: string): number {
  let total = 0
  for (const e of (existsSync(dir) ? readdirAll(dir) : [])) {
    const p = join(dir, e)
    const st = statSync(p)
    total += st.isDirectory() ? dirSize(p) : st.size
  }
  return total
}
function readdirAll(dir: string): string[] {
  return readdirSync(dir)
}
