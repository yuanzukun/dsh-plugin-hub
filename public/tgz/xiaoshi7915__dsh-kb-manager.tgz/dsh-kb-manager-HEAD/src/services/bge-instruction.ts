/** bge 系模型 query 侧 instruction 前缀（DESIGN §5.2） */
import type { KbConfig } from '../contracts/types.ts'

export function bgeQueryPrefix(cfg: KbConfig, query: string): string {
  const instruction = cfg.embedding.instruction
  return instruction ? `${instruction}${query}` : query
}
