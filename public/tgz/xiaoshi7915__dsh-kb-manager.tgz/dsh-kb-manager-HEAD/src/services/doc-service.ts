/**
 * 文档服务：导入管线（读→解析→分块→嵌入→单事务写入）、软删、恢复、列表（DESIGN §4.4/§6.5/§7.3）。
 * 幂等规则（§6.5）：
 * - source_key 命中且文档已软删、content_hash 相同 → 恢复（清 tombstone，不重嵌）
 * - source_key 命中且 status!=deleted、hash 相同 → unchanged（deduplicated）
 * - hash 变化 → 就地替换（旧块 tombstone + 新块写入，单事务）
 */
import { readFileSync, mkdirSync, writeFileSync } from 'node:fs'
import { join, basename } from 'node:path'
import { randomUUID, createHash } from 'node:crypto'
import type { ChunkRow, DocInfo, DocChunkItem, DocSourceType, EmbeddingIdentity, KbConfig } from '../contracts/types.ts'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import { tx, type KbStore } from '../store/store.ts'
import { parseDocument, isSupported, extOf } from '../parsers/index.ts'
import { chunkDocument, previewText } from '../chunker/index.ts'
import { tokenizeForFts } from '../index/bm25.ts'
import type { Embedder } from '../embedder/embedder.ts'
import { assertSameIdentity, EMBED_BATCH } from '../embedder/embedder.ts'
import type { JobProgress, JobStage } from '../contracts/types.ts'
import type { KbService } from './kb-service.ts'

export interface ImportResult {
  doc_id: string
  file_name: string
  chunk_count: number
  status: 'ok' | 'unchanged' | 'restored' | 'unparseable'
  deduplicated: boolean
  errors: string[]
}

export class DocService {
  constructor(
    private readonly kbs: KbService,
    private readonly embedder: () => Promise<Embedder>,
    private readonly cfg: () => KbConfig,
    private readonly workspace?: string,
  ) {}

  /** 默认导入白名单：会话 workspace + 存储 inbox（DESIGN §12 路径白名单） */
  private defaultAllowedDirs(): string[] {
    const dirs: string[] = []
    if (this.workspace) dirs.push(this.workspace)
    dirs.push(join(this.kbs.rootPath(), 'inbox'))
    return dirs
  }

  /** 文档状态 → WHERE 白名单（B3：防非法状态拼 SQL 崩库/注入；DESIGN §7.3） */
  private static readonly DOC_STATUS_WHERE: Record<string, string> = {
    importing: "status = 'importing'",
    ok: "status = 'ok'",
    unparseable: "status = 'unparseable'",
    failed: "status = 'failed'",
    deleted: "status = 'deleted'",
  }

  listDocuments(kbId: string, opts: { status?: string; limit?: number; offset?: number } = {}): { total: number; docs: DocInfo[] } {
    const store = this.kbs.getStore(kbId)
    const limit = Math.min(opts.limit ?? 50, 500)
    const offset = opts.offset ?? 0
    let where = "status NOT IN ('deleted')"
    if (opts.status) {
      const mapped = DocService.DOC_STATUS_WHERE[opts.status]
      if (!mapped) {
        throw new KbError(ErrorCodes.SRCH_BAD_FILTER, `未知文档状态: ${opts.status}`, '可选: importing / ok / unparseable / failed / deleted')
      }
      where = mapped
    }
    const total = (store.db.prepare(`SELECT COUNT(*) c FROM documents WHERE ${where}`).get() as { c: number }).c
    const rows = store.db.prepare(`SELECT * FROM documents WHERE ${where} ORDER BY imported_at DESC LIMIT ? OFFSET ?`).all(limit, offset) as Array<Record<string, unknown>>
    return { total, docs: rows.map(docFromRow) }
  }

  getDocument(kbId: string, docId: string): DocInfo {
    const store = this.kbs.getStore(kbId)
    const row = store.db.prepare('SELECT * FROM documents WHERE doc_id = ?').get(docId) as Record<string, unknown> | undefined
    if (!row) throw new KbError(ErrorCodes.DOC_NOT_FOUND, `文档不存在: ${docId}`, '用 list_documents 查看库内文档')
    return docFromRow(row)
  }

  /** 按文档列出已入库分块（deleted=0，按 ord 排序），供 Web 面板“查看分块”。 */
  listDocChunks(kbId: string, docId: string): DocChunkItem[] {
    const store = this.kbs.getStore(kbId)
    const row = store.db.prepare('SELECT doc_id FROM documents WHERE doc_id = ? AND status != \'deleted\'').get(docId) as { doc_id: string } | undefined
    if (!row) throw new KbError(ErrorCodes.DOC_NOT_FOUND, `文档不存在或已删除: ${docId}`)
    const rows = store.db.prepare(
      `SELECT chunk_id, ord, text, heading_path, page_num, token_count
       FROM chunks WHERE doc_id = ? AND deleted = 0 ORDER BY ord ASC`,
    ).all(docId) as Array<Record<string, unknown>>
    return rows.map((r) => ({
      chunk_id: String(r.chunk_id),
      ord: Number(r.ord),
      text: String(r.text),
      heading_path: String(r.heading_path ?? ''),
      page_num: r.page_num == null ? null : Number(r.page_num),
      token_count: Number(r.token_count),
    }))
  }

  /** 同步软删（DESIGN §4.4）：毫秒级；检索立即可见性消失；物理回收走 compact_index。 */
  deleteDocument(kbId: string, docId: string): { success: boolean; removed_chunks: number } {
    const store = this.kbs.getStore(kbId)
    const removed = tx(store, (db) => {
      const row = db.prepare('SELECT doc_id, chunk_count FROM documents WHERE doc_id = ? AND status != \'deleted\'').get(docId) as { doc_id: string; chunk_count: number } | undefined
      if (!row) throw new KbError(ErrorCodes.DOC_NOT_FOUND, `文档不存在或已删除: ${docId}`)
      db.prepare('UPDATE documents SET status = ?, updated_at = ? WHERE doc_id = ?').run('deleted', nowIso(), docId)
      db.prepare('UPDATE chunks SET deleted = 1 WHERE doc_id = ?').run(docId)
      return row.chunk_count
    })
    return { success: true, removed_chunks: removed }
  }

  /**
   * 导入工作函数（由 JobQueue 调度执行）。
   * report 回调推进 job 进度（stage 序列：reading → parsing → chunking → embedding → indexing）。
   */
  importWork(kbId: string, source: string, sourceType: DocSourceType | 'auto', metadata: Record<string, unknown> = {}) {
    return async (report: (done: number, total: number, stage: JobStage) => void, signal: AbortSignal) => {
      const cfg = this.cfg()
      const store = this.kbs.getStore(kbId)
      const meta = this.kbs.getKb(kbId)
      report(0, 5, 'reading')

      // 1) 读取
      const isUrl = /^https?:\/\//i.test(source)
      let text: string
      let fileName: string
      let resolvedSource: string
      if (isUrl) {
        const { fetchUrl } = await import('../parsers/url.ts')
        const r = await fetchUrl(source, join(this.kbs.rootPath(), 'cache'), {
          allowlist: cfg.import_url_allowlist,
          maxBytes: cfg.max_file_size_mb * 1024 * 1024,
        })
        text = r.text
        // URL 无文件名/无已知扩展名时默认按 HTML 解析（网页几乎都是 HTML），
        // 避免 basename 为空或为 host（如 example.com 被当作 .com 文件）导致"不支持的类型"。
        const base = basename(r.finalUrl.split('?')[0]!)
        fileName = base && isSupported(base) ? base : 'index.html'
        resolvedSource = r.finalUrl
      } else {
        const { assertPathAllowed, assertFileWithinLimit } = await import('../security/path-guard.ts')
        const real = assertPathAllowed(source, cfg.import_allowed_dirs.length ? cfg.import_allowed_dirs : this.defaultAllowedDirs(), 'import source')
        assertFileWithinLimit(real, cfg.max_file_size_mb * 1024 * 1024, 'file')
        text = readFileSync(real, 'utf8')
        fileName = basename(real)
        resolvedSource = real
      }
      if (signal.aborted) throw new KbError('JOB.CANCELLED', '任务已取消')

      // 2) 解析
      report(1, 5, 'parsing')
      const type: DocSourceType = sourceType === 'auto' ? (extOf(fileName) as DocSourceType) : sourceType
      let parseFailed: string | null = null
      let parsed: ReturnType<typeof parseDocument> | null = null
      if (!isSupported(fileName, sourceType === 'auto' ? undefined : sourceType)) {
        parseFailed = `不支持的类型 .${extOf(fileName)}`
      } else {
        try {
          parsed = parseDocument(text, fileName, sourceType === 'auto' ? undefined : sourceType)
        } catch (e) {
          parseFailed = (e as Error).message
        }
      }

      const sourceKey = resolvedSource
      const contentHash = createHash('sha256').update(text).digest('hex')
      const existing = store.db.prepare('SELECT * FROM documents WHERE source_key = ?').get(sourceKey) as Record<string, unknown> | undefined

      // 幂等：未变化
      if (existing && String(existing.status) !== 'deleted' && String(existing.content_hash) === contentHash) {
        report(5, 5, 'indexing')
        return { doc_id: String(existing.doc_id), file_name: String(existing.file_name), chunk_count: Number(existing.chunk_count), status: 'unchanged', deduplicated: true, errors: [] } as ImportResult
      }

      // 解析失败：登记 unparseable（原文已可溯源），不入库向量
      if (!parsed) {
        const docId = existing ? String(existing.doc_id) : randomUUID()
        tx(store, (db) => {
          // B10：此前 ok/importing 的文档内容变化后解析失败 → 就地替换语义应同时 tombstone 旧块，
          // 否则旧内容仍可检索、挂在 unparseable 文档下
          if (existing && String(existing.status) !== 'deleted' && Number(existing.chunk_count) > 0) {
            db.prepare('UPDATE chunks SET deleted = 1 WHERE doc_id = ?').run(docId)
          }
          db.prepare(
            `INSERT INTO documents (doc_id, file_name, source_type, source_key, content_hash, status, chunk_count, size_bytes, metadata_json, imported_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)
             ON CONFLICT(doc_id) DO UPDATE SET status=excluded.status, content_hash=excluded.content_hash, size_bytes=excluded.size_bytes, updated_at=excluded.updated_at`,
          ).run(docId, fileName, type, sourceKey, contentHash, 'unparseable', 0, Buffer.byteLength(text), JSON.stringify(metadata), nowIso(), nowIso())
        })
        this.writeRaw(store, docId, text)
        report(5, 5, 'indexing')
        return { doc_id: docId, file_name: fileName, chunk_count: 0, status: 'unparseable', deduplicated: false, errors: [parseFailed!] } as ImportResult
      }

      // 3-5) 分块→嵌入→单事务写入（共享管线，import_kb 的 importText 复用）
      return this.indexParsed({
        kbId, store, meta, parsed,
        fileName, type, sourceKey, text, contentHash, metadata,
        docId: existing ? String(existing.doc_id) : randomUUID(),
        wasDeleted: existing ? String(existing.status) === 'deleted' : false,
        hasExisting: !!existing,
        report, signal,
      })
    }
  }

  /**
   * 从包内文本导入单文档（import_kb 的 onImported 复用管线）。
   * source_key 幂等：同 key 未变 → unchanged；变化 → 就地替换（旧块 tombstone）。
   * 解析失败登记 unparseable（原文可溯源，不阻断包导入）。
   */
  async importText(kbId: string, doc: { file_name: string; source_type: string; text: string; source_key: string; metadata: Record<string, unknown> }): Promise<ImportResult> {
    const store = this.kbs.getStore(kbId)
    const meta = this.kbs.getKb(kbId)
    const fileName = doc.file_name || 'import.md'
    const type: DocSourceType = extOf(fileName) as DocSourceType
    const contentHash = createHash('sha256').update(doc.text).digest('hex')
    const sourceKey = doc.source_key || contentHash
    const existing = store.db.prepare('SELECT * FROM documents WHERE source_key = ?').get(sourceKey) as Record<string, unknown> | undefined
    if (existing && String(existing.status) !== 'deleted' && String(existing.content_hash) === contentHash) {
      return { doc_id: String(existing.doc_id), file_name: String(existing.file_name), chunk_count: Number(existing.chunk_count), status: 'unchanged', deduplicated: true, errors: [] } as ImportResult
    }
    let parsed: ReturnType<typeof parseDocument> | null = null
    let parseFailed: string | null = null
    if (!isSupported(fileName)) parseFailed = `不支持的类型 .${extOf(fileName)}`
    else {
      try { parsed = parseDocument(doc.text, fileName) } catch (e) { parseFailed = (e as Error).message }
    }
    const docId = existing ? String(existing.doc_id) : randomUUID()
    const wasDeleted = existing ? String(existing.status) === 'deleted' : false
    if (!parsed) {
      tx(store, (db) => {
        if (existing && String(existing.status) !== 'deleted' && Number(existing.chunk_count) > 0) {
          db.prepare('UPDATE chunks SET deleted = 1 WHERE doc_id = ?').run(docId)
        }
        db.prepare(
          `INSERT INTO documents (doc_id, file_name, source_type, source_key, content_hash, status, chunk_count, size_bytes, metadata_json, imported_at, updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)
           ON CONFLICT(doc_id) DO UPDATE SET status=excluded.status, content_hash=excluded.content_hash, size_bytes=excluded.size_bytes, updated_at=excluded.updated_at`,
        ).run(docId, fileName, type, sourceKey, contentHash, 'unparseable', 0, Buffer.byteLength(doc.text), JSON.stringify(doc.metadata ?? {}), nowIso(), nowIso())
      })
      this.writeRaw(store, docId, doc.text)
      return { doc_id: docId, file_name: fileName, chunk_count: 0, status: 'unparseable', deduplicated: false, errors: [parseFailed!] } as ImportResult
    }
    return this.indexParsed({
      kbId, store, meta, parsed,
      fileName, type, sourceKey, text: doc.text, contentHash, metadata: doc.metadata ?? {},
      docId, wasDeleted, hasExisting: !!existing,
      report: () => undefined, signal: new AbortController().signal,
    })
  }

  /** 原文持久化：documents/{docId}/raw（export_kb json/kbpack 文档 text 溯源；kbpack 逐文件 sha256 依赖） */
  private writeRaw(store: KbStore, docId: string, text: string): void {
    try {
      const dir = join(store.kbDir, 'documents', docId)
      mkdirSync(dir, { recursive: true })
      writeFileSync(join(dir, 'raw'), text)
    } catch { /* 原文写入失败不阻断导入（DB 内已有解析文本） */ }
  }

  /** 共享管线：分块 → 嵌入（身份校验 + 批处理）→ 单事务写入 + meta empty→ready（§4.3 原子性） */  private async indexParsed(ctx: {
    kbId: string
    store: KbStore
    meta: { embedding: EmbeddingIdentity }
    parsed: ReturnType<typeof parseDocument>
    fileName: string
    type: DocSourceType
    sourceKey: string
    text: string
    contentHash: string
    metadata: Record<string, unknown>
    docId: string
    wasDeleted: boolean
    hasExisting: boolean
    report: (done: number, total: number, stage: JobStage) => void
    signal: AbortSignal
  }): Promise<ImportResult> {
    const cfg = this.cfg()
    const { kbId, store, meta, parsed, fileName, type, sourceKey, text, contentHash, metadata, docId, wasDeleted, hasExisting, report, signal } = ctx
    // 3) 分块
    report(2, 5, 'chunking')
    const params = {
      chunkSize: cfg.chunk_size,
      chunkOverlap: cfg.chunk_overlap,
      strategy: cfg.chunk_strategy,
      tableChunkMaxTokens: cfg.table_chunk_max_tokens,
      csvRowsPerChunk: cfg.csv_rows_per_chunk,
    }
    const drafts = chunkDocument(parsed, params)

    // 4) 嵌入（身份校验 + 批处理；批边界响应取消）
    report(3, 5, 'embedding')
    const emb = await this.embedder()
    assertSameIdentity(meta.embedding, emb.identity(), 'KB 绑定身份与当前 provider')
    const vectors: number[][] = []
    for (let i = 0; i < drafts.length; i += EMBED_BATCH) {
      if (signal.aborted) throw new KbError('JOB.CANCELLED', '任务已取消')
      vectors.push(...await emb.embed(drafts.slice(i, i + EMBED_BATCH).map((d) => d.text), signal))
      report(3 + (i + EMBED_BATCH) / Math.max(1, drafts.length * 4), 5, 'embedding')
    }

    // 5) 单事务写入（§4.3 原子性；软删恢复 / 新增 / 替换三态）
    report(4, 5, 'indexing')
    const chunks: ChunkRow[] = drafts.map((d, i) => ({
      ...d,
      chunk_id: `${kbId}:${docId}:${i}`,
      doc_id: docId,
      ord: i,
      deleted: 0,
    }))
    const chunkCount = tx(store, (db) => {
      if (wasDeleted || hasExisting) {
        // 替换/恢复：物理删除旧块与向量（FTS 删除触发器自动同步；chunk_id 由 kbId:docId:ord 决定，必须清掉避免主键冲突），随后统一插入新块
        db.prepare('DELETE FROM vec_chunks WHERE chunk_id IN (SELECT chunk_id FROM chunks WHERE doc_id = ?)').run(docId)
        db.prepare('DELETE FROM chunks WHERE doc_id = ?').run(docId)
      }
      db.prepare(
        `INSERT INTO documents (doc_id, file_name, source_type, source_key, content_hash, status, chunk_count, size_bytes, metadata_json, imported_at, updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)
         ON CONFLICT(doc_id) DO UPDATE SET file_name=excluded.file_name, source_type=excluded.source_type, content_hash=excluded.content_hash, status='ok', chunk_count=excluded.chunk_count, size_bytes=excluded.size_bytes, metadata_json=excluded.metadata_json, updated_at=excluded.updated_at`,
      ).run(docId, fileName, type, sourceKey, contentHash, 'ok', chunks.length, Buffer.byteLength(text), JSON.stringify(metadata), nowIso(), nowIso())
      const insChunk = db.prepare(
        `INSERT INTO chunks (chunk_id, doc_id, ord, text, bm25_text, deleted, heading_path, heading_level, page_num, char_start, char_end, token_count, table_detected, metadata_json)
         VALUES (?,?,?,?,?,0,?,?,?,?,?,?,?,?)`,
      )
      const insVec = db.prepare('INSERT INTO vec_chunks (chunk_id, embedding) VALUES (?, ?)')
      for (let i = 0; i < chunks.length; i++) {
        const c = chunks[i]!
        insChunk.run(c.chunk_id, c.doc_id, c.ord, c.text, tokenizeForFts(c.text), c.heading_path, c.heading_level, c.page_num, c.char_start, c.char_end, c.token_count, c.table_detected ? 1 : 0, JSON.stringify(c.metadata))
        insVec.run(c.chunk_id, new Float32Array(vectors[i]!))
      }
      return chunks.length
    })
    // meta 状态迁移 empty→ready
    const metaAfter = this.kbs.getKb(kbId)
    if (metaAfter.status === 'empty') {
      const { readMeta, writeMeta } = await import('../store/store.ts')
      const m = readMeta(store)!
      m.status = 'ready'
      m.updated_at = nowIso()
      writeMeta(store, m)
    }
    // 原文持久化（export_kb json/kbpack 的文档 text 溯源依赖 documents/{docId}/raw）
    this.writeRaw(store, docId, text)
    report(5, 5, 'indexing')
    return {
      doc_id: docId,
      file_name: fileName,
      chunk_count: chunkCount,
      status: wasDeleted ? 'restored' : 'ok',
      deduplicated: false,
      errors: [],
    } as ImportResult
  }

  /** 重建索引/换引擎/换模型（DESIGN §7.3 rebuild_index） */
  rebuildWork(kbId: string, opts: { targetEngine?: 'sqlite-vec' | 'usearch'; embedding?: { model: string; provider: string; dim: number } }) {
    return async (report: (done: number, total: number, stage: JobStage) => void, signal: AbortSignal) => {
      const store = this.kbs.getStore(kbId)
      const emb = await this.embedder()
      // usearch 引擎 v1.2 才交付；避免 meta.backend 谎报为 usearch 实仍用 sqlite-vec
      if (opts.targetEngine && opts.targetEngine !== 'sqlite-vec') {
        throw new KbError(ErrorCodes.IDX_ENGINE_BUSY, `目标引擎 "${opts.targetEngine}" 尚未交付（v1.2）`, '当前仅支持 sqlite-vec；target_engine 留空即可')
      }
      // B5：换模型唯一合法路径 = 先 configure 再 rebuild；目标身份必须与当前 embedder 一致，
      // 否则向量会被错误身份标记（静默损坏）。不一致 → 干净报错，不改写 meta。
      if (opts.embedding) {
        assertSameIdentity(opts.embedding as EmbeddingIdentity, emb.identity(), 'rebuild_index 目标身份与当前 embedder')
      }
      let reembed = false
      if (opts.embedding) {
        reembed = true
        const m = this.kbs.getKb(kbId)
        if (m.embedding.model !== opts.embedding.model || m.embedding.provider !== opts.embedding.provider || m.embedding.dim !== opts.embedding.dim) {
          // 更新 KB 身份（唯一合法换模型路径）
          const { readMeta, writeMeta } = await import('../store/store.ts')
          const meta = readMeta(store)!
          meta.embedding = { ...opts.embedding }
          meta.updated_at = nowIso()
          writeMeta(store, meta)
        }
      }
      if (opts.targetEngine) {
        const { readMeta, writeMeta } = await import('../store/store.ts')
        const meta = readMeta(store)!
        meta.backend = opts.targetEngine
        meta.updated_at = nowIso()
        writeMeta(store, meta)
      }
      const rows = store.db.prepare("SELECT chunk_id, text FROM chunks WHERE deleted = 0 ORDER BY doc_id, ord").all() as Array<{ chunk_id: string; text: string }>
      if (!reembed && !opts.targetEngine) {
        report(1, 1, 'indexing')
        return { success: true, chunk_count: rows.length, elapsed_ms: 0 }
      }
      report(0, rows.length, 'embedding')
      const ids: string[] = []
      const vecs: number[][] = []
      for (let i = 0; i < rows.length; i += EMBED_BATCH) {
        if (signal.aborted) throw new KbError('JOB.CANCELLED', '任务已取消')
        const batch = rows.slice(i, i + EMBED_BATCH)
        const v = await emb.embed(batch.map((r) => r.text), signal)
        batch.forEach((r, j) => { ids.push(r.chunk_id); vecs.push(v[j]!) })
        report(i + batch.length, rows.length, 'embedding')
      }
      const started = Date.now()
      report(rows.length, rows.length, 'indexing')
      tx(store, (db) => {
        const del = db.prepare('DELETE FROM vec_chunks')
        del.run()
        const ins = db.prepare('INSERT INTO vec_chunks (chunk_id, embedding) VALUES (?, ?)')
        for (let i = 0; i < ids.length; i++) ins.run(ids[i]!, new Float32Array(vecs[i]!))
      })
      report(rows.length, rows.length, 'indexing')
      return { success: true, chunk_count: rows.length, elapsed_ms: Date.now() - started }
    }
  }

  /** compact：物理回收 tombstone（DESIGN §4.4） */
  compactWork(kbId: string) {
    return async (report: (done: number, total: number, stage: JobStage) => void, signal: AbortSignal) => {
      const store = this.kbs.getStore(kbId)
      report(0, 3, 'indexing')
      const removed = tx(store, (db) => {
        const n = (db.prepare('DELETE FROM chunks WHERE deleted = 1').run().changes) as number
        db.prepare('DELETE FROM vec_chunks WHERE chunk_id NOT IN (SELECT chunk_id FROM chunks)').run()
        db.prepare("INSERT OR REPLACE INTO kv (key, value) VALUES ('deleted_ratio', '0')").run()
        return n
      })
      report(1, 3, 'indexing')
      store.db.exec('DELETE FROM chunks_fts') // FTS 重建（触发器保证后续同步）
      store.db.exec('INSERT INTO chunks_fts(rowid, bm25_text) SELECT rowid, bm25_text FROM chunks')
      store.db.pragma('optimize')
      if (signal.aborted) throw new KbError('JOB.CANCELLED', '任务已取消')
      store.db.pragma('vacuum')
      report(3, 3, 'indexing')
      return { removed_chunks: removed }
    }
  }

  /** 预览采样（DESIGN §9：前 2 万字符） */
  previewChunks(kbId: string, docPath: string): string[] {
    void kbId
    const { assertPathAllowed } = require('../security/path-guard.ts') as typeof import('../security/path-guard.ts')
    void assertPathAllowed; void docPath
    return []
  }
}

function docFromRow(r: Record<string, unknown>): DocInfo {
  return {
    doc_id: String(r.doc_id),
    file_name: String(r.file_name),
    source_type: r.source_type as DocInfo['source_type'],
    source_key: String(r.source_key),
    content_hash: String(r.content_hash),
    status: r.status as DocInfo['status'],
    chunk_count: Number(r.chunk_count),
    size_bytes: Number(r.size_bytes),
    metadata_json: String(r.metadata_json ?? '{}'),
    imported_at: String(r.imported_at),
    updated_at: String(r.updated_at),
  }
}

function nowIso(): string {
  return new Date().toISOString()
}

export { previewText }
