/**
 * 快照服务（DESIGN §4.3/§7.3）：create 同步秒级 + LRU；restore 两步确认（dry-run 先返回 impact）。
 */
import { randomUUID } from 'node:crypto'
import type { KbStore } from '../store/store.ts'
import { createSnapshot, listSnapshots, readSnapshotManifest, restoreSnapshotDb } from '../store/store.ts'
import { KbError, ErrorCodes, ConfirmTokens } from '../contracts/errors.ts'

export class SnapshotService {
  constructor(
    private readonly getStore: (kbId: string) => KbStore,
    private readonly enqueue: (kbId: string, work: (report: (done: number, total: number, stage: 'copying' | 'indexing') => void, signal: AbortSignal) => Promise<unknown>) => { job_id: string },
    private readonly confirms?: ConfirmTokens,
  ) {}

  async create(kbId: string, note?: string) {
    const store = this.getStore(kbId)
    return createSnapshot(store, `snap-${randomUUID().slice(0, 8)}`, note)
  }

  list(kbId: string, limit = 20, offset = 0): { total: number; snapshots: Array<{ snapshot_id: string; created_at: string; note: string | null; doc_count: number; size_bytes: number }> } {
    // DESIGN §C.4 list_snapshots 契约：{ total, snapshots }；total 为全部快照数（不受分页截断）
    const store = this.getStore(kbId)
    const total = (store.db.prepare('SELECT COUNT(*) c FROM snapshots').get() as { c: number }).c
    const snapshots = listSnapshots(store, limit, offset)
    return { total, snapshots }
  }

  /** 无 token：dry-run（impact + token，不入队）；带有效 token：入队执行。token 经 ConfirmTokens 签发/校验（§8.4，5 分钟单用）。 */
  restore(kbId: string, snapshotId: string, confirmToken?: string):
    | { requires_confirm: true; confirm_token: string; impact: { restored_docs: number; removed_chunks: number; freed_bytes: number } }
    | { requires_confirm: false; job_id: string; status: 'queued' } {
    const store = this.getStore(kbId)
    const manifest = readSnapshotManifest(store, snapshotId)
    if (!manifest) throw new KbError(ErrorCodes.DOC_NOT_FOUND, `快照不存在: ${snapshotId}`, '用 list_snapshots 查看可用快照')
    const scope = `restore:${kbId}:${snapshotId}`
    if (!confirmToken) {
      const curChunks = (store.db.prepare('SELECT COUNT(*) c FROM chunks WHERE deleted = 0').get() as { c: number }).c
      const token = this.confirms
        ? this.confirms.issue(scope)
        : `${scope}:${Date.now()}:${Math.random().toString(36).slice(2, 10)}`
      return {
        requires_confirm: true,
        confirm_token: token,
        impact: {
          restored_docs: Number(manifest.doc_count ?? 0),
          removed_chunks: Math.max(0, curChunks - Number(manifest.chunk_count ?? 0)),
          freed_bytes: 0,
        },
      }
    }
    // B9：token 必须经 ConfirmTokens 校验（有效+单用+TTL）；未注入时退化为格式校验
    if (this.confirms && !this.confirms.consume(confirmToken, scope)) {
      throw new KbError(ErrorCodes.SEC_CONFIRM_REQUIRED, '确认 token 无效或已过期', '不带 confirm_token 重新调用 restore_snapshot 获取新确认')
    }
    const job = this.enqueue(kbId, this.restoreWork(kbId, snapshotId))
    return { requires_confirm: false, job_id: job.job_id, status: 'queued' }
  }

  private restoreWork(kbId: string, snapshotId: string) {
    return async (report: (done: number, total: number, stage: 'copying' | 'indexing') => void, _signal: AbortSignal) => {
      const store = this.getStore(kbId)
      report(0, 3, 'copying')
      const autoId = `snap-auto-${randomUUID().slice(0, 8)}`
      await createSnapshot(store, autoId, '恢复前自动备份')
      report(1, 3, 'copying')
      restoreSnapshotDb(store, snapshotId)
      report(2, 3, 'indexing')
      // 原文 reconcile：manifest.docs 中缺 raw 文件的 doc 标 failed（向量仍在，可检索、原文不可溯）
      const manifest = readSnapshotManifest(store, snapshotId)
      const docs = (manifest?.docs ?? []) as Array<{ doc_id: string }>
      const { join } = await import('node:path')
      const { existsSync } = await import('node:fs')
      const missing = docs.filter((d) => !existsSync(join(store.kbDir, 'documents', d.doc_id, 'raw'))).length
      if (missing > 0) {
        const mark = store.db.prepare("UPDATE documents SET status='failed' WHERE doc_id = ? AND status != 'failed'")
        for (const d of docs) {
          if (!existsSync(join(store.kbDir, 'documents', d.doc_id, 'raw'))) mark.run(d.doc_id)
        }
      }
      report(3, 3, 'indexing')
      return { snapshot_id: snapshotId, auto_backup: autoId, docs_checked: docs.length, docs_missing_raw: missing }
    }
  }
}
