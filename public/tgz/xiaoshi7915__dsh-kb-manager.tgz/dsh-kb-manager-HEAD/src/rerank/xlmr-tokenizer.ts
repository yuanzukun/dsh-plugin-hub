/**
 * XLM-RoBERTa Unigram 分词器（bge-reranker-base，DESIGN §5.4）。
 * 对齐 transformers.js 的 XLM-R fast tokenizer（tokenizer.json）：
 * - 归一化：NFKC（JS 内置，近似 sentencepiece Precompiled charsmap 主体）+ 空格类/控制字符清理
 * - 预分词：Metaspace（add_prefix_space → 前缀空格；空格 → ▁）
 * - 模型：Unigram Viterbi（词表 log-score 上 DP + 回溯；<unk> 兜底）
 * - pair 编码：<s> A </s></s> B </s> → [0, A, 2, 2, B, 2]（XLM-R 无 token_type_ids）
 */
export interface XlmrEncoding {
  inputIds: number[]
  attentionMask: number[]
}

interface VocabEntry {
  id: number
  score: number
}

export class XlmrUnigramTokenizer {
  private readonly vocab = new Map<string, VocabEntry>()
  private readonly specialIds = new Set<number>()
  readonly bosId = 0 // <s>
  readonly padId = 1 // <pad>
  readonly eosId = 2 // </s>
  readonly unkId = 3 // <unk>
  private readonly maxLen: number
  private readonly maxTokenLen: number

  constructor(tokenizerJson: { model?: { vocab?: Array<[string, number]> }; added_tokens?: Array<{ id: number; special?: boolean }> }, maxLen = 512) {
    const model = tokenizerJson.model as { vocab?: Array<[string, number]> }
    for (const [token, score] of model?.vocab ?? []) {
      this.vocab.set(token, { id: this.vocab.size, score })
    }
    for (const tok of tokenizerJson.added_tokens ?? []) {
      if (tok.special) this.specialIds.add(tok.id)
    }
    this.maxLen = maxLen
    let max = 0
    for (const t of this.vocab.keys()) max = Math.max(max, [...t].length)
    this.maxTokenLen = Math.min(max, 64)
  }

  vocabSize(): number {
    return this.vocab.size
  }

  /** 近似 sentencepiece 归一化：NFKC + 全角空格→空格 + 控制字符清理（不 lowercase） */
  private normalize(text: string): string {
    let out = text.normalize('NFKC')
    out = out.replace(/\u3000/gu, ' ')
    out = out.replace(/\t/gu, ' ').replace(/\n/gu, ' ').replace(/\r/gu, ' ')
    let cleaned = ''
    for (const c of out) {
      const code = c.codePointAt(0)!
      if (code === 0 || code === 0xfffd || (code >= 0x1 && code <= 0x1f) || code === 0x7f) continue
      cleaned += c
    }
    return cleaned
  }

  /** Metaspace：add_prefix_space → 前缀空格；所有空格 → ▁ */
  private metaspace(text: string): string {
    return (' ' + text).split(' ').join('▁')
  }

  /** Unigram Viterbi：最小负对数似然切分，返回 token 字符串数组 */
  private unigramSplit(text: string): string[] {
    if (text.length === 0) return []
    const n = text.length
    const bestScore = new Float64Array(n + 1).fill(Infinity)
    const bestStart = new Int32Array(n + 1).fill(-1)
    bestScore[0] = 0
    for (let i = 0; i < n; i++) {
      const base = bestScore[i]!
      if (base === Infinity) continue
      const maxL = Math.min(this.maxTokenLen, n - i)
      // 优先匹配长 token（词表顺序与长度无关，遍历长度）
      for (let l = 1; l <= maxL; l++) {
        const entry = this.vocab.get(text.slice(i, i + l))
        if (!entry || this.specialIds.has(entry.id)) continue
        const sc = base - entry.score // score = log(P)<0；-score = -log(P)
        if (sc < (bestScore[i + l] ?? Infinity)) {
          bestScore[i + l] = sc
          bestStart[i + l] = i
        }
      }
    }
    if (bestScore[n] === Infinity) {
      // 完全无法覆盖 → 整体 <unk>（保持字符级兜底）
      return ['<unk>']
    }
    const out: string[] = []
    let pos = n
    while (pos > 0) {
      const start = bestStart[pos]!
      if (start < 0) { out.unshift('<unk>'); break }
      out.unshift(text.slice(start, pos))
      pos = start
    }
    return out
  }

  /** pair 编码：<s> A </s></s> B </s>，截断 maxLen（为 2×</s> 预留），不 pad（ONNX 动态长度） */
  encodePair(query: string, passage: string): XlmrEncoding {
    const qTokens = this.unigramSplit(this.metaspace(this.normalize(query)))
    const pTokens = this.unigramSplit(this.metaspace(this.normalize(passage)))
    const ids = [this.bosId]
    const reserved = 4 // <s> + </s></s> + </s>
    const qCap = Math.max(0, this.maxLen - reserved)
    const pCap = Math.max(0, this.maxLen - reserved - qTokens.length)
    for (const t of qTokens.slice(0, qCap)) ids.push(this.vocab.get(t)?.id ?? this.unkId)
    ids.push(this.eosId)
    ids.push(this.eosId)
    for (const t of pTokens.slice(0, pCap)) ids.push(this.vocab.get(t)?.id ?? this.unkId)
    ids.push(this.eosId)
    if (ids.length > this.maxLen) ids.length = this.maxLen
    return { inputIds: ids, attentionMask: new Array(ids.length).fill(1) }
  }

  /** 调试：输出 token 字符串 */
  debugPair(query: string, passage: string): string[] {
    const idToToken = new Map<number, string>()
    for (const [t, { id }] of this.vocab) idToToken.set(id, t)
    return this.encodePair(query, passage).inputIds.map((id) => idToToken.get(id) ?? `#${id}`)
  }
}
