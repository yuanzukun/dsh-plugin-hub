/**
 * bge-reranker-base ONNX 重排序引擎（DESIGN §5.4，v1.1 交付）：
 * - Xenova/bge-reranker-base（XLM-RoBERTa cross-encoder，int8 量化 model_quantized.onnx）
 * - 首次使用自动下载模型 + tokenizer.json（hf-mirror 国内直连源 + sha256 校验）
 * - 输入：(query, passage) → XLM-R pair 编码 → input_ids / attention_mask（无 token_type_ids）
 * - 输出：logits[0] → sigmoid → [0,1] 相关性分数
 */
import { createHash } from 'node:crypto'
import { createReadStream, createWriteStream, existsSync, mkdirSync } from 'node:fs'
import { readFile, rename, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { Readable } from 'node:stream'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import type { Reranker, RerankCandidate } from '../index/rerank.ts'
import { XlmrUnigramTokenizer } from './xlmr-tokenizer.ts'

const RERANK_MODEL = 'bge-reranker-base'
// hf-mirror 国内直连（sha256 = HF LFS oid，下载后复核）
const MODEL_URL = 'https://hf-mirror.com/Xenova/bge-reranker-base/resolve/main/onnx/model_quantized.onnx'
const MODEL_SHA256 = 'dd98f3e67837d23210a6b7550c08cced4f61845b940ac45be3565840a10f3244'
const TOKENIZER_URL = 'https://hf-mirror.com/Xenova/bge-reranker-base/resolve/main/tokenizer.json'
const TOKENIZER_SHA256 = '48564c5c7d3fa64d85d95e65414a542385f88b0f128fd8d4163fd7a57f2be05c'

type Ort = typeof import('onnxruntime-node')

function sha256File(path: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash = createHash('sha256')
    const stream = createReadStream(path)
    stream.on('data', (d) => hash.update(d))
    stream.on('end', () => resolve(hash.digest('hex')))
    stream.on('error', reject)
  })
}

async function downloadFile(url: string, dest: string, tmp: string): Promise<void> {
  const res = await fetch(url, { redirect: 'follow' })
  if (!res.ok || !res.body) throw new KbError(ErrorCodes.EMB_NOT_READY, `重排序模型下载失败 HTTP ${res.status}: ${url}`, '网络不可达时可在插件配置页确认后重试')
  await new Promise<void>((resolve, reject) => {
    const ws = createWriteStream(tmp)
    Readable.fromWeb(res.body as never).pipe(ws)
    ws.on('finish', () => { ws.close(); resolve() })
    ws.on('error', reject)
  })
}

export class OnnxReranker implements Reranker {
  private session: Awaited<ReturnType<Ort['InferenceSession']['create']>> | null = null
  private tokenizer: XlmrUnigramTokenizer | null = null
  private ort: Ort | null = null

  constructor(
    private readonly modelDir: string,
    private readonly model: string = RERANK_MODEL,
  ) {}

  available(): boolean {
    return !!this.session
  }

  /** 懒加载：onnxruntime → 确保模型/tokenizer 文件（自动下载 + sha256）→ session；失败向上抛 */
  async ensureReady(): Promise<void> {
    if (this.session) return
    let ort: Ort
    try {
      ort = (await import('onnxruntime-node')) as Ort
    } catch {
      throw new KbError(ErrorCodes.EMB_NOT_READY, 'onnxruntime-node 依赖加载失败（可选依赖缺失或安装失败）', '请重新安装插件；或关闭 enable_rerank 临时退回 RRF。')
    }
    this.ort = ort
    mkdirSync(this.modelDir, { recursive: true })
    const modelPath = join(this.modelDir, 'model.onnx')
    const tokenizerPath = join(this.modelDir, 'tokenizer.json')
    await this.ensureFile(modelPath, MODEL_URL, MODEL_SHA256, '重排序模型')
    await this.ensureFile(tokenizerPath, TOKENIZER_URL, TOKENIZER_SHA256, '重排序词表')
    const tokenizerJson = JSON.parse(await readFile(tokenizerPath, 'utf8'))
    this.tokenizer = new XlmrUnigramTokenizer(tokenizerJson)
    this.session = await ort.InferenceSession.create(modelPath)
  }

  /** 下载到临时文件 → sha256 校验 → 原子替换；失败清理（不落脏数据） */
  private async ensureFile(dest: string, url: string, expected: string, what: string): Promise<void> {
    if (!/^[0-9a-f]{64}$/i.test(expected)) {
      throw new KbError(ErrorCodes.EMB_NOT_READY, `${what} sha256 未配置（当前: ${expected}）`, '需开发者先下载模型计算哈希后填入配置，再重试')
    }
    if (existsSync(dest) && (await sha256File(dest)) === expected) return
    const tmp = `${dest}.tmp`
    try {
      await downloadFile(url, dest, tmp)
      const actual = await sha256File(tmp)
      if (actual !== expected) {
        throw new KbError(ErrorCodes.EMB_NOT_READY, `${what} 校验失败 sha256 不匹配（期望 ${expected.slice(0, 12)}…，实际 ${actual.slice(0, 12)}…）`, '下载可能被篡改，请重试')
      }
      await rm(dest, { force: true })
      await rename(tmp, dest)
    } catch (e) {
      await rm(tmp, { force: true }).catch(() => undefined)
      throw e
    }
  }

  async rerank(query: string, candidates: RerankCandidate[], topN: number): Promise<Array<{ chunk_id: string; score: number }>> {
    await this.ensureReady()
    const ort = this.ort!
    const session = this.session!
    const tokenizer = this.tokenizer!
    const out: Array<{ chunk_id: string; score: number }> = []
    for (const c of candidates) {
      const enc = tokenizer.encodePair(query, c.text)
      const n = enc.inputIds.length
      const feeds: Record<string, unknown> = {
        input_ids: new ort.Tensor('int64', BigInt64Array.from(enc.inputIds.map((x) => BigInt(x))), [1, n]),
        attention_mask: new ort.Tensor('int64', BigInt64Array.from(enc.attentionMask.map((x) => BigInt(x))), [1, n]),
      }
      const res = (await session.run(feeds)) as Record<string, { data: ArrayLike<number>; dims: number[] }>
      const logits = res.logits ?? res['output_0']
      if (!logits) throw new KbError(ErrorCodes.IDX_NOT_READY, `重排序模型输出名未知: ${Object.keys(res).join(',')}`, '检查模型版本或改用 RRF-only')
      const logit = logits.data[0] as number
      const score = 1 / (1 + Math.exp(-logit)) // sigmoid → [0,1]
      out.push({ chunk_id: c.chunk_id, score })
    }
    out.sort((a, b) => b.score - a.score)
    return out.slice(0, topN)
  }
}
