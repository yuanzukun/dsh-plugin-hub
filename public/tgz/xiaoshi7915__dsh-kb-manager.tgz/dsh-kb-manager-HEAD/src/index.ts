/**
 * KbManager：顶层装配（DESIGN §3/§7）。
 * 组合 config / stores / jobs / 五个 service，暴露给 agent-tools 与 Web RPC。
 */
import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { homedir } from 'node:os'
import type { DeepPartial, EmbeddingIdentity, Envelope, Job, KbConfig, KbStatus } from './contracts/types.ts'
import { DEFAULT_CONFIG } from './contracts/types.ts'
import { KbError, ErrorCodes, ConfirmTokens, ok, err } from './contracts/errors.ts'
import { type KbStore, readMeta, writeMeta } from './store/store.ts'
import { JobQueue, type JobWork } from './jobs/queue.ts'
import { KbService } from './services/kb-service.ts'
import { DocService } from './services/doc-service.ts'
import { SearchService } from './services/search-service.ts'
import { SnapshotService } from './services/snapshot-service.ts'
import { ExportService } from './services/export-service.ts'
import { NoopReranker, type Reranker } from './index/rerank.ts'
import { OnnxReranker } from './rerank/onnx-reranker.ts'
import { embedderFactory, type Embedder } from './embedder/index.ts'
import type { JobType } from './contracts/types.ts'

export class KbManager {
  readonly root: string
  cfg: KbConfig
  readonly kbs: KbService
  readonly docs: DocService
  readonly search: SearchService
  readonly snapshots: SnapshotService
  readonly exports: ExportService
  readonly jobs: JobQueue
  readonly confirms = new ConfirmTokens()
  workspace?: string
  private embedderPromise: Promise<Embedder> | null = null
  readonly stores = new Map<string, KbStore>()

  storesAll(): KbStore[] {
    return [...this.stores.values()]
  }

  constructor(root?: string, config?: DeepPartial<KbConfig> & { onJobEvent?: (job: Job) => void; workspace?: string }) {
    const { onJobEvent, workspace, ...cfgOverride } = config ?? {}
    this.root = root ?? (cfgOverride.storage_path || join(homedir(), '.dsh', 'kb-manager'))
    this.cfg = { ...DEFAULT_CONFIG, ...cfgOverride, embedding: { ...DEFAULT_CONFIG.embedding, ...(cfgOverride.embedding ?? {}) } }
    mkdirSync(join(this.root, 'kbs'), { recursive: true })
    this.loadConfigFile()

    this.kbs = new KbService(this.root)
    this.kbs.setDefaultIdentity(identityFromCfg(this.cfg))
    this.workspace = workspace
    const self = this
    const getStore = (kbId: string): KbStore => {
      let s = self.stores.get(kbId)
      if (!s) {
        s = self.kbs.getStore(kbId)
        self.stores.set(kbId, s)
      }
      return s
    }
    const listStores = () => [...self.stores.values()]
    const getEmbedder = (): Promise<Embedder> => {
      if (!self.embedderPromise) self.embedderPromise = embedderFactory(self.cfg, self.root)
      return self.embedderPromise
    }
    // reranker：ONNX（懒加载；模型缺失/不可用 → available()=false → applyRerank 显式降级 fallback_rrf）
    let reranker: Reranker | null = null
    const getReranker = (): Reranker => {
      if (!reranker) reranker = new OnnxReranker(`${self.root}/models/rerank`, self.cfg.rerank_model)
      return reranker
    }
    this.docs = new DocService(this.kbs, getEmbedder, () => this.cfg, workspace)
    this.search = new SearchService(this.kbs, getEmbedder, () => this.cfg, getReranker)
    // B11：job 生命周期 → meta.status 四态（empty→building→ready|error；cancelled 回退 prior）
    const writeTypes = new Set<JobType>(['import', 'import_kb', 'rebuild', 'reindex', 'restore', 'compact'])
    const buildingPrior = new Map<string, KbStatus>()
    const syncKbStatus = (job: Job): void => {
      try {
        const store = self.kbs.getStore(job.kb_id)
        const meta = readMeta(store)
        if (!meta) return
        if (job.status === 'running') {
          if (writeTypes.has(job.type) && meta.status !== 'building') {
            buildingPrior.set(job.kb_id, meta.status)
            meta.status = 'building'
            meta.updated_at = new Date().toISOString()
            writeMeta(store, meta)
          }
        } else if (job.status === 'done' || job.status === 'failed' || job.status === 'cancelled') {
          if (meta.status === 'building' || buildingPrior.has(job.kb_id)) {
            if (job.status === 'done') meta.status = 'ready'
            else if (job.status === 'failed') meta.status = 'error'
            else meta.status = buildingPrior.get(job.kb_id) ?? meta.status
            buildingPrior.delete(job.kb_id)
            meta.updated_at = new Date().toISOString()
            writeMeta(store, meta)
          }
        }
      } catch { /* kb 可能已删除（delete_kb），忽略 */ }
    }
    const jobEvent = (job: Job): void => {
      syncKbStatus(job)
      onJobEvent?.(job)
    }
    this.jobs = new JobQueue({ getStore, listStores, onEvent: jobEvent, maxGlobal: 2 })
    this.snapshots = new SnapshotService(getStore, (kbId: string, work: JobWork) => self.jobs.enqueue(kbId, 'restore', work), this.confirms)
    this.exports = new ExportService(getStore)
    // B4：崩溃恢复（DESIGN §6.4）——启动时打开所有库（构建 jobIndex 内存索引），
    // 遗留 running/queued → JOB.INTERRUPTED（可安全重放）；此后 get_job 能查到旧任务。
    for (const id of this.kbs.kbIds()) {
      try { getStore(id) } catch { /* 损坏/不可打开的库跳过，启动不因此失败 */ }
    }
    this.jobs.recover()
  }

  /** 显式 kbId 的入队入口（export / import_kb / compact / rebuild 用；job 记在目标 KB 的 db 里） */
  enqueue(kbId: string, type: JobType, work: JobWork): Job {
    return this.jobs.enqueue(kbId, type, work)
  }

  // ---------- config ----------
  private loadConfigFile(): void {
    const p = join(this.root, 'config.json')
    if (existsSync(p)) {
      try {
        const saved = JSON.parse(readFileSync(p, 'utf8')) as Partial<KbConfig>
        this.cfg = { ...DEFAULT_CONFIG, ...saved, embedding: { ...DEFAULT_CONFIG.embedding, ...(saved.embedding ?? {}) } }
      } catch {
        /* 损坏配置：保留默认 */
      }
    }
  }

  saveConfig(): void {
    writeFileSync(join(this.root, 'config.json'), JSON.stringify(this.cfg, null, 2))
  }

  /** configure 白名单应用（DESIGN §8.5）：仅 12 项用户配置；storage_path 重启生效 */
  applyConfigPatch(patch: Record<string, unknown>): { updated: string[]; restart_required: string[] } {
    const updated: string[] = []
    const restart: string[] = []
    for (const [key, value] of Object.entries(patch)) {
      if (!CONFIG_WHITELIST_KEYS.has(key)) {
        throw new KbError(ErrorCodes.CFG_KEY_INVALID, `配置键不可经 configure 修改: ${key}`, '安全类配置（import_allowed_dirs 等）请在 Web 配置页管理')
      }
      const parts = key.split('.')
      let target: Record<string, unknown> = this.cfg as unknown as Record<string, unknown>
      for (let i = 0; i < parts.length - 1; i++) target = target[parts[i]!] as Record<string, unknown>
      target[parts[parts.length - 1]!] = value
      updated.push(key)
      if (key === 'storage_path') restart.push(key)
    }
    // B7：embedding.* 变更使 embedder 缓存失效——否则 configure 声称热生效实际仍用旧 embedder
    // （已建库绑定旧身份，由 assertSameIdentity 保护；新库/rebuild 用新配置）
    if (Object.keys(patch).some((k) => k.startsWith('embedding.'))) {
      this.embedderPromise = null
      // 同时更新默认身份：否则新库仍按旧身份建，导入时与新 embedder 不一致直接报错
      this.kbs.setDefaultIdentity(identityFromCfg(this.cfg))
    }
    this.saveConfig()
    return { updated, restart_required: restart }
  }

  issueConfirm(scope: string): string {
    return this.confirms.issue(scope)
  }
  consumeConfirm(token: string, scope: string): boolean {
    return this.confirms.consume(token, scope)
  }

  close(): void {
    this.stores.clear()
    this.kbs.dispose()
  }
}

const EMBED_SUBKEYS = [
  'embedding.model', 'embedding.provider', 'embedding.base_url', 'embedding.api_key_ref', 'embedding.instruction',
]
const CONFIG_WHITELIST_KEYS = new Set([
  'storage_path',
  ...EMBED_SUBKEYS,
  'chunk_size', 'chunk_overlap', 'chunk_strategy', 'top_k',
  'enable_rerank', 'rerank_model', 'auto_sync_dir', 'auto_sync_interval', 'max_file_size_mb',
])

/** 由当前配置推导默认 embedding 身份（建库时未显式指定则用）。
 *  MVP：onnx(bge-small-zh)/mock 固定 512；外部模型若维度不同，首次检索身份校验会报 EMB.DIMENSION_MISMATCH。 */
export function identityFromCfg(cfg: KbConfig): EmbeddingIdentity {
  const provider = cfg.embedding.provider
  const model = cfg.embedding.model || (provider === 'onnx' ? 'bge-small-zh-v1.5' : provider)
  return { model, provider, dim: 512 }
}


/** 统一执行包装：任何异常 → 错误信封（DESIGN §7.1） */
export function runTool<T>(fn: () => T | Promise<T>): Promise<Envelope<T>> {
  return Promise.resolve()
    .then(fn)
    .then((data) => ok(data))
    .catch((e: unknown) => err(e))
}
