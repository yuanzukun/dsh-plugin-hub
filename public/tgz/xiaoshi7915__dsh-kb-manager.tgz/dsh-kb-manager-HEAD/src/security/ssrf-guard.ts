/**
 * SSRF guard（DESIGN §8.2）：
 * - 仅 http/https
 * - DNS 解析后所有地址必须不是私网/环回/link-local/保留段
 * - 逐跳重定向重新校验
 */
import { lookup } from 'node:dns/promises'
import { isIP } from 'node:net'
import { KbError, ErrorCodes } from '../contracts/errors.ts'

const PRIVATE_V4: Array<[number, number, number, number]> = [
  // 起始八位组, 掩码位数, 起始位段, 备注
]

function ipToLong(ip: string): number {
  const parts = ip.split('.').map(Number)
  if (parts.length !== 4 || parts.some((n) => Number.isNaN(n) || n < 0 || n > 255)) return -1
  return ((parts[0]! << 24) | (parts[1]! << 16) | (parts[2]! << 8) | parts[3]!) >>> 0
}

/** 判断 IPv4 是否私网/环回/保留。覆盖设计列出的段 + 常见补充。 */
export function isPrivateIPv4(ip: string): boolean {
  const n = ipToLong(ip)
  if (n < 0) return true
  const inRange = (start: number, prefix: number) =>
    (n & (0xffffffff << (32 - prefix)) >>> 0) === (start & (0xffffffff << (32 - prefix)) >>> 0)
  return (
    inRange(0x7f000000, 8) || // 127/8 loopback
    inRange(0x0a000000, 8) || // 10/8
    inRange(0xac100000, 12) || // 172.16/12
    inRange(0xc0a80000, 16) || // 192.168/16
    inRange(0xa9fe0000, 16) || // 169.254/16 link-local + cloud metadata
    inRange(0x00000000, 8) || // 0/8
    inRange(0x64400000, 10) || // 100.64/10 CGNAT
    inRange(0xfc000000, 7) // 224/3 multicast + 240/5 reserved (superset check)
  )
}

function isPrivateIPv6(ip: string): boolean {
  const v6 = ip.toLowerCase()
  if (v6 === '::1' || v6 === '::') return true
  if (v6.startsWith('fc') || v6.startsWith('fd')) return true // fc00::/7 unique-local
  if (v6.startsWith('fe80')) return true // link-local
  // IPv4-mapped ::ffff:a.b.c.d
  const m = v6.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/)
  if (m) return isPrivateIPv4(m[1]!)
  return false
}

export function isPrivateIp(ip: string): boolean {
  const v = isIP(ip)
  return v === 4 ? isPrivateIPv4(ip) : v === 6 ? isPrivateIPv6(ip) : true
}

export interface SsrfOptions {
  allowlist?: string[] // 域名白名单；非空时 hostname 必须匹配（精确或子域）
  maxRedirects?: number
}

function hostInAllowlist(hostname: string, allowlist: string[]): boolean {
  const h = hostname.toLowerCase()
  return allowlist.some((a) => {
    const t = a.toLowerCase()
    return h === t || h.endsWith('.' + t)
  })
}

/** 解析主机名的所有 IP 并逐一校验。 */
export async function assertHostSafe(hostname: string, allowlist?: string[]): Promise<void> {
  if (allowlist && allowlist.length > 0 && !hostInAllowlist(hostname, allowlist)) {
    throw new KbError(
      ErrorCodes.SEC_URL_DENIED,
      `Host "${hostname}" is not in import_url_allowlist`,
      '该域名不在白名单中。请在配置页将域名加入 import_url_allowlist 后重试。',
    )
  }
  let addrs: string[]
  if (isIP(hostname)) {
    addrs = [hostname]
  } else {
    try {
      const res = await lookup(hostname, { all: true, verbatim: true })
      addrs = res.map((r) => r.address)
    } catch (e) {
      throw new KbError(ErrorCodes.SEC_URL_DENIED, `Cannot resolve host "${hostname}"`, (e as Error).message)
    }
  }
  for (const ip of addrs) {
    if (isPrivateIp(ip)) {
      throw new KbError(
        ErrorCodes.SEC_URL_DENIED,
        `Host "${hostname}" resolves to a private/reserved address (${ip})`,
        'URL 指向内网/保留地址，已被 SSRF 防护拦截。',
      )
    }
  }
}

/**
 * 安全 fetch：协议限制 + 首跳与每次重定向逐跳校验。
 * 返回最终 Response（调用方负责读取 body）。
 */
export async function safeFetch(url: string, opts: SsrfOptions & { timeoutMs?: number } = {}): Promise<Response> {
  const maxRedirects = opts.maxRedirects ?? 5
  let current = new URL(url)
  for (let hop = 0; ; hop++) {
    if (current.protocol !== 'http:' && current.protocol !== 'https:') {
      throw new KbError(ErrorCodes.SEC_URL_DENIED, `Only http/https URLs are allowed, got: ${current.protocol}`)
    }
    await assertHostSafe(current.hostname, opts.allowlist)
    const ctrl = new AbortController()
    const timer = opts.timeoutMs ? setTimeout(() => ctrl.abort(), opts.timeoutMs) : undefined
    try {
      const res = await fetch(current.toString(), { redirect: 'manual', signal: ctrl.signal })
      const status = res.status
      if (status >= 300 && status < 400 && hop < maxRedirects) {
        const loc = res.headers.get('location')
        if (!loc) throw new KbError(ErrorCodes.SEC_URL_DENIED, 'Redirect without Location header')
        current = new URL(loc, current)
        continue
      }
      return res
    } catch (e) {
      if (e instanceof KbError) throw e
      throw new KbError(
        ErrorCodes.EMB_MODEL_UNREACHABLE,
        `Fetch failed for ${current.host}: ${(e as Error).message}`,
        '目标站点不可达；请检查网络或将 URL 改为白名单内目标。',
      )
    } finally {
      if (timer) clearTimeout(timer)
    }
  }
}
