/**
 * 审计日志（DESIGN §8.6）：写入 kv.audit，环形保留最近 1000 条。
 */
import type Database from 'better-sqlite3'

type Db = Database.Database

const AUDIT_KEY = 'audit_log'
const MAX_ENTRIES = 1000

export interface AuditEntry {
  at: string
  actor: string
  action: string
  target: string
  detail?: string
  ok: boolean
}

export function audit(db: Db, entry: Omit<AuditEntry, 'at'> & { at?: string }): void {
  const raw = db.prepare('SELECT value FROM kv WHERE key = ?').get(AUDIT_KEY) as { value: string } | undefined
  const log: AuditEntry[] = raw ? JSON.parse(raw.value) : []
  log.push({ at: new Date().toISOString(), ...entry })
  while (log.length > MAX_ENTRIES) log.shift()
  db.prepare('INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)').run(AUDIT_KEY, JSON.stringify(log))
}

export function recentAudits(db: Db, limit = 100): AuditEntry[] {
  const raw = db.prepare('SELECT value FROM kv WHERE key = ?').get(AUDIT_KEY) as { value: string } | undefined
  if (!raw) return []
  return (JSON.parse(raw.value) as AuditEntry[]).slice(-limit)
}
