/**
 * 路径白名单守卫（DESIGN §8.1）：
 * - 所有导入/导出路径 realpath 后必须落在 import_allowed_dirs 之内
 * - 符号链接逃逸、.. 穿越一律拒绝
 */
import { realpathSync, existsSync, statSync } from 'node:fs'
import { resolve, isAbsolute, relative, sep } from 'node:path'
import { KbError, ErrorCodes } from '../contracts/errors.ts'

/** 解析并校验绝对路径在 allowedDirs 内；返回 realpath。 */
export function assertPathAllowed(rawPath: string, allowedDirs: string[], label = 'path'): string {
  if (!rawPath || typeof rawPath !== 'string' || !isAbsolute(rawPath)) {
    throw new KbError(
      ErrorCodes.SEC_PATH_DENIED,
      `${label} must be an absolute path inside an allowed directory`,
      `当前允许的目录: ${allowedDirs.join(', ') || '(无)'}。请将文件放到白名单目录内后重试。`,
    )
  }
  if (allowedDirs.length === 0) {
    throw new KbError(
      ErrorCodes.SEC_PATH_DENIED,
      'No import/export directories are configured',
      '在配置页或 configure 无法设置 import_allowed_dirs（宿主侧键）；请手动将文件放入默认白名单目录。',
    )
  }
  const p = resolve(rawPath)
  const real = existsSync(p) ? realpathSync(p) : p
  const allowed = allowedDirs.map((d) => (existsSync(d) ? realpathSync(d) : resolve(d)))
  for (const dir of allowed) {
    // B14：Windows realpath 返回反斜杠，不能直接 startsWith(dir + '/')；
    // 用 path.relative 比较（正确处理分隔符与大小写），且防 ../ 与绝对路径逃逸
    const rel = relative(dir, real)
    if (rel === '' || (!(rel === '..' || rel.startsWith('..' + sep)) && !isAbsolute(rel))) return real
  }
  throw new KbError(
    ErrorCodes.SEC_PATH_DENIED,
    `${label} "${rawPath}" is outside the allowed directories`,
    `仅允许访问: ${allowed.join(', ')}`,
  )
}

/** 校验文件存在且大小在限内（DESIGN: max_file_size_mb 硬上限） */
export function assertFileWithinLimit(realPath: string, maxFileBytes: number, label = 'file'): void {
  if (!existsSync(realPath)) {
    throw new KbError(ErrorCodes.DOC_NOT_FOUND, `${label} does not exist: ${realPath}`)
  }
  const st = statSync(realPath)
  if (st.size > maxFileBytes) {
    throw new KbError(
      ErrorCodes.DOC_TOO_LARGE,
      `${label} is ${(st.size / 1024 / 1024).toFixed(1)}MB, exceeding the ${maxFileBytes / 1024 / 1024}MB limit`,
      '拆分为多个小于限制的文档分别导入，或调整 max_file_size_mb（宿主侧配置）。',
    )
  }
}
