/**
 * dsh-kb-manager client Remote 贡献（TYPERT_REMOTE）。
 *
 * web 半在 apply 中执行 `await ctx.remote.$mount(TYPERT_REMOTE)`：
 * client gateway 用 requireStrictDescriptor 校验每个描述符（strict codec +
 * zod v4 schema），随后安装 `remote.kbManager` 命名空间服务，组件经
 * `ctx.get('remote.kbManager')` 取到方法句柄。
 *
 * 描述符与 host 清单（src/typert.ts）同源（src/remote.ts KB_INVOCATIONS），
 * 两端 wire 契约零漂移。
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol'
import { KB_INVOCATIONS, KB_PACKAGE } from './remote.ts'

export const TYPERT_REMOTE: TypertRemoteContribution = {
  package: KB_PACKAGE,
  descriptors: KB_INVOCATIONS,
}

export default TYPERT_REMOTE
