/**
 * dsh-kb-manager Remote wire 契约（host/client 单一事实源）。
 *
 * 两个产物都从本文件派生，保证 host/client 描述符零漂移：
 * - host:   src/typert.ts       → TYPERT（@deepseek-ai/dsh-typert-loader 校验、
 *                                 dsh-host-apiproxy Typert Gateway 分发）
 * - client: src/remote-client.ts → TYPERT_REMOTE（web 半经 ctx.remote.$mount 挂载）
 *
 * 浏览器安全约束：本文件只允许 zod 值导入 + 纯数据，
 * 不得 import node 内建或 KbManager 实现（会被打进 client bundle）。
 */
import { z } from 'zod'
import type { InvocationDescriptor } from '@deepseek-ai/dsh-typert-protocol'

export const KB_PACKAGE = 'dsh-kb-manager'
export const KB_NAMESPACE = 'kbManager'

const sym = (method: string, wire: string): string =>
  `${KB_PACKAGE}#${KB_NAMESPACE}/${method}:${wire}`

/** 必填字符串参数 */
const strParam = (method: string, wire: string): InvocationDescriptor['parameters'][number] => ({
  name: wire,
  wire,
  source: 'json',
  codec: { mode: 'strict', typeSymbol: sym(method, wire), schema: z.string().min(1) },
})

/** 可省略字符串参数（acceptsUndefined：wire 缺省 → host 收到 undefined） */
const strParamOpt = (method: string, wire: string): InvocationDescriptor['parameters'][number] => ({
  name: wire,
  wire,
  source: 'json',
  acceptsUndefined: true,
  codec: { mode: 'strict', typeSymbol: sym(method, wire), schema: z.string().min(1).optional() },
})

/** 可省略整数参数 */
const intParamOpt = (
  method: string,
  wire: string,
  schema: z.ZodType,
): InvocationDescriptor['parameters'][number] => ({
  name: wire,
  wire,
  source: 'json',
  acceptsUndefined: true,
  codec: { mode: 'strict', typeSymbol: sym(method, wire), schema },
})

/** 可省略字符串数组参数 */
const strArrParamOpt = (method: string, wire: string): InvocationDescriptor['parameters'][number] => ({
  name: wire,
  wire,
  source: 'json',
  acceptsUndefined: true,
  codec: { mode: 'strict', typeSymbol: sym(method, wire), schema: z.array(z.string()).optional() },
})

/** 可省略 JSON object 参数（配置补丁 / 文档元数据） */
const objParamOpt = (method: string, wire: string): InvocationDescriptor['parameters'][number] => ({
  name: wire,
  wire,
  source: 'json',
  acceptsUndefined: true,
  codec: { mode: 'strict', typeSymbol: sym(method, wire), schema: z.record(z.string(), z.unknown()).optional() },
})

/** 可省略枚举字符串参数 */
const enumParamOpt = (method: string, wire: string, values: string[]): InvocationDescriptor['parameters'][number] => ({
  name: wire,
  wire,
  source: 'json',
  acceptsUndefined: true,
  codec: { mode: 'strict', typeSymbol: sym(method, wire), schema: z.enum(values as [string, ...string[]]).optional() },
})

/** 可省略布尔参数 */
const boolParamOpt = (method: string, wire: string): InvocationDescriptor['parameters'][number] => ({
  name: wire,
  wire,
  source: 'json',
  acceptsUndefined: true,
  codec: { mode: 'strict', typeSymbol: sym(method, wire), schema: z.boolean().optional() },
})

const objParam = (method: string, wire: string): InvocationDescriptor['parameters'][number] => ({
  name: wire,
  wire,
  source: 'json',
  codec: { mode: 'strict', typeSymbol: sym(method, wire), schema: z.record(z.string(), z.unknown()) },
})

/**
 * 结果统一用 z.unknown() 宽松 strict codec：
 * 业务负载是 runTool 信封（{ok,data} | {ok:false,error}），
 * 形状由 src/remote-types.ts 的 TS 接口约束，wire 侧不二次裁剪。
 */
const resultCodec = (method: string) => ({
  mode: 'strict' as const,
  typeSymbol: sym(method, 'result'),
  schema: z.unknown() as z.ZodType,
})

const inv = (method: string, parameters: InvocationDescriptor['parameters']): InvocationDescriptor => ({
  id: `${KB_PACKAGE}#${KB_NAMESPACE}/${method}`,
  service: KB_NAMESPACE,
  namespace: KB_NAMESPACE,
  method,
  invocation: { kind: 'direct' },
  parameters,
  result: resultCodec(method),
})

/**
 * 21 个 wire 方法（与 agent 工具同名映射，见 src/agent-tools/tools.ts）：
 * list / detail / stats / docs / search / create / importDoc / job / cancelJob /
 * deleteKb / deleteDoc / rebuild / configure
 * + v1.1：renameKb / multiKbSearch / createSnapshot / listSnapshots / restoreSnapshot /
 *   exportKb / importKb / compactIndex
 */
export const KB_INVOCATIONS: InvocationDescriptor[] = [
  // ---------- KB 管理（同步） ----------
  inv('list', [
    strParamOpt('list', 'domain_tag'),
    intParamOpt('list', 'limit', z.number().int().min(1).max(500).optional()),
    intParamOpt('list', 'offset', z.number().int().min(0).optional()),
  ]),
  inv('detail', [strParam('detail', 'kb_id')]),
  inv('stats', [strParam('stats', 'kb_id')]),
  inv('renameKb', [
    strParam('renameKb', 'kb_id'),
    strParam('renameKb', 'name'),
  ]),
  inv('docs', [
    strParam('docs', 'kb_id'),
    strParamOpt('docs', 'status'),
    intParamOpt('docs', 'limit', z.number().int().min(1).max(200).optional()),
    intParamOpt('docs', 'offset', z.number().int().min(0).optional()),
  ]),
  inv('listDocChunks', [
    strParam('listDocChunks', 'kb_id'),
    strParam('listDocChunks', 'doc_id'),
  ]),
  inv('search', [
    strParam('search', 'kb_id'),
    strParam('search', 'query'),
    intParamOpt('search', 'top_k', z.number().int().min(1).max(50).optional()),
  ]),
  inv('multiKbSearch', [
    strArrParamOpt('multiKbSearch', 'kb_ids'),
    strParam('multiKbSearch', 'query'),
    intParamOpt('multiKbSearch', 'top_k', z.number().int().min(1).max(50).optional()),
  ]),
  inv('create', [
    strParam('create', 'name'),
    strParamOpt('create', 'description'),
    strArrParamOpt('create', 'domain_tags'),
  ]),
  // ---------- 快照 ----------
  inv('createSnapshot', [
    strParam('createSnapshot', 'kb_id'),
    strParamOpt('createSnapshot', 'note'),
  ]),
  inv('listSnapshots', [
    strParam('listSnapshots', 'kb_id'),
    intParamOpt('listSnapshots', 'limit', z.number().int().min(1).max(200).optional()),
    intParamOpt('listSnapshots', 'offset', z.number().int().min(0).optional()),
  ]),
  inv('restoreSnapshot', [
    strParam('restoreSnapshot', 'kb_id'),
    strParam('restoreSnapshot', 'snapshot_id'),
    strParamOpt('restoreSnapshot', 'confirm_token'),
  ]),
  // ---------- 文档（导入异步） ----------
  inv('importDoc', [
    strParam('importDoc', 'kb_id'),
    strParam('importDoc', 'source'),
    objParamOpt('importDoc', 'metadata'),
  ]),
  // 浏览器文件上传导入：Web 面板经 input[type=file] 读文本 → 传内容到宿主导入
  inv('importText', [
    strParam('importText', 'kb_id'),
    strParam('importText', 'file_name'),
    strParam('importText', 'source_type'),
    strParam('importText', 'text'),
    strParamOpt('importText', 'source_key'),
    objParamOpt('importText', 'metadata'),
  ]),
  inv('deleteDoc', [
    strParam('deleteDoc', 'kb_id'),
    strParam('deleteDoc', 'doc_id'),
  ]),
  // ---------- 任务 ----------
  inv('job', [strParam('job', 'job_id')]),
  inv('cancelJob', [strParam('cancelJob', 'job_id')]),
  // ---------- 维护（删除两步确认 / 重建异步 / 配置热更） ----------
  inv('deleteKb', [
    strParam('deleteKb', 'kb_id'),
    strParamOpt('deleteKb', 'confirm_token'),
  ]),
  inv('rebuild', [
    strParam('rebuild', 'kb_id'),
    strParamOpt('rebuild', 'target_engine'),
  ]),
  inv('compactIndex', [strParam('compactIndex', 'kb_id')]),
  // ---------- 迁移（导出异步 / 导入异步） ----------
  inv('exportKb', [
    strParam('exportKb', 'kb_id'),
    enumParamOpt('exportKb', 'format', ['kbpack', 'json']),
    strParamOpt('exportKb', 'output_path'),
    boolParamOpt('exportKb', 'include_index'),
  ]),
  inv('importKb', [
    strParam('importKb', 'file_path'),
    enumParamOpt('importKb', 'merge_strategy', ['create_new', 'merge']),
    strParamOpt('importKb', 'kb_id'),
  ]),
  inv('configure', [objParam('configure', 'patch')]),
]
