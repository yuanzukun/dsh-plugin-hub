/**
 * kb.db 存储层（DESIGN §4）。每 KB 一个 SQLite 库：
 * documents / chunks / chunks_fts / vec_chunks / snapshots / jobs / kv。
 * 原子性 = 单库单事务；快照 = online backup 副本 + manifest（§4.3）。
 */
import Database from 'better-sqlite3'
import { load as loadSqliteVec } from 'sqlite-vec'
import { mkdirSync, writeFileSync, readFileSync, existsSync, copyFileSync, renameSync, statSync, rmSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import type { Job, KbMeta } from '../contracts/types.ts'

export const KB_SCHEMA_VERSION = 1

const MIGRATIONS: Record<number, (db: Database.Database) => void> = {
  1(db) {
    db.exec(`
      CREATE TABLE IF NOT EXISTS documents(
        doc_id TEXT PRIMARY KEY, file_name TEXT NOT NULL,
        source_type TEXT NOT NULL, source_key TEXT NOT NULL,
        content_hash TEXT NOT NULL, status TEXT NOT NULL,
        chunk_count INTEGER NOT NULL DEFAULT 0, size_bytes INTEGER NOT NULL DEFAULT 0,
        metadata_json TEXT NOT NULL DEFAULT '{}',
        imported_at TEXT NOT NULL, updated_at TEXT NOT NULL,
        UNIQUE(source_key)
      );
      CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);

      CREATE TABLE IF NOT EXISTS chunks(
        chunk_id TEXT PRIMARY KEY, doc_id TEXT NOT NULL REFERENCES documents(doc_id),
        ord INTEGER NOT NULL, text TEXT NOT NULL, bm25_text TEXT NOT NULL,
        deleted INTEGER NOT NULL DEFAULT 0,
        heading_path TEXT NOT NULL DEFAULT '', heading_level INTEGER,
        page_num INTEGER, char_start INTEGER, char_end INTEGER,
        token_count INTEGER NOT NULL, table_detected INTEGER NOT NULL DEFAULT 0,
        metadata_json TEXT NOT NULL DEFAULT '{}'
      );
      CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(doc_id);
      CREATE INDEX IF NOT EXISTS idx_chunks_deleted ON chunks(deleted);

      CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
        bm25_text, content=chunks, content_rowid=rowid, tokenize='unicode61'
      );

      CREATE VIRTUAL TABLE IF NOT EXISTS vec_chunks USING vec0(
        chunk_id TEXT PRIMARY KEY, embedding float[512]
      );

      CREATE TABLE IF NOT EXISTS snapshots(
        snapshot_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, note TEXT,
        doc_count INTEGER NOT NULL, chunk_count INTEGER NOT NULL,
        size_bytes INTEGER NOT NULL, manifest_json TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS jobs(
        job_id TEXT PRIMARY KEY, kb_id TEXT NOT NULL, type TEXT NOT NULL, status TEXT NOT NULL,
        progress_json TEXT NOT NULL, result_json TEXT, error_json TEXT,
        created_at TEXT NOT NULL, started_at TEXT, finished_at TEXT
      );

      CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    `)
    // FTS5 external-content 触发器（保证 chunks 增删改同步 FTS 索引）
    db.exec(`
      CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
        INSERT INTO chunks_fts(rowid, bm25_text) VALUES (new.rowid, new.bm25_text);
      END;
      CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
        INSERT INTO chunks_fts(chunks_fts, rowid, bm25_text) VALUES('delete', old.rowid, old.bm25_text);
      END;
      CREATE TRIGGER IF NOT EXISTS chunks_au AFTER UPDATE OF bm25_text ON chunks BEGIN
        INSERT INTO chunks_fts(chunks_fts, rowid, bm25_text) VALUES('delete', old.rowid, old.bm25_text);
        INSERT INTO chunks_fts(rowid, bm25_text) VALUES (new.rowid, new.bm25_text);
      END;
    `)
  },
}

export interface KbStore {
  db: Database.Database
  kbDir: string
  metaPath: string
  close(): void
}

/** 打开（或创建）一个 KB 库；加载 sqlite-vec 扩展并迁移到当前 schema。 */
export function openKbStore(kbDir: string): KbStore {
  mkdirSync(join(kbDir, 'documents'), { recursive: true })
  mkdirSync(join(kbDir, 'snapshots'), { recursive: true })
  const db = new Database(join(kbDir, 'kb.db'))
  db.pragma('journal_mode = WAL')
  db.pragma('synchronous = NORMAL')
  db.pragma('foreign_keys = ON')
  if (existsSync(join(kbDir, 'kb.db'))) loadSqliteVec(db) // 扩展须在库就绪后加载
  const version = db.pragma('user_version', { simple: true }) as number
  for (let v = version + 1; v <= KB_SCHEMA_VERSION; v++) {
    MIGRATIONS[v]?.(db)
    db.pragma(`user_version = ${v}`)
  }
  return { db, kbDir, metaPath: join(kbDir, 'meta.json'), close: () => db.close() }
}

/** 事务封装：fn 抛错即整体回滚（§4.3 原子性根因） */
export function tx<T>(store: KbStore, fn: (db: Database.Database) => T): T {
  return store.db.transaction(() => fn(store.db))()
}

// ---------- meta.json ----------

export function readMeta(store: KbStore): KbMeta | null {
  if (!existsSync(store.metaPath)) return null
  return JSON.parse(readFileSync(store.metaPath, 'utf8')) as KbMeta
}

export function writeMeta(store: KbStore, meta: KbMeta): void {
  writeFileSync(store.metaPath, JSON.stringify(meta, null, 2))
}

// ---------- 快照（§4.3：online backup 单文件一致副本 + manifest） ----------

export async function createSnapshot(store: KbStore, snapshotId: string, note?: string): Promise<{ snapshot_id: string; created_at: string; size_bytes: number; doc_count: number }> {
  const dir = join(store.kbDir, 'snapshots', snapshotId)
  mkdirSync(dir, { recursive: true })
  const backupPath = join(dir, 'kb.db')
  await store.db.backup(backupPath) // SQLite online backup：一致性快照，不锁写
  const docCount = (store.db.prepare("SELECT COUNT(*) c FROM documents WHERE status NOT IN ('deleted')").get() as { c: number }).c
  const chunkCount = (store.db.prepare("SELECT COUNT(*) c FROM chunks WHERE deleted = 0").get() as { c: number }).c
  const meta = readMeta(store)!
  const manifest = {
    snapshot_id: snapshotId,
    created_at: new Date().toISOString(),
    note,
    schema_version: meta.schema_version,
    embedding: meta.embedding,
    backend: meta.backend,
    doc_count: docCount,
    chunk_count: chunkCount,
  }
  const manifestPath = join(dir, 'manifest.json')
  writeFileSync(manifestPath, JSON.stringify(manifest, null, 2))
  store.db.prepare(
    'INSERT INTO snapshots (snapshot_id, created_at, note, doc_count, chunk_count, size_bytes, manifest_json) VALUES (?,?,?,?,?,?,?)',
  ).run(snapshotId, manifest.created_at, note ?? null, docCount, chunkCount, statSync(backupPath).size, JSON.stringify(manifest))
  enforceSnapshotLru(store, 20)
  return { snapshot_id: snapshotId, created_at: manifest.created_at, size_bytes: statSync(backupPath).size, doc_count: docCount }
}

export function listSnapshots(store: KbStore, limit = 20, offset = 0): Array<{ snapshot_id: string; created_at: string; note: string | null; doc_count: number; size_bytes: number }> {
  return store.db.prepare('SELECT snapshot_id, created_at, note, doc_count, size_bytes FROM snapshots ORDER BY created_at DESC LIMIT ? OFFSET ?').all(limit, offset) as Array<{ snapshot_id: string; created_at: string; note: string | null; doc_count: number; size_bytes: number }>
}

export function readSnapshotManifest(store: KbStore, snapshotId: string): Record<string, unknown> | null {
  const row = store.db.prepare('SELECT manifest_json FROM snapshots WHERE snapshot_id = ?').get(snapshotId) as { manifest_json: string } | undefined
  return row ? (JSON.parse(row.manifest_json) as Record<string, unknown>) : null
}

/** 恢复：替换 kb.db（调用方须先自动备份当前状态，见 doc-service） */
export function restoreSnapshotDb(store: KbStore, snapshotId: string): void {
  const src = join(store.kbDir, 'snapshots', snapshotId, 'kb.db')
  if (!existsSync(src)) throw new Error(`snapshot db missing: ${snapshotId}`)
  store.db.close()
  for (const f of ['kb.db', 'kb.db-wal', 'kb.db-shm']) {
    const p = join(store.kbDir, f)
    if (existsSync(p)) rmSync(p)
  }
  copyFileSync(src, join(store.kbDir, 'kb.db'))
  // 重新打开（扩展与迁移幂等）
  const reopened = openKbStore(store.kbDir)
  store.db = reopened.db
  store.close = reopened.close
}

function enforceSnapshotLru(store: KbStore, max: number): void {
  const rows = store.db.prepare('SELECT snapshot_id FROM snapshots ORDER BY created_at DESC').all() as Array<{ snapshot_id: string }>
  for (const r of rows.slice(max)) {
    store.db.prepare('DELETE FROM snapshots WHERE snapshot_id = ?').run(r.snapshot_id)
    rmSync(join(store.kbDir, 'snapshots', r.snapshot_id), { recursive: true, force: true })
  }
}

// ---------- jobs 持久化（§6.4 崩溃恢复） ----------

export function persistJob(store: KbStore, job: Job): void {
  store.db.prepare(
    `INSERT INTO jobs (job_id, type, status, progress_json, result_json, error_json, created_at, started_at, finished_at)
     VALUES (?,?,?,?,?,?,?,?,?)
     ON CONFLICT(job_id) DO UPDATE SET status=excluded.status, progress_json=excluded.progress_json,
       result_json=excluded.result_json, error_json=excluded.error_json,
       started_at=COALESCE(excluded.started_at, jobs.started_at), finished_at=excluded.finished_at`,
  ).run(
    job.job_id, job.type, job.status, JSON.stringify(job.progress),
    job.result === undefined ? null : JSON.stringify(job.result),
    job.error ? JSON.stringify(job.error) : null,
    job.created_at, job.started_at ?? null, job.finished_at ?? null,
  )
}

/** 进程重启后：遗留 running → failed(JOB.INTERRUPTED, retryable) */
export function recoverInterruptedJobs(store: KbStore): Job[] {
  const rows = store.db.prepare("SELECT * FROM jobs WHERE status IN ('queued','running')").all() as Array<Record<string, unknown>>
  const out: Job[] = []
  for (const r of rows) {
    const job = jobFromRow(r as never)
    job.status = 'failed'
    job.error = { code: 'JOB.INTERRUPTED', message: '进程重启时任务中断', hint: '该任务可安全重放（导入幂等/重建可重入）', }
    job.finished_at = new Date().toISOString()
    persistJob(store, job)
    out.push(job)
  }
  return out
}

function jobFromRow(r: { job_id: string; kb_id: string; type: string; status: string; progress_json: string; result_json: string | null; error_json: string | null; created_at: string; started_at: string | null; finished_at: string | null }): Job {
  return {
    job_id: r.job_id, kb_id: r.kb_id, type: r.type as Job['type'], status: r.status as Job['status'],
    progress: JSON.parse(r.progress_json),
    result: r.result_json ? JSON.parse(r.result_json) : undefined,
    error: r.error_json ? JSON.parse(r.error_json) : undefined,
    created_at: r.created_at,
    started_at: r.started_at ?? undefined,
    finished_at: r.finished_at ?? undefined,
  }
}
