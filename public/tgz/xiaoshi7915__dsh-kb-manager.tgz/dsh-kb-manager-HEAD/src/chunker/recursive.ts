/**
 * 分块核心（DESIGN §5.1）。
 * - recursive（默认）：block 优先；超预算块按分隔符层级 \n\n → \n → 。！？；!?; → 空格 拆分
 * - heading 感知：标题进入当前块首行，heading_path 栈随 level 维护
 * - 表格：≤ table_chunk_max_tokens 整表一块；超预算按行切 + 表头重复 + table_detected
 * - 贪心合并；仅当块因预算溢出被强制刷新时，尾部回卷 chunk_overlap 个 token 作下一块前缀
 */
import type { ChunkDraft, ChunkingParams, ParsedBlock, ParsedDoc } from '../contracts/types.ts'
import { countTokens, prefixWithinBudget } from './tokens.ts'

const SEPARATORS: RegExp[] = [/\n\n/, /\n/, /[。！？；!?;]/, / /]
/** 分隔符对应的连接字符（用于拆分后重新粘合） */
const GLUES: string[] = ['\n\n', '\n', '', ' ']

interface Unit {
  text: string
  isTable: boolean
  page_num: number | null
  heading_path: string
  heading_level: number | null
  /** 块起始时的文档字符偏移（近似，按单元顺序累计） */
  char_start: number
}

/** ParsedDoc blocks → 带 heading 上下文的单元序列（表格已按预算预切）。 */
export function blocksToUnits(doc: ParsedDoc, tableMax: number): Unit[] {
  const units: Unit[] = []
  const headingStack: Array<{ level: number; text: string }> = []
  let charOffset = 0
  const pathOf = (): string => headingStack.map((h) => h.text).join(' > ')

  for (const block of doc.blocks) {
    const here = charOffset
    charOffset += blockTextLen(block) + 1
    if (block.kind === 'heading') {
      while (headingStack.length > 0 && headingStack[headingStack.length - 1]!.level >= block.level) headingStack.pop()
      headingStack.push({ level: block.level, text: block.text })
      units.push({ text: block.text, isTable: false, page_num: block.page_num ?? null, heading_path: pathOf(), heading_level: block.level, char_start: here })
      continue
    }
    if (block.kind === 'table') {
      for (const part of chunkTable(block.markdown, tableMax)) {
        units.push({ text: part, isTable: true, page_num: block.page_num ?? null, heading_path: pathOf(), heading_level: null, char_start: here })
      }
      continue
    }
    for (const part of block.text.split(/\n\n+/).filter((x) => x.trim().length > 0)) {
      units.push({ text: part, isTable: false, page_num: block.page_num ?? null, heading_path: pathOf(), heading_level: null, char_start: here })
    }
  }
  return units
}

function blockTextLen(b: ParsedBlock): number {
  return b.kind === 'table' ? b.markdown.length : b.text.length
}

/** 表格单元：整表 ≤ 预算 → 单块；否则按行切 + 表头重复。 */
function chunkTable(markdown: string, tableMax: number): string[] {
  if (countTokens(markdown) <= tableMax) return [markdown]
  const lines = markdown.split('\n').filter((l) => l.trim().length > 0)
  if (lines.length <= 2) return [markdown] // 单行巨表：整块兜底
  const header = lines.slice(0, 2)
  const rows = lines.slice(2)
  const headerCost = countTokens(header.join('\n') + '\n')
  const out: string[] = []
  let bucket: string[] = []
  let cost = headerCost
  for (const row of rows) {
    const rc = countTokens(row) + 1
    if (cost + rc > tableMax && bucket.length > 0) {
      out.push([...header, ...bucket].join('\n'))
      bucket = []
      cost = headerCost
    }
    bucket.push(row)
    cost += rc
  }
  if (bucket.length > 0) out.push([...header, ...bucket].join('\n'))
  return out
}

/** 超预算文本按分隔符层级贪心拆分。 */
export function splitLongText(text: string, budget: number): string[] {
  if (countTokens(text) <= budget) return [text]
  for (let si = 0; si < SEPARATORS.length; si++) {
    const pieces = text.split(SEPARATORS[si]!)
    if (pieces.length <= 1) continue
    const glue = GLUES[si]!
    const out: string[] = []
    let cur = ''
    for (const piece of pieces) {
      const candidate = cur === '' ? piece : `${cur}${glue}${piece}`
      if (countTokens(candidate) > budget && cur !== '') {
        out.push(cur)
        cur = piece
      } else {
        cur = candidate
      }
    }
    if (cur.length > 0) out.push(cur)
    if (!out.some((p) => countTokens(p) > budget)) return out
  }
  // 无任何有效分隔符：硬切
  const out: string[] = []
  let rest = text
  while (countTokens(rest) > budget) {
    const cut = prefixWithinBudget(rest, budget)
    out.push(rest.slice(0, cut))
    rest = rest.slice(cut)
  }
  if (rest.length > 0) out.push(rest)
  return out
}

/** 取 text 尾部约 n 个 token 的原文（从词边界回卷）。 */
export function tailFromTokens(text: string, tokens: number): string {
  if (tokens <= 0 || text.length === 0) return ''
  let remaining = tokens
  let i = text.length
  while (i > 0 && remaining > 0) {
    const ch = text[i - 1]!
    if (/\s/.test(ch)) {
      i--
      continue
    }
    if (/[\u3000-\u303f\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uff00-\uffef]/.test(ch)) {
      remaining--
      i--
      continue
    }
    let j = i - 1
    while (j > 0 && /[A-Za-z0-9_]/.test(text[j]!)) j--
    remaining--
    i = j
  }
  while (i < text.length && /\s/.test(text[i]!)) i++
  return text.slice(i)
}

interface Buf {
  text: string
  meta: Unit
}

/** recursive 主流程：缓冲 + 边界刷新 + 溢出回卷。 */
export function chunkRecursive(doc: ParsedDoc, p: ChunkingParams): ChunkDraft[] {
  const units = blocksToUnits(doc, p.tableChunkMaxTokens)
  const drafts: ChunkDraft[] = []
  let buf: Buf | null = null
  let carry = '' // 上一块溢出回卷的前缀

  const flush = (forced: boolean) => {
    if (!buf || buf.text.trim().length === 0) {
      carry = ''
      buf = null
      return
    }
    const full = buf.meta.heading_path !== '' && buf.meta.heading_level === null
      ? `${buf.meta.heading_path}\n${buf.text}`
      : buf.text
    drafts.push({
      text: full,
      heading_path: buf.meta.heading_path,
      heading_level: buf.meta.heading_level,
      page_num: buf.meta.page_num,
      char_start: buf.meta.char_start,
      char_end: buf.meta.char_start + buf.text.length,
      token_count: countTokens(full),
      table_detected: buf.meta.isTable,
      metadata: buf.meta.isTable ? { table: true } : {},
    })
    carry = forced ? tailFromTokens(buf.text, p.chunkOverlap) : ''
    buf = null
  }

  for (const unit of units) {
    // 表格与标题单元独立成块（表格天然自洽；标题必须与下级内容分块以保持结构）
    if (unit.isTable || unit.heading_level !== null) {
      flush(false)
      buf = { text: unit.text, meta: unit }
      if (countTokens(buf.text) > p.chunkSize && !unit.isTable) {
        // 罕见：超长标题行
        buf.text = splitLongText(unit.text, p.chunkSize).join('\n')
      }
      continue
    }
    if (buf === null) {
      buf = { text: '', meta: unit }
    }
    let pieceBudget = p.chunkSize
    // 当前块已有标题上下文或 overlap 前缀时，相应扣减预算
    const reserved =
      countTokens(carry) +
      (buf.meta.heading_path !== '' && buf.meta.heading_level === null ? countTokens(`${buf.meta.heading_path}\n`) : 0)
    if (reserved > 0) pieceBudget = Math.max(32, p.chunkSize - reserved)

    const pieces = splitLongText(unit.text, pieceBudget)
    for (const piece of pieces) {
      const candidate = buf!.text === '' ? piece : `${buf!.text}\n\n${piece}`
      if (countTokens(candidate) <= p.chunkSize) {
        buf!.text = candidate
        continue
      }
      // 放不下：溢出刷新（带回卷），piece 开新块
      flush(true)
      buf = {
        text: carry + piece,
        meta: unit,
      }
      // carry+piece 仍可能超预算（carry 很大），继续拆
      while (countTokens(buf!.text) > p.chunkSize) {
        const cut = prefixWithinBudget(buf!.text, p.chunkSize)
        const emitted = buf!.text.slice(0, cut)
        drafts.push({
          text: emitted,
          heading_path: unit.heading_path,
          heading_level: null,
          page_num: unit.page_num,
          char_start: unit.char_start,
          char_end: unit.char_start + emitted.length,
          token_count: countTokens(emitted),
          table_detected: false,
          metadata: {},
        })
        const rest = buf!.text.slice(cut)
        carry = tailFromTokens(emitted, p.chunkOverlap)
        buf!.text = carry + rest
        if (rest.length === 0) break
      }
    }
  }
  flush(false)
  return drafts
}

/** fixed 策略：纯 token 滑窗（无结构感知），仅用于对比评测。 */
export function chunkFixed(doc: ParsedDoc, p: ChunkingParams): ChunkDraft[] {
  const full = doc.blocks
    .map((b) => (b.kind === 'heading' ? `# ${'#'.repeat(Math.max(0, b.level - 1))} ${b.text}` : b.kind === 'table' ? b.markdown : b.text))
    .join('\n\n')
  const out: ChunkDraft[] = []
  let start = 0
  const step = Math.max(32, p.chunkSize - p.chunkOverlap)
  while (start < full.length) {
    const cut = prefixWithinBudget(full.slice(start), p.chunkSize)
    if (cut <= 0) break
    const text = full.slice(start, start + cut)
    out.push({
      text,
      heading_path: '',
      heading_level: null,
      page_num: null,
      char_start: start,
      char_end: start + cut,
      token_count: countTokens(text),
      table_detected: false,
      metadata: {},
    })
    if (cut >= full.length - start) break
    start += step
  }
  return out
}
