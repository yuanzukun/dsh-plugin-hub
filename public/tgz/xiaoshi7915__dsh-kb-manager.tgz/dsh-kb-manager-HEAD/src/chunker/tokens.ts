/**
 * token 计数（DESIGN §5.1：分块以 token 为单位）。
 * MVP 近似器：面向 bge 系分词器（WordPiece）的启发式估计——
 *   CJK 字符 ≈ 1 token/字；ASCII 单词 ≈ 1 token/词（多音节词实际 1-2，偏保守取 1）；
 *   其它非空白连续段 ≈ 1 token/段。
 * 略高估英文是安全的方向（宁可早切、不超窗口）。
 * 接口隔离在 countTokens()：接入真实 bge tokenizer（随 ONNX 模型词表）只改此文件。
 */

const CJK_RE = /[\u3000-\u303f\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uff00-\uffef]/
const ASCII_WORD_RE = /[A-Za-z0-9_]+/
const OTHER_RUN_RE = /[^A-Za-z0-9_\s]/

export function countTokens(text: string): number {
  let tokens = 0
  let i = 0
  const n = text.length
  while (i < n) {
    const ch = text[i]!
    if (ch === ' ' || ch === '\t' || ch === '\n' || ch === '\r') {
      i++
      continue
    }
    if (CJK_RE.test(ch)) {
      tokens++
      i++
      continue
    }
    const rest = text.slice(i)
    const word = rest.match(ASCII_WORD_RE)
    if (word && word.index === 0) {
      tokens++
      i += word[0].length
      continue
    }
    const other = rest.match(OTHER_RUN_RE)
    if (other && other.index === 0) {
      tokens++
      i += other[0].length
      continue
    }
    // 不应到达（上面已覆盖），防御性前进
    i++
  }
  return tokens
}

/** 按 token 预算从 text 的 [0, len) 找到不超预算的前缀长度（字符级） */
export function prefixWithinBudget(text: string, budget: number): number {
  let tokens = 0
  let i = 0
  while (i < text.length) {
    const ch = text[i]!
    if (ch === ' ' || ch === '\t' || ch === '\n' || ch === '\r') {
      i++
      continue
    }
    if (CJK_RE.test(ch)) {
      if (tokens + 1 > budget) break
      tokens++
      i++
      continue
    }
    const rest = text.slice(i)
    const word = rest.match(ASCII_WORD_RE)
    if (word && word.index === 0) {
      if (tokens + 1 > budget) break
      tokens++
      i += word[0].length
      continue
    }
    const other = rest.match(OTHER_RUN_RE)
    if (other && other.index === 0) {
      if (tokens + 1 > budget) break
      tokens++
      i += other[0].length
      continue
    }
    i++
  }
  return i
}
