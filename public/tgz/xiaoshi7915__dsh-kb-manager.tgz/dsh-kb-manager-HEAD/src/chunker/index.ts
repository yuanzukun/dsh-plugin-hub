/** 分块策略注册（DESIGN §5.1）：fixed / recursive 在 MVP；semantic 在 v1.2。 */
import type { ChunkDraft, ChunkingParams, ParsedDoc } from '../contracts/types.ts'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import { chunkFixed, chunkRecursive } from './recursive.ts'
import { countTokens } from './tokens.ts'

export type Chunker = (doc: ParsedDoc, p: ChunkingParams) => ChunkDraft[]

export const chunkers: Record<string, Chunker> = {
  recursive: chunkRecursive,
  fixed: chunkFixed,
  semantic: () => {
    throw new KbError(
      ErrorCodes.SRCH_BAD_FILTER,
      'semantic chunking is not implemented yet (v1.2)',
      '请改用 chunk_strategy: recursive 或 fixed',
    )
  },
}

export function chunkDocument(doc: ParsedDoc, p: ChunkingParams): ChunkDraft[] {
  const c = chunkers[p.strategy]
  if (!c) {
    throw new KbError(ErrorCodes.SRCH_BAD_FILTER, `unknown chunk strategy "${p.strategy}"`, '可选: fixed / recursive')
  }
  const drafts = c(doc, p)
  // 空文档防御：至少不产出空块
  return drafts.filter((d) => d.text.trim().length > 0)
}

/** 预览采样（DESIGN §9：前 2 万字符） */
export function previewText(text: string, maxChars = 20000): string {
  return text.length > maxChars ? text.slice(0, maxChars) : text
}

export { countTokens }
