/**
 * KbManagerRemote —— dsh-kb-manager 的 Host Remote 服务（DESIGN §13.2 Web 数据面）。
 *
 * 继承 @deepseek-ai/dsh-typert-protocol 的 TypertRemoteService：
 * - 构造即 `ctx.reflect.provide('kbManager', this)`（fiber effect，随宿主条目卸载自动注销）
 * - `this.typertRemote` 绑定（serviceKey='kbManager', namespace='kbManager'）供 Gateway 校验
 * - 每个 @Remote 方法是 wire 描述符（src/remote.ts）的服务端实现：
 *   位置参数与描述符 parameters 顺序一一对应；返回值经 Gateway 的 strict result codec 后
 *   原样过线（z.unknown()），因此直接返回 runTool 信封即可
 *
 * 除 cancelJob 外的方法全部复用 executeTool（与 13 个 agent 工具同一执行入口，
 * 错误码 / 信封 / 审计完全一致）；cancelJob 在 MVP 无同名 agent 工具，直接走 JobQueue。
 */
import type { Context } from '@deepseek-ai/cordis'
import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import { executeTool } from './agent-tools/tools.ts'
import { KbError, ErrorCodes } from './contracts/errors.ts'
import type { Envelope, Job, KbMeta, SearchResponse, DocChunkItem } from './contracts/types.ts'
import type { KbManager } from './index.ts'
import { runTool } from './index.ts'
import type {
  CancelJobResult,
  ConfigureResult,
  DeleteDocResult,
  DeleteKbDone,
  DeleteKbPending,
  DocListData,
  JobAccepted,
  KbListData,
  KbStats,
  MultiKbResult,
  ImportTextResult,
  RenameResult,
  RestorePending,
  SnapshotData,
  SnapshotListData,
} from './remote-types.ts'

export class KbManagerRemote extends TypertRemoteService {
  constructor(ctx: Context, private readonly manager: KbManager) {
    super(ctx, 'kbManager')
  }

  /** list_kbs：列出知识库（domain_tag 过滤 + 分页）。 */
  @Remote
  async list(domain_tag?: string, limit?: number, offset?: number): Promise<Envelope<KbListData>> {
    return executeTool<KbListData>(this.manager, 'list_kbs', { domain_tag, limit, offset })
  }

  /** get_kb：单库详情（含 embedding 身份）。 */
  @Remote
  async detail(kb_id: string): Promise<Envelope<KbMeta>> {
    return executeTool<KbMeta>(this.manager, 'get_kb', { kb_id })
  }

  /** get_kb_stats：库统计。 */
  @Remote
  async stats(kb_id: string): Promise<Envelope<KbStats>> {
    return executeTool<KbStats>(this.manager, 'get_kb_stats', { kb_id })
  }

  /** rename_kb：改库名（embedding 身份不变）。 */
  @Remote
  async renameKb(kb_id: string, name: string): Promise<Envelope<RenameResult>> {
    return executeTool<RenameResult>(this.manager, 'rename_kb', { kb_id, name })
  }

  /** multi_kb_search：跨库合并检索（同 embedding 硬校验）。 */
  @Remote
  async multiKbSearch(kb_ids?: string[], query?: string, top_k?: number): Promise<Envelope<MultiKbResult>> {
    return executeTool<MultiKbResult>(this.manager, 'multi_kb_search', { kb_ids, query, top_k })
  }

  /** create_snapshot：快照恢复点。 */
  @Remote
  async createSnapshot(kb_id: string, note?: string): Promise<Envelope<SnapshotData>> {
    return executeTool<SnapshotData>(this.manager, 'create_snapshot', { kb_id, note })
  }

  /** list_snapshots：快照分页列表。 */
  @Remote
  async listSnapshots(kb_id: string, limit?: number, offset?: number): Promise<Envelope<SnapshotListData>> {
    return executeTool<SnapshotListData>(this.manager, 'list_snapshots', { kb_id, limit, offset })
  }

  /** restore_snapshot：两步确认恢复（首次返回 token + impact）。 */
  @Remote
  async restoreSnapshot(kb_id: string, snapshot_id: string, confirm_token?: string): Promise<Envelope<RestorePending | JobAccepted>> {
    return executeTool<RestorePending | JobAccepted>(this.manager, 'restore_snapshot', { kb_id, snapshot_id, confirm_token })
  }

  /** export_kb：导出 kbpack（含向量）/ json（元数据+文本）。 */
  @Remote
  async exportKb(kb_id: string, format?: string, output_path?: string, include_index?: boolean): Promise<Envelope<JobAccepted>> {
    return executeTool<JobAccepted>(this.manager, 'export_kb', { kb_id, format, output_path, include_index })
  }

  /** import_kb：导入（create_new 建库 / merge 合入，kb_id 必填）。 */
  @Remote
  async importKb(file_path: string, merge_strategy?: string, kb_id?: string): Promise<Envelope<JobAccepted>> {
    return executeTool<JobAccepted>(this.manager, 'import_kb', { file_path, merge_strategy, kb_id })
  }

  /** compact_index：整理碎片回收空间（异步）。 */
  @Remote
  async compactIndex(kb_id: string): Promise<Envelope<JobAccepted>> {
    return executeTool<JobAccepted>(this.manager, 'compact_index', { kb_id })
  }

  /** list_documents：文档分页列表（status 过滤）。 */
  @Remote
  async docs(kb_id: string, status?: string, limit?: number, offset?: number): Promise<Envelope<DocListData>> {
    return executeTool<DocListData>(this.manager, 'list_documents', { kb_id, status, limit, offset })
  }

  /** list_doc_chunks：按文档列出已入库分块（Web 面板“查看分块”）。 */
  @Remote
  async listDocChunks(kb_id: string, doc_id: string): Promise<Envelope<DocChunkItem[]>> {
    return runTool<DocChunkItem[]>(() => this.manager.docs.listDocChunks(kb_id, doc_id))
  }

  /** search_kb：混合检索（top_k 1..50，默认走配置）。 */
  @Remote
  async search(kb_id: string, query: string, top_k?: number): Promise<Envelope<SearchResponse>> {
    return executeTool<SearchResponse>(this.manager, 'search_kb', { kb_id, query, top_k })
  }

  /** create_kb：建库（embedding 身份建后不可变）。 */
  @Remote
  async create(name: string, description?: string, domain_tags?: string[]): Promise<Envelope<KbMeta>> {
    return executeTool<KbMeta>(this.manager, 'create_kb', { name, description, domain_tags })
  }

  /** import_document：异步导入（立即返回 job_id，UI 轮询 job）。 */
  @Remote
  async importDoc(kb_id: string, source: string, metadata?: Record<string, unknown>): Promise<Envelope<JobAccepted>> {
    return executeTool<JobAccepted>(this.manager, 'import_document', { kb_id, source, metadata })
  }

  /** importText：浏览器文件上传导入（Web 面板 input[type=file] 读文本 → 内容直达宿主，同步导入）。 */
  @Remote
  async importText(kb_id: string, file_name: string, source_type: string, text: string, source_key?: string, metadata?: Record<string, unknown>): Promise<Envelope<ImportTextResult>> {
    return runTool<ImportTextResult>(() => this.manager.docs.importText(kb_id, {
      file_name, source_type, text,
      source_key: source_key ?? text,
      metadata: metadata ?? {},
    }) as unknown as ImportTextResult)
  }

  /** delete_document：软删文档（重导同路径可恢复）。 */
  @Remote
  async deleteDoc(kb_id: string, doc_id: string): Promise<Envelope<DeleteDocResult>> {
    return executeTool<DeleteDocResult>(this.manager, 'delete_document', { kb_id, doc_id })
  }

  /** get_job：任务状态轮询（只读幂等）。 */
  @Remote
  async job(job_id: string): Promise<Envelope<Job>> {
    return executeTool<Job>(this.manager, 'get_job', { job_id })
  }

  /** cancel_job：批边界协作式取消（MVP 独有，无同名 agent 工具）。 */
  @Remote
  async cancelJob(job_id: string): Promise<Envelope<CancelJobResult>> {
    return runTool<CancelJobResult>(() => {
      const known = this.manager.jobs.get(job_id)
      if (!known) {
        throw new KbError(ErrorCodes.JOB_NOT_FOUND, `任务不存在: ${job_id}`, '确认 job_id 来自异步操作的返回')
      }
      const r = this.manager.jobs.cancel(job_id)
      return r
    })
  }

  /** delete_kb：两步确认删库（token 由首次调用签发）。 */
  @Remote
  async deleteKb(kb_id: string, confirm_token?: string): Promise<Envelope<DeleteKbPending | DeleteKbDone>> {
    return executeTool<DeleteKbPending | DeleteKbDone>(this.manager, 'delete_kb', { kb_id, confirm_token })
  }

  /** rebuild_index：全量重建索引（异步；换引擎/换模型唯一合法路径）。 */
  @Remote
  async rebuild(kb_id: string, target_engine?: string): Promise<Envelope<JobAccepted>> {
    return executeTool<JobAccepted>(this.manager, 'rebuild_index', { kb_id, target_engine })
  }

  /** configure：白名单配置热更。 */
  @Remote
  async configure(patch: Record<string, unknown>): Promise<Envelope<ConfigureResult>> {
    return executeTool<ConfigureResult>(this.manager, 'configure', { patch })
  }
}
