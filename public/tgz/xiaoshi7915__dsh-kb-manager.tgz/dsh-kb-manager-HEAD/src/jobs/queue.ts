/**
 * Job 队列（DESIGN §6）：
 * - 每 KB 一个 FIFO 写队列（检索读不排队）；全局并行写 job ≤ 2
 * - jobs 表在各自 kb.db 内；JobQueue 维护 job_id→kbId 运行时索引，
 *   启动时扫描所有 kb.db 重建（崩溃恢复：遗留 running → JOB.INTERRUPTED）
 * - cancel：批边界协作式（embedding 批边界/阶段边界）；写索引事务阶段不可中断
 */
import { randomUUID } from 'node:crypto'
import type { Job, JobProgress, JobStage, JobType } from '../contracts/types.ts'
import type { KbStore } from '../store/store.ts'
import { err } from '../contracts/errors.ts'

const STAGE_LABELS: Record<JobStage, string> = {
  reading: '读取中', parsing: '解析中', chunking: '分块中',
  embedding: '向量化中', indexing: '写索引中', copying: '复制中', restoring: '恢复中',
}
export function stageLabel(stage: JobStage): string {
  return STAGE_LABELS[stage] ?? stage
}

export type JobWork = (
  report: (done: number, total: number, stage: JobStage) => void,
  signal: AbortSignal,
) => Promise<unknown>

interface Running {
  job: Job
  abort: AbortController
  work: JobWork
  nonInterruptible: boolean
  store: KbStore
}

interface QueueOpts {
  getStore: (kbId: string) => KbStore
  listStores: () => KbStore[]
  onEvent?: (job: Job) => void
  maxGlobal?: number
}

export class JobQueue {
  private readonly getStore: (kbId: string) => KbStore
  private readonly listStores: () => KbStore[]
  private readonly onEvent?: (job: Job) => void
  private readonly maxGlobal: number
  private readonly perKb = new Map<string, Array<{ job: Job; work: JobWork }>>()
  private readonly running = new Map<string, Running>()
  private readonly jobIndex = new Map<string, string>() // job_id → kbId
  private processing = false

  constructor(opts: QueueOpts) {
    this.getStore = opts.getStore
    this.listStores = opts.listStores
    this.onEvent = opts.onEvent
    this.maxGlobal = opts.maxGlobal ?? 2
  }

  /** 启动时重建 job 索引 + 崩溃恢复；返回恢复的 Job 列表 */
  recover(): Job[] {
    const recovered: Job[] = []
    for (const store of this.listStores()) {
      const rows = store.db.prepare('SELECT * FROM jobs').all() as Array<Record<string, unknown>>
      for (const r of rows) {
        const job = JobQueue.fromRow(r as never)
        this.jobIndex.set(job.job_id, job.kb_id)
        if (job.status === 'queued' || job.status === 'running') {
          job.status = 'failed'
          job.error = { code: 'JOB.INTERRUPTED', message: '进程重启时任务中断', hint: '该任务可安全重放（导入幂等、重建可重入）' }
          job.finished_at = new Date().toISOString()
          this.persist(store, job)
          recovered.push(job)
        }
      }
    }
    return recovered
  }

  enqueue(kbId: string, type: JobType, work: JobWork): Job {
    const store = this.getStore(kbId)
    const job: Job = {
      job_id: randomUUID(),
      type,
      kb_id: kbId,
      status: 'queued',
      progress: { done: 0, total: 1, stage: 'reading', stage_label: stageLabel('reading') },
      created_at: new Date().toISOString(),
    }
    this.jobIndex.set(job.job_id, kbId)
    this.persist(store, job)
    const q = this.perKb.get(kbId) ?? []
    q.push({ job, work })
    this.perKb.set(kbId, q)
    void this.pump()
    return job
  }

  /** get_job 入口：不携带 kb_id，经 jobIndex 定位 */
  get(jobId: string): Job | null {
    const mem = this.running.get(jobId)
    if (mem) return mem.job
    const kbId = this.jobIndex.get(jobId)
    if (!kbId) return null
    const row = this.getStore(kbId).db.prepare('SELECT * FROM jobs WHERE job_id = ?').get(jobId) as Record<string, unknown> | undefined
    return row ? JobQueue.fromRow(row as never) : null
  }

  /** 返回 status：cancelled（已取消）/ 当前状态；终态由调用方按 JOB_ALREADY_TERMINAL 处理 */
  cancel(jobId: string): { job_id: string; status: Job['status'] } {
    const run = this.running.get(jobId)
    if (run) {
      if (run.nonInterruptible) return { job_id: jobId, status: run.job.status } // 写索引事务阶段不可中断
      run.abort.abort()
      return { job_id: jobId, status: 'cancelled' }
    }
    const job = this.get(jobId)
    if (!job) return { job_id: jobId, status: 'queued' } // 调用方按 JOB_NOT_FOUND 处理
    if (job.status === 'done' || job.status === 'failed' || job.status === 'cancelled') {
      return { job_id: jobId, status: job.status }
    }
    const store = this.getStore(job.kb_id)
    this.persist(store, { ...job, status: 'cancelled', finished_at: new Date().toISOString() })
    return { job_id: jobId, status: 'cancelled' }
  }

  markNonInterruptible(jobId: string, on: boolean): void {
    const run = this.running.get(jobId)
    if (run) run.nonInterruptible = on
  }

  private persist(store: KbStore, job: Job): void {
    store.db.prepare(
      `INSERT INTO jobs (job_id, kb_id, type, status, progress_json, result_json, error_json, created_at, started_at, finished_at)
       VALUES (?,?,?,?,?,?,?,?,?,?)
       ON CONFLICT(job_id) DO UPDATE SET status=excluded.status, progress_json=excluded.progress_json,
         result_json=excluded.result_json, error_json=excluded.error_json,
         started_at=COALESCE(excluded.started_at, jobs.started_at), finished_at=excluded.finished_at`,
    ).run(
      job.job_id, job.kb_id, job.type, job.status, JSON.stringify(job.progress),
      job.result === undefined ? null : JSON.stringify(job.result),
      job.error ? JSON.stringify(job.error) : null,
      job.created_at, job.started_at ?? null, job.finished_at ?? null,
    )
    this.onEvent?.(job)
  }

  private async pump(): Promise<void> {
    if (this.processing) return
    this.processing = true
    try {
      while (this.running.size < this.maxGlobal) {
        const next = this.nextQueued()
        if (!next) break
        await this.run(next)
      }
    } finally {
      this.processing = false
    }
  }

  private nextQueued(): { job: Job; work: JobWork } | null {
    for (const [, q] of this.perKb) {
      const entry = q[0]
      if (!entry) continue
      const busy = [...this.running.values()].some((r) => r.job.kb_id === entry.job.kb_id)
      if (busy) continue
      q.shift()
      return entry
    }
    return null
  }

  private async run(picked: { job: Job; work: JobWork }): Promise<void> {
    const job = picked.job
    const store = this.getStore(job.kb_id)
    job.status = 'running'
    job.started_at = new Date().toISOString()
    const abort = new AbortController()
    const entry: Running = { job, abort, work: picked.work, nonInterruptible: false, store }
    this.running.set(job.job_id, entry)
    this.persist(store, job)
    const report = (done: number, total: number, stage: JobStage) => {
      if (entry.job.status !== 'running') return
      entry.job.progress = { done, total, stage, stage_label: stageLabel(stage) }
      this.persist(entry.store, entry.job)
    }
    try {
      const result = await entry.work(report, abort.signal)
      if (abort.signal.aborted) this.finish(entry, 'cancelled')
      else this.finish(entry, 'done', { result })
    } catch (e) {
      if (abort.signal.aborted) this.finish(entry, 'cancelled')
      else {
        // B13：保留 KbError 的 code/hint（错误码契约 §7.1）；否则所有异步任务错误都变成 FS.IO
        const envelope = err(e)
        if (envelope.ok) throw new Error('err() 不应返回 ok')
        this.finish(entry, 'failed', { error: envelope.error })
      }
    }
    void this.pump()
  }

  private finish(entry: Running, status: Job['status'], extra?: Partial<Job>): void {
    const next: Job = { ...entry.job, status, finished_at: new Date().toISOString(), ...extra }
    this.running.delete(next.job_id)
    this.persist(entry.store, next)
  }

  static fromRow(r: {
    job_id: string; kb_id: string; type: string; status: string; progress_json: string
    result_json: string | null; error_json: string | null
    created_at: string; started_at: string | null; finished_at: string | null
  }): Job {
    return {
      job_id: r.job_id,
      kb_id: r.kb_id,
      type: r.type as Job['type'],
      status: r.status as Job['status'],
      progress: JSON.parse(r.progress_json) as JobProgress,
      result: r.result_json ? JSON.parse(r.result_json) : undefined,
      error: r.error_json ? JSON.parse(r.error_json) : undefined,
      created_at: r.created_at,
      started_at: r.started_at ?? undefined,
      finished_at: r.finished_at ?? undefined,
    }
  }
}
