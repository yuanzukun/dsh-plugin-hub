/**
 * dsh-kb-manager Host 入口（DESIGN §3/§13.2）。
 * bundle patch 行（cordis.patch.yml 的 kb-manager 行）→ Cordis 插件：
 * - 注册 13 个 MVP Agent 工具（docstring 见 DESIGN 附录 C / agent-tools/tools.ts）
 * - system prompt preamble（工具协作约定）
 * - fiber 卸载时自动注销全部工具与 prompt section 并关闭所有 store
 *
 * Job 事件：MVP 仅记日志（Web 端经 get_job 轮询，DESIGN §6.2）。
 * 插件形态与 harness 内置工具插件一致：模块具名导出即 Plugin.Object。
 */
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-system-prompt'
import { KbManager } from './index.ts'
import { TOOL_SPECS, TOOLS_PREAMBLE, executeTool } from './agent-tools/tools.ts'
import type { Envelope } from './contracts/types.ts'
import { KbManagerRemote } from './remote-service.ts'

export const name = 'dsh-kb-manager'
export const inject = ['tools', 'systemPrompt']

export interface Config {
  /** 存储根目录；空 = ~/.dsh/kb-manager/ */
  storagePath?: string
  logLevel?: 'debug' | 'info' | 'warn' | 'error'
  /** 导入白名单目录（宿主侧安全配置，经 profile 层注入；缺省 = 会话 workspace + storage/inbox） */
  importAllowedDirs?: string[]
  /** 会话 workspace（默认导入白名单的一部分） */
  workspace?: string
}

export const Config: z<Config> = z.object({
  storagePath: z.string().default(''),
  logLevel: z.union(['debug', 'info', 'warn', 'error'] as const).default('info'),
  importAllowedDirs: z.array(z.string()).default([]),
  workspace: z.string(),
})

// ---------- JSON Schema（ToolSpec.parameters）→ dsh-tools spec 转换 ----------

type JsonNode = Record<string, unknown>

function nodeToSpec(node: JsonNode): JsonNode {
  const out: JsonNode = {}
  if (typeof node.description === 'string') out.description = node.description
  switch (node.type) {
    case 'string': {
      out.type = 'string'
      if (Array.isArray(node.enum)) out.enum = node.enum as readonly string[]
      break
    }
    case 'integer': out.type = 'integer'; break
    case 'number': out.type = 'number'; break
    case 'boolean': out.type = 'boolean'; break
    case 'array': {
      out.type = 'array'
      if (node.items) out.items = nodeToSpec(node.items as JsonNode)
      break
    }
    case 'object': {
      out.type = 'object'
      out.additionalProperties = !node.properties
      if (node.properties) {
        out.properties = Object.fromEntries(
          Object.entries(node.properties as JsonNode).map(([k, v]) => [k, nodeToSpec(v as JsonNode)]),
        )
      }
      break
    }
    default: out.type = 'json'
  }
  return out
}

function toParamSpec(root: JsonNode): Record<string, JsonNode> {
  const props = (root.properties ?? {}) as JsonNode
  const required = (root.required ?? []) as string[]
  const out: Record<string, JsonNode> = {}
  for (const [k, v] of Object.entries(props)) {
    const spec = nodeToSpec(v as JsonNode)
    if (required.includes(k)) spec.required = true
    out[k] = spec
  }
  return out
}

// ---------- 信封渲染（模型看到的工具输出） ----------

function renderEnvelope(value: unknown): string {
  const env = value as Envelope<unknown>
  if (!env || typeof env !== 'object' || !('ok' in env)) return JSON.stringify(value)
  if (env.ok) return JSON.stringify(env.data, null, 2)
  const e = env.error
  return `ERROR ${e.code}: ${e.message}${e.hint ? ` | hint: ${e.hint}` : ''}`
}

// ---------- 插件主体 ----------

export function apply(ctx: Context, config: Config): void {
  const log = ctx.logger('kb-manager')
  const m = new KbManager(config.storagePath || undefined, {
    import_allowed_dirs: config.importAllowedDirs,
    workspace: config.workspace,
    onJobEvent: (job) => {
      if (job.status === 'done' || job.status === 'failed') {
        const detail = job.error ? `: ${job.error.code} ${job.error.message}` : ''
        log.info(`job ${job.job_id} (${job.type}/${job.kb_id}) ${job.status}${detail}`)
      }
    },
  })

  const disposers: Array<() => void> = []
  // Web 数据面：注册 'kbManager' Remote 服务（DESIGN §13.2）。
  // TypertRemoteService 构造即 provide，fiber 卸载时自动注销，无需显式 disposer。
  new KbManagerRemote(ctx, m)
  for (const spec of TOOL_SPECS) {
    disposers.push(ctx.tools.register(defineTool({
      name: spec.name,
      description: spec.description,
      parameters: toParamSpec(spec.parameters),
      output: {
        schema: { type: 'json' },
        render: (_args: unknown, value: unknown) => [{ type: 'text', text: renderEnvelope(value) }],
      },
      execute: (args: unknown) => executeTool(m, spec.name, (args ?? {}) as Record<string, unknown>),
    } as never)))
  }
  disposers.push(ctx.systemPrompt.section({
    name: 'tool:kb-manager',
    order: 150,
    text: TOOLS_PREAMBLE,
  }))

  ctx.effect(() => () => {
    for (const d of disposers) {
      try { d() } catch { /* fiber 已注销，忽略 */ }
    }
    m.close()
    log.info('dsh-kb-manager 已关闭')
  }, 'kb-manager')
}
