/**
 * dsh-kb-manager host Typert 清单（TYPERT 导出，经 package.json exports["./typert"] 暴露）。
 *
 * @deepseek-ai/dsh-typert-loader 在装配期扫描宿主 Loader 条目，对本包执行
 * `import('dsh-kb-manager/typert')` 并用 validateTypertManifest 校验：
 * - package 必须等于包名（manifest 由导出它的包独占）
 * - face 固定 'host'；schemas 数组（本插件无独立 schema，留空）
 * - model.services[0] 声明 'kbManager' 服务的 exportName（KbManagerRemote）与成员签名
 * - invocations 与 src/remote.ts 的 KB_INVOCATIONS 同源
 *
 * 分发路径：dsh-host-apiproxy Typert Gateway `claimsEndpoint` 命中
 * `ctx.typert.local.get('kbManager/<method>')` → 解析 service 'kbManager'
 * （本包 host-entry 注册的 KbManagerRemote）→ 按描述符解码参数并调用。
 */
import { KB_INVOCATIONS, KB_NAMESPACE, KB_PACKAGE } from './remote.ts'

const member = (inv: (typeof KB_INVOCATIONS)[number]) => ({
  kind: 'method',
  name: inv.method,
  signature: `${inv.method}(${inv.parameters
    .map((p) => `${p.name}${p.acceptsUndefined ? '?' : ''}: unknown`)
    .join(', ')}): Promise<unknown>`,
})

export const TYPERT = {
  package: KB_PACKAGE,
  face: 'host',
  schemas: [] as unknown[],
  invocations: KB_INVOCATIONS,
  model: {
    services: [
      {
        tags: [],
        description:
          'dsh-kb-manager host service: knowledge-base management, document import, hybrid search, job polling and configuration, exposed to the Web settings UI through the Typert Gateway.',
        summary: 'dsh-kb-manager remote service.',
        key: KB_NAMESPACE,
        exportName: 'KbManagerRemote',
        members: KB_INVOCATIONS.map(member),
        types: [],
      },
    ],
    events: [],
    objects: [],
  },
}

export default TYPERT
