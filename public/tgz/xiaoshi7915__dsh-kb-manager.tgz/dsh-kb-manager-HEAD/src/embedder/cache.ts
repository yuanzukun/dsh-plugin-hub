/**
 * 磁盘向量缓存（DESIGN §5.2）：key = sha256(model|provider|dim|text)。
 * 换模型时 key 自动失配，旧缓存不污染新身份。
 * 实现：storage_path/cache/embedding/{key[0:2]}/{key}.f32（Float32Array 裸字节）。
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'

export class EmbeddingCache {
  constructor(private readonly dir: string) {}
  private pathFor(key: string): string {
    return join(this.dir, key.slice(0, 2), key + '.f32')
  }
  get(key: string, dim: number): Float32Array | null {
    const p = this.pathFor(key)
    if (!existsSync(p)) return null
    const buf = readFileSync(p)
    if (buf.byteLength !== dim * 4) return null
    return new Float32Array(buf.buffer, buf.byteOffset, dim)
  }
  set(key: string, vec: number[]): void {
    const p = this.pathFor(key)
    mkdirSync(join(this.dir, key.slice(0, 2)), { recursive: true })
    writeFileSync(p, Buffer.from(new Float32Array(vec).buffer))
  }
  /** 批量命中检测：返回 [cacheKey 命中?, 未命中 index 列表] */
  probe(keys: string[], dim: number): { cached: Array<Float32Array | null>; misses: number[] } {
    const cached = keys.map((k) => this.get(k, dim))
    const misses = cached.map((v, i) => (v === null ? i : -1)).filter((i) => i >= 0)
    return { cached, misses }
  }
}

export function cacheKeyOf(key: string): string {
  return createHash('sha256').update(key).digest('hex')
}
