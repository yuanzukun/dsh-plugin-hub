/**
 * ONNX 内置 embedding（DESIGN §5.2，拍板⑤'）：
 * - onnxruntime-node 预编译二进制（零编译）+ bge-small-zh-v1.5 ONNX 模型（Xenova 官方转换）
 * - 首次使用自动下载模型（固定 URL + sha256 校验；约 100MB，下载失败不落脏数据）
 * - 输入：WordPiece 分词（本地 vocab.txt，对齐 transformers BertTokenizer）→ input_ids / attention_mask / token_type_ids
 * - 输出：[CLS] 池化 → L2 归一化（512 维）
 */
import { createHash } from 'node:crypto'
import { createReadStream, createWriteStream, existsSync, mkdirSync } from 'node:fs'
import { readFile, rename, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { Readable } from 'node:stream'
import type { EmbeddingIdentity } from '../contracts/types.ts'
import type { Embedder } from './embedder.ts'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import { BertTokenizer } from './bert-tokenizer.ts'

const MODEL_NAME = 'bge-small-zh-v1.5'
const DIM = 512
// 国内可直连镜像（sha256 校验保证完整性与防篡改）；主源 https://huggingface.co/Xenova/bge-small-zh-v1.5/resolve/main/onnx/model.onnx
const MODEL_URL = 'https://hf-mirror.com/Xenova/bge-small-zh-v1.5/resolve/main/onnx/model.onnx'
const MODEL_SHA256 = '69a0b846f4f116b5e6aabf9546ea6754d02264f3211a13a1bd69b31b8040749a'
const VOCAB_URL = 'https://hf-mirror.com/Xenova/bge-small-zh-v1.5/resolve/main/vocab.txt'
const VOCAB_SHA256 = '45bbac6b341c319adc98a532532882e91a9cefc0329aa57bac9ae761c27b291c'

type Ort = typeof import('onnxruntime-node')

function sha256File(path: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash = createHash('sha256')
    const stream = createReadStream(path)
    stream.on('data', (d) => hash.update(d))
    stream.on('end', () => resolve(hash.digest('hex')))
    stream.on('error', reject)
  })
}

async function downloadFile(url: string, dest: string, tmp: string): Promise<void> {
  const res = await fetch(url, { redirect: 'follow' })
  if (!res.ok || !res.body) throw new KbError(ErrorCodes.EMB_NOT_READY, `模型下载失败 HTTP ${res.status}: ${url}`, '网络不可达时可在插件配置页确认后重试')
  await new Promise<void>((resolve, reject) => {
    const ws = createWriteStream(tmp)
    Readable.fromWeb(res.body as never).pipe(ws)
    ws.on('finish', () => { ws.close(); resolve() })
    ws.on('error', reject)
  })
}

export class OnnxEmbedder implements Embedder {
  private session: Awaited<ReturnType<Ort['InferenceSession']['create']>> | null = null
  private tokenizer: BertTokenizer | null = null
  private ort: Ort | null = null

  constructor(
    private readonly modelDir: string,
    private readonly model: string = MODEL_NAME,
    private readonly dim = DIM,
  ) {}

  identity(): EmbeddingIdentity {
    return { model: this.model, provider: 'onnx', dim: this.dim }
  }

  /** 懒加载：加载 onnxruntime → 确保模型/vocab 文件（首次自动下载 + sha256 校验）→ WordPiece → session */
  async ensureReady(confirmDownload: (url: string) => Promise<boolean>): Promise<void> {
    if (this.session) return
    let ort: Ort
    try {
      ort = (await import('onnxruntime-node')) as Ort
    } catch {
      throw new KbError(
        ErrorCodes.EMB_NOT_READY,
        'onnxruntime-node 依赖加载失败（可选依赖缺失或安装失败）',
        '请重新安装插件；或临时改用 openai-compat / ollama provider。',
      )
    }
    this.ort = ort
    mkdirSync(this.modelDir, { recursive: true })

    const modelPath = join(this.modelDir, 'model.onnx')
    const vocabPath = join(this.modelDir, 'vocab.txt')

    // 模型文件：缺失/校验失败 → 下载（confirm 通过后）
    if (!existsSync(modelPath) || (await sha256File(modelPath)) !== MODEL_SHA256) {
      const ok = await confirmDownload(MODEL_URL)
      if (!ok) {
        throw new KbError(ErrorCodes.EMB_NOT_READY, 'ONNX 模型未下载', `确认后自动下载（约 100MB）：${MODEL_URL}`)
      }
      await this.ensureModelFile(modelPath, MODEL_URL, MODEL_SHA256)
    }
    if (!existsSync(vocabPath) || (await sha256File(vocabPath)) !== VOCAB_SHA256) {
      const ok = await confirmDownload(VOCAB_URL)
      if (!ok) throw new KbError(ErrorCodes.EMB_NOT_READY, '模型词表未下载', `确认后自动下载：${VOCAB_URL}`)
      await this.ensureModelFile(vocabPath, VOCAB_URL, VOCAB_SHA256)
    }

    const vocabText = await readFile(vocabPath, 'utf8')
    this.tokenizer = new BertTokenizer(vocabText)
    this.session = await ort.InferenceSession.create(modelPath)
  }

  /** 下载到临时文件 → sha256 校验 → 原子替换；失败清理临时文件（不落脏数据） */
  private async ensureModelFile(dest: string, url: string, expected: string): Promise<void> {
    if (!/^[0-9a-f]{64}$/i.test(expected)) {
      throw new KbError(ErrorCodes.EMB_NOT_READY, `模型 sha256 未配置（当前: ${expected}）`, '需开发者先下载模型文件计算哈希后填入 embedder 配置，再重试导入')
    }
    const tmp = `${dest}.tmp`
    try {
      await downloadFile(url, dest, tmp)
      const actual = await sha256File(tmp)
      if (actual !== expected) {
        throw new KbError(ErrorCodes.EMB_NOT_READY, `模型校验失败 sha256 不匹配（期望 ${expected.slice(0, 12)}…，实际 ${actual.slice(0, 12)}…）`, '下载可能被篡改，请重试')
      }
      await rm(dest, { force: true })
      await rename(tmp, dest)
    } catch (e) {
      await rm(tmp, { force: true }).catch(() => undefined)
      throw e
    }
  }

  async embed(texts: string[], signal?: AbortSignal): Promise<number[][]> {
    await this.ensureReady(async () => true) // 首次自动下载（本地模型，固定 URL + sha256）
    const ort = this.ort!
    const session = this.session!
    const tokenizer = this.tokenizer!
    const out: number[][] = []
    for (const text of texts) {
      if (signal?.aborted) throw new Error('任务已取消') // queue 按 abort 标 cancelled，不读错误码
      const enc = tokenizer.encode(text)
      const n = enc.inputIds.length
      const feeds: Record<string, unknown> = {
        input_ids: new ort.Tensor('int64', BigInt64Array.from(enc.inputIds.map((x) => BigInt(x))), [1, n]),
        attention_mask: new ort.Tensor('int64', BigInt64Array.from(enc.attentionMask.map((x) => BigInt(x))), [1, n]),
        token_type_ids: new ort.Tensor('int64', BigInt64Array.from(enc.tokenTypeIds.map((x) => BigInt(x))), [1, n]),
      }
      const res = (await session.run(feeds)) as Record<string, { data: ArrayLike<number>; dims: number[] }>
      const hidden = res.last_hidden_state ?? res['output_0']
      if (!hidden) throw new KbError(ErrorCodes.EMB_DIMENSION_MISMATCH, `模型输出名未知: ${Object.keys(res).join(',')}`)
      // last_hidden_state: [1, seq, dim] → 取 [CLS]（第 0 位）→ L2 归一化
      const vec: number[] = []
      for (let i = 0; i < this.dim; i++) vec.push(hidden.data[i] as number)
      const norm = Math.sqrt(vec.reduce((a, b) => a + b * b, 0)) || 1
      out.push(vec.map((x) => x / norm))
    }
    return out
  }
}
