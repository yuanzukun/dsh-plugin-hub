/**
 * openai-compat provider：任意兼容 /v1/embeddings 的本地/远端服务（DESIGN §5.2）。
 * 加 provider 是配置项不是架构变更。
 */
import type { EmbeddingIdentity } from '../contracts/types.ts'
import type { Embedder } from './embedder.ts'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import { EMBED_BATCH, withRetry } from './embedder.ts'

export interface CompatConfig {
  baseUrl: string
  apiKeyRef: string // 解析后的明文 key（宿主凭据注入）
  model: string
  dim: number
}

export class OpenAiCompatEmbedder implements Embedder {
  private cfg: CompatConfig
  constructor(cfg: CompatConfig) {
    this.cfg = cfg
  }
  identity(): EmbeddingIdentity {
    return { model: this.cfg.model, provider: 'openai-compat', dim: this.cfg.dim }
  }
  async embed(texts: string[], signal?: AbortSignal): Promise<number[][]> {
    const out: number[][] = []
    for (let i = 0; i < texts.length; i += EMBED_BATCH) {
      const batch = texts.slice(i, i + EMBED_BATCH)
      out.push(...(await withRetry(() => this.callBatch(batch, signal), batch.join(' ').slice(0, 60))))
    }
    return out
  }
  private async callBatch(batch: string[], signal?: AbortSignal): Promise<number[][]> {
    let res: Response
    try {
      res = await fetch(this.cfg.baseUrl.replace(/\/$/, '') + '/embeddings', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          ...(this.cfg.apiKeyRef ? { authorization: `Bearer ${this.cfg.apiKeyRef}` } : {}),
        },
        body: JSON.stringify({ model: this.cfg.model, input: batch }),
        signal,
      })
    } catch (e) {
      throw new KbError(ErrorCodes.EMB_MODEL_UNREACHABLE, `embedding 服务请求失败: ${(e as Error).message}`)
    }
    if (!res.ok) {
      throw new KbError(ErrorCodes.EMB_MODEL_UNREACHABLE, `embedding 服务返回 ${res.status}`)
    }
    const json = (await res.json()) as { data: Array<{ index: number; embedding: number[] }> }
    return json.data.sort((a, b) => a.index - b.index).map((d) => {
      if (d.embedding.length !== this.cfg.dim) {
        throw new KbError(ErrorCodes.EMB_DIMENSION_MISMATCH, `embedding 维度 ${d.embedding.length} != ${this.cfg.dim}`)
      }
      return d.embedding
    }).map((v) => {
      // B8：L2 归一化（接口契约"已 L2 归一化"）；vec0 默认 L2 度量，未归一向量排序会失真（L2≠cosine）
      const norm = Math.sqrt(v.reduce((a, b) => a + b * b, 0)) || 1
      return v.map((x) => x / norm)
    })
  }
}
