/**
 * Embedding 层（DESIGN §5.2）：
 * - 统一 embed(texts[]) 接口；provider = onnx(默认内置) / ollama / openai-compat
 * - 磁盘缓存 key = sha256(model|provider|dim|text)
 * - KB 绑定不可变身份 (model, provider, dim)；维度不匹配 → EMB.DIMENSION_MISMATCH
 * - 批量 32、出站并发 ≤4、指数退避重试 3 次
 * - query 侧 instruction 前缀由调用方（search-service）拼好
 */
import { createHash } from 'node:crypto'
import type { EmbeddingIdentity } from '../contracts/types.ts'
import { KbError, ErrorCodes } from '../contracts/errors.ts'

export interface Embedder {
  identity(): EmbeddingIdentity
  /** 返回与 texts 等长的向量数组（已 L2 归一化） */
  embed(texts: string[], signal?: AbortSignal): Promise<number[][]>
}

export const EMBED_BATCH = 32

export function embedKey(model: string, provider: string, dim: number, text: string): string {
  return createHash('sha256').update(`${model}|${provider}|${dim}|${text}`).digest('hex')
}

export function assertSameIdentity(a: EmbeddingIdentity, b: EmbeddingIdentity, where = 'KB 身份与当前配置'): void {
  if (a.model !== b.model || a.provider !== b.provider || a.dim !== b.dim) {
    throw new KbError(
      ErrorCodes.EMB_DIMENSION_MISMATCH,
      `Embedding identity mismatch: ${where} expects ${a.model}/${a.provider}/${a.dim}, got ${b.model}/${b.provider}/${b.dim}`,
      '该 KB 绑定固定的 embedding 身份。换模型请用 rebuild_index(kb_id, embedding={...}) 全量重建，不要混用。',
    )
  }
}

/** 指数退避重试（3 次，仅对可重试错误） */
export async function withRetry<T>(fn: () => Promise<T>, what: string): Promise<T> {
  let lastErr: unknown
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      return await fn()
    } catch (e) {
      lastErr = e
      const retriable = e instanceof KbError ? e.code === ErrorCodes.EMB_MODEL_UNREACHABLE : true
      if (!retriable) throw e
      await new Promise((r) => setTimeout(r, 300 * 2 ** attempt))
    }
  }
  throw new KbError(
    ErrorCodes.EMB_MODEL_UNREACHABLE,
    `Embedding 调用失败（已重试 3 次）: ${what}`,
    'embedding 服务不可达；检查 provider 配置/网络后重试（缓存命中的部分不会重算）。',
  )
}
