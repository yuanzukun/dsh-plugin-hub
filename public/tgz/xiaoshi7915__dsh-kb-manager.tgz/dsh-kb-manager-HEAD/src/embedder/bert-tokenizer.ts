/**
 * BERT WordPiece 分词器（bge-small-zh-v1.5，DESIGN §5.2 拍板⑤'）。
 * 对齐 transformers BertTokenizer 的 BasicTokenizer + WordPieceTokenizer：
 * - clean_text：空白归一、控制字符移除
 * - tokenize_chinese_chars：CJK 两侧加空格（中文逐字）
 * - 按空白/标点切分；WordPiece 最长前缀匹配，首 piece 不带 ##、后续带 ##
 * - 组装 [CLS]…[SEP]，截断 maxLen，[PAD] 补齐，输出 input_ids / attention_mask / token_type_ids
 */
export interface BertEncoding {
  inputIds: number[]
  attentionMask: number[]
  tokenTypeIds: number[]
}

function isCjk(code: number): boolean {
  return (
    (code >= 0x4e00 && code <= 0x9fff) ||
    (code >= 0x3400 && code <= 0x4dbf) ||
    (code >= 0x20000 && code <= 0x2a6df) ||
    (code >= 0xf900 && code <= 0xfaff) ||
    (code >= 0x2f800 && code <= 0x2fa1f)
  )
}

function isAlnumChar(c: string): boolean {
  return /[A-Za-z0-9]/u.test(c)
}

export class BertTokenizer {
  private readonly vocab = new Map<string, number>()
  readonly unkId: number
  readonly clsId: number
  readonly sepId: number
  readonly padId: number
  private readonly maxLen: number

  constructor(vocabText: string, maxLen = 512) {
    for (const line of vocabText.split(/\r?\n/u)) {
      if (!line) continue
      this.vocab.set(line, this.vocab.size)
    }
    this.unkId = this.vocab.get('[UNK]') ?? 100
    this.clsId = this.vocab.get('[CLS]') ?? 101
    this.sepId = this.vocab.get('[SEP]') ?? 102
    this.padId = this.vocab.get('[PAD]') ?? 0
    this.maxLen = maxLen
  }

  vocabSize(): number {
    return this.vocab.size
  }

  private cleanText(text: string): string {
    let out = text.replace(/\t/u, ' ')
    out = out.replace(/\n/u, ' ')
    out = out.replace(/\r/u, ' ')
    // 移除控制字符
    let cleaned = ''
    for (const c of out) {
      const code = c.codePointAt(0)!
      if (code === 0 || code === 0xfffd || (code >= 0x1 && code <= 0x1f) || code === 0x7f) continue
      cleaned += c
    }
    return cleaned
  }

  private tokenizeChineseChars(text: string): string {
    let out = ''
    for (const c of text) {
      const code = c.codePointAt(0)!
      if (isCjk(code)) out += ` ${c} `
      else out += c
    }
    return out
  }

  private runSplitOnPunc(token: string, out: string[]): void {
    let startNew = true
    for (const c of token) {
      const isPunc = !isAlnumChar(c)
      if (isPunc) {
        out.push(c)
        startNew = true
      } else if (startNew) {
        out.push(c)
        startNew = false
      } else {
        out[out.length - 1]! += c
      }
    }
  }

  private basicTokenize(text: string): string[] {
    const cleaned = this.cleanText(text)
    const spaced = this.tokenizeChineseChars(cleaned)
    const words = spaced.split(/\s+/u).filter(Boolean)
    const out: string[] = []
    for (const w of words) this.runSplitOnPunc(w, out)
    return out
  }

  /** WordPiece：首 piece 原 token，后续 ## 前缀；任一字缺失 → null（整体 [UNK]） */
  private wordPiece(token: string): string[] | null {
    if (this.vocab.has(token)) return [token]
    if ([...token].length > 100) return null
    const chars = [...token]
    const subTokens: string[] = []
    let start = 0
    while (start < chars.length) {
      let end = chars.length
      let cur: string | null = null
      while (start < end) {
        const sub = (start > 0 ? '##' : '') + chars.slice(start, end).join('')
        if (this.vocab.has(sub)) { cur = sub; break }
        end--
      }
      if (cur === null) return null
      subTokens.push(cur)
      start = end
    }
    return subTokens
  }

  encode(text: string): BertEncoding {
    const ids: number[] = [this.clsId]
    const mask: number[] = [1]
    const types: number[] = [0]
    for (const token of this.basicTokenize(text)) {
      const pieces = this.wordPiece(token)
      if (pieces === null) {
        ids.push(this.unkId); mask.push(1); types.push(0)
      } else {
        for (const p of pieces) {
          const id = this.vocab.get(p)!
          ids.push(id); mask.push(1); types.push(0)
        }
      }
      if (ids.length >= this.maxLen - 1) break // 预留 [SEP]
    }
    ids.push(this.sepId); mask.push(1); types.push(0)
    while (ids.length < this.maxLen) { ids.push(this.padId); mask.push(0); types.push(0) }
    return { inputIds: ids, attentionMask: mask, tokenTypeIds: types }
  }

  /** 调试：输出 token 序列（[CLS]…[SEP] 不含 padding） */
  debugTokens(text: string): string[] {
    const { inputIds } = this.encode(text)
    const idToToken = new Map<string, string>()
    for (const [t, id] of this.vocab) idToToken.set(String(id), t)
    const out: string[] = []
    for (const id of inputIds) {
      const tok = idToToken.get(String(id))
      if (tok === undefined || tok === '[PAD]') break
      out.push(tok)
    }
    return out
  }
}
