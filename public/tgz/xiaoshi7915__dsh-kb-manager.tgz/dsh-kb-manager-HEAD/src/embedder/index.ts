/**
 * Embedding 工厂（DESIGN §5.2）：按 provider 构造；onnx 默认，其余可选。
 * 组合磁盘缓存（sha256(model|provider|dim|text)）。
 */
import type { KbConfig } from '../contracts/types.ts'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import type { Embedder } from './embedder.ts'
import { EMBED_BATCH, embedKey } from './embedder.ts'
import { EmbeddingCache } from './cache.ts'
import { MockNgramEmbedder } from './mock.ts'
import { OnnxEmbedder } from './onnx.ts'
import { OpenAiCompatEmbedder } from './openai-compat.ts'

export type { Embedder } from './embedder.ts'
export type EmbedderFactory = (cfg: KbConfig, storagePath: string) => Promise<Embedder>

export const embedderFactory: EmbedderFactory = async (cfg, storagePath) => {
  let base: Embedder
  switch (cfg.embedding.provider) {
    case 'onnx':
      base = new OnnxEmbedder(`${storagePath}/models/onnx`)
      break
    case 'openai-compat':
      if (!cfg.embedding.base_url) {
        throw new KbError(ErrorCodes.CFG_EMBEDDING_NOT_CONFIGURED, 'openai-compat 需要 embedding.base_url')
      }
      base = new OpenAiCompatEmbedder({
        baseUrl: cfg.embedding.base_url,
        apiKeyRef: cfg.embedding.api_key_ref,
        model: cfg.embedding.model,
        dim: 512,
      })
      break
    case 'mock': {
      // dev/test only：3-gram 哈希弱语义向量，驱动管线测试
      base = new MockNgramEmbedder(512)
      break
    }
    case 'ollama':
      base = new OpenAiCompatEmbedder({
        baseUrl: cfg.embedding.base_url || 'http://127.0.0.1:11434/v1',
        apiKeyRef: '',
        model: cfg.embedding.model,
        dim: 512,
      })
      break
    default:
      throw new KbError(ErrorCodes.CFG_KEY_INVALID, `unknown embedding provider: ${String(cfg.embedding.provider)}`)
  }
  return withCache(base, `${storagePath}/cache/embedding`)
}

/** 开发/测试入口：mock provider 显式声明（不出现在生产配置里） */
export function devEmbedder(dim = 512): Embedder {
  return withCache(new MockNgramEmbedder(dim), '/tmp/kb-manager-dev-cache')
}

function withCache(base: Embedder, cacheDir: string): Embedder {
  const id = base.identity()
  const cache = new EmbeddingCache(cacheDir)
  return {
    identity: () => base.identity(),
    async embed(texts: string[], signal?: AbortSignal): Promise<number[][]> {
      const keys = texts.map((t) => embedKey(id.model, id.provider, id.dim, t))
      const { cached, misses } = cache.probe(keys, id.dim)
      if (misses.length === 0) return cached.map((c) => Array.from(c!))
      const toEmbed = misses.map((i) => texts[i]!)
      // 批量 32，逐批缓存回写
      for (let i = 0; i < toEmbed.length; i += EMBED_BATCH) {
        const batch = toEmbed.slice(i, i + EMBED_BATCH)
        const vecs = await base.embed(batch, signal)
        batch.forEach((t, j) => {
          const idx = misses[i + j]!
          cache.set(keys[idx]!, vecs[j]!)
          cached[idx] = new Float32Array(vecs[j]!)
        })
      }
      return cached.map((c) => Array.from(c!))
    },
  }
}
