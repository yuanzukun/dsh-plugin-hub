/**
 * 开发/测试用 embedding：字符 3-gram 哈希到固定维度 + L2 归一化。
 * 提供真实的（弱）语义相似度——相同词/短语重叠度越高余弦越大，
 * 足以驱动检索管线测试与 eval 骨架；生产路径用 OnnxEmbedder。
 */
import { createHash } from 'node:crypto'
import type { EmbeddingIdentity } from '../contracts/types.ts'
import type { Embedder } from './embedder.ts'

export class MockNgramEmbedder implements Embedder {
  constructor(private readonly dim = 512) {}
  identity(): EmbeddingIdentity {
    return { model: 'mock', provider: 'mock', dim: this.dim }
  }
  async embed(texts: string[], _signal?: AbortSignal): Promise<number[][]> {
    return texts.map((t) => this.encode(t))
  }
  private encode(text: string): number[] {
    const v = new Array<number>(this.dim).fill(0)
    const s = text.toLowerCase().replace(/\s+/g, ' ')
    for (let i = 0; i + 3 <= s.length; i++) {
      const h = createHash('sha256').update(s.slice(i, i + 3)).digest()
      const idx = (h[0]! << 8 | h[1]!) % this.dim
      v[idx]! += 1
    }
    // 单词整体哈希（提升整词匹配权重）
    for (const w of s.split(' ')) {
      if (w.length < 2) continue
      const h = createHash('sha256').update('w:' + w).digest()
      const idx = (h[0]! << 8 | h[1]!) % this.dim
      v[idx]! += 2
    }
    const norm = Math.sqrt(v.reduce((a, b) => a + b * b, 0)) || 1
    return v.map((x) => x / norm)
  }
}
