/**
 * URL 导入（DESIGN §8.2）：SSRF guard + 大小限 + 抓取缓存。
 */
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import { safeFetch } from '../security/ssrf-guard.ts'

export interface FetchResult {
  text: string
  finalUrl: string
  fromCache: boolean
}

/** 白名单内抓取；缓存 key = sha256(规范化 URL) */
export async function fetchUrl(
  url: string,
  cacheDir: string,
  opts: { allowlist?: string[]; maxBytes?: number; timeoutMs?: number } = {},
): Promise<FetchResult> {
  const maxBytes = opts.maxBytes ?? 100 * 1024 * 1024
  let u: URL
  try {
    u = new URL(url)
  } catch {
    throw new KbError(ErrorCodes.SEC_URL_DENIED, `非法 URL: ${url}`)
  }
  const normalized = `${u.protocol}//${u.host}${u.pathname}${u.search}`
  const key = createHash('sha256').update(normalized).digest('hex')
  const cachePath = join(cacheDir, 'fetch', key + '.html')
  if (existsSync(cachePath)) {
    return { text: readFileSync(cachePath, 'utf8'), finalUrl: normalized, fromCache: true }
  }
  const res = await safeFetch(url, { allowlist: opts.allowlist, timeoutMs: opts.timeoutMs ?? 60000 })
  if (!res.ok) {
    throw new KbError(ErrorCodes.SEC_URL_DENIED, `抓取失败: HTTP ${res.status}`, '目标返回非 2xx；确认 URL 可公开访问')
  }
  const text = await res.text()
  if (text.length * 4 > maxBytes) {
    throw new KbError(ErrorCodes.DOC_TOO_LARGE, '页面内容超过大小限制', '选择内容更小的页面')
  }
  mkdirSync(join(cacheDir, 'fetch'), { recursive: true })
  writeFileSync(cachePath, text)
  return { text, finalUrl: res.url || normalized, fromCache: false }
}
