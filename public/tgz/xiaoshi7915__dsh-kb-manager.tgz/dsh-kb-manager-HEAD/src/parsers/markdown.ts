/**
 * Markdown 解析器：heading 层级 / 段落 / 表格（GFM）。
 * 表格转 Markdown 表格文本（供 chunker 整表/按行切，DESIGN §5.1）。
 */
import type { ParsedBlock, ParsedDoc } from '../contracts/types.ts'

export function parseMarkdown(text: string, fileName: string): ParsedDoc {
  const blocks: ParsedBlock[] = []
  const lines = text.split('\n')
  let i = 0
  let para: string[] = []
  const flushPara = () => {
    const t = para.join('\n').trim()
    if (t) blocks.push({ kind: 'para', text: t })
    para = []
  }
  while (i < lines.length) {
    const line = lines[i]!
    const h = line.match(/^(#{1,6})\s+(.*)$/)
    if (h) {
      flushPara()
      blocks.push({ kind: 'heading', level: h[1]!.length, text: h[2]!.trim() })
      i++
      continue
    }
    // 表格：当前行含 | 且下一行是分隔行 |---|
    if (line.includes('|') && i + 1 < lines.length && /^\s*\|?[\s:|-]+\|[\s:|-]*$/.test(lines[i + 1]!) && lines[i + 1]!.includes('-')) {
      flushPara()
      const tbl: string[] = []
      while (i < lines.length && lines[i]!.includes('|')) {
        tbl.push(lines[i]!)
        i++
      }
      const md = tbl.join('\n')
      const rows = tbl.length - 2
      const cols = (tbl[0]!.match(/\|/g)?.length ?? 1) - 1
      blocks.push({ kind: 'table', markdown: md, rows: Math.max(0, rows), cols: Math.max(0, cols) })
      continue
    }
    if (line.trim() === '') {
      flushPara()
      i++
      continue
    }
    para.push(line)
    i++
  }
  flushPara()
  return { source_type: 'md', file_name: fileName, blocks }
}
