/**
 * 解析器注册表（DESIGN §3.1：统一 parse()→ParsedDoc 边界）。
 * PDF/DOCX：MVP 先标记为暂不可解析（parser 接入 pdfjs-dist / mammoth 在实现期，见 §12）。
 */
import type { ParsedDoc } from '../contracts/types.ts'
import { KbError, ErrorCodes } from '../contracts/errors.ts'
import { parseMarkdown } from './markdown.ts'
import { parseTxt } from './txt.ts'
import { parseCsv } from './csv.ts'
import { parseJson } from './json.ts'
import { parseHtml } from './html.ts'

export interface Parser {
  parse(text: string, fileName: string): ParsedDoc
}

export const parsers: Record<string, Parser> = {
  md: { parse: (t, f) => parseMarkdown(t, f) },
  markdown: { parse: (t, f) => parseMarkdown(t, f) },
  txt: { parse: (t, f) => parseTxt(t, f) },
  text: { parse: (t, f) => parseTxt(t, f) },
  csv: { parse: (t, f) => parseCsv(t, f, 50) },
  json: { parse: (t, f) => parseJson(t, f) },
  html: { parse: (t, f) => parseHtml(t, f) },
  htm: { parse: (t, f) => parseHtml(t, f) },
}

export function extOf(fileName: string): string {
  const i = fileName.lastIndexOf('.')
  return i < 0 ? '' : fileName.slice(i + 1).toLowerCase()
}

export function isSupported(fileName: string, sourceType?: string): boolean {
  const ext = extOf(fileName)
  if (parsers[ext]) return true
  if (sourceType && parsers[sourceType]) return true
  return false
}

/** 解析入口；不支持的类型抛 DOC.UNSUPPORTED_TYPE（doc-service 转 unparseable 处理） */
export function parseDocument(text: string, fileName: string, sourceType?: string): ParsedDoc {
  const ext = extOf(fileName)
  const p = parsers[ext] ?? (sourceType ? parsers[sourceType] : undefined)
  if (!p) {
    throw new KbError(
      ErrorCodes.DOC_UNSUPPORTED_TYPE,
      `不支持的文件类型: .${ext || '?'}`,
      'MVP 支持 md/txt/csv/json/html；pdf/docx 解析器接入中（或先转文本再导入）',
    )
  }
  try {
    return p.parse(text, fileName)
  } catch (e) {
    if (e instanceof KbError) throw e
    throw new KbError(
      ErrorCodes.DOC_PARSE_FAILED,
      `解析失败: ${(e as Error).message}`,
      '文档格式异常；可尝试人工清洗后重新导入',
    )
  }
}
