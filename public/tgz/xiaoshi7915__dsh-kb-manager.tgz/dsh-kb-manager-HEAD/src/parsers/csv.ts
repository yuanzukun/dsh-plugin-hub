/**
 * CSV 解析器（DESIGN §5.1）：每 csv_rows_per_chunk 行一块 + 表头重复。
 * 实现为：整表按行切成 para 块（每块 = 表头 + N 行，Markdown 表格表达），
 * 行数分块由 chunker 的 table 单元逻辑统一处理——此处按行组产出 table 块。
 */
import type { ParsedBlock, ParsedDoc } from '../contracts/types.ts'

/** 极简 CSV 行解析（支持双引号转义） */
export function parseCsvLine(line: string): string[] {
  const out: string[] = []
  let cur = ''
  let inQ = false
  for (let i = 0; i < line.length; i++) {
    const ch = line[i]!
    if (inQ) {
      if (ch === '"') {
        if (line[i + 1] === '"') {
          cur += '"'
          i++
        } else inQ = false
      } else cur += ch
    } else if (ch === '"') {
      inQ = true
    } else if (ch === ',') {
      out.push(cur)
      cur = ''
    } else cur += ch
  }
  out.push(cur)
  return out.map((s) => s.trim())
}

export function parseCsv(text: string, fileName: string, rowsPerChunk = 50): ParsedDoc {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0)
  if (lines.length === 0) return { source_type: 'csv', file_name: fileName, blocks: [] }
  const header = parseCsvLine(lines[0]!)
  const rows = lines.slice(1).map(parseCsvLine)
  const blocks: ParsedBlock[] = []
  const toTable = (rowsGroup: string[][]): string => {
    const md = [
      header.map((h) => h || ' ').join(' | '),
      header.map(() => '---').join(' | '),
      ...rowsGroup.map((r) => r.map((c) => c || ' ').join(' | ')),
    ]
    return md.join('\n')
  }
  for (let i = 0; i < rows.length; i += rowsPerChunk) {
    const group = rows.slice(i, i + rowsPerChunk)
    blocks.push({ kind: 'table', markdown: toTable(group), rows: group.length, cols: header.length })
  }
  return { source_type: 'csv', file_name: fileName, blocks }
}
