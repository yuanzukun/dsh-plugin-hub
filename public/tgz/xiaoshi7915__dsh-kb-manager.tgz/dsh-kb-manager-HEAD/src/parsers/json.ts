/**
 * JSON 解析器（DESIGN §5.1）：递归拍平为 "path: value" 行后按段落切块。
 */
import type { ParsedBlock, ParsedDoc } from '../contracts/types.ts'

function flatten(obj: unknown, prefix: string, out: string[], depth = 0): void {
  if (depth > 8) {
    out.push(`${prefix}: ${JSON.stringify(obj)}`)
    return
  }
  if (obj === null || typeof obj !== 'object') {
    out.push(`${prefix}: ${String(obj)}`)
    return
  }
  if (Array.isArray(obj)) {
    obj.forEach((v, i) => flatten(v, `${prefix}[${i}]`, out, depth + 1))
    return
  }
  for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
    flatten(v, prefix ? `${prefix}.${k}` : k, out, depth + 1)
  }
}

export function parseJson(text: string, fileName: string): ParsedDoc {
  let data: unknown
  try {
    data = JSON.parse(text)
  } catch (e) {
    throw new Error(`JSON parse failed: ${(e as Error).message}`)
  }
  const lines: string[] = []
  flatten(data, '', lines)
  // 每 50 行一段（与 CSV 块大小同量级）
  const blocks: ParsedBlock[] = []
  for (let i = 0; i < lines.length; i += 50) {
    blocks.push({ kind: 'para', text: lines.slice(i, i + 50).join('\n') })
  }
  return { source_type: 'json', file_name: fileName, blocks }
}
