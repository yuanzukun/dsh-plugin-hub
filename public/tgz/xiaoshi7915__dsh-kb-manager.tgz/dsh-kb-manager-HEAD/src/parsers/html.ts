/**
 * 最小 HTML → 文本（MVP）：去 script/style、块级标签换行、解码实体。
 * 升级路径：换 turndown 获得标题/表格结构（v1.1 评估）。
 */
import type { ParsedBlock, ParsedDoc } from '../contracts/types.ts'

const ENTITIES: Record<string, string> = {
  '&nbsp;': ' ', '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&#39;': "'",
}

export function htmlToText(html: string): string {
  let s = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<head[\s\S]*?<\/head>/gi, ' ')
  s = s.replace(/<br\s*\/?>/gi, '\n')
  s = s.replace(/<\/(p|div|h[1-6]|li|tr|table|section|article|header|footer)>/gi, '\n')
  s = s.replace(/<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/gi, (_m, lvl: string, inner: string) => {
    return `\n${'#'.repeat(Number(lvl))} ${inner.trim()}\n`
  })
  s = s.replace(/<[^>]+>/g, ' ')
  s = s.replace(/&#(\d+);/g, (_m, n: string) => String.fromCodePoint(Number(n)))
  s = s.replace(/&[a-z]+;/g, (m) => ENTITIES[m] ?? ' ')
  return s.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim()
}

export function parseHtml(html: string, fileName: string): ParsedDoc {
  // 粗转成 markdown 形态后交给 markdown 解析器（保留 heading 结构）
  // 复用 markdown 解析避免重复实现
  const text = htmlToText(html)
  const blocks: ParsedBlock[] = []
  const lines = text.split('\n')
  let para: string[] = []
  const flush = () => {
    const t = para.join('\n').trim()
    if (t) blocks.push({ kind: 'para', text: t })
    para = []
  }
  for (const line of lines) {
    const h = line.match(/^(#{1,6})\s+(.*)$/)
    if (h) {
      flush()
      blocks.push({ kind: 'heading', level: h[1]!.length, text: h[2]!.trim() })
      continue
    }
    if (line.trim() === '') {
      flush()
      continue
    }
    para.push(line)
  }
  flush()
  return { source_type: 'html', file_name: fileName, blocks }
}
