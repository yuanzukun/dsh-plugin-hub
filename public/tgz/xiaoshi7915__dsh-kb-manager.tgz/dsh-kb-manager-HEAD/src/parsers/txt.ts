/**
 * 纯文本解析器：按空行分段。
 */
import type { ParsedBlock, ParsedDoc } from '../contracts/types.ts'

export function parseTxt(text: string, fileName: string): ParsedDoc {
  const blocks: ParsedBlock[] = []
  for (const part of text.split(/\n\s*\n/)) {
    const t = part.trim()
    if (t) blocks.push({ kind: 'para', text: t })
  }
  return { source_type: 'txt', file_name: fileName, blocks }
}
