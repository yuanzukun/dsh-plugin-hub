/**
 * 中文 BM25 通道（DESIGN §5.3 + 拍板⑥'）。
 * - 分词：Intl.Segmenter（granularity 'word'，零依赖、无 node-gyp）
 * - 入库前预分词写入 chunks.bm25_text（空格分隔），FTS5 用 unicode61 分词器索引空格串
 * - 纯 JS BM25 评分器供测试/降级使用；生产查询走 FTS5 bm25() 排名
 * - 若评测显示 BM25 路明显拖后腿 → 换 jieba-wasm（仍不碰 native）
 */

const seg = new Intl.Segmenter('zh', { granularity: 'word' })

/** 预分词：输出空格分隔的小写 token 串（写 chunks.bm25_text 与查询前共用） */
export function tokenizeZh(text: string): string[] {
  const out: string[] = []
  for (const s of seg.segment(text)) {
    if (!s.isWordLike) continue
    const t = s.segment.toLowerCase()
    if (t.length === 0) continue
    out.push(t)
  }
  return out
}

export function tokenizeForFts(text: string): string {
  return tokenizeZh(text).join(' ')
}

/** 查询词：去重保序（FTS5 查询串 / JS 评分共用） */
export function queryTokens(text: string): string[] {
  const seen = new Set<string>()
  const out: string[] = []
  for (const t of tokenizeZh(text)) {
    if (!seen.has(t)) {
      seen.add(t)
      out.push(t)
    }
  }
  return out
}

export interface Bm25Params {
  k1?: number
  b?: number
}

/**
 * 内存 BM25 评分器（k1=1.5, b=0.75）。
 * 生产路径用 FTS5 的 bm25()；此实现用于单测、降级路径与 eval 对齐。
 */
export class InMemoryBm25 {
  private df = new Map<string, number>()
  private tf = new Map<string, Map<string, number>>() // docId → term → freq
  private docLen = new Map<string, number>()
  private N = 0
  private avgdl = 0
  private readonly k1: number
  private readonly b: number

  constructor(params: Bm25Params = {}) {
    this.k1 = params.k1 ?? 1.5
    this.b = params.b ?? 0.75
  }

  addDoc(docId: string, tokens: string[]): void {
    if (this.tf.has(docId)) return // 幂等
    this.N += 1
    this.docLen.set(docId, tokens.length)
    const per = new Map<string, number>()
    for (const t of tokens) per.set(t, (per.get(t) ?? 0) + 1)
    for (const [t, c] of per) {
      if (c > 0) this.df.set(t, (this.df.get(t) ?? 0) + 1)
    }
    this.tf.set(docId, per)
    this.avgdl = [...this.docLen.values()].reduce((a, b) => a + b, 0) / this.N
  }

  removeDoc(docId: string): void {
    const per = this.tf.get(docId)
    if (!per) return
    const len = this.docLen.get(docId) ?? 0
    for (const [t, c] of per) {
      if (c > 0) this.df.set(t, (this.df.get(t) ?? 0) - 1)
    }
    this.tf.delete(docId)
    this.docLen.delete(docId)
    this.N = Math.max(0, this.N - 1)
    if (this.N > 0) this.avgdl = [...this.docLen.values()].reduce((a, b) => a + b, 0) / this.N
    else this.avgdl = 0
  }

  search(query: string[], topN = 10): Array<{ id: string; score: number }> {
    const out: Array<{ id: string; score: number }> = []
    for (const [id, per] of this.tf) {
      let score = 0
      for (const q of query) {
        const f = per.get(q)
        if (!f) continue
        const df = this.df.get(q) ?? 0
        const idf = Math.log(1 + (this.N - df + 0.5) / (df + 0.5))
        const dl = this.docLen.get(id) ?? 0
        score += idf * ((f * (this.k1 + 1)) / (f + this.k1 * (1 - this.b + (this.b * dl) / (this.avgdl || 1))))
      }
      if (score > 0) out.push({ id, score })
    }
    out.sort((a, b) => b.score - a.score)
    return out.slice(0, topN)
  }
}
