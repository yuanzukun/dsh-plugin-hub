/**
 * Rerank 接口（DESIGN §5.4，引擎 v1.1 交付）。
 * MVP 提供 NoopReranker：显式降级为 RRF-only（rerank: 'fallback_rrf'），绝不静默。
 */
import type { RerankStatus } from '../contracts/types.ts'

export interface RerankCandidate {
  chunk_id: string
  text: string
}

export interface Reranker {
  /** 触发加载（下载模型/建 session）；不可用/失败时应静默（applyRerank 据此降级） */
  ensureReady(): Promise<void>
  /** 引擎是否可用（模型已加载/已下载） */
  available(): boolean
  /** 返回降序排序后的 [{chunk_id, score}]，score ∈ [0,1]（ONNX 推理异步） */
  rerank(query: string, candidates: RerankCandidate[], topN: number): Promise<Array<{ chunk_id: string; score: number }>>
}

export class NoopReranker implements Reranker {
  async ensureReady(): Promise<void> {}
  available(): boolean {
    return false
  }
  rerank(): never {
    throw new Error('rerank engine not loaded (v1.1); caller must check available() first')
  }
}

export interface RerankOutcome {
  status: RerankStatus
  ranked: Array<{ chunk_id: string; score: number; score_kind: 'rerank' | 'rrf' }>
}

/**
 * 统一降级出口：
 * - enable_rerank=false            → 'disabled'（用户配置，不提示异常）
 * - 引擎不可用                      → 'fallback_rrf'（显式降级，UI 黄灯 + "重排序不可用"）
 * - 引擎可用且打分成功              → 'applied'
 */
export async function applyRerank(
  enableRerank: boolean,
  reranker: Reranker,
  query: string,
  candidates: RerankCandidate[],
  topK: number,
  minScore: number,
  rrfFallback: Array<{ chunk_id: string; score: number }>,
): Promise<RerankOutcome> {
  if (!enableRerank) {
    return {
      status: 'disabled',
      ranked: rrfFallback.slice(0, topK).map((c) => ({ chunk_id: c.chunk_id, score: c.score, score_kind: 'rrf' as const })),
    }
  }
  // 先触发加载（下载模型/建 session）；失败静默 → available()=false → 显式降级 fallback_rrf
  try {
    await reranker.ensureReady()
  } catch {
    // 引擎不可用（未下载/加载失败/OOM）→ 走下方降级
  }
  if (!reranker.available()) {
    return {
      status: 'fallback_rrf',
      ranked: rrfFallback.slice(0, topK).map((c) => ({ chunk_id: c.chunk_id, score: c.score, score_kind: 'rrf' as const })),
    }
  }
  const ranked = (await reranker.rerank(query, candidates, topK * 2))
    .filter((r) => r.score >= minScore)
    .slice(0, topK)
    return {
      status: 'applied',
      ranked: ranked.length > 0 ? ranked.map((r) => ({ ...r, score_kind: 'rerank' as const })) : rrfFallback.slice(0, topK).map((c) => ({ chunk_id: c.chunk_id, score: c.score, score_kind: 'rrf' as const })),
    }
}
