/**
 * RRF 融合（DESIGN §5.3/§5.6）：score = Σ 1/(k + rank)，k 默认 60。
 * 只消费各路"有界初筛 top-K"的序，零跨库/跨模型可比性问题。
 */
export interface RankedIds {
  ids: string[] // 按该路相关性降序
  scores?: number[] // 可选的原始分（仅调试透传用）
}

export function rrfFusion(lists: RankedIds[], k = 60): Map<string, number> {
  const acc = new Map<string, number>()
  for (const list of lists) {
    list.ids.forEach((id, i) => {
      const rank = i + 1
      acc.set(id, (acc.get(id) ?? 0) + 1 / (k + rank))
    })
  }
  return acc
}

export function topFromMap(map: Map<string, number>, n: number): Array<[string, number]> {
  return [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, n)
}

/** 展示分归一化：top-1 = 1.0（DESIGN §5.6） */
export function normalizeForDisplay(scored: Array<[string, number]>): Map<string, number> {
  if (scored.length === 0) return new Map()
  const max = scored[0]![1]
  if (max <= 0) return new Map(scored.map(([id]) => [id, 0]))
  return new Map(scored.map(([id, s]) => [id, s / max]))
}
