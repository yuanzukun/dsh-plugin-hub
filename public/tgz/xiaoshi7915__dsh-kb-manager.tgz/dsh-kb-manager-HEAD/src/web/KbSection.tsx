/**
 * 知识库设置页（settings.section 'kb-manager'）。
 *
 * 纯 React + 内联样式（主题变量 --dsw-alias-*，回退中性色）。
 * 数据面全部走 remote.kbManager（host 侧 KbManagerRemote）。
 * props：owner share（close）+ inject face（kb / t），由 slot 渲染器展开注入。
 */
import { Fragment, useCallback, useEffect, useRef, useState } from 'react'
import type { CSSProperties } from 'react'
import type {
  DocInfo,
  DocChunkItem,
  Envelope,
  Job,
  KbListItem,
  KbMeta,
  SearchResponse,
} from '../contracts/types.ts'
import type {
  DeleteKbDone,
  DeleteKbPending,
  KbRemoteApi,
  KbStats,
  RestorePending,
  SnapshotData,
} from '../remote-types.ts'
import type { KbLocaleKey } from './locales.ts'

export interface KbSectionInjected {
  /** 取 remote.kbManager 命名空间句柄（挂载期已 $mount）。 */
  kb: () => KbRemoteApi
  /** 取 remote.directoryPicker（宿主原生目录选择器；未挂载时为 undefined）。 */
  pickDir: () => DirPickerRemote | undefined
  /** 本命名空间翻译函数（locale 切换时经壳层重注册保持新鲜）。 */
  t: (key: KbLocaleKey) => string
}

/**
 * DSH 系统 remote 命名空间 remote.directoryPicker（宿主原生选择器）。
 * 仅声明本插件实际使用的 pick()；运行时不 import 任何 @deepseek-ai 客户端包。
 */
export interface DirPickerRemote {
  pick(): Promise<{ ok: boolean; value?: string | null; error?: { code?: string; message?: string } }>
}

export type KbSectionProps = { close: () => void } & KbSectionInjected

// ---------- 样式（主题变量 + 回退） ----------

const c = {
  text: 'var(--dsw-alias-label-primary, #1f2328)',
  text2: 'var(--dsw-alias-label-secondary, #61666b)',
  text3: 'var(--dsw-alias-label-tertiary, #81858c)',
  border: 'var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.35))',
  bgSubtle: 'var(--dsw-alias-bg-subtle, rgba(127, 127, 127, 0.08))',
  danger: '#cf222e',
  accent: 'var(--dsw-alias-brand-primary, #0f1115)',
}

const S: Record<string, CSSProperties> = {
  root: { display: 'flex', flexDirection: 'column', gap: 16, padding: '4px 0', color: c.text, fontSize: 14 },
  head: { display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' },
  h1: { margin: 0, fontSize: 18, fontWeight: 600 },
  sub: { color: c.text3, fontSize: 13 },
  btn: {
    border: `1px solid ${c.border}`, background: 'transparent', color: c.text,
    borderRadius: 6, padding: '6px 12px', cursor: 'pointer', fontSize: 13,
  },
  btnPrimary: {
    border: `1px solid ${c.accent}`, background: c.accent, color: '#fff',
    borderRadius: 6, padding: '6px 12px', cursor: 'pointer', fontSize: 13,
  },
  btnDanger: {
    border: `1px solid ${c.danger}`, background: 'transparent', color: c.danger,
    borderRadius: 6, padding: '6px 12px', cursor: 'pointer', fontSize: 13,
  },
  btnSmall: {
    border: `1px solid ${c.border}`, background: 'transparent', color: c.text2,
    borderRadius: 5, padding: '2px 8px', cursor: 'pointer', fontSize: 12,
  },
  card: { border: `1px solid ${c.border}`, borderRadius: 8, padding: 12 },
  row: {
    display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px',
    border: `1px solid ${c.border}`, borderRadius: 8, cursor: 'pointer',
  },
  rowName: { fontWeight: 500, flex: 1 },
  badge: { fontSize: 12, color: c.text3, whiteSpace: 'nowrap' },
  input: {
    border: `1px solid ${c.border}`, borderRadius: 6, padding: '6px 10px',
    fontSize: 13, background: 'transparent', color: c.text, width: '100%', boxSizing: 'border-box',
  },
  label: { fontSize: 12, color: c.text3, marginBottom: 4, display: 'block' },
  table: { width: '100%', borderCollapse: 'collapse', fontSize: 13 },
  th: { textAlign: 'left', color: c.text3, fontWeight: 500, fontSize: 12, padding: '4px 8px', borderBottom: `1px solid ${c.border}` },
  td: { padding: '6px 8px', borderBottom: `1px solid ${c.border}`, verticalAlign: 'top' },
  err: { color: c.danger, fontSize: 13 },
  ok: { color: '#1a7f37', fontSize: 13 },
  hit: { border: `1px solid ${c.border}`, borderRadius: 8, padding: 10, display: 'flex', flexDirection: 'column', gap: 4 },
  hitMeta: { fontSize: 12, color: c.text3 },
  hitText: { whiteSpace: 'pre-wrap', lineHeight: 1.5 },
  stat: { display: 'flex', gap: 18, flexWrap: 'wrap', fontSize: 13, color: c.text2 },
  bar: { background: c.bgSubtle, borderRadius: 8, padding: '10px 12px', fontSize: 13 },
  danger: { border: `1px solid ${c.danger}`, borderRadius: 8, padding: 12, display: 'flex', flexDirection: 'column', gap: 10 },
  confirm: { display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', fontSize: 13 },
  empty: { color: c.text3, fontSize: 13, padding: '8px 0' },
  muted: { color: c.text3, fontSize: 12 },
  cardTitle: { fontSize: 13, fontWeight: 600, color: c.text, marginBottom: 10 },
  kvs: { display: 'flex', flexDirection: 'column', gap: 6, fontSize: 13, color: c.text2 },
  kvsRow: { display: 'flex', justifyContent: 'space-between', gap: 8 },
  kvsKey: { color: c.text3 },
  kvsVal: { textAlign: 'right', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  railTitle: { fontSize: 13, fontWeight: 600, color: c.text, marginBottom: 10 },
}

// ---------- 工具 ----------

/** RemoteResult → Envelope 双层错误 → 展示文本 */
function failureText(t: (k: KbLocaleKey) => string, r: { ok: boolean; value?: Envelope<unknown>; error?: { code: string; message: string } }): string | null {
  if (!r.ok) return `${r.error?.code ?? 'REMOTE'}: ${r.error?.message ?? 'remote call failed'}`
  const env = r.value
  if (env && 'ok' in env && !env.ok) return `${t('error')} ${env.error.code}: ${env.error.message}${env.error.hint ? `（${t('hint')}: ${env.error.hint}）` : ''}`
  return null
}

function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / 1024 / 1024).toFixed(1)} MB`
}

function fmtTime(iso: string): string {
  try {
    return new Date(iso).toLocaleString()
  } catch {
    return iso
  }
}

const STATUS_LABEL: Record<string, KbLocaleKey | undefined> = {
  importing: 'statusImporting', ok: 'statusOk', unparseable: 'statusUnparseable',
  failed: 'statusFailed', deleted: 'statusDeleted',
  building: 'statusImporting',
}

/** 文档 / KB 状态 → 展示文本（无词条时回退原始值）。 */
function statusLabel(t: (k: KbLocaleKey) => string, s: string): string {
  const key = STATUS_LABEL[s]
  return key ? t(key) : s
}

// ---------- 子组件 ----------

function JobBanner({ t, job }: { t: (k: KbLocaleKey) => string; job: Job }) {
  const terminal = job.status === 'done' || job.status === 'failed' || job.status === 'cancelled'
  const pct = job.progress.total > 0 ? Math.round((job.progress.done / job.progress.total) * 100) : 0
  return (
    <div style={S.bar}>
      <div>
        {t('job')}: {job.type} — {job.status}
        {!terminal && ` ${pct}%（${job.progress.stage_label} ${job.progress.done}/${job.progress.total}）`}
      </div>
      {job.status === 'failed' && job.error && (
        <div style={S.err}>{job.error.code}: {job.error.message}{job.error.hint ? `（${t('hint')}: ${job.error.hint}）` : ''}</div>
      )}
    </div>
  )
}

// ---------- 主组件 ----------

export function KbSection({ kb, t }: KbSectionProps) {
  const api = kb()
  const [view, setView] = useState<'list' | 'create' | 'detail'>('list')
  const [kbs, setKbs] = useState<KbListItem[]>([])
  const [listState, setListState] = useState<'loading' | 'ready' | 'error'>('loading')
  const [listError, setListError] = useState<string | null>(null)
  const [selected, setSelected] = useState<KbMeta | null>(null)
  const [stats, setStats] = useState<KbStats | null>(null)
  const [docs, setDocs] = useState<DocInfo[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<SearchResponse | null>(null)
  const [searchError, setSearchError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [activeJob, setActiveJob] = useState<Job | null>(null)
  const [pendingKbDelete, setPendingKbDelete] = useState<DeleteKbPending | null>(null)
  const [pendingDocDelete, setPendingDocDelete] = useState<DocInfo | null>(null)
  const [notice, setNotice] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null)
  const [importPath, setImportPath] = useState('')
  const [snapshots, setSnapshots] = useState<SnapshotData[]>([])
  const [pendingRestore, setPendingRestore] = useState<RestorePending & { snapshot_id: string } | null>(null)
  const [snapNote, setSnapNote] = useState('')
  const reloadRef = useRef<(() => void) | null>(null)
  const [expandedDoc, setExpandedDoc] = useState<string | null>(null)
  const [docChunks, setDocChunks] = useState<DocChunkItem[] | null>(null)
  const [chunksLoading, setChunksLoading] = useState(false)

  const flash = useCallback((kind: 'ok' | 'err', text: string) => {
    setNotice({ kind, text })
    window.setTimeout(() => setNotice(null), 6000)
  }, [])

  // ---------- KB 列表 ----------
  const loadKbs = useCallback(async () => {
    setListState('loading')
    // list 描述符含 3 个 wire 参数（domain_tag/limit/offset，均可选）：
    // Gateway 按 parameters.length 校验实参个数，可选参数也必须显式传 undefined。
    const r = await api.list(undefined, undefined, undefined)
    const fail = failureText(t, r)
    if (fail || !r.ok || !r.value.ok) {
      setListState('error')
      setListError(fail ?? 'list failed')
      return
    }
    setKbs(r.value.data.kbs)
    setListState('ready')
  }, [api, t])

  useEffect(() => { void loadKbs() }, [loadKbs])

  // ---------- 详情 ----------
  const loadDetail = useCallback(async (kbId: string) => {
    const [d, s, doc, snap] = await Promise.all([
      api.detail(kbId), api.stats(kbId), api.docs(kbId, undefined, 100, 0), api.listSnapshots(kbId, undefined, undefined),
    ])
    const fail = failureText(t, d) ?? failureText(t, s) ?? failureText(t, doc) ?? failureText(t, snap)
    if (fail) {
      flash('err', fail)
      return
    }
    if (d.ok && d.value.ok) setSelected(d.value.data)
    if (s.ok && s.value.ok) setStats(s.value.data)
    if (doc.ok && doc.value.ok) setDocs(doc.value.data.docs)
    if (snap.ok && snap.value.ok) setSnapshots(snap.value.data.snapshots)
  }, [api, t, flash])

  const openDetail = useCallback((kbId: string) => {
    setView('detail')
    setSelected(null)
    setStats(null)
    setDocs([])
    setSnapshots([])
    setPendingRestore(null)
    setSearchResults(null)
    setSearchError(null)
    setNotice(null)
    void loadDetail(kbId)
  }, [loadDetail])

  // 让 job 完成后能刷新详情（reloadRef 避免 effect 依赖抖动）
  reloadRef.current = selected ? () => void loadDetail(selected.kb_id) : loadKbs

  // ---------- 任务轮询 ----------
  useEffect(() => {
    if (!activeJob) return
    if (activeJob.status === 'done' || activeJob.status === 'failed' || activeJob.status === 'cancelled') return
    const timer = window.setInterval(async () => {
      const r = await api.job(activeJob.job_id)
      const fail = failureText(t, r)
      if (fail || !r.ok || !r.value.ok) return
      const j = r.value.data
      setActiveJob(j)
      if (j.status === 'done' || j.status === 'failed' || j.status === 'cancelled') {
        void reloadRef.current?.()
      }
    }, 1000)
    return () => window.clearInterval(timer)
  }, [activeJob, api, t])

  // ---------- 操作 ----------
  const doCreate = useCallback(async (name: string, description: string, tags: string[]) => {
    setBusy(true)
    try {
      const r = await api.create(name, description || undefined, tags.length ? tags : undefined)
      const fail = failureText(t, r)
      if (fail || !r.ok || !r.value.ok) {
        flash('err', fail ?? 'create failed')
        return
      }
      flash('ok', `${name}`)
      await loadKbs()
      openDetail(r.value.data.kb_id)
    } finally {
      setBusy(false)
    }
  }, [api, t, flash, loadKbs, openDetail])

  const doImport = useCallback(async () => {
    if (!selected) return
    const source = importPath.trim()
    if (!source) {
      flash('err', t('importEmpty'))
      return
    }
    setBusy(true)
    try {
      const r = await api.importDoc(selected.kb_id, source, undefined)
      const fail = failureText(t, r)
      if (fail || !r.ok || !r.value.ok) {
        flash('err', fail ?? 'import failed')
        return
      }
      setImportPath('')
      setActiveJob({
        job_id: r.value.data.job_id,
        type: 'import',
        kb_id: selected.kb_id,
        status: 'queued',
        progress: { done: 0, total: 1, stage: 'reading', stage_label: 'queued' },
        created_at: new Date().toISOString(),
      })
    } finally {
      setBusy(false)
    }
  }, [api, t, selected, importPath, flash])

  /** 浏览器文件选择 → FileReader 读文本 → importText 上传宿主导入（同机场景）。 */
  const doUploadFile = useCallback(async (file: File | undefined) => {
    if (!selected || !file) return
    if (file.size > 5 * 1024 * 1024) {
      flash('err', t('fileTooLarge'))
      return
    }
    const ext = (file.name.split('.').pop() || 'txt').toLowerCase()
    const sourceType = ['md', 'markdown', 'txt', 'text', 'csv', 'json', 'html', 'htm'].includes(ext) ? ext : 'txt'
    setBusy(true)
    try {
      const text = await file.text()
      const r = await api.importText(selected.kb_id, file.name, sourceType, text, undefined, undefined)
      const fail = failureText(t, r)
      if (fail || !r.ok || !r.value.ok) {
        flash('err', fail ?? 'import failed')
        return
      }
      const res = r.value.data
      flash('ok', `${file.name} → ${t('imported')} (${res.chunk_count})`)
      void loadDetail(selected.kb_id)
    } catch {
      flash('err', t('pickFailed'))
    } finally {
      setBusy(false)
    }
  }, [api, t, selected, flash, loadDetail])

  const doSearch = useCallback(async () => {
    if (!selected || !searchQuery.trim()) return
    setBusy(true)
    try {
      const r = await api.search(selected.kb_id, searchQuery.trim(), undefined)
      const fail = failureText(t, r)
      if (fail || !r.ok || !r.value.ok) {
        setSearchError(fail ?? 'search failed')
        return
      }
      setSearchError(null)
      setSearchResults(r.value.data)
    } finally {
      setBusy(false)
    }
  }, [api, t, selected, searchQuery])

  /** 展开/收起文档的分块列表（点击“查看分块”）。 */
  const toggleChunks = useCallback(async (doc: DocInfo) => {
    if (!selected) return
    if (expandedDoc === doc.doc_id) {
      setExpandedDoc(null)
      setDocChunks(null)
      return
    }
    setExpandedDoc(doc.doc_id)
    setDocChunks(null)
    setChunksLoading(true)
    try {
      const r = await api.listDocChunks(selected.kb_id, doc.doc_id)
      const fail = failureText(t, r)
      if (fail || !r.ok || !r.value.ok) {
        flash('err', fail ?? 'list chunks failed')
        setExpandedDoc(null)
        return
      }
      setDocChunks(r.value.data)
    } finally {
      setChunksLoading(false)
    }
  }, [api, t, selected, flash, expandedDoc])

  const doRebuild = useCallback(async () => {
    if (!selected) return
    const r = await api.rebuild(selected.kb_id, undefined)
    const fail = failureText(t, r)
    if (fail || !r.ok || !r.value.ok) {
      flash('err', fail ?? 'rebuild failed')
      return
    }
    setActiveJob({
      job_id: r.value.data.job_id,
      type: 'rebuild',
      kb_id: selected.kb_id,
      status: 'queued',
      progress: { done: 0, total: 1, stage: 'reading', stage_label: 'queued' },
      created_at: new Date().toISOString(),
    })
  }, [api, t, selected, flash])

  const askDeleteKb = useCallback(async () => {
    if (!selected) return
    // deleteKb 描述符含 2 个 wire 参数（kb_id + 可选 confirm_token）
    const r = await api.deleteKb(selected.kb_id, undefined)
    const fail = failureText(t, r)
    if (fail || !r.ok || !r.value.ok) {
      flash('err', fail ?? 'delete failed')
      return
    }
    if ((r.value.data as DeleteKbPending).requires_confirm) {
      setPendingKbDelete(r.value.data as DeleteKbPending)
    } else {
      flash('ok', t('deleted'))
      setPendingKbDelete(null)
      setView('list')
      setSelected(null)
      void loadKbs()
    }
  }, [api, t, selected, flash, loadKbs])

  const confirmDeleteKb = useCallback(async () => {
    if (!selected || !pendingKbDelete) return
    setBusy(true)
    try {
      const r = await api.deleteKb(selected.kb_id, pendingKbDelete.confirm_token)
      const fail = failureText(t, r)
      if (fail || !r.ok || !r.value.ok) {
        flash('err', fail ?? 'delete failed')
        return
      }
      setPendingKbDelete(null)
      flash('ok', t('deleted'))
      setView('list')
      setSelected(null)
      void loadKbs()
    } finally {
      setBusy(false)
    }
  }, [api, t, selected, pendingKbDelete, flash, loadKbs])

  const doDeleteDoc = useCallback(async (doc: DocInfo) => {
    if (!selected) return
    const r = await api.deleteDoc(selected.kb_id, doc.doc_id)
    const fail = failureText(t, r)
    if (fail || !r.ok || !r.value.ok) {
      flash('err', fail ?? 'delete failed')
      return
    }
    setPendingDocDelete(null)
    flash('ok', `${doc.file_name} ${t('deleted')}`)
    void loadDetail(selected.kb_id)
  }, [api, t, selected, flash, loadDetail])

  // ---------- 快照（v1.1） ----------
  const doCreateSnapshot = useCallback(async () => {
    if (!selected) return
    setBusy(true)
    try {
      const r = await api.createSnapshot(selected.kb_id, snapNote.trim() || undefined)
      const fail = failureText(t, r)
      if (fail || !r.ok || !r.value.ok) {
        flash('err', fail ?? 'create snapshot failed')
        return
      }
      setSnapNote('')
      flash('ok', t('snapCreated'))
      void loadDetail(selected.kb_id)
    } finally {
      setBusy(false)
    }
  }, [api, t, selected, snapNote, flash, loadDetail])

  const askRestore = useCallback(async (snap: SnapshotData) => {
    if (!selected) return
    const r = await api.restoreSnapshot(selected.kb_id, snap.snapshot_id, undefined)
    const fail = failureText(t, r)
    if (fail || !r.ok || !r.value.ok) {
      flash('err', fail ?? 'restore failed')
      return
    }
    const d = r.value.data as RestorePending
    if (d.requires_confirm) {
      setPendingRestore({ ...d, snapshot_id: snap.snapshot_id })
    }
  }, [api, t, selected, flash])

  const confirmRestore = useCallback(async () => {
    if (!selected || !pendingRestore) return
    setBusy(true)
    try {
      const r = await api.restoreSnapshot(selected.kb_id, pendingRestore.snapshot_id, pendingRestore.confirm_token)
      const fail = failureText(t, r)
      if (fail || !r.ok || !r.value.ok) {
        flash('err', fail ?? 'restore failed')
        return
      }
      setPendingRestore(null)
      const job = r.value.data as { job_id: string; status: 'queued' }
      setActiveJob({
        job_id: job.job_id,
        type: 'restore',
        kb_id: selected.kb_id,
        status: 'queued',
        progress: { done: 0, total: 1, stage: 'restoring', stage_label: 'queued' },
        created_at: new Date().toISOString(),
      })
    } finally {
      setBusy(false)
    }
  }, [api, t, selected, pendingRestore, flash])

  // ---------- 渲染 ----------

  if (view === 'create') {
    return <CreateForm t={t} busy={busy} notice={notice} onCancel={() => setView('list')} onCreate={doCreate} />
  }

  if (view === 'detail' && selected) {
    return (
      <div style={S.root}>
        <div style={S.head}>
          <button type="button" style={S.btnSmall} onClick={() => { setView('list'); void loadKbs() }}>{t('back')}</button>
          <h1 style={{ ...S.h1, fontSize: 16 }}>{selected.name}</h1>
          <span style={S.badge}>{statusLabel(t, selected.status)}</span>
          <span style={S.badge}>{selected.embedding.model} / {selected.embedding.provider} / {selected.embedding.dim}d</span>
        </div>
        {notice && <div style={notice.kind === 'ok' ? S.ok : S.err}>{notice.text}</div>}
        {activeJob && <JobBanner t={t} job={activeJob} />}

        {/* 检索（置顶全宽） */}
        <div style={S.card}>
          <div style={S.cardTitle}>{t('searchSection')}</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              style={{ ...S.input, flex: 1 }}
              placeholder={t('searchPh')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') void doSearch() }}
            />
            <button type="button" style={S.btnPrimary} disabled={busy || !searchQuery.trim()} onClick={() => void doSearch()}>
              {t('search')}
            </button>
          </div>
          {searchError && <div style={{ ...S.err, marginTop: 8 }}>{searchError}</div>}
          {searchResults && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 10 }}>
              <div style={S.hitMeta}>
                {searchResults.results.length} hits · rerank={t(searchResults.rerank === 'applied' ? 'rerankApplied' : searchResults.rerank === 'fallback_rrf' ? 'rerankRrf' : 'rerankDisabled')} · {searchResults.elapsed_ms}ms
              </div>
              {searchResults.results.length === 0 && <div style={S.empty}>{t('noResults')}</div>}
              {searchResults.results.map((h) => (
                <div key={h.chunk_id} style={S.hit}>
                  <div style={S.hitMeta}>
                    score {h.score.toFixed(3)} · {h.source_doc}{h.page_num ? ` · p${h.page_num}` : ''}{h.heading_path ? ` · ${h.heading_path}` : ''}
                  </div>
                  <div style={S.hitText}>{h.text}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 主体：文档列表 + 右侧信息/导入/维护栏 */}
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'flex-start' }}>
          <div style={{ flex: '1 1 380px', minWidth: 0, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={S.card}>
              <div style={S.cardTitle}>{t('docsSection')}</div>
              {docs.length === 0 ? (
                <div style={S.empty}>{t('noDocs')}</div>
              ) : (
                <table style={S.table}>
                  <thead>
                    <tr>
                      <th style={S.th}>{t('docFile')}</th>
                      <th style={S.th}>{t('docStatus')}</th>
                      <th style={S.th}>{t('docChunks')}</th>
                      <th style={S.th}>{t('docImported')}</th>
                      <th style={S.th} />
                    </tr>
                  </thead>
                  <tbody>
                    {docs.map((d) => (
                      <Fragment key={d.doc_id}>
                        <tr>
                          <td style={{ ...S.td, maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={d.file_name}>{d.file_name}</td>
                          <td style={S.td}>{statusLabel(t, d.status)}</td>
                          <td style={S.td}>{d.chunk_count}</td>
                          <td style={S.td}>{fmtTime(d.imported_at)}</td>
                          <td style={{ ...S.td, textAlign: 'right', whiteSpace: 'nowrap' }}>
                            {d.status !== 'deleted' && (
                              <button type="button" style={S.btnSmall} onClick={() => void toggleChunks(d)}>
                                {expandedDoc === d.doc_id ? t('hideChunks') : t('viewChunks')}
                              </button>
                            )}
                            {pendingDocDelete?.doc_id === d.doc_id ? (
                              <span style={S.confirm}>
                                {t('confirmDeleteDoc')}
                                <button type="button" style={S.btnDanger} onClick={() => void doDeleteDoc(d)}>{t('confirm')}</button>
                                <button type="button" style={S.btnSmall} onClick={() => setPendingDocDelete(null)}>{t('cancel')}</button>
                              </span>
                            ) : (
                              d.status !== 'deleted' && (
                                <button type="button" style={S.btnSmall} onClick={() => setPendingDocDelete(d)}>{t('deleteDoc')}</button>
                              )
                            )}
                          </td>
                        </tr>
                        {expandedDoc === d.doc_id && (
                          <tr>
                            <td colSpan={5} style={S.td}>
                              {chunksLoading ? (
                                <div style={S.muted}>{t('loading')}</div>
                              ) : docChunks === null ? (
                                <div style={S.muted}>{t('noChunks')}</div>
                              ) : docChunks.length === 0 ? (
                                <div style={S.empty}>{t('noChunks')}</div>
                              ) : (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                  {docChunks.map((c) => (
                                    <div key={c.chunk_id} style={{ ...S.hit, fontSize: 12 }}>
                                      <div style={S.hitMeta}>
                                        #{c.ord} · {c.token_count} tokens{c.heading_path ? ` · ${c.heading_path}` : ''}{c.page_num != null ? ` · p${c.page_num}` : ''}
                                      </div>
                                      <div style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{c.text}</div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                      </Fragment>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            {/* 快照历史（v1.1） */}
            <div style={S.card}>
              <div style={{ ...S.cardTitle, display: 'flex', alignItems: 'center', gap: 8 }}>
                {t('snapshotsSection')}
                <span style={S.badge}>{snapshots.length}</span>
              </div>
              <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
                <input
                  style={{ ...S.input, flex: 1 }}
                  placeholder={t('snapNotePh')}
                  value={snapNote}
                  onChange={(e) => setSnapNote(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') void doCreateSnapshot() }}
                />
                <button type="button" style={S.btnPrimary} disabled={busy} onClick={() => void doCreateSnapshot()}>
                  {t('snapCreate')}
                </button>
              </div>
              {snapshots.length === 0 ? (
                <div style={S.empty}>{t('noSnapshots')}</div>
              ) : (
                <table style={S.table}>
                  <thead>
                    <tr>
                      <th style={S.th}>{t('snapTime')}</th>
                      <th style={S.th}>{t('snapNotePh').replace('（可选）', '')}</th>
                      <th style={S.th}>{t('snapDocs')}</th>
                      <th style={S.th}>{t('snapSize')}</th>
                      <th style={S.th} />
                    </tr>
                  </thead>
                  <tbody>
                    {snapshots.map((snap) => (
                      <tr key={snap.snapshot_id}>
                        <td style={{ ...S.td, whiteSpace: 'nowrap' }}>{fmtTime(snap.created_at)}</td>
                        <td style={{ ...S.td, maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={snap.note ?? ''}>{snap.note ?? ''}</td>
                        <td style={S.td}>{snap.doc_count}</td>
                        <td style={S.td}>{fmtBytes(snap.size_bytes)}</td>
                        <td style={{ ...S.td, textAlign: 'right', whiteSpace: 'nowrap' }}>
                          {pendingRestore?.snapshot_id === snap.snapshot_id ? (
                            <span style={S.confirm}>
                              <span>
                                {t('confirmRestore')} {t('snapImpact').replace('{docs}', String(pendingRestore.impact.restored_docs))
                                  .replace('{chunks}', String(pendingRestore.impact.removed_chunks))
                                  .replace('{bytes}', fmtBytes(pendingRestore.impact.freed_bytes))}
                              </span>
                              <button type="button" style={S.btnDanger} disabled={busy} onClick={() => void confirmRestore()}>{t('confirm')}</button>
                              <button type="button" style={S.btnSmall} onClick={() => setPendingRestore(null)}>{t('cancel')}</button>
                            </span>
                          ) : (
                            <button type="button" style={S.btnSmall} disabled={busy} onClick={() => void askRestore(snap)}>{t('snapRestore')}</button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          <div style={{ flex: '0 1 260px', display: 'flex', flexDirection: 'column', gap: 16, minWidth: 220 }}>
            <div style={S.card}>
              <div style={S.railTitle}>{t('infoSection')}</div>
              {stats && (
                <div style={S.kvs}>
                  <div style={S.kvsRow}><span style={S.kvsKey}>{t('statsDocs')}</span><span style={S.kvsVal}>{stats.doc_count}</span></div>
                  <div style={S.kvsRow}><span style={S.kvsKey}>{t('statsChunks')}</span><span style={S.kvsVal}>{stats.chunk_count}</span></div>
                  <div style={S.kvsRow}><span style={S.kvsKey}>{t('statsSize')}</span><span style={S.kvsVal}>{fmtBytes(stats.index_size_bytes)}</span></div>
                  <div style={S.kvsRow}><span style={S.kvsKey}>{t('statsEmbedding')}</span><span style={S.kvsVal}>{selected.embedding.model} / {selected.embedding.provider} / {selected.embedding.dim}d</span></div>
                </div>
              )}
            </div>

            <div style={S.card}>
              <div style={S.railTitle}>{t('importTitle')}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <input
                  style={S.input}
                  placeholder={t('importPath')}
                  value={importPath}
                  onChange={(e) => setImportPath(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') void doImport() }}
                />
                <div style={{ display: 'flex', gap: 8 }}>
                  <button type="button" style={{ ...S.btnPrimary, flex: 1 }} disabled={busy} onClick={() => void doImport()}>
                    {t('importBtn')}
                  </button>
                </div>
                <div style={S.muted}>{t('importHint')}</div>
                <label style={{ ...S.btn, flex: 1, textAlign: 'center', cursor: 'pointer', display: 'block' }}>
                  {t('browseFile')}
                  <input
                    type="file"
                    style={{ display: 'none' }}
                    accept=".md,.markdown,.txt,.csv,.json,.html,.htm"
                    disabled={busy || !selected}
                    onChange={(e) => { const f = e.target.files?.[0]; void doUploadFile(f); e.target.value = '' }}
                  />
                </label>
              </div>
            </div>

            <div style={S.danger}>
              <div style={S.railTitle}>{t('danger')}</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <button type="button" style={S.btn} disabled={busy} onClick={() => void doRebuild()}>{t('rebuild')}</button>
                {!pendingKbDelete && (
                  <button type="button" style={S.btnDanger} disabled={busy} onClick={() => void askDeleteKb()}>{t('deleteKb')}</button>
                )}
              </div>
              {pendingKbDelete && (
                <div style={S.confirm}>
                  <span>
                    {t('confirmDeleteKb')} {t('impact').replace('{docs}', String(pendingKbDelete.impact.docs))
                      .replace('{chunks}', String(pendingKbDelete.impact.chunks))
                      .replace('{bytes}', fmtBytes(pendingKbDelete.impact.bytes))}
                  </span>
                  <button type="button" style={S.btnDanger} disabled={busy} onClick={() => void confirmDeleteKb()}>{t('confirm')}</button>
                  <button type="button" style={S.btnSmall} onClick={() => setPendingKbDelete(null)}>{t('cancel')}</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    )
  }

  // list 视图
  return (
    <div style={S.root}>
      <div style={S.head}>
        <h1 style={S.h1}>{t('title')}</h1>
        <span style={S.sub}>{t('subtitle')}</span>
        <button type="button" style={S.btnPrimary} onClick={() => setView('create')}>{t('newKb')}</button>
      </div>
      {notice && <div style={notice.kind === 'ok' ? S.ok : S.err}>{notice.text}</div>}
      {activeJob && <JobBanner t={t} job={activeJob} />}
      {listState === 'loading' && <div style={S.empty}>{t('loading')}</div>}
      {listState === 'error' && <div style={S.err}>{listError}</div>}
      {listState === 'ready' && kbs.length === 0 && (
        <div style={S.empty}>{t('empty')}</div>
      )}
      {listState === 'ready' && kbs.map((k) => (
        <div key={k.kb_id} style={S.row} onClick={() => openDetail(k.kb_id)}>
          <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <span style={{ ...S.rowName, display: 'flex', alignItems: 'center', gap: 8 }}>
              {k.name}
              <span style={{ ...S.badge, border: `1px solid ${c.border}`, borderRadius: 4, padding: '0 6px' }}>{statusLabel(t, k.index_status)}</span>
            </span>
            <span style={S.badge}>{k.doc_count} {t('statsDocs')} · {fmtTime(k.last_updated)}</span>
          </div>
          <span style={{ color: c.text3 }}>›</span>
        </div>
      ))}
    </div>
  )
}

// ---------- 建库表单 ----------

function CreateForm({
  t, busy, notice, onCancel, onCreate,
}: {
  t: (k: KbLocaleKey) => string
  busy: boolean
  notice: { kind: 'ok' | 'err'; text: string } | null
  onCancel: () => void
  onCreate: (name: string, description: string, tags: string[]) => Promise<void>
}) {
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [tags, setTags] = useState('')

  return (
    <div style={S.root}>
      <div style={S.head}>
        <button type="button" style={S.btnSmall} onClick={onCancel}>{t('back')}</button>
        <h1 style={{ ...S.h1, fontSize: 16 }}>{t('newKb')}</h1>
      </div>
      {notice && <div style={notice.kind === 'ok' ? S.ok : S.err}>{notice.text}</div>}
      <div style={S.card}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div>
            <label style={S.label}>{t('kbName')}</label>
            <input style={S.input} value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <label style={S.label}>{t('kbDesc')}</label>
            <input style={S.input} value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div>
            <label style={S.label}>{t('kbTags')}</label>
            <input style={S.input} value={tags} onChange={(e) => setTags(e.target.value)} />
          </div>
          <div>
            <button
              type="button"
              style={S.btnPrimary}
              disabled={busy || !name.trim()}
              onClick={() => void onCreate(name.trim(), description.trim(),
                tags.split(/[,，]/).map((s) => s.trim()).filter(Boolean))}
            >
              {t('create')}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
