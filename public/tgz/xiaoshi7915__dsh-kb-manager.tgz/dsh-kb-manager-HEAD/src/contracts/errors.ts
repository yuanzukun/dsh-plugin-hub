/**
 * 三层错误码 + 统一信封（DESIGN §7.1）。
 * 错误码以 DESIGN v2.1 附录 C docstring 中出现的形式为权威拼写。
 */
import type { Envelope, ToolError } from './types.ts'

export const ErrorCodes = {
  CFG_EMBEDDING_NOT_CONFIGURED: 'CFG.EMBEDDING.NOT_CONFIGURED',
  CFG_KEY_INVALID: 'CFG.KEY.INVALID',
  KB_NOT_FOUND: 'KB.NOT_FOUND',
  KB_NAME_CONFLICT: 'KB_NAME_CONFLICT',
  KB_BUSY: 'KB.BUSY',
  DOC_NOT_FOUND: 'DOC.NOT_FOUND',
  DOC_TOO_LARGE: 'DOC.TOO_LARGE',
  DOC_UNSUPPORTED_TYPE: 'DOC.UNSUPPORTED_TYPE',
  DOC_PARSE_FAILED: 'DOC.PARSE_FAILED',
  SEC_PATH_DENIED: 'SEC.PATH.DENIED',
  SEC_URL_DENIED: 'SEC.URL.DENIED',
  SEC_CONFIRM_REQUIRED: 'SEC.CONFIRM_REQUIRED',
  EMB_MODEL_UNREACHABLE: 'EMB.MODEL_UNREACHABLE',
  EMB_DIMENSION_MISMATCH: 'EMB.DIMENSION_MISMATCH',
  EMB_NOT_READY: 'EMB.NOT_READY',
  IDX_NOT_READY: 'IDX.NOT_READY',
  IDX_CORRUPT: 'IDX.CORRUPT',
  IDX_ENGINE_BUSY: 'IDX.ENGINE_BUSY',
  SRCH_BAD_FILTER: 'SRCH.BAD_FILTER',
  SRCH_TOPK_OUT_OF_RANGE: 'SRCH.TOPK_OUT_OF_RANGE',
  JOB_NOT_FOUND: 'JOB.NOT_FOUND',
  JOB_ALREADY_TERMINAL: 'JOB.ALREADY_TERMINAL',
  JOB_INTERRUPTED: 'JOB.INTERRUPTED',
  FS_DISK_FULL: 'FS.DISK_FULL',
  FS_IO: 'FS.IO',
} as const

export type ErrorCode = (typeof ErrorCodes)[keyof typeof ErrorCodes]

/** retryable 标注供 Agent 决策（DESIGN §7.1 表） */
const RETRYABLE: ReadonlySet<string> = new Set([
  ErrorCodes.EMB_MODEL_UNREACHABLE,
  ErrorCodes.KB_BUSY,
  ErrorCodes.IDX_NOT_READY,
  ErrorCodes.IDX_ENGINE_BUSY,
  ErrorCodes.JOB_INTERRUPTED,
  ErrorCodes.FS_DISK_FULL,
  ErrorCodes.FS_IO,
])

export class KbError extends Error {
  readonly code: string
  readonly hint?: string
  constructor(code: string, message: string, hint?: string) {
    super(message)
    this.name = 'KbError'
    this.code = code
    if (hint !== undefined) this.hint = hint
  }
  get retryable(): boolean {
    return RETRYABLE.has(this.code)
  }
  toToolError(): ToolError {
    return { code: this.code, message: this.message, hint: this.hint }
  }
}

export function ok<T>(data: T): Envelope<T> {
  return { ok: true, data }
}

/** 把任意异常归一为错误信封：KbError 保留 code/hint，其余归 FS.IO 兜底 */
export function err(e: unknown): Envelope<never> {
  if (e instanceof KbError) return { ok: false, error: e.toToolError() }
  const message = e instanceof Error ? e.message : String(e)
  return {
    ok: false,
    error: {
      code: ErrorCodes.FS_IO,
      message,
      hint: '操作未成功完成；若是偶发 IO 错误可重试一次，持续失败请检查存储路径可写性与磁盘空间',
    },
  }
}

/** 两步确认 token（DESIGN §8.4）：5 分钟有效，单用 */
export class ConfirmTokens {
  private readonly tokens = new Map<string, number>()
  constructor(private readonly ttlMs = 5 * 60 * 1000) {}
  issue(scope: string): string {
    const token = `${scope}:${Date.now()}:${Math.random().toString(36).slice(2, 10)}`
    this.tokens.set(token, Date.now() + this.ttlMs)
    return token
  }
  consume(token: string, scope: string): boolean {
    const exp = this.tokens.get(token)
    if (exp === undefined || !token.startsWith(`${scope}:`)) return false
    if (Date.now() > exp) {
      this.tokens.delete(token)
      return false
    }
    this.tokens.delete(token)
    return true
  }
}
