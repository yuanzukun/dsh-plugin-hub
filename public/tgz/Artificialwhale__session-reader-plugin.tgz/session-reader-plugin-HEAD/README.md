# dsh-session-reader

在 DSH 会话内**读取其他会话的内容**：消息、工具调用/结果、推理过程（thinking）、压缩前的原始事件流。支持 agent 工具调用与 `/sessions` 斜杠命令两种使用方式，所有读取都是**只读**且**有界**的。

> 由实际使用需求驱动开发：让一个会话里的 agent 能查阅别的会话（比如查另一个会话的上下文再继续讨论）。已在 DSH 0.1.0-rc.6 上验证。

## 功能

### agent 工具

- **`session_list`** — 列出未归档会话（id、标题、工作区、创建时间、预设），支持按 id/工作区过滤、`limit`、`includeArchived`
- **`session_read`** — 按 id 读取会话内容，4 种模式：
  - `io` — 用户/助手消息与工具调用/结果（默认）
  - `thinking` — 推理分块（reasoning chunks）
  - `surface` — 压缩后的当前模型可见消息
  - `raw` — 原始日志事件（含压缩前的事件）

### 斜杠命令（无需模型回合，直接输出）

- `/sessions list [query] [--limit N] [--archived]`
- `/sessions read <id> [io|thinking|surface|raw] [--query text] [--limit N]`

## 安装

```sh
# 从 npm
dsh plugin --profile web add dsh-session-reader

# 或从 GitHub
dsh plugin --profile web add github:Artificialwhale/session-reader-plugin

# 或本地目录
dsh plugin --profile web add /path/to/dsh-session-reader
```

本包声明了 `dsh.bundle`，安装后会自动追加进 `dsh.profile.bundles` 层栈并激活；重启 dsh 后生效。

## 使用示例

```sh
# 发现会话 id
/sessions list
/sessions list 爱丽丝 --limit 5

# 读取某个会话
/sessions read session-xxxx-xxxx io
/sessions read session-xxxx-xxxx thinking --limit 20
/sessions read session-xxxx-xxxx raw --query "step/start"
```

## 兼容性

- 纯 JS，无构建步骤、无原生依赖、无运行时依赖
- 依赖宿主提供的 `sessionQuery` 服务以及随 dsh 发行版自带的 `@deepseek-ai/dsh-tools`、`@deepseek-ai/dsh-llm`，**无需单独安装**
- 输出有截断保护：单条内容与总数都有上限，避免污染上下文

## License

MIT
