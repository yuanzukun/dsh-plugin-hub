/**
 * Mission Control main page.
 *
 * Panes live in stable portal hosts inside dynamic horizontal rows, so moving
 * a pane between rows preserves its conversation component and DOM. A row
 * that would overflow the available width moves its rightmost pane to a new
 * row, and a manual header drag can place a pane in any row. Panes with no
 * persisted size split their row's width evenly; each row scrolls horizontally
 * instead of auto-wrapping.
 * Panes are resizable through every edge and corner. Left-edge resizes
 * compensate the previous pane's width; top-edge resizes add a vertical
 * offset inside the row. A bottom-edge resize may grow past the current row:
 * the pane draws on top while dragging and the row height allocation below
 * gives way on commit, so taller panes squeeze the rows underneath instead of
 * being clamped at the row boundary.
 */
import React from 'react';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionFace, SessionListState } from '@deepseek-ai/dsh-api-session-controller/client';
import type { ModelDirectory } from '@deepseek-ai/dsh-client-ui-model-selection/client';
import { type PaneChatObservable, type PaneSessionStatusObservable } from './MiniChatPane.tsx';
import type { PermissionOption } from './PaneToolbar.tsx';
/** One host slash command surfaced in the pane input menu. */
export interface PaneCommand {
    readonly name: string;
    readonly description: string;
    readonly hint?: string;
}
/** Registration-side page face: resolves session services for panes. */
export interface MissionControlPageInjected {
    readonly getSession: (sessionId: string) => SessionFace | undefined;
    /**
     * Resolve one session's assembled Chat view.
     *
     * Absent on shells that predate the Conversation assembly; panes then render
     * their empty state instead of a transcript.
     */
    readonly getChat: (sessionId: string) => PaneChatObservable | undefined;
    /**
     * Session UI status source (pending approvals/plan review).
     *
     * Resolved lazily because it only exists on shells with the Session UI
     * layer; without it a pane simply never shows the open-in-main hint.
     */
    readonly getSessionStatus: () => PaneSessionStatusObservable | undefined;
    readonly getModelDirectory: (sessionId: string) => ModelDirectory | undefined;
    readonly listCommands: (sessionId: string) => Promise<readonly PaneCommand[]>;
    /** Process-wide permission preset catalog shared by every pane toolbar. */
    readonly listPermissionOptions: () => Promise<readonly PermissionOption[]>;
    readonly openInMain: (sessionId: string) => void;
}
/** Props supplied by either the legacy main-page or official overlay adapter. */
export interface MissionControlPageProps extends MissionControlPageInjected {
    readonly useSessions: SnapshotSelectorHook<SessionListState>;
}
/** Mission Control page with a row-based pane layout. */
export declare function MissionControlPage({ useSessions, getSession, getChat, getSessionStatus, getModelDirectory, listCommands, listPermissionOptions, openInMain, }: MissionControlPageProps): React.JSX.Element;
