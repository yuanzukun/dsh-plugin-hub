import { defineConfig } from 'tsdown'

// Self-contained git-install build: no project references, no type checking —
// pnpm runs this through `prepare` after fetching sources from a git host.
export default defineConfig({
  entry: ['src/index.ts', 'src/bridge.ts', 'src/mh.ts', 'src/mh-ui.ts', 'src/estimate.ts'],
  format: ['esm'],
  dts: false,
  sourcemap: false,
  clean: true,
  outDir: 'lib',
  external: [/^@deepseek-ai\//],
})
