/**
 * Context-share estimation for `mh_load`: how much of the model's context
 * window a loaded memory pack occupies, and the resulting session total.
 *
 * Both inputs come from the session's own durable log when possible: the
 * newest `request/context` event carries the adapter-advertised context
 * window, and the newest `assistant/message` usage carries the last request's
 * measured input size. The token count of the memory pack itself uses mh's
 * own heuristic (~4 chars per token) so the estimate agrees with `mh ui`.
 */

import type { Agent } from '@deepseek-ai/dsh-agent'

/** One context-share estimate for a loaded memory pack. */
export interface ContextShare {
  /** Context window used as the denominator. */
  readonly windowTokens: number
  /** Where the window came from: the model adapter's report, or plugin config. */
  readonly windowSource: 'adapter' | 'config'
  /** Estimated tokens of the loaded memory pack. */
  readonly memoryTokens: number
  /** memoryTokens as a percentage of the window. */
  readonly memoryPercent: number
  /** Last request's measured input tokens, when the session has one. */
  readonly currentTokens?: number
  /** (current + memory) as a percentage of the window, when current is known. */
  readonly totalPercent?: number
}

/** mh's density heuristic: ~4 characters per token. */
export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4)
}

/**
 * Estimate the share for a memory pack in this agent's session. Without an
 * agent (detached execution) only the config-window memory share is available.
 */
export function contextShare(
  agent: Agent | undefined,
  memoryText: string,
  fallbackWindowTokens: number,
): ContextShare {
  let windowTokens = fallbackWindowTokens
  let windowSource: ContextShare['windowSource'] = 'config'
  let currentTokens: number | undefined
  if (agent !== undefined) {
    for (const event of [...agent.session.events].reverse()) {
      if (windowSource === 'adapter' && currentTokens !== undefined) break
      if (windowSource !== 'adapter'
        && event.type === 'request/context'
        && event.data.contextWindow !== undefined) {
        windowTokens = event.data.contextWindow
        windowSource = 'adapter'
      }
      if (currentTokens === undefined
        && event.type === 'assistant/message'
        && event.data.usage !== undefined) {
        currentTokens = event.data.usage.inputTokens
      }
    }
  }
  const memoryTokens = estimateTokens(memoryText)
  const memoryPercent = (memoryTokens / windowTokens) * 100
  const totalPercent = currentTokens === undefined
    ? undefined
    : ((currentTokens + memoryTokens) / windowTokens) * 100
  return {
    windowTokens,
    windowSource,
    memoryTokens,
    memoryPercent,
    ...currentTokens === undefined ? {} : { currentTokens },
    ...totalPercent === undefined ? {} : { totalPercent },
  }
}

/** Render one estimate as a compact model-facing annotation line. */
export function renderShare(share: ContextShare): string {
  const source = share.windowSource === 'adapter' ? 'adapter-reported' : 'configured'
  const head = `[memoryhub] memory ≈ ${share.memoryTokens.toLocaleString('en-US')} tokens`
    + ` ≈ ${share.memoryPercent.toFixed(1)}% of the ${share.windowTokens.toLocaleString('en-US')}-token context window (${source})`
  return share.totalPercent === undefined
    ? head
    : `${head}; session total after load ≈ ${share.totalPercent.toFixed(1)}%`
}
