/**
 * Transcript bridge: render the live dsh session's durable event log as a
 * pi-format JSONL transcript, so the stock `mh` CLI can purify or compact
 * this session through its existing `--transcript` path.
 *
 * mh owns every parsing decision downstream; this module only emits clean
 * user/assistant text records, one per durable event:
 *
 *   {"type":"message","timestamp":"…","message":{"role":"user","content":[{"type":"text","text":"…"}]}}
 *
 * Identity: mh's pi naming rule takes the filename stem after the first `_`
 * as the session id, so the file is `dsh_<session-id>.jsonl` and every save
 * of one dsh session replaces the previous representation instead of
 * duplicating it.
 */

import { mkdirSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type { Agent } from '@deepseek-ai/dsh-agent'

/** One emitted JSONL record in pi's transcript schema. */
interface PiRecord {
  readonly type: 'message'
  readonly timestamp: string
  readonly message: {
    readonly role: 'user' | 'assistant'
    readonly content: readonly [{ readonly type: 'text'; readonly text: string }]
  }
}

/** Join the text blocks of one message; non-text blocks do not purify. */
function textOf(content: readonly { readonly type: string }[]): string {
  const parts: string[] = []
  for (const block of content) {
    if (block.type === 'text' && typeof (block as { text?: unknown }).text === 'string') {
      const text = (block as unknown as { text: string }).text
      if (text.length > 0) parts.push(text)
    }
  }
  return parts.join('\n').trim()
}

/**
 * An mh load invocation, however it reached the CLI — matched by CALL SHAPE,
 * never by mere mention: diagnostic commands that grep for `mh load` in file
 * contents must not arm the drop. A direct `mh_load` tool call; a
 * `run_code` block calling `tools.mh_load(…)` (the web GUI's path) or
 * running `mh load` as a shell command; a `bash` call whose command runs
 * `mh load`. The shell pattern anchors on command position (start of the
 * command or after a separator) with a backslash lookbehind so escaped
 * `\|` inside grep patterns does not count as a pipe separator.
 */
const MH_LOAD_TOOL_REF = /tools\s*\.\s*(?:mh_load|\[\s*['"]mh_load['"]\s*\])\s*\(/
const MH_LOAD_SHELL = /(?:^|(?<!\\)(?:&&|;|\||\n)\s*)mh\s+load\b/
/** Only a real `mh load` prints one of these; grep/edit output never does. */
const MH_LOAD_RECEIPT = /<!--\s*mh\s*\|\s*loaded:|\[memoryhub\] memory\s*≈|no sessions saved in the loaded checkpoints/

function isMhLoadCall(name: string, args: string): boolean {
  if (name === 'mh_load') return true
  if (name === 'run_code') return MH_LOAD_TOOL_REF.test(args) || MH_LOAD_SHELL.test(args)
  if (name === 'bash') return MH_LOAD_SHELL.test(args)
  return false
}

/**
 * Render the agent's session as pi-format JSONL. Only genuine user input
 * (`source.kind === 'user'`) and assistant text survive: plugin-injected
 * context (including this plugin's own `mh load` snapshot), tool results,
 * and reasoning stay out, matching what mh's purifier keeps for the agents
 * it discovers natively.
 *
 * Assistant text that follows an mh load is also dropped, until the next
 * genuine user message: that reply is the load receipt plus a digest of the
 * memory that was just loaded — content that already lives in the
 * checkpoints being loaded. Saving it would re-embed old memory into every
 * new session and snowball from there. The user's own request line stays
 * (it is genuine input); mh's purifier renders the dangling turn as
 * "(no textual reply captured)".
 */
export function sessionToJsonl(agent: Agent): string {
  const records: PiRecord[] = []
  let afterMhLoad = false
  /** Call-ids of shape-matched load candidates, awaiting their result. */
  const pendingLoads = new Set<string>()
  for (const event of agent.session.events) {
    if (event.type === 'tool/call') {
      const data = event.data as { name?: unknown; arguments?: unknown; callId?: unknown }
      const name = typeof data.name === 'string' ? data.name : ''
      const args = typeof data.arguments === 'string' ? data.arguments : ''
      const callId = typeof data.callId === 'string' ? data.callId : ''
      if (isMhLoadCall(name, args)) pendingLoads.add(callId)
      continue
    }
    if (event.type === 'tool/result') {
      const message = (event.data as { message?: unknown }).message as
        | { source?: { callId?: unknown }; content?: unknown }
        | undefined
      const callId = typeof message?.source?.callId === 'string' ? message.source.callId : ''
      // Two-key confirmation: the call looked like a load AND the result
      // carries mh's own load receipt. Mentions in edit/grep payloads fail
      // the second key, so they can never arm the drop.
      if (pendingLoads.delete(callId) && MH_LOAD_RECEIPT.test(JSON.stringify(message?.content ?? ''))) {
        afterMhLoad = true
      }
      continue
    }
    if (event.type === 'user/message') {
      const message = event.data
      if (message.source.kind !== 'user') continue
      afterMhLoad = false
      const text = textOf(message.content)
      if (text.length === 0) continue
      records.push({
        type: 'message',
        timestamp: new Date(event.time).toISOString(),
        message: { role: 'user', content: [{ type: 'text', text }] },
      })
    } else if (event.type === 'assistant/message') {
      if (afterMhLoad) continue
      const text = textOf(event.data.message.content)
      if (text.length === 0) continue
      records.push({
        type: 'message',
        timestamp: new Date(event.time).toISOString(),
        message: { role: 'assistant', content: [{ type: 'text', text }] },
      })
    }
  }
  return records.map(record => JSON.stringify(record)).join('\n') + (records.length > 0 ? '\n' : '')
}

export interface BridgeFile {
  /** Absolute path of the (re)written transcript. */
  readonly path: string
  /** Byte length of the written content. */
  readonly bytes: number
}

/**
 * Write (or atomically-enough rewrite) the bridge transcript for this agent
 * under the shared temp directory and return its location. The path is stable
 * per session, which is what keeps repeated saves under one mh identity.
 */
export function writeBridgeTranscript(agent: Agent): BridgeFile {
  const safeId = String(agent.id).replaceAll('/', '_').replaceAll('\\', '_')
  const dir = join(tmpdir(), 'dsh-memoryhub')
  mkdirSync(dir, { recursive: true })
  const path = join(dir, `dsh_${safeId}.jsonl`)
  const jsonl = sessionToJsonl(agent)
  writeFileSync(path, jsonl, 'utf8')
  return { path, bytes: Buffer.byteLength(jsonl) }
}
