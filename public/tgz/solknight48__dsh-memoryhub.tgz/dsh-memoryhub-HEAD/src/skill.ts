/**
 * The mh workflow skill, adapted for DeepSeek Harness. Registered at runtime
 * through `ctx.skills.register()` so it appears in the model's skill catalog
 * (and as the `/mh` user command) without any files on disk.
 *
 * Differences from MemoryHub's own Claude-Code skill:
 * - session-start `mh load` is performed by the plugin automatically;
 * - saving goes through the `mh_save` tool, which bridges the live dsh
 *   session into a transcript mh can purify (mh does not discover dsh
 *   session files itself);
 * - `mh import` backfills Claude Code / pi / Codex history only.
 */

export const SKILL_NAME = 'mh'

export const SKILL_DESCRIPTION =
  'Load and save project memory with MemoryHub: purified session contexts ' +
  'stored in .memoryhub/ checkpoints. Use at the start of work in a project ' +
  'containing .memoryhub/; when the user says "save/checkpoint this session", ' +
  '"保存上下文", "load memory", "pick up where we left off", "link checkpoints", ' +
  '"go back a stage", or asks to take over a project / import old sessions ' +
  '("接管项目", "导入历史会话"); and at session end to save the session.'

export const SKILL_CONTENT = `# MemoryHub workflow (DeepSeek Harness)

\`.memoryhub/\` is the project's context hub: **checkpoints** holding
**purified sessions**, versioned in the hub's own git repo and managed by the
\`mh\` CLI. Checkpoints are independent of each other; **linked** checkpoints
load together, their sessions merged in time order. This harness integrates
mh through the memoryhub plugin: the \`mh_load\` / \`mh_save\` / \`mh_status\` /
\`mh_list\` / \`mh_search\` / \`mh_checkpoint\` tools wrap the CLI, and anything
else (\`mh link\`, \`mh back\`, \`mh import\`, \`mh ui\`) runs in the shell.

## Session start
- The plugin runs \`mh load\` automatically and injects the output as prior
  project memory; the header says which checkpoints were included. Trust it
  over guessing; if it contradicts the code, the code wins.
- If no memory block is present (fresh project, or the plugin is configured
  not to auto-load) and the user asks for memory: call \`mh_load\`. It loads
  EVERY session in the selected checkpoints by default (no budget cap) — if
  the user asks for a capped/cheaper load, pass a token \`budget\` instead.
  The tool result ends with an estimate of how much of the context window
  the loaded memory occupies; mention it to the user when it is large. If mh
  reports no hub, propose \`mh init\`, run it on approval, then
  \`mh checkpoint <name>\` and proceed.
- \`mh_status\` shows the current checkpoint, position, and staleness.

## During / end of session
- \`mh_save\` — purify THIS dsh session (mechanical, no LLM cost) into the
  current checkpoint. Run it at session end, and whenever the user asks to
  save or checkpoint. Re-running later in the same session replaces the saved
  file — never a duplicate.
- \`mh_save\` with \`compact: true\` and a \`summary\` you write — when the
  user asks for a compact/summarized save ("compact this session", "压缩保存").
  mh has no model of its own, so YOU are the summarizer. Cover, in this order:
  the user's explicit requests and intent; key technical concepts; files and
  code sections touched and why; errors hit and how they were fixed; problems
  solved; every non-tool-result user message; pending tasks; what was in
  progress immediately before the save; and the next step if one is clearly
  implied. Preserve any security-relevant instruction or constraint
  **verbatim**. Quote the user's own words for anything in progress — do not
  paraphrase a task description, or the next session will drift. A compact
  save lands under the session's real identity, so it replaces (never
  duplicates) a purified save of the same session — one representation per
  session. Without \`summary\` the tool fails by design; do not retry without
  \`compact\` unless the user asks for the purified save instead.
- \`mh_checkpoint\` — start a new checkpoint (becomes current). Only when the
  user declares a new workstream or stage.
- \`mh link A B\` / \`mh unlink A B\`, navigation (\`mh back\`, \`mh forward\`,
  \`mh goto <ckpt>\`) — shell commands, only on explicit user request;
  afterwards tell the user which checkpoint is now current.

## Taking over a project with existing history
When the user asks to take over a project, import old sessions, or backfill
history: run \`mh import --dry-run\` first and show the summary, then on
approval \`mh import\`. It discovers the project's past **Claude Code, pi, and
Codex** sessions (not dsh sessions — dsh history lives in checkpoints saved
by this plugin), purifies them, and lands them in a \`history\` checkpoint in
one commit. Scope follows the invocation directory: run it from the project
root for the whole history, or from a subfolder to import only that
workstream. Then \`mh_load\` (or \`mh_load\` with \`["history"]\`) to absorb
the past.

## Rules
- Do not create HANDOFF.md / EXP.md / context.md files in a project that has
  a hub — that content belongs in checkpoints via \`mh_save\`.
- The hub is a normal git repo. Anything \`mh\` does not cover (rename,
  delete, merge, undo) is \`git -C .memoryhub ...\` — only on user request.
`
