/**
 * The Memory conversation view: the `mh ui` checkpoint map for the current
 * session's workspace, embedded in an iframe. The host half of this plugin
 * spawns the map server and hands out its token-bearing URL through
 * `/plugins/memoryhub/mh-ui?session=<id>`.
 */

import { useEffect, useState } from 'react'
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'

/** Business face the entry's inject factory supplies to the component. */
export interface MemoryHubViewInjected {
  /** Session whose workspace owns the map. */
  sessionId: string
}

/** Wire shape of the host route's JSON response. */
interface MhUiRouteResponse {
  url?: string | null
  reason?: string
  message?: string
}

type PanelState =
  | { readonly kind: 'loading' }
  | { readonly kind: 'ready'; readonly url: string }
  | { readonly kind: 'no-hub' }
  | { readonly kind: 'error'; readonly message: string }

const centerStyle = {
  flex: 1,
  minHeight: 0,
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '0.75em',
  padding: '2em',
  textAlign: 'center',
  opacity: 0.85,
} as const

/** Conversation-view component rendering one workspace's checkpoint map. */
export function MemoryHubView({
  sessionId,
  t,
}: ConvViewProps & InjectFace<MemoryHubViewInjected> & PropsLocale<'memoryhub'>) {
  const [state, setState] = useState<PanelState>({ kind: 'loading' })
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    let cancelled = false
    setState({ kind: 'loading' })
    fetch(`/plugins/memoryhub/mh-ui?session=${encodeURIComponent(sessionId)}`)
      .then(async (response): Promise<MhUiRouteResponse> => {
        if (!response.ok) return { url: null, reason: 'error', message: `HTTP ${response.status}` }
        return await (response.json() as Promise<MhUiRouteResponse>)
      })
      .then((data) => {
        if (cancelled) return
        if (typeof data.url === 'string' && data.url.length > 0) {
          setState({ kind: 'ready', url: data.url })
        } else if (data.reason === 'no-hub') {
          setState({ kind: 'no-hub' })
        } else {
          setState({ kind: 'error', message: data.message ?? data.reason ?? 'unknown error' })
        }
      })
      .catch((error: unknown) => {
        if (!cancelled) setState({ kind: 'error', message: String(error) })
      })
    return () => { cancelled = true }
  }, [sessionId, attempt])

  if (state.kind === 'ready') {
    return (
      <div style={{ flex: 1, minHeight: 0, position: 'relative' }}>
        <iframe
          src={state.url}
          title="MemoryHub"
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', border: 0 }}
        />
      </div>
    )
  }
  if (state.kind === 'loading') {
    return <div style={centerStyle}>{t('loading')}</div>
  }
  if (state.kind === 'no-hub') {
    return (
      <div style={centerStyle}>
        <div style={{ fontWeight: 600 }}>{t('noHub')}</div>
        <div style={{ maxWidth: '36em' }}>{t('noHubHint')}</div>
        <button type="button" onClick={() => { setAttempt(n => n + 1) }}>{t('retry')}</button>
      </div>
    )
  }
  return (
    <div style={centerStyle}>
      <div style={{ fontWeight: 600 }}>{t('failed')}</div>
      <div style={{ maxWidth: '48em', wordBreak: 'break-word' }}>{state.message}</div>
      <button type="button" onClick={() => { setAttempt(n => n + 1) }}>{t('retry')}</button>
    </div>
  )
}
