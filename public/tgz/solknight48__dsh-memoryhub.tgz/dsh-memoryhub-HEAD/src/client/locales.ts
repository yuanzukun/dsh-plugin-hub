/** `memoryhub` namespace dictionaries (Memory tab label + panel states). */

/** Dictionary namespace owned by this plugin. */
export const NS = 'memoryhub'

/** The memoryhub dictionary key set (the source of truth for both locales). */
export type MemoryHubKey =
  | 'view.memory'
  | 'loading'
  | 'noHub'
  | 'noHubHint'
  | 'retry'
  | 'failed'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The Memory view tab label and panel-state strings. */
    'memoryhub': MemoryHubKey
  }
}

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh: Record<MemoryHubKey, string> = {
  'view.memory': '记忆',
  'loading': '正在启动 MemoryHub 检查点地图…',
  'noHub': '这个工作区还没有 MemoryHub 中枢',
  'noHubHint': '在项目根目录运行 mh init 创建一个（或让 agent 代劳），然后点击重试。',
  'retry': '重试',
  'failed': 'MemoryHub 检查点地图启动失败',
}

/** English dictionary checked against the Chinese key set. */
export const en: Record<MemoryHubKey, string> = {
  'view.memory': 'Memory',
  'loading': 'Starting the MemoryHub checkpoint map…',
  'noHub': 'No MemoryHub hub in this workspace yet',
  'noHubHint': 'Run mh init at the project root (or ask the agent to), then retry.',
  'retry': 'Retry',
  'failed': 'Failed to start the MemoryHub checkpoint map',
}
