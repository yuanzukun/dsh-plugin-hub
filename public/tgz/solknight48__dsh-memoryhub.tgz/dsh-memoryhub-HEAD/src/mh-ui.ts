/**
 * `mh ui` process pool: one checkpoint-map server per session workspace,
 * spawned lazily when the MemoryHub web tab first asks for it and killed when
 * the plugin unloads.
 *
 * The pool shells out to `mh ui --no-browser --port 0` with the session cwd,
 * so hub discovery (walk up for `.memoryhub/` with `.git`, `MH_HUB` override)
 * stays owned by mh. The minted URL — including its one-shot token — is
 * parsed from the child's stdout line `mh ui: http://…`.
 */

import { spawn } from 'node:child_process'
import type { ChildProcess } from 'node:child_process'

/** A running mh ui server and its token-bearing URL. */
export interface MhUiServer {
  /** Full URL including the one-shot token (`http://127.0.0.1:<port>/?t=…`). */
  readonly url: string
  /** Hub path reported by mh on stdout, when captured. */
  readonly hub: string | undefined
  readonly proc: ChildProcess
}

export type MhUiFailureCode = 'no-hub' | 'timeout' | 'exited' | 'spawn-error'

/** Startup failure; `code` lets the HTTP layer map it to a client hint. */
export class MhUiError extends Error {
  constructor(
    readonly code: MhUiFailureCode,
    message: string,
  ) {
    super(message)
    this.name = 'MhUiError'
  }
}

/** Milliseconds to wait for the `mh ui:` stdout line before giving up. */
const STARTUP_TIMEOUT_MS = 15_000

const URL_LINE = /mh ui: (http:\/\/\S+)/
const HUB_LINE = /^hub: (.+?)(?:\s+\(read-only\))?$/m

export class MhUiPool {
  private readonly servers = new Map<string, Promise<MhUiServer>>()

  constructor(
    private readonly bin: string,
    private readonly readOnly: boolean,
    private readonly budget: number | 'none',
    private readonly warn: (message: string) => void,
  ) {}

  /**
   * Return the running server for this workspace, spawning it on first use.
   * Concurrent callers share one startup promise; a failed startup is dropped
   * from the pool so the next call retries.
   */
  ensure(cwd: string): Promise<MhUiServer> {
    let pending = this.servers.get(cwd)
    if (pending === undefined) {
      pending = this.launch(cwd)
      this.servers.set(cwd, pending)
      pending.catch(() => this.servers.delete(cwd))
    }
    return pending
  }

  /** Kill every spawned server. Idempotent. */
  dispose(): void {
    const pending = [...this.servers.values()]
    this.servers.clear()
    for (const entry of pending) {
      void entry.then(({ proc }) => { proc.kill('SIGTERM') }, () => {})
    }
  }

  private launch(cwd: string): Promise<MhUiServer> {
    const args = ['ui', '--no-browser', '--port', '0', '--budget', String(this.budget)]
    if (this.readOnly) args.push('--read-only')
    return new Promise((resolve, reject) => {
      const proc = spawn(this.bin, args, { cwd, stdio: ['ignore', 'pipe', 'pipe'] })
      let settled = false
      let stdout = ''
      let stderr = ''
      const timer = setTimeout(() => {
        if (settled) return
        settled = true
        proc.kill('SIGTERM')
        reject(new MhUiError('timeout', `mh ui did not report a URL within ${STARTUP_TIMEOUT_MS}ms`))
      }, STARTUP_TIMEOUT_MS)

      proc.stdout.on('data', (chunk: Buffer) => {
        stdout += chunk.toString('utf8')
        const match = URL_LINE.exec(stdout)
        if (match?.[1] !== undefined && !settled) {
          settled = true
          clearTimeout(timer)
          resolve({ url: match[1], hub: HUB_LINE.exec(stdout)?.[1], proc })
        }
      })
      proc.stderr.on('data', (chunk: Buffer) => { stderr += chunk.toString('utf8') })
      proc.on('error', (error) => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        reject(new MhUiError('spawn-error', `failed to start mh ui: ${error.message}`))
      })
      proc.on('exit', (code) => {
        this.servers.delete(cwd)
        if (settled) {
          this.warn(`memoryhub: mh ui for ${cwd} exited with code ${String(code)}`)
          return
        }
        settled = true
        clearTimeout(timer)
        const detail = (stderr.trim() || stdout.trim())
        reject(new MhUiError(
          code === 2 ? 'no-hub' : 'exited',
          detail.length > 0 ? detail : `mh ui exited with code ${String(code)}`,
        ))
      })
    })
  }
}
