/**
 * MemoryHub integration for DeepSeek Harness.
 *
 * - On `agent/session-start`, runs `mh load` in the session workspace and
 *   injects the resulting checkpoint memory as durable plugin context.
 * - Registers `mh_load` / `mh_save` / `mh_status` / `mh_list` / `mh_search` /
 *   `mh_checkpoint` tools wrapping the `mh` CLI. Saving bridges the live dsh
 *   session into a pi-format transcript so stock mh can purify or compact it
 *   (mh does not discover dsh session files itself).
 * - Registers the `mh` workflow skill so the model knows when and how to use
 *   all of the above.
 * - Web UI: a "Memory" tab beside chat/trajectory (the package's `dsh.client`
 *   half) showing the `mh ui` checkpoint map in an iframe. The map server is
 *   spawned per session workspace by this host half; the browser learns its
 *   token-bearing URL through the `/plugins/memoryhub/mh-ui` route registered
 *   here.
 *
 * @module dsh-memoryhub
 */

import { writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { defineTool } from '@deepseek-ai/dsh-tools'
import '@deepseek-ai/dsh-skill'
import type { SessionId } from '@deepseek-ai/dsh-session'
import type {} from '@deepseek-ai/dsh-session'
import type { WebServer } from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { writeBridgeTranscript } from './bridge.js'
import { contextShare, renderShare } from './estimate.js'
import type { ContextShare } from './estimate.js'
import { MH_EXIT_NO_HUB, renderMhResult, runMh } from './mh.js'
import type { MhResult } from './mh.js'
import { MhUiError, MhUiPool } from './mh-ui.js'
import { SKILL_CONTENT, SKILL_DESCRIPTION, SKILL_NAME } from './skill.js'

/** Cordis plugin name used by loader diagnostics and message source attribution. */
export const name = 'memoryhub'

/** Every service this plugin touches; all are provided by `@deepseek-ai/dsh-base`. */
export const inject = ['agents', 'tools', 'skills', 'sessions']

/** Deployment configuration for the MemoryHub plugin. */
export interface Config {
  /** Path or name of the mh executable (default `'mh'`, resolved through PATH). */
  readonly mhBin: string
  /** Run `mh load` and inject the result on every session start (default true). */
  readonly autoLoad: boolean
  /** Token budget passed to auto-load as `mh load --budget`; omit for mh's default. */
  readonly loadBudget?: number
  /** Kill any mh invocation after this many milliseconds (default 20000). */
  readonly timeoutMs: number
  /** Register the `mh_*` tools (default true). */
  readonly registerTools: boolean
  /** Register the `mh` workflow skill (default true). */
  readonly registerSkill: boolean
  /** Inject a short hint when auto-load finds no hub, instead of staying silent (default false). */
  readonly noHubHint: boolean
  /** Serve the mh-ui URL route the web Memory tab fetches (default true). No-op without a web server. */
  readonly uiTab: boolean
  /** Spawn `mh ui --read-only`: the Memory tab shows the map without editing (default false). */
  readonly uiReadOnly: boolean
  /** Initial token budget in the Memory tab's map: a number, or 'none' for no over-budget badges (default 'none'). */
  readonly uiBudget: number | 'none'
  /** Fallback context-window size for mh_load's context-% estimate when the model adapter has not reported one (default 128000). */
  readonly contextWindowTokens: number
}

/** Schemastery validation for {@link Config}; invalid values fail plugin load. */
export const Config: Schema<Config> = Schema.object({
  mhBin: Schema.string().default('mh'),
  autoLoad: Schema.boolean().default(true),
  loadBudget: Schema.number(),
  timeoutMs: Schema.number().default(20_000),
  registerTools: Schema.boolean().default(true),
  registerSkill: Schema.boolean().default(true),
  noHubHint: Schema.boolean().default(false),
  uiTab: Schema.boolean().default(true),
  uiReadOnly: Schema.boolean().default(false),
  uiBudget: Schema.union([Schema.const('none'), Schema.number()]).default('none'),
  contextWindowTokens: Schema.number().default(128_000),
})

/** Canonical return value of every `mh_*` tool: domain outcome plus model-facing text. */
interface MhToolValue {
  readonly ok: boolean
  readonly output: string
}

/** `mh_load` additionally reports the loaded pack's context-share estimate. */
interface MhLoadValue extends MhToolValue {
  readonly estimate?: ContextShare
}

const MH_OUTPUT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    ok: { type: 'boolean', required: true },
    output: { type: 'string', required: true },
  },
} as const

const MH_LOAD_OUTPUT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    ok: { type: 'boolean', required: true },
    output: { type: 'string', required: true },
    estimate: {
      type: 'object',
      additionalProperties: false,
      properties: {
        windowTokens: { type: 'number', required: true },
        windowSource: { type: 'string', required: true },
        memoryTokens: { type: 'number', required: true },
        memoryPercent: { type: 'number', required: true },
        currentTokens: { type: 'number' },
        totalPercent: { type: 'number' },
      },
    },
  },
} as const

/** Shared renderer: the text is the whole story; `ok` stays programmatic. */
function renderMhValue(_args: unknown, value: MhToolValue) {
  return [{ type: 'text' as const, text: value.output }]
}

/** `mh_load` renderer: mh's own text plus the context-share annotation. */
function renderMhLoadValue(_args: unknown, value: MhLoadValue) {
  const text = value.estimate === undefined
    ? value.output
    : `${value.output}\n\n${renderShare(value.estimate)}`
  return [{ type: 'text' as const, text }]
}

/**
 * Register the MemoryHub plugin for the lifetime of `ctx`. All registrations
 * (listener, tools, skill) are effects and unload with the plugin.
 * @param ctx - plugin context.
 * @param config - validated deployment configuration.
 */
export function apply(ctx: Context, config: Config): void {
  const mhBin = config.mhBin
  const timeoutMs = config.timeoutMs

  /** The session workspace is mh's project scope; fall back to the host cwd. */
  const cwdOf = (agent: Agent | undefined): string =>
    agent?.session.header.cwd ?? process.cwd()

  const run = (args: readonly string[], agent: Agent | undefined, signal?: AbortSignal): Promise<MhResult> =>
    runMh(mhBin, args, { cwd: cwdOf(agent), timeoutMs, ...(signal !== undefined ? { signal } : {}) })

  if (config.autoLoad) {
    // Detached on purpose: a slow mh must not gate session publication. The
    // injected snapshot is durable context the NEXT model request sees.
    ctx.on('agent/session-start', ({ agent }) => {
      const args = ['load']
      if (config.loadBudget !== undefined) args.push('--budget', String(config.loadBudget))
      void run(args, agent).then((result) => {
        try {
          if (result.ok) {
            const text = result.stdout.trim()
            if (text.length === 0) return
            agent.inject(createUserMessage({
              content: [{ type: 'text', text }],
              source: { kind: 'plugin', plugin: name, form: 'snapshot', sections: [{ name, text }] },
            }))
          } else if (result.code === MH_EXIT_NO_HUB) {
            if (!config.noHubHint) return
            agent.inject(createUserMessage({
              content: [{
                type: 'text',
                text: 'MemoryHub: no .memoryhub hub found for this workspace. '
                  + 'If the user asks for project memory, propose `mh init` and run it on approval.',
              }],
              source: { kind: 'plugin', plugin: name },
            }))
          } else {
            ctx.logger.warn(`memoryhub: auto-load failed: ${result.stderr.trim() || result.stdout.trim()}`)
          }
        } catch {
          // The agent was disposed while mh was running; nothing to inject into.
        }
      })
    })
  }

  if (config.registerTools) {
    ctx.tools.register(defineTool({
      name: 'mh_load',
      description: 'Load MemoryHub project memory: purified past sessions from the current .memoryhub checkpoint and its links, merged in time order. By default EVERY session loads (no budget cap); pass budget to keep only the newest contiguous suffix within a token budget. The result ends with an estimate of how much of the model\'s context window the loaded memory occupies.',
      parameters: {
        checkpoints: { type: 'array', items: { type: 'string' }, description: 'Checkpoint names to load; default is the current checkpoint plus its linked closure.' },
        budget: { type: 'number', description: 'Optional token budget; when given, only the newest sessions that fit are loaded (the newest always is). Omit to load everything.' },
        noLinks: { type: 'boolean', description: 'Load only the selected checkpoints, without following links.' },
      },
      output: { schema: MH_LOAD_OUTPUT_SCHEMA, render: renderMhLoadValue },
      async execute(args, exec): Promise<MhLoadValue> {
        const cli = ['load', ...args.checkpoints ?? []]
        // 默认全量加载（--all）：部署决定取消 over-budget 过滤；显式 budget 才封顶。
        if (args.budget !== undefined) cli.push('--budget', String(args.budget))
        else cli.push('--all')
        if (args.noLinks === true) cli.push('--no-links')
        const result = await run(cli, exec.agent, exec.signal)
        const output = renderMhResult('load', result)
        if (!result.ok) return { ok: false, output }
        return {
          ok: true,
          output,
          estimate: contextShare(exec.agent, output, config.contextWindowTokens),
        }
      },
    }))

    ctx.tools.register(defineTool({
      name: 'mh_save',
      description: 'Save THIS dsh session into a MemoryHub checkpoint. Default: purify the full dialog (mechanical, no LLM cost). With compact=true, store the summary you write instead — required whenever the user asks for a compact/summarized save (压缩保存). Re-saving the same session replaces the previous file, never duplicates.',
      parameters: {
        checkpoint: { type: 'string', description: 'Target checkpoint; default is the current checkpoint.' },
        compact: { type: 'boolean', description: 'Store an agent-written summary of this session instead of the purified dialog. Requires summary.' },
        summary: { type: 'string', description: 'The summary to store (required with compact). Follow the mh skill: intent, key concepts, files touched and why, errors and fixes, every user message, pending tasks, next step. Preserve security-relevant constraints verbatim; quote the user\'s own words for anything in progress.' },
      },
      output: { schema: MH_OUTPUT_SCHEMA, render: renderMhValue },
      async execute(args, exec): Promise<MhToolValue> {
        const compact = args.compact === true
        const summary = args.summary?.trim()
        if (compact && (summary === undefined || summary.length === 0)) {
          return {
            ok: false,
            output: 'mh save --compact needs the summary to store: mh does not summarize by itself. '
              + 'Write one following the mh skill and pass it as `summary`, or save without compact.',
          }
        }
        const cli = ['save']
        if (args.checkpoint !== undefined && args.checkpoint.trim().length > 0) {
          cli.push('--to', args.checkpoint.trim())
        }
        // Bridge the live dsh session into a transcript mh can own; without an
        // agent (detached execution) fall back to mh's native discovery.
        if (exec.agent !== undefined) {
          const bridge = writeBridgeTranscript(exec.agent)
          cli.push('--transcript', bridge.path)
        }
        if (compact) {
          const summaryPath = join(tmpdir(), 'dsh-memoryhub', `summary_${String(exec.agent?.id ?? process.pid)}.md`)
          writeFileSync(summaryPath, `${summary}\n`, 'utf8')
          cli.push('--compact', '--file', summaryPath)
        }
        const result = await run(cli, exec.agent, exec.signal)
        return { ok: result.ok, output: renderMhResult('save', result) }
      },
    }))

    ctx.tools.register(defineTool({
      name: 'mh_status',
      description: 'Show the MemoryHub hub status for this workspace: current checkpoint, position in the checkpoint stack, and staleness.',
      parameters: {},
      output: { schema: MH_OUTPUT_SCHEMA, render: renderMhValue },
      async execute(_args, exec): Promise<MhToolValue> {
        const result = await run(['status'], exec.agent, exec.signal)
        return { ok: result.ok, output: renderMhResult('status', result) }
      },
    }))

    ctx.tools.register(defineTool({
      name: 'mh_list',
      description: 'List the MemoryHub checkpoints in this workspace\'s hub, with session counts and links.',
      parameters: {},
      output: { schema: MH_OUTPUT_SCHEMA, render: renderMhValue },
      async execute(_args, exec): Promise<MhToolValue> {
        const result = await run(['list'], exec.agent, exec.signal)
        return { ok: result.ok, output: renderMhResult('list', result) }
      },
    }))

    ctx.tools.register(defineTool({
      name: 'mh_search',
      description: 'Search across all purified sessions stored in this workspace\'s MemoryHub checkpoints.',
      parameters: {
        query: { type: 'string', required: true, description: 'Substring to search for in checkpoint contents.' },
      },
      output: { schema: MH_OUTPUT_SCHEMA, render: renderMhValue },
      async execute(args, exec): Promise<MhToolValue> {
        const result = await run(['search', args.query], exec.agent, exec.signal)
        return { ok: result.ok, output: renderMhResult(`search ${args.query}`, result) }
      },
    }))

    ctx.tools.register(defineTool({
      name: 'mh_checkpoint',
      description: 'Create a new MemoryHub checkpoint and make it current. Only use when the user declares a new workstream or stage.',
      parameters: {
        checkpointName: { type: 'string', required: true, description: 'Name for the new checkpoint (mh slugifies it).' },
      },
      output: { schema: MH_OUTPUT_SCHEMA, render: renderMhValue },
      async execute(args, exec): Promise<MhToolValue> {
        const result = await run(['checkpoint', args.checkpointName], exec.agent, exec.signal)
        return { ok: result.ok, output: renderMhResult(`checkpoint ${args.checkpointName}`, result) }
      },
    }))
  }

  if (config.registerSkill) {
    ctx.skills.register({
      name: SKILL_NAME,
      description: SKILL_DESCRIPTION,
      content: SKILL_CONTENT,
      source: 'runtime',
    })
  }

  // The web Memory tab's data route. webServer is a soft dependency: headless
  // compositions have no HTTP surface, and load order is not guaranteed, so
  // attach now if it is already up, otherwise wait for its service event.
  if (config.uiTab) {
    const pool = new MhUiPool(mhBin, config.uiReadOnly, config.uiBudget, (message) => { ctx.logger.warn(message) })
    ctx.effect(() => () => { pool.dispose() }, 'memoryhub.mhUiPool')

    const attach = (webServer: WebServer): void => {
      webServer.register({
        kind: 'exact',
        path: '/plugins/memoryhub/mh-ui',
        handler: async (req, res) => {
          const send = (status: number, payload: unknown): void => {
            const body = JSON.stringify(payload)
            res.writeHead(status, {
              'Content-Type': 'application/json; charset=utf-8',
              'Content-Length': Buffer.byteLength(body),
              'Cache-Control': 'no-store',
            })
            res.end(body)
          }
          const sessionParam = new URL(req.url ?? '/', 'http://localhost').searchParams.get('session')
          if (sessionParam === null || sessionParam.length === 0) {
            send(400, { url: null, reason: 'bad-request', message: 'missing session parameter' })
            return
          }
          const cwd = ctx.sessions.get(sessionParam as SessionId)?.header.cwd
          if (cwd === undefined) {
            send(404, { url: null, reason: 'no-session', message: 'session unavailable or has no workspace' })
            return
          }
          try {
            const server = await pool.ensure(cwd)
            send(200, { url: server.url, hub: server.hub })
          } catch (error: unknown) {
            if (error instanceof MhUiError && error.code === 'no-hub') {
              send(200, { url: null, reason: 'no-hub' })
              return
            }
            send(500, { url: null, reason: 'error', message: error instanceof Error ? error.message : String(error) })
          }
        },
      })
    }

    const running = ctx.get('webServer')
    if (running !== undefined) {
      attach(running)
    } else {
      const off = ctx.on('internal/service', (serviceName) => {
        if (serviceName !== 'webServer') return
        const arrived = ctx.get('webServer')
        if (arrived === undefined) return
        off()
        attach(arrived)
      })
    }
  }
}
