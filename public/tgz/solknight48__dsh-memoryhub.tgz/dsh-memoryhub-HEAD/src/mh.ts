/**
 * Thin process runner for the `mh` CLI. The plugin never reimplements hub
 * logic: every operation shells out to the installed MemoryHub executable so
 * the on-disk format, git commits, and error wording stay owned by mh.
 */

import { execFile } from 'node:child_process'

/** Outcome of one `mh` invocation. Non-zero exits are data, not throws. */
export interface MhResult {
  /** Whether mh exited 0. */
  readonly ok: boolean
  /** Process exit code; `null` when the process never started. */
  readonly code: number | null
  readonly stdout: string
  readonly stderr: string
  /** How the run ended. */
  readonly outcome: 'exit' | 'timeout' | 'aborted' | 'spawn-error'
}

/** mh's exit code for "no hub found (run 'mh init' to create one)". */
export const MH_EXIT_NO_HUB = 2

export interface RunMhOptions {
  /** Working directory — hub discovery walks up from here. */
  readonly cwd?: string | undefined
  /** Kill the child after this many milliseconds. */
  readonly timeoutMs: number
  /** Cooperative cancellation from the owning tool execution. */
  readonly signal?: AbortSignal | undefined
}

const MAX_BUFFER = 16 * 1024 * 1024

/**
 * Run `mh` with the given arguments and capture its output. mh writes
 * human-readable results to stdout and diagnostics to stderr; both are kept.
 */
export function runMh(bin: string, args: readonly string[], options: RunMhOptions): Promise<MhResult> {
  return new Promise((resolve) => {
    const child = execFile(
      bin,
      [...args],
      {
        cwd: options.cwd,
        timeout: options.timeoutMs,
        killSignal: 'SIGTERM',
        maxBuffer: MAX_BUFFER,
        ...(options.signal !== undefined ? { signal: options.signal } : {}),
        env: process.env,
      },
      (error, stdout, stderr) => {
        if (error == null) {
          resolve({ ok: true, code: 0, stdout, stderr, outcome: 'exit' })
          return
        }
        const killedByTimeout = (error as NodeJS.ErrnoException & { killed?: boolean }).killed === true
          && !(options.signal?.aborted ?? false)
        if (options.signal?.aborted) {
          resolve({ ok: false, code: null, stdout, stderr, outcome: 'aborted' })
        } else if (killedByTimeout) {
          resolve({ ok: false, code: null, stdout, stderr, outcome: 'timeout' })
        } else if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
          resolve({ ok: false, code: null, stdout, stderr: stderr || `mh executable not found: ${bin}`, outcome: 'spawn-error' })
        } else {
          resolve({ ok: false, code: (error as { code?: number }).code ?? 1, stdout, stderr, outcome: 'exit' })
        }
      },
    )
    // The error event is fully handled by the callback above; this only
    // appeases Node's unhandled 'error' event semantics on exotic failures.
    child.on('error', () => {})
  })
}

/** Render an {@link MhResult} as the model-facing text for a tool result. */
export function renderMhResult(command: string, result: MhResult): string {
  if (result.ok) {
    const body = result.stdout.trim()
    return body.length > 0 ? body : `mh ${command}: done.`
  }
  const parts = [`mh ${command} failed`]
  if (result.outcome === 'timeout') parts.push('(timed out)')
  else if (result.outcome === 'aborted') parts.push('(cancelled)')
  else if (result.code !== null) parts.push(`(exit ${result.code})`)
  const detail = (result.stderr.trim() || result.stdout.trim())
  if (detail.length > 0) parts.push(`: ${detail}`)
  return parts.join('')
}
