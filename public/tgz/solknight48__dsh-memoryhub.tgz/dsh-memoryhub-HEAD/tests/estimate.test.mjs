/**
 * Unit tests for the mh_load context-share estimate: adapter-reported window
 * beats config fallback, last request usage drives the session-total percent,
 * and the token heuristic matches mh's ~4 chars/token.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'

import { contextShare, estimateTokens, renderShare } from '../lib/estimate.js'

function fakeAgent(events) {
  return { id: 's', session: { events } }
}

const requestContext = (window) => ({
  type: 'request/context',
  time: 1,
  data: { provider: 'p', model: 'm', ...(window === undefined ? {} : { contextWindow: window }) },
})
const assistantUsage = (inputTokens) => ({
  type: 'assistant/message',
  time: 2,
  data: {
    turn: 1,
    step: 1,
    message: { role: 'assistant', content: [], source: { kind: 'model' } },
    usage: { inputTokens, outputTokens: 5 },
  },
})
const userMsg = () => ({
  type: 'user/message',
  time: 3,
  data: { role: 'user', content: [], source: { kind: 'user' } },
})

test('estimateTokens uses mh\'s ~4 chars/token heuristic', () => {
  assert.equal(estimateTokens(''), 0)
  assert.equal(estimateTokens('abcd'), 1)
  assert.equal(estimateTokens('abcde'), 2)
})

test('adapter-reported window wins over config fallback; newest event wins', () => {
  const agent = fakeAgent([
    requestContext(100_000),
    userMsg(),
    requestContext(256_000), // newest route report is authoritative
    assistantUsage(40_000),
  ])
  const share = contextShare(agent, 'x'.repeat(10_000), 128_000)
  assert.equal(share.windowTokens, 256_000)
  assert.equal(share.windowSource, 'adapter')
  assert.equal(share.memoryTokens, 2_500)
  assert.ok(Math.abs(share.memoryPercent - 2500 / 2560) < 1e-9)
  assert.equal(share.currentTokens, 40_000)
  assert.ok(Math.abs((share.totalPercent ?? 0) - 42_500 / 2560) < 1e-9)
})

test('config fallback applies when the adapter never reported a window', () => {
  const agent = fakeAgent([requestContext(undefined), userMsg()])
  const share = contextShare(agent, 'x'.repeat(4_000), 128_000)
  assert.equal(share.windowTokens, 128_000)
  assert.equal(share.windowSource, 'config')
  assert.equal(share.memoryTokens, 1_000)
  assert.equal(share.totalPercent, undefined, 'no usage yet -> no session total')
})

test('no agent (detached execution) yields only the config-window memory share', () => {
  const share = contextShare(undefined, 'x'.repeat(2_000), 64_000)
  assert.equal(share.windowSource, 'config')
  assert.equal(share.memoryTokens, 500)
  assert.equal(share.currentTokens, undefined)
  assert.equal(share.totalPercent, undefined)
})

test('renderShare annotates percent, window source, and session total', () => {
  const withTotal = renderShare({
    windowTokens: 256_000,
    windowSource: 'adapter',
    memoryTokens: 2_500,
    memoryPercent: 2500 / 2560,
    currentTokens: 40_000,
    totalPercent: 42_500 / 2560,
  })
  assert.match(withTotal, /\[memoryhub\] memory ≈ 2,500 tokens ≈ 1\.0% of the 256,000-token context window \(adapter-reported\)/)
  assert.match(withTotal, /session total after load ≈ 16\.6%/)

  const withoutTotal = renderShare({
    windowTokens: 128_000,
    windowSource: 'config',
    memoryTokens: 500,
    memoryPercent: 500 / 1280,
  })
  assert.match(withoutTotal, /\(configured\)/)
  assert.doesNotMatch(withoutTotal, /session total/)
})
