/**
 * End-to-end test of the transcript bridge against the REAL `mh` CLI:
 *
 *   fake dsh session events -> bridge JSONL -> mh save --transcript
 *   -> mh load -> mh save --compact (same identity, replaces)
 *
 * Runs in a temp HOME so the machine's real hubs are untouched. Requires `mh`
 * on PATH (uv tool install memoryhub).
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { mkdtempSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { sessionToJsonl, writeBridgeTranscript } from '../lib/bridge.js'

const MH = process.env.MH_BIN ?? 'mh'

/** Minimal stand-in for a dsh Agent: only session.events and id are read. */
function fakeAgent(id, events) {
  return { id, session: { events } }
}

const user = (time, text) => ({
  type: 'user/message',
  time,
  data: { role: 'user', content: [{ type: 'text', text }], source: { kind: 'user' } },
})
const pluginContext = (time, text) => ({
  type: 'user/message',
  time,
  data: { role: 'user', content: [{ type: 'text', text }], source: { kind: 'plugin', plugin: 'memoryhub' } },
})
const assistant = (time, text) => ({
  type: 'assistant/message',
  time,
  data: { turn: 1, step: 1, message: { role: 'assistant', content: [{ type: 'text', text }], source: { kind: 'model' } } },
})
const toolResult = (time, callId = 'call_test', text = '') => ({
  type: 'tool/result',
  time,
  data: {
    turn: 1,
    step: 1,
    message: {
      source: { kind: 'tool', callId },
      content: text
        ? [{ type: 'tool-result', toolCallId: callId, content: [{ type: 'text', text }] }]
        : [],
    },
  },
})
const toolCall = (time, name, arguments_ = '{}') => ({
  type: 'tool/call',
  time,
  data: { turn: 1, step: 1, callId: 'call_test', name, arguments: arguments_ },
})
const LOAD_RECEIPT = '<!-- mh | loaded: study | 11 of 11 sessions | @ 18c0a54 -->'

function mh(args, cwd, env) {
  return execFileSync(MH, args, { cwd, env, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
}

/**
 * Isolated env: fresh HOME (XDG dirs included — mh reads XDG_CONFIG_HOME before
 * HOME, so an inherited one would touch the real ~/.config) plus a git
 * identity so mh's commits work.
 */
function testEnv(home) {
  return {
    ...process.env,
    HOME: home,
    XDG_CONFIG_HOME: join(home, '.config'),
    XDG_CACHE_HOME: join(home, '.cache'),
    XDG_DATA_HOME: join(home, '.local', 'share'),
    GIT_AUTHOR_NAME: 'mh-dsh-test',
    GIT_AUTHOR_EMAIL: 'mh-dsh-test@localhost',
    GIT_COMMITTER_NAME: 'mh-dsh-test',
    GIT_COMMITTER_EMAIL: 'mh-dsh-test@localhost',
  }
}

function setupProject(home) {
  const project = mkdtempSync(join(tmpdir(), 'mh-dsh-project-'))
  const env = testEnv(home)
  mh(['init'], project, env)
  mh(['checkpoint', 'main'], project, env)
  return { project, env }
}

test('bridge emits pi-format JSONL with only genuine user/assistant text', () => {
  const t0 = Date.parse('2026-08-14T10:00:00Z')
  const agent = fakeAgent('11111111-2222-3333-4444-555555555555', [
    pluginContext(t0, 'injected memory block must not be saved'),
    user(t0 + 1000, 'first question'),
    assistant(t0 + 2000, 'first answer'),
    toolResult(t0 + 2500),
    user(t0 + 3000, 'second question'),
    assistant(t0 + 4000, 'second answer\nwith two lines'),
  ])
  const jsonl = sessionToJsonl(agent)
  const records = jsonl.trim().split('\n').map(line => JSON.parse(line))
  assert.equal(records.length, 4)
  assert.deepEqual(records.map(r => r.message.role), ['user', 'assistant', 'user', 'assistant'])
  assert.equal(records[0].type, 'message')
  assert.equal(records[0].message.content[0].type, 'text')
  assert.equal(records[0].timestamp, '2026-08-14T10:00:01.000Z')
  assert.ok(!jsonl.includes('injected memory block'))
  assert.equal(records[3].message.content[0].text, 'second answer\nwith two lines')
})

test('assistant text after an mh load is dropped until the next genuine user message', () => {
  const t0 = Date.parse('2026-08-14T10:30:00Z')
  const digest = 'Study checkpoint fully loaded — 11 of 11 sessions. Old memory digest follows.'
  // Direct tool call path (headless dsh).
  const direct = fakeAgent('cccccccc-1111-2222-3333-444444444444', [
    user(t0, '/mh load study'),
    toolCall(t0 + 1000, 'mh_load', '{"checkpoints":["study"]}'),
    toolResult(t0 + 1500, 'call_test', LOAD_RECEIPT),
    assistant(t0 + 2000, digest),
    user(t0 + 3000, 'now the real question'),
    assistant(t0 + 4000, 'real answer'),
  ])
  const directJsonl = sessionToJsonl(direct)
  assert.ok(!directJsonl.includes(digest), 'load receipt/digest must not be bridged')
  assert.ok(directJsonl.includes('/mh load study'), 'the request line is genuine user input and stays')
  assert.ok(directJsonl.includes('real answer'), 'post-load turns are saved again')

  // Web GUI path: the load rides inside a run_code block.
  const viaCode = fakeAgent('dddddddd-1111-2222-3333-444444444444', [
    user(t0, 'load the memory'),
    toolCall(t0 + 1000, 'run_code', 'const r = await tools.mh_load({ checkpoints: ["study"] })'),
    toolResult(t0 + 1500, 'call_test', `mh_load ok: true\n${LOAD_RECEIPT}`),
    assistant(t0 + 2000, digest),
    user(t0 + 3000, 'thanks'),
    assistant(t0 + 3500, 'sure'),
  ])
  const codeJsonl = sessionToJsonl(viaCode)
  assert.ok(!codeJsonl.includes(digest), 'run_code-embedded mh_load echo must not be bridged')
  assert.ok(codeJsonl.includes('sure'))

  // A bash shell-out to `mh load` counts too; unrelated tool calls do not.
  const viaShell = fakeAgent('eeeeeeee-1111-2222-3333-444444444444', [
    toolCall(t0, 'bash', 'cd proj && mh load --budget 6000'),
    toolResult(t0 + 500, 'call_test', LOAD_RECEIPT),
    assistant(t0 + 1000, digest),
  ])
  assert.ok(!sessionToJsonl(viaShell).includes(digest))
  const unrelated = fakeAgent('ffffffff-1111-2222-3333-444444444444', [
    toolCall(t0, 'bash', 'ls -la'),
    toolResult(t0 + 500),
    assistant(t0 + 1000, 'plain listing answer'),
  ])
  assert.ok(sessionToJsonl(unrelated).includes('plain listing answer'))

  // MENTION is not a CALL: grepping for mh-load text (as diagnostics do)
  // must not arm the drop — the reply after it is genuine content.
  const mentionGrep = fakeAgent('aaaa1111-1111-2222-3333-444444444444', [
    toolCall(t0, 'bash', "grep -o 'afterMhLoad\\|mh load\\b' lib/bridge.js | head"),
    toolResult(t0 + 500),
    assistant(t0 + 1000, 'the bundle has 4 afterMhLoad hits; new code is live.'),
  ])
  assert.ok(sessionToJsonl(mentionGrep).includes('the bundle has 4 afterMhLoad hits'))

  // A load-shaped call whose result carries NO receipt (mh failed, or the
  // call merely edited text mentioning tools.mh_load) must not arm either.
  const failedLoad = fakeAgent('bbbb2222-1111-2222-3333-444444444444', [
    toolCall(t0, 'run_code', 'await tools.mh_load({})'),
    toolResult(t0 + 500, 'call_test', 'mh save failed(exit 2): mh: no hub found'),
    assistant(t0 + 1000, 'the load failed: no hub in this workspace yet.'),
  ])
  assert.ok(sessionToJsonl(failedLoad).includes('the load failed'), 'a failed load loads nothing; the reply is genuine content')
  const editPayload = fakeAgent('cccc3333-1111-2222-3333-444444444444', [
    toolCall(t0, 'edit', '{"file_path":"README.md","new_string":"calls tools.mh_load(…) directly"}'),
    toolResult(t0 + 500, 'call_test', 'README.md edited'),
    assistant(t0 + 1000, 'README now documents the detection rule.'),
  ])
  assert.ok(sessionToJsonl(editPayload).includes('README now documents'))
})

test('a saved session does not re-embed the load digest (e2e through real mh)', (t) => {
  const home = mkdtempSync(join(tmpdir(), 'mh-dsh-home-'))
  const { project, env } = setupProject(home)
  if (!process.env.MH_E2E_KEEP) t.after(() => {})

  const t0 = Date.parse('2026-08-14T13:00:00Z')
  const digest = 'Memory pack of 11 sessions: frozen line +792,624, nominee A on the forward clock.'
  const agent = fakeAgent('77777777-bbbb-cccc-dddd-eeeeeeeeeeee', [
    user(t0, '/mh load study'),
    toolCall(t0 + 1000, 'run_code', 'await tools.mh_load({})'),
    toolResult(t0 + 1500, 'call_test', '<!-- mh | loaded: study | 11 of 11 sessions | @ 18c0a54 -->'),
    assistant(t0 + 2000, `Loaded everything. ${digest}`),
    user(t0 + 3000, 'run the sweep'),
    assistant(t0 + 5000, 'sweep done, stitched net +12,345.'),
  ])
  const bridge = writeBridgeTranscript(agent)
  const saveOut = mh(['save', '--transcript', bridge.path], project, env)
  assert.match(saveOut, /-> main \(1 sessions\)/)

  const loadOut = mh(['load'], project, env)
  assert.ok(!loadOut.includes(digest), 'the digest of loaded memory must not enter the checkpoint')
  assert.ok(!loadOut.includes('Loaded everything.'), 'the load-receipt reply is dropped wholesale')
  assert.match(loadOut, /run the sweep/)
  assert.match(loadOut, /\+12,345/)
  assert.match(loadOut, /1 exchange/, 'the dropped reply collapses: the load request merges into the next user turn')
})

test('mh save --transcript purifies a bridged dsh session; mh load returns it', (t) => {
  const home = mkdtempSync(join(tmpdir(), 'mh-dsh-home-'))
  const { project, env } = setupProject(home)
  if (!process.env.MH_E2E_KEEP) t.after(() => {})

  const t0 = Date.parse('2026-08-14T11:00:00Z')
  const agent = fakeAgent('aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee', [
    user(t0, 'how do we shard the tick store?'),
    assistant(t0 + 5000, 'by symbol first, then month.'),
    user(t0 + 6000, 'and the cache key?'),
    assistant(t0 + 7000, 'symbol-month-bucket.'),
  ])

  const bridge = writeBridgeTranscript(agent)
  assert.ok(bridge.path.endsWith('dsh_aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.jsonl'))

  const saveOut = mh(['save', '--transcript', bridge.path], project, env)
  assert.match(saveOut, /saved .* -> main \(1 sessions\)/)

  const loadOut = mh(['load'], project, env)
  assert.match(loadOut, /how do we shard the tick store\?/)
  assert.match(loadOut, /symbol-month-bucket\./)
  assert.match(loadOut, /## User 1/)
  assert.match(loadOut, /## Agent 2/)
})

test('compact save replaces purified save of the same session (one representation)', () => {
  const home = mkdtempSync(join(tmpdir(), 'mh-dsh-home-'))
  const { project, env } = setupProject(home)

  const t0 = Date.parse('2026-08-14T12:00:00Z')
  const agent = fakeAgent('bbbbbbbb-1111-2222-3333-444444444444', [
    user(t0, 'set up the backtest'),
    assistant(t0 + 5000, 'done, config in backtest.toml.'),
  ])
  const bridge = writeBridgeTranscript(agent)

  mh(['save', '--transcript', bridge.path], project, env)

  const summaryPath = join(project, 'summary.md')
  writeFileSync(summaryPath, 'User asked to set up the backtest; config landed in backtest.toml.\n')
  const compactOut = mh(['save', '--compact', '--file', summaryPath, '--transcript', bridge.path], project, env)
  assert.match(compactOut, /saved .* -> main \(1 sessions\)/, 'still exactly one session after compact save')

  const loadOut = mh(['load'], project, env)
  assert.match(loadOut, /backtest\.toml/)
  assert.match(loadOut, /Compacted summary of/)
})

test('re-saving an extended session updates instead of duplicating', () => {
  const home = mkdtempSync(join(tmpdir(), 'mh-dsh-home-'))
  const { project, env } = setupProject(home)

  const t0 = Date.parse('2026-08-14T13:00:00Z')
  const events = [
    user(t0, 'turn one'),
    assistant(t0 + 1000, 'reply one'),
  ]
  const agent = fakeAgent('cccccccc-1111-2222-3333-444444444444', events)
  mh(['save', '--transcript', writeBridgeTranscript(agent).path], project, env)

  events.push(user(t0 + 2000, 'turn two'), assistant(t0 + 3000, 'reply two'))
  const out = mh(['save', '--transcript', writeBridgeTranscript(agent).path], project, env)
  assert.match(out, /\(1 sessions\)/, 'same session identity -> replacement, not a second file')

  const loadOut = mh(['load'], project, env)
  assert.match(loadOut, /turn two/)
  assert.match(loadOut, /2 exchanges/)
})

test('mh load in a project without a hub exits with the no-hub code', () => {
  const home = mkdtempSync(join(tmpdir(), 'mh-dsh-home-'))
  const nowhere = mkdtempSync(join(tmpdir(), 'mh-dsh-nowhere-'))
  try {
    mh(['load'], nowhere, testEnv(home))
    assert.fail('expected mh load to fail without a hub')
  } catch (error) {
    assert.equal(error.status, 2)
    assert.match(error.stderr.toString(), /no hub found/)
  }
})
