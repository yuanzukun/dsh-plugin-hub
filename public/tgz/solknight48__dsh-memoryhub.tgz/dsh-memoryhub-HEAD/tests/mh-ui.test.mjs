/**
 * End-to-end test of the mh-ui process pool against the REAL `mh` CLI:
 * spawn `mh ui` in a temp hub, fetch its token-bearing URL, verify the page
 * and its token guard, then kill the pool. Runs in a temp HOME so the
 * machine's real hubs are untouched. Requires `mh` on PATH.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { MhUiError, MhUiPool } from '../lib/mh-ui.js'

const MH = process.env.MH_BIN ?? 'mh'
const NO_LOG = () => {}

function testEnv(home) {
  return {
    ...process.env,
    HOME: home,
    // mh reads XDG_CONFIG_HOME before HOME; redirect the XDG trio too or an
    // inherited /home/<user>/.config leaks into the "isolated" run.
    XDG_CONFIG_HOME: join(home, '.config'),
    XDG_CACHE_HOME: join(home, '.cache'),
    XDG_DATA_HOME: join(home, '.local', 'share'),
    GIT_AUTHOR_NAME: 'mh-dsh-test',
    GIT_AUTHOR_EMAIL: 'mh-dsh-test@localhost',
    GIT_COMMITTER_NAME: 'mh-dsh-test',
    GIT_COMMITTER_EMAIL: 'mh-dsh-test@localhost',
  }
}

function setupProject(home) {
  const project = mkdtempSync(join(tmpdir(), 'mh-dsh-ui-project-'))
  const env = testEnv(home)
  execFileSync(MH, ['init'], { cwd: project, env, stdio: 'pipe' })
  execFileSync(MH, ['checkpoint', 'main'], { cwd: project, env, stdio: 'pipe' })
  return project
}

test('pool spawns mh ui, parses the token URL, and the page loads over HTTP', async (t) => {
  const home = mkdtempSync(join(tmpdir(), 'mh-dsh-ui-home-'))
  const project = setupProject(home)
  const pool = new MhUiPool(MH, false, 'none', NO_LOG)
  t.after(() => { pool.dispose() })

  const server = await pool.ensure(project)
  assert.match(server.url, /^http:\/\/127\.0\.0\.1:\d+\/\?t=\S+$/)
  assert.ok(server.hub?.endsWith('.memoryhub'), `hub path captured, got: ${server.hub}`)

  // Same workspace -> same server, no second process.
  const again = await pool.ensure(project)
  assert.equal(again.url, server.url)

  // The page is served and self-contained; the token in the URL authorizes it.
  const page = await fetch(server.url)
  assert.equal(page.status, 200)
  const html = await page.text()
  assert.match(html, /<html/i)
  // The pool serves the map with --budget none: the budget box starts empty,
  // so the map never renders over-budget badges.
  assert.match(html, /id="budget" value=""/, 'budget box must start empty (--budget none)')

  // Token guard: no token -> 403.
  const denied = await fetch(new URL('/', server.url).href.replace(/\?.*$/, ''))
  assert.equal(denied.status, 403)
})

test('pool maps a hub-less workspace to the no-hub failure code', async (t) => {
  const home = mkdtempSync(join(tmpdir(), 'mh-dsh-ui-home-'))
  const nowhere = mkdtempSync(join(tmpdir(), 'mh-dsh-ui-nowhere-'))
  const pool = new MhUiPool(MH, false, 'none', NO_LOG)
  t.after(() => { pool.dispose() })
  // mh ui discovers hubs from its cwd; HOME holds the hub registry, so keep
  // the child on the isolated HOME. The pool spawns with process.env, and mh
  // reads XDG_CONFIG_HOME before HOME, so the XDG trio must come along.
  const old = ['HOME', 'XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_DATA_HOME']
    .map((key) => [key, process.env[key]])
  process.env.HOME = home
  process.env.XDG_CONFIG_HOME = join(home, '.config')
  process.env.XDG_CACHE_HOME = join(home, '.cache')
  process.env.XDG_DATA_HOME = join(home, '.local', 'share')
  try {
    await assert.rejects(pool.ensure(nowhere), (error) => {
      assert.ok(error instanceof MhUiError)
      assert.equal(error.code, 'no-hub')
      assert.match(error.message, /no hub found/)
      return true
    })
  } finally {
    for (const [key, value] of old) {
      if (value === undefined) delete process.env[key]
      else process.env[key] = value
    }
  }
})
