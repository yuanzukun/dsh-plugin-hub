import { defineConfig } from 'tsdown'

/**
 * Browser bundle for the web Memory tab, self-contained third-party edition
 * of the dsh client-bundle contract: a closure-factory artifact handed to
 * `window.__ModuleLoader__.load({id, factory})`, with shared framework
 * modules resolved from the loader's frozen module table (externals) and
 * everything else inlined.
 *
 * The external list mirrors the dsh platform seed plus the documented
 * runtime exemption (`@deepseek-ai/dsh-client-runtime/client`). Type-only
 * imports of other client plugins are erased at build time and never reach
 * the module table — cross-plugin collaboration goes through cordis services
 * (ctx.slots, ctx.locale), never value imports.
 */
const PLATFORM_MODULES = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-attachment',
  '@deepseek-ai/dsh-client-schema-form',
  '@deepseek-ai/dsh-client-runtime/client',
]

export default defineConfig({
  entry: { client: 'src/client/index.ts' },
  outDir: 'lib',
  format: 'cjs',
  platform: 'browser',
  dts: false,
  sourcemap: true,
  // clean stays off: the host build (tsdown.config.ts) emits lib/index.js
  // first, and a default clean here would wipe it.
  clean: false,
  external: PLATFORM_MODULES,
  // No extra npm dependencies today; anything not in the module table must
  // inline rather than require() a specifier the table cannot answer.
  noExternal: (id) => (PLATFORM_MODULES.includes(id) ? undefined : true),
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
  },
  outputOptions: {
    entryFileNames: 'client.js',
    banner: 'window.__ModuleLoader__.load({ id: "dsh-memoryhub", factory: (require) => {',
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
  },
})
