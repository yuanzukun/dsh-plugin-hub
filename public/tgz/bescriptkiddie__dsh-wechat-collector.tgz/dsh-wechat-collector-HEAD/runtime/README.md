# pika-weixin-collection runtime

This is the credential-free, user-data-free runtime subset bundled with
`dsh-wechat-collector`.

Source: <https://github.com/bescriptkiddie/pika-weixin-collection>

Pinned commit: `c599f651dc87a2b3493f3860bf468b61c41d8698`

The DSH plugin deploys this code into its managed local state directory and
keeps credentials and collected articles outside the npm package.
