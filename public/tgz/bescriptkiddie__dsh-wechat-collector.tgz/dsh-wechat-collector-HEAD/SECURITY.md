# Security policy

## Supported release

Security fixes are applied to the latest published release.

## Runtime trust boundary

- All panel routes are loopback-only; mutating browser requests are also
  same-origin checked.
- First-run provisioning is an explicit user action, not an install lifecycle
  script.
- The managed uv binary comes from Astral's GitHub Release and is verified
  against a pinned SHA-256 before execution.
- The bundled collector runtime records its exact upstream repository and commit
  in `runtime/UPSTREAM.json`.
- The package excludes credentials, collected articles, caches, logs, and
  user-specific source configuration.
- Automatic provisioning refuses write targets outside
  `~/.local/share/dsh-wechat-collector`.
- The DeepSeek API key uses the DSH credential-reference service and is resolved
  per operation. It is never written to plugin settings, reports, tool output,
  or logs.
- Creator analysis requires an explicit account-level action, bounds the text
  sent to the configured endpoint, and stores reports with user-only file
  permissions.

## Reporting a vulnerability

Please open a private GitHub security advisory for
`bescriptkiddie/dsh-wechat-collector`. Do not include real WeChat credentials,
cookies, QR images, or collected private content in a public issue.
