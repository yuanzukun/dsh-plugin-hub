# Privacy

## Local data

The managed runtime stores its state under:

```text
~/.local/share/dsh-wechat-collector/data
```

`id_info.json` contains the local WeChat token and cookie and is created with
user-only permissions. Collected articles, account mappings, feedback events,
and runtime receipts are stored beside it. Plugin removal preserves this data
unless the user deletes it separately.

Analysis settings and reports are stored under:

```text
~/.local/share/dsh-wechat-collector/analysis
```

The DeepSeek API key is stored by DSH credentials under the configured
reference (default `DEEPSEEK_API_KEY`), not in plugin settings or reports.

## DSH boundary

- Agent tools never return the token, cookie, `token_hint`, or QR image bytes.
- The QR image is fetched only through a loopback-only DSH panel route and is
  held in the local browser UI for scanning.
- ContentStudio imports contain links and short previews, not credentials or
  complete article bodies.
- Installation and import receipts explicitly record that credentials were not
  exposed.
- Analysis tools and reports expose only credential presence/source metadata,
  never the DeepSeek API key.

## Network activity

- Explicit first-run setup downloads a pinned uv release from GitHub after the
  user confirms the disclosed action.
- The local collector contacts WeChat services for QR login, account lookup, and
  article collection.
- Optional upstream LLM enrichment runs only when the user separately supplies
  its environment configuration.
- Creator analysis runs only after an explicit account-level action. It sends a
  bounded article corpus (maximum 6,000 characters per article and 60,000 total)
  to the DeepSeek-compatible endpoint configured in the panel.
- The DSH plugin itself does not upload telemetry or credentials.
