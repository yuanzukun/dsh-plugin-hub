import { createServer } from "node:http";

const port = Number(process.env.ANALYSIS_FIXTURE_PORT || 8121);

function send(res, value, status = 200) {
	res.writeHead(status, { "content-type": "application/json" });
	res.end(JSON.stringify(value));
}

createServer(async (req, res) => {
	if (req.method !== "POST" || req.url !== "/chat/completions") return send(res, { error: { message: "not found" } }, 404);
	const chunks = [];
	for await (const chunk of req) chunks.push(chunk);
	let body;
	try { body = JSON.parse(Buffer.concat(chunks).toString("utf8")); }
	catch { return send(res, { error: { message: "invalid json" } }, 400); }
	if (req.headers.authorization !== "Bearer browser-validation-key") return send(res, { error: { message: "invalid fixture key" } }, 401);
	const isProbe = Array.isArray(body.messages) && body.messages.some((message) => String(message?.content || "").includes("返回 {\"ok\":true}"));
	const content = isProbe ? JSON.stringify({ ok: true }) : JSON.stringify({
		summary: {
			positioning: "用真实场景拆解内容工作的实践型博主",
			coreMethod: "具体问题—案例证据—可执行动作",
			readerValue: "读完可以直接复用一个内容动作"
		},
		reportMarkdown: "## 1. 一句话定位\n- 用真实场景拆解内容工作。\n## 2. 选题系统\n- 围绕内容采集、判断与行动；证据文章：样本文章1、样本文章2。\n## 3. 标题模式\n- 问题与结果并置；证据文章：样本文章1、样本文章3。\n## 4. 开头模板\n- 从具体工作现场进入；证据文章：样本文章2。\n## 5. 正文结构\n- 问题—案例—方法—行动；证据文章：样本文章3、样本文章4。\n## 6. 金句和句式\n- 短判断推动段落；证据文章：样本文章4、样本文章5。\n## 7. 可复用写作组件\n- 结构示例：先写一个真实卡点，再给证据与下一步。\n## 8. 发布前检查清单\n- 是否有原文证据；是否把推断标成推断。\n## 9. 下一步\n- 补充更长时间范围的文章后再复核长期模式。"
	});
	return send(res, { model: body.model || "deepseek-chat", choices: [{ message: { content } }] });
}).listen(port, "127.0.0.1", () => {
	process.stdout.write(`fake DeepSeek ready on http://127.0.0.1:${port}\n`);
});
