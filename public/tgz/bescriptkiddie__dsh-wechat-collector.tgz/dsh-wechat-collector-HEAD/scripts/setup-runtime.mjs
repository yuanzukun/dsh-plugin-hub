import { homedir } from "node:os";
import { join } from "node:path";
import { installRuntime } from "./runtime-manager.mjs";

const receipt = await installRuntime({
	projectRoot: process.env.DSH_WECHAT_COLLECTOR_ROOT || join(homedir(), ".local", "share", "dsh-wechat-collector", "runtime", "current"),
	label: process.env.DSH_WECHAT_COLLECTOR_LABEL || "com.pika.wechat-collector.runtime",
	baseUrl: process.env.DSH_WECHAT_COLLECTOR_URL || "http://127.0.0.1:8000"
});

process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`);
