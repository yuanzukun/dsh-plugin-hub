import { createHash } from "node:crypto";
import { execFile } from "node:child_process";
import {
	access,
	chmod,
	copyFile,
	cp,
	lstat,
	mkdir,
	mkdtemp,
	readFile,
	readlink,
	rename,
	rm,
	symlink,
	writeFile
} from "node:fs/promises";
import { homedir, platform, arch, tmpdir } from "node:os";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

export const RUNTIME_SOURCE = "https://github.com/bescriptkiddie/pika-weixin-collection";
export const RUNTIME_COMMIT = "c599f651dc87a2b3493f3860bf468b61c41d8698";
export const UV_VERSION = "0.12.6";

const PACKAGE_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const VENDORED_RUNTIME = join(PACKAGE_ROOT, "runtime");
const MANAGED_ROOT = join(homedir(), ".local", "share", "dsh-wechat-collector");
const MAX_DOWNLOAD_BYTES = 100 * 1024 * 1024;

const UV_ASSETS = {
	arm64: {
		name: "uv-aarch64-apple-darwin.tar.gz",
		folder: "uv-aarch64-apple-darwin",
		sha256: "14b459d51ea2e71eeba28c45a268c922bdf8607fc6455e3f40b4e082895d160d"
	},
	x64: {
		name: "uv-x86_64-apple-darwin.tar.gz",
		folder: "uv-x86_64-apple-darwin",
		sha256: "2a26ea71bbeff1c7e12c2cc40245c96a041deff276bc921e7038e304d5d3e04c"
	}
};

async function exists(path) {
	try { await access(path); return true; } catch { return false; }
}

async function run(program, args, { cwd, signal, timeout = 180000 } = {}) {
	return execFileAsync(program, args, {
		cwd,
		signal,
		timeout,
		maxBuffer: 10 * 1024 * 1024,
		env: { ...process.env, NO_PROXY: "127.0.0.1,localhost" }
	});
}

function validateManagedPath(path) {
	const absolute = resolve(path);
	const rel = relative(MANAGED_ROOT, absolute);
	if (!rel || rel.startsWith("..") || isAbsolute(rel)) {
		throw new Error(`自动安装只允许写入 ${MANAGED_ROOT} 内部；当前路径：${absolute}`);
	}
	return absolute;
}

function stateRootFor(currentPath) {
	const stateRoot = resolve(currentPath, "..", "..");
	const rel = relative(MANAGED_ROOT, stateRoot);
	if (rel.startsWith("..") || isAbsolute(rel)) throw new Error(`运行时状态目录必须位于 ${MANAGED_ROOT} 内部`);
	return stateRoot;
}

function runtimeTarget(baseUrl) {
	let url;
	try { url = new URL(baseUrl); } catch { throw new Error(`采集器地址不合法：${baseUrl}`); }
	if (url.protocol !== "http:" || !["127.0.0.1", "localhost", "::1"].includes(url.hostname)) {
		throw new Error("插件管理的采集运行时只允许监听本机 http 地址");
	}
	if (url.pathname !== "/" || url.search || url.hash || url.username || url.password) {
		throw new Error("采集器地址不能包含路径、查询参数或凭证");
	}
	const port = Number(url.port || 80);
	if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error("采集器端口必须在 1024-65535 之间");
	return { host: url.hostname === "localhost" ? "127.0.0.1" : url.hostname, port, baseUrl: `http://${url.hostname}:${port}` };
}

function xml(value) {
	return String(value)
		.replaceAll("&", "&amp;")
		.replaceAll("<", "&lt;")
		.replaceAll(">", "&gt;")
		.replaceAll('"', "&quot;")
		.replaceAll("'", "&apos;");
}

async function downloadVerified(url, destination, expectedSha256, signal) {
	const response = await fetch(url, { redirect: "follow", signal });
	if (!response.ok) throw new Error(`下载失败（HTTP ${response.status}）：${url}`);
	const declared = Number(response.headers.get("content-length") || 0);
	if (declared > MAX_DOWNLOAD_BYTES) throw new Error("下载文件超过 100 MB 限制");
	const bytes = Buffer.from(await response.arrayBuffer());
	if (bytes.length > MAX_DOWNLOAD_BYTES) throw new Error("下载文件超过 100 MB 限制");
	const actual = createHash("sha256").update(bytes).digest("hex");
	if (actual !== expectedSha256) throw new Error(`uv 下载校验失败：期望 ${expectedSha256}，实际 ${actual}`);
	await writeFile(destination, bytes, { mode: 0o600 });
	return { bytes: bytes.length, sha256: actual };
}

async function ensureUv(stateRoot, signal) {
	if (platform() !== "darwin") throw new Error("当前版本的内置运行时只支持 macOS");
	const asset = UV_ASSETS[arch()];
	if (!asset) throw new Error(`暂不支持当前 Mac 架构：${arch()}`);
	const binDir = join(stateRoot, "bin");
	const uvPath = join(binDir, `uv-${UV_VERSION}-${arch()}`);
	if (await exists(uvPath)) {
		try {
			const { stdout } = await run(uvPath, ["--version"], { signal, timeout: 10000 });
			if (stdout.includes(UV_VERSION)) return { path: uvPath, version: UV_VERSION, downloaded: false };
		} catch { /* replace a damaged managed binary below */ }
	}

	await mkdir(binDir, { recursive: true });
	const tempRoot = await mkdtemp(join(tmpdir(), "dsh-wechat-uv-"));
	try {
		const archive = join(tempRoot, asset.name);
		const url = `https://github.com/astral-sh/uv/releases/download/${UV_VERSION}/${asset.name}`;
		const receipt = await downloadVerified(url, archive, asset.sha256, signal);
		await run("/usr/bin/tar", ["-xzf", archive, "-C", tempRoot], { signal, timeout: 30000 });
		const extracted = join(tempRoot, asset.folder, "uv");
		if (!(await exists(extracted))) throw new Error("uv 压缩包中没有找到可执行文件");
		const staged = `${uvPath}.tmp-${process.pid}`;
		await copyFile(extracted, staged);
		await chmod(staged, 0o755);
		await run(staged, ["--version"], { signal, timeout: 10000 });
		await rename(staged, uvPath);
		await writeFile(join(binDir, "uv-receipt.json"), `${JSON.stringify({
			version: UV_VERSION,
			architecture: arch(),
			source: url,
			sha256: receipt.sha256,
			bytes: receipt.bytes,
			installedAt: new Date().toISOString()
		}, null, 2)}\n`, "utf8");
		return { path: uvPath, version: UV_VERSION, downloaded: true };
	} finally {
		await rm(tempRoot, { recursive: true, force: true });
	}
}

async function initializeData(stateRoot) {
	const dataRoot = join(stateRoot, "data");
	await mkdir(dataRoot, { recursive: true });
	const initialFiles = {
		"id_info.json": '{\n  "token": "",\n  "cookie": ""\n}\n',
		"name2fakeid.json": "{}\n",
		"message_info.json": "{}\n",
		"message_detail_text.json": "{}\n",
		"issues_message.json": '{\n  "is_delete": [],\n  "dup_minhash": {}\n}\n',
		"deleted_article_ids.json": '{\n  "ids": []\n}\n',
		"content_items.jsonl": "",
		"feedback_events.jsonl": "",
		"external_sources.json": '{\n  "sources": []\n}\n'
	};
	for (const [name, value] of Object.entries(initialFiles)) {
		const path = join(dataRoot, name);
		if (!(await exists(path))) await writeFile(path, value, { encoding: "utf8", mode: name === "id_info.json" ? 0o600 : 0o644 });
	}
	for (const name of ["README.md", "id_info.example.json", "external_sources.example.json"]) {
		const target = join(dataRoot, name);
		if (!(await exists(target))) await copyFile(join(VENDORED_RUNTIME, "data-templates", name), target);
	}
	return dataRoot;
}

async function ensureSymlink(path, target) {
	try {
		const info = await lstat(path);
		if (!info.isSymbolicLink()) throw new Error(`拒绝覆盖非符号链接：${path}`);
		const current = resolve(dirname(path), await readlink(path));
		if (current === resolve(target)) return false;
		const staged = `${path}.tmp-${process.pid}`;
		await symlink(target, staged, "dir");
		await rename(staged, path);
		return true;
	} catch (error) {
		if (error?.code !== "ENOENT") throw error;
		await symlink(target, path, "dir");
		return true;
	}
}

async function deployRuntime(currentPath, stateRoot, uvPath, signal) {
	const releasesRoot = join(stateRoot, "runtime", "releases");
	const releaseRoot = join(releasesRoot, RUNTIME_COMMIT);
	const markerPath = join(releaseRoot, "RUNTIME.json");
	await mkdir(releasesRoot, { recursive: true });
	if (!(await exists(markerPath))) {
		if (await exists(releaseRoot)) throw new Error(`运行时版本目录不完整，拒绝覆盖：${releaseRoot}`);
		await cp(VENDORED_RUNTIME, releaseRoot, { recursive: true, errorOnExist: true, force: false });
		const dataRoot = await initializeData(stateRoot);
		await symlink(dataRoot, join(releaseRoot, "data"), "dir");
		await writeFile(markerPath, `${JSON.stringify({
			source: RUNTIME_SOURCE,
			commit: RUNTIME_COMMIT,
			credentialsBundled: false,
			userDataBundled: false,
			deployedAt: new Date().toISOString()
		}, null, 2)}\n`, "utf8");
	}
	const marker = JSON.parse(await readFile(markerPath, "utf8"));
	if (marker.commit !== RUNTIME_COMMIT || marker.credentialsBundled !== false) {
		throw new Error(`运行时版本校验失败：${releaseRoot}`);
	}
	await run(uvPath, ["sync", "--frozen"], { cwd: releaseRoot, signal, timeout: 300000 });
	await mkdir(dirname(currentPath), { recursive: true });
	await ensureSymlink(currentPath, releaseRoot);
	return { releaseRoot, currentPath, dataRoot: join(stateRoot, "data") };
}

async function installLaunchAgent({ label, currentPath, uvPath, baseUrl, stateRoot, signal }) {
	if (!/^[A-Za-z0-9._-]+$/.test(label)) throw new Error("runtimeLabel 含不安全字符");
	const target = runtimeTarget(baseUrl);
	const userHome = homedir();
	const domain = `gui/${typeof process.getuid === "function" ? process.getuid() : 501}`;
	const plistPath = join(userHome, "Library", "LaunchAgents", `${label}.plist`);
	const logRoot = join(userHome, "Library", "Logs", "dsh-wechat-collector");
	await Promise.all([mkdir(dirname(plistPath), { recursive: true }), mkdir(logRoot, { recursive: true })]);
	const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>${xml(label)}</string>
  <key>ProgramArguments</key>
  <array>
    <string>${xml(uvPath)}</string><string>run</string><string>uvicorn</string><string>api:app</string>
    <string>--host</string><string>${xml(target.host)}</string><string>--port</string><string>${target.port}</string>
  </array>
  <key>WorkingDirectory</key><string>${xml(currentPath)}</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>HOME</key><string>${xml(userHome)}</string>
    <key>NO_PROXY</key><string>127.0.0.1,localhost</string>
    <key>PATH</key><string>${xml([dirname(uvPath), "/usr/bin", "/bin", "/usr/sbin", "/sbin"].join(":"))}</string>
  </dict>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>5</integer>
  <key>StandardOutPath</key><string>${xml(join(logRoot, "runtime.out.log"))}</string>
  <key>StandardErrorPath</key><string>${xml(join(logRoot, "runtime.err.log"))}</string>
</dict>
</plist>
`;
	const changed = !(await exists(plistPath)) || await readFile(plistPath, "utf8") !== plist;
	if (changed) await writeFile(plistPath, plist, { encoding: "utf8", mode: 0o600 });
	await run("/usr/bin/plutil", ["-lint", plistPath], { signal, timeout: 10000 });

	let loaded = true;
	try { await run("/bin/launchctl", ["print", `${domain}/${label}`], { signal, timeout: 10000 }); }
	catch { loaded = false; }
	if (changed && loaded) {
		await run("/bin/launchctl", ["bootout", `${domain}/${label}`], { signal, timeout: 10000 });
		loaded = false;
	}
	if (!loaded) await run("/bin/launchctl", ["bootstrap", domain, plistPath], { signal, timeout: 10000 });
	await run("/bin/launchctl", ["kickstart", "-k", `${domain}/${label}`], { signal, timeout: 10000 });

	let lastError = "";
	for (let attempt = 0; attempt < 80; attempt += 1) {
		try {
			const response = await fetch(`${target.baseUrl}/api/auth/status`, { signal: AbortSignal.any([signal ?? new AbortController().signal, AbortSignal.timeout(1000)]) });
			if (response.ok) return { plistPath, label, baseUrl: target.baseUrl, ready: true };
			lastError = `HTTP ${response.status}`;
		} catch (error) { lastError = String(error?.message || error); }
		await new Promise((resolveDelay) => setTimeout(resolveDelay, 250));
	}
	throw new Error(`采集服务已经启动，但 API 在 20 秒内没有就绪：${lastError.slice(0, 240)}`);
}

export async function installRuntime({
	projectRoot = join(MANAGED_ROOT, "runtime", "current"),
	label = "com.pika.wechat-collector.runtime",
	baseUrl = "http://127.0.0.1:8000",
	signal
} = {}) {
	const currentPath = validateManagedPath(projectRoot);
	const stateRoot = stateRootFor(currentPath);
	const uv = await ensureUv(stateRoot, signal);
	const deployed = await deployRuntime(currentPath, stateRoot, uv.path, signal);
	const launchd = await installLaunchAgent({ label, currentPath, uvPath: uv.path, baseUrl, stateRoot, signal });
	const receipt = {
		status: "complete",
		platform: platform(),
		architecture: arch(),
		runtime: { source: RUNTIME_SOURCE, commit: RUNTIME_COMMIT, ...deployed },
		uv: { version: uv.version, path: uv.path, downloaded: uv.downloaded },
		launchd,
		checks: { apiReady: true, credentialsBundled: false, credentialsExposed: false, userDataBundled: false },
		completedAt: new Date().toISOString()
	};
	await writeFile(join(stateRoot, "install-receipt.json"), `${JSON.stringify(receipt, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
	return receipt;
}

export async function stopRuntime({
	label = "com.pika.wechat-collector.runtime",
	projectRoot = join(MANAGED_ROOT, "runtime", "current"),
	unconfigure = false,
	signal
} = {}) {
	if (!/^[A-Za-z0-9._-]+$/.test(label)) throw new Error("runtimeLabel 含不安全字符");
	if (platform() !== "darwin") throw new Error("当前版本的内置运行时只支持 macOS");
	const domain = `gui/${typeof process.getuid === "function" ? process.getuid() : 501}`;
	let loaded = true;
	try { await run("/bin/launchctl", ["print", `${domain}/${label}`], { signal, timeout: 10000 }); }
	catch { loaded = false; }
	if (loaded) await run("/bin/launchctl", ["bootout", `${domain}/${label}`], { signal, timeout: 10000 });

	const currentPath = validateManagedPath(projectRoot);
	const stateRoot = stateRootFor(currentPath);
	let backupPath = "";
	const plistPath = join(homedir(), "Library", "LaunchAgents", `${label}.plist`);
	if (unconfigure && await exists(plistPath)) {
		const backupRoot = join(stateRoot, "unconfigured");
		await mkdir(backupRoot, { recursive: true });
		backupPath = join(backupRoot, `${label}.${new Date().toISOString().replace(/[:.]/g, "-")}.plist`);
		await rename(plistPath, backupPath);
	}
	return {
		stopped: loaded,
		unconfigured: unconfigure,
		serviceBackup: backupPath,
		dataPreserved: true,
		managedFilesPreserved: true,
		credentialsExposed: false
	};
}

export function runtimeMetadata() {
	return {
		supported: platform() === "darwin" && Boolean(UV_ASSETS[arch()]),
		platform: platform(),
		architecture: arch(),
		managedRoot: MANAGED_ROOT,
		source: RUNTIME_SOURCE,
		commit: RUNTIME_COMMIT,
		uvVersion: UV_VERSION,
		credentialsBundled: false,
		userDataBundled: false
	};
}
