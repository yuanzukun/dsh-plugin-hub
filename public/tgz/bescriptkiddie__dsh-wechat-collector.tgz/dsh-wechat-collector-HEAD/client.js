window.__ModuleLoader__.load({
	id: "dsh-wechat-collector",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		var STATE_URL = "/wechat-collector/state";
		var ACTION_URL = "/wechat-collector/action";
		var QRCODE_URL = "/wechat-collector/qrcode";
		var ANALYSIS_URL = "/wechat-collector/analysis";
		var CSS = [
			".wxc-tab{position:fixed;right:0;top:57%;z-index:1200;padding:11px 5px;border:1px solid #2f3943;border-right:0;border-radius:8px 0 0 8px;background:#182129;color:#91a5b6;font:11px -apple-system,'PingFang SC',sans-serif;letter-spacing:2px;writing-mode:vertical-rl;cursor:pointer}",
			".wxc-tab.live{color:#91d0ae}.wxc-mask{position:fixed;inset:0;z-index:1201;background:rgba(0,0,0,.28)}",
			".wxc-panel{position:fixed;top:0;right:0;bottom:0;width:430px;max-width:100vw;z-index:1202;background:#141a1f;color:#d7dde2;border-left:1px solid #29343d;font:12px -apple-system,'PingFang SC',sans-serif;display:flex;flex-direction:column}",
			".wxc-head{height:48px;padding:0 14px;display:flex;align-items:center;gap:8px;border-bottom:1px solid #253039}.wxc-head b{font-size:14px}.wxc-head span{margin-left:auto;color:#7f929f;cursor:pointer;padding:6px}",
			".wxc-body{flex:1;overflow:auto}.wxc-sec{padding:13px 14px;border-bottom:1px solid #222c34}.wxc-title{font-size:10px;color:#71838f;letter-spacing:1px;margin-bottom:9px}",
			".wxc-row{display:flex;gap:8px;align-items:center;margin:6px 0}.wxc-grow{flex:1;min-width:0}.wxc-dot{width:8px;height:8px;border-radius:50%;background:#687680;flex:0 0 auto}.wxc-dot.ok{background:#61a77d}.wxc-dot.bad{background:#b46e6e}.wxc-meta{color:#81919c;font-size:11px;line-height:1.5}",
			".wxc-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:7px}.wxc-stat{background:#1b242b;border:1px solid #28343d;border-radius:7px;padding:9px}.wxc-stat b{display:block;font-size:17px;color:#e1e7eb}.wxc-stat small{color:#72838f}",
			".wxc-actions{display:flex;gap:7px;flex-wrap:wrap}.wxc-btn{border:1px solid #33424c;background:#202b33;color:#cbd4da;border-radius:6px;padding:6px 10px;font-size:11px;cursor:pointer}.wxc-btn.primary{background:#245846;border-color:#32775f;color:#d8f0e5}.wxc-btn.danger{color:#d9a1a1}.wxc-btn:disabled{opacity:.4;cursor:default}",
			".wxc-input,.wxc-select{box-sizing:border-box;width:100%;min-width:0;background:#10161a;border:1px solid #30404a;color:#e0e6ea;border-radius:6px;padding:7px 9px;outline:none}.wxc-search{display:flex;gap:7px}.wxc-form{display:grid;grid-template-columns:1fr 1fr;gap:8px}.wxc-field{min-width:0}.wxc-field.full{grid-column:1/-1}.wxc-label{display:block;color:#7f909b;font-size:10px;margin-bottom:4px}",
			".wxc-card{padding:9px 0;border-top:1px solid #222c34}.wxc-card:first-child{border-top:0}.wxc-card a{color:#b9c7cf;text-decoration:none;line-height:1.45}.wxc-card a:hover{color:#8fc6a7}.wxc-card .sub{font-size:10.5px;color:#74848f;margin-top:3px}.wxc-empty{color:#73838e;line-height:1.7;padding:4px 0}.wxc-error{color:#c58484;line-height:1.6}.wxc-note{font-size:10.5px;color:#6f7e88;line-height:1.6;margin-top:8px}",
			".wxc-candidate{display:flex;gap:8px;align-items:flex-start;padding:8px 0;border-top:1px solid #222c34}.wxc-candidate .txt{flex:1;min-width:0}.wxc-candidate b{display:block}.wxc-toast{padding:8px 14px;background:#1d3028;color:#9bd0b2;border-bottom:1px solid #2b5542}",
			".wxc-qrbox{margin:10px 0;padding:10px;border:1px solid #33424c;border-radius:8px;background:#fff;text-align:center}.wxc-qr{display:block;width:230px;max-width:100%;margin:0 auto}.wxc-qrnote{margin-top:7px;color:#53616a;font-size:11px}",
			".wxc-analysis{background:#172129;border:1px solid #2b3b46;border-radius:8px;padding:10px;margin-top:8px}.wxc-report-title{font-size:13px;color:#dce5ea;margin:0 0 6px}.wxc-summary{color:#aebdc6;line-height:1.65}.wxc-report{line-height:1.7;color:#cbd4da}.wxc-report h1{font-size:16px}.wxc-report h2{font-size:13px;color:#9cc6af;margin:16px 0 5px}.wxc-report h3{font-size:12px;color:#aebdc6;margin:12px 0 4px}.wxc-report p{margin:5px 0}.wxc-report ul{margin:5px 0;padding-left:18px}.wxc-table-line{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10px;color:#96a7b1;white-space:pre-wrap}",
			"@media(max-width:560px){.wxc-panel{width:100vw}.wxc-form{grid-template-columns:1fr}}"
		].join("\n");

		function h(tag, cls, text) {
			var el = document.createElement(tag);
			if (cls) el.className = cls;
			if (text !== undefined) el.textContent = text;
			return el;
		}

		function field(label, input, full) {
			var box = h("label", "wxc-field" + (full ? " full" : ""));
			box.appendChild(h("span", "wxc-label", label));
			box.appendChild(input);
			return box;
		}

		function renderMarkdown(text) {
			var root = h("div", "wxc-report");
			var list = null;
			String(text || "").split("\n").forEach(function (raw) {
				var line = raw.trimEnd();
				if (!line.trim()) { list = null; return; }
				var match = line.match(/^(#{1,3})\s+(.+)$/);
				if (match) { list = null; root.appendChild(h("h" + match[1].length, "", match[2])); return; }
				if (/^[-*]\s+/.test(line)) {
					if (!list) { list = h("ul"); root.appendChild(list); }
					list.appendChild(h("li", "", line.replace(/^[-*]\s+/, "")));
					return;
				}
				list = null;
				if (/^\|.*\|$/.test(line)) root.appendChild(h("div", "wxc-table-line", line));
				else root.appendChild(h("p", "", line));
			});
			return root;
		}

		function apply(ctx) {
			ctx.effect(function () {
				var style = h("style"); style.textContent = CSS; document.head.appendChild(style);
				var tab = h("div", "wxc-tab", "公众号"); document.body.appendChild(tab);
				var mask = h("div", "wxc-mask"); var panel = h("div", "wxc-panel");
				mask.style.display = panel.style.display = "none"; document.body.appendChild(mask); document.body.appendChild(panel);
				var head = h("div", "wxc-head"); head.appendChild(h("b", "", "公众号采集与分析"));
				var refresh = h("span", "", "⟳"); refresh.title = "刷新"; var close = h("span", "", "✕"); close.style.marginLeft = "0"; head.appendChild(refresh); head.appendChild(close); panel.appendChild(head);
				var toast = h("div", "wxc-toast"); toast.style.display = "none"; panel.appendChild(toast);
				var body = h("div", "wxc-body"); panel.appendChild(body);
				var state = null; var error = ""; var actionError = ""; var busy = false; var candidates = []; var ticks = 0; var settingsOpen = false; var activeReport = null; var profileName = "";

				function open(value) { mask.style.display = panel.style.display = value ? "" : "none"; if (value) load(); }
				function showToast(text) { toast.textContent = text; toast.style.display = ""; setTimeout(function () { toast.style.display = "none"; }, 3000); }
				function button(text, action, primary, allowOffline) { var el = h("button", "wxc-btn" + (primary ? " primary" : ""), text); el.disabled = busy || (!allowOffline && state && !state.available); el.addEventListener("click", action); return el; }
				function post(payload) {
					actionError = ""; busy = true; render();
					return fetch(ACTION_URL, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) })
						.then(function (res) { return res.json(); })
						.then(function (envelope) { if (!envelope || !envelope.ok) throw new Error(envelope && envelope.value && envelope.value.error || "请求失败"); return envelope.value; })
						.finally(function () { busy = false; });
				}
				function refreshQr(img, note) {
					fetch(QRCODE_URL, { cache: "no-store" }).then(function (res) { return res.json(); }).then(function (envelope) {
						if (!envelope || !envelope.ok) throw new Error("二维码读取失败");
						if (envelope.value && envelope.value.ready && envelope.value.img) { img.src = envelope.value.img; img.style.display = "block"; note.textContent = "请用微信扫码；扫码成功后本面板会自动刷新。"; }
						else { img.style.display = "none"; note.textContent = "正在加载微信登录二维码…"; }
					}).catch(function (err) { img.style.display = "none"; note.textContent = String(err && err.message || err); });
				}
				function section(title) { var sec = h("div", "wxc-sec"); sec.appendChild(h("div", "wxc-title", title)); return sec; }
				function fail(err) { actionError = String(err && err.message || err); render(); }

				function loadReport(reportId) {
					busy = true; render();
					fetch(ANALYSIS_URL + "?reportId=" + encodeURIComponent(reportId), { cache: "no-store" })
						.then(function (res) { return res.json(); })
						.then(function (envelope) { if (!envelope || !envelope.ok) throw new Error(envelope && envelope.value && envelope.value.error || "报告读取失败"); activeReport = envelope.value; })
						.catch(fail).finally(function () { busy = false; render(); });
				}

				function appendAnalysisSettings() {
					var analysis = state && state.analysis || {}; var config = analysis.settings || {}; var credential = analysis.credential || {};
					var sec = section("博主分析设置");
					var line = h("div", "wxc-row"); line.appendChild(h("i", "wxc-dot " + (credential.configured ? "ok" : "bad"))); var label = h("div", "wxc-grow", credential.configured ? "DeepSeek API 已配置" : "尚未配置 DeepSeek API Key"); line.appendChild(label); line.appendChild(button(settingsOpen ? "收起" : "设置", function () { settingsOpen = !settingsOpen; render(); }, false, true)); sec.appendChild(line);
					if (credential.source) sec.appendChild(h("div", "wxc-meta", "凭据来源：" + credential.source + " · 引用：" + (credential.ref || "DEEPSEEK_API_KEY")));
					if (analysis.error || credential.error) sec.appendChild(h("div", "wxc-error", analysis.error || credential.error));
					if (settingsOpen) {
						var form = h("div", "wxc-form");
						var baseUrl = h("input", "wxc-input"); baseUrl.value = config.baseUrl || "https://api.deepseek.com"; baseUrl.placeholder = "https://api.deepseek.com";
						var model = h("input", "wxc-input"); model.value = config.model || "deepseek-chat";
						var key = h("input", "wxc-input"); key.type = "password"; key.autocomplete = "new-password"; key.placeholder = credential.configured ? "留空则保留现有密钥" : "输入 API Key";
						var skill = h("select", "wxc-select"); (analysis.skills || []).forEach(function (item) { var option = h("option", "", item.name); option.value = item.id; option.selected = item.id === config.skillId; skill.appendChild(option); });
						var limit = h("input", "wxc-input"); limit.type = "number"; limit.min = "1"; limit.max = "20"; limit.value = String(config.maxArticles || 12);
						form.appendChild(field("API 地址", baseUrl, true)); form.appendChild(field("模型", model)); form.appendChild(field("每次文章数（1-20）", limit)); form.appendChild(field("分析 Skill", skill, true)); form.appendChild(field("API Key（只写入 DSH credentials）", key, true)); sec.appendChild(form);
						var actions = h("div", "wxc-actions"); actions.style.marginTop = "9px";
						actions.appendChild(button("保存设置", function () { post({ action: "analysis_config_save", baseUrl: baseUrl.value.trim(), model: model.value.trim(), skillId: skill.value, maxArticles: Number(limit.value), apiKey: key.value.trim() }).then(function () { key.value = ""; showToast("分析设置已保存"); load(); }).catch(fail); }, true, true));
						actions.appendChild(button("测试连接", function () { post({ action: "analysis_test" }).then(function (value) { showToast(value.connected ? "DeepSeek 连接成功" : "DeepSeek 返回异常"); load(); }).catch(fail); }, false, true));
						if (credential.configured && credential.writable) { var remove = button("删除密钥", function () { if (!window.confirm("删除 DSH credentials 中的 " + (credential.ref || "DEEPSEEK_API_KEY") + "？分析报告不会删除。")) return; post({ action: "analysis_config_remove_key" }).then(function () { showToast("DeepSeek API Key 已删除"); load(); }).catch(fail); }, false, true); remove.classList.add("danger"); actions.appendChild(remove); }
						sec.appendChild(actions);
					}
					sec.appendChild(h("div", "wxc-note", "只有你明确点击“分析”时，所选公众号的有界正文片段才会发送到该 API 地址。密钥不会进入工具返回、报告或日志。"));
					body.appendChild(sec);
				}

				function appendReports() {
					var reports = state && state.analysis && state.analysis.reports || [];
					var sec = section(activeReport ? "分析报告" : "最近分析");
					if (activeReport) {
						var back = button("← 返回报告列表", function () { activeReport = null; render(); }, false, true); sec.appendChild(back);
						var box = h("div", "wxc-analysis"); box.appendChild(h("div", "wxc-report-title", activeReport.account + " · " + (activeReport.skill && activeReport.skill.name || "内容分析"))); box.appendChild(h("div", "wxc-meta", (activeReport.generatedAt || "") + " · " + (activeReport.model || "") + " · " + ((activeReport.coverage && activeReport.coverage.sentArticles) || 0) + " 篇"));
						if (activeReport.limitation) box.appendChild(h("div", "wxc-note", activeReport.limitation));
						box.appendChild(renderMarkdown(activeReport.markdown)); sec.appendChild(box);
					} else if (!reports.length) sec.appendChild(h("div", "wxc-empty", "还没有博主分析报告。先抓取文章，再在账号旁点击“分析”。"));
					else reports.forEach(function (report) { var card = h("div", "wxc-card"); var title = h("div", "wxc-report-title", report.account); card.appendChild(title); var summary = report.summary && (report.summary.positioning || report.summary.coreMethod); if (summary) card.appendChild(h("div", "wxc-summary", summary)); card.appendChild(h("div", "sub", (report.generatedAt || "") + " · " + ((report.skill && report.skill.name) || "内容分析") + " · " + ((report.coverage && report.coverage.sentArticles) || 0) + " 篇")); var actions = h("div", "wxc-actions"); actions.style.marginTop = "6px"; actions.appendChild(button("查看报告", function () { loadReport(report.id); }, false, true)); card.appendChild(actions); sec.appendChild(card); });
					body.appendChild(sec);
				}

				function appendCredentials() {
					var creds = state && state.credentials;
					if (!creds) return;
					var sec = section("凭证档案（多套 token 切换）");
					var profiles = creds.profiles || [];
					if (!profiles.length) sec.appendChild(h("div", "wxc-empty", "还没有凭证档案。扫码登录成功后会自动保存为一套档案。"));
					profiles.forEach(function (p) {
						var row = h("div", "wxc-candidate");
						var txt = h("div", "txt");
						txt.appendChild(h("b", "", (p.active ? "● " : "") + p.name));
						txt.appendChild(h("div", "wxc-meta", (p.active ? "当前使用" : "备用") + (p.lastUsedAt ? " · 最近使用 " + p.lastUsedAt : "") + (p.source === "migrated" ? " · 迁移自旧凭证" : "")));
						row.appendChild(txt);
						if (!p.active) {
							row.appendChild(button("切换", function () { post({ action: "credential_activate", name: p.name }).then(function () { showToast("已切换到 " + p.name); load(); }).catch(fail); }, true));
							var del = button("删除", function () { if (!window.confirm("删除凭证档案「" + p.name + "」？此操作不可恢复。")) return; post({ action: "credential_remove", name: p.name }).then(function () { showToast("已删除 " + p.name); load(); }).catch(fail); });
							del.classList.add("danger"); row.appendChild(del);
						}
						sec.appendChild(row);
					});
					sec.appendChild(h("div", "wxc-note", "凭证只能通过扫码登录进入档案；token/cookie 不经过本面板和任何工具。"));
					body.appendChild(sec);
				}

				function appendPolicy() {
					var policy = state && state.policy;
					if (!policy) return;
					var sec = section("抓取策略（请求节奏与限流保护）");
					if (policy.cooldownActive) { var cd = h("div", "wxc-row"); cd.appendChild(h("i", "wxc-dot bad")); cd.appendChild(h("span", "", "限流冷却中 · 剩约 " + policy.cooldownRemainingMinutes + " 分钟（截止 " + (policy.cooldownUntil || "未知") + "）")); sec.appendChild(cd); }
					var form = h("div", "wxc-form");
					var accountDelay = h("input", "wxc-input"); accountDelay.type = "number"; accountDelay.min = "0"; accountDelay.max = "300"; accountDelay.value = String(policy.accountDelaySeconds);
					var pageDelay = h("input", "wxc-input"); pageDelay.type = "number"; pageDelay.min = "0"; pageDelay.max = "120"; pageDelay.value = String(policy.pageDelaySeconds);
					var jitter = h("input", "wxc-input"); jitter.type = "number"; jitter.min = "0"; jitter.max = "1"; jitter.step = "0.1"; jitter.value = String(policy.jitterRatio);
					var hours = h("input", "wxc-input"); hours.type = "number"; hours.min = "0.5"; hours.max = "72"; hours.step = "0.5"; hours.value = String(policy.freqControlCooldownHours);
					form.appendChild(field("账号间隔（秒）", accountDelay)); form.appendChild(field("翻页间隔（秒）", pageDelay)); form.appendChild(field("随机抖动（0-1）", jitter)); form.appendChild(field("限流冷却（小时）", hours)); sec.appendChild(form);
					var actions = h("div", "wxc-actions"); actions.style.marginTop = "9px";
					actions.appendChild(button("保存策略", function () { post({ action: "policy_save", accountDelaySeconds: Number(accountDelay.value), pageDelaySeconds: Number(pageDelay.value), jitterRatio: Number(jitter.value), freqControlCooldownHours: Number(hours.value) }).then(function () { showToast("抓取策略已保存"); load(); }).catch(fail); }, true));
					if (policy.cooldownActive) actions.appendChild(button("解除冷却", function () { if (!window.confirm("手动解除限流冷却？风控窗口内立即抓取可能加重处罚。")) return; post({ action: "policy_save", clearCooldown: true }).then(function () { showToast("冷却已解除"); load(); }).catch(fail); }));
					sec.appendChild(actions);
					sec.appendChild(h("div", "wxc-note", "遇到微信频率限制会自动停止本轮抓取并进入冷却；冷却期内手动和定时抓取都会被拒绝。"));
					body.appendChild(sec);
				}

				function appendSources() {
					var sources = state && state.sources;
					if (!sources) return;
					var sec = section("信源管理（RSS / 外部源）");
					if (!sources.length) sec.appendChild(h("div", "wxc-empty", "还没有外部信源。在下方粘贴 RSS 链接添加。"));
					sources.forEach(function (s) {
						var row = h("div", "wxc-candidate");
						var txt = h("div", "txt");
						txt.appendChild(h("b", "", s.name));
						txt.appendChild(h("div", "wxc-meta", s.type + (s.enabled ? "" : " · 已停用")));
						row.appendChild(txt);
						row.appendChild(button("同步", function () { post({ action: "source_sync", sourceId: s.id }).then(function (v) { showToast("同步 " + (v.itemsSynced || 0) + " 条"); load(); }).catch(fail); }));
						if (s.type !== "bilibili_space" && s.type !== "bilibili_video") { var del = button("删除", function () { if (!window.confirm("移除信源「" + s.name + "」？已采集的文章会保留。")) return; post({ action: "source_remove", sourceId: s.id }).then(function () { showToast("已移除 " + s.name); load(); }).catch(fail); }); del.classList.add("danger"); row.appendChild(del); }
						sec.appendChild(row);
					});
					var form = h("div", "wxc-form");
					var urlInput = h("input", "wxc-input"); urlInput.placeholder = "RSS 链接（如 WeWe RSS 的 feed 地址）";
					var nameInput = h("input", "wxc-input"); nameInput.placeholder = "名称（可空）";
					form.appendChild(field("RSS 链接", urlInput, true)); form.appendChild(field("名称（可空）", nameInput, true)); sec.appendChild(form);
					var actions = h("div", "wxc-actions"); actions.style.marginTop = "9px";
					actions.appendChild(button("添加 RSS 信源", function () { if (!urlInput.value.trim()) return; post({ action: "source_add", url: urlInput.value.trim(), name: nameInput.value.trim(), sourceType: "rss_feed" }).then(function (v) { showToast("已添加并同步 " + (v.synced || 0) + " 条"); urlInput.value = ""; nameInput.value = ""; load(); }).catch(fail); }, true));
					actions.appendChild(button("全部同步", function () { post({ action: "source_sync" }).then(function (v) { showToast("同步 " + (v.itemsSynced || 0) + " 条"); load(); }).catch(fail); }));
					sec.appendChild(actions);
					sec.appendChild(h("div", "wxc-note", "RSS 信源（如 WeWe RSS 公众号订阅）是公众号抓取之外的第二水源，限流期间也能独立更新。"));
					body.appendChild(sec);
				}

				function appendAccountManagement(authValid) {
					var acc = section("公众号与博主分析"); var search = h("div", "wxc-search"); var input = h("input", "wxc-input"); input.placeholder = authValid ? "输入公众号名称" : "扫码登录后可搜索"; input.disabled = !authValid; var searchBtn = button("搜索", function () { if (!input.value.trim()) return; post({ action: "account_search", query: input.value.trim() }).then(function (value) { candidates = value.candidates || []; render(); }).catch(fail); }); if (!authValid) searchBtn.disabled = true; search.appendChild(input); search.appendChild(searchBtn); acc.appendChild(search);
					candidates.forEach(function (candidate) { var row = h("div", "wxc-candidate"); var txt = h("div", "txt"); txt.appendChild(h("b", "", candidate.name)); txt.appendChild(h("div", "wxc-meta", candidate.alias || candidate.signature || "")); row.appendChild(txt); var add = button("添加", function () { post({ action: "account_add", name: candidate.name, fakeid: candidate.fakeid }).then(function () { candidates = []; showToast("已添加 " + candidate.name); load(); }).catch(fail); }); row.appendChild(add); acc.appendChild(row); });
					(state.accounts || []).forEach(function (account) { var row = h("div", "wxc-candidate"); var txt = h("div", "txt"); txt.appendChild(h("b", "", account.name)); txt.appendChild(h("div", "wxc-meta", account.articleCount + " 篇已采集" + (account.latestUpdateTime ? " · " + account.latestUpdateTime : ""))); row.appendChild(txt); var analyze = button("分析", function () { var configured = state.analysis && state.analysis.credential && state.analysis.credential.configured; if (!configured) { settingsOpen = true; actionError = "请先配置 DeepSeek API Key"; render(); return; } if (state.runtime && state.runtime.upgradeAvailable) { actionError = "采集运行时需要先更新，才能读取博主分析语料"; render(); return; } var config = state.analysis.settings || {}; if (!window.confirm("将把“" + account.name + "”最近最多 " + (config.maxArticles || 12) + " 篇文章的有界正文片段发送到 " + (config.baseUrl || "DeepSeek API") + " 做内容方法分析。是否继续？")) return; post({ action: "analysis_run", account: account.name, skillId: config.skillId, limit: config.maxArticles }).then(function (report) { activeReport = report; showToast("“" + account.name + "”分析完成"); load(); }).catch(fail); }, true); if (!account.articleCount || (state.runtime && state.runtime.upgradeAvailable)) analyze.disabled = true; row.appendChild(analyze); acc.appendChild(row); });
					if (!(state.accounts || []).length && !candidates.length) acc.appendChild(h("div", "wxc-empty", "还没有跟踪公众号。扫码登录后搜索并添加。"));
					acc.appendChild(h("div", "wxc-note", "分析至少 5 篇有效长文才适合归纳长期方法；不足时报告会强制标注小样本。")); body.appendChild(acc);
				}

				function render() {
					body.textContent = ""; tab.classList.toggle("live", !!(state && state.available));
					if (error) { var es = section("连接状态"); es.appendChild(h("div", "wxc-error", error)); es.appendChild(h("div", "wxc-note", "先启动本机采集后端；DeepSeek 设置和已有分析报告仍可独立查看。")); body.appendChild(es); if (state) { appendAnalysisSettings(); appendReports(); } return; }
					if (!state) { body.appendChild(h("div", "wxc-sec wxc-empty", "正在读取采集器状态…")); return; }
					if (busy) body.appendChild(h("div", "wxc-toast", "正在处理，请稍候…"));
					if (actionError) { var ae = section("操作未完成"); ae.appendChild(h("div", "wxc-error", actionError)); body.appendChild(ae); }
					if (!state.available) {
						var off = section("连接状态"); var runtime = state.runtime || {}; off.appendChild(h("div", "wxc-error", state.error || "采集器未启动"));
						if (runtime.supported === false) off.appendChild(h("div", "wxc-note", "当前内置运行时只支持 Apple Silicon / Intel Mac；你仍可在插件配置中连接自己运行的采集 API。"));
						else off.appendChild(h("div", "wxc-note", runtime.configured && runtime.installed ? "本机采集运行时已安装，可以直接启动。" : "首次使用需要明确安装本地运行时。插件会部署无凭证、无用户数据的采集代码。"));
						var offActions = h("div", "wxc-actions");
						if (!(runtime.configured && runtime.installed) && runtime.supported !== false) offActions.appendChild(button("安装本地运行时", function () { if (!window.confirm("将下载并校验 uv、部署随插件打包的采集代码，并创建当前用户的 launchd 服务。不会读取或返回微信 token/cookie。是否继续？")) return; post({ action: "runtime_install" }).then(function () { showToast("运行时安装完成"); load(); }).catch(fail); }, true, true));
						if (runtime.upgradeAvailable) offActions.appendChild(button("更新采集运行时", function () { if (!window.confirm("将把本机采集运行时更新到插件固定版本，并重启采集服务。历史文章和登录态保留。是否继续？")) return; post({ action: "runtime_install" }).then(function () { showToast("采集运行时已更新"); load(); }).catch(fail); }, true, true));
						else if (runtime.configured && runtime.installed) offActions.appendChild(button("启动采集服务", function () { post({ action: "runtime_start" }).then(function () { showToast("采集服务已启动"); load(); }).catch(fail); }, true, true));
						off.appendChild(offActions); body.appendChild(off); appendAnalysisSettings(); appendReports(); return;
					}

					var status = section("运行状态"); var authValid = !!(state.auth && state.auth.valid); var loginRunning = !!(state.login && state.login.running); var auth = h("div", "wxc-row"); auth.appendChild(h("i", "wxc-dot " + (authValid ? "ok" : "bad"))); auth.appendChild(h("span", "", authValid ? "微信凭证有效" : loginRunning ? "等待微信扫码" : "尚未登录或凭证已失效")); status.appendChild(auth);
					if (loginRunning) { var qrbox = h("div", "wxc-qrbox"); var qr = h("img", "wxc-qr"); qr.alt = "微信公众号登录二维码"; qr.style.display = "none"; var qrnote = h("div", "wxc-qrnote", "正在加载微信登录二维码…"); qrbox.appendChild(qr); qrbox.appendChild(qrnote); status.appendChild(qrbox); refreshQr(qr, qrnote); }
					if (!loginRunning && state.login && state.login.error) status.appendChild(h("div", "wxc-error", state.login.error));
					var crawl = h("div", "wxc-row"); crawl.appendChild(h("i", "wxc-dot " + (state.crawl && state.crawl.running ? "ok" : ""))); crawl.appendChild(h("span", "", state.crawl && state.crawl.running ? "正在抓取 " + state.crawl.done + "/" + state.crawl.total + " · " + (state.crawl.current || "") : "抓取空闲 · 新增 " + ((state.crawl && state.crawl.newArticles) || 0))); status.appendChild(crawl);
					if (!authValid && !loginRunning) { var pn = h("input", "wxc-input"); pn.placeholder = "凭证档案名（可空，扫码成功后自动命名）"; pn.value = profileName; pn.addEventListener("input", function () { profileName = pn.value; }); status.appendChild(field("新凭证档案名（可空）", pn, true)); }
					var actions = h("div", "wxc-actions"); if (!authValid && !loginRunning) actions.appendChild(button("扫码登录", function () { post({ action: "login_start", profileName: profileName.trim() }).then(function () { showToast("请扫描面板中的二维码"); load(); }).catch(fail); }, true)); if (authValid) actions.appendChild(button("检查凭证", function () { post({ action: "auth_check" }).then(function () { showToast("凭证状态已刷新"); load(); }).catch(fail); })); if (authValid && !loginRunning) actions.appendChild(button("扫码新增凭证", function () { post({ action: "login_start", profileName: profileName.trim() }).then(function () { showToast("请扫描面板中的二维码，新凭证会存为一套档案"); load(); }).catch(fail); })); var crawlButton = button("开始抓取", function () { post({ action: "crawl_start" }).then(function () { showToast("抓取已启动"); load(); }).catch(fail); }, authValid); if (!authValid) crawlButton.disabled = true; actions.appendChild(crawlButton); actions.appendChild(button("同步到素材板", function () { post({ action: "sync_import", limit: 50 }).then(function (value) { showToast("新增 " + (value.imported || []).length + " 张来源卡"); load(); }).catch(fail); }));
					if (state.runtime && state.runtime.upgradeAvailable) actions.appendChild(button("更新采集运行时", function () { if (!window.confirm("将更新采集运行时并重启服务。历史文章和登录态保留。是否继续？")) return; post({ action: "runtime_install" }).then(function () { showToast("采集运行时已更新"); load(); }).catch(fail); }, true)); if (state.runtime && state.runtime.running) actions.appendChild(button("停止后台服务", function () { post({ action: "runtime_stop" }).then(function () { showToast("后台服务已停止"); load(); }).catch(fail); })); if (state.runtime && state.runtime.configured) actions.appendChild(button("停用常驻服务", function () { if (!window.confirm("将停止公众号采集后台服务并移走 launchd 配置。采集代码、历史文章和登录态都会保留。是否继续？")) return; post({ action: "runtime_unconfigure" }).then(function () { showToast("常驻服务已停用，数据仍保留"); load(); }).catch(fail); })); status.appendChild(actions); if (state.runtime && state.runtime.upgradeAvailable) status.appendChild(h("div", "wxc-note", "当前采集运行时不含博主语料接口，请先更新；历史数据会保留。")); status.appendChild(h("div", "wxc-note", "抓取、分析都不是发布；发表仍需排版、草稿箱和人工确认。")); body.appendChild(status);

					var stats = section("内容池"); var grid = h("div", "wxc-stats"); [[(state.accounts || []).length, "账号"], [(state.pool && state.pool.wechatCandidates) || 0, "候选"], [(state.analysis && state.analysis.reports && state.analysis.reports.length) || 0, "分析报告"]].forEach(function (pair) { var box = h("div", "wxc-stat"); box.appendChild(h("b", "", String(pair[0] || 0))); box.appendChild(h("small", "", pair[1])); grid.appendChild(box); }); stats.appendChild(grid); body.appendChild(stats);
					appendCredentials(); appendPolicy(); appendSources(); appendAnalysisSettings(); appendAccountManagement(authValid); appendReports();
					var items = section("最近素材"); (state.recentItems || []).forEach(function (item) { var card = h("div", "wxc-card"); var link = h("a", "", item.title || "未命名"); link.href = item.url || "#"; link.target = "_blank"; link.rel = "noopener noreferrer"; if (!item.url) link.addEventListener("click", function (event) { event.preventDefault(); }); card.appendChild(link); card.appendChild(h("div", "sub", item.sourceName + " · " + (item.publishedAt || "时间未知") + " · " + item.humanDecision)); items.appendChild(card); }); if (!(state.recentItems || []).length) items.appendChild(h("div", "wxc-empty", "内容池还没有公众号素材。")); body.appendChild(items);
				}

				function load() { if (busy) return; error = ""; fetch(STATE_URL, { cache: "no-store" }).then(function (res) { return res.json(); }).then(function (envelope) { if (!envelope || !envelope.ok) throw new Error(envelope && envelope.value && envelope.value.error || "状态读取失败"); state = envelope.value; render(); }).catch(function (err) { error = String(err && err.message || err); render(); }); }
				tab.addEventListener("click", function () { open(true); }); mask.addEventListener("click", function () { open(false); }); close.addEventListener("click", function () { open(false); }); refresh.addEventListener("click", load);
				var timer = setInterval(function () { ticks += 1; if (!document.hidden && panel.style.display !== "none" && !busy && ((state && state.login && state.login.running) || ticks % 4 === 0)) load(); }, 2000);
				load();
				return function () { clearInterval(timer); tab.remove(); mask.remove(); panel.remove(); style.remove(); };
			}, "dsh-wechat-collector mount");
		}
		exports.apply = apply;
		return module.exports;
	}
});
