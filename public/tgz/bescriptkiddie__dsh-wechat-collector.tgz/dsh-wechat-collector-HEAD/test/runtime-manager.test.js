import assert from "node:assert/strict";
import { mkdtemp, readFile, readdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { installRuntime, RUNTIME_COMMIT, runtimeMetadata, stopRuntime, UV_VERSION } from "../scripts/runtime-manager.mjs";

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");

test("runtime metadata discloses pinned sources without credentials", () => {
	const value = runtimeMetadata();
	assert.equal(value.commit, RUNTIME_COMMIT);
	assert.equal(value.uvVersion, UV_VERSION);
	assert.equal(value.credentialsBundled, false);
	assert.equal(value.userDataBundled, false);
	assert.match(value.source, /^https:\/\/github\.com\//);
});

test("automatic provisioning refuses paths outside the managed root before downloading", async () => {
	const unmanaged = await mkdtemp(join(tmpdir(), "dsh-wechat-unmanaged-"));
	await assert.rejects(
		installRuntime({ projectRoot: join(unmanaged, "runtime") }),
		/自动安装只允许写入/
	);
});

test("runtime service management rejects unsafe launchd labels", async () => {
	await assert.rejects(stopRuntime({ label: "../unexpected" }), /不安全字符/);
});

test("vendored runtime receipt matches the pinned commit and excludes user state", async () => {
	const upstream = JSON.parse(await readFile(join(packageRoot, "runtime", "UPSTREAM.json"), "utf8"));
	assert.equal(upstream.commit, RUNTIME_COMMIT);
	const files = await readdir(join(packageRoot, "runtime"));
	assert.ok(files.includes("data-templates"));
	assert.equal(files.includes("data"), false);
	assert.equal(files.includes(".env.local"), false);
});
