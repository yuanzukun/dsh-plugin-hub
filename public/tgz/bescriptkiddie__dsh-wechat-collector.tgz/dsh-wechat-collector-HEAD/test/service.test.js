import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile } from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { WechatCollectorService } from "../lib/service.js";

function json(res, value, status = 200) {
	res.writeHead(status, { "content-type": "application/json" });
	res.end(JSON.stringify(value));
}

async function fixture({ failOverview = false, failQr = false } = {}) {
	const requests = [];
	const server = createServer(async (req, res) => {
		const chunks = [];
		for await (const chunk of req) chunks.push(chunk);
		requests.push({ method: req.method, url: req.url, body: Buffer.concat(chunks).toString("utf8") });
		if (req.url === "/api/auth/status") return json(res, { has_credentials: true, valid: true, checked_at: "now", token_hint: "must-not-leak" });
		if (req.url === "/api/auth/check") return json(res, { has_credentials: true, valid: true, checked_at: "fresh", token_hint: "must-not-leak" });
		if (req.url === "/api/auth/login" && req.method === "POST") return json(res, { detail: "正在加载登录页面" });
		if (req.url === "/api/auth/login/status") return json(res, { running: true, done: false, error: "", started_at: "now", finished_at: "" });
		if (req.url === "/api/auth/qrcode") return failQr ? json(res, { detail: "QR is warming up" }, 503) : json(res, { img: "data:image/png;base64,cWItbm90LWEtc2VjcmV0", refreshed_at: "now" });
		if (req.url === "/api/crawl/status") return json(res, { running: false, total: 2, done: 2, current: "", errors: [], new_articles: 1 });
		if (req.url === "/api/crawl" && req.method === "POST") return json(res, { status: "started", message: "ok" });
		if (req.url === "/api/content-loop/overview") return failOverview ? json(res, { detail: "temporary" }, 503) : json(res, { content_items: 3, wechat_candidates: 2, feedback_events: 1 });
		if (req.url === "/api/accounts") return json(res, [{ name: "记忆承载3", fakeid: "secret-ish-id", has_articles: true, article_count: 6, latest_update_time: "today" }]);
		if (req.url.startsWith("/api/accounts/") && req.url.includes("/corpus?")) {
			const articles = Array.from({ length: 6 }, (_value, index) => ({
				id: `wechat_article:${index + 1}`,
				title: `样本文章${index + 1}`,
				url: `https://mp.weixin.qq.com/s/example-${index + 1}`,
				published_at: `2026-08-${String(20 + index).padStart(2, "0")}`,
				content_markdown: `这是第${index + 1}篇正文。` + "方法、证据与案例。".repeat(120)
			}));
			return json(res, { account: "记忆承载3", articles, coverage: { total_articles: 6, returned_articles: 6, with_content: 6, substantial_articles: 6, date_from: "2026-08-20", date_to: "2026-08-25" } });
		}
		if (req.url === "/api/content-loop/sync-wechat") return json(res, { result: { normalized: 1, total: 1 } });
		if (req.url.startsWith("/api/content-loop/items?")) return json(res, [{ id: "wechat_article:1", title: "长期主义", source_name: "记忆承载3", published_at: "2026-08-25 09:00", url: "https://mp.weixin.qq.com/s/example", summary: "短摘要", tags: ["AI"], human_decision: "candidate" }]);
		if (req.url === "/api/content-loop/feedback") return json(res, { event: { event: "item_reviewed" } });
		return json(res, { detail: "not found" }, 404);
	});
	await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
	return { server, requests, baseUrl: `http://127.0.0.1:${server.address().port}` };
}

test("status is secret-safe", async (t) => {
	const fx = await fixture();
	t.after(() => fx.server.close());
	const service = new WechatCollectorService({ collectorBaseUrl: fx.baseUrl });
	const value = await service.status();
	assert.equal(value.available, true);
	assert.equal(value.auth.valid, true);
	assert.equal(value.accounts[0].fakeid, undefined);
	assert.equal(JSON.stringify(value).includes("must-not-leak"), false);
});

test("import is idempotent and writes a secret-free receipt", async (t) => {
	const fx = await fixture();
	t.after(() => fx.server.close());
	const root = await mkdtemp(join(tmpdir(), "dsh-wechat-collector-"));
	await mkdir(join(root, "board"), { recursive: true });
	await import("node:fs/promises").then(({ writeFile }) => writeFile(join(root, "my-voice.md"), "# voice\n"));
	const service = new WechatCollectorService({ collectorBaseUrl: fx.baseUrl, contentStudioRoot: root });
	const first = await service.importToStudio({ limit: 10 });
	const second = await service.importToStudio({ limit: 10 });
	assert.equal(first.imported.length, 1);
	assert.equal(second.imported.length, 0);
	assert.equal(second.skipped.length, 1);
	const card = await readFile(first.imported[0].path, "utf8");
	assert.match(card, /不是本人文章，也不是已核验事实/);
	const receipt = JSON.parse(await readFile(first.receiptPath, "utf8"));
	assert.deepEqual(receipt.checks, { credentials_exposed: false, full_content_copied: false, source_cards_only: true });
});

test("feedback uses the upstream request contract", async (t) => {
	const fx = await fixture();
	t.after(() => fx.server.close());
	const service = new WechatCollectorService({ collectorBaseUrl: fx.baseUrl });
	await service.feedback({ itemId: "wechat_article:1", humanDecision: "adopted", feedbackNote: "可用" });
	const request = fx.requests.find((item) => item.url === "/api/content-loop/feedback");
	assert.equal(request.method, "POST");
	assert.deepEqual(JSON.parse(request.body), {
		item_id: "wechat_article:1",
		event: "item_reviewed",
		human_decision: "adopted",
		feedback_note: "可用",
		suggested_action: "",
		channel: "dsh-wechat-collector",
		weight: 1
	});
});

test("optional status endpoint failures stay visible without taking the plugin offline", async (t) => {
	const fx = await fixture({ failOverview: true });
	t.after(() => fx.server.close());
	const service = new WechatCollectorService({ collectorBaseUrl: fx.baseUrl });
	const value = await service.status();
	assert.equal(value.available, true);
	assert.equal(value.pool.wechatCandidates, 0);
	assert.match(value.warnings.join("\n"), /overview/);
});

test("QR data is confined to the panel-only method", async (t) => {
	const fx = await fixture();
	t.after(() => fx.server.close());
	const service = new WechatCollectorService({ collectorBaseUrl: fx.baseUrl });
	const login = await service.loginStart();
	const status = await service.status();
	const qr = await service.loginQr();
	assert.equal(login.login.running, true);
	assert.equal(JSON.stringify(login).includes("base64"), false);
	assert.equal(JSON.stringify(status).includes("base64"), false);
	assert.equal(qr.ready, true);
	assert.match(qr.img, /^data:image\/png;base64,/);
});

test("QR warm-up stays a successful loading state", async (t) => {
	const fx = await fixture({ failQr: true });
	t.after(() => fx.server.close());
	const service = new WechatCollectorService({ collectorBaseUrl: fx.baseUrl });
	const qr = await service.loginQr();
	assert.equal(qr.ready, false);
	assert.equal(qr.img, "");
	assert.match(qr.error, /QR is warming up/);
	assert.equal(qr.credentialsExposed, false);
});

test("author analysis uses DSH credentials and stores a secret-free report", async (t) => {
	const fx = await fixture();
	t.after(() => fx.server.close());
	const llmRequests = [];
	const llmServer = createServer(async (req, res) => {
		const chunks = [];
		for await (const chunk of req) chunks.push(chunk);
		const raw = Buffer.concat(chunks).toString("utf8");
		const body = JSON.parse(raw);
		llmRequests.push({ authorization: req.headers.authorization, body });
		const isProbe = body.messages.some((message) => String(message.content).includes("返回 {\"ok\":true}"));
		const content = isProbe ? JSON.stringify({ ok: true }) : JSON.stringify({
			summary: { positioning: "用案例讲内容方法", coreMethod: "问题—证据—行动", readerValue: "获得可执行步骤" },
			reportMarkdown: "## 1. 一句话定位\n- 用案例讲内容方法。\n## 2. 选题系统\n- 方法问题；证据文章：样本文章1、样本文章2。\n## 3. 标题模式\n- 问题型；证据文章：样本文章1。\n## 4. 开头模板\n- 场景进入；证据文章：样本文章2。\n## 5. 正文结构\n- 问题—证据—行动；证据文章：样本文章3。\n## 6. 金句和句式\n- 短结论；证据文章：样本文章4。\n## 7. 可复用写作组件\n- 结构示例：先问题再证据。\n## 8. 发布前检查清单\n- 是否有真实证据。\n## 9. 下一步\n- 继续补充历史文章。"
		});
		return json(res, { model: "deepseek-chat", choices: [{ message: { content } }] });
	});
	await new Promise((resolve) => llmServer.listen(0, "127.0.0.1", resolve));
	t.after(() => llmServer.close());

	let secret = "";
	const credentials = {
		describe: async () => ({ configured: secret.length > 0, source: secret ? "file" : undefined, writable: true }),
		resolve: async () => secret ? ({ value: secret, source: "file" }) : undefined,
		set: async (_ref, value) => { secret = value; },
		unset: async () => { secret = ""; }
	};
	const analysisRoot = await mkdtemp(join(tmpdir(), "dsh-wechat-analysis-"));
	const service = new WechatCollectorService({ collectorBaseUrl: fx.baseUrl, analysisRoot }, { credentials });
	const saved = await service.analysisSaveSettings({ baseUrl: `http://127.0.0.1:${llmServer.address().port}`, model: "deepseek-chat", skillId: "author-methodology-analysis", maxArticles: 6, apiKey: "unit-test-secret" });
	assert.equal(saved.credential.configured, true);
	assert.equal(JSON.stringify(saved).includes("unit-test-secret"), false);
	assert.equal((await service.analysisTest()).connected, true);

	const report = await service.analyzeAccount({ account: "记忆承载3" });
	assert.equal(report.coverage.sentArticles, 6);
	assert.equal(report.coverage.substantialArticles, 6);
	assert.match(report.markdown, /样本文章1/);
	assert.equal(JSON.stringify(report).includes("unit-test-secret"), false);
	assert.equal(llmRequests.every((request) => request.authorization === "Bearer unit-test-secret"), true);
	assert.equal(llmRequests.some((request) => JSON.stringify(request.body).includes("样本文章6")), true);
	const stored = JSON.parse(await readFile(join(analysisRoot, "reports", `${report.id}.json`), "utf8"));
	assert.equal(JSON.stringify(stored).includes("unit-test-secret"), false);
	assert.equal((await service.listAnalyses({ account: "记忆承载3" })).reports.length, 1);
	assert.equal((await service.getAnalysis(report.id)).id, report.id);
});
