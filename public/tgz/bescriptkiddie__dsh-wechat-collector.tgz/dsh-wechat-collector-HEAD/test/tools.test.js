import assert from "node:assert/strict";
import test from "node:test";
import { registerWechatCollectorTools } from "../lib/tools.js";

test("standalone plugin owns the ContentStudio compatibility tool exactly once", () => {
	const tools = [];
	registerWechatCollectorTools({ tools: { register: (tool) => tools.push(tool) } }, {});
	const names = tools.map((tool) => tool.name);
	assert.equal(names.filter((name) => name === "studio_wechat_collect").length, 1);
	assert.ok(names.includes("wechat_collector_runtime"));
	assert.ok(names.includes("wechat_collector_login"));
	assert.ok(names.includes("wechat_collector_analysis_config"));
	assert.ok(names.includes("wechat_collector_author_analysis"));
	assert.equal(new Set(names).size, names.length);
});
