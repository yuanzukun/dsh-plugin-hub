/**
 * @d86e/dsh-doctor — plugin entry.
 *
 * Registers the `dsh_doctor_*` tools on the `tools` service and refuses to
 * load if the resolved `@deepseek-ai/dsh-tools` is outside the tested
 * range (see version.ts).
 *
 * Dual mode:
 *   1. Static package — mount as a DSH composition row (see cordis.patch.yml).
 *      The loader invokes `apply(ctx, config)` and the nine tools become
 *      available to every agent after the next `dsh web` start.
 *   2. Dynamic sandbox — paste the *built* `lib/index.js` into the
 *      `code.host` field of `cordis_define` and run it. The sandbox supplies
 *      the `harness` global, which we adapt to the same `ctx.tools` shape.
 *
 * @module @d86e/dsh-doctor
 */

import { createRequire } from 'node:module'
import { promises as fs } from 'node:fs'
import * as path from 'node:path'
import { execFile as execFileCb } from 'node:child_process'
import { promisify } from 'node:util'

import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'

import { Config, type Config as ConfigT, resolveConfig } from './config.js'
import {
  StatePaths,
  doctorBase,
  ensureDir,
  readFileOrNull,
  tailFile,
  pidAlive,
  writeFileAtomic,
  logPath,
  readLastTickAt,
  lastTickPath,
  readStartedAt,
  startedAtPath,
  writeWebPid,
  type DoctorLogKind,
} from './state.js'
import { satisfiesCaret, TESTED_PEER_RANGE } from './version.js'
import { DoctorLog } from './doctor-log.js'
import { triage, diagnose, type ActionPlan } from './triage.js'
import { applySafeModePatch, clearSafeModePatch, isSafeModeActive } from './safe-mode.js'
import {
  buildServiceSpec,
  writeServiceSpec,
  removeServiceSpec,
  currentPlatform,
  type ServiceSpec,
} from './platform.js'
import {
  installWatchdogScript,
  isWatchdogInstalled,
  pluginVersion,
} from './watchdog.js'
import { WATCHDOG_STANDALONE_BODY } from './watchdog.standalone.js'
import {
  installToolErrorCapture,
  readSummary,
  ensureToolErrorLogFile,
  type ToolErrorCapture,
  type ToolErrorEntry,
} from './tool-errors.js'
import {
  installSessionWatch,
  type SessionWatch,
  type SessionState,
  type WatchConfig,
} from './session-watch.js'
import { maybeAutoInstall } from './auto-install.js'

const execFile = promisify(execFileCb)
const require = createRequire(import.meta.url)

export const name = 'dsh-doctor'
export const inject = ['tools', 'agents']

/** Snapshot of the resolved @deepseek-ai/dsh-tools version. Exposed for tests. */
export function resolvedDshToolsVersion(): string {
  try {
    const pkg = require('@deepseek-ai/dsh-tools/package.json') as { version?: string }
    return pkg.version ?? 'unknown'
  } catch {
    return 'unresolved'
  }
}

/** Turn a silent peer mismatch into a loud, actionable load error. */
export function assertPeerCompatible(): void {
  const v = resolvedDshToolsVersion()
  if (!satisfiesCaret(v, TESTED_PEER_RANGE)) {
    throw new Error(
      `@d86e/dsh-doctor: resolved @deepseek-ai/dsh-tools ${v}, but this plugin is tested with `
      + `${TESTED_PEER_RANGE}. Upgrade DeepSeek Harness to 0.1.0-rc.6 or later, then reinstall. `
      + 'See the Troubleshooting section in the README.',
    )
  }
}

// ---------------------------------------------------------------------------
// harness adapter (dynamic sandbox vs static package)
// ---------------------------------------------------------------------------

interface HarnessLike {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  defineTool: (def: any) => any
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  registerTool: (ctx: Context, def: any) => any
}

function makeHarness(_ctx: Context): HarnessLike {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const sandboxHarness: any = typeof (globalThis as any).harness !== 'undefined' ? (globalThis as any).harness : null
  if (sandboxHarness) {
    return {
      defineTool: (def) => sandboxHarness.defineTool(def),
      registerTool: (c, def) => sandboxHarness.registerTool(c, def),
    }
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const toolsPkg: any = require('@deepseek-ai/dsh-tools')
  return {
    defineTool: (def) => toolsPkg.defineTool(def),
    registerTool: (c, def) => (c.tools as unknown as { register: (d: unknown) => unknown }).register(def),
  }
}

// ---------------------------------------------------------------------------
// JSON-shaped tool output
// ---------------------------------------------------------------------------
//
// Every tool returns a structured value that dsh-tools projects to the
// model. We use the JSON value schema (`type: 'json'`) so the underlying
// `InferValue<O>` is dsh-tools's strict recursive `JsonValue`. We declare
// a local, structurally-compatible alias and rely on `unknown` at the
// tool boundary — the run-time guarantee is that the value is
// `JSON.stringify`-able.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type AnyJson = null | boolean | number | string | AnyJson[] | { [k: string]: any }

function jsonContent(value: AnyJson): { type: 'text'; text: string }[] {
  return [{ type: 'text', text: JSON.stringify(value, null, 2) }]
}

const JSON_OUTPUT = {
  schema: { type: 'json' as const },
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  render: (_args: unknown, value: any) => jsonContent(value as AnyJson),
}

/**
 * Wrap a tool body. dsh-tools's `execute` signature wants
 * `Promise<InferValue<O>>` where `O` is the output schema; for `type: 'json'`
 * that resolves to its strict recursive `JsonValue`. Authoring the body
 * with a plain structural return type and casting at the boundary is far
 * less painful than threading JsonValue through every tool. The runtime
 * value is guaranteed to be lossless JSON, so the cast is safe.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type ExecFn<A> = (args: A, exec: any) => Promise<any>
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function execBody<A, R>(fn: (args: A, exec: any) => Promise<R>): ExecFn<A> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return fn as unknown as ExecFn<A>
}

/**
 * Does `process.argv` look like a genuine `dsh web` launch?
 *
 * The doctor's apply() runs in whatever process mounts the web profile,
 * and that is NOT always the web server: `dsh plugin --profile web add`,
 * a profile-check, or a one-shot `node` evaluating the profile all run
 * apply() too (observed live: a `dsh plugin add`'s short-lived pid
 * clobbered the running web's .dsh-web.pid). Only a process whose
 * first non-flag subcommand token is `web` is actually the server, so
 * only it should publish its pid.
 */
export function looksLikeDshWeb(argv: readonly string[] = process.argv): boolean {
  if (!argv || argv.length < 3) return false
  let first: string | null = null
  for (let i = 2; i < argv.length; i++) {
    const t = argv[i]
    if (t && !t.startsWith('-')) { first = t; break }
  }
  if (first !== 'web') return false
  // The first non-flag subcommand is "web", but is that token actually a
  // dsh subcommand, or just the argument of some other script
  // (`node script.js web`)? Require argv[1] to be the dsh executable
  // itself (base name dsh / dsh.js / dsh.cmd / dsh.exe). dsh may be
  // launched through a relative/absolute path or via a versioned bin
  // prefix, so only the base name is inspected.
  const prog = String(argv[1] ?? '')
  const base = (prog.match(/[^\\/]*$/) ?? [''])[0].toLowerCase()
  if (base === 'dsh' || base === 'dsh.js' || base === 'dsh.cmd' || base === 'dsh.exe') return true
  // dsh may also be launched by its absolute JS entry (the daemon's
  // startWeb() does exactly this once it resolves dsh to .js — the
  // dsh install is not on a LaunchAgent's minimal PATH, so the daemon
  // spawns it as `<node> <dsh>/lib/bin.js web ...`). Such a launch IS
  // the web server and must publish its pid. The dsh entry file is
  // lib/bin.js inside the @deepseek-ai/dsh package, so accept any path
  // whose basename is bin.js and that contains the package's own
  // node_modules directory segment. (The v0.2.31 clobber bug came from
  // `dsh plugin --profile web add` — argv[1] is dsh, argv[2] is
  // `plugin` and NOT `web` — so this broader rule does not reopen it.)
  if (base === 'bin.js' && /node_modules[\\/]+@deepseek-ai[\\/]+dsh[\\/]/.test(prog)) return true
  return false
}

// ---------------------------------------------------------------------------
// apply
// ---------------------------------------------------------------------------

export function apply(ctx: Context, config: ConfigT): void {
  assertPeerCompatible()

  const harness = makeHarness(ctx)
  const log = new DoctorLog({
    file: StatePaths.doctorLog(),
    maxBytes: config.logMaxBytes,
    backups: config.logBackups,
  })
  const cfg = config

  // The in-process doctor runs inside dsh web, so `process.pid` is dsh
  // web's own pid. Persist it (fire-and-forget, cheap and idempotent) so
  // the standalone daemon's EADDRINUSE kill-branch has a real pid to
  // signal. But NOT every process that mounts the web profile is dsh
  // web: `dsh plugin add`, an `npx` install, or a one-shot `node` that
  // evaluates the profile all run apply() too, with a short-lived pid
  // that dies before dsh web does — that clobbers the marker (observed
  // live: a CLI runner's pid overwrote the running web's, leaving a
  // stale dead pid behind while the real web kept serving). So only a
  // process whose argv looks like a genuine `dsh web` launch writes.
  if (looksLikeDshWeb()) {
    void writeWebPid(process.pid).catch((e) => {
      void log.warn(`writeWebPid failed: ${(e as Error).message}`)
    })
  }

  // Wire tool error capture (degrades silently if the host does not expose
  // the tools/* event waterfalls).
  let capture: ToolErrorCapture | null = null
  if (cfg.toolErrorCapture) {
    try {
      capture = installToolErrorCapture(ctx, cfg, log)
      void ensureToolErrorLogFile(cfg)
    } catch (e) {
      void log.warn(`tool error capture failed to install: ${(e as Error).message}`)
      capture = null
    }
  }

  // Wire session watcher (degrades silently if the host does not expose
  // ctx.agents / session/event).
  let watch: SessionWatch | null = null
  if (cfg.watchEnabled) {
    try {
      const watchCfg: WatchConfig = {
        watchEnabled: cfg.watchEnabled,
        idleThresholdMs: cfg.watchIdleThresholdMs,
        nudgeCooldownMs: cfg.watchNudgeCooldownMs,
        maxNudgesPerSession: cfg.watchMaxNudgesPerSession,
        continueText: cfg.watchContinueText,
        tickIntervalMs: cfg.watchTickIntervalMs,
      }
      watch = installSessionWatch(ctx, watchCfg, log)
    } catch (e) {
      void log.warn(`session watch failed to install: ${(e as Error).message}`)
      watch = null
    }
  }

  // Auto-install the standalone watchdog on first load. Fire-and-forget
  // so a slow `launchctl` / `systemctl` call never blocks dsh boot.
  // The dsh_doctor_install tool remains available for explicit re-runs
  // and for dry-run / purge workflows.
  if (cfg.autoInstall) {
    void maybeAutoInstall(log, cfg).catch((e) => {
      void log.warn(`auto-install check failed: ${(e as Error).message}`)
    })
  } else {
    void log.info('auto-install disabled by config (autoInstall=false)')
  }

  // ---- dsh_doctor_install ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_install',
      description:
        'Install the dsh-doctor watchdog: write the standalone Node script, register the platform service ' +
        '(LaunchAgent / systemd / Task Scheduler), and start it. Idempotent.',
      parameters: {
        port: { type: 'number', description: 'DSH web port to probe. Defaults to DSH_WEB_PORT or 3080.' },
        dryRun: { type: 'boolean', description: 'Build all files but do not register or start the service.', default: false },
      },
      output: JSON_OUTPUT,
      execute: execBody(async (args, _exec) => {
        const port = args.port ?? (Number(process.env.DSH_WEB_PORT) || 3080)
        const result: Record<string, unknown> = {
          ok: false,
          installedAt: new Date().toISOString(),
          watchdogPath: '',
          platform: currentPlatform(),
          serviceLabel: '',
          started: false,
          dryRun: !!args.dryRun,
        }
        await ensureDir(StatePaths.doctorHome())
        await ensureDir(StatePaths.logsDir())
        await ensureToolErrorLogFile(cfg)

        const resolved = resolveConfig(cfg)
        await writeFileAtomic(StatePaths.configJson(), JSON.stringify(resolved, null, 2))

        result.watchdogPath = await installWatchdogScript()
        await log.info(`watchdog script written at ${result.watchdogPath}`)

        let spec: ServiceSpec
        try {
          spec = await buildServiceSpec({
            nodeBin: process.execPath,
            dshHome: doctorBase(),
            webPort: port,
          })
          await writeServiceSpec(spec)
          result.serviceLabel = spec.label
          await log.info(`platform service spec: ${spec.label} → ${spec.file}`)
        } catch (e) {
          await log.warn(`platform spec generation failed: ${(e as Error).message}`)
          throw e
        }

        await writeFileAtomic(
          StatePaths.installedMarker(),
          JSON.stringify({ installedAt: result.installedAt, version: pluginVersion() }, null, 2),
        )

        if (result.dryRun) {
          result.ok = true
          await log.info('dry-run: not registering or starting the service')
          return result
        }

        try {
          await execFile(spec.registerCmd[0], spec.registerCmd.slice(1), {
            env: { ...process.env, DSH_HOME: doctorBase(), DSH_WEB_PORT: String(port) },
          })
          await log.info(`platform service registered: ${spec.label}`)
        } catch (e) {
          await log.warn(`register command failed (continuing): ${(e as Error).message}`)
        }
        try {
          await execFile(spec.startCmd[0], spec.startCmd.slice(1), {
            env: { ...process.env, DSH_HOME: doctorBase(), DSH_WEB_PORT: String(port) },
          })
          await log.info(`platform service start requested: ${spec.label}`)
        } catch (e) {
          await log.warn(`start command failed (continuing): ${(e as Error).message}`)
        }
        result.started = true
        result.ok = true
        return result
      }),
    }),
  )

  // ---- dsh_doctor_uninstall ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_uninstall',
      description: 'Unregister the platform service, remove state files. Logs are kept by default.',
      parameters: {
        purgeLogs: { type: 'boolean', description: 'Also delete $DSH_HOME/doctor/logs/.', default: false },
      },
      output: JSON_OUTPUT,
      execute: execBody(async (args, _exec) => {
        const removed: string[] = []
        try {
          const spec = await buildServiceSpec({
            nodeBin: process.execPath,
            dshHome: doctorBase(),
            webPort: Number(process.env.DSH_WEB_PORT) || 3080,
          })
          try {
            await execFile(spec.stopCmd[0], spec.stopCmd.slice(1))
            removed.push(`stopped ${spec.label}`)
          } catch (e) {
            await log.warn(`stop command failed (continuing): ${(e as Error).message}`)
          }
          try {
            await execFile(spec.unregisterCmd[0], spec.unregisterCmd.slice(1))
            removed.push(`unregistered ${spec.label}`)
          } catch (e) {
            await log.warn(`unregister command failed (continuing): ${(e as Error).message}`)
          }
        } catch (e) {
          await log.warn(`platform spec build failed during uninstall: ${(e as Error).message}`)
        }
        for (const f of [
          StatePaths.installedMarker(),
          StatePaths.stoppedMarker(),
          StatePaths.restartLock(),
          StatePaths.watchdogPid(),
          StatePaths.configJson(),
          StatePaths.lastKnownGood(),
          StatePaths.safeModePatch(),
          StatePaths.watchdogScript(),
          lastTickPath(),
          startedAtPath(),
        ]) {
          try {
            await fs.unlink(f)
            removed.push(f)
          } catch (err) {
            if ((err as NodeJS.ErrnoException).code !== 'ENOENT') {
              await log.warn(`unlink failed for ${f}: ${(err as Error).message}`)
            }
          }
        }
        await removeServiceSpec()
        removed.push(`${StatePaths.platformDir()}/`)
        if (args.purgeLogs) {
          try {
            const entries = await fs.readdir(StatePaths.logsDir())
            for (const e of entries) {
              await fs.rm(path.join(StatePaths.logsDir(), e), { force: true })
              removed.push(`${StatePaths.logsDir()}/${e}`)
            }
          } catch (err) {
            if ((err as NodeJS.ErrnoException).code !== 'ENOENT') {
              await log.warn(`log purge failed: ${(err as Error).message}`)
            }
          }
        }
        capture?.dispose()
        watch?.dispose()
        await log.info(`uninstall complete: ${removed.length} paths removed`)
        return {
          ok: true,
          removed,
          logsPurged: !!args.purgeLogs,
          platform: currentPlatform(),
        }
      }),
    }),
  )

  // ---- dsh_doctor_status ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_status',
      description: 'Snapshot: installed, running, last 5 recoveries, uptime, port, current mode, tool-error counts.',
      parameters: {},
      output: JSON_OUTPUT,
      execute: execBody(async (_args, _exec) => {
        const installed = await isWatchdogInstalled()
        let running = false
        let pid: number | null = null
        let uptime: string | null = null
        if (installed) {
          const raw = await readFileOrNull(StatePaths.watchdogPid())
          if (raw) {
            const n = Number(raw.trim())
            if (Number.isInteger(n) && n > 0 && pidAlive(n)) {
              running = true
              pid = n
              // Real uptime from the watchdog's start marker. The marker
              // is stamped once at watchdog boot and removed on clean
              // shutdown / uninstall; fall back to the (inaccurate but
              // honest) age of the last tick, then to the installed
              // marker's mtime.
              const startedAt = await readStartedAt()
              const lastTick = await readLastTickAt()
              if (startedAt !== null) {
                const sec = Math.max(0, Math.round((Date.now() - startedAt) / 1000))
                uptime = formatUptime(sec)
              } else if (lastTick !== null) {
                uptime = `unknown boot time; last tick ${Math.max(0, Math.round((Date.now() - lastTick) / 1000))}s ago`
              } else {
                uptime = 'unknown (pid alive)'
              }
            }
          }
        }
        const cfgResolved = resolveConfig(cfg)
        const recent = await readRecentRecoveries(5)
        const safeMode = await isSafeModeActive()
        const paused = (await readFileOrNull(StatePaths.stoppedMarker())) !== null
        const lastTickAt = await readLastTickAt().catch(() => null)
        return {
          installed,
          running,
          pid,
          uptime,
          lastTickAt,
          lastTickAgeSec: lastTickAt !== null ? Math.round((Date.now() - lastTickAt) / 1000) : null,
          platform: currentPlatform(),
          webPort: Number(process.env.DSH_WEB_PORT) || 3080,
          paused,
          safeMode,
          config: cfgResolved,
          recent,
          toolErrors: capture ? readSummary(capture) : null,
          toolErrorCaptureEnabled: !!capture,
          watchActive: !!watch?.isActive,
          trackedSessions: watch ? watch.list().length : 0,
          version: pluginVersion(),
        }
      }),
    }),
  )

  // ---- dsh_doctor_pause ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_pause',
      description: 'Pause the watchdog: probes continue, recovery is skipped.',
      parameters: {},
      output: JSON_OUTPUT,
      execute: execBody(async (_args, _exec) => {
        await writeFileAtomic(StatePaths.stoppedMarker(), new Date().toISOString())
        await log.info('watchdog paused')
        return { ok: true, paused: true }
      }),
    }),
  )

  // ---- dsh_doctor_resume ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_resume',
      description: 'Resume the watchdog after a pause.',
      parameters: {},
      output: JSON_OUTPUT,
      execute: execBody(async (_args, _exec) => {
        try {
          await fs.unlink(StatePaths.stoppedMarker())
        } catch (err) {
          if ((err as NodeJS.ErrnoException).code !== 'ENOENT') throw err
        }
        await log.info('watchdog resumed')
        return { ok: true, paused: false }
      }),
    }),
  )

  // ---- dsh_doctor_diagnose ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_diagnose',
      description: 'One-shot triage of the current dsh web failure. Returns the verdict without restarting.',
      parameters: {
        logLines: { type: 'number', description: 'How many log lines to consider. Defaults to Config.triageLogLines.', default: 0 },
      },
      output: JSON_OUTPUT,
      execute: execBody(async (args, _exec) => {
        const resolved = resolveConfig(cfg)
        const requested = Number(args.logLines ?? 0)
        // 0 means "use configured default"; otherwise honour caller (clamped).
        const n = requested > 0
          ? Math.max(10, Math.min(50_000, requested))
          : Math.max(10, Math.min(50_000, resolved.triageLogLines))
        const lines = await tailFile(StatePaths.watchdogLog(), n)
        const d = diagnose(lines)
        return {
          ok: true,
          matched: d.matched ? d.matched.id : null,
          reason: d.reason,
          plan: d.plan,
          logLines: lines.length,
        }
      }),
    }),
  )

  // ---- dsh_doctor_recent_log (NEW in 0.2.18) ----
  // The doctor writes to four log files (web, watchdog, doctor,
  // tool-errors). Before this tool existed, the only way for an agent
  // (or a human via the GUI) to see what the doctor actually did was to
  // tail the file system manually. Now you can pull the recent tail of
  // any of them in one tool call.
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_recent_log',
      description:
        'Return the last N lines of one of the doctor-managed log files. ' +
        'Useful when you want to see exactly what the watchdog did without ' +
        'opening a shell. Defaults: kind=watchdog, lines=100.',
      parameters: {
        kind: {
          type: 'string',
          description: 'Which log: "web" (dsh web stdout), "watchdog" (standalone), "doctor" (in-process), "tool-errors".',
          default: 'watchdog',
        },
        lines: { type: 'number', description: 'How many of the most recent lines to return. 1-2000. Defaults to 100.', default: 100 },
      },
      output: JSON_OUTPUT,
      execute: execBody(async (args, _exec) => {
        const raw = String(args.kind ?? 'watchdog')
        const allowed: DoctorLogKind[] = ['web', 'watchdog', 'doctor', 'tool-errors']
        if (!allowed.includes(raw as DoctorLogKind)) {
          return { ok: false, reason: `unknown kind "${raw}"`, lines: [] as string[] }
        }
        const kind = raw as DoctorLogKind
        const n = Math.max(1, Math.min(2_000, Number(args.lines ?? 100)))
        const file = logPath(kind)
        const lines = await tailFile(file, n)
        return {
          ok: true,
          kind,
          path: file,
          lines,
          count: lines.length,
        }
      }),
    }),
  )

  // ---- dsh_doctor_safe_mode_enter ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_safe_mode_enter',
      description: 'Manually enable the safe-mode patch layer. Useful for debugging plugin-induced boot failures.',
      parameters: {},
      output: JSON_OUTPUT,
      execute: execBody(async (_args, _exec) => {
        const p = await applySafeModePatch(resolveConfig(cfg).safeModeBundles)
        await log.info(`safe-mode manually enabled at ${p}`)
        return { ok: true, safeMode: true, path: p }
      }),
    }),
  )

  // ---- dsh_doctor_safe_mode_exit ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_safe_mode_exit',
      description: 'Manually disable the safe-mode patch layer.',
      parameters: {},
      output: JSON_OUTPUT,
      execute: execBody(async (_args, _exec) => {
        await clearSafeModePatch()
        await log.info('safe-mode manually disabled')
        return { ok: true, safeMode: false, path: StatePaths.safeModePatch() }
      }),
    }),
  )

  // ---- dsh_doctor_drain_deferred (NEW in 0.1.0) ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_drain_deferred',
      description:
        'Surface the queued "deferred" agent-class tool errors for the current session. ' +
        'Intended for a quiet moment in a turn — the doctor never mutates the live waterfall.',
      parameters: {
        sessionId: { type: 'string', description: 'Session id to drain. Defaults to "current" (the whole queue, capped).' },
        max: { type: 'number', description: 'Max entries to return. Defaults to 50.', default: 50 },
      },
      output: JSON_OUTPUT,
      execute: execBody(async (args, _exec) => {
        if (!capture) {
          return { ok: false, reason: 'tool-error capture is disabled', entries: [] as ToolErrorEntry[] }
        }
        const total = capture.queue.summary(Number.POSITIVE_INFINITY).total
        const max = Math.max(1, Math.min(total || 1, args.max ?? 50))
        const sessionId = args.sessionId && args.sessionId !== 'current' ? args.sessionId : null
        const entries = capture.queue.drain(sessionId, max)
        await log.info(`drained ${entries.length} deferred tool errors (sessionId=${sessionId ?? 'all'})`)
        return { ok: true, reason: 'drained', sessionId: sessionId ?? 'all', entries }
      }),
    }),
  )

  // ---- dsh_doctor_watch_list (NEW in 0.2.0) ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_watch_list',
      description:
        'List all sessions the doctor is currently watching. Each entry shows last event age, ' +
        'whether a turn is running, how many nudges have been sent, and the last failure (if any).',
      parameters: {},
      output: JSON_OUTPUT,
      execute: execBody(async (_args, _exec) => {
        if (!watch) return { ok: false, reason: 'session watch is disabled', sessions: [] as SessionState[] }
        return {
          ok: true,
          reason: 'list',
          watchActive: watch.isActive,
          count: watch.list().length,
          sessions: watch.list(),
        }
      }),
    }),
  )

  // ---- dsh_doctor_watch_nudge (NEW in 0.2.0) ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_watch_nudge',
      description:
        'Manually inject a "continue" message into a live session. Use this when the user wants ' +
        'to unstick a session on demand (the automatic watch already handles idle detection).',
      parameters: {
        sessionId: { type: 'string', description: 'Session id to nudge.', required: true },
        text: { type: 'string', description: 'Text to inject. Defaults to the configured continue text.' },
      },
      output: JSON_OUTPUT,
      execute: execBody(async (args, _exec) => {
        if (!watch) return { ok: false, reason: 'session watch is disabled' }
        const text = args.text && args.text.length > 0 ? args.text : cfg.watchContinueText
        const r = watch.nudge(args.sessionId, text)
        await log.info(`manual nudge ${args.sessionId}: ${r.ok ? 'sent' : r.reason}`)
        return { ok: r.ok, reason: r.reason ?? 'sent', sessionId: args.sessionId, text }
      }),
    }),
  )

  // ---- dsh_doctor_watch_cancel (NEW in 0.2.0) ----
  harness.registerTool(
    ctx,
    defineTool({
      name: 'dsh_doctor_watch_cancel',
      description:
        'Cancel the current turn on a live session. Use this when a session is truly hung and ' +
        'a nudge will not help (e.g. the agent is in a loop). The cancellation is marked as ' +
        '"user" so it is not confused with a system stop.',
      parameters: {
        sessionId: { type: 'string', description: 'Session id whose turn should be cancelled.', required: true },
      },
      output: JSON_OUTPUT,
      execute: execBody(async (args, _exec) => {
        if (!watch) return { ok: false, reason: 'session watch is disabled' }
        const r = watch.cancel(args.sessionId)
        await log.info(`manual cancel ${args.sessionId}: ${r.ok ? 'cancelled' : r.reason}`)
        return { ok: r.ok, reason: r.reason ?? 'cancelled', sessionId: args.sessionId }
      }),
    }),
  )
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

interface RecoveryEntry {
  ts: string
  plan: string
  detail: string
}

async function readRecentRecoveries(n: number): Promise<RecoveryEntry[]> {
  const lines = await tailFile(StatePaths.watchdogLog(), 200)
  const out: RecoveryEntry[] = []
  let cur: RecoveryEntry | null = null
  for (const line of lines) {
    if (line.includes('health probe failed')) {
      if (cur) out.push(cur)
      cur = { ts: extractTs(line), plan: 'probe-failed', detail: line.split(']').slice(2).join(']').trim() }
    } else if (line.includes('triage: matched=') && cur) {
      const m = line.match(/triage: matched=(\S+)/)
      if (m) cur.plan = m[1] ?? cur.plan
      cur.detail = line.split(']').slice(2).join(']').trim()
    } else if (line.includes('recovered after') && cur) {
      cur.detail += ' | ' + line.split(']').slice(2).join(']').trim()
    }
  }
  if (cur) out.push(cur)
  return out.slice(-n).reverse()
}

function extractTs(line: string): string {
  const m = line.match(/^\[([^\]]+)\]/)
  return m ? m[1] : ''
}

/**
 * Human-readable uptime from a duration in seconds.
 *
 * Rule: drop leading zero units, show at most three units, drop
 * trailing zero units. '300s' -> '5m' (not '5m 0s'),
 * '86400+3600' -> '1d 1h', '2d 3h 1m 1s' -> '2d 3h 1m' (seconds fall
 * off the three-unit budget), '0' -> '0s'.
 */
function formatUptime(sec: number): string {
  const s = Math.max(0, Math.floor(sec))
  const units: Array<[number, string]> = [
    [Math.floor(s / 86400), 'd'],
    [Math.floor((s % 86400) / 3600), 'h'],
    [Math.floor((s % 3600) / 60), 'm'],
    [s % 60, 's'],
  ]
  let start = 0
  while (start < units.length && units[start][0] === 0) start++
  if (start >= units.length) return '0s'
  let end = Math.min(units.length, start + 3)
  while (end > start && units[end - 1][0] === 0) end--
  return units.slice(start, end).map(([v, u]) => `${v}${u}`).join(' ')
}

// Re-export for unit tests and for the dsh CLI doctor subcommand.
export {
  formatUptime,
  Config,
  resolveConfig,
  satisfiesCaret,
  TESTED_PEER_RANGE,
  triage,
  diagnose,
  applySafeModePatch,
  clearSafeModePatch,
  isSafeModeActive,
  buildServiceSpec,
  writeServiceSpec,
  removeServiceSpec,
  currentPlatform,
  installWatchdogScript,
  isWatchdogInstalled,
  pluginVersion,
  WATCHDOG_STANDALONE_BODY,
}
export type { ConfigT, ActionPlan, RecoveryEntry, ToolErrorEntry }
