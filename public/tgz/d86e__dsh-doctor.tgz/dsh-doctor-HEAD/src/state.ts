/**
 * Filesystem helpers for the `$DSH_HOME/doctor/` state directory.
 *
 * All paths are computed from `$DSH_HOME` (default `~/.dsh`) and the resolved
 * DSH web port. The watchdog uses these helpers at every tick; the plugin's
 * tools use them at install/uninstall time.
 *
 * @module dsh-doctor/state
 */

import { promises as fs } from 'node:fs'
import * as path from 'node:path'
import * as os from 'node:os'

/** Path helpers — exported so the watchdog script and the plugin can agree. */
export const StatePaths = {
  doctorHome(): string {
    return path.join(doctorBase(), 'doctor')
  },
  configJson(): string {
    return path.join(doctorBase(), 'doctor', 'config.json')
  },
  watchdogScript(): string {
    return path.join(doctorBase(), 'doctor', 'watchdog.js')
  },
  /** Pid of the running watchdog. */
  watchdogPid(): string {
    return path.join(doctorBase(), 'doctor', '.doctor-watchdog.pid')
  },
  /** Presence marker. */
  installedMarker(): string {
    return path.join(doctorBase(), 'doctor', '.doctor-installed')
  },
  /** User-paused marker. */
  stoppedMarker(): string {
    return path.join(doctorBase(), 'doctor', '.doctor-stopped')
  },
  /** Restart mutex (TTL 120 s). */
  restartLock(): string {
    return path.join(doctorBase(), 'doctor', '.doctor-restart.lock')
  },
  /** Last successfully booted profile snapshot. */
  lastKnownGood(): string {
    return path.join(doctorBase(), 'doctor', 'last-known-good.json')
  },
  /** Generated safe-mode patch. */
  safeModePatch(): string {
    return path.join(doctorBase(), 'doctor', 'safe-mode.patch.yml')
  },
  logsDir(): string {
    return path.join(doctorBase(), 'doctor', 'logs')
  },
  watchdogLog(): string {
    return path.join(doctorBase(), 'doctor', 'logs', 'watchdog.log')
  },
  doctorLog(): string {
    return path.join(doctorBase(), 'doctor', 'logs', 'doctor.log')
  },
  platformDir(): string {
    return path.join(doctorBase(), 'doctor', 'platform')
  },
  profilePatchFile(): string {
    return path.join(doctorBase(), 'profiles', 'web', 'cordis.patch.yml')
  },
  profileDir(): string {
    return path.join(doctorBase(), 'profiles', 'web')
  },
}

/** Return `$DSH_HOME` (default `~/.dsh`). */
export function doctorBase(): string {
  return process.env.DSH_HOME && process.env.DSH_HOME.length > 0
    ? process.env.DSH_HOME
    : path.join(os.homedir(), '.dsh')
}

/** Ensure a directory exists (recursive, idempotent). */
export async function ensureDir(dir: string): Promise<void> {
  await fs.mkdir(dir, { recursive: true })
}

/** Read a file, returning `null` if it does not exist. */
export async function readFileOrNull(p: string): Promise<string | null> {
  try {
    return await fs.readFile(p, 'utf8')
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') return null
    throw err
  }
}

/** Write a file atomically: write to `<p>.tmp` then rename. */
export async function writeFileAtomic(p: string, content: string): Promise<void> {
  const tmp = `${p}.tmp.${process.pid}.${Date.now()}`
  await fs.writeFile(tmp, content, { mode: 0o600 })
  await fs.rename(tmp, p)
}

/** Tail the last N lines of a file. Returns `[]` if the file is missing. */
export async function tailFile(p: string, maxLines: number): Promise<string[]> {
  const content = await readFileOrNull(p)
  if (content === null) return []
  const lines = content.split(/\r?\n/).filter((l) => l.length > 0)
  return lines.slice(Math.max(0, lines.length - maxLines))
}

/** Is a pid alive? Sends signal 0, never throws. */
export function pidAlive(pid: number): boolean {
  if (!Number.isInteger(pid) || pid <= 0) return false
  try {
    process.kill(pid, 0)
    return true
  } catch (err) {
    return (err as NodeJS.ErrnoException).code === 'EPERM'
  }
}

/**
 * Write the pid of the running dsh web process. The in-process doctor
 * runs inside dsh web, so `process.pid` IS the web pid: persisting it
 * is what makes the daemon's EADDRINUSE kill-pid-and-restart branch
 * have anything to kill. Stale after dsh web exits — readWebPid's
 * caller treats a dead pid as already-terminated, which is exactly the
 * "dsh web crashed, its pid file is left behind" case the branch
 * exists for.
 */
export async function writeWebPid(pid: number): Promise<void> {
  await ensureDir(StatePaths.profileDir())
  await writeFileAtomic(path.join(StatePaths.profileDir(), '.dsh-web.pid'), `${pid}\n`)
}

/** Read the DSH web pid from the profile directory, if present. */
export async function readWebPid(): Promise<number | null> {
  const p = path.join(StatePaths.profileDir(), '.dsh-web.pid')
  const content = await readFileOrNull(p)
  if (content === null) return null
  const n = Number(content.trim())
  return Number.isInteger(n) && n > 0 ? n : null
}

/**
 * Known log files managed by the doctor. Used by `dsh_doctor_recent_log`.
 *
 * `web`     — dsh web's own stdout/stderr (the thing triage reads from)
 * `watchdog` — the standalone watchdog's diagnostic log
 * `doctor`  — the in-process doctor's diagnostic log (captures tool errors, watch events)
 * `tool-errors` — the JSONL-ish log of every classified tool error
 */
export type DoctorLogKind = 'web' | 'watchdog' | 'doctor' | 'tool-errors'

/** Map a log kind to its absolute path. */
export function logPath(kind: DoctorLogKind): string {
  switch (kind) {
    case 'web':         return path.join(doctorBase(), 'doctor', 'logs', 'dsh-web.log')
    case 'watchdog':    return StatePaths.watchdogLog()
    case 'doctor':      return StatePaths.doctorLog()
    case 'tool-errors': return path.join(doctorBase(), 'doctor', 'logs', 'tool-errors.log')
  }
}

/** Read the watchdog's last-tick timestamp (epoch ms), or `null`. */
export async function readLastTickAt(): Promise<number | null> {
  const raw = await readFileOrNull(path.join(doctorBase(), 'doctor', '.doctor-last-tick'))
  if (raw === null) return null
  const n = Number(raw.trim())
  return Number.isFinite(n) && n > 0 ? n : null
}

/** Absolute path to the watchdog's last-tick marker. */
export function lastTickPath(): string {
  return path.join(doctorBase(), 'doctor', '.doctor-last-tick')
}

/**
 * Read the watchdog's start timestamp (epoch ms), or `null`. Written once
 * by the generated script at boot (before the first tick) and removed on
 * clean shutdown / uninstall. Lets `dsh_doctor_status` report a real
 * uptime instead of the historical hard-coded 'unknown (pid alive)'.
 */
export async function readStartedAt(): Promise<number | null> {
  const raw = await readFileOrNull(startedAtPath())
  if (raw === null) return null
  const n = Number(raw.trim())
  return Number.isFinite(n) && n > 0 ? n : null
}

/** Absolute path to the watchdog's start timestamp marker. */
export function startedAtPath(): string {
  return path.join(doctorBase(), 'doctor', '.doctor-started')
}
