/**
 * dsh-maid-emoji 冒烟测试：用 mock 服务驱动 host 端 apply()，
 * 验证配置注册、文件夹扫描、/emoji 静态服务、系统提示词段与 RPC 快照。
 * 运行：node tests/smoke.mjs（在插件目录内）
 */

import { apply } from '../lib/index.js'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const z = require('@deepseek-ai/schemastery')

// --- 最小 settings 服务 mock -------------------------------------------------
function createSettingsMock() {
  const scopes = new Map()
  const service = {
    writable: true,
    register(ns, schema) {
      if (scopes.has(ns)) throw new Error(`duplicate ns ${ns}`)
      let user = {}
      const watchers = new Set()
      const scope = {
        get() {
          const resolved = schema()
          return Object.assign({}, resolved, user)
        },
        watch(cb) {
          watchers.add(cb)
          return () => watchers.delete(cb)
        },
        async replace(section) {
          user = JSON.parse(JSON.stringify(section))
          for (const cb of watchers) await cb(scope.get(), scope.get())
        },
        async update(patch) {
          user = Object.assign({}, user, JSON.parse(JSON.stringify(patch)))
          for (const cb of watchers) await cb(scope.get(), scope.get())
        },
      }
      scopes.set(ns, scope)
      return scope
    },
    get(ns) {
      return scopes.get(ns)?.get()
    },
  }
  return service
}

// --- 最小 webServer mock ------------------------------------------------------
function createWebServerMock() {
  const routes = []
  const service = {
    host: '127.0.0.1',
    port: 3080,
    register(route) {
      routes.push(route)
      return () => {
        const i = routes.indexOf(route)
        if (i >= 0) routes.splice(i, 1)
      }
    },
  }
  return { service, routes }
}

// --- 最小 systemPrompt mock ---------------------------------------------------
function createSystemPromptMock() {
  const sections = []
  const service = {
    section(section) {
      sections.push(section)
      return () => {
        const i = sections.indexOf(section)
        if (i >= 0) sections.splice(i, 1)
      }
    },
  }
  return { service, sections }
}

// --- 最小 ctx / connection mock ------------------------------------------------
function createCtx(services) {
  const effects = []
  const listeners = []
  const ctx = {
    get(key) {
      return services[key]
    },
    effect(fn) {
      // 真实 Cordis：注册后立即执行，返回的 disposer 随 fiber 清理。
      const disposer = fn()
      effects.push(disposer)
      return () => {}
    },
    on(name, callback, options) {
      // 收集事件监听器（llm/stream 等 waterfall 监听）。
      listeners.push({ name, callback, options })
      return () => {
        const i = listeners.findIndex((l) => l.callback === callback)
        if (i >= 0) listeners.splice(i, 1)
      }
    },
    inject(deps, fn) {
      // connection mock 直接执行注入回调
      const connectionCtx = { connection: services.connection }
      fn(connectionCtx)
      return () => {}
    },
  }
  return { ctx, effects, listeners }
}

function createConnectionMock() {
  let handler = null
  const connection = {
    rpc: {
      handle(channel, fn) {
        handler = fn
        return async () => { handler = null }
      },
    },
  }
  return {
    connection,
    get handler() {
      return handler
    },
  }
}

// --- 执行 ----------------------------------------------------------------------
const settings = createSettingsMock()
const { service: webServer, routes } = createWebServerMock()
const { service: systemPrompt, sections } = createSystemPromptMock()
const connectionMock = createConnectionMock()
const services = {
  settings,
  webServer,
  systemPrompt,
  connection: connectionMock.connection,
}

const { ctx, listeners } = createCtx(services)
apply(ctx)

console.log('✓ apply 执行完成')

// 1. 配置注册
const config0 = settings.get('maid-emoji')
console.log('✓ 默认配置:', JSON.stringify(config0))
if (config0.enabled !== true || config0.maxPerReply !== 2) throw new Error('默认配置不符')
if (config0.emojiWidth !== 160) throw new Error('默认 emojiWidth 不符')
if (config0.includeBuiltin !== true) throw new Error('默认 includeBuiltin 不符')

// 2. 配置文件夹 → watch → 扫描（通过 RPC rescan/set-config 触发重扫）
// 手动触发配置变更：直接用 RPC set-config 配置真实文件夹。
const rpc = connectionMock.handler
if (typeof rpc !== 'function') throw new Error('RPC 通道未注册')

/** 模拟客户端解包 RPC 信封。 */
async function call(endpoint, payload) {
  const result = await rpc(endpoint, payload)
  if (!result || result.ok !== true) {
    throw new Error(result && result.error ? result.error.message : 'rpc failed')
  }
  return result.value
}

// apply 后初始 rescan 是异步的，先用 RPC 强制完成一次扫描再读配置。
await call('rescan')
const before = await call('get-config')
console.log('✓ get-config(空配置): count=', before.count, '内置=', before.builtinCount, '自定义=', before.userCount)
if (before.count !== 47 || before.builtinCount !== 47 || before.userCount !== 0) {
  throw new Error('内置默认表情包扫描结果不符')
}

// 3. 通过 RPC set-config 配置真实文件夹 → 触发重扫（与内置重名，去重后用户版胜出）
const FOLDER = 'G:\\深鲸湾\\biaoqingbao\\女仆表情包'
const after = await call('set-config', {
  enabled: true,
  includeBuiltin: true,
  folders: [FOLDER],
  injectList: true,
  maxPerReply: 2,
  emojiWidth: 200,
})
console.log('✓ set-config 后 count =', after.count, '内置 =', after.builtinCount, '自定义 =', after.userCount, 'baseUrl =', after.baseUrl)
if (after.count !== 47) throw new Error('同名去重后数量不符（应为 47）')
if (after.config.emojiWidth !== 200) throw new Error('emojiWidth 保存不符')
console.log('✓ 前 3 张:', after.files.slice(0, 3).map((f) => f.name).join(', '))

// 4. HTTP 路由存在
const emojiRoute = routes.find((r) => r.path === '/emoji')
if (!emojiRoute) throw new Error('未注册 /emoji 路由')
console.log('✓ HTTP 路由:', emojiRoute.kind, emojiRoute.path)

// 5. HTTP handler 返回图片字节
const first = after.files[0]
const req = { url: `/emoji/${encodeURIComponent(first.name)}` }
const chunks = []
const res = {
  status: 0,
  headers: null,
  writeHead(code, headers) {
    this.status = code
    this.headers = headers
  },
  end(data) {
    chunks.push(data)
  },
}
await emojiRoute.handler(req, res)
console.log('✓ GET /emoji/<file> → status', res.status, 'type', res.headers?.['Content-Type'], 'bytes', Buffer.concat(chunks.map((c) => Buffer.from(c))).length)
if (res.status !== 200) throw new Error('表情文件返回失败')

// 6. 404 与 400 分支
const missingReq = { url: '/emoji/不存在.png' }
const missingRes = { writeHead(c, h) { this.status = c; this.headers = h }, end(d) { this.body = d } }
await emojiRoute.handler(missingReq, missingRes)
if (missingRes.status !== 404) throw new Error('404 分支异常')
console.log('✓ 404 分支正常')

// 7. 系统提示词段
const section = sections.find((s) => s.name === 'emoji:usage')
if (!section) throw new Error('未注册 emoji:usage 提示词段')
const text = typeof section.text === 'function' ? section.text({}) : section.text
console.log('--- 提示词段预览（前 12 行）---')
console.log(text.split('\n').slice(0, 12).join('\n'))
if (!text.includes('::文件名::') || !text.includes('/emoji/')) throw new Error('提示词段缺少 marker 协议说明')

// 8. 关闭表情后提示词行为
await call('set-config', { enabled: false, folders: [FOLDER], injectList: true, maxPerReply: 2 })
const textOff = typeof section.text === 'function' ? section.text({}) : section.text
if (!textOff.includes('已停用')) throw new Error('停用状态提示词异常')
console.log('✓ 停用状态提示词正常')

// 9. llm/stream 转写
await call('set-config', { enabled: true, folders: [FOLDER], injectList: true, maxPerReply: 2, emojiWidth: 160 })
const streamListener = listeners.find((l) => l.name === 'llm/stream')
if (!streamListener) throw new Error('未注册 llm/stream 监听器')

/** 把文本块喂给监听器，返回转写后的完整文本。 */
async function transcribe(blocks, options = {}) {
  async function* source() {
    for (const text of blocks) {
      yield { type: 'block-end', index: 0, block: { type: 'text', text } }
    }
  }
  const stream = streamListener.callback({ purpose: options.purpose }, () => source())
  let out = ''
  for await (const chunk of stream) {
    if (chunk.type === 'block-end' && chunk.block.type === 'text') out += chunk.block.text
  }
  return out
}

const rewritten = await transcribe(['::开心:: 今天好棒 ::委屈::'])
console.log('✓ 转写结果:', rewritten)
if (!rewritten.includes('![开心.png](http://127.0.0.1:3080/emoji/%E5%BC%80%E5%BF%83.png)')) {
  throw new Error('::开心:: 未转写为图片')
}
if (!rewritten.includes('![委屈.png](http://127.0.0.1:3080/emoji/%E5%A7%94%E5%B1%88.png)')) {
  throw new Error('::委屈:: 未转写为图片')
}
if (rewritten.includes('::')) throw new Error('marker 残留')

// 9.1 代码块保护：代码内的 marker 不转写
const codeText = '```js\n::开心::\n```\n后面 ::吃瓜::'
const codeOut = await transcribe([codeText])
if (codeOut.includes('![开心.png]')) throw new Error('代码块内 marker 被误转写')
if (!codeOut.includes('![吃瓜.png]')) throw new Error('代码块外 marker 未转写')
console.log('✓ 代码块保护正常')

// 9.2 未命中的 marker 原样保留
const unknownOut = await transcribe(['::不存在的表情::'])
if (unknownOut !== '::不存在的表情::') throw new Error('未命中 marker 被改动')
console.log('✓ 未命中 marker 保留')

// 9.3 超过上限的 marker 被移除（maxPerReply = 2，第三个不转写）
const limitOut = await transcribe(['::开心:: 一 ::委屈:: 二 ::吃瓜:: 三'])
if (limitOut.includes('![吃瓜.png]')) throw new Error('超上限 marker 未被移除')
if (limitOut.includes('::吃瓜::')) throw new Error('超上限 marker 残留文本')
console.log('✓ 上限移除正常:', JSON.stringify(limitOut))

// 9.4 带 purpose 的调用不转写
const purposeOut = await transcribe(['::开心::'], { purpose: 'title' })
if (purposeOut !== '::开心::') throw new Error('带 purpose 的流被误转写')
console.log('✓ 非主对话流不转写')

console.log('\n全部冒烟测试通过！')
