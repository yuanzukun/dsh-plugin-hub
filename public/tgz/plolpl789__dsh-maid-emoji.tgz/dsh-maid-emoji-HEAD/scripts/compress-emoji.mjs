/**
 * 表情素材压缩工具：把 assets/emoji 内的表情图统一缩放到指定宽度（高度等比），
 * 并压缩 README 预览图。用于控制插件包体积。
 *
 * 用法：node scripts/compress-emoji.mjs [宽度px]   （默认 160）
 * 依赖：sharp（DSH 安装目录自带，或用 npm i -D sharp 安装）
 */

import { promises as fs } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const root = fileURLToPath(new URL('..', import.meta.url))

// sharp 优先从本包解析，回退到 DSH 安装目录（本地开发环境）。
let sharp
try {
  sharp = require('sharp')
} catch {
  const candidates = [
    'C:/Users/Administrator/AppData/Roaming/npm/node_modules/@deepseek-ai/dsh/node_modules/sharp',
  ]
  for (const candidate of candidates) {
    try {
      sharp = require(candidate)
      break
    } catch {
      // 继续尝试下一个
    }
  }
}
if (!sharp) {
  console.error('找不到 sharp，请先 npm i -D sharp')
  process.exit(1)
}

const width = Number(process.argv[2] ?? 160)
if (!Number.isFinite(width) || width <= 0) {
  console.error('宽度参数无效')
  process.exit(1)
}

const IMAGE_RE = /\.(png|jpe?g|webp)$/i

async function processDir(dir, targetWidth) {
  let entries
  try {
    entries = await fs.readdir(dir, { withFileTypes: true })
  } catch {
    console.log(`跳过（目录不存在）: ${dir}`)
    return { processed: 0, skipped: 0, saved: 0 }
  }
  let processed = 0
  let skipped = 0
  let beforeBytes = 0
  let afterBytes = 0
  for (const entry of entries) {
    if (!entry.isFile() || !IMAGE_RE.test(entry.name)) continue
    const full = path.join(dir, entry.name)
    const meta = await sharp(full).metadata()
    beforeBytes += meta.size ?? 0
    if (meta.width !== undefined && meta.width <= targetWidth) {
      skipped += 1
      afterBytes += meta.size ?? 0
      console.log(`跳过（已 ${meta.width}px）: ${entry.name}`)
      continue
    }
    const tmp = full + '.tmp' + path.extname(full)
    await sharp(full)
      .resize({ width: targetWidth, withoutEnlargement: true })
      .toFile(tmp)
    await fs.rename(tmp, full)
    const after = await sharp(full).metadata()
    afterBytes += after.size ?? 0
    processed += 1
    console.log(`已压缩 ${entry.name}: ${meta.width}px → ${targetWidth}px`)
  }
  return { processed, skipped, saved: beforeBytes - afterBytes }
}

async function main() {
  const emojiDir = path.join(root, 'assets', 'emoji')
  const preview = path.join(root, 'docs', 'preview.png')

  console.log(`压缩 assets/emoji 到宽度 ${width}px …`)
  const result = await processDir(emojiDir, width)
  console.log(`表情压缩完成：处理 ${result.processed} 张，跳过 ${result.skipped} 张，节省 ${(result.saved / 1024 / 1024).toFixed(2)} MB`)

  console.log('压缩 docs/preview.png 到宽度 480px …')
  if (await fs.access(preview).then(() => true).catch(() => false)) {
    const meta = await sharp(preview).metadata()
    if (meta.width !== undefined && meta.width > 480) {
      await sharp(preview).resize({ width: 480 }).toFile(preview + '.tmp.png')
      await fs.rename(preview + '.tmp.png', preview)
      console.log(`preview.png: ${meta.width}px → 480px`)
    } else {
      console.log('preview.png 已足够小，跳过')
    }
  }
}

main().catch((error) => {
  console.error(error)
  process.exit(1)
})
