export const SessionId = value => value
export const WorkspaceId = value => value
export const createUserMessage = value => value
export const installModelSelection = () => () => {}
export const setApprovalPolicy = (session, policy) => session.append('approval/policy', { policy })
export const defineTool = definition => definition
const schemaNode = new Proxy(() => schemaNode, {
  apply: () => schemaNode,
  get: () => schemaNode,
})
export default schemaNode
