import assert from "node:assert/strict";
import test from "node:test";
import { createDefinition, createManualRun } from "../src/domain.ts";
import { AutomationService, type AutomationConfig } from "../src/service.ts";
import type { AutomationDefinition, AutomationRun } from "../src/types.ts";
import { registerAutomationTools } from "../src/tools.ts";

const permissionPresets = {
  names: ["read-only", "workspace-write", "danger-full-access"],
  defaultPreset: "workspace-write",
  optionOf: (value: string) => ({ value, name: value }),
  set() {},
};

class MemoryTable<V> {
  private readonly values = new Map<string, V>();
  beforeMutation?: (kind: "put" | "update", key: string) => Promise<void>;
  get(key: string): V | undefined {
    return this.values.get(key);
  }
  entries(): IterableIterator<[string, V]> {
    return this.values.entries();
  }
  keys(): IterableIterator<string> {
    return this.values.keys();
  }
  get size(): number {
    return this.values.size;
  }
  setNow(key: string, value: V): void {
    this.values.set(key, value);
  }
  async put(key: string, value: V): Promise<void> {
    await this.beforeMutation?.("put", key);
    this.values.set(key, value);
  }
  async delete(key: string): Promise<boolean> {
    return this.values.delete(key);
  }
  async update(key: string, transform: (current: V) => V): Promise<V> {
    await this.beforeMutation?.("update", key);
    const current = this.values.get(key);
    if (current === undefined) throw new Error(`missing ${key}`);
    const next = transform(current);
    this.values.set(key, next);
    return next;
  }
}

function config(overrides: Partial<AutomationConfig> = {}): AutomationConfig {
  return {
    runTimeoutMs: 60_000,
    misfireGraceMs: 15 * 60_000,
    historyLimit: 3,
    ...overrides,
  };
}

function makeService(
  initial: {
    definitions?: AutomationDefinition[];
    runs?: AutomationRun[];
  } = {},
  overrides: Partial<AutomationConfig> = {},
  ctxOverrides: Record<string, unknown> = {},
) {
  const definitions = new MemoryTable<AutomationDefinition>();
  const runs = new MemoryTable<AutomationRun>();
  for (const item of initial.definitions ?? [])
    void definitions.put(item.id, item);
  for (const item of initial.runs ?? []) void runs.put(item.id, item);
  const agent = {
    session: {
      header: { cwd: "D:\\work\\demo", agentPreset: "standard" },
      requestHeader: () => ({ config: { provider: "deepseek", model: "v4" } }),
    },
    ctx: {},
  };
  const ctx = {
    permissionPresets,
    logger: { warn() {} },
    storageDomain: {
      async open() {
        return {
          name: "dsh_automation",
          table(name: string) {
            return name === "definitions" ? definitions : runs;
          },
          async close() {},
        };
      },
    },
    agents: {
      get() {
        return agent;
      },
    },
    workspaceRegistry: {
      get(id: unknown) {
        return String(id) === "ws_1"
          ? { id: "ws_1", title: "demo", path: "D:\\work\\demo" }
          : undefined;
      },
      async resolveByPath(path: string) {
        return path === "D:\\work\\demo"
          ? { id: "ws_1", title: "demo", path: "D:\\work\\demo" }
          : undefined;
      },
    },
    agentDefaultModel: {
      currentSelection: () => ({ provider: "deepseek", model: "v4" }),
    },
    agentPresets: { composedPreset: () => "standard" },
    ...ctxOverrides,
  };
  return AutomationService.open(ctx as never, config(overrides)).then(
    async (service) => {
      Object.assign(service as any, { definitions, runs });
      return { service, definitions, runs };
    },
  );
}

function sampleDefinition(
  overrides: Partial<AutomationDefinition> = {},
): AutomationDefinition {
  return createDefinition({
    id: "automation_1",
    name: "每日检查",
    prompt: "检查测试",
    schedule: { kind: "once", at: "2026-08-16T01:00:00.000Z", timeZone: "UTC" },
    workspaceId: "ws_1",
    cwd: "D:\\work\\demo",
    agentPreset: "standard",
    createdBy: { kind: "web", sessionId: "session_1" },
    now: "2026-08-16T00:00:00.000Z",
    ...overrides,
  });
}

test("Agent 工具可固定、修复和清空模型目标，省略字段保留原值", async () => {
  const { service, definitions } = await makeService();
  const tools = new Map<string, any>();
  const agent = {
    id: "session_1",
    ctx: { tools: { register(tool: any) { tools.set(tool.name, tool); return () => {}; } } },
  };
  const dispose = registerAutomationTools(service, agent);
  const context = { agent, signal: new AbortController().signal };
  const base = { name: "检查", prompt: "检查测试", kind: "interval", every_minutes: 10, time_zone: "UTC" };
  const target = (value: any) => [value.provider, value.model, value.reasoningEffort];
  try {
    const created = await tools.get("automation_create").execute({ ...base, provider: "custom", model: "old-model", reasoning_effort: "high" }, context);
    assert.equal(created.ok, true);
    const id = created.automation.id;
    assert.deepEqual(target(created.automation), ["custom", "old-model", "high"]);
    assert.deepEqual(target(definitions.get(id)), ["custom", "old-model", "high"]);

    const repaired = await tools.get("automation_update").execute({ id, provider: "custom", model: "new-model", reasoning_effort: "low" }, context);
    assert.equal(repaired.ok, true);
    assert.deepEqual(target(repaired.automation), ["custom", "new-model", "low"]);
    const renamed = await tools.get("automation_update").execute({ id, name: "改名" }, context);
    assert.deepEqual(target(renamed.automation), ["custom", "new-model", "low"]);

    const cleared = await tools.get("automation_update").execute({ id, provider: null, model: null, reasoning_effort: null }, context);
    assert.equal(cleared.ok, true);
    assert.deepEqual(target(cleared.automation), [null, null, null]);
    assert.deepEqual(target(definitions.get(id)), [null, null, null]);
    const listing = await tools.get("automation_list").execute({}, context);
    assert.deepEqual(target(listing.automations.find((item: any) => item.id === id)), [null, null, null]);

    const inherited = await tools.get("automation_create").execute(base, context);
    assert.deepEqual(target(inherited.automation), ["deepseek", "v4", undefined]);
    const global = await tools.get("automation_create").execute({ ...base, provider: null, model: null }, context);
    assert.deepEqual(target(global.automation), [null, null, undefined]);
  } finally {
    dispose();
    await service.dispose();
  }
});

test("Web 指定工作区创建时显式 null 不被全局模型覆盖", async () => {
  const { service } = await makeService();
  try {
    const definition = await service.create({ sessionId: "session_1", creatorKind: "web", hostWide: true }, {
      name: "跟随全局", prompt: "检查测试", workspaceId: "ws_1",
      schedule: { kind: "interval", everyMinutes: 10, anchor: new Date().toISOString(), timeZone: "UTC" },
      provider: null, model: null, reasoningEffort: null,
    });
    assert.equal(definition.provider, null);
    assert.equal(definition.model, null);
    assert.equal(definition.reasoningEffort, null);
  } finally {
    await service.dispose();
  }
});

test("创建和更新拒绝不完整模型配对且不写库，切换模型清除陈旧推理等级", async () => {
  const { service, definitions } = await makeService();
  const scope = { sessionId: "session_1", creatorKind: "agent" as const };
  const base = { name: "检查", prompt: "检查", schedule: { kind: "daily" as const, time: "09:00", timeZone: "UTC" } };
  try {
    const saved = await service.create(scope, { ...base, provider: "deepseek", model: "v4", reasoningEffort: "high" });
    for (const partial of [
      { provider: "pi-ai" }, { model: "gemini" }, { provider: null }, { model: null },
      { provider: "pi-ai", model: null }, { provider: null, model: "gemini" },
      { provider: "", model: "gemini" }, { provider: "pi-ai", model: "  " },
    ]) {
      await assert.rejects(service.create(scope, { ...base, ...partial }), /provider 与 model 必须同时/);
      await assert.rejects(service.create({ ...scope, hostWide: true }, { ...base, workspaceId: "ws_1", ...partial }), /provider 与 model 必须同时/);
      await assert.rejects(service.update(scope, saved.id, partial), /provider 与 model 必须同时/);
      assert.equal(definitions.size, 1);
      assert.deepEqual(definitions.get(saved.id), saved);
    }
    const unchanged = await service.update(scope, saved.id, { provider: "deepseek", model: "v4" });
    assert.equal(unchanged.reasoningEffort, "high");
    const changed = await service.update(scope, saved.id, { provider: "pi-ai", model: "gemini" });
    assert.equal(changed.reasoningEffort, null);
    const explicit = await service.update(scope, saved.id, { provider: "deepseek", model: "v4", reasoningEffort: "low" });
    assert.equal(explicit.reasoningEffort, "low");
    const global = await service.update(scope, saved.id, { provider: null, model: null });
    assert.equal(global.reasoningEffort, null);
  } finally { await service.dispose(); }
});

function selectionAgent(config: Record<string, unknown>) {
  const agent = {
    session: {
      header: { cwd: "D:\\work\\demo", agentPreset: "standard" },
      requestHeader: () => ({ config }),
    },
    ctx: {},
  };
  return { get: () => agent };
}

test("省略模型时整对继承，保存时去掉空白，不拼接不同来源", async () => {
  const scope = { sessionId: "session_1", creatorKind: "agent" as const };
  const base = { name: "检查", prompt: "检查", schedule: { kind: "daily" as const, time: "09:00", timeZone: "UTC" } };
  const partial = await makeService({}, {}, {
    agents: selectionAgent({ provider: "antigravity", model: "  " }),
    agentDefaultModel: { currentSelection: () => ({ provider: " deepseek ", model: " v4 " }) },
  });
  try {
    const inherited = await partial.service.create(scope, base);
    assert.deepEqual([inherited.provider, inherited.model], ["deepseek", "v4"]);
  } finally { await partial.service.dispose(); }

  const sessionWins = await makeService({}, {}, {
    agents: selectionAgent({ provider: " antigravity ", model: " gemini " }),
    agentDefaultModel: { currentSelection: () => ({ provider: "deepseek", model: "v4" }) },
  });
  try {
    const inherited = await sessionWins.service.create(scope, base);
    assert.deepEqual([inherited.provider, inherited.model], ["antigravity", "gemini"]);
  } finally { await sessionWins.service.dispose(); }

  const missing = await makeService({}, {}, {
    agents: selectionAgent({ provider: "antigravity" }),
    agentDefaultModel: { currentSelection: () => ({ provider: "deepseek" }) },
  });
  try {
    await assert.rejects(missing.service.create(scope, base), /当前会话和全局选择都没有完整的模型配对/);
    assert.equal(missing.definitions.size, 0);
    const followed = await missing.service.create(scope, { ...base, provider: null, model: null });
    assert.equal(followed.provider, null);
    assert.equal(followed.model, null);
    await assert.rejects(
      missing.service.create({ ...scope, creatorKind: "web", hostWide: true }, { ...base, workspaceId: "ws_1" }),
      /全局选择没有完整的模型配对/,
    );
  } finally { await missing.service.dispose(); }

  const { service } = await makeService();
  try {
    const created = await service.create(scope, { ...base, provider: " pi-ai ", model: " gemini ", reasoningEffort: "high" });
    assert.deepEqual([created.provider, created.model, created.reasoningEffort], ["pi-ai", "gemini", "high"]);
    const kept = await service.update(scope, created.id, { provider: " pi-ai ", model: " gemini " });
    assert.equal(kept.provider, "pi-ai");
    assert.equal(kept.model, "gemini");
    assert.equal(kept.reasoningEffort, "high");
  } finally { await service.dispose(); }
});

test("Agent 列表提供模型 ID、推理等级、全局选择和目录故障", async () => {
  const { service } = await makeService({}, {}, {
    llm: {
      listProviders: () => [{ id: "deepseek" }, { id: "offline" }],
      async listModels(provider: string) {
        if (provider === "offline") throw new Error("catalog offline");
        return [{ id: "v4", name: "V4" }];
      },
      async resolveModelInfo() { return { reasoning: { efforts: [{ id: "low", name: "Low" }], defaultEffort: "low" } }; },
    },
  });
  const tools = new Map<string, any>();
  const agent = { id: "session_1", ctx: { tools: { register(tool: any) { tools.set(tool.name, tool); return () => {}; } } } };
  const dispose = registerAutomationTools(service, agent);
  try {
    const result = await tools.get("automation_list").execute({}, { agent, signal: new AbortController().signal });
    assert.equal(result.ok, true);
    assert.equal(result.models[0].provider, "deepseek");
    assert.equal(result.models[0].model, "v4");
    assert.deepEqual(result.models[0].reasoning.efforts, [{ id: "low", name: "Low" }]);
    assert.equal(result.defaultModel.model, "v4");
    assert.equal(result.modelFailures[0].provider, "offline");
  } finally { dispose(); await service.dispose(); }
});

test("重启后只把遗留 running 标记为 host_interrupted，并保留尚未启动的 queued", async () => {
  const definition = sampleDefinition();
  const { runs } = await makeService({
    definitions: [definition],
    runs: [
      {
        version: 1,
        id: "run_old",
        automationId: definition.id,
        definitionRevision: 1,
        occurrenceKey: "k",
        trigger: "schedule",
        scheduledFor: "2026-08-16T00:30:00.000Z",
        status: "running",
        promptSnapshot: definition.prompt,
        targetSnapshot: {
          workspaceId: definition.workspaceId,
          cwd: definition.cwd,
          agentPreset: definition.agentPreset,
          provider: null,
          model: null,
          permissionPreset: "read-only",
        },
        sessionId: "sess",
        startedAt: "2026-08-16T00:30:00.000Z",
        finishedAt: null,
        summary: null,
        error: null,
        unread: true,
      },
      {
        version: 1,
        id: "run_queued",
        automationId: definition.id,
        definitionRevision: 1,
        occurrenceKey: "queued",
        trigger: "manual",
        scheduledFor: "2026-08-16T00:31:00.000Z",
        status: "queued",
        promptSnapshot: definition.prompt,
        targetSnapshot: {
          workspaceId: definition.workspaceId,
          cwd: definition.cwd,
          agentPreset: definition.agentPreset,
          provider: null,
          model: null,
          permissionPreset: "read-only",
        },
        sessionId: null,
        startedAt: null,
        finishedAt: null,
        summary: null,
        error: null,
        unread: false,
      },
    ],
  });
  const recovered = runs.get("run_old");
  assert.equal(recovered?.status, "failed");
  assert.equal(recovered?.error?.code, "host_interrupted");
  assert.equal(runs.get("run_queued")?.status, "queued");
  assert.equal(runs.get("run_queued")?.error, null);
});

test("重启后调度泵会领取已准入的 queued，且不按 misfire 窗口重新判定", async () => {
  const definition = sampleDefinition();
  let resolveWorkspaceStatus: ((status: string) => void) | undefined;
  const workspaceStatus = new Promise<string>((resolve) => {
    resolveWorkspaceStatus = resolve;
  });
  const { service, runs } = await makeService(
    {
      definitions: [definition],
      runs: [
        {
          version: 1,
          id: "run_queued",
          automationId: definition.id,
          definitionRevision: 1,
          occurrenceKey: "queued",
          trigger: "schedule",
          scheduledFor: "2026-08-16T01:00:00.000Z",
          status: "queued",
          promptSnapshot: definition.prompt,
          targetSnapshot: {
            workspaceId: definition.workspaceId,
            cwd: definition.cwd,
            agentPreset: definition.agentPreset,
            provider: null,
            model: null,
            permissionPreset: "read-only",
          },
          sessionId: null,
          startedAt: null,
          finishedAt: null,
          summary: null,
          error: null,
          unread: false,
        },
      ],
    },
    {},
    {
      workspaceRegistry: {
        get(id: unknown) {
          if (String(id) !== "ws_1") return undefined;
          return {
            id: "ws_1",
            title: "demo",
            path: "D:\\work\\demo",
            status: async () => workspaceStatus,
          };
        },
      },
    },
  );

  try {
    service.start();
    for (
      let attempt = 0;
      attempt < 20 && runs.get("run_queued")?.status === "queued";
      attempt += 1
    ) {
      await new Promise((resolve) => setImmediate(resolve));
    }
    const claimed = runs.get("run_queued");
    assert.equal(claimed?.status, "running");
    assert.match(claimed?.sessionId ?? "", /^dsh-automation-session-/);
    assert.equal(typeof claimed?.startedAt, "string");
    assert.equal(runs.size, 1);
  } finally {
    resolveWorkspaceStatus?.("unavailable");
    await service.dispose();
  }
});

test("ownsSession 通过前缀、运行记录和消息来源识别自动化会话", async () => {
  const { service } = await makeService();
  assert.equal(service.ownsSession("dsh-automation-session-abc"), true);
  assert.equal(
    service.ownsSession("user-session", [
      { type: "user/message", data: { source: { kind: "automation" } } },
    ]),
    true,
  );
  assert.equal(
    service.ownsSession("user-session", [
      { type: "user/message", data: { source: { kind: "user" } } },
    ]),
    false,
  );
  assert.equal(
    service.ownsSession("user-session", {
      deriveMessages: () => [{ source: { kind: "automation" } }],
      snapshotEvents: () => {
        throw new Error("deprecated");
      },
    }),
    true,
  );
});

test("创建和立即运行都限制在来源工作区", async () => {
  const { service } = await makeService();
  const created = await service.create(
    { sessionId: "session_1", creatorKind: "web" },
    {
      name: "一次性",
      prompt: "跑测试",
      schedule: {
        kind: "once",
        at: "2099-01-01T10:00:00.000Z",
        timeZone: "UTC",
      },
    },
  );
  assert.equal(created.workspaceId, "ws_1");
  const run = await service.runNow(
    { sessionId: "session_1", creatorKind: "web" },
    created.id,
  );
  assert.equal(run.trigger, "manual");
  await assert.rejects(
    () =>
      service.runNow(
        { sessionId: "session_1", creatorKind: "web" },
        created.id,
      ),
    /已有排队/,
  );
});

test("同目录的不同自动化全部启动，仍阻止同一自动化重叠和停止后的调度", async () => {
  const { service, runs } = await makeService();
  const internals = service as unknown as {
    active: Map<string, unknown>;
    stopping: boolean;
    startRun(run: AutomationRun): void;
    startQueuedRuns(): Promise<void>;
  };
  const now = "2026-09-12T00:00:00.000Z";
  const busyDefinition = sampleDefinition({ id: "busy" });
  const busy = createManualRun(busyDefinition, now);
  await runs.put(busy.id, { ...busy, status: "running" });
  internals.active.set(busy.id, {});
  const blocked = createManualRun(busyDefinition, now);
  await runs.put(blocked.id, blocked);
  const expected: string[] = [];
  for (let index = 0; index < 40; index++) {
    const definition = sampleDefinition({ id: `independent_${index}` });
    const run = createManualRun(definition, now);
    await runs.put(run.id, run);
    expected.push(run.id);
    if (index === 0) {
      const duplicate = createManualRun(definition, now);
      await runs.put(duplicate.id, duplicate);
    }
  }
  const started: string[] = [];
  // 在执行器边界记录启动，避免模型调用干扰调度行为的验证。
  internals.startRun = (run) => { started.push(run.id); };
  await internals.startQueuedRuns();
  assert.deepEqual(started, expected);
  internals.stopping = true;
  await internals.startQueuedRuns();
  assert.deepEqual(started, expected);
});

test("权限列表、默认值和校验均来自 Host 官方服务", async () => {
  const { service } = await makeService();
  const snapshot = await service.snapshot({
    sessionId: "session_1",
    creatorKind: "web",
    hostWide: true,
  });
  assert.deepEqual(
    snapshot.permissions.map((item) => item.value),
    permissionPresets.names,
  );
  assert.equal(snapshot.defaultPermission, "workspace-write");
  const created = await service.create(
    { sessionId: "session_1", creatorKind: "web" },
    {
      name: "官方默认权限",
      prompt: "检查状态",
      schedule: {
        kind: "once",
        at: "2099-01-01T10:00:00.000Z",
        timeZone: "UTC",
      },
    },
  );
  assert.equal(created.permissionPreset, "workspace-write");
  await assert.rejects(
    () =>
      service.update(
        { sessionId: "session_1", creatorKind: "web" },
        created.id,
        { permissionPreset: "not-official" },
      ),
    /unknown permission preset/,
  );
});

test("Agent 预设名册、默认值和校验均来自 Host 官方服务", async () => {
  const agentPresets = {
    defaultId: "minimal",
    composedPreset: () => "standard",
    async remoteExportList() {
      return {
        presets: [
          { id: "standard" },
          { id: "minimal", name: "极简模式" },
          { id: "broken", broken: "无法加载" },
        ],
      };
    },
  };
  const { service } = await makeService({}, {}, { agentPresets });
  const snapshot = await service.snapshot({
    sessionId: "session_1",
    creatorKind: "web",
    hostWide: true,
  });
  assert.equal(snapshot.defaultAgentPreset, "minimal");
  assert.deepEqual(
    snapshot.agentPresets.map((item) => item.id),
    ["standard", "minimal", "broken"],
  );

  const created = await service.create(
    { sessionId: "session_1", creatorKind: "web", hostWide: true },
    {
      name: "指定预设",
      prompt: "检查状态",
      schedule: { kind: "once", at: "2099-01-01T10:00:00.000Z", timeZone: "UTC" },
      agentPreset: "minimal",
      workspaceId: "ws_1",
      cwd: "D:\\work\\demo",
      permissionPreset: "read-only",
    },
  );
  assert.equal(created.agentPreset, "minimal");

  const inherited = await service.create(
    { sessionId: "session_1", creatorKind: "web", hostWide: true },
    {
      name: "默认预设",
      prompt: "检查状态",
      schedule: { kind: "once", at: "2099-01-02T10:00:00.000Z", timeZone: "UTC" },
      workspaceId: "ws_1",
      cwd: "D:\\work\\demo",
      permissionPreset: "read-only",
    },
  );
  assert.equal(inherited.agentPreset, "minimal");

  await assert.rejects(
    () =>
      service.update(
        { sessionId: "session_1", creatorKind: "web", hostWide: true },
        created.id,
        { agentPreset: "not-official" },
      ),
    /不在当前宿主名册中/,
  );
  const updated = await service.update(
    { sessionId: "session_1", creatorKind: "web", hostWide: true },
    created.id,
    { agentPreset: "standard" },
  );
  assert.equal(updated.agentPreset, "standard");
  await service.dispose();
});

test("Agent 预设名册读取失败不缓存，恢复后立即可用", async () => {
  let calls = 0;
  const agentPresets = {
    defaultId: "standard",
    composedPreset: () => "standard",
    async remoteExportList() {
      calls += 1;
      if (calls === 1) throw new Error("registry not ready");
      return { presets: [{ id: "standard" }, { id: "ptc" }] };
    },
  };
  const { service } = await makeService({}, {}, { agentPresets });
  const first = await service.agentPresetOptions();
  assert.deepEqual(first.map((item) => item.id), ["standard"]);
  const second = await service.agentPresetOptions();
  assert.deepEqual(second.map((item) => item.id), ["standard", "ptc"]);
  await service.dispose();
});

test("Agent 预设名册不可用时显式预设放行", async () => {
  const agentPresets = {
    defaultId: "standard",
    composedPreset: () => "standard",
    async remoteExportList() {
      throw new Error("down");
    },
  };
  const { service } = await makeService({}, {}, { agentPresets });
  const created = await service.create(
    { sessionId: "session_1", creatorKind: "web", hostWide: true },
    {
      name: "名册不可用",
      prompt: "检查状态",
      schedule: { kind: "once", at: "2099-01-01T10:00:00.000Z", timeZone: "UTC" },
      agentPreset: "ptc",
      workspaceId: "ws_1",
      cwd: "D:\\work\\demo",
      permissionPreset: "read-only",
    },
  );
  assert.equal(created.agentPreset, "ptc");
  await service.dispose();
});

test("Agent 预设名册为空时拒绝显式预设，不当成读取失败", async () => {
  const agentPresets = {
    defaultId: "standard",
    composedPreset: () => "standard",
    async remoteExportList() {
      return { presets: [] };
    },
  };
  const { service } = await makeService({}, {}, { agentPresets });
  assert.deepEqual(await service.agentPresetOptions(), []);
  await assert.rejects(
    () =>
      service.create(
        { sessionId: "session_1", creatorKind: "web", hostWide: true },
        {
          name: "空名册",
          prompt: "检查状态",
          schedule: { kind: "once", at: "2099-01-01T10:00:00.000Z", timeZone: "UTC" },
          agentPreset: "whatever",
          workspaceId: "ws_1",
          cwd: "D:\\work\\demo",
          permissionPreset: "read-only",
        },
      ),
    /未声明任何 Agent 预设/,
  );
  await service.dispose();
});

test("宿主声明零预设且无默认值时，快照默认值为空并拒绝创建", async () => {
  const agentPresets = {
    defaultId: "",
    composedPreset: () => "standard",
    async remoteExportList() {
      return { presets: [] };
    },
  };
  const { service } = await makeService({}, {}, { agentPresets });
  assert.equal(service.defaultAgentPreset(), "");
  const snapshot = await service.snapshot({
    sessionId: "session_1",
    creatorKind: "web",
    hostWide: true,
  });
  assert.equal(snapshot.defaultAgentPreset, "");
  assert.deepEqual(snapshot.agentPresets, []);
  await assert.rejects(
    () =>
      service.create(
        { sessionId: "session_1", creatorKind: "web", hostWide: true },
        {
          name: "零预设宿主",
          prompt: "检查状态",
          schedule: { kind: "once", at: "2099-01-01T10:00:00.000Z", timeZone: "UTC" },
          workspaceId: "ws_1",
          cwd: "D:\\work\\demo",
          permissionPreset: "read-only",
        },
      ),
    /未声明任何 Agent 预设/,
  );
  await service.dispose();
});

test("有预设但无默认值时，省略预设给中文错误，显式预设可创建", async () => {
  const agentPresets = {
    defaultId: "",
    composedPreset: () => "",
    async remoteExportList() {
      return { presets: [{ id: "standard" }, { id: "ptc" }] };
    },
  };
  const { service } = await makeService({}, {}, { agentPresets });
  const scope = { sessionId: "session_1", creatorKind: "web" as const, hostWide: true };
  const base = {
    name: "无默认预设",
    prompt: "检查状态",
    schedule: { kind: "once" as const, at: "2099-01-01T10:00:00.000Z", timeZone: "UTC" },
    workspaceId: "ws_1",
    cwd: "D:\\work\\demo",
    permissionPreset: "read-only",
  };
  await assert.rejects(() => service.create(scope, base), /请显式指定 agent_preset/);
  const created = await service.create(scope, { ...base, agentPreset: "ptc" });
  assert.equal(created.agentPreset, "ptc");
  await service.dispose();
});

test("名册读取失败且默认值为空时，回退名册不产生空 id 选项", async () => {
  const agentPresets = {
    defaultId: "",
    composedPreset: () => "",
    async remoteExportList() {
      throw new Error("down");
    },
  };
  const { service } = await makeService({}, {}, { agentPresets });
  assert.deepEqual(await service.agentPresetOptions(), []);
  await service.dispose();
});

test("Agent 预设名册可用时拒绝未知和损坏预设", async () => {
  const agentPresets = {
    defaultId: "standard",
    composedPreset: () => "standard",
    async remoteExportList() {
      return { presets: [{ id: "standard" }, { id: "broken", broken: "无法加载" }] };
    },
  };
  const { service } = await makeService({}, {}, { agentPresets });
  const scope = { sessionId: "session_1", creatorKind: "web" as const, hostWide: true };
  const base = {
    name: "预设校验",
    prompt: "检查状态",
    schedule: { kind: "once" as const, at: "2099-01-01T10:00:00.000Z", timeZone: "UTC" },
    workspaceId: "ws_1",
    cwd: "D:\\work\\demo",
    permissionPreset: "read-only",
  };
  await assert.rejects(
    () => service.create(scope, { ...base, agentPreset: "unknown" }),
    /不在当前宿主名册中/,
  );
  await assert.rejects(
    () => service.create(scope, { ...base, agentPreset: "broken" }),
    /当前不可用/,
  );
  await service.dispose();
});

test("存量任务预设已删除时仅改名仍可保存，改成未知值仍被拒绝", async () => {
  const agentPresets = {
    defaultId: "standard",
    composedPreset: () => "standard",
    async remoteExportList() {
      return { presets: [{ id: "standard" }] };
    },
  };
  const { service } = await makeService(
    { definitions: [sampleDefinition({ agentPreset: "deleted-preset" })] },
    {},
    { agentPresets },
  );
  const scope = { sessionId: "session_1", creatorKind: "web" as const, hostWide: true };
  const renamed = await service.update(scope, "automation_1", {
    name: "改名",
    agentPreset: "deleted-preset",
  });
  assert.equal(renamed.name, "改名");
  assert.equal(renamed.agentPreset, "deleted-preset");
  await assert.rejects(
    () => service.update(scope, "automation_1", { agentPreset: "unknown" }),
    /不在当前宿主名册中/,
  );
  await service.dispose();
});

test("启动时把旧 full-access 迁移成官方 danger-full-access", async () => {
  const legacy = sampleDefinition({ permissionPreset: "full-access" });
  const { definitions } = await makeService({ definitions: [legacy] });
  assert.equal(
    definitions.get(legacy.id)?.permissionPreset,
    "danger-full-access",
  );
});

test("服务端接受 Host 官方完全访问权限", async () => {
  const { service } = await makeService();
  const created = await service.create(
    { sessionId: "session_1", creatorKind: "web" },
    {
      name: "危险任务",
      prompt: "修改任意文件",
      schedule: {
        kind: "once",
        at: "2099-01-01T10:00:00.000Z",
        timeZone: "UTC",
      },
      permissionPreset: "danger-full-access",
    },
  );
  assert.equal(created.permissionPreset, "danger-full-access");
});

test("编辑已到期 once 的非计划字段时允许保留原时间", async () => {
  const definition = sampleDefinition();
  const { service } = await makeService({ definitions: [definition] });
  const updated = await service.update(
    { sessionId: "session_1", creatorKind: "web", hostWide: true },
    definition.id,
    { name: "改名后", schedule: definition.schedule },
  );
  assert.equal(updated.name, "改名后");
  const sameSchedule = await service.update(
    { sessionId: "session_1", creatorKind: "web", hostWide: true },
    definition.id,
    {
      schedule: {
        timeZone: "UTC",
        at: definition.schedule.kind === "once" ? definition.schedule.at : "",
        kind: "once",
      },
    },
  );
  assert.deepEqual(sameSchedule.schedule, definition.schedule);
  await assert.rejects(
    () =>
      service.update(
        { sessionId: "session_1", creatorKind: "web", hostWide: true },
        definition.id,
        {
          schedule: {
            kind: "once",
            at: "2026-08-17T01:00:00.000Z",
            timeZone: "UTC",
          },
        },
      ),
    /必须安排在未来/,
  );
});

test("更新工作区时必须由 id 和路径解析到同一个注册目录", async () => {
  const definition = sampleDefinition();
  const { service } = await makeService({ definitions: [definition] });
  await assert.rejects(
    () =>
      service.update(
        { sessionId: "session_1", creatorKind: "web", hostWide: true },
        definition.id,
        { workspaceId: "ws_1", cwd: "D:\\other" },
      ),
    /同一个已注册目录/,
  );
});

test("创建工作区时 id 和路径也必须解析到同一个注册目录", async () => {
  const { service } = await makeService();
  const scope = {
    sessionId: "session_1",
    creatorKind: "web" as const,
    hostWide: true,
  };
  const request = {
    name: "工作区检查",
    prompt: "检查状态",
    schedule: {
      kind: "once" as const,
      at: "2099-01-01T10:00:00.000Z",
      timeZone: "UTC",
    },
  };
  await assert.rejects(
    () =>
      service.create(scope, {
        ...request,
        workspaceId: "missing",
        cwd: "D:\\work\\demo",
      }),
    /同一个已注册目录/,
  );
  await assert.rejects(
    () =>
      service.create(scope, {
        ...request,
        workspaceId: "ws_1",
        cwd: "D:\\other",
      }),
    /同一个已注册目录/,
  );
  const byId = await service.create(scope, {
    ...request,
    name: "仅 ID",
    workspaceId: "ws_1",
  });
  const byPath = await service.create(scope, {
    ...request,
    name: "仅目录",
    cwd: "D:\\work\\demo",
  });
  assert.equal(byId.workspaceId, "ws_1");
  assert.equal(byId.cwd, "D:\\work\\demo");
  assert.equal(byPath.workspaceId, "ws_1");
  assert.equal(byPath.cwd, "D:\\work\\demo");
});

test("连续 snapshot 在短 TTL 内复用模型和技能目录结果", async () => {
  let listModelsCalls = 0;
  let resolveCalls = 0;
  const { service } = await makeService(
    {},
    {},
    {
      llm: {
        listProviders: () => [{ id: "deepseek", name: "DeepSeek" }],
        async listModels() {
          listModelsCalls += 1;
          return [{ id: "v4", name: "V4" }];
        },
        async resolveModelInfo() {
          resolveCalls += 1;
          return {};
        },
      },
    },
  );
  const scope = {
    sessionId: "session_1",
    creatorKind: "web" as const,
    hostWide: true,
  };
  await service.snapshot(scope);
  await service.snapshot(scope);
  assert.equal(listModelsCalls, 1);
  assert.equal(resolveCalls, 1);
});

test("forgetSession 会摘掉已删除 Session，但保留运行历史", async () => {
  const definition = sampleDefinition();
  const { service, runs } = await makeService({
    definitions: [definition],
    runs: [
      {
        version: 1,
        id: "run_keep",
        automationId: definition.id,
        definitionRevision: 1,
        occurrenceKey: "k2",
        trigger: "schedule",
        scheduledFor: "2026-08-16T00:30:00.000Z",
        status: "succeeded",
        promptSnapshot: definition.prompt,
        targetSnapshot: {
          workspaceId: definition.workspaceId,
          cwd: definition.cwd,
          agentPreset: definition.agentPreset,
          provider: null,
          model: null,
          permissionPreset: "read-only",
        },
        sessionId: "dead-session",
        startedAt: "2026-08-16T00:30:00.000Z",
        finishedAt: "2026-08-16T00:31:00.000Z",
        summary: "ok",
        error: null,
        unread: false,
      },
    ],
  });
  await service.forgetSession("dead-session");
  const kept = runs.get("run_keep");
  assert.equal(kept?.status, "succeeded");
  assert.equal(kept?.sessionId, null);
});

test("forgetSession 与运行完成并发时不会把终态覆盖回 running", async () => {
  const definition = sampleDefinition();
  const running: AutomationRun = {
    version: 1,
    id: "run_race_forget",
    automationId: definition.id,
    definitionRevision: 1,
    occurrenceKey: "race-forget",
    trigger: "schedule",
    scheduledFor: "2026-08-16T00:30:00.000Z",
    status: "running",
    promptSnapshot: definition.prompt,
    targetSnapshot: {
      workspaceId: definition.workspaceId,
      cwd: definition.cwd,
      agentPreset: definition.agentPreset,
      provider: null,
      model: null,
      permissionPreset: "read-only",
    },
    sessionId: "dead-session",
    startedAt: "2026-08-16T00:30:00.000Z",
    finishedAt: null,
    summary: null,
    error: null,
    unread: false,
  };
  const { service, runs } = await makeService({
    definitions: [definition],
    runs: [running],
  });
  runs.setNow(running.id, running);
  let release!: () => void;
  let mutationStarted!: () => void;
  const gate = new Promise<void>((resolve) => {
    release = resolve;
  });
  const started = new Promise<void>((resolve) => {
    mutationStarted = resolve;
  });
  let blocked = false;
  runs.beforeMutation = async (_kind, key) => {
    if (key !== running.id || blocked) return;
    blocked = true;
    mutationStarted();
    await gate;
  };

  const forgetting = service.forgetSession("dead-session");
  await started;
  runs.setNow(running.id, {
    ...running,
    status: "succeeded",
    finishedAt: "2026-08-16T00:31:00.000Z",
    summary: "ok",
    unread: true,
  });
  release();
  await forgetting;

  const completed = runs.get(running.id);
  assert.equal(completed?.status, "succeeded");
  assert.equal(completed?.summary, "ok");
  assert.equal(completed?.sessionId, null);
});

test("删除定义与运行完成并发时只更新历史任务名", async () => {
  const definition = sampleDefinition({ name: "当前任务名" });
  const running: AutomationRun = {
    version: 1,
    id: "run_race_delete",
    automationId: definition.id,
    automationName: "旧任务名",
    definitionRevision: 1,
    occurrenceKey: "race-delete",
    trigger: "schedule",
    scheduledFor: "2026-08-16T00:30:00.000Z",
    status: "running",
    promptSnapshot: definition.prompt,
    targetSnapshot: {
      workspaceId: definition.workspaceId,
      cwd: definition.cwd,
      agentPreset: definition.agentPreset,
      provider: null,
      model: null,
      permissionPreset: "read-only",
    },
    sessionId: "live-session",
    startedAt: "2026-08-16T00:30:00.000Z",
    finishedAt: null,
    summary: null,
    error: null,
    unread: false,
  };
  const { service, runs } = await makeService({
    definitions: [definition],
    runs: [running],
  });
  runs.setNow(running.id, running);
  let release!: () => void;
  let mutationStarted!: () => void;
  const gate = new Promise<void>((resolve) => {
    release = resolve;
  });
  const started = new Promise<void>((resolve) => {
    mutationStarted = resolve;
  });
  let blocked = false;
  runs.beforeMutation = async (_kind, key) => {
    if (key !== running.id || blocked) return;
    blocked = true;
    mutationStarted();
    await gate;
  };

  const deleting = service.delete(
    { sessionId: "session_1", creatorKind: "web", hostWide: true },
    definition.id,
  );
  await started;
  runs.setNow(running.id, {
    ...running,
    status: "succeeded",
    finishedAt: "2026-08-16T00:31:00.000Z",
    summary: "ok",
    unread: true,
  });
  release();
  await deleting;

  const completed = runs.get(running.id);
  assert.equal(completed?.status, "succeeded");
  assert.equal(completed?.summary, "ok");
  assert.equal(completed?.automationName, "当前任务名");
});

for (const scenario of [
  {
    name: "旧版已删除会话",
    stored: [{ id: "other" }],
    live: [],
    expected: null,
  },
  {
    name: "旧版冷会话",
    stored: [{ id: "ghost" }],
    live: [],
    expected: "ghost",
  },
  {
    name: "新版冷会话",
    stored: [{ header: { id: "ghost" }, revision: "r1" }],
    live: [],
    expected: "ghost",
  },
  {
    name: "新版已删除会话",
    stored: [{ header: { id: "other" }, revision: "r1" }],
    live: [],
    expected: null,
  },
  {
    name: "尚未落盘的活会话",
    stored: [],
    live: [{ id: "ghost" }],
    expected: "ghost",
  },
  { name: "持久化枚举抛错时保留关联", stored: [], live: [], expected: "ghost", warns: true, storedThrows: true },
  { name: "活会话枚举抛错时保留关联", stored: [], live: [], expected: "ghost", warns: true, liveThrows: true },
  { name: "缺少持久化枚举", stored: undefined, live: [], expected: "ghost" },
  {
    name: "枚举缺少 id 时保留关联",
    stored: [{ header: {} }],
    live: [],
    expected: "ghost",
    warns: true,
  },
  {
    name: "枚举不是数组时保留关联",
    stored: { items: [] },
    live: [],
    expected: "ghost",
    warns: true,
  },
  {
    name: "枚举空项时保留关联",
    stored: [null],
    live: [],
    expected: "ghost",
    warns: true,
  },
  {
    name: "枚举空白 id 时保留关联",
    stored: [{ id: " " }],
    live: [],
    expected: "ghost",
    warns: true,
  },
  {
    name: "部分枚举损坏时停止清理",
    stored: [{ id: "other" }, { id: 123 }],
    live: [],
    expected: "ghost",
    warns: true,
  },
  {
    name: "无关 header 回退顶层 id",
    stored: [{ id: "ghost", header: { title: "旧元数据" } }],
    live: [],
    expected: "ghost",
  },
  {
    name: "空 header 回退顶层 id",
    stored: [{ id: "ghost", header: null }],
    live: [],
    expected: "ghost",
  },
  {
    name: "活会话枚举异常时保留关联",
    stored: [],
    live: [{}],
    expected: "ghost",
    warns: true,
  },
]) {
  test(`启动对账保留真实关联：${scenario.name}`, async () => {
    const definition = sampleDefinition();
    const definitions = new MemoryTable<AutomationDefinition>();
    const runs = new MemoryTable<AutomationRun>();
    await definitions.put(definition.id, definition);
    await runs.put("run_ghost", {
      version: 1,
      id: "run_ghost",
      automationId: definition.id,
      definitionRevision: 1,
      occurrenceKey: "k3",
      trigger: "schedule",
      scheduledFor: "2026-08-16T00:30:00.000Z",
      status: "succeeded",
      promptSnapshot: definition.prompt,
      targetSnapshot: {
        workspaceId: definition.workspaceId,
        cwd: definition.cwd,
        agentPreset: definition.agentPreset,
        provider: null,
        model: null,
        permissionPreset: "read-only",
      },
      sessionId: "ghost",
      startedAt: "2026-08-16T00:30:00.000Z",
      finishedAt: "2026-08-16T00:31:00.000Z",
      summary: "ok",
      error: null,
      unread: false,
    });
    const warnings: string[] = [];
    const ctx = {
      permissionPresets,
      logger: {
        warn(message: string) {
          warnings.push(message);
        },
      },
      get(name: string) {
        return name === "sessionPersistence" && scenario.stored !== undefined
          ? {
              async list() {
                if ("storedThrows" in scenario) throw new Error("枚举读取失败");
                return scenario.stored;
              },
            }
          : undefined;
      },
      sessions: {
        list() {
          if ("liveThrows" in scenario) throw new Error("活会话枚举失败");
          return scenario.live;
        },
      },
      storageDomain: {
        async open() {
          return {
            name: "dsh_automation",
            table(name: string) {
              return name === "definitions" ? definitions : runs;
            },
            async close() {},
          };
        },
      },
      agents: {
        get() {
          return {
            session: { header: {}, requestHeader: () => ({ config: {} }) },
            ctx: {},
          };
        },
      },
      workspaceRegistry: {
        async resolveByPath() {
          return { id: "ws_1", title: "demo", path: "D:\\work\\demo" };
        },
      },
      agentDefaultModel: {
        currentSelection: () => ({ provider: "deepseek", model: "v4" }),
      },
      agentPresets: { composedPreset: () => "standard" },
    };
    const service = await AutomationService.open(ctx as never, config());
    Object.assign(service, { definitions, runs });
    const ghost = runs.get("run_ghost");
    assert.equal(ghost?.status, "succeeded");
    assert.equal(ghost?.sessionId, scenario.expected);
    assert.equal(warnings.length, "warns" in scenario ? 1 : 0);
  });
}

test("单任务并发上限统一约束手动准入、定时准入和队列启动", async () => {
  const definition = sampleDefinition({ maxConcurrentRuns: 2 });
  const { service, runs } = await makeService({ definitions: [definition] });
  const scope = { sessionId: "session_1", creatorKind: "web" as const };
  const results = await Promise.allSettled(Array.from({ length: 3 }, () => service.runNow(scope, definition.id)));
  assert.equal(results.filter(result => result.status === "fulfilled").length, 2);
  assert.equal(results.filter(result => result.status === "rejected").length, 1);
  const internals = service as any;
  const started: string[] = [];
  internals.startRun = (run: AutomationRun) => started.push(run.id);
  await internals.startQueuedRuns();
  assert.equal(started.length, 2);
  await internals.claimLatestDue(definition, "2026-08-16T01:00:00.000Z", [...runs.entries()].map(([, run]) => run));
  assert.equal([...runs.entries()].filter(([, run]) => run.status === "skipped").length, 1);
});

test("定时任务有剩余并发名额时准入，降低上限后等待现有运行结束", async () => {
  const definition = sampleDefinition({ maxConcurrentRuns: 2 });
  const { service, runs, definitions } = await makeService({ definitions: [definition] });
  const first = createManualRun(definition, "2026-08-16T00:50:00.000Z");
  await runs.put(first.id, { ...first, status: "running" });
  const internals = service as any;
  internals.active.set(first.id, {});
  await internals.claimLatestDue(definition, "2026-08-16T01:00:00.000Z", [...runs.entries()].map(([, run]) => run));
  assert.equal([...runs.entries()].filter(([, run]) => run.status === "queued").length, 1);
  await definitions.put(definition.id, { ...definition, maxConcurrentRuns: 1 });
  const started: string[] = [];
  internals.startRun = (run: AutomationRun) => started.push(run.id);
  await internals.startQueuedRuns();
  assert.equal(started.length, 0);
  internals.active.delete(first.id);
  await runs.put(first.id, { ...first, status: "succeeded" });
  await internals.startQueuedRuns();
  assert.equal(started.length, 1);
});

test("Agent 工具支持跨工作区查询、修改、迁移工作空间及运行与删除", async () => {
  const ws1 = { id: "ws_1", title: "demo", path: "D:\\work\\demo" };
  const ws2 = { id: "ws_2", title: "yyrenting", path: "D:\\Repository\\yyrenting" };
  const wsList = [ws1, ws2];
  const definitionWs2 = sampleDefinition({
    id: "auto_weather",
    name: "每日深圳天气查询",
    workspaceId: "ws_2",
    cwd: "D:\\Repository\\yyrenting",
    maxConcurrentRuns: 5,
  });
  const { service, definitions } = await makeService(
    { definitions: [definitionWs2] },
    {},
    {
      workspaceRegistry: {
        get(id: unknown) {
          return wsList.find((w) => w.id === String(id));
        },
        async resolveByPath(path: string) {
          // 对齐真宿主真实契约：非全限定抛 TypeError，路径不存在抛 ENOENT
          if (!path.includes("/") && !path.includes("\\") && !/^[a-zA-Z]:/.test(path)) {
            throw new TypeError(`Workspace path is not fully qualified: '${path}'`);
          }
          const found = wsList.find((w) => w.path === path);
          if (!found) {
            const err = new Error(`ENOENT: no such file or directory, realpath '${path}'`);
            (err as any).code = "ENOENT";
            throw err;
          }
          return found;
        },
        list() {
          return wsList;
        },
      },
    },
  );

  const tools = new Map<string, any>();
  const agent = {
    id: "session_1", // 属于 ws_1
    ctx: { tools: { register(tool: any) { tools.set(tool.name, tool); return () => {}; } } },
  };
  const dispose = registerAutomationTools(service, agent as any);
  const context = { agent, signal: new AbortController().signal };

  try {
    // 1. 默认仅列出当前工作区 (ws_1)，不包含 ws_2 任务
    const listDefault = await tools.get("automation_list").execute({}, context);
    assert.equal(listDefault.ok, true);
    assert.equal(listDefault.automations.length, 0);

    // 2. all_workspaces: true 可查到 ws_2 任务并带有工作区信息
    const listAll = await tools.get("automation_list").execute({ all_workspaces: true }, context);
    assert.equal(listAll.ok, true);
    assert.equal(listAll.automations.length, 1);
    assert.equal(listAll.automations[0].id, "auto_weather");
    assert.equal(listAll.automations[0].workspaceTitle, "yyrenting");

    // 3. 跨工作区操作未传 cross_workspace 时必须被拒绝，并返回目标工作区引导提示
    // 3.1 update 未确认拒绝
    const rejectedUpdate = await tools.get("automation_update").execute({
      id: "auto_weather",
      prompt: "新天气查询提示词",
    }, context);
    assert.equal(rejectedUpdate.ok, false);
    assert.match(rejectedUpdate.message, /该自动化属于工作区「yyrenting」/);
    assert.match(rejectedUpdate.message, /cross_workspace: true/);

    // 3.2 run_now 未确认拒绝
    const rejectedRun = await tools.get("automation_run_now").execute({ id: "auto_weather" }, context);
    assert.equal(rejectedRun.ok, false);
    assert.match(rejectedRun.message, /该自动化属于工作区「yyrenting」/);
    assert.match(rejectedRun.message, /cross_workspace: true/);

    // 3.3 delete 未确认拒绝
    const rejectedDelete = await tools.get("automation_delete").execute({ id: "auto_weather" }, context);
    assert.equal(rejectedDelete.ok, false);
    assert.match(rejectedDelete.message, /该自动化属于工作区「yyrenting」/);
    assert.match(rejectedDelete.message, /cross_workspace: true/);

    // 4. 显式声明 cross_workspace: true 时跨工作区修改和立即运行成功
    const updated = await tools.get("automation_update").execute({
      id: "auto_weather",
      prompt: "新天气查询提示词",
      status: "paused",
      cross_workspace: true,
    }, context);
    assert.equal(updated.ok, true);
    assert.equal(updated.automation.prompt, "新天气查询提示词");
    assert.equal(updated.automation.status, "paused");

    const runNowResult = await tools.get("automation_run_now").execute({ id: "auto_weather", cross_workspace: true }, context);
    assert.equal(runNowResult.ok, true);
    assert.equal(runNowResult.run.automationId, "auto_weather");
    const ws2RunId = runNowResult.run.id;

    // 5. markRead 针对别区记录测试：未确认拒绝，显式确认后成功
    await assert.rejects(
      () => service.markRead({ sessionId: "session_1", creatorKind: "agent" }, ws2RunId),
      /该运行记录属于工作区「yyrenting」/,
    );
    const marked = await service.markRead({ sessionId: "session_1", creatorKind: "agent", crossWorkspace: true }, ws2RunId);
    assert.equal(marked.unread, false);

    // 6. 跨工作区新建：直接新建到 yyrenting (ws_2) 未确认拒绝，确认后成功
    const rejectedCreate = await tools.get("automation_create").execute({
      name: "跨区新建",
      prompt: "新任务",
      kind: "hourly",
      minute: 10,
      time_zone: "UTC",
      workspace: "yyrenting",
    }, context);
    assert.equal(rejectedCreate.ok, false);
    assert.match(rejectedCreate.message, /将自动化创建到其他工作区「yyrenting」/);

    const allowedCreate = await tools.get("automation_create").execute({
      name: "跨区新建",
      prompt: "新任务",
      kind: "hourly",
      minute: 10,
      time_zone: "UTC",
      workspace: "yyrenting",
      cross_workspace: true,
    }, context);
    assert.equal(allowedCreate.ok, true);
    assert.equal(allowedCreate.automation.workspaceId, "ws_2");

    // 7. 迁移工作空间：未传 cross_workspace 拒绝迁移，传了之后迁移至 demo (ws_1)
    const rejectedMigrate = await tools.get("automation_update").execute({
      id: "auto_weather",
      workspace: "demo",
    }, context);
    assert.equal(rejectedMigrate.ok, false);

    const migrated = await tools.get("automation_update").execute({
      id: "auto_weather",
      workspace: "demo",
      cross_workspace: true,
    }, context);
    assert.equal(migrated.ok, true);
    assert.equal(migrated.automation.workspaceId, "ws_1");
    assert.equal(migrated.automation.cwd, "D:\\work\\demo");

    // 8. 不存在的工作区抛出明确中文错误，而不是外泄英文 TypeError/ENOENT
    const notFoundWorkspace = await tools.get("automation_update").execute({
      id: "auto_weather",
      workspace: "non_existent_workspace",
      cross_workspace: true,
    }, context);
    assert.equal(notFoundWorkspace.ok, false);
    assert.match(notFoundWorkspace.message, /所选工作区「non_existent_workspace」不存在或目录未注册。/);

    // 9. 任务已迁移至当前工作区 ws_1，此时不带 cross_workspace 也可运行
    const localRun = await tools.get("automation_run_now").execute({ id: "auto_weather" }, context);
    assert.equal(localRun.ok, true);

    // 9.1 迁出到其他工作区 (ws_2)：未声明 cross_workspace 必须被阻断
    const rejectedOutMigrate = await tools.get("automation_update").execute({
      id: "auto_weather",
      workspace: "yyrenting",
    }, context);
    assert.equal(rejectedOutMigrate.ok, false);
    assert.match(rejectedOutMigrate.message, /将自动化迁移到其他工作区「yyrenting」/);

    // 9.2 声明 cross_workspace: true 允许迁出至 ws_2
    const allowedOutMigrate = await tools.get("automation_update").execute({
      id: "auto_weather",
      workspace: "yyrenting",
      cross_workspace: true,
    }, context);
    assert.equal(allowedOutMigrate.ok, true);
    assert.equal(allowedOutMigrate.automation.workspaceId, "ws_2");

    // 10. 删除任务（其他区带 cross_workspace 删）
    const deleteResult = await tools.get("automation_delete").execute({ id: "auto_weather", cross_workspace: true }, context);
    assert.equal(deleteResult.ok, true);
    assert.equal(definitions.get("auto_weather"), undefined);
    await tools.get("automation_delete").execute({ id: allowedCreate.automation.id, cross_workspace: true }, context);
  } finally {
    dispose();
    await service.dispose();
  }
});

test("存在多个同名工作区时迁移会提示歧义并阻止误操作", async () => {
  const wsList = [
    { id: "ws_a", title: "same_name", path: "D:\\a\\project" },
    { id: "ws_b", title: "same_name", path: "D:\\b\\project" },
  ];
  const definition = sampleDefinition({ id: "auto_dup", workspaceId: "ws_a", cwd: "D:\\a\\project" });
  const { service } = await makeService(
    { definitions: [definition] },
    {},
    {
      workspaceRegistry: {
        get(id: unknown) { return wsList.find((w) => w.id === String(id)); },
        async resolveByPath() { throw new TypeError("not qualified"); },
        list() { return wsList; },
      },
    },
  );
  try {
    await assert.rejects(
      () => service.update({ sessionId: "session_1", creatorKind: "web", hostWide: true }, definition.id, {
        workspace: "same_name",
      }),
      /存在多个名为「same_name」的工作区/,
    );
  } finally {
    await service.dispose();
  }
});

test("来源会话目录未注册工作区时，显式指定工作区并确认 cross_workspace 可创建成功", async () => {
  const ws = { id: "ws_registered", title: "registered", path: "D:/repo/reg" };
  const { service } = await makeService(
    {},
    {},
    {
      workspaceRegistry: {
        get(id: unknown) { return String(id) === ws.id ? ws : undefined; },
        async resolveByPath(p: string) { return p === ws.path ? ws : undefined; },
        list() { return [ws]; },
      },
      agents: {
        get() {
          return {
            session: {
              header: { cwd: "D:/unregistered/path" },
              requestHeader: () => ({ config: { provider: "deepseek", model: "v4" } }),
            },
            ctx: {},
          };
        },
      },
    },
  );
  try {
    const scope = { sessionId: "session_1", creatorKind: "agent" as const };
    const request = {
      name: "未注册目录会话创建任务",
      prompt: "执行",
      schedule: { kind: "once" as const, at: "2099-01-01T00:00:00.000Z", timeZone: "UTC" },
      workspace: "registered",
    };
    // 未带 cross_workspace 提示需要显式确认
    await assert.rejects(
      () => service.create(scope, request),
      /将自动化创建到其他工作区「registered」.*需要显式确认/,
    );
    // 声明 cross_workspace: true 成功创建
    const created = await service.create({ ...scope, crossWorkspace: true }, request);
    assert.equal(created.workspaceId, "ws_registered");
    assert.equal(created.cwd, "D:/repo/reg");
  } finally {
    await service.dispose();
  }
});
