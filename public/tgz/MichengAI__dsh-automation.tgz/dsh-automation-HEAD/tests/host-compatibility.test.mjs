// 独立进程加载 npm 宿主实现，不使用 register-dsh-stubs；模型响应固定且不联网。
import assert from "node:assert/strict";
import test from "node:test";
import { mkdtempSync, rmSync } from "node:fs";
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import { pathToFileURL } from "node:url";
import { dirname, join } from "node:path";
import { Context, Inject } from "@deepseek-ai/cordis";

const requireResolver = createRequire(import.meta.url);
import { load } from "js-yaml";
import { applyEntryPatches } from "@deepseek-ai/cordis-plugin-include";
import LlmRuntime, { LlmAdapter } from "@deepseek-ai/dsh-llm";
import SessionStore from "@deepseek-ai/dsh-session";
import SessionProjectionRegistry from "@deepseek-ai/dsh-session-projection";
import SystemPrompt from "@deepseek-ai/dsh-system-prompt";
import ToolRuntime from "@deepseek-ai/dsh-tools";
import AgentRegistry from "@deepseek-ai/dsh-agent";
import AgentLoop from "@deepseek-ai/dsh-agent-loop";
import ApprovalService from "@deepseek-ai/dsh-user-approval";
import PermissionPresets from "@deepseek-ai/dsh-permission-presets";
import * as Connection from "@deepseek-ai/dsh-client-connection";
import { apply as applyAutomation, inject as automationInject } from "../src/index.ts";
import { registerAutomationRpc } from "../src/rpc.ts";
import { createDefinition, createScheduledRun } from "../src/domain.ts";
import { executeAutomationRun } from "../src/executor.ts";

class FixedAdapter extends LlmAdapter {
  requests = [];
  async resolveModel(provider, model) {
    return { provider, id: model, name: model };
  }
  async *stream(request) {
    this.requests.push(request);
    yield { type: "block-start", index: 0, blockType: "text" };
    yield { type: "text-delta", index: 0, text: "兼容性验收通过" };
    yield {
      type: "block-end",
      index: 0,
      block: { type: "text", text: "兼容性验收通过" },
    };
    yield { type: "usage", usage: { inputTokens: 10, outputTokens: 5 } };
    yield { type: "finish", reason: { kind: "stop" } };
  }
}

const hostVersion = process.env.DSH_TEST_VERSION ?? "0.2.1-rc.2";
const explicitAgent = hostVersion.startsWith("0.2.");
const sessionHeaderVersion = 4;

test(`${hostVersion} 真实 Connection 在插件作用域注册和卸载自动化 RPC`, async (t) => {
  const ctx = new Context();
  t.after(() => ctx.fiber.dispose());
  const routes = new Set();
  const startupService = /^0\.2\.1-/.test(hostVersion) ? "webStartup" : "webRuntime";
  ctx.provide(startupService, { trustedHosts: [] });
  // 与真实 Loader 一致：WebServer 来自兄弟插件，不能用根 Context 的无条件提供掩盖缺失注入。
  await ctx.plugin({
    apply(owner) {
      owner.provide("webServer", {
        port: 0,
        register(route) {
          routes.add(route);
          return () => routes.delete(route);
        },
        registerUpgrade() {
          return () => {};
        },
        tapIndex() {
          return () => {};
        },
      });
    },
  });
  let record;
  ctx.provide("credentials", {
    async readRecord() {
      return record;
    },
    async modifyRecord(_key, mutate) {
      record = await mutate(record);
      return record;
    },
  });
  const patches = load(
    await readFile(new URL("../cordis.patch.yml", import.meta.url), "utf8"),
  );
  assert.ok(Array.isArray(patches), "bundle 必须是 YAML 补丁列表");
  const warnings = [];
  const base = [
    {
      id: "connection",
      name: "@deepseek-ai/dsh-client-connection",
      inject: [startupService],
    },
  ];
  // 先用官方引擎替换配置，再按 Loader 语义合并插件源码依赖，覆盖两个层次。
  const entries = applyEntryPatches(base, patches, (...args) =>
    warnings.push(args),
  );
  const entry = entries.find((item) => item.id === "connection");
  assert.deepEqual(warnings, []);
  assert.deepEqual(entry?.inject, [startupService], "必须保留官方 Connection 的配置依赖");
  assert.deepEqual(base[0].inject, [startupService], "补丁不可污染原始 bundle");
  const inject = Inject.resolve(Connection.inject);
  Inject.resolve(entry.inject, inject);
  for (const dependency of Object.keys(Inject.resolve(Connection.inject)))
    assert.ok(dependency in inject);
  await ctx.plugin({ ...Connection, inject });
  let remove;
  await ctx.plugin({
    inject: ["connection", "webServer"],
    apply(owner) {
      remove = registerAutomationRpc(owner, {});
    },
  });
  assert.ok([...routes].some((route) => route.path === "/dsh-automation"));
  await remove();
  assert.ok(![...routes].some((route) => route.path === "/dsh-automation"));
});

test("自动化补丁保留新旧 Connection 的配置及自定义注入", async () => {
  const patches = load(
    await readFile(new URL("../cordis.patch.yml", import.meta.url), "utf8"),
  );
  assert.ok(Array.isArray(patches));
  for (const service of ["webRuntime", "webStartup"]) {
    const base = [{
      id: "connection",
      name: "@deepseek-ai/dsh-client-connection",
      inject: [service, "customExtra"],
      config: {
        trustedHosts: { __jsExpr: `ctx.${service}.trustedHosts` },
        recovery: { maxRetries: 7 },
      },
    }];
    const applied = applyEntryPatches(base, patches, () => assert.fail("补丁不应告警"));
    assert.deepEqual(applied[0], base[0]);
    assert.notEqual(applied[0], base[0]);
  }
});

test(`${hostVersion} 真实 AgentLoop 执行自动化、保留权限日志并释放 Agent`, {
  timeout: 10_000,
}, async (t) => {
  const ctx = new Context();
  t.after(() => ctx.fiber.dispose());
  await ctx.plugin(LlmRuntime);
  await ctx.plugin(SessionStore);
  await ctx.plugin(SessionProjectionRegistry);
  await ctx.plugin(SystemPrompt);
  await ctx.plugin(ToolRuntime);
  if (typeof ctx.tools?.setExecutor === "function") {
    try {
      const toolsDir = dirname(requireResolver.resolve("@deepseek-ai/dsh-tools"));
      const pipelineUrl = pathToFileURL(join(toolsDir, "pipeline.js")).href;
      const indexUrl = pathToFileURL(join(toolsDir, "index.js")).href;
      const { ToolExecutionPipeline, executeToolBatch } = await import(pipelineUrl);
      const toolsMod = await import(indexUrl);
      const pipeline = new ToolExecutionPipeline(ctx);
      ctx.tools.setExecutor({
        describe: (tools) => ({ schemas: tools.map((d) => toolsMod.projectToolSchema ? toolsMod.projectToolSchema(d, false) : []) }),
        execute: async (input) => {
          const isSingleCall = !input.calls && input.name;
          const batchInput = isSingleCall
            ? { ...input, calls: [{ id: input.callId, name: input.name, arguments: JSON.stringify(input.arguments ?? {}) }] }
            : input;
          const outcome = await executeToolBatch(batchInput, pipeline, () => 10);
          return isSingleCall ? (outcome.results[0]?.result ?? outcome) : outcome;
        },
      });
    } catch {}
  }
  await ctx.plugin(AgentRegistry);
  await ctx.plugin(ApprovalService);
  // 此夹具不执行 shell，只提供权限预设读取的宿主能力描述。
  ctx.provide("shell", { sandboxMode: "workspace-write" });
  await ctx.plugin(PermissionPresets, { defaultPreset: "workspace-write" });
  await ctx.plugin(AgentLoop, { agents: [] });
  const adapter = new FixedAdapter();
  ctx.llm.registerAdapter(["compat"], adapter);
  const cwd = process.cwd();
  const attached = [];
  ctx.provide("workspaceRegistry", {
    get: () => ({
      path: cwd,
      status: async () => "ok",
      attachSession: async (id) => {
        attached.push(id);
      },
    }),
  });
  ctx.provide("agentDefaultModel", {
    currentSelection: () => ({ provider: "compat", model: "fixed" }),
  });
  ctx.provide("agentPresets", {
    mount: async (agentCtx) => {
      if (explicitAgent)
        assert.throws(() => agentCtx.agent, /cannot get property "agent"/);
      else assert.ok(agentCtx.agent.session);
    },
  });
  let session;
  ctx.on("agent/created", ({ agent }) => {
    session = agent.session;
  });
  const definition = createDefinition({
    id: "compat",
    name: "新版宿主验收",
    prompt: "输出验收结果",
    schedule: { kind: "once", at: "2026-09-11T00:00:00Z", timeZone: "UTC" },
    workspaceId: "compat-workspace",
    cwd,
    agentPreset: "standard",
    provider: "compat",
    model: "fixed",
    permissionPreset: "danger-full-access",
    createdBy: { kind: "web", sessionId: "source" },
    now: "2026-09-10T00:00:00Z",
  });
  const run = createScheduledRun(definition, "2026-09-11T00:00:00Z");
  const result = await executeAutomationRun(ctx, definition, run, {
    sessionId: "compat-run",
    runTimeoutMs: 3_000,
  });
  assert.equal(result.status, "succeeded", JSON.stringify(result));
  assert.equal(result.summary, "兼容性验收通过");
  assert.equal(adapter.requests.length, 1);
  assert.deepEqual(attached, ["compat-run"]);
  const events =
    typeof session.snapshotEvents === "function"
      ? session.snapshotEvents()
      : session.events;
  assert.equal(session.header.version, sessionHeaderVersion);
  assert.equal(
    events.findLast((event) => event.type === "permission/preset")?.data.preset,
    "danger-full-access",
  );
  assert.equal(
    events.findLast((event) => event.type === "approval/policy")?.data.policy,
    "never",
  );
  assert.equal(ctx.agents.get("compat-run"), undefined);
  assert.equal(ctx.sessions.get("compat-run"), undefined);
});

test("真实 DSH Schema 可编译全部自动化管理工具", async () => {
  const { registerAutomationTools } = await import("../src/tools.ts");
  const registered = [];
  const agent = {
    id: "schema-regression",
    ctx: { tools: { register(definition) { registered.push(definition); return () => {}; } } },
  };
  const dispose = registerAutomationTools({ permissionNames: () => ["read-only"] }, agent);
  assert.equal(registered.length, 6);
  for (const name of ["automation_create", "automation_update"]) {
    const tool = registered.find(item => item.name === name);
    assert.equal(tool.parameters.properties.max_concurrent_runs.type, "integer");
    for (const field of ["provider", "model", "reasoning_effort"]) {
      assert.deepEqual(tool.parameters.properties[field].oneOf, [{ type: "string" }, { type: "null" }]);
      assert.equal(tool.parameters.required.includes(field), false);
    }
  }
  dispose();
});

test(`${hostVersion} 真实 AgentRegistry 下 apply 正常启动并仅向根会话挂载管理工具`, {
  timeout: 10_000,
}, async (t) => {
  const ctx = new Context();
  const stateDir = mkdtempSync(join(tmpdir(), "dsh-automation-compat-apply-"));
  t.after(async () => {
    await ctx.fiber.dispose();
    rmSync(stateDir, { recursive: true, force: true });
  });
  await ctx.plugin(LlmRuntime);
  await ctx.plugin(SessionStore);
  await ctx.plugin(SessionProjectionRegistry);
  await ctx.plugin(SystemPrompt);
  await ctx.plugin(ToolRuntime);
  await ctx.plugin(AgentRegistry);
  await ctx.plugin(ApprovalService);
  ctx.provide("shell", { sandboxMode: "workspace-write" });
  await ctx.plugin(PermissionPresets, { defaultPreset: "workspace-write" });
  await ctx.plugin(AgentLoop, { agents: [] });
  ctx.llm.registerAdapter(["compat"], new FixedAdapter());
  const cwd = process.cwd();
  const memTable = () => {
    const map = new Map();
    return {
      get: (k) => map.get(k),
      entries: () => map.entries(),
      keys: () => map.keys(),
      get size() { return map.size; },
      async put(k, v) { map.set(k, v); },
      async delete(k) { return map.delete(k); },
      async update(k, fn) { const n = fn(map.get(k)); map.set(k, n); return n; },
    };
  };
  const tables = new Map([["definitions", memTable()], ["runs", memTable()]]);
  ctx.provide("storageDomain", {
    async open() {
      return {
        name: "dsh_automation",
        table: (name) => tables.get(name),
        async close() {},
      };
    },
  });
  ctx.provide("workspaceRegistry", {
    list: () => [],
    get: () => undefined,
    resolveByPath: async () => undefined,
  });
  ctx.provide("agentDefaultModel", {
    currentSelection: () => ({ provider: "compat", model: "fixed" }),
  });
  ctx.provide("agentPresets", {
    defaultId: "standard",
    async mount() {},
  });
  ctx.provide("connection", {
    rpc: { handle: () => async () => {} },
  });
  ctx.provide("webServer", {
    register: () => () => {},
  });

  const legacyRoots = typeof ctx.agents.roots === "function";
  const createChild = async (sessionId, rootAgent) => ctx.agents.create(
    legacyRoots
      ? {
          sessionId,
          parentAgent: rootAgent,
          meta: { cwd },
          agentOptions: { provider: "compat", model: "fixed" },
          setup: async () => {},
        }
      : {
          sessionId,
          meta: { cwd, origin: "subagent", delegationDepth: 1 },
          agentOptions: { provider: "compat", model: "fixed", subagentDepth: 1 },
          setup: async () => {},
        },
  );

  const startupRoot = await ctx.agents.create({
    sessionId: "compat-apply-startup-root",
    meta: { cwd },
    agentOptions: { provider: "compat", model: "fixed" },
    setup: async () => {},
  });
  const startupChild = await createChild("compat-apply-startup-child", startupRoot.agent);

  await ctx.plugin({
    inject: automationInject,
    apply: (pluginCtx) => applyAutomation(pluginCtx, {
      runTimeoutMinutes: 60,
      misfireGraceMinutes: 15,
      historyLimit: 200,
      stateDir,
    }),
  });

  assert.ok(ctx.tools.get("automation_create", startupRoot.agent) !== undefined);
  assert.equal(ctx.tools.get("automation_create", startupChild.agent), undefined);

  const liveRoot = await ctx.agents.create({
    sessionId: "compat-apply-live-root",
    meta: { cwd },
    agentOptions: { provider: "compat", model: "fixed" },
    setup: async () => {},
  });
  const liveChild = await createChild("compat-apply-live-child", liveRoot.agent);
  const ownedAutomation = await ctx.agents.create({
    sessionId: "dsh-automation-session-compat-owned",
    meta: { cwd },
    agentOptions: { provider: "compat", model: "fixed" },
    setup: async () => {},
  });

  assert.ok(ctx.tools.get("automation_create", liveRoot.agent) !== undefined);
  assert.equal(ctx.tools.get("automation_create", liveChild.agent), undefined);
  assert.equal(ctx.tools.get("automation_create", ownedAutomation.agent), undefined);
});
