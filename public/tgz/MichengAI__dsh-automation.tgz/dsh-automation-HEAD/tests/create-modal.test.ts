import assert from 'node:assert/strict'
import test from 'node:test'
import { readFileSync } from 'node:fs'
import {
  resolvePresetGuard,
  shouldConfirmFullAccess,
  shouldCloseCreateModal,
} from '../src/client/create-modal-logic.ts'

test('新建弹窗点遮罩不能关，Esc 只关弹窗', () => {
  assert.equal(shouldCloseCreateModal('backdrop'), false)
  assert.equal(shouldCloseCreateModal('escape'), true)
  assert.equal(shouldCloseCreateModal('cancel'), true)
})

test('预设门禁区分零预设、未选预设、旧快照和编辑态', () => {
  assert.deepEqual(resolvePresetGuard({ loaded: true, presets: 0, defaultPreset: '', selected: '' }), { missing: true, required: false })
  assert.deepEqual(resolvePresetGuard({ loaded: true, presets: 2, defaultPreset: '', selected: '' }), { missing: false, required: true })
  assert.deepEqual(resolvePresetGuard({ loaded: true, presets: 2, defaultPreset: 'standard', selected: 'standard' }), { missing: false, required: false })
  assert.deepEqual(resolvePresetGuard({ loaded: false, presets: 0, defaultPreset: '', selected: '' }), { missing: false, required: false })
  assert.deepEqual(resolvePresetGuard({ editing: true, loaded: true, presets: 0, defaultPreset: '', selected: '' }), { missing: false, required: false })
  assert.deepEqual(resolvePresetGuard({ loaded: true, presets: 2, defaultPreset: '', selected: 'ptc' }), { missing: false, required: false })
})

test('宿主未声明预设时新建弹窗说明原因并禁用保存', () => {
  const modal = readFileSync(new URL('../src/client/create-modal.tsx', import.meta.url), 'utf8')
  assert.match(modal, /resolvePresetGuard\(\{/)
  assert.match(modal, /presetMissing && <p className="dsh-st-error" role="alert">/)
  assert.match(modal, /presetRequired && <p className="dsh-st-muted">/)
  assert.match(modal, /form\.agentPresetMissing/)
  assert.match(modal, /form\.agentPresetRequired/)
  assert.match(modal, /agentPresetsLoaded !== false/)
  assert.match(modal, /disabled=\{busy \|\| addingWorkspace \|\| !workspaceReady \|\| presetMissing \|\| presetRequired\}/)
})

test('任务编辑弹窗使用宿主 Modal，点遮罩不能关闭', () => {
  const modal = readFileSync(new URL('../src/client/create-modal.tsx', import.meta.url), 'utf8')
  const styles = readFileSync(new URL('../src/client/styles.ts', import.meta.url), 'utf8')

  assert.match(modal, /<Modal/)
  assert.match(modal, /blockHostModalBackdrop/)
  assert.match(modal, /dsh-st-create-dialog/)
  assert.match(modal, /contentClassName="dsh-st-create-content"/)
  assert.match(styles, /\.dsh-st-create-dialog\{[^}]*max-height:100%/)
  assert.match(styles, /\.dsh-st-create-content>div:last-child\{[^}]*overflow-y:auto/)
  assert.match(styles, /\.dsh-st-create-content>div:last-child\{[^}]*min-height:0/)
  assert.match(modal, /event\.stopImmediatePropagation\(\)/)
  assert.match(modal, /onClose\(\)/)
  assert.doesNotMatch(modal, /AntdProvider|from ["']antd|antd\/es/)
  assert.doesNotMatch(modal, /dsh-st-modal-close/)
  assert.doesNotMatch(styles, /\.dsh-st-modal\{/)
  assert.doesNotMatch(styles, /\.dsh-st-mask\{/)
})

test('权限选择与 Chat 一致，切换到完全访问时要求风险确认', () => {
  assert.equal(shouldConfirmFullAccess('read-only', 'danger-full-access'), true)
  assert.equal(shouldConfirmFullAccess('workspace-write', 'danger-full-access'), true)
  assert.equal(shouldConfirmFullAccess('danger-full-access', 'danger-full-access'), false)
  assert.equal(shouldConfirmFullAccess('danger-full-access', 'read-only'), false)
})

test('任务表单可以添加工作区，未登记时不能保存', () => {
  const modal = readFileSync(new URL('../src/client/create-modal.tsx', import.meta.url), 'utf8')
  const styles = readFileSync(new URL('../src/client/styles.ts', import.meta.url), 'utf8')
  assert.match(modal, /IconPlusOutline/)
  assert.match(modal, /add-workspace/)
  assert.doesNotMatch(styles, /ant-btn|ant-select/)
  assert.match(modal, /variant="primary"/)
  assert.doesNotMatch(modal, /popupRender/)
  assert.match(modal, /document\.activeElement instanceof HTMLElement/)
  assert.doesNotMatch(modal, /getPopupContainer/)
  assert.match(modal, /!workspaceReady/)
  assert.match(modal, /form\.workspaceRequired/)
})

test('任务模型用分组选择和推理等级选择，不再自绘两层面板', () => {
  const modal = readFileSync(new URL('../src/client/create-modal.tsx', import.meta.url), 'utf8')
  const styles = readFileSync(new URL('../src/client/styles.ts', import.meta.url), 'utf8')
  assert.match(modal, /models\.reduce/)
  assert.match(modal, /item\?\.reasoning\?\.defaultEffort \?\? 'none'/)
  assert.match(modal, /modelT\('effort\.providerDefault'\)/)
  assert.doesNotMatch(modal, /setPane\('model'\)|setPane\('effort'\)|role="menuitemradio"/)
  assert.doesNotMatch(modal, /form\.modelDefault|跟随默认模型|reasoningEffort: 'high'/)
  assert.doesNotMatch(styles, /\.dsh-st-model-select/)
  assert.doesNotMatch(styles, /\.dsh-st-select-menu/)
})

test('工作区、模型、推理等级和权限在输入区上方两列排列，技能用 / 召回', () => {
  const modal = readFileSync(new URL('../src/client/create-modal.tsx', import.meta.url), 'utf8')
  const styles = readFileSync(new URL('../src/client/styles.ts', import.meta.url), 'utf8')
  const settingsAt = modal.indexOf('dsh-st-settings')
  const promptAt = modal.indexOf("t('form.prompt')")
  assert.ok(settingsAt >= 0 && promptAt > settingsAt)
  assert.match(modal, /form\.fieldWorkspace/)
  assert.match(modal, /form\.fieldModel/)
  assert.match(modal, /form\.fieldEffort/)
  assert.match(modal, /form\.fieldPermission/)
  assert.match(modal, /dsh-st-skill-menu/)
  assert.doesNotMatch(modal, /slice\(0,\s*8\)/)
  assert.match(styles, /\.dsh-st-skill-menu\{[^}]*bottom:calc\(100%/)
  assert.match(modal, /dsh-st-skill-token/)
  assert.match(modal, /spellCheck=\{false\}/)
  assert.doesNotMatch(modal, /form\.skills/)
  assert.match(styles, /grid-template-columns:1fr 1fr/)
  assert.match(styles, /\.dsh-st-plan-row\{[^}]*grid-template-columns:minmax\(0,1fr\) minmax\(0,1fr\)/)
  assert.match(styles, /\.dsh-st-picker-field \.dsh-st-menu-select-wrap>span\{[^}]*width:100%/)
})

test('间隔输入是短框，自定义写成每隔几天', () => {
  const modal = readFileSync(new URL('../src/client/create-modal.tsx', import.meta.url), 'utf8')
  const styles = readFileSync(new URL('../src/client/styles.ts', import.meta.url), 'utf8')
  const locales = readFileSync(new URL('../src/client/locales/zh.ts', import.meta.url), 'utf8')
  assert.match(modal, /dsh-st-amount/)
  assert.match(modal, /form\.every/)
  assert.match(modal, /form\.customHint/)
  assert.match(styles, /\.dsh-st-amount\{[^}]*width:128px/)
  assert.match(locales, /每隔几天/)
})

test('删除任务必须先显示确认对话框', () => {
  const view = readFileSync(new URL('../src/client/AutomationView.tsx', import.meta.url), 'utf8')
  const confirmation = readFileSync(new URL('../src/client/delete-confirmation.tsx', import.meta.url), 'utf8')
  assert.match(view, /setDeleteTarget\(item\)/)
  assert.match(view, /<DeleteConfirmation/)
  assert.match(confirmation, /<Modal/)
  assert.match(confirmation, /variant="outline" className="dsh-st-modal-action"/)
  assert.match(confirmation, /variant="outline" className="dsh-st-modal-action dsh-st-btn-danger"/)
  assert.doesNotMatch(confirmation, /variant="primary"/)
  assert.doesNotMatch(confirmation, /dsh-st-n-danger-button/)
  assert.doesNotMatch(confirmation, /antd/)
  assert.match(confirmation, /card\.confirmDelete/)
  assert.match(confirmation, /card\.confirmDeleteHint/)
  assert.match(confirmation, /card\.confirm/)
})
