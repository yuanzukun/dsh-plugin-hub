import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'
import { en, zh } from '../src/client/locales.ts'

test('设置标题旁提供仓库和反馈 GitHub 链接', async () => {
  const source = await readFile(new URL('../src/client/AutomationView.tsx', import.meta.url), 'utf8')
  const styles = await readFile(new URL('../src/client/styles.ts', import.meta.url), 'utf8')

  assert.match(source, /className="dsh-st-heading-row"/)
  assert.match(source, /https:\/\/github\.com\/MichengAI\/dsh-automation/)
  assert.match(source, /https:\/\/github\.com\/MichengAI\/dsh-automation\/issues/)
  assert.match(source, /FeedbackIcon/)
  assert.match(source, /variant="outline" size="sm"/)
  assert.match(styles, /\.dsh-st-heading-links\{display:flex;align-items:center;gap:8px/)
  assert.match(styles, /\.dsh-st-heading-links>span\[data-mpi-check\]\{display:inline-flex;align-items:center\}/)
  assert.equal(en['header.githubProject'], 'GitHub')
  assert.equal(en['header.githubFeedback'], 'Issues')
  assert.equal(zh['header.githubFeedback'], '问题反馈')
})
