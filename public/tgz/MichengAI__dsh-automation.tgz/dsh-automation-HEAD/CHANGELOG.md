# Changelog

[简体中文](CHANGELOG.zh-CN.md)

Upcoming changes and recent published versions are listed below. Git tags and GitHub Releases now mirror these entries; historical sections retain links to their original release commits.

## 1.0.0 - 2026-10-17

- This line starts at `1.0.0` and requires DeepSeek Harness `0.2.0-rc.1`, `0.2.0-rc.2`, `0.2.1-rc.1`, or `0.2.1-rc.2`. Development dependencies are pinned to `0.2.1-rc.2`, Cordis to `4.0.5`, and Schemastery to `3.18.5`. Hosts still on `0.1.x` should stay on plugin `0.1.66`.
- Completely dropped Ant Design in favor of host native primitives (buttons, switches, inputs, menus, segmented tabs, and dialog modals).
- Switched settings page tabs and sidebar view switcher to official `SegmentedTabs`, featuring pill segments, smooth sliding indicators, and wireframe icons.
- Fully aligned sidebar icons and controls with host design system: folders use `IconFolderClose` and `IconFolderOpen`, chevrons use `IconTriangleRightFill`, unarchive uses `IconUnarchiveOutline`, pulse statuses use official `StateDot`, and overview controls use `IconSlidersTwoOutline` with 28px borderless circular hover styling.
- Added Hide archived (`IconArchiveOffOutline`) to view options filter menu, matching official 3-way radio selection and default state.
- Aligned session ellipsis menus with official slots, supporting Copy Session ID; group rows support Restore all conversations and batch restore dialogs; archived sessions guarantee restore and deletion fallbacks.
- Aligned destructive action buttons with skills manager and archive manager: deletion and group archive confirm buttons use red outlined buttons (`variant="outline"` with `.dsh-st-btn-danger`) instead of filled primary buttons.
- Aligned model select dropdown with official Chat: `deepseek-account` is prioritized at top, localized to DeepSeek 账号 in Chinese, and official Flash models mount the 1017 blue badge.
- Aligned workspace directory picking with IM Assistant: dynamically probes `__DSH_DIRECTORY_PICKER__`, `uiWorkspace`, `dialog`, and `workspaces`, supporting creation directly through `workspaces.create`.
- Successful self-update automatically records the exact version in the profile release-age allowlist to prevent subsequent install rejections.
- Scheduled session opening strictly uses `uiWorkspace.openSession`.
- Dialog confirmations place instructions in host modal descriptions rather than body text.

## 0.1.66 - 2026-10-15

- Support DSH `0.2.1-alpha.3` while retaining all existing supported versions; pin development `@deepseek-ai/dsh*` dependencies to host `0.2.1-alpha.3`, Cordis to `4.0.5-alpha.2`, and Schemastery to `3.18.5-alpha.2`.
- Pin `cordis-plugin-timer` in the Host version matrix so `0.2.1-alpha.2` installs stay on `1.1.7-alpha.1` under npm strict peer resolution.
- No production plugin API breaks for this release (peer / documentation / development dependency / matrix alignment only).

## 0.1.64 - 2026-10-14

- Adjust settings navigation section order to ensure stable placement and avoid conflicts with other plugins.

## 0.1.63 - 2026-10-12

- Fix Web startup on DSH `0.2.1-alpha.2` while retaining compatibility with the previously supported Host versions.
- Preserve the Host’s trusted-address configuration and register scheduled-task requests in the automation plugin’s own scope.
- Restart DSH and refresh the page after upgrading.

## 0.1.62 - 2026-10-12

- Support DSH `0.2.1-alpha.2` while retaining all existing supported versions.

## 0.1.61 - 2026-10-09

- The new-task form can add a workspace. An existing workspace no longer blocks that action. After you choose a folder, the new workspace is selected and the list closes.
- Add workspace matches Instant Messaging: a plus icon, and blue at rest instead of only on hover.
- Workspace, model, reasoning effort, and permission sit in two columns above the prompt. Type / in the prompt to recall a skill. Recalled skills appear as chips, like chat.
- Interval is a short number: every N minutes. Every few days is every N days at a chosen time, with a one-line explanation.
- Fully quit and reopen DSH Desktop after upgrading. A refresh is not enough.

## 0.1.60 - 2026-10-08

- The Tasks / Schedule sidebar keeps its layout when another plugin reloads. Its runtime styles now belong to this plugin (#16).
- Restart DSH and refresh the page after upgrading.

## 0.1.59 - 2026-10-08

- Creating a session from the schedule tab returns the sidebar to Tasks. A scheduled session still stays on Schedule.
- Restart DSH and refresh the page after upgrading.

## 0.1.58 - 2026-10-07

- Official Desktop can update this plugin in place. It no longer targets the web profile by mistake.
- A new version is marked with a warning color. Version numbers keep their normal color.
- After updating, fully quit and reopen DSH Desktop.

## 0.1.55 - 2026-10-07

- Agent automation create/update tools support provider, model, and reasoning effort, including resetting to the runtime global model or model default (#15).
- Reject incomplete provider/model pairs and preserve explicit null on creation. Switching models clears an omitted reasoning override. `automation_list` now includes model IDs, supported reasoning efforts, the global model, and catalog failures.
- Trim model IDs on save. Omitted model fields inherit a complete pair and never splice a session provider with the global model.

## 0.1.54 - 2026-10-06

- The installed-plugin list shows “Automation” and a localized description instead of the package name. Titles and descriptions come from `meta.title` and `meta.description` in `locale/zh.json` and `locale/en.json`.

## 0.1.53 - 2026-09-30

- Supports DeepSeek Harness `0.2.0-rc.2`. `0.2.0-rc.1`, `0.1.7-rc.2`, `0.1.7-rc.1`, `0.1.5-rc.2`, `0.1.5-rc.1`, `0.1.2-rc.1`, `0.1.1-rc.2`, and `0.1.0-rc.8` still work.
- `0.2.0-rc.2` still stores sessions as V4. Those sessions cannot be opened after you downgrade the host. Restart DSH and refresh the page after upgrading.

## 0.1.52 - 2026-09-28

- Supports DeepSeek Harness `0.2.0-rc.1`. `0.1.7-rc.2`, `0.1.7-rc.1`, `0.1.5-rc.2`, `0.1.5-rc.1`, `0.1.2-rc.1`, `0.1.1-rc.2`, and `0.1.0-rc.8` still work.
- `0.2.0-rc.1` still stores sessions as V4. Those sessions cannot be opened after you downgrade the host. Restart DSH and refresh the page after upgrading.

## 0.1.51 - 2026-09-25

- Supports DeepSeek Harness `0.1.7-rc.2`. `0.1.7-rc.1`, `0.1.5-rc.2`, `0.1.5-rc.1`, `0.1.2-rc.1`, `0.1.1-rc.2`, and `0.1.0-rc.8` still work.
- No plugin behavior changes were needed: the host exports and interfaces `0.1.7-rc.2` removed or renamed are ones this plugin does not use.
- `0.1.7` stores sessions as V4. Those sessions cannot be opened after you downgrade the host. Restart DSH and refresh the page after upgrading.

## 0.1.50 - 2026-09-24

- DeepSeek Harness 0.1.7-rc.1 can install this plugin again. The host install gate checks every `@deepseek-ai/dsh-*` peer, including optional ones, so the old `@deepseek-ai/dsh-agent-presets` range rejected 0.1.49.
- That package is no longer a peer. Listing either the old name or `@deepseek-ai/dsh-agent-preset-registry` would fail the other host line. Scheduled tasks still use the host `agentPresets` service. Supported older hosts are unchanged.
- Restart DSH and refresh the page after upgrading.

## 0.1.49 - 2026-09-24

- On older DeepSeek Harness hosts, the Scheduled tab opens again. It no longer fails when the host has no inline session action slot.
- Restart DSH and refresh the page after upgrading.

## 0.1.48 - 2026-09-23

- Supports DeepSeek Harness 0.1.7-rc.1. Versions 0.1.0-rc.8, 0.1.1-rc.2, 0.1.2-rc.1, 0.1.5-rc.1, and 0.1.5-rc.2 still work.
- If your host is still on 0.1.6, upgrade it to 0.1.7-rc.1 before installing this version.
- 0.1.7 stores sessions as V4. Those sessions cannot be opened after you downgrade the host. Restart DSH and refresh the page after upgrading.

## 0.1.47 - 2026-09-23

- Scheduled rows always use the 0.1.7 session list: 5px scrollbar, 10px caption time, 10px action gap, 12px workspace-tree indent, archived caption color, animated title scroll, 800ms hover cards, workspace tree, archived filters, and double-click rename. Older hosts still open menus through the items API those menus actually have. Relative time includes months and years. Pin and manual sort stay unavailable.
- Restart DSH and refresh the page after upgrading.

## 0.1.46 - 2026-09-23

- Works on DeepSeek Harness 0.1.7, and still works on older hosts. The scheduled sidebar stays visible on 0.1.7.
- The scheduled session list now matches the official task sidebar: workspace tree, archived filters, and hover cards for completed, pending, subagent, and archived sessions. Pin is not offered.
- Session menus can delete when archive-manager is installed. Stop-and-archive and undo still use the host actions.
- Settings, create and delete dialogs, sort, and the overview switch share one interface. Escape closes only the current dialog, not the whole settings page.
- Check for updates uses the same dialog as skills. The web client loads a smaller package.

## 0.1.45 - 2026-09-18

- Support DSH `0.1.6-alpha.2` while keeping older hosts. Open scheduled sessions through `uiWorkspace.openSession` when present, and fall back to `sessions.open` on older clients.
- Fix scheduled sessions that could not be opened from the sidebar on alpha.2: probe official `openSession` with `reflect.get('uiWorkspace')` instead of reading `ctx.uiWorkspace` (Cordis throws without inject) or the removed `sessions.open`.
- Resolve the selected session from `retainedBy.mainView` when the session list no longer exposes `current`.
- Align the scheduled session list with official WorkspaceBrowser chrome (indent, hover folder-to-chevron, scrollbar gutter, search and empty states). With archive-manager installed, session menus can delete.
- Forward host rename/archive/delete/fork onto the self-drawn scheduled list when no tab registry is present, so those menus match the hosted tab path.

## 0.1.44 - 2026-09-16

- Keep only turn-boundary events in the live run-summary buffer, dropping request headers and tool results.
- Treat plugin-fiber unload (`INACTIVE_EFFECT`) or an aborted run signal mid-execution as `cancelled`, not `executor_error`.

## 0.1.43 - 2026-09-16

- Add support for DSH `0.1.6-alpha.1`, retaining compatibility with `0.1.0-rc.8`, `0.1.1-rc.2`, `0.1.2-rc.1`, `0.1.5-rc.1`, and `0.1.5-rc.2`.
- On DSH `0.1.6+` hosts, collect run summaries from live `session/event` updates and fall back to the deprecated snapshot when that stream is missing or incomplete. Owned-session detection prefers `deriveMessages` and still reads events on older hosts.
- Open scheduled-task settings from overview cards on the Codex UI settings page, not only the official settings dialog.

## 0.1.42 - 2026-09-14

- Preserve a replacement sidebar tab when an older registration with the same ID is unloaded.

## 0.1.41 - 2026-09-14

- Fix Scheduled and execution-history navigation disappearing when used with the archive and IM plugins.

## 0.1.40 - 2026-09-12

- Configure concurrency per automation to allow overlapping executions of the same task. The default is `1`, preserving existing task behavior. When full, scheduled triggers are skipped and manual starts are rejected; lowering the limit does not cancel existing runs.
- Reduce the minimum interval from 5 minutes to 1 minute.
- Agent create/update tools accept `max_concurrent_runs`, and Web RPC accepts per-task `maxConcurrentRuns`; these are separate from the retired plugin-level global concurrency setting.

## 0.1.39 - 2026-09-12

- Remove the global concurrency cap for different automations, including those in the same directory, so they no longer wait for one of the previous two execution slots.
- The legacy `maxConcurrentRuns` setting no longer takes effect. Duplicate-run protection remains for each automation: an existing queued or running record blocks another manual start, and overlapping scheduled occurrences are still skipped.

## 0.1.38 - 2026-09-11

- Add support for DSH `0.1.5-rc.2`, retaining compatibility with `0.1.0-rc.8`, `0.1.1-rc.2`, `0.1.2-rc.1`, and `0.1.5-rc.1`.

## 0.1.37 - 2026-09-11

- This version was not published to npm; install `0.1.38` or later.
- Add support for DSH `0.1.5-rc.2`, retaining compatibility with `0.1.0-rc.8`, `0.1.1-rc.2`, `0.1.2-rc.1`, and `0.1.5-rc.1`.

## 0.1.36 - 2026-09-10

- Support DSH `0.1.5-rc.1` Agent setup and Web RPC dependency injection while retaining legacy interfaces. Correct manual/scheduled history labels and cover the official patch engine, real Connection, AgentLoop, and permissions.
- Accept both persisted session-list formats; preserve all session links when enumeration is unavailable or malformed, avoiding accidental unlinking of existing cold sessions.
- Pin development dependencies to `0.1.5-rc.1` and restrict official Host peers to `0.1.0-rc.8 || 0.1.1-rc.2 || 0.1.2-rc.1 || 0.1.5-rc.1`. Other versions fall outside the declared range and fail strict peer installation. Add new versions to the standalone `pnpm test:matrix` before expanding support.

## 0.1.35 - 2026-09-09

- Adjust model menu sizing and hint containers, and simplify model rows.

- Unified settings headings, descriptions, and action layouts; maintenance controls no longer squeeze titles or versions. The layout adapts to native DSH settings without Codex UI.

## 0.1.34 - 2026-09-07

- Aligned the release workflow's pnpm version with the package-declared version so tag publishing can start its checks.

## 0.1.33 - 2026-09-07

- Added independent in-product update checks with automatic updates when a verified DSH update service is available and a profile-specific manual fallback otherwise.
- Removed the update-button dependency on `react-dom/client` so the client can load on Hosts that do not register that module id.

## 0.1.32 — 2026-09-06

- Removed the fixed unattended tool allowlist and background-shell ban so tool calls and background process management follow DSH. Retained automatic rejection of approval requests and task timeout cancellation.

## 0.1.31 — 2026-09-05

- Aligned the scheduled-task editor with the Host modal surface, elevation, themed mask, and borderless close icon while preserving its existing dismissal behavior.
- Opened the exact automation settings from task overview cards instead of navigating to the latest run session, removed the trailing session arrow, kept schedule icons visible, and replaced the verbose English next-run label with a compact right-aligned countdown while preserving the full accessible description.
- Rearmed Host session synchronization every five minutes after a missing set exhausts its fast retries, and excluded terminal runs older than 24 hours so slow propagation is not abandoned permanently and stale sessions do not consume retry state.
- Updated local automation status immediately after successful pause or resume mutations even when the following snapshot refresh fails, and reused the shared toggle semantics in Settings.
- Used low-frequency snapshot polling while only the background synchronization bridge is subscribed, accelerating by run state only after UI subscribers mount. Host recovery now marks only started runs as interrupted and lets queued work resume through the scheduler.

## 0.1.30 — 2026-09-04

- Kept standalone Web and Codex UI scheduled-task lists current without requiring a mounted plugin page, and refreshed the Host session index when Automation runs reference sessions that have not appeared there yet.
- Added bounded refresh-cycle backoff for delayed Host session creation, dynamically reading the current Host session store while suppressing repeated refresh warnings.
- Refined the native and Codex UI schedule sidebars with aligned folder and card gutters, more compact task cards, and accessible pause/resume switches in place of status badges.

## 0.1.29 — 2026-09-04

- Refreshed scheduled execution records immediately when the DSH page regains focus or becomes visible, avoiding stale history when Chromium throttles background-tab timers.
- Removed page-resume listeners after the final client subscriber disconnects.

## 0.1.28 — 2026-09-04

- Compared normalized schedules semantically so property order no longer makes an unchanged overdue one-time schedule look edited.
- Formatted scheduled-session and execution-record titles in the task's IANA time zone. Host-local fallback formatting now follows the runtime time zone dynamically.
- Clarified that the unattended tool guard is layered on top of the selected permission preset, and ignored the repository-local pnpm store.

## 0.1.27 — 2026-09-03

- Fixed the scheduled execution-record list staying empty after a run until the sidebar was switched several times. New runs now stay visible even when the Host session index has not caught up yet, the snapshot refreshes immediately when the open session is a scheduled run, and polling speeds up while a run is queued or running.

## 0.1.26 — 2026-09-03

- Added compatibility with DeepSeek Harness `0.1.2-rc.1`, keeping scheduled automations responsive to session events in current Hosts.

## 0.1.25 — 2026-09-03

- Fixed scheduled-task select menus so their backgrounds, borders, shadows, and hover states follow the DSH theme. Time options now remain readable in light mode.

## 0.1.24 — 2026-09-03

- Corrected the DSH peer range to `>=0.1.0-rc.5 <0.2.0`; the development test baseline remains `0.1.2-alpha.5`.

## 0.1.23 — 2026-09-02

- Declared the DSH peer compatibility range as `>=0.1.0-rc.5 <0.2.0` and pinned the development test baseline to `0.1.2-alpha.5`.
- Kept only common client injections so legacy hosts do not need alpha-only UI packages.
- Aligned the Settings GitHub and Issues links with Archive Manager, including icons, dimensions, and localized labels.

## 0.1.22 — 2026-08-28

- Enabled npm Trusted Publishing through the repository's GitHub Actions release workflow.

Published package: [`@michengai/dsh-automation@0.1.22`](https://www.npmjs.com/package/@michengai/dsh-automation/v/0.1.22).

## 0.1.21 — 2026-08-27

- Localized the scheduled-session more-actions accessibility label in both English and Chinese.
- Added regression coverage for opening the scheduled-task settings section, including delayed dialog mounting, cleanup, timeout handling, and cross-plugin request delivery.
- Replaced the native session and workspace hook `any` signatures with shared typed selectors and narrowed unknown Host props at the adapter boundary.
- Made legacy task-name fallback fail closed when multiple tasks share the same name, preventing the wrong task settings from opening.

Published package: [`@michengai/dsh-automation@0.1.21`](https://www.npmjs.com/package/@michengai/dsh-automation/v/0.1.21).

## 0.1.20 — 2026-08-27

- Merged [PR #4](https://github.com/MichengAI/dsh-automation/pull/4) by [@louishzwang](https://github.com/louishzwang), adding a read-only task overview beside execution history and persistent default sorting by created or planned time.
- Refined the native and Codex-style schedule sidebars with compact task cards, matching toolbar rhythm and typography, symmetric card gutters, and an icon-only sorting trigger.
- Added official-style scheduled-session folders that preserve existing session actions, keep stable group ordering, highlight only expanded folders containing the current session, and open the exact task settings directly.
- Added optional whole-group archiving with a confirmation step when Archive Manager is installed, while keeping long lists independently scrollable so the Settings footer remains available.

Published package: [`@michengai/dsh-automation@0.1.20`](https://www.npmjs.com/package/@michengai/dsh-automation/v/0.1.20).

## 0.1.19 — 2026-08-26

- Preserved time-zone and interval-anchor data while editing scheduled tasks, and made overdue recurrence recovery cadence-aware.
- Prevented stale concurrent updates from overwriting run history; safely reconciled deleted or missing scheduled sessions.
- Added a confirmation step before deleting a task, validated workspace ID and path agreement, and exposed interrupted runs in history filters.
- Aligned Agent creation and update with all supported schedule types, including hourly, monthly, and custom plans.

Published package: [`@michengai/dsh-automation@0.1.19`](https://www.npmjs.com/package/@michengai/dsh-automation/v/0.1.19).

## 0.1.18 — 2026-08-26

- Replaced the native task and status filters in run history with the same styled dropdown used for task sorting.
- Added consistent selected states, long-label truncation, scrolling, outside-click dismissal, and Escape handling for those filters.

Published package: [`@michengai/dsh-automation@0.1.18`](https://www.npmjs.com/package/@michengai/dsh-automation/v/0.1.18).

## 0.1.17 — 2026-08-26

- Removed the redundant full-width divider below the scheduled-task tabs while retaining the active-tab underline.
- Matched the sorting control to Qianwen with a filled pill trigger, compact four-option menu, smaller arrow, and neutral selected state.

Published package: [`@michengai/dsh-automation@0.1.17`](https://www.npmjs.com/package/@michengai/dsh-automation/v/0.1.17).

## 0.1.16 — 2026-08-26

- Added an Edit action to each scheduled-task card menu, reusing the existing task editor.
- Added a compact sorting dropdown for created time and planned time in ascending or descending order.
- Kept tasks without a next planned run at the end of the list and preserved created-time descending as the default.

Published package: [`@michengai/dsh-automation@0.1.16`](https://www.npmjs.com/package/@michengai/dsh-automation/v/0.1.16).

## 0.1.15 — 2026-08-26

- Restored localized built-in permission labels in the scheduled-task composer instead of exposing missing `preset.*` translation keys.
- Kept full-access confirmation copy in the Host-owned permission namespace while moving display labels into this plugin's bilingual dictionary.
- Moved the Changelog link from the README footer into the top navigation in both languages.

Published package: [`@michengai/dsh-automation@0.1.15`](https://www.npmjs.com/package/@michengai/dsh-automation/v/0.1.15).

## 0.1.14 — 2026-08-23

- Added bilingual changelogs covering the five most recent releases.
- Linked the release history from both README editions and included it in the npm package.

Published package: [`@michengai/dsh-automation@0.1.14`](https://www.npmjs.com/package/@michengai/dsh-automation/v/0.1.14).
