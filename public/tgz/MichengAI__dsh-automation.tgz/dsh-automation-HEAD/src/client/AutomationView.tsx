import { useEffect, useMemo, useState, useSyncExternalStore } from 'react'
import type { AutomationViewProps, Translate } from './contracts.js'
import {
  AutomationFormError,
  buildCreateInput,
  clockTime,
  formatDuration,
  formatRunTrigger,
  formatSchedule,
  formatWithin,
  formFromAutomation,
  groupHistory,
  HISTORY_STATUS_OPTIONS,
  readSortDefault,
  sortAutomations,
  SETTINGS_SORT_DEFAULT_KEY,
  type AutomationFormState,
  type AutomationSortDirection,
  type AutomationSortKey,
  type HistoryRange,
  type ScheduleKind,
  type SortPreferenceStorage,
} from './helpers.js'
import { automationToggleMutation } from './schedule-rail-model.js'
import { GithubIcon } from './icons.js'
import {
  IconClockOutline,
  IconEditOutline,
  IconEllipsisOutline,
  IconFlatListOutline,
  IconInfoOutline,
  IconNewChatOutline,
  IconPlusOutline,
  IconRefreshOutline,
} from './host-icons.js'
import { Button, Input, Menu, SegmentedTabs, Switch, Tooltip } from '@deepseek-ai/dsh-client-ui-primitives'
import { rowIconStyle } from './plugin-ui.js'
import { MenuSelect } from './menu-select.js'
import { CreateModal } from './create-modal.js'
import { DeleteConfirmation } from './delete-confirmation.js'
import { triggerChatCreation } from './prefill.js'
import { isTransportError } from './runtime.js'
import { SortMenu } from './sort-menu.js'
import type { AutomationRunStatus, AutomationRunViewModel, AutomationViewModel } from './protocol.js'
import {
  AUTOMATION_TASK_SETTINGS_EVENT,
  clearAutomationTaskSettingsRequest,
  parseAutomationTaskSettingsRequest,
  readAutomationTaskSettingsRequest,
  resolveAutomationTaskSettings,
  type AutomationTaskSettingsRequest,
} from './task-settings-request.js'
import {
  AUTOMATION_CREATE_TASK_EVENT,
  clearAutomationCreateTaskRequest,
  readAutomationCreateTaskRequest,
} from './create-task-request.js'

const SORT_STORAGE: SortPreferenceStorage | undefined = typeof window === 'undefined' ? undefined : window.localStorage
const TASK_SETTINGS_STORAGE: Storage | undefined = typeof window === 'undefined' ? undefined : window.sessionStorage
const CREATE_TASK_STORAGE: Storage | undefined = typeof window === 'undefined' ? undefined : window.sessionStorage

type Tab = 'mine' | 'runs'

const EXAMPLES: readonly { readonly name: string; readonly scheduleKind: ScheduleKind; readonly time: string; readonly weekdays: readonly number[] }[] = [
  { name: '每日回归检查', scheduleKind: 'daily', time: '09:00', weekdays: [1, 2, 3, 4, 5] },
  { name: '每周依赖巡检', scheduleKind: 'weekly', time: '10:00', weekdays: [1] },
  { name: '工作日早报', scheduleKind: 'weekly', time: '08:00', weekdays: [1, 2, 3, 4, 5] },
]

export function AutomationView({ t, permissionT, modelT, runtime, closeSettings, addWorkspace }: AutomationViewProps): JSX.Element {
  const state = useSyncExternalStore(runtime.source.subscribe, runtime.source.getSnapshot, runtime.source.getSnapshot)
  const [tab, setTab] = useState<Tab>('mine')
  const [query, setQuery] = useState('')
  const [creating, setCreating] = useState(false)
  const [editingId, setEditingId] = useState<string>()
  const [deleteTarget, setDeleteTarget] = useState<AutomationViewModel>()
  const [draft, setDraft] = useState<Partial<AutomationFormState>>()
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string>()
  const [historyRange, setHistoryRange] = useState<HistoryRange>('day')
  const [historyTask, setHistoryTask] = useState('all')
  const [historyStatus, setHistoryStatus] = useState<'all' | AutomationRunStatus>('all')
  const [sortKey, setSortKey] = useState<AutomationSortKey>(() => readSortDefault(SORT_STORAGE, SETTINGS_SORT_DEFAULT_KEY)?.key ?? 'created')
  const [sortDirection, setSortDirection] = useState<AutomationSortDirection>(() => readSortDefault(SORT_STORAGE, SETTINGS_SORT_DEFAULT_KEY)?.direction ?? 'desc')
  const [taskSettingsRequest, setTaskSettingsRequest] = useState<AutomationTaskSettingsRequest | undefined>(() => readAutomationTaskSettingsRequest(TASK_SETTINGS_STORAGE))
  const [createTaskRequest, setCreateTaskRequest] = useState<boolean>(() => readAutomationCreateTaskRequest(CREATE_TASK_STORAGE))
  const now = useMemo(() => new Date(state.snapshot?.serverNow ?? Date.now()), [state.snapshot?.serverNow, state.refreshedAt])

  const snapshot = state.snapshot
  const workspaces = snapshot?.workspaces ?? []
  const models = snapshot?.models ?? []
  const permissions = snapshot?.permissions ?? []
  const defaultPermission = snapshot?.defaultPermission ?? ''
  const automations = sortAutomations(
    (snapshot?.automations ?? []).filter(item => query.trim() === '' || `${item.name} ${item.prompt}`.toLowerCase().includes(query.trim().toLowerCase())),
    sortKey,
    sortDirection,
  )

  const runs = (snapshot?.runs ?? []).filter((run) => {
    if (historyTask !== 'all' && run.automationId !== historyTask) return false
    if (historyStatus !== 'all' && run.status !== historyStatus) return false
    return true
  })
  const groups = groupHistory(runs, historyRange, now, t)

  const runAction = async (action: () => Promise<void>): Promise<void> => {
    setBusy(true)
    setError(undefined)
    try {
      await action()
    } catch (caught) {
      setError(caught instanceof AutomationFormError
        ? t(caught.key)
        : isTransportError(caught) ? t('error.offline')
          : caught instanceof Error ? caught.message : t('error.action'))
    } finally {
      setBusy(false)
    }
  }

  const closeModal = (): void => {
    setCreating(false)
    setDraft(undefined)
    setEditingId(undefined)
  }

  const openCreate = (partial?: Partial<AutomationFormState>): void => {
    if (defaultPermission === '' || permissions.length === 0) return
    setEditingId(undefined)
    setDraft(partial)
    setCreating(true)
  }

  const openEdit = (item: AutomationViewModel): void => {
    setEditingId(item.id)
    setDraft(formFromAutomation(item, workspaces, snapshot?.defaultModel ?? null, snapshot?.defaultPermission ?? item.permission))
    setCreating(true)
  }

  useEffect(() => {
    if (typeof window === 'undefined') return
    const onTaskSettings = (event: Event): void => {
      const request = parseAutomationTaskSettingsRequest((event as CustomEvent<unknown>).detail)
      if (request !== undefined) setTaskSettingsRequest(request)
    }
    const onCreateTask = (): void => { setCreateTaskRequest(true) }
    window.addEventListener(AUTOMATION_TASK_SETTINGS_EVENT, onTaskSettings)
    window.addEventListener(AUTOMATION_CREATE_TASK_EVENT, onCreateTask)
    return () => {
      window.removeEventListener(AUTOMATION_TASK_SETTINGS_EVENT, onTaskSettings)
      window.removeEventListener(AUTOMATION_CREATE_TASK_EVENT, onCreateTask)
    }
  }, [])

  useEffect(() => {
    if (!createTaskRequest || snapshot === undefined) return
    clearAutomationCreateTaskRequest(CREATE_TASK_STORAGE)
    setCreateTaskRequest(false)
    setTab('mine')
    setQuery('')
    openCreate()
  }, [createTaskRequest, snapshot, t])

  useEffect(() => {
    if (taskSettingsRequest === undefined || snapshot === undefined) return
    const item = resolveAutomationTaskSettings(taskSettingsRequest, snapshot.automations, snapshot.runs)
    clearAutomationTaskSettingsRequest(TASK_SETTINGS_STORAGE)
    setTaskSettingsRequest(undefined)
    setTab('mine')
    setQuery('')
    if (item === undefined) {
      setError(t('error.taskMissing'))
      return
    }
    openEdit(item)
  }, [snapshot, taskSettingsRequest, t])

  return (
    <div className="dsh-st-shell">
      <header className="dsh-st-top">
        <div className="dsh-st-heading">
          <div className="dsh-st-heading-row">
            <h1>{t('tab')}</h1>
            <div className="dsh-st-heading-links">
              <Button variant="outline" size="sm" aria-label={t('header.githubProject')} icon={<GithubIcon />} onClick={() => { window.open('https://github.com/MichengAI/dsh-automation', '_blank', 'noreferrer') }}>{t('header.githubProject')}</Button>
              <Button variant="outline" size="sm" aria-label={t('header.githubFeedback')} icon={<IconEditOutline size={16} />} onClick={() => { window.open('https://github.com/MichengAI/dsh-automation/issues', '_blank', 'noreferrer') }}>{t('header.githubFeedback')}</Button>
            </div>
          </div>
          <p>{t('header.lead')}</p>
        </div>
        <div className="dsh-st-toolbar">
          <Input className="dsh-st-search" value={query} placeholder={t('search.placeholder')} onChange={event => setQuery(event.target.value)} />
          <Button variant="outline" icon={<IconNewChatOutline size={18} />} onClick={() => {
            triggerChatCreation(t('chat.prompt'), closeSettings)
          }}>{t('action.chatCreate')}</Button>
          <Button variant="primary" icon={<IconPlusOutline size={18} />} disabled={defaultPermission === '' || permissions.length === 0} onClick={() => openCreate()}>{t('action.create')}</Button>
          <Button className="dsh-st-row-icon" variant="outline" size="sm" icon={<IconRefreshOutline size={16} />} aria-label={t('section.refresh')} style={rowIconStyle} onClick={() => { void runtime.refresh() }} />
        </div>
      </header>

      <div className="dsh-st-banner" role="note">
        <span><IconInfoOutline size={18} />{t('banner.wake')}</span>
      </div>

      <section className="dsh-st-examples">
        <div className="dsh-st-examples-head">
          <h2>{t('examples.title')}</h2>
        </div>
        <div className="dsh-st-example-row">
          {EXAMPLES.map((example, index) => (
            <button
              key={example.name}
              type="button"
              className="dsh-st-example"
              disabled={defaultPermission === '' || permissions.length === 0}
              onClick={() => openCreate({
                name: t(`examples.${index + 1}.title` as 'examples.1.title'),
                prompt: t(`examples.${index + 1}.body` as 'examples.1.body'),
                scheduleKind: example.scheduleKind,
                time: example.time,
                weekdays: example.weekdays,
              })}
            >
              <strong>{t(`examples.${index + 1}.title` as 'examples.1.title')}</strong>
              <p>{t(`examples.${index + 1}.body` as 'examples.1.body')}</p>
              <span className="dsh-st-chip"><IconClockOutline size={14} />{t(`examples.${index + 1}.chip` as 'examples.1.chip')}</span>
            </button>
          ))}
        </div>
      </section>

      {error !== undefined && <p className="dsh-st-error">{error}</p>}
      {(state.phase === 'idle' || (state.phase === 'loading' && snapshot === undefined)) && <p className="dsh-st-muted">{t('loading')}</p>}
      {state.phase === 'error' && snapshot === undefined && (
        <div className="dsh-st-empty">
          <h3>{t('error.title')}</h3>
          <p>{state.error}</p>
          <Button variant="primary" onClick={() => { void runtime.refresh() }}>{t('error.retry')}</Button>
        </div>
      )}

      <div className="dsh-st-tabs">
        <SegmentedTabs
          className="dsh-st-settings-tabs"
          label={t('tab')}
          value={tab}
          items={[
            {
              value: 'mine' as const,
              id: 'dsh-st-tab-mine',
              panelId: 'dsh-st-panel-mine',
              label: (
                <span className="dsh-st-tab-label">
                  <IconClockOutline size={14} />
                  <span>{t('tabs.mine')}</span>
                </span>
              ),
            },
            {
              value: 'runs' as const,
              id: 'dsh-st-tab-runs',
              panelId: 'dsh-st-panel-runs',
              label: (
                <span className="dsh-st-tab-label">
                  <IconFlatListOutline size={14} />
                  <span>{t('tabs.runs')}</span>
                </span>
              ),
            },
          ]}
          onChange={setTab}
        />
        {tab === 'mine' && (
          <div className="dsh-st-sort-wrap">
            <SortMenu
              t={t}
              {...(SORT_STORAGE === undefined ? {} : { storage: SORT_STORAGE })}
              storageKey={SETTINGS_SORT_DEFAULT_KEY}
              sortKey={sortKey}
              sortDirection={sortDirection}
              onSelect={(key, direction) => {
                setSortKey(key)
                setSortDirection(direction)
              }}
            />
          </div>
        )}
        {tab === 'runs' && (
          <div className="dsh-st-filters">
            <MenuSelect
              compact
              className="dsh-st-filter-range"
              value={historyRange}
              options={(['day', 'week', 'month'] as const).map(range => ({ value: range, label: t(`history.range.${range}`) }))}
              onChange={value => setHistoryRange(value as HistoryRange)}
            />
            <MenuSelect
              compact
              className="dsh-st-filter-task"
              value={historyTask}
              options={[
                { value: 'all', label: t('history.allTasks') },
                ...(snapshot?.automations ?? []).map(item => ({ value: item.id, label: item.name })),
              ]}
              onChange={setHistoryTask}
            />
            <MenuSelect
              compact
              className="dsh-st-filter-status"
              value={historyStatus}
              options={[
                { value: 'all', label: t('history.allStatus') },
                ...HISTORY_STATUS_OPTIONS.map(status => ({ value: status, label: t(`status.${status}`) })),
              ]}
              onChange={value => setHistoryStatus(value as 'all' | AutomationRunStatus)}
            />
          </div>
        )}
      </div>

      {tab === 'mine' && (
        automations.length === 0
          ? <div id="dsh-st-panel-mine" role="tabpanel" aria-labelledby="dsh-st-tab-mine" className="dsh-st-empty"><h3>{t('empty.title')}</h3><p>{t('empty.body')}</p></div>
          : <div id="dsh-st-panel-mine" role="tabpanel" aria-labelledby="dsh-st-tab-mine" className="dsh-st-grid">
              {automations.map(item => (
                <TaskCard
                  key={item.id}
                  item={item}
                  t={t}
                  now={now}
                  busy={busy}
                  onEdit={() => openEdit(item)}
                  onToggle={() => { void runAction(() => runtime.mutateAutomation(item.id, automationToggleMutation(item.status))) }}
                  onRun={() => { void runAction(() => runtime.runNow(item.id)) }}
                  onDelete={() => setDeleteTarget(item)}
                />
              ))}
            </div>
      )}

      {tab === 'runs' && (
        groups.length === 0
          ? <div id="dsh-st-panel-runs" role="tabpanel" aria-labelledby="dsh-st-tab-runs" className="dsh-st-empty">{t('runs.empty')}</div>
          : <div id="dsh-st-panel-runs" role="tabpanel" aria-labelledby="dsh-st-tab-runs" className="dsh-st-timeline">
              {groups.map(group => (
                <section key={group.key} className="dsh-st-group">
                  <h3>{group.label}</h3>
                  {group.items.map(run => <RunRow key={run.id} run={run} t={t} />)}
                </section>
              ))}
            </div>
      )}

      {creating && (
        <CreateModal
          key={editingId ?? 'create'}
          t={t}
          permissionT={permissionT}
          modelT={modelT}
          busy={busy}
          workspaces={workspaces}
          models={models}
          modelFailures={snapshot?.modelFailures ?? []}
          defaultModel={snapshot?.defaultModel ?? null}
          skills={snapshot?.skills ?? []}
          permissions={permissions}
          defaultPermission={defaultPermission}
          editing={editingId !== undefined}
          {...(draft === undefined ? {} : { draft })}
          onClose={closeModal}
          {...(addWorkspace === undefined ? {} : { onAddWorkspace: addWorkspace })}
          onSubmit={async (form) => {
            const input = buildCreateInput(form, workspaces, models, new Date(), {
              allowPastOnce: editingId !== undefined,
            })
            await runAction(async () => {
              if (editingId === undefined) await runtime.createAutomation(input)
              else await runtime.updateAutomation(editingId, input)
              closeModal()
            })
          }}
        />
      )}
      <DeleteConfirmation
        target={deleteTarget}
        t={t}
        busy={busy}
        onCancel={() => setDeleteTarget(undefined)}
        onConfirm={() => {
          const target = deleteTarget
          if (target === undefined) return
          void runAction(async () => {
            await runtime.mutateAutomation(target.id, 'delete')
            setDeleteTarget(undefined)
          })
        }}
      />
    </div>
  )
}

function TaskCard({
  item, t, now, busy, onEdit, onToggle, onRun, onDelete,
}: {
  readonly item: AutomationViewModel
  readonly t: Translate
  readonly now: Date
  readonly busy: boolean
  readonly onEdit: () => void
  readonly onToggle: () => void
  readonly onRun: () => void
  readonly onDelete: () => void
}): JSX.Element {
  const [menuOpen, setMenuOpen] = useState(false)
  return (
    <article className="dsh-st-card" onClick={onEdit}>
      <div className="dsh-st-card-head">
        <span onClick={(event) => event.stopPropagation()}>
          <Switch checked={item.status === 'active'} disabled={busy} label={item.status === 'active' ? t('card.pause') : t('card.resume')} onChange={() => onToggle()} />
        </span>
        <span onClick={(event) => event.stopPropagation()}>
          {/* 原语菜单替代 Antd Dropdown，对齐技能插件 */}
          <Menu
            open={menuOpen}
            onClose={() => setMenuOpen(false)}
            align="end"
            portal
            dense
            anchor={
              <Tooltip label={t('card.more')} side="bottom" delayMs={500} portal>
                <button
                  type="button"
                  className="dsh-st-row-icon"
                  aria-label={t('card.more')}
                  style={{ ...rowIconStyle, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', padding: 0, border: '1px solid var(--dsw-alias-border-l2, rgba(255,255,255,.15))', borderRadius: 'var(--dsw-radius-sm, 6px)', background: 'transparent', color: 'var(--dsw-alias-label-secondary)', cursor: 'pointer' }}
                  onClick={() => setMenuOpen(prev => !prev)}
                >
                  <IconEllipsisOutline size={16} />
                </button>
              </Tooltip>
            }
            items={[
              { id: 'run', label: t('menu.run'), disabled: busy },
              { id: 'edit', label: t('menu.edit'), disabled: busy },
              { id: 'delete', label: t('menu.delete'), danger: true, disabled: busy },
            ]}
            onSelect={(id) => {
              setMenuOpen(false)
              if (id === 'run') onRun()
              if (id === 'edit') onEdit()
              if (id === 'delete') onDelete()
            }}
          />
        </span>
      </div>
      <h3>{item.name}</h3>
      <p>{item.prompt}</p>
      <div className="dsh-st-card-foot">
        <span className="dsh-st-chip"><IconClockOutline size={14} />{formatSchedule(item.schedule, t)}</span>
        <span>{item.nextRunAt === undefined ? t('stats.noneScheduled') : t('history.nextApprox', { when: formatWithin(item.nextRunAt, now, t) })}</span>
      </div>
    </article>
  )
}

function RunRow({ run, t }: { readonly run: AutomationRunViewModel; readonly t: Translate }): JSX.Element {
  const duration = formatDuration(run.startedAt, run.finishedAt)
  return (
    <article className={`dsh-st-run is-${run.status}`}>
      <strong>{run.automationName}</strong>
      <p>
        <span>{clockTime(run.startedAt ?? run.scheduledFor)}</span>
        {duration !== undefined && <span>{duration}</span>}
        <span>{formatRunTrigger(run.trigger, t)}</span>
      </p>
    </article>
  )
}
