import { createElement, useEffect, useMemo, useSyncExternalStore, type ComponentType } from 'react'
import { AutomationView } from './AutomationView.js'
import type { ClientContext, NativeSwitcherProps, SessionSelector, WorkspaceSelector } from './contracts.js'
import { en, NS, zh } from './locales.js'
import {
  attachNativeTabRegistry,
  createNativeTabRegistry,
  findNativeTabRegistry,
  isForeignSidebarHost,
  type NativeTabRegistry,
} from './native-tabs.js'
import { applyPrefillToDom, createPanelCloseSettings, peekChatPrefill, subscribeChatPrefill, takeChatPrefill } from './prefill.js'
import { createAutomationRuntime, installAutomationSessionSync, type AutomationRuntime } from './runtime.js'
import { createHostWorkspace, pickHostDirectory } from './workspace-create.js'
import { NativeScheduleShell, ScheduledRecordsView } from './ScheduleRail.js'
import { ScheduleOverview } from './schedule-overview.js'
import { AUTOMATION_SESSION_PREFIX, canOpenClientSession, collectScheduledSessionIds, ensureOpenScheduledSession, hasCodexUiSidebar, openClientSession, pickWrappableWorkspacesEntry, resolveClientSessionOpenAccess, resolveOfficialTreeComponent, type ClientSessionOpenAccess } from './schedule-rail-model.js'
import { IconClockOutline } from './host-icons.js'
import { hostIconMarkup } from './host-icon-markup.js'
import { installStyles } from './styles.js'
import { openSettingsSection } from './settings-navigation.js'
import { installSettingsNavIcon } from './settings-nav-icon.js'
import { clearAutomationTaskSettingsRequest, requestAutomationTaskSettings, type AutomationTaskSettingsRequest } from './task-settings-request.js'
import { clearAutomationCreateTaskRequest, requestAutomationCreateTask } from './create-task-request.js'
import { observePluginUpdate, PLUGIN_UPDATE_TOGGLE_EVENT, type PluginUpdateIconName } from './plugin-update-ui.js'
import { resolveApiUrl } from './api-base.js'
import { setupSidebarEntry } from './bundle-config.js'

export const name = 'dsh-automation-client'
export const inject = ['slots', 'locale', 'connection', 'sessions']

const UPDATE_ICON_PATHS: Record<PluginUpdateIconName, readonly string[]> = {
  refresh: ['M13.5 5.5V2.5m0 0h-3m3 0-2.1 2.1A5.5 5.5 0 1 0 13.2 12'],
  download: ['M8 2v8m0 0 3-3m-3 3-3-3M3 13v2h10v-2'],
  copy: ['M5 5h8v8H5z', 'M3 3h8'],
  close: ['m4 4 8 8M12 4 4 12'],
}

function createPluginUpdateIcon(name: PluginUpdateIconName): HTMLElement {
  const element = document.createElement('span')
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
  svg.setAttribute('viewBox', '0 0 16 16')
  svg.setAttribute('width', '16')
  svg.setAttribute('height', '16')
  svg.setAttribute('fill', 'none')
  svg.setAttribute('stroke', 'currentColor')
  svg.setAttribute('stroke-width', '1.5')
  svg.setAttribute('stroke-linecap', 'round')
  svg.setAttribute('stroke-linejoin', 'round')
  svg.setAttribute('aria-hidden', 'true')
  for (const d of UPDATE_ICON_PATHS[name]) {
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path')
    path.setAttribute('d', d)
    svg.append(path)
  }
  element.append(svg)
  return element
}

type MutableSlotEntry = {
  component?: ComponentType<any>
  options?: { id?: unknown }
}

function isSessionSelector(value: unknown): value is SessionSelector {
  return typeof value === 'function'
}

function isWorkspaceSelector(value: unknown): value is WorkspaceSelector {
  return typeof value === 'function'
}

type HostComponent = ComponentType<any> & {
  displayName?: string
  __dshNativeTabHost?: boolean
  __dshNativeTabWrapped?: boolean
  __dshNativeTabOriginal?: ComponentType<any>
  __dshNativeTabOwner?: string
  __dshAutomationWrapped?: boolean
  __dshAutomationOriginal?: ComponentType<any>
}

export function apply(ctx: ClientContext): void {
  ctx.effect(() => installStyles(), 'dsh-automation: styles')
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-automation: locale')
  const t = ctx.locale.bind(NS)
  const permissionT = ctx.locale.bind('permission.access')
  const modelT = ctx.locale.bind('model')
  const runtime = createAutomationRuntime(ctx.connection.rpc)
  const addWorkspace = async (): Promise<string | undefined> => {
    const picked = await pickHostDirectory(ctx)
    if (picked === undefined) return undefined
    // 前端通知宿主工作区服务创建并即时刷新侧栏/下拉视图；后端 RPC 确保定时任务调度器持久化登记
    await createHostWorkspace(ctx, picked)
    const registered = await runtime.registerWorkspace(picked)
    return registered.id
  }
  const api = async (path: string, options?: RequestInit): Promise<any> => {
    const targetUrl = resolveApiUrl(`/api/michengai/dsh-automation${path}`)
    const headers = Object.assign({
      'x-michengai-client': '1',
    }, options?.headers)
    const res = await fetch(targetUrl, { ...options, headers })
    const json = await res.json()
    if (!res.ok) throw new Error(json?.error ?? 'request failed')
    return json
  }
  let syncActiveTaskTreeFilter = (): void => undefined
  const sidebarController = setupSidebarEntry(ctx, {
    callApi: api,
    renderPanel: (ownerProps) => createElement(AutomationView, {
      t,
      permissionT: ownerProps.permissionT ?? permissionT,
      modelT: ownerProps.modelT ?? modelT,
      runtime,
      addWorkspace,
      closeSettings: createPanelCloseSettings(ctx, ownerProps),
    }),
    ns: NS,
    injectProps: () => ({
      createWorkspace: (input: { path: string }) => createHostWorkspace(ctx, input.path),
      pickDirectory: () => pickHostDirectory(ctx),
      permissionT,
      modelT,
    }),
    onOnlineUpdateChange: () => {
      if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(PLUGIN_UPDATE_TOGGLE_EVENT))
    },
    onTaskTreeSessionsChange: () => {
      syncActiveTaskTreeFilter()
    },
  })
  ctx.effect(() => () => sidebarController.destroy(), 'dsh-automation: sidebar entry')
  ctx.effect(() => observePluginUpdate({
    endpoint: '/api/michengai/dsh-automation/update',
    packageName: '@michengai/dsh-automation',
    titleRowSelector: '.dsh-st-heading-row',
    linksSelector: '.dsh-st-heading-links',
    zhName: '定时任务',
    enName: 'Scheduled tasks',
    createIcon: createPluginUpdateIcon,
    isEnabled: () => sidebarController.isOnlineUpdateEnabled(),
  }), 'dsh-automation: plugin update ui')
  const openTaskSettings = (request: AutomationTaskSettingsRequest): void => {
    requestAutomationTaskSettings(request)
    openSettingsSection(
      [t('tab'), 'Scheduled tasks', '定时任务'],
      () => { requestAutomationTaskSettings(request) },
      // 与新建一致：设置页没打开就撤掉挂起请求，避免下次手动进入设置时误开旧任务。
      () => { clearAutomationTaskSettingsRequest(window.sessionStorage) },
    )
  }
  const openCreateTask = (): void => {
    requestAutomationCreateTask()
    openSettingsSection(
      [t('tab'), 'Scheduled tasks', '定时任务'],
      () => { requestAutomationCreateTask() },
      // 设置页始终没打开时必须撤掉挂起标记，否则下次手动打开设置会莫名弹出新建框。
      () => { clearAutomationCreateTaskRequest(window.sessionStorage) },
    )
  }
  ctx.effect(() => installAutomationSessionSync(runtime, () => ctx.sessions), 'dsh-automation: session sync')
  ctx.effect(() => installSettingsNavIcon(
    () => [t('tab'), 'Scheduled tasks', '定时任务'],
    () => hostIconMarkup(IconClockOutline, 16),
  ), 'dsh-automation: settings icon')
  // 官方任务树只在会话空闲时渲染 leading 槽位；这里用官方时钟图标标记定时会话。
  ctx.slots.inject('sidebar.session.row.leading', () => ctx.slots.register({
    name: 'sidebar.session.row.leading',
    id: 'dsh-automation-session-clock',
    order: 20,
  }, function AutomationSessionClock(props: { readonly sessionId?: string }) {
    const runs = useSyncExternalStore(
      runtime.source.subscribe,
      () => runtime.source.getSnapshot().snapshot?.runs,
      () => undefined,
    )
    const scheduledIds = useMemo(() => collectScheduledSessionIds(runs), [runs])
    if (props.sessionId === undefined || !scheduledIds.has(props.sessionId)) return null
    return createElement(
      'span',
      { className: 'dsh-st-session-clock', 'aria-hidden': 'true' },
      createElement(IconClockOutline, { size: 16 }),
    )
  }))
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'scheduled-tasks',
    order: 35,
    locale: NS,
    label: () => t('tab'),
    icon: 'schedule',
    inject: () => ({
      createWorkspace: (input: { path: string }) => createHostWorkspace(ctx, input.path),
      pickDirectory: () => pickHostDirectory(ctx),
      permissionT,
      modelT,
    }),
  }, function ScheduledTasksSettings(props: { close?: () => void }) {
    return createElement(AutomationView, {
      t,
      permissionT,
      modelT,
      runtime,
      ...(props.close === undefined ? {} : { closeSettings: props.close }),
      addWorkspace,
    })
  }))
  // Codex UI 通过该插槽判断「定时」TAB 是否可用；注册总览后由宿主负责呈现页签。
  ctx.slots.inject('sidebar.schedule', () => ctx.slots.register({
    name: 'sidebar.schedule',
    id: 'dsh-automation-schedule-overview',
    order: 10,
    locale: NS,
    inject: () => ({ openTaskSettings, openCreateTask }),
  }, function CodexUiScheduleOverview(props: {
    openTaskSettings?: (request: AutomationTaskSettingsRequest) => void
    openCreateTask?: () => void
  }) {
    const state = useSyncExternalStore(runtime.source.subscribe, runtime.source.getSnapshot, runtime.source.getSnapshot)
    return createElement(ScheduleOverview, {
      t,
      automations: state.snapshot?.automations ?? [],
      ...(state.snapshot?.serverNow === undefined ? {} : { serverNow: state.snapshot.serverNow }),
      openTaskSettings: props.openTaskSettings ?? openTaskSettings,
      openCreateTask: props.openCreateTask ?? openCreateTask,
      onToggleAutomation: (automationId, mutation) => runtime.mutateAutomation(automationId, mutation),
    })
  }))
  ctx.slots.inject('sidebar.workspaces', () => {
    let wrappedEntry: MutableSlotEntry | undefined
    let originalComp: ComponentType<any> | undefined
    let ownedWrapper: HostComponent | undefined
    let ownedRegistry: NativeTabRegistry | undefined
    let insertedRegistry: NativeTabRegistry | undefined
    let removeInsertedTab = (): void => undefined
    let removeInsertedOpener = (): void => undefined
    let removeInsertedFilter = (): void => undefined
    let activeFilterRegistry: NativeTabRegistry | undefined
    let filterInstalled = false
    let warnedUnsupportedFilter = false
    let syncing = false
    let retryTimer: number | undefined
    // 直接替换 component 不触发宿主插槽通知；与 IM 共用事件，在本次同步完成后重新协调。
    const notifyPeers = (): void => { queueMicrotask(() => window.dispatchEvent(new Event('dsh-native-sidebar-change'))) }
    const stopRetry = (): void => {
      if (retryTimer !== undefined) {
        window.clearInterval(retryTimer)
        retryTimer = undefined
      }
    }
    const clearFilter = (): void => {
      if (filterInstalled) {
        removeInsertedFilter()
        removeInsertedFilter = (): void => undefined
        filterInstalled = false
      }
      warnedUnsupportedFilter = false
    }
    const ensureFilter = (registry?: NativeTabRegistry): void => {
      if (registry !== activeFilterRegistry) {
        clearFilter()
        activeFilterRegistry = registry
      }
      if (registry === undefined) {
        clearFilter()
        return
      }
      const showSessions = typeof sidebarController !== 'undefined' && typeof sidebarController?.isTaskTreeSessionsEnabled === 'function'
        ? sidebarController.isTaskTreeSessionsEnabled()
        : false
      if (showSessions) {
        clearFilter()
        return
      }
      if (!filterInstalled) {
        if (typeof registry.addSessionFilter === 'function') {
          const dispose = registry.addSessionFilter((sessionId) => {
            if (sessionId.startsWith(AUTOMATION_SESSION_PREFIX)) return false
            const snapshot = runtime?.source?.getSnapshot?.()?.snapshot
            return snapshot?.runs?.some(run => run.sessionId === sessionId) !== true
          })
          removeInsertedFilter = () => {
            dispose()
          }
          filterInstalled = true
        } else if (!warnedUnsupportedFilter) {
          warnedUnsupportedFilter = true
          console.warn('[dsh-automation] 外壳注册表未支持 addSessionFilter 协议，无法在任务树过滤会话')
        }
      }
    }
    syncActiveTaskTreeFilter = () => {
      ensureFilter(insertedRegistry ?? ownedRegistry)
    }
    const unwrap = (): void => {
      stopRetry()
      removeInsertedTab()
      removeInsertedTab = (): void => undefined
      removeInsertedOpener()
      removeInsertedOpener = (): void => undefined
      clearFilter()
      activeFilterRegistry = undefined
      insertedRegistry = undefined
      if (wrappedEntry !== undefined) {
        if (originalComp !== undefined && wrappedEntry.component === ownedWrapper) wrappedEntry.component = originalComp
        const record = wrappedEntry as MutableSlotEntry & { __dshNativeTabs?: unknown }
        if (record.__dshNativeTabs === ownedRegistry) delete record.__dshNativeTabs
        notifyPeers()
      }
      wrappedEntry = undefined
      originalComp = undefined
      ownedWrapper = undefined
      ownedRegistry = undefined
    }
    const installScheduledOpener = (registry: NativeTabRegistry): (() => void) => {
      if (!Array.isArray(registry.sessionOpeners) || typeof registry.addSessionOpener !== 'function') return () => undefined
      if (registry.sessionOpeners.some(item => item.id === 'automation')) return () => undefined
      return registry.addSessionOpener({
        id: 'automation',
        order: 10,
        matchSession: (sessionId) => {
          if (sessionId.startsWith(AUTOMATION_SESSION_PREFIX)) return true
          const snapshot = runtime.source.getSnapshot().snapshot
          return snapshot?.runs?.some(run => run.sessionId === sessionId) === true
        },
        open: (sessionId, hostOpen) => {
          createScheduledSessionOpener(ctx, runtime, hostOpen)(sessionId)
        },
      })
    }
    const insertScheduleTab = (entry: unknown): boolean => {
      const registry = findNativeTabRegistry(entry)
      if (registry === undefined) return false
      if (insertedRegistry !== registry) {
        removeInsertedTab()
        removeInsertedTab = (): void => undefined
        removeInsertedOpener()
        removeInsertedOpener = (): void => undefined
        insertedRegistry = registry
      }
      if (Array.isArray(registry.sessionOpeners) && !registry.sessionOpeners.some(item => item.id === 'automation')) {
        removeInsertedOpener = installScheduledOpener(registry)
      }
      ensureFilter(registry)
      if (registry.getTabs().some(item => item.id === 'schedule')) return true
      removeInsertedTab = registry.insert({
        id: 'schedule',
        label: t('sidebar.tab'),
        order: 30,
        matchSession: (sessionId) => sessionId.startsWith(AUTOMATION_SESSION_PREFIX),
        render: (props) => {
          const hostOpen = typeof props.openSession === 'function'
            ? props.openSession as (id: string) => void
            : typeof props.open === 'function'
              ? props.open as (id: string) => void
              : undefined
          const opener = createScheduledSessionOpener(ctx, runtime, hostOpen)
          const hostTree = typeof registry.officialTree === 'function'
            ? registry.officialTree as ComponentType<Record<string, unknown>>
            : undefined
          // 复用宿主注册表里的官方树；没有官方树时才退回轻量分组列表。
          return createElement(ScheduledRecordsView, {
            t,
            runtime,
            ...(hostTree === undefined ? {} : { officialTree: hostTree }),
            hostProps: props,
            openSession: opener,
            ...(openTaskSettings === undefined ? {} : { openTaskSettings }),
            ...(openCreateTask === undefined ? {} : { openCreateTask }),
            ...(isSessionSelector(props.useSessions) ? { useSessions: props.useSessions } : {}),
            ...(isWorkspaceSelector(props.useWorkspaces) ? { useWorkspaces: props.useWorkspaces } : {}),
            ...(typeof props.wide === 'boolean' ? { wide: props.wide } : {}),
          })
        },
      })
      return true
    }
    const insertIntoKnownHosts = (): boolean => {
      const entries = readSlotEntries(ctx, 'sidebar.workspaces')
      for (const entry of entries) {
        const record = entry as { component?: unknown }
        if (insertScheduleTab(entry) || insertScheduleTab(record.component)) return true
      }
      // 当前显示外壳不再提供旧表时立即释放自有贡献，等待新表就绪通知。
      removeInsertedTab()
      removeInsertedTab = (): void => undefined
      removeInsertedOpener()
      removeInsertedOpener = (): void => undefined
      insertedRegistry = undefined
      return false
    }
    const ensureScheduleTab = (): void => {
      if (insertIntoKnownHosts()) {
        stopRetry()
        return
      }
      if (retryTimer !== undefined) return
      let tries = 0
      retryTimer = window.setInterval(() => {
        tries += 1
        if (insertIntoKnownHosts() || tries >= 20) stopRetry()
      }, 250)
    }
    const sync = (): void => {
      if (syncing) return
      syncing = true
      try {
        if (hasCodexUiSidebar(readSlotEntries(ctx, 'sidebar'))) {
          unwrap()
          return
        }
        const entries = readSlotEntries(ctx, 'sidebar.workspaces')
        const active = entries.find(entry => (entry as MutableSlotEntry)?.component !== undefined) as MutableSlotEntry | undefined
        if (wrappedEntry !== undefined && (active !== wrappedEntry || active.component !== ownedWrapper)) unwrap()
        if (active === wrappedEntry && active?.component === ownedWrapper && ownedWrapper !== undefined) {
          ensureScheduleTab()
          return
        }
        if (active === undefined) { unwrap(); return }
        if (active.component !== ownedWrapper && isForeignSidebarHost(active.component)) {
          ensureScheduleTab()
          return
        }
        const occupant = pickWrappableWorkspacesEntry(entries) as MutableSlotEntry | undefined
        if (occupant?.component === undefined) return
        const resolved = resolveOfficialTreeComponent(occupant.component)
        if (resolved === undefined) return
        originalComp = resolved as ComponentType<any>
        const registry = createNativeTabRegistry(originalComp)
        ownedRegistry = registry
        attachNativeTabRegistry(occupant, registry)
        function DshNativeTabWorkspaceShell(innerProps: NativeSwitcherProps): JSX.Element | null {
          const openSession = createScheduledSessionOpener(ctx, runtime, innerProps.openSession ?? innerProps.open)
          return createElement(NativeScheduleShell, {
            t,
            runtime,
            hostProps: innerProps as Record<string, unknown>,
            openSession,
            openTaskSettings,
            openCreateTask,
            tabRegistry: registry,
            ...(innerProps.wide === undefined ? {} : { wide: innerProps.wide }),
            ...(innerProps.useSessions === undefined ? {} : { useSessions: innerProps.useSessions }),
            ...(innerProps.useWorkspaces === undefined ? {} : { useWorkspaces: innerProps.useWorkspaces }),
            officialTree: tree,
          })
        }
        const marked = DshNativeTabWorkspaceShell as HostComponent
        marked.displayName = 'DshNativeTabWorkspaceShell'
        marked.__dshNativeTabHost = true
        marked.__dshNativeTabWrapped = true
        marked.__dshNativeTabOriginal = originalComp
        marked.__dshNativeTabOwner = 'automation'
        marked.__dshAutomationWrapped = true
        marked.__dshAutomationOriginal = originalComp
        const tree = originalComp
        attachNativeTabRegistry(marked, registry)
        ensureFilter(registry)
        occupant.component = marked
        ownedWrapper = marked
        wrappedEntry = occupant
        ensureScheduleTab()
        notifyPeers()
      } catch (error) {
        console.warn('[dsh-automation] 包裹官方任务树失败', error)
      } finally {
        syncing = false
      }
    }
    sync()
    const unsub = typeof ctx.slots.subscribe === 'function' ? ctx.slots.subscribe('sidebar.workspaces', sync) : () => undefined
    const unsubSidebar = ctx.slots.subscribe?.('sidebar', sync) ?? (() => undefined)
    window.addEventListener('dsh-native-sidebar-change', sync)
    ensureScheduleTab()
    return () => {
      syncActiveTaskTreeFilter = (): void => undefined
      unsub()
      unsubSidebar()
      window.removeEventListener('dsh-native-sidebar-change', sync)
      unwrap()
    }
  })
  ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
    name: 'conversation.input.left',
    id: 'dsh-automation-prefill',
    order: 80,
    locale: NS,
  }, PrefillBridge))
}

function createScheduledSessionOpener(
  ctx: ClientContext,
  runtime: AutomationRuntime,
  hostOpen?: (sessionId: string) => void,
): (sessionId: string) => void {
  // 宿主服务可能晚于本插件挂载，仍需延迟探测；探测成功后缓存，避免每次打开都重新反射。
  let access: ClientSessionOpenAccess | undefined
  return (sessionId) => {
    const resolved = access ??= resolveClientSessionOpenAccess(ctx)
    void ensureOpenScheduledSession({
      id: sessionId,
      adopt: (id) => runtime.adoptSession(id),
      listed: (id) => {
        const snap = ctx.sessions?.list?.getSnapshot()
        return (snap?.ids ?? []).includes(id) || snap?.byId?.[id] !== undefined
      },
      ...(ctx.sessions?.refresh === undefined ? {} : { refresh: () => ctx.sessions!.refresh!() }),
      ...(canOpenClientSession(resolved) ? { openRuntime: (id: string) => { openClientSession(resolved, id) } } : {}),
      ...(hostOpen === undefined ? {} : { openHost: hostOpen }),
    })
  }
}
function PrefillBridge(props: { inputActions?: { setDraft(text: string): void } }): null {
  useEffect(() => {
    const applyPrefill = (text: string | null): void => {
      if (text === null || text === '') return
      if (props.inputActions !== undefined) {
        props.inputActions.setDraft(text)
        takeChatPrefill()
        return
      }
      if (applyPrefillToDom(text)) takeChatPrefill()
    }
    applyPrefill(peekChatPrefill())
    return subscribeChatPrefill(applyPrefill)
  }, [props.inputActions])
  return null
}

function readSlotEntries(ctx: ClientContext, name: string): readonly unknown[] {
  try {
    const read = ctx.slots.entriesOfSlot ?? ctx.slots.entries
    return read?.call(ctx.slots, name) ?? []
  } catch {
    return []
  }
}

export { resolveApiUrl } from './api-base.js'
export { setupSidebarEntry } from './bundle-config.js'

