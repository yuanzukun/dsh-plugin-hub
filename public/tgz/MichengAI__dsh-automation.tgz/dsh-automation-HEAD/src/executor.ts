/** 已认领 run 的独立 Agent 执行边界。 */

import { randomUUID } from 'node:crypto'
import { installModelSelection, type ModelSelection } from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-agent-default-model'
import type { Context } from '@deepseek-ai/cordis'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { SessionId } from '@deepseek-ai/dsh-session'
import { setApprovalPolicy } from '@deepseek-ai/dsh-user-approval'
import { WorkspaceId } from '@deepseek-ai/dsh-workspace'
import { automationSessionTitle } from './run-title.ts'
import type { PermissionPresetService } from './permission-presets.ts'
import { AUTOMATION_SESSION_PREFIX, type AutomationDefinition, type AutomationRun } from './types.ts'

interface TextBlock { readonly type: string; readonly text?: string }
interface SetupAgent { readonly session: unknown }
export interface SessionEventLike {
  readonly seq?: number
  readonly type: string
  readonly data: Record<string, any>
}

interface SessionEventReader {
  snapshotEvents(): readonly SessionEventLike[]
}

export interface SessionOwnershipHintObject extends SessionEventReader {
  deriveMessages?(): readonly { readonly source?: { readonly kind?: unknown } }[]
}

export type SessionOwnershipHint = readonly SessionEventLike[] | SessionOwnershipHintObject

export interface SessionEventWatch {
  readonly events: SessionEventLike[]
  stop(): void
}

const CANCEL_CONVERGENCE_TIMEOUT_MS = 10_000
const SUMMARY_EVENT_TYPES = new Set(['turn/start', 'assistant/message', 'turn/end'])

function isInactiveEffect(error: unknown): boolean {
  return typeof error === 'object' && error !== null && 'code' in error
    && (error as { readonly code?: unknown }).code === 'INACTIVE_EFFECT'
}

function isAbortRequested(signal?: AbortSignal): boolean {
  return signal?.aborted === true
}

/** 对不保证及时响应 AbortSignal 的宿主任务设置第二道退出上限。 */
export async function settlesWithin(promise: Promise<unknown>, timeoutMs: number): Promise<boolean> {
  let timer: ReturnType<typeof setTimeout> | undefined
  try {
    return await Promise.race([
      promise.then(() => true, () => false),
      new Promise<false>((resolve) => { timer = setTimeout(() => resolve(false), timeoutMs) }),
    ])
  } finally {
    if (timer !== undefined) clearTimeout(timer)
  }
}

export interface RunCompletion {
  readonly sessionId?: string
  readonly status: 'succeeded' | 'failed' | 'cancelled'
  readonly summary?: string
  readonly error?: { readonly code: string; readonly message: string }
}

export interface ExecutorConfig {
  readonly runTimeoutMs: number
  readonly sessionId: string
  readonly signal?: AbortSignal
  readonly reusedAgent?: unknown
  readonly resumeSession?: boolean
  readonly cancelConvergenceTimeoutMs?: number
}

/** 先应用官方预设的完整语义，再让无人值守审批 fail-closed。 */
export function applyUnattendedPermission(
  presets: PermissionPresetService,
  session: unknown,
  permission: AutomationDefinition['permissionPreset'],
): void {
  presets.set(session, permission)
  setApprovalPolicy(session, 'never')
}

function isSessionEventList(hint: SessionOwnershipHint): hint is readonly SessionEventLike[] {
  return Array.isArray(hint)
}

function eventsHaveAutomationSource(events: readonly SessionEventLike[]): boolean {
  return events.some((event) => {
    if (event.type !== 'user/message' || typeof event.data !== 'object' || event.data === null) return false
    const source = (event.data as { readonly source?: unknown }).source
    return typeof source === 'object' && source !== null && (source as { readonly kind?: unknown }).kind === 'automation'
  })
}

/** 优先读 deriveMessages；没有投影时再读 snapshotEvents。数组入参只给测试夹具。 */
export function hasAutomationSource(hint: SessionOwnershipHint = []): boolean {
  if (isSessionEventList(hint)) return eventsHaveAutomationSource(hint)
  if (typeof hint.deriveMessages === 'function') {
    return hint.deriveMessages().some((message) => message?.source?.kind === 'automation')
  }
  return eventsHaveAutomationSource(readSessionEvents(hint))
}

/** 已弃用的同步历史读取，只给 session/event 没有增量或不完整时兜底。 */
export function readSessionEvents(session: SessionEventReader): readonly SessionEventLike[] {
  return session.snapshotEvents()
}

/** 订阅当前会话增量，避免为摘要再扫整段历史。 */
export function watchSessionEvents(
  ctx: { on?(name: string, listener: (...args: any[]) => void): () => void },
  session: unknown,
  fromSeq: number,
): SessionEventWatch {
  const events: SessionEventLike[] = []
  const stop = typeof ctx.on === 'function'
    ? ctx.on('session/event', (target: unknown, event: SessionEventLike) => {
        if (target !== session || typeof event?.type !== 'string') return
        if (typeof event.seq === 'number' && event.seq < fromSeq) return
        if (!SUMMARY_EVENT_TYPES.has(event.type)) return
        events.push(event)
      })
    : () => {}
  return { events, stop }
}

/** 一次执行的可读结论：正文加上终止原因。 */
export interface RunSummary {
  readonly text: string
  readonly reason?: Record<string, any>
}

/** 增量能产出正文或结束原因时用增量；否则回退同步快照。 */
export function summarizeCollectedRun(
  live: readonly SessionEventLike[],
  session: SessionEventReader,
  firstSeq: number,
): RunSummary {
  const fromLive = summarizeRun(live, firstSeq)
  if (fromLive.text !== '' || fromLive.reason !== undefined) return fromLive
  return summarizeRun(readSessionEvents(session), firstSeq)
}

export function summarizeRun(events: readonly SessionEventLike[], firstSeq: number): RunSummary {
  let started = false
  let text = ''
  let reason: Record<string, any> | undefined
  for (const event of events) {
    if (typeof event.seq === 'number' && event.seq < firstSeq) continue
    if (event.type === 'turn/start') {
      started = true
      continue
    }
    if (!started) continue
    if (event.type === 'assistant/message') {
      const blocks = (event.data.message?.content ?? []) as readonly TextBlock[]
      const joined = blocks.filter(block => block.type === 'text')
        .map(block => block.text ?? '')
        .join('')
      if (joined !== '') text = joined
    }
    if (event.type === 'turn/end') reason = event.data.reason as Record<string, any>
  }
  return { text, ...(reason === undefined ? {} : { reason }) }
}

function boundSummary(value: string): string | undefined {
  const normalized = value.trim()
  if (normalized === '') return undefined
  return normalized.length <= 2_000 ? normalized : `${normalized.slice(0, 1_999)}…`
}

function reasonError(reason: Record<string, any> | undefined): { readonly code: string; readonly message: string } {
  if (reason === undefined) return { code: 'no_turn_result', message: '本次自动化没有产生完整 turn。' }
  if (reason.kind === 'error') {
    return {
      code: typeof reason.error?.code === 'string' ? reason.error.code : 'agent_error',
      message: typeof reason.error?.message === 'string'
        ? reason.error.message
        : '自动化 Agent 执行失败。',
    }
  }
  return { code: `turn_${String(reason.kind)}`, message: `自动化以 ${String(reason.kind)} 结束。` }
}

export async function executeAutomationRun(
  ctx: Context,
  definition: AutomationDefinition,
  run: AutomationRun,
  config: ExecutorConfig,
): Promise<RunCompletion> {
  if (isAbortRequested(config.signal)) {
    return { status: 'cancelled', error: { code: 'cancelled', message: '自动化在启动前已被取消。' } }
  }
  const target = run.targetSnapshot
  const workspace = ctx.workspaceRegistry.get(WorkspaceId(target.workspaceId))
  if (workspace === undefined) {
    return { status: 'failed', error: { code: 'workspace_not_found', message: '目标工作区已不存在。' } }
  }
  if (await workspace.status() !== 'ok' || workspace.path !== target.cwd) {
    return { status: 'failed', error: { code: 'workspace_unavailable', message: '目标工作区目录不可用或已变更。' } }
  }

  const fallbackSelection = ctx.agentDefaultModel.currentSelection()
  const selection: ModelSelection = target.provider !== null && target.model !== null
    ? {
        provider: target.provider,
        model: target.model,
        ...(target.reasoningEffort ? { reasoningEffort: target.reasoningEffort } : {}),
      }
    : fallbackSelection
  let sessionId = SessionId(config.sessionId)
  const isReuseMode = definition.sessionMode === 'reuse'
  let isReused = config.reusedAgent !== undefined
  let liveAgent: any = config.reusedAgent
  let handle: Awaited<ReturnType<Context['agents']['create']>> | undefined
  let timeout: ReturnType<typeof setTimeout> | undefined
  let removeCancellationListener = () => {}
  let watched: SessionEventWatch | undefined
  const cancelConvergenceTimeoutMs = config.cancelConvergenceTimeoutMs ?? CANCEL_CONVERGENCE_TIMEOUT_MS
  try {
    if (liveAgent === undefined) {
      if (config.resumeSession === true && typeof ctx.agents?.resume === 'function') {
        try {
          handle = await ctx.agents.withoutInitiator(() => ctx.agents.resume({
            resumeSessionId: sessionId,
            ...(config.signal === undefined ? {} : { signal: config.signal }),
            agentOptions: {
              provider: selection.provider,
              model: selection.model,
              ...(selection.reasoningEffort === undefined ? {} : { reasoningEffort: selection.reasoningEffort }),
            },
            setup: async (agentCtx: Context, resumedAgent?: SetupAgent) => {
              if (ctx.agentPresets !== undefined) {
                await ctx.agentPresets.mount(agentCtx, target.agentPreset)
              }
              installModelSelection(agentCtx)
              if (resumedAgent !== undefined) {
                applyUnattendedPermission(ctx.permissionPresets, resumedAgent.session, target.permissionPreset)
              }
            },
          }))
          liveAgent = handle.agent
          isReused = true
        } catch {
          // 持久化会话恢复失败（例如会话损坏或不存在），自愈回退到新建
          sessionId = SessionId(`${AUTOMATION_SESSION_PREFIX}${randomUUID()}`)
          isReused = false
        }
      }
      if (liveAgent === undefined) {
        handle = await ctx.agents.withoutInitiator(() => ctx.agents.create({
          sessionId,
          ...(config.signal === undefined ? {} : { signal: config.signal }),
          meta: { cwd: target.cwd, agentPreset: target.agentPreset },
          // DSH 0.2.2-rc.1 起移除 installModelSelection 的 selection 参数，
          // 初始路由（含 reasoningEffort）完全通过 AgentOptions 传递并在请求头中生效。
          agentOptions: {
            provider: selection.provider,
            model: selection.model,
            ...(selection.reasoningEffort === undefined ? {} : { reasoningEffort: selection.reasoningEffort }),
          },
          setup: async (agentCtx: Context, createdAgent?: SetupAgent) => {
            if (ctx.agentPresets === undefined) throw new Error('Host 未提供 agentPresets 服务。')
            await ctx.agentPresets.mount(agentCtx, target.agentPreset)
            installModelSelection(agentCtx)
            if (createdAgent === undefined) throw new Error('automation setup has no scoped Agent')
            const agent = createdAgent
            applyUnattendedPermission(ctx.permissionPresets, agent.session, target.permissionPreset)
          },
        }))
        liveAgent = handle.agent
      }
    }

    // 跨工作区逃逸与预设不匹配防御：若复用的会话 cwd 或预设与当前任务目标不一致，必须拒绝复用并自愈新建
    if (isReused && liveAgent !== undefined) {
      const sessionCwd =
        liveAgent?.session?.header?.cwd ??
        liveAgent?.session?.meta?.cwd ??
        liveAgent?.meta?.cwd
      const sessionPreset =
        liveAgent?.session?.header?.agentPreset ??
        liveAgent?.session?.meta?.agentPreset ??
        liveAgent?.meta?.agentPreset
      const isCwdMismatched = sessionCwd !== undefined && sessionCwd !== target.cwd
      const isPresetMismatched =
        sessionPreset !== undefined &&
        target.agentPreset !== undefined &&
        sessionPreset !== target.agentPreset

      if (isCwdMismatched || isPresetMismatched) {
        if (handle !== undefined) {
          await handle.dispose().catch(() => {})
          handle = undefined
        }
        sessionId = SessionId(`${AUTOMATION_SESSION_PREFIX}${randomUUID()}`)
        isReused = false
        liveAgent = undefined
        handle = await ctx.agents.withoutInitiator(() => ctx.agents.create({
          sessionId,
          ...(config.signal === undefined ? {} : { signal: config.signal }),
          meta: { cwd: target.cwd, agentPreset: target.agentPreset },
          agentOptions: {
            provider: selection.provider,
            model: selection.model,
            ...(selection.reasoningEffort === undefined ? {} : { reasoningEffort: selection.reasoningEffort }),
          },
          setup: async (agentCtx: Context, createdAgent?: SetupAgent) => {
            if (ctx.agentPresets === undefined) throw new Error('Host 未提供 agentPresets 服务。')
            await ctx.agentPresets.mount(agentCtx, target.agentPreset)
            installModelSelection(agentCtx)
            if (createdAgent === undefined) throw new Error('automation setup has no scoped Agent')
            const agent = createdAgent
            applyUnattendedPermission(ctx.permissionPresets, agent.session, target.permissionPreset)
          },
        }))
        liveAgent = handle.agent
      }
    }

    // 复用会话必须始终重新应用当前任务定义的权限预设、fail-closed 审批策略与模型选择
    if (isReused) {
      if (ctx.permissionPresets !== undefined && liveAgent?.session !== undefined) {
        applyUnattendedPermission(ctx.permissionPresets, liveAgent.session, target.permissionPreset)
      }
      if (typeof liveAgent?.model?.select === 'function') {
        liveAgent.model.select(selection)
      }
    }

    let timedOut = false
    let aborted = false
    const deadline = new Promise<void>((resolve) => {
      timeout = setTimeout(() => {
        timedOut = true
        liveAgent?.cancel({ kind: 'hook', reason: 'automation run timeout' })
        resolve()
      }, config.runTimeoutMs)
    })
    const cancellation = new Promise<void>((resolve) => {
      if (config.signal === undefined) return
      const cancel = () => {
        aborted = true
        liveAgent?.cancel({ kind: 'hook', reason: 'automation service disposed' })
        resolve()
      }
      if (config.signal.aborted) cancel()
      else {
        config.signal.addEventListener('abort', cancel, { once: true })
        removeCancellationListener = () => { config.signal?.removeEventListener('abort', cancel) }
      }
    })

    // 等待初始空闲状态（受到超时与取消监听器保护，防止忙碌会话永久挂起）
    const initialIdle = liveAgent.whenIdle()
    await Promise.race([initialIdle, deadline, cancellation])
    if (timedOut || aborted) {
      removeCancellationListener()
      if (!await settlesWithin(initialIdle, cancelConvergenceTimeoutMs)) {
        return {
          sessionId: String(sessionId),
          status: aborted ? 'cancelled' : 'failed',
          error: {
            code: 'cancel_convergence_timeout',
            message: '自动化取消后未能在安全时限内停止。',
          },
        }
      }
      if (timeout !== undefined) clearTimeout(timeout)
      if (aborted) {
        return {
          sessionId: String(sessionId),
          status: 'cancelled',
          error: { code: 'cancelled', message: '自动化因其所属服务停止而被取消。' },
        }
      }
      return {
        sessionId: String(sessionId),
        status: 'failed',
        error: { code: 'timeout', message: '自动化超过最大运行时限。' },
      }
    }

    await workspace.attachSession(sessionId)
    if (!isReused) {
      pinAutomationSessionTitle(ctx, liveAgent.session, automationSessionTitle(
        definition.name,
        run.startedAt ?? run.scheduledFor,
        definition.timeZone,
      ))
    }
    const firstSeq = liveAgent.session.seq
    watched = watchSessionEvents(ctx, liveAgent.session, firstSeq)
    liveAgent.followup(createUserMessage({
      content: [{ type: 'text', text: run.promptSnapshot }],
      source: {
        kind: 'automation',
        automationId: definition.id,
        runId: run.id,
        scheduledFor: run.scheduledFor,
      },
    }))

    const turnIdle = liveAgent.whenIdle()
    await Promise.race([turnIdle, deadline, cancellation])
    removeCancellationListener()
    if ((timedOut || aborted) && !await settlesWithin(turnIdle, cancelConvergenceTimeoutMs)) {
      return {
        sessionId: String(sessionId),
        status: aborted ? 'cancelled' : 'failed',
        error: {
          code: 'cancel_convergence_timeout',
          message: '自动化取消后未能在安全时限内停止。',
        },
      }
    }
    if (timeout !== undefined) clearTimeout(timeout)
    await ctx.sessions.flush(liveAgent.session)
    const outcome = summarizeCollectedRun(watched.events, liveAgent.session, firstSeq)
    const summary = boundSummary(outcome.text)
    if (aborted) {
      return {
        sessionId: String(sessionId),
        status: 'cancelled',
        ...(summary === undefined ? {} : { summary }),
        error: { code: 'cancelled', message: '自动化因其所属服务停止而被取消。' },
      }
    }
    if (timedOut) {
      return {
        sessionId: String(sessionId),
        status: 'failed',
        ...(summary === undefined ? {} : { summary }),
        error: { code: 'timeout', message: '自动化超过最大运行时限。' },
      }
    }
    if (outcome.reason?.kind === 'completed') {
      return { sessionId: String(sessionId), status: 'succeeded', ...(summary === undefined ? {} : { summary }) }
    }
    return {
      sessionId: String(sessionId),
      status: 'failed',
      ...(summary === undefined ? {} : { summary }),
      error: reasonError(outcome.reason),
    }
  } catch (error: unknown) {
    if (isAbortRequested(config.signal) || isInactiveEffect(error)) {
      return {
        ...(liveAgent === undefined ? {} : { sessionId: String(sessionId) }),
        status: 'cancelled',
        error: { code: 'cancelled', message: '自动化因其所属服务停止而被取消。' },
      }
    }
    return {
      ...(liveAgent === undefined ? {} : { sessionId: String(sessionId) }),
      status: 'failed',
      error: {
        code: 'executor_error',
        message: error instanceof Error ? error.message : '自动化执行器失败。',
      },
    }
  } finally {
    watched?.stop()
    removeCancellationListener()
    if (timeout !== undefined) clearTimeout(timeout)
    if (handle !== undefined && !isReuseMode) {
      await settlesWithin(handle.dispose().catch(() => {}), cancelConvergenceTimeoutMs)
    }
  }
}

export function pinAutomationSessionTitle(ctx: Context, session: unknown, title: string): void {
  // Cordis 未 inject 时直接读 ctx.sessionTitle 会抛错，必须走可选查询。
  const service = ctx.get('sessionTitle') as { rename?(target: unknown, value: string): unknown } | undefined
  if (service === undefined || typeof service.rename !== 'function') return
  try {
    service.rename(session, title)
  } catch (error: unknown) {
    ctx.logger.warn(`dsh-automation: failed to pin session title: ${error instanceof Error ? error.message : String(error)}`)
  }
}
