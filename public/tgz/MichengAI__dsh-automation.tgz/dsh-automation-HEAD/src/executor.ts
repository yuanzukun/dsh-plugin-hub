/** 已认领 run 的独立 Agent 执行边界。 */

import { installModelSelection, type ModelSelection } from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-agent-default-model'
import type {} from '@deepseek-ai/dsh-agent-presets'
import type { Context } from '@deepseek-ai/cordis'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { SessionId } from '@deepseek-ai/dsh-session'
import { setApprovalPolicy } from '@deepseek-ai/dsh-user-approval'
import { WorkspaceId } from '@deepseek-ai/dsh-workspace'
import { automationSessionTitle } from './run-title.ts'
import type { PermissionPresetService } from './permission-presets.ts'
import type { AutomationDefinition, AutomationRun } from './types.ts'

interface TextBlock { readonly type: string; readonly text?: string }
interface SetupAgent { readonly session: unknown }
export interface SessionEventLike {
  readonly seq?: number
  readonly type: string
  readonly data: Record<string, any>
}

interface SessionEventReader {
  snapshotEvents(): readonly SessionEventLike[]
}

export interface SessionOwnershipHintObject extends SessionEventReader {
  deriveMessages?(): readonly { readonly source?: { readonly kind?: unknown } }[]
}

export type SessionOwnershipHint = readonly SessionEventLike[] | SessionOwnershipHintObject

export interface SessionEventWatch {
  readonly events: SessionEventLike[]
  stop(): void
}

const CANCEL_CONVERGENCE_TIMEOUT_MS = 10_000
const SUMMARY_EVENT_TYPES = new Set(['turn/start', 'assistant/message', 'turn/end'])

function isInactiveEffect(error: unknown): boolean {
  return typeof error === 'object' && error !== null && 'code' in error
    && (error as { readonly code?: unknown }).code === 'INACTIVE_EFFECT'
}

function isAbortRequested(signal?: AbortSignal): boolean {
  return signal?.aborted === true
}

/** 对不保证及时响应 AbortSignal 的宿主任务设置第二道退出上限。 */
export async function settlesWithin(promise: Promise<unknown>, timeoutMs: number): Promise<boolean> {
  let timer: ReturnType<typeof setTimeout> | undefined
  try {
    return await Promise.race([
      promise.then(() => true, () => false),
      new Promise<false>((resolve) => { timer = setTimeout(() => resolve(false), timeoutMs) }),
    ])
  } finally {
    if (timer !== undefined) clearTimeout(timer)
  }
}

export interface RunCompletion {
  readonly sessionId?: string
  readonly status: 'succeeded' | 'failed' | 'cancelled'
  readonly summary?: string
  readonly error?: { readonly code: string; readonly message: string }
}

export interface ExecutorConfig {
  readonly runTimeoutMs: number
  readonly sessionId: string
  readonly signal?: AbortSignal
}

/** 先应用官方预设的完整语义，再让无人值守审批 fail-closed。 */
export function applyUnattendedPermission(
  presets: PermissionPresetService,
  session: unknown,
  permission: AutomationDefinition['permissionPreset'],
): void {
  presets.set(session, permission)
  setApprovalPolicy(session, 'never')
}

function isSessionEventList(hint: SessionOwnershipHint): hint is readonly SessionEventLike[] {
  return Array.isArray(hint)
}

function eventsHaveAutomationSource(events: readonly SessionEventLike[]): boolean {
  return events.some((event) => {
    if (event.type !== 'user/message' || typeof event.data !== 'object' || event.data === null) return false
    const source = (event.data as { readonly source?: unknown }).source
    return typeof source === 'object' && source !== null && (source as { readonly kind?: unknown }).kind === 'automation'
  })
}

/** 优先读 deriveMessages；没有投影时再读 snapshotEvents。数组入参只给测试夹具。 */
export function hasAutomationSource(hint: SessionOwnershipHint = []): boolean {
  if (isSessionEventList(hint)) return eventsHaveAutomationSource(hint)
  if (typeof hint.deriveMessages === 'function') {
    return hint.deriveMessages().some((message) => message?.source?.kind === 'automation')
  }
  return eventsHaveAutomationSource(readSessionEvents(hint))
}

/** 已弃用的同步历史读取，只给 session/event 没有增量或不完整时兜底。 */
export function readSessionEvents(session: SessionEventReader): readonly SessionEventLike[] {
  return session.snapshotEvents()
}

/** 订阅当前会话增量，避免为摘要再扫整段历史。 */
export function watchSessionEvents(
  ctx: { on?(name: string, listener: (...args: any[]) => void): () => void },
  session: unknown,
  fromSeq: number,
): SessionEventWatch {
  const events: SessionEventLike[] = []
  const stop = typeof ctx.on === 'function'
    ? ctx.on('session/event', (target: unknown, event: SessionEventLike) => {
        if (target !== session || typeof event?.type !== 'string') return
        if (typeof event.seq === 'number' && event.seq < fromSeq) return
        if (!SUMMARY_EVENT_TYPES.has(event.type)) return
        events.push(event)
      })
    : () => {}
  return { events, stop }
}

/** 一次执行的可读结论：正文加上终止原因。 */
export interface RunSummary {
  readonly text: string
  readonly reason?: Record<string, any>
}

/** 增量能产出正文或结束原因时用增量；否则回退同步快照。 */
export function summarizeCollectedRun(
  live: readonly SessionEventLike[],
  session: SessionEventReader,
  firstSeq: number,
): RunSummary {
  const fromLive = summarizeRun(live, firstSeq)
  if (fromLive.text !== '' || fromLive.reason !== undefined) return fromLive
  return summarizeRun(readSessionEvents(session), firstSeq)
}

export function summarizeRun(events: readonly SessionEventLike[], firstSeq: number): RunSummary {
  let started = false
  let text = ''
  let reason: Record<string, any> | undefined
  for (const event of events) {
    if (typeof event.seq === 'number' && event.seq < firstSeq) continue
    if (event.type === 'turn/start') {
      started = true
      continue
    }
    if (!started) continue
    if (event.type === 'assistant/message') {
      const blocks = (event.data.message?.content ?? []) as readonly TextBlock[]
      const joined = blocks.filter(block => block.type === 'text')
        .map(block => block.text ?? '')
        .join('')
      if (joined !== '') text = joined
    }
    if (event.type === 'turn/end') reason = event.data.reason as Record<string, any>
  }
  return { text, ...(reason === undefined ? {} : { reason }) }
}

function boundSummary(value: string): string | undefined {
  const normalized = value.trim()
  if (normalized === '') return undefined
  return normalized.length <= 2_000 ? normalized : `${normalized.slice(0, 1_999)}…`
}

function reasonError(reason: Record<string, any> | undefined): { readonly code: string; readonly message: string } {
  if (reason === undefined) return { code: 'no_turn_result', message: '本次自动化没有产生完整 turn。' }
  if (reason.kind === 'error') {
    return {
      code: typeof reason.error?.code === 'string' ? reason.error.code : 'agent_error',
      message: typeof reason.error?.message === 'string'
        ? reason.error.message
        : '自动化 Agent 执行失败。',
    }
  }
  return { code: `turn_${String(reason.kind)}`, message: `自动化以 ${String(reason.kind)} 结束。` }
}

export async function executeAutomationRun(
  ctx: Context,
  definition: AutomationDefinition,
  run: AutomationRun,
  config: ExecutorConfig,
): Promise<RunCompletion> {
  if (isAbortRequested(config.signal)) {
    return { status: 'cancelled', error: { code: 'cancelled', message: '自动化在启动前已被取消。' } }
  }
  const target = run.targetSnapshot
  const workspace = ctx.workspaceRegistry.get(WorkspaceId(target.workspaceId))
  if (workspace === undefined) {
    return { status: 'failed', error: { code: 'workspace_not_found', message: '目标工作区已不存在。' } }
  }
  if (await workspace.status() !== 'ok' || workspace.path !== target.cwd) {
    return { status: 'failed', error: { code: 'workspace_unavailable', message: '目标工作区目录不可用或已变更。' } }
  }

  const fallbackSelection = ctx.agentDefaultModel.currentSelection()
  const selection: ModelSelection = target.provider !== null && target.model !== null
    ? {
        provider: target.provider,
        model: target.model,
        ...(target.reasoningEffort ? { reasoningEffort: target.reasoningEffort } : {}),
      }
    : fallbackSelection
  const sessionId = SessionId(config.sessionId)
  let handle: Awaited<ReturnType<Context['agents']['create']>> | undefined
  let timeout: ReturnType<typeof setTimeout> | undefined
  let removeCancellationListener = () => {}
  let watched: SessionEventWatch | undefined
  try {
    handle = await ctx.agents.withoutInitiator(() => ctx.agents.create({
      sessionId,
      ...(config.signal === undefined ? {} : { signal: config.signal }),
      meta: { cwd: target.cwd, agentPreset: target.agentPreset },
      // DSH 0.2.2-rc.1 removed the selection argument from installModelSelection
      // and applies the initial route (including reasoningEffort) from AgentOptions.
      // The effort must travel here to be recorded in the request header.
      agentOptions: {
        provider: selection.provider,
        model: selection.model,
        ...(selection.reasoningEffort === undefined ? {} : { reasoningEffort: selection.reasoningEffort }),
      },
      setup: async (agentCtx: Context, createdAgent?: SetupAgent) => {
        if (ctx.agentPresets === undefined) throw new Error('Host 未提供 agentPresets 服务。')
        await ctx.agentPresets.mount(agentCtx, target.agentPreset)
        // DSH 0.2.0-rc.2 → 0.2.1-rc.5 select the model through the second argument;
        // DSH 0.2.2-rc.1 accepts only agentCtx and ignores it (AgentOptions above wins).
        installModelSelection(agentCtx, { current: selection, assembled: undefined })
        if (createdAgent === undefined) throw new Error('automation setup has no scoped Agent')
        const agent = createdAgent
        applyUnattendedPermission(ctx.permissionPresets, agent.session, target.permissionPreset)
      },
    }))
    await handle.agent.whenIdle()
    await workspace.attachSession(sessionId)
    pinAutomationSessionTitle(ctx, handle.agent.session, automationSessionTitle(
      definition.name,
      run.startedAt ?? run.scheduledFor,
      definition.timeZone,
    ))
    const firstSeq = handle.agent.session.seq
    watched = watchSessionEvents(ctx, handle.agent.session, firstSeq)
    handle.agent.followup(createUserMessage({
      content: [{ type: 'text', text: run.promptSnapshot }],
      source: {
        kind: 'automation',
        automationId: definition.id,
        runId: run.id,
        scheduledFor: run.scheduledFor,
      },
    }))

    let timedOut = false
    let aborted = false
    const idle = handle.agent.whenIdle()
    const deadline = new Promise<void>((resolve) => {
      timeout = setTimeout(() => {
        timedOut = true
        handle?.agent.cancel({ kind: 'hook', reason: 'automation run timeout' })
        resolve()
      }, config.runTimeoutMs)
    })
    const cancellation = new Promise<void>((resolve) => {
      if (config.signal === undefined) return
      const cancel = () => {
        aborted = true
        handle?.agent.cancel({ kind: 'hook', reason: 'automation service disposed' })
        resolve()
      }
      if (config.signal.aborted) cancel()
      else {
        config.signal.addEventListener('abort', cancel, { once: true })
        removeCancellationListener = () => { config.signal?.removeEventListener('abort', cancel) }
      }
    })
    await Promise.race([idle, deadline, cancellation])
    removeCancellationListener()
    if ((timedOut || aborted) && !await settlesWithin(idle, CANCEL_CONVERGENCE_TIMEOUT_MS)) {
      return {
        sessionId: String(sessionId),
        status: aborted ? 'cancelled' : 'failed',
        error: {
          code: 'cancel_convergence_timeout',
          message: '自动化取消后未能在安全时限内停止。',
        },
      }
    }
    if (timeout !== undefined) clearTimeout(timeout)
    await ctx.sessions.flush(handle.agent.session)
    const outcome = summarizeCollectedRun(watched.events, handle.agent.session, firstSeq)
    const summary = boundSummary(outcome.text)
    if (aborted) {
      return {
        sessionId: String(sessionId),
        status: 'cancelled',
        ...(summary === undefined ? {} : { summary }),
        error: { code: 'cancelled', message: '自动化因其所属服务停止而被取消。' },
      }
    }
    if (timedOut) {
      return {
        sessionId: String(sessionId),
        status: 'failed',
        ...(summary === undefined ? {} : { summary }),
        error: { code: 'timeout', message: '自动化超过最大运行时限。' },
      }
    }
    if (outcome.reason?.kind === 'completed') {
      return { sessionId: String(sessionId), status: 'succeeded', ...(summary === undefined ? {} : { summary }) }
    }
    return {
      sessionId: String(sessionId),
      status: 'failed',
      ...(summary === undefined ? {} : { summary }),
      error: reasonError(outcome.reason),
    }
  } catch (error: unknown) {
    if (isAbortRequested(config.signal) || isInactiveEffect(error)) {
      return {
        ...(handle === undefined ? {} : { sessionId: String(sessionId) }),
        status: 'cancelled',
        error: { code: 'cancelled', message: '自动化因其所属服务停止而被取消。' },
      }
    }
    return {
      ...(handle === undefined ? {} : { sessionId: String(sessionId) }),
      status: 'failed',
      error: {
        code: 'executor_error',
        message: error instanceof Error ? error.message : '自动化执行器失败。',
      },
    }
  } finally {
    watched?.stop()
    removeCancellationListener()
    if (timeout !== undefined) clearTimeout(timeout)
    if (handle !== undefined) {
      await settlesWithin(handle.dispose().catch(() => {}), CANCEL_CONVERGENCE_TIMEOUT_MS)
    }
  }
}

export function pinAutomationSessionTitle(ctx: Context, session: unknown, title: string): void {
  // Cordis 未 inject 时直接读 ctx.sessionTitle 会抛错，必须走可选查询。
  const service = ctx.get('sessionTitle') as { rename?(target: unknown, value: string): unknown } | undefined
  if (service === undefined || typeof service.rename !== 'function') return
  try {
    service.rename(session, title)
  } catch (error: unknown) {
    ctx.logger.warn(`dsh-automation: failed to pin session title: ${error instanceof Error ? error.message : String(error)}`)
  }
}
