import type { Context } from '@deepseek-ai/cordis'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, isAbsolute, join, resolve } from 'node:path'

export const SETTINGS_API_HEADER = 'x-michengai-client'
const MAX_SETTINGS_BODY_BYTES = 64 * 1024

export type EntryLocation = 'both' | 'sidebar' | 'settings'

export interface PersistedSettings {
  entryLocation?: EntryLocation | undefined
  sidebarEntry?: boolean | undefined
  hideOfficialSchedule?: boolean | undefined
  taskTreeSessions?: boolean | undefined
}

type UpdateContext = Context & {
  webServer: { register(route: { kind: 'exact'; path: string; handler(request: any, response: any): Promise<void> }): () => void }
  get?(name: string): unknown
}

function resolveProfileDir(ctx: Context): string {
  try {
    const profiles = (ctx as any).get?.('desktopProfiles')
    if (profiles?.current?.dir && typeof profiles.current.dir === 'string' && isAbsolute(profiles.current.dir)) {
      return resolve(profiles.current.dir)
    }
    const launched = (ctx as any).get?.('profileContext')
    if (launched?.dir && typeof launched.dir === 'string' && isAbsolute(launched.dir)) {
      return resolve(launched.dir)
    }
  } catch {}
  const env = process.env
  const home = homedir()
  return resolve(env.DSH_PROFILE_DIR ?? resolve(home, '.dsh', 'profiles', 'web'))
}

function header(request: { headers?: Record<string, string | string[] | undefined> }, name: string): string | undefined {
  const value = request.headers?.[name]
  return Array.isArray(value) ? value[0] : value
}

function validateApiMutation(request: { method?: string; headers?: Record<string, string | string[] | undefined> }): { status: number; error: string } | undefined {
  const method = (request.method ?? 'GET').toUpperCase()
  if (method === 'GET' || method === 'HEAD') return undefined
  const marker = header(request, SETTINGS_API_HEADER)
  if (marker !== '1') return { status: 403, error: 'forbidden mutation request' }
  const contentType = header(request, 'content-type')?.split(';', 1)[0]?.trim().toLowerCase()
  if (contentType !== 'application/json') return { status: 415, error: 'content-type must be application/json' }
  return undefined
}

export class SettingsManager {
  private readonly file: string
  private store: PersistedSettings = {}

  constructor(options: {
    ctx: Context
    stateDir?: string
  }) {
    if (options.stateDir !== undefined && options.stateDir !== '') {
      this.file = isAbsolute(options.stateDir) ? join(options.stateDir, 'settings.json') : resolve(options.stateDir, 'settings.json')
    } else {
      const profileDir = resolveProfileDir(options.ctx)
      this.file = join(profileDir, 'automation-settings.json')
    }
    this.load()
  }

  private load(): void {
    if (!existsSync(this.file)) return
    try {
      const content = readFileSync(this.file, 'utf8')
      const parsed = JSON.parse(content) as unknown
      if (typeof parsed === 'object' && parsed !== null) {
        const item = parsed as Record<string, unknown>
        let entryLocation: EntryLocation | undefined
        if (item.entryLocation === 'both' || item.entryLocation === 'sidebar' || item.entryLocation === 'settings') {
          entryLocation = item.entryLocation
        }
        this.store = {
          entryLocation,
          sidebarEntry: typeof item.sidebarEntry === 'boolean' ? item.sidebarEntry : undefined,
          hideOfficialSchedule: typeof item.hideOfficialSchedule === 'boolean' ? item.hideOfficialSchedule : undefined,
          taskTreeSessions: typeof item.taskTreeSessions === 'boolean' ? item.taskTreeSessions : undefined,
        }
      }
    } catch {
      this.store = {}
    }
  }

  private flush(): void {
    try {
      const dir = dirname(this.file)
      if (!existsSync(dir)) {
        mkdirSync(dir, { recursive: true })
      }
      writeFileSync(this.file, JSON.stringify(this.store, null, 2), 'utf8')
    } catch {
      // 存储写入失败降级为内存保留，不阻断运行
    }
  }

  getEntryLocation(): EntryLocation {
    if (this.store.entryLocation === 'both' || this.store.entryLocation === 'sidebar' || this.store.entryLocation === 'settings') {
      return this.store.entryLocation
    }
    return this.store.sidebarEntry !== false ? 'both' : 'settings'
  }

  async setEntryLocation(location: EntryLocation): Promise<EntryLocation> {
    if (location !== 'both' && location !== 'sidebar' && location !== 'settings') {
      throw new Error('location 必须是 both、sidebar 或 settings')
    }
    this.store.entryLocation = location
    this.store.sidebarEntry = location !== 'settings'
    this.flush()
    return location
  }

  getSidebarEntry(): boolean {
    return this.getEntryLocation() !== 'settings'
  }

  async setSidebarEntry(enabled: boolean): Promise<boolean> {
    if (typeof enabled !== 'boolean') throw new Error('enabled 必须是布尔值')
    await this.setEntryLocation(enabled ? 'both' : 'settings')
    return enabled
  }

  getHideOfficialSchedule(): boolean {
    return this.store.hideOfficialSchedule ?? this.getSidebarEntry()
  }

  async setHideOfficialSchedule(enabled: boolean): Promise<boolean> {
    if (typeof enabled !== 'boolean') throw new Error('enabled 必须是布尔值')
    this.store.hideOfficialSchedule = enabled
    this.flush()
    return enabled
  }

  getTaskTreeSessions(): boolean {
    return this.store.taskTreeSessions === true
  }

  async setTaskTreeSessions(enabled: boolean): Promise<boolean> {
    if (typeof enabled !== 'boolean') throw new Error('enabled 必须是布尔值')
    this.store.taskTreeSessions = enabled
    this.flush()
    return enabled
  }
}

export function registerSettingsApi(ctx: Context, manager: SettingsManager): () => void {
  const host = ctx as UpdateContext
  if (typeof host.webServer?.register !== 'function') return () => {}

  const json = (res: any, status: number, body: unknown) => {
    res.writeHead(status, {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
    })
    res.end(JSON.stringify(body))
  }

  const checkAuthAndMutation = (request: any, response: any): boolean => {
    const connection = (typeof ctx.get === 'function' ? ctx.get('connection') : undefined) as {
      requestRejection?: (request: { headers: any }) => 401 | 403 | undefined
    } | undefined
    if (typeof connection?.requestRejection === 'function') {
      const rejection = connection.requestRejection(request)
      if (rejection !== undefined) {
        json(response, rejection, { ok: false, error: rejection === 401 ? '请先登录 DSH / Sign in to DSH first' : '宿主拒绝此请求 / Request forbidden' })
        return false
      }
    }
    const mutationError = validateApiMutation(request)
    if (mutationError !== undefined) {
      json(response, mutationError.status, { ok: false, error: mutationError.error })
      return false
    }
    return true
  }

  const readBody = (req: any): Promise<{ ok: boolean; status?: number; data?: any; error?: string }> => new Promise((resolveBody) => {
    const chunks: Buffer[] = []
    let received = 0
    let oversized = false

    req.on('data', (chunk: Buffer) => {
      received += chunk.length
      if (received > MAX_SETTINGS_BODY_BYTES) {
        oversized = true
        return
      }
      chunks.push(chunk)
    })

    req.on('end', () => {
      if (oversized) {
        resolveBody({ ok: false, status: 413, error: 'payload too large' })
        return
      }
      try {
        const raw = Buffer.concat(chunks).toString('utf8')
        resolveBody({ ok: true, data: raw ? JSON.parse(raw) : {} })
      } catch {
        resolveBody({ ok: false, status: 400, error: 'invalid json' })
      }
    })

    req.on('error', () => resolveBody({ ok: false, status: 400, error: 'read error' }))
  })

  const offSidebar = host.webServer.register({
    kind: 'exact',
    path: '/api/michengai/dsh-automation/sidebar-entry',
    handler: async (request: any, response: any) => {
      if (!checkAuthAndMutation(request, response)) return
      const method = request.method
      if (method === 'GET' || method === 'HEAD') {
        if (method === 'HEAD') {
          response.writeHead(200, { 'cache-control': 'no-store' })
          response.end()
          return
        }
        const location = manager.getEntryLocation()
        json(response, 200, { ok: true, location, enabled: location !== 'settings' })
        return
      }
      if (method === 'POST') {
        const bodyRes = await readBody(request)
        if (!bodyRes.ok || !bodyRes.data) {
          json(response, bodyRes.status ?? 400, { ok: false, error: bodyRes.error ?? '请求体不能为空' })
          return
        }
        if (typeof bodyRes.data.location === 'string') {
          const loc = bodyRes.data.location
          if (loc !== 'both' && loc !== 'sidebar' && loc !== 'settings') {
            json(response, 400, { ok: false, error: 'location 必须是 both、sidebar 或 settings' })
            return
          }
          const location = await manager.setEntryLocation(loc)
          json(response, 200, { ok: true, location, enabled: location !== 'settings' })
          return
        }
        if (typeof bodyRes.data.enabled === 'boolean') {
          const location = await manager.setEntryLocation(bodyRes.data.enabled ? 'both' : 'settings')
          json(response, 200, { ok: true, location, enabled: location !== 'settings' })
          return
        }
        json(response, 400, { ok: false, error: '缺少合法的 location 或 enabled 参数' })
        return
      }
      response.writeHead(405, { allow: 'GET, HEAD, POST' })
      response.end()
    },
  })

  const offOfficial = host.webServer.register({
    kind: 'exact',
    path: '/api/michengai/dsh-automation/official-schedule',
    handler: async (request: any, response: any) => {
      if (!checkAuthAndMutation(request, response)) return
      const method = request.method
      if (method === 'GET' || method === 'HEAD') {
        if (method === 'HEAD') {
          response.writeHead(200, { 'cache-control': 'no-store' })
          response.end()
          return
        }
        json(response, 200, {
          ok: true,
          enabled: manager.getHideOfficialSchedule(),
        })
        return
      }
      if (method === 'POST') {
        const bodyRes = await readBody(request)
        if (!bodyRes.ok || !bodyRes.data || typeof bodyRes.data.enabled !== 'boolean') {
          json(response, bodyRes.status ?? 400, { ok: false, error: bodyRes.error ?? 'enabled 必须是布尔值' })
          return
        }
        const enabled = await manager.setHideOfficialSchedule(bodyRes.data.enabled)
        json(response, 200, { ok: true, enabled })
        return
      }
      response.writeHead(405, { allow: 'GET, HEAD, POST' })
      response.end()
    },
  })

  const offTaskTreeSessions = host.webServer.register({
    kind: 'exact',
    path: '/api/michengai/dsh-automation/task-tree-sessions',
    handler: async (request: any, response: any) => {
      if (!checkAuthAndMutation(request, response)) return
      const method = request.method
      if (method === 'GET' || method === 'HEAD') {
        if (method === 'HEAD') {
          response.writeHead(200, { 'cache-control': 'no-store' })
          response.end()
          return
        }
        json(response, 200, {
          ok: true,
          enabled: manager.getTaskTreeSessions(),
        })
        return
      }
      if (method === 'POST') {
        const bodyRes = await readBody(request)
        if (!bodyRes.ok || !bodyRes.data || typeof bodyRes.data.enabled !== 'boolean') {
          json(response, bodyRes.status ?? 400, { ok: false, error: bodyRes.error ?? 'enabled 必须是布尔值' })
          return
        }
        const enabled = await manager.setTaskTreeSessions(bodyRes.data.enabled)
        json(response, 200, { ok: true, enabled })
        return
      }
      response.writeHead(405, { allow: 'GET, HEAD, POST' })
      response.end()
    },
  })

  return () => {
    try { offSidebar() } catch {}
    try { offOfficial() } catch {}
    try { offTaskTreeSessions() } catch {}
  }
}
