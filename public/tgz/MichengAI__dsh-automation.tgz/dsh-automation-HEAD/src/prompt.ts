/** 给模型看的定时任务入口说明，避免把「定时任务」理解成操作系统 cron。 */

export const AUTOMATION_PROMPT_NAME = 'tool:automation'
export const AUTOMATION_PROMPT_ORDER = 118

export const AUTOMATION_PROMPT_TEXT = [
  '当用户要创建定时任务、计划任务，或让某件事每天/每周/工作日自动执行时，必须调用 automation_create。',
  '不要建议 crontab、cron、systemd timer、GitHub Actions 或 CI 定时，除非用户明确要求操作系统级 cron。',
  'schedule_create 只用于当前会话里的提醒，不会新开独立编码 Session。写日报、跑代码、做研究等独立工作必须用 automation_create。',
  '自然语言映射：每个工作日/周一到周五 → kind=weekly, weekdays=["MO","TU","WE","TH","FR"]；每天 → kind=daily；早上8点 → time="08:00"。',
  '高级计划映射：每小时第15分钟 → kind=hourly, minute=15；每月31日 → kind=monthly, month_day=31；每3天 → kind=custom, every_days=3。monthly/custom 还必须提供 time。',
  '未指定时区时使用 Asia/Shanghai。prompt 必须写成每次独立运行都能看懂的完整任务说明。',
  'automation_create 和 automation_update 支持 provider、model 和 reasoning_effort。provider/model 使用提供方和模型 ID；推理等级使用该模型公布的 reasoningEfforts 值。将 provider 和 model 都设为 null 可跟随每次运行时的全局模型；reasoning_effort=null 恢复模型默认。更新时省略这些字段保持不变。',
  '指定或修改模型时 provider/model 必须成对传入非空 ID 或成对设为 null。先调用 automation_list 查询 models 和 reasoning.efforts，目录加载失败见 modelFailures。切换模型时未指定 reasoning_effort 会清除旧等级，恢复模型默认。',
].join('\n')

export const AUTOMATION_CREATE_DESCRIPTION = [
  '当用户要创建定时任务、计划任务、每天/每周/工作日自动执行某件事时使用本工具。',
  '不要改用 crontab、systemd 或 CI。',
  '为当前工作区创建一条独立 DSH 自动化；每次触发开启全新 Session，不继承当前对话。',
  '工作日早上 8 点示例：kind=weekly, weekdays=["MO","TU","WE","TH","FR"], time="08:00", time_zone="Asia/Shanghai"。',
  '同时支持 hourly(minute)、monthly(month_day + time) 和 custom(every_days + time)。',
  '可用 provider、model、reasoning_effort 固定模型和推理等级。省略模型继承当前会话或全局选择；provider/model 都设为 null 跟随每次运行时的全局选择；省略或清空 reasoning_effort 使用模型默认。返回保存后的完整定义。',
  '可用 agent_preset 指定 Agent 预设；省略时使用宿主默认预设，宿主未设置默认值时必须显式指定。先调用 automation_list 查看 agentPresets 与 defaultAgentPreset。',
  '必须使用显式 IANA 时区。最短间隔 1 分钟。默认权限来自 Host；不需要写入时应显式选择 read-only，只有需要改文件时才选 workspace-write。',
].join('')

export function shouldUseAutomationCreate(userText: string): boolean {
  const text = userText.trim()
  if (text === '') return false
  const wantsSchedule = /定时任务|计划任务|每小时|每天|每周|每月|每(?:隔)?\d+天|工作日|每周一到周五|cron/.test(text)
  const wantsOsCron = /crontab\s+-e|systemd timer|github actions|操作系统.*cron|系统级.?cron/.test(text)
  return wantsSchedule && !wantsOsCron
}
