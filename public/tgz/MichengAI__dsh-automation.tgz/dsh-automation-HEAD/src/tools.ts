/** 绑定到单个 root Agent 工作区的管理工具。 */

import { defineTool, type JsonValue, type ToolRunContext } from '@deepseek-ai/dsh-tools'
import type { AutomationService } from './service.ts'
import { AUTOMATION_CREATE_DESCRIPTION } from './prompt.ts'
import type { AutomationSchedule, PermissionPreset, UpdateAutomationInput, Weekday } from './types.ts'

interface ToolAgent {
  readonly id: string
  readonly ctx: {
    readonly tools: { register(definition: unknown): () => void }
  }
}

const WEEKDAYS: readonly Weekday[] = ['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU']

interface ScheduleArgs {
  readonly kind?: 'once' | 'interval' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'custom'
  readonly time_zone?: string
  readonly at?: string
  readonly every_minutes?: number
  readonly minute?: number
  readonly time?: string
  readonly weekdays?: string[]
  readonly month_day?: number
  readonly every_days?: number
}

interface ModelArgs {
  readonly provider?: string | null
  readonly model?: string | null
  readonly reasoning_effort?: string | null
}

interface CreateArgs extends ScheduleArgs, ModelArgs {
  readonly name: string
  readonly prompt: string
  readonly kind: 'once' | 'interval' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'custom'
  readonly time_zone: string
  readonly max_concurrent_runs?: number
  readonly permission?: PermissionPreset
}

interface UpdateArgs extends ScheduleArgs, ModelArgs {
  readonly id: string
  readonly name?: string
  readonly prompt?: string
  readonly status?: 'active' | 'paused'
  readonly max_concurrent_runs?: number
  readonly permission?: PermissionPreset
}

interface IdArgs { readonly id: string }

const SCHEDULE_FIELDS = [
  'time_zone', 'at', 'every_minutes', 'minute', 'time', 'weekdays', 'month_day', 'every_days',
] as const

function render(_args: unknown, value: JsonValue): { type: 'text'; text: string }[] {
  return [{ type: 'text', text: JSON.stringify(value) }]
}

const JSON_OUTPUT = {
  schema: { type: 'json' },
  render,
} as const

const MODEL_PARAMETERS = {
  provider: {
    oneOf: [{ type: 'string' }, { type: 'null' }],
    description: '模型提供方 ID，必须与 model 成对指定非空 ID 或成对设为 null。创建时两项都省略继承当前会话或全局选择；更新时两项都省略保持不变。先用 automation_list 查询 models。',
  },
  model: {
    oneOf: [{ type: 'string' }, { type: 'null' }],
    description: '模型 ID，必须与 provider 成对传入。跟随全局时将两项都设为 null。切换模型时省略 reasoning_effort 会清除旧等级，恢复模型默认。',
  },
  reasoning_effort: {
    oneOf: [{ type: 'string' }, { type: 'null' }],
    description: '该模型公布的 reasoningEfforts 值。创建时省略使用模型默认；更新时省略保持不变；null 清除固定等级，恢复模型默认。',
  },
} as const

function modelFromArgs(args: ModelArgs) {
  return {
    ...(args.provider === undefined ? {} : { provider: args.provider }),
    ...(args.model === undefined ? {} : { model: args.model }),
    ...(args.reasoning_effort === undefined ? {} : { reasoningEffort: args.reasoning_effort }),
  }
}

function json(value: unknown): JsonValue {
  return JSON.parse(JSON.stringify(value)) as JsonValue
}

function present(title: string, kind: 'read' | 'other', rawInput?: unknown) {
  return { card: 'generic' as const, title, kind, ...(rawInput === undefined ? {} : { rawInput }) }
}

function validateScheduleSelector(args: ScheduleArgs): void {
  const presentFields = SCHEDULE_FIELDS.filter(field => args[field] !== undefined)
  if (args.kind === undefined) {
    if (presentFields.length > 0) throw new Error('修改计划字段时必须提供 kind')
    return
  }
  const required = args.kind === 'once'
    ? ['time_zone', 'at'] as const
    : args.kind === 'interval'
      ? ['time_zone', 'every_minutes'] as const
      : args.kind === 'hourly'
        ? ['time_zone', 'minute'] as const
        : args.kind === 'weekly'
          ? ['time_zone', 'time', 'weekdays'] as const
          : args.kind === 'monthly'
            ? ['time_zone', 'time', 'month_day'] as const
            : args.kind === 'custom'
              ? ['time_zone', 'time', 'every_days'] as const
              : ['time_zone', 'time'] as const
  const allowed = new Set<string>(required)
  const missing = required.filter(field => args[field] === undefined)
  if (missing.length > 0) throw new Error(`${args.kind} 计划需要 ${missing.join(', ')}`)
  const unrelated = presentFields.filter(field => !allowed.has(field))
  if (unrelated.length > 0) throw new Error(`${args.kind} 计划不接受 ${unrelated.join(', ')}`)
}

function scheduleFromArgs(args: ScheduleArgs, now: string): AutomationSchedule {
  validateScheduleSelector(args)
  const timeZone = String(args.time_zone ?? '')
  switch (args.kind) {
    case 'once':
      return { kind: 'once', at: String(args.at ?? ''), timeZone }
    case 'interval':
      return { kind: 'interval', everyMinutes: Number(args.every_minutes), anchor: now, timeZone }
    case 'hourly':
      return { kind: 'hourly', minute: Number(args.minute), timeZone }
    case 'daily':
      return { kind: 'daily', time: String(args.time ?? ''), timeZone }
    case 'weekly': {
      const weekdays = Array.isArray(args.weekdays) ? args.weekdays.map(String) : []
      if (weekdays.some(day => !WEEKDAYS.includes(day as Weekday))) throw new Error('weekdays 包含无效值')
      return { kind: 'weekly', weekdays: weekdays as Weekday[], time: String(args.time ?? ''), timeZone }
    }
    case 'monthly':
      return { kind: 'monthly', day: Number(args.month_day), time: String(args.time ?? ''), timeZone }
    case 'custom':
      return { kind: 'custom', everyDays: Number(args.every_days), time: String(args.time ?? ''), timeZone }
    default:
      throw new Error('kind 必须是 once、interval、hourly、daily、weekly、monthly 或 custom')
  }
}

export function registerAutomationTools(service: AutomationService, agent: ToolAgent): () => void {
  const scope = { sessionId: agent.id, creatorKind: 'agent' as const }
  const permissionNames = [...service.permissionNames()]
  const disposers: Array<() => void> = []
  const register = (definition: unknown): void => { disposers.push(agent.ctx.tools.register(definition)) }
  try {
    register(defineTool({
      name: 'automation_create',
      description: AUTOMATION_CREATE_DESCRIPTION,
      parameters: {
        name: { type: 'string', required: true },
        prompt: { type: 'string', required: true, description: '每次独立运行都使用的自包含任务说明。' },
        kind: { type: 'string', required: true, enum: ['once', 'interval', 'hourly', 'daily', 'weekly', 'monthly', 'custom'] },
        time_zone: { type: 'string', required: true, description: 'IANA 时区，例如 Asia/Shanghai。' },
        at: { type: 'string', description: '一次性计划的带偏移 ISO 时间。' },
        every_minutes: { type: 'integer', description: '间隔计划的分钟数，最小 1。' },
        minute: { type: 'integer', description: '每小时计划在第几分钟运行，范围 0-59。' },
        time: { type: 'string', description: '每天、每周、每月或自定义计划的本地 HH:mm。' },
        weekdays: { type: 'array', items: { type: 'string', enum: WEEKDAYS } },
        month_day: { type: 'integer', description: '每月计划在第几日运行，范围 1-31。' },
        every_days: { type: 'integer', description: '自定义计划每隔几天运行，范围 1-365。' },
        max_concurrent_runs: { type: 'integer', description: '同一自动化的并发运行上限，必须为正整数，默认 1' },
        permission: { type: 'string', enum: permissionNames },
        ...MODEL_PARAMETERS,
      },
      output: JSON_OUTPUT,
      async execute(args: CreateArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          const value = await service.create(scope, {
            name: args.name,
            prompt: args.prompt,
            schedule: scheduleFromArgs(args, new Date().toISOString()),
            ...(args.max_concurrent_runs === undefined ? {} : { maxConcurrentRuns: args.max_concurrent_runs }),
            ...(args.permission === undefined ? {} : { permissionPreset: args.permission }),
            ...modelFromArgs(args),
          }, exec.signal)
          return json({ ok: true, automation: value })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: (args: CreateArgs) => present('创建自动化', 'other', args.name),
    }))

    register(defineTool({
      name: 'automation_list',
      description: '列出当前工作区的自动化规则、下次运行时间和最近一次结果，以及可选模型目录 models、各模型 reasoning.efforts、全局 defaultModel 和目录加载失败 modelFailures。指定或修复模型前先查询目录，使用其中的 provider/model ID 和推理等级。',
      parameters: {},
      output: JSON_OUTPUT,
      async execute(_args: Record<string, never>, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          const snapshot = await service.snapshot(scope, exec.signal)
          return json({
            ok: true,
            generatedAt: snapshot.generatedAt,
            workspace: snapshot.workspace,
            models: snapshot.models,
            modelFailures: snapshot.modelFailures,
            defaultModel: snapshot.defaultModel,
            automations: snapshot.definitions,
          })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: () => present('列出自动化', 'read'),
    }))

    register(defineTool({
      name: 'automation_update',
      description: '更新当前工作区中一条自动化的名称、任务说明、计划、模型、推理等级、权限或暂停/恢复状态。仅暂停或修改模型不需要其他字段。返回保存后的完整定义；provider 和 model 均为 null 表示跟随运行时全局选择。',
      parameters: {
        id: { type: 'string', required: true },
        name: { type: 'string' },
        prompt: { type: 'string' },
        status: { type: 'string', enum: ['active', 'paused'] },
        kind: { type: 'string', enum: ['once', 'interval', 'hourly', 'daily', 'weekly', 'monthly', 'custom'] },
        time_zone: { type: 'string' },
        at: { type: 'string' },
        every_minutes: { type: 'integer' },
        minute: { type: 'integer' },
        time: { type: 'string' },
        weekdays: { type: 'array', items: { type: 'string', enum: WEEKDAYS } },
        month_day: { type: 'integer' },
        every_days: { type: 'integer' },
        max_concurrent_runs: { type: 'integer', description: '同一自动化的并发运行上限，必须为正整数，默认 1' },
        permission: { type: 'string', enum: permissionNames },
        ...MODEL_PARAMETERS,
      },
      output: JSON_OUTPUT,
      async execute(args: UpdateArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          validateScheduleSelector(args)
          const input: { -readonly [K in keyof Omit<UpdateAutomationInput, 'now'>]: UpdateAutomationInput[K] } = { ...modelFromArgs(args) }
          if (args.name !== undefined) input.name = String(args.name)
          if (args.prompt !== undefined) input.prompt = String(args.prompt)
          if (args.status !== undefined) input.status = args.status
          if (args.max_concurrent_runs !== undefined) input.maxConcurrentRuns = args.max_concurrent_runs
          if (args.permission !== undefined) input.permissionPreset = args.permission
          if (args.kind !== undefined) input.schedule = scheduleFromArgs(args, new Date().toISOString())
          if (Object.keys(input).length === 0) throw new Error('automation_update 至少需要一个变更字段')
          const value = await service.update(scope, args.id, input, exec.signal)
          return json({ ok: true, automation: value })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: (args: UpdateArgs) => present('更新自动化', 'other', args.id),
    }))

    register(defineTool({
      name: 'automation_runs',
      description: '读取当前工作区有界的自动化运行历史，包括失败、跳过、摘要和结果 Session。',
      parameters: {},
      output: JSON_OUTPUT,
      async execute(_args: Record<string, never>, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          const snapshot = await service.snapshot(scope, exec.signal)
          return json({ ok: true, generatedAt: snapshot.generatedAt, runs: snapshot.runs })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: () => present('读取运行历史', 'read'),
    }))

    register(defineTool({
      name: 'automation_run_now',
      description: '立即排队执行一次已有自动化。仍会使用全新 Session 和该规则保存的权限边界。',
      parameters: { id: { type: 'string', required: true } },
      output: JSON_OUTPUT,
      async execute(args: IdArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          return json({ ok: true, run: await service.runNow(scope, args.id, exec.signal) })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: (args: IdArgs) => present('立即运行自动化', 'other', args.id),
    }))

    register(defineTool({
      name: 'automation_delete',
      description: '删除当前工作区的自动化定义，但保留运行历史用于审计。',
      parameters: { id: { type: 'string', required: true } },
      output: JSON_OUTPUT,
      async execute(args: IdArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          return json({ ok: true, value: await service.delete(scope, args.id, exec.signal) })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: (args: IdArgs) => present('删除自动化', 'other', args.id),
    }))
  } catch (error) {
    for (const dispose of disposers.reverse()) dispose()
    throw error
  }
  return () => { for (const dispose of disposers.reverse()) dispose() }
}
