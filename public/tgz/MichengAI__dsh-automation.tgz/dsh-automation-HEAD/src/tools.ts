/** 绑定到单个 root Agent 工作区的管理工具。 */

import { defineTool, type JsonValue, type ToolRunContext } from '@deepseek-ai/dsh-tools'
import type { AutomationDefinitionView, AutomationService } from './service.ts'
import { AUTOMATION_CREATE_DESCRIPTION } from './prompt.ts'
import type { AutomationSchedule, AutomationRun, PermissionPreset, UpdateAutomationInput, Weekday } from './types.ts'

interface ToolAgent {
  readonly id: string
  readonly ctx: {
    readonly tools: { register(definition: unknown): () => void }
  }
}

const WEEKDAYS: readonly Weekday[] = ['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU']

interface ScheduleArgs {
  readonly kind?: 'once' | 'interval' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'custom'
  readonly time_zone?: string
  readonly at?: string
  readonly every_minutes?: number
  readonly minute?: number
  readonly time?: string
  readonly weekdays?: string[]
  readonly month_day?: number
  readonly every_days?: number
}

interface ModelArgs {
  readonly provider?: string | null
  readonly model?: string | null
  readonly reasoning_effort?: string | null
}

interface CreateArgs extends ScheduleArgs, ModelArgs {
  readonly name: string
  readonly prompt: string
  readonly kind: 'once' | 'interval' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'custom'
  readonly time_zone: string
  readonly max_concurrent_runs?: number
  readonly permission?: PermissionPreset
  readonly agent_preset?: string
  readonly workspace?: string
  readonly cross_workspace?: boolean
}

interface UpdateArgs extends ScheduleArgs, ModelArgs {
  readonly id: string
  readonly name?: string
  readonly prompt?: string
  readonly status?: 'active' | 'paused'
  readonly max_concurrent_runs?: number
  readonly permission?: PermissionPreset
  readonly agent_preset?: string
  readonly workspace?: string
  readonly cross_workspace?: boolean
}

interface ListArgs {
  readonly all_workspaces?: boolean
  readonly include_prompt?: boolean
}

interface RunsArgs {
  readonly automation_id?: string
  readonly limit?: number
}

const LAST_RUN_SUMMARY_LIMIT = 240
const RUN_LIST_LIMIT_DEFAULT = 20
const RUN_LIST_LIMIT_MAX = 100

function truncated(text: string | null): string | null {
  return text === null || text.length <= LAST_RUN_SUMMARY_LIMIT
    ? text
    : `${text.slice(0, LAST_RUN_SUMMARY_LIMIT)}…`
}

/** 运行历史的精简视图：状态、时间、摘要与结果 Session；promptSnapshot/targetSnapshot 不回传。 */
function briefRun(run: AutomationRun): JsonValue {
  return {
    id: run.id,
    automationId: run.automationId,
    automationName: run.automationName ?? null,
    status: run.status,
    trigger: run.trigger,
    scheduledFor: run.scheduledFor,
    startedAt: run.startedAt,
    finishedAt: run.finishedAt,
    sessionId: run.sessionId,
    summary: truncated(run.summary),
    error: run.error as unknown as JsonValue,
    unread: run.unread,
  }
}

/**
 * 列表用的精简视图：条目元数据 + 最近一次运行的结论行。
 * prompt 仅在 include_prompt 时返回；运行快照始终省略，避免大段正文占用上下文。
 */
function briefDefinition(view: AutomationDefinitionView, includePrompt: boolean): JsonValue {
  const run = view.lastRun
  const summary = run?.summary ?? null
  return {
    id: view.id,
    name: view.name,
    status: view.status,
    workspaceId: view.workspaceId,
    workspaceTitle: view.workspaceTitle ?? null,
    cwd: view.cwd,
    maxConcurrentRuns: view.maxConcurrentRuns ?? 1,
    kind: view.schedule.kind,
    schedule: view.schedule as unknown as JsonValue,
    timeZone: view.timeZone,
    rrule: view.rrule,
    nextRunAt: view.nextRunAt,
    agentPreset: view.agentPreset,
    provider: view.provider,
    model: view.model,
    reasoningEffort: view.reasoningEffort ?? null,
    permissionPreset: view.permissionPreset,
    revision: view.revision,
    updatedAt: view.updatedAt,
    promptChars: view.prompt.length,
    ...(includePrompt ? { prompt: view.prompt } : {}),
    lastRun:
      run === null
        ? null
        : {
            status: run.status,
            trigger: run.trigger,
            scheduledFor: run.scheduledFor,
            startedAt: run.startedAt,
            finishedAt: run.finishedAt,
            sessionId: run.sessionId,
            summary: truncated(summary),
            error: run.error as unknown as JsonValue,
            unread: run.unread,
          },
  }
}

interface IdArgs {
  readonly id: string
  readonly cross_workspace?: boolean
}

const SCHEDULE_FIELDS = [
  'time_zone', 'at', 'every_minutes', 'minute', 'time', 'weekdays', 'month_day', 'every_days',
] as const

function render(_args: unknown, value: JsonValue): { type: 'text'; text: string }[] {
  return [{ type: 'text', text: JSON.stringify(value) }]
}

const JSON_OUTPUT = {
  schema: { type: 'json' },
  render,
} as const

const MODEL_PARAMETERS = {
  provider: {
    oneOf: [{ type: 'string' }, { type: 'null' }],
    description: '模型提供方 ID，必须与 model 成对指定非空 ID 或成对设为 null。创建时两项都省略继承当前会话或全局选择；更新时两项都省略保持不变。先用 automation_list 查询 models。',
  },
  model: {
    oneOf: [{ type: 'string' }, { type: 'null' }],
    description: '模型 ID，必须与 provider 成对传入。跟随全局时将两项都设为 null。切换模型时省略 reasoning_effort 会清除旧等级，恢复模型默认。',
  },
  reasoning_effort: {
    oneOf: [{ type: 'string' }, { type: 'null' }],
    description: '该模型公布的 reasoningEfforts 值。创建时省略使用模型默认；更新时省略保持不变；null 清除固定等级，恢复模型默认。',
  },
} as const

function modelFromArgs(args: ModelArgs) {
  return {
    ...(args.provider === undefined ? {} : { provider: args.provider }),
    ...(args.model === undefined ? {} : { model: args.model }),
    ...(args.reasoning_effort === undefined ? {} : { reasoningEffort: args.reasoning_effort }),
  }
}

function json(value: unknown): JsonValue {
  return JSON.parse(JSON.stringify(value)) as JsonValue
}

function present(title: string, kind: 'read' | 'other', rawInput?: unknown) {
  return { card: 'generic' as const, title, kind, ...(rawInput === undefined ? {} : { rawInput }) }
}

function validateScheduleSelector(args: ScheduleArgs): void {
  const presentFields = SCHEDULE_FIELDS.filter(field => args[field] !== undefined)
  if (args.kind === undefined) {
    if (presentFields.length > 0) throw new Error('修改计划字段时必须提供 kind')
    return
  }
  const required = args.kind === 'once'
    ? ['time_zone', 'at'] as const
    : args.kind === 'interval'
      ? ['time_zone', 'every_minutes'] as const
      : args.kind === 'hourly'
        ? ['time_zone', 'minute'] as const
        : args.kind === 'weekly'
          ? ['time_zone', 'time', 'weekdays'] as const
          : args.kind === 'monthly'
            ? ['time_zone', 'time', 'month_day'] as const
            : args.kind === 'custom'
              ? ['time_zone', 'time', 'every_days'] as const
              : ['time_zone', 'time'] as const
  const allowed = new Set<string>(required)
  const missing = required.filter(field => args[field] === undefined)
  if (missing.length > 0) throw new Error(`${args.kind} 计划需要 ${missing.join(', ')}`)
  const unrelated = presentFields.filter(field => !allowed.has(field))
  if (unrelated.length > 0) throw new Error(`${args.kind} 计划不接受 ${unrelated.join(', ')}`)
}

function scheduleFromArgs(args: ScheduleArgs, now: string): AutomationSchedule {
  validateScheduleSelector(args)
  const timeZone = String(args.time_zone ?? '')
  switch (args.kind) {
    case 'once':
      return { kind: 'once', at: String(args.at ?? ''), timeZone }
    case 'interval':
      return { kind: 'interval', everyMinutes: Number(args.every_minutes), anchor: now, timeZone }
    case 'hourly':
      return { kind: 'hourly', minute: Number(args.minute), timeZone }
    case 'daily':
      return { kind: 'daily', time: String(args.time ?? ''), timeZone }
    case 'weekly': {
      const weekdays = Array.isArray(args.weekdays) ? args.weekdays.map(String) : []
      if (weekdays.some(day => !WEEKDAYS.includes(day as Weekday))) throw new Error('weekdays 包含无效值')
      return { kind: 'weekly', weekdays: weekdays as Weekday[], time: String(args.time ?? ''), timeZone }
    }
    case 'monthly':
      return { kind: 'monthly', day: Number(args.month_day), time: String(args.time ?? ''), timeZone }
    case 'custom':
      return { kind: 'custom', everyDays: Number(args.every_days), time: String(args.time ?? ''), timeZone }
    default:
      throw new Error('kind 必须是 once、interval、hourly、daily、weekly、monthly 或 custom')
  }
}

export function registerAutomationTools(service: AutomationService, agent: ToolAgent): () => void {
  const scope = { sessionId: agent.id, creatorKind: 'agent' as const }
  const permissionNames = [...service.permissionNames()]
  const disposers: Array<() => void> = []
  const register = (definition: unknown): void => { disposers.push(agent.ctx.tools.register(definition)) }
  try {
    register(defineTool({
      name: 'automation_create',
      description: AUTOMATION_CREATE_DESCRIPTION,
      parameters: {
        name: { type: 'string', required: true },
        prompt: { type: 'string', required: true, description: '每次独立运行都使用的自包含任务说明。' },
        kind: { type: 'string', required: true, enum: ['once', 'interval', 'hourly', 'daily', 'weekly', 'monthly', 'custom'] },
        time_zone: { type: 'string', required: true, description: 'IANA 时区，例如 Asia/Shanghai。' },
        at: { type: 'string', description: '一次性计划的带偏移 ISO 时间。' },
        every_minutes: { type: 'integer', description: '间隔计划的分钟数，最小 1。' },
        minute: { type: 'integer', description: '每小时计划在第几分钟运行，范围 0-59。' },
        time: { type: 'string', description: '每天、每周、每月或自定义计划的本地 HH:mm。' },
        weekdays: { type: 'array', items: { type: 'string', enum: WEEKDAYS } },
        month_day: { type: 'integer', description: '每月计划在第几日运行，范围 1-31。' },
        every_days: { type: 'integer', description: '自定义计划每隔几天运行，范围 1-365。' },
        max_concurrent_runs: { type: 'integer', description: '同一自动化的并发运行上限，必须为正整数，默认 1' },
        permission: { type: 'string', enum: permissionNames },
        agent_preset: { type: 'string', description: '目标 Agent 预设 ID。省略时使用宿主默认预设；宿主未设置默认值时必须显式指定。可先调用 automation_list 查看 agentPresets。' },
        workspace: { type: 'string', description: '可选。目标工作区的名称（如 yyrenting）、ID 或目录路径。省略时默认使用当前会话所在工作区。' },
        cross_workspace: { type: 'boolean', description: '若目标工作区非当前会话所在工作区，必须显式设为 true。' },
        ...MODEL_PARAMETERS,
      },
      output: JSON_OUTPUT,
      async execute(args: CreateArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          const opScope = args.cross_workspace ? { ...scope, crossWorkspace: true } : scope
          const value = await service.create(opScope, {
            name: args.name,
            prompt: args.prompt,
            schedule: scheduleFromArgs(args, new Date().toISOString()),
            ...(args.max_concurrent_runs === undefined ? {} : { maxConcurrentRuns: args.max_concurrent_runs }),
            ...(args.permission === undefined ? {} : { permissionPreset: args.permission }),
            ...(args.agent_preset === undefined ? {} : { agentPreset: args.agent_preset }),
            ...(args.workspace === undefined ? {} : { workspace: args.workspace }),
            ...modelFromArgs(args),
          }, exec.signal)
          return json({ ok: true, automation: value })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: (args: CreateArgs) => present('创建自动化', 'other', args.name),
    }))

    register(defineTool({
      name: 'automation_list',
      description: '列出自动化规则、计划、下次运行时间和最近一次结果的摘要（不再默认回显 prompt 全文，只给 promptChars），并附带模型目录 models、各模型 reasoning.efforts、全局 defaultModel 和目录加载失败 modelFailures。默认列出当前工作区，可通过 all_workspaces: true 列出所有工作区。指定或修复模型前先查询目录，使用其中的 provider/model ID 和推理等级；需要逐字复述某条任务说明时再传 include_prompt: true。',
      parameters: {
        all_workspaces: { type: 'boolean', description: '是否列出所有已注册工作区的自动化任务。默认 false（仅当前工作区）。跨工作区管理时请设为 true。' },
        include_prompt: { type: 'boolean', description: '是否随每条自动化返回 prompt 全文（默认 false，只给 promptChars）。仅在需要逐字核对或复述任务说明时开启。' },
      },
      output: JSON_OUTPUT,
      async execute(args: ListArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          const listScope = args.all_workspaces ? { ...scope, allWorkspaces: true } : scope
          const snapshot = await service.snapshot(listScope, exec.signal)
          return json({
            ok: true,
            generatedAt: snapshot.generatedAt,
            workspace: snapshot.workspace,
            models: snapshot.models,
            modelFailures: snapshot.modelFailures,
            defaultModel: snapshot.defaultModel,
            agentPresets: snapshot.agentPresets,
            defaultAgentPreset: snapshot.defaultAgentPreset,
            automations: snapshot.definitions.map((definition) =>
              briefDefinition(definition, args.include_prompt === true),
            ),
          })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: () => present('列出自动化', 'read'),
    }))

    register(defineTool({
      name: 'automation_update',
      description: '更新一条自动化的名称、任务说明、计划、工作区、模型、推理等级、权限、Agent 预设或暂停/恢复状态。支持通过 workspace 参数迁移工作区（支持工作区名称/ID/路径）。若操作其他工作区的自动化，需显式声明 cross_workspace: true。仅暂停或修改模型不需要其他字段。返回保存后的完整定义；provider 和 model 均为 null 表示跟随运行时全局选择。',
      parameters: {
        id: { type: 'string', required: true },
        name: { type: 'string' },
        prompt: { type: 'string' },
        status: { type: 'string', enum: ['active', 'paused'] },
        workspace: { type: 'string', description: '目标工作区的名称（如 yyrenting）、ID 或目录路径。用于将任务迁移或关联到其他工作区。' },
        cross_workspace: { type: 'boolean', description: '若目标自动化属于其他工作区，必须显式设为 true 以确认跨工作区操作。' },
        kind: { type: 'string', enum: ['once', 'interval', 'hourly', 'daily', 'weekly', 'monthly', 'custom'] },
        time_zone: { type: 'string' },
        at: { type: 'string' },
        every_minutes: { type: 'integer' },
        minute: { type: 'integer' },
        time: { type: 'string' },
        weekdays: { type: 'array', items: { type: 'string', enum: WEEKDAYS } },
        month_day: { type: 'integer' },
        every_days: { type: 'integer' },
        max_concurrent_runs: { type: 'integer', description: '同一自动化的并发运行上限，必须为正整数，默认 1' },
        permission: { type: 'string', enum: permissionNames },
        agent_preset: { type: 'string', description: '目标 Agent 预设 ID。省略时保持原值；可先调用 automation_list 查看 agentPresets。' },
        ...MODEL_PARAMETERS,
      },
      output: JSON_OUTPUT,
      async execute(args: UpdateArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          validateScheduleSelector(args)
          const input: { -readonly [K in keyof Omit<UpdateAutomationInput, 'now'>]: UpdateAutomationInput[K] } & { workspace?: string } = { ...modelFromArgs(args) }
          if (args.name !== undefined) input.name = String(args.name)
          if (args.prompt !== undefined) input.prompt = String(args.prompt)
          if (args.status !== undefined) input.status = args.status
          if (args.workspace !== undefined) input.workspace = String(args.workspace)
          if (args.max_concurrent_runs !== undefined) input.maxConcurrentRuns = args.max_concurrent_runs
          if (args.permission !== undefined) input.permissionPreset = args.permission
          if (args.agent_preset !== undefined) input.agentPreset = args.agent_preset
          if (args.kind !== undefined) input.schedule = scheduleFromArgs(args, new Date().toISOString())
          if (Object.keys(input).length === 0) throw new Error('automation_update 至少需要一个变更字段')
          const opScope = args.cross_workspace ? { ...scope, crossWorkspace: true } : scope
          const value = await service.update(opScope, args.id, input, exec.signal)
          return json({ ok: true, automation: value })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: (args: UpdateArgs) => present('更新自动化', 'other', args.id),
    }))

    register(defineTool({
      name: 'automation_runs',
      description: '读取当前工作区的自动化运行历史（按计划时间倒序，默认最近 20 条、最多 100 条），只回状态、时间、摘要（≤240 字）、错误和结果 Session，不回 promptSnapshot/targetSnapshot。可用 automation_id 只看某条任务；需要更早的记录就加大 limit。',
      parameters: {
        automation_id: { type: 'string', description: '只看该自动化的运行记录（automation id）。省略则返回整个工作区。' },
        limit: { type: 'integer', description: '最多返回多少条，默认 20，上限 100。' },
      },
      output: JSON_OUTPUT,
      async execute(args: RunsArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          const snapshot = await service.snapshot(scope, exec.signal)
          const limit = Math.min(
            RUN_LIST_LIMIT_MAX,
            Math.max(1, Math.trunc(args.limit ?? RUN_LIST_LIMIT_DEFAULT)),
          )
          const filtered =
            args.automation_id === undefined
              ? snapshot.runs
              : snapshot.runs.filter((run) => run.automationId === args.automation_id)
          return json({
            ok: true,
            generatedAt: snapshot.generatedAt,
            total: filtered.length,
            limit,
            truncated: filtered.length > limit,
            runs: filtered.slice(0, limit).map(briefRun),
          })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: () => present('读取运行历史', 'read'),
    }))

    register(defineTool({
      name: 'automation_run_now',
      description: '立即排队执行一次已有自动化（支持当前或任意工作区的自动化）。若操作其他工作区的自动化，需显式声明 cross_workspace: true。仍会使用全新 Session 和该规则保存的工作区与权限边界。',
      parameters: {
        id: { type: 'string', required: true },
        cross_workspace: { type: 'boolean', description: '若目标自动化属于其他工作区，必须显式设为 true 以确认跨工作区操作。' },
      },
      output: JSON_OUTPUT,
      async execute(args: IdArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          const opScope = args.cross_workspace ? { ...scope, crossWorkspace: true } : scope
          return json({ ok: true, run: await service.runNow(opScope, args.id, exec.signal) })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: (args: IdArgs) => present('立即运行自动化', 'other', args.id),
    }))

    register(defineTool({
      name: 'automation_delete',
      description: '删除指定的自动化定义，但保留运行历史用于审计。若操作其他工作区的自动化，需显式声明 cross_workspace: true。',
      parameters: {
        id: { type: 'string', required: true },
        cross_workspace: { type: 'boolean', description: '若目标自动化属于其他工作区，必须显式设为 true 以确认跨工作区操作。' },
      },
      output: JSON_OUTPUT,
      async execute(args: IdArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          const opScope = args.cross_workspace ? { ...scope, crossWorkspace: true } : scope
          return json({ ok: true, value: await service.delete(opScope, args.id, exec.signal) })
        } catch (error: unknown) {
          if (exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
          return json({ ok: false, code: 'automation_error', message: error instanceof Error ? error.message : String(error) })
        }
      },
      presentCall: (args: IdArgs) => present('删除自动化', 'other', args.id),
    }))
  } catch (error) {
    for (const dispose of disposers.reverse()) dispose()
    throw error
  }
  return () => { for (const dispose of disposers.reverse()) dispose() }
}
