import type { Context } from '@deepseek-ai/cordis';
export declare const SETTINGS_API_HEADER = "x-michengai-client";
export type EntryLocation = 'both' | 'sidebar' | 'settings';
export interface PersistedSettings {
    entryLocation?: EntryLocation | undefined;
    sidebarEntry?: boolean | undefined;
    hideOfficialSchedule?: boolean | undefined;
    taskTreeSessions?: boolean | undefined;
}
export declare class SettingsManager {
    private readonly file;
    private store;
    constructor(options: {
        ctx: Context;
        stateDir?: string;
    });
    private load;
    private flush;
    getEntryLocation(): EntryLocation;
    setEntryLocation(location: EntryLocation): Promise<EntryLocation>;
    getSidebarEntry(): boolean;
    setSidebarEntry(enabled: boolean): Promise<boolean>;
    getHideOfficialSchedule(): boolean;
    setHideOfficialSchedule(enabled: boolean): Promise<boolean>;
    getTaskTreeSessions(): boolean;
    setTaskTreeSessions(enabled: boolean): Promise<boolean>;
}
export declare function registerSettingsApi(ctx: Context, manager: SettingsManager): () => void;
