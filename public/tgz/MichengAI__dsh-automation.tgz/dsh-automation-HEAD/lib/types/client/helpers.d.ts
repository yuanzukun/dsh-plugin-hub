import type { Translate } from './contracts.js';
import type { AutomationSchedule, AutomationRunViewModel, AutomationViewModel, CreateAutomationInput, ModelOption, WorkspaceOption } from './protocol.js';
export type ScheduleKind = 'once' | 'interval' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'custom';
/** 使用宿主实际产生的触发类型和统一文案，避免把手动运行显示为定时。 */
export declare function formatRunTrigger(trigger: AutomationRunViewModel['trigger'], t: Translate): string;
export interface AutomationFormState {
    readonly name: string;
    readonly prompt: string;
    readonly scheduleKind: ScheduleKind;
    readonly onceAt: string;
    readonly maxConcurrentRuns: string;
    readonly everyMinutes: string;
    readonly intervalAnchor: string;
    readonly time: string;
    readonly weekdays: readonly number[];
    readonly hourlyMinute: string;
    readonly monthDay: string;
    readonly customDays: string;
    readonly timeZone: string;
    readonly permission: CreateAutomationInput['permission'];
    readonly agentPreset: string;
    readonly workspaceId: string;
    readonly modelKey: string;
    readonly reasoningEffort: string;
    readonly skills: readonly string[];
}
export type FormErrorKey = 'form.error.maxConcurrentRuns' | 'form.error.name' | 'form.error.prompt' | 'form.error.once' | 'form.error.interval' | 'form.error.weekdays' | 'form.error.workspace';
export declare class AutomationFormError extends Error {
    readonly key: FormErrorKey;
    constructor(key: FormErrorKey);
}
/** Chat 点选技能后写入输入框的 `/name` 文本。优先用合法技能名，否则回退到目录 id。 */
export declare function skillGestureToken(skill: {
    readonly id: string;
    readonly name: string;
}): string;
/** 在光标处插入技能手势；已存在相同 token 时不重复插入。 */
export declare function insertSkillGesture(prompt: string, token: string, caret: number): {
    readonly text: string;
    readonly caret: number;
};
/** 光标前正在输入的 `/query`。词中间的斜杠（如网址）不召回。 */
export declare function activeSlashQuery(text: string, caret: number): {
    readonly start: number;
    readonly query: string;
} | undefined;
/** 按技能名或 id 过滤；空查询返回全部。 */
export declare function filterSlashSkills<T extends {
    readonly id: string;
    readonly name: string;
}>(skills: readonly T[], query: string): T[];
/** 用选中的技能 token 替换光标处正在输入的 `/query`。 */
export declare function applySlashSkill(text: string, caret: number, token: string): {
    readonly text: string;
    readonly caret: number;
};
/** 把正文拆成普通文字和已登记技能标签。未登记的 `/token` 保持纯文本。 */
export declare function splitSkillTokens(text: string, skills: readonly {
    readonly id: string;
    readonly name: string;
}[]): Array<{
    readonly kind: 'text' | 'skill';
    readonly text: string;
}>;
export declare function localDateTimeValue(date?: Date): string;
export declare function defaultFormState(now?: Date, workspaces?: readonly WorkspaceOption[], defaultModel?: ModelOption | null, defaultPermission?: string, defaultAgentPreset?: string): AutomationFormState;
export declare function buildCreateInput(form: AutomationFormState, workspaces: readonly WorkspaceOption[], models: readonly ModelOption[], now?: Date, options?: {
    readonly allowPastOnce?: boolean;
}): CreateAutomationInput;
export declare function formatRelativeTime(iso: string, now: Date, t: Translate): string;
export declare function formatSchedule(schedule: AutomationSchedule, t: Translate): string;
export declare function workspaceLabel(item: {
    readonly workspaceId?: string;
    readonly cwd?: string;
}, workspaces: readonly WorkspaceOption[]): string;
export declare function formatWithin(iso: string, now: Date, t: Translate): string;
export declare function formatDuration(startedAt?: string, finishedAt?: string): string | undefined;
export declare function clockTime(iso: string): string;
export type HistoryRange = 'day' | 'week' | 'month';
export declare const HISTORY_STATUS_OPTIONS: readonly ["succeeded", "failed", "interrupted", "running", "queued", "skipped", "cancelled"];
export type AutomationSortKey = 'created' | 'planned';
export type AutomationSortDirection = 'asc' | 'desc';
export interface HistoryGroup {
    readonly key: string;
    readonly label: string;
    readonly items: readonly import('./protocol.js').AutomationRunViewModel[];
}
/** 设置页任务列表排序：计划时间 = nextRunAt，无计划的任务固定排最后。 */
export declare function sortAutomations(items: readonly AutomationViewModel[], key: AutomationSortKey, direction: AutomationSortDirection): AutomationViewModel[];
export interface SortPreferenceStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
}
export declare const SETTINGS_SORT_DEFAULT_KEY = "dsh-automation.sort-default.settings";
export declare const OVERVIEW_SORT_DEFAULT_KEY = "dsh-automation.sort-default.overview";
/** 读取已保存的默认排序；缺失、损坏或无存储时返回 undefined，由调用方用自身默认值。 */
export declare function readSortDefault(storage: SortPreferenceStorage | undefined, storageKey: string): {
    readonly key: AutomationSortKey;
    readonly direction: AutomationSortDirection;
} | undefined;
export declare function writeSortDefault(storage: SortPreferenceStorage, storageKey: string, key: AutomationSortKey, direction: AutomationSortDirection): void;
export declare function groupHistory(runs: readonly import('./protocol.js').AutomationRunViewModel[], range: HistoryRange, now: Date, t: Translate): HistoryGroup[];
export declare function formFromAutomation(item: import('./protocol.js').AutomationViewModel, workspaces?: readonly WorkspaceOption[], defaultModel?: ModelOption | null, defaultPermission?: string, defaultAgentPreset?: string): AutomationFormState;
