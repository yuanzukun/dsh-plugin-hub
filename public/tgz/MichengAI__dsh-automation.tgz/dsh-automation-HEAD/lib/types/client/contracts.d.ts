import type { ComponentType, ReactNode } from 'react';
import type { AutomationLocaleKey } from './locales.js';
import type { AutomationRuntime } from './runtime.js';
import type { PermissionTranslate } from './permissions.js';
import type { PresetTranslate } from './agent-presets.js';
import type { SessionListState, WorkspaceListState } from './schedule-rail-model.js';
export type Translate = (key: AutomationLocaleKey, params?: Record<string, unknown>) => string;
export type ModelTranslate = (key: string, params?: Record<string, unknown>) => string;
export type SessionSelector = <Selected>(select: (state: SessionListState) => Selected, equals?: (left: Selected, right: Selected) => boolean) => Selected;
export type WorkspaceSelector = <Selected>(select: (state: WorkspaceListState) => Selected, equals?: (left: Selected, right: Selected) => boolean) => Selected;
export interface AutomationViewProps {
    readonly t: Translate;
    readonly permissionT: PermissionTranslate;
    readonly modelT: ModelTranslate;
    readonly presetT?: PresetTranslate | undefined;
    readonly runtime: AutomationRuntime;
    readonly closeSettings?: () => void;
    readonly addWorkspace?: () => Promise<string | undefined>;
}
export interface ClientRpc {
    call(channel: string, endpoint: string, payload: unknown, signal?: AbortSignal): Promise<unknown>;
}
export interface SlotRegisterOptions {
    readonly name: string;
    readonly id?: string;
    readonly key?: string;
    readonly order?: number;
    readonly locale?: string;
    readonly label?: () => string;
    readonly icon?: string;
    readonly priority?: number;
    readonly children?: Record<string, {
        readonly kind: string;
        readonly scope: string;
    }>;
    readonly inject?: () => Record<string, unknown>;
}
export interface ClientContext {
    effect(factory: () => void | (() => void), label?: string): void;
    get?(name: string): unknown;
    reflect?: {
        get?(name: string): unknown;
    };
    connection: {
        readonly rpc: ClientRpc;
    };
    sessions?: {
        refresh?: () => Promise<void>;
        list?: {
            getSnapshot(): {
                ids?: readonly string[];
                byId?: Record<string, unknown>;
            };
        };
    };
    uiWorkspace?: {
        openSession(id: string): void;
    };
    locale: {
        register(namespace: string, dictionaries: {
            readonly zh: Record<string, string>;
            readonly en: Record<string, string>;
        }): () => void;
        bind(namespace: string): (key: string, params?: Record<string, unknown>) => string;
    };
    slots: {
        inject(name: string, register: () => void | (() => void)): void;
        register(options: SlotRegisterOptions, component: ComponentType<any>): () => void;
        entries?(name: string): readonly unknown[];
        entriesOfSlot?(name: string): readonly unknown[];
        subscribe?(name: string, listener: () => void): () => void;
    };
}
export interface NativeSwitcherProps {
    readonly wide?: boolean;
    readonly openSession?: (sessionId: string) => void;
    readonly open?: (sessionId: string) => void;
    readonly useSessions?: SessionSelector;
    readonly useWorkspaces?: WorkspaceSelector;
    readonly renderSlot?: (name: string, props?: Record<string, unknown>, opts?: {
        readonly hookContext?: unknown;
    }) => ReactNode;
}
