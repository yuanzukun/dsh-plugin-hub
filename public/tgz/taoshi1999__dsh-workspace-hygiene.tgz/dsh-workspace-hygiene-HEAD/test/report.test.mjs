import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, mkdir, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { resolveConfig } from '../src/config.js'
import { writeLatestReport } from '../src/report.js'
import { scanWorkspace } from '../src/scan.js'

test('human report includes value decisions and organization suggestions', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-report-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  await writeFile(join(root, 'tmp', 'debug.log'), 'generated intermediate\n')
  const config = resolveConfig({ workspaceRoot: root, managedRoots: ['tmp'], minAgeHours: 0 })
  const scan = await scanWorkspace(root, config)
  const report = await writeLatestReport(scan, config)
  const markdown = await readFile(report.markdownPath, 'utf8')
  assert.match(markdown, /Value \| Action \| Suggested organization/)
  assert.match(markdown, /disposable \(\d+\/100\)/)
  assert.match(markdown, /workspace-artifacts\/to-delete\//)
})
