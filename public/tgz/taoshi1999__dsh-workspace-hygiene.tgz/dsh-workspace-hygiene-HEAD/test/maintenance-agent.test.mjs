import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, mkdir, writeFile, readFile, access, symlink, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { MaintenanceAgent } from '../src/maintenance-agent.js'
import { WorkerClient } from '../src/worker-client.js'
import { HygieneController } from '../src/controller.js'
import { resolveConfig } from '../src/config.js'
import { cleanliness, listDirectory } from '../src/inventory.js'
import { reviewEvidence } from '../src/reviewer.js'
import { runCommand } from '../src/verification.js'

async function fixture(t, extra = {}, reviewer = async () => ({ approved: true, summary: 'Fixture evidence verified', concerns: [] })) {
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-ui-test-'))
  // All recursive cleanup targets are literal mkdtemp children of the expected temp root.
  t.after(async () => { assert.ok(resolve(root).startsWith(resolve(tmpdir()))); await rm(root, { recursive: true, force: true }) })
  await mkdir(join(root, 'tmp'))
  await mkdir(join(root, 'src'))
  await writeFile(join(root, 'src', 'main.js'), 'export const answer = 42\n')
  await writeFile(join(root, 'tmp', 'discard.log'), 'temporary process residue\n')
  const config = resolveConfig({ managedRoots: ['tmp'], minAgeHours: 0, monitorIntervalMs: 1000, autoScan: false,
    valuePolicy: { discardPatterns: ['tmp/**'] }, ...extra })
  const agent = new MaintenanceAgent(root, config, { reviewer })
  await agent.init()
  return { root, agent, config }
}

test('manual monitoring does not move files or create a proposal; automatic mode asks first', async t => {
  const { root, agent } = await fixture(t)
  await agent.turnEnded()
  assert.equal(agent.snapshot().proposal, null)
  await access(join(root, 'tmp', 'discard.log'))
  await agent.setMode('automatic')
  const state = await agent.turnEnded()
  assert.equal(state.proposal.kind, 'suggestion')
  assert.ok(state.score.score < 80)
  await access(join(root, 'tmp', 'discard.log'))
  await agent.dismiss()
  assert.equal((await agent.turnEnded()).proposal, null, 'unchanged declined proposal does not nag')
  const revived = new MaintenanceAgent(root, agent.config)
  await revived.init()
  assert.equal(revived.snapshot().mode, 'automatic')
})

test('maintenance activity reports useful transitions without logging unchanged monitor scans', async t => {
  const { root, agent } = await fixture(t)
  const initial = agent.snapshot().activity
  assert.ok(initial.some(entry => entry.title === '整理 Agent 已启动'))
  assert.ok(initial.some(entry => entry.title === '目录扫描完成'))

  await agent.refresh({ reason: 'monitor' })
  assert.equal(agent.snapshot().activity.length, initial.length)

  await writeFile(join(root, 'tmp', 'new-output.log'), 'new temporary output\n')
  await agent.refresh({ reason: 'monitor' })
  assert.equal(agent.snapshot().activity.at(-1).title, '检测到工作区变化')

  const prepared = await agent.prepare()
  assert.equal(prepared.activity.at(-1).title, '整理方案已生成')
})

test('all directories can be browsed, including protected source and hidden files; path escape fails', async t => {
  const { root, config } = await fixture(t)
  await writeFile(join(root, '.env'), 'DO_NOT_DISPLAY_SECRET')
  const page = await listDirectory(root, config)
  assert.ok(page.entries.some(entry => entry.name === '.env'))
  const source = await listDirectory(root, config, { path: 'src' })
  assert.equal(source.entries[0].category, 'protected')
  assert.match(source.entries[0].purpose, /Source code/)
  assert.doesNotMatch(JSON.stringify(page), /DO_NOT_DISPLAY_SECRET/)
  await assert.rejects(listDirectory(root, config, { path: '../' }))
  await assert.rejects(listDirectory(root, config, { path: 'C:\\Windows' }))
  const paged = await listDirectory(root, config, { limit: 1 })
  assert.equal(paged.entries.length, 1)
  assert.equal(paged.nextOffset, 1)
  const external = await mkdtemp(join(tmpdir(), 'dsh-hygiene-link-test-'))
  t.after(() => rm(external, { recursive: true, force: true }))
  await symlink(external, join(root, 'external'), 'junction')
  const linked = await listDirectory(root, config)
  assert.equal(linked.entries.find(entry => entry.name === 'external').type, 'symlink')
  await assert.rejects(listDirectory(root, config, { path: 'external' }), /never followed/)
})

test('score is bounded, explainable and marks truncated evidence', () => {
  assert.equal(cleanliness({ catalogEntries: [] }).score, 100)
  const score = cleanliness({ truncated: true, catalogEntries: [{ valueClass: 'disposable' }, { valueClass: 'protected' }] })
  assert.equal(score.score, 30)
  assert.equal(score.complete, false)
  assert.equal(score.assessedFiles, 1)
})

test('file referenced from source is omitted from the organization plan', async t => {
  const { root, agent } = await fixture(t)
  await writeFile(join(root, 'src', 'main.js'), 'const log = "../tmp/discard.log"\n')
  const state = await agent.prepare()
  assert.equal(state.proposal.selectedCount, 0)
  assert.equal(state.proposal.blocked[0].path, 'tmp/discard.log')
})

test('execution requires a current confirmed proposal and rejects references introduced after approval', async t => {
  const { root, agent } = await fixture(t)
  const state = await agent.prepare()
  assert.equal(state.proposal.selectedCount, 1)
  await assert.rejects(agent.execute({ proposalId: state.proposal.id, confirm: false }), /confirmed/)
  await assert.rejects(agent.execute({ proposalId: 'wrong', confirm: true }), /confirmed/)
  await writeFile(join(root, 'src', 'main.js'), 'const log = "discard.log"\n')
  const result = await agent.execute({ proposalId: state.proposal.id, confirm: true })
  assert.equal(result.phase, 'blocked')
  await access(join(root, 'tmp', 'discard.log'))
})

test('baseline check failure leaves source files unchanged', async t => {
  const { root, agent } = await fixture(t, { verificationCommands: [{ command: process.execPath, args: ['-e', 'process.exit(1)'] }] })
  const state = await agent.prepare()
  const result = await agent.execute({ proposalId: state.proposal.id, confirm: true })
  assert.equal(result.phase, 'blocked')
  assert.match(result.error, /Baseline/)
  await access(join(root, 'tmp', 'discard.log'))
})

test('post-organization check failure restores quarantined bytes', async t => {
  const { root, agent } = await fixture(t, { verificationCommands: [{ command: process.execPath, args: ['-e', 'process.exit(require("fs").existsSync("tmp/discard.log") ? 0 : 1)'] }] })
  const state = await agent.prepare()
  const result = await agent.execute({ proposalId: state.proposal.id, confirm: true })
  assert.equal(result.phase, 'rolled-back', JSON.stringify(result))
  assert.equal(await readFile(join(root, 'tmp', 'discard.log'), 'utf8'), 'temporary process residue\n')
})

test('independent reviewer rejection triggers rollback', async t => {
  const { root, agent } = await fixture(t, {}, async () => ({ approved: false, summary: 'needs more evidence' }))
  const state = await agent.prepare()
  const result = await agent.execute({ proposalId: state.proposal.id, confirm: true })
  assert.equal(result.phase, 'rolled-back', JSON.stringify(result))
  await access(join(root, 'tmp', 'discard.log'))
})

test('verified organization remains pending until primary Agent supplies evidence', async t => {
  const { root, agent } = await fixture(t)
  const state = await agent.prepare()
  const result = await agent.execute({ proposalId: state.proposal.id, confirm: true })
  assert.equal(result.phase, 'awaiting-review', JSON.stringify(result))
  await assert.rejects(access(join(root, 'tmp', 'discard.log')), { code: 'ENOENT' })
  await assert.rejects(agent.prepare(), /current review/)
  await assert.rejects(agent.recordReview({ runId: result.result.run.runId, approved: true, summary: 'fine', checks: [] }), /evidence/)
  const complete = await agent.recordReview({ runId: result.result.run.runId, approved: true, summary: 'Reviewed project references and source integrity', checks: ['src/main.js contents unchanged; fixture static verification passed'] })
  assert.equal(complete.phase, 'completed')
})

test('negative primary review is recoverable without deleting evidence', async t => {
  const { root, agent } = await fixture(t)
  const state = await agent.prepare()
  const result = await agent.execute({ proposalId: state.proposal.id, confirm: true })
  await agent.recordReview({ runId: result.result.run.runId, approved: false, summary: 'Found consumer outside the reference scan', checks: ['External integration requires original path'] })
  assert.equal((await agent.rollback()).phase, 'rolled-back')
  await access(join(root, 'tmp', 'discard.log'))
})

test('maintenance worker has its own PID and persists its own mode/context', async t => {
  const { root, config } = await fixture(t)
  const worker = new WorkerClient(root, config)
  t.after(() => worker.dispose())
  const initial = await worker.ready
  assert.notEqual(initial.pid, process.pid)
  assert.equal(initial.independentContext, true)
  const changed = await worker.request('setMode', 'automatic')
  assert.equal(changed.mode, 'automatic')
  assert.ok((await worker.request('browse', { path: 'src' })).entries.length)
})

test('controller rejects workspace overrides, busy peers and unassigned primary reviews', async t => {
  const { root, config } = await fixture(t)
  const agent = { id: 'main', status: 'running', session: { header: { cwd: root } }, runMaintenance: async task => task(new AbortController().signal) }
  const controller = new HygieneController({ agents: { get: id => id === 'main' ? agent : undefined, list: () => [agent] } }, config)
  t.after(() => controller.dispose())
  assert.equal((await controller.rpc('status', { sessionId: 'main', root: 'C:\\' })).ok, false)
  assert.equal((await controller.rpc('status', { sessionId: 'unknown' })).ok, false)
  const { worker } = await controller.workerFor(agent)
  await assert.rejects(controller.withIdleWorkspace(await controller.rootFor(agent), worker, () => assert.fail('must not execute')), /in use/)
  await assert.rejects(controller.review({ runId: 'forged' }, { agent }), /assigned/)
  agent.status = 'idle'
  let reserved = false
  agent.runMaintenance = async task => { reserved = true; return task(new AbortController().signal) }
  await controller.withIdleWorkspace(await controller.rootFor(agent), worker, async () => { assert.equal(reserved, true) })
})

test('cancelled independent verification restores files without asking the primary Agent to review', async t => {
  const abort = new AbortController()
  const { root, agent } = await fixture(t, {}, async () => { abort.abort(); return { approved: true, summary: 'Must not commit cancelled evidence' } })
  const state = await agent.prepare()
  const result = await agent.execute({ proposalId: state.proposal.id, confirm: true }, abort.signal)
  assert.equal(result.phase, 'rolled-back')
  assert.equal(result.result.primaryReview.status, 'not-started')
  await access(join(root, 'tmp', 'discard.log'))
})

test('late source changes fail verification and preserve an external edit while restoring artifacts', async t => {
  const { root, agent } = await fixture(t)
  agent.reviewer = async () => { await writeFile(join(root, 'src', 'main.js'), 'external edit\n'); return { approved: true, summary: 'Earlier evidence was valid' } }
  const state = await agent.prepare()
  const result = await agent.execute({ proposalId: state.proposal.id, confirm: true })
  assert.equal(result.phase, 'rolled-back')
  assert.match(result.error, /changed during verification/)
  assert.equal(await readFile(join(root, 'src', 'main.js'), 'utf8'), 'external edit\n')
  await access(join(root, 'tmp', 'discard.log'))
})

test('controller hands off exactly once, rejects another Agent, and rolls back a negative primary review at idle', async t => {
  const { root, agent: maintenance, config } = await fixture(t)
  let handoffs = 0
  const primary = { id: 'main', status: 'idle', session: { header: { cwd: root } }, followup: () => handoffs++, runMaintenance: task => task(new AbortController().signal) }
  const worker = { latest: maintenance.snapshot(), ready: Promise.resolve(), request: async (method, args) => { const result = await maintenance[method](args); worker.latest = result; return result }, cancel() {}, async dispose() {} }
  const controller = new HygieneController({ agents: { get: () => primary, list: () => [primary] } }, config, { createWorker: () => worker })
  t.after(() => controller.dispose())
  const state = await maintenance.prepare()
  await controller.startJob(primary, 'execute', { proposalId: state.proposal.id, confirm: true }, false)
  await controller.observe(primary)
  assert.equal(handoffs, 1)
  const verdict = { runId: worker.latest.result.run.runId, approved: false, summary: 'External consumer detected', checks: ['An external integration still needs tmp/discard.log'] }
  await assert.rejects(controller.review(verdict, { agent: { ...primary } }), /assigned/)
  await controller.review(verdict, { agent: primary })
  await controller.observe(primary, true)
  assert.equal(worker.latest.phase, 'rolled-back')
  await access(join(root, 'tmp', 'discard.log'))
})

test('restart invalidates proposals and oversized independent evidence is rejected without a partial review', async t => {
  const { root, agent, config } = await fixture(t)
  const proposal = (await agent.prepare()).proposal
  const restored = new MaintenanceAgent(root, config)
  await restored.init()
  assert.equal(restored.snapshot().proposal, null)
  await assert.rejects(restored.execute({ proposalId: proposal.id, confirm: true }), /confirmed/)
  await assert.rejects(reviewEvidence({ text: 'a'.repeat(20001) }, config), /exceeds 20,000/)
})

test('verification timeout terminates a process tree instead of leaving inherited pipes open', { timeout: 10000 }, async () => {
  const script = 'require("node:child_process").spawn(process.execPath,["-e","setInterval(()=>{},1000)"],{stdio:"inherit",windowsHide:true});setInterval(()=>{},1000)'
  const result = await runCommand(process.execPath, ['-e', script], { timeout: 1000 })
  assert.equal(result.ok, false)
  assert.equal(result.timedOut, true)
})
