import test from 'node:test'
import assert from 'node:assert/strict'
import {
  access,
  mkdir,
  mkdtemp,
  readFile,
  readdir,
  rm,
  writeFile,
} from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import * as catalogApi from '../src/catalog.js'
import { scanWorkspace } from '../src/scan.js'
import { applyPlan, planWorkspace } from '../src/transaction.js'

async function makeWorkspace(prefix = 'dsh-hygiene-catalog-integration-') {
  const root = await mkdtemp(join(tmpdir(), prefix))
  await mkdir(join(root, 'tmp'), { recursive: true })
  return root
}

function config(root, extra = {}) {
  return {
    workspaceRoot: root,
    managedRoots: ['tmp'],
    minAgeHours: 0,
    candidateExtensions: ['log'],
    candidateDirectories: ['tmp'],
    ...extra,
  }
}

async function sync(root, cfg) {
  const scan = await scanWorkspace(root, cfg)
  const catalog = await catalogApi.syncCatalog(root, scan, cfg, {
    observedAt: scan.scannedAt,
    refreshMissing: scan.truncated !== true,
    pruneMissing: scan.truncated !== true,
    strict: false,
  })
  return { scan, catalog }
}

async function metadataFiles(root, group) {
  try {
    return (await readdir(join(root, 'workspace-artifacts', group)))
      .filter(name => name.endsWith('.json'))
  } catch (error) {
    if (error?.code === 'ENOENT') return []
    throw error
  }
}

test('idle catalog synchronization stores metadata only and leaves source bytes in place', async (t) => {
  const root = await makeWorkspace()
  t.after(() => rm(root, { recursive: true, force: true }))
  const source = join(root, 'tmp', 'unique-process-output.log')
  const sourceText = 'UNIQUE_SOURCE_BYTES_9e4a\n'
  await writeFile(source, sourceText)
  const cfg = config(root)
  const { catalog } = await sync(root, cfg)

  assert.equal(catalog.counts['to-delete'], 1)
  assert.equal(await readFile(source, 'utf8'), sourceText)
  const files = await metadataFiles(root, 'to-delete')
  assert.equal(files.length, 1)
  const metadataPath = join(root, 'workspace-artifacts', 'to-delete', files[0])
  const metadataText = await readFile(metadataPath, 'utf8')
  const metadata = JSON.parse(metadataText)
  assert.equal(metadata.relativePath, 'tmp/unique-process-output.log')
  assert.equal(metadata.directory, 'tmp')
  assert.equal(metadata.name, 'unique-process-output.log')
  assert.equal(typeof metadata.purpose, 'string')
  assert.equal(metadata.recommendation, 'delete')
  assert.equal(metadata.group, 'to-delete')
  assert.match(metadata.suggestedPath, /^workspace-artifacts\/to-delete\//)
  assert.match(metadata.suggestedSourcePath, /^tmp\//)
  assert.doesNotMatch(metadataText, /UNIQUE_SOURCE_BYTES_9e4a/)
})

test('confirming a to-delete catalog entry deletes the source and retires its metadata', async (t) => {
  const root = await makeWorkspace()
  t.after(() => rm(root, { recursive: true, force: true }))
  const source = join(root, 'tmp', 'confirmed-delete.log')
  await writeFile(source, 'delete me\n')
  const cfg = config(root)
  await sync(root, cfg)
  const plan = await planWorkspace(root, cfg, { actions: ['delete'], includeMedium: true })
  assert.equal(plan.selectedCount, 1)
  const result = await applyPlan(root, cfg, {
    planId: plan.planId,
    token: plan.token,
  }, { token: plan.token, confirm: true })
  assert.equal(result.counts.deleted, 1)
  await assert.rejects(access(source), { code: 'ENOENT' })
  assert.equal((await catalogApi.readCatalog(root, cfg)).entries.length, 0)
  assert.equal((await metadataFiles(root, 'to-delete')).length, 0)
})

test('without confirmation both a to-delete source and its metadata remain untouched', async (t) => {
  const root = await makeWorkspace()
  t.after(() => rm(root, { recursive: true, force: true }))
  const source = join(root, 'tmp', 'await-confirmation.log')
  await writeFile(source, 'keep until reviewed\n')
  const cfg = config(root)
  await sync(root, cfg)
  const plan = await planWorkspace(root, cfg, { actions: ['delete'], includeMedium: true })
  const result = await applyPlan(root, cfg, {
    planId: plan.planId,
    token: plan.token,
  }, { token: plan.token })
  assert.equal(result.code, 'CONFIRMATION_REQUIRED')
  await access(source)
  assert.equal((await catalogApi.readCatalog(root, cfg)).counts['to-delete'], 1)
})

test('physical organization rejects a catalog directory as a source destination', async (t) => {
  const root = await makeWorkspace('dsh-hygiene-catalog-destination-')
  t.after(() => rm(root, { recursive: true, force: true }))
  const source = join(root, 'tmp', 'organization-target.log')
  await writeFile(source, 'must not move into catalog\n')
  const cfg = config(root, {
    valuePolicy: {
      retainPatterns: ['tmp/organization-target.log'],
      organization: { fileRoot: 'workspace-artifacts' },
    },
  })
  const plan = await planWorkspace(root, cfg, {
    includeMedium: true,
    includeRetain: true,
    actions: ['retain'],
  })
  assert.equal(plan.selectedCount, 1)
  const result = await applyPlan(root, cfg, {
    planId: plan.planId,
    token: plan.token,
  }, { token: plan.token, confirm: true, organize: true })
  assert.equal(result.counts.organized, 0)
  assert.ok(result.errors.some(error => error.code === 'DESTINATION_ERROR'))
  await access(source)
})

test('a truncated scan does not mark unseen catalog entries stale', async (t) => {
  const root = await makeWorkspace('dsh-hygiene-catalog-truncated-')
  t.after(() => rm(root, { recursive: true, force: true }))
  await writeFile(join(root, 'tmp', 'a-first.log'), 'first\n')
  const second = join(root, 'tmp', 'b-second.log')
  await writeFile(second, 'second\n')
  const completeConfig = config(root, { maxScanFiles: 50 })
  await sync(root, completeConfig)
  await rm(second)
  const boundedConfig = config(root, { maxScanFiles: 1 })
  const bounded = await sync(root, boundedConfig)
  assert.equal(bounded.scan.truncated, true)
  const afterBounded = await catalogApi.readCatalog(root, boundedConfig)
  const unseen = afterBounded.entries.find(entry => entry.relativePath === 'tmp/b-second.log')
  assert.ok(unseen)
  assert.notEqual(unseen.status, 'stale')

  const full = await sync(root, completeConfig)
  assert.equal(full.scan.truncated, false)
  const afterFull = await catalogApi.readCatalog(root, completeConfig)
  const missing = afterFull.entries.find(entry => entry.relativePath === 'tmp/b-second.log')
  assert.equal(missing?.status, 'stale')
})
