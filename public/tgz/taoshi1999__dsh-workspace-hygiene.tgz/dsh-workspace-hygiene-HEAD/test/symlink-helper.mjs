import { stat, symlink } from 'node:fs/promises'
/** Directory junctions exercise Windows path-redirection guards without elevated privileges. */
export async function testSymlink(t, target, path) {
  const directory = (await stat(target)).isDirectory()
  try { await symlink(target, path, directory && process.platform === 'win32' ? 'junction' : directory ? 'dir' : 'file'); return true }
  catch (error) {
    if (process.platform === 'win32' && error.code === 'EPERM' && !directory) { t.skip('Creating file symlinks requires Windows Developer Mode or elevated privileges'); return false }
    throw error
  }
}
