import test from 'node:test'
import assert from 'node:assert/strict'
import { access, readdir, readFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const root = dirname(here)

test('package exposes the DeepSeek Harness bundle contract', async () => {
  const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'))
  assert.equal(pkg.type, 'module')
  assert.equal(pkg.main, 'index.js')
  assert.equal(pkg.dsh?.bundle?.patch, './cordis.patch.yml')
  assert.equal(pkg.exports['./client'], './client.js')
  assert.equal(pkg.exports['./package.json'], './package.json')
  assert.equal(pkg.dsh.client.platform, 'web')
  assert.ok(pkg.files.includes('client.js'))
  assert.ok(pkg.files.includes('index.js'))
  assert.ok(pkg.files.includes('cordis.patch.yml'))
  assert.ok(pkg.files.includes('src'))
  assert.ok(pkg.files.includes('docs'))
  assert.ok(pkg.files.includes('assets'))
  assert.ok(pkg.files.includes('examples'))
  assert.equal(pkg.bin?.['dsh-workspace-hygiene'], 'bin/dsh-workspace-hygiene.mjs')
})

test('bundle patch inserts one stable plugin row by package name', async () => {
  const patch = await readFile(join(root, 'cordis.patch.yml'), 'utf8')
  assert.match(patch, /id:\s*workspace-hygiene/)
  assert.match(patch, /name:\s*dsh-workspace-hygiene/)
  assert.doesNotMatch(patch, /\/src\/|\.ts['"]?\s*$/m)
})

test('workspace view keeps organization conversation in the right panel', async () => {
  const client = await readFile(join(root, 'client.js'), 'utf8')
  assert.match(client, /function HygieneAgentPanel/)
  assert.match(client, /className: 'hygiene-workarea'/)
  assert.match(client, /data-composer-seat/)
  assert.match(client, /工作区整理 Agent 对话/)
  assert.match(client, /方案等待确认/)
  assert.doesNotMatch(client, /createPortal|hygiene-modal-backdrop|workspace-hygiene-confirmation/)
})

test('documentation is bilingual and references the static workspace screenshots', async () => {
  const [en, zh, screenshots] = await Promise.all([
    readFile(join(root, 'README.md'), 'utf8'),
    readFile(join(root, 'README.zh.md'), 'utf8'),
    readFile(join(root, 'screenshots.json'), 'utf8'),
  ])
  assert.match(en, /README\.zh\.md/)
  assert.match(zh, /README\.md/)
  assert.doesNotMatch(en, /\.gif/i)
  assert.doesNotMatch(zh, /\.gif/i)
  const screenshotPaths = [
    'assets/workspace-before.png',
    'assets/workspace-search-noise.png',
    'assets/workspace-value-review.png',
    'assets/workspace-after.png',
  ]
  for (const path of screenshotPaths) {
    assert.match(en, new RegExp(path.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')))
    assert.match(zh, new RegExp(path.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')))
    await access(join(root, path))
  }
  const metadata = JSON.parse(screenshots)
  assert.equal(metadata.assets.length, screenshotPaths.length)
  assert.deepEqual(metadata.assets.map(asset => asset.path), screenshotPaths)
  assert.ok(metadata.assets.every(asset => asset.kind === 'png'))
  assert.ok(metadata.assets.every(asset => asset.width === 1200 && asset.height === 700))
  assert.ok(metadata.assets.every(asset => !/\.gif$/i.test(asset.path)))
})

test('the generic starter examples are self-contained JSON/ignore files', async () => {
  const config = JSON.parse(await readFile(join(root, 'examples', 'workspace-hygiene.config.json'), 'utf8'))
  assert.deepEqual(config.managedRoots, ['tmp', 'scratch', 'outputs', 'artifacts/staging'])
  assert.equal(config.mode, 'manual')
  assert.equal(config.archiveRoot, '~/.dsh/workspace-hygiene-archive')
  assert.deepEqual(config.valuePolicy.retainPatterns, [
    'reports/final/**',
    'outputs/release/**',
    'artifacts/published/**',
  ])
  assert.deepEqual(config.valuePolicy.discardPatterns, [
    'tmp/**',
    'scratch/**',
    'artifacts/staging/**',
  ])
  assert.equal(config.valuePolicy.allowDelete, false)
  assert.equal(config.valuePolicy.organization.namingTemplate, '{date}-{stem}{ext}')
  const ignore = await readFile(join(root, 'examples', 'workspace.hygieneignore'), 'utf8')
  assert.match(ignore, /scratch\/keep/)
  assert.match(ignore, /tmp\/manual-review/)
  const exampleFiles = (await readdir(join(root, 'examples'))).sort()
  assert.deepEqual(exampleFiles, [
    'cordis.patch.example.yml',
    'workspace-hygiene.config.json',
    'workspace.hygieneignore',
  ])
})
