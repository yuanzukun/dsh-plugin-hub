import test from 'node:test'
import assert from 'node:assert/strict'
import { access, mkdir, mkdtemp, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

async function loadPlugin(t) {
  try {
    return await import('../index.js')
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return undefined
    }
    throw error
  }
}

function fakeContext() {
  const tools = []
  const commands = []
  const listeners = new Map()
  const context = {
    tools: {
      register(definition) {
        tools.push(definition)
        return () => {
          const index = tools.indexOf(definition)
          if (index >= 0) tools.splice(index, 1)
        }
      },
    },
    commands: {
      register(definition) {
        commands.push(definition)
        return () => {
          const index = commands.indexOf(definition)
          if (index >= 0) commands.splice(index, 1)
        }
      },
    },
    on(event, listener) {
      listeners.set(event, listener)
      return () => listeners.delete(event)
    },
    effect(factory) {
      const disposer = factory()
      return typeof disposer === 'function' ? disposer : () => {}
    },
  }
  return { context, tools, commands, listeners }
}

test('plugin registers only the primary review tool and disposes it', async (t) => {
  const plugin = await loadPlugin(t)
  if (!plugin) return
  const { context, tools, commands } = fakeContext()
  const workspaceRoot = await mkdtemp(join(tmpdir(), 'dsh-hygiene-plugin-'))
  await writeFile(join(workspaceRoot, 'README.md'), 'protected\n')
  const instance = plugin.apply(context, {
    workspaceRoot,
    autoScan: false,
    managedRoots: ['.'],
  })
  assert.deepEqual(tools.map(item => item.name), ['workspace_hygiene_review'])
  assert.equal(commands.length, 0)
  await instance.dispose()
  assert.equal(tools.length, 0)
  assert.equal(commands.length, 0)
})

test('committed turn completion schedules independent assessment after idle, including failed turns', async t => {
  const plugin = await loadPlugin(t)
  if (!plugin) return
  const { context, listeners } = fakeContext()
  const instance = plugin.apply(context, { autoScan: false })
  t.after(() => instance.dispose())
  const agent = { id: 'turn-end-agent', session: { header: { cwd: process.cwd() } } }
  instance.controller.remember(agent)
  const assessments = []
  instance.controller.observe = async (subject, ended) => assessments.push({ subject, ended })
  listeners.get('session/event')({ id: agent.id }, { type: 'turn/end', outcome: 'error' })
  assert.equal(assessments.length, 0)
  listeners.get('agent/status')({ agent, status: 'idle' })
  await new Promise(resolve => setImmediate(resolve))
  assert.deepEqual(assessments, [{ subject: agent, ended: true }])
  listeners.get('agent/status')({ agent, status: 'idle' })
  await new Promise(resolve => setImmediate(resolve))
  assert.equal(assessments.length, 1)
})

test('tool handlers fail closed when an apply request lacks confirmation', async (t) => {
  const plugin = await loadPlugin(t)
  if (!plugin) return
  const workspaceRoot = await mkdtemp(join(tmpdir(), 'dsh-hygiene-handler-'))
  const handlers = plugin.buildTools({ workspaceRoot, autoScan: false, managedRoots: ['.'] })
  const result = await handlers.workspace_hygiene_apply({
    planId: 'plan-missing',
    token: 'not-a-token',
    confirm: false,
  })
  assert.equal(result.ok, false)
  assert.ok(result.error)
})

test('model tools reject arbitrary workspace redirects by default', async (t) => {
  const plugin = await loadPlugin(t)
  if (!plugin) return
  const workspaceRoot = await mkdtemp(join(tmpdir(), 'dsh-hygiene-redirect-base-'))
  const otherRoot = await mkdtemp(join(tmpdir(), 'dsh-hygiene-redirect-other-'))
  const handlers = plugin.buildTools({ autoScan: false })
  const result = await handlers.workspace_hygiene_scan({ workspaceRoot: otherRoot }, {
    agent: { session: { header: { cwd: workspaceRoot } } },
  })
  assert.equal(result.ok, false)
  assert.equal(result.error.code, 'PATH_OVERRIDE_DISABLED')
})

test('registered definitions satisfy the native Harness tool boundary', async (t) => {
  const plugin = await loadPlugin(t)
  if (!plugin) return
  const { context, tools } = fakeContext()
  const workspaceRoot = await mkdtemp(join(tmpdir(), 'dsh-hygiene-definition-'))
  const instance = plugin.apply(context, { workspaceRoot, autoScan: false })
  for (const definition of tools) {
    assert.match(definition.name, /^workspace_hygiene_/)
    assert.equal(typeof definition.description, 'string')
    assert.equal(definition.parameters.type, 'object')
    assert.equal(definition.output.schema.type, 'object')
    assert.equal(typeof definition.output.render, 'function')
    assert.equal(typeof definition.execute, 'function')
    const rendered = definition.output.render({}, { ok: true })
    assert.equal(rendered[0].type, 'text')
  }
  await instance.dispose()
})

test('tool schemas stay within the Harness dsh-tools JSON-schema subset', async (t) => {
  const plugin = await loadPlugin(t)
  if (!plugin) return
  const allowed = new Set([
    'type', 'oneOf', 'properties', 'required', 'additionalProperties', 'items',
    'enum', 'const', 'description', 'title', 'default', 'examples',
  ])
  const violations = []
  function walk(node, path) {
    if (!node || typeof node !== 'object') return
    if (Array.isArray(node)) {
      node.forEach((item, index) => walk(item, `${path}[${index}]`))
      return
    }
    for (const [key, value] of Object.entries(node)) {
      if (!allowed.has(key)) violations.push(`${path}.${key}`)
      if (key === 'additionalProperties' && typeof value !== 'boolean') {
        violations.push(`${path}.additionalProperties must be boolean`)
      }
      if (key === 'properties' && value && typeof value === 'object' && !Array.isArray(value)) {
        for (const [property, child] of Object.entries(value)) walk(child, `${path}.properties.${property}`)
      } else if (key !== 'properties' && key !== 'examples') {
        walk(value, `${path}.${key}`)
      }
    }
  }
  for (const [name, definition] of Object.entries(plugin.TOOL_DEFINITIONS)) {
    walk(definition.parameters, `${name}.parameters`)
    walk(definition.output.schema, `${name}.output.schema`)
  }
  assert.equal(
    plugin.TOOL_DEFINITIONS.workspace_hygiene_plan.parameters.properties.decisions.additionalProperties,
    true,
  )
  assert.deepEqual(violations, [])
})
