import { testSymlink } from './symlink-helper.mjs'
import test from 'node:test'
import assert from 'node:assert/strict'
import {
  access,
  lstat,
  mkdtemp,
  readFile,
  readdir,
  rm,
  symlink,
  writeFile,
} from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, relative, resolve } from 'node:path'

import {
  CATALOG_GROUPS,
  CatalogError,
  catalogEntryPath,
  catalogRootFor,
  readCatalog,
  removeCatalogEntry,
  removeConfirmedCatalogEntry,
  syncCatalog,
  updateCatalogEntry,
} from '../src/catalog.js'

async function makeWorkspace(prefix = 'dsh-hygiene-catalog-') {
  const root = await mkdtemp(join(tmpdir(), prefix))
  await writeFile(join(root, 'scratch-run.log'), 'source bytes must stay in place\n')
  return root
}

function config(root, extra = {}) {
  return {
    workspaceRoot: root,
    catalog: { root: 'workspace-artifacts' },
    ...extra,
  }
}

function record(relativePath, fields = {}) {
  const name = relativePath.split('/').at(-1)
  const directory = relativePath.includes('/')
    ? relativePath.slice(0, relativePath.lastIndexOf('/'))
    : '.'
  return {
    relativePath,
    directory,
    name,
    purpose: 'generated process evidence',
    recommendation: 'archive',
    group: 'intermediate',
    valueClass: 'intermediate',
    ...fields,
  }
}

async function metadataFiles(root, group) {
  const directory = join(root, 'workspace-artifacts', group)
  try {
    return (await readdir(directory)).filter(name => name.endsWith('.json')).sort()
  } catch (error) {
    if (error?.code === 'ENOENT') return []
    throw error
  }
}

test('catalog root and source paths stay inside the workspace boundary', async (t) => {
  const root = await makeWorkspace('dsh-hygiene-catalog-root-')
  t.after(() => rm(root, { recursive: true, force: true }))

  assert.equal(catalogRootFor(root, config(root)), join(root, 'workspace-artifacts'))
  assert.throws(
    () => catalogRootFor(root, config(root, { catalogRoot: '../outside' })),
    error => error instanceof CatalogError && error.code === 'CATALOG_ROOT_INVALID',
  )
  assert.throws(
    () => catalogRootFor(root, config(root, { catalogRoot: resolve(root, '..', 'outside') })),
    error => error instanceof CatalogError && error.code === 'CATALOG_ROOT_INVALID',
  )
  assert.throws(
    () => catalogEntryPath(root, 'review', 'workspace-artifacts/metadata.json', config(root)),
    error => error instanceof CatalogError && error.code === 'CATALOG_SELF_REFERENCE',
  )

  // A symlink at the catalog root must fail closed before any directory or
  // metadata write can be redirected outside the workspace.
  const outside = await mkdtemp(join(tmpdir(), 'dsh-hygiene-catalog-outside-'))
  t.after(() => rm(outside, { recursive: true, force: true }))
  if (!await testSymlink(t, outside, join(root, 'workspace-artifacts'))) return
  await assert.rejects(
    syncCatalog(root, [record('scratch-run.log')], config(root)),
    error => error instanceof CatalogError && error.code === 'SYMLINK_REJECTED',
  )
  assert.equal((await readdir(outside)).length, 0)
})

test('sync writes deterministic metadata records and never copies or moves source files', async (t) => {
  const root = await makeWorkspace('dsh-hygiene-catalog-sync-')
  t.after(() => rm(root, { recursive: true, force: true }))
  const source = join(root, 'scratch-run.log')
  const sourceBytes = await readFile(source)
  const cfg = config(root)
  const entry = record('scratch-run.log', {
    purpose: 'reproducible benchmark trace',
    recommendation: 'archive',
    group: 'intermediate',
    valueScore: 52,
    reasons: ['generated-prefix'],
  })

  const first = await syncCatalog(root, [entry], cfg, { now: '2026-09-02T00:00:00.000Z' })
  assert.equal(first.counts.intermediate, 1)
  assert.equal(first.entries.length, 1)
  assert.deepEqual(first.changed, {
    created: ['scratch-run.log'],
    updated: [],
    moved: [],
    removed: [],
  })
  assert.deepEqual(await readFile(source), sourceBytes)
  assert.equal((await lstat(source)).isFile(), true)

  const files = await metadataFiles(root, 'intermediate')
  assert.equal(files.length, 1)
  const metadataPath = join(root, 'workspace-artifacts', 'intermediate', files[0])
  assert.equal(metadataPath, catalogEntryPath(root, 'intermediate', 'scratch-run.log', cfg))
  const metadata = JSON.parse(await readFile(metadataPath, 'utf8'))
  assert.equal(metadata.relativePath, 'scratch-run.log')
  assert.equal(metadata.directory, '.')
  assert.equal(metadata.name, 'scratch-run.log')
  assert.equal(metadata.purpose, 'reproducible benchmark trace')
  assert.equal(metadata.group, 'intermediate')
  assert.equal(metadata.recommendation, 'archive')
  assert.notEqual(await readFile(metadataPath, 'utf8'), sourceBytes.toString('utf8'))

  // Repeating an equivalent observation is a no-op and preserves the same
  // deterministic metadata filename and serialized representation.
  const before = await readFile(metadataPath, 'utf8')
  const second = await syncCatalog(root, [{
    ...entry,
    // Deliberately reorder fields at the producer boundary.
    group: undefined,
    category: 'intermediate',
  }], cfg, { now: '2026-09-02T00:00:00.000Z' })
  assert.deepEqual(second.changed, { created: [], updated: [], moved: [], removed: [] })
  assert.equal(await readFile(metadataPath, 'utf8'), before)
  assert.deepEqual(await readFile(source), sourceBytes)
})

test('updating a record migrates only its metadata between category directories', async (t) => {
  const root = await makeWorkspace('dsh-hygiene-catalog-migrate-')
  t.after(() => rm(root, { recursive: true, force: true }))
  const cfg = config(root)
  const initial = await syncCatalog(root, [record('scratch-run.log', {
    group: 'review',
    recommendation: 'review',
    valueClass: 'uncertain',
    purpose: 'needs operator review',
  })], cfg, { now: '2026-09-02T00:00:00.000Z' })
  assert.equal(initial.counts.review, 1)
  assert.equal((await metadataFiles(root, 'review')).length, 1)

  const updated = await updateCatalogEntry(root, record('scratch-run.log', {
    group: 'retained',
    recommendation: 'retain',
    valueClass: 'valuable',
    purpose: 'approved benchmark evidence',
    valueScore: 91,
  }), cfg, { now: '2026-09-02T01:00:00.000Z' })
  assert.deepEqual(updated.changed.moved, ['scratch-run.log'])
  assert.ok(updated.changed.updated.includes('scratch-run.log'))
  assert.equal(updated.counts.review, 0)
  assert.equal(updated.counts.retained, 1)
  assert.equal((await metadataFiles(root, 'review')).length, 0)
  assert.equal((await metadataFiles(root, 'retained')).length, 1)
  assert.equal(updated.entries[0].purpose, 'approved benchmark evidence')
  assert.equal(updated.entries[0].recommendation, 'retain')

  // The source remains exactly where it was; category changes are catalog
  // metadata migrations, not workspace file organization.
  assert.equal(await readFile(join(root, 'scratch-run.log'), 'utf8'), 'source bytes must stay in place\n')
  assert.equal((await readdir(root)).includes('workspace-artifacts'), true)
  assert.equal((await readdir(root)).includes('scratch-run.log'), true)
})

test('removing a to-delete entry requires confirmation and removes metadata only', async (t) => {
  const root = await makeWorkspace('dsh-hygiene-catalog-remove-')
  t.after(() => rm(root, { recursive: true, force: true }))
  const cfg = config(root)
  await syncCatalog(root, [record('scratch-run.log', {
    group: 'to-delete',
    recommendation: 'delete',
    valueClass: 'disposable',
    purpose: 'confirmed disposable process residue',
  })], cfg)
  assert.equal((await metadataFiles(root, 'to-delete')).length, 1)

  await assert.rejects(
    removeCatalogEntry(root, 'scratch-run.log', cfg, { requireConfirmation: true }),
    error => error instanceof CatalogError && error.code === 'CONFIRMATION_REQUIRED',
  )
  assert.equal((await metadataFiles(root, 'to-delete')).length, 1)
  assert.equal(await readFile(join(root, 'scratch-run.log'), 'utf8'), 'source bytes must stay in place\n')

  const removed = await removeConfirmedCatalogEntry(root, 'scratch-run.log', cfg)
  assert.deepEqual(removed.removed, ['scratch-run.log'])
  assert.equal((await metadataFiles(root, 'to-delete')).length, 0)
  // Deleting the source is a separate, confirmed transaction owned by the
  // caller; catalog removal must never perform that destructive operation.
  assert.equal(await readFile(join(root, 'scratch-run.log'), 'utf8'), 'source bytes must stay in place\n')

  const empty = await readCatalog(root, cfg)
  assert.equal(empty.entries.length, 0)
  assert.deepEqual(empty.counts, Object.fromEntries(CATALOG_GROUPS.map(group => [group, 0])))
})

