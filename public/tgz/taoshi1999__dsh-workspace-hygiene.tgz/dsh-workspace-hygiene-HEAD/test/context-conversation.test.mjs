import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, mkdir, writeFile, readFile, rm, realpath, symlink } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { PrivateConversation } from '../src/private-conversation.js'
import { collectWorkspaceContext, generatePrivateResponse } from '../src/context-bridge.js'
import { MaintenanceAgent } from '../src/maintenance-agent.js'
import { HygieneController } from '../src/controller.js'
import { WorkerClient } from '../src/worker-client.js'
import { resolveConfig } from '../src/config.js'
import { projectEvidence } from '../src/verification.js'

async function fixture(t) {
  const scratch = await mkdtemp(join(tmpdir(), 'hygiene-context-test-'))
  t.after(async () => { assert.ok(resolve(scratch).startsWith(resolve(tmpdir()))); await rm(scratch, { recursive: true, force: true }) })
  const root = join(scratch, 'workspace'), storage = join(scratch, 'private')
  await mkdir(join(root, 'tmp'), { recursive: true })
  await mkdir(join(root, 'src'))
  await writeFile(join(root, 'tmp', 'experiment.log'), 'experiment residue\n')
  await writeFile(join(root, 'src', 'main.js'), 'export const n = 1\n')
  const config = resolveConfig({ privateStorageRoot: storage, managedRoots: ['tmp'], minAgeHours: 0, autoScan: false, valuePolicy: { discardPatterns: ['tmp/**'] } })
  return { root: await realpath(root), config, scratch, storage }
}
const context = text => ({ sources: [{ sessionId: 'primary', revision: 1, messages: [{ role: 'user', text }] }], digest: text, truncated: false })
const response = (input, category = 'disposable') => {
  const data = JSON.parse(input.prompt)
  if (data.privateTranscript && data.entries) return JSON.stringify({ preservePaths: data.entries.filter(entry => entry.path === 'tmp').map(entry => entry.path) })
  if (data.entries) return JSON.stringify({ entries: data.entries.map(entry => ({ path: entry.path, category, purpose: '实验文件', reason: '当前任务的实验输出' })) })
  return '已记录文件保护要求；请通过整理按钮确认方案。'
}
async function settle(agent) {
  while (agent.assessment.running) await agent.assessment.running
}

test('private conversation requires a capability, encrypts persistence and invalidates access on lock/restart', async t => {
  const { root, config } = await fixture(t)
  const chat = new PrivateConversation(root, config)
  await chat.init()
  assert.throws(() => chat.read('primary-session'), /解锁/)
  const unlocked = await chat.unlock('fixture-password-123')
  await chat.send(unlocked.capability, 'PRIVATE_SENTINEL keep my files', async () => 'PRIVATE_REPLY')
  const encrypted = await readFile(chat.path, 'utf8')
  assert.doesNotMatch(encrypted, /PRIVATE_SENTINEL|PRIVATE_REPLY|fixture-password|hygiene-private-/)
  assert.doesNotMatch(JSON.stringify(chat.status()), new RegExp(unlocked.capability))
  assert.equal(chat.read(unlocked.capability).messages.length, 2)
  chat.lock()
  assert.throws(() => chat.read(unlocked.capability), /解锁/)
  const restarted = new PrivateConversation(root, config)
  await restarted.init()
  await assert.rejects(restarted.unlock('incorrect-password'), /密码不正确/)
  const recovered = await restarted.unlock('fixture-password-123')
  assert.equal(recovered.messages[0].text, 'PRIVATE_SENTINEL keep my files')
  assert.throws(() => restarted.read(unlocked.capability), /解锁/)
  restarted.lock()
})

test('locking an in-flight conversation discards its late reply', async t => {
  const { root, config } = await fixture(t)
  const chat = new PrivateConversation(root, config)
  const { capability } = await chat.unlock('fixture-password-123')
  let finish, started
  const ready = new Promise(resolve => { started = resolve })
  const sending = chat.send(capability, 'Keep the experiment', () => { started(); return new Promise(resolve => { finish = resolve }) })
  await ready
  chat.lock()
  finish('LATE_PRIVATE_REPLY')
  await sending
  const restored = await chat.unlock('fixture-password-123')
  assert.equal(restored.messages.length, 1)
  chat.lock()
})

test('private storage rejects workspace paths and junction redirection', async t => {
  const { root, config, scratch } = await fixture(t)
  assert.throws(() => new PrivateConversation(root, { ...config, privateStorageRoot: join(root, 'private') }), /工作区之外/)
  const redirected = join(scratch, 'redirected')
  await symlink(root, redirected, process.platform === 'win32' ? 'junction' : 'dir')
  const chat = new PrivateConversation(root, { ...config, privateStorageRoot: join(redirected, 'secrets') })
  await assert.rejects(chat.init(), /工作区外|符号链接/)
})

test('context imports only bounded same-workspace visible messages and excludes hygiene output', async t => {
  const { root, scratch } = await fixture(t)
  const session = (id, cwd, messages) => ({ id, header: { cwd }, seq: 5, deriveMessages: () => messages })
  const messages = [
    { role: 'user', content: [{ type: 'text', text: 'Keep the experiment logs' }, { type: 'reasoning', text: 'HIDDEN_REASONING' }] },
    { role: 'assistant', source: { plugin: 'dsh-workspace-hygiene' }, content: [{ type: 'text', text: 'PRIVATE_EXCLUDED' }] },
  ]
  const sources = [session('primary', root, messages), session('outside', scratch, [{ content: [{ type: 'text', text: 'OTHER_WORKSPACE' }] }]), session('hygiene-private-secret', root, messages)]
  const result = await collectWorkspaceContext(root, sources, 'primary', 40000)
  assert.equal(result.sources.length, 1)
  assert.equal(result.sources[0].messages[0].text, 'Keep the experiment logs')
  assert.doesNotMatch(JSON.stringify(result), /HIDDEN_REASONING|PRIVATE_EXCLUDED|OTHER_WORKSPACE/)
  const bounded = await collectWorkspaceContext(root, sources, 'primary', 10)
  assert.equal(bounded.truncated, true)
  assert.equal(bounded.sources[0].messages[0].text.length, 10)
})

test('auxiliary model request is frozen, has no ordinary session ID or tools and rejects tool calls', async () => {
  let request
  const llm = { async *stream(input) { request = input; yield { type: 'text-delta', index: 0, text: 'hello' }; yield { type: 'block-end', index: 0, block: { type: 'text', text: 'hello' } }; yield { type: 'finish', reason: { kind: 'stop' } } } }
  const result = await generatePrivateResponse(llm, { provider: 'fixture', model: 'fixture' }, { system: 'private', prompt: 'PRIVATE' })
  assert.equal(result, 'hello')
  assert.equal(Object.isFrozen(request.messages[0].content), true)
  assert.equal(request.sessionId, undefined)
  assert.equal(request.tools, undefined)
  const invalid = { async *stream() { yield { type: 'tool-call-delta', index: 0, name: 'shell' } } }
  await assert.rejects(generatePrivateResponse(invalid, { provider: 'fixture', model: 'fixture' }, { system: 'private', prompt: 'private' }), /不能调用工具/)
})

test('classification uses current context, caches unchanged scans and cannot move context-preserved files', async t => {
  const { root, config } = await fixture(t)
  let source = context('This log is valuable evidence'), calls = 0
  const agent = new MaintenanceAgent(root, config, { readContext: async () => source, generate: async input => { calls++; return response(input, source.digest.includes('valuable') ? 'valuable' : 'disposable') } })
  t.after(() => agent.assessment.close())
  await agent.init(); await settle(agent)
  const first = calls
  const browse = await agent.browse({ path: 'tmp' })
  assert.equal(browse.entries[0].contextCategory, 'valuable')
  assert.equal(browse.entries[0].classificationSource, 'task-context')
  const plan = await agent.prepare()
  assert.equal(plan.proposal.selectedCount, 0)
  await settle(agent)
  assert.equal(calls, first, 'unchanged context and inventory reuse the model result')
  source = context('The failed experiment can be discarded')
  await agent.refresh(); await settle(agent)
  assert.ok(calls > first)
  assert.equal((await agent.prepare()).proposal.selectedCount, 1)
  source = context('This log is valuable evidence again')
  const executed = await agent.execute({ proposalId: agent.context.proposal.id, confirm: true })
  assert.equal(executed.phase, 'blocked')
  assert.match(executed.error, /上下文已变化/)
  assert.equal(await readFile(join(root, 'tmp', 'experiment.log'), 'utf8'), 'experiment residue\n')
  await settle(agent)
})

test('private preferences veto directory cleanup without exposing transcript to public descriptions or snapshots', async t => {
  const { root, config } = await fixture(t)
  const prompts = []
  const agent = new MaintenanceAgent(root, config, { readContext: async () => context('failed experiment'), generate: async input => { prompts.push(input); return response(input) } })
  t.after(() => { agent.assessment.close(); agent.conversation.lock() })
  await agent.init(); await settle(agent)
  const { capability } = await agent.chatUnlock({ password: 'fixture-password-123' })
  await agent.chatSend({ capability, text: 'PRIVATE_SENTINEL protect the entire tmp directory' })
  await settle(agent)
  const publicPrompts = prompts.filter(input => input.system.includes('Infer file AND directory'))
  assert.doesNotMatch(JSON.stringify(publicPrompts), /PRIVATE_SENTINEL/)
  const planned = await agent.prepare()
  assert.equal(planned.proposal.selectedCount, 0)
  assert.doesNotMatch(JSON.stringify(planned), /PRIVATE_SENTINEL|fixture-password/)
  assert.doesNotMatch(await readFile(join(root, '.dsh-hygiene', 'agent', 'context.json'), 'utf8'), /PRIVATE_SENTINEL/)
  agent.chatLock({ capability })
  await assert.rejects(agent.prepare(), /解锁/)
  await settle(agent)
})

test('automatic mode waits for contextual classification before suggesting cleanup', async t => {
  const { root, config } = await fixture(t)
  let finish
  const agent = new MaintenanceAgent(root, config, { readContext: async () => context('valuable experiment'), generate: input => new Promise(resolve => { finish = () => resolve(response(input, 'valuable')) }) })
  t.after(() => agent.assessment.close())
  await agent.init(); await agent.setMode('automatic')
  assert.equal((await agent.turnEnded()).proposal, null)
  finish(); await settle(agent)
  assert.equal(agent.snapshot().proposal, null)
  assert.equal(agent.snapshot().score.score, 100)
})

test('real worker IPC keeps private messages out of public snapshots and refuses unauthenticated chat access', async t => {
  const { root, config } = await fixture(t)
  const worker = new WorkerClient(root, config, { context: async () => context('experiment'), generate: async input => response(input) })
  t.after(() => worker.dispose())
  await worker.ready
  await assert.rejects(worker.request('chatRead', { capability: 'primary' }), /解锁/)
  const unlocked = await worker.request('chatUnlock', { password: 'fixture-password-123' })
  await worker.request('chatSend', { capability: unlocked.capability, text: 'IPC_PRIVATE_SENTINEL' })
  let chat
  for (let i = 0; i < 100; i++) { chat = await worker.request('chatRead', { capability: unlocked.capability }); if (!chat.busy && chat.messages.length === 2) break; await new Promise(resolve => setTimeout(resolve, 10)) }
  assert.equal(chat.messages.length, 2)
  const publicState = await worker.request('snapshot')
  assert.doesNotMatch(JSON.stringify(publicState), /IPC_PRIVATE_SENTINEL|hygiene-private-|capability/)
  await worker.request('chatLock', { capability: unlocked.capability })
  await assert.rejects(worker.request('chatRead', { capability: unlocked.capability }), /解锁/)
})

test('RPC errors include details required by the native DSH result schema', async () => {
  const controller = new HygieneController({}, resolveConfig({}))
  assert.deepEqual(await controller.rpc('prepare', {}), { ok: false, error: { code: 'internal', message: 'sessionId is required', details: {} } })
})

test('binary evidence is streamed independently of the reference text budget; actual text excess still fails closed', async t => {
  const { root, config } = await fixture(t)
  await writeFile(join(root, 'large.pptx'), Buffer.alloc(4096, 1))
  const evidence = await projectEvidence(root, { ...config, maxReferenceBytes: 1024 })
  assert.match(evidence.files.get('large.pptx'), /^[a-f0-9]{64}$/)
  assert.equal(evidence.texts.has('large.pptx'), false)
  await writeFile(join(root, 'oversized.txt'), 'a'.repeat(2048))
  await assert.rejects(projectEvidence(root, { ...config, maxReferenceBytes: 1024 }), /maxReferenceBytes/)
})
