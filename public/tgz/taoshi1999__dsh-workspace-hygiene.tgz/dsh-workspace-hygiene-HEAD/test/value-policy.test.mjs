import test from 'node:test'
import assert from 'node:assert/strict'
import {
  DEFAULT_VALUE_POLICY,
  VALUE_ACTIONS,
  VALUE_CLASSES,
  classifyValue,
  normalizeValuePolicy,
  projectValuePolicy,
  recommendAction,
  scoreArtifact,
  suggestOrganization,
} from '../src/value-policy.js'

test('value policy exposes conservative defaults and normalizes friendly aliases', () => {
  const policy = normalizeValuePolicy({
    keepPatterns: ['./reports/final/**', 'reports/final/**'],
    deletePatterns: ['tmp/**'],
    keepExtensions: ['.json', 'CSV'],
    deleteExtensions: ['.log'],
    organize: {
      root: 'artifacts',
      keepDirectory: 'published',
      intermediateDirectory: 'scratch',
      nameTemplate: '{date}-{stem}{ext}',
    },
    allowDelete: true,
  })

  assert.equal(DEFAULT_VALUE_POLICY.allowDelete, false)
  assert.equal(policy.allowDelete, true)
  assert.deepEqual(policy.retainPatterns, ['reports/final/**', 'reports/final/**'])
  assert.deepEqual(policy.discardPatterns, ['tmp/**'])
  assert.deepEqual(policy.retainExtensions, ['json', 'csv'])
  assert.deepEqual(policy.discardExtensions, ['log'])
  assert.equal(policy.organization.root, 'artifacts')
  assert.equal(policy.organization.retainDirectory, 'published')
  assert.equal(policy.organization.archiveDirectory, 'scratch')
  assert.equal(policy.organization.namingTemplate, '{date}-{stem}{ext}')
  assert.ok(Object.isFrozen(policy))
  assert.ok(Object.isFrozen(policy.organization))
})

test('nested policies honor top-level delete aliases and reject unsafe organization paths', () => {
  const policy = normalizeValuePolicy({
    valuePolicy: { discardPatterns: ['tmp/**'] },
    allowDelete: true,
  })
  assert.equal(policy.allowDelete, true)
  assert.deepEqual(policy.discardPatterns, ['tmp/**'])

  assert.throws(
    () => normalizeValuePolicy({ organization: { root: '../outside' } }),
    /organization\.root.*safe workspace-relative path/i,
  )
  assert.throws(
    () => normalizeValuePolicy({ organization: { deleteDirectory: '/tmp' } }),
    /organization\.deleteDirectory.*workspace-relative path/i,
  )
  assert.throws(
    () => suggestOrganization(
      { relativePath: 'tmp/file.log', action: 'archive' },
      { retainThreshold: 70, organization: { root: '../outside' } },
    ),
    /organization\.root.*workspace-relative path/i,
  )
})

test('public policy helpers normalize partial policy objects safely', () => {
  const input = { relativePath: 'tmp/partial.log', kind: 'candidate' }
  const classified = classifyValue(input, { retainThreshold: 70 })
  assert.equal(classified.recommendation, 'archive')
  assert.equal(classified.execution, 'quarantine')

  const projection = projectValuePolicy({ retainThreshold: 70 })
  assert.deepEqual(projection.retainPatterns, [])
  assert.equal(projection.retainThreshold, 70)
})

test('threshold normalization keeps delete <= archive <= retain', () => {
  const policy = normalizeValuePolicy({
    deleteThreshold: 95,
    archiveThreshold: 10,
    retainThreshold: 5,
  })
  assert.ok(policy.deleteThreshold <= policy.archiveThreshold)
  assert.ok(policy.archiveThreshold <= policy.retainThreshold)
  assert.equal(policy.deleteThreshold, 10)
  assert.equal(policy.archiveThreshold, 10)
  assert.equal(policy.retainThreshold, 10)
})

test('protected input is always retained and never scheduled for mutation', () => {
  const result = classifyValue({
    relativePath: '.env.production',
    name: '.env.production',
    kind: 'protected',
    tracked: true,
  })

  assert.equal(result.valueScore, 100)
  assert.equal(result.valueClass, 'protected')
  assert.equal(result.recommendation, 'retain')
  assert.equal(result.action, 'retain')
  assert.equal(result.execution, 'skip')
  assert.ok(result.reasons.includes('git-tracked'))
  assert.equal(result.organization.category, 'retain')
  assert.equal(result.organization.targetDirectory, 'workspace-artifacts/retained')
})

test('disabling value policy falls back to explicit review without weakening protection', () => {
  const review = classifyValue({
    relativePath: 'tmp/generated.log',
    kind: 'candidate',
    generatedPrefix: true,
  }, { enabled: false })
  assert.equal(review.valueClass, 'uncertain')
  assert.equal(review.recommendation, 'review')
  assert.equal(review.action, 'review')
  assert.equal(review.execution, 'skip')
  assert.equal(review.decisionSource, 'disabled')
  assert.deepEqual(review.reasons, ['value-policy-disabled'])

  const protectedResult = classifyValue({
    relativePath: '.env.local',
    kind: 'protected',
    tracked: true,
  }, { enabled: false })
  assert.equal(protectedResult.valueClass, 'protected')
  assert.equal(protectedResult.recommendation, 'retain')
  assert.equal(protectedResult.execution, 'skip')
})

test('explicit retain and discard rules produce explainable actions', () => {
  const policy = normalizeValuePolicy({
    retainPatterns: ['reports/final/**'],
    discardPatterns: ['tmp/**'],
  })

  const retained = classifyValue({
    relativePath: 'reports/final/summary.log',
    name: 'summary.log',
    kind: 'candidate',
    generatedPrefix: true,
  }, policy, { candidateExtensions: ['log'] })
  assert.equal(retained.valueClass, 'valuable')
  assert.equal(retained.recommendation, 'retain')
  assert.equal(retained.execution, 'skip')
  assert.equal(retained.decisionSource, 'explicit')
  assert.ok(retained.reasons.includes('explicit-retain-rule'))
  assert.equal(retained.organization.category, 'retain')

  const discarded = classifyValue({
    relativePath: 'tmp/debug.log',
    name: 'debug.log',
    kind: 'ordinary',
  }, policy)
  assert.equal(discarded.valueScore, 0)
  assert.equal(discarded.valueClass, 'disposable')
  assert.equal(discarded.recommendation, 'delete')
  // Permanent deletion is opt-in; the default execution remains reversible.
  assert.equal(discarded.execution, 'quarantine')
  assert.equal(discarded.decisionSource, 'explicit')
  assert.ok(discarded.reasons.includes('explicit-discard-rule'))
  assert.equal(discarded.organization.category, 'delete')

  const destructive = classifyValue({
    relativePath: 'tmp/debug.log',
    name: 'debug.log',
  }, { ...policy, allowDelete: true })
  assert.equal(destructive.recommendation, 'delete')
  assert.equal(destructive.execution, 'delete')
})

test('conflicting value rules fail safe to retain and expose the conflict', () => {
  const policy = normalizeValuePolicy({
    retainPatterns: ['tmp/**'],
    discardPatterns: ['tmp/maybe.log'],
  })
  const result = classifyValue({
    relativePath: 'tmp/maybe.log',
    name: 'maybe.log',
    kind: 'candidate',
  }, policy)
  assert.equal(result.recommendation, 'retain')
  assert.equal(result.valueClass, 'valuable')
  assert.equal(result.signals.conflictingRules, 0)
  assert.ok(result.reasons.includes('conflicting-retain-discard-rules'))
})

test('heuristic signals lower disposable artifacts while preserving valuable extensions', () => {
  const disposable = classifyValue({
    relativePath: 'tmp/rollout.log',
    name: 'rollout.log',
    kind: 'candidate',
    generatedPrefix: true,
    artifactDirectory: true,
    marker: true,
    ageHours: 200,
  }, {}, { candidateExtensions: ['log'] })
  assert.equal(disposable.valueScore, 0)
  assert.equal(disposable.valueClass, 'disposable')
  assert.equal(disposable.recommendation, 'delete')
  assert.equal(disposable.execution, 'quarantine')
  assert.ok(disposable.reasons.includes('generated-prefix'))
  assert.ok(disposable.reasons.includes('artifact-directory'))
  assert.ok(disposable.reasons.includes('generated-marker'))
  assert.ok(disposable.reasons.includes('older-than-one-week'))

  const valuable = classifyValue({
    relativePath: 'reports/final/metrics.json',
    name: 'metrics.json',
    ageHours: 1,
  }, { retainExtensions: ['json'] })
  // An explicit valuable extension contributes both the retain-rule and the
  // extension signal; the score is intentionally clamped to the 0–100 range.
  assert.ok(valuable.valueScore >= 70)
  assert.equal(valuable.valueClass, 'valuable')
  assert.equal(valuable.recommendation, 'retain')
  assert.equal(valuable.execution, 'skip')
  assert.ok(valuable.reasons.includes('valuable-extension:.json'))

  // A generic candidate with no strong evidence remains reviewable rather than
  // being silently discarded.
  const uncertain = classifyValue({ relativePath: 'tmp/unknown.bin', kind: 'candidate' })
  assert.equal(uncertain.valueScore, 50)
  assert.equal(uncertain.valueClass, 'intermediate')
  assert.equal(uncertain.recommendation, 'archive')
  assert.equal(uncertain.execution, 'quarantine')
})

test('organization suggestions are deterministic, grouped by action, and safe to display', () => {
  const mtimeMs = Date.parse('2025-01-02T03:04:05.000Z')
  const suggestion = suggestOrganization({
    relativePath: 'tmp/Run 1/final output.log',
    name: 'final output.log',
    mtimeMs,
    action: 'archive',
    sha256: '0123456789abcdef',
  })
  assert.equal(suggestion.enabled, true)
  assert.equal(suggestion.category, 'archive')
  assert.equal(suggestion.targetDirectory, 'workspace-artifacts/intermediate')
  assert.equal(suggestion.suggestedName, '2025-01-02-final-output.log')
  assert.equal(suggestion.suggestedPath, 'workspace-artifacts/intermediate/2025-01-02-final-output.log')
  assert.match(suggestion.reason, /group archive artifacts/)
  assert.doesNotMatch(suggestion.suggestedPath, /[\\/]{2}|\.\./)

  const custom = suggestOrganization({
    relativePath: 'tmp/result.txt',
    name: 'result.txt',
    mtimeMs,
    action: 'retain',
    sha256: 'deadbeefcafebabe',
  }, {
    organization: {
      root: 'project/artifacts',
      retainDirectory: 'published',
      namingTemplate: '{category}-{hash8}-{stem}{ext}',
    },
  })
  assert.equal(custom.targetDirectory, 'project/artifacts/published')
  assert.equal(custom.suggestedName, 'retain-deadbeef-result.txt')
  assert.equal(custom.suggestedPath, 'project/artifacts/published/retain-deadbeef-result.txt')
})

test('organization names preserve human-readable Unicode stems', () => {
  const suggestion = suggestOrganization({
    relativePath: 'scratch/训练日志.log',
    name: '训练日志.log',
    mtimeMs: Date.parse('2026-01-02T00:00:00Z'),
    action: 'archive',
  })
  assert.equal(suggestion.suggestedName, '2026-01-02-训练日志.log')
  assert.equal(suggestion.suggestedPath, 'workspace-artifacts/intermediate/2026-01-02-训练日志.log')
})

test('projected value policy is bounded and action/score aliases stay stable', () => {
  const policy = normalizeValuePolicy({
    retainPatterns: Array.from({ length: 140 }, (_, index) => `keep/${index}`),
    discardPatterns: Array.from({ length: 140 }, (_, index) => `drop/${index}`),
  })
  const projection = projectValuePolicy(policy)
  assert.equal(projection.retainPatterns.length, 100)
  assert.equal(projection.discardPatterns.length, 100)
  assert.deepEqual([...VALUE_CLASSES], ['protected', 'valuable', 'intermediate', 'disposable', 'uncertain'])
  assert.deepEqual([...VALUE_ACTIONS], ['retain', 'archive', 'delete', 'review'])

  const input = { relativePath: 'tmp/cache.log', kind: 'candidate' }
  assert.equal(scoreArtifact(input, policy), classifyValue(input, policy).valueScore)
  assert.equal(recommendAction(input, policy), classifyValue(input, policy).recommendation)
})
