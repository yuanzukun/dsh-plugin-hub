import test from 'node:test'
import assert from 'node:assert/strict'
import { access, mkdir, mkdtemp, readFile, rm, stat, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

async function loadTransactions(t) {
  try {
    return await import('../src/transaction.js')
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return undefined
    }
    throw error
  }
}

async function makeActionWorkspace(prefix = 'dsh-hygiene-value-plan-') {
  const root = await mkdtemp(join(tmpdir(), prefix))
  await mkdir(join(root, 'tmp'), { recursive: true })
  await mkdir(join(root, 'reports', 'final'), { recursive: true })
  await writeFile(join(root, 'tmp', 'drop.log'), 'disposable intermediate\n')
  await writeFile(join(root, 'reports', 'final', 'result.log'), 'valuable final report\n')
  return root
}

function actionConfig(root, valuePolicy = {}) {
  return {
    workspaceRoot: root,
    managedRoots: ['tmp', 'reports'],
    minAgeHours: 0,
    candidateExtensions: ['log'],
    candidateDirectories: ['tmp', 'reports'],
    valuePolicy: {
      retainPatterns: ['reports/final/**'],
      discardPatterns: ['tmp/**'],
      ...valuePolicy,
    },
    maxArchiveFiles: 10,
    maxArchiveBytes: 1024 * 1024,
  }
}

test('plans expose value decisions, action counts, and organization targets', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await makeActionWorkspace()
  const config = actionConfig(root)
  const plan = await tx.planWorkspace(root, config, {
    includeMedium: true,
    includeRetain: true,
    actions: ['retain', 'delete'],
  })

  assert.equal(plan.selectedCount, 2)
  assert.deepEqual(plan.actionCounts, { retain: 1, archive: 0, delete: 1, review: 0 })
  assert.ok(plan.organization['workspace-artifacts/retained'] >= 1)
  assert.ok(plan.organization['workspace-artifacts/to-delete'] >= 1)
  assert.ok(plan.valuePolicy)

  const byPath = new Map(plan.entries.map(entry => [entry.relativePath, entry]))
  const retained = byPath.get('reports/final/result.log')
  assert.ok(retained)
  assert.equal(retained.valueClass, 'valuable')
  assert.equal(retained.recommendation, 'retain')
  assert.equal(retained.action, 'retain')
  assert.equal(retained.execution, 'skip')
  assert.equal(retained.decisionSource, 'explicit')
  assert.equal(retained.organization.category, 'retain')
  assert.equal(typeof retained.valueSignals, 'object')
  assert.match(retained.organization.suggestedPath, /workspace-artifacts\/retained\//)

  const discarded = byPath.get('tmp/drop.log')
  assert.ok(discarded)
  assert.equal(discarded.valueClass, 'disposable')
  assert.equal(discarded.recommendation, 'delete')
  assert.equal(discarded.action, 'delete')
  // A delete recommendation is still reversible unless permanent deletion is
  // explicitly enabled at apply time.
  assert.equal(discarded.execution, 'quarantine')
  assert.equal(discarded.decisionSource, 'explicit')
  assert.ok(discarded.valueReasons.includes('explicit-discard-rule'))
  assert.match(discarded.organization.suggestedPath, /workspace-artifacts\/to-delete\//)
})

test('operator decisions override recommendations and are recorded in the plan', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await makeActionWorkspace('dsh-hygiene-value-override-')
  const config = actionConfig(root)
  const plan = await tx.planWorkspace(root, config, {
    includeMedium: true,
    includeRetain: true,
    actions: ['retain', 'delete'],
    decisions: {
      'tmp/drop.log': 'retain',
    },
  })
  const entry = plan.entries.find(item => item.relativePath === 'tmp/drop.log')
  assert.ok(entry)
  assert.equal(entry.recommendation, 'delete')
  assert.equal(entry.action, 'retain')
  assert.equal(entry.decisionSource, 'operator')
  assert.equal(entry.organization.category, 'retain')
  assert.deepEqual(plan.actionCounts, { retain: 2, archive: 0, delete: 0, review: 0 })
})

test('invalid operator decisions fail closed instead of falling back silently', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await makeActionWorkspace('dsh-hygiene-value-invalid-decision-')
  t.after(async () => rm(root, { recursive: true, force: true }))
  const config = actionConfig(root)
  await assert.rejects(
    tx.planWorkspace(root, config, {
      includeMedium: true,
      actions: ['retain', 'delete'],
      decisions: { 'tmp/cache.log': 'remove-forever' },
    }),
    error => error?.code === 'DECISION_ACTION_INVALID',
  )
  await assert.rejects(
    tx.planWorkspace(root, config, {
      includeMedium: true,
      actions: ['retain', 'delete'],
      decisions: { '../outside.log': 'delete' },
    }),
    error => error?.code === 'DECISION_PATH_INVALID',
  )
})

test('explicit per-path decisions include medium candidates without broadening filters', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-value-explicit-medium-'))
  t.after(async () => rm(root, { recursive: true, force: true }))
  await writeFile(join(root, 'medium.log'), 'named by the operator\n')
  const config = {
    workspaceRoot: root,
    managedRoots: ['.'],
    minAgeHours: 0,
    candidateExtensions: ['log'],
    candidateDirectories: [],
    maxArchiveFiles: 10,
    maxArchiveBytes: 1024 * 1024,
  }
  const { scanWorkspace } = await import('../src/scan.js')
  const scan = await scanWorkspace(root, config)
  assert.equal(scan.candidateCount, 1)
  assert.equal(scan.counts.candidate, 1)
  assert.equal(scan.counts.ordinary, 0)
  const plan = await tx.planWorkspace(root, config, {
    // No includeMedium/includeRetain or action allow-list is needed: an
    // explicit path decision is already an operator review.
    decisions: { 'medium.log': 'retain' },
  })
  assert.equal(plan.selectedCount, 1)
  assert.equal(plan.entries[0].relativePath, 'medium.log')
  assert.equal(plan.entries[0].action, 'retain')
  assert.equal(plan.entries[0].decisionSource, 'operator')
})

test('invalid action filters fail closed before a plan is persisted', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await makeActionWorkspace('dsh-hygiene-value-invalid-action-')
  t.after(async () => rm(root, { recursive: true, force: true }))
  await assert.rejects(
    tx.planWorkspace(root, actionConfig(root), {
      actions: ['delete', 'purge'],
    }),
    error => error?.code === 'ACTION_INVALID',
  )
})

test('apply executes retain and delete actions safely, then restore recovers quarantined files', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await makeActionWorkspace('dsh-hygiene-value-apply-')
  const config = actionConfig(root)
  const plan = await tx.planWorkspace(root, config, {
    includeMedium: true,
    includeRetain: true,
    actions: ['retain', 'delete'],
  })
  const applied = await tx.applyPlan(root, config, {
    planId: plan.planId,
    token: plan.token,
  }, {
    token: plan.token,
    confirm: true,
  })
  assert.equal(applied.status, 'completed')
  assert.equal(applied.counts.retained, 1)
  assert.equal(applied.counts.quarantined, 1)
  assert.equal(applied.counts.deleted, 0)
  await access(join(root, 'reports', 'final', 'result.log'))
  await assert.rejects(access(join(root, 'tmp', 'drop.log')))
  const archived = applied.entries.find(entry => entry.relativePath === 'tmp/drop.log')
  assert.equal(archived.status, 'quarantined')
  assert.ok(archived.archivedRelativePath)
  assert.equal(typeof archived.valueSignals, 'object')

  const restored = await tx.restoreRun(root, config, { runId: applied.runId }, { confirm: true })
  assert.equal(restored.status, 'restored')
  assert.equal(restored.restored, 1)
  assert.equal(restored.conflicts.length, 0)
  assert.equal(await readFile(join(root, 'tmp', 'drop.log'), 'utf8'), 'disposable intermediate\n')
  assert.equal(await readFile(join(root, 'reports', 'final', 'result.log'), 'utf8'), 'valuable final report\n')
})

test('permanent deletion has a separate policy and confirmation gate', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await makeActionWorkspace('dsh-hygiene-value-delete-')
  const config = actionConfig(root, { allowDelete: true })
  // Keep only the disposable path in this plan so the delete gate is easy to
  // inspect and cannot be confused with a retained entry.
  const plan = await tx.planWorkspace(root, config, {
    includeMedium: true,
    actions: ['delete'],
  })
  assert.equal(plan.selectedCount, 1)
  assert.equal(plan.entries[0].action, 'delete')

  const blocked = await tx.applyPlan(root, config, {
    planId: plan.planId,
    token: plan.token,
  }, {
    token: plan.token,
    confirm: true,
    permanentDelete: true,
  })
  assert.equal(blocked.ok, false)
  assert.equal(blocked.code, 'DELETE_CONFIRMATION_REQUIRED')
  assert.equal(blocked.deleteCount, 1)
  await access(join(root, 'tmp', 'drop.log'))

  const applied = await tx.applyPlan(root, config, {
    planId: plan.planId,
    token: plan.token,
  }, {
    token: plan.token,
    confirm: true,
    permanentDelete: true,
    confirmDelete: true,
  })
  assert.equal(applied.status, 'completed')
  assert.equal(applied.counts.deleted, 1)
  assert.equal(applied.counts.quarantined, 0)
  await assert.rejects(access(join(root, 'tmp', 'drop.log')))
  assert.equal(applied.entries[0].status, 'deleted')
  assert.equal(applied.entries[0].execution, 'delete')
  // A permanently deleted entry has no archive and therefore cannot be
  // restored; the durable run still records that fact for auditability.
  const restore = await tx.restoreRun(root, config, { runId: applied.runId }, { confirm: true })
  assert.equal(restore.status, 'restore-partial')
  assert.ok(restore.errors.some(error => error.code === 'NO_ARCHIVE'))

  const preview = await tx.restoreRun(root, config, { runId: applied.runId }, { dryRun: true })
  assert.equal(preview.ok, false)
  assert.equal(preview.unrecoverableCount, 1)
  assert.equal(preview.unrecoverable[0].code, 'NO_ARCHIVE')
})

test('default plan selection excludes retain decisions unless explicitly requested', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await makeActionWorkspace('dsh-hygiene-value-selection-')
  const config = actionConfig(root)
  const withoutRetain = await tx.planWorkspace(root, config, {
    includeMedium: true,
    actions: ['retain', 'delete'],
    includeRetain: false,
  })
  // An explicit actions list is authoritative and includes retain even when
  // includeRetain is false; this documents the precedence for callers.
  assert.equal(withoutRetain.selectedCount, 2)

  const defaults = await tx.planWorkspace(root, config, { includeMedium: true })
  assert.equal(defaults.selectedCount, 1)
  assert.equal(defaults.entries[0].action, 'delete')
})

test('organization can be disabled independently of value decisions', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await makeActionWorkspace('dsh-hygiene-value-organize-disabled-')
  const config = actionConfig(root, { organization: { enabled: false } })
  const plan = await tx.planWorkspace(root, config, {
    includeMedium: true,
    includeRetain: true,
    actions: ['retain'],
  })
  assert.equal(plan.selectedCount, 1)
  const applied = await tx.applyPlan(root, config, {
    planId: plan.planId,
    token: plan.token,
  }, {
    token: plan.token,
    confirm: true,
    organize: true,
  })
  assert.equal(applied.status, 'completed')
  assert.equal(applied.counts.organized, 0)
  assert.equal(applied.counts.retained, 1)
  await access(join(root, 'reports', 'final', 'result.log'))
})

test('restore reports retain-only runs as not restorable', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await makeActionWorkspace('dsh-hygiene-value-retain-only-')
  const config = actionConfig(root)
  const plan = await tx.planWorkspace(root, config, {
    includeMedium: true,
    includeRetain: true,
    actions: ['retain'],
  })
  assert.equal(plan.selectedCount, 1)
  const applied = await tx.applyPlan(root, config, {
    planId: plan.planId,
    token: plan.token,
  }, {
    token: plan.token,
    confirm: true,
  })
  assert.equal(applied.status, 'completed')
  assert.equal(applied.counts.retained, 1)

  const restored = await tx.restoreRun(root, config, { runId: applied.runId }, { confirm: true })
  assert.equal(restored.ok, false)
  assert.equal(restored.code, 'RUN_NOT_RESTORABLE')
  assert.equal(restored.status, 'completed')

  const preview = await tx.restoreRun(root, config, { runId: applied.runId }, { dryRun: true })
  assert.equal(preview.ok, false)
  assert.equal(preview.code, 'RUN_NOT_RESTORABLE')
  assert.equal(preview.status, 'completed')
})

test('organize executes the suggested move and keeps organized output out of rescans', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await makeActionWorkspace('dsh-hygiene-value-organize-')
  const config = actionConfig(root)
  const plan = await tx.planWorkspace(root, config, {
    includeMedium: true,
    includeRetain: true,
    actions: ['retain'],
  })
  const applied = await tx.applyPlan(root, config, {
    planId: plan.planId,
    token: plan.token,
  }, {
    token: plan.token,
    confirm: true,
    organize: true,
  })
  assert.equal(applied.status, 'completed')
  assert.equal(applied.counts.organized, 1)
  const moved = applied.entries[0]
  assert.equal(moved.status, 'organized')
  assert.ok(moved.organizedRelativePath)
  await assert.rejects(access(join(root, 'reports', 'final', 'result.log')))
  await access(join(root, moved.organizedRelativePath))

  const scan = await (await import('../src/scan.js')).scanWorkspace(root, config)
  assert.equal(scan.candidates.some(item => item.relativePath === moved.organizedRelativePath), false)
})
