import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

async function loadModules(t) {
  try {
    return {
      scan: await import('../src/scan.js'),
      transaction: await import('../src/transaction.js'),
    }
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return undefined
    }
    throw error
  }
}

function config(root, valuePolicy = {}) {
  return {
    workspaceRoot: root,
    managedRoots: ['tmp', 'inputs'],
    minAgeHours: 0,
    // Keep the test fixtures ordinary unless a value rule or explicit
    // decision promotes them. The defaults otherwise treat `tmp` as an
    // artifact directory.
    candidateExtensions: ['log'],
    candidateDirectories: ['generated'],
    valuePolicy,
    maxArchiveFiles: 20,
    maxArchiveBytes: 1024 * 1024,
  }
}

test('explicit retain/discard rules promote ordinary files into the scan', async (t) => {
  const modules = await loadModules(t)
  if (!modules) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-explicit-rule-'))
  t.after(() => rm(root, { recursive: true, force: true }))
  await mkdir(join(root, 'tmp'), { recursive: true })
  await writeFile(join(root, 'tmp', 'valuable.json'), 'durable result\n')
  await writeFile(join(root, 'tmp', 'discard.json'), 'throwaway result\n')

  const scan = await modules.scan.scanWorkspace(root, config(root, {
    retainPatterns: ['tmp/valuable.json'],
    discardPatterns: ['tmp/discard.json'],
  }))
  const byPath = new Map(scan.candidates.map(item => [item.relativePath, item]))
  assert.equal(byPath.get('tmp/valuable.json')?.action, 'retain')
  assert.equal(byPath.get('tmp/discard.json')?.action, 'delete')
  assert.equal(byPath.get('tmp/valuable.json')?.confidence, 'high')
  assert.equal(byPath.get('tmp/discard.json')?.confidence, 'high')
  assert.equal(byPath.get('tmp/valuable.json')?.selectionReason, 'explicit-value-rule')

  const explained = await modules.scan.explainPath(root, 'tmp/valuable.json', config(root, {
    retainPatterns: ['tmp/valuable.json'],
  }))
  assert.equal(explained.kind, 'candidate')
  assert.equal(explained.eligible, true)
  assert.equal(explained.confidence, 'high')
  assert.equal(explained.selectionReason, 'explicit-value-rule')
})

test('a per-path decision can plan an ordinary file without include flags', async (t) => {
  const modules = await loadModules(t)
  if (!modules) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-explicit-decision-'))
  t.after(() => rm(root, { recursive: true, force: true }))
  await mkdir(join(root, 'inputs'), { recursive: true })
  await writeFile(join(root, 'inputs', 'manual.bin'), 'operator selected\n')

  const plan = await modules.transaction.planWorkspace(root, config(root), {
    // No includeMedium/includeRetain/actions option is required: an explicit
    // decision is an operator review and is selected ahead of heuristics.
    decisions: { 'inputs/manual.bin': 'retain' },
  })
  assert.equal(plan.selectedCount, 1)
  assert.equal(plan.entries[0].relativePath, 'inputs/manual.bin')
  assert.equal(plan.entries[0].action, 'retain')
  assert.equal(plan.entries[0].decisionSource, 'operator')
  assert.ok(plan.entries[0].reasons.includes('operator-decision'))
})

test('explicit rules and decisions cannot promote protected paths', async (t) => {
  const modules = await loadModules(t)
  if (!modules) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-explicit-protected-'))
  t.after(() => rm(root, { recursive: true, force: true }))
  await mkdir(join(root, 'tmp'), { recursive: true })
  await writeFile(join(root, 'tmp', 'credentials.log'), 'secret\n')
  await writeFile(join(root, 'tmp', 'source.txt'), 'source\n')

  const scan = await modules.scan.scanWorkspace(root, config(root, {
    discardPatterns: ['tmp/**'],
  }))
  assert.equal(scan.candidates.some(item => item.relativePath === 'tmp/credentials.log'), false)
  assert.equal(scan.candidates.some(item => item.relativePath === 'tmp/source.txt'), false)

  const plan = await modules.transaction.planWorkspace(root, config(root, {
    discardPatterns: ['tmp/**'],
  }), {
    decisions: {
      'tmp/credentials.log': 'delete',
      'tmp/source.txt': 'delete',
    },
  })
  assert.equal(plan.selectedCount, 0)
  assert.equal(plan.warnings.length, 2)
  assert.ok(plan.warnings.every(warning => /protected|managed roots/i.test(warning)))
})
