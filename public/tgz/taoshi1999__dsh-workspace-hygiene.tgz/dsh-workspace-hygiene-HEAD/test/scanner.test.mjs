import { testSymlink } from './symlink-helper.mjs'
import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdir, mkdtemp, unlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  ignorePatternNames,
  isIgnored,
  loadIgnorePatterns,
  MAX_IGNORE_FILE_BYTES,
} from '../src/ignore.js'

test('hygieneignore recursive globs match zero or more directory levels', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-ignore-'))
  await writeFile(join(root, '.hygieneignore'), [
    'logs/**/checkpoints/**',
    'outputs/**/checkpoints/**',
  ].join('\n'))
  const patterns = await loadIgnorePatterns(root)
  assert.equal(isIgnored('logs/checkpoints/latest.pt', patterns), true)
  assert.equal(isIgnored('logs/run-1/checkpoints/latest.pt', patterns), true)
  assert.equal(isIgnored('outputs/checkpoints/latest.pt', patterns), true)
  assert.equal(isIgnored('outputs/run-1/checkpoints/latest.pt', patterns), true)
  assert.equal(isIgnored('logs/run-1/rollout/latest.pt', patterns), false)
})

test('hygieneignore directory patterns with a trailing slash cover descendants', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-ignore-dir-'))
  await writeFile(join(root, '.hygieneignore'), [
    'logs/',
    'outputs/**/checkpoints/',
  ].join('\n'))
  const patterns = await loadIgnorePatterns(root)
  assert.equal(isIgnored('logs', patterns), true)
  assert.equal(isIgnored('logs/run-1/output.log', patterns), true)
  assert.equal(isIgnored('outputs/checkpoints', patterns), true)
  assert.equal(isIgnored('outputs/run-1/checkpoints/latest.pt', patterns), true)
  assert.equal(isIgnored('outputs/run-1/rollout/latest.pt', patterns), false)
})

test('hygieneignore rejects external symlinks and oversized policy files', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-ignore-safety-'))
  const outside = await mkdtemp(join(tmpdir(), 'dsh-hygiene-ignore-outside-'))
  const outsideFile = join(outside, 'secrets.txt')
  await writeFile(outsideFile, 'SECRET_SENTINEL\npassword=do-not-read\n')
  if (!await testSymlink(t, outsideFile, join(root, '.hygieneignore'))) return
  await assert.rejects(
    () => loadIgnorePatterns(root),
    (error) => error?.code === 'SYMLINK_REJECTED',
  )

  await unlink(join(root, '.hygieneignore'))
  await writeFile(join(root, '.hygieneignore'), 'x'.repeat(MAX_IGNORE_FILE_BYTES + 1))
  await assert.rejects(
    () => loadIgnorePatterns(root),
    (error) => error?.code === 'IGNORE_FILE_TOO_LARGE',
  )
})

test('hygieneignore rejects non-files, path traversal, and symlinked parents', async (t) => {
  const directoryRoot = await mkdtemp(join(tmpdir(), 'dsh-hygiene-ignore-type-'))
  await mkdir(join(directoryRoot, '.hygieneignore'))
  await assert.rejects(
    () => loadIgnorePatterns(directoryRoot),
    (error) => error?.code === 'IGNORE_FILE_REJECTED' && /not a regular file/i.test(error.message),
  )

  const escapeRoot = await mkdtemp(join(tmpdir(), 'dsh-hygiene-ignore-path-'))
  await assert.rejects(
    () => loadIgnorePatterns(escapeRoot, '../outside.ignore'),
    (error) => ['IGNORE_PATH_INVALID', 'PATH_ESCAPE'].includes(error?.code),
  )

  const outside = await mkdtemp(join(tmpdir(), 'dsh-hygiene-ignore-parent-'))
  await writeFile(join(outside, 'policy.ignore'), 'outside-secret-pattern\n')
  if (!await testSymlink(t, outside, join(escapeRoot, 'external'))) return
  await assert.rejects(
    () => loadIgnorePatterns(escapeRoot, 'external/policy.ignore'),
    (error) => error?.code === 'SYMLINK_REJECTED' || error?.code === 'PATH_ESCAPE',
  )
})

test('ignore metadata projection stays bounded', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-ignore-bounded-'))
  await writeFile(join(root, '.hygieneignore'), Array.from({ length: 150 }, (_, index) => `artifact-${index}.log`).join('\n'))
  const patterns = await loadIgnorePatterns(root)
  const names = ignorePatternNames(patterns)
  assert.equal(names.length, 101)
  assert.match(names.at(-1), /50 more ignore patterns/)
})

test('scanner is bounded, deterministic, and skips symlinks/protected names', async (t) => {
  let scanWorkspace
  try {
    ({ scanWorkspace } = await import('../src/scan.js'))
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return
    }
    throw error
  }
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-scan-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  await mkdir(join(root, 'src'), { recursive: true })
  await writeFile(join(root, 'tmp', 'agent.log'), 'generated intermediate log\n')
  await writeFile(join(root, '.env'), 'DO_NOT_TOUCH=1\n')
  await writeFile(join(root, 'src', 'main.js'), 'export default 1\n')
  if (!await testSymlink(t, join(root, 'tmp', 'agent.log'), join(root, 'tmp', 'link.log'))) return
  const scan = await scanWorkspace(root, {
    stateDir: '.dsh-hygiene',
    minAgeHours: 0,
    maxScanFiles: 100,
    resultLimit: 10,
    candidateExtensions: ['log'],
    candidateDirectories: ['tmp'],
    protectedDirectories: ['src', '.git'],
    protectedNames: ['.env'],
  })
  assert.equal(scan.root, root)
  assert.equal(scan.skippedSymlinks, 1)
  assert.ok(scan.candidates.some((item) => item.relativePath === 'tmp/agent.log'))
  assert.ok(!scan.candidates.some((item) => item.relativePath.includes('link.log')))
  assert.ok(!scan.candidates.some((item) => item.relativePath === '.env'))
  assert.ok(!scan.candidates.some((item) => item.relativePath === 'src/main.js'))
})

test('explainPath reports policy reasons without moving a file', async (t) => {
  let explainPath
  try {
    ({ explainPath } = await import('../src/scan.js'))
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return
    }
    throw error
  }
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-explain-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  await writeFile(join(root, 'tmp', 'trace.log'), 'temporary\n')
  const candidate = await explainPath(root, 'tmp/trace.log', { managedRoots: ['tmp'], minAgeHours: 0 })
  assert.equal(candidate.eligible, true)
  assert.ok(candidate.reasons.includes('disposable-extension:.log'))
  const outside = await explainPath(root, 'notes.txt', { managedRoots: ['tmp'], minAgeHours: 0 })
  assert.equal(outside.managed, false)
  assert.equal(outside.protected, true)
  assert.ok(outside.reasons.includes('outside-managed-roots'))

  const missing = await explainPath(root, 'tmp/missing.log', { managedRoots: ['tmp'], minAgeHours: 0 })
  assert.equal(missing.exists, false)
  assert.equal(missing.eligible, false)
})

test('explainPath rejects a regular file reached through an external symlinked parent', async (t) => {
  let explainPath
  try {
    ({ explainPath } = await import('../src/scan.js'))
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return
    }
    throw error
  }
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-explain-escape-'))
  const outside = await mkdtemp(join(tmpdir(), 'dsh-hygiene-explain-outside-'))
  await writeFile(join(outside, 'secret.log'), 'outside\n')
  if (!await testSymlink(t, outside, join(root, 'tmp'))) return
  const result = await explainPath(root, 'tmp/secret.log', { managedRoots: ['tmp'], minAgeHours: 0 })
  assert.equal(result.protected, true)
  assert.equal(result.managed, false)
  assert.ok(result.reasons.includes('path-escape'))

  const missing = await explainPath(root, 'tmp/missing.log', { managedRoots: ['tmp'], minAgeHours: 0 })
  assert.equal(missing.protected, true)
  assert.equal(missing.managed, false)
  assert.ok(missing.reasons.includes('path-escape'))
})

test('an explicitly managed hidden root can contain disposable artifacts', async (t) => {
  let scanWorkspace
  try {
    ({ scanWorkspace } = await import('../src/scan.js'))
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return
    }
    throw error
  }
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-hidden-managed-'))
  await mkdir(join(root, '.dsh', 'ephemeral'), { recursive: true })
  await writeFile(join(root, '.dsh', 'ephemeral', 'rollout.log'), 'intermediate\n')
  const scan = await scanWorkspace(root, {
    managedRoots: ['.dsh/ephemeral'],
    minAgeHours: 0,
    candidateExtensions: ['log'],
  })
  assert.ok(scan.candidates.some((item) => item.relativePath === '.dsh/ephemeral/rollout.log'))
})

test('default scope does not descend into hidden or protected trees', async (t) => {
  let scanWorkspace
  try {
    ({ scanWorkspace } = await import('../src/scan.js'))
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return
    }
    throw error
  }
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-private-tree-'))
  await mkdir(join(root, '.private'), { recursive: true })
  await mkdir(join(root, 'src'), { recursive: true })
  await writeFile(join(root, '.private', 'secret.log'), 'do not read\n')
  await writeFile(join(root, 'src', 'build.log'), 'source tree\n')
  await writeFile(join(root, 'visible.log'), 'visible artifact\n')

  const scan = await scanWorkspace(root, {
    minAgeHours: 0,
    candidateExtensions: ['log'],
    candidateDirectories: [],
    protectedDirectories: ['src'],
  })

  assert.ok(scan.candidates.some((item) => item.relativePath === 'visible.log'))
  assert.ok(!scan.candidates.some((item) => item.relativePath.startsWith('.private/')))
  assert.ok(!scan.candidates.some((item) => item.relativePath.startsWith('src/')))
  // The bounded inventory should not even count files in skipped trees.
  assert.equal(scan.totalFiles, 1)
})

test('scanner skips POSIX filenames that are ambiguous across path platforms', async (t) => {
  if (process.platform === 'win32') {
    t.skip('Windows treats backslashes as path separators')
    return
  }
  let scanWorkspace
  try {
    ({ scanWorkspace } = await import('../src/scan.js'))
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return
    }
    throw error
  }
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-backslash-name-'))
  await writeFile(join(root, 'odd\\name.log'), 'ambiguous\n')
  await writeFile(join(root, 'C:artifact.log'), 'drive-like\n')
  const scan = await scanWorkspace(root, { minAgeHours: 0, candidateExtensions: ['log'] })
  assert.equal(scan.candidateCount, 0)
  assert.equal(scan.warnings.filter((warning) => warning.includes('ambiguous path name')).length, 2)
})

test('scanner protects credential names and key material even with permissive overrides', async (t) => {
  let scanWorkspace
  try {
    ({ scanWorkspace } = await import('../src/scan.js'))
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return
    }
    throw error
  }
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-secrets-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  await writeFile(join(root, 'tmp', 'credentials.log'), 'secret material\n')
  await writeFile(join(root, 'tmp', 'server.pem'), '-----BEGIN PRIVATE KEY-----\n')
  await writeFile(join(root, 'tmp', 'ordinary.log'), 'generated intermediate\n')
  const scan = await scanWorkspace(root, {
    managedRoots: ['tmp'],
    minAgeHours: 0,
    protectedNames: [],
    protectedExtensions: [],
    candidateExtensions: ['log', 'pem'],
    candidateDirectories: ['tmp'],
  })
  assert.ok(scan.candidates.some((item) => item.relativePath === 'tmp/ordinary.log'))
  assert.ok(!scan.candidates.some((item) => item.relativePath === 'tmp/credentials.log'))
  assert.ok(!scan.candidates.some((item) => item.relativePath === 'tmp/server.pem'))
})
