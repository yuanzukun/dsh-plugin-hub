import test from 'node:test'
import assert from 'node:assert/strict'
import { resolve } from 'node:path'
import { isInside, safeRelativePath } from '../src/path-utils.js'
import { assertArchiveRoot, assertManagedPath, isProtectedRelativePath, policyFingerprint } from '../src/policy.js'
import { archiveRootFor, Config, resolveConfig } from '../src/config.js'

test('relative-path guard rejects POSIX, UNC, drive and mixed-separator traversal', () => {
  for (const value of ['../outside', '..\\outside', 'a/../../outside', '/etc/passwd', '\\\\server\\share', 'C:\\outside', 'C:outside']) {
    assert.throws(() => safeRelativePath(value), /(?:relative|absolute|invalid)/i, value)
  }
  assert.equal(safeRelativePath('tmp\\nested\\file.log'), 'tmp/nested/file.log')
  assert.equal(safeRelativePath('./tmp/./nested/file.log'), 'tmp/nested/file.log')
})

test('managed-path guard keeps lexical paths inside the workspace', () => {
  assert.equal(isInside('/workspace', '/workspace/tmp/a.log'), true)
  assert.equal(isInside('/workspace', '/workspace/../outside'), false)
  assert.throws(() => assertManagedPath('/workspace', '../outside.log', { managedRoots: [] }))
  assert.equal(isProtectedRelativePath('.env', { protectedNames: [] }), true)
  assert.deepEqual(resolveConfig({ managedRoots: ['tmp\\'] }).managedRoots, ['tmp'])
  assert.deepEqual(resolveConfig({ managedRoots: ['.'] }).managedRoots, [])
  assert.throws(() => resolveConfig({ managedRoots: ['../outside'] }), /managedRoots/i)
  assert.throws(() => resolveConfig({ managedRoots: ['/outside'] }), /managedRoots/i)
  assert.throws(() => resolveConfig({ stateDir: '.' }), /stateDir/i)
  const relativeArchiveConfig = resolveConfig({ archiveRoot: 'quarantine' })
  assert.equal(relativeArchiveConfig.archiveRoot, 'quarantine')
  assert.equal(archiveRootFor('/workspace/project', relativeArchiveConfig), resolve('/workspace/project/quarantine'))
  assert.throws(() => resolveConfig({ archiveRoot: '../quarantine' }), /archiveRoot/i)
  assert.throws(() => resolveConfig({ archiveRoot: 'nested/../../quarantine' }), /archiveRoot/i)
  // The metadata catalog must never double as an archive destination: doing
  // so would put source bytes under workspace-artifacts and violate the
  // metadata-only contract before an apply operation even starts.
  assert.throws(() => resolveConfig({ archiveRoot: 'workspace-artifacts' }), /catalogRoot cannot overlap archiveRoot/i)
  assert.throws(() => archiveRootFor('/workspace/project', { archiveRoot: '../quarantine' }), /archiveRoot/i)
  assert.equal(resolveConfig({
    valuePolicy: { discardPatterns: ['tmp/**'] },
    allowDelete: true,
  }).valuePolicy.allowDelete, true)
  assert.throws(() => resolveConfig({
    managedRoots: ['workspace-artifacts'],
  }), /organization\.root.*overlap managedRoots/i)
})

test('credential-looking names and key/certificate extensions stay hard-protected', () => {
  const permissive = {
    managedRoots: ['tmp'],
    protectedNames: [],
    protectedExtensions: [],
    candidateExtensions: ['log', 'pem', 'key', 'p12'],
  }
  for (const relative of [
    'tmp/credentials.yaml',
    'tmp/my_secret.log',
    'tmp/private.pem',
    'tmp/server.KEY',
    'tmp/bundle.p12',
    'tmp/private.pem.bak',
  ]) {
    assert.equal(isProtectedRelativePath(relative, permissive), true, relative)
    assert.throws(() => assertManagedPath('/workspace', relative, permissive), /protected/i)
  }
  const baseline = policyFingerprint(permissive)
  const changed = policyFingerprint({ ...permissive, protectedExtensions: ['asc'] })
  assert.notEqual(baseline, changed)
})

test('common ecosystem lockfiles stay protected in managed roots', () => {
  const permissive = {
    managedRoots: ['tmp'],
    protectedNames: [],
    protectedExtensions: [],
    candidateExtensions: ['log', 'yaml', 'json'],
  }
  for (const relative of [
    'tmp/uv.lock',
    'tmp/Gemfile.lock',
    'tmp/terraform.lock.hcl',
    'tmp/packages.lock.json',
  ]) {
    assert.equal(isProtectedRelativePath(relative, permissive), true, relative)
    assert.throws(() => assertManagedPath('/workspace', relative, permissive), /protected/i)
  }
})

test('Schemastery config rejects invalid maintenance budgets at load time', () => {
  assert.equal(Config({ maxArchiveFiles: 3 }).maxArchiveFiles, 3)
  assert.throws(() => Config({ maxArchiveFiles: 0 }), /expected number >= 1/i)
  assert.throws(() => Config({ autoScanEveryTurns: 1.5 }), /multiple of 1/i)
  assert.throws(() => Config({ minAgeHours: -1 }), /expected number >= 0/i)
})

test('archive root cannot contain or overlap the workspace sources', () => {
  const root = '/workspace/project'
  assert.throws(() => assertArchiveRoot(root, '/workspace'), (error) => (
    error.code === 'ARCHIVE_ROOT_INVALID' && /contain the workspace/i.test(error.message)
  ))
  assert.throws(() => assertArchiveRoot(root, '/workspace/project/tmp/archive', { managedRoots: ['tmp'] }), (error) => (
    error.code === 'ARCHIVE_ROOT_INVALID' && /overlaps managed root/i.test(error.message)
  ))
  assert.throws(() => assertArchiveRoot(root, '/workspace/project', { managedRoots: ['tmp'] }), (error) => (
    error.code === 'ARCHIVE_ROOT_INVALID' && /workspace root/i.test(error.message)
  ))
  assert.throws(() => assertArchiveRoot(root, '/workspace/project/archive', { managedRoots: ['archive/data'] }), (error) => (
    error.code === 'ARCHIVE_ROOT_INVALID' && /overlaps managed root/i.test(error.message)
  ))
  assert.equal(assertArchiveRoot(root, '/var/tmp/dsh-archive', { managedRoots: ['tmp'] }), resolve('/var/tmp/dsh-archive'))
})
