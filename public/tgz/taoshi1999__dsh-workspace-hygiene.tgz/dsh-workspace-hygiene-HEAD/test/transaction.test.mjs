import { testSymlink } from './symlink-helper.mjs'
import test from 'node:test'
import assert from 'node:assert/strict'
import { access, lstat, mkdir, mkdtemp, readFile, rename, unlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

async function loadTransactions(t) {
  try {
    return await import('../src/transaction.js')
  } catch (error) {
    if (error?.code === 'ERR_MODULE_NOT_FOUND') {
      t.skip(`optional Harness dependency is not installed: ${error.message}`)
      return undefined
    }
    throw error
  }
}

test('plan → confirmation → quarantine → restore is reversible', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-tx-'))
  await mkdir(join(root, 'scratch'), { recursive: true })
  const source = join(root, 'scratch', 'old.log')
  await writeFile(source, 'temporary artifact\n')
  const config = {
    workspaceRoot: root,
    managedRoots: ['scratch'],
    minAgeHours: 0,
    maxArchiveFiles: 10,
    maxArchiveBytes: 1024 * 1024,
  }
  const plan = await tx.planWorkspace(root, config, { includeMedium: true })
  assert.equal(plan.selectedCount, 1)
  assert.ok(plan.token)
  const blocked = await tx.applyPlan(root, config, { planId: plan.planId, token: plan.token }, { token: plan.token })
  assert.equal(blocked.requiresConfirmation, true)
  const applied = await tx.applyPlan(root, config, { planId: plan.planId, token: plan.token }, {
    token: plan.token,
    confirm: true,
  })
  assert.equal(applied.status, 'completed')
  await assert.rejects(access(source))
  const archivedSummary = await tx.status(root, config)
  assert.equal(archivedSummary.counts.archivedFiles, 1)
  const restored = await tx.restoreRun(root, config, { runId: applied.runId })
  assert.equal(restored.status, 'restored')
  assert.equal(await readFile(source, 'utf8'), 'temporary artifact\n')
  const summary = await tx.status(root, config)
  assert.equal(summary.counts.archivedFiles, 0)
})

test('changed files are rejected at apply time', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-stale-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  const source = join(root, 'tmp', 'stale.log')
  await writeFile(source, 'before\n')
  const config = { workspaceRoot: root, minAgeHours: 0 }
  const plan = await tx.planWorkspace(root, config, { includeMedium: true })
  await writeFile(source, 'after\n')
  const result = await tx.applyPlan(root, config, { planId: plan.planId, token: plan.token }, {
    token: plan.token,
    confirm: true,
  })
  assert.equal(result.status, 'failed')
  assert.ok(result.errors.some((item) => item.code === 'SOURCE_CHANGED'))
  const preview = await tx.restoreRun(root, config, { runId: result.runId }, { dryRun: true })
  assert.equal(preview.ok, false)
  assert.equal(preview.unrecoverableCount, 1)
  assert.equal(preview.unrecoverable[0].status, 'failed')
  assert.equal(preview.unrecoverable[0].code, 'NO_ARCHIVE')
  const restored = await tx.restoreRun(root, config, { runId: result.runId }, { confirm: true })
  assert.equal(restored.status, 'restore-partial')
  assert.equal(restored.ok, false)
  assert.ok(restored.errors.some((item) => item.code === 'NO_ARCHIVE'))
})

test('dry-run previews do not consume a plan or move files', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-dry-run-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  const source = join(root, 'tmp', 'preview.log')
  await writeFile(source, 'preview\n')
  const config = { workspaceRoot: root, managedRoots: ['tmp'], minAgeHours: 0 }
  const plan = await tx.planWorkspace(root, config, { includeMedium: true })
  const preview = await tx.applyPlan(root, config, { planId: plan.planId, token: plan.token }, {
    token: plan.token,
    dryRun: true,
  })
  assert.equal(preview.status, 'dry-run')
  assert.equal(await readFile(source, 'utf8'), 'preview\n')
  const applied = await tx.applyPlan(root, config, { planId: plan.planId, token: plan.token }, {
    token: plan.token,
    confirm: true,
  })
  const restorePreview = await tx.restoreRun(root, config, { runId: applied.runId }, { dryRun: true })
  assert.equal(restorePreview.dryRun, true)
  assert.equal(restorePreview.pendingCount, 1)
  assert.equal(await readFile(source, 'utf8').catch(() => ''), '')
})

test('dry-run records are not presented as restorable runs', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-dry-run-restore-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  await writeFile(join(root, 'tmp', 'preview.log'), 'preview\n')
  const config = { workspaceRoot: root, managedRoots: ['tmp'], minAgeHours: 0 }
  const plan = await tx.planWorkspace(root, config, { includeMedium: true })
  const preview = await tx.applyPlan(root, config, { planId: plan.planId, token: plan.token }, {
    token: plan.token,
    dryRun: true,
  })
  const restore = await tx.restoreRun(root, config, { runId: preview.runId }, { confirm: true })
  assert.equal(restore.ok, false)
  assert.equal(restore.code, 'RUN_NOT_RESTORABLE')
  assert.equal(restore.status, 'dry-run')
})

test('status counts archives left by partial runs', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-status-partial-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  const first = join(root, 'tmp', 'first.log')
  const second = join(root, 'tmp', 'second.log')
  await writeFile(first, 'first\n')
  await writeFile(second, 'second-before\n')
  const config = { workspaceRoot: root, managedRoots: ['tmp'], minAgeHours: 0 }
  const plan = await tx.planWorkspace(root, config, { includeMedium: true })
  assert.equal(plan.selectedCount, 2)
  await writeFile(second, 'second-after\n')
  const applied = await tx.applyPlan(root, config, { planId: plan.planId, token: plan.token }, {
    token: plan.token,
    confirm: true,
  })
  assert.equal(applied.status, 'partial')
  const summary = await tx.status(root, config)
  assert.equal(summary.counts.archivedFiles, 1)
  assert.ok(summary.counts.archivedBytes > 0)
})

test('restore rejects a source path redirected outside the workspace', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-restore-escape-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  const source = join(root, 'tmp', 'escape.log')
  await writeFile(source, 'inside\n')
  const config = { workspaceRoot: root, managedRoots: ['tmp'], minAgeHours: 0 }
  const plan = await tx.planWorkspace(root, config, { includeMedium: true })
  const applied = await tx.applyPlan(root, config, { planId: plan.planId, token: plan.token }, {
    token: plan.token,
    confirm: true,
  })
  assert.equal(applied.status, 'completed')
  await rename(join(root, 'tmp'), join(root, 'tmp-removed'))
  const outside = await mkdtemp(join(tmpdir(), 'dsh-hygiene-outside-'))
  await mkdir(join(outside, 'tmp'), { recursive: true })
  await writeFile(join(outside, 'tmp', 'escape.log'), 'outside\n')
  // Point the managed directory at an external directory that contains the
  // same relative leaf. This exercises the realpath boundary check (rather
  // than merely the missing-parent/symlink-ancestor guard).
  if (!await testSymlink(t, join(outside, 'tmp'), join(root, 'tmp'))) return
  const restored = await tx.restoreRun(root, config, { runId: applied.runId }, { confirm: true })
  assert.equal(restored.ok, false)
  const restoreIssues = [...(restored.errors ?? []), ...(restored.conflicts ?? [])]
  assert.ok(restoreIssues.some((item) => (
    item.code === 'PATH_ESCAPE'
    || item.code === 'TARGET_EXISTS'
    || item.code === 'SYMLINK_CONFLICT'
    || item.code === 'SYMLINK_REJECTED'
  )))
  assert.equal(await readFile(join(outside, 'tmp', 'escape.log'), 'utf8'), 'outside\n')
  await unlink(join(root, 'tmp'))
})

test('restore rechecks policy before honoring a tampered run target', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-restore-policy-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  await mkdir(join(root, '.git'), { recursive: true })
  const source = join(root, 'tmp', 'policy.log')
  await writeFile(source, 'protected target test\n')
  const config = { workspaceRoot: root, managedRoots: ['tmp'], minAgeHours: 0 }
  const plan = await tx.planWorkspace(root, config, { includeMedium: true })
  const applied = await tx.applyPlan(root, config, { planId: plan.planId, token: plan.token }, {
    token: plan.token,
    confirm: true,
  })
  assert.equal(applied.status, 'completed')

  const runPath = join(root, '.dsh-hygiene', 'runs', `${applied.runId}.json`)
  const run = JSON.parse(await readFile(runPath, 'utf8'))
  run.entries[0].relativePath = '.git/should-not-be-restored'
  await writeFile(runPath, `${JSON.stringify(run, null, 2)}\n`)

  const restored = await tx.restoreRun(root, config, { runId: applied.runId }, { confirm: true })
  assert.equal(restored.ok, false)
  assert.ok(restored.errors.some((item) => item.code === 'PATH_POLICY_REJECTED'))
  await assert.rejects(access(join(root, '.git', 'should-not-be-restored')))
  await assert.rejects(access(source))
})

test('state and archive symlinks fail closed before any write', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-state-link-'))
  const outside = await mkdtemp(join(tmpdir(), 'dsh-hygiene-state-outside-'))
  if (!await testSymlink(t, outside, join(root, '.dsh-hygiene'))) return
  await assert.rejects(
    tx.planWorkspace(root, { managedRoots: [], minAgeHours: 0 }),
    (error) => error.code === 'SYMLINK_REJECTED',
  )
  await unlink(join(root, '.dsh-hygiene'))

  if (!await testSymlink(t, outside, join(root, 'archive-link'))) return
  await assert.rejects(
    tx.planWorkspace(root, { archiveRoot: 'archive-link', minAgeHours: 0 }),
    (error) => error.code === 'SYMLINK_REJECTED',
  )
  await unlink(join(root, 'archive-link'))
})

test('nested plan/run state directories reject symlink redirection', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-nested-state-link-'))
  const outside = await mkdtemp(join(tmpdir(), 'dsh-hygiene-nested-state-outside-'))
  await mkdir(join(root, '.dsh-hygiene'), { recursive: true })
  if (!await testSymlink(t, outside, join(root, '.dsh-hygiene', 'plans'))) return
  await assert.rejects(
    tx.status(root, { minAgeHours: 0 }),
    (error) => error.code === 'SYMLINK_REJECTED',
  )
  await assert.rejects(
    tx.planWorkspace(root, { minAgeHours: 0 }),
    (error) => error.code === 'SYMLINK_REJECTED',
  )
  const rootWithRunsLink = await mkdtemp(join(tmpdir(), 'dsh-hygiene-runs-link-'))
  const stateWithRunsLink = join(rootWithRunsLink, '.dsh-hygiene')
  await mkdir(stateWithRunsLink, { recursive: true })
  if (!await testSymlink(t, outside, join(stateWithRunsLink, 'runs'))) return
  await assert.rejects(
    tx.planWorkspace(rootWithRunsLink, { minAgeHours: 0 }),
    (error) => error.code === 'SYMLINK_REJECTED',
  )
})

test('manifest symlinks cannot redirect audit writes', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-manifest-link-'))
  const outside = await mkdtemp(join(tmpdir(), 'dsh-hygiene-manifest-outside-'))
  const stateRoot = join(root, '.dsh-hygiene')
  await mkdir(join(stateRoot, 'plans'), { recursive: true })
  await mkdir(join(stateRoot, 'runs'), { recursive: true })
  const outsideManifest = join(outside, 'manifest.jsonl')
  await writeFile(outsideManifest, 'sentinel\n')
  if (!await testSymlink(t, outsideManifest, join(stateRoot, 'manifest.jsonl'))) return
  await assert.rejects(
    tx.planWorkspace(root, { managedRoots: [], minAgeHours: 0 }),
    (error) => error.code === 'SYMLINK_REJECTED',
  )
  assert.equal(await readFile(outsideManifest, 'utf8'), 'sentinel\n')
})

test('standalone workspace lock rejects a symlinked state root', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-lock-link-'))
  const outside = await mkdtemp(join(tmpdir(), 'dsh-hygiene-lock-outside-'))
  const stateLink = join(root, 'state-link')
  if (!await testSymlink(t, outside, stateLink)) return
  await assert.rejects(
    tx.acquireWorkspaceLock(stateLink),
    (error) => error.code === 'SYMLINK_REJECTED',
  )
  // The guard must not have created a lock through the link.
  await assert.rejects(access(join(outside, '.lock')))
  await unlink(stateLink)
})

test('corrupt plan records are reported as state corruption', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-corrupt-plan-'))
  const statePlans = join(root, '.dsh-hygiene', 'plans')
  await mkdir(statePlans, { recursive: true })
  const planId = 'plan-corrupt-12345'
  await writeFile(join(statePlans, `${planId}.json`), '{not-json\n')
  await assert.rejects(
    tx.applyPlan(root, {}, { planId, token: 'anything' }, { token: 'anything', confirm: true }),
    (error) => error.code === 'STATE_CORRUPT',
  )
})

test('state records with malformed entry arrays fail closed', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-corrupt-shape-'))
  const state = join(root, '.dsh-hygiene')
  await mkdir(join(state, 'plans'), { recursive: true })
  await mkdir(join(state, 'runs'), { recursive: true })
  const planId = 'plan-corrupt-shape-12345'
  await writeFile(join(state, 'plans', `${planId}.json`), JSON.stringify({
    kind: 'workspace-hygiene-plan',
    planId,
    root,
    status: 'planned',
    entries: [null],
  }))
  await assert.rejects(
    tx.applyPlan(root, {}, { planId, token: 'anything' }, { token: 'anything', confirm: true }),
    (error) => error.code === 'STATE_CORRUPT',
  )

  const runId = 'run-corrupt-shape-12345'
  await writeFile(join(state, 'runs', `${runId}.json`), JSON.stringify({
    kind: 'workspace-hygiene-run',
    runId,
    root,
    status: 'completed',
    entries: [null],
  }))
  await assert.rejects(
    tx.restoreRun(root, {}, { runId }, { confirm: true }),
    (error) => error.code === 'STATE_CORRUPT',
  )

  // The read-only summary skips malformed records instead of crashing while
  // compacting their entries.
  const summary = await tx.status(root, {})
  assert.equal(summary.counts.plans, 0)
  assert.equal(summary.counts.runs, 0)
})

test('policy changes invalidate an existing plan', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-stale-policy-'))
  await mkdir(join(root, 'tmp'), { recursive: true })
  await writeFile(join(root, 'tmp', 'policy.log'), 'policy\n')
  const plan = await tx.planWorkspace(root, { managedRoots: ['tmp'], minAgeHours: 0 }, { includeMedium: true })
  await assert.rejects(
    tx.applyPlan(root, { managedRoots: ['tmp'], minAgeHours: 1 }, {
      planId: plan.planId,
      token: plan.token,
    }, { token: plan.token, confirm: true }),
    (error) => error.code === 'PLAN_STALE_POLICY',
  )
})

test('status stays read-only when no state exists', async (t) => {
  const tx = await loadTransactions(t)
  if (!tx) return
  const root = await mkdtemp(join(tmpdir(), 'dsh-hygiene-status-readonly-'))
  const summary = await tx.status(root, { minAgeHours: 0 })
  assert.equal(summary.counts.plans, 0)
  await assert.rejects(lstat(join(root, '.dsh-hygiene')), (error) => error.code === 'ENOENT')
})
