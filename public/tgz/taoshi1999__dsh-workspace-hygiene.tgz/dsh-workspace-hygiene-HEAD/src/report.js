/** Small, bounded on-disk projections for human review. */

import { lstat, mkdir, rename, unlink, writeFile } from 'node:fs/promises'
import { randomBytes } from 'node:crypto'
import { dirname, join } from 'node:path'
import { archiveRootFor, stateRootFor } from './config.js'
import { assertArchiveRoot } from './policy.js'
import { projectScan } from './scan.js'

async function ensureNoSymlinkPath(target) {
  let current = target
  while (true) {
    try {
      const info = await lstat(current)
      if (info.isSymbolicLink()) throw new Error(`report path component is a symlink: ${current}`)
      if (!info.isDirectory()) throw new Error(`report path component is not a directory: ${current}`)
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
    }
    const parent = dirname(current)
    if (parent === current) break
    current = parent
  }
}

function markdown(scan, limit = 25) {
  const view = projectScan(scan, limit)
  const cell = (value) => String(value ?? '').replace(/[|`]/g, '\\$&')
  const lines = [
    '# Workspace hygiene report',
    '',
    `- Root: \`${view.root}\``,
    `- Scanned: ${view.scannedAt}`,
    `- Files: ${view.totalFiles} (${view.totalBytes} bytes)`,
    `- Candidates: ${view.candidateCount}`,
    `- Catalog entries: ${view.catalogEntryCount ?? 0}`,
    `- Value classes: ${Object.entries(view.valueCounts ?? {}).map(([key, value]) => `${key}=${value}`).join(', ')}`,
    `- Protected: ${view.counts.protected}`,
    `- Skipped symlinks: ${view.skippedSymlinks}`,
    '',
    // Keep the original "Value | Action | Suggested organization" sequence
    // stable for consumers that parse the human report, while adding the
    // source metadata fields needed to understand a catalog entry.  The
    // suggested organization column is the metadata catalog path; the
    // following source-path column is the optional physical move suggestion.
    '| Path | Directory | Name | Purpose | Size | Age (h) | Confidence | Value | Action | Suggested organization | Catalog group | Suggested source path | Reasons |',
    '| --- | --- | --- | --- | ---: | ---: | --- | --- | --- | --- | --- | --- | --- |',
  ]
  for (const item of view.candidates) {
    const value = `${item.valueClass ?? 'unknown'} (${item.valueScore ?? '?'}/100)`
    const action = `${item.action ?? item.recommendation ?? 'review'}${item.execution ? ` [${item.execution}]` : ''}`
    const organization = item.organization ?? {}
    const catalogPath = organization.catalogPath
      ?? organization.suggestedPath
      ?? (organization.catalogDirectory && organization.suggestedName
        ? `${organization.catalogDirectory}/${organization.suggestedName}`
        : '')
    const sourcePath = organization.suggestedSourcePath
      ?? organization.physicalSuggestedPath
      ?? (organization.suggestedDirectory && organization.suggestedName
        ? `${organization.suggestedDirectory}/${organization.suggestedName}`
        : '')
    const group = actionGroup(item.action ?? item.recommendation)
    lines.push(`| \`${cell(item.relativePath)}\` | ${cell(item.directory ?? '')} | ${cell(item.name ?? '')} | ${cell(item.purpose ?? '')} | ${item.size} | ${item.ageHours} | ${cell(item.confidence)} | ${cell(value)} | ${cell(action)} | ${cell(catalogPath)} | ${cell(group)} | ${cell(sourcePath)} | ${cell((item.reasons ?? []).join(', '))} |`)
  }
  if (view.candidates.length === 0) lines.push('| *(none)* |  |  |  |  |  |  |  |  |  |  |  |  |')
  if (view.truncated) lines.push('', '> Scan was truncated by the configured bound.')
  if (view.warnings.length > 0) lines.push('', 'Warnings:', ...view.warnings.map(item => `- ${item}`))
  return `${lines.join('\n')}\n`
}

function actionGroup(action) {
  switch (String(action ?? '').toLowerCase()) {
    case 'retain': return 'retained'
    case 'archive': return 'intermediate'
    case 'delete': return 'to-delete'
    default: return 'review'
  }
}

async function atomicWrite(path, content) {
  await ensureNoSymlinkPath(dirname(path))
  await mkdir(dirname(path), { recursive: true, mode: 0o700 })
  await ensureNoSymlinkPath(dirname(path))
  // A report is a maintenance artifact, but it still lives under the plugin's
  // state boundary. Replace a pre-existing regular file atomically while
  // refusing a leaf symlink that could redirect the write elsewhere.
  try {
    const info = await lstat(path)
    if (info.isSymbolicLink()) throw new Error(`report destination is a symlink: ${path}`)
    if (!info.isFile()) throw new Error(`report destination is not a regular file: ${path}`)
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  const temporary = `${path}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`
  try {
    await writeFile(temporary, content, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
    await rename(temporary, path)
  } catch (error) {
    try { await unlink(temporary) } catch {}
    throw error
  }
}

/** Write latest-report.json/md under the hidden state directory. */
export async function writeLatestReport(scan, config = {}) {
  if (config.writeReports === false || !scan?.root) return undefined
  const stateRoot = stateRootFor(scan.root, config)
  const jsonPath = join(stateRoot, 'latest-report.json')
  const markdownPath = join(stateRoot, 'latest-report.md')
  const view = projectScan(scan, config.resultLimit ?? 25)
  await ensureNoSymlinkPath(stateRoot)
  await Promise.all([
    atomicWrite(jsonPath, `${JSON.stringify(view, null, 2)}\n`),
    atomicWrite(markdownPath, markdown(scan, config.resultLimit ?? 25)),
  ])
  return {
    jsonPath,
    markdownPath,
    archiveRoot: assertArchiveRoot(scan.root, archiveRootFor(scan.root, config), config),
  }
}

export default { writeLatestReport }
