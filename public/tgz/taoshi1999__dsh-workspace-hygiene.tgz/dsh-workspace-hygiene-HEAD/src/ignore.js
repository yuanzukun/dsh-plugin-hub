/**
 * Tiny, deliberately conservative ignore reader.
 *
 * `.hygieneignore` is not intended to be a second .gitignore implementation;
 * it only needs predictable path and directory patterns for a maintenance
 * tool.  A leading `!` is not supported on purpose: exclusions should be
 * explicit and monotonic.
 */

import { constants as fsConstants } from 'node:fs'
import { lstat, open, realpath } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { isInside, safeRelativePath, toPosixPath } from './path-utils.js'

// Ignore files are operator-authored policy, not an unbounded data channel.
// Keeping the limit small both bounds scanner memory and prevents a malformed
// file from inflating the model-facing inventory.
export const MAX_IGNORE_FILE_BYTES = 256 * 1024
export const MAX_EXPOSED_IGNORE_PATTERNS = 100
const MAX_EXPOSED_PATTERN_CHARS = 512

function ignoreError(message, code = 'IGNORE_FILE_REJECTED') {
  const error = new Error(message)
  error.code = code
  return error
}

/** Check existing parent components without following directory symlinks. */
async function ensureNoSymlinkAncestors(directory, boundary) {
  const root = resolve(boundary)
  let current = resolve(directory)
  if (!isInside(root, current)) throw ignoreError(`ignore path escapes workspace: ${directory}`, 'PATH_ESCAPE')
  while (true) {
    try {
      const info = await lstat(current)
      if (info.isSymbolicLink()) {
        throw ignoreError(`ignore path component is a symlink: ${current}`, 'SYMLINK_REJECTED')
      }
      if (!info.isDirectory()) {
        throw ignoreError(`ignore path component is not a directory: ${current}`)
      }
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
    }
    if (current === root || current === dirname(current)) break
    current = dirname(current)
  }
}

/**
 * Read a workspace ignore file only after boundary, type, and size checks.
 * O_NOFOLLOW protects the leaf on platforms that expose it; the realpath and
 * ancestor checks cover the common external-parent symlink case as well.
 */
async function readIgnoreFile(root, fileName) {
  const workspaceRoot = resolve(root)
  let relativeName
  try {
    relativeName = safeRelativePath(fileName)
  } catch (error) {
    throw ignoreError(`invalid ignore file path: ${fileName}`, 'IGNORE_PATH_INVALID')
  }
  const filePath = join(workspaceRoot, relativeName)
  if (!isInside(workspaceRoot, filePath)) {
    throw ignoreError(`ignore file escapes workspace: ${fileName}`, 'PATH_ESCAPE')
  }

  let info
  try {
    info = await lstat(filePath)
  } catch (error) {
    if (error?.code === 'ENOENT') return undefined
    throw error
  }
  if (info.isSymbolicLink()) {
    throw ignoreError(`ignore file is a symlink: ${filePath}`, 'SYMLINK_REJECTED')
  }
  if (!info.isFile()) {
    throw ignoreError(`ignore file is not a regular file: ${filePath}`)
  }
  if (info.size > MAX_IGNORE_FILE_BYTES) {
    throw ignoreError(
      `ignore file exceeds ${MAX_IGNORE_FILE_BYTES} bytes: ${filePath}`,
      'IGNORE_FILE_TOO_LARGE',
    )
  }

  await ensureNoSymlinkAncestors(dirname(filePath), workspaceRoot)
  const canonicalRoot = await realpath(workspaceRoot)
  const canonicalFile = await realpath(filePath)
  if (!isInside(canonicalRoot, canonicalFile)) {
    throw ignoreError(`ignore file resolves outside workspace: ${filePath}`, 'PATH_ESCAPE')
  }

  const flags = fsConstants.O_RDONLY | Number(fsConstants.O_NOFOLLOW ?? 0)
  let handle
  try {
    handle = await open(filePath, flags)
    const opened = await handle.stat()
    if (!opened.isFile()) throw ignoreError(`ignore file is not a regular file: ${filePath}`)
    if (opened.size > MAX_IGNORE_FILE_BYTES) {
      throw ignoreError(
        `ignore file exceeds ${MAX_IGNORE_FILE_BYTES} bytes: ${filePath}`,
        'IGNORE_FILE_TOO_LARGE',
      )
    }

    // Read at most one byte beyond the limit so a concurrent growth cannot
    // turn this policy file into an unbounded allocation.
    const buffer = Buffer.alloc(MAX_IGNORE_FILE_BYTES + 1)
    let offset = 0
    while (offset < buffer.length) {
      const { bytesRead } = await handle.read(buffer, offset, buffer.length - offset, null)
      if (bytesRead === 0) break
      offset += bytesRead
    }
    if (offset > MAX_IGNORE_FILE_BYTES) {
      throw ignoreError(
        `ignore file exceeds ${MAX_IGNORE_FILE_BYTES} bytes: ${filePath}`,
        'IGNORE_FILE_TOO_LARGE',
      )
    }
    return buffer.subarray(0, offset).toString('utf8')
  } catch (error) {
    if (error?.code === 'ELOOP') {
      throw ignoreError(`ignore file is a symlink: ${filePath}`, 'SYMLINK_REJECTED')
    }
    throw error
  } finally {
    try { await handle?.close() } catch {}
  }
}

function globToRegExp(pattern) {
  // Treat a trailing slash as the familiar "directory and descendants"
  // spelling. Without removing it first, `logs/` would compile to a pattern
  // that only matches a literal directory separator and would silently fail
  // to ignore `logs/run/output.log`.
  const normalized = toPosixPath(pattern.trim())
    .replace(/^\.\//, '')
    .replace(/^\//, '')
    .replace(/\/+$/, '')
  let source = ''
  for (let i = 0; i < normalized.length; i += 1) {
    const char = normalized[i]
    const next = normalized[i + 1]
    // `**/` is the recursive-directory form users expect from git-style
    // ignore files.  Make the directory prefix optional so a pattern such as
    // `logs/**/checkpoints/**` matches both `logs/checkpoints/a.pt` and
    // `logs/run-1/checkpoints/a.pt`.
    if (char === '*' && next === '*' && normalized[i + 2] === '/') {
      source += '(?:.*/)?'
      i += 2
    } else if (char === '*' && next === '*') {
      source += '.*'
      i += 1
    } else if (char === '*') {
      source += '[^/]*'
    } else if (char === '?') {
      source += '[^/]'
    } else {
      source += char.replace(/[\\^$+.()|{}[\]]/g, '\\$&')
    }
  }
  return new RegExp(`^(?:${source})(?:/.*)?$`, 'i')
}

/** Read and compile `.hygieneignore` from a workspace root. */
export async function loadIgnorePatterns(root, fileName = '.hygieneignore') {
  const raw = await readIgnoreFile(root, fileName)
  if (raw === undefined) return []
  return raw
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(line => line !== '' && !line.startsWith('#') && !line.startsWith('!'))
    .map(pattern => ({ pattern, regexp: globToRegExp(pattern) }))
}

/** Whether a POSIX relative path is covered by one of the compiled patterns. */
export function isIgnored(relativePath, patterns) {
  const normalized = toPosixPath(relativePath)
  return patterns.some(item => item.regexp.test(normalized))
}

/** Return the human-readable patterns for report metadata. */
export function ignorePatternNames(patterns, limit = MAX_EXPOSED_IGNORE_PATTERNS) {
  const safeLimit = Math.max(1, Math.min(MAX_EXPOSED_IGNORE_PATTERNS, Math.floor(limit)))
  const names = patterns.slice(0, safeLimit).map(item => String(item.pattern).slice(0, MAX_EXPOSED_PATTERN_CHARS))
  if (patterns.length > safeLimit) names.push(`… [${patterns.length - safeLimit} more ignore patterns]`)
  return names
}
