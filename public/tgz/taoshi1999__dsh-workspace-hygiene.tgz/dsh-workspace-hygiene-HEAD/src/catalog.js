/**
 * Metadata-only workspace artifact catalog.
 *
 * `workspace-artifacts/` is deliberately a catalog, not a second copy of the
 * workspace.  Each category contains small JSON records describing a source
 * file's location, name, purpose and recommended handling.  The source file
 * is never copied, moved, renamed or deleted by this module.  Transactional
 * file operations remain in transaction.js; a confirmed deletion can call
 * removeCatalogEntry() after the source operation succeeds.
 */

import { createHash } from 'node:crypto'
import {
  lstat,
  mkdir,
  readdir,
  readFile,
  realpath,
  rename,
  unlink,
  writeFile,
} from 'node:fs/promises'
import { dirname, join, relative, resolve } from 'node:path'
import {
  isInside,
  safeRelativePath,
  toPosixPath,
} from './path-utils.js'

export const CATALOG_SCHEMA_VERSION = 1

/** Stable on-disk directory names.  Keep this list intentionally small. */
export const CATALOG_GROUPS = Object.freeze([
  'retained',
  'intermediate',
  'review',
  'to-delete',
])

const GROUP_SET = new Set(CATALOG_GROUPS)
const ACTION_TO_GROUP = Object.freeze({
  retain: 'retained',
  valuable: 'retained',
  retained: 'retained',
  protected: 'retained',
  archive: 'intermediate',
  intermediate: 'intermediate',
  delete: 'to-delete',
  discard: 'to-delete',
  disposable: 'to-delete',
  'to-delete': 'to-delete',
  review: 'review',
  uncertain: 'review',
})
const GROUP_TO_ACTION = Object.freeze({
  retained: 'retain',
  intermediate: 'archive',
  review: 'review',
  'to-delete': 'delete',
})
const VALID_RECOMMENDATIONS = new Set(['retain', 'archive', 'delete', 'review'])

export class CatalogError extends Error {
  constructor(message, code = 'CATALOG_ERROR', details = undefined) {
    super(message)
    this.name = 'CatalogError'
    this.code = code
    if (details !== undefined) this.details = details
  }
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

function asNonEmptyString(value) {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : undefined
}

function asFiniteNumber(value, { integer = false, min = 0, max = Number.POSITIVE_INFINITY } = {}) {
  if (value === undefined || value === null || value === '') return undefined
  const number = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(number) || number < min || number > max || (integer && !Number.isInteger(number))) return undefined
  return number
}

function isoOrUndefined(value) {
  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? undefined : value.toISOString()
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    const date = new Date(value)
    return Number.isNaN(date.getTime()) ? undefined : date.toISOString()
  }
  if (typeof value === 'string' && value.trim() !== '') {
    const date = new Date(value)
    return Number.isNaN(date.getTime()) ? value.trim() : date.toISOString()
  }
  return undefined
}

function normalizeGroup(value) {
  const text = String(value ?? '').trim().toLowerCase()
  if (GROUP_SET.has(text)) return text
  return ACTION_TO_GROUP[text]
}

export function groupForAction(action, fallback = 'review') {
  return normalizeGroup(action) ?? (normalizeGroup(fallback) ?? 'review')
}

export function actionForGroup(group, fallback = 'review') {
  return GROUP_TO_ACTION[normalizeGroup(group) ?? ''] ?? fallback
}

function valueClassForGroup(group, fallback = undefined) {
  const normalized = normalizeGroup(group)
  const supplied = asNonEmptyString(fallback)
  // Retained entries may be hard-protected or merely valuable. Preserve that
  // distinction when it is compatible with the authoritative group.
  if (normalized === 'retained' && (supplied === 'protected' || supplied === 'valuable')) return supplied
  if (normalized === 'intermediate' && supplied === 'intermediate') return supplied
  if (normalized === 'to-delete' && supplied === 'disposable') return supplied
  if (normalized === 'review' && supplied === 'uncertain') return supplied
  return normalized === 'retained'
    ? 'valuable'
    : normalized === 'intermediate'
      ? 'intermediate'
      : normalized === 'to-delete'
        ? 'disposable'
        : 'uncertain'
}

function slug(value, fallback = 'artifact') {
  const cleaned = String(value ?? '')
    .normalize('NFKC')
    .replace(/[^\p{L}\p{M}\p{N}._-]+/gu, '-')
    .replace(/-{2,}/g, '-')
    .replace(/^[.-]+|[.-]+$/g, '')
  return cleaned || fallback
}

function sourceRelativePath(workspaceRoot, inputPath) {
  const text = asNonEmptyString(inputPath)
  if (!text) return undefined
  // A backslash is a legal POSIX filename character but a path separator on
  // Windows. Refuse it here rather than silently describing a different file
  // after platform normalization.
  if (text.includes('\\') && !/^[A-Za-z]:[\\/]/.test(text)) {
    throw new CatalogError(`ambiguous source path: ${inputPath}`, 'SOURCE_PATH_INVALID')
  }
  // Absolute source paths are accepted only when they resolve inside the
  // workspace.  Storing an absolute path in the catalog would make the
  // metadata non-portable and could hide a path-boundary mistake.
  if (text.startsWith('/') || /^[A-Za-z]:[\\/]/.test(text)) {
    const absolute = resolve(text)
    if (!isInside(workspaceRoot, absolute)) {
      throw new CatalogError(`source path escapes workspace: ${inputPath}`, 'SOURCE_PATH_ESCAPE')
    }
    return safeRelativePath(toPosixPath(relative(workspaceRoot, absolute)))
  }
  return safeRelativePath(text)
}

function entrySourcePath(workspaceRoot, input) {
  const source = isRecord(input?.source) ? input.source : {}
  const direct = input?.relativePath ?? input?.path ?? source.relativePath ?? source.path
  if (direct !== undefined) return sourceRelativePath(workspaceRoot, direct)
  const directory = input?.directory ?? input?.sourceDirectory ?? source.directory ?? ''
  const name = input?.name ?? source.name
  if (!asNonEmptyString(name)) {
    throw new CatalogError('catalog entry requires relativePath or name', 'ENTRY_INVALID')
  }
  const joined = [String(directory ?? '').trim(), String(name).trim()]
    .filter(Boolean).join('/')
  return sourceRelativePath(workspaceRoot, joined)
}

function ensureCatalogRelativePath(value, label = 'catalog path') {
  try {
    return safeRelativePath(value)
  } catch (error) {
    throw new CatalogError(`${label} must be a safe workspace-relative path: ${value}`, 'CATALOG_PATH_INVALID')
  }
}

function optionalSafeMetadataPath(value, label) {
  const text = asNonEmptyString(value)
  if (text === undefined) return undefined
  try { return safeRelativePath(text) } catch {
    throw new CatalogError(`${label} must be a safe relative path: ${value}`, 'METADATA_PATH_INVALID')
  }
}

function organizationInput(config = {}) {
  const valuePolicy = isRecord(config?.valuePolicy) ? config.valuePolicy : {}
  const catalog = isRecord(config?.catalog) ? config.catalog : {}
  const organization = isRecord(valuePolicy.organization) ? valuePolicy.organization : {}
  return { catalog, organization }
}

/**
 * Resolve the metadata catalog root.  It is always a child of the workspace;
 * absolute paths and `..` segments are rejected so a model cannot redirect
 * catalog writes outside the workspace boundary.
 */
export function catalogRootFor(workspaceRoot, config = {}) {
  const root = resolve(workspaceRoot)
  const { catalog, organization } = organizationInput(config)
  const topLevel = asNonEmptyString(config?.catalogRoot)
    ?? asNonEmptyString(config?.workspaceArtifactsRoot)
    ?? asNonEmptyString(config?.catalogDirectory)
  const nested = asNonEmptyString(catalog.root)
    ?? asNonEmptyString(organization.catalogRoot)
    ?? asNonEmptyString(organization.root)
  // resolveConfig() supplies the default top-level spelling even when an
  // operator configured a nested organization root. Treat that default as
  // non-authoritative so `valuePolicy.organization.root: custom-index` keeps
  // working after normalization; an explicit non-default top-level value wins.
  const configured = nested && (!topLevel || topLevel === 'workspace-artifacts')
    ? nested
    : topLevel
      ?? nested
      ?? 'workspace-artifacts'
  const text = asNonEmptyString(configured) ?? 'workspace-artifacts'
  if (text.startsWith('/') || /^[A-Za-z]:[\\/]/.test(text) || text.startsWith('~')) {
    throw new CatalogError('catalogRoot must be workspace-relative', 'CATALOG_ROOT_INVALID')
  }
  let relativeRoot
  try {
    relativeRoot = safeRelativePath(text)
  } catch {
    throw new CatalogError(`catalogRoot must be a safe workspace-relative path: ${configured}`, 'CATALOG_ROOT_INVALID')
  }
  const target = resolve(root, relativeRoot)
  if (target === root || !isInside(root, target)) {
    throw new CatalogError('catalogRoot cannot be the workspace root or escape it', 'CATALOG_ROOT_INVALID')
  }
  const stateText = asNonEmptyString(config?.stateDir)
  if (stateText) {
    try {
      const stateRoot = resolve(root, safeRelativePath(stateText))
      if (isInside(stateRoot, target) || isInside(target, stateRoot)) {
        throw new CatalogError('catalogRoot cannot overlap stateDir', 'CATALOG_ROOT_INVALID')
      }
    } catch (error) {
      if (error instanceof CatalogError) throw error
      // resolveConfig() validates stateDir; raw callers with malformed state
      // paths are left to their own configuration boundary.
    }
  }
  const archiveText = asNonEmptyString(config?.archiveRoot)
  if (archiveText && !archiveText.startsWith('~')) {
    try {
      const archivePath = resolve(root, archiveText)
      if (isInside(archivePath, target) || isInside(target, archivePath)) {
        throw new CatalogError('catalogRoot cannot overlap archiveRoot', 'CATALOG_ROOT_INVALID')
      }
    } catch (error) {
      if (error instanceof CatalogError) throw error
      // Archive path validation is performed by config/policy. Ignore an
      // unrelated malformed value here so catalog root errors stay focused.
    }
  }
  return target
}

// Friendly aliases used by integrations that call the namespace
// `workspace-artifacts` rather than `catalog`.
export const workspaceArtifactsRootFor = catalogRootFor
export const workspaceArtifactsCatalogRoot = catalogRootFor

/** Return whether catalog persistence is explicitly disabled. */
export function catalogEnabled(config = {}) {
  const { catalog } = organizationInput(config)
  return config?.catalogEnabled !== false && catalog.enabled !== false
}

function catalogGroupRoot(catalogRoot, group) {
  const normalized = normalizeGroup(group)
  if (!normalized) throw new CatalogError(`unknown catalog group: ${group}`, 'GROUP_INVALID')
  return join(catalogRoot, normalized)
}

function entryDigest(relativePath) {
  return createHash('sha256').update(relativePath).digest('hex').slice(0, 16)
}

/** Stable, human-readable metadata filename for a source path. */
export function catalogEntryFileName(relativePath, name = undefined) {
  const rel = ensureCatalogRelativePath(relativePath, 'source relativePath')
  const base = asNonEmptyString(name) ?? rel.split('/').at(-1) ?? 'artifact'
  return `${slug(base)}--${entryDigest(rel)}.json`
}

export function catalogEntryPath(workspaceRoot, group, relativePath, config = {}, name = undefined) {
  if (isRecord(relativePath)) {
    const entry = relativePath
    name = entry.name
    relativePath = entry.relativePath ?? entry.path
  }
  const root = catalogRootFor(workspaceRoot, config)
  const rel = ensureCatalogRelativePath(relativePath, 'source relativePath')
  if (isInside(root, resolve(workspaceRoot, rel))) {
    throw new CatalogError('catalog cannot describe a file inside itself', 'CATALOG_SELF_REFERENCE')
  }
  const groupRoot = catalogGroupRoot(root, group)
  return join(groupRoot, catalogEntryFileName(rel, name))
}

/** Check every existing path component without following symlinks. */
async function ensureNoSymlinkPath(target, boundary = undefined) {
  const absolute = resolve(target)
  if (boundary !== undefined && !isInside(boundary, absolute)) {
    throw new CatalogError(`catalog path escapes boundary: ${target}`, 'CATALOG_PATH_ESCAPE')
  }
  const stop = boundary === undefined ? resolve('/') : resolve(boundary)
  let current = absolute
  while (true) {
    try {
      const info = await lstat(current)
      if (info.isSymbolicLink()) throw new CatalogError(`catalog path component is a symlink: ${current}`, 'SYMLINK_REJECTED')
      if (!info.isDirectory()) throw new CatalogError(`catalog path component is not a directory: ${current}`, 'CATALOG_DESTINATION_ERROR')
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
    }
    if (current === stop || current === dirname(current)) break
    current = dirname(current)
  }
}

async function ensureCatalogDirectories(catalogRoot) {
  await ensureNoSymlinkPath(catalogRoot)
  await mkdir(catalogRoot, { recursive: true, mode: 0o700 })
  await ensureNoSymlinkPath(catalogRoot)
  for (const group of CATALOG_GROUPS) {
    const directory = join(catalogRoot, group)
    await ensureNoSymlinkPath(directory, catalogRoot)
    await mkdir(directory, { recursive: true, mode: 0o700 })
    await ensureNoSymlinkPath(directory, catalogRoot)
  }
}

async function atomicWriteJson(path, value) {
  await ensureNoSymlinkPath(dirname(path))
  await mkdir(dirname(path), { recursive: true, mode: 0o700 })
  await ensureNoSymlinkPath(dirname(path))
  try {
    const info = await lstat(path)
    if (info.isSymbolicLink()) throw new CatalogError(`catalog entry is a symlink: ${path}`, 'SYMLINK_REJECTED')
    if (!info.isFile()) throw new CatalogError(`catalog entry is not a file: ${path}`, 'CATALOG_DESTINATION_ERROR')
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  const temporary = `${path}.${process.pid}.${entryDigest(`${path}:${Date.now()}`)}.tmp`
  try {
    await writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, {
      encoding: 'utf8', flag: 'wx', mode: 0o600,
    })
    await rename(temporary, path)
  } catch (error) {
    try { await unlink(temporary) } catch {}
    if (error instanceof CatalogError) throw error
    throw new CatalogError(`cannot write catalog entry: ${error?.message ?? String(error)}`, 'CATALOG_WRITE_ERROR')
  }
}

function stableArray(value) {
  if (!Array.isArray(value)) return undefined
  const items = value.filter(item => typeof item === 'string' && item.trim() !== '')
    .map(item => item.trim())
  return [...new Set(items)]
}

function canonicalValue(value) {
  if (Array.isArray(value)) return value.map(canonicalValue)
  if (!isRecord(value)) return value
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonicalValue(value[key])]))
}

function derivePurpose(input, group, recommendation, valueClassOverride = undefined) {
  const explicit = asNonEmptyString(input?.purpose ?? input?.description ?? input?.use)
  if (explicit) return explicit
  const valueClass = asNonEmptyString(valueClassOverride ?? input?.valueClass)
  const reasons = stableArray(input?.valueReasons ?? input?.reasons)
  const qualifier = valueClass ? `${valueClass} artifact` : 'workspace artifact'
  if (reasons?.length) return `${qualifier}; ${reasons.slice(0, 3).join(', ')}`
  return `${qualifier}; recommended action: ${recommendation || actionForGroup(group)}`
}

/**
 * Normalize one scanner/agent record into the compact durable catalog shape.
 * Unknown fields are intentionally not copied into the catalog, keeping the
 * files small and making their JSON deterministic across producers.
 */
export function normalizeCatalogEntry(input, workspaceRoot, existing = undefined, options = {}) {
  if (!isRecord(input)) throw new CatalogError('catalog entry must be an object', 'ENTRY_INVALID')
  const root = resolve(workspaceRoot)
  const relativePath = entrySourcePath(root, input)
  if (isInside(catalogRootFor(root, options.config ?? {}), resolve(root, relativePath))) {
    throw new CatalogError('catalog cannot describe a file inside itself', 'CATALOG_SELF_REFERENCE')
  }
  const source = isRecord(input.source) ? input.source : {}
  // `relativePath` is authoritative for source identity.  A producer may
  // supply a stale/malicious `name` field, but the catalog must always expose
  // the actual basename so directory/name metadata cannot disagree.
  const name = relativePath.split('/').at(-1)
  const directory = relativePath.includes('/') ? relativePath.slice(0, relativePath.lastIndexOf('/')) : '.'
  const handling = isRecord(input.handling) ? input.handling : {}
  // `action` is the explicit transaction decision and therefore outranks a
  // stale recommendation/group carried by a scanner snapshot. When action is
  // absent, retain the older aliases and explicit category precedence for
  // backwards-compatible catalog producers.
  const explicitAction = asNonEmptyString(input.action)
  const action = explicitAction ?? asNonEmptyString(input.recommendation
    ?? input.handlingRecommendation ?? input.processingRecommendation
    ?? handling.action ?? handling.recommendation)
  const group = explicitAction
    ? normalizeGroup(explicitAction)
    : normalizeGroup(input.group ?? input.category ?? action ?? input.valueClass)
      ?? normalizeGroup(existing?.group)
      ?? 'review'
  const requestedRecommendation = explicitAction ?? asNonEmptyString(input.recommendation
    ?? input.handlingRecommendation ?? input.processingRecommendation
    ?? handling.recommendation ?? handling.action)
  const recommendation = requestedRecommendation && VALID_RECOMMENDATIONS.has(requestedRecommendation.toLowerCase())
    ? requestedRecommendation.toLowerCase()
    : actionForGroup(group)
  const valueClass = valueClassForGroup(group, input.valueClass)
  const reasons = stableArray(input.valueReasons ?? input.reasons)
    ?? stableArray(existing?.reasons)
  const valueSignals = isRecord(input.valueSignals)
    ? canonicalValue(input.valueSignals)
    : (isRecord(existing?.valueSignals) ? canonicalValue(existing.valueSignals) : undefined)
  const valueScore = asFiniteNumber(input.valueScore ?? input.score, { min: 0, max: 100 })
    ?? asFiniteNumber(existing?.valueScore, { min: 0, max: 100 })
  const size = asFiniteNumber(input.size ?? source.size, { integer: true })
    ?? asFiniteNumber(existing?.size, { integer: true })
  const mtimeMs = asFiniteNumber(input.mtimeMs ?? source.mtimeMs, { min: 0 })
    ?? asFiniteNumber(existing?.mtimeMs, { min: 0 })
  const sha256 = asNonEmptyString(input.sha256 ?? input.hash ?? source.sha256)
    ?? asNonEmptyString(existing?.sha256)
  // Preserve a human-authored purpose during routine scanner refreshes when
  // the producer did not supply a replacement description.
  const suppliedPurpose = asNonEmptyString(input?.purpose ?? input?.description ?? input?.use)
  const purpose = suppliedPurpose ?? asNonEmptyString(existing?.purpose)
    ?? derivePurpose(input, group, recommendation, valueClass)
  const organization = isRecord(input.organization) ? input.organization : undefined
  const suggestedName = asNonEmptyString(input.suggestedName ?? organization?.suggestedName)
    ?? asNonEmptyString(existing?.suggestedName)
  const suggestedPath = optionalSafeMetadataPath(input.suggestedPath ?? organization?.suggestedPath, 'suggestedPath')
    ?? asNonEmptyString(existing?.suggestedPath)
  // Keep the catalog location (suggestedPath) separate from a possible
  // physical source-file destination.  Older producers only emitted
  // suggestedPath, so those records remain readable; newer producers can
  // explicitly expose the source-side suggestion without ever making the
  // catalog root a file-move target.
  const suggestedSourceName = asNonEmptyString(
    input.suggestedSourceName
      ?? input.physicalSuggestedName
      ?? organization?.suggestedSourceName
      ?? organization?.physicalSuggestedName,
  ) ?? asNonEmptyString(existing?.suggestedSourceName)
  const suggestedSourcePath = optionalSafeMetadataPath(
    input.suggestedSourcePath
      ?? input.physicalSuggestedPath
      ?? input.sourceSuggestedPath
      ?? organization?.suggestedSourcePath
      ?? organization?.physicalSuggestedPath,
    'suggestedSourcePath',
  ) ?? asNonEmptyString(existing?.suggestedSourcePath)
  const archivedRelativePath = optionalSafeMetadataPath(
    input.archivedRelativePath ?? input.archiveRelativePath ?? input.archivePath,
    'archivedRelativePath',
  ) ?? asNonEmptyString(existing?.archivedRelativePath)
  const organizedRelativePath = optionalSafeMetadataPath(
    input.organizedRelativePath ?? input.organizedPath,
    'organizedRelativePath',
  ) ?? asNonEmptyString(existing?.organizedRelativePath)
  const now = isoOrUndefined(options.now)
  const observedAt = isoOrUndefined(input.lastSeenAt ?? input.scannedAt ?? options.observedAt)
    ?? asNonEmptyString(existing?.lastSeenAt)
  const createdAt = isoOrUndefined(input.createdAt) ?? asNonEmptyString(existing?.createdAt)
  const updatedAt = isoOrUndefined(input.updatedAt) ?? now ?? asNonEmptyString(existing?.updatedAt)
  const explicitStatus = asNonEmptyString(input.status)
  const sourceExists = typeof input.sourceExists === 'boolean'
    ? input.sourceExists
    : typeof input.exists === 'boolean'
      ? input.exists
      : typeof existing?.sourceExists === 'boolean' ? existing.sourceExists : undefined
  const assessmentChanged = Boolean(existing && (
    existing.group !== group
      || existing.recommendation !== recommendation
      || (sha256 && existing.sha256 && sha256 !== existing.sha256)
  ))
  const fingerprintChanged = Boolean(existing && observedFingerprintChanged(existing, {
    size,
    mtimeMs,
    sha256,
    sourceExists,
  }, input))
  const status = explicitStatus
    ?? (fingerprintChanged ? 'stale' : undefined)
    ?? (assessmentChanged ? 'pending' : undefined)
    ?? (existing?.status === 'stale' && sourceExists !== false ? 'pending' : undefined)
    ?? asNonEmptyString(existing?.status)
    ?? 'pending'
  const normalized = {
    schemaVersion: CATALOG_SCHEMA_VERSION,
    relativePath,
    directory,
    name,
    purpose,
    recommendation,
    group,
    valueClass,
    ...(valueScore === undefined ? {} : { valueScore }),
    ...(reasons === undefined ? {} : { reasons }),
    ...(valueSignals === undefined ? {} : { valueSignals }),
    ...(size === undefined ? {} : { size }),
    ...(mtimeMs === undefined ? {} : { mtimeMs }),
    ...(sha256 === undefined ? {} : { sha256 }),
    ...(suggestedName === undefined ? {} : { suggestedName }),
    ...(suggestedPath === undefined ? {} : { suggestedPath }),
    ...(suggestedSourceName === undefined ? {} : { suggestedSourceName }),
    ...(suggestedSourcePath === undefined ? {} : { suggestedSourcePath }),
    ...(archivedRelativePath === undefined ? {} : { archivedRelativePath }),
    ...(organizedRelativePath === undefined ? {} : { organizedRelativePath }),
    ...(observedAt === undefined ? {} : { lastSeenAt: observedAt }),
    ...(createdAt === undefined ? {} : { createdAt }),
    ...(updatedAt === undefined ? {} : { updatedAt }),
    ...(sourceExists === undefined ? {} : { sourceExists }),
    status,
  }
  // A physically organized file can still look like a candidate on the next
  // scan (for example, a retained `.log` under its original parent). Preserve
  // the already-applied naming decision while its fingerprint and action stay
  // unchanged; otherwise the default `{date}-{stem}` template would prepend
  // the date repeatedly on every idle cycle. A changed source fingerprint or
  // value group intentionally invalidates this shortcut and is re-evaluated.
  const stableOrganized = existing?.status === 'applied'
    && existing?.organizedRelativePath === relativePath
    && !fingerprintChanged
    && existing?.group === group
    && existing?.recommendation === recommendation
  if (stableOrganized) {
    for (const key of [
      'suggestedName', 'suggestedPath', 'suggestedSourceName',
      'suggestedSourcePath', 'organizedRelativePath',
    ]) {
      if (existing[key] !== undefined) normalized[key] = existing[key]
    }
  }
  return normalized
}

function entryFileNameFor(entry) {
  return catalogEntryFileName(entry.relativePath, entry.name)
}

function entrySort(left, right) {
  const a = String(left.relativePath)
  const b = String(right.relativePath)
  return a < b ? -1 : a > b ? 1 : 0
}

function emptyCatalog(root, catalogRoot, warnings = []) {
  const groups = Object.fromEntries(CATALOG_GROUPS.map(group => [group, []]))
  return {
    schemaVersion: CATALOG_SCHEMA_VERSION,
    root,
    catalogRoot,
    groups,
    entries: [],
    // `items` is a convenient alias for consumers that do not need grouped
    // access; it intentionally points to a separate array in JSON results.
    items: [],
    counts: Object.fromEntries(CATALOG_GROUPS.map(group => [group, 0])),
    warnings,
  }
}

async function readMetadataFile(path, group, workspaceRoot, config) {
  let info
  try {
    info = await lstat(path)
  } catch (error) {
    if (error?.code === 'ENOENT') return undefined
    throw error
  }
  if (info.isSymbolicLink()) throw new CatalogError(`catalog metadata is a symlink: ${path}`, 'SYMLINK_REJECTED')
  if (!info.isFile()) return undefined
  let value
  try {
    value = JSON.parse(await readFile(path, 'utf8'))
  } catch (error) {
    throw new CatalogError(`cannot parse catalog metadata ${path}: ${error?.message ?? String(error)}`, 'CATALOG_CORRUPT')
  }
  if (!isRecord(value) || value.schemaVersion !== CATALOG_SCHEMA_VERSION) {
    throw new CatalogError(`invalid catalog metadata: ${path}`, 'CATALOG_CORRUPT')
  }
  const normalized = normalizeCatalogEntry({ ...value, group }, workspaceRoot, value, { config })
  // Preserve the actual metadata filename for sync/move bookkeeping. It is
  // deliberately non-enumerable so public JSON remains deterministic.
  Object.defineProperty(normalized, '_catalogFile', { value: path, enumerable: false })
  return normalized
}

/** Read grouped metadata without inspecting or changing source files. */
export async function readCatalog(workspaceRoot, config = {}, options = {}) {
  const root = resolve(workspaceRoot)
  const catalogRoot = catalogRootFor(root, config)
  const result = emptyCatalog(root, catalogRoot)
  if (!catalogEnabled(config)) return result
  try {
    await ensureNoSymlinkPath(catalogRoot, root)
    await lstat(catalogRoot)
  } catch (error) {
    if (error?.code === 'ENOENT') return result
    throw error
  }
  const warnings = []
  for (const group of CATALOG_GROUPS) {
    const directory = catalogGroupRoot(catalogRoot, group)
    try {
      await ensureNoSymlinkPath(directory, catalogRoot)
    } catch (error) {
      if (error?.code === 'ENOENT') continue
      throw error
    }
    let entries
    try {
      entries = await readdir(directory, { withFileTypes: true })
    } catch (error) {
      if (error?.code === 'ENOENT') continue
      throw new CatalogError(`cannot read catalog group ${group}: ${error?.message ?? String(error)}`, 'CATALOG_READ_ERROR')
    }
    entries.sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0)
    for (const item of entries) {
      if (item.isDirectory()) continue
      if (!item.name.toLowerCase().endsWith('.json')) {
        warnings.push(`ignored non-JSON catalog file: ${group}/${item.name}`)
        continue
      }
      const path = join(directory, item.name)
      try {
        const metadata = await readMetadataFile(path, group, root, config)
        if (metadata) result.groups[group].push(metadata)
      } catch (error) {
        if (options.strict === false) {
          warnings.push(error?.message ?? String(error))
          continue
        }
        throw error
      }
    }
    result.groups[group].sort(entrySort)
  }
  result.entries = CATALOG_GROUPS.flatMap(group => result.groups[group])
  result.items = [...result.entries]
  result.counts = Object.fromEntries(CATALOG_GROUPS.map(group => [group, result.groups[group].length]))
  result.warnings = warnings
  return result
}

export const readWorkspaceCatalog = readCatalog

/** Return a bounded, model-safe view of a catalog. */
export function projectCatalog(catalog, limit = 100) {
  const safeLimit = Math.max(1, Math.min(500, Math.floor(Number(limit) || 100)))
  const sourceGroups = isRecord(catalog?.groups) ? catalog.groups : {}
  const groups = Object.fromEntries(CATALOG_GROUPS.map(group => [
    group,
    (Array.isArray(sourceGroups[group]) ? sourceGroups[group] : []).slice(0, safeLimit)
      .map(entry => projectedEntry(entry, group, catalog?.catalogRoot)),
  ]))
  const entries = CATALOG_GROUPS.flatMap(group => groups[group])
  return {
    schemaVersion: catalog?.schemaVersion ?? CATALOG_SCHEMA_VERSION,
    root: catalog?.root,
    catalogRoot: catalog?.catalogRoot,
    counts: catalog?.counts ?? Object.fromEntries(CATALOG_GROUPS.map(group => [group, sourceGroups[group]?.length ?? 0])),
    warnings: Array.isArray(catalog?.warnings) ? catalog.warnings.slice(0, 20) : [],
    entries,
    groups,
  }
}

function recordsFromInput(input) {
  if (Array.isArray(input)) return input
  if (!isRecord(input)) return []
  // Scanner snapshots may carry a complete, bounded inventory for catalog
  // maintenance while keeping the model-facing `candidates` projection
  // intentionally small. Prefer that explicit catalog stream when present.
  if (Array.isArray(input.catalogEntries)) return input.catalogEntries
  if (Array.isArray(input.entries)) return input.entries
  if (Array.isArray(input.candidates)) return input.candidates
  if (Array.isArray(input.items)) return input.items
  return [input]
}

function serializableEntry(entry) {
  const copy = { ...entry }
  delete copy._catalogFile
  return copy
}

/**
 * Return whether a source path was inside the portion of the workspace that a
 * scan actually observed.  Scans deliberately skip protected/ignored trees,
 * and may stop at their file bound.  Treating an unobserved path as missing
 * would turn a safe informational scan into an unsafe stale/prune operation.
 */
function pathWasObserved(relativePath, coverage, partialScan = false) {
  if (partialScan) return false
  const prefixes = Array.isArray(coverage?.excludedPrefixes)
    ? coverage.excludedPrefixes
    : []
  for (const rawPrefix of prefixes) {
    let prefix
    try { prefix = safeRelativePath(String(rawPrefix)) } catch { continue }
    if (relativePath === prefix || relativePath.startsWith(`${prefix}/`)) return false
  }
  return true
}

/**
 * Inspect one catalog source without following a symlink outside the
 * workspace.  `lstat` alone is insufficient because a parent directory can be
 * replaced with a symlink between scans; checking the canonical existing
 * ancestor catches both existing and missing leaves in that situation.
 */
async function inspectSource(workspaceRoot, relativePath) {
  const root = resolve(workspaceRoot)
  const absolute = resolve(root, relativePath)
  let info
  try {
    info = await lstat(absolute)
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
    let current = absolute
    while (true) {
      try {
        const canonical = await realpath(current)
        if (!isInside(root, canonical)) return { sourceExists: false, unsafe: true }
        break
      } catch (ancestorError) {
        if (ancestorError?.code !== 'ENOENT') throw ancestorError
        const parent = dirname(current)
        if (parent === current) break
        current = parent
      }
    }
    return { sourceExists: false, unsafe: false }
  }

  // A catalog describes regular source files. A replacement directory,
  // device, or symlink is not the original source and must become stale.
  if (info.isSymbolicLink() || !info.isFile()) {
    return { sourceExists: false, unsafe: info.isSymbolicLink(), info }
  }
  const canonical = await realpath(absolute)
  if (!isInside(root, canonical)) return { sourceExists: false, unsafe: true, info }
  return { sourceExists: true, unsafe: false, info }
}

function observedFingerprintChanged(previous, next, input) {
  // An explicitly supplied status is authoritative (transaction workflows use
  // it to record `confirmed`, `applied`, or `archived`).  Scanner refreshes do
  // not supply status, so a changed lightweight fingerprint invalidates the
  // previous human/autonomous decision and requires re-review.
  if (isRecord(input) && asNonEmptyString(input.status)) return false
  if (previous?.sourceExists === false && next?.sourceExists === true) return true
  const comparable = ['size', 'mtimeMs', 'sha256']
  for (const key of comparable) {
    if (previous?.[key] === undefined || next?.[key] === undefined) continue
    if (String(previous[key]) !== String(next[key])) return true
  }
  return false
}

function projectedEntry(entry, group, catalogRoot) {
  const copy = serializableEntry(entry)
  const file = entry?._catalogFile
  if (file && catalogRoot) {
    try {
      const rel = toPosixPath(relative(catalogRoot, file))
      if (rel && rel !== '..' && !rel.startsWith('../')) copy.catalogPath = rel
    } catch {}
  }
  if (!copy.catalogPath && copy.relativePath && group) {
    copy.catalogPath = `${group}/${catalogEntryFileName(copy.relativePath, copy.name)}`
  }
  return copy
}

function sameJson(left, right) {
  return JSON.stringify(serializableEntry(left), null, 2) === JSON.stringify(serializableEntry(right), null, 2)
}

/**
 * Synchronize catalog metadata from a scan/candidate list.  Only JSON files
 * below the catalog root are written; no source path is opened or mutated.
 * Existing records not represented by the input are retained unless
 * `pruneMissing:true` is supplied.
 */
export async function syncCatalog(workspaceRoot, input = [], config = {}, options = {}) {
  // A friendly overload accepts syncCatalog(root, config, { entries }) when a
  // caller has no records.  The explicit four-argument form remains canonical.
  if (isRecord(input) && !Array.isArray(input) && isRecord(config)
    && (Array.isArray(config.entries) || Array.isArray(config.candidates) || Array.isArray(config.items))) {
    const swap = config
    config = input
    input = swap
  }
  if (isRecord(input) && !Array.isArray(input) && isRecord(config)
    && Object.keys(config).length === 0
    && !Array.isArray(input.entries) && !Array.isArray(input.candidates) && !Array.isArray(input.items)
    && ['catalogRoot', 'catalogEnabled', 'catalog', 'valuePolicy', 'managedRoots', 'workspaceRoot']
      .some(key => Object.prototype.hasOwnProperty.call(input, key))) {
    config = input
    input = []
  }
  const root = resolve(workspaceRoot)
  const catalogRoot = catalogRootFor(root, config)
  const current = await readCatalog(root, config, { strict: options.strict !== false })
  if (!catalogEnabled(config)) return { ...current, changed: { created: [], updated: [], moved: [], removed: [] } }
  const records = recordsFromInput(input)
  // A scan carries one observation timestamp for all candidates. Reuse it as
  // the catalog's lastSeenAt value unless the caller supplied a more specific
  // timestamp. This keeps periodic refreshes reproducible and avoids making
  // otherwise identical syncs dirty merely because wall-clock time advanced.
  const observedAt = options.observedAt
    ?? (isRecord(input) ? input.scannedAt : undefined)
  const syncOptions = observedAt === undefined ? { ...options, config } : { ...options, config, observedAt }
  const coverage = options.coverage
    ?? (isRecord(input) && isRecord(input.catalogCoverage) ? input.catalogCoverage : undefined)
  const partialScan = Boolean(
    options.partialScan === true
      || (isRecord(input) && input.truncated === true)
      || coverage?.truncated === true,
  )
  // Never refresh/prune unseen records from a bounded scan unless the caller
  // explicitly opts in.  A scan that stopped at maxScanFiles only observed a
  // prefix of the workspace; preserving old metadata is safer than guessing
  // that every omitted source disappeared.
  const allowPartialRefresh = options.allowPartialRefresh === true
    || options.refreshPartial === true
  const refreshMissing = options.refreshMissing === true
    && (!partialScan || allowPartialRefresh)
  const pruneMissing = options.pruneMissing === true
    && (!partialScan || allowPartialRefresh)
  const seen = new Set()
  const byPath = new Map(current.entries.map(entry => [entry.relativePath, entry]))
  const next = new Map(byPath)
  const changes = { created: [], updated: [], moved: [], removed: [] }
  for (const record of records) {
    let normalized
    try {
      const relativePath = entrySourcePath(root, record)
      const existing = byPath.get(relativePath)
      normalized = normalizeCatalogEntry(record, root, existing, syncOptions)
    } catch (error) {
      if (options.strict === false) continue
      throw error
    }
    seen.add(normalized.relativePath)
    const previous = byPath.get(normalized.relativePath)
    next.set(normalized.relativePath, normalized)
    if (!previous) changes.created.push(normalized.relativePath)
    else if (!sameJson(previous, normalized)) changes.updated.push(normalized.relativePath)
    if (previous && previous.group !== normalized.group) changes.moved.push(normalized.relativePath)
  }
  if (refreshMissing) {
    // Candidates are a deliberately narrow view of the workspace. Refresh
    // catalog entries that did not appear in this scan so a manually removed
    // or moved source becomes visibly stale instead of silently lingering.
    // The check is metadata-only (lstat); it never reads or mutates bytes.
    for (const [relativePath, previous] of byPath) {
      if (seen.has(relativePath)) continue
      if (!pathWasObserved(relativePath, coverage, partialScan)) continue
      const source = await inspectSource(root, relativePath)
      const info = source.info
      const refreshed = normalizeCatalogEntry({
        ...serializableEntry(previous),
        sourceExists: source.sourceExists,
        status: source.sourceExists
          ? (previous.status === 'stale' ? 'pending' : previous.status)
          : 'stale',
        ...(source.sourceExists && info?.isFile() ? { size: info.size, mtimeMs: info.mtimeMs } : {}),
      }, root, previous, syncOptions)
      next.set(relativePath, refreshed)
      if (!sameJson(previous, refreshed)) changes.updated.push(relativePath)
    }
  }
  if (pruneMissing) {
    for (const [relativePath, previous] of byPath) {
      if (seen.has(relativePath)) continue
      if (!pathWasObserved(relativePath, coverage, partialScan)) continue
      // A pending to-delete record is retained by default. It may only be
      // removed by an explicit confirmed deletion path.
      if (previous.group === 'to-delete' && options.removeToDelete !== true) continue
      // `refreshMissing` deliberately marks an absent source as stale. Do not
      // immediately erase that evidence during the same maintenance pass;
      // humans and autonomous policies need the record to understand what
      // happened. A caller that truly wants pruning can opt into
      // `removeStale:true` (and still never removes pending to-delete entries
      // without `removeToDelete:true`).
      const refreshed = next.get(relativePath)
      if (refreshed?.status === 'stale' && options.removeStale !== true) continue
      if (refreshed && refreshed.sourceExists === true) continue
      next.delete(relativePath)
      changes.removed.push(relativePath)
    }
  }
  for (const key of Object.keys(changes)) changes[key].sort()
  if (options.dryRun === true) {
    const preview = emptyCatalog(root, catalogRoot, current.warnings)
    for (const entry of [...next.values()].sort(entrySort)) preview.groups[entry.group].push(serializableEntry(entry))
    preview.entries = CATALOG_GROUPS.flatMap(group => preview.groups[group])
    preview.items = [...preview.entries]
    preview.counts = Object.fromEntries(CATALOG_GROUPS.map(group => [group, preview.groups[group].length]))
    preview.changed = changes
    return preview
  }
  await ensureCatalogDirectories(catalogRoot)
  // Remove duplicate/stale metadata files first. Source files are never part
  // of this loop: every path came from a catalog group's own directory.
  const desiredFiles = new Set()
  for (const entry of next.values()) {
    const target = join(catalogGroupRoot(catalogRoot, entry.group), entryFileNameFor(entry))
    desiredFiles.add(resolve(target))
  }
  for (const old of current.entries) {
    const oldPath = old._catalogFile
    if (!oldPath || desiredFiles.has(resolve(oldPath))) continue
    try { await unlink(oldPath) } catch (error) { if (error?.code !== 'ENOENT') throw error }
  }
  for (const entry of [...next.values()].sort(entrySort)) {
    const target = join(catalogGroupRoot(catalogRoot, entry.group), entryFileNameFor(entry))
    const previous = byPath.get(entry.relativePath)
    if (!previous || previous.group !== entry.group || !sameJson(previous, entry)) {
      await atomicWriteJson(target, serializableEntry(entry))
    }
  }
  const result = await readCatalog(root, config, { strict: options.strict !== false })
  result.changed = changes
  return result
}

export const syncWorkspaceCatalog = syncCatalog
export const updateCatalog = syncCatalog

/** Persist an already grouped catalog projection (metadata only). */
export async function writeCatalog(workspaceRoot, catalog, config = {}, options = {}) {
  const records = isRecord(catalog) && isRecord(catalog.groups)
    ? CATALOG_GROUPS.flatMap(group => (Array.isArray(catalog.groups[group])
      ? catalog.groups[group].map(entry => ({ ...entry, group }))
      : []))
    : recordsFromInput(catalog)
  return syncCatalog(workspaceRoot, records, config, options)
}

export const persistCatalog = writeCatalog

/**
 * Refresh source existence and lightweight stat metadata for current catalog
 * entries.  This is useful at idle boundaries when no fresh candidate list is
 * available. It performs lstat only and never reads, copies, moves or deletes
 * source files. Missing `to-delete` entries are intentionally retained until
 * a confirmed deletion workflow removes their metadata.
 */
export async function refreshCatalog(workspaceRoot, config = {}, options = {}) {
  const root = resolve(workspaceRoot)
  const current = await readCatalog(root, config, { strict: options.strict !== false })
  if (current.entries.length === 0) return { ...current, changed: { created: [], updated: [], moved: [], removed: [] } }
  const records = []
  for (const entry of current.entries) {
    const source = await inspectSource(root, entry.relativePath)
    const info = source.info
    records.push({
      ...serializableEntry(entry),
      sourceExists: source.sourceExists,
      status: source.sourceExists
        ? (entry.status === 'stale' ? 'pending' : entry.status)
        : 'stale',
      ...(source.sourceExists && info?.isFile() ? { size: info.size, mtimeMs: info.mtimeMs } : {}),
    })
  }
  return syncCatalog(root, records, config, options)
}

export const refreshWorkspaceCatalog = refreshCatalog

/** Upsert one metadata record; never touches its source file. */
export async function updateCatalogEntry(workspaceRoot, entry, config = {}, options = {}) {
  return syncCatalog(workspaceRoot, [entry], config, options)
}

function matchingEntries(catalog, relativePath) {
  const normalized = ensureCatalogRelativePath(relativePath, 'source relativePath')
  return catalog.entries.filter(entry => entry.relativePath === normalized)
}

/**
 * Remove metadata entries for a source path. This does not delete the source
 * file. Callers handling `to-delete` should pass `confirm:true` after the
 * source deletion succeeds, or use removeConfirmedCatalogEntry().
 */
export async function removeCatalogEntry(workspaceRoot, relativePath, config = {}, options = {}) {
  const root = resolve(workspaceRoot)
  const catalog = await readCatalog(root, config, { strict: options.strict !== false })
  const matches = matchingEntries(catalog, relativePath)
  if (options.requireConfirmation === true && matches.some(entry => entry.group === 'to-delete') && options.confirm !== true) {
    throw new CatalogError('removing a to-delete catalog entry requires confirmation', 'CONFIRMATION_REQUIRED')
  }
  if (matches.length === 0) return { ...catalog, removed: [] }
  const removed = matches.map(entry => entry.relativePath)
  if (options.dryRun === true) return { ...catalog, removed, dryRun: true }
  for (const entry of matches) {
    if (!entry._catalogFile) continue
    try { await unlink(entry._catalogFile) } catch (error) { if (error?.code !== 'ENOENT') throw error }
  }
  const result = await readCatalog(root, config, { strict: options.strict !== false })
  result.removed = removed
  return result
}

export async function removeCatalogEntries(workspaceRoot, relativePaths, config = {}, options = {}) {
  const paths = Array.isArray(relativePaths) ? relativePaths : [relativePaths]
  let result = await readCatalog(workspaceRoot, config, { strict: options.strict !== false })
  const removed = []
  for (const path of paths) {
    const one = await removeCatalogEntry(workspaceRoot, path, config, options)
    removed.push(...(one.removed ?? []))
    result = one
  }
  result.removed = [...new Set(removed)]
  return result
}

/** Explicit alias for the post-confirmation deletion workflow. */
export async function removeConfirmedCatalogEntry(workspaceRoot, relativePath, config = {}, options = {}) {
  return removeCatalogEntry(workspaceRoot, relativePath, config, {
    ...options,
    requireConfirmation: true,
    confirm: true,
  })
}

export const confirmCatalogDeletion = removeConfirmedCatalogEntry

export default {
  CATALOG_SCHEMA_VERSION,
  CATALOG_GROUPS,
  CatalogError,
  catalogEnabled,
  catalogRootFor,
  catalogEntryFileName,
  catalogEntryPath,
  groupForAction,
  actionForGroup,
  normalizeCatalogEntry,
  readCatalog,
  readWorkspaceCatalog,
  projectCatalog,
  syncCatalog,
  syncWorkspaceCatalog,
  updateCatalog,
  writeCatalog,
  persistCatalog,
  updateCatalogEntry,
  refreshCatalog,
  refreshWorkspaceCatalog,
  removeCatalogEntry,
  removeCatalogEntries,
  removeConfirmedCatalogEntry,
  confirmCatalogDeletion,
  workspaceArtifactsRootFor,
  workspaceArtifactsCatalogRoot,
}
