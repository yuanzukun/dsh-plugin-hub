/** Small path and cancellation helpers shared by the scanner and archive. */

import { realpath, stat } from 'node:fs/promises'
import { isAbsolute, relative, resolve, sep } from 'node:path'

/** Return true when target is root itself or a descendant of root. */
export function isInside(root, target) {
  const rootAbs = resolve(root)
  const targetAbs = resolve(target)
  const rel = relative(rootAbs, targetAbs)
  return rel === '' || (rel !== '..' && !rel.startsWith(`..${sep}`) && !isAbsolute(rel))
}

/** Throw when a path would leave the supplied root. */
export function assertInside(root, target, label = 'path') {
  if (!isInside(root, target)) {
    throw new Error(`${label} escapes workspace root: ${target}`)
  }
  return resolve(target)
}

/** Canonicalize an existing directory and reject files. */
export async function canonicalDirectory(input) {
  const canonical = await realpath(resolve(input))
  const info = await stat(canonical)
  if (!info.isDirectory()) throw new Error(`workspace root is not a directory: ${canonical}`)
  return canonical
}

/** Convert platform paths to stable manifest paths. */
export function toPosixPath(value) {
  // Normalize both separators regardless of the host platform. A plugin can
  // receive a Windows-style path from a model even when the Harness process
  // itself runs on POSIX; leaving `\\` intact would make traversal checks
  // platform-dependent.
  return String(value).replace(/\\/g, '/').split(sep).join('/')
}

/** Normalize a relative path and reject traversal. */
export function safeRelativePath(value) {
  if (typeof value !== 'string' || value.trim() === '') throw new Error('empty relative path')
  const normalized = toPosixPath(value.trim()).replace(/^\.\//, '')
  if (normalized === '' || normalized === '.') throw new Error('empty relative path')
  if (normalized.includes('\0')) throw new Error(`invalid relative path: ${value}`)
  // Reject POSIX roots, UNC paths and drive-qualified Windows paths before
  // splitting. `path.resolve()` treats these as absolute on their native
  // platform, so accepting them would defeat the workspace boundary.
  if (normalized.startsWith('/') || /^[A-Za-z]:/.test(normalized)) {
    throw new Error(`absolute path is not allowed: ${value}`)
  }
  const parts = normalized.split('/')
  if (parts.some(part => part === '..' || part === '')) {
    throw new Error(`invalid relative path: ${value}`)
  }
  const clean = parts.filter(part => part !== '.')
  if (clean.length === 0) throw new Error('empty relative path')
  return clean.join('/')
}

/** Throw if an operation was cancelled. Works with Node and simple test fakes. */
export function throwIfAborted(signal) {
  if (signal?.aborted) {
    const reason = signal.reason
    if (reason instanceof Error) throw reason
    throw new Error('operation aborted')
  }
}

/** Await a promise while preserving cancellation checks at task boundaries. */
export async function withAbort(promise, signal) {
  throwIfAborted(signal)
  const value = await promise
  throwIfAborted(signal)
  return value
}
