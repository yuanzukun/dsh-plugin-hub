import { createHash } from 'node:crypto'
import { createReadStream } from 'node:fs'
import { spawn } from 'node:child_process'
import { readFile, readdir, lstat, access } from 'node:fs/promises'
import { dirname, extname, join, delimiter } from 'node:path'
import { safePath } from './inventory.js'
import { SOURCE_EXTENSIONS } from './scan.js'

const SKIP = new Set(['.git', '.hg', '.svn', 'node_modules', '.venv', 'venv', '__pycache__'])
const TEXT = new Set([...SOURCE_EXTENSIONS, 'md', 'txt', 'rst', 'csv', 'tsv', 'html', 'css', 'json', 'yaml', 'yml', 'toml', 'sh', 'ps1', 'log', 'xml', 'ini'])

/** Reference inspection fails closed if the complete project evidence exceeds its budget. */
export async function projectEvidence(root, config) {
  const files = new Map()
  const texts = new Map()
  let textBytes = 0
  const maxFiles = config.maxVerificationFiles ?? 10000
  const maxTextBytes = config.maxReferenceBytes ?? 128 * 1024 * 1024
  async function walk(path = '') {
    const absolute = await safePath(root, path)
    for (const entry of await readdir(absolute, { withFileTypes: true })) {
      const rel = path ? `${path}/${entry.name}` : entry.name
      if (rel === config.stateDir || rel.startsWith(`${config.stateDir}/`) || rel === config.catalogRoot || rel.startsWith(`${config.catalogRoot}/`) || SKIP.has(entry.name)) continue
      if (entry.isSymbolicLink()) { files.set(rel, 'symlink'); continue }
      if (entry.isDirectory()) { await walk(rel); continue }
      if (!entry.isFile()) continue
      const safe = await safePath(root, rel)
      const stat = await lstat(safe)
      if (files.size >= maxFiles) throw new Error(`校验文件数超过 ${maxFiles}，请调整 maxVerificationFiles 或缩小工作区。`)
      const textual = TEXT.has(extname(rel).slice(1).toLowerCase()) || !extname(rel)
      if (textual && textBytes + stat.size > maxTextBytes) throw new Error(`引用检查的文本总量超过 ${maxTextBytes} 字节，请调整 maxReferenceBytes 或缩小工作区。`)
      const hash = createHash('sha256')
      const chunks = []
      let readBytes = 0
      for await (const chunk of createReadStream(safe)) {
        hash.update(chunk)
        readBytes += chunk.length
        if (textual) {
          if (textBytes + readBytes > maxTextBytes) throw new Error('引用检查期间文本增长并超过 maxReferenceBytes。')
          chunks.push(chunk)
        }
      }
      await safePath(root, rel)
      const after = await lstat(safe)
      if (after.size !== stat.size || after.mtimeMs !== stat.mtimeMs || readBytes !== stat.size) throw new Error(`校验时文件发生变化，请稍后重试：${rel}`)
      files.set(rel, hash.digest('hex'))
      if (textual) {
        textBytes += readBytes
        const content = Buffer.concat(chunks)
        if (!content.includes(0)) texts.set(rel, content.toString('utf8'))
      }
    }
  }
  await walk()
  return { files, texts }
}

export function referenceBlocks(candidates, evidence) {
  const blocked = []
  const eligible = []
  for (const entry of candidates) {
    const name = entry.relativePath.split('/').at(-1)
    const references = []
    for (const [path, content] of evidence.texts) {
      if (path !== entry.relativePath && (content.includes(entry.relativePath) || content.includes(name))) references.push(path)
    }
    if (references.length) blocked.push({ path: entry.relativePath, reason: 'referenced-by-project', references: references.slice(0, 10) })
    else eligible.push(entry)
  }
  return { eligible, blocked }
}

export function changedEvidence(before, after, movedPaths = new Set()) {
  const changed = []
  for (const [path, digest] of before.files) {
    if (!movedPaths.has(path) && after.files.get(path) !== digest) changed.push(path)
  }
  return changed
}

export async function findNodeCli(name, configured) {
  const candidates = [configured, ...(name === 'dsh' && /[\\/]dsh[\\/]lib[\\/]bin\.js$/.test(process.argv[1] ?? '') ? [process.argv[1]] : [])]
  const suffix = name === 'npm' ? ['node_modules', 'npm', 'bin', 'npm-cli.js'] : ['node_modules', '@deepseek-ai', 'dsh', 'lib', 'bin.js']
  for (const directory of [dirname(process.execPath), ...(process.env.PATH ?? '').split(delimiter)]) {
    candidates.push(join(directory, ...suffix))
  }
  for (const candidate of candidates.filter(Boolean)) { try { await access(candidate); return candidate } catch {} }
  throw new Error(`${name} Node CLI was not found${name === 'dsh' ? '; set reviewerCli to the installed dsh/lib/bin.js' : ''}`)
}

export async function runCommand(command, args, { cwd, timeout = 120000, signal, maxOutput = 12000, env } = {}) {
  if (command === 'npm' || command === 'npm.cmd') { args = [await findNodeCli('npm'), ...args]; command = process.execPath }
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, shell: false, windowsHide: true, detached: process.platform !== 'win32', stdio: ['ignore', 'pipe', 'pipe'], env: env ?? process.env })
    let output = ''
    let timedOut = false
    const collect = data => { output = (output + data.toString()).slice(-maxOutput) }
    child.stdout.on('data', collect)
    child.stderr.on('data', collect)
    let stopping = false
    const stop = () => {
      if (stopping || !child.pid) return
      stopping = true
      // Kill the tree while its root still exists, so grandchildren cannot be orphaned.
      if (process.platform === 'win32') {
        const killer = spawn('taskkill', ['/pid', String(child.pid), '/t', '/f'], { windowsHide: true, stdio: 'ignore' })
        killer.on('error', () => child.kill())
        killer.on('exit', code => { if (code !== 0) child.kill() })
      } else { try { process.kill(-child.pid, 'SIGKILL') } catch { child.kill('SIGKILL') } }
    }
    const timer = setTimeout(() => { timedOut = true; stop() }, timeout)
    const abort = () => stop()
    signal?.addEventListener('abort', abort, { once: true })
    if (signal?.aborted) stop()
    child.once('error', error => { clearTimeout(timer); signal?.removeEventListener('abort', abort); reject(error) })
    child.once('close', code => {
      clearTimeout(timer)
      signal?.removeEventListener('abort', abort)
      resolve({ ok: code === 0 && !timedOut && !signal?.aborted, code, timedOut, output })
    })
  })
}

export async function verificationCommands(root, config) {
  if (config.verificationCommands.length) return config.verificationCommands
  try {
    const path = await safePath(root, 'package.json')
    const pkg = JSON.parse(await readFile(path, 'utf8'))
    if (pkg.scripts?.test && !pkg.scripts.test.includes('no test specified')) return [{ command: 'npm', args: ['test'] }]
  } catch (error) { if (error.code !== 'ENOENT') throw error }
  return []
}

export async function runChecks(root, config, commands, signal) {
  const results = []
  for (const command of commands) {
    const result = await runCommand(command.command, command.args, { cwd: root, timeout: config.verificationTimeoutMs, signal })
    results.push({ command: [command.command, ...command.args].join(' '), ...result })
    if (!result.ok) break
  }
  return { ok: results.every(result => result.ok), results, coverage: commands.length ? 'project-checks' : 'static-only' }
}
