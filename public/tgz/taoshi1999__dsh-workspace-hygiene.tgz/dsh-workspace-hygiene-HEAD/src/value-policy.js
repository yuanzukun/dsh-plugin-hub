/**
 * Small, deterministic value policy for workspace artifacts.
 *
 * The scanner can tell that a file looks generated, but a useful hygiene
 * decision also needs to answer a second question: should the file be kept,
 * reviewed, archived, or deleted?  This module keeps that decision explicit
 * and inspectable.  Operators may provide path/name rules; the fallback
 * signals are intentionally modest and are never presented as certainty.
 *
 * This module has no filesystem or Harness dependencies.  Keeping it pure
 * makes the policy easy to test, explain in a UI, and replace with a learned
 * policy in future research without changing the transaction layer.
 */

import { extname } from 'node:path'
import { safeRelativePath, toPosixPath } from './path-utils.js'

export const VALUE_CLASSES = Object.freeze([
  'protected',
  'valuable',
  'intermediate',
  'disposable',
  'uncertain',
])

export const VALUE_ACTIONS = Object.freeze([
  'retain',
  'archive',
  'delete',
  'review',
])

/** Defaults are deliberately conservative: no permanent delete is enabled. */
export const DEFAULT_VALUE_POLICY = Object.freeze({
  enabled: true,
  retainThreshold: 70,
  deleteThreshold: 20,
  archiveThreshold: 45,
  defaultAction: 'review',
  allowDelete: false,
  deleteRequiresConfirmation: true,
  retainPatterns: Object.freeze([]),
  discardPatterns: Object.freeze([]),
  retainNames: Object.freeze([]),
  discardNames: Object.freeze([]),
  retainExtensions: Object.freeze([]),
  discardExtensions: Object.freeze([]),
  retainDirectories: Object.freeze([]),
  discardDirectories: Object.freeze([]),
  organization: Object.freeze({
    enabled: true,
    // `root` is a metadata catalog namespace. It never contains the source
    // artifacts themselves; each entry records the source path, name, purpose
    // and recommended handling.
    root: 'workspace-artifacts',
    retainDirectory: 'retained',
    archiveDirectory: 'intermediate',
    reviewDirectory: 'review',
    deleteDirectory: 'to-delete',
    namingTemplate: '{date}-{stem}{ext}',
    // Physical file moves are opt-in. An autonomous deployment can enable
    // this when it wants the plugin to apply suggested source paths too.
    moveFiles: false,
    // Empty keeps a suggested source file in its original parent directory;
    // a relative path chooses a separate physical organization namespace.
    fileRoot: '',
  }),
})

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

// classifyValue() is called once per scanned file, so it uses a fast path for
// the immutable object returned by normalizeValuePolicy().  Checking only one
// threshold here is too weak: a caller can pass `{ retainThreshold: 70 }`
// (or another partially shaped object), which would make the classifier try
// to call `.find()` on an absent rule list. Keep the fast path explicit and
// fall back to the normalizer for every partial/raw policy.
const POLICY_LIST_KEYS = Object.freeze([
  'retainPatterns', 'discardPatterns', 'retainNames', 'discardNames',
  'retainExtensions', 'discardExtensions', 'retainDirectories',
  'discardDirectories',
])

const ORGANIZATION_KEYS = Object.freeze([
  'root', 'retainDirectory', 'archiveDirectory', 'reviewDirectory',
  'deleteDirectory', 'namingTemplate', 'fileRoot',
])

function isNormalizedValuePolicy(value) {
  if (!isRecord(value)
    || !Object.isFrozen(value)
    || typeof value.enabled !== 'boolean'
    || !Number.isFinite(value.retainThreshold)
    || value.retainThreshold < 0 || value.retainThreshold > 100
    || !Number.isFinite(value.deleteThreshold)
    || value.deleteThreshold < 0 || value.deleteThreshold > 100
    || !Number.isFinite(value.archiveThreshold)
    || value.archiveThreshold < 0 || value.archiveThreshold > 100
    || value.deleteThreshold > value.archiveThreshold
    || value.archiveThreshold > value.retainThreshold
    || !VALUE_ACTIONS.includes(value.defaultAction)
    || typeof value.allowDelete !== 'boolean'
    || typeof value.deleteRequiresConfirmation !== 'boolean'
    || !isRecord(value.organization)
    || typeof value.organization.enabled !== 'boolean') {
    return false
  }
  if (!POLICY_LIST_KEYS.every(key => Array.isArray(value[key])
    && Object.isFrozen(value[key])
    && value[key].every(item => typeof item === 'string'))) return false
  if (!Object.isFrozen(value.organization)) return false
  if (!ORGANIZATION_KEYS.every(key => typeof value.organization[key] === 'string')) return false
  if (typeof value.organization.moveFiles !== 'boolean') return false
  try {
    for (const key of ORGANIZATION_KEYS) {
      if (key === 'namingTemplate') continue
      organizationPath(value.organization[key], value.organization[key], `organization.${key}`)
    }
  } catch {
    return false
  }
  return true
}

function resolveValuePolicy(policyInput) {
  return isNormalizedValuePolicy(policyInput)
    ? policyInput
    : normalizeValuePolicy(policyInput)
}

function asList(value) {
  if (!Array.isArray(value)) return []
  return value
    .filter(item => typeof item === 'string' && item.trim() !== '')
    .map(item => item.trim())
}

function asLowerList(value) {
  return asList(value).map(item => item.toLowerCase())
}

function asPatterns(value) {
  return asList(value).map(item => {
    const normalized = toPosixPath(item).replace(/^\.\//, '').replace(/\/+$/g, '')
    if (normalized.startsWith('/') || /^[A-Za-z]:\//.test(normalized)
      || !normalized
      || normalized.split('/').some(part => part === '' || part === '..')) {
      throw new Error(`value policy pattern must stay inside the workspace: ${item}`)
    }
    return normalized
  })
}

function boundedNumber(value, fallback, min = 0, max = 100) {
  if (value === undefined || value === null || value === '') return fallback
  const number = Number(value)
  if (!Number.isFinite(number)) return fallback
  return Math.max(min, Math.min(max, number))
}

function booleanOr(value, fallback) {
  return typeof value === 'boolean' ? value : fallback
}

function organizationPath(value, fallback, label) {
  const raw = String(value ?? fallback).trim().replace(/\\/g, '/')
  if (raw.startsWith('/') || /^[A-Za-z]:\//.test(raw) || raw.startsWith('~')) {
    throw new Error(`${label} must be a workspace-relative path: ${value}`)
  }
  const text = raw.replace(/\/+$/g, '')
  if (!text) return fallback
  try {
    return safeRelativePath(text)
  } catch {
    throw new Error(`${label} must be a safe workspace-relative path: ${value}`)
  }
}

/**
 * Normalize the operator-facing policy.  A few friendly aliases are accepted
 * so a profile can say `keepPatterns`/`deletePatterns` without introducing a
 * second policy implementation.  The returned object is safe to include in
 * a plan fingerprint.
 */
export function normalizeValuePolicy(input = {}) {
  const outer = isRecord(input) ? input : {}
  const source = isRecord(outer.valuePolicy) ? outer.valuePolicy : outer
  const rules = isRecord(source.rules) ? source.rules : {}
  const organizationInput = isRecord(source.organization)
    ? source.organization
    : isRecord(source.organize)
      ? source.organize
      : isRecord(outer.organization)
        ? outer.organization
        : (isRecord(outer.organize) ? outer.organize : {})

  const pick = (...keys) => {
    for (const key of keys) {
      if (source[key] !== undefined) return source[key]
      if (rules[key] !== undefined) return rules[key]
      // Keep the standalone helper friendly when callers provide a nested
      // valuePolicy plus a top-level alias (for example
      // `{ valuePolicy: { discardPatterns: [...] }, allowDelete: true }`).
      if (outer[key] !== undefined) return outer[key]
    }
    return undefined
  }

  const organization = {
    enabled: booleanOr(organizationInput.enabled, DEFAULT_VALUE_POLICY.organization.enabled),
    root: organizationPath(organizationInput.root ?? pick('organizationRoot')
      ?? DEFAULT_VALUE_POLICY.organization.root, DEFAULT_VALUE_POLICY.organization.root, 'organization.root'),
    retainDirectory: organizationPath(organizationInput.retainDirectory
      ?? organizationInput.keepDirectory
      ?? DEFAULT_VALUE_POLICY.organization.retainDirectory,
    DEFAULT_VALUE_POLICY.organization.retainDirectory, 'organization.retainDirectory'),
    archiveDirectory: organizationPath(organizationInput.archiveDirectory
      ?? organizationInput.intermediateDirectory
      ?? DEFAULT_VALUE_POLICY.organization.archiveDirectory,
    DEFAULT_VALUE_POLICY.organization.archiveDirectory, 'organization.archiveDirectory'),
    reviewDirectory: organizationPath(organizationInput.reviewDirectory
      ?? DEFAULT_VALUE_POLICY.organization.reviewDirectory,
    DEFAULT_VALUE_POLICY.organization.reviewDirectory, 'organization.reviewDirectory'),
    deleteDirectory: organizationPath(organizationInput.deleteDirectory
      ?? organizationInput.discardDirectory
      ?? DEFAULT_VALUE_POLICY.organization.deleteDirectory,
    DEFAULT_VALUE_POLICY.organization.deleteDirectory, 'organization.deleteDirectory'),
    namingTemplate: String(organizationInput.namingTemplate
      ?? organizationInput.nameTemplate
      ?? pick('namingTemplate', 'nameTemplate')
      ?? DEFAULT_VALUE_POLICY.organization.namingTemplate).trim()
      || DEFAULT_VALUE_POLICY.organization.namingTemplate,
    moveFiles: booleanOr(organizationInput.moveFiles
      ?? organizationInput.organizeFiles,
    DEFAULT_VALUE_POLICY.organization.moveFiles),
    fileRoot: organizationPath(organizationInput.fileRoot
      ?? organizationInput.sourceRoot
      ?? DEFAULT_VALUE_POLICY.organization.fileRoot,
    DEFAULT_VALUE_POLICY.organization.fileRoot, 'organization.fileRoot'),
  }

  // Empty rule lists are meaningful (they disable a rule), so they do not
  // fall back to candidate defaults here.  The scanner supplies its existing
  // candidate extension list as a separate heuristic signal.
  const normalized = {
    enabled: booleanOr(pick('enabled'), DEFAULT_VALUE_POLICY.enabled),
    retainThreshold: boundedNumber(pick('retainThreshold', 'keepThreshold'),
      DEFAULT_VALUE_POLICY.retainThreshold),
    deleteThreshold: boundedNumber(pick('deleteThreshold', 'discardThreshold'),
      DEFAULT_VALUE_POLICY.deleteThreshold),
    archiveThreshold: boundedNumber(pick('archiveThreshold'),
      DEFAULT_VALUE_POLICY.archiveThreshold),
    defaultAction: VALUE_ACTIONS.includes(pick('defaultAction'))
      ? pick('defaultAction')
      : DEFAULT_VALUE_POLICY.defaultAction,
    allowDelete: booleanOr(pick('allowDelete', 'deleteEnabled', 'permanentDelete'),
      DEFAULT_VALUE_POLICY.allowDelete),
    deleteRequiresConfirmation: booleanOr(pick('deleteRequiresConfirmation'),
      DEFAULT_VALUE_POLICY.deleteRequiresConfirmation),
    retainPatterns: asPatterns(pick('retainPatterns', 'keepPatterns', 'valuablePatterns')),
    discardPatterns: asPatterns(pick('discardPatterns', 'deletePatterns', 'removePatterns', 'worthlessPatterns')),
    retainNames: asLowerList(pick('retainNames', 'keepNames', 'valuableNames')),
    discardNames: asLowerList(pick('discardNames', 'deleteNames', 'removeNames')),
    retainExtensions: asLowerList(pick('retainExtensions', 'keepExtensions', 'valuableExtensions'))
      .map(item => item.replace(/^\./, '')),
    discardExtensions: asLowerList(pick('discardExtensions', 'deleteExtensions', 'removeExtensions', 'disposableExtensions'))
      .map(item => item.replace(/^\./, '')),
    retainDirectories: asPatterns(pick('retainDirectories', 'keepDirectories', 'valuableDirectories')),
    discardDirectories: asPatterns(pick('discardDirectories', 'deleteDirectories', 'removeDirectories', 'disposableDirectories')),
    organization,
  }

  // Keep threshold ordering sensible even when a profile contains a typo.
  normalized.deleteThreshold = Math.min(normalized.deleteThreshold, normalized.archiveThreshold)
  normalized.archiveThreshold = Math.max(normalized.deleteThreshold, normalized.archiveThreshold)
  normalized.retainThreshold = Math.max(normalized.archiveThreshold, normalized.retainThreshold)
  return Object.freeze({
    ...normalized,
    retainPatterns: Object.freeze(normalized.retainPatterns),
    discardPatterns: Object.freeze(normalized.discardPatterns),
    retainNames: Object.freeze(normalized.retainNames),
    discardNames: Object.freeze(normalized.discardNames),
    retainExtensions: Object.freeze(normalized.retainExtensions),
    discardExtensions: Object.freeze(normalized.discardExtensions),
    retainDirectories: Object.freeze(normalized.retainDirectories),
    discardDirectories: Object.freeze(normalized.discardDirectories),
    organization: Object.freeze(organization),
  })
}

function globToRegExp(pattern) {
  const normalized = toPosixPath(String(pattern).trim())
    .replace(/^\.\//, '').replace(/^\/+/, '').replace(/\/+$/, '')
  if (!normalized) return /^$/
  let source = ''
  for (let index = 0; index < normalized.length; index += 1) {
    const char = normalized[index]
    const next = normalized[index + 1]
    if (char === '*' && next === '*' && normalized[index + 2] === '/') {
      source += '(?:.*/)?'
      index += 2
    } else if (char === '*' && next === '*') {
      source += '.*'
      index += 1
    } else if (char === '*') {
      source += '[^/]*'
    } else if (char === '?') {
      source += '[^/]'
    } else {
      source += char.replace(/[\\^$+.()|{}[\]]/g, '\\$&')
    }
  }
  return new RegExp(`^(?:${source})(?:/.*)?$`, 'i')
}

function matchesPattern(relativePath, pattern) {
  try {
    const path = toPosixPath(relativePath).replace(/^\.\//, '').replace(/\/+$/, '')
    return globToRegExp(pattern).test(path)
  } catch {
    return false
  }
}

function matchesAny(relativePath, patterns) {
  return patterns.find(pattern => matchesPattern(relativePath, pattern))
}

function matchesDirectory(relativePath, directories) {
  const path = toPosixPath(relativePath).replace(/^\.\//, '')
  const parts = path.split('/').filter(Boolean)
  // Directory rules accept either a literal component (`tmp`) or a path/glob
  // (`results/final/**`).
  for (const directory of directories) {
    const normalized = toPosixPath(directory).replace(/^\.\//, '').replace(/\/+$/, '')
    if (!normalized) continue
    if (normalized.includes('*') || normalized.includes('?')) {
      if (matchesPattern(path, normalized)) return directory
      continue
    }
    if (parts.some((_, index) => parts.slice(0, index + 1).join('/') === normalized)) return directory
    if (parts.some(part => part.toLowerCase() === normalized.toLowerCase())) return directory
  }
  return undefined
}

function extensionOf(name, relativePath) {
  const base = String(name ?? relativePath ?? '').split('/').at(-1) ?? ''
  const extension = extname(base).toLowerCase()
  return extension.startsWith('.') ? extension.slice(1) : ''
}

function clampScore(value) {
  return Math.max(0, Math.min(100, Math.round(value)))
}

function addSignal(signals, reasons, key, amount, reason) {
  signals[key] = (signals[key] ?? 0) + amount
  if (reason && !reasons.includes(reason)) reasons.push(reason)
}

function safeStem(name) {
  const base = String(name ?? 'artifact').split('/').at(-1) ?? 'artifact'
  const extension = extname(base)
  const stem = extension ? base.slice(0, -extension.length) : base
  return { stem, extension }
}

function slug(value, fallback = 'artifact') {
  const cleaned = String(value ?? '')
    .normalize('NFKC')
    // Keep letters and numbers from any script so a suggested name remains
    // recognisable to the person who created the artifact (for example,
    // `训练日志.log` should not collapse to the opaque `artifact.log`).
    .replace(/[^\p{L}\p{M}\p{N}._-]+/gu, '-')
    .replace(/-{2,}/g, '-')
    .replace(/^[.-]+|[.-]+$/g, '')
  return cleaned || fallback
}

function datePart(input) {
  const timestamp = Number(input?.mtimeMs)
  const date = Number.isFinite(timestamp) ? new Date(timestamp) : new Date()
  return date.toISOString().slice(0, 10)
}

/**
 * Suggest a stable, human-readable destination and name.  This is advisory:
 * callers may put it in a plan or report without creating directories.
 */
export function suggestOrganization(input = {}, policyInput = {}) {
  const policy = resolveValuePolicy(policyInput)
  const organization = policy.organization ?? DEFAULT_VALUE_POLICY.organization
  const action = VALUE_ACTIONS.includes(input.action) ? input.action : 'review'
  const directoryName = action === 'retain'
    ? organization.retainDirectory
    : action === 'archive'
      ? organization.archiveDirectory
      : action === 'delete'
        ? organization.deleteDirectory
        : organization.reviewDirectory
  // Keep the source location separate from the catalog location.  The public
  // `suggestedPath` field historically referred to the category entry under
  // `workspace-artifacts/`; retain that meaning for existing integrations,
  // while exposing `suggestedSourcePath`/`physicalSuggestedPath` for callers
  // that may actually organize a source file.  This distinction is important:
  // a catalog path is metadata, never a file-move destination.
  let relativePath = toPosixPath(String(input.relativePath ?? input.name ?? 'artifact'))
    .replace(/^\.\//, '')
  try {
    relativePath = safeRelativePath(relativePath)
  } catch {
    // Suggestions are advisory, but they must never display traversal or an
    // absolute path.  Upstream scanners validate paths; this fallback keeps
    // direct helper calls safe as well.
    relativePath = 'artifact'
  }
  const { stem, extension } = safeStem(input.name ?? relativePath)
  const original = relativePath.split('/').at(-1) ?? 'artifact'
  const sourceDirectory = relativePath.includes('/')
    ? relativePath.slice(0, relativePath.lastIndexOf('/'))
    : '.'
  const values = {
    category: action,
    date: datePart(input),
    stem: slug(stem),
    ext: extension,
    original: slug(original),
    hash8: String(input.sha256 ?? input.hash ?? '').slice(0, 8),
  }
  let name = typeof organization.namingTemplate === 'string' && organization.namingTemplate.trim() !== ''
    ? organization.namingTemplate
    : DEFAULT_VALUE_POLICY.organization.namingTemplate
  name = name.replace(/\{(category|date|stem|ext|original|hash8)\}/g,
    (_match, key) => values[key] ?? '')
  name = name.replace(/[\\/]+/g, '-').replace(/^-+|-+$/g, '')
  if (!name) name = `${values.date}-${values.stem}${values.ext}`
  // Preserve a source extension when a template omitted `{ext}`. Do not add
  // one when the source itself had no extension.
  if (extension && !name.toLowerCase().endsWith(extension.toLowerCase())) name += extension
  // Re-validate even when a caller passes an already-shaped policy object
  // (the fast path used by the scanner). This keeps the suggestion safe to
  // display and prevents a future organizer from inheriting `..` or absolute
  // destination components from a hand-built policy.
  const root = organizationPath(organization.root, DEFAULT_VALUE_POLICY.organization.root, 'organization.root')
  const directory = organizationPath(directoryName || action, action, 'organization directory')
  const catalogDirectory = [root, directory].filter(Boolean).join('/')
  const suggestedName = slug(name)

  // Physical organization is opt-in.  With an empty `fileRoot`, the
  // original parent directory is retained and only the name is normalised.
  // A configured `fileRoot` creates a clearly separated physical namespace;
  // category directories there use the same stable names as the catalog.
  const fileRoot = organizationPath(
    organization.fileRoot,
    DEFAULT_VALUE_POLICY.organization.fileRoot,
    'organization.fileRoot',
  )
  const suggestedDirectory = fileRoot
    ? [fileRoot, directory].filter(Boolean).join('/')
    : sourceDirectory
  const suggestedSourcePath = [suggestedDirectory === '.' ? '' : suggestedDirectory, suggestedName]
    .filter(Boolean).join('/')
  const suggestedPath = [catalogDirectory, suggestedName].filter(Boolean).join('/')
  const moveFiles = organization.moveFiles === true
  return {
    enabled: organization.enabled !== false,
    category: action,
    // `targetDirectory` remains as a compatibility alias, but it is now
    // unambiguously the metadata catalog directory rather than a source-file
    // destination.  New consumers should prefer `catalogDirectory`.
    targetDirectory: catalogDirectory,
    catalogRoot: root,
    catalogDirectory,
    sourceDirectory,
    sourceName: original,
    suggestedDirectory,
    suggestedName,
    suggestedPath,
    // Explicit names make it difficult for a consumer to accidentally pass a
    // metadata path to a filesystem operation.  Keep both aliases because
    // early development builds used `physicalSuggestedPath`.
    suggestedSourcePath,
    physicalSuggestedPath: suggestedSourcePath,
    fileRoot,
    moveFiles,
    reason: moveFiles
      ? `group ${action} artifacts in catalog under ${catalogDirectory}; if approved, organize source files under ${suggestedDirectory || '.'}`
      : `group ${action} artifacts in catalog under ${catalogDirectory}; keep the source in place unless organization is explicitly enabled`,
  }
}

/** Alias with a name that reads naturally in consumers. */
export const organizationSuggestion = suggestOrganization

/**
 * Classify one file using explicit operator rules plus bounded metadata
 * signals.  Higher scores mean "more valuable to keep".  The result always
 * contains both `recommendation` and `action`; these are aliases by design so
 * older integrations can use either vocabulary.
 */
export function classifyValue(input = {}, policyInput = {}, context = {}) {
  const policy = resolveValuePolicy(policyInput)
  const relativePath = toPosixPath(String(input.relativePath ?? input.path ?? input.name ?? ''))
    .replace(/^\.\//, '')
  const name = String(input.name ?? relativePath.split('/').at(-1) ?? '')
  const lowerName = name.toLowerCase()
  const extension = extensionOf(name, relativePath)
  const reasons = []
  const signals = {}

  const retainPattern = matchesAny(relativePath, policy.retainPatterns)
  const discardPattern = matchesAny(relativePath, policy.discardPatterns)
  const retainDirectory = matchesDirectory(relativePath, policy.retainDirectories)
  const discardDirectory = matchesDirectory(relativePath, policy.discardDirectories)
  const explicitRetain = Boolean(retainPattern || retainDirectory || policy.retainNames.includes(lowerName)
    || policy.retainExtensions.includes(extension))
  const explicitDiscard = Boolean(discardPattern || discardDirectory || policy.discardNames.includes(lowerName)
    || policy.discardExtensions.includes(extension))
  const conflictingRules = explicitRetain && explicitDiscard

  // Hard protection is a value decision too: preserving a secret or source
  // file is more important than any disposable-looking filename signal.
  const protectedInput = input.protected === true || input.kind === 'protected'
    || input.tracked === true || input.policyProtected === true
  if (protectedInput) {
    reasons.push(input.tracked ? 'git-tracked' : 'protected-by-policy')
    if (conflictingRules) reasons.push('conflicting-retain-discard-rules')
    const organization = suggestOrganization({ ...input, relativePath, name, action: 'retain' }, policy)
    return {
      valueScore: 100,
      valueClass: 'protected',
      recommendation: 'retain',
      action: 'retain',
      execution: 'skip',
      decisionSource: 'protection',
      reasons,
      signals: { protected: 100 },
      organization,
    }
  }

  // A disabled value policy must not silently fall back to heuristic delete
  // recommendations. Keep the hard-protection branch above unconditional,
  // then make every other item explicitly review-only until the operator
  // enables the policy again.
  if (policy.enabled === false) {
    const organization = suggestOrganization({ ...input, relativePath, name, action: 'review' }, policy)
    return {
      valueScore: 50,
      valueClass: 'uncertain',
      recommendation: 'review',
      action: 'review',
      execution: 'skip',
      decisionSource: 'disabled',
      reasons: ['value-policy-disabled'],
      signals: {},
      organization,
    }
  }

  let score = 50
  if (explicitRetain) {
    addSignal(signals, reasons, 'explicitRetain', 50, 'explicit-retain-rule')
  }
  if (explicitDiscard) {
    addSignal(signals, reasons, 'explicitDiscard', -50, 'explicit-discard-rule')
  }
  if (conflictingRules) {
    // Retain wins a conflict because it is the reversible, data-preserving
    // outcome. Keep the conflict visible so the operator can repair the
    // profile instead of mistaking precedence for agreement.
    addSignal(signals, reasons, 'conflictingRules', 0, 'conflicting-retain-discard-rules')
  }
  if (policy.retainExtensions.includes(extension)) {
    addSignal(signals, reasons, 'valuableExtension', 25, `valuable-extension:.${extension}`)
  }
  if (Array.isArray(context.valuableExtensions)
    && context.valuableExtensions.map(String).map(item => item.toLowerCase().replace(/^\./, '')).includes(extension)) {
    addSignal(signals, reasons, 'valuableExtension', 20, `project-valuable-extension:.${extension}`)
  }
  if (context.sourceExtension === true || input.sourceExtension === true) {
    addSignal(signals, reasons, 'source', 35, 'source-or-config-extension')
  }
  if (/^(?:final|release|baseline|reference|gold|important|canonical)[-_.]/i.test(name)
    || /(?:^|[-_.])(?:final|release|baseline|reference|gold|important|canonical)(?:[-_.]|$)/i.test(name)) {
    addSignal(signals, reasons, 'semanticName', 15, 'valuable-name-signal')
  }
  if (policy.discardExtensions.includes(extension)) {
    addSignal(signals, reasons, 'explicitDisposableExtension', -40, `disposable-extension:.${extension}`)
  }
  const candidateExtensions = Array.isArray(context.candidateExtensions)
    ? context.candidateExtensions.map(String).map(item => item.toLowerCase().replace(/^\./, ''))
    : []
  if (candidateExtensions.includes(extension)) {
    addSignal(signals, reasons, 'disposableExtension', -30, `generated-extension:.${extension}`)
  }
  if (input.generatedPrefix === true) {
    addSignal(signals, reasons, 'generatedPrefix', -24, 'generated-prefix')
  }
  if (input.generatedName === true) {
    addSignal(signals, reasons, 'generatedName', -14, 'generated-name')
  }
  if (input.artifactDirectory === true) {
    addSignal(signals, reasons, 'artifactDirectory', -16, 'artifact-directory')
  }
  if (input.marker === true) {
    addSignal(signals, reasons, 'generatedMarker', -12, 'generated-marker')
  }
  const ageHours = Number(input.ageHours)
  if (Number.isFinite(ageHours) && ageHours >= 168) {
    addSignal(signals, reasons, 'stale', -8, 'older-than-one-week')
  } else if (Number.isFinite(ageHours) && ageHours >= 24) {
    addSignal(signals, reasons, 'stale', -3, 'older-than-one-day')
  }

  score = clampScore(score + Object.values(signals).reduce((sum, value) => sum + value, 0))
  let valueClass
  let recommendation
  let decisionSource = 'heuristic'
  if (explicitRetain) {
    valueClass = 'valuable'
    recommendation = 'retain'
    decisionSource = 'explicit'
  } else if (explicitDiscard) {
    valueClass = 'disposable'
    recommendation = 'delete'
    decisionSource = 'explicit'
  } else if (score >= policy.retainThreshold) {
    valueClass = 'valuable'
    recommendation = 'retain'
  } else if (score <= policy.deleteThreshold) {
    valueClass = 'disposable'
    recommendation = 'delete'
  } else if (score <= policy.archiveThreshold || input.kind === 'candidate') {
    valueClass = 'intermediate'
    recommendation = 'archive'
  } else {
    valueClass = 'uncertain'
    recommendation = policy.defaultAction
  }

  const execution = recommendation === 'delete' && policy.allowDelete === true
    ? 'delete'
    : recommendation === 'delete'
      ? 'quarantine'
      : recommendation === 'archive'
        ? 'quarantine'
        : 'skip'
  const organization = suggestOrganization({ ...input, relativePath, name, action: recommendation }, policy)
  return {
    valueScore: score,
    valueClass,
    recommendation,
    action: recommendation,
    execution,
    decisionSource,
    reasons,
    signals,
    organization,
  }
}

/** Compact policy metadata suitable for a model-facing response. */
export function projectValuePolicy(policyInput = {}) {
  const policy = resolveValuePolicy(policyInput)
  return {
    enabled: policy.enabled,
    retainThreshold: policy.retainThreshold,
    archiveThreshold: policy.archiveThreshold,
    deleteThreshold: policy.deleteThreshold,
    defaultAction: policy.defaultAction,
    allowDelete: policy.allowDelete,
    deleteRequiresConfirmation: policy.deleteRequiresConfirmation,
    retainPatterns: [...policy.retainPatterns].slice(0, 100),
    discardPatterns: [...policy.discardPatterns].slice(0, 100),
    retainExtensions: [...policy.retainExtensions].slice(0, 100),
    discardExtensions: [...policy.discardExtensions].slice(0, 100),
    retainDirectories: [...policy.retainDirectories].slice(0, 100),
    discardDirectories: [...policy.discardDirectories].slice(0, 100),
    organization: { ...policy.organization },
  }
}

export const scoreArtifact = (input, policy, context) => classifyValue(input, policy, context).valueScore
export const recommendAction = (input, policy, context) => classifyValue(input, policy, context).recommendation

export default {
  VALUE_CLASSES,
  VALUE_ACTIONS,
  DEFAULT_VALUE_POLICY,
  normalizeValuePolicy,
  classifyValue,
  scoreArtifact,
  recommendAction,
  suggestOrganization,
  organizationSuggestion,
  projectValuePolicy,
}
