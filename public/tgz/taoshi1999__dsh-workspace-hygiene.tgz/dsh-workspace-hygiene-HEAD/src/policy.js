/**
 * Policy helpers shared by the scanner and transaction layer.
 *
 * The policy module is deliberately boring: it contains no filesystem writes
 * and has no knowledge of the Harness runtime.  Keeping these checks in one
 * place makes it easier to audit a plugin installation and to test the
 * dangerous edges (path traversal, protected names and policy drift).
 */

import { createHash } from 'node:crypto'
import { resolve } from 'node:path'
import { isProtectedArtifactName } from './config.js'
import { assertInside, isInside, safeRelativePath, toPosixPath } from './path-utils.js'

/**
 * Return a normalized list of workspace-relative roots that the plugin is
 * allowed to inspect.  An omitted or empty list means the whole workspace
 * (subject to the protected-directory checks in scan.js).  Supplying
 * managedRoots is the preferred way to narrow a policy for a shared
 * repository.
 */
export function managedRootsFor(workspaceRoot, config = {}) {
  const raw = Array.isArray(config.managedRoots) && config.managedRoots.length > 0
    ? config.managedRoots
    : []

  const roots = []
  for (const value of raw) {
    if (typeof value !== 'string' || value.trim() === '') continue
    const text = value.trim()
    // A managed root is intentionally workspace-relative by default.  An
    // absolute root is accepted only when explicitly enabled by the policy.
    if (text.startsWith('/') || /^[A-Za-z]:[\\/]/.test(text)) {
      if (!config.allowPathOverride) continue
      const absolute = resolve(text)
      roots.push(absolute)
      continue
    }
    try {
      const rel = safeRelativePath(text)
      const absolute = resolve(workspaceRoot, rel)
      if (isInside(workspaceRoot, absolute)) roots.push(absolute)
    } catch {
      // Invalid user policy entries are ignored here.  resolveConfig() is
      // responsible for reporting malformed scalar values; ignoring a single
      // managed root keeps a read-only scan safe and useful.
    }
  }
  return [...new Set(roots)]
}

/** Return true when a relative path is under one of the configured roots. */
export function isUnderManagedRoot(relativePath, config = {}) {
  const normalized = toPosixPath(relativePath).replace(/^\.\//, '').replace(/\/$/, '')
  const roots = Array.isArray(config.managedRoots) ? config.managedRoots : []
  if (roots.length === 0) return true
  return roots.some(root => {
    if (typeof root !== 'string' || root.trim() === '') return false
    const candidate = toPosixPath(root.trim()).replace(/^\.\//, '').replace(/\/$/, '')
    return normalized === candidate || normalized.startsWith(`${candidate}/`)
  })
}

/**
 * Return true when a path is beneath an explicitly configured managed root.
 * This is intentionally separate from isUnderManagedRoot(): an empty
 * managedRoots list means "the whole workspace", but it must not implicitly
 * override hidden/protected-directory safeguards.
 */
export function isExplicitlyManagedPath(relativePath, config = {}) {
  const normalized = toPosixPath(relativePath).replace(/^\.\//, '').replace(/\/$/, '')
  const roots = Array.isArray(config.managedRoots) ? config.managedRoots : []
  return roots.some(root => {
    if (typeof root !== 'string' || root.trim() === '') return false
    const candidate = toPosixPath(root.trim()).replace(/^\.\//, '').replace(/\/$/, '')
    if (candidate === '' || candidate.startsWith('/') || /^[A-Za-z]:\//.test(candidate)) return false
    try { safeRelativePath(candidate) } catch { return false }
    return normalized === candidate || normalized.startsWith(`${candidate}/`)
  })
}

// These directories contain repository metadata, dependency trees, or
// interpreter environments. A managed-root opt-in must not make them
// mutable by this plugin.
const NEVER_OVERRIDE_DIRECTORIES = new Set([
  '.git', '.hg', '.svn', 'node_modules', '.venv', 'venv',
])

/**
 * Check whether a workspace-relative path is protected by the policy.
 * Protected paths are skipped unless an operator explicitly places the path
 * under a managed root; repository metadata, dependency trees, and sensitive
 * names remain non-overridable. The check is lexical; callers must additionally
 * reject symlinks before performing a mutation.
 */
export function isProtectedRelativePath(relativePath, config = {}) {
  let normalized
  try {
    normalized = safeRelativePath(relativePath)
  } catch {
    return true
  }
  const parts = normalized.split('/').filter(Boolean)
  const lowerParts = parts.map(part => part.toLowerCase())
  const protectedDirectories = Array.isArray(config.protectedDirectories)
    ? config.protectedDirectories.map(value => String(value).toLowerCase())
    : []
  const protectedNames = Array.isArray(config.protectedNames)
    ? config.protectedNames.map(value => String(value).toLowerCase())
    : []
  const basename = lowerParts.at(-1) ?? ''
  // Keep the hard-coded credential/key guard in sync with the scanner. The
  // explicit list is still consulted for backwards-compatible custom names,
  // while obvious secret-looking names and key/certificate extensions remain
  // protected even if a caller replaces `protectedNames`.
  if (isProtectedArtifactName(basename, {
    protectedNames,
    protectedExtensions: Array.isArray(config.protectedExtensions)
      ? config.protectedExtensions.map(value => String(value).toLowerCase().replace(/^\./, ''))
      : [],
  })) return true

  const explicitlyManaged = isExplicitlyManagedPath(normalized, config)
  if (lowerParts.some(part => NEVER_OVERRIDE_DIRECTORIES.has(part))) return true
  // An explicit managed root is an operator-level opt-in. It may live under
  // a normally protected directory such as `.dsh` or `src`, but never under
  // the repository/dependency directories guarded above.
  if (lowerParts.some(part => protectedDirectories.includes(part)) && !explicitlyManaged) return true
  // Hidden trees are private by default.  A caller may opt in to a hidden
  // disposable file by setting allowHiddenCandidates. An explicitly managed
  // root is the other deliberate opt-in (for example `.dsh/ephemeral`).
  if (parts.some(part => part.startsWith('.')) && !config.allowHiddenCandidates && !explicitlyManaged) return true
  return false
}

/**
 * Assert that a candidate path is both inside the workspace and permitted by
 * the policy.  Returns a normalized absolute path for convenient chaining.
 */
export function assertManagedPath(workspaceRoot, relativePath, config = {}, label = 'path') {
  const rel = safeRelativePath(relativePath)
  if (!isUnderManagedRoot(rel, config)) {
    throw new Error(`${label} is outside managed roots: ${rel}`)
  }
  if (isProtectedRelativePath(rel, config)) {
    throw new Error(`${label} is protected by policy: ${rel}`)
  }
  return assertInside(workspaceRoot, resolve(workspaceRoot, rel), label)
}

/**
 * Build the immutable portion of a policy.  Excluding transient options such
 * as notifyAgent keeps plan tokens stable across harmless UI changes while
 * still invalidating a plan when safety boundaries or budgets change.
 */
export function policySnapshot(config = {}) {
  const keys = [
    'stateDir', 'archiveRoot', 'minAgeHours', 'maxScanFiles',
    'maxArchiveFiles', 'maxArchiveBytes', 'candidateExtensions',
    'candidateDirectories', 'protectedDirectories', 'protectedNames',
    'protectedExtensions',
    'managedRoots', 'allowPathOverride', 'allowHiddenCandidates',
    'valuePolicy', 'allowDelete',
  ]
  const snapshot = {}
  for (const key of keys) {
    const value = config[key]
    if (Array.isArray(value)) snapshot[key] = [...value].map(item => String(item)).sort()
    else if (value !== undefined) snapshot[key] = value
  }
  return snapshot
}

function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value)
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`
  return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`
}

/** SHA-256 fingerprint used to reject stale plans after policy changes. */
export function policyFingerprint(config = {}) {
  return createHash('sha256').update(stableStringify(policySnapshot(config))).digest('hex')
}

/**
 * Validate a destination root. An archive may be outside the workspace, but
 * it may never be the workspace itself, an ancestor containing the workspace,
 * or a path that overlaps an explicitly managed source root. Overlap would
 * make the scanner either inspect its own quarantine or skip source files.
 *
 * The optional config argument is intentionally accepted for compatibility
 * with callers that only need the workspace/ancestor check.
 */
export function assertArchiveRoot(workspaceRoot, archiveRoot, config = {}) {
  const root = resolve(workspaceRoot)
  const archive = resolve(archiveRoot)
  const reject = (message) => {
    const error = new Error(message)
    error.code = 'ARCHIVE_ROOT_INVALID'
    throw error
  }
  if (archive === root) reject('archive root cannot be the workspace root')
  if (isInside(archive, root)) {
    reject('archive root cannot contain the workspace root')
  }

  const managed = managedRootsFor(root, config)
  for (const sourceRoot of managed) {
    if (isInside(sourceRoot, archive) || isInside(archive, sourceRoot)) {
      reject(`archive root overlaps managed root: ${sourceRoot}`)
    }
  }
  return archive
}

/** A compact, model-safe policy description. */
export function projectPolicy(config = {}) {
  const snapshot = policySnapshot(config)
  return {
    ...snapshot,
    candidateExtensions: snapshot.candidateExtensions ?? [],
    candidateDirectories: snapshot.candidateDirectories ?? [],
    protectedDirectories: snapshot.protectedDirectories ?? [],
    protectedNames: snapshot.protectedNames ?? [],
    fingerprint: policyFingerprint(config),
  }
}

export default {
  managedRootsFor,
  isUnderManagedRoot,
  isExplicitlyManagedPath,
  isProtectedRelativePath,
  assertManagedPath,
  policySnapshot,
  policyFingerprint,
  assertArchiveRoot,
  projectPolicy,
}
