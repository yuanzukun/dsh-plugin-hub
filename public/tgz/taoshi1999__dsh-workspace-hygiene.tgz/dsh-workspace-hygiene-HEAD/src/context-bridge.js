import { randomUUID, createHash } from 'node:crypto'
import { realpath } from 'node:fs/promises'

// No private hygiene session is ever entered in DSH's session/agent registries.
export async function collectWorkspaceContext(root, sessions, preferredId, maxChars = 40000) {
  const unique = [...new Map(sessions.filter(Boolean).map(session => [session.id, session])).values()]
  unique.sort((a, b) => Number(b.id === preferredId) - Number(a.id === preferredId))
  const sources = []
  let remaining = maxChars, truncated = false
  for (const session of unique) {
    if (!session.header?.cwd || session.id?.startsWith('hygiene-private-')) continue
    if (await realpath(session.header.cwd).catch(() => null) !== root) continue
    const all = session.deriveMessages?.() ?? []
    const records = []
    const allowance = Math.min(remaining, 20000)
    let used = 0
    for (const message of all.slice(-80).reverse()) {
      if (message.source?.plugin === 'dsh-workspace-hygiene') continue
      const text = (message.content ?? []).map(block => {
        if (block.type === 'text') return block.text
        if (block.type === 'tool-call') return `${block.name}: ${JSON.stringify(block.arguments)}`
        if (block.type === 'tool-result') return JSON.stringify(block.content ?? [])
        return '' // Never import hidden reasoning or binary content.
      }).filter(Boolean).join('\n')
      if (!text) continue
      const bounded = text.slice(0, Math.min(4000, allowance - used))
      if (bounded.length < text.length) truncated = true
      if (!bounded) { truncated = true; break }
      records.unshift({ role: message.role, text: bounded })
      used += bounded.length
    }
    if (all.length > 80) truncated = true
    sources.push({ sessionId: session.id, revision: session.seq ?? all.length, messages: records })
    remaining -= used
    if (remaining <= 0) { truncated = true; break }
  }
  const digest = createHash('sha256').update(JSON.stringify(sources.map(({ sessionId, messages }) => ({ sessionId, messages })))).digest('hex')
  return { sources, truncated, digest, capturedAt: new Date().toISOString() }
}

function freeze(value) {
  if (value && typeof value === 'object' && !(value instanceof AbortSignal)) {
    for (const child of Object.values(value)) freeze(child)
    Object.freeze(value)
  }
  return value
}

/** Auxiliary request on the configured model transport; no main-agent turn or log append. */
export async function generatePrivateResponse(llm, route, input, signal) {
  if (!llm?.stream || !route?.provider || !route?.model) throw new Error('尚无可用模型，请先为当前 DSH 会话配置模型。')
  if (typeof input.prompt !== 'string' || input.prompt.length > 150000 || typeof input.system !== 'string') throw new Error('整理模型的输入超过允许范围。')
  const config = { provider: route.provider, model: route.model, maxTokens: 8192 }
  const prepared = llm.prepareCall ? await llm.prepareCall(config, signal) : null
  const request = freeze({ ...(prepared?.config ?? config), signal, system: input.system,
    messages: [{ id: randomUUID(), role: 'user', source: { kind: 'plugin', plugin: 'dsh-workspace-hygiene' }, content: [{ type: 'text', text: input.prompt }] }] })
  const blocks = new Map(), deltas = new Map()
  let terminal = false
  for await (const chunk of prepared ? prepared.stream(request) : llm.stream(request)) {
    signal?.throwIfAborted()
    if (chunk.type === 'tool-call-delta' || (chunk.type === 'block-end' && chunk.block.type === 'tool-call')) throw new Error('整理模型只能分析或回复，不能调用工具。')
    if (chunk.type === 'text-delta') deltas.set(chunk.index, (deltas.get(chunk.index) ?? '') + chunk.text)
    if (chunk.type === 'block-end' && chunk.block.type === 'text') blocks.set(chunk.index, chunk.block.text)
    if ([...deltas.values()].reduce((sum, text) => sum + text.length, 0) > 100000) throw new Error('整理模型输出超限。')
    if (chunk.type === 'finish') {
      if (chunk.reason.kind !== 'stop') throw new Error(`整理模型未正常完成（${chunk.reason.kind}）。请检查模型配置后重试。`)
      terminal = true
    }
  }
  if (!terminal) throw new Error('整理模型响应中断，请重试。')
  const text = [...new Set([...blocks.keys(), ...deltas.keys()])].sort((a, b) => a - b).map(index => blocks.get(index) ?? deltas.get(index)).join('')
  if (!text.trim() || text.length > 100000) throw new Error('整理模型回复为空或超过允许范围。')
  return text
}
