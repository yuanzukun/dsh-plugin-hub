import { watch } from 'node:fs'
import { MaintenanceAgent } from './maintenance-agent.js'
import { randomUUID } from 'node:crypto'
let agent, watcher, interval, debounce, activeController
const services = new Map()
const service = (method, input) => new Promise((resolve, reject) => {
  const id = randomUUID()
  services.set(id, { resolve, reject })
  send({ event: 'service', id, method, input })
})
let queue = Promise.resolve()
const send = message => { if (process.connected) process.send(message) }
const publish = () => { if (agent) send({ event: 'snapshot', value: agent.snapshot() }) }
const refresh = () => { queue = queue.then(async () => { await agent.refresh({ reason: 'monitor' }); publish() }).catch(error => send({ event: 'error', message: error.message })) }
const shutdown = () => { watcher?.close(); clearInterval(interval); clearTimeout(debounce); activeController?.abort(); agent?.assessment.close(); agent?.conversation.lock(); for (const pending of services.values()) pending.reject(new Error('Maintenance stopped')); services.clear(); queue.finally(async () => { await agent?.conversation.writeQueue.catch(() => {}); process.exit(0) }) }
process.on('message', message => {
  if (message.serviceReply) {
    const pending = services.get(message.serviceReply)
    services.delete(message.serviceReply)
    if (pending) message.error ? pending.reject(new Error(message.error)) : pending.resolve(message.value)
    return
  }
  if (message.method === 'chatRead' && agent) {
    try { send({ id: message.id, value: agent.conversation.read(message.args?.capability) }) }
    catch (error) { send({ id: message.id, error: error.message }) }
    return
  }
  if (message.method === 'cancel') { activeController?.abort(); return }
  if (message.method === 'dispose') { shutdown(); return }
  queue = queue.then(async () => {
    try {
      let value
      if (message.method === 'init') {
        agent = new MaintenanceAgent(message.root, message.config, { readContext: () => service('context'), generate: input => service('generate', input), changed: publish })
        const save = agent.save.bind(agent)
        agent.save = async () => { await save(); publish() }
        value = await agent.init()
        if (message.config.autoScan !== false) {
          interval = setInterval(refresh, message.config.monitorIntervalMs)
          interval.unref()
          try {
            watcher = watch(agent.root, { recursive: true }, (_event, filename) => {
              const path = String(filename ?? '').replaceAll('\\', '/')
              if ([agent.config.stateDir, agent.config.catalogRoot].some(prefix => path === prefix || path.startsWith(`${prefix}/`))) return
              clearTimeout(debounce)
              debounce = setTimeout(refresh, Math.max(100, agent.config.debounceMs))
            })
            watcher.on('error', () => { watcher?.close(); watcher = null })
          } catch { /* Periodic scanning remains available without recursive watching. */ }
        }
      } else if (!agent) throw new Error('Maintenance agent is not initialized')
      else if (message.method === 'execute') {
        activeController = new AbortController()
        value = await agent.execute(message.args, activeController.signal)
        activeController = null
      } else if (message.method === 'snapshot') value = agent.snapshot()
      else if (message.method === 'chatUnlock') value = await agent.chatUnlock(message.args)
      else if (message.method === 'chatLock') value = agent.chatLock(message.args)
      else if (message.method === 'chatSend') {
        if (agent.active) throw new Error('正在执行整理，请完成后再发送新的整理要求。')
        agent.conversation.authorize(message.args?.capability)
        if (agent.conversation.busy) throw new Error('整理会话正在回复。')
        if (typeof message.args.text !== 'string' || !message.args.text.trim() || message.args.text.length > 8000) throw new Error('消息应为 1–8000 个字符。')
        void agent.chatSend(message.args).catch(() => {})
        value = { started: true }
      }
      else if (['browse', 'setMode', 'turnEnded', 'dismiss', 'prepare', 'refresh', 'recordReview', 'rollback'].includes(message.method)) value = await agent[message.method](message.args)
      else throw new Error('Unknown maintenance operation')
      publish()
      send({ id: message.id, value })
    } catch (error) { send({ id: message.id, error: error.message }) }
  })
})
process.on('disconnect', shutdown)
