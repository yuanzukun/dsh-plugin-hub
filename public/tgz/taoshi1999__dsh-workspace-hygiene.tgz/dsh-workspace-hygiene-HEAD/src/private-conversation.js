import { createHash, randomBytes, randomUUID, scrypt as derive, createCipheriv, createDecipheriv, timingSafeEqual } from 'node:crypto'
import { promisify } from 'node:util'
import { readFile, writeFile, mkdir, rename, lstat, realpath } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join, resolve, dirname } from 'node:path'
import { isInside } from './path-utils.js'
const scrypt = promisify(derive)

/** Password-encrypted storage outside every managed workspace. Plaintext exists only while unlocked. */
export class PrivateConversation {
  constructor(root, config) {
    const storage = resolve(config.privateStorageRoot || join(homedir(), '.dsh-workspace-hygiene', 'private'))
    this.root = root
    if (isInside(root, storage)) throw new Error('privateStorageRoot 必须位于工作区之外。')
    this.path = join(storage, `${createHash('sha256').update(root).digest('hex')}.json`)
    this.key = null
    this.data = null
    this.capabilities = new Set()
    this.exists = false
    this.busy = false
    this.generation = 0
    this.failures = 0
    this.retryAt = 0
    this.writeQueue = Promise.resolve()
  }
  async init() {
    this.root = await realpath(this.root)
    await this.checkStorage()
    try { const info = await lstat(this.path); if (!info.isFile() || info.isSymbolicLink() || info.size > 8 * 1024 * 1024) throw new Error('私有会话存储不是有效的普通文件。'); this.exists = true }
    catch (error) { if (error.code !== 'ENOENT') throw error }
  }
  async checkStorage() {
    for (let path = dirname(this.path); ; path = dirname(path)) {
      try {
        const info = await lstat(path)
        if (info.isSymbolicLink() || !info.isDirectory() || isInside(this.root, await realpath(path))) throw new Error('私有会话目录必须位于工作区外，且不能经过符号链接。')
      } catch (error) { if (error.code !== 'ENOENT') throw error }
      if (dirname(path) === path) break
    }
  }
  status() { return { exists: this.exists, locked: !this.key, busy: this.busy, storage: 'password-encrypted', isolation: 'application-and-encrypted-storage' } }
  authorize(capability) {
    if (!this.key || typeof capability !== 'string' || !this.capabilities.has(capability)) throw new Error('请先解锁整理会话；其它 Agent 会话无权读取。')
  }
  async unlock(password) {
    if (typeof password !== 'string' || password.length < 12 || password.length > 1024) throw new Error('请使用至少 12 个字符的整理会话密码。')
    if (Date.now() < this.retryAt) throw new Error('密码尝试过多，请稍后重试。')
    if (this.busy) throw new Error('整理会话正在回复，请稍后解锁。')
    await this.writeQueue.catch(() => {})
    await this.init()
    let envelope
    try { envelope = JSON.parse(await readFile(this.path, 'utf8')); this.exists = true } catch (error) { if (error.code !== 'ENOENT') throw new Error('无法读取私有会话加密存储。') }
    if (envelope && (envelope.version !== 1 || typeof envelope.salt !== 'string' || Buffer.from(envelope.salt, 'base64').length !== 16 || typeof envelope.iv !== 'string' || Buffer.from(envelope.iv, 'base64').length !== 12 || typeof envelope.tag !== 'string' || Buffer.from(envelope.tag, 'base64').length !== 16 || typeof envelope.data !== 'string')) throw new Error('私有会话加密格式无效。')
    const salt = envelope ? Buffer.from(envelope.salt, 'base64') : randomBytes(16)
    const key = await scrypt(password, salt, 32)
    let data
    try {
      if (envelope) {
        if (envelope.version !== 1) throw new Error('format')
        const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(envelope.iv, 'base64'))
        decipher.setAuthTag(Buffer.from(envelope.tag, 'base64'))
        data = JSON.parse(Buffer.concat([decipher.update(Buffer.from(envelope.data, 'base64')), decipher.final()]).toString('utf8'))
        if (!Array.isArray(data.messages) || data.messages.length > 201 || !Number.isSafeInteger(data.revision) || !data.id?.startsWith('hygiene-private-') || data.messages.some(item => !['user', 'assistant'].includes(item.role) || typeof item.text !== 'string' || item.text.length > 16000)) throw new Error('format')
      } else data = { id: `hygiene-private-${randomUUID()}`, messages: [], revision: 0 }
      if (this.key && !timingSafeEqual(key, this.key)) throw new Error('wrong key')
    } catch {
      key.fill(0)
      this.failures++
      if (this.failures >= 5) this.retryAt = Date.now() + 30000
      throw new Error('密码不正确或会话文件已损坏。')
    }
    this.key?.fill(0)
    this.key = key
    this.salt = salt
    this.data = data
    this.failures = 0
    const capability = randomBytes(32).toString('base64url')
    this.capabilities.add(capability)
    await this.save()
    return { capability, ...this.read(capability) }
  }
  read(capability) {
    this.authorize(capability)
    return { ...this.status(), sessionId: this.data.id, revision: this.data.revision, messages: this.data.messages.slice(-200).map(item => ({ ...item })) }
  }
  history() { return this.data?.messages.slice(-24).map(({ role, text }) => ({ role, text: text.slice(0, 1600) })) ?? [] }
  async save() {
    if (!this.key) return
    const iv = randomBytes(12)
    const cipher = createCipheriv('aes-256-gcm', this.key, iv)
    const ciphertext = Buffer.concat([cipher.update(JSON.stringify(this.data)), cipher.final()])
    const body = JSON.stringify({ version: 1, salt: this.salt.toString('base64'), iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'), data: ciphertext.toString('base64') })
    this.writeQueue = this.writeQueue.catch(() => {}).then(async () => {
      await this.checkStorage()
      await mkdir(dirname(this.path), { recursive: true, mode: 0o700 })
      await this.checkStorage()
      const temp = `${this.path}.${randomUUID()}.tmp`
      await writeFile(temp, body, { flag: 'wx', mode: 0o600 })
      await rename(temp, this.path)
      this.exists = true
    })
    return this.writeQueue
  }
  async send(capability, text, generate, changed = () => {}) {
    this.authorize(capability)
    if (this.busy) throw new Error('整理会话正在回复。')
    if (typeof text !== 'string' || !text.trim() || text.length > 8000) throw new Error('消息应为 1–8000 个字符。')
    const generation = this.generation
    this.busy = true
    this.data.messages.push({ id: randomUUID(), role: 'user', text: text.trim(), at: new Date().toISOString() })
    this.data.revision++
    try {
      await this.save()
      changed()
      const reply = await generate(this.history())
      if (generation !== this.generation) return
      this.data.messages.push({ id: randomUUID(), role: 'assistant', text: reply.slice(0, 16000), at: new Date().toISOString() })
    } catch {
      if (generation === this.generation) this.data.messages.push({ id: randomUUID(), role: 'assistant', text: '本次模型调用失败，请检查 DSH 模型配置后重试。文件未因这条消息而被整理。', at: new Date().toISOString(), error: true })
    } finally {
      if (generation === this.generation) {
        this.busy = false
        this.data.revision++
        this.data.messages = this.data.messages.slice(-200)
        await this.save()
        changed()
      }
    }
  }
  lock() {
    this.generation++
    this.key?.fill(0)
    this.key = null
    this.data = null
    this.busy = false
    this.capabilities.clear()
    return this.status()
  }
}
