/** Loaded only in the separate DSH reviewer. The reviewer receives evidence, never write capabilities. */
import { writeFile } from 'node:fs/promises'
export const inject = ['tools']
export function apply(ctx) {
  ctx.tools.guard(exec => exec.name === 'hygiene_verdict' ? undefined : 'The workspace hygiene reviewer can only submit its verdict; filesystem and shell tools are disabled.')
  ctx.on('agent/created', ({ agent }) => {
    // An empty allow-list hides inherited tools; the global guard is the dispatch boundary.
    agent.ctx.tools.restrict({ allow: [] })
    agent.ctx.tools.register({ name: 'hygiene_verdict', description: 'Submit the independent workspace review verdict based only on the supplied evidence. This ends the review.',
      parameters: { type: 'object', properties: { approved: { type: 'boolean' }, summary: { type: 'string' }, concerns: { type: 'array', items: { type: 'string' } } }, required: ['approved', 'summary', 'concerns'], additionalProperties: false },
      output: { schema: { type: 'object', properties: { recorded: { type: 'boolean' } }, required: ['recorded'] }, render: () => [{ type: 'text', text: 'Review recorded.' }] },
      async execute(args, exec) {
        if (typeof args.approved !== 'boolean' || typeof args.summary !== 'string' || !Array.isArray(args.concerns)) throw new Error('Invalid review verdict')
        await writeFile(process.env.DSH_HYGIENE_VERDICT, JSON.stringify(args), { flag: 'wx', mode: 0o600 })
        exec.concludeTurn()
        return { recorded: true }
      } })
  })
}
