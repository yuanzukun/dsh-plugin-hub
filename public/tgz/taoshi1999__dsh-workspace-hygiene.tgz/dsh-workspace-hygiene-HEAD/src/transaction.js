/**
 * Transactional quarantine/restore operations.
 *
 * A plan is a short-lived, hashed description of files selected by a scan.
 * Applying a plan always re-checks the policy, file metadata and content
 * digest while holding a per-workspace lock. Files are moved to a quarantine
 * directory by default; permanent deletion is a separately gated opt-in.
 */

import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'
import { constants as fsConstants, createReadStream } from 'node:fs'
import {
  copyFile,
  link,
  lstat,
  mkdir,
  open,
  readFile,
  readdir,
  realpath,
  rename,
  rm,
  unlink,
  writeFile,
} from 'node:fs/promises'
import { dirname, extname, join, relative, resolve } from 'node:path'
import { setTimeout as delay } from 'node:timers/promises'
import {
  archiveRootFor,
  resolveConfig,
  resolveUserPath,
  stateRootFor,
} from './config.js'
import {
  canonicalDirectory,
  assertInside,
  isInside,
  safeRelativePath,
  throwIfAborted,
  toPosixPath,
} from './path-utils.js'
import {
  assertArchiveRoot,
  assertManagedPath,
  isProtectedRelativePath,
  policyFingerprint,
} from './policy.js'
import { explainPath, projectScan, scanWorkspace, selectCandidates } from './scan.js'
import { VALUE_ACTIONS, projectValuePolicy, suggestOrganization } from './value-policy.js'
import {
  catalogRootFor,
  groupForAction,
  projectCatalog,
  readCatalog,
  removeConfirmedCatalogEntry,
  removeCatalogEntry,
  updateCatalogEntry,
} from './catalog.js'

const DEFAULT_PLAN_TTL_MS = 15 * 60 * 1000
const DEFAULT_LOCK_TIMEOUT_MS = 0
const DEFAULT_LOCK_STALE_MS = 30 * 60 * 1000
const HASH_CHUNK_SIZE = 64 * 1024
const RESTORE_ENTRY_STATUSES = Object.freeze([
  'quarantined', 'moved', 'organized', 'failed', 'aborted', 'deleted',
])

export class HygieneError extends Error {
  constructor(message, code = 'HYGIENE_ERROR', details = undefined) {
    super(message)
    this.name = 'HygieneError'
    this.code = code
    if (details !== undefined) this.details = details
  }
}

function nowIso() {
  return new Date().toISOString()
}

function makeId(prefix = '') {
  const timestamp = new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14)
  const entropy = randomBytes(7).toString('hex')
  return `${prefix}${timestamp}-${entropy}`
}

function makeToken() {
  return randomBytes(24).toString('base64url')
}

function hashText(value) {
  return createHash('sha256').update(String(value)).digest('hex')
}

function equalDigest(left, right) {
  if (typeof left !== 'string' || typeof right !== 'string') return false
  const a = Buffer.from(left, 'utf8')
  const b = Buffer.from(right, 'utf8')
  return a.length === b.length && timingSafeEqual(a, b)
}

async function hashFile(filePath, signal) {
  throwIfAborted(signal)
  const hash = createHash('sha256')
  let bytes = 0
  // Refuse a leaf symlink if the path changes after safeExistingFile()'s
  // lstat. O_NOFOLLOW is zero on platforms that do not expose the flag.
  const noFollow = Number(fsConstants.O_NOFOLLOW ?? 0)
  const stream = createReadStream(filePath, {
    flags: fsConstants.O_RDONLY | noFollow,
    highWaterMark: HASH_CHUNK_SIZE,
  })
  try {
    for await (const chunk of stream) {
      throwIfAborted(signal)
      hash.update(chunk)
      bytes += chunk.length
    }
  } finally {
    // Calling destroy on an already-ended stream is harmless and prevents a
    // descriptor leak when an AbortSignal interrupts the iterator.
    stream.destroy()
  }
  return { sha256: hash.digest('hex'), bytes }
}

async function readJson(filePath) {
  try {
    const raw = await readFile(filePath, 'utf8')
    const value = JSON.parse(raw)
    if (value === null || typeof value !== 'object' || Array.isArray(value)) {
      throw new Error('JSON value is not an object')
    }
    return value
  } catch (error) {
    if (error?.code === 'ENOENT') return undefined
    throw new HygieneError(`cannot read ${filePath}: ${error?.message ?? String(error)}`, 'STATE_READ_ERROR')
  }
}

async function writeJsonAtomic(filePath, value) {
  // Check before and after mkdir: recursive mkdir follows a symlinked parent
  // unless the path is inspected first. The second check narrows the window
  // before the atomic rename (the lock still serializes normal writers).
  await ensureNoSymlinkPath(dirname(filePath))
  await mkdir(dirname(filePath), { recursive: true, mode: 0o700 })
  await ensureNoSymlinkPath(dirname(filePath))
  const temporary = `${filePath}.${process.pid}.${randomBytes(5).toString('hex')}.tmp`
  try {
    await writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
    await rename(temporary, filePath)
  } catch (error) {
    try { await unlink(temporary) } catch {}
    throw new HygieneError(`cannot write ${filePath}: ${error?.message ?? String(error)}`, 'STATE_WRITE_ERROR')
  }
}

async function appendJsonl(filePath, value) {
  await ensureNoSymlinkPath(dirname(filePath))
  await mkdir(dirname(filePath), { recursive: true, mode: 0o700 })
  await ensureNoSymlinkPath(dirname(filePath))
  // Refuse a leaf symlink before opening and use O_NOFOLLOW where available.
  // The second guard closes the common lstat -> open replacement window that
  // an appendFile call would otherwise leave open.
  try {
    const info = await lstat(filePath)
    if (info.isSymbolicLink()) throw new HygieneError(`audit file is a symlink: ${filePath}`, 'SYMLINK_REJECTED')
    if (!info.isFile()) throw new HygieneError(`audit path is not a regular file: ${filePath}`, 'STATE_WRITE_ERROR')
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  // Each event is immutable and a partially written final line can be ignored
  // on recovery. Opening once and writing through the handle also avoids a
  // second path lookup inside appendFile.
  const flags = fsConstants.O_WRONLY
    | fsConstants.O_APPEND
    | fsConstants.O_CREAT
    | Number(fsConstants.O_NOFOLLOW ?? 0)
  let handle
  try {
    handle = await open(filePath, flags, 0o600)
    await handle.writeFile(`${JSON.stringify(value)}\n`, { encoding: 'utf8' })
  } catch (error) {
    if (error?.code === 'ELOOP') {
      throw new HygieneError(`audit file is a symlink: ${filePath}`, 'SYMLINK_REJECTED')
    }
    throw error
  } finally {
    try { await handle?.close() } catch {}
  }
}

function plansDirectory(stateRoot) {
  return join(stateRoot, 'plans')
}

function runsDirectory(stateRoot) {
  return join(stateRoot, 'runs')
}

function planPath(stateRoot, planId) {
  return join(plansDirectory(stateRoot), `${planId}.json`)
}

function runPath(stateRoot, runId) {
  return join(runsDirectory(stateRoot), `${runId}.json`)
}

function eventPath(stateRoot) {
  return join(stateRoot, 'manifest.jsonl')
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

function isNonNegativeFiniteNumber(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0
}

function isPlanEntryRecord(entry) {
  if (!isRecord(entry) || typeof entry.relativePath !== 'string' || entry.relativePath.trim() === '') return false
  if (!isNonNegativeFiniteNumber(entry.size)) return false
  const digest = entry.sha256 ?? entry.hash
  if (typeof digest !== 'string' || digest.length === 0) return false
  if (entry.action !== undefined && !VALUE_ACTIONS.includes(String(entry.action))) return false
  if (entry.recommendation !== undefined && !VALUE_ACTIONS.includes(String(entry.recommendation))) return false
  if (entry.valueScore !== undefined && !isNonNegativeFiniteNumber(entry.valueScore)) return false
  return true
}

function isRunEntryRecord(entry) {
  if (!isRecord(entry) || typeof entry.relativePath !== 'string' || entry.relativePath.trim() === '') return false
  if (typeof entry.status !== 'string' || entry.status.trim() === '') return false
  if (entry.size !== undefined && !isNonNegativeFiniteNumber(entry.size)) return false
  if (entry.archivedRelativePath !== undefined && typeof entry.archivedRelativePath !== 'string') return false
  if (entry.organizedRelativePath !== undefined && typeof entry.organizedRelativePath !== 'string') return false
  return true
}

/**
 * Validate the small, durable shape needed by every state consumer. Keeping
 * this check at the record boundary means status/compaction code never has to
 * trust a hand-edited JSON array containing nulls or scalar values.
 */
function assertStateRecordShape(value, expectedKind) {
  if (!isRecord(value) || value.kind !== expectedKind) {
    throw new HygieneError(`invalid ${expectedKind} record`, 'STATE_CORRUPT')
  }
  if (expectedKind === 'workspace-hygiene-plan') {
    if (!normalizePlanId(value.planId)
      || normalizePlanId(value.planId) !== value.planId
      || typeof value.root !== 'string'
      || typeof value.status !== 'string'
      || !Array.isArray(value.entries)
      || !value.entries.every(isPlanEntryRecord)) {
      throw new HygieneError('invalid workspace-hygiene-plan record', 'STATE_CORRUPT')
    }
  } else if (expectedKind === 'workspace-hygiene-run') {
    if (!normalizePlanId(value.runId)
      || normalizePlanId(value.runId) !== value.runId
      || typeof value.root !== 'string'
      || typeof value.status !== 'string'
      || !Array.isArray(value.entries)
      || !value.entries.every(isRunEntryRecord)) {
      throw new HygieneError('invalid workspace-hygiene-run record', 'STATE_CORRUPT')
    }
  }
  return value
}

/** Read one state record without following a symlinked record file. */
async function readStateRecord(filePath, expectedKind) {
  let info
  try {
    info = await lstat(filePath)
  } catch (error) {
    if (error?.code === 'ENOENT') return undefined
    throw error
  }
  if (info.isSymbolicLink()) {
    throw new HygieneError(`state record is a symlink: ${filePath}`, 'SYMLINK_REJECTED')
  }
  if (!info.isFile()) {
    throw new HygieneError(`state record is not a regular file: ${filePath}`, 'STATE_CORRUPT')
  }
  let value
  try {
    value = await readJson(filePath)
  } catch (error) {
    if (error?.code === 'STATE_READ_ERROR') {
      throw new HygieneError(`invalid state record: ${filePath}`, 'STATE_CORRUPT', { cause: error.message })
    }
    throw error
  }
  return assertStateRecordShape(value, expectedKind)
}

function normalizePlanId(value) {
  if (typeof value !== 'string' || value.trim() === '') return undefined
  const id = value.trim().replace(/\.json$/i, '')
  // IDs are generated locally; rejecting path separators prevents an input
  // from escaping the plans/runs directory even before safe path checks.
  if (!/^[A-Za-z0-9][A-Za-z0-9_-]{4,127}$/.test(id)) return undefined
  return id
}

function resolveStateRoot(root, config) {
  if (typeof config.stateRoot === 'string' && config.stateRoot.trim() !== '') {
    return resolveUserPath(config.stateRoot, root)
  }
  return resolve(stateRootFor(root, config))
}

function resolveArchiveRoot(root, config) {
  const archive = typeof config.archiveRoot === 'string' && config.archiveRoot.trim() !== ''
    ? resolveUserPath(config.archiveRoot, root)
    : resolve(archiveRootFor(root, config))
  return assertArchiveRoot(root, archive, config)
}

/** Canonical workspace context shared by all public operations. */
export async function workspaceContext(inputRoot, inputConfig = {}) {
  const configInput = inputConfig && typeof inputConfig === 'object' ? inputConfig : {}
  const requestedRoot = typeof inputRoot === 'string' && inputRoot.trim() !== ''
    ? inputRoot
    : configInput.workspaceRoot
  const root = await canonicalDirectory(requestedRoot || process.cwd())
  // resolveConfig() accepts a workspaceRoot but preserving an already
  // resolved custom stateRoot is useful for isolated test profiles.
  let config
  try {
    config = resolveConfig({ ...configInput, workspaceRoot: root })
  } catch (error) {
    if (error instanceof HygieneError) throw error
    throw new HygieneError(`invalid hygiene configuration: ${error?.message ?? String(error)}`, 'CONFIG_ERROR')
  }
  const stateRoot = resolveStateRoot(root, config)
  const archiveRoot = resolveArchiveRoot(root, config)
  // `stateRoot` is a legacy/standalone override that is intentionally not
  // part of the public Schemastery surface.  Re-check it here because the
  // catalog namespace must remain metadata-only even when a library caller
  // supplies that override directly.
  const metadataRoot = catalogRootFor(root, config)
  if (isInside(metadataRoot, stateRoot) || isInside(stateRoot, metadataRoot)) {
    throw new HygieneError('catalog root cannot overlap state root', 'CATALOG_ROOT_INVALID')
  }
  if (isInside(metadataRoot, archiveRoot) || isInside(archiveRoot, metadataRoot)) {
    throw new HygieneError('catalog root cannot overlap archive root', 'CATALOG_ROOT_INVALID')
  }
  return { root, config, stateRoot, archiveRoot }
}

/**
 * Check every existing component on the way to a path. Node's recursive mkdir
 * follows symlinked parents, so this guard must run before creating state or
 * archive directories. Missing components are fine; their first existing
 * ancestor is still checked.
 */
async function ensureNoSymlinkPath(target, boundary = undefined) {
  const absolute = resolve(target)
  if (boundary !== undefined) assertInside(boundary, absolute, 'path')
  const stop = boundary === undefined ? resolve('/') : resolve(boundary)
  let current = absolute
  while (true) {
    try {
      const info = await lstat(current)
      if (info.isSymbolicLink()) throw new HygieneError(`path component is a symlink: ${current}`, 'SYMLINK_REJECTED')
      if (!info.isDirectory()) {
        throw new HygieneError(`path component is not a directory: ${current}`, 'DESTINATION_ERROR')
      }
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
    }
    if (current === stop || current === dirname(current)) break
    current = dirname(current)
  }
}

async function ensureStateDirectories(context) {
  await ensureNoSymlinkPath(context.stateRoot, context.root)
  await ensureNoSymlinkPath(context.archiveRoot)
  await mkdir(context.stateRoot, { recursive: true, mode: 0o700 })
  await mkdir(plansDirectory(context.stateRoot), { recursive: true, mode: 0o700 })
  await mkdir(runsDirectory(context.stateRoot), { recursive: true, mode: 0o700 })
  await mkdir(context.archiveRoot, { recursive: true, mode: 0o700 })
  await ensureNoSymlinkPath(context.stateRoot, context.root)
  // The nested record directories are separate attack points: a pre-existing
  // `plans` or `runs` symlink would otherwise make read-only status look at,
  // or state writers target, an unrelated directory.
  await ensureNoSymlinkPath(plansDirectory(context.stateRoot), context.root)
  await ensureNoSymlinkPath(runsDirectory(context.stateRoot), context.root)
  await ensureNoSymlinkPath(context.archiveRoot, undefined)
}

/**
 * Acquire a small per-workspace lock.  The lock is a regular file containing
 * an owner token; release only removes a lock owned by this process.
 */
export async function acquireWorkspaceLock(stateRoot, options = {}) {
  const timeoutMs = Number.isFinite(options.timeoutMs) ? Math.max(0, options.timeoutMs) : DEFAULT_LOCK_TIMEOUT_MS
  const staleMs = Number.isFinite(options.staleMs) ? Math.max(10_000, options.staleMs) : DEFAULT_LOCK_STALE_MS
  // This function is public and may be called without workspaceContext(); do
  // not let recursive mkdir follow a symlinked state directory in that case.
  await ensureNoSymlinkPath(stateRoot)
  await mkdir(stateRoot, { recursive: true, mode: 0o700 })
  await ensureNoSymlinkPath(stateRoot)
  const lockPath = join(stateRoot, '.lock')
  const owner = `${process.pid}-${randomBytes(10).toString('hex')}`
  const started = Date.now()

  while (true) {
    let handle
    try {
      handle = await open(lockPath, 'wx', 0o600)
      await handle.writeFile(JSON.stringify({ owner, pid: process.pid, createdAt: nowIso() }))
      await handle.close()
      let released = false
      return {
        lockPath,
        owner,
        async release() {
          if (released) return
          released = true
          try {
            const current = JSON.parse(await readFile(lockPath, 'utf8'))
            if (current?.owner !== owner) return
          } catch {
            return
          }
          try { await unlink(lockPath) } catch (error) {
            if (error?.code !== 'ENOENT') throw error
          }
        },
      }
    } catch (error) {
      try { await handle?.close() } catch {}
      if (error?.code !== 'EEXIST') throw new HygieneError(`cannot acquire workspace lock: ${error?.message ?? String(error)}`, 'LOCK_ERROR')

      // A stale lock is removed only when its owner PID is no longer alive (or
      // the metadata is unreadable) and its mtime is older than the threshold.
      // This avoids stealing a lock from a slow but healthy maintenance run.
      try {
        const lockInfo = await lstat(lockPath)
        if (lockInfo.isSymbolicLink()) {
          throw new HygieneError(`workspace lock is a symlink: ${lockPath}`, 'SYMLINK_REJECTED')
        }
        if (!lockInfo.isFile()) {
          throw new HygieneError(`workspace lock is not a regular file: ${lockPath}`, 'LOCK_ERROR')
        }
        if (Date.now() - lockInfo.mtimeMs > staleMs) {
          let stale = true
          try {
            const current = JSON.parse(await readFile(lockPath, 'utf8'))
            if (Number.isInteger(current?.pid) && current.pid > 0 && current.pid !== process.pid) {
              try { process.kill(current.pid, 0); stale = false } catch (probeError) {
                if (probeError?.code !== 'ESRCH') stale = false
              }
            }
          } catch {}
          if (stale) {
            try { await unlink(lockPath) } catch (unlinkError) {
              if (unlinkError?.code !== 'ENOENT') throw unlinkError
            }
            continue
          }
        }
      } catch (probeError) {
        if (probeError?.code !== 'ENOENT') throw probeError
      }

      if (Date.now() - started >= timeoutMs) {
        throw new HygieneError('workspace is busy', 'LOCK_BUSY', { lockPath })
      }
      await delay(Math.min(100, Math.max(10, timeoutMs - (Date.now() - started))))
    }
  }
}

function planTtlMs(config, options) {
  const raw = options.ttlMs ?? config.planTtlMs
  if (raw === undefined) return DEFAULT_PLAN_TTL_MS
  const parsed = Number(raw)
  if (!Number.isFinite(parsed) || parsed < 1_000) throw new HygieneError('ttlMs must be at least 1000ms', 'CONFIG_ERROR')
  return Math.min(parsed, 7 * 24 * 60 * 60 * 1000)
}

function planTokenMatches(plan, token) {
  if (typeof token !== 'string' || token === '') return false
  if (typeof plan.tokenHash === 'string') return equalDigest(plan.tokenHash, hashText(token))
  if (typeof plan.token === 'string') return equalDigest(plan.token, token)
  return false
}

function extractPlanReference(reference, options = {}) {
  const source = reference && typeof reference === 'object' ? reference : {}
  const rawString = typeof reference === 'string' ? reference.trim() : undefined
  const generatedId = rawString && /^plan-[0-9]{14}-[A-Za-z0-9_-]+$/.test(rawString) ? rawString : undefined
  const planId = normalizePlanId(source.planId ?? source.id ?? generatedId ?? options.planId)
  const token = source.token ?? source.planToken ?? source.confirmToken
    ?? (generatedId ? undefined : rawString)
    ?? options.token ?? options.planToken
  return { planId, token: typeof token === 'string' ? token : undefined }
}

function extractRunReference(reference, options = {}) {
  const source = reference && typeof reference === 'object' ? reference : {}
  const runId = normalizePlanId(source.runId ?? source.id ?? (typeof reference === 'string' ? reference : undefined) ?? options.runId)
  return { runId }
}

async function findPlanByToken(stateRoot, token) {
  if (typeof token !== 'string' || token === '') return undefined
  await ensureNoSymlinkPath(plansDirectory(stateRoot))
  let entries
  try { entries = await readdir(plansDirectory(stateRoot), { withFileTypes: true }) } catch (error) {
    if (error?.code === 'ENOENT') return undefined
    throw error
  }
  entries.sort((a, b) => a.name.localeCompare(b.name))
  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith('.json')) continue
    const value = await readStateRecord(join(plansDirectory(stateRoot), entry.name), 'workspace-hygiene-plan')
    if (value && planTokenMatches(value, token)) return value
  }
  return undefined
}

async function loadPlan(context, reference, options = {}) {
  const ref = extractPlanReference(reference, options)
  let plan
  if (ref.planId) plan = await readStateRecord(planPath(context.stateRoot, ref.planId), 'workspace-hygiene-plan')
  if (!plan && ref.token) plan = await findPlanByToken(context.stateRoot, ref.token)
  if (!plan) throw new HygieneError('plan not found or expired', 'PLAN_NOT_FOUND')
  if (!normalizePlanId(plan.planId) || !Array.isArray(plan.entries)) {
    throw new HygieneError('invalid plan record', 'STATE_CORRUPT')
  }
  if (ref.planId && plan.planId !== ref.planId) {
    throw new HygieneError('plan id does not match its state record', 'STATE_CORRUPT')
  }
  if (ref.token && !planTokenMatches(plan, ref.token)) throw new HygieneError('invalid plan token', 'PLAN_TOKEN_INVALID')
  return { plan, ref }
}

async function loadRun(context, reference, options = {}) {
  const ref = extractRunReference(reference, options)
  if (!ref.runId) throw new HygieneError('runId is required', 'RUN_NOT_FOUND')
  const run = await readStateRecord(runPath(context.stateRoot, ref.runId), 'workspace-hygiene-run')
  if (!run) throw new HygieneError(`run not found: ${ref.runId}`, 'RUN_NOT_FOUND')
  if (!normalizePlanId(run.runId) || !Array.isArray(run.entries)) {
    throw new HygieneError('invalid run record', 'STATE_CORRUPT')
  }
  if (run.runId !== ref.runId) {
    throw new HygieneError('run id does not match its state record', 'STATE_CORRUPT')
  }
  return { run, ref }
}

function compactPlan(plan, token) {
  const entries = Array.isArray(plan?.entries) ? plan.entries : []
  return {
    schemaVersion: plan?.schemaVersion,
    planId: plan?.planId,
    token,
    tokenHint: plan?.tokenHint,
    root: plan?.root,
    createdAt: plan?.createdAt,
    expiresAt: plan?.expiresAt,
    status: plan?.status,
    policyFingerprint: plan?.policyFingerprint,
    candidateCount: plan?.candidateCount,
    selectedCount: entries.length,
    selectedBytes: plan?.selectedBytes,
    skippedCount: plan?.skippedCount,
    actionCounts: plan?.actionCounts,
    organization: plan?.organization,
    valuePolicy: plan?.valuePolicy,
    warnings: Array.isArray(plan?.warnings) ? plan.warnings.slice(0, 50) : [],
    entries: entries.map(entry => ({
      relativePath: entry.relativePath,
      size: entry.size,
      ageHours: entry.ageHours,
      confidence: entry.confidence,
      score: entry.score,
      reasons: entry.reasons,
      sha256: entry.sha256,
      valueScore: entry.valueScore,
      valueClass: entry.valueClass,
      recommendation: entry.recommendation,
      action: entry.action,
      execution: entry.execution,
      decisionSource: entry.decisionSource,
      selectionReason: entry.selectionReason,
      valueReasons: entry.valueReasons,
      valueSignals: entry.valueSignals,
      organization: entry.organization,
    })),
  }
}

function normalizeAction(value) {
  const action = String(value ?? '').trim().toLowerCase()
  return VALUE_ACTIONS.includes(action) ? action : undefined
}

function normalizeActions(value) {
  if (value === undefined || value === null) return undefined
  if (!Array.isArray(value)) {
    throw new HygieneError('actions must be an array', 'ACTIONS_INVALID')
  }
  if (value.length === 0) return undefined
  const actions = []
  for (const raw of value) {
    const action = normalizeAction(raw)
    if (!action) {
      throw new HygieneError(
        `invalid action; expected one of ${VALUE_ACTIONS.join(', ')}`,
        'ACTION_INVALID',
        { allowed: [...VALUE_ACTIONS], received: raw },
      )
    }
    if (!actions.includes(action)) actions.push(action)
  }
  return actions
}

/**
 * Normalize explicit per-path decisions before creating a plan.
 *
 * The model-facing schema intentionally leaves decision-map values open
 * because dsh-tools only supports boolean `additionalProperties`.  Validate
 * the values and paths here instead of silently falling back to a heuristic:
 * a typo in an operator's `delete` decision must be visible and fail closed.
 */
function normalizeDecisions(options = {}) {
  const source = options?.decisions ?? options?.decisionByPath ?? options?.actionsByPath
  if (source === undefined || source === null) return new Map()
  const result = new Map()
  const add = (rawPath, rawAction) => {
    if (typeof rawPath !== 'string' || rawPath.trim() === '') {
      throw new HygieneError('decision path must be a non-empty workspace-relative string', 'DECISION_PATH_INVALID')
    }
    let relativePath
    try { relativePath = safeRelativePath(rawPath) } catch {
      throw new HygieneError(`decision path must stay inside the workspace: ${rawPath}`, 'DECISION_PATH_INVALID')
    }
    const action = normalizeAction(rawAction)
    if (!action) {
      throw new HygieneError(
        `invalid decision for ${relativePath}; expected one of ${VALUE_ACTIONS.join(', ')}`,
        'DECISION_ACTION_INVALID',
        { relativePath, allowed: [...VALUE_ACTIONS] },
      )
    }
    result.set(relativePath, action)
  }
  if (Array.isArray(source)) {
    for (const row of source) {
      if (!row || typeof row !== 'object' || Array.isArray(row)) {
        throw new HygieneError('decision entries must be objects', 'DECISION_INVALID')
      }
      add(row.relativePath ?? row.path, row.action ?? row.decision ?? row.recommendation)
    }
    return result
  }
  if (typeof source !== 'object') {
    throw new HygieneError('decisions must be an object or array', 'DECISION_INVALID')
  }
  for (const [rawPath, rawAction] of Object.entries(source)) add(rawPath, rawAction)
  return result
}

function isExpired(plan) {
  const expiresAt = Date.parse(plan.expiresAt ?? '')
  return Number.isFinite(expiresAt) && expiresAt <= Date.now()
}

/**
 * Add explicitly decided paths that the heuristic scanner did not classify
 * as candidates.  Value rules and per-path decisions are operator input, so
 * they must not depend on a filename extension crossing the legacy candidate
 * score threshold.  This supplement remains fail-closed: missing paths,
 * protected paths, symlinks, paths outside managed roots, and too-young files
 * are reported as warnings and never enter a plan.
 */
async function supplementDecisionCandidates(context, scan, decisions, signal, warnings) {
  if (!(decisions instanceof Map) || decisions.size === 0) return scan
  const originalCandidates = Array.isArray(scan?.candidates) ? scan.candidates : []
  const seen = new Set(originalCandidates.map(candidate => String(candidate?.relativePath ?? '')))
  const forced = []
  for (const [relativePath] of decisions) {
    throwIfAborted(signal)
    if (seen.has(relativePath)) continue

    let explanation
    try {
      explanation = await explainPath(context.root, relativePath, context.config)
    } catch (error) {
      if (signal?.aborted) throw error
      warnings.push(`decision path rejected: ${relativePath} (${error?.message ?? String(error)})`)
      continue
    }
    throwIfAborted(signal)
    if (!explanation?.exists) {
      warnings.push(`decision path missing: ${relativePath}`)
      continue
    }
    if (!explanation.managed || explanation.protected || explanation.kind === 'protected') {
      warnings.push(`decision path protected or outside managed roots: ${relativePath}`)
      continue
    }

    let sourcePath
    try {
      sourcePath = assertManagedPath(context.root, relativePath, context.config, 'decision')
    } catch (error) {
      if (signal?.aborted) throw error
      warnings.push(`decision path rejected: ${relativePath} (${error?.message ?? String(error)})`)
      continue
    }
    let source
    try {
      source = await safeExistingFile(sourcePath, context.root, 'decision source')
    } catch (error) {
      if (signal?.aborted) throw error
      warnings.push(`decision path rejected: ${relativePath} (${error?.message ?? String(error)})`)
      continue
    }
    if (!source) {
      warnings.push(`decision path missing: ${relativePath}`)
      continue
    }
    const ageHours = Math.max(0, (Date.now() - source.info.mtimeMs) / 3_600_000)
    if (ageHours < context.config.minAgeHours) {
      warnings.push(`decision path is younger than minAgeHours: ${relativePath}`)
      continue
    }

    const name = relativePath.split('/').at(-1) ?? relativePath
    const extension = extname(name).toLowerCase().replace(/^\./, '')
    // `explainPath` deliberately does not read file content. Reuse its
    // explainable policy evidence while binding size/mtime to the fresh stat
    // that will be checked and hashed again in the normal planning loop.
    forced.push({
      relativePath,
      path: source.absolute,
      name,
      extension,
      size: source.info.size,
      mtimeMs: source.info.mtimeMs,
      ageHours,
      confidence: 'high',
      score: Number.isFinite(explanation.score)
        ? explanation.score
        : Number.isFinite(explanation.valueScore) ? explanation.valueScore : 50,
      reasons: [...(Array.isArray(explanation.reasons) ? explanation.reasons : []), 'operator-decision'],
      valueScore: explanation.valueScore,
      valueClass: explanation.valueClass,
      recommendation: explanation.recommendation,
      action: explanation.action,
      execution: explanation.execution,
      decisionSource: explanation.decisionSource,
      valueReasons: Array.isArray(explanation.valueReasons) ? [...explanation.valueReasons] : [],
      valueSignals: explanation.valueSignals && typeof explanation.valueSignals === 'object'
        ? { ...explanation.valueSignals }
        : {},
      organization: explanation.organization,
      selectionReason: 'operator-decision',
    })
    seen.add(relativePath)
  }
  if (forced.length === 0) return scan
  return {
    ...scan,
    candidateCount: originalCandidates.length + forced.length,
    candidates: [...originalCandidates, ...forced],
  }
}

/**
 * Scan and persist a deterministic, short-lived plan.  The returned token is
 * required by applyPlan and is never written to the model-facing audit log.
 */
export async function planWorkspace(inputRoot, inputConfig = {}, options = {}) {
  // Allow planWorkspace({workspaceRoot, config, ...options}) for CLI callers.
  if (inputRoot && typeof inputRoot === 'object') {
    const request = inputRoot
    options = { ...request, ...(inputConfig && typeof inputConfig === 'object' ? inputConfig : {}) }
    inputConfig = request.config ?? request
    inputRoot = request.workspaceRoot
  }
  const context = await workspaceContext(inputRoot, inputConfig)
  if (context.config.enabled === false) throw new HygieneError('workspace hygiene is disabled', 'DISABLED')
  const decisions = normalizeDecisions(options)
  const actions = normalizeActions(options.actions)
  throwIfAborted(options.signal)
  await ensureStateDirectories(context)

  const scan = options.scan && options.scan.root
    ? options.scan
    : await scanWorkspace(context.root, context.config, options.signal)
  if (resolve(scan.root) !== context.root) throw new HygieneError('scan root does not match workspace root', 'ROOT_MISMATCH')

  const warnings = []
  const planningScan = await supplementDecisionCandidates(
    context,
    scan,
    decisions,
    options.signal,
    warnings,
  )

  const selectedLimits = {
    includeMedium: options.includeMedium === true,
    includeRetain: options.includeRetain === true,
    includeReview: options.includeReview === true,
    actions,
    // A per-path operator decision is already an explicit review. Pass the
    // normalized map to the selector so it can include a medium-confidence
    // candidate (or an action normally excluded by the default allow-list)
    // when the operator deliberately names it.
    decisions,
    maxFiles: Math.min(
      Number.isInteger(options.maxFiles) && options.maxFiles > 0 ? options.maxFiles : context.config.maxArchiveFiles,
      context.config.maxArchiveFiles ?? Number.MAX_SAFE_INTEGER,
    ),
    maxBytes: Math.min(
      Number.isInteger(options.maxBytes) && options.maxBytes > 0 ? options.maxBytes : context.config.maxArchiveBytes,
      context.config.maxArchiveBytes ?? Number.MAX_SAFE_INTEGER,
    ),
  }
  const { selected, bytes, skipped } = selectCandidates(planningScan, selectedLimits)
  const entries = []
  const actionCounts = { retain: 0, archive: 0, delete: 0, review: 0 }
  const organizationSummary = {}
  for (const candidate of selected) {
    throwIfAborted(options.signal)
    let rel
    try { rel = safeRelativePath(candidate.relativePath) } catch (error) {
      warnings.push(`invalid candidate path skipped: ${candidate.relativePath}`)
      continue
    }
    let sourcePath
    try { sourcePath = assertManagedPath(context.root, rel, context.config, 'candidate') } catch (error) {
      warnings.push(error?.message ?? String(error))
      continue
    }
    let before
    try {
      before = await safeExistingFile(sourcePath, context.root, 'source')
    } catch (error) {
      warnings.push(`candidate path rejected: ${rel} (${error?.message ?? String(error)})`)
      continue
    }
    if (!before) {
      warnings.push(`candidate disappeared: ${rel}`)
      continue
    }
    const digest = await hashFile(before.absolute, options.signal)
    let after
    try {
      after = await safeExistingFile(sourcePath, context.root, 'source')
    } catch (error) {
      warnings.push(`candidate path changed while planning: ${rel} (${error?.message ?? String(error)})`)
      continue
    }
    if (!after || after.info.size !== before.info.size || after.info.mtimeMs !== before.info.mtimeMs) {
      warnings.push(`candidate changed while planning: ${rel}`)
      continue
    }
    // Re-check the age gate against the post-hash stat as well. Callers may
    // provide a cached/custom scan, and an explicit decision must not turn
    // that shortcut into a way to select a file produced moments ago.
    const currentAgeHours = Math.max(0, (Date.now() - after.info.mtimeMs) / 3_600_000)
    if (currentAgeHours < context.config.minAgeHours) {
      warnings.push(`candidate is younger than minAgeHours: ${rel}`)
      continue
    }
    const requested = decisions.get(rel)
    const action = requested ?? normalizeAction(candidate.action ?? candidate.recommendation) ?? 'archive'
    // Recompute the destination when an operator overrides the heuristic
    // action; retaining a file must never leave a stale "to-delete" path in
    // the plan.
    const organization = suggestOrganization({ ...candidate, relativePath: rel, action }, context.config.valuePolicy)
    const execution = action === 'delete' && context.config.valuePolicy?.allowDelete === true
      ? 'delete'
      : action === 'delete' || action === 'archive'
        ? 'quarantine'
        : 'skip'
    actionCounts[action] = (actionCounts[action] ?? 0) + 1
    const organizationKey = organization?.catalogDirectory
      ?? organization?.targetDirectory
      ?? action
    organizationSummary[organizationKey] = (organizationSummary[organizationKey] ?? 0) + 1
    entries.push({
      relativePath: rel,
      directory: candidate.directory
        ?? (rel.includes('/') ? rel.slice(0, rel.lastIndexOf('/')) : '.'),
      name: candidate.name ?? rel.split('/').at(-1),
      purpose: candidate.purpose,
      size: after.info.size,
      mtimeMs: after.info.mtimeMs,
      mode: after.info.mode,
      ageHours: Math.round(currentAgeHours * 10) / 10,
      confidence: candidate.confidence,
      score: candidate.score,
      reasons: Array.isArray(candidate.reasons) ? [...candidate.reasons] : [],
      valueScore: Number.isFinite(candidate.valueScore) ? candidate.valueScore : undefined,
      valueClass: candidate.valueClass,
      recommendation: candidate.recommendation,
      action,
      execution,
      decisionSource: requested ? 'operator' : candidate.decisionSource,
      selectionReason: requested ? 'operator-decision' : candidate.selectionReason,
      valueReasons: Array.isArray(candidate.valueReasons) ? [...candidate.valueReasons] : [],
      valueSignals: candidate.valueSignals && typeof candidate.valueSignals === 'object'
        ? { ...candidate.valueSignals }
        : {},
      organization,
      sha256: digest.sha256,
      hash: digest.sha256,
      fingerprint: { size: after.info.size, mtimeMs: after.info.mtimeMs },
    })
  }

  const planId = makeId('plan-')
  const token = makeToken()
  const createdAt = nowIso()
  const expiresAt = new Date(Date.now() + planTtlMs(context.config, options)).toISOString()
  const plan = {
    schemaVersion: 1,
    kind: 'workspace-hygiene-plan',
    planId,
    tokenHash: hashText(token),
    tokenHint: token.slice(-8),
    root: context.root,
    stateRoot: context.stateRoot,
    archiveRoot: context.archiveRoot,
    createdAt,
    expiresAt,
    status: 'planned',
    policyFingerprint: policyFingerprint(context.config),
    candidateCount: Number(planningScan.candidateCount ?? planningScan.candidates?.length ?? 0),
    selectedBytes: entries.reduce((sum, entry) => sum + entry.size, 0),
    skippedCount: Math.max(0, skipped + (selected.length - entries.length)),
    actionCounts,
    organization: organizationSummary,
    valuePolicy: projectValuePolicy(context.config.valuePolicy),
    scan: projectScan(planningScan, context.config.resultLimit ?? 25),
    entries,
    warnings,
  }
  await writeJsonAtomic(planPath(context.stateRoot, planId), plan)
  await appendJsonl(eventPath(context.stateRoot), {
    schemaVersion: 1,
    event: 'plan-created',
    planId,
    root: context.root,
    createdAt,
    expiresAt,
    selectedCount: entries.length,
    selectedBytes: plan.selectedBytes,
    policyFingerprint: plan.policyFingerprint,
  })
  return compactPlan(plan, token)
}

async function safeExistingFile(filePath, boundary, label) {
  const absolute = assertInside(boundary, filePath, label)
  let info
  try { info = await lstat(absolute) } catch (error) {
    if (error?.code === 'ENOENT') return undefined
    throw error
  }
  if (info.isSymbolicLink()) throw new HygieneError(`${label} is a symlink: ${absolute}`, 'SYMLINK_REJECTED')
  if (!info.isFile()) throw new HygieneError(`${label} is not a regular file: ${absolute}`, 'FILE_TYPE_REJECTED')
  // lstat protects the leaf, while realpath catches a symlink in an ancestor
  // directory (for example workspace/tmp -> /outside).  A race can still be
  // detected by the hash/postcondition checks surrounding each move.
  try {
    const canonical = await realpath(absolute)
    if (!isInside(boundary, canonical)) {
      throw new HygieneError(`${label} resolves outside its boundary: ${absolute}`, 'PATH_ESCAPE')
    }
  } catch (error) {
    if (error instanceof HygieneError) throw error
    throw new HygieneError(`cannot resolve ${label}: ${error?.message ?? String(error)}`, 'PATH_CHECK_FAILED')
  }
  return { absolute, info }
}

async function ensureNoSymlinkAncestors(directory, boundary) {
  const absolute = assertInside(boundary, directory, 'destination')
  const boundaryAbs = resolve(boundary)
  await ensureNoSymlinkPath(boundaryAbs)
  const rel = relative(boundaryAbs, absolute)
  let current = boundaryAbs
  if (rel === '') return
  for (const part of rel.split(/[\\/]+/).filter(Boolean)) {
    current = join(current, part)
    try {
      const info = await lstat(current)
      if (info.isSymbolicLink()) throw new HygieneError(`destination ancestor is a symlink: ${current}`, 'SYMLINK_REJECTED')
      if (!info.isDirectory()) throw new HygieneError(`destination ancestor is not a directory: ${current}`, 'DESTINATION_ERROR')
    } catch (error) {
      if (error?.code === 'ENOENT') return
      throw error
    }
  }
}

async function collisionSafeDestination(archiveRoot, runId, relativePath) {
  const rel = safeRelativePath(relativePath)
  const runRoot = assertInside(archiveRoot, resolve(archiveRoot, runId), 'archive run')
  const base = assertInside(runRoot, resolve(runRoot, rel), 'archive destination')
  let candidate = base
  let counter = 0
  while (true) {
    try {
      const info = await lstat(candidate)
      if (info.isSymbolicLink()) throw new HygieneError(`archive collision is a symlink: ${candidate}`, 'SYMLINK_REJECTED')
      counter += 1
      const extension = extname(base)
      const stem = extension ? base.slice(0, -extension.length) : base
      candidate = `${stem}--${counter}${extension}`
    } catch (error) {
      if (error?.code === 'ENOENT') return { absolute: candidate, relativePath: toPosixPath(relative(archiveRoot, candidate)) }
      throw error
    }
  }
}

/** Collision-safe destination for explicit in-workspace organization moves. */
async function collisionSafeWorkspaceDestination(workspaceRoot, relativePath) {
  const rel = safeRelativePath(relativePath)
  let candidate = assertInside(workspaceRoot, resolve(workspaceRoot, rel), 'organization destination')
  let counter = 0
  while (true) {
    try {
      const info = await lstat(candidate)
      if (info.isSymbolicLink()) throw new HygieneError(`organization collision is a symlink: ${candidate}`, 'SYMLINK_REJECTED')
      counter += 1
      const extension = extname(candidate)
      const stem = extension ? candidate.slice(0, -extension.length) : candidate
      candidate = `${stem}--${counter}${extension}`
    } catch (error) {
      if (error?.code === 'ENOENT') {
        return { absolute: candidate, relativePath: toPosixPath(relative(workspaceRoot, candidate)) }
      }
      throw error
    }
  }
}

function organizationModeRequested(options = {}, context = undefined) {
  // An explicit request is still supported for manual tool calls.  Full
  // autonomy implies the same request for idle maintenance, but the actual
  // physical move remains gated by valuePolicy.organization.moveFiles.
  return options.organize === true
    || options.organization === true
    || options.organizeFiles === true
    || context?.config?.autonomousMode === true
}

function physicalOrganizationEnabled(context, options = {}) {
  if (!organizationModeRequested(options, context)) return false
  const organization = context?.config?.valuePolicy?.organization
  if (organization?.enabled === false) return false
  // A direct, confirmed `organize:true` call is an explicit operator
  // decision and may perform the physical move even when the profile keeps
  // the autonomous/idle move gate off.  Idle autonomous maintenance remains
  // opt-in through `organization.moveFiles:true` so merely enabling scans
  // cannot rewrite a workspace.
  return options.organize === true
    || options.organization === true
    || options.organizeFiles === true
    || organization?.moveFiles === true
}

function assertOrganizationPath(context, relativePath) {
  const rel = safeRelativePath(relativePath)
  const absolute = assertInside(context.root, resolve(context.root, rel), 'organization destination')
  if (isInside(context.stateRoot, absolute) || isInside(context.archiveRoot, absolute)) {
    throw new HygieneError(`organization destination overlaps plugin state: ${rel}`, 'DESTINATION_ERROR')
  }
  // The catalog is metadata-only.  Never allow a hand-edited/legacy plan to
  // treat its category directory as a physical source destination.
  let catalogRoot
  try { catalogRoot = catalogRootFor(context.root, context.config) } catch (error) {
    throw new HygieneError(error?.message ?? String(error), error?.code ?? 'DESTINATION_ERROR')
  }
  if (isInside(catalogRoot, absolute)) {
    throw new HygieneError(`organization destination overlaps metadata catalog: ${rel}`, 'DESTINATION_ERROR')
  }
  // Organization is an explicit mutation mode, but it must still respect the
  // hard protected-tree and credential boundaries.
  if (isProtectedRelativePath(rel, context.config)) {
    throw new HygieneError(`organization destination is protected by policy: ${rel}`, 'PATH_POLICY_REJECTED')
  }
  return absolute
}

async function moveFile(source, destination, boundary = undefined) {
  const parent = dirname(destination)
  if (boundary) await ensureNoSymlinkAncestors(parent, boundary)
  else await ensureNoSymlinkPath(parent)
  await mkdir(parent, { recursive: true, mode: 0o700 })
  if (boundary) await ensureNoSymlinkAncestors(parent, boundary)
  else await ensureNoSymlinkPath(parent)
  try {
    // Hard-link + unlink is the closest portable equivalent to renameat2
    // RENAME_NOREPLACE: it cannot overwrite a destination created by a race.
    // Fall back to COPYFILE_EXCL for filesystems that disallow hard links.
    await link(source, destination)
    await unlink(source)
  } catch (error) {
    if (error?.code === 'EEXIST') throw new HygieneError(`destination already exists: ${destination}`, 'DESTINATION_EXISTS')
    if (!['EXDEV', 'EPERM', 'EOPNOTSUPP', 'ENOSYS'].includes(error?.code)) throw error
    // Cross-device quarantine is uncommon but supported. COPYFILE_EXCL keeps
    // a race from overwriting an existing artifact.
    try {
      await copyFile(source, destination, 1)
    } catch (copyError) {
      if (copyError?.code === 'EEXIST') throw new HygieneError(`destination already exists: ${destination}`, 'DESTINATION_EXISTS')
      throw copyError
    }
    await unlink(source)
  }
}

function sourceParts(relativePath) {
  const rel = safeRelativePath(relativePath)
  const name = rel.split('/').at(-1) ?? rel
  const directory = rel.includes('/') ? rel.slice(0, rel.lastIndexOf('/')) : '.'
  return { relativePath: rel, directory, name }
}

/**
 * Best-effort catalog lookup used after a source mutation.  Catalog failures
 * must never cause a successful source move/delete to be rolled back (the
 * source operation is already durable), but callers receive the error so it
 * can be written to the run/audit record and retried by the next scan.
 */
async function catalogEntryFor(context, relativePath) {
  const catalog = await readCatalog(context.root, context.config, { strict: false })
  return catalog.entries.find(entry => entry.relativePath === relativePath)
}

/** Return source paths currently awaiting a confirmed to-delete decision. */
async function catalogToDeletePaths(context) {
  try {
    const catalog = await readCatalog(context.root, context.config, { strict: false })
    return new Set((catalog.groups?.['to-delete'] ?? [])
      .filter(entry => entry?.status !== 'stale')
      .map(entry => String(entry.relativePath)))
  } catch {
    // A malformed optional catalog must not widen a destructive operation;
    // fail closed by treating it as if no catalog-backed delete existed.
    return new Set()
  }
}

/**
 * Decide whether a delete recommendation is backed by an approved catalog
 * entry for this invocation.  Manual confirmation is the user's explicit
 * approval of a `to-delete` entry and therefore does not require the separate
 * permanent-delete policy flag.  Autonomous maintenance has no human in the
 * loop, so it still requires `valuePolicy.allowDelete:true`; otherwise the
 * normal reversible quarantine path is used.  `catalogConfirm:false` is used
 * by the legacy autoArchive flow to make that distinction explicit.
 */
function catalogDeletionAuthorized(context, relativePath, catalogDeleteSet, {
  catalogConfirmationAllowed = true,
  planConfirmed = false,
  options = {},
} = {}) {
  if (!catalogConfirmationAllowed || !catalogDeleteSet?.has(String(relativePath))) return false
  if (options.permanentDelete === false) return false
  if (context?.config?.autonomousMode === true) {
    return context.config.valuePolicy?.allowDelete === true
  }
  return planConfirmed === true
}

function explicitConfirmationForPlan(plan, ref, options, context) {
  return confirmationProvided(plan, ref, options, context)
}

function catalogRecordFor(relativePath, entry, patch = {}) {
  const parts = sourceParts(relativePath)
  const base = entry && typeof entry === 'object' ? { ...entry } : {}
  // `_catalogFile` is non-enumerable on records read from disk, but deleting
  // it here keeps this helper safe if a producer supplied it as enumerable.
  delete base._catalogFile
  return {
    ...base,
    ...parts,
    ...patch,
    relativePath: parts.relativePath,
    directory: patch.directory ?? parts.directory,
    name: patch.name ?? parts.name,
  }
}

/**
 * Return the canonical catalog fields for an explicit transaction decision.
 *
 * Plan entries intentionally carry both `action` and the scanner's original
 * `recommendation`.  When an operator overrides a recommendation (for
 * example, changing a catalog `to-delete` item to `retain`), spreading the
 * two records verbatim would leave a contradictory metadata record: the
 * group could be `retained` while `recommendation` still says `delete`.
 * Catalog entries persist the recommendation/group/value class, so make the
 * explicit action authoritative at this lifecycle boundary.
 */
function catalogDecisionPatch(entry, fallback = undefined) {
  const action = normalizeAction(entry?.action ?? entry?.decision)
    ?? normalizeAction(entry?.recommendation)
  if (!action) return {}
  const group = groupForAction(action)
  const suppliedValueClass = entry?.valueClass ?? fallback?.valueClass
  const valueClass = action === 'retain'
    ? (suppliedValueClass === 'protected' ? 'protected' : 'valuable')
    : action === 'archive'
      ? 'intermediate'
      : action === 'delete'
        ? 'disposable'
        : 'uncertain'
  return {
    recommendation: action,
    group,
    valueClass,
  }
}

/** Recompute both catalog and physical name/path suggestions for a decision. */
function catalogOrganizationPatch(context, relativePath, source, action) {
  if (!action) return {}
  try {
    const organization = suggestOrganization({
      ...(source && typeof source === 'object' ? source : {}),
      relativePath,
      name: source?.name ?? sourceParts(relativePath).name,
      action,
      mtimeMs: source?.mtimeMs,
      sha256: source?.sha256,
    }, context.config.valuePolicy)
    return {
      suggestedName: organization.suggestedName,
      // `suggestedPath` is the metadata catalog location. Keep the explicit
      // source-side aliases in sync so an organizer never receives the
      // catalog path by accident.
      suggestedPath: organization.suggestedPath,
      suggestedSourceName: organization.suggestedName,
      suggestedSourcePath: organization.suggestedSourcePath
        ?? organization.physicalSuggestedPath,
    }
  } catch {
    // Suggestions are advisory. A malformed hand-edited policy is rejected at
    // configuration time; if a future producer supplies an invalid record,
    // keep the durable decision update rather than masking its lifecycle.
    return {}
  }
}

async function catalogRemoveAfterSourceAction(context, relativePath) {
  try {
    return { result: await removeConfirmedCatalogEntry(context.root, relativePath, context.config) }
  } catch (error) {
    return { error }
  }
}

async function catalogConfirmInPlace(context, relativePath, entry, status = 'confirmed') {
  try {
    const existing = await catalogEntryFor(context, relativePath)
    if (!existing && !entry) return {}
    // A plan may contain an operator override (for example, retain a path
    // previously classified as to-delete). Let the plan decision replace the
    // catalog's action/group while preserving human-authored fields such as
    // purpose when the plan does not carry them.
    // Do not let an explicitly present `undefined` field from a plan erase a
    // human-authored catalog value (purpose, reasons, signals, ...).  Plans
    // are projections and commonly omit those fields.
    const definedEntry = entry && typeof entry === 'object'
      ? Object.fromEntries(Object.entries(entry).filter(([, value]) => value !== undefined))
      : entry
    const source = existing && definedEntry ? { ...existing, ...definedEntry } : (existing ?? definedEntry)
    // `pending` is used by restore: the source is being put back after a
    // quarantine, so keep the catalog's existing assessment instead of
    // reapplying the run's original `delete` action.  Confirmation/apply
    // lifecycle states, on the other hand, represent a fresh explicit
    // decision and must update group/recommendation consistently.
    const decisionPatch = status === 'pending' ? {} : catalogDecisionPatch(definedEntry, source)
    const action = decisionPatch.recommendation
    const record = catalogRecordFor(relativePath, source, {
      ...decisionPatch,
      ...catalogOrganizationPatch(context, relativePath, source, action),
      status,
      sourceExists: true,
      updatedAt: nowIso(),
    })
    const result = await updateCatalogEntry(context.root, record, context.config, { strict: false })
    return { result }
  } catch (error) {
    return { error }
  }
}

/** Preserve an intermediate/archive entry after its source is quarantined. */
async function catalogArchiveAfterSourceAction(context, relativePath, entry, archivedRelativePath) {
  try {
    const existing = await catalogEntryFor(context, relativePath)
    if (!existing && !entry) return {}
    const source = existing ?? entry
    const decisionPatch = { recommendation: 'archive', group: 'intermediate', valueClass: 'intermediate' }
    const record = catalogRecordFor(relativePath, source, {
      ...decisionPatch,
      ...catalogOrganizationPatch(context, relativePath, source, 'archive'),
      group: 'intermediate',
      recommendation: 'archive',
      action: 'archive',
      status: 'archived',
      sourceExists: false,
      archivedRelativePath,
      updatedAt: nowIso(),
    })
    const result = await updateCatalogEntry(context.root, record, context.config, { strict: false })
    return { result }
  } catch (error) {
    return { error }
  }
}

/** Update a catalog entry when an explicitly enabled physical organization
 * move changes its source path.  The source file itself is handled by the
 * transaction loop; this helper only migrates metadata JSON. */
async function catalogMoveAfterOrganization(context, oldRelativePath, newRelativePath, entry) {
  try {
    const existing = await catalogEntryFor(context, oldRelativePath)
    const definedEntry = entry && typeof entry === 'object'
      ? Object.fromEntries(Object.entries(entry).filter(([, value]) => value !== undefined))
      : entry
    const source = existing && definedEntry ? { ...existing, ...definedEntry } : (existing ?? definedEntry)
    const parts = sourceParts(newRelativePath)
    // An explicit plan action wins over the catalog's prior recommendation;
    // this matters when a user organizes a path after changing its decision.
    const action = normalizeAction(definedEntry?.action ?? definedEntry?.decision)
      ?? normalizeAction(definedEntry?.recommendation)
      ?? normalizeAction(existing?.recommendation)
      ?? 'review'
    const oldParts = sourceParts(oldRelativePath)
    const organization = suggestOrganization({
      ...source,
      ...definedEntry,
      // Derive the stable name from the pre-move source.  Deriving it from
      // `newRelativePath` would feed an already date-prefixed name back into
      // the default `{date}-{stem}` template and produce names such as
      // `2026-09-02-2026-09-02-result.log`.
      relativePath: oldParts.relativePath,
      name: oldParts.name,
      action,
      mtimeMs: definedEntry?.mtimeMs ?? source?.mtimeMs,
      sha256: definedEntry?.sha256 ?? source?.sha256,
    }, context.config.valuePolicy)
    const suggestedName = definedEntry?.organization?.suggestedName
      ?? existing?.suggestedName
      ?? organization.suggestedName
    const catalogDirectory = organization.catalogDirectory
      ?? organization.targetDirectory
    const suggestedPath = catalogDirectory
      ? `${catalogDirectory}/${suggestedName}`
      : organization.suggestedPath
    const record = catalogRecordFor(newRelativePath, source, {
      ...catalogDecisionPatch({ ...definedEntry, action }, source),
      status: 'applied',
      sourceExists: true,
      updatedAt: nowIso(),
      suggestedName,
      suggestedPath,
      suggestedSourceName: suggestedName,
      // The actual destination wins over an advisory template path (it may
      // have acquired a collision suffix during the move).
      suggestedSourcePath: newRelativePath,
      organizedRelativePath: newRelativePath,
    })
    await updateCatalogEntry(context.root, record, context.config, { strict: false })
    if (oldRelativePath !== newRelativePath) {
      await removeCatalogEntry(context.root, oldRelativePath, context.config, { strict: false })
    }
    return {}
  } catch (error) {
    return { error }
  }
}

function appendCatalogError(run, relativePath, operation, error) {
  if (!error) return
  const message = error?.message ?? String(error)
  const code = error?.code ?? 'CATALOG_UPDATE_FAILED'
  run.errors.push({ relativePath, code: 'CATALOG_UPDATE_FAILED', operation, message, cause: code })
  // A source operation can succeed while its metadata update fails. Marking
  // the run partial makes that condition visible without pretending the
  // source operation itself was rolled back.
  run.counts.failed += 1
}

async function updatePlanStatus(context, plan, patch) {
  Object.assign(plan, patch)
  await writeJsonAtomic(planPath(context.stateRoot, plan.planId), plan)
}

function confirmationProvided(plan, ref, options, context = undefined) {
  const token = ref.token ?? options.token ?? options.planToken ?? options.confirmToken
  const tokenValid = planTokenMatches(plan, token)
  if (!tokenValid) return false
  return context?.config?.autonomousMode === true
    || (options.autonomous === true && context?.config?.autonomousMode === true)
    || options.confirm === true
    || options.confirmation === true
    || options.confirmation === token
    || options.confirmToken === token
    || options.confirmToken === true
}

function planDeleteEntries(plan) {
  return (Array.isArray(plan?.entries) ? plan.entries : [])
    .filter(entry => String(entry?.action ?? entry?.recommendation ?? '') === 'delete')
}

function permanentDeleteRequested(options = {}, context = undefined) {
  if (options.permanentDelete === true || options.delete === true || options.purge === true) return true
  // In full-autonomy mode an explicitly enabled delete policy is sufficient
  // to turn a delete recommendation into a permanent delete.  The policy
  // gate and the final hash/inode checks below still apply; callers can pass
  // `permanentDelete:false` to retain the reversible quarantine fallback.
  return context?.config?.autonomousMode === true
    && options.permanentDelete !== false
    && context?.config?.valuePolicy?.allowDelete === true
}

function permanentDeleteAllowed(context, options = {}) {
  const policy = context.config.valuePolicy ?? {}
  if (policy.allowDelete !== true) return false
  if (!permanentDeleteRequested(options, context)) return false
  if (policy.deleteRequiresConfirmation === false) return true
  if (context.config.autonomousMode === true && options.permanentDelete !== false) return true
  return options.confirmDelete === true || options.deleteConfirmation === true
}

function deleteConfirmationResponse(plan, context) {
  return {
    ok: false,
    requiresDeleteConfirmation: true,
    code: 'DELETE_CONFIRMATION_REQUIRED',
    planId: plan.planId,
    tokenHint: plan.tokenHint,
    expiresAt: plan.expiresAt,
    deleteCount: planDeleteEntries(plan).length,
    allowDelete: context.config.valuePolicy?.allowDelete === true,
    message: context.config.valuePolicy?.allowDelete === true
      ? 'This plan includes permanent-delete recommendations. Pass permanentDelete:true and confirmDelete:true to delete; otherwise apply will quarantine them for recovery.'
      : 'This plan includes permanent-delete recommendations. Permanent deletion is disabled; apply will quarantine them for recovery.',
  }
}

function planTokenFrom(plan, ref, options) {
  return ref.token ?? options.token ?? options.planToken ?? options.confirmToken
}

function assertApplicablePlan(context, plan, ref, options) {
  if (!plan || plan.root !== context.root) {
    throw new HygieneError('plan root does not match workspace root', 'ROOT_MISMATCH')
  }
  const token = planTokenFrom(plan, ref, options)
  if (!planTokenMatches(plan, token)) {
    throw new HygieneError('invalid plan token', 'PLAN_TOKEN_INVALID')
  }
  if (isExpired(plan)) throw new HygieneError('plan has expired; create a new plan', 'PLAN_EXPIRED')
  if (plan.status !== 'planned') throw new HygieneError(`plan is not applicable (status=${plan.status})`, 'PLAN_APPLIED')
  if (plan.policyFingerprint !== policyFingerprint(context.config)) {
    throw new HygieneError('policy changed since plan creation; create a new plan', 'PLAN_STALE_POLICY')
  }
}

/**
 * Apply a plan after explicit confirmation.  The operation is idempotent only
 * up to the first successful move; a subsequent call reports PLAN_APPLIED.
 */
export async function applyPlan(inputRoot, inputConfig = {}, reference, options = {}) {
  // Object form: applyPlan({workspaceRoot, config, planId, token, confirm})
  if (inputRoot && typeof inputRoot === 'object') {
    const request = inputRoot
    options = { ...request, ...(options && typeof options === 'object' ? options : {}) }
    reference = request.plan ?? request.planId ?? request
    inputConfig = request.config ?? request
    inputRoot = request.workspaceRoot
  }
  const context = await workspaceContext(inputRoot, inputConfig)
  if (context.config.enabled === false) throw new HygieneError('workspace hygiene is disabled', 'DISABLED')
  await ensureStateDirectories(context)
  let { plan, ref } = await loadPlan(context, reference, options)
  if (plan.root !== context.root) throw new HygieneError('plan root does not match workspace root', 'ROOT_MISMATCH')
  const tokenValid = planTokenMatches(plan, planTokenFrom(plan, ref, options))
  const planConfirmed = explicitConfirmationForPlan(plan, ref, options, context)
  const catalogDeleteSet = await catalogToDeletePaths(context)
  // A maintenance-triggered legacy autoArchive call passes confirm:true to
  // satisfy the transaction's general confirmation gate, but that is not a
  // human confirmation of an irreversible catalog deletion. Callers can set
  // catalogConfirm:false to force the reversible quarantine path; direct
  // manual applies default to true once their plan confirmation is present.
  const catalogConfirmationAllowed = options.catalogConfirm !== false
  const catalogBackedDelete = (plan.entries ?? []).some(entry => (
    String(entry?.action ?? entry?.recommendation ?? '') === 'delete'
      && catalogDeletionAuthorized(context, entry?.relativePath, catalogDeleteSet, {
        catalogConfirmationAllowed,
        planConfirmed,
        options,
      })
  ))
  if (!tokenValid || (options.dryRun !== true && !planConfirmed)) {
    return {
      ok: false,
      requiresConfirmation: true,
      code: 'CONFIRMATION_REQUIRED',
      planId: plan.planId,
      tokenHint: plan.tokenHint,
      expiresAt: plan.expiresAt,
      selectedCount: plan.entries?.length ?? 0,
      selectedBytes: plan.selectedBytes ?? 0,
      message: 'Pass the plan token and confirm:true to quarantine these files.',
    }
  }
  let deleteEntries = planDeleteEntries(plan)
  const permanentDelete = permanentDeleteAllowed(context, options)
  const organize = physicalOrganizationEnabled(context, options)
  if (deleteEntries.length > 0 && permanentDeleteRequested(options, context)
    && context.config.valuePolicy?.allowDelete !== true
    && !catalogBackedDelete) {
    return deleteConfirmationResponse(plan, context)
  }
  if (deleteEntries.length > 0 && permanentDeleteRequested(options, context)
    && !permanentDelete && options.dryRun !== true
    && !catalogBackedDelete) {
    return deleteConfirmationResponse(plan, context)
  }
  assertApplicablePlan(context, plan, ref, options)
  throwIfAborted(options.signal)

  const lock = await acquireWorkspaceLock(context.stateRoot, options)
  // Re-read under the lock. Two callers may have passed the fast checks above
  // concurrently; only one should be allowed to consume a planned record.
  try {
    const fresh = await loadPlan(context, reference, options)
    plan = fresh.plan
    ref = fresh.ref
    deleteEntries = planDeleteEntries(plan)
    // Refresh the catalog view under the same workspace lock used for source
    // mutations. A user may have edited/moved a catalog entry while a plan
    // was waiting for confirmation.
    const freshCatalogDeleteSet = await catalogToDeletePaths(context)
    catalogDeleteSet.clear()
    for (const path of freshCatalogDeleteSet) catalogDeleteSet.add(path)
    assertApplicablePlan(context, plan, ref, options)
    if (options.dryRun !== true && !confirmationProvided(plan, ref, options, context)) {
      await lock.release()
      return {
        ok: false,
        requiresConfirmation: true,
        code: 'CONFIRMATION_REQUIRED',
        planId: plan.planId,
        tokenHint: plan.tokenHint,
        expiresAt: plan.expiresAt,
        selectedCount: Array.isArray(plan.entries) ? plan.entries.length : 0,
        selectedBytes: plan.selectedBytes ?? 0,
        message: 'Pass the plan token and confirm:true to quarantine these files.',
      }
    }
    if (deleteEntries.length > 0 && permanentDeleteRequested(options, context)
      && !permanentDelete && options.dryRun !== true
      && !deleteEntries.some(entry => catalogDeletionAuthorized(context, entry?.relativePath, catalogDeleteSet, {
        catalogConfirmationAllowed,
        planConfirmed: confirmationProvided(plan, ref, options, context),
        options,
      }))) {
      await lock.release()
      return deleteConfirmationResponse(plan, context)
    }
  } catch (error) {
    await lock.release()
    throw error
  }
  const runId = makeId('run-')
  const startedAt = nowIso()
  const run = {
    schemaVersion: 1,
    kind: 'workspace-hygiene-run',
    runId,
    planId: plan.planId,
    root: context.root,
    stateRoot: context.stateRoot,
    archiveRoot: context.archiveRoot,
    startedAt,
    completedAt: undefined,
    status: 'running',
    entries: [],
    counts: {
      planned: plan.entries.length,
      quarantined: 0,
      deleted: 0,
      organized: 0,
      retained: 0,
      review: 0,
      failed: 0,
      conflicts: 0,
    },
    bytes: 0,
    errors: [],
  }
  try {
    await writeJsonAtomic(runPath(context.stateRoot, runId), run)
    await appendJsonl(eventPath(context.stateRoot), { schemaVersion: 1, event: 'run-started', runId, planId: plan.planId, startedAt })

    if (options.dryRun === true) {
      run.status = 'dry-run'
      run.completedAt = nowIso()
      run.entries = plan.entries.map(entry => {
        const action = normalizeAction(entry.action ?? entry.recommendation) ?? 'archive'
        const catalogDeleteConfirmed = action === 'delete'
          && catalogDeletionAuthorized(context, entry?.relativePath, catalogDeleteSet, {
            catalogConfirmationAllowed,
            planConfirmed,
            options,
          })
        const wouldPermanentlyDelete = permanentDelete || catalogDeleteConfirmed
        const status = action === 'retain'
          ? (organize ? 'would-organize' : 'would-retain')
          : action === 'review'
            ? (organize ? 'would-organize' : 'would-review')
            : action === 'delete' && wouldPermanentlyDelete
              ? 'would-delete'
              : 'would-quarantine'
        return { ...entry, action, status }
      })
      run.counts.quarantined = 0
      run.counts.deleted = 0
      run.counts.retained = organize
        ? 0
        : plan.entries.filter(entry => String(entry.action ?? entry.recommendation) === 'retain').length
      run.counts.review = organize
        ? 0
        : plan.entries.filter(entry => String(entry.action ?? entry.recommendation) === 'review').length
      run.counts.organized = 0
      await writeJsonAtomic(runPath(context.stateRoot, runId), run)
      // A preview must not consume the plan: the same token can still be
      // reviewed and applied after the caller explicitly confirms it.
      await updatePlanStatus(context, plan, { lastDryRunId: runId })
      await appendJsonl(eventPath(context.stateRoot), { schemaVersion: 1, event: 'run-dry-run', runId, completedAt: run.completedAt })
      return compactRun(run)
    }

    let aborted = false
    let abortReason
    for (const entry of plan.entries) {
      let rel = String(entry?.relativePath ?? '')
      let failureRecord = { ...entry, status: 'failed' }
      try {
        throwIfAborted(options.signal)
        rel = safeRelativePath(rel)
        const action = normalizeAction(entry.action ?? entry.recommendation) ?? 'archive'
        // Retain/review decisions are durable audit entries, but do not mutate
        // the workspace unless the caller explicitly requests organization.
        if ((action === 'retain' || action === 'review') && !organize) {
          const status = action === 'retain' ? 'retained' : 'review-required'
          const catalogUpdate = await catalogConfirmInPlace(context, rel, entry, 'confirmed')
          const runEntry = {
            ...entry,
            relativePath: rel,
            action,
            status,
            catalogStatus: catalogUpdate.error ? 'update-failed' : 'confirmed',
            decidedAt: nowIso(),
          }
          if (catalogUpdate.error) appendCatalogError(run, rel, 'confirm', catalogUpdate.error)
          run.entries.push(runEntry)
          if (action === 'retain') run.counts.retained += 1
          else run.counts.review += 1
          await appendJsonl(eventPath(context.stateRoot), {
            schemaVersion: 1,
            event: `file-${status}`,
            runId,
            relativePath: rel,
            action,
          })
          await writeJsonAtomic(runPath(context.stateRoot, runId), run)
          continue
        }
        const sourcePath = assertManagedPath(context.root, rel, context.config, 'plan entry')
        const source = await safeExistingFile(sourcePath, context.root, 'source')
        if (!source) throw new HygieneError('source disappeared before apply', 'SOURCE_MISSING')
        if (source.info.size !== entry.size) throw new HygieneError('file size changed since plan', 'SOURCE_CHANGED')
        const digest = await hashFile(source.absolute, options.signal)
        if (!equalDigest(digest.sha256, entry.sha256 ?? entry.hash)) {
          throw new HygieneError('file content changed since plan', 'SOURCE_CHANGED', { currentSha256: digest.sha256 })
        }

        if ((action === 'retain' || action === 'review') && organize) {
          // `suggestedPath` is the metadata catalog location.  Only the
          // explicit source-side aliases may be passed to a file move;
          // falling back to the legacy field is retained for old plans, while
          // assertOrganizationPath() rejects a workspace-artifacts target
          // before any mutation.
          const suggested = entry.organization?.suggestedSourcePath
            ?? entry.organization?.physicalSuggestedPath
            ?? entry.organization?.suggestedPath
          if (!suggested) throw new HygieneError('organization suggestion is missing', 'DESTINATION_ERROR')
          const requestedDestination = assertOrganizationPath(context, suggested)
          if (resolve(requestedDestination) === resolve(sourcePath)) {
            const catalogUpdate = await catalogConfirmInPlace(context, rel, entry, 'applied')
            run.entries.push({
              ...entry,
              relativePath: rel,
              action,
              execution: 'organize',
              status: 'already-organized',
              catalogStatus: catalogUpdate.error ? 'update-failed' : 'applied',
              organizedRelativePath: rel,
              organizedAt: nowIso(),
            })
            if (catalogUpdate.error) appendCatalogError(run, rel, 'organize', catalogUpdate.error)
            run.counts.organized += 1
            await writeJsonAtomic(runPath(context.stateRoot, runId), run)
            continue
          }
          const destination = await collisionSafeWorkspaceDestination(context.root, suggested)
          await assertOrganizationPath(context, destination.relativePath)
          await ensureNoSymlinkAncestors(dirname(destination.absolute), context.root)
          // Keep the destination in the failure record before the move. If a
          // post-move verification fails, restore can still locate the file
          // and recover it instead of treating the artifact as permanently
          // lost.
          failureRecord = {
            ...entry,
            status: 'failed',
            organizedRelativePath: destination.relativePath,
            organizedPath: destination.absolute,
          }
          await moveFile(source.absolute, destination.absolute, context.root)
          const organized = await safeExistingFile(destination.absolute, context.root, 'organized destination')
          const organizedDigest = organized ? await hashFile(organized.absolute, options.signal) : undefined
          if (!organizedDigest || !equalDigest(organizedDigest.sha256, entry.sha256 ?? entry.hash)) {
            throw new HygieneError('organization hash verification failed', 'ORGANIZE_VERIFY_FAILED')
          }
          const catalogUpdate = await catalogMoveAfterOrganization(
            context,
            rel,
            destination.relativePath,
            entry,
          )
          run.entries.push({
            ...entry,
            relativePath: rel,
            action,
            execution: 'organize',
            status: 'organized',
            catalogStatus: catalogUpdate.error ? 'update-failed' : 'applied',
            organizedRelativePath: destination.relativePath,
            organizedPath: destination.absolute,
            organizedAt: nowIso(),
          })
          if (catalogUpdate.error) {
            appendCatalogError(run, rel, 'organize', catalogUpdate.error)
          }
          run.counts.organized += 1
          run.bytes += entry.size
          await appendJsonl(eventPath(context.stateRoot), {
            schemaVersion: 1,
            event: 'file-organized',
            runId,
            relativePath: rel,
            organizedRelativePath: destination.relativePath,
            action,
            sha256: entry.sha256,
            size: entry.size,
          })
          await writeJsonAtomic(runPath(context.stateRoot, runId), run)
          continue
        }

        // A delete recommendation is quarantined by default. Permanent
        // deletion is only reachable when the policy and this invocation both
        // opt in (permanentDelete + confirmDelete).
        const catalogDeleteConfirmed = catalogDeletionAuthorized(context, rel, catalogDeleteSet, {
          catalogConfirmationAllowed,
          planConfirmed,
          options,
        })
        const permanentDeleteForEntry = permanentDelete || catalogDeleteConfirmed
        if (action === 'delete' && permanentDeleteForEntry) {
          const finalCheck = await safeExistingFile(sourcePath, context.root, 'delete source')
          if (!finalCheck || finalCheck.info.size !== entry.size) {
            throw new HygieneError('file changed before delete', 'SOURCE_CHANGED')
          }
          // Re-hash immediately before the irreversible unlink. A concurrent
          // writer can replace a file with another file of the same size after
          // the initial apply-time check; deleting that replacement would be
          // a data-loss bug. The digest is the plan's content binding, not
          // merely a size/mtime hint.
          const finalDigest = await hashFile(finalCheck.absolute, options.signal)
          if (!equalDigest(finalDigest.sha256, entry.sha256 ?? entry.hash)) {
            throw new HygieneError('file content changed before delete', 'SOURCE_CHANGED', {
              currentSha256: finalDigest.sha256,
            })
          }
          // Detect a replacement that happened while the final hash was being
          // computed. The inode/device check complements the digest and keeps
          // the irreversible operation bound to the same directory entry that
          // was inspected.
          let afterDigestInfo
          try { afterDigestInfo = await lstat(finalCheck.absolute) } catch (error) {
            if (error?.code === 'ENOENT') throw new HygieneError('file changed before delete', 'SOURCE_CHANGED')
            throw error
          }
          if (!afterDigestInfo.isFile()
            || afterDigestInfo.size !== finalCheck.info.size
            || afterDigestInfo.mtimeMs !== finalCheck.info.mtimeMs
            || afterDigestInfo.dev !== finalCheck.info.dev
            || afterDigestInfo.ino !== finalCheck.info.ino) {
            throw new HygieneError('file changed before delete', 'SOURCE_CHANGED')
          }
          await unlink(finalCheck.absolute)
          // A confirmed delete consumes the corresponding to-delete catalog
          // entry.  The catalog helper is metadata-only; the source unlink
          // above is the destructive operation and has already passed all
          // hash/inode checks.
          const catalogUpdate = await catalogRemoveAfterSourceAction(context, rel)
          run.entries.push({
            ...entry,
            relativePath: rel,
            action,
            execution: 'delete',
            status: 'deleted',
            catalogStatus: catalogUpdate.error ? 'update-failed' : 'removed',
            deletedAt: nowIso(),
          })
          if (catalogUpdate.error) appendCatalogError(run, rel, 'delete', catalogUpdate.error)
          run.counts.deleted += 1
          run.bytes += entry.size
          await appendJsonl(eventPath(context.stateRoot), {
            schemaVersion: 1,
            event: 'file-deleted',
            runId,
            relativePath: rel,
            sha256: entry.sha256,
            size: entry.size,
          })
          await writeJsonAtomic(runPath(context.stateRoot, runId), run)
          continue
        }

        const destination = await collisionSafeDestination(context.archiveRoot, runId, rel)
        const archivedRelativePath = toPosixPath(relative(context.archiveRoot, destination.absolute))
        failureRecord = { ...entry, status: 'failed', archivedRelativePath }
        await ensureNoSymlinkAncestors(dirname(destination.absolute), context.archiveRoot)
        await moveFile(source.absolute, destination.absolute, context.archiveRoot)
        const archived = await safeExistingFile(destination.absolute, context.archiveRoot, 'archive')
        const archivedDigest = archived ? await hashFile(archived.absolute, options.signal) : undefined
        if (!archivedDigest || !equalDigest(archivedDigest.sha256, entry.sha256 ?? entry.hash)) {
          // Never overwrite a source that may have been recreated by a user;
          // an exclusive move either succeeds into an empty path or leaves the
          // verified archive for manual restore.
          throw new HygieneError('archive hash verification failed', 'ARCHIVE_VERIFY_FAILED')
        }
        // Quarantine removes the source path from the active workspace, but
        // the metadata entry remains as a provenance pointer to the archive.
        // Only a confirmed delete retires a `to-delete` entry entirely.
        const catalogUpdate = await catalogArchiveAfterSourceAction(
          context,
          rel,
          entry,
          archivedRelativePath,
        )
        run.entries.push({
          ...entry,
          action,
          execution: 'quarantine',
          status: 'quarantined',
          catalogStatus: catalogUpdate.error ? 'update-failed' : 'archived',
          archivedRelativePath,
          archivedPath: destination.absolute,
          quarantinedAt: nowIso(),
        })
        if (catalogUpdate.error) appendCatalogError(run, rel, 'quarantine', catalogUpdate.error)
        run.counts.quarantined += 1
        run.bytes += entry.size
        await appendJsonl(eventPath(context.stateRoot), {
          schemaVersion: 1,
          event: 'file-quarantined',
          runId,
          relativePath: rel,
          archivedRelativePath,
          sha256: entry.sha256,
          size: entry.size,
        })
      } catch (error) {
        const message = error?.message ?? String(error)
        const code = error?.code ?? 'MOVE_FAILED'
        const details = error?.details
        run.counts.failed += 1
        run.errors.push({ relativePath: rel, code, message, ...(details === undefined ? {} : { details }) })
        run.entries.push({ ...failureRecord, relativePath: rel, status: options.signal?.aborted ? 'aborted' : failureRecord.status, error: message })
        if (options.signal?.aborted) {
          aborted = true
          abortReason = error
        }
      }
      await writeJsonAtomic(runPath(context.stateRoot, runId), run)
      if (aborted) break
    }

    run.completedAt = nowIso()
    run.status = aborted
      ? 'aborted'
      : run.counts.failed > 0
      ? (run.counts.quarantined > 0 ? 'partial' : 'failed')
      : 'completed'
    await writeJsonAtomic(runPath(context.stateRoot, runId), run)
    await updatePlanStatus(context, plan, { status: 'applied', lastRunId: runId, appliedAt: run.completedAt })
    await appendJsonl(eventPath(context.stateRoot), {
      schemaVersion: 1,
      event: 'run-completed',
      runId,
      planId: plan.planId,
      status: run.status,
      completedAt: run.completedAt,
      counts: run.counts,
      bytes: run.bytes,
    })
    const compacted = compactRun(run)
    if (aborted) {
      // Preserve the durable run record before honoring normal cancellation
      // semantics expected by the Harness tool pipeline.
      throw abortReason instanceof Error ? abortReason : new Error('operation aborted')
    }
    return compacted
  } finally {
    await lock.release()
  }
}

function compactRun(run) {
  const entries = Array.isArray(run?.entries) ? run.entries : []
  const errors = Array.isArray(run?.errors) ? run.errors : []
  return {
    ok: run?.status === 'completed' || run?.status === 'partial' || run?.status === 'dry-run',
    schemaVersion: run?.schemaVersion,
    runId: run?.runId,
    planId: run?.planId,
    root: run?.root,
    archiveRoot: run?.archiveRoot,
    startedAt: run?.startedAt,
    completedAt: run?.completedAt,
    status: run?.status,
    counts: run?.counts,
    bytes: run?.bytes,
    errors: errors.slice(0, 50),
    entries: entries.map(entry => ({
      relativePath: entry.relativePath,
      directory: entry.directory,
      name: entry.name,
      purpose: entry.purpose,
      archivedRelativePath: entry.archivedRelativePath,
      organizedRelativePath: entry.organizedRelativePath,
      size: entry.size,
      status: entry.status,
      action: entry.action,
      execution: entry.execution,
      catalogStatus: entry.catalogStatus,
      sha256: entry.sha256 ?? entry.hash,
      valueScore: entry.valueScore,
      valueClass: entry.valueClass,
      recommendation: entry.recommendation,
      decisionSource: entry.decisionSource,
      selectionReason: entry.selectionReason,
      valueReasons: entry.valueReasons,
      valueSignals: entry.valueSignals,
      organization: entry.organization,
      error: entry.error,
    })),
  }
}

/** Restore a completed or partial run without overwriting user files. */
export async function restoreRun(inputRoot, inputConfig = {}, reference, options = {}) {
  if (inputRoot && typeof inputRoot === 'object') {
    const request = inputRoot
    options = { ...request, ...(options && typeof options === 'object' ? options : {}) }
    reference = request.run ?? request.runId ?? request
    inputConfig = request.config ?? request
    inputRoot = request.workspaceRoot
  }
  const context = await workspaceContext(inputRoot, inputConfig)
  if (context.config.enabled === false) throw new HygieneError('workspace hygiene is disabled', 'DISABLED')
  await ensureStateDirectories(context)
  let { run } = await loadRun(context, reference, options)
  if (run.root !== context.root) throw new HygieneError('run root does not match workspace root', 'ROOT_MISMATCH')
  // A restore must use the archive location recorded by the run.  Silently
  // following a newly configured archive root would turn a harmless config
  // change into an apparent missing artifact and could restore the wrong
  // bytes if a path were reused.
  if (run.archiveRoot !== undefined && resolve(run.archiveRoot) !== context.archiveRoot) {
    throw new HygieneError('archive root changed since the run was created', 'ARCHIVE_ROOT_CHANGED', {
      recorded: run.archiveRoot,
      current: context.archiveRoot,
    })
  }
  if (run.status === 'dry-run') {
    // A preview run never moved anything and therefore cannot be restored.
    // Keep the durable status unchanged instead of turning an empty preview
    // into a misleading successful restore.
    return {
      ok: false,
      code: 'RUN_NOT_RESTORABLE',
      runId: run.runId,
      status: run.status,
      message: 'dry-run records contain no archived files to restore',
    }
  }
  // A completed run containing only retain/review decisions did not move any
  // files. Report that explicitly instead of converting its lifecycle status
  // to `restored`, which would falsely suggest that a rollback occurred.
  const restorableEntries = (run.entries ?? []).filter(entry => RESTORE_ENTRY_STATUSES.includes(entry.status))
  if (restorableEntries.length === 0 && run.status !== 'restored') {
    return {
      ok: false,
      code: 'RUN_NOT_RESTORABLE',
      runId: run.runId,
      status: run.status,
      pendingCount: 0,
      message: 'run contains no archived or organized files to restore',
    }
  }
  // Direct library callers historically restored immediately when they did
  // not pass an options object. Model-facing adapters always pass `confirm`,
  // so a missing/false confirmation becomes a harmless preview instead of a
  // surprising mutation.
  if (Object.hasOwn(options, 'confirm') && options.confirm !== true && options.dryRun !== true) {
    const pending = (run.entries ?? []).filter(entry => RESTORE_ENTRY_STATUSES.includes(entry.status))
    return {
      ok: false,
      requiresConfirmation: true,
      code: 'CONFIRMATION_REQUIRED',
      runId: run.runId,
      status: run.status,
      pending: pending.length,
      message: 'Pass confirm:true to restore archived files; existing different files are never overwritten.',
    }
  }
  if (options.dryRun === true) {
    const pendingEntries = (run.entries ?? [])
      .filter(entry => RESTORE_ENTRY_STATUSES.includes(entry.status)
        && Boolean(entry.archivedRelativePath ?? entry.organizedRelativePath))
    const pending = pendingEntries.slice(0, 100)
      .map(entry => ({
      relativePath: entry.relativePath,
      directory: entry.directory,
      name: entry.name,
      purpose: entry.purpose,
        archivedRelativePath: entry.archivedRelativePath,
        organizedRelativePath: entry.organizedRelativePath,
        size: entry.size,
        status: entry.status,
      }))
    const unrecoverableEntries = (run.entries ?? [])
      .filter(entry => RESTORE_ENTRY_STATUSES.includes(entry.status)
        && !entry.archivedRelativePath && !entry.organizedRelativePath)
    const unrecoverable = unrecoverableEntries.slice(0, 100)
      .map(entry => ({
        relativePath: entry.relativePath,
        status: entry.status,
        code: 'NO_ARCHIVE',
        message: 'no archived or organized file is available for this entry',
      }))
    if (pendingEntries.length === 0 && unrecoverableEntries.length === 0) {
      const alreadyRestored = run.status === 'restored'
      return {
        ok: alreadyRestored,
        dryRun: true,
        ...(alreadyRestored ? { code: 'ALREADY_RESTORED' } : { code: 'RUN_NOT_RESTORABLE' }),
        runId: run.runId,
        status: run.status,
        pendingCount: 0,
        pending: [],
        unrecoverableCount: 0,
        unrecoverable: [],
        archiveRoot: run.archiveRoot,
        message: alreadyRestored
          ? 'run has already been restored'
          : 'run contains no archived or organized files to restore',
      }
    }
    return {
      ok: unrecoverableEntries.length === 0,
      dryRun: true,
      runId: run.runId,
      status: run.status,
      pendingCount: pendingEntries.length,
      pending,
      unrecoverableCount: unrecoverableEntries.length,
      unrecoverable,
      archiveRoot: run.archiveRoot,
    }
  }
  if (run.status === 'restored') return compactRestore(run, run.restoreConflicts ?? [], run.restoreErrors ?? [])
  const lock = await acquireWorkspaceLock(context.stateRoot, options)
  try {
    const fresh = await loadRun(context, reference, options)
    run = fresh.run
    if (run.root !== context.root) throw new HygieneError('run root does not match workspace root', 'ROOT_MISMATCH')
    if (run.archiveRoot !== undefined && resolve(run.archiveRoot) !== context.archiveRoot) {
      throw new HygieneError('archive root changed since the run was created', 'ARCHIVE_ROOT_CHANGED', {
        recorded: run.archiveRoot,
        current: context.archiveRoot,
      })
    }
    if (run.status === 'restored') {
      await lock.release()
      return compactRestore(run, run.restoreConflicts ?? [], run.restoreErrors ?? [])
    }
  } catch (error) {
    await lock.release()
    throw error
  }
  const conflicts = []
  const errors = []
  let restored = 0
  let aborted = false
  let abortReason
  try {
    for (const entry of run.entries ?? []) {
      // An apply interrupted after moving a file records `aborted`; if its
      // archive path is present it is just as recoverable as a quarantined or
      // failed entry and must remain eligible for a later restore attempt.
      if (!RESTORE_ENTRY_STATUSES.includes(entry.status)) continue
      let rel = String(entry?.relativePath ?? '')
      try {
        throwIfAborted(options.signal)
        rel = safeRelativePath(rel)
        // A failed move or permanent deletion has no recoverable source.
        // Record it as an explicit unresolved error instead of allowing an
        // otherwise empty run to be mislabeled "restored".
        const organizedEntry = entry.status === 'organized' || Boolean(entry.organizedRelativePath)
        const movedRelativePath = organizedEntry
          ? entry.organizedRelativePath
          : entry.archivedRelativePath
        if (!movedRelativePath) {
          errors.push({ relativePath: rel, code: 'NO_ARCHIVE', message: 'no archived file is available for this entry' })
          continue
        }
        // A run record is durable state, but it is still a local JSON file
        // that can be edited between apply and restore. Re-apply the current
        // managed-path policy here so a tampered record cannot redirect an
        // archive into .git, credentials, source metadata, or another
        // protected tree. Restores may therefore require the operator to
        // temporarily widen a changed managedRoots policy, but never bypass
        // the hard protection boundary.
        let sourcePath
        try {
          sourcePath = assertManagedPath(context.root, rel, context.config, 'restore source')
        } catch (error) {
          throw new HygieneError(error?.message ?? String(error), 'PATH_POLICY_REJECTED')
        }
        const movedRel = safeRelativePath(movedRelativePath)
        const movedBoundary = organizedEntry ? context.root : context.archiveRoot
        const movedAbsolute = assertInside(movedBoundary, resolve(movedBoundary, movedRel), organizedEntry ? 'organized source' : 'restore archive')
        if (organizedEntry && isProtectedRelativePath(movedRel, context.config)) {
          throw new HygieneError(`organized source is protected by policy: ${movedRel}`, 'PATH_POLICY_REJECTED')
        }
        const moved = await safeExistingFile(movedAbsolute, movedBoundary, organizedEntry ? 'organized source' : 'archive')
        if (!moved) throw new HygieneError(organizedEntry ? 'organized file is missing' : 'quarantined file is missing', 'ARCHIVE_MISSING')
        const movedDigest = await hashFile(moved.absolute, options.signal)
        if (!equalDigest(movedDigest.sha256, entry.sha256 ?? entry.hash)) {
          throw new HygieneError(organizedEntry ? 'organized file failed hash verification' : 'quarantined file failed hash verification', 'ARCHIVE_CHANGED')
        }
        let existing
        try {
          // Use the same realpath-aware guard as archive files. A path can be
          // redirected outside the workspace after planning by replacing one
          // of its parent directories with a symlink; hashing that target
          // would otherwise read data beyond the declared boundary.
          existing = await safeExistingFile(sourcePath, context.root, 'restore target')
        } catch (error) {
          const code = error?.code
          if (code === 'SYMLINK_REJECTED' || code === 'FILE_TYPE_REJECTED' || code === 'PATH_ESCAPE') {
            conflicts.push({ relativePath: rel, code: code === 'SYMLINK_REJECTED' ? 'SYMLINK_CONFLICT' : code, message: error.message })
            continue
          }
          throw error
        }
        if (existing) {
          const current = await hashFile(existing.absolute, options.signal)
          if (equalDigest(current.sha256, entry.sha256 ?? entry.hash)) {
            // The content is already restored; retain the archive as a
            // verified backup and mark the manifest accordingly.
            entry.status = 'already-restored'
            const catalogUpdate = organizedEntry
              ? await catalogMoveAfterOrganization(context, movedRel, rel, entry)
              : await catalogConfirmInPlace(context, rel, entry, 'pending')
            entry.catalogStatus = catalogUpdate.error ? 'update-failed' : 'restored'
            if (catalogUpdate.error) errors.push({
              relativePath: rel,
              code: 'CATALOG_UPDATE_FAILED',
              operation: 'restore',
              message: catalogUpdate.error?.message ?? String(catalogUpdate.error),
            })
            entry.restoredAt = nowIso()
            restored += 1
            continue
          }
          conflicts.push({ relativePath: rel, code: 'TARGET_EXISTS', message: 'restore target exists and differs' })
          continue
        }
        // Check parents before mkdir so a symlink cannot redirect creation.
        await ensureNoSymlinkAncestors(dirname(sourcePath), context.root)
        await mkdir(dirname(sourcePath), { recursive: true })
        await ensureNoSymlinkAncestors(dirname(sourcePath), context.root)
        await moveFile(moved.absolute, sourcePath, context.root)
        const restoredInfo = await safeExistingFile(sourcePath, context.root, 'restored source')
        const restoredDigest = restoredInfo ? await hashFile(restoredInfo.absolute, options.signal) : undefined
        if (!restoredDigest || !equalDigest(restoredDigest.sha256, entry.sha256 ?? entry.hash)) {
          // Do not overwrite a user-created target while attempting rollback.
          throw new HygieneError('restore hash verification failed', 'RESTORE_VERIFY_FAILED')
        }
        entry.status = 'restored'
        const catalogUpdate = organizedEntry
          ? await catalogMoveAfterOrganization(context, movedRel, rel, entry)
          : await catalogConfirmInPlace(context, rel, entry, 'pending')
        entry.catalogStatus = catalogUpdate.error ? 'update-failed' : 'restored'
        if (catalogUpdate.error) errors.push({
          relativePath: rel,
          code: 'CATALOG_UPDATE_FAILED',
          operation: 'restore',
          message: catalogUpdate.error?.message ?? String(catalogUpdate.error),
        })
        entry.restoredAt = nowIso()
        restored += 1
        await appendJsonl(eventPath(context.stateRoot), {
          schemaVersion: 1,
          event: 'file-restored',
          runId: run.runId,
          relativePath: rel,
          ...(organizedEntry ? { organizedRelativePath: movedRel } : { archivedRelativePath: movedRel }),
          sha256: entry.sha256,
        })
      } catch (error) {
        const message = error?.message ?? String(error)
        const code = error?.code ?? 'RESTORE_FAILED'
        errors.push({ relativePath: rel, code, message })
        if (options.signal?.aborted) {
          aborted = true
          abortReason = error
        }
      }
      await writeJsonAtomic(runPath(context.stateRoot, run.runId), run)
      if (aborted) break
    }
    const remaining = (run.entries ?? []).filter(entry => (
      RESTORE_ENTRY_STATUSES.includes(entry.status)
      && Boolean(entry.archivedRelativePath ?? entry.organizedRelativePath)
    )).length
    const unresolvedWithoutArchive = (run.entries ?? []).filter(entry => (
      RESTORE_ENTRY_STATUSES.includes(entry.status)
      && !entry.archivedRelativePath && !entry.organizedRelativePath
    )).length
    run.status = aborted
      ? 'restore-aborted'
      : (remaining === 0 && unresolvedWithoutArchive === 0 && conflicts.length === 0 && errors.length === 0
        ? 'restored'
        : 'restore-partial')
    run.restoredAt = nowIso()
    run.restoreConflicts = conflicts
    run.restoreErrors = errors
    await writeJsonAtomic(runPath(context.stateRoot, run.runId), run)
    await appendJsonl(eventPath(context.stateRoot), {
      schemaVersion: 1,
      event: 'run-restored',
      runId: run.runId,
      restoredAt: run.restoredAt,
      restored,
      conflicts: conflicts.length,
      errors: errors.length,
      status: run.status,
    })
    const compacted = compactRestore(run, conflicts, errors, restored)
    if (aborted) throw abortReason instanceof Error ? abortReason : new Error('operation aborted')
    return compacted
  } finally {
    await lock.release()
  }
}

function compactRestore(run, conflicts = [], errors = [], restored = 0) {
  const restoredCount = restored || (run.entries ?? []).filter(entry => ['restored', 'already-restored'].includes(entry.status)).length
  return {
    ok: run.status === 'restored' && conflicts.length === 0 && errors.length === 0,
    runId: run.runId,
    status: run.status,
    restored: restoredCount,
    conflicts,
    errors,
    archiveRoot: run.archiveRoot,
  }
}

async function listRecords(directory, kind) {
  await ensureNoSymlinkPath(directory)
  let entries
  try { entries = await readdir(directory, { withFileTypes: true }) } catch (error) {
    if (error?.code === 'ENOENT') return []
    throw error
  }
  const records = []
  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith('.json')) continue
    try {
      const record = kind
        ? await readStateRecord(join(directory, entry.name), kind)
        : await readJson(join(directory, entry.name))
      if (record) records.push(record)
    } catch {
      // Status/prune are maintenance surfaces: a truncated or manually
      // removed record must not prevent the rest of the workspace summary
      // from being read. Direct plan/run loads still fail closed with
      // STATE_CORRUPT above.
    }
  }
  records.sort((a, b) => String(b.createdAt ?? b.startedAt ?? '').localeCompare(String(a.createdAt ?? a.startedAt ?? '')))
  return records
}

/** Return a compact state summary without scanning the workspace. */
export async function status(inputRoot, inputConfig = {}, options = {}) {
  if (inputRoot && typeof inputRoot === 'object') {
    const request = inputRoot
    options = { ...request, ...(options && typeof options === 'object' ? options : {}) }
    inputConfig = request.config ?? request
    inputRoot = request.workspaceRoot
  }
  const context = await workspaceContext(inputRoot, inputConfig)
  // Status is a read-only surface. Check existing path components for links,
  // but do not create `.dsh-hygiene` or an external archive merely to report
  // that no plans/runs exist yet.
  await ensureNoSymlinkPath(context.stateRoot, context.root)
  await ensureNoSymlinkPath(context.archiveRoot)
  const [plans, runs] = await Promise.all([
    listRecords(plansDirectory(context.stateRoot), 'workspace-hygiene-plan'),
    listRecords(runsDirectory(context.stateRoot), 'workspace-hygiene-run'),
  ])
  let lock
  try {
    const lockPath = join(context.stateRoot, '.lock')
    const lockInfo = await lstat(lockPath)
    if (!lockInfo.isSymbolicLink() && lockInfo.isFile()) lock = JSON.parse(await readFile(lockPath, 'utf8'))
  } catch {}
  const activePlans = plans.filter(plan => plan.status === 'planned' && !isExpired(plan))
  // Count manifest entries whose archive file still exists. A successful
  // restore moves the file back and therefore should not leave phantom bytes
  // in the disk accounting; stranded archives from partial failures remain
  // visible.
  const archivedEntries = []
  for (const run of runs) {
    for (const entry of (Array.isArray(run.entries) ? run.entries : [])) {
      if (typeof entry.archivedRelativePath !== 'string' || entry.archivedRelativePath === '') continue
      try {
        const archiveRel = safeRelativePath(entry.archivedRelativePath)
        const archivePath = assertInside(context.archiveRoot, resolve(context.archiveRoot, archiveRel), 'status archive')
        // Reuse the realpath-aware guard so a parent directory replaced by a
        // symlink cannot make a read-only status query account for bytes
        // outside the configured archive boundary.
        const existing = await safeExistingFile(archivePath, context.archiveRoot, 'status archive')
        if (existing) archivedEntries.push(entry)
      } catch {
        // Missing, malformed, or redirected archive paths are not counted as
        // present bytes; the run record remains available for diagnostics.
      }
    }
  }
  const archivedBytes = archivedEntries.reduce((sum, entry) => sum + Number(entry.size || 0), 0)
  let catalog
  try {
    catalog = await readCatalog(context.root, context.config, { strict: false })
  } catch (error) {
    // Keep status useful when optional, hand-edited metadata is malformed;
    // expose the bounded error rather than hiding the condition.
    catalog = { error: { code: error?.code ?? 'CATALOG_READ_ERROR', message: error?.message ?? String(error) } }
  }
  const limit = Number.isInteger(options.limit) && options.limit > 0 ? Math.min(options.limit, 100) : 10
  return {
    schemaVersion: 1,
    root: context.root,
    stateRoot: context.stateRoot,
    archiveRoot: context.archiveRoot,
    policyFingerprint: policyFingerprint(context.config),
    lock: lock ? { pid: lock.pid, createdAt: lock.createdAt } : null,
    counts: {
      plans: plans.length,
      activePlans: activePlans.length,
      runs: runs.length,
      archivedFiles: archivedEntries.length,
      archivedBytes,
      ...(catalog?.counts ? { catalogEntries: Object.values(catalog.counts).reduce((sum, value) => sum + Number(value || 0), 0) } : {}),
    },
    catalog: catalog?.error ? catalog : projectCatalog(catalog, limit),
    latestPlan: plans[0] ? compactPlan(plans[0]) : null,
    latestRun: runs[0] ? compactRun(runs[0]) : null,
    plans: plans.slice(0, limit).map(plan => ({
      planId: plan.planId,
      createdAt: plan.createdAt,
      expiresAt: plan.expiresAt,
      status: plan.status,
      selectedCount: plan.entries?.length ?? 0,
      selectedBytes: plan.selectedBytes ?? 0,
    })),
    runs: runs.slice(0, limit).map(run => ({
      runId: run.runId,
      planId: run.planId,
      startedAt: run.startedAt,
      completedAt: run.completedAt,
      status: run.status,
      counts: run.counts,
      bytes: run.bytes,
    })),
  }
}

export const getStatus = status
export const statusWorkspace = status
export const createPlan = planWorkspace
export const executePlan = applyPlan

/** Remove expired plan records while retaining the audit stream. */
export async function pruneExpiredPlans(inputRoot, inputConfig = {}, options = {}) {
  const context = await workspaceContext(inputRoot, inputConfig)
  await ensureStateDirectories(context)
  if (options.dryRun !== true && options.confirm !== true) {
    return {
      removed: [],
      wouldRemove: [],
      dryRun: false,
      requiresConfirmation: true,
      code: 'CONFIRMATION_REQUIRED',
      message: 'Pass confirm:true to remove expired plan records.',
    }
  }
  const lock = await acquireWorkspaceLock(context.stateRoot, options)
  const plans = await listRecords(plansDirectory(context.stateRoot), 'workspace-hygiene-plan')
  const removed = []
  try {
    for (const plan of plans) {
      if (!isExpired(plan) || plan.status === 'applied') continue
      const planId = normalizePlanId(plan.planId)
      if (!planId) continue
      if (options.dryRun === true) { removed.push(planId); continue }
      try {
        await rm(planPath(context.stateRoot, planId), { force: true })
        removed.push(planId)
        await appendJsonl(eventPath(context.stateRoot), {
          schemaVersion: 1,
          event: 'plan-pruned',
          planId,
          root: context.root,
          at: nowIso(),
        })
      } catch (error) {
        if (error?.code !== 'ENOENT') throw error
      }
    }
    return {
      removed: options.dryRun === true ? [] : removed,
      wouldRemove: options.dryRun === true ? removed : [],
      dryRun: options.dryRun === true,
    }
  } finally {
    await lock.release()
  }
}

export default {
  HygieneError,
  workspaceContext,
  acquireWorkspaceLock,
  planWorkspace,
  applyPlan,
  restoreRun,
  status,
  getStatus,
  statusWorkspace,
  createPlan,
  executePlan,
  pruneExpiredPlans,
}
