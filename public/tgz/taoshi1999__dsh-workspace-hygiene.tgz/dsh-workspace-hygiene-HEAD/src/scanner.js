// Stable module name for consumers.  The implementation lives in scan.js to
// preserve the short CLI-facing filename used by the first preview release.
export * from './scan.js'
export { default } from './scan.js'
