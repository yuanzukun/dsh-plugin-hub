/**
 * Model-facing adapters for dsh-workspace-hygiene.
 *
 * The core modules intentionally know nothing about Cordis. This file is the
 * thin boundary that turns them into native DeepSeek Harness tools while also
 * exposing the same handlers to the standalone CLI and tests. Tool results are
 * canonical JSON objects; the renderer only adds a bounded human-readable
 * projection.
 */

import { resolve } from 'node:path'
import { resolveConfig } from './config.js'
import { explainPath, projectScan, scanWorkspace } from './scan.js'
import { projectCatalog, readCatalog, syncCatalog } from './catalog.js'
import {
  HygieneError,
  applyPlan,
  planWorkspace,
  restoreRun,
  status,
} from './transaction.js'

export const TOOL_NAMES = Object.freeze([
  'workspace_hygiene_scan',
  'workspace_hygiene_plan',
  'workspace_hygiene_apply',
  'workspace_hygiene_restore',
  'workspace_hygiene_status',
  'workspace_hygiene_explain',
])

const COMMON_PROPERTIES = Object.freeze({
  workspaceRoot: {
    type: 'string',
    description: 'Optional workspace path. It must match the configured/session workspace unless allowPathOverride is enabled.',
  },
})

function objectParameters(properties, required = []) {
  return {
    type: 'object',
    properties,
    required,
    additionalProperties: false,
  }
}

const OUTPUT_SCHEMA = Object.freeze({ type: 'object', additionalProperties: true })

function compactJson(value, maxChars = 12_000) {
  let text
  try { text = JSON.stringify(value, null, 2) } catch { text = String(value) }
  if (text.length <= maxChars) return text
  return `${text.slice(0, maxChars)}\n… [truncated; use structured fields or inspect the state directory]`
}

/** Materialize a tool result as lossless JSON before it reaches Harness. */
function canonicalJson(value) {
  const encoded = JSON.stringify(value)
  if (encoded === undefined) return null
  return JSON.parse(encoded)
}

function outputDefinition() {
  return {
    schema: OUTPUT_SCHEMA,
    render: (_args, value) => [{ type: 'text', text: compactJson(value) }],
  }
}

/** Raw JSON-Schema definitions accepted directly by ctx.tools.register(). */
export const TOOL_DEFINITIONS = Object.freeze({
  workspace_hygiene_scan: {
    name: 'workspace_hygiene_scan',
    description: 'Read-only bounded inventory with value scores, retain/archive/delete recommendations, and metadata-catalog suggestions. Never moves or deletes source files; catalog JSON may be refreshed.',
    parameters: objectParameters({
      ...COMMON_PROPERTIES,
      limit: { type: 'integer', description: 'Maximum candidate rows to return (1–100; values are clamped).' },
      includeValuePolicy: { type: 'boolean', description: 'Include normalized value policy metadata (default true).' },
    }),
    output: outputDefinition(),
  },
  workspace_hygiene_plan: {
    name: 'workspace_hygiene_plan',
    description: 'Create a short-lived, hash-bound plan covering catalog decisions and optional source organization/quarantine. This is read-only and moves no files.',
    parameters: objectParameters({
      ...COMMON_PROPERTIES,
      includeMedium: { type: 'boolean', description: 'Include medium-confidence candidates (default false).' },
      includeRetain: { type: 'boolean', description: 'Include candidates recommended for retention in the review plan (default false).' },
      includeReview: { type: 'boolean', description: 'Include uncertain/review candidates (default false).' },
      actions: {
        type: 'array',
        items: { type: 'string', enum: ['retain', 'archive', 'delete', 'review'] },
        description: 'Optional action allow-list. Defaults to archive/delete; retain/review require explicit opt-in.',
      },
      decisions: {
        type: 'object',
        // dsh-tools' JSON-Schema subset accepts only a boolean here.  The
        // object keys are workspace-relative paths and therefore cannot be
        // enumerated in a static schema; normalizeDecisions() performs the
        // value validation at execution time.
        additionalProperties: true,
        description: 'Optional workspace-relative path → action overrides. Values are validated at plan time; invalid paths/actions fail closed.',
        examples: [{ 'tmp/old.log': 'delete' }],
      },
      maxFiles: { type: 'integer', description: 'Optional positive file cap; never exceeds the configured archive budget.' },
      maxBytes: { type: 'integer', description: 'Optional positive byte cap; never exceeds the configured archive budget.' },
      ttlMs: { type: 'integer', description: 'Optional plan lifetime in milliseconds; at least 1000 and at most 7 days.' },
    }),
    output: outputDefinition(),
  },
  workspace_hygiene_apply: {
    name: 'workspace_hygiene_apply',
    description: 'Apply a previously planned set. Manual calls require the exact planId, full plan token, and confirm:true; autonomousMode may satisfy confirmation from policy. Catalog entries are updated/removed independently from source moves.',
    parameters: objectParameters({
      ...COMMON_PROPERTIES,
      planId: { type: 'string', description: 'planId returned by workspace_hygiene_plan.' },
      token: { type: 'string', description: 'Secret token returned by workspace_hygiene_plan.' },
      confirm: { type: 'boolean', description: 'Set true only after reviewing the plan.' },
      dryRun: { type: 'boolean', description: 'Validate and report a run without moving files.' },
      permanentDelete: { type: 'boolean', description: 'Opt into permanent deletion for delete actions; requires valuePolicy.allowDelete and confirmDelete:true.' },
      confirmDelete: { type: 'boolean', description: 'Second explicit confirmation required for permanent deletion.' },
      organize: { type: 'boolean', description: 'After confirmation, request physical organization of retain/review entries. An explicit request may move files; idle autonomous moves additionally require valuePolicy.organization.moveFiles:true.' },
      autonomous: { type: 'boolean', description: 'Optional annotation for a configured autonomousMode run; it cannot enable autonomy by itself.' },
    }, ['planId', 'token']),
    output: outputDefinition(),
  },
  workspace_hygiene_restore: {
    name: 'workspace_hygiene_restore',
    description: 'Restore files from a prior quarantine run after archive hash and path checks. Existing different files are never overwritten.',
    parameters: objectParameters({
      ...COMMON_PROPERTIES,
      runId: { type: 'string', description: 'runId returned by workspace_hygiene_apply.' },
      confirm: { type: 'boolean', description: 'Set true to perform the restore; false returns a preview.' },
      dryRun: { type: 'boolean', description: 'Return the restore plan without moving archived files.' },
    }, ['runId']),
    output: outputDefinition(),
  },
  workspace_hygiene_status: {
    name: 'workspace_hygiene_status',
    description: 'Show compact plans, runs, metadata-catalog counts, lock state, and quarantine byte totals without scanning source files.',
    parameters: objectParameters({
      ...COMMON_PROPERTIES,
      limit: { type: 'integer', description: 'Maximum plan/run rows to return (1–100; values are clamped).' },
    }),
    output: outputDefinition(),
  },
  workspace_hygiene_explain: {
    name: 'workspace_hygiene_explain',
    description: 'Explain a path value score, retain/archive/delete recommendation, safety gate, and organization/name suggestion. This is read-only.',
    parameters: objectParameters({
      ...COMMON_PROPERTIES,
      path: { type: 'string', description: 'Workspace-relative path to explain.' },
    }, ['path']),
    output: outputDefinition(),
  },
})

function asObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function publicError(error) {
  if (error instanceof HygieneError) {
    return { code: error.code, message: error.message, ...(error.details === undefined ? {} : { details: error.details }) }
  }
  return { code: error?.code ?? 'HYGIENE_ERROR', message: error?.message ?? String(error) }
}

function errorResult(error) {
  return { ok: false, error: publicError(error) }
}

function sessionRoot(exec) {
  const cwd = exec?.agent?.session?.header?.cwd
  return typeof cwd === 'string' && cwd.trim() !== '' ? resolve(cwd) : undefined
}

/** Resolve a tool request to a canonical workspace and immutable policy. */
export async function resolveToolContext(baseConfig = {}, input = {}, exec = undefined) {
  const request = asObject(input)
  const base = asObject(baseConfig)
  const configuredRoot = typeof base.workspaceRoot === 'string' && base.workspaceRoot.trim() !== ''
    ? resolve(base.workspaceRoot)
    : undefined
  const sessionDefault = sessionRoot(exec) ?? process.cwd()
  const requestedOverride = typeof request.workspaceRoot === 'string' && request.workspaceRoot.trim() !== ''
  const requestedRoot = requestedOverride
    ? resolve(request.workspaceRoot)
    : (configuredRoot ?? sessionDefault)
  // A model-supplied path is an authority boundary even when the operator did
  // not pin workspaceRoot in configuration. Without this check a tool call
  // could silently redirect maintenance to an arbitrary directory such as
  // /etc or another checkout.
  if (requestedOverride && base.allowPathOverride !== true) {
    const expectedRoot = configuredRoot ?? resolve(sessionDefault)
    if (requestedRoot !== expectedRoot) {
      throw new HygieneError('workspaceRoot override is disabled by policy', 'PATH_OVERRIDE_DISABLED')
    }
  }
  const configInput = { ...base, workspaceRoot: requestedRoot }
  delete configInput.config
  const config = resolveConfig(configInput)
  return { root: requestedRoot, config }
}

function requestWithSignal(request, exec) {
  return exec?.signal ? { ...request, signal: exec.signal } : request
}

async function scanTool(baseConfig, input, exec) {
  const request = asObject(input)
  const { root, config } = await resolveToolContext(baseConfig, request, exec)
  const scan = await scanWorkspace(root, config, exec?.signal)
  const result = projectScan(scan, request.limit ?? config.resultLimit ?? 25)
  try {
    const catalog = await syncCatalog(root, scan, config, {
      observedAt: scan.scannedAt,
      refreshMissing: scan.truncated !== true,
      pruneMissing: scan.truncated !== true,
      strict: false,
    })
    result.catalog = projectCatalog(catalog, request.limit ?? config.resultLimit ?? 25)
  } catch (error) {
    // Catalog persistence is auxiliary to the bounded source inventory. Keep
    // scan useful if a hand-edited metadata file is malformed, while exposing
    // the issue in the result for the next maintenance cycle.
    result.catalog = { error: publicError(error) }
  }
  if (request.includeValuePolicy === false) delete result.valuePolicy
  return { ok: true, ...result }
}

async function planTool(baseConfig, input, exec) {
  const request = asObject(input)
  const { root, config } = await resolveToolContext(baseConfig, request, exec)
  const plan = await planWorkspace(root, config, requestWithSignal({
    includeMedium: request.includeMedium === true,
    includeRetain: request.includeRetain === true,
    includeReview: request.includeReview === true,
    actions: request.actions,
    decisions: request.decisions,
    maxFiles: request.maxFiles,
    maxBytes: request.maxBytes,
    ttlMs: request.ttlMs,
  }, exec))
  try {
    plan.catalog = projectCatalog(await readCatalog(root, config, { strict: false }), request.limit ?? config.resultLimit ?? 25)
  } catch (error) {
    plan.catalog = { error: publicError(error) }
  }
  return {
    ok: true,
    ...plan,
    confirmation: {
      required: true,
      instruction: config.autonomousMode === true
        ? 'autonomousMode is enabled for this profile; the idle maintainer may apply this plan after the same hash/path checks. Manual calls can still pass confirm:true. Review catalog entries before enabling unattended runs.'
        : 'Review value decisions and organization suggestions, then call workspace_hygiene_apply with this planId, token, and confirm:true. A confirmed to-delete catalog entry removes its source and metadata; permanent deletion for uncataloged recommendations additionally requires permanentDelete:true and confirmDelete:true when enabled by policy.',
    },
  }
}

async function applyTool(baseConfig, input, exec) {
  const request = asObject(input)
  const { root, config } = await resolveToolContext(baseConfig, request, exec)
  const result = await applyPlan(root, config, {
    planId: request.planId,
    token: request.token ?? request.planToken,
  }, requestWithSignal({
    confirm: request.confirm === true,
    confirmation: request.confirmation,
    confirmToken: request.confirmToken,
    token: request.token ?? request.planToken,
    dryRun: request.dryRun === true,
    // Omit a false value so autonomousMode can supply its configured default;
    // an explicit true remains an operator request for permanent deletion.
    ...(request.permanentDelete === true ? { permanentDelete: true } : {}),
    confirmDelete: request.confirmDelete === true,
    organize: request.organize === true,
    // `autonomousMode` is a profile-level authority boundary.  The optional
    // request flag is only an annotation and never bypasses that policy.
    autonomous: request.autonomous === true && config.autonomousMode === true,
  }, exec))
  try {
    const catalog = await readCatalog(root, config, { strict: false })
    return { ...result, catalog: projectCatalog(catalog, config.resultLimit ?? 25) }
  } catch (error) {
    return { ...result, catalog: { error: publicError(error) } }
  }
}

async function restoreTool(baseConfig, input, exec) {
  const request = asObject(input)
  const { root, config } = await resolveToolContext(baseConfig, request, exec)
  return restoreRun(root, config, { runId: request.runId }, requestWithSignal({
    confirm: request.confirm === true,
    dryRun: request.dryRun === true,
  }, exec))
}

async function statusTool(baseConfig, input, exec) {
  const request = asObject(input)
  const { root, config } = await resolveToolContext(baseConfig, request, exec)
  const result = await status(root, config, { limit: request.limit })
  try {
    result.catalog = projectCatalog(await readCatalog(root, config, { strict: false }), request.limit ?? config.resultLimit ?? 25)
  } catch (error) {
    result.catalog = { error: publicError(error) }
  }
  return result
}

async function explainTool(baseConfig, input, exec) {
  const request = asObject(input)
  const { root, config } = await resolveToolContext(baseConfig, request, exec)
  const result = { ok: true, ...(await explainPath(root, request.path, config)) }
  try {
    const catalog = await readCatalog(root, config, { strict: false })
    const relativePath = result.relativePath
    result.catalogEntry = catalog.entries.find(entry => entry.relativePath === relativePath) ?? null
  } catch (error) {
    result.catalogEntry = { error: publicError(error) }
  }
  return result
}

const INVOKERS = Object.freeze({
  workspace_hygiene_scan: scanTool,
  workspace_hygiene_plan: planTool,
  workspace_hygiene_apply: applyTool,
  workspace_hygiene_restore: restoreTool,
  workspace_hygiene_status: statusTool,
  workspace_hygiene_explain: explainTool,
})

/** Build the same handlers used by the CLI and the Harness adapters. */
export function buildTools(baseConfig = {}, runtime = {}) {
  const handlers = {}
  for (const toolName of TOOL_NAMES) {
    handlers[toolName] = async (input = {}, exec = undefined) => {
      try { return canonicalJson(await INVOKERS[toolName](baseConfig, input, exec)) } catch (error) { return canonicalJson(errorResult(error)) }
    }
  }
  Object.defineProperty(handlers, 'definitions', { value: TOOL_DEFINITIONS, enumerable: false })
  Object.defineProperty(handlers, 'runtime', { value: runtime, enumerable: false })
  return handlers
}

export const createToolHandlers = buildTools

function modelDefinition(toolName, baseConfig) {
  const definition = TOOL_DEFINITIONS[toolName]
  return {
    ...definition,
    output: outputDefinition(),
    async execute(args, exec) {
      // A real Harness execution must throw on infrastructure failure so its
      // registry can mark the call as isError; the standalone handlers above
      // intentionally contain errors as ordinary JSON for scripts/tests.
      return canonicalJson(await INVOKERS[toolName](baseConfig, args, exec))
    },
  }
}

/**
 * Register all model-facing tools on a real DSH tools registry.
 *
 * Raw ToolDefinitions are intentional: the Harness accepts them directly and
 * this package remains installable without bundling a second copy of
 * @deepseek-ai/dsh-tools. The registry owns validation and disposal.
 */
export function registerTools(ctx, baseConfig = {}, runtime = {}) {
  const handlers = buildTools(baseConfig, runtime)
  const disposables = []
  const register = ctx?.tools?.register
  if (typeof register !== 'function') {
    return { handlers, definitions: TOOL_DEFINITIONS, dispose: async () => {} }
  }
  try {
    for (const toolName of TOOL_NAMES) {
      const result = register.call(ctx.tools, modelDefinition(toolName, baseConfig))
      if (typeof result === 'function') disposables.push(result)
      else if (result && typeof result.dispose === 'function') disposables.push(() => result.dispose())
    }
  } catch (error) {
    // A duplicate or invalid definition must not leave a partially installed
    // tool set behind when Cordis aborts plugin activation.
    for (const dispose of disposables.reverse()) {
      try {
        const pending = dispose()
        if (pending && typeof pending.catch === 'function') pending.catch(() => {})
      } catch {}
    }
    throw error
  }
  return {
    handlers,
    definitions: TOOL_DEFINITIONS,
    async dispose() {
      for (const dispose of disposables.reverse()) {
        try { await dispose() } catch {}
      }
    },
  }
}

export const installTools = registerTools

export default {
  TOOL_NAMES,
  TOOL_DEFINITIONS,
  resolveToolContext,
  buildTools,
  createToolHandlers,
  registerTools,
  installTools,
}
