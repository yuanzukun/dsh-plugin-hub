/**
 * Configuration and safety defaults for dsh-workspace-hygiene.
 *
 * The plugin deliberately keeps the policy in one small, dependency-light
 * module.  The harness may validate the exported Schemastery schema, while
 * resolveConfig() also makes the standalone CLI useful without a harness.
 */

import { homedir } from 'node:os'
import { extname, isAbsolute, join, resolve } from 'node:path'
import z from '@deepseek-ai/schemastery'
import { isInside, safeRelativePath } from './path-utils.js'
import { normalizeValuePolicy } from './value-policy.js'


export const DEFAULT_CANDIDATE_EXTENSIONS = Object.freeze([
  'tmp', 'temp', 'bak', 'orig', 'rej', 'swp', 'swo',
  'log', 'out', 'trace', 'prof', 'profile', 'pid', 'core', 'dump',
  'pyc', 'pyo', 'npz', 'npy', 'pt', 'pth', 'ckpt',
])

export const DEFAULT_CANDIDATE_DIRECTORIES = Object.freeze([
  'tmp', 'temp', 'scratch', 'debug', 'diag', 'diagnostic', 'logs',
  'output', 'outputs', 'artifact', 'artifacts', 'rollout', 'rollouts',
  'checkpoint', 'checkpoints', 'profile', 'profiling', 'experiment',
  'experiments', 'result', 'results', 'dump', 'dumps',
])

// An empty managed-root list means "the workspace, subject to the protected
// path rules below".  This keeps the first-run experience useful for projects
// whose temporary directories have different names, while users that share a
// repository can opt into a much narrower allow-list in cordis.patch.yml.
export const DEFAULT_MANAGED_ROOTS = Object.freeze([])

export const DEFAULT_PROTECTED_DIRECTORIES = Object.freeze([
  '.git', '.hg', '.svn', '.dsh', '.agents', 'node_modules',
  '.venv', 'venv', '__pycache__', '.cache', '.npm', '.pnpm-store',
  'dist', 'build', 'lib', 'include', 'src', 'test', 'tests', 'docs',
])

export const DEFAULT_PROTECTED_NAMES = Object.freeze([
  'readme', 'readme.md', 'readme.zh.md', 'license', 'license.md',
  'agents.md', 'package.json', 'package-lock.json', 'pnpm-lock.yaml',
  'yarn.lock', 'bun.lock', 'bun.lockb', 'deno.lock', 'npm-shrinkwrap.json',
  'uv.lock', 'poetry.lock', 'pipfile.lock', 'conda-lock.yml',
  'pyproject.toml', 'cargo.toml', 'cargo.lock', 'go.mod', 'go.sum',
  'go.work.sum', 'gemfile.lock', 'composer.lock', 'podfile.lock',
  'cartfile.resolved', 'mix.lock', 'pubspec.lock', 'package.resolved',
  'packages.lock.json', 'project.assets.json', 'gradle.lockfile',
  'flake.lock', 'terraform.lock.hcl', 'stack.yaml.lock', 'makefile',
  'dockerfile',
  '.env', '.env.local', '.env.production', '.gitignore', '.hygieneignore',
  '.npmrc', '.pypirc', '.netrc', 'credentials', 'credentials.json',
  'secrets.json', 'id_rsa', 'id_ed25519', 'id_ecdsa', 'authorized_keys',
])

// These formats are commonly used for private keys, certificates, or bundled
// credentials. They remain protected even when an operator supplies a custom
// `protectedNames` list; a mistaken override must not turn key material into
// an archive candidate.
export const DEFAULT_PROTECTED_EXTENSIONS = Object.freeze([
  'pem', 'key', 'crt', 'cer', 'der', 'p12', 'pfx', 'jks', 'keystore',
])

// Filename-based credential signals are deliberately conservative and
// hard-coded: custom policy lists may add protections, but cannot accidentally
// make an obvious secret-looking name eligible for quarantine.
const SENSITIVE_NAME_RE = /(?:^|[._-])(?:credential|credentials|secret|secrets|password|passwd|passphrase|api[-_]?key|private[-_]?key|access[-_]?token|auth[-_]?token|id_(?:rsa|ed25519|ecdsa)|authorized[-_]?keys)(?:[._-]|$)/i
const SENSITIVE_EXTENSION_RE = /\.(?:pem|key|crt|cer|der|p12|pfx|jks|keystore)(?:$|[._-])/i

/** Return true for a built-in or operator-configured sensitive filename. */
export function isProtectedArtifactName(name, config = {}) {
  const lower = String(name).toLowerCase()
  const configuredNames = Array.isArray(config.protectedNames)
    ? config.protectedNames.map(value => String(value).toLowerCase())
    : []
  if (DEFAULT_PROTECTED_NAMES.includes(lower) || configuredNames.includes(lower)) return true
  if (lower.startsWith('.env')) return true
  const extension = extname(lower).replace(/^\./, '')
  const configuredExtensions = Array.isArray(config.protectedExtensions)
    ? config.protectedExtensions.map(value => String(value).toLowerCase().replace(/^\./, ''))
    : []
  if (DEFAULT_PROTECTED_EXTENSIONS.includes(extension)
    || configuredExtensions.includes(extension)
    || SENSITIVE_EXTENSION_RE.test(lower)) return true
  return SENSITIVE_NAME_RE.test(lower)
}

/**
 * Schemastery configuration surface used by DSH's Loader.
 *
 * Arrays intentionally remain optional here: resolveConfig() supplies the
 * immutable defaults and normalizes user-provided values for the standalone
 * entry point as well.
 */
export const Config = z.object({
  enabled: z.boolean().default(true),
  // Empty means use the agent/session cwd (or process.cwd() for the CLI).
  workspaceRoot: z.string().default(''),
  stateDir: z.string().default('.dsh-hygiene'),
  // workspace-artifacts is a metadata catalog. It never contains source
  // artifact bytes; only one JSON description per cataloged path is stored.
  catalogRoot: z.string().default('workspace-artifacts'),
  catalogEnabled: z.boolean().default(true),
  // Empty means <workspace>/.dsh-hygiene/archive.
  archiveRoot: z.string().default(''),
  autoScan: z.boolean().default(true),
  mode: z.union(['manual', 'automatic']).default('manual'),
  cleanlinessThreshold: z.number().min(0).max(100).default(80),
  monitorIntervalMs: z.natural().min(1000).default(30000),
  verificationCommands: z.any().default([]),
  verificationTimeoutMs: z.natural().min(1000).default(120000),
  reviewerTimeoutMs: z.natural().min(1000).default(180000),
  reviewerCli: z.string().default(''),
  contextAware: z.boolean().default(true),
  contextMaxChars: z.natural().min(1000).default(40000),
  contextBatchSize: z.natural().min(1).max(100).default(60),
  contextModelTimeoutMs: z.natural().min(1000).default(120000),
  privateStorageRoot: z.string().default(''),
  maxVerificationFiles: z.natural().min(1).default(10000),
  maxReferenceBytes: z.natural().min(1024).default(134217728),
  autoArchive: z.boolean().default(false),
  // When enabled, idle maintenance may apply eligible catalog decisions
  // without waiting for a per-run user confirmation. Hard protection rules,
  // budgets, and the value-policy delete gate still apply.
  autonomousMode: z.boolean().default(false),
  autoScanEveryTurns: z.natural().min(1).default(3),
  debounceMs: z.natural().default(1500),
  planTtlMs: z.natural().min(1_000).max(7 * 24 * 60 * 60 * 1000).default(15 * 60 * 1000),
  minAgeHours: z.number().min(0).default(24),
  maxScanFiles: z.natural().min(1).default(5000),
  maxArchiveFiles: z.natural().min(1).default(20),
  maxArchiveBytes: z.natural().min(1).default(100 * 1024 * 1024),
  resultLimit: z.natural().min(1).max(100).default(25),
  allowPathOverride: z.boolean().default(false),
  allowHiddenCandidates: z.boolean().default(false),
  notifyAgent: z.boolean().default(false),
  writeReports: z.boolean().default(true),
  managedRoots: z.array(z.string()).default([...DEFAULT_MANAGED_ROOTS]),
  candidateExtensions: z.array(z.string()).default([...DEFAULT_CANDIDATE_EXTENSIONS]),
  candidateDirectories: z.array(z.string()).default([...DEFAULT_CANDIDATE_DIRECTORIES]),
  protectedDirectories: z.array(z.string()).default([...DEFAULT_PROTECTED_DIRECTORIES]),
  protectedNames: z.array(z.string()).default([...DEFAULT_PROTECTED_NAMES]),
  protectedExtensions: z.array(z.string()).default([...DEFAULT_PROTECTED_EXTENSIONS]),
  // Value policy is intentionally open-ended at the schema boundary. The
  // normalizer below supplies a small stable shape while allowing future
  // research policies to add signals without requiring a bundle rebuild.
  valuePolicy: z.any().default({}),
  // Friendly top-level alias for profiles that want to enable permanent
  // deletion without nesting one boolean. It is folded into valuePolicy.
  allowDelete: z.boolean().default(false),
})

function optionalString(value) {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : undefined
}

function finiteNumber(value, fallback, { min = 0, integer = false } = {}) {
  if (value === undefined || value === null || value === '') return fallback
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min) {
    throw new Error(`expected a finite number >= ${min}, got ${JSON.stringify(value)}`)
  }
  if (integer && !Number.isInteger(value)) {
    throw new Error(`expected an integer, got ${JSON.stringify(value)}`)
  }
  return value
}

function booleanOr(value, fallback) {
  return typeof value === 'boolean' ? value : fallback
}

function normalizeList(value, fallback) {
  if (!Array.isArray(value)) return [...fallback]
  const result = value
    .filter(item => typeof item === 'string' && item.trim() !== '')
    .map(item => item.trim())
  return result.length > 0 ? [...new Set(result)] : [...fallback]
}

function expandHome(value) {
  if (value === '~') return homedir()
  if (value.startsWith('~/') || value.startsWith('~\\')) return join(homedir(), value.slice(2))
  return value
}

function normalizeArchiveRoot(value) {
  const text = optionalString(value)
  if (text === undefined) return undefined
  const expanded = expandHome(text)
  if (isAbsolute(expanded)) return resolve(expanded)
  // Relative archive paths are intentionally constrained to the workspace.
  // An operator can still choose an external location with an absolute path
  // or `~`, but a `..` segment must never silently broaden the archive scope.
  try {
    return safeRelativePath(expanded)
  } catch {
    throw new Error(`archiveRoot must be an absolute path, ~ path, or safe workspace-relative path: ${value}`)
  }
}

export function resolveUserPath(value, base = process.cwd()) {
  const text = optionalString(value)
  if (text === undefined) return resolve(base)
  const expanded = expandHome(text)
  return isAbsolute(expanded) ? resolve(expanded) : resolve(base, expanded)
}

function normalizeStateDir(value) {
  const text = optionalString(value) ?? '.dsh-hygiene'
  if (isAbsolute(text) || text.split(/[\\/]/).some(part => part === '..')) {
    throw new Error(`stateDir must be a relative path without '..': ${text}`)
  }
  const normalized = text.replace(/[\\/]+/g, '/').replace(/^\.\//, '').replace(/\/$/, '')
  if (normalized === '.') {
    throw new Error('stateDir cannot be the workspace root; choose a child directory')
  }
  return normalized || '.dsh-hygiene'
}

function normalizeCatalogRoot(value) {
  const text = optionalString(value) ?? 'workspace-artifacts'
  if (isAbsolute(text) || text.startsWith('~')) {
    throw new Error(`catalogRoot must be a workspace-relative path: ${text}`)
  }
  try {
    return safeRelativePath(text)
  } catch {
    throw new Error(`catalogRoot must be a safe workspace-relative path: ${text}`)
  }
}

function normalizeExtensions(value, fallback = DEFAULT_CANDIDATE_EXTENSIONS) {
  return normalizeList(value, fallback)
    .map(item => item.toLowerCase().replace(/^\./, ''))
}

function normalizeNames(value, fallback) {
  return normalizeList(value, fallback).map(item => item.toLowerCase())
}

/**
 * Fill defaults and validate the bounded policy.
 * @param {object|null|undefined} input raw Loader or CLI configuration.
 * @returns {object} a fully resolved immutable-ish configuration object.
 */
export function resolveConfig(input = {}) {
  const raw = input && typeof input === 'object' && !Array.isArray(input) ? input : {}
  const stateDir = normalizeStateDir(raw.stateDir)
  const rawCatalog = raw.catalog && typeof raw.catalog === 'object' && !Array.isArray(raw.catalog)
    ? raw.catalog
    : undefined
  const rawValuePolicy = raw.valuePolicy && typeof raw.valuePolicy === 'object' && !Array.isArray(raw.valuePolicy)
    ? raw.valuePolicy
    : undefined
  const rawOrganization = rawValuePolicy?.organization
    && typeof rawValuePolicy.organization === 'object'
    && !Array.isArray(rawValuePolicy.organization)
    ? rawValuePolicy.organization
    : undefined
  const topCatalogRoot = optionalString(raw.catalogRoot)
    ?? optionalString(raw.workspaceArtifactsRoot)
  const nestedCatalogRoot = optionalString(rawCatalog?.root)
    ?? optionalString(rawOrganization?.root)
  const catalogRoot = normalizeCatalogRoot(
    nestedCatalogRoot && (!topCatalogRoot || topCatalogRoot === 'workspace-artifacts')
      ? nestedCatalogRoot
      : topCatalogRoot ?? nestedCatalogRoot,
  )
  const workspaceRoot = optionalString(raw.workspaceRoot)
  const archiveRoot = optionalString(raw.archiveRoot)
  const workspaceBase = workspaceRoot === undefined
    ? process.cwd()
    : resolveUserPath(workspaceRoot)

  // Keep relative archive paths relative until archiveRootFor() receives the
  // canonical workspace. This matters for a plugin shared by agents whose
  // session cwd differs from the Harness process cwd. normalizeArchiveRoot()
  // rejects traversal, while absolute and `~` paths remain explicit external
  // locations subject to assertArchiveRoot() overlap checks.
  const normalizedArchiveRoot = normalizeArchiveRoot(archiveRoot)

  const nestedValuePolicy = raw.valuePolicy && typeof raw.valuePolicy === 'object'
    && !Array.isArray(raw.valuePolicy)
    ? raw.valuePolicy
    : undefined
  // Keep the catalog namespace consistent across the top-level shorthand and
  // the value-policy organization object.  Without this bridge,
  // `catalogRoot: "my-index"` would write metadata under `my-index` while
  // value suggestions still advertise `workspace-artifacts/...`.
  const valuePolicyInput = {
    ...(nestedValuePolicy ?? raw),
    allowDelete: nestedValuePolicy?.allowDelete ?? raw.allowDelete,
  }
  // `catalog.root`, `catalogRoot`, and `valuePolicy.organization.root` are
  // aliases for one namespace. Whichever value resolveConfig selected must be
  // reflected in the normalized organization policy as well; otherwise the
  // catalog would be written under one directory while suggestions advertise
  // another (notably when only `{ catalog: { root: "my-index" } }` is set).
  if (catalogRoot) {
    valuePolicyInput.organization = {
      ...(nestedValuePolicy?.organization && typeof nestedValuePolicy.organization === 'object'
        ? nestedValuePolicy.organization
        : {}),
      root: catalogRoot,
    }
  }
  const valuePolicy = normalizeValuePolicy(valuePolicyInput)

  const resolved = {
    enabled: booleanOr(raw.enabled, true),
    workspaceRoot: workspaceRoot === undefined ? undefined : workspaceBase,
    stateDir,
    catalogRoot,
    catalogEnabled: booleanOr(raw.catalogEnabled ?? rawCatalog?.enabled, true),
    // Relative archive paths are intentionally resolved later by
    // archiveRootFor(workspaceRoot, config). Absolute paths and `~` are
    // expanded here so their meaning is stable across workspace calls.
    archiveRoot: normalizedArchiveRoot,
    autoScan: booleanOr(raw.autoScan, true),
    mode: raw.mode ?? ((raw.autonomousMode || raw.autoArchive) ? 'automatic' : 'manual'),
    cleanlinessThreshold: finiteNumber(raw.cleanlinessThreshold, 80),
    monitorIntervalMs: finiteNumber(raw.monitorIntervalMs, 30000, { min: 1000, integer: true }),
    verificationCommands: raw.verificationCommands ?? [],
    verificationTimeoutMs: finiteNumber(raw.verificationTimeoutMs, 120000, { min: 1000, integer: true }),
    reviewerTimeoutMs: finiteNumber(raw.reviewerTimeoutMs, 180000, { min: 1000, integer: true }),
    reviewerCli: optionalString(raw.reviewerCli),
    contextAware: booleanOr(raw.contextAware, true),
    contextMaxChars: finiteNumber(raw.contextMaxChars, 40000, { min: 1000, integer: true }),
    contextBatchSize: finiteNumber(raw.contextBatchSize, 60, { min: 1, integer: true }),
    contextModelTimeoutMs: finiteNumber(raw.contextModelTimeoutMs, 120000, { min: 1000, integer: true }),
    privateStorageRoot: optionalString(raw.privateStorageRoot),
    maxVerificationFiles: finiteNumber(raw.maxVerificationFiles, 10000, { min: 1, integer: true }),
    maxReferenceBytes: finiteNumber(raw.maxReferenceBytes, 134217728, { min: 1024, integer: true }),
    autoArchive: booleanOr(raw.autoArchive, false),
    autonomousMode: booleanOr(raw.autonomousMode ?? raw.autonomous ?? raw.fullAutonomy, false),
    autoScanEveryTurns: finiteNumber(raw.autoScanEveryTurns, 3, { min: 1, integer: true }),
    debounceMs: finiteNumber(raw.debounceMs, 1500, { min: 0, integer: true }),
    planTtlMs: finiteNumber(raw.planTtlMs, 15 * 60 * 1000, { min: 1_000, integer: true }),
    minAgeHours: finiteNumber(raw.minAgeHours, 24, { min: 0 }),
    maxScanFiles: finiteNumber(raw.maxScanFiles, 5000, { min: 1, integer: true }),
    maxArchiveFiles: finiteNumber(raw.maxArchiveFiles, 20, { min: 1, integer: true }),
    maxArchiveBytes: finiteNumber(raw.maxArchiveBytes, 100 * 1024 * 1024, { min: 1, integer: true }),
    resultLimit: finiteNumber(raw.resultLimit, 25, { min: 1, integer: true }),
    allowPathOverride: booleanOr(raw.allowPathOverride, false),
    allowHiddenCandidates: booleanOr(raw.allowHiddenCandidates, false),
    notifyAgent: booleanOr(raw.notifyAgent, false),
    writeReports: booleanOr(raw.writeReports, true),
    managedRoots: normalizeManagedRoots(raw.managedRoots),
    candidateExtensions: normalizeExtensions(raw.candidateExtensions),
    candidateDirectories: normalizeNames(raw.candidateDirectories, DEFAULT_CANDIDATE_DIRECTORIES),
    protectedDirectories: normalizeNames(raw.protectedDirectories, DEFAULT_PROTECTED_DIRECTORIES),
    protectedNames: normalizeNames(raw.protectedNames, DEFAULT_PROTECTED_NAMES),
    protectedExtensions: normalizeExtensions(raw.protectedExtensions, DEFAULT_PROTECTED_EXTENSIONS),
    valuePolicy,
    allowDelete: valuePolicy.allowDelete,
  }

  if (!['manual', 'automatic'].includes(resolved.mode)) throw new Error('mode must be manual or automatic')
  if (resolved.contextBatchSize > 100) throw new Error('contextBatchSize must be <= 100')
  if (resolved.cleanlinessThreshold > 100) throw new Error('cleanlinessThreshold must be <= 100')
  if (!Array.isArray(resolved.verificationCommands) || resolved.verificationCommands.some(command => (
    !command || typeof command.command !== 'string' || !command.command.trim()
    || !Array.isArray(command.args) || command.args.some(arg => typeof arg !== 'string')
  ))) throw new Error('verificationCommands must contain { command, args: string[] } records')

  // The catalog is metadata-only. Keep its namespace disjoint from the
  // state and archive roots so a quarantine destination can never place
  // source bytes under `workspace-artifacts/` (or make state files appear as
  // catalog entries). This check belongs at configuration resolution so all
  // entry points—scan, plan, CLI, and idle maintenance—fail closed before a
  // source mutation can be attempted.
  const catalogAbsolute = resolve(workspaceBase, catalogRoot)
  const stateAbsolute = resolve(workspaceBase, stateDir)
  const archiveAbsolute = normalizedArchiveRoot === undefined
    ? resolve(stateAbsolute, 'archive')
    : resolveUserPath(normalizedArchiveRoot, workspaceBase)
  const overlaps = (left, right) => isInside(left, right) || isInside(right, left)
  if (overlaps(catalogAbsolute, stateAbsolute)) {
    throw new Error(`catalogRoot cannot overlap stateDir: ${catalogRoot}`)
  }
  if (overlaps(catalogAbsolute, archiveAbsolute)) {
    throw new Error(`catalogRoot cannot overlap archiveRoot: ${catalogRoot}`)
  }

  // The organization namespace is a destination, not an input root. Keeping
  // it disjoint from managed roots prevents an organize run from moving a
  // file into a directory that the next scan would treat as fresh input.
  const organizationRoot = valuePolicy.organization?.root
  const catalogRoots = [...new Set([organizationRoot, resolved.catalogRoot].filter(Boolean))]
  for (const catalogRoot of catalogRoots) {
    if (resolved.managedRoots.some(root => (
      root === catalogRoot
      || root.startsWith(`${catalogRoot}/`)
      || catalogRoot.startsWith(`${root}/`)
    ))) {
      const label = catalogRoot === organizationRoot ? 'organization.root' : 'catalogRoot'
      throw new Error(`${label} must not overlap managedRoots: ${catalogRoot}`)
    }
  }

  return Object.freeze(resolved)
}

function normalizeManagedRoots(value) {
  if (value === undefined || value === null) return [...DEFAULT_MANAGED_ROOTS]
  if (!Array.isArray(value)) throw new Error('managedRoots must be an array of workspace-relative paths')
  const result = []
  for (const item of value) {
    if (typeof item !== 'string') {
      throw new Error(`managedRoots entries must be strings, got ${JSON.stringify(item)}`)
    }
    const text = item.trim().replace(/\\/g, '/').replace(/\/+$/, '')
    // `.` is an explicit spelling of the default whole-workspace scope.
    if (text === '') continue
    if (text === '.') continue
    try {
      result.push(safeRelativePath(text))
    } catch {
      // Silently dropping an invalid root would broaden an intended narrow
      // policy back to the whole workspace. Fail closed instead.
      throw new Error(`managedRoots entry must be a safe workspace-relative path: ${item}`)
    }
  }
  return [...new Set(result)]
}

/** Resolve the state directory for one canonical workspace. */
export function stateRootFor(workspaceRoot, config) {
  const stateDir = normalizeStateDir(config?.stateDir)
  return resolve(workspaceRoot, stateDir)
}

/** Resolve the archive root; relative values stay inside the workspace. */
export function archiveRootFor(workspaceRoot, config) {
  // Re-validate here as well as in resolveConfig(). This helper is exported
  // and is used by a few lightweight consumers that pass a raw config object
  // directly; without the second boundary, `archiveRootFor(root, { archiveRoot:
  // '../outside' })` could still resolve outside the workspace.
  const archiveRoot = normalizeArchiveRoot(config?.archiveRoot)
  return archiveRoot === undefined
    ? resolve(stateRootFor(workspaceRoot, config), 'archive')
    : resolveUserPath(archiveRoot, workspaceRoot)
}
