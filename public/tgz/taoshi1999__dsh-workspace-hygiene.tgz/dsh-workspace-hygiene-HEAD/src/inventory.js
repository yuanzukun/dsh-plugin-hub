/** Full, lazy workspace browsing. Display scope is separate from mutation scope. */
import { lstat, realpath, readdir } from 'node:fs/promises'
import { basename, extname, join } from 'node:path'
import { isInside, safeRelativePath } from './path-utils.js'
import { isProtectedRelativePath } from './policy.js'
import { classifyValue } from './value-policy.js'
import { SOURCE_EXTENSIONS } from './scan.js'

export async function safePath(root, relativePath = '', { missing = false } = {}) {
  root = await realpath(root)
  const rel = relativePath === '' ? '' : safeRelativePath(relativePath)
  let current = root
  for (const part of rel.split('/').filter(Boolean)) {
    current = join(current, part)
    try {
      const info = await lstat(current)
      if (info.isSymbolicLink()) throw new Error('Symbolic links are displayed but never followed')
      if (!isInside(root, await realpath(current))) throw new Error('Path escapes workspace')
    } catch (error) {
      if (!(missing && error.code === 'ENOENT')) throw error
    }
  }
  return current
}

export function purposeFor(path, type = 'file') {
  if (type === 'directory') return '目录 / Directory'
  if (type === 'symlink') return '符号链接（不跟随） / Symbolic link'
  const name = basename(path).toLowerCase()
  const ext = extname(name).slice(1)
  if (/^readme|\.md$|\.rst$/.test(name)) return '说明文档 / Documentation'
  if (/test|spec/.test(path) && SOURCE_EXTENSIONS.has(ext)) return '测试与校验 / Tests'
  if (/lock$|lock\.|package\.json|config|\.ya?ml$|\.toml$/.test(name)) return '配置或依赖清单 / Configuration'
  if (SOURCE_EXTENSIONS.has(ext)) return '项目源文件 / Source code'
  if (/log|trace/.test(ext)) return '运行日志 / Execution log'
  if (/png|jpe?g|svg|webp|gif/.test(ext)) return '图片资源 / Image asset'
  if (/csv|tsv|json|parquet|npy/.test(ext)) return '结构化数据 / Structured data'
  if (/tmp|temp|bak|orig|rej/.test(ext)) return '临时或备份文件 / Temporary artifact'
  return '工作区文件，用途待确认 / Purpose needs review'
}

export function describeEntry(path, info, config, catalog = new Map(), annotations = new Map()) {
  const type = info.isSymbolicLink() ? 'symlink' : info.isDirectory() ? 'directory' : info.isFile() ? 'file' : 'other'
  const protectedPath = type !== 'file' || isProtectedRelativePath(path, config)
  const hint = catalog.get(path)
  let contextual = annotations.get(path)
  const parts = path.split('/')
  if (parts.slice(0, -1).some((_, index) => annotations.get(parts.slice(0, index + 1).join('/'))?.preserve)) contextual = { ...contextual, category: protectedPath && type !== 'directory' ? 'protected' : 'valuable', reason: '所在目录的整理策略要求保留。' }
  const value = hint ?? classifyValue({ relativePath: path, name: basename(path), size: info.size,
    protected: protectedPath, sourceExtension: SOURCE_EXTENSIONS.has(extname(path).slice(1)),
  }, config.valuePolicy)
  return { path, name: basename(path), type, size: info.size, mtimeMs: info.mtimeMs,
    category: protectedPath ? 'protected' : contextual?.category ?? value.valueClass,
    action: protectedPath ? 'retain' : value.action ?? value.recommendation,
    purpose: contextual?.purpose ?? purposeFor(path, type), assessment: contextual?.reason ?? hint?.purpose ?? value.reasons?.join(', ') ?? '',
    classificationSource: contextual ? 'task-context' : 'rules', contextCategory: contextual?.category ?? null,
    protected: protectedPath || value.valueClass === 'protected',
    suggestedPath: hint?.organization?.suggestedSourcePath ?? null }
}

export async function listDirectory(root, config, { path = '', offset = 0, limit = 200 } = {}, catalog = new Map(), annotations = new Map()) {
  if (typeof path !== 'string' || !Number.isSafeInteger(offset) || offset < 0) throw new Error('Invalid directory request')
  const directory = await safePath(root, path)
  const entries = await readdir(directory, { withFileTypes: true })
  entries.sort((a, b) => Number(b.isDirectory()) - Number(a.isDirectory()) || a.name.localeCompare(b.name, 'en'))
  const page = entries.slice(offset, offset + Math.min(500, Math.max(1, Number(limit) || 200)))
  const rows = []
  for (const entry of page) {
    const relativePath = path ? `${path}/${entry.name}` : entry.name
    try { rows.push(describeEntry(relativePath, await lstat(join(directory, entry.name)), config, catalog, annotations)) }
    catch (error) { rows.push({ path: relativePath, name: entry.name, type: 'unavailable', category: 'protected', purpose: error.code ?? 'Unavailable', protected: true }) }
  }
  // Recheck the directory before returning metadata from a raced traversal.
  await safePath(root, path)
  return { path, entries: rows, total: entries.length, nextOffset: offset + page.length < entries.length ? offset + page.length : null }
}

/** Explainable score of the assessed artifact surface, not source-code quality. */
export function cleanliness(scan) {
  const entries = (scan.catalogEntries ?? []).filter(entry => entry.valueClass !== 'protected')
  const counts = { disposable: 0, intermediate: 0, uncertain: 0, valuable: 0 }
  for (const entry of entries) counts[entry.valueClass] = (counts[entry.valueClass] ?? 0) + 1
  const denominator = Math.max(1, entries.length)
  const residue = 70 * counts.disposable / denominator
  const intermediates = 20 * counts.intermediate / denominator
  const uncertain = 10 * counts.uncertain / denominator
  return { score: Math.max(0, Math.min(100, Math.round(100 - residue - intermediates - uncertain))),
    assessedFiles: entries.length, counts, penalties: { residue, intermediates, uncertain },
    complete: !scan.truncated, excludedPrefixes: scan.catalogCoverage?.excludedPrefixes ?? [],
    formula: '100 − 70 × disposable/N − 20 × intermediate/N − 10 × uncertain/N (N = assessed, non-protected files)' }
}
