import { fork } from 'node:child_process'
import { randomUUID } from 'node:crypto'
export class WorkerClient {
  constructor(root, config, services = {}) {
    this.pending = new Map()
    this.latest = null
    this.closed = false
    this.serviceCalls = new Map()
    this.child = fork(new URL('./worker.js', import.meta.url), [], { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe', 'ipc'], execArgv: [], serialization: 'json' })
    this.child.stderr.on('data', () => {})
    this.child.on('message', message => {
      if (message.event === 'service') {
        const controller = new AbortController()
        const timer = setTimeout(() => controller.abort(), config.contextModelTimeoutMs ?? 120000)
        this.serviceCalls.set(message.id, controller)
        Promise.resolve().then(() => {
          if (!services[message.method]) {
            if (message.method === 'context') return { sources: [], digest: 'empty', truncated: false }
            throw new Error('整理模型服务不可用。')
          }
          return services[message.method](message.input, controller.signal)
        }).then(value => { if (!this.closed) this.child.send({ serviceReply: message.id, value }) })
          .catch(() => { if (!this.closed) this.child.send({ serviceReply: message.id, error: '整理模型或上下文服务不可用，请检查当前 DSH 模型配置。' }) })
          .finally(() => { clearTimeout(timer); this.serviceCalls.delete(message.id) })
        return
      }
      if (message.event === 'snapshot') { this.latest = message.value; return }
      if (message.event === 'error') { if (this.latest) this.latest.error = message.message; return }
      const pending = this.pending.get(message.id)
      if (!pending) return
      this.pending.delete(message.id)
      message.error ? pending.reject(new Error(message.error)) : pending.resolve(message.value)
    })
    const fail = error => {
      this.closed = true
      for (const controller of this.serviceCalls.values()) controller.abort()
      if (this.latest) { this.latest.phase = 'worker-stopped'; this.latest.error = error.message }
      for (const pending of this.pending.values()) pending.reject(error)
      this.pending.clear()
    }
    this.child.on('error', fail)
    this.child.on('exit', () => fail(new Error('Independent maintenance process stopped')))
    this.ready = this.request('init', undefined, { root, config })
  }
  request(method, args, extra = {}) {
    if (this.closed) return Promise.reject(new Error('Maintenance worker is unavailable'))
    const id = randomUUID()
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject })
      this.child.send({ id, method, args, ...extra }, error => { if (error) { this.pending.delete(id); reject(error) } })
    })
  }
  cancel() { if (!this.closed) this.child.send({ method: 'cancel' }); for (const controller of this.serviceCalls.values()) controller.abort() }
  async dispose() {
    if (this.closed) return
    for (const controller of this.serviceCalls.values()) controller.abort()
    this.child.send({ method: 'dispose' })
    await new Promise(resolve => {
      const timer = setTimeout(() => { this.child.kill(); resolve() }, 10000)
      this.child.once('exit', () => { clearTimeout(timer); resolve() })
    })
  }
}
