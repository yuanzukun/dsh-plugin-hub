/** Deterministic, credential-free model fixture. Loaded only by dev-web with --fixture-model. */
export const inject = ['llm']
export function apply(ctx) {
  ctx.on('llm/stream', options => (async function* () {
    let text = '这是隔离测试模型的回复。实验日志保留供分析，失败补丁可以清理。'
    let data
    try { data = JSON.parse(options.messages.at(-1).content.filter(block => block.type === 'text').map(block => block.text).join('')) } catch {}
    if (data?.entries && data.privateTranscript) text = JSON.stringify({ preservePaths: data.entries.filter(entry => entry.path === 'tmp/debug-run.log').map(entry => entry.path) })
    else if (data?.entries) text = JSON.stringify({ entries: data.entries.map(entry => ({ path: entry.path,
      category: entry.path.endsWith('.bak') ? 'disposable' : entry.protected && entry.type === 'file' ? 'protected' : 'valuable',
      purpose: entry.type === 'directory' ? '保存任务资料与实验产物' : entry.path.endsWith('.bak') ? '失败尝试的临时备份' : '当前实验的参考材料', reason: '依据测试任务上下文推断' })) })
    else if (data?.privateTranscript) text = '已记住：实验日志应保留供分析。可以在左侧目录查看用途；实际整理仍需点击整理按钮并在右侧确认方案。'
    yield { type: 'block-start', index: 0, block: { type: 'text', text: '' } }
    yield { type: 'text-delta', index: 0, text }
    yield { type: 'block-end', index: 0, block: { type: 'text', text } }
    yield { type: 'finish', reason: { kind: 'stop' }, usage: { inputTokens: 10, outputTokens: 10, totalTokens: 20 } }
  })())
}
