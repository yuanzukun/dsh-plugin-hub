/** Boot an isolated real DSH Web for integration checks; no user profile is edited. */
import { mkdtemp, mkdir, writeFile, symlink, readFile, appendFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawn } from 'node:child_process'
import { findNodeCli } from '../src/verification.js'
const cli = await findNodeCli('dsh', process.env.HYGIENE_DSH_CLI)
const scratch = await mkdtemp(join(tmpdir(), 'dsh-hygiene-web-'))
const home = join(scratch, 'home')
const workspace = join(scratch, 'workspace')
const profile = join(home, 'profiles', 'web')
await mkdir(profile, { recursive: true })
await mkdir(join(workspace, 'tmp'), { recursive: true })
await mkdir(join(workspace, 'src'), { recursive: true })
await writeFile(join(workspace, 'src', 'main.js'), 'export const answer = 42\n')
await writeFile(join(workspace, 'README.md'), '# Workspace integration fixture\n')
await writeFile(join(workspace, 'tmp', 'debug-run.log'), 'temporary output\n')
await writeFile(join(workspace, 'tmp', 'failed.patch.bak'), 'abandoned attempt\n')
await writeFile(join(profile, 'package.json'), JSON.stringify({ name: 'hygiene-ui-test-profile', private: true, dsh: { profile: { bundles: ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app'] } } }))
await mkdir(join(profile, 'node_modules'))
await symlink(join(dirname(dirname(cli)), 'node_modules', '@deepseek-ai'), join(profile, 'node_modules', '@deepseek-ai'), process.platform === 'win32' ? 'junction' : 'dir')
await symlink(fileURLToPath(new URL('..', import.meta.url)), join(profile, 'node_modules', 'dsh-workspace-hygiene'), process.platform === 'win32' ? 'junction' : 'dir')
const patch = join(scratch, 'hygiene.patch.yml')
await writeFile(join(profile, 'cordis.patch.yml'), `- insert:\n    - id: workspace-hygiene\n      name: dsh-workspace-hygiene\n      config:\n        workspaceRoot: ${JSON.stringify(workspace)}\n        privateStorageRoot: ${JSON.stringify(join(scratch, "private-conversations"))}\n        reviewerCli: ${JSON.stringify(cli)}\n        minAgeHours: 0\n        monitorIntervalMs: 2000\n        managedRoots: [tmp]\n        valuePolicy:\n          discardPatterns: ['tmp/**']\n`)
await writeFile(patch, '[]\n')
if (process.argv.includes('--fixture-model')) {
  const fixturePackage = join(profile, 'node_modules', 'hygiene-fixture-model')
  await mkdir(fixturePackage)
  await writeFile(join(fixturePackage, 'package.json'), JSON.stringify({ name: 'hygiene-fixture-model', type: 'module', main: 'index.js' }))
  await writeFile(join(fixturePackage, 'index.js'), await readFile(new URL('./dev-model.mjs', import.meta.url)))
  await appendFile(join(profile, 'cordis.patch.yml'), '- insert:\n    - id: hygiene-fixture-model\n      name: hygiene-fixture-model\n')
}
console.log(JSON.stringify({ scratch, workspace, home }))
const child = spawn(process.execPath, [cli, '--profile', 'web', '--patch', patch, '--port', '0', '--no-open'], { env: { ...process.env, DSH_HOME: home }, windowsHide: true, stdio: 'inherit' })
process.on('SIGINT', () => child.kill())
process.on('SIGTERM', () => child.kill())
child.on('exit', code => process.exit(code ?? 0))
