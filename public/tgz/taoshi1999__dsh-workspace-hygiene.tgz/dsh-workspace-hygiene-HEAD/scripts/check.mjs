import { readdirSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
const files = ['index.js', 'client.js', ...readdirSync('src').filter(name => name.endsWith('.js')).map(name => `src/${name}`), ...readdirSync('bin').filter(name => name.endsWith('.mjs')).map(name => `bin/${name}`)]
for (const file of files) {
  const result = spawnSync(process.execPath, ['--check', file], { stdio: 'inherit' })
  if (result.status !== 0) process.exit(result.status ?? 1)
}
const tests = readdirSync('test').filter(name => name.endsWith('.test.mjs')).map(name => `test/${name}`)
const result = spawnSync(process.execPath, ['--test', ...tests], { stdio: 'inherit' })
process.exit(result.status ?? 1)
