/* DSH closure-factory browser entry; React is supplied by the host's module table. */
window.__ModuleLoader__.load({ id: 'dsh-workspace-hygiene', factory: require => {
  const React = require('react')
  const { createElement: h, useEffect, useRef, useState, useSyncExternalStore } = React
  const labels = { protected: '受保护', valuable: '有价值', intermediate: '中间产物', disposable: '可清理', uncertain: '待确认' }
  const phases = { monitoring: '监控中', proposed: '等待确认', organizing: '正在整理与校验', 'awaiting-review': '等待主 Agent 复核', completed: '已完成双重核查', blocked: '整理已阻止', 'rolled-back': '已回滚', 'review-failed': '主 Agent 复核未通过', 'recovery-required': '需要恢复', 'worker-stopped': '维护进程已停止' }
  const css = `
    .dsh-hygiene-view-active [data-composer-seat]{display:none!important}.hygiene{box-sizing:border-box;height:100%;min-height:300px;overflow:auto;padding:20px 24px;color:var(--text-primary,#20242c);font:14px/1.5 system-ui,sans-serif;background:var(--background-primary,#fff)}
    .hygiene *{box-sizing:border-box}.hygiene button{font:inherit;cursor:pointer;border:1px solid #dce2e9;border-radius:8px;padding:7px 12px;background:var(--background-primary,#fff);color:inherit}.hygiene button:disabled{opacity:.45;cursor:default}.hygiene .primary{background:#4169e1;color:white;border-color:#4169e1}.hygiene button:focus-visible,.hygiene input:focus-visible,.hygiene textarea:focus-visible{outline:2px solid #4169e1;outline-offset:2px}
    .hygiene h2{font-size:20px;margin:0 0 4px}.hygiene small,.hygiene-muted{color:#718096}.hygiene-top{display:flex;gap:24px;align-items:center;justify-content:space-between;margin-bottom:14px}.hygiene-root{overflow-wrap:anywhere;color:#718096;font-size:12px}.hygiene-score{display:flex;align-items:center;gap:14px;flex-shrink:0}.hygiene-gauge{width:74px;height:74px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(#4169e1 calc(var(--score)*1%),#edf1f7 0);position:relative}.hygiene-gauge:before{content:'';position:absolute;inset:7px;border-radius:50%;background:var(--background-primary,#fff)}.hygiene-gauge strong{position:relative;font-size:24px}
    .hygiene-toolbar{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;border:1px solid #e5e9ef;border-radius:12px;padding:12px 14px;margin-bottom:12px}.hygiene-modes{display:flex;gap:18px}.hygiene-modes label{display:flex;align-items:center;gap:6px;cursor:pointer}.hygiene-actions,.hygiene-proposal-actions{display:flex;gap:8px;flex-wrap:wrap}.hygiene-note{margin:6px 0 12px;color:#718096;font-size:12px}.hygiene-error{padding:10px;border:1px solid #edb7b3;background:#fff1ef;color:#a12622;border-radius:8px;overflow-wrap:anywhere;margin:8px 0}.hygiene-context{padding:9px 12px;border-radius:8px;background:var(--background-secondary,#f7f9fc);font-size:12px;color:#718096;margin-bottom:12px}
    .hygiene-workarea{display:grid;grid-template-columns:minmax(0,1fr) minmax(340px,400px);gap:16px;align-items:start}.hygiene-main{min-width:0}.hygiene-tree{border:1px solid #e5e9ef;border-radius:12px;overflow:hidden}.hygiene-tree-head{display:grid;grid-template-columns:minmax(150px,1fr) 90px 175px;background:var(--background-secondary,#f7f9fc);padding:10px 14px;font-size:12px;color:#718096}.hygiene-row{display:grid;grid-template-columns:minmax(150px,1fr) 90px 175px;align-items:center;min-height:39px;padding:4px 14px;border-top:1px solid #f0f2f5;gap:4px}.hygiene-row:hover{background:#f7f9fc}.hygiene-row.selected{background:#eef3ff}.hygiene-row .hygiene-filename{border:0;padding:3px 0;background:transparent;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:flex;gap:7px;align-items:center}.hygiene-purpose{color:#718096;font-size:12px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.hygiene-badge{font-size:11px;display:inline-block;width:fit-content;padding:2px 7px;border-radius:5px;background:#edf1f7;color:#58677a}.hygiene-badge.disposable{background:#fff1e5;color:#b66c1b}.hygiene-badge.valuable{background:#e9f7f0;color:#27835c}.hygiene-badge.uncertain{background:#f4ecff;color:#8754b7}.hygiene-empty{padding:24px;color:#718096;text-align:center}
    .hygiene-file-inspector{border:1px solid #e5e9ef;border-radius:10px;padding:10px 14px;margin-bottom:10px}.hygiene-file-inspector summary{cursor:pointer;font-weight:600}.hygiene-file-inspector dl{display:grid;grid-template-columns:80px minmax(0,1fr);gap:6px;margin:10px 0 0;font-size:12px}.hygiene-file-inspector dt{color:#718096}.hygiene-file-inspector dd{margin:0;overflow-wrap:anywhere}.hygiene-footer{display:flex;gap:14px;flex-wrap:wrap;margin-top:12px;font-size:11px;color:#718096}.hygiene-report{border:1px solid #e5e9ef;border-radius:10px;padding:10px 14px;margin-top:12px}.hygiene-report pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px;max-height:220px;overflow:auto}
    .hygiene-agent{border:1px solid #e5e9ef;border-radius:12px;background:var(--background-primary,#fff);height:calc(100vh - 330px);min-height:420px;position:sticky;top:0;display:flex;flex-direction:column;overflow:hidden}.hygiene-agent-head{padding:13px 14px;border-bottom:1px solid #e5e9ef;display:flex;justify-content:space-between;gap:10px;align-items:center}.hygiene-agent-head h3{margin:0;font-size:15px}.hygiene-agent-log{flex:1;min-height:0;overflow:auto;padding:8px 12px}.hygiene-agent input,.hygiene-agent textarea{font:inherit;color:inherit;background:var(--background-primary,#fff);border:1px solid #cbd5e1;border-radius:8px;padding:9px;width:100%}.hygiene-agent textarea{min-height:72px;max-height:150px;resize:vertical}.hygiene-agent-compose,.hygiene-agent-unlock{padding:11px 12px;border-top:1px solid #e5e9ef}.hygiene-agent-unlock input{margin:7px 0}.hygiene-chat-message{padding:9px 11px;border-radius:10px;background:var(--background-secondary,#f7f9fc);margin:8px 0;white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}.hygiene-chat-message.user{border-left:3px solid #4169e1}.hygiene-chat-message.activity{border-left:3px solid #94a3b8}.hygiene-chat-message.error{border-left-color:#d9534f;background:#fff1ef}.hygiene-chat-message.success{border-left-color:#27835c}.hygiene-chat-message.warning{border-left-color:#c17b22}.hygiene-chat-message p{margin:4px 0}.hygiene-chat-meta{color:#718096;font-size:10px}.hygiene-proposal{border:1px solid #9eb5f1;background:#f5f8ff;border-radius:10px;padding:11px;margin:10px 0;font-size:12px}.hygiene-proposal h4{margin:0 0 6px}.hygiene-proposal ul{margin:7px 0;padding-left:18px;max-height:180px;overflow:auto}.hygiene-proposal-actions{margin-top:10px}
    @media(max-width:1100px){.hygiene-workarea{grid-template-columns:minmax(0,1fr) 330px}.hygiene-tree-head,.hygiene-row{grid-template-columns:minmax(140px,1fr) 82px}.hygiene-purpose{display:none}}@media(max-width:780px){.hygiene-workarea{grid-template-columns:1fr}.hygiene-agent{position:static;height:560px;min-height:0}.hygiene{padding:16px}.hygiene-top{align-items:flex-start}.hygiene-score{gap:8px}.hygiene-gauge{width:64px;height:64px}}
    @media(prefers-color-scheme:dark){.hygiene-row:hover{background:#202839}.hygiene-row.selected{background:#243452}.hygiene-error{background:#442323;color:#ffc6bd}.hygiene-proposal{background:#1d2a46}}
  `
  function makeStore(connection, sessionId) {
    let snapshot = { loading: true }, timer, disposed = false, polling = false, privateCapability = null
    const listeners = new Set()
    const emit = patch => { snapshot = { ...snapshot, ...patch }; for (const listener of listeners) listener() }
    const call = async (endpoint, payload = {}) => {
      const result = await connection.rpc.call('/workspace-hygiene', endpoint, { ...payload, sessionId })
      if (!result.ok) throw new Error(result.error?.message ?? '请求失败')
      return result.value
    }
    const poll = async () => {
      if (polling || disposed) return
      polling = true
      try { const value = await call('status'); if (!disposed) emit({ ...value, loading: false, connectionError: null }) }
      catch (error) { if (!disposed) emit({ loading: false, connectionError: error.message }) }
      finally { polling = false }
    }
    return { getSnapshot: () => snapshot,
      subscribe(listener) { listeners.add(listener); if (!timer) { void poll(); timer = setInterval(poll, 2500) }; return () => { listeners.delete(listener); if (!listeners.size) { clearInterval(timer); timer = null } } },
      async action(endpoint, args) { const value = await call(endpoint, args); if (value && Object.hasOwn(value, 'phase')) emit(value); else await poll(); return value },
      async unlockChat(password) { const { capability, ...view } = await call('chat-unlock', { password }); privateCapability = capability; await poll(); return view },
      async readChat() { const capability = privateCapability; if (!capability) return null; try { const view = await call('chat-read', { capability }); return capability === privateCapability ? view : null } catch (error) { if (capability === privateCapability) privateCapability = null; throw error } },
      sendChat(text) { return call('chat-send', { capability: privateCapability, text }) },
      async lockChat() { const capability = privateCapability; privateCapability = null; await call('chat-lock', { capability }); await poll() },
      call, dispose() { privateCapability = null; disposed = true; clearInterval(timer); listeners.clear() } }
  }
  const useHygiene = store => useSyncExternalStore(store.subscribe, store.getSnapshot, store.getSnapshot)
  function Directory({ store, path = '', depth = 0, scannedAt, selected, onSelect }) {
    const [page, setPage] = useState(null), [error, setError] = useState(''), [expanded, setExpanded] = useState({})
    useEffect(() => { let alive = true; store.call('directory', { path }).then(value => { if (alive) { setPage(value); setError(''); const updated = value.entries.find(entry => entry.path === selected?.path); if (updated) onSelect(updated) } }).catch(error => { if (alive) setError(error.message) }); return () => { alive = false } }, [store, path, scannedAt])
    const more = async () => { try { const next = await store.call('directory', { path, offset: page.nextOffset }); setPage({ ...next, entries: [...page.entries, ...next.entries] }) } catch (error) { setError(error.message) } }
    if (error) return h('div', { className: 'hygiene-error', role: 'alert' }, error)
    if (!page) return h('div', { className: 'hygiene-empty' }, '正在读取目录…')
    return h(React.Fragment, null,
      page.entries.map(entry => h(React.Fragment, { key: entry.path },
        h('div', { className: `hygiene-row ${selected?.path === entry.path ? 'selected' : ''}` },
          h('button', { className: 'hygiene-filename', style: { paddingLeft: `${depth * 16}px` }, title: entry.path,
            'aria-expanded': entry.type === 'directory' ? Boolean(expanded[entry.path]) : undefined,
            onClick: () => { onSelect(entry); if (entry.type === 'directory') setExpanded(value => ({ ...value, [entry.path]: !value[entry.path] })) } },
            h('span', { 'aria-hidden': true }, entry.type === 'directory' ? (expanded[entry.path] ? '▾ 📂' : '▸ 📁') : entry.type === 'symlink' ? '↗' : '▤'), entry.name),
          h('span', { className: `hygiene-badge ${entry.contextCategory ?? entry.category}`, title: entry.protected ? '路径受保护，不会因模型分类而移动' : undefined }, labels[entry.contextCategory ?? entry.category] ?? '待确认'),
          h('span', { className: 'hygiene-purpose', title: entry.purpose }, entry.purpose)),
        entry.type === 'directory' && expanded[entry.path] ? h(Directory, { store, path: entry.path, depth: depth + 1, scannedAt, selected, onSelect }) : null)),
      page.nextOffset !== null ? h('button', { onClick: more }, `加载更多（已显示 ${page.entries.length}/${page.total}）`) : null,
      !page.entries.length ? h('div', { className: 'hygiene-empty' }, '空目录') : null)
  }
  function timestamp(value) { try { return new Date(value).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) } catch { return '' } }
  function ProposalCard({ proposal, state, store, run }) {
    if (!proposal) return null
    const planned = proposal.kind === 'plan'
    const act = (name, args) => run(async () => { await store.action(name, args) })
    return h('section', { className: 'hygiene-proposal', 'aria-label': planned ? '整理方案等待确认' : '整理建议等待确认' },
      h('h4', null, planned ? '整理 Agent · 方案等待确认' : '整理 Agent · 建议整理'),
      h('p', null, planned ? `计划处理 ${proposal.selectedCount} 个文件。确认前不会修改工作区。` : `当前整洁度 ${proposal.score}/100，低于阈值 ${state.threshold}。`),
      planned ? h('ul', null, proposal.entries?.slice(0, 50).map(entry => h('li', { key: entry.relativePath }, `${entry.relativePath} → ${entry.action === 'archive' || entry.action === 'delete' ? '可恢复隔离区' : entry.organization?.suggestedSourcePath ?? '保留'}`))) : null,
      planned && proposal.entries?.length > 50 ? h('p', { className: 'hygiene-muted' }, `另有 ${proposal.entries.length - 50} 项，完整清单保存在方案中。`) : null,
      planned && proposal.blocked?.length ? h('p', { className: 'hygiene-muted' }, `${proposal.blocked.length} 个文件因引用或上下文要求保持原位。`) : null,
      h('div', { className: 'hygiene-proposal-actions' },
        h('button', { disabled: state.phase === 'organizing', onClick: () => act('dismiss') }, '暂不整理'),
        h('button', { className: 'primary', disabled: state.phase === 'organizing' || (planned && !proposal.selectedCount), onClick: () => act(planned ? 'execute' : 'prepare', planned ? { proposalId: proposal.id, confirm: true } : {}) }, planned ? '确认并开始整理' : '生成详细方案')))
  }
  function HygieneAgentPanel({ store, state, externalError }) {
    const [view, setView] = useState(null), [password, setPassword] = useState(''), [text, setText] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false)
    const logRef = useRef(null)
    useEffect(() => {
      let alive = true, reading = false
      const read = async () => { if (reading) return; reading = true; try { const value = await store.readChat(); if (alive) setView(value) } catch (error) { if (alive) { setView(null); setError(error.message) } } finally { reading = false } }
      void read(); const timer = setInterval(read, 1200)
      return () => { alive = false; clearInterval(timer) }
    }, [store])
    const run = async task => { setBusy(true); setError(''); try { await task() } catch (error) { setError(error.message) } finally { setBusy(false) } }
    const unlock = event => { event.preventDefault(); const secret = password; setPassword(''); void run(async () => setView(await store.unlockChat(secret))) }
    const send = event => { event.preventDefault(); const message = text.trim(); if (!message) return; void run(async () => { await store.sendChat(message); setText(''); setView(await store.readChat()) }) }
    const lock = () => { setView(null); setPassword(''); setText(''); void run(() => store.lockChat()) }
    const activities = (state.activity ?? []).map(item => ({ ...item, source: 'activity' }))
    const messages = (view?.messages ?? []).map(item => ({ ...item, source: 'message' }))
    const timeline = [...activities, ...messages].sort((a, b) => Date.parse(a.at) - Date.parse(b.at))
    useEffect(() => { const log = logRef.current; if (log) log.scrollTop = log.scrollHeight }, [timeline.length, state.proposal?.id, state.contextAssessment?.processed, state.phase])
    return h('aside', { className: 'hygiene-agent', 'aria-label': '工作区整理 Agent 对话' },
      h('header', { className: 'hygiene-agent-head' }, h('div', null, h('h3', null, '整理 Agent'), h('small', null, phases[state.phase] ?? '连接中')),
        view ? h('button', { onClick: lock, disabled: busy }, '锁定') : h('small', null, state.privateConversation?.exists ? '会话已锁定' : '尚未创建私有会话')),
      h('div', { ref: logRef, className: 'hygiene-agent-log', role: 'log', 'aria-label': '刷新、整理与会话记录', 'aria-live': 'polite' },
        h('article', { className: 'hygiene-chat-message activity' }, h('strong', null, '整理 Agent'), h('p', null, '我会在这里展示扫描、分类、整理、校验和复核过程。你也可以在下方说明整理需求。')),
        timeline.map(item => item.source === 'message'
          ? h('article', { key: `message-${item.id}`, className: `hygiene-chat-message ${item.role}` }, h('strong', null, item.role === 'user' ? '你' : '整理 Agent'), h('p', null, item.text), h('span', { className: 'hygiene-chat-meta' }, timestamp(item.at)))
          : h('article', { key: `activity-${item.id}`, className: `hygiene-chat-message activity ${item.kind}` }, h('strong', null, item.title), item.detail ? h('p', null, item.detail) : null, h('span', { className: 'hygiene-chat-meta' }, timestamp(item.at)))),
        state.contextAssessment?.status === 'analyzing' ? h('article', { className: 'hygiene-chat-message activity' }, h('strong', null, '正在评估工作区'), h('p', null, `${state.contextAssessment.processed}/${state.contextAssessment.total} 项 · 正在调用当前模型`)) : null,
        h(ProposalCard, { proposal: state.proposal, state, store, run }),
        state.result && !state.proposal ? h('article', { className: 'hygiene-chat-message activity' }, h('strong', null, `整理结果 · ${phases[state.phase] ?? state.phase}`), h('p', null, state.result.independentReview?.summary ?? state.result.primaryReview?.summary ?? '检查记录已更新。'), ['awaiting-review', 'review-failed', 'recovery-required'].includes(state.phase) && state.result.run ? h('button', { disabled: busy, onClick: () => run(() => store.action('rollback', { confirm: true })) }, '回滚本次整理') : null) : null,
        (error || externalError || state.error || state.connectionError) ? h('div', { className: 'hygiene-error', role: 'alert' }, error || externalError || state.error || state.connectionError) : null),
      view ? h('form', { className: 'hygiene-agent-compose', onSubmit: send },
        h('textarea', { 'aria-label': '发送给整理 Agent 的消息', value: text, maxLength: 8000, required: true, disabled: busy || view.busy || state.phase === 'organizing', onChange: event => setText(event.target.value), placeholder: '说明你对整理方式的建议与需求…' }),
        h('div', { className: 'hygiene-proposal-actions' }, h('small', null, view.busy ? '整理 Agent 正在回复…' : '消息只进入独立整理会话'), h('button', { type: 'submit', className: 'primary', disabled: busy || view.busy || state.phase === 'organizing' || !text.trim() }, '发送'))) :
        h('form', { className: 'hygiene-agent-unlock', onSubmit: unlock }, h('label', null, state.privateConversation?.exists ? '输入密码后继续对话' : '创建私有整理会话（至少 12 个字符）',
          h('input', { type: 'password', autoComplete: state.privateConversation?.exists ? 'current-password' : 'new-password', minLength: 12, maxLength: 1024, required: true, value: password, onChange: event => setPassword(event.target.value), placeholder: '密码不会写入普通会话' })),
          h('button', { className: 'primary', disabled: busy, type: 'submit' }, busy ? '处理中…' : state.privateConversation?.exists ? '解锁并继续' : '创建会话')))
  }
  function FileInspector({ selected }) {
    if (!selected) return null
    const fields = [['原始路径', selected.path], ['分类', labels[selected.contextCategory ?? selected.category]], ['路径保护', selected.protected ? '受保护' : '按整理策略判断'], ['用途简述', selected.purpose], ['分类来源', selected.classificationSource === 'task-context' ? '任务上下文（模型推断）' : '文件名、路径与规则'], ['评估依据', selected.assessment || '基于名称、路径及保护策略；用途属于推断。'], ['建议路径', selected.suggestedPath || '保留当前路径'], ['大小', `${selected.size ?? 0} bytes`]]
    return h('details', { className: 'hygiene-file-inspector', open: true }, h('summary', null, selected.name), h('dl', null, fields.map(([key, value]) => h(React.Fragment, { key }, h('dt', null, key), h('dd', null, value)))))
  }
  function Workspace({ hygieneStore: store }) {
    const state = useHygiene(store), [selected, setSelected] = useState(null), [error, setError] = useState(''), [busy, setBusy] = useState(false)
    useEffect(() => { document.body.classList.add('dsh-hygiene-view-active'); return () => document.body.classList.remove('dsh-hygiene-view-active') }, [])
    const action = async (name, args) => { setBusy(true); setError(''); try { await store.action(name, args) } catch (error) { setError(error.message) } finally { setBusy(false) } }
    const locked = busy || state.phase === 'organizing'
    return h('section', { className: 'hygiene', 'aria-label': '工作区整洁度' },
      h('div', { className: 'hygiene-top' }, h('div', null, h('h2', null, '工作区'), h('div', { className: 'hygiene-root' }, state.root ?? '读取当前会话工作区…'), h('small', null, phases[state.phase] ?? '连接维护进程…')),
        h('div', { className: 'hygiene-score' }, h('div', { className: 'hygiene-gauge', style: { '--score': state.score?.score ?? 0 }, 'aria-label': `整洁度 ${state.score?.score ?? '待评估'} / 100` }, h('strong', null, state.score?.score ?? '—')),
          h('div', null, h('strong', null, '整洁度 / 100'), h('br'), h('small', null, state.score?.complete === false ? '扫描未完成 · 暂估' : '文件生命周期评分')))),
      h('div', { className: 'hygiene-toolbar' }, h('div', { className: 'hygiene-modes', role: 'radiogroup', 'aria-label': '整理模式' },
        [['manual', '手动整理'], ['automatic', '自动整理']].map(([mode, label]) => h('label', { key: mode }, h('input', { type: 'radio', name: `hygiene-mode-${state.agentId}`, value: mode, checked: state.mode === mode, disabled: locked, onChange: () => action('mode', { mode }) }), label))),
        h('div', { className: 'hygiene-actions' }, h('button', { onClick: () => action('refresh'), disabled: locked }, '刷新'), h('button', { className: 'primary', onClick: () => action('prepare'), disabled: locked || state.contextAssessment?.status === 'analyzing' || state.privateConversation?.busy || ['awaiting-review', 'review-failed', 'recovery-required'].includes(state.phase) }, '整理工作区'))),
      h('p', { className: 'hygiene-note' }, state.mode === 'automatic' ? `每轮结束后评估整洁度，低于 ${state.threshold ?? 80} 分时在右侧请求确认；确认前不会移动文件。` : '独立进程持续监控；刷新、方案与整理细节显示在右侧。仅确认方案后执行。'),
      h('div', { className: 'hygiene-workarea' },
        h('main', { className: 'hygiene-main' },
          h('div', { className: 'hygiene-context', role: 'status' }, `上下文分类 · ${state.contextAssessment?.sources?.length ?? 0} 个会话 · ${state.contextAssessment?.processed ?? 0}/${state.contextAssessment?.total ?? 0} 项。`, state.contextAssessment?.status === 'analyzing' ? '正在调用当前模型评估…' : state.contextAssessment?.message ?? '等待扫描。', state.contextAssessment?.truncated ? ' 当前上下文或目录范围已截断。' : ''),
          h(FileInspector, { selected }),
          h('div', { className: 'hygiene-tree' }, h('div', { className: 'hygiene-tree-head' }, h('span', null, '目录 / 文件'), h('span', null, '分类'), h('span', null, '用途简述')),
            !state.loading && state.root ? h(Directory, { store, scannedAt: `${state.scannedAt}/${state.contextAssessment?.processed}/${state.contextAssessment?.status}`, selected, onSelect: setSelected }) : h('div', { className: 'hygiene-empty' }, state.connectionError ? '连接不可用' : '正在加载…')),
          h('div', { className: 'hygiene-footer' }, h('span', null, `独立维护进程 PID ${state.pid ?? '—'}`), h('span', null, `候选文件 ${state.candidateCount ?? 0}`), h('span', null, `最近评估 ${state.scannedAt ? new Date(state.scannedAt).toLocaleTimeString() : '—'}`)),
          h('details', { className: 'hygiene-report' }, h('summary', null, '评分依据与范围'), h('p', null, '100 − 70 × 可清理占比 − 20 × 中间产物占比 − 10 × 待确认占比'), h('p', null, state.score ? Object.entries(state.score.counts).map(([category, count]) => `${labels[category] ?? category} ${count}`).join(' · ') : '等待评估'), h('p', null, `计分文件 ${state.score?.assessedFiles ?? 0} 个。受保护文件、依赖目录及忽略目录不参与计分。`)),
          state.result ? h('details', { className: 'hygiene-report' }, h('summary', null, `完整检查记录 · ${phases[state.phase] ?? state.phase}`), h('pre', null, JSON.stringify({ changes: state.result.run?.entries, checks: state.result.checks ?? state.result.baseline, independentReview: state.result.independentReview, primaryReview: state.result.primaryReview, rollback: state.result.rollback }, null, 2))) : null),
        h(HygieneAgentPanel, { store, state, externalError: error })))
  }
  function apply(ctx) {
    const stores = new Map()
    const storeFor = id => { if (!stores.has(id)) stores.set(id, makeStore(ctx.connection, id)); return stores.get(id) }
    ctx.effect(() => { const style = document.createElement('style'); style.dataset.plugin = 'dsh-workspace-hygiene'; style.textContent = css; document.head.append(style); return () => { style.remove(); for (const store of stores.values()) store.dispose() } })
    ctx.slots.inject('conversation.view', () => ctx.slots.register({ name: 'conversation.view', id: 'workspace-hygiene', order: 20, label: '工作区', inject: sessionId => ({ hygieneStore: storeFor(sessionId) }) }, Workspace))
  }
  return { inject: ['slots', 'connection'], apply }
} })
