/** DSH host face: monitoring runs independently; only completed organization requests primary review. */
import { resolveConfig, Config } from './src/config.js'
import { HygieneController, optionalService, reviewTool, RPC_CHANNEL } from './src/controller.js'
export const name = 'dsh-workspace-hygiene'
export const inject = ['tools']
export { Config }

export function apply(ctx, rawConfig = {}) {
  const config = resolveConfig(rawConfig)
  const controller = new HygieneController(ctx, config)
  const disposers = []
  if (!config.enabled || process.env.DSH_HYGIENE_REVIEWER === '1') return { config, controller, dispose: () => controller.dispose() }
  const warn = error => { try { optionalService(ctx, 'logger')?.warn(`[${name}] ${error.message}`) } catch {} }
  const observe = (agent, ended = false) => { void controller.observe(agent, ended).catch(warn) }
  disposers.push(ctx.tools.register(reviewTool(controller)))
  const completedTurns = new WeakSet()
  disposers.push(ctx.on('agent/session-start', ({ agent }) => { controller.remember(agent); if (config.autoScan) observe(agent) }))
  // Durable turn/end also covers failed/cancelled turns, which can leave artifacts.
  disposers.push(ctx.on('session/event', (session, event) => {
    if (event.type !== 'turn/end') return
    const agent = optionalService(ctx, 'agents')?.get(session.id) ?? controller.knownAgents.get(session.id)
    if (agent) completedTurns.add(agent)
  }))
  disposers.push(ctx.on('agent/status', ({ agent, status }) => {
    controller.remember(agent)
    if (status !== 'idle') { void controller.activityStarted(agent); return }
    const ended = completedTurns.has(agent)
    completedTurns.delete(agent)
    if (ended || config.autoScan) queueMicrotask(() => observe(agent, ended))
  }))
  disposers.push(ctx.on('agent/disposed', ({ agent }) => { controller.knownAgents.delete(agent.id) }))
  let connectionFiber
  const connect = context => context.connection.rpc.handle(RPC_CHANNEL,
    (endpoint, payload) => controller.rpc(endpoint, payload), { authority: 'trusted-host' })
  if (optionalService(ctx, 'connection')) disposers.push(connect(ctx))
  else if (typeof ctx.inject === 'function') connectionFiber = ctx.inject(['connection'], connect)
  for (const agent of optionalService(ctx, 'agents')?.list() ?? []) {
    controller.remember(agent)
    if (config.autoScan) observe(agent)
  }
  let disposed = false
  const dispose = async () => {
    if (disposed) return
    disposed = true
    for (const disposer of disposers.reverse()) if (typeof disposer === 'function') await disposer()
    await connectionFiber?.dispose()
    await controller.dispose()
  }
  ctx.effect?.(() => dispose)
  return { config, controller, dispose }
}

export * from './src/config.js'
export * from './src/policy.js'
export * from './src/value-policy.js'
export * from './src/catalog.js'
export * from './src/scan.js'
export * from './src/report.js'
export * from './src/transaction.js'
export * from './src/tools.js'
