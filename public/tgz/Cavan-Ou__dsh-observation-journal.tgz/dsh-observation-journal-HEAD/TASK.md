# TASK：实现 dsh-observation-journal 插件

## 目标
按 DESIGN.md（v0.2，专家团评审整合版）实现 dsh-observation-journal 插件：纯观察者（零工具注册/零 LLM 调用），session 结束时自动把运行事实写入观测卡。

## 硬约束
1. **读 DESIGN.md 全文**——字段映射表/输出格式/架构段落是唯一规范，逐条实现，不许自创格式
2. 参考实现：`/home/administrator/.dsh/profiles/headless/node_modules/dsh-fail-logger/lib/index.js`（431 行，完整模板：ctx.on('session/event') 事件收集、callId 关联、marker 区段渲染、跨进程锁、OBS_REPLAY 式回放测试、脱敏正则）——**复用它的模式，不要重新发明**
3. bundle 形态（package.json 声明 dsh.bundle + cordis.patch.yml + lib/index.js）——参考同目录 hermes-dsh-collab 的 package.json 结构
4. 实现细节注意（实测发现）：
   - 首条 user/message 要过滤 `source.kind=='user'`（skill-catalog/agent-instructions 注入不是任务）
   - turn/end 的 reason.kind ∈ {completed, error, interrupted}，未知值原样存
   - 模型从 request/context 取（会话级）
   - todo/write 轨迹进 raw sidecar（最多 5 项）
   - 任务标题含 `|` 或换行必须转义（防打碎表格）
5. 测试：必须写回放测试（OBS_REPLAY 模式，用真实 session.jsonl 样本验证字段提取正确）——测试会话样本在 /home/administrator/.dsh/sessions/--mnt-d-WorkSpace-Projects-style-museum--/（任意 .zstd 文件，用 python zstandard 解压喂给回放）
6. **禁止 git commit**（git 唯一写者 = Hermes 主控）

## 交付
- lib/index.js（完整实现）
- package.json（bundle 声明）
- cordis.patch.yml
- 回放测试脚本/测试文件
- REPORT.md（实现决策 + 测试结果 + 遗留项）
