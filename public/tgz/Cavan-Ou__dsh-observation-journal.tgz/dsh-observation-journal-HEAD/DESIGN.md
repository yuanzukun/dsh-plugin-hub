# dsh-observation-journal 设计方案 v0.2（专家团评审后整合）

## 定位（收窄后）

**零侵入的运行事实遥测**：纯观察者插件（零工具注册、零 LLM 调用、零 agent 介入），session 结束时自动把任务/模型/工具/失败/状态/时长结构化写入人机共读的项目档案。

- 与 fail-logger 对偶：它记失败（skill 闭环），我们记完整运行事实（档案）
- 与 dsh-task-planner 边界：它记"怎么解决的"（LLM 提炼、注入回 agent）；我们记"发生了什么"（零提炼、写文件）
- 与 dsh-mneme/memento 边界：它们 agent 主动写 + 注入回 agent；我们 harness 被动写 + 人/项目读，**不注入、不检索**
- 消费闭环（MVP 内）：观测卡统计汇总区（自动生成）——机器事实 × 人工段落同文件交叉验证

## 数据源（实测确认）

| 事件 | 提取 | 实证备注 |
|---|---|---|
| `session` | sid、cwd、时间 | ✅ |
| `session/title` | 任务标题 | source.kind ∈ {provider, fallback} |
| `user/message` | 任务描述（截 200） | **必须过滤 source.kind=='user'**（skill-catalog/agent-instructions 注入不是任务）|
| `request/context` | 完整模型 id + effort | 会话级（45 会话样本：同会话多模型=0）|
| `todo/write` | 规划轨迹（最多 5 项）→ raw sidecar | 样本确认 |
| `tool/call` + `tool/result` | 工具计数 + 失败工具 top3 + 失败率 | callId 关联（fail-logger 同款）|
| `turn/end` | reason.kind ∈ {completed, error, interrupted} | 45 会话实测 {completed, error}；未知原样存 |
| `step/start`/`step/end` | 步骤数、时长（秒）| ✅ |

## 输出

**主卡**（`config.obsFile`，默认 `$DSH_HOME/observations.md`，可指项目级）——marker 区段，**一行一 session**（不合并去重）：

```markdown
<!-- OBS-JOURNAL:BEGIN -->
| time | sid | task | model | dur | turns | tools | calls | fail | status |
|---|---|---|---|---|---|---|---|---|---|
| 2026-08-15T02:35 | a8f3c | 统计页行动处方 | deepseek-v4-flash(max) | 184 | 3 | node-test:12,pytest:30 | 42 | 0 | completed |
<!-- OBS-JOURNAL:END -->
```

- `task`：title 短文本，转义 `\|` 与换行；`task_hash`（归一化去空白/标点/数字后缀，sha1 前 8）
- `tools`：`name:count` 对（按调用数降序 top5）；`fail` 纯数字（失败次数）
- **统计汇总区**（同文件，`<!-- OBS-JOURNAL:STATS -->`）：会话总数、失败率、top 工具、按模型分组的平均时长——MVP 就有的消费闭环

**raw sidecar**（`obsFile + '.jsonl'`，追加写）：完整字段（todo 轨迹/工具全量计数/失败工具/完整模型 id/任务描述全文）——v2 LLM 洞察的素材，TTL 与主卡解耦。

## 架构（fail-logger 已验证模式增量）

```
lib/index.js
├── ctx.on('session/event', handle)      # 同 telemetry 钩子
├── sessionBuffer: 当前会话事实累积（sid 键控）
├── flush(): turn/end + 300ms 防抖 → 渲染主卡行 + 追加 raw + 重写统计区
├── 渲染: <!-- OBS-JOURNAL:BEGIN/END --> 区段正则替换（人工区不动）
├── 脱敏: REDACT_DEFAULT 同款正则表（任务描述/参数）
├── 跨进程锁: 同 fail-logger（LOCK + STALE 5s）
├── 回放测试: OBS_REPLAY=<session.jsonl>（同 FAIL_LOG_REPLAY）
└── 配置: obsFile/maxRows(200)/marker/redact/flushMs——全可选
```

## MVP 边界

- ✅ 事实记录 + 统计汇总区 + raw sidecar
- ❌ v2：LLM 模式洞察、路由表自动刷新、多会话周报、观测卡↔人工段落 fuzzy-join

## 验证（交叉验证）

1. **回放验证**：真实 session.jsonl（含 Pro 长提炼样本）回放 → 字段逐项与人工核对
2. **真实验证**：headless 装插件跑真实任务 → 核对主卡行/统计区/raw 三处一致
3. **集成验证**：与既有观测卡（style-museum observations.md）双区段共存无冲突
