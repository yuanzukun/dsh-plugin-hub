# REPORT — dsh-observation-journal 实现报告

**版本**: v0.1.0 · **日期**: 2026-08-15 · **依据**: TASK.md + DESIGN.md（v0.2 专家团评审整合版）
**参考实现**: `dsh-fail-logger@0.4.3`（`~/.dsh/profiles/headless/node_modules/dsh-fail-logger/lib/index.js`，431 行模板逐模式复用）

## 1. 交付物

| 文件 | 说明 |
|---|---|
| `lib/index.js` | 完整实现（519 行），纯观察者：零工具注册、零 LLM 调用、零 agent 介入 |
| `package.json` | bundle 声明（`dsh.bundle.patch` → cordis.patch.yml，同 hermes-dsh-collab 结构） |
| `cordis.patch.yml` | profile patch：`- insert: [{id: dsh-observation-journal, name: 'dsh-observation-journal'}]` |
| `dsh.plugin.json` | 插件元数据，`contributes.tools: []`（明示零工具注册） |
| `tests/test.mjs` + `tests/fixtures/*.zstd` | 回放测试（14 用例）+ 5 个真实 session 样本（约 3.4MB） |
| `README.md` / `LICENSE` | 使用文档 / MIT |

## 2. 实现决策（对照 DESIGN 逐条）

### 2.1 数据源提取（45 会话实测集逐项实证）

| 事件 | 实现 | 实证 |
|---|---|---|
| `session` | sid（`event.id` 顶层）、cwd、createdAt | 21 样本全部顶层字段 ✅ |
| `session/title` | source.kind ∈ {provider, fallback} 都收；**provider(2) > fallback(1)** 优先级，同档后到覆盖 | 实测 21 fallback + 6 provider；3dea/5fe1 双标题，provider 更语义化（如「图片主色调分析」vs 首句截断） |
| `user/message` | **仅 `source.kind=='user'`**，取首条（其余为 skill-catalog/agent-instructions/plugin 注入） | 实测 94 条 user/message 中仅 21 条 kind=='user'；其余是 45 技能目录快照/系统注入 |
| `request/context` | 模型 id（会话级） | 21/21 样本有；多模型会话 = 0 实证 ✅ |
| `request/header` | effort 取 `header.config.reasoningEffort`（DESIGN 表格写 effort 在 request/context，实测不在——**effort 在 request/header**，以实测为准） | 12 max + 3 high；qwen3.7-plus 与部分会话无 effort → 模型格不带 `(effort)` |
| `tool/call`+`tool/result` | callId 关联（fail-logger 同款）：计数 + 失败工具计数；isError 判 `tool-result` 块（回退 `message.isError`） | 实测 288 calls / 4 失败（read_image×2、edit×1、read×1，callId 全关联成功） |
| `turn/end` | turns 计数；status = `reason.kind` ∈ {completed, error, interrupted}，**未知值原样存**；无 turn/end 的会话 → `unknown` | 实测 18 completed + 2 error（UNSUPPORTED_REASONING_EFFORT / PI_AI_ERROR）；3dea 样本中途被杀无 turn/end |
| `step/start`/`step/end` | steps 计数；dur = (最后 step/end − 首个 step/start) 秒，无 step 回退 createdAt→lastTime | 实测 dur 0~1242 秒 |

### 2.2 输出格式

- **主卡**（`obsFile` 默认 `$DSH_HOME/observations.md`）：`<!-- OBS-JOURNAL:BEGIN/END -->` 区段，表头 10 列与 DESIGN 逐字一致（time/sid/task/model/dur/turns/tools/calls/fail/status），**一行一 session 不合并去重**。
  - `task`：title 短文本，`\|` 转义 + 换行折空格（防打碎表格）；无 title 回退 desc 截 200。
  - `tools`：`name:count` 按调用数降序 top5，同数按名序（确定性）。
  - `sid`：session id 去 `session-` 前缀取前 8 位（DESIGN 示例 `a8f3c` 未定长度，8 位短 id 可读且近窗唯一）。
  - `model`：`deepseek-v4-flash(max)` 形式；effort 缺省只写模型。
- **raw sidecar**（`obsFile + '.jsonl'` 追加写，v1 schema）：time(ISO)/sid/cwd/title/taskHash/desc/模型全 id/effort/provider/turns/steps/dur/calls/fail/status/tools 全量计数/failedTools/todos。
  - `task_hash`：归一化去空白/标点/尾部数字后缀 → sha1 前 8（「统计页行动处方」「统计页行动处方 3」「统计 页!行动处方」同哈希，已测）。
  - `todos`：最后一条 todo/write 前 5 项（abe9 实测 9 项 → 5）。
  - desc 全文（安全上限 2000 字符——45 会话实测最大 383 字符，任务书都是「读 specs/… 按任务书执行」式短引用；上限仅为防病态输入，不触碰正常全文）。
- **统计汇总区**（同文件）：`<!-- OBS-JOURNAL:STATS -->` 开头（与 DESIGN 逐字一致）+ `<!-- OBS-JOURNAL:STATS:END -->` 收尾（为可替换区段加的成对闭合，人工区不动）。四行：会话总数、失败率（fail/calls，`1.4%（4/288）`）、top 工具（全量聚合 top5）、平均时长按模型分组。**统计扫描 raw sidecar 全量历史**（与主卡 maxRows TTL 解耦，不因裁剪失真）。

### 2.3 架构（fail-logger 已验证模式增量，逐项复用）

- `ctx.on('session/event', handle)` 同 telemetry 钩子 ✅
- sessionBuffer（sid 键控 Map）；`turn/end` + 300ms 防抖 → flush；**dispose 兜底落盘无 turn/end 会话**（3dea 型中途被杀样本）✅
- 区段正则替换（首次写入追加、之后原地替换、去重多余区段）——人工区一字不动 ✅
- REDACT_DEFAULT 同款 8 条脱敏正则 + config.redact 叠加（任务描述/标题）✅
- 跨进程锁 LOCK + STALE 5s，持锁重读；写失败保 dirty 重试；raw 先行防重（`rawAppended` 标记）✅
- OBS_REPLAY 回放模式（同 FAIL_LOG_REPLAY）✅
- 配置全可选：obsFile/maxRows(200)/marker/redact/flushMs；env：OBS_FILE、OBS_REPLAY ✅

### 2.4 实现中修的 bug（回放测试抓出）

1. **无 turn/end 会话不落盘**：flush 只遍历 pending（turn/end 才入列）→ 改遍历 sessions 全量（pending 仅作调度信号）。
2. **区段解析把分隔行当数据行**：`|---|` 行过滤正则要求行尾是 `-`，实为 `|` 结尾 → 修正后共存测试从 3 行回归 2 行。
3. flushMs=0 被 `|| 300` 吞掉 → 与 fail-logger 同语义（下限 300ms），测试等待对齐（不属 bug，记录）。

## 3. 测试结果

`node --test tests/test.mjs` → **14/14 全绿**（node v26，需 python3 + zstandard 解压 fixture）。

| 用例 | 验证点 |
|---|---|
| 5 × 真实样本回放（128dec23 大 Flash / 41ee error / 3dea unknown / 5fe1 Pro-high / abe9 Pro-max 长提炼） | 10 列字段 vs **人工核对锚点**（time/sid/model/dur/turns/tools/calls/fail/status 逐项硬编码）+ 测试内独立重算对照；raw sidecar 全字段 + taskHash + todos 截 5 |
| 同文件两次回放 | 两行不合并去重，统计区累计（会话总数 2、失败率 20.0%（1/5）） |
| 合成：转义/脱敏/状态 | 标题 `\|` 与换行、sk-key 与 password 脱敏、interrupted 与 `cancelled-by-hermes` 原样存 |
| 合成：首条 user 过滤 | skill-catalog 注入先于真实任务 → desc 取真实任务 |
| 合成：无 title 回退 | 卡片截 200，raw 保全文 |
| 共存 | 人工观测卡（style-museum 真实内容同构）+ 双区段追加/原地替换，人工区一字不动 |
| maxRows | 主卡裁到 2 行，raw 4 行全量，统计 4 会话 |
| task_hash | 归一化同哈希三例 |
| 自定义 marker/redact | MY-JOURNAL 区段 + 额外脱敏规则 |
| live 路径 | session/event 订阅逐事件累积 + dispose 兜底落盘 |

**集成验证（DESIGN 验证 #3 全量版）**：21 个真实样本全部回放进 style-museum 真实 observations.md 的副本 → 21 行主卡（human 区字节级一致）、raw 21 行、统计区 `会话总数 21 / 失败率 1.4%（4/288）/ top 工具 read:118,bash:83,edit:46,grep:12,job_output:8 / 按模型平均时长`，双区段共存零冲突。

## 4. 遗留项

1. **DESIGN 验证 #2（真实验证）未执行**：headless 实装插件跑真实任务。修改用户 live profile（`~/.dsh/profiles/headless`）属主控决策，留给 Hermes 主控执行：`dsh plugin --profile headless add <repo>` 后跑一真实任务核对主卡/统计/raw 三处一致。
2. **统计口径**：失败率 = 失败工具调用 / 工具调用总数（tool 级，DESIGN 数据表同口径）；若意图是「有失败的会话占比」需主控拍板改一行。
3. **raw desc 2000 字符安全上限**：正常任务书引用远低于此（实测最大 383）；极端内联长文会截断（v2 可调）。
4. **多进程边界**：headless 每进程一会话（45 会话实证），跨进程并发由 LOCK 串行化；raw 追加与主卡写入同锁（跨进程一致）。
5. **v2 明确不做**（DESIGN MVP 边界）：LLM 模式洞察、路由表自动刷新、多会话周报、观测卡↔人工段落 fuzzy-join。
6. 未 git commit（git 唯一写者 = Hermes 主控，遵守任务硬约束）。
