/**
 * dsh-observation-journal 回放测试（OBS_REPLAY 模式）
 *
 * 用真实 session.jsonl.zstd 样本（style-museum 45 会话实测集）解压后喂给回放，
 * 逐字段与人工核对的锚点 + 独立重算对照。需要 python3 + zstandard 做解压。
 *
 * 运行：node --test tests/
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, writeFileSync, rmSync, existsSync, readdirSync, copyFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const __dirname = dirname(fileURLToPath(import.meta.url));
const FIXTURES = join(__dirname, 'fixtures');
const LIB = join(__dirname, '..', 'lib', 'index.js');

const BEGIN = '<!-- OBS-JOURNAL:BEGIN -->';
const END = '<!-- OBS-JOURNAL:END -->';
const STATS = '<!-- OBS-JOURNAL:STATS -->';
const STATS_END = '<!-- OBS-JOURNAL:STATS:END -->';

// ---- 工具函数 ----

const decompressZstd = (zstdPath, outPath) => {
  const script = [
    'import zstandard, sys',
    'src, dst = sys.argv[1], sys.argv[2]',
    'with open(src, "rb") as fin, open(dst, "wb") as fout:',
    '    reader = zstandard.ZstdDecompressor().stream_reader(fin, read_across_frames=True)',
    '    while True:',
    '        chunk = reader.read(1 << 16)',
    '        if not chunk: break',
    '        fout.write(chunk)',
  ].join('\n');
  const r = spawnSync('python3', ['-c', script, zstdPath, outPath], { encoding: 'utf8' });
  assert.equal(r.status, 0, 'python3 zstandard decompress failed: ' + (r.stderr || '').trim());
};

const readEvents = (jsonlPath) => {
  const evs = [];
  for (const line of readFileSync(jsonlPath, 'utf8').split('\n')) {
    if (!line.trim()) continue;
    evs.push(JSON.parse(line));
  }
  return evs;
};

/** 与 lib 相同的规格独立重算（对照基准，非复用 lib 代码） */
const computeGroundTruth = (evs) => {
  const g = {
    sid: null, cwd: null, createdAt: null,
    title: null, desc: null,
    model: null, effort: null, provider: null,
    turns: 0, steps: 0, stepFirst: null, stepLast: null,
    tools: {}, calls: 0, failedTools: {}, fail: 0,
    status: 'unknown', todos: null,
  };
  const callMap = new Map();
  for (const ev of evs) {
    const d = ev.data ?? {};
    const t = ev.time;
    if (ev.type === 'session') {
      g.sid = ev.id; g.cwd = ev.cwd; g.createdAt = ev.createdAt ?? t;
    } else if (ev.type === 'session/title') {
      const kind = d.source?.kind;
      if ((kind === 'provider' || kind === 'fallback') && typeof d.title === 'string') {
        const rank = kind === 'provider' ? 2 : 1;
        if (!g.titleRank || rank >= g.titleRank) { g.titleRank = rank; g.title = d.title; }
      }
    } else if (ev.type === 'user/message') {
      if (d.source?.kind === 'user' && g.desc == null) {
        const c = d.content;
        g.desc = typeof c === 'string' ? c : Array.isArray(c) ? c.map((b) => (b?.text) ?? '').join('') : '';
      }
    } else if (ev.type === 'request/context') {
      if (typeof d.model === 'string') g.model = d.model;
      if (typeof d.provider === 'string') g.provider = d.provider;
    } else if (ev.type === 'request/header') {
      const cfg = d.header?.config ?? {};
      if (typeof cfg.reasoningEffort === 'string') g.effort = cfg.reasoningEffort;
    } else if (ev.type === 'todo/write') {
      if (Array.isArray(d.todos)) g.todos = d.todos.slice(0, 5).map((x) => ({ content: String(x?.content ?? ''), status: String(x?.status ?? '') }));
    } else if (ev.type === 'tool/call') {
      g.calls += 1;
      g.tools[d.name] = (g.tools[d.name] || 0) + 1;
      if (typeof d.callId === 'string') callMap.set(d.callId, d.name);
    } else if (ev.type === 'tool/result') {
      const m = d.message ?? {};
      const blk = Array.isArray(m.content) ? (m.content.find((b) => b && b.type === 'tool-result') ?? null) : null;
      if (blk ? blk.isError === true : m.isError === true) {
        g.fail += 1;
        const cid = (blk && blk.toolCallId) || m.source?.callId || m.callId;
        const fname = typeof cid === 'string' ? (callMap.get(cid) ?? 'unknown') : 'unknown';
        g.failedTools[fname] = (g.failedTools[fname] || 0) + 1;
      }
    } else if (ev.type === 'step/start') {
      g.steps += 1;
      if (g.stepFirst == null || t < g.stepFirst) g.stepFirst = t;
    } else if (ev.type === 'step/end') {
      if (g.stepLast == null || t > g.stepLast) g.stepLast = t;
    } else if (ev.type === 'turn/end') {
      g.turns += 1;
      const kind = d.reason?.kind;
      g.status = typeof kind === 'string' && kind ? kind : 'unknown';
    }
  }
  g.dur = Math.max(0, Math.round(((g.stepLast ?? g.createdAt) - (g.stepFirst ?? g.createdAt)) / 1000));
  g.toolsTop = Object.entries(g.tools).sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0)).slice(0, 5).map(([n, c]) => `${n}:${c}`).join(',');
  g.modelCell = g.model + (g.effort ? `(${g.effort})` : '');
  return g;
};

const p2 = (n) => String(n).padStart(2, '0');
const fmtCard = (ms) => {
  const d = new Date(ms);
  return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}T${p2(d.getHours())}:${p2(d.getMinutes())}`;
};

let applyFn = null;
const getApply = async () => {
  if (!applyFn) applyFn = (await import(LIB)).apply;
  return applyFn;
};

const runReplay = async (jsonlPath, { obsFile, config = {} } = {}) => {
  const dir = mkdtempSync(join(tmpdir(), 'obs-journal-'));
  const obs = obsFile ?? join(dir, 'observations.md');
  process.env.OBS_REPLAY = jsonlPath;
  if (obsFile === undefined && process.env.OBS_FILE) delete process.env.OBS_FILE;
  process.env.OBS_FILE = obs;
  try {
    await (await getApply())({ on: () => {} }, config);
  } finally {
    delete process.env.OBS_REPLAY;
    delete process.env.OBS_FILE;
  }
  return { obs, dir };
};

const readCard = (obsFile) => {
  const text = readFileSync(obsFile, 'utf8');
  assert.ok(text.includes(BEGIN), 'card BEGIN marker missing');
  assert.ok(text.includes(END), 'card END marker missing');
  const body = text.slice(text.indexOf(BEGIN) + BEGIN.length, text.indexOf(END));
  const lines = body.split('\n').map((l) => l.trim()).filter(Boolean);
  assert.equal(lines[0], '| time | sid | task | model | dur | turns | tools | calls | fail | status |');
  assert.match(lines[1], /^\|(\s*---\s*\|)+$/);
  return { text, rows: lines.slice(2).map(parseRow) };
};

const parseRow = (line) => {
  // 单元格可能含 \| 转义竖线：先按未转义竖线切
  const cells = [];
  let cur = '';
  for (let i = 1; i < line.length - 1; i++) {
    const ch = line[i];
    if (ch === '|' && line[i - 1] !== '\\') { cells.push(cur.trim()); cur = ''; }
    else cur += ch;
  }
  cells.push(cur.trim());
  assert.equal(cells.length, 10, 'row should have 10 cells: ' + line);
  return {
    time: cells[0], sid: cells[1], task: cells[2], model: cells[3],
    dur: Number(cells[4]), turns: Number(cells[5]), tools: cells[6],
    calls: Number(cells[7]), fail: Number(cells[8]), status: cells[9],
  };
};

const readRawLines = (obsFile) => readFileSync(obsFile + '.jsonl', 'utf8').trim().split('\n').map((l) => JSON.parse(l));

const taskHash = (t) => createHash('sha1')
  .update(String(t).toLowerCase().replace(/[\s\p{P}]+/gu, '').replace(/\d+$/u, ''))
  .digest('hex').slice(0, 8);

// ---- 真实样本回放 ----

const FIXTURE_ANCHORS = {
  'session-128dec23-7e88-4631-963a-ce088581a6b2': {
    // Flash-max 常规阶段（S11-S10），含 1 次 edit 失败
    time: '2026-08-14T19:56', sid: '128dec23', model: 'deepseek-v4-flash(max)',
    turns: 1, calls: 54, fail: 1, status: 'completed', dur: 298,
    tools: 'bash:28,read:11,edit:8,grep:7', taskPrefix: '阅读 specs/s11-s10.md 任务书，按',
    failed: { edit: 1 },
  },
  'session-41ee5351-b151-448c-84d3-d8457f1243e1': {
    // qwen3.7-plus 视觉 patch 配 max effort → turn error（UNSUPPORTED_REASONING_EFFORT）
    time: '2026-08-14T21:38', sid: '41ee5351', model: 'qwen3.7-plus',
    turns: 1, calls: 0, fail: 0, status: 'error', dur: 0,
    tools: '', task: '只输出你的主模型 id 一句话', failed: {},
  },
  'session-3dea5944-8cee-42ae-9156-80166914e18c': {
    // 会话中途被杀，无 turn/end → status unknown；read_image 失败 1 次
    time: '2026-08-14T21:39', sid: '3dea5944', model: 'deepseek-v4-flash',
    turns: 0, calls: 5, fail: 1, status: 'unknown', dur: 70,
    tools: 'bash:3,read_image:1,skill:1', task: '图片主色调分析',
    failed: { read_image: 1 },
  },
  'session-5fe1ff3a-8f53-4b23-a206-ee6fa737512e': {
    // Pro（deepseek-official, effort high），provider 标题覆盖 fallback
    time: '2026-08-13T21:50', sid: '5fe1ff3a', model: 'deepseek-v4-pro(high)',
    turns: 1, calls: 7, fail: 0, status: 'completed', dur: 26,
    tools: 'edit:3,read:2,bash:1,glob:1', task: 'Add compare attempt count function',
    failed: {},
  },
  'session-abe96e0f-f603-4198-bc73-7dbbb0cb94e4': {
    // Pro-max 长提炼（S11-1，读 74 件教材），todo 轨迹 9 项 → raw 只留 5
    time: '2026-08-14T21:42', sid: 'abe96e0f', model: 'deepseek-v4-pro(max)',
    turns: 1, calls: 106, fail: 0, status: 'completed', dur: 1242,
    tools: 'read:80,bash:12,edit:9,todo_write:4,write:1',
    taskPrefix: '阅读 specs/s11-1.md 任务书，按任', failed: {}, todosCount: 5,
  },
};

for (const [fixture, anchor] of Object.entries(FIXTURE_ANCHORS)) {
  test(`replay: ${fixture.slice(0, 17)} 字段与锚点+独立重算一致`, async () => {
    const zstd = join(FIXTURES, fixture + '.jsonl.zstd');
    assert.ok(existsSync(zstd), 'fixture missing: ' + zstd);
    const dir = mkdtempSync(join(tmpdir(), 'obs-fix-'));
    const jsonl = join(dir, 'session.jsonl');
    decompressZstd(zstd, jsonl);

    const { obs } = await runReplay(jsonl);
    const card = readCard(obs);
    assert.equal(card.rows.length, 1, 'one session → one row');
    const row = card.rows[0];

    // 人工核对锚点
    assert.equal(row.time, anchor.time);
    assert.equal(row.sid, anchor.sid);
    assert.equal(row.model, anchor.model);
    assert.equal(row.turns, anchor.turns);
    assert.equal(row.calls, anchor.calls);
    assert.equal(row.fail, anchor.fail);
    assert.equal(row.status, anchor.status);
    assert.equal(row.dur, anchor.dur);
    assert.equal(row.tools, anchor.tools);
    if (anchor.task) assert.equal(row.task, anchor.task);
    if (anchor.taskPrefix) assert.ok(row.task.startsWith(anchor.taskPrefix), 'task mismatch: ' + row.task);
    assert.ok(!row.task.includes('\n'), 'task cell must not contain newline');
    assert.ok(!row.task.includes(' | '), 'task cell pipe must be escaped');
    assert.match(row.time, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/);

    // 独立重算对照（不依赖 lib 的实现）
    const g = computeGroundTruth(readEvents(jsonl));
    assert.equal(row.sid, g.sid.replace(/^session-/, '').slice(0, 8));
    assert.equal(row.model, g.modelCell);
    assert.equal(row.turns, g.turns);
    assert.equal(row.calls, g.calls);
    assert.equal(row.fail, g.fail);
    assert.equal(row.status, g.status);
    assert.equal(row.dur, g.dur);
    assert.equal(row.tools, g.toolsTop);
    assert.equal(row.time, fmtCard(g.createdAt));
    const expectTask = g.title || g.desc.slice(0, 200);
    assert.equal(row.task, expectTask.replace(/[\x00-\x1f\x7f]/g, ' ').replace(/\|/g, '\\|').replace(/\r?\n/g, ' ').trim());

    // raw sidecar
    const raw = readRawLines(obs);
    assert.equal(raw.length, 1);
    const r = raw[0];
    assert.equal(r.sid, g.sid);
    assert.equal(r.model, g.model);
    assert.equal(r.effort, g.effort ?? null);
    assert.equal(r.cwd, g.cwd);
    assert.equal(r.turns, g.turns);
    assert.equal(r.steps, g.steps);
    assert.equal(r.calls, g.calls);
    assert.equal(r.fail, g.fail);
    assert.equal(r.status, g.status);
    assert.equal(r.dur, g.dur);
    assert.deepEqual(r.tools, g.tools);
    assert.deepEqual(r.failedTools, anchor.failed);
    if (g.title) {
      assert.equal(r.title, g.title);
      assert.equal(r.taskHash, taskHash(g.title));
      assert.match(r.taskHash, /^[0-9a-f]{8}$/);
    }
    assert.equal(r.desc, g.desc);
    if (anchor.todosCount != null) assert.equal((r.todos ?? []).length, anchor.todosCount);
    assert.ok(Array.isArray(r.todos) && r.todos.length <= 5);
    for (const td of r.todos ?? []) assert.equal(typeof td.content, 'string');

    // 统计区
    assert.ok(card.text.includes(STATS), 'stats marker missing');
    assert.ok(card.text.includes(STATS_END), 'stats end marker missing');
    assert.ok(card.text.includes('- 会话总数: 1'));
    const rate = g.calls > 0 ? ((g.fail / g.calls) * 100).toFixed(1) : '0.0';
    assert.ok(card.text.includes(`- 失败率: ${rate}%（${g.fail}/${g.calls}）`));
    if (g.toolsTop) assert.ok(card.text.includes('- top 工具: ' + g.toolsTop));
    assert.ok(card.text.includes(`- 平均时长(秒) 按模型: ${g.modelCell}: ${g.dur}`));

    rmSync(dir, { recursive: true, force: true });
    rmSync(obs, { force: true });
    rmSync(join(obs, '..'), { recursive: true, force: true });
  });
}

// ---- 同一文件多次回放：一行一 session，不合并去重 ----

test('replay: 同一 obsFile 两次回放 → 两行不合并，统计区累计', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'obs-dup-'));
  const jsonlA = join(dir, 'a.jsonl');
  const jsonlB = join(dir, 'b.jsonl');
  decompressZstd(join(FIXTURES, 'session-41ee5351-b151-448c-84d3-d8457f1243e1.jsonl.zstd'), jsonlA);
  decompressZstd(join(FIXTURES, 'session-3dea5944-8cee-42ae-9156-80166914e18c.jsonl.zstd'), jsonlB);
  const obs = join(dir, 'obs.md');

  await runReplay(jsonlA, { obsFile: obs });
  await runReplay(jsonlB, { obsFile: obs });

  const card = readCard(obs);
  assert.equal(card.rows.length, 2, 'two sessions → two rows (no merge/dedup)');
  assert.equal(card.rows[0].sid, '41ee5351');
  assert.equal(card.rows[1].sid, '3dea5944');

  const raw = readRawLines(obs);
  assert.equal(raw.length, 2);

  const text = card.text;
  assert.ok(text.includes('- 会话总数: 2'));
  assert.ok(text.includes(`- 失败率: ${((1 / 5) * 100).toFixed(1)}%（1/5）`));
  assert.ok(text.includes('- top 工具: bash:3,read_image:1,skill:1'));
  assert.ok(text.includes('qwen3.7-plus: 0, deepseek-v4-flash: 70') || text.includes('deepseek-v4-flash: 70') && text.includes('qwen3.7-plus: 0'));
  rmSync(dir, { recursive: true, force: true });
});

// ---- 合成事件：转义 / 脱敏 / 状态原样存 / 首条 user 过滤 ----

test('synthetic: 标题竖线与换行转义、脱敏、interrupted/未知状态原样存', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'obs-syn-'));
  const jsonl = join(dir, 'synthetic.jsonl');
  const t0 = 1786714704334;
  const events = [
    { type: 'session', version: 0, id: 'session-deadbeef-0000-0000-0000-000000000001', createdAt: t0, cwd: '/tmp/x' },
    // 注入类消息必须先于真实任务（必须被过滤掉）
    { type: 'user/message', seq: 1, time: t0 + 1, data: { content: [{ type: 'text', text: 'SKILL-CATALOG-INJECTION' }], source: { kind: 'skill-catalog', form: 'catalog', entries: [] } } },
    { type: 'user/message', seq: 2, time: t0 + 2, data: { content: [{ type: 'text', text: '任务描述 含 sk-1234567890123456789 与密码 password=hunter2' }], source: { kind: 'user' } } },
    { type: 'session/title', seq: 3, time: t0 + 3, data: { title: '标题有|竖线\n和换行', source: { kind: 'fallback' } } },
    { type: 'request/context', seq: 4, time: t0 + 4, data: { provider: 'opencode-go', model: 'deepseek-v4-pro', contextWindow: 1000000 } },
    { type: 'request/header', seq: 5, time: t0 + 5, data: { header: { config: { model: 'deepseek-v4-pro', reasoningEffort: 'max' } } } },
    { type: 'step/start', seq: 6, time: t0 + 6, data: { turn: 1, step: 1 } },
    { type: 'step/end', seq: 7, time: t0 + 6006, data: { turn: 1, step: 1 } },
    { type: 'turn/end', seq: 8, time: t0 + 6007, data: { turn: 1, reason: { kind: 'interrupted' } } },
  ];
  writeFileSync(jsonl, events.map((e) => JSON.stringify(e)).join('\n') + '\n');

  const { obs } = await runReplay(jsonl);
  const card = readCard(obs);
  assert.equal(card.rows.length, 1);
  const row = card.rows[0];
  assert.equal(row.task, '标题有\\|竖线 和换行', 'pipe escaped + newline folded');
  assert.ok(!row.task.includes('\n'));
  assert.equal(row.model, 'deepseek-v4-pro(max)');
  assert.equal(row.status, 'interrupted', 'interrupted stored as-is');
  assert.equal(row.dur, 6);

  const raw = readRawLines(obs)[0];
  assert.equal(raw.desc.includes('sk-1234567890123456789'), false, 'api key must be redacted');
  assert.equal(raw.desc.includes('password=hunter2'), false, 'password must be redacted');
  assert.ok(raw.desc.includes('sk-***'));
  assert.equal(raw.desc.includes('SKILL-CATALOG-INJECTION'), false, 'skill-catalog injection must not become the task');
  assert.equal(raw.taskHash, taskHash('标题有|竖线\n和换行'));

  rmSync(dir, { recursive: true, force: true });
  rmSync(obs, { force: true });
});

test('synthetic: 未知 reason.kind 原样存', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'obs-syn2-'));
  const jsonl = join(dir, 's2.jsonl');
  const t0 = 1786714704334;
  const events = [
    { type: 'session', version: 0, id: 'session-cafe0000-0000-0000-0000-000000000002', createdAt: t0, cwd: '/tmp/x' },
    { type: 'user/message', seq: 1, time: t0 + 1, data: { content: [{ type: 'text', text: 'x' }], source: { kind: 'user' } } },
    { type: 'turn/end', seq: 2, time: t0 + 2, data: { turn: 1, reason: { kind: 'cancelled-by-hermes' } } },
  ];
  writeFileSync(jsonl, events.map((e) => JSON.stringify(e)).join('\n') + '\n');
  const { obs } = await runReplay(jsonl);
  const row = readCard(obs).rows[0];
  assert.equal(row.status, 'cancelled-by-hermes', 'unknown reason.kind stored raw');
  rmSync(dir, { recursive: true, force: true });
  rmSync(obs, { force: true });
});

test('synthetic: 无标题时任务格回退描述（截 200）', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'obs-syn3-'));
  const jsonl = join(dir, 's3.jsonl');
  const t0 = 1786714704334;
  const longDesc = 'D'.repeat(500);
  const events = [
    { type: 'session', version: 0, id: 'session-faceb00c-0000-0000-0000-000000000003', createdAt: t0, cwd: '/tmp/x' },
    { type: 'user/message', seq: 1, time: t0 + 1, data: { content: [{ type: 'text', text: longDesc }], source: { kind: 'user' } } },
    { type: 'turn/end', seq: 2, time: t0 + 2, data: { turn: 1, reason: { kind: 'completed' } } },
  ];
  writeFileSync(jsonl, events.map((e) => JSON.stringify(e)).join('\n') + '\n');
  const { obs } = await runReplay(jsonl);
  const row = readCard(obs).rows[0];
  assert.equal(row.task, 'D'.repeat(200), 'card cell truncated at 200');
  const raw = readRawLines(obs)[0];
  assert.equal(raw.desc, longDesc, 'raw sidecar keeps full description');
  rmSync(dir, { recursive: true, force: true });
  rmSync(obs, { force: true });
});

// ---- 与既有观测卡共存：人工区不动，双区段无冲突 ----

test('coexist: 既有人工观测卡 + 插件双区段共存，人工内容一字不动', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'obs-co-'));
  const jsonl = join(dir, 'co.jsonl');
  decompressZstd(join(FIXTURES, 'session-5fe1ff3a-8f53-4b23-a206-ee6fa737512e.jsonl.zstd'), jsonl);
  const obs = join(dir, 'obs.md');
  const human = [
    '# 观测卡（人工维护）',
    '',
    '## 行为模式',
    '- 自报诚实：3 次主动标注语义修正',
    '- 已装 dsh-fail-logger@0.4.3',
    '',
    '## 待补充',
  ].join('\n') + '\n';
  writeFileSync(obs, human);

  await runReplay(jsonl, { obsFile: obs });

  const text = readFileSync(obs, 'utf8');
  assert.ok(text.startsWith(human.trimEnd()), 'human content must stay untouched at top');
  const cardStart = text.indexOf(BEGIN);
  const statsStart = text.indexOf(STATS);
  assert.ok(cardStart > 0 && statsStart > cardStart, 'card section then stats section appended after human content');
  assert.equal((text.match(/OBS-JOURNAL:BEGIN/g) ?? []).length, 1, 'exactly one card section');
  assert.equal((text.match(/OBS-JOURNAL:END/g) ?? []).length, 1);
  assert.equal((text.match(/OBS-JOURNAL:STATS -->/g) ?? []).length, 1);
  assert.equal(readCard(obs).rows.length, 1);

  // 再次回放同一文件：区段原地替换，不复制、不破坏人工区
  await runReplay(jsonl, { obsFile: obs });
  const text2 = readFileSync(obs, 'utf8');
  assert.ok(text2.startsWith(human.trimEnd()));
  assert.equal((text2.match(/OBS-JOURNAL:BEGIN/g) ?? []).length, 1, 'section replaced in place, not duplicated');
  assert.equal(readCard(obs).rows.length, 2);
  rmSync(dir, { recursive: true, force: true });
});

// ---- maxRows 裁剪 ----

test('maxRows: 主卡只留最近 N 行，raw sidecar 全量', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'obs-cap-'));
  const jsonl = join(dir, 'cap.jsonl');
  decompressZstd(join(FIXTURES, 'session-41ee5351-b151-448c-84d3-d8457f1243e1.jsonl.zstd'), jsonl);
  const obs = join(dir, 'obs.md');
  for (let i = 0; i < 4; i++) await runReplay(jsonl, { obsFile: obs, config: { maxRows: 2 } });
  const card = readCard(obs);
  assert.equal(card.rows.length, 2, 'card trimmed to maxRows');
  const raw = readRawLines(obs);
  assert.equal(raw.length, 4, 'raw sidecar keeps all rows (TTL decoupled)');
  assert.ok(card.text.includes('- 会话总数: 4'), 'stats computed from full sidecar, not trimmed card');
  rmSync(dir, { recursive: true, force: true });
});

// ---- task_hash 归一化 ----

test('task_hash: 去空白/标点/数字后缀归一化，同义标题同哈希', () => {
  const h1 = taskHash('统计页行动处方');
  const h2 = taskHash('统计页行动处方 3');
  const h3 = taskHash('统计 页!行动处方');
  assert.equal(h1, h2, 'trailing digit suffix normalized away');
  assert.equal(h1, h3, 'whitespace/punctuation normalized away');
  assert.notEqual(h1, taskHash('别的任务标题'));
});

// ---- live 路径：session/event 订阅 + dispose 兜底 ----

test('live: 订阅路径逐事件累积，turn/end 防抖落盘；无 turn/end 由 dispose 兜底', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'obs-live-'));
  const obs = join(dir, 'obs.md');
  let handler = null;
  const disposes = [];
  const ctx = {
    on: (ev, fn) => {
      if (ev === 'session/event') handler = fn;
      if (ev === 'dispose') disposes.push(fn);
    },
  };
  process.env.OBS_FILE = obs;
  await (await getApply())(ctx, { flushMs: 0 });
  delete process.env.OBS_FILE;
  assert.ok(handler, 'session/event subscription registered');

  const t0 = 1786714704334;
  const send = (ev) => handler(null, ev);
  // 会话 A：完整终局
  send({ type: 'session', version: 0, id: 'session-aaaa1111-0000-0000-0000-00000000000a', createdAt: t0, cwd: '/tmp/x' });
  send({ type: 'user/message', seq: 1, time: t0 + 1, data: { content: [{ type: 'text', text: '任务A' }], source: { kind: 'user' } } });
  send({ type: 'session/title', seq: 2, time: t0 + 2, data: { title: '任务A标题', source: { kind: 'fallback' } } });
  send({ type: 'request/context', seq: 3, time: t0 + 3, data: { model: 'deepseek-v4-flash', provider: 'opencode-go' } });
  send({ type: 'step/start', seq: 4, time: t0 + 4, data: { turn: 1, step: 1 } });
  send({ type: 'step/end', seq: 5, time: t0 + 4004, data: { turn: 1, step: 1 } });
  send({ type: 'turn/end', seq: 6, time: t0 + 4005, data: { turn: 1, reason: { kind: 'completed' } } });
  await new Promise((r) => setTimeout(r, 400)); // 防抖（flushMs 下限 300ms，同 fail-logger）
  const card1 = readCard(obs);
  assert.equal(card1.rows.length, 1);
  assert.equal(card1.rows[0].sid, 'aaaa1111');
  assert.equal(card1.rows[0].task, '任务A标题');
  assert.equal(card1.rows[0].model, 'deepseek-v4-flash');
  assert.equal(card1.rows[0].status, 'completed');
  assert.equal(card1.rows[0].dur, 4);

  // 会话 B：中途被杀，无 turn/end → dispose 兜底落盘
  send({ type: 'session', version: 0, id: 'session-bbbb2222-0000-0000-0000-00000000000b', createdAt: t0 + 100000, cwd: '/tmp/x' });
  send({ type: 'user/message', seq: 1, time: t0 + 100001, data: { content: [{ type: 'text', text: '任务B' }], source: { kind: 'user' } } });
  assert.equal(disposes.length, 1);
  for (const fn of disposes) fn();
  const card2 = readCard(obs);
  assert.equal(card2.rows.length, 2);
  assert.equal(card2.rows[1].sid, 'bbbb2222');
  assert.equal(card2.rows[1].status, 'unknown', 'no turn/end → status unknown');
  assert.equal(card2.rows[1].task, '任务B');
  const raw = readRawLines(obs);
  assert.equal(raw.length, 2);
  assert.ok(card2.text.includes('- 会话总数: 2'));
  rmSync(dir, { recursive: true, force: true });
});

// ---- 自定义 marker 与 redact ----

test('config: 自定义 marker 与额外脱敏规则生效', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'obs-cfg-'));
  const jsonl = join(dir, 'cfg.jsonl');
  const t0 = 1786714704334;
  const events = [
    { type: 'session', version: 0, id: 'session-0badc0de-0000-0000-0000-000000000004', createdAt: t0, cwd: '/tmp/x' },
    { type: 'user/message', seq: 1, time: t0 + 1, data: { content: [{ type: 'text', text: 'secret-word-here 是敏感词' }], source: { kind: 'user' } } },
    { type: 'session/title', seq: 2, time: t0 + 2, data: { title: 't1', source: { kind: 'fallback' } } },
    { type: 'turn/end', seq: 3, time: t0 + 3, data: { turn: 1, reason: { kind: 'completed' } } },
  ];
  writeFileSync(jsonl, events.map((e) => JSON.stringify(e)).join('\n') + '\n');
  const { obs } = await runReplay(jsonl, { config: { marker: 'MY-JOURNAL', redact: ['secret-word-here'] } });
  const text = readFileSync(obs, 'utf8');
  assert.ok(text.includes('<!-- MY-JOURNAL:BEGIN -->'));
  assert.ok(text.includes('<!-- MY-JOURNAL:STATS -->'));
  assert.ok(!text.includes('OBS-JOURNAL'));
  const raw = readRawLines(obs)[0];
  assert.ok(raw.desc.includes('***') && !raw.desc.includes('secret-word-here'));
  rmSync(dir, { recursive: true, force: true });
  rmSync(obs, { force: true });
});
