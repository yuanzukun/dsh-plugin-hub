import type { RivetTheme } from '../theme.js';
/** formatBrandWelcome 的渲染输入。 */
export interface FormatBrandWelcomeInput {
    width: number;
    /** 品牌名（缺省 'dsh-tianshu-tui'）。 */
    brand?: string;
    /** 副标题（缺省 'DeepSeek Harness'）。 */
    subtitle?: string;
    /** 插件版本号（提供时副标题行追加 ` · v<version>`；缺省不追加）。 */
    version?: string;
    /** 水平对齐；hero 左栏用 left，窄屏叠放用 center（缺省）。 */
    align?: 'center' | 'left';
}
/**
 * 欢迎页品牌区：主标 brand（BOLD brandColor）+ 副标题（muted），各一行。
 * @param input - 宽度、品牌名、副标题与对齐。
 * @param theme - 当前主题（主标 brandColor BOLD，副标题 muted）。
 * @returns 两行 ANSI；width ≤ 0 返回空数组。
 */
export declare function formatBrandWelcome(input: FormatBrandWelcomeInput, theme: RivetTheme): string[];
/**
 * 首次启动环境检查结果，供欢迎页环境行使用。
 */
export interface WelcomeEnvCheck {
    /** API key 是否已配置（env / credentials 文件 / .env 分层，非仅环境变量）。 */
    hasApiKey: boolean;
    /** 当前目录是否为 git 仓库（git status 可执行）。 */
    isGitRepo: boolean;
    /** 当前主题引用名（如 'graphite'，环境行首段展示）。 */
    themeName: string;
    /** 终端列数（宽度预算）。 */
    cols: number;
    /** 水平对齐；hero 左栏用 left，窄屏叠放用 center（缺省）。 */
    align?: 'center' | 'left';
}
/**
 * 环境检查行：`graphite · API Key ✓ · Git ✓`。
 * 缺 API key 时增加「设 DEEPSEEK_API_KEY 或运行 /key」行动段，warning 色；
 * 超宽按段换行而不是截断行动指引。git ✗ 仅信息性展示。
 * @param env - 环境检查结果（主题名/API key/git/对齐）。
 * @param theme - 当前主题（muted；缺 key 段 warning）。
 * @returns ANSI 行数组；cols ≤ 0 返回空数组。
 */
export declare function formatEnvCheckLine(env: WelcomeEnvCheck, theme: RivetTheme): string[];
/** 欢迎页 Tips 一项（快捷键 + 说明；不可用项整行 muted）。 */
export interface WelcomeTipItem {
    /** 快捷键（如 'ctrl+n'、'/'）。 */
    keyHint: string;
    /** 说明（如 '新会话'）。 */
    label: string;
    /** 可用性；false 时整行 muted（如无可恢复会话）。 */
    available?: boolean;
}
/** formatWelcomeTips 的渲染输入。 */
export interface FormatWelcomeTipsInput {
    width: number;
    items: readonly WelcomeTipItem[];
    /** 水平对齐；宽屏右栏 left，窄屏叠放 center（缺省 left）。 */
    align?: 'center' | 'left';
}
/** 欢迎页行动项上限（动态 /key、/help 也计入）。 */
export declare const WELCOME_TIPS_MAX_ITEMS = 4;
/**
 * 欢迎页 Tips：普通字重 muted 标题 + 快捷键列对齐 + 说明，最多四项。
 * 不可用项整行 muted 且仍显示 keyHint（与旧菜单不同：tips 要让用户知道键还在）。
 * 空 items 仍渲染标题（调用方恒有一组默认 tips）。
 * @param input - 宽度、tips 项与对齐。
 * @param theme - 当前主题（标题/说明 muted，hint secondary）。
 * @returns ANSI 行数组。
 */
export declare function formatWelcomeTips(input: FormatWelcomeTipsInput, theme: RivetTheme): string[];
/** 宽屏左品牌 / 右 tips 的最小列数。 */
export declare const WELCOME_HERO_WIDE_MIN = 72;
/** 欢迎区 / live chrome 左侧留白（列）。避免鲸鱼、品牌、输入轨贴边。 */
export declare const CHROME_GUTTER = 2;
/** formatWelcomeHero 的渲染输入。 */
export interface FormatWelcomeHeroInput {
    width: number;
    /** 已渲染的鲸鱼行（可能为空：窄屏/无色/legacy 降级）。 */
    whale: readonly string[];
    env: WelcomeEnvCheck;
    tips: readonly WelcomeTipItem[];
    /** 插件版本号（透传 formatBrandWelcome 副标题行）。 */
    version?: string;
}
/**
 * 欢迎英雄区：宽屏左鲸鱼/品牌/环境 + 右 Tips zip；窄屏垂直居中叠放。
 * @param input - 终端宽、鲸鱼行、环境检查、tips 项。
 * @param theme - 当前主题。
 * @returns ANSI 行数组；width ≤ 0 返回空数组。
 */
export declare function formatWelcomeHero(input: FormatWelcomeHeroInput, theme: RivetTheme): string[];
/**
 * blue/star 像素门禁不满足时的紧凑单列：文字品牌 → Tips → 环境，整体左对齐。
 * 不携带鲸鱼，也不改变显式 retro 的居中/双列旧布局。
 */
export declare function formatCompactWelcomeHero(input: Omit<FormatWelcomeHeroInput, 'whale'>, theme: RivetTheme): string[];
/** star 标题块宽度：standard 宽档 / mini 窄档（生成物实测，welcome-title-frames.ts）。 */
export declare const STAR_TITLE_MAX_COLS: number;
export declare const STAR_TITLE_MIN_COLS: number;
/** star hero 宽屏门禁最小列数（gutter + 画 + 间隙 + 标题窄档）。 */
export declare const STAR_HERO_MIN_COLS: number;
/** star hero 静态矮屏门禁；选档另校验右栏高度 + 11 的整页预算。 */
export declare const STAR_HERO_MIN_ROWS = 24;
/** blue 生成物标题宽度常量；运行时中窄档改用 DeepSeek / Harness 文字 lockup。 */
export declare const BLUE_TITLE_MAX_COLS: number;
export declare const BLUE_TITLE_MIN_COLS: number;
/** blue hero 宽屏门禁最小列数（沿用既有像素布局门禁）。 */
export declare const BLUE_HERO_MIN_COLS: number;
/** blue hero 静态矮屏门禁；选档另校验右栏高度 + 11 的整页预算。 */
export declare const BLUE_HERO_MIN_ROWS = 24;
/** formatStarWelcomeHero / formatBlueWelcomeHero 的渲染输入。 */
export interface FormatStarWelcomeHeroInput {
    width: number;
    /** 终端行数（矮屏门禁）。 */
    rows: number;
    /** 已渲染的抱星鲸鱼行（空数组 = 画已降级，由调用方走紧凑单列）。 */
    whale: readonly string[];
    env: WelcomeEnvCheck;
    tips: readonly WelcomeTipItem[];
    /** 插件版本号（附在 @tianshu 标识行尾）。 */
    version?: string;
    /** 颜色能力等级（缺省 chalk.level）；0 不出画（艺术字/像素画无色无层次）。 */
    colorLevel?: number;
}
/** formatBlueWelcomeHero 的渲染输入（与 star 同形）。 */
export type FormatBlueWelcomeHeroInput = FormatStarWelcomeHeroInput;
/**
 * star 模式欢迎英雄区：左抱星鲸鱼（紫）+ 右艺术字标题块（DeepSeek» /
 * < Harness > / @tianshu·版本 / Tips / 环境行）zip。布局/降级矩阵见
 * formatPixelWelcomeHero；门禁常量 STAR_HERO_MIN_COLS / STAR_HERO_MIN_ROWS。
 * @param input - 终端尺寸、鲸鱼行、环境检查、tips 项。
 * @param theme - 当前主题（标题 brandColor BOLD、副标 secondary、标识/环境 muted）。
 * @returns ANSI 行数组；降级时空数组。
 */
export declare function formatStarWelcomeHero(input: FormatStarWelcomeHeroInput, theme: RivetTheme): string[];
/**
 * blue 模式欢迎英雄区（默认风格）：左蓝鲸抱星 + 右标题块
 * （DeepSeek / Harness / @tianshu·版本 / Tips / 环境行）zip。
 * 宽档使用 ANSI Shadow；中窄档使用简洁 DeepSeek / Harness 文字 lockup，
 * full 宽度档不用双宽块字符 ANSI Shadow。布局/降级矩阵见
 * formatPixelWelcomeHero；门禁常量 BLUE_HERO_MIN_COLS / BLUE_HERO_MIN_ROWS。
 * @param input - 终端尺寸、鲸鱼行、环境检查、tips 项。
 * @param theme - 当前主题（标题 brandColor BOLD、副标 secondary、标识/环境 muted）。
 * @returns ANSI 行数组；降级时空数组。
 */
export declare function formatBlueWelcomeHero(input: FormatBlueWelcomeHeroInput, theme: RivetTheme): string[];
