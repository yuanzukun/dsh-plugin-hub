/**
 * Session title surface — `/session list` 每行展示的会话标题。
 *
 * 只读纯函数层。数据源是官方 harness 的 log-backed `session/title` 事件
 * （`@deepseek-ai/dsh-session-title` 服务写入；LLM 标题由装配在 dsh-base 的
 * `session-title-llm` provider 在会话活跃时自动生成，first-prompt cadence）。
 * TUI 不做任何生成：不调 API、不写 sidecar、不发明事件——「纯展示层」纪律与
 * 「所有渲染状态派生自会话事件」在本模块保持成立（dsh-base 装配见宿主
 * cordis.patch.yml：session-title + session-title-llm）。
 *
 * 展示优先级：
 * 1. seed 边界（`session/end-seed`，fork/恢复标记）之后本会话自己的标题事件
 *    或首条真人消息——同父 fork 不再撞父标题；
 * 2. 全量折叠的最新 `session/title` 事件（fallback / LLM provider / 用户 rename 源）；
 * 3. 确定性 fallback——首条真人消息的前几个词（与 dsh-base 装配配置
 *    `fallbackMaxWords: 5` / `fallbackMaxBytes: 40` 对齐；历史会话无标题事件
 *    时免费可用，纯函数现算、不落盘）；
 * 4. 无任何真人聊天记录 → {@link EMPTY_TITLE}。
 *
 * @module @deepseek-ai/dsh-tianshu-tui/adapter/session-title
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
/** 无任何真人聊天记录的会话直接展示的占位标题（状态而非内容）。 */
export declare const EMPTY_TITLE = "\u65B0\u5BF9\u8BDD";
/** fallback 词数上限（与 dsh-base 装配的 session-title config 对齐）。 */
export declare const FALLBACK_MAX_WORDS = 5;
/** fallback 字节上限（与 dsh-base 装配的 session-title config 对齐）。 */
export declare const FALLBACK_MAX_BYTES = 40;
/**
 * 计算一个会话在 `/session list` 中的展示标题。
 * 纯函数、同步、无副作用：seed 边界后的自有标题 → 全量 fold → 确定性
 * fallback → 「新对话」。
 * @param events - 会话事件日志（live 或持久化重放）。
 * @returns 展示标题（恒非空）。
 */
export declare function sessionTitleFor(events: readonly SessionEvent[]): string;
