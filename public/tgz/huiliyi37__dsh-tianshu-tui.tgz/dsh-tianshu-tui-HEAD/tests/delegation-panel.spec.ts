/**
 * delegation-panel.spec.ts — 委派树面板纯函数（grok-build tasks_pane 分组行移植）。
 *
 * 覆盖：标题行与空输入、depth 层级缩进、卡片状态形（进行中 ⠋ / 终态 ›/✗）、
 * mode 标记（one-shot ▶ / continuable ↻）、label 与短哈希、运行态投影段
 * （进行中 ⎿ body：activity / token / 工具计数；header suffix：终态词 / 耗时）、
 * 宽度预算、diagnostic 警示行、极端窄宽不抛错。条目自带 identity/progress/timing。
 */
import { describe, expect, it } from 'vitest'
import {
  projectDelegationTree,
  projectExternalRunSection,
  type DelegationProgressProjection,
  type DelegationTreeEntry,
  type ExternalRunEntry,
} from '../src/delegation-panel.js'
import { displayWidth } from '../src/width.js'

/** child 条目：running + continuable，depth 1。 */
const childRunningContinuable: DelegationTreeEntry = {
  kind: 'child',
  id: '11111111-2222-4333-8444-555555555555',
  parentId: 'root-session',
  depth: 1,
  activity: 'running',
  hasChildren: true,
  mode: 'continuable',
  label: '主探索',
}

/** child 条目：inactive + one-shot 且无 label（触发短哈希回退），depth 2。 */
const childInactiveOneShotNoLabel: DelegationTreeEntry = {
  kind: 'child',
  id: 'aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee',
  parentId: '11111111-2222-4333-8444-555555555555',
  depth: 2,
  activity: 'inactive',
  hasChildren: false,
  mode: 'one-shot',
}

/** diagnostic 条目。 */
const diagnosticEntry: DelegationTreeEntry = {
  kind: 'diagnostic',
  id: 'dddddddd-0000-4aaa-8bbb-cccccccccccc',
  parentId: 'root-session',
  depth: 1,
  reason: 'corrupt',
}

/** 运行中 progress：一次进行中的 bash 调用。 */
const progressRunningTool: DelegationProgressProjection = {
  turns: 0,
  toolCalls: 1,
  tokensUsed: 12_300,
  lastTool: 'bash',
  toolInFlight: true,
}

const withProgress = (
  base: DelegationTreeEntry,
  progress: DelegationProgressProjection,
): DelegationTreeEntry => (base.kind === 'child' ? { ...base, progress } : base)

describe('projectDelegationTree 标题与空输入', () => {
  it('空 entries 返回空数组（无委派树则不渲染面板）', () => {
    expect(projectDelegationTree([], { width: 80 })).toEqual([])
  })

  it('非空 entries 首行为标题行', () => {
    const rows = projectDelegationTree([childRunningContinuable], { width: 80 })
    expect(rows[0]).toBe('🌳 委派')
  })
})

describe('projectDelegationTree 层级缩进（depth 驱动）', () => {
  it('depth 1 缩进 2 空格，depth 2 缩进 4 空格', () => {
    const rows = projectDelegationTree(
      [childRunningContinuable, childInactiveOneShotNoLabel],
      { width: 80 },
    )
    const line1 = rows.find(r => r.includes('主探索'))
    const line2 = rows.find(r => r.includes('aaaaaaaa'))
    expect(line1).toMatch(/^  › /)
    expect(line2).toMatch(/^    › /)
  })
})

describe('projectDelegationTree activity/mode 标记', () => {
  it('running 无 in-flight → ›，continuable → ↻', () => {
    const rows = projectDelegationTree([childRunningContinuable], { width: 80 })
    expect(rows).toContain('  › ↻ 主探索')
  })

  it('inactive → ›，one-shot → ▶', () => {
    const rows = projectDelegationTree([childInactiveOneShotNoLabel], { width: 80 })
    const line = rows.find(r => r.includes('aaaaaaaa'))
    expect(line).toMatch(/^    › ▶ /)
  })
})

describe('projectDelegationTree label 与短哈希回退', () => {
  it('label 存在时渲染 label', () => {
    const rows = projectDelegationTree([childRunningContinuable], { width: 80 })
    expect(rows.some(r => r.includes('主探索'))).toBe(true)
  })

  it('label 缺失回退 id 前 8 位短哈希', () => {
    const rows = projectDelegationTree([childInactiveOneShotNoLabel], { width: 80 })
    expect(rows.some(r => r.includes('aaaaaaaa'))).toBe(true)
    expect(rows.some(r => r.includes('aaaaaaaa-bbbb'))).toBe(false)
  })

  it('session- 前缀 id 的短哈希回退去前缀（uuid8，非 session- 空壳）', () => {
    const entry: DelegationTreeEntry = {
      ...childInactiveOneShotNoLabel,
      id: 'session-77aa88bb-9c00-4d11-8e22-334455667788',
    }
    const rows = projectDelegationTree([entry], { width: 80 })
    expect(rows.some(r => r.includes('77aa88bb'))).toBe(true)
    expect(rows.some(r => r.includes('session-'))).toBe(false)
  })
})

describe('projectDelegationTree 运行态投影段', () => {
  it('进行中工具 → header ⠋ + ⎿ `Running: <tool>`', () => {
    const rows = projectDelegationTree([withProgress(childRunningContinuable, progressRunningTool)], { width: 80 })
    expect(rows.some(r => r.includes('⠋') && r.includes('主探索'))).toBe(true)
    expect(rows.some(r => r.includes('Running: bash'))).toBe(true)
    expect(rows.some(r => r.includes('⎿'))).toBe(true)
  })

  it('工具已完成且 turn 未结束 → ⎿ `Done: <tool>`', () => {
    const done: DelegationProgressProjection = {
      ...progressRunningTool, toolInFlight: false,
    }
    const rows = projectDelegationTree([withProgress(childRunningContinuable, done)], { width: 80 })
    expect(rows.some(r => r.includes('Done: bash'))).toBe(true)
    expect(rows.some(r => r.includes('⎿'))).toBe(true)
  })

  it('token 段复用紧凑格式（12.3k tok），工具计数段在 body', () => {
    const rows = projectDelegationTree([withProgress(childRunningContinuable, progressRunningTool)], { width: 80 })
    const body = rows.find(r => r.includes('Running: bash'))
    expect(body).toContain('12.3k tok')
    expect(body).toContain('1 工具')
  })

  it('终态词：completed → `✓ 已完成`；error → `✗ 出错`', () => {
    const done: DelegationProgressProjection = {
      ...progressRunningTool, toolInFlight: false, lastTurnEnd: 'completed',
    }
    const rows = projectDelegationTree([withProgress(childRunningContinuable, done)], { width: 80 })
    expect(rows.some(r => r.includes('✓ 已完成'))).toBe(true)
    expect(rows.some(r => r.includes('⎿'))).toBe(false)
    const failed: DelegationProgressProjection = {
      ...progressRunningTool, toolInFlight: false, lastTurnEnd: 'error',
    }
    const rows2 = projectDelegationTree([withProgress(childRunningContinuable, failed)], { width: 80 })
    expect(rows2.some(r => r.includes('✗ 出错'))).toBe(true)
    expect(rows2.some(r => r.startsWith('  ✗ '))).toBe(true)
    expect(rows2.some(r => r.includes('⎿'))).toBe(false)
  })
})

describe('projectDelegationTree 耗时', () => {
  it('entry.timing settledMs 渲染耗时（秒，一位小数）', () => {
    const entry: DelegationTreeEntry = { ...childRunningContinuable, timing: { settledMs: 2300 } }
    const rows = projectDelegationTree([entry], { width: 80 })
    expect(rows.some(r => r.includes('2.3s'))).toBe(true)
  })

  it('无 progress/timing 时不渲染运行信息段', () => {
    const rows = projectDelegationTree([childRunningContinuable], { width: 80 })
    const line = rows.find(r => r.includes('主探索'))
    expect(line).toBe('  › ↻ 主探索')
  })

  it('active turn + now → 实时耗时 = settledMs + (now - since)', () => {
    const entry: DelegationTreeEntry = {
      ...childRunningContinuable,
      timing: { settledMs: 1000, active: { since: 10_000, through: 10_000 } },
    }
    const rows = projectDelegationTree([entry], { width: 80, now: 13_000 })
    expect(rows.some(r => r.includes('4.0s'))).toBe(true)
  })

  it('active turn 无 now → 回落 settledMs', () => {
    const entry: DelegationTreeEntry = {
      ...childRunningContinuable,
      timing: { settledMs: 1000, active: { since: 10_000, through: 10_000 } },
    }
    const rows = projectDelegationTree([entry], { width: 80 })
    expect(rows.some(r => r.includes('1.0s'))).toBe(true)
  })
})

describe('projectDelegationTree 宽度预算（suffix 从右往左丢）', () => {
  it('行放不下时先丢尾部 suffix，再截 label', () => {
    const entry: DelegationTreeEntry = {
      ...childRunningContinuable,
      progress: progressRunningTool,
      timing: { settledMs: 2300 },
    }
    const rows = projectDelegationTree([entry], { width: 16 })
    for (const row of rows) {
      expect(displayWidth(row)).toBeLessThanOrEqual(16)
    }
    const header = rows.find(r => r.includes('主探索'))
    expect(header).toBeDefined()
    expect(header).not.toContain('2.3s')
    const rows2 = projectDelegationTree([entry], { width: 10 })
    for (const row of rows2) {
      expect(displayWidth(row)).toBeLessThanOrEqual(10)
    }
    const header2 = rows2.find(r => r.includes('Running') || r.includes('主'))
    expect(header2).toBeDefined()
    expect(rows2.some(r => r.includes('Running'))).toBe(false)
  })

  it('宽幅下完整渲染（header 耗时 + ⎿ 活动段）', () => {
    const entry: DelegationTreeEntry = {
      ...childRunningContinuable,
      progress: progressRunningTool,
      timing: { settledMs: 2300 },
    }
    const rows = projectDelegationTree([entry], { width: 80 })
    expect(rows[1]).toBe('  ⠋ ↻ 主探索 · 2.3s')
    expect(rows[2]).toBe('  ⎿  Running: bash · 12.3k tok · 1 工具')
  })
})

describe('projectDelegationTree diagnostic 警示行', () => {
  it('diagnostic 条目渲染警示行（不伪造 activity/mode）', () => {
    const rows = projectDelegationTree([diagnosticEntry], { width: 80 })
    const line = rows.find(r => r.includes('dddddddd'))
    expect(line).toMatch(/⚠/)
    expect(line).not.toMatch(/[⠋›✗]/)
  })

  it('unavailable reason → 不可用 警示文本', () => {
    const rows = projectDelegationTree(
      [{ kind: 'diagnostic', id: 'uuuuuuuu-0000-4aaa-8bbb-cccccccccccc', parentId: 'root-session', depth: 1, reason: 'unavailable' }],
      { width: 80 },
    )
    expect(rows.some(r => r.includes('不可用'))).toBe(true)
  })

  it('unsupported reason → 不支持 警示文本', () => {
    const rows = projectDelegationTree(
      [{ kind: 'diagnostic', id: 'ssssssss-0000-4aaa-8bbb-cccccccccccc', parentId: 'root-session', depth: 1, reason: 'unsupported' }],
      { width: 80 },
    )
    expect(rows.some(r => r.includes('不支持'))).toBe(true)
  })
})

describe('projectDelegationTree 窄宽截断', () => {
  it('长 label 在窄宽下截断补 …，且不超 width', () => {
    const longEntry: DelegationTreeEntry = {
      kind: 'child',
      id: '99999999-8888-4777-8666-555555555555',
      parentId: 'root-session',
      depth: 1,
      activity: 'running',
      hasChildren: false,
      mode: 'continuable',
      label: '这是一个非常非常长的委派任务描述，用来验证窄宽截断降级逻辑是否正常工作',
    }
    const rows = projectDelegationTree([longEntry], { width: 16 })
    for (const row of rows) {
      expect(displayWidth(row)).toBeLessThanOrEqual(16)
    }
    const line = rows.find(r => r.includes('…'))
    expect(line).toBeDefined()
  })

  it('极端窄宽（width ≤ 1）不抛错', () => {
    expect(() =>
      projectDelegationTree([childRunningContinuable], { width: 1 }),
    ).not.toThrow()
  })

  it('宽幅下不截断', () => {
    const rows = projectDelegationTree([childRunningContinuable], { width: 80 })
    expect(rows).toContain('  › ↻ 主探索')
  })
})

describe('projectExternalRunSection（G3 外部 run 等价状态面）', () => {
  const external: ExternalRunEntry = {
    id: 'ext-1',
    provider: 'acp',
    label: '外部检索',
    startedAt: 1000,
  }

  it('空数组 → 空行数组（无活跃外部 run 不渲染段）', () => {
    expect(projectExternalRunSection([], { width: 80 })).toEqual([])
  })

  it('非空 → 标题行 + 每 run 一张运行中卡（provider 徽标 + 实时耗时）', () => {
    const rows = projectExternalRunSection([external], { width: 80, now: 5000 })
    expect(rows[0]).toBe('⤷ 外部子代理')
    expect(rows.some(r => r.includes('外部检索 · acp'))).toBe(true)
    expect(rows.some(r => r.includes('4.0s'))).toBe(true)
  })

  it('label 缺失回退 id 短哈希；now 缺失不渲染耗时', () => {
    const rows = projectExternalRunSection([{ id: 'ext-2', provider: 'codex' }], { width: 80 })
    expect(rows.some(r => r.includes('ext-2') && r.includes('codex'))).toBe(true)
    expect(rows.some(r => r.includes('⠋'))).toBe(true) // 运行中卡仍渲染，仅无耗时段
  })
})

describe('委派树 running 执行位（G1）', () => {
  it('running=true → 运行态字形（无 lastTurnEnd 的活跃子代理）', () => {
    const entry: DelegationTreeEntry = {
      ...childRunningContinuable,
      activity: 'running',
      progress: { turns: 1, toolCalls: 0, tokensUsed: 0, toolInFlight: false, running: true },
    }
    const rows = projectDelegationTree([entry], { width: 80 })
    expect(rows.some(r => r.includes('⠋'))).toBe(true)
  })

  it('running=false（旧投影值缺省）→ 回落 toolInFlight 语义（现行为不变）', () => {
    const entry: DelegationTreeEntry = {
      ...childRunningContinuable,
      activity: 'running',
      progress: progressRunningTool, // toolInFlight: true、无 running 位
    }
    const rows = projectDelegationTree([entry], { width: 80 })
    expect(rows.some(r => r.includes('⠋'))).toBe(true)
  })
})
