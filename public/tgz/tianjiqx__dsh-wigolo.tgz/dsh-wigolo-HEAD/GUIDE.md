# dsh-wigolo Usage Guide

> **One-liner**: gives DSH's AI 18+ search-engine fusion, site crawls, structured extraction, multi-step deep research, a reusable local cache, and URL change monitoring — **search stops being one-shot and becomes an accumulating, reusable, watchable knowledge pipeline.**
>
> This guide is organized by real workflows. Each scenario covers "who it's for, what it can do, how to use it, what you get."

---

## Quick Start (Installation)

The plugin ships with `cordis.patch.yml` (declared via `dsh.bundle.patch`). After `dsh plugin add`, the **host side registers automatically — no manual route setup needed**. Taking the `web` profile as an example:

```sh
# 1. Install into the profile
dsh plugin --profile web add github:tianjiqx/dsh-wigolo

# 2. Write the wigolo daemon's bearer token to a secure file
echo "YOUR_TOKEN" > ~/.dsh/wigolo-token && chmod 600 ~/.dsh/wigolo-token

# 3. Restart dsh web to apply
```

Open the **Wigolo** entry in the sidebar and hit **Test connection** to verify connectivity.

**Prerequisites**: a running [wigolo daemon](https://knockoutez.github.io/wigolo/docs/) (v0.2+), reachable over HTTP with a bearer token. Local `127.0.0.1:3333` is the default — zero extra configuration.

**Editing config** (e.g. adjust tool timeouts, enable takeover): use the "Connection" and "Takeover & Tools" tabs of the sidebar Wigolo panel; saving applies immediately (connection/token changes hot-reload; the takeover toggle needs a DSH restart).

**Editing the config file directly** (advanced): config lives in `~/.dsh/wigolo.json` (v2, atomic writes):

```jsonc
{
  "version": 2,
  "connection": {
    "host": "127.0.0.1",       // daemon address
    "port": 3333,
    "hostHeader": "auto",       // auto | none | "<literal>"
    "tokenFile": ""             // "" = ~/.dsh/wigolo-token
  },
  "takeover": false,            // true = wigolo drives web_search + web_fetch
  "tools": {
    "wigolo_search":  { "enabled": true,  "defaults": { "max_results": 10 } },
    "wigolo_crawl":   { "enabled": true,  "defaults": { "max_pages": 50 }, "timeoutMs": 300000 },
    "wigolo_extract": { "enabled": true },
    "wigolo_research":{ "enabled": true,  "timeoutMs": 600000 },
    "wigolo_find_similar": { "enabled": false },
    "wigolo_cache":   { "enabled": true },
    "wigolo_watch":   { "enabled": true }
  },
  "announceToAgent": true
}
```

Uninstall: `dsh plugin --profile web remove @tianjiqx/dsh-wigolo` — everything is cleaned up automatically.

---

## Know It (30 seconds)

After installing, any conversation gains a set of tools: **wigolo_search · wigolo_crawl · wigolo_extract · wigolo_research · wigolo_find_similar · wigolo_cache · wigolo_watch**. The sidebar gains a **Wigolo** panel with tabs: **Connection · Takeover & Tools · About**. You can optionally enable a "Wigolo Cache" conversation tab for read-only browsing of the daemon cache library.

One sentence: **search goes from "use-and-throw-away" to "the more you search, the more you have"** — searched content is cached automatically, whole sites can be crawled, pages can be structurally extracted, complex questions can be researched in multiple steps, and URLs can be watched for changes.

> Tip: `wigolo_find_similar` is off by default (used less often); enable it in the "Takeover & Tools" tab when needed. The other six tools are all on by default.

---

## Scenario 1: Check the "notebook" before searching (cache-first)

**Who it's for**: people who often ask the AI about the same topic or documents — and don't want to re-search from scratch every time.

The wigolo daemon automatically caches the full markdown of every page searched or crawled. **What the AI has searched before, it doesn't need to search again** — it checks the local cache first: instant, zero network cost.

**How to use**:

1. Tell the AI "**search for the new features in React 19**" — it uses `wigolo_search`, and results go into the cache automatically;
2. Days later, ask "**what did that React 19 document we looked up say?**" — the AI checks the local cache via `wigolo_cache` first, hits it, and answers instantly with the full markdown (only touching the network on a miss);
3. To inspect cache size: "**how much is in the cache?**" — the AI calls `wigolo_cache stats` and returns the URL count, total size, and time span;
4. Want to clear a stale cache: "**clear the cache**" — the AI confirms with you first (it's destructive), then clears.

**What you get**: zero-latency repeat searches, and full text you can re-check any time — the AI's search goes from "goldfish memory" to "photographic memory."

---

## Scenario 2: Pull an entire docs site into the cache (site crawl)

**Who it's for**: people who need to consult a documentation site repeatedly (React docs, the Rust Book, an internal wiki) — and don't want the AI to fetch URL by URL each time.

**How to use**:

1. Tell the AI "**crawl the React official docs**" — it uses `wigolo_crawl`, expanding from the seed URL by link depth, putting every page into the local cache;
2. Scoping is possible: "**only crawl pages under /docs/, max 100 pages**" — the AI sets `include_patterns` and `max_pages`;
3. After the crawl, all questions about the React docs draw from the cache first — **usable offline** (cache is local);
4. You can also crawl competitor docs, technical specs, API references — any static site.

**What you get**: a whole docs site becomes the AI's "private library" — minutes for the initial crawl, millisecond local lookups afterward.

---

## Scenario 3: Extract structured data out of pages (structured extraction)

**Who it's for**: people who need tables, price lists, API fields etc. from pages — and don't want to copy-paste and reformat by hand.

**How to use**:

1. Tell the AI "**extract the price table from this page**" — it uses `wigolo_extract` with a CSS selector (e.g. `table`, `.price`);
2. More complex: "**extract name, price, and rating from this product page**" — the AI uses a field schema (JSON object) to define the extraction and get structured output in one shot;
3. Note: extract only handles server-rendered DOM. On SPA pages where extraction misses, the AI tells you explicitly and suggests crawling first with `wigolo_crawl`, then parsing the markdown.

**What you get**: tables, lists, and key fields become structured JSON directly — the AI handles the tedious "open page → find target → copy and organize" flow for you.

---

## Scenario 4: Hand complex questions to the "researcher" (deep research)

**Who it's for**: people who need in-depth research on open-ended, multi-faceted questions — "compare X vs Y," "analyze the ecosystem of some technology," questions that need synthesis from many sources.

**How to use**:

1. Tell the AI "**research the pros and cons of Rust vs Go for backend services**" — it uses `wigolo_research`, breaking it into multiple sub-queries (performance, ecosystem, learning curve…), searching sources in parallel, and synthesizing a cited research report;
2. Depth is selectable: "**quick research**" (`quick`) or "**deep research**" (`deep`, up to 30 sources);
3. Domains can be constrained: "**only look at GitHub and Stack Overflow**" — the AI sets `include_domains`;
4. The report comes back with citations — every conclusion is traceable.

> Tip: for simple factual questions ("what's the news today") `wigolo_search` is enough; `wigolo_research` is for open-ended questions needing multi-angle synthesis.

**What you get**: a cited research report — the AI does the heavy "search ten pages → read each → cross-check → write it up" work for you.

---

## Scenario 5: More precise searches — category, freshness, domain filters (advanced search)

**Who it's for**: people with precise requirements on results — news only, code only, content from a domain, last week only.

`wigolo_search` is not an ordinary keyword search; it's a **meta search engine fusing 18+ search engines**, supporting:

- **Category search**: `category` = general / news / code / docs / papers / images — "**search the latest papers**" automatically uses papers;
- **Freshness filter**: `time_range` (day/week/month/year) or an exact date range (`from_date` / `to_date`) — "**this week's tech news**";
- **Domain filter**: `include_domains` / `exclude_domains` — "**only GitHub, not CSDN**";
- **Multi-variant queries**: separate variants with `|` — "**search rust async | tokio vs async-std**", searched in parallel and deduplicated;
- **Depth tiers**: `search_depth` — `ultra-fast` (cache only) / `fast` (engines only) / `balanced` (default) / `deep` (full-text enrichment, lands in cache);
- **Force refresh**: `force_refresh` bypasses the cache — for live info (stock prices, status pages).

**How to use**:

1. Just describe the need in natural language; the AI picks the right parameters;
2. Or be precise: "**search issues about bun runtime on github.com from the last week**" — the AI combines `time_range: week` + `include_domains: ["github.com"]` + `category: code`.

**What you get**: far more precise results — no longer buried in irrelevant content or misled by stale info.

---

## Scenario 6: Take over official search — route web_search through wigolo (search takeover)

**Who it's for**: people who want *all* searches in DSH (including the official `web_search` / `web_fetch`) to go through wigolo's 18+ engine fusion and local cache.

By default `web_search` uses DSH's official provider and `wigolo_search` is a separate enhanced tool. Enabling **takeover** routes `web_search` and `web_fetch` through wigolo too — **all searches unified under wigolo, all results auto-cached**.

**How to use**:

1. Sidebar Wigolo panel → "Takeover & Tools" tab → turn on "**use wigolo for web_search and web_fetch**";
2. Restart DSH to apply (the panel prompts you);
3. Now when the AI calls `web_search`, the underlying engine is wigolo's 18+ fusion — richer results, auto-cached;
4. To switch back: turn the toggle off and restart.

> Technical note: the takeover toggle automatically manages the `searchProvider: wigolo` route config in `~/.dsh/cordis.patch.yml`, avoiding multi-provider conflicts (`WEB_PROVIDER_AMBIGUOUS`).

**What you get**: one switch unifies every search entry — whether the AI uses `web_search` or `wigolo_search`, the same 18+ engine + cache pipeline sits underneath.

---

## Scenario 7: Watch a page and tell me when it changes (URL change monitoring)

**Who it's for**: people who need to keep an eye on page changes — price pages, release pages, status pages, competitor moves — without manually refreshing daily.

**How to use**:

1. Tell the AI "**watch this page and check it once a day**" — it uses `wigolo_watch` to create a job with `interval_seconds: 86400`;
2. Watch only part of the page: "**only watch the price-table section**" — the AI sets `selector` (CSS selector), ignoring noise elsewhere;
3. Batch monitoring: "**add all three URLs to monitoring**" — one call, many jobs;
4. Manage jobs: "**list all watch jobs**", "**pause the price watch**", "**check that page now**", "**delete the watch for the decommissioned page**";
5. Watch jobs **persist across daemon restarts** — nothing is lost;
6. Pair with scheduled tasks for notifications: have the AI check results periodically and notify you via Feishu / in-app on changes.

**What you get**: automatic awareness of page changes — no more daily manual refreshes; the AI watches and notifies.

---

## Scenario 8: Find similar content — start from a good article (similar-content lookup)

**Who it's for**: people who found a great article/document and want more like it — "this is great, are there others?"

> Note: `wigolo_find_similar` is off by default; enable it manually in the "Takeover & Tools" tab.

**How to use**:

1. Tell the AI "**find content similar to this article**" and give the URL — it uses `wigolo_find_similar` to find related content from the local cache and the web;
2. You can also give a concept instead of a URL: "**find articles similar to Rust async runtimes**" — the AI uses the `concept` parameter;
3. If you previously crawled a site, similar-content lookup **prefers the local cache** — instant, zero network cost.

**What you get**: discover more good content starting from one — the AI handles the "follow the vines to the melon" discovery process.

---

## Scenario 9: Visual management — sidebar panel + cache browsing tab

**Who it's for**: users who want to see connection status at a glance, manage tool toggles, and browse cached content.

**Sidebar panel** (tabs):

- **Connection**: daemon host/port/Host header/token file, one-click **Test connection** for live latency + daemon version, and pasting a token directly in the panel (no terminal needed);
- **Takeover & Tools**: search-takeover toggle, cache-tab toggle, per-tool enable/disable — saving applies immediately;
- **About**: plugin version, related links, Host-header tech notes, legacy migration guide.

**"Wigolo Cache" conversation tab** (opt-in):

- Off by default; enable it in the "Takeover & Tools" tab;
- Once on, it appears at the top of the conversation with two sub-pages:
  - **Browse**: a stats bar (URL count / total size / time span) + keyword filter + "this session only" toggle + list (URL/title/fetch time, newest first) + click to expand the full markdown (lazy-loaded);
  - **Watch jobs**: all watch jobs + inline quick actions (check now / pause / resume).

**How to use**:

1. Click the Wigolo icon in the sidebar to open the panel;
2. First time: fill in the daemon address, write the token, hit test in the "Connection" tab — all GUI, no terminal;
3. To browse the cache: enable the cache-tab toggle in "Takeover & Tools" → the "Wigolo Cache" tab appears at the top of the conversation.

**What you get**: connection status at a glance, tool toggles at hand, cache content visualized — not everything needs a conversation; the GUI can manage it.

---

## More Capabilities (one-line index)

- **Parameter-slimming design**: each wigolo daemon MCP tool has 15–25 params; the plugin trims to 6–10 high-frequency ones — the model picks more accurately, easier to use;
- **Key security**: the token lives in `~/.dsh/wigolo-token` (mode 0600), never enters the config JSON, never returns to the browser;
- **Panel loopback fence**: panel API routes are loopback-only (remote address + Host + sec-fetch-site + origin quadruple check), not exposed to LAN deployments;
- **Config hot-reload**: connection/token/tool-toggle changes apply immediately (MCP client reconfigures hot); only the takeover toggle needs a DSH restart;
- **Fail-loud config validation**: unknown fields in the config file trigger a warning and suggest "did you mean XX" (edit-distance match) instead of being silently ignored;
- **Automatic legacy migration**: env vars (`WIGOLO_HOST_IP` / `WIGOLO_PORT`) and an existing token file are imported automatically on first run;
- **Panel i18n**: the sidebar panel is bilingual (zh/en, following the DSH language setting).

---

## Tool Cheat Sheet

| Tool | Purpose | Typical trigger | Timeout |
|------|---------|-----------------|---------|
| `wigolo_search` | Advanced search (18+ engines, category, freshness, domain filter) | "search for XX", "recent news about XX" | 60s |
| `wigolo_crawl` | Site crawl (into local cache) | "crawl this docs site", "grab this wiki" | 300s |
| `wigolo_extract` | Structured extraction (CSS selector / field schema) | "extract this page's price table", "pull the key fields" | 60s |
| `wigolo_research` | Multi-step deep research (decompose + parallel + synthesis) | "research the pros/cons of XX", "deep-dive XX" | 600s |
| `wigolo_find_similar` | Similar-content lookup | "find articles like this one" (off by default) | 120s |
| `wigolo_cache` | Local cache search/stats/clear | "what's in the cache", "how big is it", "clear the cache" | 30s |
| `wigolo_watch` | URL change monitoring | "watch this page", "check this URL daily" | 120s |

---

## Three Principles

1. **Agent-first**: write operations (search/crawl/clear/create-watch) are carried by AI tools — the model judges query variants, depth, and domain filters better; the GUI only does read-only browsing (cache browse / watch status) and is off by default;
2. **Cache as an asset**: every search and crawl accumulates local cache — later lookups are instant, offline-capable, and reusable across sessions;
3. **Safe by default**: token never in config, panel loopback-only, destructive actions confirm first — safe out of the box, no extra hardening.

---
