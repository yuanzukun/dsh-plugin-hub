import { defineConfig } from 'tsdown'
import { readFile } from 'node:fs/promises'
import { basename, dirname, resolve as resolvePath } from 'node:path'
import { createRequire } from 'node:module'
import { transform } from 'lightningcss'

const pkg = createRequire(import.meta.url)('./package.json') as { version: string }

// Platform modules the dsh web shell seeds into its frozen module table
// (see deepseek-harness packages/client/web/src/platform.ts). The client core
// resolves these through the `require` injected by __ModuleLoader__.load; a
// require() the table cannot answer is a guaranteed runtime throw, so anything
// else the bundle imports is inlined below.
const CLIENT_EXTERNALS = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  // Seeded by the web shell's frozen module table (platform.ts) — resolved
  // through the injected require like react; everything else gets inlined.
  '@deepseek-ai/dsh-client-ui-primitives',
]

/**
 * Virtual-id wrapper keeping module CSS away from tsdown's own css pipeline
 * (which requires @tsdown/css). The suffix matters: tsdown's guard matches ids
 * ending in `.css`, so the virtual id must not.
 * (Mirrors deepseek-harness packages/client/tsdown.client.ts.)
 */
const CSS_VIRTUAL_PREFIX = '\0dsh-css:'
const CSS_VIRTUAL_SUFFIX = '.mjs'

export default defineConfig([
  {
    // Host half: one bundled ESM file; runtime deps stay external (bare specifiers).
    // clean: false — the tsc -p tsconfig.build.json pass writes lib/types/*.d.ts
    // FIRST in the build script, and tsdown's default clean would wipe them.
    entry: { index: 'src/index.ts' },
    outDir: 'lib',
    format: 'esm',
    dts: false, // d.ts come from tsc -p tsconfig.build.json
    platform: 'node',
    unbundle: false,
    clean: false,
    // Inline the guide content (zh + en) at build time so the host route
    // doesn't need to resolve filesystem paths at runtime (avoids
    // import.meta.url issues after bundling and works regardless of install
    // location). The browser locale picks which variant the route serves.
    define: {
      __GUIDE_CONTENT__: JSON.stringify(await readFile('GUIDE.zh.md', 'utf-8')),
      __GUIDE_EN_CONTENT__: JSON.stringify(await readFile('GUIDE.md', 'utf-8')),
    },
  },
  {
    // Browser half: a closure-factory bundle consumed by the dsh web shell's
    // ModuleLoader. Emits window.__ModuleLoader__.load({ id, factory: (require) => ... })
    // and resolves the platform externals through the injected require (the frozen
    // module table — react / react-dom / react/jsx-runtime). CSS Modules are compiled
    // by lightningcss inside the bundle. This mirrors how dsh-ssh / dsh-context /
    // dsh-better-sidebar build their client.js (and the official tsdown.client.ts).
    name: 'dsh-wigolo/client',
    entry: { client: 'src/client/index.ts' },
    outDir: 'lib',
    format: 'cjs',
    platform: 'browser',
    dts: false, // types ship from lib/types (tsc)
    clean: false,
    minify: false,
    deps: {
      // Exactly the module-table entries stay external (resolved through the
      // require injected by __ModuleLoader__.load); everything else bundles.
      neverBundle: [...CLIENT_EXTERNALS],
      alwaysBundle: (id: string) => !CLIENT_EXTERNALS.includes(id),
    },
    // Browser bundles inline node-idiom deps (zustand/immer read
    // process.env.NODE_ENV; zustand's esm build also probes import.meta.env.MODE).
    // Harmless to define for safety, matching the official preset.
    // __WIGOLO_VERSION__ feeds the About tab from package.json at build time.
    define: {
      'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
      'import.meta.env.MODE': JSON.stringify(process.env.NODE_ENV ?? 'production'),
      'import.meta.env': JSON.stringify({ MODE: process.env.NODE_ENV ?? 'production' }),
      __WIGOLO_VERSION__: JSON.stringify(pkg.version),
    },
    plugins: [{
      name: 'dsh-wigolo-css-modules-inline',
      resolveId(source: string, importer: string | undefined) {
        if (!source.endsWith('.module.css')) return null
        const abs = importer !== undefined ? resolvePath(dirname(importer), source) : source
        return CSS_VIRTUAL_PREFIX + abs + CSS_VIRTUAL_SUFFIX
      },
      async load(virtualId: string) {
        if (!virtualId.startsWith(CSS_VIRTUAL_PREFIX)) return null
        const fileId = virtualId.slice(CSS_VIRTUAL_PREFIX.length, -CSS_VIRTUAL_SUFFIX.length)
        const source = await readFile(fileId)
        const { code, exports: cssExports } = transform({
          filename: fileId,
          code: source,
          cssModules: { pattern: '[hash]_[local]' },
          minify: true,
        })
        const classMap: Record<string, string> = {}
        if (cssExports) {
          for (const [local, exp] of Object.entries(cssExports)) classMap[local] = exp.name
        }
        // Sort classMap keys for deterministic build output
        const sortedClassMap = Object.fromEntries(
          Object.entries(classMap).sort(([a], [b]) => a.localeCompare(b))
        )
        // One <style data-plugin> per module file; idempotent under re-evaluation.
        return [
          `const css = ${JSON.stringify(code.toString())};`,
          `const tagId = ${JSON.stringify(`dsh-wigolo/${basename(fileId)}`)};`,
          `if (typeof document !== 'undefined' && document.querySelector('style[data-plugin-css=' + JSON.stringify(tagId) + ']') === null) {`,
          `  const tag = document.createElement('style');`,
          `  tag.dataset.plugin = ${JSON.stringify('@tianjiqx/dsh-wigolo')};`,
          `  tag.dataset.pluginCss = tagId;`,
          `  tag.textContent = css;`,
          `  document.head.appendChild(tag);`,
          `}`,
          `export default ${JSON.stringify(sortedClassMap)};`,
        ].join('\n')
      },
    }],
    outputOptions: {
      entryFileNames: 'client.js',
      banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify('@tianjiqx/dsh-wigolo')}, factory: (require) => {`,
      footer: 'return module.exports; } });',
      intro: 'var module = { exports: {} }; var exports = module.exports;',
    },
  },
])
