import { describe, expect, it, vi } from 'vitest'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { ConfigStore } from '../src/store.ts'
import { PanelController } from '../src/client/controller.ts'

describe('PanelController', () => {
  it('notifies subscribers on toggle and cleans up on unsubscribe', () => {
    const controller = new PanelController()
    const listener = vi.fn()
    const unsubscribe = controller.subscribe(listener)
    expect(controller.getSnapshot().panelOpen).toBe(false)

    controller.openPanel()
    expect(listener).toHaveBeenCalledTimes(1)
    expect(controller.getSnapshot().panelOpen).toBe(true)

    controller.toggle() // closes
    expect(controller.getSnapshot().panelOpen).toBe(false)

    unsubscribe()
    controller.toggle()
    expect(listener).toHaveBeenCalledTimes(2) // not called after unsubscribe
  })
})

describe('ConfigStore panel flows', () => {
  it('summarize() hides the token but reports its presence', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-wigolo-panel-'))
    const store = new ConfigStore(join(dir, 'wigolo.json'))
    store.update((c) => ({ ...c, connection: { ...c.connection, tokenFile: join(dir, 'token') } }))
    store.writeToken('sekrit-token-value')

    const summary = store.summarize()
    expect(summary.hasToken).toBe(true)
    expect(JSON.stringify(summary)).not.toContain('sekrit-token-value')
  })

  it('takeover transitions persist through update()', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-wigolo-takeover-'))
    const store = new ConfigStore(join(dir, 'wigolo.json'))
    
    // Test false -> true
    store.update((c) => ({ ...c, takeover: true }))
    expect(new ConfigStore(join(dir, 'wigolo.json')).load().takeover).toBe(true)
    
    // Test true -> false
    store.update((c) => ({ ...c, takeover: false }))
    expect(new ConfigStore(join(dir, 'wigolo.json')).load().takeover).toBe(false)
  })

  it('tool exposure flags round-trip', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-wigolo-tools-'))
    const store = new ConfigStore(join(dir, 'wigolo.json'))
    store.update((c) => ({ ...c, tools: { ...c.tools, wigolo_research: { enabled: false } } }))
    const reloaded = new ConfigStore(join(dir, 'wigolo.json')).load()
    expect(reloaded.tools.wigolo_research.enabled).toBe(false)
    expect(reloaded.tools.wigolo_search.enabled).toBe(true) // untouched default
  })
})
