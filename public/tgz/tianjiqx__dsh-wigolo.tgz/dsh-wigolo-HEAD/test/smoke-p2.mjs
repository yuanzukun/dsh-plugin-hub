/**
 * P2 smoke: run wigolo_search + wigolo_extract + wigolo_watch(list) through
 * the REAL tool definitions (via tsx-style strip-types import) against the
 * real daemon. Manual run: npx tsx test/smoke-p2.ts (or vitest -t smoke with
 * WIGOLO_SMOKE=1 if added to a suite).
 */
import http from 'node:http'
import { existsSync, readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const HOST = process.env.WIGOLO_HOST_IP || '192.168.2.100'
const PORT = Number(process.env.WIGOLO_PORT || 3333)
const tokenPath = join(homedir(), '.dsh', 'wigolo-token')
if (!existsSync(tokenPath)) { console.error('no token file'); process.exit(1) }
const token = readFileSync(tokenPath, 'utf8').split('\n')[0].trim()

function post(body, sessionId) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body)
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json, text/event-stream',
      'Authorization': 'Bearer ' + token,
      'Host': '0.0.0.0',
      'Content-Length': Buffer.byteLength(payload),
    }
    if (sessionId) headers['Mcp-Session-Id'] = sessionId
    const req = http.request({ host: HOST, port: PORT, path: '/mcp', method: 'POST', headers }, (res) => {
      const sid = res.headers['mcp-session-id']
      let text = ''
      res.on('data', c => { text += c })
      res.on('end', () => resolve({ sid, text, status: res.statusCode }))
    })
    req.on('error', reject)
    req.setTimeout(60_000, () => req.destroy(new Error('timeout')))
    req.end(payload)
  })
}

function parse(text) {
  for (const line of text.split('\n')) {
    if (line.startsWith('data: ')) return JSON.parse(line.slice(6))
  }
  return text.trim() === '' ? null : JSON.parse(text)
}

// session
const init = await post({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'dsh-wigolo', version: '1.0.0' } } }, null)
await post({ jsonrpc: '2.0', method: 'notifications/initialized' }, init.sid)

async function callTool(name, args) {
  const resp = await post({ jsonrpc: '2.0', id: Math.floor(Math.random() * 1e6), method: 'tools/call', params: { name, arguments: args } }, init.sid)
  const frame = parse(resp.text)
  if (frame?.error) throw new Error(frame.error.message)
  for (const c of frame?.result?.content ?? []) {
    if (c.type === 'text') {
      try { return JSON.parse(c.text) } catch { return { text: c.text } }
    }
  }
  return frame?.result ?? {}
}

// 1) search — the wigolo_search tool's trimmed surface
const search = await callTool('search', { query: 'dsh-wigolo smoke test', max_results: 3 })
console.log('[search]   results:', (search.results ?? []).length, ' engines:', (search.engines_used ?? []).slice(0, 4).join(','))

// 2) extract — structured extraction on a stable page
const extract = await callTool('extract', { url: 'https://example.com', css_selector: 'h1', multiple: false })
console.log('[extract]  keys:', Object.keys(extract).slice(0, 5).join(','))

// 3) watch list
const watch = await callTool('watch', { action: 'list' })
console.log('[watch]    keys:', Object.keys(watch).slice(0, 5).join(','), ' jobs:', Array.isArray(watch.jobs) ? watch.jobs.length : 'n/a')

// 4) cache query (read-only)
const cache = await callTool('cache', { query: 'wigolo', limit: 3 })
console.log('[cache]    keys:', Object.keys(cache).slice(0, 5).join(','))

console.log('P2 SMOKE OK')
