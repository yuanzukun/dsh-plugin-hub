/**
 * Smoke test against the REAL wigolo daemon (192.168.2.100:3333).
 * Not part of vitest (no daemon in CI); run manually:
 *   node test/smoke-real-daemon.mjs
 */
import http from 'node:http'
import { existsSync, readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const HOST = process.env.WIGOLO_HOST_IP || '192.168.2.100'
const PORT = Number(process.env.WIGOLO_PORT || 3333)
const tokenPath = join(homedir(), '.dsh', 'wigolo-token')
if (!existsSync(tokenPath)) {
  console.error('no token file at', tokenPath)
  process.exit(1)
}
const token = readFileSync(tokenPath, 'utf8').split('\n')[0].trim()

function post(body, sessionId) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body)
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json, text/event-stream',
      'Authorization': 'Bearer ' + token,
      'Host': '0.0.0.0',
      'Content-Length': Buffer.byteLength(payload),
    }
    if (sessionId) headers['Mcp-Session-Id'] = sessionId
    const req = http.request({ host: HOST, port: PORT, path: '/mcp', method: 'POST', headers }, (res) => {
      const sid = res.headers['mcp-session-id']
      let text = ''
      res.on('data', c => { text += c })
      res.on('end', () => resolve({ sid, text, status: res.statusCode }))
    })
    req.on('error', reject)
    req.setTimeout(20000, () => req.destroy(new Error('timeout')))
    req.end(payload)
  })
}

function parse(text) {
  for (const line of text.split('\n')) {
    if (line.startsWith('data: ')) return JSON.parse(line.slice(6))
  }
  return text.trim() === '' ? null : JSON.parse(text)
}

// 1) probe (initialize) — mirrors WigoloMcpClient.probe()
const started = Date.now()
const init = await post({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'dsh-wigolo', version: '1.0.0' } } }, null)
const initFrame = parse(init.text)
console.log('[probe]  status:', init.status, ' latency:', Date.now() - started, 'ms', ' server:', initFrame?.result?.serverInfo?.version ?? '?')

// 2) initialized notification
await post({ jsonrpc: '2.0', method: 'notifications/initialized' }, init.sid)

// 3) tools/list — confirm the 10 expected tools
const list = await post({ jsonrpc: '2.0', id: 2, method: 'tools/list', params: {} }, init.sid)
const tools = parse(list.text)?.result?.tools ?? []
console.log('[tools]  count:', tools.length, ' names:', tools.map(t => t.name).join(', '))

// 4) cache stats — the panel's Cache tab surface
const stats = await post({ jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'cache', arguments: { stats: true } } }, init.sid)
const statsText = parse(stats.text)?.result?.content?.[0]?.text ?? ''
console.log('[cache]  status:', stats.status, ' payload head:', String(statsText).slice(0, 120).replace(/\n/g, ' '))

console.log('SMOKE OK')
