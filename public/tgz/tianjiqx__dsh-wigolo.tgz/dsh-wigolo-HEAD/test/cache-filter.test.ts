import { describe, expect, it, vi } from 'vitest'
import { filterCacheEntries, parseFetchedMs, timeRangeToSinceMs } from '../src/client/cache-filter.ts'
import type { CacheEntryRow } from '../src/protocol.ts'

const rows: CacheEntryRow[] = [
  { url: 'https://github.com/trending', title: 'GitHub Trending', fetched_at: '2026-08-18 05:00:00' },
  { url: 'https://blog.example/doc', title: 'DuckDB Deep Dive', fetched_at: '2026-08-17 12:00:00' },
  { url: 'https://news.site/page', title: '', fetched_at: '' },
]

describe('filterCacheEntries (docs/CACHE-TAB.md §3 front-end filtering)', () => {
  it('keeps everything for an empty query and no time floor', () => {
    expect(filterCacheEntries(rows, { query: '', sinceMs: 0 })).toHaveLength(3)
  })

  it('matches keyword against URL or title (case-insensitive)', () => {
    const byTitle = filterCacheEntries(rows, { query: 'duckdb', sinceMs: 0 })
    expect(byTitle).toHaveLength(1)
    expect(byTitle[0].url).toBe('https://blog.example/doc')
    const byUrl = filterCacheEntries(rows, { query: 'GITHUB', sinceMs: 0 })
    expect(byUrl).toHaveLength(1)
    expect(byUrl[0].url).toBe('https://github.com/trending')
  })

  it('applies a time floor (this-session filter)', () => {
    const since = parseFetchedMs('2026-08-18 00:00:00')
    const out = filterCacheEntries(rows, { query: '', sinceMs: since })
    expect(out.map((r) => r.url)).toEqual(['https://github.com/trending'])
  })

  it('rows without a parseable fetched_at survive an empty sinceMs check', () => {
    const out = filterCacheEntries(rows, { query: '', sinceMs: 0 })
    expect(out.some((r) => r.fetched_at === '')).toBe(true)
  })

  it('applies a time ceiling in the session range (untilMs)', () => {
    const since = parseFetchedMs('2026-08-18 00:00:00')
    const until = parseFetchedMs('2026-08-18 06:00:00')
    // session range: [createdAt, last turn end] — entries after the session's
    // active period (post-dormancy noise from other clients) are excluded.
    const out = filterCacheEntries(rows, { query: '', sinceMs: since, untilMs: until, timeRange: 'session' })
    expect(out.map((r) => r.url)).toEqual(['https://github.com/trending'])
    // untilMs is ignored outside the session range.
    const notSession = filterCacheEntries(rows, { query: '', sinceMs: 0, untilMs: until, timeRange: 'all' })
    expect(notSession.length).toBe(rows.length)
  })

  it('ignores untilMs when no floor is set (anchor not yet loaded)', () => {
    const until = parseFetchedMs('2026-08-18 06:00:00')
    const out = filterCacheEntries(rows, { query: '', sinceMs: 0, untilMs: until, timeRange: 'session' })
    expect(out.length).toBe(rows.length)
  })

  it('a time floor drops unparseable/empty fetched_at entries', () => {
    const since = parseFetchedMs('2026-08-17 00:00:00')
    const out = filterCacheEntries(rows, { query: '', sinceMs: since })
    expect(out.every((r) => r.fetched_at !== '')).toBe(true)
  })
})

describe('parseFetchedMs', () => {
  it('handles empty and the daemon "YYYY-MM-DD HH:mm:ss" format', () => {
    expect(parseFetchedMs('')).toBe(0)
    expect(parseFetchedMs('2026-08-18 05:00:00')).toBeGreaterThan(0)
  })
})

describe('timeRangeToSinceMs', () => {
  it('returns 0 for "all" and "session"', () => {
    expect(timeRangeToSinceMs('all')).toBe(0)
    expect(timeRangeToSinceMs('session')).toBe(0)
  })

  it('returns today midnight for "today"', () => {
    const ms = timeRangeToSinceMs('today')
    const d = new Date(ms)
    expect(d.getHours()).toBe(0)
    expect(d.getMinutes()).toBe(0)
  })

  it('returns ~7 days ago for "7d"', () => {
    const before = Date.now()
    const ms = timeRangeToSinceMs('7d')
    const diff = before - ms
    expect(diff).toBeGreaterThanOrEqual(7 * 24 * 60 * 60 * 1000 - 100)
    expect(diff).toBeLessThan(7 * 24 * 60 * 60 * 1000 + 100)
  })

  it('returns ~30 days ago for "30d"', () => {
    const before = Date.now()
    const ms = timeRangeToSinceMs('30d')
    const diff = before - ms
    expect(diff).toBeGreaterThanOrEqual(30 * 24 * 60 * 60 * 1000 - 100)
    expect(diff).toBeLessThan(30 * 24 * 60 * 60 * 1000 + 100)
  })
})

describe('filterCacheEntries with timeRange', () => {
  const recentRows: CacheEntryRow[] = [
    { url: 'https://a.com', title: 'A', fetched_at: '2026-08-18 10:00:00' },
    { url: 'https://b.com', title: 'B', fetched_at: '2026-08-15 10:00:00' },
    { url: 'https://c.com', title: 'C', fetched_at: '2026-07-01 10:00:00' },
  ]

  it('"all" keeps everything', () => {
    const out = filterCacheEntries(recentRows, { query: '', sinceMs: 0, timeRange: 'all' })
    expect(out).toHaveLength(3)
  })

  it('"7d" keeps only entries from the last 7 days', () => {
    // Mock Date.now to 2026-08-18 12:00:00
    const mockNow = new Date('2026-08-18T12:00:00').getTime()
    vi.spyOn(Date, 'now').mockReturnValue(mockNow)
    const out = filterCacheEntries(recentRows, { query: '', sinceMs: 0, timeRange: '7d' })
    expect(out.map(r => r.url)).toEqual(['https://a.com', 'https://b.com'])
    vi.restoreAllMocks()
  })

  it('"30d" keeps entries from the last 30 days', () => {
    const mockNow = new Date('2026-08-18T12:00:00').getTime()
    vi.spyOn(Date, 'now').mockReturnValue(mockNow)
    // c.com (2026-07-01) is 48 days ago, outside 30d window
    const out = filterCacheEntries(recentRows, { query: '', sinceMs: 0, timeRange: '30d' })
    expect(out.map(r => r.url)).toEqual(['https://a.com', 'https://b.com'])
    vi.restoreAllMocks()
  })

  it('sinceMs takes precedence over timeRange', () => {
    const since = parseFetchedMs('2026-08-17 00:00:00')
    // b.com (2026-08-15) is before the since floor, only a.com passes
    const out = filterCacheEntries(recentRows, { query: '', sinceMs: since, timeRange: '30d' })
    expect(out.map(r => r.url)).toEqual(['https://a.com'])
  })
})
