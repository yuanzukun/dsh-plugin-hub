import { describe, expect, it } from 'vitest'
import { mkdtempSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { ConfigStore } from '../src/store.ts'
import { applyLegacyImport, defaultConfig, detectLegacySetup, resolveHostHeaderFromConfig, validateTakeover } from '../src/config.ts'
import { insertManagedBlock, stripManagedBlock, readManagedTakeover, hasManagedBlock } from '../src/cordis-managed.ts'

function tmp(): string {
  return mkdtempSync(join(tmpdir(), 'dsh-wigolo-test-'))
}

describe('ConfigStore', () => {
  it('creates the stock config on first run', () => {
    const dir = tmp()
    const store = new ConfigStore(join(dir, 'wigolo.json'))
    const config = store.load()
    expect(config.version).toBe(2)
    expect(config.connection.host).toBe('127.0.0.1')
    expect(config.connection.port).toBe(3333)
    expect(config.takeover).toBe(false)
    expect(existsSync(join(dir, 'wigolo.json'))).toBe(true)
  })

  it('round-trips updates atomically', () => {
    const dir = tmp()
    const store = new ConfigStore(join(dir, 'wigolo.json'))
    store.update((c) => ({ ...c, connection: { ...c.connection, host: '192.168.2.100' } }))
    const reloaded = new ConfigStore(join(dir, 'wigolo.json')).load()
    expect(reloaded.connection.host).toBe('192.168.2.100')
  })

  it('falls back to defaults on a corrupt file', () => {
    const dir = tmp()
    const path = join(dir, 'wigolo.json')
    writeFileSync(path, 'NOT JSON')
    const store = new ConfigStore(path)
    expect(store.load().connection.port).toBe(3333)
  })

  it('never persists the token in the config file', () => {
    const dir = tmp()
    const store = new ConfigStore(join(dir, 'wigolo.json'))
    store.update((c) => ({ ...c, connection: { ...c.connection, tokenFile: join(dir, 'token') } }))
    store.writeToken('sekrit')
    const raw = readFileSync(join(dir, 'wigolo.json'), 'utf8')
    expect(raw).not.toContain('sekrit')
    expect(readFileSync(join(dir, 'token'), 'utf8').trim()).toBe('sekrit')
    expect(store.readToken()).toBe('sekrit')
  })
})

describe('legacy migration', () => {
  it('detects env-based legacy setup', () => {
    const legacy = detectLegacySetup({ WIGOLO_HOST_IP: '192.168.2.100', WIGOLO_PORT: '3333' } as NodeJS.ProcessEnv, () => false)
    expect(legacy?.host).toBe('192.168.2.100')
    expect(legacy?.port).toBe(3333)
  })

  it('imports host/port into the fresh config', () => {
    const config = applyLegacyImport(defaultConfig(), { host: '192.168.2.100', port: 3333, hasTokenFile: true })
    expect(config.connection.host).toBe('192.168.2.100')
    expect(config.connection.port).toBe(3333)
  })

  it('returns undefined when nothing to import', () => {
    expect(detectLegacySetup({}, () => false)).toBeUndefined()
  })
})

describe('hostHeader resolution', () => {
  it('auto + localhost sends no custom header', () => {
    expect(resolveHostHeaderFromConfig({ host: 'localhost', hostHeader: 'auto' })).toBeUndefined()
    expect(resolveHostHeaderFromConfig({ host: '127.0.0.1', hostHeader: 'auto' })).toBeUndefined()
  })

  it('auto + remote host uses the bind-host trick', () => {
    expect(resolveHostHeaderFromConfig({ host: '192.168.2.100', hostHeader: 'auto' })).toBe('0.0.0.0')
  })

  it('none never sends a custom header', () => {
    expect(resolveHostHeaderFromConfig({ host: '192.168.2.100', hostHeader: 'none' })).toBeUndefined()
  })

  it('literal custom value passes through', () => {
    expect(resolveHostHeaderFromConfig({ host: 'example.com', hostHeader: 'my.lan.host' })).toBe('my.lan.host')
  })
})

describe('cordis managed block', () => {
  const EXISTING = ['- id: something', '  config: {}', ''].join('\n')

  it('inserts a takeover block when enabled', () => {
    const out = insertManagedBlock(EXISTING, true)
    expect(out).toContain('searchProvider: wigolo')
    expect(out).toContain('fetchProvider: wigolo')
    expect(readManagedTakeover(out)).toBe(true)
    // existing entries preserved
    expect(out).toContain('- id: something')
  })

  it('strips the block when disabled', () => {
    const withBlock = insertManagedBlock(EXISTING, true)
    expect(hasManagedBlock(withBlock)).toBe(true)
    const stripped = insertManagedBlock(withBlock, false)
    expect(hasManagedBlock(stripped)).toBe(false)
    expect(stripped).toContain('- id: something')
  })

  it('round-trips: insert then strip then re-insert', () => {
    const once = insertManagedBlock(EXISTING, true)
    const twice = insertManagedBlock(once, false)
    const thrice = insertManagedBlock(twice, true)
    expect(readManagedTakeover(thrice)).toBe(true)
    expect((thrice.match(/dsh-wigolo managed/g) ?? []).length).toBe(2) // begin+end markers only once
  })

  it('validates takeover values', () => {
    expect(validateTakeover(true)).toBeUndefined()
    expect(validateTakeover(false)).toBeUndefined()
    expect(validateTakeover('nope')).toBeDefined()
  })
})
