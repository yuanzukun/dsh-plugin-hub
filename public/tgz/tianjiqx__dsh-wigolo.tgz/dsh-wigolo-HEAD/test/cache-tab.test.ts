import { describe, expect, it } from 'vitest'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { ConfigStore } from '../src/store.ts'
import { makeRoutes } from '../src/routes.ts'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import { WIGOLO_API, type CacheEntryRow } from '../src/protocol.ts'
import type { WigoloMcpClient } from '../src/mcp-client.ts'

/** Fake MCP client capturing cache/watch calls with canned payloads. */
function fakeClient(payloads: Record<string, Record<string, unknown>> = {}): WigoloMcpClient & { calls: Array<{ name: string; args: Record<string, unknown> }> } {
  const calls: Array<{ name: string; args: Record<string, unknown> }> = []
  return {
    calls,
    settings: { host: 'x', port: 1, hostHeader: '' },
    async callTool(name: string, args: Record<string, unknown>) { calls.push({ name, args }); return payloads[name] ?? {} },
    async callToolObject(name: string, args: Record<string, unknown>) { calls.push({ name, args }); return payloads[name] ?? {} },
    async probe() { return { ok: true, latencyMs: 1 } },
    reconfigure() { /* no-op in tests */ },
  } as unknown as WigoloMcpClient & { calls: Array<{ name: string; args: Record<string, unknown> }> }
}

/** Minimal loopback-looking req/res pair invoking one WebRoute handler. */
async function callRoute(route: WebRoute, reqInit: { method: string; url?: string; body?: unknown }): Promise<{ status: number; body: Record<string, unknown> }> {
  let status = 0
  let body: Record<string, unknown> = {}
  const chunks: Buffer[] = reqInit.body !== undefined ? [Buffer.from(JSON.stringify(reqInit.body))] : []
  const req = {
    method: reqInit.method,
    url: reqInit.url ?? WIGOLO_API.cacheTabList,
    headers: { host: '127.0.0.1:3080' },
    socket: { remoteAddress: '127.0.0.1' },
    async *[Symbol.asyncIterator]() { for (const c of chunks) yield c },
  }
  const res = {
    writeHead(s: number) { status = s },
    end(payload: string) { try { body = JSON.parse(payload) } catch { body = {} } },
  }
  await route.handler(req as never, res as never)
  return { status, body }
}

function storeWith(cacheTabEnabled: boolean): ConfigStore {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-wigolo-cache-tab-'))
  const store = new ConfigStore(join(dir, 'wigolo.json'))
  // Pin timezone to UTC+0 so fetched_at conversion is the identity — the test
  // asserts raw daemon timestamps and must not depend on the host's timezone.
  store.update((c) => ({ ...c, timezone: '+0' }))
  if (cacheTabEnabled) store.update((c) => ({ ...c, cacheTab: { enabled: true } }))
  return store
}

describe('cache tab routes (docs/CACHE-TAB.md §7)', () => {
  it('403s when the module is off', async () => {
    const client = fakeClient()
    const routes = makeRoutes({ store: storeWith(false), client })
    const listRoute = routes.find((r) => r.kind === 'exact' && r.path === WIGOLO_API.cacheTabList)!
    const { status, body } = await callRoute(listRoute, { method: 'GET' })
    expect(status).toBe(403)
    expect(body.error).toBe('cache tab disabled')
    expect(client.calls.length).toBe(0)
  })

  it('lists metadata with markdown stripped', async () => {
    const client = fakeClient({
      cache: {
        results: [
          { url: 'https://a', title: 'A', fetched_at: '2026-08-18 05:00:00', markdown: '# huge body' },
          { url: 'https://b', title: 'B', fetched_at: '2026-08-18 04:00:00' },
        ],
      },
    })
    const routes = makeRoutes({ store: storeWith(true), client })
    const listRoute = routes.find((r) => r.kind === 'exact' && r.path === WIGOLO_API.cacheTabList)!
    const { status, body } = await callRoute(listRoute, { method: 'GET', url: WIGOLO_API.cacheTabList + '?limit=2' })
    expect(status).toBe(200)
    const entries = body.entries as CacheEntryRow[]
    expect(entries).toHaveLength(2)
    expect(entries[0]).toEqual({ url: 'https://a', title: 'A', fetched_at: '2026-08-18 05:00:00' })
    expect(JSON.stringify(body)).not.toContain('huge body')
    expect(client.calls[0].args.limit).toBe(2)
  })

  it('entry returns markdown for an exact URL and 404s on a miss', async () => {
    const client = fakeClient({
      cache: { results: [{ url: 'https://a', markdown: '# content', fetched_at: 't' }] },
    })
    const routes = makeRoutes({ store: storeWith(true), client })
    const entryRoute = routes.find((r) => r.kind === 'exact' && r.path === WIGOLO_API.cacheTabEntry)!
    const hit = await callRoute(entryRoute, { method: 'GET', url: WIGOLO_API.cacheTabEntry + '?url=' + encodeURIComponent('https://a') })
    expect(hit.status).toBe(200)
    expect(hit.body.markdown).toBe('# content')
    expect(client.calls[0].args.url_pattern).toBe('https://a')

    const missClient = fakeClient({ cache: { results: [] } })
    const missRoutes = makeRoutes({ store: storeWith(true), client: missClient })
    const missRoute = missRoutes.find((r) => r.kind === 'exact' && r.path === WIGOLO_API.cacheTabEntry)!
    const miss = await callRoute(missRoute, { method: 'GET', url: WIGOLO_API.cacheTabEntry + '?url=' + encodeURIComponent('https://x') })
    expect(miss.status).toBe(404)
  })

  it('session route returns header.createdAt for a live session and 404 otherwise', async () => {
    const client = fakeClient()
    const routes = makeRoutes({ store: storeWith(true), client, getSessionCreatedAt: (id) => (id === 'session-1' ? 1737300000000 : undefined) })
    const sessionRoute = routes.find((r) => r.kind === 'exact' && r.path === WIGOLO_API.cacheTabSession)!

    const hit = await callRoute(sessionRoute, { method: 'GET', url: WIGOLO_API.cacheTabSession + '?sessionId=session-1' })
    expect(hit.status).toBe(200)
    expect(hit.body).toEqual({ sessionId: 'session-1', createdAt: 1737300000000 })

    const miss = await callRoute(sessionRoute, { method: 'GET', url: WIGOLO_API.cacheTabSession + '?sessionId=session-9' })
    expect(miss.status).toBe(404)

    const noParam = await callRoute(sessionRoute, { method: 'GET', url: WIGOLO_API.cacheTabSession })
    expect(noParam.status).toBe(400)
  })

  it('watch GET humanizes and POST only allows check/pause/resume', async () => {
    const client = fakeClient({ watch: { jobs: [{ id: 'j1', url: 'https://a', interval_seconds: 3600, status: 'active', staleness_seconds: -600 }] } })
    const routes = makeRoutes({ store: storeWith(true), client })
    const watchRoute = routes.find((r) => r.kind === 'exact' && r.path === WIGOLO_API.cacheTabWatch)!

    const list = await callRoute(watchRoute, { method: 'GET' })
    expect(list.status).toBe(200)
    expect((list.body.jobs as Array<{ next_check_in: string }>)[0].next_check_in).toContain('until next check')

    const bad = await callRoute(watchRoute, { method: 'POST', body: { action: 'delete', job_id: 'j1' } })
    expect(bad.status).toBe(400)

    const ok = await callRoute(watchRoute, { method: 'POST', body: { action: 'pause', job_id: 'j1' } })
    expect(ok.status).toBe(200)
    expect(client.calls[client.calls.length - 1].args).toEqual({ action: 'pause', job_id: 'j1' })
  })
})

describe('cacheTab config (docs/CACHE-TAB.md §5)', () => {
  it('defaults off and round-trips the toggle', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-wigolo-cache-tab-cfg-'))
    const store = new ConfigStore(join(dir, 'wigolo.json'))
    expect(store.load().cacheTab.enabled).toBe(false)
    store.update((c) => ({ ...c, cacheTab: { enabled: true } }))
    expect(new ConfigStore(join(dir, 'wigolo.json')).load().cacheTab.enabled).toBe(true)
  })

  it('config PUT accepts a cacheTab boolean', async () => {
    const client = fakeClient()
    const store = storeWith(false)
    const routes = makeRoutes({ store, client })
    const configRoute = routes.find((r) => r.kind === 'exact' && r.path === WIGOLO_API.config)!
    const res = await callRoute(configRoute, { method: 'PUT', body: { cacheTab: true } })
    expect(res.status).toBe(200)
    expect(store.load().cacheTab.enabled).toBe(true)
    const bad = await callRoute(configRoute, { method: 'PUT', body: { cacheTab: 'yes' } })
    expect(bad.status).toBe(400)
  })
})
