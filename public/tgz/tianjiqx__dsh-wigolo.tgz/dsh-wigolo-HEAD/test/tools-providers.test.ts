import { describe, expect, it } from 'vitest'
import { buildAllTools } from '../src/tools.ts'
import { toSearchResult, toFetchResult, WigoloSearchProvider, WigoloFetchProvider } from '../src/providers.ts'
import type { WigoloMcpClient } from '../src/mcp-client.ts'
import type { ToolConfig } from '../src/protocol.ts'

/** Minimal fake ToolRunContext (the wigolo tools never touch it). */
const fakeExec = { signal: new AbortController().signal } as never

/** Recording fake client: captures tool calls, returns canned payloads. */
function fakeClient(payloads: Record<string, Record<string, unknown>> = {}): WigoloMcpClient & { calls: Array<{ name: string; args: Record<string, unknown> }> } {
  const calls: Array<{ name: string; args: Record<string, unknown> }> = []
  const client = {
    calls,
    settings: { host: 'x', port: 1, hostHeader: '' },
    async callTool(name: string, args: Record<string, unknown>) {
      calls.push({ name, args })
      return payloads[name] ?? {}
    },
    async callToolObject(name: string, args: Record<string, unknown>) {
      calls.push({ name, args })
      return payloads[name] ?? {}
    },
    async probe() { return { ok: true, latencyMs: 1 } },
  } as unknown as WigoloMcpClient & { calls: Array<{ name: string; args: Record<string, unknown> }> }
  return client
}

describe('tool parameter mapping', () => {
  it('search: splits multi-variant queries and clamps max_results', async () => {
    const client = fakeClient({ search: { results: [] } })
    const tool = buildAllTools(client, { wigolo_search: { enabled: true } })[0]
    expect(tool.name).toBe('wigolo_search')
    await tool.execute({ query: 'rust async | tokio', max_results: 99 }, fakeExec)
    expect(client.calls[0].name).toBe('search')
    expect(client.calls[0].args.query).toEqual(['rust async', 'tokio'])
    expect(client.calls[0].args.max_results).toBe(20)
  })

  it('search: config defaults merge under model args', async () => {
    const client = fakeClient({ search: { results: [] } })
    const tool = buildAllTools(client, { wigolo_search: { enabled: true, defaults: { max_results: 5, search_depth: 'deep' } } })[0]
    await tool.execute({ query: 'plain' }, fakeExec)
    expect(client.calls[0].args.max_results).toBe(5)
    expect(client.calls[0].args.search_depth).toBe('deep')
  })

  it('search: model args override defaults', async () => {
    const client = fakeClient({ search: { results: [] } })
    const tool = buildAllTools(client, { wigolo_search: { enabled: true, defaults: { max_results: 5 } } })[0]
    await tool.execute({ query: 'plain', max_results: 8 }, fakeExec)
    expect(client.calls[0].args.max_results).toBe(8)
  })

  it('search: maps the payload to scored sources', async () => {
    const client = fakeClient({
      search: {
        results: [
          { url: 'https://a', title: 'A', snippet: 'sa', relevance_score: 0.91234, published_date: '2025-01-02T03:04:05Z' },
          { url: '', title: 'dropped' },
        ],
        engines_used: ['google', 'bing'],
        total_time_ms: 120,
      },
    })
    const tool = buildAllTools(client, { wigolo_search: { enabled: true } })[0]
    const out = await tool.execute({ query: 'q' }, fakeExec) as never as { sources: Array<{ url: string; score: number }>; engines_used?: string[] }
    expect(out.sources).toHaveLength(1)
    expect(out.sources[0].url).toBe('https://a')
    expect(out.sources[0].score).toBe(0.912)
    expect(out.engines_used).toEqual(['google', 'bing'])
  })

  it('crawl: forwards trimmed args', async () => {
    const client = fakeClient({ crawl: { pages: [] } })
    const tools = buildAllTools(client, { wigolo_crawl: { enabled: true } })
    const crawl = tools.find(t => t.name === 'wigolo_crawl')!
    await crawl.execute({ url: 'https://docs', max_pages: 999, max_depth: 9, strategy: 'bfs', include_patterns: ['/docs/'] }, fakeExec)
    expect(client.calls[0].args).toEqual({
      url: 'https://docs', max_pages: 500, max_depth: 5, strategy: 'bfs', include_patterns: ['/docs/'],
    })
  })

  it('extract: passes schema object through', async () => {
    const client = fakeClient({ extract: { data: {} } })
    const tools = buildAllTools(client, { wigolo_extract: { enabled: true } })
    const extract = tools.find(t => t.name === 'wigolo_extract')!
    await extract.execute({ url: 'https://x', css_selector: 'table', schema: { price: '.price' }, multiple: true }, fakeExec)
    expect(client.calls[0].args.schema).toEqual({ price: '.price' })
    expect(client.calls[0].args.multiple).toBe(true)
  })

  it('research: clips the report and returns raw payload', async () => {
    const long = 'x'.repeat(40_000)
    const client = fakeClient({ research: { report: long } })
    const tools = buildAllTools(client, { wigolo_research: { enabled: true } })
    const research = tools.find(t => t.name === 'wigolo_research')!
    const out = await research.execute({ question: 'q?' }, fakeExec) as { report: string; raw: Record<string, unknown> }
    expect(out.report.length).toBeLessThan(31_000)
    expect(out.report).toContain('truncated')
    expect(out.raw.report).toBe(long)
  })

  it('cache: stats and clear flags forward verbatim', async () => {
    const client = fakeClient({ cache: { stats: { total_urls: 1 } } })
    const tools = buildAllTools(client, { wigolo_cache: { enabled: true } })
    const cache = tools.find(t => t.name === 'wigolo_cache')!
    await cache.execute({ stats: true }, fakeExec)
    expect(client.calls[0].args.stats).toBe(true)
  })

  it('watch: forwards action args', async () => {
    const client = fakeClient({ watch: { jobs: [] } })
    const tools = buildAllTools(client, { wigolo_watch: { enabled: true } })
    const watch = tools.find(t => t.name === 'wigolo_watch')!
    await watch.execute({ action: 'add', url: 'https://x', interval_seconds: 30 }, fakeExec)
    // interval clamps to the politeness floor (60)
    expect(client.calls[0].args.interval_seconds).toBe(60)
  })

  it('timeouts come from config with sane fallbacks', () => {
    const client = fakeClient()
    const tools = buildAllTools(client, {
      wigolo_search: { enabled: true },
      wigolo_research: { enabled: true, timeoutMs: 900_000 },
    })
    const byName = Object.fromEntries(tools.map(t => [t.name, t]))
    expect(byName.wigolo_search.timeoutMs).toBe(60_000)
    expect(byName.wigolo_research.timeoutMs).toBe(900_000)
    expect(byName.wigolo_crawl.timeoutMs).toBe(300_000)
  })
})

describe('providers', () => {
  const searchPayload = {
    answer: 'the answer',
    results: [
      { url: 'https://a', title: 'A', snippet: 's', published_date: '2025-01-01' },
      { url: 'https://b' },
    ],
  }

  it('toSearchResult maps the contract fields', () => {
    const out = toSearchResult(searchPayload)
    expect(out.content).toBe('the answer')
    expect(out.sources[0]).toEqual({ url: 'https://a', title: 'A', snippet: 's', publishedAt: '2025-01-01' })
    expect(out.sources[1]).toEqual({ url: 'https://b' })
    expect(out.truncated).toBe(false)
  })

  it('toSearchResult prefers report when answer is absent', () => {
    const out = toSearchResult({ report: 'R' })
    expect(out.content).toBe('R')
  })

  it('toFetchResult maps markdown + status', () => {
    const out = toFetchResult({ url: 'https://u', http_status: 404, markdown: '# hi' }, 'https://req')
    expect(out.url).toBe('https://u')
    expect(out.statusCode).toBe(404)
    expect(out.body).toEqual({ kind: 'text', content: '# hi' })
  })

  it('providers bridge search/fetch through the client', async () => {
    const client = fakeClient({ search: searchPayload, fetch: { url: 'https://f', http_status: 200, markdown: 'm' } })
    const search = new WigoloSearchProvider(client, true)
    const fetch = new WigoloFetchProvider(client, true)
    expect(search.id).toBe('wigolo')
    expect(fetch.id).toBe('wigolo')
    expect(search.available()).toBe(true)

    const sres = await search.search({ query: 'q', maxResults: 3 })
    expect(client.calls[0].args.max_results).toBe(3)
    expect(sres.sources).toHaveLength(2)

    const fres = await fetch.fetch({ url: 'https://f' })
    expect(fres.body.content).toBe('m')
  })

  it('providers without a token are unavailable (cheap check, no network)', () => {
    const client = fakeClient()
    expect(new WigoloSearchProvider(client, false).available()).toBe(false)
    expect(new WigoloFetchProvider(client, false).available()).toBe(false)
  })
})
