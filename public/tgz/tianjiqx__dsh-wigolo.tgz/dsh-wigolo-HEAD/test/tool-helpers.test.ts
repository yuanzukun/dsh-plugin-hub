import { describe, expect, it } from 'vitest'
import { annotateExtract, humanizeWatch } from '../src/tool-helpers.ts'

describe('annotateExtract (P0: explicit selector-miss detection)', () => {
  const metaOnly = {
    data: { title: 'Trending repositories on GitHub today · GitHub', description: 'GitHub is...', og_image: 'https://x/logo.png', og_type: 'summary_large_image', canonical_url: 'https://github.com/trending' },
    source_url: 'https://github.com/trending',
    mode: 'css',
    response_time_ms: 421,
  }

  it('marks metadata-only fallback when the selector misses an SPA page', () => {
    const out = annotateExtract(metaOnly, { css_selector: 'article.Box-row' }) as Record<string, unknown>
    expect(out.selector_matched).toBe(false)
    expect(out.fallback).toBe('metadata-only')
    expect(String(out.hint)).toContain('wigolo_crawl')
  })

  it('marks selector_matched true when data carries non-metadata keys', () => {
    const hit = { ...metaOnly, data: { ...metaOnly.data, rows: [{ name: 'immich' }] } }
    const out = annotateExtract(hit, { css_selector: 'article.Box-row' }) as Record<string, unknown>
    expect(out.selector_matched).toBe(true)
  })

  it('leaves metadata-only requests (no selector asked) untouched', () => {
    const out = annotateExtract(metaOnly, { url: 'https://github.com/trending' }) as Record<string, unknown>
    expect(out.selector_matched).toBeUndefined()
    expect(out.hint).toBeUndefined()
  })

  it('handles schema requests that fall back to metadata', () => {
    const out = annotateExtract(metaOnly, { schema: { name: 'h1' } }) as Record<string, unknown>
    expect(out.selector_matched).toBe(false)
    expect(out.fallback).toBe('metadata-only')
  })
})

describe('humanizeWatch (readable next-check timing)', () => {
  it('converts negative staleness into a countdown string on jobs arrays', () => {
    const out = humanizeWatch({ jobs: [{ id: 'a', url: 'https://x', staleness_seconds: -3598 }] }) as unknown as { jobs: Array<{ next_check_in: string }> }
    expect(out.jobs[0].next_check_in).toContain('until next check')
    expect(out.jobs[0].next_check_in).toMatch(/59m|60m/)
  })

  it('marks overdue jobs explicitly', () => {
    const out = humanizeWatch({ jobs: [{ id: 'b', staleness_seconds: 125 }] }) as unknown as { jobs: Array<{ next_check_in: string }> }
    expect(out.jobs[0].next_check_in).toContain('overdue by 2m5s')
  })

  it('passes through payloads without staleness unchanged', () => {
    const out = humanizeWatch({ ok: true, id: 'c3742af5' }) as Record<string, unknown>
    expect(out).toEqual({ ok: true, id: 'c3742af5' })
  })
})
