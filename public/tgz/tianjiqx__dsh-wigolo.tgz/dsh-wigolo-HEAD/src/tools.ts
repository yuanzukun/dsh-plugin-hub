/**
 * The seven wigolo_* agent tools over the official defineTool DSL, trimmed
 * from the daemon's real MCP schemas. Each builder takes the live client
 * plus its ToolConfig (enabled/defaults/timeoutMs) from the store.
 */

import { defineTool } from '@deepseek-ai/dsh-tools'
import type { WigoloMcpClient } from './mcp-client.ts'
import type { ToolConfig } from './protocol.ts'
import {
  annotateExtract, clip, convertUtcToTimezone, effectiveTimeout, humanizeWatch, mergeDefaults, renderSources,
  takeBoolean, takeNumber, takeString, takeStringArray, toSources,
} from './tool-helpers.ts'

/** Text content block helper (the only Native shape the renders need). */
const text = (t: string) => [{ type: 'text', text: t }] as never[]

// ---------------------------------------------------------------------------
// wigolo_search
// ---------------------------------------------------------------------------

export function wigoloSearchTool(client: WigoloMcpClient, config: ToolConfig) {
  return defineTool({
    name: 'wigolo_search',
    description: 'Advanced web search via the wigolo meta-engine (18+ engines, RRF fusion, local cache). Use for scoped or freshness-sensitive searches: category (news/papers/code/docs), time_range, include/exclude_domains, depth tiers, or multiple query variants. For a plain keyword search, prefer web_search.',
    parameters: {
      query: { type: 'string', description: 'Search query, or multiple "|" separated variants for parallel search and dedup (e.g. "rust async | tokio vs async-std").', required: true },
      max_results: { type: 'number', description: 'Max results (default 10, max 20).' },
      category: { type: 'string', description: 'Result category: general | news | code | docs | papers | images.' },
      time_range: { type: 'string', description: 'Freshness filter: day | week | month | year.' },
      from_date: { type: 'string', description: 'ISO date YYYY-MM-DD — only results published after.' },
      to_date: { type: 'string', description: 'ISO date YYYY-MM-DD — only results published before.' },
      include_domains: { type: 'array', items: { type: 'string' }, description: 'Only return results from these domains.' },
      exclude_domains: { type: 'array', items: { type: 'string' }, description: 'Never return results from these domains.' },
      search_depth: { type: 'string', description: 'ultra-fast (cache-only) | fast (engines only) | balanced (default) | deep (full enrichment).' },
      force_refresh: { type: 'boolean', description: 'Bypass caches — use for news, prices, status pages.' },
      exact_match: { type: 'boolean', description: 'Treat the query as a quoted phrase.' },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value) => text(renderSources(value)),
    },
    timeoutMs: effectiveTimeout(config, 60_000),
    isConcurrencySafe: () => true,
    async execute(args) {
      const merged = mergeDefaults(config.defaults, args as unknown as Record<string, unknown>)
      const mcpArgs: Record<string, unknown> = {}
      if (typeof merged.query === 'string' && merged.query.length > 0) {
        const variants = merged.query.split('|').map((s) => s.trim()).filter(Boolean)
        mcpArgs.query = variants.length > 1 ? variants : merged.query.trim()
      }
      takeNumber(merged, 'max_results', 'max_results', mcpArgs, 1, 20)
      for (const k of ['category', 'time_range', 'from_date', 'to_date', 'search_depth']) takeString(merged, k, k, mcpArgs)
      for (const k of ['include_domains', 'exclude_domains']) takeStringArray(merged, k, k, mcpArgs)
      for (const k of ['force_refresh', 'exact_match']) takeBoolean(merged, k, k, mcpArgs)
      const payload = await client.callToolObject('search', mcpArgs)
      const cap = typeof mcpArgs.max_results === 'number' ? mcpArgs.max_results : 10
      return {
        sources: toSources(payload, cap),
        ...(Array.isArray(payload.engines_used) && payload.engines_used.length > 0 ? { engines_used: payload.engines_used } : {}),
        ...(typeof payload.total_time_ms === 'number' ? { total_time_ms: payload.total_time_ms } : {}),
        truncated: false,
      }
    },
  })
}

// ---------------------------------------------------------------------------
// wigolo_crawl
// ---------------------------------------------------------------------------

export function wigoloCrawlTool(client: WigoloMcpClient, config: ToolConfig) {
  return defineTool({
    name: 'wigolo_crawl',
    description: 'Crawl a site from a seed URL and return content from many pages. Use for indexing docs, wikis, multi-page references; every page lands in the local cache for later offline reuse.',
    parameters: {
      url: { type: 'string', description: 'Seed URL.', required: true },
      max_depth: { type: 'number', description: 'Max link depth from the seed (default 2, max 5).' },
      max_pages: { type: 'number', description: 'Max pages to fetch (default 50, max 500).' },
      include_patterns: { type: 'array', items: { type: 'string' }, description: 'Only follow URLs matching these patterns (e.g. ["/docs/"]).' },
      exclude_patterns: { type: 'array', items: { type: 'string' }, description: 'Skip URLs matching these patterns.' },
      strategy: { type: 'string', description: 'Crawl order: bfs (default) | dfs.' },
    },
    output: { schema: { type: 'json' }, render: (_a, v) => text(JSON.stringify(v).slice(0, 4000)) },
    timeoutMs: effectiveTimeout(config, 300_000),
    isConcurrencySafe: () => true,
    async execute(args) {
      const merged = mergeDefaults(config.defaults, args as unknown as Record<string, unknown>)
      const mcpArgs: Record<string, unknown> = {}
      takeString(merged, 'url', 'url', mcpArgs)
      takeNumber(merged, 'max_depth', 'max_depth', mcpArgs, 1, 5)
      takeNumber(merged, 'max_pages', 'max_pages', mcpArgs, 1, 500)
      takeStringArray(merged, 'include_patterns', 'include_patterns', mcpArgs)
      takeStringArray(merged, 'exclude_patterns', 'exclude_patterns', mcpArgs)
      takeString(merged, 'strategy', 'strategy', mcpArgs)
      return await client.callToolObject('crawl', mcpArgs)
    },
  })
}

// ---------------------------------------------------------------------------
// wigolo_extract
// ---------------------------------------------------------------------------

export function wigoloExtractTool(client: WigoloMcpClient, config: ToolConfig) {
  return defineTool({
    name: 'wigolo_extract',
    description: 'Extract structured data from a URL: tables, prices, schema fields — via a CSS selector or a field schema. Server-rendered DOM only: on JS-rendered SPA pages the selector may miss and you get metadata only (the response then carries selector_matched: false with guidance). For dynamic pages, prefer wigolo_crawl first and parse the markdown. When a crawl snapshot exists in the local cache, the response includes a cached_markdown hint for offline reuse.',
    parameters: {
      url: { type: 'string', description: 'Target URL.', required: true },
      css_selector: { type: 'string', description: 'CSS selector to extract (e.g. "table", ".price", "h1").' },
      multiple: { type: 'boolean', description: 'Return all matches (true) or the first match (false, default).' },
      schema: { type: 'json', description: 'Field-extraction schema: keys are output fields, values are CSS selectors or instructions.' },
      max_tokens_out: { type: 'number', description: 'Cap the extracted payload size (tokens).' },
    },
    output: { schema: { type: 'json' }, render: (_a, v) => text(JSON.stringify(v).slice(0, 4000)) },
    timeoutMs: effectiveTimeout(config, 60_000),
    isConcurrencySafe: () => true,
    async execute(args) {
      const merged = mergeDefaults(config.defaults, args as unknown as Record<string, unknown>)
      const mcpArgs: Record<string, unknown> = {}
      takeString(merged, 'url', 'url', mcpArgs)
      takeString(merged, 'css_selector', 'css_selector', mcpArgs)
      takeBoolean(merged, 'multiple', 'multiple', mcpArgs)
      if (typeof merged.schema === 'object' && merged.schema !== null) mcpArgs.schema = merged.schema
      takeNumber(merged, 'max_tokens_out', 'max_tokens_out', mcpArgs, 100, 100_000)
      const payload = await client.callToolObject('extract', mcpArgs)
      return annotateExtract(payload, mcpArgs)
    },
  })
}

// ---------------------------------------------------------------------------
// wigolo_research
// ---------------------------------------------------------------------------

export function wigoloResearchTool(client: WigoloMcpClient, config: ToolConfig) {
  return defineTool({
    name: 'wigolo_research',
    description: 'Multi-step research on a complex question: decomposes into sub-queries, searches in parallel, fetches sources, synthesizes a cited report. Best for open, exploratory questions ("compare X vs Y", "analyze pros/cons"). For simple factual or list-type queries ("top trending repos today"), prefer wigolo_search or wigolo_crawl — the decomposition pipeline can drift on narrow queries. Use include_domains to steer sources (e.g. github.com for repo questions) and avoid irrelevant citations.',
    parameters: {
      question: { type: 'string', description: 'The research question.', required: true },
      depth: { type: 'string', description: 'quick | standard (default) | deep.' },
      max_sources: { type: 'number', description: 'Max sources to consult (default 8, max 30).' },
      include_domains: { type: 'array', items: { type: 'string' }, description: 'Only consult these domains.' },
      exclude_domains: { type: 'array', items: { type: 'string' }, description: 'Skip these domains.' },
    },
    output: { schema: { type: 'json' }, render: (_a, v) => text(clip(String((v as { report?: string })?.report ?? JSON.stringify(v).slice(0, 4000)), 8000)) },
    timeoutMs: effectiveTimeout(config, 600_000),
    isConcurrencySafe: () => true,
    async execute(args) {
      const merged = mergeDefaults(config.defaults, args as unknown as Record<string, unknown>)
      const mcpArgs: Record<string, unknown> = {}
      takeString(merged, 'question', 'question', mcpArgs)
      takeString(merged, 'depth', 'depth', mcpArgs)
      takeNumber(merged, 'max_sources', 'max_sources', mcpArgs, 1, 30)
      takeStringArray(merged, 'include_domains', 'include_domains', mcpArgs)
      takeStringArray(merged, 'exclude_domains', 'exclude_domains', mcpArgs)
      const payload = await client.callToolObject('research', mcpArgs)
      const report = typeof payload.report === 'string' ? payload.report : (typeof payload.answer === 'string' ? payload.answer : '')
      return { report: clip(report, 30_000), raw: payload }
    },
  })
}

// ---------------------------------------------------------------------------
// wigolo_find_similar
// ---------------------------------------------------------------------------

export function wigoloFindSimilarTool(client: WigoloMcpClient, config: ToolConfig) {
  return defineTool({
    name: 'wigolo_find_similar',
    description: 'Find content related to a URL or concept. Best after a successful crawl/fetch — the local cache makes recommendations cheap. Concept-only queries also work.',
    parameters: {
      url: { type: 'string', description: 'Seed URL to find similar content for.' },
      concept: { type: 'string', description: 'Concept text instead of a URL.' },
      max_results: { type: 'number', description: 'Max results (default 10, max 20).' },
      include_web: { type: 'boolean', description: 'Also search the web beyond the local cache (default true).' },
    },
    output: { schema: { type: 'json' }, render: (_a, v) => text(renderSources(v)) },
    timeoutMs: effectiveTimeout(config, 120_000),
    isConcurrencySafe: () => true,
    async execute(args) {
      const merged = mergeDefaults(config.defaults, args as unknown as Record<string, unknown>)
      const mcpArgs: Record<string, unknown> = {}
      takeString(merged, 'url', 'url', mcpArgs)
      takeString(merged, 'concept', 'concept', mcpArgs)
      takeNumber(merged, 'max_results', 'max_results', mcpArgs, 1, 20)
      takeBoolean(merged, 'include_web', 'include_web', mcpArgs)
      const payload = await client.callToolObject('find_similar', mcpArgs)
      const cap = typeof mcpArgs.max_results === 'number' ? mcpArgs.max_results : 10
      return { sources: toSources(payload, cap), truncated: false }
    },
  })
}

// ---------------------------------------------------------------------------
// wigolo_cache
// ---------------------------------------------------------------------------

export function wigoloCacheTool(client: WigoloMcpClient, config: ToolConfig, timezone: string = 'local') {
  return defineTool({
    name: 'wigolo_cache',
    description: 'Search previously fetched content WITHOUT hitting the network. Run this BEFORE any search/fetch — cache hits return instantly with full markdown. Also exposes stats (usage numbers) and clear (wipe, destructive).',
    parameters: {
      query: { type: 'string', description: 'Search the local cache by keyword.' },
      url_pattern: { type: 'string', description: 'Glob pattern matched against the FULL URL (fullmatch, not substring): "https://example.com/page" for exact, "*keyword*" for substring, "*suffix" for suffix. Bare substrings without "*" match nothing.' },
      since: { type: 'string', description: 'Only entries newer than this (YYYY-MM-DD or ISO).' },
      stats: { type: 'boolean', description: 'Return cache statistics instead of searching.' },
      clear: { type: 'boolean', description: 'Wipe the whole cache (destructive; confirm with the user first).' },
      limit: { type: 'number', description: 'Max entries to return (default 10, max 50).' },
    },
    output: { schema: { type: 'json' }, render: (_a, v) => text(JSON.stringify(v).slice(0, 4000)) },
    timeoutMs: effectiveTimeout(config, 30_000),
    isConcurrencySafe: () => true,
    async execute(args) {
      const merged = mergeDefaults(config.defaults, args as unknown as Record<string, unknown>)
      const mcpArgs: Record<string, unknown> = {}
      takeString(merged, 'query', 'query', mcpArgs)
      takeString(merged, 'url_pattern', 'url_pattern', mcpArgs)
      takeString(merged, 'since', 'since', mcpArgs)
      takeBoolean(merged, 'stats', 'stats', mcpArgs)
      takeBoolean(merged, 'clear', 'clear', mcpArgs)
      takeNumber(merged, 'limit', 'limit', mcpArgs, 1, 50)
      const payload = await client.callToolObject('cache', mcpArgs)
      
      // Apply timezone conversion to timestamps
      // Convert fetched_at in results
      if (Array.isArray(payload.results)) {
        payload.results = payload.results.map((item: any) => {
          if (item.fetched_at) {
            return { ...item, fetched_at: convertUtcToTimezone(item.fetched_at, timezone) }
          }
          return item
        })
      }
      
      // Convert stats timestamps
      if (payload.stats && typeof payload.stats === 'object') {
        const stats = payload.stats as any
        if (stats.oldest) stats.oldest = convertUtcToTimezone(stats.oldest, timezone)
        if (stats.newest) stats.newest = convertUtcToTimezone(stats.newest, timezone)
      }
      
      return payload
    },
  })
}

// ---------------------------------------------------------------------------
// wigolo_watch
// ---------------------------------------------------------------------------

export function wigoloWatchTool(client: WigoloMcpClient, config: ToolConfig) {
  return defineTool({
    name: 'wigolo_watch',
    description: 'Watch URLs for changes: schedule lazy re-checks and surface diffs on change. Jobs persist across daemon restarts. Actions: create | list | check | pause | resume | delete (aliases: add→create, remove→delete). Tip: pair with a scheduled task to run check() periodically; pause/resume lets you temporarily suspend a watch without losing its history.',
    parameters: {
      action: { type: 'string', description: 'create | list | check | pause | resume | delete (add/remove accepted as aliases).', required: true },
      url: { type: 'string', description: 'URL to watch (create) or check.' },
      urls: { type: 'array', items: { type: 'string' }, description: 'Multiple URLs (create).' },
      interval_seconds: { type: 'number', description: 'Re-check interval (create; keep >= 600 for politeness).' },
      selector: { type: 'string', description: 'Watch only this CSS selector subtree (create, optional).' },
      job_id: { type: 'string', description: 'Job id (pause/resume/delete/check one job).' },
    },
    output: { schema: { type: 'json' }, render: (_a, v) => text(JSON.stringify(v).slice(0, 4000)) },
    timeoutMs: effectiveTimeout(config, 120_000),
    isConcurrencySafe: () => true,
    async execute(args) {
      const merged = mergeDefaults(config.defaults, args as unknown as Record<string, unknown>)
      const mcpArgs: Record<string, unknown> = {}
      // Normalize documented aliases to the daemon's real action names.
      const alias: Record<string, string> = { add: 'create', remove: 'delete' }
      if (typeof merged.action === 'string' && merged.action.trim() !== '') {
        const normalized = merged.action.trim()
        mcpArgs.action = alias[normalized] ?? normalized
      }
      takeString(merged, 'url', 'url', mcpArgs)
      takeStringArray(merged, 'urls', 'urls', mcpArgs)
      takeNumber(merged, 'interval_seconds', 'interval_seconds', mcpArgs, 60, 86_400)
      takeString(merged, 'selector', 'selector', mcpArgs)
      takeString(merged, 'job_id', 'job_id', mcpArgs)
      const payload = await client.callToolObject('watch', mcpArgs)
      return humanizeWatch(payload)
    },
  })
}

/** All seven tool builders, keyed by the store's tool ids. */
export function buildAllTools(client: WigoloMcpClient, configs: Record<string, ToolConfig>, timezone: string = 'local') {
  return [
    wigoloSearchTool(client, configs.wigolo_search ?? { enabled: true }),
    wigoloCrawlTool(client, configs.wigolo_crawl ?? { enabled: true }),
    wigoloExtractTool(client, configs.wigolo_extract ?? { enabled: true }),
    wigoloResearchTool(client, configs.wigolo_research ?? { enabled: true }),
    wigoloFindSimilarTool(client, configs.wigolo_find_similar ?? { enabled: false }),
    wigoloCacheTool(client, configs.wigolo_cache ?? { enabled: true }, timezone),
    wigoloWatchTool(client, configs.wigolo_watch ?? { enabled: true }),
  ]
}
