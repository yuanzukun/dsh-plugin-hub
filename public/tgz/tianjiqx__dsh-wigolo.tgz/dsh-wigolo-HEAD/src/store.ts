/**
 * Config store: one JSON file (~/.dsh/wigolo.json, version 2) written
 * atomically (tmp + rename). Pure file I/O — no cordis dependency,
 * unit-testable (same pattern as dsh-ssh's HostStore).
 */

import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { applyLegacyImport, defaultConfig, detectLegacySetup, expandHome, resolveTokenFilePath } from './config.ts'
import { CONFIG_FILE_NAME } from './invariant.ts'
import type { WigoloConfig, WigoloConfigSummary } from './protocol.ts'

/** File format version this store reads/writes. */
const CURRENT_VERSION = 2

/** Store file location: <home>/.dsh/wigolo.json. */
export function storePath(): string {
  return join(homedir(), '.dsh', CONFIG_FILE_NAME)
}

/** Read the raw token from the token file (empty string when absent). */
export function readTokenFrom(path: string): string {
  try {
    return readFileSync(path, 'utf8').split('\n')[0].trim()
  } catch {
    return ''
  }
}

/** Whether the token file exists and holds a non-empty token. */
export function hasTokenAt(path: string): boolean {
  return readTokenFrom(path) !== ''
}

interface StoreFile {
  version: number
  config: WigoloConfig
}

/** Top-level config keys this store understands. */
const KNOWN_KEYS = ['version', 'connection', 'takeover', 'tools', 'announceToAgent', 'cacheTab'] as const

/** Connection keys this store understands. */
const KNOWN_CONNECTION_KEYS = ['host', 'port', 'hostHeader', 'tokenFile'] as const

/** Minimal edit distance for a "did you mean" hint. */
function editDistance(a: string, b: string): number {
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array<number>(b.length).fill(0)])
  for (let j = 1; j <= b.length; j++) dp[0][j] = j
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1))
    }
  }
  return dp[a.length][b.length]
}

/** "did you mean" hint for an unknown key, or undefined. */
function didYouMean(key: string, known: readonly string[]): string | undefined {
  let best: { key: string; d: number } | undefined
  for (const candidate of known) {
    const d = editDistance(key, candidate)
    if (d <= Math.max(2, Math.floor(candidate.length / 3)) && (best === undefined || d < best.d)) {
      best = { key: candidate, d }
    }
  }
  return best?.key
}

/**
 * The config store. All mutations go through update() which re-reads,
 * merges, validates, and persists atomically. Unknown config keys are
 * reported (fail-loud) instead of being silently dropped.
 */
export class ConfigStore {
  /** The JSON file path. */
  readonly path: string
  /** Whether a legacy import was applied when the file was first created (memoized for the summary). */
  private migratedFromLegacy = false
  /** Warning sink (defaults to console.warn; the host half passes the plugin logger). */
  private readonly warn: (message: string) => void

  constructor(path?: string, warn: (message: string) => void = (m) => { console.warn('[dsh-wigolo]', m) }) {
    this.path = resolve(path ?? storePath())
    this.warn = warn
  }

  /** Load the config, creating it (with legacy import) on first run. */
  load(): WigoloConfig {
    if (!existsSync(this.path)) {
      const fresh = defaultConfig()
      const legacy = detectLegacySetup()
      const imported = applyLegacyImport(fresh, legacy)
      this.migratedFromLegacy = legacy !== undefined
      this.persist(imported)
      return imported
    }
    this.migratedFromLegacy = false
    return this.normalize(this.readRaw())
  }

  /** Secret-free summary for the browser surface. */
  summarize(): WigoloConfigSummary {
    const config = this.load()
    return {
      connection: config.connection,
      takeover: config.takeover,
      tools: config.tools,
      announceToAgent: config.announceToAgent,
      cacheTab: config.cacheTab,
      timezone: config.timezone,
      hasToken: hasTokenAt(resolveTokenFilePath(config)),
      migratedFromLegacy: this.migratedFromLegacy,
    }
  }

  /** Merge a partial config and persist atomically. Returns the new config. */
  update(mutator: (current: WigoloConfig) => WigoloConfig): WigoloConfig {
    const current = this.load()
    const next = mutator(current)
    this.persist(this.normalize(next))
    return next
  }

  /** Write the token to the token file (0600). Creates parent dirs. */
  writeToken(token: string): void {
    const config = this.load()
    const target = resolveTokenFilePath(config)
    mkdirSync(dirname(target), { recursive: true })
    writeFileSync(target, token.trim() + '\n', { mode: 0o600 })
  }

  /** Read the token (env override first — same precedence the legacy plugin used). */
  readToken(): string {
    return this.readTokenFrom(this.load().connection.tokenFile)
  }

  /**
   * Read the token against an explicit tokenFile value ('' = default path).
   * Env override applies the same way as readToken().
   */
  readTokenFrom(tokenFile: string): string {
    if (process.env.WIGOLO_TOKEN !== undefined && process.env.WIGOLO_TOKEN !== '') return process.env.WIGOLO_TOKEN
    const config = this.load()
    const path = tokenFile.trim() !== '' ? expandHome(tokenFile.trim()) : resolveTokenFilePath(config)
    return readTokenFrom(path)
  }

  // -- internals ------------------------------------------------------------

  private readRaw(): WigoloConfig {
    const text = readFileSync(this.path, 'utf8')
    let parsed: unknown
    try {
      parsed = JSON.parse(text)
    } catch {
      // Corrupt file: fall back to defaults rather than crash the host.
      return defaultConfig()
    }
    if (typeof parsed === 'object' && parsed !== null && 'version' in parsed && 'config' in parsed) {
      const file = parsed as StoreFile
      return typeof file.config === 'object' && file.config !== null ? file.config : defaultConfig()
    }
    // A bare config object (no envelope) — accept it too.
    return parsed as WigoloConfig
  }

  private normalize(config: unknown): WigoloConfig {
    const base = defaultConfig()
    if (typeof config !== 'object' || config === null) return base
    const c = config as Partial<WigoloConfig>
    // Fail-loud: unknown keys are reported with a "did you mean" hint rather
    // than being silently dropped (a typo'd key would otherwise quietly lose
    // the setting).
    for (const key of Object.keys(config as Record<string, unknown>)) {
      if (!(key in base)) {
        const hint = didYouMean(key, KNOWN_KEYS)
        this.warn(`unknown config key "${key}" in ${this.path}${hint !== undefined ? ` — did you mean "${hint}"?` : ''} (ignored)`)
      }
    }
    const conn = (c.connection ?? {}) as Record<string, unknown>
    for (const key of Object.keys(conn)) {
      if (!(key in base.connection)) {
        const hint = didYouMean(key, KNOWN_CONNECTION_KEYS)
        this.warn(`unknown connection key "${key}"${hint !== undefined ? ` — did you mean "${hint}"?` : ''} (ignored)`)
      }
    }
    return {
      version: 2,
      connection: {
        host: str(conn.host, base.connection.host),
        port: num(conn.port, base.connection.port, 1, 65535),
        hostHeader: str(conn.hostHeader, base.connection.hostHeader),
        tokenFile: typeof conn.tokenFile === 'string' ? conn.tokenFile : base.connection.tokenFile,
      },
      takeover: typeof c.takeover === 'boolean' ? c.takeover : base.takeover,
      tools: mergeTools(base.tools, c.tools),
      announceToAgent: typeof c.announceToAgent === 'boolean' ? c.announceToAgent : base.announceToAgent,
      cacheTab: {
        enabled: typeof (c.cacheTab as { enabled?: unknown } | undefined)?.enabled === 'boolean'
          ? (c.cacheTab as { enabled: boolean }).enabled
          : base.cacheTab.enabled,
      },
      timezone: typeof (c as Partial<WigoloConfig>).timezone === 'string' ? (c as Partial<WigoloConfig>).timezone! : base.timezone,
    }
  }

  private persist(config: WigoloConfig): void {
    const file: StoreFile = { version: CURRENT_VERSION, config }
    const dir = dirname(this.path)
    mkdirSync(dir, { recursive: true })
    const tmp = join(dir, `.wigolo.json.${process.pid}.${Date.now()}.tmp`)
    writeFileSync(tmp, JSON.stringify(file, null, 2) + '\n', { mode: 0o600 })
    renameSync(tmp, this.path)
  }
}

// -- small merge helpers ----------------------------------------------------

function str(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.trim() !== '' ? value : fallback
}

function num(value: unknown, fallback: number, min: number, max: number): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < min || value > max) return fallback
  return value
}

interface ToolSettings { enabled: boolean; defaults?: Record<string, unknown>; timeoutMs?: number }

function mergeTools(base: Record<string, ToolSettings>, patch: unknown): Record<string, ToolSettings> {
  if (typeof patch !== 'object' || patch === null) return base
  const out: Record<string, ToolSettings> = {}
  for (const key of Object.keys(base)) {
    out[key] = { ...base[key] }
  }
  for (const [key, value] of Object.entries(patch as Record<string, unknown>)) {
    if (typeof value !== 'object' || value === null) continue
    const v = value as { enabled?: unknown; defaults?: unknown; timeoutMs?: unknown }
    out[key] = {
      enabled: typeof v.enabled === 'boolean' ? v.enabled : (out[key]?.enabled ?? true),
      ...(isPlainObject(v.defaults) ? { defaults: v.defaults } : {}),
      ...(typeof v.timeoutMs === 'number' && v.timeoutMs >= 0 ? { timeoutMs: v.timeoutMs } : {}),
    }
  }
  return out
}

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v)
}
