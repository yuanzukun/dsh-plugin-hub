/** Stable facts about the plugin, independent of any runtime. */

/** Stable cordis plugin name. */
export const PLUGIN_NAME = '@tianjiqx/dsh-wigolo' as const

/** Provider ids registered into the dsh-web seam (kept from the legacy plugin so existing searchProvider configs keep working). */
export const SEARCH_PROVIDER_ID = 'wigolo' as const
export const FETCH_PROVIDER_ID = 'wigolo' as const

/** The wigolo daemon's MCP endpoint path. */
export const MCP_PATH = '/mcp' as const

/** MCP protocol version spoken by the client. */
export const MCP_PROTOCOL_VERSION = '2024-11-05' as const

/** Client identity announced during MCP initialize. */
export const MCP_CLIENT_INFO = { name: 'dsh-wigolo', version: '1.1.0' } as const

/** Config file location: <home>/.dsh/wigolo.json. */
export const CONFIG_FILE_NAME = 'wigolo.json' as const

/** Legacy token file location (also the default tokenFile target). */
export const DEFAULT_TOKEN_FILE_NAME = 'wigolo-token' as const

/** Legacy env vars, imported on first run. */
export const LEGACY_ENV_HOST = 'WIGOLO_HOST_IP' as const
export const LEGACY_ENV_PORT = 'WIGOLO_PORT' as const
export const LEGACY_ENV_TOKEN = 'WIGOLO_TOKEN' as const

/** Managed block markers in ~/.dsh/cordis.patch.yml (dsh-skin precedent). */
export const CORDIS_MANAGED_BEGIN = '# --- dsh-wigolo managed (auto-generated; do not edit) ---'
export const CORDIS_MANAGED_END = '# --- end dsh-wigolo managed ---'

/** The agent-facing announcement order within the tool-guidance band. */
export const ANNOUNCE_ORDER = 151
