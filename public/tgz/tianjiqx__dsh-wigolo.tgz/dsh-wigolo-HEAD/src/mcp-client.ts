/**
 * Minimal streamable-http MCP client for the wigolo daemon, with lazy
 * session establishment and stale-session recovery. Features hostHeader
 * resolution ("auto" sends no custom Host for local addresses, literal
 * only for remote hosts behind wigolo's DNS-rebinding allowlist) and
 * injectable connection settings so the panel's test probe can use them
 * without a store.
 *
 * Transport: node:http (NOT fetch — the Fetch spec forbids setting the
 * Host header). initialize (capture mcp-session-id) ->
 * notifications/initialized (202, empty body) -> tools/call. Responses
 * arrive as SSE frames or plain JSON.
 */

import http from 'node:http'
import type { ConnectionConfig } from './protocol.ts'
import { MCP_CLIENT_INFO, MCP_PATH, MCP_PROTOCOL_VERSION } from './invariant.ts'
import { resolveHostHeaderFromConfig } from './config.ts'

export { resolveHostHeaderFromConfig as resolveHostHeader } from './config.ts'

/** A lossless JSON document (the parsed MCP tool result). */
export type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue }

/** One JSON-RPC response frame. */
interface McpFrame { jsonrpc?: string; id?: number; result?: unknown; error?: { message?: string } }

/** Low-level POST; resolves { sid, text, status }. */
function post(host: string, port: number, hostHeader: string | undefined, token: string, body: unknown, sessionId: string | null, timeoutMs: number): Promise<{ sid?: string; text: string; status: number }> {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body)
    const headers: Record<string, string | number> = {
      'Content-Type': 'application/json',
      Accept: 'application/json, text/event-stream',
      Authorization: `Bearer ${token}`,
      'Content-Length': Buffer.byteLength(payload),
    }
    if (hostHeader !== undefined) headers.Host = hostHeader
    if (sessionId !== null) headers['Mcp-Session-Id'] = sessionId
    const req = http.request({ host, port, path: MCP_PATH, method: 'POST', headers }, (res) => {
      const sid = res.headers['mcp-session-id']
      let text = ''
      res.on('data', (c) => { text += c })
      res.on('end', () => {
        if (res.statusCode === undefined || res.statusCode >= 400) {
          reject(new Error(`wigolo HTTP ${res.statusCode}: ${text.slice(0, 200)}`))
        } else {
          resolve({ sid: sid !== undefined ? String(sid) : undefined, text, status: res.statusCode })
        }
      })
    })
    req.on('error', reject)
    req.setTimeout(timeoutMs, () => req.destroy(new Error('wigolo request timeout')))
    req.end(payload)
  })
}

/** Parse an SSE/JSON body into the JSON payload (null for empty bodies like 202 notifications). */
function parseFrame(text: string): McpFrame | null {
  for (const line of text.split('\n')) {
    if (line.startsWith('data: ')) return JSON.parse(line.slice(6)) as McpFrame
  }
  return text.trim() === '' ? null : JSON.parse(text) as McpFrame
}

/** Connection probe result (panel "test connection"). */
export interface ProbeResult { ok: boolean; latencyMs: number; serverVersion?: string; error?: string }

/**
 * The MCP client. One instance owns one session; callTool re-establishes the
 * session on stale-id failures (daemon restart) exactly once before retrying.
 */
export class WigoloMcpClient {
  private sessionId: string | null = null
  private initPromise: Promise<void> | null = null
  private nextId = 1
  /** Bumped by reconfigure(); in-flight handshakes check it after each await. */
  private generation = 0
  private readonly timeoutMs: number

  constructor(
    private connection: { host: string; port: number; hostHeader: string },
    private token: string,
    timeoutMs = 60_000,
  ) {
    this.timeoutMs = timeoutMs
  }

  /** Connection settings snapshot (host/port/hostHeader the client was built with). */
  get settings(): { host: string; port: number; hostHeader: string } {
    return this.connection
  }

  /**
   * Hot-reconfigure the connection without creating a new client instance.
   * Resets the MCP session (sessions are bound to a specific host/port).
   * Called by the panel API after config edits so tool calls pick up the
   * new connection immediately — no DSH restart required.
   */
  reconfigure(connection: { host: string; port: number; hostHeader: string }, token: string): void {
    this.connection = connection
    this.token = token
    this.sessionId = null
    this.initPromise = null
    // Invalidate any handshake still in flight against the old connection so
    // it cannot write a stale session id back after we reset it.
    this.generation++
  }

  /** Probe the daemon: one initialize round, no session retained. */
  async probe(): Promise<ProbeResult> {
    const started = Date.now()
    try {
      const init = await post(this.connection.host, this.connection.port, this.connection.hostHeader, this.token, {
        jsonrpc: '2.0', id: this.nextId++, method: 'initialize',
        params: { protocolVersion: MCP_PROTOCOL_VERSION, capabilities: {}, clientInfo: MCP_CLIENT_INFO },
      }, null, 10_000)
      // Deliberately do NOT store the session: probe never completes the
      // handshake (notifications/initialized), so keeping it would hand the
      // next callTool a half-initialized session.
      const frame = parseFrame(init.text)
      const info = frame?.result as { serverInfo?: { version?: string } } | undefined
      return { ok: true, latencyMs: Date.now() - started, ...(info?.serverInfo?.version !== undefined ? { serverVersion: info.serverInfo.version } : {}) }
    } catch (err) {
      return { ok: false, latencyMs: Date.now() - started, error: err instanceof Error ? err.message : String(err) }
    }
  }

  private async ensureSession(isRetry = false): Promise<void> {
    if (this.sessionId !== null) return
    if (this.initPromise === null) {
      const generation = this.generation
      this.initPromise = (async () => {
        const init = await post(this.connection.host, this.connection.port, this.connection.hostHeader, this.token, {
          jsonrpc: '2.0', id: this.nextId++, method: 'initialize',
          params: { protocolVersion: MCP_PROTOCOL_VERSION, capabilities: {}, clientInfo: MCP_CLIENT_INFO },
        }, null, this.timeoutMs)
        // A reconfigure landed while the handshake was in flight — the session
        // belongs to the old connection; drop it instead of writing it back.
        if (this.generation !== generation) return
        this.sessionId = init.sid ?? null
        // initialized notification: 202, empty body — must not be parsed as a frame.
        await post(this.connection.host, this.connection.port, this.connection.hostHeader, this.token, {
          jsonrpc: '2.0', method: 'notifications/initialized',
        }, this.sessionId, this.timeoutMs)
      })().finally(() => { if (this.generation === generation) this.initPromise = null })
    }
    await this.initPromise
    if (this.sessionId === null && this.initPromise === null && !isRetry) {
      // The awaited handshake was invalidated by a reconfigure — run one
      // fresh handshake against the current connection, then give up (a
      // daemon that never returns a session id cannot be retried away).
      return this.ensureSession(true)
    }
  }

  /**
   * Call a wigolo tool and coerce the result to an object shape (empty when
   * the daemon returned a non-object). The convenience consumers (tools,
   * providers) all expect object payloads.
   */
  async callToolObject(name: string, args: Record<string, unknown> = {}): Promise<Record<string, JsonValue>> {
    const result = await this.callTool(name, args)
    return typeof result === 'object' && result !== null && !Array.isArray(result) ? result : {}
  }

  /**
   * Call a wigolo tool; re-initializes once on session failure before retrying.
   * The return is a parsed JSON document (lossless JSON by construction).
   */
  async callTool(name: string, args: Record<string, unknown> = {}): Promise<JsonValue> {
    await this.ensureSession()
    let text: string
    try {
      const resp = await post(this.connection.host, this.connection.port, this.connection.hostHeader, this.token, {
        jsonrpc: '2.0', id: this.nextId++, method: 'tools/call',
        params: { name, arguments: args },
      }, this.sessionId, this.timeoutMs)
      text = resp.text
    } catch (err) {
      // Stale session (daemon restarted): drop it, re-handshake, retry once.
      this.sessionId = null
      await this.ensureSession()
      const resp = await post(this.connection.host, this.connection.port, this.connection.hostHeader, this.token, {
        jsonrpc: '2.0', id: this.nextId++, method: 'tools/call',
        params: { name, arguments: args },
      }, this.sessionId, this.timeoutMs)
      text = resp.text
      void err
    }
    const frame = parseFrame(text)
    if (frame?.error !== undefined) throw new Error(`wigolo MCP error: ${frame.error.message ?? JSON.stringify(frame.error)}`)
    const result = frame?.result as { content?: Array<{ type: string; text?: string }> } | undefined
    if (result?.content !== undefined) {
      for (const entry of result.content) {
        if (entry.type === 'text' && entry.text !== undefined) {
          try {
            return JSON.parse(entry.text) as JsonValue
          } catch {
            return { text: entry.text }
          }
        }
      }
    }
    return (frame?.result as JsonValue) ?? {}
  }
}

/** Build a live client from the stored config + token (factory used by the host half). */
export function clientFromConfig(connection: ConnectionConfig, token: string, timeoutMs?: number): WigoloMcpClient {
  const hostHeader = resolveHostHeaderFromConfig(connection)
  return new WigoloMcpClient({ host: connection.host, port: connection.port, hostHeader: hostHeader ?? '' }, token, timeoutMs)
}
