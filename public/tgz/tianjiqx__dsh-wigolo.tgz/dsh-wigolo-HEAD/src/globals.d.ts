/** Build-time globals injected by tsdown's define (see tsdown.config.ts). */

/** Plugin version from package.json, injected at build time. */
declare const __WIGOLO_VERSION__: string

/** Chinese guide content from GUIDE.zh.md, injected at build time. */
declare const __GUIDE_CONTENT__: string

/** English guide content from GUIDE.md, injected at build time. */
declare const __GUIDE_EN_CONTENT__: string
