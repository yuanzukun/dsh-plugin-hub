/**
 * dsh-wigolo — host half. Mounts the config store, the /api/dsh-wigolo
 * route family, the web seam providers (per takeover), the wigolo_* agent
 * tools (per tool exposure), and a system-prompt announcement.
 * The browser half (./client) renders the sidebar panel.
 *
 * Takeover: a boolean. true registers the wigolo providers AND requires
 * searchProvider/fetchProvider: wigolo in the home cordis patch (without it,
 * coexisting providers would trip the seam's WEB_PROVIDER_AMBIGUOUS error);
 * false registers nothing into the seam — the wigolo_* tools work standalone.
 * See cordis-managed.ts for the routing management.
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import type {} from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-system-prompt'
import type {} from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-web'
import { ConfigStore } from './store.ts'
import { makeRoutes } from './routes.ts'
import { clientFromConfig } from './mcp-client.ts'
import { WigoloFetchProvider, WigoloSearchProvider } from './providers.ts'
import { buildAllTools } from './tools.ts'
import { ANNOUNCE_ORDER, PLUGIN_NAME } from './invariant.ts'

/** Stable cordis plugin name. */
export const name = PLUGIN_NAME

/** Services required before the wigolo surfaces can mount. */
export const inject = ['webServer', 'web', 'tools', 'systemPrompt', 'settings', 'sessions']

/** Stable profile entry/settings id used by both the current and legacy settings surfaces. */
export const WIGOLO_SETTINGS_NAMESPACE = 'dsh-wigolo'

/** Plugin entry config, validated by the same-named schemastery schema (doubles as the settings card schema). */
export interface Config {
  /** Master switch for the plugin (routes, providers, tools, prompt). */
  enabled?: boolean
  /** When true (default), a system-prompt section announces the wigolo tools to every agent. */
  announceToAgent?: boolean
  /** Overrides the shipped announcement text (deployments localize or rewrite it). */
  guidance?: string
}

/** Schema default, re-read for hand-built test contexts. */
const DEFAULT_ANNOUNCE = true

export const Config: z<Config> = z.object({
  // DSH 0.1.7+ exposes volatile Config fields through its profile settings
  // editor. Older DSH versions ignore this metadata and use the legacy
  // settings.register adapter below.
  enabled: z.boolean().default(true).volatile(),
  announceToAgent: z.boolean().default(DEFAULT_ANNOUNCE).volatile(),
  guidance: z.string().volatile(),
})

/** Shape of the pre-0.1.7 settings service. Keep this structural so this
 * package does not bind its runtime to one dsh-settings package generation. */
interface LegacySettingsService {
  register(
    ns: string,
    schema: z<Config>,
    options: { base: Config; applies: 'live' },
  ): {
    get(): Config
    watch(callback: () => void): (() => void) | void
  }
}

function legacySettings(ctx: Context): LegacySettingsService | undefined {
  const service = (ctx as unknown as { settings?: Partial<LegacySettingsService> }).settings
  return typeof service?.register === 'function' ? service as LegacySettingsService : undefined
}

/** Model-facing announcement: capabilities, takeover note, and limits. */
export const WIGOLO_GUIDANCE =
  '本机已安装 dsh-wigolo 插件（wigolo 搜索集成）：侧边栏「Wigolo」面板配置连接/接管/缓存。' +
  '能力：wigolo_search 高级搜索（category/time_range/域名过滤/多变体/深度档）；wigolo_crawl 站点爬取（入本地缓存）；' +
  'wigolo_extract 结构化提取（CSS 选择器/字段 schema）；wigolo_research 多轮研究（分解子查询+引用报告）；' +
  'wigolo_find_similar 相似内容；wigolo_cache 本地缓存检索（搜索前先查缓存，秒回）；wigolo_watch URL 变化监控（daemon 侧持久任务）。' +
  'web_search/web_fetch 是否由 wigolo 驱动取决于面板的接管开关。' +
  '限制：需 wigolo daemon 在线（面板可测试连接）；research/crawl 耗时较长；watch 的 interval 不低于 600s；' +
  'cache clear 为破坏性操作先确认。用户提到「wigolo / 深度搜索 / 爬取 / 研究 / 监控页面变化」时即指本插件。'

/**
 * Mount every surface: store, routes, providers (takeover-gated), tools,
 * and the announcement.
 * @param ctx - host plugin context.
 * @param config - resolved plugin entry config.
 */
export function apply(ctx: Context, config?: Config): void {
  const enabled = config?.enabled ?? true
  if (!enabled) return

  // The current DSH settings API edits this plugin's volatile Config fields
  // directly in the profile entry. Retain the pre-0.1.7 namespace adapter for
  // older DSH versions that still expose settings.register/get/watch.
  let current: () => Config = () => config ?? {}
  const resolve = (): Required<Pick<Config, 'enabled' | 'announceToAgent'>> & { guidance?: string } => {
    const value = current()
    return {
      enabled: value.enabled ?? true,
      announceToAgent: value.announceToAgent ?? DEFAULT_ANNOUNCE,
      ...(typeof value.guidance === 'string' && value.guidance.trim() !== '' ? { guidance: value.guidance } : {}),
    }
  }

  const store = new ConfigStore(undefined, (m) => { ctx.logger?.warn?.(m) })

  // Snapshot the file config ONCE at startup: providers/tools are rebuilt
  // on dsh restart (the panel's restart hints say so). Routes re-read the
  // store per request, so panel edits apply immediately there.
  const boot = store.load()
  const token = store.readToken()
  const tokenPresent = token !== ''
  const client = clientFromConfig(boot.connection, token)

  // Routes (panel API) — always mounted (loopback-fenced); the enabled
  // master switch governs the agent-facing surfaces only, so the panel
  // stays operable for re-enabling. Pass the client so config updates
  // can hot-reconfigure it (no restart required).
  // Session creation-time lookup for the cache tab's "this session" filter:
  // the live SessionStore owns header.createdAt (the real creation time the
  // client-side SessionSummary does not expose). Typed access through the
  // structural minimum — no hard dependency on dsh-session types.
  const getSessionCreatedAt = (sessionId: string): number | undefined => {
    const sessions = (ctx as unknown as { sessions?: { get(id: string): { header: { createdAt?: unknown } } | undefined } }).sessions
    const session = sessions?.get(sessionId)
    const createdAt = session?.header?.createdAt
    return typeof createdAt === 'number' ? createdAt : undefined
  }

  const routes = makeRoutes({ store, client, getSessionCreatedAt })
  ctx.effect(() => {
    const disposers = routes.map(route => ctx.webServer.register(route))
    return () => { for (const dispose of disposers) dispose() }
  }, 'dsh-wigolo: routes')

  let disposeTools: (() => void) | undefined
  let disposeSection: (() => void) | undefined

  const sync = (): void => {
    const value = resolve()
    // Tear down the previous registration before re-registering so
    // duplicate names never throw (dsh-ssh's sync pattern).
    if (disposeSection !== undefined) { disposeSection(); disposeSection = undefined }
    if (disposeTools !== undefined) { disposeTools(); disposeTools = undefined }
    if (!value.enabled || !tokenPresent) return

    disposeTools = ctx.effect(() => {
      const disposers = buildAllTools(client, boot.tools, boot.timezone)
        .filter((tool) => {
          const entry = boot.tools[tool.name]
          return entry?.enabled !== false
        })
        .map(tool => ctx.tools.register(tool))
      return () => { for (const dispose of disposers) dispose() }
    }, 'dsh-wigolo: tools')

    if (value.announceToAgent) {
      disposeSection = ctx.effect(() => ctx.systemPrompt.section({
        name: 'plugin:dsh-wigolo',
        order: ANNOUNCE_ORDER,
        text: value.guidance ?? WIGOLO_GUIDANCE,
      }), 'dsh-wigolo: prompt section')
    }
  }

  // Web seam providers — startup only (takeover needs a restart by design).
  if (tokenPresent && boot.takeover) {
    ctx.effect(() => ctx.web.registerSearchProvider(new WigoloSearchProvider(client, tokenPresent)), 'dsh-wigolo: search provider')
    ctx.effect(() => ctx.web.registerFetchProvider(new WigoloFetchProvider(client, tokenPresent)), 'dsh-wigolo: fetch provider')
  } else if (!tokenPresent) {
    ctx.logger?.warn?.('dsh-wigolo: no token configured (~/.dsh/wigolo-token, or paste one in the panel) — providers/tools stay unregistered')
  }

  ctx.inject(['settings'], (settingsCtx) => {
    const service = legacySettings(settingsCtx)
    if (service === undefined) return
    const scope = service.register(WIGOLO_SETTINGS_NAMESPACE, Config, {
      base: config ?? {},
      applies: 'live',
    })
    current = () => scope.get()
    scope.watch(sync)
    sync()
  })

  // Initial registration from the composition entry also covers headless or
  // newer runtimes where no legacy registration API is present.
  sync()
}
