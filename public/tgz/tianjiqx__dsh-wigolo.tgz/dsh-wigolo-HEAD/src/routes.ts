/**
 * The /api/dsh-wigolo route family: config CRUD (secret-free), connection
 * test, and takeover switching (which also syncs the cordis managed block).
 * Every route carries the same loopback-only trust fence as dsh-ssh's —
 * these endpoints read/write user-private config and must not be served to
 * LAN-exposed deployments.
 *
 * Cache/watch management is NOT exposed here — the agent tools (wigolo_cache,
 * wigolo_watch) cover it over MCP. WebRoute has no method field: each path is
 * one handler that branches on req.method internally (dsh-ssh precedent).
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import type { ConfigStore } from './store.ts'
import type { WigoloMcpClient } from './mcp-client.ts'
import { clientFromConfig } from './mcp-client.ts'
import { syncManagedBlock } from './cordis-managed.ts'
import { resolveHostHeaderFromConfig, validateConnectionPayload, validateTakeover, validateTimezone } from './config.ts'
import { WIGOLO_API, type ConnectionTestResult, type CacheEntryRow } from './protocol.ts'
import { convertUtcToTimezone, humanizeWatch } from './tool-helpers.ts'

/** Cap on JSON request bodies (config payloads are small). */
const MAX_JSON_BODY_BYTES = 64 * 1024

/** Loopback literal check plus browser same-origin markers (mirrors dsh-ssh's fence). */
function isLoopbackRequest(request: IncomingMessage): boolean {
  const address = request.socket.remoteAddress
  if (address !== '127.0.0.1' && address !== '::1' && address !== '::ffff:127.0.0.1') return false
  const host = request.headers.host
  if (typeof host !== 'string') return false
  let hostUrl: URL
  try {
    hostUrl = new URL('http://' + host)
  } catch {
    return false
  }
  if (hostUrl.hostname !== '127.0.0.1' && hostUrl.hostname !== 'localhost' && hostUrl.hostname !== '[::1]') return false
  if (request.headers['sec-fetch-site'] === 'cross-site') return false
  const origin = request.headers.origin
  if (origin === undefined) return true
  try {
    return new URL(origin).host === hostUrl.host
  } catch {
    return false
  }
}

/** One JSON response. */
function writeJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'referrer-policy': 'no-referrer' })
  res.end(payload)
}

/** Read a JSON request body (undefined when too large or unparseable). */
async function readJsonBody(req: IncomingMessage): Promise<Record<string, unknown> | undefined> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const buffer = chunk as Buffer
    size += buffer.length
    if (size > MAX_JSON_BODY_BYTES) return undefined
    chunks.push(buffer)
  }
  try {
    const parsed: unknown = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    return typeof parsed === 'object' && parsed !== null ? parsed as Record<string, unknown> : undefined
  } catch {
    return undefined
  }
}

/** Module gate for the cache tab routes: 403 when the module is off. */
function cacheTabGuard(store: ConfigStore, res: ServerResponse): boolean {
  if (!store.load().cacheTab.enabled) {
    writeJson(res, 403, { error: 'cache tab disabled' })
    return false
  }
  return true
}

/** Route family dependencies. */
export interface WigoloRoutesDeps {
  /** The config store. */
  store: ConfigStore
  /** The live MCP client — reconfigured in-place after connection edits. */
  client: WigoloMcpClient
  /** Session creation-time lookup (host cordis ctx.sessions; undefined when the service is absent). */
  getSessionCreatedAt?: (sessionId: string) => number | undefined
}

/** Build every /api/dsh-wigolo route (one handler per path, method-branched). */
export function makeRoutes(deps: WigoloRoutesDeps): WebRoute[] {
  const { store, client, getSessionCreatedAt } = deps

  /** Fresh client bound to the CURRENT config (config edits take effect on next call). */
  const liveClient = (): WigoloMcpClient | undefined => {
    const token = store.readToken()
    if (token === '') return undefined
    return clientFromConfig(store.load().connection, token)
  }

  const guard = (req: IncomingMessage, res: ServerResponse): boolean => {
    if (!isLoopbackRequest(req)) {
      writeJson(res, 403, { error: 'forbidden: loopback-only' })
      return false
    }
    return true
  }

  const routes: WebRoute[] = [
    // config: GET summary | PUT connection update
    {
      kind: 'exact',
      path: WIGOLO_API.config,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (req.method === 'GET') {
          writeJson(res, 200, store.summarize())
          return
        }
        if (req.method !== 'PUT') { writeJson(res, 405, { error: 'method not allowed' }); return }
        const body = await readJsonBody(req)
        if (body === undefined) { writeJson(res, 400, { error: 'invalid JSON body' }); return }
        const err = validateConnectionPayload(body)
        if (err !== undefined) { writeJson(res, 400, { error: err }); return }
        // cacheTab toggle rides the same PUT: boolean, applied atomically.
        if (body.cacheTab !== undefined && typeof body.cacheTab !== 'boolean') {
          writeJson(res, 400, { error: 'cacheTab must be a boolean' }); return
        }
        if (body.timezone !== undefined) {
          const tzErr = validateTimezone(body.timezone)
          if (tzErr !== undefined) { writeJson(res, 400, { error: tzErr }); return }
        }
        const updated = store.update((current) => ({
          ...current,
          ...(body.cacheTab !== undefined ? { cacheTab: { enabled: body.cacheTab as boolean } } : {}),
          ...(body.timezone !== undefined ? { timezone: body.timezone as string } : {}),
          connection: {
            host: typeof body.host === 'string' ? body.host : current.connection.host,
            port: typeof body.port === 'number' ? body.port : current.connection.port,
            hostHeader: typeof body.hostHeader === 'string' ? body.hostHeader : current.connection.hostHeader,
            tokenFile: typeof body.tokenFile === 'string' ? body.tokenFile : current.connection.tokenFile,
          },
        }))
        // Hot-reconfigure the live client so tool calls use the new connection
        // immediately — no DSH restart required.
        const hostHeader = resolveHostHeaderFromConfig(updated.connection)
        client.reconfigure(
          { host: updated.connection.host, port: updated.connection.port, hostHeader: hostHeader ?? '' },
          store.readToken(),
        )
        writeJson(res, 200, { ...store.summarize(), restartHint: undefined })
      },
    },
    // tools: PUT exposure update
    {
      kind: 'exact',
      path: WIGOLO_API.tools,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (req.method !== 'PUT') { writeJson(res, 405, { error: 'method not allowed (PUT)' }); return }
        const body = await readJsonBody(req)
        if (body === undefined) { writeJson(res, 400, { error: 'invalid JSON body' }); return }
        if (typeof body.tools !== 'object' || body.tools === null) { writeJson(res, 400, { error: 'tools must be an object' }); return }
        store.update((current) => ({ ...current, tools: body.tools as Record<string, { enabled: boolean }> }))
        writeJson(res, 200, { ...store.summarize(), restartHint: 'restart dsh to apply tool exposure changes' })
      },
    },
    // token: PUT writes the 0600 token file (the secret is never read back)
    {
      kind: 'exact',
      path: WIGOLO_API.token,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (req.method !== 'PUT') { writeJson(res, 405, { error: 'method not allowed (PUT)' }); return }
        const body = await readJsonBody(req)
        const token = body?.token
        if (typeof token !== 'string' || token.trim() === '') { writeJson(res, 400, { error: 'token must be a non-empty string' }); return }
        try {
          store.writeToken(token)
          // Hot-reconfigure so agent tool calls pick up the new token
          // immediately — same no-restart semantics as connection edits.
          const config = store.load()
          const hostHeader = resolveHostHeaderFromConfig(config.connection)
          client.reconfigure(
            { host: config.connection.host, port: config.connection.port, hostHeader: hostHeader ?? '' },
            store.readToken(),
          )
          writeJson(res, 200, { ok: true, hasToken: true })
        } catch (err) {
          writeJson(res, 500, { ok: false, error: err instanceof Error ? err.message : String(err) })
        }
      },
    },
    // connection test — accepts optional connection params so the panel can
    // probe with unsaved form values (host/port/hostHeader) before committing.
    {
      kind: 'exact',
      path: WIGOLO_API.test,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (req.method !== 'POST') { writeJson(res, 405, { error: 'method not allowed (POST)' }); return }
        const body = await readJsonBody(req)
        // If the request carries connection overrides, build a one-shot client
        // from them instead of the saved config — this lets the panel test
        // values before clicking Save.
        const hasOverride = body !== undefined && (
          body.host !== undefined || body.port !== undefined ||
          body.hostHeader !== undefined || body.tokenFile !== undefined
        )
        if (hasOverride) {
          const saved = store.load()
          const conn = {
            host: typeof body.host === 'string' && body.host.trim() !== '' ? body.host : saved.connection.host,
            port: typeof body.port === 'number' ? body.port : saved.connection.port,
            hostHeader: typeof body.hostHeader === 'string' ? body.hostHeader : saved.connection.hostHeader,
            tokenFile: typeof body.tokenFile === 'string' ? body.tokenFile : saved.connection.tokenFile,
          }
          // The token follows the (possibly overridden) tokenFile, so probing
          // an unsaved token path tests what the user actually sees.
          const token = store.readTokenFrom(conn.tokenFile)
          if (token === '') { writeJson(res, 400, { ok: false, error: 'no token configured' }); return }
          const probeClient = clientFromConfig(conn, token)
          const result: ConnectionTestResult = await probeClient.probe()
          writeJson(res, result.ok ? 200 : 502, result)
          return
        }
        const client = liveClient()
        if (client === undefined) { writeJson(res, 400, { ok: false, error: 'no token configured' }); return }
        const result: ConnectionTestResult = await client.probe()
        writeJson(res, result.ok ? 200 : 502, result)
      },
    },
    // takeover switch
    {
      kind: 'exact',
      path: WIGOLO_API.takeover,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (req.method !== 'PUT') { writeJson(res, 405, { error: 'method not allowed (PUT)' }); return }
        const body = await readJsonBody(req)
        const takeover = body?.takeover
        const err = validateTakeover(takeover)
        if (err !== undefined) { writeJson(res, 400, { error: err }); return }
        const takeoverBool = takeover as boolean
        const restartNeeded = syncManagedBlock(takeoverBool)
        store.update((current) => ({ ...current, takeover: takeoverBool }))
        writeJson(res, 200, {
          ok: true,
          takeover: takeoverBool,
          restartNeeded,
          message: restartNeeded ? 'cordis routing updated — restart dsh to apply' : 'routing already up to date',
        })
      },
    },
    // -- cache tab (read-only browser over the daemon cache/watch; module-gated) --
    // cache list — metadata only, markdown stripped host-side
    {
      kind: 'exact',
      path: WIGOLO_API.cacheTabList,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (!cacheTabGuard(store, res)) return
        if (req.method !== 'GET') { writeJson(res, 405, { error: 'method not allowed (GET)' }); return }
        const u = new URL(req.url ?? '/', 'http://localhost')
        const limitRaw = Number(u.searchParams.get('limit') ?? '50')
        const limit = Number.isInteger(limitRaw) ? Math.min(Math.max(limitRaw, 1), 200) : 50
        try {
          const payload = await client.callToolObject('cache', { limit })
          const rows: CacheEntryRow[] = (Array.isArray(payload.results) ? payload.results : [])
            .map((r) => {
              const item = (r ?? {}) as Record<string, unknown>
              return {
                url: typeof item.url === 'string' ? item.url : '',
                title: typeof item.title === 'string' ? item.title : '',
                fetched_at: typeof item.fetched_at === 'string' ? convertUtcToTimezone(item.fetched_at, store.load().timezone) : '',
              }
            })
            .filter((r) => r.url !== '')
          writeJson(res, 200, { entries: rows })
        } catch (err) {
          writeJson(res, 502, { error: err instanceof Error ? err.message : String(err) })
        }
      },
    },
    // cache stats strip
    {
      kind: 'exact',
      path: WIGOLO_API.cacheTabStats,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (!cacheTabGuard(store, res)) return
        if (req.method !== 'GET') { writeJson(res, 405, { error: 'method not allowed (GET)' }); return }
        try {
          const payload = await client.callToolObject('cache', { stats: true })
          const s = (payload.stats ?? {}) as Record<string, unknown>
          writeJson(res, 200, {
            stats: {
              total_urls: typeof s.total_urls === 'number' ? s.total_urls : 0,
              total_size_mb: typeof s.total_size_mb === 'number' ? Number(s.total_size_mb.toFixed(1)) : 0,
              ...(typeof s.oldest === 'string' ? { oldest: convertUtcToTimezone(s.oldest, store.load().timezone) } : {}),
              ...(typeof s.newest === 'string' ? { newest: convertUtcToTimezone(s.newest, store.load().timezone) } : {}),
            },
          })
        } catch (err) {
          writeJson(res, 502, { error: err instanceof Error ? err.message : String(err) })
        }
      },
    },
    // single entry markdown — lazy-loaded detail (exact URL only; glob substring needs leading *)
    {
      kind: 'exact',
      path: WIGOLO_API.cacheTabEntry,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (!cacheTabGuard(store, res)) return
        if (req.method !== 'GET') { writeJson(res, 405, { error: 'method not allowed (GET)' }); return }
        const u = new URL(req.url ?? '/', 'http://localhost')
        const target = u.searchParams.get('url') ?? ''
        if (target.trim() === '') { writeJson(res, 400, { error: 'url query param required' }); return }
        try {
          // The daemon's cache matches url_pattern (full-length glob) against a
          // NORMALIZED key: trailing slashes stripped AND a leading 'www.' on
          // the host removed (protocol kept), while results carry the original
          // URL. So query with the same normalization as an EXACT pattern — no
          // wildcards — to avoid cross-matching sibling URLs; fall back to a
          // wildcard probe only if the exact form misses (unknown norms).
          const normalized = target.replace(/\*+/g, '')
            .replace(/\/+$/, '')
            .replace(/^(https?:\/\/)www\./, '$1')
          let payload = await client.callToolObject('cache', { url_pattern: normalized, limit: 10 })
          let rows = Array.isArray(payload.results) ? payload.results : []
          if (rows.length === 0 && normalized !== target) {
            payload = await client.callToolObject('cache', { url_pattern: '*' + normalized + '*', limit: 10 })
            rows = Array.isArray(payload.results) ? payload.results : []
          }
          // Last resort for entries whose key the daemon REWROTE (redirect
          // canonicalization): '.../crypto/bitcoin/' keyed as '.../crypto/all',
          // 'en.m.wikipedia.org' keyed as 'en.wikipedia.org', or a fully
          // rewritten path keyed under the host root. Probe prefix globs over
          // host variants (original / www-stripped / m-segment-stripped) ×
          // path prefixes (parent dir first, then host root), keeping only
          // rows whose ORIGINAL url equals the requested target.
          if (rows.length === 0) {
            try {
              const t = new URL(target)
              const parent = t.pathname.replace(/\/+$/, '').replace(/\/[^/]*$/, '')
              const prefixes: string[] = []
              if (parent !== '' && parent !== '/') prefixes.push(parent)
              prefixes.push('')
              const hosts = [t.hostname, t.hostname.replace(/^www\./, ''), t.hostname.replace(/\b(?:www\.)?m\./, '')]
              outer: for (const prefix of prefixes) {
                for (const host of new Set(hosts)) {
                  const pattern = t.protocol + '//' + host + prefix + '/*'
                  payload = await client.callToolObject('cache', { url_pattern: pattern, limit: 10 })
                  const hits = (Array.isArray(payload.results) ? payload.results : [])
                    .filter((r) => (r as Record<string, unknown>).url === target)
                  if (hits.length > 0) { rows = hits; break outer }
                }
              }
            } catch { /* invalid URL — skip prefix fallback */ }
          }
          if (rows.length === 0) { writeJson(res, 404, { error: 'not found in cache' }); return }
          // Prefer the row whose ORIGINAL url equals the requested target;
          const item = (rows.find((r) => (r as Record<string, unknown>).url === target) ?? rows[0] ?? {}) as Record<string, unknown>
          writeJson(res, 200, {
            url: target,
            markdown: typeof item.markdown === 'string' ? item.markdown : '',
            fetched_at: typeof item.fetched_at === 'string' ? item.fetched_at : '',
          })
        } catch (err) {
          writeJson(res, 502, { error: err instanceof Error ? err.message : String(err) })
        }
      },
    },
    // watch jobs — GET list (humanized) | POST check/pause/resume (no create/delete)
    {
      kind: 'exact',
      path: WIGOLO_API.cacheTabWatch,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (!cacheTabGuard(store, res)) return
        if (req.method === 'GET') {
          try {
            const payload = await client.callToolObject('watch', { action: 'list' })
            writeJson(res, 200, humanizeWatch(payload))
          } catch (err) {
            writeJson(res, 502, { error: err instanceof Error ? err.message : String(err) })
          }
          return
        }
        if (req.method !== 'POST') { writeJson(res, 405, { error: 'method not allowed (GET|POST)' }); return }
        const body = await readJsonBody(req)
        const action = body?.action
        const jobId = body?.job_id
        if (action !== 'check' && action !== 'pause' && action !== 'resume') {
          writeJson(res, 400, { error: 'action must be check | pause | resume' }); return
        }
        if (typeof jobId !== 'string' || jobId.trim() === '') { writeJson(res, 400, { error: 'job_id required' }); return }
        try {
          const payload = await client.callToolObject('watch', { action, job_id: jobId })
          writeJson(res, 200, humanizeWatch(payload))
        } catch (err) {
          writeJson(res, 502, { error: err instanceof Error ? err.message : String(err) })
        }
      },
    },
    // -- session info: the "this session" filter's anchor (real creation time) --
    // Replaces the old PAGE_LOADED_AT approximation: the client passes the
    // slot-injected sessionId and gets header.createdAt back. 404 when the
    // session is not live (or the sessions service is absent) — the client
    // then hides the "this session" option rather than filtering wrong.
    {
      kind: 'exact',
      path: WIGOLO_API.cacheTabSession,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (!cacheTabGuard(store, res)) return
        if (req.method !== 'GET') { writeJson(res, 405, { error: 'method not allowed (GET)' }); return }
        const u = new URL(req.url ?? '/', 'http://localhost')
        const sessionId = u.searchParams.get('sessionId') ?? ''
        if (sessionId.trim() === '') { writeJson(res, 400, { error: 'sessionId query param required' }); return }
        const createdAt = getSessionCreatedAt?.(sessionId)
        if (typeof createdAt !== 'number') { writeJson(res, 404, { error: 'session not live' }); return }
        writeJson(res, 200, { sessionId, createdAt })
      },
    },
    // -- guide: serve the bundled usage guide for the in-panel help tab --
    {
      kind: 'exact',
      path: WIGOLO_API.guide,
      handler: async (req, res) => {
        if (!guard(req, res)) return
        if (req.method !== 'GET') { writeJson(res, 405, { error: 'method not allowed (GET)' }); return }
        // Guide content is inlined at build time via tsdown's define option
        // (avoids runtime filesystem path resolution issues after bundling).
        // The browser's locale selects the variant through the ?lang= param.
        const u = new URL(req.url ?? '/', 'http://localhost')
        const lang = u.searchParams.get('lang') ?? 'zh'
        const markdown = lang === 'en' ? __GUIDE_EN_CONTENT__ : __GUIDE_CONTENT__
        writeJson(res, 200, { markdown })
      },
    },
  ]
  return routes
}
