/**
 * Cordis managed-block management: the takeover switch writes/removes a
 * self-managed block in ~/.dsh/cordis.patch.yml (dsh-skin precedent) that
 * routes the web seam's searchProvider/fetchProvider to wigolo. A restart
 * of dsh is required for the routing to take effect — the panel says so.
 */

import { existsSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import { CORDIS_MANAGED_BEGIN, CORDIS_MANAGED_END } from './invariant.ts'
import type { TakeoverMode } from './protocol.ts'

/** The home-layer cordis patch file. */
export function cordisPatchPath(): string {
  return join(homedir(), '.dsh', 'cordis.patch.yml')
}

/** Lines of the managed block for a takeover mode (empty array = remove the block). */
function blockFor(takeover: TakeoverMode): string[] {
  if (!takeover) return []
  const lines = [CORDIS_MANAGED_BEGIN,
    '- id: web',
    "  name: '@deepseek-ai/dsh-web'",
    '  config:',
    '    searchProvider: wigolo',
    '    fetchProvider: wigolo',
    CORDIS_MANAGED_END]
  return lines
}

/** Whether a managed block currently exists in the file content. */
export function hasManagedBlock(content: string): boolean {
  return content.includes(CORDIS_MANAGED_BEGIN)
}

/** Remove any existing managed block from the file content (no-op when absent). */
export function stripManagedBlock(content: string): string {
  const begin = content.indexOf(CORDIS_MANAGED_BEGIN)
  if (begin === -1) return content
  const endMarker = content.indexOf(CORDIS_MANAGED_END, begin)
  const end = endMarker === -1 ? content.length : endMarker + CORDIS_MANAGED_END.length
  let rest = content.slice(0, begin) + content.slice(end)
  // Collapse the blank-line run the block leaves behind (keep at most one).
  rest = rest.replace(/\n{3,}/g, '\n\n')
  return rest.trimEnd() + '\n'
}

/** Splice a fresh managed block in at the end of the file content. */
export function insertManagedBlock(content: string, takeover: TakeoverMode): string {
  const base = stripManagedBlock(content)
  if (!takeover) return base
  const block = blockFor(takeover)
  return base.trimEnd() + '\n\n' + block.join('\n') + '\n'
}

/**
 * Sync the managed block to match the takeover mode (atomic write).
 * @param takeover - the desired routing.
 * @returns whether the file changed (a dsh restart applies it).
 */
export function syncManagedBlock(takeover: TakeoverMode): boolean {
  const path = cordisPatchPath()
  const before = existsSync(path) ? readFileSync(path, 'utf8') : ''
  const after = insertManagedBlock(before, takeover)
  if (after === before) return false
  const dir = dirname(path)
  const tmp = join(dir, '.cordis.patch.yml.' + process.pid + '.' + Date.now() + '.tmp')
  writeFileSync(tmp, after)
  renameSync(tmp, path)
  return true
}

/** Read which routing the current managed block encodes (undefined = no block). */
export function readManagedTakeover(content: string): TakeoverMode | undefined {
  if (!hasManagedBlock(content)) return undefined
  const hasSearch = /searchProvider:\s*wigolo/.test(content)
  const hasFetch = /fetchProvider:\s*wigolo/.test(content)
  return hasSearch && hasFetch
}
