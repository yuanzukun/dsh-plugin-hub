/**
 * Config schema, defaults, validation, and legacy migration.
 *
 * Storage: ~/.dsh/wigolo.json (version 2), written atomically (tmp + rename),
 * same trust model as dsh-ssh's host store. The token itself NEVER lives in
 * this file — it stays in its own 0600 file (default ~/.dsh/wigolo-token),
 * so the config file is safe to render in the panel and in error messages.
 */

import { existsSync, readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import {
  DEFAULT_TOKEN_FILE_NAME,
  LEGACY_ENV_HOST,
  LEGACY_ENV_PORT,
} from './invariant.ts'
import type { ConnectionConfig, WigoloConfig } from './protocol.ts'

// Note: the cordis/schemastery entry schema lands with the settings-section
// integration in P2; P1 validation is the hand-rolled kind below, which the
// store's normalize() already applies.

/** Plugin-level config as seen by cordis (subset exposed in the composition layer). */
export interface PluginEntryConfig {
  enabled?: boolean
}

// ---------------------------------------------------------------------------
// Defaults
// ---------------------------------------------------------------------------

/** Tool ids exposed by the plugin (keys of tools config). */
export const TOOL_IDS = [
  'wigolo_search',
  'wigolo_crawl',
  'wigolo_extract',
  'wigolo_research',
  'wigolo_find_similar',
  'wigolo_cache',
  'wigolo_watch',
] as const
export type ToolId = (typeof TOOL_IDS)[number]

/** Sensible per-tool defaults (disabled ones still carry defaults for the panel). */
function defaultTools(): Record<ToolId, { enabled: boolean; defaults?: Record<string, unknown>; timeoutMs?: number }> {
  return {
    wigolo_search: { enabled: true, defaults: { max_results: 10, search_depth: 'balanced' } },
    wigolo_crawl: { enabled: true, defaults: { max_pages: 50 }, timeoutMs: 300_000 },
    wigolo_extract: { enabled: true },
    wigolo_research: { enabled: true, timeoutMs: 600_000 },
    wigolo_find_similar: { enabled: false },
    wigolo_cache: { enabled: true },
    wigolo_watch: { enabled: true },
  }
}

/** The stock config a fresh install gets. */
export function defaultConfig(): WigoloConfig {
  return {
    version: 2,
    connection: {
      host: '127.0.0.1',
      port: 3333,
      hostHeader: 'auto',
      tokenFile: '',
    },
    takeover: false,
    tools: defaultTools(),
    announceToAgent: true,
    cacheTab: { enabled: false },
    timezone: 'local',
  }
}

/** Resolve the effective token file path ('' means the default location). */
export function resolveTokenFilePath(config: WigoloConfig): string {
  if (config.connection.tokenFile.trim() !== '') return expandHome(config.connection.tokenFile.trim())
  return join(homedir(), '.dsh', DEFAULT_TOKEN_FILE_NAME)
}

/** Expand a leading ~ in a user-provided path. */
export function expandHome(p: string): string {
  if (p === '~') return homedir()
  if (p.startsWith('~/')) return join(homedir(), p.slice(2))
  return p
}

// ---------------------------------------------------------------------------
// Legacy setup detection
// ---------------------------------------------------------------------------

/**
 * Detect a legacy setup (env vars or token file) and return connection
 * overrides to import. Returns undefined when nothing to import. Pure
 * function of env + fs (injectable for tests).
 */
export function detectLegacySetup(env: NodeJS.ProcessEnv = process.env, exists = existsSync, readFile = readFileSync): {
  host?: string
  port?: number
  hasTokenFile: boolean
} | undefined {
  const legacyTokenPath = join(homedir(), '.dsh', DEFAULT_TOKEN_FILE_NAME)
  const hasTokenFile = exists(legacyTokenPath)
  const host = env[LEGACY_ENV_HOST]
  const port = env[LEGACY_ENV_PORT]
  if (host === undefined && port === undefined && !hasTokenFile) return undefined
  const result: { host?: string; port?: number; hasTokenFile: boolean } = { hasTokenFile }
  if (typeof host === 'string' && host.trim() !== '') result.host = host.trim()
  if (typeof port === 'string' && Number.isInteger(Number(port)) && Number(port) > 0) result.port = Number(port)
  return result
}

/** Merge legacy detection into a fresh config (first-run import). */
export function applyLegacyImport(config: WigoloConfig, legacy: ReturnType<typeof detectLegacySetup>): WigoloConfig {
  if (legacy === undefined) return config
  return {
    ...config,
    connection: {
      ...config.connection,
      ...(legacy.host !== undefined ? { host: legacy.host } : {}),
      ...(legacy.port !== undefined ? { port: legacy.port } : {}),
    },
  }
}

// ---------------------------------------------------------------------------
// Validation helpers (wire payloads)
// ---------------------------------------------------------------------------

/** Validate a connection payload from the panel; returns a message or undefined. */
export function validateConnectionPayload(payload: unknown): string | undefined {
  if (typeof payload !== 'object' || payload === null) return 'body must be a JSON object'
  const p = payload as Record<string, unknown>
  if (p.host !== undefined && (typeof p.host !== 'string' || p.host.trim() === '')) return 'host must be a non-empty string'
  if (p.port !== undefined && (typeof p.port !== 'number' || !Number.isInteger(p.port) || p.port < 1 || p.port > 65535)) {
    return 'port must be an integer in 1..65535'
  }
  if (p.hostHeader !== undefined && typeof p.hostHeader !== 'string') return 'hostHeader must be a string'
  if (p.hostHeader === 'auto' || p.hostHeader === 'none' || p.hostHeader === undefined) return undefined
  if (p.hostHeader.trim() === '') return 'hostHeader must be auto, none, or a non-empty literal'
  if (p.tokenFile !== undefined && typeof p.tokenFile !== 'string') return 'tokenFile must be a string'
  return undefined
}

/** Validate a takeover value. */
export function validateTakeover(value: unknown): string | undefined {
  if (typeof value === 'boolean') return undefined
  return 'takeover must be a boolean'
}

/** Validate a timezone value. */
export function validateTimezone(value: unknown): string | undefined {
  if (typeof value !== 'string') return 'timezone must be a string'
  const tz = value.trim()
  if (tz === '' || tz === 'local') return undefined
  // Check numeric offset like "+8", "-5", "+5.5"
  if (/^[+-]\d+(?:\.\d+)?$/.test(tz)) return undefined
  // Check IANA timezone name (basic validation)
  try {
    Intl.DateTimeFormat(undefined, { timeZone: tz })
    return undefined
  } catch {
    return 'timezone must be "local", a numeric offset like "+8", or a valid IANA timezone name'
  }
}

// ---------------------------------------------------------------------------
// Host header resolution
// ---------------------------------------------------------------------------

/** Local hostnames/addresses on wigolo's DNS-rebinding allowlist by default. */
const LOCAL_HOSTS = new Set(['localhost', '127.0.0.1', '[::1]', '::1', '0.0.0.0'])

/**
 * Resolve the Host header to send: undefined = default; 'auto' sends no
 * custom header for local targets and the bind-host trick for remote ones.
 */
export function resolveHostHeaderFromConfig(connection: Pick<ConnectionConfig, 'host' | 'hostHeader'>): string | undefined {
  if (connection.hostHeader === 'none') return undefined
  if (connection.hostHeader !== 'auto') return connection.hostHeader
  return LOCAL_HOSTS.has(connection.host) ? undefined : '0.0.0.0'
}
