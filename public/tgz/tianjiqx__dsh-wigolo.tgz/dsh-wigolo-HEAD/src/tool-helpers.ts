/**
 * Tool-definition helpers over the official defineTool DSL: every wigolo_*
 * tool uses ValueSchemaSpec specs (compiled, validated) instead of raw JSON
 * Schema objects. Parameters stay trimmed to the model's high-frequency set.
 */

import type { ToolConfig } from './protocol.ts'

/**
 * Parse timezone configuration into a usable format.
 * Supports:
 * - "local" → use system local timezone
 * - IANA timezone names like "Asia/Shanghai"
 * - Numeric offsets like "+8", "-5", "+5.5", "-9.5"
 */
export function parseTimezone(tz: string): string {
  if (!tz || tz === 'local') {
    // Return empty string to indicate "use local timezone"
    return ''
  }
  
  // Check if it's a numeric offset like "+8", "-5", "+5.5"
  const numericMatch = tz.match(/^([+-])(\d+(?:\.\d+)?)$/)
  if (numericMatch) {
    const [, sign, hours] = numericMatch
    const numHours = parseFloat(hours)
    const totalMinutes = Math.round(numHours * 60)
    const absMinutes = Math.abs(totalMinutes)
    const h = Math.floor(absMinutes / 60)
    const m = absMinutes % 60
    // Convert to ISO 8601 offset format like "+08:00" or "-05:30"
    return `${sign}${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`
  }
  
  // Assume it's an IANA timezone name
  return tz
}

/**
 * Convert a UTC timestamp string to the specified timezone.
 * Input format: "YYYY-MM-DD HH:MM:SS" (zone-less UTC from wigolo daemon)
 * Output format: "YYYY-MM-DD HH:MM:SS" in the target timezone
 */
export function convertUtcToTimezone(utcTime: string, timezone: string): string {
  if (!utcTime) return utcTime
  
  // Parse the zone-less UTC timestamp
  // Add 'Z' to explicitly mark it as UTC for JavaScript's Date parser
  const date = new Date(utcTime.replace(' ', 'T') + 'Z')
  
  if (isNaN(date.getTime())) {
    // If parsing fails, return as-is
    return utcTime
  }
  
  const parsedTz = parseTimezone(timezone)
  
  if (parsedTz === '') {
    // Use local timezone
    return date.toLocaleString('sv-SE', { 
      hour12: false 
    }).slice(0, 19)
  }
  
  // Check if it's a fixed offset (ISO 8601 format like "+08:00")
  if (/^[+-]\d{2}:\d{2}$/.test(parsedTz)) {
    // Parse the offset
    const [sign, hh, mm] = parsedTz.match(/([+-])(\d{2}):(\d{2})/)!.slice(1)
    const offsetMinutes = (sign === '+' ? 1 : -1) * (parseInt(hh) * 60 + parseInt(mm))
    
    // Apply the offset
    const localDate = new Date(date.getTime() + offsetMinutes * 60 * 1000)
    
    // Format as "YYYY-MM-DD HH:MM:SS"
    const year = localDate.getUTCFullYear()
    const month = String(localDate.getUTCMonth() + 1).padStart(2, '0')
    const day = String(localDate.getUTCDate()).padStart(2, '0')
    const hours = String(localDate.getUTCHours()).padStart(2, '0')
    const minutes = String(localDate.getUTCMinutes()).padStart(2, '0')
    const seconds = String(localDate.getUTCSeconds()).padStart(2, '0')
    
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
  }
  
  // Use IANA timezone
  try {
    return date.toLocaleString('sv-SE', { 
      timeZone: parsedTz,
      hour12: false 
    }).slice(0, 19)
  } catch {
    // If timezone is invalid, fall back to UTC
    return utcTime
  }
}

/** Shared property builders (concise descriptions for the model). */
export const P = {
  query: () => ({ type: 'string', description: 'Search query, or multiple "|" separated variants for parallel search and dedup (e.g. "rust async | tokio vs async-std").' } as const),
  url: () => ({ type: 'string', description: 'Target URL.' } as const),
  maxResults: (def: number) => ({ type: 'number', description: 'Max results (default ' + def + ', max 20).' } as const),
  timeRange: () => ({ type: 'string', description: 'Freshness filter: day | week | month | year.' } as const),
  fromDate: () => ({ type: 'string', description: 'ISO date YYYY-MM-DD — only results published after.' } as const),
  toDate: () => ({ type: 'string', description: 'ISO date YYYY-MM-DD — only results published before.' } as const),
  includeDomains: () => ({ type: 'array', items: { type: 'string' }, description: 'Only return results from these domains.' } as const),
  excludeDomains: () => ({ type: 'array', items: { type: 'string' }, description: 'Never return results from these domains.' } as const),
  searchDepth: () => ({ type: 'string', description: 'ultra-fast (cache-only) | fast (engines only) | balanced (default) | deep (full enrichment).' } as const),
  forceRefresh: () => ({ type: 'boolean', description: 'Bypass caches — use for news, prices, status pages.' } as const),
  exactMatch: () => ({ type: 'boolean', description: 'Treat the query as a quoted phrase.' } as const),
  category: () => ({ type: 'string', description: 'Result category: general | news | code | docs | papers | images.' } as const),
}

/** Merge config defaults under the model's explicit args (model wins). */
export function mergeDefaults(defaults: Record<string, unknown> | undefined, args: Record<string, unknown>): Record<string, unknown> {
  return { ...(defaults ?? {}), ...args }
}

/** Copy a string arg into out when non-empty. */
export function takeString(args: Record<string, unknown>, from: string, to: string, out: Record<string, unknown>): void {
  const v = args[from]
  if (typeof v === 'string' && v.trim() !== '') out[to] = v.trim()
}

/** Copy a clamped number arg. */
export function takeNumber(args: Record<string, unknown>, from: string, to: string, out: Record<string, unknown>, min: number, max: number): void {
  const v = args[from]
  if (typeof v === 'number' && Number.isFinite(v)) out[to] = Math.min(Math.max(Math.trunc(v), min), max)
}

/** Copy a boolean arg. */
export function takeBoolean(args: Record<string, unknown>, from: string, to: string, out: Record<string, unknown>): void {
  const v = args[from]
  if (typeof v === 'boolean') out[to] = v
}

/** Copy a non-empty string-array arg. */
export function takeStringArray(args: Record<string, unknown>, from: string, to: string, out: Record<string, unknown>): void {
  const v = args[from]
  if (Array.isArray(v) && v.length > 0 && v.every((x) => typeof x === 'string')) out[to] = v
}

/** Normalize a wigolo results array into the compact source shape (scored). */
export function toSources(payload: Record<string, unknown>, cap: number): Array<{ url: string; title?: string; snippet?: string; score?: number; publishedAt?: string }> {
  const raw = Array.isArray(payload.results) ? payload.results : []
  return raw
    .map((r) => {
      const item = (r ?? {}) as Record<string, unknown>
      return {
        url: typeof item.url === 'string' ? item.url : '',
        ...(typeof item.title === 'string' && item.title !== '' ? { title: item.title } : {}),
        ...(typeof item.snippet === 'string' && item.snippet !== '' ? { snippet: item.snippet } : {}),
        ...(typeof item.relevance_score === 'number' ? { score: Number(item.relevance_score.toFixed(3)) } : {}),
        ...(typeof item.published_date === 'string' && item.published_date !== '' ? { publishedAt: item.published_date } : {}),
      }
    })
    .filter((s) => s.url.length > 0)
    .slice(0, cap)
}

/**
 * Annotate wigolo_extract responses: make selector misses explicit instead of
 * silently returning page metadata, and hint at cached crawl snapshots so the
 * model can pivot to offline reuse.
 */
export function annotateExtract(payload: Record<string, unknown>, mcpArgs: Record<string, unknown>): Record<string, never> {
  return annotateExtractInner(payload, mcpArgs) as Record<string, never>
}

function annotateExtractInner(payload: Record<string, unknown>, mcpArgs: Record<string, unknown>): Record<string, unknown> {
  const wantedSelector = typeof mcpArgs.css_selector === 'string' || (mcpArgs.schema !== undefined && mcpArgs.schema !== null)
  if (!wantedSelector) return payload
  // Real daemon shape: { data: {...}, source_url, mode, response_time_ms }. Selector
  // results land in data too — a data object holding ONLY metadata keys means the
  // selector missed and the daemon silently fell back to page metadata.
  const META_KEYS = ['title', 'description', 'og_image', 'og_type', 'canonical_url', 'url']
  const data = (payload.data ?? {}) as Record<string, unknown>
  const dataKeys = Object.keys(data)
  const dataIsMetaOnly = dataKeys.length > 0 && dataKeys.every((k) => META_KEYS.includes(k))
  const hasDirectMatch = payload.extracted !== undefined || payload.matches !== undefined
    || payload.fields !== undefined || payload.rows !== undefined
    || Array.isArray(payload.data) || (Array.isArray(payload.results) && payload.results.length > 0)
  const matched = hasDirectMatch || !dataIsMetaOnly
  if (matched) return { ...payload, selector_matched: true }
  return {
    ...payload,
    selector_matched: false,
    fallback: 'metadata-only',
    hint: 'CSS selector did not match the server-rendered DOM (common on JS-rendered SPA pages). Try: (1) wigolo_crawl the URL first and parse the markdown, (2) wigolo_cache search for an existing snapshot of this URL.',
  }
}

/**
 * Humanize wigolo_watch payloads: readable next-check timing so the model does
 * not have to interpret raw negative staleness seconds.
 */
export function humanizeWatch(payload: Record<string, unknown>): Record<string, never> {
  return humanizeWatchInner(payload) as Record<string, never>
}

function humanizeWatchInner(payload: Record<string, unknown>): Record<string, unknown> {
  const fmt = (secs: number): string => {
    const s = Math.max(0, Math.round(secs))
    if (s < 60) return s + 's'
    if (s < 3600) return Math.floor(s / 60) + 'm' + (s % 60 !== 0 ? (s % 60) + 's' : '')
    const h = Math.floor(s / 3600)
    const m = Math.floor((s % 3600) / 60)
    return h + 'h' + (m !== 0 ? m + 'm' : '')
  }
  const decorate = (job: Record<string, unknown>): Record<string, unknown> => {
    if (typeof job.staleness_seconds === 'number') {
      const v = job.staleness_seconds
      return { ...job, next_check_in: v <= 0 ? fmt(-v) + ' (until next check)' : 'overdue by ' + fmt(v) }
    }
    return job
  }
  if (Array.isArray(payload.jobs)) return { ...payload, jobs: payload.jobs.map((j) => decorate((j ?? {}) as Record<string, unknown>)) }
  if (Array.isArray(payload.watches)) return { ...payload, watches: payload.watches.map((j) => decorate((j ?? {}) as Record<string, unknown>)) }
  if (payload.job && typeof payload.job === 'object') return { ...payload, job: decorate(payload.job as Record<string, unknown>) }
  if (typeof payload.staleness_seconds === 'number') return decorate(payload)
  return payload
}

/** Render scored [score] title | url lines plus wigolo telemetry. */
export function renderSources(value: unknown): string {
  const v = (value ?? {}) as { sources?: Array<{ score?: number; title?: string; url: string; publishedAt?: string; snippet?: string }>; engines_used?: string[]; total_time_ms?: number }
  const srcs = v.sources ?? []
  if (srcs.length === 0) return 'wigolo returned no results.'
  const lines: string[] = []
  for (const s of srcs) {
    const score = typeof s.score === 'number' ? '[' + s.score + '] ' : ''
    const date = s.publishedAt !== undefined ? ' (' + String(s.publishedAt).slice(0, 10) + ')' : ''
    lines.push(score + (s.title ?? s.url) + date)
    lines.push('  ' + s.url)
    if (s.snippet !== undefined) lines.push('  ' + String(s.snippet).slice(0, 200))
  }
  if (Array.isArray(v.engines_used) && v.engines_used.length > 0) lines.push('engines: ' + v.engines_used.join(', '))
  if (typeof v.total_time_ms === 'number') lines.push('time: ' + v.total_time_ms + 'ms')
  return lines.join('\n')
}

/** Truncate a long text payload for the model view. */
export function clip(text: string, max: number): string {
  if (text.length <= max) return text
  return text.slice(0, max) + '\n...[truncated ' + (text.length - max) + ' chars]'
}

/** Resolve the effective timeout (config override or default). */
export function effectiveTimeout(config: ToolConfig, fallback: number): number {
  return config.timeoutMs !== undefined && config.timeoutMs > 0 ? config.timeoutMs : fallback
}
