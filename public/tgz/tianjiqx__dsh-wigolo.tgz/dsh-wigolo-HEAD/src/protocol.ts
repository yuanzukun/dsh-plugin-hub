/**
 * Wire types shared by the host half (routes/tools) and the browser half
 * (panel). Mirrors the dsh-ssh protocol.ts pattern: plain JSON shapes, no
 * host-only imports, so the client bundle can type-check against it.
 */

// ---------------------------------------------------------------------------
// Connection
// ---------------------------------------------------------------------------

/** Result of a connection probe against the configured wigolo daemon. */
export interface ConnectionTestResult {
  ok: boolean
  /** Round-trip latency of the probe (initialize round), in ms. */
  latencyMs?: number
  /** wigolo daemon version, when the handshake succeeds. */
  serverVersion?: string
  /** Human-readable failure reason, when !ok. */
  error?: string
}

// ---------------------------------------------------------------------------
// Config (public projection — secrets never leave the host)
// ---------------------------------------------------------------------------

/** Provider takeover mode: true = use wigolo for both search and fetch, false = use official providers. */
export type TakeoverMode = boolean

/** hostHeader resolution: auto (default) | none | a literal custom value. */
export type HostHeaderMode = 'auto' | 'none' | (string & {})

/** Connection settings (as stored; tokenFile is a path, the token itself never lives here). */
export interface ConnectionConfig {
  host: string
  port: number
  hostHeader: HostHeaderMode
  tokenFile: string
}

/** Per-tool exposure settings. */
export interface ToolConfig {
  enabled: boolean
  /** Default argument values merged under the model's explicit args. */
  defaults?: Record<string, unknown>
  /** Tool execution timeout override (ms). */
  timeoutMs?: number
}

/** The full stored config, version 2. */
export interface WigoloConfig {
  version: 2
  connection: ConnectionConfig
  takeover: TakeoverMode
  tools: Record<string, ToolConfig>
  announceToAgent: boolean
  /** Read-only cache/watch browser tab (conversation.view slot). Off by default. */
  cacheTab: { enabled: boolean }
  /** Timezone for displaying timestamps from wigolo daemon (which returns UTC).
   * "local" = use system local timezone; or IANA timezone name like "Asia/Shanghai". */
  timezone: string
}

/** Secret-free projection served to the browser. */
export interface WigoloConfigSummary {
  connection: ConnectionConfig
  takeover: TakeoverMode
  tools: Record<string, ToolConfig>
  announceToAgent: boolean
  cacheTab: { enabled: boolean }
  /** Timezone for displaying timestamps. */
  timezone: string
  /** Whether the token file exists and is non-empty. */
  hasToken: boolean
  /** Whether a legacy setup was detected and imported. */
  migratedFromLegacy: boolean
}

// ---------------------------------------------------------------------------
// Cache tab API shapes
// ---------------------------------------------------------------------------

/** One cache entry row (metadata only — markdown never rides the list). */
export interface CacheEntryRow {
  url: string
  title: string
  fetched_at: string
}

/** Cache stats strip. */
export interface CacheStats {
  total_urls: number
  total_size_mb: number
  oldest?: string
  newest?: string
}

/** One watch job row. */
export interface WatchJobRow {
  id: string
  url: string
  interval_seconds: number
  status: string
  /** Humanized timing, same format the wigolo_watch tool returns. */
  next_check_in?: string
}

// ---------------------------------------------------------------------------
// API routes (paths only — the host builds WebRoutes from these)
// ---------------------------------------------------------------------------

export const WIGOLO_API = {
  config: '/api/dsh-wigolo/config',
  token: '/api/dsh-wigolo/token',
  test: '/api/dsh-wigolo/test',
  tools: '/api/dsh-wigolo/tools',
  takeover: '/api/dsh-wigolo/takeover',
  cacheTabList: '/api/dsh-wigolo/cache-tab/list',
  cacheTabStats: '/api/dsh-wigolo/cache-tab/stats',
  cacheTabEntry: '/api/dsh-wigolo/cache-tab/entry',
  cacheTabWatch: '/api/dsh-wigolo/cache-tab/watch',
  /** Session creation-time lookup for the "this session" filter (host reads ctx.sessions). */
  cacheTabSession: '/api/dsh-wigolo/cache-tab/session',
  guide: '/api/dsh-wigolo/guide',
} as const
