/**
 * Panel state owner (open/close/toggle) — a tiny observable the sidebar
 * entry row and the React root both subscribe to (same shape as dsh-ssh's
 * PanelController, minus terminal-specific state).
 */

export interface PanelSnapshot {
  panelOpen: boolean
}

/** Subscribable panel controller. */
export class PanelController {
  private listeners = new Set<() => void>()
  private open = false

  getSnapshot(): PanelSnapshot {
    return { panelOpen: this.open }
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  private emit(): void {
    for (const listener of this.listeners) listener()
  }

  openPanel(): void {
    if (!this.open) { this.open = true; this.emit() }
  }

  closePanel(): void {
    if (this.open) { this.open = false; this.emit() }
  }

  toggle(): void {
    this.open = !this.open
    this.emit()
  }
}
