/**
 * Wigolo panel locale dictionaries (zh/en).
 * Registered under the "dsh-wigolo" namespace.
 */

export const zh = {
  // Panel header
  'panel.title': 'Wigolo',
  'panel.close': '关闭',
  'panel.loadError': '加载配置失败',
  'panel.loading': '加载中…',
  'common.saved': '已保存。',
  'common.error': '出错：',
  'conn.port.invalid': '端口必须是 1–65535 的整数',
  
  // Tabs
  'tab.connection': '连接配置',
  'tab.takeover': '接管与工具',
  'tab.about': '关于',
  'tab.help': '使用指南',
  
  // Connection tab
  'conn.host': '主机地址',
  'conn.port': '端口',
  'conn.hostHeader': 'Host 头',
  'conn.hostHeader.auto': '自动（本地守护进程推荐）',
  'conn.hostHeader.none': '无（让 node:http 决定）',
  'conn.hostHeader.custom': '自定义…',
  'conn.hostHeader.customPlaceholder': '例如 0.0.0.0（绑定主机白名单技巧）',
  'conn.tokenFile': 'Token 文件',
  'conn.tokenFile.placeholder': '~/.dsh/wigolo-token（默认）',
  'conn.tokenFile.present': 'Token 文件已存在。',
  'conn.tokenFile.absent': '尚未配置 Token — 在下方粘贴或自行写入文件（首行，权限 0600）。',
  'conn.token.replace': '替换 Token',
  'conn.token.set': '设置 Token',
  'conn.token.placeholder': '粘贴守护进程 bearer token',
  'conn.token.write': '写入',
  'conn.token.writing': '写入中…',
  'conn.token.success': 'Token 已写入（权限 0600）。agent 工具已即时生效；仅 web_search/web_fetch 提供商接管需重启 DSH。',
  'conn.token.failed': '失败',
  'conn.save': '保存',
  'conn.saving': '保存中…',
  'conn.test': '测试连接',
  'conn.testing': '测试中…',
  'conn.testSuccess': '连接成功',
  'conn.testFailed': '连接失败',
  'conn.testHint': '请检查守护进程是否运行以及 Token 是否正确 — 安装指南',
  'conn.docs': 'wigolo 文档',
  'conn.migrated': '已从旧版环境变量导入配置。',
  'conn.restarts.tools': '已保存。工具暴露变更需重启 DSH 后生效。',
  'conn.dirty': '有未保存的修改',
  
  // Takeover tab
  'takeover.title': '搜索接管',
  'takeover.enabled': '使用 wigolo 接管 web_search 和 web_fetch',
  'takeover.disabled': '使用官方搜索提供商',
  'takeover.hintEnabled': 'wigolo 将接管 web_search 和 web_fetch。重启 DSH 后生效。',
  'takeover.hintDisabled': '官方提供商处理 web_search 和 web_fetch。wigolo_* 工具仍可使用。',
  'takeover.switching': '切换中…',
  'takeover.cacheTab': '缓存 Tab',
  'takeover.cacheTab.on': '「Wigolo 缓存」tab 已启用（会话顶部）',
  'takeover.cacheTab.off': '「Wigolo 缓存」tab 已关闭',
  'takeover.cacheTab.hint': '只读浏览 daemon 缓存快照库与监控任务；即时生效，无需重启。',
  'takeover.cacheTab.applied': '已生效。',
  'takeover.tools': 'Agent 工具',
  'takeover.saveTools': '保存工具配置',
  
  // Tool descriptions
  'tool.search': '范围/时效搜索',
  'tool.crawl': '站点爬取入缓存',
  'tool.extract': '结构化数据提取',
  'tool.research': '多步深度研究',
  'tool.findSimilar': '相似内容查找',
  'tool.cache': '本地缓存搜索/统计',
  'tool.watch': 'URL 变更监控',
  
  // Cache tab (conversation.view)
  'cacheTab.label': 'Wigolo 缓存',
  'cacheTab.sub.browse': '缓存浏览',
  'cacheTab.sub.watch': '监控任务',
  'cacheTab.loading': '加载中…',
  'cacheTab.offline': 'daemon 离线',
  'cacheTab.offlineHint': '无法连接 wigolo daemon — 请在侧边栏 Wigolo 面板检查连接配置。',
  'cacheTab.filter.placeholder': '关键词过滤 URL / 标题…',
  'cacheTab.filter.session': '仅看本会话期间',
  'cacheTab.filter.sessionHint': '按当前会话创建时间起筛选抓取记录（时间近似，可能含同期其他客户端的抓取）。',
  'cacheTab.filter.range.all': '全部时间',
  'cacheTab.filter.range.today': '今天',
  'cacheTab.filter.range.7d': '近 7 天',
  'cacheTab.filter.range.30d': '近 30 天',
  'cacheTab.filter.limit.n20': '20 条',
  'cacheTab.filter.limit.n50': '50 条',
  'cacheTab.filter.limit.n100': '100 条',
  'cacheTab.filter.limit.n200': '200 条',
  'cacheTab.empty': '没有匹配的缓存条目',
  'cacheTab.detail.loading': '加载原文…',
  'cacheTab.detail.empty': '（此条目无 markdown 内容）',
  'cacheTab.detail.copy': '复制',
  'cacheTab.detail.copied': '已复制',
  'cacheTab.detail.preview': '预览',
  'cacheTab.detail.raw': '原始',
  'cacheTab.watch.empty': '暂无监控任务 — 通过对话让 agent 用 wigolo_watch 创建。',
  'cacheTab.watch.check': '立即检查',
  'cacheTab.watch.pause': '暂停',
  'cacheTab.watch.resume': '恢复',
  'cacheTab.watch.done': '操作已执行。',
  'cacheTab.watch.manageHint': '创建与删除监控任务请通过 agent 对话（wigolo_watch）。',

  // About tab
  'about.plugin': '插件',
  'about.providers': '提供商',
  'about.tools': '工具',
  'about.links': '相关链接',
  'about.linkDaemon': 'wigolo（上游守护进程）',
  'about.linkDocs': 'wigolo 文档',
  'about.linkGuide': '使用指南（中文）',
  'about.hostHeader': '为什么需要 Host 头？',
  'about.hostHeaderText': 'wigolo 通过白名单机制防止 DNS 重绑定攻击（允许 localhost、回环地址及其自身绑定主机）。绑定到 0.0.0.0 的局域网守护进程因此接受 Host 头为 0.0.0.0 的请求。浏览器/fetch 拒绝设置 Host —— 本插件使用 node:http，允许此操作。默认的"自动"模式对本地守护进程不发送自定义头，对远程守护进程使用绑定主机技巧。',
  'about.migration': '从旧版迁移',
  'about.migrationText': '环境变量（WIGOLO_HOST_IP / WIGOLO_PORT）和现有 token 文件会在首次运行时自动导入。',
  
  // Help tab
  'help.loadError': '加载使用指南失败',
  'common.copy': '复制',
  'common.copied': '已复制',
} as const

export const en = {
  // Panel header
  'panel.title': 'Wigolo',
  'panel.close': 'Close',
  'panel.loadError': 'Failed to load config',
  'panel.loading': 'Loading…',
  'common.saved': 'Saved.',
  'common.error': 'Error:',
  'conn.port.invalid': 'Port must be an integer in 1–65535',
  
  // Tabs
  'tab.connection': 'Connection',
  'tab.takeover': 'Takeover & Tools',
  'tab.about': 'About',
  'tab.help': 'Guide',
  
  // Connection tab
  'conn.host': 'Host',
  'conn.port': 'Port',
  'conn.hostHeader': 'Host header',
  'conn.hostHeader.auto': 'auto (recommended for local daemons)',
  'conn.hostHeader.none': 'none (let node:http pick)',
  'conn.hostHeader.custom': 'custom…',
  'conn.hostHeader.customPlaceholder': 'e.g. 0.0.0.0 (bind-host allowlist trick)',
  'conn.tokenFile': 'Token file',
  'conn.tokenFile.placeholder': '~/.dsh/wigolo-token (default)',
  'conn.tokenFile.present': 'Token file present.',
  'conn.tokenFile.absent': 'No token yet — paste it below or write the file yourself (first line, 0600).',
  'conn.token.replace': 'Replace token',
  'conn.token.set': 'Set token',
  'conn.token.placeholder': 'paste the daemon bearer token',
  'conn.token.write': 'Write',
  'conn.token.writing': 'Writing…',
  'conn.token.success': 'Token written (0600). Agent tools are live immediately; only the web_search/web_fetch provider takeover needs a DSH restart.',
  'conn.token.failed': 'Failed',
  'conn.save': 'Save',
  'conn.saving': 'Saving…',
  'conn.test': 'Test connection',
  'conn.testing': 'Testing…',
  'conn.testSuccess': 'Connected',
  'conn.testFailed': 'Failed',
  'conn.testHint': 'Check the daemon is running and the token is correct — install/setup guide',
  'conn.docs': 'wigolo docs',
  'conn.migrated': 'Settings imported from legacy env vars.',
  'conn.restarts.tools': 'Saved. Tool exposure changes apply after a DSH restart.',
  'conn.dirty': 'Unsaved changes',
  
  // Takeover tab
  'takeover.title': 'Provider takeover',
  'takeover.enabled': 'Use wigolo for web_search and web_fetch',
  'takeover.disabled': 'Use official providers',
  'takeover.hintEnabled': 'wigolo drives both web_search and web_fetch. Restart DSH to apply.',
  'takeover.hintDisabled': 'Official providers handle web_search and web_fetch. wigolo_* tools are still available.',
  'takeover.switching': 'Switching…',
  'takeover.cacheTab': 'Cache tab',
  'takeover.cacheTab.on': '"Wigolo Cache" tab enabled (top of the session)',
  'takeover.cacheTab.off': '"Wigolo Cache" tab off',
  'takeover.cacheTab.hint': 'Read-only browsing of the daemon cache snapshot library and watch jobs; applies immediately, no restart.',
  'takeover.cacheTab.applied': 'Applied.',
  'takeover.tools': 'Agent tools',
  'takeover.saveTools': 'Save tools',
  
  // Tool descriptions
  'tool.search': 'scoped/freshness search',
  'tool.crawl': 'site crawl into cache',
  'tool.extract': 'structured extraction',
  'tool.research': 'multi-step research',
  'tool.findSimilar': 'related content',
  'tool.cache': 'local cache search/stats',
  'tool.watch': 'URL change monitoring',
  
  // Cache tab (conversation.view)
  'cacheTab.label': 'Wigolo Cache',
  'cacheTab.sub.browse': 'Browse',
  'cacheTab.sub.watch': 'Watch jobs',
  'cacheTab.loading': 'Loading…',
  'cacheTab.offline': 'daemon offline',
  'cacheTab.offlineHint': 'Cannot reach the wigolo daemon — check the connection settings in the Wigolo sidebar panel.',
  'cacheTab.filter.placeholder': 'Filter by keyword (URL / title)…',
  'cacheTab.filter.session': 'This session only',
  'cacheTab.filter.sessionHint': 'Entries fetched since this session was created (time-based; may include other clients fetches).',
  'cacheTab.filter.range.all': 'All time',
  'cacheTab.filter.range.today': 'Today',
  'cacheTab.filter.range.7d': 'Last 7 days',
  'cacheTab.filter.range.30d': 'Last 30 days',
  'cacheTab.filter.limit.n20': '20 items',
  'cacheTab.filter.limit.n50': '50 items',
  'cacheTab.filter.limit.n100': '100 items',
  'cacheTab.filter.limit.n200': '200 items',
  'cacheTab.empty': 'No matching cache entries',
  'cacheTab.detail.loading': 'Loading markdown…',
  'cacheTab.detail.empty': '(no markdown content for this entry)',
  'cacheTab.detail.copy': 'Copy',
  'cacheTab.detail.copied': 'Copied',
  'cacheTab.detail.preview': 'Preview',
  'cacheTab.detail.raw': 'Raw',
  'cacheTab.watch.empty': 'No watch jobs — ask the agent to create one via wigolo_watch.',
  'cacheTab.watch.check': 'Check now',
  'cacheTab.watch.pause': 'Pause',
  'cacheTab.watch.resume': 'Resume',
  'cacheTab.watch.done': 'Done.',
  'cacheTab.watch.manageHint': 'Create/delete watch jobs through the agent (wigolo_watch).',

  // About tab
  'about.plugin': 'Plugin',
  'about.providers': 'Providers',
  'about.tools': 'Tools',
  'about.links': 'Links',
  'about.linkDaemon': 'wigolo (upstream daemon)',
  'about.linkDocs': 'wigolo docs',
  'about.linkGuide': 'Usage guide (中文)',
  'about.hostHeader': 'Why a Host header?',
  'about.hostHeaderText': 'wigolo guards against DNS-rebinding by allowlisting Host values (localhost, loopback literals, and its own bind host). A daemon bound to 0.0.0.0 on a LAN machine therefore accepts requests whose Host header is 0.0.0.0. Browsers/fetch refuse to set Host — the plugin uses node:http, which allows it. The default "auto" mode sends no custom header for local daemons and the bind-host trick for remote ones.',
  'about.migration': 'Legacy migration',
  'about.migrationText': 'Legacy env vars (WIGOLO_HOST_IP / WIGOLO_PORT) and the existing token file are imported automatically on first run.',
  
  // Help tab
  'help.loadError': 'Failed to load guide',
  'common.copy': 'Copy',
  'common.copied': 'Copied',
} as const

export type WigoloLocaleKey = keyof typeof zh

// Compile-time assertion: zh and en must carry identical key sets, so a key
// added to one dictionary but not the other fails the build instead of
// surfacing as a runtime missing translation. When the sets diverge, at
// least one of these conditional types evaluates to never and the object
// literal below no longer satisfies its (empty) expected shape.
type EnKey = keyof typeof en
type EnExtra = Exclude<EnKey, WigoloLocaleKey>
type ZhExtra = Exclude<WigoloLocaleKey, EnKey>
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const _localeKeysInSync: Record<EnExtra | ZhExtra, never> = {}
