/**
 * Panel view mounting (dsh-ssh precedent): the panel takes over the center
 * column at the DOM level — a container appended inside the center column
 * as an extra trailing child React never manages, and a stylesheet rule
 * hides the conversation content while the panel is active. Toggling is a
 * data attribute on <html>; cross-panel mutex rides the dsh-panel-activate
 * event so ssh / task-board / wigolo panels never overlap visually.
 */

import { createRoot, type Root } from 'react-dom/client'
import type { WigoloApi } from './api.ts'
import type { PanelController } from './controller.ts'
import { WigoloPanel } from './panel/WigoloPanel.tsx'
import css from './panel/panel.module.css'

/** The injected panel container (kept in the DOM, hidden when inactive). */
export const PANEL_VIEW_SELECTOR = '[data-dsh-wigolo-view]'

const CONVERSATION_COLUMN_SELECTOR = '[data-pane="conversation"], [class*="centerCol"]'
const ACTIVE_ATTR = 'data-dsh-wigolo-active'
/** Sibling panels' activation attributes, removed when this panel opens. */
const OTHER_ACTIVE_ATTRS = ['data-dsh-taskboard-active', 'data-dsh-ssh-active']
/** Cross-plugin activation event; detail is the activating panel name. */
const ACTIVATE_EVENT = 'dsh-panel-activate'
const PANEL_NAME = 'wigolo'

/** Find the center column, or undefined while the frame is not mounted. */
function conversationColumn(): HTMLElement | undefined {
  return document.querySelector<HTMLElement>(CONVERSATION_COLUMN_SELECTOR) ?? undefined
}

/**
 * Mount the panel React tree into the center column and bind its visibility
 * to the controller's panelOpen state.
 * @returns disposer unmounting the tree and restoring the column.
 */
export function mountPanel(
  controller: PanelController,
  api: WigoloApi,
  t: (key: string) => string,
  locale: () => string,
  subscribeLocale: (fn: () => void) => () => void,
): () => void {
  let root: Root | undefined
  let container: HTMLDivElement | undefined
  /** Locale-change subscriptions for the current root; cleared on remount. */
  const rootLocaleDisposers: Array<() => void> = []

  const ensure = (): void => {
    if (container !== undefined) {
      if (container.isConnected) return
      // The conversation pane was replaced; drop the stale tree and remount.
      for (const off of rootLocaleDisposers.splice(0)) off()
      root?.unmount()
      root = undefined
      container.remove()
      container = undefined
    }
    const column = conversationColumn()
    if (column === undefined) return
    container = document.createElement('div')
    container.dataset.dshWigoloView = ''
    container.className = css.view
    column.appendChild(container)
    root = createRoot(container)
    // Re-render on every locale change so the help-tab guide variant (and any
    // other locale-driven text) stays in sync with the DSH language setting.
    const render = (): void => { root?.render(<WigoloPanel controller={controller} api={api} t={t} locale={locale()} />) }
    render()
    const offLocale = subscribeLocale(render)
    rootLocaleDisposers.push(offLocale)
  }

  const activate = (open: boolean): void => {
    const html = document.documentElement
    if (open) {
      // Cross-panel mutex: tell sibling panels to close, then mark ourselves.
      window.dispatchEvent(new CustomEvent(ACTIVATE_EVENT, { detail: PANEL_NAME }))
      for (const attr of OTHER_ACTIVE_ATTRS) html.removeAttribute(attr)
      html.setAttribute(ACTIVE_ATTR, '')
    } else {
      html.removeAttribute(ACTIVE_ATTR)
    }
  }

  const onOtherActivate = (event: Event): void => {
    if ((event as CustomEvent<string>).detail !== PANEL_NAME) {
      controller.closePanel()
    }
  }

  const sync = (): void => {
    const open = controller.getSnapshot().panelOpen
    if (open) ensure()
    activate(open)
    if (container !== undefined) {
      container.style.display = open ? 'block' : 'none'
    }
  }

  const unsubscribe = controller.subscribe(sync)
  const offAllLocale = subscribeLocale(sync)
  window.addEventListener(ACTIVATE_EVENT, onOtherActivate)
  sync()

  return () => {
    unsubscribe()
    offAllLocale()
    for (const off of rootLocaleDisposers.splice(0)) off()
    window.removeEventListener(ACTIVATE_EVENT, onOtherActivate)
    activate(false)
    root?.unmount()
    container?.remove()
  }
}
