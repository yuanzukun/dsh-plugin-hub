/**
 * Pure filtering helpers for the cache browse sub-page, extracted so the
 * keyword + this-session logic is unit-testable without a component renderer.
 */
import type { CacheEntryRow } from '../protocol.ts'

/** Parse a daemon fetched_at ("YYYY-MM-DD HH:mm:ss", daemon-local) to ms epoch; 0 when unparseable/empty. */
export function parseFetchedMs(s: string): number {
  if (s === '') return 0
  const t = Date.parse(s.replace(' ', 'T'))
  return Number.isNaN(t) ? 0 : t
}

export type TimeRange = 'all' | 'today' | '7d' | '30d' | 'session'

export interface CacheFilterOpts {
  query: string
  /** ms epoch; 0 = no time floor. */
  sinceMs: number
  /** ms epoch ceiling for the 'session' range; 0/undefined = unbounded.
   * Set from the session's last turn end while the session is idle (excludes
   * post-dormancy noise); left open while running (the in-flight turn's
   * fetches postdate the last persisted message). */
  untilMs?: number
  /** Preset time range (sinceMs takes precedence when > 0). */
  timeRange?: TimeRange
}

/**
 * Compute the ms-epoch floor for a preset time range.
 * Returns 0 for 'all' (no filter) and 'session' (handled separately).
 */
export function timeRangeToSinceMs(range: TimeRange, sessionStartedAt?: number): number {
  if (range === 'all' || range === 'session') return 0
  const now = Date.now()
  if (range === 'today') {
    const d = new Date(now)
    d.setHours(0, 0, 0, 0)
    return d.getTime()
  }
  if (range === '7d') return now - 7 * 24 * 60 * 60 * 1000
  if (range === '30d') return now - 30 * 24 * 60 * 60 * 1000
  return 0
}

/** Client-side filter over cached-metadata rows (design §3: front-end filtering). */
export function filterCacheEntries(entries: CacheEntryRow[], opts: CacheFilterOpts): CacheEntryRow[] {
  const q = opts.query.trim().toLowerCase()
  const isSessionRange = opts.timeRange === 'session'
  const floor = opts.sinceMs > 0 ? opts.sinceMs : (opts.timeRange && !isSessionRange && opts.timeRange !== 'all' ? timeRangeToSinceMs(opts.timeRange) : 0)
  // Ceiling only pairs with a real floor: without sinceMs the window would
  // silently widen to [0, untilMs] and admit pre-session history.
  const ceiling = isSessionRange && floor > 0 && opts.untilMs !== undefined && opts.untilMs > 0 ? opts.untilMs : 0
  return entries.filter((e) => {
    if (q !== '' && !(e.url.toLowerCase().includes(q) || e.title.toLowerCase().includes(q))) return false
    if (floor > 0 && parseFetchedMs(e.fetched_at) < floor) return false
    if (ceiling > 0 && parseFetchedMs(e.fetched_at) > ceiling) return false
    return true
  })
}
