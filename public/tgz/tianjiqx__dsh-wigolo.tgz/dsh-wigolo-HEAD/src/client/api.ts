/**
 * Browser-side API client for the /api/dsh-wigolo route family. The only
 * data access path the panel components use — plain fetch, same origin.
 */

import type { ConnectionTestResult, WigoloConfigSummary } from '../protocol.ts'

const API = {
  config: '/api/dsh-wigolo/config',
  token: '/api/dsh-wigolo/token',
  tools: '/api/dsh-wigolo/tools',
  test: '/api/dsh-wigolo/test',
  takeover: '/api/dsh-wigolo/takeover',
  guide: '/api/dsh-wigolo/guide',
} as const

/** Error carrying the route's JSON error message. */
export class WigoloApiError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'WigoloApiError'
  }
}

async function readJson<T>(response: Response): Promise<T> {
  let body: unknown
  try {
    body = await response.json()
  } catch {
    throw new WigoloApiError('HTTP ' + response.status + ': invalid JSON response')
  }
  if (!response.ok) {
    const message = typeof body === 'object' && body !== null && typeof (body as { error?: unknown }).error === 'string'
      ? (body as { error: string }).error
      : 'HTTP ' + response.status
    throw new WigoloApiError(message)
  }
  return body as T
}

export interface ConfigUpdateResult extends WigoloConfigSummary {
  restartHint?: string
}

export interface TakeoverResult {
  ok: boolean
  takeover: boolean
  restartNeeded: boolean
  message: string
}

/** The panel's API surface. */
export interface WigoloApi {
  getConfig(): Promise<WigoloConfigSummary>
  updateConnection(payload: Record<string, unknown>): Promise<ConfigUpdateResult>
  writeToken(token: string): Promise<{ ok: boolean; hasToken?: boolean; error?: string }>
  updateTools(tools: Record<string, { enabled: boolean; defaults?: Record<string, unknown>; timeoutMs?: number }>): Promise<ConfigUpdateResult>
  testConnection(params?: { host?: string; port?: number; hostHeader?: string; tokenFile?: string }): Promise<ConnectionTestResult>
  setTakeover(takeover: boolean): Promise<TakeoverResult>
  setCacheTab(enabled: boolean): Promise<ConfigUpdateResult>
  getGuide(locale?: string): Promise<{ markdown: string }>
}

export function makeApi(): WigoloApi {
  return {
    async getConfig() {
      return readJson(await fetch(API.config, { method: 'GET' }))
    },
    async writeToken(token) {
      return readJson(await fetch(API.token, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ token }),
      }))
    },
    async updateConnection(payload) {
      return readJson(await fetch(API.config, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload),
      }))
    },
    async updateTools(tools) {
      return readJson(await fetch(API.tools, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ tools }),
      }))
    },
    async testConnection(params) {
      return readJson(await fetch(API.test, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(params ?? {}),
      }))
    },
    async setTakeover(takeover) {
      return readJson(await fetch(API.takeover, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ takeover }),
      }))
    },
    async setCacheTab(enabled) {
      return readJson(await fetch(API.config, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ cacheTab: enabled }),
      }))
    },
    async getGuide(locale?: string) {
      return readJson(await fetch(API.guide + (locale !== undefined ? '?lang=' + encodeURIComponent(locale) : ''), { method: 'GET' }))
    },
  }
}
