/**
 * About tab: versions, upstream links, the Host-header technical note, and
 * the migration pointer for legacy users.
 */

import css from './panel.module.css'

export interface AboutTabProps {
  t: (key: string) => string
}

export function AboutTab({ t }: AboutTabProps): React.JSX.Element {
  const LINKS = [
    { label: t('about.linkDaemon'), href: 'https://github.com/KnockOutEZ/wigolo' },
    { label: t('about.linkDocs'), href: 'https://knockoutez.github.io/wigolo/docs/' },
    { label: t('about.linkGuide'), href: 'https://github.com/tianjiqx/dsh-wigolo/blob/main/GUIDE.zh.md' },
  ]
  return (
    <div>
      <div className={css.kv} style={{ marginBottom: 14 }}>
        <span className={css.kvKey}>{t('about.plugin')}</span><span>{'dsh-wigolo ' + __WIGOLO_VERSION__}</span>
        <span className={css.kvKey}>{t('about.providers')}</span><span>search + fetch (id: wigolo)</span>
        <span className={css.kvKey}>{t('about.tools')}</span><span>wigolo_search / crawl / extract / research / find_similar / cache / watch</span>
      </div>

      <div className={css.field}>
        <span className={css.label}>{t('about.links')}</span>
        <ul style={{ margin: 0, paddingLeft: 18 }}>
          {LINKS.map((l) => (
            <li key={l.href}><a className={css.link} href={l.href} target="_blank" rel="noreferrer">{l.label}</a></li>
          ))}
        </ul>
      </div>

      <div className={css.field}>
        <span className={css.label}>{t('about.hostHeader')}</span>
        <p className={css.hint}>{t('about.hostHeaderText')}</p>
      </div>

      <div className={css.field}>
        <span className={css.label}>{t('about.migration')}</span>
        <p className={css.hint}>{t('about.migrationText')}</p>
      </div>
    </div>
  )
}
