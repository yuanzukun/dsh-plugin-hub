/**
 * Connection tab: host/port/hostHeader/token-file form, test button with
 * latency + daemon version, and failure diagnostics pointing at the wigolo
 * install docs.
 */

import { useEffect, useState } from 'react'
import type { WigoloApi, ConfigUpdateResult } from '../api.ts'
import type { WigoloConfigSummary, ConnectionTestResult } from '../../protocol.ts'
import css from './panel.module.css'

const WIGOLO_DOCS = 'https://knockoutez.github.io/wigolo/docs/'

export interface ConnectionTabProps {
  api: WigoloApi
  summary: WigoloConfigSummary
  onSaved: (result: ConfigUpdateResult) => void
  t: (key: string) => string
  /** Reports unsaved-changes state upward for close/switch confirmation. */
  onDirtyChange?: (dirty: boolean) => void
}

export function ConnectionTab({ api, summary, onSaved, t, onDirtyChange }: ConnectionTabProps) {
  const conn = summary.connection
  const [host, setHost] = useState(conn?.host ?? '127.0.0.1')
  const [port, setPort] = useState(String(conn?.port ?? 3333))
  const [hostHeader, setHostHeader] = useState<string>(conn?.hostHeader ?? 'auto')
  const [tokenFile, setTokenFile] = useState(conn?.tokenFile ?? '')
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState(false)
  const [saveMsg, setSaveMsg] = useState<string | null>(null)
  const [testResult, setTestResult] = useState<ConnectionTestResult | null>(null)
  const [token, setToken] = useState('')
  const [writingToken, setWritingToken] = useState(false)
  const [tokenMsg, setTokenMsg] = useState<string | null>(null)

  const portNum = Number(port)
  const portValid = port === '' ? true : (Number.isInteger(portNum) && portNum >= 1 && portNum <= 65535)

  // Dirty check against the loaded snapshot (trimming for tokenFile).
  const dirty = host !== (conn?.host ?? '127.0.0.1')
    || port !== String(conn?.port ?? 3333)
    || hostHeader !== (conn?.hostHeader ?? 'auto')
    || tokenFile.trim() !== (conn?.tokenFile ?? '')

  /** Any form edit invalidates a stale test result. */
  const onFormChange = (fn: () => void): void => { fn(); setTestResult(null) }

  useEffect(() => { onDirtyChange?.(dirty) }, [dirty, onDirtyChange])

  const save = async (): Promise<void> => {
    if (!portValid) { setSaveMsg(t('conn.port.invalid')); return }
    setSaving(true)
    setSaveMsg(null)
    try {
      const result = await api.updateConnection({
        host, port: portNum, hostHeader, tokenFile,
      })
      setSaveMsg(t('common.saved') + (result.restartHint !== undefined ? ' ' + t('conn.restarts.tools') : ''))
      onSaved(result)
    } catch (err) {
      setSaveMsg(t('common.error') + ' ' + (err instanceof Error ? err.message : String(err)))
    } finally {
      setSaving(false)
    }
  }

  const saveToken = async (): Promise<void> => {
    setWritingToken(true)
    setTokenMsg(null)
    try {
      const result = await api.writeToken(token)
      setTokenMsg(result.ok ? t('conn.token.success') : t('conn.token.failed') + ': ' + (result.error ?? '?'))
      setToken('')
    } catch (err) {
      setTokenMsg(t('common.error') + ' ' + (err instanceof Error ? err.message : String(err)))
    } finally {
      setWritingToken(false)
    }
  }

  const test = async (): Promise<void> => {
    if (!portValid) { setTestResult({ ok: false, error: t('conn.port.invalid') }); return }
    setTesting(true)
    setTestResult(null)
    try {
      // Pass the current form values so the probe tests what the user sees,
      // not the previously saved config.
      setTestResult(await api.testConnection({
        host,
        port: portNum,
        hostHeader,
        tokenFile,
      }))
    } catch (err) {
      setTestResult({ ok: false, error: err instanceof Error ? err.message : String(err) })
    } finally {
      setTesting(false)
    }
  }

  return (
    <div>
      {summary?.migratedFromLegacy === true && (
        <div className={css.notice}>{t('conn.migrated')}</div>
      )}
      <div className={css.field}>
        <label className={css.label} htmlFor="wg-host">{t('conn.host')}</label>
        <input id="wg-host" className={css.input} value={host} onChange={(e) => { onFormChange(() => { setHost(e.target.value) }) }} placeholder="127.0.0.1" />
      </div>
      <div className={css.field}>
        <label className={css.label} htmlFor="wg-port">{t('conn.port')}</label>
        <input id="wg-port" className={css.input} value={port} inputMode="numeric" aria-invalid={!portValid ? true : undefined} data-invalid={!portValid ? '' : undefined} onChange={(e) => { onFormChange(() => { setPort(e.target.value) }) }} placeholder="3333" />
        {!portValid && <p className={css.hint} style={{ color: 'var(--dsh-danger, #e5484d)' }}>{t('conn.port.invalid')}</p>}
      </div>
      <div className={css.field}>
        <label className={css.label} htmlFor="wg-hh">{t('conn.hostHeader')}</label>
        <select id="wg-hh" className={css.select} value={hostHeader === 'auto' || hostHeader === 'none' ? hostHeader : 'custom'} onChange={(e) => {
          const v = e.target.value
          onFormChange(() => { setHostHeader(v === 'custom' ? '' : v) })
        }}>
          <option value="auto">{t('conn.hostHeader.auto')}</option>
          <option value="none">{t('conn.hostHeader.none')}</option>
          <option value="custom">{t('conn.hostHeader.custom')}</option>
        </select>
        {hostHeader !== 'auto' && hostHeader !== 'none' && (
          <input className={css.input} value={hostHeader} onChange={(e) => { onFormChange(() => { setHostHeader(e.target.value) }) }} placeholder={t('conn.hostHeader.customPlaceholder')} />
        )}
      </div>
      <div className={css.field}>
        <label className={css.label} htmlFor="wg-tokenfile">{t('conn.tokenFile')}</label>
        <input id="wg-tokenfile" className={css.input} value={tokenFile} onChange={(e) => { onFormChange(() => { setTokenFile(e.target.value) }) }} placeholder={t('conn.tokenFile.placeholder')} />
        <p className={css.hint}>{summary?.hasToken === true ? t('conn.tokenFile.present') : t('conn.tokenFile.absent')}</p>
      </div>
      <div className={css.field}>
        <label className={css.label} htmlFor="wg-token">{summary?.hasToken === true ? t('conn.token.replace') : t('conn.token.set')}</label>
        <div style={{ display: 'flex', gap: 8 }}>
          <input id="wg-token" className={css.input} type="password" autoComplete="off" value={token} onChange={(e) => { setToken(e.target.value) }} placeholder={t('conn.token.placeholder')} />
          <button type="button" className={css.button} disabled={token.trim() === '' || writingToken} onClick={() => { void saveToken() }}>{writingToken ? t('conn.token.writing') : t('conn.token.write')}</button>
        </div>
        {tokenMsg !== null && <p className={css.hint}>{tokenMsg}</p>}
      </div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <button type="button" className={css.button + ' ' + css.buttonPrimary} disabled={saving || !portValid} onClick={() => { void save() }}>{saving ? t('conn.saving') : t('conn.save')}</button>
        <button type="button" className={css.button} disabled={testing || !portValid} onClick={() => { void test() }}>{testing ? t('conn.testing') : t('conn.test')}</button>
        {dirty && !saving && <span className={css.hint} style={{ color: 'var(--dsh-warning, #f5a524)' }}>● {t('conn.dirty')}</span>}
      </div>
      {saveMsg !== null && <p className={css.hint}>{saveMsg}</p>}
      {testResult !== null && (
        <div style={{ marginTop: 12 }}>
          {testResult.ok
            ? <p className={css.statusOk}>{t('conn.testSuccess')} · {testResult.latencyMs}ms{testResult.serverVersion !== undefined ? ' · daemon ' + testResult.serverVersion : ''}</p>
            : <div>
                <p className={css.statusErr}>{t('conn.testFailed')}: {testResult.error}</p>
                <p className={css.hint}>{t('conn.testHint')}: <a className={css.link} href={WIGOLO_DOCS} target="_blank" rel="noreferrer">{t('conn.docs')}</a></p>
              </div>}
        </div>
      )}
    </div>
  )
}
