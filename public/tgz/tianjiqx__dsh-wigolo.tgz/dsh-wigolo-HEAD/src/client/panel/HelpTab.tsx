/**
 * The help tab: renders the bundled usage guide (zh or en, matching the DSH
 * locale) using the official MarkdownText renderer (same pipeline as the
 * chat's AssistantMarkdown). Content is fetched lazily from the host route
 * on first mount and re-fetched when the locale changes.
 */
import { useEffect, useState } from 'react'
import { MarkdownText } from '@deepseek-ai/dsh-client-ui-primitives'
import type { WigoloApi } from '../api.ts'
import css from './panel.module.css'

export interface HelpTabProps {
  api: WigoloApi
  t: (key: string) => string
  /** Active DSH locale id ('zh' | 'en'); picks the guide variant. */
  locale: string
}

export function HelpTab({ api, t, locale }: HelpTabProps): React.JSX.Element {
  const [markdown, setMarkdown] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    setMarkdown(null)
    setError(null)
    api.getGuide(locale)
      .then((res) => { if (!cancelled) setMarkdown(res.markdown) })
      .catch((err) => { if (!cancelled) setError(err instanceof Error ? err.message : String(err)) })
    return () => { cancelled = true }
  }, [api, locale])

  if (error !== null) {
    return <p className={css.statusErr}>{t('help.loadError')}: {error}</p>
  }
  if (markdown === null) {
    return <p className={css.hint}>{t('panel.loading')}</p>
  }
  return (
    <div className={css.helpContent}>
      <MarkdownText
        text={markdown}
        codeLabels={{ copyLabel: t('common.copy' as never) ?? 'Copy', copiedLabel: t('common.copied' as never) ?? 'Copied' }}
      />
    </div>
  )
}
