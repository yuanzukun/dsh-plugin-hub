/**
 * Takeover tab: a simple toggle switch for provider takeover plus
 * the per-tool exposure switches with their default-parameter hints.
 */

import { useState } from 'react'
import type { WigoloApi, ConfigUpdateResult } from '../api.ts'
import type { WigoloConfigSummary, TakeoverMode } from '../../protocol.ts'
import css from './panel.module.css'
import { CACHE_TAB_TOGGLED_EVENT } from '../cache-tab-slot.ts'

const TOOL_ORDER = ['wigolo_search', 'wigolo_crawl', 'wigolo_extract', 'wigolo_research', 'wigolo_find_similar', 'wigolo_cache', 'wigolo_watch'] as const

const TOOL_DESC_KEYS: Record<string, string> = {
  wigolo_search: 'tool.search',
  wigolo_crawl: 'tool.crawl',
  wigolo_extract: 'tool.extract',
  wigolo_research: 'tool.research',
  wigolo_find_similar: 'tool.findSimilar',
  wigolo_cache: 'tool.cache',
  wigolo_watch: 'tool.watch',
}

export interface TakeoverTabProps {
  api: WigoloApi
  summary: WigoloConfigSummary
  onSaved: (result: ConfigUpdateResult | WigoloConfigSummary) => void
  t: (key: string) => string
}

export function TakeoverTab({ api, summary, onSaved, t }: TakeoverTabProps) {
  const [takeover, setTakeover] = useState<TakeoverMode>(summary.takeover)
  const [switching, setSwitching] = useState(false)
  const [takeoverMsg, setTakeoverMsg] = useState<string | null>(null)
  const [tools, setTools] = useState(summary.tools)
  const [toolsMsg, setToolsMsg] = useState<string | null>(null)
  const [cacheTab, setCacheTab] = useState(summary.cacheTab.enabled)
  const [cacheTabSwitching, setCacheTabSwitching] = useState(false)
  const [cacheTabMsg, setCacheTabMsg] = useState<string | null>(null)

  const switchCacheTab = async (enabled: boolean): Promise<void> => {
    if (cacheTabSwitching || enabled === cacheTab) return
    setCacheTabSwitching(true)
    setCacheTabMsg(null)
    try {
      await api.setCacheTab(enabled)
      setCacheTab(enabled)
      setCacheTabMsg(t('takeover.cacheTab.applied'))
      onSaved({ ...summary, cacheTab: { enabled } })
      // Notify the slot registrar so the tab appears/disappears immediately.
      window.dispatchEvent(new Event(CACHE_TAB_TOGGLED_EVENT))
    } catch (err) {
      setCacheTabMsg(t('common.error') + ' ' + (err instanceof Error ? err.message : String(err)))
    } finally {
      setCacheTabSwitching(false)
    }
  }

  const switchTakeover = async (enabled: boolean): Promise<void> => {
    if (switching || enabled === takeover) return
    setSwitching(true)
    setTakeoverMsg(null)
    try {
      const result = await api.setTakeover(enabled)
      setTakeover(enabled)
      setTakeoverMsg(result.message)
      onSaved({ ...summary, takeover: enabled })
    } catch (err) {
      setTakeoverMsg(t('common.error') + ' ' + (err instanceof Error ? err.message : String(err)))
    } finally {
      setSwitching(false)
    }
  }

  const toggleTool = (id: string): void => {
    setTools((prev) => ({ ...prev, [id]: { ...(prev[id] ?? { enabled: true }), enabled: !(prev[id]?.enabled ?? true) } }))
  }

  const saveTools = async (): Promise<void> => {
    setToolsMsg(null)
    try {
      const result = await api.updateTools(tools)
      setToolsMsg(t('common.saved') + (result.restartHint !== undefined ? ' ' + t('conn.restarts.tools') : ''))
      onSaved(result)
    } catch (err) {
      setToolsMsg(t('common.error') + ' ' + (err instanceof Error ? err.message : String(err)))
    }
  }

  return (
    <div>
      <div className={css.field}>
        <span className={css.label}>{t('takeover.title')}</span>
        <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: switching ? 'wait' : 'pointer', marginTop: 8, opacity: switching ? .6 : 1, transition: 'opacity .15s ease' }}>
          <input
            type="checkbox"
            checked={takeover}
            disabled={switching}
            onChange={(e) => { void switchTakeover(e.target.checked) }}
            style={{ width: 18, height: 18 }}
          />
          <span style={{ fontSize: 14 }}>
            {switching ? t('takeover.switching') : (takeover ? t('takeover.enabled') : t('takeover.disabled'))}
          </span>
        </label>
        <p className={css.hint}>
          {takeover ? t('takeover.hintEnabled') : t('takeover.hintDisabled')}
        </p>
        {takeoverMsg !== null && <p className={css.hint}>{takeoverMsg}</p>}
      </div>

      <div className={css.field} style={{ marginTop: 18 }}>
        <span className={css.label}>{t('takeover.cacheTab')}</span>
        <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: cacheTabSwitching ? 'wait' : 'pointer', marginTop: 8, opacity: cacheTabSwitching ? .6 : 1, transition: 'opacity .15s ease' }}>
          <input
            type="checkbox"
            checked={cacheTab}
            disabled={cacheTabSwitching}
            onChange={(e) => { void switchCacheTab(e.target.checked) }}
            style={{ width: 18, height: 18 }}
          />
          <span style={{ fontSize: 14 }}>
            {cacheTabSwitching ? t('takeover.switching') : (cacheTab ? t('takeover.cacheTab.on') : t('takeover.cacheTab.off'))}
          </span>
        </label>
        <p className={css.hint}>{t('takeover.cacheTab.hint')}</p>
        {cacheTabMsg !== null && <p className={css.hint}>{cacheTabMsg}</p>}
      </div>

      <div className={css.field}>
        <span className={css.label}>{t('takeover.tools')}</span>
      </div>
      {TOOL_ORDER.map((id) => (
        <div key={id} className={css.toolRow}>
          <div>
            <div className={css.toolName}>{id}</div>
            <div className={css.toolDesc}>{t(TOOL_DESC_KEYS[id])}</div>
          </div>
          <label style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
            <input type="checkbox" checked={tools[id]?.enabled ?? true} onChange={() => { toggleTool(id) }} />
          </label>
        </div>
      ))}
      <button type="button" className={css.button + ' ' + css.buttonPrimary} onClick={() => { void saveTools() }}>{t('takeover.saveTools')}</button>
      {toolsMsg !== null && <p className={css.hint}>{toolsMsg}</p>}
    </div>
  )
}
