/**
 * The Wigolo panel shell: header, four-tab bar, active tab content. The
 * summary is fetched once and passed down; saves propagate the fresh copy
 * back up through onSaved.
 */

import { useEffect, useRef, useState } from 'react'
import type { WigoloApi, ConfigUpdateResult } from '../api.ts'
import type { PanelController } from '../controller.ts'
import type { WigoloConfigSummary } from '../../protocol.ts'
import { AboutTab } from './AboutTab.tsx'
import { ConnectionTab } from './ConnectionTab.tsx'
import { TakeoverTab } from './TakeoverTab.tsx'
import { HelpTab } from './HelpTab.tsx'
import css from './panel.module.css'

/** The panel's tab identifiers. (Cache & watch live in the agent tools — the panel is config-only.) */
export type WigoloTab = 'connection' | 'takeover' | 'about' | 'help'

// TABS will be computed inside the component using t()

export interface WigoloPanelProps {
  controller: PanelController
  api: WigoloApi
  t: (key: string) => string
  /** Active DSH locale id ('zh' | 'en'); drives the help-tab guide variant. */
  locale: string
}

export function WigoloPanel({ controller, api, t, locale }: WigoloPanelProps) {
  const [activeTab, setActiveTab] = useState<WigoloTab>('connection')
  const [summary, setSummary] = useState<WigoloConfigSummary | undefined>(undefined)
  const [loadErr, setLoadErr] = useState<string | null>(null)
  /** Latest unsaved-changes flag reported by ConnectionTab (ref, not state — no rerender needed). */
  const dirtyRef = useRef(false)
  const reportDirty = (v: boolean): void => { dirtyRef.current = v }

  useEffect(() => {
    let cancelled = false
    api.getConfig()
      .then((s) => { if (!cancelled) setSummary(s) })
      .catch((err) => { if (!cancelled) setLoadErr(err instanceof Error ? err.message : String(err)) })
    return () => { cancelled = true }
  }, [api])

  const onSaved = (result: ConfigUpdateResult | WigoloConfigSummary): void => {
    setSummary((prev) => ({ ...(result as WigoloConfigSummary), ...(prev !== undefined ? { migratedFromLegacy: prev.migratedFromLegacy } : {}) }))
  }

  const TABS = [
    { id: 'connection' as WigoloTab, label: t('tab.connection') },
    { id: 'takeover' as WigoloTab, label: t('tab.takeover') },
    { id: 'help' as WigoloTab, label: t('tab.help') },
    { id: 'about' as WigoloTab, label: t('tab.about') },
  ]

  return (
    <div className={css.panel}>
      <div className={css.panelHeader}>
        <h2 className={css.panelTitle}>{t('panel.title')}</h2>
        <button type="button" className={css.iconButton} aria-label={t('panel.close')} onClick={() => {
          if (dirtyRef.current && !window.confirm(t('conn.dirty') + ' — ' + t('panel.close') + '?')) return
          controller.closePanel()
        }}>✕</button>
      </div>
      <div className={css.tabBar} role="tablist">
        {TABS.map((tab) => (
          <button key={tab.id} type="button" role="tab" aria-selected={activeTab === tab.id} data-active={activeTab === tab.id ? '' : undefined} className={css.tab} onClick={() => {
            if (dirtyRef.current && activeTab === 'connection' && tab.id !== 'connection') {
              if (!window.confirm(t('conn.dirty') + ' — ' + t('tab.takeover') + '?')) return
            }
            setActiveTab(tab.id)
          }}>
            {tab.label}
          </button>
        ))}
      </div>
      <div className={css.panelContent}>
        {loadErr !== null && <p className={css.statusErr}>{t('panel.loadError')}: {loadErr}</p>}
        {activeTab === 'connection' && summary !== undefined && (
          <ConnectionTab api={api} summary={summary} onSaved={onSaved} t={t} onDirtyChange={reportDirty} />
        )}
        {activeTab === 'connection' && summary === undefined && loadErr === null && <p className={css.hint}>{t('panel.loading')}</p>}
        {activeTab === 'takeover' && summary !== undefined && (
          <TakeoverTab api={api} summary={summary} onSaved={onSaved} t={t} />
        )}
        {activeTab === 'takeover' && summary === undefined && loadErr === null && <p className={css.hint}>{t('panel.loading')}</p>}
        {activeTab === 'help' && <HelpTab api={api} t={t} locale={locale} />}
        {activeTab === 'about' && <AboutTab t={t} />}
      </div>
    </div>
  )
}
