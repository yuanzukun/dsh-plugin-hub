/**
 * conversation.view slot for the Wigolo cache tab: registered only while
 * cacheTab.enabled is on. The toggle drives dispose + re-register (the
 * memory-evolve disposeXxxTab pattern), so the tab appears/disappears
 * without a page refresh. A slow config poll backstops missed toggle
 * events (e.g. the file edited by hand). Design: docs/CACHE-TAB.md §5.
 */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots'
import { CacheTabView, type CacheTabApi } from './CacheTabView.tsx'
export type { CacheTabApi } from './CacheTabView.tsx'

/** Panel-saved toggle notification (fired from WigoloPanel after persist). */
export const CACHE_TAB_TOGGLED_EVENT = 'dsh-wigolo:cache-tab-toggled'

/** Backstop poll for hand-edited config (slow; the event is the fast path). */
const CONFIG_POLL_MS = 10_000

/**
 * Register the cache tab while enabled.
 *
 * The "this session" filter anchor comes from the slot-injected sessionId
 * (SessionStandardProps): the view resolves the real session creation time
 * through the host route (header.createdAt). The old PAGE_LOADED_AT module
 * constant was wrong across page refreshes, resumed sessions, and multi-tab
 * (docs/CACHE-TAB.md §1, revised).
 * @returns disposer unregistering the slot and all listeners.
 */
export function registerCacheTab(ctx: ClientContext, t: Translate, makeApi: () => CacheTabApi): () => void {
  let disposeTab: (() => void) | undefined
  let lastEnabled: boolean | undefined

  const register = (): void => {
    disposeTab?.()
    disposeTab = undefined
    if (lastEnabled !== true) return
    // Create the api object ONCE per registration so the reference stays
    // stable across re-renders. Previously makeApi() was called inside the
    // view factory, producing a new object on every render and causing
    // useEffect([api]) in CacheTabView to re-fire → constant data reloads.
    const stableApi = makeApi()
    // The conversation tab bar slot: memory-evolve's register shape. The
    // inject() wrapper survives shell re-renders; the disposer unregisters.
    disposeTab = (ctx as unknown as {
      slots: {
        inject: (name: 'conversation.view', factory: () => void) => () => void
        register: (def: Record<string, unknown>, view: (props: unknown) => JSX.Element) => () => void
      }
    }).slots.inject('conversation.view', () =>
      (ctx as unknown as { slots: { register: (def: Record<string, unknown>, view: (props: unknown) => JSX.Element) => () => void } }).slots.register({
        name: 'conversation.view',
        id: 'wigolo-cache',
        order: 40,
        label: () => String(t('cacheTab.label' as never)),
      }, (props: unknown) => CacheTabView({ ...(props as Record<string, unknown>), t, api: stableApi } as never)),
    )
  }

  const sync = (enabled: boolean): void => {
    if (enabled === lastEnabled) return
    lastEnabled = enabled
    register()
  }

  const pull = (): void => {
    void fetch('/api/dsh-wigolo/config')
      .then(async (r) => (r.ok ? await r.json() as { cacheTab?: { enabled?: boolean } } : undefined))
      .then((cfg) => { if (cfg?.cacheTab !== undefined) sync(cfg.cacheTab.enabled === true) })
      .catch(() => { /* offline: keep the last known state */ })
  }

  const onToggled = (): void => { pull() }
  window.addEventListener(CACHE_TAB_TOGGLED_EVENT, onToggled)
  const timer = window.setInterval(pull, CONFIG_POLL_MS)
  pull()

  return () => {
    window.removeEventListener(CACHE_TAB_TOGGLED_EVENT, onToggled)
    window.clearInterval(timer)
    disposeTab?.()
    disposeTab = undefined
  }
}
