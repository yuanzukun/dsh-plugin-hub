/**
 * Wigolo 缓存 tab (conversation.view entry): a read-only browser over the
 * daemon's cache snapshot library and watch jobs. Two sub-pages navigated
 * in-tab. All data flows through /api/dsh-wigolo/cache-tab/* host routes
 * (loopback-fenced, module-gated); markdown details are lazy-loaded per
 * entry; keyword/time filtering happens client-side on the already-fetched
 * metadata (design: docs/CACHE-TAB.md).
 */
import { useCallback, useEffect, useMemo, useState } from 'react'
import { MarkdownText } from '@deepseek-ai/dsh-client-ui-primitives'
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots'
import type { CacheEntryRow, CacheStats, WatchJobRow } from '../protocol.ts'
import { filterCacheEntries, type TimeRange } from './cache-filter.ts'
import css from './panel/panel.module.css'

export interface CacheTabApi {
  list(limit?: number): Promise<{ entries: CacheEntryRow[] }>
  stats(): Promise<{ stats: CacheStats }>
  entry(url: string): Promise<{ url: string; markdown: string; fetched_at: string }>
  watchList(): Promise<{ jobs?: WatchJobRow[] }>
  watchAction(action: 'check' | 'pause' | 'resume', jobId: string): Promise<Record<string, unknown>>
  sessionInfo(sessionId: string): Promise<{ sessionId: string; createdAt: number }>
}

export interface CacheTabViewProps {
  t: Translate
  api: CacheTabApi
  /** Framework-injected current session id (SessionStandardProps). */
  sessionId?: string
  /** Framework-injected conversation-snapshot selector (SessionStandardProps). */
  useSession?: <T>(select: (snapshot: SessionSnapshotShape) => T) => T
}

/** The minimal structural slice of ConversationSnapshot this view reads. */
export interface SessionSnapshotShape {
  running: boolean
  blank: boolean
  /** turn number → exact in-window turn/start time and optional turn/end time. */
  turnTimings: ReadonlyMap<number, { startTime: number; endTime?: number }>
}

type SubPage = 'browse' | 'watch'

/** Cache-entry detail view mode: rendered markdown vs raw source. */
type DetailMode = 'preview' | 'raw'

export function CacheTabView({ t, api, sessionId, useSession }: CacheTabViewProps): JSX.Element {
  // The "this session" filter anchor: the REAL session creation time from
  // the host (header.createdAt via /cache-tab/session), resolved per current
  // session id. Undefined while loading / on lookup failure → the filter
  // option hides (never filters against a wrong anchor).
  const [sessionStartedAt, setSessionStartedAt] = useState<number | undefined>(undefined)
  useEffect(() => {
    setSessionStartedAt(undefined)
    if (sessionId === undefined) return
    let alive = true
    api.sessionInfo(sessionId)
      .then((info) => { if (alive) setSessionStartedAt(info.createdAt) })
      .catch(() => { if (alive) setSessionStartedAt(undefined) })
    return () => { alive = false }
  }, [api, sessionId])

  // The "this session" filter CEILING: the session's active period ends at
  // the last completed turn's endTime. While running (an in-flight turn may
  // be fetching right now — those fetches postdate the last persisted
  // message) the ceiling opens; while blank (no turn ever) the window is
  // empty, which is correct: nothing was ever fetched for this session.
  const sessionBounds = useSession?.((s) => {
    if (s.running) return { blank: s.blank, endedAt: undefined as number | undefined }
    if (s.blank) return { blank: true, endedAt: undefined as number | undefined }
    let last: number | undefined = undefined
    for (const timing of s.turnTimings.values()) {
      if (timing.endTime !== undefined && (last === undefined || timing.endTime > last)) last = timing.endTime
    }
    return { blank: false, endedAt: last }
  }) ?? { blank: false, endedAt: undefined as number | undefined }
  const sessionEndedAt = sessionBounds.endedAt
  const blankSession = sessionBounds.blank

  const [page, setPage] = useState<SubPage>('browse')
  return (
    <div className={css.cacheTabRoot}>
      <div className={css.tabBar} role="tablist">
        <button type="button" role="tab" aria-selected={page === 'browse'} data-active={page === 'browse' ? '' : undefined} className={css.tab} onClick={() => { setPage('browse') }}>{t('cacheTab.sub.browse' as never)}</button>
        <button type="button" role="tab" aria-selected={page === 'watch'} data-active={page === 'watch' ? '' : undefined} className={css.tab} onClick={() => { setPage('watch') }}>{t('cacheTab.sub.watch' as never)}</button>
      </div>
      <div className={css.cacheTabPage}>
        {page === 'browse' ? <BrowseSubPage t={t} api={api} sessionStartedAt={sessionStartedAt} sessionEndedAt={sessionEndedAt} blankSession={blankSession} sessionIdKnown={sessionId !== undefined} /> : <WatchSubPage t={t} api={api} />}
      </div>
    </div>
  )
}

// -- browse sub-page ---------------------------------------------------------

/** Detail pane renderer: loading → empty → preview/raw toggle. Extracted to
 *  avoid a deeply nested ternary in the list JSX (ocr review finding). */
function renderDetail(
  t: Translate,
  detail: { url: string; markdown: string } | null,
  loading: boolean,
  mode: DetailMode,
  setMode: (m: DetailMode) => void,
): JSX.Element {
  if (loading) return <p className={css.hint}>{t('cacheTab.detail.loading' as never)}</p>
  if (detail === null || detail.markdown === '') {
    return <p className={css.hint}>{t('cacheTab.detail.empty' as never)}</p>
  }
  return (
    <>
      <div className={css.cacheTabDetailHeader}>
        <button type="button" className={`${css.cacheTabActionBtn} ${css.cacheTabModeBtn}`} data-active={mode === 'preview' ? '' : undefined} onClick={() => { setMode('preview') }}>{t('cacheTab.detail.preview' as never)}</button>
        <button type="button" className={`${css.cacheTabActionBtn} ${css.cacheTabModeBtn}`} data-active={mode === 'raw' ? '' : undefined} onClick={() => { setMode('raw') }}>{t('cacheTab.detail.raw' as never)}</button>
        <button type="button" className={`${css.cacheTabActionBtn} ${css.cacheTabCopyBtn}`} onClick={() => {
          navigator.clipboard.writeText(detail.markdown).catch(() => { /* silent */ })
        }}>{t('cacheTab.detail.copy' as never)}</button>
      </div>
      {mode === 'preview'
        ? <div className={css.cacheTabMarkdownPreview}>
            {/* DSH MarkdownText (same renderer as the chat's AssistantMarkdown
                / better-sidebar's md viewer): untrusted-markdown pipeline,
                GFM + KaTeX, raw HTML off. codeLabels keep the fence copy
                buttons in the active locale. */}
            <MarkdownText
              text={detail.markdown}
              codeLabels={{ copyLabel: t('cacheTab.detail.copy' as never), copiedLabel: t('cacheTab.detail.copied' as never) }}
            />
          </div>
        : <pre className={css.cacheTabMarkdown}>{detail.markdown}</pre>}
    </>
  )
}

function BrowseSubPage({ t, api, sessionStartedAt, sessionEndedAt, blankSession, sessionIdKnown }: { t: Translate; api: CacheTabApi; sessionStartedAt?: number; sessionEndedAt?: number; blankSession: boolean; sessionIdKnown: boolean }): JSX.Element {
  const [entries, setEntries] = useState<CacheEntryRow[] | null>(null)
  const [stats, setStats] = useState<CacheStats | null>(null)
  const [offline, setOffline] = useState(false)
  const [query, setQuery] = useState('')
  const [timeRange, setTimeRange] = useState<TimeRange>('session')
  const [limit, setLimit] = useState(50)
  const [openUrl, setOpenUrl] = useState<string | null>(null)
  const [detail, setDetail] = useState<{ url: string; markdown: string } | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [detailMode, setDetailMode] = useState<DetailMode>('preview')

  const load = useCallback((): void => {
    setEntries(null)
    setOffline(false)
    Promise.all([api.list(limit), api.stats().catch(() => ({ stats: {} as CacheStats }))])
      .then(([l, s]) => { setEntries(l.entries); setStats(s.stats ?? null) })
      .catch(() => {
        // one silent retry, then offline state (design §3)
        Promise.all([api.list(limit), api.stats().catch(() => ({ stats: {} as CacheStats }))])
          .then(([l, s]) => { setEntries(l.entries); setStats(s.stats ?? null) })
          .catch(() => { setOffline(true); setEntries([]) })
      })
  }, [api, limit])

  useEffect(() => { load() }, [load])

  // Lazy detail: fetch markdown only when a row is opened. Every row opens
  // fresh in preview mode (like better-sidebar's per-file preview/edit toggle).
  useEffect(() => {
    setDetailMode('preview')
    if (openUrl === null) { setDetail(null); return }
    setDetailLoading(true)
    api.entry(openUrl)
      .then((d) => { setDetail({ url: d.url, markdown: d.markdown }) })
      .catch(() => { setDetail({ url: openUrl, markdown: '' }) })
      .finally(() => { setDetailLoading(false) })
  }, [openUrl, api])

  const filtered = useMemo(() => filterCacheEntries(entries ?? [], {
    query,
    sinceMs: timeRange === 'session' && sessionStartedAt !== undefined ? sessionStartedAt : 0,
    untilMs: timeRange === 'session' && !blankSession && sessionStartedAt !== undefined ? sessionEndedAt : undefined,
    timeRange,
  }), [entries, query, timeRange, sessionStartedAt, sessionEndedAt, blankSession])

  if (offline) {
    return (
      <div className={css.cacheTabOffline}>
        <p className={css.statusErr}>{t('cacheTab.offline' as never)}</p>
        <p className={css.hint}>{t('cacheTab.offlineHint' as never)}</p>
      </div>
    )
  }
  if (entries === null) return <p className={css.hint}>{t('cacheTab.loading' as never)}</p>

  return (
    <div>
      {stats !== null && (
        <p className={css.hint}>
          {stats.total_urls} URL · {stats.total_size_mb}MB
          {stats.oldest !== undefined ? ' · ' + stats.oldest.slice(0, 10) + ' ~ ' + (stats.newest ?? '').slice(0, 10) : ''}
        </p>
      )}
      <div className={css.cacheTabToolbar}>
        <input className={css.input} value={query} placeholder={t('cacheTab.filter.placeholder' as never)} onChange={(e) => { setQuery(e.target.value) }} style={{ flex: 1, minWidth: 120 }} />
        <select className={css.select} value={sessionStartedAt === undefined && timeRange === 'session' ? 'all' : timeRange} onChange={(e) => { setTimeRange(e.target.value as TimeRange) }}>
          <option value="all">{t('cacheTab.filter.range.all' as never)}</option>
          <option value="today">{t('cacheTab.filter.range.today' as never)}</option>
          <option value="7d">{t('cacheTab.filter.range.7d' as never)}</option>
          <option value="30d">{t('cacheTab.filter.range.30d' as never)}</option>
          {sessionStartedAt !== undefined && <option value="session">{t('cacheTab.filter.session' as never)}</option>}
        </select>
        <select className={css.select} value={limit} onChange={(e) => { setLimit(Number(e.target.value)) }}>
          <option value={20}>{t('cacheTab.filter.limit.n20' as never)}</option>
          <option value={50}>{t('cacheTab.filter.limit.n50' as never)}</option>
          <option value={100}>{t('cacheTab.filter.limit.n100' as never)}</option>
          <option value={200}>{t('cacheTab.filter.limit.n200' as never)}</option>
        </select>
      </div>
      {timeRange === 'session' && <p className={css.hint}>{t('cacheTab.filter.sessionHint' as never)}</p>}
      <ul className={css.cacheTabList}>
        {filtered.map((e) => (
          <li key={e.url}>
            <div className={css.cacheTabRow} data-open={openUrl === e.url ? '' : undefined} onClick={() => { setOpenUrl(openUrl === e.url ? null : e.url) }}>
              <span className={css.cacheTabRowTitle}>{e.title !== '' ? e.title : e.url}</span>
              <span className={css.cacheTabRowUrl}>{e.url}</span>
              <span className={css.cacheTabRowTime}>{e.fetched_at}</span>
            </div>
            {openUrl === e.url && (
              <div className={css.cacheTabDetail}>
                {renderDetail(t, detail, detailLoading, detailMode, setDetailMode)}
              </div>
            )}
          </li>
        ))}
        {filtered.length === 0 && <li className={css.hint}>{t('cacheTab.empty' as never)}</li>}
      </ul>
    </div>
  )
}

// -- watch sub-page ----------------------------------------------------------

function WatchSubPage({ t, api }: { t: Translate; api: CacheTabApi }): JSX.Element {
  const [jobs, setJobs] = useState<WatchJobRow[] | null>(null)
  const [offline, setOffline] = useState(false)
  const [busy, setBusy] = useState<string | null>(null)
  const [msg, setMsg] = useState<string | null>(null)

  const load = useCallback((): void => {
    setJobs(null)
    setOffline(false)
    api.watchList()
      .then((r) => { setJobs(r.jobs ?? []) })
      .catch(() => { setOffline(true); setJobs([]) })
  }, [api])

  useEffect(() => { load() }, [load])

  const act = (action: 'check' | 'pause' | 'resume', job: WatchJobRow): void => {
    if (busy !== null) return
    setBusy(job.id)
    setMsg(null)
    api.watchAction(action, job.id)
      .then(() => { setMsg(t('cacheTab.watch.done' as never)); load() })
      .catch((err) => { setMsg(t('common.error' as never) + ' ' + String(err instanceof Error ? err.message : err)) })
      .finally(() => { setBusy(null) })
  }

  if (offline) {
    return (
      <div>
        <p className={css.statusErr}>{t('cacheTab.offline' as never)}</p>
        <p className={css.hint}>{t('cacheTab.offlineHint' as never)}</p>
      </div>
    )
  }
  if (jobs === null) return <p className={css.hint}>{t('cacheTab.loading' as never)}</p>

  return (
    <div>
      {jobs.length === 0 && <p className={css.hint}>{t('cacheTab.watch.empty' as never)}</p>}
      <ul className={css.cacheTabList}>
        {jobs.map((j) => (
          <li key={j.id} className={css.cacheTabWatchRow}>
            <div>
              <div className={css.cacheTabRowTitle}>{j.url}</div>
              <div className={css.hint}>
                {j.status}
                {j.next_check_in !== undefined ? ' · ' + j.next_check_in : ''}
                {' · ' + Math.round(j.interval_seconds / 60) + 'm'}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <button type="button" className={css.button} disabled={busy !== null} onClick={() => { act('check', j) }}>{t('cacheTab.watch.check' as never)}</button>
              {j.status === 'paused'
                ? <button type="button" className={css.button} disabled={busy !== null} onClick={() => { act('resume', j) }}>{t('cacheTab.watch.resume' as never)}</button>
                : <button type="button" className={css.button} disabled={busy !== null} onClick={() => { act('pause', j) }}>{t('cacheTab.watch.pause' as never)}</button>}
            </div>
          </li>
        ))}
      </ul>
      {msg !== null && <p className={css.hint}>{msg}</p>}
      <p className={css.hint}>{t('cacheTab.watch.manageHint' as never)}</p>
    </div>
  )
}
