/**
 * Load the dsh client-locale Context augmentation (`Context.locale`), which
 * lives on the module's `./client` subpath (not its main entry). Declared here
 * in a type-only file so it never emits a runtime import into the bundle.
 */
import '@deepseek-ai/dsh-client-locale/client'
