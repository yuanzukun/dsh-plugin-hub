/**
 * dsh-wigolo — browser half entry (runs inside the dsh web GUI).
 *
 * Exports the cordis-plugin-shaped module (apply/inject) the web shell's
 * ModuleLoader consumes, and self-registers when loaded as a plain script.
 * DOM mounting failures are logged, never thrown — the web shell fails the
 * whole boot when a plugin apply throws, and an external plugin must not
 * take the GUI down.
 */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import { makeApi } from './api.ts'
import { mountPanel } from './mount.tsx'
import { PanelController } from './controller.ts'
import { mountSidebarEntry } from './sidebar-entry.ts'
import { registerCacheTab, type CacheTabApi } from './cache-tab-slot.ts'
import css from './panel/panel.module.css'
import { zh, en } from './locales.ts'
import { WIGOLO_API } from '../protocol.ts'

/** Same-origin JSON fetch with error extraction (panel api.ts shape). */
async function readJson<T>(response: Response): Promise<T> {
  let body: unknown
  try { body = await response.json() } catch { throw new Error('HTTP ' + response.status + ': invalid JSON response') }
  if (!response.ok) {
    const message = typeof body === 'object' && body !== null && typeof (body as { error?: unknown }).error === 'string' ? (body as { error: string }).error : 'HTTP ' + response.status
    throw new Error(message)
  }
  return body as T
}

/** Type-only surface (export discipline: no value exports beyond the plugin contract). */
export type { PanelSnapshot } from './controller.ts'

/** Required services (the runtime must be up before mounting). */
export const inject = ['slots', 'locale']

/**
 * Mount the Wigolo panel surfaces.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  const controller = new PanelController()
  const api = makeApi()

  // Register locale dictionaries through ctx.effect so they auto-unregister on
  // dispose; inject declares 'locale'. Uses the single-locale
  // register(ns, locale, dict) form (dsh-better-sidebar precedent), so the
  // typed bind below returns the wide Translate compatible with the panels.
  ctx.effect(() => {
    const offZh = ctx.locale.register('dsh-wigolo', 'zh', zh)
    const offEn = ctx.locale.register('dsh-wigolo', 'en', en)
    return () => { offZh(); offEn() }
  }, 'dsh-wigolo: dictionaries')
  const translate: (key: string) => string = ctx.locale.bind('dsh-wigolo')

  // Locale plumbing for the panel: a getter returning the active locale id and
  // a subscription that fires on every locale/snapshot change so the panel can
  // re-render (e.g. re-fetch the help-tab guide in the new language).
  const locale: () => string = () => ctx.locale.getLocale().active
  const subscribeLocale: (fn: () => void) => () => void = (fn) =>
    ctx.locale.subscribe(() => { fn() })

  const disposers: Array<() => void> = []
  try {
    disposers.push(mountSidebarEntry(controller, css as unknown as Record<string, string>, translate))
    disposers.push(mountPanel(controller, api, translate, locale, subscribeLocale))
  } catch (error) {
    // DOM failures degrade the panel, never the GUI.
    console.warn('[dsh-wigolo] mount failed:', error)
  }

  // Cache tab (conversation.view): registered only while cacheTab.enabled is
  // on. Panel saves dispatch CACHE_TAB_TOGGLED_EVENT (after persisting), and
  // a config poll backstops missed events — both drive dispose+re-register,
  // so the tab appears/disappears without a page refresh.
  disposers.push(registerCacheTab(ctx, translate, () => ({
    list: async (limit?: number) => readJson(await fetch(WIGOLO_API.cacheTabList + (limit !== undefined ? '?limit=' + limit : ''))),
    stats: async () => readJson(await fetch(WIGOLO_API.cacheTabStats)),
    entry: async (url: string) => readJson(await fetch(WIGOLO_API.cacheTabEntry + '?url=' + encodeURIComponent(url))),
    watchList: async () => readJson(await fetch(WIGOLO_API.cacheTabWatch)),
    watchAction: async (action: 'check' | 'pause' | 'resume', jobId: string) => readJson(await fetch(WIGOLO_API.cacheTabWatch, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ action, job_id: jobId }),
    })),
    sessionInfo: async (sessionId: string) => readJson(await fetch(WIGOLO_API.cacheTabSession + '?sessionId=' + encodeURIComponent(sessionId))),
  })))
  ctx.effect((): (() => void) => {
    return () => {
      for (const dispose of disposers.splice(0)) dispose()
    }
  }, 'dsh-wigolo: ui mounts')
}
