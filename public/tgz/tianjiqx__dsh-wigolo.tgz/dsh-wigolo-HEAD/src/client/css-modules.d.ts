/** CSS-modules type declaration (tsdown/lightningcss handles the actual import). */
declare module '*.module.css' {
  const classes: Record<string, string>
  export default classes
}
