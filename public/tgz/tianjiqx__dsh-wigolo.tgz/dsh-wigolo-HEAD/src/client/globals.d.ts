/** Build-time globals injected by tsdown's define (see tsdown.config.ts). */

/** Plugin version from package.json, injected at build time. */
declare const __WIGOLO_VERSION__: string

/** Guide content from GUIDE.{zh.}md, injected at build time. */
declare const __GUIDE_CONTENT__: string
