/**
 * Web seam providers (WebSearchProvider + WebFetchProvider) backed by the
 * wigolo daemon. Registered only when takeover != 'none' — see the
 * AMBIGUOUS-trap note in the plugin entry. Registration order never matters:
 * the seam resolves providers at call time by configured id.
 */

import type { WigoloMcpClient } from './mcp-client.ts'
import { SEARCH_PROVIDER_ID, FETCH_PROVIDER_ID } from './invariant.ts'

/** Map a wigolo search payload to the dsh-web WebSearchResult shape (contract from the legacy plugin). */
export function toSearchResult(payload: Record<string, unknown>): { content?: string; sources: Array<{ url: string; title?: string; snippet?: string; publishedAt?: string }>; truncated: boolean } {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const raw = Array.isArray(payload.results) ? payload.results : []
  const sources = raw
    .map((r) => {
      const item = (r ?? {}) as Record<string, unknown>
      return {
        url: typeof item.url === 'string' ? item.url : '',
        ...(typeof item.title === 'string' && item.title !== '' ? { title: item.title } : {}),
        ...(typeof item.snippet === 'string' && item.snippet !== '' ? { snippet: item.snippet } : {}),
        ...(typeof item.published_date === 'string' && item.published_date !== '' ? { publishedAt: item.published_date } : {}),
      }
    })
    .filter((s) => s.url.length > 0)
  const content = (typeof payload.answer === 'string' && payload.answer !== '' ? payload.answer : undefined)
    ?? (typeof payload.report === 'string' && payload.report !== '' ? payload.report : undefined)
  return { ...(content !== undefined ? { content } : {}), sources, truncated: false }
}

/** Map a wigolo fetch payload to the dsh-web WebFetchResult shape. */
export function toFetchResult(payload: Record<string, unknown>, requestUrl: string): { url: string; statusCode: number; body: { kind: 'text'; content: string }; truncated: boolean } {
  const markdown = typeof payload.markdown === 'string' ? payload.markdown : ''
  return {
    url: typeof payload.url === 'string' && payload.url !== '' ? payload.url : requestUrl,
    statusCode: typeof payload.http_status === 'number' ? payload.http_status : 200,
    body: { kind: 'text', content: markdown },
    truncated: false,
  }
}

/** Search provider bridging the seam's search() to wigolo's search tool. */
export class WigoloSearchProvider {
  readonly id = SEARCH_PROVIDER_ID
  constructor(private readonly client: WigoloMcpClient, private readonly tokenPresent: boolean) {}

  /** Cheap local check only — no network calls (contract requirement). */
  available(): boolean {
    return this.tokenPresent && this.client.settings.host !== '' && this.client.settings.port > 0
  }

  async search(request: { query: string; maxResults?: number }): Promise<ReturnType<typeof toSearchResult>> {
    const payload = await this.client.callToolObject('search', {
      query: request.query,
      max_results: Math.min(request.maxResults ?? 10, 20),
    })
    return toSearchResult(payload)
  }
}

/** Fetch provider bridging the seam's fetch() to wigolo's fetch tool. */
export class WigoloFetchProvider {
  readonly id = FETCH_PROVIDER_ID
  constructor(private readonly client: WigoloMcpClient, private readonly tokenPresent: boolean) {}

  available(): boolean {
    return this.tokenPresent && this.client.settings.host !== '' && this.client.settings.port > 0
  }

  async fetch(request: { url: string }): Promise<ReturnType<typeof toFetchResult>> {
    const payload = await this.client.callToolObject('fetch', {
      url: request.url,
      include_full_markdown: true,
    })
    return toFetchResult(payload, request.url)
  }
}
