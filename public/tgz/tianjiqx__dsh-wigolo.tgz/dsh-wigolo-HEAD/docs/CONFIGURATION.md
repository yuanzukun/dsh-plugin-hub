# Configuration System

## Overview

dsh-wigolo uses a three-layer configuration system, each layer serving a distinct purpose:

1. **Official Settings UI** (hot-reload): High-level behavioral switches
2. **Config file** (mostly hot-apply): Structural configuration — connection edits and the cacheTab toggle take effect immediately; tool-exposure and takeover changes need a restart
3. **Token file** (secret): Bearer token for daemon authentication — hot-apply on write

This separation prevents the common confusion of "I changed a setting but it didn't take effect" by making the restart requirement explicit.

## Layer 1: Official Settings UI

**Location**: ~/.dsh/settings.json (managed by DSH settings service)

**Fields**:
- `enabled` (boolean, default: true): Master switch for the plugin. When false, routes/tools/providers are not registered.
- `announceToAgent` (boolean, default: true): Whether to inject the WIGOLO_GUIDANCE into agent system prompts.
- `guidance` (string, optional): Override the default announcement text. Useful for localization or custom usage patterns.

**Hot-reload**: Changes take effect immediately without restarting DSH. The plugin uses `installSettingsSection` (dsh-ssh pattern) to register a settings card in the official DSH settings UI.

**Implementation**:
```typescript
// src/index.ts
export const Config: z<Config> = z.object({
  enabled: z.boolean().default(true),
  announceToAgent: z.boolean().default(true),
  guidance: z.string(),
})

installSettingsSection(ctx, WIGOLO_SETTINGS_NAMESPACE, Config, config ?? {}, {
  setSource: (source) => { current = source; sync() },
  onChange: sync,
})
```

The `sync()` function tears down and re-registers tools/prompt sections when settings change.

## Layer 2: Config File

**Location**: ~/.dsh/wigolo.json

**Schema** (v2):
```jsonc
{
  "version": 2,
  "connection": {
    "host": "127.0.0.1",        // daemon address
    "port": 3333,
    "hostHeader": "auto",       // auto | none | "<literal>"
    "tokenFile": ""             // "" = ~/.dsh/wigolo-token
  },
  "takeover": false,           // true = wigolo drives web_search + web_fetch; false = official providers
  "tools": {
    "wigolo_search":  { "enabled": true,  "defaults": { "max_results": 10 } },
    "wigolo_crawl":   { "enabled": true,  "defaults": { "max_pages": 50 }, "timeoutMs": 300000 },
    "wigolo_extract": { "enabled": true },
    "wigolo_research":{ "enabled": true,  "timeoutMs": 600000 },
    "wigolo_find_similar": { "enabled": false },
    "wigolo_cache":   { "enabled": true },
    "wigolo_watch":   { "enabled": true }
  },
  "cacheTab": { "enabled": false },   // "Wigolo Cache" read-only GUI tab (default off; hot-apply)
  "announceToAgent": true
}
```

**Apply semantics**: Connection edits and the cacheTab toggle take effect immediately (the live MCP client is hot-reconfigured and the tab slot re-registers — no restart). Tool **exposure** changes and **takeover** require a DSH restart; the panel shows a restart hint only for those.

**Atomic writes**: The ConfigStore uses tmp + rename to ensure the file is never in a half-written state.

**Fail-loud validation**: Unknown keys trigger warnings with "did you mean?" hints:
```
[dsh-wigolo] unknown config key "hostheader" in ~/.dsh/wigolo.json — did you mean "hostHeader"? (ignored)
```

The hint uses edit-distance matching (Levenshtein distance ≤ max(2, key.length/3)).

## Layer 3: Token File

**Location**: ~/.dsh/wigolo-token (or custom path via `connection.tokenFile`)

**Permissions**: 0600 (owner read/write only)

**Format**: First line contains the bearer token. Subsequent lines are ignored.

**Why separate?**: Secrets in config files are a security risk:
- Accidental commits to version control
- World-readable permissions (config files are often 0644)
- Harder to audit ("where is the token?")

By isolating the token, we can:
- Enforce 0600 permissions explicitly
- Never return it in API responses (only `hasToken: boolean`)
- Write it directly from the panel (no terminal required)

**Token resolution order**:
1. `WIGOLO_TOKEN` environment variable (highest priority, for testing)
2. Token file (default: ~/.dsh/wigolo-token)

**Panel write**: The Connection tab has a password input that writes the token to the file:
```
POST /api/dsh-wigolo/token
{ "token": "..." }
→ writes to ~/.dsh/wigolo-token with 0600 permissions
→ returns { ok: true, hasToken: true }
```

The token is never echoed back.

## Tool Defaults

Each tool can have `defaults` (merged under model arguments) and `timeoutMs` (override):

```json
"wigolo_search": {
  "enabled": true,
  "defaults": { "max_results": 10, "search_depth": "balanced" },
  "timeoutMs": 60000
}
```

**Merge order**: Model arguments > Config defaults > Built-in defaults

**Rationale**: Users can set their preferred defaults (e.g., always use `search_depth: "deep"`) without repeating them in every prompt.

## Cache Tab

`cacheTab.enabled` (default `false`) registers the "Wigolo Cache" read-only GUI tab (a `conversation.view` slot) that browses the daemon's cache snapshot library and watch jobs. Toggling it from the panel hot-applies (the slot disposes/re-registers — no restart). When off, the tab is absent and its API routes return 403. See [CACHE-TAB.md](./CACHE-TAB.md) for the design.

The cache tab reads through four loopback-fenced host routes: `/api/dsh-wigolo/cache-tab/list`, `/cache-tab/stats`, `/cache-tab/entry`, and `/cache-tab/watch` (GET list / POST check|pause|resume). List responses strip markdown; entry carries one row's markdown on demand.

## Takeover

The `takeover` field is a boolean controlling whether wigolo replaces the official web_search/web_fetch providers:

- `true`: wigolo drives both web_search and web_fetch
- `false`: wigolo does not register any providers (default)

**Implementation**: When `takeover` is `true`, the plugin writes a managed block to ~/.dsh/cordis.patch.yml (see [PROVIDERS.md](./PROVIDERS.md)).

**Restart required**: The web seam's provider routing is read at startup, so takeover changes require a restart.

## Configuration Flow

```
User edits settings UI
  ↓
installSettingsSection fires onChange
  ↓
sync() re-registers tools/prompt (hot-reload)

User edits panel (connection/tools)
  ↓
POST /api/dsh-wigolo/config or /tools
  ↓
ConfigStore.update() writes ~/.dsh/wigolo.json (atomic)
  ↓
Panel shows "restart required" hint

User writes token in panel
  ↓
POST /api/dsh-wigolo/token
  ↓
ConfigStore.writeToken() writes ~/.dsh/wigolo-token (0600)
  ↓
live client hot-reconfigured → agent tools use it immediately (no restart)
```