# Design Documentation

This directory contains design documentation for dsh-wigolo.

**中文文档**: [Chinese version](./zh/README.md)

## Documents

- **[ARCHITECTURE.md](./ARCHITECTURE.md)** — Overall system design, component relationships, design principles
- **[CONFIGURATION.md](./CONFIGURATION.md)** — Three-layer config system (Settings UI / config file / token file)
- **[PROVIDERS.md](./PROVIDERS.md)** — Web seam provider takeover mechanism and the AMBIGUOUS trap
- **[TOOLS.md](./TOOLS.md)** — Seven agent tools and the parameter trimming philosophy
- **[SECURITY.md](./SECURITY.md)** — Security model (loopback fence, token handling, fail-loud validation)
- **[CLIENT.md](./CLIENT.md)** — Client-side architecture (sidebar entry, panel, cross-panel mutex)
- **[CACHE-TAB.md](./CACHE-TAB.md)** — The opt-in "Wigolo Cache" read-only tab (design, routes, module gate)

## Key Design Decisions

### Agent-First (revised)

The plugin's core value is the seven agent tools. Write operations (search, crawl, cache clear, watch create/delete) stay agent-only. Read-only browsing — the cache snapshot library and watch status — surfaces in an opt-in "Wigolo Cache" tab (off by default; see docs/CACHE-TAB.md).

### Configuration Layering

Three layers with clear restart semantics:
1. **Settings UI** (hot-reload): enabled, announceToAgent, guidance
2. **Config file** (restart required): connection, tools, takeover (boolean)
3. **Token file** (secret): bearer token

### Fail-Loud Over Fail-Silent

Unknown config keys trigger warnings with "did you mean?" hints instead of being silently dropped.

### No External UI Dependencies

The plugin does not depend on better-sidebar or other community plugins. All UI is self-contained (sidebar entry + panel).

## Version History

See [CHANGELOG.md](../CHANGELOG.md) for the full version history.

### v1.2.0 (current)

- Optional "Wigolo Cache" conversation tab (read-only daemon cache browser)
- Panel i18n (zh/en bilingual)
- Connection/token edits hot-apply
- Usage guide (Help tab)
- watch action names fixed, extract fallback explicit

### v1.1.0

- Agent-first positioning (panel is config-only)
- Token write from panel (no terminal required)
- Official settings integration (hot-reload)
- Fail-loud config validation
- Panel slimmed to 3 tabs

### v1.0.0

- Initial release
- Seven agent tools
- Provider takeover (boolean switch)
- Sidebar panel with 3 tabs
- MCP client with hostHeader resolution