# Client-Side Architecture

## Overview

The client half of dsh-wigolo runs in the DSH web GUI (browser). It provides:

1. **Sidebar entry**: A clickable row in the sidebar that toggles the panel
2. **Panel**: A React-based configuration UI in the center column
3. **Cross-panel mutex**: Coordination with other panels (ssh, taskboard)

The client is agent-first: the panel covers configuration. Write operations (search, crawl, cache clear, watch create/delete) stay agent-only; read-only browsing of the cache snapshot library and watch status lives in the opt-in "Wigolo Cache" tab (off by default; docs/CACHE-TAB.md).

## Sidebar Entry

### DOM Injection

DSH's sidebar shell does not expose a plugin registration slot, so we inject the entry row directly into the DOM:

```typescript
// src/client/sidebar-entry.ts
export function mountSidebarEntry(controller, css): () => void {
  const entry = document.createElement('button')
  entry.dataset.dshWigoloEntry = ''
  entry.className = css.entry
  entry.innerHTML = '<span class="' + css.entryIcon + '">' + ICON + '</span><span class="' + css.entryLabel + '">Wigolo</span>'
  entry.addEventListener('click', () => controller.toggle())
  
  // Insert after the "New Session" button
  const root = sidebarRoot()
  const button = newSessionButton(root)
  root.insertBefore(entry, button.nextElementSibling)
  
  // Self-heal on shell re-renders
  const observer = new MutationObserver(() => {
    if (!root.contains(entry)) {
      root.insertBefore(entry, button.nextElementSibling)
    }
  })
  observer.observe(root, { childList: true, subtree: true })
  
  return () => {
    observer.disconnect()
    entry.remove()
  }
}
```

### Family Block Ordering

Multiple plugins (taskboard, ssh, wigolo) inject sidebar entries. To prevent them from swapping positions on shell re-renders, we use a "family block" protocol:

```typescript
const family = Array.from(root.children).filter(
  el => el.matches('[data-dsh-taskboard-entry], [data-dsh-ssh-entry], [data-dsh-wigolo-entry]')
)
const anchor = family.length > 0
  ? family[family.length - 1].nextElementSibling
  : base.nextElementSibling
root.insertBefore(entry, anchor)
```

**Rationale**: Without this, each plugin's MutationObserver might insert at slightly different times, causing entries to swap positions. The family block ensures stable ordering.

### Self-Healing

The MutationObserver watches for the entry being removed (by shell re-renders) and re-inserts it in the same frame (before paint), so there's no visible flicker.

## Panel

### Structure

The panel is a React 18 component with three tabs:

1. **Connection**: Host/port/token configuration + test connection
2. **Takeover & Tools**: Takeover mode switch + tool exposure flags
3. **About**: Documentation links, Host header explanation, migration guide

### Mount Point

The panel is mounted in the center column (conversation area) as an overlay:

```typescript
// src/client/mount.tsx
export function mountPanel(controller, api): () => void {
  const container = document.createElement('div')
  container.dataset.dshWigoloView = ''
  container.className = css.view
  
  const column = conversationColumn()
  column.appendChild(container)
  
  const root = createRoot(container)
  root.render(<WigoloPanel controller={controller} api={api} />)
  
  // Show/hide based on controller state
  const sync = () => {
    const open = controller.getSnapshot().panelOpen
    container.style.display = open ? 'block' : 'none'
  }
  controller.subscribe(sync)
  
  return () => {
    root.unmount()
    container.remove()
  }
}
```

### Token Write

The Connection tab has a password input that writes the token directly (no terminal required):

```tsx
<div className={css.field}>
  <label>Set token</label>
  <div style={{ display: 'flex', gap: 8 }}>
    <input type="password" value={token} onChange={...} />
    <button onClick={() => api.writeToken(token)}>Write</button>
  </div>
</div>
```

The API call:

```typescript
async writeToken(token: string) {
  return readJson(await fetch('/api/dsh-wigolo/token', {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ token }),
  }))
}
```

The token is sent over HTTPS (or HTTP if DSH is not using TLS), written to ~/.dsh/wigolo-token with 0600 permissions, and never echoed back.

## Cross-Panel Mutex

### The Problem

Multiple panels (ssh, taskboard, wigolo) can be open simultaneously, overlapping in the center column. This creates visual chaos.

### The Solution

Panels coordinate via a custom event:

```typescript
// When opening wigolo panel
window.dispatchEvent(new CustomEvent('dsh-panel-activate', { detail: 'wigolo' }))

// When any panel receives the event
window.addEventListener('dsh-panel-activate', (event) => {
  if (event.detail !== 'wigolo') {
    controller.closePanel()  // Close ourselves if another panel is activating
  }
})
```

### Active Attribute

The panel also sets a data attribute on `<html>` for CSS styling:

```typescript
const html = document.documentElement
if (open) {
  // Remove other panels' active attributes
  html.removeAttribute('data-dsh-taskboard-active')
  html.removeAttribute('data-dsh-ssh-active')
  // Set our own
  html.setAttribute('data-dsh-wigolo-active', '')
} else {
  html.removeAttribute('data-dsh-wigolo-active')
}
```

**Rationale**: This allows CSS to hide the conversation content when any panel is active, without JavaScript coordination.

## Controller

The panel state is managed by a simple controller:

```typescript
export class PanelController {
  private open = false
  private listeners = new Set<() => void>()
  
  getSnapshot() {
    return { panelOpen: this.open }
  }
  
  subscribe(listener: () => void) {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }
  
  toggle() {
    this.open = !this.open
    this.listeners.forEach(l => l())
  }
  
  openPanel() {
    if (!this.open) {
      this.open = true
      this.listeners.forEach(l => l())
    }
  }
  
  closePanel() {
    if (this.open) {
      this.open = false
      this.listeners.forEach(l => l())
    }
  }
}
```

The controller follows the React `useSyncExternalStore` pattern (getSnapshot + subscribe), so React components can read the state efficiently.

## API Client

The API client is a thin wrapper around fetch:

```typescript
export function makeApi(): WigoloApi {
  return {
    async getConfig() {
      return readJson(await fetch('/api/dsh-wigolo/config'))
    },
    async updateConnection(payload) {
      return readJson(await fetch('/api/dsh-wigolo/config', {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload),
      }))
    },
    async writeToken(token) {
      return readJson(await fetch('/api/dsh-wigolo/token', {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ token }),
      }))
    },
    async testConnection() {
      return readJson(await fetch('/api/dsh-wigolo/test', { method: 'POST' }))
    },
    // ...
  }
}
```

All API calls are loopback-only (enforced by the host), so the client does not need to handle authentication or CORS.

## Build Output

The client is built by tsdown into a single closure-factory bundle. Platform
externals (`react`, `react-dom/client`, `react/jsx-runtime`) stay external and
are resolved through the `require` the shell injects:

```
src/client/index.ts
  ↓ tsdown (CJS + outputOptions banner/intro/footer)
lib/client.js
```

The ModuleLoader wrapper is emitted by `outputOptions` (banner / intro /
footer), producing the exact shape other dsh plugins (dsh-ssh, dsh-context,
dsh-better-sidebar) use:

```javascript
window.__ModuleLoader__.load({
  id: "dsh-wigolo",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    let react = require("react");
    let react_dom_client = require("react-dom/client");
    // ... plugin code ...
    exports.apply = apply;
    exports.inject = inject;
    return module.exports;
  }
});
```

This matches the DSH web shell's module loading protocol (same as dsh-ssh).

## CSS Modules

The panel uses CSS Modules for scoped styles:

```tsx
import css from './panel.module.css'

<div className={css.panel}>
  <div className={css.panelHeader}>...</div>
</div>
```

A tsdown plugin compiles each `.module.css` with lightningcss inside the bundle:
the hashed class map becomes the default export, and the CSS text auto-injects a
`<style data-plugin="dsh-wigolo">` tag at factory execution (the loader removes
plugin-owned tags on unload). No separate `style.css` artifact is produced.

## Failure Policy

DOM mounting problems are logged, never thrown:

```typescript
export function apply(ctx: ClientContext): void {
  try {
    disposers.push(mountSidebarEntry(controller))
    disposers.push(mountPanel(controller, api))
  } catch (error) {
    console.warn('[dsh-wigolo] mount failed:', error)
  }
}
```

**Rationale**: The DSH web shell fails the whole boot when a plugin apply throws. An external plugin must not take the GUI down.

## Cache Tab (conversation.view)

Read-only cache/watch browsing ships as an opt-in **"Wigolo Cache"** tab on the conversation tab bar, implemented as a `conversation.view` slot (`id: 'wigolo-cache'`, order 40). It is registered only while `cacheTab.enabled` is on; the panel toggle drives dispose + re-register (see [CACHE-TAB.md](./CACHE-TAB.md)). Design, routes, and the module gate are documented there; the tab itself reads through the four `/api/dsh-wigolo/cache-tab/*` host routes.
