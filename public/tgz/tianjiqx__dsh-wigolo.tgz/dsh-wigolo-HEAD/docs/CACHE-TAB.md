# 缓存浏览 Tab 设计文档

> 状态：**已实施**（P0+P1）。本文件保留为设计依据与实现记录。
> 前置讨论结论：缓存数据全量存于 wigolo daemon 服务端（本机零副本）；fast/balanced 搜索不落缓存、deep 档 enrichment 与 crawl/research 落盘；条目与会话无关联标记。

## 1. 动机与定位

### 解决什么问题

- wigolo daemon 上积累了大量已抓取网页的全文 markdown 快照（实测 559 URL / 148MB / 跨度约一个月），目前只能通过 agent 对话（wigolo_cache 工具）检索，用户无法自主浏览、无法离线复查原文
- watch 监控任务的生命周期（next_check_in / paused 态）同样没有可视化

### 明确不做什么（边界）

| 不做 | 理由 |
|---|---|
| 面板内发起实时搜索 | 搜索是 agent 职责（模型要判断 query 变体/深度/域名过滤）；面板做搜索框与 agent 抢职责，且绕过缓存优先引导 |
| 待办/记忆类 tab | wigolo 无待办语义；参考 memory-evolve 的是机制（slot 注册/badge/开关），不是功能清单 |
| watch 任务创建表单 | 创建/删除走 agent 对话；tab 只做查看 + 快捷操作（check/pause/resume），delete 不进 UI 防误删 |
| 缓存清除按钮 | 破坏性操作（148MB 共享库），保留 agent 工具入口（已有确认语义）+ CLI，不给一键 UI |
| 会话精确关联（按 URL） | daemon 条目无会话标记，按 URL 精确关联留作 P2；「本会话期间」的时间锚点已改为真实会话创建时间（见 §2 修订） |

### 定位一句话

**远程快照库只读浏览器**：数据在 daemon、链路为宿主 API 代理、读写分离（tab 只读，写操作仍归 agent 工具）。同 SSH 插件看远程主机、memory-evolve tab 读 host API 一个模式。

## 2. 信息架构

### 顶层：单个 conversation.view tab

- slot: `conversation.view`，id: `wigolo-cache`，order: 40（memory 系之后）
- label: 「Wigolo 缓存」/ "Wigolo Cache"（带插件名前缀，清晰明确——一眼可辨来源，避免与其他插件的缓存类 tab 混淆；清晰性优先于 label 长度）
- **默认关闭**（opt-in，见 §5 开关），关闭时 slot 不注册，tab 完全不出现

### 子页导航（tab 内部，非顶层 tab）

```
Wigolo 缓存 tab
├── 子页 1：缓存浏览（默认）
└── 子页 2：监控任务
```

#### 子页 1：缓存浏览

- **默认时间倒序**：daemon cache 接口原生按 fetched_at 倒序返回（已实测验证），列表直接沿用，用户打开 tab 即看到最近抓取的内容（含最近搜索 deep 档/crawl 落盘的页面）
- 顶部统计条：`{total_urls} URL · {total_size_mb}MB · {oldest} ~ {newest}`（来自 cache stats）
- 关键词过滤框（前端过滤已拉取的元数据列表）
- 时间过滤开关：「仅看本会话期间」（窗口 = `[会话创建时间, 会话活跃期结束]`。**下界**：宿主 `SessionHeader.createdAt`（slot 注入的 sessionId 经 `/cache-tab/session` 路由查询；替换了早期 PAGE_LOADED_AT 近似，其在刷新/恢复旧会话/多 tab 场景下全错，且 createdAt 持久在会话头里，重开多久都正确）。**上界**：客户端 `useSession` 快照取 `turnTimings` 中最大的 `turn/end` 时间——锁定会话活跃期，排除休眠后其他客户端的抓取；会话 `running` 时上界放开（当前 turn 刚抓的内容晚于最后落盘消息，不能排除）；blank 会话窗口为空集（从未抓过，正确语义）。查不到创建时间（会话不 live）则隐藏该过滤项。仍按时间近似，活跃期内可能混入同期其他客户端内容——文案明示）
- 列表：url / title / fetched_at（倒序），行点击展开详情
- 详情：markdown 快照渲染（只读，懒加载：点开才请求该条 markdown）

#### 子页 2：监控任务

- 列表：url / interval_seconds / status / next_check_in（复用 host 侧 humanizeWatch 的格式化逻辑，保持工具与 UI 文案一致）
- 行内操作：立即 check / pause / resume（按钮态跟随 status）
- 无 delete 入口

## 3. 数据流与接口

### 链路

```
浏览器 React（CacheTabView）
  → fetch /api/dsh-wigolo/cache-tab/*（同源）
  → 插件 host 路由（guard 复用现有机制）
  → MCP client → wigolo daemon
```

### 新增 host 路由（只读 + 受控写）

| 路由 | 方法 | daemon 调用 | 说明 |
|---|---|---|---|
| /api/dsh-wigolo/cache-tab/list | GET | cache {limit} | 元数据列表（url/title/fetched_at，**不含 markdown**；daemon 原生 fetched_at 倒序，直接沿用） |
| /api/dsh-wigolo/cache-tab/stats | GET | cache {stats: true} | 统计条 |
| /api/dsh-wigolo/cache-tab/entry | GET | cache {url_pattern: <完整URL>} | 单条 markdown 全文（详情懒加载）。⚠️ 实测 url_pattern 只接受完整 URL 精确匹配（"trending"/"github.com" 子串均返回空），entry 请求必须传完整 URL |
| /api/dsh-wigolo/cache-tab/watch | GET | watch {action: list} | 任务列表 |
| /api/dsh-wigolo/cache-tab/session | GET | （不走 daemon）宿主 ctx.sessions.get(id).header.createdAt | 「本会话期间」过滤的真实锚点；会话不 live 返回 404 |
| /api/dsh-wigolo/cache-tab/watch | POST | watch {action: check/pause/resume, job_id} | 快捷操作（无 create/delete） |

约束：
- 所有路由带现有 guard；模块开关关闭时返回 403 "cache tab disabled"（对齐 memory-evolve 的 API 拒绝模式）
- 列表响应必须裁剪 markdown 字段（daemon cache 返回含全文，host 侧剥掉，避免一次 148MB 灌进浏览器）
- watch 操作路由对非幂等动作（check）直接透传 daemon 语义，不做重试

### 前端交互约束（远程数据的防抖策略）

- 首屏：拉元数据列表（可分页，复用 cache limit 参数）+ stats，之后**关键词/时间过滤全部在前端做**（元数据量小：559 条 × ~100B）
- markdown 详情：点开才请求（懒加载），长文分页或滚动加载
- daemon 不可达：列表区显示离线态（"daemon 离线，检查连接配置" + 跳转连接 Tab 入口），不显示无解释的空白/报错堆栈
- 请求失败静默重试一次，再失败落离线态

## 4. 与现有模块的关系

### 与 ARCHITECTURE.md "Agent-First" 原则的关系

现有文档写死了 "Cache browsing … happen through agent conversations, not dedicated UI surfaces"。本设计**有意修订**该原则为：

> Agent 优先：写操作（搜索/爬取/清除/创建监控）仍是 agent 工具；**只读浏览**（缓存复查、监控状态查看）可由 GUI 承担，条件是默认关闭、不与 agent 职责重叠。

实施时必须同步修订 ARCHITECTURE.md / README（中英）相关段落，否则重蹈"文档与实现不一致"（本次优化刚修过的问题）。

### 与 wigolo_cache / wigolo_watch 工具的关系

- 不替代：工具仍是模型侧唯一入口，工具描述不变
- 复用：humanizeWatch 的 next_check_in 格式化在 host 路由层复用（同一份代码两处消费），annotateExtract 不涉及

### 与侧边栏配置面板的关系

- 面板新增「缓存 Tab」开关行（见 §5），放「接管与工具」页
- 面板本身不新增任何缓存浏览 UI（职责不混）

## 5. 开关与动态生效

### 配置模型

`~/.dsh/wigolo.json` tools 同级新增：

```json
{ "cacheTab": { "enabled": false } }
```

- 默认 false（opt-in，避免 tab 膨胀）
- 走现有配置存取（fail-loud 的未知键告警机制自动覆盖）

### 动态生效（两档）

**目标档：即时动态（无需刷新）**
- 面板保存 → host 落盘 + 响应携带新 cacheTab.enabled
- 客户端 dispose 旧 slot 注册 / 重注册（照 memory-evolve 的 disposeXxxTab?.() + ctx.slots.inject('conversation.view', …) 模式原样套用，不自建事件通道）
- 已验证先例：memory-evolve badge 变化驱动的 tab 重注册在同一 shell 上工作正常

**保底档：刷新生效**
- 若实测 shell 对 slot 注销响应异常（tab 消失但占位残留等），降级为保存后提示"刷新页面后生效"（memory-evolve 提示词管理器同款文案模式）
- 两档配置存法完全相同，降级不影响数据模型

### 红点徽标（P2，可后置）

daemon 连接状态轮询（复用面板 test 逻辑），离线时 tab label 显示离线标记，避免用户点进去才发现不可达。

## 6. 实施切分

| 阶段 | 内容 | 规模 |
|---|---|---|
| P0 | host 路由 ×5 + 配置开关 + slot 注册/注销 + 空白子页骨架 | ~150 行 |
| P1 | 缓存浏览子页（列表/过滤/详情懒加载/离线态） | ~250 行 |
| P1 | 监控子页（列表 + check/pause/resume） | ~120 行 |
| P2 | 会话 URL 轨迹匹配（host 侧 Map<sessionId, Set<url>>，tab 内「本会话相关」筛选 + 徽标） | ~80 行 |
| P2 | daemon 离线红点徽标 | ~40 行 |

单次提交可完成 P0+P1；P2 按使用反馈决定。

## 7. 测试

- host 路由：单元测试覆盖 list 裁剪 markdown、模块关闭 403、watch 操作透传（mock MCP client）
- 辅助逻辑：时间过滤边界（无 oldest）、url 精确匹配
- 客户端：过滤交互、离线态渲染（沿用现有 vitest + 面板测试基建）
- 真实 daemon 冒烟：复用 test/smoke-real-daemon.mjs 模式加 cache-tab 路由段

## 8. 风险与开放问题

- **slot 注销的 shell 响应**：设计已含保底档；实施首日先做 P0 验证这一点，异常即锁定降级档
- **url_pattern 语义已查明（glob fullmatch）**：实测为对完整 URL 的 glob 全匹配——完整 URL 精确命中；`*kw*` 子串过滤（命中 4 条验证）；裸子串/`github*`（缺前导 `*`）不命中。工具描述与中英文档已按此修正（docs/TOOLS.md + src/tools.ts）。设计影响：entry 路由传完整 URL 仍正确；前端过滤仍为主策略（首屏元数据在手、零延迟），daemon `*kw*` 检索留作大列表服务端过滤后备；P2 会话 URL 轨迹匹配可直接用精确 url_pattern 批量查命中
- **daemon cache 接口的列表能力**：cache 工具以 query/url_pattern 检索为主，若"全量元数据列举"无原生支持（limit 只有过滤后语义），列表路由需带一个宽松 query（如空串行为实测）或退化为首屏按 stats.newest 向前翻页——P0 实施时实测定案
- **多客户端共享缓存**：内容可能混有其他会话/机器的调研结果，时间过滤文案已明示；不做隔离（daemon 侧无会话标记）
- **markdown 大条目**：单条可能数 MB，详情路由必要时加 max_tokens_out 裁剪 + 前端分页
