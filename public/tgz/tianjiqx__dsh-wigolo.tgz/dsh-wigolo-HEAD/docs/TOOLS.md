# Agent Tools

## Overview

dsh-wigolo exposes seven agent tools, each mapping to a wigolo daemon capability. The key design decision is **parameter trimming**: wigolo's MCP tools have 15-25 parameters each, but we expose only 6-10 per tool.

## Why Trim Parameters?

The model's tool selection accuracy degrades with large parameter schemas. A tool with 20 parameters is harder for the model to use correctly than one with 8. We trim to the high-frequency subset that covers 95% of use cases.

**Example**: wigolo's `search` tool has 25 parameters. We expose 11:
- query (required)
- max_results, category, time_range, from_date, to_date
- include_domains, exclude_domains, search_depth
- force_refresh, exact_match

The remaining 14 (render_js, use_auth, max_fetches, include_content, content_max_chars, max_content_chars, max_total_chars, format, max_highlights, include_favicon, include_images, max_tokens_out, include_full_markdown, citation_format, mode, agent_context) are advanced options that rarely need to be set by the model.

## Tool List

### wigolo_search

**Capability**: Advanced web search with 18+ engines, RRF fusion, local cache

**Parameters**:
- `query` (required): Search query, or "a | b" for parallel multi-variant search
- `max_results`: Max results (default 10, max 20)
- `category`: general | news | code | docs | papers | images
- `time_range`: day | week | month | year
- `from_date` / `to_date`: ISO date filters
- `include_domains` / `exclude_domains`: Domain filters
- `search_depth`: ultra-fast | fast | balanced | deep
- `force_refresh`: Bypass cache
- `exact_match`: Quoted phrase search

**Output**: Sources array with url/title/snippet/score/publishedAt + engines_used + total_time_ms

**Timeout**: 60s (configurable)

### wigolo_crawl

**Capability**: Crawl a site from a seed URL, following links

**Parameters**:
- `url` (required): Seed URL
- `max_depth`: Max link depth (default 2, max 5)
- `max_pages`: Max pages to fetch (default 50, max 500)
- `include_patterns` / `exclude_patterns`: URL pattern filters
- `strategy`: bfs | dfs

**Output**: Raw crawl result (pages array)

**Timeout**: 300s (configurable)

**Use case**: "Crawl the React docs site so I can ask questions about it later"

### wigolo_extract

**Capability**: Extract structured data from a URL

**Parameters**:
- `url` (required): Target URL
- `css_selector`: CSS selector to extract
- `multiple`: Return all matches (true) or first (false)
- `schema`: Field extraction schema (JSON object)
- `max_tokens_out`: Cap output size

**Output**: Extracted data (structure depends on selector/schema)

**Timeout**: 60s (configurable)

**Use case**: "Extract all prices from this product page"

### wigolo_research

**Capability**: Multi-step research with sub-query decomposition

**Parameters**:
- `question` (required): Research question
- `depth`: quick | standard | deep
- `max_sources`: Max sources to consult (default 8, max 30)
- `include_domains` / `exclude_domains`: Domain filters

**Output**: Report (cited synthesis) + raw payload

**Timeout**: 600s (configurable)

**Use case**: "Research the tradeoffs between Rust and Go for backend services"

### wigolo_find_similar

**Capability**: Find related content from a URL or concept

**Parameters**:
- `url`: Seed URL
- `concept`: Concept text (alternative to URL)
- `max_results`: Max results (default 10, max 20)
- `include_web`: Search beyond local cache

**Output**: Sources array

**Timeout**: 120s (configurable)

**Default**: Disabled (rarely needed; enable in config)

**Use case**: "Find similar articles to this one"

### wigolo_cache

**Capability**: Search the local cache without hitting the network

**Parameters**:
- `query`: Search by keyword
- `url_pattern`: Glob pattern matched against the full URL (fullmatch): exact URL for one entry, `*keyword*` for substring, `*suffix` for suffix. Bare substrings without `*` match nothing.
- `since`: Only entries newer than this
- `stats`: Return cache statistics
- `clear`: Wipe the cache (destructive)
- `limit`: Max entries to return (default 10, max 50)

**Output**: Cache entries or stats

**Timeout**: 30s (configurable)

**Use case**: "Check if we have cached content about React hooks" or "Clear the cache"

**Note**: The wigolo_cache tool searches the daemon's snapshot library; an opt-in "Wigolo Cache" GUI tab (conversation.view, off by default) also browses it read-only — see [CACHE-TAB.md](./CACHE-TAB.md).

### wigolo_watch

**Capability**: Monitor URLs for changes

**Parameters**:
- `action` (required): create | list | check | pause | resume | delete (add/remove accepted as aliases and normalized to create/delete)
- `url`: URL to watch (create/check)
- `urls`: Multiple URLs (create)
- `interval_seconds`: Re-check interval (min 60, max 86400)
- `selector`: Watch only this CSS selector subtree
- `job_id`: Job id (pause/resume/delete/check one job)

**Output**: Job list or confirmation

**Timeout**: 120s (configurable)

**Use case**: "Watch this pricing page daily and tell me if it changes"

**Note**: Jobs persist across daemon restarts. Pair with a scheduled agent task for notifications.

## Parameter Trimming Philosophy

For each tool, we ask: "What parameters does the model need to set in 95% of cases?"

- **Always expose**: The required parameter + the 5-8 most common optional parameters
- **Never expose**: Internal tuning knobs (max_tokens_out, citation_format, render_js)
- **Sometimes expose**: Advanced options that power users might want (force_refresh, exact_match)

The goal is to make the tools easy to use correctly, not maximally flexible. Users who need the full parameter surface can call wigolo directly via MCP.

## Tool Registration

Tools are registered using the official `defineTool` DSL from @deepseek-ai/dsh-tools:

```typescript
export function wigoloSearchTool(client, config) {
  return defineTool({
    name: 'wigolo_search',
    description: '...',
    parameters: {
      query: { type: 'string', required: true, description: '...' },
      max_results: { type: 'number', description: '...' },
      // ...
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value) => text(renderSources(value)),
    },
    timeoutMs: effectiveTimeout(config, 60_000),
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      // ...
    },
  })
}
```

Benefits of `defineTool`:
- Automatic parameter validation
- Type-safe execute function
- Official output schema/render contract
- Concurrency safety declaration

## Tool Exposure Flags

Each tool can be disabled in the config:

```json
"tools": {
  "wigolo_find_similar": { "enabled": false }
}
```

Disabled tools are not registered, so they don't appear in the agent's tool list.

**Default exposure**:
- Enabled: search, crawl, extract, research, cache, watch
- Disabled: find_similar (rarely needed)

## Timeout Budgets

Each tool has a default timeout, configurable per-tool:

| Tool | Default | Rationale |
|------|---------|-----------|
| search | 60s | Most searches complete in <10s |
| crawl | 300s | Crawling 500 pages can take minutes |
| extract | 60s | Single-page extraction is fast |
| research | 600s | Multi-step research is slow |
| find_similar | 120s | Cache lookup + optional web search |
| cache | 30s | Local cache operations are instant |
| watch | 120s | Job management is fast |

Users can override these in the config:

```json
"wigolo_research": { "timeoutMs": 900000 }
```

## Output Rendering

Tools with source-shaped output (search, find_similar) use a custom renderer:

```typescript
render: (_args, value) => text(renderSources(value))
```

The renderer formats sources as:

```
[0.912] Title (2025-01-02)
  https://example.com
  Snippet text...
engines: google, bing, duckduckgo
time: 120ms
```

This gives the model a compact, scannable view of the results.
