# 设计文档

本目录包含 dsh-wigolo 的设计文档。

## 文档列表

- **[ARCHITECTURE.md](./ARCHITECTURE.md)** — 系统架构、设计原则、组件关系
- **[CONFIGURATION.md](./CONFIGURATION.md)** — 三层配置系统（设置界面 / 配置文件 / token 文件）
- **[PROVIDERS.md](./PROVIDERS.md)** — Web seam provider 接管机制与 AMBIGUOUS 陷阱
- **[TOOLS.md](./TOOLS.md)** — 七个 agent 工具与参数裁剪哲学
- **[SECURITY.md](./SECURITY.md)** — 安全模型（回环栅栏、token 处理、fail-loud 校验）
- **[CLIENT.md](./CLIENT.md)** — 客户端架构（侧边栏入口、面板、跨面板互斥）
- **[CACHE-TAB.md](../CACHE-TAB.md)** — 可选「Wigolo 缓存」只读 Tab（设计、路由、模块门控）

## 关键设计决策

### Agent 优先（已修订）

插件的核心价值是七个 agent 工具。写操作（搜索/爬取/缓存清除/监控创建与删除）仍归 agent。只读浏览——缓存快照库与监控状态——由默认关闭的「Wigolo 缓存」tab（可选启用）承载（见 docs/CACHE-TAB.md）。

### 配置分层

三层配置，各自有明确的重启语义：
1. **设置界面**（热更新）：enabled、announceToAgent、guidance
2. **配置文件**（需重启）：连接、工具、接管开关
3. **Token 文件**（密钥）：bearer token

### 失败即告警（Fail-Loud）

未知配置键触发警告并附带"你是不是想说……"提示，而不是被静默丢弃。

### 无外部 UI 依赖

插件不依赖 better-sidebar 等社区插件。所有 UI 自包含（侧边栏入口 + 面板）。

## 版本历史

完整版本历史见 [CHANGELOG.md](../CHANGELOG.md)。

### v1.2.0（当前）

- 可选「Wigolo 缓存」会话 Tab（只读浏览 daemon 缓存库与监控任务）
- 面板国际化（中英文双语）
- 连接/token 变更即时热更新
- 使用指南（Help Tab）
- watch action 名称修正、extract 降级显式化

### v1.1.0

- Agent 优先定位（面板仅用于配置）
- 面板内写入 token（无需终端）
- 官方设置集成（热更新）
- 失败即告警的配置校验
- 面板精简为 3 个 Tab

### v1.0.0

- 初始发布
- 七个 agent 工具
- Provider 接管（布尔开关）
- 3 个 Tab 的侧边栏面板
- 支持 hostHeader 解析的 MCP 客户端
