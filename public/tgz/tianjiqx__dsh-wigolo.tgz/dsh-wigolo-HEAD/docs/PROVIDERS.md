# Provider Takeover

## Overview

dsh-wigolo can route DSH's official `web_search` and `web_fetch` through the wigolo daemon. This is called "takeover" and is controlled by the `takeover` field in the config file.

## Why Takeover?

DSH's web seam is designed to be provider-agnostic. The default provider is `deepseek-official` (requires `DEEPSEEK_API_KEY`). By registering wigolo as a provider, users can:

- Use wigolo's 18+ search engines with RRF fusion
- Benefit from wigolo's local cache (repeated queries are instant)
- Route web_fetch through wigolo's markdown extraction

## The AMBIGUOUS Trap

DSH's web seam has strict provider selection rules:

1. If a provider is explicitly configured (`searchProvider: wigolo`), use it
2. If no provider is configured and exactly one is registered and available, use it
3. If no provider is configured and multiple are registered, throw `WEB_PROVIDER_AMBIGUOUS`

**The trap**: If the user has `deepseek-official` registered (default) AND wigolo registers, AND no explicit routing is set, web_search fails with AMBIGUOUS.

**The solution**: Takeover `true` automatically writes explicit routing to ~/.dsh/cordis.patch.yml. Takeover `false` does not register any providers, avoiding the conflict entirely.

## Takeover Switch

`takeover` is a simple boolean:

| Value | web_search | web_fetch | cordis patch | Restart |
|------|-----------|-----------|--------------|---------|
| `true` | wigolo | wigolo | writes managed block | required |
| `false` | official | official | removes managed block | required |

## Cordis Managed Block

When `takeover` is `true`, the plugin writes a self-managed block to ~/.dsh/cordis.patch.yml (dsh-skin pattern):

```yaml
# --- dsh-wigolo managed (auto-generated; do not edit) ---
- id: web
  name: '@deepseek-ai/dsh-web'
  config:
    searchProvider: wigolo
    fetchProvider: wigolo
# --- end dsh-wigolo managed ---
```

The block is bounded by markers so it can be safely added/removed without affecting other entries.

**Implementation**: `src/cordis-managed.ts` provides:
- `syncManagedBlock(takeover)`: writes the appropriate block (or removes it for `none`)
- `stripManagedBlock(content)`: removes any existing managed block
- `readManagedTakeover(content)`: reads the current routing from the block

## Provider Implementation

```typescript
// src/providers.ts
export class WigoloSearchProvider {
  readonly id = 'wigolo'
  
  available(): boolean {
    // Cheap local check — no network calls (seam contract)
    return this.tokenPresent && this.client.settings.host !== ''
  }
  
  async search(request) {
    const payload = await this.client.callToolObject('search', {
      query: request.query,
      max_results: Math.min(request.maxResults ?? 10, 20),
    })
    return toSearchResult(payload)
  }
}
```

**Contract mapping**:
- `results[].url` → `sources[].url`
- `results[].title` → `sources[].title`
- `results[].snippet` → `sources[].snippet`
- `results[].published_date` → `sources[].publishedAt`
- `answer` / `report` → `content`

## Registration Flow

```
DSH startup
  ↓
apply() reads config file
  ↓
takeover == true?
  ↓ YES
ctx.web.registerSearchProvider(new WigoloSearchProvider(...))
  ↓
(both providers registered together)
  ↓ YES
ctx.web.registerFetchProvider(new WigoloFetchProvider(...))
  ↓
takeover == false?
  ↓ YES
Do not register any providers
```

**Important**: Provider registration happens once at startup. Takeover changes require a restart because the web seam's routing is read at construction time.

## Why Not Hot-Reload Takeover?

The web seam's `searchProviderId` is read in the constructor:

```typescript
// @deepseek-ai/dsh-web
constructor(ctx, config = {}) {
  this.searchProviderId = config.searchProvider ?? process.env.DSH_WEB_SEARCH_PROVIDER
}
```

Changing it at runtime would require re-constructing the service, which is not supported by the cordis lifecycle. So takeover changes require a restart.

