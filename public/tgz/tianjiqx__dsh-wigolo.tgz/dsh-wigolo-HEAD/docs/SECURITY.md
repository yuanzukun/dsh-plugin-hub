# Security Model

## Overview

dsh-wigolo handles sensitive data (bearer tokens, daemon connections) and must defend against:

1. **LAN exposure**: DSH web GUI served on a LAN should not leak tokens or allow remote config changes
2. **Secret leakage**: Tokens should never appear in logs, API responses, or config files
3. **Config corruption**: Malformed config should fail loudly, not silently

## Loopback-Only API Routes

All panel API routes (/api/dsh-wigolo/*) are protected by a loopback-only trust fence:

```typescript
function isLoopbackRequest(request: IncomingMessage): boolean {
  // 1. Remote address must be loopback
  const address = request.socket.remoteAddress
  if (address !== '127.0.0.1' && address !== '::1' && address !== '::ffff:127.0.0.1') return false
  
  // 2. Host header must be loopback
  const host = request.headers.host
  const hostUrl = new URL('http://' + host)
  if (hostUrl.hostname !== '127.0.0.1' && hostUrl.hostname !== 'localhost' && hostUrl.hostname !== '[::1]') return false
  
  // 3. sec-fetch-site must not be cross-site
  if (request.headers['sec-fetch-site'] === 'cross-site') return false
  
  // 4. Origin header (if present) must match the host
  const origin = request.headers.origin
  if (origin !== undefined) {
    const originUrl = new URL(origin)
    if (originUrl.host !== hostUrl.host) return false
  }
  
  return true
}
```

**Why four checks?** Defense in depth:
- Remote address: Blocks non-localhost TCP connections
- Host header: Blocks DNS-rebinding attacks (attacker registers evil.com pointing to 127.0.0.1)
- sec-fetch-site: Blocks cross-origin fetch from browsers
- Origin: Blocks cross-origin requests from browsers (when Origin is sent)

**Rationale**: This is the same fence used by dsh-ssh and @deepseek-ai/dsh-client-connection. It's a proven pattern for protecting sensitive APIs in local-first tools.

**What this prevents**:
- A malicious webpage cannot call /api/dsh-wigolo/token to steal your token
- A LAN user cannot change your config remotely
- DNS-rebinding attacks cannot bypass the loopback check

## Token Handling

### Storage

The token is stored in a separate file (~/.dsh/wigolo-token) with 0600 permissions:

```bash
$ ls -la ~/.dsh/wigolo-token
-rw------- 1 user user 65 Aug 18 03:00 /home/user/.dsh/wigolo-token
```

**Why separate from config?**:
- Config files are often 0644 (world-readable)
- Config files are more likely to be committed to version control
- Isolating secrets makes auditing easier

### Resolution Order

1. `WIGOLO_TOKEN` environment variable (highest priority, for testing)
2. Token file (default: ~/.dsh/wigolo-token, or custom path via `connection.tokenFile`)

### API Responses

The token is **never** returned in API responses. The panel receives:

```json
{
  "hasToken": true,
  "connection": { ... },
  "takeover": false,
  ...
}
```

Only `hasToken: boolean` is exposed, not the token itself.

### Panel Write

The panel can write the token directly (no terminal required):

```
POST /api/dsh-wigolo/token
Content-Type: application/json

{ "token": "..." }
```

The route:
1. Validates the token is a non-empty string
2. Writes it to the token file with 0600 permissions
3. Returns `{ ok: true, hasToken: true }` (never echoes the token)

### MCP Client

The MCP client reads the token once at startup and passes it in the Authorization header:

```typescript
const headers = {
  'Authorization': `Bearer ${token}`,
  'Host': hostHeader,  // DNS-rebinding bypass
  ...
}
```

The token is held in memory for the lifetime of the client. It is not logged.

## Fail-Loud Validation

Unknown config keys trigger warnings instead of being silently dropped:

```
[dsh-wigolo] unknown config key "hostheader" in ~/.dsh/wigolo.json — did you mean "hostHeader"? (ignored)
```

**Why fail-loud?**: A typo in a config key (e.g., `hostheader` instead of `hostHeader`) would silently fall back to the default, making the bug invisible. Fail-loud catches these immediately.

**Implementation**: The ConfigStore's `normalize()` function checks each key against the known set and logs warnings with "did you mean?" hints (edit-distance matching).

## MCP Session Security

The MCP client uses streamable-http with session management:

1. **Session establishment**: `initialize` request captures the `Mcp-Session-Id` from the response header
2. **Session reuse**: Subsequent requests include the session ID
3. **Stale-session recovery**: If the daemon restarts (invalidating the session), the client detects the error, re-initializes, and retries once

**Why retry once?**: Daemon restarts are rare but can happen during development. A single retry avoids permanent failure without masking persistent errors.

## Host Header Bypass

wigolo's daemon has DNS-rebinding protection that allowlists certain Host header values:
- localhost
- 127.0.0.1
- [::1]
- The daemon's bind host (e.g., 0.0.0.0)

For remote daemons (e.g., 192.168.2.100), the client sends `Host: 0.0.0.0` to pass the allowlist. This is safe because:
- The daemon still enforces bearer token auth
- The Host header trick is documented in wigolo's own code
- The `hostHeader` config field allows users to override or disable this behavior

**Configuration**:
- `"auto"` (default): Send no custom header for local daemons, send `0.0.0.0` for remote
- `"none"`: Never send a custom header
- `"<literal>"`: Send a specific value

## Threat Model

### What we defend against

1. **LAN exposure**: Loopback fence prevents remote config changes
2. **Secret leakage**: Token isolation + never-return-in-API
3. **Config corruption**: Fail-loud validation
4. **DNS-rebinding**: Loopback fence + Host header checks
5. **Cross-origin attacks**: sec-fetch-site + Origin checks

### What we don't defend against

1. **Local attacker**: A user with shell access can read the token file (0600, but they own it)
2. **Daemon compromise**: If the wigolo daemon is compromised, the token is exposed
3. **Memory dumps**: The token is held in memory; a core dump could expose it

These are acceptable trade-offs for a local-first tool.

## Audit Checklist

When auditing dsh-wigolo's security:

- [ ] All API routes use `isLoopbackRequest()` guard
- [ ] Token is never logged (grep for `token` in log statements)
- [ ] Token is never returned in API responses (check `summarize()`)
- [ ] Token file is written with 0600 permissions
- [ ] Config validation fails loud on unknown keys
- [ ] MCP client does not log the Authorization header
- [ ] Panel token write uses password input (type="password")