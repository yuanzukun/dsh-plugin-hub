# 系统架构

## 概述

dsh-wigolo 将 [wigolo](https://github.com/KnockOutEZ/wigolo) 元搜索守护进程作为一等公民集成到 DSH 中。插件分为两部分：

- **Host 端**（Node.js）：MCP 客户端、配置存储、web seam providers、agent 工具、API 路由
- **Client 端**（React）：配置用的侧边栏面板

## 设计原则

### Agent 优先

插件的核心价值是七个 agent 工具。写操作（搜索/爬取/缓存清除/监控创建删除）仍归 agent。只读浏览（缓存快照库与监控状态）由默认关闭的「Wigolo 缓存」tab（可选启用）承载（见 docs/CACHE-TAB.md）。

**理由**：用户主要通过 agent 提示与 wigolo 交互（"搜索 X"、"爬取这个站点"、"监控这个页面"）。为这些操作构建丰富的 GUI 会重复 agent 已经做得很好的工作。面板的职责是一次性设置（token、host、接管开关），而非日常使用。

### 配置分层

配置存在于三个地方，各有明确用途：

1. **官方 Settings UI**（~/.dsh/settings.json）：enabled、announceToAgent、guidance — 改变插件行为的高层开关，无需重启
2. **配置文件**（~/.dsh/wigolo.json）：连接详情、工具暴露、默认值 — 需要重启才能应用的结构化配置
3. **Token 文件**（~/.dsh/wigolo-token）：bearer token，0600 权限 — 密钥，永远不在配置 JSON 中

**理由**：将可热更新的设置与结构化配置分离，避免了"我改了设置但没生效"的困惑。Token 单独存放是因为配置文件中的密钥存在安全风险（意外提交、全局可读权限）。

### Fail-Loud 而非 Fail-Silent

未知配置键触发警告并附带"你是不是想说……"提示（编辑距离匹配），而非被静默丢弃。

**理由**：hostHeader 中的拼写错误（如 hostheader）会静默回退到 auto，使错误不可见。Fail-loud 立即捕获这些问题。

## 组件关系

Host 端负责：
- ConfigStore：原子写入、fail-loud 校验、旧版迁移
- WigoloMcpClient：懒会话建立、过期会话恢复、hostHeader 解析
- Web Providers：search/fetch 接管（由 takeover 布尔开关门控）
- Agent Tools：7 个参数裁剪后的工具
- API Routes：回环栅栏保护的面板 API
- Settings Section：可热更新的 enabled/announceToAgent/guidance

Client 端负责：
- Sidebar Entry：DOM 注入 + MutationObserver（与 ssh/taskboard 共存）
- Panel：3 个 tab（Connection / Takeover & Tools / About）
- Cross-Panel Mutex：dsh-panel-activate 事件协调

## 构建系统

插件使用 tsdown 的双入口配置：

- Host 入口：src/index.ts → lib/index.mjs（ESM bundle，依赖外部化）
- Client 入口：src/client/index.ts → lib/client.js（CJS 闭包工厂 + ModuleLoader 包装）

Client bundle 通过 outputOptions 的 banner/intro/footer 生成为 `window.__ModuleLoader__.load({ id, factory: (require) => ... })`，以匹配 DSH web shell 的模块加载协议——平台外部依赖（react、react-dom、react/jsx-runtime）通过注入的 `require` 解析，与 dsh-ssh / dsh-context / dsh-better-sidebar 完全一致。

TypeScript 声明由 tsc -p tsconfig.build.json 生成（与 tsdown 分离以避免打包问题）。

## 安全模型

详见 [SECURITY.md](./SECURITY.md)。

要点：
- API 路由仅限回环（远程地址 + Host + sec-fetch-site + origin 检查）
- Token 存储在独立的 0600 文件中，永远不在配置 JSON 中
- 面板永不返回 token（仅 hasToken: boolean）
- Fail-loud 校验防止静默配置错误

## 配置

详见 [CONFIGURATION.md](./CONFIGURATION.md)。

三层配置：
1. Settings UI（热更新）：enabled、announceToAgent、guidance
2. 配置文件（需重启）：connection、tools、takeover
3. Token 文件（密钥）：bearer token

## Provider 接管

详见 [PROVIDERS.md](./PROVIDERS.md)。

插件可以通过 wigolo 路由 web_search / web_fetch（takeover 布尔开关：`true` = 两者都由 wigolo 驱动，`false` = 官方提供商，默认）。接管开关向 ~/.dsh/cordis.patch.yml 写入管理块（dsh-skin 模式），需要重启。

## Agent 工具

详见 [TOOLS.md](./TOOLS.md)。

七个工具，参数裁剪后的表面（每个 6-10 个参数，从 wigolo 的 20+ 个减少）。参数由官方 defineTool DSL 验证。

## 客户端架构

详见 [CLIENT.md](./CLIENT.md)。

- 侧边栏入口使用 DOM 注入 + MutationObserver（与 ssh/taskboard 共存）
- 面板使用跨面板互斥（dsh-panel-activate 事件）
- Token 可以直接从面板写入（无需终端）
