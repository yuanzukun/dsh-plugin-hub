# dsh-wigolo 设计文档

本文档目录包含 dsh-wigolo 插件的详细设计说明。

## 文档列表

- **[ARCHITECTURE.md](./ARCHITECTURE.md)** - 系统架构
  - 设计原则（Agent 优先、配置分层、Fail-Loud）
  - 组件关系图
  - 构建系统
  - 安全模型概览

- **[CONFIGURATION.md](./CONFIGURATION.md)** - 配置系统
  - 三层配置架构（Settings UI / 配置文件 / Token 文件）
  - 配置验证和迁移
  - 工具默认值和超时预算

- **[PROVIDERS.md](./PROVIDERS.md)** - Provider 接管机制
  - 接管布尔开关（true = 两者都接管，false = 官方提供商）
  - AMBIGUOUS 陷阱及解决方案
  - Cordis 管理块
  - 热重载限制

- **[TOOLS.md](./TOOLS.md)** - Agent 工具
  - 七个工具详解（search / crawl / extract / research / find_similar / cache / watch）
  - 参数裁剪哲学
  - 输出渲染

- **[SECURITY.md](./SECURITY.md)** - 安全模型
  - 仅限回环的 API 路由
  - Token 处理（存储、解析顺序、面板写入）
  - Fail-Loud 校验
  - MCP 会话安全
  - Host 头绕过
  - 威胁模型

- **[CLIENT.md](./CLIENT.md)** - 客户端架构
  - 侧边栏入口（DOM 注入、家族块排序、自我修复）
  - 面板（结构、挂载点、Token 写入）
  - 跨面板互斥
  - 缓存 Tab（conversation.view）
- **[CACHE-TAB.md](./CACHE-TAB.md)** - 可选「Wigolo 缓存」只读 tab（设计、路由、模块门禁）
  - 控制器和 API 客户端
  - 构建输出
  - CSS 模块
  - 失败策略
  - 未来 better-sidebar 集成

## 核心设计决策

### Agent 优先（已修订）

插件的核心价值是七个 agent 工具。写操作（搜索/爬取/缓存清除/监控创建与删除）仍归 agent。只读浏览——缓存快照库与监控状态——由默认关闭的「Wigolo 缓存」tab（可选启用）承载（见 docs/CACHE-TAB.md）。

### 配置分层

三层配置，各自有明确的重启语义：
1. **Settings UI**（热更新）：enabled、announceToAgent、guidance
2. **配置文件**（需重启）：connection、tools、takeover（布尔值）
3. **Token 文件**（密钥）：bearer token

### Fail-Loud 而非 Fail-Silent

未知配置键触发警告并附带 "did you mean?" 提示，而非被静默丢弃。

### 无外部 UI 依赖

插件不依赖 better-sidebar 或其他社区插件。所有 UI 自包含（侧边栏入口 + 面板）。

## 版本历史

完整版本历史见 [CHANGELOG.md](../../CHANGELOG.md)。

### v1.1.0（当前）

- Agent 优先定位（面板仅用于配置）
- 面板直接写入 token（无需终端）
- 官方 settings 集成（热更新）
- Fail-loud 配置校验
- 面板精简为 3 个 tab

### v1.0.0

- 初始发布
- 七个 agent 工具
- Provider 接管（both/search/none）
- 侧边栏面板（4 个 tab）
- MCP 客户端（hostHeader 解析）