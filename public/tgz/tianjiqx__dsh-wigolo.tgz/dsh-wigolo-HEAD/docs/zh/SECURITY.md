# 安全模型

## 概述

dsh-wigolo 处理敏感数据（bearer tokens、守护进程连接），必须防御：

1. **LAN 暴露**：在 LAN 上提供服务的 DSH web GUI 不应泄露 tokens 或允许远程配置更改
2. **密钥泄露**：Tokens 不应出现在日志、API 响应或配置文件中
3. **配置损坏**：格式错误的配置应该响亮地失败，而不是静默地

## 仅限回环的 API 路由

所有面板 API 路由（/api/dsh-wigolo/*）都受仅限回环的信任栅栏保护：

```typescript
function isLoopbackRequest(request: IncomingMessage): boolean {
  // 1. 远程地址必须是回环
  const address = request.socket.remoteAddress
  if (address !== '127.0.0.1' && address !== '::1' && address !== '::ffff:127.0.0.1') return false
  
  // 2. Host 头必须是回环
  const host = request.headers.host
  const hostUrl = new URL('http://' + host)
  if (hostUrl.hostname !== '127.0.0.1' && hostUrl.hostname !== 'localhost' && hostUrl.hostname !== '[::1]') return false
  
  // 3. sec-fetch-site 不能是 cross-site
  if (request.headers['sec-fetch-site'] === 'cross-site') return false
  
  // 4. Origin 头（如果存在）必须与 host 匹配
  const origin = request.headers.origin
  if (origin !== undefined) {
    const originUrl = new URL(origin)
    if (originUrl.host !== hostUrl.host) return false
  }
  
  return true
}
```

**为什么四个检查？** 纵深防御：
- 远程地址：阻止非本地主机 TCP 连接
- Host 头：阻止 DNS 重绑定攻击（攻击者注册 evil.com 指向 127.0.0.1）
- sec-fetch-site：阻止来自浏览器的跨源 fetch
- Origin：阻止来自浏览器的跨源请求（当发送 Origin 时）

**理由**：这是 dsh-ssh 和 @deepseek-ai/dsh-client-connection 使用的相同栅栏。这是在本地优先工具中保护敏感 API 的经过验证的模式。

**这防止了什么**：
- 恶意网页不能调用 /api/dsh-wigolo/token 来窃取你的 token
- LAN 用户不能远程更改你的配置
- DNS 重绑定攻击不能绕过回环检查

## Token 处理

### 存储

Token 存储在独立文件（~/.dsh/wigolo-token）中，权限为 0600：

```bash
$ ls -la ~/.dsh/wigolo-token
-rw------- 1 user user 65 Aug 18 03:00 /home/user/.dsh/wigolo-token
```

**为什么与配置分开？**：
- 配置文件通常是 0644（全局可读）
- 配置文件更可能被提交到版本控制
- 隔离密钥使审计更容易

### 解析顺序

1. `WIGOLO_TOKEN` 环境变量（最高优先级，用于测试）
2. Token 文件（默认：~/.dsh/wigolo-token，或通过 `connection.tokenFile` 自定义路径）

### API 响应

Token **永远不**在 API 响应中返回。面板接收：

```json
{
  "hasToken": true,
  "connection": { ... },
  "takeover": false,
  ...
}
```

仅暴露 `hasToken: boolean`，而非 token 本身。

### 面板写入

面板可以直接写入 token（无需终端）：

```
POST /api/dsh-wigolo/token
Content-Type: application/json

{ "token": "..." }
```

路由：
1. 验证 token 是非空字符串
2. 以 0600 权限写入 token 文件
3. 返回 `{ ok: true, hasToken: true }`（永远不回显 token）

### MCP 客户端

MCP 客户端在启动时读取一次 token，并在 Authorization 头中传递它：

```typescript
const headers = {
  'Authorization': `Bearer ${token}`,
  'Host': hostHeader,  // DNS 重绑定绕过
  ...
}
```

Token 在客户端的生命周期内保存在内存中。它不会被记录。

## Fail-Loud 校验

未知配置键触发警告而非被静默丢弃：

```
[dsh-wigolo] unknown config key "hostheader" in ~/.dsh/wigolo.json — did you mean "hostHeader"? (ignored)
```

**为什么 fail-loud？**：配置键中的拼写错误（如 `hostheader` 而非 `hostHeader`）会静默回退到默认值，使错误不可见。Fail-loud 立即捕获这些。

**实现**：ConfigStore 的 `normalize()` 函数检查每个键与已知集合，并记录带有"你是不是想说……"提示的警告（编辑距离匹配）。

## MCP 会话安全

MCP 客户端使用带有会话管理的 streamable-http：

1. **会话建立**：`initialize` 请求从响应头捕获 `Mcp-Session-Id`
2. **会话重用**：后续请求包含会话 ID
3. **过期会话恢复**：如果守护进程重启（使会话无效），客户端检测错误，重新初始化，并重试一次

**为什么重试一次？**：守护进程重启很少见但可能在开发期间发生。单次重试避免永久失败，而不掩盖持久错误。

## Host 头绕过

wigolo 的守护进程有 DNS 重绑定保护，允许某些 Host 头值：
- localhost
- 127.0.0.1
- [::1]
- 守护进程的绑定主机（如 0.0.0.0）

对于远程守护进程（如 192.168.2.100），客户端发送 `Host: 0.0.0.0` 以通过允许列表。这是安全的，因为：
- 守护进程仍然强制 bearer token 认证
- Host 头技巧在 wigolo 自己的代码中有文档
- `hostHeader` 配置字段允许用户覆盖或禁用此行为

**配置**：
- `"auto"`（默认）：对本地守护进程不发送自定义头，对远程发送 `0.0.0.0`
- `"none"`：永不发送自定义头
- `"<字面值>"`：发送特定值

## 威胁模型

### 我们防御什么

1. **LAN 暴露**：回环栅栏防止远程配置更改
2. **密钥泄露**：Token 隔离 + 永不返回于 API
3. **配置损坏**：Fail-loud 校验
4. **DNS 重绑定**：回环栅栏 + Host 头检查
5. **跨源攻击**：sec-fetch-site + Origin 检查

### 我们不防御什么

1. **本地攻击者**：具有 shell 访问权限的用户可以读取 token 文件（0600，但他们拥有它）
2. **守护进程妥协**：如果 wigolo 守护进程被妥协，token 被暴露
3. **内存转储**：Token 保存在内存中；核心转储可能暴露它

对于本地优先工具，这些是可接受的权衡。

## 审计清单

审计 dsh-wigolo 的安全性时：

- [ ] 所有 API 路由使用 `isLoopbackRequest()` 守卫
- [ ] Token 永不被记录（grep 日志语句中的 `token`）
- [ ] Token 永不返回于 API 响应（检查 `summarize()`）
- [ ] Token 文件以 0600 权限写入
- [ ] 配置校验对未知键响亮失败
- [ ] MCP 客户端不记录 Authorization 头
- [ ] 面板 token 写入使用密码输入（type="password"）