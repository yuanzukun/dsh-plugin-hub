# Agent 工具

## 概述

dsh-wigolo 暴露七个 agent 工具，每个映射到 wigolo 守护进程的一个能力。关键设计决策是**参数裁剪**：wigolo 的 MCP 工具每个有 15-25 个参数，但我们每个工具只暴露 6-10 个。

## 为什么裁剪参数？

模型的工具选择准确性随着大型参数 schema 而降低。一个有 20 个参数的工具比一个有 8 个参数的工具更难被模型正确使用。我们裁剪到覆盖 95% 用例的高频子集。

**示例**：wigolo 的 `search` 工具有 25 个参数。我们暴露 11 个：
- query（必需）
- max_results、category、time_range、from_date、to_date
- include_domains、exclude_domains、search_depth
- force_refresh、exact_match

剩余的 14 个（render_js、use_auth、max_fetches、include_content、content_max_chars、max_content_chars、max_total_chars、format、max_highlights、include_favicon、include_images、max_tokens_out、include_full_markdown、citation_format、mode、agent_context）是高级选项，模型很少需要设置。

## 工具列表

### wigolo_search

**能力**：高级网页搜索，18+ 引擎，RRF 融合，本地缓存

**参数**：
- `query`（必需）：搜索查询，或 "a | b" 用于并行多变体搜索
- `max_results`：最大结果数（默认 10，最大 20）
- `category`：general | news | code | docs | papers | images
- `time_range`：day | week | month | year
- `from_date` / `to_date`：ISO 日期过滤器
- `include_domains` / `exclude_domains`：域名过滤器
- `search_depth`：ultra-fast | fast | balanced | deep
- `force_refresh`：绕过缓存
- `exact_match`：引号短语搜索

**输出**：Sources 数组，包含 url/title/snippet/score/publishedAt + engines_used + total_time_ms

**超时**：60s（可配置）

### wigolo_crawl

**能力**：从种子 URL 爬取站点，跟随链接

**参数**：
- `url`（必需）：种子 URL
- `max_depth`：最大链接深度（默认 2，最大 5）
- `max_pages`：最大爬取页数（默认 50，最大 500）
- `include_patterns` / `exclude_patterns`：URL 模式过滤器
- `strategy`：bfs | dfs

**输出**：原始爬取结果（pages 数组）

**超时**：300s（可配置）

**用例**："爬取 React 文档站点，以便我以后可以询问相关问题"

### wigolo_extract

**能力**：从 URL 提取结构化数据

**参数**：
- `url`（必需）：目标 URL
- `css_selector`：要提取的 CSS 选择器
- `multiple`：返回所有匹配（true）或第一个（false）
- `schema`：字段提取 schema（JSON 对象）
- `max_tokens_out`：限制输出大小

**输出**：提取的数据（结构取决于选择器/schema）

**超时**：60s（可配置）

**用例**："从这个产品页面提取所有价格"

### wigolo_research

**能力**：多步骤研究，子查询分解

**参数**：
- `question`（必需）：研究问题
- `depth`：quick | standard | deep
- `max_sources`：最大咨询源数（默认 8，最大 30）
- `include_domains` / `exclude_domains`：域名过滤器

**输出**：报告（带引用的综合）+ 原始有效载荷

**超时**：600s（可配置）

**用例**："研究 Rust 和 Go 用于后端服务的权衡"

### wigolo_find_similar

**能力**：从 URL 或概念查找相关内容

**参数**：
- `url`：种子 URL
- `concept`：概念文本（URL 的替代）
- `max_results`：最大结果数（默认 10，最大 20）
- `include_web`：搜索超出本地缓存

**输出**：Sources 数组

**超时**：120s（可配置）

**默认**：禁用（很少需要；在配置中启用）

**用例**："查找与这篇类似的文章"

### wigolo_cache

**能力**：搜索本地缓存而不触网

**参数**：
- `query`：按关键词搜索
- `url_pattern`：对完整 URL 做 glob 全匹配：完整 URL 精确命中单条；`*关键词*` 为子串过滤；`*后缀` 为后缀匹配。不带 `*` 的裸子串不会命中任何条目
- `since`：仅比这更新的条目
- `stats`：返回缓存统计
- `clear`：清空缓存（破坏性）
- `limit`：最大返回条目数（默认 10，最大 50）

**输出**：缓存条目或统计

**超时**：30s（可配置）

**用例**："检查我们是否有关于 React hooks 的缓存内容" 或 "清空缓存"

**注意**：wigolo_cache 工具检索守护进程的快照库；默认关闭的「Wigolo 缓存」GUI tab（conversation.view，可选启用）也能只读浏览该库——见 [CACHE-TAB.md](../CACHE-TAB.md)。

### wigolo_watch

**能力**：监控 URL 的变化

**参数**：
- `action`（必需）：create | list | check | pause | resume | delete（add/remove 作为别名被接受，自动归一为 create/delete）
- `url`：要监控的 URL（create/check）
- `urls`：多个 URL（create）
- `interval_seconds`：重新检查间隔（最小 60，最大 86400）
- `selector`：仅监控此 CSS 选择器子树
- `job_id`：任务 id（pause/resume/delete/单独 check）

**输出**：任务列表或确认

**超时**：120s（可配置）

**用例**："每天监控这个定价页面，如果有变化就告诉我"

**注意**：任务在守护进程重启后持久存在。与定时 agent 任务配对以实现通知。

## 参数裁剪哲学

对于每个工具，我们问："模型在 95% 的情况下需要设置哪些参数？"

- **始终暴露**：必需参数 + 5-8 个最常见的可选参数
- **永不暴露**：内部调优旋钮（max_tokens_out、citation_format、render_js）
- **有时暴露**：高级用户可能想要的高级选项（force_refresh、exact_match）

目标是使工具易于正确使用，而非最大化灵活性。需要完整参数表面的用户可以直接通过 MCP 调用 wigolo。

## 工具注册

工具使用 @deepseek-ai/dsh-tools 的官方 `defineTool` DSL 注册：

```typescript
export function wigoloSearchTool(client, config) {
  return defineTool({
    name: 'wigolo_search',
    description: '...',
    parameters: {
      query: { type: 'string', required: true, description: '...' },
      max_results: { type: 'number', description: '...' },
      // ...
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value) => text(renderSources(value)),
    },
    timeoutMs: effectiveTimeout(config, 60_000),
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      // ...
    },
  })
}
```

`defineTool` 的好处：
- 自动参数验证
- 类型安全的 execute 函数
- 官方输出 schema/render 契约
- 并发安全声明

## 工具暴露标志

每个工具可以在配置中禁用：

```json
"tools": {
  "wigolo_find_similar": { "enabled": false }
}
```

禁用的工具不注册，因此不会出现在 agent 的工具列表中。

**默认暴露**：
- 启用：search、crawl、extract、research、cache、watch
- 禁用：find_similar（很少需要）

## 超时预算

每个工具有默认超时，可逐工具配置：

| 工具 | 默认 | 理由 |
|------|---------|-----------|
| search | 60s | 大多数搜索在 <10s 内完成 |
| crawl | 300s | 爬取 500 页可能需要几分钟 |
| extract | 60s | 单页提取很快 |
| research | 600s | 多步骤研究很慢 |
| find_similar | 120s | 缓存查找 + 可选网页搜索 |
| cache | 30s | 本地缓存操作是瞬间的 |
| watch | 120s | 任务管理很快 |

用户可以在配置中覆盖这些：

```json
"wigolo_research": { "timeoutMs": 900000 }
```

## 输出渲染

具有 source 形状输出的工具（search、find_similar）使用自定义渲染器：

```typescript
render: (_args, value) => text(renderSources(value))
```

渲染器将 sources 格式化为：

```
[0.912] Title (2025-01-02)
  https://example.com
  Snippet text...
engines: google, bing, duckduckgo
time: 120ms
```

这为模型提供了结果的紧凑、可扫描视图。
