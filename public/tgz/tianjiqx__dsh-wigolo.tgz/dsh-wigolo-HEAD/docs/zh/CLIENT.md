# 客户端架构

## 概述

dsh-wigolo 的客户端部分运行在 DSH web GUI（浏览器）中。它提供：

1. **侧边栏入口**：侧边栏中可点击的行，切换面板
2. **面板**：基于 React 的配置 UI，位于中心列
3. **跨面板互斥**：与其他面板（ssh、taskboard）的协调

客户端是 agent 优先的：面板用于配置。写操作（搜索/爬取/缓存清除/监控创建删除）仍归 agent，只读浏览（缓存快照库与监控状态）由默认关闭的「Wigolo 缓存」tab（可选启用）承载（见 docs/CACHE-TAB.md）。

## 侧边栏入口

### DOM 注入

DSH 的侧边栏 shell 不暴露插件注册 slot，因此我们直接将入口行注入到 DOM 中：

```typescript
// src/client/sidebar-entry.ts
export function mountSidebarEntry(controller, css): () => void {
  const entry = document.createElement('button')
  entry.dataset.dshWigoloEntry = ''
  entry.className = css.entry
  entry.innerHTML = '<span class="' + css.entryIcon + '">' + ICON + '</span><span class="' + css.entryLabel + '">Wigolo</span>'
  entry.addEventListener('click', () => controller.toggle())
  
  // 在 "New Session" 按钮之后插入
  const root = sidebarRoot()
  const button = newSessionButton(root)
  root.insertBefore(entry, button.nextElementSibling)
  
  // 在 shell 重新渲染时自我修复
  const observer = new MutationObserver(() => {
    if (!root.contains(entry)) {
      root.insertBefore(entry, button.nextElementSibling)
    }
  })
  observer.observe(root, { childList: true, subtree: true })
  
  return () => {
    observer.disconnect()
    entry.remove()
  }
}
```

### 家族块排序

多个插件（taskboard、ssh、wigolo）注入侧边栏入口。为了防止它们在 shell 重新渲染时交换位置，我们使用"家族块"协议：

```typescript
const family = Array.from(root.children).filter(
  el => el.matches('[data-dsh-taskboard-entry], [data-dsh-ssh-entry], [data-dsh-wigolo-entry]')
)
const anchor = family.length > 0
  ? family[family.length - 1].nextElementSibling
  : base.nextElementSibling
root.insertBefore(entry, anchor)
```

**理由**：没有这个，每个插件的 MutationObserver 可能在不同时间插入，导致入口交换位置。家族块确保稳定的排序。

### 自我修复

MutationObserver 监视入口被移除（由 shell 重新渲染），并在同一帧中重新插入它（在绘制之前），因此没有可见的闪烁。

## 面板

### 结构

面板是一个 React 18 组件，有三个 tab：

1. **Connection**：Host/port/token 配置 + 测试连接
2. **Takeover & Tools**：接管布尔开关 + 工具暴露标志
3. **About**：文档链接、Host 头解释、迁移指南

### 挂载点

面板作为覆盖层挂载在中心列（对话区域）：

```typescript
// src/client/mount.tsx
export function mountPanel(controller, api): () => void {
  const container = document.createElement('div')
  container.dataset.dshWigoloView = ''
  container.className = css.view
  
  const column = conversationColumn()
  column.appendChild(container)
  
  const root = createRoot(container)
  root.render(<WigoloPanel controller={controller} api={api} />)
  
  // 根据控制器状态显示/隐藏
  const sync = () => {
    const open = controller.getSnapshot().panelOpen
    container.style.display = open ? 'block' : 'none'
  }
  controller.subscribe(sync)
  
  return () => {
    root.unmount()
    container.remove()
  }
}
```

### Token 写入

Connection tab 有一个密码输入，直接写入 token（无需终端）：

```tsx
<div className={css.field}>
  <label>Set token</label>
  <div style={{ display: 'flex', gap: 8 }}>
    <input type="password" value={token} onChange={...} />
    <button onClick={() => api.writeToken(token)}>Write</button>
  </div>
</div>
```

API 调用：

```typescript
async writeToken(token: string) {
  return readJson(await fetch('/api/dsh-wigolo/token', {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ token }),
  }))
}
```

Token 通过 HTTPS（或如果 DSH 不使用 TLS 则通过 HTTP）发送，以 0600 权限写入 ~/.dsh/wigolo-token，永不回显。

## 跨面板互斥

### 问题

多个面板（ssh、taskboard、wigolo）可以同时打开，在中心列重叠。这造成视觉混乱。

### 解决方案

面板通过自定义事件协调：

```typescript
// 打开 wigolo 面板时
window.dispatchEvent(new CustomEvent('dsh-panel-activate', { detail: 'wigolo' }))

// 当任何面板接收到事件时
window.addEventListener('dsh-panel-activate', (event) => {
  if (event.detail !== 'wigolo') {
    controller.closePanel()  // 如果另一个面板正在激活，关闭我们自己
  }
})
```

### 活动属性

面板还在 `<html>` 上设置数据属性用于 CSS 样式：

```typescript
const html = document.documentElement
if (open) {
  // 移除其他面板的活动属性
  html.removeAttribute('data-dsh-taskboard-active')
  html.removeAttribute('data-dsh-ssh-active')
  // 设置我们自己的
  html.setAttribute('data-dsh-wigolo-active', '')
} else {
  html.removeAttribute('data-dsh-wigolo-active')
}
```

**理由**：这允许 CSS 在任何面板活动时隐藏对话内容，而无需 JavaScript 协调。

## 控制器

面板状态由一个简单的控制器管理：

```typescript
export class PanelController {
  private open = false
  private listeners = new Set<() => void>()
  
  getSnapshot() {
    return { panelOpen: this.open }
  }
  
  subscribe(listener: () => void) {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }
  
  toggle() {
    this.open = !this.open
    this.listeners.forEach(l => l())
  }
  
  openPanel() {
    if (!this.open) {
      this.open = true
      this.listeners.forEach(l => l())
    }
  }
  
  closePanel() {
    if (this.open) {
      this.open = false
      this.listeners.forEach(l => l())
    }
  }
}
```

控制器遵循 React `useSyncExternalStore` 模式（getSnapshot + subscribe），因此 React 组件可以高效地读取状态。

## API 客户端

API 客户端是 fetch 的薄包装：

```typescript
export function makeApi(): WigoloApi {
  return {
    async getConfig() {
      return readJson(await fetch('/api/dsh-wigolo/config'))
    },
    async updateConnection(payload) {
      return readJson(await fetch('/api/dsh-wigolo/config', {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload),
      }))
    },
    async writeToken(token) {
      return readJson(await fetch('/api/dsh-wigolo/token', {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ token }),
      }))
    },
    async testConnection() {
      return readJson(await fetch('/api/dsh-wigolo/test', { method: 'POST' }))
    },
    // ...
  }
}
```

所有 API 调用仅限回环（由 host 强制），因此客户端不需要处理认证或 CORS。

## 构建输出

客户端由 tsdown 构建为单个闭包工厂 bundle。平台外部依赖（`react`、`react-dom/client`、`react/jsx-runtime`）保持外部，通过 shell 注入的 `require` 解析：

```
src/client/index.ts
  ↓ tsdown（CJS + outputOptions banner/intro/footer）
lib/client.js
```

ModuleLoader 包装由 `outputOptions`（banner / intro / footer）生成，产出的形态与其他 dsh 插件（dsh-ssh、dsh-context、dsh-better-sidebar）完全一致：

```javascript
window.__ModuleLoader__.load({
  id: "dsh-wigolo",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    let react = require("react");
    let react_dom_client = require("react-dom/client");
    // ... 插件代码 ...
    exports.apply = apply;
    exports.inject = inject;
    return module.exports;
  }
});
```

这匹配 DSH web shell 的模块加载协议（与 dsh-ssh 相同）。

## CSS 模块

面板使用 CSS 模块进行作用域样式：

```tsx
import css from './panel.module.css'

<div className={css.panel}>
  <div className={css.panelHeader}>...</div>
</div>
```

tsdown 插件在 bundle 内用 lightningcss 编译每个 `.module.css`：哈希后的类名映射成为默认导出，CSS 文本则在 factory 执行时自动注入 `<style data-plugin="dsh-wigolo">` 标签（loader 在卸载时移除插件所属标签）。不再产生独立的 style.css 产物。

## 失败策略

DOM 挂载问题被记录，永不抛出：

```typescript
export function apply(ctx: ClientContext): void {
  try {
    disposers.push(mountSidebarEntry(controller))
    disposers.push(mountPanel(controller, api))
  } catch (error) {
    console.warn('[dsh-wigolo] mount failed:', error)
  }
}
```

**理由**：当插件 apply 抛出时，DSH web shell 使整个启动失败。外部插件不能使 GUI 崩溃。

## 缓存 Tab（conversation.view）

只读缓存/监控浏览以默认关闭的「Wigolo 缓存」tab 寄宿在会话 tab 栏，实现为 `conversation.view` slot（`id: 'wigolo-cache'`，order 40）。仅在 `cacheTab.enabled` 开启时注册；面板开关驱动 dispose + 重注册（见 [CACHE-TAB.md](../CACHE-TAB.md)）。设计、路由与模块门禁见该文档；tab 本身通过 /api/dsh-wigolo/cache-tab/* 四个宿主路由读取。
