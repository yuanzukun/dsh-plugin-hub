# 配置系统

## 概述

dsh-wigolo 使用三层配置系统，每层服务于不同的目的：

1. **官方 Settings UI**（热更新）：高层行为开关
2. **配置文件**（需重启）：结构化配置
3. **Token 文件**（密钥）：守护进程认证的 bearer token

这种分离避免了"我改了设置但没生效"的常见困惑，通过明确重启需求来实现。

## 第一层：官方 Settings UI

**位置**：~/.dsh/settings.json（由 DSH settings 服务管理）

**字段**：
- `enabled`（布尔值，默认 true）：插件的主开关。为 false 时，路由/工具/providers 不注册。
- `announceToAgent`（布尔值，默认 true）：是否将 WIGOLO_GUIDANCE 注入 agent 系统提示。
- `guidance`（字符串，可选）：覆盖默认公告文本。用于本地化或自定义使用模式。

**热更新**：更改立即生效，无需重启 DSH。插件使用 `installSettingsSection`（dsh-ssh 模式）在官方 DSH settings UI 中注册设置卡片。

**实现**：
```typescript
// src/index.ts
export const Config: z<Config> = z.object({
  enabled: z.boolean().default(true),
  announceToAgent: z.boolean().default(true),
  guidance: z.string(),
})

installSettingsSection(ctx, WIGOLO_SETTINGS_NAMESPACE, Config, config ?? {}, {
  setSource: (source) => { current = source; sync() },
  onChange: sync,
})
```

`sync()` 函数在设置更改时拆除并重新注册工具/提示部分。

## 第二层：配置文件

**位置**：~/.dsh/wigolo.json

**Schema**（v2）：
```jsonc
{
  "version": 2,
  "connection": {
    "host": "127.0.0.1",        // 守护进程地址
    "port": 3333,
    "hostHeader": "auto",       // auto | none | "<字面值>"
    "tokenFile": ""             // "" = ~/.dsh/wigolo-token
  },
  "takeover": false,           // true = wigolo 驱动 web_search + web_fetch；false = 官方提供商
  "tools": {
    "wigolo_search":  { "enabled": true,  "defaults": { "max_results": 10 } },
    "wigolo_crawl":   { "enabled": true,  "defaults": { "max_pages": 50 }, "timeoutMs": 300000 },
    "wigolo_extract": { "enabled": true },
    "wigolo_research":{ "enabled": true,  "timeoutMs": 600000 },
    "wigolo_find_similar": { "enabled": false },
    "wigolo_cache":   { "enabled": true },
    "wigolo_watch":   { "enabled": true }
  },
  "cacheTab": { "enabled": false },   // 「Wigolo 缓存」只读 GUI tab（默认关闭；热生效）
  "announceToAgent": true
}
```

**生效语义**：连接编辑与 cacheTab 开关立即生效（live MCP client 热配置 + tab slot 重注册，无需重启）。工具**暴露**变更与**接管**需要重启 DSH；仅这两类面板显示重启提示。

**原子写入**：ConfigStore 使用 tmp + rename 确保文件永远不会处于半写入状态。

**Fail-loud 校验**：未知键触发警告并附带"你是不是想说……"提示：
```
[dsh-wigolo] unknown config key "hostheader" in ~/.dsh/wigolo.json — did you mean "hostHeader"? (ignored)
```

提示使用编辑距离匹配（Levenshtein 距离 ≤ max(2, key.length/3)）。

## 第三层：Token 文件

**位置**：~/.dsh/wigolo-token（或通过 `connection.tokenFile` 自定义路径）

**权限**：0600（仅所有者可读写）

**格式**：第一行包含 bearer token。后续行被忽略。

**为什么单独存放？**：配置文件中的密钥存在安全风险：
- 意外提交到版本控制
- 全局可读权限（配置文件通常是 0644）
- 更难审计（"token 在哪里？"）

通过隔离 token，我们可以：
- 明确强制 0600 权限
- 永远不在 API 响应中返回它（仅 `hasToken: boolean`）
- 直接从面板写入（无需终端）

**Token 解析顺序**：
1. `WIGOLO_TOKEN` 环境变量（最高优先级，用于测试）
2. Token 文件（默认：~/.dsh/wigolo-token）

**面板写入**：Connection tab 有一个密码输入，直接写入 token：
```
POST /api/dsh-wigolo/token
{ "token": "..." }
→ 以 0600 权限写入 ~/.dsh/wigolo-token
→ 返回 { ok: true, hasToken: true }
```

Token 永远不会被回显。

## 工具默认值

每个工具可以有 `defaults`（合并在模型参数之下）和 `timeoutMs`（覆盖）：

```json
"wigolo_search": {
  "enabled": true,
  "defaults": { "max_results": 10, "search_depth": "balanced" },
  "timeoutMs": 60000
}
```

**合并顺序**：模型参数 > 配置默认值 > 内置默认值

**理由**：用户可以设置他们的首选默认值（如始终使用 `search_depth: "deep"`），而无需在每个提示中重复。

## 缓存 Tab

`cacheTab.enabled`（默认 `false`）注册「Wigolo 缓存」只读 GUI tab（一个 `conversation.view` slot），浏览 daemon 的缓存快照库与监控任务。面板内切换立即生效（slot dispose/重注册，无需重启）。关闭时 tab 不存在且其 API 路由返回 403。设计见 [CACHE-TAB.md](../CACHE-TAB.md)。

缓存 tab 通过四个 loopback 围栏宿主路由读取：`/api/dsh-wigolo/cache-tab/list`、`/cache-tab/stats`、`/cache-tab/entry`、`/cache-tab/watch`（GET 列表 / POST check|pause|resume）。列表响应剥离 markdown；entry 按需携带单条 markdown。

## 接管

`takeover` 字段是一个布尔值，控制 wigolo 是否替换官方 web_search/web_fetch providers：

- `true`：wigolo 驱动 web_search 和 web_fetch
- `false`：wigolo 不注册任何 providers（默认）

**实现**：当 `takeover` 为 `true` 时，插件向 ~/.dsh/cordis.patch.yml 写入管理块（见 [PROVIDERS.md](./PROVIDERS.md)）。

**需要重启**：web seam 的 provider 路由在启动时读取，因此接管更改需要重启。

## 配置流程

```
用户编辑 settings UI
  ↓
installSettingsSection 触发 onChange
  ↓
sync() 重新注册工具/提示（热更新）

用户编辑面板连接（或 cacheTab 开关）
  ↓
POST /api/dsh-wigolo/config
  ↓
ConfigStore.update() 写入 ~/.dsh/wigolo.json（原子）
  ↓
live MCP client 热配置 / cache tab 重注册 → 立即生效（无需重启）

用户编辑面板工具暴露
  ↓
POST /api/dsh-wigolo/tools
  ↓
ConfigStore.update() 写入 ~/.dsh/wigolo.json（原子）
  ↓
面板显示"重新加载 DSH 以应用工具暴露变更"提示

用户在面板中写入 token
  ↓
POST /api/dsh-wigolo/token
  ↓
ConfigStore.writeToken() 写入 ~/.dsh/wigolo-token（0600）
  ↓
live client 热配置 → agent 工具立即使用（无需重启）
```