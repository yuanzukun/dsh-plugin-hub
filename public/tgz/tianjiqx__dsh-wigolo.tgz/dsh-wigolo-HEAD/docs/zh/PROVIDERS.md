# Provider 接管

## 概述

dsh-wigolo 可以通过 wigolo 守护进程路由 DSH 官方的 `web_search` 和 `web_fetch`。这称为"接管"，由配置文件中的 `takeover` 字段控制。

## 为什么需要接管？

DSH 的 web seam 设计为 provider 无关的。默认 provider 是 `deepseek-official`（需要 `DEEPSEEK_API_KEY`）。通过将 wigolo 注册为 provider，用户可以：

- 使用 wigolo 的 18+ 搜索引擎与 RRF 融合
- 受益于 wigolo 的本地缓存（重复查询瞬间完成）
- 通过 wigolo 的 markdown 提取路由 web_fetch

## AMBIGUOUS 陷阱

DSH 的 web seam 有严格的 provider 选择规则：

1. 如果显式配置了 provider（`searchProvider: wigolo`），使用它
2. 如果没有配置 provider 且恰好注册了一个可用的，使用它
3. 如果没有配置 provider 且注册了多个，抛出 `WEB_PROVIDER_AMBIGUOUS`

**陷阱**：如果用户注册了 `deepseek-official`（默认）并且 wigolo 也注册了，并且没有显式路由，web_search 会以 AMBIGUOUS 失败。

**解决方案**：takeover 开启（`true`）时自动向 ~/.dsh/cordis.patch.yml 写入显式路由；关闭（`false`）时不注册任何 providers，完全避免冲突。

## 接管开关

`takeover` 字段是一个简单的布尔值：

| 值 | web_search | web_fetch | cordis 补丁 | 重启 |
|------|-----------|-----------|--------------|---------|
| `true` | wigolo | wigolo | 写入管理块 | 需要 |
| `false` | 官方 | 官方 | 移除管理块 | 需要 |

## Cordis 管理块

当 `takeover` 为 `true` 时，插件向 ~/.dsh/cordis.patch.yml 写入自管理块（dsh-skin 模式）：

```yaml
# --- dsh-wigolo managed (auto-generated; do not edit) ---
- id: web
  name: '@deepseek-ai/dsh-web'
  config:
    searchProvider: wigolo
    fetchProvider: wigolo
# --- end dsh-wigolo managed ---
```

该块由标记界定，因此可以安全地添加/移除而不影响其他条目。

**实现**：`src/cordis-managed.ts` 提供：
- `syncManagedBlock(takeover)`：写入适当的块（`none` 时移除）
- `stripManagedBlock(content)`：移除任何现有的管理块
- `readManagedTakeover(content)`：从块中读取当前路由

## Provider 实现

```typescript
// src/providers.ts
export class WigoloSearchProvider {
  readonly id = 'wigolo'
  
  available(): boolean {
    // 廉价的本地检查 — 无网络调用（seam 契约）
    return this.tokenPresent && this.client.settings.host !== ''
  }
  
  async search(request) {
    const payload = await this.client.callToolObject('search', {
      query: request.query,
      max_results: Math.min(request.maxResults ?? 10, 20),
    })
    return toSearchResult(payload)
  }
}
```

**契约映射**：
- `results[].url` → `sources[].url`
- `results[].title` → `sources[].title`
- `results[].snippet` → `sources[].snippet`
- `results[].published_date` → `sources[].publishedAt`
- `answer` / `report` → `content`

## 注册流程

```
DSH 启动
  ↓
apply() 读取配置文件
  ↓
takeover == true?
  ↓ 是
ctx.web.registerSearchProvider(new WigoloSearchProvider(...))
  ↓
（两个 provider 一起注册）
  ↓ 是
ctx.web.registerFetchProvider(new WigoloFetchProvider(...))
  ↓
takeover == false?
  ↓ 是
不注册任何 providers
```

**重要**：Provider 注册在启动时发生一次。接管更改需要重启，因为 web seam 的路由在构造时读取。

## 为什么不能热更新接管？

web seam 的 `searchProviderId` 在构造函数中读取：

```typescript
// @deepseek-ai/dsh-web
constructor(ctx, config = {}) {
  this.searchProviderId = config.searchProvider ?? process.env.DSH_WEB_SEARCH_PROVIDER
}
```

在运行时更改它需要重新构造服务，而 cordis 生命周期不支持这一点。因此接管更改需要重启。

