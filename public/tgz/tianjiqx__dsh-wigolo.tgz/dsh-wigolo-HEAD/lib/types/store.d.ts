/**
 * Config store: one JSON file (~/.dsh/wigolo.json, version 2) written
 * atomically (tmp + rename). Pure file I/O — no cordis dependency,
 * unit-testable (same pattern as dsh-ssh's HostStore).
 */
import type { WigoloConfig, WigoloConfigSummary } from './protocol.ts';
/** Store file location: <home>/.dsh/wigolo.json. */
export declare function storePath(): string;
/** Read the raw token from the token file (empty string when absent). */
export declare function readTokenFrom(path: string): string;
/** Whether the token file exists and holds a non-empty token. */
export declare function hasTokenAt(path: string): boolean;
/**
 * The config store. All mutations go through update() which re-reads,
 * merges, validates, and persists atomically. Unknown config keys are
 * reported (fail-loud) instead of being silently dropped.
 */
export declare class ConfigStore {
    /** The JSON file path. */
    readonly path: string;
    /** Whether a legacy import was applied when the file was first created (memoized for the summary). */
    private migratedFromLegacy;
    /** Warning sink (defaults to console.warn; the host half passes the plugin logger). */
    private readonly warn;
    constructor(path?: string, warn?: (message: string) => void);
    /** Load the config, creating it (with legacy import) on first run. */
    load(): WigoloConfig;
    /** Secret-free summary for the browser surface. */
    summarize(): WigoloConfigSummary;
    /** Merge a partial config and persist atomically. Returns the new config. */
    update(mutator: (current: WigoloConfig) => WigoloConfig): WigoloConfig;
    /** Write the token to the token file (0600). Creates parent dirs. */
    writeToken(token: string): void;
    /** Read the token (env override first — same precedence the legacy plugin used). */
    readToken(): string;
    /**
     * Read the token against an explicit tokenFile value ('' = default path).
     * Env override applies the same way as readToken().
     */
    readTokenFrom(tokenFile: string): string;
    private readRaw;
    private normalize;
    private persist;
}
