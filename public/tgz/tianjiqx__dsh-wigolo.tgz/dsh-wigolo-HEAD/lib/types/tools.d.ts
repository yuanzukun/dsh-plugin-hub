/**
 * The seven wigolo_* agent tools over the official defineTool DSL, trimmed
 * from the daemon's real MCP schemas. Each builder takes the live client
 * plus its ToolConfig (enabled/defaults/timeoutMs) from the store.
 */
import type { WigoloMcpClient } from './mcp-client.ts';
import type { ToolConfig } from './protocol.ts';
export declare function wigoloSearchTool(client: WigoloMcpClient, config: ToolConfig): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function wigoloCrawlTool(client: WigoloMcpClient, config: ToolConfig): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function wigoloExtractTool(client: WigoloMcpClient, config: ToolConfig): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function wigoloResearchTool(client: WigoloMcpClient, config: ToolConfig): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function wigoloFindSimilarTool(client: WigoloMcpClient, config: ToolConfig): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function wigoloCacheTool(client: WigoloMcpClient, config: ToolConfig, timezone?: string): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function wigoloWatchTool(client: WigoloMcpClient, config: ToolConfig): import("@deepseek-ai/dsh-tools").ToolDefinition;
/** All seven tool builders, keyed by the store's tool ids. */
export declare function buildAllTools(client: WigoloMcpClient, configs: Record<string, ToolConfig>, timezone?: string): import("@deepseek-ai/dsh-tools").ToolDefinition[];
