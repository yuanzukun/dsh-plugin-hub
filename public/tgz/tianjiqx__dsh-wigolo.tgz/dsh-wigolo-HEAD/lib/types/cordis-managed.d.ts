/**
 * Cordis managed-block management: the takeover switch writes/removes a
 * self-managed block in ~/.dsh/cordis.patch.yml (dsh-skin precedent) that
 * routes the web seam's searchProvider/fetchProvider to wigolo. A restart
 * of dsh is required for the routing to take effect — the panel says so.
 */
import type { TakeoverMode } from './protocol.ts';
/** The home-layer cordis patch file. */
export declare function cordisPatchPath(): string;
/** Whether a managed block currently exists in the file content. */
export declare function hasManagedBlock(content: string): boolean;
/** Remove any existing managed block from the file content (no-op when absent). */
export declare function stripManagedBlock(content: string): string;
/** Splice a fresh managed block in at the end of the file content. */
export declare function insertManagedBlock(content: string, takeover: TakeoverMode): string;
/**
 * Sync the managed block to match the takeover mode (atomic write).
 * @param takeover - the desired routing.
 * @returns whether the file changed (a dsh restart applies it).
 */
export declare function syncManagedBlock(takeover: TakeoverMode): boolean;
/** Read which routing the current managed block encodes (undefined = no block). */
export declare function readManagedTakeover(content: string): TakeoverMode | undefined;
