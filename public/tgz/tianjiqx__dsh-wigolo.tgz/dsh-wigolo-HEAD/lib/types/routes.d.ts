/**
 * The /api/dsh-wigolo route family: config CRUD (secret-free), connection
 * test, and takeover switching (which also syncs the cordis managed block).
 * Every route carries the same loopback-only trust fence as dsh-ssh's —
 * these endpoints read/write user-private config and must not be served to
 * LAN-exposed deployments.
 *
 * Cache/watch management is NOT exposed here — the agent tools (wigolo_cache,
 * wigolo_watch) cover it over MCP. WebRoute has no method field: each path is
 * one handler that branches on req.method internally (dsh-ssh precedent).
 */
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver';
import type { ConfigStore } from './store.ts';
import type { WigoloMcpClient } from './mcp-client.ts';
/** Route family dependencies. */
export interface WigoloRoutesDeps {
    /** The config store. */
    store: ConfigStore;
    /** The live MCP client — reconfigured in-place after connection edits. */
    client: WigoloMcpClient;
    /** Session creation-time lookup (host cordis ctx.sessions; undefined when the service is absent). */
    getSessionCreatedAt?: (sessionId: string) => number | undefined;
}
/** Build every /api/dsh-wigolo route (one handler per path, method-branched). */
export declare function makeRoutes(deps: WigoloRoutesDeps): WebRoute[];
