/**
 * Tool-definition helpers over the official defineTool DSL: every wigolo_*
 * tool uses ValueSchemaSpec specs (compiled, validated) instead of raw JSON
 * Schema objects. Parameters stay trimmed to the model's high-frequency set.
 */
import type { ToolConfig } from './protocol.ts';
/**
 * Parse timezone configuration into a usable format.
 * Supports:
 * - "local" → use system local timezone
 * - IANA timezone names like "Asia/Shanghai"
 * - Numeric offsets like "+8", "-5", "+5.5", "-9.5"
 */
export declare function parseTimezone(tz: string): string;
/**
 * Convert a UTC timestamp string to the specified timezone.
 * Input format: "YYYY-MM-DD HH:MM:SS" (zone-less UTC from wigolo daemon)
 * Output format: "YYYY-MM-DD HH:MM:SS" in the target timezone
 */
export declare function convertUtcToTimezone(utcTime: string, timezone: string): string;
/** Shared property builders (concise descriptions for the model). */
export declare const P: {
    query: () => {
        readonly type: "string";
        readonly description: "Search query, or multiple \"|\" separated variants for parallel search and dedup (e.g. \"rust async | tokio vs async-std\").";
    };
    url: () => {
        readonly type: "string";
        readonly description: "Target URL.";
    };
    maxResults: (def: number) => {
        readonly type: "number";
        readonly description: string;
    };
    timeRange: () => {
        readonly type: "string";
        readonly description: "Freshness filter: day | week | month | year.";
    };
    fromDate: () => {
        readonly type: "string";
        readonly description: "ISO date YYYY-MM-DD — only results published after.";
    };
    toDate: () => {
        readonly type: "string";
        readonly description: "ISO date YYYY-MM-DD — only results published before.";
    };
    includeDomains: () => {
        readonly type: "array";
        readonly items: {
            readonly type: "string";
        };
        readonly description: "Only return results from these domains.";
    };
    excludeDomains: () => {
        readonly type: "array";
        readonly items: {
            readonly type: "string";
        };
        readonly description: "Never return results from these domains.";
    };
    searchDepth: () => {
        readonly type: "string";
        readonly description: "ultra-fast (cache-only) | fast (engines only) | balanced (default) | deep (full enrichment).";
    };
    forceRefresh: () => {
        readonly type: "boolean";
        readonly description: "Bypass caches — use for news, prices, status pages.";
    };
    exactMatch: () => {
        readonly type: "boolean";
        readonly description: "Treat the query as a quoted phrase.";
    };
    category: () => {
        readonly type: "string";
        readonly description: "Result category: general | news | code | docs | papers | images.";
    };
};
/** Merge config defaults under the model's explicit args (model wins). */
export declare function mergeDefaults(defaults: Record<string, unknown> | undefined, args: Record<string, unknown>): Record<string, unknown>;
/** Copy a string arg into out when non-empty. */
export declare function takeString(args: Record<string, unknown>, from: string, to: string, out: Record<string, unknown>): void;
/** Copy a clamped number arg. */
export declare function takeNumber(args: Record<string, unknown>, from: string, to: string, out: Record<string, unknown>, min: number, max: number): void;
/** Copy a boolean arg. */
export declare function takeBoolean(args: Record<string, unknown>, from: string, to: string, out: Record<string, unknown>): void;
/** Copy a non-empty string-array arg. */
export declare function takeStringArray(args: Record<string, unknown>, from: string, to: string, out: Record<string, unknown>): void;
/** Normalize a wigolo results array into the compact source shape (scored). */
export declare function toSources(payload: Record<string, unknown>, cap: number): Array<{
    url: string;
    title?: string;
    snippet?: string;
    score?: number;
    publishedAt?: string;
}>;
/**
 * Annotate wigolo_extract responses: make selector misses explicit instead of
 * silently returning page metadata, and hint at cached crawl snapshots so the
 * model can pivot to offline reuse.
 */
export declare function annotateExtract(payload: Record<string, unknown>, mcpArgs: Record<string, unknown>): Record<string, never>;
/**
 * Humanize wigolo_watch payloads: readable next-check timing so the model does
 * not have to interpret raw negative staleness seconds.
 */
export declare function humanizeWatch(payload: Record<string, unknown>): Record<string, never>;
/** Render scored [score] title | url lines plus wigolo telemetry. */
export declare function renderSources(value: unknown): string;
/** Truncate a long text payload for the model view. */
export declare function clip(text: string, max: number): string;
/** Resolve the effective timeout (config override or default). */
export declare function effectiveTimeout(config: ToolConfig, fallback: number): number;
