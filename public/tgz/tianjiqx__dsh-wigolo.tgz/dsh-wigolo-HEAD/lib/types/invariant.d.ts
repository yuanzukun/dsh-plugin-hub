/** Stable facts about the plugin, independent of any runtime. */
/** Stable cordis plugin name. */
export declare const PLUGIN_NAME: "@tianjiqx/dsh-wigolo";
/** Provider ids registered into the dsh-web seam (kept from the legacy plugin so existing searchProvider configs keep working). */
export declare const SEARCH_PROVIDER_ID: "wigolo";
export declare const FETCH_PROVIDER_ID: "wigolo";
/** The wigolo daemon's MCP endpoint path. */
export declare const MCP_PATH: "/mcp";
/** MCP protocol version spoken by the client. */
export declare const MCP_PROTOCOL_VERSION: "2024-11-05";
/** Client identity announced during MCP initialize. */
export declare const MCP_CLIENT_INFO: {
    readonly name: "dsh-wigolo";
    readonly version: "1.1.0";
};
/** Config file location: <home>/.dsh/wigolo.json. */
export declare const CONFIG_FILE_NAME: "wigolo.json";
/** Legacy token file location (also the default tokenFile target). */
export declare const DEFAULT_TOKEN_FILE_NAME: "wigolo-token";
/** Legacy env vars, imported on first run. */
export declare const LEGACY_ENV_HOST: "WIGOLO_HOST_IP";
export declare const LEGACY_ENV_PORT: "WIGOLO_PORT";
export declare const LEGACY_ENV_TOKEN: "WIGOLO_TOKEN";
/** Managed block markers in ~/.dsh/cordis.patch.yml (dsh-skin precedent). */
export declare const CORDIS_MANAGED_BEGIN = "# --- dsh-wigolo managed (auto-generated; do not edit) ---";
export declare const CORDIS_MANAGED_END = "# --- end dsh-wigolo managed ---";
/** The agent-facing announcement order within the tool-guidance band. */
export declare const ANNOUNCE_ORDER = 151;
