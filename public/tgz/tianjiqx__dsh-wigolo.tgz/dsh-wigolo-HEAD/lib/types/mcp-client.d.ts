/**
 * Minimal streamable-http MCP client for the wigolo daemon, with lazy
 * session establishment and stale-session recovery. Features hostHeader
 * resolution ("auto" sends no custom Host for local addresses, literal
 * only for remote hosts behind wigolo's DNS-rebinding allowlist) and
 * injectable connection settings so the panel's test probe can use them
 * without a store.
 *
 * Transport: node:http (NOT fetch — the Fetch spec forbids setting the
 * Host header). initialize (capture mcp-session-id) ->
 * notifications/initialized (202, empty body) -> tools/call. Responses
 * arrive as SSE frames or plain JSON.
 */
import type { ConnectionConfig } from './protocol.ts';
export { resolveHostHeaderFromConfig as resolveHostHeader } from './config.ts';
/** A lossless JSON document (the parsed MCP tool result). */
export type JsonValue = null | boolean | number | string | JsonValue[] | {
    [key: string]: JsonValue;
};
/** Connection probe result (panel "test connection"). */
export interface ProbeResult {
    ok: boolean;
    latencyMs: number;
    serverVersion?: string;
    error?: string;
}
/**
 * The MCP client. One instance owns one session; callTool re-establishes the
 * session on stale-id failures (daemon restart) exactly once before retrying.
 */
export declare class WigoloMcpClient {
    private connection;
    private token;
    private sessionId;
    private initPromise;
    private nextId;
    /** Bumped by reconfigure(); in-flight handshakes check it after each await. */
    private generation;
    private readonly timeoutMs;
    constructor(connection: {
        host: string;
        port: number;
        hostHeader: string;
    }, token: string, timeoutMs?: number);
    /** Connection settings snapshot (host/port/hostHeader the client was built with). */
    get settings(): {
        host: string;
        port: number;
        hostHeader: string;
    };
    /**
     * Hot-reconfigure the connection without creating a new client instance.
     * Resets the MCP session (sessions are bound to a specific host/port).
     * Called by the panel API after config edits so tool calls pick up the
     * new connection immediately — no DSH restart required.
     */
    reconfigure(connection: {
        host: string;
        port: number;
        hostHeader: string;
    }, token: string): void;
    /** Probe the daemon: one initialize round, no session retained. */
    probe(): Promise<ProbeResult>;
    private ensureSession;
    /**
     * Call a wigolo tool and coerce the result to an object shape (empty when
     * the daemon returned a non-object). The convenience consumers (tools,
     * providers) all expect object payloads.
     */
    callToolObject(name: string, args?: Record<string, unknown>): Promise<Record<string, JsonValue>>;
    /**
     * Call a wigolo tool; re-initializes once on session failure before retrying.
     * The return is a parsed JSON document (lossless JSON by construction).
     */
    callTool(name: string, args?: Record<string, unknown>): Promise<JsonValue>;
}
/** Build a live client from the stored config + token (factory used by the host half). */
export declare function clientFromConfig(connection: ConnectionConfig, token: string, timeoutMs?: number): WigoloMcpClient;
