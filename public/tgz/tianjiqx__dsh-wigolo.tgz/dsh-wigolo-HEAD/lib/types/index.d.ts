/**
 * dsh-wigolo — host half. Mounts the config store, the /api/dsh-wigolo
 * route family, the web seam providers (per takeover), the wigolo_* agent
 * tools (per tool exposure), and a system-prompt announcement.
 * The browser half (./client) renders the sidebar panel.
 *
 * Takeover: a boolean. true registers the wigolo providers AND requires
 * searchProvider/fetchProvider: wigolo in the home cordis patch (without it,
 * coexisting providers would trip the seam's WEB_PROVIDER_AMBIGUOUS error);
 * false registers nothing into the seam — the wigolo_* tools work standalone.
 * See cordis-managed.ts for the routing management.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Stable cordis plugin name. */
export declare const name: "@tianjiqx/dsh-wigolo";
/** Services required before the wigolo surfaces can mount. */
export declare const inject: string[];
/** Stable profile entry/settings id used by both the current and legacy settings surfaces. */
export declare const WIGOLO_SETTINGS_NAMESPACE = "dsh-wigolo";
/** Plugin entry config, validated by the same-named schemastery schema (doubles as the settings card schema). */
export interface Config {
    /** Master switch for the plugin (routes, providers, tools, prompt). */
    enabled?: boolean;
    /** When true (default), a system-prompt section announces the wigolo tools to every agent. */
    announceToAgent?: boolean;
    /** Overrides the shipped announcement text (deployments localize or rewrite it). */
    guidance?: string;
}
export declare const Config: z<Config>;
/** Model-facing announcement: capabilities, takeover note, and limits. */
export declare const WIGOLO_GUIDANCE: string;
/**
 * Mount every surface: store, routes, providers (takeover-gated), tools,
 * and the announcement.
 * @param ctx - host plugin context.
 * @param config - resolved plugin entry config.
 */
export declare function apply(ctx: Context, config?: Config): void;
