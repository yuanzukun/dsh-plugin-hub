/**
 * Config schema, defaults, validation, and legacy migration.
 *
 * Storage: ~/.dsh/wigolo.json (version 2), written atomically (tmp + rename),
 * same trust model as dsh-ssh's host store. The token itself NEVER lives in
 * this file — it stays in its own 0600 file (default ~/.dsh/wigolo-token),
 * so the config file is safe to render in the panel and in error messages.
 */
import { existsSync, readFileSync } from 'node:fs';
import type { ConnectionConfig, WigoloConfig } from './protocol.ts';
/** Plugin-level config as seen by cordis (subset exposed in the composition layer). */
export interface PluginEntryConfig {
    enabled?: boolean;
}
/** Tool ids exposed by the plugin (keys of tools config). */
export declare const TOOL_IDS: readonly ["wigolo_search", "wigolo_crawl", "wigolo_extract", "wigolo_research", "wigolo_find_similar", "wigolo_cache", "wigolo_watch"];
export type ToolId = (typeof TOOL_IDS)[number];
/** The stock config a fresh install gets. */
export declare function defaultConfig(): WigoloConfig;
/** Resolve the effective token file path ('' means the default location). */
export declare function resolveTokenFilePath(config: WigoloConfig): string;
/** Expand a leading ~ in a user-provided path. */
export declare function expandHome(p: string): string;
/**
 * Detect a legacy setup (env vars or token file) and return connection
 * overrides to import. Returns undefined when nothing to import. Pure
 * function of env + fs (injectable for tests).
 */
export declare function detectLegacySetup(env?: NodeJS.ProcessEnv, exists?: typeof existsSync, readFile?: typeof readFileSync): {
    host?: string;
    port?: number;
    hasTokenFile: boolean;
} | undefined;
/** Merge legacy detection into a fresh config (first-run import). */
export declare function applyLegacyImport(config: WigoloConfig, legacy: ReturnType<typeof detectLegacySetup>): WigoloConfig;
/** Validate a connection payload from the panel; returns a message or undefined. */
export declare function validateConnectionPayload(payload: unknown): string | undefined;
/** Validate a takeover value. */
export declare function validateTakeover(value: unknown): string | undefined;
/** Validate a timezone value. */
export declare function validateTimezone(value: unknown): string | undefined;
/**
 * Resolve the Host header to send: undefined = default; 'auto' sends no
 * custom header for local targets and the bind-host trick for remote ones.
 */
export declare function resolveHostHeaderFromConfig(connection: Pick<ConnectionConfig, 'host' | 'hostHeader'>): string | undefined;
