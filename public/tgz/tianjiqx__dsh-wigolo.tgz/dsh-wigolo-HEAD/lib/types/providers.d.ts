/**
 * Web seam providers (WebSearchProvider + WebFetchProvider) backed by the
 * wigolo daemon. Registered only when takeover != 'none' — see the
 * AMBIGUOUS-trap note in the plugin entry. Registration order never matters:
 * the seam resolves providers at call time by configured id.
 */
import type { WigoloMcpClient } from './mcp-client.ts';
/** Map a wigolo search payload to the dsh-web WebSearchResult shape (contract from the legacy plugin). */
export declare function toSearchResult(payload: Record<string, unknown>): {
    content?: string;
    sources: Array<{
        url: string;
        title?: string;
        snippet?: string;
        publishedAt?: string;
    }>;
    truncated: boolean;
};
/** Map a wigolo fetch payload to the dsh-web WebFetchResult shape. */
export declare function toFetchResult(payload: Record<string, unknown>, requestUrl: string): {
    url: string;
    statusCode: number;
    body: {
        kind: 'text';
        content: string;
    };
    truncated: boolean;
};
/** Search provider bridging the seam's search() to wigolo's search tool. */
export declare class WigoloSearchProvider {
    private readonly client;
    private readonly tokenPresent;
    readonly id: "wigolo";
    constructor(client: WigoloMcpClient, tokenPresent: boolean);
    /** Cheap local check only — no network calls (contract requirement). */
    available(): boolean;
    search(request: {
        query: string;
        maxResults?: number;
    }): Promise<ReturnType<typeof toSearchResult>>;
}
/** Fetch provider bridging the seam's fetch() to wigolo's fetch tool. */
export declare class WigoloFetchProvider {
    private readonly client;
    private readonly tokenPresent;
    readonly id: "wigolo";
    constructor(client: WigoloMcpClient, tokenPresent: boolean);
    available(): boolean;
    fetch(request: {
        url: string;
    }): Promise<ReturnType<typeof toFetchResult>>;
}
