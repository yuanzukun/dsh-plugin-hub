## [Unreleased]

### Changed

- Use DSH 0.1.7+ volatile plugin Config fields for the current profile settings editor, while retaining runtime feature detection for the legacy `settings.register` API.


## [1.2.2] - 2025-08-19

### Fixed

- **PLUGIN_NAME consistency** — changed from 'dsh-wigolo' to '@tianjiqx/dsh-wigolo' in src/invariant.ts and tsdown.config.ts module loader, ensuring all plugin identifiers match the npm package name.
- **Documentation uninstall commands** — updated GUIDE.md, GUIDE.zh.md, README.md, README.zh.md to use '@tianjiqx/dsh-wigolo' instead of 'dsh-wigolo'.

## [1.2.1] - 2025-08-19

### Fixed

- **cordis.patch.yml name mismatch** — sync name field with package.json rename to @tianjiqx/dsh-wigolo; the stale dsh-wigolo name caused module resolution failure on install.
- **No-op .replace removed** from convertUtcToTimezone (cosmetic cleanup).
- **Trailing newline** added to src/tools.ts, src/routes.ts, test/cache-tab.test.ts, src/client/cache-filter.ts.

## [1.2.0] - 2025-08-18

### Added

- **Timezone-aware cache timestamps** — new `timezone` config option converts the daemon's zone-less UTC timestamps (`fetched_at`, `oldest`, `newest`) to the configured timezone before returning to the agent. Supports `"local"` (system timezone, default), numeric offsets (`"+8"`, `"-5"`, `"+5.5"`), and IANA timezone names (`"Asia/Shanghai"`, `"America/New_York"`).
- **Wigolo Cache tab (conversation.view, off by default)** — optional read-only browser over the daemon cache snapshot library and watch jobs, per docs/CACHE-TAB.md: two in-tab sub-pages (browse with stats strip / keyword / this-session filters and lazy-loaded markdown details; watch jobs with check/pause/resume quick actions, no create/delete), 4 module-gated host routes (markdown stripped from list responses, 403 when off), dynamic toggle from the panel (dispose+re-register, no page refresh), ARCHITECTURE's Agent-First principle revised accordingly.
- **Usage guide (Help tab)** — the sidebar panel gains a fourth "Help" tab that renders the bundled GUIDE.zh.md via the official MarkdownText renderer (same pipeline as chat AssistantMarkdown). Content fetched lazily from a new `/api/dsh-wigolo/guide` host route.
- **Panel i18n** — the sidebar panel ships zh/en locale dictionaries (registered via the dsh client-locale service); all user-facing strings localized.
- **Test connection with unsaved values** — the Connection tab's test button probes the form's current host/port/hostHeader/tokenFile before committing them.
- **Client build CSS Modules inline** — tsdown config now compiles CSS Modules via lightningcss inside the client bundle (drops the `@tsdown/css` dependency); About tab version is injected from package.json at build time.

### Changed

- **Connection/token edits hot-apply** — saving connection settings or writing a token from the panel now hot-reconfigures the live MCP client (no dsh restart needed for tool calls to pick them up).
- **Panel UX fixes (frontend)** — token success message no longer tells users to restart DSH (agent tools are live immediately; only provider takeover needs a restart); restart hints are localized instead of raw English strings; connection form gains dirty-state tracking (unsaved-changes dot + confirm on tab switch/panel close), live port validation (red border + message), and stale test results are cleared on any form edit; takeover toggle shows a switching state; close button uses ✕; inputs/buttons/tabs get a visible :focus-visible ring.
- **wigolo_watch action names fixed** — the tool description now matches the daemon's real actions (create | list | check | pause | resume | delete); add/remove are accepted as aliases and normalized to create/delete before dispatch. Docs (en/zh) updated to match. Watch payloads are humanized: raw staleness_seconds gain a readable next_check_in field.
- **wigolo_extract selector misses are explicit** — when a CSS selector/schema request falls back to metadata-only (typical on JS-rendered SPA pages), the response now carries selector_matched: false, fallback: "metadata-only", and a hint pointing at wigolo_crawl / wigolo_cache instead of silently returning page metadata. The tool description documents the server-rendered-DOM limitation.
- **wigolo_research description steers usage** — the description now says to prefer wigolo_search/wigolo_crawl for simple factual/list queries and to use include_domains to keep citations on-topic.

### Fixed

- **Panel no longer overwrites saved config with defaults** — the Connection form previously initialized from defaults while the config was still loading and never resynced; saving at that moment would silently overwrite the real host/port.
- **Connection probe no longer poisons the MCP session** — "Test connection" previously stored a half-initialized session id that the next tool call would reuse.
- **Takeover flag simplified to a boolean** — docs updated to match (README/CONFIGURATION/PROVIDERS/ARCHITECTURE, en+zh previously described the removed three-state modes).
- **Cache tab frequent refresh bug** — the slot view factory created a new `makeApi()` object on every render, causing useEffect dependency chain avalanche. Fixed by creating a stable api reference inside the closure.

## [1.1.0] - 2025-08-18

### Added

- **Token write from panel** — paste the bearer token directly into the Connection tab; the plugin writes the 0600 file. No terminal required for first-time setup.
- **Official settings integration** — `enabled`, `announceToAgent`, and `guidance` override now live in the official DSH settings UI (dsh-ssh `installSettingsSection` pattern). Hot-reload: change settings, no restart needed.
- **Fail-loud config validation** — unknown keys in `~/.dsh/wigolo.json` trigger warnings with "did you mean?" hints (edit-distance matching) instead of being silently dropped.

### Changed

- **Agent-first positioning** — the panel is now config-only (Connection / Takeover & Tools / About). Cache browsing and watch management happen through the agent tools (`wigolo_cache`, `wigolo_watch`), not the GUI.
- **Panel slimmed** — removed the Cache & Watch tab (redundant with agent tools).

### Fixed

- **Settings hot-reload** — `announceToAgent` and `guidance` changes take effect immediately without restarting dsh.

## [1.0.0] - 2025-08-18

### Added

- **Provider takeover** — configurable routing of `web_search` / `web_fetch` through
  the wigolo daemon (boolean switch: `true` = wigolo drives both, `false` = official providers),
  switched from the sidebar panel with automatic cordis managed-block handling (`~/.dsh/cordis.patch.yml`).
- **Web seam providers** — `WebSearchProvider` + `WebFetchProvider` (id `wigolo`).
- **Seven agent tools** — `wigolo_search`, `wigolo_crawl`, `wigolo_extract`,
  `wigolo_research`, `wigolo_find_similar`, `wigolo_cache`, `wigolo_watch`, built on
  the official `defineTool` DSL with per-tool parameter surfaces trimmed from the
  daemon's real MCP schemas.
- **Sidebar panel** (React 18, CSS Modules) — three tabs: Connection (host/port/
  hostHeader/token file + live test with latency & daemon version), Takeover & Tools
  (boolean takeover switch + per-tool exposure), About (Host-header note).
- **Config store** — `~/.dsh/wigolo.json` (v2) with atomic writes (tmp + rename);
  the token lives in its own 0600 file (`~/.dsh/wigolo-token`) and never in the config.
- **Panel API** — `/api/dsh-wigolo/*` route family behind a loopback-only trust
  fence (remote address + Host + `sec-fetch-site` + origin), secret-free responses.
- **MCP client** — streamable-http with lazy session establishment, stale-session
  recovery, and `hostHeader` resolution (`auto` sends no custom header for local
  daemons, the bind-host trick for remote ones).
- **Tests** — 35 unit tests (store, migration, host-header resolution, cordis managed
  block, tool parameter mapping, provider contracts) plus manual smoke scripts
  against a live daemon.
