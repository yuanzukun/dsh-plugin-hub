/**
 * 文件工作台持久化存储 —— 后端 JSON 配置文件（按类型分文件）。
 *
 * 不同持久化类型各自写入独立 JSON 文件，目录为：
 *   {DSH_HOME | ~/.dsh}/fileworkbench/
 *   ├── prefs.json     界面偏好
 *   ├── favorites.json 收藏路径
 *   └── layout.json    布局（导航分组展开态 / 资源管理器分隔比例）
 *
 * key → 文件名 由白名单 PERSIST_KEYS 约束，杜绝路径穿越。
 */
import { readFile, writeFile, mkdir, readdir } from "node:fs/promises";
import { join, basename } from "node:path";
import { homedir } from "node:os";
import type { TaskArchiveMap, TaskLogRecord } from "../../shared/types";

/** 允许持久化的 key 白名单（key 即产物文件名，不含扩展名）。 */
export const PERSIST_KEYS = [
  "prefs",
  "favorites",
  "recent",
  "layout",
  // 终端浮窗几何 / 按目录视图记忆 / 后台任务历史：均为客户端实际在用的键。
  "termWin",
  "termWins",
  "folderViews",
  "taskLogs",
  // VS Code 编辑器面板状态（项目目录 / 已开标签 / 激活标签 / 展开节点 / 比例）。
  "vscode",
  // SSH 远端主机连接配置（含认证机密——本机配置文件，不外发）。
  "ssh-hosts",
  // Git / SVN 账号（凭据）配置（含认证机密——本机配置文件，不外发）；
  // 与系统凭据管理器 / %APPDATA%\Subversion\auth 互不干扰，仅在用户显式点「写入系统」时写入。
  "accounts",
] as const;
export type PersistKey = (typeof PERSIST_KEYS)[number];

/** 持久化文件存放目录：{DSH_HOME | ~/.dsh}/fileworkbench/。 */
function stateDir(): string {
  const dshHome = process.env.DSH_HOME || join(homedir(), ".dsh");
  return join(dshHome, "fileworkbench");
}

/**
 * 对外暴露持久化目录：accounts 需要在同目录下生成 git 凭据外壳（askpass），
 * 与 `accounts.json` 同处一个已被本插件管理的目录，避免再引入一处散落状态。
 */
export function workbenchStateDir(): string {
  return stateDir();
}

/** key 是否合法：命中白名单。 */
function isPersistKey(key: string): boolean {
  return (PERSIST_KEYS as readonly string[]).includes(key);
}

function fileFor(key: string): string {
  return join(stateDir(), `${key}.json`);
}

/** 读取某个持久化 key 的配置（文件不存在或损坏时返回 undefined）。 */
export async function getPersistKey(key: string): Promise<unknown> {
  if (!isPersistKey(key)) return undefined;
  try {
    return JSON.parse(await readFile(fileFor(key), "utf8"));
  } catch {
    return undefined;
  }
}

/** 写入某个持久化 key 到其独立配置文件。 */
export async function setPersistKey(key: string, value: unknown): Promise<void> {
  if (!isPersistKey(key)) {
    throw new Error(`unknown persist key: ${key}`);
  }
  await mkdir(stateDir(), { recursive: true });
  await writeFile(fileFor(key), JSON.stringify(value ?? null), "utf8");
}

/** 汇总所有持久化 key 为单个对象（供客户端一次性读取全量）。 */
export async function getAllPersist(): Promise<Record<string, unknown>> {
  const out: Record<string, unknown> = {};
  for (const k of PERSIST_KEYS) {
    const v = await getPersistKey(k);
    if (v !== undefined) out[k] = v;
  }
  return out;
}

/* ── 插件数据（pluginData.json，单文件命名空间存储） ─────────────────────── */

/**
 * 外部 / 内置插件的持久化数据：全部存进单个 `pluginData.json`，顶层按 key 分区。
 *
 * 与 PERSIST_KEYS 白名单解耦——插件自带任意 key 不可能逐个加白名单，故另立一处
 * 受控容器：key 经严格校验（字符集 + 长度），杜绝把 key 当路径使用；整表单条原子覆写。
 */
const PLUGIN_DATA_FILE = "pluginData";

/** 合法插件数据 key：字母/数字/_/-/. ，1~128 长，且不得含路径分隔或 ".."。 */
function isPluginDataKey(key: string): boolean {
  return /^[A-Za-z0-9_.-]{1,128}$/.test(key) && !key.includes("..");
}

async function readPluginData(): Promise<Record<string, unknown>> {
  try {
    const parsed: unknown = JSON.parse(await readFile(join(stateDir(), `${PLUGIN_DATA_FILE}.json`), "utf8"));
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? (parsed as Record<string, unknown>) : {};
  } catch {
    return {};
  }
}

/** 读插件数据单项；key 非法返回 undefined。 */
export async function getPluginData(key: string): Promise<unknown> {
  if (!isPluginDataKey(key)) return undefined;
  return (await readPluginData())[key];
}

/** 写插件数据单项（覆盖）；key 非法抛错。 */
export async function setPluginData(key: string, value: unknown): Promise<void> {
  if (!isPluginDataKey(key)) throw new Error(`invalid plugin data key: ${key}`);
  const map = await readPluginData();
  map[key] = value ?? null;
  await mkdir(stateDir(), { recursive: true });
  await writeFile(join(stateDir(), `${PLUGIN_DATA_FILE}.json`), JSON.stringify(map), "utf8");
}

/** 列出全部插件数据 key（供管理界面查看 / 清理）。 */
export async function listPluginDataKeys(): Promise<string[]> {
  return Object.keys(await readPluginData());
}

/* ── 后台任务归档（taskArchives/<日期>.json，逐日独立文件） ───────────────── */

/** 归档日期合法性：YYYY-MM-DD，杜绝路径穿越拾取任意文件。 */
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/** 归档存放目录：{stateDir}/taskArchives/。 */
function taskArchivesDir(): string {
  return join(stateDir(), "taskArchives");
}

/** 按日期读取当日归档记录；文件缺失或损坏返回空数组。 */
async function readTaskArchive(date: string): Promise<TaskLogRecord[]> {
  if (!DATE_RE.test(date)) return [];
  try {
    const parsed: unknown = JSON.parse(await readFile(join(taskArchivesDir(), `${date}.json`), "utf8"));
    return Array.isArray(parsed) ? (parsed as TaskLogRecord[]) : [];
  } catch {
    return [];
  }
}

/** 列出所有已归档日期（倒序，最新在前）。 */
export async function listTaskArchiveDates(): Promise<string[]> {
  try {
    const names = await readdir(taskArchivesDir());
    return names
      .filter((n) => n.endsWith(".json") && DATE_RE.test(basename(n, ".json")))
      .map((n) => basename(n, ".json"))
      .sort((a, b) => (a < b ? 1 : -1));
  } catch {
    return [];
  }
}

/** 读取全量归档映射（{ 日期: 记录[] }）。 */
export async function readTaskArchives(): Promise<TaskArchiveMap> {
  const dates = await listTaskArchiveDates();
  const map: TaskArchiveMap = {};
  for (const d of dates) map[d] = await readTaskArchive(d);
  return map;
}

/**
 * 整体覆写归档映射：逐日期写为独立 JSON 文件。
 * 注意：清空某日归档时写空数组而非删除文件——受限环境对删除有安全守卫，
 * 前端按记录数过滤空日份即可。
 */
export async function writeTaskArchives(map: TaskArchiveMap): Promise<void> {
  const dir = taskArchivesDir();
  await mkdir(dir, { recursive: true });
  const dates = Object.keys(map).filter((d) => DATE_RE.test(d));
  await Promise.all(
    dates.map((d) => writeFile(join(dir, `${d}.json`), JSON.stringify(map[d] ?? []), "utf8")),
  );
}
