Condense prior history into structured summary for plot continuation. Include main plot, old summaries & worldbook snapshot facts. Newer main text overrides conflicting old summaries.

只输出摘要本身，按以下八段组织，某段无内容写「ToPopulate」：

剧情脉络：Record key events, causal chains & pending items chronologically. Preserve exact time, location, participants and outcomes. Content summary handled separately; prioritize structural links.
人物档案：每位人物一行——身份、外貌特征、性格、口吻习惯、能力、动机、秘密、当前状态（伤势/持有/所在位置/活动）、Sexualization、Erogenous、Allure、Genitalia；Take note of newly introduced characters; Monitor character changes and OfflineActivity for departed characters
关系网：Directed relationships and evolution between characters — relationship type, current stage, key turning-point events, secrets, promises, Amorous, Lust
世界与设定：各轮世界书上下文与正文中确立的世界规则——地理、组织、能力体系、经济政治规则、公开与秘密状态；不要抄录，整理为关键规则；
物品与资源：重要物品的持有者、所在位置、状态与来历
伏笔与约定：所有未解决线索、未兑现约定、待确认事项、用户否定过的走向；已兑现的注明结果，若篇幅不足，则压缩或删除已兑现的伏笔，仅保留精要事实
当前情况：Time, location, present characters, their states & ongoing actions, ambient mood. Concise, no redundancy. Prioritize off-screen hidden character dynamics. Live scene handled by separate system maintenance. 注意不要和剧情主线段冗余！关注暗线进展！
用户意志：用户明确表达过的偏好、底线与对剧情的纠正；用户表述的事实永远有效

记录要求：
保留专名、数字、称谓与用户原话中的关键表述，但不要冗余，拒绝无意义的修辞
一次性描写不得写成永久设定，剧情尽量压缩
遇到取舍时优先保：用户意志 > 人物关系 > 未兑现伏笔 > 当前生效设定 > 历史事件细节 > 当前现场；结果 > 过程；结构关系 > 场景叙述；暗线发展 > 过期主线; 长期影响 > 短期事态
只总结已发生的内容，不续写、不猜测、不评价，只输出摘要
已有摘要也一起归纳，合并重复内容，省略琐碎和失效的细节，使摘要显著短于原文
核心要务：提炼关键信息，精炼有效的规则集，而非叙述性描写；结构化摘要，各段不要重复冗余，职责清晰
