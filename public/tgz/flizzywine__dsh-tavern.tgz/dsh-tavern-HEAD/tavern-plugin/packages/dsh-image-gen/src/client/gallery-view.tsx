/**
 * Native Workspace Gallery & Studio View Component for DSH `conversation.view` slot.
 * Fully i18n-reactive (Chinese & English) with modular tabs, multi-dimensional filters,
 * responsive image grid, and image editing.
 */
import { useEffect, useState, useMemo, useRef, type FC, type MouseEvent } from 'react'
import { IMAGE_ROUTE, DELETE_ROUTE } from '../shared.js'
import {
  Image as ImageIcon,
  SlidersHorizontal,
  Heart,
  Search,
  Copy,
  Download,
  FileText,
  Trash2,
  X,
  ChevronLeft,
  ChevronRight,
  Check,
  AlertTriangle,
  Sparkles,
} from 'lucide-react'
import {
  getGalleryItems,
  subscribeGallery,
  saveGalleryItem,
  bulkDeleteGalleryItems,
  toggleFavoriteGalleryItem,
  isItemInWorkspace,
  type GalleryItem,
} from './gallery-store.js'
import { StudioView } from './studio-view.js'
import { evictAttachmentCache, fetchAttachmentBlob } from './image-cache.js'
import { copyImageBlob } from './browser-image-utils.js'
import { conversationRegenerateRequest } from './conversation-regenerate.js'
import { STUDIO_ROUTE, type StudioWorkspaceInfo, type StudioGenerateResponse } from '../shared.js'

export interface LocaleService {
  getSnapshot(): { active: string }
  subscribe(fn: () => void): () => void
}

export type TabKey = 'gallery' | 'studio' | 'favorites'
export type SortKey = 'newest' | 'oldest'

const DICT = {
  zh: {
    // 顶部 Tab
    tabGallery: '图库',
    tabStudio: '工作台',
    tabFavorites: '收藏',
    tabCompare: '对比',
    tabTasks: '任务',

    // 筛选工具栏
    filterAllProviders: '全部提供商',
    filterGoogle: 'Google Gemini',
    filterOpenAI: 'OpenAI / 兼容接口',
    filterSeedream: '字节 Seedream',
    filterDashScope: '阿里 DashScope',
    filterComfyUI: '本地 ComfyUI',
    filterAllModels: '全部模型',
    filterAllRatios: '全部比例',
    searchPlaceholder: '搜索 Prompt、标签…',
    filterCurrentWorkspace: '仅看此工作区',
    filterCurrentWorkspaceHint: '只展示属于当前工作区的生图记录与物理文件',
    sortNewest: '最新生成',
    sortOldest: '最早生成',

    // 状态与提示
    totalCount: '共 {count} 张生成图片',
    emptyTitle: '暂无生图记录',
    emptyDesc: '在对话中让 Agent 生图后，生成的图片会自动收录到这里。',
    favEmptyTitle: '暂无收藏图片',
    favEmptyDesc: '在图库中点击卡片右下角的 ♡ 按钮，即可将喜爱的图片收录到这里。',
    noMatchTitle: '未找到匹配结果',
    noMatchDesc: '尝试更换搜索关键词或调整筛选条件。',
    copiedPrompt: '已复制 Prompt',
    copiedImage: '已复制图片',
    copyFailed: '复制失败',
    favoriteAdded: '已添加到收藏',
    favoriteRemoved: '已取消收藏',

    // 卡片与弹窗操作
    preview: '查看大图',
    download: '下载图片',
    copyImg: '复制图片',
    copyPpt: '复制 Prompt',
    regenerate: '重新生成',
    regenerateTitle: '重新生成图片',
    regenerateHint: '可按需修改 Prompt，基于当前模型和比例在画廊生成一张新图片。',
    confirmRegenerate: '开始生成',
    regenerating: '正在重新生成…',
    regenerateSuccess: '已生成新图片并收录到画廊',
    regenerateFailed: '重新生成失败',
    delete: '从画廊删除',
    confirmDelete: '确定要从画廊中删除这张图片吗？（不会影响原聊天记录）',
    deleted: '已从画廊删除',
    model: '模型',
    prompt: 'Prompt',
    close: '关闭 (Esc)',
    prevImage: '上一张 (←)',
    nextImage: '下一张 (→)',

    // 批量管理与删除
    manage: '批量删除',
    exitManage: '退出选择',
    selectedCount: '已选 {n} 项',
    selectAll: '全选',
    invertSelect: '反选',
    clearSelect: '清空',
    batchDelete: '批量删除',
    batchDeleteTitle: '确认批量删除选中的 {count} 张图片？',
    batchDeleteTitleSingle: '确认从画廊中删除这张图片？',
    batchDeleteDesc: '将从画廊历史记录中移除所选图片。',
    deleteWorkspaceFilesOpt: '同时清理工作区磁盘物理文件（不可恢复）',
    cancel: '取消',
    confirmBatchDelete: '确认删除 ({count})',
    confirmDeleteSingle: '确认删除',
    batchDeletedToast: '已删除 {count} 张图片',
    batchDeletedWithFilesToast: '已删除 {count} 张图片，并清理了 {files} 个工作区文件',
    deleteFailedFileLocked: '已删除 {count} 张图片，但有 {files} 个文件因被系统占用未能删除',
    deleteFailedDatabase: '删除失败：本地数据库操作异常',

    // 时间格式化
    justNow: '刚刚',
    minutesAgo: '{n} 分钟前',
    hoursAgo: '{n} 小时前',
    daysAgo: '{n} 天前',
  },
  en: {
    // Top Tabs
    tabGallery: 'Gallery',
    tabStudio: 'Studio',
    tabFavorites: 'Favorites',
    tabCompare: 'Compare',
    tabTasks: 'Tasks',

    // Filter Toolbar
    filterAllProviders: 'All Providers',
    filterGoogle: 'Google Gemini',
    filterOpenAI: 'OpenAI / Compatible',
    filterSeedream: 'ByteDance Seedream',
    filterDashScope: 'Aliyun DashScope',
    filterComfyUI: 'Local ComfyUI',
    filterAllModels: 'All Models',
    filterAllRatios: 'All Ratios',
    searchPlaceholder: 'Search prompt, tags…',
    filterCurrentWorkspace: 'Current workspace only',
    filterCurrentWorkspaceHint: 'Only show images belonging to the active workspace',
    sortNewest: 'Newest first',
    sortOldest: 'Oldest first',

    // States & Toasts
    totalCount: '{count} images total',
    emptyTitle: 'No images generated yet',
    emptyDesc: 'Images generated during conversations will automatically appear here.',
    favEmptyTitle: 'No favorite images yet',
    favEmptyDesc: 'Click the ♡ button on any card in the gallery to collect your favorite images here.',
    noMatchTitle: 'No matching images',
    noMatchDesc: 'Try a different search keyword or adjust filter criteria.',
    copiedPrompt: 'Prompt copied',
    copiedImage: 'Image copied',
    copyFailed: 'Copy failed',
    favoriteAdded: 'Added to favorites',
    favoriteRemoved: 'Removed from favorites',

    // Card & Lightbox Actions
    preview: 'Full Preview',
    download: 'Download',
    copyImg: 'Copy Image',
    copyPpt: 'Copy Prompt',
    regenerate: 'Regenerate',
    regenerateTitle: 'Regenerate Image',
    regenerateHint: 'Edit prompt if needed. A new image will be generated and added to the gallery.',
    confirmRegenerate: 'Generate',
    regenerating: 'Regenerating…',
    regenerateSuccess: 'New image generated and added to gallery',
    regenerateFailed: 'Regeneration failed',
    delete: 'Delete from gallery',
    confirmDelete: 'Are you sure you want to remove this image from the gallery? (Chat history will not be affected)',
    deleted: 'Deleted from gallery',
    model: 'Model',
    prompt: 'Prompt',
    close: 'Close (Esc)',
    prevImage: 'Previous (←)',
    nextImage: 'Next (→)',

    // Batch Management & Delete
    manage: 'Batch Delete',
    exitManage: 'Done',
    selectedCount: '{n} selected',
    selectAll: 'Select All',
    invertSelect: 'Invert',
    clearSelect: 'Clear',
    batchDelete: 'Batch Delete',
    batchDeleteTitle: 'Delete {count} selected images?',
    batchDeleteTitleSingle: 'Delete this image from gallery?',
    batchDeleteDesc: 'These images will be removed from your gallery history.',
    deleteWorkspaceFilesOpt: 'Also delete files from workspace disk (cannot be undone)',
    cancel: 'Cancel',
    confirmBatchDelete: 'Delete ({count})',
    confirmDeleteSingle: 'Delete',
    batchDeletedToast: 'Deleted {count} images',
    batchDeletedWithFilesToast: 'Deleted {count} images and cleaned {files} workspace files',
    deleteFailedFileLocked: 'Deleted {count} images, but {files} files could not be deleted (busy/locked)',
    deleteFailedDatabase: 'Failed to delete: local database error',

    // Relative Time
    justNow: 'Just now',
    minutesAgo: '{n}m ago',
    hoursAgo: '{n}h ago',
    daysAgo: '{n}d ago',
  },
} as const

export type DictKey = keyof typeof DICT.zh

/** Format human-readable relative time */
function formatRelativeTime(
  timestamp: number,
  t: (key: DictKey, params?: Record<string, string>) => string
): string {
  const diff = Date.now() - timestamp
  if (diff < 60_000) {
    return t('justNow')
  }
  if (diff < 3600_000) {
    const mins = Math.max(1, Math.floor(diff / 60_000))
    return t('minutesAgo', { n: String(mins) })
  }
  if (diff < 86400_000) {
    const hours = Math.floor(diff / 3600_000)
    return t('hoursAgo', { n: String(hours) })
  }
  if (diff < 30 * 86400_000) {
    const days = Math.floor(diff / 86400_000)
    return t('daysAgo', { n: String(days) })
  }
  const d = new Date(timestamp)
  return `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`
}

/** Extract standard aspect ratio for precise filtering */
function getItemRatio(item: GalleryItem): string {
  if (item.aspectRatio && item.aspectRatio !== 'custom') {
    return item.aspectRatio
  }
  if (item.output) {
    const ratioMatch = item.output.match(/\b(1:1|16:9|9:16|4:3|3:4|3:2|2:3)\b/)
    if (ratioMatch?.[1]) return ratioMatch[1]

    const dimMatch = item.output.match(/(\d{3,4})\s*[×x*]\s*(\d{3,4})/)
    if (dimMatch?.[1] && dimMatch[2]) {
      const w = parseInt(dimMatch[1], 10)
      const h = parseInt(dimMatch[2], 10)
      if (w === h) return '1:1'
      const approx = w / h
      if (Math.abs(approx - 16 / 9) < 0.05) return '16:9'
      if (Math.abs(approx - 9 / 16) < 0.05) return '9:16'
      if (Math.abs(approx - 4 / 3) < 0.05) return '4:3'
      if (Math.abs(approx - 3 / 4) < 0.05) return '3:4'
      if (Math.abs(approx - 3 / 2) < 0.05) return '3:2'
      if (Math.abs(approx - 2 / 3) < 0.05) return '2:3'
    }
  }
  return '1:1'
}

/** Format aspect ratio or dimensions for card metadata (e.g., 1024×1024 or 16:9) */
function formatCardMeta(item: GalleryItem): string {
  if (item.output) {
    const dimMatch = item.output.match(/(\d{3,4})\s*[×x*]\s*(\d{3,4})/)
    if (dimMatch?.[1] && dimMatch[2]) {
      return `${dimMatch[1]}×${dimMatch[2]}`
    }
  }
  if (item.aspectRatio && item.aspectRatio !== 'custom') {
    return item.aspectRatio
  }
  if (item.output) {
    const ratioMatch = item.output.match(/\b(1:1|16:9|9:16|4:3|3:4|3:2|2:3)\b/)
    if (ratioMatch?.[1]) return ratioMatch[1]
  }
  if (item.imageSize) {
    return item.imageSize
  }
  return '1:1'
}

export interface GalleryViewTabProps {
  locale?: LocaleService
  sessionId?: string
  useSession?: (selector: (state: any) => any) => any
  useSessions?: (selector: (state: any) => any) => any
  useWorkspaces?: (selector: (state: any) => any) => any
}

export const GalleryViewTab: FC<GalleryViewTabProps> = (props) => {
  const { locale, sessionId, useSessions, useWorkspaces } = props
  const [activeTab, setActiveTab] = useState<TabKey>('gallery')
  const [items, setItems] = useState<GalleryItem[]>([])
  const [search, setSearch] = useState('')
  const [selectedProvider, setSelectedProvider] = useState<string>('all')
  const [selectedRatio, setSelectedRatio] = useState<string>('all')
  const [sortBy, setSortBy] = useState<SortKey>('newest')
  const [onlyCurrentWorkspace, setOnlyCurrentWorkspace] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('dsh-ig-only-current-workspace')
      return stored === null ? true : stored === 'true'
    } catch {
      return true
    }
  })
  const [serverWorkspaces, setServerWorkspaces] = useState<StudioWorkspaceInfo[]>([])
  const [serverActiveRoot, setServerActiveRoot] = useState<string | null>(null)

  useEffect(() => {
    try {
      localStorage.setItem('dsh-ig-only-current-workspace', String(onlyCurrentWorkspace))
    } catch {}
  }, [onlyCurrentWorkspace])

  useEffect(() => {
    let mounted = true
    fetch(STUDIO_ROUTE)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!mounted || !data) return
        if (Array.isArray(data.workspaces)) setServerWorkspaces(data.workspaces)
        if (typeof data.workspaceRoot === 'string') setServerActiveRoot(data.workspaceRoot)
      })
      .catch(() => {})
    return () => {
      mounted = false
    }
  }, [])

  const liveWorkspaces = useWorkspaces ? useWorkspaces((s: any) => s?.items) : null
  const liveSessions = useSessions ? useSessions((s: any) => s) : null
  const currentSessionId = sessionId || liveSessions?.current

  const activeWorkspace = useMemo(() => {
    const allWs: Array<{
      workspaceId?: string
      path?: string
      title?: string
      sessionIds?: readonly string[]
    }> =
      Array.isArray(liveWorkspaces) && liveWorkspaces.length > 0
        ? liveWorkspaces
        : serverWorkspaces

    if (allWs.length > 0) {
      if (currentSessionId) {
        const matched = allWs.find(
          (ws) => Array.isArray(ws.sessionIds) && ws.sessionIds.includes(currentSessionId),
        )
        if (matched) return matched
      }
      if (serverActiveRoot) {
        const normActive = serverActiveRoot.replace(/\\/g, '/').toLowerCase()
        const matched = allWs.find(
          (ws) => ws.path && ws.path.replace(/\\/g, '/').toLowerCase() === normActive,
        )
        if (matched) return matched
      }
      return allWs[0]
    }
    if (serverActiveRoot) {
      return { workspaceId: 'default', path: serverActiveRoot, title: 'Workspace', sessionIds: [] }
    }
    return null
  }, [liveWorkspaces, serverWorkspaces, currentSessionId, serverActiveRoot])

  const [previewItem, setPreviewItem] = useState<GalleryItem | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const previewUrlRef = useRef<string | null>(null)
  previewUrlRef.current = previewUrl
  const [previewBlob, setPreviewBlob] = useState<Blob | null>(null)
  const [toast, setToast] = useState<string | null>(null)

  // In-Gallery Regenerate State
  const [showRegenerateModal, setShowRegenerateModal] = useState(false)
  const [regeneratePrompt, setRegeneratePrompt] = useState('')
  const [isRegenerating, setIsRegenerating] = useState(false)
  const regenerateControllerRef = useRef<AbortController | null>(null)

  // Batch Management & Shift-Selection State
  const [isManageMode, setIsManageMode] = useState(false)
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const lastSelectedIndexRef = useRef<number | null>(null)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [deleteWorkspaceFiles, setDeleteWorkspaceFiles] = useState(true)
  const [isDeleting, setIsDeleting] = useState(false)

  // Clear batch selection and shift anchor when switching tabs, searching, or changing filters
  useEffect(() => {
    setSelectedIds(new Set())
    lastSelectedIndexRef.current = null
  }, [activeTab, search, selectedProvider, selectedRatio, sortBy, onlyCurrentWorkspace])

  const [lang, setLang] = useState<'zh' | 'en'>(() => {
    const active = locale?.getSnapshot?.()?.active
    return active?.startsWith('en') ? 'en' : 'zh'
  })

  useEffect(() => {
    if (!locale?.subscribe) return
    return locale.subscribe(() => {
      const active = locale.getSnapshot?.()?.active
      setLang(active?.startsWith('en') ? 'en' : 'zh')
    })
  }, [locale])

  const dict = lang === 'en' ? DICT.en : DICT.zh
  const t = (key: DictKey, params?: Record<string, string>): string => {
    let text: string = dict[key] || DICT.zh[key] || key
    if (params) {
      for (const [k, v] of Object.entries(params)) {
        text = text.replace(`{${k}}`, v)
      }
    }
    return text
  }

  const showToast = (msg: string) => {
    setToast(msg)
    setTimeout(() => {
      setToast(null)
    }, 2000)
  }

  // Hide chat input composer while browsing gallery/studio
  useEffect(() => {
    const seat = document.querySelector('[data-composer-seat]') as HTMLElement | null
    if (seat) {
      const prevDisplay = seat.style.display
      seat.style.display = 'none'
      return () => {
        seat.style.display = prevDisplay
      }
    }
  }, [])

  // Load items from IndexedDB
  useEffect(() => {
    let active = true
    const load = () => {
      void getGalleryItems().then((res) => {
        if (active) setItems(res)
      })
    }
    load()
    const unsubscribe = subscribeGallery(load)
    return () => {
      active = false
      unsubscribe()
    }
  }, [])

  const [previewLoading, setPreviewLoading] = useState(false)
  const blobCache = useMemo(() => new Map<string, Blob>(), [])
  const abortControllerRef = useRef<AbortController | null>(null)

  // Multi-dimensional filtering and sorting (Provider, Ratio, Search, and Sort)
  const filteredItems = useMemo(() => {
    return items
      .filter((item) => {
        // Tab-level filter (Favorites tab only shows favorited items)
        if (activeTab === 'favorites' && !item.isFavorite) {
          return false
        }
        // Provider filter
        if (selectedProvider !== 'all' && item.provider !== selectedProvider) {
          return false
        }
        // Ratio filter
        if (selectedRatio !== 'all') {
          const ratio = getItemRatio(item)
          if (ratio !== selectedRatio) {
            return false
          }
        }
        // Search filter (Prompt, model, tags, provider)
        if (search.trim().length > 0) {
          const q = search.trim().toLowerCase()
          const matchPrompt = item.prompt?.toLowerCase().includes(q)
          const matchModel = item.model?.toLowerCase().includes(q)
          const matchProvider = item.provider?.toLowerCase().includes(q)
          const matchTags = item.tags?.some((t) => t.toLowerCase().includes(q))
          if (!matchPrompt && !matchModel && !matchProvider && !matchTags) {
            return false
          }
        }
        // Workspace filter
        if (onlyCurrentWorkspace && activeWorkspace) {
          if (!isItemInWorkspace(item, activeWorkspace)) {
            return false
          }
        }
        return true
      })
      .sort((a, b) => {
        if (sortBy === 'oldest') {
          return a.createdAt - b.createdAt
        }
        return b.createdAt - a.createdAt
      })
  }, [items, activeTab, selectedProvider, selectedRatio, search, sortBy, onlyCurrentWorkspace, activeWorkspace])

  // Count of items belonging to the current workspace (before other search/filter criteria)
  const workspaceItemsCount = useMemo(() => {
    if (!activeWorkspace) return items.length
    return items.filter((item) => isItemInWorkspace(item, activeWorkspace)).length
  }, [items, activeWorkspace])

  // Current item index in the active filtered sequence
  const currentPreviewIndex = useMemo(() => {
    if (!previewItem) return -1
    return filteredItems.findIndex((i) => i.id === previewItem.id)
  }, [previewItem, filteredItems])

  const hasPrev = currentPreviewIndex > 0
  const hasNext = currentPreviewIndex >= 0 && currentPreviewIndex < filteredItems.length - 1

  // Safely open or navigate preview item
  const openPreviewItem = (item: GalleryItem, blob?: Blob) => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
      abortControllerRef.current = null
    }
    if (previewUrlRef.current) {
      URL.revokeObjectURL(previewUrlRef.current)
      previewUrlRef.current = null
    }
    setPreviewItem(item)

    if (blob) {
      blobCache.set(item.id, blob)
      const url = URL.createObjectURL(blob)
      previewUrlRef.current = url
      setPreviewBlob(blob)
      setPreviewUrl(url)
      setPreviewLoading(false)
      return
    }

    const cached = blobCache.get(item.id)
    if (cached) {
      const url = URL.createObjectURL(cached)
      previewUrlRef.current = url
      setPreviewBlob(cached)
      setPreviewUrl(url)
      setPreviewLoading(false)
      return
    }

    setPreviewLoading(true)
    setPreviewBlob(null)
    setPreviewUrl(null)

    const controller = new AbortController()
    abortControllerRef.current = controller

    fetchAttachmentBlob(item.attachment)
      .then((fetchedBlob) => {
        if (controller.signal.aborted) return
        blobCache.set(item.id, fetchedBlob)
        const url = URL.createObjectURL(fetchedBlob)
        previewUrlRef.current = url
        setPreviewBlob(fetchedBlob)
        setPreviewUrl(url)
        setPreviewLoading(false)
      })
      .catch((err) => {
        if (controller.signal.aborted) return
        setPreviewLoading(false)
        showToast(t('copyFailed'))
      })
  }

  // Close preview and revoke object URL
  const handleClosePreview = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
      abortControllerRef.current = null
    }
    if (regenerateControllerRef.current) {
      regenerateControllerRef.current.abort()
      regenerateControllerRef.current = null
      setIsRegenerating(false)
    }
    setShowRegenerateModal(false)
    if (previewUrlRef.current) {
      URL.revokeObjectURL(previewUrlRef.current)
      previewUrlRef.current = null
    }
    setPreviewItem(null)
    setPreviewUrl(null)
    setPreviewBlob(null)
    setPreviewLoading(false)
  }

  const goToPrev = () => {
    if (currentPreviewIndex > 0) {
      const prevItem = filteredItems[currentPreviewIndex - 1]
      if (prevItem) openPreviewItem(prevItem)
    }
  }

  const goToNext = () => {
    if (currentPreviewIndex >= 0 && currentPreviewIndex < filteredItems.length - 1) {
      const nextItem = filteredItems[currentPreviewIndex + 1]
      if (nextItem) openPreviewItem(nextItem)
    }
  }

  const handleOpenRegenerate = () => {
    if (!previewItem || isRegenerating) return
    setRegeneratePrompt(previewItem.prompt)
    setShowRegenerateModal(true)
  }

  const handleCancelRegeneratePrompt = () => {
    setShowRegenerateModal(false)
  }

  const handleAbortRegenerating = () => {
    regenerateControllerRef.current?.abort()
    regenerateControllerRef.current = null
    setIsRegenerating(false)
    showToast(t('cancel'))
  }

  const handleConfirmRegenerate = async () => {
    if (!previewItem || isRegenerating || regeneratePrompt.trim().length === 0) return
    setShowRegenerateModal(false)
    setIsRegenerating(true)

    const controller = new AbortController()
    regenerateControllerRef.current = controller

    try {
      const request = conversationRegenerateRequest(
        previewItem,
        regeneratePrompt,
        previewItem.aspectRatio
          ? { ratio: previewItem.aspectRatio, quality: previewItem.imageSize || 'standard' }
          : undefined,
      )
      if (activeWorkspace?.path) {
        request.workspaceRoot = activeWorkspace.path
      }

      const response = await fetch(STUDIO_ROUTE, {
        method: 'POST',
        credentials: 'same-origin',
        signal: controller.signal,
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(request),
      })

      const payload = (await response.json().catch(() => null)) as
        | StudioGenerateResponse
        | { error?: string }
        | null

      if (!response.ok || payload === null || !('attachment' in payload)) {
        throw new Error(
          payload && 'error' in payload && payload.error ? payload.error : t('regenerateFailed'),
        )
      }

      const newItem: GalleryItem = {
        id: String(payload.attachment.attachmentId),
        attachment: payload.attachment,
        prompt: payload.prompt,
        provider: payload.provider,
        model: payload.model,
        createdAt: payload.createdAt,
        aspectRatio: request.ratio,
        imageSize: request.quality,
        output: payload.output,
        ...(payload.savedTo ? { savedTo: payload.savedTo } : {}),
        ...(activeWorkspace?.path ? { workspacePath: activeWorkspace.path } : {}),
        ...(activeWorkspace?.workspaceId ? { workspaceId: activeWorkspace.workspaceId } : {}),
        ...(currentSessionId ? { sessionId: currentSessionId } : {}),
      }

      await saveGalleryItem(newItem)

      if (activeTab !== 'gallery') {
        setActiveTab('gallery')
      }
      if (search.trim().length > 0) {
        setSearch('')
      }

      // Smoothly update preview to the newly created item and load its image blob
      openPreviewItem(newItem)
      showToast(t('regenerateSuccess'))
    } catch (err) {
      if (controller.signal.aborted) return
      showToast(err instanceof Error ? err.message : String(err))
    } finally {
      setIsRegenerating(false)
      regenerateControllerRef.current = null
    }
  }

  // Clean up only on component unmount
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) abortControllerRef.current.abort()
      if (regenerateControllerRef.current) regenerateControllerRef.current.abort()
      if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current)
    }
  }, [])

  // Keyboard navigation: Esc (close modal or preview), ArrowLeft (prev), ArrowRight (next)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return
      }
      if (showRegenerateModal) {
        if (e.key === 'Escape') {
          e.preventDefault()
          setShowRegenerateModal(false)
        }
        return
      }
      if (showDeleteModal) {
        if (e.key === 'Escape' && !isDeleting) {
          e.preventDefault()
          setShowDeleteModal(false)
          if (!isManageMode) setSelectedIds(new Set())
        }
        return
      }
      if (previewItem) {
        if (e.key === 'Escape') {
          handleClosePreview()
        } else if (e.key === 'ArrowLeft' || e.key === 'Left') {
          e.preventDefault()
          goToPrev()
        } else if (e.key === 'ArrowRight' || e.key === 'Right') {
          e.preventDefault()
          goToNext()
        }
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [showRegenerateModal, showDeleteModal, isDeleting, isManageMode, previewItem, currentPreviewIndex, filteredItems])

  // Shift-Click Range Selection & Card Click Handler
  const handleCardClick = (item: GalleryItem, index: number, e: MouseEvent, blob?: Blob) => {
    // If holding Shift, or if currently in manage mode:
    if (e.shiftKey || isManageMode) {
      e.stopPropagation()
      if (!isManageMode) {
        setIsManageMode(true)
      }

      if (e.shiftKey && lastSelectedIndexRef.current !== null) {
        const from = Math.min(lastSelectedIndexRef.current, index)
        const to = Math.max(lastSelectedIndexRef.current, index)
        const rangeItems = filteredItems.slice(from, to + 1)
        setSelectedIds((prev) => {
          const next = new Set(prev)
          for (const r of rangeItems) {
            next.add(r.id)
          }
          return next
        })
      } else {
        setSelectedIds((prev) => {
          const next = new Set(prev)
          if (next.has(item.id)) {
            next.delete(item.id)
          } else {
            next.add(item.id)
          }
          return next
        })
        lastSelectedIndexRef.current = index
      }
      return
    }

    // Normal click -> open preview
    if (blob) {
      openPreviewItem(item, blob)
    }
  }

  // Toggle selection for a specific card index
  const handleToggleSelect = (id: string, index: number, e: MouseEvent) => {
    e.stopPropagation()
    if (!isManageMode) {
      setIsManageMode(true)
    }

    if (e.shiftKey && lastSelectedIndexRef.current !== null) {
      const from = Math.min(lastSelectedIndexRef.current, index)
      const to = Math.max(lastSelectedIndexRef.current, index)
      const rangeItems = filteredItems.slice(from, to + 1)
      setSelectedIds((prev) => {
        const next = new Set(prev)
        for (const r of rangeItems) {
          next.add(r.id)
        }
        return next
      })
    } else {
      setSelectedIds((prev) => {
        const next = new Set(prev)
        if (next.has(id)) {
          next.delete(id)
        } else {
          next.add(id)
        }
        return next
      })
      lastSelectedIndexRef.current = index
    }
  }

  const handleSelectAll = () => {
    setSelectedIds(new Set(filteredItems.map((i) => i.id)))
  }

  const handleInvertSelect = () => {
    setSelectedIds((prev) => {
      const next = new Set<string>()
      for (const item of filteredItems) {
        if (!prev.has(item.id)) {
          next.add(item.id)
        }
      }
      return next
    })
  }

  const handleClearSelect = () => {
    setSelectedIds(new Set())
    lastSelectedIndexRef.current = null
  }

  const handleExitManage = () => {
    setIsManageMode(false)
    setSelectedIds(new Set())
    lastSelectedIndexRef.current = null
  }

  // Request single image deletion through the unified modal
  const requestSingleDelete = (item: GalleryItem, e?: MouseEvent) => {
    if (e) e.stopPropagation()
    setSelectedIds(new Set([item.id]))
    setShowDeleteModal(true)
  }

  const hasWorkspaceFilesToDelete = useMemo(
    () => items.some(i => selectedIds.has(i.id) && typeof i.savedTo === 'string' && i.savedTo.trim().length > 0),
    [items, selectedIds]
  )

  // Execute batch deletion (IndexedDB single transaction + optional workspace disk unlink)
  const handleConfirmBatchDelete = async () => {
    if (selectedIds.size === 0 || isDeleting) return
    setIsDeleting(true)

    const idsToDelete = Array.from(selectedIds)
    const itemsToDelete = items.filter((i) => selectedIds.has(i.id))

    // 1. Collect exact workspace file paths
    const pathsToDelete = itemsToDelete
      .map((i) => i.savedTo)
      .filter((p): p is string => typeof p === 'string' && p.trim().length > 0)

    let deletedFiles = 0

    if (deleteWorkspaceFiles && pathsToDelete.length > 0) {
      try {
        const res = await fetch(DELETE_ROUTE, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            paths: pathsToDelete,
          }),
        })
        if (!res.ok) {
          setIsDeleting(false)
          showToast(`工作区文件删除失败 (${res.status})`)
          return
        }
        const data = (await res.json().catch(() => null)) as {
          ok?: boolean
          deletedCount?: number
          failedFiles?: { path: string; error: string }[]
        } | null
        if (!data || data.ok === false || (Array.isArray(data.failedFiles) && data.failedFiles.length > 0)) {
          setIsDeleting(false)
          const reason = data?.failedFiles?.[0]?.error || '工作区文件未能删除'
          showToast(`删除失败：${reason}`)
          return
        }
        deletedFiles = data.deletedCount ?? 0
      } catch (err) {
        setIsDeleting(false)
        showToast(err instanceof Error ? err.message : '工作区文件删除网络异常')
        return
      }
    }

    // 2. Perform IndexedDB deletion with real error handling
    try {
      await bulkDeleteGalleryItems(idsToDelete)
      for (const item of itemsToDelete) {
        evictAttachmentCache(item.attachment.attachmentId)
      }
    } catch (err) {
      setIsDeleting(false)
      showToast(t('deleteFailedDatabase'))
      return
    }

    // Close lightbox if preview item was deleted
    if (previewItem && selectedIds.has(previewItem.id)) {
      handleClosePreview()
    }

    setIsDeleting(false)
    setShowDeleteModal(false)
    if (isManageMode) {
      handleExitManage()
    } else {
      setSelectedIds(new Set())
      lastSelectedIndexRef.current = null
    }

    if (deletedFiles > 0) {
      showToast(t('batchDeletedWithFilesToast', { count: String(idsToDelete.length), files: String(deletedFiles) }))
    } else {
      showToast(t('batchDeletedToast', { count: String(idsToDelete.length) }))
    }
  }

  return (
    <div className="dsh-ig-gallery-page" data-conversation-composer-overlay="">
      {/* 1. Top Navigation Tabs */}
      <header className="dsh-ig-studio-tabs-bar">
        <button
          type="button"
          className={`dsh-ig-studio-tab-btn ${activeTab === 'gallery' ? 'is-active' : ''}`}
          onClick={() => setActiveTab('gallery')}
        >
          <ImageIcon size={15} />
          <span>{t('tabGallery')}</span>
        </button>

        <button
          type="button"
          className={`dsh-ig-studio-tab-btn ${activeTab === 'studio' ? 'is-active' : ''}`}
          onClick={() => setActiveTab('studio')}
        >
          <SlidersHorizontal size={15} />
          <span>{t('tabStudio')}</span>
        </button>

        <button
          type="button"
          className={`dsh-ig-studio-tab-btn ${activeTab === 'favorites' ? 'is-active' : ''}`}
          onClick={() => setActiveTab('favorites')}
        >
          <Heart size={15} />
          <span>{t('tabFavorites')}</span>
        </button>
      </header>

      {/* 2. Secondary Filter & Search Toolbar (Displayed on Gallery & Favorites) */}
      {(activeTab === 'gallery' || activeTab === 'favorites') && (
        <div className="dsh-ig-studio-toolbar">
          <div className="dsh-ig-studio-toolbar-left">
            {/* Provider Filter */}
            <select
              className="dsh-ig-studio-select"
              value={selectedProvider}
              onChange={(e) => setSelectedProvider(e.target.value)}
            >
              <option value="all">{t('filterAllProviders')}</option>
              <option value="google">{t('filterGoogle')}</option>
              <option value="openai">{t('filterOpenAI')}</option>
              <option value="grok">Grok / xAI</option>
              <option value="seedream">{t('filterSeedream')}</option>
              <option value="dashscope">{t('filterDashScope')}</option>
              <option value="comfyui">{t('filterComfyUI')}</option>
            </select>

            {/* Ratio Filter */}
            <select
              className="dsh-ig-studio-select"
              value={selectedRatio}
              onChange={(e) => setSelectedRatio(e.target.value)}
            >
              <option value="all">{t('filterAllRatios')}</option>
              <option value="1:1">1:1</option>
              <option value="16:9">16:9</option>
              <option value="9:16">9:16</option>
              <option value="4:3">4:3</option>
              <option value="3:4">3:4</option>
              <option value="3:2">3:2</option>
              <option value="2:3">2:3</option>
            </select>

            {/* Prompt & Tag Search Bar */}
            <div className="dsh-ig-studio-search-wrap">
              <Search className="dsh-ig-studio-search-icon" size={14} />
              <input
                type="text"
                className="dsh-ig-studio-search-input"
                placeholder={t('searchPlaceholder')}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            {/* Filter: Current Workspace Only */}
            <label className="dsh-ig-workspace-filter-label" title={t('filterCurrentWorkspaceHint')}>
              <input
                type="checkbox"
                className="dsh-ig-workspace-checkbox"
                checked={onlyCurrentWorkspace}
                onChange={(e) => setOnlyCurrentWorkspace(e.target.checked)}
              />
              <span className="dsh-ig-workspace-filter-text">{t('filterCurrentWorkspace')}</span>
              <span className="dsh-ig-workspace-filter-badge">
                {workspaceItemsCount}/{items.length}
              </span>
            </label>
          </div>

          <div className="dsh-ig-studio-toolbar-right">
            {/* Sort Dropdown */}
            <select
              className="dsh-ig-studio-select dsh-ig-studio-select-sort"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortKey)}
            >
              <option value="newest">{t('sortNewest')}</option>
              <option value="oldest">{t('sortOldest')}</option>
            </select>

            {/* Batch Delete Mode Toggle */}
            <button
              type="button"
              className={`dsh-ig-studio-btn dsh-ig-studio-btn-danger ${isManageMode ? 'is-active' : ''}`}
              title={isManageMode ? t('exitManage') : t('manage')}
              onClick={() => {
                if (isManageMode) {
                  handleExitManage()
                } else {
                  setIsManageMode(true)
                }
              }}
            >
              <Trash2 size={13} />
              <span>{isManageMode ? t('exitManage') : t('manage')}</span>
            </button>
          </div>
        </div>
      )}

      {/* 3. Main View Body */}
      <div className={`dsh-ig-gallery-page-body ${activeTab === 'studio' ? 'is-workbench' : ''}`}>
        {activeTab === 'gallery' || activeTab === 'favorites' ? (
          items.length === 0 ? (
            <div className="dsh-ig-gallery-empty">
              <div className="dsh-ig-gallery-empty-icon">🖼️</div>
              <div className="dsh-ig-gallery-empty-title">{t('emptyTitle')}</div>
              <div className="dsh-ig-gallery-empty-desc">{t('emptyDesc')}</div>
            </div>
          ) : activeTab === 'favorites' && filteredItems.length === 0 && search === '' && selectedProvider === 'all' && selectedRatio === 'all' ? (
            <div className="dsh-ig-gallery-empty">
              <div className="dsh-ig-gallery-empty-icon">🤍</div>
              <div className="dsh-ig-gallery-empty-title">{t('favEmptyTitle')}</div>
              <div className="dsh-ig-gallery-empty-desc">{t('favEmptyDesc')}</div>
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="dsh-ig-gallery-empty">
              <div className="dsh-ig-gallery-empty-icon">🔍</div>
              <div className="dsh-ig-gallery-empty-title">{t('noMatchTitle')}</div>
              <div className="dsh-ig-gallery-empty-desc">{t('noMatchDesc')}</div>
            </div>
          ) : (
            <div className="dsh-ig-gallery-grid">
              {filteredItems.map((item, idx) => (
                <GalleryCard
                  key={item.id}
                  item={item}
                  index={idx}
                  isManageMode={isManageMode}
                  isSelected={selectedIds.has(item.id)}
                  t={t}
                  onClick={(e, blob) => handleCardClick(item, idx, e, blob)}
                  onToggleSelect={(e) => handleToggleSelect(item.id, idx, e)}
                  onRequestDelete={() => requestSingleDelete(item)}
                  onPreview={(blob) => openPreviewItem(item, blob)}
                  onBlobLoaded={(b) => blobCache.set(item.id, b)}
                  onToast={showToast}
                />
              ))}
            </div>
          )
        ) : (
          <StudioView locale={locale} workspace={activeWorkspace} />
        )}
      </div>

      {toast && <div className="dsh-ig-gallery-page-toast">{toast}</div>}

      {/* 4. Floating Batch Action Bar */}
      {(isManageMode || selectedIds.size > 0) && (
        <div className="dsh-ig-batch-bar">
          <div className="dsh-ig-batch-bar-left">
            <span className="dsh-ig-batch-counter">
              {t('selectedCount', { n: String(selectedIds.size) })}
            </span>
            <button
              type="button"
              className="dsh-ig-batch-btn"
              onClick={handleSelectAll}
            >
              {t('selectAll')}
            </button>
            <button
              type="button"
              className="dsh-ig-batch-btn"
              onClick={handleInvertSelect}
            >
              {t('invertSelect')}
            </button>
            {selectedIds.size > 0 && (
              <button
                type="button"
                className="dsh-ig-batch-btn"
                onClick={handleClearSelect}
              >
                {t('clearSelect')}
              </button>
            )}
          </div>

          <div className="dsh-ig-batch-bar-right">
            <button
              type="button"
              className="dsh-ig-batch-btn dsh-ig-batch-btn-danger"
              disabled={selectedIds.size === 0}
              onClick={() => setShowDeleteModal(true)}
            >
              <Trash2 size={13} />
              <span>{t('batchDelete')}{selectedIds.size > 0 ? ` (${selectedIds.size})` : ''}</span>
            </button>

            <button
              type="button"
              className="dsh-ig-batch-btn dsh-ig-batch-btn-exit"
              onClick={handleExitManage}
            >
              {t('exitManage')}
            </button>
          </div>
        </div>
      )}

      {/* 5. Delete Confirmation Modal (Unified for single & batch) */}
      {showDeleteModal && (
        <div
          className="dsh-ig-modal-backdrop"
          onClick={() => {
            if (!isDeleting) {
              setShowDeleteModal(false)
              if (!isManageMode) setSelectedIds(new Set())
            }
          }}
        >
          <div className="dsh-ig-modal-box" onClick={(e) => e.stopPropagation()}>
            <div className="dsh-ig-modal-header">
              <div className="dsh-ig-modal-icon-danger">
                <AlertTriangle size={20} />
              </div>
              <div className="dsh-ig-modal-title">
                {selectedIds.size === 1
                  ? t('batchDeleteTitleSingle')
                  : t('batchDeleteTitle', { count: String(selectedIds.size) })}
              </div>
            </div>

            <div className="dsh-ig-modal-body">
              <p className="dsh-ig-modal-desc">
                {t('batchDeleteDesc')}
              </p>

              {hasWorkspaceFilesToDelete && (
                <label className="dsh-ig-modal-checkbox-label">
                  <input
                    type="checkbox"
                    checked={deleteWorkspaceFiles}
                    onChange={(e) => setDeleteWorkspaceFiles(e.target.checked)}
                    disabled={isDeleting}
                  />
                  <span>{t('deleteWorkspaceFilesOpt')}</span>
                </label>
              )}
            </div>

            <div className="dsh-ig-modal-footer">
              <button
                type="button"
                className="dsh-ig-modal-btn dsh-ig-modal-btn-cancel"
                onClick={() => {
                  setShowDeleteModal(false)
                  if (!isManageMode) setSelectedIds(new Set())
                }}
                disabled={isDeleting}
              >
                {t('cancel')}
              </button>
              <button
                type="button"
                className="dsh-ig-modal-btn dsh-ig-modal-btn-danger"
                onClick={handleConfirmBatchDelete}
                disabled={isDeleting}
              >
                {isDeleting
                  ? '...'
                  : selectedIds.size === 1
                  ? t('confirmDeleteSingle')
                  : t('confirmBatchDelete', { count: String(selectedIds.size) })}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. Regenerate Prompt Modal */}
      {showRegenerateModal && previewItem && (
        <div
          className="dsh-ig-modal-backdrop"
          onClick={handleCancelRegeneratePrompt}
        >
          <div className="dsh-ig-modal-box dsh-ig-regenerate-modal-box" onClick={(e) => e.stopPropagation()}>
            <div className="dsh-ig-modal-header">
              <div className="dsh-ig-regenerate-modal-icon">
                <Sparkles size={18} />
              </div>
              <div className="dsh-ig-regenerate-modal-title-wrap">
                <div className="dsh-ig-modal-title">{t('regenerateTitle')}</div>
                <div className="dsh-ig-regenerate-modal-meta">
                  <span className="dsh-ig-tag">{previewItem.provider}</span>
                  {previewItem.model && <span className="dsh-ig-tag dsh-ig-tag-model">{previewItem.model}</span>}
                  <span className="dsh-ig-tag">{formatCardMeta(previewItem)}</span>
                </div>
              </div>
            </div>

            <div className="dsh-ig-modal-body">
              <p className="dsh-ig-modal-desc">{t('regenerateHint')}</p>
              <textarea
                className="dsh-ig-regenerate-modal-textarea"
                value={regeneratePrompt}
                onChange={(e) => setRegeneratePrompt(e.target.value)}
                placeholder={t('prompt')}
                rows={4}
                autoFocus
              />
            </div>

            <div className="dsh-ig-modal-footer">
              <button
                type="button"
                className="dsh-ig-modal-btn dsh-ig-modal-btn-cancel"
                onClick={handleCancelRegeneratePrompt}
              >
                {t('cancel')}
              </button>
              <button
                type="button"
                className="dsh-ig-modal-btn dsh-ig-modal-btn-primary"
                onClick={handleConfirmRegenerate}
                disabled={regeneratePrompt.trim().length === 0}
              >
                <Sparkles size={14} />
                <span>{t('confirmRegenerate')}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. Lightbox Preview Modal */}
      {previewItem && (
        <div
          className="dsh-ig-lightbox-backdrop"
          onClick={handleClosePreview}
        >
          {/* Top Bar: Info, Index Counter & Close */}
          <div
            className="dsh-ig-lightbox-topbar"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="dsh-ig-lightbox-meta">
              <span className="dsh-ig-tag">{previewItem.provider}</span>
              {previewItem.model ? (
                <span className="dsh-ig-tag dsh-ig-tag-model">{previewItem.model}</span>
              ) : null}
              {currentPreviewIndex >= 0 && (
                <span className="dsh-ig-lightbox-counter">
                  {currentPreviewIndex + 1} / {filteredItems.length}
                </span>
              )}
            </div>
            <button
              type="button"
              className="dsh-ig-lightbox-close-btn"
              title={t('close')}
              onClick={handleClosePreview}
            >
              <X size={18} />
            </button>
          </div>

          {/* Floating Prev Button (Left) */}
          <button
            type="button"
            className="dsh-ig-lightbox-nav-btn dsh-ig-lightbox-nav-prev"
            title={t('prevImage')}
            disabled={!hasPrev}
            onClick={(e) => {
              e.stopPropagation()
              goToPrev()
            }}
          >
            <ChevronLeft size={24} />
          </button>

          {/* Floating Next Button (Right) */}
          <button
            type="button"
            className="dsh-ig-lightbox-nav-btn dsh-ig-lightbox-nav-next"
            title={t('nextImage')}
            disabled={!hasNext}
            onClick={(e) => {
              e.stopPropagation()
              goToNext()
            }}
          >
            <ChevronRight size={24} />
          </button>

          {/* Centered Image / Loading state */}
          <div className="dsh-ig-lightbox-img-wrap" onClick={(e) => e.stopPropagation()}>
            {previewLoading ? (
              <div className="dsh-ig-lightbox-loading">
                <div className="dsh-ig-lightbox-spinner" />
              </div>
            ) : previewUrl ? (
              <img
                className="dsh-ig-lightbox-img"
                src={previewUrl}
                alt={previewItem.prompt}
              />
            ) : null}
          </div>

          {/* Bottom Floating Pill Bar: Prompt & Actions */}
          <div
            className="dsh-ig-lightbox-bottombar"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="dsh-ig-lightbox-prompt-text" title={previewItem.prompt}>
              {previewItem.prompt}
            </div>
            <div className="dsh-ig-lightbox-actions">
              <button
                type="button"
                className="dsh-ig-lightbox-btn"
                title={t('copyPpt')}
                onClick={async () => {
                  await navigator.clipboard.writeText(previewItem.prompt)
                  showToast(t('copiedPrompt'))
                }}
              >
                <FileText size={14} />
                <span>{t('copyPpt')}</span>
              </button>

              <button
                type="button"
                className="dsh-ig-lightbox-btn"
                title={t('copyImg')}
                onClick={async () => {
                  if (!previewBlob) return
                  const ok = await copyImageBlob(previewBlob)
                  showToast(ok ? t('copiedImage') : t('copyFailed'))
                }}
              >
                <Copy size={14} />
                <span>{t('copyImg')}</span>
              </button>

              <button
                type="button"
                className="dsh-ig-lightbox-btn"
                title={t('download')}
                onClick={() => {
                  if (!previewUrl) return
                  const a = document.createElement('a')
                  a.href = previewUrl
                  a.download = `dsh-${previewItem.provider}-${previewItem.id}.png`
                  document.body.appendChild(a)
                  a.click()
                  document.body.removeChild(a)
                }}
              >
                <Download size={14} />
                <span>{t('download')}</span>
              </button>

              <button
                type="button"
                className="dsh-ig-lightbox-btn dsh-ig-lightbox-btn-regenerate"
                title={t('regenerate')}
                disabled={isRegenerating}
                onClick={handleOpenRegenerate}
              >
                <Sparkles size={14} />
                <span>{t('regenerate')}</span>
              </button>

              {isRegenerating && (
                <div className="dsh-ig-lightbox-generating-indicator">
                  <div className="dsh-ig-lightbox-spinner-sm" />
                  <span>{t('regenerating')}</span>
                  <button
                    type="button"
                    className="dsh-ig-lightbox-abort-btn"
                    onClick={handleAbortRegenerating}
                  >
                    {t('cancel')}
                  </button>
                </div>
              )}

              <button
                type="button"
                className="dsh-ig-lightbox-btn dsh-ig-lightbox-btn-danger"
                title={t('delete')}
                onClick={() => {
                  if (previewItem) {
                    requestSingleDelete(previewItem)
                  }
                }}
              >
                <Trash2 size={14} />
                <span>{t('delete')}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

interface GalleryCardProps {
  item: GalleryItem
  index: number
  isManageMode: boolean
  isSelected: boolean
  t: (key: DictKey, params?: Record<string, string>) => string
  onClick: (e: MouseEvent, blob?: Blob) => void
  onToggleSelect: (e: MouseEvent) => void
  onRequestDelete: () => void
  onPreview: (blob: Blob) => void
  onBlobLoaded?: (blob: Blob) => void
  onToast: (msg: string) => void
}

const GalleryCard: FC<GalleryCardProps> = ({
  item,
  index: _index,
  isManageMode,
  isSelected,
  t,
  onClick,
  onToggleSelect,
  onRequestDelete,
  onPreview: _onPreview,
  onBlobLoaded,
  onToast,
}) => {
  const [url, setUrl] = useState<string>()
  const [blob, setBlob] = useState<Blob>()
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string>()

  useEffect(() => {
    const controller = new AbortController()
    let objectUrl: string | undefined

    void fetch(IMAGE_ROUTE, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ attachment: item.attachment }),
    })
      .then(async (response) => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`)
        const resBlob = await response.blob()
        if (controller.signal.aborted) return
        setBlob(resBlob)
        onBlobLoaded?.(resBlob)
        objectUrl = URL.createObjectURL(resBlob)
        setUrl(objectUrl)
        setLoading(false)
      })
      .catch((err) => {
        if (!controller.signal.aborted) {
          setError(err instanceof Error ? err.message : String(err))
          setLoading(false)
        }
      })

    return () => {
      controller.abort()
      if (objectUrl) URL.revokeObjectURL(objectUrl)
    }
  }, [item.attachment])

  const copyPrompt = async (e: MouseEvent) => {
    e.stopPropagation()
    try {
      await navigator.clipboard.writeText(item.prompt)
      onToast(t('copiedPrompt'))
    } catch {
      onToast(t('copyFailed'))
    }
  }

  const copyImage = async (e: MouseEvent) => {
    e.stopPropagation()
    if (!blob) return
    const ok = await copyImageBlob(blob)
    onToast(ok ? t('copiedImage') : t('copyFailed'))
  }

  const downloadImage = (e: MouseEvent) => {
    e.stopPropagation()
    if (!url) return
    const a = document.createElement('a')
    a.href = url
    a.download = `dsh-${item.provider}-${item.id}.png`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
  }

  const toggleFavorite = async (e: MouseEvent) => {
    e.stopPropagation()
    const nextStatus = await toggleFavoriteGalleryItem(item.id)
    onToast(nextStatus ? t('favoriteAdded') : t('favoriteRemoved'))
  }

  // Label for top badge: show model or fallback to provider
  const badgeLabel = item.model || item.provider

  return (
    <div
      className={`dsh-ig-gallery-card ${isSelected ? 'is-selected' : ''} ${isManageMode ? 'is-manage-mode' : ''}`}
      onClick={(e) => onClick(e, blob)}
    >
      {/* Upper media container */}
      <div className="dsh-ig-gallery-card-media">
        {/* Selection Checkbox (Top Left) */}
        <button
          type="button"
          className={`dsh-ig-card-checkbox ${isSelected ? 'is-checked' : ''}`}
          title={isSelected ? t('clearSelect') : t('manage')}
          onClick={onToggleSelect}
        >
          {isSelected && <Check size={11} strokeWidth={3} />}
        </button>

        {loading && <div className="dsh-ig-gallery-card-loading">...</div>}
        {error && <div className="dsh-ig-gallery-card-error">⚠️ {error}</div>}
        {url && (
          <img
            className="dsh-ig-gallery-card-img"
            src={url}
            alt={item.prompt}
            loading="lazy"
          />
        )}

        {/* Hover quick action toolbar */}
        <div className="dsh-ig-card-toolbar">
          <button
            type="button"
            className="dsh-ig-tool-btn"
            title={t('copyImg')}
            onClick={(e) => {
              void copyImage(e)
            }}
          >
            <Copy size={13} />
          </button>
          <button
            type="button"
            className="dsh-ig-tool-btn"
            title={t('download')}
            onClick={downloadImage}
          >
            <Download size={13} />
          </button>
          <button
            type="button"
            className="dsh-ig-tool-btn"
            title={t('copyPpt')}
            onClick={(e) => {
              void copyPrompt(e)
            }}
          >
            <FileText size={13} />
          </button>
          <button
            type="button"
            className="dsh-ig-tool-btn dsh-ig-tool-btn-danger"
            title={t('delete')}
            onClick={(e) => {
              e.stopPropagation()
              onRequestDelete()
            }}
          >
            <Trash2 size={13} />
          </button>
        </div>
      </div>

      {/* Lower metadata container aligned with mockup */}
      <div className="dsh-ig-gallery-card-meta">
        {/* Top badge */}
        <div className="dsh-ig-card-badge-row">
          <span className="dsh-ig-card-badge" title={badgeLabel}>
            {badgeLabel}
          </span>
        </div>

        {/* Prompt single-line title */}
        <div className="dsh-ig-gallery-card-prompt-line" title={item.prompt}>
          {item.prompt}
        </div>

        {/* Bottom meta row: dimension/ratio + relative time + heart favorite */}
        <div className="dsh-ig-card-footer-row">
          <span className="dsh-ig-card-meta-text">
            {formatCardMeta(item)} | {formatRelativeTime(item.createdAt, t)}
          </span>

          <button
            type="button"
            className={`dsh-ig-card-fav-btn ${item.isFavorite ? 'is-favorited' : ''}`}
            title={item.isFavorite ? t('favoriteRemoved') : t('favoriteAdded')}
            onClick={(e) => {
              void toggleFavorite(e)
            }}
          >
            <Heart
              size={15}
              fill={item.isFavorite ? 'currentColor' : 'none'}
            />
          </button>
        </div>
      </div>
    </div>
  )
}

export { copyImageBlob } from './browser-image-utils.js'
