// Adapted from dsh-image-gen src/openai-compatible.ts at 0a1bb6d4ad0adb0e676a1193d098bd4c4589d167.
// Copyright (c) 2026 dsh-image-gen contributors. MIT; see ../../LICENSE.
import { lookup } from 'node:dns/promises'
import { isIP } from 'node:net'
import { request as httpsRequest } from 'node:https'
import { Readable } from 'node:stream'
import { imageStyleSettings } from './scene-image-style.js'
import { channelSettings, imageChannelRequest, channelImageResult } from './scene-image-channels.js'
import { sceneImageFromZip } from './scene-image-zip.js'
import { generateComfyImage } from './scene-image-comfy.js'
import { redactSceneDiagnostic } from './redact.js'
import { imageNetworkCodes } from './scene-image-transport.js'

export function imageSettings(value = {}) {
  return {
    ...channelSettings(value),
    enabled: value.enabled === true,
    style: imageStyleSettings(value.style)
  }
}

async function boundedBytes(response, limit) {
  if (Number(response.headers.get('content-length')) > limit) { await response.body?.cancel(); throw new Error('生图响应过大') }
  const chunks = []
  let length = 0
  if (response.body) for await (const chunk of response.body) {
    length += chunk.length
    if (length > limit) throw new Error('生图响应过大')
    chunks.push(Buffer.from(chunk))
  }
  return Buffer.concat(chunks)
}

function imageBytes(data, maxBytes) {
  if (!data.length || data.length > maxBytes) throw new Error('图片为空或超过大小限制')
  let mediaType
  if (data.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) mediaType = 'image/png'
  else if (data[0] === 255 && data[1] === 216 && data[2] === 255) mediaType = 'image/jpeg'
  else if (/^GIF8[79]a$/.test(data.subarray(0, 6).toString())) mediaType = 'image/gif'
  else if (data.subarray(0, 4).toString() === 'RIFF' && data.subarray(8, 12).toString() === 'WEBP') mediaType = 'image/webp'
  if (!mediaType) throw new Error('服务没有返回支持的图片格式')
  return { data, mediaType }
}

function privateAddress(address) {
  if (isIP(address) !== 4) return true // returned-download IPv6 conservatively excluded in v1
  const [a, b] = address.split('.').map(Number)
  return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127)
}

/** Never send generation credentials to a provider-returned image URL. */
export async function validateImageDownload(url, baseURL) {
  const target = new URL(url)
  if (!['https:', 'http:'].includes(target.protocol) || target.username || target.password) throw new Error('图片下载地址不合法')
  // Explicitly configured self-hosted providers may return their own private origin.
  if (target.origin === new URL(baseURL).origin) return target.href
  if (target.protocol !== 'https:') throw new Error('第三方图片下载地址必须使用 HTTPS')
  const addresses = await lookup(target.hostname, { all: true })
  if (!addresses.length || addresses.some(item => privateAddress(item.address))) throw new Error('拒绝第三方图片的内网下载地址')
  return target.href
}

// Validate the DNS answer used by the socket itself, not just a preliminary
// lookup that a rebinding domain could change before fetch connects.
function downloadPublicImage(url, signal) {
  return new Promise((resolve, reject) => {
    const request = httpsRequest(url, { signal, lookup(host, options, callback) {
      lookup(host, { all: true }).then(addresses => {
        if (!addresses.length || addresses.some(item => privateAddress(item.address))) return callback(new Error('拒绝第三方图片的内网下载地址'))
        const first = addresses[0]
        if (options.all) callback(null, [first])
        else callback(null, first.address, first.family)
      }, callback)
    } }, response => {
      if (response.statusCode !== 200) { response.resume(); reject(new Error('图片下载失败（HTTP ' + response.statusCode + '）')); return }
      const headers = new Headers()
      for (const [key, value] of Object.entries(response.headers)) if (value !== undefined) headers.set(key, Array.isArray(value) ? value.join(', ') : value)
      resolve(new Response(Readable.toWeb(response), { status: 200, headers }))
    })
    request.on('error', reject)
    request.end()
  })
}

export async function generateSceneImage(input, deps = {}) {
  let outcome = 'not_requested'
  const request = deps.fetch || fetch
  let sequence = 0
  async function emit(event) {
    try { await input.onProviderRequest?.(redactSceneDiagnostic(event, [input.apiKey])) }
    catch { /* Diagnostic errors must not alter dispatch, acceptance or retries. */ }
  }
  async function observedRequest(url, init, send = request) {
    const requestId = ++sequence, method = init?.method || 'GET'
    let body
    if (typeof init?.body === 'string') { try { body = JSON.parse(init.body) } catch { body = '[non-JSON request omitted]' } }
    await emit({ requestId, at: Date.now(), phase: 'dispatch', method, url: String(url), ...(body ? { body } : {}) })
    if (method === 'POST') outcome = 'unconfirmed'
    const began = Date.now()
    try {
      const response = await send(url, init)
      await emit({ requestId, at: Date.now(), phase: 'response', method, status: response.status, durationMs: Date.now() - began,
        providerRequestId: response.headers?.get?.('x-request-id') || response.headers?.get?.('request-id') || null })
      return response
    } catch (error) {
      await emit({ requestId, at: Date.now(), phase: 'transport-error', method, durationMs: Date.now() - began, error: String(error.message || error), networkCodes: imageNetworkCodes(error) })
      throw error
    }
  }
  try {
    return await requestSceneImage(input, { ...deps, fetch: observedRequest,
      publicDownload: (url, signal) => observedRequest(url, { signal }, (address, options) => downloadPublicImage(address, options.signal)), usePublicDownload: !deps.fetch })
  } catch (error) {
    error.imageOutcome ||= outcome
    throw error
  }
}

const NOVELAI_BUSY_RETRIES = 3
// Exponential backoff with jitter, never shorter than the server's Retry-After, capped at 30s.
function novelaiRetryDelay(response, attempt, baseMs = 2000) {
  const header = Number(response.headers?.get?.('retry-after'))
  const backoff = baseMs * 2 ** attempt * (0.5 + Math.random() / 2)
  return Math.min(30000, Math.max(Number.isFinite(header) ? header * 1000 : 0, backoff))
}
function abortableDelay(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(signal.reason)
    const timer = setTimeout(() => { signal?.removeEventListener('abort', abort); resolve() }, ms)
    function abort() { clearTimeout(timer); reject(signal.reason) }
    signal?.addEventListener('abort', abort, { once: true })
  })
}

async function requestSceneImage(input, deps) {
  if (input.provider === 'comfyui') return generateComfyImage(input, { ...deps, readBytes: boundedBytes, decodeImage: imageBytes })
  const request = deps.fetch || fetch
  const maxBytes = input.maxBytes || 20 * 1024 * 1024
  const spec = imageChannelRequest(input)
  const send = () => request(spec.url, {
    method: 'POST', redirect: 'error', signal: input.signal,
    headers: spec.headers,
    body: JSON.stringify(spec.body)
  })
  let response = await send()
  // NovelAI answers 429 when the account already has a generation running
  // (e.g. in its own web UI) and same-protocol custom endpoints pass it through: the job
  // was refused before generating, so waiting and resending cannot double-charge.
  // Other channels and 5xx stay unretried; they do not prove the job was skipped.
  for (let attempt = 0; input.provider === 'novelai' && response.status === 429 && attempt < NOVELAI_BUSY_RETRIES; attempt++) {
    await response.body?.cancel()
    await abortableDelay(novelaiRetryDelay(response, attempt, deps.retryBaseMs), input.signal)
    response = await send()
  }
  // Keep bounded, useful error fields; never forward arbitrary bodies or secrets.
  if (!response.ok) {
    let detail = {}
    try {
      const payload = JSON.parse((await boundedBytes(response, 8192)).toString('utf8'))
      const value = payload?.error && typeof payload.error === 'object' ? payload.error : payload
      const message = typeof payload?.error === 'string' ? payload.error : value?.message || (typeof payload?.detail === 'string' ? payload.detail : '')
      const safe = value => redactSceneDiagnostic(value, [input.apiKey]).replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, 400)
      detail = Object.fromEntries(Object.entries({ message, code: value?.code, param: value?.param }).filter(([, item]) => typeof item === 'string').map(([key, item]) => [key, safe(item)]))
    } catch { /* A malformed/oversized error must not hide the actual HTTP status. */ }
    const error = new Error('生图服务请求失败（HTTP ' + response.status + '）' + (detail.message ? '：' + detail.message : '') + (detail.param ? '（字段：' + detail.param + '）' : ''))
    // Many custom endpoints serve image models only through chat/completions.
    if (response.status === 404 && input.provider === 'openai') error.message += '。该地址没有 OpenAI 图片接口；如果它提供的是 NovelAI 图片，请改选「NovelAI（官方或自定义渠道）」并添加接入点'
    error.imageFailure = { httpStatus: response.status, ...detail }
    // A proxy timeout/5xx or 429 does not establish whether the upstream took
    // the job. Only explicit validation/auth rejection is safe for ordinary retry.
    if ([400, 401, 402, 403, 404, 422].includes(response.status)) error.imageOutcome = 'rejected'
    throw error
  }
  if (input.provider === 'novelai' && spec.body.messages === undefined) {
    const archive = await boundedBytes(response, maxBytes + 65536)
    // An OpenAI-style custom endpoint answers this native path with its own web page:
    // nothing reached an image service, so nothing was charged.
    if (/^\s*</.test(archive.subarray(0, 64).toString('utf8'))) {
      const error = new Error('该地址返回的是网页，不是 NovelAI 图片。如果这个地址用对话接口出图，请把这个接入点的「接口格式」改成「对话格式」。')
      error.imageOutcome = 'rejected'
      throw error
    }
    return { ...imageBytes(sceneImageFromZip(archive, maxBytes), maxBytes), metadata: { seed: spec.body.parameters.seed, model: spec.body.model, request: spec.body } }
  }
  let payload
  try { payload = JSON.parse((await boundedBytes(response, Math.ceil(maxBytes * 1.4) + 4096)).toString('utf8')) }
  catch (error) { if (error.message === '生图响应过大') throw error; throw new Error('生图服务返回的不是有效 JSON') }
  const item = channelImageResult(input.provider, payload)
  if (!item || typeof item !== 'object') throw new Error('生图服务没有返回图片')
  // Keep only useful reported facts, never echo a server's full info blob.
  let metadata
  if (input.provider === 'webui') {
    try {
      const info = typeof payload.info === 'string' ? JSON.parse(payload.info) : payload.info
      const values = {}
      if (Number.isSafeInteger(info?.seed) && info.seed >= 0) values.seed = info.seed
      if (typeof info?.sd_model_name === 'string' && info.sd_model_name.length <= 200) values.model = info.sd_model_name
      if (typeof info?.sd_model_hash === 'string' && /^[a-f0-9]{8,64}$/i.test(info.sd_model_hash)) values.modelHash = info.sd_model_hash
      if (Object.keys(values).length) metadata = values
    } catch { /* Missing/malformed optional metadata cannot discard a valid image. */ }
  }
  const controls = Object.fromEntries(['negative_prompt', 'steps', 'cfg_scale'].filter(key => spec.body[key] !== undefined).map(key => [key, spec.body[key]]))
  if (spec.body.parameters?.negative_prompt !== undefined) controls.negative_prompt = spec.body.parameters.negative_prompt
  if (Object.keys(controls).length) metadata = { ...metadata, generationParameters: controls }
  const finish = data => ({ ...imageBytes(data, maxBytes), ...(metadata ? { metadata } : {}) })
  const inline = typeof item.b64_json === 'string' && item.b64_json.trim().length > 0 ? item.b64_json : /^data:image\/[\w.+-]+;base64,/i.test(item.url || '') ? item.url.split(',')[1] : null
  if (inline !== null) {
    const clean = inline.replace(/\s+/g, '')
    if (!/^[A-Za-z0-9+/]+={0,2}$/.test(clean)) throw new Error('图片 base64 数据不合法')
    return finish(Buffer.from(clean, 'base64'))
  }
  if (typeof item.url !== 'string') throw new Error('生图服务没有返回图片数据')
  const baseURL = channelSettings(input).baseURL
  const url = await (deps.validateDownload || validateImageDownload)(item.url, baseURL)
  const downloaded = deps.usePublicDownload && new URL(url).origin !== new URL(baseURL).origin
    ? await deps.publicDownload(url, input.signal)
    : await request(url, { redirect: 'error', signal: input.signal })
  if (!downloaded.ok) { await downloaded.body?.cancel(); throw new Error('图片下载失败（HTTP ' + downloaded.status + '）') }
  return finish(await boundedBytes(downloaded, maxBytes))
}
