#!/usr/bin/env bash
set -euo pipefail

DSH_ROOT="${DSH_HOME:-${HOME}/.dsh}"
APP_DIR="${DSH_TAVERN_SOURCE_ROOT:-${DSH_TAVERN_ANDROID_APP_DIR:-${DSH_ROOT}/apps/dsh-tavern}}"
DEFAULT_REPOSITORY="https://github.com/flizzywine/dsh-tavern.git"
REPOSITORY="${DSH_TAVERN_REPOSITORY:-${DEFAULT_REPOSITORY}}"
# Follows the main branch, same as install.sh.
BRANCH="${DSH_TAVERN_BRANCH:-main}"
DEFAULT_TARBALL_URL="https://codeload.github.com/flizzywine/dsh-tavern/tar.gz/refs/heads/main"
TARBALL_URL="${DSH_TAVERN_TARBALL_URL:-${DEFAULT_TARBALL_URL}}"
SOURCE_MARKER=".dsh-tavern-tarball-source"
OFFLINE_TARBALL="/root/tavern-offline.tar"
OFFLINE_DIR="${DSH_ROOT}/tavern-offline"
TEMP_ROOT=""
SOURCE_BACKUP=""
SOURCE_SWAPPED=0

fail() {
  printf 'DSH Tavern 安装失败：%s\n' "$1" >&2
  exit 1
}

# 全程带步骤序号与耗时，日志会原样落到 APK 的安装日志里，方便判断卡在哪一步。
START_TIME=$(date +%s)
STEP=0
stage() {
  STEP=$((STEP + 1))
  printf '\n== [步骤 %s] %s（已用 %ss）==\n' "${STEP}" "$*" "$(( $(date +%s) - START_TIME ))"
}
info() { printf '   %s\n' "$*"; }

require_command() {
  command -v "$1" >/dev/null 2>&1 || fail "缺少命令 $1，请先完成 DSHA 的基础安装。"
}

cleanup() {
  if [ -n "${TEMP_ROOT}" ] && [ -d "${TEMP_ROOT}" ]; then
    rm -r -- "${TEMP_ROOT}"
  fi
}
trap cleanup EXIT

prepare_temp_root() {
  if [ -z "${TEMP_ROOT}" ]; then
    mkdir -p "$(dirname -- "${APP_DIR}")"
    TEMP_ROOT="$(mktemp -d "$(dirname -- "${APP_DIR}")/.dsh-tavern-download.XXXXXX")"
  fi
}

verify_source() {
  local source="$1"
  [ -f "${source}/package.json" ] || fail "下载内容不完整，缺少 package.json。"
  [ -f "${source}/bin/dsh-tavern.mjs" ] || fail "下载内容不完整，缺少 bin/dsh-tavern.mjs。"
  [ -f "${source}/android/install.sh" ] || fail "下载内容不完整，缺少 android/install.sh。"
}

# APK 自带的离线包：{ revision, source/, store/, cache/, registry, pnpm-runtime/ }。
# 首装完全离线；解包一次后保留在数据目录，失败重试时不必再解。
OFFLINE_READY=0
prepare_offline_bundle() {
  [ "${OFFLINE_READY}" -eq 1 ] && return 0
  if [ -f "${OFFLINE_DIR}/revision" ] && [ -d "${OFFLINE_DIR}/store" ] && [ -d "${OFFLINE_DIR}/source" ]; then
    # 新 APK 可能带更新的源码/缓存；只按目录存在复用会把旧 store 和缺失的
    # metadata 缓存一直留着，首装继续退回联网。比对包内 revision，不同就重解。
    local bundled_revision=""
    if [ -f "${OFFLINE_TARBALL}" ]; then
      bundled_revision="$(tar -xzOf "${OFFLINE_TARBALL}" revision 2>/dev/null || true)"
    fi
    if [ -z "${bundled_revision}" ] || [ "$(cat "${OFFLINE_DIR}/revision")" = "${bundled_revision}" ]; then
      info "复用已解包的离线依赖：${OFFLINE_DIR}"
      OFFLINE_READY=1
      return 0
    fi
    info "内置依赖包版本变化（$(cat "${OFFLINE_DIR}/revision" 2>/dev/null) → ${bundled_revision}），重新解包"
    rm -rf -- "${OFFLINE_DIR}" 2>/dev/null || true
  fi
  [ -f "${OFFLINE_TARBALL}" ] || return 1
  stage "解开 APK 内置依赖包（$(du -h "${OFFLINE_TARBALL}" 2>/dev/null | cut -f1)，约 20-60s）"
  info "源文件：${OFFLINE_TARBALL}"
  mkdir -p "${OFFLINE_DIR}"
  # 分步解，日志里能看到每个目录的落盘时间，便于判断是慢还是卡死。
  tar -xzf "${OFFLINE_TARBALL}" -C "${OFFLINE_DIR}" \
    || { info '离线包解压失败，改用联网安装。'; return 1; }
  if [ ! -f "${OFFLINE_DIR}/revision" ] || [ ! -d "${OFFLINE_DIR}/store" ] || [ ! -d "${OFFLINE_DIR}/source" ]; then
    info '离线包内容不完整，改用联网安装。'
    return 1
  fi
  info "离线包就绪：源码 $(find "${OFFLINE_DIR}/source" -type f | wc -l) 个文件，store $(du -sh "${OFFLINE_DIR}/store" 2>/dev/null | cut -f1)"
  # 已解包则可以删掉压缩包，省出与包体相当的空间。
  rm -f -- "${OFFLINE_TARBALL}" 2>/dev/null || true
  OFFLINE_READY=1
  return 0
}

install_from_offline() {
  prepare_offline_bundle || return 1
  stage "使用 APK 内置源码快照（$(cat "${OFFLINE_DIR}/revision")）"
  prepare_temp_root
  # 复制而不是移动：离线目录保持完整，安装失败重试时不必重新解包。
  local candidate="${TEMP_ROOT}/offline-source"
  cp -a "${OFFLINE_DIR}/source" "${candidate}" || { info '复制内置源码失败，改用联网安装。'; return 1; }
  verify_source "${candidate}"
  info "源码已就绪：$(find "${candidate}" -type f | wc -l) 个文件"
  # 快照没有 .git：写 tarball 标记，之后的更新走官方压缩包覆盖，行为与既有压缩包安装一致。
  printf '%s\n' "${DEFAULT_TARBALL_URL}" >"${candidate}/${SOURCE_MARKER}"
  replace_source "${candidate}"
  return 0
}

download_file() {
  local url="$1"
  local destination="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 2 --connect-timeout 20 -o "${destination}" "${url}"
    return
  fi
  printf '未检测到 curl，正在通过 Node.js 下载……\n'
  node - "${url}" "${destination}" <<'NODE'
const fs = require('node:fs')
const [url, destination] = process.argv.slice(2)
fetch(url, { redirect: 'follow' })
  .then(response => {
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    return response.arrayBuffer()
  })
  .then(body => fs.writeFileSync(destination, Buffer.from(body)))
  .catch(error => {
    console.error(`Node.js 下载失败：${error.message}`)
    process.exitCode = 1
  })
NODE
}

replace_source() {
  local candidate="$1"
  verify_source "${candidate}"
  if [ -d "${APP_DIR}/data" ] && [ ! -e "${candidate}/data" ]; then
    cp -a "${APP_DIR}/data" "${candidate}/data"
  fi
  if [ -e "${APP_DIR}" ]; then
    SOURCE_BACKUP="${TEMP_ROOT}/previous-source"
    mv -- "${APP_DIR}" "${SOURCE_BACKUP}"
  fi
  if ! mv -- "${candidate}" "${APP_DIR}"; then
    if [ -n "${SOURCE_BACKUP}" ] && [ -d "${SOURCE_BACKUP}" ]; then mv -- "${SOURCE_BACKUP}" "${APP_DIR}"; fi
    fail "无法替换源码目录，旧版本已恢复。"
  fi
  SOURCE_SWAPPED=1
}

rollback_source() {
  [ "${SOURCE_SWAPPED}" -eq 1 ] || return 0
  # Never move code out from underneath a still-running service. Keep both
  # versions for repair if shutdown failed or the PID record cannot be trusted.
  if ! node - "${DSH_ROOT}/logs/tavern.pid.json" <<'NODE'
const fs = require('node:fs')
try {
  const record = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'))
  if (!Number.isInteger(record.pid) || record.pid <= 0) process.exit(1)
  try { process.kill(record.pid, 0); process.exit(1) }
  catch (error) { if (error.code !== 'ESRCH') process.exit(1) }
} catch (error) { if (error.code !== 'ENOENT') process.exit(1) }
NODE
  then
    printf '服务可能仍在运行，保留源码和备份：%s\n' "${TEMP_ROOT}" >&2
    TEMP_ROOT=""
    return 1
  fi
  if [ -e "${APP_DIR}" ]; then mv -- "${APP_DIR}" "${TEMP_ROOT}/failed-source"; fi
  if [ -n "${SOURCE_BACKUP}" ] && [ -d "${SOURCE_BACKUP}" ]; then mv -- "${SOURCE_BACKUP}" "${APP_DIR}"; fi
  SOURCE_SWAPPED=0
}

install_from_tarball() {
  require_command tar
  prepare_temp_root
  local archive="${TEMP_ROOT}/dsh-tavern.tar.gz"
  local candidate="${TEMP_ROOT}/tarball-source"
  printf 'Git 下载失败，正在改用 GitHub 压缩包……\n'
  download_file "${TARBALL_URL}" "${archive}" || fail "Git 与压缩包下载均失败，请检查网络后重试。"
  mkdir -p "${candidate}"
  tar -xzf "${archive}" -C "${candidate}" --strip-components=1 --exclude='*/docs' --exclude='*/docs/*' || fail "压缩包无法解压，旧版本未被修改。"
  verify_source "${candidate}"
  printf '%s\n' "${TARBALL_URL}" > "${candidate}/${SOURCE_MARKER}"
  replace_source "${candidate}"
}

install_source() {
  prepare_temp_root
  if command -v git >/dev/null 2>&1; then
    local candidate="${TEMP_ROOT}/git-source"
    local attempt
    for attempt in 1 2 3; do
      printf '正在通过 Git 下载 DSH Tavern（第 %s/3 次）……\n' "${attempt}"
      if git clone --filter=blob:none --no-checkout --branch "${BRANCH}" --single-branch "${REPOSITORY}" "${candidate}" \
        && git -C "${candidate}" sparse-checkout set --no-cone '/*' '!**/docs/' \
        && git -C "${candidate}" checkout "${BRANCH}"; then
        replace_source "${candidate}"
        return
      fi
      # A failed clone or checkout can leave a directory that blocks the next clone.
      if [ -e "${candidate}" ]; then rm -rf -- "${candidate}"; fi
      if [ "${attempt}" -lt 3 ]; then sleep 2; fi
    done
  else
    printf '未检测到 Git，直接使用 GitHub 压缩包。\n'
  fi
  install_from_tarball
}

is_disposable_upgrade_residue() {
  [ -d "${APP_DIR}" ] || return 1
  [ -z "$(find "${APP_DIR}" -mindepth 1 ! -type d ! -type l -print -quit 2>/dev/null)" ]
}

update_source() {
  if [ -d "${APP_DIR}/.git" ]; then
    require_command git
    if ! git -C "${APP_DIR}" diff --quiet || ! git -C "${APP_DIR}" diff --cached --quiet; then
      fail "项目目录存在未提交修改。为避免覆盖你的文件，已停止更新。"
    fi
    printf '正在检查 DSH Tavern 更新……\n'
    # Apply before fetching so existing installations also stop requesting doc blobs.
    git -C "${APP_DIR}" config remote.origin.promisor true
    git -C "${APP_DIR}" config remote.origin.partialclonefilter blob:none
    git -C "${APP_DIR}" sparse-checkout set --no-cone '/*' '!**/docs/'
    if git -C "${APP_DIR}" fetch origin "${BRANCH}"; then
      if ! git -C "${APP_DIR}" merge-base --is-ancestor HEAD "origin/${BRANCH}"; then
        local generated_only=1
        local commit subject files
        while IFS= read -r commit; do
          [ -n "${commit}" ] || continue
          subject="$(git -C "${APP_DIR}" show -s --format=%s "${commit}")"
          files="$(git -C "${APP_DIR}" diff-tree --no-commit-id --name-only -r "${commit}")"
          if [ "${subject}" != 'chore: publish runtime manifest [skip ci]' ] || [ "${files}" != 'dsh-tavern-runtime.json' ]; then
            generated_only=0
            break
          fi
        done < <(git -C "${APP_DIR}" rev-list "origin/${BRANCH}..HEAD")
        if [ "${generated_only}" -eq 1 ]; then
          printf '仅检测到自动生成的运行清单分叉，正在安全重新下载源码……\n'
          install_source
          return
        fi
        fail "项目目录包含本地提交或已经分叉，无法自动安全更新。"
      fi
      git -C "${APP_DIR}" merge --ff-only "origin/${BRANCH}"
      return
    fi
    install_from_tarball
    return
  fi
  if [ -f "${APP_DIR}/${SOURCE_MARKER}" ]; then
    if [ -z "${DSH_TAVERN_TARBALL_URL:-}" ]; then
      TARBALL_URL="$(sed -n '1p' "${APP_DIR}/${SOURCE_MARKER}")"
      [ -n "${TARBALL_URL}" ] || TARBALL_URL="${DEFAULT_TARBALL_URL}"
    fi
    install_from_tarball
    return
  fi
  if is_disposable_upgrade_residue; then
    printf '检测到 DSHA 升级残留的空依赖目录，正在重新安装 DSH Tavern……\n'
    install_source
    return
  fi
  fail "${APP_DIR} 已存在但不是受支持的 Git 或压缩包安装，请备份并移走该目录后重试。"
}

require_command bash
require_command node

stage "准备酒馆源码"
if [ ! -e "${APP_DIR}" ]; then
  # 全新安装优先用 APK 内置快照：不联网、不受网络质量影响。
  if install_from_offline; then
    info '使用 APK 内置源码（离线）'
  else
    info '未找到可用的内置依赖包，改为联网下载。'
    install_source
  fi
else
  info '已有安装，检查更新。'
  update_source
fi

verify_source "${APP_DIR}"

stage "安装依赖并配置 Profile（最慢的一步，日志会持续输出）"
if ! DSH_HOME="${DSH_ROOT}" DSH_TAVERN_OFFLINE_DIR="${OFFLINE_DIR}" bash "${APP_DIR}/android/install.sh"; then
  rollback_source || fail "无法确认服务已停止，未回滚源码，请检查进程后重试。"
  fail "依赖或 Profile 安装失败，源码已恢复到更新前版本。"
fi

SOURCE_SWAPPED=0
# 安装成功后内置依赖包已无用，清掉可释放数百 MB（失败时保留，重试更快）。
if [ -d "${OFFLINE_DIR}" ]; then
  rm -rf -- "${OFFLINE_DIR}" 2>/dev/null || true
fi
if [ "${DSH_TAVERN_ANDROID_STANDALONE:-0}" = 1 ]; then
  printf '\n全部完成。请返回 DSH Tavern 应用并重新启动酒馆。\n'
else
  printf '\n全部完成。请重启 DSHA，然后点击侧栏里的“酒馆工作台”。\n'
fi
