/**
 * Auxiliary-model routing for compaction summaries.
 *
 * A `llm/stream` waterfall listener: every call classified with
 * `purpose: 'compaction'` (issued by the compaction backend for its summary
 * request) is rerouted to the configured auxiliary summarizer pair, while the
 * conversation's own model route stays untouched. This is what makes "compress
 * the context with a separate model" work without touching the compaction
 * backend's own configuration. When no auxiliary route is configured the
 * listener is a pure pass-through.
 *
 * @module dsh-auxiliary/compact-router
 */
import type { Context } from '@deepseek-ai/cordis';
import type { GenerateOptions, StreamChunk, ReasoningEffortId } from '@deepseek-ai/dsh-llm';
import { deepFreeze } from './dsh.js';
import type { HostAPI } from '@dsh-plugin/dsh-loader';
import { installProviderCompaction } from './provider-compaction.js';
import type { ResolvedPluginConfig } from './config.js';

/** The configured auxiliary summarizer route, or undefined when routing is off. */
export function compactRoute(get: () => ResolvedPluginConfig): { provider: string; model: string; reasoningEffort?: ReasoningEffortId } | undefined {
  const compact = get().compact;
  if (!compact.enabled || compact.provider.length === 0 || compact.model.length === 0) return undefined;
  return { provider: compact.provider, model: compact.model, ...(compact.reasoningEffort ? { reasoningEffort: compact.reasoningEffort } : {}) };
}

/**
 * Install the compaction rerouting middleware. The waterfall listener returns
 * its own stream when rerouting is needed (guarded against re-entry by the
 * route match check) and delegates via `next()` otherwise.
 */
export function installCompactRouter(ctx: Context, get: () => ResolvedPluginConfig, patch?: HostAPI['patch']): () => void {
  const perProvider = patch === undefined ? undefined : installProviderCompaction(ctx, patch);
  const legacy = (options: GenerateOptions, next: () => AsyncIterable<StreamChunk>): AsyncIterable<StreamChunk> => {
    if (options.purpose !== 'compaction') return next();
    const route = compactRoute(get);
    if (route === undefined) return next();
    if (options.provider === route.provider && options.model === route.model && options.reasoningEffort === route.reasoningEffort) { return next(); }
    const rerouted = deepFreeze({ ...options, provider: route.provider, model: route.model, reasoningEffort: route.reasoningEffort });
    return ctx.llm.stream(rerouted);
  };
  const dispose = ctx.on('llm/stream', (options: GenerateOptions, next: () => AsyncIterable<StreamChunk>) =>
    perProvider?.route(options, next, () => legacy(options, next)) ?? legacy(options, next));
  return () => { dispose(); perProvider?.dispose(); };
}
