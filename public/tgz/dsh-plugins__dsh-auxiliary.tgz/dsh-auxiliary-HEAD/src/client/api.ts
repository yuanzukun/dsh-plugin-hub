/**
 * Browser-side Host data access for the dsh-auxiliary settings section. All
 * reads and writes use the connection's ApiProxy (`llm.*` / `settings.*`), so
 * the settings page shares the Host's provider directory and namespace writer.
 *
 * @module dsh-auxiliary/client/api
 */
import type {
  ConfigurableProviderView,
  IApiClient,
  ModelCatalogFailure,
  ModelCatalogModel,
  ModelProviderGroup as HostModelProviderGroup,
  RpcError,
  RpcResponse,
  SettingsNamespaceView,
} from '@deepseek-ai/dsh-client-connection/client';

/** One configurable provider row returned by the live route directory. */
export interface ProviderOption {
  /** Provider route key (`anvilcraft-ai`, `deepseek-official`, …). */
  id: string;
  /** Human-readable provider name. */
  name: string;
  /** Whether the route is currently registered and requestable. */
  active: boolean;
}

/** One model entry retained inside a provider group. */
export type ModelOption = ModelCatalogModel;

/** One provider group retained from `llm.models`. */
export type ModelProviderGroup = HostModelProviderGroup;

/** Host model catalog, preserving provider groups and lookup diagnostics. */
export interface ModelCatalog {
  /** Successful groups in provider-directory order. */
  groups: readonly ModelProviderGroup[];
  /** Non-fatal lookup failures reported by the Host. */
  failures: readonly ModelCatalogFailure[];
}

/** A possibly stale provider/model route stored in the auxiliary namespace. */
export interface AuxRoute {
  provider?: string;
  model?: string;
}

/** One independently configurable auxiliary feature. */
export interface AuxFeatureSettings extends AuxRoute {
  enabled: boolean;
  /** Image handoff toggle; only meaningful for the vision feature. */
  handoff?: boolean;
  /** Skip injecting vision tools/prompt when the main model sees images; vision only. */
  skipWhenMainModelSupportsImage?: boolean;
}

/** The optional compression-engine policy surfaced by the compaction card. */
export interface AuxEngineSettings {
  /** Whether the auxiliary compression engine handles pressure. */
  enabled: boolean;
  /** Context-usage fraction at which automatic compaction triggers. */
  thresholdRatio: number;
}

/** Complete decoded auxiliary namespace state used by the settings page. */
export interface AuxSettings {
  /** `tool.enabled` plus the `vision` provider/model route. */
  vision: AuxFeatureSettings;
  /** `compact.enabled` plus the compact provider/model route. */
  compact: AuxFeatureSettings;
  /** `approve.enabled` plus the approval-reviewer provider/model route. */
  approve: AuxFeatureSettings;
  /** `subagent.enabled` plus the subagent provider/model route. */
  subagent: AuxFeatureSettings;
  /** `title.enabled` plus the session-title provider/model route. */
  title: AuxFeatureSettings;
  /** `imagegen.enabled` plus the auxiliary image-generation provider/model route. */
  imagegen: AuxFeatureSettings;
  /** Compression-engine policy edited from the compaction card. */
  engine: AuxEngineSettings;
  /** Namespace revision for the next optimistic-concurrency write. */
  revision?: number;
  /** Whether the namespace is exposed by the current Host. */
  available: boolean;
  /** Whether the current settings provider accepts writes. */
  writable: boolean;
}

/** Complete settings snapshot returned after a successful feature write. */
export interface AuxSettingsSnapshot {
  vision: AuxFeatureSettings;
  compact: AuxFeatureSettings;
  approve: AuxFeatureSettings;
  subagent: AuxFeatureSettings;
  title: AuxFeatureSettings;
  imagegen: AuxFeatureSettings;
  engine: AuxEngineSettings;
  revision: number;
}

/** Feature names accepted by the atomic auxiliary settings writer. */
export type AuxFeature = 'vision' | 'compact' | 'approve' | 'subagent' | 'title' | 'imagegen';

/** Draft shape submitted by one feature card. */
export interface AuxFeatureDraft extends AuxRoute {
  enabled: boolean;
  /** Image handoff toggle; only the vision card edits it. */
  handoff?: boolean;
  /** Skip-injection toggle; only the vision card edits it. */
  skipWhenMainModelSupportsImage?: boolean;
}

/** Additional local validation code used before an RPC write. */
type LocalAuxiliaryErrorCode = 'invalid-route' | 'image-capability-unavailable';

/** Structured error raised by an auxiliary API operation. */
export class AuxiliaryApiError extends Error {
  /** Machine-readable RPC or local validation code. */
  readonly code: RpcError['code'] | LocalAuxiliaryErrorCode;
  /** Wire details when the Host supplied them. */
  readonly details: unknown;

  constructor(
    code: RpcError['code'] | LocalAuxiliaryErrorCode,
    message: string,
    details?: unknown,
  ) {
    super(message);
    this.name = 'AuxiliaryApiError';
    this.code = code;
    this.details = details;
  }
}

/** Unwrap a unary RPC response without discarding its discriminant code. */
function valueOf<T>(response: RpcResponse<T>): T {
  if (!response.result.ok) {
    throw new AuxiliaryApiError(
      response.result.error.code,
      response.result.error.message,
      response.result.error.details,
    );
  }
  return response.result.value;
}

/** List every configurable provider from the live route registry. */
export async function loadProviders(api: IApiClient): Promise<ProviderOption[]> {
  const value = valueOf(await api.llm.providers({}));
  return value.providers.map((entry: ConfigurableProviderView) => ({
    id: entry.provider,
    name: entry.displayName,
    active: entry.active,
  }));
}

/** One user-editable llm-pi-ai provider route, with its catalog display name. */
export interface PiAiProviderRef {
  /** Provider route key (`lanqin-gpt`, `anvilcraft-ai`, …). */
  id: string;
  /** Display name shown by the Models catalog card header. */
  name: string;
}

/** Every provider route whose models live in the user-editable llm-pi-ai namespace. */
export async function loadPiAiProviders(api: IApiClient): Promise<PiAiProviderRef[]> {
  const value = valueOf(await api.llm.providers({}));
  return value.providers
    .filter((entry: ConfigurableProviderView) => entry.settingsNs === 'llm-pi-ai')
    .map((entry: ConfigurableProviderView) => ({ id: entry.provider, name: entry.displayName }));
}

/**
 * Load the model catalog while retaining its provider groups and failures.
 * Inactive provider routes remain out of the selectable groups even if their
 * last catalog response is still present.
 */
export async function loadModels(api: IApiClient): Promise<ModelCatalog> {
  const [providers, response] = await Promise.all([
    loadProviders(api),
    api.llm.models({}),
  ]);
  const value = valueOf(response);
  const activeProviders = new Set(providers.filter((provider) => provider.active).map((provider) => provider.id));
  return {
    groups: value.groups.filter((group: ModelProviderGroup) => activeProviders.has(group.id)),
    failures: value.failures,
  };
}

/** Image-input declaration of one editable llm-pi-ai model row. */
export interface ModelImageCapability {
  /** Whether the provider has a user-owned llm-pi-ai model row for this id. */
  available: boolean;
  /** Whether the model currently declares image input. */
  supported: boolean;
  /** Whether the Host settings provider accepts writes. */
  writable: boolean;
}

/** Narrow an unknown settings value to a plain record. */
function recordOf(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined;
}

/** Read a modality declaration without admitting arbitrary wire values. */
function modalitiesOf(value: unknown): readonly string[] | undefined {
  return Array.isArray(value) && value.every((entry) => typeof entry === 'string')
    ? value
    : undefined;
}

/** A located user-owned model row inside the llm-pi-ai namespace. */
interface PiAiModelLocation {
  namespace: SettingsNamespaceView;
  models: Array<Record<string, unknown>>;
  modelIndex: number;
}

/** Locate the user-owned model row for one provider/model pair. */
function locatePiAiModel(namespace: SettingsNamespaceView, provider: string, model: string): PiAiModelLocation | undefined {
  const providers = recordOf(recordOf(namespace.user)?.providers);
  const providerProfile = providers === undefined ? undefined : recordOf(providers[provider]);
  const rawModels = providerProfile?.models;
  if (!Array.isArray(rawModels)) return undefined;
  const models = rawModels.map(recordOf);
  if (models.some((entry) => entry === undefined)) return undefined;
  const typedModels = models as Array<Record<string, unknown>>;
  const modelIndex = typedModels.findIndex((entry) => entry.id === model);
  if (modelIndex < 0) return undefined;
  return { namespace, models: typedModels, modelIndex };
}

/** Read the effective image-input declaration of one editable llm-pi-ai model. */
export async function loadModelImageCapability(api: IApiClient, provider: string, model: string): Promise<ModelImageCapability> {
  const settings = valueOf(await api.settings.describe({}));
  const namespace = settings.namespaces.find((entry) => entry.ns === 'llm-pi-ai');
  const location = namespace === undefined ? undefined : locatePiAiModel(namespace, provider, model);
  if (location === undefined) return { available: false, supported: false, writable: settings.writable };

  const providers = recordOf(recordOf(location.namespace.value)?.providers);
  const resolvedProfile = providers === undefined ? undefined : recordOf(providers[provider]);
  const resolvedModels = Array.isArray(resolvedProfile?.models)
    ? resolvedProfile.models.map(recordOf).filter((entry): entry is Record<string, unknown> => entry !== undefined)
    : [];
  const resolvedModel = resolvedModels.find((entry) => entry.id === model) ?? location.models[location.modelIndex];
  const modelInput = modalitiesOf(resolvedModel?.input);
  const defaultInput = modalitiesOf(resolvedProfile?.defaultInput);
  const supported = (modelInput !== undefined && modelInput.length > 0 ? modelInput : defaultInput)?.includes('image') ?? false;
  return { available: true, supported, writable: settings.writable };
}

/** Write one editable llm-pi-ai model's image-input declaration, preserving sibling rows. */
export async function saveModelImageCapability(
  api: IApiClient,
  provider: string,
  model: string,
  supported: boolean,
): Promise<ModelImageCapability> {
  const settings = valueOf(await api.settings.describe({}));
  const namespace = settings.namespaces.find((entry) => entry.ns === 'llm-pi-ai');
  const location = namespace === undefined ? undefined : locatePiAiModel(namespace, provider, model);
  if (location === undefined || !settings.writable) {
    throw new AuxiliaryApiError(
      'image-capability-unavailable',
      'dsh-auxiliary: the selected model does not expose an editable llm-pi-ai model row',
    );
  }
  const models = location.models.map((entry, index) => index === location.modelIndex
    ? { ...entry, input: supported ? ['text', 'image'] : ['text'] }
    : entry);
  valueOf(await api.settings.update({
    ns: 'llm-pi-ai',
    patch: { providers: { [provider]: { models } } },
    expectedRevision: location.namespace.revision,
  }));
  return { available: true, supported, writable: true };
}

/**
 * Image-generation declaration of one editable llm-pi-ai model row.
 *
 * Unlike image input, pi-ai has no schema field for generation, so the flag
 * lives in the user-owned row as a plugin-owned `imageGeneration` boolean: the
 * settings service persists the raw user section (unknown keys survive), while
 * pi-ai's own schema resolution strips the key from every derived view. Reads
 * therefore go to the raw row directly — the resolved profile models would
 * never carry the flag.
 */
export interface ModelGenerationCapability {
  /** Whether the provider has a user-owned llm-pi-ai model row for this id. */
  available: boolean;
  /** Whether the model is currently marked as image-generating. */
  supported: boolean;
  /** Whether the Host settings provider accepts writes. */
  writable: boolean;
}

/** Read the image-generation flag of one editable llm-pi-ai model. */
export async function loadModelGenerationCapability(
  api: IApiClient,
  provider: string,
  model: string,
): Promise<ModelGenerationCapability> {
  const settings = valueOf(await api.settings.describe({}));
  const namespace = settings.namespaces.find((entry) => entry.ns === 'llm-pi-ai');
  const location = namespace === undefined ? undefined : locatePiAiModel(namespace, provider, model);
  if (location === undefined) return { available: false, supported: false, writable: settings.writable };
  const row = location.models[location.modelIndex];
  const supported = row.imageGeneration === true;
  return { available: true, supported, writable: settings.writable };
}

/** Write one editable llm-pi-ai model's image-generation flag, preserving sibling rows. */
export async function saveModelGenerationCapability(
  api: IApiClient,
  provider: string,
  model: string,
  supported: boolean,
): Promise<ModelGenerationCapability> {
  const settings = valueOf(await api.settings.describe({}));
  const namespace = settings.namespaces.find((entry) => entry.ns === 'llm-pi-ai');
  const location = namespace === undefined ? undefined : locatePiAiModel(namespace, provider, model);
  if (location === undefined || !settings.writable) {
    throw new AuxiliaryApiError(
      'image-capability-unavailable',
      'dsh-auxiliary: the selected model does not expose an editable llm-pi-ai model row',
    );
  }
  const models = location.models.map((entry, index) => index === location.modelIndex
    ? { ...entry, imageGeneration: supported }
    : entry);
  valueOf(await api.settings.update({
    ns: 'llm-pi-ai',
    patch: { providers: { [provider]: { models } } },
    expectedRevision: location.namespace.revision,
  }));
  return { available: true, supported, writable: true };
}

/**
 * Every pi-ai thinking level a profile may declare, in escalation order.
 * Mirrors `THINKING_LEVELS` in `@deepseek-ai/dsh-llm-pi-ai`.
 */
const THINKING_LEVELS = ['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'] as const;

/** A model's official reasoning-efforts declaration. */
type ReasoningEfforts =
  | false
  | Readonly<Record<string, string | null>>;

/** Whether a level name is a pi-ai thinking level. */
function isThinkingLevel(value: string): boolean {
  return (THINKING_LEVELS as readonly string[]).includes(value);
}

/**
 * Read the declared thinking levels from a row's official `reasoningEfforts`.
 *
 * Levels come back in pi-ai's escalation order, independent of key order in
 * the profile. `false` (explicit non-reasoning) and `undefined` (inherit the
 * installed catalog) both yield an empty list.
 */
function levelsOfReasoningEfforts(value: unknown): readonly string[] {
  const efforts = recordOf(value);
  if (efforts === undefined) return [];
  return THINKING_LEVELS.filter(level => efforts[level] !== undefined);
}

/** Read the provider-level default reasoning effort of one llm-pi-ai route. */
function providerReasoningDefault(namespace: SettingsNamespaceView, provider: string): string | null {
  const providers = recordOf(recordOf(namespace.user)?.providers);
  const profile = providers === undefined ? undefined : recordOf(providers[provider]);
  return typeof profile?.reasoning === 'string' ? profile.reasoning : null;
}

/**
 * Read one row's declared reasoning levels, migrating the plugin's legacy
 * `thinkingLevels` private field when the official field is absent.
 */
export function readReasoningLevels(row: Readonly<Record<string, unknown>>): readonly string[] {
  const official = levelsOfReasoningEfforts(row.reasoningEfforts);
  if (official.length > 0) return official;
  if (Array.isArray(row.thinkingLevels)) {
    const legacy = row.thinkingLevels.filter((entry): entry is string => typeof entry === 'string' && isThinkingLevel(entry));
    return THINKING_LEVELS.filter(level => legacy.includes(level));
  }
  return [];
}

/**
 * Read one row's full official reasoning config: levels from `reasoningEfforts`
 * (with legacy migration) and the default from the provider-level `reasoning`
 * effort (with legacy migration).
 */
export function readModelThinkingRow(
  namespace: SettingsNamespaceView,
  provider: string,
  row: Readonly<Record<string, unknown>>,
): { levels: readonly string[]; defaultLevel: string | null } {
  const levels = readReasoningLevels(row);
  let defaultLevel = providerReasoningDefault(namespace, provider);
  if (defaultLevel === null && typeof row.defaultThinkingLevel === 'string' && isThinkingLevel(row.defaultThinkingLevel)) {
    defaultLevel = row.defaultThinkingLevel;
  }
  return { levels, defaultLevel };
}

/**
 * Selectable thinking levels and the default level of one editable llm-pi-ai
 * model.
 *
 * The levels are read directly from the model row's OFFICIAL `reasoningEfforts`
 * field (level → same-name wire token, `off` → `null`): pi-ai's model directory
 * advertises reasoning capability — and therefore the conversation's
 * reasoning-effort picker — from that single field, so the plugin's editor is
 * just an authoring surface for it. The default level is the provider-level
 * `reasoning` effort, the official pre-selection for the composer picker.
 *
 * Rows saved by older plugin versions carry the private `thinkingLevels`
 * / `defaultThinkingLevel` fields; they are honoured as a fallback on read and
 * stripped again on write, migrating the stored configuration to the official
 * fields in one save.
 */
export interface ModelThinkingConfig {
  /** Whether the provider has a user-owned llm-pi-ai model row for this id. */
  available: boolean;
  /** Offered thinking levels (`low`, `high`, …), in pi-ai escalation order. */
  levels: readonly string[];
  /** The default level, or null when unset. */
  defaultLevel: string | null;
  /** Whether the Host settings provider accepts writes. */
  writable: boolean;
}

/** Read the official reasoning configuration of one editable llm-pi-ai model. */
export async function loadModelThinkingConfig(
  api: IApiClient,
  provider: string,
  model: string,
): Promise<ModelThinkingConfig> {
  const settings = valueOf(await api.settings.describe({}));
  const namespace = settings.namespaces.find((entry) => entry.ns === 'llm-pi-ai');
  const location = namespace === undefined ? undefined : locatePiAiModel(namespace, provider, model);
  if (location === undefined) return { available: false, levels: [], defaultLevel: null, writable: settings.writable };
  const { levels, defaultLevel } = readModelThinkingRow(location.namespace, provider, location.models[location.modelIndex]);
  return { available: true, levels, defaultLevel, writable: settings.writable };
}

/** Write one model's official reasoning configuration, preserving sibling rows. */
export async function saveModelThinkingConfig(
  api: IApiClient,
  provider: string,
  model: string,
  levels: readonly string[],
  defaultLevel: string | null,
): Promise<ModelThinkingConfig> {
  const settings = valueOf(await api.settings.describe({}));
  const namespace = settings.namespaces.find((entry) => entry.ns === 'llm-pi-ai');
  const location = namespace === undefined ? undefined : locatePiAiModel(namespace, provider, model);
  if (location === undefined || !settings.writable) {
    throw new AuxiliaryApiError(
      'bad-request',
      'dsh-auxiliary: the selected model does not expose an editable llm-pi-ai model row',
    );
  }
  const hasThinking = levels.some((level) => level !== 'off');
  // The OFFICIAL `reasoningEfforts` declaration, unwrapped from the editor's
  // level list: each non-`off` level maps to its same-name wire token, `off`
  // maps to `null` ("supported, send nothing"). Schema rules (pi-ai):
  //  - an empty dict is invalid, so an empty list omits the field (inherit the
  //    installed catalog's capability);
  //  - only `off` is invalid as a dict, so that collapses to `false` (explicit
  //    non-reasoning);
  //  - a real declaration must keep at least one non-`off` level.
  const reasoningEfforts: false | Readonly<Record<string, string | null>> | undefined = hasThinking
    ? Object.fromEntries(
        levels.map((level) => [level, level === 'off' ? null : level]),
      )
    : levels.length > 0
      ? false
      : undefined;
  const models = location.models.map((entry, index) => {
    if (index !== location.modelIndex) return entry;
    const { thinkingLevels: _legacyLevels, defaultThinkingLevel: _legacyDefault, ...rest } = entry;
    return {
      ...rest,
      ...(reasoningEfforts === undefined ? {} : { reasoningEfforts }),
    };
  });
  // The provider-level `reasoning` default: the official pre-selection for the
  // conversation picker (see `describableReasoningLevel`). Only levels the
  // list offers may be defaulted; a null or absent default keeps the current
  // provider value untouched.
  const providerProfile = recordOf(
    recordOf(recordOf(location.namespace.user)?.providers)?.[provider],
  );
  const reasoningDefault = defaultLevel !== null && levels.includes(defaultLevel)
    ? defaultLevel
    : undefined;
  const patch: Record<string, unknown> = {
    ...(providerProfile === undefined ? {} : { ...providerProfile }),
    models,
    ...(reasoningDefault === undefined ? {} : { reasoning: reasoningDefault }),
  };
  valueOf(await api.settings.update({
    ns: 'llm-pi-ai',
    patch: { providers: { [provider]: patch } },
    expectedRevision: location.namespace.revision,
  }));
  return { available: true, levels: [...levels], defaultLevel, writable: true };
}

/**
 * List every user-owned llm-pi-ai model marked for image generation
 * (`imageGeneration: true` in its raw row). The flag survives in the raw user
 * section but is stripped from resolved views, so this walks `namespace.user`
 * directly, mirroring `loadModelGenerationCapability`.
 * @returns `provider\u0000model` keys of the marked models.
 */
export async function loadImageGenModelKeys(api: IApiClient): Promise<ReadonlySet<string>> {
  const settings = valueOf(await api.settings.describe({}));
  const namespace = settings.namespaces.find((entry) => entry.ns === 'llm-pi-ai');
  if (namespace === undefined) return new Set();
  const providers = recordOf(recordOf(namespace.user)?.providers);
  if (providers === undefined) return new Set();
  const keys = new Set<string>();
  for (const [provider, profile] of Object.entries(providers)) {
    const models = recordOf(profile)?.models;
    if (!Array.isArray(models)) continue;
    for (const raw of models) {
      const row = recordOf(raw);
      if (row === undefined || row.imageGeneration !== true || typeof row.id !== 'string') continue;
      keys.add(`${provider}\u0000${row.id}`);
    }
  }
  return keys;
}

/**
 * Retain only the provider groups whose models are marked for image
 * generation, preserving group order and provider metadata. Groups left with
 * no marked models are dropped.
 */
export function filterImageGenGroups(
  groups: readonly ModelProviderGroup[],
  keys: ReadonlySet<string>,
): readonly ModelProviderGroup[] {
  const filtered: ModelProviderGroup[] = [];
  for (const group of groups) {
    const models = group.models.filter((model) => keys.has(`${group.id}\u0000${model.id}`));
    if (models.length === 0) continue;
    filtered.push({ ...group, models });
  }
  return filtered;
}

interface AuxNamespaceValue {
  vision?: {
    provider?: string;
    model?: string;
    handoff?: boolean;
    skipWhenMainModelSupportsImage?: boolean;
  };
  tool?: {
    enabled?: boolean;
  };
  compact?: {
    enabled?: boolean;
    provider?: string;
    model?: string;
  };
  approve?: {
    enabled?: boolean;
    provider?: string;
    model?: string;
  };
  subagent?: {
    enabled?: boolean;
    provider?: string;
    model?: string;
  };
  title?: {
    enabled?: boolean;
    provider?: string;
    model?: string;
  };
  imagegen?: {
    enabled?: boolean;
    provider?: string;
    model?: string;
  };
  engine?: {
    enabled?: boolean;
    thresholdRatio?: number;
  };
}

/** Read the schema-resolved auxiliary value from a wire namespace view. */
function namespaceValue(view: SettingsNamespaceView): AuxNamespaceValue {
  return view.value as AuxNamespaceValue;
}

/** Decode one namespace view into the complete feature snapshot. */
function snapshotOf(view: SettingsNamespaceView): AuxSettingsSnapshot {
  const value = namespaceValue(view);
  return {
    vision: {
      enabled: value.tool?.enabled ?? true,
      provider: value.vision?.provider,
      model: value.vision?.model,
      handoff: value.vision?.handoff ?? true,
      skipWhenMainModelSupportsImage: value.vision?.skipWhenMainModelSupportsImage ?? false,
    },
    compact: {
      enabled: value.compact?.enabled ?? false,
      provider: value.compact?.provider,
      model: value.compact?.model,
    },
    approve: {
      enabled: value.approve?.enabled ?? false,
      provider: value.approve?.provider,
      model: value.approve?.model,
    },
    subagent: {
      enabled: value.subagent?.enabled ?? false,
      provider: value.subagent?.provider,
      model: value.subagent?.model,
    },
    title: {
      enabled: value.title?.enabled ?? false,
      provider: value.title?.provider,
      model: value.title?.model,
    },
    imagegen: {
      enabled: value.imagegen?.enabled ?? false,
      provider: value.imagegen?.provider,
      model: value.imagegen?.model,
    },
    engine: {
      enabled: value.engine?.enabled ?? false,
      thresholdRatio: value.engine?.thresholdRatio ?? 0.8,
    },
    revision: view.revision,
  };
}

/** Read the dsh-auxiliary namespace from the settings descriptor. */
export async function loadAuxSettings(api: IApiClient): Promise<AuxSettings> {
  const value = valueOf(await api.settings.describe({}));
  const namespace: SettingsNamespaceView | undefined = value.namespaces.find((ns) => ns.ns === 'dsh-auxiliary');
  if (namespace === undefined) {
    return {
      vision: { enabled: true },
      compact: { enabled: false },
      approve: { enabled: false },
      subagent: { enabled: false },
      title: { enabled: false },
      imagegen: { enabled: false },
      engine: { enabled: false, thresholdRatio: 0.8 },
      available: false,
      writable: value.writable,
    };
  }
  const snapshot = snapshotOf(namespace);
  return {
    ...snapshot,
    available: true,
    writable: value.writable,
  };
}

/** Return the non-empty route text, or an empty wire value when cleared. */
function routeText(value: string | undefined): string {
  return value?.trim() ?? '';
}

/** Normalize and validate a feature draft before constructing its patch. */
function normalizedDraft(draft: AuxFeatureDraft): { enabled: boolean; provider: string; model: string; handoff?: boolean; skipWhenMainModelSupportsImage?: boolean } {
  const provider = routeText(draft.provider);
  const model = routeText(draft.model);
  if (Boolean(provider) !== Boolean(model)) {
    throw new AuxiliaryApiError(
      'invalid-route',
      'dsh-auxiliary: provider and model must be selected together',
    );
  }
  return {
    enabled: draft.enabled,
    provider,
    model,
    ...(draft.handoff === undefined ? {} : { handoff: draft.handoff }),
    ...(draft.skipWhenMainModelSupportsImage === undefined ? {} : { skipWhenMainModelSupportsImage: draft.skipWhenMainModelSupportsImage }),
  };
}

/** Preserve unrelated engine fields while the UI edits threshold/enabled. */
async function loadRawAuxEngine(
  api: IApiClient,
): Promise<AuxNamespaceValue['engine']> {
  const settings = valueOf(await api.settings.describe({}));
  const namespace = settings.namespaces.find((entry) => entry.ns === 'dsh-auxiliary');
  return namespace === undefined ? undefined : namespaceValue(namespace).engine;
}

/**
 * Atomically save one feature while preserving the other feature's namespace
 * fields. The returned snapshot is the complete post-write namespace value.
 * Saving the compaction card with `engineThresholdRatio` also enables the
 * auxiliary compression engine so the new threshold takes effect.
 */
export async function saveAuxFeature(
  api: IApiClient,
  feature: AuxFeature,
  draft: AuxFeatureDraft,
  expectedRevision?: number,
  engineThresholdRatio?: number,
): Promise<AuxSettingsSnapshot> {
  const normalized = normalizedDraft(draft);
  const patch = feature === 'vision'
    ? {
      vision: {
        provider: normalized.provider,
        model: normalized.model,
        ...(normalized.handoff === undefined ? {} : { handoff: normalized.handoff }),
        ...(normalized.skipWhenMainModelSupportsImage === undefined ? {} : { skipWhenMainModelSupportsImage: normalized.skipWhenMainModelSupportsImage }),
      },
      tool: {
        enabled: normalized.enabled,
      },
    }
    : feature === 'approve'
      ? {
        approve: {
          enabled: normalized.enabled,
          provider: normalized.provider,
          model: normalized.model,
        },
      }
      : feature === 'subagent'
        ? {
          subagent: {
            enabled: normalized.enabled,
            provider: normalized.provider,
            model: normalized.model,
          },
        }
        : feature === 'title'
          ? {
            title: {
              enabled: normalized.enabled,
              provider: normalized.provider,
              model: normalized.model,
            },
          }
          : feature === 'imagegen'
            ? {
              imagegen: {
                enabled: normalized.enabled,
                provider: normalized.provider,
                model: normalized.model,
              },
            }
            : await (async () => {
              const compact = {
                enabled: normalized.enabled,
                provider: normalized.provider,
                model: normalized.model,
              };
              if (engineThresholdRatio === undefined) return { compact };
              const rawEngine = await loadRawAuxEngine(api);
              return {
                compact,
                engine: {
                  ...(rawEngine ?? {}),
                  enabled: true,
                  thresholdRatio: engineThresholdRatio,
                },
              };
            })();
  const view = valueOf(await api.settings.update({
    ns: 'dsh-auxiliary',
    patch,
    ...(expectedRevision !== undefined ? { expectedRevision } : {}),
  }));
  return snapshotOf(view);
}

/** Read-only host state served by the dsh-auxiliary state endpoint. */
export interface ApproveHostState {
  /** Whether the approve-for-me plugin registered one of its review presets. */
  readonly approvePluginInstalled: boolean;
}

/**
 * Fetch the host-side approve-for-me detection state. The endpoint is a
 * same-origin read-only route registered by the plugin; any failure (older
 * host, headless profile, network) conservatively reports "not installed".
 */
export async function loadApproveHostState(): Promise<ApproveHostState> {
  try {
    const response = await fetch('/dsh-auxiliary/state', { headers: { accept: 'application/json' } });
    if (!response.ok) return { approvePluginInstalled: false };
    const state = await response.json() as Partial<ApproveHostState>;
    return { approvePluginInstalled: state.approvePluginInstalled === true };
  } catch {
    return { approvePluginInstalled: false };
  }
}

/** Return the Host revision from a structured settings conflict, if present. */
export function conflictRevision(error: unknown): number | undefined {
  if (!(error instanceof AuxiliaryApiError) || error.code !== 'settings-conflict') return undefined;
  const details = error.details;
  if (typeof details !== 'object' || details === null || !('actual' in details)) return undefined;
  const actual = (details as { actual?: unknown }).actual;
  return typeof actual === 'number' ? actual : undefined;
}
