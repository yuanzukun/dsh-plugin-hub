import {test} from 'node:test';
import assert from 'node:assert/strict';
import {defaultsFor,validateValues} from '@dsh-plugin/dsh-loader/config';
import {Config} from '../lib/config.js';
import {createConfigTemplate, runtimeConfig} from '../lib/config-template.js';

test('config template preserves seeded routes and validates complete nested configuration',()=>{
  const template=createConfigTemplate(Config({vision:{provider:'p',model:'m'}}));
  const defaults=defaultsFor(template.fields);
  assert.deepEqual(defaults.vision.selection,{provider:'p',model:'m'});
  assert.equal(runtimeConfig(defaults).vision.model,'m');
  assert.equal(defaults.tool.enabled,true); assert.equal(defaults.engine.retainRatio,0.16);
  assert(!('视觉模型' in defaults));
  assert.throws(()=>validateValues(template.fields,{...defaults,tool:{...defaults.tool,maxImageBytes:-1}}));
  assert.throws(()=>validateValues(template.fields,{...defaults,engine:{...defaults.engine,thresholdRatio:2}}));
  assert.deepEqual(validateValues(template.fields,JSON.parse(JSON.stringify(defaults))),defaults);
});

test('only supported hosts receive the official translation form',()=>{
  const group=version=>createConfigTemplate(Config({}),version).fields.find(field=>field.key==='translation');
  assert.equal(group('0.2.1-alpha.5'),undefined);
  const latest=group('0.2.1-rc.1');assert.equal(latest.label,'思考过程机器翻译');
  assert.equal(defaultsFor([latest]).translation.selection.model,'deepseek-flash');
  assert.equal(defaultsFor([latest]).translation.enabled,false);
});

test('翻译模型保存第三方提供商，清除选择后恢复官方默认模型', () => {
  const template = createConfigTemplate(Config({ translation: { enabled: true, provider: 'foo', model: 'example' } }), '0.2.1-rc.1');
  const value = defaultsFor(template.fields);
  assert.deepEqual(value.translation.selection, { provider: 'foo', model: 'example' });
  const saved = runtimeConfig(validateValues(template.fields, value));
  assert.equal(saved.translation.provider, 'foo');
  assert.equal(saved.translation.model, 'example');
  value.translation.selection = null;
  const cleared = runtimeConfig(value);
  assert.equal(cleared.translation.provider, 'deepseek-official');
  assert.equal(cleared.translation.model, 'deepseek-flash');
});

test('子智能体模型使用对应宿主版本的选择方式，其他辅助路由保持可用', () => {
  for (const [version, legacy] of [
    ['0.1.1-rc.2', true], ['0.1.2-alpha.1', true],
    ['0.1.2-alpha.2', false], ['0.1.2-alpha.2+build.1', false], ['0.1.2-beta.1', false],
    ['0.1.2-rc.1', false], ['0.1.2', false], ['0.1.5-alpha.1', false],
    ['0.2.1-rc.5', false], ['0.2.2-alpha.3', false], [undefined, false], ['bad', false],
  ]) {
    const base = Config({ title: { enabled: true, provider: 'foo', model: 'title' }, subagent: { enabled: true, provider: 'foo', model: 'child' } });
    const value = defaultsFor(createConfigTemplate(base, version).fields);
    assert.equal(value.subagent !== undefined, legacy, version);
    value.subagent = { enabled: true, selection: { provider: 'foo', model: 'child' } };
    const configured = runtimeConfig(value, version);
    assert.equal(configured.subagent.enabled, legacy, version);
    assert.equal(configured.subagent.model, legacy ? 'child' : '', version);
    assert.equal(configured.title.provider, 'foo');
    assert.equal(configured.title.model, 'title');
  }
});

test('部署路由缺少提供商或模型时报告配置错误', () => {
  for (const vision of [{ provider: 'foo' }, { model: 'example' }]) {
    assert.throws(() => createConfigTemplate(Config({ vision })), /必须同时配置/);
  }
});
