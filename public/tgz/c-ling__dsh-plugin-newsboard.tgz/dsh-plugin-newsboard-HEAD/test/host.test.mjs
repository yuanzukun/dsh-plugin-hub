import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import {
  API_PREFIX,
  DEFAULT_CONFIG,
  SOURCE_IDS,
  apply,
  assignCategories,
  attachTranslations,
  buildFetchPlan,
  filterItems,
  hasCjk,
  mergeItems,
  needsTranslation,
  normalizeItem,
  parseHnHits,
  parseLobsters,
  parseRssFeed,
  parseTranslationReply,
  seedTranslations,
} from "../lib/index.js";

// ── RSS parsing ────────────────────────────────────────────────────────────

test("parseRssFeed extracts RSS 2.0 fields and decodes CDATA/entities", () => {
  const xml = `<?xml version="1.0"?>
<rss version="2.0"><channel><title>feed</title>
<item><title><![CDATA[OpenAI &amp; friends]]></title><link>https://example.com/a?x=1&amp;y=2</link><description><![CDATA[<p>Hello <b>world</b></p>]]></description><pubDate>Mon, 16 Aug 2026 10:00:00 GMT</pubDate></item>
<item><title>No date</title><link>https://example.com/b</link></item>
</channel></rss>`;
  const rows = parseRssFeed(xml);
  assert.equal(rows.length, 2);
  assert.equal(rows[0].title, "OpenAI & friends");
  assert.equal(rows[0].url, "https://example.com/a?x=1&y=2");
  assert.equal(rows[0].summary, "Hello world");
  assert.ok(rows[0].publishedAt.startsWith("2026-08-16"));
  assert.equal(rows[1].publishedAt, undefined);
});

test("parseRssFeed extracts Atom link/title/updated", () => {
  const xml = `<feed xmlns="http://www.w3.org/2005/Atom">
<entry><title>Atom title</title><link rel="alternate" href="https://example.com/atom"/><summary>Summary</summary><updated>2026-08-16T09:00:00Z</updated></entry>
</feed>`;
  const rows = parseRssFeed(xml);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].title, "Atom title");
  assert.equal(rows[0].url, "https://example.com/atom");
  assert.ok(rows[0].publishedAt.startsWith("2026-08-16"));
});

// ── item normalization / source parsers ────────────────────────────────────

test("normalizeItem drops items without title or link and derives ids", () => {
  assert.equal(normalizeItem("hn_front", { title: "", url: "https://x.dev" }), null);
  assert.equal(normalizeItem("hn_front", { title: "T", url: "" }), null);
  assert.equal(normalizeItem("hn_front", { title: "T", url: "javascript:alert(1)" }), null);
  assert.equal(normalizeItem("hn_front", { title: "T", url: "data:text/html,hi" }), null);
  const item = normalizeItem("lobsters", { title: "T", url: "https://x.dev", score: 5 });
  assert.equal(item.source, "lobsters");
  assert.equal(item.category, "tech");
  assert.equal(item.score, 5);
  assert.match(item.id, /^[0-9a-f]{24}$/);
});

test("parseHnHits falls back to the HN discussion link", () => {
  const rows = parseHnHits({ hits: [{ title: "Show HN", url: null, objectID: "42", points: 7, num_comments: 3, created_at: "2026-08-16T08:00:00Z" }] });
  assert.equal(rows.length, 1);
  assert.equal(rows[0].url, "https://news.ycombinator.com/item?id=42");
  assert.equal(rows[0].score, 7);
  assert.equal(rows[0].comments, 3);
});

test("parseLobsters falls back to the story page", () => {
  const rows = parseLobsters([{ title: "T", url: "", short_id: "abc123", created_at: "2026-08-16T08:00:00Z" }]);
  assert.equal(rows[0].url, "https://lobste.rs/s/abc123");
});

// ── filtering / merging ────────────────────────────────────────────────────

test("filterItems sorts, dedupes and caps", () => {
  const now = Date.now();
  const items = [
    { title: "old", url: "https://x.dev/old", publishedAt: new Date(now - 999 * 60 * 60 * 1000).toISOString() },
    { title: "newer", url: "https://x.dev/newer", publishedAt: new Date(now - 1000).toISOString() },
    { title: "newest", url: "https://x.dev/newest", publishedAt: new Date(now).toISOString() },
  ];
  const rows = filterItems(items, { ...DEFAULT_CONFIG, maxItems: 2 });
  assert.equal(rows.length, 2);
  assert.equal(rows[0].title, "newest");
  assert.equal(rows[1].title, "newer");
});

test("filterItems keeps every source story in 全部 and assigns configured categories", () => {
  const now = new Date().toISOString();
  const items = [
    { title: "OpenAI ships GPT", summary: "model release", source: "hn_ai", url: "https://x.dev/1", publishedAt: now },
    { title: "Rust release", summary: "systems programming", source: "hn_ai", url: "https://x.dev/2", publishedAt: now },
    { title: "OpenAI but sponsored", summary: "sponsored", source: "hn_ai", url: "https://x.dev/3", publishedAt: now },
    { title: "A new laptop", summary: "hardware", source: "hn_front", url: "https://x.dev/4", publishedAt: now },
  ];
  const cfg = {
    ...DEFAULT_CONFIG,
    blockwords: ["sponsored"],
    categories: [
      { id: "ai", name: "AI", keywords: ["OpenAI", "Rust"], sources: ["hn_ai"] },
      { id: "tech", name: "科技", keywords: [], sources: ["hn_front"] },
    ],
  };
  const rows = filterItems(items, cfg);
  assert.deepEqual(rows.map((item) => item.title), ["OpenAI ships GPT", "Rust release", "A new laptop"]);
  assert.deepEqual(rows[0].categories, ["ai"]);
  assert.deepEqual(rows[1].categories, ["ai"]);
  assert.deepEqual(rows[2].categories, ["tech"]);
});

test("assignCategories gates on source membership and keyword boundaries", () => {
  const categories = [
    { id: "ai", name: "AI", keywords: ["AI"], sources: ["hn_ai"] },
    { id: "tech", name: "科技", keywords: [], sources: ["hn_front"] },
    { id: "life", name: "生活", keywords: [], sources: ["hn_ai"] },
  ];
  assert.deepEqual(assignCategories({ source: "hn_ai", title: "AI safety report", summary: "" }, categories), ["ai", "life"]);
  assert.deepEqual(assignCategories({ source: "hn_ai", title: "Air conditioner review", summary: "" }, categories), ["life"]);
  assert.deepEqual(assignCategories({ source: "hn_front", title: "Email client update", summary: "" }, categories), ["tech"]);
  assert.deepEqual(assignCategories({ source: "sspai", title: "AI 生活", summary: "" }, categories), []);
  const withDisabled = [
    { id: "ai", name: "AI", enabled: true, keywords: [], sources: ["hn_ai"] },
    { id: "tech", name: "科技", enabled: false, keywords: [], sources: ["hn_front"] },
  ];
  assert.deepEqual(assignCategories({ source: "hn_ai", title: "AI", summary: "" }, withDisabled), ["ai"]);
  assert.deepEqual(assignCategories({ source: "hn_front", title: "Tech", summary: "" }, withDisabled), []);
});

test("disabled categories hide their exclusive sources and are not fetched", () => {
  const now = new Date().toISOString();
  const categories = [
    { id: "ai", name: "AI", enabled: true, keywords: [], sources: ["hn_ai"] },
    { id: "tech", name: "科技", enabled: false, keywords: [], sources: ["hn_front"] },
    { id: "game", name: "游戏", enabled: true, keywords: [], sources: [] },
    { id: "life", name: "生活", enabled: true, keywords: [], sources: [] },
  ];
  const rows = filterItems([
    { title: "AI story", source: "hn_ai", url: "https://x.dev/ai", publishedAt: now },
    { title: "Tech story", source: "hn_front", url: "https://x.dev/tech", publishedAt: now },
  ], { ...DEFAULT_CONFIG, categories });
  assert.deepEqual(rows.map((item) => item.title), ["AI story"]);
  assert.deepEqual(rows[0].categories, ["ai"]);
});

test("mergeItems dedupes by canonical url", () => {
  const merged = mergeItems([
    [{ title: "A", url: "https://x.dev/a#one" }],
    [{ title: "A duplicate", url: "https://x.dev/a" }],
  ]);
  assert.equal(merged.length, 1);
});

// ── translation helpers ────────────────────────────────────────────────────

test("translation helpers detect CJK and attach cached translations", () => {
  assert.equal(hasCjk("OpenAI ships GPT"), false);
  assert.equal(hasCjk("OpenAI 发布新模型"), true);
  assert.equal(needsTranslation("OpenAI ships GPT"), true);
  assert.equal(needsTranslation("OpenAI 发布新模型"), false);
  assert.equal(needsTranslation(""), false);

  const rows = attachTranslations([
    { id: "a", title: "English title", summary: "English summary", titleZh: "stale" },
    { id: "b", title: "中文标题", summary: "中文摘要" },
  ], new Map([["a", { titleZh: "英文标题", summaryZh: "英文摘要" }]]));
  assert.equal(rows[0].titleZh, "英文标题");
  assert.equal(rows[0].summaryZh, "英文摘要");
  assert.equal(rows[1].titleZh, undefined);

  const seeded = seedTranslations(rows);
  assert.deepEqual(seeded.get("a"), { titleZh: "英文标题", summaryZh: "英文摘要" });
});

test("parseTranslationReply accepts bare or fenced JSON", () => {
  const rows = parseTranslationReply('```json\n{"items":[{"id":"a","title":"标题","summary":"摘要"}]}\n```');
  assert.equal(rows.get("a").titleZh, "标题");
  assert.equal(rows.get("a").summaryZh, "摘要");
  assert.equal(parseTranslationReply("not json"), undefined);
  assert.equal(parseTranslationReply('{"items":[]}'), undefined);
});

test("buildFetchPlan exposes one fetcher per expanded source registry", () => {
  const plan = buildFetchPlan();
  for (const id of SOURCE_IDS) assert.equal(typeof plan[id], "function", `missing fetcher: ${id}`);
  assert.equal(Object.keys(plan).length, SOURCE_IDS.length);
  assert.ok(SOURCE_IDS.includes("gcores"));
  assert.ok(SOURCE_IDS.includes("yystv"));
  assert.ok(SOURCE_IDS.includes("toodaylab"));
  assert.ok(SOURCE_IDS.includes("atlasobscura"));
});

// ── Host routes (0.2.1 connection.fetch) ───────────────────────────────────

function makeContext() {
  const routes = new Map();
  const disposers = [];
  const ctx = {
    logger: { debug() {}, warn() {}, info() {} },
    effect(fn) {
      const disposer = fn();
      if (typeof disposer === "function") disposers.push(disposer);
    },
    get() { return undefined; },
    connection: {
      fetch: {
        register(entry) {
          routes.set(entry.path, entry);
          return () => routes.delete(entry.path);
        },
      },
    },
  };
  return { ctx, routes, dispose() { for (const dispose of disposers) dispose(); } };
}

function requestFor(path, options = {}) {
  return new Request(`http://localhost${path}`, options);
}

async function call(routes, path, options) {
  const route = routes.get(path);
  assert.ok(route, `route missing: ${path}`);
  return route.fetch(requestFor(path, options));
}

const allSourcesOff = Object.fromEntries(SOURCE_IDS.map((id) => [id, false]));

test("host registers the authenticated /api routes", async () => {
  const directory = await mkdtemp(join(tmpdir(), "dsh-newsboard-host-"));
  const harness = makeContext();
  try {
    const plugin = apply(harness.ctx, { directory, sources: allSourcesOff });
    await plugin.ready;
    for (const path of [
      `${API_PREFIX}/config`,
      `${API_PREFIX}/feed`,
      `${API_PREFIX}/refresh`,
      `${API_PREFIX}/logs/translation`,
      `${API_PREFIX}/logs/fetch`,
    ]) {
      assert.ok(harness.routes.has(path), `missing registry key ${path}`);
    }
  } finally {
    harness.dispose();
    await new Promise((resolve) => setTimeout(resolve, 50));
    await rm(directory, { recursive: true, force: true });
  }
});

test("config and feed routes round-trip over the Fetch surface", async () => {
  const directory = await mkdtemp(join(tmpdir(), "dsh-newsboard-host-"));
  const harness = makeContext();
  try {
    const plugin = apply(harness.ctx, { directory, sources: allSourcesOff });
    await plugin.ready;

    const configResponse = await call(harness.routes, `${API_PREFIX}/config`);
    assert.equal(configResponse.status, 200);
    assert.equal(configResponse.headers.get("cache-control"), "no-store");
    const config = await configResponse.json();
    assert.equal(config.ok, true);
    assert.equal(config.config.categories.length, 4);
    for (const category of config.config.categories) assert.deepEqual(category.sources, []);
    assert.deepEqual(config.sourceIds, SOURCE_IDS);
    assert.deepEqual(config.secretSet, { translationSecretKey: false, translationApiKey: false });
    assert.equal(config.revision, 0);
    assert.equal("sources" in config.config, false);
    assert.equal("keywords" in config.config, false);

    const postedResponse = await call(harness.routes, `${API_PREFIX}/config`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        config: {
          refreshMinutes: 7,
          categories: [
            { id: "ai", name: "AI", keywords: ["AI"], sources: [] },
            { id: "tech", name: "科技", keywords: ["芯片"], sources: [] },
            { id: "game", name: "游戏", keywords: ["RPG"], sources: [] },
            { id: "life", name: "生活", keywords: ["生活"], sources: [] },
            { id: "games", name: "游戏精选", keywords: ["RPG"], sources: [] },
          ],
        },
        expectedRevision: 0,
      }),
    });
    assert.equal(postedResponse.status, 200);
    const posted = await postedResponse.json();
    assert.equal(posted.revision, 1);
    assert.equal(posted.config.refreshMinutes, 7);
    assert.equal(posted.config.categories.length, 5);
    assert.deepEqual(posted.config.categories.find((entry) => entry.id === "ai"), {
      id: "ai", name: "AI", enabled: true, keywords: ["AI"], sources: [],
    });
    assert.deepEqual(posted.config.categories.find((entry) => entry.id === "games"), {
      id: "games", name: "游戏精选", enabled: true, keywords: ["RPG"], sources: [],
    });
    for (const id of ["tech", "game", "life"]) {
      assert.ok(posted.config.categories.some((entry) => entry.id === id), `preset ${id} restored`);
    }
    assert.equal(posted.config.translate, true);
    const onDisk = JSON.parse(await readFile(join(directory, "config.json"), "utf8"));
    assert.equal(onDisk.refreshMinutes, 7);
    assert.equal(onDisk.categories.length, 5);

    const staleResponse = await call(harness.routes, `${API_PREFIX}/config`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ config: { refreshMinutes: 9 }, expectedRevision: 0 }),
    });
    assert.equal(staleResponse.status, 409);
    const stale = await staleResponse.json();
    assert.equal(stale.error.code, "STALE_CONFIG");
    assert.equal(stale.revision, 1);

    const secretResponse = await call(harness.routes, `${API_PREFIX}/config`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        config: { translationAppId: "app-1", translationSecretKey: "hunter2" },
        expectedRevision: 1,
      }),
    });
    const secretBody = await secretResponse.json();
    assert.equal(secretResponse.status, 200);
    assert.equal(secretBody.config.translationSecretKey, "", "secrets never ride the wire");
    assert.equal(secretBody.secretSet.translationSecretKey, true);
    const configAfterSecret = await (await call(harness.routes, `${API_PREFIX}/config`)).json();
    assert.equal(configAfterSecret.config.translationSecretKey, "");
    assert.equal(configAfterSecret.secretSet.translationSecretKey, true);
    assert.equal(configAfterSecret.revision, 2);
    assert.equal(secretBody.config.translationAppId, "app-1");

    const unknownResponse = await call(harness.routes, `${API_PREFIX}/config`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ config: { nope: true }, expectedRevision: 2 }),
    });
    assert.equal(unknownResponse.status, 400);
    assert.equal((await unknownResponse.json()).error.code, "UNKNOWN_CONFIG_KEY");

    const feedResponse = await call(harness.routes, `${API_PREFIX}/feed`);
    assert.equal(feedResponse.status, 200);
    const feed = await feedResponse.json();
    assert.equal(feed.ok, true);
    assert.ok(Array.isArray(feed.items));
    assert.equal(typeof feed.refreshedAt, "number");
    assert.equal(feed.refreshMinutes, 7);
    assert.equal(feed.categories.length, 5);
    assert.equal(feed.categories[0].id, "ai");

    const refreshResponse = await call(harness.routes, `${API_PREFIX}/refresh`, { method: "POST" });
    assert.equal(refreshResponse.status, 200);
    assert.equal((await refreshResponse.json()).ok, true);

    const logsResponse = await call(harness.routes, `${API_PREFIX}/logs/fetch`);
    const logs = await logsResponse.json();
    assert.equal(logs.ok, true);
    assert.equal(logs.type, "fetch");
    assert.ok(Array.isArray(logs.logs));
  } finally {
    harness.dispose();
    await new Promise((resolve) => setTimeout(resolve, 100));
    await rm(directory, { recursive: true, force: true });
  }
});

test("legacy config.json.migrated is imported by the host at boot", async () => {
  const directory = await mkdtemp(join(tmpdir(), "dsh-newsboard-host-"));
  const { writeFile } = await import("node:fs/promises");
  await writeFile(join(directory, "config.json.migrated"), JSON.stringify({
    maxItems: 35,
    sources: allSourcesOff,
  }));
  const harness = makeContext();
  try {
    const plugin = apply(harness.ctx, { directory });
    await plugin.ready;
    const response = await call(harness.routes, `${API_PREFIX}/config`);
    const config = await response.json();
    assert.equal(config.config.maxItems, 35);
    assert.equal(config.config.categories.length, 4);
    for (const category of config.config.categories) assert.deepEqual(category.sources, []);
    const persisted = JSON.parse(await readFile(join(directory, "config.json"), "utf8"));
    assert.equal(persisted.maxItems, 35);
    assert.equal(persisted.categories.length, 4);
  } finally {
    harness.dispose();
    await new Promise((resolve) => setTimeout(resolve, 100));
    await rm(directory, { recursive: true, force: true });
  }
});
