import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { normalizeConfig } from "../lib/config.js";
import { createConfigStore } from "../lib/store.js";

async function tempDir() {
  return mkdtemp(join(tmpdir(), "dsh-newsboard-store-"));
}

test("load creates the state directory and starts from the entry config", async () => {
  const directory = await tempDir();
  try {
    const store = createConfigStore({ directory, baseConfig: { maxItems: 25 } });
    const config = await store.load();
    assert.equal(config.maxItems, 25);
    assert.equal(store.getRevision(), 0);
    const info = await stat(directory);
    assert.equal(info.mode & 0o777, 0o700);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("save persists a partial patch atomically and bumps the revision", async () => {
  const directory = await tempDir();
  try {
    const store = createConfigStore({ directory });
    await store.load();
    const first = await store.save({
      maxItems: 42,
      categories: [{ id: "ai", name: "AI", keywords: ["AI"], sources: ["hn_ai"] }],
    }, { expectedRevision: 0 });
    assert.equal(first.revision, 1);
    assert.equal(first.config.maxItems, 42);

    const raw = JSON.parse(await readFile(join(directory, "config.json"), "utf8"));
    assert.equal(raw.maxItems, 42);
    assert.deepEqual(raw.categories.find((entry) => entry.id === "ai"), {
      id: "ai", name: "AI", enabled: true, keywords: ["AI"], sources: ["hn_ai"],
    });
    for (const id of ["tech", "game", "life"]) {
      assert.ok(raw.categories.some((entry) => entry.id === id), `preset ${id} restored`);
    }

    const info = await stat(join(directory, "config.json"));
    assert.equal(info.mode & 0o777, 0o600);

    // A fresh store reads the persisted document back.
    const reloaded = createConfigStore({ directory });
    const config = await reloaded.load();
    assert.equal(config.maxItems, 42);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("a stale expectedRevision is rejected without writing", async () => {
  const directory = await tempDir();
  try {
    const store = createConfigStore({ directory });
    await store.load();
    await store.save({ maxItems: 42 }, { expectedRevision: 0 });
    await assert.rejects(
      () => store.save({ maxItems: 99 }, { expectedRevision: 0 }),
      (error) => {
        assert.equal(error.code, "STALE_CONFIG");
        assert.equal(error.state.revision, 1);
        assert.equal(error.state.config.maxItems, 42);
        return true;
      },
    );
    const raw = JSON.parse(await readFile(join(directory, "config.json"), "utf8"));
    assert.equal(raw.maxItems, 42, "stale write did not touch disk");
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("concurrent saves sharing one expectedRevision cannot both commit", async () => {
  const directory = await tempDir();
  try {
    const store = createConfigStore({ directory });
    await store.load();
    const results = await Promise.allSettled([
      store.save({ maxItems: 70 }, { expectedRevision: 0 }),
      store.save({ maxItems: 80 }, { expectedRevision: 0 }),
    ]);
    const fulfilled = results.filter((entry) => entry.status === "fulfilled");
    const rejected = results.filter((entry) => entry.status === "rejected");
    assert.equal(fulfilled.length, 1);
    assert.equal(rejected.length, 1);
    assert.equal(rejected[0].reason.code, "STALE_CONFIG");
    assert.equal(store.getRevision(), 1);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("blank secrets keep the stored credential and secretSet reports it", async () => {
  const directory = await tempDir();
  try {
    const store = createConfigStore({ directory });
    await store.load();
    await store.save({ translationAppId: "app", translationSecretKey: "hunter2" }, { expectedRevision: 0 });
    assert.deepEqual(store.state().secretSet, { translationSecretKey: true, translationApiKey: false });
    assert.equal(store.state().config.translationSecretKey, "", "wire view blanks the secret");

    await store.save({ translationAppId: "app-2", translationSecretKey: "" }, { expectedRevision: 1 });
    assert.equal(store.get().translationSecretKey, "hunter2");
    assert.equal(store.get().translationAppId, "app-2");

    await store.save({ translationSecretKey: "" }, { expectedRevision: 2, clearSecrets: ["translationSecretKey"] });
    assert.equal(store.get().translationSecretKey, "");
    assert.equal(store.state().secretSet.translationSecretKey, false);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("a legacy config.json is persisted as the category model on load", async () => {
  const directory = await tempDir();
  try {
    await writeFile(join(directory, "config.json"), JSON.stringify({
      maxItems: 33,
      keywords: ["DeepSeek"],
      sources: { hn_front: false, hn_ai: true },
      translationAppId: "legacy-app",
    }));
    const store = createConfigStore({ directory });
    const config = await store.load();
    assert.equal(config.maxItems, 33);
    assert.equal(config.categories.length, 4);
    assert.equal(config.categories.find((entry) => entry.id === "ai").sources.includes("hn_ai"), true);
    assert.equal(config.categories.find((entry) => entry.id === "tech").sources.includes("hn_front"), false);
    const persisted = JSON.parse(await readFile(join(directory, "config.json"), "utf8"));
    assert.equal("keywords" in persisted, false);
    assert.equal("sources" in persisted, false);
    assert.equal(persisted.categories.length, 4);
    assert.equal(persisted.categories.find((entry) => entry.id === "ai").keywords.includes("OpenAI"), true);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("config.json.migrated is imported once when config.json is missing", async () => {
  const directory = await tempDir();
  try {
    await writeFile(join(directory, "config.json.migrated"), JSON.stringify({
      refreshMinutes: 9,
      maxItems: 33,
      keywords: ["DeepSeek"],
      translationAppId: "legacy-app",
      translationSecretKey: "legacy-secret",
      sources: { hn_front: false },
    }));
    const store = createConfigStore({ directory, baseConfig: { maxAgeHours: 24 } });
    const config = await store.load();
    assert.equal(config.refreshMinutes, 9);
    assert.equal(config.maxItems, 33);
    assert.equal(config.maxAgeHours, 24);
    assert.equal(config.categories.find((entry) => entry.id === "tech").sources.includes("hn_front"), false);
    assert.equal(config.translationSecretKey, "legacy-secret");

    const persisted = JSON.parse(await readFile(join(directory, "config.json"), "utf8"));
    assert.equal(persisted.maxItems, 33);
    assert.ok(Array.isArray(persisted.categories));
    // The backup stays for a manual rollback.
    await readFile(join(directory, "config.json.migrated"), "utf8");
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("a corrupt config.json falls back to the entry config instead of crashing", async () => {
  const directory = await tempDir();
  try {
    await writeFile(join(directory, "config.json"), "{not json");
    await writeFile(join(directory, "config.json.migrated"), JSON.stringify({ maxItems: 77 }));
    const warnings = [];
    const store = createConfigStore({
      directory,
      baseConfig: { maxItems: 11 },
      logger: { warn(message) { warnings.push(message); }, info() {} },
    });
    const config = await store.load();
    assert.equal(config.maxItems, 11, "corrupt config must not import the archived document");
    assert.ok(warnings.some((message) => message.includes("corrupt config")));
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("unknown config keys are rejected by the store", async () => {
  const directory = await tempDir();
  try {
    const store = createConfigStore({ directory });
    await store.load();
    await assert.rejects(
      () => store.save({ nonsense: true }, { expectedRevision: 0 }),
      (error) => error.code === "UNKNOWN_CONFIG_KEY",
    );
    assert.equal(store.getRevision(), 0);
    assert.deepEqual(store.get(), normalizeConfig({}));
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});
