import { test } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import vm from "node:vm";

import { CONFIG_SECTION_KEYS, DEFAULT_CATEGORIES, SOURCE_IDS } from "../lib/config.js";

const here = fileURLToPath(new URL(".", import.meta.url));
const source = await readFile(join(here, "..", "lib", "client.js"), "utf8");

function extractObjectLiteral(startIndex) {
  const open = source.indexOf("{", startIndex);
  assert.notEqual(open, -1, "object literal not found");
  let quote = "";
  let escaped = false;
  let depth = 0;
  for (let index = open; index < source.length; index += 1) {
    const char = source[index];
    if (quote !== "") {
      if (escaped) escaped = false;
      else if (char === "\\") escaped = true;
      else if (char === quote) quote = "";
      continue;
    }
    if (char === '"' || char === "'" || char === "`") quote = char;
    else if (char === "{") depth += 1;
    else if (char === "}") {
      depth -= 1;
      if (depth === 0) return source.slice(open, index + 1);
    }
  }
  throw new Error("unterminated object literal");
}

function extractDict() {
  const marker = source.indexOf("var DICT = {");
  assert.notEqual(marker, -1, "DICT not found");
  return Function(`"use strict"; return (${extractObjectLiteral(marker)});`)();
}

function loadClient() {
  let descriptor = null;
  const styles = [];
  const head = { appendChild(node) { styles.push(node); } };
  const context = {
    console,
    window: { __ModuleLoader__: { load(entry) { descriptor = entry; } } },
    document: {
      querySelector() { return null; },
      createElement() { return { setAttribute() {}, textContent: "" }; },
      head,
    },
  };
  vm.runInNewContext(source, context, { filename: "lib/client.js" });
  assert.ok(descriptor, "__ModuleLoader__.load was not called");

  const React = {
    Component: class { constructor(props) { this.props = props; this.state = {}; } setState() {} },
    createElement: (type, props, ...children) => ({ type, props: props || {}, children }),
    useSyncExternalStore: () => ({}),
    useState: () => [null, () => {}],
    useEffect: () => {},
    useCallback: (fn) => fn,
    useRef: (value) => ({ current: value }),
  };
  const exports = descriptor.factory((name) => {
    if (name === "react") return React;
    if (name === "react-dom") throw new Error("react-dom unavailable in test");
    throw new Error(`unexpected require: ${name}`);
  });
  return { descriptor, exports, styles };
}

test("client dictionary has 1:1 zh/en keys, every source and its leaning", () => {
  const dict = extractDict();
  const zh = Object.keys(dict.zh).sort();
  const en = Object.keys(dict.en).sort();
  assert.deepEqual(zh, en, "zh and en keys must be identical");
  for (const id of SOURCE_IDS) {
    assert.ok(zh.includes("source_" + id), `missing source label: source_${id}`);
    assert.ok(zh.includes("sourceDesc_" + id), `missing source description: sourceDesc_${id}`);
    assert.ok(en.includes("sourceDesc_" + id), `missing English description: sourceDesc_${id}`);
  }
  for (const id of DEFAULT_CATEGORIES.map((entry) => entry.id)) {
    assert.ok(zh.includes("category_" + id), `missing category label: category_${id}`);
  }
  assert.equal(dict.zh.panel, "快讯看板");
  assert.equal(dict.zh.pageTitle, "快讯看板");
  assert.equal(dict.zh.tab_all, "全部");
  assert.equal(dict.zh.tab_settings, "设置");
  assert.equal(dict.zh.category_game, "游戏");
  assert.equal(dict.en.category_game, "Games");
  assert.equal(dict.zh.categoryPreset, "预设");
  assert.equal(dict.zh.categoryDeleteTitle, "删除分类");
  assert.equal(typeof dict.zh.categoryDeleteMessage, "string");
  assert.equal(typeof dict.zh.categoryEnabledLabel, "string");
  assert.equal(dict.en.categoryDisabled, "Disabled");
  assert.equal("pageIntro" in dict.zh, false, "the old page intro was removed");
  assert.equal("settingsIntro" in dict.zh, false, "the old settings lead was removed");
  assert.equal("keywords" in dict.zh, false, "global include keywords were replaced by category keywords");
  for (const code of [
    "NETWORK_ERROR", "INVALID_JSON", "INVALID_CONFIG", "UNKNOWN_CONFIG_KEY",
    "STALE_CONFIG", "PAYLOAD_TOO_LARGE", "STORAGE_FAILED", "METHOD_NOT_ALLOWED",
    "INTERNAL_ERROR",
  ]) {
    assert.ok(zh.includes("error_" + code), `missing error translation: ${code}`);
  }
});

test("client bundle registers under the package id and exports a Cordis plugin", () => {
  const { descriptor, exports } = loadClient();
  assert.equal(descriptor.id, "dsh-plugin-newsboard");
  assert.equal(exports.name, "dsh-plugin-newsboard");
  assert.deepEqual(Array.from(exports.inject), ["slots", "locale", "layout"]);
  assert.equal(exports.PAGE_ID, "newsboard");
  assert.equal(exports.ALL_TAB, "all");
  assert.equal(exports.SETTINGS_TAB, "settings");
  assert.deepEqual(Array.from(exports.SOURCE_ORDER), [...SOURCE_IDS]);
  assert.deepEqual(Array.from(exports.FALLBACK_CATEGORIES).map((entry) => entry.id), DEFAULT_CATEGORIES.map((entry) => entry.id));
  assert.deepEqual(
    Array.from(exports.TAB_SECTIONS.settings).sort(),
    [...CONFIG_SECTION_KEYS].sort(),
    "the settings tab must save exactly the host's config keys",
  );
  assert.equal(typeof exports.apply, "function");
  assert.equal(typeof exports.NewsPage, "function");
  assert.equal(typeof exports.PageTabs, "function");
  assert.equal(typeof exports.SettingsPanel, "function");
  assert.equal(typeof exports.NewsBoardIcon, "function");
  assert.equal(typeof exports.countUnread, "function");
});

test("apply registers the sidebar entry and the keyed main page only", () => {
  const { exports } = loadClient();
  const registrations = [];
  const slots = {
    inject(slot, factory) {
      registrations.push({ slot, entry: factory() });
    },
    register(options, Component) {
      return { options, Component };
    },
  };
  const locale = {
    bind() { return (key) => extractDict().zh[key] ?? key; },
    register() { return () => {}; },
  };
  const ctx = {
    effect(fn) { fn(); },
    get(name) {
      if (name === "slots") return slots;
      if (name === "locale") return locale;
      return undefined;
    },
  };
  exports.apply(ctx);

  assert.deepEqual(registrations.map((entry) => entry.slot), ["main", "sidebar.panellist"]);
  const main = registrations[0].entry.options;
  assert.equal(main.name, "main");
  assert.equal(main.key, "newsboard");
  assert.equal(main.locale, "dsh-plugin-newsboard");
  const sidebar = registrations[1].entry.options;
  assert.equal(sidebar.name, "sidebar.panellist");
  assert.equal(sidebar.id, "newsboard");
  assert.equal(sidebar.id, main.key);
  assert.equal(sidebar.order, 30);
  assert.equal(sidebar.label(), "快讯看板");
  assert.equal(typeof registrations[1].entry.Component, "function");
  assert.equal(registrations.some((entry) => entry.slot === "shell.overlay"), false);
  assert.equal(registrations.some((entry) => entry.slot === "settings.section"), false);
});

test("client CSS keeps the fixed shell and adds unread/category styles", () => {
  const { styles } = loadClient();
  assert.equal(styles.length, 1);
  const css = styles[0].textContent;
  assert.match(css, /\.dsh-newsboard-page\{[^}]*height:100%[^}]*overflow:hidden/);
  assert.match(css, /\.dsh-newsboard-inner\{[^}]*max-width:1056px[^}]*min-height:0/);
  assert.match(css, /\.dsh-newsboard-scroll\{[^}]*flex:1[^}]*min-height:0[^}]*overflow-y:auto/);
  assert.match(css, /\[data-platform=darwin\] \.dsh-newsboard-head\{padding-top:calc\(28px \+ var\(--dsh-frame-top-clearance/);
  assert.match(css, /\.dsh-newsboard-tabs-row\{[^}]*min-height:44px/);
  assert.match(css, /\.dsh-newsboard-tab-actions\{[^}]*min-height:44px[^}]*padding-bottom:8px/);
  assert.match(css, /\.dsh-newsboard-tabpanel\[hidden\]\{display:none!important;?\}/);
  assert.match(css, /\.dsh-newsboard-new-badge\{/);
  assert.match(css, /\.dsh-newsboard-matrix\{display:grid/);
  assert.match(css, /\.dsh-newsboard-matrix-source-desc\{/);
  assert.match(css, /\.dsh-newsboard-side-count\{[^}]*box-sizing:border-box[^}]*min-width:16px/);
  assert.match(css, /button:has\(\.dsh-newsboard-side-count\)/);
  assert.match(css, /\.dsh-newsboard-category-editor-disabled\{/);
  assert.match(css, /\.dsh-newsboard-btn\.dsh-newsboard-btn-danger\{[^}]*background:var\(--dsw-alias-state-error-primary\)/);
  assert.match(css, /\.dsh-newsboard-matrix-headcell-disabled\{/);
  assert.match(css, /\.dsh-newsboard-card-new\{/);
  assert.match(css, /\.dsh-newsboard-new-tag\{/);
  assert.match(css, /\.dsh-newsboard-overlay\{[^}]*background:rgba\(0,0,0,\.45\)/);
});
