import { test } from "node:test";
import assert from "node:assert/strict";

import {
  API_PREFIX,
  MAX_CONFIG_BYTES,
  createFetchRoutes,
  jsonResponse,
  readJsonBody,
} from "../lib/connection-routes.js";

function makeHandlers(overrides = {}) {
  return {
    getConfig: async () => jsonResponse(200, { ok: true, config: {}, revision: 0 }),
    postConfig: async (request) => {
      const body = await readJsonBody(request, MAX_CONFIG_BYTES);
      return jsonResponse(200, { ok: true, echo: body });
    },
    getFeed: async () => jsonResponse(200, { ok: true, items: [] }),
    postRefresh: async () => jsonResponse(200, { ok: true, items: [] }),
    getLogs: async (request, type) => jsonResponse(200, { ok: true, type, logs: [] }),
    ...overrides,
  };
}

function routes(overrides) {
  const table = createFetchRoutes(makeHandlers(overrides));
  return new Map(table.map((entry) => [entry.path, entry]));
}

function post(path, body, headers = {}) {
  return new Request(`http://localhost${path}`, {
    method: "POST",
    headers: { "content-type": "application/json", ...headers },
    body: typeof body === "string" ? body : JSON.stringify(body),
  });
}

test("every route path includes the /api prefix and the expected methods", () => {
  const table = routes();
  assert.deepEqual([...table.keys()], [
    `${API_PREFIX}/config`,
    `${API_PREFIX}/feed`,
    `${API_PREFIX}/refresh`,
    `${API_PREFIX}/logs/translation`,
    `${API_PREFIX}/logs/fetch`,
  ]);
  for (const path of table.keys()) assert.ok(path.startsWith("/api/"), path);
  assert.deepEqual(table.get(`${API_PREFIX}/config`).methods, ["GET", "POST"]);
  assert.deepEqual(table.get(`${API_PREFIX}/feed`).methods, ["GET"]);
  assert.deepEqual(table.get(`${API_PREFIX}/refresh`).methods, ["POST"]);
  assert.equal(table.get(`${API_PREFIX}/config`).requestBody, "buffered");
});

test("GET config returns a no-store JSON envelope", async () => {
  const route = routes().get(`${API_PREFIX}/config`);
  const response = await route.fetch(new Request(`http://localhost${route.path}`));
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("cache-control"), "no-store");
  assert.match(response.headers.get("content-type"), /application\/json/);
  const body = await response.json();
  assert.equal(body.ok, true);
  assert.equal(body.revision, 0);
});

test("POST config buffers and parses a JSON body", async () => {
  const route = routes().get(`${API_PREFIX}/config`);
  const response = await route.fetch(post(route.path, { config: { maxItems: 42 }, expectedRevision: 3 }));
  assert.equal(response.status, 200);
  assert.deepEqual((await response.json()).echo, { config: { maxItems: 42 }, expectedRevision: 3 });
});

test("method mismatch returns 405 with an Allow header", async () => {
  const route = routes().get(`${API_PREFIX}/feed`);
  const response = await route.fetch(new Request(`http://localhost${route.path}`, { method: "POST" }));
  assert.equal(response.status, 405);
  assert.equal(response.headers.get("allow"), "GET");
  assert.equal((await response.json()).error.code, "METHOD_NOT_ALLOWED");
});

test("invalid JSON returns 400 INVALID_JSON", async () => {
  const route = routes().get(`${API_PREFIX}/config`);
  const response = await route.fetch(post(route.path, "{not json"));
  assert.equal(response.status, 400);
  assert.equal((await response.json()).error.code, "INVALID_JSON");
});

test("oversized bodies return 413 PAYLOAD_TOO_LARGE", async () => {
  const route = routes().get(`${API_PREFIX}/config`);
  const response = await route.fetch(post(route.path, { blob: "x".repeat(MAX_CONFIG_BYTES + 10) }));
  assert.equal(response.status, 413);
  assert.equal((await response.json()).error.code, "PAYLOAD_TOO_LARGE");
});

test("a stale revision surfaces 409 with the current wire state", async () => {
  const route = routes({
    postConfig: async () => {
      const error = new Error("stale");
      error.code = "STALE_CONFIG";
      error.state = { config: { maxItems: 60 }, secretSet: {}, revision: 4 };
      throw error;
    },
  }).get(`${API_PREFIX}/config`);
  const response = await route.fetch(post(route.path, { config: { maxItems: 10 }, expectedRevision: 1 }));
  assert.equal(response.status, 409);
  const body = await response.json();
  assert.equal(body.error.code, "STALE_CONFIG");
  assert.equal(body.revision, 4);
  assert.equal(body.config.maxItems, 60);
});

test("unknown config keys keep their stable 400 code and key", async () => {
  const route = routes({
    postConfig: async () => {
      const error = new Error("unknown");
      error.code = "UNKNOWN_CONFIG_KEY";
      error.key = "nope";
      throw error;
    },
  }).get(`${API_PREFIX}/config`);
  const response = await route.fetch(post(route.path, { config: { nope: true } }));
  assert.equal(response.status, 400);
  assert.deepEqual((await response.json()).error, { code: "UNKNOWN_CONFIG_KEY", key: "nope" });
});

test("logs routes dispatch with the requested type", async () => {
  const table = routes();
  for (const type of ["translation", "fetch"]) {
    const route = table.get(`${API_PREFIX}/logs/${type}`);
    const response = await route.fetch(new Request(`http://localhost${route.path}`));
    assert.equal(response.status, 200);
    assert.equal((await response.json()).type, type);
  }
});

test("readJsonBody enforces the content-length precheck", async () => {
  const request = new Request("http://localhost/x", {
    method: "POST",
    headers: { "content-length": String(MAX_CONFIG_BYTES + 1) },
    body: "{}",
  });
  await assert.rejects(() => readJsonBody(request), (error) => error.code === "PAYLOAD_TOO_LARGE");
});
