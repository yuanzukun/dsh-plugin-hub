import { test } from "node:test";
import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("..", import.meta.url));

async function manifest() {
  return JSON.parse(await readFile(join(root, "package.json"), "utf8"));
}

test("package manifest declares the dual-face bundle contract", async () => {
  const pkg = await manifest();
  assert.equal(pkg.name, "dsh-plugin-newsboard");
  assert.equal(pkg.type, "module");
  assert.equal(pkg.main, "lib/index.js");
  assert.equal(pkg.exports["./client"].default, "./lib/client.js");
  assert.equal(pkg.exports["./package.json"], "./package.json");
  assert.equal(pkg.exports["./cordis.patch.yml"].default, "./cordis.patch.yml");
  assert.equal(pkg.dsh.client.platform, "web");
  assert.equal(pkg.dsh.client.immediately, true);
  assert.equal(pkg.dsh.bundle.patch, "./cordis.patch.yml");
  assert.equal(pkg.engines.dsh, ">=0.2.1-rc.2 <0.3.0-0");
  assert.equal(pkg.dependencies, undefined, "0.2.1 target has no runtime dependency");
  for (const file of [
    "lib/index.js",
    "lib/client.js",
    "lib/config.js",
    "lib/store.js",
    "lib/connection-routes.js",
    "cordis.patch.yml",
    "README-en.md",
  ]) {
    assert.ok(pkg.files.includes(file), `files must ship ${file}`);
    await access(join(root, file));
  }
});

test("cordis.patch.yml inserts exactly the package row", async () => {
  const patch = await readFile(join(root, "cordis.patch.yml"), "utf8");
  const rows = patch.split("\n").filter((line) => line.trim().startsWith("- id:"));
  assert.deepEqual(rows.map((line) => line.trim()), ["- id: dsh-plugin-newsboard"]);
  assert.match(patch, /name: ['"]dsh-plugin-newsboard['"]/);
});
