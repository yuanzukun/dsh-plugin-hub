import { test } from "node:test";
import assert from "node:assert/strict";

import {
  CONFIG_SECTION_KEYS,
  DEFAULT_CATEGORIES,
  DEFAULT_CONFIG,
  PRESET_CATEGORY_IDS,
  SOURCE_IDS,
  enabledSourceIds,
  mergeConfigPatch,
  mergeSecrets,
  mergeStoredConfig,
  normalizeCategories,
  normalizeConfig,
  redactConfig,
  sliceConfig,
} from "../lib/config.js";

test("normalizeConfig merges defaults and clamps numeric fields", () => {
  const cfg = normalizeConfig({ refreshMinutes: 0, maxItems: 9999, maxAgeHours: 0 });
  assert.equal(cfg.refreshMinutes, 1);
  assert.equal(cfg.maxItems, 200);
  assert.equal(cfg.maxAgeHours, 1);
  assert.equal(cfg.categories.length, DEFAULT_CATEGORIES.length);
  assert.deepEqual(cfg.categories.map((entry) => entry.id), [...PRESET_CATEGORY_IDS]);
});

test("normalizeConfig keeps every preset category with keywords and sources", () => {
  const cfg = normalizeConfig({});
  for (const category of cfg.categories) {
    assert.ok(category.name.length > 0);
    assert.ok(category.keywords.length > 0, `${category.id} preset must ship keywords`);
    assert.ok(category.sources.length > 0, `${category.id} preset must ship checked channels`);
    for (const source of category.sources) assert.ok(SOURCE_IDS.includes(source));
  }
  const ai = cfg.categories.find((entry) => entry.id === "ai");
  assert.ok(ai.keywords.includes("OpenAI"));
  assert.ok(ai.sources.includes("openai_news"));
  const life = cfg.categories.find((entry) => entry.id === "life");
  assert.ok(life.keywords.includes("生活"));
  assert.ok(life.keywords.includes("旅行"));
});

test("normalizeConfig sanitizes blockwords and provider enums", () => {
  const cfg = normalizeConfig({
    blockwords: [" spam ", "spam", 42, "广告"],
    translationProvider: "BAIDU",
    translationBaiduMode: "unknown",
  });
  assert.deepEqual(cfg.blockwords, ["spam", "广告"]);
  assert.equal(cfg.translationProvider, "baidu");
  assert.equal(cfg.translationBaiduMode, DEFAULT_CONFIG.translationBaiduMode);
});

test("normalizeCategories keeps ids unique, filters unknown sources and restores missing presets", () => {
  const categories = normalizeCategories([
    { id: "ai", name: " AI ", keywords: [" GPT ", "GPT", 42], sources: ["openai_news", "nope", "openai_news"] },
    { id: "ai", name: "Second", keywords: [], sources: ["hn_ai"] },
    { id: "game", name: "", keywords: [], sources: [] },
    { id: "life", name: "Life", keywords: [], sources: [] },
    { id: "extra1", name: "X1", keywords: [], sources: [] },
    { id: "extra2", name: "X2", keywords: [], sources: [] },
    { id: "extra3", name: "X3", keywords: [], sources: [] },
    { id: "extra4", name: "X4", keywords: [], sources: [] },
    { id: "extra5", name: "X5", keywords: [], sources: [] },
  ]);
  assert.equal(categories.length, 10);
  assert.deepEqual(categories[0], {
    id: "ai",
    name: "AI",
    enabled: true,
    keywords: ["GPT"],
    sources: ["openai_news"],
  });
  assert.equal(categories[1].id, "ai-2");
  assert.equal(categories[2].name, "分类 3");
  assert.ok(categories.some((entry) => entry.id === "tech"), "missing preset is restored");
  assert.equal(new Set(categories.map((entry) => entry.id)).size, categories.length);
});

test("preset categories cannot be deleted and custom categories are capped", () => {
  const restored = normalizeCategories([{ id: "custom", name: "Custom", keywords: [], sources: [] }]);
  assert.deepEqual(restored.map((entry) => entry.id), ["custom", ...PRESET_CATEGORY_IDS]);
  const many = normalizeCategories(Array.from({ length: 16 }, (_, index) => ({
    id: `custom-${index}`,
    name: `Custom ${index}`,
    keywords: [],
    sources: [],
  })));
  assert.equal(many.length, 12);
  for (const id of PRESET_CATEGORY_IDS) assert.ok(many.some((entry) => entry.id === id), `preset ${id} kept`);
  assert.equal(many.filter((entry) => entry.id.startsWith("custom-")).length, 8);
});

test("legacy top-level sources migrate into preset category channels", () => {
  const cfg = normalizeConfig({
    categories: undefined,
    sources: { hn_front: false, hn_ai: false, verge_ai: true, openai_news: true },
  });
  const tech = cfg.categories.find((entry) => entry.id === "tech");
  const ai = cfg.categories.find((entry) => entry.id === "ai");
  assert.equal(tech.sources.includes("hn_front"), false);
  assert.equal(ai.sources.includes("hn_ai"), false);
  assert.equal(ai.sources.includes("verge_ai"), true);
  assert.equal(ai.sources.includes("openai_news"), true);
  assert.equal("sources" in cfg, false, "legacy sources are not written back");
  assert.equal("keywords" in cfg, false, "legacy keywords are not written back");
});

test("enabledSourceIds ignores disabled categories and returns registry order", () => {
  const categories = [
    { id: "a", enabled: true, name: "A", keywords: [], sources: ["hn_ai", "sspai"] },
    { id: "b", enabled: true, name: "B", keywords: [], sources: ["sspai", "gcores"] },
    { id: "c", enabled: false, name: "C", keywords: [], sources: ["lobsters"] },
  ];
  assert.deepEqual(enabledSourceIds(categories), SOURCE_IDS.filter((id) => ["hn_ai", "sspai", "gcores"].includes(id)));
  assert.deepEqual(enabledSourceIds([{ enabled: false, sources: ["gcores"] }]), []);
});

test("CONFIG_SECTION_KEYS covers every normalized top-level field", () => {
  assert.deepEqual(Object.keys(normalizeConfig({})).sort(), [...CONFIG_SECTION_KEYS].sort());
});

test("redactConfig blanks secrets and reports secretSet", () => {
  const { config, secretSet } = redactConfig(normalizeConfig({
    translationSecretKey: "hunter2",
    translationApiKey: "deepl-key",
    refreshMinutes: 9,
  }));
  assert.equal(config.translationSecretKey, "");
  assert.equal(config.translationApiKey, "");
  assert.equal(config.refreshMinutes, 9);
  assert.deepEqual(secretSet, { translationSecretKey: true, translationApiKey: true });
});

test("mergeSecrets keeps stored values on blank, replaces on non-empty, clears on request", () => {
  const stored = normalizeConfig({ translationSecretKey: "stored", translationApiKey: "stored-key" });
  const kept = mergeSecrets(stored, { ...stored, translationSecretKey: "", translationApiKey: "" }, []);
  assert.equal(kept.translationSecretKey, "stored");
  assert.equal(kept.translationApiKey, "stored-key");

  const replaced = mergeSecrets(stored, { ...stored, translationApiKey: "new-key" }, []);
  assert.equal(replaced.translationApiKey, "new-key");
  assert.equal(replaced.translationSecretKey, "stored");

  const cleared = mergeSecrets(stored, { ...stored, translationSecretKey: "" }, ["translationSecretKey"]);
  assert.equal(cleared.translationSecretKey, "");
});

test("mergeConfigPatch replaces categories but keeps untouched sections", () => {
  const stored = normalizeConfig({ maxItems: 30 });
  const next = mergeConfigPatch(stored, {
    maxItems: 50,
    categories: [{ id: "games", name: "Games", keywords: ["RPG"], sources: ["gcores"] }],
  });
  assert.equal(next.maxItems, 50);
  assert.equal(next.categories.length, 1);
  assert.deepEqual(next.categories[0], {
    id: "games",
    name: "Games",
    keywords: ["RPG"],
    sources: ["gcores"],
  });
  assert.equal(next.translate, true);
  assert.equal(next.refreshMinutes, stored.refreshMinutes);
});

test("mergeConfigPatch rejects unknown top-level keys", () => {
  assert.throws(
    () => mergeConfigPatch(normalizeConfig({}), { keywords: ["old"] }),
    (error) => error.code === "UNKNOWN_CONFIG_KEY" && error.key === "keywords",
  );
});

test("mergeStoredConfig imports a legacy document including its sources map", () => {
  const base = normalizeConfig({ refreshMinutes: 11 });
  const merged = mergeStoredConfig(base, {
    refreshMinutes: 7,
    blockwords: ["赞助"],
    sources: { hn_front: false, hn_ai: false, gcores: true },
    translationSecretKey: "legacy-secret",
  });
  assert.equal(merged.refreshMinutes, 7);
  assert.deepEqual(merged.blockwords, ["赞助"]);
  assert.equal(merged.translationSecretKey, "legacy-secret");
  assert.equal(merged.categories.find((entry) => entry.id === "tech").sources.includes("hn_front"), false);
  assert.equal(merged.categories.find((entry) => entry.id === "ai").sources.includes("hn_ai"), false);
  assert.equal(merged.categories.find((entry) => entry.id === "game").sources.includes("gcores"), true);
});

test("sliceConfig returns only the requested sections", () => {
  const config = normalizeConfig({ maxItems: 42 });
  const slice = sliceConfig(config, ["maxItems", "blockwords"]);
  assert.deepEqual(Object.keys(slice).sort(), ["blockwords", "maxItems"]);
});
