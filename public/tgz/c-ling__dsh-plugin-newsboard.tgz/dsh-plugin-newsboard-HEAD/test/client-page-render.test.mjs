import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

import { CONFIG_SECTION_KEYS, DEFAULT_CATEGORIES, SOURCE_IDS, normalizeConfig } from "../lib/config.js";

const SOURCE = readFileSync(new URL("../lib/client.js", import.meta.url), "utf8");

function clientConfig(overrides = {}) {
  const normalized = normalizeConfig(overrides);
  return {
    ...normalized,
    translationSecretKey: "",
    translationApiKey: "",
  };
}

function loadClient(options = {}) {
  let spec;
  const windowStub = { __ModuleLoader__: { load(value) { spec = value; } } };
  const style = { setAttribute() {}, dataset: {}, textContent: "" };
  const documentStub = {
    documentElement: { dataset: { platform: options.platform || "" } },
    querySelector: () => null,
    createElement: () => style,
    head: { appendChild() {} },
    addEventListener() {},
    removeEventListener() {},
    dispatchEvent() {},
    body: {},
  };
  new Function("window", "document", "location", SOURCE)(windowStub, documentStub, { protocol: options.protocol || "http:" });
  assert.ok(spec, "client bundle is captured");

  let index = 0;
  let seeds = {};
  const React = {
    Component: class { constructor(props) { this.props = props; this.state = {}; } setState() {} },
    createElement(type, props, ...children) { return { type, props: props || {}, children }; },
    memo: (fn) => fn,
    useState(initial) {
      const at = index++;
      if (Object.prototype.hasOwnProperty.call(seeds, at)) {
        const seeded = seeds[at];
        return [typeof seeded === "function" ? seeded() : seeded, () => {}];
      }
      return [typeof initial === "function" ? initial() : initial, () => {}];
    },
    useCallback: (fn) => fn,
    useEffect: () => {},
    useMemo: (fn) => fn(),
    useRef: (value) => ({ current: value }),
    useSyncExternalStore: (subscribe, getSnapshot) => getSnapshot(),
  };
  const client = spec.factory((id) => {
    if (id === "react") return React;
    if (id === "react-dom") {
      if (options.reactDOM) return options.reactDOM;
      throw new Error("react-dom unavailable in test");
    }
    throw new Error("unexpected require: " + id);
  });
  return {
    client,
    resetHooks(seedValues = {}) {
      index = 0;
      seeds = seedValues;
    },
  };
}

function findNodes(node, predicate, out = []) {
  if (!node || typeof node !== "object") return out;
  if (Array.isArray(node)) {
    for (const child of node) findNodes(child, predicate, out);
    return out;
  }
  if (predicate(node)) out.push(node);
  if (node.children) findNodes(node.children, predicate, out);
  return out;
}

function textOf(node) {
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(textOf).join(" ");
  if (node && node.children) return textOf(node.children);
  return "";
}

function fakeStore(configValue, feed = {}) {
  let snapshot = {
    feed: {
      items: [],
      categories: DEFAULT_CATEGORIES.map((entry) => ({ ...entry })),
      refreshedAt: 0,
      failedSources: [],
      status: "idle",
      error: "",
      serverTime: "",
      ...feed,
    },
    config: {
      value: configValue,
      revision: 2,
      secretSet: { translationSecretKey: true, translationApiKey: false },
      loading: false,
      error: "",
      saving: false,
    },
  };
  const saveCalls = [];
  return {
    saveCalls,
    subscribe() { return () => {}; },
    getSnapshot() { return snapshot; },
    loadFeed() { return Promise.resolve(snapshot.feed); },
    refreshFeed() { return Promise.resolve(snapshot.feed); },
    loadConfig() { return Promise.resolve(snapshot.config.value); },
    saveConfig(patch, expectedRevision, clearSecrets) {
      saveCalls.push({ patch, expectedRevision, clearSecrets });
      snapshot = {
        ...snapshot,
        config: { ...snapshot.config, value: { ...snapshot.config.value, ...patch }, revision: expectedRevision + 1, saving: false },
      };
      return Promise.resolve({
        ok: true,
        config: snapshot.config.value,
        revision: snapshot.config.revision,
        secretSet: snapshot.config.secretSet,
      });
    },
    setSnapshot(next) { snapshot = next; },
  };
}

function tabList(client) {
  return [
    { id: "all", label: "全部" },
    ...client.FALLBACK_CATEGORIES.map((category) => ({ id: category.id, label: category.name })),
    { id: "settings", label: "设置" },
  ];
}

test("PageTabs renders dynamic category tabs plus All and Settings", () => {
  const { client } = loadClient();
  const tabs = tabList(client);
  const tree = client.PageTabs({ t: (key) => key, tabs, active: "all", onChange: () => {} });
  const rendered = findNodes(tree, (node) => node.props?.role === "tab");
  assert.equal(rendered.length, 6);
  assert.deepEqual(rendered.map((node) => node.props["data-tab"]), ["all", "ai", "tech", "game", "life", "settings"]);
  assert.equal(rendered[0].props["aria-selected"], true);
  assert.equal(rendered[5].props["aria-selected"], false);
  assert.deepEqual(rendered.map(textOf), ["全部", "AI", "科技", "游戏", "生活", "设置"]);
});

test("categoryLabel localizes preset names but preserves custom names", () => {
  const { client } = loadClient();
  const zh = client.DICT.zh;
  const t = (key) => zh[key] ?? key;
  assert.equal(client.categoryLabel(t, { id: "tech", name: "科技" }), "科技");
  assert.equal(client.categoryLabel(t, { id: "tech", name: "数码" }), "数码");
  assert.equal(client.categoryLabel(t, { id: "game", name: "" }), "游戏");
});

test("ItemCard prefers the translated title and keeps the original as a subtitle", () => {
  const { client } = loadClient();
  const item = {
    id: "a",
    source: "openai_news",
    categories: ["ai"],
    title: "OpenAI ships a new model",
    titleZh: "OpenAI 发布新模型",
    summary: "English summary",
    summaryZh: "中文摘要",
    author: "Sam",
    score: 12,
    comments: 3,
    url: "https://example.com/a",
    publishedAt: new Date().toISOString(),
  };
  const tree = client.ItemCard({ t: (key) => key, item, isNew: true });
  assert.equal(tree.type, "a");
  assert.equal(tree.props.target, "_blank");
  assert.ok(tree.props.className.includes("dsh-newsboard-card-new"));
  assert.equal(findNodes(tree, (node) => node.props?.className === "dsh-newsboard-new-tag").length, 1);
  const text = textOf(tree);
  assert.ok(text.includes("OpenAI 发布新模型"));
  assert.ok(text.includes("OpenAI ships a new model"));
  assert.ok(text.includes("中文摘要"));
  assert.ok(text.includes("热度 12"));
});

test("ItemCard refuses non-http(s) links and renders a plain card instead", () => {
  const { client } = loadClient();
  const tree = client.ItemCard({
    t: (key) => key,
    item: {
      id: "x", source: "hn_front", title: "T", url: "javascript:alert(1)",
      publishedAt: new Date().toISOString(),
    },
  });
  assert.equal(tree.type, "div");
  assert.equal(tree.props.href, undefined);
});

test("FeedPanel marks only stories newer than the last-seen baseline", () => {
  const { client } = loadClient();
  const now = Date.now();
  const seen = now - 3_600_000;
  const items = [
    { id: "new", title: "New story", source: "hn_front", url: "https://x.dev/new", publishedAt: new Date(now - 60_000).toISOString() },
    { id: "old", title: "Old story", source: "hn_front", url: "https://x.dev/old", publishedAt: new Date(now - 7_200_000).toISOString() },
  ];
  const tree = client.FeedPanel({
    t: (key) => key,
    feed: { items, status: "idle", error: "" },
    items,
    query: "",
    refreshing: false,
    lastSeen: seen,
    onRefresh: () => {},
    onClearSearch: () => {},
  });
  const cards = findNodes(tree, (node) => node.type === client.ItemCard);
  assert.equal(cards.length, 2);
  assert.equal(cards[0].props.isNew, true);
  assert.equal(cards[1].props.isNew, false);
});

test("FeedPanel renders loading, empty and populated states", () => {
  const { client } = loadClient();
  const loading = client.FeedPanel({
    t: (key) => key,
    feed: { items: [], status: "loading", error: "" },
    items: [],
    query: "",
    refreshing: true,
    onRefresh: () => {},
    onClearSearch: () => {},
  });
  assert.equal(loading.props.spinner, true);

  const empty = client.FeedPanel({
    t: (key) => key,
    feed: { items: [], status: "idle", error: "" },
    items: [],
    query: "",
    refreshing: false,
    onRefresh: () => {},
    onClearSearch: () => {},
  });
  assert.equal(empty.props.text, "暂未抓到消息");

  const populated = client.FeedPanel({
    t: (key) => key,
    feed: { items: [{ id: "a" }], status: "idle", error: "" },
    items: [{ id: "a", url: "https://x.dev", title: "T", publishedAt: new Date().toISOString(), source: "hn_front" }],
    query: "",
    refreshing: false,
    onRefresh: () => {},
    onClearSearch: () => {},
  });
  assert.equal(findNodes(populated, (node) => node.type === client.ItemCard).length, 1);
});

test("SettingsPanel keeps the save action inline without ReactDOM and posts the full config slice", async () => {
  const { client, resetHooks } = loadClient();
  const base = clientConfig({ maxItems: 60 });
  const draft = { ...base, maxItems: 80 };
  const store = fakeStore(base);
  resetHooks({ 0: draft, 1: null, 2: null, 3: null });
  const tree = client.SettingsPanel({ t: (key) => key, store, visible: true, actionsSlot: null });

  const actions = findNodes(tree, (node) => node.props?.className === "dsh-newsboard-actions");
  assert.equal(actions.length, 1, "inline action bar rendered without a portal");
  assert.match(textOf(actions[0]), /有未保存的更改/);

  const categories = findNodes(tree, (node) => node.props?.className === "dsh-newsboard-category-editor");
  assert.equal(categories.length, 4, "every preset category has an editor");
  const matrixCheckboxes = findNodes(tree, (node) => node.type === "input" && node.props?.type === "checkbox");
  assert.equal(matrixCheckboxes.length, SOURCE_IDS.length * 4, "one source/category checkbox per matrix cell");
  assert.equal(matrixCheckboxes.filter((node) => node.props.checked === true).length > 0, true);
  assert.match(textOf(tree), /Hacker News 首页热帖/);

  const saveButton = findNodes(actions[0], (node) => node.props?.className === "dsh-newsboard-primary")[0];
  assert.equal(saveButton.props.disabled, false);
  saveButton.props.onClick();
  await new Promise((resolve) => setImmediate(resolve));

  assert.equal(store.saveCalls.length, 1);
  const call = store.saveCalls[0];
  assert.equal(call.expectedRevision, 2);
  assert.deepEqual(Object.keys(call.patch).sort(), [...CONFIG_SECTION_KEYS].sort());
  assert.equal(call.patch.maxItems, 80);
  assert.equal(call.patch.categories.length, 4);
  assert.equal(call.patch.translationSecretKey, "");
});

test("SettingsPanel marks presets non-deletable and confirms custom deletion", () => {
  const { client, resetHooks } = loadClient();
  const base = clientConfig({});
  const custom = { id: "custom", name: "Custom", enabled: false, keywords: [], sources: [] };
  const draft = { ...base, categories: [...base.categories, custom] };
  const store = fakeStore(base);
  resetHooks({ 0: draft, 1: null, 2: null, 3: "custom" });
  const tree = client.SettingsPanel({ t: (key) => key, store, visible: true, actionsSlot: null });
  const editors = findNodes(tree, (node) => node.props?.className?.includes("dsh-newsboard-category-editor"));
  assert.equal(editors.length, 5);
  assert.equal(editors.filter((node) => node.props.className.includes("dsh-newsboard-category-editor-disabled")).length, 1);
  const presetTags = findNodes(tree, (node) => node.props?.className === "dsh-newsboard-tag" && textOf(node) === "预设");
  assert.equal(presetTags.length, 4, "preset categories show a non-deletable tag");
  const dialogs = findNodes(tree, (node) => node.type === client.ConfirmDeleteDialog);
  assert.equal(dialogs.length, 1, "deleting a custom category opens the confirmation dialog");
  assert.equal(dialogs[0].props.name, "Custom");
  const switches = findNodes(tree, (node) => node.type === client.Switch);
  assert.equal(switches.length, 5);
  assert.equal(switches.filter((node) => node.props.checked === false).length, 1);
});

test("ConfirmDeleteDialog renders the category name, cancel and danger actions", () => {
  const { client, resetHooks } = loadClient();
  resetHooks({});
  const tree = client.ConfirmDeleteDialog({
    t: (key, params) => {
      const text = client.DICT.zh[key] ?? key;
      if (!params) return text;
      return text.split("{name}").join(params.name);
    },
    name: "Custom",
    onCancel: () => {},
    onConfirm: () => {},
  });
  const dialog = findNodes(tree, (node) => node.props?.role === "dialog")[0];
  assert.ok(dialog);
  assert.equal(dialog.props["aria-modal"], "true");
  assert.match(textOf(tree), /删除分类/);
  assert.match(textOf(tree), /确定删除「Custom」吗/);
  const buttons = findNodes(tree, (node) => node.type === "button");
  assert.equal(buttons.length, 2);
  assert.equal(buttons[0].props.className, "dsh-newsboard-btn");
  assert.equal(buttons[1].props.className, "dsh-newsboard-btn dsh-newsboard-btn-danger");
});

test("SettingsPanel portals its save bar into the tab action slot when ReactDOM is available", () => {
  const portals = [];
  const { client, resetHooks } = loadClient({
    reactDOM: {
      createPortal(node, target) {
        portals.push({ node, target });
        return { type: "portal", props: { target }, children: [node] };
      },
    },
  });
  const base = clientConfig({});
  const store = fakeStore(base);
  const target = { id: "tab-actions" };
  resetHooks({ 0: base, 1: null, 2: null, 3: null });
  client.SettingsPanel({ t: (key) => key, store, visible: true, actionsSlot: target });
  assert.equal(portals.length, 1);
  assert.equal(portals[0].target, target);
  assert.equal(findNodes(portals[0].node, (node) => node.props?.className === "dsh-newsboard-primary").length, 1);
});

test("SettingsPanel disables save on a clean draft", () => {
  const { client, resetHooks } = loadClient();
  const base = clientConfig({});
  const store = fakeStore(base);
  resetHooks({ 0: base, 1: null, 2: null, 3: null });
  const tree = client.SettingsPanel({ t: (key) => key, store, visible: true, actionsSlot: null });
  const saveButton = findNodes(tree, (node) => node.props?.className === "dsh-newsboard-primary")[0];
  assert.equal(saveButton.props.disabled, true);
});

test("NewsPage renders dynamic tabs, the title unread count and no intro", () => {
  const { client, resetHooks } = loadClient({ platform: "darwin" });
  const now = Date.now();
  const items = [{
    id: "a", source: "openai_news", category: "ai", categories: ["ai"],
    title: "OpenAI ships a model", url: "https://example.com/a",
    publishedAt: new Date(now - 60_000).toISOString(),
  }];
  const store = fakeStore(clientConfig({}), {
    items,
    refreshedAt: now,
    categories: DEFAULT_CATEGORIES.map((entry) => ({ ...entry })),
  });
  resetHooks({ 0: "all", 1: "", 2: false, 3: true, 4: now - 3_600_000, 5: null });
  const tree = client.NewsPage({ t: (key) => key, store, layout: null });

  const tabs = findNodes(tree, (node) => node.type === client.PageTabs);
  assert.equal(tabs.length, 1);
  assert.equal(tabs[0].props.tabs.length, 6);
  assert.equal(tabs[0].props.tabs[1].id, "ai");
  const badge = findNodes(tree, (node) => node.props?.className === "dsh-newsboard-new-badge");
  assert.equal(badge.length, 1);
  assert.equal(textOf(badge[0]), "1", "the title badge shows only the compact count");
  assert.match(String(badge[0].props.title), /新增 1 条/);
  assert.equal(textOf(tree).includes("AI 与技术资讯聚合"), false, "the old intro was removed");
  assert.equal(findNodes(tree, (node) => node.type === client.SettingsPanel).length, 0, "settings mount lazily");
  const feedPanel = findNodes(tree, (node) => node.type === client.FeedPanel)[0];
  assert.equal(feedPanel.props.lastSeen, now - 3_600_000);
  assert.match(textOf(tree), /静默更新/);
  assert.match(textOf(tree), /🖥 桌面端/);
});

test("NewsPage hides disabled categories from the tab strip", () => {
  const { client, resetHooks } = loadClient();
  const now = Date.now();
  const categories = DEFAULT_CATEGORIES.map((entry) => ({
    ...entry,
    enabled: entry.id !== "game",
  }));
  const store = fakeStore(clientConfig({}), { items: [], refreshedAt: now, categories });
  resetHooks({ 0: "all", 1: "", 2: false, 3: true, 4: now, 5: null });
  const tree = client.NewsPage({ t: (key) => key, store, layout: null });
  const tabs = findNodes(tree, (node) => node.type === client.PageTabs)[0];
  assert.equal(tabs.props.tabs.length, 5);
  assert.equal(tabs.props.tabs.some((entry) => entry.id === "game"), false);
  assert.ok(tabs.props.tabs.some((entry) => entry.id === "life"));
});

test("NewsBoardIcon shows the unread count in the sidebar glyph", () => {
  const { client, resetHooks } = loadClient();
  const now = Date.now();
  const store = fakeStore(clientConfig({}), {
    items: [
      { id: "a", title: "A", source: "hn_front", publishedAt: new Date(now - 60_000).toISOString() },
      { id: "b", title: "B", source: "hn_front", publishedAt: new Date(now - 90 * 60_000).toISOString() },
    ],
  });
  resetHooks({ 0: now - 3_600_000 });
  const tree = client.NewsBoardIcon({ size: 16, store, t: (key) => key });
  const count = findNodes(tree, (node) => node.props?.className === "dsh-newsboard-side-count");
  assert.equal(count.length, 1);
  assert.equal(textOf(count[0]), "1");
});

test("filterFeedItems filters by category tags and search text", () => {
  const { client } = loadClient();
  const items = [
    { title: "AI model", source: "openai_news", categories: ["ai"] },
    { title: "Game review", source: "gcores", categories: ["game"] },
    { title: "AI game tool", source: "hn_ai", categories: ["ai", "game"] },
    { title: "未分类消息", source: "hn_front", categories: [] },
  ];
  const t = (key) => client.DICT.zh[key] ?? key;
  assert.deepEqual(client.filterFeedItems(items, "all", "", t).map((item) => item.title), ["AI model", "Game review", "AI game tool", "未分类消息"]);
  assert.deepEqual(client.filterFeedItems(items, "ai", "", t).map((item) => item.title), ["AI model", "AI game tool"]);
  assert.deepEqual(client.filterFeedItems(items, "game", "", t).map((item) => item.title), ["Game review", "AI game tool"]);
  assert.deepEqual(client.filterFeedItems(items, "game", "review", t).map((item) => item.title), ["Game review"]);
  assert.deepEqual(client.filterFeedItems(items, "ai", "游戏", t).map((item) => item.title), []);
});

test("countUnread compares ISO timestamps against the last-seen value", () => {
  const { client } = loadClient();
  const now = Date.now();
  const items = [
    { publishedAt: new Date(now - 60_000).toISOString() },
    { publishedAt: new Date(now - 3_600_000).toISOString() },
    { publishedAt: "not-a-date" },
  ];
  assert.equal(client.countUnread(items, now - 30 * 60_000), 1);
  assert.equal(client.countUnread(items, now - 2 * 3_600_000), 2);
  assert.equal(client.countUnread(items, 0), 0);
});
