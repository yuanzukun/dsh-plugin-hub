/**
 * Static UI harness for the news board page.
 *
 * Extracts the real CSS string from lib/client.js (no build step, no React)
 * and renders the same class names with representative markup so the layout
 * can be checked in headless Chrome at 1440px / narrow widths in both themes.
 *
 * Usage:
 *   node tools/render-ui-harness.mjs [outDir]
 *   # then open the generated HTML files or screenshot them with Chrome.
 */

import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const here = dirname(fileURLToPath(import.meta.url));
const source = await readFile(join(here, "..", "lib", "client.js"), "utf8");
const outDir = resolve(process.argv[2] ?? "/tmp/dsh-newsboard-ui");

let css = "";
const context = {
  console,
  window: {
    __ModuleLoader__: {
      load(entry) {
        entry.factory((id) => {
          if (id === "react") {
            return {
              Component: class {},
              createElement() { return {}; },
            };
          }
          throw new Error(`unexpected require: ${id}`);
        });
      },
    },
  },
  document: {
    querySelector() { return null; },
    createElement() {
      return { setAttribute() {}, textContent: "" };
    },
    head: {
      appendChild(node) { css = node.textContent; },
    },
  },
};
vm.runInNewContext(source, context, { filename: "lib/client.js" });
if (css === "") throw new Error("client CSS was not captured");

const lightTokens = `
:root{
  --dsw-alias-bg-base:#f7f8fa;
  --dsw-alias-bg-layer-1:#fff;
  --dsw-alias-bg-layer-2:#fff;
  --dsw-alias-bg-layer-3:#fff;
  --dsw-alias-label-primary:#1f2328;
  --dsw-alias-label-secondary:#5f6672;
  --dsw-alias-label-tertiary:#8a919c;
  --dsw-alias-label-dimmed:#a8adb7;
  --dsw-alias-label-primary-foreground:#fff;
  --dsw-alias-border-l1:rgba(0,0,0,.08);
  --dsw-alias-border-l2:rgba(0,0,0,.12);
  --dsw-alias-border-l3:rgba(0,0,0,.18);
  --dsw-alias-border-l4:rgba(0,0,0,.2);
  --dsw-alias-interactive-bg-hover:rgba(0,0,0,.04);
  --dsw-alias-interactive-bg-hover-solid:rgba(0,0,0,.06);
  --dsw-alias-state-business-primary:#4a6cf7;
  --dsw-alias-state-success-primary:#3c9a5f;
  --dsw-alias-state-warn-primary:#b7791f;
  --dsw-alias-state-error-primary:#e5484d;
  --dsw-alias-button-primary-fill:#1f2328;
  --dsw-alias-button-primary-hover:#000;
  --dsw-alias-settings-card-fill:#fff;
  --dsw-alias-settings-card-stroke:rgba(0,0,0,.1);
  --dsw-radius-md:8px;
  --dsw-radius-lg:12px;
  --dsw-focus-ring-color:#4a6cf7;
  --dsh-frame-top-clearance:48px;
}`;

const darkTokens = `
:root{
  --dsw-alias-bg-base:#1b1b1d;
  --dsw-alias-bg-layer-1:#262628;
  --dsw-alias-bg-layer-2:#2c2c2e;
  --dsw-alias-bg-layer-3:#333335;
  --dsw-alias-label-primary:#f5f5f7;
  --dsw-alias-label-secondary:#b8bcc4;
  --dsw-alias-label-tertiary:#8a919c;
  --dsw-alias-label-dimmed:#6e727b;
  --dsw-alias-label-primary-foreground:#1b1b1d;
  --dsw-alias-border-l1:rgba(255,255,255,.09);
  --dsw-alias-border-l2:rgba(255,255,255,.14);
  --dsw-alias-border-l3:rgba(255,255,255,.2);
  --dsw-alias-border-l4:rgba(255,255,255,.24);
  --dsw-alias-interactive-bg-hover:rgba(255,255,255,.06);
  --dsw-alias-interactive-bg-hover-solid:rgba(255,255,255,.1);
  --dsw-alias-state-business-primary:#7d95ff;
  --dsw-alias-state-success-primary:#62c47e;
  --dsw-alias-state-warn-primary:#e0a44b;
  --dsw-alias-state-error-primary:#ff6b6f;
  --dsw-alias-button-primary-fill:#f5f5f7;
  --dsw-alias-button-primary-hover:#fff;
  --dsw-alias-label-primary-foreground:#1b1b1d;
  --dsw-alias-settings-card-fill:#242426;
  --dsw-alias-settings-card-stroke:rgba(255,255,255,.12);
  --dsw-radius-md:8px;
  --dsw-radius-lg:12px;
  --dsw-focus-ring-color:#7d95ff;
  --dsh-frame-top-clearance:48px;
}`;

const refreshIcon = `<svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M13.2 7.1A5.3 5.3 0 1 0 13 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M13.4 3.4v3.5H9.9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const settingsIcon = `<svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 10.1a2.1 2.1 0 1 0 0-4.2 2.1 2.1 0 0 0 0 4.2Z" stroke="currentColor" stroke-width="1.4"/><path d="M13.1 9.7c.1-.4.2-.8.2-1.2s-.1-.8-.2-1.2l1-.8-1.1-1.9-1.2.5c-.6-.5-1.2-.8-1.9-1L9.6 2.6H7.4l-.3 1.5c-.7.2-1.3.5-1.9 1l-1.2-.5-1.1 1.9 1 .8c-.1.4-.2.8-.2 1.2s.1.8.2 1.2l-1 .8 1.1 1.9 1.2-.5c.6.5 1.2.8 1.9 1l.3 1.5h2.2l.3-1.5c.7-.2 1.3-.5 1.9-1l1.2.5 1.1-1.9-1-.8Z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/></svg>`;
const externalIcon = `<svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M9.5 3.5h3v3M12.5 3.5 7.6 8.4" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M11.8 9.8v1.8a1.4 1.4 0 0 1-1.4 1.4H4.4A1.4 1.4 0 0 1 3 11.6V5.6a1.4 1.4 0 0 1 1.4-1.4h1.8" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>`;

function tabRow(active, actions = "") {
  const tabs = [
    ["all", "全部"],
    ["ai", "AI"],
    ["tech", "科技"],
    ["game", "游戏"],
    ["life", "生活"],
    ["settings", "设置"],
  ];
  return `<div class="dsh-newsboard-tabs-row">
    <div class="dsh-newsboard-tabs" role="tablist" aria-label="快讯看板分类">
      ${tabs.map(([id, label]) => `<button type="button" role="tab" ${active === id ? 'aria-selected="true"' : 'aria-selected="false" tabindex="-1"'} class="dsh-newsboard-tab" data-tab="${id}">${label}</button>`).join("")}
    </div>
    <div class="dsh-newsboard-tab-actions">${actions}</div>
  </div>`;
}

function head(platform = "darwin") {
  return `<header class="dsh-newsboard-head">
    <div class="dsh-newsboard-heading">
      <div class="dsh-newsboard-title-row">
        <h2 class="dsh-newsboard-title">快讯看板</h2>
        <span class="dsh-newsboard-new-badge" title="自上次离开看板后新增 12 条">12</span>
      </div>
      <div class="dsh-newsboard-meta">
        <span>更新于 14:32</span><span>·</span><span>60 条</span>
        <span class="dsh-newsboard-meta-error" title="不可用来源：Solidot">· 1 个来源不可用</span>
        <span class="dsh-newsboard-platform">${platform === "darwin" ? "🖥 桌面端" : "🌐 Web"}</span>
      </div>
    </div>
    <div class="dsh-newsboard-head-actions">
      <input class="dsh-newsboard-search" type="search" placeholder="在当前分类中搜索">
      <button type="button" class="dsh-newsboard-icon-button" aria-label="刷新" title="刷新">${refreshIcon}</button>
      <button type="button" class="dsh-newsboard-icon-button" aria-label="设置" title="设置">${settingsIcon}</button>
    </div>
  </header>`;
}

const cards = [
  {
    source: "OpenAI",
    isNew: true,
    time: "12 分钟前",
    title: "OpenAI 发布新一代推理模型，强化多步工具调用能力",
    original: "",
    summary: "新模型在数学、代码与长链路 Agent 任务上均有提升，并开放更细粒度的推理强度控制。",
    foot: ["热度 412", "评论 96"],
  },
  {
    source: "Hacker News",
    time: "38 分钟前",
    title: "Show HN: A local-first news reader built on SQLite",
    original: "Show HN: A local-first news reader built on SQLite",
    summary: "A small offline-first reader that syncs RSS feeds through a single-file database.",
    summaryZh: "一个基于单文件数据库同步 RSS 的小型离线优先阅读器。",
    foot: ["热度 188", "评论 54", "作者：tobias"],
  },
  {
    source: "IT之家",
    time: "1 小时前",
    title: "国产开源模型社区发布新一批工具链与评测基准",
    original: "",
    summary: "覆盖推理、Agent、代码生成与多模态评测，强调可复现的本地运行流程。",
    foot: [],
  },
  {
    source: "arXiv AI",
    time: "2 小时前",
    title: "Efficient Long-Context Retrieval with Hierarchical Memory",
    original: "Efficient Long-Context Retrieval with Hierarchical Memory",
    summary: "The paper proposes a hierarchical memory index that reduces retrieval latency while keeping recall competitive on long-context benchmarks.",
    summaryZh: "论文提出分层记忆索引，在长上下文基准上保持召回率的同时降低检索延迟。",
    foot: ["评论 0", "作者：L. Chen et al."],
  },
  {
    source: "少数派",
    time: "3 小时前",
    title: "把信息流收进一个页面：我的 RSS 工作流 2.0",
    original: "",
    summary: "从来源筛选、关键词规则到每日回顾，作者分享了一套尽量不打断专注的阅读流程。",
    foot: [],
  },
];

function card(item) {
  const originalTitle = item.original && item.original !== item.title
    ? `<p class="dsh-newsboard-card-title-original">${item.original}</p>` : "";
  const originalSummary = item.summaryZh
    ? `<p class="dsh-newsboard-card-summary-original">${item.summary}</p>` : "";
  return `<a class="dsh-newsboard-card${item.isNew ? " dsh-newsboard-card-new" : ""}" href="#">
    <div class="dsh-newsboard-card-top">
      ${item.isNew ? '<span class="dsh-newsboard-new-tag" title="上次离开看板后新增的消息">新</span>' : ""}
      <span class="dsh-newsboard-badge">${item.source}</span>
      <span>${item.time}</span>
    </div>
    <h3 class="dsh-newsboard-card-title">${item.title}</h3>
    ${originalTitle}
    <p class="dsh-newsboard-card-summary">${item.summaryZh || item.summary}</p>
    ${originalSummary}
    <div class="dsh-newsboard-card-foot">
      ${item.foot.map((entry) => `<span>${entry}</span>`).join("")}
      <span class="dsh-newsboard-card-open">打开原文${externalIcon}</span>
    </div>
  </a>`;
}

function footer() {
  return `<footer class="dsh-newsboard-footer">
    <span>静默更新，不弹通知、不发声。</span>
    <span>内容来自公开 RSS / JSON 源；翻译由所选服务提供。</span>
  </footer>`;
}

function listPage(options) {
  const platform = options.platform ?? "darwin";
  return `<div class="dsh-newsboard-page">
    <div class="dsh-newsboard-inner">
      ${head(platform)}
      ${tabRow("all")}
      <div class="dsh-newsboard-scroll">
        <div class="dsh-newsboard-tabpanel">
          ${options.empty
            ? `<div class="dsh-newsboard-empty dsh-newsboard-empty-feed">
                <span>暂未抓到消息</span>
                <span class="dsh-newsboard-hint">来源可能需要几秒响应，或检查设置中的来源开关与关键词。</span>
                <div class="dsh-newsboard-empty-actions"><button class="dsh-newsboard-btn">重试</button></div>
              </div>`
            : `<div class="dsh-newsboard-list">${cards.map(card).join("")}</div>`}
        </div>
      </div>
      ${footer()}
    </div>
  </div>`;
}

function switchMarkup(on) {
  return `<button type="button" role="switch" aria-checked="${on}" class="dsh-newsboard-switch${on ? " dsh-newsboard-switch-on" : ""}"><span class="dsh-newsboard-switch-knob"></span></button>`;
}

function field(label, control, hint = "") {
  return `<label class="dsh-newsboard-field">
    <span>${label}</span>
    ${control}
    ${hint ? `<span class="dsh-newsboard-hint">${hint}</span>` : ""}
  </label>`;
}

const HARNESS_SOURCES = [
  ["Hacker News", "首页热帖，偏开发者与创业社区讨论。"],
  ["HN · AI", "HN 上的 AI 新帖，偏模型、工具与行业动态。"],
  ["Lobsters", "技术社区，偏编程、系统与开源项目。"],
  ["OpenAI News", "OpenAI 官方，偏模型发布、产品与安全研究。"],
  ["Google AI Blog", "Google AI 官方，偏研究进展与产品落地。"],
  ["TechCrunch AI", "AI 创业、融资与商业动态。"],
  ["The Verge AI", "消费级 AI 产品与行业评论。"],
  ["arXiv AI", "最新论文，偏学术研究。"],
  ["MIT 科技评论", "深度科技趋势与影响分析。"],
  ["雷锋网", "中文 AI、智能汽车与产业新闻。"],
  ["IT之家", "中文数码、硬件与科技快讯。"],
  ["Solidot", "开源、安全与极客文化。"],
  ["Ars Technica", "深度技术、科学与政策分析。"],
  ["36氪", "中文科技商业、创投与公司动态。"],
  ["爱范儿", "消费电子、产品体验与数字生活。"],
  ["机核", "中文游戏文化、评测与开发者访谈。"],
  ["游研社", "中文游戏历史、文化与行业观察。"],
  ["GamesIndustry.biz", "全球游戏产业、商业与人事。"],
  ["Rock Paper Shotgun", "PC 游戏评测、新闻与独立游戏。"],
  ["Indie Games Plus", "独立游戏与开发者故事。"],
  ["PC Gamer", "PC 平台游戏新闻与硬件。"],
  ["少数派", "数字生活、效率工具与消费决策。"],
  ["理想生活实验室", "生活方式、设计、酒店与消费。"],
  ["Atlas Obscura", "旅行、人文地理与冷门文化。"],
];

function categoryEditor(name, keywords, sourceCount) {
  return `<div class="dsh-newsboard-category-editor">
    <div class="dsh-newsboard-category-head">
      <input class="dsh-newsboard-input" value="${name}">
      ${switchMarkup(true)}
      <span class="dsh-newsboard-category-count">${sourceCount} 个渠道</span>
      <span class="dsh-newsboard-tag" title="预设分类不可删除，可禁用或修改关键词/渠道。">预设</span>
    </div>
    <label class="dsh-newsboard-field">
      <span>分类关键词</span>
      <textarea class="dsh-newsboard-input" rows="2">${keywords}</textarea>
      <span class="dsh-newsboard-hint">每行一个；留空表示该分类接收其来源的全部消息。</span>
    </label>
  </div>`;
}

function sourceMatrix() {
  const categories = ["AI", "科技", "游戏", "生活"];
  const checked = {
    "Hacker News": [false, true, false, false],
    "HN · AI": [true, false, false, false],
    "Lobsters": [false, true, false, false],
    "OpenAI News": [true, false, false, false],
    "Google AI Blog": [true, false, false, false],
    "TechCrunch AI": [true, false, false, false],
    "The Verge AI": [true, false, false, false],
    "arXiv AI": [true, false, false, false],
    "MIT 科技评论": [true, true, false, false],
    "雷锋网": [true, true, false, false],
    "IT之家": [false, true, false, false],
    "Solidot": [false, true, false, false],
    "Ars Technica": [false, true, false, false],
    "36氪": [false, true, false, false],
    "爱范儿": [false, true, false, true],
    "机核": [false, false, true, false],
    "游研社": [false, false, true, false],
    "GamesIndustry.biz": [false, false, true, false],
    "Rock Paper Shotgun": [false, false, true, false],
    "Indie Games Plus": [false, false, false, false],
    "PC Gamer": [false, false, false, false],
    "少数派": [false, false, false, true],
    "理想生活实验室": [false, false, false, true],
    "Atlas Obscura": [false, false, false, true],
  };
  const headCells = [`<div class="dsh-newsboard-matrix-cell dsh-newsboard-matrix-headcell">来源 / 内容倾向</div>`]
    .concat(categories.map((name) => `<div class="dsh-newsboard-matrix-cell dsh-newsboard-matrix-headcell">${name}</div>`))
    .join("");
  const rows = HARNESS_SOURCES.map(([name, desc], rowIndex) => {
    const last = rowIndex === HARNESS_SOURCES.length - 1 ? " dsh-newsboard-matrix-row-last" : "";
    const cells = categories.map((category, index) => `<label class="dsh-newsboard-matrix-cell dsh-newsboard-matrix-checkcell${last}"><input type="checkbox" ${checked[name][index] ? "checked" : ""} aria-label="把 ${name} 归入 ${category}"></label>`).join("");
    return `<div class="dsh-newsboard-matrix-cell dsh-newsboard-matrix-source-cell${last}"><span class="dsh-newsboard-matrix-source-name">${name}</span><span class="dsh-newsboard-matrix-source-desc" title="${desc}">${desc}</span></div>${cells}`;
  }).join("");
  return `<div class="dsh-newsboard-matrix-wrap"><div class="dsh-newsboard-matrix" style="grid-template-columns:minmax(220px,1fr) repeat(4,72px)">${headCells}${rows}</div></div>`;
}

function settingsPage(options) {
  const platform = options.platform ?? "darwin";
  const actions = `<div class="dsh-newsboard-actions">
    <div class="dsh-newsboard-actions-status">
      <span class="dsh-newsboard-tag dsh-newsboard-tag-warn">有未保存的更改</span>
    </div>
    <div class="dsh-newsboard-actions-buttons">
      <button type="button" class="dsh-newsboard-btn">撤销</button>
      <button type="button" class="dsh-newsboard-primary">保存设置</button>
    </div>
  </div>`;
  return `<div class="dsh-newsboard-page">
    <div class="dsh-newsboard-inner">
      ${head(platform)}
      ${tabRow("settings", actions)}
      <div class="dsh-newsboard-scroll">
        <div class="dsh-newsboard-tabpanel">
          <div class="dsh-newsboard-settings">
            <div class="dsh-newsboard-card-row">
              <div class="dsh-newsboard-card-header"><h3>分类</h3></div>
              <p class="dsh-newsboard-hint">分类 = 名称 + 关键词。来源被归入该分类、且标题或摘要命中任一关键词的消息会出现在对应 Tab；「全部」仍然显示所有已抓取消息。</p>
              <div class="dsh-newsboard-category-list">
                ${categoryEditor("AI", "AI\nLLM\nAgent\n模型\nOpenAI\nClaude\nGemini\nAnthropic", 7)}
                ${categoryEditor("科技", "科技\n芯片\n半导体\n开源\n编程\n开发者\n互联网", 5)}
                ${categoryEditor("游戏", "游戏\n玩家\n主机\nSteam\nPlayStation\nXbox\nNintendo", 4)}
                ${categoryEditor("生活", "生活\n消费\n设计\n旅行\n家居\n美食\n健康\n效率", 3)}
              </div>
              <div class="dsh-newsboard-row"><button type="button" class="dsh-newsboard-btn">添加分类</button></div>
            </div>
            <div class="dsh-newsboard-card-row">
              <div class="dsh-newsboard-card-header"><h3>来源渠道</h3><button type="button" class="dsh-newsboard-btn dsh-newsboard-btn-small">查看抓取日志</button></div>
              <p class="dsh-newsboard-hint">勾选每个来源归属的分类；同一来源可以归入多个分类。来源下方的说明表示它倾向于的内容。</p>
              ${sourceMatrix()}
            </div>
            <div class="dsh-newsboard-card-row">
              <div class="dsh-newsboard-card-header"><h3>更新与展示</h3></div>
              <p class="dsh-newsboard-hint">控制抓取频率、展示条数与时间窗。</p>
              <div class="dsh-newsboard-form-grid">
                ${field("刷新间隔（分钟）", `<input class="dsh-newsboard-input" type="number" value="5">`, "1–120 分钟。太频繁会给来源站点带来压力，默认 5 分钟。")}
                ${field("最多显示", `<input class="dsh-newsboard-input" type="number" value="60">`, "10–200 条，默认 60 条。")}
                ${field("只保留最近（小时）", `<input class="dsh-newsboard-input" type="number" value="72">`, "1–720 小时，默认 72 小时。")}
              </div>
            </div>
            <div class="dsh-newsboard-card-row">
              <div class="dsh-newsboard-card-header"><h3>英文内容翻译</h3><button type="button" class="dsh-newsboard-btn dsh-newsboard-btn-small">查看翻译日志</button></div>
              <p class="dsh-newsboard-hint">翻译结果随消息缓存；关闭后仅显示原文。凭据字段只写不回显，留空表示保持已保存的值。</p>
              <div class="dsh-newsboard-toggle-row">
                <div class="dsh-newsboard-toggle-text"><span>英文内容翻译为中文</span><span class="dsh-newsboard-hint">使用当前模型或所选翻译接口；失败时自动回退原文。</span></div>
                ${switchMarkup(true)}
              </div>
              <div class="dsh-newsboard-form-grid">
                ${field("翻译接口", `<select class="dsh-newsboard-input"><option>百度翻译</option><option>当前模型（LLM）</option></select>`, "默认使用当前模型；也可选择百度翻译、有道翻译或 DeepL 等有免费额度的平台。")}
                ${field("百度翻译方式", `<select class="dsh-newsboard-input"><option>通用翻译</option><option>大模型翻译</option></select>`, "两种方式都使用百度翻译开放平台的 AppID/密钥，仅请求接口不同。")}
              </div>
            </div>
            <div class="dsh-newsboard-card-row">
              <div class="dsh-newsboard-card-header"><h3>屏蔽词</h3></div>
              ${field("屏蔽关键词", `<textarea class="dsh-newsboard-input" rows="2">sponsored
招聘</textarea>`, "每行一个；标题或摘要命中任一屏蔽词的消息不会出现在任何 Tab。")}
            </div>
          </div>
        </div>
      </div>
      ${footer()}
    </div>
  </div>`;
}

function deleteDialog() {
  return `<div class="dsh-newsboard-overlay">
    <div class="dsh-newsboard-dialog dsh-newsboard-dialog-confirm" role="dialog" aria-modal="true" aria-labelledby="dsh-newsboard-delete-title">
      <div class="dsh-newsboard-dialog-header">
        <h3 id="dsh-newsboard-delete-title" class="dsh-newsboard-dialog-title">删除分类</h3>
      </div>
      <div class="dsh-newsboard-dialog-body">
        <p class="dsh-newsboard-confirm-message">确定删除「新分类」吗？该分类的关键词与渠道配置将丢失；仅属于它的来源将不再抓取。</p>
      </div>
      <div class="dsh-newsboard-dialog-actions">
        <button type="button" class="dsh-newsboard-btn">取消</button>
        <button type="button" class="dsh-newsboard-btn dsh-newsboard-btn-danger">确认删除</button>
      </div>
    </div>
  </div>`;
}

function documentFor({ dark, platform, body, title }) {
  return `<!doctype html>
<html lang="zh-CN" data-platform="${platform}"${dark ? ' data-ds-dark-theme="true"' : ""}>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title}</title>
<style>
${dark ? darkTokens : lightTokens}
html,body{margin:0;height:100%;}
body{background:var(--dsw-alias-bg-base);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;}
${css}
</style>
</head>
<body>${body}</body>
</html>`;
}

const variants = [
  { file: "list-light.html", title: "list light", dark: false, platform: "darwin", mode: "list" },
  { file: "list-dark.html", title: "list dark", dark: true, platform: "darwin", mode: "list" },
  { file: "list-web-light.html", title: "list web", dark: false, platform: "web", mode: "list" },
  { file: "empty-dark.html", title: "empty dark", dark: true, platform: "darwin", mode: "empty" },
  { file: "settings-light.html", title: "settings light", dark: false, platform: "darwin", mode: "settings" },
  { file: "settings-dark.html", title: "settings dark", dark: true, platform: "darwin", mode: "settings" },
  { file: "delete-dialog-light.html", title: "delete dialog", dark: false, platform: "darwin", mode: "dialog" },
  { file: "delete-dialog-dark.html", title: "delete dialog dark", dark: true, platform: "darwin", mode: "dialog" },
];

await mkdir(outDir, { recursive: true });
for (const variant of variants) {
  let body;
  if (variant.mode === "settings") body = settingsPage({ platform: variant.platform });
  else if (variant.mode === "dialog") body = settingsPage({ platform: variant.platform }) + deleteDialog();
  else body = listPage({ platform: variant.platform, empty: variant.mode === "empty" });
  const html = documentFor({ dark: variant.dark, platform: variant.platform, body, title: variant.title });
  await writeFile(join(outDir, variant.file), html, "utf8");
  console.log(join(outDir, variant.file));
}
