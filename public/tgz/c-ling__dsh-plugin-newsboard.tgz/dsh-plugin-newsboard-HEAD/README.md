# dsh-plugin-newsboard

DeepSeek Harness 的 AI 与技术快讯看板。**0.2.1+** 版本改为官方同款的**左侧边栏入口 + 独立页面**：不再有右上角浮窗，也不再占用「设置」页；所有内容在 `快讯看板` 页面内完成浏览、搜索、来源切换、翻译与设置。

[English](README-en.md)

[![dsh-plugin topic](https://img.shields.io/badge/topic-dsh--plugin-blue)](https://github.com/topics/dsh-plugin)
[![license](https://img.shields.io/badge/license-MIT-green)](LICENSE)

> **当前发布：v2.0.0（DSH 0.2.1+，Web + Desktop）。**
> `v1.2.0` 是旧的浮窗 + Settings 页面版本，**不兼容 0.2.1**；从 0.1.x 升级请直接安装 `v2.0.0`。

## 功能

- **侧边栏独立页面**：左侧边栏「快讯看板」入口（`sidebar.panellist`）+ 独立主页面（`main` key `newsboard`）。页面为固定页头 / Tab 行 / 页脚，仅中间内容滚动。
- **双端一致**：Web 与 Desktop 使用同一份 bundle；页面页头显示 `🌐 Web` / `🖥 桌面端` 标识，macOS 额外预留 `--dsh-frame-top-clearance` 顶部安全区。所有接口走带认证的 `/api/dsh-plugin-newsboard/...` Connection 路由。
- **动态分类 Tab**：预设 `AI / 科技 / 游戏 / 生活` 四个分类，每个分类由「名称 + N 个关键词」组成，可在设置中新增/删除/改名并编辑关键词；Tab 顺序跟随分类顺序。`全部` 始终显示所有已抓取消息，不会因为关键词不匹配而丢消息。
- **新消息数量**：侧边栏「快讯看板」右侧显示未读数，页面标题右侧显示数字徽标；列表内对应的新消息还会显示「新」标签和蓝色描边。未读以「上次离开看板」为基线；首次安装会把当前缓存视为已读，避免一上来显示几十条未读。
- **分类来源矩阵**：24 个来源渠道按分类勾选归属，同一来源可归入多个分类；每个来源下方标注内容倾向（如「机核：中文游戏文化、评测与开发者访谈」）。宿主只抓取被任一**启用**分类选中的来源并自动去重。
- **分类启用/禁用与删除保护**：每个分类都有启用开关；禁用后不再拉取该分类独有来源，该分类的 Tab 隐藏，旧缓存中的独有来源消息也不再出现在「全部」。预设分类不可删除，只可禁用/修改；删除自定义分类会弹出二次确认窗。
- **双语条目**：默认调用 DeepSeek Harness 当前已配置的模型，把英文标题/摘要翻译成中文并随抓取缓存；也可切换百度翻译（通用 / 大模型）、有道翻译或 DeepL。翻译失败自动回退原文，中文优先展示，原文作为副标题。
- **完整设置页**：分类与关键词、分类来源矩阵、翻译开关与接口凭据、刷新间隔、展示条数、时间窗、全局屏蔽词。设置保存按钮位于 Tab 行右侧，只保存设置 Tab 自己的配置切片。
- **只写凭据**：翻译密钥/API Key 在读取时始终返回空串，只通过 `secretSet` 告知是否已配置；留空保存表示保持原值。
- **低打扰**：不弹通知、不发声；侧边栏入口每 60 秒静默拉取一次，宿主仅在缓存过期时抓取来源。
- **双语 UI**：中文 / English 随「设置 → 通用 → 语言」实时切换，无需刷新。

预设分类与默认来源：

| 分类 | 默认来源 |
| --- | --- |
| AI | HN AI 检索、OpenAI News、Google AI Blog、TechCrunch AI、The Verge AI、arXiv cs.AI、MIT 科技评论 |
| 科技 | Hacker News 首页、Lobsters、Ars Technica、IT之家、Solidot |
| 游戏 | 机核、游研社、GamesIndustry.biz、Rock Paper Shotgun |
| 生活 | 少数派、理想生活实验室、Atlas Obscura |

另外可选 5 个渠道：雷锋网（AI/产业）、36氪（科技商业）、爱范儿（消费电子/数字生活）、Indie Games Plus（独立游戏）、PC Gamer（PC 游戏）。每个渠道在设置页都有中英双语的内容倾向说明。

> 四个预设分类都自带一组初始关键词和默认勾选的来源渠道；关键词与渠道都可随时改写、清空或增删。关键词留空表示该分类接收其来源的全部消息。

## 安装

目标运行时：**DeepSeek Harness 0.2.1+**（Desktop `0.2.1-rc.2` 与更新版本、Web 0.2.1+）。本包声明了 `dsh.bundle`，推荐按 bundle 安装。

### Bundle（推荐）

```sh
# Web
dsh plugin --profile web add "github:c-ling/dsh-plugin-newsboard#v2.0.0"
# 或
npx @deepseek-ai/dsh plugin --profile web add "github:c-ling/dsh-plugin-newsboard#v2.0.0"

# Desktop（退出 App 后使用自带 CLI，或在 Plugins 页面安装该 tag）
dsh plugin --profile desktop add "github:c-ling/dsh-plugin-newsboard#v2.0.0"
```

`dsh plugin add` 会把包写入 `dsh.profile.bundles`，包内 `cordis.patch.yml` 负责插入 loader 行；**不要同时手写同一条 loader 行**。Desktop profile 由 App 管理，`npx @deepseek-ai/dsh ... --profile desktop` 会被拒绝，请使用 App 自带 CLI 或 Plugins 页面。

### 手动依赖 + loader 行（与 bundle 二选一）

```sh
cd ~/.dsh/profiles/web
corepack pnpm add "github:c-ling/dsh-plugin-newsboard#v2.0.0"
```

然后在 `~/.dsh/profiles/web/cordis.patch.yml` 增加：

```yaml
- insert:
    - id: dsh-plugin-newsboard
      name: 'dsh-plugin-newsboard'
```

> bundle 与手动 loader 行**不要同时使用**，否则会重复激活。安装/更新后必须重启宿主（Web 重启 `dsh web`，Desktop 退出并重新打开 App），再硬刷新页面；`client-modules` 按进程缓存包裁决。

本地开发验证可用 `link:` 安装（不会走 GitHub tag）：

```sh
cd ~/.dsh/profiles/web
corepack pnpm add "link:/absolute/path/to/dsh-plugin-newsboard"
# 然后在 profile 的 cordis.patch.yml 增加本插件的 insert 行；或使用 dsh plugin add "link:..."
```

## 使用

1. 左侧边栏点击「快讯看板」，页面默认打开「全部」；侧边栏和标题右侧的未读数来自上次离开后新增的消息。
2. 页头搜索框在当前分类内过滤；刷新按钮立即触发宿主抓取。
3. 切到「设置」：
   - 「分类」中改名、编辑关键词、启用/禁用分类、添加分类；预设分类不可删除，自定义分类删除会弹出二次确认窗；
   - 「来源渠道」矩阵中勾选每个来源归属的分类，来源下方有内容倾向说明；
   - 保存按钮在 Tab 行右侧，保存后立即按新分类/关键词重新归属消息，并触发一次后台刷新。
4. 分类/关键词/来源变化保存后，宿主刷新一次；翻译日志与抓取日志在设置卡片右上角查看。
5. 再次从其他页面进入时自动回到「全部」；页面不持久化 Tab。

## 数据与迁移

- 配置：`$DSH_HOME/storages/dsh-plugin-newsboard/config.json`（可用 entry config `directory` 覆盖目录）。
- 抓取缓存：`feed-cache.json`；日志：`logs.json`。
- 旧版 `config.json.migrated` 会在首次启动时一次性导入为新的 `config.json`，备份保留。
- 0.1.x 的 `settings.yaml` 命名空间不再使用；如果旧配置只在 settings 文档里，请在新页面重新填写（历史 `config.json.migrated` 仍可恢复大部分字段）。

## HTTP 接口

所有接口都需要浏览器认证，路径包含 `/api`：

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/dsh-plugin-newsboard/config` | 脱敏配置 + `secretSet` + `revision` + 来源元数据 |
| POST | `/api/dsh-plugin-newsboard/config` | 部分 patch + `expectedRevision` revision fence；409 `STALE_CONFIG` |
| GET | `/api/dsh-plugin-newsboard/feed` | 当前可见消息；缓存过期时后台刷新 |
| POST | `/api/dsh-plugin-newsboard/refresh` | 立即刷新 |
| GET | `/api/dsh-plugin-newsboard/logs/translation` | 翻译调用日志 |
| GET | `/api/dsh-plugin-newsboard/logs/fetch` | 来源抓取日志 |

配置字段：`refreshMinutes`、`maxItems`、`maxAgeHours`、`blockwords`、`categories`、`translate`、`translationProvider`、`translationBaiduMode`、`translationAppId`、`translationSecretKey`、`translationApiKey`。其中 `categories` 是 `{ id, name, keywords, sources }` 数组；旧配置的 `keywords` / `sources` 顶层字段会在首次启动时自动迁移为分类关键词与分类来源。POST 未知顶层字段返回 400 `UNKNOWN_CONFIG_KEY`——客户端热更新但 Host 仍是旧进程时会看到这个错误，需要重启宿主。

## 开发

```sh
node --check lib/index.js lib/client.js lib/config.js lib/store.js lib/connection-routes.js
node --test
python3 -m json.tool package.json
git diff --check
```

源码结构：

- `lib/index.js`：宿主插件入口——来源抓取、解析、去重过滤、翻译、缓存与 `ctx.connection.fetch.register` 路由。
- `lib/config.js`：默认值、归一化、secret 脱敏、部分 patch 白名单。
- `lib/store.js`：`config.json` 原子写入、revision fence、旧配置导入。
- `lib/connection-routes.js`：0.2.1 Fetch 路由表与错误信封（依赖无关，可直接用 `Request` 测试）。
- `lib/client.js`：手写 factory-CJS bundle，无构建步骤；`inject: ["slots", "locale", "layout"]`，注册 `sidebar.panellist` 与 keyed `main`。

验证要点：

```sh
# 未认证访问只到认证门（401），不能证明路由存在
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:<port>/api/dsh-plugin-newsboard/config
# 旧匿名路由应 404
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:<port>/dsh-plugin-newsboard/config
```

静态 UI 核对：`node tools/render-ui-harness.mjs /tmp/newsboard-ui` 生成与 `lib/client.js` 同源的 HTML，可用浏览器在浅色/深色与 1440px/1024px 下检查布局。

真正的路由存在性由 `test/connection-routes.test.mjs` / `test/host.test.mjs` 断言 registry key 为 `/api/...`；页面是否生效请在带认证的 GUI 中检查侧边栏入口与页面。

## 已知限制

- 依赖各来源站点的 RSS/JSON 可访问性；个别来源失败时页头显示「N 个来源不可用」，不影响其余来源。
- 首次打开且无缓存时最多等待约 10 秒完成首轮抓取；之后由缓存即时响应。
- 翻译是尽力而为的辅助能力：模型/接口不可用或凭据缺失时保留原文。
- 插件故意不做推送/声音打扰；如需任务结束提醒请配合 `dsh-plugin-notify` 使用。

## License

[MIT](LICENSE)
