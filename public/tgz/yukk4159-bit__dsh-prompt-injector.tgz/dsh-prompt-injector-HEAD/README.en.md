English | [简体中文](README.md)

# dsh-prompt-injector · Prompt Injector

A [DeepSeek Harness](https://deepseek.com/harness/) web plugin: reusable prompt presets are **injected into the front of the message at the moment it is sent**, instead of being typed into the composer.

How many times it injects is your call: **💌 inject the next message only** (default) or **💖 inject on every turn**.

Cute anime-style visuals: 🌸 pink-purple gradients, rounded cards, a little face that breathes.

Measured working on DeepSeek Harness `0.2.0-rc.2` (67 cases on the host side; the browser half has been exercised in a real GUI — see [Verified](#verified--not-yet-verified)).

## What it looks like

First choose the injection mode, then click a preset:

![The picker: choose one-shot or every-turn injection first](docs/picker.png)

Once picked, the chip becomes `💌 名字 下一条`, and **not one extra character lands in the composer**:

![Picked in one-shot mode: the chip reads 💌 … 下一条, the composer is untouched](docs/chip-once.png)

Send time is when the injection actually happens. Below is the result of sending twice in a row in 💖 每轮都注入 mode — both messages carry the preset block, while the composer still holds only what you wrote:

![Recorded messages: every-turn mode injected both, while the composer stays empty](docs/injected-messages.png)

---

## How it differs from "prompt preset" plugins

| | Common preset plugins | Prompt Injector |
|---|---|---|
| After picking a preset | The prompt is **filled into the composer** | Only a 💌 / 💖 badge appears to the left of the composer; the composer content does not move at all |
| While you type | You have to keep writing after a long block of prompt text | The composer holds only what you wrote |
| How many messages | Active for as long as it is picked | The next message only by default, then released automatically; injecting every turn is a switch you flip yourself |
| At send time | The prompt is part of the message (you can see it in the composer) | The host **prepends the prompt to the message** at `agent/pre-step` |
| Session log | The prompt is mixed in with your words | The log holds the complete injected text (whatever the model sees is what the log records) |

Where it is implemented: `applyInjection()` in `lib/inject.js`, registered on the `agent/pre-step` waterfall event — the last seam before messages enter the session log.

### Why not "stuff a marker into the composer"

The original design was to write an invisible pick marker into the composer draft and send it to the host along with the message. In practice that road does not work in the current version:

- DSH's composer is a Lexical editor, and there is **no public service for writing into the draft**;
- Lexical owns the document state itself, so changing the DOM directly gets overwritten by its next reconcile;
- Writing through DOM events (`execCommand('insertText')`) also depends on the current selection, and once the panel is open the focus is no longer on the editor.

So the choice was to let the **host keep it per session** instead: the browser half tells the host "which preset this session picked, and until when" through the plugin's HTTP interface (`/selection` in `lib/http.js`), and the host looks it up and injects at the instant of sending. This depends on none of the editor's internals and needs no polluting of the message text — and it incidentally makes "inject one message only" easy to implement: the host drops the selection as soon as it has injected.

> An earlier version also wrote a "best effort" draft writer; that code has been deleted. Writing into the draft made no difference anyway (the host-side selection is what actually decides), and keeping it around only blurred "who is in charge". The plugin now **never touches the composer**.

---

## Install

The plugin is a "bundle" (there is a `cordis.patch.yml` in the repository root); install it with `dsh plugin`:

```sh
dsh plugin --profile web add "github:yukk4159-bit/dsh-prompt-injector"
```

`dsh plugin` forwards package management to pnpm, so a local path or a specific branch works too:

```sh
# local checkout (use this while changing code; it takes effect after a restart)
dsh plugin --profile web add "/path/to/prompt-injector"

# a specific branch or tag
dsh plugin --profile web add "github:yukk4159-bit/dsh-prompt-injector#main"
```

Or, in an environment without a global `dsh`:

```sh
npx -p @deepseek-ai/dsh dsh plugin --profile web add "github:yukk4159-bit/dsh-prompt-injector"
```

After installing, **restart that profile**, then open the Web GUI:

- To the left of the composer there is a new 🌸 **预设** button — click it to pick a preset;
- Left sidebar → **设置** → **提示词注入器** — manage the preset library (create, read, update, delete, search, tag filtering).

---

## Usage

1. **Settings page**: write a preset — name, ID (optional), tags, injection content → save.
   Saving writes into that profile's config file (`config.presets` in `cordis.patch.yml`), so it survives restarts and session switches.
2. Click 🌸 to the left of the composer. At the top of the panel, first choose the **injection mode**, then click a preset:
   - **💌 inject the next message only** (default) — only the message you send right after this one is injected; the host drops the selection as soon as it has injected, so the next send is clean;
   - **💖 inject on every turn** — stays in effect until you click "cancel".
   The switch at the top of the panel takes effect **immediately**: when a preset is already picked, changing the mode also moves that pick to the new mode.
   The chip spells out which one is active (`💌 名字 下一条` / `💖 名字 每轮`), so "thought it was once, was actually injecting all along" cannot happen.
3. Write your message normally and press Enter to send.
4. At the instant of sending, the host wraps the preset body in the template and prepends it to the **front** of the message before handing it to the model.
5. In the default mode, the chip returns to 🌸 by itself after that one message is sent (while the panel is open it asks the host once every 3 seconds, because a one-shot selection is released by the host and the host cannot notify the page on its own).

Clicking the same preset again, or "cancel" in the panel, cancels it.

### Usable without the panel: `{{ID}}`

Write `{{code}}` directly in a message (`code` being that preset's ID) and that one message uses the corresponding preset, once and done — this is one-shot by nature, and it does not interfere with the chip's selection.

- An ID that **is in the library**: it is injected and that `{{code}}` is taken out of the message;
- An ID that is **not in the library**: it is sent as ordinary text, and it does not block the chip's selection either;
- Pointing at a **disabled** preset: nothing is injected, and the text stays as written.

### Injection precedence

1. An inline pick marker in the message body (`{{id}}`, or the private-use marker an earlier version wrote);
2. **This session's selection** (the one recorded in step 2 above);
3. `config.defaultPresetId`.

If a private-use marker points at a preset that does not exist or is disabled, it **deliberately suppresses** the two fallback levels — you named that one, so silently swapping in another would be wrong. A hand-typed `{{id}}` gets no such privilege, because it may just be ordinary text.

### Relationships

- A selection is **per session**: different sessions can pick different presets without interfering with each other.
- "How many messages to inject" is remembered in the browser (`localStorage`), so the next time you open the panel it is still the mode you chose last time.
- The selection itself lives in host process memory and is cleared by a restart — it expresses "which one I want for this turn", not persistent configuration. For something permanent use `defaultPresetId` (which by definition injects on every turn).

### What a preset looks like

```yaml
presets:
  - id: code
    name: 代码评审
    text: 请以资深工程师视角严格评审这段代码，指出风险与改进点。
    tags: [work, code]
    enabled: true
```

### Injection template

`config.template` decides the wrapping form; it supports `{{name}}`, `{{id}}`, `{{text}}`:

```text
[{{name}}]
{{text}}
[/{{name}}]
```

`config.separator` (two newlines by default) is joined between your own text and the preset block.
Change `config.position` from `prefix` (the default, front of the message) to `suffix` and it is appended at the end instead.

---

## All configuration options

| Config | Default | Description |
|---|---|---|
| `enabled` | `true` | Master switch. When off the UI is still there, but nothing is injected any more. |
| `position` | `prefix` | `prefix` prepends to the front of the message, `suffix` appends to the end. |
| `template` | `[{{name}}]\n{{text}}\n[/{{name}}]` | The wrapper around the preset body. |
| `separator` | two newlines | The joining string between the preset block and your own text. |
| `defaultPresetId` | empty | Fallback preset: used when nobody picked one and the message carries no marker. **It injects on every turn by definition**; empty means no injection. |
| `agentPresets` | `[]` | Only takes effect for these agent presets; empty means all of them. |
| `libraryPath` | empty | Optional JSON copy path (default `<DSH_HOME>/prompt-injector/prompt-injector.json`). |
| `presets` | `[]` | The preset library itself. |

> "How many messages to inject" is not a config option: it is **a gesture made each time you pick**, so it stays in the UI and in the browser instead of being written into the config.

---

## Where the data lives

1. **Primary storage for the preset library**: `config.presets` in that profile's `cordis.patch.yml`.
   The settings page writes it back through the Harness `settings.update()` when saving, so it is both "plugin config" and "preset library", and the automatic form on the settings page can edit it directly as well.
2. **Optional JSON copy**: when the `settings` provider is unavailable (or you want the library to travel with the repository), writes degrade to `libraryPath`; it can also be read from there when running with an agent the profile does not have.
3. **Session selection**: only in host process memory, never written to disk (see above).

## HTTP interface

The browser half talks to the host half over these three routes; they are mounted on the composed host web server, so they are protected by that server's browser-trust fence and authentication as well.

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/prompt-injector/prompt-injector/library` | Read the preset library, the tags and every session selection |
| `PUT` | `/prompt-injector/prompt-injector/library` | Overwrite the whole library |
| `PUT` | `/prompt-injector/prompt-injector/preset` | Add or update one entry (by id) |
| `DELETE` | `/prompt-injector/prompt-injector/preset?id=…` | Delete one entry |
| `GET` | `/prompt-injector/prompt-injector/selection` | Read-only session selections (this is what the panel polls) |
| `PUT` | `/prompt-injector/prompt-injector/selection` | Record/clear one session's selection; the body is `{sessionId, presetId, mode}`, where `mode` is `once` / `sticky` |

The `selections` returned by `GET /library` looks like `{"session-…": {"presetId": "code", "mode": "once"}}`. When `mode` is `once`, the host deletes that entry as soon as it has injected that one message — so it is gone from the next `GET`, which is how the panel restores the chip to 🌸.

The `prompt-injector` in the path is the plugin entry id, so two instances never overwrite each other.

---

## Project layout

```text
prompt-injector/
├─ cordis.patch.yml        # bundle entry: a single insert line
├─ package.json            # dsh.bundle + dsh.client declarations
├─ lib/                    # host half (Node)
│  ├─ index.js             # plugin entry: Config, pre-step injection, one-shot release, route and store wiring
│  ├─ config.js            # Config schema (its own file, to isolate the schemastery dependency)
│  ├─ core.js              # pure functions: preset normalization, marker encode/decode, injection modes, template rendering, composition
│  ├─ inject.js            # the agent/pre-step injection logic (pure functions + message rewrite)
│  ├─ store.js             # preset library storage + session selections (including once/sticky): settings write-through + atomic JSON copy
│  ├─ http.js              # /prompt-injector/<id>/library, /preset, /selection
│  └─ client/client.js     # build output: the browser half
├─ client/                 # browser half (hand-written lazy-CJS factory, no bundler needed)
│  ├─ index.js             # entry: apply/inject, slot registration, library and selection sync, mode preference
│  └─ src/                 # config / core / styles / composer / settings-page
├─ scripts/build-client.mjs # assembles client/ into client/client.js
├─ docs/                   # the screenshots used in the README
└─ test/                   # node:test, no third-party dependencies
```

`client/client.js` is a **build artifact committed to the repository**: Harness loads it directly, so anyone who clones the repository can install the plugin without building it first.

### Building the browser half

```sh
node scripts/build-client.mjs
```

The script does four things by itself: resolve relative `import`s, turn `react` / `react-dom` into platform `require`s, wrap each source file in its own closure, and finally package it as the module loader expects:
`window.__ModuleLoader__.load({ id, factory })`. No bundler dependency.

### Tests

```sh
node --test --experimental-test-isolation=none "test/*.test.js"
# or
node scripts/build-client.mjs && node --test --experimental-test-isolation=none "test/*.test.js"
```

The file glob is required: under `--experimental-test-isolation=none` a directory cannot be passed directly.
Inside a restricted sandbox (`workspace-write`) you must also keep `--experimental-test-isolation=none` — the default test runner spawns child processes over pipes, which the sandbox rejects (EPERM).

Coverage: preset normalization / marker encode-decode (including hand-typed `{{id}}`) / injection-mode normalization / template and composition / message rewriting (including exclusion of non-human messages, disabled presets, allow-list, `{{id}}` hit or miss) / session selections and one-shot release / store write-through and the atomic JSON copy / registration and slot contributions of the browser bundle / the full pre-step path of the host half's `apply()`.
67 cases in total; of those, "Config defaults" needs `@deepseek-ai/schemastery` to resolve and is skipped in a plain repository checkout.

### Verified / not yet verified

Already measured:

- **The injection really happens at send time, and really reaches the model request.** A temporary observer plugin listened on `llm/stream` and took evidence from the messages rewritten at `agent/pre-step`: the request contained `[PROBE-INJECTED] Reply with exactly: PROBE-OK`, showing that the rewritten content is exactly the message the model receives.
- **The plugin loads in a real profile**: after `dsh plugin --profile <name> add <this directory>` the bundle layer shows `- id: prompt-injector`, the host half applies normally, disabled presets are filtered out, and the HTTP routes register successfully.
- **The browser half runs in a real GUI**: the 🌸 preset chip appears to the left of the composer; the panel opens, searches and filters by tag; after picking, the chip shows the preset name and the mode; that session's selection can be seen in `selections` from the host's `/library`; after "cancel" the selection is cleared.
- **"Inject the next message only" really injects exactly one**: in a preview profile, 4 messages were really typed and sent with Enter (that profile uses a fake key, so the requests get 401, but the injection happens at `agent/pre-step`, i.e. before the request). The host trace and the body written into the session log were, respectively:
  - message 1 (💌 picked `code-review`): `changed=true preset=code-review source=session`
  - message 2: `changed=false source=none` — the selection had already been released
  - message 3 (switched to 💖 `novel`): `changed=true preset=novel source=session`
  - message 4: `changed=true preset=novel source=session` — injection continues in every-turn mode
  The session log matches entry by entry: message 1 carries a `[严格代码评审]…` block, message 2 is **unchanged**, messages 3 and 4 both carry a `[小说续写]…` block. After sending, `GET /selection` returns `{}` and the chip goes back to 🌸 by itself.
- **A hand-typed `{{id}}` works too**: sending `{{code-review}} 顺手看看 {{nope}} 这个写法` records the preset block plus `顺手看看 {{nope}} 这个写法` in the log — the one that hit was injected and removed, the one that missed was left as written.
- **The settings page can read and write**: the left sidebar's "设置 → 提示词注入器" lists 6 presets (including disabled ones, marked 🚫), search and tag filtering work, and after saving the host's `/library` really does return the changed library.
- **The complete chain from selection to injection** (automated case): one test in `test/host.test.js` writes a selection straight through the HTTP route, then drives `agent/pre-step`, asserting that `[小说续写]` appears at the front of the message, and that sticky injects into two consecutive messages while once injects only the first and is released afterwards.
- 67 cases on the host side, 66 passing and 1 skipped (the skipped one needs `@deepseek-ai/schemastery` to resolve on this machine).

**Not verified**: an actual model reply on real hardware (the preview profile has no usable key), and the behaviour of providers other than the official DeepSeek route — neither of these has anything to do with the injection logic.

### Debug switch

`DSH_PROMPT_INJECTOR_TRACE=1` prints every step of the host half to stderr (apply, library size, the webServer wait, the pre-step decision, the injection result).

---

## Implementation notes

- **The injection point is `agent/pre-step`.** It runs as a waterfall, and this plugin calls `next()` first and then rewrites the returned `messages`, so it composes with compaction and other pre-step policies instead of overriding them.
- **Only "human-written" user messages are rewritten**: `source.kind === 'user'`. Runtime-context snapshots, skill reminders and tool additions are never injected into.
- **At most one message is rewritten per step**, so the same preset is never multiplied.
- **Markers use private-use characters**, which cannot occur in normal text, so there are no false positives.
- **Failure lets the message through**: any injection error is logged and the message passes unchanged; content you sent is never lost because of a plugin problem.
- **Every resource has an owner**: routes, effects and stylesheets are all registered on the plugin fiber's effect, and are reclaimed automatically when the plugin unloads.

## Known limitations

- **A selection lives only in host process memory**, and restarting DSH clears it. It is the intent "which one for this round", not persistent configuration; for something permanent configure `defaultPresetId`.
- Writes to the preset library depend on the Harness `settings` service. When it is unavailable the store degrades to the JSON copy, and in that case edits from the settings page only take effect within the current process.
- The injected text does enter the session log — deliberately so: the record should equal what the model actually received.
- **A one-shot selection is released by the host, and the page can only find out after the fact**: while the panel is open it calls `GET /selection` once every 3 seconds (polling only while a one-shot selection is waiting to be sent). So after sending a message the chip can take up to 3 seconds to change from 💌 back to 🌸 — this does not affect injection, the badge is just one beat late.
- `{{id}}` only counts as a reference when the ID matches a preset in the library, so the more a preset ID looks like an ordinary word (for example `code`), the more likely it is to catch a `{{code}}` written in ordinary prose. If that bothers you, give the ID something distinctive (for example `pi-code`).

## Contributing

Issues for bugs and ideas, or a pull request, are all welcome. After changing code in the browser half, remember to run
`node scripts/build-client.mjs` — `client/client.js` is a build artifact that has to be committed along with the change.

## License

MIT, see [LICENSE](LICENSE).
