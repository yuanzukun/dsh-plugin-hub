#!/usr/bin/env node
/**
 * Build the browser half into the lazy-CJS factory the Harness client module
 * system expects.
 *
 * The project deliberately ships no bundler: this script does the small amount
 * of work the build actually needs.
 *   1. read the browser sources,
 *   2. resolve their relative imports by hand and drop the import/export syntax,
 *   3. wrap every module in its own closure and give it a tiny `require`,
 *   4. emit `window.__ModuleLoader__.load({ id, factory })`.
 *
 * External platform modules (react, react-dom) are redirected to the loader's
 * own `require`, which the module system resolves against its seed table.
 */

import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname, join, posix, relative, resolve } from 'node:path'

const root = resolve(import.meta.dirname, '..')
const entry = join(root, 'client', 'index.js')
const outFile = join(root, 'client', 'client.js')

/** Browser sources live in their own namespace so ids stay readable. */
const MODULE_PREFIX = 'dpi:'

/**
 * Platform modules the loader resolves itself. Everything else that is not a
 * relative import is a build error, because cross-plugin value imports are
 * rejected by the client bundle-purity gate anyway.
 */
const EXTERNALS = new Map([
  ['react', 'react'],
  ['react-dom', 'react-dom'],
  ['react/jsx-runtime', 'react/jsx-runtime'],
])

/**
 * @typedef {{ id: string, source: string, deps: Map<string, string>, body: string }} Module
 */

/**
 * Turn a `{ a, b as c }` import clause into `const` declarations over a module.
 * @param {string} clause
 * @param {string} local
 * @returns {string[]}
 */
function destructure(clause, local) {
  const lines = []
  for (const piece of clause.split(',')) {
    const trimmed = piece.trim()
    if (trimmed.length === 0) continue
    const [from, to] = trimmed.split(/\s+as\s+/).map((value) => value.trim())
    lines.push(`const ${to ?? from} = ${local}[${JSON.stringify(from)}];`)
  }
  return lines
}

/**
 * Turn one source file into a module body: relative imports become `dpi:`
 * module ids, external imports become loader `require` calls, and the
 * import/export statements disappear.
 * @param {string} id
 * @param {string} source
 * @param {(specifier: string) => string} resolveId
 * @returns {Module}
 */
function transform(id, source, resolveId) {
  /** @type {Map<string, string>} */
  const deps = new Map()
  /** @type {string[]} */
  /** @type {Set<string>} */
  const exported = new Set()
  let index = 0

  let body = source.replace(
    /^[ \t]*import\s+(?:([\w$]+)\s*,\s*)?(?:\{([^}]*)\}|\*\s+as\s+([\w$]+)|([\w$]+))?\s*from\s*['"]([^'"]+)['"];?[ \t]*$/gm,
    (whole, defaultName, named, namespace, bare, specifier) => {
      if (EXTERNALS.has(specifier)) {
        const local = `__ext${index++}`
        const parts = [`const ${local} = __require(${JSON.stringify(EXTERNALS.get(specifier))});`]
        if (bare) parts.push(`const ${bare} = ${local};`)
        if (defaultName) parts.push(`const ${defaultName} = ${local}.default ?? ${local};`)
        if (namespace) parts.push(`const ${namespace} = ${local};`)
        if (named) parts.push(...destructure(named, local))
        return parts.join('\n')
      }
      const target = resolveId(specifier)
      deps.set(specifier, target)
      const local = `__m${index++}`
      const parts = [`const ${local} = __require(${JSON.stringify(target)});`]
      if (bare) parts.push(`const ${bare} = ${local};`)
      if (defaultName) parts.push(`const ${defaultName} = ${local}.default ?? ${local};`)
      if (namespace) parts.push(`const ${namespace} = ${local};`)
      if (named) parts.push(...destructure(named, local))
      return parts.join('\n')
    },
  )

  body = body.replace(/^[ \t]*import\s*['"]([^'"]+)['"];?[ \t]*$/gm, (whole, specifier) => {
    if (EXTERNALS.has(specifier)) return `__require(${JSON.stringify(EXTERNALS.get(specifier))});`
    const target = resolveId(specifier)
    deps.set(specifier, target)
    return `__require(${JSON.stringify(target)});`
  })

  body = body.replace(/^[ \t]*export\s+default\s+/gm, 'exports.default = ')
  body = body.replace(/^[ \t]*export\s+(async\s+)?function\s+([\w$]+)/gm, (whole, asyncKeyword, name) => {
    exported.add(name)
    return `${asyncKeyword ?? ''}function ${name}`
  })
  body = body.replace(
    /^[ \t]*export\s*\{([^}]*)\};?[ \t]*$/gm,
    (whole, names) => {
      const lines = []
      for (const piece of names.split(',')) {
        const trimmed = piece.trim()
        if (trimmed.length === 0) continue
        const [from, to] = trimmed.split(/\s+as\s+/).map((value) => value.trim())
        lines.push(`exports[${JSON.stringify(to ?? from)}] = ${from};`)
      }
      return lines.join('\n')
    },
  )
  body = body.replace(/^[ \t]*export\s+(const|let|var|class)\s+([\w$]+)/gm, (whole, keyword, name) => {
    exported.add(name)
    return `${keyword} ${name}`
  })

  if (exported.size > 0) {
    body += '\n' + [...exported].map((name) => `exports[${JSON.stringify(name)}] = ${name};`).join('\n')
  }

  if (/^\s*export\s/m.test(body)) {
    throw new Error(`${id}: unsupported export syntax remains in the transformed source`)
  }

  return { id, source, deps, body }
}

/**
 * Collect a module graph depth-first from the entry.
 * @param {string} entryPath
 * @returns {Promise<Module[]>}
 */
async function collect(entryPath) {
  /** @type {Map<string, Module>} */
  const modules = new Map()

  const resolveId = (fromFile, specifier) => {
    const absolute = resolve(dirname(fromFile), specifier)
    return MODULE_PREFIX + posix.normalize(relative(root, absolute).split('\\').join('/'))
  }

  const visit = async (filePath) => {
    const id = MODULE_PREFIX + posix.normalize(relative(root, filePath).split('\\').join('/'))
    if (modules.has(id)) return id
    const source = await readFile(filePath, 'utf8')
    const module = transform(id, source, (specifier) => resolveId(filePath, specifier))
    modules.set(id, module)
    for (const specifier of module.deps.keys()) {
      const absolute = resolve(dirname(filePath), specifier)
      await visit(absolute)
    }
    return id
  }

  const entryId = await visit(entryPath)
  return [modules.get(entryId), ...[...modules.values()].filter((module) => module.id !== entryId)]
}

/**
 * Emit the loader registration.
 * @param {string} entryId
 * @param {Module[]} modules
 * @param {string} packageName
 * @param {string} css
 * @returns {string}
 */
function emit(entryId, modules, packageName, css) {
  const cssTag = `${packageName}/styles.css`
  const lines = []
  lines.push('window.__ModuleLoader__.load({')
  lines.push(`\tid: ${JSON.stringify(packageName)},`)
  lines.push('\tfactory: (require) => {')
  // A factory failure is reported by the loader as a bare entry name, which is
  // useless for diagnosis. Surface the real error on the console (and keep it
  // as a global for a debugger) before rethrowing, so the loader's own report
  // still sees the failure.
  lines.push('\t\ttry {')
  lines.push('\t\tvar module = { exports: {} };')
  lines.push('\t\tvar exports = module.exports;')
  lines.push('\t\tObject.defineProperty(exports, Symbol.toStringTag, { value: "Module" });')
  lines.push('\t\tvar __require = require;')
  lines.push('\t\tvar __factories = {};')
  lines.push('\t\tvar __cache = {};')
  lines.push('\t\tfunction __load(id) {')
  lines.push('\t\t\tif (Object.prototype.hasOwnProperty.call(__cache, id)) return __cache[id].exports;')
  lines.push('\t\t\tvar factory = __factories[id];')
  lines.push('\t\t\tif (factory === undefined) {')
  lines.push('\t\t\t\t// Platform modules are not in the graph; the loader owns them.')
  lines.push('\t\t\t\tif (typeof id === "string" && id.indexOf("dpi:") !== 0) return __require(id);')
  lines.push('\t\t\t\tthrow new Error("prompt-injector: unknown module " + id);')
  lines.push('\t\t\t}')
  lines.push('\t\t\tvar record = { exports: {} };')
  lines.push('\t\t\t__cache[id] = record;')
  lines.push('\t\t\tfactory(record, record.exports, __load);')
  lines.push('\t\t\treturn record.exports;')
  lines.push('\t\t}')
  lines.push('\t\t// Plugin stylesheet, installed once per page.')
  lines.push(`\t\tif (typeof document !== "undefined" && document.querySelector('style[data-plugin-css="${cssTag}"]') === null) {`)
  lines.push('\t\t\tvar __style = document.createElement("style");')
  lines.push(`\t\t\t__style.dataset.plugin = ${JSON.stringify(packageName)};`)
  lines.push(`\t\t\t__style.dataset.pluginCss = ${JSON.stringify(cssTag)};`)
  lines.push(`\t\t\t__style.textContent = ${JSON.stringify(css)};`)
  lines.push('\t\t\tdocument.head.appendChild(__style);')
  lines.push('\t\t}')
  for (const module of modules) {
    lines.push(`\t\t__factories[${JSON.stringify(module.id)}] = (module, exports, __require) => {`)
    lines.push(module.body)
    lines.push('\t\t};')
  }
  lines.push('\t\tvar entry = __load(' + JSON.stringify(entryId) + ');')
  lines.push('\t\treturn entry;')
  lines.push('\t\t} catch (error) {')
  lines.push(`\t\t\tglobalThis.__DSH_PROMPT_INJECTOR_ERROR__ = error;`)
  lines.push(`\t\t\tconsole.error(${JSON.stringify(packageName + ": factory failed")}, error);`)
  lines.push('\t\t\tthrow error;')
  lines.push('\t\t}')
  lines.push('\t}')
  lines.push('});')
  return lines.join('\n') + '\n'
}

const manifest = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'))
const packageName = manifest.name
const modules = await collect(entry)
const entryModule = modules[0]
const stylesSource = await readFile(join(root, 'client', 'src', 'styles.js'), 'utf8')
const stylesMatch = /export const MOE_CSS = `([\s\S]*)`\n/.exec(stylesSource)
if (stylesMatch === null) throw new Error('client/src/styles.js: MOE_CSS template literal not found')
const css = stylesMatch[1].replace(/\\`/g, '`').replace(/\\\$\{/g, '${')

await mkdir(dirname(outFile), { recursive: true })
await writeFile(outFile, emit(entryModule.id, modules, packageName, css), 'utf8')
process.stdout.write(`built ${relative(root, outFile)} (${modules.length} modules)\n`)
