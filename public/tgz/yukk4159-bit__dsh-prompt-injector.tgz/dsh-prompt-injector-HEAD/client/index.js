/**
 * Browser half of dsh-prompt-injector.
 *
 * Responsibilities:
 *   - a composer toolbar chip that opens the preset picker,
 *   - the "moe" panel, book and chip styling,
 *   - the Settings page that owns library CRUD, search and tag filters,
 *   - telling the host half which preset the session picked, and whether that
 *     pick covers the next message only or every message. The selection is a UI
 *     gesture, so it lives here; the preset TEXT is injected by the host half at
 *     send time and never enters the composer draft.
 *
 * The loader delivers this file as a lazy-CJS factory, so the source stays in
 * plain JavaScript and `scripts/build-client.mjs` wraps it. JSX is avoided on
 * purpose: `React.createElement` keeps the build free of a compiler.
 */
import { CONFIG } from './src/config.js'
import { TOKEN_HEAD, TOKEN_TAIL, filterPresets, normalizeMode, selectionOf, slugify, validateDraft } from './src/core.js'
import { createComposerButton } from './src/composer.js'
import { createSettingsPage } from './src/settings-page.js'

/**
 * Required client services.
 *
 * `slots` must be declared here. The Cordis client context is a guarded facade:
 * reading `ctx.slots` — or any other service — without a matching `inject` entry
 * throws at runtime, and the boot audit reports the whole entry as failed. The
 * declarations are hard dependencies, so the fiber waits for the service instead
 * of racing it.
 */
export const inject = ['slots']

/** Debug aid: keep the last registration failure visible in the page. */
function noteFailure(step, error) {
  try {
    const list = (globalThis.__DSH_PROMPT_INJECTOR_STEPS__ ??= [])
    list.push(`${step}: ${error instanceof Error ? `${error.name}: ${error.message}` : String(error)}`)
    console.error(`[prompt-injector] ${step} failed`, error)
  } catch {
    /* the debug aid must never be the reason a plugin fails */
  }
}

/**
 * Mount the browser half.
 * @param {object} ctx - restricted Cordis client context
 * @param {{ styles?: { insert(css: string): () => void } }} [deps] - loader builtins
 */
export function apply(ctx, deps) {
  void deps
  const state = {
    library: [],
    revision: '',
    error: '',
    ready: false,
    /** session id -> { presetId, mode }, mirrored from the host half. */
    selections: {},
    listeners: new Set(),
    /** Cached view of `state` for `useSyncExternalStore`. */
    snapshot: undefined,
  }

  /**
   * The mode the picker opens on, remembered across reloads.
   *
   * `once` unless the user has explicitly asked for every turn: repeating an
   * injection is a decision, not a default.
   * @type {import('./src/core.js').InjectionMode}
   */
  let preferredMode = (() => {
    try {
      return normalizeMode(globalThis.localStorage?.getItem(CONFIG.modeKey))
    } catch {
      return normalizeMode(undefined)
    }
  })()

  const emit = () => {
    // `useSyncExternalStore` compares snapshots by identity: handing it a fresh
    // object on every read is an infinite render loop (React error #185), so the
    // view is materialized only when the state actually changes.
    state.snapshot = {
      library: state.library,
      revision: state.revision,
      error: state.error,
      ready: state.ready,
      selections: state.selections,
    }
    for (const listener of [...state.listeners]) {
      try {
        listener()
      } catch (error) {
        console.error('[prompt-injector] listener failed', error)
      }
    }
  }

  const subscribe = (listener) => {
    state.listeners.add(listener)
    return () => state.listeners.delete(listener)
  }

  const snapshot = () =>
    (state.snapshot ??= {
      library: state.library,
      revision: state.revision,
      error: state.error,
      ready: state.ready,
      selections: state.selections,
    })

  const setLibrary = (presets, revision, selections) => {
    state.library = Array.isArray(presets) ? presets : []
    state.revision = typeof revision === 'string' ? revision : ''
    if (selections !== undefined && selections !== null && typeof selections === 'object') {
      state.selections = selections
    }
    state.ready = true
    state.error = ''
    emit()
  }

  const request = async (path, init) => {
    const response = await fetch(`/prompt-injector/${CONFIG.id}${path}`, {
      headers: { 'content-type': 'application/json' },
      ...init,
    })
    const body = await response.json().catch(() => undefined)
    if (!response.ok) throw new Error(body?.error ?? `HTTP ${response.status}`)
    return body
  }

  const refresh = async () => {
    try {
      const body = await request('/library')
      setLibrary(body?.presets, body?.revision, body?.selections)
    } catch (error) {
      state.ready = true
      state.error = error instanceof Error ? error.message : String(error)
      emit()
    }
  }

  const savePreset = async (preset) => {
    const body = await request('/preset', { method: 'PUT', body: JSON.stringify(preset) })
    setLibrary(body?.presets, body?.revision, body?.selections)
    return body?.saved
  }

  const removePreset = async (id) => {
    const body = await request(`/preset?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
    setLibrary(body?.presets, body?.revision, body?.selections)
  }

  /**
   * Remember which mode the user reached for last, so the picker opens on the
   * choice they made before. Storage is optional: a page without it still works,
   * it just forgets.
   * @returns {import('./src/core.js').InjectionMode}
   */
  const getPreferredMode = () => preferredMode

  /**
   * @param {unknown} mode
   * @returns {import('./src/core.js').InjectionMode}
   */
  const setPreferredMode = (mode) => {
    preferredMode = normalizeMode(mode)
    try {
      globalThis.localStorage?.setItem(CONFIG.modeKey, preferredMode)
    } catch {
      /* a page without storage keeps the in-memory preference only */
    }
    return preferredMode
  }

  /** Read one session's selection, tolerating a host that reports bare ids. */
  const getSelection = (sessionId) => selectionOf(state.selections, sessionId)

  /**
   * Record (or clear) the picked preset for one session.
   *
   * The selection lives on the host half, not in the message: the composer has
   * no supported way for a third-party plugin to write into its draft, so
   * putting the intent in the draft was never reliable. The host injects the
   * selected preset at send time instead, and for how long is `mode`.
   * @param {unknown} sessionId
   * @param {unknown} presetId
   * @param {unknown} [mode]
   */
  const setActiveId = async (sessionId, presetId, mode) => {
    const key = typeof sessionId === 'string' && sessionId.length > 0 ? sessionId : 'global'
    const chosen = setPreferredMode(mode ?? preferredMode)
    const next = { ...state.selections }
    if (typeof presetId === 'string' && presetId.length > 0) next[key] = { presetId, mode: chosen }
    else delete next[key]
    // Optimistic: the chip responds immediately, then the host confirms.
    state.selections = next
    emit()
    try {
      const body = await request('/selection', {
        method: 'PUT',
        body: JSON.stringify({ sessionId: key, presetId: presetId ?? '', mode: chosen }),
      })
      if (body?.selections) {
        state.selections = body.selections
        emit()
      }
    } catch (error) {
      state.error = error instanceof Error ? error.message : String(error)
      emit()
    }
  }

  /**
   * Re-read just the selections.
   *
   * A one-shot pick is released by the HOST the moment it injects, and the host
   * has no channel to the page, so the composer polls this while a one-shot is
   * pending. It is a local, authenticated GET, and it only runs while there is
   * something to notice.
   */
  const refreshSelections = async () => {
    try {
      const body = await request('/selection')
      if (body?.selections) {
        state.selections = body.selections
        emit()
      }
    } catch {
      /* a transient read failure must never blank the picker */
    }
  }

  const deps_ = {
    store: {
      subscribe,
      snapshot,
      refresh,
      refreshSelections,
      savePreset,
      removePreset,
      getSelection,
      setActiveId,
      getPreferredMode,
      setPreferredMode,
      filterPresets,
      searchPresets: (library, query) => filterPresets(library, query, []),
      validateDraft,
      slugify,
    },
  }

  const registerSlot = (key, options, component) => {
    try {
      ctx.slots.inject(key, () => ctx.slots.register({ name: key, ...options }, component))
    } catch (error) {
      noteFailure(`slots.inject(${key})`, error)
    }
  }

  registerSlot(
    'conversation.input.left',
    { id: CONFIG.slotId, order: CONFIG.slotOrder, label: CONFIG.title },
    createComposerButton(deps_),
  )
  registerSlot(
    'settings.section',
    { id: CONFIG.settingsId, order: CONFIG.settingsOrder, label: () => CONFIG.title },
    createSettingsPage(deps_),
  )

  refresh()

  try {
    ctx.effect(
      () => () => {
        state.listeners.clear()
      },
      'prompt-injector: client teardown',
    )
  } catch (error) {
    noteFailure('ctx.effect', error)
  }
}

export { TOKEN_HEAD, TOKEN_TAIL }
