window.__ModuleLoader__.load({
	id: "dsh-prompt-injector",
	factory: (require) => {
		try {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		var __require = require;
		var __factories = {};
		var __cache = {};
		function __load(id) {
			if (Object.prototype.hasOwnProperty.call(__cache, id)) return __cache[id].exports;
			var factory = __factories[id];
			if (factory === undefined) {
				// Platform modules are not in the graph; the loader owns them.
				if (typeof id === "string" && id.indexOf("dpi:") !== 0) return __require(id);
				throw new Error("prompt-injector: unknown module " + id);
			}
			var record = { exports: {} };
			__cache[id] = record;
			factory(record, record.exports, __load);
			return record.exports;
		}
		// Plugin stylesheet, installed once per page.
		if (typeof document !== "undefined" && document.querySelector('style[data-plugin-css="dsh-prompt-injector/styles.css"]') === null) {
			var __style = document.createElement("style");
			__style.dataset.plugin = "dsh-prompt-injector";
			__style.dataset.pluginCss = "dsh-prompt-injector/styles.css";
			__style.textContent = "\n.dpi-root {\n  --dpi-pink: var(--dsw-alias-state-business-primary, #ff8ec4);\n  --dpi-pink-strong: #ff5fa8;\n  --dpi-lilac: #b79cff;\n  --dpi-mint: #7fe0d4;\n  --dpi-ink: var(--dsw-alias-label-primary, #2b2436);\n  --dpi-ink-soft: var(--dsw-alias-label-secondary, #6b6178);\n  --dpi-ink-faint: var(--dsw-alias-label-tertiary, #9a92a6);\n  --dpi-line: var(--dsw-alias-border-l2, rgba(183, 156, 255, 0.35));\n  --dpi-surface: var(--dsw-alias-bg-layer-1, #fffafd);\n  --dpi-surface-2: var(--dsw-alias-bg-layer-2, #fff3fa);\n  --dpi-shadow: 0 10px 30px rgba(255, 95, 168, 0.18);\n  --dpi-radius: 16px;\n  font-family: inherit;\n  color: var(--dpi-ink);\n}\n\n/* ---------------------------------------------------------------- chip --- */\n\n.dpi-chip {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  height: 28px;\n  padding: 0 10px;\n  border-radius: 999px;\n  border: 1px solid var(--dpi-line);\n  background: linear-gradient(135deg, var(--dpi-surface-2), var(--dpi-surface));\n  color: var(--dpi-ink);\n  font: inherit;\n  font-size: 12px;\n  line-height: 1;\n  cursor: pointer;\n  transition: transform 140ms ease, box-shadow 140ms ease, border-color 140ms ease;\n}\n.dpi-chip:hover {\n  transform: translateY(-1px) scale(1.03);\n  border-color: var(--dpi-pink);\n  box-shadow: 0 6px 16px rgba(255, 95, 168, 0.22);\n}\n.dpi-chip:focus-visible {\n  outline: var(--dsw-focus-ring-width, 2px) solid var(--dsw-focus-ring-color, var(--dpi-lilac));\n  outline-offset: 2px;\n}\n.dpi-chip[data-active='true'] {\n  border-color: var(--dpi-pink);\n  background: linear-gradient(135deg, #ffe3f1, #f3e8ff);\n  box-shadow: 0 4px 14px rgba(255, 95, 168, 0.24);\n}\n.dpi-chip[data-empty='true'] {\n  color: var(--dpi-ink-faint);\n}\n.dpi-chip-emoji {\n  font-size: 13px;\n  line-height: 1;\n}\n.dpi-chip-name {\n  max-width: 12ch;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n/* The mode badge is what keeps \"this one message\" and \"every message\" visibly\n   different at a glance, so a sticky pick can never masquerade as a one-shot. */\n.dpi-chip-mode {\n  font-size: 10px;\n  padding: 1px 6px;\n  border-radius: 999px;\n  background: rgba(183, 156, 255, 0.24);\n  color: var(--dpi-ink-soft);\n  letter-spacing: 0.02em;\n}\n.dpi-chip[data-mode='sticky'] .dpi-chip-mode {\n  background: rgba(255, 95, 168, 0.22);\n  color: var(--dpi-pink-strong);\n}\n.dpi-chip[data-mode='sticky'] {\n  background: linear-gradient(135deg, #ffdcec, #f1e4ff);\n}\n\n/* --------------------------------------------------------------- panel --- */\n\n.dpi-panel {\n  position: fixed;\n  z-index: 60;\n  width: min(380px, calc(100vw - 24px));\n  /* The component sets maxHeight from the space actually available above the\n     chip, so the header can never be pushed off-screen. */\n  max-height: 560px;\n  display: flex;\n  flex-direction: column;\n  border-radius: var(--dpi-radius);\n  border: 1px solid var(--dpi-line);\n  background: var(--dpi-surface);\n  box-shadow: var(--dpi-shadow);\n  overflow: hidden;\n  animation: dpi-pop 160ms ease-out;\n}\n@keyframes dpi-pop {\n  from {\n    transform: translateY(8px) scale(0.97);\n    opacity: 0;\n  }\n  to {\n    transform: translateY(0) scale(1);\n    opacity: 1;\n  }\n}\n\n.dpi-panel-head {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: 10px 12px 8px;\n  background: linear-gradient(135deg, #ffe9f4, #efe6ff);\n  border-bottom: 1px dashed var(--dpi-line);\n}\n.dpi-panel-title {\n  margin: 0;\n  font-size: 13px;\n  font-weight: 700;\n  letter-spacing: 0.02em;\n}\n.dpi-panel-sub {\n  font-size: 11px;\n  color: var(--dpi-ink-faint);\n  margin-left: auto;\n}\n.dpi-close {\n  border: 0;\n  background: transparent;\n  color: var(--dpi-ink-soft);\n  font-size: 14px;\n  cursor: pointer;\n  border-radius: 8px;\n  padding: 2px 6px;\n}\n.dpi-close:hover {\n  background: rgba(255, 95, 168, 0.14);\n  color: var(--dpi-pink-strong);\n}\n\n.dpi-search-row {\n  display: flex;\n  gap: 6px;\n  padding: 8px 12px 4px;\n}\n\n/* --------------------------------------------------------- mode switch --- */\n\n.dpi-modes {\n  display: flex;\n  gap: 6px;\n  padding: 8px 12px 0;\n}\n.dpi-mode {\n  flex: 1;\n  min-width: 0;\n  padding: 6px 8px;\n  border-radius: 10px;\n  border: 1px dashed var(--dpi-line);\n  background: transparent;\n  color: var(--dpi-ink-soft);\n  font: inherit;\n  font-size: 11.5px;\n  cursor: pointer;\n  transition: transform 120ms ease, border-color 120ms ease, background 120ms ease;\n}\n.dpi-mode:hover {\n  transform: translateY(-1px);\n  border-color: var(--dpi-pink);\n}\n.dpi-mode[data-on='true'] {\n  border-style: solid;\n  border-color: var(--dpi-pink-strong);\n  background: linear-gradient(135deg, #ffe3f1, #f0e7ff);\n  color: var(--dpi-ink);\n  font-weight: 650;\n}\n.dpi-mode-hint {\n  margin: 6px 12px 0;\n  font-size: 11px;\n  color: var(--dpi-ink-faint);\n}\n.dpi-input {\n  flex: 1;\n  min-width: 0;\n  height: 30px;\n  padding: 0 10px;\n  border-radius: 10px;\n  border: 1px solid var(--dpi-line);\n  background: var(--dpi-surface-2);\n  color: var(--dpi-ink);\n  font: inherit;\n  font-size: 12px;\n}\n.dpi-input:focus {\n  outline: none;\n  border-color: var(--dpi-pink);\n  box-shadow: 0 0 0 3px rgba(255, 143, 196, 0.22);\n}\n\n.dpi-tags {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 5px;\n  padding: 6px 12px 2px;\n}\n.dpi-tag {\n  border: 1px solid var(--dpi-line);\n  background: transparent;\n  color: var(--dpi-ink-soft);\n  border-radius: 999px;\n  padding: 2px 9px;\n  font: inherit;\n  font-size: 11px;\n  cursor: pointer;\n}\n.dpi-tag[data-on='true'] {\n  background: linear-gradient(135deg, #ffd9ec, #e6dbff);\n  border-color: var(--dpi-pink);\n  color: var(--dpi-ink);\n}\n\n.dpi-list {\n  list-style: none;\n  margin: 6px 0 0;\n  padding: 0 8px 8px;\n  overflow: auto;\n}\n.dpi-card {\n  width: 100%;\n  text-align: left;\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  padding: 9px 10px;\n  margin: 4px 0;\n  border-radius: 12px;\n  border: 1px solid transparent;\n  background: var(--dpi-surface-2);\n  color: inherit;\n  font: inherit;\n  cursor: pointer;\n  transition: border-color 120ms ease, transform 120ms ease, background 120ms ease;\n}\n.dpi-card:hover {\n  border-color: var(--dpi-pink);\n  transform: translateX(2px);\n  background: #fff0f8;\n}\n.dpi-card[data-active='true'] {\n  border-color: var(--dpi-pink-strong);\n  background: linear-gradient(135deg, #ffe6f3, #f0e7ff);\n}\n.dpi-card-name {\n  font-size: 12.5px;\n  font-weight: 650;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.dpi-card-crumb {\n  font-size: 10.5px;\n  color: var(--dpi-ink-faint);\n  letter-spacing: 0.04em;\n}\n.dpi-card-text {\n  font-size: 11.5px;\n  color: var(--dpi-ink-soft);\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n  white-space: pre-wrap;\n}\n.dpi-card-tags {\n  display: flex;\n  gap: 4px;\n  flex-wrap: wrap;\n}\n.dpi-mini-tag {\n  font-size: 10px;\n  padding: 1px 7px;\n  border-radius: 999px;\n  background: rgba(183, 156, 255, 0.18);\n  color: var(--dpi-ink-soft);\n}\n\n.dpi-empty {\n  padding: 18px 14px 22px;\n  text-align: center;\n  font-size: 12px;\n  color: var(--dpi-ink-faint);\n}\n.dpi-empty-emoji {\n  display: block;\n  font-size: 22px;\n  margin-bottom: 6px;\n  animation: dpi-bob 1.8s ease-in-out infinite;\n}\n@keyframes dpi-bob {\n  0%, 100% { transform: translateY(0); }\n  50% { transform: translateY(-4px); }\n}\n\n.dpi-note {\n  margin: 0;\n  padding: 8px 12px 10px;\n  font-size: 11px;\n  color: var(--dpi-ink-faint);\n  border-top: 1px dashed var(--dpi-line);\n}\n.dpi-error {\n  color: #d94f7a;\n}\n\n/* ------------------------------------------------------------ settings --- */\n\n.dpi-settings {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  max-width: 760px;\n}\n.dpi-settings-head {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.dpi-h2 {\n  margin: 0;\n  font-size: 18px;\n  font-weight: 700;\n}\n.dpi-blurb {\n  margin: 0;\n  font-size: 12.5px;\n  color: var(--dpi-ink-faint);\n}\n.dpi-banner {\n  border-radius: 12px;\n  border: 1px dashed var(--dpi-line);\n  background: linear-gradient(135deg, #fff0f8, #f4edff);\n  padding: 10px 12px;\n  font-size: 12px;\n  color: var(--dpi-ink-soft);\n}\n.dpi-grid {\n  display: grid;\n  grid-template-columns: minmax(0, 320px) minmax(0, 1fr);\n  gap: 14px;\n  align-items: start;\n}\n@media (max-width: 760px) {\n  .dpi-grid {\n    grid-template-columns: minmax(0, 1fr);\n  }\n}\n.dpi-column {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  min-width: 0;\n}\n.dpi-column-head {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 12px;\n  color: var(--dpi-ink-faint);\n}\n.dpi-btn {\n  border: 1px solid var(--dpi-line);\n  background: linear-gradient(135deg, #ffe3f1, #efe4ff);\n  color: var(--dpi-ink);\n  border-radius: 10px;\n  padding: 6px 12px;\n  font: inherit;\n  font-size: 12px;\n  font-weight: 600;\n  cursor: pointer;\n  transition: transform 120ms ease, box-shadow 120ms ease;\n}\n.dpi-btn:hover {\n  transform: translateY(-1px);\n  box-shadow: 0 6px 14px rgba(255, 95, 168, 0.2);\n}\n.dpi-btn:focus-visible {\n  outline: var(--dsw-focus-ring-width, 2px) solid var(--dpi-lilac);\n  outline-offset: 2px;\n}\n.dpi-btn[disabled] {\n  opacity: 0.5;\n  cursor: not-allowed;\n  transform: none;\n  box-shadow: none;\n}\n.dpi-btn-ghost {\n  background: transparent;\n}\n.dpi-btn-danger {\n  background: transparent;\n  border-color: rgba(217, 79, 122, 0.5);\n  color: #c8406a;\n}\n.dpi-row {\n  display: flex;\n  gap: 8px;\n  align-items: center;\n  flex-wrap: wrap;\n}\n.dpi-field {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.dpi-label {\n  font-size: 11.5px;\n  color: var(--dpi-ink-faint);\n}\n.dpi-textarea {\n  min-height: 190px;\n  resize: vertical;\n  padding: 10px;\n  border-radius: 12px;\n  border: 1px solid var(--dpi-line);\n  background: var(--dpi-surface-2);\n  color: var(--dpi-ink);\n  font: inherit;\n  font-size: 12px;\n  line-height: 1.55;\n}\n.dpi-textarea:focus {\n  outline: none;\n  border-color: var(--dpi-pink);\n  box-shadow: 0 0 0 3px rgba(255, 143, 196, 0.2);\n}\n.dpi-help {\n  font-size: 11px;\n  color: var(--dpi-ink-faint);\n}\n\n@media (prefers-reduced-motion: reduce) {\n  .dpi-panel,\n  .dpi-empty-emoji,\n  .dpi-chip,\n  .dpi-card,\n  .dpi-mode,\n  .dpi-btn {\n    animation: none !important;\n    transition: none !important;\n  }\n}\n";
			document.head.appendChild(__style);
		}
		__factories["dpi:client/index.js"] = (module, exports, __require) => {
/**
 * Browser half of dsh-prompt-injector.
 *
 * Responsibilities:
 *   - a composer toolbar chip that opens the preset picker,
 *   - the "moe" panel, book and chip styling,
 *   - the Settings page that owns library CRUD, search and tag filters,
 *   - telling the host half which preset the session picked, and whether that
 *     pick covers the next message only or every message. The selection is a UI
 *     gesture, so it lives here; the preset TEXT is injected by the host half at
 *     send time and never enters the composer draft.
 *
 * The loader delivers this file as a lazy-CJS factory, so the source stays in
 * plain JavaScript and `scripts/build-client.mjs` wraps it. JSX is avoided on
 * purpose: `React.createElement` keeps the build free of a compiler.
 */
const __m0 = __require("dpi:client/src/config.js");
const CONFIG = __m0["CONFIG"];
const __m1 = __require("dpi:client/src/core.js");
const TOKEN_HEAD = __m1["TOKEN_HEAD"];
const TOKEN_TAIL = __m1["TOKEN_TAIL"];
const filterPresets = __m1["filterPresets"];
const normalizeMode = __m1["normalizeMode"];
const selectionOf = __m1["selectionOf"];
const slugify = __m1["slugify"];
const validateDraft = __m1["validateDraft"];
const __m2 = __require("dpi:client/src/composer.js");
const createComposerButton = __m2["createComposerButton"];
const __m3 = __require("dpi:client/src/settings-page.js");
const createSettingsPage = __m3["createSettingsPage"];

/**
 * Required client services.
 *
 * `slots` must be declared here. The Cordis client context is a guarded facade:
 * reading `ctx.slots` — or any other service — without a matching `inject` entry
 * throws at runtime, and the boot audit reports the whole entry as failed. The
 * declarations are hard dependencies, so the fiber waits for the service instead
 * of racing it.
 */
const inject = ['slots']

/** Debug aid: keep the last registration failure visible in the page. */
function noteFailure(step, error) {
  try {
    const list = (globalThis.__DSH_PROMPT_INJECTOR_STEPS__ ??= [])
    list.push(`${step}: ${error instanceof Error ? `${error.name}: ${error.message}` : String(error)}`)
    console.error(`[prompt-injector] ${step} failed`, error)
  } catch {
    /* the debug aid must never be the reason a plugin fails */
  }
}

/**
 * Mount the browser half.
 * @param {object} ctx - restricted Cordis client context
 * @param {{ styles?: { insert(css: string): () => void } }} [deps] - loader builtins
 */
function apply(ctx, deps) {
  void deps
  const state = {
    library: [],
    revision: '',
    error: '',
    ready: false,
    /** session id -> { presetId, mode }, mirrored from the host half. */
    selections: {},
    listeners: new Set(),
    /** Cached view of `state` for `useSyncExternalStore`. */
    snapshot: undefined,
  }

  /**
   * The mode the picker opens on, remembered across reloads.
   *
   * `once` unless the user has explicitly asked for every turn: repeating an
   * injection is a decision, not a default.
   * @type {import('./src/core.js').InjectionMode}
   */
  let preferredMode = (() => {
    try {
      return normalizeMode(globalThis.localStorage?.getItem(CONFIG.modeKey))
    } catch {
      return normalizeMode(undefined)
    }
  })()

  const emit = () => {
    // `useSyncExternalStore` compares snapshots by identity: handing it a fresh
    // object on every read is an infinite render loop (React error #185), so the
    // view is materialized only when the state actually changes.
    state.snapshot = {
      library: state.library,
      revision: state.revision,
      error: state.error,
      ready: state.ready,
      selections: state.selections,
    }
    for (const listener of [...state.listeners]) {
      try {
        listener()
      } catch (error) {
        console.error('[prompt-injector] listener failed', error)
      }
    }
  }

  const subscribe = (listener) => {
    state.listeners.add(listener)
    return () => state.listeners.delete(listener)
  }

  const snapshot = () =>
    (state.snapshot ??= {
      library: state.library,
      revision: state.revision,
      error: state.error,
      ready: state.ready,
      selections: state.selections,
    })

  const setLibrary = (presets, revision, selections) => {
    state.library = Array.isArray(presets) ? presets : []
    state.revision = typeof revision === 'string' ? revision : ''
    if (selections !== undefined && selections !== null && typeof selections === 'object') {
      state.selections = selections
    }
    state.ready = true
    state.error = ''
    emit()
  }

  const request = async (path, init) => {
    const response = await fetch(`/prompt-injector/${CONFIG.id}${path}`, {
      headers: { 'content-type': 'application/json' },
      ...init,
    })
    const body = await response.json().catch(() => undefined)
    if (!response.ok) throw new Error(body?.error ?? `HTTP ${response.status}`)
    return body
  }

  const refresh = async () => {
    try {
      const body = await request('/library')
      setLibrary(body?.presets, body?.revision, body?.selections)
    } catch (error) {
      state.ready = true
      state.error = error instanceof Error ? error.message : String(error)
      emit()
    }
  }

  const savePreset = async (preset) => {
    const body = await request('/preset', { method: 'PUT', body: JSON.stringify(preset) })
    setLibrary(body?.presets, body?.revision, body?.selections)
    return body?.saved
  }

  const removePreset = async (id) => {
    const body = await request(`/preset?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
    setLibrary(body?.presets, body?.revision, body?.selections)
  }

  /**
   * Remember which mode the user reached for last, so the picker opens on the
   * choice they made before. Storage is optional: a page without it still works,
   * it just forgets.
   * @returns {import('./src/core.js').InjectionMode}
   */
  const getPreferredMode = () => preferredMode

  /**
   * @param {unknown} mode
   * @returns {import('./src/core.js').InjectionMode}
   */
  const setPreferredMode = (mode) => {
    preferredMode = normalizeMode(mode)
    try {
      globalThis.localStorage?.setItem(CONFIG.modeKey, preferredMode)
    } catch {
      /* a page without storage keeps the in-memory preference only */
    }
    return preferredMode
  }

  /** Read one session's selection, tolerating a host that reports bare ids. */
  const getSelection = (sessionId) => selectionOf(state.selections, sessionId)

  /**
   * Record (or clear) the picked preset for one session.
   *
   * The selection lives on the host half, not in the message: the composer has
   * no supported way for a third-party plugin to write into its draft, so
   * putting the intent in the draft was never reliable. The host injects the
   * selected preset at send time instead, and for how long is `mode`.
   * @param {unknown} sessionId
   * @param {unknown} presetId
   * @param {unknown} [mode]
   */
  const setActiveId = async (sessionId, presetId, mode) => {
    const key = typeof sessionId === 'string' && sessionId.length > 0 ? sessionId : 'global'
    const chosen = setPreferredMode(mode ?? preferredMode)
    const next = { ...state.selections }
    if (typeof presetId === 'string' && presetId.length > 0) next[key] = { presetId, mode: chosen }
    else delete next[key]
    // Optimistic: the chip responds immediately, then the host confirms.
    state.selections = next
    emit()
    try {
      const body = await request('/selection', {
        method: 'PUT',
        body: JSON.stringify({ sessionId: key, presetId: presetId ?? '', mode: chosen }),
      })
      if (body?.selections) {
        state.selections = body.selections
        emit()
      }
    } catch (error) {
      state.error = error instanceof Error ? error.message : String(error)
      emit()
    }
  }

  /**
   * Re-read just the selections.
   *
   * A one-shot pick is released by the HOST the moment it injects, and the host
   * has no channel to the page, so the composer polls this while a one-shot is
   * pending. It is a local, authenticated GET, and it only runs while there is
   * something to notice.
   */
  const refreshSelections = async () => {
    try {
      const body = await request('/selection')
      if (body?.selections) {
        state.selections = body.selections
        emit()
      }
    } catch {
      /* a transient read failure must never blank the picker */
    }
  }

  const deps_ = {
    store: {
      subscribe,
      snapshot,
      refresh,
      refreshSelections,
      savePreset,
      removePreset,
      getSelection,
      setActiveId,
      getPreferredMode,
      setPreferredMode,
      filterPresets,
      searchPresets: (library, query) => filterPresets(library, query, []),
      validateDraft,
      slugify,
    },
  }

  const registerSlot = (key, options, component) => {
    try {
      ctx.slots.inject(key, () => ctx.slots.register({ name: key, ...options }, component))
    } catch (error) {
      noteFailure(`slots.inject(${key})`, error)
    }
  }

  registerSlot(
    'conversation.input.left',
    { id: CONFIG.slotId, order: CONFIG.slotOrder, label: CONFIG.title },
    createComposerButton(deps_),
  )
  registerSlot(
    'settings.section',
    { id: CONFIG.settingsId, order: CONFIG.settingsOrder, label: () => CONFIG.title },
    createSettingsPage(deps_),
  )

  refresh()

  try {
    ctx.effect(
      () => () => {
        state.listeners.clear()
      },
      'prompt-injector: client teardown',
    )
  } catch (error) {
    noteFailure('ctx.effect', error)
  }
}

exports["TOKEN_HEAD"] = TOKEN_HEAD;
exports["TOKEN_TAIL"] = TOKEN_TAIL;

exports["apply"] = apply;
exports["inject"] = inject;
		};
		__factories["dpi:client/src/config.js"] = (module, exports, __require) => {
/** Shared constants for the browser half. */
const CONFIG = {
  id: 'prompt-injector',
  title: '提示词注入器',
  slotId: 'prompt-injector-composer',
  slotOrder: 40,
  settingsId: 'prompt-injector',
  settingsOrder: 30,
  /** Remembers which injection mode the user reached for last. */
  modeKey: 'dsh.prompt-injector.mode.v1',
  /** How often a pending one-shot selection re-reads the host, in ms. */
  oncePollMs: 3000,
}

exports["CONFIG"] = CONFIG;
		};
		__factories["dpi:client/src/core.js"] = (module, exports, __require) => {
/**
 * Browser-side rules and the shared vocabulary the two halves agree on.
 *
 * The token helpers below are the inline wire format `lib/core.js` still
 * accepts. The picker no longer writes tokens — a pick travels over the
 * plugin's HTTP interface instead — so keep `TOKEN_HEAD` / `TOKEN_TAIL`
 * byte-identical to the host half rather than assuming nothing reads them: the
 * test suite compares the two files, which is what stops a future writer from
 * drifting.
 */

const TOKEN_HEAD = ''
const TOKEN_TAIL = ''

/** Longest preset id the token may carry. */
const MAX_PRESET_ID_LENGTH = 64

/**
 * How long a picker selection lasts. Keep these values byte-identical to
 * `lib/core.js`: the host half normalizes exactly these strings.
 * @typedef {'once' | 'sticky'} InjectionMode
 */
const DEFAULT_INJECTION_MODE = 'once'

/**
 * @param {unknown} value
 * @returns {InjectionMode}
 */
function normalizeMode(value) {
  return value === 'sticky' ? 'sticky' : DEFAULT_INJECTION_MODE
}

/**
 * Human-facing labels for the two modes, so the chip, the segmented control and
 * the notices can never disagree about wording.
 * @type {Record<InjectionMode, { emoji: string, label: string, short: string, hint: string }>}
 */
const MODE_INFO = {
  once: {
    emoji: '💌',
    label: '只注入下一条',
    short: '下一条',
    hint: '选好之后，只有你紧接着发送的那一条消息会被注入。',
  },
  sticky: {
    emoji: '💖',
    label: '每轮都注入',
    short: '每轮',
    hint: '一直注入，直到你点「取消」为止。',
  },
}

/**
 * Read one session's selection out of the host's `selections` map.
 *
 * The host reports `session id -> { presetId, mode }`. A bare string is still
 * accepted so a page loaded against an older host half cannot break the chip.
 * @param {Record<string, any> | undefined} selections
 * @param {unknown} sessionId
 * @returns {{ presetId: string, mode: InjectionMode }}
 */
function selectionOf(selections, sessionId) {
  const key = typeof sessionId === 'string' && sessionId.length > 0 ? sessionId : 'global'
  const entry = selections?.[key]
  if (typeof entry === 'string') return { presetId: entry, mode: DEFAULT_INJECTION_MODE }
  if (entry !== null && typeof entry === 'object' && entry !== undefined) {
    return {
      presetId: typeof entry.presetId === 'string' ? entry.presetId : '',
      mode: normalizeMode(entry.mode),
    }
  }
  return { presetId: '', mode: DEFAULT_INJECTION_MODE }
}

/**
 * @param {unknown} input
 * @returns {string}
 */
function slugify(input) {
  const base = String(input ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^\p{Letter}\p{Number}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
  const ascii = base.replace(/[^\x20-\x7E]/g, '').replace(/^-+|-+$/g, '')
  const chosen = ascii.length > 0 ? ascii : base
  return (chosen.length > 0 ? chosen : 'preset').slice(0, MAX_PRESET_ID_LENGTH)
}

/**
 * @param {unknown} id
 * @returns {string}
 */
function encodeToken(id) {
  return `${TOKEN_HEAD}${slugify(id)}${TOKEN_TAIL}`
}

/**
 * @param {unknown} text
 * @returns {{ id: string, start: number, end: number } | undefined}
 */
function decodeToken(text) {
  const haystack = String(text ?? '')
  const start = haystack.indexOf(TOKEN_HEAD)
  if (start < 0) return undefined
  const from = start + TOKEN_HEAD.length
  const tail = haystack.indexOf(TOKEN_TAIL, from)
  if (tail < 0) return undefined
  return { id: slugify(haystack.slice(from, tail)), start, end: tail + TOKEN_TAIL.length }
}

/**
 * @param {unknown} text
 * @returns {string}
 */
function stripTokens(text) {
  let out = String(text ?? '')
  for (;;) {
    const token = decodeToken(out)
    if (token === undefined) break
    out = out.slice(0, token.start) + out.slice(token.end)
  }
  return out
}

/**
 * @param {readonly any[]} library
 * @returns {string[]}
 */
function collectTags(library) {
  const tags = new Set()
  for (const preset of library ?? []) for (const tag of preset?.tags ?? []) tags.add(tag)
  return [...tags].sort((a, b) => a.localeCompare(b))
}

/**
 * @param {readonly any[]} library
 * @param {string} query
 * @param {readonly string[]} activeTags
 * @param {{ includeDisabled?: boolean }} [options]
 * @returns {any[]}
 */
function filterPresets(library, query, activeTags, options) {
  const needle = String(query ?? '').trim().toLowerCase()
  const tags = [...(activeTags ?? [])]
  const includeDisabled = options?.includeDisabled === true
  return (library ?? []).filter((preset) => {
    if (!includeDisabled && preset?.enabled === false) return false
    if (tags.length > 0 && !tags.every((tag) => (preset?.tags ?? []).includes(tag))) return false
    if (needle.length === 0) return true
    return [preset?.name, preset?.id, ...(preset?.tags ?? [])].join(' ').toLowerCase().includes(needle)
  })
}

/**
 * @param {readonly any[]} library
 * @param {string} query
 * @returns {any[]}
 */
function searchPresets(library, query) {
  return filterPresets(library, query, [])
}

/**
 * Validate a preset form before it reaches the host.
 * @param {{ name?: string, id?: string, text?: string, tags?: string }} draft
 * @returns {{ ok: true, preset: object } | { ok: false, message: string }}
 */
function validateDraft(draft) {
  const name = String(draft?.name ?? '').trim()
  const text = String(draft?.text ?? '')
  if (name.length === 0) return { ok: false, message: '给这个预设起个名字吧～' }
  if (text.trim().length === 0) return { ok: false, message: '预设内容是空的，注入时不会起作用哦。' }
  if (text.length > 20000) return { ok: false, message: '预设内容太长了（上限 20000 字）。' }
  const tags = String(draft?.tags ?? '')
    .split(/[,，\s]+/)
    .map((tag) => tag.trim())
    .filter((tag) => tag.length > 0)
  const explicitId = String(draft?.id ?? '').trim()
  return {
    ok: true,
    preset: { id: slugify(explicitId.length > 0 ? explicitId : name), name, text, tags, enabled: true },
  }
}

exports["normalizeMode"] = normalizeMode;
exports["selectionOf"] = selectionOf;
exports["slugify"] = slugify;
exports["encodeToken"] = encodeToken;
exports["decodeToken"] = decodeToken;
exports["stripTokens"] = stripTokens;
exports["collectTags"] = collectTags;
exports["filterPresets"] = filterPresets;
exports["searchPresets"] = searchPresets;
exports["validateDraft"] = validateDraft;
exports["TOKEN_HEAD"] = TOKEN_HEAD;
exports["TOKEN_TAIL"] = TOKEN_TAIL;
exports["MAX_PRESET_ID_LENGTH"] = MAX_PRESET_ID_LENGTH;
exports["DEFAULT_INJECTION_MODE"] = DEFAULT_INJECTION_MODE;
exports["MODE_INFO"] = MODE_INFO;
		};
		__factories["dpi:client/src/composer.js"] = (module, exports, __require) => {
/**
 * Composer toolbar contribution: the picker chip plus its "moe" panel.
 *
 * Picking a preset never touches the composer draft. It records the pick on the
 * host half together with the mode the user chose:
 *
 *   - 💌 只注入下一条 — the host injects into the next message and then releases
 *     the pick, so sending again is clean,
 *   - 💖 每轮都注入 — the host keeps injecting until the user cancels.
 *
 * `once` is the mode the panel opens on, and the only one that can surprise
 * nobody: repeating an injection is something the user asks for.
 */
const __ext0 = __require("react-dom");
const createPortal = __ext0["createPortal"];
const __ext1 = __require("react");
const Fragment = __ext1["Fragment"];
const createElement = __ext1["createElement"];
const useEffect = __ext1["useEffect"];
const useRef = __ext1["useRef"];
const useState = __ext1["useState"];
const useSyncExternalStore = __ext1["useSyncExternalStore"];

const __m2 = __require("dpi:client/src/config.js");
const CONFIG = __m2["CONFIG"];
const __m3 = __require("dpi:client/src/core.js");
const MODE_INFO = __m3["MODE_INFO"];
const normalizeMode = __m3["normalizeMode"];

/**
 * Build the composer component.
 * @param {{ store: any }} deps
 * @returns {(props: object) => any}
 */
function createComposerButton({ store }) {
  const react = { createElement, Fragment, useEffect, useRef, useState, useSyncExternalStore }
  const reactDom = { createPortal }

  /**
   * @param {object} props
   */
  return function PromptInjectorChip(props) {
    const sessionId = props?.sessionId ?? props?.session?.id ?? 'global'
    const live = react.useSyncExternalStore(store.subscribe, store.snapshot, store.snapshot)
    const [open, setOpen] = react.useState(false)
    const [query, setQuery] = react.useState('')
    const [tags, setTags] = react.useState(() => [])
    const [notice, setNotice] = react.useState('')
    const [mode, setMode] = react.useState(() =>
      store.getPreferredMode === undefined ? normalizeMode(undefined) : store.getPreferredMode(),
    )
    const anchorRef = react.useRef(null)

    const selection =
      store.getSelection === undefined ? { presetId: '', mode: normalizeMode(undefined) } : store.getSelection(sessionId)
    const activeId = selection.presetId
    const active = live.library.find((preset) => preset.id === activeId)
    const visible = store.filterPresets
      ? store.filterPresets(live.library, query, tags)
      : store.searchPresets(live.library, query)

    react.useEffect(() => {
      store.refresh()
    }, [])

    // The host releases a one-shot pick the instant it injects, and it has no
    // channel back into the page. While one is pending — and only then — the
    // chip re-reads the selection so it stops claiming a message it already sent.
    const pendingOnce = activeId.length > 0 && selection.mode === 'once'
    react.useEffect(() => {
      if (!pendingOnce || store.refreshSelections === undefined) return undefined
      const timer = setInterval(() => store.refreshSelections(), CONFIG.oncePollMs)
      return () => clearInterval(timer)
    }, [pendingOnce, activeId])

    const allTags = Array.from(
      new Set(
        (live.library ?? [])
          .filter((preset) => preset.enabled !== false)
          .flatMap((preset) => preset.tags ?? []),
      ),
    )

    const toggleTag = (tag) => {
      setTags((current) => (current.includes(tag) ? current.filter((value) => value !== tag) : [...current, tag]))
    }

    /** Switch the mode, and move an existing pick with it. */
    const changeMode = (next) => {
      const chosen = store.setPreferredMode === undefined ? normalizeMode(next) : store.setPreferredMode(next)
      setMode(chosen)
      if (activeId.length === 0) return
      store.setActiveId(sessionId, activeId, chosen)
      setNotice(
        chosen === 'sticky'
          ? `「${active?.name ?? activeId}」改成每轮都注入啦，点「取消」才会停哦 ♥`
          : `「${active?.name ?? activeId}」改成只注入下一条，之后发送就清清爽爽～`,
      )
    }

    const choose = (preset) => {
      // Clicking the preset that is already picked, in the mode already shown,
      // is the way to take it back.
      if (activeId === preset.id && selection.mode === mode) {
        store.setActiveId(sessionId, '')
        setNotice(`已取消「${preset.name}」。`)
        return
      }
      store.setActiveId(sessionId, preset.id, mode)
      setNotice(
        mode === 'sticky'
          ? `已锁定「${preset.name}」：接下来每一轮都会注入 ♥`
          : `已选好「${preset.name}」：只注入你紧接着发送的那一条～`,
      )
    }

    const chipMode = MODE_INFO[active ? selection.mode : mode]
    const label = active ? active.name : '预设'
    const chip = react.createElement(
      'button',
      {
        ref: anchorRef,
        type: 'button',
        className: 'dpi-chip',
        'data-active': active ? 'true' : 'false',
        'data-empty': active ? 'false' : 'true',
        'data-mode': active ? selection.mode : 'idle',
        title: active
          ? `${chipMode.label}：${active.name}（点开可改）`
          : `提示词注入器：挑一个预设（默认${MODE_INFO.once.label}）`,
        'aria-haspopup': 'dialog',
        'aria-expanded': open ? 'true' : 'false',
        onClick: () => setOpen((value) => !value),
      },
      react.createElement('span', { className: 'dpi-chip-emoji' }, active ? chipMode.emoji : '🌸'),
      react.createElement('span', { className: 'dpi-chip-name' }, label),
      active ? react.createElement('span', { className: 'dpi-chip-mode' }, chipMode.short) : null,
    )

    if (!open) return chip

    const rect = anchorRef.current?.getBoundingClientRect?.()
    const viewportHeight = window.innerHeight || 900
    const viewportWidth = window.innerWidth || 1440
    // Anchor the panel above the chip and give it only the space that actually
    // exists there, so its header can never be pushed off-screen.
    const panelWidth = Math.min(380, viewportWidth - 24)
    const style = rect
      ? {
          left: Math.max(8, Math.min(rect.left, viewportWidth - panelWidth - 12)),
          bottom: Math.max(8, viewportHeight - rect.top + 8),
          maxHeight: Math.max(220, Math.min(560, rect.top - 24)),
        }
      : { left: 16, bottom: 96, maxHeight: 560 }

    const modeButton = (value) =>
      react.createElement(
        'button',
        {
          key: value,
          type: 'button',
          className: 'dpi-mode',
          'data-on': mode === value ? 'true' : 'false',
          onClick: () => changeMode(value),
          title: MODE_INFO[value].hint,
        },
        MODE_INFO[value].emoji + ' ' + MODE_INFO[value].label,
      )

    const panel = react.createElement(
      'div',
      { className: 'dpi-root dpi-panel', style, role: 'dialog', 'aria-label': '提示词预设' },
      react.createElement(
        'div',
        { className: 'dpi-panel-head' },
        react.createElement('h3', { className: 'dpi-panel-title' }, '🌸 提示词预设'),
        react.createElement('span', { className: 'dpi-panel-sub' }, live.library.length + ' 个'),
        react.createElement(
          'button',
          { type: 'button', className: 'dpi-close', onClick: () => setOpen(false), title: '收起' },
          '✕',
        ),
      ),
      react.createElement('div', { className: 'dpi-modes', role: 'group', 'aria-label': '注入次数' }, [
        modeButton('once'),
        modeButton('sticky'),
      ]),
      react.createElement('p', { className: 'dpi-mode-hint' }, MODE_INFO[mode].hint),
      react.createElement(
        'div',
        { className: 'dpi-search-row' },
        react.createElement('input', {
          className: 'dpi-input',
          value: query,
          placeholder: '搜索名字 / 标签…',
          onChange: (event) => setQuery(event.target.value),
        }),
        active
          ? react.createElement(
              'button',
              { type: 'button', className: 'dpi-btn dpi-btn-ghost', onClick: () => choose(active) },
              '取消',
            )
          : null,
      ),
      allTags.length > 0
        ? react.createElement(
            'div',
            { className: 'dpi-tags' },
            allTags.map((tag) =>
              react.createElement(
                'button',
                {
                  key: tag,
                  type: 'button',
                  className: 'dpi-tag',
                  'data-on': tags.includes(tag) ? 'true' : 'false',
                  onClick: () => toggleTag(tag),
                },
                '#' + tag,
              ),
            ),
          )
        : null,
      visible.length === 0
        ? react.createElement(
            'div',
            { className: 'dpi-empty' },
            react.createElement('span', { className: 'dpi-empty-emoji' }, '🍡'),
            live.error ? '读不到预设库：' + live.error : '这里空空的～去「设置 → 提示词注入器」添加预设吧！',
          )
        : react.createElement(
            'ul',
            { className: 'dpi-list' },
            visible.map((preset) =>
              react.createElement(
                'li',
                { key: preset.id },
                react.createElement(
                  'button',
                  {
                    type: 'button',
                    className: 'dpi-card',
                    'data-active': preset.id === activeId ? 'true' : 'false',
                    onClick: () => choose(preset),
                  },
                  react.createElement(
                    'span',
                    { className: 'dpi-card-name' },
                    preset.id === activeId ? MODE_INFO[selection.mode].emoji + ' ' : '🌸 ',
                    preset.name,
                  ),
                  react.createElement('span', { className: 'dpi-card-crumb' }, '{{' + preset.id + '}}'),
                  (preset.tags ?? []).length > 0
                    ? react.createElement(
                        'span',
                        { className: 'dpi-card-tags' },
                        (preset.tags ?? []).map((tag) =>
                          react.createElement('span', { className: 'dpi-mini-tag', key: tag }, '#' + tag),
                        ),
                      )
                    : null,
                  react.createElement('span', { className: 'dpi-card-text' }, preset.text),
                ),
              ),
            ),
          ),
      react.createElement(
        'p',
        { className: 'dpi-note' },
        notice.length > 0
          ? notice
          : '预设文字不会出现在输入框里，而是在你发送的瞬间注入到消息首部。再点一次同一项即取消。',
      ),
    )

    return react.createElement(
      react.Fragment,
      null,
      chip,
      reactDom.createPortal ? reactDom.createPortal(panel, document.body) : panel,
    )
  }
}

exports["createComposerButton"] = createComposerButton;
		};
		__factories["dpi:client/src/settings-page.js"] = (module, exports, __require) => {
/**
 * Settings page: the preset library with create/read/update/delete, search and
 * tag filters. Every write goes to the host half, so the library the injector
 * reads and the library shown here are the same document.
 */

const __ext0 = __require("react");
const createElement = __ext0["createElement"];
const useEffect = __ext0["useEffect"];
const useState = __ext0["useState"];
const useSyncExternalStore = __ext0["useSyncExternalStore"];

/**
 * Build the settings section component.
 * @param {{ store: any }} deps
 * @returns {(props: object) => any}
 */
function createSettingsPage({ store }) {
  const react = { createElement, useEffect, useState, useSyncExternalStore }
  const emptyDraft = { id: '', name: '', text: '', tags: '' }

  return function PromptInjectorSettings() {
    const live = react.useSyncExternalStore(store.subscribe, store.snapshot, store.snapshot)
    const [query, setQuery] = react.useState('')
    const [tags, setTags] = react.useState(() => [])
    const [draft, setDraft] = react.useState(emptyDraft)
    const [status, setStatus] = react.useState({ tone: 'idle', text: '' })
    const [busy, setBusy] = react.useState(false)

    react.useEffect(() => {
      store.refresh()
    }, [])

    const allTags = Array.from(new Set((live.library ?? []).flatMap((preset) => preset.tags ?? [])))
    const visible = store.filterPresets
      ? store.filterPresets(live.library, query, tags, { includeDisabled: true })
      : store.searchPresets(live.library, query)

    const patch = (fields) => setDraft((current) => ({ ...current, ...fields }))

    const reset = () => {
      setDraft(emptyDraft)
      setStatus({ tone: 'idle', text: '' })
    }

    const beginEdit = (preset) => {
      setDraft({
        id: preset.id,
        name: preset.name,
        text: preset.text,
        tags: (preset.tags ?? []).join(' '),
      })
      setStatus({ tone: 'idle', text: '正在编辑「' + preset.name + '」' })
    }

    const submit = async () => {
      const checked = store.validateDraft ? store.validateDraft(draft) : { ok: true, preset: draft }
      if (!checked.ok) {
        setStatus({ tone: 'error', text: checked.message })
        return
      }
      setBusy(true)
      try {
        await store.savePreset(checked.preset)
        setStatus({ tone: 'ok', text: '保存好啦：' + checked.preset.name + ' ♪' })
        setDraft({ ...emptyDraft, id: checked.preset.id })
      } catch (error) {
        setStatus({ tone: 'error', text: '保存失败：' + (error instanceof Error ? error.message : String(error)) })
      } finally {
        setBusy(false)
      }
    }

    const remove = async (preset) => {
      setBusy(true)
      try {
        await store.removePreset(preset.id)
        setStatus({ tone: 'ok', text: '已删除「' + preset.name + '」' })
        if (draft.id === preset.id) setDraft(emptyDraft)
      } catch (error) {
        setStatus({ tone: 'error', text: '删除失败：' + (error instanceof Error ? error.message : String(error)) })
      } finally {
        setBusy(false)
      }
    }

    return react.createElement(
      'div',
      { className: 'dpi-root dpi-settings' },
      react.createElement(
        'div',
        { className: 'dpi-settings-head' },
        react.createElement('h2', { className: 'dpi-h2' }, '🌸 提示词注入器'),
        react.createElement(
          'button',
          { type: 'button', className: 'dpi-btn dpi-btn-ghost', onClick: () => store.refresh(), disabled: busy },
          '刷新',
        ),
      ),
      react.createElement(
        'p',
        { className: 'dpi-blurb' },
        '这里管理预设库。在输入框左侧点 🌸 挑一个预设，然后选注入方式：💌 只注入下一条（默认，发完就自动松开）或者 💖 每轮都注入（一直生效到你自己取消）。不管哪种，输入框里的字都不会被动。',
      ),
      live.error
        ? react.createElement('div', { className: 'dpi-banner dpi-error' }, '读不到预设库：' + live.error)
        : null,
      react.createElement(
        'div',
        { className: 'dpi-grid' },
        react.createElement(
          'div',
          { className: 'dpi-column' },
          react.createElement(
            'div',
            { className: 'dpi-column-head' },
            react.createElement('span', null, '📚 预设库（' + live.library.length + '）'),
          ),
          react.createElement(
            'div',
            { className: 'dpi-tags' },
            react.createElement(
              'button',
              { type: 'button', className: 'dpi-btn', onClick: () => setDraft(emptyDraft) },
              '＋ 新建',
            ),
          ),
          react.createElement('input', {
            className: 'dpi-input',
            value: query,
            placeholder: '搜索名字 / 标签…',
            onChange: (event) => setQuery(event.target.value),
          }),
          allTags.length > 0
            ? react.createElement(
                'div',
                { className: 'dpi-tags' },
                allTags.map((tag) =>
                  react.createElement(
                    'button',
                    {
                      key: tag,
                      type: 'button',
                      className: 'dpi-tag',
                      'data-on': tags.includes(tag) ? 'true' : 'false',
                      onClick: () =>
                        setTags((current) =>
                          current.includes(tag) ? current.filter((value) => value !== tag) : [...current, tag],
                        ),
                    },
                    '#' + tag,
                  ),
                ),
              )
            : null,
          visible.length === 0
            ? react.createElement(
                'div',
                { className: 'dpi-empty' },
                react.createElement('span', { className: 'dpi-empty-emoji' }, '🍡'),
                live.library.length === 0 ? '还没有预设，右边写一个吧～' : '没有匹配的预设。',
              )
            : react.createElement(
                'ul',
                { className: 'dpi-list' },
                visible.map((preset) =>
                  react.createElement(
                    'li',
                    { key: preset.id },
                    react.createElement(
                      'div',
                      {
                        className: 'dpi-card',
                        'data-active': draft.id === preset.id ? 'true' : 'false',
                      },
                      react.createElement(
                        'span',
                        { className: 'dpi-card-name' },
                        preset.enabled === false ? '🚫 ' : '🌸 ',
                        preset.name,
                      ),
                      react.createElement('span', { className: 'dpi-card-crumb' }, '{{' + preset.id + '}}'),
                      (preset.tags ?? []).length > 0
                        ? react.createElement(
                            'span',
                            { className: 'dpi-card-tags' },
                            (preset.tags ?? []).map((tag) =>
                              react.createElement('span', { className: 'dpi-mini-tag', key: tag }, '#' + tag),
                            ),
                          )
                        : null,
                      react.createElement('span', { className: 'dpi-card-text' }, preset.text),
                      react.createElement(
                        'span',
                        { className: 'dpi-row' },
                        react.createElement(
                          'button',
                          { type: 'button', className: 'dpi-btn dpi-btn-ghost', onClick: () => beginEdit(preset) },
                          '编辑',
                        ),
                        react.createElement(
                          'button',
                          {
                            type: 'button',
                            className: 'dpi-btn dpi-btn-danger',
                            onClick: () => remove(preset),
                            disabled: busy,
                          },
                          '删除',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
        ),
        react.createElement(
          'div',
          { className: 'dpi-column' },
          react.createElement(
            'div',
            { className: 'dpi-column-head' },
            react.createElement('span', null, draft.id ? '✏️ 编辑预设' : '✨ 新建预设'),
          ),
          react.createElement(
            'div',
            { className: 'dpi-field' },
            react.createElement('span', { className: 'dpi-label' }, '名字'),
            react.createElement('input', {
              className: 'dpi-input',
              value: draft.name,
              placeholder: '例如：严谨代码评审',
              onChange: (event) => patch({ name: event.target.value }),
            }),
          ),
          react.createElement(
            'div',
            { className: 'dpi-field' },
            react.createElement('span', { className: 'dpi-label' }, 'ID（可选；在消息里打 {{ID}} 就只给那一条注入）'),
            react.createElement('input', {
              className: 'dpi-input',
              value: draft.id,
              placeholder: '留空则按名字生成',
              onChange: (event) => patch({ id: event.target.value }),
            }),
          ),
          react.createElement(
            'div',
            { className: 'dpi-field' },
            react.createElement('span', { className: 'dpi-label' }, '标签（空格或逗号分隔）'),
            react.createElement('input', {
              className: 'dpi-input',
              value: draft.tags,
              placeholder: '工作 写作 代码',
              onChange: (event) => patch({ tags: event.target.value }),
            }),
          ),
          react.createElement(
            'div',
            { className: 'dpi-field' },
            react.createElement('span', { className: 'dpi-label' }, '注入内容'),
            react.createElement('textarea', {
              className: 'dpi-textarea',
              value: draft.text,
              placeholder: '这段文字会在发送时被拼到你消息的最前面。',
              onChange: (event) => patch({ text: event.target.value }),
            }),
          ),
          react.createElement(
            'div',
            { className: 'dpi-row' },
            react.createElement('button', { type: 'button', className: 'dpi-btn', onClick: submit, disabled: busy }, '保存'),
            react.createElement('button', { type: 'button', className: 'dpi-btn dpi-btn-ghost', onClick: reset }, '清空'),
            status.text
              ? react.createElement(
                  'span',
                  { className: status.tone === 'error' ? 'dpi-help dpi-error' : 'dpi-help' },
                  status.text,
                )
              : null,
          ),
          react.createElement(
            'p',
            { className: 'dpi-help' },
            '保存会写进这个 profile 的配置文件（cordis.patch.yml 的 config.presets），所以重启、切会话都不会丢。',
          ),
          react.createElement(
            'p',
            { className: 'dpi-help' },
            '不想点面板也可以：在消息里写 {{ID}}（例如 {{code}}），那一条就会用这个名字对应的预设，发完即止。',
          ),
        ),
      ),
    )
  }
}

exports["createSettingsPage"] = createSettingsPage;
		};
		var entry = __load("dpi:client/index.js");
		return entry;
		} catch (error) {
			globalThis.__DSH_PROMPT_INJECTOR_ERROR__ = error;
			console.error("dsh-prompt-injector: factory failed", error);
			throw error;
		}
	}
});
