/**
 * Settings page: the preset library with create/read/update/delete, search and
 * tag filters. Every write goes to the host half, so the library the injector
 * reads and the library shown here are the same document.
 */

import { createElement, useEffect, useState, useSyncExternalStore } from 'react'

/**
 * Build the settings section component.
 * @param {{ store: any }} deps
 * @returns {(props: object) => any}
 */
export function createSettingsPage({ store }) {
  const react = { createElement, useEffect, useState, useSyncExternalStore }
  const emptyDraft = { id: '', name: '', text: '', tags: '' }

  return function PromptInjectorSettings() {
    const live = react.useSyncExternalStore(store.subscribe, store.snapshot, store.snapshot)
    const [query, setQuery] = react.useState('')
    const [tags, setTags] = react.useState(() => [])
    const [draft, setDraft] = react.useState(emptyDraft)
    const [status, setStatus] = react.useState({ tone: 'idle', text: '' })
    const [busy, setBusy] = react.useState(false)

    react.useEffect(() => {
      store.refresh()
    }, [])

    const allTags = Array.from(new Set((live.library ?? []).flatMap((preset) => preset.tags ?? [])))
    const visible = store.filterPresets
      ? store.filterPresets(live.library, query, tags, { includeDisabled: true })
      : store.searchPresets(live.library, query)

    const patch = (fields) => setDraft((current) => ({ ...current, ...fields }))

    const reset = () => {
      setDraft(emptyDraft)
      setStatus({ tone: 'idle', text: '' })
    }

    const beginEdit = (preset) => {
      setDraft({
        id: preset.id,
        name: preset.name,
        text: preset.text,
        tags: (preset.tags ?? []).join(' '),
      })
      setStatus({ tone: 'idle', text: '正在编辑「' + preset.name + '」' })
    }

    const submit = async () => {
      const checked = store.validateDraft ? store.validateDraft(draft) : { ok: true, preset: draft }
      if (!checked.ok) {
        setStatus({ tone: 'error', text: checked.message })
        return
      }
      setBusy(true)
      try {
        await store.savePreset(checked.preset)
        setStatus({ tone: 'ok', text: '保存好啦：' + checked.preset.name + ' ♪' })
        setDraft({ ...emptyDraft, id: checked.preset.id })
      } catch (error) {
        setStatus({ tone: 'error', text: '保存失败：' + (error instanceof Error ? error.message : String(error)) })
      } finally {
        setBusy(false)
      }
    }

    const remove = async (preset) => {
      setBusy(true)
      try {
        await store.removePreset(preset.id)
        setStatus({ tone: 'ok', text: '已删除「' + preset.name + '」' })
        if (draft.id === preset.id) setDraft(emptyDraft)
      } catch (error) {
        setStatus({ tone: 'error', text: '删除失败：' + (error instanceof Error ? error.message : String(error)) })
      } finally {
        setBusy(false)
      }
    }

    return react.createElement(
      'div',
      { className: 'dpi-root dpi-settings' },
      react.createElement(
        'div',
        { className: 'dpi-settings-head' },
        react.createElement('h2', { className: 'dpi-h2' }, '🌸 提示词注入器'),
        react.createElement(
          'button',
          { type: 'button', className: 'dpi-btn dpi-btn-ghost', onClick: () => store.refresh(), disabled: busy },
          '刷新',
        ),
      ),
      react.createElement(
        'p',
        { className: 'dpi-blurb' },
        '这里管理预设库。在输入框左侧点 🌸 挑一个预设，然后选注入方式：💌 只注入下一条（默认，发完就自动松开）或者 💖 每轮都注入（一直生效到你自己取消）。不管哪种，输入框里的字都不会被动。',
      ),
      live.error
        ? react.createElement('div', { className: 'dpi-banner dpi-error' }, '读不到预设库：' + live.error)
        : null,
      react.createElement(
        'div',
        { className: 'dpi-grid' },
        react.createElement(
          'div',
          { className: 'dpi-column' },
          react.createElement(
            'div',
            { className: 'dpi-column-head' },
            react.createElement('span', null, '📚 预设库（' + live.library.length + '）'),
          ),
          react.createElement(
            'div',
            { className: 'dpi-tags' },
            react.createElement(
              'button',
              { type: 'button', className: 'dpi-btn', onClick: () => setDraft(emptyDraft) },
              '＋ 新建',
            ),
          ),
          react.createElement('input', {
            className: 'dpi-input',
            value: query,
            placeholder: '搜索名字 / 标签…',
            onChange: (event) => setQuery(event.target.value),
          }),
          allTags.length > 0
            ? react.createElement(
                'div',
                { className: 'dpi-tags' },
                allTags.map((tag) =>
                  react.createElement(
                    'button',
                    {
                      key: tag,
                      type: 'button',
                      className: 'dpi-tag',
                      'data-on': tags.includes(tag) ? 'true' : 'false',
                      onClick: () =>
                        setTags((current) =>
                          current.includes(tag) ? current.filter((value) => value !== tag) : [...current, tag],
                        ),
                    },
                    '#' + tag,
                  ),
                ),
              )
            : null,
          visible.length === 0
            ? react.createElement(
                'div',
                { className: 'dpi-empty' },
                react.createElement('span', { className: 'dpi-empty-emoji' }, '🍡'),
                live.library.length === 0 ? '还没有预设，右边写一个吧～' : '没有匹配的预设。',
              )
            : react.createElement(
                'ul',
                { className: 'dpi-list' },
                visible.map((preset) =>
                  react.createElement(
                    'li',
                    { key: preset.id },
                    react.createElement(
                      'div',
                      {
                        className: 'dpi-card',
                        'data-active': draft.id === preset.id ? 'true' : 'false',
                      },
                      react.createElement(
                        'span',
                        { className: 'dpi-card-name' },
                        preset.enabled === false ? '🚫 ' : '🌸 ',
                        preset.name,
                      ),
                      react.createElement('span', { className: 'dpi-card-crumb' }, '{{' + preset.id + '}}'),
                      (preset.tags ?? []).length > 0
                        ? react.createElement(
                            'span',
                            { className: 'dpi-card-tags' },
                            (preset.tags ?? []).map((tag) =>
                              react.createElement('span', { className: 'dpi-mini-tag', key: tag }, '#' + tag),
                            ),
                          )
                        : null,
                      react.createElement('span', { className: 'dpi-card-text' }, preset.text),
                      react.createElement(
                        'span',
                        { className: 'dpi-row' },
                        react.createElement(
                          'button',
                          { type: 'button', className: 'dpi-btn dpi-btn-ghost', onClick: () => beginEdit(preset) },
                          '编辑',
                        ),
                        react.createElement(
                          'button',
                          {
                            type: 'button',
                            className: 'dpi-btn dpi-btn-danger',
                            onClick: () => remove(preset),
                            disabled: busy,
                          },
                          '删除',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
        ),
        react.createElement(
          'div',
          { className: 'dpi-column' },
          react.createElement(
            'div',
            { className: 'dpi-column-head' },
            react.createElement('span', null, draft.id ? '✏️ 编辑预设' : '✨ 新建预设'),
          ),
          react.createElement(
            'div',
            { className: 'dpi-field' },
            react.createElement('span', { className: 'dpi-label' }, '名字'),
            react.createElement('input', {
              className: 'dpi-input',
              value: draft.name,
              placeholder: '例如：严谨代码评审',
              onChange: (event) => patch({ name: event.target.value }),
            }),
          ),
          react.createElement(
            'div',
            { className: 'dpi-field' },
            react.createElement('span', { className: 'dpi-label' }, 'ID（可选；在消息里打 {{ID}} 就只给那一条注入）'),
            react.createElement('input', {
              className: 'dpi-input',
              value: draft.id,
              placeholder: '留空则按名字生成',
              onChange: (event) => patch({ id: event.target.value }),
            }),
          ),
          react.createElement(
            'div',
            { className: 'dpi-field' },
            react.createElement('span', { className: 'dpi-label' }, '标签（空格或逗号分隔）'),
            react.createElement('input', {
              className: 'dpi-input',
              value: draft.tags,
              placeholder: '工作 写作 代码',
              onChange: (event) => patch({ tags: event.target.value }),
            }),
          ),
          react.createElement(
            'div',
            { className: 'dpi-field' },
            react.createElement('span', { className: 'dpi-label' }, '注入内容'),
            react.createElement('textarea', {
              className: 'dpi-textarea',
              value: draft.text,
              placeholder: '这段文字会在发送时被拼到你消息的最前面。',
              onChange: (event) => patch({ text: event.target.value }),
            }),
          ),
          react.createElement(
            'div',
            { className: 'dpi-row' },
            react.createElement('button', { type: 'button', className: 'dpi-btn', onClick: submit, disabled: busy }, '保存'),
            react.createElement('button', { type: 'button', className: 'dpi-btn dpi-btn-ghost', onClick: reset }, '清空'),
            status.text
              ? react.createElement(
                  'span',
                  { className: status.tone === 'error' ? 'dpi-help dpi-error' : 'dpi-help' },
                  status.text,
                )
              : null,
          ),
          react.createElement(
            'p',
            { className: 'dpi-help' },
            '保存会写进这个 profile 的配置文件（cordis.patch.yml 的 config.presets），所以重启、切会话都不会丢。',
          ),
          react.createElement(
            'p',
            { className: 'dpi-help' },
            '不想点面板也可以：在消息里写 {{ID}}（例如 {{code}}），那一条就会用这个名字对应的预设，发完即止。',
          ),
        ),
      ),
    )
  }
}
