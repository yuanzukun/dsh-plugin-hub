/** Shared constants for the browser half. */
export const CONFIG = {
  id: 'prompt-injector',
  title: '提示词注入器',
  slotId: 'prompt-injector-composer',
  slotOrder: 40,
  settingsId: 'prompt-injector',
  settingsOrder: 30,
  /** Remembers which injection mode the user reached for last. */
  modeKey: 'dsh.prompt-injector.mode.v1',
  /** How often a pending one-shot selection re-reads the host, in ms. */
  oncePollMs: 3000,
}
