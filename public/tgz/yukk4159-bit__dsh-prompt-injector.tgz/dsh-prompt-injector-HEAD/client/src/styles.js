/**
 * The "moe" stylesheet.
 *
 * Every colour reads a Harness theme token first and falls back to the cute
 * palette, so the widget follows light/dark instead of fighting it. Animations
 * are disabled under `prefers-reduced-motion`.
 */
export const MOE_CSS = `
.dpi-root {
  --dpi-pink: var(--dsw-alias-state-business-primary, #ff8ec4);
  --dpi-pink-strong: #ff5fa8;
  --dpi-lilac: #b79cff;
  --dpi-mint: #7fe0d4;
  --dpi-ink: var(--dsw-alias-label-primary, #2b2436);
  --dpi-ink-soft: var(--dsw-alias-label-secondary, #6b6178);
  --dpi-ink-faint: var(--dsw-alias-label-tertiary, #9a92a6);
  --dpi-line: var(--dsw-alias-border-l2, rgba(183, 156, 255, 0.35));
  --dpi-surface: var(--dsw-alias-bg-layer-1, #fffafd);
  --dpi-surface-2: var(--dsw-alias-bg-layer-2, #fff3fa);
  --dpi-shadow: 0 10px 30px rgba(255, 95, 168, 0.18);
  --dpi-radius: 16px;
  font-family: inherit;
  color: var(--dpi-ink);
}

/* ---------------------------------------------------------------- chip --- */

.dpi-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px;
  border-radius: 999px;
  border: 1px solid var(--dpi-line);
  background: linear-gradient(135deg, var(--dpi-surface-2), var(--dpi-surface));
  color: var(--dpi-ink);
  font: inherit;
  font-size: 12px;
  line-height: 1;
  cursor: pointer;
  transition: transform 140ms ease, box-shadow 140ms ease, border-color 140ms ease;
}
.dpi-chip:hover {
  transform: translateY(-1px) scale(1.03);
  border-color: var(--dpi-pink);
  box-shadow: 0 6px 16px rgba(255, 95, 168, 0.22);
}
.dpi-chip:focus-visible {
  outline: var(--dsw-focus-ring-width, 2px) solid var(--dsw-focus-ring-color, var(--dpi-lilac));
  outline-offset: 2px;
}
.dpi-chip[data-active='true'] {
  border-color: var(--dpi-pink);
  background: linear-gradient(135deg, #ffe3f1, #f3e8ff);
  box-shadow: 0 4px 14px rgba(255, 95, 168, 0.24);
}
.dpi-chip[data-empty='true'] {
  color: var(--dpi-ink-faint);
}
.dpi-chip-emoji {
  font-size: 13px;
  line-height: 1;
}
.dpi-chip-name {
  max-width: 12ch;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
/* The mode badge is what keeps "this one message" and "every message" visibly
   different at a glance, so a sticky pick can never masquerade as a one-shot. */
.dpi-chip-mode {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 999px;
  background: rgba(183, 156, 255, 0.24);
  color: var(--dpi-ink-soft);
  letter-spacing: 0.02em;
}
.dpi-chip[data-mode='sticky'] .dpi-chip-mode {
  background: rgba(255, 95, 168, 0.22);
  color: var(--dpi-pink-strong);
}
.dpi-chip[data-mode='sticky'] {
  background: linear-gradient(135deg, #ffdcec, #f1e4ff);
}

/* --------------------------------------------------------------- panel --- */

.dpi-panel {
  position: fixed;
  z-index: 60;
  width: min(380px, calc(100vw - 24px));
  /* The component sets maxHeight from the space actually available above the
     chip, so the header can never be pushed off-screen. */
  max-height: 560px;
  display: flex;
  flex-direction: column;
  border-radius: var(--dpi-radius);
  border: 1px solid var(--dpi-line);
  background: var(--dpi-surface);
  box-shadow: var(--dpi-shadow);
  overflow: hidden;
  animation: dpi-pop 160ms ease-out;
}
@keyframes dpi-pop {
  from {
    transform: translateY(8px) scale(0.97);
    opacity: 0;
  }
  to {
    transform: translateY(0) scale(1);
    opacity: 1;
  }
}

.dpi-panel-head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px 8px;
  background: linear-gradient(135deg, #ffe9f4, #efe6ff);
  border-bottom: 1px dashed var(--dpi-line);
}
.dpi-panel-title {
  margin: 0;
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.02em;
}
.dpi-panel-sub {
  font-size: 11px;
  color: var(--dpi-ink-faint);
  margin-left: auto;
}
.dpi-close {
  border: 0;
  background: transparent;
  color: var(--dpi-ink-soft);
  font-size: 14px;
  cursor: pointer;
  border-radius: 8px;
  padding: 2px 6px;
}
.dpi-close:hover {
  background: rgba(255, 95, 168, 0.14);
  color: var(--dpi-pink-strong);
}

.dpi-search-row {
  display: flex;
  gap: 6px;
  padding: 8px 12px 4px;
}

/* --------------------------------------------------------- mode switch --- */

.dpi-modes {
  display: flex;
  gap: 6px;
  padding: 8px 12px 0;
}
.dpi-mode {
  flex: 1;
  min-width: 0;
  padding: 6px 8px;
  border-radius: 10px;
  border: 1px dashed var(--dpi-line);
  background: transparent;
  color: var(--dpi-ink-soft);
  font: inherit;
  font-size: 11.5px;
  cursor: pointer;
  transition: transform 120ms ease, border-color 120ms ease, background 120ms ease;
}
.dpi-mode:hover {
  transform: translateY(-1px);
  border-color: var(--dpi-pink);
}
.dpi-mode[data-on='true'] {
  border-style: solid;
  border-color: var(--dpi-pink-strong);
  background: linear-gradient(135deg, #ffe3f1, #f0e7ff);
  color: var(--dpi-ink);
  font-weight: 650;
}
.dpi-mode-hint {
  margin: 6px 12px 0;
  font-size: 11px;
  color: var(--dpi-ink-faint);
}
.dpi-input {
  flex: 1;
  min-width: 0;
  height: 30px;
  padding: 0 10px;
  border-radius: 10px;
  border: 1px solid var(--dpi-line);
  background: var(--dpi-surface-2);
  color: var(--dpi-ink);
  font: inherit;
  font-size: 12px;
}
.dpi-input:focus {
  outline: none;
  border-color: var(--dpi-pink);
  box-shadow: 0 0 0 3px rgba(255, 143, 196, 0.22);
}

.dpi-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  padding: 6px 12px 2px;
}
.dpi-tag {
  border: 1px solid var(--dpi-line);
  background: transparent;
  color: var(--dpi-ink-soft);
  border-radius: 999px;
  padding: 2px 9px;
  font: inherit;
  font-size: 11px;
  cursor: pointer;
}
.dpi-tag[data-on='true'] {
  background: linear-gradient(135deg, #ffd9ec, #e6dbff);
  border-color: var(--dpi-pink);
  color: var(--dpi-ink);
}

.dpi-list {
  list-style: none;
  margin: 6px 0 0;
  padding: 0 8px 8px;
  overflow: auto;
}
.dpi-card {
  width: 100%;
  text-align: left;
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 9px 10px;
  margin: 4px 0;
  border-radius: 12px;
  border: 1px solid transparent;
  background: var(--dpi-surface-2);
  color: inherit;
  font: inherit;
  cursor: pointer;
  transition: border-color 120ms ease, transform 120ms ease, background 120ms ease;
}
.dpi-card:hover {
  border-color: var(--dpi-pink);
  transform: translateX(2px);
  background: #fff0f8;
}
.dpi-card[data-active='true'] {
  border-color: var(--dpi-pink-strong);
  background: linear-gradient(135deg, #ffe6f3, #f0e7ff);
}
.dpi-card-name {
  font-size: 12.5px;
  font-weight: 650;
  display: flex;
  align-items: center;
  gap: 6px;
}
.dpi-card-crumb {
  font-size: 10.5px;
  color: var(--dpi-ink-faint);
  letter-spacing: 0.04em;
}
.dpi-card-text {
  font-size: 11.5px;
  color: var(--dpi-ink-soft);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  white-space: pre-wrap;
}
.dpi-card-tags {
  display: flex;
  gap: 4px;
  flex-wrap: wrap;
}
.dpi-mini-tag {
  font-size: 10px;
  padding: 1px 7px;
  border-radius: 999px;
  background: rgba(183, 156, 255, 0.18);
  color: var(--dpi-ink-soft);
}

.dpi-empty {
  padding: 18px 14px 22px;
  text-align: center;
  font-size: 12px;
  color: var(--dpi-ink-faint);
}
.dpi-empty-emoji {
  display: block;
  font-size: 22px;
  margin-bottom: 6px;
  animation: dpi-bob 1.8s ease-in-out infinite;
}
@keyframes dpi-bob {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-4px); }
}

.dpi-note {
  margin: 0;
  padding: 8px 12px 10px;
  font-size: 11px;
  color: var(--dpi-ink-faint);
  border-top: 1px dashed var(--dpi-line);
}
.dpi-error {
  color: #d94f7a;
}

/* ------------------------------------------------------------ settings --- */

.dpi-settings {
  display: flex;
  flex-direction: column;
  gap: 12px;
  max-width: 760px;
}
.dpi-settings-head {
  display: flex;
  align-items: center;
  gap: 10px;
}
.dpi-h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 700;
}
.dpi-blurb {
  margin: 0;
  font-size: 12.5px;
  color: var(--dpi-ink-faint);
}
.dpi-banner {
  border-radius: 12px;
  border: 1px dashed var(--dpi-line);
  background: linear-gradient(135deg, #fff0f8, #f4edff);
  padding: 10px 12px;
  font-size: 12px;
  color: var(--dpi-ink-soft);
}
.dpi-grid {
  display: grid;
  grid-template-columns: minmax(0, 320px) minmax(0, 1fr);
  gap: 14px;
  align-items: start;
}
@media (max-width: 760px) {
  .dpi-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}
.dpi-column {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
}
.dpi-column-head {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: var(--dpi-ink-faint);
}
.dpi-btn {
  border: 1px solid var(--dpi-line);
  background: linear-gradient(135deg, #ffe3f1, #efe4ff);
  color: var(--dpi-ink);
  border-radius: 10px;
  padding: 6px 12px;
  font: inherit;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 120ms ease, box-shadow 120ms ease;
}
.dpi-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 6px 14px rgba(255, 95, 168, 0.2);
}
.dpi-btn:focus-visible {
  outline: var(--dsw-focus-ring-width, 2px) solid var(--dpi-lilac);
  outline-offset: 2px;
}
.dpi-btn[disabled] {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}
.dpi-btn-ghost {
  background: transparent;
}
.dpi-btn-danger {
  background: transparent;
  border-color: rgba(217, 79, 122, 0.5);
  color: #c8406a;
}
.dpi-row {
  display: flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
}
.dpi-field {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.dpi-label {
  font-size: 11.5px;
  color: var(--dpi-ink-faint);
}
.dpi-textarea {
  min-height: 190px;
  resize: vertical;
  padding: 10px;
  border-radius: 12px;
  border: 1px solid var(--dpi-line);
  background: var(--dpi-surface-2);
  color: var(--dpi-ink);
  font: inherit;
  font-size: 12px;
  line-height: 1.55;
}
.dpi-textarea:focus {
  outline: none;
  border-color: var(--dpi-pink);
  box-shadow: 0 0 0 3px rgba(255, 143, 196, 0.2);
}
.dpi-help {
  font-size: 11px;
  color: var(--dpi-ink-faint);
}

@media (prefers-reduced-motion: reduce) {
  .dpi-panel,
  .dpi-empty-emoji,
  .dpi-chip,
  .dpi-card,
  .dpi-mode,
  .dpi-btn {
    animation: none !important;
    transition: none !important;
  }
}
`
