/**
 * Composer toolbar contribution: the picker chip plus its "moe" panel.
 *
 * Picking a preset never touches the composer draft. It records the pick on the
 * host half together with the mode the user chose:
 *
 *   - 💌 只注入下一条 — the host injects into the next message and then releases
 *     the pick, so sending again is clean,
 *   - 💖 每轮都注入 — the host keeps injecting until the user cancels.
 *
 * `once` is the mode the panel opens on, and the only one that can surprise
 * nobody: repeating an injection is something the user asks for.
 */
import { createPortal } from 'react-dom'
import { Fragment, createElement, useEffect, useRef, useState, useSyncExternalStore } from 'react'

import { CONFIG } from './config.js'
import { MODE_INFO, normalizeMode } from './core.js'

/**
 * Build the composer component.
 * @param {{ store: any }} deps
 * @returns {(props: object) => any}
 */
export function createComposerButton({ store }) {
  const react = { createElement, Fragment, useEffect, useRef, useState, useSyncExternalStore }
  const reactDom = { createPortal }

  /**
   * @param {object} props
   */
  return function PromptInjectorChip(props) {
    const sessionId = props?.sessionId ?? props?.session?.id ?? 'global'
    const live = react.useSyncExternalStore(store.subscribe, store.snapshot, store.snapshot)
    const [open, setOpen] = react.useState(false)
    const [query, setQuery] = react.useState('')
    const [tags, setTags] = react.useState(() => [])
    const [notice, setNotice] = react.useState('')
    const [mode, setMode] = react.useState(() =>
      store.getPreferredMode === undefined ? normalizeMode(undefined) : store.getPreferredMode(),
    )
    const anchorRef = react.useRef(null)

    const selection =
      store.getSelection === undefined ? { presetId: '', mode: normalizeMode(undefined) } : store.getSelection(sessionId)
    const activeId = selection.presetId
    const active = live.library.find((preset) => preset.id === activeId)
    const visible = store.filterPresets
      ? store.filterPresets(live.library, query, tags)
      : store.searchPresets(live.library, query)

    react.useEffect(() => {
      store.refresh()
    }, [])

    // The host releases a one-shot pick the instant it injects, and it has no
    // channel back into the page. While one is pending — and only then — the
    // chip re-reads the selection so it stops claiming a message it already sent.
    const pendingOnce = activeId.length > 0 && selection.mode === 'once'
    react.useEffect(() => {
      if (!pendingOnce || store.refreshSelections === undefined) return undefined
      const timer = setInterval(() => store.refreshSelections(), CONFIG.oncePollMs)
      return () => clearInterval(timer)
    }, [pendingOnce, activeId])

    const allTags = Array.from(
      new Set(
        (live.library ?? [])
          .filter((preset) => preset.enabled !== false)
          .flatMap((preset) => preset.tags ?? []),
      ),
    )

    const toggleTag = (tag) => {
      setTags((current) => (current.includes(tag) ? current.filter((value) => value !== tag) : [...current, tag]))
    }

    /** Switch the mode, and move an existing pick with it. */
    const changeMode = (next) => {
      const chosen = store.setPreferredMode === undefined ? normalizeMode(next) : store.setPreferredMode(next)
      setMode(chosen)
      if (activeId.length === 0) return
      store.setActiveId(sessionId, activeId, chosen)
      setNotice(
        chosen === 'sticky'
          ? `「${active?.name ?? activeId}」改成每轮都注入啦，点「取消」才会停哦 ♥`
          : `「${active?.name ?? activeId}」改成只注入下一条，之后发送就清清爽爽～`,
      )
    }

    const choose = (preset) => {
      // Clicking the preset that is already picked, in the mode already shown,
      // is the way to take it back.
      if (activeId === preset.id && selection.mode === mode) {
        store.setActiveId(sessionId, '')
        setNotice(`已取消「${preset.name}」。`)
        return
      }
      store.setActiveId(sessionId, preset.id, mode)
      setNotice(
        mode === 'sticky'
          ? `已锁定「${preset.name}」：接下来每一轮都会注入 ♥`
          : `已选好「${preset.name}」：只注入你紧接着发送的那一条～`,
      )
    }

    const chipMode = MODE_INFO[active ? selection.mode : mode]
    const label = active ? active.name : '预设'
    const chip = react.createElement(
      'button',
      {
        ref: anchorRef,
        type: 'button',
        className: 'dpi-chip',
        'data-active': active ? 'true' : 'false',
        'data-empty': active ? 'false' : 'true',
        'data-mode': active ? selection.mode : 'idle',
        title: active
          ? `${chipMode.label}：${active.name}（点开可改）`
          : `提示词注入器：挑一个预设（默认${MODE_INFO.once.label}）`,
        'aria-haspopup': 'dialog',
        'aria-expanded': open ? 'true' : 'false',
        onClick: () => setOpen((value) => !value),
      },
      react.createElement('span', { className: 'dpi-chip-emoji' }, active ? chipMode.emoji : '🌸'),
      react.createElement('span', { className: 'dpi-chip-name' }, label),
      active ? react.createElement('span', { className: 'dpi-chip-mode' }, chipMode.short) : null,
    )

    if (!open) return chip

    const rect = anchorRef.current?.getBoundingClientRect?.()
    const viewportHeight = window.innerHeight || 900
    const viewportWidth = window.innerWidth || 1440
    // Anchor the panel above the chip and give it only the space that actually
    // exists there, so its header can never be pushed off-screen.
    const panelWidth = Math.min(380, viewportWidth - 24)
    const style = rect
      ? {
          left: Math.max(8, Math.min(rect.left, viewportWidth - panelWidth - 12)),
          bottom: Math.max(8, viewportHeight - rect.top + 8),
          maxHeight: Math.max(220, Math.min(560, rect.top - 24)),
        }
      : { left: 16, bottom: 96, maxHeight: 560 }

    const modeButton = (value) =>
      react.createElement(
        'button',
        {
          key: value,
          type: 'button',
          className: 'dpi-mode',
          'data-on': mode === value ? 'true' : 'false',
          onClick: () => changeMode(value),
          title: MODE_INFO[value].hint,
        },
        MODE_INFO[value].emoji + ' ' + MODE_INFO[value].label,
      )

    const panel = react.createElement(
      'div',
      { className: 'dpi-root dpi-panel', style, role: 'dialog', 'aria-label': '提示词预设' },
      react.createElement(
        'div',
        { className: 'dpi-panel-head' },
        react.createElement('h3', { className: 'dpi-panel-title' }, '🌸 提示词预设'),
        react.createElement('span', { className: 'dpi-panel-sub' }, live.library.length + ' 个'),
        react.createElement(
          'button',
          { type: 'button', className: 'dpi-close', onClick: () => setOpen(false), title: '收起' },
          '✕',
        ),
      ),
      react.createElement('div', { className: 'dpi-modes', role: 'group', 'aria-label': '注入次数' }, [
        modeButton('once'),
        modeButton('sticky'),
      ]),
      react.createElement('p', { className: 'dpi-mode-hint' }, MODE_INFO[mode].hint),
      react.createElement(
        'div',
        { className: 'dpi-search-row' },
        react.createElement('input', {
          className: 'dpi-input',
          value: query,
          placeholder: '搜索名字 / 标签…',
          onChange: (event) => setQuery(event.target.value),
        }),
        active
          ? react.createElement(
              'button',
              { type: 'button', className: 'dpi-btn dpi-btn-ghost', onClick: () => choose(active) },
              '取消',
            )
          : null,
      ),
      allTags.length > 0
        ? react.createElement(
            'div',
            { className: 'dpi-tags' },
            allTags.map((tag) =>
              react.createElement(
                'button',
                {
                  key: tag,
                  type: 'button',
                  className: 'dpi-tag',
                  'data-on': tags.includes(tag) ? 'true' : 'false',
                  onClick: () => toggleTag(tag),
                },
                '#' + tag,
              ),
            ),
          )
        : null,
      visible.length === 0
        ? react.createElement(
            'div',
            { className: 'dpi-empty' },
            react.createElement('span', { className: 'dpi-empty-emoji' }, '🍡'),
            live.error ? '读不到预设库：' + live.error : '这里空空的～去「设置 → 提示词注入器」添加预设吧！',
          )
        : react.createElement(
            'ul',
            { className: 'dpi-list' },
            visible.map((preset) =>
              react.createElement(
                'li',
                { key: preset.id },
                react.createElement(
                  'button',
                  {
                    type: 'button',
                    className: 'dpi-card',
                    'data-active': preset.id === activeId ? 'true' : 'false',
                    onClick: () => choose(preset),
                  },
                  react.createElement(
                    'span',
                    { className: 'dpi-card-name' },
                    preset.id === activeId ? MODE_INFO[selection.mode].emoji + ' ' : '🌸 ',
                    preset.name,
                  ),
                  react.createElement('span', { className: 'dpi-card-crumb' }, '{{' + preset.id + '}}'),
                  (preset.tags ?? []).length > 0
                    ? react.createElement(
                        'span',
                        { className: 'dpi-card-tags' },
                        (preset.tags ?? []).map((tag) =>
                          react.createElement('span', { className: 'dpi-mini-tag', key: tag }, '#' + tag),
                        ),
                      )
                    : null,
                  react.createElement('span', { className: 'dpi-card-text' }, preset.text),
                ),
              ),
            ),
          ),
      react.createElement(
        'p',
        { className: 'dpi-note' },
        notice.length > 0
          ? notice
          : '预设文字不会出现在输入框里，而是在你发送的瞬间注入到消息首部。再点一次同一项即取消。',
      ),
    )

    return react.createElement(
      react.Fragment,
      null,
      chip,
      reactDom.createPortal ? reactDom.createPortal(panel, document.body) : panel,
    )
  }
}
