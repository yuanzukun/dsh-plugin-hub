/**
 * Browser-side rules and the shared vocabulary the two halves agree on.
 *
 * The token helpers below are the inline wire format `lib/core.js` still
 * accepts. The picker no longer writes tokens — a pick travels over the
 * plugin's HTTP interface instead — so keep `TOKEN_HEAD` / `TOKEN_TAIL`
 * byte-identical to the host half rather than assuming nothing reads them: the
 * test suite compares the two files, which is what stops a future writer from
 * drifting.
 */

export const TOKEN_HEAD = ''
export const TOKEN_TAIL = ''

/** Longest preset id the token may carry. */
export const MAX_PRESET_ID_LENGTH = 64

/**
 * How long a picker selection lasts. Keep these values byte-identical to
 * `lib/core.js`: the host half normalizes exactly these strings.
 * @typedef {'once' | 'sticky'} InjectionMode
 */
export const DEFAULT_INJECTION_MODE = 'once'

/**
 * @param {unknown} value
 * @returns {InjectionMode}
 */
export function normalizeMode(value) {
  return value === 'sticky' ? 'sticky' : DEFAULT_INJECTION_MODE
}

/**
 * Human-facing labels for the two modes, so the chip, the segmented control and
 * the notices can never disagree about wording.
 * @type {Record<InjectionMode, { emoji: string, label: string, short: string, hint: string }>}
 */
export const MODE_INFO = {
  once: {
    emoji: '💌',
    label: '只注入下一条',
    short: '下一条',
    hint: '选好之后，只有你紧接着发送的那一条消息会被注入。',
  },
  sticky: {
    emoji: '💖',
    label: '每轮都注入',
    short: '每轮',
    hint: '一直注入，直到你点「取消」为止。',
  },
}

/**
 * Read one session's selection out of the host's `selections` map.
 *
 * The host reports `session id -> { presetId, mode }`. A bare string is still
 * accepted so a page loaded against an older host half cannot break the chip.
 * @param {Record<string, any> | undefined} selections
 * @param {unknown} sessionId
 * @returns {{ presetId: string, mode: InjectionMode }}
 */
export function selectionOf(selections, sessionId) {
  const key = typeof sessionId === 'string' && sessionId.length > 0 ? sessionId : 'global'
  const entry = selections?.[key]
  if (typeof entry === 'string') return { presetId: entry, mode: DEFAULT_INJECTION_MODE }
  if (entry !== null && typeof entry === 'object' && entry !== undefined) {
    return {
      presetId: typeof entry.presetId === 'string' ? entry.presetId : '',
      mode: normalizeMode(entry.mode),
    }
  }
  return { presetId: '', mode: DEFAULT_INJECTION_MODE }
}

/**
 * @param {unknown} input
 * @returns {string}
 */
export function slugify(input) {
  const base = String(input ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^\p{Letter}\p{Number}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
  const ascii = base.replace(/[^\x20-\x7E]/g, '').replace(/^-+|-+$/g, '')
  const chosen = ascii.length > 0 ? ascii : base
  return (chosen.length > 0 ? chosen : 'preset').slice(0, MAX_PRESET_ID_LENGTH)
}

/**
 * @param {unknown} id
 * @returns {string}
 */
export function encodeToken(id) {
  return `${TOKEN_HEAD}${slugify(id)}${TOKEN_TAIL}`
}

/**
 * @param {unknown} text
 * @returns {{ id: string, start: number, end: number } | undefined}
 */
export function decodeToken(text) {
  const haystack = String(text ?? '')
  const start = haystack.indexOf(TOKEN_HEAD)
  if (start < 0) return undefined
  const from = start + TOKEN_HEAD.length
  const tail = haystack.indexOf(TOKEN_TAIL, from)
  if (tail < 0) return undefined
  return { id: slugify(haystack.slice(from, tail)), start, end: tail + TOKEN_TAIL.length }
}

/**
 * @param {unknown} text
 * @returns {string}
 */
export function stripTokens(text) {
  let out = String(text ?? '')
  for (;;) {
    const token = decodeToken(out)
    if (token === undefined) break
    out = out.slice(0, token.start) + out.slice(token.end)
  }
  return out
}

/**
 * @param {readonly any[]} library
 * @returns {string[]}
 */
export function collectTags(library) {
  const tags = new Set()
  for (const preset of library ?? []) for (const tag of preset?.tags ?? []) tags.add(tag)
  return [...tags].sort((a, b) => a.localeCompare(b))
}

/**
 * @param {readonly any[]} library
 * @param {string} query
 * @param {readonly string[]} activeTags
 * @param {{ includeDisabled?: boolean }} [options]
 * @returns {any[]}
 */
export function filterPresets(library, query, activeTags, options) {
  const needle = String(query ?? '').trim().toLowerCase()
  const tags = [...(activeTags ?? [])]
  const includeDisabled = options?.includeDisabled === true
  return (library ?? []).filter((preset) => {
    if (!includeDisabled && preset?.enabled === false) return false
    if (tags.length > 0 && !tags.every((tag) => (preset?.tags ?? []).includes(tag))) return false
    if (needle.length === 0) return true
    return [preset?.name, preset?.id, ...(preset?.tags ?? [])].join(' ').toLowerCase().includes(needle)
  })
}

/**
 * @param {readonly any[]} library
 * @param {string} query
 * @returns {any[]}
 */
export function searchPresets(library, query) {
  return filterPresets(library, query, [])
}

/**
 * Validate a preset form before it reaches the host.
 * @param {{ name?: string, id?: string, text?: string, tags?: string }} draft
 * @returns {{ ok: true, preset: object } | { ok: false, message: string }}
 */
export function validateDraft(draft) {
  const name = String(draft?.name ?? '').trim()
  const text = String(draft?.text ?? '')
  if (name.length === 0) return { ok: false, message: '给这个预设起个名字吧～' }
  if (text.trim().length === 0) return { ok: false, message: '预设内容是空的，注入时不会起作用哦。' }
  if (text.length > 20000) return { ok: false, message: '预设内容太长了（上限 20000 字）。' }
  const tags = String(draft?.tags ?? '')
    .split(/[,，\s]+/)
    .map((tag) => tag.trim())
    .filter((tag) => tag.length > 0)
  const explicitId = String(draft?.id ?? '').trim()
  return {
    ok: true,
    preset: { id: slugify(explicitId.length > 0 ? explicitId : name), name, text, tags, enabled: true },
  }
}
