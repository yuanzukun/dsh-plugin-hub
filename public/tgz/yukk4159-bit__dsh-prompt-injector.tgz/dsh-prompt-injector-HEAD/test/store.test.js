import assert from 'node:assert/strict'
import test from 'node:test'

import { PresetStore, defaultLibraryPath } from '../lib/store.js'

test('replace normalizes, persists and reports the stored library', async () => {
  const writes = []
  const store = new PresetStore({
    initial: [],
    persist: async (presets) => writes.push(presets),
  })
  const library = await store.replace([{ name: 'A', text: 'a' }, { name: 'A', text: 'b' }])
  assert.deepEqual(
    library.map((preset) => preset.id),
    ['a', 'a-2'],
  )
  assert.equal(writes.length, 1)
  assert.equal(writes[0].length, 2)
})

test('upsert inserts, then replaces in place', async () => {
  const store = new PresetStore({ initial: [{ name: 'A', text: '1' }] })
  await store.upsert({ id: 'a', name: 'A', text: '2' })
  assert.equal(store.presets.length, 1)
  assert.equal(store.presets[0].text, '2')
  await store.upsert({ name: 'B', text: 'b' })
  assert.deepEqual(
    store.presets.map((preset) => preset.id),
    ['a', 'b'],
  )
})

test('remove reports whether anything was deleted', async () => {
  const store = new PresetStore({ initial: [{ name: 'A' }] })
  assert.equal(await store.remove('a'), true)
  assert.equal(await store.remove('a'), false)
  assert.equal(store.presets.length, 0)
})

test('a failing settings write falls back to the JSON copy', async () => {
  const reports = []
  const store = new PresetStore({
    initial: [],
    persist: async () => {
      throw new Error('no provider')
    },
    filePath: undefined,
    report: (message, error) => reports.push(`${message}: ${String(error?.message ?? error)}`),
  })
  await store.upsert({ name: 'A', text: 'a' })
  assert.equal(reports.length, 1)
  assert.match(reports[0], /settings write failed/)
})

test('loadFromFile seeds an empty store from its JSON copy', async () => {
  const { mkdtemp, rm, writeFile } = await import('node:fs/promises')
  const { tmpdir } = await import('node:os')
  const { join } = await import('node:path')
  const dir = await mkdtemp(join(tmpdir(), 'dpi-store-'))
  try {
    const file = join(dir, 'library.json')
    await writeFile(file, JSON.stringify({ version: 1, presets: [{ name: 'FromDisk', text: 'x' }] }), 'utf8')
    const store = new PresetStore({ initial: [], filePath: file })
    const library = await store.loadFromFile()
    assert.equal(library.length, 1)
    assert.equal(library[0].name, 'FromDisk')
  } finally {
    await rm(dir, { recursive: true, force: true })
  }
})

test('loadFromFile never clobbers a library that Config already carried', async () => {
  const store = new PresetStore({ initial: [{ name: 'Configured' }], filePath: 'Z:\\does\\not\\exist.json' })
  const library = await store.loadFromFile()
  assert.equal(library[0].name, 'Configured')
})

test('session selections round-trip, carry their mode and drop a vanished preset', () => {
  const store = new PresetStore({ initial: [{ id: 'a', name: 'A' }, { id: 'b', name: 'B' }] })
  assert.deepEqual(store.getSelection('s1'), { presetId: '', mode: 'once' })
  store.setActive('s1', 'a')
  store.setActive('s2', 'b', 'sticky')
  // The default mode is the safe one: one message, not every message.
  assert.deepEqual(store.getSelection('s1'), { presetId: 'a', mode: 'once' })
  assert.deepEqual(store.activeSelections(), {
    s1: { presetId: 'a', mode: 'once' },
    s2: { presetId: 'b', mode: 'sticky' },
  })

  // Re-picking the same preset in the other mode must move the mode.
  store.setActive('s1', 'a', 'sticky')
  assert.deepEqual(store.getSelection('s1'), { presetId: 'a', mode: 'sticky' })

  store.setActive('s1', '')
  assert.deepEqual(store.getSelection('s1'), { presetId: '', mode: 'once' })
  assert.deepEqual(store.activeSelections(), { s2: { presetId: 'b', mode: 'sticky' } })

  // Removing the preset must invalidate the selection instead of leaving a
  // dangling id the injector would silently ignore.
  store.presets = store.presets.filter((preset) => preset.id !== 'b')
  assert.deepEqual(store.getSelection('s2'), { presetId: '', mode: 'once' })
  assert.deepEqual(store.activeSelections(), {})
})

test('clearActive reports whether a pick was released', () => {
  const store = new PresetStore({ initial: [{ id: 'a' }] })
  store.setActive('s1', 'a', 'sticky')
  assert.equal(store.clearActive('s1'), true)
  assert.equal(store.clearActive('s1'), false)
  assert.equal(store.clearActive('   '), false)
  assert.deepEqual(store.activeSelections(), {})
})

test('an unknown mode never becomes sticky by accident', () => {
  const store = new PresetStore({ initial: [{ id: 'a' }] })
  const applied = store.setActive('s1', 'a', 'every-turn')
  assert.equal(applied.mode, 'once')
  assert.deepEqual(store.getSelection('s1'), { presetId: 'a', mode: 'once' })
})

test('a blank session id never records a selection', () => {
  const store = new PresetStore({ initial: [{ id: 'a' }] })
  assert.deepEqual(store.setActive('   ', 'a'), { sessionId: '', presetId: '', mode: 'once' })
  assert.deepEqual(store.activeSelections(), {})
})

test('defaultLibraryPath stays under the injector directory', () => {
  const path = defaultLibraryPath('D:\\dsh-home', 'prompt-injector')
  assert.match(path, /prompt-injector[\\/]prompt-injector\.json$/)
})
