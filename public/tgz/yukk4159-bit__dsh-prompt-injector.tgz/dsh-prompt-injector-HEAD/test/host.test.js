import assert from 'node:assert/strict'
import test from 'node:test'

/**
 * Host-half integration test.
 *
 * It drives the real `apply()` from `lib/index.js` against a recording Cordis
 * context, then invokes every listener the plugin installed. That exercises the
 * whole injection path — Config resolution, `agent/pre-step` ordering, message
 * rewriting and the disposers — without a model credential.
 */

/** @returns {Promise<{ apply: Function, Config: any, name: string }>} */
async function loadPlugin() {
  return import('../lib/index.js')
}

/**
 * A minimal Cordis context that records what the plugin registers.
 * @param {{ services?: Record<string, unknown> }} [options]
 */
function recordingContext({ services = {} } = {}) {
  const listeners = new Map()
  const effects = []
  const context = {
    logger: undefined,
    get(name) {
      return services[name]
    },
    on(event, listener) {
      const list = listeners.get(event) ?? []
      list.push(listener)
      listeners.set(event, list)
      return () => {
        const current = listeners.get(event) ?? []
        listeners.set(
          event,
          current.filter((entry) => entry !== listener),
        )
      }
    },
    effect(callback, label) {
      const disposer = callback()
      effects.push({ label, disposer })
      return () => disposer?.()
    },
  }
  return { context, listeners, effects }
}

const config = {
  enabled: true,
  position: 'prefix',
  template: '[{{name}}]\n{{text}}\n[/{{name}}]',
  separator: '\n\n',
  defaultPresetId: '',
  agentPresets: [],
  presets: [
    { id: 'verify', name: '验证预设', text: 'INJECTOR-VERIFY-OK', tags: ['verify'], enabled: true },
    { id: 'off-preset', name: '停用示例', text: 'SHOULD-NEVER-APPEAR', enabled: false },
  ],
}

/**
 * @param {string} text
 * @param {object} [source]
 */
function userMessage(text, source = { kind: 'user' }) {
  return { id: 'm1', role: 'user', source, content: [{ type: 'text', text }] }
}

/**
 * Run the plugin's pre-step waterfall.
 * @param {Function[]} listeners
 * @param {object[]} messages
 */
async function preStep(listeners, messages) {
  const payload = { agent: { session: { agentPreset: 'standard' } }, messages, turn: 1, step: 1, signal: {} }
  const next = async () => ({ kind: 'enter', messages })
  let index = 0
  const dispatch = async (list) => {
    if (index >= list.length) return next()
    const listener = list[index++]
    return listener(payload, () => dispatch(list))
  }
  return dispatch(listeners)
}

/** True when the schemastery peer resolves, which decides how strict the
 * Config assertions can be. */
const schemaModule = await import('../lib/config.js').then(
  () => true,
  () => false,
)

test('the plugin exposes the documented host surface', async () => {
  const plugin = await loadPlugin()
  assert.equal(plugin.name, 'prompt-injector')
  assert.equal(plugin.INJECTOR_ID, 'prompt-injector')
  assert.equal(typeof plugin.apply, 'function')
})

test('Config exposes a Standard Schema, with the peer or without it', async () => {
  const plugin = await loadPlugin()
  const standard = plugin.Config?.['~standard']
  assert.equal(typeof standard?.validate, 'function')
  const resolved = standard.validate({})
  assert.equal(resolved.issues, undefined)
  assert.ok(resolved.value !== null && typeof resolved.value === 'object')
})

test('Config fills every documented default when schemastery resolves', async (t) => {
  if (!schemaModule) {
    t.skip('@deepseek-ai/schemastery is not resolvable from this checkout; the pass-through schema is exercised instead')
    return
  }
  const plugin = await loadPlugin()
  const resolved = plugin.Config['~standard'].validate({})
  assert.equal(resolved.value.enabled, true)
  assert.equal(resolved.value.position, 'prefix')
  assert.equal(resolved.value.defaultPresetId, '')
  assert.deepEqual(resolved.value.agentPresets, [])
  assert.deepEqual(resolved.value.presets, [])
  assert.match(resolved.value.template, /\{\{text\}\}/)
})

test('pre-step injects the tokenized preset at the FRONT of the message', async () => {
  const plugin = await loadPlugin()
  const { context, listeners } = recordingContext()
  plugin.apply(context, config)

  const listeners_ = listeners.get('agent/pre-step')
  assert.equal(listeners_.length, 1)

  const token = '\uE000\uE001verify\uE002'
  const result = await preStep(listeners_, [userMessage(`帮我看看 ${token}`)])

  assert.equal(result.kind, 'enter')
  assert.equal(result.messages[0].content[0].text, '[验证预设]\nINJECTOR-VERIFY-OK\n[/验证预设]\n\n帮我看看')
})

test('pre-step ignores disabled presets and a missing token', async () => {
  const plugin = await loadPlugin()
  const { context, listeners } = recordingContext()
  plugin.apply(context, { ...config, defaultPresetId: 'off-preset' })

  const result = await preStep(listeners.get('agent/pre-step'), [userMessage('原样发送')])
  assert.equal(result.messages[0].content[0].text, '原样发送')
})

test('pre-step never rewrites a runtime-context or reminder message', async () => {
  const plugin = await loadPlugin()
  const { context, listeners } = recordingContext()
  plugin.apply(context, { ...config, defaultPresetId: 'verify' })

  const messages = [
    userMessage('human text'),
    userMessage('reminder body', { kind: 'runtime-context' }),
    userMessage('skill body', { kind: 'plugin' }),
  ]
  const result = await preStep(listeners.get('agent/pre-step'), messages)
  assert.match(result.messages[0].content[0].text, /^\[验证预设\]/)
  assert.equal(result.messages[1].content[0].text, 'reminder body')
  assert.equal(result.messages[2].content[0].text, 'skill body')
})

test('the agent-preset allow-list gates the injection', async () => {
  const plugin = await loadPlugin()
  const { context, listeners } = recordingContext()
  plugin.apply(context, { ...config, defaultPresetId: 'verify', agentPresets: ['other'] })

  const result = await preStep(listeners.get('agent/pre-step'), [userMessage('nope')])
  assert.equal(result.messages[0].content[0].text, 'nope')
})

test('a disabled plugin leaves the message untouched', async () => {
  const plugin = await loadPlugin()
  const { context, listeners } = recordingContext()
  plugin.apply(context, { ...config, enabled: false, defaultPresetId: 'verify' })

  const result = await preStep(listeners.get('agent/pre-step'), [userMessage('untouched')])
  assert.equal(result.messages[0].content[0].text, 'untouched')
})

test('a rejecting downstream listener short-circuits the injection', async () => {
  const plugin = await loadPlugin()
  const { context, listeners } = recordingContext()
  plugin.apply(context, { ...config, defaultPresetId: 'verify' })

  const payload = { agent: { session: {} }, messages: [userMessage('x')], turn: 1, step: 1, signal: {} }
  const decision = await listeners.get('agent/pre-step')[0](payload, async () => ({ kind: 'reject' }))
  assert.equal(decision.kind, 'reject')
})

test('apply installs disposable routes and effects only when a web server exists', async () => {
  const plugin = await loadPlugin()
  const registered = []
  const { context, effects } = recordingContext({
    services: {
      webServer: {
        register(route) {
          registered.push(route)
          return () => {}
        },
      },
    },
  })
  plugin.apply(context, config)
  assert.deepEqual(
    registered.map((route) => route.path),
    [
      '/prompt-injector/prompt-injector/library',
      '/prompt-injector/prompt-injector/preset',
      '/prompt-injector/prompt-injector/selection',
    ],
  )
  assert.ok(effects.length >= 1)
})

test('a session selection made through the HTTP route drives the injection', async () => {
  const plugin = await loadPlugin()
  const { registerRoutes } = await import('../lib/http.js')

  const routes = new Map()
  const library = [
    { id: 'code', name: '代码评审', text: '请严格评审。', enabled: true },
    { id: 'novel', name: '小说续写', text: '续写 300 字。', enabled: true },
  ]
  const sessionId = 'session-abc'

  // One seam, both halves: the plugin builds the store, the routes read and
  // write it, and the pre-step listener serves the selection back.
  const { context, listeners } = recordingContext({
    services: {
      webServer: {
        register(route) {
          routes.set(`${route.kind}:${route.path}`, route)
          return () => routes.delete(`${route.kind}:${route.path}`)
        },
      },
    },
  })
  let store
  plugin.apply(context, {
    ...config,
    presets: library,
    onStore: (created) => {
      store = created
    },
  })
  assert.ok(store, 'the plugin must expose the store it built')

  /** Minimal request/response pair for a route handler. */
  const call = async (key, method, body) => {
    const route = routes.get(key)
    assert.ok(route, `route ${key} must be registered`)
    const chunks = body === undefined ? [] : [Buffer.from(JSON.stringify(body), 'utf8')]
    const request = {
      method,
      url: '/',
      async *[Symbol.asyncIterator]() {
        for (const chunk of chunks) yield chunk
      },
    }
    let status = 0
    let payload = ''
    const response = {
      writeHead(code) {
        status = code
      },
      end(text) {
        payload = text ?? ''
      },
    }
    await route.handler(request, response)
    return { status, body: payload.length > 0 ? JSON.parse(payload) : undefined }
  }

  const step = async (messages) =>
    listeners.get('agent/pre-step')[0](
      { agent: { session: { id: sessionId, agentPreset: 'standard' } }, messages, turn: 1, step: 1, signal: {} },
      async () => ({ kind: 'enter', messages }),
    )

  const before = await step([userMessage('接着写')])
  assert.equal(before.messages[0].content[0].text, '接着写')

  const selected = await call('exact:/prompt-injector/prompt-injector/selection', 'PUT', {
    sessionId,
    presetId: 'novel',
    mode: 'sticky',
  })
  assert.equal(selected.status, 200)
  assert.equal(selected.body.applied.presetId, 'novel')
  assert.equal(selected.body.applied.mode, 'sticky')

  const readView = await call('exact:/prompt-injector/prompt-injector/library', 'GET')
  assert.equal(readView.status, 200)
  assert.deepEqual(readView.body.selections, { [sessionId]: { presetId: 'novel', mode: 'sticky' } })

  const injected = await step([userMessage('接着写')])
  const text = injected.messages[0].content[0].text
  assert.match(text, /^\[小说续写\]/)
  assert.match(text, /接着写$/)

  // A sticky pick keeps applying: the second send is injected as well.
  const again = await step([userMessage('再来一段')])
  assert.match(again.messages[0].content[0].text, /^\[小说续写\]/)

  // Clearing the selection must stop the injection, which is what the picker's
  // "取消" control does.
  await call('exact:/prompt-injector/prompt-injector/selection', 'PUT', { sessionId, presetId: '' })
  const cleared = await step([userMessage('接着写')])
  assert.equal(cleared.messages[0].content[0].text, '接着写')
})

test('a one-shot pick is released after it has been injected once', async () => {
  const plugin = await loadPlugin()

  const routes = new Map()
  const sessionId = 'session-once'
  const { context, listeners } = recordingContext({
    services: {
      webServer: {
        register(route) {
          routes.set(`${route.kind}:${route.path}`, route)
          return () => routes.delete(`${route.kind}:${route.path}`)
        },
      },
    },
  })
  plugin.apply(context, {
    ...config,
    presets: [{ id: 'code', name: '代码评审', text: '请严格评审。', enabled: true }],
  })

  const selection = routes.get('exact:/prompt-injector/prompt-injector/selection')
  const chunks = [Buffer.from(JSON.stringify({ sessionId, presetId: 'code', mode: 'once' }), 'utf8')]
  await selection.handler(
    {
      method: 'PUT',
      url: '/',
      async *[Symbol.asyncIterator]() {
        for (const chunk of chunks) yield chunk
      },
    },
    { writeHead() {}, end() {} },
  )

  const step = async (text) =>
    listeners.get('agent/pre-step')[0](
      { agent: { session: { id: sessionId, agentPreset: 'standard' } }, messages: [userMessage(text)], turn: 1, step: 1, signal: {} },
      async () => ({ kind: 'enter', messages: [userMessage(text)] }),
    )

  const first = await step('第一句')
  assert.match(first.messages[0].content[0].text, /^\[代码评审\]/)

  // The pick covered the next message only, so the one after it is untouched.
  const second = await step('第二句')
  assert.equal(second.messages[0].content[0].text, '第二句')

  // And the host has forgotten it, so the picker's chip can go back to 🌸.
  const view = await readLibrary(routes)
  assert.deepEqual(view.selections, {})
})

/**
 * GET the library route and parse its JSON body.
 * @param {Map<string, any>} routes
 */
async function readLibrary(routes) {
  const route = routes.get('exact:/prompt-injector/prompt-injector/library')
  let payload = ''
  await route.handler(
    {
      method: 'GET',
      url: '/',
      async *[Symbol.asyncIterator]() {},
    },
    { writeHead() {}, end(text) { payload = text ?? '' } },
  )
  return JSON.parse(payload)
}

test('the settings write path is preferred and the JSON copy is the fallback', async () => {
  const plugin = await loadPlugin()
  const updates = []
  const services = {
    settings: {
      describe: () => [{ ns: 'prompt-injector', revision: 7 }],
      update: async (ns, patch, revision) => updates.push({ ns, patch, revision }),
    },
  }
  const { context } = recordingContext({ services })
  plugin.apply(context, config)

  const store = new (await import('../lib/store.js')).PresetStore({
    initial: config.presets,
    persist: async (presets) => {
      const descriptor = services.settings.describe().find((entry) => entry.ns === 'prompt-injector')
      await services.settings.update('prompt-injector', { presets }, descriptor.revision)
    },
  })
  await store.upsert({ id: 'new', name: 'New', text: 'body' })
  assert.equal(updates.length, 1)
  assert.equal(updates[0].ns, 'prompt-injector')
  assert.equal(updates[0].revision, 7)
  assert.equal(updates[0].patch.presets.length, 3)
})
