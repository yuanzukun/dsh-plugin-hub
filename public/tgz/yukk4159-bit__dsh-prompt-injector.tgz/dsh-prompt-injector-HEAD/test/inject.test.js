import assert from 'node:assert/strict'
import test from 'node:test'

import { encodeToken, normalizeLibrary } from '../lib/core.js'
import { applyInjection, candidateIndexes, resolveInjection, rewriteMessage } from '../lib/inject.js'

/**
 * @param {object} [overrides]
 */
function config(overrides = {}) {
  return {
    enabled: true,
    position: 'prefix',
    template: '[{{name}}]\n{{text}}\n[/{{name}}]',
    separator: '\n\n',
    defaultPresetId: '',
    presets: normalizeLibrary([
      { id: 'code', name: '代码评审', text: '请严格评审。', tags: ['work'] },
      { id: 'off', name: '停用', text: '不该出现', enabled: false },
    ]),
    ...overrides,
  }
}

/**
 * @param {string} text
 * @param {object} [extra]
 */
function userMessage(text, extra = {}) {
  return {
    id: 'm1',
    role: 'user',
    source: { kind: 'user' },
    content: [{ type: 'text', text }],
    ...extra,
  }
}

test('candidateIndexes only accepts human-authored text messages', () => {
  const messages = [
    { role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: 'a' }] },
    { role: 'user', source: { kind: 'runtime-context' }, content: [{ type: 'text', text: 'b' }] },
    { role: 'user', source: { kind: 'user' }, content: [{ type: 'image', attachment: {} }] },
    { role: 'assistant', content: [{ type: 'text', text: 'c' }] },
  ]
  assert.deepEqual(candidateIndexes(messages), [0])
})

test('resolveInjection prefers the token over the session selection and the default', () => {
  const settings = config({ defaultPresetId: 'code' })
  const fromToken = resolveInjection({
    text: `hi ${encodeToken('code')}`,
    presets: settings.presets,
    defaultPresetId: settings.defaultPresetId,
    sessionPresetId: 'other',
    template: settings.template,
  })
  assert.equal(fromToken.preset?.id, 'code')
  assert.equal(fromToken.tokenFound, true)
  assert.equal(fromToken.source, 'token')
  assert.match(fromToken.injected, /请严格评审。/)
})

test('the session selection beats the configured default and reports its source', () => {
  const settings = config({ defaultPresetId: 'code' })
  const fromSession = resolveInjection({
    text: 'hi',
    presets: settings.presets,
    defaultPresetId: settings.defaultPresetId,
    sessionPresetId: 'code',
    template: settings.template,
  })
  assert.equal(fromSession.preset?.id, 'code')
  assert.equal(fromSession.source, 'session')

  const fromDefault = resolveInjection({
    text: 'hi',
    presets: settings.presets,
    defaultPresetId: 'code',
    template: settings.template,
  })
  assert.equal(fromDefault.preset?.id, 'code')
  assert.equal(fromDefault.source, 'default')
})

test('an unknown token suppresses every fallback', () => {
  const settings = config({ defaultPresetId: 'code' })
  const result = resolveInjection({
    text: `hi ${encodeToken('nope')}`,
    presets: settings.presets,
    defaultPresetId: settings.defaultPresetId,
    sessionPresetId: 'code',
    template: settings.template,
  })
  assert.equal(result.preset, undefined)
  assert.equal(result.source, 'none')
  assert.equal(result.injected, '')
})

test('a session selection of a disabled preset injects nothing', () => {
  const settings = config({ defaultPresetId: '' })
  const result = resolveInjection({
    text: 'hi',
    presets: settings.presets,
    defaultPresetId: '',
    sessionPresetId: 'off',
    template: settings.template,
  })
  assert.equal(result.preset, undefined)
})

test('resolveInjection ignores a disabled preset and an unknown token', () => {
  const settings = config({ defaultPresetId: 'off' })
  assert.equal(
    resolveInjection({
      text: 'hi',
      presets: settings.presets,
      defaultPresetId: 'off',
      template: settings.template,
    }).preset,
    undefined,
  )
  assert.equal(
    resolveInjection({
      text: `hi ${encodeToken('nope')}`,
      presets: settings.presets,
      defaultPresetId: 'code',
      template: settings.template,
    }).preset,
    undefined,
  )
})

test('rewriteMessage prefixes the preset and removes the token', () => {
  const result = rewriteMessage({
    message: userMessage(`把这段改一下 ${encodeToken('code')}`),
    config: config(),
  })
  assert.equal(result.changed, true)
  assert.equal(result.preset?.id, 'code')
  assert.equal(result.message.content[0].text, '[代码评审]\n请严格评审。\n[/代码评审]\n\n把这段改一下')
})

test('rewriteMessage leaves an unrelated message byte-identical', () => {
  const message = userMessage('nothing to do')
  const result = rewriteMessage({ message, config: config() })
  assert.equal(result.changed, false)
  assert.equal(result.message, message)
})

test('rewriteMessage supports the suffix position', () => {
  const result = rewriteMessage({
    message: userMessage('body'),
    config: config({ position: 'suffix', defaultPresetId: 'code', separator: ' | ' }),
  })
  assert.equal(result.message.content[0].text, 'body | [代码评审]\n请严格评审。\n[/代码评审]')
})

test('rewriteMessage keeps non-text blocks in place', () => {
  const image = { type: 'image', attachment: { id: 'a' } }
  const message = {
    ...userMessage('look'),
    content: [image, { type: 'text', text: 'look' }],
  }
  const result = rewriteMessage({ message, config: config({ defaultPresetId: 'code' }) })
  assert.equal(result.changed, true)
  assert.equal(result.message.content[0], image)
  assert.match(result.message.content[1].text, /^\[代码评审\]/)
})

test('rewriteMessage reports no change when nothing was tokenized and no text block exists', () => {
  const message = { role: 'user', source: { kind: 'user' }, content: [{ type: 'image' }] }
  assert.equal(rewriteMessage({ message, config: config() }).changed, false)
})

test('applyInjection rewrites only the newest human message in a step', () => {
  const messages = [
    userMessage('older'),
    { role: 'user', source: { kind: 'runtime-context' }, content: [{ type: 'text', text: 'ctx' }] },
    userMessage('newer'),
  ]
  const result = applyInjection({ messages, config: config({ defaultPresetId: 'code' }) })
  assert.equal(result.changed, true)
  assert.equal(result.messages[0].content[0].text, 'older')
  assert.equal(result.messages[1].content[0].text, 'ctx')
  assert.match(result.messages[2].content[0].text, /^\[代码评审\]/)
})

test('applyInjection is inert when disabled or when no candidate exists', () => {
  const messages = [userMessage('hi')]
  const disabled = applyInjection({ messages, config: config({ enabled: false, defaultPresetId: 'code' }) })
  assert.equal(disabled.changed, false)
  assert.equal(disabled.messages[0].content[0].text, 'hi')

  const noCandidate = applyInjection({
    messages: [{ role: 'assistant', content: [{ type: 'text', text: 'x' }] }],
    config: config({ defaultPresetId: 'code' }),
  })
  assert.equal(noCandidate.changed, false)
})

test('applyInjection returns a new array and never mutates the input', () => {
  const messages = [userMessage('hi')]
  const copy = [...messages]
  const result = applyInjection({ messages, config: config({ defaultPresetId: 'code' }) })
  assert.notEqual(result.messages, messages)
  assert.deepEqual(messages, copy)
})

test('applyInjection reports which rule produced the injection', () => {
  const fromToken = applyInjection({
    messages: [userMessage(`hi ${encodeToken('code')}`)],
    config: config({ defaultPresetId: 'code' }),
  })
  assert.equal(fromToken.source, 'token')

  const fromSession = applyInjection({ messages: [userMessage('hi')], config: config({ sessionPresetId: 'code' }) })
  assert.equal(fromSession.source, 'session')

  const fromDefault = applyInjection({ messages: [userMessage('hi')], config: config({ defaultPresetId: 'code' }) })
  assert.equal(fromDefault.source, 'default')

  const idle = applyInjection({ messages: [userMessage('hi')], config: config() })
  assert.equal(idle.source, 'none')
})

test('a hand-typed {{id}} injects for that message only and is taken back out', () => {
  const result = rewriteMessage({
    message: userMessage('帮我看看 {{code}} 这段'),
    config: config({ defaultPresetId: 'off' }),
  })
  assert.equal(result.changed, true)
  assert.equal(result.source, 'token')
  assert.equal(result.message.content[0].text, '[代码评审]\n请严格评审。\n[/代码评审]\n\n帮我看看  这段')
})

test('a {{id}} that matches nothing is left as ordinary prose', () => {
  const result = rewriteMessage({ message: userMessage('写 {{nope}} 这个'), config: config() })
  assert.equal(result.changed, false)
  assert.equal(result.source, 'none')
  assert.equal(result.message.content[0].text, '写 {{nope}} 这个')

  // …and it must not block the session selection either.
  const withSession = rewriteMessage({
    message: userMessage('写 {{nope}} 这个'),
    config: config({ sessionPresetId: 'code' }),
  })
  assert.equal(withSession.source, 'session')
  assert.equal(withSession.message.content[0].text, '[代码评审]\n请严格评审。\n[/代码评审]\n\n写 {{nope}} 这个')
})

test('a {{id}} naming a disabled preset injects nothing and stays as typed', () => {
  const result = rewriteMessage({ message: userMessage('看 {{off}} 这里'), config: config({ defaultPresetId: 'code' }) })
  assert.equal(result.changed, false)
  assert.equal(result.source, 'none')
  assert.equal(result.message.content[0].text, '看 {{off}} 这里')
})

test('the private-use token still suppresses the fallbacks when it names nothing usable', () => {
  const result = rewriteMessage({
    message: userMessage(`看 ${encodeToken('nope')} 这里`),
    config: config({ defaultPresetId: 'code' }),
  })
  assert.equal(result.source, 'none')
  // The stray marker must never reach the model, even with nothing to inject.
  assert.equal(result.message.content[0].text, '看  这里')
})
