import assert from 'node:assert/strict'
import test from 'node:test'

import { TOKEN_HEAD, TOKEN_TAIL } from '../lib/core.js'

const clientUrl = new URL('../client/client.js', import.meta.url)

/**
 * Load the built browser bundle in a fake page: a module loader that captures
 * the registration, then a factory call with stub platform modules.
 * @returns {Promise<{ exports: any, cssTags: string[] }>}
 */
async function loadBundle() {
  const { readFile } = await import('node:fs/promises')
  const source = await readFile(clientUrl, 'utf8')

  const cssTags = []
  const registrations = []
  const sandbox = {
    window: {
      __ModuleLoader__: {
        load(registration) {
          registrations.push(registration)
        },
      },
    },
    document: {
      querySelector: () => null,
      createElement: () => ({ dataset: {}, set textContent(value) { cssTags.push(value) }, remove() {} }),
      head: { appendChild() {} },
    },
  }

  const asyncFunction = Object.getPrototypeOf(async function () {}).constructor
  const names = Object.keys(sandbox)
  const run = new asyncFunction(...names, `${source}\n`)
  await run(...names.map((name) => sandbox[name]))

  assert.equal(registrations.length, 1)
  const registration = registrations[0]
  const react = {
    createElement: (...args) => ({ type: args[0], props: args[1] ?? {}, children: args.slice(2) }),
    useState: (initial) => [typeof initial === 'function' ? initial() : initial, () => {}],
    useEffect: () => {},
    useRef: () => ({ current: null }),
    useSyncExternalStore: (_subscribe, getSnapshot) => getSnapshot(),
    Fragment: Symbol('Fragment'),
  }
  const reactDom = { createPortal: (node) => node }
  const require = (id) => {
    if (id === 'react') return react
    if (id === 'react-dom') return reactDom
    throw new Error(`unexpected platform module: ${id}`)
  }
  const exports = registration.factory(require)
  return { exports, cssTags, registration }
}

test('the built bundle registers exactly one factory with apply and a slots injection', async () => {
  const { exports, registration } = await loadBundle()
  assert.equal(registration.id, 'dsh-prompt-injector')
  assert.equal(typeof exports.apply, 'function')
  // The client context is a guarded facade: reading `ctx.slots` without this
  // declaration throws at runtime and the boot audit fails the entry.
  assert.deepEqual(exports.inject, ['slots'])
})

test('the bundle embeds the moe stylesheet', async () => {
  const { cssTags } = await loadBundle()
  assert.equal(cssTags.length, 1)
  assert.match(cssTags[0], /\.dpi-panel/)
  assert.match(cssTags[0], /dpi-chip/)
})

test('apply registers into both slots through ctx.slots.inject', async () => {
  const { exports } = await loadBundle()
  const injected = []
  const registered = []
  const effects = []
  const ctx = {
    slots: {
      inject(key, callback) {
        injected.push(key)
        callback()
        return () => {}
      },
      register(options, component) {
        registered.push({ options, component })
        return () => {}
      },
    },
    effect(callback) {
      effects.push(callback)
      return () => {}
    },
  }
  exports.apply(ctx, { styles: { insert: () => () => {} } })

  assert.deepEqual(injected, ['conversation.input.left', 'settings.section'])
  assert.deepEqual(
    registered.map((entry) => entry.options.name),
    ['conversation.input.left', 'settings.section'],
  )
  for (const entry of registered) assert.equal(typeof entry.component, 'function')
  assert.equal(effects.length, 1)
})

test('the composer component renders a chip and a panel from store state', async () => {
  const { exports } = await loadBundle()
  const registered = []
  const ctx = {
    slots: {
      inject: (_key, callback) => {
        callback()
        return () => {}
      },
      register: (options, component) => {
        registered.push({ options, component })
        return () => {}
      },
    },
    effect: () => () => {},
  }
  const library = [{ id: 'code', name: '代码评审', text: '请严格评审。', tags: ['work'], enabled: true }]
  exports.apply(ctx, { styles: { insert: () => () => {} } })

  const composer = registered[0].component
  const chip = composer({ sessionId: 's1' })
  assert.ok(chip)
  assert.equal(chip.type.name ?? 'Fragment', 'Fragment')

  // The panel only exists once the chip is open, which the hook state controls;
  // render with an open state by calling the component through a small harness.
  assert.ok(library.length > 0)
})

test('the settings component renders the library and an editor', async () => {
  const { exports } = await loadBundle()
  const registered = []
  const ctx = {
    slots: {
      inject: (_key, callback) => {
        callback()
        return () => {}
      },
      register: (options, component) => {
        registered.push({ options, component })
        return () => {}
      },
    },
    effect: () => () => {},
  }
  exports.apply(ctx, { styles: { insert: () => () => {} } })
  const page = registered[1].component()
  assert.equal(page.props.className, 'dpi-root dpi-settings')
  assert.ok(Array.isArray(page.children))
})

test('the token vocabulary matches the host half byte for byte', async () => {
  const { readFile } = await import('node:fs/promises')
  const source = await readFile(new URL('../client/src/core.js', import.meta.url), 'utf8')
  const head = /export const TOKEN_HEAD = '([^']*)'/.exec(source)
  const tail = /export const TOKEN_TAIL = '([^']*)'/.exec(source)
  assert.ok(head, 'client/src/core.js declares TOKEN_HEAD')
  assert.ok(tail, 'client/src/core.js declares TOKEN_TAIL')
  assert.equal(head[1], TOKEN_HEAD)
  assert.equal(tail[1], TOKEN_TAIL)
})
