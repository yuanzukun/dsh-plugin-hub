import assert from 'node:assert/strict'
import test from 'node:test'

import {
  TOKEN_HEAD,
  TOKEN_TAIL,
  collectTags,
  compose,
  decodeToken,
  encodeToken,
  findPreset,
  injectedText,
  injectionAllowed,
  normalizeLibrary,
  normalizeMode,
  normalizePreset,
  removeToken,
  renderTemplate,
  searchPresets,
  selectablePresets,
  slugify,
  stripTokens,
  toText,
} from '../lib/core.js'

test('toText renders JSON scalars and empties', () => {
  assert.equal(toText('a'), 'a')
  assert.equal(toText(3), '3')
  assert.equal(toText(true), 'true')
  assert.equal(toText(null), '')
  assert.equal(toText(undefined), '')
  assert.equal(toText([1, 2]), '[1,2]')
})

test('slugify keeps ascii and falls back to letters', () => {
  assert.equal(slugify('Meeting Summary'), 'meeting-summary')
  assert.equal(slugify('  代码 评审  '), '代码-评审')
  assert.equal(slugify('!!!'), 'preset')
  assert.equal(slugify('a'.repeat(200)).length, 64)
})

test('normalizePreset fills defaults and trims', () => {
  const preset = normalizePreset({ name: '  X  ', text: 'body', tags: ['a', 'a', ' b '] }, 0)
  assert.deepEqual(preset, { id: 'x', name: 'X', text: 'body', tags: ['a', 'b'], enabled: true })
})

test('normalizePreset honours an explicit id and disabled flag', () => {
  const preset = normalizePreset({ id: 'My ID', name: 'n', text: 't', enabled: false }, 0)
  assert.equal(preset.id, 'my-id')
  assert.equal(preset.enabled, false)
})

test('normalizeLibrary keeps ids unique', () => {
  const library = normalizeLibrary([{ name: 'dup' }, { name: 'dup' }, { name: 'dup' }])
  assert.deepEqual(
    library.map((preset) => preset.id),
    ['dup', 'dup-2', 'dup-3'],
  )
})

test('tokens round-trip and stay out of prose', () => {
  const token = encodeToken('meeting-summary')
  assert.ok(token.startsWith(TOKEN_HEAD))
  assert.ok(token.endsWith(TOKEN_TAIL))
  assert.deepEqual(decodeToken(`hello ${token} world`), {
    id: 'meeting-summary',
    start: 6,
    end: 6 + token.length,
    raw: token,
    style: 'token',
  })
  assert.equal(decodeToken('no token here'), undefined)
})

test('a typed {{id}} reference decodes too, and only inside braces', () => {
  assert.deepEqual(decodeToken('帮我看看 {{code-review}}'), {
    id: 'code-review',
    start: 5,
    end: 20,
    raw: '{{code-review}}',
    style: 'braces',
  })
  assert.deepEqual(decodeToken('{{ spaced }}'), {
    id: 'spaced',
    start: 0,
    end: 12,
    raw: '{{ spaced }}',
    style: 'braces',
  })
  assert.equal(decodeToken('{code}'), undefined)
  assert.equal(decodeToken('{{}}'), undefined)
  assert.equal(decodeToken('{{not a slug}}'), undefined)
  // The private-use spelling wins when both are present.
  assert.equal(decodeToken(`{{a}} ${encodeToken('b')}`).style, 'token')
  // A caller that only understands the wire format can opt out.
  assert.equal(decodeToken('{{a}}', { allowBraces: false }), undefined)
})

test('stripTokens removes the private-use tokens and leaves a typed reference alone', () => {
  const text = `a${encodeToken('x')}b${encodeToken('y')}c`
  assert.equal(stripTokens(text), 'abc')
  // `{{id}}` needs the library to tell a reference from prose, so the
  // text-only helper must not touch it.
  assert.equal(stripTokens('keep {{code}} please'), 'keep {{code}} please')
})

test('removeToken cuts exactly the decoded span', () => {
  const token = encodeToken('x')
  assert.equal(removeToken(`a${token}b`, decodeToken(`a${token}b`)), 'ab')
  assert.equal(removeToken('untouched', undefined), 'untouched')
})

test('findPreset matches by id only', () => {
  const library = normalizeLibrary([{ name: 'A' }])
  assert.equal(findPreset(library, 'a')?.name, 'A')
  assert.equal(findPreset(library, 'A'), undefined)
  assert.equal(findPreset(library, ''), undefined)
})

test('selectablePresets drops disabled entries', () => {
  const library = normalizeLibrary([{ name: 'on' }, { name: 'off', enabled: false }])
  assert.deepEqual(
    selectablePresets(library).map((preset) => preset.id),
    ['on'],
  )
})

test('searchPresets matches name, id and tags', () => {
  const library = normalizeLibrary([
    { name: '评审', tags: ['work'] },
    { name: 'Novel', tags: ['writing'] },
  ])
  assert.equal(searchPresets(library, 'work').length, 1)
  assert.equal(searchPresets(library, 'novel')[0].name, 'Novel')
  assert.equal(searchPresets(library, '  ').length, 2)
  assert.equal(searchPresets(library, 'zzz').length, 0)
})

test('collectTags is deduplicated and sorted', () => {
  const library = normalizeLibrary([{ name: 'a', tags: ['b', 'a'] }, { name: 'c', tags: ['a'] }])
  assert.deepEqual(collectTags(library), ['a', 'b'])
})

test('renderTemplate substitutes name, text and id', () => {
  const preset = normalizePreset({ id: 'p', name: 'N', text: 'T' }, 0)
  assert.equal(renderTemplate('[{{name}}]{{text}}/{{id}}', preset), '[N]T/p')
})

test('injectedText drops an empty render', () => {
  assert.equal(injectedText({ preset: undefined, template: 'x' }), '')
  assert.equal(injectedText({ preset: normalizePreset({ name: 'n', text: '   ' }, 0), template: '{{text}}' }), '')
  assert.equal(injectedText({ preset: normalizePreset({ name: 'n', text: 'ok' }, 0), template: '{{text}}' }), 'ok')
})

test('compose respects position, separator and empty sides', () => {
  assert.equal(compose({ userText: 'U', presetText: 'P', position: 'prefix', separator: '\n\n' }), 'P\n\nU')
  assert.equal(compose({ userText: 'U', presetText: 'P', position: 'suffix', separator: ' | ' }), 'U | P')
  assert.equal(compose({ userText: 'U', presetText: '', position: 'prefix', separator: '\n\n' }), 'U')
  assert.equal(compose({ userText: '', presetText: 'P', position: 'prefix', separator: '\n\n' }), 'P')
})

test('injectionAllowed honours the agent preset allow-list', () => {
  assert.equal(injectionAllowed({ enabled: true, agentPresets: [], agentPreset: undefined }), true)
  assert.equal(injectionAllowed({ enabled: false, agentPresets: [], agentPreset: 'x' }), false)
  assert.equal(injectionAllowed({ enabled: true, agentPresets: ['a'], agentPreset: 'a' }), true)
  assert.equal(injectionAllowed({ enabled: true, agentPresets: ['a'], agentPreset: 'b' }), false)
  assert.equal(injectionAllowed({ enabled: true, agentPresets: ['a'], agentPreset: undefined }), false)
})

test('normalizeMode defaults to once and only sticky opts out', () => {
  assert.equal(normalizeMode(undefined), 'once')
  assert.equal(normalizeMode(''), 'once')
  assert.equal(normalizeMode('every'), 'once')
  assert.equal(normalizeMode('once'), 'once')
  assert.equal(normalizeMode('sticky'), 'sticky')
})
