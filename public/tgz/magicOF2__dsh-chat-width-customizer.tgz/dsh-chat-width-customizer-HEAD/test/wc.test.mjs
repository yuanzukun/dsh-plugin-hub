/**
 * dsh-chat-width-customizer - logic tests (Node only, no browser needed).
 *
 * Loads the REAL bundle (lib/client.js) through a minimal __ModuleLoader__
 * shim and asserts the pure helpers exported as `_internals`.
 *
 * Run:  npm test   (node --test)
 */
globalThis.window = {
	__ModuleLoader__: {
		load: (mod) => {
			globalThis.__cwx_loaded = mod;
		}
	}
};

const mod = await import("../lib/client.js");
const captured = globalThis.__cwx_loaded;
if (!captured) throw new Error("bundle did not register with __ModuleLoader__");

const loaded = captured.factory((name) => {
	if (name === "react") return {};
	throw new Error("unexpected require: " + name);
});
if (typeof loaded.apply !== "function") throw new Error("apply missing");
if (!Array.isArray(loaded.inject)) throw new Error("inject missing");
const I = loaded._internals;
if (!I) throw new Error("_internals missing");

import assert from "node:assert/strict";
import { test } from "node:test";

test("nextPreset: cycles forward through the preset list", () => {
	assert.equal(I.nextPreset(I.PRESETS, 748), 896);
	assert.equal(I.nextPreset(I.PRESETS, 1440), 1600);
	assert.equal(I.nextPreset(I.PRESETS, 1600), 748); // wrap-around
});

test("nextPreset: unknown current falls back to the first preset", () => {
	// e.g. a width persisted by an older version that is no longer a preset
	assert.equal(I.nextPreset(I.PRESETS, 999), I.PRESETS[0]);
});

test("effectiveWidth: wide viewports keep the preset verbatim", () => {
	assert.equal(I.effectiveWidth(1600, 1920), 1600);
	assert.equal(I.effectiveWidth(748, 1024), 748);
});

test("effectiveWidth: narrow viewports clamp to fit (min 24px margin)", () => {
	assert.equal(I.effectiveWidth(1600, 800), 800 - 24);
	assert.equal(I.effectiveWidth(748, 500), 500 - 24);
});

test("effectiveWidth: never below the 320px floor", () => {
	assert.equal(I.effectiveWidth(748, 200), 320);
});

test("widthCss: overrides both variables on the scroll container and releases the bubble cap", () => {
	const css = I.widthCss(1152);
	assert.ok(css.includes("--dsh-chat-content-width:1152px"));
	assert.ok(css.includes("--dsh-composer-card-max-width:calc(var(--dsh-chat-content-width) + 32px)"));
	assert.ok(css.includes('[data-conversation-scroll]'));
	assert.ok(css.includes("userStack"));
});

test("readSavedFrom: accepts only current presets", () => {
	const ok = (k) => (k === I.STORAGE_KEY ? "1280" : null);
	assert.equal(I.readSavedFrom(ok, I.PRESETS), 1280);
	const stale = (k) => (k === I.STORAGE_KEY ? "999" : null); // removed preset
	assert.equal(I.readSavedFrom(stale, I.PRESETS), I.PRESETS[0]);
	const junk = (k) => (k === I.STORAGE_KEY ? "wide" : null);
	assert.equal(I.readSavedFrom(junk, I.PRESETS), I.PRESETS[0]);
	const none = () => null;
	assert.equal(I.readSavedFrom(none, I.PRESETS), I.PRESETS[0]);
});

test("readSavedFrom: throwing accessor falls back to the default preset", () => {
	assert.equal(I.readSavedFrom(() => { throw new Error("blocked"); }, I.PRESETS), I.PRESETS[0]);
});
