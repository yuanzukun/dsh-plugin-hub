import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { apply, inject, internals, name } from '../lib/daemon.js'

const CONFIG = { brief: 'You are the ecosystem watcher.', flushIntervalMs: 300_000, journal: true }

/** Build a stub host context with the three services the daemon injects. */
function makeCtx({ services = {} } = {}) {
  const captured = { effects: [], listeners: new Map(), created: [], flushes: 0, errors: [] }
  // Production shape since dsh 0.1.2-alpha.4: `snapshotEvents(fromSeq)`, no
  // `events` array. A double that keeps the old property is weaker than the
  // thing it stands in for, and would have stayed green through the outage.
  const log = []
  const session = {
    seq: 0,
    log,
    snapshotEvents: (fromSeq = 0) => log.filter(e => e.seq >= fromSeq),
    header: { id: 'session-test' },
  }
  const agent = {
    session,
    whenIdle: async () => {},
    followup: vi.fn(),
  }
  const provided = {
    loader: { await: async () => {} },
    agents: {
      create: async (spec) => {
        captured.created.push(spec)
        return { agent }
      },
    },
    agentDefaultModel: { currentSelection: () => ({ provider: 'deepseek', model: 'deepseek-flash' }) },
    sessions: { flush: async () => void captured.flushes++ },
    ...services,
  }
  const ctx = {
    get: service => provided[service],
    on: (event, handler) => void captured.listeners.set(event, handler),
    effect: fn => void captured.effects.push(fn()),
    logger: { error: msg => void captured.errors.push(msg) },
  }
  return { ctx, captured, agent, session }
}

/** Append one assistant message to the stub session log. */
function say(session, text) {
  session.log.push({ seq: session.seq++, type: 'assistant/message', data: { message: { content: [{ type: 'text', text }] } } })
}

let written
beforeEach(() => {
  vi.useFakeTimers()
  written = []
  internals.stdout = { write: chunk => void written.push(chunk) }
})
afterEach(() => {
  vi.useRealTimers()
  internals.stdout = process.stdout
})

describe('registration', () => {
  it('exports the function-plugin surface', () => {
    expect(name).toBe('dsh-watch-daemon')
    expect(inject).toEqual(['agentDefaultModel', 'agents', 'sessions'])
  })

  it('holds the event loop open and releases it on disposal', async () => {
    const { ctx, captured } = makeCtx()
    apply(ctx, CONFIG)
    await vi.waitFor(() => expect(captured.created.length).toBe(1))
    expect(vi.getTimerCount()).toBeGreaterThan(0)
    for (const dispose of captured.effects) dispose()
    expect(vi.getTimerCount()).toBe(0)
  })
})

describe('eventsSince', () => {
  const { eventsSince } = internals
  const event = seq => ({ seq, type: 'assistant/message' })

  it('reads the accessor dsh 0.1.2 exposes, and honours fromSeq', () => {
    const log = [event(0), event(1), event(2)]
    const session = { snapshotEvents: (from = 0) => log.filter(e => e.seq >= from) }
    expect(eventsSince(session, 1)).toEqual([event(1), event(2)])
  })

  it('still reads the array dsh 0.1.1-rc.2 and earlier exposed', () => {
    const events = [event(0), event(1)]
    expect(eventsSince({ events }, 0)).toBe(events)
  })

  it('throws rather than journal silence when a session offers neither', () => {
    // The failure this guards against is not an exception, it is a daemon
    // that runs for weeks writing nothing because a `?? []` swallowed a
    // renamed property.
    expect(() => eventsSince({ seq: 0 }, 0)).toThrow(/snapshotEvents/)
  })
})

describe('the standing session', () => {
  it('creates one agent on the default model and seeds the brief as user input', async () => {
    const { ctx, captured, agent } = makeCtx()
    apply(ctx, CONFIG)
    await vi.waitFor(() => expect(agent.followup).toHaveBeenCalledTimes(1))
    expect(captured.created[0].agentOptions).toEqual({ provider: 'deepseek', model: 'deepseek-flash' })
    expect(captured.created[0].sessionId).toMatch(/^session-/)
    const message = agent.followup.mock.calls[0][0]
    expect(message.content[0].text).toBe(CONFIG.brief)
    // A user-authored brief, so it refills the watch wake budget like any
    // human turn would; a plugin-sourced one would not.
    expect(message.source.kind).toBe('user')
  })

  it('waits for the loader before creating the agent, so the ear is mounted first', async () => {
    let released
    const gate = new Promise((res) => { released = res })
    const { ctx, captured } = makeCtx({ services: { loader: { await: () => gate } } })
    apply(ctx, CONFIG)
    await Promise.resolve()
    expect(captured.created).toEqual([])
    released()
    await vi.waitFor(() => expect(captured.created.length).toBe(1))
  })

  it('flushes the session on its interval and once more on disposal', async () => {
    const { ctx, captured } = makeCtx()
    apply(ctx, CONFIG)
    await vi.waitFor(() => expect(captured.created.length).toBe(1))
    expect(captured.flushes).toBe(0)
    await vi.advanceTimersByTimeAsync(CONFIG.flushIntervalMs * 2)
    expect(captured.flushes).toBe(2)
    for (const dispose of captured.effects) dispose()
    await vi.waitFor(() => expect(captured.flushes).toBe(3))
  })
})

describe('the operator journal', () => {
  it('writes one timestamped line per active period, not per message', async () => {
    const { ctx, captured, agent, session } = makeCtx()
    apply(ctx, CONFIG)
    await vi.waitFor(() => expect(agent.followup).toHaveBeenCalledTimes(1))
    const status = captured.listeners.get('agent/status')
    // Boot line first: an operator must be able to tell a slow first turn
    // from a daemon that died during startup.
    expect(written).toHaveLength(1)
    expect(written[0]).toMatch(/^\d{4}-\d{2}-\d{2}T.*Z up — session /)
    say(session, 'thinking out loud')
    say(session, 'Standing by.')
    status({ agent, status: 'idle' })
    expect(written).toHaveLength(2)
    expect(written[1]).toMatch(/^\d{4}-\d{2}-\d{2}T.*Z Standing by\.\n$/)
    // The next period reports only its own closing text.
    say(session, 'HEARD acme/dsh-radar')
    status({ agent, status: 'idle' })
    expect(written).toHaveLength(3)
    expect(written[2]).toContain('HEARD acme/dsh-radar')
    expect(written[2]).not.toContain('Standing by')
  })

  it('stays quiet for a period that produced no text, and for other agents', async () => {
    const { ctx, captured, agent, session } = makeCtx()
    apply(ctx, CONFIG)
    await vi.waitFor(() => expect(agent.followup).toHaveBeenCalledTimes(1))
    const status = captured.listeners.get('agent/status')
    status({ agent, status: 'idle' })
    status({ agent, status: 'running' })
    say(session, 'from a subagent')
    status({ agent: { session }, status: 'idle' })
    expect(written.filter(line => !line.includes(' up — session '))).toEqual([])
  })

  it('reads a dsh 0.1.5 (log format v3) period: system heads and failed attempts are not closing text', async () => {
    // v3 writes the system prompt into the log as a `system/message` surface
    // event before each request whose prompt changed, and records a model
    // attempt that committed no message as `assistant/attempt` — which carries
    // a `stream` and NO `data.message`. A period can end on both, when the last
    // step's request fails after its prompt was replaced.
    const { ctx, captured, agent, session } = makeCtx()
    apply(ctx, CONFIG)
    await vi.waitFor(() => expect(agent.followup).toHaveBeenCalledTimes(1))
    const append = (type, data) => session.log.push({ seq: session.seq++, type, data })
    const system = text => append('system/message', { message: { role: 'system', content: [{ type: 'text', text }] } })
    const attempt = () => append('assistant/attempt', { turn: 1, step: 2, stream: [] })
    append('step/start', { turn: 1, step: 1 })
    system('You are dsh.')
    say(session, 'HEARD acme/dsh-radar')
    append('step/start', { turn: 1, step: 2 })
    system('You are dsh. A standing watch is armed.')
    attempt()
    captured.listeners.get('agent/status')({ agent, status: 'idle' })
    expect(written).toHaveLength(2)
    expect(written[1]).toContain('HEARD acme/dsh-radar')
    expect(written[1]).not.toContain('You are dsh')
  })

  it('reads a dsh 0.1.7 (log format v4) period: tool-role results and developer messages are not closing text', async () => {
    // v4 records a tool result as its own tool-role message (`tool/result`,
    // no longer a user-role block) and tool-set changes as `developer/message`.
    // Both carry `data.message.content` text blocks, so only the event type
    // keeps them out of the journal.
    const { ctx, captured, agent, session } = makeCtx()
    apply(ctx, CONFIG)
    await vi.waitFor(() => expect(agent.followup).toHaveBeenCalledTimes(1))
    const append = (type, data) => session.log.push({ seq: session.seq++, type, data })
    say(session, 'HEARD acme/dsh-radar; checking it.')
    append('tool/result', {
      turn: 1,
      step: 2,
      message: { role: 'tool', source: { kind: 'tool', callId: 'call-1' }, toolCallId: 'call-1', content: [{ type: 'text', text: 'README of acme/dsh-radar' }] },
    })
    append('developer/message', { turn: 1, step: 3, message: { role: 'developer', source: { kind: 'tool-registry' }, content: [{ type: 'text', text: 'tools added: watch' }] } })
    captured.listeners.get('agent/status')({ agent, status: 'idle' })
    expect(written).toHaveLength(2)
    expect(written[1]).toContain('HEARD acme/dsh-radar')
    expect(written[1]).not.toContain('README of')
    expect(written[1]).not.toContain('tools added')
  })

  it('indents continuation lines so a multi-line report stays one journal entry', async () => {
    const { ctx, captured, agent, session } = makeCtx()
    apply(ctx, CONFIG)
    await vi.waitFor(() => expect(agent.followup).toHaveBeenCalledTimes(1))
    say(session, 'HEARD two:\nacme/dsh-radar\nbeta/dsh-lantern')
    captured.listeners.get('agent/status')({ agent, status: 'idle' })
    expect(written[1]).toContain('HEARD two:\n  acme/dsh-radar\n  beta/dsh-lantern')
  })

  it('registers no status listener when journalling is off', async () => {
    const { ctx, captured, agent } = makeCtx()
    apply(ctx, { ...CONFIG, journal: false })
    await vi.waitFor(() => expect(agent.followup).toHaveBeenCalledTimes(1))
    expect(captured.listeners.has('agent/status')).toBe(false)
  })
})

describe('degraded hosts', () => {
  it('mounts without starting a session when a core service is missing', async () => {
    const { ctx, captured, agent } = makeCtx({ services: { agents: undefined } })
    apply(ctx, CONFIG)
    await Promise.resolve()
    await Promise.resolve()
    expect(agent.followup).not.toHaveBeenCalled()
    expect(captured.errors).toEqual([])
  })

  it('logs a failed startup instead of taking the process down', async () => {
    const { ctx, captured } = makeCtx({ services: { agents: { create: async () => { throw new Error('no model configured') } } } })
    apply(ctx, CONFIG)
    await vi.waitFor(() => expect(captured.errors.length).toBe(1))
    expect(captured.errors[0]).toContain('no model configured')
  })
})
