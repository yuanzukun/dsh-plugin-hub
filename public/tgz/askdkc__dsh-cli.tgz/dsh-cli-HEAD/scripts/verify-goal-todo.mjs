/**
 * Headless verification of the GoalTodoPanel: renders the compiled component
 * with fake channel data and asserts the visible output. Also simulates the
 * "data arrives later" path (a live channel emits after a goal mutation or
 * todo write) to prove the panel updates without a restart.
 *
 * Run with plain node against the compiled lib (tsx/esbuild is broken under
 * WSL here): `node scripts/verify-goal-todo.mjs`
 */
import { Writable, PassThrough } from 'node:stream'
import React from 'react'
import { render, useInput } from '../lib/types/ui.js'
import { GoalTodoPanel } from '../lib/types/components/GoalTodoPanel.js'
import { AlternateScreen } from '../lib/types/ink/components/AlternateScreen.js'

let failed = 0
function check(name, ok, extra = '') {
  console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}${extra ? `  (${extra})` : ''}`)
  if (!ok) failed += 1
}

const toPlain = s =>
  s
    .replace(/\x1b\[(\d+)C/g, (_, n) => ' '.repeat(Number(n)))
    .replace(/\x1b\[[0-9;?>:]*[a-zA-Z]/g, '')
    .replace(/\x1b\]9;[^\x07]*\x07/g, '')

function makeStreams() {
  const stdout = new Writable({
    write(chunk, _enc, cb) {
      stdout.frames.push(String(chunk))
      cb()
    },
  })
  stdout.columns = 100
  stdout.rows = 30
  stdout.isTTY = true
  stdout.frames = []
  const stderr = new Writable({ write(_c, _e, cb) { cb() } })
  stderr.isTTY = true
  const stdin = new PassThrough()
  stdin.isTTY = true
  stdin.setRawMode = () => stdin
  stdin.setEncoding = () => stdin
  stdin.ref = () => stdin
  stdin.unref = () => stdin
  return { stdout, stderr, stdin }
}

const sleep = ms => new Promise(r => setTimeout(r, ms))

const baseChannel = {
  version: 0,
  rows: [],
  status: 'idle',
  sessionTitle: '',
  agentId: 'a1',
  model: 'm',
  tokens: { input: 0, output: 0 },
  cwd: '.',
  gitBranch: undefined,
  working: false,
  spinnerMode: 'requesting',
  responseChars: 0,
  activeToolCount: 0,
  turnStart: 0,
  lastUserText: '',
  notifications: [],
  contextWindow: undefined,
  reasoningEffort: undefined,
  lastUsage: undefined,
  tps: undefined,
  tpsSamples: [],
  activityFrames: undefined,
  activityEnabled: false,
  contextBarEnabled: true,
  commandList: [],
  contextSegments: { system: 0, prompt: 0, assistant: 0, thinking: 0, tools: 0 },
  subscribe() { return () => {} },
  submit() {},
  cancel() {},
  clear() {},
  notify() {},
  listFiles: async () => [],
  listModels: async () => [],
  runExternalCommand: async () => undefined,
  rewindTo: async () => null,
  resumeTo: async () => ({ ok: true }),
  newSession: async () => true,
  switchModel: async () => true,
  loadOlder: () => 0,
  setActivityFrames: () => true,
  emit() {},
  goal: undefined,
  todos: [],
}

async function run() {
  // Authoritative task states remain distinguishable and visible while idle,
  // including Done/Ignore, with the identity/revision and host-permitted actions.
  for (const status of ['ToDo', 'Working', 'Pending', 'Done', 'Ignore']) {
    const { stdout, stderr, stdin } = makeStreams()
    const channel = { ...baseChannel, todos: [{ source: 'kiokuko', content: 'Canonical task', status,
      taskId: 'task-123', runId: 'task-123', revision: 7, generation: 1,
      ...(status === 'Pending' ? { runStatus: 'failed', previousOutcome: { status: 'interrupted' } } : {}),
      reason: 'Host-confirmed reason', evidence: ['receipt:verified'], allowedOps: ['resume'] }] }
    const instance = await render(React.createElement(GoalTodoPanel, { channel }),
      { stdout, stderr, stdin, exitOnCtrlC: false, patchConsole: false })
    const deadline = Date.now() + 2000
    while (!toPlain(stdout.frames.join('')).includes('/kioku-task resume') && Date.now() < deadline) await sleep(20)
    const frame = toPlain(stdout.frames.join(''))
    check(`canonical ${status} is visible while idle`, frame.includes(`[${status}] Canonical task`))
    check(`${status} shows identity/revision`, frame.includes('task-123 · r7'))
    check(`${status} shows host reason/evidence/actions`, frame.includes('Host-confirmed reason') && frame.includes('receipt:verified') && frame.includes('/kioku-task resume'))
    if (status === 'Pending') check('failed and interrupted execution outcomes remain distinct', frame.includes('Execution: failed') && frame.includes('Previous execution: interrupted'))
    instance.unmount()
  }
  // 1. Empty channel -> nothing rendered.
  {
    const { stdout, stderr, stdin } = makeStreams()
    const instance = await render(
      React.createElement(GoalTodoPanel, { channel: { ...baseChannel } }),
      { stdout, stderr, stdin, exitOnCtrlC: false, patchConsole: false },
    )
    await sleep(500)
    const frame = toPlain(stdout.frames.join(''))
    check('empty channel renders nothing', frame.trim() === '', JSON.stringify(frame))
    instance.unmount()
  }

  // 2. Goal + todos present.
  {
    const { stdout, stderr, stdin } = makeStreams()
    const channel = {
      ...baseChannel,
      working: true,
      goal: {
        id: 'g1',
        revision: 3,
        objective: 'Fix the login page crash',
        phase: 'active',
        maxGoalRounds: 10,
        roundsStarted: 2,
      },
      todos: [
        { content: 'Reproduce the crash', status: 'completed' },
        { content: 'Fix the null deref in auth', status: 'in_progress' },
        { content: 'Add a regression test', status: 'pending' },
      ],
    }
    const instance = await render(
      React.createElement(GoalTodoPanel, { channel }),
      { stdout, stderr, stdin, exitOnCtrlC: false, patchConsole: false },
    )
    await sleep(500)
    const frame = toPlain(stdout.frames.join(''))
    console.log('--- GoalTodoPanel frame ---')
    console.log(JSON.stringify(frame))
    check('objective shown', frame.includes('Fix the login page crash'))
    check('phase badge + rounds shown', /active · 2\/10/.test(frame))
    check('completed todo shown', frame.includes('Reproduce the crash'))
    check('in-progress todo shown', frame.includes('Fix the null deref in auth'))
    check('pending todo shown', frame.includes('Add a regression test'))
    check('no transcript glue (no ❯ prompt)', !frame.includes('❯'))
    instance.unmount()
  }

  // 3. Idle channels drop a snapshot containing only completed work.
  {
    const { stdout, stderr, stdin } = makeStreams()
    const channel = {
      ...baseChannel,
      todos: [
        { content: 'Reproduce the crash', status: 'completed' },
        { content: 'Fix the null deref in auth', status: 'completed' },
      ],
    }
    const instance = await render(
      React.createElement(GoalTodoPanel, { channel }),
      { stdout, stderr, stdin, exitOnCtrlC: false, patchConsole: false },
    )
    await sleep(500)
    const frame = toPlain(stdout.frames.join(''))
    check('idle channel hides an all-completed todo snapshot', frame.trim() === '', JSON.stringify(frame))
    instance.unmount()
  }

  // 4. Idle channels retain unfinished work but drop completed rows.
  {
    const { stdout, stderr, stdin } = makeStreams()
    const channel = {
      ...baseChannel,
      todos: [
        { content: 'Reproduce the crash', status: 'completed' },
        { content: 'Add a regression test', status: 'pending' },
      ],
    }
    const instance = await render(
      React.createElement(GoalTodoPanel, { channel }),
      { stdout, stderr, stdin, exitOnCtrlC: false, patchConsole: false },
    )
    await sleep(500)
    const frame = toPlain(stdout.frames.join(''))
    check('idle channel hides completed todo rows', !frame.includes('Reproduce the crash'))
    check('idle channel keeps unfinished todo rows', frame.includes('Add a regression test'))
    instance.unmount()
  }

  // 5. Blocked goal with reason.
  {
    const { stdout, stderr, stdin } = makeStreams()
    const channel = {
      ...baseChannel,
      goal: {
        id: 'g2',
        revision: 5,
        objective: 'Ship the release',
        phase: 'blocked',
        maxGoalRounds: 5,
        roundsStarted: 4,
        blockedReason: { code: 'stale-deps', message: 'CI is red: dependency update broke the build' },
      },
    }
    const instance = await render(
      React.createElement(GoalTodoPanel, { channel }),
      { stdout, stderr, stdin, exitOnCtrlC: false, patchConsole: false },
    )
    await sleep(500)
    const frame = toPlain(stdout.frames.join(''))
    check('blocked phase shown', /blocked · 4\/5/.test(frame))
    check('block reason shown', frame.includes('CI is red: dependency update broke the build'))
    instance.unmount()
  }

  // 6. Live update: data arrives after mount (simulates a channel.emit from
  //    a goal/change or todo/write event re-rendering the Chat screen).
  {
    const { stdout, stderr, stdin } = makeStreams()
    const channel = { ...baseChannel }
    const App = () => {
      const [, force] = React.useState(0)
      React.useEffect(() => {
        // Simulate the channel mutating + notifying subscribers.
        const t = setTimeout(() => {
          channel.goal = {
            id: 'g3',
            revision: 1,
            objective: 'Polish the panel',
            phase: 'active',
            maxGoalRounds: 3,
            roundsStarted: 0,
          }
          channel.todos = [
            { content: 'Render live', status: 'in_progress' },
            { content: 'Ship it', status: 'pending' },
          ]
          force(n => n + 1)
        }, 500)
        return () => clearTimeout(t)
      }, [])
      return React.createElement(GoalTodoPanel, { channel })
    }
    const instance = await render(React.createElement(App), {
      stdout, stderr, stdin, exitOnCtrlC: false, patchConsole: false,
    })
    await sleep(300)
    const before = toPlain(stdout.frames.join(''))
    check('nothing before data arrives', before.trim() === '', JSON.stringify(before))
    await sleep(600)
    const after = toPlain(stdout.frames.at(-1) ?? '')
    check('panel appears after live update', after.includes('Polish the panel') && after.includes('Render live'), JSON.stringify(after))
    instance.unmount()
  }

  // 7. Collapsed mode (ctrl/cmd+q): the todo section folds to its header
  //    line — counts plus the live-task preview — while the goal card stays.
  {
    const { stdout, stderr, stdin } = makeStreams()
    const channel = {
      ...baseChannel,
      working: true,
      goal: {
        id: 'g4',
        revision: 2,
        objective: 'Fix the login page crash',
        phase: 'active',
        maxGoalRounds: 10,
        roundsStarted: 2,
      },
      todos: [
        { content: 'Reproduce the crash', status: 'completed' },
        { content: 'Fix the null deref in auth', status: 'in_progress' },
        { content: 'Add a regression test', status: 'pending' },
      ],
    }
    const instance = await render(
      React.createElement(GoalTodoPanel, { channel, collapsed: true }),
      { stdout, stderr, stdin, exitOnCtrlC: false, patchConsole: false },
    )
    await sleep(500)
    const frame = toPlain(stdout.frames.join(''))
    check('collapsed keeps the goal card', frame.includes('Fix the login page crash'))
    check('collapsed shows the done/total header', /✓ 1\/3/.test(frame))
    check('collapsed previews the live task', frame.includes('Fix the null deref in auth'))
    check('collapsed hides non-preview todo rows', !frame.includes('Add a regression test'))
    check('collapsed shows the fold marker', frame.includes('▸'))
    instance.unmount()
  }

  // 8. SGR mouse click on the fold header: real stdin bytes → parser →
  //    handleMouseEvent → dispatchClick → onToggle. Wrapped in
  //    <AlternateScreen> like the real Chat screen — dispatchClick is gated
  //    on altScreenActive (clicks need the fixed viewport for hit-testing).
  {
    const { stdout, stderr, stdin } = makeStreams()
    const channel = {
      ...baseChannel,
      todos: [
        { content: 'Fold via click', status: 'in_progress' },
        { content: 'Second row', status: 'pending' },
      ],
    }
    const state = { collapsed: false }
    const App = () => {
      const [, force] = React.useState(0)
      // Enable raw mode so App subscribes to stdin — without a useInput
      // consumer (PromptInput in the real screen), no input flows at all.
      useInput(() => {})
      const panel = React.createElement(GoalTodoPanel, {
        channel,
        collapsed: state.collapsed,
        onToggle: () => {
          state.collapsed = !state.collapsed
          force(n => n + 1)
        },
      })
      return React.createElement(AlternateScreen, null, panel)
    }
    const instance = await render(React.createElement(App), {
      stdout, stderr, stdin, exitOnCtrlC: false, patchConsole: false,
    })
    await sleep(600)
    // Joined frames: ink writes terminal diffs, so the last chunk alone may
    // carry only the changed cells (the alt-screen clear frame, or a partial
    // repaint) — accumulate for presence checks.
    const before = toPlain(stdout.frames.join(''))
    check('expanded before click', before.includes('▾'), JSON.stringify(before))
    // Alt screen starts at row 0; panel paddingTop 1 → fold header on row 1
    // (0-indexed), glyph at col 2. SGR is 1-indexed: press then release.
    stdin.write('\x1b[<0;4;2M')
    await sleep(120)
    stdin.write('\x1b[<0;4;2m')
    await sleep(500)
    const after = toPlain(stdout.frames.join(''))
    check('click on fold header collapses the todo list', after.includes('▸'), JSON.stringify(after))
    check('click fold keeps the summary count', /✓ 0\/2/.test(after), JSON.stringify(after))
    instance.unmount()
  }

  process.exit(failed)
}

run()
