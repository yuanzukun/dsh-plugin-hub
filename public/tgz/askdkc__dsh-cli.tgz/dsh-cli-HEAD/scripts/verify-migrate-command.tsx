/**
 * `/migrate` 交互回归（挂真实 Chat，fake channel + fake stdout/stdin）：
 *   1. **fresh 会话直接入口**：mount 后第一次就输入 `/migrate claude-code`
 *      必须打开确认层——旧实现从 picker 的行缓存里查 agent，缓存为空时
 *      一律报「未知迁移源」，正是 docs/migrate.md 承诺的那个入口；
 *   2. 未知源仍然报未知（不能因为修 1 而放行任意字符串）；
 *   3. `/migrate --dry-run` 明说要源，不再报「未知迁移源 --dry-run」；
 *   4. `/migrate a b` 报 usage，不静默只跑第一个（与 CLI 退出码 2 同语义）；
 *   5. 重开裸 `/migrate` 清空上一轮的勾选（Esc 退出后不得残留 [x]）。
 * 运行：node --import tsx/esm scripts/verify-migrate-command.tsx
 */
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import assert from 'node:assert/strict'
import { settled, viewportLines } from './lib/term-test.mjs'

process.env.FORCE_COLOR = '3'
process.env.DSH_CLI_LANG = 'zh'
// adapter 走 os.homedir()（Windows 读 USERPROFILE）：两个都指到空夹具目录，
// 扫描既不碰真实数据，也保证各源计数为 0、启动提示检测无信号。grok-build 还
// 认 GROK_HOME，一并钉到夹具下的 .grok（否则挂载后的活动检测会扫真实会话库）。
const fixtureHome = mkdtempSync(join(tmpdir(), 'verify-migrate-command-'))
process.env.HOME = fixtureHome
process.env.USERPROFILE = fixtureHome
process.env.GROK_HOME = join(fixtureHome, '.grok')

const [{ PassThrough, Writable }, React, { render }, { Chat }, { QuestionStore }, { LOCAL_COMMANDS }, { Terminal }] = await Promise.all([
  import('node:stream'),
  import('react'),
  import('../src/ui.js'),
  import('../src/screens/Chat.js'),
  import('../src/dsh-adapter/questions.js'),
  import('../src/commands.js'),
  import('@xterm/headless'),
])

class FakeStdout extends Writable {
  columns = 100
  rows = 28
  isTTY = true
  frames: string[] = []
  terminal = new Terminal({ cols: this.columns, rows: this.rows, scrollback: 100, allowProposedApi: true })
  screen = () => viewportLines(this.terminal).join('\n')
  _write(chunk: unknown, _encoding: BufferEncoding, callback: () => void) {
    this.frames.push(String(chunk))
    this.terminal.write(String(chunk), callback)
  }
}

class FakeStderr extends Writable {
  isTTY = true
  _write(_chunk: unknown, _encoding: BufferEncoding, callback: () => void) {
    callback()
  }
}

class FakeStdin extends PassThrough {
  isTTY = true
  setRawMode() {
    return this
  }
  ref() {
    return this
  }
  unref() {
    return this
  }
}

const plainText = (frames: readonly string[]) => frames
  .join('')
  .replace(/\x1b\[(\d+)C/g, (_, n) => ' '.repeat(Number(n)))
  .replace(/\x1b\[[0-9;?]*[a-zA-Z]/g, '')
  .replace(/\x1b\]9;[^\x07]*\x07/g, '')

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms))
const ESC = '\u001b'

let failures = 0
function check(name: string, ok: boolean, extra = ''): void {
  if (ok) console.log(`  ✓ ${name}`)
  else {
    failures++
    console.error(`  ✗ ${name}${extra ? `  (${extra})` : ''}`)
  }
}

/** Fake channel in smoke.tsx's shape: Chat reads a wide surface, so the stub
 *  carries the fields it renders plus the calls these assertions observe. */
function makeChannel() {
  return {
    version: 0,
    whaleIdle: false,
    rows: [],
    status: 'idle' as const,
    sessionTitle: 'probe',
    agentId: 'probe',
    model: 'deepseek-v4-flash',
    provider: 'deepseek',
    tokens: { input: 0, output: 0 },
    cwd: 'C:/code/demo-project',
    displayCwd: 'C:/code/demo-project',
    gitBranch: 'main',
    working: false,
    spinnerMode: 'requesting' as const,
    mode: { plan: false },
    responseChars: 0,
    activeToolCount: 0,
    turnStart: 0,
    lastUserText: '',
    pending: [],
    commandList: LOCAL_COMMANDS,
    commandCompletions: () => [],
    notifications: [],
    contextSegments: { system: 0, prompt: 0, assistant: 0, thinking: 0, tools: 0 },
    subscribe: () => () => {},
    submitCalls: [] as string[],
    notifyCalls: [] as string[],
    localRows: [] as string[][],
    submit(text: string) { this.submitCalls.push(text) },
    steer() {},
    cancel() {},
    clear() {},
    notify(text: string) { this.notifyCalls.push(text) },
    pushLocal(_command: string, lines: readonly string[]) { this.localRows.push([...lines]) },
    listModels: () => Promise.resolve([]),
    listSessions: () => [],
    setResumeTarget: () => {},
  }
}

type FakeChannel = ReturnType<typeof makeChannel>

/** One mounted Chat, torn down by the caller. `run` types a line and settles. */
async function mountChat(): Promise<{
  channel: FakeChannel
  stdout: FakeStdout
  stdin: FakeStdin
  run: (line: string) => Promise<string>
  keys: (sequence: readonly string[]) => Promise<void>
  mark: () => number
  since: (mark: number) => string
  unmount: () => Promise<void>
}> {
  const channel = makeChannel()
  const stdout = new FakeStdout()
  const stdin = new FakeStdin()
  const instance = await render(
    <Chat channel={channel as never} questionStore={new QuestionStore()} />,
    { stdout, stdin, stderr: new FakeStderr(), exitOnCtrlC: false, patchConsole: false },
  )
  await delay(400)
  return {
    channel,
    stdout,
    stdin,
    mark: () => stdout.frames.length,
    since: m => plainText(stdout.frames.slice(m)),
    run: async (line: string) => {
      const from = stdout.frames.length
      stdin.write(line)
      await delay(120)
      stdin.write('\r')
      await delay(700)
      return plainText(stdout.frames.slice(from))
    },
    keys: async (sequence: readonly string[]) => {
      for (const key of sequence) {
        stdin.write(key)
        await delay(220)
      }
    },
    unmount: async () => { await instance.unmount(); stdout.terminal.dispose() },
  }
}

const CONFIRM_TITLE = '确认导入'
const PICKER_TITLE = '迁移哪个代理的对话？'
const UNKNOWN = '未知迁移源'

// ── 1. fresh 会话的 /migrate <agent>（本回归的存在理由）──────────────────
{
  const chat = await mountChat()
  const after = await chat.run('/migrate claude-code')
  const unknown = chat.channel.notifyCalls.filter(text => text.includes(UNKNOWN))
  check('1a. fresh mount 直接 /migrate claude-code 不报未知源', unknown.length === 0, unknown.join(' | '))
  check('1b. 打开二次确认层', after.includes(CONFIRM_TITLE))
  check('1c. 不误开选择器', !after.includes(PICKER_TITLE))
  await chat.unmount()
}

// ── 2. 未知源仍然被拒 ──────────────────────────────────────────────────
{
  const chat = await mountChat()
  const after = await chat.run('/migrate not-an-agent')
  check('2a. 未知源报未知迁移源', chat.channel.notifyCalls.some(text => text.includes(UNKNOWN)))
  check('2b. 不打开确认层', !after.includes(CONFIRM_TITLE))
  await chat.unmount()
}

// ── 3. --dry-run 的语义 ────────────────────────────────────────────────
{
  const chat = await mountChat()
  const after = await chat.run('/migrate --dry-run')
  check('3a. 裸 --dry-run 提示要指明源（不再报“未知迁移源 --dry-run”）',
    chat.channel.notifyCalls.some(text => text.includes('指明要预览的源'))
    && !chat.channel.notifyCalls.some(text => text.includes(UNKNOWN)),
    chat.channel.notifyCalls.join(' | '))
  check('3b. 不打开确认层', !after.includes(CONFIRM_TITLE))
  await chat.unmount()
}

// ── 4. 多参数（与 CLI 的 usage 退出码 2 同语义）────────────────────────
{
  const chat = await mountChat()
  const after = await chat.run('/migrate claude-code codex')
  check('4a. 两个源报 usage',
    chat.channel.notifyCalls.some(text => text.includes('一次只能迁移一个源')),
    chat.channel.notifyCalls.join(' | '))
  check('4b. 不打开确认层', !after.includes(CONFIRM_TITLE))
  await chat.unmount()
}

// ── 5. 重开 picker 清空上一轮勾选 ──────────────────────────────────────
{
  const chat = await mountChat()
  await chat.run('/migrate')
  await chat.keys([' ', ESC])
  const mark = chat.mark()
  await chat.run('/migrate')
  const reopened = chat.since(mark)
  check('5a. 重开渲染出源行（行缓存不是空态）', reopened.includes('Claude Code'))
  check('5b. 重开 picker 不残留上一轮勾选', !reopened.includes('[x]'), reopened.replace(/\s+/gu, ' ').slice(0, 120))
  await chat.unmount()
}

// ── 6. direct 入口的确认层 Esc 回 picker：勾选必须与确认内容一致 ────────
// 空夹具家目录下没有近期活动 → 行序＝注册表序（claude-code, codex, …），
// 所以「↓ + 空格」勾的是 Codex。随后 `/migrate claude-code` 的确认层说的是
// claude-code；Esc 回 picker 时若还挂着 Codex 的勾，用户看到的与刚确认的就
// 不是同一件事（Enter 会导入 Codex）。direct 分支因此把勾选钉成该单源——
// 断言按下 Enter 后确认层列的到底是哪个源（行为，而非渲染细节）。
{
  const chat = await mountChat()
  const screen = chat.stdout.screen
  // Wait for each observable transition before the next key. A fixed pause
  // can expire before the lone-Esc parser timer on a busy CI runner, letting
  // the following Enter act on the confirmation instead of the picker.
  try {
    await chat.run('/migrate')
    assert.ok(await settled(() => screen().includes('[ ] Codex')), 'initial picker ready')
    chat.stdin.write('\u001b[B')
    assert.ok(await settled(() => screen().includes('❯ [ ] Codex')), 'Codex focused')
    chat.stdin.write(' ')
    assert.ok(await settled(() => screen().includes('[x] Codex')), 'Codex checked')
    chat.stdin.write(ESC)
    assert.ok(await settled(() => !screen().includes(PICKER_TITLE)), 'picker closed')
    await chat.run('/migrate claude-code')
    assert.ok(await settled(() => screen().includes(CONFIRM_TITLE)), 'direct confirmation ready')
    chat.stdin.write(ESC)
    assert.ok(await settled(() => screen().includes(PICKER_TITLE) && screen().includes('[x] Claude Code')
      && !screen().includes(CONFIRM_TITLE)), 'returned picker preserves Claude selection')
    chat.stdin.write('\r')
    check('6a. Esc 回 picker 后 Enter 导入的是刚确认的那个源',
      await settled(() => screen().includes(CONFIRM_TITLE) && screen().includes('Claude Code')), screen())
    check('6b. 早先勾的 Codex 不再残留', !screen().includes('Codex'), screen())
    assert.equal(chat.channel.localRows.length, 0, 'confirmation must not start the import')
  } finally {
    await chat.unmount()
  }
}

rmSync(fixtureHome, { recursive: true, force: true })
if (failures > 0) {
  console.error(`/migrate 交互回归 FAILED（${failures} 项）`)
  process.exitCode = 1
} else {
  console.log('/migrate 交互回归 passed')
}
