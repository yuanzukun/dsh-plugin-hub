/**
 * Pure-function verification for the /update machinery (real compiled lib,
 * no network, no child processes):
 *
 * - installedCliVersion() finds the version in both the compiled-package
 *   layout and the source-checkout layout, and prefers a matching manifest
 *   over a foreign one at the nearer level
 * - resolveRegistryBase() honors NPM_CONFIG_REGISTRY (both spellings), the
 *   user ~/.npmrc `registry=` line, and falls back to npmjs.org
 * - isVersionNewer() requires a strictly greater valid semver
 * - update command args pin the preflight target version, with --latest as the
 *   fallback when preflight could not resolve one
 * - isBootDeadlockTarget() flags exactly the 0.7.0–0.7.1 hard-inject range
 * - DSH_CLI_UPDATED_FROM is stamped from the pre-update version: the stamp
 *   read happens before the first installer child runs and the restart env
 *   reuses that captured value (issue #307's new-vs-new false alarm)
 * - isEexistTmpRenameFailure() classifies the deterministic Linux rename
 *   collision (issue #479) — recovery territory, never a plain retry — and
 *   removeStalePackageInstall() clears the stale package dir plus leftover
 *   `_tmp_` staging dirs without traversing a junction/symlink
 * - the /update restart tail reuses the hardened restartCli handoff
 *   (issues #284/#307/#483) with kind: 'update'
 *
 * Run: node scripts/verify-update.mjs
 */
import { chmodSync, cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

let failed = 0
function check(name, ok, extra = '') {
  console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}${extra ? `  (${extra})` : ''}`)
  if (!ok) failed += 1
}

const {
  installedCliVersion,
  resolveRegistryBase,
  isVersionNewer,
  isBootDeadlockTarget,
  resolveDshProfileName,
  shellQuote,
  cliUpdatePluginArgs,
  isTransientUpdateFailure,
  isEexistTmpRenameFailure,
  profilePackageDir,
  removeStalePackageInstall,
  ensureProfileAllowBuilds,
  ensureProfileReleaseAgeExclude,
  sharpCurrentSuffix,
  ignoredSharpOptionalPatterns,
  ensureProfileSharpPlatformFilter,
  detectLibc,
  profileWorkspaceYamlPath,
  isStandaloneRuntime,
  getStandaloneBinaryPath,
  getStandaloneAssetName,
} = await import('../lib/types/update.js')
const compiledModulePath = fileURLToPath(new URL('../lib/types/update.js', import.meta.url))
const compiledShellQuotePath = fileURLToPath(new URL('../lib/types/utils/shellQuote.js', import.meta.url))
const compiledPathsPath = fileURLToPath(new URL('../lib/types/utils/paths.js', import.meta.url))
const repoRoot = fileURLToPath(new URL('..', import.meta.url))

/**
 * Mirror compiled update module and its dependencies into a scratch directory.
 *
 * @param {string} dstDir - Destination directory to receive the modules.
 */
function copyUpdateModule(dstDir) {
  mkdirSync(join(dstDir, 'utils'), { recursive: true })
  cpSync(compiledModulePath, join(dstDir, 'update.js'))
  cpSync(join(repoRoot, 'lib/types/package-version.js'), join(dstDir, 'package-version.js'))
  cpSync(compiledShellQuotePath, join(dstDir, 'utils', 'shellQuote.js'))
  cpSync(compiledPathsPath, join(dstDir, 'utils', 'paths.js'))
}

// ---- installedCliVersion: compiled layout is this module's own real layout
const compiled = installedCliVersion()
check(
  'installedCliVersion returns this package version',
  compiled !== undefined && /^\d+\.\d+\.\d+/.test(compiled),
  `got ${compiled}`,
)

const scratch = mkdtempSync(join(tmpdir(), 'verify-update-'))
try {
  // The copied module imports `semver`; point its root at this repo's deps.
  symlinkSync(join(repoRoot, 'node_modules'), join(scratch, 'node_modules'), process.platform === 'win32' ? 'junction' : 'dir')

  // Source-checkout layout: <root>/package.json + module under <root>/src/.
  // ../../package.json lands above the root (missing) → ../package.json hits.
  const sourceRoot = join(scratch, 'source')
  copyUpdateModule(join(sourceRoot, 'src'))
  writeFileSync(join(sourceRoot, 'package.json'), JSON.stringify({ name: '@askdkc/dsh-cli', version: '1.2.3', type: 'module' }))
  const sourceMod = await import(`${pathToFileURL(join(sourceRoot, 'src', 'update.js'))}?probe=1`)
  check(
    'installedCliVersion reads the source-checkout layout',
    sourceMod.installedCliVersion() === '1.2.3',
    `got ${sourceMod.installedCliVersion()}`,
  )

  // Compiled layout with a foreign manifest at the near level: the root
  // manifest must win over a nearer foreign one.
  const pkgRoot = join(scratch, 'pkg')
  copyUpdateModule(join(pkgRoot, 'lib', 'types'))
  writeFileSync(join(pkgRoot, 'package.json'), JSON.stringify({ name: '@askdkc/dsh-cli', version: '0.9.9', type: 'module' }))
  writeFileSync(join(pkgRoot, 'lib', 'package.json'), JSON.stringify({ name: 'other-pkg', version: '9.9.9' }))
  const pkgMod = await import(`${pathToFileURL(join(pkgRoot, 'lib', 'types', 'update.js'))}?probe=2`)
  check(
    'installedCliVersion prefers the matching root manifest over a foreign near one',
    pkgMod.installedCliVersion() === '0.9.9',
    `got ${pkgMod.installedCliVersion()}`,
  )

  // A foreign name at BOTH levels must yield undefined, never a version.
  const foreignRoot = join(scratch, 'foreign')
  copyUpdateModule(join(foreignRoot, 'lib', 'types'))
  writeFileSync(join(foreignRoot, 'package.json'), JSON.stringify({ name: 'other-pkg', version: '9.9.9' }))
  writeFileSync(join(foreignRoot, 'lib', 'package.json'), JSON.stringify({ name: 'third-pkg', version: '8.8.8' }))
  const foreignMod = await import(`${pathToFileURL(join(foreignRoot, 'lib', 'types', 'update.js'))}?probe=3`)
  check(
    'installedCliVersion rejects foreign manifests entirely',
    foreignMod.installedCliVersion() === undefined,
    `got ${foreignMod.installedCliVersion()}`,
  )
} finally {
  rmSync(scratch, { recursive: true, force: true })
}

// ---- resolveRegistryBase: env (both spellings) over npmrc over default
const HOME_BACKUP = process.env.HOME
const USERPROFILE_BACKUP = process.env.USERPROFILE
const scratch2 = mkdtempSync(join(tmpdir(), 'verify-update2-'))
try {
  writeFileSync(join(scratch2, '.npmrc'), 'registry=https://mirror.example.com/\n')

  delete process.env.NPM_CONFIG_REGISTRY
  delete process.env.npm_config_registry
  process.env.HOME = scratch2
  process.env.USERPROFILE = scratch2
  check(
    'resolveRegistryBase reads ~/.npmrc',
    resolveRegistryBase() === 'https://mirror.example.com',
    `got ${resolveRegistryBase()}`,
  )

  process.env.NPM_CONFIG_REGISTRY = 'https://env-registry.example.com/'
  check(
    'resolveRegistryBase prefers NPM_CONFIG_REGISTRY (upper)',
    resolveRegistryBase() === 'https://env-registry.example.com',
    `got ${resolveRegistryBase()}`,
  )

  delete process.env.NPM_CONFIG_REGISTRY
  process.env.npm_config_registry = 'https://lower-registry.example.com'
  check(
    'resolveRegistryBase honors npm_config_registry (lower)',
    resolveRegistryBase() === 'https://lower-registry.example.com',
    `got ${resolveRegistryBase()}`,
  )

  delete process.env.npm_config_registry
  // Default applies only with no env AND no readable user .npmrc.
  const emptyHome = mkdtempSync(join(tmpdir(), 'verify-update3-'))
  try {
    process.env.HOME = emptyHome
    process.env.USERPROFILE = emptyHome
    check(
      'resolveRegistryBase defaults to npmjs.org',
      resolveRegistryBase() === 'https://registry.npmjs.org',
      `got ${resolveRegistryBase()}`,
    )
  } finally {
    rmSync(emptyHome, { recursive: true, force: true })
  }
} finally {
  if (HOME_BACKUP === undefined) delete process.env.HOME
  else process.env.HOME = HOME_BACKUP
  if (USERPROFILE_BACKUP === undefined) delete process.env.USERPROFILE
  else process.env.USERPROFILE = USERPROFILE_BACKUP
  rmSync(scratch2, { recursive: true, force: true })
}

// ---- isVersionNewer
check('isVersionNewer: newer major wins', isVersionNewer('1.0.0', '0.4.1'))
check('isVersionNewer: newer minor wins', isVersionNewer('0.5.0', '0.4.1'))
check('isVersionNewer: same version is not newer', !isVersionNewer('0.4.1', '0.4.1'))
check('isVersionNewer: older is not newer', !isVersionNewer('0.4.0', '0.4.1'))
check('isVersionNewer: invalid input is not newer', !isVersionNewer('banana', '0.4.1'))

// ---- resolveDshProfileName: the profile /update must act on
check(
  'profile: --profile value is read',
  resolveDshProfileName(['node', 'dsh', '--profile', 'my-tui']) === 'my-tui',
)
check(
  'profile: --profile=name form is read',
  resolveDshProfileName(['node', 'dsh', '--profile=my-tui', '--resume', 'abc']) === 'my-tui',
)
check(
  'profile: missing value yields undefined',
  resolveDshProfileName(['node', 'dsh', '--profile']) === undefined,
)
check(
  'profile: no launcher flags yields undefined (source mode)',
  resolveDshProfileName(['node', 'scripts/run.ts']) === undefined,
)
check(
  'profile: inner app args do not shadow the launcher flag',
  resolveDshProfileName(['node', 'dsh', '--profile', 'dsh-cli', '--resume', 'sid', '--model', 'x']) === 'dsh-cli',
)

// ---- shellQuote: cmd.exe safety for the .cmd path (P1 companion)
check(
  'shellQuote: plain tokens pass through',
  shellQuote(['plugin', '--profile', 'dsh-cli']).join(' ') === 'plugin --profile dsh-cli',
)
check(
  'shellQuote: spaces get quoted',
  shellQuote(['C:\\Program Files\\nodejs\\node.exe']).join(' ') === '"C:\\Program Files\\nodejs\\node.exe"',
)
check(
  'shellQuote: embedded quotes are doubled',
  shellQuote(['a"b c']).join(' ') === '"a""b c"',
)

// ---- pnpm args reuse the preflight result instead of resolving latest twice
const exactUpdateArgs = cliUpdatePluginArgs('dsh-cli', '0.7.2')
check(
  'update command pins the preflight target version',
  JSON.stringify(exactUpdateArgs) === JSON.stringify([
    'plugin', '--profile', 'dsh-cli', 'update', '@askdkc/dsh-cli@0.7.2',
  ]),
  `got ${JSON.stringify(exactUpdateArgs)}`,
)
const fallbackUpdateArgs = cliUpdatePluginArgs('custom-profile')
check(
  'update command falls back to --latest when preflight failed',
  JSON.stringify(fallbackUpdateArgs) === JSON.stringify([
    'plugin', '--profile', 'custom-profile', 'update', '--latest', '@askdkc/dsh-cli',
  ]),
  `got ${JSON.stringify(fallbackUpdateArgs)}`,
)

// ---- pnpm allowBuilds pre-seed: pnpm ≥11 kills installs whose tree carries
// un-allowlisted build scripts (ERR_PNPM_IGNORED_BUILDS); the update flow
// must seed the profile workspace with explicit `false` entries first.
{
  const DSH_HOME_BACKUP = process.env.DSH_HOME
  const allowScratch = mkdtempSync(join(tmpdir(), 'verify-allowbuilds-'))
  const profileRoot = join(allowScratch, 'profiles', 'tui')
  try {
    process.env.DSH_HOME = allowScratch
    mkdirSync(profileRoot, { recursive: true })
    const yamlPath = profileWorkspaceYamlPath('tui')

    // Case 1: no workspace file yet → created with all four entries.
    let outcome = ensureProfileAllowBuilds('tui')
    check(
      'allowBuilds: missing file is created with all entries',
      outcome !== undefined && outcome.added.length === 4 && existsSync(yamlPath),
      JSON.stringify(outcome),
    )
    let text = readFileSync(yamlPath, 'utf8')
    check(
      'allowBuilds: file contains the four false entries',
      /'@google\/genai': false/u.test(text) && /esbuild: false/u.test(text) &&
        /koffi: false/u.test(text) && /protobufjs: false/u.test(text),
      text,
    )

    // Case 2: idempotent — a second run adds nothing and leaves the file alone.
    const before = readFileSync(yamlPath, 'utf8')
    outcome = ensureProfileAllowBuilds('tui')
    check(
      'allowBuilds: second run is a no-op',
      outcome !== undefined && outcome.added.length === 0 && readFileSync(yamlPath, 'utf8') === before,
      JSON.stringify(outcome),
    )

    // Case 3: an existing file without an allowBuilds block keeps its content.
    const legacyYaml = join(profileRoot, 'pnpm-workspace.yaml')
    writeFileSync(legacyYaml, 'packages:\n  - .\n\nnodeLinker: hoisted\n')
    outcome = ensureProfileAllowBuilds('tui')
    text = readFileSync(legacyYaml, 'utf8')
    check(
      'allowBuilds: block appended, existing keys preserved',
      outcome !== undefined && outcome.added.length === 4 &&
        text.startsWith('packages:\n  - .\n\nnodeLinker: hoisted\n') &&
        text.includes('allowBuilds:') && /protobufjs: false/u.test(text),
      text,
    )

    // Case 4: a partial block is completed without touching existing entries
    // (an explicit user `true`/`false` decision wins).
    writeFileSync(legacyYaml, "allowBuilds:\n  '@google/genai': true\n  esbuild: false\n")
    outcome = ensureProfileAllowBuilds('tui')
    text = readFileSync(legacyYaml, 'utf8')
    check(
      'allowBuilds: missing entries appended, existing values untouched',
      outcome !== undefined && outcome.added.length === 2 &&
        outcome.existing.includes('@google/genai') && outcome.existing.includes('esbuild') &&
        /'@google\/genai': true/u.test(text) && /koffi: false/u.test(text) && /protobufjs: false/u.test(text),
      `${JSON.stringify(outcome)} :: ${text}`,
    )

    // Case 5: entries in the middle of the file (other top-level keys after
    // the block) still insert inside the block, after existing entries.
    writeFileSync(legacyYaml, 'packages: []\nallowBuilds:\n  esbuild: false\nminimumReleaseAgeExclude:\n  - x@1.0.0\n')
    outcome = ensureProfileAllowBuilds('tui')
    text = readFileSync(legacyYaml, 'utf8')
    check(
      'allowBuilds: insertion stays inside the block before later keys',
      outcome !== undefined && outcome.added.length === 3 &&
        /allowBuilds:\n  esbuild: false\n  '@google\/genai': false\n  koffi: false\n  protobufjs: false\nminimumReleaseAgeExclude:/u.test(text),
      text,
    )

    // Case 6: missing profile directory → undefined, nothing written.
    outcome = ensureProfileAllowBuilds('missing-profile')
    check(
      'allowBuilds: absent profile directory yields undefined',
      outcome === undefined,
      JSON.stringify(outcome),
    )
  } finally {
    if (DSH_HOME_BACKUP === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = DSH_HOME_BACKUP
    rmSync(allowScratch, { recursive: true, force: true })
  }
}

// ---- pnpm minimumReleaseAgeExclude pre-seed: pnpm ≥11 delays installs of
// packages published within minimumReleaseAge (24h default) — on release day
// that gate refuses the exact version /update pins, so the update flow must
// exempt this package at the exact target before pnpm runs.
{
  const DSH_HOME_BACKUP = process.env.DSH_HOME
  const ageScratch = mkdtempSync(join(tmpdir(), 'verify-releaseage-'))
  const profileRoot = join(ageScratch, 'profiles', 'tui')
  try {
    process.env.DSH_HOME = ageScratch
    mkdirSync(profileRoot, { recursive: true })
    const yamlPath = profileWorkspaceYamlPath('tui')

    // Case 1: no workspace file yet → created with the exact-version entry.
    let outcome = ensureProfileReleaseAgeExclude('tui', '0.10.0-beta.1')
    check(
      'releaseAge: missing file is created with the exact entry',
      outcome !== undefined && outcome.changed === true &&
        outcome.entries.length === 1 &&
        outcome.entries[0] === '@askdkc/dsh-cli@0.10.0-beta.1' &&
        existsSync(yamlPath),
      JSON.stringify(outcome),
    )
    let text = readFileSync(yamlPath, 'utf8')
    check(
      'releaseAge: file carries the quoted list entry',
      /minimumReleaseAgeExclude:\n  - '@askdkc\/dsh-cli@0\.10\.0-beta\.1'\n/u.test(text),
      text,
    )

    // Case 2: idempotent — the same version again changes nothing.
    const before = readFileSync(yamlPath, 'utf8')
    outcome = ensureProfileReleaseAgeExclude('tui', '0.10.0-beta.1')
    check(
      'releaseAge: second run for the same version is a no-op',
      outcome !== undefined && outcome.changed === false && readFileSync(yamlPath, 'utf8') === before,
      JSON.stringify(outcome),
    )

    // Case 3: a stale entry for this package is replaced (no accumulation)
    // while foreign entries survive.
    writeFileSync(yamlPath, "minimumReleaseAgeExclude:\n  - 'x@1.0.0'\n  - '@askdkc/dsh-cli@0.9.3'\n")
    outcome = ensureProfileReleaseAgeExclude('tui', '0.10.0-beta.1')
    text = readFileSync(yamlPath, 'utf8')
    check(
      'releaseAge: stale own entry replaced, foreign entry kept',
      outcome !== undefined && outcome.changed === true &&
        text.includes("- 'x@1.0.0'") &&
        text.includes("- '@askdkc/dsh-cli@0.10.0-beta.1'") &&
        !text.includes('0.9.3'),
      `${JSON.stringify(outcome)} :: ${text}`,
    )

    // Case 4: a file without the block keeps its content and gains one.
    writeFileSync(yamlPath, 'packages:\n  - .\n\nnodeLinker: hoisted\n')
    outcome = ensureProfileReleaseAgeExclude('tui', '1.2.3')
    text = readFileSync(yamlPath, 'utf8')
    check(
      'releaseAge: block appended, existing keys preserved',
      outcome !== undefined && outcome.changed === true &&
        text.startsWith('packages:\n  - .\n\nnodeLinker: hoisted\n') &&
        text.includes("minimumReleaseAgeExclude:\n  - '@askdkc/dsh-cli@1.2.3'\n"),
      text,
    )

    // Case 5: absent profile directory → undefined, nothing written.
    outcome = ensureProfileReleaseAgeExclude('missing-profile', '1.2.3')
    check(
      'releaseAge: absent profile directory yields undefined',
      outcome === undefined,
      JSON.stringify(outcome),
    )
  } finally {
    if (DSH_HOME_BACKUP === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = DSH_HOME_BACKUP
    rmSync(ageScratch, { recursive: true, force: true })
  }
}

// ---- isBootDeadlockTarget: the 0.7.0–0.7.1 hard-inject range only
check('deadlock: 0.7.0 is refused', isBootDeadlockTarget('0.7.0'))
check('deadlock: 0.7.1 is refused', isBootDeadlockTarget('0.7.1'))
check('deadlock: 0.6.1 predates the inject and is fine', !isBootDeadlockTarget('0.6.1'))
check('deadlock: 0.7.2 dropped the hard inject', !isBootDeadlockTarget('0.7.2'))
check('deadlock: 0.8.0 is fine', !isBootDeadlockTarget('0.8.0'))
check('deadlock: invalid input is never a deadlock target', !isBootDeadlockTarget('banana'))

const compiledSource = readFileSync(compiledModulePath, 'utf8')
// P1: the node restart must NOT go through a shell — assert the compiled
// restart spawn call has no shell option while the dsh call does. The
// restart spawn now lives inside restartCli() (shared by /restart and the
// /update restart tail); the dsh calls live in updateCliAndRestart().
const dshSpawn = compiledSource.indexOf('runProcess(dsh')
const nodeSpawn = compiledSource.indexOf('spawn(process.execPath')
const dshSegment = compiledSource.slice(dshSpawn, nodeSpawn)
const nodeSegment = compiledSource.slice(nodeSpawn)
check(
  'P1: dsh.cmd spawn requests a shell',
  /\{\s*shell:\s*true[,\s}]/.test(dshSegment),
)
check(
  'P1: node restart spawn has no shell (space-safe exec path)',
  !/shell/.test(nodeSegment.replace(/shellQuote/g, '')),
)

// ---- DSH_CLI_UPDATED_FROM stamping (issue #307): the pre-update version is
// captured before the installer child runs and reused in the restart env —
// a post-update read already sees the replaced manifest (new-vs-new).
const stampRead = compiledSource.indexOf('const updatedFrom = installedCliVersion()')
check(
  'stamp: pre-update version is captured before the installer runs',
  stampRead !== -1 && stampRead < dshSpawn,
)
const stampEnvUse = compiledSource.indexOf('[UPDATED_FROM_ENV]: updatedFrom')
check(
  'stamp: restart env reuses the captured value, not a fresh read',
  stampEnvUse !== -1 && stampEnvUse > dshSpawn,
)
// The --latest fallback (preflight failed) can also land on the deadlock
// range on a stale mirror: the post-install guard must refuse a restart
// into a version that JUST moved into 0.7.0–0.7.1. Three occurrences = the
// export + the post-install guard in updateCli + the CLI preflight refusal
// in cliUpdate — a plain count would pass with the guard deleted, so pin
// the guard's own call shape too.
check(
  'deadlock: post-install guard refuses a fresh landing on the range',
  (compiledSource.match(/isBootDeadlockTarget/g) ?? []).length >= 3
    && /installedNow !== updatedFrom && isBootDeadlockTarget\(installedNow\)/.test(compiledSource),
)

// ---- launcher bridge (0.8.3): the compiled runtime must keep the
// post-/update launcher-alignment hints — static contract against the built
// output so future refactors cannot silently drop the bridge.
const compiledPluginPath = join(repoRoot, 'lib', 'types', 'dsh-adapter', 'plugin.js')
const compiledPluginSource = readFileSync(compiledPluginPath, 'utf8')
check(
  'launcher bridge: runtime reads the launcher version marker',
  compiledPluginSource.includes('DSH_CLI_LAUNCHER_VERSION'),
)
check(
  'launcher bridge: old-launcher update path keeps a generic alignment hint',
  compiledPluginSource.includes('update-launcher-align-unknown'),
)
check(
  'launcher bridge: known older launcher gets a directional hint',
  compiledPluginSource.includes('update-launcher-outdated'),
)

// ---- isTransientUpdateFailure: the Windows tmp-rename race (issue #225)
check(
  'transient: pnpm tmp-rename ENOENT qualifies',
  isTransientUpdateFailure(
    "[ERR_PNPM_ENOENT] [importPackage D:\\p\\node_modules\\dsh-cli] ENOENT: no such file or directory, scandir 'D:\\p\\node_modules\\dsh-cli_tmp_40044_1\\node_modules'",
  ),
)
check(
  'transient: EPERM rename on a tmp staging dir qualifies',
  isTransientUpdateFailure('EPERM: operation not permitted, rename D:\\p\\dsh-cli_tmp_123_4'),
)
check(
  'transient: plain resolution ENOENT without tmp token does not qualify',
  !isTransientUpdateFailure('ENOENT: no such file or directory, open /home/u/package.json'),
)
check(
  'transient: registry 404 does not qualify',
  !isTransientUpdateFailure('ERR_PNPM_FETCH_404 GET https://registry.npmjs.org/x: Not Found - 404'),
)
check(
  'transient: empty output does not qualify',
  !isTransientUpdateFailure(''),
)

// ---- isEexistTmpRenameFailure: the deterministic Linux flavor (issue #479)
const eexistSample =
  "ERR_PNPM_EEXIST  EEXIST: file already exists, rename " +
  "'/root/.dsh/profiles/dsh-cli/node_modules/@askdkc/dsh-cli/node_modules' " +
  "-> '/root/.dsh/profiles/dsh-cli/node_modules/@askdkc/dsh-cli_tmp_2424672_1/node_modules'"
check(
  'eexist: pnpm tmp-rename EEXIST qualifies (#479 verbatim stderr)',
  isEexistTmpRenameFailure(eexistSample),
)
check(
  'eexist: EEXIST without the tmp token does not qualify',
  !isEexistTmpRenameFailure('EEXIST: file already exists, mkdir /root/.cache/pnpm'),
)
check(
  'eexist: transient ENOENT is not the EEXIST flavor',
  !isEexistTmpRenameFailure("[ERR_PNPM_ENOENT] [importPackage] ENOENT: scandir 'D:\\p\\dsh-cli_tmp_40044_1\\node_modules'"),
)
check(
  'transient: EEXIST is NOT plain-retry transient (needs stale-install recovery, #479)',
  !isTransientUpdateFailure(eexistSample),
)

// ---- profilePackageDir: where the recovery path clears a stale install
const DSH_HOME_BACKUP = process.env.DSH_HOME
const staleSandbox = mkdtempSync(join(tmpdir(), 'verify-update-stale-'))
try {
  const sandboxRoot = join(staleSandbox, 'dsh-root')
  process.env.DSH_HOME = sandboxRoot
  check(
    'profilePackageDir: DSH_HOME root wins',
    profilePackageDir('dsh-cli') === join(sandboxRoot, 'profiles', 'dsh-cli', 'node_modules', '@askdkc', 'dsh-cli'),
    `got ${profilePackageDir('dsh-cli')}`,
  )
  delete process.env.DSH_HOME
  check(
    'profilePackageDir: defaults to ~/.dsh',
    profilePackageDir('custom') === join(homedir(), '.dsh', 'profiles', 'custom', 'node_modules', '@askdkc', 'dsh-cli'),
    `got ${profilePackageDir('custom')}`,
  )
  process.env.DSH_HOME = sandboxRoot

  // ---- removeStalePackageInstall: clears the package dir + tmp staging dirs
  const scope = join(sandboxRoot, 'profiles', 'dsh-cli', 'node_modules', '@askdkc')
  const pkgDir = join(scope, 'dsh-cli')
  mkdirSync(join(pkgDir, 'lib'), { recursive: true })
  writeFileSync(join(pkgDir, 'lib', 'marker.txt'), 'stale install')
  mkdirSync(join(scope, 'dsh-cli_tmp_2424672_1'))
  writeFileSync(join(scope, 'dsh-cli_tmp_2424672_1', 'leftover'), 'x')
  // Look-alike dirs must survive: other packages and foreign tmp names.
  mkdirSync(join(scope, 'unrelated-pkg'))
  mkdirSync(join(scope, 'other_tmp_999_1'))
  const removal = removeStalePackageInstall('dsh-cli')
  check(
    'stale: package dir removed',
    !existsSync(pkgDir),
  )
  check(
    'stale: leftover tmp staging dir removed',
    !existsSync(join(scope, 'dsh-cli_tmp_2424672_1')),
  )
  check(
    'stale: removal reports both halves',
    removal.packageDir === 'removed' && removal.tmpDirs.length === 1 && removal.tmpDirs[0] === 'dsh-cli_tmp_2424672_1',
    `got ${JSON.stringify(removal)}`,
  )
  check(
    'stale: sibling packages and foreign tmp names survive',
    existsSync(join(scope, 'unrelated-pkg')) && existsSync(join(scope, 'other_tmp_999_1')),
  )

  // A junction/symlink at the package dir: the LINK goes, the target tree
  // it points at (a dev checkout) must never be traversed or deleted.
  const precious = join(staleSandbox, 'precious-checkout')
  mkdirSync(join(precious, 'src'), { recursive: true })
  writeFileSync(join(precious, 'src', 'keep.txt'), 'do not delete')
  symlinkSync(precious, pkgDir, process.platform === 'win32' ? 'junction' : 'dir')
  const linkRemoval = removeStalePackageInstall('dsh-cli')
  check(
    'stale: link at the package dir is unlinked',
    !existsSync(pkgDir),
  )
  check(
    'stale: link target is never traversed',
    existsSync(join(precious, 'src', 'keep.txt')),
  )
  check(
    'stale: link removal still reports removed',
    linkRemoval.packageDir === 'removed',
  )

  const absent = removeStalePackageInstall('never-existed')
  check(
    'stale: absent package dir reports absent (custom roots just miss)',
    absent.packageDir === 'absent' && absent.tmpDirs.length === 0,
  )
} finally {
  if (DSH_HOME_BACKUP === undefined) delete process.env.DSH_HOME
  else process.env.DSH_HOME = DSH_HOME_BACKUP
  rmSync(staleSandbox, { recursive: true, force: true })
}

// ---- recovery wiring (issue #479): the EEXIST signature and the stale
// install removal must be reachable from the shared install half (updateCli,
// which updateCliAndRestart delegates to), and the /update restart tail must
// ride the hardened restartCli handoff (#483).
const updateFnStart = compiledSource.indexOf('export async function updateCli')
const restartFnStart = compiledSource.indexOf('export async function restartCli')
const updateSegment = compiledSource.slice(updateFnStart, restartFnStart)
check(
  'recovery: EEXIST failure routes to the stale-install removal (#479)',
  updateSegment.includes('isEexistTmpRenameFailure(updateStderr)') && updateSegment.includes('removeStalePackageInstall(profile)'),
)
check(
  'recovery: transient retry failure also escalates to removal (#225 leftovers)',
  updateSegment.includes('isTransientUpdateFailure(updateStderr)'),
)
check(
  'update restart: reuses the hardened restartCli handoff with kind update (#483)',
  updateSegment.includes("kind: 'update'") && updateSegment.includes('restartCli(sessionId, {'),
)
check(
  'restartCli: update kind skips the /restart boot-diagnosis marker',
  /kind === 'restart' \? \{ \[RESTART_CHILD_ENV\]: '1' \} : \{\}/.test(compiledSource),
)

// ---- CLI update（issue #509）：安装半程与 /update 共用同一实现 ----------------
// updateCli 是 updateCliAndRestart 的安装半程，cliUpdate 是 bin 启动器
// 动态 import 的无头入口——两者必须存在于编译产物，且 updateCliAndRestart
// 委托 updateCli 而不是保留一份拷贝（DRY 契约：装机逻辑只有一份）。
{
  const mod = await import('../lib/types/update.js')
  check('cli: updateCli is exported from the compiled lib', typeof mod.updateCli === 'function')
  check('cli: cliUpdate is exported from the compiled lib', typeof mod.cliUpdate === 'function')
  check(
    'cli: updateCliAndRestart delegates to updateCli (single install path)',
    /updateCliAndRestart[\s\S]{0,400}await updateCli\(/.test(compiledSource),
  )
}

// ---- cli: 真实 cliUpdate 的「版本未前进」路径（预检失败 + --latest no-op）------
// 拷贝的编译模块 + 版本固定的 manifest：registry 指向必然拒绝连接的地址
// （预检 → unknown → --latest 兜底），stub dsh 什么都不装、返回 0。安装前后
// installedCliVersion 相同——必须如实打印 version did not advance，绝不打印
// 虚假的 updated X → X。真实模块、真实子进程，只有网络与 dsh 是假的。
{
  const scratch3 = mkdtempSync(join(tmpdir(), 'verify-update-cli-'))
  const ENV_BACKUP = { reg: process.env.NPM_CONFIG_REGISTRY, regL: process.env.npm_config_registry, path: process.env.PATH }
  try {
    symlinkSync(join(repoRoot, 'node_modules'), join(scratch3, 'node_modules'), process.platform === 'win32' ? 'junction' : 'dir')
    const pkgRoot = join(scratch3, 'pkg')
    copyUpdateModule(join(pkgRoot, 'lib', 'types'))
    writeFileSync(join(pkgRoot, 'package.json'), JSON.stringify({ name: '@askdkc/dsh-cli', version: '2.0.0', type: 'module' }))
    const stubDir = join(scratch3, 'stub-bin')
    mkdirSync(stubDir, { recursive: true })
    writeFileSync(join(stubDir, 'dsh'), '#!/bin/sh\nexit 0\n')
    chmodSync(join(stubDir, 'dsh'), 0o755)
    // Windows spawns the launcher through cmd.exe (shell: true), which does
    // not run sh scripts — provide a .cmd stub that exits 0 as well.
    writeFileSync(join(stubDir, 'dsh.cmd'), '@exit /b 0\r\n')
    // Isolate the profile workspace: ensureProfileAllowBuilds inside
    // updateCli must touch this scratch home, never the real ~/.dsh.
    const DSH_HOME_BACKUP = process.env.DSH_HOME
    process.env.DSH_HOME = join(scratch3, 'home')
    process.env.NPM_CONFIG_REGISTRY = 'http://127.0.0.1:1'
    // NOTE: no `delete process.env.npm_config_registry` here — Windows env
    // vars are case-insensitive, so deleting the lowercase spelling would
    // also drop the uppercase value just set, silently pointing the probe at
    // the real npmjs registry (and making this test network-dependent).
    process.env.PATH = stubDir
    const cliMod = await import(`${pathToFileURL(join(pkgRoot, 'lib', 'types', 'update.js'))}?probe=cli`)
    let captured = ''
    const origWrite = process.stdout.write.bind(process.stdout)
    process.stdout.write = chunk => { captured += String(chunk); return true }
    let code
    try {
      code = await cliMod.cliUpdate('dsh-cli')
    } finally {
      process.stdout.write = origWrite
    }
    if (DSH_HOME_BACKUP === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = DSH_HOME_BACKUP
    check('cli: no-op --latest 兜底以 0 退出', code === 0, `code=${code}`)
    check('cli: 版本未前进时如实提示', captured.includes('version did not advance'), JSON.stringify(captured.slice(0, 120)))
    check('cli: 不打印虚假的 updated X → X', !captured.includes('updated 2.0.0'))
  } finally {
    if (ENV_BACKUP.reg === undefined) delete process.env.NPM_CONFIG_REGISTRY
    else process.env.NPM_CONFIG_REGISTRY = ENV_BACKUP.reg
    if (ENV_BACKUP.regL === undefined) delete process.env.npm_config_registry
    else process.env.npm_config_registry = ENV_BACKUP.regL
    process.env.PATH = ENV_BACKUP.path
    rmSync(scratch3, { recursive: true, force: true })
  }
}

// ---- standalone: 便携包环境检测与资产名称解析 --------------------------------
{
  const origEnv = {
    standalone: process.env.DSH_CLI_STANDALONE,
    binary: process.env.DSH_CLI_STANDALONE_BINARY,
    dshHome: process.env.DSH_HOME,
  }
  try {
    delete process.env.DSH_CLI_STANDALONE
    delete process.env.DSH_CLI_STANDALONE_BINARY
    process.env.DSH_HOME = '/home/user/.dsh'
    check('standalone: 默认非便携模式', isStandaloneRuntime() === false)

    process.env.DSH_CLI_STANDALONE = '1'
    check('standalone: DSH_CLI_STANDALONE=1 识别为便携模式', isStandaloneRuntime() === true)

    delete process.env.DSH_CLI_STANDALONE
    process.env.DSH_CLI_STANDALONE_BINARY = '/tmp/dsh-cli'
    check('standalone: DSH_CLI_STANDALONE_BINARY 识别为便携模式', isStandaloneRuntime() === true)
    check('standalone: getStandaloneBinaryPath 返回指定路径', getStandaloneBinaryPath() === '/tmp/dsh-cli')

    delete process.env.DSH_CLI_STANDALONE_BINARY
    process.env.DSH_HOME = '/home/user/.dsh-cli-standalone'
    check('standalone: DSH_HOME 包含 dsh-cli-standalone 识别为便携模式', isStandaloneRuntime() === true)

    // 资产名称匹配
    check('standalone: Windows 资产名匹配', getStandaloneAssetName('win32', 'x64') === 'dsh-cli-standalone-win-x64.zip')
    check('standalone: macOS arm64 资产名匹配', getStandaloneAssetName('darwin', 'arm64') === 'dsh-cli-standalone-darwin-arm64.tar.gz')
    check('standalone: macOS x64 资产名匹配', getStandaloneAssetName('darwin', 'x64') === 'dsh-cli-standalone-darwin-x64.tar.gz')
    check('standalone: Linux x64 资产名匹配', getStandaloneAssetName('linux', 'x64') === 'dsh-cli-standalone-linux-x64.tar.gz')
    check('standalone: Linux arm64 资产名匹配', getStandaloneAssetName('linux', 'arm64') === 'dsh-cli-standalone-linux-arm64.tar.gz')
  } finally {
    if (origEnv.standalone === undefined) delete process.env.DSH_CLI_STANDALONE
    else process.env.DSH_CLI_STANDALONE = origEnv.standalone
    if (origEnv.binary === undefined) delete process.env.DSH_CLI_STANDALONE_BINARY
    else process.env.DSH_CLI_STANDALONE_BINARY = origEnv.binary
    if (origEnv.dshHome === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = origEnv.dshHome
  }
}

// --- sharp 异平台 optional 过滤（维护群 2026-09-11 反馈：更新时下载全平台
// --- @img/sharp-*，~90MB 下载量换不来任何运行时价值）----------------------------
// 平台矩阵一律用显式输入断言：断言不得依赖跑测试的机器，否则 Windows/macOS
// 上会把本机平台当成异平台而假红（PR #861 首版即如此）。
{
  check('sharp 后缀: glibc linux x64', sharpCurrentSuffix('linux', 'x64', 'glibc') === 'linux-x64')
  check('sharp 后缀: musl linux arm64', sharpCurrentSuffix('linux', 'arm64', 'musl') === 'linuxmusl-arm64')
  check('sharp 后缀: win32 x64 直拼', sharpCurrentSuffix('win32', 'x64', 'glibc') === 'win32-x64')
  check('sharp 后缀: darwin arm64 直拼', sharpCurrentSuffix('darwin', 'arm64', 'glibc') === 'darwin-arm64')
  check('sharp 后缀: freebsd 只有 wasm 形态', sharpCurrentSuffix('freebsd', 'x64', 'glibc') === 'freebsd-wasm32')
  const onLinuxX64 = ignoredSharpOptionalPatterns('linux', 'x64', 'glibc')
  check('忽略清单: 排除本平台 wrapper 与 libvips', !onLinuxX64.includes('@img/sharp-linux-x64') && !onLinuxX64.includes('@img/sharp-libvips-linux-x64'))
  check('忽略清单: 含异平台代表项', onLinuxX64.includes('@img/sharp-win32-x64') && onLinuxX64.includes('@img/sharp-darwin-arm64') && onLinuxX64.includes('@img/sharp-libvips-linuxmusl-x64'))
  check('忽略清单: 与 registry 矩阵对齐（不列不存在的包）', !onLinuxX64.includes('@img/sharp-libvips-win32-x64') && !onLinuxX64.includes('@img/sharp-linuxmusl-arm') && !onLinuxX64.includes('@img/sharp-linux-ia32'))
  check('忽略清单: freebsd 的 wasm 形态在别的平台算异平台', onLinuxX64.includes('@img/sharp-freebsd-wasm32'))
  check('忽略清单: freebsd 保留自身唯一可加载的 wasm 形态', !ignoredSharpOptionalPatterns('freebsd', 'x64', 'glibc').includes('@img/sharp-freebsd-wasm32'))
  const onMusl = ignoredSharpOptionalPatterns('linux', 'x64', 'musl')
  check('忽略清单: musl 环境排除 linuxmusl-x64 而保留 linux-x64', !onMusl.includes('@img/sharp-linuxmusl-x64') && onMusl.includes('@img/sharp-linux-x64'))
  check('忽略清单: 不含非平台的纯 JS 包', !onMusl.some(p => p.includes('colour')))
  check('libc 判定: report 的 glibc 标记优先于 musl loader 存在', detectLibc('linux', { header: { glibcVersionRuntime: '2.36' } }, true) === 'glibc')
  check('libc 判定: 无 report 时 loader 探测兜底', detectLibc('linux', undefined, true) === 'musl' && detectLibc('linux', undefined, false) === 'glibc')
  check('libc 判定: 非 Linux 平台恒为 glibc', detectLibc('win32', undefined, true) === 'glibc' && detectLibc('darwin', undefined, true) === 'glibc')

  // 本机平台（与被测实现同源输入：report 优先，loader 路径兜底）。
  const hostLoaderPresent = existsSync('/lib/ld-musl-x86_64.so.1') || existsSync('/lib/ld-musl-aarch64.so.1') || existsSync('/etc/alpine-release')
  const hostLibc = detectLibc(process.platform, process.report?.getReport(), hostLoaderPresent)
  const hostSuffix = sharpCurrentSuffix(process.platform, process.arch, hostLibc)
  const hostIgnore = ignoredSharpOptionalPatterns(process.platform, process.arch, hostLibc)

  // 手写字面表（刻意不调用被测 helper）：本机平台自己的包，以及必须被忽略的
  // 异平台代表性包。与 helper 推导的期望互为独立 oracle——helper 少算/漏算时
  // 这组会红，反过来 helper 多算（忽略本机包）时 OWN_NAMES 会红。
  const OWN_NAMES = {
    'win32-x64': ['@img/sharp-win32-x64'],
    'darwin-arm64': ['@img/sharp-darwin-arm64', '@img/sharp-libvips-darwin-arm64'],
    'darwin-x64': ['@img/sharp-darwin-x64', '@img/sharp-libvips-darwin-x64'],
    'linux-x64': ['@img/sharp-linux-x64', '@img/sharp-libvips-linux-x64'],
    'linux-arm64': ['@img/sharp-linux-arm64', '@img/sharp-libvips-linux-arm64'],
    'linuxmusl-x64': ['@img/sharp-linuxmusl-x64', '@img/sharp-libvips-linuxmusl-x64'],
    'linuxmusl-arm64': ['@img/sharp-linuxmusl-arm64', '@img/sharp-libvips-linuxmusl-arm64'],
    'freebsd-wasm32': ['@img/sharp-freebsd-wasm32'],
  }
  const IGNORED_PROBES = {
    'win32-x64': ['@img/sharp-darwin-arm64', '@img/sharp-linux-x64', '@img/sharp-linuxmusl-x64', '@img/sharp-libvips-linux-x64', '@img/sharp-libvips-linuxmusl-x64'],
    'darwin-arm64': ['@img/sharp-darwin-x64', '@img/sharp-win32-x64', '@img/sharp-linux-x64', '@img/sharp-libvips-darwin-x64'],
    'linux-x64': ['@img/sharp-win32-x64', '@img/sharp-darwin-arm64', '@img/sharp-linux-arm64', '@img/sharp-libvips-linuxmusl-x64'],
    'linuxmusl-x64': ['@img/sharp-linux-x64', '@img/sharp-win32-x64', '@img/sharp-libvips-linux-x64'],
    'freebsd-wasm32': ['@img/sharp-linux-x64', '@img/sharp-win32-x64', '@img/sharp-libvips-linux-x64'],
  }
  const ownNames = OWN_NAMES[hostSuffix] ?? [`@img/sharp-${hostSuffix}`]
  const literalProbes = IGNORED_PROBES[hostSuffix] ?? ['@img/sharp-linux-x64', '@img/sharp-win32-x64', '@img/sharp-darwin-arm64'].filter(p => p !== `@img/sharp-${hostSuffix}`)

  const sharpScratch = mkdtempSync(join(tmpdir(), 'verify-sharp-filter-'))
  const prevDshHome = process.env.DSH_HOME
  try {
    process.env.DSH_HOME = join(sharpScratch, 'dsh-home')
    const profDir = join(process.env.DSH_HOME, 'profiles', 'dsh-cli')
    mkdirSync(profDir, { recursive: true })
    const wsPath = join(profDir, 'pnpm-workspace.yaml')
    writeFileSync(wsPath, 'packages:\n  - .\nnodeLinker: hoisted\n')
    const first = ensureProfileSharpPlatformFilter('dsh-cli')
    const yamlText = readFileSync(profileWorkspaceYamlPath('dsh-cli'), 'utf8')
    check('workspace 预种: 块落盘且带模式行', first !== undefined && first.changed && yamlText.includes('ignoredOptionalDependencies:') && yamlText.includes(`- '${hostIgnore[0]}'`), `host=${process.platform}-${process.arch} first=${JSON.stringify(first)}`)
    check('workspace 预种: 既有内容保留', yamlText.includes('nodeLinker: hoisted'))
    check('workspace 预种: 不忽略本机平台（手写期望）', !ownNames.some(n => yamlText.includes(n)), `yaml 含本机包 ownNames=${ownNames.join(',')}`)
    check('workspace 预种: 忽略本机外的代表性包（手写期望）', literalProbes.every(p => yamlText.includes(`- '${p}'`)), `host=${hostSuffix} probes=${literalProbes.join(',')}`)
    const second = ensureProfileSharpPlatformFilter('dsh-cli')
    const afterText = readFileSync(profileWorkspaceYamlPath('dsh-cli'), 'utf8')
    check('workspace 预种: 幂等（不重复块、不再写盘）', afterText.match(/ignoredOptionalDependencies:/gu)?.length === 1 && second !== undefined && second.changed === false && afterText === yamlText)

    // 名单跟着运行平台走：已有块里若有「本机平台的包」或别的平台算出的残留，
    // 重算必须把它换掉；块内非表内条目是用户显式决策，原样保留。
    const hostOwnLine = `- '${ownNames[0]}'`
    writeFileSync(wsPath, `ignoredOptionalDependencies:\n  - fsevents\n  ${hostOwnLine}\n  - '@img/sharp-linux-riscv64'\n`)
    const third = ensureProfileSharpPlatformFilter('dsh-cli')
    const refreshed = readFileSync(profileWorkspaceYamlPath('dsh-cli'), 'utf8')
    check('workspace 预种: 旧名单被重算（本机平台的包被移出）', third !== undefined && third.changed && !refreshed.includes(ownNames[0]))
    check('workspace 预种: 用户自定义条目保留', refreshed.includes('- fsevents'))
    check('workspace 预种: 重算后覆盖当前平台矩阵', hostIgnore.every(p => refreshed.includes(`- '${p}'`)))
    check('workspace 预种: 重算后仍只有一个块', refreshed.match(/ignoredOptionalDependencies:/gu)?.length === 1)
    const fourth = ensureProfileSharpPlatformFilter('dsh-cli')
    check('workspace 预种: 重算后再次运行不再写盘', fourth !== undefined && fourth.changed === false)

    // 归类必须按「包名」而不是原始字节：空行、条目尾注释、双引号都是合法 YAML，
    // 若把它们当成用户条目保留，本机平台自己的包就会留在忽略名单里——pnpm 跳过
    // 它、sharp 直接加载失败，正是本改动要消灭的跨平台故障。
    const malformed = [
      ['块内空行', `ignoredOptionalDependencies:\n  - fsevents\n\n  ${hostOwnLine}\n`],
      ['条目尾注释', `ignoredOptionalDependencies:\n  - fsevents\n  ${hostOwnLine} # keep\n`],
      ['双引号写法', `ignoredOptionalDependencies:\n  - fsevents\n  - "@img/sharp-${hostSuffix}"\n`],
    ]
    for (const [label, seeded] of malformed) {
      writeFileSync(wsPath, seeded)
      const outcome = ensureProfileSharpPlatformFilter('dsh-cli')
      const got = readFileSync(wsPath, 'utf8')
      check(`workspace 预种: ${label}时本机包仍被重算掉`, outcome !== undefined && !got.includes(ownNames[0]) && got.includes('- fsevents'), `got=${got.replace(/\n/gu, '|')}`)
    }
    // 用户自写的、不在本模块两张表内的 @img 条目（如自带豁免 wasm 回退包）是用户
    // 决策，不能被重算抹掉。
    writeFileSync(wsPath, `ignoredOptionalDependencies:\n  - fsevents\n  - '@img/sharp-wasm32'\n`)
    const keepOutcome = ensureProfileSharpPlatformFilter('dsh-cli')
    check('workspace 预种: 用户自写的表外 @img 条目保留', keepOutcome !== undefined && readFileSync(wsPath, 'utf8').includes(`- '@img/sharp-wasm32'`))

    // 重复键的文档本来就不是合法 YAML：不能往里写（否则 pnpm 连 workspace 都读不了）。
    const duplicated = `ignoredOptionalDependencies:\n  - fsevents\nignoredOptionalDependencies:\n  - '@img/sharp-wasm32'\n`
    writeFileSync(wsPath, duplicated)
    check('workspace 预种: 重复键原样放过', ensureProfileSharpPlatformFilter('dsh-cli') === undefined && readFileSync(wsPath, 'utf8') === duplicated)
    // 流式写法（键行自带值）同理。
    writeFileSync(wsPath, 'ignoredOptionalDependencies: [fsevents]\n')
    check('workspace 预种: 流式写法不动用户文件', ensureProfileSharpPlatformFilter('dsh-cli') === undefined && readFileSync(wsPath, 'utf8') === 'ignoredOptionalDependencies: [fsevents]\n')

    // 文件不存在时要新建，且不能以空行开头。
    const emptyProf = join(process.env.DSH_HOME, 'profiles', 'dsh-cli-empty')
    mkdirSync(emptyProf, { recursive: true })
    const created = ensureProfileSharpPlatformFilter('dsh-cli-empty')
    const createdText = readFileSync(join(emptyProf, 'pnpm-workspace.yaml'), 'utf8')
    check('workspace 预种: 新建文件不以空行开头', created !== undefined && createdText.startsWith('ignoredOptionalDependencies:'))
    check('workspace 预种: profile 目录缺失返回 undefined', ensureProfileSharpPlatformFilter('absent') === undefined)
  } finally {
    if (prevDshHome === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = prevDshHome
    rmSync(sharpScratch, { recursive: true, force: true })
  }
}

if (failed > 0) {
  console.error(`\n${failed} check(s) failed`)
  process.exit(1)
}
console.log('\nall checks passed')
