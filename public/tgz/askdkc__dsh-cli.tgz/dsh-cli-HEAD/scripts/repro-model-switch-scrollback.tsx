/**
 * `/model` 切换 scrollback 重复沉积回归（真机取证：每次切换 scrollback 多一份
 * splash 拷贝，+18 行/次）。真实 channel（createChannel）+ 最小 fake agent /
 * sessions / agents 服务，逐键走完整 UI 路径（输入 /model → 补全浮层 → picker
 * → fork+replay）；xterm-headless 开 2000 行 scrollback 重建终端视角，断言
 * splash/历史等唯一 UI 文本在 scrollback + 视口中恰好一份、缓冲区零增长。
 *
 * 根因：补全/picker 等瞬态面板 in-flow 挂载使帧高涨落，帧顶行被滚进
 * scrollback 后遭关闭重绘二次写入。修复：瞬态面板改 OverlayAbove 零高度浮层。
 *
 * 运行：node --import tsx/esm scripts/repro-model-switch-scrollback.tsx
 */
process.env.FORCE_COLOR = '3'
process.env.TERM_PROGRAM = 'WezTerm'  // DEC-2026 同步输出路径
process.env.DSH_CLI_THEME = 'dark'     // 跳过 OSC 11 探测，保持确定性
process.env.DSH_CLI_LANG = 'zh'        // 固定中文 UI（splash 标语断言）

// 隔离家目录：switchModel 会把 picker 选择写进 ~/.dsh-cli/model.json
// （modelPrefs.PREFS_DIR 在模块加载时按 homedir() 解析），不隔离会把
// fake-provider 写进真机配置——真机下一次启动所有回合报
// "no adapter registered for provider fake-provider"。必须在 import src 之前。
// HOME 与 USERPROFILE 必须成对设置：os.homedir() 在 POSIX 读 HOME、在 Windows
// 读 USERPROFILE，只设一个等于在另一个平台上根本没有隔离。
const { mkdtempSync, readFileSync } = await import('node:fs')
const { tmpdir } = await import('node:os')
const { join: joinPath } = await import('node:path')
const reproHome = mkdtempSync(joinPath(tmpdir(), 'dshcli-repro-home-'))
process.env.HOME = reproHome
process.env.USERPROFILE = reproHome

const [{ PassThrough, Writable }, React, { Terminal: XTerm }, { render }, { Chat }, { QuestionStore }, { createChannel }, { settled, sleep }] = await Promise.all([
  import('node:stream'),
  import('react'),
  import('@xterm/headless'),
  import('../src/ui.js'),
  import('../src/screens/Chat.js'),
  import('../src/dsh-adapter/questions.js'),
  import('../src/dsh-adapter/channel.js'),
  import('./lib/term-test.mjs'),
])

const COLS = 100
const ROWS = 30
const SCROLLBACK = 2000
const term = new XTerm({ cols: COLS, rows: ROWS, scrollback: SCROLLBACK, allowProposedApi: true })

const rawChunks: string[] = []
class FakeStdout extends Writable {
  columns = COLS
  rows = ROWS
  isTTY = true
  _write(chunk: unknown, _e: BufferEncoding, cb: () => void) {
    const str = String(chunk)
    rawChunks.push(str)
    term.write(str, () => cb())
  }
}
class FakeStderr extends Writable {
  isTTY = true
  _write(_c: unknown, _e: BufferEncoding, cb: () => void) { cb() }
}
class FakeStdin extends PassThrough {
  isTTY = true
  setRawMode() { return this }
  ref() { return this }
  unref() { return this }
}
function fullBufferLines(): string[] {
  const buf = term.buffer.active
  const out: string[] = []
  for (let y = 0; y < buf.length; y++) out.push(buf.getLine(y)?.translateToString(true) ?? '')
  return out
}

let failed = 0
function check(name: string, ok: boolean, extra = '') {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${extra ? `  (${extra})` : ''}`)
  if (!ok) failed += 1
}

/** 唯一标记在 scrollback+视口中的出现次数（逐行包含匹配）。 */
function countMarker(marker: string): number {
  return fullBufferLines().filter(l => l.includes(marker)).length
}

// ---- SessionEvent 预制：2 轮历史（user + reasoning + 长 assistant） ----------
let seq = 0
let now = Date.now()
function ev(type: string, data: Record<string, unknown>): Record<string, unknown> {
  return { seq: seq++, time: (now += 5), type, data }
}
function userEvent(text: string) {
  return ev('user/message', { source: { kind: 'user' }, content: [{ type: 'text', text }] })
}
function assistantEvent(text: string, turn: number) {
  return ev('assistant/message', {
    turn, step: 0,
    message: { role: 'assistant', content: [{ type: 'text', text }] },
    usage: { inputTokens: 100, outputTokens: 50 },
  })
}
const events: Array<Record<string, unknown>> = []
for (let turn = 0; turn < 2; turn++) {
  events.push(ev('turn/start', { turn }))
  events.push(userEvent(`历史问题 ${turn}：检查一下构建配置`))
  const body = Array.from(
    { length: 12 },
    (_, i) => `- 第 ${turn}-${i} 条历史回答要点：装配、主题、同步与加密打包`,
  ).join('\n')
  events.push(assistantEvent(`历史回答 ${turn}：\n\n${body}`, turn))
  events.push(ev('turn/end', { turn, reason: { kind: 'completed' } }))
}

// ---- 最小 fake agent / sessions / agents --------------------------------------
const stubAgentCtx = { on: () => () => {} }
function makeAgent(id: string, sessionEvents: readonly unknown[]) {
  return {
    id,
    status: 'idle',
    session: { id: `s-${id}`, seq: sessionEvents.length, events: sessionEvents, header: {} , snapshotEvents() { return this.events }},
    ctx: stubAgentCtx,
    followup() {},
    steer() {},
    inbox: { remove: () => true },
  }
}
let agentCounter = 0
const handlers = new Map<string, unknown>()
const services: Record<string, unknown> = {
  sessions: {
    async flush() {},
  },
  agents: {
    async create(options: { sessionId: string; seed: readonly unknown[] }) {
      agentCounter += 1
      const agent = makeAgent(`fork-${agentCounter}`, options.seed)
      return { agent, dispose: async () => {} }
    },
  },
  llm: {
    listProviders: () => [{ id: 'fake-provider' }],
    listModels: async () => [
      { provider: 'fake-provider', id: 'deepseek-v4-flash', name: 'DeepSeek V4 Flash' },
      { provider: 'fake-provider', id: 'deepseek-v4-pro', name: 'DeepSeek V4 Pro' },
    ],
  },
}
const ctx = {
  on(event: string, handler: unknown) {
    handlers.set(event, handler)
    return () => handlers.delete(event)
  },
  get(name: string) {
    return services[name]
  },
  logger: { warn() {} },
}

// ---- 真实 channel + 真实 Chat ---------------------------------------------------
const channel = createChannel(ctx as never, makeAgent('a1', events) as never, {
  whaleIdle: false, // 探针确定性：鲸鱼欢迎期闲置动画不进本探针的测量窗口。
  model: 'deepseek-v4-flash',
  cwd: '/tmp/demo',
  provider: 'fake-provider',
  activity: false,
})

// Optional manual PTY check with the same isolated fixture and real stdio.
if (process.env.LIVE_TTY === '1') {
  const live = await render(
    <Chat channel={channel as never} questionStore={new QuestionStore()} onExit={() => {}} />,
    { stdout: process.stdout, stdin: process.stdin, stderr: process.stderr, exitOnCtrlC: false, patchConsole: false },
  )
  await sleep(30_000) // 固定窗:墙钟 手動確認用の操作時間
  live.unmount()
  process.exit(0)
}

const stdoutObj = new FakeStdout()
const stdin = new FakeStdin()
const instance = await render(
  <Chat channel={channel as never} questionStore={new QuestionStore()} onExit={() => {}} />,
  { stdout: stdoutObj, stdin, stderr: new FakeStderr(), exitOnCtrlC: false, patchConsole: false },
)

const SPLASH = '探索未至之境'
const HIST0 = '历史问题 0：检查一下构建配置'
const HIST1 = '历史回答 1：'
// boot 落定：轮询到 splash 与历史行都上屏再断言（原固定 1200ms 在慢
// runner 上会断言到未画完的缓冲区）——等待与断言共用同一谓词（settled）。
check('boot 后 splash 恰好一份', await settled(() => countMarker(SPLASH) === 1), `实际 ${countMarker(SPLASH)}`)
check('boot 后历史行恰好一份', await settled(() => countMarker(HIST0) === 1 && countMarker(HIST1) === 1),
  `问题=${countMarker(HIST0)} 回答=${countMarker(HIST1)}`)
console.log(`boot: buffer=${term.buffer.active.length} 行 (视口 ${ROWS})`)

// ---- 走真实 UI 路径：输入 /model → 筛选 → 回车切换 ----------------
// 与真机操作逐键一致：补全面板、picker、notify、fork+replay 全部经过。
const bufLen = (tag: string) =>
  console.log(`  [${tag}] buffer=${term.buffer.active.length} scrollback=${term.buffer.active.baseY}`)
// 逐键 40ms 与各步 200/600ms 均为按键序列的 ordering pacing：补全浮层/
// picker 的 key-ready 状态无法用纯文本屏幕内容观测（同 repro-settings）。
const typeKeys = async (keys: string) => {
  for (const ch of keys) {
    stdin.write(ch)
    await sleep(40) // 固定窗:pacing 逐键步间
  }
}
bufLen('boot')
await typeKeys('/model openai')
await sleep(200) // 固定窗:pacing 補完が入力を受け付けるまで
stdin.write('\r')
await sleep(600) // 固定窗:pacing ダイアログの描画完了まで
check('一致しない /model 引数も検索欄に残る', fullBufferLines().some(line => line.includes('openai')))
check('一致しない引数で自動切り替えしない', channel.model === 'deepseek-v4-flash')
stdin.write('\x1b')
await sleep(200) // 固定窗:pacing Esc の描画完了まで
await typeKeys('/model seek deep')
await sleep(200) // 固定窗:pacing 等补全浮层收键就绪
bufLen('typed /model seek deep')
stdin.write('\r')            // 打开 picker（slash 命令派发）
await sleep(600) // 固定窗:pacing 等 picker 收键就绪
bufLen('picker open')
check('順不同の検索語がピッカーに残る', fullBufferLines().some(line => line.includes('seek deep')))
check('検索結果に DeepSeek が表示される', fullBufferLines().some(line => line.includes('DeepSeek V4 Pro')))
check('検索語 Enter だけでは切り替えない', channel.model === 'deepseek-v4-flash', `実際 ${channel.model}`)
stdin.write('\x06')        // Ctrl+F: 現在の候補をお気に入りへ
await sleep(200) // 固定窗:pacing お気に入りの再描画まで
const favoriteFile = joinPath(reproHome, '.dsh-cli', 'model-favorites.json')
check('Ctrl+F がお気に入りを保存する', readFileSync(favoriteFile, 'utf8').includes('deepseek-v4-flash'))
check('お気に入りの星が表示される', fullBufferLines().some(line => line.includes('★') && line.includes('DeepSeek V4 Flash')))
stdin.write('\x06')
await sleep(200) // 固定窗:pacing お気に入り解除の再描画まで
check('Ctrl+F 再押下でお気に入りを解除する', JSON.parse(readFileSync(favoriteFile, 'utf8')).models.length === 0)
stdin.write('\x1b[B\r')   // 同一入力バッチで二番目を選択して確定
// 固定窗:探针 「恰好一份」断言防的是切换后追加帧的多余沉积，对已成立条件
// （count===1）轮询立即返回等于没测。
await sleep(1500)
bufLen('switched')

check('切换后模型名生效', await settled(() => channel.model === 'deepseek-v4-pro'), `实际 ${channel.model}`)
check('切换后 splash 恰好一份', countMarker(SPLASH) === 1, `实际 ${countMarker(SPLASH)}`)
check('切换后历史行恰好一份', countMarker(HIST0) === 1 && countMarker(HIST1) === 1,
  `问题=${countMarker(HIST0)} 回答=${countMarker(HIST1)}`)
check('历史问题 1 恰好一份', countMarker('历史问题 1：检查一下构建配置') === 1,
  `实际 ${countMarker('历史问题 1：检查一下构建配置')}`)
check('历史片段 0-8 恰好一份', countMarker('第 0-8 条历史回答要点') === 1,
  `实际 ${countMarker('第 0-8 条历史回答要点')}`)

// ---- 再切一次：确认沉积随切换次数线性增长 --------------------------------------
await typeKeys('/model')
await sleep(200) // 固定窗:pacing 等补全浮层收键就绪
stdin.write('\r')
await sleep(600) // 固定窗:pacing 等 picker 收键就绪
await typeKeys('flash v4')
await sleep(200) // 固定窗:pacing 按键步间
stdin.write('\r')
// 固定窗:探针 同上，沉积「恰好一份」是不得改变的断言。
await sleep(1500)
check('二次切换后 splash 恰好一份', countMarker(SPLASH) === 1, `实际 ${countMarker(SPLASH)}`)

// ---- Esc 只关不切换：浮层整体条件挂载的回归场景 -----------------------------
// 关键前置：等 splash 动画彻底稳定（不再有新帧）。动画每 tick 会把 ScrollBox
// 标脏、强制全量重绘，掩盖"关闭浮层后被覆盖行留空"的缺陷（条件挂载缺失时，
// 干净 ScrollBox 的 blit 会跳过 absoluteClear 覆盖行——真实终端上动画停止
// 后这些行永久空白）。覆盖区内的历史尾行没有动画治疗，是最敏感的探针。
const waitQuiet = async () => {
  const deadline = Date.now() + 20_000
  let last = rawChunks.length
  while (Date.now() < deadline) {
    await sleep(600) // 固定窗:pacing 轮询步长，条件见循环（600ms 内无新帧即视为静息）
    if (rawChunks.length === last) return
    last = rawChunks.length
  }
  console.log('  [warn] 动画 20s 未稳定，继续执行（历史行断言不受影响）')
}
await waitQuiet()
const modelBeforeEsc = channel.model
const bufBeforeEsc = term.buffer.active.length
await typeKeys('/model')
await sleep(200) // 固定窗:pacing 等补全浮层收键就绪
stdin.write('\r')            // 打开 picker
await sleep(600) // 固定窗:pacing 等 picker 收键就绪
stdin.write('\x1b')          // Esc：只关闭，不切换
// 固定窗:探针 Esc 不切换/历史仍在/缓冲区零增长都是「状态不得改变」断言，
// 轮询已成立条件立即返回等于没测。
await sleep(600)
check('Esc 不改动模型', channel.model === modelBeforeEsc, `实际 ${channel.model}`)
check('Esc 关闭后被覆盖历史行仍在',
  countMarker('第 1-8 条历史回答要点') === 1 && countMarker('第 1-11 条历史回答要点') === 1,
  `1-8=${countMarker('第 1-8 条历史回答要点')} 1-11=${countMarker('第 1-11 条历史回答要点')}`)
check('Esc 开关周期缓冲区零增长', term.buffer.active.length === bufBeforeEsc,
  `${bufBeforeEsc} → ${term.buffer.active.length}`)

console.log(`final: buffer=${term.buffer.active.length} 行 (视口 ${ROWS}, scrollback ${term.buffer.active.length - ROWS})`)
const fullResets = rawChunks.join('').match(/\x1b\[10000S/g)?.length ?? 0
check('全程无 full-reset (CSI 10000S)', fullResets === 0, `实际 ${fullResets}`)

await typeKeys('/model fake-provider/deepseek-v4-pro')
await sleep(200) // 固定窗:pacing 完全ルートの補完が入力を受け付けるまで
stdin.write('\r')
check('登録済み完全ルートは直接切り替える', await settled(() => channel.model === 'deepseek-v4-pro'))

if (process.env.DUMP === '1') {
  const buf = term.buffer.active
  console.log('---- scrollback 内容 ----')
  for (let y = 0; y < buf.baseY; y++) {
    const l = buf.getLine(y)?.translateToString(true) ?? ''
    if (l.trim()) console.log(String(y).padStart(3), l.slice(0, 90))
  }
}

instance.unmount()
if (failed > 0) {
  console.log(`\n${failed} 项失败`)
  process.exit(1)
}
console.log('\n全部通过')
process.exit(0)
