/**
 * Headless verification of the streaming scroll-jump fix: a transient
 * virtualized-content SHRINK frame (tail unmount + stale heightCache
 * spacer) must not yank an explicitly scrolled position. Before the fix,
 * the follow/clamp wrote scrollTop = maxScroll (0 when the transient
 * measurement dropped below the viewport) → the view jumped to the top
 * while streaming; now the position is frozen for the shrink frame and
 * re-validated when content grows back.
 *
 * Scenario: 60-row content in a 24-row viewport (maxScroll 36). Scroll
 * away from the top, then re-render with 20 rows (shrink: maxScroll 0),
 * then back to 60 (grow). A MID-SCROLL shrink frame must keep the
 * pre-frame scrollTop (10), never 0.
 *
 * Exception (#421/#422 contract): scrolling to the EXACT bottom re-pins
 * sticky (the wheel-tremor restore in render-node-to-output). A sticky
 * view on a shrink frame clamps to the shrunken maxScroll instead of
 * freezing — the freeze would park scrollTop past the whole collapsed
 * content and paint blank; clamping shows the (real) bottom rows.
 * "Nothing renderable exists below maxScroll" — so the bottom-scrolled
 * shrink frame now expects scrollTop 0 (= collapsed maxScroll).
 *
 * Run with plain node against the compiled lib: `node scripts/verify-scroll.mjs`
 */
import { Writable, PassThrough } from 'node:stream'
import React from 'react'
import { render, Text, ScrollBox } from '../lib/types/ui.js'
import { settle, settled } from './lib/term-test.mjs'

let failed = 0
function check(name, ok, extra = '') {
  console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}${extra ? `  (${extra})` : ''}`)
  if (!ok) failed += 1
}

function makeStreams() {
  const stdout = new Writable({
    write(chunk, _enc, cb) {
      stdout.frames.push(String(chunk))
      cb()
    },
  })
  stdout.columns = 100
  stdout.rows = 30
  stdout.isTTY = true
  stdout.frames = []
  const stderr = new Writable({ write(_c, _e, cb) { cb() } })
  stderr.isTTY = true
  const stdin = new PassThrough()
  stdin.isTTY = true
  stdin.setRawMode = () => stdin
  stdin.setEncoding = () => stdin
  stdin.ref = () => stdin
  stdin.unref = () => stdin
  return { stdout, stderr, stdin }
}

const rows = (count) =>
  Array.from({ length: count }, (_, i) =>
    React.createElement(Text, { key: i }, `row ${i}`))

async function run() {
  const { stdout, stderr, stdin } = makeStreams()
  let scrollHandle = null
  // Frame log: every painted frame records the committed scroll geometry.
  const frameLog = []
  const makeScroller = (count) =>
    React.createElement(ScrollBox, {
      ref: h => { scrollHandle = h },
      stickyScroll: false,
      width: 40,
      height: 24,
      flexDirection: 'column',
    }, rows(count))
  const instance = await render(makeScroller(60), {
    stdout,
    stderr,
    stdin,
    exitOnCtrlC: false,
    patchConsole: false,
    onFrame: () => {
      frameLog.push({
        scrollTop: scrollHandle?.getScrollTop() ?? -1,
        scrollHeight: scrollHandle?.getScrollHeight() ?? -1,
      })
    },
  })
  // The extra frame clause is ordering: scrollTo below needs the first
  // full-height layout committed, which the fixed sleep used to cover.
  check('ScrollBox handle attached', await settled(() => scrollHandle !== null && frameLog.at(-1)?.scrollHeight === 60))
  if (!scrollHandle) process.exit(failed)

  // ---- bottom-scrolled: 60 rows, maxScroll 36, scroll to 36.
  scrollHandle.scrollTo(36)
  check('bottom scroll landed at maxScroll', await settled(() => frameLog.at(-1)?.scrollTop === 36 && frameLog.at(-1)?.scrollHeight === 60), JSON.stringify(frameLog.at(-1)))

  // ---- shrink frame: 20 rows → content collapses to the viewport height
  // (24; the content wrapper flexGrows to at least the viewport), so
  // maxScroll = 0. scrollTo(36) landed on the exact bottom, which re-pins
  // sticky; a sticky shrink frame clamps to the collapsed maxScroll (#421:
  // freezing past the content paints blank — see the docstring exception).
  instance.rerender(makeScroller(20))
  check('shrink frame clamps the re-pinned sticky view to the collapsed bottom', await settled(() => {
    const f = frameLog.find(f => f.scrollHeight === 24)
    return f !== undefined && f.scrollTop === 0
  }), JSON.stringify(frameLog.find(f => f.scrollHeight === 24) ?? frameLog.at(-1)))

  // ---- grow back: 60 rows. Position re-validated at the bottom.
  instance.rerender(makeScroller(60))
  check('grow-back frame stays at the bottom', await settled(() => frameLog.at(-1)?.scrollTop === 36 && frameLog.at(-1)?.scrollHeight === 60), JSON.stringify(frameLog.at(-1)))

  // ---- mid-scrolled: 60 rows, scroll to 10 (away from bottom), shrink, grow.
  instance.rerender(makeScroller(60))
  await settle(() => frameLog.at(-1)?.scrollHeight === 60)
  scrollHandle.scrollTo(10)
  await settle(() => frameLog.at(-1)?.scrollTop === 10)
  instance.rerender(makeScroller(20))
  check('mid-scroll shrink frame keeps the position', await settled(() => {
    const f = frameLog.filter(f => f.scrollHeight === 24).at(-1)
    return f !== undefined && f.scrollTop === 10
  }), JSON.stringify(frameLog.filter(f => f.scrollHeight === 24).at(-1) ?? frameLog.at(-1)))

  // ---- the frame AFTER the shrink artifact must not pull the mid position
  // to the bottom: the positional at-bottom check must not trust a maxScroll
  // computed from the artifact frame (opentui #709: content-size changes
  // must not reset the manual-scroll state).
  instance.rerender(makeScroller(60))
  check('post-shrink grow frame keeps the mid position', await settled(() => frameLog.at(-1)?.scrollTop === 10 && frameLog.at(-1)?.scrollHeight === 60), JSON.stringify(frameLog.at(-1)))

  instance.unmount()
  process.exit(failed)
}

run()
