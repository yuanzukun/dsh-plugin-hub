---
name: disk-guard
description: 磁盘守护：把下载/产物/缓存/临时文件放到指定目录（默认非 C 盘），防止 C 盘爆炸；提供 disk_guard 工具用法与 C 盘迁移指引。
whenToUse: 用户提到下载目录、缓存目录、C 盘满了、磁盘占用、temp 清理、DSH_HOME 迁移时使用。
---

# disk-guard（磁盘守护）

用户安装了 dsh-disk-guard 插件。本技能是插件提示词的可选补充，用于按需加载更详细的执行规则。

## 核心规则

1. **下载目录**：所有下载、导出、安装包、产物、大文件一律保存到 {{downloadDir}}。
2. **缓存目录**：临时文件与缓存一律放 {{cacheDir}}（临时 {{tempDir}}，npm 缓存 {{npmCacheDir}}）。
3. **C 盘红线**：禁止向 C 盘写入任何大文件/缓存/临时文件（%TEMP%、C:\Users\*\Temp、C:\Windows\Temp、桌面、文档、用户目录）。
4. **默认路径**：用户没指定路径时按第 1、2 条执行；用完的临时文件随手清理。
5. **工具**：disk_guard status 查看配置与磁盘占用；disk_guard clean（scope=temp|npm|downloads|all，删 downloads 需 force:true）清理过期缓存；disk_guard set 修改目录（需已配置外置 configFile）。

## DSH home 在 C 盘时的迁移

- 检查 $DSH_HOME 是否落在 C 盘（默认 C:\Users\<user>\.dsh）。
- 若在 C 盘：建议运行插件安装包里的 scripts/migrate-c-drive.ps1，它会把 DSH_HOME 设为其他盘（如 E:\dsh-home）、迁移旧数据并可选清理 C 盘临时垃圾。
- 迁移前先确认 DSH 未在运行。
