/**
 * dsh-disk-guard —— DSH 磁盘守护插件
 *
 * 目标：把 DSH 生态的"下载产物"与"缓存/临时文件"从 C 盘重定向到用户指定目录，
 * 并通过会话注入的"路径纪律提示词"让 agent 每次运行都遵守，防止 C 盘爆炸。
 *
 * 能力：
 *  1. 配置驱动：downloadDir / cacheDir（+tempDir/npmCacheDir）可写在
 *     cordis.patch.yml 的本插件 config 里，也可写在外置 YAML（configFile）——
 *     外置文件优先级更高，改配置不用动 patch、重装也不丢。
 *  2. 环境重定向：把 TMP/TEMP/TMPDIR 指到 <cacheDir>/tmp、npm_config_cache
 *     指到 <cacheDir>/npm；并可选把同样内容追加进 $DSH_HOME/.env
 *     （dsh-launch-environment 的 user-env 层，让后续每次启动/子进程都继承）。
 *  3. 提示词注入：每个会话的首条用户消息前注入"路径纪律"块，告诉 agent
 *     下载/产物往哪放、缓存往哪放、C 盘红线、磁盘工具怎么用。
 *  4. 自带工具 disk_guard：status（路径/盘剩余/目录体积）/ clean（清理过期
 *     缓存与临时文件）/ set（改外置配置并即时生效）。
 *  5. 启动自检：DSH home 还在 C 盘时打警告并给出迁移指引。
 *
 * 设计约束：
 *  - 运行期零第三方依赖（yaml 由 esbuild 打进 bundle），只依赖 Node 内置模块；
 *  - 所有路径解析确定化（~ 与 %VAR% 展开、相对路径相对 DSH home 解析）；
 *  - 清理只允许发生在自身配置的目录内，绝不触碰目录外的任何文件；
 *  - 任何一步失败都不影响 DSH 其余功能（全 try/catch + logger）。
 */

import { mkdir, readFile, writeFile, appendFile, readdir, rm, stat, statfs } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { homedir } from 'node:os'
import { join, resolve, isAbsolute } from 'node:path'
import { parse as parseYaml } from 'yaml'

export const name = 'dsh-disk-guard'
/** 需要 tools 注册表（disk_guard 工具）与 systemPrompt 之外的消息注入能力。 */
export const inject = ['tools']

// ────────────────────────────────────────────────────────────────────────────
// 类型
// ────────────────────────────────────────────────────────────────────────────

interface DiskGuardConfig {
  /** 总开关 */
  enabled?: boolean
  /** 下载/产物目录：agent 保存下载、导出、安装包等大文件的地方 */
  downloadDir?: string
  /** 缓存根目录：临时文件、npm 缓存等 */
  cacheDir?: string
  /** 临时目录（默认 <cacheDir>/tmp） */
  tempDir?: string
  /** npm 缓存目录（默认 <cacheDir>/npm） */
  npmCacheDir?: string
  /** 外置 YAML 配置文件（优先级最高；支持 ~ 与 %VAR% 展开） */
  configFile?: string
  /** 是否把 TMP/TEMP/TMPDIR/npm_config_cache 重定向进本进程环境 */
  redirectEnv?: boolean
  /** 是否把同样内容追加进 $DSH_HOME/.env（user-env 层，供后续启动继承） */
  writeUserEnvFile?: boolean
  /** 是否向每个会话注入路径纪律提示词 */
  injectPrompt?: boolean
  /** 启动时是否清理 tempDir 中过期文件 */
  cleanupOnBoot?: boolean
  /** 清理阈值天数（默认 7） */
  maxAgeDays?: number
  /** DSH home 在 C 盘时是否告警 */
  warnC?: boolean
}

interface Resolved {
  enabled: boolean
  dshHome: string
  dshHomeOnC: boolean
  downloadDir: string
  cacheDir: string
  tempDir: string
  npmCacheDir: string
  configFile?: string
  redirectEnv: boolean
  writeUserEnvFile: boolean
  injectPrompt: boolean
  cleanupOnBoot: boolean
  maxAgeDays: number
  warnC: boolean
}

// ────────────────────────────────────────────────────────────────────────────
// 路径工具
// ────────────────────────────────────────────────────────────────────────────

/** 解析 DSH home：DSH_HOME 环境变量 > ~/.dsh（与 dsh-home-paths 一致） */
function resolveDshHome(): string {
  const env = process.env.DSH_HOME?.trim()
  return env ? resolve(env) : join(homedir(), '.dsh')
}

/** 展开 ~ 前缀与 %VAR% 占位符；返回绝对路径（不做 resolve，保持原样） */
function expandPath(p: string): string {
  let s = (p ?? '').trim()
  if (!s) return s
  if (s === '~') return homedir()
  if (s.startsWith('~/') || s.startsWith('~\\')) s = join(homedir(), s.slice(2))
  s = s.replace(/%([^%]+)%/g, (_, k: string) => process.env[k] ?? `%${k}%`)
  return s
}

/** 路径解析：绝对路径直接展开；相对路径以 base（默认 DSH home）为基准 */
function resolvePath(p: string, base: string): string {
  const expanded = expandPath(p)
  if (!expanded) return expanded
  return isAbsolute(expanded) ? resolve(expanded) : resolve(base, expanded)
}

/** 选出剩余空间最大的非 C 盘（至少 minFreeGB GB），没有则 null */
async function pickBestDataDrive(minFreeGB = 5): Promise<string | null> {
  const letters = 'DEFGHIJKLMNOPQRSTUVWXYZ'
  let best: { letter: string; free: bigint } | null = null
  const minFree = BigInt(minFreeGB) * 1024n ** 3n
  for (const l of letters) {
    try {
      const s = await statfs(`${l}:\\`)
      const free = s.bavail * s.bsize
      if (free > minFree && (!best || free > best.free)) best = { letter: l, free }
    } catch {
      /* 该盘不存在或不可访问，跳过 */
    }
  }
  return best?.letter ?? null
}

// ────────────────────────────────────────────────────────────────────────────
// 配置解析
// ────────────────────────────────────────────────────────────────────────────

const DEFAULTS = {
  enabled: true,
  redirectEnv: true,
  writeUserEnvFile: true,
  injectPrompt: true,
  cleanupOnBoot: false,
  maxAgeDays: 7,
  warnC: true,
}

/** 读外置 YAML 配置（不存在返回空对象；解析失败抛错并给出文件名） */
async function loadConfigFile(path: string): Promise<Partial<DiskGuardConfig>> {
  let raw: string
  try {
    raw = await readFile(path, 'utf8')
  } catch (e: any) {
    if (e?.code === 'ENOENT') return {}
    throw new Error(`[dsh-disk-guard] 无法读取配置文件 ${path}: ${e?.message ?? e}`)
  }
  try {
    const parsed = parseYaml(raw)
    return parsed && typeof parsed === 'object' ? (parsed as Partial<DiskGuardConfig>) : {}
  } catch (e: any) {
    throw new Error(`[dsh-disk-guard] 配置文件 YAML 解析失败 ${path}: ${e?.message ?? e}`)
  }
}

async function resolveConfig(config: DiskGuardConfig): Promise<Resolved> {
  const dshHome = resolveDshHome()

  // 合并优先级：默认 < patch 行配置 < 外置 configFile
  let fileCfg: Partial<DiskGuardConfig> = {}
  let configFile: string | undefined
  const cfgFileRaw = config?.configFile
  if (cfgFileRaw && String(cfgFileRaw).trim()) {
    configFile = resolvePath(String(cfgFileRaw), dshHome)
    fileCfg = await loadConfigFile(configFile)
  }
  const merged: DiskGuardConfig = { ...DEFAULTS, ...(config ?? {}), ...fileCfg }

  // 自动兜底：优先挑剩余空间最大的非 C 盘；只有 C 盘时落在 DSH home 旁并告警
  let downloadDir = merged.downloadDir ? resolvePath(merged.downloadDir, dshHome) : ''
  let cacheDir = merged.cacheDir ? resolvePath(merged.cacheDir, dshHome) : ''
  let autoOnC = false
  if (!downloadDir || !cacheDir) {
    const drive = await pickBestDataDrive(5)
    if (drive) {
      if (!downloadDir) downloadDir = resolve(`${drive}:\\dsh\\downloads`)
      if (!cacheDir) cacheDir = resolve(`${drive}:\\dsh\\cache`)
    } else {
      autoOnC = true
      if (!downloadDir) downloadDir = resolve(join(dshHome, '..', 'dsh-data', 'downloads'))
      if (!cacheDir) cacheDir = resolve(join(dshHome, '..', 'dsh-data', 'cache'))
    }
  }

  const tempDir = merged.tempDir ? resolvePath(merged.tempDir, dshHome) : join(cacheDir, 'tmp')
  const npmCacheDir = merged.npmCacheDir ? resolvePath(merged.npmCacheDir, dshHome) : join(cacheDir, 'npm')
  const homeUpper = dshHome.toUpperCase()

  return {
    enabled: merged.enabled !== false,
    dshHome,
    dshHomeOnC: homeUpper.startsWith('C:') || homeUpper === 'C' + '\\' + '.DSH',
    downloadDir,
    cacheDir,
    tempDir,
    npmCacheDir,
    configFile,
    redirectEnv: merged.redirectEnv !== false,
    writeUserEnvFile: merged.writeUserEnvFile !== false,
    injectPrompt: merged.injectPrompt !== false,
    cleanupOnBoot: merged.cleanupOnBoot === true,
    maxAgeDays: typeof merged.maxAgeDays === 'number' && merged.maxAgeDays > 0 ? Math.floor(merged.maxAgeDays) : 7,
    warnC: merged.warnC !== false,
    ...(autoOnC ? { autoOnC: true as boolean } : {}),
  }
}

// ────────────────────────────────────────────────────────────────────────────
// 环境重定向
// ────────────────────────────────────────────────────────────────────────────

function envPairs(r: Resolved): Array<[string, string]> {
  return [
    ['TMP', r.tempDir],
    ['TEMP', r.tempDir],
    ['TMPDIR', r.tempDir],
    ['npm_config_cache', r.npmCacheDir],
  ]
}

function applyEnvRedirect(r: Resolved): void {
  for (const [k, v] of envPairs(r)) {
    try {
      process.env[k] = v
    } catch {
      /* 只读环境变量（罕见）忽略 */
    }
  }
}

/** 把缺失的键追加进 $DSH_HOME/.env（user-env 层），不覆盖已有值 */
async function appendUserEnv(r: Resolved): Promise<void> {
  if (!r.writeUserEnvFile) return
  const file = join(r.dshHome, '.env')
  let existing = ''
  if (existsSync(file)) {
    try {
      existing = await readFile(file, 'utf8')
    } catch {
      return
    }
  }
  const keys = new Set(
    existing
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('#'))
      .map((l) => l.split('=')[0].trim().toUpperCase()),
  )
  const add: string[] = []
  for (const [k, v] of envPairs(r)) {
    if (!keys.has(k.toUpperCase())) add.push(`${k}=${v}`)
  }
  if (add.length === 0) return
  try {
    const sep2 = existing === '' || existing.endsWith('\n') ? '' : '\n'
    await appendFile(file, `${sep2}# dsh-disk-guard: 重定向临时/缓存环境变量\n${add.join('\n')}\n`)
  } catch (e: any) {
    throw new Error(`[dsh-disk-guard] 无法写入 ${file}: ${e?.message ?? e}`)
  }
}

// ────────────────────────────────────────────────────────────────────────────
// 目录体积与清理（有界遍历，绝不越界）
// ────────────────────────────────────────────────────────────────────────────

interface WalkStats {
  files: number
  bytes: number
  oldestMs: number
}

async function walkDir(root: string, maxEntries = 50000): Promise<WalkStats> {
  const stats: WalkStats = { files: 0, bytes: 0, oldestMs: Number.POSITIVE_INFINITY }
  let seen = 0
  async function walk(dir: string, depth: number): Promise<void> {
    if (depth > 6 || seen > maxEntries) return
    let entries: string[]
    try {
      entries = await readdir(dir, { withFileTypes: true })
    } catch {
      return
    }
    for (const ent of entries) {
      if (seen > maxEntries) return
      const full = join(dir, ent.name)
      try {
        if (ent.isDirectory()) {
          await walk(full, depth + 1)
        } else if (ent.isFile()) {
          seen++
          const st = await stat(full)
          stats.files++
          stats.bytes += st.size
          if (st.mtimeMs < stats.oldestMs) stats.oldestMs = st.mtimeMs
        }
      } catch {
        /* 单文件失败不影响统计 */
      }
    }
  }
  await walk(root, 0)
  return stats
}

async function removeOldFiles(root: string, olderThanDays: number, maxEntries = 50000): Promise<{ files: number; bytes: number }> {
  const cutoff = Date.now() - olderThanDays * 86400000
  let removed = 0
  let bytes = 0
  let seen = 0
  async function walk(dir: string, depth: number): Promise<void> {
    if (depth > 6 || seen > maxEntries) return
    let entries: string[]
    try {
      entries = await readdir(dir, { withFileTypes: true })
    } catch {
      return
    }
    for (const ent of entries) {
      if (seen > maxEntries) return
      const full = join(dir, ent.name)
      try {
        if (ent.isDirectory()) {
          await walk(full, depth + 1)
        } else if (ent.isFile()) {
          seen++
          const st = await stat(full)
          if (st.mtimeMs < cutoff) {
            await rm(full, { force: true })
            removed++
            bytes += st.size
          }
        }
      } catch {
        /* 跳过无法删除的 */
      }
    }
  }
  await walk(root, 0)
  return { files: removed, bytes }
}

// ────────────────────────────────────────────────────────────────────────────
// 提示词（路径纪律）——用户要的"提示词"
// ────────────────────────────────────────────────────────────────────────────

function buildPrompt(r: Resolved): string {
  const extra = r.dshHomeOnC
    ? `\n⚠️ 当前 DSH 数据主目录在 C 盘（${r.dshHome}）：请提醒用户运行插件自带的迁移脚本把 DSH_HOME 指到其他盘（` +
      `见插件 README 的 scripts/migrate-c-drive.ps1），否则会话/附件仍会占用 C 盘。`
    : ''
  return [
    '【磁盘守护 dsh-disk-guard · 路径纪律】（本条为插件注入，请严格遵守）',
    '',
    '1. 下载目录（默认下载/导出/安装包/产物/大文件保存处）：' + r.downloadDir,
    '2. 缓存目录：' + r.cacheDir,
    '   - 临时文件：' + r.tempDir,
    '   - npm 等包缓存：' + r.npmCacheDir,
    '3. 红线：禁止把任何大文件、下载、缓存或临时文件写到 C 盘',
    '   （包括 %TEMP%、C:\\Users\\*\\Temp、C:\\Windows\\Temp、用户目录、桌面、文档）。',
    '4. 用户说"下载/存到/缓存"却没给路径时，一律按第 1、2 条执行；',
    '   中间产物与临时文件放临时目录，用完后随手清理。',
    '5. 需要看磁盘占用/清理过期缓存时，调用工具 disk_guard（status / clean），不要瞎猜。',
    extra,
    '',
  ]
    .filter((l) => l !== '')
    .join('\n')
}

/** 外部覆盖文件：$DSH_HOME/disk-guard-prompt.md 存在则用之（完全替换默认提示词） */
async function loadPromptOverride(r: Resolved): Promise<string | null> {
  const file = join(r.dshHome, 'disk-guard-prompt.md')
  if (!existsSync(file)) return null
  try {
    const text = await readFile(file, 'utf8')
    return text.trim() || null
  } catch {
    return null
  }
}

// ────────────────────────────────────────────────────────────────────────────
// disk_guard 工具
// ────────────────────────────────────────────────────────────────────────────

function formatBytes(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let i = 0
  let v = n
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024
    i++
  }
  return `${v.toFixed(v >= 100 ? 0 : 1)} ${units[i]}`
}

function diskGuardTool(r: Resolved) {
  return {
    name: 'disk_guard',
    description:
      'DSH 磁盘守护：查看下载/缓存目录配置与磁盘占用（status）、清理过期缓存与临时文件（clean，仅限插件配置的目录，绝不动其他文件）、' +
      '或修改下载/缓存目录（set，需已配置外置 configFile）。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      required: ['action'],
      properties: {
        action: { type: 'string', enum: ['status', 'clean', 'set'], description: '操作：status=查看，clean=清理，set=修改目录' },
        scope: {
          type: 'string',
          enum: ['temp', 'npm', 'downloads', 'all'],
          description: 'clean 的作用域：temp=临时目录，npm=npm 缓存，downloads=下载目录（需 force），all=temp+npm',
        },
        force: { type: 'boolean', description: 'clean downloads 时必须为 true（删除下载产物属破坏性操作）' },
        olderThanDays: { type: 'number', description: '仅清理超过 N 天的文件；缺省用配置的 maxAgeDays' },
        downloadDir: { type: 'string', description: 'set 时的新下载目录（绝对路径或 ~ 开头）' },
        cacheDir: { type: 'string', description: 'set 时的新缓存目录（绝对路径或 ~ 开头）' },
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        required: ['ok', 'message'],
        properties: {
          ok: { type: 'boolean' },
          message: { type: 'string' },
          data: { type: 'object' },
        },
      },
      render: (_args: unknown, value: { message?: string }) => [{ type: 'text', text: String(value?.message ?? '') }],
    },
    async execute(args: Record<string, unknown>) {
      const action = String(args?.action ?? '')
      try {
        if (action === 'status') {
          const drives: Array<{ drive: string; freeGB: number }> = []
          for (const l of 'CDEFGHIJKLMNOPQRSTUVWXYZ') {
            try {
              const s = await statfs(`${l}:\\`)
              drives.push({ drive: `${l}:\\`, freeGB: Math.round((Number(s.bavail) * Number(s.bsize)) / 1e9) })
            } catch {
              /* 跳过 */
            }
          }
          const [temp, npm, dl, cache] = await Promise.all([
            walkDir(r.tempDir),
            walkDir(r.npmCacheDir),
            walkDir(r.downloadDir),
            walkDir(r.cacheDir),
          ])
          const lines = [
            `下载目录: ${r.downloadDir}（${formatBytes(dl.bytes)}，${dl.files} 个文件）`,
            `缓存目录: ${r.cacheDir}（${formatBytes(cache.bytes)}）`,
            `  临时目录: ${r.tempDir}（${formatBytes(temp.bytes)}，${temp.files} 个文件）`,
            `  npm 缓存: ${r.npmCacheDir}（${formatBytes(npm.bytes)}，${npm.files} 个文件）`,
            `DSH 主目录: ${r.dshHome}${r.dshHomeOnC ? ' ⚠️ 在 C 盘！建议迁移' : ''}`,
            '各盘剩余: ' + drives.map((d) => `${d.drive} ${d.freeGB}GB`).join('，'),
          ]
          return {
            ok: true,
            message: lines.join('\n'),
            data: {
              downloadDir: r.downloadDir,
              cacheDir: r.cacheDir,
              tempDir: r.tempDir,
              npmCacheDir: r.npmCacheDir,
              dshHome: r.dshHome,
              dshHomeOnC: r.dshHomeOnC,
              drives,
              sizes: { temp: temp.bytes, npm: npm.bytes, downloads: dl.bytes, cache: cache.bytes },
            },
          }
        }

        if (action === 'clean') {
          const days =
            typeof args?.olderThanDays === 'number' && (args.olderThanDays as number) > 0
              ? Math.floor(args.olderThanDays as number)
              : r.maxAgeDays
          const scope = String(args?.scope ?? 'temp')
          const force = args?.force === true
          const targets: Array<{ label: string; dir: string; needForce: boolean }> = []
          if (scope === 'temp' || scope === 'all') targets.push({ label: '临时目录', dir: r.tempDir, needForce: false })
          if (scope === 'npm' || scope === 'all') targets.push({ label: 'npm 缓存', dir: r.npmCacheDir, needForce: false })
          if (scope === 'downloads') targets.push({ label: '下载目录', dir: r.downloadDir, needForce: true })
          if (targets.length === 0) return { ok: false, message: `未知 scope: ${scope}` }
          const blocked = targets.filter((t) => t.needForce && !force)
          if (blocked.length > 0) {
            return {
              ok: false,
              message: `${blocked.map((t) => t.label).join('、')} 是用户产物，删除需显式确认：请传 force: true 再执行。`,
            }
          }
          let totalFiles = 0
          let totalBytes = 0
          for (const t of targets) {
            const res = await removeOldFiles(t.dir, days)
            totalFiles += res.files
            totalBytes += res.bytes
          }
          return {
            ok: true,
            message: `已清理超过 ${days} 天的文件：${totalFiles} 个，共 ${formatBytes(totalBytes)}（scope=${scope}）。`,
            data: { removedFiles: totalFiles, removedBytes: totalBytes, scope, olderThanDays: days },
          }
        }

        if (action === 'set') {
          if (!r.configFile) {
            return {
              ok: false,
              message:
                '未配置外置 configFile，无法持久化修改。请在插件 cordis.patch.yml 的 config 里加 configFile 指向 ~/.dsh/disk-guard.yaml（参考 config.example.yaml），或直接编辑 cordis.patch.yml 里的 downloadDir/cacheDir 后重启。',
            }
          }
          const dl = args?.downloadDir ? resolvePath(String(args.downloadDir), r.dshHome) : undefined
          const ca = args?.cacheDir ? resolvePath(String(args.cacheDir), r.dshHome) : undefined
          if (!dl && !ca) return { ok: false, message: 'set 需要至少给 downloadDir 或 cacheDir 之一。' }
          const merged: Partial<DiskGuardConfig> = {}
          if (dl) merged.downloadDir = dl
          if (ca) merged.cacheDir = ca
          // 保留原文件里的其他键
          let base: Record<string, unknown> = {}
          try {
            const raw = await readFile(r.configFile!, 'utf8')
            const parsed = parseYaml(raw)
            if (parsed && typeof parsed === 'object') base = parsed as Record<string, unknown>
          } catch {
            /* 不存在或解析失败按空处理 */
          }
          // 先确保新目录可创建，再持久化配置，避免"配置已改但目录没建成"的中间态
          const nextDl = dl ?? r.downloadDir
          const nextCache = ca ?? r.cacheDir
          const nextTemp = join(nextCache, 'tmp')
          const nextNpm = join(nextCache, 'npm')
          await mkdir(nextDl, { recursive: true })
          await mkdir(nextCache, { recursive: true })
          await mkdir(nextTemp, { recursive: true })
          await mkdir(nextNpm, { recursive: true })
          const next = { ...base, ...merged }
          await writeFile(r.configFile!, `# dsh-disk-guard 配置（disk_guard set 会更新本文件）\n` + toYaml(next), 'utf8')
          if (dl) r.downloadDir = dl
          if (ca) {
            r.cacheDir = ca
            r.tempDir = nextTemp
            r.npmCacheDir = nextNpm
          }
          applyEnvRedirect(r)
          return {
            ok: true,
            message: `已更新配置并生效：下载=${r.downloadDir}，缓存=${r.cacheDir}（写入 ${r.configFile}）。新会话的提示词将使用新路径。`,
            data: { downloadDir: r.downloadDir, cacheDir: r.cacheDir, configFile: r.configFile },
          }
        }

        return { ok: false, message: `未知 action: ${action}` }
      } catch (e: any) {
        return { ok: false, message: `disk_guard ${action} 失败: ${e?.message ?? e}` }
      }
    },
    presentCall(args: Record<string, unknown>) {
      return { card: 'generic', title: `disk_guard: ${String(args?.action ?? '')}`, kind: 'read' }
    },
  }
}

/** 极简 YAML 输出（仅需覆盖字符串键值，不追求通用性） */
function toYaml(obj: Record<string, unknown>): string {
  return Object.entries(obj)
    .map(([k, v]) => {
      if (v === undefined || v === null) return `${k}:`
      if (typeof v === 'boolean' || typeof v === 'number') return `${k}: ${v}`
      const s = String(v)
      const needsQuote = /[:#\n]|^\s|\s$/.test(s)
      return `${k}: ${needsQuote ? JSON.stringify(s) : s}`
    })
    .join('\n')
}

// ────────────────────────────────────────────────────────────────────────────
// 插件主体
// ────────────────────────────────────────────────────────────────────────────

export async function apply(ctx: any, config: DiskGuardConfig) {
  let r: Resolved
  try {
    r = await resolveConfig(config)
  } catch (e: any) {
    ctx.logger.warn(`[dsh-disk-guard] 配置解析失败，插件跳过：${e?.message ?? e}`)
    return
  }
  if (!r.enabled) {
    ctx.logger.info('[dsh-disk-guard] 已按配置禁用')
    return
  }

  // 建目录
  for (const d of [r.downloadDir, r.cacheDir, r.tempDir, r.npmCacheDir]) {
    try {
      await mkdir(d, { recursive: true })
    } catch (e: any) {
      ctx.logger.warn(`[dsh-disk-guard] 创建目录失败 ${d}: ${e?.message ?? e}`)
    }
  }

  // 环境重定向
  if (r.redirectEnv) {
    applyEnvRedirect(r)
    ctx.logger.info(`[dsh-disk-guard] 环境重定向：TMP/TEMP/TMPDIR=${r.tempDir}，npm_config_cache=${r.npmCacheDir}`)
  }
  if (r.writeUserEnvFile) {
    try {
      await appendUserEnv(r)
      ctx.logger.info(`[dsh-disk-guard] 已同步 ${join(r.dshHome, '.env')}（user-env 层）`)
    } catch (e: any) {
      ctx.logger.warn(`[dsh-disk-guard] 写入 .env 失败：${e?.message ?? e}`)
    }
  }

  // 启动清理（可选）
  if (r.cleanupOnBoot) {
    try {
      const res = await removeOldFiles(r.tempDir, r.maxAgeDays)
      if (res.files > 0) ctx.logger.info(`[dsh-disk-guard] 启动清理：删除 ${res.files} 个过期临时文件（${formatBytes(res.bytes)}）`)
    } catch (e: any) {
      ctx.logger.warn(`[dsh-disk-guard] 启动清理失败：${e?.message ?? e}`)
    }
  }

  // 注册 disk_guard 工具
  try {
    ctx.effect(() => ctx.tools.register(diskGuardTool(r)))
    ctx.logger.info('[dsh-disk-guard] 工具 disk_guard 已注册（status / clean / set）')
  } catch (e: any) {
    ctx.logger.warn(`[dsh-disk-guard] 注册工具失败：${e?.message ?? e}`)
  }

  // 提示词注入：每个会话首条用户消息前插入路径纪律
  if (r.injectPrompt) {
    const promptOverride = await loadPromptOverride(r)
    const promptText = promptOverride ?? buildPrompt(r)
    const firstHandled = new Set<string>()
    ctx.on('agent/pre-step', async ({ agent, messages, signal }: any, next: any) => {
      try {
        const decision = await next()
        if (!decision || decision.kind !== 'enter' || signal?.aborted) return decision
        const msgs = decision.messages
        if (!msgs || msgs.length === 0) return decision
        // 只注入主代理会话，跳过子代理，避免刷屏
        if (agent?.session?.header?.origin === 'subagent') return decision
        const sid = agent?.session?.id ?? 'unknown'
        if (firstHandled.has(sid)) return decision
        const userMsgs = msgs.filter((m: any) => m?.source?.kind === 'user')
        if (userMsgs.length === 0) return decision
        let priorUser = 0
        for (const e of agent?.session?.events ?? []) if (e?.type === 'user/message') priorUser++
        if (priorUser > 0) return decision
        firstHandled.add(sid)
        const first = userMsgs[0]
        const rewritten = msgs.map((m: any) =>
          m === first ? { ...m, content: [{ type: 'text', text: promptText }, ...(m.content ?? [])] } : m,
        )
        ctx.logger.info(`[dsh-disk-guard] 已向会话 ${sid} 注入路径纪律提示词（${promptText.length} 字符）`)
        return { ...decision, messages: rewritten }
      } catch (e: any) {
        ctx.logger.warn(`[dsh-disk-guard] pre-step 注入失败：${e?.message ?? e}`)
        return undefined
      }
    })
  }

  // 启动横幅
  ctx.logger.info(
    `[dsh-disk-guard] 就绪 ── 下载=${r.downloadDir} | 缓存=${r.cacheDir} | 临时=${r.tempDir} | home=${r.dshHome}${r.dshHomeOnC ? ' ⚠️ home 在 C 盘' : ''}`,
  )
  if (r.warnC && r.dshHomeOnC) {
    ctx.logger.warn(
      `[dsh-disk-guard] 警告：DSH 主目录 ${r.dshHome} 位于 C 盘。建议把 DSH_HOME 环境变量设到其他盘（如 E:\\dsh-home）并迁移数据，运行插件自带 scripts/migrate-c-drive.ps1 可一键完成。`,
    )
  }
}

export default { name, inject, apply }