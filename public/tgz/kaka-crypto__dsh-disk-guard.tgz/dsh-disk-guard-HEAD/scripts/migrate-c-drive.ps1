﻿# dsh-disk-guard 迁移脚本：把 DSH home 从 C 盘搬到其他盘
# 用法：
#   powershell -ExecutionPolicy Bypass -File scripts\migrate-c-drive.ps1            # 只体检+提示
#   powershell -ExecutionPolicy Bypass -File scripts\migrate-c-drive.ps1 -MoveData  # 设置 DSH_HOME 并迁移数据
#   powershell -ExecutionPolicy Bypass -File scripts\migrate-c-drive.ps1 -MoveData -DeleteOld -Force  # 全自动（删旧+清临时）
# 注意：请先退出 DSH 再迁移；-DeleteOld 会删除 C 盘旧 ~/.dsh（迁移+校验后）。
[CmdletBinding()]
param(
  [string]$NewHome = '',
  [switch]$MoveData,
  [switch]$DeleteOld,
  [switch]$CleanTemp,
  [switch]$Force
)
$ErrorActionPreference = 'Stop'

function Confirm-Yes {
  param([string]$Prompt)
  if ($Force) { return $true }
  $r = Read-Host "$Prompt [y/N]"
  return ($r -eq 'y' -or $r -eq 'Y')
}

function Pick-DataDrive {
  $c = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Name -ne 'C' -and $_.Free -gt 10GB } | Sort-Object Free -Descending
  if ($c) { return $c[0].Name }
  return $null
}

$oldHome = if ($env:DSH_HOME -and $env:DSH_HOME.Trim()) { $env:DSH_HOME.Trim() } else { Join-Path $HOME '.dsh' }
$oldOnC = $oldHome -match '^C:\\'

Write-Host '== DSH home 迁移体检 =='
Write-Host ("当前 DSH home: " + $oldHome + ($(if ($oldOnC) { '  ⚠️ 在 C 盘' } else { '  ✓ 不在 C 盘' })))

if (-not $oldOnC) {
  Write-Host 'DSH home 已不在 C 盘，无需迁移。'
  if ($CleanTemp) { Write-Host '如需清理 C 盘临时文件，请手动执行: Remove-Item $env:TEMP\* -Recurse -Force' }
  exit 0
}

if (-not $MoveData) {
  Write-Host ''
  Write-Host '检测到 DSH home 在 C 盘。'
  $oldSizeMB = [math]::Round((Get-ChildItem $oldHome -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum / 1MB, 1)
  Write-Host ('  会话/附件/任务板/皮肤缓存等约占用: ' + $oldSizeMB + ' MB')
  Write-Host '迁移步骤（加 -MoveData 执行）：'
  Write-Host '  1) 退出 DSH'
  Write-Host '  2) 本脚本会把 DSH_HOME 设为其他盘并 robocopy 迁移数据'
  Write-Host '  3) 确认无误后再用 -DeleteOld 删除 C 盘旧数据'
  Write-Host '一键全自动：powershell -ExecutionPolicy Bypass -File scripts\migrate-c-drive.ps1 -MoveData -DeleteOld -Force'
  exit 0
}

# 目标目录
if (-not $NewHome) {
  $drive = Pick-DataDrive
  if (-not $drive) { throw '没有可用的非 C 盘（剩余 >=10GB），请用 -NewHome 指定目标。' }
  $NewHome = "${drive}:\dsh-home"
}
New-Item -ItemType Directory -Force -Path $NewHome | Out-Null
Write-Host ("目标 DSH home: " + $NewHome)

# 迁移数据
if (Test-Path $oldHome) {
  $sizeMB = [math]::Round((Get-ChildItem $oldHome -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum / 1MB, 1)
  Write-Host ("旧数据约 " + $sizeMB + " MB，开始 robocopy ...")
  robocopy $oldHome $NewHome /E /COPY:DAT /R:1 /W:1 /NFL /NDL /NP
  if ($LASTEXITCODE -ge 8) { throw "robocopy 出错（exit=$LASTEXITCODE），迁移中止，未删除旧数据。" }
  Write-Host '迁移完成。'
} else {
  Write-Host '旧 home 不存在，跳过数据迁移。'
}

# 设置 DSH_HOME（用户级持久 + 当前进程）
setx DSH_HOME $NewHome | Out-Null
$env:DSH_HOME = $NewHome
Write-Host '已设置用户级环境变量 DSH_HOME（setx）。新开的终端/重启 DSH 后生效。'

# 删除旧数据
if ($DeleteOld -and (Test-Path $oldHome)) {
  if (Confirm-Yes -Prompt "确认删除 C 盘旧数据 $oldHome ？") {
    Remove-Item $oldHome -Recurse -Force
    Write-Host '旧 C 盘数据已删除。'
  } else {
    Write-Host '跳过删除，旧数据保留。'
  }
}

# 清理 C 盘临时文件
if ($CleanTemp) {
  $tmp = $env:TEMP
  if ($tmp -and (Test-Path $tmp)) {
    $tmb = [math]::Round((Get-ChildItem $tmp -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum / 1MB, 1)
    Write-Host ("%TEMP% 当前占用约 " + $tmb + " MB: " + $tmp)
    if (Confirm-Yes -Prompt '删除 %TEMP% 里所有文件/子目录？（运行中的程序可能占用个别文件，会跳过）') {
      Get-ChildItem $tmp -Force -ErrorAction SilentlyContinue | ForEach-Object {
        try { Remove-Item $_.FullName -Recurse -Force -ErrorAction Stop } catch { }
      }
      Write-Host '%TEMP% 已清理（占用中的文件跳过）。'
    }
  }
}

Write-Host ''
Write-Host '== 完成 =='
Write-Host '重启 DSH 后生效。首次启动会看到 [dsh-disk-guard] 就绪 日志；'
Write-Host '若旧 DSH 进程还在运行，请先退出再重启。'
