﻿# dsh-disk-guard 一键安装脚本
# 用法：
#   powershell -ExecutionPolicy Bypass -File scripts\install.ps1
#   powershell -ExecutionPolicy Bypass -File scripts\install.ps1 -DownloadDir 'E:\dsh\downloads' -CacheDir 'E:\dsh\cache'
# 参数：
#   -PluginSource   插件包目录（含 package.json），默认脚本所在目录的上一级
#   -ProfileDir     dsh profile 目录，默认 $DSH_HOME\profiles\web
#   -DownloadDir    下载目录（缺省自动挑剩余空间最大的非 C 盘）
#   -CacheDir       缓存目录（缺省自动挑）
#   -SkipPnpmInstall 跳过 pnpm install
[CmdletBinding()]
param(
  [string]$PluginSource = '',
  [string]$ProfileDir = '',
  [string]$DownloadDir = '',
  [string]$CacheDir = '',
  [switch]$SkipPnpmInstall
)
$ErrorActionPreference = 'Stop'

function Write-NoBom {
  param([string]$Path, [string]$Content)
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

function Pick-DataDrive {
  $c = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Name -ne 'C' -and $_.Free -gt 5GB } | Sort-Object Free -Descending
  if ($c) { return $c[0].Name }
  return $null
}

Write-Host '== dsh-disk-guard 安装 =='

# 1. 定位插件源码
$src = if ($PluginSource) { $PluginSource } else { Join-Path $PSScriptRoot '..' }
$src = (Resolve-Path $src).Path
if (-not (Test-Path (Join-Path $src 'package.json'))) { throw "插件包目录无效（缺 package.json）: $src" }
Write-Host ("插件源码: " + $src)

# 2. DSH home 与 profile
$dshHome = if ($env:DSH_HOME -and $env:DSH_HOME.Trim()) { $env:DSH_HOME.Trim() } else { Join-Path $HOME '.dsh' }
if ($dshHome -match '^C:\\') {
  Write-Warning "DSH home 在 C 盘: $dshHome。会话/附件会继续占 C 盘，强烈建议先运行 scripts\migrate-c-drive.ps1 迁移。"
}
if (-not $ProfileDir) { $ProfileDir = Join-Path $dshHome 'profiles\web' }
if (-not (Test-Path (Join-Path $ProfileDir 'package.json'))) { throw "profile 目录无效（缺 package.json）: $ProfileDir" }
Write-Host ("profile: " + $ProfileDir)

# 3. 计算下载/缓存目录
$drive = Pick-DataDrive
if (-not $DownloadDir) {
  $DownloadDir = if ($drive) { "${drive}:\dsh\downloads" } else { Join-Path $dshHome '..\dsh-data\downloads' }
}
if (-not $CacheDir) {
  $CacheDir = if ($drive) { "${drive}:\dsh\cache" } else { Join-Path $dshHome '..\dsh-data\cache' }
}
Write-Host ("下载目录: " + $DownloadDir)
Write-Host ("缓存目录: " + $CacheDir)

# 4. 拷贝到 profile vendor
$vendor = Join-Path $ProfileDir 'vendor\dsh-disk-guard'
$srcResolved = (Resolve-Path $src).Path
$vendorResolved = (Resolve-Path $vendor -ErrorAction SilentlyContinue).Path
if (-not $vendorResolved -or $srcResolved -ne $vendorResolved) {
  if (Test-Path $vendor) { Remove-Item $vendor -Recurse -Force }
  New-Item -ItemType Directory -Force -Path (Split-Path $vendor) | Out-Null
  Copy-Item $src $vendor -Recurse
}
# 清理拷贝里的构建缓存
Remove-Item (Join-Path $vendor 'node_modules') -Recurse -Force -ErrorAction SilentlyContinue

# 5. 确保已构建 lib/index.js
if (-not (Test-Path (Join-Path $vendor 'lib\index.js'))) {
  Write-Host '未发现 lib/index.js，自动构建（npm install esbuild yaml && node build.mjs）...'
  Push-Location $vendor
  try {
    npm install --no-save esbuild | Out-Null
    node build.mjs
  } finally { Pop-Location }
  if (-not (Test-Path (Join-Path $vendor 'lib\index.js'))) { throw '构建失败，请手动在插件目录执行: npm install --no-save esbuild && node build.mjs' }
}

# 6. 生成外置配置文件并接进 patch
$cfgFile = Join-Path $dshHome 'disk-guard.yaml'
$cfgContent = @"
# dsh-disk-guard 配置（install.ps1 生成；以后改目录直接改这个文件，重启生效；
# 会话内可用 disk_guard set 即时生效）
downloadDir: '${DownloadDir}'
cacheDir: '${CacheDir}'
"@
Write-NoBom -Path $cfgFile -Content $cfgContent
Write-Host ("外置配置: " + $cfgFile)

$patchFile = Join-Path $vendor 'cordis.patch.yml'
$lines = @(Get-Content -LiteralPath $patchFile)
if (-not ($lines | Where-Object { $_ -match '^\s*configFile:' })) {
  $idx = -1
  for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\s+redirectEnv:') { $idx = $i; break }
  }
  if ($idx -ge 0) {
    $cfgFileEsc = $cfgFile.Replace('\', '\\')
    $newLine = "        configFile: '${cfgFileEsc}'"
    $newLines = New-Object System.Collections.Generic.List[string]
    for ($i = 0; $i -lt $lines.Count; $i++) {
      if ($i -eq $idx) { $newLines.Add($newLine) }
      $newLines.Add($lines[$i])
    }
    Write-NoBom -Path $patchFile -Content ($newLines -join [Environment]::NewLine)
    Write-Host '已把 configFile 接入 vendor/cordis.patch.yml'
  }
}

# 7. 接线 profile package.json（依赖 + bundles）
$pjPath = Join-Path $ProfileDir 'package.json'
$pj = Get-Content -LiteralPath $pjPath -Raw | ConvertFrom-Json
if (-not $pj.dependencies.'dsh-disk-guard') {
  $pj.dependencies | Add-Member -NotePropertyName 'dsh-disk-guard' -NotePropertyValue 'file:vendor\\dsh-disk-guard' -Force
  Write-Host '已添加依赖 dsh-disk-guard (file:vendor)'
}
if (-not ($pj.dsh.profile.bundles -contains 'dsh-disk-guard')) {
  $pj.dsh.profile.bundles += 'dsh-disk-guard'
  Write-Host '已把 dsh-disk-guard 加入 bundles'
}
Write-NoBom -Path $pjPath -Content ($pj | ConvertTo-Json -Depth 20)

# 8. pnpm install
if (-not $SkipPnpmInstall) {
  Write-Host '== pnpm install =='
  Push-Location $ProfileDir
  try { pnpm install } finally { Pop-Location }
  if ($LASTEXITCODE -ne 0) { throw 'pnpm install 失败，请手动在 profile 目录执行 pnpm install' }
}

# 9. skill
$skillDir = Join-Path $dshHome 'skills\disk-guard'
New-Item -ItemType Directory -Force -Path $skillDir | Out-Null
Copy-Item (Join-Path $vendor 'SKILL.md') (Join-Path $skillDir 'SKILL.md') -Force
Write-Host ("技能已安装: " + $skillDir)

Write-Host ''
Write-Host '== 安装完成 =='
Write-Host '下一步：重启 DSH（web GUI / headless）。启动日志出现 [dsh-disk-guard] 就绪 即生效；'
Write-Host '每个会话首条消息前会自动注入路径纪律提示词。改目录请编辑:'
Write-Host ('  ' + $cfgFile)
Write-Host '或在会话里调用 disk_guard set。'