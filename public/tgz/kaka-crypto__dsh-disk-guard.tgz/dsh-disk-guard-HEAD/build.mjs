/**
 * dsh-disk-guard 构建脚本（esbuild）：src/index.ts -> lib/index.js。
 * yaml 依赖打进 bundle，运行期零第三方依赖。
 * 用法：npm install（或 pnpm install --no-save esbuild yaml）后 node build.mjs
 */
import { build, context } from 'esbuild'
import { fileURLToPath } from 'node:url'

const watch = process.argv.includes('--watch')

const nodePaths = [fileURLToPath(new URL('./node_modules', import.meta.url))]

const hostOptions = {
  entryPoints: ['src/index.ts'],
  bundle: true,
  platform: 'node',
  format: 'esm',
  target: 'node22',
  nodePaths,
  outfile: 'lib/index.js',
  sourcemap: true,
  logLevel: 'info',
  external: ['yaml'], // 运行时从 profile node_modules 解析（nodeLinker: hoisted）
}

if (watch) {
  await (await context(hostOptions)).watch()
  console.log('[build] watching src/ for changes...')
} else {
  await build(hostOptions)
  console.log('[build] lib/index.js built')
}