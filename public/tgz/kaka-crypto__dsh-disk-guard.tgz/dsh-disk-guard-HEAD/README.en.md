# dsh-disk-guard

Disk guard for DeepSeek Harness (DSH): redirects downloads, artifacts, caches and temp files off the C: drive to user-specified directories (auto-picks the largest non-C drive by default), injects a path-discipline prompt into every session, and ships a `disk_guard` tool for status and cleanup.

## Features

| Capability | Description |
|---|---|
| Download directory | `downloadDir`: all downloads/exports/installers/artifacts land here |
| Cache directory | `cacheDir` (temp under `<cacheDir>/tmp`, npm cache under `<cacheDir>/npm`) |
| Smart default | no config - auto-picks the largest non-C drive (>=5 GB free) |
| Env redirect | `TMP/TEMP/TMPDIR` -> temp dir, `npm_config_cache` -> npm cache (inherited by bash/pwsh subprocesses); synced into `$DSH_HOME/.env` so every launch inherits |
| Prompt injection | a path-discipline block is prepended to the first user message of every session |
| Built-in tool | `disk_guard`: `status` (paths / free space / dir sizes), `clean` (expired caches; downloads require `force:true`), `set` (change dirs, persisted, instant) |
| C-drive check | warns at boot when `$DSH_HOME` is on C:, ships a one-command migration script |

## Install

```sh
# inside the repo (after building lib/index.js):
powershell -ExecutionPolicy Bypass -File scripts\install.ps1
# or with explicit dirs:
powershell -ExecutionPolicy Bypass -File scripts\install.ps1 -DownloadDir 'E:\dsh\downloads' -CacheDir 'E:\dsh\cache'
```

The script copies the plugin into `<profile>/vendor/dsh-disk-guard`, writes `$DSH_HOME/disk-guard.yaml` (the file you edit to change dirs), wires it into the profile's `package.json` (dependency + `dsh.profile.bundles`), runs `pnpm install`, and installs the `disk-guard` skill. Restart DSH and watch for `[dsh-disk-guard] 就绪` in the log.

## Configuration

Priority: **external YAML > patch config > defaults**.

- External file (recommended): `$DSH_HOME/disk-guard.yaml`
```yaml
downloadDir: 'E:\dsh\downloads'
cacheDir: 'E:\dsh\cache'
```
- Patch config: the `config:` block in `cordis.patch.yml` (`configFile` points at the external file).
- Paths support `~` and `%VAR%`; relative paths resolve against the DSH home.

## The prompt (injected per session)

Every session gets, before its first user message:

> 【磁盘守护 dsh-disk-guard · 路径纪律】1. 下载目录 = <downloadDir>; 2. 缓存目录 = <cacheDir> (temp <tempDir>, npm <npmCacheDir>); 3. 红线：禁止向 C 盘写大文件/缓存/临时文件; 4. 用户没给路径时按 1、2 执行; 5. 查磁盘/清理用 disk_guard。

To fully customize, put your own text in `$DSH_HOME/disk-guard-prompt.md`.

## Migrate DSH home off C:

```sh
powershell -ExecutionPolicy Bypass -File scripts\migrate-c-drive.ps1 -MoveData -DeleteOld -Force
```

## Design

- Zero runtime third-party deps (yaml is external, resolved from the profile).
- Cleanup is strictly bounded to the plugin's own configured directories.
- Prompt injected once per session (deduped by session id, skips subagents).
- Any failure is logged, never breaks DSH.

## License

MIT