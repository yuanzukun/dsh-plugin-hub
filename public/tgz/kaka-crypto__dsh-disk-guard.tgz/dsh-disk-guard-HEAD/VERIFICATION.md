# dsh-disk-guard · 验证报告（2026-08-28）

## 环境
- DSH 安装：E:\Git\npm-global\node_modules\@deepseek-ai\dsh（v0.1.1-rc.2，Cordis profile 架构）
- DSH home：E:\Git\dsh-home（DSH_HOME）
- profile：profiles/web（本 GUI 宿主）
- 盘况：C 136GB/199GB，D 4GB（近满），E 194GB/200GB

## 机制研究结论（主代理 + 两个研究子代理交叉验证）
1. **DSH_HOME 解析**：显式配置 > $DSH_HOME 环境变量 > %USERPROFILE%\.dsh（@deepseek-ai/dsh-home-paths）。未设 DSH_HOME 时，sessions/attachments/task-board/storages/skin-center/profiles node_modules 全落 C 盘。
2. **插件 = npm 包**：package.json 的 dsh.bundle.patch 指向 cordis.patch.yml（insert 服务行），main 导出 {name, inject, apply} 的 Cordis 插件；profile package.json 加依赖 + bundles 后 pnpm install 装载。
3. **提示词注入**：agent/pre-step 事件在首条用户消息前拼接文本（meow-memory 同款模式，会话 id 去重、跳过子代理）。
4. **环境重定向**：插件进程设置 process.env 可透传到 bash/pwsh 子进程（dsh-subprocess 只清洗凭据类与 DSH_* 变量）；$DSH_HOME/.env 是 dsh-launch-environment 的 user-env 层，持久化给后续启动。
5. **技能**：$DSH_HOME/skills/<name>/SKILL.md（frontmatter name/description），skill-filesystem 实时发现。

## 验证结果
| 项 | 结果 |
|---|---|
| esbuild 构建（yaml external，22KB） | ✅ lib/index.js |
| 冒烟：环境重定向 TMP/TEMP/TMPDIR/npm_config_cache | ✅ E:\dsh\cache\tmp / npm |
| 冒烟：自动挑盘 → E:\dsh\downloads、E:\dsh\cache | ✅（E 最大） |
| 冒烟：disk_guard status/clean 输出 | ✅ |
| 冒烟：clean downloads 无 force 被拦截 | ✅（安全护栏） |
| 冒烟：pre-step 提示词注入（首条用户消息） | ✅ 含"路径纪律" |
| disk_guard set：先建目录再写外置配置、即时生效 | ✅（配置转义正确） |
| 安装：vendor 拷贝 + package.json 依赖/bundles + disk-guard.yaml + 技能 | ✅ |
| 配置树接线（--dump-config） | ✅ - id: dsh-disk-guard |
| 宿主解析（node_modules → vendor lib） | ✅ 三处哈希一致 |
| 技能实时发现 | ✅ available_skills 出现 disk-guard |
| pnpm install | ✅ --config.minimum-release-age=0（profile 既有 supply-chain 策略） |

## 遗留
- 插件服务行需**重启 GUI**（web profile）后随 bundle 装载（本会话无法自重启，避免中断宿主）；技能与配置已即时生效。
- profile package.json 由脚本 ConvertTo-Json 重写，格式变化但 JSON 语义不变（已备份 bak-disk-guard-*）。
