<div align="center">

# dsh-purge · lite

**给 DeepSeek Harness 换上你自己的 system prompt。**

一个只做两件事的插件：把注入正文塞进 `system prompt`，再给宿主打上让它生效的补丁。除此之外的模块全部不存在。

[![license](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](LICENSE)
[![version](https://img.shields.io/badge/version-1.5.3--lite-success.svg)](CHANGELOG.md)
[![node](https://img.shields.io/badge/node-%3E%3D18-brightgreen.svg)](https://nodejs.org)
[![patches](https://img.shields.io/badge/host%20patches-84-informational.svg)](#工作原理)
[![platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey.svg)](#兼容性)

</div>

---

## 目录

- [这是什么](#这是什么)
- [设计取舍](#设计取舍)
- [安装](#安装)
- [升级](#升级)
- [快速开始](#快速开始)
- [配置](#配置)
- [命令](#命令)
- [HTTP 接口](#http-接口)
- [工作原理](#工作原理)
- [目录结构](#目录结构)
- [兼容性](#兼容性)
- [版本支持矩阵](#版本支持矩阵)
- [常见问题](#常见问题)
- [已知限制](#已知限制)
- [版本](#版本)
- [上游与许可](#上游与许可)

---

## 这是什么

DeepSeek Harness（下称 DSH）在每次请求前会装配 `system prompt`：宿主身份段 + 插件段 + 工具说明。这个插件把这段装配结果按你的意愿重写——用你写的正文替换掉宿主正文，并在尾部挂一个锚点，保证多轮之后注入仍然生效。

它不是"提示词管理器"。没有演练台、没有资产库、没有技能库、没有规则面板、没有在线更新。**设置页只有一个只读状态面板。**

| 做 | 不做 |
|---|---|
| 把 `prompt-inject.md` 的正文挂到 system prompt 最前 | 管理多个提示词模板 |
| 改写 `system-prompt/assemble`，清空宿主身份段 | 提供联网检索、向量库、记忆抽取 |
| 给宿主打 84 条补丁，让审批门与沙箱按配置走 | 绕过服务端的模型侧策略 |
| 提供 `/purge` 命令、CLI 与 HTTP 接口做状态查询与开关 | 在线自动更新（升级 = 重新下载） |

## 设计取舍

这类插件常见的写法是"什么都塞进来"，结果是 1.2 MB 源码里有 300 KB 是死代码，升级一次就崩一次。本仓库反过来：

- **只保留两件事**。任何与"注入 + 补丁"无关的模块都不进代码树。1.2.0 相对 1.1.90 删掉了 13 个模块、约 170 KB，补丁表从 86 条降到 84 条。
- **不落第二份数据**。正文只认 `$DSH_HOME/prompt-inject.md` 这一个文件，不写数据库、不做同步副本。
- **补丁可逆**。所有宿主改动先备份原文，`--revert` 逐条还原；还原失败会中止卸载而不是留半截。
- **失败要吵**。补丁漂移（宿主升级后原文变了、pattern 匹配不上）会明确标记为 `drifted`，而不是静默跳过。

## 安装

> 需要 Node.js ≥ 18，宿主 DeepSeek Harness 支持范围 **0.2.1-rc.2 ～ 0.2.2-rc.1**（`engines.dsh: >=0.2.1-rc.2 <0.2.3-0`，插件市场据此显示宿主要求）。**1.5.1-lite 起，84 条补丁表覆盖这三个宿主版本**（1.4.2-lite 及更早版本在 0.2.2-rc.1 上有 11 条失配，功能不完整，详见[版本支持矩阵](#版本支持矩阵)）。补丁表覆盖不等于已经落到宿主上——安装后仍需执行一次 `--apply`，见下方「必读」。下文 `<DSH_HOME>` 默认是 `~/.dsh`（Windows 为 `%USERPROFILE%\.dsh`）。

**已加入插件市场**：本插件已收录进 [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin) 插件目录（[PR #12160](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/12160)，2026-11-07 合并）。在 DSH 内置插件市场搜索 `Nero0427/dsh-purge-lite`，点卡片上的安装即可；市场安装走 `github:` 仓库源，等价于下面的方式三，也能正常收到更新提示。

### 必读：补丁不会随插件自动生效

插件包里带的是**补丁表**（`lib/core.js` 的 `ALL_PATCHES`），不是"已经打好的宿主"。表里是 pattern 与替换文本，必须由 `--apply` 写进宿主文件才生效——它是本地文件改写，不是运行时 hook。

- **默认不自动打补丁**：`autoApplyOnStart` 默认 `false`。装上插件、重启 DSH，注入正文能生效（那是运行时读的），但 84 条宿主补丁一条都没动。
- **手动执行一次**：`node bin/dsh-purge.js --apply --status`。Windows 上宿主在 `Program Files` 下，需要**管理员权限**。
- **密封 `app.asar` 会先解包**：官方原样安装的宿主必须先解成 `resources/app/`。插件检测到 `desktopAsarStillSealed()` 时会跳过启动时的自动重打（`wait for Apply`），只认手动 `--apply`，过程中会重启客户端。
- **市场「更新」不重打补丁**：只替换 `node_modules` 里的插件文件，宿主里已打的补丁保持原样；只有新版调整了补丁表时才需要 `--revert` 再 `--apply`。
- **验证**：`--status` 逐条看 `applied` / `pending` / `drifted`；`drifted` 表示宿主原文变了、pattern 已经匹配不上。

所以「从市场装了插件」和「插件已经生效」是两个状态，中间隔着一次 `--apply`。

**为什么不能开箱即用**——不是权限没给够，是架构决定的：

1. 官方发行把整个应用封在 `resources/app.asar` 里，84 条 pattern 指向 asar 内部的原文，不先解包就没有可改的文件；
2. 补丁要写 `Program Files` 下的系统目录，Windows 默认只读，必须提权；
3. 插件市场只能把 JS 包装进 `~/.dsh`，既没有权限、也不应该替用户改宿主安装目录，提权动作必须由用户自己发起；
4. 补丁是逐字文本替换、绑定宿主版本，宿主一升级原文变了就 `drifted`，只能等插件补新 pattern；
5. Electron 优先加载 `resources/app/` 目录——这是解包后能生效的原因，也是重装会把解包目录还原掉的原因。

### 方式一：Release 解压（推荐）

1. 到 [Releases](https://github.com/Nero0427/dsh-purge-lite/releases) 下载最新 `dsh-purge-<version>.zip`。
2. 解压后把 `dsh-purge/` 整个目录放到：

```
<DSH_HOME>/profiles/desktop/node_modules/dsh-purge
```

3. 注册到 profile bundle：

```bash
node "<DSH_HOME>/profiles/desktop/node_modules/dsh-purge/scripts/ensure-profile-bundle.mjs"
```

### 方式二：本地打包 tgz（开发用）

Release 只提供源码 zip，不发 tgz。需要 tgz 时先在插件目录执行 `pnpm pack` 自行生成：

```bash
cd <DSH_HOME>/profiles/desktop
pnpm add file:/path/to/dsh-purge-<version>.tgz
```

### 方式三：从 GitHub 仓库安装（推荐，可点更新）

```bash
cd <DSH_HOME>/profiles/desktop
pnpm add github:Nero0427/dsh-purge-lite
```

插件市场会比较仓库根 `package.json` 的 `version` 与已装版本，发现新版后出现更新入口，点击即重装到新版。**发新版必须递增版本号**，否则市场不会提示更新。

### 方式四：克隆后 `link:`（开发用）

```bash
git clone https://github.com/Nero0427/dsh-purge-lite.git
cd <DSH_HOME>/profiles/desktop
pnpm add link:/path/to/dsh-purge-lite
```

`link:` 方式改完源码不用重装，重启 DSH 即生效。但它是本地开发副本，**不在插件市场的更新通道内**，不会收到更新提示。

### 验证安装

```bash
cd <DSH_HOME>/profiles/desktop/node_modules/dsh-purge
node bin/dsh-purge.js --status
```

能看到 84 条补丁的状态表，说明插件接上了；每行是 `applied` 才算真正落到宿主上，`pending` 就回到上面跑 `--apply`。

## 升级

精简版不含在线更新器，升级就是换一份新文件。**顺序很重要**——旧版写进宿主的代码必须先还原，否则会残留：

1. 打开 [Releases](https://github.com/Nero0427/dsh-purge-lite/releases)，先看 release notes 与 [CHANGELOG.md](CHANGELOG.md) 的迁移提示（例如 1.1.90 → 1.2.0 的强制 revert）。
2. 在**旧目录**里还原补丁：

   ```bash
   node bin/dsh-purge.js --revert
   ```

3. 下载 `dsh-purge-<version>.zip`，解压，整体替换 `<DSH_HOME>/profiles/desktop/node_modules/dsh-purge`。
4. 重新应用并确认状态：

   ```bash
   node bin/dsh-purge.js --apply
   node bin/dsh-purge.js --status
   ```

5. 重启 DSH。

版本号在根 `package.json`，与 Release tag `v<version>` 一致。用 `link:` 装的开发副本直接 `git pull` 即可，但仍需走一遍第 2、4 步。

**从 `github:` 安装的**：市场点「更新」只替换 `node_modules` 里的插件文件，宿主里已打的补丁不会自动重打。更新完仍需执行第 4 步的 `--apply --status`；若新版调整了补丁表，先 `--revert` 再 `--apply`。补丁备份在 `<DSH_HOME>/dsh-purge/host-backups/`，不在插件目录里，替换插件后照样能还原。

## 快速开始

从装好到生效的完整流程。按 Windows 桌面版写，其他平台把路径换成对应位置，命令一致。**全程用管理员终端**——`--apply` 要写 `Program Files`。

### 1. 确认插件已就位

市场安装或 Release 解压后，目录应该是：

```
<DSH_HOME>/profiles/desktop/node_modules/dsh-purge
```

Windows 默认在 `%USERPROFILE%\.dsh\profiles\desktop\node_modules\dsh-purge`。

### 2. 开管理员终端并进入插件目录

开始菜单搜 PowerShell → 右键「以管理员身份运行」：

```powershell
cd "$env:USERPROFILE\.dsh\profiles\desktop\node_modules\dsh-purge"
```

### 3. 指定宿主包根

```powershell
$env:DSH_BASE = "<DeepSeek 安装目录>\resources\app\dsh\node_modules\@deepseek-ai"
$env:DSH_SURFACE = "desktop"
```

`DSH_BASE` 必须指到**包含** `dsh-agent-instructions\lib` 的那一层 `@deepseek-ai`，不是 `node_modules`，也不是 `resources\app`。指错会报「插件根未定位」。

### 4. 先看现状

```powershell
node bin/dsh-purge.js --status
```

没打过补丁的宿主会看到大面积 `pending` / `drifted`。这一步只读，不改任何文件。

### 5. 应用

```powershell
node bin/dsh-purge.js --apply
```

- 宿主还是密封 `app.asar` 时，这一步会先解包成 `resources/app/`，期间可能重启客户端；DSH 正在运行就先退出。
- 少数机器上 `schtasks.exe` 会被安全软件拦，日志会有提示，主流程不受影响。
- 成功后写应用戳，下次启动不会重复打。

### 6. 验证

```powershell
node bin/dsh-purge.js --status
```

逐行看：`applied` 才算落到宿主；还有 `pending` 就重跑第 5 步；出现 `drifted` 说明宿主原文和 pattern 对不上，等插件更新，不要强打。

### 7. 重启并确认

手动启动 DSH（桌面宿主禁用了自重启）。发一条消息，看回复是否按你的注入正文来；设置页面板也能看到状态。

### 日常三件事

| 想做什么 | 怎么做 |
|---|---|
| 改注入正文 | `node bin/dsh-purge.js --edit`，或直接改 `<DSH_HOME>/prompt-inject.md`，下一轮组装生效 |
| 开 / 关注入 | 设置页开关，或改 `<DSH_HOME>/dsh-purge/inject-switch.json` 的 `promptInject` |
| 看补丁状态 | `node bin/dsh-purge.js --status`，或设置页面板 |

### 回滚

```powershell
node bin/dsh-purge.js --revert
```

逐条还原宿主原文，不删 `prompt-inject.md`（那是你的文件）。

> **升级提示**：从 1.1.90 升级到 1.2.0 必须 `--revert` 再 `--apply`。旧版往 `main.js` 写过补丁 #45/#46（桌面更新接管），新版补丁表里已移除，只有先还原才能把那段代码清干净。

## 配置

配置写在 profile 的 `cordis.patch.yml`：

```yaml
- id: dsh-purge
  name: dsh-purge
  inject: [systemPrompt, tools]
  config:
    enabled: true
    autoApplyOnStart: false
    autoRevertOnMissing: false
    injectOnce: false
    stripMnemon: true
    verbose: false
    capabilityProtocol: true
    hooksDenyBypass: true
    anchorMode: auto
    subagentControl: true
```

| 键 | 默认 | 作用 |
|---|---|---|
| `enabled` | `true` | 总开关。关掉后不再改写装配 |
| `autoApplyOnStart` | `false` | 启动时自动打补丁，不必手动 `--apply` |
| `autoRevertOnMissing` | `false` | 宿主文件找不到时自动回滚，避免半打状态 |
| `injectOnce` | `false` | 只在首轮注入，后续轮次不重复挂 |
| `stripMnemon` | `true` | 清掉宿主自带的身份/记忆段 |
| `verbose` | `false` | 控制台输出补丁过程 |
| `capabilityProtocol` | `true` | 追加一段"如何主动发现 skill / MCP"的说明 |
| `hooksDenyBypass` | `true` | 审批门按本插件配置放行，不再每条都问 |

**注入模式**（同一份 `inject-switch.json` 的 `mode` 字段）：

| 模式 | 注入内容 | 体积（字符） |
|---|---|---|
| `full`（默认） | 整份 `prompt-inject.md` | 21,738 |
| `general` | 只注入 `$DSH_HOME/dsh-purge/sections/core.md`（通用段） | **6,306（省 71%）** |
| `pentest` | `core.md` + `sections/pentest.md`（通用段 + 任务分类与产出模板） | 21,736（等于全量） |

通用段 = 前言、EXECUTION ECONOMY、Style、HARD OUTPUT RULES、REFUSAL HARDENING、STABILITY ANCHORS、House Rules；场景段 = Scoped Rules、CTF 两节、Routing（占正文 71%），只在渗透 / 解题类任务里用得上。

分段文件放在 `$DSH_HOME/dsh-purge/sections/`。**1.5.3 起 `core.md` 缺失会自动从 `prompt-inject.md` 现场拆一份**（已有文件不覆盖），拆不出来才降级回全量。`full` 下完全不读这些文件，行为与 1.3.0 一致。

另有一个**运行时开关**，不属于上面的 cordis 配置：设置页状态卡上的「关闭注入 / 开启注入」，状态落在 `$DSH_HOME/dsh-purge/inject-switch.json`（字段 `promptInject`，默认 `true`）。关掉后宿主不再往 system prompt 挂注入正文；切换**下一轮对话生效，不用重启 dsh**。它与配置里的 `enabled` 是「与」关系，任一为假即不注入。
| `anchorMode` | `auto` | `auto` 挂尾部锚点，`off` 立即关闭 |
| `subagentControl` | `true` | 子代理的审批由本插件接管 |

> YAML 里写成字符串的布尔（`"false"`）会被 JS 当**真值**。插件内部统一做了一次收敛：`false/0/no/off` 视为关，其余视为开。

## 命令

会话内 `/purge`：

```
/purge status      状态（补丁进度、shim、override 文件）
/purge apply       应用全部清洗
/purge revert      还原
/purge uninstall   卸载插件
/purge edit        编辑注入文件
/purge help        帮助
```

同时注册三个模型可调用的工具：`purge_status`、`purge_apply`、`purge_revert`。

CLI：

```bash
dsh-purge --status      # 状态表
dsh-purge --apply       # 应用
dsh-purge --revert      # 回滚
dsh-purge --uninstall   # 卸载（已应用则先还原）
dsh-purge --edit        # 编辑 prompt-inject.md
dsh-purge --mode <full|general|pentest>   # 切换注入模式（下一轮对话生效）
dsh-purge --bash-budget [ms]              # 收紧 ops_bash 前台超时上限（默认 180000）
dsh-purge --bash-budget-revert            # 还原 ops_bash 超时上限
dsh-purge --help        # 帮助
```

## HTTP 接口

桌面端由插件起一个同源服务，前缀 `/dsh-purge`：

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/dsh-purge/status` | 状态汇总 |
| GET | `/dsh-purge/prompt-text` | 当前注入正文（面板用，只读） |
| POST | `/dsh-purge/apply` | 应用补丁 |
| POST | `/dsh-purge/revert` | 还原 |
| POST | `/dsh-purge/uninstall` | 卸载 |
| POST | `/dsh-purge/override` | 写入注入文件 |
| POST | `/dsh-purge/restart` | 重启宿主 |
| POST | `/dsh-purge/hooks-deny` | 开关审批门绕过 |
| GET | `/dsh-purge/inject` | 读注入开关与模式，附可用模式列表 |
| POST | `/dsh-purge/inject` | 写开关或模式（body `{"promptInject": boolean}` 和/或 `{"mode": "general"}`），下一轮对话生效 |

前端 `client.js` 调用 `prompt-text`、`status` 与 `inject`，其余给设置页的按钮用。面板挂在「设置 → Purge」。

## 工作原理

```
请求进入
   │
   ├─ system-prompt/assemble  (waterfall)
   │      │
   │      ├─ 清空宿主身份段（includeHarnessIdentity / personaPrefix / personaSuffix）
   │      ├─ 读 $DSH_HOME/prompt-inject.md          ┐ 三级取文：
   │      │   ↑ 空则读设置框里提交的正文             │ 提示词框 > 文件 > 加密默认
   │      │   ↑ 再空则解密内置默认（AES-GCM+inflate）┘
   │      ├─ 挂到 system prompt 最前
   │      └─ 追加尾部锚点（anchor）
   │
   └─ 工具调用前
          └─ 审批门 / 沙箱按配置放行（hooks-deny、subagent-control）
```

宿主补丁分成四层，共 84 条：

| 层 | 数量 | 内容 |
|---|---|---|
| `PATCHES` | 主体 | 提示词层与工具描述改写 |
| `CODE_PATCHES` | 若干 | 代码默认值（审批、沙箱） |
| `ENGINE_PATCHES` | 若干 | 引擎级行为 |
| `NEW_TOOL_PATCHES` | 若干 | 新增工具接口 |

每条补丁在应用前先备份目标文件原文。宿主升级导致原文变化时，补丁状态标记为 `drifted`，提示更新 pattern，而不是硬写进去。

## 目录结构

```
.
├── bin/
│   └── dsh-purge.js            CLI 入口（--status/--apply/--revert/--mode/--bash-budget/...）
├── lib/
│   ├── index.js                插件入口：命令、路由、工具、配置装配
│   ├── core.js                 84 条补丁表、asar 解包、加密默认正文
│   ├── identity.js             注入文本解析与 assemble 改写
│   ├── rules.js                三级取文策略
│   ├── desktop.js              桌面宿主补丁写入与还原
│   ├── reapply.js              宿主自愈重打
│   ├── profile-insert.js       profile bundle 自愈
│   ├── extract-asar.js         asar 解包 / 回写
│   ├── hooks-deny.js           审批门绕过
│   ├── inject-switch.js        注入总开关与模式（运行时，下一轮生效）
│   ├── sections.js             按模式组合注入正文（core + 场景段）
│   ├── bash-budget.js          ops_bash 前台超时上限的收紧 / 还原
│   ├── anchor.js               尾部锚点
│   ├── capability-protocol.js  能力发现协议段
│   ├── subagent-control.js     子代理审批接管
│   ├── asset-table.js          加密正文解密槽（不是资产库）
│   ├── uninstall.js            卸载
│   └── ...                     其余为补丁工具与策略模块
├── client.js                   设置页状态面板（浏览器半区）：开关与模式选择
├── cordis.patch.yml            bundle patch
├── scripts/
│   └── ensure-profile-bundle.mjs   postinstall 注册
└── verify/
    └── treehealth.mjs          补丁表与 profile 的静态一致性检查
```

## 兼容性

| 项 | 范围 |
|---|---|
| Node.js | ≥ 18 |
| 宿主 | DSH `0.2.1-rc.2` / `0.2.1-rc.5` / `0.2.2-rc.1`（见 `package.json` 的 `dshTargets`） |
| 系统 | Windows（桌面端）、macOS、Linux（web 端） |
| Cordis | `^4.0.1` (peer) |

宿主小版本升级后，先跑 `--status` 看有没有 `drifted` 补丁，再决定是否 `--apply`。

## 版本支持矩阵

**哪个插件版本支持哪个宿主版本，以此表为准。** `engines.dsh` 只决定「能不能装/能不能加载」，破甲功能是否完整另看最后一列——两者不是一回事。

| 插件版本 | `engines.dsh` | 0.2.1-rc.2 | 0.2.1-rc.5 | 0.2.2-rc.1 | 说明 |
|---|---|---|---|---|---|
| `≤ 1.4.0-lite` | 未声明 | 完整 | 完整 | 未适配 | 无版本门，宿主不拦截，但补丁只对齐到 rc.5 |
| `1.4.1-lite` | `>=0.2.1-rc.2 <=0.2.1-rc.5` | 完整 | 完整 | **拒绝加载** | 上限把新宿主挡在 `dsh-app-boot` 兼容性门外 |
| `1.4.2-lite` | `>=0.2.1-rc.2 <0.2.3-0` | 完整 | 完整 | **能装，功能残缺** | 过渡版：只放宽声明，11 条补丁失配；已由 1.5.0-lite 取代，勿用 |
| `1.5.0-lite` | `>=0.2.1-rc.2 <0.2.3-0` | 完整 | 完整 | 完整 | 首个完整支持 0.2.2-rc.1 的版本；注入总开关关闭不彻底，见 1.5.1-lite |
| `1.5.1-lite` | `>=0.2.1-rc.2 <0.2.3-0` | 完整 | 完整 | 完整 | 1.5.0 + 注入总开关修复：关闭 = 原生 system prompt，不残留任何注入段 |
| `1.5.2-lite` | `>=0.2.1-rc.2 <0.2.3-0` | 完整 | 完整 | 完整 | 1.5.1 + 思考开销收敛：语言规则不再自相矛盾、锚点禁词清单合并为正向指令、新增「一次判定」纪律 |
| **`1.5.3-lite`** | `>=0.2.1-rc.2 <0.2.3-0` | **完整** | **完整** | **完整** | 1.5.2 + 分段边界重划与缺失自愈：`general` 只注入通用段，常驻正文 21,738 → 6,306 字符 |

反过来看，按你的宿主版本选插件：

| 宿主版本 | 推荐插件版本 | 升级前必读 |
|---|---|---|
| `0.2.1-rc.2` / `0.2.1-rc.5` | `1.5.3-lite` | 从 1.4.x 升级照「升级」章节走 `--revert` → 替换 → `--apply` |
| `0.2.2-rc.1` | **`1.5.3-lite`**（`1.5.0-lite` 补丁完整但开关关闭不彻底） | ① 第三方 `dsh-ops 0.4.4` 声明 `<0.2.2-0`，须先升到 `0.5.0`，否则宿主拒绝加载；② 覆盖安装会还原 `app.asar` 并摊掉全部补丁，需重新解包、`--apply --status`、重启；③ `app-update.yml` 会恢复官方 nightly 源，要锁版本需再改回 `disabled.invalid` |

**1.5.0-lite 做了什么**：官方 0.2.2-rc.1 改写了沙箱授信、观察策略、system-prompt、agent-loop、桌面壳 `main.js` 的实现，并把交付物提示词迁到 `dsh-deliverable-file-references`、PTC `run_code` 描述迁到 `dsh-tool-executor-ptc`、工具审批分支迁到 `dsh-tools/lib/pipeline.js`。本版给 11 条受影响补丁**追加**新版原文候选、给 4 个目标路径补上迁移后的新文件，旧版 pattern 一条未删——引擎逐条尝试命中，所以三个宿主版本共用同一张 84 条补丁表，不需要按宿主分发不同插件。

**验证口径**（离线补丁层，非运行时）：从官方安装包解出 `app.asar`（213,202,918 B / 20,519 文件）建立干净树，完整跑一遍 `applyPatches` 后 `drifted = 0`、`pending = 0`；11 条修复项的 marker 全部落盘；48 个被改写的 `.js` 文件 `node --check` 全通过；15 条破甲语义断言全通过；桌面壳 5 条补丁单独验证全部 `applied`；在 rc.5 真实宿主上跑 `--status` 与改动前逐条比对，差异 0。**端到端的模型行为仍需你在升级后发一条消息人工确认**——离线验证只能证明补丁正确写进了宿主文件。

**1.5.3-lite 改了什么**：分段边界从「House Rules 之前」前移到「Scoped Rules 之前」，把任务分类规则和产出模板（占正文 71%）整块划进场景段；`core.md` 缺失时自动从 `prompt-inject.md` 现场拆，重装/换机不再静默退回全量。`mode: "general"` 的常驻正文从 19,427 字节降到 8,179 字节。判定内容与补丁表未动。

**1.5.2-lite 改了什么**：只收敛思考开销，不动判定内容。① 正文与参考稿里的「用英文思考」改成「思考与回复同语言」——此前这句与人设记忆的「思考也用中文」直接冲突，实测模型会花整段 thinking 自我检讨语言问题；② 尾部锚点把「10 个禁词的开场白清单 + 免责 + 替代方案」三条合并为一条正向指令（以交付物本体开头、不附前言），禁止清单要求逐项比对，正向写法把判定降到一次；③ 锚点新增「一次判定、不重读规则、不开已结的结论」；④ 去掉「思考必须以身份自述开场」的强制要求。补丁表与开关行为均未变化。

**1.5.1-lite 额外修了什么**：注入总开关此前只关掉 `prompt-inject.md` 正文，尾部锚点 `[OPERATOR ANCHOR — ACTIVE]`、capability 段与 `dsh-wb-memory` 记忆段仍会进 system prompt，表现为「关了开关还看得到注入」。本版让关闭态直接返回原生装配、剔除全部注入侧 section / context；开启态行为完全不变。详见 release notes 与 `CHANGELOG.md`。

## 常见问题

**从市场装了插件，设置页能打开，但注入 / 审批没变化**
插件装上了不等于补丁打上了。`autoApplyOnStart` 默认 `false`，84 条宿主补丁要手动跑一次 `node bin/dsh-purge.js --apply --status`（Windows 需管理员权限）。宿主仍是密封 `app.asar` 时会先解包并重启客户端。详见安装章节的「必读」。

**官方更新了宿主，补丁全变成 `drifted`**
官方安装包重装了 `app.asar`，之前解包的 `resources/app/` 与全部补丁被覆盖。重新解包后跑 `--apply`；若只有少数几条 `drifted`，说明新版宿主改了对应原文，等插件更新 pattern，不要强打。

**报「插件根未定位 / plugin root not found」**
`DSH_BASE` 没指对。它必须指向**包含** `dsh-agent-instructions/lib` 的那一层 `@deepseek-ai` 目录，不是 `node_modules`，也不是 `resources/app`。

**`--apply` 说成功，但重启后没生效**
桌面端要确认 `DSH_SURFACE=desktop`；web 端确认 profile 里 `dsh-purge` 已进 `bundles`。再跑 `--status`，看补丁是否真的 `applied` 而不是 `pending`。

**补丁状态 `drifted` 是什么意思**
宿主文件被官方更新了，补丁要匹配的那段原文找不到了。此时不要强行应用。等插件更新 pattern，或临时 `--revert`。

**注入正文被改了怎么办**
改 `$DSH_HOME/prompt-inject.md`，重启即生效。设置页看到的是同一份文件。`--revert` 不会删它（属于用户文件）。

**能同时挂多个注入段吗**
可以。`dsh-purge` 把 `dsh-purge*` 段强制排在最前，其它插件（例如 [`dsh-wb-memory`](https://github.com/Nero0427/dsh-wb-memory)）追加的段自然落在它后面。

**卸载干净吗**
`--uninstall` 会先还原补丁、移除 profile 引用、删插件目录。命令行卸载直接删；界面卸载交给独立助手等端口释放后再删（Windows 上文件被占用时删不掉）。

## 已知限制

- **提示词注入的端到端验证需要人工确认**。静态检查只能证明"补丁打上了"，不能证明"装配结果里真有你那段"。发一条消息看模型是否按你的身份回答才算验证完。
- **84 条补丁是全量应用**。裁到"提示词 + 审批门/沙箱"约 35 条是后续计划；补丁之间有依赖，裁错宿主起不来。
- **多工作区按 `last-cwd` 选注入文件**。这是功能不是残留，但换工作区时行为会变。
- **桌面端 HTTP 服务是随机端口**。前端用同源相对路径通信，不能跨端口调用。

## 版本

完整变更见 [CHANGELOG.md](CHANGELOG.md)。

| 版本 | 要点 |
|---|---|
| `1.5.3-lite` | **分段边界重划 + 缺失自愈**：`general` 只注入通用段，常驻正文 21,738 → 6,306 字符（-71%）；`core.md` 缺失自动现场拆 |
| `1.5.2-lite` | **思考开销收敛**：语言规则去冲突、锚点禁词清单合并为正向指令、新增一次判定纪律；判定内容与补丁表不变 |
| `1.5.1-lite` | **注入总开关修复**：关闭后不再残留锚点 / capability / 记忆段；开启态行为不变 |
| `1.5.0-lite` | **完整适配 0.2.2-rc.1**：补齐 11 条失配补丁与 4 处路径迁移，rc.2 / rc.5 / 0.2.2-rc.1 三版全生效；新增版本支持矩阵 |
| `1.4.2-lite` | 过渡版：仅把宿主声明放宽到 0.2.2-rc.1（代码与补丁表未改），在新宿主上功能残缺，已被 1.5.0-lite 取代 |
| `1.4.1-lite` | 声明宿主 rc.2～rc.5 支持范围 + 插件市场收录说明（维护版） |
| `1.4.0-lite` | 注入模式分段（full/general/pentest）+ ops_bash 超时上限收紧 |
| `1.3.0-lite` | 设置页新增注入总开关；修复手改正文被误判成插件默认并覆盖 |
| `1.2.2-lite` | 修复 git 源安装后构建授权被反复清除，市场点更新不再被拦 |
| `1.2.1-lite` | 补 GitHub 仓库安装与更新说明，代码未改 |
| `1.2.0-lite` | 删除 13 个模块（在线更新、技能库、回退、续跑、演练台），补丁 86 → 84 |
| `1.1.90-lite` | 首个精简版基线 |

## 上游与许可

本仓库是 `dsh-purge` 的**精简衍生版**，上游项目与版权声明见 [NOTICE](NOTICE)。按 Apache License 2.0 分发；衍生作品需保留 NOTICE 与归属。

```
Copyright 2026 YuJunZhiXue
Modifications Copyright 2026 Nero0427
```

使用本插件意味着你自行承担宿主被修改的风险。插件所做的是修改**你本机安装的客户端程序**，请确保你有权这样做，并注意保留 `--revert` 的能力。
