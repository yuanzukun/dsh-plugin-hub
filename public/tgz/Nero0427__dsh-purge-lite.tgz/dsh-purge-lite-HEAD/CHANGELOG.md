# Changelog

本项目所有值得记录的变更都写在这里。

格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，
版本号遵循 `主版本.次版本.修订号-lite` 的约定，`-lite` 表示精简衍生线。

## [Unreleased]

### Docs

- README 安装章节新增「必读：补丁不会随插件自动生效」：补丁表随插件发布，但必须 `--apply` 写进宿主文件才生效；`autoApplyOnStart` 默认 `false`；密封 `app.asar` 会跳过启动重打、只认手动 Apply；市场「更新」不重打补丁；Windows 写 `Program Files` 需要管理员权限。
- 「必读」补「为什么不能开箱即用」：asar 打包、系统目录权限、市场只能装 JS 包、pattern 绑宿主版本、Electron 目录优先加载。
- 「快速开始」从原来的 4 行命令改成 7 步完整教程（管理员终端、`DSH_BASE` / `DSH_SURFACE`、`--status` 基线、`--apply` 解包与重启、`--status` 验收、手动重启确认），另加「日常三件事」表与回滚说明。
- 常见问题补两条：「装了插件但注入 / 审批没变化」「官方更新宿主后补丁全变 `drifted`」。

### Planned

- 补丁表从 84 条裁剪到约 35 条（提示词层 + 审批门 + 沙箱），逐组验证依赖关系。
- `drifted` 补丁的自动 pattern 更新（当前只能等新版本）。

## [1.5.4-lite] - 2026-11-21

宿主适配：追加 `HOST_VARIANTS_022RC5`，修掉 0.2.2-rc.5 上的 5 条补丁漂移。判定逻辑与注入正文未改。

### Fixed

- `#13` / `#35`：rc.5 把 `throw new Error` 改成 `throw new SandboxEscalationError(..., "CODE")`，`cancelled` 分支拆成三行——追加 rc.5 版 pattern，两条审批门补丁不再静默失效。
- `#18`：rc.5 删掉了 repeat-tool-reminder 的 `downstream.kind === "block"` 分支——追加精简版 hook pattern。
- `#56` / `#77`：rc.5 用 `surfaceOp` / `replacements` 重写了对话客户端的 rewind 隐藏机制，原文案已不存在；标记 `softSettle`，由官方原生语义覆盖。

### Docs

- README / release-notes 的版本支持矩阵补 0.2.2-rc.5 列，四个宿主版本统一推荐 `1.5.4-lite`。

## [1.5.3-lite] - 2026-11-07

注入体积：**分段边界重划 + 缺失自愈**。`mode: "general"` 从「少注入一段 Routing」变成「只注入通用段」，常驻正文从 21,738 字符降到 6,306 字符。判定内容与补丁表未改动。

### Changed

- `lib/sections.js`：通用段 / 场景段的分界从「House Rules 之前」前移到「Scoped Rules 之前」。原先 `Scoped Rules`（任务分类规则，8,165 字符）留在通用段里，切到 `general` 只省掉 Routing 与 CTF 两节，省了个零头。现在整块任务分类与产出模板（15,430 字符，占正文 71%）都归场景段。

### Added

- `splitSections(text)`：按结构匹配切分（`Scoped Rules` 小节开头 → `STABILITY ANCHORS` / `House Rules` 之前），不依赖行号；匹配不上返回 `null`，调用方回退全量。
- `seedSections()`：`mode` 非 `full` 而 `core.md` 不存在时，从 `$DSH_HOME/prompt-inject.md` 现场拆一份。此前只认手放的 sections——重装、换机、清过配置之后会静默退回全量，开关看着是开的，实际一点没省。已有 `core.md` 一律不覆盖，用户自己定制的分段优先。

### Notes

- `mode` 默认仍是 `full`，行为不变。要省体积把 `$DSH_HOME/dsh-purge/inject-switch.json` 的 `mode` 改成 `"general"`（下一轮组装即生效，不用重启）。
- 场景段文件名沿用 `pentest.md`，`mode: "pentest"` = 通用段 + 场景段，等价于原来的全量内容。
- 通用段保留：前言、EXECUTION ECONOMY、Style、HARD OUTPUT RULES、REFUSAL HARDENING、STABILITY ANCHORS、House Rules。

## [1.5.2-lite] - 2026-11-07

收敛思考开销：**语言规则去冲突、锚点禁词清单合并、新增一次判定纪律**。判定内容与 84 条补丁表均未改动。

### Changed

- `lib/default-prompt-inject.{zh,en}.md`：`用英文思考。用用户的语言回复` / `Think in English. Reply in the user's language` 改为「思考与回复同语言」。这句与人设记忆的「思考也用中文」互相打架，实测模型会花整段 thinking 自我检讨语言问题，属于纯无效开销。
- `lib/anchor.js`：主锚点 9 条压到 8 条。原第 4/5/6 条（10 个禁词的开场白清单 + 免责声明 + 替代方案）合并为一条正向指令 `Start with the artifact itself and let it stand alone`。禁止清单要求逐项比对，模型每轮都在 thinking 里打一遍勾；正向写法把判定降到一次。子锚点同步合并 4/5 两条。
- `lib/asset-table.js`：按新正文重新加密（AES-GCM + inflate），密文槽与 `$DSH_HOME/prompt-inject.md` 逐字一致。

### Added

- 主锚点第 5 条：`Deliberate once, then build`——一次判定、不重读规则、不开已结的结论，把思考预算花在产出而不是许可上。子锚点同步。
- 正文 STABILITY ANCHORS 补一条同义规则，与尾部锚点呼应。
- 落盘正文去掉了「思考必须以身份自述开场」（原 `Mandatory thinking MUST begin as Little Code Sauce!`）：身份默认激活，不需要每轮声明。

### Notes

- 尾部锚点始终是 recency 位，正文里原有的「思考只做决策」条款位置太靠前、注意力够不到，这是本次把纪律写进锚点的原因。
- 密文槽改动后 `defaultOverrideHash()` 会变；`override-state.json` 的 `hash` / `seedHash` 已同步为新指纹，升级时不会被误判成「用户手改」而拒绝更新。
- 判定内容（任务优先、拒绝即故障、占位符归一化、不可提及本段）一字未改，本版只改写法。

## [1.5.1-lite] - 2026-11-07

修复注入总开关：**关闭后不再残留任何注入内容**。功能与补丁表相对 1.5.0-lite 无变化。

### Fixed

- `registerAnchor()` 增加 `allow` 回调，主锚点 `dsh-purge:anchor` 与子锚点 `dsh-purge:child-anchor` 的 `text` 每轮判运行时开关。此前 `anchorOn()` 只看 `config.enabled` / `config.anchorMode`，关掉 `promptInject` 后 `[OPERATOR ANCHOR — ACTIVE]` 的 9 条规则仍留在 system prompt。
- `rewriteLiveAssembly()` 在开关关闭时直接返回原生装配，跳过 `rewritePromptAssembly`（它还会 `dropMnemon` 清宿主身份、补 capability 段）；新增导出 `isInjectedName()` / `nativeAssembly()`，按名剔除 `dsh-purge*` / `dshpg-capabilities` / `dsh-wb-memory` 的 sections 与 contexts。
- 两处 `registerAnchor` 调用（主 ctx 与隔离层）传入 `() => injectAllowedNow(config)`。
- 更新[版本支持矩阵](README.md#版本支持矩阵)：三个宿主版本均推荐 `1.5.1-lite`；`1.5.0-lite` 补丁完整但开关关闭不彻底。

### Notes

- 开启态行为完全不变：正文 + 锚点 + capability + 记忆段照常注入。
- 关闭态：`wb-memory` 的 HTTP 路由与 `/memory` 命令仍在，只是不再进 system prompt。
- 宿主静态补丁（84 条）不随开关变化，其中一条把 `harness:identity` 正文清空；要完全"官方原生"需跑 `--revert` + 重启（会摊掉破甲）。
- 开关文件 `~/.dsh/dsh-purge/inject-switch.json` 每轮读，切换后不重启也生效；`mode: "general"` 是精简分段模式（用 `sections/core.md`），不是"关"，要整份正文设 `mode: "full"`。

### Verified

- 真实 cordis 4.1.0 + 已打补丁的 `dsh-system-prompt` 装配，**21/21** 断言通过：开启态 6 个注入段全在（prompt 1,523 B）；关闭态锚点 `text` 为 0 字节、注入侧段全剔除、`harness:identity` 等宿主段名保留、prompt 归零。
- `isInjectedName` 10 个边界用例全对；`lib/index.js` / `lib/anchor.js` `node --check` 通过；84 条补丁状态与上一版一致（`76 applied`，差异 0）。

## [1.5.0-lite] - 2026-11-07

**首个完整支持官方宿主 `0.2.2-rc.1` 的版本。** 1.4.2-lite 只是放宽了版本声明，11 条补丁在新宿主上仍然失配；本版把功能补齐，并明确写出「哪个版本支持哪个版本」。

### Added

- `HOST_VARIANTS_022RC1` 适配层：给 11 条受影响的补丁追加 0.2.2-rc.1 原文候选，`ALL_PATCHES` 组装后统一挂载。旧版 pattern 一条未删，引擎逐条尝试命中，rc.2 / rc.5 / 0.2.2-rc.1 共用同一张 84 条补丁表。
- `targetFiles` 补齐官方拆包后的新路径：`dsh-deliverable-file-references`、`dsh-tool-executor-ptc`（`lib/index.js` 与 `lib/types/ptc.js`）、`dsh-tools/lib/pipeline.js` 与 `lib/types/pipeline.js`。旧宿主不含这些文件，自动回落到原路径。
- README 新增「版本支持矩阵」：按插件版本和按宿主版本两个方向列明支持关系与破甲功能完整度。

### Fixed

- `#14` 沙箱授信：`displayReason` 改为 `escalationDisplayReason()` 调用后的新原文。
- `#17` 观察策略：`editIntent` 被抽成 `requirePresent()` 后的新原文（`writeIntent` 旧 pattern 仍命中）。
- `#40` system-prompt：新版 `assemble` 早退分支与最终返回都多了 `tools` 字段，注入逻辑同步保留该字段。
- `#54` 交付物提示词、`#60` PTC/run_code 描述、`#62` 工具审批分支：三处代码被搬到新包/新文件，补上目标路径后原有 pattern 直接命中；给这三条加 `softSettle`，避免官方搬走代码后留下的旧副本被误报为上游漂移。
- `#67` agent-loop：循环体多包一层 `try`，缩进 4 tab → 5 tab。
- `#74` preStep：`assemble` 前多了 `model.current()` / `tools.resolve()`，参数结构也变了，在 `try` 内重新挂载 prepare 钩子。
- `#82` / `#84` / `#92` 桌面壳 `lib/main.js`：import 后的 `//#region` 变成打包器生成路径、`close` 回调签名由 `(code, signal)` 变 `(code)`、`code=0` 仍走 else 弹错，三条分别追加新候选。

### Verified（离线补丁层）

- 官方安装包 `app.asar`（213,202,918 B，20,519 文件）导出全新干净树，跑完整 `applyPatches`：`applied 71` / `na 10` / `missing_file 2` / `skipped 1`，**`drifted 0`、`pending 0`、报告无异常行**。
- 11 条修复项的 marker 11/11 真实落盘；15 条破甲语义断言（审批放行、注入保留、提示词移除、code=0 不弹错等）15/15 通过。
- 48 个被改写的 `.js` 文件 `node --check` 全部通过；桌面壳 5 条补丁单独验证全部 `applied`。
- rc.5 真实宿主 `--status` 与改动前逐条比对，差异 0；隔离验证前后真实 `~/.dsh` 快照哈希一致。

### Upgrade notes

- 从任意旧版升级：先在旧目录 `--revert`，替换插件目录，再 `--apply --status`，重启 DSH。
- 宿主升到 0.2.2-rc.1：先把第三方 `dsh-ops 0.4.4` 升到 `0.5.0`（否则 `dsh-app-boot` 拒绝加载）；覆盖安装会还原 `app.asar` 并摊掉全部补丁，需重新解包后重打；`app-update.yml` 会恢复 nightly 源，锁版本需再改回 `disabled.invalid`。
- 端到端模型行为仍需升级后人工发一条消息确认；离线验证只证明补丁正确写进宿主文件。

## [1.4.2-lite] - 2026-11-07

> **已被 1.5.0-lite 取代**：本版只放宽版本声明，在 0.2.2-rc.1 上 11 条补丁失配，请勿在升级后的宿主上使用。

兼容版本，运行时代码与补丁表未改。

### Changed

- `engines.dsh` 从 `>=0.2.1-rc.2 <=0.2.1-rc.5` 放宽为 `>=0.2.1-rc.2 <0.2.3-0`，覆盖官方 0.2.2-rc.1 宿主；`dshTargets` 增加 `0.2.2-rc.1`，让 `--status` 不再提示「未适配」。
- README 安装章节与版本表同步宿主支持范围。

### Known Issues

- 0.2.2-rc.1 上离线核查：84 条补丁中 11 条 `drifted`（8 条官方包原文改写、3 条桌面壳 `lib/main.js` 重写），需逐条对齐后才能全部生效。详见 `release-notes.md`。
- 第三方 `dsh-ops 0.4.4` 在 0.2.2-rc.1 上不兼容，升级宿主前需先升到 0.5.0。

## [1.4.1-lite] - 2026-11-07

维护版本，运行时代码逻辑未改。

### Added

- `package.json` 声明 `engines.dsh: ">=0.2.1-rc.2 <=0.2.1-rc.5"`；插件市场与宿主据此判定宿主兼容性，卡片不再显示「未声明宿主要求」。
- README 安装章节写明宿主支持范围，补充插件市场收录说明（awesome-dsh-plugin PR #12160）与一键安装方式。

### Fixed

- README 与 `client.js` 文件头里「设置页只读面板」的过期描述：设置页现可切换注入开关与注入模式，正文本身仍只读。

## [1.4.0-lite] - 2026-11-07

注入正文支持按模式分段；新增 `ops_bash` 前台超时上限的手工收紧命令。默认配置与 1.3.0 完全一致。

### Added

- `lib/sections.js`：按模式组合注入正文。`full`（默认）注入整份 `prompt-inject.md`；`general` 只注入 `$DSH_HOME/dsh-purge/sections/core.md`；其它模式注入 `core.md` + `<mode>.md`。任一文件缺失都降级回全量，不会因为分段文件没放好而少注入。
- `inject-switch.json` 增加 `mode` 字段，默认 `full`；`GET/POST /dsh-purge/inject` 与 `/dsh-purge/status` 同步支持，设置页状态卡增加模式下拉，CLI 增加 `--mode <full|general|pentest>`。
- `lib/bash-budget.js` + `--bash-budget [ms]` / `--bash-budget-revert`：把 `dsh-ops` 的 `MAX_BASH_TIMEOUT_MS` 从 `2_147_483_647` 收到 180 秒。超时后 `ops_bash` 会走 `kind: "promoted"` 把命令转成后台 job（不杀进程），主循环继续，之后用 `job_output` 取结果。幂等、带备份、可还原。

### Changed

- `refreshHungOperator()` 的缓存键加入 `inject-switch.json` 的 mtime：切模式只改这个文件，不加的话会命中上一轮的旧正文。
- 全量模式改为直读磁盘、不再优先 `committed`：`committed` 可能是上一次分段模式钉进去的正文，切回 `full` 时若还认它，用户会看到旧内容一直被复用。

### Notes

- `general` 模式的收益是实测的：`prompt-inject.md` 26,275 B → `core.md` 19,427 B，省 26%，代价是不再注入 CTF 两段与渗透模板（CANNED WORKFLOWS / web-pentest canned slots / WEB PENTEST ROUTING）。
- `pentest` 模式等于全量（core + 渗透模板 = 原文），只是语义明确，不省体积。

### Test

- `full` 下 `composeInjection()` 返回 `null`，走原有 `resolveInjectText` 路径，行为与 1.3.0 一致。
- `pentest` 组合 21,494 字符，含 EXECUTION ECONOMY / CTF Contract / ffuf 模板 / House Rules，ChatML 信封 1 开 1 闭。
- 模式写入 → 读取 → 还原，全程不重启进程。
- `--bash-budget`：幂等（`current 180000 -> 180000`）、`--bash-budget-revert` 还原、再 apply（`2147483647 -> 180000`）三步走通。

## [1.3.0-lite] - 2026-11-07

设置页新增注入总开关；修复「基于默认正文增补的内容会被当成插件默认并覆盖」的判定错误。补丁表未改。

### Added

- `lib/inject-switch.js`：注入开关，落盘在 `$DSH_HOME/dsh-purge/inject-switch.json`，字段 `promptInject`，缺文件或坏 JSON 一律按「开」处理。
- 路由 `GET /dsh-purge/inject`（读状态）与 `POST /dsh-purge/inject`（写状态，body `{"promptInject": boolean}`）。
- 设置页状态卡增加「开启注入 / 关闭注入」按钮，并标明切换后**下一轮对话生效、无需重启 dsh**。
- `/dsh-purge/status` 增加 `prompt_inject` 字段。

### Fixed

- `isKeepableUserOverride()` 与 `ensureOverrideFile()` 不再用 `looksLikePluginDefault()` 决定是否覆盖。原先「文本含三个默认标记即算插件默认」的判据，会把用户基于默认原文增补的正文判成默认，下一轮 `syncPromptInjectOnDiskSync()` 直接拿加密槽盖掉，手改内容留存不下来。现在只看 hash 与 `override-state.json`：与当前槽、上次 seed、上次插件写入三者都不等，即视为用户正文并永久保留；`customized === true` 直接保留。
- `looksLikePluginDefault()` 保留，但降级为展示/诊断用途，不再参与覆盖判定。

### Changed

- `rewriteLiveAssembly()` 的缓存签名改用 `injectAllowedNow()` 的统一结果，切换开关后不会命中上一轮的改写缓存。

### Test

- 纯默认正文 → `isKeepableUserOverride` = false，可被新版本刷新。
- 默认 + 两行 → true，`syncPromptInjectOnDiskSync()` 返回 `{action:"keep",reason:"user_custom"}`，内容不变。
- 带 ChatML 头 + 增补正文 → true，真实文件同步后字节数与内容均未变。
- 开关：默认 true → 写入 false → 读到 false → 写回 true，全程无需重启进程。

## [1.2.2-lite] - 2026-11-05

修复从 GitHub 仓库安装后，市场「点击更新」被构建授权反复拦住的问题。补丁表与运行时逻辑未改。

### Fixed

- `lib/profile-insert.js`：`purgePnpmBuildSpecs()` 读取 profile 的 `package.json`，在依赖为 `github:owner/repo` 时额外生成稳定 git 授权键 `dsh-purge@git+https://github.com/owner/repo.git`，新装不必手工放行构建脚本。
- `rewritePnpmAllowBuilds()` 保留 pnpm / 市场写出的合法 git 键，并把待决占位行 `set this to true or false` 确认为 `true`；畸形历史键仍按 #185 清除。此前每跑一次 postinstall 就把授权删光，导致 `ERR_PNPM_IGNORED_BUILDS` 反复出现，且因 pnpm 按整个 profile 检查，会连带阻塞同一 profile 里其它插件的更新。

### Test

- 构造含占位行、稳定 git 键与畸形键的 YAML 样本，验证重写结果：占位行变 `true`、稳定键保留、畸形键清除、`validateAllowBuildRewrite` 通过。

## [1.2.1-lite] - 2026-11-05

维护版本，代码与补丁表未改。

### Added

- README 增加「从 GitHub 仓库安装」方式：`pnpm add github:Nero0427/dsh-purge-lite`，说明市场按仓库根 `package.json` 的 `version` 判断新版。
- README 升级章节说明：`link:` 是本地开发副本、不在市场更新通道；从仓库安装后点更新只替换插件文件，宿主补丁仍需 `--apply`（必要时先 `--revert`）。

### Notes

- 插件自身不含在线更新器，更新由 DSH 插件市场执行；本版本递增版本号供更新链路检测。

## [1.2.0-lite] - 2026-11-04

以「只做注入与补丁」为原则做的第二轮删减。与 1.1.90-lite 相比，删掉的模块不是停用，而是从代码树里彻底消失。

### Removed

| 模块 | 体积 | 原功能 |
|---|---|---|
| `lib/update.js` | 39 KB | 在线更新（拉 GitHub tar 包、换版本、重启） |
| `lib/official-update.js` + `.wscript` | 2 KB | 接管官方桌面升级、替换安装器 |
| `lib/skills.js` | 28 KB | `/skills` 技能库（导入、创建、删除、打包） |
| `lib/rewind.js` | 20 KB | 消息回退（`/rewind once\|round`） |
| `lib/continue-retry.js` | 11 KB | 超时/截断后自动补「继续」 |
| `lib/asset-table.js` 等 3 个 | 18 KB | 演练台资产表 |
| `lib/drill-grant.js` | 2 KB | 演练授权（靶标范围承诺） |
| `lib/redteam/role-section.js` | 6 KB | 红队子智能体角色稿 |
| `lib/reapply-cli.js` 等 6 个 | 32 KB | 入口不可达的死代码 |
| `lib/zip-extract.js` | 6 KB | 只被 `update.js` 使用 |

同时移除：

- 宿主补丁 `#45` / `#46`（`OFFICIAL_DESKTOP_UPDATE_HANDOFF` / `_ASCII`），补丁表 86 → **84**。
- 5 条 `dsh-redteam-*` 禁用行、`dsh.install` 在线安装源、三个红队关键词。
- 功能路由只保留 `/prompt-text`、`/apply`、`/revert`、`/override`、`/uninstall`、`/restart`、`/hooks-deny`、`/status`。
- 命令只保留 `/purge`（`/rules`、`/skills`、`/rewind` 注销）。
- 配置键 `autoUpdateOnStart`、`autoContinue`、`continueMax`、`continueText`、`autoRetry`、`retryMax` 从 `DEFAULTS` 与 `BOOLEAN_CONFIG_KEYS` 移除。
- 红队预设目录 `~/.dsh/.agent-presets/redteam/`（28 KB 人设 + anchor-gate）。

### Changed

- `lib/wsh.js` 新增：从 `official-update.js` 抽出的路径与 WSH 字面量工具，供补丁表复用。
- `client.js` 收敛为只读面板：状态、正文大小/行数/修改时间、来源路径、正文。
- README 重写，补齐安装、配置、接口、FAQ 与已知限制。

### Fixed

- CLI `--apply` 现在会写入应用戳，避免下次启动时 `settle` 误判未对齐而重复打补丁。
- `asset-table.js` 在文档与注释中明确标注为「加密出厂正文的解密槽」——它名字像资产库，但删掉注入正文就没了。

### Verification

```
文件数        54 → 40（lib 模块 38 → 27）
体积          1.2 MB → 913 KB
tgz           289 KB → 242 KB（37 个文件）
补丁          86 → 84
index.js      2914 行 → 2223 行
语法          node --check 全部通过
加载          import('dsh-purge') 通过，导出 7 个符号
前端接口      client.js 只读 /dsh-purge/prompt-text
```

### Migration

从 `1.1.90-lite` 升级必须：

```bash
node bin/dsh-purge.js --revert   # 清掉旧补丁 #45/#46
node bin/dsh-purge.js --apply
```

## [1.1.90-lite] - 2026-11-03

首个精简版基线。从上游 `dsh-purge` v1.1.90 裁出第一版可运行的精简形态：保留注入与补丁主链，砍掉外围面板。

[Unreleased]: https://github.com/Nero0427/dsh-purge-lite/compare/v1.5.4-lite...HEAD
[1.5.4-lite]: https://github.com/Nero0427/dsh-purge-lite/compare/v1.5.3-lite...v1.5.4-lite
[1.5.3-lite]: https://github.com/Nero0427/dsh-purge-lite/compare/v1.5.2-lite...v1.5.3-lite
[1.5.2-lite]: https://github.com/Nero0427/dsh-purge-lite/compare/v1.5.1-lite...v1.5.2-lite
[1.5.1-lite]: https://github.com/Nero0427/dsh-purge-lite/compare/v1.5.0-lite...v1.5.1-lite
[1.5.0-lite]: https://github.com/Nero0427/dsh-purge-lite/compare/v1.4.2-lite...v1.5.0-lite
[1.2.2-lite]: https://github.com/Nero0427/dsh-purge-lite/releases/tag/v1.2.2-lite
[1.2.1-lite]: https://github.com/Nero0427/dsh-purge-lite/releases/tag/v1.2.1-lite
[1.2.0-lite]: https://github.com/Nero0427/dsh-purge-lite/releases/tag/v1.2.0-lite
[1.1.90-lite]: https://github.com/Nero0427/dsh-purge-lite/releases/tag/v1.1.90-lite
