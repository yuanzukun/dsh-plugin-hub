# Roadmap

**Direction.** This plugin is **lightweight personalisation for the status line** —
the indicator in front of the turn-status text plus the text itself, with one
settings surface and nothing else. It stays deliberately small: no dependencies, no
build step, no config file, no network requests. It is not trying to be a phrase
engine — the text rotation is one feature, the indicator is the point. Everything
below serves that.

---

## 0.2.0 — Coexistence & quiet

- [x] **Indicator-only mode** — keep the loading icon, leave the status text
      untouched, so the plugin can sit alongside another status-text plugin instead
      of replacing it.
- [x] **Respect `prefers-reduced-motion`** — the indicator stops animating when the
      OS asks for reduced motion.
- [x] **Boot-time prefetch** (`dsh.client.immediately`) so the plugin is ready before
      the first status line appears.
- [x] **Declared requirements** — `>= 0.1.2-rc.1`, repository/homepage/bugs metadata,
      optional harness peer dependencies.
- [x] **Hardened status-line matching** — DSH 0.1.5 moved the status line into
      `dsh-client-ui-chat` and localized its label to the `chat.deepDiving` key. The
      primary class-token match was unaffected (plugin v0.1.0 already worked on DSH
      0.1.5); the label fallback now also covers the Chinese label, as insurance for
      the day the class token itself changes.

## 0.3.0 — Indicator options

The indicator is the differentiator, so make it a first-class, configurable element.

- [x] **Loader styles** — five, chosen in Settings: dot orbit (default), spinner
      ring, pulse, bouncing dots, equalizer bars. All share the configured font
      color and swap in place.
- [x] **Icon size** — small / medium / large (`0.8` / `1` / `1.25`), applied as a
      `--tq-loader-scale` transform so every style scales together.
- [ ] **Speed / gap** controls for the chosen style.
- [ ] **Phase-aware indicator** — calmer while the model is thinking, quicker while a
      tool is running, warmer on a long turn.
- [ ] **Elapsed-progress ring** — the ring fills as the turn runs, so the indicator
      carries information, not just motion.

## 0.4.0 — Theme & languages

- [x] **Match theme** — one button reads the active theme's accent off the live DOM
      (`--dsw-alias-link` → `--dsw-alias-state-business-primary` →
      `--dsw-static-deepseek-*`), keeps the hue and fits the lightness until the
      colour reaches 4.5:1 against `--dsw-alias-bg-base`. Follows theme switches
      until **Stop following** is pressed or the colour is edited by hand; a
      **Back to brand blue** button appears whenever a custom colour is in effect.
- [x] **Color presets** — brand blue / violet / teal / amber, one click each; every chip is
      fitted to the live background and floored at 4.5:1 (see 0.9.0 for the measurements, and
      for the Match-theme contrast defect the presets uncovered).
- [ ] **Generalize the `# <language>` sections** beyond Chinese / English: any
      `# <name>` header becomes a selectable section, and "Follow UI" maps the DSH
      locale onto it.

## 0.5.0 — Shape morph indicator

- [x] **Shape morph** — one SVG outline that becomes a circle → a rounded triangle
      → a rounded square → a circle, turning with a quintic ease so the rotation
      lags the shape and settles into each one. The geometry (rounded-polygon
      radial profiles, the blend, the path builder, both easings) is pure and
      unit-tested; the frame loop stops itself when the indicator leaves the DOM,
      and reduced-motion keeps a static circle.
- [ ] **Morph speed** — exposed by 0.6.0's global multiplier; a no-rotation variant
      for anyone who wants the shape change on its own is still open.

## 0.11.5 — The rainbow's colouring is restored, and every copy is phase-stamped (current)

- [x] **0.11.4 broke the text's rainbow — reverted, and why** — it moved the shell-token declarations
      from `.tq-line` (a stylesheet rule the text subtree inherits) onto the wrapper as INLINE
      `var(--tq-ink)` values. In the real shell the visible text then stopped following altogether
      (reported: "the text has no rainbow at all" while the icon stayed green). The single-clock idea
      was right; moving WHERE the tokens are declared was not. They are back on the line, and the
      sheet declares `--dsw-alias-label-deep-diving` / `--dsw-alias-label-shimmer` there again.
- [x] **The wave reads the line's ink instead of animating a third copy** — `.tq-wave` kept its own
      `--dsw-static-deepseek-500` and stayed blue under the rainbow; it is rebuilt on every text
      change, so giving it an animation of its own would reintroduce exactly the desync this release
      is about. Measured after the change: wave, its items and the icon are the SAME colour.
- [x] **Phase-stamping instead of a shared element** — two copies are unavoidable (the icon is a
      sibling of the line and cannot inherit its animation), so each copy is given, AT CREATION, the
      negative `animation-delay` that lands on the shared epoch's phase, with `important` priority
      (the sheet's `animation` shorthand is `!important` and otherwise resets it — the first attempt
      silently did nothing). Measured across a mid-turn loader change: **Δ = 0 immediately**, and
      ≈ 7-13 RGB units (about a tenth of a second of the six-second cycle) once the two have settled,
      against the 216/243 of whole-hue mismatch before.
- [x] **STAMP ONCE — re-aligning later makes it worse, recorded in the code** — a per-pass aligner
      was tried and dropped: changing `animation-delay` on a running CSS animation restarts its
      timeline in Chromium, so every pass pushed the copies further apart (measured delay drift
      -447ms → -4283ms → -7189ms with the drawn colour jumping each time). The note is in
      `inkPhaseDelay`'s JSDoc so it is not re-invented.
## 0.11.4 — One clock for the rainbow, so switching the icon cannot desync it

- [x] **The animation moved onto the wrapper** — reported as "switching the icon while it is thinking
      desynchronises the colours", and reproduced through the real settings path (a loader change only
      sends `patchConfig({ loader })`): every animated element ran its OWN copy of the animation, so the
      rebuilt icon span started at phase 0 while the text — seconds into its own copy — kept going.
      Measured Δ of 216 RGB units 1.3s after the switch, and 243 immediately after switching to a
      sprite (a fresh icon at the leading stop beside a violet text: the screenshot that started this).
      Now ONE animation runs on the wrapper the plugin owns, driving a registered `--tq-ink`; the icon,
      the line, the shell's text and its sweep all resolve that live value, so a node that joins later
      has no animation of its own to restart. Re-measured across two mid-turn switches
      (orbit → bars → jelly): **Δ = 0 at every sample**, with the wrapper's single clock advancing
      (900ms → 1917ms) while the icon, the line and the glyphs report no animation at all.
- [x] **Pinned by an assertion about the COUNT** — `test-presets.mjs` requires exactly one
      `animation:tq-rainbow-ink` in the sheet, with no `.tq-line,.tq-wave{animation…}` and no
      `.tq-loader{animation…}` of its own: a second copy is precisely the bug.

## 0.11.3 — The rainbow drives the shell's own paint too

- [x] **The icon and the text share one clock now** — reported as "with the rainbow the icon and the
      text do not transition together", and the screenshot agreed: a teal icon beside red text. The
      shell paints its visible glyphs through `TextShimmer`, which reads
      `--dsw-alias-label-deep-diving` / `--dsw-alias-label-shimmer` and NOT `color` — so animating
      `color` moved the icon while the text sat on the static sweep token written from the leading
      stop (measured: `#f06666`, unchanged, while the line cycled through six hues). A keyframe
      cannot animate a custom property unless it is registered, so `--tq-ink` is declared as a
      `<color>` through `@property`, the keyframes drive it beside `color`, and both tokens read it;
      the highlight stays a brighter version of the live hue via `color-mix`. `TextShimmer`'s base
      `.text` carries an EXPLICIT colour rather than a token (measured: it stayed
      `rgb(43, 83, 199)`), so the sheet also colours `[data-shimmer-text]` — the stable attribute
      the plugin already reads for the elapsed clock, and the element whose `::after` draws the
      glyphs.
- [x] **Measured, not assumed** — in a browser the icon, the glyphs and the sweep now agree at every
      instant (four samples across one cycle: `rgb(74,127,10)`, `rgb(12,128,147)`, `rgb(168,32,200)`,
      `rgb(232,19,26)` — all three parts equal per sample), where the sweep used to be a constant.
      `test-presets.mjs` pins the routing (the registered property, both token writes, the base-glyph
      rule), and its colour whitelist admits `var(--tq-ink)` while still failing on any literal that
      is not a fitted stop — a hidden `color:transparent` still fails.

## 0.11.2 — Three fixes reported from real use

- [x] **The plugin's own spinner ring is gone** — it was the same gesture as DSH's official state dot,
      which this plugin can render, so keeping both only made the dropdown longer. A saved choice of
      `ring` migrates to `stateDot` in `loadConfig` (a silent fall-back to the default would have left
      the dropdown and the line disagreeing), and the official option's own degradation path now falls
      back to `orbit` instead of the removed style. The ring's CSS-borders lesson stays in the history
      above; its painter, keyframes and rules are gone.
- [x] **The sprites are framed on their own content** — the delivery draws inside a 24-unit box with
      wide margins: the jelly block filled 42% of a 1em icon, the bead's track 56%, the bouncing ball
      33%, which read as "small next to the text" (reported). Each sprite now carries a `frame`
      (measured over one animation cycle in a browser) and draws through it, so every icon fills
      **93%-97%** of its box and its motion scales with it. The geometry itself is untouched: the
      delivery comparison still checks it against the SVG files field by field.
- [x] **…and three of them did not animate at all** — the first port turned the delivery's
      `translateY(4.6px)` into a unitless `4.6`, reasoning that a unitless length in an SVG transform
      is a user unit. That is true of the `transform` ATTRIBUTE, not of CSS, where `translateY(4.6)`
      is an invalid value and the whole declaration is dropped: bonk's mallet, the bead and the
      bouncing ball had **0px of travel** (measured). The unit is back (in CSS on an SVG element `px`
      *is* the local user unit, so it still scales with the box), and the browser acceptance now
      asserts that every sprite **visibly animates** — a part that moves at least 6% of its box, or one
      whose size changes by 15% — which is the check that would have caught it.

## 0.11.1 — A refresh no longer opens on the same quip

- [x] **The rotation's opening index is random per page load** — the quip index is derived from the
      clock (`floor(elapsed / quipMs) % count`) on purpose, so that a shell re-render cannot move the
      text or restart the animation; but its origin is the page load, so every refresh opened on index
      0 — the same first quip (`正在思考…`) no matter what had been showing before. The offset added
      here is an **index**, not a millisecond phase: it stays correct when the list length or the
      per-quip time changes, and the rotation still advances exactly one step per interval. It is
      chosen lazily on the first pass, which is where the list length is known.
- [x] **Pinned by a deterministic draw** — the self-check stubs `Math.random` to `0` and to `0.75` and
      asserts the opening quip is `list[0]` and `list[floor(0.75 × count)]`, that the two differ, and
      that the rotation then advances one step from wherever it opened.
## 0.11.0 — Eight contributed sprites

The design brief (`docs/loading图标设计需求.md` — in the repo, not in the published tarball) asks for 6–10 small
animated icons bound to the font size, and the eight delivered files in `.sprites/loading-icons/svg-final/`
arrived as static SVG carrying their own `<style>` blocks. This release adapts them into the plugin's
loader system rather than shipping them as they are.

- [x] **Geometry in a table, drawing in one function** — `LOADER_SPRITES` holds the delivered
      viewBox coordinates unrounded (a 24-unit box) and `ensureSprite` walks it. The stylesheet sizes
      the `<svg>` to `1em`, so the sprites scale with the content font size exactly like the plugin's
      own em-based drawings, and nothing writes a pixel size: the delivery's `translateY(4.6px)` /
      `translateX(10.4px)` became unitless user units (inside an SVG a unitless transform length IS a
      viewBox unit, while `px` there is a device pixel). The self-check walks the whole table to prove
      no value contains `px`.
- [x] **Their animations moved into the plugin stylesheet** — the delivered `<style>`/`<title>` are not
      ported; the keyframes live with the other loader rules, every duration is
      `calc(1.6s / var(--tq-speed,1))` (the families' shared rhythm, so the speed control scales them
      and a multi-part icon stays in phase with itself), and the two files that were missing a
      `transform-origin` gain it: tickTock's arm would have rotated about its own box centre instead
      of the axis, and pinwheel's blades about a point below the hub (an independent verification
      sampled the three blades and measured that bounding-box centre at (0, −1.946)).
- [x] **Reduced motion freezes each sprite on a frame that reads** — every classed part carries the
      `tq-sprite` marker, so one rule stops them all (sprites added later included). The ripple's
      second ring is pinned to `scale(.32)` (stopping alone would collapse both rings onto each other)
      and bonk's sparks carry a static `opacity="0"`, so a stopped animation leaves them invisible —
      the "cocked, not struck" still frame the family's own acceptance list asks for.
- [x] **Wired into everything that enumerates styles** — the settings dropdown, the i18n key check and
      the offline preview page all derive their lists from `LOADER_STYLES`, so the eight appear in each
      without a second list to keep in sync.
- [x] **Accepted in a real browser** (`.backups/_sprite-render-check.mjs`, 48 assertions):
      24-unit viewBox, no size in the markup, `currentColor` on every leaf, the
      font-size scaling (16px → 24px while the text goes 14px → 22px — the same `16px + delta` base the
      plugin's own icons use, proportions unchanged), the sm/md/lg ladder, every animation running with
      an advancing clock, and the still frame per icon. The self-check is the one that walks the
      geometry table (no `px`, strokes ≥ 1.5 viewBox units) **and compares all eight sprites against
      the delivered SVG files field by field** — the fidelity guard that an independent verification
      showed was missing when a silently rounded coordinate passed every other assertion.
## 0.10.0 — A rainbow that still keeps the contrast promise

- [x] **A fifth preset, and it is not a colour** — `rainbow` is a sentinel like `shimmer`: the config
      stores the word and the stylesheet animates the line's **colour** through six fitted stops, icon
      included. The chip is the one place it holds still (a moving target is a worse control than a
      still one), so the button shows the whole spectrum as a **static** gradient while the status
      line's colour cycles.
- [x] **…and the obvious implementation was wrong** — the first version painted a *clipped* gradient
      (`background-clip: text` plus a transparent fill). Every structural check passed and the flow
      was measured moving in a browser, yet in the real shell the text **disappeared and only the icon
      was left** (reported by the user): DSH renders its visible label through a pseudo-element
      (`<span class="text" data-shimmer-text="…"></span>` plus
      `::after { content: attr(data-shimmer-text) }`), and a clipped background on the ancestor does
      not paint pseudo-element glyphs. Animating `color` inherits into that pseudo-element and cannot
      hide it, whatever the effect is. The browser probe now asserts the **glyph colour and the
      pseudo-element's content**, not just the shape of the CSS — the check that would have caught it.
- [x] **Every stop is fitted, not just the first** — `rainbowStops(bg)` puts each of the six hues
      through the same fit-then-floor pipeline as a flat preset (`fitToTheme` → `readableOn`), so no
      colour the line can pass through is below 4.5:1. Measured over the same backgrounds the presets
      use: worst stop 4.51:1 (white; mid-grey is a hair better at 4.51). A rainbow was the obvious way
      to break the promise the other four keep; this is why it does not.
- [x] **The motion obeys the plugin's own rules** — the cycle reads `--tq-speed`, so Slow/Normal/Fast
      scale it with every other animation; `prefers-reduced-motion: reduce` freezes it **at the
      leading stop** instead of dropping it, because `animation: none` on its own leaves the shell's
      own colour — measured: the line fell back to DSH's brand blue and stopped being a rainbow at all.
      The icon cycles with the line, and a theme switch re-fits the stops against the background that
      is on screen. `test/test-presets.mjs` pins the stops' contrast per background, the six-stop
      keyframes, the "no transparent fill / no clipped background" rule (the bug above), the
      frozen-at-the-leading-stop rule, the static chip and the sentinel's storage round-trip;
      mutations that drop the floor, the reduced-motion rule, the chip gradient or the sentinel each
      fail a named assertion.

## 0.9.1 — The elapsed clock stops inheriting the previous turn

The time beside the quip could be the previous turn's age (a user saw "used 3h 24m" on a turn that
had just started), and the first attempt at fixing that made it restart at zero on every page
refresh while the shell's own line kept the right number — the user's second report, and their
question: "your clock and the real one disagree; why not just use the shell's own?"

- [x] **The shell's own clock is the primary source** — DSH knows the running turn's start (it reads
      it from its own store) and rewrites its label (`深度求索中，用时 10分46秒 ···` / `Deep diving
      for …`) once a second. The plugin hides that label while it owns the line but never removes it,
      so the authoritative number stays in the DOM: `durationFromText`/`labelDuration` read it back
      with the same unit vocabulary the plugin formats with, and `elapsedFrom` prefers it over
      everything else. That is what makes the plugin's line and the shell's line agree, and it is the
      only one of the three sources that survives a page refresh (a refresh re-mounts the plugin but
      not the shell's store) — measured from the report where the plugin read 8m 27s while the shell
      read 10m 46s, the difference being exactly the time since that refresh.
- [x] **The seat and the self-timer stay as fallbacks** — a shell whose label is missing or carries
      no duration falls back to the `turnTail` seat, then to the self-timer. The seat rules stay
      (only an `open` turn may set the clock; a `start.time` that is not a finite number is refused;
      an older turn can never move it backwards; a held turn that closes gives it back), because that
      seat is rendered once per turn tail and a finished turn's tail stays mounted — which is the
      "used 3h 24m" bug this release opened with.
- [x] **The DOM never drops the official clock** — the first attempt cleared it on the first pass
      that missed the running line; a refresh re-mounts that line, the seat does not re-run for a
      DOM-only change, and so the start was gone for the rest of the turn and the clock restarted at
      zero. Leaving the line now resets only the self-timer. `test-adapt-02.mjs` pins the precedence
      ("the shell's own duration wins over the seat's start") and "a line that leaves never drops the
      official clock"; `test/test-clock.mjs` pins the parser, the precedence chain and the seat
      rules. Each half is mutation-checked — ignoring the label, breaking the parser, and skipping
      the close-clear each fail a named assertion.
## 0.9.0 — Colour presets & the contrast promise

Four one-click colours, a promise the plugin used to make and did not always keep, and two
tests that could not have caught either.

- [x] **Colour presets** — brand blue / violet / teal / amber as four chips in the settings
      page, one click each. A chip is *not* a stored hex: it is fitted to the background on
      screen and then floored at 4.5:1 (`presetColor` = `readableOn(fitToTheme(base, bg), bg)`),
      so the same chip stays legible in the light and the dark theme — measured over 4 presets ×
      8 backgrounds (32 combinations), worst value 4.52:1. Picking one writes `colorTheme: false` for the
      same reason typing a hex does (a preset is the user naming a colour; staying on follow
      would let the next theme switch overwrite the click). Brand blue writes the `shimmer`
      sentinel rather than a hex, because in this plugin `shimmer` *is* the default brand blue
      and the only value that leaves DSH's own `TextShimmer` and its theme token untouched —
      writing a hex there would silently turn "the default" into "an override".
- [x] **The 4.5:1 promise is now kept on the Match-theme path too** — this was a real, shipped
      defect, surfaced while building the presets: a *preset* with a teal hue was more readable
      than the theme match of the same hue. `fitToTheme` walks lightness inside a band and
      **breaks at the band edge**, so it could return a colour still under `MIN_CONTRAST`:
      measured `fitToTheme("#0E9C8E","#ffffff")` = 3.61:1 and `fitToTheme("#C47A00","#808080")`
      = 3.07:1. On a mid-tone background the band points the wrong way entirely — over the 51
      dead-zone greys × 108 accents (**5,508 combinations**), **5508/5508** results were under
      4.5:1 before the fix (worst 1.18:1) and **0** were after (worst 4.50:1); the whole grey
      range (86 × 108 = 9,288 combinations) is clean after it. The fix is one line: `matchThemeColor`
      now returns
      `readableOn(fitToTheme(accent, bg), bg)`, the same floor the presets use. The band and
      `fitToTheme`'s own look are deliberately untouched, and a separate assertion pins
      `fitToTheme("#0e9c8e","#ffffff") === "#0e978a"` so the floor cannot be "achieved" by
      widening the band instead. Following the theme is unaffected: the matcher's report carries
      no `colorTheme` field, and the settings page now shows 4.57:1 where it used to show 3.61:1.
- [x] **Two test-honesty gaps closed** (both found by independent verification, not by the author
      of the code). `test/test-sections.mjs` carried a **hand-written copy** of
      `parseQuips`/`selectPhrases`, so breaking the shipped parser left it green; it now loads the
      real module through `__internal` (a mutation that breaks the shipped header regex turns it
      red — the old copy stayed green on that same mutation). And `test/test-i18n.mjs` treated the
      new `quips.preset.*` keys as *notes* rather than assertions, so deleting one from both
      dictionaries was invisible; it now enumerates `COLOR_PRESETS` through `__internal`, so a key
      missing from either language fails. DSH renders a missing key as the key itself, so the user
      would otherwise have read `quips.preset.teal` on the settings page.
- [x] **Docs that had drifted** — the package description still advertised "six configurable
      loading icons" (there are nine) and both READMEs still listed a separate "glow strength"
      control that 0.8.0 had already folded back into sweep brightness; the handover doc also
      carried a real local machine path, which the workspace's own rules forbid in a committed
      file. No behavioural claims were added beyond what 0.9.0's checks measured.

## 0.8.0 — Official surfaces, the settings page & animation stability

Reuse what DSH already ships instead of redrawing it, give the settings a page of their own in
the settings nav, and stop the running line's own re-renders from interrupting what is on screen.

- [x] **Official icon options** — three more loader styles, each reusing DSH's own asset
      rather than a copy of it: `stateDot` renders the seeded `StateDot` in its `ongoing`
      state (a real spinner, through a small React root), `fish` assembles the seeded
      `FISH_LOGO_PATH` into the plugin's own svg, and `native` **clones DSH's own
      running-line whale** out of the live DOM. The clone is byte-identical and keeps both
      of DSH's variants — the 60-frame APNG mask and the static SVG — so the official
      `@supports` / `prefers-reduced-motion` gating keeps working for free. When the icon
      node is not there, `native` falls back to reading the mask out of the official
      stylesheet's CSSOM (the rule is nested two levels deep, `@supports` → `@media`), and
      when neither is available it degrades like the other official options
      (`stateDot` → the plugin's own spinner at the time — `orbit` since 0.11.2, `fish`/`native` → `orbit`). DSH's whale is a **choice** rather than
      a permanent neighbour: whenever the plugin draws an icon of its own, the wrapper is
      marked (`data-tq-icon`) and the stylesheet retires DSH's node by attribute — leaving
      the node itself untouched — so the line always shows exactly one indicator. Pick
      `native` to have DSH's own whale be that one.
- [x] **The raster whale: sized in pixels, with a speed cue** — DSH's running whale is a
      28×28 APNG used as an alpha mask, so the shared `transform: scale()` rasterised it at
      14px and then stretched the bitmap, which is visibly soft at Large. `native` now sizes
      the box itself (`calc((14px + font-delta) * var(--tq-loader-scale))`) and opts out of
      the transform, so the mask is rasterised at its final size (11.2 / 14 / 17.5px — all
      downscales from 28px). The APNG's 60 frame delays live *inside the image*, which no CSS
      property can retime, so a speed level adds the plugin's own swim cue around the
      official motion (`1.4s / speed`), written only off Normal — Normal still overrides
      nothing — stopped by `prefers-reduced-motion`, and explained in the settings row while
      `native` is selected.
- [x] **The icons follow the global font size** — the seven styles the plugin draws itself were
      frozen on a 16px grid, so they silently ignored the one size the user can change globally.
      DSH publishes the content font size as `--dsh-content-font-delta` (= font size − 14px) and
      sizes its own running icon as `14px + delta`; the plugin's own drawings now declare that base
      once (`font-size: calc(16px + var(--dsh-content-font-delta, 0px))`) and express every
      geometry in `em`, so they grow with the text with no JS, no observer and no re-render —
      measured 16 / 17 / 20px at delta 0 / 1 / 4. The mounted official nodes are deliberately
      excluded (`stateDot`/`native` size themselves — the probe showed their `font-size` untouched
      while the native *box* still tracked `14px + delta`), and `native`'s mask branch (`:empty`)
      now includes the delta as well; it was the one place still reading `14px * scale`.
- [x] **A face in the plugin list** — the settings inventory (内置插件) reads display metadata
      from the package WITHOUT loading the plugin, so that row used to show the raw package name
      and the panel's default artwork. It now ships `icon.svg` (36x36, transparent, the soft
      two-gradient recipe the one shipped row with an icon uses — a speech bubble whose pointer
      is a whale fluke) and `locale/{en,zh}.json`; `"./locale/*.json"` had to join `exports`, or
      the resolver never sees the files and the fallback quietly wins. `test-package.mjs`
      asserts every rule DSH applies, including that the row's title equals the plugin's own.
- [x] **The settings live on their own page** — twelve controls were a row under General
      (`settings.general.item`), which is the seat for *one* preference and shared with every
      other plugin that adds one. They moved to `settings.section`: its own nav entry
      (id `thinking-quips`, order 30, label thunk so it follows the locale), rendering the page
      body into the panel's content column.
- [x] **A nav glyph of the plugin's own** — DSH picks the settings-nav icon from a table keyed
      by section id (`navIcon` in dsh-client-ui-settings-general) and hands an unknown id the
      settings gear, so a third-party section cannot supply one. The plugin marks its own nav
      row (`data-tq-section`, matched by the label it registered) and the stylesheet retires the
      gear in that row and paints a **16×16 whale tail** as a mask — same box as DSH's icons
      (measured: viewBox 16, size 16, `ICON_MEDIUM_STROKE` 1.3), drawn filled because a 1.3
      outline closes up at that size. If the panel's markup ever changes, no row matches and the
      gear simply stays.
- [x] **Indicator-only works like the rest of the line** — with the text handed back to DSH,
      the icon used to be *appended*, so it landed to the RIGHT of DSH's own label, and it was
      the single custom-coloured thing on a line whose text kept DSH's default colour. The icon
      is now anchored on "whatever renders the text" (the plugin's own line, else DSH's label),
      the empty plugin line is removed rather than left behind to become that anchor, and the
      icon follows DSH's own running-text token — which `paintHost` also writes when a custom
      colour is set. The mode stays: it is the only way to sit next to another plugin that owns
      the status text.
- [x] **The sweep's brightness is a control again** — retired with the `glow` effect it used
      to belong to, it came back where it actually belongs: measured in the installed
      primitives, the official `TextShimmer` stylesheet paints `.sweep { color:
      var(--dsw-alias-label-shimmer) }` and masks it with a moving gradient, so that token IS
      the highlight. `glow` (0–100) now writes a mix of the text colour toward white there: the
      shipped default writes nothing at all (DSH keeps painting), the default colour with
      another brightness writes only the sweep, and a custom colour moves both. The preview
      page reproduces that component from its own stylesheet so the control can be seen.
- [x] **One sweep, not two** — the plugin used to carry its own hand-painted
      `background-clip:text` gradient as the `glow` effect (and as the fallback when the
      primitives were missing). Side by side with the official sweep it was
      indistinguishable, so it is gone: `TEXT_EFFECTS` is now `shimmer` (DSH's own
      `TextShimmer`, rendered through the seed) plus `wave`, the painted-gradient CSS and
      its keyframes are deleted along with the `glow` strength setting, and a shell with no
      primitives falls back to plain text (guarded, so it cannot churn the DOM). A saved
      `official` or `glow` config maps onto the sweep.
- [x] **A re-render must not touch the quip or the animation** — DSH rebuilds the running
      line whenever the turn re-renders (every tool call, and once a second for the elapsed
      label). The plugin used to read "there is no icon in this element yet" as a first paint,
      so every tool call reset the rotation to quip #1 — which changed the text and rebuilt the
      animating container. The rotation now comes from a clock alone (`quipIndex`), and when
      the line is replaced the plugin's own nodes are **carried over** into the new element
      (`adoptNodes`), with the official React root re-pointed rather than remounted. For the
      same reason `wave` now updates its tokens' text in place when the token shape is
      unchanged, so the once-a-second elapsed tick no longer restarts the wave.
- [x] **The icon keeps its place when the style changes mid-turn** — the rebuild used to
      `appendChild`, so picking another style while a turn was running pushed the icon to the
      END of the line (past the plugin's own text). It is now inserted immediately before the
      plugin's own `line` element, and the "nothing to redraw" path repairs a misplaced icon
      once (checked with `previousElementSibling`, so a whitespace text node cannot make it
      re-insert every pass — that would feed the observer loop fixed below).
- [x] **Two real bugs found by actually rendering the gallery** (not by reading code):
      the shimmer/official fallback deleted and rebuilt its glow container on every pass,
      and the plugin's own `document.body` MutationObserver turned each mutation into
      another pass as a microtask — an endless chain that froze the tab (in headless
      Chromium `DOMContentLoaded` never fired). It now reuses the container, so the
      `data-text` guard holds. Separately, the morph loop's `requestAnimationFrame`
      *handle* was being called as a function, which threw inside `ensureLoader`'s
      try/catch and silently dropped every second and later morph icon; it is now
      cancelled with `cancelAnimationFrame`. Both have regression assertions.
- [x] **Settings controls from the seeds** — the row's hand-written switch, segmented
      controls and modal are now thin wrappers around the seeded `Switch`,
      `SegmentedControl` and `Modal`, each falling back to the old hand-written markup on a
      shell that seeds nothing. The official `Modal` brings its own mask, close button,
      Escape/Tab handling and focus restore (and `data-modal-autofocus` for the textarea).
- [x] **Running surface** — the plugin reads `dshDesktop` / `<html data-platform>` and
      watches the mark, because it can arrive as late as `DOMContentLoaded`. The result is
      a runtime fact: it lives in a store that is deliberately **not** persisted (it must
      never end up in the saved preference config) and is echoed read-only in the settings
      row as `data-tq-surface` / `data-tq-platform`.
- [x] **Offline animation gallery** — `preview/animations.html`, generated by
      `tools/build-preview.mjs`. It embeds the shipped `lib/client.js` verbatim and calls
      the plugin's own `injectPluginCss` / `ensureLoader` / `applyStatusText` / `apply` on
      mock status lines, inlining the official whale stylesheet and logo path extracted
      from the installed DSH. `test/test-preview.mjs` rebuilds it in memory, so a page
      that has fallen behind the plugin is a red self-check rather than silent rot.

## 0.7.0 — DSH 0.2

- [x] **0.2 anchor** — the running line is `[data-chat-running]` now, and the only
      `role="status"` inside it is a screen-reader announcement clipped to 1px, so the old
      `[class*="turnStatus"]` match (and its "Deep diving" text fallback) aimed the quips
      at an invisible node. The plugin matches the attribute first, keeps the 0.1.x token
      as a fallback, and never writes into the announcement.
- [x] **Line ownership** — on 0.2 the visible label lives inside DSH's `TextShimmer` and
      React rewrites it every second (it carries the live elapsed time), with an inert
      decoration copy mirroring it through `data-shimmer-text`. So the plugin hides that
      label by attribute (`data-tq-owned`) and paints its own `.tq-line` instead of
      blanking a node React owns. DSH's whale icon is left alone: the two coexist.
- [x] **Official shimmer via the seed** — 0.2 seeds
      `@deepseek-ai/dsh-client-ui-primitives` for every client plugin, so `shimmer` (and
      its alias `official`) renders DSH's own `TextShimmer` through a small React root
      instead of reimplementing the sweep. `glow` keeps the pre-0.2 painted gradient, on
      the plugin's own node.
- [x] **Elapsed time** — `conversation.chat.turnTail` (official, session-scoped) hands over
      `turn.start.time`. It turned out to be rendered **once per turn tail** — finished turns
      included, and their tails stay mounted — which is why 0.9.1 had to constrain it to an open
      turn; the clock uses that official start with a self-timer fallback. Inline folds the duration into the
      animated text (the 0.2 shape); separate renders it as a tertiary-grey note outside
      the animation (the 0.1 shape); off hides it. The format matches DSH's
      `formatRunDuration` (verified over 13 inputs in both locales).
- [x] **Colour hook migration** — the pre-0.2 `background-image` surgery is replaced by
      `--dsw-alias-label-shimmer` on the running wrapper (the official `.running` rule
      re-maps it to its deep-diving tint), plus `--tq-base`/`--tq-hi` for the plugin's own
      nodes.
- [x] **Speed stays ours** — 0.2 animates its sweep on `.sweep`/`.highlight` inside a
      component the plugin does not own, so the speed control scales only the plugin's
      animations (0.6.1's "the official sweep keeps its own pace", now enforced by the
      markup rather than by choice).
- [x] **Declaration hygiene** — `@deepseek-ai/dsh-client-runtime` no longer exists in 0.2
      (the profile still had a dangling junction for it); dropped from `dsh.client.inject`
      and the peers, `engines.dsh` bumped to `>=0.2.0-rc.2`.
- [x] **Adopt more official UI** (landed in 0.8.0) — the settings row used to hand-roll its
      switch, segmented control and modal; `@deepseek-ai/dsh-client-ui-primitives` exports
      `Switch`, `SegmentedControl`, `Modal`, `Toast` and `SettingsForm`, and the row now
      prefers the first three.
- [x] **Native icon options** (landed in 0.8.0) — DSH's whale (`native`), `StateDot` and the
      `FishLogo` path are now loader styles (the zero-copy ways to reach the whale APNG are
      recorded in the source repository's `docs/状态行扩展调研.md`; research notes are not
      shipped in the npm package).

## 0.6.0 — Text effects & one global speed

- [x] **Text effect** — **Shimmer** (DSH's own sweep, default) or **Wave**: each CJK
      glyph / Latin word lifts in turn, left to right, staggered in pure CSS. The wave
      owns its colour and text fill, so it does not depend on DSH's text clip; the line
      is handed back to DSH when the quip list is empty, and the label node React owns
      is blanked rather than removed.
- [x] **One animation speed, in three steps** — Slow / Normal / Fast (0.5× / 1× / 2×)
      scales the loading icons, the shape morph, the wave and DSH's shimmer sweep, through
      one CSS variable (and one elapsed multiplier for the morph). "Normal" is the shipped
      pace and overrides nothing at all.
- [ ] **More effects** — the same machinery admits a typewriter or a per-word fade; the
      tokeniser and the settings dropdown are already in place.
- [ ] **Effect per language** — CJK and Latin could run different effects, since the
      tokeniser already knows which is which.

## Later / considered

- [ ] Optional: persist config in the official DSH settings namespace
      (`$DSH_HOME/settings.yaml`) via a node-side route, so it survives plugin
      upgrades — today it lives in `localStorage`.
- [ ] Optional: publish to npm with build provenance.
- [ ] **Test strength: the lightness-band guard is weaker than it looks** (recorded by the
      independent verification of 0.9.0, not fixed there). The `l <= 57.5` / `l >= 61` assertions
      still pass when the band's *lower* edge is widened (32 → 18), and **nothing** fails when the
      *upper* edge is (56 → 70). What actually catches a widened band today is the pinned
      `fitToTheme("#0e9c8e","#ffffff")` value. To pin the band itself, assert the two constants,
      or the band on a clamped input (e.g. a very light accent at `l = 80`).
- [ ] **Test strength: the contrast floor is still asserted against `MIN_CONTRAST` itself**
      (same verification). Lowering that constant to 1 is caught by the "held input" premises and
      the pinned value, not by the `>= MIN_CONTRAST` comparisons — so the guard disappears the day
      those premises do. A literal `4.5` in at least one assertion would make it independent.

- [ ] **Two limits of reading the shell's clock** (recorded, neither reachable in the two shipped
      shapes). The parse knows the two locales DSH ships (`小时/分/秒` and `h/m/s`), so a third one
      would fall back to the seat — still the same turn start, just not the same rendering; and a
      shell that rendered a `runningText` label without `data-chat-running` would let the plugin
      read its own line, so `labelDuration` could skip labels inside its own `.tq-line`.

## Non-goals

Deliberately **not** planned — they belong to a different, heavier kind of plugin:

- danmaku / bullet-screen output
- theme packs and phrase-pack marketplaces
- typewriter rendering
- browser tab-title rotation
- presets and time-of-day scheduling

This plugin stays the calm, small option: no config file, no network requests, no
file writes, and a status line that is pleasant rather than loud.
