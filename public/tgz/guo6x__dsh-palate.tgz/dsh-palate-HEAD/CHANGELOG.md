# Changelog

All notable changes to dsh-palate.

## [0.6.2] - 2026-08-30

### Added

- Add a keyless `pnpm demo` that exercises the shipped host bundle, local palate, retrieval, and Web route without a model or API key.
- Add a first-run card to the Web panel with an explicit local-readiness state and a copyable review prompt, so plugin installation and provider authentication are easy to distinguish.
- Document the first-run demo, expected Web signals, and a failure matrix in English and Chinese.

## [0.6.1] - 2026-08-27

### Fixed

- Omit absent session-context fields from staged training candidates, so `palate_intake` returns lossless JSON to the real DSH host instead of staging successfully and then failing output validation.

## [0.6.0] - 2026-08-27

### Added

- A visual-training desk: `palate_intake` stages structured hierarchy, typography, color, spacing, interaction, and related observations as a reviewable session instead of immediately changing learned taste.
- `palate_candidates` exposes the pending/resolved training queue; `palate_decide` is the only path that accepts or rejects candidates after an explicit human decision. Accepted examples and principles retain their session provenance; rejected candidates remain auditable without changing the palate.
- Explicit `aligned`, `conflicts`, and `insufficient_evidence` comparisons against visual-reference packs. A comparison against an unapplied pack is clearly marked reference-only and never activates that pack.
- A loopback `/palate/training` API, `training.md` read-only mirror, candidate-queue stats, and panel visibility for staged sessions and decisions.
- Principle provenance storage with an additive migration for existing SQLite palates.

## [0.5.0] - 2026-08-27

### Added

- Two opt-in, auditable visual-reference packs: Apple-inspired product storytelling and X-inspired direct utility. They distill public-page observations into abstract principles and examples without shipping brand assets, copy, or imitation templates.
- `palate_packs` to inspect available packs and `palate_seed` to apply one or more packs exactly once without replacing an existing palate.
- Style tags now filter both examples and style-specific principles in `palate_review`, so `apple` and `x` references cannot bleed into each other while universal rules remain available.
- A tagged-principle migration check, pack API, and panel visibility for applied reference packs.

## [0.4.3] - 2026-08-26

### Fixed

- Keep GitHub installs lifecycle-script free: the committed `lib/` entrypoints are the source of truth, so pnpm does not need to run a blocked `prepare` build for this Git dependency.
- Add CI coverage that fails when a source change leaves the committed `lib/` output out of sync.

## [0.4.2] - 2026-08-26

### Fixed

- Run the build through `prepare` when the plugin is installed as a Git dependency, while retaining committed `lib/` entrypoints as a fallback.

## [0.4.1] - 2026-08-26

### Fixed

- Dock the growth panel below the browser cockpit by default and cap its height so opening the DSH plugin panels together does not hide controls.

## [0.4.0] - 2026-08-25

### Added

- Four transparent starter examples are seeded only when a profile has no taste examples, giving the first review concrete good/bad evidence without overwriting existing user data.
- The growth panel now shows recent tracked reviews and the exact example refs captured as evidence through the read-only `/palate/reviews` route.

## [0.3.3] - 2026-08-25

### Changed

- Make the GitHub first-run path explicit in both READMEs: install, restart, visible success signal, a safe 90-second learning-loop demo, and recovery steps.

## [0.3.2] - 2026-08-25

### Fixed

- Declare the client-side `slots` dependency before registering the sidebar button and overlay, so the DSH Web UI loads the palate panel instead of rejecting the plugin at startup.
- Make the sidebar button and overlay subscribe to the same open state; dragging now uses the title bar only and calculates from the pointer-down position.
- Add a generated-client contract test that verifies the injection declaration, both slot registrations, and shared panel state.

## [0.3.1] - 2026-08-25

### Fixed

- Commit the built `lib/` entrypoints required by GitHub/path installations, so the published plugin always contains the files declared by `main` and `exports`.

## [0.3.0] - 2026-08-25

### Added

- Tracked `palate_review` records with a `review_id` and a snapshot of the principles and examples used as evidence.
- `palate_feedback` records one helpful/mixed/unhelpful outcome per review, plus accepted and rejected reviewed principles. Only accepted principles gain evidence.
- `palate_effectiveness`, a loopback `/palate/effectiveness` endpoint, `feedback.md`, and the growth panel expose real acceptance/rejection history separately from raw corpus size.

## [0.2.0] - 2026-08-25

### Changed

- `palate_review` now ranks examples against the actual review subject instead of returning merely recent examples.
- Local zero-dependency retrieval scores words and tags, includes Chinese word fragments, exposes matched terms, and omits unrelated evidence when no tag filter was requested.

## [0.1.0] - 2026-08-16

### Added

- **Accumulated taste store**: a growing corpus of design examples (good/bad/notes with reasons + tags) plus codified principles, backed by `node:sqlite` with human-readable Markdown mirrors (`taste.md`, `principles.md`).
- **Starter palate**: 12 foundational design principles seeded on first run (hierarchy, contrast, type scale, spacing, alignment, palette discipline, consistency, affordance, proximity, feedback, clarity, anti-AI-slop).
- **Six tools**: `palate_review` (assemble learned taste as critique context), `palate_add` (feed examples), `palate_learn` (distill principles), `palate_list`, `palate_principles`, `palate_stats`.
- **Reinforcement loop**: verdicts can reinforce the principles they support, bumping evidence counts.
- **Growth panel**: draggable Web GUI overlay showing examples studied, principles distilled, and recent judgments.
- Zero runtime dependencies; 17 pure-logic smoke checks; GitHub Actions CI.
