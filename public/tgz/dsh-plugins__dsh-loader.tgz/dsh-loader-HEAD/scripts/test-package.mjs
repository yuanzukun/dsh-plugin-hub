/** Verify the packed archive, outside this repository's dependency tree. */
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, readdirSync, symlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, relative, resolve } from 'node:path';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
const temp = mkdtempSync(join(tmpdir(), 'dsh-loader-package-'));
const run = (cmd, args, options = {}) => execFileSync(cmd, args, { cwd: temp, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], ...options });
const npm = process.env.npm_execpath;
assert(npm, 'Run through npm run test:package');
const [packed] = Object.values(JSON.parse(run(process.execPath, [npm, 'pack', '--json', '--pack-destination', temp], { cwd: root })));
assert(packed && typeof packed.filename === 'string' && Array.isArray(packed.files), 'npm pack returned no package metadata');
const packageDir = join(temp, 'node_modules/@dsh-plugin/dsh-loader');
mkdirSync(packageDir, { recursive: true });
run('tar', ['-xf', join(temp, packed.filename), '-C', packageDir, '--strip-components=1']);
assert.equal(JSON.parse(readFileSync(join(packageDir, 'package.json'), 'utf8')).version, '2.0.0');
for (const file of ['README.zh_CN.md', 'docs/config-api.md', 'docs/support.md', 'examples/config-plugin/index.mjs', 'examples/config-plugin/operations.mjs', 'examples/config-plugin/client.tsx']) {
  assert(packed.files.some(entry => entry.path === file), `Missing packed documentation: ${file}`);
}
const link = (name, from = require) => {
  const target = dirname(from.resolve(`${name}/package.json`));
  const destination = join(temp, 'node_modules', name);
  mkdirSync(dirname(destination), { recursive: true });
  symlinkSync(target, destination, process.platform === 'win32' ? 'junction' : 'dir');
};
for (const name of ['semver', '@arco-design/web-react', '@icon-park/react', '@types/node', '@types/react', '@types/react-dom']) { link(name); }
const reactTypes = createRequire(require.resolve('@types/react/package.json'));
for (const name of ['@types/prop-types', 'csstype']) { link(name, reactTypes); }
link('undici-types', createRequire(require.resolve('@types/node/package.json')));
writeFileSync(join(temp, 'package.json'), JSON.stringify({ type: 'module', private: true }));

function walk(folder) { return readdirSync(folder, { withFileTypes: true }).flatMap(item => item.isDirectory() ? walk(join(folder, item.name)) : [join(folder, item.name)]); }
for (const file of walk(packageDir).filter(file => file.endsWith('.d.ts'))) {
  const source = readFileSync(file, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '');
  assert(!/(?:from\s*|import\s*\()\s*['"]@deepseek-ai\//.test(source), `Upstream type dependency: ${file}`);
}
const subpaths = Object.keys(JSON.parse(readFileSync(join(packageDir, 'package.json'), 'utf8')).exports)
  .filter(name => !['./package.json', './cordis.patch.yml'].includes(name));
writeFileSync(join(temp, 'consumer.mts'), subpaths.map((path, index) => `import type * as Entry${index} from '@dsh-plugin/dsh-loader${path === '.' ? '' : path.slice(1)}';`).join('\n') + `
import { defineConfig, type ConfigHandle, type ConfigField } from '@dsh-plugin/dsh-loader/config';
import type { HostAPI, CordisContext } from '@dsh-plugin/dsh-loader';
import type { ToolArgsError } from '@dsh-plugin/dsh-loader/tools';
import type { SlotCore } from '@dsh-plugin/dsh-loader/ui-slots';
import { Arco, ModelSelect, type DshLoaderUi, type ConfigDialogProps, type ConfigPanelProps, type ModelSelectProps, type ConfigModelSource } from '@dsh-plugin/dsh-loader/client';
import * as React from 'react';
import type { ConfigModelValue } from '@dsh-plugin/dsh-loader/config';
interface Example { title: string }
declare const api: HostAPI, ctx: CordisContext;
declare const ui: DshLoaderUi;
const dialog = ui.config.registerDialog<Example>(ctx, { id: 'editor', configId: 'example', field: ['document'], title: 'Editor', component(props: ConfigDialogProps<Example>) { props.setReader(async signal => { signal.throwIfAborted(); return { title: props.value.title }; }); return null; } });
dialog.open().then(session => session.save());
ui.config.registerPanel(ctx, { configId: 'example', id: 'manager', component(props: ConfigPanelProps) { return React.createElement('button', { onClick: () => props.client.invoke(props.view.template.id, 'items.list', { input: {} }) }, '刷新'); } });
const group: ConfigField = { type: 'group', label: 'Group', collapsible: true, defaultCollapsed: true, fields: [{ type: 'text', key: 'title', label: 'Title' }] };
const model: ConfigModelValue = { provider: 'example', model: 'example-model', reasoningEffort: 'custom' };
const modelField: ConfigField = { type: 'model', key: 'assistantModel', label: '辅助模型', default: model };
const loadModels: ConfigModelSource = async signal => { signal.throwIfAborted(); return { groups: [{ id: 'example', name: '示例', models: [{ id: 'example-model', name: '示例模型' }] }], failures: [] }; };
const modelProps: ModelSelectProps = { value: model, onChange(value) { if (value) { console.log(value.provider); } }, loadModels };
ModelSelect(modelProps);
const arcoButtonProps: Arco.ButtonProps = { type: 'primary', children: '保存配置' };
const arcoSelectProps: Arco.SelectProps = { options: ['foo', 'bar'] };
const arcoButton: React.ReactElement<Arco.ButtonProps> = React.createElement(Arco.Button, arcoButtonProps);
React.createElement(Arco.Select, arcoSelectProps);
const handle: Promise<ConfigHandle<Example>> = api.config.register<Example>(ctx, defineConfig({ id: 'example', packageName: '@example/plugin', title: 'Example', fields: [group] }));
handle.then(config => config.registerOperation('preview', ({ input, resource, config: saved, signal }) => ({ value: { text: String(input.text), revision: saved.revision, aborted: signal.aborted }, ...(resource ? { resource } : {}) })));
defineConfig({ id: 'editor', packageName: '@example/editor', title: 'Editor', fields: [], panels: [{ id: 'documents', title: 'Documents', fields: [{ type: 'textarea', key: 'text', label: 'Text' }], operations: [{ id: 'preview', input: ['text'], readOnly: true, button: { label: 'Preview' }, result: [{ type: 'markdown' }] }] }] });
`);
writeFileSync(join(temp, 'tsconfig.json'), JSON.stringify({ compilerOptions: { strict: true, noEmit: true, skipLibCheck: false, module: 'NodeNext', moduleResolution: 'NodeNext', target: 'ES2023', jsx: 'react-jsx', types: ['node', 'react'] }, files: ['consumer.mts'] }));
const { API } = await import('typescript/unstable/sync');
const compiler = new API({ cwd: temp });
try {
  const snapshot = compiler.updateSnapshot({ openProjects: [join(temp, 'tsconfig.json')] });
  const program = snapshot.getProject(join(temp, 'tsconfig.json'))?.program;
  assert(program, 'Packed-consumer TypeScript project was not loaded');
  const diagnostics = [
    ...program.getConfigFileParsingDiagnostics(), ...program.getProgramDiagnostics(),
    ...program.getGlobalDiagnostics(), ...program.getSyntacticDiagnostics(),
    ...program.getSemanticDiagnostics(),
  ];
  // Arco 及其依赖自带有误的声明；仍严格检查发布包、消费方及所有依赖解析错误。
  const ownDiagnostics = diagnostics.filter(diagnostic => {
    if (!diagnostic.fileName || [2307, 2688, 7016].includes(diagnostic.code)) {
      return true;
    }
    const path = relative(temp, diagnostic.fileName);
    return path !== '..' && !path.startsWith(`..${process.platform === 'win32' ? '\\' : '/'}`);
  });
  const upstreamDiagnostics = diagnostics.filter(diagnostic => !ownDiagnostics.includes(diagnostic));
  if (upstreamDiagnostics.length > 0) {
    console.log('Third-party declaration diagnostics:', upstreamDiagnostics.map(({ fileName, code }) => ({ fileName, code })));
  }
  assert.equal(ownDiagnostics.length, 0, JSON.stringify(ownDiagnostics, null, 2));
} finally {
  compiler.close();
}
console.log('Packed declarations: all public subpaths typecheck without dsh installed.');

// Only runtime ABI fixtures are installed after the no-upstream type test.
const names = ['tools', 'llm', 'agent', 'settings', 'timeout', 'subagent', 'credentials', 'compaction-basic'];
for (const name of names) {
  const dir = join(temp, 'node_modules/@deepseek-ai/dsh-' + name);
  mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, 'package.json'), JSON.stringify({ name: '@deepseek-ai/dsh-' + name, type: 'module', exports: './index.js' }));
  const source = readFileSync(join(packageDir, 'src/stable', name + '.js'), 'utf8');
  const exports = [...source.matchAll(/export const (\w+) =/g)].map(match => match[1]);
  writeFileSync(join(dir, 'index.js'), exports.map(name => name === 'defineTool' ? 'export function defineTool(value) { return value; }' : `export const ${name} = {};`).join('\n') + (source.includes('export default') ? '\nexport default {};' : ''));
}
writeFileSync(join(temp, 'runtime.mjs'), `
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const Module = require('node:module');
const original = Module._resolveFilename;
const root = await import('@dsh-plugin/dsh-loader');
assert.equal(root.name, '@dsh-plugin/dsh-loader');
for (const name of ${JSON.stringify(names)}) {
  const esm = await import('@dsh-plugin/dsh-loader/' + name);
  const cjs = require('@dsh-plugin/dsh-loader/' + name);
  for (const name of Object.keys(esm)) assert.equal(esm[name], cjs[name]);
}
const { defineTool } = await import('@dsh-plugin/dsh-loader/tools');
const sample = { name: 'test' }; assert.equal(defineTool(sample), sample);
const { defineConfig } = require('@dsh-plugin/dsh-loader/config'); assert.equal(typeof defineConfig, 'function');
assert.equal(typeof require('@dsh-plugin/dsh-loader/patch').patchSlot, 'function');
assert.equal(Module._resolveFilename, original, 'ESM/CJS exports must work without installing resolver hooks');
`);
console.log(run(process.execPath, ['runtime.mjs'], { env: { ...process.env, DSHLOADER_DSH_VERSION: '0.1.5-rc.3' } }));
let rejected = false;
try { run(process.execPath, ['runtime.mjs'], { env: { ...process.env, DSHLOADER_DSH_VERSION: '0.9.0' } }); }
catch (error) { rejected = /no adapter covers/.test(String(error.stderr)); }
assert(rejected, 'Unknown patch must reject stable imports');
const browser = readFileSync(join(packageDir, 'lib/client.js'), 'utf8');
const bundlerRequire = createRequire(require.resolve('tsdown'));
const { parseAst } = await import(pathToFileURL(bundlerRequire.resolve('rolldown/parseAst')).href);
const browserImports = [];
const visit = node => {
  if (!node || typeof node !== 'object') return;
  const specifier = ['ImportDeclaration', 'ImportExpression', 'ExportNamedDeclaration', 'ExportAllDeclaration'].includes(node.type) ? node.source
    : node.type === 'CallExpression' && node.callee.type === 'Identifier' && node.callee.name === 'require' ? node.arguments[0] : undefined;
  if (typeof specifier?.value === 'string') browserImports.push(specifier.value);
  for (const value of Object.values(node)) if (Array.isArray(value)) value.forEach(visit); else if (value && typeof value === 'object') visit(value);
};
visit(parseAst(browser));
assert(!browserImports.some(name => name.startsWith('node:')), 'Browser bundle imports Node modules');
console.log(`Packed ESM/CJS imports, unsupported-version rejection and browser separation passed (${packed.files.length} files).\nArchive: ${join(temp, packed.filename)}`);
