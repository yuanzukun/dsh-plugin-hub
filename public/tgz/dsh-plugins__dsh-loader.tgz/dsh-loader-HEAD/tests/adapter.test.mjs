// L1 unit tests �?Web stable API + service alias (design.md §4.3, §4.4, §5.2, §5.4).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createWebAPI, DshLoaderWebError } from '../dist/services/web.js';
import { createServicesAPI } from '../dist/services/services.js';
import { makeMockCtx, makeMockWebServer } from './helpers/mock.mjs';
import { create as createDsh1xAdapter, installHostPackageAliases } from '../dist/adapters/dsh-1-x.js';

// TC-WEB-01: register prefix route �?webServer.register called with kind prefix.
test('TC-WEB-01 web.register registers prefix route', () => {
  const { webServer, registrations } = makeMockWebServer();
  const { ctx, registerService } = makeMockCtx();
  registerService('webServer', webServer);
  const web = createWebAPI({ ctx });
  const dispose = web.register('/api/demo', () => {});
  assert.equal(typeof dispose, 'function');
  assert.equal(registrations.length, 1);
  assert.equal(registrations[0].kind, 'prefix');
  assert.equal(registrations[0].path, '/api/demo');
});

// TC-WEB-02: use middleware �?webServer.register called with kind middleware.
test('TC-WEB-02 web.use registers middleware kind', () => {
  const { webServer, registrations } = makeMockWebServer();
  const { ctx, registerService } = makeMockCtx();
  registerService('webServer', webServer);
  const web = createWebAPI({ ctx });
  const mw = () => {};
  web.use(mw);
  assert.equal(registrations[0].kind, 'middleware');
  assert.equal(registrations[0].handler, mw);
});

// TC-BND-SVC-01: webServer missing �?error with dshloader prefix.
test('TC-BND-SVC-01 web.register without webServer throws dshloader error', () => {
  const { ctx } = makeMockCtx();
  const web = createWebAPI({ ctx });
  assert.throws(
    () => web.register('/api/x', () => {}),
    (err) => err instanceof DshLoaderWebError && /webServer service unavailable/.test(err.message) && /\[dshloader/.test(err.message),
  );
});

// TC-ALIAS-01: httpServer -> webServer alias; both access paths return same instance.
test('TC-ALIAS-01 adapter aliases httpServer to webServer (both access paths)', async () => {
  const { webServer, registrations } = makeMockWebServer();
  const { ctx, services, registerService } = makeMockCtx();
  registerService('webServer', webServer);
  // expose a direct property getter for httpServer too, mirroring §3.3.2.
  Object.defineProperty(ctx, 'httpServer', { get: () => services.get('httpServer'), enumerable: true, configurable: true });

  const adapter = createDsh1xAdapter(ctx, { exposeAllNamespaces: false });
  await adapter.apply();

  assert.equal(ctx.get('httpServer'), ctx.get('webServer'));
  assert.equal(ctx.httpServer, ctx.webServer); // direct property path synced
  assert.equal(ctx.httpServer, webServer);
});

// TC-ALIAS-02: existing real httpServer is not overwritten; logs skip.
test('TC-ALIAS-02 existing httpServer is not overwritten', async () => {
  const { webServer } = makeMockWebServer();
  const realHttp = { register: () => () => {} };
  const { ctx, services, registerService } = makeMockCtx();
  registerService('webServer', webServer);
  registerService('httpServer', realHttp);
  Object.defineProperty(ctx, 'httpServer', { get: () => services.get('httpServer'), enumerable: true, configurable: true });

  const logs = [];
  const orig = console.log;
  console.log = (m) => logs.push(m);
  try {
    const adapter = createDsh1xAdapter(ctx, { exposeAllNamespaces: false });
    await adapter.apply();
  } finally {
    console.log = orig;
  }
  assert.equal(ctx.get('httpServer'), realHttp);
  assert.ok(logs.some((l) => /httpServer already exists, skip alias/.test(l)));
});

// TC-BND-SEC-02: alias does not cover official service (same as TC-ALIAS-02 path).
test('TC-BND-SEC-02 alias skipped when official httpServer present', async () => {
  const { webServer } = makeMockWebServer();
  const realHttp = { register: () => () => {} };
  const { ctx, registerService } = makeMockCtx();
  registerService('webServer', webServer);
  registerService('httpServer', realHttp);
  const adapter = createDsh1xAdapter(ctx, { exposeAllNamespaces: false });
  await adapter.apply();
  assert.equal(ctx.get('httpServer'), realHttp);
});

// services.alias low-level helper.
test('services.alias provides one-hop alias and skips when source exists', () => {
  const { ctx, registerService } = makeMockCtx();
  const target = { x: 1 };
  registerService('webServer', target);
  const services = createServicesAPI({ ctx });
  services.alias('httpServer', 'webServer');
  assert.equal(ctx.get('httpServer'), target);
  // second call: source now exists �?skip, no overwrite
  services.alias('httpServer', 'webServer');
  assert.equal(ctx.get('httpServer'), target);
});

// TC-WEB-03: registerUpgrade proxies to webServer.registerUpgrade.
test('TC-WEB-03 web.registerUpgrade proxies to webServer.registerUpgrade', () => {
  const upgrades = [];
  const webServer = {
    register: () => () => {},
    registerUpgrade(route) {
      upgrades.push(route);
      return () => { const i = upgrades.indexOf(route); if (i >= 0) upgrades.splice(i, 1); };
    },
  };
  const { ctx, registerService } = makeMockCtx();
  registerService('webServer', webServer);
  const web = createWebAPI({ ctx });
  const handler = (req, socket, head) => {};
  const dispose = web.registerUpgrade({ path: '/ws/test', handler });
  assert.equal(typeof dispose, 'function');
  assert.equal(upgrades.length, 1);
  assert.equal(upgrades[0].path, '/ws/test');
  assert.equal(upgrades[0].handler, handler);
  dispose();
  assert.equal(upgrades.length, 0);
});

// TC-WEB-04: registerUpgrade throws when webServer lacks registerUpgrade.
test('TC-WEB-04 web.registerUpgrade throws when webServer lacks method', () => {
  const { webServer } = makeMockWebServer(); // no registerUpgrade
  const { ctx, registerService } = makeMockCtx();
  registerService('webServer', webServer);
  const web = createWebAPI({ ctx });
  assert.throws(
    () => web.registerUpgrade({ path: '/ws/x', handler: () => {} }),
    (err) => err instanceof DshLoaderWebError && /registerUpgrade/.test(err.message),
  );
});

// TC-HOST-PKG-01: installHostPackageAliases intercepts CJS require.
test('TC-HOST-PKG-01 installHostPackageAliases maps CJS require', async () => {
  const Module = await import('node:module').then((m) => m.default ?? m.Module ?? m);
  const original = Module._resolveFilename;
  const resolved = [];
  // Monkey-patch _resolveFilename to record calls without actually resolving.
  Module._resolveFilename = function(request, ...rest) {
    resolved.push(request);
    return `/fake/${request}`;
  };
  try {
    const dispose = await installHostPackageAliases({
      '@old/host-pkg': '@new/host-pkg',
    });
    // Simulate a require('@old/host-pkg') �?the hook should map it.
    Module._resolveFilename('@old/host-pkg');
    Module._resolveFilename('node:fs');
    assert.deepEqual(resolved, ['@new/host-pkg', 'node:fs']);
    dispose();
    // After dispose, mapping is gone.
    resolved.length = 0;
    Module._resolveFilename('@old/host-pkg');
    assert.deepEqual(resolved, ['@old/host-pkg']);
  } finally {
    Module._resolveFilename = original;
  }
});

// TC-HOST-PKG-02: empty aliases is a no-op.
test('TC-HOST-PKG-02 empty host package aliases is no-op', async () => {
  const dispose = await installHostPackageAliases({});
  assert.equal(typeof dispose, 'function');
  dispose(); // should not throw
});

// TC-HOST-PKG-03: stable @dsh-plugin/dsh-loader/* subpaths map to real
// dsh package names via the adapter's default hostPackageAliases.
test('TC-HOST-PKG-03 stable @dsh-plugin/dsh-loader/* maps to real dsh packages', async () => {
  const Module = await import('node:module').then((m) => m.default ?? m.Module ?? m);
  const original = Module._resolveFilename;
  const resolved = [];
  Module._resolveFilename = function(request, ...rest) {
    resolved.push(request);
    return `/fake/${request}`;
  };
  try {
    const { hostPackageAliases } = await import('../dist/adapters/dsh-1-x.js');
    const dispose = await installHostPackageAliases(hostPackageAliases);
    Module._resolveFilename('@dsh-plugin/dsh-loader/tools');
    Module._resolveFilename('@dsh-plugin/dsh-loader/llm');
    Module._resolveFilename('@dsh-plugin/dsh-loader/agent');
    assert.deepEqual(resolved, [
      '@deepseek-ai/dsh-tools',
      '@deepseek-ai/dsh-llm',
      '@deepseek-ai/dsh-agent',
    ]);
    dispose();
  } finally {
    Module._resolveFilename = original;
  }
});

// ---- Session.events accessor polyfill (dsh >= 0.1.2-alpha.2) ----

/** Session double shaped like dsh-session 0.1.2: snapshotEvents method, no events accessor. */
function makeSession012(log) {
  class Session012 {
    constructor(events) { this.log = events; }
    snapshotEvents() { return Object.freeze([...this.log]); }
  }
  return new Session012(log);
}

function disposeAll(effects) {
  for (const entry of effects) entry.dispose?.();
}

// TC-SESS-EV-01: missing accessor is polyfilled via snapshotEvents on the
// prototype; already-live sessions (store.list) are covered immediately.
test('TC-SESS-EV-01 events accessor polyfilled for snapshotEvents-only sessions', async () => {
  const session = makeSession012([{ seq: 0, type: 'turn/start' }]);
  const { ctx, effects, registerService } = makeMockCtx();
  registerService('sessions', { list: () => [session] });

  const adapter = createDsh1xAdapter(ctx, { exposeAllNamespaces: false });
  await adapter.apply();
  try {
    assert.equal(session.events.length, 1);
    assert.equal(session.events[0].type, 'turn/start');
    assert.ok(Object.isFrozen(session.events));
    // Prototype-level, non-enumerable — matches the old class accessor shape.
    const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(session), 'events');
    assert.equal(typeof descriptor.get, 'function');
    assert.equal(descriptor.enumerable, false);
  } finally {
    disposeAll(effects);
  }
});

// TC-SESS-EV-02: a session created later is covered through session/created
// (dispatched before agent/created in the real creation flow).
test('TC-SESS-EV-02 session/created hook polyfills later sessions', async () => {
  const { ctx, effects, listeners, registerService } = makeMockCtx();
  registerService('sessions', { list: () => [] });

  const adapter = createDsh1xAdapter(ctx, { exposeAllNamespaces: false });
  await adapter.apply();
  try {
    const hook = listeners.filter((l) => l.name === 'session/created');
    assert.equal(hook.length, 1);
    assert.deepEqual(hook[0].options, { global: true });
    const session = makeSession012([]);
    hook[0].listener(session);
    assert.deepEqual([...session.events], []);
  } finally {
    disposeAll(effects);
  }
});

// TC-SESS-EV-03: prototype already exposing events is left untouched.
test('TC-SESS-EV-03 existing events accessor is not overridden', async () => {
  class SessionLegacy {
    get events() { return 'legacy'; }
  }
  const session = new SessionLegacy();
  const { ctx, effects, registerService } = makeMockCtx();
  registerService('sessions', { list: () => [session] });

  const adapter = createDsh1xAdapter(ctx, { exposeAllNamespaces: false });
  await adapter.apply();
  try {
    assert.equal(session.events, 'legacy');
  } finally {
    disposeAll(effects);
  }
  assert.equal(session.events, 'legacy'); // dispose must not delete a pre-existing accessor
});

// TC-SESS-EV-04: no snapshotEvents -> no polyfill (fail loud, never silent empty).
test('TC-SESS-EV-04 without snapshotEvents the accessor is not installed', async () => {
  const session = { id: 'bare' };
  const { ctx, effects, registerService } = makeMockCtx();
  registerService('sessions', { list: () => [session] });

  const adapter = createDsh1xAdapter(ctx, { exposeAllNamespaces: false });
  await adapter.apply();
  try {
    assert.equal(session.events, undefined);
    assert.equal('events' in session, false);
  } finally {
    disposeAll(effects);
  }
});

// TC-SESS-EV-05: dispose removes only our accessor (identity-checked).
test('TC-SESS-EV-05 dispose removes the installed accessor', async () => {
  const session = makeSession012([]);
  const { ctx, effects, registerService } = makeMockCtx();
  registerService('sessions', { list: () => [session] });

  const adapter = createDsh1xAdapter(ctx, { exposeAllNamespaces: false });
  await adapter.apply();
  assert.ok(Array.isArray(session.events));
  disposeAll(effects);
  assert.equal('events' in session, false);
});
