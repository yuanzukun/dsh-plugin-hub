/**
 * 小窗面板的**真浏览器**冒烟测试（无头 Chrome）。
 *
 * 为什么需要它：`test-client.mjs` 用的是手搓 DOM 桩，桩上"什么都对"但真实浏览器里
 * 连着踩过三次（都是它测不出来的那类问题）：
 *   ① `mouseup` 对面板内的目标直接 return —— 小窗里划词毫无反应（桩里 target 用的是 document.body）；
 *   ② 引用浮标的 z-index 比面板低 —— 浮标画在面板**底下**，看不见也点不着（桩里不跑层叠）；
 *   ③ 翻译 / 详解两节里划词取不到（桩里没覆盖"节"这条路径）。
 * 所以这里用真 DOM、真选区、真 MouseEvent、真层叠（`elementFromPoint`）跑一遍主要交互。
 *
 * 用法：node tests/browser/panel.test.mjs [lib/client.js 路径]
 *       CHROME=/path/to/chrome node tests/browser/panel.test.mjs
 * 退出码：全部 PASS = 0；找不到 Chrome 打印 SKIP 后退出 0（与 smoke-bridge 一致）。
 */
import { createServer } from 'node:http'
import { readFileSync, existsSync, mkdirSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFile } from 'node:child_process'

const HERE = dirname(fileURLToPath(import.meta.url))
const ROOT = resolve(HERE, '..', '..')
const BUNDLE = process.argv[2] || resolve(ROOT, 'lib', 'client.js')

function findChrome() {
  const candidates = [
    process.env.CHROME,
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/usr/bin/google-chrome',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
  ].filter(Boolean)
  for (const item of candidates) if (existsSync(item)) return item
  return ''
}

const chrome = findChrome()
if (!chrome) {
  if (process.env.REQUIRE_BROWSER === '1') throw new Error('Chrome/Chromium is required for the browser suite')
  console.log('SKIP  没找到 Chrome/Chromium（设 CHROME=/path/to/chrome 可指定）')
  process.exit(0)
}

const PAGE = `<!doctype html>
<html lang="zh-CN" data-platform="darwin"><head><meta charset="utf-8"><title>panel smoke</title>
<style>html,body{margin:0;padding:0;background:#fff}
/* DSH 桌面的原生拖拽规则：全屏 body 浮层不能成为 no-drag 矩形。 */
html[data-platform=darwin] [data-window-drag]{-webkit-app-region:drag}
html[data-platform=darwin] body>:not(#root){-webkit-app-region:no-drag}
html[data-platform=darwin] :is(button,input,textarea,[role=button],[role=dialog]){-webkit-app-region:no-drag}
/* 给主界面留一块"正文"，用来验主界面划词那条路 */
#doc{padding:40px;font:14px/1.7 -apple-system,"PingFang SC",sans-serif}
</style></head>
<body>
<div id="root"><div id="desktop-drag-probe" data-window-drag style="position:fixed;left:300px;top:0;width:400px;height:24px"></div></div>
<div id="doc"><p id="docp">Dev: the migration ran long, so we ship Wednesday.</p></div>
<!-- "别处正在打字"的输入框：必须 fixed 定位 —— 放进文档流会挪动上面那段文字的坐标，
     而这一页里有一族"依赖坐标的划词用例"（见下面 ① 的注释），挪一下就会撞红。 -->
<textarea id="other" style="position:fixed;right:8px;bottom:8px;width:150px;height:34px">别处正在打字</textarea>
<div id="mount"></div>
<pre id="out">PENDING</pre>
<script>
// ── 自检结果收集 ──
var RESULTS = []
function check(name, ok, extra) { RESULTS.push({ name: name, ok: !!ok, extra: extra === undefined ? '' : String(extra).slice(0, 300) }) }
function finish() { document.getElementById('out').textContent = JSON.stringify(RESULTS) }
var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
function waitFor(fn, ms) {
  var deadline = Date.now() + (ms || 3000)
  return new Promise(function (done) {
    ;(function tick() {
      var value
      try { value = fn() } catch (error) { value = false }
      if (value || Date.now() > deadline) return done(value)
      setTimeout(tick, 25)
    })()
  })
}

// ── 插件 bundle 需要的环境：ModuleLoader / React 垫片 / ctx ──
var captured = null
window.__ModuleLoader__ = { load: function (spec) { captured = spec } }
var React = {
  createElement: function (type, props) {
    var children = Array.prototype.slice.call(arguments, 2)
    var out = { type: type, props: Object.assign({}, props || {}) }
    if (children.length === 1) out.props.children = children[0]
    else if (children.length > 1) out.props.children = children
    return out
  },
}

var fixture = {
  translation: '## 翻译\\n第一段译文：the migration ran long——迁移跑得比预期久，可以被划词引用。\\n\\n> 在本句中：进度延迟。\\n',
  detail: '## 详解\\n详解第二段：这句话在排期上意味着顺延，也可以被划词引用。\\n',
  chat: '这是对追问的回答：冒烟用例。',
}
function sse(events) {
  var body = events.map(function (e) { return 'data: ' + JSON.stringify(e) + '\\n\\n' }).join('')
  return new Response(body, { headers: { 'content-type': 'text/event-stream' } })
}
// 麦克风占用：默认"没人在录"。⑫ 交接用例要它报"豆包在录"才能把语音卡唤出来。
var micState = { ok: true, available: true, capturing: false, processes: [], reason: '' }
var pillPosStore = null // 内存版 host 存储（/api/pill）
var panelSizeStore = null // 内存版 host 存储（/api/panel，只存尺寸）
var realFetch = window.fetch.bind(window) // 兜底：不认识的 URL 走真 fetch（截图模式要取 /thumb.png）
window.fetch = function (input, init) {
  var url = String(input)
  var body = {}
  try { body = init && init.body ? JSON.parse(String(init.body)) : {} } catch (error) { body = {} }
  if (url.indexOf('/selection-explain/api/mic') >= 0) {
    window.__micHits = (window.__micHits || 0) + 1
    return Promise.resolve(new Response(JSON.stringify(micState), { headers: { 'content-type': 'application/json' } }))
  }
  if (url.indexOf('/selection-explain/api/ping') >= 0) {
    return Promise.resolve(new Response(JSON.stringify({ ok: true, route: { provider: 'fixture', model: 'fixture' }, reasoningEffortByStage: { translation: 'low', detail: 'high', chat: 'high' }, limits: {} }), { headers: { 'content-type': 'application/json' } }))
  }
  if (url.indexOf('/selection-explain/api/quote-context') >= 0) {
    return Promise.resolve(new Response(JSON.stringify({ ok: true, matched: true, context: '用户：上一问\\n助手：上一答\\n用户：【' + (body.text || '') + '】\\n助手：下一答', rounds: 2 }), { headers: { 'content-type': 'application/json' } }))
  }
  if (url.indexOf('/selection-explain/api/history') >= 0) {
    var entry = fixture.history && url.indexOf('key=' + encodeURIComponent(fixture.history.key)) >= 0 ? fixture.history : null
    return Promise.resolve(new Response(JSON.stringify({ ok: true, entry: entry, entries: [] }), { headers: { 'content-type': 'application/json' } }))
  }
  if (url.indexOf('/selection-explain/api/panel') >= 0) {
    var isGetPanel = !init || !init.method || String(init.method).toUpperCase() === 'GET'
    if (isGetPanel) return Promise.resolve(new Response(JSON.stringify({ ok: true, size: panelSizeStore }), { headers: { 'content-type': 'application/json' } }))
    if (body.clear === true) {
      panelSizeStore = null
      return Promise.resolve(new Response(JSON.stringify({ ok: true, size: null }), { headers: { 'content-type': 'application/json' } }))
    }
    // 只认 w/h：位置不该出现在这个载荷里
    panelSizeStore = body.size ? { w: body.size.w, h: body.size.h, hadXY: ('x' in body.size || 'y' in body.size) } : null
    return Promise.resolve(new Response(JSON.stringify({ ok: true, size: panelSizeStore }), { headers: { 'content-type': 'application/json' } }))
  }
  if (url.indexOf('/selection-explain/api/pill') >= 0) {
    var isGet = !init || !init.method || String(init.method).toUpperCase() === 'GET'
    if (isGet) return Promise.resolve(new Response(JSON.stringify({ ok: true, position: pillPosStore }), { headers: { 'content-type': 'application/json' } }))
    if (body.clear === true) {
      pillPosStore = null
      return Promise.resolve(new Response(JSON.stringify({ ok: true, position: null }), { headers: { 'content-type': 'application/json' } }))
    }
    if (typeof body.right === 'number' && typeof body.y === 'number') {
      pillPosStore = { right: body.right, y: body.y }
      return Promise.resolve(new Response(JSON.stringify({ ok: true, position: pillPosStore }), { headers: { 'content-type': 'application/json' } }))
    }
    return Promise.resolve(new Response(JSON.stringify({ ok: false, error: 'position 需要 { right, y }' }), { status: 400, headers: { 'content-type': 'application/json' } }))
  }
  if (url.indexOf('/selection-explain/api/models') >= 0) {
    // 三个模型：一个长名字、一个同名 id 挂在另一个 provider 下 —— 给"菜单里给当前在用的
    // 那个打勾"那条用例用。current = 会话在用的那个（跟随态菜单要照它打勾）。
    return Promise.resolve(new Response(JSON.stringify({
      ok: true,
      current: { provider: 'p1', model: 'm-fast' },
      stages: { chat: 'high' },
      models: [
        { provider: 'p1', providerName: 'Provider One', model: 'm-fast', name: 'DeepSeek V4.1 Flash', efforts: [{ id: 'off', name: 'Off' }, { id: 'low', name: 'Low' }, { id: 'high', name: 'High' }, { id: 'max', name: 'Max' }], defaultEffort: 'high' },
        { provider: 'p1', providerName: 'Provider One', model: 'm-strong', name: 'Strong Model With A Very Long Display Name', efforts: [{ id: 'off', name: 'Off' }, { id: 'high', name: 'High' }], defaultEffort: 'high' },
        { provider: 'p2', providerName: 'DeepSeek Account', model: 'm-fast', name: 'Another Provider Same Id', efforts: [], defaultEffort: null },
      ],
    }), { headers: { 'content-type': 'application/json' } }))
  }
  if (url.indexOf('/selection-explain/api/attach') >= 0) {
    // 附件上传：宿主把 base64 存进附件服务、回一个持久引用。这里只记请求、回一件：
    // 客户端要验的是"逐件上传 + 引用回传"，不是附件服务自己（那条有 tests/unit/attach.test.mjs）。
    window.__attachHits = window.__attachHits || []
    window.__attachHits.push(body)
    // __attachDelay：把回复拖慢一点，让"上传中"这个中间态可被确定性地观察到
    //（真上传很快，不拖慢的话「发送键在上传期间置灰」这条只能靠运气撞上）。
    if (window.__attachDelay) {
      return new Promise(function (resolve) {
        setTimeout(function () { resolve(reply()) }, window.__attachDelay)
      })
    }
    return reply()
    function reply() {
    var item = (body.items || [])[0] || {}
    // 失败开关：用来验"失败 → 重试"那条路
    if (window.__attachFail && window.__attachFail === item.name) {
      return Promise.resolve(new Response(JSON.stringify({ ok: false, code: 'UNSUPPORTED_IMAGE_TYPE', error: '不是受支持的图片格式（PNG / JPEG / WebP / GIF）', name: item.name }), { status: 400, headers: { 'content-type': 'application/json' } }))
    }
    var ref = item.kind === 'image'
      ? { attachmentId: 'sha256:' + 'a'.repeat(64), mediaType: item.mediaType || 'image/png', width: 800, height: 600, bytes: 12, name: item.name }
      : { attachmentId: 'sha256:' + 'b'.repeat(64), name: item.name, bytes: 12 }
    return Promise.resolve(new Response(JSON.stringify({ ok: true, items: [{ kind: item.kind, ref: ref }] }), { headers: { 'content-type': 'application/json' } }))
    }
  }
  if (url.indexOf('/selection-explain/api/analyze') >= 0) {
    if (body.question) {
      // 追问的载荷留下来给附件用例断言（"引用只带引用、不带 base64"）
      window.__askBodies = window.__askBodies || []
      window.__askBodies.push(body)
      return Promise.resolve(sse([{ type: 'start', provider: 'fixture', model: 'fixture', mode: 'chat' }, { type: 'delta', text: fixture.chat }, { type: 'done', chars: 8 }]))
    }
    var fence = String.fromCharCode(96, 96, 96)
    var code = '## 注释\\n' + fence + 'js\\n// 注释：先声明常量\\nconst x = 1\\n' + fence + '\\n\\n> 小结：一句话说清。\\n'
    var text = body.kind === 'code' ? code : body.stage === 'detail' ? fixture.detail : fixture.translation
    return Promise.resolve(sse([{ type: 'start', provider: 'fixture', model: 'fixture', stage: body.stage || 'translation' }, { type: 'delta', text: text }, { type: 'done', chars: text.length }]))
  }
  // 兜底：不认识的 URL 走**真** fetch。
  // 以前这里一律回一个空 JSON —— 截图模式要拿页面自己的一张真 PNG 当缩略图，
  // 被这条兜底拦住的话拿到的是一段 JSON，缩略图就成了破图。
  return realFetch.apply(window, arguments)
}

var disposers = []
var registration = null
var ctx = {
  logger: { info: function () {}, warn: function () {} },
  get: function () { return undefined },
  effect: function (fn) { var d = fn(); if (typeof d === 'function') disposers.push(d); return d },
  slots: {
    inject: function (key, callback) { var d = callback(); if (typeof d === 'function') disposers.push(d); return d },
    register: function (options, component) { registration = { options: options, component: component }; return function () {} },
  },
}

// ── 真选区 + 真事件 ──
</script>
<script src="/client.js"></script>
<script>
function selectIn(node, needle) {
  var text = node.textContent || ''
  var at = needle ? text.indexOf(needle) : 0
  if (at < 0) return null
  var len = needle ? needle.length : Math.min(6, text.length)
  var walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, null)
  var acc = 0, startNode = null, startOffset = 0, endNode = null, endOffset = 0, current
  while ((current = walker.nextNode())) {
    var next = acc + current.nodeValue.length
    if (startNode === null && at < next) { startNode = current; startOffset = at - acc }
    if (startNode !== null && at + len <= next) { endNode = current; endOffset = at + len - acc; break }
    acc = next
  }
  if (!startNode || !endNode) return null
  var range = document.createRange()
  range.setStart(startNode, Math.max(0, startOffset))
  range.setEnd(endNode, Math.max(0, endOffset))
  var sel = window.getSelection()
  sel.removeAllRanges()
  sel.addRange(range)
  return range
}
function mouseUpOn(node) {
  node.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }))
}
function clickOn(node) {
  node.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }))
}
/**
 * 像用户那样点一下：mousedown → mouseup → click。
 * 只派发 click 是"程序化点击"，浏览器不会走聚焦/选区那套默认行为 ——
 * 而浮标靠 mousedown 的 preventDefault 保住选区，正是那条路要验。
 */
function realClick(node) {
  var opts = { bubbles: true, cancelable: true, view: window, detail: 1 }
  node.dispatchEvent(new MouseEvent("mousedown", opts))
  node.dispatchEvent(new MouseEvent("mouseup", opts))
  node.dispatchEvent(new MouseEvent("click", opts))
}
/**
 * 量几何之前先把过渡/动画冻住。
 *
 * 为什么必须冻：这个冒烟脚本跑在 --virtual-time-budget 下，定时器是虚拟时间（秒级飞快），
 * 但 **CSS 过渡的动画时钟不跟着走** —— 胶囊的宽度/位置过渡（.32s）会在"中间某一帧"被量到，
 * 于是"等了 420ms 还是量到起点值"。冻住之后量到的是终值，断言才是确定的；
 * "到底有没有动画"另外用 getComputedStyle 断言（transition-property 里有没有 max-width）。
 */
function freezeMotion() {
  if (document.getElementById('freeze-motion')) return
  var style = document.createElement('style')
  style.id = 'freeze-motion'
  style.textContent = '*{transition:none!important;animation:none!important}'
  document.head.appendChild(style)
}
/** 按**顶层**逗号切分 CSS 列表值：cubic-bezier(0.4, 0, 0.6, 1) 里面也有逗号，直接 split 会切碎。 */
function splitCssList(value) {
  var out = []
  var depth = 0
  var current = ''
  for (var i = 0; i < String(value).length; i += 1) {
    var ch = String(value)[i]
    if (ch === '(') depth += 1
    if (ch === ')') depth -= 1
    if (ch === ',' && depth === 0) { out.push(current.trim()); current = '' } else { current += ch }
  }
  if (current.trim()) out.push(current.trim())
  return out
}
/** 浮标是不是**最上层**（z-index 低于面板时 elementFromPoint 会返回面板）。 */
function onTop(node) {
  var rect = node.getBoundingClientRect()
  if (!rect.width || !rect.height) return false
  var hit = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2)
  return hit === node || node.contains(hit)
}

async function main() {
  var mount = document.getElementById('mount')
  var hook = null
  try {
    var modules = captured.factory(function (name) { return name === 'react' ? React : {} })
    modules.apply(ctx)
    check('插件装载（槽注册 + apply）', !!registration && registration.options.id === '@yfwu2020/dsh-selection-explain', registration && registration.options.id)
    registration.component().props.ref(mount)
    hook = window.__dshSelectionExplain
    check('解读自有浮层已挂载', !!document.querySelector('.dsh-sel-layer'), '')
    var ownedLayer = document.querySelector('.dsh-sel-layer')
    check('解读使用 body 自有根，公开归属且空白穿透', ownedLayer.parentNode === document.body && ownedLayer.getAttribute('data-dsh-floating-owner') === 'explanation' && getComputedStyle(ownedLayer).pointerEvents === 'none', '')
    check('桌面标题栏仍是原生窗口拖拽区域', getComputedStyle(document.getElementById('desktop-drag-probe')).webkitAppRegion === 'drag', '')
    check('全屏浮层不把桌面标题栏排除出原生拖拽区域', getComputedStyle(ownedLayer).webkitAppRegion === 'none', getComputedStyle(ownedLayer).webkitAppRegion)
    check('标题栏的鼠标命中仍穿透插件空白', document.elementFromPoint(500, 10) === document.getElementById('desktop-drag-probe'), '')
    var desktopControls = Array.from(ownedLayer.querySelectorAll('.dsh-sel-btn,.dsh-sel-panel,.dsh-sel-pill,.dsh-sel-history'))
    check('插件交互区域仍禁止原生窗口拖拽', desktopControls.every(function (node) { return getComputedStyle(node).webkitAppRegion === 'no-drag' }), desktopControls.map(function (node) { return node.className + ':' + getComputedStyle(node).webkitAppRegion }).join(', '))
    check('解读独立根越过完整视图工作面板', Number(getComputedStyle(ownedLayer).zIndex) > 60, getComputedStyle(ownedLayer).zIndex)
    var modeFrame = document.createElement('div')
    document.body.appendChild(modeFrame)
    modeFrame.setAttribute('data-dsh-full-view', '')
    await sleep(40)
    check('解读自身响应完整视图并隐藏胶囊', getComputedStyle(document.querySelector('.dsh-sel-pill')).display === 'none', '')
    modeFrame.removeAttribute('data-dsh-full-view')
    await sleep(40)
    check('返回分栏由解读自身恢复胶囊', getComputedStyle(document.querySelector('.dsh-sel-pill')).display !== 'none', '')
    modeFrame.remove()
  } catch (error) {
    check('插件装载（槽注册 + apply）', false, error && error.message)
    finish()
    return
  }

  var panel = document.querySelector('.dsh-sel-panel')
  var quoteBtn = hook.quoteNode()
  var quotesBox = document.querySelector('.dsh-sel-quotes')

  function chipCount() { return hook.quotes().length }
  function dropQuotes() {
    var xs = quotesBox.querySelectorAll('.dsh-sel-quotechip-x')
    for (var i = xs.length - 1; i >= 0; i -= 1) clickOn(xs[i])
  }
  /** 等面板"安顿下来"（开窗自动聚焦那一下会清掉选区，等它过去再划）。 */
  async function settlePanel() {
    var box = document.querySelector(".dsh-sel-askbox")
    await waitFor(function () { return box && document.activeElement === box }, 800)
    await sleep(30)
  }
  /** 划一段 → 点引用 → 返回那一段引用（并清场）。find() 返回 { node, needle }。 */
  async function quoteOnce(label, find) {
    await settlePanel()
    var target = find()
    if (!target || !target.node) { check(label + '：找到目标节点', false, '未找到'); return null }
    var range = selectIn(target.node, target.needle)
    check(label + '：能建出真选区', !!range, range ? range.toString().slice(0, 24) : '未找到目标文字')
    if (!range) return null
    // ⚠️ 合成选区 vs 面板渲染有竞态：面板晚一步重绘会把刚选中的节点换掉，插件据此判定
    // "那段文字没了"并收起浮标（这是对的），用例于是偶发红 —— 真浏览器冒烟在 CI 与本机
    // 都复现过（改动前的基线同样 192/2）。所以这里**重试合成选区**（最多 3 次，每次都重新
    // 取节点、重建 range），而不是放宽断言。
    var shown = false
    for (var attempt = 0; attempt < 3 && !shown; attempt += 1) {
      if (attempt > 0) {
        await settlePanel()
        var fresh = find()
        if (!fresh || !fresh.node) break
        target = fresh
        range = selectIn(target.node, target.needle)
        if (!range) break
      }
      mouseUpOn(target.node)
      shown = await waitFor(function () { return hook.quoteState().visible === true }, 1500)
    }
    check(label + '：浮出「❝ 引用」', shown === true, JSON.stringify(hook.quoteState()))
    if (!shown) return null
    check(label + '：浮标在最上层（不被面板盖住）', onTop(quoteBtn), '')
    clickOn(quoteBtn)
    await sleep(40)
    var quotes = hook.quotes()
    var picked = quotes.length ? quotes[quotes.length - 1] : null
    check(label + '：进了引用区', chipCount() === 1 && !!picked, JSON.stringify(quotes.map(function (q) { return q.label + ':' + q.text.slice(0, 12) })))
    dropQuotes()
    await sleep(30)
    return picked
  }
  function sectionContent(key) {
    return document.querySelector('.dsh-sel-sec[data-sec="' + key + '"] .dsh-sel-c')
  }

  // ── 打开面板（fetch 桩给固定两节内容）──
  hook.open('冒烟探针', '上下文片段 ABC', '冒烟')
  await waitFor(function () { return hook.state().phase === 'done' }, 4000)
  check('首轮渲染完成', hook.state().phase === 'done', hook.state().phase)

  // ── 面板 / 设置抽屉的真实尺寸 ──
  // 为什么要有这一段：单测的 DOM 桩**没有布局**。这里曾经有条按阶段收窄到 440px 的规则，
  // 因为 CSS 声明块漏了收尾花括号被整条丢弃（属性对、规则不生效，单测照样全绿）；
  // 修好闭合后它又暴露了"追问一下宽度就从 440 跳到 540"的问题 —— 两件事都只有真浏览器量得出来。
  // 现在宽度**不随阶段变**（恒 540），下面同时钉住"首轮就是 540"和"追问之后仍是 540"。
  // ── 录音行不许把发送键顶到下一行（用户报：一开麦 ↑ 就掉到下面单独一行）──
  // 真浏览器量布局：按录音态把 DOM 摆成插件摆的样子（亮出录音行、让位那几样工具），
  // 再量发送键是否还与录音行同处一行。CSS 里那两条 flex-basis:0% + nowrap 就是为它服务的。
  {
    var toolsEl = document.querySelector('.dsh-sel-asktools')
    var captureEl = document.querySelector('.dsh-sel-capture')
    var sendEl = document.querySelector('.dsh-sel-asksend')
    var waveEl = document.querySelector('.dsh-sel-vwave')
    if (toolsEl && captureEl && sendEl) {
      var yielding = ['.dsh-sel-pref', '.dsh-sel-askspace', '.dsh-sel-picker', '.dsh-sel-mic']
        .map(function (sel) { return document.querySelector(sel) })
        .filter(Boolean)
      var restore = yielding.map(function (n) { return [n, n.style.display] })
      // 必须**窄一点**量：波形那个 svg 的固有宽度是 384px（viewBox 640x40 按 24px 高推出来的），
      // 540px 的面板刚好放得下、量不出问题；用户那个宽度才会露出来。面板本来就可调窄，这是真实场景。
      var panelWide = document.querySelector('.dsh-sel-panel')
      var widthBefore = panelWide ? panelWide.style.width : ''
      if (panelWide) panelWide.style.width = '420px'
      toolsEl.setAttribute('data-capturing', '1')
      captureEl.setAttribute('data-show', '1')
      captureEl.style.display = 'flex'
      if (waveEl) waveEl.style.display = ''
      yielding.forEach(function (n) { n.style.display = 'none' })
      var captureRect = captureEl.getBoundingClientRect()
      var sendRect = sendEl.getBoundingClientRect()
      check(
        '录音行出现时发送键仍在同一行（不被顶到下面）',
        sendRect.height > 0 && sendRect.top < captureRect.bottom && Math.abs(sendRect.top - captureRect.top) <= 8,
        JSON.stringify({
          capture: [Math.round(captureRect.top), Math.round(captureRect.bottom)],
          send: [Math.round(sendRect.top), Math.round(sendRect.bottom)],
        }),
      )
      restore.forEach(function (pair) { pair[0].style.display = pair[1] })
      if (panelWide) panelWide.style.width = widthBefore
      captureEl.style.display = 'none'
      captureEl.setAttribute('data-show', '0')
      toolsEl.setAttribute('data-capturing', '0')
      if (waveEl) waveEl.style.display = 'none'
    } else {
      check('录音行出现时发送键仍在同一行（不被顶到下面）', false, '没找到工具行/录音行/发送键')
    }
  }

  var WIDE_WIDTH = 540
  {
    var panelEl = document.querySelector('.dsh-sel-panel')
    var beforeRect = panelEl.getBoundingClientRect()
    check('首轮阶段宽度就是常规宽度（不再按阶段收窄到 440）',
      Math.abs(beforeRect.width - WIDE_WIDTH) <= 2,
      'stage=' + panelEl.getAttribute('data-stage') + ' width=' + Math.round(beforeRect.width))

    var settingsBtn = Array.prototype.slice.call(panelEl.querySelectorAll('.dsh-sel-action'))
      .filter(function (b) { return b.textContent.indexOf('设置') >= 0 })[0]
    check('头部有「设置」键', !!settingsBtn, settingsBtn ? settingsBtn.textContent : '未找到')
    if (settingsBtn) {
      clickOn(settingsBtn)
      await waitFor(function () { return panelEl.getAttribute('data-settings') === '1' }, 1200)
      await sleep(60)
      var openRect = panelEl.getBoundingClientRect()
      var sheetEl = panelEl.querySelector('.dsh-sel-sheet')
      var sheetBody = sheetEl && sheetEl.querySelector('.dsh-sel-sheetbody')
      // 抽屉是 inset:0 贴在面板上的：面板多大多小，抽屉就多大多小。
      // 而面板高度是"解读内容有多长"撑出来的 —— 刚开窗时内容很短，
      // 不锁下限的话设置列表只剩十几个像素（实测 17px），等于没法用。
      // 设置窗口是 inset:0 贴在面板上的：**宽度必须与小窗一致**，
      // 开抽屉不该让面板自己"胖一圈"或"瘦一圈"（高度才需要补下限）。
      check('开设置抽屉后：设置窗口宽度与小窗完全一致（不额外加宽）',
        Math.abs(openRect.width - beforeRect.width) <= 0.5,
        '抽屉=' + openRect.width.toFixed(1) + ' 小窗=' + beforeRect.width.toFixed(1))
      check('开设置抽屉后：高度有下限（不再被内容长短绑架）',
        openRect.height >= 500,
        'height=' + Math.round(openRect.height) + '（首轮未开抽屉时 ' + Math.round(beforeRect.height) + '）')
      var bodyH = sheetBody ? sheetBody.clientHeight : 0
      check('设置列表可视高度够用（不是一条缝）',
        bodyH >= 200,
        'sheetBody.clientHeight=' + Math.round(bodyH))
      // 关掉，别影响后面的用例
      var backBtn = sheetEl && sheetEl.querySelector('.dsh-sel-sheetback')
      if (backBtn) clickOn(backBtn)
      await waitFor(function () { return panelEl.getAttribute('data-settings') !== '1' }, 1200)
      await sleep(40)
      var restored = panelEl.getBoundingClientRect()
      check('关掉抽屉后：小窗宽度不变（开合抽屉不动宽度）',
        Math.abs(restored.width - beforeRect.width) <= 0.5 && Math.abs(restored.width - WIDE_WIDTH) <= 2,
        'width=' + Math.round(restored.width))
    }
  }

  // ── 拖动 / 改大小 ──
  // 规则：**尺寸**记住（用户拖角调过的），**位置不记**（每次开窗都按选区重新锚定）。
  function pointerOn(node, type, x, y) {
    node.dispatchEvent(new PointerEvent(type, { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, pointerId: 1, button: 0, buttons: 1 }))
  }
  {
    var panelEl2 = document.querySelector('.dsh-sel-panel')
    var before = hook.panelGeom()

    // ① 拖右下角 → 变宽变高，并且只有尺寸被存下来
    var corner = panelEl2.querySelector('.dsh-sel-grip-corner')
    check('有右下角改大小手柄', !!corner, corner ? corner.className : '未找到')
    if (corner) {
      pointerOn(corner, 'pointerdown', 0, 0)
      pointerOn(window, 'pointermove', 140, 90)
      pointerOn(window, 'pointerup', 140, 90)
      await sleep(60)
      var grown = hook.panelGeom()
      check('拖角能让小窗变大',
        Math.round(grown.w) > Math.round(before.w) + 100 && Math.round(grown.h) > Math.round(before.h) + 60,
        'w ' + Math.round(before.w) + '→' + Math.round(grown.w) + '  h ' + Math.round(before.h) + '→' + Math.round(grown.h))
      check('改过大小会打标记（设置页就不再插手高度）', grown.resized === true, String(grown.resized))
      await sleep(420) // 防抖 300ms
      check('尺寸存到了 host（下次开窗回到这个大小）',
        !!panelSizeStore && Math.abs(panelSizeStore.w - grown.w) <= 1 && Math.abs(panelSizeStore.h - grown.h) <= 1,
        JSON.stringify(panelSizeStore))
      check('存档里**没有位置**（载荷只有 w/h）', !!panelSizeStore && panelSizeStore.hadXY === false,
        JSON.stringify(panelSizeStore))
    }

    // ② 拖标题栏：这次能挪动，但**不该存位置**
    var headEl = panelEl2.querySelector('.dsh-sel-head')
    var posBefore = hook.panelGeom()
    pointerOn(headEl, 'mousedown', posBefore.x + 60, posBefore.y + 12)
    window.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: posBefore.x + 60 + 70, clientY: posBefore.y + 12 + 44 }))
    window.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }))
    await sleep(60)
    var moved = hook.panelGeom()
    check('拖标题栏能挪动小窗（本次有效）',
      Math.abs(moved.x - posBefore.x) > 40 && Math.abs(moved.y - posBefore.y) > 20,
      'x ' + Math.round(posBefore.x) + '→' + Math.round(moved.x) + '  y ' + Math.round(posBefore.y) + '→' + Math.round(moved.y))
    await sleep(420)
    check('拖动**不会**把位置存进 host（位置记忆已按要求去掉）',
      !!panelSizeStore && panelSizeStore.hadXY === false,
      JSON.stringify(panelSizeStore))

    // ③ 尺寸能读回来（模拟刷新：清掉内联尺寸，再让客户端重读一次）
    panelEl2.style.width = ''
    panelEl2.style.height = ''
    panelEl2.removeAttribute('data-resized')
    hook.loadPanelSize()
    await sleep(80)
    var restored2 = hook.panelGeom()
    // 宽度按存档精确恢复；高度只作为天花板 —— 内容撑不到就自己短着（见 ⑥）
    check('宽度能按存档恢复',
      Math.abs(restored2.w - panelSizeStore.w) <= 1,
      'w=' + Math.round(restored2.w) + ' / 存档 ' + Math.round(panelSizeStore.w))
    check('高度不超过存档的上限',
      restored2.h <= panelSizeStore.h + 1,
      'h=' + Math.round(restored2.h) + ' / 上限 ' + Math.round(panelSizeStore.h))

    // ④ 重新开窗 → 必须重新按选区锚定（这是"位置不记"的核心保证）
    //    先把窗口挪到一个明显偏离锚点的位置，再关掉重开。
    panelEl2.style.left = '7px'
    panelEl2.style.top = '7px'
    hook.close()
    await sleep(40)
    hook.open('重新锚定探测', '上下文片段 ABC', '冒烟')
    await sleep(60)
    var reopened = hook.panelGeom()
    check('重新开窗会重新按选区锚定（位置没被记住）',
      reopened.x > 20 && reopened.y > 20,
      'x=' + Math.round(reopened.x) + ' y=' + Math.round(reopened.y) + '（若被记住应是 7,7）')

    // ⑤ 双击角标 → 恢复默认尺寸
    if (corner) {
      corner.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window }))
      await sleep(80)
      var afterReset = hook.panelGeom()
      check('双击角标恢复默认尺寸（清掉存档）',
        afterReset.resized === false && panelSizeStore === null,
        'resized=' + afterReset.resized + ' store=' + JSON.stringify(panelSizeStore))
      await sleep(420)
    }

    // ⑥ 记住的高度只能当**天花板**：新会话内容短时面板必须缩回去，不能留一大片空白。
    //    这条是用户报的回归 —— 高度被当成固定值写上去，新开一个会话（只有一小段翻译）
    //    面板硬撑到上次那么高，下面全是空的。
    panelSizeStore = { w: 620, h: 700, hadXY: false }
    panelEl2.style.width = ''
    panelEl2.style.height = ''
    panelEl2.style.maxHeight = ''
    panelEl2.removeAttribute('data-resized')
    hook.loadPanelSize()
    await sleep(80)
    hook.close()
    await sleep(40)
    hook.open('自适应高度探测', '上下文片段 ABC', '冒烟')
    await sleep(100)
    var fresh = hook.panelGeom()
    var blank = panelEl2.clientHeight - panelEl2.scrollHeight
    check('新会话高度自适应：面板里没有大片空白',
      blank <= 4,
      'clientHeight=' + panelEl2.clientHeight + ' scrollHeight=' + panelEl2.scrollHeight + ' 空白=' + blank)
    check('存档的高度只当天花板（没被当成固定高度）',
      fresh.h < 680,
      'h=' + Math.round(fresh.h) + '（存档上限 700，若被当固定值用就该是 700）')
    check('宽度仍沿用存档的值（宽度固定、高度自适应）',
      Math.abs(fresh.w - 620) <= 1,
      'w=' + Math.round(fresh.w))

    // ⑦ 双击 = 自适应 = 恢复默认尺寸（同一个动作）：把窗口**拉小**之后再双击，
    //    高度不该还被旧的上限卡着 —— 那是"只清了 width/height、漏了 maxHeight"的症状。
    panelSizeStore = { w: 340, h: 250, hadXY: false }
    panelEl2.style.width = ''
    panelEl2.style.height = ''
    panelEl2.style.maxHeight = ''
    panelEl2.removeAttribute('data-resized')
    hook.loadPanelSize()
    await sleep(80)
    hook.close()
    await sleep(40)
    hook.open('拉小后双击探测', '上下文片段 ABC', '冒烟')
    await sleep(120)
    var shrunk = hook.panelGeom()
    check('存档的小尺寸生效（宽度 340、高度被 250 卡住）',
      Math.abs(shrunk.w - 340) <= 1,
      'w=' + Math.round(shrunk.w) + ' h=' + Math.round(shrunk.h))
    corner.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window }))
    await sleep(120)
    var back = hook.panelGeom()
    check('双击后宽度回到默认（不再被存档的 340 卡住）',
      Math.abs(back.w - 340) > 40,
      'w ' + Math.round(shrunk.w) + '→' + Math.round(back.w))
    check('双击后高度上限也被清掉（不再被 250 卡住）',
      panelEl2.style.maxHeight === '' && back.h > 260,
      'maxHeight=' + JSON.stringify(panelEl2.style.maxHeight) + ' h=' + Math.round(back.h))
    await sleep(420)

    // ⑦.5 刚拖完角标就双击还原：防抖里那次没落盘的保存**不能**把还原撤销掉。
    //      savePanelSize 在定时器触发时才读当前尺寸 —— 不掐掉的话它 300ms 后会读到
    //      "已还原的默认尺寸"，反过来当成用户选的尺寸存下来，宽度被钉死。
    pointerOn(corner, 'pointerdown', 0, 0)
    pointerOn(window, 'pointermove', 90, 60)
    pointerOn(window, 'pointerup', 90, 60)
    await sleep(40) // 远小于 300ms 防抖：保存还没落盘
    corner.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window }))
    await sleep(500) // 跨过防抖窗口，看那次保存会不会"复活"
    check('刚拖完就双击还原：待落的保存不会把还原撤销掉',
      panelSizeStore === null && panelEl2.style.width === '' && panelEl2.getAttribute('data-resized') === null,
      'store=' + JSON.stringify(panelSizeStore) + ' inline=' + JSON.stringify(panelEl2.style.width) +
        ' resized=' + panelEl2.getAttribute('data-resized'))

    // ⑧ 恢复默认尺寸**不等于没有上限**：上限从"用户调过的"换回"CSS 默认的" min(78vh,720px)。
    //    清掉的是用户那条自定义上限，不是限制本身。
    {
      var cap = Math.min(window.innerHeight * 0.78, 720)
      var computedMax = getComputedStyle(panelEl2).maxHeight
      check('恢复默认后高度仍有上限（回到 CSS 默认 min(78vh,720px)）',
        panelEl2.style.maxHeight === '' && computedMax !== 'none' &&
          Math.abs(parseFloat(computedMax) - cap) <= 2,
        'inline=' + JSON.stringify(panelEl2.style.maxHeight) + ' computed=' + computedMax +
          ' 期望=' + Math.round(cap) + 'px')
      // 塞一段超长内容：面板不该被撑破上限，多出来的部分在正文里滚动
      // 塞一段超长内容量一次 —— 量完必须**收拾干净**：这一段动的是真面板，
      // 面板高度会 423 → 634 → 423，滚动位置也会变；不还原就会影响后面那些
      // 依赖坐标的划词用例（跑多次能撞见）。
      var bodyEl = panelEl2.querySelector('.dsh-sel-body')
      var savedScroll = bodyEl.scrollTop
      var filler = document.createElement('div')
      filler.style.cssText = 'height:3000px;flex:0 0 auto'
      bodyEl.appendChild(filler)
      await sleep(80)
      var tall = panelEl2.getBoundingClientRect().height
      check('内容超长时面板不越过上限（超出部分内部滚动）',
        tall <= cap + 2,
        'h=' + Math.round(tall) + ' 上限=' + Math.round(cap) + ' body 可滚=' + (bodyEl.scrollHeight > bodyEl.clientHeight))
      filler.remove()
      bodyEl.scrollTop = savedScroll
      void panelEl2.offsetHeight // 强制回流，别让后面的用例量到中间态
      await sleep(140)
    }

    // ⑨ 手柄不该有常驻的视觉标识（用户要求去掉右下角那道小斜纹）
    var cornerAfter = getComputedStyle(corner, '::after')
    check('右下角手柄没有常驻标识（不再画小斜纹）',
      !cornerAfter.content || cornerAfter.content === 'none' || cornerAfter.content === 'normal',
      'content=' + cornerAfter.content)
    check('手柄仍在（只是不可见，鼠标移上去光标会变）',
      getComputedStyle(corner).cursor === 'nwse-resize',
      'cursor=' + getComputedStyle(corner).cursor)

    // ⑩ 贴着屏幕边缘时双击恢复默认尺寸 → 面板不能被顶出屏幕
    //    复现：先拉宽到接近满屏并推到右边，再双击角标（宽度会跳回默认 540，位置是旧的）
    var vw = window.innerWidth
    var vh = window.innerHeight
    pointerOn(corner, 'pointerdown', 0, 0)
    pointerOn(window, 'pointermove', vw, vh) // 尽量拉大
    pointerOn(window, 'pointerup', vw, vh)
    await sleep(80)
    // 推到右下角
    var big = hook.panelGeom()
    var headEl2 = panelEl2.querySelector('.dsh-sel-head')
    pointerOn(headEl2, 'mousedown', big.x + 60, big.y + 12)
    window.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: vw + 500, clientY: vh + 500 }))
    window.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }))
    await sleep(80)
    var beforeReset = hook.panelGeom()
    corner.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window }))
    await sleep(120)
    var afterDbl = hook.panelGeom()
    check('贴边双击恢复默认尺寸后，面板仍在屏幕内',
      afterDbl.x >= 0 && afterDbl.y >= 0 &&
        afterDbl.x + afterDbl.w <= vw + 1 && afterDbl.y + afterDbl.h <= vh + 1,
      'x=' + Math.round(afterDbl.x) + ' y=' + Math.round(afterDbl.y) +
        ' 右=' + Math.round(afterDbl.x + afterDbl.w) + '/' + vw +
        ' 下=' + Math.round(afterDbl.y + afterDbl.h) + '/' + vh +
        '（双击前 x=' + Math.round(beforeReset.x) + ' w=' + Math.round(beforeReset.w) + '）')
  }

  // ① 翻译节
  var picked1 = await quoteOnce('翻译节划词', function () {
    return { node: sectionContent('translation'), needle: '迁移跑得比预期久' }
  })
  var transTitle = document.querySelector('.dsh-sel-sec[data-sec="translation"] .dsh-sel-sh span')
  var transTitleText = transTitle ? transTitle.textContent : ''
  check(
    '翻译节的来源写明是哪一节（用该节自己的标题）',
    !!picked1 && !!transTitleText && picked1.label === '小窗「' + transTitleText + '」节',
    picked1 && picked1.label + ' vs ' + transTitleText,
  )

  // ② 结论条（.dsh-sel-callout，也在翻译节里）
  await quoteOnce('结论条划词', function () {
    return { node: document.querySelector('.dsh-sel-callout'), needle: '进度延迟' }
  })

  // ③ 展开详解 → 详解节
  hook.expand()
  await waitFor(function () { return (hook.parts().detail || '').length > 0 && hook.state().phase === 'done' }, 4000)
  check('详解节渲染出来了', !!sectionContent('detail'), '')
  var picked3 = await quoteOnce('详解节划词', function () {
    return { node: sectionContent('detail'), needle: '也可以被划词引用' }
  })
  check('详解节的来源写明是哪一节', !!picked3 && picked3.label.indexOf('详解') >= 0, picked3 && picked3.label)

  // ④ 跨节选择：从翻译节拖到详解节
  {
    var from = sectionContent('translation')
    var to = sectionContent('detail')
    var texts = []
    var walker = document.createTreeWalker(from, NodeFilter.SHOW_TEXT, null)
    var node
    while ((node = walker.nextNode())) if (node.nodeValue.trim()) texts.push(node)
    if (texts.length && to.firstChild) {
      // 与 quoteOnce 同一套重试（合成选区 vs 面板渲染的竞态）
      var shown = false
      for (var attempt2 = 0; attempt2 < 3 && !shown; attempt2 += 1) {
        if (attempt2 > 0) await settlePanel()
        var fromNow = sectionContent('translation')
        var toNow = sectionContent('detail')
        var textsNow = []
        var walker2 = document.createTreeWalker(fromNow, NodeFilter.SHOW_TEXT, null)
        var nodeNow
        while ((nodeNow = walker2.nextNode())) if (nodeNow.nodeValue.trim()) textsNow.push(nodeNow)
        if (!textsNow.length || !toNow.firstChild) break
        var range = document.createRange()
        range.setStart(textsNow[0], 0)
        var endNode = toNow.firstChild.nodeType === 3 ? toNow.firstChild : toNow
        range.setEnd(endNode, Math.min(4, (endNode.nodeValue || '').length))
        var sel = window.getSelection()
        sel.removeAllRanges()
        sel.addRange(range)
        mouseUpOn(toNow)
        shown = await waitFor(function () { return hook.quoteState().visible === true }, 1500)
      }
      check('跨节选择：也浮出「❝ 引用」', shown === true, JSON.stringify(hook.quoteState()))
      if (shown) {
        clickOn(quoteBtn)
        await sleep(40)
        check('跨节选择：进了引用区', chipCount() === 1, JSON.stringify(hook.quotes().map(function (q) { return q.text.length })))
        dropQuotes()
        await sleep(30)
      }
    } else {
      check('跨节选择：也浮出「❝ 引用」', false, '没找到可跨的文本节点')
    }
  }

  // ⑤ 面板**滚动之后**再划词（长内容 + 滚动是真实常态）
  {
    var body = document.querySelector('.dsh-sel-body')
    body.scrollTop = Math.min(120, Math.max(0, body.scrollHeight - body.clientHeight))
    await sleep(30)
    var picked5 = await quoteOnce('滚动后划翻译节', function () {
      return { node: sectionContent('translation'), needle: '迁移跑得比预期久' }
    })
    check('滚动之后划词照常能用', !!picked5, '')
  }

  // ⑥ 代码注释节（「## 注释」+ <pre>，划词落在 pre 里）
  {
    hook.close()
    hook.open('function add(a, b) { return a + b }', 'const x = 1', '代码块')
    await waitFor(function () { return hook.state().phase === 'done' }, 4000)
    var header = document.querySelector('.dsh-sel-sec[data-sec="translation"] .dsh-sel-sh')
    check('代码用例切到「注释」节', !!header && header.textContent.indexOf('注释') >= 0, header ? header.textContent : '未找到')
    await quoteOnce('代码块里划词', function () {
      return { node: document.querySelector('.dsh-sel-pre'), needle: 'const x' }
    })
  }

  // ⑦ 对话气泡（不带上下文，但要写清出处）
  {
    hook.close()
    hook.open('冒烟探针', '上下文片段 ABC', '冒烟')
    await waitFor(function () { return hook.state().phase === 'done' }, 4000)
    var widthBeforeAsk = Math.round(document.querySelector('.dsh-sel-panel').getBoundingClientRect().width)
    hook.ask('冒烟追问')
    // ask() 是异步的（要先取引用上下文 / 传附件才入队）：提问刚发出那一刻 asking 还是 false，
    // 只等 asking===false 会立刻返回、气泡还没画出来。等回答真的落到气泡里再量宽度。
    await waitFor(function () {
      var list = document.querySelectorAll('.dsh-sel-chatlog .dsh-sel-bubble-bot')
      var last = list[list.length - 1]
      return hook.state().asking === false && !!last && last.textContent.indexOf('冒烟用例') >= 0
    }, 4000)
    var widthAfterAsk = Math.round(document.querySelector('.dsh-sel-panel').getBoundingClientRect().width)
    check('追问前后宽度不变（不再从 440 跳到 540）',
      widthBeforeAsk === widthAfterAsk && Math.abs(widthAfterAsk - WIDE_WIDTH) <= 2,
      '追问前 ' + widthBeforeAsk + 'px → 追问后 ' + widthAfterAsk + 'px')
    var bubbles = document.querySelectorAll('.dsh-sel-chatlog .dsh-sel-bubble-bot')
    var bot = bubbles[bubbles.length - 1]
    check('追问气泡渲染出来了', !!bot && bot.textContent.indexOf('冒烟用例') >= 0, bot ? bot.textContent.slice(0, 24) : '未找到')
    var picked7 = await quoteOnce('对话气泡划词', function () { return { node: bot, needle: '冒烟用例' } })
    check('对话引用写清了出处（第 N 轮 + 角色）', !!picked7 && /第 [0-9]+ 轮/.test(picked7.label), picked7 && picked7.label)
    check('对话引用不带上下文（小窗对话本来就在历史里）', !!picked7 && !picked7.context, picked7 && JSON.stringify(picked7.context))
    var all = bot.querySelector('.dsh-sel-bubquote')
    check('气泡末尾有「引用整条」', !!all, '')
    if (all) {
      clickOn(all)
      await sleep(40)
      var quoted = hook.quotes()
      var last = quoted.length ? quoted[quoted.length - 1] : null
      check('「引用整条」也不带上下文', !!last && !last.context, last && JSON.stringify(last.context))
      check('「引用整条」也写清出处', !!last && /第 [0-9]+ 轮/.test(last.label), last && last.label)
      dropQuotes()
      await sleep(30)
    }
  }

  // ⑧ 主界面划词（小窗开着）→ 会话里的引用（带 host 上下文）
  {
    var docp = document.getElementById('docp')
    var picked8 = await quoteOnce('主界面划词', function () { return { node: docp, needle: 'the migration ran long' } })
    check('主界面引用标成会话里的', !!picked8 && picked8.session === true, picked8 && String(picked8.session))
  }

  // ⑨ 点「✦ 解读」后立刻收掉本文档选区（用户报的：小窗亮起时旧选区又触发「❝ 引用」浮标）
  {
    hook.close()
    await sleep(80)
    var planBtn = document.querySelector('.dsh-sel-btn:not(.dsh-sel-quotebtn)')
    var docp2 = document.getElementById('docp')
    selectIn(docp2, 'the migration ran long')
    mouseUpOn(docp2)
    var planShown = await waitFor(function () {
      return planBtn && planBtn.style.display !== 'none' && planBtn.getBoundingClientRect().width > 0
    }, 1500)
    check('主界面划词：浮出「✦ 解读」', planShown === true, planBtn ? planBtn.style.display : '未找到按钮')
    if (planShown) {
      realClick(planBtn)
      // ⚠️ 这里**同步**检查，一下都不 await：开窗自动聚焦那一下是异步的（要等输入框可见），
      //    所以"选区这会儿已经没了"只可能是我们自己在点的时候清的 —— 它骗不过这一条。
      var live = window.getSelection()
      check(
        '点「解读」后选区立刻收掉（同步检查，不等聚焦那一下）',
        !!live && (live.rangeCount === 0 || live.isCollapsed === true),
        live ? 'rangeCount=' + live.rangeCount + ' collapsed=' + live.isCollapsed : 'null',
      )
      check('选区记录也一并作废（不再拿它当"当前选区"）', hook.selection() === null, JSON.stringify(hook.selection()))
      await sleep(120)
      check('旧选区没有让「❝ 引用」浮标复活', !onTop(quoteBtn), String(quoteBtn.style.display))
      // 用户报症状的那一步：小窗亮着时在输入框里按方向键（keyup 会触发一次选区检查）
      var askBox = document.querySelector('.dsh-sel-askbox')
      if (askBox) {
        askBox.dispatchEvent(new KeyboardEvent('keyup', { key: 'ArrowLeft', bubbles: true }))
        await sleep(120)
        check('开窗后按方向键也不再冒出引用浮标', !onTop(quoteBtn), String(quoteBtn.style.display))
      }
      hook.close()
      await sleep(60)
    }
  }

  // ⑨-b 选中的文字被删掉 → 浮标跟着消失（用户报的：文字没了，浮标还赖在屏幕上）
  {
    hook.close()
    await sleep(80)
    var planBtn2 = document.querySelector('.dsh-sel-btn:not(.dsh-sel-quotebtn)')
    var docp3 = document.getElementById('docp')
    selectIn(docp3, 'the migration ran long')
    mouseUpOn(docp3)
    var lit = await waitFor(function () {
      return planBtn2 && planBtn2.style.display !== 'none' && planBtn2.getBoundingClientRect().width > 0
    }, 1500)
    check('（准备）主界面划词浮出「✦ 解读」', lit === true, planBtn2 ? planBtn2.style.display : '未找到按钮')

    // ① 选区塌陷（Backspace / Delete / 打字覆盖 / 剪切走的都是这条）：浏览器会发 selectionchange
    window.getSelection().removeAllRanges()
    var gone = await waitFor(function () { return planBtn2.style.display === 'none' }, 800)
    check('选中的文字被删掉（选区塌陷）→ 浮标消失', gone === true, planBtn2 ? planBtn2.style.display : '未找到按钮')

    // ② 选中的节点被整个换掉（流式回答重渲染就是这条）：那段文字没了，浮标也不该留着。
    //    ⚠️ 先确认浮标**真的收掉了**再往下走：不然 ① 漏掉时浮标一直亮着，
    //      下面的"再次亮着"会白捡一个 PASS（这条用例就测不出东西了）。
    var settled = await waitFor(function () { return planBtn2.style.display === 'none' }, 800)
    check('（准备 ②）① 之后浮标确实是收着的', settled === true, planBtn2 ? planBtn2.style.display : '未找到按钮')
    selectIn(docp3, 'the migration ran long')
    mouseUpOn(docp3)
    var lit2 = await waitFor(function () {
      return planBtn2 && planBtn2.style.display !== 'none' && planBtn2.getBoundingClientRect().width > 0
    }, 1500)
    check('（准备 ②）浮标再次亮着', lit2 === true, planBtn2 ? planBtn2.style.display : '未找到按钮')
    docp3.textContent = '（这段文字已经被换掉了）'
    var gone2 = await waitFor(function () { return planBtn2.style.display === 'none' }, 800)
    check('选中的节点被摘掉（文字被换掉）→ 浮标也消失', gone2 === true, planBtn2 ? planBtn2.style.display : '未找到按钮')
    docp3.textContent = 'Dev: the migration ran long, so we ship Wednesday.'
    await sleep(30)
  }

  // ⑩ 浮标图标的**墨迹**要在画布里居中（用户报的："✦ 和 解读 好像没对齐，也没在按钮里居中"）
  //    为什么量 getBBox 而不是截图：浮动按钮是 align-items:center 的 flex，居中的是**画布盒子**，
  //    图形在画布里偏一点，图标就整体偏一点 —— 老星形路径 y 占 1.2~12.4（中心 6.8，不是 8），
  //    于是比右边「解读」两个字高 1.1px（8x 截图量出来的）。文字墨迹没法用 DOM 量，
  //    但"图标墨迹居中"这一条就足以拦住这类回归。
  {
    var icons = [
      ['解读浮标 ✦ 图标', document.querySelector('.dsh-sel-btn:not(.dsh-sel-quotebtn) svg')],
      ['引用浮标 ❝ 图标', quoteBtn.querySelector('svg')],
    ]
    for (var k = 0; k < icons.length; k += 1) {
      var svg = icons[k][1]
      // 浮标这会儿多半是隐藏的（display:none）—— 隐藏元素的 getBBox() 一律返回 0，
      // 所以量之前先临时摆出来，量完还原（不改它此刻的真实状态）。
      var btn = svg ? svg.closest('.dsh-sel-btn') : null
      var prev = btn ? btn.style.display : ''
      if (btn) btn.style.display = 'inline-flex'
      var box = svg ? svg.getBBox() : null
      if (btn) btn.style.display = prev
      var cx = box ? box.x + box.width / 2 : 0
      var cy = box ? box.y + box.height / 2 : 0
      check(
        icons[k][0] + '墨迹在 16×16 画布里居中',
        !!box && Math.abs(cx - 8) <= 0.25 && Math.abs(cy - 8) <= 0.25,
        box ? 'cx=' + cx.toFixed(2) + ' cy=' + cy.toFixed(2) : '未找到 svg',
      )
    }
  }

  // ⑪ 胶囊宽度：**有**费用胶囊就跟随它，**没有**就收到 PILL_FALLBACK_MAX = 200px（用户定的规则）
  //    这条只有真浏览器能量：要真布局（getBoundingClientRect）、真 CSS（max-width 生效），
  //    还要能挂一个假的 dsh-spend 挂载点。
  {
    var pillNode = hook.pill()
    var pillName = pillNode.querySelector('.dsh-sel-pillname')
    var pillMeta = pillNode.querySelector('.dsh-sel-pillmeta')
    var savedName = pillName.textContent
    var savedMeta = pillMeta.textContent
    // 先确认"动画是声明过的"（冻住之后就量不出来了）：收球/吸附靠 max-width / padding / gap / 位置的过渡
    var pillTrans = getComputedStyle(pillNode).transitionProperty
    check('胶囊声明了过渡（收球/吸附是动画，不是跳变）', /max-width/.test(pillTrans) && /padding/.test(pillTrans) && /left/.test(pillTrans), pillTrans)
    check('过渡只在"第一帧已经贴好位置"之后才打开（data-ready）', hook.pillState().ready === true, String(hook.pillState().ready))

    // 收 / 放**严格互逆**的结构前提：所有会变的属性共用同一条时长 + 同一条曲线，
    // 而且那条曲线必须时间对称（x1+x2=1 且 y1+y2=1 → 把动画倒过来放就是另一个方向）。
    // 之前用 easeOutQuint(.22,1,.36,1)：.22+.36≠1，两个方向前后半程不镜像 —— 用户报的"不对称"就是它。
    var durList = splitCssList(getComputedStyle(pillNode).transitionDuration)
    var easeList = splitCssList(getComputedStyle(pillNode).transitionTimingFunction)
    var morphDur = durList.slice(1) // 第 0 条是 box-shadow 的 .15s，不属于形变
    var morphEase = easeList.slice(1)
    check('收/放所有属性共用一条时长', morphDur.length > 0 && morphDur.every(function (x) { return x === morphDur[0] }), durList.join(' | '))
    check('收/放所有属性共用一条曲线', morphEase.length > 0 && morphEase.every(function (x) { return x === morphEase[0] }), easeList.join(' | '))
    // 不用正则：这段代码在模板字符串里，\( 这种转义会被吃掉（踩过）
    var easeText = morphEase[0] || ''
    var easeAt = easeText.indexOf('cubic-bezier(')
    var easeArgs = easeAt >= 0
      ? easeText.slice(easeAt + 'cubic-bezier('.length, -1).split(',').map(function (x) { return Number(x.trim()) })
      : []
    check(
      '曲线时间对称（x1+x2=1 且 y1+y2=1 → 倒放即另一个方向）',
      easeArgs.length === 4 && Math.abs(easeArgs[0] + easeArgs[2] - 1) < 1e-6 && Math.abs(easeArgs[1] + easeArgs[3] - 1) < 1e-6,
      easeText + ' → ' + JSON.stringify(easeArgs),
    )
    var nameDur = splitCssList(getComputedStyle(pillName).transitionDuration)[0]
    var starEl = pillNode.querySelector('.dsh-sel-pillstar')
    var starTrans = getComputedStyle(starEl)
    check('文字那格的时长和胶囊一致（不一致 → 中间帧宽度由另一条曲线决定）', nameDur === morphDur[0], nameDur + ' vs ' + morphDur[0])

    // ── 球心图形的形变轨迹（这一组是重点：光看两端点会漏掉中间帧的形状） ──
    // 曾经踩过的坑：用 CSS 的 transition:d 在两条静态 path 之间插值 —— CSS 只能线性插值，
    // 于是中途会经过一个正菱形（谷跟着尖一起动），读起来像方块；而且尖在 160ms 就停住、
    // 胶囊还要走到 280ms，"配合"就散了。所以现在路径由 JS 按 p 现算（两段 smoothstep）。
    check('球心图形不走 CSS 的 d 过渡（线性插值会经过正菱形）', starTrans.transitionProperty.trim() !== 'd', starTrans.transitionProperty.trim() || '(无过渡)')
    var radiiAt = function (p) {
      // 不写正则：模板字符串里反斜杠会被吃掉。按 M/L 切段再取两个数。
      var parts = String(hook.pillStarAt(p)).split('L')
      parts[0] = parts[0].charAt(0) === 'M' ? parts[0].slice(1) : parts[0]
      return parts.map(function (seg) {
        var z = seg.indexOf('Z')
        if (z >= 0) seg = seg.slice(0, z)
        var xy = seg.split(' ')
        return Math.sqrt(parseFloat(xy[0]) * parseFloat(xy[0]) + parseFloat(xy[1]) * parseFloat(xy[1]))
      })
    }
    var r0 = radiiAt(0)
    var r25 = radiiAt(0.25)
    var r50 = radiiAt(0.5)
    var r80 = radiiAt(0.8)
    var r100 = radiiAt(1)
    check('p=0：32 个顶点同半径 4.00（8px 圆点）', r0.length === 32 && r0.every(function (r) { return Math.abs(r - 4) < 0.02 }), r0.length + ' 顶点，半径 ' + r0[0].toFixed(3))
    check('p=0.25：谷仍停在 4.00（"两段"的签名 —— 线性插值会把它拉到 3.80，那就是菱形相）', Math.abs(r25[4] - 4) < 0.02, '谷 ' + r25[4].toFixed(3))
    check('p=0.25：尖已经在长（> 4 但远未到顶，尖先长）', r25[0] > 4.3 && r25[0] < r100[0] - 0.5, '尖 ' + r25[0].toFixed(3) + '（顶 ' + r100[0].toFixed(2) + '）')
    check('p=0.5：尖接近满长（≥ 顶-0.6），身刚开始收（谷仍 > 3.6）', r50[0] >= r100[0] - 0.6 && r50[4] > 3.6, '尖 ' + r50[0].toFixed(2) + ' / 谷 ' + r50[4].toFixed(2))
    // 同一个 p 下，从尖到谷的半径必须单调递减（尖 > 11.25° > 22.5° > 33.75° > 谷），
    // 且左右对称 —— 这就是"不出现波浪边"的可测形式。
    var sectorOk = function (r) {
      var k
      for (k = 0; k < 4; k += 1) if (r[k] < r[k + 1] - 0.02) return false
      for (k = 1; k < 16; k += 1) if (Math.abs(r[k] - r[32 - k]) > 0.02) return false
      return true
    }
    check('同一进度下：尖→谷单调递减且左右对称（没有波浪边）', sectorOk(r25) && sectorOk(r50) && sectorOk(radiiAt(0.8)), JSON.stringify(r50.map(function (r) { return Number(r.toFixed(2)) }).slice(0, 5)))
    // 形状空间的过冲：尖在 p≈0.8 处冲过终点一点，到 p=1 精确回到终点
    check('尖有轻微过冲（p=0.8 处高出终点一点，再收回）', r80[0] > r100[0] + 0.05, 'p=.8 尖 ' + r80[0].toFixed(3) + ' / p=1 尖 ' + r100[0].toFixed(3))
    check('p=1 的路径与客户端常量逐字相同（和「✦ 解读」那颗星同一条几何）', hook.pillStarAt(1) === hook.pillStarD(), hook.pillStarAt(1) === hook.pillStarD() ? '逐字一致' : '不一致')
    check('p=0 的路径与客户端常量逐字相同（展开态就是那枚 8px 圆点）', hook.pillStarAt(0) === hook.pillStarDotD(), hook.pillStarAt(0) === hook.pillStarDotD() ? '逐字一致' : '不一致')
    // 曲线：时间对称（倒放即另一个方向）+ 轻微蓄势/过冲（不直来直去）
    var xs = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    var ys = xs.map(function (x) { return hook.pillStarEaseAt(x) })
    var symOk = xs.every(function (x) { return Math.abs(hook.pillStarEaseAt(x) + hook.pillStarEaseAt(1 - x) - 1) < 1e-6 })
    check('球心图形的曲线时间对称（收/放互为倒放）', symOk, ys.map(function (y) { return y.toFixed(3) }).join(' '))
    // 曲线本身要"干净"（单调 S，不能是波浪）：过冲放在形状空间，不放在时间轴上
    var monotone = true
    for (var mi = 1; mi < xs.length; mi += 1) if (hook.pillStarEaseAt(xs[mi]) <= hook.pillStarEaseAt(xs[mi - 1])) monotone = false
    check('时间轴上的曲线是干净单调的 S（过冲不放在这里 —— 对称曲线的过冲必成波浪）', monotone && ys[0] > 0 && ys[ys.length - 1] < 1, ys.map(function (y) { return y.toFixed(3) }).join(' '))
    check('JS 那条时长与 CSS 那条同拍（280ms ↔ .28s）', hook.pillMorphMs() === 280 && morphDur[0] === '0.28s', hook.pillMorphMs() + 'ms vs ' + morphDur[0])
    freezeMotion()
    // 最坏内容（选中文字 12 字 + 最长状态）：自然宽度 301px，最容易被上限拦到
    pillName.textContent = '迁移作业耗时超出了原计划…'
    pillMeta.textContent = '· 追问中 12.3s'

    // ① 没有费用胶囊 → 兜底上限 200
    hook.place()
    check('没有费用胶囊：上限收到 200px', pillNode.style.maxWidth === '200px', pillNode.style.maxWidth || '(空 = 回落 CSS 280)')
    check('没有费用胶囊：不写死宽度（内容自适应）', pillNode.style.width === '', pillNode.style.width || '(空)')
    var cappedWidth = Math.round(pillNode.getBoundingClientRect().width)
    check('没有费用胶囊：最坏内容也真的被拦在 200px', cappedWidth === 200, cappedWidth + 'px')
    check('没有费用胶囊：拦到上限后选中文字走省略号（不撑破）', pillName.scrollWidth > pillName.clientWidth, pillName.clientWidth + 'px 可见 / ' + pillName.scrollWidth + 'px 全长')

    // ② 挂一个假的费用胶囊（宽 240）→ 跟随它的实测宽度，并清掉兜底上限
    var fakeSpend = document.createElement('div')
    fakeSpend.id = 'dsh-spend-widget'
    fakeSpend.innerHTML = '<div class="dsu-widget" style="position:fixed;right:20px;bottom:20px">'
      + '<div class="dsu-pill" style="box-sizing:border-box;width:240px;height:32px"></div></div>'
    document.body.appendChild(fakeSpend)
    hook.place()
    check('有费用胶囊：宽度写死成它的实测宽度', pillNode.style.width === '240px', pillNode.style.width || '(空)')
    check('有费用胶囊：清掉兜底上限（回到 CSS 280，和它同宽）', pillNode.style.maxWidth === '', pillNode.style.maxWidth || '(空)')
    // ⚠️ 宽度现在有过渡（.32s）：改完立刻量会量到**起点**，得等它走完
    await sleep(420)
    var followedWidth = Math.round(pillNode.getBoundingClientRect().width)
    check('有费用胶囊：最坏内容跟着它到 240px（上限确实放开了）', followedWidth === 240, followedWidth + 'px')

    // ③ 费用胶囊消失 → 立刻回到兜底
    fakeSpend.remove()
    hook.place()
    check(
      '费用胶囊消失后又回到 200px 兜底',
      pillNode.style.maxWidth === '200px' && pillNode.style.width === '',
      pillNode.style.maxWidth + ' / ' + (pillNode.style.width || '宽=空'),
    )
    // ⚠️ 这里必须把"最坏内容"重新写一遍再量：paintPill() 会在异步里把文案换回**真实内容**
    //    （真实内容自然宽 184px < 200，于是量到 184 而不是 200）—— 这条断言想验的是
    //    "上限回到 200"，不是"内容恰好 301px"，写回最坏内容才与内容变化解耦（否则偶发红）。
    pillName.textContent = '迁移作业耗时超出了原计划…'
    pillMeta.textContent = '· 追问中 12.3s'
    await sleep(420)
    check('回到兜底后宽度也收回来了', Math.round(pillNode.getBoundingClientRect().width) === 200, Math.round(pillNode.getBoundingClientRect().width) + 'px')

    // 还原内容（后面的断言不受影响）
    pillName.textContent = savedName
    pillMeta.textContent = savedMeta
    hook.place()
  }

  // ⑫ 胶囊可以拖：拖到别处就留在那儿；拖回右下角附近自动吸附回去；拖完那一下不算点击。
  //    全用真鼠标事件（mousedown 打在胶囊上，mousemove/mouseup 打在 window —— 和面板拖动同一套）。
  //    过渡已在 ⑪ 冻住（见 freezeMotion），所以每一步都能**同步**断言，不用等动画。
  {
    var pillEl = hook.pill()
    var panelOpen = function () {
      return hook.quoteState().panelOpen === true
    }
    function fire(type, x, y, onWindow) {
      var event = new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 })
      if (onWindow) window.dispatchEvent(event)
      else pillEl.dispatchEvent(event)
    }
    function dragTo(x, y) {
      var rect = pillEl.getBoundingClientRect()
      fire('mousedown', Math.round(rect.left) + 20, Math.round(rect.top) + 10, false)
      fire('mousemove', x, y, true)
      fire('mousemove', x + 4, y + 2, true) // 第二下：确保"位移超过阈值"这条判定走完
      fire('mouseup', x + 4, y + 2, true)
    }
    /** 拖到右下角那一带（吸附区）—— 用视口右下角算，和"贴角位置"差得不多，必落在吸附半径里。 */
    function dragToCorner() {
      dragTo(Math.round(window.innerWidth - 30), Math.round(window.innerHeight - 30))
    }

    hook.place()
    var home = hook.pillState()
    check('起始：贴着右下角（dock=anchor，right/bottom=20）', home.dock === 'anchor' && home.rect.right === 20 && home.rect.bottom === 20, home.dock + ' ' + home.rect.right + '/' + home.rect.bottom)

    // ① 拖到屏幕中间 → 留在那儿（自由摆放）
    var midX = Math.round(window.innerWidth / 2)
    var midY = Math.round(window.innerHeight / 2)
    dragTo(midX, midY)
    var free = hook.pillState()
    check('拖到屏幕中间：位置跟着走了（dock=free）', free.dock === 'free', free.dock)
    check('拖到屏幕中间：落在松手的地方（±40px）', Math.abs(free.rect.left + 20 - midX) < 40 && Math.abs(free.rect.top + 10 - midY) < 40, free.rect.left + ',' + free.rect.top)

    // 自由摆放时，贴角轮询不许把它拽回去
    hook.place()
    var stillFree = hook.pillState()
    check('自由摆放时轮询不把它拽回去', stillFree.dock === 'free' && Math.abs(stillFree.rect.left - free.rect.left) <= 2, stillFree.dock + ' ' + stillFree.rect.left)

    // ② 拖回右下角附近 → 自动吸附回贴角位置（没有费用胶囊就是 20/20）
    dragToCorner()
    var snapped = hook.pillState()
    check('拖回右下角附近：自动吸附（dock=anchor）', snapped.dock === 'anchor', snapped.dock)
    check('吸附回右下角 20/20', snapped.rect.right === 20 && snapped.rect.bottom === 20, snapped.rect.right + '/' + snapped.rect.bottom)

    // ③ 拖完浏览器会补一个 click —— 不能被当成"点了一下"（否则会顺手开关小窗）
    if (panelOpen()) hook.close()
    dragTo(midX, midY)
    fire('click', midX, midY, false) // 模拟浏览器在拖完之后补的那一下
    check('拖完那一下不算点击（小窗没被打开）', panelOpen() === false, String(panelOpen()))
    check('拖完那一下也不算"点开"（胶囊还在自由摆放位）', hook.pillState().dock === 'free', hook.pillState().dock)

    // ④ 有费用胶囊时：拖到右下角附近 → 吸附到"跟随它的位置"（在那枚胶囊上方、同宽）
    var fakeSpend2 = document.createElement('div')
    fakeSpend2.id = 'dsh-spend-widget'
    fakeSpend2.innerHTML = '<div class="dsu-widget" style="position:fixed;right:20px;bottom:20px">'
      + '<div class="dsu-pill" style="box-sizing:border-box;width:240px;height:32px"></div></div>'
    document.body.appendChild(fakeSpend2)
    hook.place()
    dragToCorner()
    var withSpend = hook.pillState()
    check('有费用胶囊时拖到右下角：吸附到跟随它的位置', withSpend.dock === 'anchor' && withSpend.rect.right === 20, withSpend.dock + ' right=' + withSpend.rect.right)
    check('吸附后宽度是跟随它的 240px', withSpend.rect.width === 240, withSpend.rect.width + 'px')
    check('吸附位置在费用胶囊**上方**（不压住它）', withSpend.rect.bottom >= 42, 'bottom=' + withSpend.rect.bottom)

    // 再拖走 → 留在那儿；再拖回 → 又吸附回去
    dragTo(midX, midY)
    check('有费用胶囊时也能拖走（dock=free）', hook.pillState().dock === 'free', hook.pillState().dock)
    dragToCorner()
    var backHome = hook.pillState()
    check('再拖回右下角：又吸附回去', backHome.dock === 'anchor' && backHome.rect.right === 20, backHome.dock + ' right=' + backHome.rect.right)
    fakeSpend2.remove()
    hook.place()

    // ⑤ 没动的那一下仍然是"点击"（拖动不能把点击吃掉）
    if (panelOpen()) hook.close()
    var clickRect = pillEl.getBoundingClientRect()
    fire('mousedown', Math.round(clickRect.left) + 20, Math.round(clickRect.top) + 10, false)
    fire('mouseup', Math.round(clickRect.left) + 20, Math.round(clickRect.top) + 10, true)
    fire('click', Math.round(clickRect.left) + 20, Math.round(clickRect.top) + 10, false)
    await sleep(160)
    check('没位移的那一下照旧是点击（小窗打开了）', panelOpen() === true, String(panelOpen()))
    hook.close()
    // 关小窗会让面板尺寸变 0 → 面板那个 ResizeObserver 会补一次 placePanel→paintPill（= 一次"活动"）。
    // 生产上无所谓（只是把静置计时重新拨满），测试里得先把这拍异步排掉，否则会和下面的收球抢时序。
    await sleep(200)
  }

  // ⑬ 静置收球：**没有费用胶囊**时收成小球；有费用胶囊 / 小窗开着 / 鼠标停着都不收。
  //    过渡已冻住，所以"收成 32×32"是同步可断言的；"到底有没有过渡"在 ⑪ 用 computed style 断言过。
  {
    var pillBall = hook.pill()
    var panelIsOpen = function () {
      return hook.quoteState().panelOpen === true
    }
    if (panelIsOpen()) hook.close()
    await sleep(200)
    var before = hook.pillState()
    check('收球前是展开的胶囊', before.ball === false && before.rect.width > 100, before.rect.width + 'px')

    var anchoredRightBefore = window.innerWidth - before.rect.right
    var idleCollapsed = hook.pillIdle()
    var balled = hook.pillState()
    check('没有费用胶囊 → 静置收球', idleCollapsed === true && balled.ball === true, JSON.stringify(balled.style))
    check('收成小球：32×32 的圆', balled.rect.width === balled.ballSize && balled.rect.height === balled.ballSize, balled.rect.width + '×' + balled.rect.height)
    check('小球仍然贴着右下角（位置没跑）', balled.rect.right === 20 && balled.rect.bottom === 20, balled.rect.right + '/' + balled.rect.bottom)
    check(
      '锚定态收球：以胶囊自己的右边缘为锚（右边缘不动，往左收成球）',
      Math.abs((window.innerWidth - balled.rect.right) - anchoredRightBefore) <= 1,
      '右边缘 ' + anchoredRightBefore.toFixed(1) + ' → ' + (window.innerWidth - balled.rect.right).toFixed(1),
    )

    // ── 球心里的星芒：收球时 d 换成星、展开时换回圆点，几何都得对得上 ──
    //    球心图形是 JS 按时间推进的（胶囊那条是 CSS 过渡，被 freezeMotion 冻成瞬时），
    //    所以分三件事验：① 目标对不对（同步）② 计时器真的在推进（短等几拍）③ 终态几何（同步画到终点再量）。
    //    ⚠️ 不能靠"等 280ms 再看"：这段时间里任何一次活动（比如首轮解读流式结束后的 paintPill）
    //       都会按设计把球展开回胶囊，等出来的就不是球态了。
    var starCanvas = pillBall.querySelector('.dsh-sel-pillicon')
    var starPath = pillBall.querySelector('.dsh-sel-pillstar')
    var starWant = hook.pillStarD()
    var dotWant = hook.pillStarDotD()
    check('收球时球心图形的目标是"星芒"（1）', hook.pillStarTarget() === 1, String(hook.pillStarTarget()))
    // "计时器真的在推进"用解耦的钩子验（不依赖胶囊此刻是不是球态 ——
    //  首轮解读收尾时 paintPill→notePillActivity 会按设计把球展开，和这条无关）
    hook.pillStarAnimate(0)
    var pAtStart = hook.pillStarProgress()
    hook.pillStarAnimate(1)
    var grew = false
    for (var tick = 0; tick < 12 && !grew; tick += 1) {
      await sleep(24)
      if (hook.pillStarProgress() > pAtStart + 0.05) grew = true
    }
    check('球心图形的动画真的在推进（计时器在跑，不是画一帧就停）', grew, pAtStart.toFixed(3) + ' → ' + hook.pillStarProgress().toFixed(3))
    // 球态的画布居中：这是 CSS 那边的事（margin 过渡），冻住运动后是瞬时终值，可以同步量。
    // ⚠️ 先显式确保还在球态：上面的等待里任何一次活动都会按设计把球展开。
    if (hook.pillState().ball !== true) {
      hook.pillIdle()
      await sleep(80)
    }
    check('（前置）此刻确实是球态，下面量的是球心几何', hook.pillState().ball === true, String(hook.pillState().ball))
    var ballRect = pillBall.getBoundingClientRect()
    var canvasRect = starCanvas.getBoundingClientRect()
    check(
      '星芒在球里居中（图形中心 = 球的中心，±0.6px）',
      Math.abs(canvasRect.left + canvasRect.width / 2 - (ballRect.left + ballRect.width / 2)) <= 0.6,
      '画布中心 ' + (canvasRect.left + canvasRect.width / 2).toFixed(1) + ' vs 球中心 ' + (ballRect.left + ballRect.width / 2).toFixed(1),
    )
    check('球态画布用 -1px 负边距摆正（内宽 32-2 边框 = 30）', getComputedStyle(starCanvas).marginLeft === '-1px', getComputedStyle(starCanvas).marginLeft)
    // 同步画到终点，再量终态几何（不受计时器与异步活动影响）
    hook.pillStarTo(1)
    var starD = starPath.getAttribute('d')
    var starBox = starPath.getBBox()
    check('收球终态：d 与客户端那条常量逐字相同', starD === starWant, starD === starWant ? '32 顶点一致' : starD.slice(0, 18) + '… ≠ ' + starWant.slice(0, 18))
    var pillFontSize = parseFloat(getComputedStyle(pillBall).fontSize)
    check(
      '星芒和胶囊里的文字一样高（墨迹 ≈ 字号，±0.8px）',
      Math.abs(starBox.height - pillFontSize) <= 1.0 && Math.abs(starBox.width - starBox.height) < 0.15,
      '星芒 ' + starBox.width.toFixed(2) + '×' + starBox.height.toFixed(2) + ' vs 字号 ' + pillFontSize + 'px',
    )
    check(
      '星芒的内外半径比 = .3788（和「✦ 解读」浮标那颗星同一条几何，只是缩小了）+ 顶点数 32',
      Math.abs(r100[0] / r100[4] - 1 / 0.3788) < 0.05 && r100.length === 32,
      '尖 ' + r100[0].toFixed(2) + ' / 谷 ' + r100[4].toFixed(2) + ' = ' + (r100[0] / r100[4]).toFixed(3) + '（应为 2.640）',
    )

    // 鼠标一放上去就展开（若已被异步活动展开过，先收回球态，好让 mouseenter 真的走一次展开）
    if (hook.pillState().ball !== true) {
      hook.pillIdle()
      await sleep(80)
    }
    pillBall.dispatchEvent(new MouseEvent('mouseenter', { view: window }))
    var expanded = hook.pillState()
    check('鼠标移上去：小球展开回胶囊', expanded.ball === false && expanded.rect.width > 100, expanded.rect.width + 'px')
    check(
      '锚定态展开：右边缘同样不动（往右长回去）',
      Math.abs((window.innerWidth - expanded.rect.right) - anchoredRightBefore) <= 1,
      '右边缘 ' + anchoredRightBefore.toFixed(1) + ' → ' + (window.innerWidth - expanded.rect.right).toFixed(1),
    )
    // 展开态：图形回到 8px 圆点，且画布**布局占位**仍是 8px（两侧 -12px）——
    // 这样胶囊的排版与宽度和以前那枚 8px 圆点完全一样，不会因为换了个 SVG 就把胶囊撑宽。
    check('展开时球心图形的目标是"圆点"（0）', hook.pillStarTarget() === 0, String(hook.pillStarTarget()))
    // 真实悬停路径：展开会重置静置计时，不能因此取消球心图形的动画。
    pillBall.dispatchEvent(new MouseEvent('mouseleave', { view: window }))
    if (hook.pillState().ball !== true) hook.pillIdle()
    hook.pillStarTo(1)
    pillBall.dispatchEvent(new MouseEvent('mouseenter', { view: window }))
    await sleep(350)
    check(
      '悬停展开后星芒自行回到圆点',
      hook.pillState().ball === false && hook.pillStarProgress() === 0 && starPath.getAttribute('d') === dotWant,
      'ball=' + hook.pillState().ball + ' progress=' + hook.pillStarProgress(),
    )
    hook.pillStarTo(0) // 同步画回圆点，量终态
    var dotD = pillBall.querySelector('.dsh-sel-pillstar').getAttribute('d')
    var dotBox = pillBall.querySelector('.dsh-sel-pillstar').getBBox()
    var iconCanvas = pillBall.querySelector('.dsh-sel-pillicon')
    var iconStyle = getComputedStyle(iconCanvas)
    var pillRectForDot = pillBall.getBoundingClientRect()
    var canvasForDot = iconCanvas.getBoundingClientRect()
    var dotRect = starPath.getBoundingClientRect()
    var dotCx = dotRect.left + dotRect.width / 2
    var dotCy = dotRect.top + dotRect.height / 2
    var canvasCx = canvasForDot.left + canvasForDot.width / 2
    var pillCy = pillRectForDot.top + pillRectForDot.height / 2
    check(
      '展开后圆点墨迹居中：横向在 SVG 画布中心，纵向在胶囊中心',
      Math.abs(dotCx - canvasCx) < 0.25 && Math.abs(dotCy - pillCy) < 0.25,
      '偏移 x=' + (dotCx - canvasCx).toFixed(2) + ' y=' + (dotCy - pillCy).toFixed(2),
    )
    check('展开后回到圆点态：d 与客户端那条常量**逐字相同**', dotD === dotWant, dotD === dotWant ? '32 顶点一致' : dotD.slice(0, 14) + '… ≠ ' + dotWant.slice(0, 14))
    // 这条是补覆盖：上面用 pillStarTo(0) 同步画到终点，验的是"终点长什么样"，
    // 但"展开这条动画**自己**会不会走到终点"没验过 —— 用户报的"展开后没恢复成圆点"正是这里。
    hook.pillStarAnimate(1)
    await sleep(60)
    hook.pillStarAnimate(0)
    var settled = false
    for (var settleTick = 0; settleTick < 24 && !settled; settleTick += 1) {
      await sleep(24)
      if (hook.pillStarProgress() === 0) settled = true
    }
    check('展开动画自己会走到圆点（不是停在星芒上）', settled, 'progress=' + hook.pillStarProgress())

    // 用户报的"展开后没恢复成圆点"，根因是**打断**：来回打断时每一段都跑满 280ms，
    // 于是图形永远追不上目标（实测序列 10101010、进度卡在 0.158）。
    // 这里用高频交替打断复现它，然后断言"停手之后能很快落到目标上"。
    // （比"等悬停那一下走完"稳：冒烟跑在虚拟时钟下，10 秒静置会瞬间到期、球态随时可能翻。）
    hook.pillStarAnimate(0)
    for (var ham = 0; ham < 8; ham += 1) {
      hook.pillStarAnimate(1)
      await sleep(16)
      hook.pillStarAnimate(0)
      await sleep(16)
    }
    var settleTicks = -1
    for (var st = 0; st < 40 && settleTicks < 0; st += 1) {
      await sleep(24)
      if (hook.pillStarProgress() === 0) settleTicks = st + 1
    }
    check(
      '来回打断之后图形仍会落到目标上，且很快（不再卡在半路）',
      settleTicks > 0 && settleTicks <= 6,
      '停手后第 ' + settleTicks + ' 拍到位（每拍 24ms）· progress=' + hook.pillStarProgress() + ' · 起跑=' + hook.pillStarStarts(),
    )
    pillBall.dispatchEvent(new MouseEvent('mouseleave', { view: window }))
    check('圆点态墨迹 8×8（和以前那枚 8px 圆点一致）', Math.abs(dotBox.width - 8) < 0.1 && Math.abs(dotBox.height - 8) < 0.1, dotBox.width.toFixed(2) + '×' + dotBox.height.toFixed(2))
    check('展开态画布布局占位 = 8px（两侧 -12px 负边距）', iconStyle.marginLeft === '-12px' && iconStyle.marginRight === '-12px', iconStyle.marginLeft + '/' + iconStyle.marginRight)
    check('展开态画布本身仍是 32px（1 单位 = 1px，几何数字照抄设计稿）', iconStyle.width === '32px' && iconStyle.height === '32px', iconStyle.width + '×' + iconStyle.height)
    check('展开后还是贴右下角', expanded.rect.right === 20 && expanded.rect.bottom === 20, expanded.rect.right + '/' + expanded.rect.bottom)

    // 鼠标离开 → 又能收
    pillBall.dispatchEvent(new MouseEvent('mouseleave', { view: window }))
    check('鼠标离开后静置又能收球', hook.pillIdle() === true && hook.pillState().ball === true, String(hook.pillState().ball))

    // 鼠标停在上面时不许收（"点得到"优先于"藏起来"）
    pillBall.dispatchEvent(new MouseEvent('mouseenter', { view: window }))
    check('鼠标停在小球上时不收球', hook.pillIdle() === false && hook.pillState().ball === false, String(hook.pillState().ball))
    pillBall.dispatchEvent(new MouseEvent('mouseleave', { view: window }))

    // 自由摆放时收球/展开都以**右边缘**为锚（往左收成球、往右展开回原样，右边缘一个像素都不动）
    // 这条只有真浏览器能验：要真布局量矩形、真过渡（这里已冻住 → 量到的是终值）。
    {
      var homeRect = hook.pillState().rect
      hook.pillIdle() // 先收起来（锚定态）
      var anchored = hook.pillState()
      var midX2 = Math.round(window.innerWidth / 2)
      var midY2 = Math.round(window.innerHeight / 2)
      pillBall.dispatchEvent(new MouseEvent('mouseenter', { view: window })) // 展开再拖（拖的是展开态）
      pillBall.dispatchEvent(new MouseEvent('mouseleave', { view: window }))
      var r0 = pillBall.getBoundingClientRect()
      var fireOn = function (type, x, y, onWindow) {
        var event = new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 })
        if (onWindow) window.dispatchEvent(event)
        else pillBall.dispatchEvent(event)
      }
      fireOn('mousedown', Math.round(r0.left) + 20, Math.round(r0.top) + 10, false)
      fireOn('mousemove', midX2, midY2, true)
      fireOn('mousemove', midX2 + 4, midY2 + 2, true)
      fireOn('mouseup', midX2 + 4, midY2 + 2, true)
      var wideFree = hook.pillState()
      check('自由摆放（拖到中间）', wideFree.dock === 'free' && wideFree.rect.width > 100, wideFree.dock + ' ' + wideFree.rect.width)
      check(
        '自由摆放使用固定的 CSS right 定位，使过渡每一帧都能守住右边缘',
        wideFree.style.left === 'auto' && wideFree.style.right !== 'auto' && wideFree.style.right !== '',
        'left=' + wideFree.style.left + ' right=' + wideFree.style.right,
      )
      var rightBefore = wideFree.rect.right
      hook.pillIdle()
      var ballFree = hook.pillState()
      check('自由摆放时收球：右边缘不动（±1px，往左收成球）', ballFree.ball === true && Math.abs(ballFree.rect.right - rightBefore) <= 1, '右边缘 ' + rightBefore.toFixed(1) + ' → ' + ballFree.rect.right.toFixed(1))
      var geoRightBefore = window.innerWidth - rightBefore
      var geoRightBall = window.innerWidth - ballFree.rect.right
      check('自由摆放时收球：球确实贴到了右边缘（球右边 = 原胶囊右边，球宽 32）', Math.abs(geoRightBall - geoRightBefore) <= 1 && ballFree.rect.width === ballFree.ballSize, '几何右边 ' + geoRightBefore.toFixed(1) + ' → ' + geoRightBall.toFixed(1) + '，球宽 ' + ballFree.rect.width)
      pillBall.dispatchEvent(new MouseEvent('mouseenter', { view: window }))
      var wideAgain = hook.pillState()
      check('自由摆放时展开：右边缘也不动（±1px）', wideAgain.ball === false && Math.abs(wideAgain.rect.right - rightBefore) <= 1, '右边缘 ' + rightBefore.toFixed(1) + ' → ' + wideAgain.rect.right.toFixed(1))

      await sleep(30) // 存档是异步 POST
      check(
        '拖到别处后把位置存到了 host 上（右边缘 + 垂直中心）',
        pillPosStore && Math.abs(pillPosStore.right - (window.innerWidth - wideFree.rect.right)) <= 2,
        JSON.stringify(pillPosStore) + ' vs 几何右边 ' + (window.innerWidth - wideFree.rect.right).toFixed(1),
      )
      // 读回来：预置一个位置，调钩子，胶囊应当切成自由摆放并摆到那儿（右边缘为锚）
      pillPosStore = { right: 300, y: 220 }
      hook.loadPillPos()
      await sleep(60)
      var restored = hook.pillState()
      check(
        '重挂载读回 host 上的位置：切成自由摆放并摆回去（右边缘 = 存档）',
        restored.dock === 'free' && Math.abs(window.innerWidth - restored.rect.right - 300) <= 2,
        'dock=' + restored.dock + ' 几何右边 ' + (window.innerWidth - restored.rect.right).toFixed(1) + '（存档 300）',
      )
      // 再拖回中间，接着跑下面的"收球右边缘不动"
      pillPosStore = null
      hook.loadPillPos()
      await sleep(0)
      pillBall.dispatchEvent(new MouseEvent('mouseleave', { view: window }))
      // 拖回右下角，后面的断言接着用锚定态
      var frozenStyle = document.getElementById('freeze-motion')
      fireOn('mousedown', Math.round(pillBall.getBoundingClientRect().left) + 20, Math.round(pillBall.getBoundingClientRect().top) + 10, false)
      fireOn('mousemove', Math.round(window.innerWidth - 30), Math.round(window.innerHeight - 30), true)
      frozenStyle.remove() // 拖动中 data-drag 会关过渡，此时解除全局冻结，不会让胶囊跳
      fireOn('mouseup', Math.round(window.innerWidth - 30), Math.round(window.innerHeight - 30), true)
      var snapAnimated = pillBall.getAnimations().some(function (animation) { return animation.transitionProperty === 'left' })
      check('自由摆放从 CSS right 切回吸附时仍有滑行动画', snapAnimated, String(snapAnimated))
      document.head.appendChild(frozenStyle)
      check('拖回右下角后又吸附（回到 anchor）', hook.pillState().dock === 'anchor', JSON.stringify(hook.pillState()))
      await sleep(30)
      check('吸附回右下角后清掉 host 上的存档（那是默认位置，不用记）', pillPosStore === null, JSON.stringify(pillPosStore))
      check('锚定位置和最初一致', Math.abs(hook.pillState().rect.left - homeRect.left) <= 2, hook.pillState().rect.left + ' vs ' + homeRect.left)
      void anchored
    }

    // 有费用胶囊时不收球（收球的前提是"没有可跟随的胶囊"）
    var fakeSpend3 = document.createElement('div')
    fakeSpend3.id = 'dsh-spend-widget'
    fakeSpend3.innerHTML = '<div class="dsu-widget" style="position:fixed;right:20px;bottom:20px">'
      + '<div class="dsu-pill" style="box-sizing:border-box;width:240px;height:32px"></div></div>'
    document.body.appendChild(fakeSpend3)
    hook.place()
    check('有费用胶囊时静置也不收球', hook.pillIdle() === false, String(hook.pillState().ball))
    check('有费用胶囊时保持展开', hook.pillState().ball === false, String(hook.pillState().ball))

    // 收着球时费用胶囊出现 → 立刻展开（球没有存在的意义了）
    fakeSpend3.remove()
    hook.place()
    check('静置收球后费用胶囊出现 → 立刻展开', hook.pillIdle() === true && hook.pillState().ball === true, String(hook.pillState().ball))
    document.body.appendChild(fakeSpend3)
    hook.place()
    check('费用胶囊一出现，小球立刻展开', hook.pillState().ball === false && hook.pillState().rect.width === 240, hook.pillState().ball + ' ' + hook.pillState().rect.width)
    fakeSpend3.remove()
    hook.place()

    // 小窗开着时不收球（"小窗活动"也是活动）
    hook.open('收球冒烟：小窗开着', '上下文', '冒烟')
    await sleep(200)
    check('小窗开着时不收球', hook.pillIdle() === false, String(hook.pillState().ball))
    hook.close()
    await sleep(200)
    check('小窗关掉后又能收球', hook.pillIdle() === true && hook.pillState().ball === true, String(hook.pillState().ball))

    // 收着球也能点开（小球仍然是个按钮）
    var ballRect = pillBall.getBoundingClientRect()
    var bx = Math.round(ballRect.left) + 16
    var by = Math.round(ballRect.top) + 16
    pillBall.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window, clientX: bx, clientY: by, button: 0 }))
    window.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window, clientX: bx, clientY: by, button: 0 }))
    pillBall.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window, clientX: bx, clientY: by }))
    await sleep(200)
    check('小球状态点一下照样打开小窗', panelIsOpen() === true, String(panelIsOpen()))
    hook.close()
    await sleep(120)
  }

  // 可选截图模式（?shot=1）：把两个**终态**摆出来（展开=圆点 / 收球=星芒），
  // 真实大小各一份 + 几何各一份放大，给人工核对，也给以后换图标留一张回归图。
  // 用克隆而不是改原胶囊：克隆同样吃到那套 CSS（选择器都是 .dsh-sel-pill[data-ball="1"] …）。
  if (location.search.indexOf('shot=1') >= 0) {
    freezeMotion()
    if (panelIsOpen()) hook.close()
    await sleep(200)
    hook.pillIdle()
    await sleep(400)
    var src = hook.pill()
    var stage = document.createElement('div')
    stage.setAttribute('id', 'shotstage')
    stage.setAttribute('style',
      'position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483600;background:#f4f6f8;' +
      'display:flex;flex-direction:column;gap:22px;align-items:center;justify-content:center;color:#57606a;' +
      'font:12px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif')
    var row1 = document.createElement('div')
    row1.setAttribute('style', 'display:flex;gap:26px;align-items:center')
    /**
     * 造一格：clone 是胶囊的克隆；ball 决定它摆成球还是展开；scale 是放大倍数；
     * dotOnly 时把球态画布里的 d 换成"圆点"那条 —— 用来单独看圆点的几何。
     * 盒子尺寸按**放大后的视觉尺寸**给（球 32×scale），克隆的布局盒仍是被 scale 前的尺寸，
     * 所以放大后的图形会对称溢出布局盒、正好落在盒子里。
     */
    function cell(ball, dotOnly, scale, label) {
      var wrap = document.createElement('div')
      wrap.setAttribute('style', 'display:flex;flex-direction:column;align-items:center;gap:9px')
      var boxW = ball ? Math.round(48 * scale) + 24 : 232
      var boxH = ball ? Math.round(48 * scale) + 24 : 92
      var box = document.createElement('div')
      box.setAttribute('style', 'display:flex;align-items:center;justify-content:center;' +
        'width:' + boxW + 'px;height:' + boxH + 'px;background:#fff;border-radius:14px;' +
        'box-shadow:0 6px 20px rgba(0,0,0,.10)')
      var clone = src.cloneNode(true)
      clone.style.position = 'static'
      clone.style.right = 'auto'
      clone.style.bottom = 'auto'
      clone.style.transition = 'none'
      clone.style.transform = scale === 1 ? 'none' : 'scale(' + scale + ')'
      if (ball) clone.setAttribute('data-ball', '1')
      else clone.removeAttribute('data-ball')
      clone.setAttribute('data-ready', '1')
      var starClone = clone.querySelector('.dsh-sel-pillstar')
      if (starClone) {
        starClone.setAttribute('d', ball && !dotOnly
          ? window.__dshSelectionExplain.pillStarD()
          : window.__dshSelectionExplain.pillStarDotD())
      }
      box.appendChild(clone)
      wrap.appendChild(box)
      var cap = document.createElement('div')
      cap.setAttribute('style', 'max-width:240px;text-align:center;line-height:1.6')
      cap.textContent = label
      wrap.appendChild(cap)
      return wrap
    }
    row1.appendChild(cell(false, false, 1, '展开态（真实大小）：球心里是 8px 圆点'))
    row1.appendChild(cell(true, false, 1, '收球态（真实大小）：8px 圆点长成星芒 16.8px'))
    row1.appendChild(cell(true, true, 4, '圆点 8px（4×）—— 32 边形，半径恒 4'))
    row1.appendChild(cell(true, false, 4, '星芒 16.8px（4×）—— 与「✦ 解读」那颗星逐点同形'))
    stage.appendChild(row1)

    // 下行：形变逐帧（直接用 hook.pillStarAt(p) 画真实轨迹）——
    // 这一条就是"中间帧形状不对"的可视回归图：曾经用 CSS 的 d 过渡做线性插值，
    // 25%~38% 那几帧会是一个正菱形（谷跟着尖一起动），在这里一眼就能看出来。
    var row2 = document.createElement('div')
    row2.setAttribute('style', 'display:flex;gap:9px;align-items:flex-end')
    for (var fi = 0; fi <= 8; fi += 1) {
      var fp = fi / 8
      var fcell = document.createElement('div')
      fcell.setAttribute('style', 'display:flex;flex-direction:column;align-items:center;gap:5px')
      var fclone = src.cloneNode(true)
      fclone.style.position = 'static'
      fclone.style.right = 'auto'
      fclone.style.bottom = 'auto'
      fclone.style.transition = 'none'
      fclone.setAttribute('data-ball', '1')
      fclone.setAttribute('data-ready', '1')
      var fstar = fclone.querySelector('.dsh-sel-pillstar')
      if (fstar) {
        fstar.setAttribute('d', window.__dshSelectionExplain.pillStarAt(fp))
        fstar.style.transform = 'rotate(' + Math.round(8 * (1 - fp) * 100) / 100 + 'deg)'
      }
      fcell.appendChild(fclone)
      var fcap = document.createElement('div')
      fcap.setAttribute('style', 'font-size:10px;color:#8c959f')
      fcap.textContent = Math.round(fp * 100) + '%'
      fcell.appendChild(fcap)
      row2.appendChild(fcell)
    }
    stage.appendChild(row2)
    document.body.appendChild(stage)
    await sleep(400)
  }

  // ⑮ 模型菜单：跟随态也要给"当前在用"那个打勾（真浏览器里量几何 —— 桩里量不出换行/溢出）
  {
    hook.open('模型菜单勾选', '', '菜单冒烟')
    await waitFor(function () { return hook.state().phase === 'done' }, 8000)
    await hook.loadModels(true)
    var modelNodes = hook.modelNodes()
    // DSH 按属性判定弹层，不检查 CSS 可见性（Issue #1）。
    var modalSelector = '[role="dialog"][aria-modal="true"], [role="menu"]'
    function modelMenuOwnsShortcuts() {
      return Array.from(document.querySelectorAll(modalSelector)).includes(modelNodes.menu)
    }
    function checkModelMenuClosed(reason) {
      check(reason + '：模型菜单不再占用 DSH 快捷键',
        !modelMenuOwnsShortcuts() && modelNodes.menu.getAttribute('data-open') !== '1' &&
          modelNodes.pill.getAttribute('aria-expanded') === 'false')
    }
    checkModelMenuClosed('初始收起')
    // 官方 useModalLayer 在 document 冒泡阶段处理 Esc；插件 capture 必须让行。
    function checkHostEscapeFirst(target, label) {
      var hostSettings = document.createElement('div')
      hostSettings.setAttribute('role', 'dialog')
      hostSettings.setAttribute('aria-modal', 'true')
      hostSettings.setAttribute('data-shortcut-modal', 'settings')
      var hostInput = document.createElement('input')
      hostSettings.appendChild(hostInput)
      document.body.appendChild(hostSettings)
      function dismissHost(event) {
        if (event.key !== 'Escape' || event.defaultPrevented) return
        event.preventDefault()
        hostSettings.remove()
      }
      document.addEventListener('keydown', dismissHost)
      try {
        var event = new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true })
        ;(target || hostInput).dispatchEvent(event)
        check(label + '：Esc 到达官方浮层并只关闭官方设置',
          event.defaultPrevented && !hostSettings.isConnected && panel.style.display === 'flex')
      } finally {
        document.removeEventListener('keydown', dismissHost)
        hostSettings.remove()
      }
    }
    var escapeModeFrame = document.createElement('div')
    escapeModeFrame.setAttribute('data-dsh-full-view', '')
    escapeModeFrame.setAttribute('data-dsh-active-floating-window', 'explanation')
    for (var fullViewMode of [false, true]) {
      if (fullViewMode) document.body.appendChild(escapeModeFrame)
      var modeLabel = fullViewMode ? '完整视图' : '普通分栏'
      checkHostEscapeFirst(null, modeLabel + '／焦点在官方设置')
      checkHostEscapeFirst(document.querySelector('.dsh-sel-askbox'), modeLabel + '／焦点仍在解读输入框')
    }
    escapeModeFrame.remove()
    hook.openModel()
    await sleep(120)
    check('模型菜单展开时占用 DSH 快捷键',
      modelMenuOwnsShortcuts() && modelNodes.pill.getAttribute('aria-expanded') === 'true')
    var menu = hook.modelNodes().menu
    var rows = Array.prototype.slice.call(menu.querySelectorAll('.dsh-sel-pickerrow'))
    check('模型菜单列出 3 个模型（含同名 id 的另一 provider）', rows.length === 3, String(rows.length))
    var onRows = rows.filter(function (r) { return r.getAttribute('data-on') === '1' })
    check('跟随态：只有当前在用的那一行打勾',
      onRows.length === 1 && onRows[0].textContent.indexOf('DeepSeek V4.1 Flash') >= 0,
      onRows.map(function (r) { return r.textContent }).join(' | ') || '没有任何一行打勾')
    var badge = onRows[0] && onRows[0].querySelector('.dsh-sel-pickerfollow')
    check('跟随态那一行有「跟随」小标，且小标在菜单里可见（没被挤出边界）',
      !!badge && badge.offsetWidth > 0 && badge.getBoundingClientRect().right <= menu.getBoundingClientRect().right + 1,
      badge ? Math.round(badge.getBoundingClientRect().left) + '→' + Math.round(badge.getBoundingClientRect().right) + '（菜单右边界 ' + Math.round(menu.getBoundingClientRect().right) + '）' : '没有小标')
    var nameSpan = onRows[0] && onRows[0].querySelector('.dsh-sel-pickername')
    check('名字带省略号、不撑破一行（真实布局下 scrollWidth 不超）',
      !!nameSpan && nameSpan.scrollWidth >= nameSpan.clientWidth && onRows[0].scrollWidth <= onRows[0].clientWidth + 1,
      nameSpan ? nameSpan.clientWidth + ' 可见 / ' + nameSpan.scrollWidth + ' 全长；行 ' + onRows[0].clientWidth + '/' + onRows[0].scrollWidth : '没有名字节点')
    // 长名字那行（没打勾、没小标）也不该被撑破
    var longRow = rows.filter(function (r) { return r.textContent.indexOf('Strong Model With A Very Long') >= 0 })[0]
    check('超长名字那一行同样不横向溢出（靠省略号收窄）',
      !!longRow && longRow.scrollWidth <= longRow.clientWidth + 1,
      longRow ? longRow.clientWidth + '/' + longRow.scrollWidth : '没找到那一行')
    var rowBox = onRows[0] ? onRows[0].getBoundingClientRect() : null
    check('打勾那一行仍是单行（高度不超过 30px，没折成两行）',
      !!rowBox && rowBox.height <= 30, rowBox ? Math.round(rowBox.height) + 'px' : '没找到那一行')

    checkHostEscapeFirst(modelNodes.menu, '模型菜单仍展开')
    check('官方设置关闭时保留插件模型菜单', modelNodes.menu.getAttribute('data-open') === '1')

    clickOn(modelNodes.pill)
    checkModelMenuClosed('再次点击胶囊')
    hook.openModel()
    modelNodes.menu.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
    checkModelMenuClosed('按 Esc')
    hook.openModel()
    document.getElementById('docp').dispatchEvent(new MouseEvent('mousedown', { bubbles: true }))
    checkModelMenuClosed('点击菜单外部')
    hook.openModel()
    clickOn(modelNodes.menu.querySelector('.dsh-sel-pickerrow'))
    checkModelMenuClosed('选择模型')
    hook.openModel()
    hook.close() // 关窗会顺手收起模型菜单
    checkModelMenuClosed('关闭解读面板')
    await sleep(30)
  }


  // 内容把面板撑出视口 → 必须自动收回（回复框不能被顶到屏幕外）
  //
  // 真实场景：开窗那一刻"放得下吗"是按当时的高度算的（常常只有一行翻译在流），
  // 之后正文长到 max-height，面板从固定的 top 往下挂 —— 它是 position:fixed、页面不滚，
  // 顶出去那截（回复框）就点不到了。
  //
  // ⚠️ 复核挂在**绘制之后**（内容这时才在 DOM 里）。所以这里灌完内容要再走一次真实绘制，
  // 不能用 askValue 那类只改状态、不重绘的钩子（踩过：断言量到的一直是注入前的旧位置）。
  {
    hook.open('溢出探测', '上下文片段', '冒烟')
    await sleep(140)
    var panelEl3 = document.querySelector('.dsh-sel-panel')
    var bodyEl3 = panelEl3.querySelector('.dsh-sel-body')
    var filler = document.createElement('div')
    filler.style.height = Math.round(window.innerHeight * 0.9) + 'px'
    filler.style.flex = '0 0 auto'
    bodyEl3.appendChild(filler)
    // 再开一次 = 走一遍真实的 showPanel + paint（内容已经在 DOM 里，复核这帧就能看见）
    hook.open('溢出探测', '上下文片段', '冒烟')
    await sleep(180)
    var overRect = panelEl3.getBoundingClientRect()
    check('内容把面板撑出视口时自动收回可视区（回复框不会被顶到屏幕外）',
      overRect.bottom <= window.innerHeight - 2,
      'bottom=' + Math.round(overRect.bottom) + ' vh=' + window.innerHeight)
    filler.remove()
    hook.open('溢出探测', '上下文片段', '冒烟')
    await sleep(80)
    hook.close()
    await sleep(40)
  }

  // ⑫ 卡片 → 小窗的交接（方案二「缩放长出」）：真浏览器里量真矩形 + 真过渡。
  //    桩 DOM 里只能验"写进去的 transform 字符串"，这里补上"浏览器真的从那一格长出来"。
  {
    hook.close()
    await sleep(60)
    var docp4 = document.getElementById('docp')
    selectIn(docp4, 'the migration ran long')
    mouseUpOn(docp4)
    // 让 host 报"豆包在录"：插件轮询到就把卡片弹出来（这是真实的触发路径）
    micState = { ok: true, available: true, capturing: true, processes: [{ pid: 513, bundleId: 'com.bytedance.inputmethod.doubaoime', name: 'DoubaoIme' }], reason: '' }
    var cardEl = await waitFor(function () {
      var el = document.querySelector('.dsh-sel-vcard')
      return el && getComputedStyle(el).display !== 'none' && el.getBoundingClientRect().width > 0 ? el : null
    }, 2500)
    check('（准备）输入法开麦 → 语音卡自己弹出来', !!cardEl, cardEl ? '' : '没等到卡片')
    if (cardEl) {
      check('语音卡自身禁止原生窗口拖拽', getComputedStyle(cardEl).webkitAppRegion === 'no-drag', getComputedStyle(cardEl).webkitAppRegion)
      var marks = Array.from(document.querySelectorAll('.dsh-sel-umark,.dsh-sel-thread'))
      check('全屏选中提示不阻止原生窗口拖拽', marks.length > 0 && marks.every(function (node) { return getComputedStyle(node).webkitAppRegion === 'none' }), marks.map(function (node) { return node.className.baseVal || node.className }).join(', '))
      var vbox = cardEl.querySelector('.dsh-sel-vcard-box')
      var vsend = cardEl.querySelector('.dsh-sel-vcard-send')
      vbox.value = '这是 在推迟 还是提前'
      vbox.dispatchEvent(new Event('input', { bubbles: true }))
      await sleep(60)
      var cardRect = cardEl.getBoundingClientRect()
      var panelEl4 = document.querySelector('.dsh-sel-panel')
      // ⚠️ 不能用"点完下一帧读计算值"来抓起点：这个冒烟页跑在 --virtual-time-budget 下，
      //    虚拟时钟会往前跳，rAF 回来时过渡可能已经跑完了（实测读到 matrix=none）。
      //    改成**记录 style 属性的每一次写入**（MutationObserver 的 attributeOldValue 给的是
      //    写之前的值）—— 于是"起点把面板压到卡片那一格"这件事与时钟无关，直接可读可验。
      var reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches
      var styleWrites = []
      var mo = new MutationObserver(function (records) {
        for (var i = 0; i < records.length; i += 1) styleWrites.push(records[i].oldValue || '')
      })
      mo.observe(panelEl4, { attributes: true, attributeFilter: ['style'], attributeOldValue: true })
      clickOn(vsend)
      // 期望值必须在**同一个任务里**读完：插件也是在这次点击里量的几何
      // （openPanelWith 内层跑完、内容已换新 → 量高度；随后流式回答才会把面板撑高）。
      // 面板的 offset* 是布局值，不受正在跑的 transform 影响。
      var expW = panelEl4.offsetWidth
      var expH = panelEl4.offsetHeight
      var expLeft = panelEl4.offsetLeft
      var expTop = panelEl4.offsetTop
      await sleep(150)
      mo.disconnect()
      var startStyle = null
      for (var wi = 0; wi < styleWrites.length; wi += 1) {
        if (styleWrites[wi].indexOf('transform: translate(') >= 0) startStyle = styleWrites[wi]
      }
      // ⚠️ 页面脚本是**模板字符串**里的：正则里的 \d / \( 会被模板字面量吃掉反斜杠
      //    （写成 [\d.] 到了页面里变成 [d.]，永远匹配不上 —— 实测就是这么红的）。
      //    所以这里只用不带反斜杠的字符类 [0-9.] 取数，并且从 transform 那一段开始取，
      //    免得把 z-index / left / top 上的数字也吃进来。
      var seg = startStyle ? startStyle.slice(startStyle.indexOf('transform: translate(')) : ''
      var nums = seg.match(/-?[0-9.]+/g) || []
      var m = nums.length >= 4 ? [seg.slice(0, 60), nums[0], nums[1], nums[2], nums[3]] : null
      // 期望值：面板的**布局**值（offset*，不受动画影响）与卡片矩形的比值/差值
      var sx = cardRect.width / expW
      var sy = cardRect.height / expH
      var dx = cardRect.left - expLeft
      var dy = cardRect.top - expTop
      check('交接动画遵守系统减少动效偏好',
        reducedMotion ? !startStyle && !panelEl4.style.transition : !!startStyle,
        'reducedMotion=' + reducedMotion + '; style 写入次数=' + styleWrites.length)
      if (!reducedMotion) {
        check('交接起点：面板被压到卡片那一格（缩放 + 位移，量的是真矩形）',
          !!m && Math.abs(Number(m[3]) - sx) < 0.01 && Math.abs(Number(m[4]) - sy) < 0.01 &&
            Math.abs(Number(m[1]) - dx) < 1 && Math.abs(Number(m[2]) - dy) < 1,
          m ? '起点=' + m[0] + ' 期望≈translate(' + dx.toFixed(1) + 'px,' + dy.toFixed(1) + 'px) scale(' + sx.toFixed(4) + ',' + sy.toFixed(4) + ')'
            : '没观察到起点写入；style 写入次数=' + styleWrites.length)
        check('交接期间 transform-origin 在左上角（否则缩放会把面板甩出去）',
          !!startStyle && startStyle.indexOf('transform-origin: 0px 0px') >= 0,
          startStyle ? startStyle.slice(0, 120) : '（没抓到）')
        var sawTransition = styleWrites.some(function (v) { return v.indexOf('transition: transform 260ms cubic-bezier(0.2, 0.8, 0.2, 1)') >= 0 })
        check('交接只动 transform、260ms 同一族曲线（不动 width/left/top）',
          sawTransition || String(panelEl4.style.transition).indexOf('transform 260ms') === 0,
          '写入=' + JSON.stringify(styleWrites.map(function (v) { return (v.match(/transition:[^;]*/) || [''])[0] }).filter(Boolean).slice(0, 2)))
      }
      await sleep(520)
      var settledMatrix = getComputedStyle(panelEl4).transform
      check('交接结束：回到恒等（无 transform）',
        settledMatrix === 'none' || settledMatrix === 'matrix(1, 0, 0, 1, 0, 0)', String(settledMatrix))
      check('交接收尾：内联 transform / transition / transformOrigin 清干净',
        !panelEl4.style.transform && !panelEl4.style.transition && !panelEl4.style.transformOrigin,
        JSON.stringify({ tf: panelEl4.style.transform, tr: panelEl4.style.transition, og: panelEl4.style.transformOrigin }))
      // 收尾：麦克风"松开"，别影响后面的用例
      micState = { ok: true, available: true, capturing: false, processes: [], reason: '' }
      await sleep(80)
      hook.close()
      await sleep(40)
    }
  }

  // ⑬ 小窗开着时开麦 = 点一下「❝ 引用」（2026-10-09 定的行为）。
  //    真浏览器里验的是**接线**：引用浮标亮着才轮到轮询、开麦后引用真的进了引用区、
  //    焦点真的落到小窗输入框（IME 上屏要往那儿落）、而且**不弹语音卡**。
  {
    var recording = { ok: true, available: true, capturing: true, processes: [{ pid: 513, bundleId: 'com.bytedance.inputmethod.doubaoime', name: 'DoubaoIme' }], reason: '' }
    var notRecording = { ok: true, available: true, capturing: false, processes: [], reason: '' }
    micState = notRecording
    hook.close()
    await sleep(60)
    hook.open('引用开麦用例', '开麦引用的上下文片段', '引用开麦')
    await waitFor(function () { return hook.state().phase === 'done' }, 3000)
    var quoteBtn = document.querySelector('.dsh-sel-quotebtn')
    var quotesBox = document.querySelector('.dsh-sel-quotes')
    var vcardEl = document.querySelector('.dsh-sel-vcard')
    var askEl = document.querySelector('.dsh-sel-askbox')

    // ① 没有引用浮标时不轮询（用户定的：探针只跟着浮标活）
    var hitsIdle = window.__micHits || 0
    await sleep(500)
    check('没有引用浮标时不轮询麦克风', (window.__micHits || 0) === hitsIdle, hitsIdle + ' → ' + (window.__micHits || 0))

    // ② 主界面划词 → 引用浮标亮 → 开始问
    var docp5 = document.getElementById('docp')
    selectIn(docp5, 'the migration ran long')
    mouseUpOn(docp5)
    var lit = await waitFor(function () {
      return quoteBtn && quoteBtn.style.display !== 'none' && getComputedStyle(quoteBtn).display !== 'none'
    }, 1500)
    check('（前提）引用浮标亮着', lit === true, quoteBtn ? getComputedStyle(quoteBtn).display : '未找到浮标')
    var hitsFloat = window.__micHits || 0
    await sleep(500)
    check('引用浮标亮着时才问麦克风', (window.__micHits || 0) > hitsFloat, hitsFloat + ' → ' + (window.__micHits || 0))

    // ③ 开麦 → 引用挂进来 + 焦点进小窗输入框 + 不弹语音卡
    var quotesBefore = (hook.quotes() || []).length
    micState = recording
    var quoted = await waitFor(function () { return (hook.quotes() || []).length > quotesBefore }, 2000)
    var got = hook.quotes() || []
    check('开麦 → 选中的那段自动挂进引用', quoted === true && /migration ran long/.test(got[got.length - 1].text), JSON.stringify(got.map(function (q) { return q.text })))
    check('开麦 → 光标进了小窗输入框（输入法上屏的字落在这儿）',
      document.activeElement === askEl, document.activeElement ? (document.activeElement.className || document.activeElement.tagName) : 'null')
    check('开麦 → **不**弹语音卡（面板开着时字直接落进小窗）',
      !vcardEl || getComputedStyle(vcardEl).display === 'none', vcardEl ? getComputedStyle(vcardEl).display : '没有卡片元素')
    await sleep(120)
    check('开麦 → 引用浮标自己收了', quoteBtn.style.display === 'none' || getComputedStyle(quoteBtn).display === 'none', quoteBtn.style.display)
    check('开麦 → 引用区真的画出来了', quotesBox && quotesBox.getAttribute('data-show') === '1', quotesBox ? quotesBox.getAttribute('data-show') : '未找到引用区')

    // ④ 别处正在打字 → 不加引用、不抢焦点（守卫，与语音卡那条完全一致）
    micState = notRecording
    await sleep(400)
    var otherEl = document.getElementById('other')
    otherEl.focus()
    var docp6 = document.getElementById('docp')
    selectIn(docp6, 'the migration ran long')
    mouseUpOn(docp6)
    await waitFor(function () { return quoteBtn && quoteBtn.style.display !== 'none' }, 1200)
    var quotesGuard = (hook.quotes() || []).length
    micState = recording
    await sleep(600)
    check('别处正在打字：不加引用', (hook.quotes() || []).length === quotesGuard, JSON.stringify((hook.quotes() || []).map(function (q) { return q.text })))
    check('别处正在打字：不抢焦点（人家的听写不能被拽进小窗）',
      document.activeElement === otherEl, document.activeElement ? (document.activeElement.id || document.activeElement.className || document.activeElement.tagName) : 'null')

    // 收尾
    micState = notRecording
    if (otherEl) otherEl.blur()
    hook.close()
    await sleep(60)
  }

  // ⑯ 附件：＋ 在工具行最左、「输出偏好」文字已去掉、上传/失败/发送全链路
  {
    hook.open('附件探针', '上下文片段 ABC', '附件冒烟')
    await waitFor(function () { return hook.state().phase === 'done' }, 8000)

    var tools = document.querySelector('.dsh-sel-asktools')
    var addBtn = tools && tools.children[0]
    check('工具行最左是 ＋ 附件键（排在最前面，不是挨着麦克风）',
      !!addBtn && String(addBtn.className).indexOf('dsh-sel-add') >= 0 && tools.children[1] !== addBtn,
      addBtn ? addBtn.className : '未找到')
    // 十字 = 一条 path 里的两段（竖 + 横）；圆底是 CSS 给的（桩环境量不出背景色）
    var addPaths = addBtn ? Array.from(addBtn.querySelectorAll('path')) : []
    var addD = addPaths.map(function (p) { return String(p.getAttribute('d')) }).join(' ')
    check('图标是十字（竖 + 横两段，不是回形针的弧线）',
      addPaths.length === 1 && /M8 3\.4v9\.2/.test(addD) && /M3\.4 8h9\.2/.test(addD),
      addD)

    var prefWrap = document.querySelector('.dsh-sel-pref')
    check('「输出偏好」四个字已从工具行去掉（只剩两格图标）',
      !!prefWrap && prefWrap.textContent.trim() === '' && !document.querySelector('.dsh-sel-preftext'),
      prefWrap ? JSON.stringify(prefWrap.textContent) : '未找到')
    check('去掉文字后语义仍在（title 说明这是什么）',
      !!prefWrap && String(prefWrap.title).indexOf('输出偏好') >= 0, prefWrap ? prefWrap.title : '')

    var attachBox = document.querySelector('.dsh-sel-attach')
    var sendBtn = document.querySelector('.dsh-sel-asksend')
    check('初始没有附件（附件条收着、不占高度）',
      !!attachBox && attachBox.getAttribute('data-show') === '0' && attachBox.children.length === 0,
      attachBox ? attachBox.getAttribute('data-show') + '/' + attachBox.children.length : '未找到')

    // 真造三个 File 塞进 <input type=file>（Chrome 支持直接赋 files）
    // 两张图是为了验"多图时左右切换"——一张不够摆出翻页。
    var fileInput = document.querySelector('.dsh-sel-ask input[type=file]')
    check('有隐藏的文件选择器（图片与文件一起选）',
      !!fileInput && fileInput.multiple === true && !fileInput.getAttribute('accept'),
      fileInput ? 'multiple=' + fileInput.multiple + ' accept=' + fileInput.getAttribute('accept') : '未找到')

    window.__attachHits = []
    var dt = new DataTransfer()
    dt.items.add(new File([new Uint8Array([37, 80, 68, 70])], '季度报表.pdf', { type: 'application/pdf' }))
    dt.items.add(new File([new Uint8Array([137, 80, 78, 71])], '截图.png', { type: 'image/png' }))
    dt.items.add(new File([new Uint8Array([137, 80, 78, 72])], '第二张.png', { type: 'image/png' }))
    fileInput.files = dt.files
    fileInput.dispatchEvent(new Event('change', { bubbles: true }))

    // 新流程（0.13.0）：选中只进内存（status=local），**点发送才真正上传** ——
    // 叉掉的图不该在附件库留垃圾。所以这里断言"还没传"，上传断言挪到点发送那一刻。
    await waitFor(function () { return attachBox.children.length === 3 }, 3000)
    check('三件附件都上了附件条', attachBox.children.length === 3, String(attachBox.children.length))
    check('附件条展开了', attachBox.getAttribute('data-show') === '1', attachBox.getAttribute('data-show'))
    check('图片是缩略图（里面是 img）、文件是文件卡',
      attachBox.children[0].className.indexOf('dsh-sel-fcard') >= 0 &&
        attachBox.children[1].className.indexOf('dsh-sel-thumb') >= 0 &&
        attachBox.children[2].className.indexOf('dsh-sel-thumb') >= 0,
      attachBox.children[0].className + ' / ' + attachBox.children[1].className + ' / ' + attachBox.children[2].className)
    check('选中后先不落盘（三件都还是 local，一个请求都没发）',
      window.__attachHits.length === 0 &&
        ['0', '1', '2'].every(function (i) { return attachBox.children[i].getAttribute('data-state') === 'local' }),
      String(window.__attachHits.length) + ' / ' + ['0', '1', '2'].map(function (i) { return attachBox.children[i].getAttribute('data-state') }).join(','))
    check('没在传时发送键可点（不必等上传）', sendBtn.disabled === false, String(sendBtn.disabled))
    // 名字/大小在 local 阶段就能看（本地 File 自带，不用等上传）
    check('文件卡显示名字与类型·大小',
      attachBox.children[0].textContent.indexOf('季度报表.pdf') >= 0 && /PDF/.test(attachBox.children[0].textContent),
      attachBox.children[0].textContent)

    // ── 图片预览：输入框上方的待发送缩略图，点一下要在**本窗口**里放大 ──
    // 用户报的就是这条：小窗里加的图（还没发的、已经发出去的）都点不开。
    var thumb = attachBox.children[1]
    var thumb2 = attachBox.children[2]
    check('待发送缩略图标成可预览（放大镜光标 + 可 Tab 到）',
      !!thumb && thumb.getAttribute('data-preview') === '1' && thumb.getAttribute('role') === 'button' && thumb.tabIndex === 0 &&
        !!thumb2 && thumb2.getAttribute('data-preview') === '1',
      thumb ? thumb.getAttribute('data-preview') + '/' + thumb.getAttribute('role') + '/' + thumb.tabIndex : '未找到')
    thumb.click()
    await waitFor(function () { return document.querySelector('.dsh-sel-lightbox[data-open="1"]') !== null }, 1500)
    var lightbox = document.querySelector('.dsh-sel-lightbox')
    check('点缩略图打开灯箱（同一扇窗，不是新标签）',
      !!lightbox && lightbox.getAttribute('data-open') === '1',
      lightbox ? lightbox.getAttribute('data-open') : '未找到')
    var lightboxImg = lightbox && lightbox.querySelector('.dsh-sel-lightbox-img')
    check('灯箱里是这张图（上传前用本地 blob 先看，不必等传完）',
      !!lightboxImg && String(lightboxImg.getAttribute('src') || '').indexOf('blob:') === 0,
      lightboxImg ? String(lightboxImg.getAttribute('src')).slice(0, 40) : '未找到')
    check('灯箱显示文件名与关闭提示',
      !!lightbox && lightbox.textContent.indexOf('截图.png') >= 0 && lightbox.textContent.indexOf('Esc') >= 0,
      lightbox ? lightbox.textContent : '')
    var lightboxCount = lightbox.querySelector('.dsh-sel-lightbox-count')
    check('多图时有计数（1 / 2），第一张的「上一张」是灰的',
      !!lightboxCount && lightboxCount.textContent === '1 / 2' &&
        lightbox.querySelector('.dsh-sel-lightbox-nav[data-dir="prev"]').disabled === true &&
        lightbox.querySelector('.dsh-sel-lightbox-nav[data-dir="next"]').disabled === false,
      lightboxCount ? lightboxCount.textContent : '未找到')
    // 右侧按钮 → 第二张；本地 blob 地址必须换掉（不是同一张图重画）
    var firstSrc = lightboxImg.getAttribute('src')
    lightbox.querySelector('.dsh-sel-lightbox-nav[data-dir="next"]').click()
    await waitFor(function () { return lightbox.querySelector('.dsh-sel-lightbox-count').textContent === '2 / 2' }, 1000)
    check('点右箭头切到下一张（名字与 blob 都跟着换）',
      lightbox.querySelector('.dsh-sel-lightbox-name').textContent === '第二张.png' &&
        lightboxImg.getAttribute('src') !== firstSrc,
      lightbox.querySelector('.dsh-sel-lightbox-name').textContent + ' / ' + String(lightboxImg.getAttribute('src')).slice(0, 24))
    check('最后一张的「下一张」是灰的、「上一张」可点',
      lightbox.querySelector('.dsh-sel-lightbox-nav[data-dir="next"]').disabled === true &&
        lightbox.querySelector('.dsh-sel-lightbox-nav[data-dir="prev"]').disabled === false,
      '')
    // ← 键 → 回到第一张（方向键只在多图时接管）
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', bubbles: true, cancelable: true }))
    await waitFor(function () { return lightbox.querySelector('.dsh-sel-lightbox-count').textContent === '1 / 2' }, 1000)
    check('← 键切回上一张',
      lightbox.querySelector('.dsh-sel-lightbox-name').textContent === '截图.png' &&
        lightboxImg.getAttribute('src') === firstSrc,
      lightbox.querySelector('.dsh-sel-lightbox-name').textContent)
    lightbox.click() // 点空白处
    await waitFor(function () {
      var box = document.querySelector('.dsh-sel-lightbox')
      return !box || box.getAttribute('data-open') === '0'
    }, 1500)
    check('点空白处收起灯箱',
      document.querySelector('.dsh-sel-lightbox').getAttribute('data-open') === '0',
      document.querySelector('.dsh-sel-lightbox').getAttribute('data-open'))

    // 发送：附件引用必须进这一轮追问的载荷，而且**不带 base64**
    window.__askBodies = []
    var askBox = document.querySelector('.dsh-sel-askbox')
    askBox.value = '这个报表里哪个季度掉得最多？'
    askBox.dispatchEvent(new Event('input', { bubbles: true }))
    // 拖慢上传，让"上传中"这个中间态可确定性观察
    window.__attachDelay = 120
    sendBtn.click()
    await waitFor(function () { return window.__attachHits.length > 0 }, 3000)
    check('点发送才开始上传（上传中发送键置灰，不让材料没齐就发出去）',
      sendBtn.disabled === true, String(sendBtn.disabled))
    await waitFor(function () { return window.__attachHits.length === 3 }, 4000)
    check('每件各发一次请求（逐件上传，失败不牵连别件）', window.__attachHits.length === 3, String(window.__attachHits.length))
    check('请求里带的是 base64（不带 data: 前缀）',
      window.__attachHits.every(function (hit) { return typeof hit.items[0].data === 'string' && hit.items[0].data.indexOf('data:') !== 0 && hit.items[0].data.length > 0 }),
      window.__attachHits.map(function (hit) { return String(hit.items[0].data).slice(0, 12) }).join(' | '))
    check('图片那件声明了 mediaType（附件服务要拿它跟字节比对）',
      window.__attachHits.some(function (hit) { return hit.items[0].kind === 'image' && hit.items[0].mediaType === 'image/png' }),
      JSON.stringify(window.__attachHits.map(function (hit) { return hit.items[0].mediaType })))
    window.__attachDelay = 0
    await waitFor(function () { return window.__askBodies.length > 0 }, 4000)
    var ask = window.__askBodies[0] || {}
    check('追问载荷带上了三件附件引用',
      Array.isArray(ask.attachments) && ask.attachments.length === 3 && ask.attachments.every(function (a) { return a.ref && a.ref.attachmentId }),
      JSON.stringify(ask.attachments))
    check('载荷里没有 base64（只回传引用）',
      JSON.stringify(ask.attachments).indexOf('data') < 0 && JSON.stringify(ask).length < 2000,
      String(JSON.stringify(ask).length))
    check('附件说明拼进了发给模型的那条消息（历史里也看得到带过附件）',
      String(ask.question).indexOf('【本条消息带了附件】') >= 0 && String(ask.question).indexOf('季度报表.pdf') >= 0,
      String(ask.question).slice(0, 120))
    await waitFor(function () { return attachBox.children.length === 0 }, 2000)
    check('发送后附件条清空（附件属于这一条消息，不属于会话）',
      attachBox.children.length === 0 && attachBox.getAttribute('data-show') === '0',
      String(attachBox.children.length))

    // 气泡里要看得见附件 —— 用户报的就是这条："图片在消息窗口并没有显示"。
    // 注意图片是走**回放路由**取的（本地 object URL 在发送那一刻就释放了）。
    await waitFor(function () { return document.querySelector('.dsh-sel-bqattach') !== null }, 2000)
    var strip = document.querySelector('.dsh-sel-bqattach')
    check('发出去的消息气泡里有附件条', !!strip && strip.children.length === 3, strip ? String(strip.children.length) : '未找到')
    var bqImg = document.querySelector('.dsh-sel-bqimg')
    // 注意 img.src 拿到的是**绝对** URL（浏览器解析过），所以用 includes 而不是 startsWith
    check('图片渲染成缩略图，且指向回放路由（不是本地 blob —— 那个地址发送时就释放了）',
      !!bqImg && String(bqImg.getAttribute('src')).includes('/selection-explain/api/attachment') &&
        String(bqImg.getAttribute('src')).includes('kind=image') && String(bqImg.getAttribute('src')).indexOf('blob:') !== 0,
      bqImg ? String(bqImg.getAttribute('src')).slice(0, 90) : '未找到')
    check('缩略图是懒加载；外层仍是链接（⌘/中键 / 右键还能走新标签）',
      !!bqImg && bqImg.getAttribute('loading') === 'lazy' && bqImg.parentNode.tagName === 'A' && bqImg.parentNode.target === '_blank', '')
    // 真去取一次字节：naturalWidth > 0 = 图**解码成功**（只看 src 证明不了它真能显示）
    await waitFor(function () { return bqImg && bqImg.complete && bqImg.naturalWidth > 0 }, 3000)
    check('缩略图真的从回放路由取到并解码了（不是破图）',
      !!bqImg && bqImg.naturalWidth > 0, bqImg ? bqImg.naturalWidth + 'x' + bqImg.naturalHeight : '未找到')
    // 量比例：源图很宽（810x180），被 max-width 压下来时必须**等比** —— 变形了就是 CSS 写错
    var bqRect = bqImg.getBoundingClientRect()
    var naturalRatio = bqImg.naturalWidth / bqImg.naturalHeight
    var shownRatio = bqRect.width / Math.max(1, bqRect.height)
    check('缩略图等比缩放、没被压变形',
      Math.abs(shownRatio - naturalRatio) / naturalRatio < 0.06,
      '显示 ' + Math.round(bqRect.width) + 'x' + Math.round(bqRect.height) + ' (' + shownRatio.toFixed(2) + ':1) vs 原始 ' + naturalRatio.toFixed(2) + ':1')
    check('缩略图高度不超过 180px（不许把气泡撑爆）', bqRect.height <= 181, Math.round(bqRect.height) + 'px')

    // ── 已发出的图片：普通左键同样在本窗口预览（不是新标签）──
    bqImg.click()
    await waitFor(function () { return document.querySelector('.dsh-sel-lightbox[data-open="1"]') !== null }, 1500)
    var sentLightbox = document.querySelector('.dsh-sel-lightbox')
    var sentLightboxImg = sentLightbox && sentLightbox.querySelector('.dsh-sel-lightbox-img')
    check('点气泡里的图片也打开灯箱',
      !!sentLightbox && sentLightbox.getAttribute('data-open') === '1',
      sentLightbox ? sentLightbox.getAttribute('data-open') : '未找到')
    check('灯箱取的是回放路由那张图（不是气泡里的缩略尺寸）',
      !!sentLightboxImg && String(sentLightboxImg.getAttribute('src')).includes('/selection-explain/api/attachment') &&
        String(sentLightboxImg.getAttribute('src')).includes('kind=image'),
      sentLightboxImg ? String(sentLightboxImg.getAttribute('src')).slice(0, 90) : '未找到')
    check('灯箱打开时声明为模态浮层（读屏与 Esc 层级都用它）',
      sentLightbox.getAttribute('aria-modal') === 'true',
      sentLightbox.getAttribute('aria-modal'))
    // 会话里的两张图也要能左右翻（这轮消息里就有两张）
    var sentCount = sentLightbox.querySelector('.dsh-sel-lightbox-count')
    check('会话里多张图时带翻页计数（1 / 2）',
      !!sentCount && sentCount.textContent === '1 / 2',
      sentCount ? sentCount.textContent : '未找到')
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, cancelable: true }))
    await waitFor(function () { return sentLightbox.querySelector('.dsh-sel-lightbox-count').textContent === '2 / 2' }, 1000)
    check('→ 键切到会话里的下一张',
      sentLightbox.querySelector('.dsh-sel-lightbox-count').textContent === '2 / 2',
      sentLightbox.querySelector('.dsh-sel-lightbox-count').textContent)
    // 到头不循环：再按一次仍是最后一张（不会莫名跳回第一张）
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, cancelable: true }))
    await sleep(80)
    check('最后一张再按 → 不循环回第一张',
      sentLightbox.querySelector('.dsh-sel-lightbox-count').textContent === '2 / 2',
      sentLightbox.querySelector('.dsh-sel-lightbox-count').textContent)
    // Esc 只退最内层：灯箱关掉，小窗必须还在
    var escLightbox = new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true })
    document.dispatchEvent(escLightbox)
    await waitFor(function () { return document.querySelector('.dsh-sel-lightbox').getAttribute('data-open') === '0' }, 1500)
    check('Esc 只关灯箱，不会顺手把小窗也关了',
      document.querySelector('.dsh-sel-lightbox').getAttribute('data-open') === '0' &&
        getComputedStyle(document.querySelector('.dsh-sel-panel')).display !== 'none',
      'lightbox=' + document.querySelector('.dsh-sel-lightbox').getAttribute('data-open') +
        ' panel=' + getComputedStyle(document.querySelector('.dsh-sel-panel')).display +
        ' prevented=' + escLightbox.defaultPrevented)
    // 关着的灯箱不能继续以 aria-modal 出现：宿主的 Esc 是"有官方模态就让它先退"，
    // 留一个隐藏的 aria-modal 会让小窗从此关不掉（点 ✕ 之外所有 Esc 都被吞）。
    check('灯箱关掉后不再占着"模态浮层"这个身份',
      document.querySelector('[role="dialog"][aria-modal="true"]') === null,
      String(document.querySelector('[role="dialog"][aria-modal="true"]')))

    // 点第二张图 → 应该从第 2 张开始（下标跟着点击的那张走）；✕ 也能关
    var bqImgs = document.querySelectorAll('.dsh-sel-bqimg')
    if (bqImgs[1]) bqImgs[1].click()
    await waitFor(function () { return document.querySelector('.dsh-sel-lightbox[data-open="1"]') !== null }, 1500)
    check('点第二张图打开时直接停在第 2 张（不总是从第一张开始）',
      document.querySelector('.dsh-sel-lightbox-count').textContent === '2 / 2',
      document.querySelector('.dsh-sel-lightbox-count').textContent)
    document.querySelector('.dsh-sel-lightbox-x').click()
    await waitFor(function () { return document.querySelector('.dsh-sel-lightbox').getAttribute('data-open') === '0' }, 1500)
    check('右上角 ✕ 也能关掉灯箱',
      document.querySelector('.dsh-sel-lightbox').getAttribute('data-open') === '0',
      document.querySelector('.dsh-sel-lightbox').getAttribute('data-open'))

    var bqFile = document.querySelector('.dsh-sel-bqfile')
    check('文件渲染成一张可下载的卡（扩展名 + 名字 + 大小）',
      !!bqFile && /PDF/.test(bqFile.textContent) && /季度报表\.pdf/.test(bqFile.textContent) && /B/.test(bqFile.textContent) && String(bqFile.getAttribute('href')).indexOf('download=1') > 0,
      bqFile ? bqFile.textContent : '未找到')
    check('气泡正文里不再重复那行「本条消息带了附件」',
      String(document.querySelector('.dsh-sel-bubble-user').textContent).indexOf('本条消息带了附件') < 0,
      String(document.querySelector('.dsh-sel-bubble-user').textContent).slice(0, 80))

    // 跨轮次：第二轮必须把**上一轮**的附件引用随历史回传。
    // 这就是"附件持久化"在客户端这一侧的终点 —— 没有这一条，模型下一轮就看不见那张图了。
    await waitFor(function () { return hook.state().asking !== true }, 4000)
    window.__askBodies = []
    askBox.value = '那第二列呢？'
    askBox.dispatchEvent(new Event('input', { bubbles: true }))
    sendBtn.click()
    await waitFor(function () { return window.__askBodies.length > 0 }, 3000)
    var secondAsk = window.__askBodies[0] || {}
    var carried = (secondAsk.history || []).filter(function (turn) { return turn.attachments && turn.attachments.length > 0 })
    check('第二轮把上一轮的附件引用带进了历史（跨轮次仍看得见那张图）',
      carried.length === 1 && carried[0].attachments.length === 3,
      JSON.stringify(secondAsk.history || []).slice(0, 220))
    check('历史里的附件只有引用、没有 base64',
      JSON.stringify(secondAsk.history || []).indexOf('data:') < 0 && JSON.stringify(secondAsk.history || []).length < 3000,
      String(JSON.stringify(secondAsk.history || []).length))
    await waitFor(function () { return hook.state().asking !== true }, 4000)

    // 失败 → 就地重试。注意新流程：选中不传，失败发生在**点发送**那一刻。
    window.__attachFail = '坏图.bmp'
    var dt2 = new DataTransfer()
    dt2.items.add(new File([new Uint8Array([1, 2, 3])], '坏图.bmp', { type: 'image/bmp' }))
    fileInput.files = dt2.files
    fileInput.dispatchEvent(new Event('change', { bubbles: true }))
    check('还没发送时失败件仍是 local（没上传就不会有错）',
      attachBox.children.length === 1 && attachBox.children[0].getAttribute('data-state') === 'local',
      attachBox.children[0] ? attachBox.children[0].getAttribute('data-state') : '未找到')
    askBox.value = '这张图里是什么？'
    askBox.dispatchEvent(new Event('input', { bubbles: true }))
    sendBtn.click()
    await waitFor(function () { return attachBox.children.length === 1 && attachBox.children[0].getAttribute('data-state') === 'error' }, 3000)
    check('被拒的附件标成错误态（不是静默丢掉）',
      attachBox.children.length === 1 && attachBox.children[0].getAttribute('data-state') === 'error',
      attachBox.children[0] ? attachBox.children[0].getAttribute('data-state') : '未找到')
    var note = document.querySelector('.dsh-sel-attachnote')
    check('错误原因写在附件条下面（把错误码翻成人话）',
      !!note && note.getAttribute('data-show') === '1' && /图片格式/.test(note.textContent), note ? note.textContent : '')
    check('错误态有移除键（用户可以删掉这件）', !!attachBox.children[0].querySelector('.dsh-sel-attachx'), '')

    // 重试成功
    window.__attachFail = null
    var retryBtn = attachBox.children[0].querySelector('.dsh-sel-attachx')
    retryBtn.click()
    await waitFor(function () { return attachBox.children[0].getAttribute('data-state') === 'done' }, 3000)
    check('点重试后就地成功（不用重新选文件）',
      attachBox.children[0].getAttribute('data-state') === 'done',
      attachBox.children[0].getAttribute('data-state'))

    // 移除
    var removeBtn = attachBox.children[0].querySelector('.dsh-sel-attachx')
    removeBtn.click()
    await waitFor(function () { return attachBox.children.length === 0 }, 2000)
    check('点 ✕ 移除该件', attachBox.children.length === 0, String(attachBox.children.length))

    // ── 拖放的路由：拖到小窗上，**不能**同时落进主会话的输入框 ──
    //
    // 主会话的投放监听是 document 级、冒泡阶段，而且**不看 defaultPrevented** ——
    // 所以只 preventDefault 拦不住它。这里在 document 上装一个同样的监听当"主会话"，
    // 看它收不收得到事件。（这一段放在场景最后：它会往附件条里加东西，
    // 放前面会把后面"失败→重试→移除"那几条的状态搅乱。）
    var mainDrops = []
    var mainEnters = []
    function mainDropProbe(event) { mainDrops.push(String(event.target.className || event.target.tagName)) }
    function mainEnterProbe(event) { mainEnters.push(String(event.target.className || event.target.tagName)) }
    document.addEventListener('drop', mainDropProbe)
    document.addEventListener('dragenter', mainEnterProbe)
    try {
      function fileDrag() {
        var box = new DataTransfer()
        box.items.add(new File([new Uint8Array([1, 2, 3])], '拖进来的.txt', { type: 'text/plain' }))
        return box
      }
      var dragOpts = function (transfer) { return { dataTransfer: transfer, bubbles: true, cancelable: true } }
      var asked = document.querySelector('.dsh-sel-askbox')

      // ① 拖进来（还没松手）：遮罩亮、且主会话不该被点亮
      var transfer = fileDrag()
      asked.dispatchEvent(new DragEvent('dragenter', dragOpts(transfer)))
      asked.dispatchEvent(new DragEvent('dragover', dragOpts(transfer)))
      check('拖到小窗上：小窗自己铺了投放遮罩',
        document.querySelector('.dsh-sel-panel').getAttribute('data-dropping') === '1',
        String(document.querySelector('.dsh-sel-panel').getAttribute('data-dropping')))
      check('拖到小窗上：主会话的拖入监听也收不到（全视口遮罩不会在小窗上方点亮）',
        mainEnters.length === 0, JSON.stringify(mainEnters))

      // ② 松手：文件只进小窗
      var before = attachBox.children.length
      asked.dispatchEvent(new DragEvent('drop', dragOpts(transfer)))
      await waitFor(function () { return attachBox.children.length > before }, 2000)
      check('松手：文件进了小窗的附件条', attachBox.children.length === before + 1, String(attachBox.children.length))
      check('松手：document 级（=主会话）的投放监听**收不到** —— 不会同时落进主会话',
        mainDrops.length === 0, JSON.stringify(mainDrops))
      check('松手后投放遮罩收起',
        document.querySelector('.dsh-sel-panel').getAttribute('data-dropping') === null,
        String(document.querySelector('.dsh-sel-panel').getAttribute('data-dropping')))

      // ③ 反向对照：拖到小窗**外面**，主会话照常收到（小窗不是全局拦截器）
      var outside = fileDrag()
      var doc = document.getElementById('doc')
      doc.dispatchEvent(new DragEvent('dragenter', dragOpts(outside)))
      doc.dispatchEvent(new DragEvent('drop', dragOpts(outside)))
      check('拖到小窗外面：主会话照常收到（没有把小窗变成全局拦截器）', mainDrops.length === 1, JSON.stringify(mainDrops))

      // ④ 拖一段**文字**：小窗完全不插手（它没有"接文字"这回事），仍归主会话
      var textDrag = new DataTransfer()
      textDrag.setData('text/plain', '一段被拖动的文字')
      mainDrops.length = 0
      asked.dispatchEvent(new DragEvent('drop', dragOpts(textDrag)))
      check('拖的是文字（不是文件）时小窗不插手 —— 仍归主会话', mainDrops.length === 1, JSON.stringify(mainDrops))

      // 收尾：把拖进来的那件移掉，别留给下一个场景
      var dragged = attachBox.children[attachBox.children.length - 1]
      var dragRemove = dragged && dragged.querySelector('.dsh-sel-attachx')
      if (dragRemove) dragRemove.click()
      await waitFor(function () { return attachBox.children.length === 0 }, 2000)
    } finally {
      document.removeEventListener('drop', mainDropProbe)
      document.removeEventListener('dragenter', mainEnterProbe)
    }


    hook.close()
    await sleep(60)
  }

  // Long conversations keep their data while rendering a bounded, expandable window.
  {
    fixture.history = { key: 'browser-memory' + String.fromCharCode(0) + 'context', text: 'browser-memory', context: 'context', label: 'Memory',
      parts: { translation: 'kept translation', detail: '' },
      turns: Array.from({ length: 100 }, function (_, i) { return { role: i % 2 ? 'assistant' : 'user', text: 'browser-memory-' + i } }) }
    fixture.history.turns[99].text = String.fromCharCode(96).repeat(3) + 'html' + String.fromCharCode(10) + '<!doctype html><html><body style="margin:0"><div style="height:2200px">memory preview</div></body></html>' + String.fromCharCode(10) + String.fromCharCode(96).repeat(3)
    hook.forget()
    hook.open('browser-memory', 'context', 'Memory')
    await waitFor(function () { return hook.turns().length === 100 }, 3000)
    var memoryLog = document.querySelector('.dsh-sel-chatlog')
    check('长对话只渲染最近 40 条，完整对话仍有 100 条', memoryLog.querySelectorAll('.dsh-sel-bubble').length === 40 && hook.turns().length === 100)
    var moreHistory = memoryLog.querySelector('[data-history-more]')
    var tallPreview = memoryLog.querySelector('iframe')
    // Chrome's virtual clock does not wait for scripts in a sandboxed iframe.
    // Exercise the real height-message handler with an already measured tall page.
    window.dispatchEvent(new MessageEvent('message', { source: tallPreview.contentWindow,
      data: { __dshPreview: true, id: tallPreview.getAttribute('data-preview-id'), h: 2200 } }))
    var firstVisible = memoryLog.querySelector('.dsh-sel-bubble')
    var scrollBody = document.querySelector('.dsh-sel-body')
    scrollBody.scrollTop = firstVisible.offsetTop
    var anchorTop = firstVisible.getBoundingClientRect().top
    moreHistory.click()
    var anchorAfter = Array.from(memoryLog.querySelectorAll('.dsh-sel-bubble')).find(function (node) { return node.textContent.indexOf('browser-memory-60') >= 0 })
    check('展开旧消息增加到 80 条并保持原消息阅读位置', memoryLog.querySelectorAll('.dsh-sel-bubble').length === 80 && Math.abs(anchorAfter.getBoundingClientRect().top - anchorTop) < 4)
    check('当前网页回答仍可预览', memoryLog.querySelectorAll('iframe').length === 1)
    check('展开旧消息保留已加载的网页帧和高度', memoryLog.querySelector('iframe') === tallPreview && parseFloat(tallPreview.style.height) >= 2200, JSON.stringify({same: memoryLog.querySelector('iframe') === tallPreview, height: tallPreview.style.height}))
    hook.close()
    check('关闭小窗释放网页帧和气泡，保留完整文字', panel.querySelectorAll('iframe').length === 0 && memoryLog.children.length === 0 && hook.turns().length === 100 && hook.memory().previewFrames === 0)
    hook.pill().click()
    await sleep(30)
    check('重开小窗恢复最近气泡及网页预览', memoryLog.querySelectorAll('.dsh-sel-bubble').length === 40 && memoryLog.querySelectorAll('iframe').length === 1)
    hook.close()
    fixture.history = null
  }

  // 可选截图模式（?shot=attach）：把"小窗 composer 带附件"的**真实渲染**摆出来。
  // 用服务端的一张真 PNG（/thumb.png）当被选中的图片 —— 假字节画不出缩略图，
  // 截出来会是一张破图，那就没法核对了。
  if (location.search.indexOf('shot=attach') >= 0 || location.search.indexOf('shot=drop') >= 0 || location.search.indexOf('shot=bubble') >= 0 || location.search.indexOf('shot=preview') >= 0) {
    freezeMotion()
    if (panelIsOpen()) hook.close()
    await sleep(150)
    hook.open('小窗支持添加图片或文件', '上下文片段 ABC', '截图')
    await waitFor(function () { return hook.state().phase === 'done' }, 8000)
    var shotInput = document.querySelector('.dsh-sel-ask input[type=file]')
    var shotBox = document.querySelector('.dsh-sel-attach')
    window.__attachFail = null
    var pngBytes = new Uint8Array(await (await fetch('/thumb.png')).arrayBuffer())
    var png2Bytes = new Uint8Array(await (await fetch('/thumb2.png')).arrayBuffer())
    var shotDt = new DataTransfer()
    shotDt.items.add(new File([new Uint8Array([37, 80, 68, 70, 45, 49, 46, 52])], '季度报表.pdf', { type: 'application/pdf' }))
    shotDt.items.add(new File([pngBytes], '截图.png', { type: 'image/png' }))
    shotDt.items.add(new File([png2Bytes], '第二张.png', { type: 'image/png' }))
    shotDt.items.add(new File([new Uint8Array([123, 34, 97, 34, 58, 49, 125])], 'config.json', { type: 'application/json' }))
    shotInput.files = shotDt.files
    shotInput.dispatchEvent(new Event('change', { bubbles: true }))
    await waitFor(function () {
      return shotBox.children.length === 4 && Array.prototype.every.call(shotBox.children, function (c) { return c.getAttribute('data-state') === 'done' })
    }, 6000)
    document.querySelector('.dsh-sel-askbox').value = '这个报表里哪个季度掉得最多？'
    // 让面板落在窗口里、别贴着边缘（截图好看一点，也不影响任何判定）
    var shotPanel = document.querySelector('.dsh-sel-panel')
    if (shotPanel) { shotPanel.style.left = '24px'; shotPanel.style.top = '18px' }
    // ?shot=bubble / ?shot=drop / ?shot=preview 都先发一条带附件的消息，好让气泡里有东西可看
    if (location.search.indexOf('shot=bubble') >= 0 || location.search.indexOf('shot=preview') >= 0) {
      var shotAsk = document.querySelector('.dsh-sel-askbox')
      shotAsk.value = '这个图片上是什么呀？'
      shotAsk.dispatchEvent(new Event('input', { bubbles: true }))
      document.querySelector('.dsh-sel-asksend').click()
      await waitFor(function () { return document.querySelector('.dsh-sel-bqimg') !== null }, 8000)
      await sleep(400)
    }
    // ?shot=preview：把灯箱打开 —— 这是"点一下预览"那张真实渲染。
    // 点第二张：截图里能看到计数 2 / 2 与两侧翻页键（第一张时"上一张"是灰的，信息少一半）。
    if (location.search.indexOf('shot=preview') >= 0) {
      var shotBqImgs = document.querySelectorAll('.dsh-sel-bqimg')
      var shotBqImg = shotBqImgs[1] || shotBqImgs[0]
      if (shotBqImg) shotBqImg.click()
      await waitFor(function () { return document.querySelector('.dsh-sel-lightbox[data-open="1"]') !== null }, 3000)
      await sleep(400)
    }
    // ?shot=drop：额外把拖放遮罩点亮（那层只有拖拽时才出现，不摆出来就永远没被看过）
    if (location.search.indexOf('shot=drop') >= 0 && shotPanel) shotPanel.setAttribute('data-dropping', '1')
    await sleep(300)
  }

  if (location.search.indexOf('shot=') < 0) {
    hook.open('unload-memory-probe', '', 'Memory')
    await waitFor(function () { return hook.state().phase === 'done' }, 3000)
    var unloadInput = document.querySelector('.dsh-sel-ask input[type=file]')
    var unloadData = new DataTransfer()
    unloadData.items.add(new File([await (await fetch('/thumb.png')).arrayBuffer()], 'draft.png', { type: 'image/png' }))
    unloadInput.files = unloadData.files
    unloadInput.dispatchEvent(new Event('change', { bubbles: true }))
    await waitFor(function () { return document.querySelector('.dsh-sel-attach [data-state=done]') }, 3000)
    var draftImage = document.querySelector('.dsh-sel-attach img')
    var draftUrl = draftImage && draftImage.src
    var revoked = []
    var originalRevoke = URL.revokeObjectURL.bind(URL)
    URL.revokeObjectURL = function (url) { revoked.push(url); originalRevoke(url) }
    disposers.reverse().forEach(function (dispose) { dispose() })
    check('卸载时回收未发送附件的本地图片 URL', !!draftUrl && revoked.indexOf(draftUrl) >= 0)
    check('卸载后缓存、计时器和网页帧登记清空', Object.values(hook.memory()).every(function (value) { return value === 0 }))
    URL.revokeObjectURL = originalRevoke
  }
  finish()
}

main().catch(function (error) {
  check('冒烟脚本自身没抛错', false, (error && error.message) || String(error))

  finish()
})
</script>
</body></html>`

const server = createServer((req, res) => {
  const url = (req.url || '/').split('?')[0]
  if (url === '/client.js') {
    res.writeHead(200, { 'content-type': 'application/javascript; charset=utf-8' })
    res.end(readFileSync(BUNDLE))
    return
  }
  // 回放路由：<img src> 是**浏览器自己**发起的资源请求，走不到 window.fetch 的桩，
  // 所以必须在真服务器上有一条。用真 PNG 回，缩略图才画得出来（假字节 = 破图）。
  if (url === '/selection-explain/api/attachment') {
    // 回放路由按引用里的文件名给不同的真图：多图预览截图里才看得出"确实换了张图"。
    var refName = ''
    try {
      var raw = new URL(req.url, 'http://x').searchParams.get('ref') || ''
      refName = JSON.parse(Buffer.from(raw.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')).name || ''
    } catch (error) {
      refName = ''
    }
    res.writeHead(200, { 'content-type': 'image/png', 'cache-control': 'no-store' })
    res.end(readFileSync(resolve(ROOT, 'assets', refName === '第二张.png' ? 'translation.png' : 'voice.png')))
    return
  }
  // ?shot=attach 用的真图片：缩略图要能画出东西，截出来才可核对
  if (url === '/thumb.png') {
    res.writeHead(200, { 'content-type': 'image/png' })
    res.end(readFileSync(resolve(ROOT, 'assets', 'voice.png')))
    return
  }
  // 第二张用一张别的真图：多图预览截图里能看出"确实换了一张"，不是同一张重画
  if (url === '/thumb2.png') {
    res.writeHead(200, { 'content-type': 'image/png' })
    res.end(readFileSync(resolve(ROOT, 'assets', 'translation.png')))
    return
  }
  if (url === '/' || url === '/smoke.html') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
    res.end(PAGE)
    return
  }
  res.writeHead(404, { 'content-type': 'text/plain' })
  res.end('not found')
})

await new Promise((done) => server.listen(0, '127.0.0.1', done))
const port = server.address().port

function parseDump(dump) {
  const matched = /<pre id="out">([\s\S]*?)<\/pre>/.exec(dump || '')
  if (!matched) return null
  const text = matched[1]
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
  try {
    return JSON.parse(text)
  } catch (error) {
    return null
  }
}

let results = null
let dump = ''
try {
  for (let attempt = 1; attempt <= 2 && !results; attempt += 1) {
    const out = await new Promise((done) => {
      execFile(
        chrome,
        [
          '--headless',
          '--disable-gpu',
          '--no-first-run',
          '--no-default-browser-check',
          '--window-size=1200,900',
          '--virtual-time-budget=25000',
          '--dump-dom',
          `http://127.0.0.1:${port}/smoke.html`,
        ],
        { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024, timeout: 90000 },
        (error, stdout) => done(stdout || ''),
      )
    })
    dump = out
    results = parseDump(dump)
  }

  // 截图（可选，失败不影响判定）：把两个终态并排拍一张 —— 换图标时人工核对用。
  // 走同一个页面，加 ?shot=1 让页面在跑完检查后把"展开态 / 收球态"克隆出来并排摆好。
  try {
    const shotDir = resolve(ROOT, 'docs')
    if (!existsSync(shotDir)) mkdirSync(shotDir, { recursive: true })
    const shotPath = resolve(shotDir, 'pill-star-states.png')
    await new Promise((done) => {
      execFile(
        chrome,
        [
          '--headless',
          '--disable-gpu',
          '--no-first-run',
          '--no-default-browser-check',
          '--window-size=1180,560',
          '--virtual-time-budget=20000',
          `--screenshot=${shotPath}`,
          `http://127.0.0.1:${port}/smoke.html?shot=1`,
        ],
        { encoding: 'utf8', timeout: 90000 },
        () => done(),
      )
    })
    console.log(`=== 截图（圆点 / 星芒 两个终态）：${shotPath} ===`)
  } catch (error) {
    console.log('（截图跳过：' + ((error && error.message) || String(error)) + '）')
  }

  // 截图（可选）：小窗 composer 带附件时的**真样子**（不是设计稿）。
  // ?shot=attach 会让页面开窗 + 挂两件附件（一张真图 + 一个文件）后停住。
  try {
    const shotDir = resolve(ROOT, 'docs')
    if (!existsSync(shotDir)) mkdirSync(shotDir, { recursive: true })
    const shotPath = resolve(shotDir, 'attach-composer-real.png')
    await new Promise((done) => {
      execFile(
        chrome,
        [
          '--headless',
          '--disable-gpu',
          '--no-first-run',
          '--no-default-browser-check',
          '--window-size=760,560',
          '--virtual-time-budget=25000',
          `--screenshot=${shotPath}`,
          `http://127.0.0.1:${port}/smoke.html?shot=attach`,
        ],
        { encoding: 'utf8', timeout: 90000 },
        () => done(),
      )
    })
    console.log(`=== 截图（小窗 composer 带附件 · 真实渲染）：${shotPath} ===`)
  } catch (error) {
    console.log('（附件截图跳过：' + ((error && error.message) || String(error)) + '）')
  }

  // 截图（可选）：发出去的那条消息 —— 气泡里的缩略图与文件卡
  try {
    const shotPath = resolve(ROOT, 'docs', 'attach-bubble-real.png')
    await new Promise((done) => {
      execFile(
        chrome,
        ['--headless', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--window-size=760,620', '--virtual-time-budget=25000', `--screenshot=${shotPath}`, `http://127.0.0.1:${port}/smoke.html?shot=bubble`],
        { encoding: 'utf8', timeout: 90000 },
        () => done(),
      )
    })
    console.log(`=== 截图（消息气泡里的附件 · 真实渲染）：${shotPath} ===`)
  } catch (error) {
    console.log('（气泡截图跳过：' + ((error && error.message) || String(error)) + '）')
  }

  // 截图（可选）：图片预览灯箱（点气泡里的缩略图之后）
  try {
    const shotPath = resolve(ROOT, 'docs', 'attach-preview-real.png')
    await new Promise((done) => {
      execFile(
        chrome,
        ['--headless', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--window-size=900,680', '--virtual-time-budget=25000', `--screenshot=${shotPath}`, `http://127.0.0.1:${port}/smoke.html?shot=preview`],
        { encoding: 'utf8', timeout: 90000 },
        () => done(),
      )
    })
    console.log(`=== 截图（图片预览灯箱 · 真实渲染）：${shotPath} ===`)
  } catch (error) {
    console.log('（预览截图跳过：' + ((error && error.message) || String(error)) + '）')
  }

  // 截图（可选）：拖放遮罩（拖文件到小窗上时铺的那一层）
  try {
    const shotPath = resolve(ROOT, 'docs', 'attach-drop-real.png')
    await new Promise((done) => {
      execFile(
        chrome,
        [
          '--headless',
          '--disable-gpu',
          '--no-first-run',
          '--no-default-browser-check',
          '--window-size=760,560',
          '--virtual-time-budget=25000',
          `--screenshot=${shotPath}`,
          `http://127.0.0.1:${port}/smoke.html?shot=drop`,
        ],
        { encoding: 'utf8', timeout: 90000 },
        () => done(),
      )
    })
    console.log(`=== 截图（拖放遮罩 · 真实渲染）：${shotPath} ===`)
  } catch (error) {
    console.log('（遮罩截图跳过：' + ((error && error.message) || String(error)) + '）')
  }
} finally {
  if (typeof server.closeAllConnections === 'function') server.closeAllConnections()
  server.close()
}

let failed = 0
if (!results) {
  // 与 voice / bridge 冒烟同一套规矩：**Chrome 根本没跑起来**（容器缺 dbus/显示、
  // 或有别的浏览器占着）不是面板的错，按 SKIP 处理；真跑起来了却没有结果仍然判失败。
  if (!dump.trim() && process.env.REQUIRE_BROWSER !== '1' && process.env.SEL_ONLINE !== '1') {
    console.log('SKIP  Chrome 没起来（没拿到任何页面输出）—— 面板冒烟本次不跑')
    process.exit(0)
  }
  console.log('FAIL  浏览器里没拿到结果（<pre id="out">）')
  console.log(dump.slice(0, 400))
  failed += 1
} else {
  for (const item of results) {
    console.log(`${item.ok ? 'PASS' : 'FAIL'}  ${item.name}${item.extra ? ' — ' + item.extra : ''}`)
    if (!item.ok) failed += 1
  }
}
console.log(`\n=== 小窗面板冒烟结束：${results ? results.length - failed : 0} 通过 / ${failed} 失败 ===`)
process.exit(failed === 0 ? 0 : 1)
