# 项目架构

划词解读由 DSH 宿主服务、浏览器界面和 macOS 原生探针组成。

## 目录与职责

| 路径 | 职责 |
| --- | --- |
| `src/index.ts` | 公共插件入口和兼容导出 |
| `src/host/plugin.ts` | 创建服务、注册 HTTP 路由和生命周期清理 |
| `src/host/models.ts`、`sessions.ts` | 模型选择、推理能力清单、会话模型与背景缓存 |
| `src/host/settings-store.ts`、`history-store.ts` | 设置覆盖、历史条目和界面位置/尺寸的持久化 |
| `src/host/analyze.ts`、`analyze-*.ts` | 解读请求调度，以及请求归一化、消息与工具准备、流式执行、重试和补结论 |
| `src/host/shot.ts`、`shot-service.ts`、`shot-capture.ts`、`shot-platform.ts`、`shot-geometry.ts` | 截图 HTTP 接口、实例任务生命周期、捕获流程、系统操作与纯几何规则 |
| `src/host/native-probe.ts` | 原生探针的发布二进制选择和源码 hash 编译缓存 |
| `src/host/promote.ts`、`promote-seed.ts`、`speech.ts`、`attach.ts` | 升格、语音识别，以及附件的上传与回放接口 |
| `src/host/filters.ts`、`effort.ts`、`context.ts`、`tools.ts`、`history-attachments.ts` | 可独立测试的处理规则、附件引用的收敛与预算、宿主工具适配与读取边界 |
| `src/config-values.ts` | 配置类型、默认值和数值边界 |
| `src/settings.ts` | 设置控件元数据与补丁归一化 |
| `src/prompts.ts` | 提示词文本 |
| `src/client/index.js` | 客户端生命周期、共享服务与宿主挂载 |
| `src/client/view.js`、`state.js`、`controllers.js`、`events.js` | 界面节点、实例状态、控制器装配和事件订阅/清理 |
| `src/client/controller-contracts.d.ts` | 控制器依赖的 DOM、状态、回调与服务类型契约 |
| `src/client/history.js`、`history-*.js` | 历史调度、文本转换、消息回放、滚动与截图标题生成 |
| `src/client/*` | 设置、面板、选区、语音卡、引用、附件、预览、历史、对话及录音控制器；样式与渲染辅助 |
| `native/mic-probe.c`、`native/window-list.c` | macOS 麦克风占用、窗口与显示器探针源码 |
| `skills/web-design/` | 网页回答时由宿主读取的设计规范 |
| `tests/unit/`、`integration/`、`browser/` | 规则测试、隔离宿主集成、真实浏览器验证 |
| `tests/client/fixtures/`、`tests/client/scenarios/` | DOM/接口/流式响应夹具，以及独立运行的客户端场景 |
| `tests/browser/fixtures/`、`tests/browser/scenarios/`、`tests/fixtures/` | 浏览器页面骨架、分场景断言与原生测试夹具 |
| `scripts/` | 构建、测试调度、提示词导出和设计开发工具 |
| `lib/` | 可重新生成的发布产物，不纳入版本控制 |

## 装配与状态

宿主入口只负责公开 DSH 需要的 `name`、`inject`、`Config`、`apply`。`apply` 创建各服务工厂，再注册原有 `/selection-explain/api/*` 路由。服务通过参数接收 `ctx`、配置和所需的其他服务。配置对象在实例内共享，设置更新立即对后续请求生效；模型缓存、历史和会话缓存由对应服务持有。

浏览器入口调用 `view.js` 创建 DOM，通过 `controllers.js` 向控制器传递节点、回调和必要的状态访问器。可变状态通过访问器读取当前值，避免复制布尔状态或模型缓存造成界面不同步。控制器之间的连接集中在装配层；依赖类型由 `controller-contracts.d.ts` 检查。偏好、面板状态和胶囊交互状态分别由工厂创建，每次挂载拥有独立实例。`events.js` 返回统一的清理函数。纯渲染、音频编码、图标和预览桥使用普通模块导出。

`analyze.ts` 负责 HTTP 验证与阶段调度，执行上下文以明确类型传递给消息、工具、流式轮次和补结论模块，继续使用原有取消信号和容量限制。截图服务由每次宿主 `apply` 创建，持有自己的任务、长轮询和临时目录。平台接口可注入，几何规则不访问系统；任务结束会取消未使用的预读取，停用会中止活动命令、释放等待客户端并在命令退出后清理文件。

客户端通过 esbuild 打包为一个 CommonJS 工厂，并由 `window.__ModuleLoader__.load` 注册。模块求值发生在工厂 materialize 时，DOM 挂载和监听仍由 `apply` 执行；停用时通过已有 effect/slot 清理资源。

客户端结果缓存由 `memory.js` 管理：最多 20 项，序列化文本的 UTF-16 估算总量最多 8 MiB，读取命中会刷新淘汰顺序。缓存保存独立 JSON 快照，避免保留可变界面对象；此预算不代表浏览器进程的堆内存上限。计时器作用域只登记仍然活动的计时器，完成、取消和卸载时立即移除。

长对话默认渲染最近 40 条可见消息，按需每次再展开 40 条；完整轮次仍用于保存与组装模型请求。关闭面板会清除回答区域的 DOM 和预览帧登记，保留文字、草稿与待发送附件，重开时重新渲染。卸载时还会释放附件 object URL、缓存、计时器和桥的帧引用。

## 升格为正式会话

`promote-seed.ts` 先把上下文、首轮解读和追问组装为完整 seed：事件 `seq` 从 0 连续，轮号从 1 连续，turn/step 成对闭合，消息保留插件来源与附件引用。`promote.ts` 复用宿主的 agent composition（预设挂载与模型选择设置），通过 `agents.create` 一次传入 seed、`inheritedEventCount` 和 `isSeeded`。历史在 agent 构造前已进入投影，下一轮自然从历史末尾继续；不能先建空 agent，再向 live 日志追加历史。

宿主缺少 seed 创建或 composition 能力、或无法解析来源工作目录时，使用普通会话创建与打包 prompt，不手写执行事件。修复仅改变新升格会话；已有损坏的正式会话日志需要另行备份与修复，不自动改写用户历史。

## 小窗模型上下文

`src/chat-context.ts` 是浏览器/宿主共享的纯协议：包含输入估算、容量预留、完整问答分界、原文指纹及版本1进度。`contextState` 随历史记录保存，字段为 sessionId、source、through、digest、summary 和 background。指纹只用于检测原文变化，不是权限凭据。初次追问冻结会话绑定与背景，跨主会话重开仍恢复原绑定；客户端恢复进度前验证前缀指纹，只映射并发送未压缩的原文尾部，不再随消息变旧把HTML改写成Markdown。隐藏解读前情作为固定背景单独发送，不计入持久消息偏移。旧历史没有进度时按完整历史处理。

`host/chat-context.ts` 优先读取宿主模型容量和视觉计价能力，兼容缺少这两个接口的旧宿主；默认输入预算200000估算tokens。文本按ASCII每3字符、其他UTF-16单元每1字符估算一个token，再预留安全余量；这不等于供应商的精确计数。图片缺少计价接口时按每512×512像素约1024 tokens保守估算，最少计1024，避免把小缩略图计作整张百万像素图片。模型容量已知时扣除输出和工具预留。达到输入预算85%时，将较早完整问答按批次调用同一路由生成摘要，并优先保留最近一组问答；如果最近一组也无法在预算内原样保留，则允许把它一并摘要（未回答的历史提问不会被单独吞掉）；摘要成功且重新估算合格后才发送新的SSE进度。不能安全容纳当前材料或摘要失败时明确报错，不推进进度。被拒绝的本轮用户/助手消息以contextExcluded标记保留原文，模型请求只投影短占位，消息编号不变，后续短问题不会被失败输入堵住。主工具循环与补结论请求都对实际消息（包括嵌套工具结果和图片）再次检查容量；补结论保留摘要、原文尾部及已恢复图像。

附件重建不再按固定图片张数、字节或文件数滚动替换历史。小窗独有的 `selection_material` 工具随全局工具开关和轮数开关启用：用附件ID在本次传入的规范化索引中查找，由宿主附件服务验证路径及存在性；旧图以新的材料消息提供，旧文件返回只读路径。工具只接受已列出的ID或已压缩的消息编号，不接受任意磁盘路径。恢复的附件通过SSE关联到当前用户消息，下轮仍保持稳定。原始消息从已保存的本小窗历史按字符分页读取；关闭保存或历史被删除时明确报告原文不可用。摘要中的路径不能授予读取权限。

压缩进度和附件索引都不是图片/文件字节副本，也不新增跨会话的无界内存缓存。HTTP请求体及历史保存仍有大小护栏；客户端在共享的512KiB请求体边界前本地拒绝过大输入，并保留原文及可恢复状态；历史保存仍有2MB护栏，失败时在回答旁明确提示复制重要内容。摘要不能代替原始记录。

## 数据和发布资源

用户数据位于 `${DSH_HOME}/selection-explain`，未设置 `DSH_HOME` 时使用 `~/.dsh/selection-explain`。本次整理保留各 JSON 文件格式和 HTTP 路径。

发布内容仅包含 `lib/`、原生探针源码、装配清单、运行时 skill、README 和许可证。Linux 构建不会产生 macOS 二进制；Mac 上首次使用可按源码 hash 在数据目录中编译并缓存。因此 `native/mic-probe.c` 和 `native/window-list.c` 都必须保留。窗口探针优先使用包内二进制；缺失时编译到唯一临时路径，成功后替换缓存，失败时保留截图降级路径。宿主文件移动后的资源路径相对于 `lib/host/` 解析。

README 截图使用仓库中的版本链接，不随运行时包复制。`assets/` 仍在仓库中。公开架构和贡献说明纳入版本控制，其余本机资料与设计实验继续忽略。
