# hermes-dsh-collab

**把 DeepSeek Harness 接进你的 Hermes 管线：派单、执行、验收全自动——质量门不信任自报。**

![MIT](https://img.shields.io/badge/license-MIT-green)
![DSH](https://img.shields.io/badge/DSH-0.1.0--rc.6-orange) [![Awesome DSH Plugin](https://awesome-dsh-plugin.com/badge.svg)](https://awesome-dsh-plugin.com/)
[![dsh-plugin](https://img.shields.io/badge/GitHub-dsh--plugin-0969da?style=flat-square)](https://github.com/topics/dsh-plugin)
![Hermes](https://img.shields.io/badge/Hermes-ready-9B30FF?style=flat-square)

你的 AI 助手能自己干一整天活，问题是：你敢放手吗？

这个 skill 让放手变得安全：Hermes 写派单 spec，DSH 执行，Hermes 验收——只有质量门真失败时才轮到你介入。从一条真实跑过的 14 天管线提炼（30 个 commit，7/7 阶段零返工交付）。

**依赖：** DSH 0.1.x（headless profile）+ 任意编排方 agent（用 Hermes 构建并实测）。

---

## 为什么需要它

Hermes 是你的个人助手，DSH 是能干活的执行器。缺的是两者之间的**运行契约**：一份合格的派单 spec 长什么样、哪个阶段用哪档模型、谁有资格 commit、验证到底怎么做。

大多数管线跳过这份契约，然后为返工买单。最近的工作（[COPE](https://arxiv.org/abs/2504.02095)）证明 planner/executor 分离有效——但前提是执行方的行为被约束。这个 skill 固化的就是这些约束，全部来自一条实测过的管线：

- **模型分层路由** —— 常规阶段与看图都走 Flash（`reasoning: max`，主模型原生多模态，没有视觉档也就不需要视觉 patch），多文件重构/长提炼 Pro（该通道上游当前不可用，表格里直说而不是假装能跑）。拿不准先 Flash 试一轮——返工就升级
- **Spec 三铁律** —— Plan 先行 · 测试先行（TDD 红→绿）· 范围声明。缺一不派单
- **Git 唯一写者** —— 只有编排方 commit。执行方永远不碰 git，历史保持线性可审计
- **质量门归编排方** —— 全量测试 + build + diff 对照范围 + 真浏览器走查。自报不算证据
- **写回靠启动目录** —— `cd <项目> && dsh --profile headless "任务"` 直接写回。不要 /tmp 镜像，不要 patch 交接
- **踩坑都有实锤** —— 每一条都是真实事故：patch 配置是整段替换（不是深合并）、`read` 碰二进制直接报错而 `read_image` 要求模型声明图片输入、旧后端进程会让"测试全绿"验到旧代码……

## 快速开始

```bash
# 方式一：dsh plugin 安装（bundle，推荐）
dsh plugin --profile headless add github:Cavan-Ou/hermes-dsh-collab

# 方式二：直接复制 skill 包（轻量，任意 profile）
git clone https://github.com/Cavan-Ou/hermes-dsh-collab
cp -r skills/hermes-dsh-collab "$DSH_HOME/skills/"   # 默认：~/.dsh/skills/
```

任选其一，下次 DSH 会话自动加载（bundle 注册 skill provider；复制方式由 skills 扫描器发现）。

三个验证：

1. 新会话的技能列表出现 `hermes-dsh-collab`
2. 说"帮我写一份派单任务书"——按场景自动触发
3. 问"执行者可以自己 git commit 吗？"——它回答**不可以**，并解释原因（唯一写者约定）

## 里面有什么

```
skills/hermes-dsh-collab/
├── SKILL.md                      # 判断指引：阻断项 → 判断表格 → What NOT to do
└── references/                   # 按需加载，保持主文件精简
    ├── spec-template.md          # 可复制的派单 spec 模板（三铁律 + 不 commit 条款）
    ├── model-routing.md          # 档位表 + patch 机制 + 两个 patch 坑
    ├── quality-gates.md          # 质量门四步命令 + 回炉/升级链
    └── pitfalls.md               # 12 条真实踩坑清单（症状 → 根因 → 对策）
```

写法对齐 DeepSeek 官方仓库自用 skill（见 [deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness) 的 `.agents/skills`）：引导式而非清单 · 指明真源而非复述 · 专门的 "What NOT to do" 节。

> **安装形态说明**：两种方式都支持——bundle（`dsh plugin add`，官方分发路径，已在 DSH 0.1.0-rc.6 实测）与直接复制（`$DSH_HOME/skills/`，轻量免构建）。

## 实测结果

| 结果 | 证据 |
|---|---|
| **质量门自动抓系统性错误** | 一次长提炼（74 份设计文档，约 60 万 token）中，验证环节揪出 **3 条方向完全相反的反判据** + 一个"全宇宙特征"（发丝线在 5 个流派 78–100% 高频）——这类错误人工检查要数小时且大概率漏掉 |
| Flash 常规阶段零返工 | 3/3 阶段——TDD 红→绿，质量门全绿，真浏览器走查通过 |
| skill 真的改变行为 | 真实会话：加载后 DSH 拒绝 commit 并复述唯一写者规则 |

**人工只在升级链上介入**：质量门失败，或同一阶段重试两次。其余全自动。

## 文档

- `SKILL.md` —— 判断指引本体（先读这个）
- `REPORT.md` —— 构建报告：设计决策、自测方法（隔离 `DSH_HOME` 验证）、遗留项

**路线图：** 按工作区隔离失败记录 · 路由表从观测卡活体刷新 · references 英文镜像

> **可移植性说明**：skill 的"真源"指向工作区专属路径（如 `~/.dsh/profiles/headless/*.patch.yml`）。规则本身可移植——把路径换成你的工作区即可。

## 贡献

这个 skill 靠真实使用长大。遇到清单里没有的坑？开 issue 带上事故现场（症状 → 根因 → 对策）。中英文 PR 都欢迎。

## License

MIT

---

*不是读文档写出来的，是跑真实管线跑出来的。*
