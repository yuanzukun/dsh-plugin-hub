# REPORT — dsh-harness-collab skill 包交付报告

> 任务：把「Hermes×dsh 多 agent 协作规范」沉淀为可安装、可复用的 dsh skill。
> 结论：交付完成，三项加载自测全部在真实 headless 会话中通过。

## 1. 交付物

```
dsh-harness-collab/
├── skills/hermes-dsh-collab/            # ① skill 包（打包形态，安装源）
│   ├── SKILL.md                         #   主技能：判断指引（约 120 行）
│   └── references/                      #   按需加载的细则（正文引用才被读取）
│       ├── spec-template.md             #   可复制 spec 任务书模板（三铁律通用化版）
│       ├── model-routing.md             #   模型分层路由细则 + patch 机制 + 验证姿势
│       ├── quality-gates.md             #   质量门四步 + 不信自报 + 回炉升级链
│       └── pitfalls.md                  #   常见踩坑唯一清单家（10 条）
├── .agents/skills/hermes-dsh-collab/    # ② 项目级已安装实例（rank 200，本仓库内直接生效）
├── README.md                            # 安装/自测/形态说明
└── REPORT.md                            # 本报告
```

## 2. 决策记录

### 2.1 形态：纯 skill 目录（放弃 npm bundle）

- 本包是**零代码纯提示词资产**。bundle 形态要经 `dsh plugin --profile X add` → pnpm 依赖解析；实战观测卡明确记录过 pnpm PATH/软链 Permission denied、`pnpm add` 只装依赖不激活的安装坑——对纯 skill 全是成本、零收益。
- dsh skill-filesystem 原生扫描 `<skills root>/<name>/SKILL.md`（只扫一层），目录热加载、正文修改即时生效；安装 = 一条 `cp -r`。
- 官方 make-dsh-plugin 中纯 skill 走 bundle 是「随插件分发/发布」场景；本地人工安装复用，hello-dsh 官方文档（docs/writing-skills.md）的最小形态就是纯 SKILL.md 目录。

### 2.2 结构：SKILL.md（判断层）+ references/（细则层）

对齐官方 11 个 skill 的写法（dsh-code-review 为范本）：
- **SKILL.md = 判断指引而非清单**：阻断项（git 唯一写者/写回/三铁律）→ 判断表格（三铁律、分层路由、质量门四步）→ 专门的 **What NOT to do 节**（挡住"自行 commit / 范围外顺手修 / 抄 patch 内容 / resume 回炉 / 信自报"等最高频错误）→ 自测节。
- **references/ = 按需加载**：spec 模板可复制件、路由细则、质量门命令、踩坑清单家——正文只引用路径，不复制内容，控制正文 token（正文约 120 行）。
- **真源指向而非复述**：observations.md / specs/template-v2.md / 两个 patch 文件是活体（会持续更新），SKILL.md 以路径引用它们；本包只承载提炼后的通用规则 + 一个通用化模板副本。

### 2.3 内容取舍（任务书最小集 → 落点映射）

| 任务书要求 | 落点 |
|---|---|
| 模型分层路由（Flash/Pro/qwen） | SKILL.md 路由表 + references/model-routing.md（判断问句 + 依据 + patch 三坑 + 双确认验证姿势） |
| spec 三铁律（Plan 先行/TDD/范围声明） | SKILL.md 三铁律表 + references/spec-template.md 完整模板 |
| git 唯一写者 | SKILL.md 阻断项第 1 条 + 三铁律表"不 commit"行 + What NOT to do 首条 |
| 质量门（测试+build+diff 审查+走查） | SKILL.md 四步 + references/quality-gates.md（命令/判定/不信自报/回炉升级链） |
| 写回机制（cd 项目启动） | SKILL.md 阻断项第 2 条 + 独立小节 |
| 常见踩坑 | SKILL.md 速览三条 + references/pitfalls.md 全量 10 条（症状→根因→对策） |

补充提炼（超出最小集但对规范成立必要）：回炉/升级降级链、每阶段新会话策略、进程管理纪律（terminal background 不用 nohup）、"不信自报"验证原则。

## 3. 自测方法与结果

### 3.1 静态检查

- frontmatter 键名校验：`name` kebab-case 且与目录名一致 ✓；`description` 以「当……时使用」开头 ✓；无驼峰非法键（`whenToUse` 为官方文档列出的合法可选字段）✓。

### 3.2 三项加载自测（hello-dsh 自测标准），全部在真实会话验证

| # | 标准 | 实测方式 | 结果 |
|---|---|---|---|
| 1 | 出现在技能目录里 | ① 本会话热加载：项目内建 `.agents/skills/` 后，watcher 实时追加替换目录（本会话收到含 `hermes-dsh-collab` 的新目录）② 新起 headless 会话询问「列出技能名」 | ✓ 目录内出现 `hermes-dsh-collab` |
| 2 | description 能自动触发 | 新起 headless 会话，只给场景（「给 dsh 执行者派单文件 bug 修复任务，写派单任务书」），**不点名技能名** | ✓ 模型自行加载本 skill，产出任务书完整落了三铁律+不 commit+模型等级表+质量门+回炉链（派单命令 `cd <项目根> && dsh --profile headless` 即本 skill 写回条款） |
| 3 | 正文真的改变行为 | 新起 headless 会话显式加载后提问「执行者可以自己 git commit 吗」 | ✓ 回答「不可以」并给出 skill 内理由（唯一写者=主控、质量门是主控独立验证、历史观测 dsh 会自行 commit），并复述三铁律 |

### 3.3 验证环境说明（等价性）

- 沙箱禁止本会话写 `~/.dsh/skills`（EACCES 且无审批通道），故用户级安装路径改用**隔离 DSH_HOME** 等价验证：在工作区内建 `.dshtest`（复制 headless profile + 把 skill 放入 `.dshtest/skills/`，即 `$DSH_HOME/skills` = 官方 user-dsh rank 400 根），`DSH_HOME=.dshtest dsh --profile headless "..."` 真实起会话（真实 API 调用）。
- 自测 #2/#3 前**临时移走项目级 `.agents/skills` 副本**，确认 skill 仍被加载——证明**用户级根目录单独生效**（即 README 所述 `cp -r ... ~/.dsh/skills/` 安装方式在机制上成立）。
- 测试残留（`.dshtest`、`.refs` 参考克隆）已删除；未产生任何 git commit（唯一写者约定）。

## 4. 遗留问题

1. **用户级全局安装未在本机实际落盘**：`cp -r skills/hermes-dsh-collab ~/.dsh/skills/` 被会话沙箱拒绝（workspace 外写入需审批且无通道）。机制已用隔离 DSH_HOME 等价验证；真实环境一条命令即可：`cp -r skills/hermes-dsh-collab ~/.dsh/skills/`（或 `~/.agents/skills/`，rank 500 跨 agent 共享）。
2. **两份副本的漂移风险**：`skills/`（打包源）与 `.agents/skills/`（项目级实例）是普通副本，非软链（WSL/Windows 跨盘软链有 Permission denied 历史坑，故不用）。改包后需重复制一次；README 已注明。
3. **真源路径是绝对路径**：SKILL.md 指向 style-museum 的 observations.md / template-v2.md / headless patch 文件——规范活体在该项目；换机器或项目重组需同步更新这几行引用。
4. **路由表个别档位样本少**：视觉密集实现、复杂调试的实战验证样本待积累（观测卡仅记录 Flash 常规 3/3、Pro 长提炼 1/1）；skill 已把「拿不准就试跑 Flash」写成决策规则以对冲。
5. **description 触发只测了正向**：未测误触发/漏触发边界（如普通 bug 修复 vs 管线派单的区分）；可接受，因为正文首节「何时使用」给了边界。
