# TASK：开发「dsh-harness-collab」skill 包

## 目标（你要交付什么）
开发一个 **Markdown skill 包**：把"Hermes×dsh 多 agent 协作规范"沉淀成可安装、可复用的 dsh skill。让任何 dsh 使用者（包括未来的你）读完就能按这套规范工作。

## 参考材料（必须自己读，按需使用）
- **经验源**（你的任务不是复述，是提炼）：`/mnt/d/WorkSpace/Projects/style-museum/output/dsh-pipeline/observations.md`（14 天 30 commits 的实战记录：模型分层路由/spec v2/质量门/写回机制/踩坑）
- **写作规范**：https://github.com/pingfanfan/hello-dsh （README 的 writing-skills 章节 + examples/skills/ 下 22 个中文 skill 示例 + docs/writing-skills.md）——skill 写法三要素：引导式非清单式 / 指明真源不重述 / 专门的 "what not to do" 节
- **插件形态**：https://github.com/vlln/plugin-registry 的 skills/make-dsh-plugin（官方插件开发引导）+ references/gotchas.md
- **官方 skill 参考**：https://github.com/deepseek-ai/deepseek-harness 的 .agents/skills 目录（DeepSeek 内部 11 个 skill 的写法标准）

## 边界（硬约束）
1. 产物在本项目目录内（/mnt/d/WorkSpace/Projects/dsh-harness-collab/），skill 包结构由你设计（可参考 make-dsh-plugin 的 bundle 形态或纯 skill 文件，二选一，给出理由）
2. 中文编写
3. 内容覆盖（最小集）：模型分层路由（Flash 常规/Pro 复杂/qwen 视觉）、spec 模板三铁律（Plan 先行/TDD/范围声明）、git 唯一写者约定、质量门流程（测试+build+diff 审查+走查）、写回机制（cd 项目启动）、常见踩坑
4. 自测要求：写完后 dry-run 验证（说明如何安装进 ~/.agents/skills 或 profile，并实际验证加载）
5. 禁止 git commit（git 唯一写者 = Hermes 主控）
6. 项目内已有 TASK.md 和 .git 以外什么都没有——目录结构由你规划

## 完成标准
- skill 文件齐全 + 自测通过说明（实际验证过加载/安装）
- 一份简短报告：你做了什么决策（为什么选这个形态/结构/内容取舍）、自测结果、遗留问题

## 输出
报告写在本项目 REPORT.md（你的决策+自测+遗留），skill 产物在项目目录内。
