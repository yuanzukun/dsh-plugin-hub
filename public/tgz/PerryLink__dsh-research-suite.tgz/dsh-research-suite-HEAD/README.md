<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/assets/dsh-research-suite-hero-en-dark.webp">
  <img src="docs/assets/dsh-research-suite-hero-en-light.webp" width="100%" alt="dsh-research-suite: twelve research plugins mounted as one bundle, with research_doctor reporting status ok — researchEvidence and researchReport on, evidence.jsonl 1 line and 0 malformed, latest ok.rep.json sealed">
</picture>

# dsh-research-suite

**One command for the research family — plus a doctor that tells you whether the evidence store is healthy.**

*Installs the twelve evidence, verification, systematic-review and report plugins as one bundle layer — the package is `dsh-research-suite-plugin` — and mounts `research_doctor`: a read-only check of the REP root, the mounted services, every journal and the latest sealed record.*

[简体中文](README-zh.md) · [Español](README-es.md) · [Português](README-pt.md) · [हिन्दी](README-hi.md)

[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%5E22.19%20%7C%7C%20%3E%3D24.9-brightgreen.svg)]()
[![DSH plugin](https://img.shields.io/badge/dsh--plugin-✅-green)](https://github.com/topics/dsh-plugin)

</div>

---

## Why a bundle

The research family is deliberately separate packages: `dsh-research-core`, `dsh-doc-anchor`, `dsh-cite-verify`, `dsh-claim-check`, `dsh-statcheck`, `dsh-retraction-watch`, `dsh-repro-audit`, `dsh-sr-ledger`, `dsh-meta-analysis`, `dsh-manuscript-check`, `dsh-research-report` and `dsh-library`. That is good for composition and bad for onboarding: a new profile needs twelve installs and a way to tell whether the rows actually mounted.

This package is the **bundle** for that set. One dependency tree, one `cordis.patch.yml`, one `research_doctor` row. It does not re-implement any tool.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/assets/dsh-research-suite-flow-v5-dark.svg">
  <img src="docs/assets/dsh-research-suite-flow-v5-light.svg" width="100%" alt="dsh-research-suite structure: one dsh plugin add call installs a bundle patch with twelve dependency rows and the doctor row, the rows mount researchEvidence, researchReport and one tool, and research_doctor inspects the .research-rep store read-only and returns a status with hints">
</picture>

*Structure: install → mount → inspect; `research_doctor` is the only tool this package adds, and it never repairs. The token labels inside the diagram are the real service names, journal files and config keys, so the same picture serves all five languages.*

## Install

```sh
dsh plugin --profile <name> add dsh-research-suite-plugin
dsh --profile <name> --dump-config | grep -E 'research|cite-verify|doc-anchor|statcheck|claim-check|sr-ledger|meta-analysis|manuscript|retraction|repro-audit|library'
```

Then ask the agent:

```text
Run research_doctor.
```

A healthy profile reports `research_doctor: ok`, both services `on`, and the latest record as `(sealed)`.

## What `research_doctor` checks

![dsh-research-suite test suite: the real vitest run in this checkout — 9 tests across the package contract, the mount, research_doctor and REP inspection — followed by the verify:package gate reporting 12 dependency rows](docs/assets/dsh-research-suite-demo.gif)

*Animated: the real `pnpm exec vitest run` output on 2026-11-21 (3 test files, 9 tests), then `pnpm run verify:package`. The bundle has no CLI of its own, so the doctor contract and the package gate are the run; pass markers and timings are omitted.*

| Check | Meaning |
|---|---|
| `services.researchEvidence` | `ctx.researchEvidence` is mounted (core active) |
| `services.researchReport` | `ctx.researchReport` is mounted (`dsh-research-report` active) |
| `journals[]` | `snapshots/evidence/evidence-checks/claims/verdicts/audits.jsonl`: exists, bytes, lines, malformed |
| `records` | sealed `records/*.rep.json` count, malformed files, latest record id/createdAt/evidence/claims/sealed |
| `hints[]` | what to fix next (missing root, no record, unsealed record, malformed journal, missing service) |

It is **read-only**. It never repairs, deletes, edits or creates a record. A malformed journal makes the status `error` because every count derived from it would be unreliable; a missing store is only `warn` (a fresh profile has no records yet).

## Compatibility

| | |
|---|---|
| DeepSeek Harness | `dsh-v0.2.3-alpha.1` (verified on this machine) — peer line `>=0.2.1-0 <0.3.0 \|\| >=0.2.2-0 <0.3.0` |
| Node | `^22.19.0 \|\| >=24.9.0` (tested on `24.22.1`), ESM only |
| Peers | `@deepseek-ai/cordis ^4.0.5-alpha.1`, `@deepseek-ai/dsh-tools`, `@deepseek-ai/schemastery ^3.18.5-alpha.1` |
| Runtime dependencies | the twelve research plugins (pinned) |
| Store | `.research-rep` (same default as `dsh-research-core`) |

## Configuration

| Key | Default | Meaning |
|---|---|---|
| `enabled` | `true` | `false` mounts no doctor tool (the other rows stay) |
| `root` | `.research-rep` | REP root the doctor reads, resolved against the harness working directory |
| `maxScanBytes` | `16777216` | per-journal/file scan cap; larger files are counted but not parsed |

The doctor also accepts a per-call `root` override.

## What this package does not do

- **No tools of its own beyond the doctor.** All evidence/verification/report tools belong to their plugins.
- **No automatic repair.** A malformed journal is reported, never rewritten.
- **No telemetry, no network.** The doctor reads local files and `ctx.get`.
- **No hidden install.** The bundle is a normal package dependency tree; uninstall it like any other plugin.

## Development

```sh
pnpm install
pnpm run check:lockfile
pnpm typecheck
pnpm test
pnpm build
pnpm verify:package
```

The lockfile is committed exactly as `pnpm install --lockfile-only` writes it (two documents: pnpm's own package-manager document, then the project document), so a local install does not rewrite it. `pnpm run check:lockfile` fails when the lockfile drifts from `package.json` or loses that form.

## License

Apache-2.0. See [LICENSE](LICENSE).
