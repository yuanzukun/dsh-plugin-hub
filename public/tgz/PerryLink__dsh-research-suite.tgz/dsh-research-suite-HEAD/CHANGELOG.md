# Changelog

## [Unreleased]

## [0.1.8] - 2026-11-22

- Compatibility: declare DeepSeek Harness 0.2.3-alpha.1 support (>=0.2.3-0 <0.3.0-0 in engines.dsh and every @deepseek-ai/dsh-* peer range) and refresh README verification stamps.

## [0.1.7] - 2026-11-20

### Changed

- First release through the Trusted Publisher OIDC path.


## [0.1.6] - 2026-11-20

### Changed

- Publish the corrected tarball with the built lib/ tree under dsh-research-suite-plugin.


## [0.1.5] - 2026-11-20

### Changed

- Re-publish after the 0.1.4 staged entry could not be listed; no code change.


## [0.1.4] - 2026-11-20

### Changed

- Publish under the bare npm name dsh-research-suite-plugin.


## [0.1.3] - 2026-11-20

### Changed

- Publish under the bare npm name dsh-research-suite-plugin (the name must keep the dsh prefix).


## [0.1.2] - 2026-11-20

### Changed

- Publish under the bare npm name dsh-research-suite-plugin (the scoped name was retired from the release path).


All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-11-10

### Added

- `dsh-research-suite-plugin`: one bundle layer for `dsh-research-core`,
  `dsh-doc-anchor`, `dsh-cite-verify`, `dsh-claim-check`, `dsh-statcheck`,
  `dsh-retraction-watch`, `dsh-repro-audit`, `dsh-sr-ledger`,
  `dsh-meta-analysis`, `dsh-manuscript-check`, `dsh-research-report` and
  `dsh-library`.
- `research_doctor`: read-only REP inspection (root, mounted services, journal
  line/malformed counts, sealed-record count and latest record, actionable
  hints). It never repairs or writes.
