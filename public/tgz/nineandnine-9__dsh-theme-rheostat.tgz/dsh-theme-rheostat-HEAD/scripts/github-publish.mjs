// One-shot GitHub publisher for dsh-theme-rheostat.
// Reads the token from the GH_TOKEN env var (never hardcoded).
// NOTE: this sandbox requires `node --use-system-ca` for GitHub's TLS chain.
const token = process.env.GH_TOKEN
if (!token) {
  console.error('GH_TOKEN env var is required')
  process.exit(1)
}

const NAME = 'dsh-theme-rheostat'
const DESCRIPTION = 'Sliding-rheostat theme plugin for the DeepSeek Harness web GUI: model + reasoning-effort driven accents, composer glow, and a whale slider.'

const headers = {
  Authorization: `Bearer ${token}`,
  'User-Agent': 'dsh-theme-rheostat-publisher',
  Accept: 'application/vnd.github+json',
  'Content-Type': 'application/json',
}

async function main() {
  const userRes = await fetch('https://api.github.com/user', { headers })
  const user = await userRes.json()
  console.log('user status', userRes.status, 'login', user.login ?? user.message)
  if (userRes.status !== 200) process.exit(1)

  const body = JSON.stringify({
    name: NAME,
    description: DESCRIPTION,
    private: false,
    auto_init: false,
  })
  const res = await fetch('https://api.github.com/user/repos', { method: 'POST', headers, body })
  const repo = await res.json()
  console.log('repo status', res.status, repo.full_name ?? repo.message)
  if (repo.html_url) console.log('html_url', repo.html_url)
  if (repo.clone_url) console.log('clone_url', repo.clone_url)
}

main()
