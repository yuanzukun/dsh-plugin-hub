/**
 * The dock control rendered in the `conversation.input.dock` slot (a full-width
 * row stacked above the composer card). It renders a whale slider (the rheostat
 * wiper) above a readout of the current gear. The track is continuous: the whale
 * rests anywhere along it, and its position maps to a (model, reasoning-effort)
 * zone — the left half is v4-flash, the right half is v4-pro, and within each
 * half the lower quarter is 强 (high) and the upper quarter is 超强 (max). The
 * selection previews live while dragging and commits on release.
 */
import * as React from 'react'
import { LEVELS, resolveLevel, type GearLevel } from './levels.ts'

/** Minimal uSES-compatible store surface the model directory exposes. */
interface DirectoryStore<T = unknown> {
  subscribe: (callback: () => void) => () => void
  getSnapshot: () => T
}

interface ModelSelectionLike {
  provider?: string
  model?: string
  reasoningEffort?: string
}

interface ModelGroup {
  id: string
  models?: { id: string }[]
}

interface ModelDirectoryState {
  current?: ModelSelectionLike | null
  groups?: ModelGroup[]
}

interface GearDockProps {
  directory: DirectoryStore<ModelDirectoryState>
  select: (selection: { provider: string; model: string; reasoningEffort?: string }) => Promise<boolean>
  load: () => void
  sessionId: string
  t: (key: string, params?: Record<string, unknown>) => string
  session?: unknown
  input?: unknown
}

/** Horizontal inset (px) of the rail — matches the CSS `.rheostat-rail` insets. */
const RAIL_INSET = 14

/** Continuous position (0..1) → the gear zone index (0..3). */
function derivedIndex(position: number): number {
  return Math.max(0, Math.min(LEVELS.length - 1, Math.floor(position * LEVELS.length)))
}

/** Gear zone index → the centre of that zone (the whale's rest position). */
function zoneCenter(index: number): number {
  return (index + 0.5) / LEVELS.length
}

/**
 * Resolve the provider route for a model: prefer the catalog group that owns it,
 * then fall back to the current selection's provider.
 */
function findProvider(state: ModelDirectoryState | undefined, modelId: string): string | undefined {
  for (const group of state?.groups ?? []) {
    if (group.models?.some((model) => model.id === modelId)) return group.id
  }
  return state?.current?.provider
}

/** Cartoon whale thumb with an animated spout; inherits colour via `currentColor`. */
function WhaleIcon(): React.ReactNode {
  return (
    <svg width="46" height="32" viewBox="0 0 92 64" fill="none" aria-hidden="true">
      <g className="whale-spout">
        <path
          d="M30 14 C27 7 32 3 37 7 C42 3 47 7 44 14"
          stroke="currentColor"
          strokeWidth="3.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle className="whale-drop whale-drop-1" cx="32" cy="7" r="1.9" fill="currentColor" />
        <circle className="whale-drop whale-drop-2" cx="36" cy="5" r="2.1" fill="currentColor" />
        <circle className="whale-drop whale-drop-3" cx="40" cy="4" r="1.7" fill="currentColor" />
        <circle className="whale-drop whale-drop-4" cx="35" cy="3" r="1.4" fill="currentColor" />
      </g>
      <path
        d="M58 32 C66 24 76 22 84 25 C76 28 72 31 70 35 C76 37 80 38 84 39 C76 42 66 40 58 36 Z"
        fill="currentColor"
      />
      <path
        d="M18 32 C18 18 30 10 46 10 C62 10 72 20 72 32 C72 44 60 54 44 54 C28 54 18 44 18 32 Z"
        fill="currentColor"
      />
      <path
        d="M28 46 C32 52 52 52 58 44 C52 51 34 51 28 46 Z"
        fill="rgba(255, 255, 255, 0.35)"
      />
      <path
        d="M48 34 C52 42 58 45 63 43 C58 39 53 34 50 32 Z"
        fill="currentColor"
      />
      <circle cx="31" cy="30" r="3.6" fill="#101422" />
      <circle cx="32.3" cy="28.8" r="1.2" fill="#ffffff" />
      <path d="M24 42 Q31 47 39 42" stroke="#101422" strokeWidth="2.6" fill="none" strokeLinecap="round" />
      <circle cx="42" cy="39" r="3" fill="rgba(255, 255, 255, 0.4)" />
    </svg>
  )
}

export function GearDock({ directory, select, load, t }: GearDockProps): React.ReactNode {
  const subscribe = React.useCallback((callback: () => void) => directory.subscribe(callback), [directory])
  const getSnapshot = React.useCallback(() => directory.getSnapshot(), [directory])
  const state = React.useSyncExternalStore(subscribe, getSnapshot)

  const committedLevel = resolveLevel(state?.current ?? null)
  const committedIndex = committedLevel === null ? 0 : LEVELS.findIndex((candidate) => candidate.key === committedLevel.key)

  const [position, setPosition] = React.useState<number>(() => zoneCenter(0))
  const [dragging, setDragging] = React.useState(false)
  const [pendingIndex, setPendingIndex] = React.useState<number | null>(null)
  const draggingRef = React.useRef(false)
  const sliderRef = React.useRef<HTMLDivElement>(null)

  // Populate the directory once so the dock shows (and can switch) immediately.
  React.useEffect(() => {
    load()
  }, [load])

  // Glide the whale to the committed gear's zone centre on external changes
  // (e.g. the composer model picker); our own drag releases stay where dropped.
  React.useEffect(() => {
    if (draggingRef.current) return
    setPosition((prev) => (derivedIndex(prev) === committedIndex ? prev : zoneCenter(committedIndex)))
  }, [committedIndex])

  // Drop the optimistic (pending) gear once the store confirms the selection, so
  // a release never flashes back to the previous gear before the new one lands.
  React.useEffect(() => {
    if (pendingIndex === null) return
    const ci = committedLevel === null ? -1 : LEVELS.findIndex((candidate) => candidate.key === committedLevel.key)
    if (ci === pendingIndex) setPendingIndex(null)
  }, [pendingIndex, committedLevel])

  const previewLevel = LEVELS[derivedIndex(position)]
  const displayedLevel = dragging
    ? previewLevel
    : pendingIndex !== null
      ? LEVELS[pendingIndex]
      : committedLevel

  React.useEffect(() => {
    if (displayedLevel === null) {
      delete document.body.dataset.dshRheostat
      delete document.body.dataset.rheostatLevel
    } else {
      document.body.dataset.dshRheostat = ''
      document.body.dataset.rheostatLevel = displayedLevel.key
    }
    return () => {
      delete document.body.dataset.dshRheostat
      delete document.body.dataset.rheostatLevel
    }
  }, [displayedLevel])

  const positionToLeft = (value: number): string =>
    `calc(${RAIL_INSET}px + (100% - ${RAIL_INSET * 2}px) * ${value})`

  const clientXToPosition = (clientX: number): number => {
    const el = sliderRef.current
    if (!el) return 0
    const rect = el.getBoundingClientRect()
    const ratio = (clientX - rect.left - RAIL_INSET) / (rect.width - RAIL_INSET * 2)
    return Math.max(0, Math.min(1, ratio))
  }

  const commit = (candidate: GearLevel): Promise<boolean> => {
    const provider = findProvider(state, candidate.modelName)
    if (provider === undefined) return Promise.resolve(false)
    return select({ provider, model: candidate.modelName, reasoningEffort: candidate.effort })
  }

  const handlePointerDown = (event: React.PointerEvent<HTMLDivElement>): void => {
    draggingRef.current = true
    setDragging(true)
    event.currentTarget.setPointerCapture(event.pointerId)
    setPosition(clientXToPosition(event.clientX))
  }

  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>): void => {
    if (!draggingRef.current) return
    setPosition(clientXToPosition(event.clientX))
  }

  const handlePointerUp = (event: React.PointerEvent<HTMLDivElement>): void => {
    if (!draggingRef.current) return
    draggingRef.current = false
    setDragging(false)
    const index = derivedIndex(clientXToPosition(event.clientX))
    setPendingIndex(index)
    commit(LEVELS[index]).then((ok) => {
      if (!ok) setPendingIndex(null)
    })
  }

  const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>): void => {
    let index: number | null = null
    if (event.key === 'ArrowLeft') index = Math.max(0, committedIndex - 1)
    else if (event.key === 'ArrowRight') index = Math.min(LEVELS.length - 1, committedIndex + 1)
    else if (event.key === 'Home') index = 0
    else if (event.key === 'End') index = LEVELS.length - 1
    if (index === null) return
    event.preventDefault()
    setPosition(zoneCenter(index))
    setPendingIndex(index)
    commit(LEVELS[index]).then((ok) => {
      if (!ok) setPendingIndex(null)
    })
  }

  const effortLabel = (effort: GearLevel['effort']) =>
    t(effort === 'max' ? 'dock.gear.super' : 'dock.gear.strong')

  const labelFor = (candidate: GearLevel | null) =>
    candidate === null
      ? t('dock.none')
      : t('dock.label', { model: candidate.modelName, effort: effortLabel(candidate.effort) })

  return (
    <div data-rheostat-dock>
      <div
        ref={sliderRef}
        className="rheostat-slider"
        role="slider"
        tabIndex={0}
        aria-label={t('dock.title')}
        aria-valuemin={0}
        aria-valuemax={LEVELS.length - 1}
        aria-valuenow={derivedIndex(position)}
        aria-valuetext={labelFor(displayedLevel)}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onKeyDown={handleKeyDown}
      >
        <div className="rheostat-rail">
          {LEVELS.map((candidate, index) => (
            <div
              key={candidate.key}
              className={index === derivedIndex(position) ? 'rheostat-zone rheostat-zone-active' : 'rheostat-zone'}
              data-zone={candidate.key}
            />
          ))}
        </div>
        <div
          className={dragging ? 'rheostat-whale is-dragging' : 'rheostat-whale'}
          style={{ left: positionToLeft(position) }}
        >
          <WhaleIcon />
        </div>
      </div>
      <div className="rheostat-readout">
        {displayedLevel !== null && (
          <img className="rheostat-gear" src={displayedLevel.image} alt="" aria-hidden />
        )}
        <span className="rheostat-label">{labelFor(displayedLevel)}</span>
      </div>
    </div>
  )
}
