/**
 * Builds the plugin stylesheet as a plain CSS string (injected once at apply).
 *
 * Token overrides are keyed on `body[data-dsh-rheostat][data-rheostat-level="…"]`
 * so every gear owns a light and a dark block; removing the attribute reverts
 * to whatever skin/theme is underneath. The composer glow targets the stable
 * `[data-composer-card]` hook the conversation shell renders.
 */
import { LEVELS, type GearLevel } from './levels.ts'

/** Base dock chrome, independent of the active gear. */
const DOCK_CSS = /* css */ `
[data-rheostat-dock] {
  display: flex;
  flex-direction: column;
  gap: 2px;
  width: 100%;
  max-width: var(--dsh-composer-card-max-width, 780px);
  margin: 0 auto;
  padding: 2px 10px 2px;
  font-size: 13px;
  line-height: 1;
  color: var(--dsw-alias-label-secondary);
  user-select: none;
}
[data-rheostat-dock] .rheostat-slider {
  position: relative;
  width: 100%;
  height: 58px;
  cursor: pointer;
  touch-action: none;
  outline: none;
}
[data-rheostat-dock] .rheostat-slider:focus-visible {
  outline: 1px solid var(--rheostat-accent, var(--dsw-alias-brand-primary));
  border-radius: 14px;
}
[data-rheostat-dock] .rheostat-rail {
  position: absolute;
  left: 14px;
  right: 14px;
  top: 44px;
  height: 8px;
  display: flex;
  gap: 4px;
  pointer-events: none;
}
[data-rheostat-dock] .rheostat-zone {
  flex: 1;
  height: 100%;
  border-radius: 2px;
  opacity: 0.45;
  transition: opacity 180ms ease, box-shadow 180ms ease;
}
[data-rheostat-dock] .rheostat-zone-active {
  opacity: 1;
  box-shadow: 0 0 8px var(--rheostat-accent, var(--dsw-alias-brand-primary));
}
[data-rheostat-dock] .rheostat-whale {
  position: absolute;
  top: 6px;
  transform: translateX(-50%);
  color: var(--rheostat-accent, var(--dsw-alias-brand-primary));
  transition: left 240ms cubic-bezier(0.22, 1, 0.36, 1);
  pointer-events: none;
  z-index: 2;
  filter: drop-shadow(0 2px 5px rgba(0, 0, 0, 0.2));
}
[data-rheostat-dock] .rheostat-whale.is-dragging {
  transition: none;
}
[data-rheostat-dock] .rheostat-whale svg {
  overflow: visible;
}
[data-rheostat-dock] .rheostat-readout {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 28px;
  padding-left: 6px;
}
[data-rheostat-dock] .rheostat-gear {
  width: 36px;
  height: 36px;
  object-fit: contain;
  filter: drop-shadow(0 0 8px var(--rheostat-accent, transparent));
}
[data-rheostat-dock] .rheostat-label {
  font-weight: 500;
  color: var(--dsw-alias-label-primary);
  white-space: nowrap;
}
@keyframes whale-spout-pulse {
  0%, 100% { transform: translateY(0); opacity: 1; }
  50% { transform: translateY(-4px); opacity: 0.68; }
}
@keyframes whale-drop {
  0% { transform: translateY(0) scale(1); opacity: 0; }
  20% { opacity: 1; }
  100% { transform: translateY(-16px) scale(0.5); opacity: 0; }
}
[data-rheostat-dock] .whale-spout {
  animation: whale-spout-pulse 1.4s ease-in-out infinite;
}
[data-rheostat-dock] .whale-drop {
  animation: whale-drop 1.4s ease-out infinite;
}
[data-rheostat-dock] .whale-drop-1 { animation-delay: 0s; }
[data-rheostat-dock] .whale-drop-2 { animation-delay: 0.35s; }
[data-rheostat-dock] .whale-drop-3 { animation-delay: 0.7s; }
[data-rheostat-dock] .whale-drop-4 { animation-delay: 1.05s; }
`

function gearBlock(level: GearLevel, dark: boolean): string {
  const scheme = dark ? 'dark' : 'light'
  const accent = level.accent[scheme]
  const ring = level.ring[scheme]
  const glow = level.glow[scheme]
  const schemeSel = dark ? '[data-ds-dark-theme]' : ':not([data-ds-dark-theme])'
  const sel = `body[data-dsh-rheostat][data-rheostat-level="${level.key}"]${schemeSel}`
  const invert = dark ? '#0b1220' : '#ffffff'
  return [
    `${sel} {`,
    `  --dsw-alias-brand-primary: ${accent};`,
    `  --dsw-alias-brand-primary-invert: ${invert};`,
    `  --dsw-alias-button-primary-fill: ${accent};`,
    `  --dsw-alias-border-l2: ${ring};`,
    `  --dsw-alias-label-primary-bluish: ${accent};`,
    `  --dsw-alias-state-business-primary: ${accent};`,
    `  --rheostat-accent: ${accent};`,
    `}`,
    `${sel} [data-composer-card] {`,
    `  box-shadow: 0 0 0 1px ${ring}, 0 6px ${level.spread}px ${glow};`,
    `  transition: box-shadow 260ms ease;`,
    `}`,
  ].join('\n')
}

export function buildStylesheet(): string {
  const blocks: string[] = [DOCK_CSS]
  for (const level of LEVELS) {
    blocks.push(gearBlock(level, false))
    blocks.push(gearBlock(level, true))
    blocks.push(`[data-rheostat-dock] .rheostat-zone[data-zone="${level.key}"] { background: ${level.accent.light}; }`)
    blocks.push(`body[data-ds-dark-theme] [data-rheostat-dock] .rheostat-zone[data-zone="${level.key}"] { background: ${level.accent.dark}; }`)
  }
  return blocks.join('\n')
}
