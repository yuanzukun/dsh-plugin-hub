/**
 * Rheostat skin — client entry.
 *
 * Registers its locale dictionary, injects the gear stylesheet, and takes the
 * `conversation.input.dock` seat (a full-width row above the composer card) to
 * render the current gear and let the user switch model + reasoning effort by
 * clicking a gear. The body attributes it projects drive the per-gear token
 * overrides and composer glow.
 */
import { GearDock } from './GearDock.tsx'
import { buildStylesheet } from './styles.ts'

const NS = 'rheostat'

const zh = {
  'dock.title': '滑动变阻器挡位',
  'dock.gear.strong': '强',
  'dock.gear.super': '超强',
  'dock.label': '{model} · {effort}',
  'dock.none': '选择挡位',
} as const

const en = {
  'dock.title': 'Rheostat gear',
  'dock.gear.strong': 'Strong',
  'dock.gear.super': 'Max',
  'dock.label': '{model} · {effort}',
  'dock.none': 'Select gear',
} as const

interface ClientContext {
  locale: {
    register: (namespace: string, dict: Record<string, Record<string, string>>) => () => void
  }
  slots: {
    inject: (name: string, register: () => () => void) => void
    register: (options: Record<string, unknown>, component: unknown) => () => void
  }
  modelDirectories: {
    directoryFor: (sessionId: string) => {
      store: unknown
      select: (selection: unknown) => Promise<void>
      load: () => Promise<unknown>
    }
  }
  effect: (fn: () => (() => void) | void, label: string) => void
}

export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'rheostat: dictionaries')

  ctx.effect(() => {
    const style = document.createElement('style')
    style.dataset.plugin = '@dsh-external/dsh-theme-rheostat'
    style.textContent = buildStylesheet()
    document.head.appendChild(style)
    return () => {
      style.remove()
    }
  }, 'rheostat: gear stylesheet')

  ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({
    name: 'conversation.input.dock',
    id: 'rheostat-gear',
    order: 0,
    locale: NS,
    inject: (sessionId: string) => {
      const directory = ctx.modelDirectories.directoryFor(sessionId)
      return {
        directory: directory.store,
        select: (selection: unknown) => directory.select(selection).then(() => true, () => false),
        load: () => directory.load().catch(() => {}),
      }
    },
  }, GearDock))
}

export const inject = ['slots', 'locale', 'modelDirectories'] as const
