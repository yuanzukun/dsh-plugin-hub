/**
 * The four rheostat gears and the resolver that maps a live model selection
 * (`{ model, reasoningEffort }`) onto exactly one gear.
 *
 * The metaphor is "a rheostat heating up": flush rides the cold family (blue →
 * indigo) and pro rides the warm family (amber → red); within each family the
 * jump from `high` (强) to `max` (超强) both deepens the accent and widens the
 * glow spread.
 */
import {
  ASSET_OVERVIEW,
  ASSET_V4_FLUSH_MAX,
  ASSET_V4_FLUSH_STRONG,
  ASSET_V4_PRO_MAX,
  ASSET_V4_PRO_STRONG,
} from './assets.generated.ts'

export type GearKey = 'flush-strong' | 'flush-max' | 'pro-strong' | 'pro-max'

export interface GearLevel {
  /** Stable key — also the value of `body[data-rheostat-level]`. */
  key: GearKey
  /** Case-insensitive substring matched against `ModelSelection.model`. */
  modelMatch: string
  /** Canonical model display name used in the dock label. */
  modelName: string
  /** Reasoning effort the gear corresponds to. */
  effort: 'high' | 'max'
  /** Embedded gear raster (data URI). */
  image: string
  /** Solid accent for --dsw-alias-* overrides, light / dark. */
  accent: { light: string; dark: string }
  /** 1px ring colour for the composer border, light / dark. */
  ring: { light: string; dark: string }
  /** Ambient outer glow colour, light / dark. */
  glow: { light: string; dark: string }
  /** Outer glow blur radius in px (grows with the gear). */
  spread: number
}

export const LEVELS: readonly GearLevel[] = [
  {
    key: 'flush-strong',
    modelMatch: 'v4-flash',
    modelName: 'deepseek-v4-flash',
    effort: 'high',
    image: ASSET_V4_FLUSH_STRONG,
    accent: { light: '#2563EB', dark: '#60A5FA' },
    ring: { light: 'rgba(37, 99, 235, 0.42)', dark: 'rgba(96, 165, 250, 0.48)' },
    glow: { light: 'rgba(37, 99, 235, 0.20)', dark: 'rgba(96, 165, 250, 0.26)' },
    spread: 14,
  },
  {
    key: 'flush-max',
    modelMatch: 'v4-flash',
    modelName: 'deepseek-v4-flash',
    effort: 'max',
    image: ASSET_V4_FLUSH_MAX,
    accent: { light: '#4F46E5', dark: '#818CF8' },
    ring: { light: 'rgba(79, 70, 229, 0.50)', dark: 'rgba(129, 140, 248, 0.55)' },
    glow: { light: 'rgba(79, 70, 229, 0.26)', dark: 'rgba(129, 140, 248, 0.32)' },
    spread: 24,
  },
  {
    key: 'pro-strong',
    modelMatch: 'v4-pro',
    modelName: 'deepseek-v4-pro',
    effort: 'high',
    image: ASSET_V4_PRO_STRONG,
    accent: { light: '#D97706', dark: '#FBBF24' },
    ring: { light: 'rgba(217, 119, 6, 0.50)', dark: 'rgba(251, 191, 36, 0.55)' },
    glow: { light: 'rgba(217, 119, 6, 0.24)', dark: 'rgba(251, 191, 36, 0.30)' },
    spread: 24,
  },
  {
    key: 'pro-max',
    modelMatch: 'v4-pro',
    modelName: 'deepseek-v4-pro',
    effort: 'max',
    image: ASSET_V4_PRO_MAX,
    accent: { light: '#DC2626', dark: '#F87171' },
    ring: { light: 'rgba(220, 38, 38, 0.58)', dark: 'rgba(248, 113, 113, 0.62)' },
    glow: { light: 'rgba(220, 38, 38, 0.30)', dark: 'rgba(248, 113, 113, 0.36)' },
    spread: 34,
  },
]

/** A model-selection slice as published by the model directory store. */
export interface ModelSelectionLike {
  model?: string
  reasoningEffort?: string
}

/**
 * Resolve the current selection to one gear, or null when the model is not one
 * this skin knows (in which case the dock hides and no token is overridden).
 * An absent/unknown effort falls back to `high` (强).
 */
export function resolveLevel(current: ModelSelectionLike | null | undefined): GearLevel | null {
  if (current === null || current === undefined) return null
  if (typeof current.model !== 'string' || current.model.length === 0) return null
  const model = current.model.toLowerCase()
  const effort: GearLevel['effort'] = current.reasoningEffort === 'max' ? 'max' : 'high'
  return LEVELS.find((level) => model.includes(level.modelMatch) && level.effort === effort) ?? null
}

/** The overview strip, shown as the dock meter track. */
export { ASSET_OVERVIEW }
