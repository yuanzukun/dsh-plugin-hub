/** Host loader entry for the browser-only rheostat skin plugin. */

/** Provides no host-side behavior. */
export function apply(): void {}
