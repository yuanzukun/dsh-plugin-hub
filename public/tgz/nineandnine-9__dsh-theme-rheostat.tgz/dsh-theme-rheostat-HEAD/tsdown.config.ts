/**
 * Standalone tsdown config for the rheostat skin.
 *
 * Emits two artifacts into lib/:
 *   - lib/index.js   (node/host half, ESM)  — a no-op apply for the Host loader.
 *   - lib/client.js  (browser half, CJS)    — the __ModuleLoader__.load closure.
 *
 * The browser half keeps `react` / `react/jsx-runtime` and the DSH platform
 * modules EXTERNAL: they resolve through the frozen module table the shell
 * seeds (`window.__ModuleLoader__.require`), never from this package. Anything
 * else is inlined. The banner/footer/intro wrap the CJS output in exactly the
 * `window.__ModuleLoader__.load({ id, factory })` hand-off the loader expects.
 */
import type { UserConfig } from 'tsdown'

const ID = '@dsh-external/dsh-theme-rheostat'

/** The shell's shared platform modules (mirrors dsh-web-app's seed table). */
const PLATFORM_MODULES = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-schema-form',
] as const

/** Snapshot-store engine is answered by the runtime row in the module table. */
const RUNTIME_STORE_EXEMPTION = '@deepseek-ai/dsh-client-runtime/client'

const EXTERNALS: readonly string[] = [...PLATFORM_MODULES, RUNTIME_STORE_EXEMPTION]

const lib: UserConfig = {
  name: ID,
  entry: ['src/index.ts'],
  outDir: 'lib',
  format: 'esm',
  platform: 'node',
  target: 'es2024',
  fixedExtension: false,
  dts: false,
  clean: false,
  external: ['@deepseek-ai/cordis'],
}

const client: UserConfig = {
  name: `${ID}/client`,
  entry: { client: 'src/client/index.ts' },
  outDir: 'lib',
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  dts: false,
  clean: false,
  jsx: 'react-jsx',
  external: [...EXTERNALS],
  noExternal: (id: string) => (EXTERNALS.includes(id) ? undefined : true),
  outputOptions: {
    entryFileNames: 'client.js',
    banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(ID)}, factory: (require) => {`,
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
  },
}

export default [lib, client]
