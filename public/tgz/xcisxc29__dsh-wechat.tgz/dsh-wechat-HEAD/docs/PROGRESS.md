# 开发进度

各档功能的完成情况与**验证方式**。用户文档见 [README](../README.md)。


- ✅ **第一档**：纯文本打通 —— 协议层、扫码登录、长轮询、发送、状态持久化、会话路由与多对话、桌面端可见的工作区、GUI 设置页、可安装 bundle
- ✅ **第二档**（已完成）：媒体双向 + 会话控制
  - ✅ **入站媒体**：图片/文件/语音/视频的下载与解密，落盘到会话工作区的 `媒体/`（保留原文件名），并把路径与大小交给 agent。**真实微信图片已验证端到端跑通**。大小上限提升到 **100MB**（对齐官方）
  - ✅ **附件合并窗口（覆盖所有非文本消息）**：**任何带附件的消息**——图片、文件、语音、视频，**无论有没有配文字**——都先停放 10 秒。
    - 窗口内来了文字 → 合并成一条 prompt，附件与所有 caption 一起交给 agent
    - 窗口内没有后续 → 超时后单独把附件交给 agent
    - 连续多条（如「文件 + 图片 + 一句要求」）会**累积成一个 prompt**，而不是三次调用
    - **为什么带文字也要等**：用户常常先发附件、再补一句说明。若带文字就立即送出，那句补充就变成了第二次、互不相关的调用——这正是这个窗口要消除的多余回复
  - ✅ **出站媒体**：`send_to_wechat` 工具，agent 可把本机文件发回微信（图片走图片通道，其他走文件通道）。caption 作为**先发的文本条目**，与官方一致
  - ✅ **语音转码（SILK → WAV）**：`packages/core/src/silk.ts`，照官方 [`silk-transcode.ts`](https://unpkg.com/@tencent-weixin/openclaw-weixin@2.4.6/src/media/silk-transcode.ts) 实现。
    - 用 `silk-wasm` 解码为 `pcm_s16le` @ **24 kHz 单声道**，套 WAV 容器；失败则**回退原始 SILK**，不会丢语音
    - `silk-wasm` 不是硬依赖：运行时按包根解析，缺失时优雅降级
    - prompt 里带上**服务端转写**与**时长**，agent 常常不必打开音频就能回答
    - **验证方式**：`node scripts/probe-silk.mjs` 做真实往返（PCM → SILK → 解码 → WAV），校验全部头部字段与时长；1 秒源音频解出 1.000 秒
  - ✅ **视频**：入站下载解密 + 出站发送。
    - **出站本来完全不存在**——`.mp4` 会被当成普通文件走 `UploadMediaType.FILE`，手机收到的是不可播的下载而非视频。现在 `packages/bundle/src/media-kind.ts` 按扩展名分派 image / video / file 三种通道
    - 条目照官方 `sendVideoMessageWeixin`：`video_item: { media, video_size: <密文大小> }`，**不发缩略图、不发 md5**
    - 入站同样要求"引用 + `aes_key` 齐"才下载；prompt 里带上**时长**（`play_length`）与 md5
    - 分类规则有独立测试（`media-kind.test.ts`），因为**类型错了不会报错**，只是手机那头拿到错的东西
  - ✅ **出站图片（已实机验证成功）**：根因是 `media.aes_key` 编码，见上文「协议依据」
  - 🔍 **出站图片可见性**：症状演进"完全看不到" → "**灰框**"。灰框意味着消息被服务接受、只是客户端**解密不了媒体**。
    - 🔑 **根因（已找到权威依据）**：`media.aes_key` 必须是 **base64(hex 文本)**，不是 base64(原始 16 字节)。前者 44 字符、后者 24 字符，只有前者能解密——发错形态时服务照收，手机显示灰框。
      参考：[腾讯官方 openclaw-weixin 的 send.ts](https://unpkg.com/@tencent-weixin/openclaw-weixin@2.4.6/src/messaging/send.ts) 里 `aes_key: Buffer.from(uploaded.aeskey).toString("base64")`，其中 `aeskey` 已是 hex 字符串。
    - **完全对齐官方 `sendImageMessageWeixin` 的条目构造**：
      ```ts
      image_item: {
        media: { encrypt_query_param, aes_key: base64(hex), encrypt_type: 1 },
        mid_size: <原图密文大小>,
      }
      ```
      因此**移除**了此前自行添加的 `image_item.aeskey`、`hd_size`、`thumb_media` 等字段——官方条目里没有它们，而多余的密钥声明正是客户端不认的形态。
    - `encrypt_type` 回到 **1**（官方对图片/文件都用 1）。
    - `file_item` 也对齐官方：只有 `media` / `file_name` / `len`，**移除** `md5`。
    - 媒体引用取**上传响应的 `x-encrypted-param` 头**（官方做法）。此前一轮曾误改为 `upload_full_url` 里的参数，那是上传授权、只读会被拒（403）。
    - `thumbnail.ts`（用应用自带 `sharp`）保留：它对入站/后续视频路径仍有用，但官方图片条目并不发送缩略图引用。
  - ❌ **工具调用卡片：已彻底删除（0.37.0）**。曾经用微信客户端原生渲染的工具卡片来显示 agent 在做什么（`type=11` 开始 / `type=12` 结果），结构对齐了官方 `reply-progress-sender.ts`，单元测试全绿，但**实机上卡片从来没出现过**（2026-10-06 12:22 的截图里全是普通文字气泡）。
    - 更糟的是**它开始报错**：发送接口返回的不是 JSON，每条都记一句 `工具卡片发送失败: Unexpected end of JSON input`，堆在设置页的「最近错误」里。功能没生效，噪音却留了下来。
    - **2026-10-09 彻底砍掉**，连接口一起：`sendItem` 之上的 `sendToolCard()`、`type=11/12` 两个枚举值、`ToolCallStartItem` / `ToolCallResultItem`、`StreamFrame` 里只为驱动它而存在的 `toolCall` / `toolCallShape` / `blockShape`、host 里的 `#announceTool` / `#closeToolCard` / `closeOpenToolCards` / `toolResultListener` / `TOOL_CARD_GRACE_MS` / `#announcedTools` / `#runningTools` / `#recordToolShape`、`tools/result` 的注册与解绑，以及 **8 个断言它的测试**。
    - **教训**：**一个"没生效但不报错"的功能会一直活着**。它当初的诊断设计（把帧字段名写进日志）本身没问题，问题是没人据此做决定——直到它开始报错才被处理。**要么让它工作，要么让它消失，不要让它悬着。**
    - **宁可少一张卡片，也不谎报成功**——这是这条设计的取舍
  - ✅ **引用消息缓存**：用户长按引用 DSH 的某条消息再追问时，把被引用的内容还原给 agent。
    - **协议事实（实测样本）**：引用到达时 `ref_msg.message_item` 只有 `type: 0` + `msg_id` + 时间戳，**正文完全不在里面**（样本 188 字节）。所以被引用内容除非自己存，否则无处可寻。
    - **ID 格式对得上**：我们发出的消息是裸数字（`7513221606025264904`），引用指向的也是裸数字；而用户自己发来的消息带 `v1:` 前缀。所以 `msg_id` 可用作主键。
    - 实现：`state.sentMessages`（按账号 → 会话两层键，每会话上限 40 条，超出丢最旧）+ `#resolveQuote`
    - 引用内容**放在 prompt 最前面**——用户的要求是*关于*它的，先看到被引用内容才读得懂「这个再展开说说」
    - 查不到时**明说**：`[引用了一条我发出的消息，但内容已不在缓存中（id …）]`。让 agent 知道"有引用但读不到"，好过它对着一个没头没尾的追问瞎猜
  - ✅ `reasoning-delta` 明确排除；纯工具回合不发空消息；**一个回合只发一条消息**（`finish` 按步骤触发，不能当回合结束）
  - ❌ **流式刷新（`message_state`）—— 不可实现，已放弃**。查证：[OpenClaw 官方文档](https://docs.openclaw.ai/zh-CN/concepts/streaming) 明确「**并不提供真正的 token 增量流式传输**」，且"预览流式传输"（更新预览消息）**只支持** Telegram / Discord / Slack / Matrix / Mattermost / MS Teams，**没有微信**。
    - 根因：预览流式传输需要**编辑消息**能力（如 Telegram 的 `editMessageText`），而 iLink 的 `SendMessageResp` **不返回消息 ID**，也没有任何编辑接口——**没有凭据，就没有"刷新"可言**
    - 官方对本渠道显式 `disableBlockStreaming: true`
    - **但"分块流式传输"已经在工作**：助手每写完一段就作为**普通消息**发出（实测截图里一轮出现三条独立气泡，就是它）。这不是编辑同一条消息，而是发多条——**已经是当前行为，无需再做**
  - ✅ **插话（`steer`）**：微信会话里后一条消息**打断**进行中的工作，而不是排在它后面。
    - DSH 的 `sessionController.prompt` 有 `mode: 'queue' | 'steer'`，编译产物里对应 `agent.followup(message)` 与 `agent.steer(message)`——**`steer` 注入正在跑的回合**
    - 关键性质：`this.running ? (mode === 'steer' ? 'steering' : 'queued') : 'transcript'`——**空闲时两种模式等价**，所以微信会话一律用 `steer` 是安全的，不必自己判断忙闲
    - **降级保底**：`steer` 可能被拒（目标回合已结束）。拒绝时自动改投 `queue`——**排队只是慢一点，丢消息无法补救**
    - **消息绝不静默丢失**：若插话与排队**都**失败，把用户原话**回发给用户**并提示重发，因为那是唯一的副本
  - ✅ **渠道身份注入**：告诉 agent 对方在手机上、**看不到这台电脑的屏幕和文件系统**、需要看东西就直接发。此前 agent 会让人"打开某个路径"，而对方根本够不到
    - **新会话的第一条消息里它单独发**。DSH 用第一条 prompt 给会话起名，而它看的是**整段文本**——提示词在里面，题目就变成「微信渠道对话支持」这类样板话。把提示词挪到末尾**不够**（实测新会话仍叫「微信渠道协助对话」），只有让它**不在那段文本里**才行
    - 之后的消息仍是完整一条，提示词附在末尾
  - ❌ **Markdown 过滤 —— 无需实现**。原计划照官方 `StreamingMarkdownFilter` 剥掉 `##`、删除 `![图](url)` 等。**实测微信客户端自带 Markdown 过滤**，这些符号本来就不会显示成噪声，因此这项取消
  - ✅ **手机端可回答交互提示（关键在于"只有手机"的用户不再被卡死）**：权限申请与多选提问原本只在桌面会话面板出现，而框架的应答者**失败即拒绝**（fail closed），所以不在电脑旁的用户会被永久卡住。
    - **机制（DSH 原生扩展点）**：`approval/request` 与 `user-questions/request` 都是 **waterfall** 事件——`Return an outcome to claim the request or call next() to delegate`。**认领微信绑定会话，其余 `next()` 交给桌面**，所以桌面行为完全不受影响
    - 事件载荷与应答（照官方实现）：`approval/request` 的 `agent` / `toolName` / `reason` / `signal` → 返回 `'allowed-once' | 'rejected' | 'cancelled'`；`user-questions/request` 的 `questions[{id,question,options[{label,description}],multiSelect}]` → 返回 `{ answers:[{id, selected:[label], custom?}] }`
    - 提示以**编号**发出，手机上按一个数字即可回答；也接受直接回文字。**权限**回复 `允许` / `拒绝`
    - **投递链最前面拦截答复**（`#settleInteraction`）：`1` / `允许` 是回答提示，**不能当新请求发给 agent**，否则既打扰 agent 又让提示永远悬着
    - **两条安全原则**：
      - **拒绝优先判定**——`不允许` 含 `允许`，子串匹配会把**拒绝当成同意**，所以先查否定词
      - **看不懂就不猜**——无法识别的回复**不当作决定**，提示重发并保持挂起；在权限上猜错等于**批准了用户没同意的事**
    - 同一会话的新提示会替换旧的（用户看的是最新那条，同时挂两个会让回复无法归属）
- ⏳ **第三档**：多账号、文档、发布
  - ~~白名单鉴权~~ **不需要**：iLink 机器人在协议层就只接收扫码绑定那一个账号的消息，且不是微信联系人（0.36.0 核实并更正）

### 会话列表与切换（已实机验证）

- ✅ **列表由通道直接发**，不靠 agent 转述。日志里出过：工具跑了、行也回来了，agent 却回**「已为你列出对话列表，请看上面的消息」**——指向一条**从未存在的消息**，因为工具结果只有 agent 看得到
- ✅ **默认只列微信会话 + 告知别处还有**，并**列出工作区名**（`另有 56 个对话在别的工作区（workplace、dsh_orb）`）。`/list` 与说大白话**走同一个渲染器**，同问同答
- ✅ **每个会话一个短 id**。同一工作区的会话共享工作区名，光看名字分不清；短 id 也能直接回给 `/switch`
- ✅ **切换失败也明确告知**（由通道发）。日志里：工具返回 `ok: false`，agent 却告诉用户**「已切过去了」**——失败时微信这边什么都没变，用户不发现不了。工具描述现在**明确禁止** agent 声称切换成功
- ✅ **可切换到任何工作区的会话**。早期 `/list all` 列出别的项目的会话，但按名字切换**只在微信工作区里搜**——列得出、点不动。现在：数字按**用户看到的那份列表**编号，题目与短 id 搜**全部工作区**（采纳时用**那个会话自己的工作区**，因为 DSH 固定 `cwd`）

验证状态（全部是真实链路跑出来的）：

| 验证项 | 方式 |
|---|---|
| 扫码登录、收消息、发消息 | 真实微信往返 |
| 无 `context_token` 的主动推送 | 真实发送，服务端接受 |
| 跨进程复用 token 与游标 | 重启进程后继续长轮询 |
| 普通消息路由到会话 | `你好` → 复用既有会话（新建=否） |
| 会话在重启后复用 | 重新挂载后仍指向同一 session |
| `/new` `/list` `/switch` `/current` | 真实微信往返，标记与切换均正确 |
| 无空格指令（`/switch1`） | 真实微信往返 |
| 出站图片 | 真实上传+发送，手机收到 |
| **入站图片** | 真实微信发图 → 87527 字节落盘 → **JPEG 有效、960×1280、EOI 完整** → agent 收到路径并产出第 3 回合回复 |
| 桌面端会话文件夹 | 工作区 `微信会话` 注册成功（`~/.dsh/storages/workspace.json`） |
| 设置页 | 单元测试覆盖加载、渲染、清理；**并按 DSH 真实设计令牌渲染截图，浅色/深色都确认过** |
| **跨工作区切换** | 真实微信往返：`switch target=微信或手机如何联系AI ok=true`，会话在 `workplace` 工作区 |
| **会话题目** | 真实微信新建会话 → 题目为**用户所问**（「北京今天天气如何」），非渠道样板话 |
| **渠道提示词的拆分** | 真实微信收到提示词**作为独立一条消息**到达 |

设置页外观的验证方式：样式取自 `client.js`，**设计令牌取自 DSH 自己的主题**（`@deepseek-ai/dsh-client-ui-theme`），渲染成 HTML 后截图比对。早先用 `color-mix(currentColor …)` 调灰阶，看着接近但**永远对不上**——app 的灰阶是**令牌**，不是透明度。
