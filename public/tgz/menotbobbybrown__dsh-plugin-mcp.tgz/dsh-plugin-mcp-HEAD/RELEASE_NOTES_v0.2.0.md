## 🚀 dsh-plugin-mcp v0.2.0: Full Claude Code MCP Parity

`dsh-plugin-mcp` v0.2.0 delivers the full developer experience, performance, and security model of Anthropic's Claude Code MCP subsystem into the DeepSeek Harness ecosystem.

---

### ✨ What's New in v0.2.0

#### 1. 💻 Dedicated CLI Management (`dsh-mcp`)
Manage your MCP servers directly from the terminal without manual YAML editing:
* `dsh-mcp list [--json]` — View all active servers, transports, scopes, and health status.
* `dsh-mcp add <name> --scope <user|project> --transport <stdio|sse|ws> -- <command> [args...]` — Add servers to `~/.dsh/mcp.json` or `.dsh/mcp.json`.
* `dsh-mcp test <name>` — Run live protocol handshakes, verify tool discovery, and benchmark round-trip latency.
* `dsh-mcp remove <name>` — Remove servers from scope configs.

#### 2. 📁 Multi-Scope Configuration Hierarchy
Mirrors Claude Code's multi-tier configuration resolution:
* **User Global Scope:** `~/.dsh/mcp.json`
* **Project Local Scope:** `.dsh/mcp.json` or `.mcp.json` in workspace root
* **Profile Scope:** Inlined `dsh.config.yaml` overrides

#### 3. 🛡️ Granular Tool Execution Permissions
Configurable execution rules:
* `allow` — Auto-approve safe read operations (e.g. `github_list_*`, `filesystem_read_*`).
* `ask` — Prompt for user confirmation on mutating actions (e.g. `postgres_query`, `filesystem_delete_*`).
* `deny` — Block sensitive or destructive commands.

#### 4. ⚡ LazyToolRegistry (Context Defender)
Prevents context window token blowout when 50+ MCP servers (500+ tools) are registered. Automatically registers lightweight stubs and streams full parameter schemas on demand.

#### 5. 🔄 Bidirectional MCP Sampling
Implements the MCP `sampling/createMessage` handler, allowing connected MCP server processes to request LLM completions through DeepSeek Harness.

---

### 🧪 Test Coverage
* **22/22 unit and integration tests passing** (`vitest`) across transports, CLI commands, scopes, permission managers, and lazy resolvers.
