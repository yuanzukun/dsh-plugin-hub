## 🚀 DeepSeek Harness Model Context Protocol (MCP) Bridge Plugin

`dsh-plugin-mcp` is an official-standard plugin for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) that connects DeepSeek agents to the entire ecosystem of [Model Context Protocol (MCP)](https://modelcontextprotocol.io) tools, resources, and prompt templates.

---

### ✨ Features
- 🔌 **Universal Transport Support:** Connects to any MCP server via `stdio`, `sse`, and `websocket`.
- 🛠️ **Automatic Tool Registration:** Seamlessly reflects MCP tools into the DSH tool registry with JSON Schema parameter validation.
- 📂 **Resource & Prompt Bridge:** Exposes external MCP resources and prompt templates directly into agent context.
- ⚡ **Resilient Execution:** Per-server timeout controls, lifecycle management, and non-blocking error handling.
- 🏷️ **Namespacing:** Automatic prefixing (`github_create_issue`, `postgres_query`) to avoid tool name collisions.
- 🧩 **Cordis Native:** Built on Cordis lifecycle hooks (`ctx.provide`, `ctx.on('ready')`, `ctx.on('dispose')`).

---

### 📦 Installation in DSH

```bash
# Install via DSH CLI
dsh plugin --profile web add "github:menotbobbybrown/dsh-plugin-mcp"
```

---

### 📄 Configuration Example

```yaml
plugins:
  mcp:
    prefixToolNames: true
    prefixDelimiter: "_"
    defaultTimeoutMs: 60000
    servers:
      github:
        type: stdio
        command: npx
        args: ["-y", "@modelcontextprotocol/server-github"]
        env:
          GITHUB_PERSONAL_ACCESS_TOKEN: "${GITHUB_TOKEN}"

      filesystem:
        type: stdio
        command: npx
        args: ["-y", "@modelcontextprotocol/server-filesystem", "./workspace"]
```
