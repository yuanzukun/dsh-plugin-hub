Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "🚀 DeepSeek Harness MCP 1-Line Quickstart" -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Docker is not installed. Please install Docker Desktop." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path .env)) {
    Write-Host "📄 Creating .env from .env.example..." -ForegroundColor Yellow
    Copy-Item .env.example .env
}

Write-Host "📦 Building and starting MCP containers..." -ForegroundColor Green
docker compose up -d

Write-Host ""
Write-Host "✅ DeepSeek Harness MCP is running!" -ForegroundColor Green
Write-Host "• List servers: docker compose run --rm dsh-mcp npx dsh-mcp list"
Write-Host "• Add server:   docker compose run --rm dsh-mcp npx dsh-mcp install github"
Write-Host "• Stop cluster: docker compose down"
