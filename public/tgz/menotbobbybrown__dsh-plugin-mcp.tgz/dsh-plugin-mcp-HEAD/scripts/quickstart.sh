#!/usr/bin/env bash
set -euo pipefail

echo "========================================="
echo "🚀 DeepSeek Harness MCP 1-Line Quickstart"
echo "========================================="

if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker and Docker Compose."
    exit 1
fi

if [ ! -f .env ]; then
    echo "📄 Creating .env from .env.example..."
    cp .env.example .env
fi

echo "📦 Building and starting MCP containers..."
docker compose up -d

echo ""
echo "✅ DeepSeek Harness MCP is running!"
echo "• List servers: docker compose run --rm dsh-mcp npx dsh-mcp list"
echo "• Add server:   docker compose run --rm dsh-mcp npx dsh-mcp install github"
echo "• Stop cluster: docker compose down"
