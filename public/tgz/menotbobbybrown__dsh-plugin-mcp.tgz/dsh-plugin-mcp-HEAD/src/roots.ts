import path from 'node:path';

export interface WorkspaceRoot {
  uri: string;
  name?: string;
}

/**
 * Workspace Roots Manager
 *
 * Implements the MCP `roots/list` client capability, advertising allowed
 * workspace folders to filesystem/git MCP servers and preventing path traversal
 * attacks outside of declared root boundaries.
 */
export class WorkspaceRootsManager {
  private roots: Map<string, WorkspaceRoot> = new Map();

  constructor(initialRoots: Array<{ path: string; name?: string }> = []) {
    for (const r of initialRoots) {
      this.addRoot(r.path, r.name);
    }
  }

  public addRoot(fsPath: string, name?: string): void {
    const resolved = path.resolve(fsPath);
    const uri = `file://${resolved.replace(/\\/g, '/')}`;
    this.roots.set(resolved, {
      uri,
      name: name || path.basename(resolved),
    });
  }

  public removeRoot(fsPath: string): void {
    const resolved = path.resolve(fsPath);
    this.roots.delete(resolved);
  }

  public listRoots(): WorkspaceRoot[] {
    return Array.from(this.roots.values());
  }

  /**
   * Verifies if a given file/folder path falls strictly within one of the registered roots.
   */
  public isPathWithinRoots(targetPath: string): boolean {
    if (this.roots.size === 0) return true; // Unrestricted if no roots declared

    const resolvedTarget = path.resolve(targetPath);
    for (const rootPath of this.roots.keys()) {
      const relative = path.relative(rootPath, resolvedTarget);
      if (!relative.startsWith('..') && !path.isAbsolute(relative)) {
        return true;
      }
    }
    return false;
  }
}
