import type { Client } from '@modelcontextprotocol/sdk/client/index.js';
import type { CallToolResult } from '@modelcontextprotocol/sdk/types.js';
import type { DshToolDefinition } from './types.js';
import type { ManagedServer } from './client-manager.js';

export interface ToolAdapterOptions {
  prefixToolNames?: boolean;
  prefixDelimiter?: string;
  defaultTimeoutMs?: number;
}

export class ToolAdapter {
  private prefixToolNames: boolean;
  private prefixDelimiter: string;
  private defaultTimeoutMs: number;

  constructor(options: ToolAdapterOptions = {}) {
    this.prefixToolNames = options.prefixToolNames ?? true;
    this.prefixDelimiter = options.prefixDelimiter ?? '_';
    this.defaultTimeoutMs = options.defaultTimeoutMs ?? 60000;
  }

  /**
   * Fetches and converts all tools from a connected MCP server into DSH tool definitions.
   */
  public async extractToolsFromServer(server: ManagedServer): Promise<DshToolDefinition[]> {
    if (!server.connected || !server.client) {
      return [];
    }

    try {
      const response = await server.client.listTools();
      const tools = response.tools || [];

      return tools.map((mcpTool) => {
        const formattedName = this.formatToolName(server.name, mcpTool.name);
        const timeoutMs = server.config.timeoutMs || this.defaultTimeoutMs;

        const toolDef: DshToolDefinition = {
          name: formattedName,
          originalName: mcpTool.name,
          serverName: server.name,
          description: mcpTool.description || `Execute ${mcpTool.name} on ${server.name} MCP server`,
          parameters: (mcpTool.inputSchema as Record<string, any>) || {
            type: 'object',
            properties: {},
          },
          execute: async (args: Record<string, any>) => {
            return this.executeToolWithTimeout(server.client, mcpTool.name, args, timeoutMs);
          },
        };

        return toolDef;
      });
    } catch (err: any) {
      console.error(`[dsh-plugin-mcp] Failed to list tools for server '${server.name}':`, err?.message || err);
      return [];
    }
  }

  /**
   * Formats tool name with server namespace prefix if enabled.
   */
  public formatToolName(serverName: string, originalToolName: string): string {
    if (!this.prefixToolNames) {
      return originalToolName;
    }
    // Clean server name to ensure valid identifier
    const safeServer = serverName.replace(/[^a-zA-Z0-9_]/g, '_');
    return `${safeServer}${this.prefixDelimiter}${originalToolName}`;
  }

  /**
   * Executes an MCP tool call with a timeout barrier and result normalization.
   */
  private async executeToolWithTimeout(
    client: Client,
    toolName: string,
    args: Record<string, any>,
    timeoutMs: number
  ): Promise<any> {
    let timer: NodeJS.Timeout | undefined;

    const timeoutPromise = new Promise<never>((_, reject) => {
      timer = setTimeout(() => {
        reject(new Error(`MCP Tool call '${toolName}' timed out after ${timeoutMs}ms`));
      }, timeoutMs);
    });

    try {
      const executionPromise = client.callTool({
        name: toolName,
        arguments: args,
      });

      const result = (await Promise.race([executionPromise, timeoutPromise])) as CallToolResult;
      return this.formatToolResult(result);
    } catch (err: any) {
      return {
        isError: true,
        error: err?.message || String(err),
      };
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  /**
   * Normalizes MCP CallToolResult content blocks into DSH output format.
   */
  public formatToolResult(result: CallToolResult): any {
    if (!result) {
      return { content: '' };
    }

    const contentBlocks = result.content || [];
    const textOutputs: string[] = [];
    const artifacts: any[] = [];

    for (const block of contentBlocks) {
      if (block.type === 'text') {
        textOutputs.push(block.text);
      } else if (block.type === 'image') {
        artifacts.push({
          type: 'image',
          mimeType: block.mimeType,
          data: block.data,
        });
      } else if (block.type === 'resource') {
        artifacts.push({
          type: 'resource',
          resource: block.resource,
        });
      }
    }

    const textSummary = textOutputs.join('\n');

    if (artifacts.length === 0) {
      // If result was explicitly marked as error by MCP server
      if (result.isError) {
        return {
          isError: true,
          content: textSummary || 'Tool execution returned error status',
        };
      }
      return textSummary;
    }

    return {
      isError: result.isError ?? false,
      content: textSummary,
      artifacts,
    };
  }
}
