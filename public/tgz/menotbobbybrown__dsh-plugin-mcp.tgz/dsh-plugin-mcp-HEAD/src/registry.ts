import type { MCPServerConfig } from './types.js';

export interface CatalogServerDefinition {
  name: string;
  description: string;
  category: 'developer' | 'database' | 'search' | 'filesystem' | 'collaboration' | 'browser';
  configTemplate: MCPServerConfig;
  requiredEnvVars?: string[];
  homepage?: string;
}

/**
 * Built-in Curated MCP Server Catalog
 *
 * Pre-configured registry of popular official & community MCP servers
 * enabling 1-click installation without memorizing package names or arguments.
 */
export const POPULAR_MCP_SERVERS: Record<string, CatalogServerDefinition> = {
  github: {
    name: 'GitHub',
    description: 'Inspect repositories, create/search issues, read pull requests, and manage branches',
    category: 'developer',
    configTemplate: {
      type: 'stdio',
      command: 'npx',
      args: ['-y', '@modelcontextprotocol/server-github'],
      env: { GITHUB_PERSONAL_ACCESS_TOKEN: '${GITHUB_TOKEN}' },
    },
    requiredEnvVars: ['GITHUB_TOKEN'],
    homepage: 'https://github.com/modelcontextprotocol/servers/tree/main/src/github',
  },
  filesystem: {
    name: 'Filesystem',
    description: 'Direct local workspace filesystem read, write, and directory navigation',
    category: 'filesystem',
    configTemplate: {
      type: 'stdio',
      command: 'npx',
      args: ['-y', '@modelcontextprotocol/server-filesystem', './workspace'],
    },
    homepage: 'https://github.com/modelcontextprotocol/servers/tree/main/src/filesystem',
  },
  postgres: {
    name: 'PostgreSQL',
    description: 'Read-only and read-write SQL queries, schema inspection, and table analysis for Postgres',
    category: 'database',
    configTemplate: {
      type: 'stdio',
      command: 'npx',
      args: ['-y', '@modelcontextprotocol/server-postgres', '${DATABASE_URL}'],
    },
    requiredEnvVars: ['DATABASE_URL'],
    homepage: 'https://github.com/modelcontextprotocol/servers/tree/main/src/postgres',
  },
  sqlite: {
    name: 'SQLite',
    description: 'Zero-config local SQLite database schema inspection and SQL queries',
    category: 'database',
    configTemplate: {
      type: 'stdio',
      command: 'npx',
      args: ['-y', '@modelcontextprotocol/server-sqlite', './data.db'],
    },
    homepage: 'https://github.com/modelcontextprotocol/servers/tree/main/src/sqlite',
  },
  brave_search: {
    name: 'Brave Search',
    description: 'Privacy-focused web search, news queries, and link resolution via Brave Search API',
    category: 'search',
    configTemplate: {
      type: 'stdio',
      command: 'npx',
      args: ['-y', '@modelcontextprotocol/server-brave-search'],
      env: { BRAVE_API_KEY: '${BRAVE_API_KEY}' },
    },
    requiredEnvVars: ['BRAVE_API_KEY'],
    homepage: 'https://github.com/modelcontextprotocol/servers/tree/main/src/brave-search',
  },
  fetch: {
    name: 'Fetch',
    description: 'Fetch and parse web page contents into clean Markdown for agent reading',
    category: 'search',
    configTemplate: {
      type: 'stdio',
      command: 'npx',
      args: ['-y', '@modelcontextprotocol/server-fetch'],
    },
    homepage: 'https://github.com/modelcontextprotocol/servers/tree/main/src/fetch',
  },
  puppeteer: {
    name: 'Puppeteer',
    description: 'Headless browser automation, page navigation, form interaction, and screenshots',
    category: 'browser',
    configTemplate: {
      type: 'stdio',
      command: 'npx',
      args: ['-y', '@modelcontextprotocol/server-puppeteer'],
    },
    homepage: 'https://github.com/modelcontextprotocol/servers/tree/main/src/puppeteer',
  },
  memory: {
    name: 'Knowledge Graph Memory',
    description: 'Graph-based long-term memory for entity relationships across conversation sessions',
    category: 'developer',
    configTemplate: {
      type: 'stdio',
      command: 'npx',
      args: ['-y', '@modelcontextprotocol/server-memory'],
    },
    homepage: 'https://github.com/modelcontextprotocol/servers/tree/main/src/memory',
  },
  agent_reach: {
    name: 'Agent Reach',
    description: 'Zero-API-cost social and web search across Twitter/X, Reddit, YouTube transcripts, and GitHub',
    category: 'search',
    configTemplate: {
      type: 'stdio',
      command: 'npx',
      args: ['-y', 'agent-reach-mcp'],
    },
    homepage: 'https://github.com/Panniantong/Agent-Reach',
  },
};

export class ServerRegistry {
  public static getAvailableServers(): CatalogServerDefinition[] {
    return Object.values(POPULAR_MCP_SERVERS);
  }

  public static findServer(name: string): CatalogServerDefinition | undefined {
    const key = name.toLowerCase().replace(/[-_\s]/g, '_');
    return POPULAR_MCP_SERVERS[key] || Object.values(POPULAR_MCP_SERVERS).find(
      (srv) => srv.name.toLowerCase() === name.toLowerCase()
    );
  }
}
