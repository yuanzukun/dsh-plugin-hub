import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import type { DshToolDefinition, DshResourceDefinition } from './types.js';

export interface CachedServerMetadata {
  serverName: string;
  tools: Array<{
    name: string;
    originalName: string;
    description: string;
    parameters: Record<string, any>;
  }>;
  resources: Array<{
    uri: string;
    name: string;
    description?: string;
    mimeType?: string;
  }>;
  cachedAt: string;
  hash: string;
}

/**
 * Two-Tier Schema Cache (L1 Memory LRU + L2 Disk Snapshot)
 *
 * Prevents re-running `tools/list` on every cold boot across 1,000+ servers.
 */
export class SchemaCache {
  private memoryCache: Map<string, CachedServerMetadata> = new Map();
  private cacheFilePath: string;
  private maxMemoryEntries: number;

  constructor(options: { cachePath?: string; maxMemoryEntries?: number } = {}) {
    this.cacheFilePath =
      options.cachePath ||
      path.join(os.homedir(), '.dsh', 'cache', 'mcp-schemas.json');
    this.maxMemoryEntries = options.maxMemoryEntries || 1000;
    this.loadL2FromDisk();
  }

  private loadL2FromDisk(): void {
    try {
      if (fs.existsSync(this.cacheFilePath)) {
        const raw = fs.readFileSync(this.cacheFilePath, 'utf-8');
        const parsed = JSON.parse(raw);
        if (typeof parsed === 'object' && parsed !== null) {
          for (const [key, val] of Object.entries(parsed)) {
            this.memoryCache.set(key, val as CachedServerMetadata);
          }
        }
      }
    } catch {
      // Fallback cleanly on corrupted cache
    }
  }

  public saveL2ToDisk(): void {
    try {
      const dir = path.dirname(this.cacheFilePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      const data: Record<string, CachedServerMetadata> = {};
      for (const [k, v] of this.memoryCache.entries()) {
        data[k] = v;
      }
      fs.writeFileSync(this.cacheFilePath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.warn('[dsh-plugin-mcp] Failed to write L2 schema cache:', err);
    }
  }

  public set(serverName: string, metadata: Omit<CachedServerMetadata, 'cachedAt'>): void {
    const entry: CachedServerMetadata = {
      ...metadata,
      cachedAt: new Date().toISOString(),
    };

    // LRU eviction for L1
    if (this.memoryCache.size >= this.maxMemoryEntries) {
      const oldestKey = this.memoryCache.keys().next().value;
      if (oldestKey) this.memoryCache.delete(oldestKey);
    }

    this.memoryCache.set(serverName, entry);
    this.saveL2ToDisk();
  }

  public get(serverName: string): CachedServerMetadata | undefined {
    return this.memoryCache.get(serverName);
  }

  public has(serverName: string): boolean {
    return this.memoryCache.has(serverName);
  }

  public invalidate(serverName: string): boolean {
    const deleted = this.memoryCache.delete(serverName);
    if (deleted) this.saveL2ToDisk();
    return deleted;
  }

  public clear(): void {
    this.memoryCache.clear();
    this.saveL2ToDisk();
  }

  public size(): number {
    return this.memoryCache.size;
  }
}
