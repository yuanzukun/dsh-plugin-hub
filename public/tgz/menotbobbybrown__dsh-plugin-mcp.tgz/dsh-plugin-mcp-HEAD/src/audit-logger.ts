import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { SecurityEngine } from './security.js';

export interface AuditEvent {
  timestamp: string;
  eventType: 'TOOL_EXECUTION' | 'PERMISSION_CHECK' | 'SERVER_CONNECT' | 'SECURITY_VIOLATION';
  toolName?: string;
  serverName?: string;
  verdict?: 'allow' | 'ask' | 'deny';
  durationMs?: number;
  success?: boolean;
  error?: string;
  metadata?: Record<string, unknown>;
}

/**
 * Security Audit Logger
 *
 * Implements structured, append-only security logs for compliance,
 * threat detection, and forensic tracing in enterprise environments.
 */
export class AuditLogger {
  private logPath: string;
  private enableConsole: boolean;

  constructor(options: { logPath?: string; enableConsole?: boolean } = {}) {
    this.logPath =
      options.logPath || path.join(os.homedir(), '.dsh', 'mcp-audit.log');
    this.enableConsole = options.enableConsole ?? false;
  }

  public logEvent(event: Omit<AuditEvent, 'timestamp'>): void {
    const fullEvent: AuditEvent = {
      timestamp: new Date().toISOString(),
      ...event,
    };

    const sanitizedLine = SecurityEngine.maskSecrets(JSON.stringify(fullEvent));

    if (this.enableConsole) {
      console.log(`[dsh-mcp-audit] ${sanitizedLine}`);
    }

    try {
      const dir = path.dirname(this.logPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.appendFileSync(this.logPath, `${sanitizedLine}\n`, 'utf-8');
    } catch {
      // Non-blocking fallback
    }
  }
}
