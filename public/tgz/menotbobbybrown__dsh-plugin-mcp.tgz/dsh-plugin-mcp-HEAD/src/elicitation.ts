export interface ElicitationField {
  name: string;
  label: string;
  type: 'string' | 'number' | 'boolean' | 'select';
  description?: string;
  options?: string[];
  required?: boolean;
  defaultValue?: unknown;
}

export interface ElicitationRequest {
  id: string;
  serverName: string;
  title: string;
  description?: string;
  fields: ElicitationField[];
  timeoutMs?: number;
}

export type ElicitationHandler = (
  request: ElicitationRequest
) => Promise<Record<string, unknown>>;

/**
 * Interactive Elicitation Manager
 *
 * Coordinates interactive user prompts, form parameters, and approvals
 * requested by MCP servers during complex multi-step workflows.
 */
export class ElicitationManager {
  private handler?: ElicitationHandler;
  private pendingRequests: Map<string, {
    request: ElicitationRequest;
    resolve: (val: Record<string, unknown>) => void;
    reject: (err: Error) => void;
  }> = new Map();

  constructor(handler?: ElicitationHandler) {
    this.handler = handler;
  }

  public setHandler(handler: ElicitationHandler): void {
    this.handler = handler;
  }

  /**
   * Dispatches an elicitation prompt to the registered UI/CLI handler.
   */
  public async promptUser(request: ElicitationRequest): Promise<Record<string, unknown>> {
    if (this.handler) {
      return this.handler(request);
    }

    // Default fallback: return default values for all required fields
    const defaultValues: Record<string, unknown> = {};
    for (const field of request.fields) {
      if (field.defaultValue !== undefined) {
        defaultValues[field.name] = field.defaultValue;
      }
    }
    return defaultValues;
  }

  public getPendingRequestsCount(): number {
    return this.pendingRequests.size;
  }
}
