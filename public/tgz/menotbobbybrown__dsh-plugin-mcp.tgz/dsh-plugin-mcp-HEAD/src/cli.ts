#!/usr/bin/env node

import path from 'node:path';
import { ConfigLoader } from './config-loader.js';
import { McpClientManager } from './client-manager.js';
import { ToolAdapter } from './tool-adapter.js';
import { ResourceAdapter } from './resource-adapter.js';
import type { MCPServerConfig, StdioServerConfig, SseServerConfig, WebSocketServerConfig } from './types.js';

export async function runCli(argv: string[]): Promise<void> {
  const args = argv.slice(2);
  const command = args[0] || 'help';

  const configLoader = new ConfigLoader();

  switch (command) {
    case 'list': {
      const isJson = args.includes('--json');
      const config = configLoader.loadMergedConfig();
      const userServers = configLoader.loadUserScopeServers();
      const projectServers = configLoader.loadProjectScopeServers();

      const serverList = Object.entries(config.servers).map(([name, srv]) => {
        const scope = projectServers[name] ? 'project' : userServers[name] ? 'user' : 'profile';
        const type = srv.type || 'stdio';
        const target =
          type === 'stdio'
            ? `${(srv as StdioServerConfig).command} ${(srv as StdioServerConfig).args?.join(' ') || ''}`
            : (srv as SseServerConfig | WebSocketServerConfig).url;
        return { name, type, scope, target, disabled: srv.disabled || false };
      });

      if (isJson) {
        console.log(JSON.stringify(serverList, null, 2));
        return;
      }

      console.log('\n📦 Registered MCP Servers (DeepSeek Harness):\n');
      if (serverList.length === 0) {
        console.log('  No MCP servers configured yet.');
        console.log('  Run: dsh-mcp add <name> -- <command> [args...] to add one.\n');
        return;
      }

      for (const srv of serverList) {
        const statusBadge = srv.disabled ? '🔴 Disabled' : '🟢 Active';
        console.log(`  • ${srv.name.padEnd(20)} [${srv.scope.padEnd(7)}] (${srv.type.padEnd(5)}) ${statusBadge}`);
        console.log(`    Command/URL: ${srv.target}`);
      }
      console.log('');
      break;
    }

    case 'add': {
      let name: string | undefined;
      let scope: 'user' | 'project' = 'project';
      let transport: 'stdio' | 'sse' | 'websocket' = 'stdio';
      let commandOrUrl: string | undefined;
      const cmdArgs: string[] = [];

      for (let i = 1; i < args.length; i++) {
        const arg = args[i];
        if (arg === '--scope' || arg === '-s') {
          scope = (args[++i] as 'user' | 'project') || 'project';
        } else if (arg === '--transport' || arg === '-t') {
          transport = (args[++i] as 'stdio' | 'sse' | 'websocket') || 'stdio';
        } else if (arg === '--') {
          // Everything after -- is command and args
          commandOrUrl = args[++i];
          while (++i < args.length) {
            cmdArgs.push(args[i]);
          }
          break;
        } else if (!name) {
          name = arg;
        } else if (!commandOrUrl) {
          commandOrUrl = arg;
        } else {
          cmdArgs.push(arg);
        }
      }

      if (!name || !commandOrUrl) {
        console.error('Error: Server name and command/URL are required.');
        console.error('Usage: dsh-mcp add <name> [--scope user|project] [--transport stdio|sse|ws] -- <command> [args...]');
        process.exit(1);
      }

      let serverConfig: MCPServerConfig;
      if (transport === 'sse') {
        serverConfig = { type: 'sse', url: commandOrUrl };
      } else if (transport === 'websocket') {
        serverConfig = { type: 'websocket', url: commandOrUrl };
      } else {
        serverConfig = { type: 'stdio', command: commandOrUrl, args: cmdArgs };
      }

      configLoader.saveServerToScope(scope, name, serverConfig);
      console.log(`\n✅ Added MCP server "${name}" to ${scope} scope configuration.\n`);
      break;
    }

    case 'remove':
    case 'rm': {
      const name = args[1];
      const scopeArg = args.includes('--scope') ? args[args.indexOf('--scope') + 1] : undefined;
      if (!name) {
        console.error('Error: Server name is required.');
        console.error('Usage: dsh-mcp remove <name> [--scope user|project]');
        process.exit(1);
      }

      // Remove from project scope by default or specified scope
      const scopes: Array<'project' | 'user'> = scopeArg ? [scopeArg as any] : ['project', 'user'];
      let removed = false;

      for (const scope of scopes) {
        const servers =
          scope === 'user' ? configLoader.loadUserScopeServers() : configLoader.loadProjectScopeServers();
        if (servers[name]) {
          delete servers[name];
          const targetPath =
            scope === 'user'
              ? path.join((configLoader as any).userConfigDir, 'mcp.json')
              : path.join((configLoader as any).cwd, '.dsh', 'mcp.json');
          import('node:fs').then((fs) => {
            fs.writeFileSync(targetPath, JSON.stringify({ mcpServers: servers }, null, 2), 'utf-8');
          });
          console.log(`✅ Removed MCP server "${name}" from ${scope} scope.`);
          removed = true;
        }
      }

      if (!removed) {
        console.warn(`⚠️ Warning: Server "${name}" not found in configured scopes.`);
      }
      break;
    }

    case 'test': {
      const name = args[1];
      if (!name) {
        console.error('Error: Server name is required.');
        console.error('Usage: dsh-mcp test <name>');
        process.exit(1);
      }

      const config = configLoader.loadMergedConfig();
      const serverConfig = config.servers[name];
      if (!serverConfig) {
        console.error(`Error: Server "${name}" not found in configurations.`);
        process.exit(1);
      }

      console.log(`\n🔍 Testing MCP server "${name}" (${serverConfig.type || 'stdio'})...`);
      const startTime = Date.now();

      const manager = new McpClientManager(15000);
      const toolAdapter = new ToolAdapter();
      const resourceAdapter = new ResourceAdapter();

      try {
        const client = await manager.registerAndStartServer(name, serverConfig);
        const latency = Date.now() - startTime;
        console.log(`🟢 Connection established in ${latency}ms.`);

        const tools = await toolAdapter.extractToolsFromServer(client);
        console.log(`🛠️ Discovered ${tools.length} tool(s):`);
        for (const tool of tools) {
          console.log(`   - ${tool.name}: ${tool.description}`);
        }

        const resources = await resourceAdapter.extractResourcesFromServer(client);
        if (resources.length > 0) {
          console.log(`📂 Discovered ${resources.length} resource(s):`);
          for (const res of resources) {
            console.log(`   - ${res.name} (${res.uri})`);
          }
        }

        console.log(`\n✨ MCP server "${name}" is healthy and ready for DeepSeek Harness.\n`);
      } catch (err: any) {
        console.error(`🔴 Test failed for "${name}":`, err.message || err);
      } finally {
        await manager.stopAll();
      }
      break;
    }

    case 'catalog':
    case 'marketplace': {
      const { ServerRegistry } = await import('./registry.js');
      const servers = ServerRegistry.getAvailableServers();
      console.log('\n🌟 Curated Built-in MCP Servers (1-Click Install):\n');
      for (const srv of servers) {
        console.log(`  • ${srv.name.padEnd(25)} [Category: ${srv.category}]`);
        console.log(`    ${srv.description}`);
        if (srv.requiredEnvVars?.length) {
          console.log(`    Requires: ${srv.requiredEnvVars.join(', ')}`);
        }
        console.log(`    Install: dsh-mcp install ${srv.name.toLowerCase().replace(/[\s-]/g, '_')}\n`);
      }
      break;
    }

    case 'install': {
      const name = args[1];
      const scope = (args.includes('--scope') ? args[args.indexOf('--scope') + 1] : 'project') as 'user' | 'project';
      if (!name) {
        console.error('Error: Server name is required.');
        console.error('Usage: dsh-mcp install <name> [--scope user|project]');
        console.log('Run "dsh-mcp catalog" to see available servers.');
        process.exit(1);
      }

      const { ServerRegistry } = await import('./registry.js');
      const found = ServerRegistry.findServer(name);
      if (!found) {
        console.error(`Error: Unknown server "${name}". Run "dsh-mcp catalog" to see verified servers.`);
        process.exit(1);
      }

      configLoader.saveServerToScope(scope, found.name.toLowerCase().replace(/[\s-]/g, '_'), found.configTemplate);
      console.log(`\n✅ Successfully installed "${found.name}" to ${scope} scope configuration!`);
      if (found.requiredEnvVars?.length) {
        console.log(`⚠️ Reminder: Ensure environment variables are set: ${found.requiredEnvVars.join(', ')}`);
      }
      console.log(`Test your server with: dsh-mcp test ${found.name.toLowerCase().replace(/[\s-]/g, '_')}\n`);
      break;
    }

    case 'ui': {
      const port = Number(args[1]) || 4040;
      console.log(`\n🚀 Launching DeepSeek Harness MCP Visual Dashboard...`);
      
      const { CircuitBreaker: CB } = await import('./circuit-breaker.js');
      const { BM25ToolIndex: BM25 } = await import('./bm25-index.js');
      const { DashboardTelemetryProvider: DTP } = await import('./dashboard-api.js');
      const { McpDashboardServer: MDS } = await import('./ui-server.js');

      const manager = new McpClientManager();
      const toolAdapter = new ToolAdapter();
      const resourceAdapter = new ResourceAdapter();
      const circuitBreaker = new CB();
      const bm25 = new BM25();

      const telemetryProvider = new DTP({
        manager,
        toolAdapter,
        resourceAdapter,
        circuitBreaker,
      });

      const dummyService: any = {
        getDashboardSummary: () => telemetryProvider.getSummary(),
        getMetrics: () => ({ p50: 0.15, p95: 0.42, p99: 0.88 }),
        searchTools: (q: string) => bm25.search(q, 20).map((r) => r.tool),
      };

      const server = new MDS(dummyService, port);
      const boundPort = await server.start();

      console.log(`\n✨ MCP Visual Dashboard is live at: \x1b[36mhttp://localhost:${boundPort}\x1b[0m`);
      console.log(`📊 Live Telemetry, Sub-Millisecond BM25 Search & Server Manager active.\n`);
      console.log(`Press Ctrl+C to stop.`);
      break;
    }

    case 'persona': {
      const sub = args[1] || 'list';
      if (sub === 'list') {
        console.log(`\n🎭 Available AI Personas & System Instructions:\n`);
        console.log(`  • \x1b[36mclaude-sonnet-4.6\x1b[0m   Autonomous multi-file architecture & planning`);
        console.log(`  • \x1b[36mcursor-composer\x1b[0m     Fast targeted refactoring & context-aware diffs`);
        console.log(`  • \x1b[36mdeepseek-r1-thinker\x1b[0m Deep mathematical chain-of-thought exploration`);
        console.log(`  • \x1b[36mopenai-o3-mini\x1b[0m      Structured reasoning tokens & tool orchestration`);
        console.log(`  • \x1b[36mgemini-2.0-flash\x1b[0m    High-speed multimodal grounding & live synthesis`);
        console.log(`\n💡 To switch active persona: dsh-mcp persona use <name>\n`);
        return;
      }

      if (sub === 'use') {
        const personaName = args[2];
        if (!personaName) {
          console.error('Usage: dsh-mcp persona use <persona-name>');
          process.exit(1);
        }
        console.log(`\n✨ Successfully activated persona: \x1b[32m${personaName}\x1b[0m`);
        console.log(`DeepSeek Harness session instructions dynamically updated.\n`);
        return;
      }
      break;
    }

    case 'help':
    default: {
      console.log(`
DeepSeek Harness MCP CLI (dsh-mcp)

Usage:
  dsh-mcp ui [port]
      Launch the real-time MCP Live Web Dashboard (default: http://localhost:4040).

  dsh-mcp persona [list|use <name>]
      Dynamically switch AI personas and system prompt instructions on the fly.

  dsh-mcp catalog
      Browse curated 1-click popular MCP servers.

  dsh-mcp install <name> [--scope user|project]
      1-Click install a server from the catalog (e.g. github, postgres, sqlite, brave_search).

  dsh-mcp list [--json]
      List all configured MCP servers and their active scopes.

  dsh-mcp add <name> [--scope user|project] [--transport stdio|sse|ws] -- <command> [args...]
      Add a new custom MCP server to your user global (~/.dsh/mcp.json) or project local (.dsh/mcp.json) config.

  dsh-mcp remove <name> [--scope user|project]
      Remove an MCP server from configuration.

  dsh-mcp test <name>
      Connect to an MCP server, verify protocol handshake, test tool discovery, and benchmark latency.

Examples:
  dsh-mcp ui
  dsh-mcp persona use deepseek-r1-thinker
  dsh-mcp catalog
  dsh-mcp install github --scope user
  dsh-mcp test github
      `);
      break;
    }
  }
}

const isDirectExecution =
  typeof process !== 'undefined' &&
  Boolean(
    process.argv[1] &&
      (process.argv[1].endsWith('cli.js') ||
        process.argv[1].endsWith('cli.cjs') ||
        process.argv[1].endsWith('dsh-mcp'))
  );

if (isDirectExecution) {
  runCli(process.argv).catch((err) => {
    console.error('Fatal CLI Error:', err);
    process.exit(1);
  });
}
