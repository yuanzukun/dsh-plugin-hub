import path from 'node:path';

/**
 * Enterprise Security Engine for MCP Clients
 *
 * Implements secrets sanitization, command injection defenses,
 * path traversal guards, and telemetry protection.
 */
export class SecurityEngine {
  private static SENSITIVE_KEY_PATTERNS = [
    /key/i,
    /secret/i,
    /token/i,
    /password/i,
    /auth/i,
    /credential/i,
    /bearer/i,
    /private/i,
  ];

  /**
   * Masks sensitive environment variables and credentials in logs and outputs.
   */
  public static maskSecrets(text: string, sensitiveValues: string[] = []): string {
    let sanitized = text;

    // Mask explicit sensitive values
    for (const val of sensitiveValues) {
      if (val && val.length > 3) {
        const regex = new RegExp(val.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
        sanitized = sanitized.replace(regex, '***REDACTED***');
      }
    }

    // Mask common key patterns (e.g. Bearer tokens, API keys)
    sanitized = sanitized
      .replace(/(Bearer\s+)[A-Za-z0-9\-_.]+/gi, '$1***REDACTED***')
      .replace(/(sk-[A-Za-z0-9_-]{20,})/gi, '***REDACTED_API_KEY***')
      .replace(/(ghp_[A-Za-z0-9]{36})/gi, '***REDACTED_GITHUB_TOKEN***')
      .replace(/(gho_[A-Za-z0-9]{36})/gi, '***REDACTED_OAUTH_TOKEN***');

    return sanitized;
  }

  /**
   * Sanitizes environment variable dictionary for safe logging and process spawn.
   */
  public static sanitizeEnvForLogging(env: Record<string, string>): Record<string, string> {
    const sanitized: Record<string, string> = {};
    for (const [k, v] of Object.entries(env)) {
      const isSensitive = this.SENSITIVE_KEY_PATTERNS.some((pattern) => pattern.test(k));
      sanitized[k] = isSensitive ? '***REDACTED***' : v;
    }
    return sanitized;
  }

  /**
   * Validates and guards against path traversal attempts.
   */
  public static isSafePath(targetPath: string, allowedBaseDir?: string): boolean {
    if (!targetPath) return false;

    // Check for null bytes
    if (targetPath.includes('\0')) return false;

    if (allowedBaseDir) {
      const resolvedTarget = path.resolve(targetPath);
      const resolvedBase = path.resolve(allowedBaseDir);
      const relative = path.relative(resolvedBase, resolvedTarget);
      return !relative.startsWith('..') && !path.isAbsolute(relative);
    }

    return true;
  }

  /**
   * Validates command and arguments against obvious shell injection patterns.
   */
  public static validateCommandSafety(command: string, args: string[] = []): { safe: boolean; reason?: string } {
    const suspiciousTokens = ['&&', '||', ';', '|', '`', '$(', '>', '<'];

    // Check command name
    for (const token of suspiciousTokens) {
      if (command.includes(token)) {
        return { safe: false, reason: `Command contains forbidden shell metacharacter: "${token}"` };
      }
    }

    // Check args
    for (const arg of args) {
      if (arg.includes('\0')) {
        return { safe: false, reason: 'Argument contains illegal null byte' };
      }
    }

    return { safe: true };
  }
}
