import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { parseConfig } from './schema.js';
import type { DshMcpPluginConfig, MCPServerConfig, StdioServerConfig } from './types.js';

export interface ScopeOptions {
  cwd?: string;
  userConfigDir?: string;
  enableProjectScope?: boolean;
  enableUserScope?: boolean;
}

/**
 * Resolves MCP server configurations across User Global, Project Local, and Profile scopes.
 * Mirrors Claude Code's multi-scope configuration model.
 */
export class ConfigLoader {
  private cwd: string;
  private userConfigDir: string;
  private enableProjectScope: boolean;
  private enableUserScope: boolean;

  constructor(options: ScopeOptions = {}) {
    this.cwd = options.cwd || process.cwd();
    this.userConfigDir = options.userConfigDir || path.join(os.homedir(), '.dsh');
    this.enableProjectScope = options.enableProjectScope ?? true;
    this.enableUserScope = options.enableUserScope ?? true;
  }

  /**
   * Discovers and merges configurations in order of precedence:
   * 1. Inline Profile Configuration (highest precedence)
   * 2. Project Scope (.dsh/mcp.json or .mcp.json)
   * 3. User Global Scope (~/.dsh/mcp.json)
   */
  public loadMergedConfig(inlineConfig?: unknown): DshMcpPluginConfig {
    const baseConfig = parseConfig(inlineConfig || {});
    const mergedServers: Record<string, MCPServerConfig> = {};

    // 1. Load User Global Scope
    if (this.enableUserScope) {
      const userServers = this.loadUserScopeServers();
      Object.assign(mergedServers, userServers);
    }

    // 2. Load Project Scope
    if (this.enableProjectScope) {
      const projectServers = this.loadProjectScopeServers();
      Object.assign(mergedServers, projectServers);
    }

    // 3. Merge Profile Config (Overrides user and project)
    if (baseConfig.servers) {
      Object.assign(mergedServers, baseConfig.servers);
    }

    return {
      ...baseConfig,
      servers: mergedServers,
    };
  }

  public loadUserScopeServers(): Record<string, MCPServerConfig> {
    const userPath = path.join(this.userConfigDir, 'mcp.json');
    return this.readJsonServers(userPath);
  }

  public loadProjectScopeServers(): Record<string, MCPServerConfig> {
    const dshProjectPath = path.join(this.cwd, '.dsh', 'mcp.json');
    const rootProjectPath = path.join(this.cwd, '.mcp.json');

    if (fs.existsSync(dshProjectPath)) {
      return this.readJsonServers(dshProjectPath);
    }
    if (fs.existsSync(rootProjectPath)) {
      return this.readJsonServers(rootProjectPath);
    }
    return {};
  }

  private interpolateEnvVars(value: string): string {
    return value.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g, (_, varName) => {
      return process.env[varName] || '';
    });
  }

  private sanitizeServerConfig(config: MCPServerConfig): MCPServerConfig {
    if (config.type === 'sse' || config.type === 'websocket') {
      const copy = { ...config };
      copy.url = this.interpolateEnvVars(copy.url);
      if (copy.headers) {
        const sanitizedHeaders: Record<string, string> = {};
        for (const [k, v] of Object.entries(copy.headers)) {
          if (typeof v === 'string') {
            sanitizedHeaders[k] = this.interpolateEnvVars(v);
          }
        }
        copy.headers = sanitizedHeaders;
      }
      return copy;
    }

    const stdioConfig = { ...config } as StdioServerConfig;
    if (stdioConfig.command) {
      stdioConfig.command = this.interpolateEnvVars(stdioConfig.command);
    }
    if (stdioConfig.args && Array.isArray(stdioConfig.args)) {
      stdioConfig.args = stdioConfig.args.map((a: string) => this.interpolateEnvVars(a));
    }
    if (stdioConfig.env && typeof stdioConfig.env === 'object') {
      const sanitizedEnv: Record<string, string> = {};
      for (const [k, v] of Object.entries(stdioConfig.env)) {
        if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(k) && typeof v === 'string') {
          sanitizedEnv[k] = this.interpolateEnvVars(v);
        }
      }
      stdioConfig.env = sanitizedEnv;
    }
    return stdioConfig;
  }

  private readJsonServers(filePath: string): Record<string, MCPServerConfig> {
    try {
      if (!fs.existsSync(filePath)) return {};
      const content = fs.readFileSync(filePath, 'utf-8');
      const parsed = JSON.parse(content);

      let rawServers: Record<string, MCPServerConfig> = {};
      if (parsed.mcpServers && typeof parsed.mcpServers === 'object') {
        rawServers = parsed.mcpServers;
      } else if (parsed.servers && typeof parsed.servers === 'object') {
        rawServers = parsed.servers;
      } else if (typeof parsed === 'object') {
        rawServers = parsed;
      }

      const sanitized: Record<string, MCPServerConfig> = {};
      for (const [name, srv] of Object.entries(rawServers)) {
        if (srv && typeof srv === 'object') {
          sanitized[name] = this.sanitizeServerConfig(srv);
        }
      }
      return sanitized;
    } catch (err) {
      console.warn(`[dsh-plugin-mcp] Warning: Failed to parse MCP config at ${filePath}:`, err);
      return {};
    }
  }

  /**
   * Helper to write a server to a specific configuration scope file.
   */
  public saveServerToScope(
    scope: 'user' | 'project',
    serverName: string,
    serverConfig: MCPServerConfig
  ): void {
    const targetPath =
      scope === 'user'
        ? path.join(this.userConfigDir, 'mcp.json')
        : path.join(this.cwd, '.dsh', 'mcp.json');

    const targetDir = path.dirname(targetPath);
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    const existing = this.readJsonServers(targetPath);
    existing[serverName] = serverConfig;

    fs.writeFileSync(targetPath, JSON.stringify({ mcpServers: existing }, null, 2), 'utf-8');
  }
}
