import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { SSEClientTransport } from '@modelcontextprotocol/sdk/client/sse.js';
import { WebSocketClientTransport } from '@modelcontextprotocol/sdk/client/websocket.js';
import type { Transport } from '@modelcontextprotocol/sdk/shared/transport.js';
import { SecurityEngine } from './security.js';
import type { MCPServerConfig, ServerStatus, TransportType } from './types.js';

export interface ManagedServer {
  name: string;
  config: MCPServerConfig;
  client: Client;
  transport?: Transport;
  connected: boolean;
  lastError?: string;
  toolsCount: number;
  resourcesCount: number;
  promptsCount: number;
}

export class McpClientManager {
  private servers = new Map<string, ManagedServer>();
  private defaultTimeoutMs: number;

  constructor(defaultTimeoutMs = 60000) {
    this.defaultTimeoutMs = defaultTimeoutMs;
  }

  public async registerAndStartServer(name: string, config: MCPServerConfig): Promise<ManagedServer> {
    if (config.disabled) {
      const managed: ManagedServer = {
        name,
        config,
        client: new Client({ name: `dsh-mcp-${name}`, version: '0.1.0' }, { capabilities: {} }),
        connected: false,
        toolsCount: 0,
        resourcesCount: 0,
        promptsCount: 0,
        lastError: 'Disabled in configuration',
      };
      this.servers.set(name, managed);
      return managed;
    }

    // If server is already running, stop it first
    if (this.servers.has(name)) {
      await this.stopServer(name);
    }

    const client = new Client(
      {
        name: `dsh-mcp-${name}`,
        version: '0.1.0',
      },
      {
        capabilities: {
          roots: {},
          sampling: {},
        },
      }
    );

    const managed: ManagedServer = {
      name,
      config,
      client,
      connected: false,
      toolsCount: 0,
      resourcesCount: 0,
      promptsCount: 0,
    };
    this.servers.set(name, managed);

    try {
      const transport = this.createTransport(config);
      managed.transport = transport;

      await client.connect(transport);
      managed.connected = true;
      managed.lastError = undefined;

      // Probe counts
      try {
        const toolsResult = await client.listTools();
        managed.toolsCount = toolsResult.tools?.length || 0;
      } catch {
        managed.toolsCount = 0;
      }

      try {
        const resourcesResult = await client.listResources();
        managed.resourcesCount = resourcesResult.resources?.length || 0;
      } catch {
        managed.resourcesCount = 0;
      }

      try {
        const promptsResult = await client.listPrompts();
        managed.promptsCount = promptsResult.prompts?.length || 0;
      } catch {
        managed.promptsCount = 0;
      }
    } catch (err: any) {
      managed.connected = false;
      managed.lastError = err?.message || String(err);
      console.error(`[dsh-plugin-mcp] Failed to connect to MCP server '${name}':`, managed.lastError);
    }

    return managed;
  }

  private createTransport(config: MCPServerConfig): Transport {
    const transportType: TransportType = (config.type as TransportType) || 'stdio';

    if (transportType === 'stdio') {
      const stdioConfig = config as import('./types.js').StdioServerConfig;
      const safetyCheck = SecurityEngine.validateCommandSafety(stdioConfig.command, stdioConfig.args || []);
      if (!safetyCheck.safe) {
        throw new Error(`[Security] Rejected unsafe MCP server command: ${safetyCheck.reason}`);
      }

      const combinedEnv = {
        ...process.env,
        ...(stdioConfig.env || {}),
      } as Record<string, string>;

      return new StdioClientTransport({
        command: stdioConfig.command,
        args: stdioConfig.args || [],
        env: combinedEnv,
        cwd: stdioConfig.cwd,
        stderr: 'pipe',
      });
    }

    if (transportType === 'sse') {
      const sseConfig = config as import('./types.js').SseServerConfig;
      return new SSEClientTransport(new URL(sseConfig.url), {
        eventSourceInit: {
          headers: sseConfig.headers,
        } as any,
        requestInit: {
          headers: sseConfig.headers,
        },
      });
    }

    if (transportType === 'websocket') {
      const wsConfig = config as import('./types.js').WebSocketServerConfig;
      return new WebSocketClientTransport(new URL(wsConfig.url));
    }

    throw new Error(`Unsupported MCP transport type: ${transportType}`);
  }

  public async stopServer(name: string): Promise<void> {
    const managed = this.servers.get(name);
    if (!managed) return;

    try {
      if (managed.connected && managed.client) {
        await managed.client.close();
      }
    } catch (err) {
      console.warn(`[dsh-plugin-mcp] Error closing MCP server '${name}':`, err);
    } finally {
      managed.connected = false;
      this.servers.delete(name);
    }
  }

  public async stopAll(): Promise<void> {
    const names = Array.from(this.servers.keys());
    await Promise.all(names.map((name) => this.stopServer(name)));
  }

  public getServer(name: string): ManagedServer | undefined {
    return this.servers.get(name);
  }

  public getAllServers(): ManagedServer[] {
    return Array.from(this.servers.values());
  }

  public getStatus(name: string): ServerStatus | undefined {
    const managed = this.servers.get(name);
    if (!managed) return undefined;
    return {
      name: managed.name,
      connected: managed.connected,
      transport: (managed.config.type as TransportType) || 'stdio',
      toolsCount: managed.toolsCount,
      resourcesCount: managed.resourcesCount,
      promptsCount: managed.promptsCount,
      lastError: managed.lastError,
    };
  }

  public getAllStatuses(): ServerStatus[] {
    return Array.from(this.servers.keys())
      .map((name) => this.getStatus(name))
      .filter((s): s is ServerStatus => s !== undefined);
  }
}
