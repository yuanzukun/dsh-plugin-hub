/**
 * Types for dsh-plugin-mcp (DeepSeek Harness Model Context Protocol Bridge)
 */

export type TransportType = 'stdio' | 'sse' | 'websocket';

export interface StdioServerConfig {
  type?: 'stdio';
  command: string;
  args?: string[];
  env?: Record<string, string>;
  cwd?: string;
  disabled?: boolean;
  autoRestart?: boolean;
  timeoutMs?: number;
}

export interface SseServerConfig {
  type: 'sse';
  url: string;
  headers?: Record<string, string>;
  disabled?: boolean;
  autoRestart?: boolean;
  timeoutMs?: number;
}

export interface WebSocketServerConfig {
  type: 'websocket';
  url: string;
  headers?: Record<string, string>;
  disabled?: boolean;
  autoRestart?: boolean;
  timeoutMs?: number;
}

export type MCPServerConfig = StdioServerConfig | SseServerConfig | WebSocketServerConfig;

export interface DshMcpPluginConfig {
  /**
   * Map of MCP server configurations keyed by unique server identifier.
   */
  servers: Record<string, MCPServerConfig>;

  /**
   * Prefix tool names with server name to avoid collisions (e.g. `github_create_issue`).
   * Default: true
   */
  prefixToolNames?: boolean;

  /**
   * Delimiter when prefixing tool names.
   * Default: '_'
   */
  prefixDelimiter?: string;

  /**
   * Whether to bridge MCP resources into DSH agent context.
   * Default: true
   */
  exposeResources?: boolean;

  /**
   * Whether to bridge MCP prompt templates into DSH agent context.
   * Default: true
   */
  exposePrompts?: boolean;

  /**
   * Default timeout in milliseconds for MCP tool calls.
   * Default: 60000 (60 seconds)
   */
  defaultTimeoutMs?: number;

  /**
   * Automatically load servers from User scope (~/.dsh/mcp.json) and Project scope (.dsh/mcp.json).
   * Default: true
   */
  enableMultiScope?: boolean;

  /**
   * Tool execution permission policy rules (allow, ask, deny).
   */
  permissions?: {
    allow?: string[];
    ask?: string[];
    deny?: string[];
    defaultVerdict?: 'allow' | 'ask' | 'deny';
  };

  /**
   * Lazy load tool schemas on demand to minimize context window token consumption.
   * Default: false
   */
  lazyLoadTools?: boolean;
}

export interface DshToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, any>;
  execute: (args: Record<string, any>) => Promise<any>;
  serverName: string;
  originalName: string;
}

export interface DshResourceDefinition {
  uri: string;
  name: string;
  description?: string;
  mimeType?: string;
  serverName: string;
  read: () => Promise<{ contents: Array<{ uri: string; mimeType?: string; text?: string; blob?: string }> }>;
}

export interface DshPromptDefinition {
  name: string;
  description?: string;
  arguments?: Array<{ name: string; description?: string; required?: boolean }>;
  serverName: string;
  get: (args: Record<string, any>) => Promise<any>;
}

export interface ServerStatus {
  name: string;
  connected: boolean;
  transport: TransportType;
  toolsCount: number;
  resourcesCount: number;
  promptsCount: number;
  lastError?: string;
}
