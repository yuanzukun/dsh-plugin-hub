import type { LightweightToolStub } from './lazy-registry.js';

export interface SearchScoreResult {
  tool: LightweightToolStub;
  score: number;
}

/**
 * Semantic & Keyword Tool Matcher (TF-IDF based)
 *
 * Efficient zero-dependency ranker that scores tool definitions against
 * user intents. Ensures only the most relevant MCP tools are injected into
 * LLM context per turn.
 */
export class ToolSemanticSearch {
  private tokenize(text: string): string[] {
    return text
      .toLowerCase()
      .replace(/[^a-z0-9_\-\s]/g, ' ')
      .split(/\s+/)
      .filter((term) => term.length > 1);
  }

  /**
   * Scores tools against query text and returns top-K ranked tools.
   */
  public search(
    tools: LightweightToolStub[],
    query: string,
    topK = 5
  ): SearchScoreResult[] {
    if (!query.trim() || tools.length === 0) {
      return tools.slice(0, topK).map((tool) => ({ tool, score: 1.0 }));
    }

    const queryTokens = new Set(this.tokenize(query));
    const scored: SearchScoreResult[] = [];

    for (const tool of tools) {
      const toolText = `${tool.name} ${tool.name.replace(/[_.-]/g, ' ')} ${tool.description} ${tool.serverName}`;
      const toolTokens = this.tokenize(toolText);

      let matches = 0;
      for (const token of toolTokens) {
        if (queryTokens.has(token)) {
          matches++;
        }
      }

      // Exact name match boost
      let bonus = 0;
      for (const qToken of queryTokens) {
        if (tool.name.toLowerCase().includes(qToken)) bonus += 2.0;
        if (tool.serverName.toLowerCase().includes(qToken)) bonus += 1.5;
      }

      const score = matches / Math.max(toolTokens.length, 1) + bonus;
      if (score > 0) {
        scored.push({ tool, score });
      }
    }

    return scored
      .sort((a, b) => b.score - a.score)
      .slice(0, topK);
  }
}
