import { z } from 'zod';
import type { DshMcpPluginConfig } from './types.js';

export const StdioServerSchema = z.object({
  type: z.literal('stdio').optional().default('stdio'),
  command: z.string().min(1, 'Command is required for stdio transport'),
  args: z.array(z.string()).optional().default([]),
  env: z.record(z.string()).optional().default({}),
  cwd: z.string().optional(),
  disabled: z.boolean().optional().default(false),
  autoRestart: z.boolean().optional().default(true),
  timeoutMs: z.number().positive().optional().default(60000),
});

export const SseServerSchema = z.object({
  type: z.literal('sse'),
  url: z.string().url('Valid URL is required for SSE transport'),
  headers: z.record(z.string()).optional().default({}),
  disabled: z.boolean().optional().default(false),
  autoRestart: z.boolean().optional().default(true),
  timeoutMs: z.number().positive().optional().default(60000),
});

export const WebSocketServerSchema = z.object({
  type: z.literal('websocket'),
  url: z.string().url('Valid URL is required for WebSocket transport'),
  headers: z.record(z.string()).optional().default({}),
  disabled: z.boolean().optional().default(false),
  autoRestart: z.boolean().optional().default(true),
  timeoutMs: z.number().positive().optional().default(60000),
});

export const MCPServerSchema = z.discriminatedUnion('type', [
  StdioServerSchema.extend({ type: z.literal('stdio') }),
  SseServerSchema,
  WebSocketServerSchema,
]).or(StdioServerSchema);

export const PermissionPolicySchema = z.object({
  allow: z.array(z.string()).optional().default([]),
  ask: z.array(z.string()).optional().default([]),
  deny: z.array(z.string()).optional().default([]),
  defaultVerdict: z.enum(['allow', 'ask', 'deny']).optional().default('allow'),
});

export const DshMcpPluginConfigSchema = z.object({
  servers: z.record(MCPServerSchema).default({}),
  prefixToolNames: z.boolean().default(true),
  prefixDelimiter: z.string().default('_'),
  exposeResources: z.boolean().default(true),
  exposePrompts: z.boolean().default(true),
  defaultTimeoutMs: z.number().positive().default(60000),
  enableMultiScope: z.boolean().default(true),
  permissions: PermissionPolicySchema.optional(),
  lazyLoadTools: z.boolean().default(false),
});

export function parseConfig(rawConfig: unknown): DshMcpPluginConfig {
  return DshMcpPluginConfigSchema.parse(rawConfig || {}) as DshMcpPluginConfig;
}
