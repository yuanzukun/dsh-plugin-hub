export interface LatencySample {
  serverName: string;
  toolName: string;
  durationMs: number;
  success: boolean;
  timestamp: number;
}

export interface PercentileStats {
  count: number;
  min: number;
  max: number;
  avg: number;
  p50: number;
  p95: number;
  p99: number;
}

/**
 * Enterprise Telemetry & Latency Histogram Engine
 *
 * Computes high-resolution p50/p95/p99 execution percentiles and pool metrics.
 */
export class TelemetryEngine {
  private samples: LatencySample[] = [];
  private maxSamples: number;
  private serverCallCounts: Map<string, number> = new Map();
  private serverErrorCounts: Map<string, number> = new Map();

  constructor(maxSamples = 10000) {
    this.maxSamples = maxSamples;
  }

  public recordSample(sample: Omit<LatencySample, 'timestamp'>): void {
    const fullSample: LatencySample = {
      ...sample,
      timestamp: Date.now(),
    };

    if (this.samples.length >= this.maxSamples) {
      this.samples.shift(); // Evict oldest sample
    }
    this.samples.push(fullSample);

    const total = this.serverCallCounts.get(sample.serverName) || 0;
    this.serverCallCounts.set(sample.serverName, total + 1);

    if (!sample.success) {
      const errs = this.serverErrorCounts.get(sample.serverName) || 0;
      this.serverErrorCounts.set(sample.serverName, errs + 1);
    }
  }

  public computeStats(serverName?: string): PercentileStats {
    let filtered = serverName
      ? this.samples.filter((s) => s.serverName === serverName)
      : this.samples;

    if (filtered.length === 0) {
      return { count: 0, min: 0, max: 0, avg: 0, p50: 0, p95: 0, p99: 0 };
    }

    const durations = filtered.map((s) => s.durationMs).sort((a, b) => a - b);
    const sum = durations.reduce((acc, val) => acc + val, 0);

    const getPercentile = (p: number) => {
      const idx = Math.min(
        Math.floor((p / 100) * durations.length),
        durations.length - 1
      );
      return durations[idx];
    };

    return {
      count: durations.length,
      min: durations[0],
      max: durations[durations.length - 1],
      avg: Number((sum / durations.length).toFixed(2)),
      p50: getPercentile(50),
      p95: getPercentile(95),
      p99: getPercentile(99),
    };
  }

  public getSummary() {
    return {
      totalInvocations: this.samples.length,
      globalStats: this.computeStats(),
      serverBreakdown: Array.from(this.serverCallCounts.entries()).map(([name, calls]) => ({
        serverName: name,
        calls,
        errors: this.serverErrorCounts.get(name) || 0,
        stats: this.computeStats(name),
      })),
    };
  }

  public clear(): void {
    this.samples = [];
    this.serverCallCounts.clear();
    this.serverErrorCounts.clear();
  }
}
