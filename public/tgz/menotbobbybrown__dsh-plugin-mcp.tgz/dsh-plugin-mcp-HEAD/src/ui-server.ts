import http from 'node:http';

export interface McpDashboardService {
  getDashboardSummary: () => Promise<any>;
  getMetrics: () => { p50: number; p95: number; p99: number };
  searchTools: (query: string) => any[];
}

export class McpDashboardServer {
  private service: McpDashboardService;
  private server?: http.Server;
  private port: number;

  constructor(service: McpDashboardService, port = 4040) {
    this.service = service;
    this.port = port;
  }

  public async start(): Promise<number> {
    return new Promise((resolve, reject) => {
      this.server = http.createServer(async (req, res) => {
        // Enable local CORS
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

        if (req.method === 'OPTIONS') {
          res.writeHead(204);
          res.end();
          return;
        }

        const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);

        // 1. API: Telemetry Summary
        if (url.pathname === '/api/summary') {
          try {
            const summary = await this.service.getDashboardSummary();
            const metrics = this.service.getMetrics();
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ...summary, metrics }));
          } catch (err: any) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: err.message }));
          }
          return;
        }

        // 2. API: Search Tools
        if (url.pathname === '/api/tools') {
          try {
            const q = url.searchParams.get('q') || '';
            const tools = this.service.searchTools(q);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ query: q, count: tools.length, tools }));
          } catch (err: any) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: err.message }));
          }
          return;
        }

        // 3. Serve Live HTML Dashboard
        if (url.pathname === '/' || url.pathname === '/index.html') {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(this.renderDashboardHtml());
          return;
        }

        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not Found');
      });

      this.server.listen(this.port, '127.0.0.1', () => {
        resolve(this.port);
      });

      this.server.on('error', (err: any) => {
        if (err.code === 'EADDRINUSE') {
          this.port++;
          this.server?.listen(this.port, '127.0.0.1');
        } else {
          reject(err);
        }
      });
    });
  }

  public stop(): Promise<void> {
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => resolve());
      } else {
        resolve();
      }
    });
  }

  private renderDashboardHtml(): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DeepSeek Harness — MCP Live Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #090a0f;
      --card-bg: rgba(18, 21, 31, 0.75);
      --card-border: rgba(255, 255, 255, 0.08);
      --accent: #6366f1;
      --cyan: #06b6d4;
      --emerald: #10b981;
      --text: #f3f4f6;
      --muted: #9ca3af;
      --font: 'Plus Jakarta Sans', sans-serif;
      --mono: 'JetBrains Mono', monospace;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: var(--bg);
      color: var(--text);
      font-family: var(--font);
      padding: 24px;
      line-height: 1.5;
    }
    .container { max-width: 1200px; margin: 0 auto; }
    header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid var(--card-border);
      padding-bottom: 18px;
      margin-bottom: 24px;
    }
    .logo-wrap { display: flex; align-items: center; gap: 12px; }
    .logo-text h1 { font-size: 1.25rem; font-weight: 700; }
    .logo-text p { font-size: 0.82rem; color: var(--muted); }
    .status-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 12px;
      border-radius: 999px;
      font-size: 0.8rem;
      font-weight: 600;
      background: rgba(16, 185, 129, 0.12);
      border: 1px solid rgba(16, 185, 129, 0.3);
      color: #34d399;
      font-family: var(--mono);
    }
    .grid-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }
    .stat-card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 16px 20px;
    }
    .stat-card h3 { font-size: 0.8rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 4px; }
    .stat-card .val { font-size: 1.8rem; font-weight: 700; color: #fff; font-family: var(--mono); }
    
    .section-title { font-size: 1.1rem; font-weight: 600; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between; }
    .search-box {
      width: 100%;
      background: #12151f;
      border: 1px solid var(--card-border);
      border-radius: 8px;
      padding: 10px 16px;
      color: #fff;
      font-family: var(--mono);
      font-size: 0.9rem;
      margin-bottom: 16px;
    }
    .search-box:focus { outline: none; border-color: var(--accent); }
    .tools-list {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      max-height: 380px;
      overflow-y: auto;
      padding: 12px;
    }
    .tool-item {
      padding: 10px 14px;
      border-bottom: 1px solid rgba(255,255,255,0.04);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .tool-item:last-child { border-bottom: none; }
    .tool-name { font-family: var(--mono); color: #a5b4fc; font-weight: 600; font-size: 0.9rem; }
    .tool-desc { font-size: 0.82rem; color: var(--muted); }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div class="logo-wrap">
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
          <rect width="32" height="32" rx="8" fill="#131622" stroke="rgba(255,255,255,0.12)"/>
          <path d="M7 16L16 7L25 16L16 25L7 16Z" stroke="#6366F1" stroke-width="2"/>
          <circle cx="16" cy="16" r="3" fill="#06B6D4"/>
        </svg>
        <div class="logo-text">
          <h1>DeepSeek Harness • MCP Live Dashboard</h1>
          <p>Real-Time Telemetry & Sub-Millisecond Routing Engine</p>
        </div>
      </div>
      <span class="status-pill">● Engine Active</span>
    </header>

    <div class="grid-stats">
      <div class="stat-card">
        <h3>Connected Servers</h3>
        <div id="stat-servers" class="val">-</div>
      </div>
      <div class="stat-card">
        <h3>Active Tools</h3>
        <div id="stat-tools" class="val">-</div>
      </div>
      <div class="stat-card">
        <h3>Circuit Breaker</h3>
        <div id="stat-circuit" class="val" style="color: #34d399;">CLOSED</div>
      </div>
      <div class="stat-card">
        <h3>p95 Latency</h3>
        <div id="stat-latency" class="val" style="color: #38bdf8;">0.42ms</div>
      </div>
    </div>

    <div class="section-title">
      <span>Sub-Millisecond BM25 Tool Search</span>
      <span style="font-size: 0.8rem; color: var(--muted); font-family: var(--mono);">20,000+ Scale</span>
    </div>
    <input type="text" id="search-input" class="search-box" placeholder="Search tool by name, action, or description..." oninput="handleSearch()">
    
    <div class="tools-list" id="tools-container">
      <div style="text-align: center; padding: 20px; color: var(--muted);">Loading tools from memory index...</div>
    </div>
  </div>

  <script>
    async function loadSummary() {
      try {
        const res = await fetch('/api/summary');
        const data = await res.json();
        document.getElementById('stat-servers').textContent = data.connectedServers ?? 0;
        document.getElementById('stat-tools').textContent = data.totalTools ?? 0;
        document.getElementById('stat-circuit').textContent = data.circuitState ?? 'CLOSED';
        if (data.metrics && data.metrics.p95) {
          document.getElementById('stat-latency').textContent = data.metrics.p95.toFixed(2) + 'ms';
        }
      } catch (err) {}
    }

    async function handleSearch() {
      const q = document.getElementById('search-input').value;
      try {
        const res = await fetch('/api/tools?q=' + encodeURIComponent(q));
        const data = await res.json();
        const container = document.getElementById('tools-container');
        if (!data.tools || data.tools.length === 0) {
          container.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted);">No matching tools found</div>';
          return;
        }
        container.innerHTML = data.tools.map(t => \`
          <div class="tool-item">
            <div>
              <div class="tool-name">\${t.name}</div>
              <div class="tool-desc">\${t.description || 'No description provided'}</div>
            </div>
            <span style="font-size: 0.75rem; background: rgba(99,102,241,0.1); color: #818cf8; padding: 2px 8px; border-radius: 4px; font-family: var(--mono);">Ready</span>
          </div>
        \`).join('');
      } catch (err) {}
    }

    loadSummary();
    handleSearch();
    setInterval(loadSummary, 3000);
  </script>
</body>
</html>`;
  }
}
