export interface CircuitBreakerOptions {
  /**
   * Maximum consecutive failures before tripping the circuit.
   * Default: 5 failures
   */
  failureThreshold?: number;

  /**
   * Time in milliseconds the circuit remains open before testing recovery (Half-Open).
   * Default: 30000ms (30 seconds)
   */
  resetTimeoutMs?: number;

  /**
   * Maximum calls allowed per minute.
   * Default: 60 calls/min
   */
  rateLimitPerMinute?: number;
}

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

/**
 * Circuit Breaker & Rate Limiter
 *
 * Prevents runaway tool execution loops, cascades of failing MCP requests,
 * and runaway API costs.
 */
export class CircuitBreaker {
  private failureThreshold: number;
  private resetTimeoutMs: number;
  private rateLimitPerMinute: number;

  private state: CircuitState = 'CLOSED';
  private failureCount = 0;
  private nextAttemptTime = 0;
  private callTimestamps: number[] = [];

  constructor(options: CircuitBreakerOptions = {}) {
    this.failureThreshold = options.failureThreshold || 5;
    this.resetTimeoutMs = options.resetTimeoutMs || 30000;
    this.rateLimitPerMinute = options.rateLimitPerMinute || 60;
  }

  public getState(): CircuitState {
    if (this.state === 'OPEN' && Date.now() >= this.nextAttemptTime) {
      this.state = 'HALF_OPEN';
    }
    return this.state;
  }

  /**
   * Checks if an execution is permitted under circuit state and rate limits.
   */
  public canExecute(): { allowed: boolean; reason?: string } {
    const currentState = this.getState();

    if (currentState === 'OPEN') {
      const waitTime = Math.ceil((this.nextAttemptTime - Date.now()) / 1000);
      return {
        allowed: false,
        reason: `Circuit breaker is OPEN due to repeated failures. Retry in ${waitTime}s.`,
      };
    }

    // Check rate limit window
    const now = Date.now();
    const oneMinuteAgo = now - 60000;
    this.callTimestamps = this.callTimestamps.filter((ts) => ts > oneMinuteAgo);

    if (this.callTimestamps.length >= this.rateLimitPerMinute) {
      return {
        allowed: false,
        reason: `Rate limit exceeded (${this.rateLimitPerMinute} calls/minute limit reached).`,
      };
    }

    this.callTimestamps.push(now);
    return { allowed: true };
  }

  /**
   * Records a successful execution and resets the failure counter.
   */
  public recordSuccess(): void {
    this.failureCount = 0;
    this.state = 'CLOSED';
  }

  /**
   * Records a failure and trips the circuit if threshold is exceeded.
   */
  public recordFailure(): void {
    this.failureCount++;
    if (this.failureCount >= this.failureThreshold || this.state === 'HALF_OPEN') {
      this.state = 'OPEN';
      this.nextAttemptTime = Date.now() + this.resetTimeoutMs;
    }
  }

  public reset(): void {
    this.state = 'CLOSED';
    this.failureCount = 0;
    this.nextAttemptTime = 0;
    this.callTimestamps = [];
  }
}
