import type { DshToolDefinition } from './types.js';

export interface TokenBudgetConfig {
  maxToolTokens?: number;
  charsPerTokenEstimate?: number;
  enableCompactSignatures?: boolean;
}

export interface BudgetedToolsResult {
  injectedTools: DshToolDefinition[];
  compactSignatures: string[];
  estimatedTokens: number;
  truncatedCount: number;
}

/**
 * Dynamic Context Budget & Progressive Schema Disclosure Manager
 *
 * Enforces strict token ceilings to prevent context bloat across 10,000+ tools.
 */
export class TokenBudgetManager {
  private maxTokens: number;
  private charsPerToken: number;
  private enableCompact: boolean;

  constructor(config: TokenBudgetConfig = {}) {
    this.maxTokens = config.maxToolTokens ?? 1500;
    this.charsPerToken = config.charsPerTokenEstimate ?? 4;
    this.enableCompact = config.enableCompactSignatures ?? true;
  }

  public estimateToolTokens(tool: DshToolDefinition): number {
    const rawSchema = JSON.stringify({
      name: tool.name,
      description: tool.description,
      parameters: tool.parameters,
    });
    return Math.ceil(rawSchema.length / this.charsPerToken);
  }

  public generateCompactSignature(tool: DshToolDefinition): string {
    const paramKeys = Object.keys(tool.parameters?.properties || {});
    const required = tool.parameters?.required || [];
    const paramsStr = paramKeys
      .map((k) => (required.includes(k) ? `${k}*` : `${k}?`))
      .join(', ');
    return `${tool.name}(${paramsStr}): ${tool.description?.slice(0, 80) || ''}`;
  }

  public allocateBudget(rankedTools: DshToolDefinition[]): BudgetedToolsResult {
    let currentTokens = 0;
    const injectedTools: DshToolDefinition[] = [];
    const compactSignatures: string[] = [];
    let truncatedCount = 0;

    for (const tool of rankedTools) {
      const estimated = this.estimateToolTokens(tool);

      if (currentTokens + estimated <= this.maxTokens) {
        injectedTools.push(tool);
        compactSignatures.push(this.generateCompactSignature(tool));
        currentTokens += estimated;
      } else {
        truncatedCount++;
      }
    }

    return {
      injectedTools,
      compactSignatures,
      estimatedTokens: currentTokens,
      truncatedCount,
    };
  }

  public getMaxTokens(): number {
    return this.maxTokens;
  }

  public setMaxTokens(tokens: number): void {
    this.maxTokens = tokens;
  }
}
