export interface CreateMessageRequestParams {
  messages: Array<{
    role: 'user' | 'assistant';
    content: {
      type: 'text' | 'image';
      text?: string;
      data?: string;
      mimeType?: string;
    };
  }>;
  modelPreferences?: {
    hints?: Array<{ name?: string }>;
    costPriority?: number;
    speedPriority?: number;
    intelligencePriority?: number;
  };
  systemPrompt?: string;
  includeContext?: 'none' | 'thisServer' | 'allServers';
  temperature?: number;
  maxTokens: number;
  stopSequences?: string[];
  metadata?: Record<string, unknown>;
}

export interface CreateMessageResult {
  role: 'assistant';
  content: {
    type: 'text';
    text: string;
  };
  model: string;
  stopReason?: 'endTurn' | 'stopSequence' | 'maxTokens' | string;
}

export type LLMCompletionHandler = (
  params: CreateMessageRequestParams
) => Promise<CreateMessageResult>;

/**
 * MCP Sampling Manager
 *
 * Implements the MCP `sampling/createMessage` client-side protocol handler.
 * Enables connected MCP servers (e.g. autonomous agent tools, code analyzers)
 * to request completions from DeepSeek LLM through DeepSeek Harness.
 */
export class McpSamplingManager {
  private completionHandler?: LLMCompletionHandler;

  constructor(completionHandler?: LLMCompletionHandler) {
    this.completionHandler = completionHandler;
  }

  public setCompletionHandler(handler: LLMCompletionHandler): void {
    this.completionHandler = handler;
  }

  /**
   * Handles incoming `sampling/createMessage` request from an MCP server.
   */
  public async handleCreateMessage(
    params: CreateMessageRequestParams
  ): Promise<CreateMessageResult> {
    if (!this.completionHandler) {
      throw new Error(
        '[dsh-plugin-mcp] Sampling handler not configured in DeepSeek Harness environment'
      );
    }
    return this.completionHandler(params);
  }
}
