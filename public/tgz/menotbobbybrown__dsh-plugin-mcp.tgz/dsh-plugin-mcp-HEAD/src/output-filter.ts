import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

export interface OutputFilterOptions {
  /**
   * Maximum character size before output is spilled over to an artifact file.
   * Default: 30000 characters (~7.5k tokens).
   */
  maxCharLength?: number;

  /**
   * Directory where large tool output artifacts are stored.
   * Default: os.tmpdir()/dsh-mcp-artifacts
   */
  artifactDir?: string;
}

export interface FilteredOutputResult {
  output: string;
  isTruncated: boolean;
  artifactPath?: string;
  originalLength: number;
}

/**
 * Output Filter & Context Spillover Guard
 *
 * Protects agent context windows from being overwhelmed by massive MCP tool outputs
 * (e.g. 500-row SQL table results, full repository file trees, binary data dumps).
 */
export class OutputFilter {
  private maxCharLength: number;
  private artifactDir: string;

  constructor(options: OutputFilterOptions = {}) {
    this.maxCharLength = options.maxCharLength || 30000;
    this.artifactDir =
      options.artifactDir || path.join(os.tmpdir(), 'dsh-mcp-artifacts');
  }

  /**
   * Neutralizes prompt injection patterns from third-party MCP output.
   */
  public neutralizePromptInjections(input: string): string {
    return input
      .replace(/<\/?system>/gi, '[system-tag]')
      .replace(/\[system\]/gi, '[system-block]')
      .replace(/(###\s*System\s*Instruction)/gi, '[System-Instruction-Disabled]')
      .replace(/(ignore\s+all\s+previous\s+instructions)/gi, '[ignored-instruction-override]');
  }

  public processOutput(rawResult: unknown, toolName: string): FilteredOutputResult {
    let text =
      typeof rawResult === 'string'
        ? rawResult
        : JSON.stringify(rawResult, null, 2);

    text = this.neutralizePromptInjections(text);
    const originalLength = text.length;

    if (originalLength <= this.maxCharLength) {
      return {
        output: text,
        isTruncated: false,
        originalLength,
      };
    }

    // Output exceeds threshold -> Write to temporary artifact file and return summary preview
    if (!fs.existsSync(this.artifactDir)) {
      fs.mkdirSync(this.artifactDir, { recursive: true });
    }

    const timestamp = Date.now();
    const artifactFilename = `${toolName}_${timestamp}.txt`;
    const artifactPath = path.join(this.artifactDir, artifactFilename);

    fs.writeFileSync(artifactPath, text, 'utf-8');

    const previewHead = text.slice(0, Math.floor(this.maxCharLength * 0.7));
    const previewTail = text.slice(-Math.floor(this.maxCharLength * 0.2));

    const summaryOutput = `${previewHead}

... [Output Truncated: ${originalLength} characters total. Full output saved to artifact: ${artifactPath}] ...

${previewTail}`;

    return {
      output: summaryOutput,
      isTruncated: true,
      artifactPath,
      originalLength,
    };
  }
}
