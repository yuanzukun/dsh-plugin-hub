export interface AgentWatchConfig {
  maxRecursionDepth?: number;
  maxConsecutiveIdenticalCalls?: number;
  perTurnExecutionTimeoutMs?: number;
  slidingWindowRateLimit?: number; // max tool calls per minute
}

export interface WatchdogVerdict {
  allowed: boolean;
  reason?: string;
  isLoopDetected?: boolean;
  depth: number;
}

/**
 * AgentWatch: Real-Time Watchdog, Deadlock Detector & Anti-Loop Guardian
 *
 * Protects DeepSeek agents from runaway tool loops, recursive deadlocks,
 * and runaway API token billing.
 */
export class AgentWatch {
  private maxDepth: number;
  private maxIdentical: number;
  private turnTimeoutMs: number;
  private rateLimitPerMin: number;

  private currentDepth = 0;
  private callHistory: Array<{ toolName: string; argsHash: string; timestamp: number }> = [];
  private turnStartTime = Date.now();

  constructor(config: AgentWatchConfig = {}) {
    this.maxDepth = config.maxRecursionDepth ?? 25;
    this.maxIdentical = config.maxConsecutiveIdenticalCalls ?? 3;
    this.turnTimeoutMs = config.perTurnExecutionTimeoutMs ?? 120000; // 2 minutes
    this.rateLimitPerMin = config.slidingWindowRateLimit ?? 60;
  }

  public startNewTurn(): void {
    this.currentDepth = 0;
    this.callHistory = [];
    this.turnStartTime = Date.now();
  }

  private hashArgs(args: Record<string, any>): string {
    try {
      return JSON.stringify(args);
    } catch {
      return String(args);
    }
  }

  /**
   * Evaluates if a tool invocation should proceed or be blocked.
   */
  public evaluateCall(toolName: string, args: Record<string, any> = {}): WatchdogVerdict {
    const now = Date.now();
    this.currentDepth++;

    // 1. Check Turn Timeout
    if (now - this.turnStartTime > this.turnTimeoutMs) {
      return {
        allowed: false,
        reason: `[AgentWatch] Turn execution exceeded timeout (${this.turnTimeoutMs}ms).`,
        depth: this.currentDepth,
      };
    }

    // 2. Check Recursion Depth Limit
    if (this.currentDepth > this.maxDepth) {
      return {
        allowed: false,
        reason: `[AgentWatch] Maximum agent tool depth (${this.maxDepth}) exceeded. Potential deadlock.`,
        depth: this.currentDepth,
      };
    }

    // 3. Sliding Window Rate Limiting (past 60s)
    const windowStart = now - 60000;
    this.callHistory = this.callHistory.filter((c) => c.timestamp > windowStart);
    if (this.callHistory.length >= this.rateLimitPerMin) {
      return {
        allowed: false,
        reason: `[AgentWatch] Rate limit ceiling exceeded (${this.rateLimitPerMin} calls/min).`,
        depth: this.currentDepth,
      };
    }

    // 4. Repetitive Tool Loop Detection
    const argsHash = this.hashArgs(args);
    let consecutiveCount = 0;

    for (let i = this.callHistory.length - 1; i >= 0; i--) {
      const prev = this.callHistory[i];
      if (prev.toolName === toolName && prev.argsHash === argsHash) {
        consecutiveCount++;
      } else {
        break;
      }
    }

    if (consecutiveCount >= this.maxIdentical) {
      return {
        allowed: false,
        reason: `[AgentWatch] Repetitive loop detected: "${toolName}" was called ${consecutiveCount + 1} times consecutively with identical arguments.`,
        isLoopDetected: true,
        depth: this.currentDepth,
      };
    }

    // Record valid call
    this.callHistory.push({ toolName, argsHash, timestamp: now });

    return {
      allowed: true,
      depth: this.currentDepth,
    };
  }

  public getCurrentDepth(): number {
    return this.currentDepth;
  }

  public reset(): void {
    this.startNewTurn();
  }
}
