import type { McpClientManager, ManagedServer } from './client-manager.js';
import type { MCPServerConfig } from './types.js';
import { SchemaCache } from './schema-cache.js';

export interface ProcessPoolOptions {
  maxActiveProcesses?: number;
  idleTimeoutMs?: number;
  schemaCache?: SchemaCache;
}

export type ServerLifecycleState = 'DORMANT' | 'WARMING' | 'ACTIVE' | 'IDLE' | 'SUSPENDED';

export interface PoolServerEntry {
  name: string;
  config: MCPServerConfig;
  state: ServerLifecycleState;
  managed?: ManagedServer;
  lastUsedTimestamp: number;
  useCount: number;
}

/**
 * Dormant-by-Default Process Pool & LRU Idle Reaper
 *
 * Keeps 10,000+ configured servers in DORMANT state (0 CPU, 0 RAM).
 * JIT activates processes only when a tool is invoked, auto-reaping idle workers
 * to maintain a constant <100MB memory footprint.
 */
export class ProcessPool {
  private manager: McpClientManager;
  private entries: Map<string, PoolServerEntry> = new Map();
  private maxActive: number;
  private idleTimeoutMs: number;
  private schemaCache: SchemaCache;
  private reaperTimer?: NodeJS.Timeout;

  constructor(manager: McpClientManager, options: ProcessPoolOptions = {}) {
    this.manager = manager;
    this.maxActive = options.maxActiveProcesses || 8;
    this.idleTimeoutMs = options.idleTimeoutMs || 300000; // 5 minutes
    this.schemaCache = options.schemaCache || new SchemaCache();
    this.startIdleReaper();
  }

  /**
   * Registers a server in DORMANT mode without spawning an OS child process.
   */
  public registerDormant(name: string, config: MCPServerConfig): void {
    this.entries.set(name, {
      name,
      config,
      state: 'DORMANT',
      lastUsedTimestamp: 0,
      useCount: 0,
    });
  }

  /**
   * Registers multiple servers in bulk in DORMANT mode (e.g. 10,000 servers).
   */
  public registerBulkDormant(servers: Record<string, MCPServerConfig>): void {
    for (const [name, config] of Object.entries(servers)) {
      this.registerDormant(name, config);
    }
  }

  /**
   * Just-In-Time (JIT) activates an active process for a target server.
   */
  public async acquireServer(name: string): Promise<ManagedServer> {
    let entry = this.entries.get(name);
    if (!entry) {
      throw new Error(`[ProcessPool] Server "${name}" is not registered in pool.`);
    }

    entry.lastUsedTimestamp = Date.now();
    entry.useCount++;

    // If already active and connected, return immediately
    if (entry.state === 'ACTIVE' && entry.managed && entry.managed.connected) {
      return entry.managed;
    }

    // Enforce LRU process limits before activating new process
    await this.enforceMaxActiveCapacity();

    entry.state = 'WARMING';
    try {
      const managed = await this.manager.registerAndStartServer(name, entry.config);
      entry.managed = managed;
      entry.state = 'ACTIVE';
      return managed;
    } catch (err: any) {
      entry.state = 'DORMANT';
      throw err;
    }
  }

  /**
   * Suspends / stops a specific server and transitions it to DORMANT.
   */
  public async suspendServer(name: string): Promise<void> {
    const entry = this.entries.get(name);
    if (entry) {
      if (entry.managed) {
        await this.manager.stopServer(name);
        entry.managed = undefined;
      }
      entry.state = 'DORMANT';
    }
  }

  /**
   * Enforces that active running processes do not exceed maxActive ceiling.
   */
  private async enforceMaxActiveCapacity(): Promise<void> {
    const activeEntries = Array.from(this.entries.values()).filter(
      (e) => e.state === 'ACTIVE'
    );

    if (activeEntries.length >= this.maxActive) {
      // Sort by least recently used
      activeEntries.sort((a, b) => a.lastUsedTimestamp - b.lastUsedTimestamp);
      const toEvict = activeEntries[0];
      if (toEvict) {
        await this.suspendServer(toEvict.name);
      }
    }
  }

  /**
   * Background LRU Idle Reaper.
   */
  private startIdleReaper(): void {
    if (typeof setInterval !== 'undefined') {
      this.reaperTimer = setInterval(() => {
        this.reapIdleProcesses().catch((err) =>
          console.warn('[ProcessPool] Error during idle reap:', err)
        );
      }, 30000);
      if (this.reaperTimer.unref) {
        this.reaperTimer.unref();
      }
    }
  }

  public async reapIdleProcesses(): Promise<number> {
    const now = Date.now();
    let reapedCount = 0;

    for (const entry of this.entries.values()) {
      if (
        entry.state === 'ACTIVE' &&
        entry.lastUsedTimestamp > 0 &&
        now - entry.lastUsedTimestamp > this.idleTimeoutMs
      ) {
        await this.suspendServer(entry.name);
        reapedCount++;
      }
    }

    return reapedCount;
  }

  public getStats() {
    let dormant = 0;
    let active = 0;

    for (const entry of this.entries.values()) {
      if (entry.state === 'ACTIVE') active++;
      else dormant++;
    }

    return {
      totalRegistered: this.entries.size,
      activeProcesses: active,
      dormantServers: dormant,
      maxActiveLimit: this.maxActive,
    };
  }

  public async shutdown(): Promise<void> {
    if (this.reaperTimer) {
      clearInterval(this.reaperTimer);
    }
    for (const name of this.entries.keys()) {
      await this.suspendServer(name);
    }
    this.entries.clear();
  }
}
