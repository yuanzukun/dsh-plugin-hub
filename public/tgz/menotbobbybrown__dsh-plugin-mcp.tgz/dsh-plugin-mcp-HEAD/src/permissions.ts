export type ToolActionVerdict = 'allow' | 'ask' | 'deny';

export interface PermissionPolicy {
  /**
   * Tool name patterns that are auto-approved without prompting (e.g. `['github_list_*', 'filesystem_read_*']`).
   */
  allow?: string[];

  /**
   * Tool name patterns that require user confirmation before executing.
   */
  ask?: string[];

  /**
   * Tool name patterns that are forbidden from execution.
   */
  deny?: string[];

  /**
   * Default verdict when no pattern matches. Default: 'allow'
   */
  defaultVerdict?: ToolActionVerdict;
}

export class PermissionManager {
  private policy: PermissionPolicy;

  constructor(policy: PermissionPolicy = {}) {
    this.policy = {
      allow: policy.allow || [],
      ask: policy.ask || [],
      deny: policy.deny || [],
      defaultVerdict: policy.defaultVerdict || 'allow',
    };
  }

  public checkPermission(toolName: string): ToolActionVerdict {
    if (this.matchesAny(toolName, this.policy.deny || [])) {
      return 'deny';
    }
    if (this.matchesAny(toolName, this.policy.ask || [])) {
      return 'ask';
    }
    if (this.matchesAny(toolName, this.policy.allow || [])) {
      return 'allow';
    }
    return this.policy.defaultVerdict || 'allow';
  }

  private matchesAny(toolName: string, patterns: string[]): boolean {
    return patterns.some((pattern) => {
      if (pattern === '*' || pattern === toolName) return true;
      if (pattern.endsWith('*')) {
        const prefix = pattern.slice(0, -1);
        return toolName.startsWith(prefix);
      }
      if (pattern.startsWith('*')) {
        const suffix = pattern.slice(1);
        return toolName.endsWith(suffix);
      }
      return false;
    });
  }
}
