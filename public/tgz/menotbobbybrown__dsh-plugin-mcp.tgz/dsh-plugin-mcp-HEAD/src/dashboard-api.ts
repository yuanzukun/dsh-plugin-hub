import type { McpClientManager } from './client-manager.js';
import type { ToolAdapter } from './tool-adapter.js';
import type { ResourceAdapter } from './resource-adapter.js';
import type { CircuitBreaker } from './circuit-breaker.js';
import type { ServerRegistry } from './registry.js';
import { POPULAR_MCP_SERVERS } from './registry.js';

export interface DashboardTelemetrySummary {
  connectedServers: number;
  totalTools: number;
  totalResources: number;
  circuitState: string;
  servers: Array<{
    name: string;
    type: string;
    connected: boolean;
    toolsCount: number;
    resourcesCount: number;
    lastError?: string;
  }>;
  availableMarketplaceServers: number;
}

/**
 * Dashboard & Web UI Telemetry Provider
 *
 * Exposes structured telemetry, metrics, and marketplace discovery
 * for DeepSeek Harness web frontend and management sidebars.
 */
export class DashboardTelemetryProvider {
  private manager: McpClientManager;
  private toolAdapter: ToolAdapter;
  private resourceAdapter: ResourceAdapter;
  private circuitBreaker: CircuitBreaker;

  constructor(deps: {
    manager: McpClientManager;
    toolAdapter: ToolAdapter;
    resourceAdapter: ResourceAdapter;
    circuitBreaker: CircuitBreaker;
  }) {
    this.manager = deps.manager;
    this.toolAdapter = deps.toolAdapter;
    this.resourceAdapter = deps.resourceAdapter;
    this.circuitBreaker = deps.circuitBreaker;
  }

  public async getSummary(): Promise<DashboardTelemetrySummary> {
    const statuses = this.manager.getAllStatuses();
    const clients = this.manager.getAllServers();

    let totalTools = 0;
    let totalResources = 0;

    const serverSummaries = await Promise.all(
      clients.map(async (client) => {
        const tools = await this.toolAdapter.extractToolsFromServer(client);
        const resources = await this.resourceAdapter.extractResourcesFromServer(client);
        totalTools += tools.length;
        totalResources += resources.length;

        const status = statuses.find((s) => s.name === client.name);
        return {
          name: client.name,
          type: client.config.type || 'stdio',
          connected: status?.connected ?? true,
          toolsCount: tools.length,
          resourcesCount: resources.length,
          lastError: status?.lastError,
        };
      })
    );

    return {
      connectedServers: clients.length,
      totalTools,
      totalResources,
      circuitState: this.circuitBreaker.getState(),
      servers: serverSummaries,
      availableMarketplaceServers: Object.keys(POPULAR_MCP_SERVERS).length,
    };
  }
}
