import type { DshToolDefinition } from './types.js';

export interface LightweightToolStub {
  name: string;
  description: string;
  serverName: string;
  originalName: string;
}

/**
 * Lazy Tool Registry
 *
 * Stores lightweight tool stubs in agent memory to conserve token context window
 * when hundreds of tools across multiple MCP servers are registered.
 * Full JSON parameter schemas and execute functions are resolved on-demand.
 */
export class LazyToolRegistry {
  private fullTools: Map<string, DshToolDefinition> = new Map();
  private stubs: Map<string, LightweightToolStub> = new Map();

  /**
   * Registers a full tool definition while indexing its lightweight summary.
   */
  public registerTool(tool: DshToolDefinition): void {
    this.fullTools.set(tool.name, tool);
    this.stubs.set(tool.name, {
      name: tool.name,
      description: tool.description,
      serverName: tool.serverName,
      originalName: tool.originalName,
    });
  }

  /**
   * Batch registers multiple tool definitions.
   */
  public registerTools(tools: DshToolDefinition[]): void {
    for (const tool of tools) {
      this.registerTool(tool);
    }
  }

  /**
   * Returns token-efficient tool stubs suitable for high-density agent system prompts.
   */
  public getToolStubs(): LightweightToolStub[] {
    return Array.from(this.stubs.values());
  }

  /**
   * Resolves the full parameter schema and execute handler on demand.
   */
  public resolveTool(name: string): DshToolDefinition | undefined {
    return this.fullTools.get(name);
  }

  /**
   * Searches for relevant tools matching a query keyword or regex.
   */
  public searchTools(query: string): LightweightToolStub[] {
    const lower = query.toLowerCase();
    return this.getToolStubs().filter(
      (stub) =>
        stub.name.toLowerCase().includes(lower) ||
        stub.description.toLowerCase().includes(lower) ||
        stub.serverName.toLowerCase().includes(lower)
    );
  }

  /**
   * Clears registered tools for a specific server.
   */
  public clearServerTools(serverName: string): void {
    for (const [name, stub] of this.stubs.entries()) {
      if (stub.serverName === serverName) {
        this.stubs.delete(name);
        this.fullTools.delete(name);
      }
    }
  }

  /**
   * Returns total count of indexed tools.
   */
  public size(): number {
    return this.fullTools.size;
  }
}
