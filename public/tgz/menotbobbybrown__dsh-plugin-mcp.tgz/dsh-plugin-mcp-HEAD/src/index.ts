import type { Context } from 'cordis';
import { parseConfig, DshMcpPluginConfigSchema } from './schema.js';
import { McpClientManager } from './client-manager.js';
import { ToolAdapter } from './tool-adapter.js';
import { ResourceAdapter } from './resource-adapter.js';
import { ConfigLoader } from './config-loader.js';
import { PermissionManager } from './permissions.js';
import { LazyToolRegistry } from './lazy-registry.js';
import { McpSamplingManager } from './sampling.js';
import { ToolSemanticSearch } from './semantic-search.js';
import { OutputFilter } from './output-filter.js';
import { WorkspaceRootsManager } from './roots.js';
import { SecurityEngine } from './security.js';
import { CircuitBreaker } from './circuit-breaker.js';
import { AuditLogger } from './audit-logger.js';
import { ServerRegistry, POPULAR_MCP_SERVERS } from './registry.js';
import { ElicitationManager } from './elicitation.js';
import { DashboardTelemetryProvider } from './dashboard-api.js';
import { SchemaCache } from './schema-cache.js';
import { BM25ToolIndex } from './bm25-index.js';
import { TokenBudgetManager } from './token-budget.js';
import { ProcessPool } from './process-pool.js';
import { TelemetryEngine } from './telemetry.js';
import { AgentWatch } from './agent-watch.js';
import { AgentReachAdapter } from './agent-reach.js';
import { runCli } from './cli.js';
import type {
  DshMcpPluginConfig,
  DshToolDefinition,
  DshResourceDefinition,
  DshPromptDefinition,
  ServerStatus,
} from './types.js';

export * from './types.js';
export * from './schema.js';
export * from './client-manager.js';
export * from './tool-adapter.js';
export * from './resource-adapter.js';
export * from './config-loader.js';
export * from './permissions.js';
export * from './lazy-registry.js';
export * from './sampling.js';
export * from './semantic-search.js';
export * from './output-filter.js';
export * from './roots.js';
export * from './security.js';
export * from './circuit-breaker.js';
export * from './audit-logger.js';
export * from './registry.js';
export * from './elicitation.js';
export * from './dashboard-api.js';
export * from './schema-cache.js';
export * from './bm25-index.js';
export * from './token-budget.js';
export * from './process-pool.js';
export * from './telemetry.js';
export * from './agent-watch.js';
export * from './agent-reach.js';
export * from './ui-server.js';
export * from './cli.js';

export const name = 'mcp';
export const Config = (rawConfig?: unknown) => parseConfig(rawConfig);

export interface DshMcpService {
  manager: McpClientManager;
  toolAdapter: ToolAdapter;
  resourceAdapter: ResourceAdapter;
  configLoader: ConfigLoader;
  permissionManager: PermissionManager;
  lazyRegistry: LazyToolRegistry;
  samplingManager: McpSamplingManager;
  semanticSearch: ToolSemanticSearch;
  outputFilter: OutputFilter;
  rootsManager: WorkspaceRootsManager;
  circuitBreaker: CircuitBreaker;
  auditLogger: AuditLogger;
  elicitationManager: ElicitationManager;
  dashboard: DashboardTelemetryProvider;
  schemaCache: SchemaCache;
  bm25Index: BM25ToolIndex;
  tokenBudget: TokenBudgetManager;
  processPool: ProcessPool;
  telemetry: TelemetryEngine;
  agentWatch: AgentWatch;
  config: DshMcpPluginConfig;
  getAllTools: () => Promise<DshToolDefinition[]>;
  getAllResources: () => Promise<DshResourceDefinition[]>;
  getAllPrompts: () => Promise<DshPromptDefinition[]>;
  getStatuses: () => ServerStatus[];
  refreshServers: () => Promise<void>;
}

declare module 'cordis' {
  interface Context {
    mcp?: DshMcpService;
  }
}

/**
 * Cordis plugin lifecycle entry point for DeepSeek Harness.
 */
export function apply(ctx: Context, rawConfig?: unknown): void {
  const configLoader = new ConfigLoader();
  const config = configLoader.loadMergedConfig(rawConfig);
  const permissionManager = new PermissionManager(config.permissions);
  const manager = new McpClientManager(config.defaultTimeoutMs);
  const toolAdapter = new ToolAdapter({
    prefixToolNames: config.prefixToolNames,
    prefixDelimiter: config.prefixDelimiter,
    defaultTimeoutMs: config.defaultTimeoutMs,
  });
  const resourceAdapter = new ResourceAdapter();
  const lazyRegistry = new LazyToolRegistry();
  const samplingManager = new McpSamplingManager();
  const semanticSearch = new ToolSemanticSearch();
  const outputFilter = new OutputFilter();
  const rootsManager = new WorkspaceRootsManager();
  const circuitBreaker = new CircuitBreaker();
  const auditLogger = new AuditLogger();
  const elicitationManager = new ElicitationManager();
  const schemaCache = new SchemaCache();
  const bm25Index = new BM25ToolIndex();
  const tokenBudget = new TokenBudgetManager();
  const processPool = new ProcessPool(manager, { schemaCache });
  const telemetry = new TelemetryEngine();
  const agentWatch = new AgentWatch();
  const dashboard = new DashboardTelemetryProvider({
    manager,
    toolAdapter,
    resourceAdapter,
    circuitBreaker,
  });

  const service: DshMcpService = {
    manager,
    toolAdapter,
    resourceAdapter,
    configLoader,
    permissionManager,
    lazyRegistry,
    samplingManager,
    semanticSearch,
    outputFilter,
    rootsManager,
    circuitBreaker,
    auditLogger,
    elicitationManager,
    dashboard,
    schemaCache,
    bm25Index,
    tokenBudget,
    processPool,
    telemetry,
    agentWatch,
    config,

    getAllTools: async (): Promise<DshToolDefinition[]> => {
      const servers = manager.getAllServers();
      const toolLists = await Promise.all(
        servers.map((server) => toolAdapter.extractToolsFromServer(server))
      );
      return toolLists.flat();
    },

    getAllResources: async (): Promise<DshResourceDefinition[]> => {
      if (!config.exposeResources) return [];
      const servers = manager.getAllServers();
      const resourceLists = await Promise.all(
        servers.map((server) => resourceAdapter.extractResourcesFromServer(server))
      );
      return resourceLists.flat();
    },

    getAllPrompts: async (): Promise<DshPromptDefinition[]> => {
      if (!config.exposePrompts) return [];
      const servers = manager.getAllServers();
      const promptLists = await Promise.all(
        servers.map((server) => resourceAdapter.extractPromptsFromServer(server))
      );
      return promptLists.flat();
    },

    getStatuses: (): ServerStatus[] => {
      return manager.getAllStatuses();
    },

    refreshServers: async (): Promise<void> => {
      const serverEntries = Object.entries(config.servers || {});
      for (const [serverName, serverConfig] of serverEntries) {
        await manager.registerAndStartServer(serverName, serverConfig);
      }
    },
  };

  ctx.provide('mcp');
  ctx.mcp = service;

  // Initialize and connect servers when Cordis environment starts
  ctx.on('ready', async () => {
    console.info(`[dsh-plugin-mcp] Initializing ${Object.keys(config.servers || {}).length} MCP server(s)...`);
    await service.refreshServers();

    const tools = await service.getAllTools();
    console.info(`[dsh-plugin-mcp] Successfully registered ${tools.length} tool(s) from MCP servers.`);

    // If DSH tool registry service exists on Context, register tools directly
    if ((ctx as any).tools && typeof (ctx as any).tools.register === 'function') {
      for (const tool of tools) {
        (ctx as any).tools.register(tool);
      }
    }
  });

  // Gracefully close all client transports on shutdown
  ctx.on('dispose', async () => {
    console.info('[dsh-plugin-mcp] Shutting down MCP client connections...');
    await manager.stopAll();
  });
}

export default {
  name,
  Config,
  apply,
};
