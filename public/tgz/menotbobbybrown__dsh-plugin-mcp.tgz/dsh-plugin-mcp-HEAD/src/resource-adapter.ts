import type { DshPromptDefinition, DshResourceDefinition } from './types.js';
import type { ManagedServer } from './client-manager.js';

export class ResourceAdapter {
  /**
   * Fetches and converts MCP resources into DSH resource definitions.
   */
  public async extractResourcesFromServer(server: ManagedServer): Promise<DshResourceDefinition[]> {
    if (!server.connected || !server.client) {
      return [];
    }

    try {
      const response = await server.client.listResources();
      const resources = response.resources || [];

      return resources.map((res) => {
        return {
          uri: res.uri,
          name: res.name,
          description: res.description,
          mimeType: res.mimeType,
          serverName: server.name,
          read: async () => {
            const readResult = await server.client.readResource({ uri: res.uri });
            return readResult as any;
          },
        };
      });
    } catch (err: any) {
      console.error(`[dsh-plugin-mcp] Failed to list resources for server '${server.name}':`, err?.message || err);
      return [];
    }
  }

  /**
   * Fetches and converts MCP prompt templates into DSH prompt definitions.
   */
  public async extractPromptsFromServer(server: ManagedServer): Promise<DshPromptDefinition[]> {
    if (!server.connected || !server.client) {
      return [];
    }

    try {
      const response = await server.client.listPrompts();
      const prompts = response.prompts || [];

      return prompts.map((prompt) => {
        return {
          name: prompt.name,
          description: prompt.description,
          arguments: prompt.arguments,
          serverName: server.name,
          get: async (args: Record<string, any>) => {
            return server.client.getPrompt({
              name: prompt.name,
              arguments: args,
            });
          },
        };
      });
    } catch (err: any) {
      console.error(`[dsh-plugin-mcp] Failed to list prompts for server '${server.name}':`, err?.message || err);
      return [];
    }
  }
}
