# 🌟 MCP Server Catalog & Guide

Overview of popular Model Context Protocol (MCP) servers verified and pre-configured for `dsh-plugin-mcp`.

---

## Verified Servers Table

| Server | Category | Description | 1-Click Install Command |
| :--- | :--- | :--- | :--- |
| **GitHub** | Developer | Inspect repos, PRs, issues, and code | `npx dsh-mcp install github` |
| **PostgreSQL** | Database | SQL queries and schema inspection | `npx dsh-mcp install postgres` |
| **SQLite** | Database | Local SQLite database querying | `npx dsh-mcp install sqlite` |
| **Brave Search** | Search | Web search and news queries | `npx dsh-mcp install brave_search` |
| **Fetch** | Search | Convert web pages to clean Markdown | `npx dsh-mcp install fetch` |
| **Filesystem** | Filesystem | Local workspace directory reads/writes | `npx dsh-mcp install filesystem` |
| **Puppeteer** | Browser | Headless browser navigation & screenshots | `npx dsh-mcp install puppeteer` |
| **Memory** | Developer | Long-term knowledge graph memory | `npx dsh-mcp install memory` |

---

## Server Details & Required Credentials

### 1. GitHub MCP Server
* **Required Env:** `GITHUB_TOKEN`
* **Features:** Read file contents, search issues, create commits, list pull requests.

### 2. PostgreSQL MCP Server
* **Required Env:** `DATABASE_URL` (e.g. `postgresql://user:pass@localhost:5432/db`)
* **Features:** Execute read/write SQL queries, list tables, inspect schema definitions.

### 3. Brave Search MCP Server
* **Required Env:** `BRAVE_API_KEY`
* **Features:** High-accuracy public web search and link summarization.
