# 🔒 Enterprise Security & Hardening

`dsh-plugin-mcp` is designed for production and multi-tenant agentic workflows with defense-in-depth safety controls.

---

## 1. 🔑 Secrets Redaction (`SecurityEngine`)
Prevents sensitive API credentials from leaking into terminal outputs, error traces, or LLM context windows:
* Automatically masks OpenAI, Anthropic, DeepSeek, and GitHub personal access tokens (`sk-...`, `ghp_...`, `gho_...`).
* Sanitizes `process.env` dictionaries before logging.

---

## 2. 🛡️ Permission Policies (`allow`, `ask`, `deny`)
Pattern-based execution rules ensure human oversight for sensitive operations:

```yaml
plugins:
  mcp:
    permissions:
      allow:
        - "github_list_*"
        - "filesystem_read_*"
      ask:
        - "postgres_query"
        - "filesystem_delete_*"
      deny:
        - "bash_rm_rf_*"
```

---

## 3. 🚦 Circuit Breaker & Rate Limiting
Protects against runaway agent retry loops and runaway token billing:
* **Failure Threshold:** Automatically trips open if an MCP server fails repeatedly.
* **Rate Limiting:** Enforces a rolling ceiling on requests per minute.
* **Self-Healing:** Probes server recovery after a cooldown period.

---

## 4. 📜 Audit Logging
Maintains append-only JSON audit logs for compliance and threat analysis:
```json
{
  "timestamp": "2026-08-22T11:45:00.000Z",
  "eventType": "TOOL_EXECUTION",
  "toolName": "postgres_query",
  "serverName": "postgres",
  "verdict": "allow",
  "durationMs": 45,
  "success": true
}
```
