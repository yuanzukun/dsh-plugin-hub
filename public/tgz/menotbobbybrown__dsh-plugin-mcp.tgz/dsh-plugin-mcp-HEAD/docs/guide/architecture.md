# 🏗️ Architecture & Token Optimization

Understand how `dsh-plugin-mcp` bridges DeepSeek LLM agents to MCP servers efficiently without prompt context bloat.

---

## 📐 Architecture Overview

```mermaid
graph TD
    A[DeepSeek LLM Agent] --> B[dsh-plugin-mcp Core Bridge]
    
    subgraph "Context Defender"
        B --> C1[LazyToolRegistry: Stubs Indexed]
        B --> C2[ToolSemanticSearch: Top-K Matching]
        B --> C3[OutputFilter: Large Payload Spillover]
    end
    
    subgraph "Transport Subsystem"
        B --> D1[Stdio Transport: Child Process Management]
        B --> D2[SSE Transport: EventSource Streaming]
        B --> D3[WebSocket Transport: Full-Duplex Connection]
    end
    
    subgraph "Safety Subsystem"
        B --> E1[SecurityEngine: Secrets Masking]
        B --> E2[CircuitBreaker: Loop Prevention]
        B --> E3[AuditLogger: Forensic Log Stream]
    end
```

---

## ⚡ Key Optimizations

### 1. Lazy Tool Registration
When 50+ MCP servers (500+ tools) are mounted, injecting all raw JSON schemas consumes 50k+ input tokens. `LazyToolRegistry` indexes lightweight stubs in agent memory and streams parameter schemas only when invoked.

### 2. Semantic Relevance Ranking (`ToolSemanticSearch`)
Uses TF-IDF token scoring to dynamically pick the top-K relevant tools matching the user's prompt turn.

### 3. Payload Truncation & Artifact Spillover (`OutputFilter`)
Massive outputs (>30k characters) are automatically stored in local scratch artifacts with structured summary pointers.
