# 💻 CLI Reference (`dsh-mcp`)

`dsh-plugin-mcp` includes a standalone command-line interface that mirrors Claude Code's terminal experience.

---

## Commands

### `dsh-mcp catalog`
Explore the verified catalog of built-in official and community MCP servers:
```bash
npx dsh-mcp catalog
```

### `dsh-mcp install <name>`
1-Click installation of a verified server from the catalog:
```bash
# Install to user global scope (~/.dsh/mcp.json)
npx dsh-mcp install github --scope user

# Install to project local scope (.dsh/mcp.json)
npx dsh-mcp install postgres --scope project
npx dsh-mcp install sqlite --scope project
```

### `dsh-mcp list`
List all configured servers across all scopes and view their active statuses:
```bash
npx dsh-mcp list

# Output in JSON format
npx dsh-mcp list --json
```

### `dsh-mcp test <name>`
Connect to an MCP server, verify protocol handshake, test tool discovery, and benchmark latency:
```bash
npx dsh-mcp test github
```

### `dsh-mcp add <name> -- <command> [args...]`
Add a custom MCP server:
```bash
# Stdio server
npx dsh-mcp add custom_tool --scope user -- npx -y my-custom-server

# Remote SSE server
npx dsh-mcp add weather --transport sse -- https://weather.example.com/sse
```

### `dsh-mcp remove <name>`
Remove an MCP server from configuration:
```bash
npx dsh-mcp remove github --scope user
```
