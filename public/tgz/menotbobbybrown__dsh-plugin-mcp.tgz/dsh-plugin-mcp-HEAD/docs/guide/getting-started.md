# ⚡ Getting Started

Learn how to install and configure `dsh-plugin-mcp` in your DeepSeek Harness environment.

---

## 📦 Installation

### In DeepSeek Harness Monorepo
```bash
# Add from GitHub
dsh plugin --profile web add "github:menotbobbybrown/dsh-plugin-mcp"

# Or install via npm
dsh plugin --profile web add dsh-plugin-mcp
```

---

## 📁 Multi-Scope Configuration

`dsh-plugin-mcp` automatically discovers and merges configurations across three distinct scopes:

### 1. User Global Scope (`~/.dsh/mcp.json`)
Servers configured here are available to all projects on your machine:
```json
{
  "mcpServers": {
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"
      }
    }
  }
}
```

### 2. Project Local Scope (`.dsh/mcp.json` or `.mcp.json`)
Scoped strictly to the current workspace root.

### 3. Profile / Inline Scope (`dsh.config.yaml`)
Direct profile overrides:
```yaml
plugins:
  mcp:
    prefixToolNames: true
    prefixDelimiter: "_"
    defaultTimeoutMs: 60000
    servers:
      postgres:
        command: npx
        args: ["-y", "@modelcontextprotocol/server-postgres", "${DATABASE_URL}"]
```
