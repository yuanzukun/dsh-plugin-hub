# 🚀 dsh-plugin-mcp Documentation

> **Universal Model Context Protocol (MCP) Bridge Plugin for DeepSeek Harness (`dsh`)**

`dsh-plugin-mcp` connects your DeepSeek agents to the entire ecosystem of [Model Context Protocol (MCP)](https://modelcontextprotocol.io) servers with full Claude Code-level feature parity, enterprise security, and token efficiency.

---

## 🧭 Navigation

- ⚡ [Getting Started](guide/getting-started.md)
- 💻 [CLI Reference (`dsh-mcp`)](guide/cli.md)
- 🔒 [Enterprise Security & Hardening](guide/security.md)
- 🌟 [MCP Server Catalog & 1-Click Install](guide/servers-catalog.md)
- 🏗️ [Architecture & Token Optimization](guide/architecture.md)

---

## ⚡ 1-Minute Quickstart

```bash
# Browse verified built-in server catalog
npx dsh-mcp catalog

# 1-Click install popular servers
npx dsh-mcp install github --scope user
npx dsh-mcp install postgres --scope project
npx dsh-mcp install sqlite --scope project

# Test connectivity and latency
npx dsh-mcp test github
```
