# 🗺️ dsh-plugin-mcp Roadmap: Path to Full Claude Code MCP Parity

This document outlines the strategic roadmap for **`dsh-plugin-mcp`** to achieve complete feature parity, performance equivalence, and developer experience comparable to Anthropic's Claude Code MCP architecture within the DeepSeek Harness ecosystem.

---

## 🧭 Vision

To provide DeepSeek Harness with an enterprise-grade, high-performance Model Context Protocol (MCP) subsystem that delivers:
1. **Zero-Configuration Onboarding:** Auto-discovery of local and project MCP configurations.
2. **Context Efficiency:** Dynamic lazy-loading to support 50+ MCP servers without bloating prompt context windows.
3. **Enterprise Security:** Granular execution permissions, sandboxing, and audit logging.
4. **Interactive Elicitation & Sampling:** Full client-to-server sampling and bidirectional MCP communication.

---

## 📍 Release Phases & Milestones

```mermaid
gantt
    title dsh-plugin-mcp Development Roadmap
    dateFormat  YYYY-MM-DD
    section Phase 1: Core Foundation
    Universal Transports (stdio, sse, ws)      :done, p1_1, 2026-08-01, 2026-08-15
    Cordis Plugin Integration                  :done, p1_2, 2026-08-15, 2026-08-20
    Initial Release v0.1.0                     :done, p1_3, 2026-08-21, 2026-08-22
    section Phase 2: Configuration & Scopes
    Multi-Scope Resolution (~/.dsh, .mcp.json) :done, p2_1, 2026-08-22, 2026-08-22
    Permission Engine (Allow / Ask / Deny)     :done, p2_2, 2026-08-22, 2026-08-22
    CLI Experience (dsh-mcp)                   :done, p2_3, 2026-08-22, 2026-08-22
    section Phase 3: Context & Performance
    Lazy Tool Loading & Dynamic Indexing       :done, p3_1, 2026-08-22, 2026-08-22
    TF-IDF Semantic Search                     :done, p3_2, 2026-08-22, 2026-08-22
    Output Truncation & Artifact Spillover     :done, p3_3, 2026-08-22, 2026-08-22
    section Phase 4: Advanced MCP Protocols
    MCP Sampling & Bidirectional Requests      :done, p4_1, 2026-08-22, 2026-08-22
    Root Directory / Sandbox Boundaries        :done, p4_2, 2026-08-22, 2026-08-22
    Interactive Elicitation Engine             :done, p4_3, 2026-08-22, 2026-08-22
    section Phase 5: Web UI & Ecosystem
    In-App Web UI Telemetry Provider           :done, p5_1, 2026-08-22, 2026-08-22
    1-Click Built-in Server Catalog            :done, p5_2, 2026-08-22, 2026-08-22
```

---

## 🎯 Detailed Milestones

### Phase 1: Core Foundation (✅ Complete - v0.1.0)
- [x] **Universal Transports:** Support `stdio`, `sse`, and `websocket` MCP connections via `@modelcontextprotocol/sdk`.
- [x] **Cordis Lifecycle:** Full integration with Cordis context lifecycle hooks (`apply`, `ready`, `dispose`).
- [x] **Tool & Resource Registration:** Automatic schema transformation, argument validation, and resource bridging.
- [x] **Fault Isolation:** Per-server timeout barriers, isolated crash recovery, and health status indicators.

---

### Phase 2: Claude Code Parity — Scopes & Security (✅ Complete - v0.2.0)
- [x] **Multi-Scope Configuration Hierarchy:**
  * **User Global Scope:** `~/.dsh/mcp.json` (mirrors `~/.claude.json` user scope).
  * **Project Local Scope:** `.dsh/mcp.json` or `.mcp.json` in repository root.
  * **Profile / Inline Scope:** `dsh.config.yaml` profile overrides.
- [x] **Granular Permission Policies:**
  * Pattern-based tool rules: `allow` (auto-approve), `ask` (human confirmation), `deny` (blocked).
  * Protection against dangerous mutating actions (e.g. destructive database queries or disk writes).
- [x] **Dedicated CLI Experience (`dsh-mcp`):**
  * `dsh-mcp add <name> --scope <user|project> -- <cmd> [args...]`
  * `dsh-mcp list` (displays active servers, tools count, and latency)
  * `dsh-mcp test <name>` (runs synthetic preflight health check)
  * `dsh-mcp remove <name>`

---

### Phase 3: Token Optimization & Lazy Loading (✅ Complete - v0.3.0)
- [x] **Lazy Tool Cataloging (Context Defender):**
  * Prevent prompt context window exhaustion when 50+ servers (500+ tools) are mounted (`LazyToolRegistry`).
  * Register lightweight tool stubs into agent memory; stream full parameter schemas on demand.
- [x] **Semantic Tool Search:**
  * Rank tool descriptions using TF-IDF token relevance so the agent retrieves only tools relevant to the current user prompt (`ToolSemanticSearch`).
- [x] **Output Truncation & Artifact Spillover:**
  * Automatically convert large tool outputs into local scratch artifacts with summary pointers (`OutputFilter`).

---

### Phase 4: Advanced MCP Capabilities (✅ Complete - v0.3.0)
- [x] **MCP Sampling Support (Bidirectional Agent Loops):**
  * Enable MCP servers to request LLM completions through DeepSeek Harness via MCP `sampling/createMessage` (`McpSamplingManager`).
- [x] **Roots & Directory Isolation:**
  * Advertise workspace roots to MCP servers with strict sandbox boundary checks (`WorkspaceRootsManager`).
- [x] **Interactive Elicitation:**
  * Support interactive UI forms and parameter elicitation prompts requested by MCP servers (`ElicitationManager`).

---

### Phase 5: Ecosystem & DSH Web UI (✅ Complete - v0.3.0)
- [x] **Web UI Management Dashboard Provider:**
  * Live server status summaries, telemetry metrics, and tool counts (`DashboardTelemetryProvider`).
- [x] **1-Click Built-in Server Registry & Marketplace:**
  * 1-Click installation of verified servers (GitHub, PostgreSQL, SQLite, Brave Search, Fetch, Puppeteer, Memory) via `dsh-mcp install` and `dsh-mcp catalog` (`ServerRegistry`).

---

## 🤝 Contributing

We welcome community RFCs, pull requests, and feedback!
* **Issues & Discussions:** [https://github.com/menotbobbybrown/dsh-plugin-mcp/discussions](https://github.com/menotbobbybrown/dsh-plugin-mcp/discussions)
* **License:** MIT
