---
name: Feature Request
about: Suggest an idea or architectural improvement for this project
title: '[FEAT] '
labels: 'enhancement, discussion'
assignees: ''
---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the Solution You'd Like**
A clear and concise description of what you want to happen.

**Describe Alternatives You've Considered**
A clear and concise description of any alternative solutions or features you've considered.

**Additional Context**
Add any other context, code mockups, or diagrams about the feature request here.
