## 🚀 dsh-plugin-mcp v0.3.0: Complete MCP Ecosystem Engine

`dsh-plugin-mcp` v0.3.0 delivers the complete end-to-end Model Context Protocol subsystem for DeepSeek Harness, bringing Claude Code-level power, enterprise security hardening, dynamic token optimization, and 1-click server installations.

---

### ✨ Highlights in v0.3.0

#### 1. 🌟 1-Click Curated Server Catalog (`dsh-mcp catalog` / `dsh-mcp install`)
Install verified MCP servers with a single command without memorizing long package arguments or environment configs:
* `dsh-mcp catalog` — Browse curated servers (GitHub, Postgres, SQLite, Brave Search, Fetch, Puppeteer, Memory).
* `dsh-mcp install github --scope user` — Installs GitHub MCP server to user global config.
* `dsh-mcp install sqlite --scope project` — Installs SQLite MCP server to local workspace.

#### 2. 🔒 Enterprise Security Hardening
* **`SecurityEngine`**: Zero-leak secrets redaction (API keys/bearer tokens), shell injection protection, and path traversal guards.
* **`CircuitBreaker`**: Automatic tripwire and rate limiter preventing runaway agent loops and API quota burn.
* **`AuditLogger`**: Structured JSON logging of all tool invocations and permissions checks.

#### 3. ⚡ Dynamic Token & Context Optimization
* **`LazyToolRegistry`**: Registers lightweight tool stubs to prevent prompt context bloat across 50+ servers.
* **`ToolSemanticSearch`**: TF-IDF token relevance ranker that filters and injects only the top matching tools for the user's prompt.
* **`OutputFilter`**: Automatically intercepts massive tool outputs (>30k chars), persisting them to artifact files with structured previews.

#### 4. 🔄 Bidirectional Sampling & Interactive Elicitation
* **`McpSamplingManager`**: Enables connected MCP servers to request LLM completions through DeepSeek Harness (`sampling/createMessage`).
* **`ElicitationManager`**: Handles interactive user prompts and parameter elicitation forms requested by MCP servers.
* **`WorkspaceRootsManager`**: MCP `roots/list` workspace boundary support.

#### 5. 📊 Web UI Telemetry Provider
* **`DashboardTelemetryProvider`**: Exposes live connected server metrics, tool counts, and latency telemetry for DeepSeek Harness Web UI.

---

### 🧪 Test Coverage & CI/CD
* **42 / 42 unit & integration tests passing** (`vitest`) across 17 test suites.
* Automated CI matrix workflows verified on Ubuntu, Windows, and macOS (Node 20, 22, 24).
