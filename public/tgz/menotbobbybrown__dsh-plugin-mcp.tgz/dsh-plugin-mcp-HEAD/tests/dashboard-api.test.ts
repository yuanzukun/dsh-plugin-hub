import { describe, it, expect } from 'vitest';
import { McpClientManager } from '../src/client-manager.js';
import { ToolAdapter } from '../src/tool-adapter.js';
import { ResourceAdapter } from '../src/resource-adapter.js';
import { CircuitBreaker } from '../src/circuit-breaker.js';
import { DashboardTelemetryProvider } from '../src/dashboard-api.js';

describe('DashboardTelemetryProvider', () => {
  it('should generate telemetry summary of servers and marketplace', async () => {
    const manager = new McpClientManager();
    const toolAdapter = new ToolAdapter();
    const resourceAdapter = new ResourceAdapter();
    const circuitBreaker = new CircuitBreaker();

    const provider = new DashboardTelemetryProvider({
      manager,
      toolAdapter,
      resourceAdapter,
      circuitBreaker,
    });

    const summary = await provider.getSummary();
    expect(summary.connectedServers).toBe(0);
    expect(summary.circuitState).toBe('CLOSED');
    expect(summary.availableMarketplaceServers).toBeGreaterThanOrEqual(8);
  });
});
