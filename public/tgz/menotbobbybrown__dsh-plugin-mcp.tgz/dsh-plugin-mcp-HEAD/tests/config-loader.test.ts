import { describe, it, expect } from 'vitest';
import { ConfigLoader } from '../src/config-loader.js';

describe('ConfigLoader', () => {
  it('should merge inline profile config over default scopes', () => {
    const loader = new ConfigLoader({ enableProjectScope: false, enableUserScope: false });
    const config = loader.loadMergedConfig({
      servers: {
        sqlite: {
          command: 'npx',
          args: ['-y', '@modelcontextprotocol/server-sqlite'],
        },
      },
    });

    expect(config.servers.sqlite).toBeDefined();
    expect((config.servers.sqlite as any).command).toBe('npx');
  });
});
