import { describe, it, expect } from 'vitest';
import { McpDashboardServer } from '../src/ui-server.js';

describe('McpDashboardServer (Live Real-Time Web Dashboard)', () => {
  it('should start HTTP server and respond with HTML dashboard and JSON telemetry', async () => {
    const mockService: any = {
      getDashboardSummary: async () => ({
        connectedServers: 3,
        totalTools: 42,
        totalResources: 5,
        circuitState: 'CLOSED',
        servers: [],
        availableMarketplaceServers: 8,
      }),
      getMetrics: () => ({ p50: 0.12, p95: 0.38, p99: 0.75 }),
      searchTools: () => [],
    };

    const server = new McpDashboardServer(mockService, 4099);
    const boundPort = await server.start();
    expect(boundPort).toBe(4099);

    // Test GET /
    const htmlRes = await fetch(`http://127.0.0.1:${boundPort}/`);
    expect(htmlRes.status).toBe(200);
    const html = await htmlRes.text();
    expect(html).toContain('DeepSeek Harness • MCP Live Dashboard');

    // Test GET /api/summary
    const jsonRes = await fetch(`http://127.0.0.1:${boundPort}/api/summary`);
    expect(jsonRes.status).toBe(200);
    const json = await jsonRes.json();
    expect(json.connectedServers).toBe(3);
    expect(json.totalTools).toBe(42);

    await server.stop();
  });
});
