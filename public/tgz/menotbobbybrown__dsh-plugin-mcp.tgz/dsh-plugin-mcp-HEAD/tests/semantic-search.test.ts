import { describe, it, expect } from 'vitest';
import { ToolSemanticSearch } from '../src/semantic-search.js';
import type { LightweightToolStub } from '../src/lazy-registry.js';

describe('ToolSemanticSearch', () => {
  const mockTools: LightweightToolStub[] = [
    {
      name: 'github_create_issue',
      description: 'Create a new issue in a GitHub repository with title and body',
      serverName: 'github',
      originalName: 'create_issue',
    },
    {
      name: 'postgres_execute_sql',
      description: 'Execute SQL queries against PostgreSQL relational database',
      serverName: 'postgres',
      originalName: 'execute_sql',
    },
    {
      name: 'brave_web_search',
      description: 'Search the public internet and web pages using Brave Search API',
      serverName: 'brave_search',
      originalName: 'web_search',
    },
  ];

  it('should rank database tools highest for database queries', () => {
    const searcher = new ToolSemanticSearch();
    const results = searcher.search(mockTools, 'query postgres sql database', 2);

    expect(results.length).toBeGreaterThan(0);
    expect(results[0].tool.name).toBe('postgres_execute_sql');
  });

  it('should rank web search tools highest for internet queries', () => {
    const searcher = new ToolSemanticSearch();
    const results = searcher.search(mockTools, 'search the web for news', 2);

    expect(results.length).toBeGreaterThan(0);
    expect(results[0].tool.name).toBe('brave_web_search');
  });

  it('should handle empty queries gracefully by returning top tools', () => {
    const searcher = new ToolSemanticSearch();
    const results = searcher.search(mockTools, '', 2);

    expect(results.length).toBe(2);
  });
});
