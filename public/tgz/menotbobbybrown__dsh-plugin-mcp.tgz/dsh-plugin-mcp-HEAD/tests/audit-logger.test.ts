import { describe, it, expect } from 'vitest';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import { AuditLogger } from '../src/audit-logger.js';

describe('AuditLogger', () => {
  it('should write sanitized audit events to log file', () => {
    const testLogPath = path.join(os.tmpdir(), `test-audit-${Date.now()}.log`);
    const logger = new AuditLogger({ logPath: testLogPath });

    logger.logEvent({
      eventType: 'TOOL_EXECUTION',
      toolName: 'github_create_issue',
      serverName: 'github',
      verdict: 'allow',
      durationMs: 120,
      success: true,
      metadata: { apiKey: 'sk-123456789012345678901234' },
    });

    expect(fs.existsSync(testLogPath)).toBe(true);
    const content = fs.readFileSync(testLogPath, 'utf-8');
    expect(content).toContain('github_create_issue');
    expect(content).toContain('TOOL_EXECUTION');
    expect(content).not.toContain('sk-123456789012345678901234'); // Must be masked

    // Clean up
    try {
      fs.unlinkSync(testLogPath);
    } catch {}
  });
});
