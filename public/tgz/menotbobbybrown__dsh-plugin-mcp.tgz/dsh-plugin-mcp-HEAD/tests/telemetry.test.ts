import { describe, it, expect } from 'vitest';
import { TelemetryEngine } from '../src/telemetry.js';

describe('TelemetryEngine (Latency Histograms & Metrics)', () => {
  it('should accurately compute p50, p95, and p99 percentiles', () => {
    const telemetry = new TelemetryEngine();

    // Record 100 samples with varying durations (1ms to 100ms)
    for (let i = 1; i <= 100; i++) {
      telemetry.recordSample({
        serverName: 'postgres',
        toolName: 'postgres_query',
        durationMs: i,
        success: i % 10 !== 0,
      });
    }

    const stats = telemetry.computeStats('postgres');
    expect(stats.count).toBe(100);
    expect(stats.min).toBe(1);
    expect(stats.max).toBe(100);
    expect(stats.p50).toBe(51);
    expect(stats.p95).toBe(96);
    expect(stats.p99).toBe(100);

    const summary = telemetry.getSummary();
    expect(summary.totalInvocations).toBe(100);
    expect(summary.serverBreakdown[0].errors).toBe(10);
  });
});
