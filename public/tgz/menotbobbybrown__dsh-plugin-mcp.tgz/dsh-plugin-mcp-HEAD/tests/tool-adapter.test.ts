import { describe, it, expect } from 'vitest';
import { ToolAdapter } from '../src/tool-adapter.js';

describe('ToolAdapter', () => {
  it('should prefix tool names when configured', () => {
    const adapter = new ToolAdapter({
      prefixToolNames: true,
      prefixDelimiter: '_',
    });

    expect(adapter.formatToolName('github', 'create_issue')).toBe('github_create_issue');
    expect(adapter.formatToolName('sqlite-db', 'query')).toBe('sqlite_db_query');
  });

  it('should not prefix tool names when prefixToolNames is false', () => {
    const adapter = new ToolAdapter({
      prefixToolNames: false,
    });

    expect(adapter.formatToolName('github', 'create_issue')).toBe('create_issue');
  });

  it('should format simple text result', () => {
    const adapter = new ToolAdapter();
    const result = adapter.formatToolResult({
      content: [{ type: 'text', text: 'Operation successful' }],
    });

    expect(result).toBe('Operation successful');
  });

  it('should format multi-block result with text and image', () => {
    const adapter = new ToolAdapter();
    const result = adapter.formatToolResult({
      content: [
        { type: 'text', text: 'Here is the diagram:' },
        { type: 'image', mimeType: 'image/png', data: 'base64data' },
      ],
    });

    expect(result).toEqual({
      isError: false,
      content: 'Here is the diagram:',
      artifacts: [{ type: 'image', mimeType: 'image/png', data: 'base64data' }],
    });
  });

  it('should handle isError result', () => {
    const adapter = new ToolAdapter();
    const result = adapter.formatToolResult({
      isError: true,
      content: [{ type: 'text', text: 'Database error: table not found' }],
    });

    expect(result).toEqual({
      isError: true,
      content: 'Database error: table not found',
    });
  });
});
