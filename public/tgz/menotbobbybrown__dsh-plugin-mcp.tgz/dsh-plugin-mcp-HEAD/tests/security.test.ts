import { describe, it, expect } from 'vitest';
import { SecurityEngine } from '../src/security.js';

describe('SecurityEngine', () => {
  it('should mask API keys and bearer tokens in logs and traces', () => {
    const rawLog = 'Connecting with Authorization: Bearer sk-ant-api03-abcdef12345678901234 and GitHub token ghp_123456789012345678901234567890123456';
    const masked = SecurityEngine.maskSecrets(rawLog, ['custom_secret_password_123']);

    expect(masked).not.toContain('ghp_123456789012345678901234567890123456');
    expect(masked).toContain('***REDACTED');
  });

  it('should sanitize environment variables dictionary', () => {
    const env = {
      PATH: '/usr/bin:/bin',
      GITHUB_TOKEN: 'secret_token_val',
      DATABASE_PASSWORD: 'super_secret_db_pass',
      PORT: '3000',
    };

    const sanitized = SecurityEngine.sanitizeEnvForLogging(env);
    expect(sanitized.PATH).toBe('/usr/bin:/bin');
    expect(sanitized.PORT).toBe('3000');
    expect(sanitized.GITHUB_TOKEN).toBe('***REDACTED***');
    expect(sanitized.DATABASE_PASSWORD).toBe('***REDACTED***');
  });

  it('should detect and prevent shell injection metacharacters', () => {
    expect(SecurityEngine.validateCommandSafety('npx -y @modelcontextprotocol/server-github').safe).toBe(true);
    expect(SecurityEngine.validateCommandSafety('npx; rm -rf /').safe).toBe(false);
    expect(SecurityEngine.validateCommandSafety('npx && cat /etc/passwd').safe).toBe(false);
  });

  it('should validate and block path traversal attempts', () => {
    expect(SecurityEngine.isSafePath('src/index.ts', './')).toBe(true);
    expect(SecurityEngine.isSafePath('../../etc/shadow', './')).toBe(false);
    expect(SecurityEngine.isSafePath('evil\0path', './')).toBe(false);
  });
});
