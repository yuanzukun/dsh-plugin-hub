import { describe, it, expect } from 'vitest';
import { LazyToolRegistry } from '../src/lazy-registry.js';
import type { DshToolDefinition } from '../src/types.js';

describe('LazyToolRegistry', () => {
  it('should register tool stubs and resolve full definitions on demand', () => {
    const registry = new LazyToolRegistry();

    const dummyTool: DshToolDefinition = {
      name: 'github_create_issue',
      description: 'Create an issue in a GitHub repository',
      parameters: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          body: { type: 'string' },
        },
        required: ['title'],
      },
      serverName: 'github',
      originalName: 'create_issue',
      execute: async (args) => ({ success: true, args }),
    };

    registry.registerTool(dummyTool);

    expect(registry.size()).toBe(1);

    const stubs = registry.getToolStubs();
    expect(stubs.length).toBe(1);
    expect(stubs[0].name).toBe('github_create_issue');
    expect((stubs[0] as any).parameters).toBeUndefined(); // Stubs do not carry parameter schema weight

    const resolved = registry.resolveTool('github_create_issue');
    expect(resolved).toBeDefined();
    expect(resolved?.parameters.properties.title).toBeDefined();
  });

  it('should search tools by keyword', () => {
    const registry = new LazyToolRegistry();

    registry.registerTools([
      {
        name: 'postgres_query',
        description: 'Execute SQL read query on Postgres',
        parameters: {},
        serverName: 'postgres',
        originalName: 'query',
        execute: async () => ({}),
      },
      {
        name: 'github_get_pr',
        description: 'Fetch PR details',
        parameters: {},
        serverName: 'github',
        originalName: 'get_pr',
        execute: async () => ({}),
      },
    ]);

    const results = registry.searchTools('sql');
    expect(results.length).toBe(1);
    expect(results[0].name).toBe('postgres_query');
  });

  it('should clear server tools on disposal', () => {
    const registry = new LazyToolRegistry();

    registry.registerTool({
      name: 'fs_read',
      description: 'Read file',
      parameters: {},
      serverName: 'filesystem',
      originalName: 'read',
      execute: async () => ({}),
    });

    registry.clearServerTools('filesystem');
    expect(registry.size()).toBe(0);
  });
});
