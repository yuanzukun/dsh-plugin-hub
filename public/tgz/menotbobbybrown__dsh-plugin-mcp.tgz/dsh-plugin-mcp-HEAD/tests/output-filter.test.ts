import { describe, it, expect } from 'vitest';
import { OutputFilter } from '../src/output-filter.js';

describe('OutputFilter', () => {
  it('should return short output without truncation', () => {
    const filter = new OutputFilter({ maxCharLength: 500 });
    const result = filter.processOutput({ status: 'ok', data: [1, 2, 3] }, 'test_tool');

    expect(result.isTruncated).toBe(false);
    expect(result.artifactPath).toBeUndefined();
    expect(result.output).toContain('"status": "ok"');
  });

  it('should truncate huge output and write to artifact file', () => {
    const filter = new OutputFilter({ maxCharLength: 200 });
    const hugePayload = 'A'.repeat(5000);

    const result = filter.processOutput(hugePayload, 'dump_tool');

    expect(result.isTruncated).toBe(true);
    expect(result.artifactPath).toBeDefined();
    expect(result.output).toContain('Output Truncated');
    expect(result.output).toContain('Full output saved to artifact');
    expect(result.originalLength).toBe(5000);
  });
});
