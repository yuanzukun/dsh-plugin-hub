import { describe, it, expect } from 'vitest';
import { McpClientManager } from '../src/client-manager.js';
import { ProcessPool } from '../src/process-pool.js';

describe('ProcessPool (Dormant-by-Default & LRU Reaper)', () => {
  it('should register servers in DORMANT state with zero active processes', () => {
    const manager = new McpClientManager();
    const pool = new ProcessPool(manager, { maxActiveProcesses: 3, idleTimeoutMs: 1000 });

    // Register 100 servers
    for (let i = 0; i < 100; i++) {
      pool.registerDormant(`server_${i}`, {
        type: 'stdio',
        command: 'echo',
        args: ['hello'],
      });
    }

    const stats = pool.getStats();
    expect(stats.totalRegistered).toBe(100);
    expect(stats.activeProcesses).toBe(0);
    expect(stats.dormantServers).toBe(100);
  });

  it('should reap idle processes exceeding idle timeout', async () => {
    const manager = new McpClientManager();
    const pool = new ProcessPool(manager, { idleTimeoutMs: 10 }); // 10ms timeout

    pool.registerDormant('srv_idle', {
      type: 'stdio',
      command: 'echo',
      args: ['hello'],
    });

    // Simulate entry state
    const entry = (pool as any).entries.get('srv_idle');
    entry.state = 'ACTIVE';
    entry.lastUsedTimestamp = Date.now() - 50; // 50ms ago

    const reaped = await pool.reapIdleProcesses();
    expect(reaped).toBe(1);
    expect(entry.state).toBe('DORMANT');
  });
});
