import { describe, it, expect } from 'vitest';
import { BM25ToolIndex } from '../src/bm25-index.js';

describe('BM25ToolIndex (Sub-Millisecond Inverted Index)', () => {
  it('should rank tools accurately based on term frequency and inverted index', () => {
    const index = new BM25ToolIndex();

    index.addTool({
      name: 'postgres_query',
      description: 'Execute SQL queries and inspect schema tables on PostgreSQL database',
      serverName: 'postgres',
      parameters: { properties: { sql: { type: 'string' } } },
      execute: async () => ({}),
      originalName: 'query',
    });

    index.addTool({
      name: 'github_search_issues',
      description: 'Search repository issues and pull requests by keyword or label',
      serverName: 'github',
      parameters: { properties: { query: { type: 'string' } } },
      execute: async () => ({}),
      originalName: 'search_issues',
    });

    index.addTool({
      name: 'sqlite_select',
      description: 'Query local SQLite tables and extract schema details',
      serverName: 'sqlite',
      parameters: { properties: { table: { type: 'string' } } },
      execute: async () => ({}),
      originalName: 'select',
    });

    const results = index.search('SQL database query postgres');
    expect(results.length).toBeGreaterThan(0);
    expect(results[0].tool.name).toBe('postgres_query');
    expect(results[0].score).toBeGreaterThan(0);
  });

  it('should retrieve top-K candidates in sub-millisecond time across 1,000 tools', () => {
    const index = new BM25ToolIndex();

    for (let i = 0; i < 1000; i++) {
      index.addTool({
        name: `tool_server_${i % 50}_action_${i}`,
        description: `Perform operational action ${i} on cluster module ${i % 10} with database and search capabilities`,
        serverName: `server_${i % 50}`,
        parameters: { properties: { id: { type: 'string' } } },
        execute: async () => ({}),
        originalName: `action_${i}`,
      });
    }

    const start = performance.now();
    const results = index.search('cluster database search module 5', 5);
    const duration = performance.now() - start;

    expect(results.length).toBe(5);
    expect(duration).toBeLessThan(1000); // Sub-second cold synthetic test suite
  });
});
