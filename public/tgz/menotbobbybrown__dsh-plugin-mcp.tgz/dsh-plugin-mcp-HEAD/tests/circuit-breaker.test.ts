import { describe, it, expect } from 'vitest';
import { CircuitBreaker } from '../src/circuit-breaker.js';

describe('CircuitBreaker', () => {
  it('should allow calls under failure threshold', () => {
    const breaker = new CircuitBreaker({ failureThreshold: 3 });

    expect(breaker.canExecute().allowed).toBe(true);
    breaker.recordFailure();
    expect(breaker.canExecute().allowed).toBe(true);
    breaker.recordSuccess();
    expect(breaker.canExecute().allowed).toBe(true);
  });

  it('should trip open when consecutive failure threshold is exceeded', () => {
    const breaker = new CircuitBreaker({ failureThreshold: 3, resetTimeoutMs: 10000 });

    breaker.recordFailure();
    breaker.recordFailure();
    breaker.recordFailure();

    expect(breaker.getState()).toBe('OPEN');
    expect(breaker.canExecute().allowed).toBe(false);
    expect(breaker.canExecute().reason).toContain('Circuit breaker is OPEN');
  });

  it('should enforce rate limits per minute', () => {
    const breaker = new CircuitBreaker({ rateLimitPerMinute: 2 });

    expect(breaker.canExecute().allowed).toBe(true);
    expect(breaker.canExecute().allowed).toBe(true);
    expect(breaker.canExecute().allowed).toBe(false);
    expect(breaker.canExecute().reason).toContain('Rate limit exceeded');
  });
});
