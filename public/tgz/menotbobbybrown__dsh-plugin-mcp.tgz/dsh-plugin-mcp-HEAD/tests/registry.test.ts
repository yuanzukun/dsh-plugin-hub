import { describe, it, expect } from 'vitest';
import { ServerRegistry, POPULAR_MCP_SERVERS } from '../src/registry.js';

describe('ServerRegistry', () => {
  it('should list all popular built-in servers in the catalog', () => {
    const servers = ServerRegistry.getAvailableServers();
    expect(servers.length).toBeGreaterThanOrEqual(8);
    expect(servers.some((s) => s.name === 'GitHub')).toBe(true);
    expect(servers.some((s) => s.name === 'PostgreSQL')).toBe(true);
    expect(servers.some((s) => s.name === 'Brave Search')).toBe(true);
  });

  it('should find server by name or alias', () => {
    const github = ServerRegistry.findServer('github');
    expect(github).toBeDefined();
    expect(github?.configTemplate.command).toBe('npx');

    const brave = ServerRegistry.findServer('brave-search');
    expect(brave).toBeDefined();
    expect(brave?.name).toBe('Brave Search');
  });
});
