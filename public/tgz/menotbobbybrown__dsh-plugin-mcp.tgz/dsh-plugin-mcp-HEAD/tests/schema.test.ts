import { describe, it, expect } from 'vitest';
import { parseConfig, DshMcpPluginConfigSchema } from '../src/schema.js';

describe('DshMcpPluginConfigSchema', () => {
  it('should parse empty config with defaults', () => {
    const config = parseConfig({});
    expect(config.servers).toEqual({});
    expect(config.prefixToolNames).toBe(true);
    expect(config.prefixDelimiter).toBe('_');
    expect(config.exposeResources).toBe(true);
    expect(config.exposePrompts).toBe(true);
    expect(config.defaultTimeoutMs).toBe(60000);
  });

  it('should parse stdio server config correctly', () => {
    const raw = {
      servers: {
        github: {
          command: 'npx',
          args: ['-y', '@modelcontextprotocol/server-github'],
          env: {
            GITHUB_PERSONAL_ACCESS_TOKEN: 'ghp_secret',
          },
        },
      },
      prefixToolNames: true,
      prefixDelimiter: '__',
    };

    const config = parseConfig(raw);
    expect(config.servers.github).toBeDefined();
    expect(config.servers.github.type).toBe('stdio');
    expect((config.servers.github as any).command).toBe('npx');
    expect(config.prefixDelimiter).toBe('__');
  });

  it('should parse sse server config correctly', () => {
    const raw = {
      servers: {
        remote: {
          type: 'sse',
          url: 'https://mcp.example.com/sse',
          headers: {
            Authorization: 'Bearer token123',
          },
        },
      },
    };

    const config = parseConfig(raw);
    expect(config.servers.remote.type).toBe('sse');
    expect((config.servers.remote as any).url).toBe('https://mcp.example.com/sse');
  });

  it('should throw on invalid SSE url', () => {
    const raw = {
      servers: {
        broken: {
          type: 'sse',
          url: 'not-a-url',
        },
      },
    };

    expect(() => parseConfig(raw)).toThrow();
  });
});
