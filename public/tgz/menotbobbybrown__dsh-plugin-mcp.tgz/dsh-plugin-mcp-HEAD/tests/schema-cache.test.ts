import { describe, it, expect } from 'vitest';
import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs';
import { SchemaCache } from '../src/schema-cache.js';

describe('SchemaCache (L1/L2)', () => {
  it('should cache and retrieve server metadata from memory and disk', () => {
    const testPath = path.join(os.tmpdir(), `test-schemas-${Date.now()}.json`);
    const cache = new SchemaCache({ cachePath: testPath, maxMemoryEntries: 10 });

    cache.set('github', {
      serverName: 'github',
      tools: [
        {
          name: 'github_create_issue',
          originalName: 'create_issue',
          description: 'Create a GitHub issue',
          parameters: { type: 'object' },
        },
      ],
      resources: [],
      hash: 'hash_123',
    });

    expect(cache.has('github')).toBe(true);
    const cached = cache.get('github');
    expect(cached).toBeDefined();
    expect(cached?.tools[0].name).toBe('github_create_issue');

    // Verify L2 file exists on disk
    expect(fs.existsSync(testPath)).toBe(true);

    // Test LRU eviction
    for (let i = 0; i < 15; i++) {
      cache.set(`server_${i}`, {
        serverName: `server_${i}`,
        tools: [],
        resources: [],
        hash: `hash_${i}`,
      });
    }

    expect(cache.size()).toBeLessThanOrEqual(10);

    try {
      fs.unlinkSync(testPath);
    } catch {}
  });
});
