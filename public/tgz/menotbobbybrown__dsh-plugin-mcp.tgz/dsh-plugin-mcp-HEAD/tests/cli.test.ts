import { describe, it, expect, vi } from 'vitest';
import { runCli } from '../src/cli.js';

describe('dsh-mcp CLI', () => {
  it('should print help text when help argument or no arguments provided', async () => {
    const logSpy = vi.spyOn(console, 'log').mockImplementation(() => {});

    await runCli(['node', 'dsh-mcp', 'help']);

    expect(logSpy).toHaveBeenCalled();
    const output = logSpy.mock.calls.flat().join('\n');
    expect(output).toContain('DeepSeek Harness MCP CLI (dsh-mcp)');
    expect(output).toContain('dsh-mcp ui');
    expect(output).toContain('dsh-mcp add');
    expect(output).toContain('dsh-mcp list');

    logSpy.mockRestore();
  });

  it('should list configured servers in json mode', async () => {
    const logSpy = vi.spyOn(console, 'log').mockImplementation(() => {});

    await runCli(['node', 'dsh-mcp', 'list', '--json']);

    expect(logSpy).toHaveBeenCalled();
    const output = logSpy.mock.calls[0][0];
    const parsed = JSON.parse(output);
    expect(Array.isArray(parsed)).toBe(true);

    logSpy.mockRestore();
  });
});
