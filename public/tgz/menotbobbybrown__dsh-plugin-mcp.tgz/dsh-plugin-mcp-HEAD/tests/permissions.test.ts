import { describe, it, expect } from 'vitest';
import { PermissionManager } from '../src/permissions.js';

describe('PermissionManager', () => {
  it('should allow tools matching allow pattern', () => {
    const manager = new PermissionManager({
      allow: ['github_*', 'filesystem_read_*'],
      ask: ['postgres_*'],
      deny: ['bash_dangerous_*'],
    });

    expect(manager.checkPermission('github_list_issues')).toBe('allow');
    expect(manager.checkPermission('filesystem_read_file')).toBe('allow');
  });

  it('should ask for confirmation on ask pattern', () => {
    const manager = new PermissionManager({
      ask: ['postgres_*', 'filesystem_delete_*'],
    });

    expect(manager.checkPermission('postgres_drop_table')).toBe('ask');
    expect(manager.checkPermission('filesystem_delete_dir')).toBe('ask');
  });

  it('should deny execution on deny pattern', () => {
    const manager = new PermissionManager({
      deny: ['rm_rf_*', 'shutdown'],
    });

    expect(manager.checkPermission('rm_rf_root')).toBe('deny');
    expect(manager.checkPermission('shutdown')).toBe('deny');
  });

  it('should return default verdict for non-matching tools', () => {
    const manager = new PermissionManager({
      allow: ['safe_*'],
      defaultVerdict: 'ask',
    });

    expect(manager.checkPermission('unknown_tool')).toBe('ask');
  });
});
