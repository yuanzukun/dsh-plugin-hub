import { describe, it, expect } from 'vitest';
import path from 'node:path';
import { WorkspaceRootsManager } from '../src/roots.js';

describe('WorkspaceRootsManager', () => {
  it('should register and list workspace roots with URI format', () => {
    const manager = new WorkspaceRootsManager();
    const testDir = path.resolve('./workspace');

    manager.addRoot(testDir, 'Main Workspace');

    const roots = manager.listRoots();
    expect(roots.length).toBe(1);
    expect(roots[0].name).toBe('Main Workspace');
    expect(roots[0].uri.startsWith('file://')).toBe(true);
  });

  it('should validate whether paths are within registered roots', () => {
    const manager = new WorkspaceRootsManager();
    const testDir = path.resolve('./workspace');

    manager.addRoot(testDir);

    const insidePath = path.join(testDir, 'src', 'index.ts');
    const outsidePath = path.resolve('../secret/passwords.txt');

    expect(manager.isPathWithinRoots(insidePath)).toBe(true);
    expect(manager.isPathWithinRoots(outsidePath)).toBe(false);
  });
});
