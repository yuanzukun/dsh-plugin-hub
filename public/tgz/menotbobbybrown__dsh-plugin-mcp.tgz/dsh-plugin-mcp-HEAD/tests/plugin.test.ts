import { describe, it, expect } from 'vitest';
import { Context } from 'cordis';
import * as McpPlugin from '../src/index.js';

describe('dsh-plugin-mcp cordis integration', () => {
  it('should load plugin into Cordis context', async () => {
    const ctx = new Context();

    ctx.plugin(McpPlugin, {
      servers: {
        disabledServer: {
          command: 'node',
          args: ['fake.js'],
          disabled: true,
        },
      },
    });

    expect(ctx.mcp).toBeDefined();
    expect(typeof ctx.mcp?.getAllTools).toBe('function');
    expect(typeof ctx.mcp?.getAllResources).toBe('function');
    expect(typeof ctx.mcp?.getAllPrompts).toBe('function');

    const statuses = ctx.mcp?.getStatuses();
    expect(Array.isArray(statuses)).toBe(true);
  });
});
