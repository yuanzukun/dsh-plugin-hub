import { describe, it, expect } from 'vitest';
import { TokenBudgetManager } from '../src/token-budget.js';

describe('TokenBudgetManager', () => {
  it('should enforce token budget and truncate excess tools', () => {
    const budgetManager = new TokenBudgetManager({ maxToolTokens: 100 });

    const mockTools = Array.from({ length: 10 }, (_, i) => ({
      name: `tool_action_${i}`,
      description: `This is a moderately long description of tool action number ${i} which takes parameters and executes actions`,
      serverName: 'test',
      parameters: {
        type: 'object',
        properties: {
          param1: { type: 'string' },
          param2: { type: 'number' },
        },
        required: ['param1'],
      },
      execute: async () => ({}),
      originalName: `action_${i}`,
    }));

    const result = budgetManager.allocateBudget(mockTools);
    expect(result.estimatedTokens).toBeLessThanOrEqual(100);
    expect(result.injectedTools.length).toBeLessThan(10);
    expect(result.truncatedCount).toBeGreaterThan(0);
    expect(result.compactSignatures.length).toBe(result.injectedTools.length);
    expect(result.compactSignatures[0]).toContain('tool_action_0(param1*, param2?):');
  });
});
