import { describe, it, expect } from 'vitest';
import { AgentReachAdapter } from '../src/agent-reach.js';
import { ServerRegistry } from '../src/registry.js';

describe('AgentReachAdapter & Catalog Integration', () => {
  it('should provide valid tool definitions for social search and youtube transcripts', async () => {
    const tools = AgentReachAdapter.getToolDefinitions();
    expect(tools.length).toBe(2);

    const socialTool = tools.find((t) => t.name === 'reach_search_social');
    expect(socialTool).toBeDefined();
    expect(socialTool?.serverName).toBe('agent_reach');

    const result = await (socialTool?.execute as any)({
      platform: 'twitter',
      query: 'deepseek-v3',
    });
    expect(result.status).toBe('success');
    expect(result.platform).toBe('twitter');

    const youtubeTool = tools.find((t) => t.name === 'reach_youtube_transcript');
    expect(youtubeTool).toBeDefined();

    const ytResult = await (youtubeTool?.execute as any)({
      url: 'https://youtube.com/watch?v=123',
    });
    expect(ytResult.status).toBe('success');
    expect(ytResult.transcriptSummary).toContain('https://youtube.com/watch?v=123');
  });

  it('should be registered in the built-in MCP server catalog', () => {
    const srv = ServerRegistry.findServer('agent_reach');
    expect(srv).toBeDefined();
    expect(srv?.name).toBe('Agent Reach');
    expect(srv?.category).toBe('search');
  });
});
