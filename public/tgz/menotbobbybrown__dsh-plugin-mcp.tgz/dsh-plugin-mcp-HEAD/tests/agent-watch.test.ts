import { describe, it, expect } from 'vitest';
import { AgentWatch } from '../src/agent-watch.js';

describe('AgentWatch (Watchdog & Deadlock Loop Interceptor)', () => {
  it('should allow normal non-looping tool invocations', () => {
    const watch = new AgentWatch();
    watch.startNewTurn();

    const v1 = watch.evaluateCall('postgres_query', { sql: 'SELECT 1;' });
    expect(v1.allowed).toBe(true);
    expect(v1.depth).toBe(1);

    const v2 = watch.evaluateCall('github_create_issue', { title: 'Bug report' });
    expect(v2.allowed).toBe(true);
    expect(v2.depth).toBe(2);
  });

  it('should detect and block repetitive tool loops with identical arguments', () => {
    const watch = new AgentWatch({ maxConsecutiveIdenticalCalls: 2 });
    watch.startNewTurn();

    expect(watch.evaluateCall('search_docs', { q: 'auth' }).allowed).toBe(true);
    expect(watch.evaluateCall('search_docs', { q: 'auth' }).allowed).toBe(true);

    const blocked = watch.evaluateCall('search_docs', { q: 'auth' });
    expect(blocked.allowed).toBe(false);
    expect(blocked.isLoopDetected).toBe(true);
    expect(blocked.reason).toContain('Repetitive loop detected');
  });

  it('should enforce recursion depth limits', () => {
    const watch = new AgentWatch({ maxRecursionDepth: 5 });
    watch.startNewTurn();

    for (let i = 1; i <= 5; i++) {
      expect(watch.evaluateCall(`step_${i}`).allowed).toBe(true);
    }

    const blocked = watch.evaluateCall('step_6');
    expect(blocked.allowed).toBe(false);
    expect(blocked.reason).toContain('Maximum agent tool depth (5) exceeded');
  });
});
