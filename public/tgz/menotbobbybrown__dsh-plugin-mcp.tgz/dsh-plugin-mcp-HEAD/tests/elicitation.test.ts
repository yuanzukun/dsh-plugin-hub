import { describe, it, expect } from 'vitest';
import { ElicitationManager } from '../src/elicitation.js';

describe('ElicitationManager', () => {
  it('should dispatch elicitation prompts to registered UI handler', async () => {
    const manager = new ElicitationManager();

    manager.setHandler(async (req) => {
      expect(req.title).toBe('Database Confirmation');
      return { confirmed: true, targetEnv: 'staging' };
    });

    const result = await manager.promptUser({
      id: 'req_1',
      serverName: 'postgres',
      title: 'Database Confirmation',
      fields: [
        { name: 'confirmed', label: 'Proceed with migration?', type: 'boolean' },
        { name: 'targetEnv', label: 'Target Environment', type: 'string' },
      ],
    });

    expect(result.confirmed).toBe(true);
    expect(result.targetEnv).toBe('staging');
  });

  it('should return default values when no handler is registered', async () => {
    const manager = new ElicitationManager();

    const result = await manager.promptUser({
      id: 'req_2',
      serverName: 'filesystem',
      title: 'Directory Select',
      fields: [
        { name: 'path', label: 'Path', type: 'string', defaultValue: './dist' },
      ],
    });

    expect(result.path).toBe('./dist');
  });
});
