import { describe, it, expect } from 'vitest';
import { McpSamplingManager } from '../src/sampling.js';

describe('McpSamplingManager', () => {
  it('should delegate createMessage requests to configured completion handler', async () => {
    const samplingManager = new McpSamplingManager();

    samplingManager.setCompletionHandler(async (params) => {
      return {
        role: 'assistant',
        content: {
          type: 'text',
          text: `DeepSeek response to: ${params.messages[0].content.text}`,
        },
        model: 'deepseek-chat',
        stopReason: 'endTurn',
      };
    });

    const response = await samplingManager.handleCreateMessage({
      messages: [
        {
          role: 'user',
          content: { type: 'text', text: 'Analyze this SQL query' },
        },
      ],
      maxTokens: 500,
    });

    expect(response.role).toBe('assistant');
    expect(response.content.text).toBe('DeepSeek response to: Analyze this SQL query');
    expect(response.model).toBe('deepseek-chat');
  });

  it('should throw error if completion handler is not set', async () => {
    const samplingManager = new McpSamplingManager();

    await expect(
      samplingManager.handleCreateMessage({
        messages: [{ role: 'user', content: { type: 'text', text: 'Hello' } }],
        maxTokens: 100,
      })
    ).rejects.toThrow('Sampling handler not configured');
  });
});
