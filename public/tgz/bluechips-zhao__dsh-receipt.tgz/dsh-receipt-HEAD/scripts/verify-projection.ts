/**
 * 小票投影折叠逻辑的独立验证脚本（node:assert，经 tsx 运行）。
 * 覆盖：按模型聚合、同一 step 重复样本整步替换不重复计数、未报告 usage、
 * 缓存/推理分桶计价、未计价模型、llmMs/spanMs、定价覆盖与复合键。
 *
 * 运行：pnpm exec tsx scripts/verify-projection.ts
 * （或在 checkout 目录：node --import tsx/esm scripts/verify-projection.ts）
 */
import assert from 'node:assert/strict'
import type { SessionEvent, Session } from '@deepseek-ai/dsh-session'
import type { TokenUsage } from '@deepseek-ai/dsh-llm'
import { applyReceipt, receiptProjectionDefinition, receiptView, type ReceiptState } from '../src/projection.ts'
import { DEFAULT_PRICING, type PricingTable } from '../src/pricing.ts'
import { receiptTree, visibleReceiptRows } from '../src/client/receipt-tree.ts'
import type { SessionListState } from '@deepseek-ai/dsh-api-session-controller/client'

/** 构造会话事件（只含折叠所需字段）。 */
function ev(type: string, data: Record<string, unknown>, time: number, seq: number): SessionEvent {
  return { type, data, time, seq } as unknown as SessionEvent
}

function stepStart(turn: number, step: number, time: number, seq: number): SessionEvent {
  return ev('step/start', { turn, step }, time, seq)
}

function message(
  turn: number,
  step: number,
  model: string,
  usage: TokenUsage | undefined,
  time: number,
  seq: number,
): SessionEvent {
  return ev('assistant/message', {
    turn,
    step,
    message: {
      role: 'assistant',
      content: [{ type: 'text', text: 'ok' }],
      source: { kind: 'model', provider: 'deepseek-official', model },
    },
    ...(usage === undefined ? {} : { usage }),
  }, time, seq)
}

function stepEnd(turn: number, step: number, time: number, seq: number): SessionEvent {
  return ev('step/end', { turn, step }, time, seq)
}

/** 跑一遍事件序列。 */
function fold(events: SessionEvent[], inheritedEventCount = 0): ReceiptState {
  const definition = receiptProjectionDefinition({}, '¥')
  return events.reduce(applyReceipt, definition.init({} as Parameters<typeof definition.init>[0], inheritedEventCount as Parameters<typeof definition.init>[1]))
}

const seq = (() => { let n = 0; return () => n++ })()

// 历史型号仅供折叠回归验证；官方当前定价页不再列出，运行时默认不计价。
const TEST_LEGACY_PRICING: PricingTable = {
  ...DEFAULT_PRICING,
  'deepseek-chat': { input: 2, cacheRead: 0.5, output: 8 },
  'deepseek-reasoner': { input: 4, cacheRead: 1, output: 16 },
}

// ---- 1. 基础聚合与计价 ----
{
  const state = fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'deepseek-chat', { inputTokens: 100, outputTokens: 50 }, 1_000, seq()),
  ])
  const view = receiptView(state, TEST_LEGACY_PRICING, '¥')
  assert.equal(view.models.length, 1)
  const row = view.models[0]!
  assert.equal(row.model, 'deepseek-chat')
  assert.equal(row.calls, 1)
  assert.equal(row.inputTokens, 100)
  assert.equal(row.outputTokens, 50)
  assert.equal(row.priced, true)
  // 100/1e6*2 + 50/1e6*8 = 0.0002 + 0.0004
  assert.ok(Math.abs(row.cost - 0.0006) < 1e-12)
  assert.equal(view.totals.cost, row.cost)
  assert.equal(view.totals.calls, 1)
  assert.equal(view.priced, true)
  assert.equal(view.llmMs, 1_000)
  assert.equal(view.spanMs, 1_000)
  assert.equal(view.updatedAt, 1_000)
  assert.equal(view.currency, '¥')
}

// ---- 2. 同一 step 的重复样本整步替换：不重复计数 ----
{
  const state = fold([
    stepStart(1, 1, 0, seq()),
    // 中断的 step 先落一条未报告 usage 的消息，随后被该 step 的终值替换
    message(1, 1, 'deepseek-chat', undefined, 500, seq()),
    message(1, 1, 'deepseek-chat', { inputTokens: 120, outputTokens: 60 }, 1_000, seq()),
  ])
  const view = receiptView(state, TEST_LEGACY_PRICING, '¥')
  assert.equal(view.models.length, 1)
  assert.equal(view.models[0]!.calls, 1)
  assert.equal(view.models[0]!.inputTokens, 120)
  assert.equal(view.models[0]!.outputTokens, 60)
  assert.equal(view.totals.inputTokens, 120)
  assert.equal(view.totals.outputTokens, 60)
}

// ---- 3. 适配器未报告 usage：零 token，但仍计一次调用 ----
{
  const state = fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'deepseek-chat', undefined, 400, seq()),
    stepEnd(1, 1, 500, seq()),
  ])
  const view = receiptView(state, TEST_LEGACY_PRICING, '¥')
  assert.equal(view.models.length, 1)
  const row = view.models[0]!
  assert.equal(row.model, 'deepseek-chat')
  assert.equal(row.calls, 1)
  assert.equal(row.inputTokens, 0)
  assert.equal(row.outputTokens, 0)
  assert.equal(view.totals.inputTokens, 0)
  assert.equal(view.llmMs, 400) // 消息落地：模型耗时照计
}

// ---- 4. 缓存/推理分桶计价 ----
{
  const state = fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'deepseek-chat', {
      inputTokens: 100,
      outputTokens: 50,
      cacheReadTokens: 200,
      cacheWriteTokens: 10,
      reasoningTokens: 5,
    }, 1_000, seq()),
  ])
  const view = receiptView(state, TEST_LEGACY_PRICING, '¥')
  const row = view.models[0]!
  assert.equal(row.cacheReadTokens, 200)
  assert.equal(row.cacheWriteTokens, 10)
  assert.equal(row.reasoningTokens, 5)
  // 100/1e6*2 + 200/1e6*0.5 + 10/1e6*0 + 50/1e6*8 + 5/1e6*0
  assert.ok(Math.abs(row.cost - (0.0002 + 0.0001 + 0.0004)) < 1e-12)
  assert.equal(row.priced, false, '缓存写入有用量但未配置价格时不得标成完整计价')
}

// ---- 5. 未配置价格的模型：未计价 ----
{
  const state = fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'vendor-unknown-model', { inputTokens: 100, outputTokens: 50 }, 1_000, seq()),
  ])
  const view = receiptView(state, TEST_LEGACY_PRICING, '¥')
  const row = view.models[0]!
  assert.equal(row.priced, false)
  assert.equal(row.cost, 0)
  assert.equal(view.priced, false)
}

// ---- 6. 定价覆盖（用户配置覆盖内置默认）与 provider/model 复合键 ----
{
  const custom: PricingTable = {
    'deepseek-chat': { input: 3, output: 9 },
    'deepseek-official/deepseek-v4-flash': { input: 1, output: 2 },
  }
  const state = fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'deepseek-chat', { inputTokens: 1_000_000, outputTokens: 0 }, 1_000, seq()),
    stepStart(2, 1, 2_000, seq()),
    message(2, 1, 'deepseek-v4-flash', { inputTokens: 1_000_000, outputTokens: 0 }, 3_000, seq()),
  ])
  const view = receiptView(state, custom, '$')
  const chat = view.models.find(r => r.model === 'deepseek-chat')!
  const flash = view.models.find(r => r.model === 'deepseek-v4-flash')!
  assert.equal(chat.cost, 3) // 覆盖了默认 2
  assert.equal(flash.cost, 1) // 复合键命中
  assert.equal(view.currency, '$')
}

// ---- 7. 定义工厂：schema 能解析 view 输出（wire 契约） ----
{
  const def = receiptProjectionDefinition(TEST_LEGACY_PRICING, '¥')
  const state = fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'deepseek-chat', { inputTokens: 10, outputTokens: 5 }, 500, seq()),
  ])
  const parsed = def.wire.viewSchema.parse(def.wire.view(state))
  assert.equal(parsed.models.length, 1)
  assert.equal(parsed.totals.calls, 1)
  // 空日志 init 也必须是纯 JSON（持久化缓存前置条件）
  const empty = def.wire.view(def.init())
  assert.deepEqual(empty.models, [])
  assert.equal(empty.totals.calls, 0)
  assert.equal(empty.priced, false)
}

// ---- 8. 多模型多 step 合计 ----
{
  const state = fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'deepseek-chat', { inputTokens: 100, outputTokens: 50 }, 1_000, seq()),
    stepStart(1, 2, 1_100, seq()),
    message(1, 2, 'deepseek-reasoner', { inputTokens: 200, outputTokens: 100 }, 2_000, seq()),
  ])
  const view = receiptView(state, TEST_LEGACY_PRICING, '¥')
  assert.equal(view.models.length, 2)
  assert.equal(view.totals.calls, 2)
  assert.equal(view.totals.inputTokens, 300)
  assert.equal(view.totals.outputTokens, 150)
  assert.equal(view.priced, true)
  // reasoner 单价更高 → 费用更高，排序在前
  assert.equal(view.models[0]!.model, 'deepseek-reasoner')
}

// ---- 9. 峰谷计价：默认高峰窗口（北京时间 9-12、14-18）----
{
  // ts = 9h（1970-01-01 09:00 UTC = 北京时间 17:00）→ 高峰 ×2
  const PEAK_TS = 9 * 3_600 * 1_000
  // ts = 5h（北京时间 13:00）→ 空闲
  const OFF_TS = 5 * 3_600 * 1_000
  const state = fold([
    stepStart(1, 1, OFF_TS, seq()),
    message(1, 1, 'deepseek-chat', { inputTokens: 100, outputTokens: 50 }, OFF_TS + 100, seq()),
    stepStart(2, 1, PEAK_TS, seq()),
    message(2, 1, 'deepseek-chat', { inputTokens: 100, outputTokens: 50 }, PEAK_TS + 100, seq()),
  ])
  const view = receiptView(state, TEST_LEGACY_PRICING, '¥')
  const row = view.models[0]!
  // 空闲 0.0006 + 高峰 0.0012；peakCost = 高峰多出的 0.0006
  assert.ok(Math.abs(row.cost - 0.0018) < 1e-12)
  assert.ok(Math.abs(row.peakCost - 0.0006) < 1e-12)
  assert.ok(Math.abs(view.totals.cost - 0.0018) < 1e-12)
  assert.ok(Math.abs(view.totals.peakCost - 0.0006) < 1e-12)
  // wire 上的默认窗口与倍率
  assert.deepEqual(view.peakHours, [{ start: 9, end: 12 }, { start: 14, end: 18 }])
  assert.equal(view.peakMultiplier, 2)
  // 全部空闲：peakCost 为 0
  const allOff = receiptView(fold([
    stepStart(1, 1, OFF_TS, seq()),
    message(1, 1, 'deepseek-chat', { inputTokens: 100, outputTokens: 50 }, OFF_TS + 100, seq()),
  ]), TEST_LEGACY_PRICING, '¥')
  assert.equal(allOff.totals.peakCost, 0)
}

// ---- 10. 自定义高峰窗口与倍率 ----
{
  // 窗口 [14,18)：ts=6h（北京时间 14:00）→ 高峰
  const PEAK_TS = 6 * 3_600 * 1_000
  const state = fold([
    stepStart(1, 1, PEAK_TS, seq()),
    message(1, 1, 'deepseek-chat', { inputTokens: 100, outputTokens: 50 }, PEAK_TS + 100, seq()),
  ])
  const view = receiptView(state, TEST_LEGACY_PRICING, '¥', { peakHours: [{ start: 14, end: 18 }], peakMultiplier: 3 })
  assert.ok(Math.abs(view.totals.cost - 0.0006 * 3) < 1e-12)
  assert.ok(Math.abs(view.totals.peakCost - 0.0006 * 2) < 1e-12)
  assert.equal(view.peakMultiplier, 3)
  // 同一时刻不在自定义窗口（窗口 [0,1)）：空闲
  const off = receiptView(state, TEST_LEGACY_PRICING, '¥', { peakHours: [{ start: 0, end: 1 }] })
  assert.ok(Math.abs(off.totals.cost - 0.0006) < 1e-12)
  assert.equal(off.totals.peakCost, 0)
}

// ---- 11. 定义工厂：schema 能解析带峰谷字段的 view 输出 ----
{
  const def = receiptProjectionDefinition(TEST_LEGACY_PRICING, '¥')
  const state = fold([
    stepStart(1, 1, 9 * 3_600 * 1_000, seq()),
    message(1, 1, 'deepseek-chat', { inputTokens: 10, outputTokens: 5 }, 9 * 3_600 * 1_000 + 100, seq()),
  ])
  const parsed = def.wire.viewSchema.parse(def.wire.view(state))
  assert.equal(parsed.models[0]!.peakCost > 0, true)
  assert.equal(parsed.totals.peakCost > 0, true)
  assert.equal(parsed.peakMultiplier, 2)
}

// ---- 12. 别名计价：已下线旧名（deepseek-v4-flash / -vision-exp）沿用 deepseek-flash 定价 ----
{
  const custom: PricingTable = {
    'deepseek-flash': { input: 1.5, cacheRead: 0.05, output: 4.5 },
  }
  const state = fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'deepseek-v4-flash-vision-exp', { inputTokens: 1_000_000, outputTokens: 0 }, 1_000, seq()),
    message(1, 2, 'deepseek-v4-flash', { inputTokens: 1_000_000, outputTokens: 0 }, 2_000, seq()),
  ])
  const view = receiptView(state, custom, '¥')
  const vision = view.models.find(r => r.model === 'deepseek-v4-flash-vision-exp')!
  const legacy = view.models.find(r => r.model === 'deepseek-v4-flash')!
  assert.equal(vision.priced, true)
  assert.equal(vision.cost, 1.5) // 沿用 deepseek-flash 的 input 单价 1.5
  assert.equal(legacy.priced, true)
  assert.equal(legacy.cost, 1.5)
  assert.equal(view.priced, true)
  assert.equal(view.totals.cost, 3) // 两个 step 各 1M 输入

  // 直接配置旧名时优先于别名（不被别名覆盖）。
  const direct: PricingTable = {
    'deepseek-flash': { input: 1.5, output: 4.5 },
    'deepseek-v4-flash-vision-exp': { input: 3, output: 9 },
  }
  const view2 = receiptView(fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'deepseek-v4-flash-vision-exp', { inputTokens: 1_000_000, outputTokens: 0 }, 1_000, seq()),
  ]), direct, '¥')
  assert.equal(view2.models[0]!.cost, 3)
}

// ---- 13. 周末全天谷底：包含调休上班的周六/周日 ----
{
  // 1970-01-03 是周六。UTC 02:00 = 北京时间 10:00（默认高峰窗口内），但周末仍应按谷底计。
  const SATURDAY_BEIJING_PEAK_TS = 2 * 86_400_000 + 2 * 3_600_000 + 0
  // 1970-01-04 是周日。UTC 08:00 = 北京时间 16:00（默认高峰窗口内）。
  const SUNDAY_BEIJING_PEAK_TS = 3 * 86_400_000 + 8 * 3_600_000
  // 2026 年国务院安排：9 月 20 日（周日）、10 月 10 日（周六）调休上班。
  // API 定价仍按自然周末全天空闲，不因调休上班转为高峰。
  const MAKEUP_SUNDAY_TS = Date.UTC(2026, 8, 20, 2) // 北京时间 10:00
  const MAKEUP_SATURDAY_TS = Date.UTC(2026, 9, 10, 2)
  for (const ts of [SATURDAY_BEIJING_PEAK_TS, SUNDAY_BEIJING_PEAK_TS, MAKEUP_SUNDAY_TS, MAKEUP_SATURDAY_TS]) {
    const state = fold([
      stepStart(1, 1, ts, seq()),
      message(1, 1, 'deepseek-chat', { inputTokens: 100, outputTokens: 50 }, ts + 100, seq()),
    ])
    const view = receiptView(state, TEST_LEGACY_PRICING, '¥')
    const row = view.models[0]!
    assert.equal(row.peakCost, 0, '周末高峰窗口时段不应计高峰费用')
    assert.ok(Math.abs(row.cost - 0.0006) < 1e-12, '周末按谷底单价计费')
    assert.equal(view.totals.peakCost, 0)
  }
}

// ---- 14. 内置默认价：当前在售型号可计价，已下线旧名经别名沿用 ----
{
  const state = fold([
    stepStart(1, 1, 0, seq()),
    // 1970-01-01 08:00 北京时间：工作日但不在高峰窗口内 → 按谷底单价。
    message(1, 1, 'deepseek-flash', { inputTokens: 1_000_000, outputTokens: 500_000 }, 1_000, seq()),
    message(1, 2, 'deepseek-v4-flash', { inputTokens: 1_000_000, outputTokens: 0 }, 2_000, seq()),
    message(1, 3, 'deepseek-v4-pro', { inputTokens: 1_000_000, outputTokens: 0 }, 3_000, seq()),
  ])
  const view = receiptView(state, DEFAULT_PRICING, '¥')
  const flash = view.models.find(r => r.model === 'deepseek-flash')!
  const legacyFlash = view.models.find(r => r.model === 'deepseek-v4-flash')!
  const pro = view.models.find(r => r.model === 'deepseek-v4-pro')!
  assert.equal(flash.priced, true)
  assert.equal(flash.cost, 3) // 1M 输入 ×1 + 0.5M 输出 ×4
  assert.equal(legacyFlash.priced, true)
  assert.equal(legacyFlash.cost, 1) // 旧名经 PRICING_ALIASES 沿用 deepseek-flash 单价
  assert.equal(pro.priced, true)
  assert.equal(pro.cost, 4.5)
  assert.equal(view.totals.peakCost, 0)
}

// ---- 15. 官网未列出的旧模型默认不估价；推理 token 已包含在输出 token 中 ----
{
  const state = fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'deepseek-chat', { inputTokens: 1_000_000, outputTokens: 0 }, 1_000, seq()),
    message(1, 2, 'deepseek-flash', {
      inputTokens: 0, cacheReadTokens: 1_000_000, outputTokens: 1_000_000, reasoningTokens: 250_000,
    }, 2_000, seq()),
  ])
  const view = receiptView(state, DEFAULT_PRICING, '¥')
  assert.equal(view.models.find(row => row.model === 'deepseek-chat')?.priced, false)
  assert.equal(view.models.find(row => row.model === 'deepseek-flash')?.cost, 4.02)
  assert.equal(view.totals.outputTokens, 1_000_000)
  assert.equal(view.totals.reasoningTokens, 250_000)
}

// ---- 16. provider 专属价格优先；自定义推理价替换对应输出部分，不重复收费 ----
{
  const state = fold([
    stepStart(1, 1, 0, seq()),
    message(1, 1, 'deepseek-flash', {
      inputTokens: 1_000_000, outputTokens: 1_000_000, reasoningTokens: 250_000,
    }, 1_000, seq()),
  ])
  const pricing: PricingTable = {
    'deepseek-flash': { input: 1, output: 4 },
    'deepseek-official/deepseek-flash': { input: 2, output: 4, reasoning: 8 },
  }
  const view = receiptView(state, pricing, '¥')
  assert.equal(view.totals.cost, 7) // 输入 2 + 普通输出 0.75×4 + 推理 0.25×8
}

// ---- 17. 已公布的 2026 年假期默认按空闲价；其他日期可由配置补充 ----
{
  const time = Date.UTC(2026, 9, 1, 2) // 北京时间 2026-10-01 10:00，周四
  const state = fold([
    stepStart(1, 1, time, seq()),
    message(1, 1, 'deepseek-flash', { inputTokens: 1_000_000, outputTokens: 0 }, time + 100, seq()),
  ])
  const holiday = receiptView(state, DEFAULT_PRICING, '¥')
  assert.equal(holiday.totals.cost, 1)
  assert.equal(holiday.totals.peakCost, 0)

  const futureTime = Date.UTC(2027, 9, 1, 2) // 未内置未来年度安排
  const future = fold([
    stepStart(1, 1, futureTime, seq()),
    message(1, 1, 'deepseek-flash', { inputTokens: 1_000_000, outputTokens: 0 }, futureTime + 100, seq()),
  ])
  assert.equal(receiptView(future, DEFAULT_PRICING, '¥').totals.cost, 2)
  assert.equal(receiptView(future, DEFAULT_PRICING, '¥', { offPeakDates: ['2027-10-01'] }).totals.cost, 1)
}

// ---- 18. Forked child does not charge its parent's inherited log again. ----
{
  const history = [
    stepStart(1, 1, 0, 0),
    message(1, 1, 'deepseek-flash', { inputTokens: 1_000_000, outputTokens: 0 }, 100, 1),
    stepStart(2, 1, 200, 2),
    message(2, 1, 'deepseek-flash', { inputTokens: 2_000_000, outputTokens: 0 }, 300, 3),
  ]
  const child = receiptView(fold(history, 2), DEFAULT_PRICING, '¥')
  assert.equal(child.totals.inputTokens, 2_000_000)
  assert.equal(child.totals.calls, 1)
  assert.equal(child.totals.cost, 2)
}

// ---- 19. Parent + nested subagents are included once; unavailable and unrelated sessions are excluded. ----
{
  const make = (cost: number) => {
    const state = fold([
      stepStart(1, 1, 0, 0),
      message(1, 1, 'deepseek-flash', { inputTokens: cost * 1_000_000, outputTokens: 0 }, 100, 1),
    ])
    return receiptView(state, DEFAULT_PRICING, '¥')
  }
  const state = { byId: {
    root: { id: 'root', displayTitle: 'Root', projectionValues: { receipt: make(1) } },
    child: { id: 'child', displayTitle: 'Child', origin: 'subagent', parentId: 'root', projectionValues: { receipt: make(2) } },
    nested: { id: 'nested', displayTitle: 'Nested', origin: 'subagent', parentId: 'child', projectionValues: { receipt: make(3) } },
    waiting: { id: 'waiting', displayTitle: 'Waiting', origin: 'subagent', parentId: 'root' },
    fork: { id: 'fork', displayTitle: 'Fork', parentId: 'root', projectionValues: { receipt: make(100) } },
    other: { id: 'other', displayTitle: 'Other', origin: 'subagent', parentId: 'elsewhere', projectionValues: { receipt: make(100) } },
  } } as unknown as SessionListState
  const tree = receiptTree(state, 'root')
  assert.equal(tree.children.length, 3)
  assert.equal(tree.childCost, 5)
  assert.equal(tree.combined?.totals.cost, 6)
  assert.equal(tree.missing, 1)
  assert.equal(tree.combined?.priced, false)
  assert.equal(tree.combined?.totals.calls, 3)
  assert.equal(tree.combined?.models.length, 1)
  assert.equal(tree.combined?.models[0]?.cost, 6)
  assert.deepEqual(tree.children.map(child => child.id), ['child', 'nested', 'waiting'])
  assert.equal(tree.children[0]?.descendants, 1)
  assert.equal(tree.children[0]?.branchCost, 5)
  assert.equal(tree.children[0]?.branchPriced, true)
  assert.deepEqual(visibleReceiptRows(tree, new Set(), {}, '').filter(row => row.kind === 'child').map(row => row.child.id), ['child', 'waiting'])
  assert.deepEqual(visibleReceiptRows(tree, new Set(['child']), {}, '').filter(row => row.kind === 'child').map(row => row.child.id), ['child', 'nested', 'waiting'])
  assert.deepEqual(visibleReceiptRows(tree, new Set(), {}, 'Nested').filter(row => row.kind === 'child').map(row => row.child.id), ['child', 'nested'])
  assert.deepEqual(visibleReceiptRows(tree, new Set(), {}, 'nested').filter(row => row.kind === 'child').map(row => row.child.id), ['child', 'nested'])

  const loading = receiptTree({ byId: {
    root: { id: 'root', displayTitle: 'Root' },
    child: { id: 'child', displayTitle: 'Child', origin: 'subagent', parentId: 'root' },
    nested: { id: 'nested', displayTitle: 'Nested', origin: 'subagent', parentId: 'child' },
  } } as unknown as SessionListState, 'root')
  assert.equal(loading.combined, undefined)
  assert.equal(loading.children[0]?.directChildren, 1)
  assert.equal(loading.children[0]?.descendants, 1)

  const differentCurrency = { ...make(4), currency: '$' }
  const mismatched = receiptTree({ byId: {
    root: { id: 'root', displayTitle: 'Root', projectionValues: { receipt: make(1) } },
    child: { id: 'child', displayTitle: 'Child', origin: 'subagent', parentId: 'root', projectionValues: { receipt: differentCurrency } },
  } } as unknown as SessionListState, 'root')
  assert.equal(mismatched.combined?.totals.cost, 1)
  assert.equal(mismatched.currencyMismatch, 1)
  assert.equal(mismatched.combined?.priced, false)
}

// ---- 20. Deep delegation and broad sibling sets stay iterative and paged. ----
{
  const rootReceipt = receiptView(fold([
    stepStart(1, 1, 0, 0),
    message(1, 1, 'deepseek-flash', { inputTokens: 1_000_000, outputTokens: 0 }, 100, 1),
  ]), DEFAULT_PRICING, '¥')
  const byId: Record<string, unknown> = { root: { id: 'root', displayTitle: 'Root', projectionValues: { receipt: rootReceipt } } }
  for (let index = 0; index < 120; index++) byId[`wide-${index}`] = { id: `wide-${index}`, displayTitle: `Wide ${index}`, origin: 'subagent', parentId: 'root' }
  for (let index = 0; index < 1_500; index++) byId[`deep-${index}`] = {
    id: `deep-${index}`, displayTitle: `Deep ${index}`, origin: 'subagent',
    parentId: index === 0 ? 'wide-0' : `deep-${index - 1}`,
  }
  const tree = receiptTree({ byId } as unknown as SessionListState, 'root')
  assert.equal(tree.children.length, 1_620)
  assert.equal(tree.children.find(child => child.id === 'wide-0')?.descendants, 1_500)
  assert.equal(tree.children.find(child => child.id === 'deep-1499')?.depth, 1_501)
  const initial = visibleReceiptRows(tree, new Set(), {}, '')
  assert.equal(initial.filter(row => row.kind === 'child').length, 20)
  assert.equal(initial.at(-1)?.kind, 'more')
  assert.equal(initial.at(-1)?.kind === 'more' ? initial.at(-1)?.remaining : 0, 100)
  const next = visibleReceiptRows(tree, new Set(), { root: 40 }, '')
  assert.equal(next.filter(row => row.kind === 'child').length, 40)
  const found = visibleReceiptRows(tree, new Set(), {}, 'Deep 1499')
  assert.equal(found.filter(row => row.kind === 'child').length, 1_501)
  assert.equal(found.at(-1)?.kind === 'child' ? found.at(-1)?.child.id : '', 'deep-1499')
}

console.log('verify-projection: 全部断言通过 ✓')
