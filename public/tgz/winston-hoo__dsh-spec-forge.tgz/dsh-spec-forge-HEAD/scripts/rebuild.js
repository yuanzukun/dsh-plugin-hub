/**
 * 重建模板指纹（0.7.1）。
 *
 * 为什么需要：0.7.1 改变了指纹的生成方式（同义词归一、领域词提权、分级配额），
 * 但**已落盘的模板指纹不会自动更新** —— 老库里的指纹仍是旧算法写的，
 * 于是「新需求用新指纹、老模板用旧指纹」，两侧口径不一致，召回效果反而可能变差。
 *
 * 用法：
 *   node scripts/rebuild.js --dry-run     # 只看会改什么
 *   node scripts/rebuild.js               # 写回（保留 hitCount / created / lastUsed）
 *   node scripts/rebuild.js --home <dir>  # 指定数据根（默认 $DSH_HOME/spec-forge）
 */
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { basename, join } from 'node:path'

import { fingerprintTemplate } from '../lib/fingerprint.js'
import {
  bulletLines,
  dataRoot,
  parseFrontmatter,
  resolveHome,
  sectionOf,
  writeTemplate,
} from '../lib/store.js'

const args = process.argv.slice(2)
const dryRun = args.includes('--dry-run')
const homeIdx = args.indexOf('--home')
const home = homeIdx >= 0 ? args[homeIdx + 1] : dataRoot(resolveHome())

function listScopeDirs(root) {
  const dirs = []
  if (existsSync(join(root, 'global', 'templates'))) dirs.push({ scope: 'global', dir: join(root, 'global', 'templates') })
  const projects = join(root, 'projects')
  if (existsSync(projects)) {
    for (const hash of readdirSync(projects)) {
      const dir = join(projects, hash, 'templates')
      if (existsSync(dir) && statSync(dir).isDirectory()) dirs.push({ scope: hash, dir })
    }
  }
  return dirs
}

/** 从已渲染的模板正文里还原出生成指纹所需的四段文本 */
function fieldsFromBody(meta, body) {
  const promptRaw = sectionOf(body, '提示词模板')
  return {
    name: meta.name ?? '',
    trigger: sectionOf(body, '触发场景').trim(),
    tags: Array.isArray(meta.tags) ? meta.tags : [],
    approach: bulletLines(sectionOf(body, '标准改法'), { keepNumber: true }),
    prompt: promptRaw.replace(/```[a-z]*\n?/gi, '').trim(),
  }
}

const dirs = listScopeDirs(home)
if (dirs.length === 0) {
  console.error(`数据根下没有找到模板：${home}`)
  process.exit(2)
}

let changed = 0
let scanned = 0

for (const { scope, dir } of dirs) {
  for (const file of readdirSync(dir)) {
    if (!file.endsWith('.md') || file.endsWith('.tmp')) continue
    scanned++
    const path = join(dir, file)
    const id = basename(file, '.md')
    const raw = readFileSync(path, 'utf8')
    const { meta, body } = parseFrontmatter(raw)
    const next = fingerprintTemplate(fieldsFromBody(meta, body))
    const before = Array.isArray(meta.fingerprint) ? meta.fingerprint.length : 0

    const oldTokens = new Set((Array.isArray(meta.fingerprint) ? meta.fingerprint : []).map((t) => String(t).split('|')[0]))
    const newTokens = new Set(next.map((t) => t.token))
    const added = [...newTokens].filter((t) => !oldTokens.has(t)).slice(0, 6)
    const removed = [...oldTokens].filter((t) => !newTokens.has(t)).slice(0, 6)

    console.log(
      `${scope}/${id}  ${before} → ${next.length} 个 token` +
        (added.length ? `　+${added.join(',')}` : '') +
        (removed.length ? `　-${removed.join(',')}` : ''),
    )

    if (dryRun) continue
    writeTemplate(home, scope, id, {
      ...meta,
      name: meta.name ?? id,
      category: meta.category ?? 'uncategorized',
      tags: Array.isArray(meta.tags) ? meta.tags : [],
      fingerprint: next,
      repo: scope === 'global' ? '' : scope,
      hitCount: Number(meta.hitCount ?? 0) || 0,
      created: meta.created,
      lastUsed: meta.lastUsed,
    }, body)
    changed++
  }
}

console.log(`\n扫描 ${scanned} 份，${dryRun ? '将重建' : '已重建'} ${dryRun ? scanned : changed} 份　数据根：${home}`)
if (dryRun) console.log('（dry-run，未写盘；去掉 --dry-run 执行）')
