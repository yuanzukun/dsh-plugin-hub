/**
 * 指纹容量基准（0.7.2）。
 *
 * 用途：模板指纹上限（TEMPLATE_FINGERPRINT_MAX）是一个有反作用的参数 ——
 * 名额越大，索引/正文词进得越多（召回更好），但余弦分母也越大（相似度被稀释）。
 * 改这个数字前必须跑一次，看三组指标是否同向变好：
 *
 *   1. 自我召回：查询 = 该模板触发场景首句         → 检验索引词覆盖
 *   2. 正文词召回：查询 = 该模板标准改法片段       → 检验正文词覆盖
 *   3. 假阳性：与所有模板无关的需求                → 检验噪声是否被放大
 *
 * 0.7.1 实测（7 份真实模板，上限 24 / 32 / 40）：
 *   自我召回 7/7 / 7/7 / 7/7，平均分 0.565 / 0.641 / 0.611
 *   正文词召回 3/7 / 5/7 / **7/7**
 *   无关需求最高分 0.256 / 0.233 / 0.209（假阳性数三档相同）
 *   → 扩到 40 用 0.03 的平均分换回 4 条正文词召回，且假阳性没有上升，因此取 40。
 *
 * 用法：
 *   node scripts/bench-cap.js                # 默认数据根
 *   node scripts/bench-cap.js --home <dir>
 *   node scripts/bench-cap.js --caps 24,32,40,48
 */
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join } from 'node:path'

import { fingerprintTemplate, inferQueryTags, queryFingerprint } from '../lib/fingerprint.js'
import { scoreTemplate } from '../lib/match.js'
import { cleanRequirement } from '../lib/prepare.js'
import { bulletLines, dataRoot, parseFrontmatter, resolveHome, sectionOf } from '../lib/store.js'

const argv = process.argv.slice(2)
const flag = (name) => {
  const i = argv.indexOf(name)
  return i >= 0 ? argv[i + 1] : undefined
}

const HOME = flag('--home') ?? dataRoot(resolveHome())
const CAPS = (flag('--caps') ?? '24,32,40').split(',').map(Number).filter((n) => n > 0)
const THRESHOLD = 0.15

// 与任何模板都无关的需求：只用来看"扩指纹是否放大噪声"
const UNRELATED = [
  '把首页底部导航的图标换成新的',
  '这个页面的字体大小统一调成 28rpx',
  '数据库连接超时改成 10 秒',
  '新增一个导出 Excel 的按钮',
  '列表默认按创建时间倒序',
  '提交，release 的 exe 也提交',
  '部署到测试环境后页面白屏',
  '把注释里的错别字改一下',
  '表单校验提示文案改一下',
  '卡片上显示个图标',
]

function listScopes(root) {
  const out = []
  const globalDir = join(root, 'global', 'templates')
  if (isDir(globalDir)) out.push({ scope: 'global', dir: globalDir })
  const projects = join(root, 'projects')
  if (isDir(projects)) {
    for (const hash of readdirSync(projects)) {
      const dir = join(projects, hash, 'templates')
      if (isDir(dir)) out.push({ scope: hash, dir })
    }
  }
  return out
}

function isDir(p) {
  try { return statSync(p).isDirectory() } catch { return false }
}

function loadTemplates(root) {
  const out = []
  for (const { scope, dir } of listScopes(root)) {
    for (const file of readdirSync(dir)) {
      if (!file.startsWith('tpl-') || !file.endsWith('.md')) continue
      const { meta, body } = parseFrontmatter(readFileSync(join(dir, file), 'utf8'))
      out.push({
        id: file.replace(/\.md$/, ''),
        scope,
        repo: scope,
        name: meta.name ?? '',
        category: meta.category,
        tags: Array.isArray(meta.tags) ? meta.tags : [],
        hitCount: Number(meta.hitCount ?? 0),
        lastUsed: meta.lastUsed,
        trigger: sectionOf(body, '触发场景').trim(),
        approach: bulletLines(sectionOf(body, '标准改法'), { keepNumber: true }),
        prompt: sectionOf(body, '提示词模板').replace(/```[a-z]*\n?/gi, '').trim(),
      })
    }
  }
  return out
}

const templates = loadTemplates(HOME)
if (templates.length === 0) {
  console.error(`数据根下没有模板：${HOME}`)
  process.exit(2)
}
console.log(`数据根：${HOME}　模板 ${templates.length} 份　候选上限 ${CAPS.join('/')}\n`)

const fpOf = (t, cap) =>
  fingerprintTemplate(
    { name: t.name, trigger: t.trigger, tags: t.tags, approach: t.approach, prompt: t.prompt },
    cap,
  )

function buildQuery(text) {
  const cleaned = cleanRequirement(text)
  const fp = queryFingerprint(cleaned)
  fp.tags = inferQueryTags(cleaned)
  return fp
}

function score(t, queryFp, cap) {
  return scoreTemplate({
    queryFp,
    template: { ...t, fingerprint: fpOf(t, cap) },
    repoHash: t.scope,
    threshold: THRESHOLD,
  })
}

// ---------- 1. 自我召回 ----------
const pad = (s, n) => String(s).padEnd(n)
console.log('=== 自我召回（查询 = 触发场景首句）===')
console.log(pad('模板', 18) + CAPS.map((c) => pad(`cap${c}`, 13)).join(''))
const selfHit = Object.fromEntries(CAPS.map((c) => [c, 0]))
const selfSum = Object.fromEntries(CAPS.map((c) => [c, 0]))
for (const t of templates) {
  const q = buildQuery(t.trigger.split(/[；;。]/)[0].slice(0, 120))
  const cells = CAPS.map((cap) => {
    const r = score(t, q, cap)
    if (r.hit) selfHit[cap]++
    selfSum[cap] += r.score
    return pad(`${r.score.toFixed(3)}/${r.hit ? 'Y' : 'n'}`, 13)
  })
  console.log(pad(t.id, 18) + cells.join(''))
}
console.log(
  `命中：${CAPS.map((c) => `${c}=${selfHit[c]}/${templates.length}`).join('　')}` +
    `　平均分：${CAPS.map((c) => `${c}=${(selfSum[c] / templates.length).toFixed(3)}`).join('　')}\n`,
)

// ---------- 2. 正文词召回 ----------
console.log('=== 正文词召回（查询 = 标准改法片段）===')
const bodyHit = Object.fromEntries(CAPS.map((c) => [c, 0]))
for (const t of templates) {
  const q = buildQuery((t.approach ?? []).join(' ').replace(/[，。；：、]/g, ' ').slice(0, 90))
  const cells = CAPS.map((cap) => {
    const r = score(t, q, cap)
    if (r.hit) bodyHit[cap]++
    return pad(`${r.score.toFixed(3)}/${r.hit ? 'Y' : 'n'}`, 13)
  })
  console.log(pad(t.id, 18) + cells.join(''))
}
console.log(`命中：${CAPS.map((c) => `${c}=${bodyHit[c]}/${templates.length}`).join('　')}\n`)

// ---------- 3. 假阳性 ----------
console.log('=== 无关需求（假阳性）===')
const fpCount = Object.fromEntries(CAPS.map((c) => [c, 0]))
for (const text of UNRELATED) {
  const q = buildQuery(text)
  const cells = CAPS.map((cap) => {
    let max = 0
    for (const t of templates) {
      const r = score(t, q, cap)
      if (r.hit) fpCount[cap]++
      if (r.score > max) max = r.score
    }
    return pad(max.toFixed(3), 13)
  })
  console.log(pad(text.slice(0, 20), 22) + cells.join(''))
}
console.log(`误命中（模板级计数）：${CAPS.map((c) => `${c}=${fpCount[c]}`).join('　')}`)
