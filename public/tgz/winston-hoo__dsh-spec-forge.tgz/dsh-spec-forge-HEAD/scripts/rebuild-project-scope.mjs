/**
 * 项目模板卫生清理（0.8.1 起，可重复跑，幂等）
 *
 * 三种模式：
 *   1. 默认：丢掉「本次只动 X / 只改 X 目录 / 不碰 Y」这类一次性任务边界，
 *      并用 topicOnly 重建指纹（只用 name+tags，正文切片不再参与打分）
 *   2. --hoist：把被抄进多份模板的**项目级**禁区收进 profile.md，模板只留主题约束
 *   3. --retire：把无复用价值的一次性任务模板移出检索集（不删除，移入 _retired-<date>/）
 *
 * 用法：
 *   node scripts/rebuild-project-scope.mjs --home <spec-forge 数据根> [--apply]
 *   node scripts/rebuild-project-scope.mjs --home <dir> --hoist [--apply]
 *   node scripts/rebuild-project-scope.mjs --home <dir> --retire tpl-xxx,tpl-yyy [--apply]
 */
import { existsSync, readFileSync, readdirSync, mkdirSync, renameSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'

import { fingerprintTemplate } from '../lib/fingerprint.js'
import { bodyDerivedFingerprintTokens, classifyDuplicateRedline, duplicatedRedlines, sanitizeRedlines } from '../lib/hygiene.js'
import {
  bulletLines, dedupeRedlines, listTemplates, parseFrontmatter, readProfile, sectionOf, writeProfile, writeTemplate,
} from '../lib/store.js'

const argv = process.argv.slice(2)
const flag = (k) => { const i = argv.indexOf(k); return i === -1 ? undefined : argv[i + 1] }
const apply = argv.includes('--apply')
const home = flag('--home')
const retire = new Set(String(flag('--retire') ?? '').split(',').map((s) => s.trim()).filter(Boolean))
if (!home) { console.error('用法: node scripts/rebuild-project-scope.mjs --home <dir> [--apply] [--retire tpl-x,tpl-y]'); process.exit(2) }

/** 只替换「## 禁区」这一段的正文，其余原样保留 */
function replaceSection(md, title, items) {
  const re = new RegExp(`(##\\s*${title}\\s*\\r?\\n\\r?\\n)([\\s\\S]*?)(?=\\r?\\n##\\s|$)`)
  if (!re.test(md)) return md
  const block = items.length ? items.map((t) => `- ${t}`).join('\n') : '（本主题无额外禁区）'
  return md.replace(re, `$1${block}\n`)
}

const projRoot = join(home, 'projects')
if (!existsSync(projRoot)) { console.error(`没有 projects 目录：${projRoot}`); process.exit(2) }

const stamp = new Date().toISOString().slice(0, 10)
const retiredDir = join(home, `_retired-${stamp}`)
let changed = 0
let retired = 0

// ── 模式 A：--hoist ──────────────────────────────────────────────
// 把「被抄进多份模板的项目级禁区」收进项目档案（profile.md），模板里只留主题约束。
// 判据见 lib/hygiene.js 的 classifyDuplicateRedline：技术边界 → 项目级；
// 业务语义（跨天时长怎么算）→ 主题级，跟着模板走，收进档案反而会污染全仓库任务。
if (argv.includes('--hoist')) {
  let hoisted = 0
  let touched = 0
  let keptTheme = 0

  for (const scope of readdirSync(projRoot)) {
    const templates = listTemplates(home, scope).filter((t) => t.scope === scope)
    if (!templates.length) continue

    const rows = templates.map((t) => {
      const { body } = parseFrontmatter(readFileSync(join(projRoot, scope, 'templates', `${t.id}.md`), 'utf8'))
      return { id: t.id, redlines: bulletLines(sectionOf(body, '禁区')) }
    })
    const dups = duplicatedRedlines(rows)
    const projectWide = dups.filter((d) => classifyDuplicateRedline(d.text, d.ids.length) === 'project-wide')
    keptTheme += dups.length - projectWide.length
    if (!projectWide.length) continue

    const profile = readProfile(home, scope)
    const remove = new Set(projectWide.map((d) => d.text.trim()))
    const merged = dedupeRedlines([...profile.redlines, ...projectWide.map((d) => d.text)])

    console.log(`\n[${apply ? '应用' : '预览'}] ${scope}：${projectWide.length} 条项目级禁区 → profile.md（档案共 ${merged.length} 条）`)
    for (const d of projectWide) console.log(`  + ${d.text}   ← ${d.ids.length} 份模板`)
    if (apply) writeProfile(home, scope, { repoName: profile.repoName || scope, redlines: merged })
    hoisted += projectWide.length

    for (const t of templates) {
      const file = join(projRoot, scope, 'templates', `${t.id}.md`)
      const { body } = parseFrontmatter(readFileSync(file, 'utf8'))
      const redlines = bulletLines(sectionOf(body, '禁区'))
      const remained = redlines.filter((r) => !remove.has(r.trim()))
      if (remained.length === redlines.length) continue
      touched++
      const nextBody = replaceSection(body, '禁区', remained)
      if (apply) {
        writeTemplate(home, scope, t.id, {
          name: t.name,
          category: t.category,
          tags: t.tags,
          fingerprint: t.fingerprint,
          hitCount: t.hitCount ?? 0,
          created: t.created,
          lastUsed: t.lastUsed,
        }, nextBody)
      }
      console.log(`  - ${scope}/${t.id} 禁区 ${redlines.length} → ${remained.length} 条`)
    }
  }

  console.log(`\n${apply ? '已应用' : '预览'}：${hoisted} 条收进档案，${touched} 份模板被改，${keptTheme} 条主题级重复保留${apply ? '' : '（加 --apply 执行）'}`)
  process.exit(0)
}

for (const scope of readdirSync(projRoot)) {
  const templates = listTemplates(home, scope).filter((t) => t.scope === scope)
  for (const t of templates) {
    const file = join(projRoot, scope, 'templates', `${t.id}.md`)

    if (retire.has(t.id)) {
      console.log(`[退役] ${scope}/${t.id}  ${t.name}`)
      if (apply) {
        mkdirSync(retiredDir, { recursive: true })
        renameSync(file, join(retiredDir, `${t.id}.md`))
      }
      retired++
      continue
    }

    const { body } = parseFrontmatter(readFileSync(file, 'utf8'))
    const redlines = bulletLines(sectionOf(body, '禁区'))
    const { kept, dropped } = sanitizeRedlines(redlines)
    const nextFp = fingerprintTemplate({ name: t.name, tags: t.tags, topicOnly: true })
    const junk = bodyDerivedFingerprintTokens(t)
    const nextBody = replaceSection(body, '禁区', kept)
    const bodyChanged = nextBody !== body
    const fpChanged = JSON.stringify(nextFp.map((x) => `${x.token}|${x.weight}`)) !== JSON.stringify((t.fingerprint ?? []).map((x) => `${x.token}|${x.weight}`))

    if (!dropped.length && !bodyChanged && !fpChanged) continue
    changed++
    console.log(`\n[${apply ? '应用' : '预览'}] ${scope}/${t.id}  ${t.name}`)
    if (dropped.length) for (const d of dropped) console.log(`  - 丢禁区：${d}`)
    if (junk.length) console.log(`  - 指纹去掉 ${junk.length} 个正文切片：${junk.slice(0, 8).join(' / ')}`)
    console.log(`  - 指纹 ${(t.fingerprint ?? []).length} → ${nextFp.length} 项`)

    if (apply) {
      writeTemplate(home, scope, t.id, {
        name: t.name,
        category: t.category,
        tags: t.tags,
        fingerprint: nextFp,
        hitCount: t.hitCount ?? 0,
        created: t.created,
        lastUsed: t.lastUsed,
      }, nextBody)
    }
  }
}

console.log(`\n${apply ? '已应用' : '预览'}：${changed} 份待改，${retired} 份退役${apply ? '' : '（加 --apply 执行）'}`)
