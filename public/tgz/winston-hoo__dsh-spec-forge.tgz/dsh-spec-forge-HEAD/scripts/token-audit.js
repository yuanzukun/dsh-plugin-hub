// token-audit.js —— 插件 token 成本静态审计
//
// 目标：量化「dsh-spec-forge 到底吃掉多少 token」以及「命中复用一次的成本」。
// 方法：
//   1. 固定开销：常驻系统提示词段、5 个工具的 defineTool 定义文本（近似序列化）
//   2. 按需开销：SKILL.md 全文（首次加载时进上下文一次）
//   3. 调用开销：用插件自身 lib 对样例需求产出真实的 recall/triage/distill 文本并测量
//   4. 命中开销：用真实模板库（~/.dsh/spec-forge）跑 rankTemplates + renderInjection 实测
//
// 口径说明：无 DeepSeek 官方 tokenizer，采用近似估算
//   tokens ≈ CJK 字符数 × 1.0 + 其余字符数 × 0.25
//   真实值取决于模型 tokenizer，误差约 ±30%，数量级可靠。
//
// 用法：node scripts/token-audit.js [--home <DSH_HOME>]

import { readFileSync, existsSync, readdirSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { homedir } from 'node:os'

import { focusFingerprint, fingerprint, inferQueryTags } from '../lib/fingerprint.js'
import { inferQueryCategory } from '../lib/classify.js'
import { rankTemplates } from '../lib/match.js'
import { triageRequirement, renderInjection, renderPreStepNotice, renderRoutingLines, renderTriageReport } from '../lib/render.js'
import { listTemplates, repoHash, dataRoot } from '../lib/store.js'

const __dirname = dirname(fileURLToPath(import.meta.url))
const repoRoot = join(__dirname, '..')

// ---------- 估算器 ----------
const cjkRe = /[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]/g
function estTokens(text) {
  const s = String(text ?? '')
  const cjk = (s.match(cjkRe) || []).length
  const rest = s.length - cjk
  return Math.round(cjk * 1.0 + rest * 0.25)
}
const pad = (s, n) => String(s).padEnd(n)
const row = (...cells) => cells.map((c, i) => pad(String(c), [26, 10, 10, 10][i] ?? 10)).join('')

const out = []
out.push('# dsh-spec-forge · token 静态审计')
out.push('')
out.push(`> 口径：tokens ≈ CJK 字符×1.0 + 其余字符×0.25（无官方 tokenizer，误差 ±30%，数量级可靠）`)
out.push('')
out.push(row('项目', '字符数', '估算tokens', '说明'))
out.push(row('---', '---', '---', '---'))

// ---------- 1. 常驻系统提示词段 ----------
// 0.4.7：三态路由改由 lib/render.js 的 ROUTING_CONTRACT 渲染，源码里不再有那几行字面量。
// 旧的"只抓单引号字面量"做法会把它们整段漏掉（实测把 823 字符量成 238 token）。
// 这里按出现顺序重组：字面量照抄，遇到 `...renderRoutingLines()` 就展开契约的真实输出。
const indexSrc = readFileSync(join(repoRoot, 'index.js'), 'utf8')
const sysMatch = /name: 'spec-forge:routing'[\s\S]*?text: \[([\s\S]*?)\]\.join\('\\n'\)/.exec(indexSrc)
let sysText = ''
if (sysMatch) {
  const parts = []
  for (const rawLine of sysMatch[1].split('\n')) {
    const line = rawLine.trim()
    if (line.startsWith('//') || !line) continue
    if (line.startsWith('...renderRoutingLines()')) {
      parts.push(...renderRoutingLines())
      continue
    }
    const literal = /^'((?:[^'\\]|\\.)*)',?$/.exec(line)
    if (literal) parts.push(literal[1])
  }
  sysText = parts.join('\n')
}
if (!sysText) throw new Error('未能测量常驻提示段（token-audit 的提取逻辑需要跟着 index.js 更新）')
const sysToks = estTokens(sysText)
// SYS_BUDGET 是**参考线，不是硬限制**（0.4.4 明确）：
// dsh 的 renderPrompt 只把两侧 sections 按 order 排序后 join('\n\n')，
// 没有任何截断或长度上限（依据 packages/core/system-prompt/src/index.ts 的 renderPrompt）。
// 因此超线只意味着"每轮多花几个 token"，**不会导致指令被裁剪或丢失**。
// 教训：曾把 447 误读成"超预算"而做了一轮压缩，结果丢掉了「报错排查」等真实指令——
// 不要为了压到线内牺牲内容；内容的完整性优先于这条线。
const SYS_BUDGET = 450
out.push(
  row(
    '① 常驻系统提示词段 spec-forge:routing',
    sysText.length,
    sysToks,
    sysToks <= SYS_BUDGET
      ? `每轮请求都带（参考线 ≤${SYS_BUDGET}，非硬限制）`
      : `每轮请求都带（超参考线约 ${sysToks - SYS_BUDGET} token；无截断风险，按内容需要取舍）`,
  ),
)

// ---------- 2. 各工具的 defineTool 定义（近似序列化体量） ----------
const toolBlocks = {}
const names = ['spec_recall', 'spec_triage', 'spec_distill', 'spec_retro']
for (let i = 0; i < names.length; i++) {
  const name = names[i]
  const start = indexSrc.indexOf(`name: '${name}'`)
  if (start < 0) continue
  const next = i + 1 < names.length ? indexSrc.indexOf(`name: '${names[i + 1]}'`) : indexSrc.indexOf('ctx.logger?.info')
  const end = next > start ? next : start + 2000
  let slice = indexSrc.slice(start, end)
  // 去掉 JS 代码噪音里不属于"发给模型"的部分：函数体、execute、async、大括号样板
  // 保留 description + schema 的字段名与描述文本（序列化后这些都会出现）
  slice = slice
    .replace(/async execute[\s\S]*$/, '')
    .replace(/\b(?:const|return|function|=>|\{|\}|\[|\])\s*/g, ' ')
    .replace(/'/g, '')
  // 去掉 execute 之后残留（上面已截断）
  toolBlocks[name] = slice
}
let toolsTotal = 0
let toolsToks = 0
for (const name of names) {
  const t = toolBlocks[name] ?? ''
  toolsTotal += t.length
  toolsToks += estTokens(t)
  out.push(row(`② 工具定义 ${name}`, t.length, estTokens(t), `每轮请求都带（${names.length} 个合计见下）`))
}
out.push(row(`② ${names.length} 个工具定义合计`, toolsTotal, toolsToks, '随工具列表每轮注入，含字段描述'))

// ---------- 3. SKILL.md（按需加载） ----------
const skillFile = join(repoRoot, 'skills', 'spec-forge', 'SKILL.md')
const skillText = existsSync(skillFile) ? readFileSync(skillFile, 'utf8') : ''
out.push(row('③ SKILL.md（按需加载一次）', skillText.length, estTokens(skillText), '模型调用 skill 工具时整篇进上下文'))

// ---------- 3b. pre-step 注入（0.5.0，命中才计入） ----------
// 常驻段是"每轮固定税"，这一层相反：只有判成 L1 一步直达 / 需求缺内容才注入，
// triage 与普通对话为 0。所以这里量的是"命中时的单价"，不是每轮成本。
const noticeFast = renderPreStepNotice({ level: 1, fastTrack: true, contentGap: [] })
const noticeGap = renderPreStepNotice({ level: 2, fastTrack: false, contentGap: ['按钮的文案与用途'] })
out.push(row('④ pre-step 注入：L1 一步直达', noticeFast.length, estTokens(noticeFast), '命中才计入；不命中为 0'))
out.push(row('④ pre-step 注入：需求缺内容', noticeGap.length, estTokens(noticeGap), '命中才计入；不命中为 0'))

// ---------- 4. 单次工具调用的典型输出 ----------
const REQUIREMENTS = {
  L1字段需求: 'index.vue 这个后台管理页面的新增/修改接口增加一个主管人员字段 isMainAdmin，值为1是，0否，默认为否，这个字段用开关来显示，请帮我完成这个需求',
  模糊需求: '帮我优化一下那个查询',
  新增store方法: '在 dsh-spec-forge 的 lib/store.js 里新增一个 staleReport 方法，列出超过 90 天未命中的模板，不要改 listTemplates 的返回结构，需要 npm test 通过',
}
out.push('')
out.push('### 4. 单次工具调用产出的文本（插件发给模型的增量）')
out.push('')
for (const [label, req] of Object.entries(REQUIREMENTS)) {
  const triage = triageRequirement(req)
  const triageReport = renderTriageReport(triage)
  const recallMiss = renderInjection({ results: [], redlines: [] })
  const fp = fingerprint(`示例模板 ${req}`)
  out.push(`- **${label}**（输入需求 ${req.length} 字）`)
  out.push(`  - spec_recall 未命中注入：${recallMiss.length} 字符 ≈ ${estTokens(recallMiss)} tokens`)
  out.push(`  - spec_triage 报告：${triageReport.length} 字符 ≈ ${estTokens(triageReport)} tokens（L${triage.classification.level}）`)
  out.push(`  - 需求指纹 token：${fp.length} 个`)
}

// ---------- 5. 命中复用的真实成本 ----------
out.push('')
out.push('### 5. 命中历史模板时的注入成本（真实模板库）')
out.push('')
const home = process.argv.includes('--home') ? process.argv[process.argv.indexOf('--home') + 1] : join(homedir(), '.dsh')
// listTemplates 的 home 参数自 0.4.1 起是「数据根」，所以这里先补一层 dataRoot
const root = dataRoot(home)
const projDir = join(root, 'projects')
let totalReal = 0
let hitInject = null
if (existsSync(projDir)) {
  const scopes = readdirSync(projDir)
  out.push(`真实库位置：${root}（项目层 ${scopes.length} 个仓库）`)
  for (const scope of scopes) {
    const templates = listTemplates(root, scope)
    if (templates.length === 0) continue
    totalReal += templates.length
    out.push(`- 仓库 ${scope}：${templates.length} 份模板`)
    // 用与 spec_recall 一致的查询构建（聚焦 + tags/category + 同仓库加分）测命中注入
    const q = REQUIREMENTS.L1字段需求
    const buildQ = (text) => {
      const fp = focusFingerprint(fingerprint(text))
      fp.tags = inferQueryTags(text)
      const cat = inferQueryCategory(text)
      if (cat) fp.category = cat
      return fp
    }
    let results = rankTemplates({ queryFp: buildQ(q), templates, repoHash: scope, threshold: 0.15 })
    let tag = ''
    let hit = results.filter((r) => r.hit)
    if (hit.length === 0) {
      results = rankTemplates({ queryFp: buildQ(q), templates, repoHash: scope, threshold: 0.1 })
      hit = results.filter((r) => r.hit)
      tag = '（默认 0.15 未命中，放宽到 0.1 观察注入上限）'
    }
    if (hit.length > 0) {
      const inj = renderInjection({ results: hit, redlines: [], maxTemplates: 2, maxChars: 4000 })
      out.push(`  - 样例需求「${q.slice(0, 18)}…」命中 ${hit.length} 份，注入 ${inj.length} 字符 ≈ ${estTokens(inj)} tokens ${tag}`)
      if (!hitInject) hitInject = inj.length
    }
  }
}
if (totalReal === 0) {
  out.push('（~/.dsh/spec-forge 暂无模板，回退用仓库示例模板估算）')
  const ex = join(repoRoot, 'templates', 'example-spring-pagination.md')
  if (existsSync(ex)) {
    const tplText = readFileSync(ex, 'utf8')
    out.push(`- 示例模板全文：${tplText.length} 字符 ≈ ${estTokens(tplText)} tokens（这是整份，注入只取节选）`)
  }
}

// ---------- 汇总 ----------
out.push('')
out.push('### 汇总（每次全新请求的固定税 = ① + ②）')
const fixed = estTokens(sysText) + toolsToks
out.push('')
out.push(`- 常驻系统提示段：≈ ${estTokens(sysText)} tokens/请求`)
out.push(`- 五个工具定义：≈ ${toolsToks} tokens/请求（含字段描述；dsh 序列化为 JSON schema 会略增）`)
out.push(`- **固定税合计 ≈ ${fixed} tokens/请求**（只出现在发往模型的完整请求里）`)
out.push(`- SKILL.md ≈ ${estTokens(skillText)} tokens，仅在模型展开技能那一次计入（及其后的上下文重建）`)
out.push('')
out.push('> 注意：以上是"发往模型"的文本量。实际计费按请求次数累计，且 dsh 会在新用户轮重建长上下文，')
out.push('> 届时此前注入的历史（含模板/报告）会整体重计一次——所以让每次注入尽量短、命中尽量准，收益是复利。')

console.log(out.join('\n'))
