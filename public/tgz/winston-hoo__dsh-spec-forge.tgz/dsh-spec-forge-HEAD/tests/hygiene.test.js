// 模板卫生（0.8.1）
//
// 背景：项目模板把一次性任务边界写进「禁区」，下一次同仓库的不相关任务会命中它，
// 把「本次只动 lib/store.js…不碰 index.js」当成硬约束注入。模型没有能力判断它过期。
// 这里把「写入前拦 / 体检时报 / 指纹不取正文」三件事钉成断言。

import { test } from 'node:test'
import assert from 'node:assert/strict'

import {
  bodyDerivedFingerprintTokens,
  classifyDuplicateRedline,
  duplicatedRedlines,
  isTaskScopedRedline,
  sanitizeRedlines,
  validateSeedTemplate,
} from '../lib/hygiene.js'
import { fingerprintTemplate } from '../lib/fingerprint.js'

test('isTaskScopedRedline：只认「范围词 + 具体文件」', () => {
  const scoped = [
    '本次只动 lib/store.js 与 tests/store.test.js，不碰 index.js 及工具接线',
    '只改目标详情页目录下的 js/wxml',
    '只改 pages/spot/detail/（js/wxml）',
    '只改目标列表页 js/wxml 与上一订单详情页未合规点',
  ]
  for (const s of scoped) assert.equal(isTaskScopedRedline(s), true, `应判为一次性：${s}`)

  // 通用纪律：没点名任何具体文件，下一个任务里依然成立 —— 必须保留
  const reusable = [
    '只改用户指定的页面文件',
    '临时脚本用完即删',
    '临时脚本与探针配置用完必须删除',
    '不把存量违规纳入本次卡口范围，让改动无法通过回归',
    '不改后端/其它订单页面',
    '既有导出函数 readTemplate/writeTemplate 等签名不可改动',
    '金额、状态等其它字段不动',
  ]
  for (const s of reusable) assert.equal(isTaskScopedRedline(s), false, `应保留为主题约束：${s}`)
})

test('sanitizeRedlines：只丢锁死范围的那几条，保留主题约束', () => {
  const { kept, dropped } = sanitizeRedlines([
    '本次只动 lib/store.js，不碰 index.js',
    '不改后端/其它订单页面',
    '只改目标详情页目录下的 js/wxml',
    '只改用户指定的页面文件',
  ])
  assert.deepEqual(kept, ['不改后端/其它订单页面', '只改用户指定的页面文件'])
  assert.equal(dropped.length, 2)
})

test('validateSeedTemplate：一次性禁区、空标签、缺验收都必须报出来', () => {
  const bad = validateSeedTemplate(
    {
      name: '某主题模板',
      tags: ['vue'],
      approach: ['a'],
      acceptance: ['b'],
      redlines: ['本次只动 src/views/a.vue'],
    },
    { scope: 'demo-scope' },
  )
  assert.equal(bad.ok, false)
  const all = bad.problems.join('\n')
  assert.match(all, /一次性任务边界/)
  assert.match(all, /至少 2 个主题标签/)

  const good = validateSeedTemplate(
    {
      name: '列表字段展示口径',
      tags: ['列表', '字段展示'],
      approach: ['在既有列配置里加一列'],
      acceptance: ['列头文案与接口字段一致'],
      redlines: ['不改后端/接口'],
    },
    { scope: 'demo-scope' },
  )
  assert.equal(good.ok, true, good.problems.join('\n'))
})

test('bodyDerivedFingerprintTokens：项目模板指纹不得含正文切片', () => {
  const base = { scope: 'demo-scope', name: '跨日时长时间口径', tags: ['跨日', '时长'] }
  const clean = { ...base, fingerprint: fingerprintTemplate({ ...base, topicOnly: true }) }
  assert.deepEqual(bodyDerivedFingerprintTokens(clean), [], 'topicOnly 指纹不该有正文切片')

  const polluted = {
    ...base,
    fingerprint: [...clean.fingerprint, { token: '回结', weight: 1 }, { token: '储层', weight: 1 }],
  }
  assert.deepEqual(bodyDerivedFingerprintTokens(polluted), ['回结', '储层'])

  const global = { scope: 'global', name: 'x', tags: [], fingerprint: [{ token: '任意', weight: 1 }] }
  assert.deepEqual(bodyDerivedFingerprintTokens(global), [], '全局模板允许带 prompt 指纹，不在此检查范围')
})

test('duplicatedRedlines：同一 scope 内被抄进多份模板的禁区能被统计出来', () => {
  const list = [
    { id: 'tpl-a', redlines: ['不改后端/接口', '不改 mock'] },
    { id: 'tpl-b', redlines: ['不改后端/接口'] },
  ]
  const dup = duplicatedRedlines(list)
  assert.equal(dup.length, 1)
  assert.deepEqual(dup[0].ids.sort(), ['tpl-a', 'tpl-b'])
})

test('classifyDuplicateRedline：技术边界进档案，业务语义留模板', () => {
  // 项目级：讲的是这个仓库的技术边界，任何任务都成立
  for (const t of [
    '不改接口封装/API/类型定义/后端/mock',
    '前端不加业务校验（后端负责）',
    '不擅自改列表查询/新增/修改既有调用逻辑',
    '不改后端/其它订单页面',
  ]) assert.equal(classifyDuplicateRedline(t), 'project-wide', t)

  // 主题级：讲的是某个主题的业务语义，跨主题注入就是污染
  for (const t of [
    '不擅自改跨天快捷时长语义（属订单详情页，不在本模板范围）',
    '不要擅自把跨天快捷时长改成跨日推算（语义归用户显式选结束时间）',
  ]) assert.equal(classifyDuplicateRedline(t), 'theme', t)
})
