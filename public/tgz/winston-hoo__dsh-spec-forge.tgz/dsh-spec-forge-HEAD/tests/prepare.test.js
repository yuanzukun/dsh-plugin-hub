import { test } from 'node:test'
import assert from 'node:assert/strict'

import { cleanRequirement, shouldSkipMatching, extractJsonKeys, stripJsonBlocks } from '../lib/prepare.js'

test('stripJsonBlocks：剥离内联 JSON，保留前后正文', () => {
  const out = stripJsonBlocks('订单详情页面时长不对，接口返回 {"msg":"操作成功","data":{"total":4}} 请修一下')
  assert.ok(!out.includes('"msg"'), 'JSON 结构应被剥掉')
  assert.ok(out.includes('订单详情页面时长不对'), '前文必须保留')
  assert.ok(out.includes('请修一下'), '后文必须保留')
})

test('stripJsonBlocks：未闭合的 JSON 不能吞掉正文', () => {
  // 需求被截断时会只剩 `{`：实现要把它剥到末尾，但前面的正文必须保留
  const out = stripJsonBlocks('跨天时长算错，接口返回 {"msg":"操作成功","data":{"rows":[')
  assert.ok(out.includes('跨天时长算错'))
  assert.ok(!out.includes('"msg"'))
})

test('stripJsonBlocks：普通的 `{` 不被当成 JSON（如代码片段）', () => {
  const out = stripJsonBlocks('把 if (a) { b() } 改成 if (a) { c() }')
  assert.ok(out.includes('{ b() }'), '不含 JSON 键值的花括号块应原样保留')
})

test('extractJsonKeys：只收有辨识度的字段，通用键排除', () => {
  const keys = extractJsonKeys('{"id":1,"status":1,"isMainAdmin":1,"unitPrice":100,"createTime":"x"}')
  assert.ok(keys.includes('isMainAdmin'))
  assert.ok(keys.includes('unitPrice'))
  assert.ok(!keys.includes('id'), '通用键 id 不该回填')
  assert.ok(!keys.includes('status'), '通用键 status 不该回填')
  assert.ok(!keys.includes('createTime'))
})

test('extractJsonKeys：最多 8 个，避免稀释向量', () => {
  const json = `{${Array.from({ length: 30 }, (_, i) => `"field${i}":1`).join(',')}}`
  assert.equal(extractJsonKeys(json).length, 8)
})

test('cleanRequirement：堆栈与 Node 内部路径被移除，字段名保留', () => {
  const raw = [
    '帮我解决报错',
    "Error: EBUSY: resource busy or locked, watch 'D:/tmp/x.tmpdir/index.vue.tmp'",
    '    at Object.watch (node:internal/fs/watchers:323:20)',
    '接口返回 {"code":200,"data":{"orderNo":"A1"}}',
  ].join('\n')
  const out = cleanRequirement(raw)
  assert.ok(out.includes('EBUSY'), '错误码必须保留')
  assert.ok(!out.includes('node:internal'), '内部路径应被移除')
  assert.ok(!out.includes('"code"'), 'JSON 结构应被剥掉')
})

test('cleanRequirement：先清洗再截断（JSON 被截半也能剥干净）', () => {
  const raw = `需求描述在这里${'字'.repeat(50)}{"a":1,"b":2,"c":3}`
  const out = cleanRequirement(raw, { clip: 60 })
  assert.ok(out.startsWith('需求描述在这里'))
  assert.ok(!out.includes('"a":'))
})

test('cleanRequirement：keepKeys=false 时不回填字段名', () => {
  const raw = '加个开关，接口 {"isMainAdmin":1}'
  assert.ok(cleanRequirement(raw).includes('isMainAdmin'))
  assert.ok(!cleanRequirement(raw, { keepKeys: false }).includes('isMainAdmin'))
})

test('shouldSkipMatching：极短输入不召回模板', () => {
  assert.equal(shouldSkipMatching('启动').skip, true)
  assert.equal(shouldSkipMatching('启动').reason, 'too-short')
  assert.equal(shouldSkipMatching('好').skip, true)
})

test('shouldSkipMatching：仅引用附件且很短视为续轮指代', () => {
  const t = '@image#1:Clipboard_Screenshot.png 实际需求有用到这种配置'
  const r = shouldSkipMatching(t)
  assert.equal(r.skip, true)
  assert.equal(r.reason, 'referential-only')
  assert.ok(r.effectiveLength < 15)
})

test('shouldSkipMatching：正常需求不得被挡', () => {
  for (const t of [
    '登录页加个按钮',
    '列表增加显示 extraField 字段',
    '把表格做成滚动条，不要整个页面滚动',
    '把某后台项目重写一遍，现有代码结构全扔掉',
    '@"src/api/order.ts" 这个接口报 500，帮我定位',
  ]) {
    assert.equal(shouldSkipMatching(t).skip, false, `不该跳过：${t}`)
  }
})

test('shouldSkipMatching：路径与 URL 不计入有效字符', () => {
  const r = shouldSkipMatching('@"src/views/very/deep/nested/some/file.vue"')
  assert.equal(r.skip, true, '只有路径、没有话，按无需求处理')
})
