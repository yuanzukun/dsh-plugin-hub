import { test } from 'node:test'
import assert from 'node:assert/strict'

import { SECTIONS, renderInjection, renderTemplateMarkdown, renderTriageReport, sectionOf, triageRequirement } from '../lib/render.js'
import { parseFrontmatter } from '../lib/store.js'

test('triageRequirement：过短且零锚点的空需求触发 L2 安全阀（问一次）', () => {
  const r = triageRequirement('帮我改一下')
  assert.equal(r.tooShort, true)
  assert.equal(r.classification.level, 2)
  assert.equal(r.unactionable, true)
  assert.equal(r.needsClarify, true, '0.4.0：空需求务必先问一次，避免盲目套默认值返工')
  assert.equal(r.ready, false)
})

test('triageRequirement：有锚点的 L2 需求不追问、按默认执行', () => {
  const r = triageRequirement('在 UserController.java 帮我做一下用户列表的导出优化，需要支持 Excel 和 CSV')
  assert.equal(r.classification.level, 2)
  assert.equal(r.unactionable, false)
  assert.equal(r.needsClarify, false, '0.4.0：可自举的 L2 一律按默认执行')
})

test('triageRequirement：四要素齐全时判定为可直接开工', () => {
  const r = triageRequirement(
    '在 src/main/java/UserController.java 新增分页查询接口，不要修改 common/Result.java 的返回结构，需要 mvn test 通过'
  )
  assert.equal(r.needsClarify, false, `不应要求澄清，缺失项：${r.missing.map((d) => d.label).join(',')}`)
  assert.equal(r.ready, true)
  assert.equal(r.hasPath, true)
})

test('triageRequirement：未说明禁区时识别为缺失', () => {
  const r = triageRequirement('在 src/main/java/UserController.java 里加一个查询接口，要能分页')
  const boundary = r.dimensions.find((d) => d.key === 'boundary')
  assert.equal(boundary.status, 'missing')
  assert.equal(r.needsClarify, false, '0.4.0：缺失项不再触发追问，L2 按默认执行')
})

test('triageRequirement：提到禁区关键词即判定为已明确', () => {
  const r = triageRequirement('改一下 a.vue 的样式，但不要动公共组件')
  const boundary = r.dimensions.find((d) => d.key === 'boundary')
  assert.equal(boundary.status, 'covered')
})

test('triageRequirement：没有路径时改动范围只能算部分明确', () => {
  const r = triageRequirement('给订单模块加一个导出功能，要用异步，需要测试通过')
  const approach = r.dimensions.find((d) => d.key === 'approach')
  assert.equal(approach.status, 'partial')
  assert.equal(r.hasPath, false)
})

test('triageRequirement：中英混排的验收信号都能识别', () => {
  assert.equal(triageRequirement('改一下 a，需要 mvn test 通过').dimensions.find((d) => d.key === 'goal').status, 'covered')
  assert.equal(triageRequirement('改一下 a，需要测试通过').dimensions.find((d) => d.key === 'goal').status, 'covered')
  assert.equal(triageRequirement('改一下 a').dimensions.find((d) => d.key === 'goal').status, 'missing')
})

test('triageRequirement：空输入不抛错，且触发安全阀要求澄清', () => {
  const r = triageRequirement('')
  assert.equal(r.length, 0)
  assert.equal(r.unactionable, true)
  assert.equal(r.needsClarify, true, '0.4.0：空需求必须问清目标')
  assert.equal(r.ready, false)
})

test('triageRequirement：信息不足的空需求报告输出 L2 安全阀追问区', () => {
  const r = triageRequirement('帮我改一下那个查询')
  assert.equal(r.needsClarify, true)
  const report = renderTriageReport(r)
  assert.ok(report.includes('Level 2'), '必须标注 Level 2')
  assert.ok(report.includes('L2 信息不足'), '必须出现安全阀标题')
  assert.ok(report.includes('需要先向你确认'), '安全阀必须列追问清单')
  assert.ok(report.includes('不要反复追问'), '必须约束只问一次')
})

test('renderTriageReport：有锚点的 L2 输出按默认执行区域，不列问题', () => {
  const r = triageRequirement('在 UserController.java 帮我做一下用户列表的导出优化，需要支持 Excel 和 CSV')
  assert.equal(r.classification.level, 2)
  const report = renderTriageReport(r)
  assert.ok(report.includes('需求完整度体检'))
  assert.ok(report.includes('已按默认执行'))
  assert.ok(!report.includes('需要先向你确认'), 'L2 可自举时禁止输出追问清单')
  assert.ok(report.includes('要实现什么'))
  assert.ok(report.includes('要怎么改'))
  assert.ok(report.includes('哪些不能改'))
})

test('renderTriageReport：L3 必须输出先问后查约束与禁止工具清单', () => {
  const r = triageRequirement('需要重构整个用户中心，跨文件跨模块')
  assert.equal(r.classification.level, 3)
  const report = renderTriageReport(r)
  assert.ok(report.includes('先问后查'), '必须出现先问后查约束')
  assert.ok(report.includes('禁止调用任何文件类工具'), '必须列明禁止的文件工具')
  assert.ok(report.includes('read_file') && report.includes('grep'), '必须点名 read_file/grep 等具体工具')
})

test('renderTriageReport：L2 需求齐全时按默认执行、不出现追问清单', () => {
  const r = triageRequirement('在 src/main/java/UserController.java 新增分页查询接口，不要修改 common/Result.java 的返回结构，需要 mvn test 通过')
  const report = renderTriageReport(r)
  assert.ok(!report.includes('需要先向你确认'))
  assert.ok(report.includes('已按默认执行'))
})

test('renderTriageReport：L2 不再附带历史模板提示（避免与分类器推断值重复）', () => {
  const r = triageRequirement('在 UserController.java 帮我做一下用户列表的导出优化，需要支持 Excel 和 CSV')
  assert.equal(r.classification.level, 2)
  const report = renderTriageReport(r)
  assert.ok(report.includes('Level 2'), '必须标注 Level 2')
  assert.ok(!report.includes('历史模板建议追加确认'), 'L2 不再附带历史模板提示')
})

test('renderTriageReport：Level 1 快速通道——单字段 CRUD 输出"执行清单"且无追问', () => {
  const text =
    'index.vue 这个后台管理页面的新增/修改接口增加一个主管人员字段 isMainAdmin，值为1是，0否，默认为否，这个字段用开关来显示，请帮我完成这个需求'
  const r = triageRequirement(text)
  assert.equal(r.classification.level, 1)
  assert.equal(r.needsClarify, false, 'L1 必须 needsClarify=false，禁止追问')
  assert.equal(r.ready, true, 'L1 必须 ready=true，可直接动手')

  const report = renderTriageReport(r)
  assert.ok(report.includes('Level 1'), '必须标注 Level 1')
  assert.ok(report.includes('直接执行清单'), '必须输出直接执行清单')
  assert.ok(report.includes('风格自举要求'), '必须输出风格自举要求')
  assert.ok(report.includes('保守默认'), '必须输出保守默认表')
  assert.ok(report.includes('待办标注规则'), '必须输出待办标注规则')
  assert.ok(report.includes('isMainAdmin'), '字段名必须出现')
  assert.ok(report.includes('el-switch'), '推断的 UI 组件必须出现')
  assert.ok(report.includes('否'), '推断的默认值必须出现')
  assert.ok(report.includes('index.vue'), '推断的目标文件必须出现')
  assert.ok(!report.includes('需要先向你确认'), 'L1 报告禁止出现"需要先向你确认"标题')
})

test('renderTriageReport：Level 1 跳过词场景输出明确的"已跳过追问"标识', () => {
  const r = triageRequirement('直接做，改一下 a.vue 的样式')
  assert.equal(r.classification.level, 1)
  assert.equal(r.classification.skipTrigger, '直接做')
  const report = renderTriageReport(r)
  assert.ok(report.includes('Level 1'))
  assert.ok(report.includes('直接做'), '跳过触发词必须出现在报告中')
  assert.ok(report.includes('直接执行清单'))
})

test('renderTriageReport：Level 2 按默认执行、不再输出追问清单', () => {
  const r = triageRequirement('在 UserController.java 帮我做一下用户列表的导出优化，需要支持 Excel 和 CSV')
  assert.equal(r.classification.level, 2, `必须判定为 L2，signals=${r.classification.signals.join(',')}`)
  const report = renderTriageReport(r)
  assert.ok(report.includes('Level 2'))
  assert.ok(report.includes('已按默认执行'), 'L2 必须输出"已按默认执行"区域')
  assert.ok(!report.includes('需要先向你确认'), 'L2 禁止输出追问清单')
  assert.ok(report.includes('UserController.java'), '推断的文件路径必须出现')
})

test('renderTriageReport：Level 3 架构重构保留完整追问', () => {
  const r = triageRequirement('需要重构整个用户中心，跨文件跨模块')
  assert.equal(r.classification.level, 3)
  const report = renderTriageReport(r)
  assert.ok(report.includes('Level 3'))
  assert.ok(report.includes('先问后查'), 'L3 保留先问后查约束')
  assert.ok(report.includes('需要先向你确认'), 'L3 仍输出追问清单')
  assert.ok(report.includes('禁止调用任何文件类工具'), 'L3 仍列明禁止的文件工具')
})

test('renderTemplateMarkdown：包含全部标准段落', () => {
  const md = renderTemplateMarkdown({
    name: '新增分页查询接口',
    category: 'feature/api',
    tags: ['java'],
    trigger: '要求加分页接口时',
    clarify: ['用 pageNum 还是 offset？'],
    approach: ['改 Controller', '改 Service'],
    redlines: ['不要改 Result.java'],
    prompt: '请按四层结构实现',
    acceptance: ['mvn test 通过'],
    repoName: 'demo',
  })
  for (const section of Object.values(SECTIONS)) {
    assert.ok(md.includes(`## ${section}`), `缺少段落：${section}`)
  }
  assert.ok(md.includes('不要改 Result.java'))
  assert.ok(md.includes('- [ ] mvn test 通过'))
  assert.ok(md.includes('1. 改 Controller'))
})

test('renderTemplateMarkdown：内容为空时给出占位而非留白', () => {
  const md = renderTemplateMarkdown({ name: '空模板' })
  assert.ok(md.includes('（待补充）'))
  assert.ok(md.includes('（本次未识别到明确禁区）'))
})

test('renderInjection：无命中时给出明确指引', () => {
  const out = renderInjection({ results: [], redlines: [] })
  assert.ok(out.includes('未命中任何历史模板'))
  assert.ok(out.includes('spec_retro'))
})

test('renderInjection：只注入三段关键内容以控制 token', () => {
  const template = {
    id: 'tpl-a1b2c3d4e5',
    name: '新增分页查询接口',
    score: 0.82,
    hit: true,
    body: [
      '## 触发场景',
      '',
      '要求分页时适用',
      '',
      '## 需求澄清清单',
      '',
      '- 用 pageNum 还是 offset？',
      '',
      '## 标准改法',
      '',
      '1. 改 Controller',
      '',
      '## 禁区',
      '',
      '- 不要改 Result.java',
      '',
      '## 提示词模板',
      '',
      '这段内容很长很长，不应该被注入进去，因为它只在用户主动打开模板时才需要……'.repeat(20),
      '',
      '## 验收标准',
      '',
      '- mvn test 通过',
    ].join('\n'),
  }

  const out = renderInjection({ results: [{ template, score: 0.82, hit: true }], redlines: ['不要动全局配置'] })

  assert.ok(out.includes('命中的历史模板'))
  assert.ok(out.includes('不要动全局配置'), '项目禁区必须出现')
  assert.ok(out.includes('用 pageNum 还是 offset？'), '澄清清单必须出现')
  assert.ok(out.includes('改 Controller'), '标准改法必须出现')
  assert.ok(!out.includes('这段内容很长很长'), '提示词模板正文不应注入，避免浪费 token')
})

test('renderInjection：超长内容被截断', () => {
  const template = {
    id: 'tpl-a1b2c3d4e5',
    name: 'x',
    body: `## 需求澄清清单\n\n${Array.from({ length: 100 }, (_, i) => `- 问题 ${i}`).join('\n')}`,
  }
  const out = renderInjection({ results: [{ template, score: 1, hit: true }], maxChars: 500 })
  assert.ok(out.length <= 520)
  assert.ok(out.includes('已截断'))
})

test('sectionOf：按标题提取段落', () => {
  const md = '## 禁区\n\n- 不要改 A\n\n## 约定\n\n- 用 4 空格\n'
  assert.ok(sectionOf(md, '禁区').includes('不要改 A'))
  assert.ok(!sectionOf(md, '禁区').includes('4 空格'))
})

test('端到端：沉淀出的模板能被再次解析回结构化段落', () => {
  const md = renderTemplateMarkdown({
    name: '新增分页查询接口',
    category: 'feature/api',
    tags: ['java'],
    clarify: ['用 pageNum 还是 offset？'],
    approach: ['改 Controller'],
    redlines: ['不要改 Result.java'],
    acceptance: ['mvn test 通过'],
  })
  const { body } = parseFrontmatter(md)
  assert.ok(sectionOf(body, SECTIONS.clarify).includes('pageNum'))
  assert.ok(sectionOf(body, SECTIONS.redlines).includes('Result.java'))
  assert.ok(sectionOf(body, SECTIONS.acceptance).includes('mvn test 通过'))
})

// ---------- 0.4.5：fastTrack 时省略与指令冲突的内容 ----------

function tplWithFlow() {
  return {
    id: 'tpl-f1a2b3c4d5',
    name: '把设计稿 HTML 落成 admin 页面',
    body: [
      '## 需求澄清清单',
      '',
      '- 页面形态：纯展示还是可交互？',
      '- 路由挂载在哪个菜单下？',
      '',
      '## 标准改法',
      '',
      '1. spec_recall → spec_triage（此类需求通常 L2，问上面 3 条）→ spec_distill',
      '2. 先读参考页 index.vue，抄它的 page-header + btn-export 结构',
      '3. 导出走浏览器原生 Blob 下载',
      '',
      '## 禁区',
      '',
      '- 不改 design 下的源 HTML',
      '',
      '## 验收标准',
      '',
      '- 页面可正常打开且导出可用',
    ].join('\n'),
  }
}

test('renderInjection：fastTrack 时不注入澄清清单（与"禁止追问"冲突）', () => {
  const out = renderInjection({
    results: [{ template: tplWithFlow(), score: 0.4, hit: true }],
    redlines: [],
    fastTrack: true,
  })
  assert.ok(!out.includes('澄清清单：'), 'fastTrack 下不得出现澄清清单')
  assert.ok(!out.includes('页面形态：纯展示还是可交互？'), '澄清问题本身也不该出现')
  assert.ok(out.includes('已省略'), '应说明为何省略，避免模型误以为模板没有澄清清单')
})

test('renderInjection：fastTrack 时滤掉"去调插件工具"的流程行（与首行指令冲突）', () => {
  const out = renderInjection({
    results: [{ template: tplWithFlow(), score: 0.4, hit: true }],
    redlines: [],
    fastTrack: true,
  })
  assert.ok(!/spec_recall\s*→\s*spec_triage/.test(out), '不得注入 spec_recall → spec_triage 流程行')
  assert.ok(!out.includes('spec_distill'), '不得注入 spec_distill')
  assert.ok(out.includes('先读参考页 index.vue'), '改法的实质内容要保留')
  assert.ok(out.includes('导出走浏览器原生 Blob'), '改法的实质内容要保留')
  assert.ok(out.includes('不改 design 下的源 HTML'), '区块禁区要保留')
  assert.ok(out.includes('页面可正常打开且导出可用'), '验收标准要保留')
})

test('renderInjection：非 fastTrack 时行为不变（澄清清单与流程行照旧注入）', () => {
  const out = renderInjection({
    results: [{ template: tplWithFlow(), score: 0.4, hit: true }],
    redlines: [],
  })
  assert.ok(out.includes('澄清清单：'), '非 fastTrack 下澄清清单应保留')
  assert.ok(out.includes('页面形态：纯展示还是可交互？'))
  assert.ok(/spec_recall\s*→\s*spec_triage/.test(out), '非 fastTrack 下流程行保留（此时它是对的）')
  assert.ok(!out.includes('已省略'))
})

test('renderInjection：fastTrack 下模板体积明显小于非 fastTrack', () => {
  const args = { results: [{ template: tplWithFlow(), score: 0.4, hit: true }], redlines: [] }
  const fast = renderInjection({ ...args, fastTrack: true })
  const full = renderInjection({ ...args, fastTrack: false })
  assert.ok(fast.length < full.length, `fastTrack 应更短：${fast.length} vs ${full.length}`)
})
