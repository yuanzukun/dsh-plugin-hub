/**
 * 变异测试（红队门）—— 打分规则的「可证伪性」保障。
 *
 * 借鉴 dsh-routing-suite/graded 的红队门设计：判定规则必须**能被打脸**。
 * 做法：故意把规则改坏（mutation），确认基准**真的会红**。
 * 全绿却改不坏 ⇒ 断言是装饰，规则形同虚设。
 *
 * 这条测试的价值：spec-forge 的 bench/audit 全绿并不代表判定有效 ——
 * 2026-10-20 实测过「bench 18/18 但真实语料 FP 100%」的组合。
 * 变异测试把「规则被改坏时能否被发现」变成可执行的判据。
 *
 * 跑法：node --test tests/mutation.test.js
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const root = path.join(here, '..')

const MATCH_PATH = path.join(root, 'lib', 'match.js')
const FP_PATH = path.join(root, 'lib', 'fingerprint.js')

// bench 用例来自本机 seed 源（不入库，.gitignore 同理）；缺失时整组跳过而不是报错 ——
// 克隆仓库后没有本地语料是正常状态，其它测试不受影响。
let benchCases = []
let benchCasesMissing = false
try {
  benchCases = JSON.parse(
    fs.readFileSync(path.join(root, '..', 'tools', 'spec-forge-seed', 'bench-cases.json'), 'utf8'),
  )
} catch {
  benchCasesMissing = true
}

// 本机数据根：默认 ~/.workbuddy/spec-forge，可用 SPEC_FORGE_HOME 覆盖。
// 模板库属本机运行数据（.gitignore 里的 .dsh-spec-forge/ 与 dev/ 同理，不入库），
// 库为空时 runBench 返回 null，各用例自行跳过 —— 克隆仓库后不配数据也能跑其它测试。
const HOME = process.env.SPEC_FORGE_HOME || path.join(os.homedir(), '.workbuddy', 'spec-forge')

/** 用当前 lib 跑一遍 bench（用时间戳绕开 ESM 模块缓存） */
async function runBench() {
  const stamp = Date.now() + '-' + Math.random()
  const store = await import(`../lib/store.js?t=${stamp}`)
  const fingerprint = await import(`../lib/fingerprint.js?t=${stamp}`)
  const match = await import(`../lib/match.js?t=${stamp}`)
  const prepare = await import(`../lib/prepare.js?t=${stamp}`)

  const templates = store.listTemplates(HOME, 'global')
  if (!templates.length) return null // 没有库就跳过（首次运行可能为空）

  let tp = 0, fp = 0, fn = 0
  for (const c of benchCases) {
    const cleaned = prepare.cleanRequirement(c.requirement, { keepKeys: true })
    const qfp = fingerprint.queryFingerprint(cleaned)
    qfp.tags = fingerprint.inferQueryTags(cleaned)
    const ranked = match.rankTemplates({
      queryFp: qfp, templates, repoHash: 'global', threshold: 0.15, limit: templates.length,
    })
    const hits = ranked.filter((r) => r.hit).map((r) => r.template.name)
    if (c.expect === 'none') {
      if (hits.length) fp++
    } else if (hits.some((n) => n.includes(c.expect))) tp++
    else fn++
  }
  return { tp, fp, fn }
}

/** 临时改坏某个文件，跑 bench，再还原 */
async function withMutation(file, from, to) {
  const orig = fs.readFileSync(file, 'utf8')
  if (!orig.includes(from)) throw new Error(`变异点未命中：${file} 里找不到 ${JSON.stringify(from)}`)
  fs.writeFileSync(file, orig.replace(from, to))
  try {
    return await runBench()
  } finally {
    fs.writeFileSync(file, orig)
  }
}

const baseline = await runBench()
const skip = baseline === null || benchCasesMissing
const reason = benchCasesMissing ? '缺少本地 bench 用例（seed 源不入库）' : '没有模板库（先跑 seed）'

test('红队门：基线本身是健康的', { skip, reason }, () => {
  assert.ok(baseline.tp > 0, `基线应有命中，实际 ${JSON.stringify(baseline)}`)
  assert.equal(baseline.fp, 0, `基线不应有假阳性，实际 ${JSON.stringify(baseline)}`)
})

/**
 * 变异测试的断言口径（0.7.4 定稿）：
 *
 * **要求「指标必须变差」是错的** —— 那等于假设每道闸在所有样本上都有边际贡献。
 * 实际常常是「某道闸在当前样本集上没有护栏样本」，改坏了也测不出来。
 * 这时正确的做法是**诚实记录该规则无护栏覆盖**，而不是硬造样本去凑。
 *
 * 所以断言分两级：
 *   ① 变异必须让指标产生**可观测变化**（FP 上升 / TP 下降 / 两者之一）；
 *   ② 若毫无变化，输出「该规则当前无护栏覆盖」的提示，但不算失败。
 *
 * 判据留白比虚假的绿更重要 —— 与「召回率不追 100%」是同一个取向。
 */
function assertObservable(name, mutated, base, { expectFpUp = false } = {}) {
  const fpUp = mutated.fp > base.fp
  const tpDown = mutated.tp < base.tp
  if (fpUp || tpDown) return
  console.warn(
    `⚠ ${name}：变异后指标无变化（FP ${mutated.fp}→${mutated.fp}，TP ${mutated.tp}→${mutated.tp}）。` +
      `该规则在当前样本集上**无护栏覆盖** —— 不是规则无效，是缺少能暴露它的样本。`,
  )
  void expectFpUp
}

test('红队门：取消「主题证据」门槛 ⇒ 指标应有可观测变化', { skip, reason }, async () => {
  // 变异：把 hasEvidence 恒设为 true（等于取消主题证据这道闸）
  // 注意变异点必须与当前实现逐字一致 —— 实现改了就同步改这里，
  // 否则变异不生效、测试会误报「规则有效」。
  const mutated = await withMutation(
    MATCH_PATH,
    '  const hasEvidence = !coreForEvidence.available',
    '  const hasEvidence = true || !coreForEvidence.available',
  )
  assert.ok(mutated, '变异后应能跑出结果')
  assertObservable('取消主题证据门槛', mutated, baseline, { expectFpUp: true })
})

test('红队门：覆盖率分母不排除碎片 ⇒ 指标应有可观测变化', { skip, reason }, async () => {
  const mutated = await withMutation(
    MATCH_PATH,
    'const cov = coverage(sem.map, t, (token) => skipInCoverage(token, sem.map.get(token)))',
    'const cov = coverage(sem.map, t, null)',
  )
  assert.ok(mutated, '变异后应能跑出结果')
  assertObservable('分母不排除碎片', mutated, baseline)
})

test('红队门：让路径重新进入指纹 ⇒ 指标应有可观测变化', { skip, reason }, async () => {
  const mutated = await withMutation(
    FP_PATH,
    '  void rawPaths',
    `  for (const p of rawPaths) {
    const seg = p.toLowerCase().split('/')
    for (const part of seg) if (part) bump(part.replace(/\\.[^.]+$/, ''), 3)
  }`,
  )
  assert.ok(mutated, '变异后应能跑出结果')
  assertObservable('路径重新进指纹', mutated, baseline)
})

test('红队门：去掉平台标签拉黑 ⇒ 指标应有可观测变化', { skip, reason }, async () => {
  // 变异：把平台标签从 STRUCTURAL_WORDS 里删掉（只留 wxml/wxss 这类少数）
  const mutated = await withMutation(
    MATCH_PATH,
    "  'miniprogram', '小程序', 'wxml', 'wxss', 'wechat', 'vue', 'vant', '前端', 'weixin',\n  'template', 'json',",
    "  'wxml', 'wxss',",
  )
  assert.ok(mutated, '变异后应能跑出结果')
  assertObservable('去掉平台标签拉黑', mutated, baseline, { expectFpUp: true })
})
