"""麦克风自检：一眼看出 DSH 到底会用哪只麦、有没有声音。
  python mic_check.py          只看状态
  python mic_check.py --test   顺带录 2 秒测信号（这时候要说话）
"""
import sys, json, argparse
sys.stdout.reconfigure(encoding="utf-8")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--test", action="store_true"); a = ap.parse_args()
    out = {}
    # 1) 系统默认麦克风 + 静音/音量
    try:
        import comtypes
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        ptr = AudioUtilities.GetMicrophone()
        out["默认麦克风"] = AudioUtilities.CreateDevice(ptr).FriendlyName
        vol = ptr.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None).QueryInterface(IAudioEndpointVolume)
        out["静音"] = bool(vol.GetMute()); out["音量%"] = round(vol.GetMasterVolumeLevelScalar() * 100, 1)
    except Exception as e:
        out["默认麦克风"] = f"读取失败 {type(e).__name__}"
    # 2) 浏览器（Edge）记忆的麦克风偏好
    import os, json as J
    p = os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Preferences")
    try:
        d = J.load(open(p, encoding="utf-8"))
        rank = d.get("media", {}).get("audio_input", {}).get("user_preference_ranking", [])
        out["Edge记忆排序"] = rank[:3] if rank else "（空，跟随系统默认 ← 正常）"
    except Exception as e:
        out["Edge记忆排序"] = f"读取失败 {type(e).__name__}"
    # 3) 真实录音信号
    if a.test:
        try:
            import numpy as np, sounddevice as sd
            dev = sd.query_devices(kind="input")
            sr = int(dev["default_samplerate"]); ch = min(2, dev["max_input_channels"])
            rec = sd.rec(int(sr * 2), samplerate=sr, channels=ch, dtype="float32"); sd.wait()
            out["实测信号"] = round(float(np.abs(rec).max()), 4)
            out["判定"] = "有声音 ✓" if np.abs(rec).max() > 0.01 else "几乎无声（可能没说话，或选错设备）"
        except Exception as e:
            out["实测信号"] = f"失败 {type(e).__name__}"
    print(json.dumps(out, ensure_ascii=False, indent=1))
    if out.get("默认麦克风", "").find("MIXLINE") >= 0 or str(out.get("Edge记忆排序", "")).find("MIXLINE") >= 0:
        print("\n⚠ 有虚拟麦克风(MIXLINE/VB-Audio)混在里面，DSH 可能选到空设备")

if __name__ == "__main__":
    main()
