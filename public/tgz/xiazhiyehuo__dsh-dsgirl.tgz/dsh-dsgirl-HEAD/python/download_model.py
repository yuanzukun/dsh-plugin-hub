"""下载 whisper 模型到插件目录（带断点续传，适合国内网络）。
用法:
  python download_model.py            # 默认 base 模型
  python download_model.py --size small
  python download_model.py --mirror https://hf-mirror.com
"""
import argparse, os, sys, urllib.request, time

SIZES = {"base": "Systran/faster-whisper-base", "small": "Systran/faster-whisper-small"}
FILES = ["config.json", "tokenizer.json", "vocabulary.txt", "model.bin"]

def size_of(url):
    req = urllib.request.Request(url, method="HEAD")
    with urllib.request.urlopen(req, timeout=30) as r:
        return int(r.headers.get("content-length", 0))

def fetch(url, dest, tries=60):
    total = size_of(url)
    for i in range(tries):
        have = os.path.getsize(dest) if os.path.exists(dest) else 0
        if total and have >= total:
            return have
        headers = {"User-Agent": "dsh-dsgirl/0.1"}
        if have:
            headers["Range"] = "bytes=%d-" % have
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=60) as r, open(dest, "ab") as f:
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk:
                        break
                    f.write(chunk)
        except Exception as e:
            print("  中断重试(%d): %s" % (i + 1, type(e).__name__))
            time.sleep(1)
    return os.path.getsize(dest) if os.path.exists(dest) else 0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", default="base", choices=list(SIZES))
    ap.add_argument("--mirror", default="https://huggingface.co")
    ap.add_argument("--dir", default="")
    a = ap.parse_args()

    root = a.dir or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")
    dest = os.path.join(root, "fw-" + a.size)
    os.makedirs(dest, exist_ok=True)
    repo = SIZES[a.size]
    print("模型: %s -> %s" % (repo, dest))
    for f in FILES:
        url = "%s/%s/resolve/main/%s" % (a.mirror, repo, f)
        path = os.path.join(dest, f)
        got = fetch(url, path)
        print("  %-16s %10d bytes" % (f, got))
    print("完成。")

if __name__ == "__main__":
    main()
