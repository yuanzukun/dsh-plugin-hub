"""hear —— 让我听见系统正在播放的声音。
  python hear.py                 从环形缓冲取最近 5 秒（推荐，不漏开头）
  python hear.py -s 8            取最近 8 秒
  python hear.py -f a.wav        转写已有文件
  python hear.py -l ja           指定语言(zh/ja/en/auto)
  python hear.py --fresh         不用缓冲，现场录（会漏开头）
输出一行 JSON。
"""
import sys, os, io, json, time, wave, argparse, urllib.request
import numpy as np
sys.stdout.reconfigure(encoding="utf-8"); sys.stderr.reconfigure(encoding="utf-8")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sonic import analyze as sonic_analyze
from faster_whisper import WhisperModel

BASE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(BASE)                      # 插件仓库根目录
MODEL_DIR = os.environ.get("DSGIRL_MODEL_DIR") or os.path.join(PKG, "models")
OUT = os.environ.get("DSGIRL_OUT_DIR") or os.path.join(PKG, "heard")
os.makedirs(OUT, exist_ok=True)
RING = "http://127.0.0.1:7317"
_model = {}

def model(size="base"):
    if size not in _model:
        _model[size] = WhisperModel(os.path.join(MODEL_DIR, f"fw-{size}"),
                                    device="cpu", compute_type="int8", cpu_threads=8)
    return _model[size]

def resample(mono, sr, target=16000):
    mono = np.asarray(mono, dtype=np.float32)
    if mono.ndim == 2: mono = mono.mean(axis=1)
    if sr == target: return mono
    idx = np.linspace(0, len(mono) - 1, int(len(mono) * target / sr))
    return np.interp(idx, np.arange(len(mono)), mono).astype(np.float32)

def read_wav_bytes(b):
    w = wave.open(io.BytesIO(b)); sr = w.getframerate(); ch = w.getnchannels()
    d = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    if ch == 2: d = d.reshape(-1, 2).mean(axis=1)
    return d, sr

def from_ring(seconds):
    with urllib.request.urlopen(f"{RING}/take?seconds={seconds}", timeout=10) as r:
        raw = r.read()
    d, sr = read_wav_bytes(raw)
    return resample(d, sr), f"ring({seconds}s)"

def fresh(seconds):
    import soundcard as sc
    spk = sc.default_speaker()
    mic = sc.get_microphone(spk.name, include_loopback=True)
    with mic.recorder(samplerate=48000) as rec:
        d = rec.record(numframes=int(48000 * seconds))
    return resample(d, 48000), spk.name

def save(mono):
    stamp = time.strftime("%Y%m%d-%H%M%S")
    p = os.path.join(OUT, f"hear-{stamp}.wav")
    pcm = (np.clip(mono, -1, 1) * 32767).astype(np.int16)
    with wave.open(p, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000); w.writeframes(pcm.tobytes())
    return p

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-s", "--seconds", type=float, default=5.0)
    ap.add_argument("-f", "--file"); ap.add_argument("-l", "--lang", default="auto")
    ap.add_argument("--fresh", action="store_true"); ap.add_argument("--model", default="base")
    a = ap.parse_args()
    t0 = time.time()
    try:
        if a.file:
            mono, src = read_wav_bytes(open(a.file, "rb").read()); mono = resample(mono, 16000); name = "file:" + os.path.basename(a.file)
        elif a.fresh:
            mono, name = fresh(a.seconds); save(mono)
        else:
            mono, name = from_ring(a.seconds); save(mono)
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"{type(e).__name__}: {e}",
                          "hint": "环形服务没在跑就先用 --fresh，或者启动 python ring.py"}, ensure_ascii=False)); return

    rms = float(np.sqrt((mono.astype(np.float64) ** 2).mean())) if len(mono) else 0.0
    peak = float(np.abs(mono).max()) if len(mono) else 0.0
    res = {"ok": True, "source": name, "duration": round(len(mono) / 16000, 2),
           "rms": round(rms, 5), "peak": round(peak, 3), "silent": False,
           "text": "", "lang": None, "model": a.model, "sonic": sonic_analyze(mono) if len(mono) else {}}
    if peak < 0.003:
        res.update(silent=True, note="没听到声音")
    else:
        t1 = time.time()
        segs, info = model(a.model).transcribe(mono, language=None if a.lang == "auto" else a.lang,
                                               beam_size=5, vad_filter=True,
                                               vad_parameters=dict(min_silence_duration_ms=400))
        parts = [s.text.strip() for s in segs if s.no_speech_prob < 0.6]
        res.update(text="".join(parts).strip(), lang=info.language, cost_s=round(time.time() - t1, 2))
        if not res["text"]:
            res["note"] = "有声音但不是人话（BGM/音效）"
    res["total_s"] = round(time.time() - t0, 2)
    print(json.dumps(res, ensure_ascii=False))
    if res.get("text"): print("听到:", res["text"], file=sys.stderr)

if __name__ == "__main__":
    main()
