"""把一段音频说成我能读懂的话：响度、亮度、节奏、像不像人声。"""
import numpy as np

def analyze(mono, sr=16000):
    d = np.asarray(mono, dtype=np.float32)
    if len(d) < sr // 2:
        return {"note": "太短"}
    # 分帧 RMS 包络
    hop = int(sr * 0.05)
    frames = len(d) // hop
    env = np.array([np.sqrt((d[i*hop:(i+1)*hop] ** 2).mean()) for i in range(frames)])
    # 频谱质心（亮度）
    win = d[:min(len(d), sr*4)] * np.hanning(min(len(d), sr*4))
    spec = np.abs(np.fft.rfft(win))
    freqs = np.fft.rfftfreq(len(win), 1/sr)
    centroid = float((spec * freqs).sum() / (spec.sum() + 1e-9))
    # 过零率（越高越"嘶/噪"）
    zcr = float((np.abs(np.diff(np.sign(d))) > 0).mean())
    # 节奏：包络自相关找 60~180 BPM
    e = env - env.mean()
    ac = np.correlate(e, e, mode="full")[len(e)-1:]
    ac = ac / (ac[0] + 1e-9)
    bpm, beat_strength = None, 0.0
    lo, hi = int(60/180/0.05), int(60/60/0.05)
    if hi < len(ac):
        seg = ac[lo:hi]
        k = int(np.argmax(seg)) + lo
        beat_strength = float(seg.max())
        bpm = round(60.0 / (k * 0.05), 1)
    # 人声感：中频占比 + 包络起伏
    band = (freqs > 200) & (freqs < 3500)
    mid_ratio = float(spec[band].sum() / (spec.sum() + 1e-9))
    steadiness = float(env.std() / (env.mean() + 1e-9))
    voicey = mid_ratio > 0.55 and 0.25 < steadiness < 1.6
    return {
        "loudness_db": round(float(20*np.log10(env.mean()+1e-9)), 1),
        "dynamics": round(steadiness, 2),
        "brightness_hz": round(centroid),
        "noisiness": round(zcr, 4),
        "bpm": bpm, "beat_strength": round(beat_strength, 2),
        "mid_ratio": round(mid_ratio, 2),
        "sounds_like": "人声/对白" if voicey else ("有节奏的音乐" if beat_strength > 0.35 else "环境音或音效"),
        "description": _describe(centroid, bpm, beat_strength, steadiness, voicey)
    }

def _describe(centroid, bpm, beat, dyn, voicey):
    parts = []
    parts.append("偏亮" if centroid > 2500 else ("偏闷" if centroid < 800 else "中频为主"))
    if beat > 0.35 and bpm: parts.append(f"有节拍，约{bpm}BPM")
    if dyn > 1.2: parts.append("起伏很大")
    elif dyn < 0.2: parts.append("很平")
    if voicey: parts.append("像人在说话")
    return "，".join(parts)
