"""ring —— 一直听着，只留最近 30 秒。
启动: python ring.py          停止: 访问 /stop
接口: GET /take?seconds=8     取最近 N 秒的 wav
      GET /status             状态
"""
import sys, io, json, time, wave, threading
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import numpy as np
import soundcard as sc

sys.stdout.reconfigure(encoding="utf-8")
SR = 48000
BLOCK = 4800          # 0.1 秒
MAX_SEC = 30
ring = deque(maxlen=int(MAX_SEC * SR / BLOCK))
lock = threading.Lock()
stats = {"device": "", "running": True, "started": time.time(), "peak": 0.0, "blocks": 0,
         "reconnects": 0, "error": None, "exited_at": None}
running = threading.Event(); running.set()
capture_thread = None

def _open_recorder():
    """按当前默认扬声器打开 loopback 采集，返回 (recorder, 设备名)；失败抛异常。"""
    spk = sc.default_speaker()
    mic = sc.get_microphone(spk.name, include_loopback=True)
    rec = mic.recorder(samplerate=SR, blocksize=BLOCK)
    rec.__enter__()
    return rec, spk.name

def capture():
    retried = False
    try:
        rec, stats["device"] = _open_recorder()
    except Exception as e:
        stats["error"] = f"{type(e).__name__}: {e}"
        stats["running"] = False
        stats["exited_at"] = time.time()
        return
    try:
        while running.is_set():
            try:
                block = rec.record(numframes=BLOCK)
                retried = False  # 采到数据后重置重连机会
            except Exception as e:
                # 设备失效（如 WASAPI 0x88890004）：先原地重连一次，失败才真正退出
                err = f"{type(e).__name__}: {e}"
                if retried or not running.is_set():
                    stats["error"] = err
                    break
                retried = True
                try:
                    new_rec, name = _open_recorder()
                except Exception as e2:
                    stats["error"] = f"{err}；重连失败: {type(e2).__name__}: {e2}"
                    break
                try:
                    rec.__exit__(None, None, None)
                except Exception:
                    pass
                rec, stats["device"] = new_rec, name
                stats["reconnects"] += 1
                stats["last_reconnect"] = {"time": time.time(), "cause": err}
                continue
            with lock:
                ring.append(block)
                stats["blocks"] += 1
                stats["peak"] = float(np.abs(block).max())
            # 重新获取默认设备（用户换耳机时自动跟上）
            if stats["blocks"] % 200 == 0:
                try:
                    cur = sc.default_speaker().name
                    if cur != stats["device"]:
                        stats["device"] = cur
                        mic = sc.get_microphone(cur, include_loopback=True)
                        rec.__exit__(None, None, None)
                        rec = mic.recorder(samplerate=SR, blocksize=BLOCK)
                        rec.__enter__()
                except Exception:
                    pass
    finally:
        try:
            rec.__exit__(None, None, None)
        except Exception:
            pass
        stats["running"] = False
        stats["exited_at"] = time.time()

def take(seconds):
    with lock:
        n = min(len(ring), int(seconds * SR / BLOCK))
        blocks = list(ring)[-n:] if n else []
    if not blocks:
        return np.zeros(0, dtype=np.float32)
    return np.concatenate(blocks, axis=0)

def wav_bytes(arr):
    if arr.ndim == 2:
        arr = arr.mean(axis=1)
    pcm = (np.clip(arr, -1, 1) * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    return buf.getvalue()

class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass
    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/take":
            sec = float(parse_qs(u.query).get("seconds", ["8"])[0])
            data = wav_bytes(take(sec))
            self.send_response(200)
            self.send_header("content-type", "audio/wav")
            self.send_header("content-length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif u.path == "/status":
            with lock:
                filled = len(ring) * BLOCK / SR
            alive = bool(stats["running"]) and (capture_thread is None or capture_thread.is_alive())
            body = json.dumps({**stats, "alive": alive, "buffered_s": round(filled, 1), "uptime_s": round(time.time() - stats["started"])}, ensure_ascii=False).encode()
            self.send_response(200); self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(body))); self.end_headers()
            self.wfile.write(body)
        elif u.path == "/stop":
            running.clear()
            body = b'{"ok":true}'
            self.send_response(200); self.send_header("content-length", str(len(body))); self.end_headers()
            self.wfile.write(body)
            threading.Timer(0.3, lambda: self.server.shutdown()).start()
        else:
            self.send_response(404); self.end_headers()

if __name__ == "__main__":
    capture_thread = threading.Thread(target=capture, daemon=True)
    capture_thread.start()
    time.sleep(0.5)
    srv = ThreadingHTTPServer(("127.0.0.1", 7317), H)
    print(json.dumps({"ok": True, "port": 7317, "device": stats["device"]}, ensure_ascii=False), flush=True)
    srv.serve_forever()
