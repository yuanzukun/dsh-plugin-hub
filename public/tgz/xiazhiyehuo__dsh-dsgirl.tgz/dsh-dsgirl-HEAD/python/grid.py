"""给截图叠坐标网格，让"目测"变成"读刻度"。
用法: python grid.py in.png out.png [step]
"""
import sys, os
from PIL import Image, ImageDraw, ImageFont

def font(size=15):
    for p in (r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\consola.ttf", r"C:\Windows\Fonts\arial.ttf"):
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()

def overlay(src, dst, step=100):
    im = Image.open(src).convert("RGB")
    d = ImageDraw.Draw(im, "RGBA")
    w, h = im.size
    f = font(15)

    for x in range(0, w, step):
        major = (x % (step * 5) == 0)
        d.line([(x, 0), (x, h)], fill=(255, 64, 64, 110 if major else 55), width=2 if major else 1)
    for y in range(0, h, step):
        major = (y % (step * 5) == 0)
        d.line([(0, y), (w, y)], fill=(64, 255, 255, 110 if major else 55), width=2 if major else 1)

    # 刻度：顶部标 x，左侧标 y，带半透明底衬，保证在亮暗背景上都看得清
    pad = 3
    for x in range(0, w, step * 5):
        label = str(x)
        tw = d.textlength(label, font=f)
        d.rectangle([x + 2, 2, x + 6 + tw, 2 + 19], fill=(0, 0, 0, 170))
        d.text((x + 4, 3), label, fill=(255, 210, 210), font=f)
    for y in range(0, h, step * 5):
        label = str(y)
        tw = d.textlength(label, font=f)
        d.rectangle([2, y + 2, 6 + tw, y + 2 + 19], fill=(0, 0, 0, 170))
        d.text((4, y + 3), label, fill=(190, 255, 255), font=f)
    im.save(dst, quality=92)
    return dst

if __name__ == "__main__":
    src = sys.argv[1]
    dst = sys.argv[2] if len(sys.argv) > 2 else src.replace(".png", "-grid.png")
    step = int(sys.argv[3]) if len(sys.argv) > 3 else 100
    out = overlay(src, dst, step)
    print(out)
