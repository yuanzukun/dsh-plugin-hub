"""模拟 WASAPI 0x88890004 设备失效，验证 ring 的死亡可见性与重连。
场景A: record 抛错一次 -> 自动重连成功 -> 继续采集
场景B: record 抛错且重连也失败 -> running/alive 变 false, error 记录原因
"""
import json, time, threading
import numpy as np
import ring

WASAPI_ERR = "OSError: [Errno -2004287484] WASAPI Error 0x88890004: AUDCLNT_E_DEVICE_INVALIDATED"

class FakeRec:
    def __init__(self, mode):
        self.mode = mode  # "die"=record 抛设备失效; "ok"=正常出数据
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def record(self, numframes=ring.BLOCK):
        if self.mode == "die":
            raise OSError(WASAPI_ERR)
        return np.random.randn(numframes, 2).astype(np.float32) * 0.1

def run_capture_with(open_recorder):
    """替换 _open_recorder 后跑 capture 线程，返回线程对象。"""
    ring._open_recorder = open_recorder
    ring.stats.update({"running": True, "error": None, "exited_at": None, "reconnects": 0, "blocks": 0})
    ring.running.set()
    t = threading.Thread(target=ring.capture, daemon=True)
    ring.capture_thread = t
    t.start()
    return t

# ---------- 场景 A：死一次，重连复活 ----------
state = {"opened": 0}
def open_then_recover():
    state["opened"] += 1
    return (FakeRec("die") if state["opened"] == 1 else FakeRec("ok")), "FakeSpeaker"

t = run_capture_with(open_then_recover)
time.sleep(1.0)
print("=== 场景A：设备失效一次后自动重连 ===")
print(json.dumps({k: ring.stats[k] for k in ("running", "reconnects", "error", "blocks")}, ensure_ascii=False))
print("thread.is_alive():", t.is_alive())
assert ring.stats["running"] is True and ring.stats["reconnects"] == 1 and t.is_alive()
ring.running.clear(); t.join(timeout=2)

# ---------- 场景 B：失效且重连也失败 -> 真实死亡 ----------
def open_always_die():
    raise OSError(WASAPI_ERR)  # 重连时连设备都打不开

def open_first_then_die():
    # 第一次打开成功（但 record 会抛），之后重连打开失败
    if run_capture_with.first:
        run_capture_with.first = False
        return FakeRec("die"), "FakeSpeaker"
    raise OSError(WASAPI_ERR)
run_capture_with.first = True

t = run_capture_with(open_first_then_die)
t.join(timeout=3)
print("\n=== 场景B：设备失效且重连失败 ===")
print(json.dumps({k: ring.stats[k] for k in ("running", "reconnects", "error", "exited_at")}, ensure_ascii=False))
print("thread.is_alive():", t.is_alive())
assert ring.stats["running"] is False and t.is_alive() is False
assert "0x88890004" in ring.stats["error"] and ring.stats["exited_at"]

# ---------- 用真 HTTP /status 验证对外可见 ----------
from http.server import ThreadingHTTPServer
srv = ThreadingHTTPServer(("127.0.0.1", 7318), ring.H)
threading.Thread(target=srv.serve_forever, daemon=True).start()
time.sleep(0.3)
import urllib.request
body = urllib.request.urlopen("http://127.0.0.1:7318/status").read().decode()
print("\n=== 死亡后 GET /status（端口7318） ===")
print(body)
d = json.loads(body)
assert d["running"] is False and d["alive"] is False and "0x88890004" in d["error"]
srv.shutdown()
print("\nALL ASSERTIONS PASSED")
