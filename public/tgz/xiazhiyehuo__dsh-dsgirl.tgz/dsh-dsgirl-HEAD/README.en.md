# dsh-dsgirl

Ears, eyes and hands for DeepSeek Harness: hear what the machine is playing, see the screen, and operate the desktop.

Windows only (audio capture goes through WASAPI). CPU only, no GPU needed.

## Tools

| Tool | What it does |
|---|---|
| `hear` | Capture the last N seconds of audio, transcribe it, classify speech / music / ambience / silence, with loudness and BPM |
| `mic_status` | Microphone self-check: default device, mute state, volume, whether something else holds it |
| `see` | Screenshot into the model's view, optional coordinate grid overlay |
| `game_state` | Read game state: scene, map, position, HP, gold, current dialogue |
| `game_press` | Press game keys: confirm / cancel / menu / arrows |
| `game_move` | Walk the character N steps, returns tiles actually moved |

`game_*` needs the game side: drop `gamebridge/GameBridge.js` into the game's `js/plugins/`, register it in `js/plugins.js`. The game then serves a local endpoint on `127.0.0.1:7311`.

## Install

**1. Install the plugin**

```bash
dsh plugin --profile web add github:xiazhiyehuo/dsh-dsgirl
```

Or by hand: add `"dsh-dsgirl": "link:<repo path>"` to `dependencies` and `"dsh-dsgirl"` to `dsh.profile.bundles` in the profile's `package.json`, then `pnpm install`.

**2. Python deps + model**

Run `scripts/setup.bat`, or manually:

```bash
python -m pip install numpy sounddevice soundcard faster-whisper scipy
python python/download_model.py --size base
```

The model (~145 MB, faster-whisper-base) is not in the repo and is downloaded on first run. Behind a slow link add `--mirror https://hf-mirror.com`.

**3. Restart DSH.** The tools appear.

## Configuration

In `cordis.yml`:

```yaml
- id: dsh-dsgirl
  name: 'dsh-dsgirl'
  inject: [tools]
  config:
    python: 'C:/Path/To/python.exe'   # empty = python from PATH
    toolsDir: ''                       # empty = python/ inside the repo
```

Environment: `DSGIRL_MODEL_DIR` for the model directory, `DSGIRL_OUT_DIR` for audio archives.

## Two ways to listen

- **ring (recommended)**: keep `python/ring.py` running; it always holds the last 30 seconds, so `hear` never misses the start of a sentence.
- **fresh**: record N seconds on demand. Simpler, but starts half a beat late and loses the first word or two.

## Requirements

Windows + Python 3.10+ + `numpy sounddevice soundcard faster-whisper scipy`.
About 1.5 s to transcribe 5 s of audio on a 20-core CPU.

## Known limits

- Loopback capture only covers what the system is **currently playing**; for a single file use `source: file`.
- Music overlapping speech noticeably hurts accuracy.
- The base model is fine for everyday Chinese; strong accents, fast speech and jargon will be wrong. Use `--size small` (~483 MB, ~3x slower) for better accuracy.
- It is not true hearing: audio becomes text, so melody and mood survive only as numeric features.

## License

MIT
