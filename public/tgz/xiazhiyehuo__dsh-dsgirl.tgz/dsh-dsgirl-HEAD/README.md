# dsh-dsgirl

给 DeepSeek Harness 装上**耳朵、眼睛和手**：听见系统在放什么声音、看见屏幕、替你在电脑上点按。

Windows 专用（音频采集走 WASAPI），纯 CPU 跑，不需要显卡。

## 能力

| 工具 | 作用 |
|---|---|
| `hear` | 截取最近 N 秒声音转成文字，并判断"人说话 / 音乐 / 环境音 / 静音"，附带响度、BPM |
| `mic_status` | 麦克风自检：默认设备、是否静音、音量、是否被别的软件占用 |
| `see` | 截屏作为图片送进模型视野，可选坐标网格叠加 |
| `game_state` | 读游戏状态：场景、地图、坐标、血量、金币、当前对话 |
| `game_press` | 替玩家按键：确认 / 取消 / 菜单 / 方向键 |
| `game_move` | 让角色走几步，返回实际移动格数 |

`game_*` 需要游戏侧配合：把 `gamebridge/GameBridge.js` 放进游戏的 `js/plugins/`，在 `js/plugins.js` 注册一行。游戏启动后会在 `127.0.0.1:7311` 开一个本地接口。

`hear` 返回示例：

```json
{
  "ok": true, "source": "ring(5s)", "duration": 5.0,
  "text": "听得清楚吗", "lang": "zh",
  "sonic": { "loudness_db": -30.6, "bpm": 80.0, "sounds_like": "人声/对白" }
}
```

## 安装

**1. 装插件**

```bash
dsh plugin --profile web add github:xiazhiyehuo/dsh-dsgirl
```

或手工：profile 的 `package.json` 里 `dependencies` 加 `"dsh-dsgirl": "link:<仓库路径>"`、`dsh.profile.bundles` 加 `"dsh-dsgirl"`，然后 `pnpm install`。

**2. Python 依赖 + 模型**

双击 `scripts/setup.bat`，或手动：

```bash
python -m pip install numpy sounddevice soundcard faster-whisper scipy
python python/download_model.py --size base
```

模型约 145MB（faster-whisper-base），不进仓库，首次由脚本下载。国内网络加 `--mirror https://hf-mirror.com`。

**3. 重启 DSH**，工具出现。

## 配置

`cordis.yml` 的插件行：

```yaml
- id: dsh-dsgirl
  name: 'dsh-dsgirl'
  inject: [tools]
  config:
    python: 'C:/Path/To/python.exe'   # 留空用 PATH 里的 python
    toolsDir: ''                       # 留空用仓库内 python/
```

环境变量：`DSGIRL_MODEL_DIR` 指定模型目录，`DSGIRL_OUT_DIR` 指定录音存档目录。

## 两种听法

- **ring（推荐）**：常驻 `python/ring.py`，一直录着最近 30 秒，`hear` 往回取，不会漏掉句子开头。
- **fresh**：现场录 N 秒，简单，但启动慢半拍，头一两个字容易丢。

## 依赖

Windows + Python 3.10+ + `numpy sounddevice soundcard faster-whisper scipy`。
20 核 CPU 上 5 秒音频约 1.5 秒转完。

## 已知限制

- 回环采集只对**系统正在播放**的声音生效；单个音频文件请用 `source: file`。
- BGM 和人声混在一起时识别率明显下降。
- base 模型中文日常对话够用，口音重、语速快、专业词会错。要更准换 `--size small`（约 483MB，慢三倍）。
- 不是"真听觉"：声音被翻译成文字，旋律和情绪只能靠特征数值描述。

## License

MIT
