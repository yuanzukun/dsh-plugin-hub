/*:
 * @target MZ
 * @plugindesc v1.0 本地桥：让外部程序读取游戏状态、代为按键
 * @author dsh-dsgirl
 *
 * @help
 * 启动游戏后监听 http://127.0.0.1:7311
 *   GET  /state                    读当前状态（场景/地图/坐标/队伍/对话）
 *   POST /press  {"key":"ok"}      模拟按键：ok cancel menu up down left right
 *   POST /move   {"dir":"down","steps":2}   直接走几步
 *   GET  /ping                     存活检查
 *
 * 只在 nw.js 环境生效，浏览器里自动跳过。
 */
(() => {
  if (typeof require !== 'function') return;
  let http;
  try { http = require('http'); } catch (e) { return; }

  const PORT = 7311;
  const KEYMAP = { ok: 90, cancel: 27, menu: 88, up: 38, down: 40, left: 37, right: 39 };
  const DIRMAP = { down: 2, left: 4, right: 6, up: 8 };

  function snapshot() {
    const out = { ok: true, scene: null, map: null, player: null, party: [], message: [], gold: 0 };
    try {
      out.scene = SceneManager._scene ? SceneManager._scene.constructor.name : null;
      if (typeof $gameMap !== 'undefined' && $gameMap && typeof $gamePlayer !== 'undefined' && $gamePlayer) {
        out.map = { id: $gameMap.mapId(), name: window.$dataMap ? $dataMap.displayName : '' };
        out.player = { x: $gamePlayer.x, y: $gamePlayer.y, dir: $gamePlayer.direction() };
      }
      if (typeof $gameParty !== 'undefined' && $gameParty && $gameParty.members) {
        out.party = $gameParty.members().map((m) => ({
          name: m.name(), level: m.level, hp: m.hp, mhp: m.mhp, mp: m.mp, mmp: m.mmp,
        }));
        out.gold = $gameParty.gold ? $gameParty.gold() : 0;
      }
      if (typeof $gameMessage !== 'undefined' && $gameMessage && $gameMessage._texts) {
        out.message = $gameMessage._texts.filter((t) => t && String(t).trim().length);
      }
      out.busy = typeof $gameMap !== 'undefined' && $gameMap && $gameMap.isEventRunning ? $gameMap.isEventRunning() : false;
    } catch (e) {
      out.error = String(e);
    }
    return out;
  }

  function pressKey(name, ms) {
    if (typeof Input === 'undefined' || !Input._currentState) return false;
    const hold = ms || 120;
    try {
      /* 直接写 Input 状态机：KeyboardEvent 的 keyCode 在 Chromium 里是只读计算值，
         构造时传进去无效，游戏根本收不到。这里绕开事件层。 */
      Input._currentState[name] = true;
      Input._latestButton = name;
      Input._pressedTime = 0;
      setTimeout(() => {
        Input._currentState[name] = false;
        if (Input._latestButton === name) Input._latestButton = null;
      }, hold);
      return true;
    } catch (e) {
      return false;
    }
  }

  function moveStep(dir, steps) {
    const d = DIRMAP[dir];
    if (!d || typeof $gamePlayer === 'undefined') return 0;
    let n = 0;
    for (let i = 0; i < (steps || 1); i++) {
      if ($gamePlayer.canPass($gamePlayer.x, $gamePlayer.y, d)) {
        $gamePlayer.moveStraight(d);
        n++;
      } else break;
    }
    return n;
  }

  function body(req) {
    return new Promise((resolve) => {
      let raw = '';
      req.on('data', (c) => { raw += c; if (raw.length > 1e5) req.destroy(); });
      req.on('end', () => {
        try { resolve(JSON.parse(raw || '{}')); } catch (e) { resolve({}); }
      });
    });
  }

  function reply(res, obj) {
    const s = JSON.stringify(obj);
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
    res.end(s);
  }

  const server = http.createServer(async (req, res) => {
    const path = (req.url || '/').split('?')[0];
    if (path === '/ping') return reply(res, { ok: true, bridge: 'GameBridge', port: PORT });
    if (path === '/state') return reply(res, snapshot());
    if (path === '/press' && req.method === 'POST') {
      const b = await body(req);
      return reply(res, { ok: pressKey(b.key, b.ms), key: b.key });
    }
    if (path === '/move' && req.method === 'POST') {
      const b = await body(req);
      return reply(res, { ok: true, moved: moveStep(b.dir, b.steps) });
    }
    res.writeHead(404, { 'content-type': 'text/plain' });
    res.end('not found');
  });

  server.on('error', (e) => { console.warn('GameBridge: ' + e.message); });
  server.listen(PORT, '127.0.0.1', () => console.log('GameBridge listening on ' + PORT));
})();
