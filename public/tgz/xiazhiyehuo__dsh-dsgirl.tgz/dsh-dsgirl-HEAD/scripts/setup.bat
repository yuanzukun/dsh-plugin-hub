@echo off
chcp 65001 >nul
title dsh-dsgirl setup
echo ============================================
echo   dsh-dsgirl  setup
echo   1) install python deps   2) download model
echo ============================================
echo.
where python >nul 2>nul
if errorlevel 1 (
  echo [X] python not found in PATH. Install Python 3.10+ first.
  pause
  exit /b 1
)
echo [1/2] installing python packages...
python -m pip install --upgrade numpy sounddevice soundcard faster-whisper scipy
if errorlevel 1 (
  echo [!] pip failed. If you are behind a proxy, run this first:
  echo     set HTTPS_PROXY=http://127.0.0.1:PORT
)
echo.
echo [2/2] downloading whisper base model (about 145MB)...
python "%~dp0..\python\download_model.py" --size base
echo.
echo Done. Restart DSH to activate the tools.
pause
