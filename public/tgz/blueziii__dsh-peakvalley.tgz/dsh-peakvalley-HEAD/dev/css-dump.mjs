/**
 * 开发期小工具：把 client.js 真实生成的 CSS 落成 dev/_real.css，
 * 供无头探针页 dev/anim-real.html 直接引用——保证「测的」就是「线上那份」CSS，
 * 而不是手抄的副本。
 *
 * 用法：node dev/css-dump.mjs
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import vm from 'node:vm';

const here = path.dirname(fileURLToPath(import.meta.url));
const pkgDir = path.resolve(here, '..');
const clientSrc = readFileSync(path.join(pkgDir, 'client.js'), 'utf8');

// 只要 CSS，不需要真的渲染，所以 React 桩给最薄的实现即可。
const React = {
  Fragment: Symbol('react.fragment'),
  createElement: () => null,
  useState: (init) => [typeof init === 'function' ? init() : init, () => {}],
  useEffect: () => undefined,
  useRef: (initial) => ({ current: initial }),
};
let exportsObject = null;
const loader = {
  load(spec) {
    exportsObject = spec.factory((name) => {
      if (name === 'react') return React;
      if (name === 'react/jsx-runtime') {
        return { jsx: () => null, jsxs: () => null, Fragment: React.Fragment };
      }
      throw new Error('unexpected require("' + name + '")');
    });
  },
};

const previousWindow = globalThis.window;
globalThis.window = { __ModuleLoader__: loader };
try {
  vm.runInThisContext(clientSrc, { filename: 'client.js' });
} finally {
  if (previousWindow === undefined) delete globalThis.window;
  else globalThis.window = previousWindow;
}

const css = exportsObject && exportsObject.__peakvalley ? exportsObject.__peakvalley.CSS : null;
if (typeof css !== 'string' || css.length === 0) {
  console.error('未能取到 CSS');
  process.exit(1);
}

// 无头 Chrome 恒报 prefers-reduced-motion: reduce（本机 Windows 也关了动画），
// 所以再导一份「剥掉 reduce 分支」的 CSS，用来观察完整动效那条路径。
const mediaBlock = /@media \(prefers-reduced-motion:reduce\)\{[\s\S]*?\}\}/;
const cssFull = css.replace(mediaBlock, '');

writeFileSync(path.join(here, '_real.css'), css, 'utf8');
writeFileSync(path.join(here, '_real-full.css'), cssFull, 'utf8');
console.log('写入 dev/_real.css（' + css.length + ' 字符，含 reduce 分支）');
console.log('写入 dev/_real-full.css（' + cssFull.length + ' 字符，剥掉 reduce 分支）');
