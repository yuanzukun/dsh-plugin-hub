/**
 * dsh-peakvalley 本地校验脚本（仅开发期使用，不随包发布）。
 *
 * 覆盖范围（对应官方 references/verification.md 允许的上限）：
 *   1. 语法：用 vm 解析 client.js / index.js。
 *   2. manifest：package.json 与 cordis.patch.yml 的字段、id 一致性。
 *   3. bundle 契约：__ModuleLoader__.load 的 id 必须等于包名；apply 必须注册到
 *      conversation.composer.dock，且能拿到 t 与 modelStore。
 *   4. 逻辑：对 2026 年节假日、周末、边界分钟做真值表；nextSwitch / durationText
 *      （单位固定 d / h / m）。
 *   5. 组件：用极简 React 桩真实执行一次渲染，确认不抛错、tooltip 有内容。
 *   6. 模型可见性：非 DeepSeek 模型必须隐藏徽标；模型服务缺失/未知时照常显示。
 *   7. 约束：无 Harness Client 包 import；CSS 无 NaN；var() 仅用主题 token；
 *      根元素用 flex order 排到上下文圆环右侧。
 *
 * 用法：node dev/check.mjs
 */
import { readFileSync, statSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import vm from 'node:vm';

const here = path.dirname(fileURLToPath(import.meta.url));
const pkgDir = path.resolve(here, '..');

let passed = 0;
const failures = [];

function check(label, condition, detail) {
  if (condition) {
    passed += 1;
    return;
  }
  failures.push(label + (detail === undefined ? '' : ' -> ' + detail));
}

function group(title) {
  console.log('\n== ' + title + ' ==');
}

const readText = (rel) => readFileSync(path.join(pkgDir, rel), 'utf8');

// ------------------------------------------------------------------ 1. 语法

group('1. 语法');

const indexSrc = readText('index.js');
const clientSrc = readText('client.js');

// index.js 是真 ESM：直接动态 import 既验语法也验可加载性。
let indexOk = true;
let indexDetail = '';
try {
  await import(pathToFileURL(path.join(pkgDir, 'index.js')).href);
} catch (error) {
  indexOk = false;
  indexDetail = String(error && error.message);
}
check('语法与加载 index.js', indexOk, indexDetail);

// client.js 在浏览器里是经典脚本：用 vm.Script 按经典脚本解析。
let clientSyntaxOk = true;
let clientSyntaxDetail = '';
try {
  new vm.Script(clientSrc, { filename: 'client.js' });
} catch (error) {
  clientSyntaxOk = false;
  clientSyntaxDetail = String(error && error.message);
}
check('语法解析 client.js（经典脚本）', clientSyntaxOk, clientSyntaxDetail);

// --------------------------------------------------------------- 2. manifest

group('2. manifest');

const pkg = JSON.parse(readText('package.json'));
check('package.json name', typeof pkg.name === 'string' && pkg.name.length > 0, pkg.name);
check('package.json type=module', pkg.type === 'module', pkg.type);
check('exports[.] 存在', Boolean(pkg.exports && pkg.exports['.']), JSON.stringify(pkg.exports));
const exportValues = pkg.exports ? Object.values(pkg.exports) : [];
check('exports 含 ./package.json', exportValues.includes('./package.json'));
check('exports 含 ./locale/*.json', exportValues.includes('./locale/*.json'));
check(
  'exports 指向的文件都存在',
  exportValues
    .filter((value) => value.includes('*') === false)
    .every((value) => {
      try {
        statSync(path.join(pkgDir, value));
        return true;
      } catch {
        return false;
      }
    }),
);
check('dsh.bundle.patch 指向存在的文件', (() => {
  const patch = pkg.dsh && pkg.dsh.bundle && pkg.dsh.bundle.patch;
  if (typeof patch !== 'string') return false;
  try {
    statSync(path.join(pkgDir, patch));
    return true;
  } catch {
    return false;
  }
})());
check('dsh.client.platform=web', pkg.dsh && pkg.dsh.client && pkg.dsh.client.platform === 'web');
check(
  'dsh.client.inject 为宿主包数组',
  Array.isArray(pkg.dsh?.client?.inject) && pkg.dsh.client.inject.length > 0,
  JSON.stringify(pkg.dsh?.client?.inject),
);

const iconRel = (pkg.icon || '').replace(/^\.\//, '');
check('icon 存在且为相对路径', iconRel.length > 0 && path.isAbsolute(iconRel) === false, pkg.icon);
if (iconRel) {
  const iconSize = statSync(path.join(pkgDir, iconRel)).size;
  check('icon <= 256 KiB', iconSize <= 256 * 1024, iconSize + ' bytes');
}

for (const rel of ['locale/zh.json', 'locale/en.json']) {
  const dict = JSON.parse(readText(rel));
  check(rel + ' meta.title', typeof dict?.meta?.title === 'string' && dict.meta.title.length > 0);
  check(rel + ' meta.description', typeof dict?.meta?.description === 'string' && dict.meta.description.length > 0);
}

const patchText = readText('cordis.patch.yml');
check('patch 含 insert', /^\s*-\s*insert:/m.test(patchText), patchText.trim());
check('patch 的 name 等于包名', patchText.includes("name: '" + pkg.name + "'") || patchText.includes('name: "' + pkg.name + '"'), patchText.trim());

// ---------------------------------------------------------- 3. bundle 契约

group('3. bundle 契约');

const registered = [];
const slotRegistrations = [];
const effects = [];
let bundleId = null;
let bundleExports = null;

const reactStub = (() => {
  const cleanups = [];
  // 徽标根元素带 ref（组件要读它的像素宽度再钉住/放开）。Node 里给它一个够像 DOM 的
  // 替身，好让「先读几何、再写内联样式」那条路径也能被真跑一遍。
  const refElement = {
    style: { width: '' },
    width: 148,
    getBoundingClientRect() {
      return { x: 0, y: 0, width: this.width, height: 20, top: 0, left: 0, right: this.width, bottom: 20 };
    },
  };
  const createElement = (type, props, ...children) => {
    if (typeof type === 'function') {
      return type(Object.assign({}, props, { children: children }));
    }
    if (props !== null && props !== undefined && props.ref !== null && typeof props.ref === 'object') {
      props.ref.current = refElement;
    }
    return { type: type, props: Object.assign({}, props, { children: children }) };
  };
  const React = {
    Fragment: Symbol('react.fragment'),
    createElement: createElement,
    useState: (init) => [typeof init === 'function' ? init() : init, () => {}],
    useEffect: (fn) => {
      const cleanup = fn();
      if (typeof cleanup === 'function') cleanups.push(cleanup);
    },
    useLayoutEffect: (fn) => {
      const cleanup = fn();
      if (typeof cleanup === 'function') cleanups.push(cleanup);
    },
    useRef: (initial) => ({ current: initial }),
  };
  return { React: React, cleanups: cleanups, refElement: refElement };
})();

const loader = {
  load(spec) {
    bundleId = spec && spec.id;
    const moduleExports = spec.factory((name) => {
      if (name === 'react') return reactStub.React;
      if (name === 'react/jsx-runtime') {
        return { jsx: reactStub.React.createElement, jsxs: reactStub.React.createElement, Fragment: reactStub.React.Fragment };
      }
      throw new Error('unexpected require("' + name + '")');
    });
    bundleExports = moduleExports;
  },
};

const previousWindow = globalThis.window;
globalThis.window = { __ModuleLoader__: loader };
try {
  vm.runInThisContext(clientSrc, { filename: 'client.js' });
} finally {
  if (previousWindow === undefined) delete globalThis.window;
  else globalThis.window = previousWindow;
}

check('client.js 调用了 __ModuleLoader__.load', bundleId !== null);
check('bundle id 等于包名', bundleId === pkg.name, String(bundleId) + ' != ' + pkg.name);
check('bundle 导出了 apply', typeof bundleExports?.apply === 'function');
check('bundle 导出了 inject', Array.isArray(bundleExports?.inject), JSON.stringify(bundleExports?.inject));

const fakeCtx = {
  // 插件用 ctx.get('modelDirectories') 惰性取会话模型服务；默认缺失。
  __services: {},
  get(name) {
    return this.__services[name];
  },
  effect(fn, label) {
    effects.push(label);
    return fn();
  },
  locale: {
    register(namespace, dictionaries) {
      registered.push({ namespace: namespace, dictionaries: dictionaries });
      return () => {};
    },
    bind(namespace) {
      const dictionaries = registered.find((item) => item.namespace === namespace)?.dictionaries || {};
      return (key) => {
        const dict = dictionaries.zh || {};
        return Object.prototype.hasOwnProperty.call(dict, key) ? dict[key] : key;
      };
    },
  },
  slots: {
    inject(ownerKey, factory) {
      slotRegistrations.push({ ownerKey: ownerKey, entry: factory() });
    },
    register(meta, render) {
      return { meta: meta, render: render };
    },
  },
};

let applyError = null;
try {
  bundleExports.apply(fakeCtx);
} catch (error) {
  applyError = error;
}
check('apply 不抛错', applyError === null, String(applyError && applyError.stack));

check('注册了 locale 字典', registered.length === 1 && Object.keys(registered[0].dictionaries).sort().join() === 'en,zh', JSON.stringify(registered.map((item) => item.namespace)));
check('注册了 1 个插槽条目', slotRegistrations.length === 1, JSON.stringify(slotRegistrations.length));
const slotEntry = slotRegistrations[0] || { ownerKey: null, entry: null };
check('插槽 ownerKey = conversation.composer.dock', slotEntry.ownerKey === 'conversation.composer.dock', String(slotEntry.ownerKey));
check('插槽 name = conversation.composer.dock', slotEntry.entry?.meta?.name === 'conversation.composer.dock', String(slotEntry.entry?.meta?.name));
check('插槽 id = peakvalley', slotEntry.entry?.meta?.id === 'peakvalley', String(slotEntry.entry?.meta?.id));
check('插槽 order 为数字且大于 统计(0)', Number.isFinite(slotEntry.entry?.meta?.order) && slotEntry.entry.meta.order > 0, String(slotEntry.entry?.meta?.order));
const injectedProps = slotEntry.entry?.meta?.inject?.('session-1') || {};
check('插槽 inject() 提供 t', typeof injectedProps.t === 'function');
check('插槽 inject() 提供 modelStore 槽位', 'modelStore' in injectedProps, Object.keys(injectedProps).join());
check('模型服务缺失时 modelStore 为 null（按未知处理）', injectedProps.modelStore === null, String(injectedProps.modelStore));
check('插槽 render 是函数', typeof slotEntry.entry?.render === 'function');
check('注册都在 ctx.effect 内完成', effects.length >= 1, JSON.stringify(effects));

// ---------------------------------------------------------------- 4. 逻辑

group('4. 峰谷逻辑真值表');

const impl = bundleExports.__peakvalley;
check('__peakvalley 内部接口存在', Boolean(impl && impl.describe && impl.stateAt && impl.nextSwitch));

const t = (key) => impl.ZH[key] ?? key;
const bj = (y, m, d, hh, mm, ss = 0, ms = 0) => Date.UTC(y, m - 1, d, hh, mm, ss, ms) - 8 * 3600 * 1000;

const cases = [
  ['2026-10-01 周四 国庆当天 12:00', bj(2026, 10, 1, 12, 0), false],
  ['2026-10-07 周三 国庆最后一天 10:00', bj(2026, 10, 7, 10, 0), false],
  ['2026-10-08 周四 08:59:59.999', bj(2026, 10, 8, 8, 59, 59, 999), false],
  ['2026-10-08 周四 09:00:00.000', bj(2026, 10, 8, 9, 0), true],
  ['2026-10-08 周四 11:59:59.999', bj(2026, 10, 8, 11, 59, 59, 999), true],
  ['2026-10-08 周四 12:00:00.000', bj(2026, 10, 8, 12, 0), false],
  ['2026-10-08 周四 13:59:59.999', bj(2026, 10, 8, 13, 59, 59, 999), false],
  ['2026-10-08 周四 14:00:00.000', bj(2026, 10, 8, 14, 0), true],
  ['2026-10-08 周四 17:59:59.999', bj(2026, 10, 8, 17, 59, 59, 999), true],
  ['2026-10-08 周四 18:00:00.000', bj(2026, 10, 8, 18, 0), false],
  ['2026-10-08 周四 23:30', bj(2026, 10, 8, 23, 30), false],
  ['2026-10-09 周五 10:00', bj(2026, 10, 9, 10, 0), true],
  ['2026-10-10 周六（调休上班）10:00', bj(2026, 10, 10, 10, 0), false],
  ['2026-10-11 周日 10:00', bj(2026, 10, 11, 10, 0), false],
  ['2026-10-12 周一 10:00', bj(2026, 10, 12, 10, 0), true],
  ['2026-10-12 周一 12:30', bj(2026, 10, 12, 12, 30), false],
  ['2026-01-04 周日（调休上班）10:00', bj(2026, 1, 4, 10, 0), false],
  ['2026-01-05 周一 10:00', bj(2026, 1, 5, 10, 0), true],
  ['2026-02-14 周六（调休上班）10:00', bj(2026, 2, 14, 10, 0), false],
  ['2026-02-16 周一 春节假期 10:00', bj(2026, 2, 16, 10, 0), false],
  ['2026-02-24 周二 节后 10:00', bj(2026, 2, 24, 10, 0), true],
  ['2026-04-06 周一 清明 10:00', bj(2026, 4, 6, 10, 0), false],
  ['2026-05-01 周五 劳动节 10:00', bj(2026, 5, 1, 10, 0), false],
  ['2026-05-09 周六（调休上班）10:00', bj(2026, 5, 9, 10, 0), false],
  ['2026-06-19 周五 端午 10:00', bj(2026, 6, 19, 10, 0), false],
  ['2026-09-20 周日（调休上班）10:00', bj(2026, 9, 20, 10, 0), false],
  ['2026-09-25 周五 中秋 10:00', bj(2026, 9, 25, 10, 0), false],
  ['2026-09-29 周二 10:00', bj(2026, 9, 29, 10, 0), true],
  ['2026-11-26 周四 10:00', bj(2026, 11, 26, 10, 0), true],
  ['2027-03-03 周三 10:00（未内置年份）', bj(2027, 3, 3, 10, 0), true],
  ['2027-01-01 周五（估算元旦）10:00', bj(2027, 1, 1, 10, 0), false],
];

for (const [label, ts, expected] of cases) {
  const state = impl.stateAt(ts);
  check('峰谷判定 ' + label, state.peak === expected, 'peak=' + state.peak + ' 期望 ' + expected);
}

group('5. 切换倒计时与文案');

check('stateAt 标记数据来源（内置年份）', impl.stateAt(bj(2026, 10, 8, 10, 0)).source === 'builtIn');
check('stateAt 标记数据来源（未内置年份走估算）', impl.stateAt(bj(2027, 3, 3, 10, 0)).source === 'estimated');
check('stateAt 标记节假日词条', impl.stateAt(bj(2026, 2, 16, 10, 0)).holiday === 'springFestival');
check('stateAt 标记周末', impl.stateAt(bj(2026, 10, 11, 10, 0)).weekend === true);

const switchCases = [
  ['2026-10-08 08:00 -> 09:00', bj(2026, 10, 8, 8, 0), bj(2026, 10, 8, 9, 0), true],
  ['2026-10-08 12:30 -> 14:00', bj(2026, 10, 8, 12, 30), bj(2026, 10, 8, 14, 0), true],
  ['2026-10-08 18:30 -> 次日 09:00', bj(2026, 10, 8, 18, 30), bj(2026, 10, 9, 9, 0), true],
  ['2026-10-09 19:00 -> 下周一 09:00', bj(2026, 10, 9, 19, 0), bj(2026, 10, 12, 9, 0), true],
  ['2026-09-30 18:30 -> 节后 10-08 09:00', bj(2026, 9, 30, 18, 30), bj(2026, 10, 8, 9, 0), true],
  ['2026-02-13 18:30 -> 节后 02-24 09:00', bj(2026, 2, 13, 18, 30), bj(2026, 2, 24, 9, 0), true],
];

for (const [label, from, expectedAt, expectedPeak] of switchCases) {
  const next = impl.nextSwitch(from);
  check('nextSwitch ' + label, next !== null && next.at === expectedAt && next.peak === expectedPeak, JSON.stringify(next));
  if (next !== null) {
    check('nextSwitch 结果永远在将来 ' + label, next.at > from);
  }
}

check('durationText 1h51m', impl.durationText(t, 111 * 60000) === '1h51m', impl.durationText(t, 111 * 60000));
check('durationText 51m', impl.durationText(t, 51 * 60000) === '51m', impl.durationText(t, 51 * 60000));
const hours = (value) => value * 60 * 60000;
check('durationText 8d23h', impl.durationText(t, hours(8 * 24 + 23)) === '8d23h', impl.durationText(t, hours(8 * 24 + 23)));
check('durationText 2h（整点不带分）', impl.durationText(t, hours(2)) === '2h', impl.durationText(t, hours(2)));
check('durationText 英文同为 d/h/m', impl.durationText((key) => impl.EN[key] ?? key, hours(2)) === '2h', impl.durationText((key) => impl.EN[key] ?? key, hours(2)));
check('durationText 45m', impl.durationText(t, 45 * 60000) === '45m', impl.durationText(t, 45 * 60000));

const zhPeak = impl.describe(bj(2026, 10, 8, 10, 0), t);
check('describe 高峰：状态/倍率/倒计时三段齐全', zhPeak.state === '高峰' && zhPeak.rate === '1x' && zhPeak.eta === '距空闲 2h', zhPeak.state + ' / ' + zhPeak.rate + ' / ' + zhPeak.eta);
check('describe 高峰 tooltip 含规则与倒计时', zhPeak.tooltip.includes('高峰时段') && zhPeak.tooltip.includes('距空闲'), zhPeak.tooltip.replace(/\n/g, ' | '));
check('describe 无模型信息时不输出当前模型行', zhPeak.tooltip.includes('当前模型') === false);
check('describe 默认模式为「全部」并提示可点击', zhPeak.tooltip.includes('显示内容：全部') && zhPeak.tooltip.includes('点击徽标可切换'), zhPeak.tooltip.replace(/\n/g, ' | '));
check('describe 传入模式 id 时提示对应模式名', impl.describe(bj(2026, 10, 8, 10, 0), t, null, 'rate').tooltip.includes('显示内容：仅倍率'));
check('describe 模式 id 非法时回退「全部」', impl.describe(bj(2026, 10, 8, 10, 0), t, null, 'nope').tooltip.includes('显示内容：全部'));
const zhValley = impl.describe(bj(2026, 10, 1, 12, 0), t);
check('describe 节假日：状态空闲、倍率 0.5x', zhValley.peak === false && zhValley.state === '空闲' && zhValley.rate === '0.5x' && zhValley.tooltip.includes('国庆节'), zhValley.state + ' / ' + zhValley.rate);
check('describe 空闲时倒计时指向下一次高峰', zhValley.eta.startsWith('距高峰 '), zhValley.eta);
const zhWeekend = impl.describe(bj(2026, 10, 11, 10, 0), t);
check('describe 周末 tooltip', zhWeekend.tooltip.includes('周末'), zhWeekend.tooltip.replace(/\n/g, ' | '));
const zhFuture = impl.describe(bj(2027, 3, 3, 10, 0), t);
check('describe 未内置年份提示（公历估算）', zhFuture.tooltip.includes('公历估算'), zhFuture.tooltip.replace(/\n/g, ' | '));
check('describe 内置年份提示（插件内置表）', impl.describe(bj(2026, 10, 8, 10, 0), t, null, 'all').tooltip.includes('插件内置表'));
const zhModel = impl.describe(bj(2026, 10, 8, 10, 0), t, { provider: 'deepseek-official', model: 'deepseek-chat' });
check('describe 带模型信息时追加当前模型行', zhModel.tooltip.includes('当前模型') && zhModel.tooltip.includes('deepseek-official/deepseek-chat'), zhModel.tooltip.replace(/\n/g, ' | '));
const enValley = impl.describe(bj(2026, 10, 1, 12, 0), (key) => impl.EN[key] ?? key);
check('describe 英文文案', enValley.state === 'Off-peak' && enValley.rate === '0.5x', enValley.state + ' / ' + enValley.rate);

// ------------------------------------------------------ 5.5 显示模式

group('5.5 显示模式（点击切换）');

check('LAYOUTS 共 7 档', impl.LAYOUTS.length === 7, String(impl.LAYOUTS.length));
check(
  'LAYOUTS 顺序：全部 → 三个单项 → 三个组合',
  impl.LAYOUTS.map((item) => item.id).join(',') === 'all,state,rate,eta,stateRate,stateEta,rateEta',
  impl.LAYOUTS.map((item) => item.id).join(','),
);
const layoutMatrix = {
  all: [true, true, true],
  state: [true, false, false],
  rate: [false, true, false],
  eta: [false, false, true],
  stateRate: [true, true, false],
  stateEta: [true, false, true],
  rateEta: [false, true, true],
};
for (const item of impl.LAYOUTS) {
  const want = layoutMatrix[item.id];
  check(
    'LAYOUTS ' + item.id + ' 的显示段正确',
    Array.isArray(want) && item.state === want[0] && item.rate === want[1] && item.eta === want[2],
    JSON.stringify(item),
  );
  check('LAYOUTS ' + item.id + ' 至少有文案键', impl.ZH['layout.' + item.id] !== undefined && impl.EN['layout.' + item.id] !== undefined);
}
check('LAYOUTS 每档都显示至少一段', impl.LAYOUTS.every((item) => item.state || item.rate || item.eta));
check('nextLayoutIndex 逐档 +1 且末档回到首档', impl.LAYOUTS.every((item, i) => impl.nextLayoutIndex(i) === (i + 1) % 7));

const storage = new Map();
globalThis.localStorage = {
  getItem: (key) => (storage.has(key) ? storage.get(key) : null),
  setItem: (key, value) => storage.set(key, String(value)),
};
check('未存过时默认第一档', impl.readLayoutIndex() === 0);
impl.writeLayoutIndex(3);
check('写入存的是模式 id 而非下标', storage.get(impl.LAYOUT_KEY) === 'eta', String(storage.get(impl.LAYOUT_KEY)));
check('读回已存模式', impl.readLayoutIndex() === 3);
storage.set(impl.LAYOUT_KEY, 'rateEta');
check('读回末档', impl.readLayoutIndex() === 6);
storage.set(impl.LAYOUT_KEY, 'nope');
check('存了非法值时回退第一档', impl.readLayoutIndex() === 0);
globalThis.localStorage = {
  getItem: () => { throw new Error('denied'); },
  setItem: () => { throw new Error('denied'); },
};
check('storage 抛错时读取回退第一档', impl.readLayoutIndex() === 0);
let writeThrew = false;
try {
  impl.writeLayoutIndex(2);
} catch (error) {
  writeThrew = true;
}
check('storage 抛错时写入静默忽略', writeThrew === false);
delete globalThis.localStorage;
check('没有 localStorage 时读取回退第一档', impl.readLayoutIndex() === 0);
let writeThrew2 = false;
try {
  impl.writeLayoutIndex(2);
} catch (error) {
  writeThrew2 = true;
}
check('没有 localStorage 时写入静默忽略', writeThrew2 === false);

// ------------------------------------------------------------- 6. 组件渲染

group('6. 组件实渲染（React 桩）');

// Node 里没有 requestAnimationFrame；进场动画只用它排一帧，这里给个不触发的空实现，
// 让组件能完整跑一遍而不至于抛 ReferenceError（真正的时序在 7.5 组里测）。
const savedRaf = globalThis.requestAnimationFrame;
globalThis.requestAnimationFrame = () => 0;
globalThis.cancelAnimationFrame = () => {};

let renderError = null;
let element = null;
try {
  element = slotEntry.entry.render({ t: t });
} catch (error) {
  renderError = error;
}
check('render 不抛错', renderError === null, String(renderError && renderError.stack));
const fragmentChildren = element && element.props && Array.isArray(element.props.children) ? element.props.children : [];
const badge = fragmentChildren[1] || null;
check('render 产出 style + 徽标两个子节点', fragmentChildren.length === 2, JSON.stringify(fragmentChildren.map((child) => String(child && child.type))));
check('徽标带 title 提示', typeof badge?.props?.title === 'string' && badge.props.title.includes('峰谷时'), String(badge?.props?.title).slice(0, 40));
check('徽标文案不含占位符', typeof badge?.props?.title === 'string' && badge.props.title.includes('undefined') === false);

// 无 t 注入时的回退路径
let fallbackError = null;
try {
  slotEntry.entry.render({});
} catch (error) {
  fallbackError = error;
}
check('render 在无 ownerProps.t 时回退到 locale t', fallbackError === null, String(fallbackError && fallbackError.message));

// useEffect 必须返回清理函数，否则宿主里的定时器会泄漏（也验证组件确实跑过 effect）。
check('组件注册了 effect 且提供清理函数', reactStub.cleanups.length >= 1, String(reactStub.cleanups.length));
for (const cleanup of reactStub.cleanups) cleanup();

// ------------------------------------------------------------ 7. 模型可见性

group('7. 模型可见性（非 DeepSeek 隐藏）');

const fakeStore = (provider, model) => ({
  getSnapshot: () => ({ current: { provider: provider, model: model } }),
});
const fakeRender = (store) => slotEntry.entry.render({ t: t, modelStore: store });
const badgeOf = (output) => (output && output.props && Array.isArray(output.props.children) ? output.props.children[1] : null);

check('isDeepSeek 命中 provider', impl.isDeepSeek('deepseek-official', 'deepseek-chat') === true);
check('isDeepSeek 命中 model', impl.isDeepSeek('custom-gateway', 'DeepSeek-V3.2') === true);
check('isDeepSeek 拒绝第三方', impl.isDeepSeek('openai', 'gpt-5') === false);
check('isDeepSeek 容忍缺失参数', impl.isDeepSeek(undefined, undefined) === false);

check('modelSnapshot 无 store 返回 null', impl.modelSnapshot(undefined) === null);
check('modelSnapshot current 为空返回 null', impl.modelSnapshot({ getSnapshot: () => ({ current: null }) }) === null);
check('modelSnapshot 抛错时返回 null', impl.modelSnapshot({ getSnapshot: () => { throw new Error('boom'); } }) === null);
const snap = impl.modelSnapshot(fakeStore('deepseek-official', 'deepseek-chat'));
check('modelSnapshot 返回 provider/model', snap !== null && snap.provider === 'deepseek-official' && snap.model === 'deepseek-chat', JSON.stringify(snap));

check('非 DeepSeek 模型时徽标返回 null', fakeRender(fakeStore('openai', 'gpt-5')) === null);
const dsElement = fakeRender(fakeStore('deepseek-official', 'deepseek-chat'));
const dsBadge = badgeOf(dsElement);
check('DeepSeek 模型时徽标正常渲染', dsBadge !== null, JSON.stringify(dsElement));
check('DeepSeek 模型时 tooltip 标明模型', String(dsBadge?.props?.title).includes('deepseek-official/deepseek-chat'), String(dsBadge?.props?.title).replace(/\n/g, ' | '));
check('store 缺失（模型未知）时照常显示', badgeOf(fakeRender(undefined)) !== null);

fakeCtx.__services.modelDirectories = { directoryFor: () => ({ store: fakeStore('deepseek-official', 'deepseek-chat') }) };
const wired = slotEntry.entry?.meta?.inject?.('session-1') || {};
check(
  '模型服务可用时 modelStore 即目录 store',
  wired.modelStore !== null && wired.modelStore.getSnapshot().current.provider === 'deepseek-official',
  String(wired.modelStore),
);
fakeCtx.__services.modelDirectories = { directoryFor: () => { throw new Error('unknown session'); } };
check('directoryFor 抛错时 modelStore 回退为 null', slotEntry.entry?.meta?.inject?.('session-x')?.modelStore === null);
delete fakeCtx.__services.modelDirectories;

// ------------------------------------------------------------ 7.5 进出场动画

group('7.5 进出场动画');

const anim = impl.ANIM_MS;
check('动画时长是正数毫秒', Number.isFinite(anim) && anim > 0 && anim < 1000, String(anim));
check('CSS 定义了 enter / exit 两个状态类', /\.pkv_enter\{/.test(impl.CSS) && /\.pkv_exit\{/.test(impl.CSS));
// 这套方案的核心：盒子只负责「几何」，文字单独一层负责「淡入淡出」，两者解耦。
// 只淡透明度的话，文字本身占的那段宽度会在卸载瞬间消失，同一行其它条目就会「跳」。
check(
  '盒子只过渡几何 width/padding/margin/border-width，不碰 opacity/transform',
  ['width', 'padding', 'margin', 'border-width'].every((prop) => new RegExp(prop + ' ' + anim + 'ms').test(impl.CSS)) &&
    !/\.pkv_root\{[^}]*transition:[^}]*opacity/.test(impl.CSS) &&
    !/\.pkv_root\{[^}]*transition:[^}]*transform/.test(impl.CSS),
  impl.CSS.replace(/^[\s\S]*?_root\{/, '_root{').slice(0, 240),
);
check(
  '内容独占一层 .pkv_inner，自己过渡 opacity/transform',
  /\.pkv_inner\{[^}]*display:inline-flex/.test(impl.CSS) &&
    /\.pkv_inner\{[^}]*transition:opacity 170ms ease 110ms,transform 240ms/.test(impl.CSS),
  (impl.CSS.match(/\.pkv_inner\{[^}]*\}/) || [''])[0],
);
check(
  'root 声明 width:auto 且允许 auto↔0 插值（否则宽度收不回去）',
  /\.pkv_root\{[^}]*width:auto/.test(impl.CSS) &&
    impl.CSS.includes('interpolate-size:allow-keywords') &&
    /\.pkv_root\{[^}]*overflow:hidden/.test(impl.CSS),
  impl.CSS.replace(/^[\s\S]*?_root\{/, '_root{').slice(0, 220),
);
check(
  '进场：盒子完全归零（含边框），内容层透明 + 位移',
  /\.pkv_enter\{width:0;padding-left:0;padding-right:0;margin-right:-12px;border-left-width:0;border-right-width:0\}/.test(impl.CSS) &&
    /\.pkv_enter \.pkv_inner\{opacity:0;transform:translateX\(6px\)\}/.test(impl.CSS),
  impl.CSS.replace(/.*_enter\{/, '_enter{').replace(/\}.*/, '}'),
);
check(
  '退场：内容层 100ms 先隐，空盒子延迟 EXIT_LAG 才开始收',
  /\.pkv_exit \.pkv_inner\{opacity:0;transform:translateX\(6px\);transition:opacity 100ms ease,transform 150ms ease\}/.test(impl.CSS) &&
    new RegExp('transition:width ' + impl.EXIT_MS + 'ms[^}]*' + impl.EXIT_LAG + 'ms').test(impl.CSS),
  impl.CSS.replace(/.*_exit\{/, '_exit{').slice(0, 260),
);
check('退场把宽度真正收到 0（margin-right:-12px 抵掉宿主 gap）', impl.CSS.includes('margin-right:-12px'));
check(
  '退场顺序合理：文字消失(100ms) 早于盒子收完',
  100 < impl.EXIT_LAG + impl.EXIT_MS,
  '内容 100ms vs 盒子 ' + (impl.EXIT_LAG + impl.EXIT_MS) + 'ms',
);
check(
  '卸载计时晚于退场动画总时长（动画才播得完，不会半截被摘掉）',
  impl.EXIT_LAG + impl.EXIT_MS < impl.UNMOUNT_MS,
  impl.EXIT_LAG + '+' + impl.EXIT_MS + ' < ' + impl.UNMOUNT_MS,
);
check(
  '文字子项 flex:none，宽度收缩时不会被压变形',
  /\.pkv_period\{flex:none/.test(impl.CSS) && /\.pkv_rest\{flex:none/.test(impl.CSS),
);
const reducedMotion = (impl.CSS.match(/@media \(prefers-reduced-motion:reduce\)\{[\s\S]*?\}\}/) || [''])[0];
check('存在 prefers-reduced-motion 分支', reducedMotion !== '', reducedMotion);
check(
  'reduced-motion 下仍然过渡 width（绝不能是 transition:none）',
  new RegExp('@media \\(prefers-reduced-motion:reduce\\)\\{\\.pkv_root,\\.pkv_exit\\{transition:width ' + impl.SHORT_MS + 'ms linear').test(
    impl.CSS,
  ) && !/prefers-reduced-motion:reduce\)\{\.pkv_root,\.pkv_exit\{transition:none\}/.test(impl.CSS),
  reducedMotion,
);
check(
  'reduced-motion 的收放确实更短（SHORT_MS < ANIM_MS）',
  impl.SHORT_MS > 0 && impl.SHORT_MS < anim,
  impl.SHORT_MS + ' < ' + anim,
);
check(
  'reduced-motion 下不做位移（内容只淡，不滑）',
  /\.pkv_enter \.pkv_inner,\.pkv_exit \.pkv_inner\{transform:none\}\}/.test(reducedMotion) && !/translateX/.test(reducedMotion),
  reducedMotion,
);
check(
  'reduced-motion 下内容仍后显 / 先隐（避免半个字）',
  /\.pkv_inner\{transition:opacity 70ms linear 70ms\}/.test(reducedMotion) &&
    /\.pkv_exit \.pkv_inner\{transition:opacity 60ms linear\}/.test(reducedMotion),
  reducedMotion,
);
check(
  '换档：内容先淡出（_switch），盒子原地不动',
  new RegExp('\\.pkv_switch \\.pkv_inner\\{opacity:0;transition:opacity ' + impl.SWAP_OUT_MS + 'ms ease\\}').test(impl.CSS),
);
check(
  'reduced-motion 下换档淡出也更短（60ms linear）',
  /\.pkv_switch \.pkv_inner\{transition:opacity 60ms linear\}/.test(reducedMotion),
  reducedMotion,
);
check(
  '根元素可点击：cursor:pointer + 禁用文字选中',
  /\.pkv_root\{[^}]*cursor:pointer/.test(impl.CSS) && /\.pkv_root\{[^}]*user-select:none/.test(impl.CSS),
);
check('根元素不再用 cursor:default', impl.CSS.includes('cursor:default') === false);
check(
  '悬停 / 聚焦有底色反馈（currentColor 混色，不引入未知 token）',
  /\.pkv_root:hover,\.pkv_root:focus-visible\{background:color-mix\(in srgb,currentColor 14%,transparent\)\}/.test(impl.CSS),
  impl.CSS.slice(impl.CSS.indexOf('_root:hover')),
);
check('文字段与分隔符都是 flex:none', /\.pkv_piece\{flex:none\}/.test(impl.CSS) && /\.pkv_sep\{flex:none/.test(impl.CSS));
check('点击提示文案中英成对存在', impl.ZH.tipClick !== undefined && impl.EN.tipClick !== undefined && impl.ZH.tipLayout !== undefined && impl.EN.tipLayout !== undefined);
check('组件本体已导出，供时序测试直接调用', typeof impl.__component === 'function');

// 一个够用的 React 运行时：hooks 按调用顺序存在 slots 里，state 变化会重渲染，
// effect 只在依赖变化时重跑（先跑上一轮的 cleanup）。
// 注意：bundle 里的 `const React = require('react')` 拿到的就是 reactStub.React 这个
// 对象本体，所以只能就地改写它的方法，换一个新对象是不生效的。
function makeHarness(initialStore) {
  const slots = [];
  const effectQueue = [];
  const timers = [];
  const rafs = [];
  const cancelledRaf = new Set();
  const savedGlobals = {
    setTimeout: globalThis.setTimeout,
    clearTimeout: globalThis.clearTimeout,
    setInterval: globalThis.setInterval,
    clearInterval: globalThis.clearInterval,
    requestAnimationFrame: globalThis.requestAnimationFrame,
    cancelAnimationFrame: globalThis.cancelAnimationFrame,
  };
  const savedHooks = {
    useState: reactStub.React.useState,
    useEffect: reactStub.React.useEffect,
    useLayoutEffect: reactStub.React.useLayoutEffect,
    useRef: reactStub.React.useRef,
  };

  // useNow 里的每秒时钟本组用不到，桩掉以免吊住进程。
  globalThis.setInterval = () => ({ stub: 'interval' });
  globalThis.clearInterval = () => {};
  globalThis.setTimeout = (fn, ms) => {
    const timer = { fn: fn, ms: ms, cancelled: false };
    timers.push(timer);
    return timer;
  };
  globalThis.clearTimeout = (timer) => {
    if (timer) timer.cancelled = true;
  };
  globalThis.requestAnimationFrame = (fn) => {
    const token = { fn: fn };
    rafs.push(token);
    return token;
  };
  globalThis.cancelAnimationFrame = (token) => {
    if (token) cancelledRaf.add(token);
  };

  // 根元素替身是所有 harness 共用的，每次开工先清掉上一次留下的内联宽度。
  reactStub.refElement.style = { width: '' };
  reactStub.refElement.width = 148;

  let output = null;
  let props = { t: t, modelStore: initialStore };
  let cursor = 0;
  let flushing = false;
  let dirty = false;

  // 不重入：effect 里的 setState 只置 dirty，等本轮 effect 全部跑完再重渲染。
  function schedule() {
    if (flushing) {
      dirty = true;
      return;
    }
    flushing = true;
    try {
      do {
        dirty = false;
        effectQueue.length = 0;
        cursor = 0;
        output = reactStub.React.createElement(impl.__component, props);
        for (let i = 0; i < effectQueue.length; i++) {
          const item = effectQueue[i];
          if (item.prev && typeof item.prev.cleanup === 'function') item.prev.cleanup();
          const record = { kind: 'effect', deps: item.deps, cleanup: null };
          slots[item.index] = record;
          const cleanup = item.fn();
          if (typeof cleanup === 'function') record.cleanup = cleanup;
        }
      } while (dirty);
    } finally {
      flushing = false;
    }
  }

  reactStub.React.useState = (init) => {
    const index = cursor++;
    if (slots[index] === undefined) {
      slots[index] = { kind: 'state', value: typeof init === 'function' ? init() : init };
    }
    const slot = slots[index];
    return [
      slot.value,
      (next) => {
        const value = typeof next === 'function' ? next(slot.value) : next;
        if (value === slot.value) return;
        slot.value = value;
        schedule();
      },
    ];
  };
  reactStub.React.useRef = (init) => {
    const index = cursor++;
    if (slots[index] === undefined) slots[index] = { kind: 'ref', ref: { current: init } };
    return slots[index].ref;
  };
  reactStub.React.useEffect = (fn, deps) => {
    const index = cursor++;
    const prev = slots[index];
    const same =
      prev !== undefined &&
      prev.kind === 'effect' &&
      Array.isArray(prev.deps) &&
      Array.isArray(deps) &&
      prev.deps.length === deps.length &&
      deps.every((dep, i) => dep === prev.deps[i]);
    if (!same) effectQueue.push({ index: index, fn: fn, deps: deps, prev: prev });
  };
  // useLayoutEffect 在这里与 useEffect 同一套时序（本组件只拿它「提交后、绘制前」
  // 读取/写入根元素的内联宽度，不依赖真实的绘制时机）。
  reactStub.React.useLayoutEffect = reactStub.React.useEffect;

  function parts() {
    return output && output.props && Array.isArray(output.props.children) ? output.props.children : [];
  }

  const api = {
    setModel: (provider, model) => {
      props = { t: t, modelStore: provider === null ? undefined : { getSnapshot: () => ({ current: { provider: provider, model: model } }) } };
      schedule();
      return api;
    },
    // 模拟每秒一次的时钟重渲染。
    tickRender: () => {
      schedule();
      return api;
    },
    flushRaf: () => {
      for (const token of rafs.splice(0)) {
        if (!cancelledRaf.has(token)) token.fn();
      }
      return api;
    },
    pendingTimers: () => timers.filter((timer) => !timer.cancelled).length,
    fireTimers: () => {
      for (const timer of timers.splice(0)) {
        if (!timer.cancelled) timer.fn();
      }
      return api;
    },
    badge: () => parts()[1] || null,
    inner: () => {
      const badge = parts()[1];
      const kids = badge && badge.props ? badge.props.children : null;
      return Array.isArray(kids) ? kids[0] || null : null;
    },
    classes: () => {
      const badge = parts()[1];
      return badge && badge.props && typeof badge.props.className === 'string' ? badge.props.className.split(' ') : [];
    },
    // 根元素（ref 的替身）：点击换档时会往它的 style.width 上钉一个像素值。
    el: () => {
      const badge = parts()[1];
      return badge && badge.props && badge.props.ref ? badge.props.ref.current : null;
    },
    // 文字段（圆点与分隔符不算）：模式的取舍就是靠它的条数 / 类名断言的。
    pieces: () => {
      const inner = api.inner();
      const kids = inner && inner.props && Array.isArray(inner.props.children) ? inner.props.children : [];
      return kids.filter(
        (child) => child && child.props && /pkv_(period|piece)/.test(String(child.props.className)),
      );
    },
    click: () => {
      const badge = parts()[1];
      if (badge && badge.props && typeof badge.props.onClick === 'function') badge.props.onClick();
      return api;
    },
    pressKey: (key) => {
      const badge = parts()[1];
      if (badge && badge.props && typeof badge.props.onKeyDown === 'function') {
        badge.props.onKeyDown({ key: key, preventDefault: () => {} });
      }
      return api;
    },
    output: () => output,
    dispose: () => {
      for (const slot of slots) {
        if (slot && typeof slot.cleanup === 'function') slot.cleanup();
      }
      Object.assign(reactStub.React, savedHooks);
      Object.assign(globalThis, savedGlobals);
    },
  };

  schedule();
  return api;
}

// A. 一开始就该显示：首帧挂 enter，两帧后才转 live。
let harness = makeHarness(undefined);
check('A 首帧就挂 pkv_enter', harness.classes().includes('pkv_enter'), harness.classes().join(' '));
check('A enter 态同时带时段色', harness.classes().some((cls) => cls === 'pkv_peak' || cls === 'pkv_valley'), harness.classes().join(' '));
check('A enter 态内容已就位（不是空壳）', harness.badge() !== null && String(harness.badge().props.title).includes('峰谷时'));
check(
  'A 文字被单独的 .pkv_inner 层包住（几何与内容解耦）',
  harness.inner() !== null &&
    harness.inner().props.className === 'pkv_inner' &&
    Array.isArray(harness.inner().props.children),
  String(harness.inner() && harness.inner().props.className),
);
check(
  'A 默认「全部」：圆点 + 时段 + 倍率 + 倒计时（含 2 个分隔符共 6 个节点）',
  harness.inner().props.children.length === 6 && harness.pieces().length === 3,
  'nodes=' + harness.inner().props.children.length + ' pieces=' + harness.pieces().length,
);
check(
  'A inner 里每个节点都带 pkv_ 前缀的类名',
  harness.inner().props.children.every((child) => typeof child.props.className === 'string' && child.props.className.startsWith('pkv_')),
);
check(
  'A 徽标是按钮语义：可点、可聚焦、可键盘触发',
  harness.badge().props.role === 'button' &&
    harness.badge().props.tabIndex === 0 &&
    typeof harness.badge().props.onClick === 'function' &&
    typeof harness.badge().props.onKeyDown === 'function',
  String(harness.badge().props.role),
);
harness.flushRaf();
check('A 只过一帧仍是 enter', harness.classes().includes('pkv_enter'), harness.classes().join(' '));
harness.flushRaf();
check('A 两帧后转 live（只剩 root + 时段色）', harness.classes().length === 2 && harness.classes().includes('pkv_enter') === false, harness.classes().join(' '));

// B. 每秒一次的时钟重渲染不得重新播放动画。
harness.tickRender();
harness.tickRender();
check('B 时钟重渲染不重启动画', harness.classes().length === 2, harness.classes().join(' '));
check('B 常态下没有挂起的退场计时器', harness.pendingTimers() === 0, String(harness.pendingTimers()));

// C. 切到非 DeepSeek：先挂 exit 跑动画，计时器到点才真正卸载。
harness.setModel('openai', 'gpt-5');
check('C 立刻挂 pkv_exit（此时还没消失）', harness.classes().includes('pkv_exit'), harness.classes().join(' '));
check('C 退场期间内容还在（动画才播得完整）', harness.badge() !== null && String(harness.badge().props.title).includes('峰谷时'));
check('C 退场计时器已挂起', harness.pendingTimers() === 1, String(harness.pendingTimers()));
harness.fireTimers();
check('C 计时器到点后卸载为 null', harness.output() === null, JSON.stringify(harness.output()));
harness.dispose();

// D. 退场还没跑完就切回 DeepSeek：必须取消卸载并保持显示。
harness = makeHarness(undefined);
harness.flushRaf();
harness.flushRaf();
harness.setModel('openai', 'gpt-5');
const sawExit = harness.classes().includes('pkv_exit');
harness.setModel('deepseek-official', 'deepseek-chat');
check('D 退场中途切回：计时器被取消', harness.pendingTimers() === 0, String(harness.pendingTimers()));
harness.fireTimers();
check(
  'D 退场中途切回能取消卸载',
  sawExit && harness.output() !== null && harness.classes().includes('pkv_exit') === false,
  'sawExit=' + String(sawExit) + ' ' + harness.classes().join(' '),
);
check('D 切回后不会残留过渡类', harness.classes().length === 2, harness.classes().join(' '));
harness.dispose();

// E. 挂载时就该隐藏：连 enter 都不播；之后切回 DeepSeek 才进场。
harness = makeHarness({ getSnapshot: () => ({ current: { provider: 'openai', model: 'gpt-5' } }) });
check('E 初始即隐藏时直接无 DOM', harness.output() === null, JSON.stringify(harness.output()));
check('E 初始隐藏时不起退场计时器', harness.pendingTimers() === 0, String(harness.pendingTimers()));
harness.setModel('deepseek-official', 'deepseek-chat');
check('E 切回 DeepSeek 才播进场', harness.classes().includes('pkv_enter'), harness.classes().join(' '));
harness.dispose();

// F. 退场跑完真的卸载之后，再切回来仍要能二次进场并收敛。
harness = makeHarness(undefined);
harness.flushRaf();
harness.flushRaf();
harness.setModel('openai', 'gpt-5');
harness.fireTimers();
check('F 卸载后确实没有 DOM', harness.output() === null);
harness.setModel('deepseek-official', 'deepseek-chat');
check('F 卸载后仍能重新进场', harness.classes().includes('pkv_enter'), harness.classes().join(' '));
harness.flushRaf();
harness.flushRaf();
check('F 二次进场能收敛到 live', harness.classes().length === 2, harness.classes().join(' '));
harness.dispose();

// ------------------------------------------------ 7.6 点击切换显示内容

group('7.6 点击切换显示内容');

// 当前档从 tooltip 的「显示内容：X」里读，顺带验证提示行本身。
// 模式名里可能带空格（「时段 + 倍率」），所以按 LAYOUTS 逐项比对 id 而不是抠字符串。
const layoutOf = (h) => {
  const badge = h.badge();
  const title = badge && badge.props ? String(badge.props.title) : '';
  const hits = impl.LAYOUTS.filter((item) => title.includes('显示内容：' + impl.ZH['layout.' + item.id]));
  return hits.length === 1 ? hits[0].id : '';
};
const pieceCls = (h) => h.pieces().map((child) => String(child.props.className)).join(' | ');

harness = makeHarness(undefined);
harness.flushRaf();
harness.flushRaf();
check('G 初始为「全部」', layoutOf(harness) === 'all', layoutOf(harness));

// 第一拍：只让内容淡出，文案与宽度都还没动。
harness.click();
check('G 点击后立刻挂 pkv_switch（内容开始淡出）', harness.classes().includes('pkv_switch'), harness.classes().join(' '));
check('G 淡出期间文案还没换', layoutOf(harness) === 'all', layoutOf(harness));
check('G 淡出期间不钉宽度（盒子原地不动）', harness.el().style.width === '', String(harness.el().style.width));
check('G 淡出计时器已挂起且只有一个', harness.pendingTimers() === 1, String(harness.pendingTimers()));

// 第二拍：换文案；同一次提交里先把旧宽度钉成像素值。
harness.fireTimers();
check(
  'G 到点后换到下一档并摘掉 pkv_switch',
  layoutOf(harness) === 'state' && harness.classes().includes('pkv_switch') === false,
  layoutOf(harness) + ' / ' + harness.classes().join(' '),
);
check('G 该档只显示 1 段文字', harness.pieces().length === 1, String(harness.pieces().length));
check('G 提交时把旧宽度钉住（auto→auto 不会插值）', harness.el().style.width === '148px', String(harness.el().style.width));
harness.flushRaf();
check('G 一帧后仍钉着', harness.el().style.width === '148px', String(harness.el().style.width));
harness.flushRaf();
check('G 两帧后放开宽度，交给 CSS 过渡', harness.el().style.width === '', String(harness.el().style.width));
check('G 放开后没有残留计时器', harness.pendingTimers() === 0, String(harness.pendingTimers()));

// 剩下六档跑一圈，逐档核对段数。
const walk = [
  ['rate', 1],
  ['eta', 1],
  ['stateRate', 2],
  ['stateEta', 2],
  ['rateEta', 2],
  ['all', 3],
];
for (const [id, count] of walk) {
  harness.click();
  harness.fireTimers();
  harness.flushRaf();
  harness.flushRaf();
  check(
    'G 循环到「' + impl.ZH['layout.' + id] + '」且显示 ' + count + ' 段',
    layoutOf(harness) === id && harness.pieces().length === count,
    layoutOf(harness) + ' / ' + String(harness.pieces().length),
  );
}
check('G 七次点击正好回到起点', layoutOf(harness) === 'all', layoutOf(harness));
harness.dispose();

// 主次：显示时段时倍率/倒计时压暗；不显示时段时用当前色（单段更醒目）。
const cycleOnce = (h) => {
  h.click();
  h.fireTimers();
  h.flushRaf();
  h.flushRaf();
};
harness = makeHarness(undefined);
harness.flushRaf();
harness.flushRaf();
check('G 全部模式：时段用当前色，倍率 / 倒计时压暗', pieceCls(harness) === 'pkv_period | pkv_piece pkv_rest | pkv_piece pkv_rest', pieceCls(harness));
cycleOnce(harness);
check('G 仅时段：单段用当前色', pieceCls(harness) === 'pkv_period', pieceCls(harness));
cycleOnce(harness);
check('G 仅倍率：单段用当前色', pieceCls(harness) === 'pkv_piece', pieceCls(harness));
cycleOnce(harness);
check('G 仅倒计时：单段用当前色', pieceCls(harness) === 'pkv_piece', pieceCls(harness));
cycleOnce(harness);
check('G 时段 + 倍率：倍率压暗', pieceCls(harness) === 'pkv_period | pkv_piece pkv_rest', pieceCls(harness));
cycleOnce(harness);
check('G 时段 + 倒计时：倒计时压暗', pieceCls(harness) === 'pkv_period | pkv_piece pkv_rest', pieceCls(harness));
cycleOnce(harness);
check('G 倍率 + 倒计时（无时段）：两段都用当前色', pieceCls(harness) === 'pkv_piece | pkv_piece', pieceCls(harness));
harness.dispose();

// 连点：基准是「已经在路上的那一档」，不能丢步、也不能堆计时器。
harness = makeHarness(undefined);
harness.flushRaf();
harness.flushRaf();
harness.click();
harness.click();
harness.click();
check('G 连点三次只留最后一个计时器', harness.pendingTimers() === 1, String(harness.pendingTimers()));
harness.fireTimers();
harness.flushRaf();
harness.flushRaf();
check('G 连点三次连进三档（全部 → 仅倒计时）', layoutOf(harness) === 'eta', layoutOf(harness));
harness.dispose();

// 键盘：Enter / 空格与点击等价，其它键不触发。
harness = makeHarness(undefined);
harness.flushRaf();
harness.flushRaf();
harness.pressKey('a');
check('G 其它按键不触发换档', harness.pendingTimers() === 0, String(harness.pendingTimers()));
harness.pressKey('Enter');
check('G Enter 触发换档', harness.pendingTimers() === 1, String(harness.pendingTimers()));
harness.fireTimers();
harness.flushRaf();
harness.flushRaf();
check('G Enter 后进了下一档', layoutOf(harness) === 'state', layoutOf(harness));
harness.pressKey(' ');
check('G 空格也触发换档', harness.pendingTimers() === 1, String(harness.pendingTimers()));
harness.fireTimers();
harness.flushRaf();
harness.flushRaf();
check('G 空格后确实进了下一档', layoutOf(harness) === 'rate', layoutOf(harness));
harness.dispose();

// 持久化：默认「全部」，换档写回，重新挂载能恢复。
const store = new Map();
globalThis.localStorage = {
  getItem: (key) => (store.has(key) ? store.get(key) : null),
  setItem: (key, value) => store.set(key, String(value)),
};
harness = makeHarness(undefined);
harness.flushRaf();
harness.flushRaf();
check('G 未存过时从「全部」开始', layoutOf(harness) === 'all', layoutOf(harness));
cycleOnce(harness);
check('G 换档后写回 localStorage（存 id 而非下标）', store.get(impl.LAYOUT_KEY) === 'state', String(store.get(impl.LAYOUT_KEY)));
harness.dispose();
store.set(impl.LAYOUT_KEY, 'rateEta');
harness = makeHarness(undefined);
harness.flushRaf();
harness.flushRaf();
check('G 重新挂载后恢复上次的档', layoutOf(harness) === 'rateEta', layoutOf(harness));
check('G 恢复的档显示 2 段', harness.pieces().length === 2, String(harness.pieces().length));
harness.dispose();
delete globalThis.localStorage;

// ------------------------------------------------ 7.7 节假日在线同步

group('7.7 节假日在线同步');

// 与数据源同构的离线样本（shape 抄自 jsDelivr 上的 NateScarlet/holiday-cn，2026-10-01
// 抓取）：7 个节日放假段 + 6 个「调休上班」的周末。这里不联网，只做回归。
const H_GROUPS_2026 = [
  ['元旦', '2026-01-01', '2026-01-03'],
  ['春节', '2026-02-15', '2026-02-23'],
  ['清明节', '2026-04-04', '2026-04-06'],
  ['劳动节', '2026-05-01', '2026-05-05'],
  ['端午节', '2026-06-19', '2026-06-21'],
  ['中秋节', '2026-09-25', '2026-09-27'],
  ['国庆节', '2026-10-01', '2026-10-07'],
];
const H_WORKDAYS_2026 = ['2026-01-04', '2026-02-14', '2026-02-28', '2026-05-09', '2026-09-20', '2026-10-10'];
const H_DAY = 86400000;
const dateRange = (from, to) => {
  const out = [];
  for (let at = Date.parse(from + 'T00:00:00Z'); at <= Date.parse(to + 'T00:00:00Z'); at += H_DAY) {
    out.push(new Date(at).toISOString().slice(0, 10));
  }
  return out;
};
const H_OFF_2026 = H_GROUPS_2026.flatMap((entry) => dateRange(entry[1], entry[2]));
const sameSet = (a, b) => a.size === b.size && Array.from(a).every((item) => b.has(item));
const feedFor = (year, groups, workdays) => {
  const days = [];
  for (const entry of groups) {
    for (const date of dateRange(entry[1], entry[2])) {
      days.push({ name: entry[0], date: date, isOffDay: true });
    }
  }
  for (const date of workdays) {
    days.push({ name: '春节', date: date, isOffDay: false });
  }
  return JSON.stringify({
    year: year,
    papers: ['https://www.gov.cn/zhengce/zhengceku/202511/content_7047091.htm'],
    days: days,
  });
};
const emptyFeed = (year) => JSON.stringify({ year: year, papers: [], days: [] });
const hFeed2026 = feedFor(2026, H_GROUPS_2026, H_WORKDAYS_2026);
const hYearOf = (url) => Number(url.slice(url.lastIndexOf('/') + 1, url.lastIndexOf('.')));
const flushMicrotasks = async (times = 30) => {
  for (let i = 0; i < times; i += 1) await Promise.resolve();
};

check(
  '两个在线镜像都是 https 且按年份拼接',
  impl.HOLIDAY_FEEDS.length === 2 && impl.HOLIDAY_FEEDS.every((feed) => /^https:\/\//.test(feed(2030)) && feed(2030).includes('2030.json'))
);
check(
  '首选 jsDelivr、次选 raw.githubusercontent',
  impl.HOLIDAY_FEEDS[0](2030).includes('cdn.jsdelivr.net') && impl.HOLIDAY_FEEDS[1](2030).includes('raw.githubusercontent.com')
);

const hParsed2026 = impl.parseHolidayFeed(2026, hFeed2026);
check('解析在线数据：只收放假日（6 个补班日被忽略）', hParsed2026 instanceof Map && hParsed2026.size === 33, String(hParsed2026 && hParsed2026.size));
check('在线放假日与独立抄录的 2026 清单一致', sameSet(new Set(hParsed2026.keys()), new Set(H_OFF_2026)), hParsed2026.size + ' vs ' + H_OFF_2026.length);
const hBuiltIn2026 = new Set();
for (const range of impl.HOLIDAYS[2026]) {
  for (const date of dateRange(range[0], range[1])) hBuiltIn2026.add(date);
}
check(
  '内置 2026 表与在线数据逐日一致（数据源或内置表变动会在这里报警）',
  sameSet(hBuiltIn2026, new Set(H_OFF_2026)),
  hBuiltIn2026.size + ' vs ' + H_OFF_2026.length
);
check(
  '中文节日名映射到词典 key',
  hParsed2026.get('2026-02-16').key === 'springFestival' && hParsed2026.get('2026-10-01').key === 'nationalDay'
);
check('保留节日名原文', hParsed2026.get('2026-09-25').raw === '中秋节');
check('补班日不进放假表', hParsed2026.has('2026-02-14') === false && hParsed2026.has('2026-10-10') === false);
check('非 JSON 响应返回 null', impl.parseHolidayFeed(2026, '<html>403 Forbidden</html>') === null);
check('年份不符的数据返回 null', impl.parseHolidayFeed(2027, hFeed2026) === null);
check('days 非数组返回 null', impl.parseHolidayFeed(2026, JSON.stringify({ year: 2026, days: {} })) === null);
check('尚未公布的年份解析为空表', impl.parseHolidayFeed(2027, emptyFeed(2027)).size === 0);
const hNoisy = impl.parseHolidayFeed(
  2026,
  JSON.stringify({
    year: 2026,
    days: [
      { name: '春节', date: '2026-02-16', isOffDay: true },
      { name: '春节', date: '2026/02/17', isOffDay: true },
      null,
      { name: '春节', isOffDay: true },
      { name: '元宵节', date: '2026-03-03', isOffDay: true },
      { name: '春节', date: '2026-02-18' },
    ],
  })
);
check('脏条目被逐条跳过', hNoisy.size === 2, String(hNoisy.size));
check('词典未收录的节日名保留原文、key 置空', hNoisy.get('2026-03-03').key === null && hNoisy.get('2026-03-03').raw === '元宵节');

impl.holidayRemote.clear();
check('没有在线数据时用内置表', impl.holidayOf(2026).source === 'builtIn');
check('没有内置表时用公历估算', impl.holidayOf(2077).source === 'estimated');
check('估算表同样是逐日条目', impl.holidayOf(2077).days.get('2077-10-01').key === 'nationalDay');
check('估算年份的国庆仍是空闲', impl.stateAt(bj(2077, 10, 1, 10, 0)).peak === false && impl.stateAt(bj(2077, 10, 1, 10, 0)).source === 'estimated');
impl.holidayRemote.set(2026, { at: Date.now(), days: hParsed2026 });
check('有在线数据时优先用在线表', impl.holidayOf(2026).source === 'online' && impl.holidayOf(2026).days === hParsed2026);
impl.holidayRemote.set(2026, { at: Date.now(), days: new Map([['2026-03-05', { key: null, raw: '临时假日' }]]) });
check('在线表覆盖内置表：新增日期变空闲', impl.stateAt(bj(2026, 3, 5, 10, 0)).peak === false && impl.stateAt(bj(2026, 3, 5, 10, 0)).source === 'online');
check('在线表没有的日期不再享受内置节假日', impl.stateAt(bj(2026, 10, 1, 10, 0)).peak === true);
check(
  '未收录节日名：holiday 为 null、holidayRaw 回传原文',
  impl.stateAt(bj(2026, 3, 5, 10, 0)).holiday === null && impl.stateAt(bj(2026, 3, 5, 10, 0)).holidayRaw === '临时假日'
);
check('describe 原样显示未收录的节日名', impl.describe(bj(2026, 3, 5, 10, 0), t, null, 'all').tooltip.includes('临时假日'));
check('describe 在线数据提示已在线同步', impl.describe(bj(2026, 3, 5, 10, 0), t, null, 'all').tooltip.includes('在线同步'));

impl.holidayRemote.clear();
check('没有数据时必须抓取', impl.holidayNeedsRefresh(2027, 1000000000000) === true);
impl.holidayRemote.set(2027, { at: 1000, days: new Map([['2027-01-01', { key: 'newYear', raw: '元旦' }]]) });
check('已公布年份 29 天内不重抓', impl.holidayNeedsRefresh(2027, 1000 + (29 * H_DAY)) === false);
check('已公布年份 31 天后重抓', impl.holidayNeedsRefresh(2027, 1000 + (31 * H_DAY)) === true);
impl.holidayRemote.set(2028, { at: 1000, days: new Map() });
check('未公布年份 11 小时内不重抓', impl.holidayNeedsRefresh(2028, 1000 + (11 * 3600000)) === false);
check('未公布年份 13 小时后重抓', impl.holidayNeedsRefresh(2028, 1000 + (13 * 3600000)) === true);
check(
  'TTL / 超时常量与设计一致',
  impl.HOLIDAY_TTL_ANNOUNCED_MS === 30 * H_DAY && impl.HOLIDAY_TTL_PENDING_MS === 12 * 3600000 && impl.HOLIDAY_TIMEOUT_MS === 8000
);

const realFetch = globalThis.fetch;
const realStorage = globalThis.localStorage;
const hCalls = [];
const hStore = new Map();
globalThis.localStorage = {
  getItem: (key) => (hStore.has(key) ? hStore.get(key) : null),
  setItem: (key, value) => hStore.set(key, String(value)),
};
impl.holidayRemote.clear();
globalThis.fetch = (url) => {
  hCalls.push(url);
  const year = hYearOf(url);
  return Promise.resolve({ ok: true, text: () => Promise.resolve(year === 2026 ? hFeed2026 : emptyFeed(year)) });
};
impl.ensureHolidays(bj(2026, 3, 3, 10, 0));
await flushMicrotasks();
check('启动后抓取本年与下一年', hCalls.length === 2, hCalls.join(' | '));
check('抓取成功后走在线表', impl.holidayOf(2026).source === 'online' && impl.holidayOf(2026).days.size === 33);
check('尚未公布的下一年记为空表、回落内置/估算', impl.holidayRemote.get(2027).days.size === 0 && impl.holidayOf(2027).source === 'estimated');
check('写入 localStorage 缓存（带版本号）', hStore.has(impl.HOLIDAY_KEY) && JSON.parse(hStore.get(impl.HOLIDAY_KEY)).v === 1);
const hSaved2026 = JSON.parse(hStore.get(impl.HOLIDAY_KEY)).years['2026'];
check('缓存内容含放假日与抓取时刻', hSaved2026.days['2026-10-01'] === '国庆节' && typeof hSaved2026.at === 'number');
impl.ensureHolidays(bj(2026, 3, 3, 10, 0));
await flushMicrotasks();
check('未过期时不重复请求', hCalls.length === 2, String(hCalls.length));

hCalls.length = 0;
impl.holidayRemote.clear();
globalThis.fetch = (url) => {
  hCalls.push(url);
  const year = hYearOf(url);
  if (url.includes('jsdelivr') && year === 2026) return Promise.resolve({ ok: false, text: () => Promise.resolve('') });
  return Promise.resolve({ ok: true, text: () => Promise.resolve(year === 2026 ? hFeed2026 : emptyFeed(year)) });
};
impl.ensureHolidays(bj(2026, 3, 3, 10, 0));
await flushMicrotasks();
check('第一个镜像失败时自动换第二个', hCalls.some((url) => url.includes('raw.githubusercontent.com') && hYearOf(url) === 2026), hCalls.join(' | '));
check('换镜像成功后仍走在线表', impl.holidayOf(2026).source === 'online');
check('两镜像都没内容的年份回落估算', impl.holidayOf(2027).source === 'estimated');

hCalls.length = 0;
const hKept = new Map([['2026-01-01', { key: 'newYear', raw: '元旦' }]]);
impl.holidayRemote.clear();
impl.holidayRemote.set(2026, { at: 1, days: hKept });
globalThis.fetch = (url) => {
  hCalls.push(url);
  return Promise.reject(new Error('offline'));
};
impl.ensureHolidays(bj(2026, 3, 3, 10, 0));
await flushMicrotasks();
check('全部镜像失败时保留旧数据', impl.holidayOf(2026).source === 'online' && impl.holidayOf(2026).days === hKept);
check('失败不刷新抓取时刻（下个周期还会再试）', impl.holidayRemote.get(2026).at === 1);
const hFailedCalls = hCalls.length;
impl.ensureHolidays(bj(2026, 3, 3, 10, 0));
await flushMicrotasks();
check('失败后标志复位、可以再次尝试', hCalls.length > hFailedCalls);

impl.holidayRemote.clear();
delete globalThis.fetch;
let hNoFetchThrew = false;
try {
  impl.ensureHolidays(bj(2026, 3, 3, 10, 0));
} catch (error) {
  hNoFetchThrew = true;
}
check('环境里没有 fetch 时静默跳过', hNoFetchThrew === false && impl.holidayRemote.size === 0);

const hInflight = [];
const hResolvers = [];
globalThis.fetch = (url) => {
  hInflight.push(url);
  return new Promise((resolve) => {
    hResolvers.push({ url: url, resolve: resolve });
  });
};
impl.ensureHolidays(bj(2026, 3, 3, 10, 0));
const hFirstRound = hInflight.length;
impl.ensureHolidays(bj(2026, 3, 3, 10, 0));
check('请求在飞时不重复发起', hInflight.length === hFirstRound && hFirstRound === 2, String(hInflight.length));
for (const item of hResolvers) {
  const year = hYearOf(item.url);
  item.resolve({ ok: true, text: () => Promise.resolve(year === 2026 ? hFeed2026 : emptyFeed(year)) });
}
await flushMicrotasks();
check('一轮结束后标志复位、结果落库', impl.holidayOf(2026).source === 'online');

const hSavedCache = JSON.stringify({ v: 1, years: { 2027: { at: 12345, days: { '2027-01-01': '元旦', '2027-01-02': '' } } } });
globalThis.localStorage = { getItem: (key) => (key === impl.HOLIDAY_KEY ? hSavedCache : null), setItem: () => {} };
impl.holidayRemote.clear();
impl.hydrateHolidays();
check('启动时从缓存恢复在线数据', impl.holidayOf(2027).source === 'online' && impl.holidayOf(2027).days.size === 2);
check('恢复时把中文名映射回词典 key', impl.holidayOf(2027).days.get('2027-01-01').key === 'newYear');
check('恢复时保留抓取时刻供 TTL 判定', impl.holidayRemote.get(2027).at === 12345);
check('恢复后 2027-01-01 直接判为空闲', impl.stateAt(bj(2027, 1, 1, 10, 0)).peak === false && impl.stateAt(bj(2027, 1, 1, 10, 0)).source === 'online');

impl.holidayRemote.clear();
globalThis.localStorage = { getItem: () => '{oops', setItem: () => {} };
let hHydrateThrew = false;
try {
  impl.hydrateHolidays();
} catch (error) {
  hHydrateThrew = true;
}
check('缓存损坏时静默忽略', hHydrateThrew === false && impl.holidayRemote.size === 0);
globalThis.localStorage = { getItem: () => JSON.stringify({ v: 2, years: { 2027: { at: 1, days: {} } } }), setItem: () => {} };
impl.hydrateHolidays();
check('缓存版本不符时忽略', impl.holidayRemote.size === 0);
delete globalThis.localStorage;
impl.hydrateHolidays();
check('没有 localStorage 时静默返回', impl.holidayRemote.size === 0);

impl.holidayRemote.set(2026, { at: 1, days: new Map() });
globalThis.localStorage = { getItem: () => null, setItem: () => { throw new Error('denied'); } };
let hPersistThrew = false;
try {
  impl.persistHolidays();
} catch (error) {
  hPersistThrew = true;
}
check('写缓存失败时静默忽略', hPersistThrew === false);

let hApplyFetches = 0;
globalThis.fetch = () => {
  hApplyFetches += 1;
  return Promise.resolve({ ok: false, text: () => Promise.resolve('') });
};
let hApplyThrew = false;
try {
  bundleExports.apply(fakeCtx);
} catch (error) {
  hApplyThrew = true;
}
await flushMicrotasks();
check('apply 阶段不发起网络请求', hApplyThrew === false && hApplyFetches === 0, String(hApplyFetches));

for (const key of ['tipSourceOnline', 'tipSourceBuiltIn', 'tipSourceEstimated']) {
  check('词典含 ' + key + '（中英）', typeof impl.ZH[key] === 'string' && typeof impl.EN[key] === 'string');
}
check(
  '数据来源提示表覆盖三种来源',
  Object.keys(impl.HOLIDAY_SOURCE_TIPS).length === 3 && impl.HOLIDAY_SOURCE_TIPS.estimated === 'tipSourceEstimated'
);

impl.holidayRemote.clear();
if (realStorage === undefined) delete globalThis.localStorage;
else globalThis.localStorage = realStorage;
globalThis.fetch = realFetch;
check('清理后回到内置表状态', impl.holidayOf(2026).source === 'builtIn' && impl.stateAt(bj(2026, 10, 1, 10, 0)).peak === false);

// ---------------------------------------------------------------- 8. 约束

group('8. 硬约束');

check('未 import Harness Client 包', /require\(\s*['"]@deepseek-ai\//.test(clientSrc) === false);
check('未直接操作 document', /\bdocument\./.test(clientSrc) === false);
check('CSS 不含 NaN', impl && impl.CSS.includes('NaN') === false, String(impl && impl.CSS).slice(0, 120));
const varTokens = Array.from(clientSrc.matchAll(/var\((--[a-z0-9-]+)/g)).map((match) => match[1]);
const badTokens = Array.from(new Set(varTokens.filter((token) => !token.startsWith('--dsw-') && !token.startsWith('--dsh-'))));
check('var() 只用 --dsw-* / --dsh-* token', badTokens.length === 0, badTokens.join(', '));
check('CSS 类名带自己的前缀', impl.CSS.includes('.' + 'pkv' + '_') && /^\.pkv_[a-z]+/.test(impl.CSS.trim()));
check('根元素用 flex order 排到上下文圆环右侧', /^\.pkv_root\{order:1/.test(impl.CSS), impl.CSS.slice(0, 60));
check('CSS 不含全价/半价旧文案', /全价|半价/.test(clientSrc) === false);

// ---------------------------------------------------------------- 结果

console.log('\n----------------------------------------');
console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项');
if (failures.length > 0) {
  console.log('\n失败明细：');
  for (const failure of failures) console.log('  - ' + failure);
  process.exit(1);
}
console.log('全部通过。');
process.exit(0);
