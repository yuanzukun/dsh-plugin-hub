/**
 * 峰谷时（Peak / Off-peak）—— DSH Web 输入栏下方工具栏里，紧挨「上下文占用圆环」
 * 右侧的时段徽标。
 *
 * 注册位置：`conversation.composer.dock`（输入卡片下方那一行）。宿主在该行里
 * 先渲染本插槽（list 型，条目按 slot `order` 排序），再把 `ContextMeter` 作为
 * 该 flex 容器的最后一个子项渲染；插槽外壳带 `display:contents`，所以条目元素
 * 自己就是 `.dock` 的 flex item。因此用 CSS `order:1` 即可把徽标排到上下文
 * 圆环右侧。
 *
 * 显示条件：当前会话模型必须走 DeepSeek（提供方或模型 id 含 "deepseek"）。
 * 模型信息来自 ui-model-selection 提供的 `ctx.modelDirectories` 服务；
 * 服务缺失或模型尚未解析时按「未知」处理，照常显示。
 *
 * 判定规则（固定北京时间 UTC+8，与本机时区、夏令时无关）：
 *   高峰时段 = 周一至周五（不含中国法定节假日）的 09:00-12:00 与 14:00-18:00
 *   空闲时段 = 其余一切时间，含周末全天与法定节假日全天
 *   空闲时段单价 = 高峰时段单价的 0.5x（高峰为 1x）
 *   倒计时单位统一为 d / h / m
 *
 * 节假日数据：运行时联网获取（NateScarlet/holiday-cn，内容来自国务院办公厅公告），
 * 结果缓存在浏览器 localStorage，未公布的下一年度会在公告发布后自动补上；
 * 取不到时依次降级为内置表（2026）与公历估算。
 * 参照用户规则，「调休上班的周末」仍按周末计为空闲时段。
 *
 * 该文件是可直接投递的客户端 bundle：host 的 Client 模块表提供 react，
 * 自身不 import 任何 Harness Client 包（含 ui-primitives）。
 */
window.__ModuleLoader__.load({
  id: 'dsh-peakvalley',
  factory(require) {
    const React = require('react');
    const h = React.createElement;

    const NS = 'dsh-peakvalley';
    const CLS = 'pkv';
    const BEIJING_OFFSET_MS = 8 * 60 * 60 * 1000;
    const MINUTE_MS = 60 * 1000;
    const DAY_MS = 24 * 60 * 60 * 1000;

    /** ui-model-selection 提供的会话级模型目录服务名。 */
    const MODEL_SERVICE = 'modelDirectories';

    /** 高峰窗口，北京时间当日分钟数，左闭右开。 */
    const PEAK_WINDOWS = [[9 * 60, 12 * 60], [14 * 60, 18 * 60]];
    /** 一天中所有可能的时段切换点（分钟数）：跨日 + 四个窗口边界。 */
    const SWITCH_EDGES = [0, 9 * 60, 12 * 60, 14 * 60, 18 * 60];
    /** 向后搜索切换点的最大天数（春节连休可达 9 天）。 */
    const MAX_LOOKAHEAD_DAYS = 15;

    /** 中国法定节假日：年 -> [起, 止, 词条 key]。 */
    const HOLIDAYS = {
      2026: [
        ['2026-01-01', '2026-01-03', 'newYear'],
        ['2026-02-15', '2026-02-23', 'springFestival'],
        ['2026-04-04', '2026-04-06', 'qingming'],
        ['2026-05-01', '2026-05-05', 'labour'],
        ['2026-06-19', '2026-06-21', 'dragonBoat'],
        ['2026-09-25', '2026-09-27', 'midAutumn'],
        ['2026-10-01', '2026-10-07', 'nationalDay'],
      ],
    };

    /** 未内置年份的保守估算：只覆盖公历日期固定的节假日。 */
    function estimatedHolidays(year) {
      return [
        [year + '-01-01', year + '-01-01', 'newYear'],
        [year + '-04-04', year + '-04-06', 'qingming'],
        [year + '-05-01', year + '-05-05', 'labour'],
        [year + '-10-01', year + '-10-07', 'nationalDay'],
      ];
    }

    // ---------------------------------------------------------------- 时间

    function pad2(value) {
      return String(value).padStart(2, '0');
    }

    /** 把毫秒时间戳换算成北京时间的日期与分钟数。 */
    function beijingOf(ms) {
      const date = new Date(ms + BEIJING_OFFSET_MS);
      const year = date.getUTCFullYear();
      const month = date.getUTCMonth() + 1;
      const day = date.getUTCDate();
      const hour = date.getUTCHours();
      const minute = date.getUTCMinutes();
      return {
        year: year,
        month: month,
        day: day,
        hour: hour,
        minute: minute,
        weekday: date.getUTCDay(),
        minuteOfDay: hour * 60 + minute,
        dateKey: year + '-' + pad2(month) + '-' + pad2(day),
      };
    }

    /** 把 [起, 止, key] 区间展开成 dateKey -> 词条 key 的映射。 */
    function expandRanges(ranges) {
      const map = new Map();
      for (let i = 0; i < ranges.length; i += 1) {
        const from = Date.parse(ranges[i][0] + 'T00:00:00Z');
        const to = Date.parse(ranges[i][1] + 'T00:00:00Z');
        const key = ranges[i][2];
        for (let cursor = from; cursor <= to; cursor += DAY_MS) {
          map.set(new Date(cursor).toISOString().slice(0, 10), key);
        }
      }
      return map;
    }

    // ------------------------------------------------------------ 节假日数据

    /**
     * 在线数据源。同一份数据集的多个镜像，按顺序尝试：
     * 1. jsDelivr（国内可直连、带 CORS 头）；2. raw.githubusercontent.com。
     * 数据仓库：NateScarlet/holiday-cn，逐年一份 <年>.json，内容取自国务院办公厅公告。
     */
    const HOLIDAY_FEEDS = [
      function (year) {
        return 'https://cdn.jsdelivr.net/gh/NateScarlet/holiday-cn@master/' + year + '.json';
      },
      function (year) {
        return 'https://raw.githubusercontent.com/NateScarlet/holiday-cn/master/' + year + '.json';
      },
    ];

    /** 在线数据的浏览器缓存键。 */
    const HOLIDAY_KEY = 'dsh-peakvalley.holidays';
    /** 单次请求超时（毫秒）。 */
    const HOLIDAY_TIMEOUT_MS = 8000;
    /** 已公布年份的复查间隔：30 天。 */
    const HOLIDAY_TTL_ANNOUNCED_MS = 30 * DAY_MS;
    /** 尚未公布年份的重试间隔：12 小时（公告一出，当天就能自动补上）。 */
    const HOLIDAY_TTL_PENDING_MS = 12 * 60 * 60 * 1000;
    /** 数据源里的中文节日名 -> 词典 key（未知名称原样显示）。 */
    const HOLIDAY_NAME_KEYS = {
      '元旦': 'newYear',
      '春节': 'springFestival',
      '清明节': 'qingming',
      '劳动节': 'labour',
      '端午节': 'dragonBoat',
      '中秋节': 'midAutumn',
      '国庆节': 'nationalDay',
    };
    /** 数据来源 -> 词典 key（提示里告知这年的节假日是哪来的）。 */
    const HOLIDAY_SOURCE_TIPS = {
      online: 'tipSourceOnline',
      builtIn: 'tipSourceBuiltIn',
      estimated: 'tipSourceEstimated',
    };

    /** 在线结果：年 -> { at: 抓取时刻, days: Map<dateKey, {key, raw}> }。 */
    const holidayRemote = new Map();
    /** 同一时刻只允许一轮请求在飞。 */
    let holidayFetching = false;
    const holidayBuiltInCache = new Map();
    const holidayEstimatedCache = new Map();

    function hasOwn(object, key) {
      return Object.prototype.hasOwnProperty.call(object, key);
    }

    /** 数据源 JSON -> dateKey 条目表；不是合法数据时返回 null（据此换镜像）。 */
    function parseHolidayFeed(year, text) {
      let payload = null;
      try {
        payload = JSON.parse(text);
      } catch (error) {
        return null;
      }
      if (payload === null || typeof payload !== 'object') return null;
      // 镜像可能落后或返回别的年份，年份不符一律不认。
      if (payload.year !== year) return null;
      if (!Array.isArray(payload.days)) return null;
      const days = new Map();
      for (let i = 0; i < payload.days.length; i += 1) {
        const day = payload.days[i];
        if (day === null || typeof day !== 'object') continue;
        // 只取放假日期；「调休上班」的周末按用户规则仍算空闲时段，故忽略。
        if (day.isOffDay !== true) continue;
        if (typeof day.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(day.date)) continue;
        const raw = typeof day.name === 'string' ? day.name : '';
        days.set(day.date, { key: hasOwn(HOLIDAY_NAME_KEYS, raw) ? HOLIDAY_NAME_KEYS[raw] : null, raw: raw });
      }
      return days;
    }

    /** 展开内置 / 估算区间为统一条目表（带缓存）。 */
    function rangeEntries(cache, year, ranges) {
      let entries = cache.get(year);
      if (entries === undefined) {
        entries = new Map();
        expandRanges(ranges).forEach(function (key, dateKey) {
          entries.set(dateKey, { key: key, raw: null });
        });
        cache.set(year, entries);
      }
      return entries;
    }

    /** 某一年的节假日条目：在线 > 内置 > 估算。 */
    function holidayOf(year) {
      const remote = holidayRemote.get(year);
      if (remote !== undefined && remote.days.size > 0) {
        return { days: remote.days, source: 'online' };
      }
      if (hasOwn(HOLIDAYS, year)) {
        return { days: rangeEntries(holidayBuiltInCache, year, HOLIDAYS[year]), source: 'builtIn' };
      }
      return { days: rangeEntries(holidayEstimatedCache, year, estimatedHolidays(year)), source: 'estimated' };
    }

    /** 从浏览器缓存恢复上次抓到的数据（同步，先用缓存渲染、再联网复查）。 */
    function hydrateHolidays() {
      try {
        if (typeof localStorage === 'undefined' || localStorage === null) return;
        const raw = localStorage.getItem(HOLIDAY_KEY);
        if (raw === null || raw === '') return;
        const stored = JSON.parse(raw);
        if (stored === null || typeof stored !== 'object') return;
        if (stored.v !== 1 || stored.years === null || typeof stored.years !== 'object') return;
        const years = Object.keys(stored.years);
        for (let i = 0; i < years.length; i += 1) {
          const year = Number(years[i]);
          const saved = stored.years[years[i]];
          if (!Number.isInteger(year) || saved === null || typeof saved !== 'object') continue;
          if (typeof saved.at !== 'number') continue;
          const names = saved.days === null || typeof saved.days !== 'object' ? {} : saved.days;
          const dateKeys = Object.keys(names);
          const days = new Map();
          for (let j = 0; j < dateKeys.length; j += 1) {
            const raw2 = names[dateKeys[j]];
            if (typeof raw2 !== 'string') continue;
            days.set(dateKeys[j], { key: hasOwn(HOLIDAY_NAME_KEYS, raw2) ? HOLIDAY_NAME_KEYS[raw2] : null, raw: raw2 });
          }
          holidayRemote.set(year, { at: saved.at, days: days });
        }
      } catch (error) {
        // 缓存损坏：忽略，等联网结果覆盖。
      }
    }

    /** 把在线结果写回浏览器缓存，供下次启动先用后刷。 */
    function persistHolidays() {
      try {
        if (typeof localStorage === 'undefined' || localStorage === null) return;
        const years = {};
        holidayRemote.forEach(function (entry, year) {
          const days = {};
          entry.days.forEach(function (value, dateKey) {
            days[dateKey] = value.raw === null ? '' : value.raw;
          });
          years[String(year)] = { at: entry.at, days: days };
        });
        localStorage.setItem(HOLIDAY_KEY, JSON.stringify({ v: 1, years: years }));
      } catch (error) {
        // 写入失败（配额、隐私模式）：忽略，只影响下次启动的首屏。
      }
    }

    /** 该年在线数据是否该复查：没数据，或已过 TTL（已公布 30 天 / 未公布 12 小时）。 */
    function holidayNeedsRefresh(year, now) {
      const entry = holidayRemote.get(year);
      if (entry === undefined) return true;
      const ttl = entry.days.size > 0 ? HOLIDAY_TTL_ANNOUNCED_MS : HOLIDAY_TTL_PENDING_MS;
      return now - entry.at >= ttl;
    }

    /** 依次尝试各镜像抓取某一年，全部失败返回 null。 */
    function fetchHolidayYear(year) {
      const urls = [];
      for (let i = 0; i < HOLIDAY_FEEDS.length; i += 1) {
        urls.push(HOLIDAY_FEEDS[i](year));
      }

      function attempt(index) {
        if (index >= urls.length) return Promise.resolve(null);
        const controller = typeof AbortController === 'function' ? new AbortController() : null;
        const timer = controller === null
          ? null
          : setTimeout(function () {
            controller.abort();
          }, HOLIDAY_TIMEOUT_MS);
        function done(text) {
          if (timer !== null) clearTimeout(timer);
          const days = text === '' ? null : parseHolidayFeed(year, text);
          return days === null ? attempt(index + 1) : days;
        }
        let request = null;
        try {
          request = fetch(urls[index], {
            cache: 'no-store',
            signal: controller === null ? undefined : controller.signal,
          });
        } catch (error) {
          return done('');
        }
        return Promise.resolve(request).then(function (response) {
          if (response === null || typeof response !== 'object' || response.ok !== true) return done('');
          return Promise.resolve(response.text()).then(done, function () {
            return done('');
          });
        }, function () {
          return done('');
        });
      }

      return attempt(0);
    }

    /**
     * 保证「本年 + 下一年」的节假日数据尽可能新；未过期时立即返回。
     *
     * 只在每秒的时钟 tick 里调用（不要在模块顶层或 apply 里调用）：数据变化靠下一次
     * 渲染自然反映，而校验脚本里没有 fetch 桩时也不会被拽去联网。
     */
    function ensureHolidays(now) {
      if (typeof fetch !== 'function' || holidayFetching) return;
      const year = beijingOf(now).year;
      const targets = [];
      for (let i = 0; i <= 1; i += 1) {
        if (holidayNeedsRefresh(year + i, now)) targets.push(year + i);
      }
      if (targets.length === 0) return;
      holidayFetching = true;
      const tasks = [];
      for (let i = 0; i < targets.length; i += 1) {
        const target = targets[i];
        tasks.push(fetchHolidayYear(target).then(function (days) {
          // 失败时保留旧数据（若有），宁可显示旧表也不要退回估算。
          if (days !== null) {
            holidayRemote.set(target, { at: Date.now(), days: days });
          }
        }, function () {}));
      }
      function finish() {
        holidayFetching = false;
        persistHolidays();
      }
      Promise.all(tasks).then(finish, finish);
    }

    // 模块加载时先读浏览器缓存，联网复查交给每秒的 tick。
    hydrateHolidays();

    /** 某一时刻的峰谷状态。 */
    function stateAt(ms) {
      const time = beijingOf(ms);
      const weekend = time.weekday === 0 || time.weekday === 6;
      const holiday = holidayOf(time.year);
      const entry = holiday.days.get(time.dateKey);
      let inWindow = false;
      for (let i = 0; i < PEAK_WINDOWS.length; i += 1) {
        if (time.minuteOfDay >= PEAK_WINDOWS[i][0] && time.minuteOfDay < PEAK_WINDOWS[i][1]) {
          inWindow = true;
        }
      }
      return {
        time: time,
        weekend: weekend,
        holiday: entry === undefined ? null : entry.key,
        holidayRaw: entry === undefined ? null : entry.raw,
        source: holiday.source,
        peak: !weekend && entry === undefined && inWindow,
      };
    }

    /** 下一次「高峰 <-> 空闲」切换的时刻，找不到时返回 null。 */
    function nextSwitch(ms) {
      const current = stateAt(ms).peak;
      const dayStart = ms - (beijingOf(ms).minuteOfDay * MINUTE_MS) - (ms % MINUTE_MS);
      for (let day = 0; day <= MAX_LOOKAHEAD_DAYS; day += 1) {
        for (let i = 0; i < SWITCH_EDGES.length; i += 1) {
          const at = dayStart + (day * DAY_MS) + (SWITCH_EDGES[i] * MINUTE_MS);
          if (at <= ms) {
            continue;
          }
          const peak = stateAt(at).peak;
          if (peak !== current) {
            return { at: at, peak: peak };
          }
        }
      }
      return null;
    }

    /** 剩余时长文案，单位固定 d / h / m，例如「8d23h」「1h51m」「45m」。 */
    function durationText(t, ms) {
      const totalMinutes = Math.max(0, Math.ceil(ms / MINUTE_MS));
      const days = Math.floor(totalMinutes / 1440);
      const hours = Math.floor((totalMinutes % 1440) / 60);
      const minutes = totalMinutes % 60;
      const parts = [];
      if (days > 0) {
        parts.push(days + t('unit.day'));
        if (hours > 0) {
          parts.push(hours + t('unit.hour'));
        }
      } else if (hours > 0) {
        parts.push(hours + t('unit.hour'));
        if (minutes > 0) {
          parts.push(minutes + t('unit.minute'));
        }
      } else {
        parts.push(minutes + t('unit.minute'));
      }
      return parts.join('').trim();
    }

    // ---------------------------------------------------------------- 模型

    /**
     * 当前会话是否在走 DeepSeek：提供方 id 或模型 id 含 "deepseek" 即算。
     * @param provider - 提供方 id，例如 deepseek-account / deepseek-official。
     * @param model - 模型 id，例如 deepseek-chat。
     * @returns 命中 DeepSeek 时为 true。
     */
    function isDeepSeek(provider, model) {
      return /deepseek/i.test(String(provider === undefined || provider === null ? '' : provider))
        || /deepseek/i.test(String(model === undefined || model === null ? '' : model));
    }

    /**
     * 读一次会话模型快照（纯读，不订阅；组件每秒重渲染时会顺带刷新）。
     * @param store - ui-model-selection 的会话目录 store。
     * @returns {provider, model}，无法判断时为 null。
     */
    function modelSnapshot(store) {
      if (store === undefined || store === null) {
        return null;
      }
      try {
        const snapshot = store.getSnapshot();
        const current = snapshot === undefined || snapshot === null ? null : snapshot.current;
        if (current === undefined || current === null) {
          return null;
        }
        return {
          provider: String(current.provider === undefined || current.provider === null ? '' : current.provider),
          model: String(current.model === undefined || current.model === null ? '' : current.model),
        };
      } catch (error) {
        return null;
      }
    }

    /**
     * 取会话的模型目录 store；服务缺失、会话未知等一律返回 null（按未知处理）。
     * @param ctx - 插件上下文。
     * @param sessionId - 插槽归属会话。
     * @returns store 或 null。
     */
    function directoryStore(ctx, sessionId) {
      if (sessionId === undefined || sessionId === null) {
        return null;
      }
      const service = ctx.get(MODEL_SERVICE);
      if (service === undefined || service === null) {
        return null;
      }
      try {
        const directory = service.directoryFor(sessionId);
        if (directory === undefined || directory === null || directory.store === undefined) {
          return null;
        }
        return directory.store;
      } catch (error) {
        return null;
      }
    }

    // -------------------------------------------------------------- 文案

    /**
     * 徽标各段文案与提示文案（纯函数，便于测试）。
     *
     * 三段信息彼此独立，按当前显示模式（LAYOUTS）取用：
     *   state = 是否空闲（高峰 / 空闲）
     *   rate  = 当前倍率（1x / 0.5x）
     *   eta   = 距下一次切换的倒计时（找不到切换点时为 ''）
     *
     * @param layout - 显示模式 id，只影响提示文案里的那一行说明。
     */
    function describe(ms, t, model, layout) {
      const state = stateAt(ms);
      const next = nextSwitch(ms);
      const label = t(state.peak ? 'period.peak' : 'period.valley');
      const price = t(state.peak ? 'price.peak' : 'price.valley');
      const eta = next === null ? '' : t(next.peak ? 'next.peak' : 'next.valley') + ' ' + durationText(t, next.at - ms);
      const tip = [t('tipTitle')];
      tip.push(t('tipNow') + ' ' + pad2(state.time.hour) + ':' + pad2(state.time.minute));
      tip.push(t('tipCurrent') + ' ' + label + ' · ' + price);
      if (state.holiday !== null) {
        tip.push(t('tipHoliday') + ' · ' + t('holiday.' + state.holiday));
      } else if (state.holidayRaw !== null) {
        // 数据源里出现了词典尚未收录的节日名，原样显示。
        tip.push(t('tipHoliday') + ' · ' + state.holidayRaw);
      } else if (state.weekend) {
        tip.push(t('tipWeekend'));
      }
      tip.push(t('tipRulePeak'));
      tip.push(t('tipRuleValley'));
      if (next !== null) {
        tip.push(eta);
      }
      if (model !== undefined && model !== null) {
        tip.push(t('tipModel') + ' ' + model.provider + '/' + model.model);
      }
      tip.push(t(HOLIDAY_SOURCE_TIPS[state.source] || 'tipSourceEstimated'));
      tip.push(t('tipLayout') + t('layout.' + layoutById(layout).id) + t('tipClick'));
      return { peak: state.peak, state: label, rate: price, eta: eta, tooltip: tip.join('\n') };
    }

    const ZH = {
      'period.peak': '高峰',
      'period.valley': '空闲',
      'price.peak': '1x',
      'price.valley': '0.5x',
      'next.peak': '距高峰',
      'next.valley': '距空闲',
      'unit.day': 'd',
      'unit.hour': 'h',
      'unit.minute': 'm',
      'tipTitle': '峰谷时（北京时间）',
      'tipNow': '当前时间',
      'tipCurrent': '当前时段',
      'tipWeekend': '今天是周末，全天空闲时段',
      'tipHoliday': '今天是法定节假日，全天空闲时段',
      'tipRulePeak': '高峰时段：工作日 09:00-12:00、14:00-18:00（不含法定节假日），单价 1x',
      'tipRuleValley': '空闲时段：其余全部时间，单价 0.5x',
      'tipModel': '当前模型',
      'tipSourceOnline': '节假日数据：已按国务院公告在线同步',
      'tipSourceBuiltIn': '节假日数据：插件内置表',
      'tipSourceEstimated': '节假日数据：公历估算（该年度安排尚未公布）',
      'tipLayout': '显示内容：',
      'tipClick': '（点击徽标可切换）',
      'layout.all': '全部',
      'layout.state': '仅时段',
      'layout.rate': '仅倍率',
      'layout.eta': '仅倒计时',
      'layout.stateRate': '时段 + 倍率',
      'layout.stateEta': '时段 + 倒计时',
      'layout.rateEta': '倍率 + 倒计时',
      'holiday.newYear': '元旦',
      'holiday.springFestival': '春节',
      'holiday.qingming': '清明节',
      'holiday.labour': '劳动节',
      'holiday.dragonBoat': '端午节',
      'holiday.midAutumn': '中秋节',
      'holiday.nationalDay': '国庆节',
    };

    const EN = {
      'period.peak': 'Peak',
      'period.valley': 'Off-peak',
      'price.peak': '1x',
      'price.valley': '0.5x',
      'next.peak': 'to peak',
      'next.valley': 'to off-peak',
      'unit.day': 'd',
      'unit.hour': 'h',
      'unit.minute': 'm',
      'tipTitle': 'Peak / off-peak (Beijing time)',
      'tipNow': 'Beijing time',
      'tipCurrent': 'Now',
      'tipWeekend': 'Weekend — off-peak all day',
      'tipHoliday': 'Statutory holiday — off-peak all day',
      'tipRulePeak': 'Peak: weekdays 09:00-12:00 and 14:00-18:00 (excluding statutory holidays), at 1x',
      'tipRuleValley': 'Off-peak: every other time, at 0.5x',
      'tipModel': 'Current model',
      'tipSourceOnline': 'Holiday data: synced online from the official announcement',
      'tipSourceBuiltIn': 'Holiday data: bundled with the plugin',
      'tipSourceEstimated': 'Holiday data: estimated (this year not published yet)',
      'tipLayout': 'Showing: ',
      'tipClick': ' (click the badge to switch)',
      'layout.all': 'everything',
      'layout.state': 'state only',
      'layout.rate': 'rate only',
      'layout.eta': 'countdown only',
      'layout.stateRate': 'state + rate',
      'layout.stateEta': 'state + countdown',
      'layout.rateEta': 'rate + countdown',
      'holiday.newYear': "New Year's Day",
      'holiday.springFestival': 'Spring Festival',
      'holiday.qingming': 'Qingming Festival',
      'holiday.labour': 'Labour Day',
      'holiday.dragonBoat': 'Dragon Boat Festival',
      'holiday.midAutumn': 'Mid-Autumn Festival',
      'holiday.nationalDay': 'National Day',
    };

    // ------------------------------------------------------------ 显示模式

    /**
     * 点击徽标循环切换的显示内容。
     *
     * 三段信息：state = 是否空闲、rate = 倍率、eta = 距下一次切换的倒计时。
     * 循环顺序：全部 → 三个单项 → 三个两两组合 → 回到全部。
     */
    const LAYOUTS = [
      { id: 'all', state: true, rate: true, eta: true },
      { id: 'state', state: true, rate: false, eta: false },
      { id: 'rate', state: false, rate: true, eta: false },
      { id: 'eta', state: false, rate: false, eta: true },
      { id: 'stateRate', state: true, rate: true, eta: false },
      { id: 'stateEta', state: true, rate: false, eta: true },
      { id: 'rateEta', state: false, rate: true, eta: true },
    ];

    /** 记住所选显示模式的 localStorage 键。 */
    const LAYOUT_KEY = 'dsh-peakvalley.layout';

    /** 下一档显示模式（循环）。 */
    function nextLayoutIndex(index) {
      return (index + 1) % LAYOUTS.length;
    }

    /** 按 id 取显示模式；id 缺失或非法（例如旧版本存下的值）时回退「全部」。 */
    function layoutById(id) {
      for (let i = 0; i < LAYOUTS.length; i += 1) {
        if (LAYOUTS[i].id === id) {
          return LAYOUTS[i];
        }
      }
      return LAYOUTS[0];
    }

    /**
     * 读上次选的显示模式。localStorage 在隐私模式或被宿主禁用时会抛异常，
     * 存的值也可能过期，这两种情况都回到第一档「全部」。
     */
    function readLayoutIndex() {
      try {
        if (typeof localStorage === 'undefined' || localStorage === null) {
          return 0;
        }
        const saved = localStorage.getItem(LAYOUT_KEY);
        for (let i = 0; i < LAYOUTS.length; i += 1) {
          if (LAYOUTS[i].id === saved) {
            return i;
          }
        }
      } catch (error) {
        return 0;
      }
      return 0;
    }

    /** 记住显示模式；写失败就静默忽略，下次打开回到默认档。 */
    function writeLayoutIndex(index) {
      try {
        if (typeof localStorage !== 'undefined' && localStorage !== null) {
          localStorage.setItem(LAYOUT_KEY, LAYOUTS[index].id);
        }
      } catch (error) {
        /* 存储不可用不影响显示 */
      }
    }

    // ---------------------------------------------------------------- 视图

    /** 盒子收放时长（毫秒）：进场就是它，退场另有 EXIT_MS。 */
    const ANIM_MS = 260;
    /** 统一缓动：起手快、收尾稳，比 linear/ease 更有「重量感」。 */
    const EASE = 'cubic-bezier(.4,0,.2,1)';
    /** 退场错峰（毫秒）：文字先隐，空盒子晚这么久才开始收。 */
    const EXIT_LAG = 40;
    /** 退场时盒子收放的时长（毫秒）。 */
    const EXIT_MS = 220;
    /** 退场后继续挂载多久（毫秒）：必须 > EXIT_LAG + EXIT_MS，动画才播得完。 */
    const UNMOUNT_MS = ANIM_MS + 60;
    /**
     * 系统开启「减少动态效果」时的收放时长（毫秒）。
     *
     * 这里**不能**写成 `transition:none`：宽度一瞬间归零会让同一行的其它条目「跳」
     * 到新位置，那本身就是一种很生硬的动效（用户反馈过）。Windows 关掉「显示动画」
     * 时 Chromium 就会报 reduce，所以这条路径很可能才是用户实际看到的那条。
     * 折中做法：把收放压到 SHORT_MS 并去掉位移，动效变小但不消失。
     */
    const SHORT_MS = 140;

    /** 换显示内容时，内容先淡出的时长（毫秒）；之后才换文案并让盒子宽度过渡过去。 */
    const SWAP_OUT_MS = 90;

    const CSS = [
      // order:1 —— 宿主把 ContextMeter 渲染成同一个 flex 容器的最后一个子项，
      // 徽标要排到它右侧，只能靠 flex order 越过默认的 0。
      // width:auto + interpolate-size 让宽度也能在 auto 与 0 之间做过渡
      // （宿主 Electron 44 / Chromium 152 已支持）。
      '.' + CLS + '_root{order:1;display:inline-flex;align-items:center;flex:none;max-width:100%;',
      'overflow:hidden;width:auto;interpolate-size:allow-keywords;',
      'padding:1px 8px;border-radius:999px;',
      'font-size:var(--dsh-content-font-size-secondary,13px);',
      'line-height:calc(20px + var(--dsh-content-font-delta-secondary,0px));',
      'font-variant-numeric:tabular-nums;white-space:nowrap;cursor:pointer;user-select:none;',
      // 盒子只承担「几何」：宽度、内边距、外边距、边框宽度一起收放。
      // 只淡出透明度是不够的——文字本身占的那段宽度会瞬间消失，同一行的其它条目
      // 就会「跳」到新位置；把宽度一起收掉，它们才会平滑地跟着挪。
      // margin-right 的 -12px 正好抵掉宿主 .dock 的 gap:12px，让宽度真正收到 0。
      'transition:width ' + ANIM_MS + 'ms ' + EASE + ',padding ' + ANIM_MS + 'ms ' + EASE + ',',
      'margin ' + ANIM_MS + 'ms ' + EASE + ',border-width ' + ANIM_MS + 'ms ' + EASE + '}',
      '.' + CLS + '_root{transform-origin:right center}',
      // 文字独占一层：淡入淡出与位移都由它自己承担，永远不被父层的 overflow 切成半个字。
      '.' + CLS + '_inner{display:inline-flex;align-items:center;gap:6px;flex:none;white-space:nowrap;',
      // 进场：先让盒子长出来，过 110ms 才让文字浮现（内容晚于容器），
      // 所以文字出现时宽度已经够用，不会有裁切感。
      'transition:opacity 170ms ease 110ms,transform 240ms ' + EASE + ' 60ms}',
      '.' + CLS + '_enter{width:0;padding-left:0;padding-right:0;margin-right:-12px;',
      'border-left-width:0;border-right-width:0}',
      '.' + CLS + '_enter .' + CLS + '_inner{opacity:0;transform:translateX(6px)}',
      // 退场反过来：文字先用 100ms 彻底隐掉，空盒子再延迟 EXIT_LAG 才开始收，
      // 于是「收」这个动作全程发生在没有文字的空盒子上，观感干净。
      '.' + CLS + '_exit{width:0;padding-left:0;padding-right:0;margin-right:-12px;',
      'border-left-width:0;border-right-width:0;',
      'transition:width ' + EXIT_MS + 'ms ' + EASE + ' ' + EXIT_LAG + 'ms,',
      'padding ' + EXIT_MS + 'ms ' + EASE + ' ' + EXIT_LAG + 'ms,',
      'margin ' + EXIT_MS + 'ms ' + EASE + ' ' + EXIT_LAG + 'ms,',
      'border-width ' + EXIT_MS + 'ms ' + EASE + ' ' + EXIT_LAG + 'ms}',
      '.' + CLS + '_exit .' + CLS + '_inner{opacity:0;transform:translateX(6px);',
      'transition:opacity 100ms ease,transform 150ms ease}',
      // 换显示内容（点击切换）：先把内容淡掉、盒子原地不动；淡完 JS 才换文案并把宽度
      // 交给上面的过渡去接管（不先钉住像素宽度，auto→auto 之间浏览器看不到「变化」，
      // 根本不会插值，同一行的其它条目又会「跳」）。
      '.' + CLS + '_switch .' + CLS + '_inner{opacity:0;transition:opacity ' + SWAP_OUT_MS + 'ms ease}',
      // 悬停 / 键盘聚焦：给一点点底色，让人看得出这东西能点。用 currentColor 混色，
      // 不依赖任何未记录的宿主 token。
      '.' + CLS + '_root:hover,.' + CLS + '_root:focus-visible{',
      'background:color-mix(in srgb,currentColor 14%,transparent)}',
      // 系统的「减少动态效果」：收放压到 SHORT_MS、去掉位移，但**绝不写成 transition:none**。
      // 宽度瞬移会让同一行的其它条目「跳」过去——那正是用户抱怨的「很生硬」。
      // （Windows 关掉「显示动画」时 Chromium 即报 reduce，这条路径很可能就是用户看到的。）
      '@media (prefers-reduced-motion:reduce){',
      '.' + CLS + '_root,.' + CLS + '_exit{transition:width ' + SHORT_MS + 'ms linear,padding ' + SHORT_MS + 'ms linear,',
      'margin ' + SHORT_MS + 'ms linear,border-width ' + SHORT_MS + 'ms linear}',
      // 内容仍然「后显 / 先隐」：盒子长到一半文字才浮现，避免被裁成半个字。
      '.' + CLS + '_inner{transition:opacity 70ms linear 70ms}',
      '.' + CLS + '_switch .' + CLS + '_inner{transition:opacity 60ms linear}',
      '.' + CLS + '_exit .' + CLS + '_inner{transition:opacity 60ms linear}',
      '.' + CLS + '_enter .' + CLS + '_inner,.' + CLS + '_exit .' + CLS + '_inner{transform:none}}',
      '.' + CLS + '_dot{flex:none;width:6px;height:6px;border-radius:50%;background:currentColor}',
      '.' + CLS + '_period{flex:none;color:currentColor}',
      // 单段显示时用当前色（时段自己的颜色），多段时次级信息压暗，主次分明。
      '.' + CLS + '_piece{flex:none}',
      '.' + CLS + '_sep{flex:none;color:var(--dsw-alias-label-tertiary)}',
      '.' + CLS + '_rest{flex:none;color:var(--dsw-alias-label-tertiary)}',
      '.' + CLS + '_peak{color:var(--dsw-alias-state-warn-primary,var(--dsw-alias-label-secondary))}',
      '.' + CLS + '_valley{color:var(--dsw-alias-state-success-primary,var(--dsw-alias-label-secondary))}',
    ].join('');

    /** 每秒走一次的时钟状态；组件卸载时自动清理定时器。 */
    function useNow() {
      const [now, setNow] = React.useState(function () {
        return Date.now();
      });
      React.useEffect(function () {
        // 每秒顺手复查一次节假日数据：未过期时是空操作；国务院公告发布后，最迟一个
        // 重试周期（12 小时）内自动补上。放在 tick 里而不是挂载时，是为了让校验脚本
        // 在没有 fetch 桩的情况下也不会被拽去联网。
        const timer = setInterval(function () {
          const at = Date.now();
          setNow(at);
          ensureHolidays(at);
        }, 1000);
        return function () {
          clearInterval(timer);
        };
      }, []);
      return now;
    }

    /**
     * 进场 / 退场的挂载状态。
     *
     * React 里不能靠 `return null` 直接卸载节点——那样 DOM 一瞬间就没了，动画无从谈起。
     * 所以这里「保持挂载」：目标状态变 false 时继续挂着、让过渡跑完再卸载；半途又变回
     * true 就取消卸载、直接回到常态。
     *
     * phase 完全由 state 推导（不另存一份），否则两个 state 容易不同步、卡在 exit。
     * 依赖里必须带上 visible：它只是布尔值，每秒一次的时钟重渲染不会造成重复触发。
     *
     * @param visible - 是否应当显示。
     * @returns {mounted, phase}，phase 为 'enter' | 'live' | 'exit' | null。
     */
    function usePresence(visible) {
      const [mounted, setMounted] = React.useState(visible);
      const [entering, setEntering] = React.useState(true);

      // 目标状态与挂载状态不一致时：要么开始进场，要么起一个退场计时器。
      React.useEffect(function () {
        if (visible === mounted) {
          return undefined;
        }
        if (visible) {
          setMounted(true);
          setEntering(true);
          return undefined;
        }
        const timer = setTimeout(function () {
          setMounted(false);
        }, UNMOUNT_MS);
        return function () {
          clearTimeout(timer);
        };
      }, [mounted, visible]);

      // 进场：等两帧才摘掉 pkv_enter，盒子的 width/padding/margin/border 与文字的
      // opacity/transform 才开始插值。只等一帧不够——React 这次提交要到下一个任务才
      // flush，那一帧浏览器还没机会按初始状态画过一次，transition 会被直接跳过
      // （表现就是「没有动画」）。
      React.useEffect(function () {
        if (!mounted || !entering) {
          return undefined;
        }
        let inner = null;
        const outer = requestAnimationFrame(function () {
          inner = requestAnimationFrame(function () {
            setEntering(false);
          });
        });
        return function () {
          cancelAnimationFrame(outer);
          if (inner !== null) {
            cancelAnimationFrame(inner);
          }
        };
      }, [mounted, entering]);

      let phase = null;
      if (mounted) {
        phase = visible ? (entering ? 'enter' : 'live') : 'exit';
      }
      return { mounted: mounted, phase: phase };
    }

    function PeakValleyBadge(props) {
      const t = props.t;
      const now = useNow();
      // 当前显示内容（0 = 全部），以及一次「换内容」的两阶段序号。
      const [layoutIndex, setLayoutIndex] = React.useState(readLayoutIndex);
      const [swapSeq, setSwapSeq] = React.useState(0);
      const rootRef = React.useRef(null);
      const swapFrom = React.useRef(0);
      const swapTo = React.useRef(0);
      const pinned = React.useRef(false);
      // 与时钟同一个 1 秒节拍读模型信息，无需额外订阅。
      const model = modelSnapshot(props.modelStore);
      // 「未知」照常显示，只有确认不是 DeepSeek 才隐藏（然后走退场动画）。
      const shouldShow = model === null || isDeepSeek(model.provider, model.model);
      const presence = usePresence(shouldShow);

      // 第二阶段：内容已经淡没了，这时才换文案（同一批次里把宽度交给过渡去接管）。
      React.useEffect(function () {
        if (swapSeq === 0) {
          return undefined;
        }
        const timer = setTimeout(function () {
          pinned.current = true;
          setLayoutIndex(swapTo.current);
          writeLayoutIndex(swapTo.current);
          setSwapSeq(0);
        }, SWAP_OUT_MS);
        return function () {
          clearTimeout(timer);
        };
      }, [swapSeq]);

      // 换文案的那次提交还没绘制：先把盒子钉在切换前的像素宽度，两帧后再放开成
      // width:auto。`auto` 到 `auto` 之间浏览器看不到「变化」，不会插值——必须先钉出
      // 一个像素旧值，宽度才会真的动起来，同一行的邻居才会平滑地跟着挪。
      React.useLayoutEffect(function () {
        const el = rootRef.current;
        if (el === null || !pinned.current) {
          return undefined;
        }
        pinned.current = false;
        el.style.width = swapFrom.current + 'px';
        let inner = null;
        const outer = requestAnimationFrame(function () {
          inner = requestAnimationFrame(function () {
            el.style.width = '';
          });
        });
        return function () {
          cancelAnimationFrame(outer);
          if (inner !== null) {
            cancelAnimationFrame(inner);
          }
          // 一定要还回去，否则内联的固定宽度会压住 _enter/_exit 的 width:0。
          el.style.width = '';
        };
      }, [swapSeq]);

      /** 换下一档显示内容：内容先淡出，淡完再换文案、再让盒子宽度过渡过去。 */
      function cycle() {
        const el = rootRef.current;
        // 连点要能连着往下走：基准是「已经在路上的那一档」，而不是屏幕上还没变的那档。
        const from = swapSeq === 0 ? layoutIndex : swapTo.current;
        swapTo.current = nextLayoutIndex(from);
        if (el === null) {
          setLayoutIndex(swapTo.current);
          writeLayoutIndex(swapTo.current);
          return;
        }
        swapFrom.current = el.getBoundingClientRect().width;
        setSwapSeq(swapSeq + 1);
      }

      function onKeyDown(event) {
        if (event.key === 'Enter' || event.key === ' ' || event.key === 'Spacebar') {
          event.preventDefault();
          cycle();
        }
      }

      if (presence.phase === null) {
        return null;
      }
      const layout = LAYOUTS[layoutIndex];
      const view = describe(now, t, model, layout.id);
      let rootClass = CLS + '_root ' + (view.peak ? CLS + '_peak' : CLS + '_valley');
      if (presence.phase !== 'live') {
        rootClass += ' ' + CLS + '_' + presence.phase;
      }
      if (swapSeq !== 0) {
        rootClass += ' ' + CLS + '_switch';
      }

      // 圆点恒显示；三段文字按当前模式取舍，分隔符只插在相邻两段之间。
      const body = [h('span', { key: 'dot', className: CLS + '_dot', 'aria-hidden': 'true' })];
      function addPiece(key, className, text) {
        if (body.length > 1) {
          body.push(h('span', { key: 'sep.' + key, className: CLS + '_sep', 'aria-hidden': 'true' }, '·'));
        }
        body.push(h('span', { key: key, className: className }, text));
      }
      if (layout.state) {
        addPiece('state', CLS + '_period', view.state);
      }
      // 时段也在显示时，倍率与倒计时是次级信息，压暗一档。
      const muted = layout.state;
      const subClass = CLS + '_piece' + (muted ? ' ' + CLS + '_rest' : '');
      if (layout.rate) {
        addPiece('rate', subClass, view.rate);
      }
      if (layout.eta && view.eta !== '') {
        addPiece('eta', subClass, view.eta);
      }
      // 兜底：万一段落全空（比如某档只剩倒计时、而查不到下一次切换），至少显示时段，
      // 不留下一个只有圆点的空壳。
      if (body.length === 1) {
        addPiece('state', CLS + '_period', view.state);
      }

      return h(
        React.Fragment,
        null,
        h('style', { key: 'style' }, CSS),
        h(
          'span',
          {
            key: 'badge',
            ref: rootRef,
            className: rootClass,
            title: view.tooltip,
            role: 'button',
            tabIndex: 0,
            onClick: cycle,
            onKeyDown: onKeyDown,
          },
          h.apply(null, ['span', { className: CLS + '_inner' }].concat(body))
        )
      );
    }

    /** 插槽渲染入口：优先用插槽注入的 t，回退到 apply 里绑定的 t。 */
    function render(ownerProps) {
      const injected = ownerProps && typeof ownerProps.t === 'function' ? ownerProps.t : render.fallbackT;
      return h(PeakValleyBadge, {
        t: injected,
        modelStore: ownerProps ? ownerProps.modelStore : null,
      });
    }

    // -------------------------------------------------------------- 插件

    const plugin = {
      inject: ['slots', 'locale'],
      apply: function apply(ctx) {
        ctx.effect(function () {
          return ctx.locale.register(NS, { zh: ZH, en: EN });
        }, NS + ': dictionaries');
        const t = ctx.locale.bind(NS);
        render.fallbackT = t;
        ctx.slots.inject('conversation.composer.dock', function () {
          return ctx.slots.register(
            {
              name: 'conversation.composer.dock',
              id: 'peakvalley',
              order: 20,
              locale: NS,
              inject: function (sessionId) {
                return { t: t, modelStore: directoryStore(ctx, sessionId) };
              },
            },
            render
          );
        });
      },
    };

    // 供 dev 校验脚本读取的内部实现，非枚举以免影响宿主对导出形状的判断。
    Object.defineProperty(plugin, '__peakvalley', {
      value: {
        describe: describe,
        stateAt: stateAt,
        nextSwitch: nextSwitch,
        durationText: durationText,
        beijingOf: beijingOf,
        parseHolidayFeed: parseHolidayFeed,
        holidayOf: holidayOf,
        holidayNeedsRefresh: holidayNeedsRefresh,
        ensureHolidays: ensureHolidays,
        hydrateHolidays: hydrateHolidays,
        persistHolidays: persistHolidays,
        holidayRemote: holidayRemote,
        estimatedHolidays: estimatedHolidays,
        HOLIDAYS: HOLIDAYS,
        HOLIDAY_FEEDS: HOLIDAY_FEEDS,
        HOLIDAY_KEY: HOLIDAY_KEY,
        HOLIDAY_NAME_KEYS: HOLIDAY_NAME_KEYS,
        HOLIDAY_SOURCE_TIPS: HOLIDAY_SOURCE_TIPS,
        HOLIDAY_TIMEOUT_MS: HOLIDAY_TIMEOUT_MS,
        HOLIDAY_TTL_ANNOUNCED_MS: HOLIDAY_TTL_ANNOUNCED_MS,
        HOLIDAY_TTL_PENDING_MS: HOLIDAY_TTL_PENDING_MS,
        isDeepSeek: isDeepSeek,
        modelSnapshot: modelSnapshot,
        usePresence: usePresence,
        ANIM_MS: ANIM_MS,
        UNMOUNT_MS: UNMOUNT_MS,
        EXIT_MS: EXIT_MS,
        EXIT_LAG: EXIT_LAG,
        EASE: EASE,
        SHORT_MS: SHORT_MS,
        LAYOUTS: LAYOUTS,
        LAYOUT_KEY: LAYOUT_KEY,
        nextLayoutIndex: nextLayoutIndex,
        readLayoutIndex: readLayoutIndex,
        writeLayoutIndex: writeLayoutIndex,
        SWAP_OUT_MS: SWAP_OUT_MS,
        // 组件本体：让校验脚本能把 React 桩对准它做进出场时序测试。
        __component: PeakValleyBadge,
        ZH: ZH,
        EN: EN,
        CSS: CSS,
      },
      enumerable: false,
    });

    return plugin;
  },
});
