/**
 * 峰谷时的 Host 半边。
 *
 * 该 bundle 的可见部分全部由客户端模块（./client.js）渲染：它注册到
 * `conversation.composer.dock`，即输入卡片下方那一行。Host 侧不需要服务、
 * 工具或会话状态，因此 apply 为空实现。
 */
export function apply() {}
