import { createRequire } from 'node:module'

const m = await import('file:///D:/tools/deepsek_harness/dsh-prompt-optimizer/src/index.js')

let handler = null
let seenOptions = null
const fakeLlm = {
	listProviders: () => [{ provider: 'p1' }],
	listModels: async () => [{ model: 'm1' }],
	stream: async function* (options) {
		seenOptions = options
		yield { type: 'block-start', index: 0, blockType: 'text' }
		yield { type: 'text-delta', index: 0, text: '优化后的提示词' }
		yield { type: 'block-end', index: 0, block: { type: 'text', text: 'x' } }
		yield { type: 'finish', reason: { kind: 'stop' } }
	}
}

// Outer ctx: accessing .llm/.commands must throw (simulating cordis' inject gate).
const outerCtx = new Proxy({}, {
	get(target, prop) {
		if (prop === 'inject') {
			return (names, fn) => fn({
				llm: fakeLlm,
				commands: { register: (d) => { handler = d.handler } }
			})
		}
		if (prop === 'llm' || prop === 'commands') {
			throw new Error(`cannot get property "${prop}" without inject`)
		}
		return target[prop]
	}
})

m.apply(outerCtx, {})
const result = await handler({
	agent: { session: { events: [], id: 's1' } },
	rawInput: ' ' + JSON.stringify({ text: '帮我写个脚本' }),
	signal: undefined
})
console.log('result:', JSON.stringify(result))
console.log('reasoningEffort passed:', seenOptions?.reasoningEffort)
if (result.kind === 'success' && result.text === '优化后的提示词' && seenOptions?.reasoningEffort === 'low') {
	console.log('PASS')
} else {
	console.log('FAIL')
	process.exit(1)
}
