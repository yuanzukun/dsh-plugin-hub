# dsh-prompt-optimizer

DeepSeek Harness (DSH) Web 插件：输入框工具栏的「一键优化提示词」按钮 + 长文本输入/编辑增强。

## 功能

1. **一键优化提示词**：在输入框工具行（发送按钮左侧）新增「优化」按钮。
   - 点击后读取当前草稿，通过宿主端 `/optimize` 命令执行**一次辅助 LLM 调用**（不进入会话模型历史），把草稿重写为结构更清晰的提示词，并**直接写回输入框**。
   - 优化面向 **DSH coding agent 场景**：重写目标是「agent 可在工作区内可靠执行的指令」——文件路径/标识符等语境细节逐字保留，U+FFFC 附件/引用占位符原位透传（宿主会重新绑定，改写会破坏绑定），结构惯例跟随草稿作者语言而非强加英文范式，并要求指令带有 agent 可校验的完成判据。
   - 优化调用默认使用**低思考等级（`reasoningEffort: low`）**以加快速度；可在配置中设为 `off` 完全关闭思考（最快），或 `high` / `max` 换取更细致的重写质量。
   - 模型路由按优先级解析：会话当前选择的模型 → 会话日志中最近一次请求的路由（`request/header`）→ 第一个可用 provider。也可在 `cordis.patch.yml` 中显式固定 `provider` + `model`。
   - 也可以手动使用：`/optimize <草稿文本>`。
2. **长文本支持**（输入框架构修复）：
   - 修复 composer 的长文本缺陷：框架的 `<textarea>` 用了 `height:100%`，但 textarea 是 replaced 元素，在高度为 auto 的父容器里会回退到固有 2 行高度（约 52px），导致长文本只有顶部两行可编辑。本插件用 `ResizeObserver` 把 textarea 的显式像素高度同步为隐藏 mirror 元素（框架用来精确撑高的镜像）的高度，恢复「textarea 铺满全文 → 滚动容器裁切/滚动」的预期架构；
   - 输入框文本区最大高度由 336px 提升到 `min(55vh, 600px)`；
   - 输入框内 **Tab / Shift+Tab** 插入/删除两空格缩进，多行选择时按块整体缩进/反缩进，便于编辑结构化长文本。

## 配置（cordis.patch.yml）

| 键 | 默认 | 说明 |
|---|---|---|
| `provider` / `model` | 未设置 | 显式固定优化调用的模型路由（需成对提供） |
| `reasoningEffort` | `low` | 优化调用的思考等级：`off`（不思考，最快）/ `low` / `high` / `max` |
| `maxInputChars` | 200000 | 草稿最大字符数 |
| `maxOutputTokens` | 8192 | 重写结果输出上限 |
| `timeoutMs` | 120000 | 单次优化调用超时 |

## 安装（web profile）

1. 通过 GitHub 仓库地址安装（自动完成安装并加入 profile 的 bundles 层列表）：
   ```sh
   dsh plugin --profile web add github:wangyuanchuan2022/dsh-prompt-optimizer
   ```
2. 重启 `dsh web` 并刷新页面。

> 也可使用完整 Git URL：`dsh plugin --profile web add https://github.com/wangyuanchuan2022/dsh-prompt-optimizer.git`。
> 后续更新：`dsh plugin --profile web update dsh-prompt-optimizer`。

## 结构

- `src/index.js` — 宿主端：注册 `/optimize` 命令，`ctx.llm.stream` 单次辅助调用。
- `lib/client.js` — 浏览器端：`conversation.input.right` 槽按钮 + CSS/键盘长文本增强。
- `cordis.patch.yml` — 宿主行与配置。

## 局限

- 草稿包含附件/引用占位符（U+FFFC chip）时按钮禁用（重写会破坏 chip 与 occurrence 表的对应关系）。
- 优化结果通过 `inputActions.setDraft` 整体替换草稿；撤销（输入机 undo）可回退。
