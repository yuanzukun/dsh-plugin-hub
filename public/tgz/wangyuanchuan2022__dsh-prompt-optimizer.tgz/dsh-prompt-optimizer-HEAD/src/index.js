/**
 * dsh-prompt-optimizer — host half.
 *
 * Registers the global `/optimize` command. The handler runs ONE auxiliary
 * LLM call through `ctx.llm.stream` (never submitted to the session's model
 * history) and returns the rewritten prompt as the command result, which the
 * browser button writes back into the composer draft.
 *
 * Payload contract: the Web client sends JSON on the command line:
 *   /optimize {"text":"draft…","provider":"…","model":"…"}
 * A human typing plain text after the command is also accepted (the raw input
 * is then treated as the draft itself).
 */

export const name = 'dsh-prompt-optimizer'

const PLUGIN_SOURCE = { kind: 'plugin', plugin: 'dsh-prompt-optimizer' }

const SYSTEM_PROMPT = [
	'You are a senior prompt engineer for AI coding assistants.',
	'Rewrite the user’s draft prompt so a coding agent can execute it reliably in its workspace. The rewritten text replaces the draft in the agent’s input box verbatim and is sent as-is, so it must be complete and self-contained. Follow these rules strictly:',
	'1. Keep the author’s language and intent. Never invent, drop, or silently soften requirements.',
	'2. Preserve every concrete detail verbatim: file paths, identifiers, error messages, constraints, examples, and expected outputs. If the draft contains U+FFFC object-replacement characters, copy each one through in place — they are attachment/reference tokens the host re-binds, and altering them breaks the binding.',
	'3. Restructure for clarity: a one-line goal first, then background/context, then concrete requirements or numbered steps, then the expected output format, and finally edge cases or acceptance criteria when applicable. Match the structural conventions of the author’s own language rather than imposing English boilerplate.',
	'4. Make implicit assumptions explicit; remove redundancy and ambiguity; prefer imperative, verifiable statements with a clear completion criterion the agent can check.',
	'5. Keep the result proportionate to the input — do not pad a short prompt with boilerplate, and do not compress a detailed specification.',
	'Return the optimized prompt as plain text only — it is used verbatim as the new draft, so the reply must contain nothing besides the prompt itself.'
].join('\n')

/** Validate config and apply deployment defaults. */
function resolveConfig(raw) {
	const value = raw === null || typeof raw !== 'object' ? {} : raw
	const positive = (key, fallback) => {
		const n = value[key]
		if (n === undefined) return fallback
		if (!Number.isInteger(n) || n <= 0) throw new Error(`dsh-prompt-optimizer: ${key} must be a positive integer`)
		return n
	}
	const route =
		value.provider !== undefined || value.model !== undefined
			? { provider: value.provider, model: value.model }
			: undefined
	if (route !== undefined) {
		if (typeof route.provider !== 'string' || route.provider.length === 0 ||
			typeof route.model !== 'string' || route.model.length === 0) {
			throw new Error('dsh-prompt-optimizer: provider and model must be non-empty strings and supplied together')
		}
	}
	const reasoningEffort = value.reasoningEffort === undefined ? 'low' : value.reasoningEffort
	if (typeof reasoningEffort !== 'string' || !['off', 'low', 'high', 'max'].includes(reasoningEffort)) {
		throw new Error('dsh-prompt-optimizer: reasoningEffort must be one of "off" | "low" | "high" | "max"')
	}
	return {
		route,
		reasoningEffort,
		maxInputChars: positive('maxInputChars', 200_000),
		maxOutputTokens: positive('maxOutputTokens', 8192),
		timeoutMs: positive('timeoutMs', 120_000)
	}
}

/** Parse rawInput: JSON payload {text, provider?, model?}, or plain text. */
function parseInput(rawInput) {
	const trimmed = rawInput.trim()
	if (trimmed === '') return { text: '' }
	if (trimmed.startsWith('{')) {
		try {
			const parsed = JSON.parse(trimmed)
			if (parsed !== null && typeof parsed === 'object' && typeof parsed.text === 'string') {
				const route =
					typeof parsed.provider === 'string' && parsed.provider !== '' &&
					typeof parsed.model === 'string' && parsed.model !== ''
						? { provider: parsed.provider, model: parsed.model }
						: undefined
				return { text: parsed.text, route }
			}
		} catch {
			/* fall through to plain-text treatment */
		}
	}
	return { text: rawInput }
}

/** Provider/model captured by the latest request/header in the session log. */
function lastLoggedRoute(agent) {
	const events = agent?.session?.events
	if (!Array.isArray(events)) return undefined
	for (let i = events.length - 1; i >= 0; i -= 1) {
		const event = events[i]
		if (event?.type !== 'request/header') continue
		const config = event?.data?.header?.config
		if (typeof config?.provider === 'string' && typeof config?.model === 'string' && config.provider !== '') {
			return { provider: config.provider, model: config.model }
		}
		return undefined
	}
	return undefined
}

/** First registered provider that currently advertises at least one model. */
async function firstAvailableRoute(llm) {
	for (const info of llm.listProviders()) {
		const provider = info?.provider ?? info?.name ?? info?.id
		if (typeof provider !== 'string' || provider === '') continue
		try {
			const models = await llm.listModels(provider)
			const model = models.find((entry) => typeof (entry?.model ?? entry?.id ?? entry?.name) === 'string')
			if (model !== undefined) {
				return { provider, model: model.model ?? model.id ?? model.name }
			}
		} catch {
			/* try the next provider */
		}
	}
	return undefined
}

/** Terminal finish reasons other than a clean stop are failures. */
function finishFailure(reason) {
	const kind = reason?.kind
	if (kind === 'stop') return undefined
	if (kind === 'error' || kind === 'aborted') {
		const failure = reason?.failure
		const error = new Error(failure?.message ?? `stream finished with ${kind}`)
		if (typeof failure?.code === 'string') error.code = failure.code
		return error
	}
	if (kind === 'max-tokens') return new Error('dsh-prompt-optimizer: output reached maxOutputTokens')
	if (kind === 'tool-calls') return new Error('dsh-prompt-optimizer: model unexpectedly requested a tool')
	return new Error(`dsh-prompt-optimizer: stream finished with reason "${String(kind ?? reason)}"`)
}

/** Run one auxiliary streaming call and return the assembled text blocks. */
async function generate(llm, options) {
	let openType = null
	let text = ''
	for await (const chunk of llm.stream(options)) {
		if (chunk.type === 'block-start') openType = chunk.blockType
		else if (chunk.type === 'text-delta') {
			if (openType === 'text') text += chunk.text
		} else if (chunk.type === 'block-end') openType = null
		else if (chunk.type === 'finish') {
			const failure = finishFailure(chunk.reason)
			if (failure !== undefined) throw failure
		}
		if (options.signal?.aborted) throw new Error('dsh-prompt-optimizer: aborted')
	}
	return text
}

export function apply(ctx, rawConfig = {}) {
	const config = resolveConfig(rawConfig)
	ctx.inject(['llm', 'commands'], (commandCtx) => {
		commandCtx.commands.register({
			name: 'optimize',
			description: 'Rewrite the composer draft into a clearer, well-structured prompt (one auxiliary model call; invoked by the 优化 button)',
			recordInput: false,
			handler: async ({ agent, rawInput, signal }) => {
				const { text, clientRoute } = (() => {
					const parsed = parseInput(rawInput)
					return { text: parsed.text, clientRoute: parsed.route }
				})()
				const draft = text.trim()
				if (draft === '') return { kind: 'error', text: 'Nothing to optimize: the draft is empty.' }
				if (text.length > config.maxInputChars) {
					return {
						kind: 'error',
						text: `Draft is ${text.length} characters, exceeding maxInputChars ${config.maxInputChars}.`
					}
				}
				let route = config.route ?? clientRoute ?? lastLoggedRoute(agent)
				if (route === undefined) route = await firstAvailableRoute(commandCtx.llm)
				if (route === undefined) {
					return { kind: 'error', text: 'No model route available: configure a model first.' }
				}
				const timeout = AbortSignal.timeout(config.timeoutMs)
				const combined = signal === undefined ? timeout : AbortSignal.any([signal, timeout])
				const options = {
					provider: route.provider,
					model: route.model,
					/* Optimization is a light rewrite task: default to minimal
					   reasoning for speed; set reasoningEffort "off" to disable
					   thinking entirely. */
					reasoningEffort: config.reasoningEffort,
					messages: [
						{
							id: `dsh-prompt-optimizer:${crypto.randomUUID()}`,
							role: 'user',
							content: [
								{
									type: 'text',
									text: `Optimize the following prompt draft (given as a JSON string so nothing can break framing):\n${JSON.stringify(text)}`
								}
							],
							source: PLUGIN_SOURCE
						}
					],
					system: SYSTEM_PROMPT,
					maxTokens: config.maxOutputTokens,
					signal: combined
				}
				if (typeof agent?.session?.id === 'string') options.sessionId = agent.session.id
				try {
					const optimized = (await generate(commandCtx.llm, options)).trim()
					if (optimized === '') return { kind: 'error', text: 'The model produced no text. Please retry.' }
					return { kind: 'success', text: optimized }
				} catch (error) {
					const message = error?.message ?? String(error)
					if (combined.aborted && timeout.aborted) {
						return { kind: 'error', text: `Optimization timed out after ${config.timeoutMs} ms.` }
					}
					return { kind: 'error', text: `Optimization failed: ${message}` }
				}
			}
		})
	})
}
