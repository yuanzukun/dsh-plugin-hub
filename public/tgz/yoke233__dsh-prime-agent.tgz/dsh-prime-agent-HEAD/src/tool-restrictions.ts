import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-tools'
import z from '@deepseek-ai/schemastery'

export const name = 'prime-agent-tool-restrictions'
export const inject = ['tools']

export interface Config {
  /** Inherited Host-global tools hidden whenever their providers are present. */
  deny: string[]
}

export const Config: z<Config> = z.object({
  deny: z.array(z.string().min(1)).min(1),
})

/** Keep each joined Agent's inherited capability mask synchronized with Host tools. */
export function apply(ctx: Context, config: Config): void {
  const configured = [...new Set(config.deny)]
  ctx.on('agent/created', ({ agent }) => {
    let activeKey = ''
    let disposeRestriction: (() => void) | undefined

    const reconcile = () => {
      const deny = configured.filter(tool => ctx.tools.get(tool) !== undefined)
      const key = deny.join('\0')
      if (key === activeKey) return
      activeKey = key
      disposeRestriction?.()
      disposeRestriction = deny.length === 0
        ? undefined
        : agent.ctx.tools.restrict({ deny })
    }

    agent.ctx.effect(() => ctx.effect(() => {
      const offChanged = agent.ctx.on('tools/change', reconcile)
      reconcile()
      return () => {
        offChanged()
        disposeRestriction?.()
      }
    }, 'prime inherited tool restrictions'))
  })
}
