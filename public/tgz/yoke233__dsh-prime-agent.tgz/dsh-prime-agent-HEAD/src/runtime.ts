/**
 * Host runtime row for Prime: the plugin body behind `dsh-prime-agent/runtime`.
 *
 * The bundle patch mounts it beside the official `ptc-runtime` row. It watches
 * its owning parent and mounts the trusted `primeRealmRuntime` service. The
 * official `ctx.ptcRuntime` remains available to non-Prime sessions.
 * @module dsh-prime-agent/runtime
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { PrimeRealmRuntime } from './realm/runtime.js'
import { watchHostParent } from './realm/host-parent.js'
import { DEFAULT_COMPLETION_RETENTION_LIMITS } from './realm/protocol.js'
import type { RealmBudgets, RealmCompletionProjectionLimits, RealmCompletionRetentionLimits } from './realm/realm.js'

export const name = 'prime-code-runtime'


/** Direct host owner captured before plugin startup can cross an asynchronous reparenting window. */
const HOST_PARENT_PID = process.ppid


/**
 * Official per-run defaults that Prime preserves when deployment config leaves
 * the shared execution and output fields blank.
 */
const OFFICIAL_DEFAULTS = {
  computeMs: 60_000,
  maxWallMs: 600_000,
  maxOutputBytes: 67_108_864,
} as const

/**
 * Single-slot completion retention fields, whose defaults come directly from
 * `src/realm/protocol.ts`.
 */
const COMPLETION_RETENTION_FIELDS = [
  'maxCompletionRetainedBytes',
  'maxCompletionRetainedNodes',
  'maxCompletionOpaqueBytes',
  'maxCompletionOpaqueNodes',
] as const

/**
 * Completion projection ceilings, restated here so the host schema can publish
 * the defaults from `DEFAULT_COMPLETION_PROJECTION_LIMITS` in
 * `src/realm/protocol.ts`.
 */
const COMPLETION_PROJECTION_DEFAULTS = {
  maxCompletionFullBytes: 65_536,
  maxCompletionProjectionBytes: 4_096,
} as const

const COMPLETION_PROJECTION_FIELDS = [
  'maxCompletionFullBytes',
  'maxCompletionProjectionBytes',
] as const

const DEFAULT_MAX_OLD_GENERATION_SIZE_MB = 64
const DEFAULT_MAX_ACTIVE_REALMS = 32
const DEFAULT_MAX_IDLE_MS = 600_000
const DEFAULT_MAX_HOST_CALLS_PER_RUN = 200
const DEFAULT_MAX_PARALLEL_HOST_CALLS_PER_RUN = 16

/** Plugin config: the official budgets passed through, plus realm-pool governance. */
export interface Config {
  /**
   * Absolute Prime state directory. It MUST be the same value the packaged
   * preset gives the agent-scoped identity tool row, or the two sides read
   * different HMAC keys and host-trusted realm ids diverge.
   */
  stateDirectory: string
  /** Busy-time budget for one run; blank passes through to the official default. */
  computeMs?: number
  /** Wall-clock ceiling for one run; blank passes through to the official default. */
  maxWallMs?: number
  /** Combined outer-output cap for one run; blank passes through to the official default. */
  maxOutputBytes?: number
  /** Worker max old-generation heap in MiB; blank uses the Prime default. */
  maxOldGenerationSizeMb?: number
  /** Realms that may hold a worker at once. */
  maxActiveRealms?: number
  /** How long a realm may sit idle before its worker is reclaimed. */
  maxIdleMs?: number
  /** Total host binding calls one run may issue before further calls are refused. */
  maxHostCallsPerRun?: number
  /** Host binding calls one run may have in flight at once. */
  maxParallelHostCallsPerRun?: number
  /** Exact serialized bytes the latest lossless-JSON completion may occupy. */
  maxCompletionRetainedBytes?: number
  /** Object-graph nodes the latest lossless-JSON completion may occupy. */
  maxCompletionRetainedNodes?: number
  /** Classification-walk byte charge the latest opaque completion may occupy. */
  maxCompletionOpaqueBytes?: number
  /** Classification-walk nodes the latest opaque completion may occupy. */
  maxCompletionOpaqueNodes?: number
  /** Serialized bytes a completion may occupy and still reach the model verbatim. */
  maxCompletionFullBytes?: number
  /** Serialized bytes one bounded completion envelope may occupy. */
  maxCompletionProjectionBytes?: number
}

export const Config: z<Config> = z.object({
  stateDirectory: z.string().required(),
  computeMs: z.number(),
  maxWallMs: z.number(),
  maxOutputBytes: z.number(),
  maxOldGenerationSizeMb: z.number(),
  maxActiveRealms: z.natural().min(1).default(DEFAULT_MAX_ACTIVE_REALMS),
  maxIdleMs: z.natural().min(1).default(DEFAULT_MAX_IDLE_MS),
  maxHostCallsPerRun: z.natural().min(1).default(DEFAULT_MAX_HOST_CALLS_PER_RUN),
  maxParallelHostCallsPerRun: z.natural().min(1).default(DEFAULT_MAX_PARALLEL_HOST_CALLS_PER_RUN),
  maxCompletionRetainedBytes: z.natural().min(1).default(DEFAULT_COMPLETION_RETENTION_LIMITS.maxCompletionRetainedBytes),
  maxCompletionRetainedNodes: z.natural().min(1).default(DEFAULT_COMPLETION_RETENTION_LIMITS.maxCompletionRetainedNodes),
  maxCompletionOpaqueBytes: z.natural().min(1).default(DEFAULT_COMPLETION_RETENTION_LIMITS.maxCompletionOpaqueBytes),
  maxCompletionOpaqueNodes: z.natural().min(1).default(DEFAULT_COMPLETION_RETENTION_LIMITS.maxCompletionOpaqueNodes),
  maxCompletionFullBytes: z.natural().min(1).default(COMPLETION_PROJECTION_DEFAULTS.maxCompletionFullBytes),
  maxCompletionProjectionBytes: z.natural().min(1).default(COMPLETION_PROJECTION_DEFAULTS.maxCompletionProjectionBytes),
}) as unknown as z<Config>


/** Per-run realm ceilings, matching the official budgets wherever they are shared. */
function realmBudgets(config: Config): RealmBudgets {
  return {
    computeMs: config.computeMs ?? OFFICIAL_DEFAULTS.computeMs,
    maxWallMs: config.maxWallMs ?? OFFICIAL_DEFAULTS.maxWallMs,
    maxOutputBytes: config.maxOutputBytes ?? OFFICIAL_DEFAULTS.maxOutputBytes,
    maxOldGenerationSizeMb: config.maxOldGenerationSizeMb ?? DEFAULT_MAX_OLD_GENERATION_SIZE_MB,
    maxHostCallsPerRun: config.maxHostCallsPerRun ?? DEFAULT_MAX_HOST_CALLS_PER_RUN,
    maxParallelHostCallsPerRun: config.maxParallelHostCallsPerRun ?? DEFAULT_MAX_PARALLEL_HOST_CALLS_PER_RUN,
  }
}

/** One realm's latest-completion retention ceilings, defaulted field by field. */
function completionRetentionLimits(config: Config): RealmCompletionRetentionLimits {
  const limits = {} as Record<(typeof COMPLETION_RETENTION_FIELDS)[number], number>
  for (const field of COMPLETION_RETENTION_FIELDS) {
    limits[field] = config[field] ?? DEFAULT_COMPLETION_RETENTION_LIMITS[field]
  }
  return limits
}

/** One realm's projection ceilings, defaulted field by field. */
function completionProjectionLimits(config: Config): RealmCompletionProjectionLimits {
  const limits = {} as Record<(typeof COMPLETION_PROJECTION_FIELDS)[number], number>
  for (const field of COMPLETION_PROJECTION_FIELDS) {
    limits[field] = config[field] ?? COMPLETION_PROJECTION_DEFAULTS[field]
  }
  return limits
}

/**
 * Monitor this host's owner and mount the trusted `primeRealmRuntime` service.
 * The official `ptcRuntime` provider remains untouched. Realm ownership is
 * claimed lazily per requested Realm id, so unrelated host processes can share
 * durable state without sharing a live namespace.
 * @param ctx - the host context this row is mounted on.
 * @param config - validated plugin config.
 */
export async function apply(ctx: Context, config: Config): Promise<void> {
  const stateDirectory = config.stateDirectory.trim()
  if (stateDirectory.length === 0) throw new Error('dsh-prime-agent: stateDirectory must not be empty')

  ctx.effect(
    () => watchHostParent(
      async () => { await ctx.root.fiber.dispose() },
      { parentPid: HOST_PARENT_PID },
    ),
    'prime host parent liveness',
  )

  // The declarative preset is registered by `presets/prime.patch.yml`; runtime
  // startup never writes profile or user configuration.

  new PrimeRealmRuntime(ctx, {
    stateDirectory,
    budgets: realmBudgets(config),
    completionRetention: completionRetentionLimits(config),
    completionProjection: completionProjectionLimits(config),
    maxActiveRealms: config.maxActiveRealms ?? DEFAULT_MAX_ACTIVE_REALMS,
    maxIdleMs: config.maxIdleMs ?? DEFAULT_MAX_IDLE_MS,
  })
}

export type { PrimeRealmRuntime, PrimeRealmRuntimeOptions } from './realm/runtime.js'
