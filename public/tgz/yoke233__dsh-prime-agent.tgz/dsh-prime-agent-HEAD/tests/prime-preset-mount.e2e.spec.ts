import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { afterEach, describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Include, { entryListSchema } from '@deepseek-ai/cordis-plugin-include'
import Loader from '@deepseek-ai/cordis-plugin-loader'
import AgentRegistry, { type Agent } from '@deepseek-ai/dsh-agent'
import AgentLoop from '@deepseek-ai/dsh-agent-loop'
import AgentPreset from '@deepseek-ai/dsh-agent-preset'
import AgentPresetRegistry from '@deepseek-ai/dsh-agent-preset-registry'
import LlmRuntime, { ToolCallId } from '@deepseek-ai/dsh-llm'
import LocalJobRegistry from '@deepseek-ai/dsh-jobs-local'
import SessionStore, { SessionId } from '@deepseek-ai/dsh-session'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'
import SkillRegistry from '@deepseek-ai/dsh-skill'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime, { defineTool } from '@deepseek-ai/dsh-tools'
import type { ToolExecutionResult } from '@deepseek-ai/dsh-tools'
import { load } from 'js-yaml'
import * as primeRuntime from '../src/runtime.js'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const PRIME_AGENT_URL = pathToFileURL(resolve(PROJECT_ROOT, 'lib/index.js')).href
const REFINE_SKILL_URL = pathToFileURL(resolve(PROJECT_ROOT, 'lib/refine-skill-provider.js')).href
const PACKAGED_DECLARATION = join(PROJECT_ROOT, 'presets/prime.patch.yml')
const testSignal = new AbortController().signal

let ctx: Context | undefined
let root: string | undefined
let disposeAgent: (() => Promise<void>) | undefined
let callNumber = 0

afterEach(async () => {
  await disposeAgent?.()
  disposeAgent = undefined
  await ctx?.fiber.dispose()
  ctx = undefined
  if (root !== undefined) await rm(root, { recursive: true, force: true })
  root = undefined
  callNumber = 0
})

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function completion(execution: ToolExecutionResult): { logs: string[], result?: unknown } {
  if (execution.isError) throw new Error(execution.error.message)
  if (!isRecord(execution.value) || !Array.isArray(execution.value.logs)
    || !execution.value.logs.every(log => typeof log === 'string')) {
    throw new Error('invalid repl result')
  }
  return {
    logs: execution.value.logs,
    ...('result' in execution.value ? { result: execution.value.result } : {}),
  }
}

async function runRepl(agent: Agent, code: string): Promise<{ logs: string[], result?: unknown }> {
  if (ctx === undefined) throw new Error('test context was not created')
  return completion(await ctx.tools.execute({
    callId: ToolCallId(`prime-preset-mount-${++callNumber}`),
    name: 'repl',
    arguments: { code },
    signal: testSignal,
    agent,
  }))
}

/** Host capabilities outside this focused preset slice. Jobs come from its real row. */
const POLICY_REQUIRED_TOOLS = [
  'subagent', 'list_agents', 'send_message', 'interrupt_agent',
]

function registerOrchestrationPlaceholders(context: Context): void {
  for (const name of POLICY_REQUIRED_TOOLS) {
    context.tools.register(defineTool({
      name,
      description: `Test-only visible ${name} capability required by the packaged Prime policy.`,
      parameters: {},
      output: {
        schema: { type: 'null' },
        render: () => [{ type: 'text', text: 'unused' }],
      },
      execute: async () => null,
    }))
  }
}

describe('Prime packaged preset realm rows', () => {
  it('mounts them for one Agent and supplies the persistent repl binding', async () => {
    // Keep the temporary composition inside this package scope so Node's
    // ordinary upward lookup resolves the self-reference and explicit dev deps.
    root = await mkdtemp(join(PROJECT_ROOT, '.prime-preset-mount-'))
    const home = join(root, 'home')
    const patch = load(await readFile(PACKAGED_DECLARATION, 'utf8'), { schema: entryListSchema }) as Array<{
      insert?: Array<{ id?: string, config?: { plugins?: Array<Record<string, unknown>> } }>
    }>
    const declaration = patch.flatMap(row => row.insert ?? []).find(row => row.id === 'preset-prime')
    if (declaration?.config?.plugins === undefined) throw new Error('packaged Prime declaration is missing')
    // Mount every Prime-owned row from the native declaration. This includes
    // policy rows, so a restriction aimed at an Agent-local tool fails here
    // exactly as it does in a real TUI preset mount.
    const realmRows = declaration.config.plugins
      .filter(row => (typeof row.id === 'string' && row.id.startsWith('prime-')) || row.id === 'tool-jobs' || row.id === 'tool-skill')
      .map(row => ({
        ...row,
        name: row.name === 'dsh-prime-agent'
          ? PRIME_AGENT_URL
          : row.name === 'dsh-prime-agent/refine-skill-provider' ? REFINE_SKILL_URL : row.name,
      }))

    ctx = new Context()
    ctx.baseUrl = pathToFileURL(root).href + '/'
    ctx.provide('dshHomePath', (...segments: string[]) => join(home, ...segments))
    await ctx.plugin(Loader)
    ctx.loader.builtins.include = Include
    await ctx.plugin(LlmRuntime)
    await ctx.plugin(SessionStore)
    await ctx.plugin(SessionProjectionRegistry)
    await ctx.plugin(SystemPrompt)
    await ctx.plugin(ToolRuntime)
    await ctx.plugin(LocalJobRegistry)
    await ctx.plugin(SkillRegistry)
    await ctx.plugin(AgentRegistry)
    await ctx.plugin(AgentLoop, { agents: [] })
    await ctx.plugin(primeRuntime, { stateDirectory: join(home, 'prime-agent') })
    await ctx.plugin(AgentPresetRegistry, { default: 'prime' })
    await ctx.plugin(AgentPreset, {
      id: 'prime',
      name: 'Prime test',
      plugins: realmRows,
    })
    registerOrchestrationPlaceholders(ctx)
    ctx.tools.register(defineTool({
      name: 'nested_probe',
      description: 'Return a deterministic nested-call sentinel.',
      parameters: {},
      output: {
        schema: { type: 'string' },
        render: (_args, value) => [{ type: 'text', text: String(value) }],
      },
      execute: async () => 'nested-ok',
    }))

    const handle = await ctx.agents.create({
      sessionId: SessionId('prime-preset-agent'),
      meta: { cwd: root, agentPreset: 'prime' },
      setup: agentCtx => ctx!.agentPresets.mount(agentCtx, 'prime').then(() => undefined),
    })
    disposeAgent = () => handle.dispose()

    expect(ctx.agentPresets.composedPreset(handle.agent.ctx)).toBe('prime')
    ctx.tools.register(defineTool({
      name: 'workflow',
      description: 'Host-global workflow capability excluded by the Prime policy.',
      parameters: {},
      output: {
        schema: { type: 'string' },
        render: (_args, value) => [{ type: 'text', text: String(value) }],
      },
      execute: async () => 'must-not-run',
    }))
    expect(ctx.tools.get('workflow')).toBeDefined()
    const assembly = await ctx.systemPrompt.assemble({ scope: handle.agent, agent: handle.agent })
    expect(assembly.tools.map(tool => tool.name)).toEqual(['repl'])
    expect(ctx.tools.get('refine', handle.agent)).toBeUndefined()
    const refineSkill = await ctx.skills.get('refine', { scope: handle.agent })
    expect(refineSkill?.content).toContain('await refine.run()')
    for (const name of ['job_output', 'job_list', 'job_kill']) {
      expect(ctx.tools.get(name, handle.agent)).toBeDefined()
    }
    expect(ctx.tools.get('skill', handle.agent)).toBeDefined()
    expect(ctx.tools.get('workflow', handle.agent)).toBeUndefined()

    const first = await runRepl(
      handle.agent,
      'const presetSentinel = await tools.nested_probe({}); presetSentinel',
    )
    expect(first.result).toBe('nested-ok')

    const second = await runRepl(handle.agent, 'presetSentinel')
    expect(second.result).toBe('nested-ok')
  })
})
