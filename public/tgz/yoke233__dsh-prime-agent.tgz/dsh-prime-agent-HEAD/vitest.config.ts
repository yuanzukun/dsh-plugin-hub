import { defineConfig } from 'vitest/config'
import { integrationTests, modelTests, resolveConfig } from './vitest.suites.js'

export default defineConfig({
  resolve: resolveConfig,
  test: {
    include: ['tests/**/*.spec.ts'],
    exclude: [...integrationTests, ...modelTests],
  },
})
