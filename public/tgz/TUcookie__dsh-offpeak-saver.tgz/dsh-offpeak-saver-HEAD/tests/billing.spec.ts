import { describe, expect, it } from 'vitest'
import { computeCosts, equivalentFreeTokens, formatMoney, round6 } from '../src/billing.js'
import { DEFAULT_PRICING } from '../src/config.js'

const FLASH = { input: 3.0, input_cache_hit: 0.1, output: 9.0 }

describe('computeCosts', () => {
  it('使用当前官方 Flash 与 Pro 高峰价格，空闲时段半价', () => {
    expect(DEFAULT_PRICING['deepseek-flash']).toEqual({ input: 2, input_cache_hit: 0.04, output: 8 })
    expect(DEFAULT_PRICING['deepseek-v4-flash']).toEqual(DEFAULT_PRICING['deepseek-flash'])
    expect(DEFAULT_PRICING['deepseek-v4-pro']).toEqual({ input: 9, input_cache_hit: 0.3, output: 27 })
    const flash = computeCosts(
      { input_tokens: 2_000_000, cache_hit_tokens: 1_000_000, output_tokens: 1_000_000 },
      DEFAULT_PRICING['deepseek-flash']!, 0.5,
    )
    expect(flash.cost_baseline).toBe(10.04)
    expect(flash.cost_actual).toBe(5.02)
  })

  it('计算缓存命中与未命中的混合计费', () => {
    const costs = computeCosts(
      { input_tokens: 1000, output_tokens: 500, cache_hit_tokens: 400 },
      FLASH,
      0.5,
    )
    // baseline = (600*3 + 400*0.1 + 500*9) / 1e6 = 0.00634
    expect(costs.cost_baseline).toBeCloseTo(0.00634, 6)
    expect(costs.cost_actual).toBeCloseTo(0.00317, 6)
    expect(costs.savings).toBeCloseTo(0.00317, 6)
  })

  it('全部命中缓存时按缓存价计费', () => {
    const costs = computeCosts({ input_tokens: 2000, output_tokens: 0, cache_hit_tokens: 2000 }, FLASH, 0.5)
    expect(costs.cost_baseline).toBeCloseTo(0.0002, 6)
    expect(costs.cost_actual).toBeCloseTo(0.0001, 6)
  })

  it('无折扣时实际价等于基准价', () => {
    const costs = computeCosts({ input_tokens: 1_000_000, output_tokens: 1_000_000, cache_hit_tokens: 0 }, FLASH, 1)
    expect(costs.cost_baseline).toBe(12)
    expect(costs.cost_actual).toBe(12)
    expect(costs.savings).toBe(0)
  })

  it('round6 入库保留 6 位小数（展示时再 toFixed(2)）', () => {
    expect(round6(0.1234567)).toBe(0.123457)
  })
})

describe('formatMoney / equivalentFreeTokens', () => {
  it('人民币与美元格式化', () => {
    expect(formatMoney(1.5, 'CNY')).toBe('¥1.50')
    expect(formatMoney(0.25, 'USD')).toBe('$0.25')
  })

  it('等效免费 tokens 按空闲输入价折算', () => {
    // savings 3.75 元，空闲输入价 1.5 元/百万 → 2,500,000 tokens
    expect(equivalentFreeTokens(3.75, FLASH, 0.5)).toBe(2_500_000)
  })
})
