/**
 * Client transport tests: the injected faces must issue exactly
 * `/plugin-manager/<endpoint>` — `call` prepends the route prefix, so a face
 * that also prepends it doubles the path and the server 404s (regression for
 * the double-prefix bug that blanked the settings tab).
 */

import { afterEach, describe, expect, it, vi } from 'vitest'
import { createInjected, toggleBundle, type BundleView } from '../src/client/index.tsx'

type FetchCall = { url: string; init?: RequestInit }

const calls: FetchCall[] = []

const stubFetch = (url: string | URL | Request, init?: RequestInit): Promise<Response> => {
  calls.push({ url: String(url), init })
  return Promise.resolve(new Response(JSON.stringify({ ok: true, value: [] }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  }))
}

const bundle = (disabled: boolean): BundleView => ({
  packageName: 'dsh-fixture-hello',
  version: '0.0.1',
  spec: 'file:/tmp/x',
  rowIds: ['hello', 'hello2'],
  disabled,
})

afterEach(() => {
  vi.unstubAllGlobals()
  calls.length = 0
})

describe('client transport', () => {
  it('issues exactly one route prefix per endpoint', async () => {
    vi.stubGlobal('fetch', stubFetch)
    const faces = createInjected()
    await faces.list()
    await faces.install('file:/tmp/x')
    await faces.uninstall('some-pkg')
    await faces.update('some-pkg')
    await faces.setEnabled('hello', false)

    expect(calls.map(call => call.url)).toEqual([
      '/plugin-manager/list',
      '/plugin-manager/install',
      '/plugin-manager/uninstall',
      '/plugin-manager/update',
      '/plugin-manager/setEnabled',
    ])
    expect(calls.every(call => !call.url.includes('/plugin-manager/plugin-manager'))).toBe(true)
  })
})

describe('toggleBundle semantics', () => {
  it('disables an enabled bundle (setEnabled(id, false)) and reports 已禁用', async () => {
    const enabled = bundle(false)
    const calls: Array<[string, boolean]> = []
    const result = await toggleBundle(enabled, async (id, flag) => {
      calls.push([id, flag])
      return { ok: true, message: 'ok' }
    })
    expect(calls).toEqual([['hello', false], ['hello2', false]])
    expect(result.ok).toBe(true)
    expect(result.message).toContain('已禁用')
  })

  it('enables a disabled bundle (setEnabled(id, true)) and reports 已启用', async () => {
    const disabled = bundle(true)
    const calls: Array<[string, boolean]> = []
    const result = await toggleBundle(disabled, async (id, flag) => {
      calls.push([id, flag])
      return { ok: true, message: 'ok' }
    })
    expect(calls).toEqual([['hello', true], ['hello2', true]])
    expect(result.ok).toBe(true)
    expect(result.message).toContain('已启用')
  })
})
