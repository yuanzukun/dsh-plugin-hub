/**
 * Enable/disable regression: WITHOUT the user-patch watcher, the manager's
 * direct apply is the only writer, so the include's in-place mutation of the
 * insert row (an id-targeted disable merges `disabled` into the insert entry)
 * is not masked. Re-enabling must strip that residue.
 */

import { mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { afterEach, describe, expect, it } from 'vitest'
import { boot, initProfile, PROFILE_PATCH_FILENAME } from '@deepseek-ai/dsh-app-boot'
import PluginManagerGateway from '../src/index.ts'

const FIXTURE = fileURLToPath(new URL('./fixtures/hello-bundle', import.meta.url))

const cleanups: Array<() => Promise<void>> = []
afterEach(async () => {
  for (const cleanup of cleanups.splice(0).reverse()) await cleanup()
})

async function eventually(test: () => boolean, message: string): Promise<void> {
  const deadline = Date.now() + 20_000
  while (!test()) {
    if (Date.now() >= deadline) throw new Error(message)
    await new Promise(resolve => setTimeout(resolve, 25))
  }
}

describe('enable/disable without the watcher (direct apply only)', () => {
  it('re-enables an entry after disabling it', { timeout: 180_000 }, async () => {
    const home = mkdtempSync(join(tmpdir(), 'dsh-edr-'))
    const profileDir = join(home, 'profiles', 't')
    initProfile(profileDir, [])
    writeFileSync(join(profileDir, 'cordis.yml'), '[]\n')

    const ctx = await boot('dsh-edr', join(profileDir, 'cordis.yml'))
    cleanups.push(() => ctx.fiber.dispose())
    const gateway = new PluginManagerGateway(ctx)

    const install = await gateway.install(`file:${FIXTURE}`)
    expect(install.ok, install.message).toBe(true)
    await eventually(() => ctx.get('helloMarker') !== undefined, 'hello did not activate')

    const disabled = await gateway.setEnabled('hello', false)
    expect(disabled.ok, disabled.message).toBe(true)
    await eventually(() => ctx.get('helloMarker') === undefined, 'hello stayed active while disabled')

    // The residue from the disable must not keep the entry disabled.
    const enabled = await gateway.setEnabled('hello', true)
    expect(enabled.ok, enabled.message).toBe(true)
    await eventually(() => ctx.get('helloMarker') !== undefined, 'hello did not re-enable after direct disable')
    expect(ctx.get('helloMarker')).toEqual({ value: 'hello from fixture' })
  })
})
