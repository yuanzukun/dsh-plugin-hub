/**
 * Gateway dispatch tests: the host gateway registers a Typert binding the
 * api-gateway can claim through source-mode reflection. The client side of
 * the wire is transported over a plugin-owned webserver route (the npm
 * `dsh-api-gateway` package is not installable because its dependency
 * `dsh-type-meta` is unpublished), so the client-mount half is covered by
 * the browser UI tests in a later phase.
 */

import { describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import { remoteMethods } from '@deepseek-ai/dsh-typert-protocol'
import PluginManagerGateway from '../src/index.ts'

describe('plugin manager gateway', () => {
  it('registers a typertRemote binding and Remote markers the gateway claims', async () => {
    const ctx = new Context()
    try {
      const gateway = new PluginManagerGateway(ctx)
      expect(gateway.typertRemote).toMatchObject({ serviceKey: 'pluginManager', namespace: 'pluginManager' })
      const markers = remoteMethods(gateway).map(marker => marker.exportName ?? marker.method)
      expect(markers).toEqual(expect.arrayContaining(['listBundles', 'install', 'uninstall', 'update', 'setEnabled']))
    } finally {
      await ctx.fiber.dispose()
    }
  })
})
