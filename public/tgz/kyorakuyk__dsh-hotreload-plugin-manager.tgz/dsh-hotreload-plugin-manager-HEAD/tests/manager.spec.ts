/**
 * REAL-composition lifecycle tests for dsh-plugin-manager: a real Loader
 * tree booted through `dsh-app-boot`, the real user-patch watcher, and real
 * pnpm against a `file:` fixture bundle — all offline and keyless.
 */

import { cpSync, existsSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { afterEach, describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Hmr from '@deepseek-ai/cordis-plugin-hmr'
import Timer from '@deepseek-ai/cordis-plugin-timer'
import {
  boot,
  initProfile,
  loadOptionalPatches,
  PROFILE_PATCH_FILENAME,
  watchUserPatches,
} from '@deepseek-ai/dsh-app-boot'
import PluginManagerGateway from '../src/index.ts'

const NAME = 'dsh-plugin-manager-test'
const FIXTURE = fileURLToPath(new URL('./fixtures/hello-bundle', import.meta.url))
const OPTDEPS_FIXTURE = fileURLToPath(new URL('./fixtures/optional-deps-bundle', import.meta.url))

const tmp = (): string => mkdtempSync(join(tmpdir(), 'dsh-mgr-'))

const cleanups: Array<() => Promise<void>> = []
afterEach(async () => {
  for (const cleanup of cleanups.splice(0).reverse()) await cleanup()
})

/** Poll a predicate up to 20s. */
async function eventually(test: () => boolean, message: string): Promise<void> {
  const deadline = Date.now() + 20_000
  while (!test()) {
    if (Date.now() >= deadline) throw new Error(message)
    await new Promise(resolve => setTimeout(resolve, 25))
  }
}

function entryDisabled(ctx: Context, id: string): boolean | undefined {
  return [...ctx.loader.entries()].find(entry => entry.options.id === id)?.disabled
}

/** Boot a profile tree over an empty root with the user patch layer applied. */
async function bootProfile(profileDir: string, applyUserLayer: boolean): Promise<Context> {
  const patches = applyUserLayer
    ? loadOptionalPatches(NAME, join(profileDir, PROFILE_PATCH_FILENAME)) ?? []
    : []
  const ctx = await boot(NAME, join(profileDir, 'cordis.yml'), patches)
  cleanups.push(() => ctx.fiber.dispose())
  return ctx
}

/** Mount the manager gateway plus the hot user-patch watcher. */
async function mountManager(profileDir: string): Promise<{ ctx: Context; gateway: PluginManagerGateway }> {
  const ctx = await bootProfile(profileDir, false)
  await ctx.plugin(Timer)
  await ctx.plugin(Hmr, { root: [], ignored: [], debounce: 0 })
  const dispose = await watchUserPatches(ctx, {
    binName: NAME,
    filename: join(profileDir, PROFILE_PATCH_FILENAME),
  })
  cleanups.push(dispose)
  return { ctx, gateway: new PluginManagerGateway(ctx) }
}

describe('plugin manager REAL composition', () => {
  it('installs a bundle hot and uninstalls it cleanly', { timeout: 180_000 }, async () => {
    const home = tmp()
    const profileDir = join(home, 'profiles', 't')
    initProfile(profileDir, [])
    writeFileSync(join(profileDir, 'cordis.yml'), '[]\n')

    const { ctx, gateway } = await mountManager(profileDir)
    const helloEntry = (): boolean => [...ctx.loader.entries()].some(entry => entry.options.id === 'hello')

    // Nothing installed yet.
    expect(gateway.listBundles()).toHaveLength(0)
    expect(ctx.get('helloMarker')).toBeUndefined()

    // Install the fixture bundle: pnpm + user-layer rows + watcher hot-mount.
    const result = await gateway.install(`file:${FIXTURE}`)
    expect(result.ok, result.message).toBe(true)

    await eventually(() => ctx.get('helloMarker') !== undefined, 'hello did not activate after install')
    expect(ctx.get('helloMarker')).toEqual({ value: 'hello from fixture' })
    expect(helloEntry()).toBe(true)
    expect(gateway.listBundles().map(bundle => bundle.packageName)).toContain('dsh-fixture-hello')

    // Uninstall: rows removed, direct hot-unmount, no residue.
    const removed = await gateway.uninstall('dsh-fixture-hello')
    expect(removed.ok, removed.message).toBe(true)
    await eventually(() => ctx.get('helloMarker') === undefined, 'hello did not deactivate after uninstall')
    expect(helloEntry()).toBe(false)
    expect(gateway.listBundles()).toHaveLength(0)

    // Double uninstall fails loud.
    expect((await gateway.uninstall('dsh-fixture-hello')).ok).toBe(false)
  })

  it('persists installs across restart via the user patch layer', { timeout: 180_000 }, async () => {
    const home = tmp()
    const profileDir = join(home, 'profiles', 't')
    initProfile(profileDir, [])
    writeFileSync(join(profileDir, 'cordis.yml'), '[]\n')

    const { ctx, gateway } = await mountManager(profileDir)
    const result = await gateway.install(`file:${FIXTURE}`)
    expect(result.ok, result.message).toBe(true)
    await eventually(() => ctx.get('helloMarker') !== undefined, 'hello did not activate')
    await ctx.fiber.dispose() // first instance exits

    // A fresh boot of the same profile composes the rows from the user layer
    // without the manager doing anything.
    const ctx2 = await bootProfile(profileDir, true)
    expect(ctx2.get('helloMarker')).toEqual({ value: 'hello from fixture' })
    expect([...ctx2.loader.entries()].some(entry => entry.options.id === 'hello')).toBe(true)
  })

  it('enables and disables an entry through the user patch layer', { timeout: 180_000 }, async () => {
    const home = tmp()
    const profileDir = join(home, 'profiles', 't')
    initProfile(profileDir, [])
    writeFileSync(join(profileDir, 'cordis.yml'), '[]\n')

    const { ctx, gateway } = await mountManager(profileDir)
    const result = await gateway.install(`file:${FIXTURE}`)
    expect(result.ok, result.message).toBe(true)
    await eventually(() => ctx.get('helloMarker') !== undefined, 'hello did not activate')

    const disabled = await gateway.setEnabled('hello', false)
    expect(disabled.ok, disabled.message).toBe(true)
    await eventually(() => entryDisabled(ctx, 'hello') === true, 'hello was not disabled')
    await eventually(() => ctx.get('helloMarker') === undefined, 'hello stayed active while disabled')

    const enabled = await gateway.setEnabled('hello', true)
    expect(enabled.ok, enabled.message).toBe(true)
    await eventually(() => ctx.get('helloMarker') !== undefined, 'hello did not re-enable')
  })

  it('updates a bundle: swaps rows and hot-applies the new patch', { timeout: 180_000 }, async () => {
    const home = tmp()
    const profileDir = join(home, 'profiles', 't')
    initProfile(profileDir, [])
    writeFileSync(join(profileDir, 'cordis.yml'), '[]\n')

    // A private copy of the fixture so the update mutates it freely.
    const bundleDir = mkdtempSync(join(tmpdir(), 'dsh-mgr-fixture-'))
    cpSync(FIXTURE, bundleDir, { recursive: true })

    const { ctx, gateway } = await mountManager(profileDir)
    const result = await gateway.install(`file:${bundleDir}`)
    expect(result.ok, result.message).toBe(true)
    await eventually(() => ctx.get('helloMarker') !== undefined, 'hello did not activate after install')
    expect(ctx.get('helloMarker')).toEqual({ value: 'hello from fixture' })

    // Bump the version and change the row config; update must swap the rows
    // and the fiber must re-apply the new config. (Updating a bundle's module
    // CODE needs a restart 鈥?Node caches resolved modules and package exports
    // in-process; the manager's update hot-applies composition and config.)
    const manifestPath = join(bundleDir, 'package.json')
    const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
    manifest.version = '0.0.2'
    writeFileSync(manifestPath, `${JSON.stringify(manifest, undefined, 2)}\n`)
    const patchPath = join(bundleDir, 'cordis.patch.yml')
    writeFileSync(patchPath, [
      '- insert:',
      '    - id: hello',
      '      name: dsh-fixture-hello',
      '      config:',
      '        value: updated',
      '',
    ].join('\n'))

    const updated = await gateway.update('dsh-fixture-hello')
    expect(updated.ok, updated.message).toBe(true)
    await eventually(() => (ctx.get('helloMarker') as { value?: string } | undefined)?.value === 'updated',
      'updated row config did not hot-apply')
    expect(gateway.listBundles().find(bundle => bundle.packageName === 'dsh-fixture-hello')?.version).toBe('0.0.2')
  })

  it('handles optional dependencies: installs, skips failing optionals, resolves present ones', { timeout: 180_000 }, async () => {
    const home = tmp()
    const profileDir = join(home, 'profiles', 't')
    initProfile(profileDir, [])
    writeFileSync(join(profileDir, 'cordis.yml'), '[]\n')

    const { ctx, gateway } = await mountManager(profileDir)

    // The fixture declares two optional file: deps — one resolvable, one
    // missing. pnpm must skip the missing one and continue the install.
    const result = await gateway.install(`file:${OPTDEPS_FIXTURE}`)
    expect(result.ok, result.message).toBe(true)

    // The bundle activated and its plugin module imported the resolvable
    // optional dependency through the profile's node_modules.
    await eventually(() => ctx.get('optdepsMarker') !== undefined, 'optdeps bundle did not activate')
    expect(ctx.get('optdepsMarker')).toEqual({ value: 'optional-real-loaded' })

    // The missing optional dependency was skipped, not fatal.
    expect(existsSync(join(profileDir, 'node_modules', 'dsh-optional-missing'))).toBe(false)
    expect(existsSync(join(profileDir, 'node_modules', 'dsh-optional-real'))).toBe(true)

    // Uninstall removes the bundle and its dependencies.
    const removed = await gateway.uninstall('dsh-fixture-optdeps')
    expect(removed.ok, removed.message).toBe(true)
    await eventually(() => ctx.get('optdepsMarker') === undefined, 'optdeps did not deactivate after uninstall')
  })

  it('cleans a CLI-reconciled bundles entry on uninstall', { timeout: 180_000 }, async () => {
    const home = tmp()
    const profileDir = join(home, 'profiles', 't')
    initProfile(profileDir, [])
    writeFileSync(join(profileDir, 'cordis.yml'), '[]\n')

    const { ctx, gateway } = await mountManager(profileDir)
    const result = await gateway.install(`file:${FIXTURE}`)
    expect(result.ok, result.message).toBe(true)
    await eventually(() => ctx.get('helloMarker') !== undefined, 'hello did not activate')

    // Simulate the CLI reconcile: the dependency lands in dsh.profile.bundles.
    const manifestPath = join(profileDir, 'package.json')
    const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
    manifest.dsh.profile.bundles = [...manifest.dsh.profile.bundles, 'dsh-fixture-hello']
    writeFileSync(manifestPath, `${JSON.stringify(manifest, undefined, 2)}\n`)

    const removed = await gateway.uninstall('dsh-fixture-hello')
    expect(removed.ok, removed.message).toBe(true)
    await eventually(() => ctx.get('helloMarker') === undefined, 'hello did not deactivate')

    const after = JSON.parse(readFileSync(manifestPath, 'utf8'))
    expect(after.dsh.profile.bundles).not.toContain('dsh-fixture-hello')
    expect(gateway.listBundles().map(bundle => bundle.packageName)).not.toContain('dsh-fixture-hello')
  })

  it('skips unresolvable ghost entries in the bundle list', { timeout: 60_000 }, async () => {
    const home = tmp()
    const profileDir = join(home, 'profiles', 't')
    initProfile(profileDir, [])
    writeFileSync(join(profileDir, 'cordis.yml'), '[]\n')

    // A bundles entry whose package does not exist must not be reported.
    const manifestPath = join(profileDir, 'package.json')
    const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
    manifest.dsh.profile.bundles = ['vanished-bundle']
    writeFileSync(manifestPath, `${JSON.stringify(manifest, undefined, 2)}\n`)

    const { gateway } = await mountManager(profileDir)
    expect(gateway.listBundles().map(bundle => bundle.packageName)).not.toContain('vanished-bundle')
  })

  it('rejects invalid specs before touching pnpm', { timeout: 60_000 }, async () => {    const home = tmp()
    const profileDir = join(home, 'profiles', 't')
    initProfile(profileDir, [])
    writeFileSync(join(profileDir, 'cordis.yml'), '[]\n')

    const { gateway } = await mountManager(profileDir)
    for (const bad of ['', 'lodash; rm -rf /', 'a b', 'https://example.com/x && echo pwned']) {
      const result = await gateway.install(bad)
      expect(result.ok).toBe(false)
    }
    expect(gateway.listBundles()).toHaveLength(0)
  })
})
