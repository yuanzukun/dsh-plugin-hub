/** Minimal dsh bundle fixture: mounts one plugin providing a marker service. */

export const name = 'hello'

/**
 * Provide a marker service so tests can assert this fixture mounted and
 * observe config hot-swaps on update.
 * @param ctx - plugin context.
 * @param config - row config; `value` labels the version.
 */
export function apply(ctx, config = {}) {
  ctx.provide('helloMarker', { value: config.value ?? 'hello from fixture' })
}
