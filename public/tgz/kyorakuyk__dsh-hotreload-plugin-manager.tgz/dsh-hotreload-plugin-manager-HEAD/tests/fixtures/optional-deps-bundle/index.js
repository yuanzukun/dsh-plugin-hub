/** Optional-deps fixture plugin: imports the resolvable optional dependency at apply time. */

export const name = 'optdeps'

/**
 * Provide a marker whose value comes from the optional dependency, proving
 * the dependency resolved through the profile's node_modules.
 * @param ctx - plugin context.
 */
export async function apply(ctx) {
  const { value } = await import('dsh-optional-real')
  ctx.provide('optdepsMarker', { value })
}
