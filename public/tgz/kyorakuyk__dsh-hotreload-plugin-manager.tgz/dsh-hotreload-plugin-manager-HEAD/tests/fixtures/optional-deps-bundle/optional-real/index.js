/** The resolvable optional dependency of the optional-deps fixture. */

export const value = 'optional-real-loaded'
