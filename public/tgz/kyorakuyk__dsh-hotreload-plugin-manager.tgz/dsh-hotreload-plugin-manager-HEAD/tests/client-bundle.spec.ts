/**
 * Client-bundle smoke test: the built lib/client.js must evaluate in a
 * browser-like shell — it registers with window.__ModuleLoader__.load and the
 * factory resolves platform externals through the injected require, exporting
 * the tab plugin without throwing at load time.
 */

import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'

const BUNDLE = fileURLToPath(new URL('../lib/client.js', import.meta.url))

const PLATFORM = [
  'react', 'react/jsx-runtime', 'react-dom', 'react-dom/client', '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-attachment',
  '@deepseek-ai/dsh-client-schema-form',
]

describe('client bundle', () => {
  it('registers and exports the tab plugin through the loader contract', () => {
    const code = readFileSync(BUNDLE, 'utf8')
    const window: Record<string, unknown> = {}
    const loaded: Array<{ id: string; factory: (require: (spec: string) => unknown) => unknown }> = []
    window.__ModuleLoader__ = { load: (entry: { id: string; factory: (require: (spec: string) => unknown) => unknown }) => loaded.push(entry) }

    const requireStub = (spec: string): unknown => {
      if (spec === 'react') return { Component: class Component {} }
      if (PLATFORM.includes(spec)) return {}
      throw new Error(`unexpected external required by the client bundle: ${spec}`)
    }

    // eslint-disable-next-line no-new-func
    const evaluate = new Function('window', 'require', code)
    evaluate(window, requireStub)

    expect(loaded).toHaveLength(1)
    expect(loaded[0]?.id).toBe('@kyorakuyk/dsh-plugin-manager')
    const module = loaded[0]?.factory(requireStub) as Record<string, unknown>
    expect(module.name).toBe('ui-plugin-manager')
    expect(typeof module.apply).toBe('function')
    expect(typeof module.PluginManagerTab).toBe('function')
  })
})
