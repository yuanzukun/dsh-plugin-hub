/**
 * Unit tests for the pnpm-workspace supply-chain helpers: reading the
 * profile's pnpm-workspace.yaml (via js-yaml), appending scope wildcards to
 * minimumReleaseAgeExclude, recording allowBuilds specs, and preserving
 * unrelated settings (including the two blocks coexisting).
 */

import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import {
  ensureAllowBuilds,
  ensureMinimumReleaseAgeExclude,
  parseWorkspace,
} from '../src/pnpm-workspace.ts'

const ws = (text: string): string => {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-ws-'))
  writeFileSync(join(dir, 'pnpm-workspace.yaml'), text)
  return dir
}

describe('parseWorkspace', () => {
  it('reads an existing exclude list', () => {
    const dir = ws([
      'packages:',
      '  - .',
      '',
      'minimumReleaseAgeExclude:',
      "  - '@kyorakuyk/*'",
      "  - 'old-scope/*'",
      '',
    ].join('\n'))
    const { excludes, allowBuilds } = parseWorkspace(dir)
    expect(excludes).toEqual(['@kyorakuyk/*', 'old-scope/*'])
    expect(allowBuilds.size).toBe(0)
  })

  it('reads an allowBuilds map with colon-bearing specs', () => {
    const dir = ws([
      'allowBuilds:',
      "  'dsh-cost-meter@git+https://github.com/kyorakuyk/dsh-cost-meter.git#abc123': true",
      '  esbuild: false',
      '',
    ].join('\n'))
    const { excludes, allowBuilds } = parseWorkspace(dir)
    expect(allowBuilds.get('dsh-cost-meter@git+https://github.com/kyorakuyk/dsh-cost-meter.git#abc123')).toBe('true')
    expect(allowBuilds.get('esbuild')).toBe('false')
    expect(excludes).toEqual([])
  })

  it('reads both blocks from one file', () => {
    const dir = ws([
      'packages:',
      '  - .',
      '',
      'nodeLinker: hoisted',
      'minimumReleaseAgeExclude:',
      "  - '@a/*'",
      'allowBuilds:',
      "  'pkg@git+https://x#1': true",
      'autoInstallPeers: false',
      '',
    ].join('\n'))
    const { excludes, allowBuilds } = parseWorkspace(dir)
    expect(excludes).toEqual(['@a/*'])
    expect(allowBuilds.get('pkg@git+https://x#1')).toBe('true')
  })

  it('returns empty settings for a missing file', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-ws-'))
    const { excludes, allowBuilds } = parseWorkspace(dir)
    expect(excludes).toEqual([])
    expect(allowBuilds.size).toBe(0)
  })
})

describe('ensureMinimumReleaseAgeExclude', () => {
  it('creates the workspace file with the scope appended', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-ws-'))
    expect(ensureMinimumReleaseAgeExclude(dir, '@kyorakuyk/*')).toBe(true)
    const text = readFileSync(join(dir, 'pnpm-workspace.yaml'), 'utf8')
    expect(text).toContain('minimumReleaseAgeExclude:')
    expect(text).toContain("'@kyorakuyk/*'")
  })

  it('preserves existing settings and deduplicates', () => {
    const dir = ws([
      'packages:',
      '  - .',
      '',
      'nodeLinker: hoisted',
      'autoInstallPeers: false',
      'minimumReleaseAgeExclude:',
      "  - '@other/*'",
      '',
    ].join('\n'))
    expect(ensureMinimumReleaseAgeExclude(dir, '@kyorakuyk/*')).toBe(true)
    expect(ensureMinimumReleaseAgeExclude(dir, '@kyorakuyk/*')).toBe(true) // no dup
    const text = readFileSync(join(dir, 'pnpm-workspace.yaml'), 'utf8')
    expect(text).toContain('nodeLinker: hoisted')
    expect(text).toContain('autoInstallPeers: false')
    const { excludes } = parseWorkspace(dir)
    expect(excludes).toEqual(['@other/*', '@kyorakuyk/*'])
  })

  it('keeps an existing allowBuilds block when appending an exclude', () => {
    const dir = ws([
      "allowBuilds:",
      "  'pkg@git+https://x#1': true",
      '',
    ].join('\n'))
    expect(ensureMinimumReleaseAgeExclude(dir, '@scope/*')).toBe(true)
    const { excludes, allowBuilds } = parseWorkspace(dir)
    expect(allowBuilds.get('pkg@git+https://x#1')).toBe('true')
    expect(excludes).toEqual(['@scope/*'])
  })
})

describe('ensureAllowBuilds', () => {
  it('appends the exact spec with value true', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-ws-'))
    const spec = 'dsh-cost-meter@git+https://github.com/kyorakuyk/dsh-cost-meter.git#14b98438'
    expect(ensureAllowBuilds(dir, spec)).toBe(true)
    const { allowBuilds } = parseWorkspace(dir)
    expect(allowBuilds.get(spec)).toBe('true')
  })

  it('preserves existing excludes and deduplicates the spec', () => {
    const dir = ws([
      'minimumReleaseAgeExclude:',
      "  - '@a/*'",
      '',
    ].join('\n'))
    const spec = 'pkg@git+https://x#1'
    expect(ensureAllowBuilds(dir, spec)).toBe(true)
    expect(ensureAllowBuilds(dir, spec)).toBe(true)
    const { excludes, allowBuilds } = parseWorkspace(dir)
    expect(excludes).toEqual(['@a/*'])
    expect([...allowBuilds.keys()].filter(key => key === spec)).toHaveLength(1)
  })
})
