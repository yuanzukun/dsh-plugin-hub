/**
 * Unit tests for the pnpm output classifiers used by the supply-chain
 * auto-remediation: detecting minimumReleaseAge and allowBuilds gates, and
 * extracting the exact specs pnpm wants recorded.
 */

import { describe, expect, it } from 'vitest'
import {
  ageViolationPackage,
  buildsNotAllowedSpec,
  isBuildsNotAllowed,
  isReleaseAgeViolation,
} from '../src/manager.ts'

describe('isReleaseAgeViolation', () => {
  it('detects the pnpm error code', () => {
    expect(isReleaseAgeViolation('[ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION] 1 lockfile entries failed')).toBe(true)
  })

  it('ignores unrelated output', () => {
    expect(isReleaseAgeViolation('Lockfile passes supply-chain policies')).toBe(false)
    expect(isReleaseAgeViolation('')).toBe(false)
  })
})

describe('ageViolationPackage', () => {
  it('extracts a scoped package from the violation line', () => {
    const tail = [
      '[ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION] 1 lockfile entries failed verification:',
      '  @kyorakuyk/dsh-plugin-manager@0.1.1 was published at 2026-08-14T17:11:23.595Z, within the minimumReleaseAge cutoff',
      '',
    ].join('\n')
    expect(ageViolationPackage(tail)).toBe('@kyorakuyk/dsh-plugin-manager')
  })

  it('extracts an unscoped package', () => {
    const tail = [
      '  dsh-cost-meter@0.1.0 was published at 2026-08-14T17:00:00.000Z, within the cutoff',
      '',
    ].join('\n')
    expect(ageViolationPackage(tail)).toBe('dsh-cost-meter')
  })

  it('returns undefined when no violation line is present', () => {
    expect(ageViolationPackage('nothing here')).toBeUndefined()
  })
})

describe('isBuildsNotAllowed', () => {
  it('detects both pnpm build-gate error codes', () => {
    expect(isBuildsNotAllowed('[ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED] Failed to prepare')).toBe(true)
    expect(isBuildsNotAllowed('[ERR_PNPM_IGNORED_BUILDS] Ignored build scripts')).toBe(true)
  })

  it('ignores unrelated output', () => {
    expect(isBuildsNotAllowed('Done in 5s')).toBe(false)
  })
})

describe('buildsNotAllowedSpec', () => {
  const GIT_SPEC = 'dsh-cost-meter@git+https://github.com/kyorakuyk/dsh-cost-meter.git#14b98438057cb162afc00f448562680d682ccee7'

  it('extracts the spec from the pnpm example block (value true)', () => {
    const tail = [
      'Add the package to "allowBuilds" in your project\'s pnpm-workspace.yaml to allow it to run scripts. For example:',
      'allowBuilds:',
      `  ${GIT_SPEC}: true`,
      '',
    ].join('\n')
    expect(buildsNotAllowedSpec(tail)).toBe(GIT_SPEC)
  })

  it('extracts the spec when pnpm wrote its placeholder value', () => {
    const tail = [
      'allowBuilds:',
      `  ${GIT_SPEC}: set this to true or false`,
      '',
    ].join('\n')
    expect(buildsNotAllowedSpec(tail)).toBe(GIT_SPEC)
  })

  it('extracts a quoted scoped-package key', () => {
    const tail = [
      'allowBuilds:',
      "  '@scope/pkg@git+https://github.com/scope/pkg.git#abc123': true",
      '',
    ].join('\n')
    expect(buildsNotAllowedSpec(tail)).toBe('@scope/pkg@git+https://github.com/scope/pkg.git#abc123')
  })

  it('returns undefined when no allowBuilds line is present', () => {
    expect(buildsNotAllowedSpec('nothing here')).toBeUndefined()
  })
})
