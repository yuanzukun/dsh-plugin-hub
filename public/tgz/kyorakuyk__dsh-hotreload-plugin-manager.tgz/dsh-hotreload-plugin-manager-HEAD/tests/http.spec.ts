/**
 * HTTP transport tests: the gateway registers a route on the webServer and
 * the route drives the manager end to end (install →hot activation → * uninstall) over the JSON protocol the browser tab uses.
 */

import { mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { afterEach, describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Hmr from '@deepseek-ai/cordis-plugin-hmr'
import Timer from '@deepseek-ai/cordis-plugin-timer'
import { boot, initProfile, PROFILE_PATCH_FILENAME, watchUserPatches } from '@deepseek-ai/dsh-app-boot'
import PluginManagerGateway from '../src/index.ts'

const FIXTURE = fileURLToPath(new URL('./fixtures/hello-bundle', import.meta.url))

const cleanups: Array<() => Promise<void>> = []
afterEach(async () => {
  for (const cleanup of cleanups.splice(0).reverse()) await cleanup()
})

/** Fake node:http request carrying one JSON body. */
function fakeRequest(method: string, url: string, body: unknown): never {
  const chunks = [Buffer.from(JSON.stringify(body), 'utf8')]
  return {
    method,
    url,
    [Symbol.asyncIterator]: async function* (): AsyncGenerator<Buffer> {
      for (const chunk of chunks) yield chunk
    },
  } as never
}

/** Fake node:http response capturing the reply (shared capture object). */
function fakeResponse(): { res: never; captured: { status: number; body: string } } {
  const captured = { status: 0, body: '' }
  const res = {
    writeHead: (status: number): void => { captured.status = status },
    end: (body: string): void => { captured.body = body },
  }
  return { res: res as never, captured }
}

async function eventually(test: () => boolean, message: string): Promise<void> {
  const deadline = Date.now() + 20_000
  while (!test()) {
    if (Date.now() >= deadline) throw new Error(message)
    await new Promise(resolve => setTimeout(resolve, 25))
  }
}

describe('plugin manager HTTP transport', () => {
  it('installs and uninstalls over the JSON route', { timeout: 180_000 }, async () => {
    const home = mkdtempSync(join(tmpdir(), 'dsh-http-'))
    const profileDir = join(home, 'profiles', 't')
    initProfile(profileDir, [])
    writeFileSync(join(profileDir, 'cordis.yml'), '[]\n')

    const ctx = await boot('dsh-http', join(profileDir, 'cordis.yml'))
    cleanups.push(() => ctx.fiber.dispose())
    await ctx.plugin(Timer)
    await ctx.plugin(Hmr, { root: [], ignored: [], debounce: 0 })
    cleanups.push(await watchUserPatches(ctx, { binName: 'dsh-http', filename: join(profileDir, PROFILE_PATCH_FILENAME) }))

    // Provide a capturing webServer so the gateway registers its route.
    let route: { kind: string; path: string; handler: (req: never, res: never) => Promise<void> } | undefined
    ctx.provide('webServer', { register: (candidate: typeof route) => { route = candidate; return () => {} } })
    new PluginManagerGateway(ctx)
    await eventually(() => route !== undefined, 'gateway did not register its HTTP route')

    const call = async (method: string, path: string, body: unknown): Promise<{ status: number; body: string }> => {
      const fake = fakeResponse()
      const req = fakeRequest(method, `http://x${path}`, body)
      await route?.handler(req, fake.res)
      return { status: fake.captured.status, body: fake.captured.body }
    }

    // Empty list initially.
    const listed = await call('GET', '/plugin-manager/list', {})
    expect(listed.status).toBe(200)
    expect(JSON.parse(listed.body)).toMatchObject({ ok: true, value: [] })

    // Install over HTTP →hot activation.
    const install = await call('POST', '/plugin-manager/install', { spec: `file:${FIXTURE}` })
    expect(install.status).toBe(200)
    expect(JSON.parse(install.body).ok).toBe(true)
    await eventually(() => ctx.get('helloMarker') !== undefined, 'hello did not activate after HTTP install')

    const after = await call('GET', '/plugin-manager/list', {})
    const bundles = (JSON.parse(after.body) as { value: Array<{ packageName: string }> }).value
    expect(bundles.map(bundle => bundle.packageName)).toContain('dsh-fixture-hello')

    // Uninstall over HTTP →hot unmount.
    const uninstall = await call('POST', '/plugin-manager/uninstall', { packageName: 'dsh-fixture-hello' })
    expect(JSON.parse(uninstall.body).ok).toBe(true)
    await eventually(() => ctx.get('helloMarker') === undefined, 'hello did not deactivate after HTTP uninstall')

    // Unknown endpoint and bad payload fail loud.
    const unknown = await call('GET', '/plugin-manager/nope', {})
    expect(unknown.status).toBe(404)
    const bad = await call('POST', '/plugin-manager/install', {})
    expect(bad.status).toBe(400)
  })
})
