import { defineConfig } from 'vitest/config'

// The published @deepseek-ai/cordis-plugin-hmr requires --expose-internals
// (it imports node internals); pass it to every worker.
export default defineConfig({
  test: {
    poolOptions: {
      forks: { execArgv: ['--expose-internals'] },
      threads: { execArgv: ['--expose-internals'] },
    },
  },
})
