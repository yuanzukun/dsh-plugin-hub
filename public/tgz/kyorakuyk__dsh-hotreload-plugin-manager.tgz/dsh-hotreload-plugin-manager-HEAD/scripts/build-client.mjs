// Build the browser client bundle: a closure-factory artifact the client
// module table can fetch. Replicates the in-tree clientBundle contract:
// CJS output wrapped in window.__ModuleLoader__.load({ id, factory }), with
// platform modules left external (resolved from the frozen module table).
import { build } from 'esbuild'
import { fileURLToPath } from 'node:url'

const PLATFORM_MODULES = [
  'react', 'react/jsx-runtime', 'react-dom', 'react-dom/client', '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-attachment',
  '@deepseek-ai/dsh-client-schema-form',
]

const result = await build({
  entryPoints: [fileURLToPath(new URL('../src/client/index.tsx', import.meta.url))],
  bundle: true,
  outfile: fileURLToPath(new URL('../lib/client.js', import.meta.url)),
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  jsx: 'automatic',
  sourcemap: true,
  external: PLATFORM_MODULES,
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
    'import.meta.env.MODE': JSON.stringify(process.env.NODE_ENV ?? 'production'),
    'import.meta.env': JSON.stringify({ MODE: process.env.NODE_ENV ?? 'production' }),
  },
  banner: {
    js: 'var module = { exports: {} }; var exports = module.exports;'
      + 'window.__ModuleLoader__.load({ id: "@kyorakuyk/dsh-plugin-manager", factory: (require) => {',
  },
  footer: { js: '\nreturn module.exports; } });' },
  logLevel: 'info',
})

if (result.errors.length > 0) {
  console.error(result.errors)
  process.exit(1)
}
console.log('client bundle written to lib/client.js')
