/**
 * Package-spec validation for `pnpm add`. Rejects anything that could smuggle
 * shell metacharacters or whitespace through argv, then admits only the
 * supported spec forms: npm names (scoped or not, optional version), git URLs,
 * the `github:` shorthand, `owner/repo`, and `file:`/`link:` paths.
 * @module dsh-plugin-manager/spec
 */

/** Characters that must never appear in a spec: whitespace, quotes, and shell operators. */
const FORBIDDEN = /[\u0000-\u001f\u007f\s&;|`"'$()<>*{}\[\]]/

/** npm package name with optional scope and version suffix. */
const NPM_NAME = /^@?[a-zA-Z0-9][a-zA-Z0-9._-]*(?:\/[a-zA-Z0-9][a-zA-Z0-9._-]*)?(?:@[a-zA-Z0-9._^~-]+)?$/

/** https/ssh git URL, optionally git+ prefixed. */
const GIT_URL = /^(?:git\+)?(?:https?|ssh):\/\/[^\s]+$/

/** GitHub shorthand `github:owner/repo` with optional ref. */
const GITHUB_SHORTHAND = /^github:[a-zA-Z0-9._-]+\/[a-zA-Z0-9._-]+(?:#[^\s]+)?$/

/** GitHub shorthand `owner/repo`. */
const OWNER_REPO = /^[a-zA-Z0-9._-]+\/[a-zA-Z0-9._-]+$/

/** Local path specs. */
const PATH_SPEC = /^(?:file|link):.+$/

/**
 * Validate one install spec.
 * @param spec - the raw spec string from the user.
 * @returns an error message when the spec is rejected, or undefined when it may be passed to pnpm.
 */
export function validatePackageSpec(spec: string): string | undefined {
  if (spec.length === 0) return 'spec is empty'
  if (spec.length > 1024) return 'spec is too long'
  if (FORBIDDEN.test(spec)) {
    return 'spec contains whitespace, quotes, or shell metacharacters'
  }
  if (NPM_NAME.test(spec) || GIT_URL.test(spec) || GITHUB_SHORTHAND.test(spec)
    || OWNER_REPO.test(spec) || PATH_SPEC.test(spec)) return undefined
  return 'spec is not a supported npm package, git URL, github shorthand, or file:/link: path'
}
