/**
 * dsh-plugin-manager — browser half.
 *
 * A Web Settings tab (slot `settings.plugins.tab`, id `manager`) for the
 * plugin hot lifecycle, talking to the host through the plugin-owned
 * same-origin HTTP transport (`/plugin-manager/*`). The bundle calls
 * `window.__ModuleLoader__.load` and resolves platform modules (react, cordis,
 * ui-slots) from the frozen module table.
 * @module dsh-plugin-manager/client
 */

import { Component, useEffect, useState, type ErrorInfo, type ReactNode } from 'react'
import type { Context } from '@deepseek-ai/cordis'

/**
 * Minimal client-context surface the tab needs. The real client packages
 * (`dsh-client-runtime`, `dsh-client-ui-slots`) are not installable from npm
 * (their dependency chain includes unpublished packages), so the browser
 * half types the services it uses locally; at runtime the module table
 * supplies the real `slots` service.
 */
export interface ClientContextLike extends Context {
  readonly slots: {
    inject(name: string, fn: () => unknown): unknown
    register(options: Record<string, unknown>, component: unknown): () => void
  }
}

/** One installed bundle shown in the tab. */
export interface BundleView {
  readonly packageName: string
  readonly version?: string
  readonly spec: string
  readonly rowIds: readonly string[]
  readonly disabled: boolean
}

/** Structured outcome of one operation. */
export interface OpResult {
  readonly ok: boolean
  readonly message: string
  readonly tail?: string
}

/** The injected face the tab renders with. */
export interface PluginManagerTabInjected {
  list(): Promise<BundleView[]>
  install(spec: string): Promise<OpResult>
  uninstall(packageName: string): Promise<OpResult>
  update(packageName: string): Promise<OpResult>
  setEnabled(entryId: string, enabled: boolean): Promise<OpResult>
}

const ROUTE = '/plugin-manager'

/** Error boundary so a render crash shows a diagnostic instead of a blank page. */
class TabErrorBoundary extends Component<{ children: ReactNode }, { error?: Error }> {
  state: { error?: Error } = {}

  static getDerivedStateFromError(error: Error): { error: Error } {
    return { error }
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    // eslint-disable-next-line no-console
    console.error('[ui-plugin-manager] render error', error, info)
  }

  render(): ReactNode {
    if (this.state.error === undefined) return this.props.children
    return (
      <div style={{ color: '#d33', fontSize: 13, whiteSpace: 'pre-wrap' }}>
        UI 渲染出错: {this.state.error.stack ?? this.state.error.message}
      </div>
    )
  }
}

/** One same-origin JSON call; throws with the server message on non-2xx. */
async function call<T>(path: string, body?: unknown): Promise<T> {
  const res = await fetch(ROUTE + path, body === undefined
    ? undefined
    : { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
  let data: unknown
  try {
    data = await res.json()
  } catch {
    throw new Error(`${path}: HTTP ${res.status} returned non-JSON`)
  }
  if (!res.ok) {
    const envelope = data as { message?: unknown } | null
    const detail = envelope !== null && typeof envelope === 'object' && typeof envelope.message === 'string'
      ? envelope.message
      : `HTTP ${res.status}`
    throw new Error(`${path}: ${detail}`)
  }
  return data as T
}

const inputStyle: React.CSSProperties = {
  flex: 1,
  padding: '6px 8px',
  borderRadius: 6,
  border: '1px solid rgba(128, 128, 128, 0.4)',
  background: 'transparent',
  color: 'inherit',
  fontSize: 13,
}

const buttonStyle: React.CSSProperties = {
  padding: '6px 12px',
  borderRadius: 6,
  border: '1px solid rgba(128, 128, 128, 0.4)',
  background: 'transparent',
  color: 'inherit',
  cursor: 'pointer',
  fontSize: 13,
}

const rowStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  padding: '8px 0',
  borderBottom: '1px solid rgba(128, 128, 128, 0.2)',
}

/** The plugin-manager settings tab. */
export function PluginManagerTab(props: PluginManagerTabInjected): React.JSX.Element {
  const [spec, setSpec] = useState('')
  const [bundles, setBundles] = useState<BundleView[]>([])
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState<string>()

  const refresh = async (): Promise<void> => {
    try {
      const loaded = await props.list()
      if (!Array.isArray(loaded)) {
        throw new TypeError(`list() 返回了非数组: ${JSON.stringify(loaded).slice(0, 200)}`)
      }
      setBundles(loaded)
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error('[ui-plugin-manager] refresh failed', error)
      setMessage(`加载失败: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  useEffect(() => { void refresh() }, [])

  const run = async (operation: () => Promise<OpResult>): Promise<void> => {
    setBusy(true)
    setMessage(undefined)
    try {
      const result = await operation()
      setMessage(`${result.ok ? '✅' : '❌'} ${result.message}${result.tail !== undefined ? `\n${result.tail}` : ''}`)
      await refresh()
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error('[ui-plugin-manager] operation failed', error)
      setMessage(`操作失败: ${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setBusy(false)
    }
  }

  return (
    <TabErrorBoundary>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, fontSize: 13 }}>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            style={inputStyle}
            value={spec}
            onChange={event => setSpec(event.target.value)}
            placeholder="安装插件（npm 包名 / git URL / file: 路径）"
            disabled={busy}
          />
          <button
            style={buttonStyle}
            disabled={busy || spec.length === 0}
            onClick={() => void run(() => props.install(spec))}
          >
            安装
          </button>
        </div>

        {message !== undefined && (
          <pre style={{ whiteSpace: 'pre-wrap', margin: 0, color: 'inherit', opacity: 0.8 }}>
            {message}
          </pre>
        )}

        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontWeight: 600 }}>已安装（{bundles.length}）</span>
            <button
              style={{ ...buttonStyle, padding: '2px 8px', fontSize: 12 }}
              disabled={busy}
              onClick={() => void run(() => Promise.resolve({ ok: true, message: '已刷新' }))}
            >
              刷新
            </button>
          </div>
          {bundles.length === 0 && <div style={{ opacity: 0.6 }}>暂无已安装插件</div>}
          {bundles.map(bundle => {
            // Defensive against a host/client version mismatch window: the
            // running host may still serve the pre-rowIds shape after a
            // reinstall, before the instance restarts.
            const rowIds = bundle.rowIds ?? []
            const disabled = bundle.disabled === true
            return (
              <div key={bundle.packageName} style={rowStyle}>
                <span style={{ flex: 1 }}>
                  {bundle.packageName}
                  {bundle.version !== undefined && <span style={{ opacity: 0.6 }}> @{bundle.version}</span>}
                  {disabled && <span style={{ opacity: 0.6 }}>（已禁用）</span>}
                </span>
                {rowIds.length > 0 && (
                  <button
                    style={buttonStyle}
                    disabled={busy}
                    onClick={() => void run(() => toggleBundle({ ...bundle, rowIds, disabled }, props.setEnabled))}
                  >
                    {disabled ? '启用' : '禁用'}
                  </button>
                )}
                <button style={buttonStyle} disabled={busy} onClick={() => void run(() => props.update(bundle.packageName))}>
                  更新
                </button>
                <button
                  style={buttonStyle}
                  disabled={busy}
                  onClick={() => {
                    // eslint-disable-next-line no-alert
                    if (window.confirm(`卸载 ${bundle.packageName}？`)) void run(() => props.uninstall(bundle.packageName))
                  }}
                >
                  卸载
                </button>
              </div>
            )
          })}
        </div>
      </div>
    </TabErrorBoundary>
  )
}

/**
 * Toggle every row a bundle owns: the action is "enable" exactly when the
 * bundle is currently disabled (`setEnabled(id, false)` disables).
 * @param bundle - the bundle view (rowIds + disabled state).
 * @param setEnabled - the injected toggle.
 * @returns the outcome of the last operation.
 */
export async function toggleBundle(
  bundle: BundleView,
  setEnabled: (entryId: string, enabled: boolean) => Promise<OpResult>,
): Promise<OpResult> {
  const enable = bundle.disabled === true
  for (const entryId of bundle.rowIds) {
    const result = await setEnabled(entryId, enable)
    if (!result.ok) return result
  }
  return {
    ok: true,
    message: enable ? `已启用 ${bundle.packageName}` : `已禁用 ${bundle.packageName} 的 ${bundle.rowIds.length} 个条目`,
  }
}

/** Stable plugin name. */
export const name = 'ui-plugin-manager'

/** Services required by the settings registration. */
export const inject = ['slots']

/**
 * The injected face: each method calls the transport with a bare endpoint —
 * `call` prepends the route prefix, so passing it again would double it.
 */
export function createInjected(): PluginManagerTabInjected {
  return {
    list: async () => (await call<{ ok: boolean; value?: BundleView[] }>('/list')).value ?? [],
    install: async spec => call<OpResult>('/install', { spec }),
    uninstall: async packageName => call<OpResult>('/uninstall', { packageName }),
    update: async packageName => call<OpResult>('/update', { packageName }),
    setEnabled: async (entryId, enabled) => call<OpResult>('/setEnabled', { entryId, enabled }),
  }
}

/** Contribute the manager tab to the Plugins settings section. */
export function apply(ctx: ClientContextLike): void {
  // eslint-disable-next-line no-console
  console.log('[ui-plugin-manager] applying', { slots: typeof ctx.slots?.inject })

  ctx.slots.inject('settings.plugins.tab', () => ctx.slots.register({
    name: 'settings.plugins.tab',
    id: 'manager',
    order: 30,
    label: () => '插件管理',
    inject: createInjected,
  }, PluginManagerTab))
}
