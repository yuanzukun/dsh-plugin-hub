/**
 * dsh-plugin-manager — host gateway.
 *
 * Web UI plugin hot lifecycle for DeepSeek Harness: install, uninstall,
 * update, list, and enable/disable profile plugin bundles from the running
 * instance without a restart. The gateway is a Typert Remote service; the
 * api-gateway dispatches it through source-mode reflection (no generated
 * artifacts needed). Every operation edits the profile's user patch layer
 * (`cordis.patch.yml`), which the launcher's `watchUserPatches` hot-applies
 * transactionally and which recomposes at boot, so installs survive restarts
 * without touching `dsh.profile.bundles`.
 *
 * The profile directory is derived from the root context's `baseUrl` (the
 * profile's `cordis.yml` directory), so the bundle must be mounted inside a
 * profile surface (`dsh --profile <name>`).
 *
 * @module dsh-plugin-manager
 */

import type { Context } from '@deepseek-ai/cordis'
import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import { fileURLToPath } from 'node:url'
import { registerManagerRoutes } from './http.js'
import {
  installBundle,
  listBundles as listBundlesCore,
  setEnabled as setEnabledCore,
  uninstallBundle,
  updateBundle,
  type ManagerRuntime,
} from './manager.js'
import type { PluginManagerBundle, PluginManagerResult } from './types.js'

/** Stable Cordis plugin name. */
export const name = 'dsh-plugin-manager'

/** Service key and Remote namespace served by this gateway. */
export const PLUGIN_MANAGER_SERVICE = 'pluginManager'

/**
 * The plugin-manager Remote gateway. Method parameters are plain identifiers
 * so the gateway's source-mode descriptor derivation can read them.
 */
export class PluginManagerGateway extends TypertRemoteService {
  /**
   * Register the service and bind the Remote namespace; register the
   * browser HTTP transport when the webServer service is present.
   * @param ctx - owning Cordis Context (the root of a profile surface).
   */
  constructor(ctx: Context) {
    super(ctx, PLUGIN_MANAGER_SERVICE)
    ctx.inject(['webServer'], (scope) => registerManagerRoutes(scope, () => this.runtime()))
  }

  /** Resolve the active profile directory from the root context's base URL. */
  private runtime(): ManagerRuntime {
    const baseUrl = this.ctx.baseUrl
    if (baseUrl === undefined) {
      throw new Error('dsh-plugin-manager: no baseUrl — mount it inside a profile surface (dsh --profile <name>)')
    }
    return {
      binName: 'dsh-plugin-manager',
      profileDir: fileURLToPath(baseUrl),
      ctx: this.ctx,
    }
  }

  /** List the bundles installed through the manager. */
  @Remote('listBundles')
  listBundles(): PluginManagerBundle[] {
    return listBundlesCore(this.runtime())
  }

  /** Install one bundle by npm/git/file spec and hot-mount its patch rows. */
  @Remote('install')
  install(spec: string): Promise<PluginManagerResult> {
    return installBundle(this.runtime(), spec)
  }

  /** Uninstall one managed bundle and hot-unmount its patch rows. */
  @Remote('uninstall')
  uninstall(packageName: string): Promise<PluginManagerResult> {
    return uninstallBundle(this.runtime(), packageName)
  }

  /** Update one managed bundle, or every managed bundle when `packageName` is empty. */
  @Remote('update')
  update(packageName: string): Promise<PluginManagerResult> {
    return updateBundle(this.runtime(), packageName)
  }

  /** Enable or disable one entry by writing a user-layer disable row. */
  @Remote('setEnabled')
  setEnabled(entryId: string, enabled: boolean): Promise<PluginManagerResult> {
    return setEnabledCore(this.runtime(), entryId, enabled)
  }
}

export default PluginManagerGateway
