/**
 * User patch-layer editing: read, modify, and write the profile's
 * `cordis.patch.yml` with the same dialect the launcher uses, plus bundle
 * patch-row extraction for install/update.
 *
 * The user patch layer is the manager's hot composition surface: it is
 * watched by the launcher's `watchUserPatches` (transactional HMR), so a
 * written change mounts or unmounts plugin entries without a restart, and it
 * is recomposed at boot, so the same rows survive restarts. The manager
 * therefore never touches `dsh.profile.bundles`; it owns its installed
 * bundles through the rows it writes here plus its state file.
 * @module dsh-plugin-manager/patch-layer
 */

import { readFileSync, renameSync, writeFileSync } from 'node:fs'
import * as yaml from 'js-yaml'
import { entryListSchema, type PatchOptions } from '@deepseek-ai/cordis-plugin-include'
import { loadOverlayPatches } from '@deepseek-ai/dsh-app-boot'

/** The user patch file name inside a profile directory. */
export const PROFILE_PATCH_FILENAME = 'cordis.patch.yml'

/** Header written above manager-owned rows; readers ignore comments. */
export const MANAGED_SECTION_HEADER = '# Rows managed by @kyorakuyk/dsh-plugin-manager — edit or remove freely, or uninstall the bundle.'

/**
 * Read the current user patch layer; a missing file is an empty layer.
 * @param file - absolute path of the profile's `cordis.patch.yml`.
 * @returns the parsed patch rows.
 */
export function readUserLayer(file: string): PatchOptions[] {
  let content: string
  try {
    content = readFileSync(file, 'utf8')
  } catch (error) {
    if ((error as NodeJS.ErrnoException | null)?.code === 'ENOENT') return []
    throw error
  }
  const parsed = yaml.load(content, { schema: entryListSchema })
  if (parsed === undefined) return []
  if (!Array.isArray(parsed)) {
    throw new Error(`user patch layer ${file} must be a top-level YAML array`)
  }
  return parsed as PatchOptions[]
}

/**
 * Write a file atomically (tmp + rename) so a crash mid-write cannot leave a
 * truncated file — the launcher watches `cordis.patch.yml` and would compose
 * garbage.
 * @param file - the target path.
 * @param content - the full content to persist.
 */
export function writeFileAtomic(file: string, content: string): void {
  const tmp = `${file}.${process.pid}.tmp`
  writeFileSync(tmp, content)
  renameSync(tmp, file)
}

/**
 * Write a user patch layer, preserving non-manager rows. The dump uses the
 * include's entry-list schema so `!!js` expression nodes round-trip verbatim.
 * @param file - absolute path of the profile's `cordis.patch.yml`.
 * @param patches - the full row list to persist.
 */
export function writeUserLayer(file: string, patches: readonly PatchOptions[]): void {
  const body = yaml.dump([...patches], { schema: entryListSchema, noRefs: true })
  writeFileAtomic(file, `${MANAGED_SECTION_HEADER}\n${body}`)
}

/** Read a bundle's patch rows from its declared patch file. */
export function readBundlePatches(binName: string, patchPath: string): PatchOptions[] {
  return loadOverlayPatches(binName, patchPath)
}

/**
 * The stable keys a patch row owns: inserted entry ids plus its own id.
 * Used to detect collisions and to remove a bundle's rows on uninstall.
 * @param rows - the bundle's patch rows.
 * @returns the owned row keys.
 */
export function rowKeys(rows: readonly PatchOptions[]): readonly string[] {
  const keys: string[] = []
  for (const row of rows) {
    if (Array.isArray(row.insert)) {
      for (const entry of row.insert) {
        if (typeof entry.id === 'string') keys.push(entry.id)
      }
    } else if (typeof row.id === 'string') {
      keys.push(row.id)
    }
  }
  return keys
}

/**
 * Remove rows owned by the given keys from a patch list: drop insert rows
 * whose entries carry a keyed id, and id-targeted rows whose id is keyed.
 * @param patches - the current user layer.
 * @param keys - row keys to remove.
 * @returns the filtered list.
 */
export function withoutRows(patches: readonly PatchOptions[], keys: ReadonlySet<string>): PatchOptions[] {
  return patches.filter((row) => {
    if (Array.isArray(row.insert)) {
      return !row.insert.some(entry => typeof entry.id === 'string' && keys.has(entry.id))
    }
    return !(typeof row.id === 'string' && keys.has(row.id))
  })
}

/**
 * Remove only id-targeted rows (overrides and disables) whose id is keyed,
 * keeping insert rows that define those entries. Used by enable/disable,
 * which must not drop the defining insert.
 *
 * An id-targeted patch mutates its target insert entry IN PLACE (the include
 * pushes insert entries by reference and later id-targeted patches mutate
 * those objects), so a disable also leaves `disabled` merged into the insert
 * entry of the mounted tree. This path strips that residue from insert
 * entries with keyed ids, or re-enabling would never take effect.
 * @param patches - the current patch list.
 * @param keys - row ids to remove overrides/disables for.
 * @returns the filtered list with the keyed entries' `disabled` residue removed.
 */
export function withoutIdRows(patches: readonly PatchOptions[], keys: ReadonlySet<string>): PatchOptions[] {
  const cleaned = patches.map((row) => {
    if (!Array.isArray(row.insert)) return row
    const insert = row.insert.map((entry) => {
      if (!(typeof entry.id === 'string' && keys.has(entry.id))) return entry
      const { disabled: _residue, ...rest } = entry
      return rest
    })
    return { ...row, insert }
  })
  return cleaned.filter(row => !(typeof row.id === 'string' && keys.has(row.id)))
}

/**
 * Detect whether any row key collides with an existing patch list.
 * @param patches - the target patch list.
 * @param keys - the incoming keys.
 * @returns the first colliding key, or undefined when none collide.
 */
export function findCollision(patches: readonly PatchOptions[], keys: ReadonlySet<string>): string | undefined {
  const present = new Set<string>()
  for (const row of patches) {
    if (Array.isArray(row.insert)) {
      for (const entry of row.insert) {
        if (typeof entry.id === 'string' && keys.has(entry.id)) return entry.id
        if (typeof entry.id === 'string') present.add(entry.id)
      }
    } else if (typeof row.id === 'string') {
      if (keys.has(row.id)) return row.id
      present.add(row.id)
    }
  }
  for (const key of keys) {
    if (present.has(key)) return key
  }
  return undefined
}
