/** Wire payload types for the pluginManager Remote namespace. */

/** One bundle installed through the plugin manager. */
export interface PluginManagerBundle {
  /** npm package name of the installed bundle. */
  readonly packageName: string
  /** Installed version from the resolved package manifest, when known. */
  readonly version?: string
  /** The install spec as recorded (npm range, file: path, git URL). */
  readonly spec: string
  /** Patch-row entry ids this bundle owns, for enable/disable. */
  readonly rowIds: readonly string[]
  /** Whether any of the bundle's rows is currently disabled. */
  readonly disabled: boolean
}

/** Structured outcome of one package or lifecycle operation. */
export interface PluginManagerResult {
  readonly ok: boolean
  /** Human-readable outcome or failure reason. */
  readonly message: string
  /** pnpm exit code when the operation ran pnpm and it reported one. */
  readonly exitCode?: number
  /** Tail of captured pnpm output (≤ 8 KiB), for diagnostics. */
  readonly tail?: string
}

/** Persistent state file contents (per profile). */
export interface ManagerState {
  /** Bundles managed through the user patch layer, in install order. */
  readonly bundles: readonly ManagedBundle[]
  /** Enable/disable rows written by the manager, keyed by entry id. */
  readonly disables: Readonly<Record<string, boolean>>
}

/** One managed bundle as recorded in state. */
export interface ManagedBundle {
  readonly packageName: string
  /** The install spec, replayed on update. */
  readonly spec: string
  /** Patch row keys owned by this bundle: insert entry ids and id-targeted row ids. */
  readonly rowIds: readonly string[]
}
