/**
 * HTTP transport for the plugin-manager UI: same-origin JSON endpoints under
 * `/plugin-manager/*`, registered on the webServer service when present.
 *
 * The npm `dsh-api-gateway` package is not installable (its dependency
 * `dsh-type-meta` is unpublished), so the browser half cannot mount a Typert
 * remote contribution; a plugin-owned webserver route is the out-of-tree
 * transport. The route is served to any caller who can reach the server; the
 * web surface defaults to loopback binding, and remote-trust enforcement is
 * a documented limitation.
 * @module dsh-plugin-manager/http
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import {
  installBundle,
  listBundles,
  setEnabled,
  uninstallBundle,
  updateBundle,
  type ManagerRuntime,
} from './manager.js'

/** The route prefix registered on the webServer. */
export const ROUTE_PREFIX = '/plugin-manager'

/** Cap on request body bytes, to bound a hostile POST. */
const BODY_LIMIT = 64 * 1024

/** Read a JSON request body, bounded. */
async function readJson(req: IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += buffer.length
    if (size > BODY_LIMIT) throw new Error('request body too large')
    chunks.push(buffer)
  }
  const text = Buffer.concat(chunks).toString('utf8')
  if (text === '') return {}
  const parsed = JSON.parse(text) as unknown
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new Error('request body must be a JSON object')
  }
  return parsed as Record<string, unknown>
}

/** Write one JSON response; never cacheable — the list must reflect live state. */
function send(res: ServerResponse, status: number, value: unknown): void {
  const body = JSON.stringify(value)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  })
  res.end(body)
}

/** One JSON string field from a body, or undefined. */
function stringField(body: Record<string, unknown>, key: string): string | undefined {
  const value = body[key]
  return typeof value === 'string' ? value : undefined
}

/**
 * Register the plugin-manager HTTP routes on the webServer service.
 * @param ctx - root context; no-op when the webServer service is absent.
 * @param runtime - resolves manager facts per request.
 * @returns the route disposer, or a no-op when no webServer is mounted.
 */
export function registerManagerRoutes(ctx: Context, runtime: () => ManagerRuntime): () => void {
  const webServer = ctx.get('webServer') as { register(route: unknown): () => void } | undefined
  if (webServer === undefined) return () => {}
  return webServer.register({
    kind: 'prefix',
    path: ROUTE_PREFIX,
    handler: async (req: IncomingMessage, res: ServerResponse): Promise<void> => {
      const url = new URL(req.url ?? '/', 'http://x')
      const method = url.pathname.split('/').filter(Boolean)[1] ?? ''
      try {
        if (req.method === 'GET') {
          if (method === 'list') {
            send(res, 200, { ok: true, value: listBundles(runtime()) })
            return
          }
          send(res, 404, { ok: false, message: `unknown endpoint ${ROUTE_PREFIX}/${method}` })
          return
        }
        if (req.method !== 'POST') {
          send(res, 405, { ok: false, message: 'method not allowed' })
          return
        }
        const body = await readJson(req)
        switch (method) {
          case 'install': {
            const spec = stringField(body, 'spec')
            if (spec === undefined) {
              send(res, 400, { ok: false, message: 'spec is required' })
              return
            }
            send(res, 200, await installBundle(runtime(), spec))
            return
          }
          case 'uninstall': {
            const packageName = stringField(body, 'packageName')
            if (packageName === undefined) {
              send(res, 400, { ok: false, message: 'packageName is required' })
              return
            }
            send(res, 200, await uninstallBundle(runtime(), packageName))
            return
          }
          case 'update': {
            const packageName = stringField(body, 'packageName') ?? ''
            send(res, 200, await updateBundle(runtime(), packageName))
            return
          }
          case 'setEnabled': {
            const entryId = stringField(body, 'entryId')
            if (entryId === undefined || typeof body.enabled !== 'boolean') {
              send(res, 400, { ok: false, message: 'entryId and enabled are required' })
              return
            }
            send(res, 200, await setEnabled(runtime(), entryId, body.enabled))
            return
          }
          default:
            send(res, 404, { ok: false, message: `unknown endpoint ${ROUTE_PREFIX}/${method}` })
        }
      } catch (error) {
        send(res, 500, { ok: false, message: error instanceof Error ? error.message : String(error) })
      }
    },
  })
}
