/**
 * pnpm process runner: spawn pnpm in the profile directory, capture output
 * (keeping only the tail for diagnostics), and surface the two failures a
 * caller must distinguish: pnpm missing from PATH, and a hung install.
 * @module dsh-plugin-manager/pnpm
 */

import { spawn } from 'node:child_process'

/** Captured pnpm output is truncated to this many trailing bytes. */
export const PNPM_TAIL_LIMIT = 8 * 1024

/** Outcome of one pnpm run. */
export interface PnpmRunResult {
  /** pnpm exit code, or 1 when the process was killed by the timeout. */
  readonly exitCode: number
  /** Tail of combined stdout/stderr, truncated. */
  readonly tail: string
}

/** `pnpm` is not on PATH; installing profile plugins needs it. */
export class PnpmMissingError extends Error {
  /**
   * @param message - diagnostic text.
   */
  constructor(message: string) {
    super(message)
    this.name = 'PnpmMissingError'
  }
}

/** pnpm did not finish within the configured budget. */
export class PnpmTimeoutError extends Error {
  /**
   * @param message - diagnostic text.
   */
  constructor(message: string) {
    super(message)
    this.name = 'PnpmTimeoutError'
  }
}

/**
 * Run pnpm with the given argv in `cwd`, capturing the output tail.
 *
 * Every invocation gets `--config.minimumReleaseAge=0`: pnpm >= 11 refuses
 * packages published within the default 24h cooldown
 * (`ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION`), which would block installing a
 * bundle the user explicitly asked for in the UI the moment it was published.
 * The manager also appends the offender's scope to the profile's
 * `minimumReleaseAgeExclude` as a second line of defense, but the config flag
 * is the authoritative bypass for manager-driven installs.
 * @param args - pnpm arguments, passed as an argv array (never a shell line).
 * @param cwd - working directory (the profile directory).
 * @param timeoutMs - hard budget; the child is killed on expiry.
 * @returns exit code and output tail.
 * @throws {@link PnpmMissingError} when pnpm is not resolvable, {@link PnpmTimeoutError} on timeout.
 */
export function runPnpm(args: readonly string[], cwd: string, timeoutMs = 600_000): Promise<PnpmRunResult> {
  return new Promise((resolve, reject) => {
    // Windows resolves pnpm through its .cmd shim, which spawn() refuses
    // without a shell since the CVE-2024-27980 hardening.
    const child = spawn('pnpm', [...args, '--config.minimumReleaseAge=0'], {
      cwd,
      stdio: ['ignore', 'pipe', 'pipe'],
      shell: process.platform === 'win32',
    })
    let buffer = ''
    let settled = false
    const sink = (chunk: Buffer): void => {
      buffer = `${buffer}${chunk.toString()}`.slice(-PNPM_TAIL_LIMIT)
    }
    child.stdout?.on('data', sink)
    child.stderr?.on('data', sink)
    child.on('error', (error: NodeJS.ErrnoException) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      if (error.code === 'ENOENT') {
        reject(new PnpmMissingError('pnpm not found on PATH — install pnpm to manage profile plugins'))
      } else {
        reject(error)
      }
    })
    child.on('close', (code) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve({ exitCode: code ?? 1, tail: buffer })
    })
    const timer = setTimeout(() => {
      if (settled) return
      child.kill()
      reject(new PnpmTimeoutError(`pnpm did not finish within ${timeoutMs}ms`))
    }, timeoutMs)
  })
}
