/**
 * Read/write of the profile's `pnpm-workspace.yaml` supply-chain settings.
 *
 * pnpm >= 11 gates installs behind two supply-chain policies:
 *
 * 1. `minimumReleaseAge` (default 1440 minutes / 24h) refuses packages
 *    published within the window unless the package's scope is listed under
 *    `minimumReleaseAgeExclude`. The manager installs freshly published
 *    bundles, so an install can fail with
 *    `ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION` even though the spec is valid.
 *    The manager appends the offending scope (e.g. `@kyorakuyk/*`) and
 *    retries once.
 *
 * 2. `allowBuilds` is a map of exact package specs whose lifecycle scripts
 *    (preinstall/install/postinstall, `prepare` on git deps) may run. A
 *    git-hosted bundle with a `prepare` script fails with
 *    `ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED` unless its exact spec (as pnpm
 *    prints in the error, e.g. `name@git+https://...#<sha>`) is allowed.
 *    The manager extracts that exact spec from the pnpm output, records
 *    `spec: true` in `allowBuilds`, and retries once.
 *
 * Both writes are additive and preserve every other setting in the file
 * (including any `minimumReleaseAge` or `allowBuilds` entries the user
 * chose); missing files are created with a minimal workspace manifest. The
 * file is parsed and re-serialized with js-yaml (a runtime dependency), so
 * unrelated settings, comments are not preserved — but pnpm tolerates a
 * normalized file and this module owns the two supply-chain blocks.
 * @module dsh-plugin-manager/pnpm-workspace
 */

import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import yaml from 'js-yaml'
import { writeFileAtomic } from './patch-layer.js'

/** File name of the pnpm workspace manifest inside a profile. */
export const PNPM_WORKSPACE_FILENAME = 'pnpm-workspace.yaml'

/** Parsed supply-chain settings of a workspace file. */
export interface WorkspaceSettings {
  /** `minimumReleaseAgeExclude` entries (scopes or exact specs). */
  readonly excludes: string[]
  /** `allowBuilds` map: exact package spec -> truthy value. */
  readonly allowBuilds: ReadonlyMap<string, string>
}

/** Default top-level keys for a freshly created workspace file. */
const DEFAULT_KEYS: ReadonlyArray<[string, unknown]> = [
  ['packages', ['.']],
  ['nodeLinker', 'hoisted'],
  ['autoInstallPeers', false],
]

/** Read and parse the workspace file, or return defaults when absent. */
function readWorkspace(profileDir: string): Record<string, unknown> {
  const file = join(profileDir, PNPM_WORKSPACE_FILENAME)
  if (!existsSync(file)) return Object.fromEntries(DEFAULT_KEYS)
  try {
    const parsed = yaml.load(readFileSync(file, 'utf8'))
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return Object.fromEntries(DEFAULT_KEYS)
    }
    return parsed as Record<string, unknown>
  } catch {
    return Object.fromEntries(DEFAULT_KEYS)
  }
}

/** Persist the workspace document, atomically, as YAML. */
function writeWorkspace(profileDir: string, doc: Record<string, unknown>): boolean {
  try {
    const text = yaml.dump(doc, { lineWidth: -1, noRefs: true })
    writeFileAtomic(join(profileDir, PNPM_WORKSPACE_FILENAME), text)
    return true
  } catch {
    return false
  }
}

/**
 * Parse the supply-chain settings of the profile workspace file.
 * @param profileDir - profile directory holding pnpm-workspace.yaml.
 * @returns the exclude list and allowBuilds map (empty when absent).
 */
export function parseWorkspace(profileDir: string): WorkspaceSettings {
  const doc = readWorkspace(profileDir)
  const excludesRaw = doc.minimumReleaseAgeExclude
  const excludes = Array.isArray(excludesRaw)
    ? excludesRaw.filter((item): item is string => typeof item === 'string')
    : []
  const allowRaw = doc.allowBuilds
  const allowBuilds = new Map<string, string>()
  if (allowRaw !== null && typeof allowRaw === 'object' && !Array.isArray(allowRaw)) {
    for (const [key, value] of Object.entries(allowRaw as Record<string, unknown>)) {
      allowBuilds.set(key, typeof value === 'string' ? value : String(value))
    }
  }
  return { excludes, allowBuilds }
}

/**
 * Ensure a scope wildcard (e.g. `@kyorakuyk/*`) is present in
 * `minimumReleaseAgeExclude`, preserving every other setting. Deduplicates;
 * missing file is created with defaults.
 * @param profileDir - profile directory holding pnpm-workspace.yaml.
 * @param scope - the exact wildcard entry to ensure is present.
 * @returns true when the entry is present after the call (no error).
 */
export function ensureMinimumReleaseAgeExclude(profileDir: string, scope: string): boolean {
  try {
    const doc = readWorkspace(profileDir)
    const excludes = Array.isArray(doc.minimumReleaseAgeExclude)
      ? [...doc.minimumReleaseAgeExclude] as unknown[]
      : []
    if (!excludes.includes(scope)) excludes.push(scope)
    doc.minimumReleaseAgeExclude = excludes
    return writeWorkspace(profileDir, doc)
  } catch {
    return false
  }
}

/**
 * Ensure an exact package spec is allowed to run lifecycle scripts: record
 * `spec: true` in `allowBuilds`, preserving every other setting. The spec
 * must be the exact form pnpm prints in
 * `ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED` (e.g.
 * `dsh-cost-meter@git+https://...#<sha>`); a bare package name is not
 * matched by pnpm. pnpm itself may pre-write the key with a placeholder
 * value ("set this to true or false") when it ignored the build; this
 * function normalizes that to `true`.
 * @param profileDir - profile directory holding pnpm-workspace.yaml.
 * @param spec - the exact spec to allow.
 * @returns true when the spec is allowed (value true) after the call.
 */
export function ensureAllowBuilds(profileDir: string, spec: string): boolean {
  try {
    const doc = readWorkspace(profileDir)
    const allow = (doc.allowBuilds !== null && typeof doc.allowBuilds === 'object' && !Array.isArray(doc.allowBuilds))
      ? { ...doc.allowBuilds as Record<string, unknown> }
      : {}
    if (allow[spec] !== true) allow[spec] = true
    doc.allowBuilds = allow
    return writeWorkspace(profileDir, doc)
  } catch {
    return false
  }
}
