/**
 * Core plugin lifecycle operations: install, uninstall, update, list, and
 * enable/disable of profile plugin bundles, hot through the mounted tree.
 *
 * Install runs `pnpm add <spec>` in the profile directory (a real dependency:
 * the package lands in the profile's node_modules and package.json, so pnpm
 * never prunes it), reads the bundle's `dsh.bundle.patch` rows, and writes
 * them into the profile's user patch layer (`cordis.patch.yml`) — the layer
 * the launcher recomposes at boot, so installs persist without touching
 * `dsh.profile.bundles`. Each operation then hot-applies the delta directly
 * to the root Include entry. Enable/disable writes a user-layer disable row
 * that overrides the bundle row by id without duplicating it.
 * @module dsh-plugin-manager/manager
 */

import { createRequire } from 'node:module'
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { dirname, join } from 'node:path'
import type { PatchOptions } from '@deepseek-ai/cordis-plugin-include'
import {
  findCollision,
  PROFILE_PATCH_FILENAME,
  readBundlePatches,
  readUserLayer,
  rowKeys,
  withoutIdRows,
  withoutRows,
  writeFileAtomic,
  writeUserLayer,
} from './patch-layer.js'
import { PnpmMissingError, PnpmTimeoutError, runPnpm } from './pnpm.js'
import { ensureAllowBuilds, ensureMinimumReleaseAgeExclude } from './pnpm-workspace.js'
import { validatePackageSpec } from './spec.js'
import {
  readState,
  replaceBundle,
  withBundle,
  withDisable,
  withoutBundle,
  withoutDisables,
  writeState,
} from './state.js'
import type { ManagedBundle, PluginManagerBundle, PluginManagerResult } from './types.js'

/** Facts a manager operation needs; the gateway supplies them per call. */
export interface ManagerRuntime {
  /** Diagnostic prefix on errors. */
  readonly binName: string
  /** Absolute path of the active profile directory. */
  readonly profileDir: string
  /** Root context carrying the include entry, for direct hot application. */
  readonly ctx: import('@deepseek-ai/cordis').Context
}

/** Slice of a package manifest the manager reads. */
interface PkgManifest {
  readonly name?: string
  readonly version?: string
  readonly dsh?: {
    readonly bundle?: { readonly patch?: string }
    readonly profile?: { readonly bundles?: unknown }
  }
}

/** Map one pnpm runner failure to a structured result. */
function pnpmFailure(error: unknown, tail = ''): PluginManagerResult {
  if (error instanceof PnpmMissingError || error instanceof PnpmTimeoutError) {
    return { ok: false, message: error.message, tail }
  }
  return { ok: false, message: error instanceof Error ? error.message : String(error), tail }
}

/** Run pnpm, converting spawn-level failures into a zero-less result shape. */
async function runPnpmSafe(
  args: readonly string[],
  cwd: string,
): Promise<{ exitCode: number; tail: string }> {
  try {
    return await runPnpm(args, cwd)
  } catch (error) {
    const mapped = pnpmFailure(error)
    // Preserve the diagnostic (e.g. "pnpm not found on PATH") in the tail so
    // the failure message below stays informative.
    return { exitCode: 1, tail: mapped.tail === '' ? mapped.message : `${mapped.message}\n${mapped.tail}` }
  }
}

/** Read a package manifest from a directory, or undefined when unreadable. */
function readPkgManifest(dir: string): PkgManifest | undefined {
  try {
    const parsed = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) as PkgManifest | null
    return parsed === null || typeof parsed !== 'object' ? undefined : parsed
  } catch {
    return undefined
  }
}

/** Resolve a package's directory inside the profile's node_modules. */
function resolvePkgDir(profileDir: string, packageName: string): string | undefined {
  const dir = join(profileDir, 'node_modules', packageName)
  return existsSync(join(dir, 'package.json')) ? dir : undefined
}

/**
 * Resolve a package's directory from the dsh installation. The manager runs
 * inside a profile, whose module walk reaches the healed
 * `$DSH_HOME/profiles/node_modules` fallback (a symlink to the installation's
 * dependency closure), so in-box bundles like `@deepseek-ai/dsh-base` resolve
 * here even though they are not in the profile's own node_modules.
 * @param packageName - the package to resolve.
 * @returns the package directory, or undefined when not resolvable.
 */
function installationPackageDir(packageName: string): string | undefined {
  try {
    return dirname(managerRequire.resolve(`${packageName}/package.json`))
  } catch {
    return undefined
  }
}

const managerRequire = createRequire(import.meta.url)

/** The bundle-declaring package pnpm most recently wrote into the profile. */
function findNewestBundle(profileDir: string): string | undefined {
  const nodeModules = join(profileDir, 'node_modules')
  if (!existsSync(nodeModules)) return undefined
  let best: { name: string; mtime: number } | undefined
  const visit = (dir: string, prefix: string): void => {
    let entries
    try {
      entries = readdirSync(dir, { withFileTypes: true })
    } catch {
      return
    }
    for (const entry of entries) {
      if (entry.name.startsWith('.')) continue
      if (!entry.isDirectory()) continue
      if (entry.name.startsWith('@')) {
        visit(join(dir, entry.name), `${prefix}${entry.name}/`)
        continue
      }
      const pkgDir = join(dir, entry.name)
      const manifest = readPkgManifest(pkgDir)
      if (manifest?.dsh?.bundle?.patch === undefined) continue
      let mtime: number
      try {
        mtime = statSync(pkgDir).mtimeMs
      } catch {
        continue
      }
      if (best === undefined || mtime > best.mtime) best = { name: `${prefix}${entry.name}`, mtime }
    }
  }
  visit(nodeModules, '')
  return best?.name
}

/** The base package name of a bare npm spec (scope included, version stripped). */
function nameFromNpmSpec(spec: string): string | undefined {
  if (!/^@?[a-zA-Z0-9][a-zA-Z0-9._-]*(?:\/[a-zA-Z0-9][a-zA-Z0-9._-]*)?(?:@[a-zA-Z0-9._^~-]+)?$/.test(spec)) return undefined
  const at = spec.indexOf('@', spec.startsWith('@') ? spec.indexOf('/') + 1 : 0)
  return at < 0 ? spec : spec.slice(0, at)
}

/** Scope wildcard of a package name: `@scope/*`, or `name` when unscoped. */
function scopeWildcard(packageName: string): string {
  if (packageName.startsWith('@')) {
    const slash = packageName.indexOf('/')
    return slash < 0 ? packageName : `${packageName.slice(0, slash)}/*`
  }
  return packageName
}

/** True when a pnpm tail reports the minimum-release-age supply-chain gate. */
export function isReleaseAgeViolation(tail: string): boolean {
  return /ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION/.test(tail)
}

/** First offending package name in a pnpm release-age violation tail. */
export function ageViolationPackage(tail: string): string | undefined {
  const match = tail.match(/^\s*(@?[\w.-]+(?:\/[\w.-]+)?)(?:@[^\s]+)? was published at/m)
  return match === null ? undefined : match[1]
}

/** True when pnpm refuses to run a git dependency's build scripts. */
export function isBuildsNotAllowed(tail: string): boolean {
  return /ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED|ERR_PNPM_IGNORED_BUILDS/.test(tail)
}

/**
 * Extract the exact package spec pnpm wants in `allowBuilds` from a
 * `ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED` (or `ERR_PNPM_IGNORED_BUILDS`)
 * tail. pnpm prints a ready-made example block; the spec is the
 * `name@git+...#<sha>` key of the first `spec: <value>` line in it. A bare
 * package name is not accepted by pnpm, so this must be the exact form pnpm
 * printed. The value may be `true` or pnpm's placeholder
 * ("set this to true or false"); the key is what matters.
 */
export function buildsNotAllowedSpec(tail: string): string | undefined {
  // `name@git+...#<sha>: <value>` — the value may be `true` or pnpm's
  // placeholder ("set this to true or false"), and the key may be quoted for
  // scoped packages. Strip surrounding quotes from the match.
  const match = tail.match(/^\s*['"]?([@\w][^\s:]*@git\+[^\s']+(?:#[0-9a-f]+)?)['"]?\s*:\s*.+?\s*$/m)
  return match === null ? undefined : match[1]
}

/** Read the profile manifest's bundle list. */
function readBundles(profileDir: string): string[] {
  const manifest = readPkgManifest(profileDir)
  const bundles = manifest?.dsh?.profile?.bundles
  return Array.isArray(bundles) ? bundles.filter((name): name is string => typeof name === 'string') : []
}

/** Rewrite the profile manifest's bundle list, preserving every other field. */
function writeBundles(profileDir: string, bundles: readonly string[]): void {
  const manifestPath = join(profileDir, 'package.json')
  const manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) as Record<string, unknown>
  const dsh = typeof manifest.dsh === 'object' && manifest.dsh !== null
    ? manifest.dsh as Record<string, unknown>
    : {}
  const profile = typeof dsh.profile === 'object' && dsh.profile !== null
    ? dsh.profile as Record<string, unknown>
    : {}
  manifest.dsh = { ...dsh, profile: { ...profile, bundles: [...bundles] } }
  writeFileAtomic(manifestPath, `${JSON.stringify(manifest, undefined, 2)}\n`)
}

/** Resolve a bundle's patch rows from its installed package. */
function bundleRows(binName: string, profileDir: string, packageName: string): { rows: PatchOptions[] } | { error: string } {
  const pkgDir = resolvePkgDir(profileDir, packageName)
  const manifest = pkgDir === undefined ? undefined : readPkgManifest(pkgDir)
  const patchPath = manifest?.dsh?.bundle?.patch
  if (patchPath === undefined || pkgDir === undefined) {
    return { error: `${packageName} declares no dsh.bundle — it is not a plugin bundle` }
  }
  try {
    return { rows: readBundlePatches(binName, join(pkgDir, patchPath)) }
  } catch (error) {
    return { error: `failed to read bundle patch: ${error instanceof Error ? error.message : String(error)}` }
  }
}

/**
 * Transactionally apply the manager's delta to the mounted composition by
 * updating the root Include entry directly. The user-patch watcher applies
 * user edits; the manager applies its own writes through the same include
 * update, so an operation takes effect even when the file watcher misses a
 * write.
 * @param runtime - manager facts including the root context.
 * @param ownedKeys - row keys this operation removes from the mounted tree.
 * @param addedRows - rows appended to the mounted tree.
 * @param removal - 'insert-rows' removes defining insert rows too (bundle
 * lifecycle); 'id-rows' removes only id-targeted overrides/disables
 * (enable/disable must keep the defining insert).
 * @returns a failure result when the include entry is absent; undefined on success.
 */
async function applyToInclude(
  runtime: ManagerRuntime,
  ownedKeys: ReadonlySet<string>,
  addedRows: readonly PatchOptions[],
  removal: 'insert-rows' | 'id-rows' = 'insert-rows',
): Promise<PluginManagerResult | undefined> {
  const include = [...runtime.ctx.loader.entries()].find(entry => entry.options.id === 'include')
  if (include === undefined) {
    return {
      ok: false,
      message: 'no root include entry in the mounted tree — the change is written to the profile and applies on restart',
    }
  }
  const { patches: _previous, ...rest } = include.options.config as { patches?: readonly PatchOptions[] }
  const current = (include.options.config as { patches?: readonly PatchOptions[] }).patches ?? []
  const filtered = removal === 'insert-rows' ? withoutRows(current, ownedKeys) : withoutIdRows(current, ownedKeys)
  const next = [...filtered, ...structuredClone(addedRows)]
  await include.update({ config: { ...rest, patches: next } })
  return undefined
}

/** Install one bundle: pnpm as a real dependency, rows into the user patch layer, hot apply. */
export async function installBundle(runtime: ManagerRuntime, spec: string): Promise<PluginManagerResult> {
  const invalid = validatePackageSpec(spec)
  if (invalid !== undefined) return { ok: false, message: invalid }
  let pnpm = await runPnpmSafe(['add', spec], runtime.profileDir)
  // pnpm >= 11 supply-chain gates can reject a legitimate install; both are
  // auto-remediated once and the install retried:
  //  - minimumReleaseAge (default 24h): a just-published bundle fails with
  //    ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION unless the offender's scope is
  //    in minimumReleaseAgeExclude.
  //  - allowBuilds: a git dependency with lifecycle scripts fails with
  //    ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED unless its exact spec (as pnpm
  //    prints it) is in allowBuilds.
  if (pnpm.exitCode !== 0) {
    const tail = pnpm.tail
    let remedied = false
    if (isReleaseAgeViolation(tail)) {
      const offender = ageViolationPackage(tail)
      remedied = offender !== undefined
        && ensureMinimumReleaseAgeExclude(runtime.profileDir, scopeWildcard(offender))
    } else if (isBuildsNotAllowed(tail)) {
      const specKey = buildsNotAllowedSpec(tail)
      remedied = specKey !== undefined && ensureAllowBuilds(runtime.profileDir, specKey)
    }
    if (remedied) {
      pnpm = await runPnpmSafe(['add', spec], runtime.profileDir)
    }
  }
  if (pnpm.exitCode !== 0) {
    return {
      ok: false,
      message: `pnpm add failed (exit ${pnpm.exitCode}) — see the output tail`,
      exitCode: pnpm.exitCode,
      tail: pnpm.tail,
    }
  }
  const packageName = findNewestBundle(runtime.profileDir)
    ?? (/^(?:file|link):/.test(spec) ? undefined : nameFromNpmSpec(spec))
  if (packageName === undefined) {
    return { ok: false, message: 'could not resolve the installed package name', tail: pnpm.tail }
  }
  const resolved = bundleRows(runtime.binName, runtime.profileDir, packageName)
  if ('error' in resolved) {
    // Roll back the dependency: the package was added to package.json and
    // node_modules but is not a managed bundle, so it would be residue the
    // UI cannot clean up.
    let rollback
    try {
      rollback = await runPnpm(['remove', packageName], runtime.profileDir)
    } catch {
      rollback = undefined
    }
    return {
      ok: false,
      message: rollback !== undefined && rollback.exitCode === 0
        ? resolved.error
        : `${resolved.error} (and pnpm remove rollback failed — remove ${packageName} from the profile manually)`,
      tail: pnpm.tail,
    }
  }
  const rows = resolved.rows
  const keys = rowKeys(rows)
  const patchFile = join(runtime.profileDir, PROFILE_PATCH_FILENAME)
  const current = readUserLayer(patchFile)
  const collision = findCollision(current, new Set(keys))
  if (collision !== undefined) {
    return { ok: false, message: `row id ${collision} already exists in the user patch layer — another bundle or a user row owns it` }
  }
  const state = readState(runtime.profileDir)
  writeState(runtime.profileDir, withBundle(state, { packageName, spec, rowIds: keys }))
  writeUserLayer(patchFile, [...current, ...structuredClone(rows)])
  const failed = await applyToInclude(runtime, new Set(), rows)
  if (failed !== undefined) return failed
  return { ok: true, message: `installed ${packageName}: ${rows.length} patch rows written and hot-applied` }
}

/** Uninstall one bundle: remove the dependency first, then drop rows, hot-unmount, and forget state. */
export async function uninstallBundle(runtime: ManagerRuntime, packageName: string): Promise<PluginManagerResult> {
  const state = readState(runtime.profileDir)
  const managed = state.bundles.find(bundle => bundle.packageName === packageName)
  if (managed === undefined) {
    return { ok: false, message: `${packageName} is not installed through the plugin manager` }
  }
  // Remove the dependency first: if it fails, nothing else was mutated and
  // the operation stays retryable.
  let pnpm
  try {
    pnpm = await runPnpm(['remove', packageName], runtime.profileDir)
  } catch (error) {
    return pnpmFailure(error)
  }
  if (pnpm.exitCode !== 0) {
    return {
      ok: false,
      message: `pnpm remove failed (exit ${pnpm.exitCode}) — nothing was changed; see the output tail`,
      exitCode: pnpm.exitCode,
      tail: pnpm.tail,
    }
  }
  const patchFile = join(runtime.profileDir, PROFILE_PATCH_FILENAME)
  const keys = new Set(managed.rowIds)
  writeState(runtime.profileDir, withoutDisables(withoutBundle(state, packageName), keys))
  writeUserLayer(patchFile, withoutRows(readUserLayer(patchFile), keys))
  // The CLI's `dsh plugin` reconcile may have added the dependency to
  // `dsh.profile.bundles` (a bundle-declaring dependency it found); remove it
  // so no stale entry stays behind and the next boot does not fail resolving
  // a vanished package.
  const bundles = readBundles(runtime.profileDir)
  if (bundles.includes(packageName)) {
    writeBundles(runtime.profileDir, bundles.filter(name => name !== packageName))
  }
  const failed = await applyToInclude(runtime, keys, [])
  if (failed !== undefined) return failed
  return { ok: true, message: `uninstalled ${packageName}: rows hot-unmounted and the dependency removed` }
}

/** Reinstall one managed bundle and swap its patch rows. */
async function reinstallOne(runtime: ManagerRuntime, bundle: ManagedBundle): Promise<PluginManagerResult> {
  // `pnpm update` refreshes registry packages. A `file:`/`link:` dependency
  // needs a full remove + re-add: pnpm's incremental re-copy of a file:
  // dependency does not materialize newly added files, so the copy would
  // stay stale.
  const local = /^(?:file|link):/.test(bundle.spec)
  let pnpm
  try {
    if (local) {
      await runPnpm(['remove', bundle.packageName], runtime.profileDir)
      pnpm = await runPnpm(['add', bundle.spec], runtime.profileDir)
    } else {
      pnpm = await runPnpm(['update', bundle.packageName], runtime.profileDir)
    }
  } catch (error) {
    return pnpmFailure(error)
  }
  if (pnpm.exitCode !== 0) {
    return {
      ok: false,
      message: `pnpm update failed (exit ${pnpm.exitCode}) — see the output tail`,
      exitCode: pnpm.exitCode,
      tail: pnpm.tail,
    }
  }
  const resolved = bundleRows(runtime.binName, runtime.profileDir, bundle.packageName)
  if ('error' in resolved) return { ok: false, message: resolved.error, tail: pnpm.tail }
  const rows = resolved.rows
  const patchFile = join(runtime.profileDir, PROFILE_PATCH_FILENAME)
  const current = readUserLayer(patchFile)
  const leftover = withoutRows(current, new Set(bundle.rowIds))
  const collision = findCollision(leftover, new Set(rowKeys(rows)))
  if (collision !== undefined) {
    return { ok: false, message: `row id ${collision} collides after update — another bundle or a user row owns it` }
  }
  const state = readState(runtime.profileDir)
  writeState(runtime.profileDir, replaceBundle(state, bundle.packageName, {
    packageName: bundle.packageName,
    spec: bundle.spec,
    rowIds: rowKeys(rows),
  }))
  writeUserLayer(patchFile, [...leftover, ...structuredClone(rows)])
  const failed = await applyToInclude(runtime, new Set(bundle.rowIds), rows)
  if (failed !== undefined) return failed
  return { ok: true, message: `updated ${bundle.packageName}` }
}

/** Update one bundle, or every managed bundle when `packageName` is empty. */
export async function updateBundle(runtime: ManagerRuntime, packageName: string): Promise<PluginManagerResult> {
  const state = readState(runtime.profileDir)
  const targets = packageName === ''
    ? state.bundles
    : state.bundles.filter(bundle => bundle.packageName === packageName)
  if (targets.length === 0) {
    return { ok: false, message: packageName === ''
      ? 'no bundles are installed through the plugin manager'
      : `${packageName} is not installed through the plugin manager` }
  }
  for (const bundle of targets) {
    const result = await reinstallOne(runtime, bundle)
    if (!result.ok) return result
  }
  return { ok: true, message: `updated ${targets.map(bundle => bundle.packageName).join(', ')}` }
}

/** List the bundles installed in the profile (the bundle layer plus any installed-but-not-listed). */
export function listBundles(runtime: ManagerRuntime): PluginManagerBundle[] {
  const state = readState(runtime.profileDir)
  const listed = new Set(readBundles(runtime.profileDir))
  const seen = new Set<string>()
  const bundles: PluginManagerBundle[] = []
  const view = (bundle: ManagedBundle): PluginManagerBundle => {
    const manifest = resolvePkgDir(runtime.profileDir, bundle.packageName) === undefined
      ? undefined
      : readPkgManifest(join(runtime.profileDir, 'node_modules', bundle.packageName))
    return {
      packageName: bundle.packageName,
      version: manifest?.version,
      spec: bundle.spec,
      rowIds: bundle.rowIds,
      disabled: bundle.rowIds.some(id => state.disables[id] === true),
    }
  }
  for (const bundle of state.bundles) {
    if (seen.has(bundle.packageName)) continue
    seen.add(bundle.packageName)
    bundles.push(view(bundle))
  }
  for (const name of listed) {
    if (seen.has(name)) continue
    seen.add(name)
    // A bundles-list entry is a ghost only when its package is resolvable
    // from NEITHER the profile's node_modules NOR the dsh installation
    // (in-box templates resolve from the latter); a ghost would fail boot
    // resolution and must not be reported as installed.
    const localDir = resolvePkgDir(runtime.profileDir, name)
    const manifest = localDir !== undefined
      ? readPkgManifest(localDir)
      : (() => {
        const dir = installationPackageDir(name)
        return dir === undefined ? undefined : readPkgManifest(dir)
      })()
    if (manifest === undefined) continue
    bundles.push({ packageName: name, version: manifest?.version, spec: 'template', rowIds: [], disabled: false })
  }
  return bundles
}

/** Enable or disable one entry: persist a user-layer disable row and hot-apply it. */
export async function setEnabled(runtime: ManagerRuntime, entryId: string, enabled: boolean): Promise<PluginManagerResult> {
  const patchFile = join(runtime.profileDir, PROFILE_PATCH_FILENAME)
  const current = readUserLayer(patchFile)
  const without = current.filter(row => !(typeof row.id === 'string' && row.id === entryId))
  const disableRow: PatchOptions = { id: entryId, disabled: true }
  const next = enabled ? without : [...without, disableRow]
  writeUserLayer(patchFile, next)
  const state = readState(runtime.profileDir)
  writeState(runtime.profileDir, withDisable(state, entryId, !enabled))
  const failed = await applyToInclude(runtime, new Set([entryId]), enabled ? [] : [disableRow], 'id-rows')
  if (failed !== undefined) return failed
  return { ok: true, message: enabled ? `enabled ${entryId}` : `disabled ${entryId}` }
}
