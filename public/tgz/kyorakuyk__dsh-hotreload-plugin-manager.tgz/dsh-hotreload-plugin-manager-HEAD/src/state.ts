/**
 * Per-profile manager state: which bundles the manager installed, their
 * install specs, and the patch-row keys each owns. Stored as
 * `plugin-manager.state.json` beside the profile's `cordis.patch.yml`.
 * @module dsh-plugin-manager/state
 */

import { readFileSync } from 'node:fs'
import { writeFileAtomic } from './patch-layer.js'
import type { ManagedBundle, ManagerState } from './types.js'

/** State file name inside a profile directory. */
export const STATE_FILENAME = 'plugin-manager.state.json'

/** Empty state for a profile that never installed anything. */
export function emptyState(): ManagerState {
  return { bundles: [], disables: {} }
}

/**
 * Read the manager state for a profile; a missing or unreadable file is
 * treated as empty rather than a failure (first install initializes it).
 * @param dir - the profile directory.
 * @returns the parsed state.
 */
export function readState(dir: string): ManagerState {
  try {
    const parsed = JSON.parse(readFileSync(`${dir}/${STATE_FILENAME}`, 'utf8')) as ManagerState | null
    if (parsed === null || typeof parsed !== 'object' || !Array.isArray(parsed.bundles)) return emptyState()
    return parsed
  } catch {
    return emptyState()
  }
}

/**
 * Write the manager state for a profile.
 * @param dir - the profile directory.
 * @param state - the state to persist.
 */
export function writeState(dir: string, state: ManagerState): void {
  writeFileAtomic(`${dir}/${STATE_FILENAME}`, `${JSON.stringify(state, undefined, 2)}\n`)
}

/** Immutable helpers over a state value. */

/** Append a managed bundle. */
export function withBundle(state: ManagerState, bundle: ManagedBundle): ManagerState {
  return { ...state, bundles: [...state.bundles, bundle] }
}

/** Remove a managed bundle by package name. */
export function withoutBundle(state: ManagerState, packageName: string): ManagerState {
  return { ...state, bundles: state.bundles.filter(bundle => bundle.packageName !== packageName) }
}

/** Replace one managed bundle's rows and spec. */
export function replaceBundle(state: ManagerState, packageName: string, bundle: ManagedBundle): ManagerState {
  return { ...state, bundles: state.bundles.map(candidate => candidate.packageName === packageName ? bundle : candidate) }
}

/** Set one enable/disable row. */
export function withDisable(state: ManagerState, entryId: string, disabled: boolean): ManagerState {
  return { ...state, disables: { ...state.disables, [entryId]: disabled } }
}

/** Drop the enable/disable rows for a set of entry ids. */
export function withoutDisables(state: ManagerState, entryIds: ReadonlySet<string>): ManagerState {
  const disables = { ...state.disables }
  for (const id of entryIds) delete disables[id]
  return { ...state, disables }
}
