/**
 * Per-profile manager state: which bundles the manager installed, their
 * install specs, and the patch-row keys each owns. Stored as
 * `plugin-manager.state.json` beside the profile's `cordis.patch.yml`.
 * @module dsh-plugin-manager/state
 */
import type { ManagedBundle, ManagerState } from './types.js';
/** State file name inside a profile directory. */
export declare const STATE_FILENAME = "plugin-manager.state.json";
/** Empty state for a profile that never installed anything. */
export declare function emptyState(): ManagerState;
/**
 * Read the manager state for a profile; a missing or unreadable file is
 * treated as empty rather than a failure (first install initializes it).
 * @param dir - the profile directory.
 * @returns the parsed state.
 */
export declare function readState(dir: string): ManagerState;
/**
 * Write the manager state for a profile.
 * @param dir - the profile directory.
 * @param state - the state to persist.
 */
export declare function writeState(dir: string, state: ManagerState): void;
/** Immutable helpers over a state value. */
/** Append a managed bundle. */
export declare function withBundle(state: ManagerState, bundle: ManagedBundle): ManagerState;
/** Remove a managed bundle by package name. */
export declare function withoutBundle(state: ManagerState, packageName: string): ManagerState;
/** Replace one managed bundle's rows and spec. */
export declare function replaceBundle(state: ManagerState, packageName: string, bundle: ManagedBundle): ManagerState;
/** Set one enable/disable row. */
export declare function withDisable(state: ManagerState, entryId: string, disabled: boolean): ManagerState;
/** Drop the enable/disable rows for a set of entry ids. */
export declare function withoutDisables(state: ManagerState, entryIds: ReadonlySet<string>): ManagerState;
