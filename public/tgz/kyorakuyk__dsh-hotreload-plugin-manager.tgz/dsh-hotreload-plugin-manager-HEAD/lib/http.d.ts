/**
 * HTTP transport for the plugin-manager UI: same-origin JSON endpoints under
 * `/plugin-manager/*`, registered on the webServer service when present.
 *
 * The npm `dsh-api-gateway` package is not installable (its dependency
 * `dsh-type-meta` is unpublished), so the browser half cannot mount a Typert
 * remote contribution; a plugin-owned webserver route is the out-of-tree
 * transport. The route is served to any caller who can reach the server; the
 * web surface defaults to loopback binding, and remote-trust enforcement is
 * a documented limitation.
 * @module dsh-plugin-manager/http
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ManagerRuntime } from './manager.js';
/** The route prefix registered on the webServer. */
export declare const ROUTE_PREFIX = "/plugin-manager";
/**
 * Register the plugin-manager HTTP routes on the webServer service.
 * @param ctx - root context; no-op when the webServer service is absent.
 * @param runtime - resolves manager facts per request.
 * @returns the route disposer, or a no-op when no webServer is mounted.
 */
export declare function registerManagerRoutes(ctx: Context, runtime: () => ManagerRuntime): () => void;
