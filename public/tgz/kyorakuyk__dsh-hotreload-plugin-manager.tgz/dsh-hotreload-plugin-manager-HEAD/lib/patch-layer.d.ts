/**
 * User patch-layer editing: read, modify, and write the profile's
 * `cordis.patch.yml` with the same dialect the launcher uses, plus bundle
 * patch-row extraction for install/update.
 *
 * The user patch layer is the manager's hot composition surface: it is
 * watched by the launcher's `watchUserPatches` (transactional HMR), so a
 * written change mounts or unmounts plugin entries without a restart, and it
 * is recomposed at boot, so the same rows survive restarts. The manager
 * therefore never touches `dsh.profile.bundles`; it owns its installed
 * bundles through the rows it writes here plus its state file.
 * @module dsh-plugin-manager/patch-layer
 */
import { type PatchOptions } from '@deepseek-ai/cordis-plugin-include';
/** The user patch file name inside a profile directory. */
export declare const PROFILE_PATCH_FILENAME = "cordis.patch.yml";
/** Header written above manager-owned rows; readers ignore comments. */
export declare const MANAGED_SECTION_HEADER = "# Rows managed by @kyorakuyk/dsh-plugin-manager \u2014 edit or remove freely, or uninstall the bundle.";
/**
 * Read the current user patch layer; a missing file is an empty layer.
 * @param file - absolute path of the profile's `cordis.patch.yml`.
 * @returns the parsed patch rows.
 */
export declare function readUserLayer(file: string): PatchOptions[];
/**
 * Write a file atomically (tmp + rename) so a crash mid-write cannot leave a
 * truncated file — the launcher watches `cordis.patch.yml` and would compose
 * garbage.
 * @param file - the target path.
 * @param content - the full content to persist.
 */
export declare function writeFileAtomic(file: string, content: string): void;
/**
 * Write a user patch layer, preserving non-manager rows. The dump uses the
 * include's entry-list schema so `!!js` expression nodes round-trip verbatim.
 * @param file - absolute path of the profile's `cordis.patch.yml`.
 * @param patches - the full row list to persist.
 */
export declare function writeUserLayer(file: string, patches: readonly PatchOptions[]): void;
/** Read a bundle's patch rows from its declared patch file. */
export declare function readBundlePatches(binName: string, patchPath: string): PatchOptions[];
/**
 * The stable keys a patch row owns: inserted entry ids plus its own id.
 * Used to detect collisions and to remove a bundle's rows on uninstall.
 * @param rows - the bundle's patch rows.
 * @returns the owned row keys.
 */
export declare function rowKeys(rows: readonly PatchOptions[]): readonly string[];
/**
 * Remove rows owned by the given keys from a patch list: drop insert rows
 * whose entries carry a keyed id, and id-targeted rows whose id is keyed.
 * @param patches - the current user layer.
 * @param keys - row keys to remove.
 * @returns the filtered list.
 */
export declare function withoutRows(patches: readonly PatchOptions[], keys: ReadonlySet<string>): PatchOptions[];
/**
 * Remove only id-targeted rows (overrides and disables) whose id is keyed,
 * keeping insert rows that define those entries. Used by enable/disable,
 * which must not drop the defining insert.
 *
 * An id-targeted patch mutates its target insert entry IN PLACE (the include
 * pushes insert entries by reference and later id-targeted patches mutate
 * those objects), so a disable also leaves `disabled` merged into the insert
 * entry of the mounted tree. This path strips that residue from insert
 * entries with keyed ids, or re-enabling would never take effect.
 * @param patches - the current patch list.
 * @param keys - row ids to remove overrides/disables for.
 * @returns the filtered list with the keyed entries' `disabled` residue removed.
 */
export declare function withoutIdRows(patches: readonly PatchOptions[], keys: ReadonlySet<string>): PatchOptions[];
/**
 * Detect whether any row key collides with an existing patch list.
 * @param patches - the target patch list.
 * @param keys - the incoming keys.
 * @returns the first colliding key, or undefined when none collide.
 */
export declare function findCollision(patches: readonly PatchOptions[], keys: ReadonlySet<string>): string | undefined;
