/**
 * Hand-written type declarations for the browser bundle (`lib/client.js`,
 * produced by esbuild, which does not emit d.ts). Kept in sync with
 * `src/client/index.tsx`.
 */

import type { Context } from '@deepseek-ai/cordis'

/** One installed bundle shown in the tab. */
export interface BundleView {
  readonly packageName: string
  readonly version?: string
  readonly spec: string
  readonly rowIds: readonly string[]
  readonly disabled: boolean
}

/** Structured outcome of one operation. */
export interface OpResult {
  readonly ok: boolean
  readonly message: string
  readonly tail?: string
}

/** The injected face the tab renders with. */
export interface PluginManagerTabInjected {
  list(): Promise<BundleView[]>
  install(spec: string): Promise<OpResult>
  uninstall(packageName: string): Promise<OpResult>
  update(packageName: string): Promise<OpResult>
  setEnabled(entryId: string, enabled: boolean): Promise<OpResult>
}

/** Minimal client-context surface the tab needs (see the source comment). */
export interface ClientContextLike extends Context {
  readonly slots: {
    inject(name: string, fn: () => unknown): unknown
    register(options: Record<string, unknown>, component: unknown): () => void
  }
}

/** Stable plugin name. */
export declare const name: string

/** Services required by the settings registration. */
export declare const inject: readonly string[]

/** The injected face factory. */
export declare function createInjected(): PluginManagerTabInjected

/** Contribute the manager tab to the Plugins settings section. */
export declare function apply(ctx: ClientContextLike): void

/** The tab component. */
export declare function PluginManagerTab(props: PluginManagerTabInjected): unknown
