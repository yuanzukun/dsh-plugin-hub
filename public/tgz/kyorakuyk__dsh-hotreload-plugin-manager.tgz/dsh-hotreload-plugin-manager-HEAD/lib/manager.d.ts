/**
 * Core plugin lifecycle operations: install, uninstall, update, list, and
 * enable/disable of profile plugin bundles, hot through the mounted tree.
 *
 * Install runs `pnpm add <spec>` in the profile directory (a real dependency:
 * the package lands in the profile's node_modules and package.json, so pnpm
 * never prunes it), reads the bundle's `dsh.bundle.patch` rows, and writes
 * them into the profile's user patch layer (`cordis.patch.yml`) — the layer
 * the launcher recomposes at boot, so installs persist without touching
 * `dsh.profile.bundles`. Each operation then hot-applies the delta directly
 * to the root Include entry. Enable/disable writes a user-layer disable row
 * that overrides the bundle row by id without duplicating it.
 * @module dsh-plugin-manager/manager
 */
import type { PluginManagerBundle, PluginManagerResult } from './types.js';
/** Facts a manager operation needs; the gateway supplies them per call. */
export interface ManagerRuntime {
    /** Diagnostic prefix on errors. */
    readonly binName: string;
    /** Absolute path of the active profile directory. */
    readonly profileDir: string;
    /** Root context carrying the include entry, for direct hot application. */
    readonly ctx: import('@deepseek-ai/cordis').Context;
}
/** True when a pnpm tail reports the minimum-release-age supply-chain gate. */
export declare function isReleaseAgeViolation(tail: string): boolean;
/** First offending package name in a pnpm release-age violation tail. */
export declare function ageViolationPackage(tail: string): string | undefined;
/** True when pnpm refuses to run a git dependency's build scripts. */
export declare function isBuildsNotAllowed(tail: string): boolean;
/**
 * Extract the exact package spec pnpm wants in `allowBuilds` from a
 * `ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED` (or `ERR_PNPM_IGNORED_BUILDS`)
 * tail. pnpm prints a ready-made example block; the spec is the
 * `name@git+...#<sha>` key of the first `spec: <value>` line in it. A bare
 * package name is not accepted by pnpm, so this must be the exact form pnpm
 * printed. The value may be `true` or pnpm's placeholder
 * ("set this to true or false"); the key is what matters.
 */
export declare function buildsNotAllowedSpec(tail: string): string | undefined;
/** Install one bundle: pnpm as a real dependency, rows into the user patch layer, hot apply. */
export declare function installBundle(runtime: ManagerRuntime, spec: string): Promise<PluginManagerResult>;
/** Uninstall one bundle: remove the dependency first, then drop rows, hot-unmount, and forget state. */
export declare function uninstallBundle(runtime: ManagerRuntime, packageName: string): Promise<PluginManagerResult>;
/** Update one bundle, or every managed bundle when `packageName` is empty. */
export declare function updateBundle(runtime: ManagerRuntime, packageName: string): Promise<PluginManagerResult>;
/** List the bundles installed in the profile (the bundle layer plus any installed-but-not-listed). */
export declare function listBundles(runtime: ManagerRuntime): PluginManagerBundle[];
/** Enable or disable one entry: persist a user-layer disable row and hot-apply it. */
export declare function setEnabled(runtime: ManagerRuntime, entryId: string, enabled: boolean): Promise<PluginManagerResult>;
