/**
 * Read/write of the profile's `pnpm-workspace.yaml` supply-chain settings.
 *
 * pnpm >= 11 gates installs behind two supply-chain policies:
 *
 * 1. `minimumReleaseAge` (default 1440 minutes / 24h) refuses packages
 *    published within the window unless the package's scope is listed under
 *    `minimumReleaseAgeExclude`. The manager installs freshly published
 *    bundles, so an install can fail with
 *    `ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION` even though the spec is valid.
 *    The manager appends the offending scope (e.g. `@kyorakuyk/*`) and
 *    retries once.
 *
 * 2. `allowBuilds` is a map of exact package specs whose lifecycle scripts
 *    (preinstall/install/postinstall, `prepare` on git deps) may run. A
 *    git-hosted bundle with a `prepare` script fails with
 *    `ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED` unless its exact spec (as pnpm
 *    prints in the error, e.g. `name@git+https://...#<sha>`) is allowed.
 *    The manager extracts that exact spec from the pnpm output, records
 *    `spec: true` in `allowBuilds`, and retries once.
 *
 * Both writes are additive and preserve every other setting in the file
 * (including any `minimumReleaseAge` or `allowBuilds` entries the user
 * chose); missing files are created with a minimal workspace manifest. The
 * file is parsed and re-serialized with js-yaml (a runtime dependency), so
 * unrelated settings, comments are not preserved — but pnpm tolerates a
 * normalized file and this module owns the two supply-chain blocks.
 * @module dsh-plugin-manager/pnpm-workspace
 */
/** File name of the pnpm workspace manifest inside a profile. */
export declare const PNPM_WORKSPACE_FILENAME = "pnpm-workspace.yaml";
/** Parsed supply-chain settings of a workspace file. */
export interface WorkspaceSettings {
    /** `minimumReleaseAgeExclude` entries (scopes or exact specs). */
    readonly excludes: string[];
    /** `allowBuilds` map: exact package spec -> truthy value. */
    readonly allowBuilds: ReadonlyMap<string, string>;
}
/**
 * Parse the supply-chain settings of the profile workspace file.
 * @param profileDir - profile directory holding pnpm-workspace.yaml.
 * @returns the exclude list and allowBuilds map (empty when absent).
 */
export declare function parseWorkspace(profileDir: string): WorkspaceSettings;
/**
 * Ensure a scope wildcard (e.g. `@kyorakuyk/*`) is present in
 * `minimumReleaseAgeExclude`, preserving every other setting. Deduplicates;
 * missing file is created with defaults.
 * @param profileDir - profile directory holding pnpm-workspace.yaml.
 * @param scope - the exact wildcard entry to ensure is present.
 * @returns true when the entry is present after the call (no error).
 */
export declare function ensureMinimumReleaseAgeExclude(profileDir: string, scope: string): boolean;
/**
 * Ensure an exact package spec is allowed to run lifecycle scripts: record
 * `spec: true` in `allowBuilds`, preserving every other setting. The spec
 * must be the exact form pnpm prints in
 * `ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED` (e.g.
 * `dsh-cost-meter@git+https://...#<sha>`); a bare package name is not
 * matched by pnpm. pnpm itself may pre-write the key with a placeholder
 * value ("set this to true or false") when it ignored the build; this
 * function normalizes that to `true`.
 * @param profileDir - profile directory holding pnpm-workspace.yaml.
 * @param spec - the exact spec to allow.
 * @returns true when the spec is allowed (value true) after the call.
 */
export declare function ensureAllowBuilds(profileDir: string, spec: string): boolean;
