/**
 * pnpm process runner: spawn pnpm in the profile directory, capture output
 * (keeping only the tail for diagnostics), and surface the two failures a
 * caller must distinguish: pnpm missing from PATH, and a hung install.
 * @module dsh-plugin-manager/pnpm
 */
/** Captured pnpm output is truncated to this many trailing bytes. */
export declare const PNPM_TAIL_LIMIT: number;
/** Outcome of one pnpm run. */
export interface PnpmRunResult {
    /** pnpm exit code, or 1 when the process was killed by the timeout. */
    readonly exitCode: number;
    /** Tail of combined stdout/stderr, truncated. */
    readonly tail: string;
}
/** `pnpm` is not on PATH; installing profile plugins needs it. */
export declare class PnpmMissingError extends Error {
    /**
     * @param message - diagnostic text.
     */
    constructor(message: string);
}
/** pnpm did not finish within the configured budget. */
export declare class PnpmTimeoutError extends Error {
    /**
     * @param message - diagnostic text.
     */
    constructor(message: string);
}
/**
 * Run pnpm with the given argv in `cwd`, capturing the output tail.
 *
 * Every invocation gets `--config.minimumReleaseAge=0`: pnpm >= 11 refuses
 * packages published within the default 24h cooldown
 * (`ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION`), which would block installing a
 * bundle the user explicitly asked for in the UI the moment it was published.
 * The manager also appends the offender's scope to the profile's
 * `minimumReleaseAgeExclude` as a second line of defense, but the config flag
 * is the authoritative bypass for manager-driven installs.
 * @param args - pnpm arguments, passed as an argv array (never a shell line).
 * @param cwd - working directory (the profile directory).
 * @param timeoutMs - hard budget; the child is killed on expiry.
 * @returns exit code and output tail.
 * @throws {@link PnpmMissingError} when pnpm is not resolvable, {@link PnpmTimeoutError} on timeout.
 */
export declare function runPnpm(args: readonly string[], cwd: string, timeoutMs?: number): Promise<PnpmRunResult>;
