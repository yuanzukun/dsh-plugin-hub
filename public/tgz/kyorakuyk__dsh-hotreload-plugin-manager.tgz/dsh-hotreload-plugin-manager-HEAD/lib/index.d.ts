/**
 * dsh-plugin-manager — host gateway.
 *
 * Web UI plugin hot lifecycle for DeepSeek Harness: install, uninstall,
 * update, list, and enable/disable profile plugin bundles from the running
 * instance without a restart. The gateway is a Typert Remote service; the
 * api-gateway dispatches it through source-mode reflection (no generated
 * artifacts needed). Every operation edits the profile's user patch layer
 * (`cordis.patch.yml`), which the launcher's `watchUserPatches` hot-applies
 * transactionally and which recomposes at boot, so installs survive restarts
 * without touching `dsh.profile.bundles`.
 *
 * The profile directory is derived from the root context's `baseUrl` (the
 * profile's `cordis.yml` directory), so the bundle must be mounted inside a
 * profile surface (`dsh --profile <name>`).
 *
 * @module dsh-plugin-manager
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { PluginManagerBundle, PluginManagerResult } from './types.js';
/** Stable Cordis plugin name. */
export declare const name = "dsh-plugin-manager";
/** Service key and Remote namespace served by this gateway. */
export declare const PLUGIN_MANAGER_SERVICE = "pluginManager";
/**
 * The plugin-manager Remote gateway. Method parameters are plain identifiers
 * so the gateway's source-mode descriptor derivation can read them.
 */
export declare class PluginManagerGateway extends TypertRemoteService {
    /**
     * Register the service and bind the Remote namespace; register the
     * browser HTTP transport when the webServer service is present.
     * @param ctx - owning Cordis Context (the root of a profile surface).
     */
    constructor(ctx: Context);
    /** Resolve the active profile directory from the root context's base URL. */
    private runtime;
    /** List the bundles installed through the manager. */
    listBundles(): PluginManagerBundle[];
    /** Install one bundle by npm/git/file spec and hot-mount its patch rows. */
    install(spec: string): Promise<PluginManagerResult>;
    /** Uninstall one managed bundle and hot-unmount its patch rows. */
    uninstall(packageName: string): Promise<PluginManagerResult>;
    /** Update one managed bundle, or every managed bundle when `packageName` is empty. */
    update(packageName: string): Promise<PluginManagerResult>;
    /** Enable or disable one entry by writing a user-layer disable row. */
    setEnabled(entryId: string, enabled: boolean): Promise<PluginManagerResult>;
}
export default PluginManagerGateway;
