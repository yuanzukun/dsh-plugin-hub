/**
 * Package-spec validation for `pnpm add`. Rejects anything that could smuggle
 * shell metacharacters or whitespace through argv, then admits only the
 * supported spec forms: npm names (scoped or not, optional version), git URLs,
 * the `github:` shorthand, `owner/repo`, and `file:`/`link:` paths.
 * @module dsh-plugin-manager/spec
 */
/**
 * Validate one install spec.
 * @param spec - the raw spec string from the user.
 * @returns an error message when the spec is rejected, or undefined when it may be passed to pnpm.
 */
export declare function validatePackageSpec(spec: string): string | undefined;
