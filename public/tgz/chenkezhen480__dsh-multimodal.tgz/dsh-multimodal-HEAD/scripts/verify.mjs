/**
 * Verify: mount the plugin against the real tools service (exactly like the
 * web profile composes it) to confirm apply() does not throw and the three
 * tools register. Also exercises the "not configured" error contract.
 *
 * Usage: node scripts/verify.mjs
 */

import { Context } from '@deepseek-ai/cordis'
import InvariantRegistry from '@deepseek-ai/dsh-invariants'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import * as Plugin from '../lib/index.js'

const ctx = new Context()
await ctx.plugin(InvariantRegistry)
await ctx.plugin(SystemPrompt, {})
await ctx.plugin(ToolRuntime, {})

try {
  await ctx.plugin({ name: Plugin.name, inject: Plugin.inject, apply: Plugin.apply }, {
    providers: [
      { id: 'my-vision', kind: 'vision', apiBase: 'https://api.openai.com/v1', apiKey: '', model: '' },
      { id: 'my-image', kind: 'image', apiBase: 'https://api.openai.com/v1', apiKey: '', model: '' },
    ],
  })
  console.log('APPLY OK')
  const tools = ctx.tools
  for (const name of ['image_recognize', 'image_generate', 'vision_providers']) {
    const present = tools.get(name) !== undefined
    console.log(`  tool ${name}: ${present ? 'present' : 'MISSING'}`)
    if (!present) process.exitCode = 1
  }
  // The tool-without-a-model contract: calling with an empty model errors.
  const recognize = tools.get('image_recognize')
  try {
    await recognize.execute({ image: 'x.png' }, { signal: new AbortController().signal })
    console.log('  ERROR: image_recognize should have failed without a model')
    process.exitCode = 1
  } catch (error) {
    console.log(`  not-configured contract OK: ${String(error.message).split('\n')[0]}`)
  }
} catch (error) {
  console.error('APPLY THREW:', error)
  process.exitCode = 1
} finally {
  await ctx.fiber.dispose()
}
