/**
 * Verify Volcengine Ark (Doubao Seedream) through the plugin's
 * generateImages(): 1) text-to-image with the configured model; 2) probe
 * image-to-image model candidates using the t2i result as the source.
 *
 * Usage: VOLC_KEY=<ark-api-key> node scripts/verify-volcengine.mjs [i2i-model ...]
 */

import { mkdir } from 'node:fs/promises'
import { join } from 'node:path'
import { generateImages } from '../lib/index.js'

const KEY = process.env.VOLC_KEY ?? ''
if (KEY.length === 0) {
  console.error('usage: VOLC_KEY=<ark-api-key> node scripts/verify-volcengine.mjs [i2i-model ...]')
  process.exit(1)
}

const outDir = join(process.cwd(), 'generated')
await mkdir(outDir, { recursive: true })

const t2iModel = process.env.T2I_MODEL ?? 'doubao-seedream-5-0-pro-260628'
const provider = {
  id: 'my-image',
  kind: 'image',
  apiBase: 'https://ark.cn-beijing.volces.com/api/v3',
  apiKey: KEY,
  model: t2iModel,
}

console.log(`=== 1) text-to-image (${t2iModel}, watermark:false) ===`)
const t2iPaths = await generateImages({
  prompt: 'a red apple on a wooden table, simple product photo',
  provider,
  image: undefined,
  cwd: process.cwd(),
  size: '1024x1024',
  n: 1,
  outputPath: join(outDir, 'ark-t2i-apple.png'),
})
console.log(`saved: ${t2iPaths.join('\n       ')}`)

const i2iCandidates = process.argv.slice(2).length > 0
  ? process.argv.slice(2)
  : [
    'doubao-seedream-5-0-pro-i2i-260628',
    'doubao-seedream-4-0-i2i-250828',
    'doubao-seedream-4-5-i2i-260615',
    'doubao-seedream-3-0-i2i-250528',
  ]

for (const i2iModel of i2iCandidates) {
  console.log(`=== 2) image-to-image probe (${i2iModel}) ===`)
  try {
    const paths = await generateImages({
      prompt: 'turn the apple purple, keep everything else the same',
      provider: { ...provider, model: t2iModel, i2iModel },
      image: t2iPaths[0], // local file → inlined as data URI
      cwd: process.cwd(),
      size: '1024x1024',
      n: 1,
      outputPath: join(outDir, `ark-i2i-${i2iModel}.png`),
    })
    console.log(`OK — saved: ${paths.join('\n       ')}`)
    console.log(`→ 把 i2iModel: '${i2iModel}' 填入 cordis.patch.yml 即可启用图生图`)
    break // first working i2i model wins
  } catch (error) {
    console.log(`FAIL — ${String(error.message).split('\n')[0]}`)
  }
}

console.log('DONE')
