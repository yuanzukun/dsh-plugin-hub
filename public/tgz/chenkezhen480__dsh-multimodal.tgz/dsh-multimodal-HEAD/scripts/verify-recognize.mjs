/**
 * End-to-end check through the plugin's own code path: generate a test PNG
 * on disk, then call the plugin's recognizeImage() with a local file path,
 * exactly like the image_recognize tool does.
 *
 * Usage: ALIYUN_KEY=sk-... node scripts/verify-recognize.mjs
 */

import { writeFile, mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { deflateSync } from 'node:zlib'
import { recognizeImage } from '../lib/index.js'

const KEY = process.env.ALIYUN_KEY ?? ''
if (KEY.length === 0) {
  console.error('usage: ALIYUN_KEY=sk-... node scripts/verify-recognize.mjs')
  process.exit(1)
}

const provider = {
  id: 'my-vision',
  kind: 'vision',
  apiBase: 'https://llm-28tbvsb98v68m6p0.cn-beijing.maas.aliyuncs.com/compatible-mode/v1',
  apiKey: KEY,
  model: 'qwen3.7-flash',
}

function makeTestPng(size = 64) {
  const crcTable = new Int32Array(256)
  for (let n = 0; n < 256; n += 1) {
    let c = n
    for (let k = 0; k < 8; k += 1) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1)
    crcTable[n] = c
  }
  const crc32 = (buf) => {
    let c = -1
    for (const byte of buf) c = crcTable[(c ^ byte) & 0xFF] ^ (c >>> 8)
    return (c ^ -1) >>> 0
  }
  const chunk = (type, data) => {
    const length = Buffer.alloc(4)
    length.writeUInt32BE(data.length)
    const typeBuf = Buffer.from(type, 'ascii')
    const crc = Buffer.alloc(4)
    crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])))
    return Buffer.concat([length, typeBuf, data, crc])
  }
  const raw = Buffer.alloc(size * (1 + size * 3))
  for (let y = 0; y < size; y += 1) {
    const row = y * (1 + size * 3)
    raw[row] = 0
    for (let x = 0; x < size; x += 1) {
      const offset = row + 1 + x * 3
      if (y < size / 2) {
        raw[offset] = 255; raw[offset + 1] = 0; raw[offset + 2] = 0
      } else {
        raw[offset] = 0; raw[offset + 1] = 0; raw[offset + 2] = 255
      }
    }
  }
  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(size, 0)
  ihdr.writeUInt32BE(size, 4)
  ihdr[8] = 8
  ihdr[9] = 2
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw)),
    chunk('IEND', Buffer.alloc(0)),
  ])
}

const dir = await mkdtemp(join(tmpdir(), 'mm-recognize-'))
try {
  const imagePath = join(dir, 'test.png')
  await writeFile(imagePath, makeTestPng())
  console.log(`test image: ${imagePath}`)
  const result = await recognizeImage({
    image: imagePath, // local path → inlined as data URI by the plugin
    prompt: '这张图片上半部分和下半部分各是什么颜色？一句话回答。',
    provider,
    maxTokens: 200,
    temperature: 0.2,
    cwd: dir,
  })
  console.log('recognizeImage OK:')
  console.log(`  ${result}`)
} finally {
  await rm(dir, { recursive: true, force: true })
}
