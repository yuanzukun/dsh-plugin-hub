/**
 * Check the configured Aliyun DashScope OpenAI-compatible endpoint:
 * 1) a plain chat request (connectivity, key, model name);
 * 2) a multimodal request with an inline image (does the model accept
 *    image_url content at all?).
 *
 * Usage: ALIYUN_KEY=sk-... node scripts/check-aliyun-vision.mjs
 */

const BASE = 'https://llm-28tbvsb98v68m6p0.cn-beijing.maas.aliyuncs.com/compatible-mode/v1'
const MODEL = process.env.MODEL ?? 'qwen3.7-flash'
const KEY = process.env.ALIYUN_KEY ?? ''

import { deflateSync } from 'node:zlib'

if (KEY.length === 0) {
  console.error('usage: ALIYUN_KEY=sk-... node scripts/check-aliyun-vision.mjs')
  process.exit(1)
}

// A tiny valid 1x1 PNG as base64.
const TINY_PNG_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='

/** Minimal PNG encoder: solid-color halves (top red, bottom blue), 64x64. */
function makeTestPng(size = 64) {
  const crcTable = new Int32Array(256)
  for (let n = 0; n < 256; n += 1) {
    let c = n
    for (let k = 0; k < 8; k += 1) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1)
    crcTable[n] = c
  }
  const crc32 = (buf) => {
    let c = -1
    for (const byte of buf) c = crcTable[(c ^ byte) & 0xFF] ^ (c >>> 8)
    return (c ^ -1) >>> 0
  }
  const chunk = (type, data) => {
    const length = Buffer.alloc(4)
    length.writeUInt32BE(data.length)
    const typeBuf = Buffer.from(type, 'ascii')
    const crc = Buffer.alloc(4)
    crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])))
    return Buffer.concat([length, typeBuf, data, crc])
  }
  const raw = Buffer.alloc(size * (1 + size * 3))
  for (let y = 0; y < size; y += 1) {
    const row = y * (1 + size * 3)
    raw[row] = 0 // filter: none
    for (let x = 0; x < size; x += 1) {
      const offset = row + 1 + x * 3
      if (y < size / 2) {
        raw[offset] = 255; raw[offset + 1] = 0; raw[offset + 2] = 0 // red
      } else {
        raw[offset] = 0; raw[offset + 1] = 0; raw[offset + 2] = 255 // blue
      }
    }
  }
  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(size, 0)
  ihdr.writeUInt32BE(size, 4)
  ihdr[8] = 8 // bit depth
  ihdr[9] = 2 // color type RGB
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw)),
    chunk('IEND', Buffer.alloc(0)),
  ])
}

async function chat(messages, label) {
  const started = Date.now()
  const response = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${KEY}` },
    body: JSON.stringify({ model: MODEL, messages, max_tokens: 200 }),
  })
  const ms = Date.now() - started
  const text = await response.text()
  let body
  try { body = JSON.parse(text) } catch { body = null }
  if (!response.ok) {
    const detail = body?.error?.message ?? text.slice(0, 300)
    console.log(`[${label}] HTTP ${response.status} (${ms}ms)`)
    console.log(`  ${detail}`)
    return null
  }
  const content = body?.choices?.[0]?.message?.content
  console.log(`[${label}] OK (${ms}ms)`)
  console.log(`  ${String(content).slice(0, 200)}`)
  return content
}

console.log(`model: ${MODEL}`)
console.log(`base:  ${BASE}`)

await chat(
  [{ role: 'user', content: '回复两个字：连通' }],
  'text-only',
)

await chat(
  [{ role: 'user', content: [
    { type: 'text', text: '这张图片的内容是什么？' },
    { type: 'image_url', image_url: { url: `data:image/png;base64,${TINY_PNG_B64}` } },
  ] }],
  'image (1x1 png, expect 400)',
)

const realPng = makeTestPng()
await chat(
  [{ role: 'user', content: [
    { type: 'text', text: '这张图片是什么颜色？上半部分和下半部分各是什么颜色？' },
    { type: 'image_url', image_url: { url: `data:image/png;base64,${realPng.toString('base64')}` } },
  ] }],
  'image (64x64 png)',
)
