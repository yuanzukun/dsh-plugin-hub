# 把剪贴板里的图片（截图）保存为 input/clip.png，然后告诉模型：
#   "识别 input/clip.png"
#
# 用法：截图（Win+Shift+S）后运行：
#   powershell -ExecutionPolicy Bypass -File C:\projects\dsh-harness\dsh-multimodal\scripts\save-clipboard-image.ps1

Add-Type -AssemblyName System.Windows.Forms
$img = [System.Windows.Forms.Clipboard]::GetImage()
if ($null -eq $img) {
    Write-Host "剪贴板里没有图片，请先截图（Win+Shift+S）。" -ForegroundColor Yellow
    exit 1
}
$dir = "C:\projects\dsh-harness\dsh-multimodal\input"
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$name = "clip-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".png"
$path = Join-Path $dir $name
$img.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
Write-Host "已保存: $path" -ForegroundColor Green
Write-Host "现在在对话里发送: 识别 $path"
