/**
 * Probe Volcengine Ark (Doubao Seedream) image-generation models over the
 * OpenAI-compatible endpoint, including the watermark:false parameter.
 * Also tries image-to-image models with an inline source image.
 *
 * Usage: VOLC_KEY=<ark-api-key> node scripts/probe-volcengine.mjs
 *        VOLC_KEY=... node scripts/probe-volcengine.mjs doubao-seedream-4-0-t2i-250828
 */

const BASE = 'https://ark.cn-beijing.volces.com/api/v3'
const KEY = process.env.VOLC_KEY ?? ''
if (KEY.length === 0) {
  console.error('usage: VOLC_KEY=<ark-api-key> node scripts/probe-volcengine.mjs [model-name ...]')
  process.exit(1)
}

const T2I_CANDIDATES = [
  'doubao-seedream-3-0-t2i-250528',
  'doubao-seedream-4-0-t2i-250828',
  'doubao-seedream-3-0-t2i-250415',
  'doubao-seedream-3-0-t2i-241215',
]

const I2I_CANDIDATES = [
  'doubao-seedream-3-0-i2i-250528',
  'doubao-seedream-4-0-i2i-250828',
  'doubao-seedream-3-0-i2i-250415',
]

/** 1x1 PNG as base64 (for i2i input). */
const TINY_PNG_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='

async function probe(model, body, label) {
  const started = Date.now()
  let response
  try {
    response = await fetch(`${BASE}/images/generations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${KEY}` },
      body: JSON.stringify(body),
    })
  } catch (error) {
    console.log(`[${label}] ${model} — NETWORK ERROR: ${String(error).slice(0, 120)}`)
    return
  }
  const ms = Date.now() - started
  const text = await response.text()
  let parsed
  try { parsed = JSON.parse(text) } catch { parsed = null }
  if (!response.ok) {
    const msg = parsed?.error?.message ?? parsed?.message ?? text.slice(0, 160)
    console.log(`[${label}] ${model} — HTTP ${response.status} (${ms}ms): ${msg}`)
    return
  }
  const item = parsed?.data?.[0]
  const summary = item?.b64_json
    ? `b64_json ${Math.round(item.b64_json.length / 1024)} KB`
    : item?.url ? `url ${item.url.slice(0, 70)}…`
    : parsed?.id ? `async task ${parsed.id} (${parsed.status ?? '?'}) — 可能需要轮询，请告知插件作者`
    : 'no data[0]'
  console.log(`[${label}] ${model} — OK (${ms}ms): ${summary}`)
}

const extra = process.argv.slice(2)
const t2iModels = extra.length > 0 ? extra : T2I_CANDIDATES
const i2iModels = extra.length > 0 ? extra : I2I_CANDIDATES

console.log(`probe ${t2iModels.length} t2i candidates + ${i2iModels.length} i2i candidates`)
console.log(`watermark: false (watermark-free request)`)

for (const model of t2iModels) {
  await probe(model, { model, prompt: 'a red apple on a wooden table', n: 1, size: '1024x1024', watermark: false }, 't2i')
}

const source = `data:image/png;base64,${TINY_PNG_B64}`
for (const model of i2iModels) {
  await probe(model, { model, prompt: 'turn the apple purple', image: source, n: 1, size: '1024x1024', watermark: false }, 'i2i')
}

console.log('done — 把 OK 的模型名填入 cordis.patch.yml 的 my-image / my-image-i2i 即可')
