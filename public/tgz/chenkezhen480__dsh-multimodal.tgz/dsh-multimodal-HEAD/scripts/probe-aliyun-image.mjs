/**
 * Probe Aliyun DashScope image-generation models over the OpenAI-compatible
 * endpoint (same key as the vision model). Tests text-to-image model names
 * first, then image-to-image names with an inline source image.
 *
 * Usage: ALIYUN_KEY=sk-... node scripts/probe-aliyun-image.mjs
 */

import { deflateSync } from 'node:zlib'

const BASE = 'https://llm-28tbvsb98v68m6p0.cn-beijing.maas.aliyuncs.com/compatible-mode/v1'
const KEY = process.env.ALIYUN_KEY ?? ''
if (KEY.length === 0) {
  console.error('usage: ALIYUN_KEY=sk-... node scripts/probe-aliyun-image.mjs')
  process.exit(1)
}

/** Minimal PNG: top red, bottom blue, 64x64. */
function makeTestPng(size = 64) {
  const crcTable = new Int32Array(256)
  for (let n = 0; n < 256; n += 1) {
    let c = n
    for (let k = 0; k < 8; k += 1) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1)
    crcTable[n] = c
  }
  const crc32 = (buf) => {
    let c = -1
    for (const byte of buf) c = crcTable[(c ^ byte) & 0xFF] ^ (c >>> 8)
    return (c ^ -1) >>> 0
  }
  const chunk = (type, data) => {
    const length = Buffer.alloc(4)
    length.writeUInt32BE(data.length)
    const typeBuf = Buffer.from(type, 'ascii')
    const crc = Buffer.alloc(4)
    crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])))
    return Buffer.concat([length, typeBuf, data, crc])
  }
  const raw = Buffer.alloc(size * (1 + size * 3))
  for (let y = 0; y < size; y += 1) {
    const row = y * (1 + size * 3)
    raw[row] = 0
    for (let x = 0; x < size; x += 1) {
      const offset = row + 1 + x * 3
      if (y < size / 2) {
        raw[offset] = 255; raw[offset + 1] = 0; raw[offset + 2] = 0
      } else {
        raw[offset] = 0; raw[offset + 1] = 0; raw[offset + 2] = 255
      }
    }
  }
  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(size, 0)
  ihdr.writeUInt32BE(size, 4)
  ihdr[8] = 8
  ihdr[9] = 2
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw)),
    chunk('IEND', Buffer.alloc(0)),
  ])
}

async function probe(model, body, label) {
  const started = Date.now()
  let response
  try {
    response = await fetch(`${BASE}/images/generations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${KEY}` },
      body: JSON.stringify(body),
    })
  } catch (error) {
    console.log(`[${label}] ${model} — NETWORK ERROR: ${String(error).slice(0, 120)}`)
    return
  }
  const ms = Date.now() - started
  const text = await response.text()
  let parsed
  try { parsed = JSON.parse(text) } catch { parsed = null }
  if (!response.ok) {
    console.log(`[${label}] ${model} — HTTP ${response.status} (${ms}ms): ${parsed?.error?.message ?? text.slice(0, 160)}`)
    return
  }
  const item = parsed?.data?.[0]
  const summary = item?.b64_json
    ? `b64_json ${Math.round(item.b64_json.length / 1024)} KB`
    : item?.url ? `url ${item.url.slice(0, 70)}…` : 'no data[0]'
  console.log(`[${label}] ${model} — OK (${ms}ms): ${summary}`)
}

const T2I_PROMPT = 'a red apple on a wooden table, simple product photo'
const I2I_PROMPT = 'turn the red part into purple, keep the blue part'

for (const model of ['wanx2.1-t2i-turbo', 'wanx2.1-t2i-plus', 'wanx-v1']) {
  await probe(model, { model, prompt: T2I_PROMPT, n: 1 }, 't2i')
}

const source = `data:image/png;base64,${makeTestPng().toString('base64')}`
for (const model of ['wanx2.1-i2i-turbo', 'wanx2.1-i2i-plus']) {
  await probe(model, { model, prompt: I2I_PROMPT, image: source, n: 1 }, 'i2i')
}
