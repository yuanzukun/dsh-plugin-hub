/**
 * End-to-end check of the built-in static server: start it over the
 * generated-images directory, then verify a real generated file is served
 * over its http(s) URL — the exact flow image_generate reports to the model.
 *
 * Usage: node scripts/verify-static.mjs
 */

import { join } from 'node:path'
import { startStaticServer } from '../lib/index.js'

// Mirrors the plugin: the server roots at the default output directory and
// generated files land directly inside it.
const root = join(process.cwd(), 'generated')
const server = startStaticServer(root, 0) // random free port
await server.ready
console.log(`serving ${server.root} at ${server.baseUrl}`)

const file = join(root, 'ark-t2i-apple.png')
const url = server.urlFor(file)
console.log(`urlFor(${file}) → ${url}`)
if (url === undefined) {
  console.error('FAIL: urlFor returned undefined')
  process.exit(1)
}

const response = await fetch(url)
const bytes = new Uint8Array(await response.arrayBuffer())
console.log(`GET ${url} → ${response.status} ${response.headers.get('content-type')} ${bytes.length} bytes`)
const isPng = bytes.length > 8
  && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47
const isJpeg = bytes.length > 3 && bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF
console.log(`image magic: ${isPng ? 'PNG' : isJpeg ? 'JPEG' : 'unknown'}`)
if (!response.ok || (!isPng && !isJpeg)) {
  console.error('FAIL: served content is not an image')
  process.exit(1)
}

// A file outside the root must not be reachable.
const outside = server.urlFor('package.json')
console.log(`urlFor(package.json) → ${String(outside)} (must be undefined)`)

await server.close()
console.log('STATIC SERVER OK')
