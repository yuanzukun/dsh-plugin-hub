/**
 * End-to-end check of DashScope-native image generation through the plugin's
 * generateImages(): 1) text-to-image with wanx2.1-t2i-turbo; 2) image-to-
 * image with wanx2.1-i2i-turbo using the first result as the source.
 *
 * Usage: ALIYUN_KEY=sk-... node scripts/verify-aliyun-image.mjs
 */

import { mkdir } from 'node:fs/promises'
import { join } from 'node:path'
import { generateImages, generateViaDashScope } from '../lib/index.js'

const KEY = process.env.ALIYUN_KEY ?? ''
if (KEY.length === 0) {
  console.error('usage: ALIYUN_KEY=sk-... node scripts/verify-aliyun-image.mjs')
  process.exit(1)
}

const outDir = join(process.cwd(), 'generated')
await mkdir(outDir, { recursive: true })

const t2iProvider = {
  id: 'my-image',
  kind: 'image',
  apiBase: 'https://dashscope.aliyuncs.com',
  apiKey: KEY,
  model: 'wanx2.1-t2i-turbo',
  protocol: 'dashscope-native',
  size: '1024*1024',
}

console.log('=== 1) text-to-image (wanx2.1-t2i-turbo) ===')
const t2iPaths = await generateImages({
  prompt: 'a red apple on a wooden table, simple product photo',
  provider: t2iProvider,
  image: undefined,
  cwd: process.cwd(),
  size: undefined,
  n: 1,
  outputPath: join(outDir, 't2i-apple.png'),
})
console.log(`saved: ${t2iPaths.join('\n       ')}`)

const i2iProvider = {
  ...t2iProvider,
  id: 'my-image-i2i',
  model: 'wanx-v1',
}
console.log('=== 2) image-to-image (wanx-v1, source = t2i public url) ===')
const t2iTask = await generateViaDashScope({
  prompt: 'a red apple on a wooden table, simple product photo',
  provider: t2iProvider,
  imageUrl: undefined,
  size: undefined,
  n: 1,
})
const i2iPaths = await generateImages({
  prompt: 'turn the apple purple, keep everything else the same',
  provider: i2iProvider,
  image: t2iTask.urls[0], // public http(s) URL accepted by DashScope
  cwd: process.cwd(),
  size: undefined,
  n: 1,
  outputPath: join(outDir, 'i2i-purple-apple.png'),
})
console.log(`saved: ${i2iPaths.join('\n       ')}`)

console.log('ALL OK')
