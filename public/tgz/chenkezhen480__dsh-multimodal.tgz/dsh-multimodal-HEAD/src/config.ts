/**
 * Deployment configuration for the multimodal (image) plugin.
 *
 * The plugin ships NO default models: every external model must be declared
 * by the deployer in the `providers` list (an OpenAI-compatible endpoint +
 * key + model name). A tool invoked against a provider whose `apiBase`,
 * `model`, or `apiKey` is empty fails with a clear error instead of guessing.
 *
 * @module dsh-plugin-multimodal/config
 */

import z from '@deepseek-ai/schemastery'

/** Settings namespace registered with the harness settings service. */
export const SETTINGS_NAMESPACE = 'multimodal'

/** What a provider endpoint is used for. */
export const PROVIDER_KINDS = ['vision', 'image'] as const
export type ProviderKind = (typeof PROVIDER_KINDS)[number]

/** API protocol used for image generation. */
export const PROTOCOLS = ['openai', 'dashscope-native'] as const
export type Protocol = (typeof PROTOCOLS)[number]

export interface ProviderConfig {
  /** Stable id the model passes to a tool's `provider` parameter. */
  readonly id: string
  /** `vision` = image recognition (chat/completions, multimodal); `image` = image generation (images/generations). */
  readonly kind: ProviderKind
  /** OpenAI-compatible endpoint base, e.g. `https://api.openai.com/v1` or `https://api.siliconflow.cn/v1`. */
  readonly apiBase: string
  /** API key (secret). Must be filled by the deployer. */
  readonly apiKey: string
  /** Model name sent to the API. Must be filled by the deployer. */
  readonly model: string
  /**
   * Optional image-to-image model name. When a tool call passes an `image`
   * argument and this is set, it is used instead of `model` — one provider
   * covers both text-to-image and image-to-image (e.g. Doubao Seedream t2i
   * vs i2i are separate models). Omit when the model handles both (e.g.
   * gpt-image-1).
   */
  readonly i2iModel?: string
  /**
   * Image-generation protocol. `openai` (default) calls
   * `images/generations`; `dashscope-native` uses the DashScope async task
   * API (`/api/v1/services/aigc/text2image/image-synthesis` + task polling),
   * needed when the OpenAI-compatible gateway does not expose image routes
   * (some Aliyun deployments). Vision providers always use chat/completions.
   */
  readonly protocol?: Protocol
  /**
   * Watermark control for OpenAI-compatible image endpoints that support a
   * `watermark` parameter (e.g. Volcengine Ark Doubao Seedream). Defaults to
   * `false` — watermark-free output. Set `true` to keep the vendor's
   * watermark. Endpoints that reject the parameter are retried without it.
   */
  readonly watermark?: boolean
  /** Default output size for image generation, e.g. `1024x1024` (image kind only). */
  readonly size?: string
  /** Default max output tokens for recognition (vision kind only). */
  readonly maxTokens?: number
  /** Default sampling temperature for recognition (vision kind only). */
  readonly temperature?: number
}

export interface Config {
  /**
   * External API models. May be empty: the plugin still loads, and every
   * model-facing tool reports a clear "not configured" error until at least
   * one matching provider is filled in.
   */
  readonly providers?: ProviderConfig[]
  /**
   * Directory where generated images are saved. Empty means
   * `<caller workspace>/generated`. Relative paths resolve against the
   * caller workspace; absolute paths are used as-is.
   */
  readonly outputDir?: string
  /**
   * Port for the built-in static file server that exposes generated images
   * to the Web GUI as `http://127.0.0.1:<port>/<file>` markdown image URLs.
   * `0` disables the server (results then carry local paths only).
   */
  readonly staticPort?: number
}

export interface ResolvedConfig {
  readonly providers: readonly ProviderConfig[]
  readonly outputDir: string | undefined
  readonly staticPort: number
}

/** Schemastery schema for Loader defaults, settings registration, and config docs. */
export const Config: z<Config> = z.object({
  providers: z.array(z.object({
    id: z.string().required().description('Stable id the model passes to a tool\'s provider parameter.'),
    kind: z.union([z.const('vision'), z.const('image')]).required()
      .description('vision = image recognition (chat/completions); image = image generation (images/generations).'),
    apiBase: z.string().default('').description('OpenAI-compatible endpoint base, e.g. https://api.openai.com/v1. Empty values are reported when a tool is called.'),
    apiKey: z.string().role('secret').default('').description('API key. Empty values are reported when a tool is called.'),
    model: z.string().default('').description('Model name sent to the API. Empty values are reported when a tool is called.'),
    i2iModel: z.string().description('Optional image-to-image model used when a call passes an image argument (e.g. Doubao Seedream i2i); falls back to model.'),
    protocol: z.union([z.const('openai'), z.const('dashscope-native')])
      .description('Image-generation protocol: openai (images/generations, default) or dashscope-native (async task API for deployments without the OpenAI image route).'),
    watermark: z.boolean().default(false)
      .description('Watermark flag sent to OpenAI-compatible image endpoints; defaults to false (watermark-free). Endpoints rejecting the parameter are retried without it.'),
    size: z.string().description('Default output size for image generation, e.g. 1024x1024.'),
    maxTokens: z.number().step(1).min(1).description('Default max output tokens for recognition.'),
    temperature: z.number().min(0).max(2).description('Default sampling temperature for recognition.'),
  })).description('External API models (OpenAI compatible). May be empty.'),
  outputDir: z.string().description('Directory for generated images; empty = <caller workspace>/generated.'),
  staticPort: z.number().step(1).min(0).max(65535).default(3081)
    .description('Port for the built-in static server exposing generated images to the Web GUI; 0 disables it.'),
})

/**
 * Validate and resolve the configuration. Loose on purpose: an empty
 * `providers` list or an empty `apiBase`/`model`/`apiKey` does NOT fail loading —
 * the plugin comes up and the tools surface the missing configuration at
 * call time with actionable errors.
 */
export function resolveConfig(config: Config): ResolvedConfig {
  const providers = [...(config.providers ?? [])]
  const ids = new Set<string>()
  for (const provider of providers) {
    if (provider.id.length === 0) {
      throw new TypeError('multimodal: provider id must be non-empty')
    }
    if (ids.has(provider.id)) {
      throw new TypeError(`multimodal: duplicate provider id "${provider.id}"`)
    }
    ids.add(provider.id)
  }
  return {
    providers,
    outputDir: (config.outputDir ?? '').trim().length > 0 ? config.outputDir!.trim() : undefined,
    staticPort: config.staticPort ?? 3081,
  }
}

/** Clear, actionable Chinese error for a provider missing its endpoint. */
export function missingApiBaseError(id: string): Error {
  return new Error(
    `multimodal: provider "${id}" 未配置 apiBase。`
    + '请在插件包内 cordis.patch.yml 的 providers 中填写 OpenAI 兼容端点，然后重启 Web profile。',
  )
}

/** Clear, actionable Chinese error for a provider missing its model. */
export function missingModelError(id: string): Error {
  return new Error(
    `multimodal: provider "${id}" 未配置 model（model 为空）。`
    + '请在插件包内 cordis.patch.yml 的 providers 中为它填写模型名（如 gpt-4o、Qwen/Qwen2.5-VL-72B-Instruct、'
    + 'black-forest-labs/FLUX.1-schnell），然后重启 dsh web。',
  )
}

/** Clear, actionable Chinese error for a provider missing its apiKey. */
export function missingApiKeyError(id: string): Error {
  return new Error(
    `multimodal: provider "${id}" 未配置 apiKey。`
    + '请在插件包内 cordis.patch.yml 的 providers 中填写该端点的 API Key，然后重启 dsh web。',
  )
}

/** No provider of the requested kind is configured at all. */
export function noProviderError(kind: ProviderKind): Error {
  const example = kind === 'vision'
    ? '{ id: my-vision, kind: vision, apiBase: https://api.openai.com/v1, apiKey: sk-..., model: gpt-4o }'
    : '{ id: my-image, kind: image, apiBase: https://api.openai.com/v1, apiKey: sk-..., model: gpt-image-1 }'
  return new Error(
    `multimodal: 未配置任何 ${kind} 类型的外部模型。`
    + `请在插件包内 cordis.patch.yml 的 providers 中添加一项，例如 ${example}，然后重启 dsh web。`,
  )
}
