/**
 * File and URL helpers: turn an image reference into something the API
 * accepts, and resolve where generated images should be saved.
 *
 * @module dsh-plugin-multimodal/util
 */

import { readFile, mkdir, writeFile } from 'node:fs/promises'
import { extname, isAbsolute, join, resolve, sep } from 'node:path'

/** Upper bound for images inlined into a vision request (25 MiB). */
export const MAX_INLINE_BYTES = 25 * 1024 * 1024

const IMAGE_EXT: Readonly<Record<string, string>> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.bmp': 'image/bmp',
  '.svg': 'image/svg+xml',
}

function mimeOf(extension: string): string | undefined {
  return IMAGE_EXT[extension.toLowerCase()]
}

/**
 * Convert an image reference to the value sent in `image_url.url`:
 *  - `data:` URIs pass through untouched;
 *  - `http(s)://` URLs pass through untouched (the API fetches them);
 *  - anything else is a local file path (absolute, or relative to `cwd`),
 *    read and inlined as a base64 data URI.
 */
export async function resolveImageUrl(reference: string, cwd: string): Promise<string> {
  const trimmed = reference.trim()
  if (trimmed.length === 0) throw new Error('multimodal: image 不能为空')
  if (trimmed.startsWith('data:')) return trimmed
  if (/^https?:\/\//iu.test(trimmed)) return trimmed
  const filePath = isAbsolute(trimmed) ? trimmed : resolve(cwd, trimmed)
  const buffer = await readFile(filePath)
  if (buffer.byteLength > MAX_INLINE_BYTES) {
    throw new Error(
      `multimodal: 图片文件过大（${Math.round(buffer.byteLength / 1024 / 1024)} MiB），`
      + `超过 ${Math.round(MAX_INLINE_BYTES / 1024 / 1024)} MiB 上限。请压缩后再试。`,
    )
  }
  const mime = mimeOf(extname(filePath))
  if (mime === undefined) {
    throw new Error(`multimodal: 不支持的图片格式 "${extname(filePath)}"。支持 png/jpg/jpeg/gif/webp/bmp/svg。`)
  }
  return `data:${mime};base64,${buffer.toString('base64')}`
}

/** Default output directory: `<caller workspace>/generated` (created on demand). */
export function defaultOutputDir(cwd: string): string {
  return join(cwd, 'generated')
}

/**
 * Resolve the final output path for a generated image.
 * `outputDir` (config) wins over the caller workspace; an explicit
 * `outputPath` from the tool call wins over both. A directory target gets a
 * unique filename; a file target is used as-is (missing parent dirs are
 * created).
 */
export function resolveOutputPath(
  cwd: string,
  outputDir: string | undefined,
  outputPath: string | undefined,
  filename: string,
): string {
  if (outputPath !== undefined && outputPath.trim().length > 0) {
    const requested = outputPath.trim()
    return looksLikeDirectory(requested) ? join(expand(requested, cwd), filename) : expand(requested, cwd)
  }
  const base = outputDir !== undefined && outputDir.length > 0 ? expand(outputDir, cwd) : defaultOutputDir(cwd)
  return join(base, filename)
}

/** Ensure the parent directory exists and write bytes; returns the path. */
export async function saveBytes(filePath: string, bytes: Uint8Array): Promise<string> {
  await mkdir(dirnameOf(filePath), { recursive: true })
  await writeFile(filePath, bytes)
  return filePath
}

function expand(path: string, cwd: string): string {
  return isAbsolute(path) ? path : resolve(cwd, path)
}

function dirnameOf(path: string): string {
  const index = path.lastIndexOf(sep)
  return index > 0 ? path.slice(0, index) : '.'
}

/** A target "looks like" a directory when it ends with a separator. */
function looksLikeDirectory(path: string): boolean {
  return path.endsWith('/') || path.endsWith('\\')
}

/** Unique image filename: `image-<yyyyMMdd-HHmmss>-<rand>.png`. */
export function uniqueImageName(now: Date = new Date()): string {
  const pad = (value: number): string => String(value).padStart(2, '0')
  const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`
    + `-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`
  const rand = Math.random().toString(36).slice(2, 8)
  return `image-${stamp}-${rand}.png`
}

/** Guess an extension from a Content-Type header; defaults to png. */
export function extensionForContentType(contentType: string | null): string {
  if (contentType === null) return '.png'
  const match = /image\/(png|jpe?g|webp|gif|bmp)/iu.exec(contentType)
  if (match === null) return '.png'
  const raw = match[1]!.toLowerCase()
  return raw === 'jpeg' ? '.jpg' : `.${raw}`
}

/** Guess the image extension from the leading bytes (magic numbers). */
export function extensionForBytes(bytes: Uint8Array): string {
  if (bytes.length >= 3 && bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF) return '.jpg'
  if (bytes.length >= 8
    && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47
    && bytes[4] === 0x0D && bytes[5] === 0x0A && bytes[6] === 0x1A && bytes[7] === 0x0A) return '.png'
  if (bytes.length >= 12
    && bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46
    && bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50) return '.webp'
  if (bytes.length >= 4 && bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46
    && (bytes[3] === 0x38 || bytes[3] === 0x39)) return '.gif'
  return '.png'
}
