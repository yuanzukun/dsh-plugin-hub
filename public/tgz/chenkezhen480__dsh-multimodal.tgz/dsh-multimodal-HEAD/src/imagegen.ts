/**
 * Image generation client: `images/generations` against any OpenAI-compatible
 * endpoint. Tries `response_format: b64_json` first; when the endpoint
 * rejects that option, retries without it and downloads the returned URL.
 *
 * @module dsh-plugin-multimodal/imagegen
 */

import type { ProviderConfig } from './config.ts'
import { generateViaDashScope } from './dashscope.ts'
import { extensionForBytes, extensionForContentType, resolveImageUrl, saveBytes } from './util.ts'
import { apiError, joinBase } from './vision.ts'

export interface GenerateInput {
  /** The text prompt describing the image to create. */
  readonly prompt: string
  readonly provider: ProviderConfig
  /** Optional source image for image-to-image (editing / variant): local
   *  path, http(s) URL, or data URI. Sent as the `image` field. */
  readonly image: string | undefined
  /** Caller workspace, used to resolve relative image paths. */
  readonly cwd: string
  /** Output size such as `1024x1024`; falls back to the provider default. */
  readonly size: string | undefined
  /** Number of images to generate; falls back to 1. */
  readonly n: number | undefined
  /** Final file path where the image is saved. */
  readonly outputPath: string
  readonly signal?: AbortSignal
}

interface GenerationData {
  readonly b64_json?: string
  readonly url?: string
}

/** Generate one or more images and save them; returns the saved file paths. */
export async function generateImages(input: GenerateInput): Promise<readonly string[]> {
  const { provider, signal } = input
  const count = typeof input.n === 'number' && Number.isInteger(input.n) && input.n >= 1
    ? Math.min(input.n, 4)
    : 1
  // One provider covers both modes: an `image` argument switches to the
  // provider's `i2iModel` when configured (text-to-image and image-to-image
  // are separate model names on some vendors, e.g. Doubao Seedream).
  const hasImage = input.image !== undefined && input.image.trim().length > 0
  const effectiveModel = hasImage && provider.i2iModel !== undefined && provider.i2iModel.trim().length > 0
    ? provider.i2iModel
    : provider.model

  // DashScope native protocol: async task + polling (the OpenAI-compatible
  // gateway of some Aliyun deployments does not expose image routes).
  if (provider.protocol === 'dashscope-native') {
    const imageUrl = hasImage ? await resolveImageUrl(input.image!, input.cwd) : undefined
    const task = await generateViaDashScope({
      prompt: input.prompt,
      provider: { ...provider, model: effectiveModel },
      imageUrl,
      size: input.size,
      n: count,
      signal,
    })
    const paths: string[] = []
    for (let index = 0; index < task.urls.length; index += 1) {
      const url = task.urls[index]
      if (url === undefined) continue
      const filePath = task.urls.length > 1 ? withIndex(input.outputPath, index) : input.outputPath
      paths.push(await downloadAndSave(url, filePath, signal))
    }
    if (paths.length === 0) {
      throw new Error('multimodal: DashScope 任务未返回任何可下载的图片。')
    }
    return paths
  }

  const baseBody: Record<string, unknown> = {
    model: effectiveModel,
    prompt: input.prompt,
    n: count,
    // Watermark-free by default on OpenAI-compatible image endpoints that
    // support a `watermark` parameter (e.g. Volcengine Ark Doubao Seedream).
    // Set `watermark: true` on the provider to keep the vendor's mark.
    watermark: provider.watermark ?? false,
  }
  if (hasImage) {
    // Image-to-image: inline the source image (or pass an http(s) URL
    // through) so the endpoint can edit/vary it.
    baseBody.image = await resolveImageUrl(input.image!, input.cwd)
  }
  if (input.size !== undefined && input.size.trim().length > 0) {
    baseBody.size = input.size.trim()
  } else if (provider.size !== undefined && provider.size.trim().length > 0) {
    baseBody.size = provider.size.trim()
  }

  // Parameter-compatibility ladder: try the full set, then progressively
  // drop parameters the endpoint rejects (some proxies/gateways do not
  // support `watermark` and/or `response_format`).
  const attempts: Array<Record<string, unknown>> = [
    { ...baseBody, response_format: 'b64_json' },
    { ...omitKeys(baseBody, ['watermark']), response_format: 'b64_json' },
    omitKeys(baseBody, ['watermark']),
  ]
  let data: GenerationData[] | undefined
  let lastError: unknown
  for (const candidate of attempts) {
    try {
      data = await postGenerations(candidate, provider, signal)
      break
    } catch (error) {
      lastError = error
      if (!(error instanceof Error) || !/response_format|watermark|unsupported|invalid|unknown/i.test(error.message)) {
        throw error
      }
    }
  }
  if (data === undefined) throw lastError

  if (!Array.isArray(data) || data.length === 0) {
    throw new Error('multimodal: 图像生成接口返回了空结果（data 数组为空）。请检查 provider 配置是否正确。')
  }

  const paths: string[] = []
  const base = outputBase(input.outputPath)
  for (let index = 0; index < data.length; index += 1) {
    const item = data[index]
    if (item === undefined) continue
    if (typeof item.b64_json === 'string' && item.b64_json.length > 0) {
      const bytes = Buffer.from(item.b64_json, 'base64')
      if (bytes.byteLength === 0) {
        throw new Error('multimodal: 图像生成接口返回了空的 base64 数据。')
      }
      // The real format only shows in the magic bytes (e.g. Doubao Seedream
      // returns JPEG payloads); fix the extension so Content-Type matches.
      const base = count > 1 ? withIndex(input.outputPath, index) : input.outputPath
      const filePath = replaceExtension(base, extensionForBytes(bytes))
      paths.push(await saveBytes(filePath, bytes))
      continue
    }
    if (typeof item.url === 'string' && item.url.length > 0) {
      const filePath = count > 1
        ? withIndex(input.outputPath, index)
        : input.outputPath
      paths.push(await downloadAndSave(item.url, filePath, signal))
      continue
    }
    throw new Error('multimodal: 图像生成接口返回的条目既没有 b64_json 也没有 url。')
  }
  if (paths.length === 0) {
    throw new Error('multimodal: 未能从图像生成接口保存任何图片。')
  }
  return paths
}

/** Download a remote image and save it to disk; returns the saved path. */
async function downloadAndSave(
  url: string,
  filePath: string,
  signal: AbortSignal | undefined,
): Promise<string> {
  const response = await fetch(url, { signal })
  if (!response.ok) {
    throw await apiError('image download', response)
  }
  const contentType = response.headers.get('content-type')
  const bytes = new Uint8Array(await response.arrayBuffer())
  const finalPath = replaceExtension(filePath, extensionForContentType(contentType))
  return await saveBytes(finalPath, bytes)
}

async function postGenerations(
  body: Record<string, unknown>,
  provider: ProviderConfig,
  signal: AbortSignal | undefined,
): Promise<GenerationData[]> {
  const response = await fetch(joinBase(provider.apiBase, 'images/generations'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${provider.apiKey}`,
    },
    body: JSON.stringify(body),
    signal,
  })
  if (!response.ok) {
    throw await apiError('images/generations', response)
  }
  const data = await response.json() as { data?: GenerationData[] }
  return data.data ?? []
}

/** Directory part of the output path (the base every file shares). */
function outputBase(outputPath: string): string {
  const index = Math.max(outputPath.lastIndexOf('/'), outputPath.lastIndexOf('\\'))
  return index > 0 ? outputPath.slice(0, index) : '.'
}

/** Copy of `body` without the listed keys. */
function omitKeys(body: Record<string, unknown>, keys: readonly string[]): Record<string, unknown> {
  const result: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(body)) {
    if (!keys.includes(key)) result[key] = value
  }
  return result
}

/** `dir/name.png` → `dir/name-2.png` for multi-image results. */
function withIndex(outputPath: string, index: number): string {
  const dot = outputPath.lastIndexOf('.')
  if (dot <= 0) return `${outputPath}-${index + 1}`
  return `${outputPath.slice(0, dot)}-${index + 1}${outputPath.slice(dot)}`
}

/** Replace the file extension (for URL downloads with a guessed type). */
function replaceExtension(outputPath: string, extension: string): string {
  const dot = outputPath.lastIndexOf('.')
  return dot > 0 ? `${outputPath.slice(0, dot)}${extension}` : `${outputPath}${extension}`
}
