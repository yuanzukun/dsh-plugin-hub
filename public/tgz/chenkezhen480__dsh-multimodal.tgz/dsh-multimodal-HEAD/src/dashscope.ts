/**
 * DashScope native (async task) image generation adapter.
 *
 * Some Aliyun DashScope deployments only expose chat through their
 * OpenAI-compatible gateway and require the NATIVE protocol for image
 * generation: submit an async task (`image-synthesis`), poll
 * `/api/v1/tasks/{id}` until SUCCEEDED, then download the result URLs.
 *
 * @module dsh-plugin-multimodal/dashscope
 */

import type { ProviderConfig } from './config.ts'

/** Default base host for the native protocol. */
export const DASHSCOPE_HOST = 'https://dashscope.aliyuncs.com'

export interface DashScopeGenerateInput {
  readonly prompt: string
  readonly provider: ProviderConfig
  /** Data URI or http(s) URL of a source image (image-to-image models). */
  readonly imageUrl: string | undefined
  /** `1024*1024` style size (DashScope uses an asterisk). */
  readonly size: string | undefined
  readonly n: number | undefined
  readonly signal?: AbortSignal
  /** Poll interval; overridable for tests. */
  readonly pollIntervalMs?: number
}

export interface DashScopeTaskResult {
  readonly urls: readonly string[]
  readonly taskId: string
}

interface TaskResponse {
  readonly output?: {
    readonly task_id?: string
    readonly task_status?: string
    readonly results?: Array<{ url?: string }>
    readonly message?: string
    readonly code?: string
  }
  readonly code?: string
  readonly message?: string
}

/** Submit the async image-synthesis task and poll until it finishes. */
export async function generateViaDashScope(input: DashScopeGenerateInput): Promise<DashScopeTaskResult> {
  const { provider, signal } = input
  const base = normalizeHost(provider.apiBase)
  const count = typeof input.n === 'number' && Number.isInteger(input.n) && input.n >= 1
    ? Math.min(input.n, 4)
    : 1
  const parameters: Record<string, unknown> = { n: count }
  const size = input.size ?? provider.size
  if (size !== undefined && size.trim().length > 0) {
    parameters.size = normalizeSize(size.trim())
  }
  const inputBody: Record<string, unknown> = { prompt: input.prompt }
  if (input.imageUrl !== undefined && input.imageUrl.length > 0) {
    inputBody.base_image_url = input.imageUrl
  }

  const submitResponse = await fetch(`${base}/api/v1/services/aigc/text2image/image-synthesis`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${provider.apiKey}`,
      'X-DashScope-Async': 'enable',
    },
    body: JSON.stringify({ model: provider.model, input: inputBody, parameters }),
    signal,
  })
  if (!submitResponse.ok) {
    throw await dashScopeError('image-synthesis 提交', submitResponse)
  }
  const submitted = await submitResponse.json() as TaskResponse
  const taskId = submitted.output?.task_id
  if (typeof taskId !== 'string' || taskId.length === 0) {
    throw new Error(`multimodal: DashScope 未返回 task_id（${JSON.stringify(submitted).slice(0, 200)}）`)
  }

  const interval = input.pollIntervalMs ?? 2000
  const deadline = Date.now() + 180_000 // hard cap: 3 minutes
  for (;;) {
    if (signal?.aborted === true) throw new Error('multimodal: DashScope 任务等待被取消')
    if (Date.now() > deadline) {
      throw new Error(`multimodal: DashScope 任务超时（task_id=${taskId}），请稍后在控制台查看或重试`)
    }
    await sleep(interval)
    const pollResponse = await fetch(`${base}/api/v1/tasks/${taskId}`, {
      headers: { 'Authorization': `Bearer ${provider.apiKey}` },
      signal,
    })
    if (!pollResponse.ok) {
      throw await dashScopeError(`任务轮询 ${taskId}`, pollResponse)
    }
    const task = await pollResponse.json() as TaskResponse
    const status = task.output?.task_status
    if (status === 'SUCCEEDED') {
      const urls = (task.output?.results ?? [])
        .map(item => item?.url)
        .filter((url): url is string => typeof url === 'string' && url.length > 0)
      if (urls.length === 0) {
        throw new Error('multimodal: DashScope 任务成功但未返回结果 URL')
      }
      return { urls, taskId }
    }
    if (status === 'FAILED' || status === 'CANCELED') {
      const detail = task.output?.message ?? task.output?.code ?? '未知原因'
      throw new Error(`multimodal: DashScope 任务失败（task_id=${taskId}）: ${detail}`)
    }
    if (status !== 'PENDING' && status !== 'RUNNING') {
      throw new Error(`multimodal: DashScope 任务状态异常（task_id=${taskId}, status=${String(status)}）`)
    }
  }
}

/** Keep only the origin so `joinBase`-style concatenation cannot double up. */
function normalizeHost(apiBase: string): string {
  const trimmed = apiBase.trim().replace(/[\\/]+$/u, '')
  return trimmed.length > 0 ? trimmed : DASHSCOPE_HOST
}

/** `1024x1024` → `1024*1024` (DashScope native expects an asterisk). */
function normalizeSize(size: string): string {
  if (size.includes('*')) return size
  return size.toLowerCase().replace(/x/gu, '*')
}

async function dashScopeError(context: string, response: Response): Promise<Error> {
  let detail = ''
  try {
    const data = await response.json() as { message?: unknown; code?: unknown }
    if (typeof data.message === 'string') detail = data.message
    else if (typeof data.code === 'string') detail = data.code
  } catch {
    // keep empty
  }
  let base = `multimodal: DashScope ${context} 失败（HTTP ${response.status}）`
  if (/url error|请检查url|check url/iu.test(detail)) {
    base += '。图生图输入图需要公网可访问的 http(s) 图片 URL（data URI 与本地路径不被 DashScope 接受），'
      + '请先把图片上传到公网（如阿里云 OSS、任意图床）再传入 URL。'
  }
  return new Error(detail.length > 0 ? `${base}: ${detail}` : base)
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}
