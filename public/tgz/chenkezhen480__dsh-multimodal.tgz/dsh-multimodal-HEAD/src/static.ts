/**
 * Built-in static file server for generated images.
 *
 * The DSH Web GUI renders absolute http(s) markdown image URLs
 * (`![](http://...)`) but not local disk paths, and the harness webserver
 * serves no files. This server exposes the generated-images directory on
 * 127.0.0.1 so `image_generate` results can be shown inline in the chat.
 *
 * @module dsh-plugin-multimodal/static
 */

import { createServer, type Server } from 'node:http'
import { readFile } from 'node:fs/promises'
import { basename, extname, join, normalize, resolve, sep } from 'node:path'

const CONTENT_TYPES: Readonly<Record<string, string>> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.bmp': 'image/bmp',
  '.svg': 'image/svg+xml',
}

export interface StaticServer {
  /** Base URL such as `http://127.0.0.1:3081`. */
  readonly baseUrl: string
  /** Absolute root directory served. */
  readonly root: string
  /** True when the port could not be bound (e.g. already in use). */
  failed(): boolean
  /** Resolves once the server is listening (rejects on bind failure). */
  readonly ready: Promise<void>
  close(): Promise<void>
  /** Public URL for a file inside the root; undefined when outside or failed. */
  urlFor(filePath: string): string | undefined
}

/**
 * Start serving `rootDir` on 127.0.0.1:port. Port 0 picks a free port.
 * Bind failures do not throw — they surface through `failed()` / a rejected
 * `ready`, so the plugin can keep working without the server.
 */
export function startStaticServer(rootDir: string, port: number): StaticServer {
  const root = resolve(rootDir)
  // Port 0 asks the OS for a free port; the real one is only known after
  // listening, so `baseUrl` is a getter over the live value.
  let baseUrl = `http://127.0.0.1:${port}`
  let bindError: Error | undefined
  let closed = false

  const server: Server = createServer(async (req, res) => {
    try {
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('method not allowed')
        return
      }
      let urlPath: string
      try {
        urlPath = decodeURIComponent(new URL(req.url ?? '/', 'http://localhost').pathname)
      } catch {
        res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('bad request')
        return
      }
      const file = normalize(join(root, urlPath))
      // Path-traversal guard: the resolved file must stay inside the root.
      if (file !== root && !file.startsWith(root + sep)) {
        res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('forbidden')
        return
      }
      let data: Buffer
      try {
        data = await readFile(file)
      } catch {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('not found')
        return
      }
      res.writeHead(200, {
        'Content-Type': CONTENT_TYPES[extname(file).toLowerCase()] ?? 'application/octet-stream',
        'Cache-Control': 'no-store',
      })
      res.end(req.method === 'HEAD' ? undefined : data)
    } catch {
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' })
      res.end('internal error')
    }
  })
  server.once('error', error => {
    bindError = error
  })
  server.listen(port, '127.0.0.1')

  const ready = new Promise<void>((resolveReady, rejectReady) => {
    server.once('listening', () => {
      const address = server.address()
      if (address !== null && typeof address === 'object' && address.port > 0) {
        baseUrl = `http://127.0.0.1:${address.port}`
      }
      resolveReady()
    })
    server.once('error', () => rejectReady(bindError ?? new Error(`static server bind failed on port ${port}`)))
  })

  return {
    get baseUrl() {
      return baseUrl
    },
    root,
    failed: () => bindError !== undefined || closed,
    ready,
    close: () => new Promise(resolveClose => {
      if (closed) {
        resolveClose()
        return
      }
      closed = true
      server.close(() => resolveClose())
    }),
    urlFor: (filePath) => {
      if (bindError !== undefined || closed) return undefined
      const file = resolve(filePath)
      if (file !== root && !file.startsWith(root + sep)) return undefined
      return `${baseUrl}/${encodeURIComponent(basename(file))}`
    },
  }
}
