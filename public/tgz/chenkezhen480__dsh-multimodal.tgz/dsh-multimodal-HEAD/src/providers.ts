/**
 * Provider resolution helpers: pick the provider a tool call should use,
 * with clear errors when the deployment is not configured.
 *
 * @module dsh-plugin-multimodal/providers
 */

import {
  missingApiBaseError,
  missingApiKeyError,
  missingModelError,
  noProviderError,
  type ProviderConfig,
  type ProviderKind,
  type ResolvedConfig,
} from './config.ts'

export interface PickOptions {
  /** Provider id requested by the model; undefined picks the first of `kind`. */
  readonly id?: string | undefined
  /** Only providers of this kind are candidates. */
  readonly kind: ProviderKind
  /** True when the call may proceed without a configured model (list tools). */
  readonly allowUnconfigured?: boolean
}

/**
 * Select the provider for a tool call. Throws actionable errors when the
 * deployment has no provider of the kind, the requested id is unknown, or
 * the chosen provider is missing its model/apiKey (the "tool without a
 * model fails normally" contract).
 */
export function pickProvider(
  resolved: ResolvedConfig,
  options: PickOptions,
): ProviderConfig {
  const candidates = resolved.providers.filter(provider => provider.kind === options.kind)
  if (candidates.length === 0) {
    throw noProviderError(options.kind)
  }
  const id = options.id ?? ''
  const chosen = id.length > 0
    ? resolved.providers.find(provider => provider.id === id)
    : candidates[0]
  if (chosen === undefined) {
    const ids = resolved.providers.map(provider => `"${provider.id}"`).join(', ')
    throw new Error(
      `multimodal: provider "${id}" 不存在。已配置的 provider: ${ids}（可用 vision_providers 工具查看）。`,
    )
  }
  if (id.length > 0 && chosen.kind !== options.kind) {
    throw new Error(
      `multimodal: provider "${id}" 的类型是 ${chosen.kind}，而本次调用需要 ${options.kind} 类型。`
      + '请换用对应类型的 provider id。',
    )
  }
  if (options.allowUnconfigured) return chosen
  if (chosen.apiBase.trim().length === 0) throw missingApiBaseError(chosen.id)
  if (chosen.model.trim().length === 0) throw missingModelError(chosen.id)
  if (chosen.apiKey.trim().length === 0) throw missingApiKeyError(chosen.id)
  return chosen
}

/** Human-readable listing of the configured providers (for vision_providers). */
export function describeProviders(resolved: ResolvedConfig): string {
  if (resolved.providers.length === 0) {
    return '未配置任何外部 API 模型。请在插件包内 cordis.patch.yml 的 providers 中添加条目后重启 dsh web。'
  }
  const lines = resolved.providers.map(provider => {
    const model = provider.model.trim().length > 0 ? provider.model : '<未配置 model>'
    const i2i = provider.i2iModel !== undefined && provider.i2iModel.trim().length > 0
      ? ` i2i=${provider.i2iModel}`
      : ''
    const key = provider.apiKey.trim().length > 0 ? '已填 apiKey' : '未填 apiKey'
    const extras: string[] = []
    if (provider.size !== undefined) extras.push(`size=${provider.size}`)
    if (provider.maxTokens !== undefined) extras.push(`maxTokens=${provider.maxTokens}`)
    if (provider.temperature !== undefined) extras.push(`temperature=${provider.temperature}`)
    const tail = extras.length > 0 ? ` (${extras.join(', ')})` : ''
    const endpoint = provider.apiBase.trim().length > 0 ? provider.apiBase : '<未配置 apiBase>'
    return `- ${provider.id} [${provider.kind}] ${model}${i2i} @ ${endpoint}（${key}）${tail}`
  })
  return `已配置 ${resolved.providers.length} 个外部 API 模型：\n${lines.join('\n')}`
}
