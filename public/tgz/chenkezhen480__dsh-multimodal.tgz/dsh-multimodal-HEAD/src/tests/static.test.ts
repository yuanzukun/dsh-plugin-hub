/**
 * Built-in static server tests: serves generated images over http(s),
 * guards path traversal, 404s missing files, degrades on port conflicts.
 *
 * @module dsh-plugin-multimodal/tests/static
 */

import assert from 'node:assert/strict'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { request } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test, { afterEach } from 'node:test'
import { startStaticServer, type StaticServer } from '../static.ts'

const servers: StaticServer[] = []

afterEach(async () => {
  for (const server of servers.splice(0)) await server.close()
})

/** Raw HTTP GET with an un-normalized request path (fetch would normalize it). */
function rawGet(baseUrl: string, rawPath: string): Promise<{ status: number }> {
  const url = new URL(baseUrl)
  return new Promise((resolve, reject) => {
    const req = request({
      host: url.hostname,
      port: Number(url.port),
      path: rawPath,
      method: 'GET',
    }, res => {
      res.resume()
      resolve({ status: res.statusCode ?? 0 })
    })
    req.on('error', reject)
    req.end()
  })
}

async function serve(port = 0): Promise<{ server: StaticServer; dir: string }> {
  const dir = await mkdtemp(join(tmpdir(), 'mm-static-'))
  const server = startStaticServer(dir, port)
  servers.push(server)
  await server.ready
  return { server, dir }
}

test('serves a file with the right content type', async () => {
  const { server, dir } = await serve()
  await writeFile(join(dir, 'a.png'), Buffer.from('PNGDATA'))
  const response = await fetch(`${server.baseUrl}/a.png`)
  assert.equal(response.status, 200)
  assert.equal(response.headers.get('content-type'), 'image/png')
  assert.equal(await response.text(), 'PNGDATA')
})

test('404 for missing files and directories', async () => {
  const { server } = await serve()
  const missing = await fetch(`${server.baseUrl}/nope.png`)
  assert.equal(missing.status, 404)
  const root = await fetch(`${server.baseUrl}/`)
  assert.equal(root.status, 404)
})

test('path traversal cannot escape the root', async () => {
  const { server, dir } = await serve()
  await writeFile(join(dir, 'secret.txt'), 's3cret')
  const outside = join(dir, '..', 'mm-static-outside.txt')
  await writeFile(outside, 'outside')
  try {
    // URL-encoded traversal folds into a root-relative path during URL
    // parsing; the only reachable file is the root-internal one.
    const folded = await rawGet(server.baseUrl, '/%2e%2e/secret.txt')
    assert.equal(folded.status, 200)
    // Files OUTSIDE the root stay unreachable under every traversal shape:
    // raw .., nested .., and encoded .. all resolve to root-relative paths
    // where the outside file does not exist (404), never served.
    assert.equal((await rawGet(server.baseUrl, '/../mm-static-outside.txt')).status, 404)
    assert.equal((await rawGet(server.baseUrl, '/a/../../mm-static-outside.txt')).status, 404)
    assert.equal((await rawGet(server.baseUrl, '/%2e%2e/mm-static-outside.txt')).status, 404)
  } finally {
    await rm(outside, { force: true })
  }
})

test('405 for non-GET methods', async () => {
  const { server } = await serve()
  const response = await fetch(`${server.baseUrl}/a.png`, { method: 'POST' })
  assert.equal(response.status, 405)
})

test('urlFor maps files inside the root and rejects outside', async () => {
  const { server, dir } = await serve()
  assert.equal(server.urlFor(join(dir, 'x.png')), `${server.baseUrl}/x.png`)
  assert.equal(server.urlFor(join(dir, '..', 'elsewhere.png')), undefined)
})

test('port conflicts degrade gracefully (failed() and rejected ready)', async () => {
  const { server: first } = await serve(0)
  const port = Number(new URL(first.baseUrl).port)
  const second = startStaticServer(first.root, port)
  servers.push(second)
  await assert.rejects(second.ready)
  assert.equal(second.failed(), true)
  assert.equal(second.urlFor(join(first.root, 'x.png')), undefined)
})

test('port 0 picks a free port', async () => {
  const { server } = await serve(0)
  assert.ok(server.baseUrl.match(/^http:\/\/127\.0\.0\.1:\d+$/u))
  await rm(server.root, { recursive: true, force: true })
})
