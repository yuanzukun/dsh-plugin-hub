/**
 * Cordis integration test: mounts the real plugin against the real tools
 * service with a stubbed OpenAI-compatible endpoint (no network). Covers
 * tool registration, the "not configured → clear error" contract, image
 * recognition via chat/completions, and image generation via
 * images/generations (base64 and URL results).
 *
 * @module dsh-plugin-multimodal/tests/plugin
 */

import assert from 'node:assert/strict'
import { existsSync, readFileSync } from 'node:fs'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test, { afterEach } from 'node:test'
import { Context } from '@deepseek-ai/cordis'
import InvariantRegistry from '@deepseek-ai/dsh-invariants'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime, { type ToolRunContext } from '@deepseek-ai/dsh-tools'
import { Multimodal, type ToolDefinitionLike } from '../plugin-under-test.ts'

const activeContexts: Context[] = []

afterEach(async () => {
  for (const ctx of activeContexts.splice(0)) await ctx.fiber.dispose()
})

interface StubCall {
  readonly url: string
  readonly body: Record<string, unknown>
}

interface StubState {
  readonly calls: StubCall[]
  /** Handler per URL suffix; returns a fake Response. */
  on(url: string, respond: (body: Record<string, unknown>) => unknown): void
}

function stubFetch(): StubState {
  const state: StubState = {
    calls: [],
    on: () => { /* populated below */ },
  }
  const handlers = new Map<string, (body: Record<string, unknown>) => unknown>()
  state.on = (url, respond) => { handlers.set(url, respond) }
  const original = globalThis.fetch
  globalThis.fetch = (async (input: string | URL | Request, init?: RequestInit) => {
    const url = String(input)
    const body = JSON.parse(String(init?.body ?? '{}')) as Record<string, unknown>
    state.calls.push({ url, body })
    for (const [suffix, respond] of handlers) {
      if (url.endsWith(suffix)) {
        return {
          ok: true,
          status: 200,
          json: async () => respond(body),
        } as unknown as Response
      }
    }
    return {
      ok: false,
      status: 404,
      json: async () => ({ error: { message: `unexpected url ${url}` } }),
    } as unknown as Response
  }) as typeof fetch
  return state
}

function restoreFetch(original: typeof fetch): void {
  globalThis.fetch = original
}

interface Mounted {
  readonly ctx: Context
  readonly dir: string
  tool(name: string): ToolDefinitionLike
}

async function mount(config: Record<string, unknown>): Promise<Mounted> {
  const ctx = new Context()
  activeContexts.push(ctx)
  // Mirror the real profile composition: invariants → systemPrompt → tools
  // (class plugins load through an async fiber).
  await ctx.plugin(InvariantRegistry)
  await ctx.plugin(SystemPrompt, {})
  await ctx.plugin(ToolRuntime, {})
  const dir = await mkdtemp(join(tmpdir(), 'mm-plugin-'))
  // staticPort 0 disables the built-in server so tests stay hermetic.
  await ctx.plugin(Multimodal, { ...config, staticPort: 0 })
  assert.ok(ctx.tools !== undefined, 'tools service missing')
  return { ctx, dir, tool: name => toolByName(ctx, name) }
}

function toolByName(ctx: Context, name: string): ToolDefinitionLike {
  const definition = (ctx.tools as ToolRuntime).get(name)
  assert.ok(definition !== undefined, `tool ${name} not registered`)
  return definition as unknown as ToolDefinitionLike
}

function runExec(): ToolRunContext {
  return { signal: new AbortController().signal } as ToolRunContext
}

/** A tiny valid PNG (1x1) as base64. */
const TINY_PNG_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='

const VISION_PROVIDER = {
  id: 'v1',
  kind: 'vision',
  apiBase: 'https://api.example.com/v1',
  apiKey: 'sk-test',
  model: 'vision-model',
}
const IMAGE_PROVIDER = {
  id: 'g1',
  kind: 'image',
  apiBase: 'https://api.example.com/v1',
  apiKey: 'sk-test',
  model: 'image-model',
}

test('plugin registers three tools', async () => {
  const mounted = await mount({ providers: [VISION_PROVIDER, IMAGE_PROVIDER] })
  for (const name of ['image_recognize', 'image_generate', 'vision_providers']) {
    assert.ok(mounted.tool(name) !== undefined, `${name} missing`)
  }
})

test('vision_providers lists configured providers', async () => {
  const mounted = await mount({ providers: [VISION_PROVIDER, IMAGE_PROVIDER] })
  const output = String(await mounted.tool('vision_providers').execute({}, runExec()))
  assert.match(output, /v1 \[vision\]/)
  assert.match(output, /g1 \[image\]/)
  assert.match(output, /vision-model/)
})

test('vision_providers explains when nothing is configured', async () => {
  const mounted = await mount({})
  const output = String(await mounted.tool('vision_providers').execute({}, runExec()))
  assert.match(output, /未配置任何外部 API 模型/)
})

test('image_recognize fails with a clear error when no vision provider is configured', async () => {
  const mounted = await mount({})
  await assert.rejects(
    mounted.tool('image_recognize').execute({ image: 'x.png' }, runExec()),
    /未配置任何 vision 类型的外部模型/,
  )
})

test('image_recognize fails with a clear error when the model is empty', async () => {
  const mounted = await mount({ providers: [{ ...VISION_PROVIDER, model: '' }] })
  await assert.rejects(
    mounted.tool('image_recognize').execute({ image: 'x.png' }, runExec()),
    /未配置 model/,
  )
})

test('image_recognize fails with a clear error when apiBase is empty', async () => {
  const mounted = await mount({ providers: [{ ...VISION_PROVIDER, apiBase: '' }] })
  await assert.rejects(
    mounted.tool('image_recognize').execute({ image: 'x.png' }, runExec()),
    /未配置 apiBase/,
  )
})

test('image_recognize fails with a clear error when the apiKey is empty', async () => {
  const mounted = await mount({ providers: [{ ...VISION_PROVIDER, apiKey: '' }] })
  await assert.rejects(
    mounted.tool('image_recognize').execute({ image: 'x.png' }, runExec()),
    /未配置 apiKey/,
  )
})

test('image_recognize fails for an unknown provider id', async () => {
  const mounted = await mount({ providers: [VISION_PROVIDER, IMAGE_PROVIDER] })
  await assert.rejects(
    mounted.tool('image_recognize').execute({ image: 'x.png', provider: 'nope' }, runExec()),
    /provider "nope" 不存在/,
  )
})

test('image_recognize calls chat/completions with a data URI and returns the answer', async () => {
  const original = globalThis.fetch
  const state = stubFetch()
  state.on('chat/completions', body => {
    assert.equal(body.model, 'vision-model')
    const content = (body.messages as Array<{ content: unknown }>)[0]?.content as Array<{ type: string; image_url?: { url: string } }>
    assert.equal(content[0]?.type, 'text')
    assert.equal(content[1]?.type, 'image_url')
    assert.ok(String(content[1]?.image_url?.url).startsWith('data:image/png;base64,'))
    return { choices: [{ message: { content: '这是一只猫。' } }] }
  })
  try {
    const mounted = await mount({ providers: [VISION_PROVIDER, IMAGE_PROVIDER] })
    const imagePath = join(mounted.dir, 'cat.png')
    const { writeFileSync } = await import('node:fs')
    writeFileSync(imagePath, Buffer.from(TINY_PNG_B64, 'base64'))
    const output = String(await mounted.tool('image_recognize').execute({
      image: imagePath,
      prompt: '这是什么？',
    }, runExec()))
    assert.equal(output, '这是一只猫。')
    assert.equal(state.calls.length, 1)
    assert.ok(state.calls[0]?.url.endsWith('/chat/completions'))
    const sent = state.calls[0]?.body as { max_tokens?: number; temperature?: number }
    assert.equal(sent.max_tokens, undefined)
  } finally {
    restoreFetch(original)
  }
})

test('image_generate fails with a clear error when no image provider is configured', async () => {
  const mounted = await mount({})
  await assert.rejects(
    mounted.tool('image_generate').execute({ prompt: 'a cat' }, runExec()),
    /未配置任何 image 类型的外部模型/,
  )
})

test('image_generate saves a base64 result to the output path', async () => {
  const original = globalThis.fetch
  const state = stubFetch()
  state.on('images/generations', body => {
    assert.equal(body.model, 'image-model')
    assert.equal(body.response_format, 'b64_json')
    assert.equal(body.watermark, false, 'watermark defaults to false')
    return { data: [{ b64_json: TINY_PNG_B64 }] }
  })
  try {
    const mounted = await mount({ providers: [VISION_PROVIDER, IMAGE_PROVIDER] })
    const outputPath = join(mounted.dir, 'out.png')
    const output = String(await mounted.tool('image_generate').execute({
      prompt: 'a cat',
      output_path: outputPath,
    }, runExec()))
    assert.match(output, /已生成 1 张图片/)
    assert.match(output, new RegExp(outputPath.replace(/[\\]/g, '\\\\')))
    assert.ok(existsSync(outputPath))
    assert.ok(readFileSync(outputPath).byteLength > 0)
  } finally {
    restoreFetch(original)
  }
})

test('image_generate retries without response_format and downloads a URL result', async () => {
  const original = globalThis.fetch
  const state = stubFetch()
  state.on('images/generations', body => {
    if (body.response_format !== undefined) {
      throw new Error('response_format not supported') // handled below by the plugin
    }
    return { data: [{ url: 'https://cdn.example.com/img.png' }] }
  })
  try {
    // URL download goes through fetch too; serve bytes for it.
    const realFetch = globalThis.fetch
    globalThis.fetch = (async (input: string | URL | Request, init?: RequestInit) => {
      const url = String(input)
      if (url.startsWith('https://cdn.example.com/')) {
        return {
          ok: true,
          status: 200,
          headers: new Headers({ 'content-type': 'image/png' }),
          arrayBuffer: async () => Buffer.from(TINY_PNG_B64, 'base64').buffer,
        } as unknown as Response
      }
      return realFetch(input, init)
    }) as typeof fetch
    const mounted = await mount({ providers: [VISION_PROVIDER, IMAGE_PROVIDER] })
    const outputPath = join(mounted.dir, 'downloaded.png')
    const output = String(await mounted.tool('image_generate').execute({
      prompt: 'a cat',
      output_path: outputPath,
    }, runExec()))
    assert.match(output, /已生成 1 张图片/)
    assert.ok(existsSync(outputPath))
  } finally {
    restoreFetch(original)
  }
})

test('image_generate rejects an empty prompt', async () => {  const mounted = await mount({ providers: [VISION_PROVIDER, IMAGE_PROVIDER] })
  await assert.rejects(
    mounted.tool('image_generate').execute({ prompt: '   ' }, runExec()),
    /prompt 不能为空/,
  )
})

test('image_generate retries without the watermark parameter when the endpoint rejects it', async () => {
  const original = globalThis.fetch
  const state = stubFetch()
  let calls = 0
  state.on('images/generations', body => {
    calls += 1
    if (calls === 1) {
      assert.equal(body.watermark, false)
      throw new Error('unsupported parameter: watermark')
    }
    assert.equal(body.watermark, undefined, 'watermark dropped on retry')
    return { data: [{ b64_json: TINY_PNG_B64 }] }
  })
  try {
    const mounted = await mount({ providers: [VISION_PROVIDER, IMAGE_PROVIDER] })
    const outputPath = join(mounted.dir, 'wm.png')
    await mounted.tool('image_generate').execute({
      prompt: 'a cat',
      output_path: outputPath,
    }, runExec())
    assert.ok(calls >= 2, 'retried after watermark rejection')
    assert.ok(existsSync(outputPath))
  } finally {
    restoreFetch(original)
  }
})

test('image_generate honors watermark:true from the provider config', async () => {
  const original = globalThis.fetch
  const state = stubFetch()
  state.on('images/generations', body => {
    assert.equal(body.watermark, true)
    return { data: [{ b64_json: TINY_PNG_B64 }] }
  })
  try {
    const mounted = await mount({ providers: [VISION_PROVIDER, { ...IMAGE_PROVIDER, watermark: true }] })
    const outputPath = join(mounted.dir, 'wm-on.png')
    await mounted.tool('image_generate').execute({
      prompt: 'a cat',
      output_path: outputPath,
    }, runExec())
    assert.ok(existsSync(outputPath))
  } finally {
    restoreFetch(original)
  }
})

test('image_generate sends the image field as a data URI for image-to-image', async () => {
  const original = globalThis.fetch
  const state = stubFetch()
  state.on('images/generations', body => {
    assert.equal(body.model, 'image-model')
    assert.equal(body.response_format, 'b64_json')
    assert.ok(String(body.image).startsWith('data:image/png;base64,'))
    return { data: [{ b64_json: TINY_PNG_B64 }] }
  })
  try {
    const mounted = await mount({ providers: [VISION_PROVIDER, IMAGE_PROVIDER] })
    const sourcePath = join(mounted.dir, 'source.png')
    const { writeFileSync } = await import('node:fs')
    writeFileSync(sourcePath, Buffer.from(TINY_PNG_B64, 'base64'))
    const outputPath = join(mounted.dir, 'edited.png')
    const output = String(await mounted.tool('image_generate').execute({
      prompt: 'turn it into a watercolor painting',
      image: sourcePath,
      output_path: outputPath,
    }, runExec()))
    assert.match(output, /已生成 1 张图片/)
    assert.ok(existsSync(outputPath))
    const sent = state.calls[0]?.body as { image?: string }
    assert.ok(sent.image !== undefined, 'image field missing from request body')
  } finally {
    restoreFetch(original)
  }
})

test('image_generate auto-switches to i2iModel when an image is passed', async () => {
  const original = globalThis.fetch
  const state = stubFetch()
  const models: string[] = []
  state.on('images/generations', body => {
    models.push(String(body.model))
    return { data: [{ b64_json: TINY_PNG_B64 }] }
  })
  try {
    const mounted = await mount({ providers: [{ ...IMAGE_PROVIDER, i2iModel: 'i2i-model' }] })
    const dir = mounted.dir
    // no image → text-to-image model
    await mounted.tool('image_generate').execute({
      prompt: 'a cat',
      output_path: join(dir, 't2i.png'),
    }, runExec())
    // with image → image-to-image model
    const sourcePath = join(dir, 'src.png')
    const { writeFileSync } = await import('node:fs')
    writeFileSync(sourcePath, Buffer.from(TINY_PNG_B64, 'base64'))
    await mounted.tool('image_generate').execute({
      prompt: 'edit it',
      image: sourcePath,
      output_path: join(dir, 'i2i.png'),
    }, runExec())
    assert.deepEqual(models, ['image-model', 'i2i-model'])
  } finally {
    restoreFetch(original)
  }
})

test('image_generate uses the DashScope native async flow when protocol is dashscope-native', async () => {
  const original = globalThis.fetch
  const state = stubFetch()
  state.on('image-synthesis', body => {
    const input = body.input as { prompt?: string; base_image_url?: string }
    // image passed → the provider's i2iModel wins on the native protocol too
    assert.equal(body.model, 'wanx2.1-i2i-turbo')
    assert.match(String(input.prompt), /purple/)
    assert.ok(String(input.base_image_url).startsWith('data:image/png;base64,'), 'i2i input image missing')
    return { output: { task_id: 'task-123', task_status: 'PENDING' } }
  })
  let polls = 0
  state.on('api/v1/tasks/task-123', () => {
    polls += 1
    if (polls < 2) return { output: { task_status: 'RUNNING' } }
    return { output: { task_status: 'SUCCEEDED', results: [{ url: 'https://cdn.example.com/result.png' }] } }
  })
  try {
    const realFetch = globalThis.fetch
    globalThis.fetch = (async (input: string | URL | Request, init?: RequestInit) => {
      const url = String(input)
      if (url.startsWith('https://cdn.example.com/')) {
        return {
          ok: true,
          status: 200,
          headers: new Headers({ 'content-type': 'image/png' }),
          arrayBuffer: async () => Buffer.from(TINY_PNG_B64, 'base64').buffer,
        } as unknown as Response
      }
      return realFetch(input, init)
    }) as typeof fetch
    const DASHSCOPE_PROVIDER = {
      id: 'wanx',
      kind: 'image',
      apiBase: 'https://dashscope.aliyuncs.com',
      apiKey: 'sk-test',
      model: 'wanx-t2i',
      i2iModel: 'wanx2.1-i2i-turbo',
      protocol: 'dashscope-native',
    }
    const mounted = await mount({ providers: [VISION_PROVIDER, DASHSCOPE_PROVIDER] })
    const sourcePath = join(mounted.dir, 'source.png')
    const { writeFileSync } = await import('node:fs')
    writeFileSync(sourcePath, Buffer.from(TINY_PNG_B64, 'base64'))
    const outputPath = join(mounted.dir, 'result.png')
    const output = String(await mounted.tool('image_generate').execute({
      prompt: 'turn it purple',
      image: sourcePath,
      provider: 'wanx',
      output_path: outputPath,
    }, runExec()))
    assert.match(output, /已生成 1 张图片/)
    assert.ok(polls >= 2, 'task polling happened')
    assert.ok(existsSync(outputPath))
  } finally {
    restoreFetch(original)
  }
})

test('image_generate fixes the extension from the b64 magic bytes (JPEG payload)', async () => {
  const original = globalThis.fetch
  const state = stubFetch()
  const jpegB64 = Buffer.from([0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46]).toString('base64')
  state.on('images/generations', () => ({ data: [{ b64_json: jpegB64 }] }))
  try {
    const mounted = await mount({ providers: [IMAGE_PROVIDER] })
    const outputPath = join(mounted.dir, 'out.png')
    const output = String(await mounted.tool('image_generate').execute({
      prompt: 'a cat',
      output_path: outputPath,
    }, runExec()))
    assert.ok(existsSync(join(mounted.dir, 'out.jpg')), 'saved with the real .jpg extension')
    assert.ok(!existsSync(outputPath), 'not saved as .png')
    assert.match(output, /out\.jpg/)
  } finally {
    restoreFetch(original)
  }
})

test('formatGenerateResult appends markdown image URLs when the server maps them', async () => {
  const { formatGenerateResult } = await import('../tools.ts')
  const plain = formatGenerateResult(['C:\\out\\a.png'], undefined)
  assert.match(plain, /已生成 1 张图片/)
  assert.doesNotMatch(plain, /!\[/)
  const withUrl = formatGenerateResult(
    ['C:\\generated\\a.png'],
    path => path.includes('a.png') ? 'http://127.0.0.1:3081/a.png' : undefined,
  )
  assert.match(withUrl, /!\[a\.png\]\(http:\/\/127\.0\.0\.1:3081\/a\.png\)/)
  // Files outside the server root get no URL.
  const partial = formatGenerateResult(
    ['C:\\generated\\a.png', 'D:\\elsewhere\\b.png'],
    path => path.startsWith('C:\\generated\\') ? `http://127.0.0.1:3081/${path.split('\\').pop()}` : undefined,
  )
  assert.match(partial, /!\[a\.png\]/)
  assert.doesNotMatch(partial, /b\.png\]\(/)
})
