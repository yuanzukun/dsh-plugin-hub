/**
 * Config resolution tests: provider validation, duplicate ids, empty apiBase,
 * outputDir normalization, and the error helpers behind the "tool without a
 * model fails normally" contract.
 *
 * @module dsh-plugin-multimodal/tests/config
 */

import assert from 'node:assert/strict'
import test from 'node:test'
import {
  Config,
  missingApiBaseError,
  missingApiKeyError,
  missingModelError,
  noProviderError,
  resolveConfig,
  type Config as ConfigValue,
} from '../config.ts'

test('empty providers resolve fine (plugin still loads)', () => {
  const resolved = resolveConfig({})
  assert.equal(resolved.providers.length, 0)
  assert.equal(resolved.outputDir, undefined)
})

test('a full provider list resolves as-is', () => {
  const resolved = resolveConfig({
    providers: [
      { id: 'v1', kind: 'vision', apiBase: 'https://api.example.com/v1', apiKey: '', model: '' },
      { id: 'g1', kind: 'image', apiBase: 'https://api.example.com/v1', apiKey: 'sk-1', model: 'gpt-image-1' },
    ],
    outputDir: '  ./pics  ',
  })
  assert.equal(resolved.providers.length, 2)
  assert.equal(resolved.outputDir, './pics')
})

test('duplicate provider ids are rejected', () => {
  assert.throws(
    () => resolveConfig({
      providers: [
        { id: 'v1', kind: 'vision', apiBase: 'https://x/v1', apiKey: '', model: '' },
        { id: 'v1', kind: 'image', apiBase: 'https://x/v1', apiKey: '', model: '' },
      ],
    }),
    /duplicate provider id "v1"/,
  )
})

test('empty provider id is rejected', () => {
  assert.throws(
    () => resolveConfig({ providers: [{ id: '', kind: 'vision', apiBase: 'https://x/v1', apiKey: '', model: '' }] }),
    /provider id must be non-empty/,
  )
})

test('nullable provider connection fields become empty strings during schema validation', () => {
  const config = Config({
    providers: [{ id: 'v1', kind: 'vision', apiBase: null, apiKey: null, model: null }],
  } as unknown as ConfigValue)
  assert.equal(config.providers?.[0]?.apiBase, '')
  assert.equal(config.providers?.[0]?.apiKey, '')
  assert.equal(config.providers?.[0]?.model, '')
})

test('empty apiBase/model/apiKey are NOT rejected at config time (error surfaces at call time)', () => {
  const resolved = resolveConfig({
    providers: [{ id: 'v1', kind: 'vision', apiBase: '', apiKey: '', model: '' }],
  })
  assert.equal(resolved.providers[0]?.apiBase, '')
  assert.equal(resolved.providers[0]?.model, '')
  assert.match(missingApiBaseError('v1').message, /未配置 apiBase/)
  assert.match(missingModelError('v1').message, /未配置 model/)
  assert.match(missingApiKeyError('v1').message, /未配置 apiKey/)
  assert.match(noProviderError('vision').message, /未配置任何 vision 类型的外部模型/)
  assert.match(noProviderError('image').message, /未配置任何 image 类型的外部模型/)
})
