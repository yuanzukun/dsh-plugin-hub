/**
 * Model-facing tools for the multimodal (image) plugin.
 *
 * Registered through `ctx.tools.register(defineTool(...))`. Each tool takes
 * the caller session's cwd as its workspace: relative image paths and
 * default output locations resolve against it.
 *
 * @module dsh-plugin-multimodal/tools
 */

import type { Context } from '@deepseek-ai/cordis'
import { defineTool, type ToolRunContext } from '@deepseek-ai/dsh-tools'
import { basename } from 'node:path'
import type { ResolvedConfig } from './config.ts'
import { generateImages } from './imagegen.ts'
import { describeProviders, pickProvider } from './providers.ts'
import type { StaticServer } from './static.ts'
import { resolveOutputPath, uniqueImageName } from './util.ts'
import { recognizeImage } from './vision.ts'

const TEXT_OUTPUT = {
  schema: { type: 'string' as const },
  render: (_args: unknown, value: string) => [{ type: 'text' as const, text: value }],
}

const recognizeParameters = {
  image: {
    type: 'string',
    required: true,
    description: '图片：本地文件路径（相对路径基于当前工作区）、http(s) URL，或 data: URI。',
  },
  prompt: {
    type: 'string',
    description: '要模型回答的问题/指令。省略时模型会详细描述图片内容。',
  },
  provider: {
    type: 'string',
    description: '使用 providers 配置中的哪个 vision 模型（id）。省略时使用第一个 vision 类型 provider。可用 vision_providers 工具查看已配置项。',
  },
  max_tokens: { type: 'integer', description: '本次调用的最大输出 token 数（覆盖 provider 默认值）。' },
  temperature: { type: 'number', description: '本次调用的采样温度 0~2（覆盖 provider 默认值）。' },
} as const

const generateParameters = {
  prompt: {
    type: 'string',
    required: true,
    description: '生成图片的提示词（描述画面内容、风格、构图等，建议用英文以获得更稳定的效果）。图生图时描述要对原图做什么修改/变换。',
  },
  image: {
    type: 'string',
    description: '图生图（image-to-image）的源图片：本地文件路径（相对路径基于当前工作区）、http(s) URL 或 data: URI。传入后自动切换为该 provider 的图生图模型（配置的 i2iModel；未配置则用同一 model），生成结果以该图为输入（编辑/变体/风格迁移，具体能力取决于模型是否支持）。不传此参数就是文生图。',
  },
  provider: {
    type: 'string',
    description: '使用 providers 配置中的哪个 image 模型（id）。省略时使用第一个 image 类型 provider。可用 vision_providers 工具查看已配置项。',
  },
  size: {
    type: 'string',
    description: '输出尺寸，如 1024x1024、512x512、1024x768（省略时用 provider 默认值）。',
  },
  n: { type: 'integer', description: '生成数量（1~4，默认 1）。多张时文件名自动加序号。' },
  output_path: {
    type: 'string',
    description: '保存路径：目录（以 / 或 \\ 结尾）或完整文件路径。省略时保存到配置的 outputDir（默认 <当前工作区>/generated）。',
  },
} as const

export interface MultimodalToolServices {
  config: () => ResolvedConfig
  /** Built-in static server exposing generated images (undefined when disabled). */
  staticServer: () => StaticServer | undefined
}

export function registerMultimodalTools(
  ctx: Context,
  services: MultimodalToolServices,
): void {
  ctx.tools.register(defineTool({
    name: 'image_recognize',
    description: '识别/分析一张图片：用配置的外部视觉模型（OpenAI 兼容 chat/completions 多模态接口）理解图片内容并返回文字结果。可用于看图说话、OCR、识别图表/截图、审核图片等。未配置视觉模型时会直接报错。',
    parameters: recognizeParameters,
    output: TEXT_OUTPUT,
    execute: async (args, exec) => {
      const resolved = services.config()
      const provider = pickProvider(resolved, {
        kind: 'vision',
        id: typeof args.provider === 'string' ? args.provider : undefined,
      })
      const cwd = cwdOf(exec)
      const result = await recognizeImage({
        image: String(args.image),
        prompt: typeof args.prompt === 'string' ? args.prompt : undefined,
        provider,
        maxTokens: typeof args.max_tokens === 'number' ? args.max_tokens : undefined,
        temperature: typeof args.temperature === 'number' ? args.temperature : undefined,
        cwd,
        signal: exec.signal,
      })
      return result
    },
    presentCall: args => ({
      card: 'generic' as const,
      title: 'Recognize image',
      rawInput: `${args.provider !== undefined ? `[${args.provider}] ` : ''}${String(args.image)}`,
    }),
  }))

  ctx.tools.register(defineTool({
    name: 'image_generate',
    description: '根据提示词生成一张图片：调用配置的外部图像生成模型（OpenAI 兼容 images/generations 接口），把结果保存为文件并返回路径。返回的 Markdown 图片链接（http://127.0.0.1:...）可在 Web 对话中直接显示图片——最终回复时请把 ![](url) 原样放进回复正文。未配置图像生成模型时会直接报错。',
    parameters: generateParameters,
    output: TEXT_OUTPUT,
    isConcurrencySafe: () => true,
    execute: async (args, exec) => {
      const prompt = String(args.prompt).trim()
      if (prompt.length === 0) throw new Error('image_generate: prompt 不能为空')
      const resolved = services.config()
      const provider = pickProvider(resolved, {
        kind: 'image',
        id: typeof args.provider === 'string' ? args.provider : undefined,
      })
      const cwd = cwdOf(exec)
      const staticServer = services.staticServer()
      // Default output directory aligns with the static server root so the
      // generated file is always reachable at its http(s) URL; explicit
      // output_path still wins.
      const outputPath = resolveOutputPath(
        cwd,
        staticServer !== undefined ? staticServer.root : resolved.outputDir,
        typeof args.output_path === 'string' ? args.output_path : undefined,
        uniqueImageName(),
      )
      const paths = await generateImages({
        prompt,
        provider,
        image: typeof args.image === 'string' ? args.image : undefined,
        cwd,
        size: typeof args.size === 'string' ? args.size : undefined,
        n: typeof args.n === 'number' ? args.n : undefined,
        outputPath,
        signal: exec.signal,
      })
      return formatGenerateResult(paths, staticServer?.urlFor)
    },
    presentCall: args => ({
      card: 'generic' as const,
      title: 'Generate image',
      rawInput: `${args.provider !== undefined ? `[${args.provider}] ` : ''}${String(args.prompt)}`,
    }),
  }))

  ctx.tools.register(defineTool({
    name: 'vision_providers',
    description: '列出当前已配置的外部 API 模型（vision = 图像识别，image = 图像生成），含 id、模型名、端点与是否已填 apiKey。调用 image_recognize / image_generate 前可用它确认可用的 provider id。',
    parameters: {},
    output: TEXT_OUTPUT,
    isConcurrencySafe: () => true,
    execute: async () => describeProviders(services.config()),
    presentCall: () => ({ card: 'generic' as const, title: 'Vision providers' }),
  }))
}

/** Caller workspace (session cwd); falls back to the process cwd. */
function cwdOf(exec: ToolRunContext): string {
  const cwd = exec.agent?.session?.header.cwd
  return cwd !== undefined && cwd.length > 0 ? cwd : process.cwd()
}

/**
 * Format the image_generate result: local paths, plus Markdown image URLs
 * (when the static server maps them) the model can paste into its reply so
 * the Web GUI renders the images inline.
 */
export function formatGenerateResult(
  paths: readonly string[],
  urlFor: ((path: string) => string | undefined) | undefined,
): string {
  const lines = paths.map(path => `- ${path}`)
  if (urlFor !== undefined) {
    const urls = paths
      .map(urlFor)
      .filter((url): url is string => url !== undefined)
    if (urls.length > 0) {
      lines.push('')
      lines.push('Web 对话中可直接显示的图片（把下面这行 Markdown 放进你的回复正文即可）：')
      urls.forEach((url, index) => {
        const name = basename(paths[index] ?? url)
        lines.push(`![${name}](${url})`)
      })
    }
  }
  return `已生成 ${paths.length} 张图片：\n${lines.join('\n')}`
}
