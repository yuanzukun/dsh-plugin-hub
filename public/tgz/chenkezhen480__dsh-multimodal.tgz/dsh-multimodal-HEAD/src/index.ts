/**
 * dsh-plugin-multimodal — image recognition and image generation for
 * DeepSeek Harness.
 *
 * The plugin is "just tools": it calls whichever OpenAI-compatible external
 * API models the deployer declares. No model is bundled or defaulted — a
 * tool invoked without a configured model fails with a clear, actionable
 * error. The `vision_providers` tool lists what is configured.
 *
 * Configuration flows through the harness settings service when available:
 * the `multimodal` namespace layers the user document
 * (`$DSH_HOME/settings.yaml`) UNDER the composition (cordis patch) config —
 * in-package config overrides outer layers (包内覆盖外层). Settings changes
 * hot-reload without a restart.
 *
 * @module dsh-plugin-multimodal
 */

import type { Context } from '@deepseek-ai/cordis'
import { join, resolve } from 'node:path'
import { Config, resolveConfig, SETTINGS_NAMESPACE, type Config as ConfigValue, type ResolvedConfig } from './config.ts'
import { startStaticServer, type StaticServer } from './static.ts'
import { registerMultimodalTools } from './tools.ts'

export const name = 'multimodal'

export { Config, SETTINGS_NAMESPACE, resolveConfig }
export { describeProviders, pickProvider } from './providers.ts'
export { recognizeImage } from './vision.ts'
export { generateImages } from './imagegen.ts'
export { generateViaDashScope, DASHSCOPE_HOST } from './dashscope.ts'
export { startStaticServer, type StaticServer } from './static.ts'
export { resolveImageUrl, resolveOutputPath, uniqueImageName } from './util.ts'

/** Capability services required by the model-facing consumer. */
export const inject = ['tools']

/** Structural settings surface (avoids a hard dsh-settings peer dependency). */
interface SettingsLike {
  register(
    ns: string,
    schema: unknown,
    options?: { base?: unknown },
  ): {
    get(): unknown
    watch(listener: (next: unknown, prev: unknown) => void): () => void
  }
}

export function apply(ctx: Context, config: ConfigValue): void {
  // A single mutable resolved config drives every consumer; settings hot
  // reloads replace it in place.
  let resolved = resolveConfig(config)
  const applyResolved = (next: ResolvedConfig): void => {
    resolved = next
  }

  // Built-in static server so the Web GUI can render generated images via
  // absolute http(s) markdown image URLs (its Markdown renderer rejects
  // local paths / relative links / data URIs by protocol allowlist).
  // The server roots at the default output directory: the configured
  // outputDir (resolved against the process cwd) or `<cwd>/generated`.
  // Port bind failures degrade gracefully (tools just return local paths).
  let staticServer: StaticServer | undefined
  if (resolved.staticPort > 0) {
    const serverRoot = resolved.outputDir !== undefined
      ? resolve(process.cwd(), resolved.outputDir)
      : join(process.cwd(), 'generated')
    staticServer = startStaticServer(serverRoot, resolved.staticPort)
    ctx.effect(() => {
      void staticServer!.ready.catch(error => {
        ctx.logger.warn(`multimodal: 静态图片服务不可用（端口 ${resolved.staticPort} 可能被占用）: ${String(error)}`)
      })
      return () => {
        void staticServer!.close()
      }
    }, 'multimodal static server')
  }

  registerMultimodalTools(ctx, { config: () => resolved, staticServer: () => staticServer })

  // Settings integration: the user document (`settings.yaml`) layers UNDER
  // the composition (cordis patch) config — in-package config overrides outer
  // layers (包内覆盖外层), the user document only fills keys the composition
  // does not declare. Changes hot-reload on every commit. Without a settings
  // provider the plugin keeps resolving the composition config alone.
  const settings = ctx.get('settings') as unknown as SettingsLike | undefined
  if (settings !== undefined) {
    const scope = settings.register(SETTINGS_NAMESPACE, Config)
    const mergeUnder = (stored: ConfigValue): ConfigValue => ({ ...stored, ...config })
    const stored = scope.get()
    if (stored !== undefined) {
      try {
        applyResolved(resolveConfig(mergeUnder(stored as ConfigValue)))
      } catch (error) {
        ctx.logger.warn(`multimodal: stored settings rejected: ${String(error)}`)
      }
    }
    ctx.effect(() => scope.watch((next) => {
      try {
        applyResolved(resolveConfig(mergeUnder(next as ConfigValue)))
        ctx.logger.info('multimodal: settings reloaded (providers=%d)', resolved.providers.length)
      } catch (error) {
        ctx.logger.warn(`multimodal: settings update rejected: ${String(error)}`)
      }
    }), 'multimodal settings watcher')
  }
}
