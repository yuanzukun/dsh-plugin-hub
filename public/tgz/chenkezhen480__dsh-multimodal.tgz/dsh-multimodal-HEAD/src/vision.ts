/**
 * Image recognition client: multimodal chat/completions against any
 * OpenAI-compatible endpoint. The image is sent as a data URI (local files)
 * or as an http(s) URL; the endpoint decides how to fetch it.
 *
 * @module dsh-plugin-multimodal/vision
 */

import type { ProviderConfig } from './config.ts'
import { resolveImageUrl } from './util.ts'

export interface RecognizeInput {
  /** Local path, http(s) URL, or data URI of the image. */
  readonly image: string
  /** What to ask about the image; a generic description when omitted. */
  readonly prompt: string | undefined
  readonly provider: ProviderConfig
  readonly maxTokens: number | undefined
  readonly temperature: number | undefined
  /** Caller workspace, used to resolve relative image paths. */
  readonly cwd: string
  readonly signal?: AbortSignal
}

/** POST an OpenAI-compatible chat completion with image content. */
export async function recognizeImage(input: RecognizeInput): Promise<string> {
  const { provider, cwd, signal } = input
  const imageUrl = await resolveImageUrl(input.image, cwd)
  const prompt = input.prompt !== undefined && input.prompt.trim().length > 0
    ? input.prompt.trim()
    : '请详细描述这张图片的内容。'
  const body: Record<string, unknown> = {
    model: provider.model,
    messages: [{
      role: 'user',
      content: [
        { type: 'text', text: prompt },
        { type: 'image_url', image_url: { url: imageUrl } },
      ],
    }],
  }
  if (input.maxTokens !== undefined || provider.maxTokens !== undefined) {
    body.max_tokens = input.maxTokens ?? provider.maxTokens
  }
  if (input.temperature !== undefined || provider.temperature !== undefined) {
    body.temperature = input.temperature ?? provider.temperature
  }
  const response = await fetch(joinBase(provider.apiBase, 'chat/completions'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${provider.apiKey}`,
    },
    body: JSON.stringify(body),
    signal,
  })
  if (!response.ok) {
    throw await apiError('chat/completions', response)
  }
  const data = await response.json() as {
    choices?: Array<{ message?: { content?: unknown } }>
  }
  const content = data.choices?.[0]?.message?.content
  if (typeof content !== 'string' || content.length === 0) {
    throw new Error('multimodal: 视觉模型返回了空内容（choices[0].message.content 缺失）。请检查 provider 配置是否正确。')
  }
  return content
}

export async function apiError(route: string, response: Response): Promise<Error> {
  let detail = ''
  try {
    const data = await response.json() as { error?: { message?: unknown } }
    if (typeof data.error?.message === 'string') detail = data.error.message
  } catch {
    // keep the empty detail
  }
  const status = response.status
  const hint = status === 401 ? '（API Key 无效或未授权）'
    : status === 404 ? '（端点或模型不存在，请检查 apiBase 与 model 拼写）'
    : status === 429 ? '（请求过于频繁或额度不足）'
    : ''
  const base = `multimodal: ${route} 请求失败（HTTP ${status}）${hint}`
  return new Error(detail.length > 0 ? `${base}\n远端信息: ${detail}` : base)
}

/** Join a base URL and a route, tolerating a trailing slash on the base. */
export function joinBase(base: string, route: string): string {
  const trimmed = base.replace(/[\\/]+$/u, '')
  return `${trimmed}/${route}`
}
