# Open-in-app launch fix · dsh-open-in-app-fix

![Open-in-app launch fix](icon.png)

[简体中文](README.md) · **English**

| Item | Detail |
| --- | --- |
| UI display name | **应用内打开修复** (from `locale/zh.json`; English fallback `Open-in-app launch fix`) |
| Package | `@local/dsh-open-in-app-fix` |
| Version | `1.1.0` |
| Shape | DSH **host-side (Node)** plugin, no browser half |
| Needs a skin? | No. Unrelated to skins and to the workspace tree |
| Touches `app.asar`? | **No** |

## What it is

Fixes the failure where DSH Desktop's "Open in …" actions cannot launch an editor.
Typical symptom: clicking "Open in Visual Studio Code" reports a failure, and the request returns **HTTP 502**:

```json
{ "code": "launch-failed", "message": "failed to launch vscode" }
```

Only entries that **spawn an executable directly** (editors, terminals) are affected;
"Show in File Explorer", which goes through the system open verb, is fine.

## Why it happens

To make the runtime bundled inside `app.asar` run as a Node interpreter, the desktop shell
starts the host process with `ELECTRON_RUN_AS_NODE=1`. That variable stays in the process
environment, and open-in-app passes the scrubbed environment straight to the child process:

```js
env: { ...scrubbedParentEnv(), ...options.env }
```

`scrubbedParentEnv` (from `@deepseek-ai/dsh-subprocess`) only filters keys matching
`/KEY|PASSWORD|SECRET|TOKEN/i` and the `DSH_` prefix — it **does not handle
`ELECTRON_RUN_AS_NODE`**, so the variable reaches the editor untouched.
An editor (itself an Electron binary) started with that variable treats itself as a Node
interpreter, tries to execute the directory argument as a script, and exits non-zero within
`launchWatchMs` (1000 ms by default). The request then falls through to 502.

## How it works

The plugin uses Node's module hooks (`module.registerHooks`) to intercept the single
`@deepseek-ai/dsh-subprocess` import that **the open-in-app package** makes, replacing it with a wrapper:

```js
export * from "<file URL of subprocess>";
import { scrubbedParentEnv as raw } from "<file URL of subprocess>";
export const scrubbedParentEnv = () => {
  const environment = raw();
  delete environment.ELECTRON_RUN_AS_NODE;   // the only change
  return environment;
};
```

Key points:

- `export *` forwards every export of the original package and overrides only the one name;
- `raw()` is still the official implementation — no upstream scrubbing rule is bypassed;
- only imports whose `parentURL` sits inside the open-in-app package directory are intercepted,
  so the host's own subprocess/terminal launchers (which **need** that variable to run in Node mode)
  are completely unaffected;
- variables declared explicitly in `options.env` (some catalog entries request
  `ELECTRON_RUN_AS_NODE` on purpose) are merged afterwards and therefore kept —
  **inherited is removed, explicit is preserved**.

The bundled `cordis.patch.yml` disables the official entry first:

```yaml
- id: open-in-app
  disabled: true
- insert:
    - id: open-in-app-fix
      name: '@local/dsh-open-in-app-fix'
      config:
        probeTimeoutMs: 10000
        iconTimeoutMs: 10000
        launchWatchMs: 1000
```

Module hooks can only affect modules that have **not started loading** yet, so the official
entry must be disabled first. The plugin then imports the official module itself and forwards
its `name` / `inject` / `Config` / `apply` unchanged, so behaviour matches the original.

## Caveats

- This is order-sensitive: the official entry must not be imported before the hook is registered,
  so `disabled: true` must stay.
- If the official package stops importing `@deepseek-ai/dsh-subprocess`, the wrapper becomes a
  no-op and the 502 returns. If the problem reappears after a DSH upgrade, check the official
  package's import site first.
- The plugin **never writes `app.asar`**, so an application upgrade cannot wipe it out, and
  uninstalling requires no file restoration.

## Install

DSH Desktop → "Plugins" in the left sidebar → Install, and enter any one of these **absolute paths**:

```text
<clone of this repo>\dsh-open-in-app-fix              # directory path, installed with link:
<clone of this repo>\build\local-dsh-open-in-app-fix-1.1.0.tgz   # build output (build/ is not in git)
<downloaded local-dsh-open-in-app-fix-1.1.0.tgz>      # or a tarball from Releases, absolute path
```

Both are equivalent: the directory is convenient while iterating locally, the tarball pins a version
for distribution.

**Quit DSH completely and restart it** afterwards.
If you previously used the old approach that rewrote `app.asar`, restore the archive before
installing this plugin so the same path is not fixed twice.

## Verify

1. Click "Open in Visual Studio Code" on a workspace — the editor should open that directory;
2. In DevTools → Network, that POST should return **200 `{ ok: true }`** instead of 502;
3. Also try Cursor, Windows Terminal and "Show in File Explorer" to confirm there is no regression.

## Uninstall

Remove the plugin from the Plugins page (or delete the `disabled` and `insert` entries from the
patch) and restart. The official entry is enabled again and behaviour returns to stock.
**No file needs to be restored.**

## Files

| File | Purpose |
| --- | --- |
| `index.js` | **All the logic**: probe the anchor → register module hooks → load and forward the official plugin |
| `cordis.patch.yml` | Disable the official entry + insert this plugin (including the three timeout settings) |
| `locale/zh.json`, `locale/en.json` | UI display name and description |
| `icon.png` | Plugin icon (512×512 PNG) |
| `README.md` | Chinese README (the default) |
| `README.en.md` | This file |

## Detailed guide

This file covers "install it and use it". The full story — why rewriting `app.asar` is not the
answer, how the module hook takes over the official plugin, how the timeout and fallback values
were chosen, plus every verification record — is in:

- [docs/详细说明.md](docs/详细说明.md) **(in this repo, written in Chinese)**
- Online: https://github.com/yanli-nyan/dsh-open-in-app-fix/blob/main/docs/详细说明.md

## Versions

| Version | Changes |
| --- | --- |
| `1.1.0` | Added the Chinese display name (`应用内打开修复`), Chinese description and `icon.png`; `README.md` switched from English to Chinese, English text moved to `README.en.md` |
| `1.0.0` | First release: module-hook approach |
