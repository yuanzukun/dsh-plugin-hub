/**
 * Keep "Open in ..." launches working when DSH runs as an Electron-as-Node host.
 *
 * The desktop host process starts with ELECTRON_RUN_AS_NODE=1 so the bundled
 * runtime behaves as a Node interpreter. The environment helper that the
 * open-in-app plugin uses for child launches passes that variable through, so a
 * launched Electron editor starts as a Node interpreter, runs the directory as
 * a script, and exits non-zero inside the launch watch window. The request then
 * fails with HTTP 502 launch-failed.
 *
 * This plugin repairs the launch without editing the shipped app.asar. It
 * registers a module hook that replaces the single @deepseek-ai/dsh-subprocess
 * import made by the open-in-app package with a wrapper that drops the
 * variable, then re-exports the official plugin verbatim. Only that package's
 * imports are rewritten, so the host's own subprocess and terminal launchers
 * keep inheriting the flag they need.
 *
 * The profile patch disables the official entry so that no import of the
 * official module happens before this plugin owns it: a module hook cannot
 * affect a module that is already being, or has already been, loaded.
 */
import { createRequire, registerHooks } from "node:module";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const OFFICIAL_PACKAGE = "@deepseek-ai/dsh-host-open-in-app";
const SUBPROCESS_PACKAGE = "@deepseek-ai/dsh-subprocess";
const SHIM_URL = "dsh-open-in-app-fix:subprocess-shim";
const PROBE_FILENAME = "__dsh-open-in-app-fix-probe.cjs";

/** Directories that may anchor the running installation's package resolution. */
function anchorCandidates() {
	const candidates = [];
	const push = (value) => {
		if (value && !candidates.includes(value)) candidates.push(value);
	};
	const executableDir = dirname(process.execPath);
	push(join(executableDir, "resources", "app.asar", "dsh"));
	push(join(executableDir, "resources", "app.unpacked", "dsh"));
	let dir = process.argv[1] === undefined ? undefined : dirname(process.argv[1]);
	while (dir !== undefined) {
		try {
			const manifest = JSON.parse(readFileSync(join(dir, "package.json"), "utf8"));
			if (manifest !== null && manifest.name === "@deepseek-ai/dsh") {
				push(dir);
				break;
			}
		} catch {
			// No readable manifest here; keep walking up.
		}
		const parent = dirname(dir);
		if (parent === dir) break;
		dir = parent;
	}
	return candidates;
}

/** Resolve a bare specifier as if from the given anchor directory. */
function resolveFrom(anchor, specifier) {
	try {
		return createRequire(join(anchor, PROBE_FILENAME)).resolve(specifier);
	} catch {
		return undefined;
	}
}

/** Locate the official plugin and the subprocess package in one installation. */
function locatePackages() {
	for (const anchor of anchorCandidates()) {
		const official = resolveFrom(anchor, OFFICIAL_PACKAGE);
		if (official === undefined) continue;
		const subprocess = resolveFrom(anchor, SUBPROCESS_PACKAGE);
		if (subprocess === undefined) continue;
		return { official, subprocess };
	}
	return null;
}

const located = locatePackages();
if (located === null) {
	throw new Error("open-in-app-fix: cannot resolve " + OFFICIAL_PACKAGE + " from the running installation");
}

const officialUrl = pathToFileURL(located.official).href;
const subprocessUrl = pathToFileURL(located.subprocess).href;
const packageDirUrl = pathToFileURL(dirname(dirname(fileURLToPath(officialUrl)))).href;

const shimSource = [
	"export * from " + JSON.stringify(subprocessUrl) + ";",
	"import { scrubbedParentEnv as raw } from " + JSON.stringify(subprocessUrl) + ";",
	"export const scrubbedParentEnv = () => {",
	"	const environment = raw();",
	"	delete environment.ELECTRON_RUN_AS_NODE;",
	"	return environment;",
	"};",
].join("\n");

registerHooks({
	resolve(specifier, context, nextResolve) {
		if (
			specifier === SUBPROCESS_PACKAGE &&
			typeof context.parentURL === "string" &&
			context.parentURL.startsWith(packageDirUrl)
		) {
			return { url: SHIM_URL, shortCircuit: true };
		}
		return nextResolve(specifier, context);
	},
	load(url, context, nextLoad) {
		if (url === SHIM_URL) {
			return { format: "module", source: shimSource, shortCircuit: true };
		}
		return nextLoad(url, context);
	},
});

const official = await import(officialUrl);

export const name = "open-in-app-fix";
export const inject = official.inject;
export const Config = official.Config;
export const apply = official.apply;
