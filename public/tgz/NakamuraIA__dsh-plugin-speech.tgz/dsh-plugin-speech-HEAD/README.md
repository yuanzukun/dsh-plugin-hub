# dsh-plugin-speech

English | [中文](README.zh.md)

![Read aloud — DeepSeek Harness speech plugin](docs/cover.jpg)

Read assistant replies aloud in [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness), one continuous voice per reply.

## What it does

Each finished assistant message gets a play control in its action row. Press it and the reply is spoken through a text-to-speech service. Press it again and the voice **pauses** — the reply keeps being synthesized and buffered behind it — and pressing once more resumes from the same word. A separate stop control appears beside it while a reply is the active one, for when the reading is over rather than interrupted. A settings row in General owns the service, the voice, and the tuning.

The whole reply goes out in **one request** and the host streams the audio back while the service is still synthesizing it. The browser holds the first **6 seconds** of audio before it starts the voice, and holds it again mid-reply if the buffer ever falls behind the playhead — so a reading runs continuously instead of stopping to wait for the next chunk. A reply that finishes arriving first starts immediately; a short one never waits.

A finished reply is **kept in memory**, so pressing play on the same message again is instant and asks the service nothing. The cache holds up to 8 replies or 64 MB, whichever comes first, and it dies with the page: nothing is written to disk.

## Providers

| Service | Key needed | Voices |
|---|---|---|
| **Microsoft Edge** (default) | no | the service publishes its full catalog, every language it serves |

Adding a provider means adding one folder under `src/providers/` and one line in `src/providers/registry.ts` — the settings screen builds its fields from what the provider declares.

### The Edge token

Every handshake carries a short-lived `Sec-MS-GEC` token: the current time in Windows file-time ticks, rounded down to five minutes, digested together with the well-known client token. In October 2026 the endpoint moved to a **second generation** of that token — a patched SHA-256 paired with a 64-bit checksum — and began answering the first generation with a bare `403` (`Edge TTS WebSocket error: Unexpected server response: 403`), which is what a reply that never speaks looks like from the browser. `src/providers/edge/gec.ts` reproduces the accepted generation; `server.ts` hands it to `msedge-tts` by replacing the library's private URL builder, which is also what pins the token version the endpoint now expects. If read-aloud stops working again, test that token first: it is the only part of this plugin that can expire without the code changing.

A refused handshake is reported as its own failure — *the speech service refused the connection. It changed, so this plugin needs an update* — rather than as the generic call failure. The distinction matters: nothing the reader changes will fix it, and a message that says so sends them to the right place. `src/speech-errors.ts` classifies the failure on the host and carries the class beside the message; the surface renders the matching copy, and the raw `403` stays in the tooltip.

## Requirements

- A DeepSeek Harness surface — `dsh web`, or the desktop app — version `0.2.2-rc.1` or newer.
- Network access to the speech service. Nothing else: there is no model to download, and the Edge provider needs no account.

The version floor is not decorative. The plugin's preferences are its own Cordis entry config, exposed to the settings screen as a form through `ctx.configForms`. Releases before `0.2.0-rc.2` had plugins register settings namespaces themselves (`settings.register`) and handed the browser a `ctx.settingsScope`; both services are gone.

## Install

This package declares `dsh.bundle.patch`, so it installs as a **profile bundle**: the package
manager links it, the launcher appends it to the profile's `dsh.profile.bundles`, and the
bundle's own patch layer inserts the plugin row. Installing also enables it — in DeepSeek
Harness, installing a plugin and enabling it in a profile are separate steps, and a bundle
collapses the two.

**Desktop app** — sidebar → **Plugins** → **Add plugin**, then give one of:

- `@nakamuraia/dsh-plugin-speech` (the npm registry)
- `github:NakamuraIA/dsh-plugin-speech`
- an absolute path to a local checkout

**From the CLI** — the same operation, profile-scoped:

```sh
dsh plugin --profile web add github:NakamuraIA/dsh-plugin-speech
```

Restart the surface afterwards. The host half claims its HTTP routes when the plugin loads,
a desktop profile is owned by the app, and a newly installed out-of-tree bundle is not mounted
by a live recomposition — an app-internal row added to a patch does reload immediately, a
package that has to come from the profile's `node_modules` does not.

### One-off overlay, without installing

`cordis.patch.yml` is the same patch the bundle applies, so it also works as a temporary
command-line overlay:

```sh
dsh web --patch ./cordis.patch.yml
```

Do **not** do both. A profile patch that inserts `ui-speech` while the bundle is selected
collides with `duplicate loader entry id`; the profile layer is for overriding the row's
config, which is what the settings screen writes.

The **row name** is the package name and also the browser module id the built bundle registers
under; the **row id** (`ui-speech`) is the settings namespace the config form is keyed by.
Nothing works if either one drifts, so change the two together.

## Settings

Settings opens on **General**, where a **Read aloud** row owns:

- **Service** — which provider speaks.
- **Language** and **Voice** — the catalog entry to use.
- **Speed**, **Volume**, **Pitch** — sent to the service with every request.
- **Skip code** — leave fenced code and inline code out of the reading.
- **Test voice** — speaks a sample through the settings on screen, saved or not.

The row edits the plugin's own entry config, so the chosen values persist in the profile patch beside the entry rather than in a settings document. Resetting a field restores the schema default, and a write the Host refuses leaves the stored value untouched while the row says so.

Tables and pasted spreadsheets are never read, whichever way **Skip code** is set. That switch decides only whether fenced and inline code are read: with it off, the code itself is spoken and just the fences go. Links keep their label and lose their target; emoji, quotes, and standalone symbols are dropped. Sentence punctuation is kept, because the voice uses it for pauses.

## How it works

```
browser                    host                        service
───────                    ────                        ───────
click ─ ▶ POST /speech/speak { text }
                           select provider from
                           its own entry config
                           ────────────────────────── ▶ synthesize
        ◀ ─ audio bytes stream back ─ ─ ─ ─ ─ ─ ─ ─ ─ ┘
buffer the first 6 s, then play while the rest appends
```

Synthesis lives on the host because a browser cannot hold an API key and cannot reach most services across CORS. The browser only posts text and plays bytes. Every editable leaf of the entry config is `.volatile()`, so a settings write lands in the running host without reloading it — the host reads the same value the browser wrote.

One request is the point. Every extra request pays a fresh handshake — around 0.9 s to the service — and adds a connection that can be dropped; sending the whole reply once means one handshake and one stream. The service is fast enough for that to be the right trade: measured at **73x realtime** on a warm connection and 1.5x on a cold one, so a two-minute reading arrives in under two seconds.

The **6-second head** is what keeps the voice continuous. A reply shorter than that finishes arriving first, so playback begins the moment the body ends and the wait is invisible; a longer one starts once the head is in hand, with enough margin to absorb the jitter that used to drain a smaller head.

Past that point a guard watches the distance between the playhead and the last byte buffered. Under **2 seconds** of lead it holds the voice — synthesis carries on behind the hold — and above **6 seconds** it lets go. That is the difference between a stall the listener hears as a dropped word and one they never notice.

The guard knows when the reply has stopped arriving. At the end of any reading that lead reaches zero by definition, and a hold there would clip the final words and leave the element paused short of its `ended` event — a reading that never finishes and a control that never resets. Once the body is drained the guard only relaxes.

If the stream dies after the voice started, what is already buffered still plays out; if the engine refuses the buffer outright the reply is played as one whole file instead.

Skipping ahead is cheap: a finished reply lives in memory as one file, so playing it again reuses it instead of synthesizing it. That copy is what makes the second listen instant, and it is also why a replay can seek. Nothing reaches disk, and the cache is dropped with the page — as is a reply that arrived truncated, so a broken reading is never replayed as if it were whole.

A voice can also end every sentence with a long silence of its own — `pt-BR-AntonioNeural`, the schema default, leaves about 0.9 s at each one, while the multilingual voices leave none. That silence is in the audio the service returns, not in how this plugin plays it.

## Development

This repository builds on its own against the published `@deepseek-ai/*` packages; no harness checkout is involved:

```sh
pnpm install
pnpm build      # tsc → lib/types, tsdown → lib/index.js + lib/client.js
pnpm test       # vitest
pnpm typecheck  # sources and specs
```

`build/plugin-bundle.ts` is the client-bundle preset. It emits the `window.__ModuleLoader__.load` handoff, keeps every module-table row a `require`, compiles CSS Modules into one injected style tag, and fails the build on a cross-plugin value import. It is a self-contained copy of the harness preset, which is what lets the package be built here.

Three specs under `tests/checkout/` compose the real client registries, which only exist as sources inside a harness checkout; `tests/checkout/README.md` explains why and how to run them. Everything else, including the client wiring, runs through `pnpm test`.

### Migrating from 0.2.x

- The harness floor is now `0.2.2-rc.1` (Cordis 4.1). `ConfigFormSnapshot` dropped `mode`; a page that is not writable is read from `writable` instead.
- The action's second press is a **pause**, not a stop. Stopping moved to its own control beside it, so a reader who only ever used the toggle now has one more button on screen while a reply is active.
- A reply that has finished is cached in memory and replayed without another synthesis.

### Migrating from 0.1.x

- The host half exports `Config` — the schemastery schema with `.volatile()` leaves — and no longer calls `settings.register`; the synthesis route reads the entry config it was handed at apply time.
- The client half takes `ctx.configForms.get('ui-speech')` instead of `ctx.settingsScope.bind(...)`, and a write reports acceptance directly (`Promise<boolean>`) instead of being checked against the settled section.
- Icons from `@deepseek-ai/dsh-client-ui-primitives` are named by weight (`IconPlayOutlineRegular`), not by drawn size (`IconPlayOutline16`).

## License

MIT. The Edge provider drives Microsoft's read-aloud endpoint through [`msedge-tts`](https://github.com/harvey-woo/msedge-tts) (MIT); that endpoint is not a documented, supported Microsoft API, so treat availability as best effort.
