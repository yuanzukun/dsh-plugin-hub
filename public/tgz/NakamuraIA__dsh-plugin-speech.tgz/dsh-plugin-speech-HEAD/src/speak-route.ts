/**
 * `POST /speech/speak`: the browser posts text, the host selects the provider
 * from its entry config and calls it with the deployment's credentials, and the
 * audio streams straight back. Synthesis belongs to the host because the browser
 * cannot hold an API key and cannot reach most providers across CORS.
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import type { SpeechAudio } from './providers/types.ts'
import { selectSpeech, type SpeechOverrides } from './selector.ts'
import { errorCodeOf } from './speech-errors.ts'
import { MAX_TEXT_CHARS } from './speech-limits.ts'
import type { SpeechSettings } from './settings.ts'

/** Largest request body accepted; one reply is far below this. */
const MAX_BODY_BYTES = 256 * 1024

/**
 * Attempts one synthesis gets before the route reports a failure. The service
 * closes a connection without audio often enough that one try is a coin flip.
 */
const SYNTHESIS_ATTEMPTS = 3

/** Pause between attempts: a failed connection is already gone, this is just courtesy. */
const RETRY_DELAY_MS = 200

/** Body shape the browser posts. */
interface SpeakBody {
  text?: unknown
  provider?: unknown
  voice?: unknown
  tuning?: unknown
}

/**
 * Read a bounded JSON request body.
 * @param req - the node:http request.
 * @returns the parsed body, or undefined when it is absent, oversized, or not JSON.
 */
async function readBody(req: IncomingMessage): Promise<SpeakBody | undefined> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const buffer = chunk as Buffer
    size += buffer.length
    if (size > MAX_BODY_BYTES) return undefined
    chunks.push(buffer)
  }
  if (size === 0) return undefined
  try {
    const parsed: unknown = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    return typeof parsed === 'object' && parsed !== null ? parsed : undefined
  } catch (_invalidJson) {
    return undefined
  }
}

/**
 * Narrow one wire value to a tuning record.
 * @param value - the request body's tuning member.
 * @returns the record, or undefined when the body carried none.
 */
function tuningOf(value: unknown): Readonly<Record<string, unknown>> | undefined {
  if (typeof value !== 'object' || value === null) return undefined
  return value as Readonly<Record<string, unknown>>
}

/**
 * Re-yield whatever a stream iterator has left after its first chunk.
 * @param iterator - the iterator the route already advanced once.
 * @returns the remaining chunks.
 */
async function* remaining(iterator: AsyncIterator<unknown>): AsyncGenerator<Buffer> {
  for (;;) {
    const next = await iterator.next()
    if (next.done === true) return
    yield next.value as Buffer
  }
}

/**
 * Answer one synthesis request.
 * @param req - the node:http request.
 * @param res - the node:http response.
 * @param section - reads the live preferences of this plugin's entry.
 */
export async function serveSpeechRequest(
  req: IncomingMessage,
  res: ServerResponse,
  section: () => SpeechSettings,
): Promise<void> {
  if (req.method !== 'POST') {
    res.writeHead(405)
    res.end()
    return
  }
  const body = await readBody(req)
  const text = typeof body?.text === 'string' ? body.text : ''
  if (text === '' || text.length > MAX_TEXT_CHARS) {
    res.writeHead(400, { 'content-type': 'application/json; charset=utf-8' })
    res.end(JSON.stringify({ error: `text must be 1..${MAX_TEXT_CHARS} characters` }))
    return
  }
  const tuning = tuningOf(body?.tuning)
  const overrides: SpeechOverrides = {
    ...(typeof body?.provider === 'string' ? { provider: body.provider } : {}),
    ...(typeof body?.voice === 'string' ? { voice: body.voice } : {}),
    ...(tuning === undefined ? {} : { tuning }),
  }
  const selected = selectSpeech(section(), text, overrides)
  if (selected === undefined) {
    res.writeHead(404, { 'content-type': 'application/json; charset=utf-8' })
    res.end(JSON.stringify({ error: 'unknown speech provider' }))
    return
  }
  try {
    // The service drops connections on its own schedule: a turn opens, then the
    // socket closes before any audio and without an error frame. Nothing was
    // sent to the browser at that point, so the whole attempt is simply repeated
    // on a fresh connection, which is what makes the difference between a silent
    // failure and a reading.
    let attempt = 0
    let audio: SpeechAudio | undefined
    let chunks: AsyncIterator<unknown> | undefined
    let first: IteratorResult<unknown> | undefined
    for (; attempt < SYNTHESIS_ATTEMPTS; attempt += 1) {
      try {
        audio = await selected.provider.synthesize(selected.request, {})
        chunks = audio.stream[Symbol.asyncIterator]()
        first = await chunks.next()
        break
      } catch (error) {
        audio?.stream.destroy()
        if (attempt === SYNTHESIS_ATTEMPTS - 1) throw error
        await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS))
      }
    }
    if (audio === undefined || chunks === undefined || first === undefined) {
      throw new Error('synthesis produced no attempt')
    }
    // Commit the response only once the service has produced audio. Committing
    // first would turn a provider that fails on its very first frame into an
    // empty 200 — silence with nothing the browser can report — which is what a
    // dropped handshake used to look like here.
    res.writeHead(200, {
      'content-type': audio.contentType,
      // Audio is already compressed and is consumed once: never deflate it, and
      // never let a proxy hold it for another request.
      'cache-control': 'no-store, no-transform',
    })
    if (first.done === true) {
      res.end()
      return
    }
    res.write(first.value)
    // The pipeline carries the rest and ends the response itself.
    await pipeline(Readable.from(remaining(chunks)), res)
  } catch (error) {
    // Past the first chunk the response is committed and its length is already
    // promised, so the only honest thing left is to tear it down.
    if (res.headersSent) {
      res.destroy()
      return
    }
    // The code travels beside the message so the surface can say something
    // useful: a refused handshake is not the reader's problem to solve, and the
    // generic "the call failed" would send them looking in the wrong place.
    const code = errorCodeOf(error)
    res.writeHead(502, { 'content-type': 'application/json; charset=utf-8' })
    res.end(JSON.stringify({
      error: error instanceof Error ? error.message : String(error),
      ...(code === undefined ? {} : { code }),
    }))
  }
}
