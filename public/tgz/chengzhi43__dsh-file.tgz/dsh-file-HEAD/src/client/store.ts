/**
 * Module-level shared state for the dsh-file UI.
 *
 * The file TREE lives in the sidebar (`sidebar.workspaces` shadow) while the
 * EDITOR renders as the center-column "文件" view (`conversation.view`, inside
 * the session scroll body). Both halves need the same "open tabs / active
 * file" facts, so this tiny external store (React 18 `useSyncExternalStore`)
 * owns that state instead of duplicating it in two component trees.
 */
import { useSyncExternalStore } from 'react';

/** One open editor tab. */
export interface OpenTab {
  path: string;
  content: string;
  savedContent: string;
  mtimeMs: number;
  dirty: boolean;
  error?: string;
}

let tabs: OpenTab[] = [];
let activePath: string | null = null;
/**
 * The workspace root the open tabs belong to (resolved by the sidebar panel
 * after `setRoot`). Used only to detect a real WORKSPACE switch so stale tabs
 * from a previous workspace are dropped — never to reset on a mere view toggle.
 */
let workspaceRoot: string | null = null;
const listeners = new Set<() => void>();

function emit(): void {
  for (const listener of listeners) listener();
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/** Read-only access to the current open tabs (used by the hook and tests). */
export function getTabs(): OpenTab[] {
  return tabs;
}

/** Read-only access to the active file path (used by the hook and tests). */
export function getActivePath(): string | null {
  return activePath;
}

/** Subscribe the sidebar tree / editor overlay to the open-tab state. */
export function useTabs(): OpenTab[] {
  return useSyncExternalStore(subscribe, getTabs);
}

/** Subscribe to the active file path (null while the editor dialog is closed). */
export function useActivePath(): string | null {
  return useSyncExternalStore(subscribe, getActivePath);
}

/** Open (or focus) one file tab. */
export function openTab(tab: OpenTab): void {
  const existing = tabs.find((t) => t.path === tab.path);
  if (existing) {
    activePath = tab.path;
  } else {
    tabs = [...tabs, tab];
    activePath = tab.path;
  }
  emit();
}

/** Focus an already-open tab. */
export function focusTab(path: string): void {
  if (tabs.some((t) => t.path === path)) {
    activePath = path;
    emit();
  }
}

/** Replace the active tab's content (editor keystrokes). */
export function updateActiveContent(content: string): void {
  if (activePath === null) return;
  tabs = tabs.map((t) => (t.path === activePath ? { ...t, content, dirty: content !== t.savedContent } : t));
  emit();
}

/** Mark the active (or named) tab as saved after a successful write. */
export function markSaved(path: string): void {
  tabs = tabs.map((t) => (t.path === path ? { ...t, savedContent: t.content, dirty: false } : t));
  emit();
}

/** Close one tab; the next-most-recent tab becomes active (if any). */
export function closeTab(path: string): void {
  tabs = tabs.filter((t) => t.path !== path);
  if (activePath === path) {
    activePath = tabs.length > 0 ? tabs[tabs.length - 1].path : null;
  }
  emit();
}

/** Update tab paths after a rename. */
export function renameTab(from: string, to: string): void {
  tabs = tabs.map((t) => (t.path === from ? { ...t, path: to } : t));
  if (activePath === from) activePath = to;
  emit();
}

/** Drop every tab whose path is being deleted (or was deleted). */
export function removeTabs(paths: readonly string[]): void {
  const gone = new Set(paths);
  tabs = tabs.filter((t) => !gone.has(t.path));
  if (activePath !== null && gone.has(activePath)) {
    activePath = tabs.length > 0 ? tabs[tabs.length - 1].path : null;
  }
  emit();
}

/** Close the editor dialog entirely (keeps open tabs for the next open). */
export function closeEditor(): void {
  activePath = null;
  emit();
}

/** Reset all editor state (panel closed / workspace switched). */
export function resetAll(): void {
  tabs = [];
  activePath = null;
  emit();
}

/**
 * Record the workspace root the open tabs belong to.
 *
 * If the root CHANGED (a real workspace / session switch), drop all editor
 * state so stale tabs from the previous workspace don't linger. Passing the
 * SAME root — e.g. when the sidebar panel remounts after toggling between the
 * "文件" and "对话" views — is a NO-OP, so unsaved edits and open tabs survive
 * ordinary view switches. The sidebar panel calls this after it re-resolves
 * the gateway root; the panel's own unmount must NOT reset state directly, or
 * switching conversation views would silently discard the user's work.
 */
export function setWorkspaceRoot(root: string): void {
  if (workspaceRoot === root) return;
  workspaceRoot = root;
  resetAll();
}

// ── sidebar visibility sync ────────────────────────────────────────────────
// The center "文件" view (FileEditorView) is mounted only while it is the
// ACTIVE conversation view. It reports that fact here so the sidebar tree
// panel can follow: "文件" tab active → sidebar shows the workspace tree;
// switching back to "对话" (or any other view) → sidebar returns to the
// workspace/session browser.

let editorViewActive = false;
const viewListeners = new Set<() => void>();

function emitView(): void {
  for (const listener of viewListeners) listener();
}

/** Called by the editor view on mount (true) / unmount (false). */
export function setEditorViewActive(active: boolean): void {
  if (editorViewActive === active) return;
  editorViewActive = active;
  emitView();
}

/** Whether the "文件" conversation view is currently the active view. */
export function isEditorViewActive(): boolean {
  return editorViewActive;
}

/** Subscribe to editor-view activation changes (returns the disposer). */
export function subscribeEditorViewActive(listener: () => void): () => void {
  viewListeners.add(listener);
  return () => {
    viewListeners.delete(listener);
  };
}
