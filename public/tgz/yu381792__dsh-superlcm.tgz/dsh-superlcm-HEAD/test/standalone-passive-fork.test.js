import test from 'node:test'
import assert from 'node:assert/strict'
import {lab,history,send,close,count} from './reliability/lab.mjs'
import {ArchiveService} from '../src/archive-service.js'
import {readSettings,saveSettings} from '../src/settings.js'
import {forkScope} from '../src/main-fork.js'
import {join} from 'node:path'
test('archive-only DSH uses a main-model fork while takeover remains off',async()=>{
 const h=await lab({capacity:64000,persistent:true,config:{auto:false}});let service
 try{
  const file=join(h.dir,'passive-settings.json'),before=readSettings(file)
  saveSettings({revision:before.revision,settings:{...before.settings,summaryEnabled:true,summaryMode:'main-fork',takeover:false}},[],file)
  service=new ArchiveService(h.ctx,h.engine.superLcmStore,file)
  history(h,.72)
  const original=h.ctx.llm.stream.bind(h.ctx.llm),branches=[]
  h.ctx.llm.stream=options=>!forkScope.getStore()?original(options):(async function*(){
    branches.push(options)
    const prompt=options.messages.at(-1).content.map(x=>x.text||'').join('')
    const plan=JSON.parse(prompt.split('\n').find(x=>x.startsWith('[{"index":')))
    yield {type:'text-delta',text:JSON.stringify({blocks:plan.map(n=>({index:n.index,summary:'# Historical state\nPending inspection; preserve the user constraint.'}))})}
    yield {type:'usage',usage:{cacheReadTokens:30000}}
    yield {type:'finish',reason:{kind:'stop'}}
  })()
  await send(h,'Never deploy. Keep working in the main chat.')
  await service.drain()
  assert.equal(branches.length,1,JSON.stringify([...service.failures.values()]))
  assert.equal(count(h,'compaction/summary'),0)
  assert.ok(service.db.nodes(h.id).length>1)
  assert.equal(readSettings(file).settings.takeover,false)
  assert.equal(branches[0].provider,'lab-main');assert.equal(branches[0].model,'main-64000')
  assert.ok(h.agent.session.snapshotEvents().some(e=>JSON.stringify(e).includes('Never deploy.')))
 }finally{await service?.close();await close(h)}
})
