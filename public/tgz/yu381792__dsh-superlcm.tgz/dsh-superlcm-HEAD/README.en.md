<p align="center"><img src="docs/images/icon.svg" width="88" alt="SuperLcm"></p>

<h1 align="center">SuperLcm for DSH</h1>

<p align="center"><b>Keep every original. Recall any detail.</b><br>Background summaries · Exact recall · Optional context compaction</p>

<p align="center"><a href="README.md">中文</a> · <b>English</b> · <a href="https://github.com/yu381792/superlcm">Full SuperLcm project →</a></p>

SuperLcm for DSH preserves complete conversations in **DeepSeek Harness (DSH)**, organizes history into layered background summaries, and gives the agent tools to read exact originals when details matter. Summary and compaction controls live in the **native DSH plugin settings**, using providers and models already configured in DSH.

This is the standalone DSH edition. For a shared archive across Claude Code, Codex, Pi and DSH, conversation handoffs, and the complete product design, see **[the full SuperLcm project](https://github.com/yu381792/superlcm)**.

This README describes the current `main` checkout; these changes are not yet published as an npm package. Around 70%, a main-model background branch prepares a complete tree in one response. Optional takeover installs its prepared root around 80%. See [behavior and verification](docs/MAIN-FORK.md).

## A complete memory for DSH

- **Keep the original words.** User messages, agent replies and tool records remain available by event number.
- **Build an outline in the background.** Source segments become summaries; adjacent summaries form higher layers. Locate a topic, then read its source.
- **Follow the current conversation model.** A background branch inherits the active model and account. A separate summary model remains an advanced option.
- **Manage everything inside the plugin.** Open **Plugins → SuperLcm** for summary and optional compaction settings. Remote browsers use the same authenticated DSH connection.

## Start with background summaries

Original archiving runs with the plugin. On a fresh installation, summarization and compaction takeover are independently off. Choose the main-model branch and enable background summaries while DSH continues to handle native compaction.

| Feature | Control | Purpose |
|---|---|---|
| Original archive | Runs with the plugin | Preserve complete DSH event records |
| Background summaries | Summary settings | Organize history with the selected model and source granularity |
| Exact recall | Agent tools | Search history, inspect summaries and read originals |
| Optional takeover | Compaction settings | Replace an older fixed context range near the selected percentage |

Source segments default to approximately **20K tokens**. The plugin plans parents with four children by default and keeps complete tool groups together. One response supplies every block and parent. Block count is not request count. Independent-model advanced mode retains its separate batch writer.

Summaries locate history. Exact numbers, authorizations and consequential decisions should be checked against the originals.

## Optional: prepare ahead, replace at the threshold

With the default 80% takeover setting, preparation starts around 70%. The plugin fixes a safe older range, preserves the active model, account and request prefix, and asks one background branch for all leaves, parents and the root. The complete tree is validated and saved together.

```mermaid
flowchart LR
  A["Archive originals"] --> B["Around 70%: background fork"]
  B --> C["One response: blocks, parents and root"]
  C --> D["Validate and save the complete tree"]
  D --> E["Around 80%: install the prepared root"]
  E --> F["Retain recent and newly appended originals"]
```

Replacement calls no model. Capacity protection can prepare earlier or pause the next request; failures preserve originals. A later eligible range or a retry can start another branch.

- **Follow model capacity.** The default replacement point is 80% of available input capacity. Custom ratios from 11% to 99% always start preparation 10 percentage points earlier: 50% replacement means 40% preparation.
- **Adjust granularity.** Source block size controls the tree, without requiring one request per block.
- **Share prepared work.** The main-model branch supplies the same tree for archive summaries and takeover.
- **Separate switches.** Summaries can run without takeover, leaving native DSH compaction in charge. An independent summary model remains an advanced option.

## Install and update

Requires **Node.js 22.16+**. Tested with **DSH 0.2.1-alpha.1 and 0.2.1-rc.3**. Current plugin version: **0.6.0**.

Build in the repository directory and install the generated archive with the official DSH command:

```sh
npm pack
dsh plugin --profile web add ./SuperLcm-0.6.0.tgz
```

Windows PowerShell:

```powershell
dsh plugin --profile web add ".\SuperLcm-0.6.0.tgz"
```

Restart that DSH host and open **Plugins → SuperLcm → Summary settings**. Choose **Main-model background branch** and enable background summaries; an independent summary model remains an advanced option. Optional takeover has its own Compaction tab. Enable “Allow another model” to choose from DSH’s native provider/model catalog for the background branch only; the conversation model remains unchanged.

Installing over the existing standalone `SuperLcm` package updates it while keeping settings and the database. If using the full SuperLcm global DSH connection, disconnect DSH there before installing this edition. Retire custom patches that separately mount an older engine or tool entry.

## Recall tools

| Tool | Purpose |
|---|---|
| `lcm_find` | Search archived sessions and original text |
| `lcm_outline` | Inspect a session's layered summary outline |
| `lcm_read` | Read complete originals by event number |

Historical logs with broken numbering are archived in physical file order. Recall marks `physical-order` and provides the archive position, original sequence and physical row. Conflicting original sequence numbers are retained separately.

Legacy tools `lcm_grep`, `lcm_describe`, `lcm_expand`, `lcm_expand_query`, `lcm_reindex` and `lcm_doctor` remain available for compaction-index inspection and maintenance.

## Data lives on the DSH host

Originals, summaries and settings are stored locally. The main-model branch reuses the conversation request and appends a summary instruction for the current provider. Independent-model mode sends selected source segments to the configured summary provider. Remote browsers read settings through their authenticated DSH connection; the host resolves database paths.

The default database is `$DSH_HOME/SuperLcm/lcm.sqlite`, using the current user's `~/.dsh` when `DSH_HOME` is unset. `DSH_SUPERLCM_DB` selects a custom file; the legacy `DSH_LOSSLESS_DB` and `lossless-context` locations remain compatible.

## More

- **[Full SuperLcm project](https://github.com/yu381792/superlcm)**: shared archives, cross-tool handoffs and the complete product introduction.
- [Architecture](docs/ARCHITECTURE.md) · [Upgrade notes](docs/UPGRADE-0.5.35.md) · [Validation scope](docs/VALIDATION.md)
- [Changelog](CHANGELOG.md) · [Design references and dependencies](THIRD_PARTY_NOTICES.md) · [MIT license](LICENSE)

71 tests and a real macOS installation/upgrade check passed. Windows portability was reviewed; an actual Windows run was not performed. See the validation document for scope.

Development checks: `npm run validate`. Real install/upgrade check: `npm run test:install`. Repository Actions remain disabled.

SuperLcm is an independent project and is not affiliated with or endorsed by DeepSeek. Names identify compatible tools.

Reliability checks: `npm run test:reliability`; full release checks: `npm run verify:release`. See [test scope](docs/RELIABILITY-LAB.md).
