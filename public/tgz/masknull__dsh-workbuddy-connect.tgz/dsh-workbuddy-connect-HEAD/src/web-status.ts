/**
 * Same-origin status route for the WorkBuddy plugin card: sign-in state,
 * token expiry, and remaining credit, fetched by the browser half. The route
 * answers loopback browser requests only and never carries token material.
 *
 * @module dsh-workbuddy-connect/web-status
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-host-webserver'
import type { WorkBuddyCredentialStore } from './auth.ts'
import type { WorkBuddyUpstreamClient } from './upstream.ts'
import { normalizeCredits } from './upstream.ts'
import type { WorkBuddyModelInfo } from './catalog.ts'
import { hostIsLoopback, originIsLoopback } from './loopback.ts'
import { WORKBUDDY_STATUS_PATH } from './status-paths.ts'
import type { WorkBuddyWebCatalog, WorkBuddyWebModelBadge, WorkBuddyWebProbeSection, WorkBuddyWebStatus } from './status-paths.ts'

export { WORKBUDDY_STATUS_PATH } from './status-paths.ts'
export type { WorkBuddyWebStatus } from './status-paths.ts'

/**
 * How long a fetched credit snapshot is reused.
 *
 * The billing endpoint is a live upstream call: its own timeout is 30s and the
 * international realm tries two candidate paths, so doing it on every card open
 * made the panel sit on "正在读取账号…" for tens of seconds. One snapshot per
 * minute is enough for a card that also offers a manual refresh.
 */
const CREDITS_CACHE_MS = 60_000

/** How long the status route waits for a fresh snapshot before answering without it. */
const CREDITS_WAIT_MS = 5_000

type CreditSnapshot = Awaited<ReturnType<WorkBuddyUpstreamClient['fetchCredits']>>

/**
 * Last successful snapshot per account **and variant**; the entry ages out
 * after {@link CREDITS_CACHE_MS}.
 *
 * The key carries the variant's own status path, not the uid alone: the CN and
 * international products draw their balances from different deployments, and a
 * sign-in that happens to share a uid across the two would otherwise let the
 * first card answer with the other's credits (measured: `dual-routes` served
 * the CN balance on the international route).
 */
const creditCache = new Map<string, { at: number; value: CreditSnapshot }>()

/** Cache key for one account's snapshot within one variant's route. */
function creditCacheKey(deps: WorkBuddyStatusRouteOptions, uid: string): string {
  return `${deps.path ?? WORKBUDDY_STATUS_PATH}\u0000${uid}`
}

/**
 * Resolve to `undefined` after `ms`. A cold billing lookup must not hold the
 * whole panel hostage; the request keeps running and lands in the cache.
 */
function timeoutAfter(ms: number): Promise<undefined> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => { resolve(undefined) }, ms)
    timer.unref()
  })
}

/** Constructor dependencies. */
export interface WorkBuddyStatusRouteOptions {
  store: WorkBuddyCredentialStore
  client: Pick<WorkBuddyUpstreamClient, 'fetchCredits'>
  /** Resolve the current model catalog for free/badge display. */
  models: () => readonly WorkBuddyModelInfo[]
  /**
   * Compact probe state for the card. Optional so the status route keeps
   * working on its own in tests and headless profiles.
   */
  probe?: () => WorkBuddyWebProbeSection
  /**
   * Origin of the currently served model list. Optional so the status route
   * keeps working without one in tests and headless profiles.
   */
  catalog?: () => WorkBuddyWebCatalog | undefined
  /** In-process key authorizing probe control writes. */
  probeKey?: string
  /**
   * In-process key authorizing sign-in writes. Minted separately from
   * {@link WorkBuddyStatusRouteOptions.probeKey} because the two authorize
   * different powers; a signed-out card needs only this one.
   */
  loginKey?: string
  /** International-card preference selecting larger declared context windows. */
  useMaximumContextWindow?: () => boolean
  /** Read the list of disabled model IDs for this variant. */
  disabledModels?: () => readonly string[]
  /**
   * Daily check-in status provider for this variant.
   */
  checkIn?: () => {
    lastDate: string
    lastAt: number
    status: 'claimed' | 'already-claimed' | 'no-campaign' | 'error'
    amount?: number | undefined
    message?: string | undefined
    nextRunAt?: number | undefined
    logs?: readonly {
      id: string
      date: string
      timestamp: number
      status: 'claimed' | 'already-claimed' | 'no-campaign' | 'error'
      amount?: number | undefined
      message?: string | undefined
    }[] | undefined
  } | undefined
  /**
   * Route path to mount. Defaults to the CN variant's path so existing callers
   * and tests keep their behaviour; the international variant passes its own.
   */
  path?: string
}

/** Redact token-like content before it crosses to the browser. */
function safeMessage(error: unknown): string {
  return (error instanceof Error ? error.message : String(error))
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/gu, '[redacted token]')
    .replace(/(\b(?:code|token|refresh_token|access_token)=)[^&\s]+/giu, '$1[redacted]')
    .slice(0, 500)
}

function json(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
  res.end(payload)
}

/**
 * The request must be addressed to the loopback interface, and a
 * browser-attached Origin must be loopback too. The Host check drops
 * DNS-rebinding pages (their Host is the attacker's domain, not loopback);
 * the card's same-origin fetches carry no Origin and pass on Host alone.
 */
function loopbackRequest(req: IncomingMessage): boolean {
  return hostIsLoopback(req.headers.host) && originIsLoopback(req.headers.origin)
}

/**
 * Assemble the card's status document. Sign-in state is read-only; credit is
 * a live billing answer whose failure degrades to `creditsError` rather than
 * failing the whole document.
 */
export async function workBuddyWebStatus(
  deps: WorkBuddyStatusRouteOptions,
): Promise<WorkBuddyWebStatus> {
  const authStatus = await deps.store.status()
  if (authStatus.state !== 'signed-in') {
    // A diagnosable sign-out (a credential for the *other* product) keeps its
    // explanation: falling back to the generic hint would tell the user to sign
    // in when the real fix is to correct a path. The sign-in key rides along so
    // this card can offer the action that resolves the state.
    return {
      status: 'signed-out',
      ...authStatus.reason === undefined ? {} : { reason: authStatus.reason },
      ...deps.loginKey === undefined ? {} : { loginKey: deps.loginKey },
    }
  }
  const status: WorkBuddyWebStatus = {
    status: 'signed-in',
    ...authStatus.nickname === undefined ? {} : { nickname: authStatus.nickname },
    ...authStatus.domain === undefined || authStatus.domain === '' ? {} : { domain: authStatus.domain },
    ...authStatus.region === undefined ? {} : { region: authStatus.region },
    ...authStatus.expiresAtMs === undefined ? {} : { expiresAt: authStatus.expiresAtMs },
    // Both arms carry the key: a signed-in card needs it for sign-out and for
    // switching accounts, and omitting it here made both actions unreachable.
    ...deps.loginKey === undefined ? {} : { loginKey: deps.loginKey },
  }
  // Model facts ride the signed-in document so the card can show rates,
  // promos, and context capacity without touching the Models picker. The rate
  // is normalized here (not in the card) so both halves agree on one display
  // form; the card additionally localizes it.
  //
  // The card receives *every* model, not just the discounted ones: context
  // capacity is exactly the fact a user wants before picking a model, and the
  // models where it matters most (a 200k model beside 1M siblings) are
  // precisely the ones with no promo attached. The discount section filters
  // what it renders.
  const models = deps.models()
  const modelsField: readonly WorkBuddyWebModelBadge[] = models
    .map(model => {
      const rate = normalizeCredits(model.billing?.credits)
      // The lapsed rate and its promotion labels, for a row whose promotion has
      // ended: they travel under the expired note, never as a live price.
      const staleRate = model.billing?.rateUnknown === true ? normalizeCredits(model.billing.credits) : undefined
      const expiredLabels = [...new Set((model.billing?.expiredPromotions ?? []).filter(label => label !== ''))]
      // The largest window the upstream declares for this model, when it
      // declares alternatives; equal to `contextWindow` otherwise, and omitted
      // when the upstream said nothing.
      const supported = model.supportedContextWindows ?? []
      const maxContextWindow = supported.length > 0 ? Math.max(...supported) : undefined
      const defaultContextWindow = model.defaultContextWindow ?? model.contextWindow
      return {
        id: model.id,
        name: model.name,
        ...model.billing?.free === true ? { free: true as const } : {},
        ...model.billing?.badges !== undefined && model.billing.badges.length > 0 ? { badges: model.billing.badges } : {},
        // The rate is deliberately withheld for a row whose price cannot be
        // vouched for (a promotion that has ended but is still baked into the
        // cached row): the card then says the price needs a refresh instead of
        // repeating a stale figure or implying the model is free. What it DOES
        // get is the lapsed figure under an "expired" note — the user needs to
        // know the price was x0.00 and that the promotion ran out, which is
        // strictly more useful than a bare "unavailable".
        ...model.billing?.rateUnknown === true
          ? {
              rateUnknown: true as const,
              ...staleRate === undefined ? {} : { expiredCredits: staleRate },
              ...expiredLabels.length === 0 ? {} : { expiredPromotions: expiredLabels },
            }
          : rate === undefined ? {} : { credits: rate },
        // Verbatim from the upstream catalog; omitted when it said nothing.
        ...typeof model.contextWindow === 'number' && model.contextWindow > 0
          ? { contextWindow: model.contextWindow }
          : {},
        ...typeof defaultContextWindow === 'number' && defaultContextWindow > 0 && defaultContextWindow < model.contextWindow
          ? { defaultContextWindow }
          : {},
        ...maxContextWindow === undefined || maxContextWindow <= defaultContextWindow
          ? {}
          : { maxContextWindow },
        ...typeof model.maxInputTokens === 'number' && model.maxInputTokens > 0
          ? { maxInputTokens: model.maxInputTokens }
          : {},
      }
    })
  // Catalog provenance rides the document even when the model list is empty:
  // "no models" is precisely the case a user needs explained, and it is the
  // only way to tell a hidden group from a failed fetch.
  const catalog = deps.catalog?.()
  const withCatalog: WorkBuddyWebStatus = catalog === undefined ? status : { ...status, catalog }
  const statusWithModels: WorkBuddyWebStatus = modelsField.length > 0
    ? { ...withCatalog, models: modelsField }
    : withCatalog
  // Probe state rides the signed-in document so the card can render the
  // consent switches and results without a second request. The control key
  // travels with it: this response already passed the loopback guard, and the
  // key authorizes only probe control, never credentials or completions.
  const checkInRecord = deps.checkIn?.()
  const probed: WorkBuddyWebStatus = {
    ...statusWithModels,
    ...deps.probe === undefined ? {} : { probe: deps.probe() },
    ...deps.probeKey === undefined ? {} : { probeKey: deps.probeKey },
    ...deps.useMaximumContextWindow === undefined ? {} : { useMaximumContextWindow: deps.useMaximumContextWindow() },
    ...deps.disabledModels === undefined ? {} : { disabledModels: deps.disabledModels() },
    ...checkInRecord === undefined ? {} : { checkIn: checkInRecord },
  }
  try {
    const credential = await deps.store.current()
    if (credential !== undefined) {
      const cacheKey = creditCacheKey(deps, credential.uid)
      const cached = creditCache.get(cacheKey)
      if (cached !== undefined && Date.now() - cached.at < CREDITS_CACHE_MS) {
        // `unlimited` and `cycleResetTime` ride along as-is: the card must see
        // "no cap" as its own state, and the fetch only sets them when the
        // upstream actually reported them.
        return { ...probed, credits: cached.value }
      }
      // A cold or expired lookup answers within CREDITS_WAIT_MS: the upstream
      // call keeps running and lands in the cache, so the next open is instant
      // instead of blocking on the full 30s billing timeout again.
      const pending = deps.client.fetchCredits(credential).then((value) => {
        creditCache.set(cacheKey, { at: Date.now(), value })
        return value
      })
      const credits = await Promise.race([pending, timeoutAfter(CREDITS_WAIT_MS)])
      // Timed out: answer without the credit fields rather than reporting a
      // failure the user cannot act on. The in-flight request still fills the
      // cache, so reopening the card is instant.
      return credits === undefined ? probed : { ...probed, credits }
    }
  } catch (error: unknown) {
    return { ...probed, creditsError: safeMessage(error) }
  }
  return probed
}

/** The status route's request handler, extracted so tests can mount it on a bare server. */
export function workBuddyStatusHandler(
  deps: WorkBuddyStatusRouteOptions,
): (req: IncomingMessage, res: ServerResponse) => Promise<void> {
  return async (req, res) => {
    if (req.method !== 'GET') {
      json(res, 405, { error: 'method not allowed' })
      return
    }
    if (!loopbackRequest(req)) {
      json(res, 403, { error: 'request-not-trusted' })
      return
    }
    try {
      json(res, 200, await workBuddyWebStatus(deps))
    } catch (error: unknown) {
      json(res, 500, { error: safeMessage(error) })
    }
  }
}

/** Mount the GET status route on an optional webServer context. */
export function registerWorkBuddyStatusRoute(ctx: Context, deps: WorkBuddyStatusRouteOptions): void {
  const path = deps.path ?? WORKBUDDY_STATUS_PATH
  ctx.effect(() => {
    const dispose = ctx.webServer.register({
      kind: 'exact',
      path,
      handler: workBuddyStatusHandler(deps),
    })
    return () => {
      dispose()
    }
  }, 'dsh-workbuddy-connect: Web status route')
}
