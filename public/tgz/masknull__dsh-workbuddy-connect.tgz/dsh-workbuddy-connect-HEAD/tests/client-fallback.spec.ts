/* eslint-disable @typescript-eslint/no-explicit-any */
import { describe, expect, it, vi } from 'vitest'

/**
 * The client entry degrades a slot-API breaking change (the rc.6→rc.7
 * `id`→`key` rename that caused the red "Failed to load plugins" banner)
 * to a console.error, so the host provider keeps working without a banner.
 *
 * We cannot import the real client entry (it pulls browser-only DSH client
 * packages); instead we replicate the exact try/catch shape from
 * `src/client/index.tsx` and assert it swallows a simulated throw.
 *
 * DRIFT WARNING: the `apply()` below is a manual mirror of the real
 * `apply()` in `src/client/index.tsx` (see the NOTE on that function). It is
 * NOT the product code, so this test only proves the fallback idea works — it
 * cannot detect a regression in the real entry. If you change the real
 * `apply()`'s guarded body or its `console.error` message, update the mirror
 * here too; a mismatch between the two is invisible to this test.
 */
describe('client card fallback', () => {
  it('swallows a slot registration failure instead of throwing', () => {
    const errors: unknown[] = []
    const spy = vi.spyOn(console, 'error').mockImplementation((...args: unknown[]) => { errors.push(args) })

    // Simulate a DSH loader that throws on ctx.slots.inject (the rc.7
    // "requires options.id" error). Loose `any` on purpose: we only test
    // the try/catch boundary, not the DSH client API types.
    const fakeCtx: any = {
      effect: () => {},
      locale: { register: () => () => {}, bind: () => () => '' },
      slots: {
        inject: () => { throw new Error('slot "settings.section" requires options.id') },
        register: () => () => {},
      },
      // The real ctx.inject runs the callback once the named services exist;
      // the fake always runs it, so an unguarded inner throw is real.
      inject: (_deps: string[], cb: (scope: any) => void) => {
        cb({ get: () => undefined, slots: fakeCtx.slots })
      },
    }

    // Mirror of src/client/index.tsx apply() body, in the real order: the
    // shared 《插件设置》 block registration and the plugin-manager seat each
    // carry their own guarded boundary; the composer seat is unguarded, so its
    // failure lands on the outer catch.
    function apply(ctx: any): void {
      try {
        const namespace = 'settings.workbuddy'
        ctx.effect(() => ctx.locale.register(namespace, { zh: {}, en: {} }), 'dsh-workbuddy-connect: settings copy')
        const t = ctx.locale.bind(namespace)

        // 1. The shared 《插件设置》 block: the container and this plugin's card.
        try {
          ctx.slots.inject('settings.section', () => {
            throw new Error('not reached')
          })
        } catch (error: unknown) {
          console.error('[dsh-workbuddy-connect] plugin settings block registration failed (host provider unaffected):', error)
        }

        // 2. This bundle's page in the sidebar's Plugins panel: the same card,
        // registered under the package name, opened expanded there.
        try {
          ctx.slots.inject('plugins.bundle.config', () => {
            throw new Error('not reached')
          })
        } catch (error: unknown) {
          console.error('[dsh-workbuddy-connect] plugin manager page registration failed (host provider unaffected):', error)
        }
        void t

        ctx.inject(['modelDirectories'], (scope: any) => {
          scope.slots.inject('conversation.input.right', () => {
            throw new Error('not reached')
          })
        })
      } catch (error: unknown) {
        console.error('[dsh-workbuddy-connect] client card failed to load (host provider unaffected):', error)
      }
    }

    // Must not throw — the whole point of the fallback.
    expect(() => apply(fakeCtx)).not.toThrow()

    // Every guarded boundary reported itself, and the unguarded composer seat
    // landed on the outer catch: the host provider keeps serving models.
    expect(errors).toHaveLength(3)
    expect(String(errors[0])).toContain('plugin settings block registration failed')
    expect(String(errors[1])).toContain('plugin manager page registration failed')
    expect(String(errors[2])).toContain('client card failed to load')
    expect(String(errors[2])).toContain('requires options.id')

    spy.mockRestore()
  })
})
