import test from "node:test";
import assert from "node:assert/strict";
import { summarizeSession, exportGraph, extractMessages } from "../lib/extractor.js";

const snapshot = {
  sessionId: "s1",
  nodes: [
    { kind: "user", seq: 1, time: 1, content: [{ type: "text", text: "帮我开发一个 DSH 插件，支持导出 Mermaid，并整理待办。" }] },
    { kind: "assistant", seq: 2, time: 2, turn: 1, step: 1, blocks: [{ kind: "reasoning", text: "调试思考不要出现在结果" }, { kind: "text", text: "尝试运行时报错：stack trace\n结论：已完成插件主体。\n- 支持 Markdown / Mermaid。\n待办：安装到本机测试。" }] },
  ],
};

test("extractMessages omits reasoning by default", () => {
  const messages = extractMessages(snapshot);
  assert.equal(messages.length, 2);
  assert.equal(messages.some(m => m.text.includes("调试思考")), false);
});

test("concise mode keeps conclusions and todos", () => {
  const tree = summarizeSession(snapshot, "concise");
  assert.equal(tree.children.length, 2);
  assert.match(exportGraph(tree, "markdown"), /最终结论/);
  assert.match(exportGraph(tree, "todo"), /安装到本机测试/);
});

test("exports mermaid and plantuml", () => {
  const tree = summarizeSession(snapshot, "default");
  assert.match(exportGraph(tree, "mermaid"), /^mindmap/);
  assert.match(exportGraph(tree, "plantuml"), /^@startmindmap/);
});
