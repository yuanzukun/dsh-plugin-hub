import type { IncomingMessage, ServerResponse } from 'node:http'
import type { ChatGPTHelmRuntime } from './runtime.js'

export const HELM_UI_STATUS_PATH = '/api/dsh-with-chatgpt/status'
export const HELM_MCP_SERVERS_PATH = '/api/dsh-with-chatgpt/mcp-servers'
export const HELM_SESSION_API_PATH = '/api/dsh-with-chatgpt/sessions'

function json(res: ServerResponse, code: number, value: unknown): void {
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  })
  res.end(JSON.stringify(value))
}

function writeSseEvent(res: ServerResponse, event: string, value: unknown): void {
  if (res.destroyed || res.writableEnded) return
  res.write(`event: ${event}
data: ${JSON.stringify(value)}

`)
}

function streamWorkHistoryChanges(runtime: ChatGPTHelmRuntime, req: IncomingMessage, res: ServerResponse): void {
  res.writeHead(200, {
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-store',
    connection: 'keep-alive',
    'x-accel-buffering': 'no',
  })
  res.write('retry: 1000\n\n')
  const unsubscribe = runtime.subscribeWorkHistoryChanges(() => writeSseEvent(res, 'changed', {}))
  let cleaned = false
  const cleanup = () => {
    if (cleaned) return
    cleaned = true
    unsubscribe()
  }
  req.once('aborted', cleanup)
  res.once('close', cleanup)
}

function streamSessionTimeline(runtime: ChatGPTHelmRuntime, req: IncomingMessage, res: ServerResponse, sessionId: string, afterSequence: number): void {
  res.writeHead(200, {
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-store',
    connection: 'keep-alive',
    'x-accel-buffering': 'no',
  })
  res.write('retry: 1000\n\n')
  const unsubscribe = runtime.subscribeSessionTimeline(sessionId, afterSequence, {
    onUpdates: (updates) => writeSseEvent(res, 'timeline', { updates }),
    onError: (error) => writeSseEvent(res, 'timeline-error', { error: error.message }),
  })
  let cleaned = false
  const cleanup = () => {
    if (cleaned) return
    cleaned = true
    unsubscribe()
  }
  req.once('aborted', cleanup)
  res.once('close', cleanup)
}

async function readJson(req: IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
  if (!chunks.length) return {}
  const value = JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {}
}

function sessionRouteParts(req: IncomingMessage): string[] {
  const pathname = new URL(req.url ?? '/', 'http://127.0.0.1').pathname
  if (pathname === HELM_SESSION_API_PATH) return []
  if (!pathname.startsWith(`${HELM_SESSION_API_PATH}/`)) return ['__invalid__']
  return pathname.slice(HELM_SESSION_API_PATH.length + 1).split('/').filter(Boolean).map((part) => decodeURIComponent(part))
}

export async function handleHelmMcpServersRequest(runtime: ChatGPTHelmRuntime, req: IncomingMessage, res: ServerResponse): Promise<void> {
  try {
    if (req.method === 'GET') return json(res, 200, await runtime.listMcpServers())
    if (req.method === 'POST') {
      const body = await readJson(req)
      if (body.action === 'scan') return json(res, 200, await runtime.scanMcpServers())
      if (body.action === 'import') {
        if (typeof body.id !== 'string' || !/^(?:codex|claude):[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}$/.test(body.id)) throw new Error('invalid MCP candidate id')
        return json(res, 200, await runtime.importMcpServer(body.id))
      }
      if (body.action === 'configureEnv') {
        if (typeof body.id !== 'string' || !/^mcp:[a-f0-9-]{36}$/.test(body.id)
          || !body.values || typeof body.values !== 'object' || Array.isArray(body.values)) throw new Error('invalid MCP environment configuration')
        return json(res, 200, await runtime.configureMcpServerEnv(body.id, body.values as Record<string, string>))
      }
      if (body.action === 'configureHeaders') {
        if (typeof body.id !== 'string' || !/^mcp:[a-f0-9-]{36}$/.test(body.id)
          || !body.headers || typeof body.headers !== 'object' || Array.isArray(body.headers)) throw new Error('Invalid MCP Headers')
        return json(res, 200, await runtime.configureMcpHttpHeaders(body.id, body.headers as Record<string, string>))
      }
      if (body.action === 'configureOAuth') {
        if (typeof body.id !== 'string' || !/^mcp:[a-f0-9-]{36}$/.test(body.id) || !body.options || typeof body.options !== 'object' || Array.isArray(body.options)) throw new Error('Invalid OAuth configuration')
        return json(res, 200, await runtime.configureMcpOAuth(body.id, body.options as import('../app/adapter.js').OAuthClientSetup))
      }
      if (body.action === 'authorize') {
        if (typeof body.id !== 'string' || !/^mcp:[a-f0-9-]{36}$/.test(body.id)) throw new Error('invalid MCP authorization id')
        return json(res, 200, await runtime.beginMcpServerOAuth(body.id))
      }
      if (body.action === 'enable') {
        if (typeof body.id !== 'string' || !/^mcp:[a-f0-9-]{36}$/.test(body.id) || typeof body.enabled !== 'boolean') throw new Error('invalid Helm MCP update')
        return json(res, 200, await runtime.setMcpServerEnabled(body.id, body.enabled))
      }
      throw new Error('unknown MCP management action')
    }
    res.setHeader('allow', 'GET, POST')
    return json(res, 405, { error: 'method not allowed' })
  } catch (error) {
    return json(res, 400, { error: error instanceof Error ? error.message : String(error) })
  }
}

export async function handleHelmStatusRequest(runtime: ChatGPTHelmRuntime, req: IncomingMessage, res: ServerResponse): Promise<void> {
  if (req.method === 'GET') {
    try {
      json(res, 200, await runtime.getStatus())
    } catch (error) {
      json(res, 503, {
        error: error instanceof Error ? error.message : String(error),
        code: 'status_unavailable',
        retryable: true,
      })
    }
    return
  }
  if (req.method === 'POST') {
    try {
      const body = await readJson(req)
      if (body.action === 'installDependency') {
        if (body.dependency !== 'serena' && body.dependency !== 'tunnelClient') throw new Error('dependency must be serena or tunnelClient')
        json(res, 200, await runtime.installDependency(body.dependency))
        return
      }
      if (body.action === 'configureTunnel') {
        const input = body.input
        if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('input must be a Tunnel setup object')
        const values = input as Record<string, unknown>
        if (typeof values.tunnelId !== 'string' || !values.tunnelId.trim()) throw new Error('Tunnel ID is required')
        if (values.organizationId !== undefined && typeof values.organizationId !== 'string') throw new Error('Organization ID must be a string')
        if (values.apiKey !== undefined && typeof values.apiKey !== 'string') throw new Error('Runtime API Key must be a string')
        if (values.proxyUrl !== undefined && typeof values.proxyUrl !== 'string') throw new Error('Tunnel proxy URL must be a string')
        json(res, 200, await runtime.configureTunnel({
          tunnelId: values.tunnelId,
          ...(typeof values.organizationId === 'string' ? { organizationId: values.organizationId } : {}),
          ...(typeof values.apiKey === 'string' ? { apiKey: values.apiKey } : {}),
          ...(typeof values.proxyUrl === 'string' ? { proxyUrl: values.proxyUrl } : {}),
        }))
        return
      }
      if (body.target === 'nativeAgent') {
        if (body.agent !== 'codex' && body.agent !== 'claude') throw new Error('agent must be codex or claude')
        if (typeof body.enabled !== 'boolean') throw new Error('enabled must be boolean')
        json(res, 200, await runtime.setNativeAgentEnabled(body.agent, body.enabled))
        return
      }
      if (body.target === 'externalAgentLsp') {
        if (typeof body.enabled !== 'boolean') throw new Error('enabled must be a boolean')
        json(res, 200, await runtime.setExternalAgentLspEnabled(body.enabled))
        return
      }
      if (body.target === 'externalUserAccess') {
        if (body.capability !== 'enabled' && body.capability !== 'mutations' && body.capability !== 'delegation') throw new Error('capability must be enabled, mutations, or delegation')
        if (typeof body.enabled !== 'boolean') throw new Error('enabled must be a boolean')
        json(res, 200, await runtime.setExternalUserAccess({ [body.capability]: body.enabled }))
        return
      }
      if (body.target !== 'core' && body.target !== 'localMcp') throw new Error('target must be core, localMcp, or externalAgentLsp')
      if (typeof body.enabled !== 'boolean') throw new Error('enabled must be a boolean')
      json(res, 200, body.target === 'core' ? await runtime.setCoreEnabled(body.enabled) : await runtime.setLocalMcpEnabled(body.enabled))
    } catch (error) {
      json(res, 400, { error: error instanceof Error ? error.message : String(error) })
    }
    return
  }
  res.setHeader('allow', 'GET, POST')
  json(res, 405, { error: 'method not allowed' })
}

export async function handleHelmSessionRequest(runtime: ChatGPTHelmRuntime, req: IncomingMessage, res: ServerResponse): Promise<void> {
  try {
    const parts = sessionRouteParts(req)
    if (parts[0] === '__invalid__') return json(res, 404, { error: 'not found' })
    if (parts.length === 0) {
      if (req.method === 'GET') {
        const url = new URL(req.url ?? '/', 'http://127.0.0.1')
        const cursor = url.searchParams.get('cursor') ?? undefined
        const rawLimit = url.searchParams.get('limit')
        const limit = rawLimit === null ? undefined : Number.parseInt(rawLimit, 10)
        if (rawLimit !== null && (!Number.isInteger(limit) || limit! < 1 || limit! > 50)) return json(res, 400, { error: 'limit must be an integer from 1 to 50' })
        return json(res, 200, await runtime.getSessionPage(cursor, limit))
      }
      res.setHeader('allow', 'GET')
      return json(res, 405, { error: 'method not allowed' })
    }
    if (req.method !== 'GET') {
      res.setHeader('allow', 'GET')
      return json(res, 405, { error: 'method not allowed' })
    }
    if (parts.length === 1 && parts[0] === 'stream') {
      streamWorkHistoryChanges(runtime, req, res)
      return
    }
    const [sessionId, child, grandchild] = parts
    if (!sessionId || parts.length > 3) return json(res, 404, { error: 'not found' })
    if (!child) {
      const session = await runtime.getSession(sessionId)
      return session ? json(res, 200, { session }) : json(res, 404, { error: 'ChatGPT session not found' })
    }
    if (child === 'timeline' && grandchild === 'stream') {
      const session = await runtime.getSession(sessionId)
      if (!session) return json(res, 404, { error: 'ChatGPT session not found' })
      const rawAfterSequence = new URL(req.url ?? '/', 'http://127.0.0.1').searchParams.get('afterSequence')
      const afterSequence = rawAfterSequence === null ? 0 : Number.parseInt(rawAfterSequence, 10)
      if (!Number.isInteger(afterSequence) || afterSequence < 0) return json(res, 400, { error: 'afterSequence must be a non-negative integer' })
      streamSessionTimeline(runtime, req, res, sessionId, afterSequence)
      return
    }
    if (grandchild) return json(res, 404, { error: 'not found' })
    if (child === 'timeline') return json(res, 200, { timeline: await runtime.getSessionTimeline(sessionId) })
    if (child === 'activity') return json(res, 200, { activity: await runtime.getSessionActivity(sessionId) })
    if (child === 'delegations') return json(res, 200, { delegations: await runtime.getSessionDelegations(sessionId) })
    return json(res, 404, { error: 'not found' })
  } catch (error) {
    return json(res, 500, { error: error instanceof Error ? error.message : String(error) })
  }
}

export async function handleHelmApiRequest(runtime: ChatGPTHelmRuntime, req: IncomingMessage, res: ServerResponse): Promise<boolean> {
  const pathname = new URL(req.url ?? '/', 'http://127.0.0.1').pathname
  if (pathname === HELM_UI_STATUS_PATH) {
    await handleHelmStatusRequest(runtime, req, res)
    return true
  }
  if (pathname === HELM_MCP_SERVERS_PATH) {
    await handleHelmMcpServersRequest(runtime, req, res)
    return true
  }
  if (pathname === HELM_SESSION_API_PATH || pathname.startsWith(`${HELM_SESSION_API_PATH}/`)) {
    await handleHelmSessionRequest(runtime, req, res)
    return true
  }
  return false
}
