<div align="center">
  <h1>dsh-improved-inline-edit</h1>
  <p><strong>当你的DSH正在工作时，你可以不用停止对话就可以再次提出要求</strong></p>

  [![GitHub stars](https://img.shields.io/github/stars/xiaosurongjia/dsh-improved-inline-edit?style=for-the-badge&logo=github)](https://github.com/xiaosurongjia/dsh-improved-inline-edit/stargazers) [![GitHub license](https://img.shields.io/badge/license-MIT-blue?style=for-the-badge)](LICENSE) [![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen?style=for-the-badge)](https://github.com/xiaosurongjia/dsh-improved-inline-edit/pulls)

  **简体中文（默认）** | [English](README.en.md)
</div>

---

## 目录

- [为什么做这个？](#为什么做这个)
- [界面预览](#界面预览)
- [Deep 短语池](#deep-短语池)
- [特性](#特性)
- [快速开始](#快速开始)
  - [安装](#安装)
  - [使用](#使用)
- [更新内容](#更新内容)
- [技术实现](#技术实现)
- [贡献](#贡献)
- [许可证](#许可证)

---

## 为什么做这个？

在 DSH使用过程中，你是否经历过这种时刻：

> _「等等，方向不对！」「先别动那个，先看看这个！」「这部分改一下再继续！」_

然后只能：
- 干等 agent 跑完 —— 浪费时间
- 粗暴停止对话 —— 丢失进度和上下文

**dsh-improved-inline-edit** 让「中断」和「继续」不再互斥：agent 运行时，composer 上方弹出一条「修改要求」输入条，你随时输入要求发送，消息会通过官方 `agent.steer()` 机制无缝注入到 agent 的下一个决策步骤。

| 现有方案的问题 | 本插件的解决方案 |
|:---|:---|
| 打断 = 丢失上下文 | 通过 `agent.steer()` 无缝注入，上下文完整保留 |
| 只能等任务跑完 | 随时插话，agent 下一步就响应 |
| 界面杂乱 | 仅在运行时弹出，运行结束自动消失 |

---

## 界面预览

**2026.8.29**

**新增撤回功能：** 在消息气泡旁增加「撤回」按钮，未被读取时可撤回，已读取则变灰。

![撤回功能预览](assets/preview-recall.png)

**2026.8.29**

**新增注入引导前缀功能（可选）：** 开启时发送的消息格式：【修改要求｜请基于当前任务继续执行，不要改变任务目标】 + 你的内容

![注入引导前缀预览](assets/preview-prefix.png)

**2026.8.28**

![dsh-improved-inline-edit 界面预览](assets/preview.png)

**演示视频（B 站）：** [点击观看 dsh-improved-inline-edit 使用演示](https://www.bilibili.com/video/BV1D4tN6TEGT)

---

## Deep 短语池

运行中的状态文案来自一个 **100 条的 Deep 短语池**（借鉴 [dsh-deep-verbs](https://github.com/Winter-And-You-Gone/dsh-deep-verbs) 项目并自由扩充）。洗牌袋抽取保证短期不重复，agent 每推进一步/调用一次工具就轮换下一条；点击状态文案可在中/英之间切换。

| 英文 | 中文 | 含义 |
|:---|:---|:---|
| Deep diving... | 深潜中… | 潜水 |
| Deep seeking... | 深度求索中… | deep seek 动词化 |
| Deep delving... | 刨根问底中… | delve into，深入探究 |
| Deep surfacing... | 喷涂彩虹中… | 潜完上浮换气 |
| Deep breaching... | 跃出海面中… | 鲸跃出水（whale logo 致敬） |
| Deep bubbling... | 海底冒泡中… | 在深海冒泡泡 |
| Deep singing... | 引吭高歌中… | 鲸歌 |
| Deep fishing... | 摸鱼中… | 深度摸鱼 |
| Deep sinking... | 沉底中… | 沉下去慢慢想 |
| Deep sleeping... | 呼呼大睡中… | 睡着了（长思考自嘲） |
| Deep napping... | 偷偷打盹中… | 打盹中（长思考自嘲） |
| Deep dreaming... | 白日做梦中… | 做梦中 |
| Deep cooking... | 小火慢炖中… | let me cook |
| Deep baking... | 烘焙中… | 烘焙 |
| Deep brewing... | 酿造中… | 酿造 |
| Deep caramelizing... | 熬糖色中… | 熬糖色 |
| Deep fermenting... | 发酵中… | 发酵 |
| Deep flambéing... | 喷火炙烤中… | 喷火炙烤 |
| Deep frosting... | 抹奶油中… | 抹奶油 |
| Deep garnishing... | 摆盘中… | 摆盘 |
| Deep julienning... | 切丝中… | 切丝 |
| Deep kneading... | 揉面中… | 揉面 |
| Deep leavening... | 发面中… | 发面 |
| Deep marinating... | 腌制入味中… | 腌制入味 |
| Deep proofing... | 醒面中… | 醒面（面团休息=思考） |
| Deep sautéing... | 爆炒中… | 爆炒 |
| Deep seasoning... | 调味中… | 调味 |
| Deep simmering... | 咕嘟咕嘟中… | 咕嘟冒泡 |
| Deep stewing... | 文火炖煮中… | 文火炖煮 |
| Deep tempering... | 回火中… | 回火 |
| Deep whisking... | 打发中… | 打发 |
| Deep zesting... | 削皮中… | 削皮 |
| Deep spelunking... | 洞窟探秘中… | 探洞 |
| Deep burrowing... | 挖洞中… | 往地底钻 |
| Deep ruminating... | 反刍中… | 反刍式思考 |
| Deep incubating... | 孵化中… | 孵蛋等结果 |
| Deep percolating... | 渗滤中… | 咖啡渗滤 |
| Deep honking... | 哔哔鸣笛中… | 鸣笛 |
| Deep noodling... | 瞎鼓捣中… | 瞎鼓捣 |
| Deep doodling... | 涂鸦中… | 涂鸦开小差 |
| Deep waddling... | 摇摇晃晃中… | 摇摇晃晃 |
| Deep frolicking... | 撒欢中… | 撒欢 |
| Deep moseying... | 溜达中… | 慢悠悠溜达 |
| Deep moonwalking... | 太空步中… | 太空步 |
| Deep photosynthesizing... | 光合作用中… | 光合作用发呆 |
| Deep precipitating... | 沉淀中… | 沉淀 |
| Deep combobulating... | 拼拼凑凑中… | 拼拼凑凑 |
| Deep recombobulating... | 重组中… | 重组 |
| Deep levitating... | 悬空冥想中… | 悬空冥想 |
| Deep metamorphosing... | 蜕变中… | 蜕变 |
| Deep zigzagging... | 蛇皮走位中… | 蛇皮走位 |
| Deep boondoggling... | 瞎忙活中… | 瞎忙活 |
| Deep gallivanting... | 到处浪中… | 到处浪 |
| Deep crafting... | 打磨中… | 打磨 |
| Deep forging... | 锻造中… | 锻造 |
| Deep deliberating... | 斟酌中… | 斟酌 |
| Deep inferring... | 推演中… | 推演 |
| Deep puzzling... | 解谜中… | 解谜 |
| Deep reticulating... | 编织中… | 编织 |
| Deep wandering... | 游弋中… | 游弋 |
| Deep meandering... | 漫步中… | 漫步 |
| Deep orbiting... | 绕飞中… | 绕飞 |
| Deep cascading... | 飞瀑中… | 飞瀑 |
| Deep churning... | 翻腾中… | 翻腾 |
| Deep billowing... | 鼓涌中… | 鼓涌 |
| Deep swirling... | 回旋中… | 回旋 |
| Deep undulating... | 起伏中… | 起伏 |
| Deep fluttering... | 扑棱中… | 扑棱 |
| Deep swooping... | 俯冲中… | 俯冲 |
| Deep shimmying... | 扭摆中… | 扭摆 |
| Deep grooving... | 踩点中… | 踩点 |
| Deep lollygagging... | 磨洋工中… | 磨洋工 |
| Deep sprouting... | 冒芽中… | 冒芽 |
| Deep floating... | 漂浮中… | 漂浮 |
| Deep drifting... | 漂移中… | 漂移 |
| Deep soaring... | 翱翔中… | 翱翔 |
| Deep cruising... | 巡航中… | 巡航 |
| Deep excavating... | 挖掘中… | 挖掘 |
| Deep mapping... | 测绘中… | 测绘 |
| Deep decoding... | 解码中… | 解码 |
| Deep encoding... | 编码中… | 编码 |
| Deep compiling... | 编译中… | 编译 |
| Deep bundling... | 打包中… | 打包 |
| Deep testing... | 测试中… | 测试 |
| Deep refactoring... | 重构中… | 重构 |
| Deep calculating... | 心算中… | 心算 |
| Deep sketching... | 起草中… | 起草 |
| Deep outlining... | 列大纲中… | 列大纲 |
| Deep jamming... | 即兴演奏中… | 即兴演奏 |
| Deep riffing... | 炫技中… | 炫技 |
| Deep brainstorming... | 头脑风暴中… | 头脑风暴 |
| Deep hypothesizing... | 假想中… | 假想 |
| Deep probing... | 探测中… | 探测 |
| Deep scanning... | 扫描中… | 扫描 |
| Deep synthesizing... | 综合提炼中… | 综合提炼 |
| Deep prioritizing... | 排优先级中… | 排优先级 |
| Deep optimizing... | 优化中… | 优化 |
| Deep streamlining... | 精简中… | 精简 |
| Deep hardening... | 加固中… | 加固 |
| Deep shipping... | 发货中… | 发货 |

---

## 特性

| 特性 | 说明 |
|:---|:---|
| **真正的实时打断** | 不是发一条新消息，而是直接注入到**运行中 agent 的下一步决策**（`agent.steer()` 官方机制）|
| **拖拽 / 粘贴附件** | 图片、文本/代码文件直接拖进输入条或 Ctrl+V 粘贴，和文字作为**同一条**插话发出；图片走 DSH 官方附件管线，发送前检查模型视觉能力 |
| **常用短语库** | 当前草稿可一键存为常用短语，下次点一下插入（最多 20 条，存本地）|
| **短语池自定义** | 100 条 Deep 短语池可编辑、导入/导出 JSON、一键恢复默认 |
| **撤回并回填** | 未被 agent 读取的消息可撤回；撤回成功把原文自动放回输入框，改完再发 |
| **流动渐变文案** | Deep 短语改为「深海蓝→紫→青」流动渐变，4 秒一轮始终流动（系统关了「动画效果」也照常流）|
| **仅运行中显示** | 输入条只在 agent 运行时弹出；运行结束自动消失，**界面零干扰** |
| **输入框自动换行** | textarea 随内容自动增高（上限 140px）；Enter 发送 / Shift+Enter 换行 / 中文输入法选字时不发送 |
| **100 条 Deep 短语池** | 运行状态文案随 agent 活动轮换，点击可**中英切换** |
| **完美视觉对齐** | 与底部 composer 同宽、左对齐，三层界面整齐一致 |
| **零侵入** | 不改任何 `@deepseek-ai/dsh-*` 源码，卸载干净 |

---

## 快速开始

### 安装

即使没有安装过 DSH，也可以按照下面步骤完成。

**1. 安装 Node.js（LTS）**

打开 [Node.js 官网](https://nodejs.org)，下载并安装 LTS 版本，然后关闭并重新打开终端。macOS 使用「终端」，Windows 使用 PowerShell。

**2. 安装 DSH 和 pnpm**

```bash
npm install --global pnpm @deepseek-ai/dsh
```

**3. 确认 DSH 已安装**

```bash
dsh --version
```

**4. 安装本插件**

```bash
# 在本插件仓库目录下运行（会自动探测 profile：desktop 优先，否则 web）
.\install.ps1

# 或者手动指定插件源码目录与目标 profile 目录
.\install.ps1 -PluginSource <插件目录> -ProfileDir <你的 profile 目录>
```

安装脚本会依次完成：

1. **Junction 链接**：把插件包链接到 profile 的 `node_modules`（与其他 dsh 插件同一约定，省空间；无 Junction 权限时自动退化为复制）
2. **注册 patch**：在 profile 的 `cordis.patch.yml` 里追加一行 `insert`，声明插件 ID 与名称
3. **校验解析**：确认 `exports['./client']` 能被 DSH 客户端模块系统解析

> 安装完成后需要**完全重启 DSH**（结束进程，不是关窗口），然后刷新页面。若 DSH 自带窗口，重启即可。

**5. 启动 DSH Web**

```bash
dsh web
```

保持终端窗口开启。浏览器通常会自动打开；如果没有，请打开终端中显示的 http://127.0.0.1:端口号。

**如果重新打开终端后仍提示 `dsh: command not found`，请改用：**

```bash
npx @deepseek-ai/dsh web
```

> 提示：若你同时想要插件市场（marketplace），也可以先运行 `dsh plugin --profile web add @springbrand/dsh-plugin-marketplace` 来安装市场插件，再从市场里安装其他插件。

### 使用

1. 让 agent 跑起来（发一条消息）
2. composer 上方出现「修改要求」输入条
3. 输入你的要求（支持多行），按 **Enter** 或点 **➤** 发送
4. agent 会在下一步决策时带上你的要求继续执行
5. **带图 / 带文件**：把图片或文本文件直接拖进输入条，或在输入框里 Ctrl+V 粘贴；出现缩略图/文件条后按 Enter，和文字一起作为同一条插话发出去（图片需要当前模型支持视觉）
6. **常用短语 / 短语池**：点左边的 ⚡ 打开面板 —— 可把当前草稿存为常用短语、点一下插入；同一面板里能编辑 100 条短语池、导入/导出 JSON、恢复默认
7. **发错了**：气泡旁的「撤回 · Ns」可把还没被读取的消息撤回；撤回成功后原文会自动回到输入框

> 附件功能需要 host 半部重启一次 DSH 才生效；只刷新页面时文字插话照旧可用，拖入附件会提示先重启。

---

## 更新内容

> 按时间与版本号倒序排列（最新的在最上面）。

v4.0

- 适配 DSH `0.2.1-rc.2`：客户端模块系统、`conversation.input.dock` 槽位、`agent.steer()`、`inbox` 撤回全部沿用官方接口；文字插话链路已在 0.2.1-rc.2 上实测可用，附件链路按官方 prompt 准入流程实现（需重启 DSH 生效）。
- 新增：**拖拽 / 粘贴附件** —— 图片与文本/代码文件可直接拖进输入条，和文字作为同一条插话发出。图片走 DSH 官方附件管线（`ctx.attachments.admitPromptContent`），发送前检查当前模型是否支持视觉；文本文件以附件引用发出（模型可拿到文件名、字节数与只读路径）。
- 新增：**常用短语库** —— 当前草稿一键存为常用短语，点一下插入，最多 20 条，存本地。
- 新增：**短语池自定义** —— 100 条 Deep 短语池可编辑、导入/导出 JSON、恢复默认（中英条数必须一致）。
- 新增：**撤回回填** —— 撤回成功后把原文自动放回输入框。
- 改进：Deep 短语改为「深海蓝→紫→青」的流动渐变文字（4 秒一轮，始终流动；不随系统「减少动态效果」停掉）。
- 改进：去掉运行中套在输入条外圈的黑色描边（DSH 0.2.x 把 `brand-primary` 换成中性色，旧代码会描出黑边）；保留 4% 淡灰细边。
- 改进：撤回按钮显示「已等待 N 秒」，消息被读取后自动变灰。
- 修复：中文输入法选词按 Enter 会把消息提前发出去 —— 现在 Enter 发送 / Shift+Enter 换行 / 输入法组字时不发送。
- 修复：DOM 每次变动都请求一次 `/pending` 的高频轮询 —— 改为 250ms 防抖 + 2s 定时。
- 修复：大请求体跨 chunk 拼接导致中文乱码 —— 改为先收 Buffer 再一次性解码。
- 修复：多会话 / 分屏下撤回可能串到别的会话 —— 撤回按钮限定在当前会话容器内，并按气泡文本匹配消息。
- 修复：样式标签在重复加载时叠加 —— 按 `data-plugin` 去重。

v3.0

- 适配 DSH `0.1.2+` 的 `SessionSnapshot` 变更：移除对已删除字段 `runningCalls` / `partial` 的依赖，修复 agent 运行中输入条渲染崩溃。

v0.2.0

- 撤回功能：消息气泡旁「撤回」按钮（带外框胶囊 UI），未被读取时可撤回，已读取则变灰。
- 草稿持久化：输入内容实时存入 localStorage（按 sessionId），不丢稿。
- 任务结束草稿保留：有内容则输入条保留，发送或清空后消失。
- 注入引导前缀：发送按钮左侧小方块开关（开=勾选），消息加「继续原任务」引导。

v0.1.6

- 按钮推至输入框最右侧，颜色统一走 DSH 主题 token。

v0.1.5

- textarea 自动换行增高（上限 140px），超限显示简约滚动条。

v0.1.4

- 修复 `setTimeout` 崩溃（改 timer 服务）；黄色实心圆钮动画。

v0.1.3

- 修复与 composer 左对齐；箭头向上；仅运行中显示。

v0.1.2

- 宽度对齐；√ / ✗ 状态反馈；按钮不被 √ 替换。

v0.1.1

- 接入 deep 短语池（73 条）轮换 + 中英切换。

v0.1.0

- 首个可发布版本：运行中弹出「修改要求」输入条，`agent.steer()` 注入。

---

## 技术实现

```
dsh-improved-inline-edit/
├── index.js             # Host 半部：注册 steer API，调用 agent.steer()
├── client.js            # Client 半部：槽位注入输入条 + 前端交互
├── cordis.patch.yml     # bundle patch 声明
├── install.ps1          # 一键安装脚本
├── assets/preview.png   # 界面预览图
├── LICENSE
└── README.md
```

- **标准 bundle patch**：不改源码，通过 patch 机制注入
- **槽位注入**：利用 DSH 的 slot 系统（`conversation.input.dock`）在 composer 上方插入输入条
- **`agent.steer()`**：通过官方 steering 机制注入修改指令
- **同源 fetch → webServer API**：
  - `POST /dsh-improved-inline-edit/api/send` —— 注入消息（可选附件）
  - `POST /dsh-improved-inline-edit/api/recall` —— 撤回未读取的消息，并回传原文
  - `GET /dsh-improved-inline-edit/api/pending` —— 待处理队列（决定能否撤回）
  - `GET /dsh-improved-inline-edit/api/limits` —— 附件上限（前端预校验）
- **附件**：图片 base64 → `ctx.attachments.admitPromptContent()` 换成 durable 引用；文件 → `ctx.attachments.admitEncodedFile()`；最后一起塞进同一条 `agent.steer` 消息，不绕过官方附件管线

---

## 贡献

欢迎贡献！如果你有想法或发现问题：

1. Fork 本仓库
2. 创建你的特性分支 (`git checkout -b feature/amazing`)
3. 提交你的改动 (`git commit -m 'Add some amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing`)

也欢迎在 [Issues](https://github.com/xiaosurongjia/dsh-improved-inline-edit/issues) 中提出建议或报告 bug。

---

## 许可证

[MIT](LICENSE) © [xiaosurongjia](https://github.com/xiaosurongjia)
