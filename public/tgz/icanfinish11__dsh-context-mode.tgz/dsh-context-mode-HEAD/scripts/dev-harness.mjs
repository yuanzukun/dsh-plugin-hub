// Standalone harness for the dsh-context-mode plugin (dev verification).
//
// Simulates the Cordis services the plugin consumes (tools registry, system
// prompt sections, a scoped logger), calls apply(), and then calls each
// registered ctx_* tool through a fake exec to prove tool registration,
// project-dir override, and result normalization work against the real engine.
//
// Engine is located the same way the plugin locates it: CONTEXT_MODE_ENGINE
// env override, the peer `context-mode` package, or this repo's ../build.
//
// Usage: node dsh/scripts/dev-harness.mjs [enginePath]
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { homedir } from 'node:os';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';

const __dir = dirname(fileURLToPath(import.meta.url));
const pkgDir = resolve(__dir, '..');
const repoRoot = resolve(__dir, '..', '..');
const pluginPath = resolve(pkgDir, 'index.js');
const engineHint = process.argv[2] || process.env.CONTEXT_MODE_ENGINE;

function makeCtx(log) {
  const tools = new Map();
  const sections = [];
  const ctx = {
    basename: repoRoot,
    logger: (name) => ({
      info: (msg) => log(`[info  ${name}] ${msg}`),
      warn: (msg) => log(`[warn  ${name}] ${msg}`),
      error: (msg) => log(`[error ${name}] ${msg}`),
    }),
    // tools service: register(definition) -> disposer
    tools: {
      register(def) {
        tools.set(def.name, def);
        return () => tools.delete(def.name);
      },
      list() { return [...tools.values()].map((d) => ({ name: d.name, description: d.description })); },
    },
    // systemPrompt service
    systemPrompt: {
      section(section) {
        sections.push(section);
        return () => { /* no-op */ };
      },
    },
    // not-required services
    skills: null,
    get(key) { return key === 'tools' ? ctx.tools : key === 'systemPrompt' ? ctx.systemPrompt : undefined; },
    effect(fn, label) {
      const dispose = fn();
      ctx._effects = ctx._effects ?? [];
      ctx._effects.push({ label, dispose });
      return () => {
        const idx = ctx._effects.findIndex((e) => e.label === label);
        if (idx >= 0) ctx._effects.splice(idx, 1);
      };
    },
    inject(keys, callback) {
      if (Array.isArray(keys) && keys.length > 0 && keys[0] === 'skills' && !ctx.skills) return;
      const scope = { skills: ctx.skills };
      if (callback) callback(scope);
    },
  };
  return { ctx, tools, sections };
}

const log = (msg) => process.stdout.write(msg + '\n');
const { ctx, tools, sections } = makeCtx(log);

const plugin = await import(pathToFileURL(pluginPath).href);
// Sandbox-safe storage: a throwaway temp dir (production default is
// $DSH_HOME/context-mode).
const store = mkdtempSync(join(tmpdir(), 'dsh-cm-'));
const config = {
  ...(engineHint ? { enginePath: engineHint } : {}),
  storageDir: store,
};

try {
  await plugin.apply(ctx, config);

  // ── Assertions ──────────────────────────────────────────
  const names = [...tools.keys()];
  log(`registered tools (${names.length}): ${names.join(', ')}`);
  log(`system prompt sections: ${sections.map((s) => s.name).join(', ')}`);

  const expected = [
    'ctx_execute', 'ctx_execute_file', 'ctx_batch_execute', 'ctx_index',
    'ctx_search', 'ctx_fetch_and_index', 'ctx_stats', 'ctx_doctor',
    'ctx_purge', 'ctx_insight',
  ];
  const missing = expected.filter((n) => !tools.has(n));
  if (missing.length) {
    log(`MISSING tools: ${missing.join(', ')}`);
    process.exitCode = 1;
  } else {
    log('all expected tools registered');
  }

  // ── One live call: ctx_index then ctx_search (FTS5 knowledge base) ──
  if (tools.has('ctx_index') && tools.has('ctx_search')) {
    try {
      const indexDef = tools.get('ctx_index');
      const searchDef = tools.get('ctx_search');
      const exec = { agent: { session: { id: 'harness-session', header: { cwd: repoRoot } } } };
      const marker = `dsh-harness-${Date.now()}`;
      const indexed = await indexDef.execute({ content: `DSH harness unit marker: ${marker}`, source: 'harness' }, exec);
      log(`ctx_index -> isError=${indexed.isError}, text=${indexed.text.slice(0, 120)}`);
      const found = await searchDef.execute({ queries: [marker] }, exec);
      log(`ctx_search -> isError=${found.isError}, text=${found.text.slice(0, 200)}`);
      if (!found.isError && found.text.includes(marker)) {
        log('ctx_index → ctx_search round trip OK');
      } else {
        log('ctx_search did not find the marker (check storage dir)');
      }
    } catch (error) {
      log(`live call error: ${error?.message ?? error}`);
      process.exitCode = 1;
    }
  }

  log('harness done');
} finally {
  try { rmSync(store, { recursive: true, force: true }); } catch { /* best effort */ }
}
