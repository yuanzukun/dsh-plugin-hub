// Boot a real dsh profile through dsh-app-boot and verify the ctx_* tools from
// the dsh-context-mode plugin are registered.
//
// Usage: DSH_HOME=<test-home> DSH_PROFILE=<profile> node dsh/scripts/dev-boot-probe.mjs
// The DSH_DEPS path below must point at the dsh installation's bundled deps;
// override with the environment variable DSH_DEPS.
import { pathToFileURL } from 'node:url';
import { join } from 'node:path';

const DSH_DEPS = process.env.DSH_DEPS
  ?? 'C:/Users/DNJ/AppData/Roaming/npm/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai';
const appBoot = await import(pathToFileURL(join(DSH_DEPS, 'dsh-app-boot', 'lib', 'index.js')).href);
const { boot, loadProfile, loadOptionalPatches } = appBoot;
const PROFILE_ROOT_FILENAME = 'cordis.yml';

const NAME = 'dsh';
const home = process.env.DSH_HOME;
const profileName = process.env.DSH_PROFILE ?? 'ctx-test';
const appBootPkg = join(DSH_DEPS, 'dsh-app-boot', 'package.json');

const composed = loadProfile(NAME, profileName, appBootPkg, home);
const allPatches = [
  ...composed.layers.flatMap((l) => l.patches),
  ...(loadOptionalPatches(NAME, composed.patchPath) ?? []),
];
const rootConfig = join(composed.dir, PROFILE_ROOT_FILENAME);

console.log(`[probe] profile=${profileName} layers=${composed.layers.map((l) => l.packageName).join(',')}`);

const ctx = await boot(NAME, rootConfig, allPatches);
const tools = ctx.get('tools');
if (!tools) {
  console.log('[probe] FAIL: no tools service — dsh-base did not mount');
  process.exit(1);
}
const names = [...(tools.view()?.visible ?? new Map()).keys()];
const ctxTools = names.filter((n) => n.startsWith('ctx_'));
console.log(`[probe] total tools=${names.length}`);
console.log(`[probe] ctx_* tools (${ctxTools.length}): ${ctxTools.sort().join(', ')}`);

const expected = ['ctx_execute', 'ctx_execute_file', 'ctx_batch_execute', 'ctx_index', 'ctx_search', 'ctx_fetch_and_index'];
const missing = expected.filter((n) => !ctxTools.includes(n));
if (missing.length > 0) {
  console.log(`[probe] MISSING: ${missing.join(', ')}`);
  process.exitCode = 1;
} else {
  console.log('[probe] PASS: all core ctx_* tools registered in a real dsh boot');
  console.log(`[probe] systemPrompt: ${ctx.get('systemPrompt') !== undefined}`);
}

await ctx.fiber.dispose();
process.exit(process.exitCode ?? 0);
