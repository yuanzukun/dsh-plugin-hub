# dsh-context-mode

Context Mode (the MCP server that keeps raw data out of the context window) as
a self-contained **DeepSeek Harness** plugin package. This folder is its own
npm package (`package.json` declares `dsh.bundle`), so it installs and
publishes independently of the `context-mode` npm package.

The plugin loads context-mode's engine library in-process (`build/server.js`
of the dependency `context-mode` package — the same module the OpenCode/Kilo
native adapter imports) and registers the `ctx_*` tools natively into dsh's
`tools` registry under their bare names — no MCP child process, no
`mcp__context-mode__` prefix. The engine is always taken from the original
author's published npm package; this repo ships only the dsh adapter.

## Contents

| Path | Purpose |
|---|---|
| `index.js` | Plugin module (`name` / `inject` / `apply`), engine location + registration |
| `cordis.patch.yml` | dsh bundle patch (`insert` row id `context-mode`) |
| `package.json` | npm metadata + `dsh.bundle.patch` manifest, depends on `context-mode` |
| `scripts/dev-harness.mjs` | Engine-level test: mock ctx, tool registration + FTS5 round trip |
| `scripts/dev-boot-probe.mjs` | Real dsh profile boot probe (dsh-app-boot), tool catalog check |

## What you get

| context-mode surface | dsh surface |
|---|---|
| `ctx_execute` / `ctx_execute_file` / `ctx_batch_execute` | native dsh tools (sandbox subprocess, only printed output enters the conversation) |
| `ctx_index` / `ctx_search` / `ctx_fetch_and_index` | native dsh tools (persistent FTS5 knowledge base, BM25 search) |
| `ctx_stats` / `ctx_doctor` / `ctx_purge` / `ctx_insight` | native dsh tools |
| SessionStart routing-block hook | `context-mode:routing` system-prompt section (dsh has no hook channel; the section plus the tool schemas are the enforcement surface) |
| session continuity (PreCompact/PostToolUse capture) | not wired — dsh has its own session/compaction layers; use `ctx_index` explicitly for durable memory |

All tools run the exact context-mode implementations, including security
routing (curl/wget/inline-fetch blocking), the executor's language matrix, and
the FTS5 content store. Storage defaults to dsh's own home
(`$DSH_HOME/context-mode`, i.e. `~/.dsh/context-mode`) so the knowledge base
is per-harness and never writes into another harness's config tree; set the
plugin `storageDir` (or `CONTEXT_MODE_DIR`/config) to override.

## Install

Requirements: Node.js ≥ 22.5 and a running dsh profile. The `context-mode`
engine package is a regular dependency and is installed automatically; no
build step is needed for this plugin (pure JS).

From GitHub (the canonical install):

```bash
dsh plugin --profile web add icanfinish11/dsh-context-mode
```

From npm (once the `dsh-context-mode` package is published):

```bash
dsh plugin --profile web add dsh-context-mode
```

From a local checkout of this repo:

```bash
npm install                              # installs the context-mode engine dependency
dsh plugin --profile web add link:/path/to/dsh-context-mode
```

> If you develop with this folder checked out *inside* a context-mode repo
> clone (`dsh/` next to the engine root), build the engine first
> (`npm run build` in the engine root) so the sibling layout resolves; a
> normal install never needs that.

Restart dsh web. Verify with `ctx stats` in a session, or:

```bash
node scripts/dev-boot-probe.mjs          # DSH_HOME + DSH_PROFILE env required
```

## Engine location order

1. `config.enginePath` (plugin config)
2. `CONTEXT_MODE_ENGINE` env var
3. the dependency `context-mode` package via Node resolution — the
   `context-mode/package.json` subpath export when upstream provides it,
   otherwise the package root resolved from its main entry by walking up to
   the `context-mode` package.json (works with the published package as of
   1.0.169, under npm flat/nested and pnpm store layouts)
4. sibling layout (`../build/server.js` — dev inside the context-mode repo only)

If none resolve, the plugin degrades to routing-only and logs a warning; it
never fails the dsh profile boot.

## Configuration

The plugin row id is `context-mode` (see `cordis.patch.yml`). Override
per-profile in `$DSH_HOME/profiles/<name>/cordis.patch.yml`:

```yaml
- id: context-mode
  config:
    storageDir: ~/.dsh/context-mode        # isolate the FTS5 store
    routing: true                          # inject the routing section
    tools:
      purge: false                         # hide destructive tools
      upgrade: false                       # host-hook updater (default off)
```

## Development

- `index.js` resolves the engine via Node resolution first (dependency
  `context-mode`), then the sibling layout — the same code works published and
  in-repo.
- `CONTEXT_MODE_EMBEDDED_PLUGIN_TOOLS=1` is set around the engine import so
  context-mode skips its stdio transport boot and process-wide handlers
  (matching the OpenCode/Kilo in-process contract).
- `scripts/dev-harness.mjs` runs the plugin against a mock ctx and proves the
  FTS5 `ctx_index` → `ctx_search` round trip; `scripts/dev-boot-probe.mjs`
  boots a real dsh profile and checks the registered tool catalog.

## Credits

This plugin is an independent dsh adapter by **icanfinish11**. The engine it
loads is **Context Mode** by **Mert Koseoğlu**
(mksglu): <https://github.com/mksglu/context-mode>, distributed on npm as
`context-mode` under the Elastic License 2.0. The engine is consumed as a
runtime dependency from the original author's published package — it is not
vendored or re-published here, and this repo contains no engine code.
