// dsh-context-mode — DeepSeek Harness plugin for context-mode
//
// A self-contained dsh bundle plugin (see package.json `dsh.bundle`).
// It loads context-mode's engine library in-process (the dependency `context-mode`
// package's build/server.js — the same module the OpenCode/Kilo native adapter
// imports; the bundled stdio entry server.bundle.mjs bootstraps a transport on
// import and must NOT be loaded as a library), then registers the ctx_* tools
// natively into dsh's `tools` registry under their bare names
// (ctx_execute, ctx_search, …) and contributes the content-window routing
// guidance as a system-prompt section — dsh has no hook channel, so the
// section is the model-facing enforcement surface next to the tools' own
// schemas and descriptions.
//
// No MCP child, no JSON-RPC hop, no server-qualified `mcp__context-mode__`
// prefix: the model sees exactly the ctx_* names context-mode's routing block
// references. The engine is isolated from host lifecycle concerns via
// CONTEXT_MODE_EMBEDDED_PLUGIN_TOOLS=1, which makes context-mode skip its
// process-wide handlers and the empty-tools/list shim.
//
// Engine location order:
//   1. config.enginePath (explicit)
//   2. CONTEXT_MODE_ENGINE env var
//   3. the dependency `context-mode` package via Node resolution
//   4. sibling layout (dsh/ inside the context-mode repo, dev only)
//
// Storage roots default to dsh's own home ($DSH_HOME/context-mode, else
// ~/.dsh/context-mode), so the FTS5 knowledge base and stats are per-harness
// and never write into another harness's config tree; set the plugin
// `storageDir` config to override. Project scope flows from dsh's session
// header (exec.agent.session.header.cwd) through the engine's
// withProjectDirOverride().

import { existsSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { homedir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const PLUGIN_DIR = dirname(fileURLToPath(import.meta.url));

// No Config schema is exported: the dsh loader applies config verbatim and
// the plugin reads optional keys with in-code defaults (the dsh-nuphus-mcp
// pattern). This keeps the plugin dependency-free beyond node builtins, so it
// resolves under any profile layout without importing dsh packages it does
// not own.

export const name = 'dsh-context-mode';
export const inject = ['tools', 'systemPrompt'];
/** Logger accessor that never throws in sparse compositions. */
function makeLogger(ctx) {
  try {
    if (typeof ctx.logger === 'function') return ctx.logger('dsh-context-mode');
  } catch { /* fall through */ }
  return { info() {}, warn(msg) { console.warn(`[dsh-context-mode] ${msg}`); }, error(msg) { console.error(`[dsh-context-mode] ${msg}`); } };
}

/**
 * Resolve the engine library path. Returns null when nothing is found; the
 * caller degrades to routing-only and logs.
 */
function locateEngine(config) {
  if (typeof config.enginePath === 'string' && config.enginePath.trim() !== '') {
    return config.enginePath;
  }
  if (typeof process.env.CONTEXT_MODE_ENGINE === 'string' && process.env.CONTEXT_MODE_ENGINE.trim() !== '') {
    return process.env.CONTEXT_MODE_ENGINE;
  }
  // The dependency `context-mode` package (normal npm/pnpm install). Two
  // strategies, tried in order, because the published package (<= 1.0.169)
  // does NOT export the './package.json' subpath:
  //   1. subpath export — works once upstream adds it;
  //   2. resolve the main entry and walk up to the package root — works with
  //      the published package under npm flat/nested and pnpm store layouts.
  try {
    const require = createRequire(import.meta.url);
    try {
      const pkgRoot = dirname(require.resolve('context-mode/package.json'));
      const candidate = join(pkgRoot, 'build', 'server.js');
      if (existsSync(candidate)) return candidate;
    } catch { /* subpath not exported — fall through to the walk */ }
    const viaMain = resolveEngineViaMainEntry(require);
    if (viaMain) return viaMain;
  } catch { /* dependency not installed — fall through */ }
  // Sibling layout: dsh/ committed inside the context-mode repo (dev).
  for (const rel of ['../build/server.js', '../server.bundle.mjs']) {
    const candidate = resolve(PLUGIN_DIR, rel);
    if (existsSync(candidate)) return candidate;
  }
  return null;
}

/**
 * Resolve the context-mode package root without relying on a
 * './package.json' subpath export: require the package's main entry, then
 * walk up from that file to the nearest package.json whose name is
 * 'context-mode'. Covers npm's flat/nested layouts and pnpm's
 * .pnpm/.../node_modules/context-mode store layout (realpaths included).
 */
function resolveEngineViaMainEntry(require) {
  let main;
  try {
    main = require.resolve('context-mode');
  } catch {
    return null;
  }
  let dir = dirname(main);
  for (let i = 0; i < 10; i += 1) {
    const pkgPath = join(dir, 'package.json');
    if (existsSync(pkgPath)) {
      try {
        const meta = JSON.parse(readFileSync(pkgPath, 'utf8'));
        if (meta.name === 'context-mode') {
          const candidate = join(dir, 'build', 'server.js');
          return existsSync(candidate) ? candidate : null;
        }
      } catch { /* unreadable package.json — keep walking */ }
    }
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

let engineModule = null;
let enginePromise = null;
/** Load the engine library module at most once per process. */
function loadEngine(locatedPath) {
  if (engineModule !== null) return Promise.resolve(engineModule);
  if (enginePromise === null) {
    enginePromise = (async () => {
      const path = locatedPath;
      if (!path) {
        throw new Error(
          'context-mode engine not found. Install the dependency "context-mode" package ' +
          '(npm i context-mode / pnpm add context-mode), set CONTEXT_MODE_ENGINE, or ' +
          'point the plugin config at its build/server.js.',
        );
      }
      const prev = process.env.CONTEXT_MODE_EMBEDDED_PLUGIN_TOOLS;
      process.env.CONTEXT_MODE_EMBEDDED_PLUGIN_TOOLS = '1';
      try {
        engineModule = await import(pathToFileURL(path).href);
        return engineModule;
      } finally {
        if (prev === undefined) delete process.env.CONTEXT_MODE_EMBEDDED_PLUGIN_TOOLS;
        else process.env.CONTEXT_MODE_EMBEDDED_PLUGIN_TOOLS = prev;
      }
    })();
  }
  return enginePromise;
}

export const apply = async (ctx, config = {}) => {
  const logger = makeLogger(ctx);

  const toolsCfg = config.tools ?? {};
  const visible = new Map([
    ['ctx_execute', toolsCfg.execute ?? true],
    ['ctx_execute_file', toolsCfg.executeFile ?? true],
    ['ctx_batch_execute', toolsCfg.batchExecute ?? true],
    ['ctx_index', toolsCfg.index ?? true],
    ['ctx_search', toolsCfg.search ?? true],
    ['ctx_fetch_and_index', toolsCfg.fetchAndIndex ?? true],
    ['ctx_stats', toolsCfg.stats ?? true],
    ['ctx_doctor', toolsCfg.doctor ?? true],
    ['ctx_purge', toolsCfg.purge ?? true],
    ['ctx_insight', toolsCfg.insight ?? true],
    ['ctx_upgrade', toolsCfg.upgrade ?? false],
  ]);

  // Register the ctx_* tools. A missing engine degrades to routing-only and
  // logs — it must never fail the dsh profile boot.
  try {
    const located = locateEngine(config);
    if (!located) {
      throw new Error('no engine located (config.enginePath, CONTEXT_MODE_ENGINE, or dependency context-mode)');
    }
    const engine = await loadEngine(located);
    if (!engine || !Array.isArray(engine.REGISTERED_CTX_TOOLS)) {
      throw new Error('engine module does not export REGISTERED_CTX_TOOLS');
    }
    // Storage root: config wins; otherwise dsh's own home so the knowledge
    // base never collides with another harness's (context-mode's unset
    // default resolves to ~/.claude/... when the platform auto-detect lands
    // on a Claude install).
    setStorageRoot(config.storageDir);
    let count = 0;
    for (const entry of engine.REGISTERED_CTX_TOOLS) {
      if (!visible.get(entry.name)) continue;
      const definition = engineEntryToDefinition(entry, engine, logger);
      if (!definition) continue;
      try {
        ctx.tools.register(definition);
        count += 1;
      } catch (error) {
        logger.warn(`[dsh-context-mode] tool "${entry.name}" registration skipped: ${error?.message ?? error}`);
      }
    }
    logger.info(`[dsh-context-mode] registered ${count} ctx_* tools (in-process engine)`);
  } catch (error) {
    logger.warn(`[dsh-context-mode] engine unavailable — ctx_* tools skipped, routing only: ${error?.message ?? error}`);
  }

  if (config.routing ?? true) {
    ctx.systemPrompt.section({
      name: 'context-mode:routing',
      order: 150,
      text: ROUTING_BLOCK,
    });
  }
};

/**
 * Point the engine at a writable storage root. The default storage root is
 * dsh's own home ($DSH_HOME/context-mode, else ~/.dsh/context-mode) so the
 * knowledge base is per-harness and never written into another harness's
 * config tree. The env value is intentionally left in place for the lifetime
 * of the process (the plugin owns this process-global for the harness);
 * another activation overwrites it.
 */
function setStorageRoot(requested) {
  const fallback = join(
    process.env.DSH_HOME || join(homedir(), '.dsh'),
    'context-mode',
  );
  const root = typeof requested === 'string' && requested.trim() !== ''
    ? requested
    : fallback;
  process.env.CONTEXT_MODE_DIR = root;
}

/**
 * Convert one engine registry entry ({ name, config, handler }) into a dsh
 * raw tool definition: parameters as object-rooted JSON Schema, output as
 * { schema, render }, execute calling the engine handler under a project-dir
 * override.
 */
function engineEntryToDefinition(entry, engine, logger) {
  const config = entry.config ?? {};
  const description = typeof config.description === 'string'
    ? config.description
    : `context-mode ${entry.name}.`;
  const handler = entry.handler;

  const parameters = zodShapeToJsonSchema(shapeOf(config.inputSchema));
  if (!parameters) {
    logger.warn(`[dsh-context-mode] ${entry.name}: input schema not convertible — skipped`);
    return null;
  }

  return {
    name: entry.name,
    description,
    parameters,
    output: {
      schema: {
        type: 'object',
        properties: {
          text: { type: 'string' },
          isError: { type: 'boolean' },
        },
        additionalProperties: false,
        required: ['text', 'isError'],
      },
      render: (_args, value) => {
        const text = value && typeof value.text === 'string'
          ? value.text
          : `${entry.name} completed`;
        return [{ type: 'text', text }];
      },
    },
    timeoutMs: 300_000,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const cwd = exec?.agent?.session?.header?.cwd ?? process.cwd();
      const sessionId = exec?.agent?.session?.id;
      const override = { projectDir: cwd, ...(sessionId ? { sessionId } : {}) };
      const run = () => handler(args ?? {});
      const result = typeof engine.withProjectDirOverride === 'function'
        ? await engine.withProjectDirOverride(override, run)
        : await run();
      return { text: toolResultText(result), isError: toolResultIsError(result) };
    },
  };
}

// ---- zod → JSON-Schema conversion (object-rooted, dsh subset) ------------
// The engine's inputSchema is a pre-compiled zod object. We emit the dsh
// supported JSON-Schema subset (type/properties/required/additionalProperties/
// items/enum/const/oneOf + description) so the model sees the real fields.
// Coercing preprocessors (coerce.number, coerceBoolean, coerceJsonArray) are
// deliberately glossed over: dsh passes the model's value through, and the
// engine's own zod parse still coerces before its handler runs.

function shapeOf(schema) {
  if (!schema) return {};
  if (schema && typeof schema.shape === 'object' && schema.shape !== null) return schema.shape;
  if (schema && schema._def && typeof schema._def.shape === 'function') {
    try { return schema._def.shape(); } catch { return {}; }
  }
  return {};
}

function zodShapeToJsonSchema(shape) {
  const properties = {};
  const required = [];
  for (const [key, field] of Object.entries(shape ?? {})) {
    const converted = zodFieldToSchema(field);
    if (converted) {
      properties[key] = converted.schema;
      if (converted.required) required.push(key);
    }
  }
  const schema = { type: 'object', properties };
  if (required.length > 0) schema.required = required;
  return schema;
}

function zodFieldToSchema(field) {
  if (!field) return null;
  const def = field._def;
  if (!def) return null;
  const description = fieldDescription(field);
  const t = def.typeName;
  // Unwrap: optional/default/preprocess/coerce/pipe keep a required inner
  // spec in the model-facing schema, but only non-optional fields join
  // `required`.
  if (t === 'ZodOptional') {
    const inner = zodFieldToSchema(def.innerType ?? def.type);
    return inner ? { ...inner, required: false } : null;
  }
  if (t === 'ZodDefault') {
    const inner = zodFieldToSchema(def.innerType ?? def.type);
    return inner ? { ...inner, required: false } : null;
  }
  if (t === 'ZodEffects' || t === 'ZodPipe' || t === 'ZodCatch' || t === 'ZodPreprocess') {
    const target = def.schema ?? def.innerType ?? def.type;
    return target ? zodFieldToSchema(target) : null;
  }
  const describe = (schema) => (description ? { ...schema, description } : schema);
  switch (t) {
    case 'ZodString': return { schema: describe({ type: 'string' }), required: true };
    case 'ZodBoolean': return { schema: describe({ type: 'boolean' }), required: true };
    case 'ZodNumber': return { schema: describe({ type: 'number' }), required: true };
    case 'ZodInteger': return { schema: describe({ type: 'integer' }), required: true };
    case 'ZodEnum':
    case 'ZodNativeEnum': {
      const values = Array.isArray(def.values)
        ? def.values.map((v) => String(v))
        : Object.keys(def.values ?? {}).filter((k) => typeof def.values[k] !== 'number');
      if (values.length === 0) return { schema: describe({ type: 'string' }), required: true };
      return { schema: describe({ type: 'string', enum: values }), required: true };
    }
    case 'ZodLiteral':
      return { schema: describe({ type: typeof def.value === 'string' ? 'string' : 'number', const: def.value }), required: true };
    case 'ZodArray': {
      const item = def.type ? zodFieldToSchema(def.type) : null;
      const items = item ? item.schema : { type: 'json' };
      return { schema: describe({ type: 'array', items }), required: true };
    }
    case 'ZodObject': {
      const shape = typeof def.shape === 'function' ? def.shape() : (def.shape ?? {});
      return { schema: describe({ type: 'object', properties: zodShapeToJsonSchema(shape).properties }), required: true };
    }
    case 'ZodRecord': return { schema: describe({ type: 'json' }), required: true };
    case 'ZodUnion': {
      const options = Array.isArray(def.options) ? def.options : [];
      const schemas = options.map((o) => zodFieldToSchema(o)?.schema).filter(Boolean);
      if (schemas.length === 0) return { schema: describe({ type: 'json' }), required: true };
      if (schemas.length === 1) return { schema: describe(schemas[0]), required: true };
      return { schema: describe({ oneOf: dedupe(schemas) }), required: true };
    }
    case 'ZodLazy': {
      const inner = def.type ? zodFieldToSchema(def.type) : null;
      return inner ? { ...inner, required: true } : { schema: describe({ type: 'json' }), required: true };
    }
    default: return { schema: describe({ type: 'json' }), required: true };
  }
}
function dedupe(list) {
  const seen = new Set();
  const out = [];
  for (const item of list) {
    const key = JSON.stringify(item);
    if (!seen.has(key)) { seen.add(key); out.push(item); }
  }
  return out;
}
function fieldDescription(field) {
  const def = field._def;
  for (const d of [field.description, def?.description]) {
    if (typeof d === 'string' && d.trim() !== '') return d;
  }
  return '';
}

// ---- result normalization ------------------------------------------------
function toolResultText(result) {
  if (result == null) return '';
  if (typeof result === 'string') return result;
  if (Array.isArray(result)) return result.map(toolResultText).join('\n');
  if (typeof result === 'object') {
    if (Array.isArray(result.content)) {
      return result.content
        .filter((part) => part && part.type === 'text' && typeof part.text === 'string')
        .map((part) => part.text)
        .join('\n');
    }
    if (typeof result.text === 'string') return result.text;
    try { return JSON.stringify(result); } catch { return ''; }
  }
  return String(result);
}
function toolResultIsError(result) {
  return result != null && typeof result === 'object' && result.isError === true;
}

// ---- routing guidance (dsh-native tool names) ----------------------------
const ROUTING_BLOCK = `<context_window_protection>
  <priority_instructions>
    Every byte a tool returns enters your conversation memory and costs reasoning capacity for the rest of the session. The context-mode tools let you do the work in a sandbox and surface only the derived answer — the raw bytes stay out. Think-in-Code: program the analysis, do not compute it by reading raw data into your conversation.
  </priority_instructions>
  <tool_selection_hierarchy>
    0. MEMORY: ctx_search(sort: "timeline") — search prior session memory before asking the user.
    1. GATHER: ctx_batch_execute(commands, queries) — run many commands in parallel, auto-index each output, return matching sections in one round trip.
    2. FOLLOW-UP: ctx_search(queries: ["q1", "q2", ...]) — batch every question about already-indexed content into one call.
    3. PROCESSING: ctx_execute(language, code) | ctx_execute_file(path, language, code) — derive answers from data; only what you print enters the conversation.
  </tool_selection_hierarchy>
  <when_not_to_use>
    - Reading a file to EDIT it: Read is correct (Edit needs exact bytes). Reading to analyze/summarize/extract: use ctx_execute_file.
    - A short fixed observational command (whoami, pwd, git status on a clean tree): dsh's own Bash/pwsh tools are simpler.
    - Writing files: use dsh's Edit/Write tools — ctx_execute sandbox subprocesses do not persist to the host filesystem.
    - WebFetch/curl/wget/inline fetch: use ctx_fetch_and_index(url, source) then ctx_search(queries) — raw page bytes never enter the conversation.
  </when_not_to_use>
  <ctx_commands>
    "ctx stats" → call ctx_stats, show output verbatim.
    "ctx doctor" → call ctx_doctor, run the returned command, display as checklist.
    "ctx purge" → call ctx_purge with confirm: true. Warn: irreversible.
  </ctx_commands>
</context_window_protection>`;

export default { name, inject, apply };
