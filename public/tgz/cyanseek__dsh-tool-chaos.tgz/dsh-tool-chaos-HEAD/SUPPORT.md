# Support

## Use GitHub Discussions for

- scenario design and “how do I test this recovery behavior?” questions;
- integration ideas;
- compatibility reports;
- showcase/adopter stories.

## Use GitHub Issues for

- reproducible bugs;
- accepted feature proposals;
- documentation defects;
- compatibility regressions.

## Use private vulnerability reporting for

- security issues, secret exposure, policy bypass, profile/path escape, or unsafe matching.

A useful support request includes Node, DSH, package, and Codex versions; operating system; sanitized patch; CLI JSON report; and the smallest reproduction. Raw logs are optional and must be redacted.
