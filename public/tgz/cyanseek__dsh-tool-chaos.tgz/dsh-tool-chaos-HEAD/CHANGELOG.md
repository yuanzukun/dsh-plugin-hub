# Changelog

All notable changes are documented here. The format follows Keep a Changelog and the project uses Semantic Versioning.

## [Unreleased]

### 0.1.0-next.1 candidate — 2026-09-28

- Target DSH 0.1.7-rc.2; prior compatibility evidence remains historical.
- Updated ToolCallId integration and TypeScript 7; fault injection remains disabled by default.


### Changed

- Refresh development DSH tools, LLM, and system-prompt dependencies to rc.8, with all 32 Windows unit/CLI/runtime tests passing. Preserve the version boundary of earlier real-profile and headless evidence.

### Added

- Codex plugin marketplace layout and `$dsh-chaos-test` Agent Skill.
- JSONL decision reporter.
- Machine-facing `doctor`, `setup`, `init`, `run`, `verify`, and Codex automation commands.
- Baseline, dry-run, and experiment run modes with JSON/Markdown evidence.
- Open-source governance and security documents.
- Pinned GitHub-source install, repeat-install, uninstall, and reinstall compatibility evidence.

### Changed

- Reworked the bilingual README around verified installation, safety, evidence, and compatibility.
- Removed maintainer-only planning, research, launch, and build-prompt material from the public distribution.

## [0.1.0-next.0] - 2026-08-14

### Added

- Deterministic rule engine.
- DSH pre/around/post tool-pipeline adapters.
- Safe defaults and five initial fault actions.
- Initial tests, examples, and bilingual documentation.

[Unreleased]: https://github.com/cyanseek/dsh-tool-chaos/compare/v0.1.0-next.0...HEAD
[0.1.0-next.0]: https://github.com/cyanseek/dsh-tool-chaos/releases/tag/v0.1.0-next.0
