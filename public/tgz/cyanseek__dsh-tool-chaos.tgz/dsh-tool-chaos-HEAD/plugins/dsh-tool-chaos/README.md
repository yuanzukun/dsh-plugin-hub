# DSH Tool Chaos — Codex plugin

This skill-only Codex plugin turns natural-language resilience requirements into isolated DeepSeek Harness fault-injection experiments.

Install through the repository marketplace during development:

```bash
codex plugin marketplace add /absolute/path/to/dsh-tool-chaos
codex plugin add dsh-tool-chaos@dsh-tool-chaos
```

From this repository checkout, install the managed plugin and standalone Skill fallback with:

```bash
npm run build
npm pack --silent
node bin/dsh-tool-chaos.mjs setup \
  --source ./dsh-tool-chaos-0.1.0-next.1.tgz \
  --codex
```

Start a new Codex thread in the checkout and invoke `$dsh-chaos-test`. The shorter `npx dsh-tool-chaos ...` route becomes available only after the npm prerelease is published.
