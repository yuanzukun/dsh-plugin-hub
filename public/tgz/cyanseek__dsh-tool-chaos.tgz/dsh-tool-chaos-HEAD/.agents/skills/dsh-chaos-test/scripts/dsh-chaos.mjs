#!/usr/bin/env node

import { existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import process from 'node:process'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const skillRoot = dirname(dirname(fileURLToPath(import.meta.url)))
const candidates = [
  resolve(skillRoot, '..', '..', '..', '..', 'bin', 'dsh-tool-chaos.mjs'),
  resolve(skillRoot, '..', '..', '..', 'bin', 'dsh-tool-chaos.mjs'),
]
const local = candidates.find(candidate => existsSync(candidate))
const args = process.argv.slice(2)
const result = local
  ? spawnSync(process.execPath, [local, ...args], { stdio: 'inherit' })
  : spawnSync('npx', ['-y', 'dsh-tool-chaos', ...args], {
      stdio: 'inherit',
      shell: process.platform === 'win32',
    })

if (result.error) {
  process.stderr.write(`dsh-chaos-test: ${result.error.message}\n`)
  process.exitCode = 127
} else {
  process.exitCode = result.status ?? 1
}
