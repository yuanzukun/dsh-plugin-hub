# Report contract

`run --json` writes one JSON report and one Markdown report. The JSON object is the source of truth.

Required fields:

- `schemaVersion`, `tool`, `version`, `runId`;
- `startedAt`, `finishedAt`, `mode`, `profile`;
- `sourcePatch`, `effectivePatch`, `task`, `command`;
- `process.exitCode`, timeout/signal state, byte counts, stdout/stderr SHA-256;
- `chaos.totalDecisions`, `injected`, `dryRuns`, `rules`, `decisions`, `parseErrors`;
- optional output assertion;
- `verdict` and `summary`.

CLI run verdicts:

- `baseline-passed` — successful run with no chaos decision;
- `preview` — successful dry-run with matching would-inject evidence;
- `passed` — successful real run with one or more injected decisions;
- `failed` — process, assertion, mode contract, or recovery failed;
- `inconclusive` — run completed but required evidence was absent.

The final three-run experiment maps these to PASS/FAIL/INCONCLUSIVE after applying the repository-specific recovery oracle.

Raw stdout/stderr are omitted by default. `--include-output` is opt-in and bounded; hashes are always recorded.
