# CLI contract

The stable machine surface is `dsh-tool-chaos <command> --json`.

## Commands

- `doctor [--profile name] --json`: dependency and profile readiness.
- `setup [--profile name] [--source spec] [--codex] --json`: idempotent DSH/Codex setup.
- `init <file> --preset retry|timeout|nested|result-block|deny`: write a safe dry-run overlay.
- `run --mode baseline|dry-run|experiment --patch file --task text [--expect regex] --json`: execute one evidence-producing run.
- `install-plugin`, `install-skill`, `install-codex-plugin`: explicit installation primitives.
- `verify --json`: repository/plugin metadata validation.
- `prompt --lang en|zh`: print the full autonomous execution prompt.
- `codex <requirement>`: invoke `codex exec` with the autonomous prompt.

## Exit codes

- `0`: command succeeded; run verdict is `baseline-passed`, `preview`, or `passed`.
- `1`: operational failure or experiment verdict `failed`.
- `2`: environment unsupported or experiment `inconclusive`.
- `3`: installation completed but effective DSH composition could not be verified.
- `127`: required executable missing from the skill wrapper.

Do not scrape human text when `--json` is available.
