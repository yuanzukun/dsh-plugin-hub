# Scenario design

Use the smallest fault that proves one recovery contract.

## Rule selection

1. Prefer an exact tool name from DSH tool schemas or observed dry-run evidence.
2. Use `scope: root` for model-direct calls and `scope: nested` for Code Mode SDK sub-dispatches.
3. Use `argumentsPattern` only when several calls share the same name.
4. Use `probability: 1` for tests. Probabilistic rules are for longer soak suites, not first diagnosis.
5. Keep `maxInjections: 1` until the single-fault recovery works.

## Recovery oracles

A valid oracle includes a user-visible outcome and negative side-effect checks.

Examples:

- Retry: final answer matches baseline, one failure appears, at most one retry occurs, no duplicate write occurs.
- Abort: the task stops within budget, child work is quiescent, no orphan process remains, final message is a bounded recovery or error.
- Deny: denied operation never runs; agent uses a safe alternative or explains why it cannot continue.
- Block: blocked data is not cited or persisted as trusted evidence.
- Nested: outer `run_code` catches or routes the sub-call failure and finishes coherently.

## Anti-patterns

- “Process exited 0” as the sole pass condition.
- Exact `*` matching.
- Reusing a personal or production profile.
- Mixing multiple unrelated faults in the first experiment.
- Manually telling the tested agent to retry after injection.
