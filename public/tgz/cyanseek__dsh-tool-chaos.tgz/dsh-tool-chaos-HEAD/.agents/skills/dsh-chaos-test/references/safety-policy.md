# Safety policy

## Allowed by default

- disposable local DSH profiles;
- workspace-local files under `.dsh-chaos/`;
- deterministic dry-run and one-shot fault injection against local/test tools;
- read-only inspection and existing repository tests.

## Requires explicit human authorization

- any production, shared, personal, or long-lived profile;
- external APIs that can mutate data or incur material cost;
- repositories/workspaces outside the current authorized root;
- broad tool matching, especially exact `*`;
- changing sandbox, approval, credential, or secret settings;
- publishing, pushing, or creating remote resources.

## Never infer as safe

- missing logs;
- skipped checks;
- inaccessible process state;
- a zero exit code without recovery evidence;
- a profile name that merely sounds disposable.

Use `INCONCLUSIVE` when observability is insufficient.
