# Report schema

The CLI writes JSON and Markdown for each run. JSON is authoritative; Markdown is a review projection.
The machine-readable contract is [schemas/chaos-run.schema.json](../schemas/chaos-run.schema.json).

## Version 1

```ts
interface ChaosRunReportV1 {
  schemaVersion: 1
  tool: 'dsh-tool-chaos'
  version: string
  runId: string
  startedAt: string
  finishedAt: string
  mode: 'baseline' | 'dry-run' | 'experiment'
  profile: string
  sourcePatch: string
  effectivePatch: string
  task: string
  command: string
  process: {
    exitCode: number
    signal: string | null
    timedOut: boolean
    stdoutBytes: number
    stderrBytes: number
    stdoutSha256: string
    stderrSha256: string
  }
  chaos: {
    totalDecisions: number
    injected: number
    dryRuns: number
    rules: string[]
    decisions: ChaosDecisionEvent[]
    parseErrors: Array<{ payload: string; error: string }>
  }
  assertion?: {
    pattern: string
    matched: boolean
  }
  verdict: 'baseline-passed' | 'preview' | 'passed' | 'failed' | 'inconclusive'
  summary: string
  output?: {
    stdout: string
    stderr: string
    truncatedAtBytes: number
  }
}
```

## Decision event

A decision contains rule/action/phase/tool identity, root/nested identity, schedule counters, sample, stable fingerprint, dry-run/injection state, optional delay, and model-facing message. Full arguments are deliberately omitted.

## Integrity model

- stdout and stderr hashes are always stored;
- raw output is opt-in and bounded;
- the exact command and effective patch path are stored;
- parse failures remain visible and cannot silently become PASS;
- a successful process with missing expected evidence is `inconclusive`.

## Three-run verdict

A complete Agent-led experiment compares:

1. a `baseline-passed` run;
2. a `preview` run proving the exact target;
3. a real `passed` or `failed` run.

The repository-specific oracle then emits final `PASS`, `FAIL`, or `INCONCLUSIVE`. This higher-level verdict must check user-visible recovery and forbidden side effects, not merely reuse the CLI process verdict.
