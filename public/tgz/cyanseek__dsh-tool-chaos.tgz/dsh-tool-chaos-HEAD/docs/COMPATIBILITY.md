# Compatibility

## Current candidate — September 28, 2026

Windows Node.js 24.11.1 and real DSH ToolRuntime 0.1.7-rc.2: 32 tests, strict typecheck, build, Skill validation, CLI verification and package inspection pass. TypeScript 7.0.2 uses explicit Node 22 types. PTC tests use a synthetic execution provider with the real registry; they do not represent a live model run. New Linux/macOS and model-backed end-to-end validation remains pending. Isolated real DSH 0.1.7-rc.2 tarball installation, effective-config inspection, and removal also pass. All older rows below are historical evidence.


## Declared peer range

```text
@deepseek-ai/cordis        ~4.0.4
@deepseek-ai/dsh-tools     0.1.7-rc.2
@deepseek-ai/schemastery   ~3.18.4
Node                       ^22.19.0 || >=24
```

A declared range is not the same as a tested matrix.

## Release matrix

| Package version | DSH line | Node | Unit/runtime adapter | Real profile install | Headless run | Nested dispatch |
|---|---|---|---|---|---|---|
| 0.1.0-next.0 | 0.1.0-rc.6 | 24.11.1 local; 22.19.0/24.x GitHub CI pass | 32 tests pass | tarball and pinned GitHub source add/repeat/dump pass; GitHub uninstall/reinstall pass with pnpm 11.7.0 | read-only dry-run preview pass | real rc.6 registry test passes |

Evidence date: August 14, 2026. The headless run used an isolated DSH home, a synthetic read-only file, one observed dry-run decision, no injected fault, and an unchanged successful tool result. The GitHub-source gate pinned commit `30221b008cd4b7a52291cdffbf8e26ce80180b2c`; pnpm required the exact codeload package key under profile-local `allowBuilds` before running the Git dependency's `prepare` script.

## Development refresh — September 12, 2026

Windows Node.js `24.11.1`, DSH tools/LLM/system-prompt `0.1.0-rc.8`: `npm run check` passes strict typechecking, build, all 32 unit/CLI/real-runtime tests, Skill validation, verification, and tarball inspection. The real rc.8 registry covers nested dispatch. Real-profile installation and headless execution were not repeated for rc.8; the release matrix above remains the August rc.6 evidence.

Update the release matrix only with stored CI or release evidence.

## Developer-preview policy

DSH explicitly allows breaking changes during developer preview. This project therefore:

- publishes prereleases until the consumer matrix is green;
- pins exact DSH versions in compatibility CI;
- keeps the runtime adapter thin;
- treats public event/type changes as release-significant;
- records unsupported lines honestly rather than broadening a peer range speculatively.
