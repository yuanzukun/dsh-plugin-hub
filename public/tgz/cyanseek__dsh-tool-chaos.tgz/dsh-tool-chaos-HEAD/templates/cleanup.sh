#!/usr/bin/env bash
set -euo pipefail

PROFILE="${PROFILE:-replace-with-isolated-profile}"
# Remove only the disposable profile created for this experiment. Inspect the
# active DSH version's profile location before enabling this line.
echo "Cleanup required for disposable profile: $PROFILE"
