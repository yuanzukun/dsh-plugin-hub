$ErrorActionPreference = "Stop"
$Profile = if ($env:PROFILE) { $env:PROFILE } else { "replace-with-isolated-profile" }
Write-Output "Cleanup required for disposable profile: $Profile"
