#!/usr/bin/env bash
set -euo pipefail

PROFILE="${PROFILE:-replace-with-isolated-profile}"
PATCH="${PATCH:-experiment.patch.yml}"
PROMPT="${PROMPT:-replace with the scenario prompt}"

dsh --profile "$PROFILE" --patch "$PATCH" "$PROMPT" 2>&1 | tee experiment.log
