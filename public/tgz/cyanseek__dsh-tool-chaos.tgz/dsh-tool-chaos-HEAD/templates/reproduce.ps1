$ErrorActionPreference = "Stop"
$Profile = if ($env:PROFILE) { $env:PROFILE } else { "replace-with-isolated-profile" }
$Patch = if ($env:PATCH) { $env:PATCH } else { "experiment.patch.yml" }
$Prompt = if ($env:PROMPT) { $env:PROMPT } else { "replace with the scenario prompt" }

dsh --profile $Profile --patch $Patch $Prompt 2>&1 | Tee-Object -FilePath experiment.log
