/** Cordis loader metadata. Function plugins must use named exports. */
export const name = 'dsh-tool-chaos'
export const inject = ['tools']

export { Config, resolveConfig } from './config.js'
export type {
  ChaosAction,
  ChaosCallScope,
  ChaosRule,
  ResolvedChaosRule,
  ResolvedConfig,
} from './options.js'
export { apply } from './runtime.js'
export {
  ChaosEngine,
  compileGlob,
  fnv1a32,
  stableStringify,
} from './core.js'
export type {
  ChaosDecisionEvent,
  ChaosExecutionLike,
  ChaosPhase,
  ChaosRuleStats,
  ChaosSnapshot,
} from './core.js'
