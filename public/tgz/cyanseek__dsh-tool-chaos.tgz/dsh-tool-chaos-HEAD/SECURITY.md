# Security Policy

`dsh-tool-chaos` intentionally changes tool execution behavior. Treat configuration, package installation, and experiment targeting as security-sensitive surfaces.

## Supported versions

| Version | Security fixes |
|---|---|
| latest prerelease | yes |
| older prereleases | best effort |
| unreleased branches | no guarantee |

The project will publish a stable support matrix after the first DSH consumer-tested release.

## Report a vulnerability

Do not open a public issue for a vulnerability. Use GitHub Private Vulnerability Reporting for this repository. Include:

- affected version and platform;
- DSH/Codex versions;
- minimal reproduction;
- security impact and likely blast radius;
- whether secrets or external systems were touched;
- suggested mitigation, if known.

Maintainers will acknowledge a complete report as soon as practical, coordinate a fix and advisory, and credit reporters who want attribution.

## High-priority classes

- rules matching tools more broadly than declared;
- dry-run executing a real fault;
- cancellation detaching upstream abort or abandoning work;
- path/profile escape in CLI automation;
- secrets appearing in JSONL or reports;
- plugin/skill installation executing an unexpected source;
- report tampering that can turn missing evidence into PASS;
- DSH policy or approval bypass.

## Safe usage

Use disposable profiles and local/test workspaces. Review package source before allowing Git/package prepare scripts. Never point autonomous experiments at production or shared profiles without explicit authorization and independent safeguards.
