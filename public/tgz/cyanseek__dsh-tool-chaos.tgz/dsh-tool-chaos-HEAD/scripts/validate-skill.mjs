#!/usr/bin/env node

import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { join, relative, resolve } from 'node:path'
import process from 'node:process'

const source = resolve('plugins/dsh-tool-chaos/skills/dsh-chaos-test')
const local = resolve('.agents/skills/dsh-chaos-test')
const errors = []

function fail(message) {
  errors.push(message)
}

function filesBelow(root, prefix = '') {
  const output = []
  for (const name of readdirSync(join(root, prefix))) {
    const path = join(prefix, name)
    if (statSync(join(root, path)).isDirectory()) output.push(...filesBelow(root, path))
    else output.push(path.replaceAll('\\', '/'))
  }
  return output.sort()
}

function validate(root, label) {
  const skillPath = join(root, 'SKILL.md')
  if (!existsSync(skillPath)) {
    fail(`${label}: missing SKILL.md`)
    return
  }
  const text = readFileSync(skillPath, 'utf8')
  const lines = text.split(/\r?\n/)
  if (lines.length > 500) fail(`${label}: SKILL.md has ${lines.length} lines; maximum is 500`)
  const match = /^---\r?\n([\s\S]*?)\r?\n---\r?\n/.exec(text)
  if (!match) {
    fail(`${label}: SKILL.md is missing YAML frontmatter`)
    return
  }
  const frontmatter = match[1]
  const name = /^name:\s*([^\r\n]+)$/m.exec(frontmatter)?.[1]?.trim()
  const description = /^description:\s*([^\r\n]+)$/m.exec(frontmatter)?.[1]?.trim()
  if (name !== 'dsh-chaos-test') fail(`${label}: name must be dsh-chaos-test`)
  if (!name || !/^[a-z0-9-]{1,64}$/.test(name)) fail(`${label}: name violates Agent Skills naming rules`)
  if (!description || description.length > 1024) fail(`${label}: description must contain 1..1024 characters`)
  if (description && !/Use when|Use for|Use to/i.test(description)) fail(`${label}: description must explain when to use the skill`)

  const required = [
    'agents/openai.yaml',
    'scripts/dsh-chaos.mjs',
    'references/cli-contract.md',
    'references/report-contract.md',
    'references/safety-policy.md',
    'references/scenario-design.md',
  ]
  for (const path of required) if (!existsSync(join(root, path))) fail(`${label}: missing ${path}`)
  const openai = existsSync(join(root, 'agents/openai.yaml'))
    ? readFileSync(join(root, 'agents/openai.yaml'), 'utf8')
    : ''
  for (const field of ['display_name:', 'short_description:', 'default_prompt:', 'allow_implicit_invocation:']) {
    if (!openai.includes(field)) fail(`${label}: agents/openai.yaml missing ${field}`)
  }
}

validate(source, 'plugin skill')
validate(local, 'repository-local skill')

if (existsSync(source) && existsSync(local)) {
  const sourceFiles = filesBelow(source)
  const localFiles = filesBelow(local)
  if (JSON.stringify(sourceFiles) !== JSON.stringify(localFiles)) {
    fail('repository-local skill file list differs from plugin skill; run npm run sync:skill')
  } else {
    for (const path of sourceFiles) {
      const left = readFileSync(join(source, path))
      const right = readFileSync(join(local, path))
      if (!left.equals(right)) fail(`repository-local skill differs at ${path}; run npm run sync:skill`)
    }
  }
}

for (const path of [
  'prompts/run-experiment.md',
  'prompts/run-experiment.zh-CN.md',
  'schemas/chaos-run.schema.json',
  'schemas/scenario.schema.json',
]) {
  if (!existsSync(resolve(path))) fail(`missing ${path}`)
}

if (errors.length) {
  for (const error of errors) process.stderr.write(`skill validation: ${error}\n`)
  process.exit(1)
}
process.stdout.write(`skill validation: PASS (${relative(process.cwd(), source)})\n`)
