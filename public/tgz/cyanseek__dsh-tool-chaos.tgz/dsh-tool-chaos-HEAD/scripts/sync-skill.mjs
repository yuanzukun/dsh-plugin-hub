#!/usr/bin/env node

import { cpSync, mkdirSync, rmSync } from 'node:fs'
import { dirname, resolve } from 'node:path'

const source = resolve('plugins/dsh-tool-chaos/skills/dsh-chaos-test')
const destination = resolve('.agents/skills/dsh-chaos-test')
mkdirSync(dirname(destination), { recursive: true })
rmSync(destination, { recursive: true, force: true })
cpSync(source, destination, { recursive: true })
process.stdout.write(`${destination}\n`)
