## Problem and user impact

## DSH/public contract relied upon

## Change

## Safety and blast radius

## Reproducible scenario

## Evidence

- [ ] `npm run typecheck`
- [ ] `npm test`
- [ ] `npm run verify`
- [ ] `npm pack --dry-run`
- [ ] Real DSH consumer smoke when public API/compatibility changed

## Compatibility and rollback

## Documentation/changelog
