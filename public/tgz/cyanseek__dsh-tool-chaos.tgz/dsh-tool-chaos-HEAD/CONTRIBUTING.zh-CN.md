# 为 dsh-tool-chaos 贡献

[English](CONTRIBUTING.md) | 简体中文

感谢你帮助 DSH 韧性测试变得可复现。我们欢迎运行时行为、场景、报告、兼容性证据、文档和集成方面的贡献。

## 编码前

1. 搜索现有 issue 与 discussion；
2. 阅读本文以及相关源码/测试；
3. 新增公开行为时，用 issue 或 draft PR 写清用户需求、DSH 扩展点、安全边界和证据计划；
4. 保持改动聚焦。基础设施级混沌、安全扫描器或无关 Agent 框架应独立成项目。

## 开发

需要 Node.js 22.19+ 或 24+。

```bash
npm install
npm run check
```

## 设计规则

- 保持确定性：seed + rule id + tool + 稳定参数 + match index；
- 保持安全默认值：禁用、dry-run、空规则、禁止全局通配；
- 使用公开 DSH/Cordis seam，不修改 Agent loop；
- function plugin 只能 named export，禁止 default export；
- 环绕分发必须保留调用方取消、等待工作停止，并在 `finally` 恢复 `exec.signal`；
- patch row 替换完整 config，示例必须重述依赖的所有字段；
- 运行时引擎与 DSH 解耦；
- fixture 中禁止包含真实凭据或用户 session 数据。

## 变更对应的最低证据

| 变更 | 最低证据 |
|---|---|
| 规则/配置 | 校验和确定性引擎测试 |
| 运行时 action | 委托、结果、取消的 adapter 测试 |
| reporter | 精确 JSONL 输出测试 |
| CLI | 非交互子进程测试 |
| Skill | `npm run validate:skill` 与触发描述检查 |
| DSH 兼容性 | 隔离 profile dump、dry-run 和真实注入证据 |

真实 DSH consumer 结果必须标明版本和平台。未执行的环境门禁不能标为通过。

## Pull Request

PR 应包含：用户需求与故障模式、变更的文件和公开契约、实际执行命令、确定性场景与预期 reporter 事件、接口变化对应的 DSH 来源、兼容性/迁移影响、安全影响。

## 提交、发布与许可

使用清晰的祈使句 commit。发布由维护者基于已审查 commit 完成；合并不代表立即发布。没有明确授权时，Agent 不得 publish、tag 或修改 remote。

贡献内容以本仓库 MIT License 授权。
