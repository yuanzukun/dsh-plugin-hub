import test from 'node:test'
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { Context } from '@deepseek-ai/cordis'
import { ToolCallId } from '@deepseek-ai/dsh-llm'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime, { defineTool } from '@deepseek-ai/dsh-tools'
import { apply } from '../lib/runtime.js'

const require = createRequire(import.meta.url)
const toolsPackage = require('@deepseek-ai/dsh-tools/package.json')

const signal = () => new AbortController().signal

function textTool(name, execute) {
  return defineTool({
    name,
    description: `${name} test fixture`,
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    execute,
  })
}

async function setup(config) {
  const ctx = new Context()
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  apply(ctx, config)
  return ctx
}

test('real DSH 0.1.7-rc.2 registry preserves dry-run behavior and emits evidence', async () => {
  assert.equal(toolsPackage.version, '0.1.7-rc.2')
  const ctx = await setup({
    enabled: true,
    dryRun: true,
    rules: [{ id: 'preview', tool: 'echo', action: 'error' }],
  })
  const decisions = []
  ctx.on('tool-chaos/decision', decision => decisions.push(decision))
  ctx.tools.register(textTool('echo', async () => 'ok'))

  const result = await ctx.tools.execute({ signal: signal(), callId: ToolCallId('dry-root'), name: 'echo', arguments: {} })
  assert.equal(result.isError, false, JSON.stringify(result))
  assert.equal(result.value, 'ok')
  assert.equal(decisions.length, 1)
  assert.equal(decisions[0].dryRun, true)
  assert.equal(decisions[0].injected, false)
})

test('real DSH 0.1.7-rc.2 registry maps deny, error, delay, and block to their native phases', async () => {
  const cases = [
    { action: 'deny', expectedPhase: 'pre', bodyCalls: 0, code: undefined },
    { action: 'error', expectedPhase: 'execute', bodyCalls: 0, code: 'CHAOS_INJECTED' },
    { action: 'delay', expectedPhase: 'execute', bodyCalls: 1, isError: false },
    { action: 'block', expectedPhase: 'post', bodyCalls: 1, code: undefined },
  ]

  for (const fixture of cases) {
    let bodyCalls = 0
    const decisions = []
    const ctx = await setup({
      enabled: true,
      dryRun: false,
      rules: [{ id: fixture.action, tool: 'target', action: fixture.action, delayMs: 5 }],
    })
    ctx.on('tool-chaos/decision', decision => decisions.push(decision))
    ctx.tools.register(textTool('target', async () => {
      bodyCalls += 1
      return 'ok'
    }))

    const result = await ctx.tools.execute({
      signal: signal(),
      callId: ToolCallId(`root-${fixture.action}`),
      name: 'target',
      arguments: {},
    })
    assert.equal(result.isError, fixture.isError ?? true, fixture.action)
    assert.equal(bodyCalls, fixture.bodyCalls, fixture.action)
    assert.equal(decisions[0]?.phase, fixture.expectedPhase, fixture.action)
    assert.equal(result.error?.info?.code, fixture.code, fixture.action)
  }
})

test('real DSH 0.1.7-rc.2 registry abort reaches quiescence and restores the upstream signal', async () => {
  const ctx = await setup({
    enabled: true,
    dryRun: false,
    rules: [{ id: 'abort', tool: 'wait', action: 'abort', delayMs: 10 }],
  })
  let settled = false
  let observedExecution
  ctx.on('tools/result', exec => { observedExecution = exec })
  ctx.tools.register(textTool('wait', async (_args, exec) => {
    await new Promise(resolve => exec.signal.addEventListener('abort', resolve, { once: true }))
    settled = true
    return 'stopped'
  }))

  const upstream = signal()
  const result = await ctx.tools.execute({ signal: upstream, callId: ToolCallId('root-abort'), name: 'wait', arguments: {} })
  assert.equal(result.isError, true)
  assert.equal(result.error?.info?.code, 'CHAOS_ABORTED')
  assert.equal(settled, true)
  assert.equal(observedExecution?.signal, upstream)
})

test('real DSH 0.1.7-rc.2 registry distinguishes nested Code Mode-style dispatch identity', async () => {
  const ctx = await setup({
    enabled: true,
    dryRun: false,
    rules: [{ id: 'nested-only', tool: 'inner', action: 'error', scope: 'nested' }],
  })
  const decisions = []
  ctx.on('tool-chaos/decision', decision => decisions.push(decision))
  ctx.tools.register(textTool('inner', async () => 'inner-ok'))
  ctx.tools.register(textTool('outer', async (_args, exec) => {
    const nested = await ctx.tools.execute({
      signal: exec.signal,
      callId: ToolCallId('nested-call'),
      rootCallId: exec.rootCallId,
      parent: exec.token,
      name: 'inner',
      arguments: {},
    })
    return nested.isError ? 'recovered' : 'unexpected-success'
  }))

  const direct = await ctx.tools.execute({ signal: signal(), callId: ToolCallId('direct-inner'), name: 'inner', arguments: {} })
  assert.equal(direct.isError, false)
  const outer = await ctx.tools.execute({ signal: signal(), callId: ToolCallId('outer-root'), name: 'outer', arguments: {} })
  assert.equal(outer.isError, false)
  assert.equal(outer.value, 'recovered')
  assert.equal(decisions.length, 1)
  assert.equal(decisions[0].nested, true)
  assert.equal(decisions[0].rootCallId, 'outer-root')
})
