import test from 'node:test'
import assert from 'node:assert/strict'
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'

const cli = resolve('bin/dsh-tool-chaos.mjs')

function run(args, cwd = process.cwd(), env = {}) {
  return spawnSync(process.execPath, [cli, ...args], {
    cwd,
    encoding: 'utf8',
    env: { ...process.env, ...env },
  })
}

function executable(path, body) {
  writeFileSync(path, `#!/usr/bin/env node\n${body}`, 'utf8')
  chmodSync(path, 0o755)
  return path
}


test('CLI help exposes the autonomous entry points', () => {
  const result = run(['help'])
  assert.equal(result.status, 0)
  assert.match(result.stdout, /install-skill/)
  assert.match(result.stdout, /codex/)
  assert.match(result.stdout, /install-plugin/)
})

test('doctor emits parseable machine-readable diagnostics', () => {
  const result = run(['doctor', '--json'])
  assert.ok([0, 2].includes(result.status))
  const report = JSON.parse(result.stdout)
  assert.equal(report.tool, 'dsh-tool-chaos')
  assert.equal(typeof report.node.supported, 'boolean')
  assert.equal(typeof report.readyForPlugin, 'boolean')
})

test('init writes a safe dry-run patch', () => {
  const directory = mkdtempSync(join(tmpdir(), 'dsh-chaos-cli-'))
  const target = join(directory, 'retry.patch.yml')
  const result = run(['init', target, '--preset', 'retry'])
  assert.equal(result.status, 0, result.stderr)
  const text = readFileSync(target, 'utf8')
  assert.match(text, /enabled: true/)
  assert.match(text, /dryRun: true/)
  assert.match(text, /maxInjections: 1/)
  assert.doesNotMatch(text, /allowGlobalWildcard: true/)
})

test('prompt appends the user requirement to the canonical workflow', () => {
  const result = run(['prompt', 'prove retry recovery'])
  assert.equal(result.status, 0, result.stderr)
  assert.match(result.stdout, /autonomous experiment prompt/i)
  assert.match(result.stdout, /prove retry recovery/)
})

test('install-skill copies a complete Codex-discoverable skill', () => {
  const project = mkdtempSync(join(tmpdir(), 'dsh-chaos-skill-'))
  const result = run(['install-skill', '--project', project])
  assert.equal(result.status, 0, result.stderr)
  const root = join(project, '.agents', 'skills', 'dsh-chaos-test')
  assert.equal(existsSync(join(root, 'SKILL.md')), true)
  assert.equal(existsSync(join(root, 'agents', 'openai.yaml')), true)
  assert.equal(existsSync(join(root, 'scripts', 'dsh-chaos.mjs')), true)
})


test('run completes baseline, dry-run, and real-injection evidence through a fake DSH executable', () => {
  const directory = mkdtempSync(join(tmpdir(), 'dsh-chaos-run-'))
  const fakeDsh = executable(join(directory, 'fake-dsh.mjs'), String.raw`
import { readFileSync } from 'node:fs'
const args = process.argv.slice(2)
if (args.includes('--help')) {
  console.log('fake dsh')
  process.exit(0)
}
if (args.includes('--dump-config')) {
  console.log('- id: tool-chaos\n- id: tool-chaos-reporter')
  process.exit(0)
}
if (args[0] === 'plugin') process.exit(0)
const patchIndex = args.indexOf('--patch')
if (patchIndex === -1) {
  console.error('missing patch')
  process.exit(9)
}
const patch = readFileSync(args[patchIndex + 1], 'utf8')
console.error("configured reporter prefix: 'DSH_TOOL_CHAOS_EVENT '")
console.log('RECOVERED')
const enabled = /^\s*enabled:\s*true$/m.test(patch)
if (enabled) {
  const dryRun = /^\s*dryRun:\s*true$/m.test(patch)
  const event = process.env.FAKE_DSH_INVALID_EVENT === '1' ? { injected: true } : {
    plugin: 'dsh-tool-chaos', version: 1, ruleId: 'first-web-error', action: 'error',
    phase: 'execute', tool: 'web_fetch', callId: 'call-1', rootCallId: 'call-1',
    nested: false, matchIndex: 1, triggerIndex: 1, probability: 1, sample: 0,
    fingerprint: '00000000', dryRun, injected: !dryRun, message: 'deterministic failure',
  }
  console.error('DSH_TOOL_CHAOS_EVENT ' + JSON.stringify(event))
}
`)
  const dryPatch = join(directory, 'dry-run.patch.yml')
  const init = run(['init', dryPatch, '--preset', 'retry'], directory)
  assert.equal(init.status, 0, init.stderr)
  const dryText = readFileSync(dryPatch, 'utf8')
  const baselinePatch = join(directory, 'baseline.patch.yml')
  const experimentPatch = join(directory, 'experiment.patch.yml')
  writeFileSync(baselinePatch, dryText.replace('enabled: true', 'enabled: false'), 'utf8')
  writeFileSync(experimentPatch, dryText.replace('    dryRun: true', '    dryRun: false'), 'utf8')
  const env = { DSH_TOOL_CHAOS_DSH_BIN: fakeDsh }

  const cases = [
    ['baseline', baselinePatch, 'baseline-passed'],
    ['dry-run', dryPatch, 'preview'],
    ['experiment', experimentPatch, 'passed'],
  ]
  for (const [mode, patch, verdict] of cases) {
    const output = join(directory, `reports-${mode}`)
    const result = run([
      'run', '--mode', mode, '--profile', 'chaos-test', '--patch', patch,
      '--task', 'recover from one failure', '--expect', 'RECOVERED',
      '--output', output, '--no-install', '--json',
    ], directory, env)
    assert.equal(result.status, 0, `${mode}: ${result.stderr}`)
    const payload = JSON.parse(result.stdout)
    assert.equal(payload.report.verdict, verdict)
    assert.deepEqual(payload.report.chaos.parseErrors, [])
    assert.equal(existsSync(payload.artifacts.jsonPath), true)
    assert.equal(existsSync(payload.artifacts.markdownPath), true)
  }

  const mismatch = run([
    'run', '--mode', 'baseline', '--profile', 'chaos-test', '--patch', dryPatch,
    '--task', 'reject a mismatched mode', '--output', join(directory, 'mismatch'),
    '--no-install', '--json',
  ], directory, env)
  assert.equal(mismatch.status, 1)
  assert.match(mismatch.stderr, /baseline patch requires tool-chaos config enabled: false/)

  const invalidEvidence = run([
    'run', '--mode', 'experiment', '--profile', 'chaos-test', '--patch', experimentPatch,
    '--task', 'reject malformed evidence', '--expect', 'RECOVERED',
    '--output', join(directory, 'invalid-evidence'), '--no-install', '--json',
  ], directory, { ...env, FAKE_DSH_INVALID_EVENT: '1' })
  assert.equal(invalidEvidence.status, 2, invalidEvidence.stderr)
  const invalidPayload = JSON.parse(invalidEvidence.stdout)
  assert.equal(invalidPayload.report.verdict, 'inconclusive')
  assert.equal(invalidPayload.report.chaos.parseErrors.length, 1)
})

test('install-codex-plugin materializes a valid local marketplace and invokes Codex idempotently', () => {
  const directory = mkdtempSync(join(tmpdir(), 'dsh-chaos-codex-'))
  const state = join(directory, 'marketplace-added')
  const fakeCodex = executable(join(directory, 'fake-codex.mjs'), String.raw`
import { existsSync, writeFileSync } from 'node:fs'
const args = process.argv.slice(2)
const state = process.env.FAKE_CODEX_STATE
if (args.includes('--version')) {
  console.log('codex-cli 0.test')
  process.exit(0)
}
if (args[0] === 'plugin' && args[1] === 'list') {
  console.log(existsSync(state)
    ? JSON.stringify([{ name: 'dsh-tool-chaos', marketplaceName: 'dsh-tool-chaos' }])
    : '[]')
  process.exit(0)
}
if (args[0] === 'plugin' && args[1] === 'marketplace' && args[2] === 'add') {
  writeFileSync(state, 'ok')
  process.exit(0)
}
if (args[0] === 'plugin' && args[1] === 'remove') process.exit(0)
if (args[0] === 'plugin' && args[1] === 'add') {
  console.log(JSON.stringify({ pluginId: args[2], installed: true }))
  process.exit(0)
}
console.error('unexpected fake codex args: ' + args.join(' '))
process.exit(8)
`)
  const destination = join(directory, 'marketplace')
  mkdirSync(destination)
  const sentinel = join(destination, 'keep-me.txt')
  writeFileSync(sentinel, 'unrelated user content', 'utf8')
  const result = run([
    'install-codex-plugin', '--dir', destination, '--json',
  ], directory, {
    DSH_TOOL_CHAOS_CODEX_BIN: fakeCodex,
    FAKE_CODEX_STATE: state,
  })
  assert.equal(result.status, 0, result.stderr)
  const report = JSON.parse(result.stdout)
  assert.equal(report.installed, true)
  assert.equal(report.pluginId, 'dsh-tool-chaos@dsh-tool-chaos')
  assert.match(report.version, /\+codex\.\d{14}$/)
  const manifest = JSON.parse(readFileSync(
    join(destination, 'plugins', 'dsh-tool-chaos', '.codex-plugin', 'plugin.json'),
    'utf8',
  ))
  assert.equal(manifest.name, 'dsh-tool-chaos')
  assert.equal(existsSync(join(destination, '.agents', 'plugins', 'marketplace.json')), true)
  assert.equal(readFileSync(sentinel, 'utf8'), 'unrelated user content')
})

test('install-plugin uses exit code 3 when DSH rejects installation', () => {
  const directory = mkdtempSync(join(tmpdir(), 'dsh-chaos-install-'))
  const fakeDsh = executable(join(directory, 'fake-dsh.mjs'), String.raw`
const args = process.argv.slice(2)
if (args.includes('--dump-config')) process.exit(0)
if (args[0] === 'plugin') process.exit(7)
process.exit(0)
`)
  const result = run([
    'install-plugin', '--profile', 'chaos-test', '--source', 'local-package', '--json',
  ], directory, { DSH_TOOL_CHAOS_DSH_BIN: fakeDsh })
  assert.equal(result.status, 3)
  assert.match(result.stderr, /dsh plugin add failed with exit code 7/)
})

test('install-plugin does not mistake a reporter-only row for the main plugin', () => {
  const directory = mkdtempSync(join(tmpdir(), 'dsh-chaos-composition-'))
  const state = join(directory, 'installed')
  const fakeDsh = executable(join(directory, 'fake-dsh.mjs'), String.raw`
import { existsSync, writeFileSync } from 'node:fs'
const args = process.argv.slice(2)
const state = process.env.FAKE_DSH_STATE
if (args.includes('--dump-config')) {
  console.log(existsSync(state)
    ? '- id: tool-chaos\n- id: tool-chaos-reporter'
    : '- id: tool-chaos-reporter')
  process.exit(0)
}
if (args[0] === 'plugin') {
  writeFileSync(state, 'installed')
  process.exit(0)
}
process.exit(0)
`)
  const result = run([
    'install-plugin', '--profile', 'chaos-test', '--source', 'local-package', '--json',
  ], directory, {
    DSH_TOOL_CHAOS_DSH_BIN: fakeDsh,
    FAKE_DSH_STATE: state,
  })
  assert.equal(result.status, 0, result.stderr)
  const report = JSON.parse(result.stdout)
  assert.equal(report.changed, true)
  assert.equal(report.hasPlugin, true)
  assert.equal(report.hasReporter, true)
})
