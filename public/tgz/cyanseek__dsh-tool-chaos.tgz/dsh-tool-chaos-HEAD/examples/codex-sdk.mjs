/**
 * Run with:
 *   npm install @openai/codex-sdk dsh-tool-chaos
 *   node examples/codex-sdk.mjs "Prove retry recovery after one web_fetch error"
 */

import { readFile } from 'node:fs/promises'
import { Codex } from '@openai/codex-sdk'

const requirement = process.argv.slice(2).join(' ').trim()
  || 'Design and run the smallest safe DSH resilience experiment for this repository.'
const promptUrl = import.meta.resolve('dsh-tool-chaos/prompts/run-experiment.md')
const prompt = await readFile(new URL(promptUrl), 'utf8')

const codex = new Codex()
const thread = codex.startThread({
  workingDirectory: process.cwd(),
  sandboxMode: 'workspace-write',
  approvalPolicy: 'never',
})
const result = await thread.run(`${prompt}\n\n## User requirement\n\n${requirement}`)
process.stdout.write(`${result.finalResponse}\n`)
