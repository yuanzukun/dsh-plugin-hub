/**
 * Package-owned invariant companion for `@domitor-syh/dsh-ui-skin-switcher`.
 * @module @domitor-syh/dsh-ui-skin-switcher/invariant
 */

/* jscpd:ignore-start */
import type { Context } from '@deepseek-ai/cordis'
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants'

const PACKAGE_NAME = '@domitor-syh/dsh-ui-skin-switcher'

/** Cordis companion plugin name. */
export const name = 'client-ui-skin-switcher-invariant'
/** Service required before the companion can reserve package ownership. */
export const inject = ['invariants']

/**
 * No runtime invariant: a pure UI surface plugin whose slot registration
 * disposal is proven by the HMR-safety contract — it emits no cordis events and
 * owns no cross-plugin mutable state.
 */
const install: InvariantInstaller = () => {}

/**
 * Register this package's invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install))
/* jscpd:ignore-end */
