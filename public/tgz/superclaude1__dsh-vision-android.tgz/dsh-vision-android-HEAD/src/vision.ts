/** 视觉模型（OpenAI 兼容）配置。 */
export interface VisionConfig {
  baseUrl: string
  apiKey: string
  model: string
  maxTokens: number
  detail: 'low' | 'high'
  timeoutMs: number
}

/**
 * 把一张图片（base64）发给 OpenAI 兼容的视觉模型并返回文本回答。
 * 图片格式约定为 PNG；API 兼容 JPEG/PNG/GIF/WebP。
 */
export async function analyzeImage(
  imageBase64: string,
  prompt: string,
  cfg: VisionConfig,
  signal?: AbortSignal,
): Promise<string> {
  if (!cfg.apiKey) throw new Error('vision api key not configured (set visionApiKey or DSH_VISION_API_KEY)')
  const url = `${cfg.baseUrl.replace(/\/+$/, '')}/chat/completions`
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), cfg.timeoutMs)
  const onAbort = () => controller.abort()
  signal?.addEventListener('abort', onAbort)
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify({
        model: cfg.model,
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: prompt },
              { type: 'image_url', image_url: { url: `data:image/png;base64,${imageBase64}`, detail: cfg.detail } },
            ],
          },
        ],
        temperature: 0.2,
        max_tokens: cfg.maxTokens,
      }),
      signal: controller.signal,
    })
    if (!res.ok) {
      const body = await res.text().catch(() => '')
      throw new Error(`vision api ${res.status}: ${body.slice(0, 500)}`)
    }
    const data = (await res.json()) as {
      choices?: { message?: { content?: unknown } }[]
    }
    const content = data.choices?.[0]?.message?.content
    if (typeof content !== 'string') throw new Error('vision api returned no text content')
    return content
  } finally {
    clearTimeout(timer)
    signal?.removeEventListener('abort', onAbort)
  }
}

/** 从模型输出中提取 JSON（容忍 ```json 围栏与前后杂文）。 */
export function extractJson(text: string): unknown {
  const cleaned = text.replace(/```json|```/g, '').trim()
  try {
    return JSON.parse(cleaned)
  } catch {
    // fall through
  }
  const m = cleaned.match(/[\{\[][\s\S]*[\}\]]/)
  if (m) {
    try {
      return JSON.parse(m[0])
    } catch {
      // fall through
    }
  }
  return null
}
