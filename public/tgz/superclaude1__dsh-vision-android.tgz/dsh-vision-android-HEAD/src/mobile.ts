import { mkdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { screencap, type AdbConfig } from './adb'
import { analyzeImage, extractJson, type VisionConfig } from './vision'

export interface UiElement {
  label: string
  role: string
  x: number
  y: number
}

export interface UiAnalysis {
  description: string
  elements: UiElement[]
  screenshotPath: string
}

/** 标准 UI 分析提示词：要求模型返回带像素中心坐标的 JSON。 */
export const UI_ANALYSIS_PROMPT = [
  'You are a mobile UI testing assistant. This is a screenshot of an Android app.',
  'Answer with ONLY one JSON object, no markdown, shaped exactly like:',
  '{"description":"<one sentence: which screen this is and its state>",',
  '"elements":[{"label":"<visible text or icon name>","role":"button|input|tab|list-item|icon|text",',
  '"x":<center pixel x>,"y":<center pixel y>}]}',
  'List EVERY interactive element (buttons, tabs, list items, inputs, icons) with pixel-center coordinates.',
  'Coordinates must be integers within the screenshot bounds (0-1080 x, 0-2400 y).',
].join(' ')

/** 把模型输出规整成 UiAnalysis（容错：JSON 解析失败时把原文当描述）。 */
export function parseUiAnalysis(text: string, screenshotPath: string): UiAnalysis {
  const raw = extractJson(text)
  const obj: unknown = raw ?? { description: text.trim().slice(0, 300), elements: [] }
  const source = obj && typeof obj === 'object' ? (obj as Record<string, unknown>) : {}
  const description = typeof source.description === 'string' ? source.description : ''
  const list = Array.isArray(source.elements)
    ? source.elements
    : Array.isArray(source)
      ? source
      : []
  const elements: UiElement[] = list
    .map((e) => {
      const o = (e ?? {}) as Record<string, unknown>
      return {
        label: String(o.label ?? ''),
        role: String(o.role ?? 'text'),
        x: Math.round(Number(o.x) || 0),
        y: Math.round(Number(o.y) || 0),
      }
    })
    .filter((e) => e.label && e.x > 0 && e.y > 0)
  return { description, elements, screenshotPath }
}

export interface MobileRunner {
  adb: AdbConfig
  vision: VisionConfig
  screenshotDir: string
}

/**
 * 核心闭环：截屏 → 存盘 → 视觉模型理解 → 返回屏幕描述 + 可点击元素坐标。
 */
export async function mobileLook(runner: MobileRunner, signal?: AbortSignal): Promise<UiAnalysis> {
  const png = await screencap(runner.adb, signal)
  await mkdir(runner.screenshotDir, { recursive: true })
  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const screenshotPath = join(runner.screenshotDir, `shot-${stamp}.png`)
  await writeFile(screenshotPath, png)
  const answer = await analyzeImage(png.toString('base64'), UI_ANALYSIS_PROMPT, runner.vision, signal)
  return parseUiAnalysis(answer, screenshotPath)
}
