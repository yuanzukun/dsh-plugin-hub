import { readFile, mkdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import Schema from '@deepseek-ai/schemastery'
import { runAdb, screencap, uiDump, deviceOnline, screenSize, type AdbConfig } from './adb'
import { analyzeImage, type VisionConfig } from './vision'
import { mobileLook, type MobileRunner } from './mobile'

// 供独立脚本与测试直接复用（demo/集成测试走打包产物 lib/index.js）
export { mobileLook, parseUiAnalysis, UI_ANALYSIS_PROMPT } from './mobile'
export { analyzeImage, extractJson } from './vision'
export { runAdb, screencap, uiDump, parseUiXml, deviceOnline, screenSize } from './adb'

export const name = 'dsh-vision-android'

export const inject = ['tools']

export interface Config {
  visionBaseUrl: string
  visionApiKey: string
  visionModel: string
  visionMaxTokens: number
  visionDetail: 'low' | 'high'
  visionTimeoutMs: number
  adbPath: string
  adbTimeoutMs: number
  screenshotDir: string
}

export const Config: Schema<Config> = Schema.object({
  visionBaseUrl: Schema.string().default('https://api.openai.com/v1'),
  visionApiKey: Schema.string().default(''),
  visionModel: Schema.string().default('gpt-5.6-luna'),
  visionMaxTokens: Schema.number().default(2000),
  visionDetail: Schema.union(['low', 'high'] as const).default('high'),
  visionTimeoutMs: Schema.number().default(120000),
  adbPath: Schema.string().default('adb'),
  adbTimeoutMs: Schema.number().default(30000),
  screenshotDir: Schema.string().default('.dsh-mobile-shots'),
})

const KEYCODES: Record<string, number> = {
  back: 4,
  home: 3,
  enter: 66,
  tab: 61,
  esc: 111,
  space: 62,
  del: 67,
  power: 26,
  volume_up: 24,
  volume_down: 25,
  menu: 82,
  app_switch: 187,
  dpad_up: 19,
  dpad_down: 20,
  dpad_left: 21,
  dpad_right: 22,
}

export function apply(ctx: Context, config: Config) {
  const vision: VisionConfig = {
    baseUrl: (config.visionBaseUrl || process.env.DSH_VISION_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, ''),
    apiKey: config.visionApiKey || process.env.DSH_VISION_API_KEY || '',
    model: config.visionModel || process.env.DSH_VISION_MODEL || 'gpt-5.6-luna',
    maxTokens: config.visionMaxTokens,
    detail: config.visionDetail,
    timeoutMs: config.visionTimeoutMs,
  }
  const adb: AdbConfig = {
    adbPath: config.adbPath || process.env.ADB || 'adb',
    timeoutMs: config.adbTimeoutMs,
  }
  const runner: MobileRunner = { adb, vision, screenshotDir: config.screenshotDir }

  console.log(`[vision-android] loaded: model=${vision.model} baseUrl=${vision.baseUrl} adb=${adb.adbPath}`)

  const requireDevice = async (signal?: AbortSignal): Promise<void> => {
    if (!(await deviceOnline(adb, signal))) {
      throw new Error('no android device/emulator online (run adb devices to check)')
    }
  }

  // ---- vision_ask：通用多模态 ----
  ctx.tools.register(defineTool({
    name: 'vision_ask',
    description:
      'Send a local image file (PNG/JPEG/WebP/GIF, e.g. a saved screenshot) to the vision model and ask a question about it. ' +
      'Use this whenever you need multimodal understanding: read UI screenshots, diagrams, photos. Returns the model\'s text answer.',
    parameters: {
      path: { type: 'string', required: true, description: 'Absolute path to the image file' },
      question: { type: 'string', required: true, description: 'What to ask about the image' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      const data = await readFile(args.path)
      return analyzeImage(data.toString('base64'), args.question, vision, exec.signal)
    },
  }))

  // ---- mobile_screenshot：只截图不分析 ----
  ctx.tools.register(defineTool({
    name: 'mobile_screenshot',
    description: 'Capture a screenshot of the connected Android device/emulator and save it as PNG. Returns the file path.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(_args, exec) {
      await requireDevice(exec.signal)
      const png = await screencap(adb, exec.signal)
      await mkdir(runner.screenshotDir, { recursive: true })
      const stamp = new Date().toISOString().replace(/[:.]/g, '-')
      const path = join(runner.screenshotDir, `shot-${stamp}.png`)
      await writeFile(path, png)
      return path
    },
  }))

  // ---- mobile_look：截屏 + 视觉理解（核心闭环）----
  ctx.tools.register(defineTool({
    name: 'mobile_look',
    description:
      'Screenshot the connected Android device, then ask the vision model to describe the screen and list every ' +
      'interactive UI element with its pixel-center coordinates. Returns description, screenshot path, and elements ' +
      '[{label, role, x, y}] ready to feed into mobile_tap. This is the core of vision-driven UI testing: look, then tap.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        properties: {
          description: { type: 'string' },
          screenshotPath: { type: 'string' },
          elements: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                label: { type: 'string' },
                role: { type: 'string' },
                x: { type: 'number' },
                y: { type: 'number' },
              },
              additionalProperties: false,
            },
          },
        },
        additionalProperties: false,
      },
      render: (_args, value) => [{
        type: 'text',
        text: `${value.description}\nscreenshot: ${value.screenshotPath}\nelements: ${JSON.stringify(value.elements)}`,
      }],
    },
    async execute(_args, exec) {
      await requireDevice(exec.signal)
      return mobileLook(runner, exec.signal)
    },
  }))

  // ---- mobile_dump：uiautomator 精确坐标（无视觉开销）----
  ctx.tools.register(defineTool({
    name: 'mobile_dump',
    description:
      'Dump the current Android UI hierarchy via uiautomator and return every element with visible text or ' +
      'content-description plus its pixel-center coordinates. Cheaper and more precise than mobile_look; use it to ' +
      'confirm exact tap targets before mobile_tap.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        properties: {
          elements: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                label: { type: 'string' },
                role: { type: 'string' },
                x: { type: 'number' },
                y: { type: 'number' },
              },
              additionalProperties: false,
            },
          },
        },
        additionalProperties: false,
      },
      render: (_args, value) => [{
        type: 'text',
        text: `elements: ${JSON.stringify(value.elements)}`,
      }],
    },
    async execute(_args, exec) {
      await requireDevice(exec.signal)
      const nodes = await uiDump(adb, exec.signal)
      return {
        elements: nodes.map((n) => ({ label: n.label, role: n.role, x: n.x, y: n.y })),
      }
    },
  }))

  // ---- mobile_tap：真实点击 ----
  ctx.tools.register(defineTool({
    name: 'mobile_tap',
    description: 'Perform a REAL tap on the Android device at pixel coordinates (x, y). Use after mobile_look or mobile_dump to pick a target.',
    parameters: {
      x: { type: 'number', required: true, description: 'Pixel x (within 1080 width)' },
      y: { type: 'number', required: true, description: 'Pixel y (within 2400 height)' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      await requireDevice(exec.signal)
      const { stderr } = await runAdb(['shell', 'input', 'tap', String(Math.round(args.x)), String(Math.round(args.y))], adb, exec.signal)
      const warn = stderr.toString('utf8').trim()
      return warn ? `tapped (${args.x}, ${args.y}) — ${warn}` : `tapped (${args.x}, ${args.y})`
    },
  }))

  // ---- mobile_swipe：滑动 ----
  ctx.tools.register(defineTool({
    name: 'mobile_swipe',
    description: 'Perform a REAL swipe gesture on the Android device from (x1, y1) to (x2, y2).',
    parameters: {
      x1: { type: 'number', required: true },
      y1: { type: 'number', required: true },
      x2: { type: 'number', required: true },
      y2: { type: 'number', required: true },
      durationMs: { type: 'number', description: 'Gesture duration in ms (default 300)' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      await requireDevice(exec.signal)
      await runAdb([
        'shell', 'input', 'swipe',
        String(Math.round(args.x1)), String(Math.round(args.y1)),
        String(Math.round(args.x2)), String(Math.round(args.y2)),
        String(Math.round(args.durationMs ?? 300)),
      ], adb, exec.signal)
      return `swiped (${args.x1},${args.y1}) -> (${args.x2},${args.y2})`
    },
  }))

  // ---- mobile_text：文本输入（ASCII）----
  ctx.tools.register(defineTool({
    name: 'mobile_text',
    description: 'Type text into the currently focused field on the Android device via "adb input text". NOTE: ASCII only (adb limitation); for Chinese text use an on-device IME.',
    parameters: {
      text: { type: 'string', required: true, description: 'Text to type (ASCII only)' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      await requireDevice(exec.signal)
      // adb 的 `input text` 用 %s 表示空格；直接传带空格的单参数会丢失空格（实测只输入首词）。
      const escaped = args.text.replace(/ /g, '%s')
      await runAdb(['shell', 'input', 'text', escaped], adb, exec.signal)
      return `typed: ${args.text}`
    },
  }))

  // ---- mobile_keyevent：按键 ----
  ctx.tools.register(defineTool({
    name: 'mobile_keyevent',
    description: `Send an Android key event. Supported keys: ${Object.keys(KEYCODES).join(', ')}.`,
    parameters: {
      key: { type: 'string', required: true, description: 'Key name, e.g. back' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      await requireDevice(exec.signal)
      const code = KEYCODES[args.key]
      if (!code) throw new Error(`unknown key "${args.key}"; supported: ${Object.keys(KEYCODES).join(', ')}`)
      await runAdb(['shell', 'input', 'keyevent', String(code)], adb, exec.signal)
      return `sent keyevent ${args.key} (${code})`
    },
  }))

  // ---- mobile_install：安装 APK ----
  ctx.tools.register(defineTool({
    name: 'mobile_install',
    description: 'Install an APK on the Android device with adb install -r (keeps app data). Returns install output.',
    parameters: {
      apkPath: { type: 'string', required: true, description: 'Absolute path to the APK on the host' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      await requireDevice(exec.signal)
      const { stdout, stderr } = await runAdb(['install', '-r', args.apkPath], adb, exec.signal)
      return `${stdout.toString('utf8').trim()}\n${stderr.toString('utf8').trim()}`.trim()
    },
  }))

  // ---- mobile_launch：启动应用 ----
  ctx.tools.register(defineTool({
    name: 'mobile_launch',
    description: 'Launch an app component on the Android device, e.g. com.storybrain.app/.MainActivity. If activity is omitted, uses monkey to start the package launcher.',
    parameters: {
      component: { type: 'string', description: 'Component like com.storybrain.app/.MainActivity' },
      package: { type: 'string', description: 'Package to launch when component is omitted' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      await requireDevice(exec.signal)
      if (args.component) {
        const { stdout } = await runAdb(['shell', 'am', 'start', '-n', args.component], adb, exec.signal)
        return stdout.toString('utf8').trim()
      }
      if (args.package) {
        const { stdout } = await runAdb(['shell', 'monkey', '-p', args.package, '1'], adb, exec.signal)
        return stdout.toString('utf8').trim()
      }
      throw new Error('provide component or package')
    },
  }))

  // ---- mobile_screen_size：分辨率（视觉坐标换算用）----
  ctx.tools.register(defineTool({
    name: 'mobile_screen_size',
    description: 'Return the device screen size in pixels (width x height). Useful to sanity-check vision coordinates.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        properties: {
          width: { type: 'number' },
          height: { type: 'number' },
        },
        additionalProperties: false,
      },
      render: (_args, value) => [{ type: 'text', text: `screen: ${value.width}x${value.height}` }],
    },
    async execute(_args, exec) {
      await requireDevice(exec.signal)
      return screenSize(adb, exec.signal)
    },
  }))

}
