import { spawn } from 'node:child_process'

/** adb 调用配置。 */
export interface AdbConfig {
  adbPath: string
  timeoutMs: number
}

export interface AdbResult {
  stdout: Buffer
  stderr: Buffer
}

/**
 * 运行一次 adb 命令。stdout/stderr 均以 Buffer 返回，保证二进制安全
 * （截屏必须走 exec-out + Buffer，不能经过文本转换）。
 */
export function runAdb(args: string[], cfg: AdbConfig, signal?: AbortSignal): Promise<AdbResult> {
  return new Promise((resolve, reject) => {
    const child = spawn(cfg.adbPath, args, {
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    })
    const out: Buffer[] = []
    const err: Buffer[] = []
    child.stdout.on('data', (c: Buffer) => out.push(c))
    child.stderr.on('data', (c: Buffer) => err.push(c))
    const timer = setTimeout(() => {
      child.kill()
      reject(new Error(`adb timeout after ${cfg.timeoutMs}ms: adb ${args.join(' ')}`))
    }, cfg.timeoutMs)
    const onAbort = () => child.kill()
    signal?.addEventListener('abort', onAbort)
    child.on('error', (e) => {
      clearTimeout(timer)
      signal?.removeEventListener('abort', onAbort)
      reject(new Error(`failed to spawn adb (${cfg.adbPath}): ${e.message}`))
    })
    child.on('close', (code) => {
      clearTimeout(timer)
      signal?.removeEventListener('abort', onAbort)
      const stdout = Buffer.concat(out)
      const stderr = Buffer.concat(err)
      if (code === 0) resolve({ stdout, stderr })
      else reject(new Error(`adb exit ${code}: ${stderr.toString('utf8').trim()}`))
    })
  })
}

/** 截取当前设备屏幕，返回 PNG Buffer。 */
export async function screencap(cfg: AdbConfig, signal?: AbortSignal): Promise<Buffer> {
  const { stdout } = await runAdb(['exec-out', 'screencap', '-p'], cfg, signal)
  if (stdout.length < 8 || stdout[0] !== 0x89) {
    throw new Error('screencap returned an invalid PNG payload')
  }
  return stdout
}

/** 获取当前设备是否在线。 */
export async function deviceOnline(cfg: AdbConfig, signal?: AbortSignal): Promise<boolean> {
  const { stdout } = await runAdb(['devices'], cfg, signal)
  return /device\s*$/.test(stdout.toString('utf8').split('\n').slice(1).join('\n').trim())
}

/** 获取屏幕物理分辨率（宽x高，像素）。 */
export async function screenSize(cfg: AdbConfig, signal?: AbortSignal): Promise<{ width: number; height: number }> {
  const { stdout } = await runAdb(['shell', 'wm', 'size'], cfg, signal)
  const text = stdout.toString('utf8')
  const m = text.match(/(\d+)x(\d+)/)
  if (!m) throw new Error(`cannot parse wm size output: ${text}`)
  return { width: Number(m[1]), height: Number(m[2]) }
}

export interface UiNode {
  label: string
  role: string
  x: number
  y: number
  clickable: boolean
}

/** 通过 uiautomator dump 抓取界面元素（精确坐标兜底，不依赖视觉模型）。 */
export async function uiDump(cfg: AdbConfig, signal?: AbortSignal): Promise<UiNode[]> {
  await runAdb(['shell', 'uiautomator', 'dump', '/sdcard/dsh_window_dump.xml'], cfg, signal)
  const { stdout } = await runAdb(['shell', 'cat', '/sdcard/dsh_window_dump.xml'], cfg, signal)
  return parseUiXml(stdout.toString('utf8'))
}

/** 解析 uiautomator XML（每行一个 <node>）。 */
export function parseUiXml(xml: string): UiNode[] {
  const nodes: UiNode[] = []
  const re = /<node[^>]*>/g
  let m: RegExpExecArray | null
  while ((m = re.exec(xml)) !== null) {
    const seg = m[0]
    const attr = (name: string): string => {
      const am = seg.match(new RegExp(`${name}="([^"]*)"`))
      return am ? am[1] : ''
    }
    const text = attr('text')
    const desc = attr('content-desc')
    const cls = attr('class')
    const clickable = attr('clickable') === 'true'
    const bm = attr('bounds').match(/\[(\d+),(\d+)\]\[(\d+),(\d+)\]/)
    if (!bm) continue
    const l = Number(bm[1]), t = Number(bm[2]), r = Number(bm[3]), b = Number(bm[4])
    const label = text || desc
    const role = clickable ? 'clickable' : (cls.includes('EditText') ? 'input' : 'text')
    if (!label) continue
    nodes.push({ label, role, x: Math.round((l + r) / 2), y: Math.round((t + b) / 2), clickable })
  }
  return nodes
}
