// 插件加载冒烟测试：验证 lib/index.js 可加载、Config schema 可校验、
// apply() 能完整注册全部工具（用假 ctx 模拟 Cordis 工具注册表）。
// 用法：node scripts/smoke.mjs（不需要真实 API Key / 设备）。
import { apply, Config } from '../lib/index.js'

const config = Config({}) // 全默认值即可：schema 校验通过即证明配置契约有效
console.log('config defaults ok:', JSON.stringify({ model: config.visionModel, baseUrl: config.visionBaseUrl, adb: config.adbPath }))

const registered = []
const fakeCtx = {
  tools: {
    register(tool) {
      if (!tool || typeof tool.name !== 'string' || typeof tool.execute !== 'function') {
        throw new Error(`malformed tool: ${JSON.stringify(tool && tool.name)}`)
      }
      if (typeof tool.output?.render !== 'function') throw new Error(`tool ${tool.name} missing output.render`)
      registered.push(tool.name)
    },
  },
}

apply(fakeCtx, config)
console.log('registered tools:', registered.join(', '))
console.log('count:', registered.length)

const expected = ['vision_ask', 'mobile_screenshot', 'mobile_look', 'mobile_dump', 'mobile_tap',
  'mobile_swipe', 'mobile_text', 'mobile_keyevent', 'mobile_install', 'mobile_launch', 'mobile_screen_size']
const missing = expected.filter((n) => !registered.includes(n))
if (missing.length) {
  console.error('SMOKE FAIL: missing tools', missing)
  process.exit(1)
}
console.log('SMOKE PASS ✅')
