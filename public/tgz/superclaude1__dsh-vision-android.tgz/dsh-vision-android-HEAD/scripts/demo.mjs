// 端到端 demo：截图 → 视觉理解 → 真实点击 → 再截图验证。
// 用法（在本目录）：node scripts/demo.mjs
// 前置：Android 模拟器/设备在线（adb devices）。
//
// 配置（环境变量）：
//   DSH_VISION_BASE_URL   OpenAI 兼容 API 地址（默认 https://api.openai.com/v1）
//   DSH_VISION_API_KEY    API Key（必填）
//   DSH_VISION_MODEL      视觉模型 ID（默认 gpt-5.6-luna）
//   ADB / ANDROID_HOME    本机 adb 路径
//   DSH_MOBILE_SHOTS      截图目录（默认 .dsh-mobile-shots）
import { mobileLook } from '../lib/index.js'
import { runAdb, deviceOnline } from '../lib/index.js'

const adbPath = process.env.ADB
  || (process.env.ANDROID_HOME ? `${process.env.ANDROID_HOME.replace(/\\+$/, '')}/platform-tools/adb.exe` : 'adb')

const adb = { adbPath, timeoutMs: 30000 }
const vision = {
  baseUrl: process.env.DSH_VISION_BASE_URL || 'https://api.openai.com/v1',
  apiKey: process.env.DSH_VISION_API_KEY || '',
  model: process.env.DSH_VISION_MODEL || 'gpt-5.6-luna',
  maxTokens: 2000,
  detail: 'high',
  timeoutMs: 120000,
}
const runner = { adb, vision, screenshotDir: process.env.DSH_MOBILE_SHOTS || '.dsh-mobile-shots' }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

if (!vision.apiKey) {
  console.error('缺少 DSH_VISION_API_KEY：请先设置环境变量后再运行。')
  process.exit(1)
}
if (!(await deviceOnline(adb))) {
  console.error('NO DEVICE: 请先启动模拟器 (adb devices 应显示 emulator-5554 device)')
  process.exit(1)
}

console.log('== STEP 1: mobile_look (截图 + 视觉理解) ==')
const look1 = await mobileLook(runner)
console.log('描述:', look1.description)
console.log('元素:', JSON.stringify(look1.elements, null, 2))
console.log('截图:', look1.screenshotPath)

const target = look1.elements.find((e) => e.role === 'list-item')
if (!target) {
  console.error('DEMO FAIL: 视觉模型没有找到可点击的列表项')
  process.exit(1)
}
console.log(`\n== STEP 2: 真实点击 "${target.label}" @ (${target.x}, ${target.y}) ==`)
await runAdb(['shell', 'input', 'tap', String(target.x), String(target.y)], adb)
await sleep(3000)

console.log('\n== STEP 3: 再次 mobile_look 验证界面变化 ==')
const look2 = await mobileLook(runner)
console.log('描述:', look2.description)
console.log('元素:', JSON.stringify(look2.elements.slice(0, 6), null, 2))
console.log(look2.description !== look1.description
  ? '\nDEMO PASS ✅ 视觉驱动真实点击闭环成立'
  : '\nDEMO FAIL ❌ 点击后界面未如预期变化')
process.exit(0)
