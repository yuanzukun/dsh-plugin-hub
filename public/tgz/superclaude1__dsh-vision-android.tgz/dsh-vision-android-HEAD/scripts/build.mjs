// 用 esbuild 把插件打成单文件 lib/index.js（自包含：dsh-tools/schemastery 全部打进产物，
// cordis 仅类型引用会被擦除），这样 overlay 加载和 profile 安装都不依赖外部解析。
import { mkdirSync } from 'node:fs'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { dirname, resolve } from 'node:path'

let esbuild
try {
  esbuild = await import('esbuild')
} catch {
  if (process.env.ESBUILD_PATH) {
    esbuild = await import(pathToFileURL(process.env.ESBUILD_PATH).href)
  } else {
    throw new Error('esbuild not found; run from the dsh checkout or set ESBUILD_PATH to esbuild/lib/main.js')
  }
}
const { build } = esbuild

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
mkdirSync(resolve(root, 'lib'), { recursive: true })

await build({
  entryPoints: [resolve(root, 'src/index.ts')],
  outfile: resolve(root, 'lib/index.js'),
  bundle: true,
  format: 'esm',
  platform: 'node',
  target: 'node20',
  sourcemap: false,
  minify: false,
  logLevel: 'info',
})

console.log('[vision-android] built lib/index.js')
