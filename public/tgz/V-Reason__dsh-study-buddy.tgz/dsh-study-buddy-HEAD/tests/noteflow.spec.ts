import { mkdir, mkdtemp, readFile, rm, stat, utimes, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { afterEach, beforeEach, describe, expect, test } from 'vitest'
import { VaultStore } from '../src/index.ts'
import { parseFrontmatter } from '../src/frontmatter.ts'
import { buildPlanRecord, isPlanExpired, planFileFor, readPlan, writePlan } from '../src/planstore.ts'
import { readSession, sessionFileFor, writeSession } from '../src/store.ts'

/**
 * 阶段 4b 端到端：**硬门禁在真实写入路径上的行为**。
 *
 * 这是需求 F2 / N1 的核心验收：门禁不只存在于 gate.ts 的单测里，而是真的挡住
 * `note_write`；并且每一条拒绝都必须**磁盘零改动**（断言文件不存在）。
 */

let dir = ''

const EXPECT_TEXT = [
  '# 笔记期望',
  '',
  '## 受众',
  '零基础能独立读完。',
  '',
  '## 文风',
  '书面技术体，短句，不用 emoji。',
  '',
  '- [检查] 禁止 🚀',
].join('\n')

beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), 'study-buddy-e2e-'))
  await writeFile(join(dir, '笔记期望.md'), EXPECT_TEXT, 'utf8')
})

afterEach(async () => {
  await rm(dir, { recursive: true, force: true })
})

function store(): VaultStore {
  return new VaultStore({ vaultRoot: dir, stateDir: '.study', fallbackDir: '未分类' })
}

const ROOT = '计算机通识/计算方法/第2章 线性方程组数值解法'
const ITEMS = [
  { title: '高斯消元法', path: `${ROOT}/直接法/高斯消元法.md`, sourceSection: '《计算方法》第2章 线性方程组数值解法 / 2.1节', order: 1 },
  { title: '列主元消元', path: `${ROOT}/直接法/列主元消元.md`, sourceSection: '《计算方法》第2章 线性方程组数值解法 / 2.2节', order: 2 },
]

async function exists(rel: string): Promise<boolean> {
  try {
    await readFile(join(dir, rel), 'utf8')
    return true
  } catch {
    return false
  }
}

/**
 * 走到"规划已确认"这一步（门禁第二环通过），返回 planId。
 *
 * **走真实确认入口**：早先这里直接手改 `.study/plans/<id>.json` 置位 `confirmed`，
 * 于是"用户点不出一个已确认的规划"与 `pnpm run check` 全绿同时成立
 * （2026-09-15 真机检查报告的 P0）。现在确认只经 `note_plan(action=confirm)`。
 */
async function planAndConfirm(
  s: VaultStore,
  items: Array<{ title: string; path: string; sourceSection?: string; order?: number }> = ITEMS,
  rootPath = ROOT,
): Promise<string> {
  const proposal = await s.notePlan({ rootPath, items, material: '《计算方法》' })
  const planId = /planId：(\d{11,12}_[0-9a-f]{6})/.exec(proposal)?.[1] as string
  await s.notePlan({ action: 'confirm', rootPath: planId })
  return planId
}

describe('阶段 4b 端到端：门禁与闭环', () => {
  test('note_library：期望文件缺失 → 明确指引；未读 → 提示；读后 → 已读', async () => {
    const s = store()
    const unread = await s.noteLibrary('check')
    expect(unread).toContain('笔记库状态')
    expect(unread).toContain('笔记期望尚未读取')
    await s.noteExpectGet()
    expect(await s.noteLibrary('check')).toContain('笔记期望：已读')
    await rm(join(dir, '笔记期望.md'), { force: true })
    const missing = await s.noteLibrary('check')
    expect(missing).toContain('笔记期望文件不存在')
    expect(missing).toContain('复制到 vault 根')
  })

  test('BUG-001 note_library 仅元数据变化仍为已读，正文变化提示已更新', async () => {
    const s = store()
    await s.noteExpectGet()
    const expectFile = join(dir, '笔记期望.md')
    // 只改时间戳（模拟 ACL/复制/改名刷新 ctime）：正文逐字未变
    const stamp = new Date('2020-01-02T03:04:05Z')
    await utimes(expectFile, stamp, stamp)
    expect(await s.noteLibrary('check')).toContain('- 笔记期望：已读')
    // 真正改正文后才要求重读
    await writeFile(expectFile, `${EXPECT_TEXT}\n\n## 追加条款\n多写例子。\n`, 'utf8')
    const changed = await s.noteLibrary('check')
    expect(changed).toContain('笔记期望已更新')
    expect(changed).not.toContain('笔记期望尚未读取')
    // 旧格式（三段式）签名同样不能静默放行
    await writeSession(sessionFileFor(dir), { expect: { signature: '1|2|3', rel: '笔记期望.md' } })
    expect(await s.noteLibrary('check')).toContain('笔记期望已更新')
  })

  test('硬门禁①：未读期望 → note_write 拒绝且磁盘零改动', async () => {
    const s = store()
    const planId = await planAndConfirm(s)
    await expect(s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文',
    })).rejects.toThrow(/未读取笔记期望/)
    expect(await exists(ITEMS[0].path)).toBe(false)
  })

  test('硬门禁①续：读过期望后用户又改了期望 → 必须重读（签名失效）', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    // 模拟用户中途改了期望
    await writeFile(join(dir, '笔记期望.md'), `${EXPECT_TEXT}\n\n## 追加条款\n多写例子。\n`, 'utf8')
    await expect(s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文',
    })).rejects.toThrow(/已更新/)
    expect(await exists(ITEMS[0].path)).toBe(false)
    // 重读后即可写入
    await s.noteExpectGet()
    const out = await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文内容。',
    })
    expect(out).toContain('已写入：')
    expect(await exists(ITEMS[0].path)).toBe(true)
  })

  test('硬门禁②：无规划 → 拒绝；未确认规划 → 拒绝', async () => {
    const s = store()
    await s.noteExpectGet()
    await expect(s.noteWrite({
      planId: '202610241200_abcdef', title: '高斯消元法', path: ITEMS[0].path, source: 'x', content: '正文',
    })).rejects.toThrow(/没有已确认的文件夹规划/)

    const proposal = await s.notePlan({ rootPath: ROOT, items: ITEMS })
    const planId = /planId：(\d{11,12}_[0-9a-f]{6})/.exec(proposal)?.[1] as string
    await expect(s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: 'x', content: '正文',
    })).rejects.toThrow(/规划尚未确认/)
    // 拒绝文案必须指向真实存在的入口（旧文案里的 note_plan(action=confirm) 曾经是空头支票）
    await expect(s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: 'x', content: '正文',
    })).rejects.toThrow(/note_plan\(\{ action: "confirm", rootPath: "\d{11,12}_[0-9a-f]{6}" \}\)/)
    expect(await exists(ITEMS[0].path)).toBe(false)

    // 确认之后同一条规划立刻可用（P0 修复的核心链路）
    await s.notePlan({ action: 'confirm', rootPath: planId })
    const out = await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文内容。',
    })
    expect(out).toContain('已写入：')
    expect(await exists(ITEMS[0].path)).toBe(true)
  })

  test('note_plan(action=confirm)：置位 confirmed 并接管 activePlanId；重复确认幂等', async () => {
    const s = store()
    await s.noteExpectGet()
    const proposal = await s.notePlan({ rootPath: ROOT, items: ITEMS, material: '《计算方法》' })
    const planId = /planId：(\d{11,12}_[0-9a-f]{6})/.exec(proposal)?.[1] as string
    const file = planFileFor(dir, planId, '.study')

    // 提案阶段：凭据已落盘但未确认（"提案只在对话里"指的是不落 vault 可见文件）
    expect((await readPlan(file))?.confirmed).toBe(false)

    const confirmed = await s.notePlan({ action: 'confirm', rootPath: planId })
    expect(confirmed).toContain(`已确认规划（planId：${planId}）`)
    expect(confirmed).toContain(ROOT)
    expect(confirmed).toContain('待落块 2 项：高斯消元法、列主元消元')
    expect(confirmed).toContain('note_write')
    expect((await readSession(sessionFileFor(dir, '.study'))).activePlanId).toBe(planId)
    const record = await readPlan(file)
    expect(record?.confirmed).toBe(true)
    expect(record?.confirmedAt).toBeTruthy()

    // 重复确认：幂等，不破坏已确认状态（不覆盖 confirmedAt）
    const before = record!.confirmedAt
    const again = await s.notePlan({ action: 'confirm', rootPath: planId })
    expect(again).toContain('规划已确认')
    expect((await readPlan(file))?.confirmedAt).toBe(before)
  })

  test('note_plan(action=confirm)：planId 缺失/传成目录/不存在 → 各自的修复提示，磁盘零改动', async () => {
    const s = store()
    await s.noteExpectGet()
    await expect(s.notePlan({ action: 'confirm', rootPath: '' }))
      .rejects.toThrow(/需要把 rootPath 传成要确认的 planId/)
    // 常见误用：把规划根目录当成 planId
    await expect(s.notePlan({ action: 'confirm', rootPath: ROOT }))
      .rejects.toThrow(/看着像目录/)
    await expect(s.notePlan({ action: 'confirm', rootPath: '202610241200_abcdef' }))
      .rejects.toThrow(/规划不存在或已损坏/)
    // 未知 action 会点名可用动作（confirm 不再缺席）
    await expect(s.notePlan({ action: 'bogus', rootPath: ROOT, items: ITEMS }))
      .rejects.toThrow(/可用 create \/ confirm \/ abandon/)
  })

  test('note_plan(action=confirm)：过期提案必须重新提案；确认后有效期从确认时刻重新起算', async () => {
    const s = store()
    await s.noteExpectGet()
    const proposal = await s.notePlan({ rootPath: ROOT, items: ITEMS })
    const planId = /planId：(\d{11,12}_[0-9a-f]{6})/.exec(proposal)?.[1] as string
    const file = planFileFor(dir, planId, '.study')

    // 搁置超过 TTL 再确认：拒绝，且不改任何状态（避免"过期确认"与"从确认时刻起算"自相矛盾）
    const stale = (await readPlan(file))!
    stale.createdAt = new Date(Date.now() - 48 * 3600_000).toISOString()
    await writePlan(file, stale)
    await expect(s.notePlan({ action: 'confirm', rootPath: planId })).rejects.toThrow(/规划已过期/)
    expect((await readPlan(file))?.confirmed).toBe(false)

    // 重新提案（新 planId）后确认：createdAt 被重置为确认时刻，之后的写入不再受旧提案时间拖累
    const fresh = await s.notePlan({ rootPath: ROOT, items: ITEMS })
    const freshId = /planId：(\d{11,12}_[0-9a-f]{6})/.exec(fresh)?.[1] as string
    const freshFile = planFileFor(dir, freshId, '.study')
    const aged = (await readPlan(freshFile))!
    // 20 小时：仍在 TTL 内（可确认），但已接近临界——确认必须把有效期重新拉满
    aged.createdAt = new Date(Date.now() - 20 * 3600_000).toISOString()
    await writePlan(freshFile, aged)
    expect(isPlanExpired(aged, 24)).toBe(false)
    await s.notePlan({ action: 'confirm', rootPath: freshId })
    const after = (await readPlan(freshFile))!
    expect(after.confirmed).toBe(true)
    expect(isPlanExpired(after, 24)).toBe(false)
    expect(Date.parse(after.createdAt)).toBeGreaterThan(Date.now() - 60_000)
    expect((await s.noteWrite({
      planId: freshId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文。',
    }))).toContain('已写入：')
  })

  test('硬门禁③：越界路径 → 拒绝并回显规划根', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await expect(s.noteWrite({
      planId, title: '高斯消元法', path: '游戏开发/别处/高斯消元法.md', source: 'x', content: '正文',
    })).rejects.toThrow(/不在本次规划范围/)
    expect(await exists('游戏开发/别处/高斯消元法.md')).toBe(false)
  })

  test('门禁④：标题不在规划里 / 同一规划内重复写入 → 拒绝', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await expect(s.noteWrite({
      planId, title: '没规划过的标题', path: ITEMS[0].path, source: 'x', content: '正文',
    })).rejects.toThrow(/不在本次规划内/)
    await s.noteWrite({ planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文。' })
    await expect(s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[1].path, source: 'x', content: '正文',
    })).rejects.toThrow(/已在本规划中写入过/)
  })

  test('闭环：期望 → 规划 → 落块 → 微目录 → 覆盖度（含 dryRun 不落盘）', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    const first = await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》',
      content: '## 直接法\n\n用初等行变换把系数矩阵化为上三角。',
    })
    // 缺微目录时提醒（需求 F3：每个主题目录都要有微目录）
    expect(first).toContain('还没有微目录')
    await s.noteWrite({
      planId, title: '列主元消元', path: ITEMS[1].path, source: '《计算方法》',
      content: '## 直接法\n\n主元过小时换行使算法稳定。',
    })

    const dry = await s.noteToc(`${ROOT}/直接法`, { dryRun: true })
    expect(dry).toContain('[dryRun]')
    expect(await exists(`${ROOT}/直接法/微目录.md`)).toBe(false)

    const toc = await s.noteToc(`${ROOT}/直接法`)
    expect(toc).toContain('已生成：')
    expect(toc).toContain('收录 2 块')
    const tocText = await readFile(join(dir, `${ROOT}/直接法/微目录.md`), 'utf8')
    expect(tocText).toContain('1. [[高斯消元法]]')
    expect(tocText).toContain('2. [[列主元消元]]')
    expect(tocText).toContain('note_toc:begin')

    // 微目录生成段可重跑（幂等），用户手写段保留（标题按目录名归一）
    await writeFile(join(dir, `${ROOT}/直接法/微目录.md`), `# 我的导读\n\n先看这两篇。\n\n${tocText.slice(tocText.indexOf('<!-- note_toc:begin -->'))}`, 'utf8')
    const again = await s.noteToc(`${ROOT}/直接法`)
    expect(again).toContain('先看这两篇。')
    expect(again).toContain('# 直接法')
    expect(again).not.toContain('我的导读')

    const overview = await s.noteOverview({ path: '计算机通识' })
    expect(overview).toContain('《计算方法》第2章 线性方程组数值解法——2 篇')
    expect(overview).toContain('节：2.1、2.2')
    expect(overview).toContain('已记录第 2 章')
  })

  test('note_list：不读正文即可导航，并标出缺微目录', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await s.noteWrite({ planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文。' })
    const root = await s.noteList({})
    expect(root).toContain('计算机通识/')
    const dirList = await s.noteList({ path: `${ROOT}/直接法` })
    expect(dirList).toContain('高斯消元法 · 块')
    expect(dirList).toContain('2.1节')
    // 叶子目录缺微目录：由父级列出时标出（叶子层自己列不出"缺"，因为还没有子目录行）
    const parentList = await s.noteList({ path: ROOT })
    expect(parentList).toContain('⚠ 缺微目录')
  })

  test('note_update：append 不需规划；replace 先存档（旧正文可 history/restore）', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》',
      content: '## 直接法\n\n第一版正文。',
    })

    const appended = await s.noteUpdate({ ref: '高斯消元法', action: 'append', changes: '补充一句。' })
    expect(appended).toContain('第一版正文。')
    expect(appended).toContain('补充一句。')

    const replaced = await s.noteUpdate({ ref: '高斯消元法', action: 'replace', newContent: '## 直接法\n\n第二版正文。' })
    expect(replaced).toContain('第二版正文。')
    expect(replaced).toContain('旧正文已存档')
    const fileText = await readFile(join(dir, ITEMS[0].path), 'utf8')
    expect(fileText).toContain('第二版正文。')
    expect(fileText).not.toContain('第一版正文。')
    // 正文里不留历史块（需求 R23）
    expect(fileText).not.toContain('<details>')

    const history = await s.noteHistory('高斯消元法')
    expect(history).toContain('历史存档（1 份')
    expect(history).toContain('replace 替换正文')

    const restored = await s.noteRestore('高斯消元法')
    expect(restored).toContain('已恢复')
    expect(await readFile(join(dir, ITEMS[0].path), 'utf8')).toContain('第一版正文。')
    // 恢复前的那一版也已存档，可来回
    expect(await s.noteHistory('高斯消元法')).toContain('历史存档（2 份')
  })

  test('BUG-002 append / definition dryRun 不落盘（五个 action 一致）', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》',
      content: '> 旧定位\n\n## 正文\n\n旧内容。',
    })
    const file = join(dir, ITEMS[0].path)
    const assertDryRun = async (args: Parameters<VaultStore['noteUpdate']>[0]): Promise<void> => {
      const before = await readFile(file, 'utf8')
      const stamp = new Date('2020-01-02T03:04:05Z')
      await utimes(file, stamp, stamp)
      const beforeStat = await stat(file)
      const out = await s.noteUpdate(args)
      expect(out).toMatch(/^\[dryRun\]/)
      expect(await readFile(file, 'utf8')).toBe(before)
      expect((await stat(file)).mtimeMs).toBe(beforeStat.mtimeMs)
    }
    await assertDryRun({ ref: '高斯消元法', action: 'append', changes: '不应写入的补充', dryRun: true })
    await assertDryRun({ ref: '高斯消元法', action: 'definition', summary: '不应写入的定位', dryRun: true })
    await assertDryRun({ ref: '高斯消元法', action: 'replace', newContent: '## 新正文\n\n不应写入的替换', dryRun: true })
    await assertDryRun({ ref: '高斯消元法', action: 'move', targetPath: `${ROOT}/直接法/不应移动.md`, dryRun: true })
    await assertDryRun({ ref: '高斯消元法', action: 'metadata', status: '需更新', dryRun: true })
  })

  test('BUG-003 definition 同步 frontmatter 简介，note_search 摘要一致', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》',
      summary: '旧定位', content: '## 直接法\n\n正文。',
    })
    const out = await s.noteUpdate({ ref: '高斯消元法', action: 'definition', summary: '新定位' })
    expect(out).toContain('简介: 新定位')
    expect(out).not.toContain('简介: 旧定位')
    const text = await readFile(join(dir, ITEMS[0].path), 'utf8')
    expect(text).toContain('简介: 新定位')
    expect(text).toContain('> 新定位')
    expect(text).not.toContain('> 旧定位')
    const hits = await s.search('新定位')
    expect(hits).toContain('- 简介：新定位')
    expect(hits).toContain('- 片段：> 新定位')
  })

  test('BUG-004 replace 以 newContent 首引用块为简介，不重复旧简介', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》',
      content: '> 旧定位\n\n## 小节\n\n旧正文。',
    })
    const out = await s.noteUpdate({
      ref: '高斯消元法', action: 'replace', newContent: '> 新定位\n\n## 小节\n\n新正文。',
    })
    expect(out).toContain('简介: 新定位')
    expect(out).not.toContain('简介: 旧定位')
    const text = await readFile(join(dir, ITEMS[0].path), 'utf8')
    expect(text).toContain('简介: 新定位')
    expect(text).not.toContain('简介: 旧定位')
    expect(text.match(/^> 新定位$/gm)).toHaveLength(1)
    expect(text).not.toContain('> 旧定位')
    expect(text).toContain('新正文。')
    const hits = await s.search('新定位')
    expect(hits).toContain('- 简介：新定位')
  })

  test('note_update metadata：先存档、正文逐字不变、未知键保留', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》',
      content: '## 直接法\n\n正文保持不动。',
    })
    const file = join(dir, ITEMS[0].path)
    const before = await readFile(file, 'utf8')
    const updated = await s.noteUpdate({
      ref: '高斯消元法',
      action: 'metadata',
      sourceSection: '《计算方法》第 2 章 线性方程组 ／ 2.1 节',
      status: '需更新',
    })
    const after = await readFile(file, 'utf8')

    expect(updated).toContain('正文逐字不变')
    expect(parseFrontmatter(after).body).toBe(parseFrontmatter(before).body)
    expect(after).toContain('来源章节: 《计算方法》第2章 线性方程组 / 2.1节')
    expect(after).toContain('状态: 需更新')
    expect(await s.noteHistory('高斯消元法')).toContain('metadata 修复')
  })

  test('note_link / note_unlink：两侧都写 wikilink，重复关联不重复添加', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await s.noteWrite({ planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文。' })
    await s.noteWrite({ planId, title: '列主元消元', path: ITEMS[1].path, source: '《计算方法》', content: '正文。' })

    const linked = await s.noteLink('高斯消元法', '列主元消元', 'next')
    expect(linked).toContain('已建立关联')
    expect(linked).toContain('改动 2 侧')
    const a = await readFile(join(dir, ITEMS[0].path), 'utf8')
    const b = await readFile(join(dir, ITEMS[1].path), 'utf8')
    expect(a).toContain('- 后续：[[列主元消元]]')
    expect(b).toContain('- 前置：[[高斯消元法]]')

    expect(await s.noteLink('高斯消元法', '列主元消元', 'next')).toContain('无改动')
    const removed = await s.noteLink('高斯消元法', '列主元消元', 'next', true)
    expect(removed).toContain('已移除关联')
    expect(await readFile(join(dir, ITEMS[0].path), 'utf8')).not.toContain('列主元消元')
  })

  test('BUG-005 标题≠文件名时 rename 不改入链，note_unlink 可删除', async () => {
    const s = store()
    await s.noteExpectGet()
    const items = [
      { title: '链路验证：甲', path: `${ROOT}/链路验证-甲.md` },
      { title: '链路验证：乙', path: `${ROOT}/链路验证-乙.md` },
    ]
    const planId = await planAndConfirm(s, items)
    await s.noteWrite({ planId, title: items[0].title, path: items[0].path, source: '验证', content: '> 甲\n\n正文。' })
    await s.noteWrite({ planId, title: items[1].title, path: items[1].path, source: '验证', content: '> 乙\n\n正文。' })
    await s.noteLink(items[1].title, items[0].title, 'next')
    const fromFile = join(dir, items[1].path)
    const toFile = join(dir, items[0].path)
    expect(await readFile(fromFile, 'utf8')).toContain('- 后续：[[链路验证-甲]]')

    const out = await s.rename(items[0].title, '链路验证：甲（改名）')
    expect(out).toContain('文件名：不变')
    expect(await readFile(toFile, 'utf8')).toContain('标题: 链路验证：甲（改名）')
    const linked = await readFile(fromFile, 'utf8')
    expect(linked).toContain('- 后续：[[链路验证-甲]]')
    expect(linked).not.toContain('[[链路验证 甲（改名）]]')
    expect(linked).not.toContain('[[链路验证：甲（改名）]]')

    expect(await s.noteLink('链路验证：甲（改名）', '链路验证：乙', 'next', true)).toContain('已移除关联')
    expect(await readFile(fromFile, 'utf8')).not.toContain('链路验证-甲')
    expect(await readFile(toFile, 'utf8')).not.toContain('链路验证-乙')
  })

  test('BUG-005 标题=文件名时 rename 同步文件名与入链', async () => {
    const s = store()
    await s.noteExpectGet()
    const items = [
      { title: '链路验证-丙', path: `${ROOT}/链路验证-丙.md` },
      { title: '链路验证-丁', path: `${ROOT}/链路验证-丁.md` },
    ]
    const planId = await planAndConfirm(s, items)
    await s.noteWrite({ planId, title: items[0].title, path: items[0].path, source: '验证', content: '> 丙\n\n正文。' })
    await s.noteWrite({ planId, title: items[1].title, path: items[1].path, source: '验证', content: '> 丁\n\n正文。' })
    await s.noteLink(items[1].title, items[0].title, 'next')

    const out = await s.rename(items[0].title, '链路验证-戊')
    expect(out).toContain('链路验证-丙.md → 链路验证-戊.md')
    expect(await exists(items[0].path)).toBe(false)
    expect(await exists(`${ROOT}/链路验证-戊.md`)).toBe(true)
    const linked = await readFile(join(dir, items[1].path), 'utf8')
    expect(linked).toContain('- 后续：[[链路验证-戊]]')
    expect(linked).not.toContain('[[链路验证-丙]]')
    expect(await s.noteLink('链路验证-戊', items[1].title, 'next', true)).toContain('已移除关联')
    expect(await readFile(join(dir, items[1].path), 'utf8')).not.toContain('链路验证-戊')
  })

  test('BUG-006 replace 保留既有 关联 小节', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await s.noteWrite({ planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '> 甲\n\n正文。' })
    await s.noteWrite({ planId, title: '列主元消元', path: ITEMS[1].path, source: '《计算方法》', content: '> 乙\n\n正文。' })
    await s.noteLink('高斯消元法', '列主元消元', 'next')
    const aFile = join(dir, ITEMS[0].path)
    const bFile = join(dir, ITEMS[1].path)
    expect(await readFile(aFile, 'utf8')).toContain('- 后续：[[列主元消元]]')

    await s.noteUpdate({
      ref: '高斯消元法', action: 'replace', newContent: '## 新正文\n\n重写后的内容。',
    })
    const afterA = await readFile(aFile, 'utf8')
    expect(afterA).toContain('### 关联')
    expect(afterA).toContain('- 后续：[[列主元消元]]')
    expect(afterA).toContain('重写后的内容。')
    expect(await readFile(bFile, 'utf8')).toContain('- 前置：[[高斯消元法]]')

    expect(await s.noteLink('高斯消元法', '列主元消元', 'next', true)).toContain('已移除关联')
    expect(await readFile(aFile, 'utf8')).not.toContain('- 后续：[[列主元消元]]')
    expect(await readFile(bFile, 'utf8')).not.toContain('- 前置：[[高斯消元法]]')
  })

  test('note_lint：会话残留与期望检查项都能报出（无分值）', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》',
      content: '见 D:\\work\\a.cs，另外这一版带 🚀 表情。',
    })
    const report = await s.lint({ ref: '高斯消元法' })
    expect(report).toContain('会话残留')
    expect(report).toContain('本机路径')
    expect(report).not.toContain('总分')
  })

  test('note_plan(action=abandon)：放弃规划后写入被拒（门禁可解，不死锁）', async () => {
    const s = store()
    await s.noteExpectGet()
    const proposal = await s.notePlan({ rootPath: ROOT, items: ITEMS })
    const planId = /planId：(\d{11,12}_[0-9a-f]{6})/.exec(proposal)?.[1] as string
    expect((await readSession(sessionFileFor(dir, '.study'))).activePlanId).toBe(planId)
    await s.notePlan({ action: 'abandon', rootPath: planId })
    expect((await readSession(sessionFileFor(dir, '.study'))).activePlanId).toBeUndefined()
    await expect(s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: 'x', content: '正文',
    })).rejects.toThrow(/没有已确认的文件夹规划/)
  })

  test('note_write(dryRun)：只回显不落盘', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    const out = await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文。', dryRun: true,
    })
    expect(out).toContain('[dryRun]')
    expect(await exists(ITEMS[0].path)).toBe(false)
    // plan 未被消费：正式写入仍然可以
    expect((await s.noteWrite({ planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文。' })))
      .toContain('已写入：')
  })

  test('落盘正文不留重复定位：首行引用块只出现一次，且被提取进 frontmatter 简介', async () => {
    const s = store()
    await s.noteExpectGet()
    const planId = await planAndConfirm(s)
    // 《笔记期望.md》要求的"术语首现用引用块给定义"正是这种写法
    await s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》',
      content: '> 用初等行变换把系数矩阵化为上三角，再回代求解。\n\n## 直接法\n\n主元非零时逐列消元。',
    })
    const text = await readFile(join(dir, ITEMS[0].path), 'utf8')
    expect(text).toContain('简介: 用初等行变换把系数矩阵化为上三角，再回代求解。')
    // 关键断言：同一句话不再"frontmatter 一遍 + 正文首行一遍"
    expect(text.match(/^> 用初等行变换/gm)).toHaveLength(1)
    // 正文首行仍是那句话（不是被删掉，而是不再重复）
    const body = text.replace(/^---[\s\S]*?\n---\n/, '').trimStart()
    expect(body.startsWith('> 用初等行变换')).toBe(true)
  })

  test('buildPlanRecord 之外：规划里已存在的目录算"复用"不算新建', async () => {
    const s = store()
    await mkdir(join(dir, `${ROOT}/直接法`), { recursive: true })
    const proposal = await s.notePlan({ rootPath: ROOT, items: ITEMS })
    expect(proposal).toContain(`复用已有目录：${ROOT}/直接法`)
    const record = buildPlanRecord({ rootPath: ROOT, items: ITEMS })
    expect(record.confirmed).toBe(false)
  })

  test('expectFile 配置生效：自定义文件名也要能被读到与门禁校验', async () => {
    // 2026-10 收口修复：此前该键"配了不生效"（路径写死常量），属静默陷阱
    await rm(join(dir, '笔记期望.md'), { force: true })
    await writeFile(join(dir, '我的笔记期望.md'), EXPECT_TEXT, 'utf8')
    const s = new VaultStore({
      vaultRoot: dir, stateDir: '.study', fallbackDir: '未分类', expectFile: '我的笔记期望.md',
    })
    const check = await s.noteLibrary('check')
    // 自定义文件名被真的读到了：状态是"尚未读取"，而不是"文件不存在"
    expect(check).toContain('笔记期望尚未读取')
    expect(check).not.toContain('笔记期望文件不存在')
    const read = await s.noteExpectGet()
    expect(read).toContain('已读取笔记期望：我的笔记期望.md')
    expect(await s.noteLibrary('check')).toContain('- 笔记期望：已读（我的笔记期望.md）')
    // 门禁按自定义文件名开门：规划确认后可以写入
    const planId = await planAndConfirm(s)
    await expect(s.noteWrite({
      planId, title: '高斯消元法', path: ITEMS[0].path, source: '《计算方法》', content: '正文。',
    })).resolves.toContain('已写入：')
  })

  test('expectPathFor 拒绝含路径分隔符的文件名（越界防御）', async () => {
    const s = new VaultStore({
      vaultRoot: dir, stateDir: '.study', fallbackDir: '未分类', expectFile: '../外面.md',
    })
    await expect(s.noteLibrary('check')).rejects.toThrow(/不能含路径分隔符/)
  })

  test('note_lint：工程路径内校验真实源码文件，路径外不触发工程规则', async () => {
    const projectRoot = join(dir, 'project')
    const sourceDir = join(projectRoot, 'Assets/Scripts/Presentation/Root')
    await mkdir(sourceDir, { recursive: true })
    await writeFile(join(sourceDir, 'CombatRoot.cs'), 'public sealed class CombatRoot { }', 'utf8')
    await mkdir(join(dir, '游戏开发/项目复盘'), { recursive: true })
    await mkdir(join(dir, '数学'), { recursive: true })

    const frontmatter = (id: string, title: string): string => [
      '---', `ID: ${id}`, `标题: ${title}`, '来源: deepseaoil', '状态: 草稿',
      '来源章节: 《荒原复苏指南》第7章 战斗总装', '顺序: 1', '---', '',
    ].join('\n')
    await writeFile(join(dir, '游戏开发/项目复盘/装配.md'), `${frontmatter('202611111200_aaaaaa', '装配')}# 装配

入口：\`Assets/Scripts/Presentation/Root/CombatRoot.cs · Assemble()\`。

源码已核对。`, 'utf8')
    await writeFile(join(dir, '游戏开发/项目复盘/缺件.md'), `${frontmatter('202611111200_bbbbbb', '缺件')}# 缺件

入口：\`Assets/Scripts/Missing.cs · Missing\`。

源码已核对。`, 'utf8')
    await writeFile(join(dir, '数学/定义.md'), `${frontmatter('202611111200_cccccc', '定义')}# 定义

参数方程给出一条曲线。`, 'utf8')

    const s = new VaultStore({
      vaultRoot: dir,
      stateDir: '.study',
      fallbackDir: '未分类',
      lint: { engineeringPaths: ['游戏开发/项目复盘'], sourceRoots: [projectRoot] },
    })

    const valid = await s.lint({ ref: '装配' })
    expect(valid).not.toContain('源码路径不存在')
    expect(valid).not.toContain('工程源码地图')
    expect(valid).not.toContain('证据级别')

    const missing = await s.lint({ ref: '缺件' })
    expect(missing).toContain('源码路径不存在')
    expect(missing).toContain('Assets/Scripts/Missing.cs')

    const generic = await s.lint({ ref: '定义' })
    expect(generic).not.toContain('工程源码地图')
    expect(generic).not.toContain('证据级别')
  })

  test('note_write / note_update：客观 lint error 在写盘和存档前阻断', async () => {
    const projectRoot = join(dir, 'project-write')
    await mkdir(join(projectRoot, 'Assets/Scripts'), { recursive: true })
    await writeFile(join(projectRoot, 'Assets/Scripts/Good.cs'), 'public sealed class Good { }', 'utf8')
    const s = new VaultStore({
      vaultRoot: dir,
      stateDir: '.study',
      fallbackDir: '未分类',
      lint: { engineeringPaths: ['游戏开发/项目复盘'], sourceRoots: [projectRoot] },
    })
    await s.noteExpectGet()
    const path = '游戏开发/项目复盘/装配.md'
    const planId = await planAndConfirm(s, [{ title: '装配', path }], '游戏开发/项目复盘')

    await expect(s.noteWrite({
      planId,
      title: '装配',
      path,
      source: 'deepseaoil',
      content: '```mermaid\nflowchart LR\n  A --> B',
    })).rejects.toThrow(/代码围栏未闭合/)
    expect(await exists(path)).toBe(false)

    await expect(s.noteWrite({
      planId,
      title: '装配',
      path,
      source: 'deepseaoil',
      content: '入口：`Assets/Scripts/Missing.cs · Missing`。\n\n源码已核对。',
    })).rejects.toThrow(/源码路径不存在/)
    expect(await exists(path)).toBe(false)

    await s.noteWrite({
      planId,
      title: '装配',
      path,
      source: 'deepseaoil',
      content: '入口：`Assets/Scripts/Good.cs · Good`。\n\n源码已核对。',
    })
    const before = await readFile(join(dir, path), 'utf8')
    await expect(s.noteUpdate({
      ref: '装配',
      action: 'append',
      changes: '```mermaid\nflowchart LR\n  X --> Y',
    })).rejects.toThrow(/代码围栏未闭合/)
    expect(await readFile(join(dir, path), 'utf8')).toBe(before)
    expect(await s.noteHistory('装配')).not.toContain('历史存档（1 份')
  })

  test('note_write：Mermaid 语法错误在写盘前阻断', async () => {
    const s = store()
    await s.noteExpectGet()
    const path = `${ROOT}/直接法/坏图.md`
    const planId = await planAndConfirm(s, [{ title: '坏图', path }])
    const content = [
      '```mermaid',
      'sequenceDiagram',
      '    participant A',
      '    A->>: missing target',
      '```',
    ].join('\n')

    await expect(s.noteWrite({
      planId,
      title: '坏图',
      path,
      source: '《计算方法》',
      content,
    })).rejects.toThrow(/Mermaid/)
    expect(await exists(path)).toBe(false)

    await mkdir(dirname(join(dir, path)), { recursive: true })
    await writeFile(join(dir, path), [
      '---', 'ID: 202611111301_eeeeee', '标题: 坏图', '来源: 《计算方法》', '状态: 草稿',
      '来源章节: 《计算方法》第2章 线性方程组数值解法 / 2.1节', '顺序: 1', '---', '',
      content,
    ].join('\n'), 'utf8')
    expect(await s.lint({ ref: '坏图' })).toContain('Mermaid 语法')
  })

  test('note_toc：容器目录导航子主题，并标出缺失的子微目录', async () => {
    const root = '项目导航'
    const child = `${root}/子主题`
    await mkdir(join(dir, child), { recursive: true })
    await writeFile(join(dir, child, '笔记.md'), [
      '---', 'ID: 202611111300_dddddd', '标题: 笔记', '来源: 测试', '状态: 草稿',
      '来源章节: 《测试》第1章 总览', '顺序: 1', '---', '', '# 笔记', '',
    ].join('\n'), 'utf8')
    await writeFile(join(dir, child, '微目录.md'), '# 子主题\n', 'utf8')

    const s = store()
    const toc = await s.noteToc(root)
    expect(toc).toContain('[[项目导航/子主题/微目录|子主题]]')
    expect(toc).toContain('1 块')

    await rm(join(dir, child, '微目录.md'), { force: true })
    const missing = await s.noteToc(root)
    expect(missing).toContain('子主题（1 块，缺微目录）')
  })

  test('note_write：工程源码地图和证据缺口只告警，不阻止落盘', async () => {
    const s = new VaultStore({
      vaultRoot: dir,
      stateDir: '.study',
      fallbackDir: '未分类',
      lint: { engineeringPaths: ['游戏开发/项目复盘'] },
    })
    await s.noteExpectGet()
    const path = '游戏开发/项目复盘/纯结论.md'
    const planId = await planAndConfirm(s, [{ title: '纯结论', path }], '游戏开发/项目复盘')
    const result = await s.noteWrite({
      planId,
      title: '纯结论',
      path,
      source: 'deepseaoil',
      content: '# 纯结论\n\n先记录装配结论。',
    })
    expect(result).toContain('工程笔记没有可定位')
    expect(result).toContain('没有声明证据状态')
    expect(await exists(path)).toBe(true)

    const unverifiedPath = '游戏开发/项目复盘/待验证.md'
    const unverifiedPlan = await planAndConfirm(s, [{ title: '待验证', path: unverifiedPath }], '游戏开发/项目复盘')
    const unverified = await s.noteWrite({
      planId: unverifiedPlan,
      title: '待验证',
      path: unverifiedPath,
      source: 'deepseaoil',
      content: '入口：`Assets/Scripts/Missing.cs · Missing`。\n\n待验证。',
    })
    expect(unverified).toContain('无法验证源码路径')
    expect(await exists(unverifiedPath)).toBe(true)
  })
})
