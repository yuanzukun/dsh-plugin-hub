/**
 * 宿主适配层——本插件与 DSH 之间的**唯一**接触面。
 *
 * 为什么要单独一层：DSH 的内部改动**不会**以编译错误或本仓 `pnpm run check` 的形式暴露。
 * 两个实测案例：
 * - 0.1.7-rc.1（提交 d1e22a7e24 / #4569）删掉目录式预设 → 「学习伙伴」预设整行消失、
 *   18 个工具全部不见，但插件代码零改动、契约探针全绿（`$DSH_HOME/.agent-presets/`
 *   再没有任何读者）；
 * - 0.1.3-alpha.1 把 `session.events` 数组换成 `session.snapshotEvents()` → 旧读法抛错
 *   并被包装成"步骤级失败"，而不是退化成"少注入一次提醒"。
 *
 * 因此本层的三条规则：
 * 1. **只有本文件可以假设宿主形状**；其余模块只用这里返回的能力对象。
 * 2. **一律特性探测 + 降级**；唯一的 fail-loud 是工具注册（没有工具=没有功能）。
 * 3. 每个接触点都登记在 {@link HOST_CONTRACTS} 里（含"变了会怎样"），并由
 *    `tools/verify-contract.mjs` 对**活平台符号面**断言（含"不得再假设已删方法"的
 *    负向断言）。改这里 = 改契约表，两边必须同步。
 *
 * 可选兼容层：装了 `@dsh-plugin/dsh-loader` 时优先走它的稳定入口
 * （`ctx.dshLoader.services.get(name)`，见 https://github.com/dsh-plugins/dsh-loader ）。
 * 但它的覆盖面是 settings 白名单桥 / `httpServer→webServer` 别名 / 包名别名 /
 * `Session.events` 补丁，**不含** `tools.register`、`systemPrompt.section`、
 * `agent/pre-step` —— 所以本层的探测与降级才是主防线。dsh-loader 既不 import 也不
 * inject：inject 了但用户没装时，整行会永远停在 `pending`，工具静默不注册。
 * @module host
 */
/** 一个宿主契约点：`ref` 是平台源码坐标，`breaks` 是"变了之后本插件的失效形态"。 */
export interface HostContract {
    readonly key: string;
    readonly ref: string;
    readonly what: string;
    readonly breaks: string;
}
/**
 * 本插件依赖的全部宿主契约点（**单一真相**：排障说明与探针断言都从这里取）。
 *
 * `ref` 的行号只是"去平台源码核准"的入口，判定按形状、不按行号（行号会漂移）。
 * 探测全部落在 {@link resolveHost} / {@link sessionCwdOf} / {@link sessionEventsOf}。
 */
export declare const HOST_CONTRACTS: readonly HostContract[];
/** 预步监听器形状（`agent/pre-step` 是 waterfall：拿到下游决策后可改写） */
export type PreStepListener = (payload: unknown, next: () => Promise<unknown>) => Promise<unknown>;
/** 宿主 ctx 的最小形状：只声明本插件真的会读的入口 */
export interface HostContextLike {
    /** 工具注册表（宿主服务；唯一 fail-loud 的接触点） */
    tools?: {
        register: (def: unknown) => () => void;
    };
    /** Cordis effect（持有注册的生命周期） */
    effect?: (callback: () => () => unknown, label?: string) => unknown;
    /** Cordis 事件订阅（返回 disposer） */
    on?: (event: string, listener: PreStepListener) => () => void;
    /** Cordis 服务读取（可选服务一律特性探测） */
    get?: (key: string) => unknown;
}
/** 工具执行的宿主上下文（`execute(args, exec)` 的第二个参数） */
export interface ToolExecLike {
    agent?: {
        session?: {
            header?: {
                id?: string;
                cwd?: string;
            };
        };
    };
}
/** 会话形状：新平台 `snapshotEvents()`、旧平台 `events` 数组（两者都在探测范围内） */
export interface SessionLike {
    events?: Array<{
        type?: string;
    }>;
    snapshotEvents?: () => Array<{
        type?: string;
    }>;
    header?: {
        cwd?: string;
    };
}
/** 系统提示段注册入口（`ctx.get('systemPrompt')`；只有 `section` 是函数时才算能力可用） */
export interface SystemPromptLike {
    section: (entry: {
        name: string;
        order: number;
        text: string;
    }) => () => void;
}
/** 探测结果：能力对象 + 取用途径（`viaDshLoader` 回显在启动日志，排障用） */
export interface HostCapabilities {
    /** true = 至少有一个服务是经 dsh-loader 稳定入口拿到的 */
    readonly viaDshLoader: boolean;
    readonly tools?: {
        register: (def: unknown) => () => void;
    };
    readonly systemPrompt?: SystemPromptLike;
    readonly on?: (event: string, listener: PreStepListener) => () => void;
}
/**
 * 特性探测宿主能力。**永不抛错**：任一环节缺失都只让对应能力变 undefined。
 * @param ctx - Cordis 上下文（preset 行的 `apply(ctx, config)` 第一个参数）
 * @returns 能力对象（`tools` 缺失时调用方必须 fail-loud，见 index.ts）
 */
export declare function resolveHost(ctx: HostContextLike | undefined): HostCapabilities;
/**
 * 调用方会话的工作目录（`includeSessionCwd` 的输入）。
 * @param exec - 工具执行的宿主上下文
 * @returns 去空白后的绝对路径，或 undefined（调用方据此跳过该检索根）
 */
export declare function sessionCwdOf(exec?: ToolExecLike): string | undefined;
/**
 * 调用方会话 ID（`study_mode` 的会话级覆盖键）。
 * 宿主版本若缺 ID，调用方仍需退到 cwd，保证核心功能可用。
 */
export declare function sessionIdOf(exec?: ToolExecLike): string | undefined;
/**
 * 会话事件快照（自动门禁的"是否恢复会话"判定输入）。
 *
 * 双形状探测 + **绝不逸出异常**：`snapshotEvents()` 是宿主 API，跨版本可能抛错，
 * 而从 pre-step 处理器逸出的异常会被包装成步骤级失败——比"少注入一次提醒"坏得多。
 * @param session - payload.agent.session（形状未知，只读探测）
 * @returns 事件数组，或 undefined（两者皆缺/抛错 → 调用方按"保守 false"处理）
 */
export declare function sessionEventsOf(session: SessionLike | undefined): Array<{
    type?: string;
}> | undefined;
