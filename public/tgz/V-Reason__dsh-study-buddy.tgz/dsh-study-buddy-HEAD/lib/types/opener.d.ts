/**
 * 开场门禁：会话首条消息强制定向读记忆。
 *
 * 两层防线（独立可测的纯逻辑）：
 * 1. 系统提示段 `study:memory-mandate`（order -1，渲染在 persona 之前）；
 * 2. `agent/pre-step` 预步提醒——首次模型请求前把「先读记忆再办事」作为
 *    本步消息一并注入（来源是**生产者自有 kind**，持久化进会话日志，可追溯）。
 *
 * 纯文本/纯函数模块：不碰文件系统、不引入 @deepseek-ai 运行时依赖、
 * 不假设宿主类型（payload/decision 用最小结构形状），便于单元测试。
 * @module opener
 */
import { type SessionLike } from './host.ts';
/** 系统提示段名（按 system-prompt 的「category:slug」惯例） */
export declare const OPENER_SECTION_NAME = "study:memory-mandate";
/** 段序：负数渲染在 persona（order 0）之前 */
export declare const OPENER_SECTION_ORDER = -1;
/** 系统提示段文案（常量；每条请求固定可见，尽量短以控制固定开销） */
export declare const MANDATE: string;
/** 预步提醒文案（仅注入一次，零稳态成本） */
export declare const REMINDER: string;
/**
 * 提醒消息的生产者自有来源标识（**v4 会话格式的硬准入**）。
 *
 * 平台侧唯一真相：
 * - `packages/session/session-format-v3-to-v4/src/message-sources.ts` 的 `source()`：
 *   `source.kind` 必须是非空字符串，且**不得**是 `'plugin'`（退场的旧包装会在
 *   `encodeEvent`——即线上写盘路径——被拒，异常冒泡成**整轮失败**，见 v1.1.1 事故）；
 * - 同包 README 的 V3→V4 映射表：「Any other plugin name → `plugin:` + 原名」，
 *   即第三方插件的规范 kind 就是 `plugin:<包名>`（平台迁移历史行时写出的也是这个值，
 *   所以新旧行不会分裂成两个生产者身份）；
 * - `packages/llm/llm/src/message.ts` 的 `MessageSourceMap` 注释：
 *   "each producer declares its own `kind`; there is no shared catch-all `plugin` kind"。
 */
export declare const OPENER_SOURCE_KIND = "plugin:dsh-study-buddy";
/**
 * 提醒消息在对话里的折叠一行文案（`ContextFormed` 的 `notice` 形态要求非空 `summary`；
 * 上限口径见 `dsh-llm` 的 `CONTEXT_SUMMARY_MAX_CHARS = 120`）。
 */
export declare const OPENER_SOURCE_SUMMARY = "\u5F00\u573A\u95E8\u7981\uFF1A\u5148\u8BFB\u8BB0\u5FC6\u3001\u8FDB\u5EA6\u4E0E\u671F\u671B";
/** 是否满足注入条件：会话首轮首步、且会话历史中还没有任何 user/message */
export declare function shouldInjectOpener(turn: number, step: number, hasPriorUserMessage: boolean): boolean;
/** 提醒消息的最小结构形状（与 dsh-llm createUserMessage 的运行时形状一致） */
export interface OpenerReminder {
    readonly id: string;
    readonly role: 'user';
    readonly content: ReadonlyArray<{
        readonly type: 'text';
        readonly text: string;
    }>;
    readonly source: {
        readonly kind: typeof OPENER_SOURCE_KIND;
        readonly form: 'notice';
        readonly summary: string;
    };
}
/** 构建预步提醒消息；id 可注入（测试用），默认 randomUUID */
export declare function buildOpenerReminder(id?: string): OpenerReminder;
/** 预步决策的最小形状：enter（带消息）或 reject */
export interface EnterDecision<T> {
    kind: 'enter';
    messages: T[];
}
export interface RejectDecision {
    kind: 'reject';
}
export type PreStepDecisionLike<T> = EnterDecision<T> | RejectDecision;
/** enter：把提醒追加到本步消息末尾（不改原对象）；reject：原样返回 */
export declare function applyOpenerDecision<T>(decision: PreStepDecisionLike<T>, reminder: T): PreStepDecisionLike<T>;
/**
 * 从预步载荷提取「会话历史已有 user/message」（恢复会话判定）。
 *
 * 事件读取走 host.ts 的 `sessionEventsOf`（本插件唯一的宿主接触面，双形状探测 +
 * 绝不逸出异常）：
 * - 旧平台（≤2026-08-27 session 重构前）：`session.events` 是数组属性；
 * - 新平台（>=0.1.3-alpha.1，session 拆分为快照 API 后）：`session.snapshotEvents()` 返回快照数组。
 * 两者皆缺/抛错 → 保守返回 false（只多注入一次提醒，不阻断流程）。
 *
 * BIZ-9：`snapshotEvents()` 是宿主 API，跨版本可能抛错；这里**必须**不逸出——
 * 从 pre-step 处理器逸出的异常会变成步骤级失败（最坏情况首步直接失败），
 * 而不是注释承诺的"只多注入一次提醒"。
 */
export declare function hasPriorUserMessage(payload: {
    agent?: {
        session?: SessionLike;
    };
}): boolean;
