export declare const PLUGIN_VERSION: string;
export declare const ARTIFACT_LABEL = "Mermaid/JSDOM \u5DF2\u5185\u8054";
export declare const ARTIFACT_MARKER: string;
