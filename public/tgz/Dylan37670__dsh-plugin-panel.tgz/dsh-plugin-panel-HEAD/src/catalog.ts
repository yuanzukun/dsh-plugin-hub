/**
 * Catalog service: merges the curated seed with a live community source, caches
 * the result to disk, and answers snapshots over the panel's HTTP routes.
 *
 * Live sources (in order of preference):
 *  1. `remoteCatalogUrl` — a JSON catalog file `{ entries: CatalogEntry[] }`
 *     (a published catalog anyone can host).
 *  2. The maintained awesome-dsh-plugin install registry (default).
 *
 * Every fetch result is merged with the seed so curated Chinese translations,
 * categories and install specs survive even when a live source omits them.
 */

import { mkdir, readFile, writeFile, rename, stat } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { SEED_ENTRIES, SEED_BY_REPO } from './catalog-data.ts';
import type { CatalogEntry, CatalogLens, CatalogSnapshot } from './types.ts';

/** JSON catalog file shape accepted from a remote URL. */
interface RemoteCatalogFile {
  manifest?: {
    schema?: string;
    generatedAt?: string;
    totalHits?: number;
    fetchedCount?: number;
    count?: number;
    coveragePct?: number;
    gaps?: number;
  };
  entries?: CatalogEntry[];
  plugins?: CommunityRegistryEntry[];
}

export const DEFAULT_INSTALL_REGISTRY_URL = 'https://awesome-dsh-plugin.com/plugins.json';
const INSTALL_REGISTRY_TIMEOUT_MS = 20_000;
const INSTALL_REGISTRY_ATTEMPTS = 3;
export const DEFAULT_FULL_CATALOG_URL = 'https://raw.githubusercontent.com/Dylan37670/dsh-plugin-panel/catalog-data/catalog.json';
/** Published alongside the full catalogue; used by the selected/curated lens. */
export const DEFAULT_CURATED_CATALOG_URL = 'https://raw.githubusercontent.com/Dylan37670/dsh-plugin-panel/catalog-data/curated.json';

/** Normalize a repo URL to its base (strip #fragment). */
function baseRepo(url: string): string {
  return url.split('#')[0].replace(/\/$/, '');
}

/** Map an awesome-list section header to our categories. */
function categoryFromSection(section: string): CatalogEntry['category'] {
  const s = section.toLowerCase();
  if (s.includes('skill')) return 'skill';
  if (s === 'ui' || s.includes('theme') || s.includes('appearance') || s.includes('ui enhance')) return 'client';
  if (s.includes('market') || s.includes('manager') || s.includes('badge')) return 'dev-resource';
  return 'plugin';
}

interface CommunityRegistryEntry {
  name?: string;
  owner?: string;
  url?: string;
  category?: string;
  description?: { en?: string; zh?: string };
  npm?: string | null;
  install?: string;
  stars?: number;
}

/** Accept only the official dsh-plugin command shape; never execute arbitrary registry text. */
export function installSpecFromCommand(command: string | undefined): string | undefined {
  if (!command) return undefined;
  const match = /^dsh\s+plugin\s+--profile\s+[A-Za-z0-9._-]+\s+add\s+(.+?)\s*$/.exec(command.trim());
  if (!match) return undefined;
  let spec = match[1].trim();
  if ((spec.startsWith('"') && spec.endsWith('"')) || (spec.startsWith("'") && spec.endsWith("'"))) spec = spec.slice(1, -1);
  return spec && !/[\r\n;&|<>]/.test(spec) ? spec : undefined;
}

/** Convert the community-maintained install registry into panel entries. */
export function parseCommunityRegistry(file: { plugins?: CommunityRegistryEntry[] }): CatalogEntry[] {
  const entries: CatalogEntry[] = [];
  for (const plugin of file.plugins ?? []) {
    if (!plugin.url?.startsWith('https://github.com/') || !plugin.name) continue;
    const install = installSpecFromCommand(plugin.install);
    const category = categoryFromSection(plugin.category ?? 'plugin');
    entries.push({
      id: plugin.url.replace(/^https:\/\/github\.com\//, '').replace(/\/tree\/[^/]+\//, '--'),
      title: plugin.name,
      description: plugin.description?.en ?? plugin.description?.zh ?? '(no description)',
      ...(plugin.description?.zh ? { descriptionZh: plugin.description.zh } : {}),
      category,
      repo: plugin.url,
      ...(plugin.npm ? { npm: plugin.npm } : {}),
      ...(install ? { install, installVerified: true, installSource: 'community' as const } : {}),
      tags: [plugin.category ?? 'plugin', 'dsh-plugin'],
      ...(plugin.owner ? { author: plugin.owner } : {}),
      ...(typeof plugin.stars === 'number' ? { stars: plugin.stars } : {}),
    });
  }
  return entries;
}

export interface CommunityRegistryFetchOptions {
  fetchImpl?: typeof fetch;
  attempts?: number;
  timeoutMs?: number;
  retryDelayMs?: number;
  signal?: AbortSignal;
}

/**
 * Download and validate the maintained install registry.
 *
 * A registry entry is trusted for one-click installation only when every
 * published row has a GitHub identity and a single safe `dsh plugin ... add`
 * command.  Rejecting the complete response prevents a partially changed or
 * damaged upstream schema from silently removing install buttons.
 */
export async function fetchCommunityRegistry(
  url = DEFAULT_INSTALL_REGISTRY_URL,
  options: CommunityRegistryFetchOptions = {},
): Promise<CatalogEntry[]> {
  const fetchImpl = options.fetchImpl ?? fetch;
  const attempts = Math.max(1, Math.floor(options.attempts ?? INSTALL_REGISTRY_ATTEMPTS));
  const timeoutMs = Math.max(1, Math.floor(options.timeoutMs ?? INSTALL_REGISTRY_TIMEOUT_MS));
  const retryDelayMs = Math.max(0, Math.floor(options.retryDelayMs ?? 1_500));
  let lastError: unknown;

  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      const response = await fetchImpl(url, {
        signal: options.signal ?? AbortSignal.timeout(timeoutMs),
        headers: { 'User-Agent': 'dsh-plugin-panel-catalog' },
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const file = await response.json() as RemoteCatalogFile;
      if (!Array.isArray(file.plugins) || file.plugins.length === 0) {
        throw new Error('registry contains no plugins');
      }
      const invalidCommands = file.plugins.filter((plugin) => installSpecFromCommand(plugin.install) === undefined);
      if (invalidCommands.length > 0) {
        throw new Error(`registry contains ${invalidCommands.length} invalid install command(s)`);
      }
      const entries = parseCommunityRegistry(file);
      if (entries.length !== file.plugins.length || entries.some((entry) => entry.installVerified !== true)) {
        throw new Error('registry contains invalid plugin identities');
      }
      return entries;
    } catch (error) {
      lastError = error;
      if (options.signal?.aborted) throw error;
      if (attempt < attempts && retryDelayMs > 0) {
        await new Promise((resolve) => setTimeout(resolve, retryDelayMs * attempt));
      }
    }
  }

  const reason = lastError instanceof Error ? lastError.message : String(lastError);
  throw new Error(`install registry unavailable after ${attempts} attempt(s): ${reason}`);
}

/** Parse the awesome-dsh-plugin README bullet list into entries. */
export function parseAwesomeMarkdown(markdown: string): CatalogEntry[] {
  const entries: CatalogEntry[] = [];
  let section = '';
  const seen = new Set<string>();
  for (const rawLine of markdown.split(/\r?\n/)) {
    const line = rawLine.trim();
    const header = line.match(/^### (.+)$/);
    if (header) {
      section = header[1];
      continue;
    }
    const bullet = line.match(/^- \[([^\]]+)\]\(([^)]+)\) - (.+)$/);
    if (!bullet) continue;
    const [, name, url, description] = bullet;
    const repo = baseRepo(url);
    if (!/^https:\/\/github\.com\//.test(repo) || seen.has(repo)) continue;
    seen.add(repo);
    const seed = SEED_BY_REPO.get(repo);
    entries.push({
      id: repo.replace(/^https:\/\/github\.com\//, ''),
      title: seed?.title ?? name,
      ...(seed?.titleZh ? { titleZh: seed.titleZh } : {}),
      description: seed?.description ?? description.trim(),
      ...(seed?.descriptionZh ? { descriptionZh: seed.descriptionZh } : {}),
      category: seed?.category ?? categoryFromSection(section),
      repo,
      ...(seed?.npm ? { npm: seed.npm } : {}),
      install: seed?.install ?? `github:${repo.replace(/^https:\/\/github\.com\//, '')}`,
      tags: seed?.tags ?? [name.toLowerCase()],
      ...(seed?.author ? { author: seed.author } : {}),
    });
  }
  return entries;
}

/** Merge fetched entries with the curated seed (seed wins for curated fields). */
export function mergeWithSeed(fetched: CatalogEntry[]): CatalogEntry[] {
  const merged = new Map<string, CatalogEntry>();
  for (const seed of SEED_ENTRIES) {
    const key = seed.repo ? baseRepo(seed.repo) : seed.id;
    if (!merged.has(key)) merged.set(key, seed);
  }
  for (const fetchedEntry of fetched) {
    const key = fetchedEntry.repo ? baseRepo(fetchedEntry.repo) : fetchedEntry.id;
    const existing = merged.get(key);
    if (!existing) {
      merged.set(key, fetchedEntry);
      continue;
    }
    const installOwner = existing.installVerified ? existing : fetchedEntry.installVerified ? fetchedEntry : existing;
    merged.set(key, {
      ...fetchedEntry,
      ...existing,
      ...(installOwner.install ? { install: installOwner.install } : {}),
      installVerified: installOwner.installVerified ?? false,
      ...(installOwner.installSource ? { installSource: installOwner.installSource } : {}),
      ...(installOwner.npm ? { npm: installOwner.npm } : {}),
      tags: [...new Set([...(existing.tags ?? []), ...(fetchedEntry.tags ?? [])])],
    });
  }
  return [...merged.values()].sort((a, b) => a.title.localeCompare(b.title));
}

/** Guess a category for a GitHub topic-search repo from name/description. */
export function guessCategory(name: string, description: string): CatalogEntry['category'] {
  const hay = `${name} ${description ?? ''}`.toLowerCase();
  if (/skill/.test(hay)) return 'skill';
  if (/theme|skin|wallpaper|mobile|sidebar|composer|ui\b|interface/.test(hay)) return 'client';
  if (/docs?|template|collection|toolkit|awesome|starter|example|hub/.test(hay)) return 'dev-resource';
  return 'plugin';
}

/** GitHub topic search result item (the fields we consume). */
interface GitHubRepo {
  full_name: string;
  name: string;
  description: string | null;
  html_url: string;
  stargazers_count?: number;
  language?: string | null;
  owner?: { login?: string };
  created_at?: string;
}

const GITHUB_SEARCH_HEADERS: Record<string, string> = {
  'User-Agent': 'dsh-plugin-panel',
  Accept: 'application/vnd.github+json',
};
const githubToken = process.env.GITHUB_TOKEN ?? process.env.GH_TOKEN;
if (githubToken) GITHUB_SEARCH_HEADERS.Authorization = `Bearer ${githubToken}`;

/** One created-date search bucket (inclusive, YYYY-MM-DD). */
export interface DateBucket {
  start: string;
  end: string;
}

/** Split a date bucket at its midpoint into two disjoint halves. */
export function splitDateBucket(bucket: DateBucket): [DateBucket, DateBucket] {
  const start = new Date(`${bucket.start}T00:00:00Z`).getTime();
  const end = new Date(`${bucket.end}T00:00:00Z`).getTime();
  const mid = start + Math.floor((end - start) / 2);
  const midDate = new Date(mid).toISOString().slice(0, 10);
  const nextStart = new Date(mid + 86_400_000).toISOString().slice(0, 10);
  return [
    { start: bucket.start, end: midDate },
    { start: nextStart, end: bucket.end },
  ];
}

/** Initial coarse created-date buckets for the topic (year + current-year halves). */
export function initialDateBuckets(now = new Date()): DateBucket[] {
  const year = now.getFullYear();
  const buckets: DateBucket[] = [{ start: '2008-01-01', end: '2023-12-31' }];
  for (let y = 2024; y < year; y += 1) buckets.push({ start: `${y}-01-01`, end: `${y}-12-31` });
  buckets.push({ start: `${year}-01-01`, end: `${year}-06-30` });
  buckets.push({ start: `${year}-07-01`, end: `${year}-12-31` });
  return buckets;
}

/**
 * Build one GitHub search query URL for a bucket.
 *
 * Sorted by `created` (desc), NOT by stars: thousands of topic repos share
 * low star counts, and star-sorted pagination is unstable across pages with
 * ties (items get skipped). `created` is effectively unique per repo, giving
 * stable pagination; the merged result is re-sorted by stars afterwards.
 */
export function bucketSearchUrl(bucket: DateBucket, page: number): string {
  return `https://api.github.com/search/repositories?q=${encodeURIComponent(
    `topic:dsh-plugin created:${bucket.start}..${bucket.end}`,
  )}&sort=created&order=desc&per_page=100&page=${page}`;
}

function toEntry(repo: GitHubRepo, topic: string): CatalogEntry {
  return {
    id: repo.full_name,
    title: repo.name,
    description: repo.description ?? '(no description)',
    category: guessCategory(repo.name, repo.description ?? ''),
    repo: repo.html_url,
    install: `github:${repo.full_name}`,
    tags: [repo.language ?? 'dsh', topic],
    author: repo.owner?.login,
    stars: repo.stargazers_count ?? 0,
  };
}

/** Fetch one page of one bucket, handling the unauthenticated rate limit once. */
export async function githubSearchPage(url: string, signal?: AbortSignal): Promise<{ items: GitHubRepo[]; total: number }> {
  const request = async (): Promise<Response> => {
    const response = await fetch(url, { signal, headers: GITHUB_SEARCH_HEADERS });
    if (response.status === 403) {
      // Search rate limit (10/min unauthenticated): back off and retry once.
      await new Promise((resolve) => setTimeout(resolve, 60_000));
      const retry = await fetch(url, { signal, headers: GITHUB_SEARCH_HEADERS });
      if (retry.status === 403) throw new Error('github search rate limit exceeded');
      return retry;
    }
    return response;
  };
  const response = await request();
  if (!response.ok) throw new Error(`github topic search failed: HTTP ${response.status}`);
  const body = (await response.json()) as { items?: GitHubRepo[]; total_count?: number };
  return { items: body.items ?? [], total: body.total_count ?? 0 };
}

/** Fetch repos tagged with a GitHub topic, best-effort up to 1000 (API cap). */
export async function fetchGitHubTopic(topic: string, signal?: AbortSignal): Promise<{ entries: CatalogEntry[]; totalHits: number }> {
  const entries: CatalogEntry[] = [];
  let totalHits = 0;
  for (let page = 1; page <= 10; page += 1) {
    const response = await fetch(bucketSearchUrl({ start: '2000-01-01', end: '2099-12-31' }, page), {
      signal,
      headers: GITHUB_SEARCH_HEADERS,
    });
    if (response.status === 403) break; // search rate limit 鈥?return what we have
    if (!response.ok) throw new Error(`github topic search failed: HTTP ${response.status}`);
    const body = (await response.json()) as { items?: GitHubRepo[]; total_count?: number };
    totalHits = body.total_count ?? totalHits;
    const items = body.items ?? [];
    for (const repo of items) entries.push(toEntry(repo, topic));
    if (items.length < 100) break;
  }
  return { entries, totalHits };
}

/**
 * Fetch EVERY repo tagged with the topic by splitting the created-date range
 * into buckets that stay under the API's 1000-result cap, paging each bucket,
 * and pacing requests to respect the unauthenticated search rate limit
 * (10/min). Merged by repo, globally sorted by stars.
 *
 * Runtime is typically 1鈥? minutes depending on how many buckets are needed.
 */
export async function fetchGitHubTopicFull(
  topic: string,
  signal?: AbortSignal,
  opts: { paceMs?: number; maxQueries?: number } = {},
): Promise<{ entries: CatalogEntry[]; totalHits: number; queries: number; complete: boolean; gaps: number }> {
  const paceMs = opts.paceMs ?? (githubToken ? 2_000 : 7_000);
  const maxQueries = opts.maxQueries ?? 85;
  const sleep = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

  // Exact grand total (one request).
  const countPage = await githubSearchPage(
    `https://api.github.com/search/repositories?q=${encodeURIComponent(`topic:${topic}`)}&per_page=1`,
    signal,
  );
  const totalHits = countPage.total;
  let queries = 1;

  const seen = new Map<string, CatalogEntry>();
  const queue = initialDateBuckets().map((bucket) => `created:${bucket.start}..${bucket.end}`);
  const gaps: Array<{ fragment: string; total: number }> = [];

  const fragmentUrl = (fragment: string, page: number): string =>
    `https://api.github.com/search/repositories?q=${encodeURIComponent(
      `topic:${topic} ${fragment}`,
    )}&sort=created&order=desc&per_page=100&page=${page}`;

  const childrenOf = (fragment: string): string[] => {
    const created = fragment.match(/created:(\d{4}-\d{2}-\d{2})\.\.(\d{4}-\d{2}-\d{2})/);
    if (!created) return [];
    const [, start, end] = created;
    const rest = fragment.replace(created[0], '').trim();
    if (start !== end) {
      const [a, b] = splitDateBucket({ start, end });
      return [
        `created:${a.start}..${a.end}${rest ? ` ${rest}` : ''}`,
        `created:${b.start}..${b.end}${rest ? ` ${rest}` : ''}`,
      ];
    }
    const stars = fragment.match(/stars:(\d+)\.\.(\d+)/);
    if (!stars) {
      return ['0..0', '1..2', '3..5', '6..10', '11..25', '26..50', '51..100', '101..500', '501..100000']
        .map((range) => `created:${start}..${end} stars:${range}`);
    }
    const starLo = Number(stars[1]);
    const starHi = Number(stars[2]);
    const withoutStars = rest.replace(stars[0], '').trim();
    if (starHi > starLo) {
      const mid = Math.floor((starLo + starHi) / 2);
      return [
        `created:${start}..${end} stars:${starLo}..${mid}${withoutStars ? ` ${withoutStars}` : ''}`,
        `created:${start}..${end} stars:${mid + 1}..${starHi}${withoutStars ? ` ${withoutStars}` : ''}`,
      ];
    }
    const size = fragment.match(/size:(\d+)\.\.(\d+)/);
    if (!size) {
      return ['0..100', '101..1000', '1001..100000000']
        .map((range) => `created:${start}..${end} ${stars[0]} size:${range}`);
    }
    const sizeLo = Number(size[1]);
    const sizeHi = Number(size[2]);
    if (sizeHi <= sizeLo) return [];
    const mid = Math.floor((sizeLo + sizeHi) / 2);
    return [
      `created:${start}..${end} ${stars[0]} size:${sizeLo}..${mid}`,
      `created:${start}..${end} ${stars[0]} size:${mid + 1}..${sizeHi}`,
    ];
  };

  const drainFragment = async (fragment: string): Promise<void> => {
    const collected: GitHubRepo[] = [];
    for (let page = 1; page <= 10; page += 1) {
      if (queries >= maxQueries) return;
      if (queries > 1) await sleep(paceMs);
      queries += 1;
      const { items, total } = await githubSearchPage(fragmentUrl(fragment, page), signal);
      collected.push(...items);
      if (items.length < 100) break;
      if (page === 1 && total > 1000) {
        const children = childrenOf(fragment);
        if (children.length > 0) queue.push(...children);
        else gaps.push({ fragment, total });
        break;
      }
    }
    for (const repo of collected) {
      if (!seen.has(repo.full_name)) seen.set(repo.full_name, toEntry(repo, topic));
    }
  };

  while (queue.length > 0 && queries < maxQueries) {
    const fragment = queue.shift();
    if (fragment === undefined) break;
    await drainFragment(fragment);
  }

  const entries = [...seen.values()].sort((a, b) => (b.stars ?? 0) - (a.stars ?? 0));
  return { entries, totalHits, queries, complete: queue.length === 0 && gaps.length === 0, gaps: gaps.length };
}

/**
 * Catalog service bound to one plugin context. Keeps two lens caches:
 *  - curated: the awesome-dsh-plugin list (or a remote JSON URL)
 *  - all:     GitHub topic search over `dsh-plugin`
 */
export class CatalogService {
  readonly dir: string;
  private readonly cacheFile: (lens: CatalogLens) => string;
  private cached = new Map<CatalogLens, CatalogSnapshot>();
  private bundledAll: CatalogSnapshot | undefined;
  private bundledCurated: CatalogSnapshot | undefined;
  private starsMap: Map<string, number> | undefined;

  constructor(dshHome: string) {
    this.dir = join(dshHome, 'plugin-panel');
    this.cacheFile = (lens) => join(this.dir, lens === 'all' ? 'catalog.all.cache.json' : 'catalog.cache.json');
  }

  /** repo base URL → stars, built from the bundled full index (v5.4). */
  private async starsByRepo(): Promise<Map<string, number>> {
    if (this.starsMap) return this.starsMap;
    const map = new Map<string, number>();
    const bundled = await this.readBundledAll();
    if (bundled) {
      for (const entry of bundled.entries) {
        if (entry.repo && typeof entry.stars === 'number' && entry.stars > 0) {
          map.set(entry.repo.split('#')[0].replace(/\/$/, ''), entry.stars);
        }
      }
    }
    this.starsMap = map;
    return map;
  }

  /** Attach real GitHub stars to entries that lack them (curated lens). */
  async enrichStars(entries: CatalogEntry[]): Promise<CatalogEntry[]> {
    const map = await this.starsByRepo();
    return entries.map((entry) => {
      if (typeof entry.stars === 'number' && entry.stars > 0) return entry;
      if (!entry.repo) return entry;
      const stars = map.get(entry.repo.split('#')[0].replace(/\/$/, ''));
      return stars !== undefined ? { ...entry, stars } : entry;
    });
  }

  /** Path of the prebuilt full-repo index shipped with the package. */
  bundledAllPath(): string {
    return fileURLToPath(new URL('../catalog/catalog.json', import.meta.url));
  }

  /** Path of the prebuilt curated index shipped with the package (v6.12). */
  bundledCuratedPath(): string {
    return fileURLToPath(new URL('../catalog/curated.json', import.meta.url));
  }

  /** Load the prebuilt curated index bundled with the plugin (v6.12). */
  async readBundledCurated(): Promise<CatalogSnapshot | undefined> {
    if (this.bundledCurated) return this.bundledCurated;
    try {
      const raw = await readFile(this.bundledCuratedPath(), 'utf8');
      const parsed = JSON.parse(raw) as RemoteCatalogFile;
      if (Array.isArray(parsed.entries) && parsed.entries.length > 0) {
        const snapshot: CatalogSnapshot = {
          entries: parsed.entries,
          fetchedAt: parsed.manifest?.generatedAt,
          source: 'remote',
          lens: 'curated',
          totalHits: parsed.entries.length,
          generatedAt: parsed.manifest?.generatedAt,
          fetchedCount: parsed.manifest?.fetchedCount,
          partial: false,
        };
        this.bundledCurated = snapshot;
        return snapshot;
      }
    } catch {
      /* bundled curated index absent */
    }
    return undefined;
  }

  /** Load the prebuilt full-repo index bundled with the plugin. */
  async readBundledAll(): Promise<CatalogSnapshot | undefined> {
    if (this.bundledAll) return this.bundledAll;
    try {
      const raw = await readFile(this.bundledAllPath(), 'utf8');
      const parsed = JSON.parse(raw) as RemoteCatalogFile;
      if (Array.isArray(parsed.entries) && parsed.entries.length > 0) {
        const snapshot: CatalogSnapshot = {
          entries: parsed.entries,
          fetchedAt: parsed.manifest?.generatedAt,
          source: 'remote',
          lens: 'all',
          totalHits: parsed.manifest?.totalHits ?? parsed.entries.length,
          generatedAt: parsed.manifest?.generatedAt,
          fetchedCount: parsed.manifest?.fetchedCount,
          coveragePct: parsed.manifest?.coveragePct,
          gaps: parsed.manifest?.gaps,
          partial: false,
        };
        this.bundledAll = snapshot;
        return snapshot;
      }
    } catch {
      /* bundled index absent — fall back to live fetch */
    }
    return undefined;
  }

  private async readCache(lens: CatalogLens): Promise<CatalogSnapshot | undefined> {
    const hit = this.cached.get(lens);
    if (hit) return hit;
    try {
      const raw = await readFile(this.cacheFile(lens), 'utf8');
      const parsed = JSON.parse(raw) as CatalogSnapshot;
      if (Array.isArray(parsed.entries)) {
        // v6.9 and earlier treated every topic repository root as installable.
        // Ignore that ALL-lens cache so stale unsafe install buttons cannot
        // survive an upgrade to the verified-target model. The curated cache
        // (awesome list / registry) has no installVerified and stays valid.
        if (lens === 'all' && !parsed.entries.some((entry) => entry.installVerified === true)) return undefined;
        const snapshot = { ...parsed, lens, source: 'cache' as const };
        this.cached.set(lens, snapshot);
        return snapshot;
      }
    } catch {
      /* no cache yet */
    }
    return undefined;
  }

  private async writeCache(snapshot: CatalogSnapshot): Promise<void> {
    await mkdir(this.dir, { recursive: true });
    const file = this.cacheFile(snapshot.lens);
    const tmp = `${file}.tmp`;
    await writeFile(tmp, JSON.stringify(snapshot, null, 2), 'utf8');
    await rename(tmp, file);
  }

  /** Age of the on-disk cache in ms (Infinity when absent). */
  async cacheAgeMs(lens: CatalogLens): Promise<number> {
    try {
      const info = await stat(this.cacheFile(lens));
      return Date.now() - info.mtimeMs;
    } catch {
      return Number.POSITIVE_INFINITY;
    }
  }

  /**
   * Current snapshot for a lens. Priority for the `all` lens (v5.1):
   *  1. a cache that is an explicit FULL prebuilt download (partial === false);
   *  2. the prebuilt bundled index (complete, ships with the plugin) — beats
   *     any cache without that marker, including legacy caches written before
   *     the `partial` flag existed (old fast top-1000 crawls);
   *  3. any remaining cache, then the seed.
   */
  async snapshot(lens: CatalogLens = 'curated'): Promise<CatalogSnapshot> {
    const cache = await this.readCache(lens);
    if (lens === 'all') {
      if (cache && cache.partial === false) return cache;
      const bundled = await this.readBundledAll();
      if (bundled) return bundled;
      if (cache) return cache;
      return { entries: SEED_ENTRIES, source: 'seed', lens };
    }
    // v6.13: curated priority = fresh cache → bundled curated index → stale
    // cache → seed. A cache wins only when it is a full download (partial
    // === false) or newer than the bundled index; a stale legacy cache (e.g.
    // an old partial registry cache) must never shadow the bundled index.
    const bundled = await this.readBundledCurated();
    if (cache) {
      const bundledAt = bundled?.generatedAt;
      const cacheAt = cache.generatedAt ?? cache.fetchedAt;
      const cacheNewer = bundledAt === undefined || (cacheAt !== undefined && cacheAt >= bundledAt);
      if (cache.partial === false || cacheNewer) {
        return { ...cache, entries: await this.enrichStars(cache.entries) };
      }
    }
    if (bundled) return { ...bundled, entries: await this.enrichStars(bundled.entries) };
    if (cache) return { ...cache, entries: await this.enrichStars(cache.entries) };
    return { entries: await this.enrichStars(SEED_ENTRIES), source: 'seed', lens };
  }

  /**
   * Persist the bundled curated index to the disk cache (v6.13): after a
   * no-URL refresh the bundled snapshot becomes the cache, so a later
   * /catalog read returns the same up-to-date list instead of a stale one.
   */
  async cacheBundledCurated(): Promise<void> {
    const bundled = await this.readBundledCurated();
    if (!bundled) return;
    const snapshot: CatalogSnapshot = { ...bundled, source: 'cache', partial: false };
    await this.writeCache(snapshot);
    this.cached.set('curated', snapshot);
  }

  /** Fetch the curated remote source (default maintained install registry). */
  async fetchCurated(remoteUrl: string, signal?: AbortSignal): Promise<CatalogSnapshot> {
    let fetched: CatalogEntry[];
    const configuredUrl = remoteUrl.trim();
    if (configuredUrl === '') {
      fetched = await fetchCommunityRegistry(DEFAULT_INSTALL_REGISTRY_URL, { signal });
    } else {
      const response = await fetch(configuredUrl, { signal, headers: { 'User-Agent': 'dsh-plugin-panel' } });
      if (!response.ok) throw new Error(`catalog fetch failed: HTTP ${response.status} from ${configuredUrl}`);
      const text = await response.text();
      const isJson = configuredUrl.endsWith('.json') || text.trimStart().startsWith('{');
      if (isJson) {
        const file = JSON.parse(text) as RemoteCatalogFile;
        fetched = file.entries ?? parseCommunityRegistry(file);
      } else {
        fetched = parseAwesomeMarkdown(text);
      }
    }
    if (fetched.length === 0) throw new Error('catalog fetch returned no entries');
    const merged = mergeWithSeed(fetched);
    const entries = await this.enrichStars(merged);
    const snapshot: CatalogSnapshot = { entries, fetchedAt: new Date().toISOString(), source: 'remote', lens: 'curated' };
    await this.writeCache(snapshot);
    this.cached.set('curated', { ...snapshot, source: 'cache' });
    return snapshot;
  }

  /**
   * Download a prebuilt full-repo catalog.json from a remote URL (v3 refresh
   * path: one fast single-file download instead of crawling GitHub pages).
   */
  async fetchPrebuiltAll(remoteUrl: string, signal?: AbortSignal): Promise<CatalogSnapshot> {
    const url = remoteUrl.trim() || DEFAULT_FULL_CATALOG_URL;
    const previous = await this.readCache('all') ?? await this.readBundledAll();
    const headers: Record<string, string> = { 'User-Agent': 'dsh-plugin-panel' };
    if (previous?.etag) headers['If-None-Match'] = previous.etag;
    if (previous?.lastModified) headers['If-Modified-Since'] = previous.lastModified;
    const response = await fetch(url, { signal, headers });
    if (response.status === 304 && previous) {
      // A successful revalidation resets cache age even though no body was
      // downloaded, so startup checks remain capped at once per hour.
      await this.writeCache(previous);
      return previous;
    }
    if (!response.ok) throw new Error(`catalog download failed: HTTP ${response.status} from ${url}`);
    const parsed = JSON.parse(await response.text()) as RemoteCatalogFile;
    if (!Array.isArray(parsed.entries) || parsed.entries.length === 0) throw new Error('远程目录文件没有 entries');
    if (parsed.manifest?.schema !== 'plugin-panel-catalog@1') throw new Error('远程目录 schema 不受支持');
    const ids = new Set(parsed.entries.map((entry) => entry.id));
    if (ids.size !== parsed.entries.length || parsed.entries.some((entry) => !entry.id || !entry.title)) throw new Error('远程目录包含重复或无效条目');
    if (parsed.entries.some((entry) => entry.installVerified && (!entry.install || /[\r\n;&|<>]/.test(entry.install)))) {
      throw new Error('远程目录包含无效的已验证安装目标');
    }
    const totalHits = parsed.manifest.totalHits ?? parsed.entries.length;
    const fetchedCount = parsed.manifest.fetchedCount ?? parsed.entries.length;
    const coveragePct = totalHits > 0 ? (fetchedCount / totalHits) * 100 : 100;
    // GitHub Search's total_count is not a stable snapshot.  A long partitioned
    // crawl can legitimately finish with a lower percentage when repositories
    // are created/deleted during it.  `gaps` plus shrink protection are the
    // actual integrity gates; coveragePct remains an informational metric.
    if ((parsed.manifest.gaps ?? 0) !== 0) throw new Error('远程目录分桶存在缺口，已保留本地旧目录');
    const previousFetched = previous?.fetchedCount ?? previous?.entries.length ?? 0;
    if (previousFetched > 0 && fetchedCount < previousFetched * 0.95) {
      throw new Error('远程目录抓取数量异常缩水，已保留本地旧目录');
    }
    const merged = mergeWithSeed(parsed.entries);
    const snapshot: CatalogSnapshot = {
      entries: merged,
      fetchedAt: new Date().toISOString(),
      source: 'remote',
      lens: 'all',
      totalHits,
      generatedAt: parsed.manifest.generatedAt,
      fetchedCount,
      coveragePct,
      gaps: parsed.manifest.gaps,
      etag: response.headers.get('etag') ?? undefined,
      lastModified: response.headers.get('last-modified') ?? undefined,
      partial: false,
    };
    await this.writeCache(snapshot);
    this.cached.set('all', { ...snapshot, source: 'cache' });
    return snapshot;
  }

  /**
   * Download a prebuilt curated index (catalog/curated.json) from a remote URL
   * (v6.12 refresh path — one fast single-file download).
   */
  async fetchPrebuiltCurated(remoteUrl: string, signal?: AbortSignal): Promise<CatalogSnapshot> {
    // A blank setting means "use our maintained selected catalogue", not
    // "re-save the copy shipped with this plugin version".
    const url = remoteUrl.trim() || DEFAULT_CURATED_CATALOG_URL;
    const response = await fetch(url, { signal, headers: { 'User-Agent': 'dsh-plugin-panel' } });
    if (!response.ok) throw new Error(`catalog download failed: HTTP ${response.status} from ${url}`);
    const parsed = JSON.parse(await response.text()) as RemoteCatalogFile;
    if (!Array.isArray(parsed.entries) || parsed.entries.length === 0) throw new Error('远程目录文件没有 entries');
    if (parsed.manifest?.schema && parsed.manifest.schema !== 'plugin-panel-curated@1') throw new Error('远程目录 schema 不受支持');
    const ids = new Set(parsed.entries.map((entry) => entry.id));
    if (ids.size !== parsed.entries.length || parsed.entries.some((entry) => !entry.id || !entry.title)) throw new Error('远程目录包含重复或无效条目');
    const merged = mergeWithSeed(parsed.entries);
    const entries = await this.enrichStars(merged);
    const snapshot: CatalogSnapshot = {
      entries,
      fetchedAt: parsed.manifest?.generatedAt ?? new Date().toISOString(),
      source: 'remote',
      lens: 'curated',
      totalHits: entries.length,
      generatedAt: parsed.manifest?.generatedAt,
      fetchedCount: parsed.manifest?.fetchedCount,
      partial: false,
    };
    await this.writeCache(snapshot);
    this.cached.set('curated', { ...snapshot, source: 'cache' });
    return snapshot;
  }

  /** Invalidate one lens's in-memory cache (used after a failed refresh). */
  invalidate(lens: CatalogLens): void {
    this.cached.delete(lens);
  }
}
