# 能力对齐审计 — dsh-humanize vs humanfia 生态

> 快照日期：2026-08-24 · 对照对象：[humanize2](https://github.com/humanfia/humanize2)、[oh-my-humanize](https://github.com/humanfia/oh-my-humanize)、[humanize-plugin](https://github.com/humanfia/humanize-plugin)（本地克隆 + 公开资料）
>
> 状态标记：✅ 机制级对齐 · 🔁 宿主等价（同一职责由 DeepSeek Harness 宿主原语兑现） · 🚧 部分对齐/预留 · ⛔ 非目标

## 结论（先读这段）

**流核心机制已机制级对齐。** Flow 生命周期（draft → check → lock → review → run / resume / stop）、规范化 + SHA-256 锁身份（`flk_<digest>`，加载重验防篡改）、HMAC 签名终态评审门禁、append-only 事件日志回放恢复、trace 导出、哈希锚定编辑——这套让 humanize2 与 humanize-plugin 立身的纪律，在本预设中以零 npm 依赖的 DSH 插件原生实现。

**平台设施由宿主等价承担。** 多编码 CLI 编排、凭据存储、系统调用级沙箱、终端 UI、PTY/剪贴板等本机能力，属于运行平台的原语；在 DSH 中分别由 subagents 注册表、credential store、sandbox/approval 栈、Web GUI、fs/shell 服务兑现。这不算缺失，算换底座。

**明确列出的非目标不装样子。** 见下文各表的 ⛔ 行与文末差距清单；每一条都给出两条补齐路径——等上游/宿主演进，或用「定制与领域特化」工作流（见 README 对应章节与 `install.ps1 -PresetName`）自行扩展成领域变体。

## humanize2（hmz，Python）对照

| humanize2 能力 | 说明 | 本预设 / DSH 宿主对应物 | 状态 |
|---|---|---|---|
| Flow 编排生命周期 | FlowDraft → flow_check 结构校验 → FlowLock | `plugins/flow-kernel.mjs` 纯函数内核 + `flow_check` / `flow_lock` | ✅ |
| 锁身份防篡改 | 语义规范化字节 + `flk_<digest>` 身份 | `identityOf` / `lockTamperReason`，加载时重验哈希 | ✅ |
| 人工评审门禁 | Review Store：终态不可变、单一决策入口 | HMAC 签名绑定 + `flow_review_prepare` / `flow_review_decide`；MAC 校验失败硬失败 | ✅ |
| 运行可恢复 | append-only 事件为唯一权威，resume 回放 | `.humanize/runs/<id>/events.jsonl` + `replayRun` + `flow_resume`（"周四停下的循环，周四继续"） | ✅ |
| Trace 观测 | `hmz trace collect` → ui.perfetto.dev | `trace_export`（md / chrome-json / jsonl） | ✅ |
| 哈希锚定编辑 | oh-my-pi/omp 血统的 anchored edits | `hash_file` + `edit_anchored` 整文件 SHA-256 校验 | ✅ |
| 多 agent 后端 | claude/codex/kimi/qwen/grok/pi/opencode/mimo/acp/agy/dsh 十余种 CLI | subagents 注册表 spawn/fork 子代理；模型三级路由（节点 > flow > 配置 > 会话）；codex/claude-code provider 行在组合中预留 | 🔁 宿主等价 |
| 权限与沙箱 | permission prompts disabled；coganchor seccomp/ptrace/syscall 过滤/netproxy/standin | DSH 宿主 sandbox + approval 栈；裁判命令经沙箱化 shell 服务执行；组合不放宽任何宿主约束 | 🔁 宿主等价 |
| 机器/容器隔离 | machines：Docker 后端 | DSH worktree 隔离（`worktree_*` 工具族）覆盖仓库级隔离；容器级隔离暂无内置 | 🚧 部分对齐 |
| 凭据与账号 | providers login/redirect/retry/store、key accounts | DSH Settings → Models 凭据存储；预设代码零凭据接触面 | 🔁 宿主等价 |
| 目标与长循环 | goals / cycles / AFK unattended | `create_goal`/`update_goal` 同会话目标 + `ralph` fresh-agent 循环 + `workflow` 大规模编排 | ✅ / 🔁 宿主等价 |
| 转向与问卷 | steering / questionnaires | `ask_user_question` + `send_message`/`interrupt_agent` 会话内转向 | 🔁 宿主等价 |
| Skills 体系 | 技能目录随 agent 分发 | `skills/humanize-flow/SKILL.md` + `skill-filesystem` 扫描预置自带 `skills/` | ✅ |
| Shapes 形态 | 会话形态模板 | persona 文本 + 组合行即形态；未做独立 shape 系统 | 🚧 部分对齐 |
| Flowverses / KDA / AgentKaggle / FlowBench | 流程宇宙市场与独立应用 | —— | ⛔ 非目标（FlowBench 官方尚未发布；市场属独立应用；其"工作方式"已化为运行时纪律）。补齐路径见文末 |

## oh-my-humanize（omh）对照

| omh 能力 | 说明 | 本预设 / DSH 宿主对应物 | 状态 |
|---|---|---|---|
| 工作流原生终端代理 | TUI、40+ providers、32 内置工具、~55k 行 Rust 核心 | 本预设不是终端产品而是 DSH 会话内的纪律层；终端/模型接入由 DSH 承担 | 🔁 宿主等价 |
| `.omhflow` 工作流工件 + adaptive workflow changes | 运行中自适应改流程 | Humanize 纪律：变更一律折回草案重走 check/lock/review，不热改运行中的图（可中断 resume 替代） | 🚧 设计取舍 |
| pi-natives 本机扩展 | pty、剪贴板、语法高亮、sixel、字体、glob、grep、HTML 渲染 | DSH Web GUI 与 fs/shell 宿主服务覆盖同等需求；预设"禁 npm import / 零捆绑原生件"红线 | 🔁 宿主等价 |
| pi-ast / LSP·DAP ops | 代码结构与语言服务 | `agent.cordis.yml` 尾部预留 `lsp-provider` / `tool-lsp` 扩展行，宿主具备即取消注释 | 🚧 预留 |
| pi-iso 文件系统隔离 | overlayfs/projfs/reflink 写时复制 | DSH `worktree_create` / `worktree_begin_next_iteration` 隔离会话工作目录 | 🔁 宿主等价 |
| `.omp` 技能包 | semantic-compression、system-prompts、tool-prompt-optimization | `skills/` 目录同构机制；宿主已内置 `prompt_optimize` 工具 | ✅ / 🔁 宿主等价 |
| vouch CI | vouch-pr / vouch-manage 人工背书流水线 | GitHub Actions 三项检查矩阵 + HMAC 评审门禁承担"改动必须过审"的等价纪律 | 🚧 部分对齐 |

## humanize-plugin（Rust MCP 插件）对照

humanize-plugin 是"把简短工作流请求变成 checked、reviewed、runnable 的 MCP flow 包"的实现，也是本预设工具面的直系前身。

| humanize-plugin 能力 | 说明 | 本预设对应物 | 状态 |
|---|---|---|---|
| `flow_suggest` 起草 | 从一句请求起草 flow 包 | `flow_draft`（整文档替换）+ `humanize-flow` 技能教模型正确写法 | ✅ |
| `flow_check` / `flow_lock` | 结构校验与锁定 | 同名工具 + `flk_<digest>` 加载重验 | ✅ |
| `prepare_flow_review` / `decide_flow_review` | 评审包准备与人工决策 | `flow_review_prepare` / `flow_review_decide`（HMAC 签名、终态不可变、拒绝理由折回草案） | ✅ |
| `run_flow` | 校验绑定后执行 | `flow_run`（验证签名绑定才调度；gate 节点纯裁判） | ✅ |
| tmux window→run、pane→节点激活 | tmux 适配器驱动多个编码 CLI | run 目录 + `node/activation_*` 事件；subagents 注册表驱动 spawn/fork 子代理 | 🔁 宿主等价 |
| driver/persistence、run_assets、transcript | 运行资产持久化 | `.humanize/runs/<id>/`（events.jsonl + artifacts/） | ✅ |
| input_ledger / participant_binding | 人作为参与者的输入账本 | "评审即下一个提示"：人在 `flow_review_decide` 决策、`ask_user_question` 收敛歧义；无逐轮输入账本 | 🚧 部分对齐 |
| Codex/Claude Code 双客户端接入 | marketplace + hooks 配置生成 | DSH cordis 组合一次挂载全宿主生效 | 🔁 宿主等价 |

## 差距清单与两条补齐路径

| # | 差距 | 现状 | 路径 A：等上游/宿主 | 路径 B：自行定制（推荐读法 → README「定制与领域特化」章节） |
|---|---|---|---|---|
| 1 | 容器级隔离 | worktree 已覆盖仓库级 | 等 DSH 宿主机基层演进 | 变体里用 `ctx.tools.register` 包装 `docker` CLI 成受控工具 |
| 2 | LSP/DAP 语言服务 | 组合尾部扩展行已预留 | 宿主 LSP provider 就绪后取消注释即可 | 无需改预设 |
| 3 | 流程模板市场（flowverse） | 无 | 关注官方 FlowBench 动向 | 把领域方法论沉淀为 `skills/<name>/SKILL.md` 随变体分发 |
| 4 | 逐轮人工输入账本 | 评审门禁 + 提问工具 | 等宿主 steering 能力演进 | 变体中加"检查点"工具，把人工确认写入事件日志 |
| 5 | 第三方 CLI 子代理（codex/claude-code…） | 组合行存在但 disabled | 上游 provider 稳定后开启 | 仿照现有行注册任意 provider，一行即插 |

## 扩展点速查（变体同样受红线约束）

- **加工具**：`tool-flow.mjs` 里 `ctx.tools.register({...})`；参数用 JSON Schema；`execute(args, exec)` 经 `ctx.get(...)` 消费宿主服务（shell/fs/subagents…）。
- **加服务**：新模块导出 `name` + `apply(ctx)`，`ctx.provide('名字', api)` 发布；在 `agent.cordis.yml` 的 `humanize` 组加一行 `name: ./plugins/<模块>.mjs`；组内 isolate realm 必须保留。
- **加技能**：`skills/<name>/SKILL.md`（frontmatter：name / description），随预置自动被发现。
- **改 persona**：`agent.cordis.yml` 的 persona 文本段。
- **落成变体**：`powershell -File tools\install.ps1 -PresetName humanize-ZZZZ`（macOS/Linux：`PRESET_NAME=humanize-ZZZZ bash tools/install.sh`）——一条命令把当前定制安装为独立预设，与原版并存。
- **四条红线对变体同样生效**：① 本地模块禁 import 任何 npm 包（只用 `node:` 内置）；② 服务必须在 isolate realm 组内；③ `events.jsonl` 是唯一权威，缓存不得反成事实源；④ 评审决策一次写入永不覆盖，MAC 校验失败必须硬失败。

---

*本文档只做诚实盘点，不做营销。humanize2 以 Apache-2.0、oh-my-humanize 以 MIT 发行；本项目为理念移植的原创实现，致谢与灵感声明见 [README.md](../README.md#致谢与灵感来源)。*
