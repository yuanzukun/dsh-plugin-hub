# Humanize 模式 — 预制 Agent 预设设计

日期：2026-08-23
状态：已批准（用户确认）
来源研究：https://humanfia.ai/ · https://github.com/humanfia/humanize2 · https://github.com/humanfia/oh-my-humanize · https://github.com/humanfia/humanize-plugin

## 1. 目标

为 DeepSeek Harness 提供一个**预制 agent 模式（agent preset）**，以最兼容 DSH 的方式近乎完整地复刻
humanfia 生态的核心机制。交付物是一个自包含的预置目录：cordis 组合 + 自带零依赖本地插件模块，
源码保留在本工作区，可继续迭代。

### 复刻范围（对应原版机制）

| humanfia 原版机制 | 本预设实现 |
| --- | --- |
| FlowDraft → check → FlowLock（SHA-256 身份 `flk_<digest>`，规范化防重排篡改） | `flow_draft` / `flow_check` / `flow_lock` + flow-kernel 规范化与摘要 |
| 六原语内核 Node / Contract(verify) / Artifact / Board / Route / Event | 节点（prompt+executor+produces+verify）、裁判命令、产物、事实板、谓词路由、append-only 事件 |
| Review Store（HMAC、Pending→Approved/Rejected/Bypassed 终态不可变、单一决策工具） | `flow_review_prepare` / `flow_review_decide` + `.humanize/reviews` 签名存储 |
| 运行时（事件为权威、快照为缓存；驱动已登录的 agent） | 事件回放调度器；节点经 `subagents` 注册表派 spawn/fork 子代理执行 |
| 可恢复长循环（“a loop that stopped on Thursday carries on”） | `flow_resume` 从 events.jsonl 回放恢复中断 run |
| trace（每次运行留痕，可导入 Perfetto） | 每 run 一份 JSONL；`trace_export` 出 Markdown 与 Chrome-JSON |
| “评审即下一个提示”“Lean 接受它否则不算”（裁判纪律） | verify 命令 exit 0 才接受；persona 与 prompt section 方法论 |
| oh-my-humanize 哈希锚定编辑 | `edit_anchored`：整文件 SHA-256 期望值校验 + 字面替换 |

明确不复刻：KDA/HOA/AgentKaggle/FlowBench 本体（它们是独立应用/未发布），Python 流格式
（humanize2 的 flow 是 Python 目录；此处改为声明式 JSON 文档，更契合 DSH 的工具调用模型）。

## 2. 形态决策

- **预制 Agent 预设**（用户选定）：装入 `${DSH_HOME}/.agent-presets/humanize/` 后从 roster 选择。
- 关键机制：组合行 `name:` 支持**相对路径**——预置目录自带插件模块随目录移动；
  绝对路径与包名亦可（`packages/preset/agent-presets/src/mount.ts` 的 import 解析）。
- 本地模块零 npm 依赖（用户根目录无 node_modules 向上解析），只用 `node:` 内置模块 +
  ctx 注入的服务。因此不导出 schemastery `Config`，改读同目录 `humanize.config.json`。

## 3. 目录结构

```
humanize-preset/
├── agent.cordis.yml          # standard 全部行 + humanize 组（isolate realm）
├── preset.yml                # name/description 元数据
├── README.md                 # 架构 + 二次开发指南
├── humanize.config.json      # stateRootMode 等 knobs
├── plugins/
│   ├── flow-kernel.mjs       # 纯函数内核（无 I/O）
│   ├── humanize-store.mjs    # 服务 humanizeStore（磁盘持久化/HMAC/事件）
│   ├── tool-flow.mjs         # 12 个模型工具 + 运行时调度器
│   └── edit-anchored.mjs     # edit_anchored 工具
└── skills/humanize-flow/SKILL.md
```

## 4. 内核数据模型

```jsonc
{
  "name": "fix-build",                  // slug
  "description": "…",
  "board": { "goal": "…" },             // 初始事实（字符串→任意 JSON）
  "nodes": [{
    "id": "implement",
    "title": "…",
    "prompt": "给子代理的完整指令",
    "executor": "spawn" | "fork" | "gate",
    "produces": ["build.status"],        // 成功时写入的 artifact 键
    "verify": [{ "command": "pnpm -r build", "timeoutMs": 600000 }],
    "maxActivations": 3                  // 循环护栏，默认 3
  }],
  "routes": [{
    "from": "audit", "to": "implement",
    "kind": "on_success" | "on_failure", // 默认 on_success
    "when": { "exists": "review.ok" } | { "truthy": "board.key" },
    "forEach": "plan.items"              // 数组 artifact 展开并行激活（可选）
  }]
}
```

- 入口节点 = 无入边节点；就绪 = 全部入边来源终端且谓词真。
- artifact 值 = 子代理最终文本（或 gate 节点的 verify 输出摘要）。
- 循环允许（回边），受 `maxActivations` 约束；超限 → run 失败并诊断。
- 失败路由缺省时，节点失败即 run 失败。

### 规范化与身份

语义无序集合（nodes 按 id、routes 按 from|to|kind|when|forEach 签名）排序后做稳定序列化，
SHA-256 → `flk_<digest前16>`；锁文件存规范化文档+诊断+双哈希，加载重验，不一致拒绝。

## 5. 存储布局

```
<workspace>/.humanize/
├── flows/<slug>.draft.json
├── flows/<slug>.<digest8>.lock.json
├── runs/<runId>/run.json               # lockId/reviewBinding/createdAt
├── runs/<runId>/events.jsonl           # 权威事件日志（append-only）
├── runs/<runId>/artifacts/<key>.txt
├── reviews/frv_<rand>/prepared.json    # HMAC-SHA256 签名
├── reviews/frv_<rand>/decision.json    # 一次写入，终态不可变
└── review-mac.key                      # 安装级随机密钥（0600 语义）
```

状态根默认 `<session cwd>/.humanize/`（flow 与仓库同址、可版本化）；`stateRootMode: "home"`
可切换到 `~/.dsh/humanize/`（对齐 humanize-plugin 把状态放项目外的偏好）。

事件类型：`run/start|finish|fail`、`node/ready`、`node/activation_start|end`、
`node/verify_ok|verify_fail`、`artifact/store`、`route/taken`、`fanout/expand`、
`review/prepared|decided`。恢复 = 读 events.jsonl 重放进度缓存，未终端节点重新激活。

## 6. 工具面（13 个）

`flow_draft` `flow_check` `flow_lock` `flow_list` `flow_show`
`flow_review_prepare` `flow_review_decide`
`flow_run` `flow_status` `flow_resume` `flow_stop`
`trace_export` `edit_anchored`

- `flow_run` 异步启动调度器立即返回 runId（不阻塞模型回合）；进度走 `flow_status`。
- `flow_run` 校验评审绑定 ∈ {approved, bypassed} 且 HMAC/哈希有效。
- referee 经 **shell 服务**执行（尊重沙箱/审批栈）；子代理经 **subagents 服务**。
- 会话可见性：评审状态以文件为准（`prepared.json` / `decision.json` / `review.md`），可见性由工具回执与运行事件日志
  （`events.jsonl`）承担。**不向会话日志写自定义事件**：原版 harness 的持久层对未知事件类型按必需事件拒绝解读整份
  日志（`SessionFormatUnsupportedError`），自定义类型会令会话历史永久不可加载——preset 必须只依赖原版 harness 的公开行为。

## 7. 组合

- 继承 standard 全部行；新增 `humanize` 组：
  `isolate: { humanizeStore: true }` 包住 store 行 + tool-flow 行 + edit-anchored 行。
  两行都 inject `humanizeStore`（组内兄弟服务）；`tools` 为硬依赖。
- persona 替换为 flow-first 人格；新增 prompt section（方法论，order 120）。
- skill 注册进预置层技能目录（skill-filesystem 发现 `<preset>/skills/`）。若不生效则把
  SKILL.md 路径写进 prompt section 作为兜底文档。
- LSP 等扩展点以注释行给出（README 说明开启方法）。

## 8. 验证

1. Node 冒烟：直接 import 每个 .mjs 断言导出形状。
2. YAML 解析 + 行结构静态审查（realm/consumer/相对路径规则）。
3. host-only 动态探针调 `agentPresets.standingKeyFor('humanize')` 做真实挂载校验；
   若审批通道不可用，退回静态检查并请用户开 Humanize 模式会话实测。
4. 端到端冒烟（可选）：一个两节点 gate 流（echo verify）跑通 draft→lock→review(bypass)→run→trace。

## 9. 风险与对策

- 相对路径行解析失败 → 改用绝对路径安装脚本生成组合（fallback 记录在 README）。
- 子代理深度限制/能力缺失 → executor 缺省 spawn；start 抛错时事件记录 node/activation_end(error) 并按失败路由。
- 长任务跨进程重启 → run 标记 interrupted，resume 重放；不做进程内迁移。
