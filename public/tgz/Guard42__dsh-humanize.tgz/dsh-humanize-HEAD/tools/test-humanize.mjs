/**
 * Smoke tests for the Humanize preset's local plugin modules.
 * Run: node tools/test-humanize.mjs
 */
import assert from 'node:assert/strict'
import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const presetDir = new URL('../', import.meta.url)

// ── kernel ────────────────────────────────────────────────────────────────
const kernel = await import(new URL('plugins/flow-kernel.mjs', presetDir).href)
{
  // stableStringify ignores key order
  assert.equal(
    kernel.stableStringify({ b: 1, a: [2, { z: 1, y: 2 }] }),
    kernel.stableStringify({ a: [2, { y: 2, z: 1 }], b: 1 }),
  )

  const doc = {
    name: 'demo',
    description: 'd',
    board: { goal: 'x' },
    nodes: [
      { id: 'audit', title: 'a', prompt: 'p', executor: 'spawn', produces: ['audit.ok'], verify: [{ command: 'exit 0' }] },
      { id: 'implement', prompt: 'p', verify: [{ command: 'exit 0' }] },
    ],
    routes: [{ from: 'implement', to: 'audit' }],
  }
  let diags = kernel.checkFlow(doc)
  assert.equal(diags.filter(d => d.severity === 'error').length, 0, JSON.stringify(diags))

  // warnings exist for missing title-less? (no warning expected here besides none) — just record
  // invalid docs produce errors
  diags = kernel.checkFlow({ name: 'Bad Name', nodes: [], routes: [{ from: 'x', to: 'y' }] })
  assert.ok(diags.some(d => d.severity === 'error' && d.path === '$.name'))
  assert.ok(diags.some(d => d.path === '$.nodes'))

  // duplicate ids rejected
  diags = kernel.checkFlow({
    name: 'dup',
    nodes: [
      { id: 'a', verify: [{ command: 'x' }] },
      { id: 'a', verify: [{ command: 'x' }] },
    ],
  })
  assert.ok(diags.some(d => /duplicate node id/.test(d.message)))

  // bad predicate rejected
  diags = kernel.checkFlow({
    name: 'badpred',
    nodes: [
      { id: 'a', verify: [{ command: 'x' }] },
      { id: 'b', verify: [{ command: 'x' }] },
    ],
    routes: [{ from: 'a', to: 'b', when: { equals: 'x' } }],
  })
  assert.ok(diags.some(d => /when must be exactly one/.test(d.message)))

  // cycle warning + still no error (entry node feeds the loop)
  diags = kernel.checkFlow({
    name: 'loop',
    nodes: [
      { id: 'entry', prompt: 'start', verify: [{ command: 'x' }] },
      { id: 'worker', prompt: 'work', verify: [{ command: 'x' }], maxActivations: 2 },
      { id: 'audit', prompt: 'audit', verify: [{ command: 'x' }] },
    ],
    routes: [
      { from: 'entry', to: 'worker' },
      { from: 'worker', to: 'audit' },
      { from: 'audit', to: 'worker' },
    ],
  })
  assert.equal(diags.filter(d => d.severity === 'error').length, 0)
  assert.ok(diags.some(d => d.severity === 'warning' && /cycle/.test(d.message)))

  // canonicalization sorts nodes and routes; identity stable across authoring order
  const reordered = {
    ...doc,
    nodes: [...doc.nodes].reverse(),
    routes: [...doc.routes].reverse(),
  }
  const c1 = kernel.canonicalizeFlow(doc)
  const c2 = kernel.canonicalizeFlow(reordered)
  assert.deepEqual(c1, c2)
  const id1 = kernel.identityOf(c1)
  const id2 = kernel.identityOf(c2)
  assert.equal(id1.lockId, id2.lockId)
  assert.match(id1.lockId, /^flk_[0-9a-f]{16}$/)
  assert.match(id1.contentHash, /^sha256:[0-9a-f]{64}$/)

  // tamper detection
  const tampered = { lockId: id1.lockId, contentHash: id1.contentHash, flow: { ...c1, description: 'changed' } }
  assert.ok(kernel.lockTamperReason(tampered))
  assert.equal(kernel.lockTamperReason({ lockId: id1.lockId, contentHash: id1.contentHash, flow: c1 }), undefined)

  // predicates
  const facts = { present: 'text', empty: '', zero: 0, flag: true }
  assert.equal(kernel.evalPredicate({ exists: 'present' }, facts), true)
  assert.equal(kernel.evalPredicate({ exists: 'absent' }, facts), false)
  assert.equal(kernel.evalPredicate({ truthy: 'empty' }, facts), false)
  assert.equal(kernel.evalPredicate({ truthy: 'zero' }, facts), false)
  assert.equal(kernel.evalPredicate({ truthy: 'flag' }, facts), true)
  // model reference parsing
  assert.deepEqual(kernel.parseModelRef('deepseek/deepseek-reasoner'), { provider: 'deepseek', model: 'deepseek-reasoner' })
  assert.deepEqual(kernel.parseModelRef('some-model'), { model: 'some-model' })
  // outer whitespace trims; INTERNAL whitespace rejects
  assert.deepEqual(kernel.parseModelRef(' spaced/name '), { provider: 'spaced', model: 'name' })
  assert.equal(kernel.parseModelRef('has space'), undefined)
  assert.equal(kernel.parseModelRef('a/b c'), undefined)
  assert.equal(kernel.parseModelRef('a/'), undefined)
  assert.equal(kernel.parseModelRef('/b'), undefined)
  assert.equal(kernel.parseModelRef(''), undefined)
  assert.equal(kernel.parseModelRef(undefined), undefined)

  // canonicalization keeps flow/node models; identity changes with them
  const modeled = {
    name: 'models',
    model: 'deepseek/deepseek-chat',
    nodes: [
      { id: 'cheap', prompt: 'p', verify: [{ command: 'x' }] },
      { id: 'strong', prompt: 'p', verify: [{ command: 'x' }], model: 'deepseek/deepseek-reasoner' },
    ],
    routes: [],
  }
  const cm = kernel.canonicalizeFlow(modeled)
  assert.equal(cm.model, 'deepseek/deepseek-chat')
  assert.equal(cm.nodes.find(n => n.id === 'strong').model, 'deepseek/deepseek-reasoner')
  assert.equal(cm.nodes.find(n => n.id === 'cheap').model, undefined)
  const diagsM = kernel.checkFlow(modeled)
  assert.equal(diagsM.filter(d => d.severity === 'error').length, 0, JSON.stringify(diagsM))
  const plain = kernel.canonicalizeFlow({ ...modeled, model: undefined })
  assert.notEqual(kernel.identityOf(cm).lockId, kernel.identityOf(plain).lockId)

  // invalid model refs are check errors
  const badModel = {
    name: 'badmodel',
    model: 'has space',
    nodes: [{ id: 'a', prompt: 'p', verify: [{ command: 'x' }], model: 'a/' }],
  }
  const diagsBad = kernel.checkFlow(badModel)
  assert.ok(diagsBad.some(d => d.path === '$.model'))
  assert.ok(diagsBad.some(d => d.path === '$.nodes[0].model'))

  console.log('kernel ✔')
}

// ── store ─────────────────────────────────────────────────────────────────
const storeModule = await import(new URL('plugins/humanize-store.mjs', presetDir).href)
{
  const store = storeModule.createStore({ stateRootMode: 'workspace', defaultExecutor: 'spawn', maxParallel: 2, verifyTimeoutMs: 1000 })
  const root = mkdtempSync(join(tmpdir(), 'humanize-test-'))

  // drafts
  const doc = { name: 'demo', nodes: [{ id: 'only', verify: [{ command: 'exit 0' }] }], routes: [] }
  store.writeDraft(root, doc)
  assert.deepEqual(store.readDraft(root, 'demo').name, 'demo')
  assert.equal(store.listDrafts(root).length, 1)

  // locks
  const canonical = kernel.canonicalizeFlow(doc)
  const { lockDoc, lockId, contentHash } = store.writeLock(root, canonical)
  assert.equal(kernel.lockTamperReason(lockDoc), undefined)
  assert.equal(store.readLock(root, lockId).lockId, lockId)
  void contentHash

  // reviews: prepare → pending → decide approved → authorized; tamper fails hard
  const review = store.prepareReview(root, lockDoc)
  let binding = store.readReviewBinding(root, review.reviewId, lockDoc.contentHash)
  assert.equal(binding.decision, 'pending')
  assert.throws(() => store.readReviewBinding(root, review.reviewId, 'sha256:wrong'))
  store.decideReview(root, review.reviewId, 'approved')
  binding = store.readReviewBinding(root, review.reviewId, lockDoc.contentHash)
  assert.equal(binding.decision, 'approved')

  // decisions immutable; reject requires reason
  assert.throws(() => store.decideReview(root, review.reviewId, 'rejected', 'second thoughts'))
  assert.throws(() => store.decideReview(root, `frv_${'0'.repeat(12)}`, 'rejected'))

  // MAC forgery detected
  const preparedPath = join(review.dir, 'prepared.json')
  const prepared = JSON.parse(readFileSync(preparedPath, 'utf8'))
  prepared.payload.flowName = 'forged'
  writeFileSync(preparedPath, JSON.stringify(prepared))
  assert.throws(() => store.readReviewBinding(root, review.reviewId, lockDoc.contentHash), /MAC mismatch/)

  // runs + events sequence numbers
  const runId = store.newRunId()
  store.createRun(root, runId, { runId, lockId, flowName: 'demo' })
  const e1 = store.appendEvent(root, runId, { type: 'run/start' })
  const e2 = store.appendEvent(root, runId, { type: 'run/finish' })
  assert.equal(e1.seq, 0)
  assert.equal(e2.seq, e1.seq + 1)
  assert.equal(store.readEvents(root, runId).length, 2)

  // artifacts
  const artifactPath = store.saveArtifact(root, runId, 'build.status', 'green')
  assert.equal(store.readArtifactText(artifactPath), 'green')

  console.log('store ✔')
}

// ── tool-flow module shape ────────────────────────────────────────────────
{
  const toolFlow = await import(new URL('plugins/tool-flow.mjs', presetDir).href)
  assert.equal(toolFlow.name, 'humanize-flow')
  assert.deepEqual(toolFlow.inject, ['humanizeStore', 'tools'])
  assert.equal(typeof toolFlow.apply, 'function')

  const humanizeStore = await import(new URL('plugins/humanize-store.mjs', presetDir).href)
  assert.equal(humanizeStore.name, 'humanize-store')
  assert.equal(typeof humanizeStore.apply, 'function')
  console.log('tool-flow module shape ✔')
}

// ── bundle installer bridge ───────────────────────────────────────────────
{
  const installer = await import(new URL('bridge/installer.mjs', presetDir).href)
  assert.equal(installer.name, 'humanize-preset-installer')
  assert.equal(typeof installer.apply, 'function')
  assert.equal(installer.MANIFEST.length, 8)

  const pkgRoot = fileURLToPath(presetDir)
  const dest = mkdtempSync(join(tmpdir(), 'humanize-bundle-'))

  // first install: everything copied
  const first = installer.installPreset(pkgRoot, dest)
  assert.equal(first.copied, 8)
  assert.equal(first.skipped.length, 0)
  assert.ok(readFileSync(join(dest, 'preset.yml'), 'utf8').includes('name:'))

  // idempotent rerun: files still match the shipped stamp -> recopied
  const second = installer.installPreset(pkgRoot, dest)
  assert.equal(second.copied, 8)

  // user-modified files are left untouched on upgrade
  writeFileSync(join(dest, 'humanize.config.json'), '{ "user": true }')
  const third = installer.installPreset(pkgRoot, dest)
  assert.equal(third.copied, 7)
  assert.ok(third.skipped.some((entry) => entry.startsWith('humanize.config.json')))
  assert.equal(JSON.parse(readFileSync(join(dest, 'humanize.config.json'), 'utf8')).user, true)

  console.log('bundle installer ✔')
}

console.log('ALL SMOKE TESTS PASSED')
