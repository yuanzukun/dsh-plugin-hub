#!/usr/bin/env bash
# Install / update the Humanize preset into the DSH agent-preset root.
#
# Usage (local clone):
#   bash tools/install.sh
# Usage (remote one-shot):
#   curl -fsSL https://raw.githubusercontent.com/Guard42/dsh-humanize/main/tools/install.sh | bash
# Usage (derived variant, e.g. a specialized humanize-ZZZZ):
#   HUMANIZE_PRESET_NAME=humanize-ZZZZ bash tools/install.sh
#
# Two modes:
#   LOCAL  - the repo root (the directory holding preset.yml, sibling of this
#            tools/ folder) exists on disk: mirror the manifest straight from it.
#   REMOTE - no local source detected: download the repository tarball from
#            GitHub codeload, extract to a temp dir and install from there.
#
# Idempotent: mirrors the fixed 8-file manifest ->
#   ~/.dsh/.agent-presets/<PRESET_NAME>
# (PRESET_NAME defaults to 'humanize'; override with HUMANIZE_PRESET_NAME or
# PRESET_NAME to install a derived variant such as 'humanize-ZZZZ' side by
# side. DSH_HUMANIZE_DEST / HUMANIZE_DEST override the whole target directory,
# e.g. for tests), then verifies every file
# SHA256. Exit codes: 0 = INSTALL OK, 2 = STALE (some copies locked or
# mismatched), anything else = hard failure.
set -euo pipefail

MANIFEST=(
  'preset.yml'
  'agent.cordis.yml'
  'humanize.config.json'
  'README.md'
  'plugins/flow-kernel.mjs'
  'plugins/humanize-store.mjs'
  'plugins/tool-flow.mjs'
  'skills/humanize-flow/SKILL.md'
)

REPO_TAR_URL='https://codeload.github.com/Guard42/dsh-humanize/tar.gz/refs/heads/main'

PRESET_NAME="${HUMANIZE_PRESET_NAME:-${PRESET_NAME:-humanize}}"

if [ -n "${DSH_HUMANIZE_DEST:-}" ]; then
  DEST="$DSH_HUMANIZE_DEST"
elif [ -n "${HUMANIZE_DEST:-}" ]; then
  DEST="$HUMANIZE_DEST"
else
  DEST="$HOME/.dsh/.agent-presets/$PRESET_NAME"
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"

SRC=''
TMPROOT=''
cleanup() { if [ -n "$TMPROOT" ]; then rm -rf "$TMPROOT"; fi; }
trap cleanup EXIT

if [ -f "$REPO_ROOT/preset.yml" ]; then
  SRC="$REPO_ROOT"
else
  TMPROOT="$(mktemp -d "${TMPDIR:-/tmp}/dsh-humanize-install.XXXXXX")"
  echo "local source not found - downloading $REPO_TAR_URL"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$REPO_TAR_URL" | tar -xz -C "$TMPROOT"
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- "$REPO_TAR_URL" | tar -xz -C "$TMPROOT"
  else
    echo 'ERROR: remote mode needs curl or wget' >&2
    exit 1
  fi
  SRC="$(find "$TMPROOT" -mindepth 1 -maxdepth 1 -type d | head -n 1)"
  if [ -z "$SRC" ] || [ ! -f "$SRC/preset.yml" ]; then
    echo 'ERROR: unexpected archive layout: no top-level repo directory found' >&2
    exit 1
  fi
fi

copied=0
for rel in "${MANIFEST[@]}"; do
  from="$SRC/$rel"
  to="$DEST/$rel"
  if [ ! -f "$from" ]; then
    echo "ERROR: manifest item missing in source: $rel" >&2
    exit 1
  fi
  mkdir -p "$(dirname "$to")"
  # cp can fail with EACCES/EPERM on protected destinations (AV/HIPS scopes);
  # report and continue so the STALE verdict below lists everything affected.
  if cp -f "$from" "$to" 2>/dev/null; then
    copied=$((copied + 1))
  else
    echo "WARN: copy blocked (antivirus/HIPS? whitelist $DEST then rerun): $rel" >&2
  fi
done

echo "copied: $copied/${#MANIFEST[@]}"

hash_of() {
  # Extract just the 64-hex digest: coreutils prefixes the whole output line
  # with '\' when the filename contains backslashes (Windows paths under MSYS).
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | grep -oE '[0-9a-fA-F]{64}' | head -n 1
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | grep -oE '[0-9a-fA-F]{64}' | head -n 1
  else
    echo 'ERROR: need sha256sum or shasum to verify the install' >&2
    exit 1
  fi
}

MISMATCH=()
for rel in "${MANIFEST[@]}"; do
  from="$SRC/$rel"
  to="$DEST/$rel"
  if [ ! -f "$to" ] || [ "$(hash_of "$from")" != "$(hash_of "$to")" ]; then
    MISMATCH+=("$rel")
  fi
done

if [ "${#MISMATCH[@]}" -eq 0 ]; then
  echo "INSTALL OK - select \"$PRESET_NAME\" in the DSH workspace preset selector (restart dsh web if it was running)"
  exit 0
else
  echo "STALE (locked this run - whitelist the destination, close whatever holds the files, rerun this script): ${MISMATCH[*]}"
  exit 2
fi
