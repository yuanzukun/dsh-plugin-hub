# Install / update the Humanize preset into the DSH agent-preset root.
#
# Usage (local clone):
#   powershell -NoProfile -ExecutionPolicy Bypass -File tools\install.ps1
# Usage (remote one-shot):
#   powershell -NoProfile -ExecutionPolicy Bypass -Command "iex (irm 'https://raw.githubusercontent.com/Guard42/dsh-humanize/main/tools/install.ps1')"
# Usage (derived variant, e.g. a specialized humanize-ZZZZ):
#   powershell -NoProfile -ExecutionPolicy Bypass -File tools\install.ps1 -PresetName humanize-ZZZZ
#
# Two modes:
#   LOCAL  - the repo root (the directory holding preset.yml, sibling of this
#            tools\ folder) exists on disk: mirror the manifest straight from it.
#   REMOTE - no local source detected (e.g. executed via iex/irm): download the
#            repository zip from GitHub codeload, extract to a temp dir and
#            install from there.
#
# Idempotent: mirrors the fixed 8-file manifest ->
#   %USERPROFILE%\.dsh\.agent-presets\<PresetName>
# (PresetName defaults to 'humanize'; override with -PresetName,
# DSH_HUMANIZE_PRESET_NAME or HUMANIZE_PRESET_NAME to install a derived
# variant such as 'humanize-ZZZZ' side by side. DSH_HUMANIZE_DEST /
# HUMANIZE_DEST override the whole target directory, e.g. for tests), then
# verifies every file
# SHA256. Exit codes: 0 = INSTALL OK, 2 = STALE (some copies locked or
# mismatched), anything else = hard failure.
#
# If copies come back "locked", the destination is almost certainly inside an
# antivirus/HIPS file-protection scope (measured on the dev machine: Huorong
# sysdiag filter denies writes to EXISTING files while allowing creation -
# ACCESS_DENIED despite permissive ACLs). Fix by whitelisting the destination
# path / the host PowerShell process in the product, or point DSH_HOME at an
# unprotected tree. Also restart the deployment before updating an already
# installed preset so no running process holds the old files open.

param(
  # Target preset directory name under .agent-presets\. Install a domain
  # specialization side by side with the stock preset, e.g.
  # -PresetName humanize-ZZZZ.
  [string]$PresetName = ''
)

$ErrorActionPreference = 'Stop'

# Windows PowerShell 5.1 negotiates TLS 1.0 by default; force TLS 1.2+ so the
# codeload download works everywhere.
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$manifest = @(
  'preset.yml',
  'agent.cordis.yml',
  'humanize.config.json',
  'README.md',
  'plugins/flow-kernel.mjs',
  'plugins/humanize-store.mjs',
  'plugins/tool-flow.mjs',
  'skills/humanize-flow/SKILL.md'
)

$repoZipUrl = 'https://codeload.github.com/Guard42/dsh-humanize/zip/refs/heads/main'

if (-not $PresetName) {
  if ($env:DSH_HUMANIZE_PRESET_NAME) { $PresetName = $env:DSH_HUMANIZE_PRESET_NAME }
  elseif ($env:HUMANIZE_PRESET_NAME) { $PresetName = $env:HUMANIZE_PRESET_NAME }
  else { $PresetName = 'humanize' }
}

if ($env:DSH_HUMANIZE_DEST) { $dest = $env:DSH_HUMANIZE_DEST }
elseif ($env:HUMANIZE_DEST) { $dest = $env:HUMANIZE_DEST }
else { $dest = Join-Path $env:USERPROFILE ".dsh\.agent-presets\$PresetName" }
$script:tempRoot = $null

function Get-SourceRoot {
  $local = $null
  if ($PSScriptRoot) { $local = Split-Path -Parent $PSScriptRoot }
  if ($local -and (Test-Path -LiteralPath (Join-Path $local 'preset.yml'))) { return $local }

  Write-Host "local source not found - downloading $repoZipUrl"
  $tempRoot = Join-Path ([IO.Path]::GetTempPath()) ('dsh-humanize-' + [Guid]::NewGuid().ToString('N'))
  $script:tempRoot = $tempRoot
  New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
  $zipPath = Join-Path $tempRoot 'dsh-humanize.zip'
  Invoke-WebRequest -Uri $repoZipUrl -OutFile $zipPath -UseBasicParsing
  Expand-Archive -LiteralPath $zipPath -DestinationPath (Join-Path $tempRoot 'unzipped') -Force
  $extracted = Get-ChildItem -LiteralPath (Join-Path $tempRoot 'unzipped') -Directory | Select-Object -First 1
  if (-not $extracted) { throw 'unexpected archive layout: no top-level directory found' }
  return $extracted.FullName
}

$src = Get-SourceRoot

$copied = 0
foreach ($rel in $manifest) {
  $from = Join-Path $src ($rel -replace '/', '\')
  $to = Join-Path $dest ($rel -replace '/', '\')
  if (-not (Test-Path -LiteralPath $from)) { throw "manifest item missing in source: $rel" }
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $to) | Out-Null
  try {
    Copy-Item -LiteralPath $from -Destination $to -Force
    $copied += 1
  } catch [UnauthorizedAccessException] {
    Write-Warning ("ACCESS_DENIED copying '{0}' - antivirus/HIPS protection is blocking writes to an existing file. Whitelist '{1}' (or the host process) in your security product, then rerun." -f $rel, $dest)
  } catch {
    Write-Warning "locked/copy failed (remount after deployment restart picks it up): $rel - $($_.Exception.Message)"
  }
}

Write-Output "copied: $copied/$($manifest.Count)"

$mismatch = @()
foreach ($rel in $manifest) {
  $from = Join-Path $src ($rel -replace '/', '\')
  $to = Join-Path $dest ($rel -replace '/', '\')
  if (-not (Test-Path -LiteralPath $to)) { $mismatch += $rel; continue }
  # A locked/unreadable destination must count as stale, not crash the check.
  $srcHash = Get-FileHash -LiteralPath $from -Algorithm SHA256 -ErrorAction SilentlyContinue
  if (-not $srcHash) { throw "cannot read source file for verification: $from" }
  $dstHash = Get-FileHash -LiteralPath $to -Algorithm SHA256 -ErrorAction SilentlyContinue
  if ((-not $dstHash) -or ($srcHash.Hash -ne $dstHash.Hash)) {
    $mismatch += $rel
  }
}

if ($script:tempRoot) {
  Remove-Item -LiteralPath $script:tempRoot -Recurse -Force -ErrorAction SilentlyContinue
}

if ($mismatch.Count -eq 0) {
  Write-Output ('INSTALL OK - select "{0}" in the DSH workspace preset selector (restart dsh web if it was running)' -f $PresetName)
  exit 0
} else {
  Write-Output ("STALE (locked this run - whitelist the destination for antivirus/HIPS, restart the deployment, rerun this script): " + ($mismatch -join ', '))
  exit 2
}
