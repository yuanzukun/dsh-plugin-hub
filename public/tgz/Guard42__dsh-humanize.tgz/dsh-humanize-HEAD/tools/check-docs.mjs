/**
 * Release-documentation referee: asserts that both READMEs carry every element
 * the project promises (attribution links, one-line install URL, tool surface,
 * customization story) and that LICENSE / CHANGELOG are intact.
 * Zero dependencies. Exit 0 = DOCS OK; exit 1 lists everything missing.
 */
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const read = (rel) => {
  try { return readFileSync(join(root, rel), 'utf8') } catch { return '' }
}

const zh = read('README.md')
const en = read('README.en.md')
const lic = read('LICENSE')
const log = read('CHANGELOG.md')

const HUMANFIA_LINKS = [
  'https://github.com/humanfia',
  'https://github.com/humanfia/humanize2',
  'https://github.com/humanfia/oh-my-humanize',
  'https://github.com/humanfia/humanize-plugin',
]
const TOOLS = [
  'flow_draft', 'flow_check', 'flow_lock', 'flow_list', 'flow_show',
  'flow_review_prepare', 'flow_review_decide', 'flow_run', 'flow_status',
  'flow_resume', 'flow_stop', 'trace_export', 'edit_anchored', 'hash_file',
  'model_catalog',
]

/** Per-README requirements. `any` = at least one of the alternatives must appear. */
const readmeRules = [
  { label: 'humanfia org link', any: ['https://github.com/humanfia'] },
  { label: 'humanize2 link', any: ['https://github.com/humanfia/humanize2'] },
  { label: 'oh-my-humanize link', any: ['https://github.com/humanfia/oh-my-humanize'] },
  { label: 'humanize-plugin link', any: ['https://github.com/humanfia/humanize-plugin'] },
  { label: 'DeepSeek Harness upstream link', any: ['https://github.com/deepseek-ai/deepseek-harness'] },
  { label: 'awesome-dsh-plugin link', any: ['https://github.com/awesome-dsh-plugin/awesome-dsh-plugin'] },
  { label: 'one-line install.ps1 URL', any: ['raw.githubusercontent.com/Guard42/dsh-humanize/main/tools/install.ps1'] },
  { label: 'agent-presets install path', any: ['.agent-presets'] },
  { label: "motto 'We build the flow around the agent'", any: ['We build the flow around the agent'] },
  { label: 'variant example name humanize-ZZZZ', any: ['humanize-ZZZZ'] },
  { label: 'PresetName installer flag', any: ['-PresetName', 'PRESET_NAME'] },
  { label: 'parity audit link', any: ['docs/parity.md'] },
  { label: 'plugin one-liner install command', any: ['dsh plugin --profile'] },
  { label: 'bundle installer precedent credit', any: ['Vibe-Mathematics'] },
  { label: 'star history chart', any: ['star-history.com'] },
  ...TOOLS.map((tool) => ({ label: `tool ${tool}`, any: [tool] })),
]

const problems = []

for (const [name, text] of [['README.md (zh)', zh], ['README.en.md (en)', en]]) {
  if (!text) { problems.push(`${name}: FILE MISSING OR EMPTY`); continue }
  for (const rule of readmeRules) {
    if (!rule.any.some((needle) => text.includes(needle))) {
      problems.push(`${name}: missing ${rule.label}`)
    }
  }
}

// Language-specific section headings.
if (!zh.includes('# 致谢与灵感来源')) problems.push('README.md: missing 「致谢与灵感来源」 heading')
if (!zh.includes('## 定制与领域特化')) problems.push('README.md: missing 「定制与领域特化」 heading')
if (!en.includes('Customize')) problems.push('README.en.md: missing Customize section')

// The exact user-facing variant request pattern must survive verbatim in zh.
if (!zh.includes('帮我往humanize模式中加入几种XXXX工具，以加强其在YYYY领域的能力，并且成为一个新的agent preset保存下来，命名为humanize-ZZZZ')) {
  problems.push('README.md: missing verbatim variant-request example sentence (XXXX/YYYY/humanize-ZZZZ)')
}

// Tool-count claim must say 15 (the registry has exactly 15 registrations).
for (const [name, text] of [['README.md', zh], ['README.en.md', en]]) {
  if (!/\b15\b/.test(text)) problems.push(`${name}: tool count "15" not stated`)
}

// LICENSE + CHANGELOG.
if (!lic.includes('MIT License')) problems.push('LICENSE: missing "MIT License"')
if (!lic.includes('Copyright (c) 2026 Guard42 and dsh-humanize contributors')) {
  problems.push('LICENSE: missing copyright line')
}
if (!log.includes('0.1.0')) problems.push('CHANGELOG.md: missing 0.1.0 entry')

if (problems.length > 0) {
  console.error(`DOCS PROBLEMS (${problems.length}):`)
  for (const problem of problems) console.error(` - ${problem}`)
  process.exit(1)
}
console.log('DOCS OK — attribution, install, tools, customization and license all present.')
