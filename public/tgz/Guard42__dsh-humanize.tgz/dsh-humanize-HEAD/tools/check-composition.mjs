/**
 * Validate agent.cordis.yml: YAML parses, rows carry id/name, group rows
 * declare their realm, relative plugin paths exist on disk.
 *
 * The `yaml` parser is resolved dynamically — zero npm hard dependency:
 *   1. $DSH_YAML_DIR        directory to resolve 'yaml' from (CI / custom setups)
 *   2. process.cwd() walk-up nearest ancestor node_modules via createRequire
 *   3. Hardcoded fallback   maintainer's local DSH checkout (local dev only)
 * If all three fail: clear error message and exit code 1.
 */
import { readFileSync, existsSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

// Local dev machine only — never relied on outside this workstation.
const FALLBACK_REQUIRE_BASE = 'F:/4-Programmes/GithubCloneForked/deepseek-harness/package.json'

function loadParse() {
  const attempts = []

  // 1. $DSH_YAML_DIR: point at a checkout root or any dir containing the package.
  const envDir = process.env.DSH_YAML_DIR
  if (envDir) {
    attempts.push(join(resolve(envDir), 'package.json'))
    attempts.push(join(resolve(envDir), 'node_modules', 'yaml', 'package.json'))
  }

  // 2. Walk up from process.cwd() through every ancestor.
  let dir = resolve(process.cwd())
  for (;;) {
    attempts.push(join(dir, 'package.json'))
    const parent = dirname(dir)
    if (parent === dir) break
    dir = parent
  }

  // 3. Hardcoded fallback (local development only).
  attempts.push(FALLBACK_REQUIRE_BASE)

  for (const base of attempts) {
    try {
      return createRequire(base)('yaml').parse
    } catch {
      // try next anchor
    }
  }

  console.error(
    'check-composition: cannot resolve the `yaml` package.\n' +
    'Tried, in order:\n' +
    (envDir ? `  1. $DSH_YAML_DIR = ${envDir}\n` : '  1. $DSH_YAML_DIR (not set)\n') +
    '  2. node_modules chain walking up from process.cwd()\n' +
    `  3. hardcoded fallback ${FALLBACK_REQUIRE_BASE} (local dev machine only)\n` +
    'Fix: install `yaml` somewhere on that chain, or set DSH_YAML_DIR to a\n' +
    'directory that contains it.'
  )
  process.exit(1)
}

const parse = loadParse()

const compositionPath = fileURLToPath(new URL('../agent.cordis.yml', import.meta.url))
const presetDir = dirname(compositionPath)
const text = readFileSync(compositionPath, 'utf8')
const rows = parse(text)

if (!Array.isArray(rows)) throw new Error('composition root must be a row array')

const ids = new Set()
const problems = []
const walk = (rowList, inGroup) => {
  for (const row of rowList) {
    if (!row || typeof row !== 'object') {
      problems.push('non-object row encountered')
      continue
    }
    if (typeof row.id !== 'string' || row.id.length === 0) problems.push(`row without id: ${JSON.stringify(row).slice(0, 80)}`)
    else if (ids.has(row.id)) problems.push(`duplicate row id: ${row.id}`)
    else ids.add(row.id)
    if (typeof row.name !== 'string') problems.push(`row ${row.id}: missing name`)
    if (typeof row.disabled === 'boolean') {
      // fine — platform-conditional or opt-out rows
    } else if (row.disabled !== undefined && typeof row.disabled !== 'object' && typeof row.disabled !== 'string') {
      // `!!js` expressions parse into tagged objects (or raw strings under a
      // plain schema) here and evaluate at load time; anything else is suspect.
      problems.push(`row ${row.id}: disabled must be boolean or a !!js expression`)
    }
    if (row.group === true) {
      if (!inGroup && !row.isolate) problems.push(`group ${row.id}: no isolate realm declared`)
      walk(Array.isArray(row.config) ? row.config : [], true)
      continue
    }
    if (typeof row.name === 'string' && row.name.startsWith('./')) {
      const modulePath = join(presetDir, row.name)
      if (!existsSync(modulePath)) problems.push(`row ${row.id}: local module missing: ${modulePath}`)
    }
    if (row.config !== undefined && typeof row.config !== 'object' && !Array.isArray(row.config)) {
      problems.push(`row ${row.id}: config must be a mapping`)
    }
  }
}
walk(rows, false)

if (problems.length > 0) {
  console.error('COMPOSITION PROBLEMS:')
  for (const problem of problems) console.error(` - ${problem}`)
  process.exit(1)
}
console.log(`composition OK — ${ids.size} rows parsed, all local modules present`)
