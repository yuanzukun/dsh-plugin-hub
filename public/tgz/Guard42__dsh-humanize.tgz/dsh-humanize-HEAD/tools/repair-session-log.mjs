#!/usr/bin/env node
/**
 * Repair session logs written by dsh-humanize <= 0.1.0.
 *
 * Those versions appended custom events (`humanize/review-prepared`,
 * `humanize/review-decided`) into the session log via agent.session.append.
 * The stock harness persistence layer refuses to interpret a log containing
 * an event type outside its catalog unless the envelope carries
 * `ignorable: true` — a marker the public append API cannot express — so any
 * session in which a review ran fails history load and resume with
 * SessionFormatUnsupportedError.
 *
 * This tool rewrites affected logs IN PLACE (after making a `.bak` copy),
 * adding `"ignorable": true` to every unknown-type event envelope. Container,
 * framing, record order and all other bytes are preserved: clean zstd frames
 * are copied verbatim, only frames that contain an unknown unmarked event are
 * recompressed, and a torn final frame is left byte-identical.
 *
 * Zero npm dependencies: node: builtins plus the KNOWN event catalog read
 * from the local DSH deployment (override with --catalog <file>).
 *
 * Usage:
 *   node repair-session-log.mjs <session.jsonl[.zstd] | sessions-root> [options]
 *
 * Options:
 *   --apply            write changes (default: dry run, report only)
 *   --no-backup        with --apply: skip the .bak copy (not recommended)
 *   --scan             treat argument as a root and walk it for session logs
 *   --catalog <file>   path to known-event-types.js (default: autodetect)
 *
 * Exit codes: 0 = nothing to do or all repairs verified; 1 = usage/IO error;
 * 2 = post-write verification failed (restore the .bak).
 * @module humanize/tools/repair-session-log
 */
import { copyFileSync, existsSync, readFileSync, readdirSync, renameSync, statSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { promisify } from 'node:util'
import { constants, zstdCompress as zstdCompressCb, zstdDecompressSync } from 'node:zlib'

const zstdCompress = promisify(zstdCompressCb)

/** Frame magic of the zstd container (`0x28 B5 2F FD`, little-endian u32). */
const ZSTD_MAGIC = 4247762216
const COMPRESSION_OPTIONS = { params: { [constants.ZSTD_c_checksumFlag]: 1 } }

// ── zstd frame scanner (mirrors scanZstdFrames of dsh-session-persistence-jsonl) ──

/**
 * Locate complete frames without decompressing their blocks.
 * @returns {{frames: Array<{start:number,end:number}>, tornStart?: number}}
 */
function scanZstdFrames(buffer) {
  const frames = []
  let offset = 0
  while (offset < buffer.length) {
    const start = offset
    if (buffer.length - offset < 4) return { frames, tornStart: start }
    if (buffer.readUInt32LE(offset) !== ZSTD_MAGIC) {
      throw new Error(`invalid frame magic at byte ${offset} — not a DSH session log?`)
    }
    offset += 4
    if (offset === buffer.length) return { frames, tornStart: start }
    const descriptor = buffer.readUInt8(offset)
    offset += 1
    if ((descriptor & 24) !== 0) {
      throw new Error(`reserved frame-header bit at byte ${offset - 1}`)
    }
    const contentSizeFlag = descriptor >>> 6
    const singleSegment = (descriptor & 32) !== 0
    const checksum = (descriptor & 4) !== 0
    const dictionaryBytes = (descriptor & 3) === 3 ? 4 : descriptor & 3
    const contentSizeBytes = contentSizeFlag === 0 ? (singleSegment ? 1 : 0) : 1 << contentSizeFlag
    const remainingHeaderBytes = (singleSegment ? 0 : 1) + dictionaryBytes + contentSizeBytes
    if (buffer.length - offset < remainingHeaderBytes) return { frames, tornStart: start }
    offset += remainingHeaderBytes
    for (;;) {
      if (buffer.length - offset < 3) return { frames, tornStart: start }
      const blockHeader = buffer.readUIntLE(offset, 3)
      offset += 3
      const lastBlock = (blockHeader & 1) !== 0
      const blockType = (blockHeader >>> 1) & 3
      const blockSize = blockHeader >>> 3
      if (blockType === 3) throw new Error(`reserved block type at byte ${offset - 3}`)
      const payloadBytes = blockType === 1 ? 1 : blockSize
      if (buffer.length - offset < payloadBytes) return { frames, tornStart: start }
      offset += payloadBytes
      if (lastBlock) break
    }
    if (checksum) {
      if (buffer.length - offset < 4) return { frames, tornStart: start }
      offset += 4
    }
    frames.push({ start, end: offset })
  }
  return { frames }
}

// ── known event catalog ──

function defaultCatalogCandidates() {
  const home = homedir()
  const scope = join(home, '.agents', 'node_modules', '@deepseek-ai', 'dsh-session', 'lib', 'types', 'known-event-types.js')
  const desktop = [
    join(home, 'AppData', 'Local', 'Programs', 'dsh', 'resources', 'app.asar.unpacked'),
    'F:\\4-Programmes\\DSH Desktop\\resources\\app.asar.unpacked',
    'C:\\Program Files\\DSH\\resources\\app.asar.unpacked',
  ]
  return [scope, ...desktop.map((root) => join(root, 'node_modules', '@deepseek-ai', 'dsh-session', 'lib', 'types', 'known-event-types.js'))]
}

async function loadKnownTypes(explicit) {
  const candidates = explicit ? [explicit] : defaultCatalogCandidates()
  for (const candidate of candidates) {
    if (!existsSync(candidate)) continue
    const mod = await import(pathToFileURL(candidate).href)
    if (mod.KNOWN_SESSION_EVENT_TYPES instanceof Set) {
      return { set: mod.KNOWN_SESSION_EVENT_TYPES, source: candidate }
    }
  }
  throw new Error('known-event-types.js not found; pass --catalog <path>')
}

// ── record rewriting ──

/**
 * Rewrite one frame plaintext. Returns { text, changed, marks } where `marks`
 * lists the events that gained the ignorable marker.
 */
function rewritePlaintext(text, known) {
  const lines = text.split('\n')
  const marks = []
  let changed = false
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    if (!line.includes('"type"')) continue
    let row
    try {
      row = JSON.parse(line)
    } catch {
      continue // not JSON — leave byte-identical
    }
    if (refuses(row, known)) {
      marks.push({ type: row.type, seq: row.seq })
      lines[i] = JSON.stringify({ ...row, ignorable: true })
      changed = true
    }
  }
  return { text: lines.join('\n'), changed, marks }
}

/**
 * The exact predicate behind SessionFormatUnsupportedError, replicated from
 * the harness read path: storage chunk rows are decoded and expanded BEFORE
 * event validation, so they never reach the type check; the header row is not
 * an event; every other envelope passes when its type is in the catalog or it
 * carries `ignorable: true`.
 */
const STORAGE_ROW_TAGS = new Set(['text-chunks', 'reasoning-chunks', 'tool-call-chunks'])

function isHeaderRow(row) {
  return row !== null && typeof row === 'object' && row.type === 'session' && typeof row.id === 'string'
}

function refuses(row, known) {
  return row !== null && typeof row === 'object' && !Array.isArray(row)
    && typeof row.type === 'string' && !isHeaderRow(row) && !STORAGE_ROW_TAGS.has(row.type)
    && typeof row.type === 'string' && !STORAGE_ROW_TAGS.has(row.type)
    && row.ignorable !== true
    && !known.has(row.type)
}
/** Repair one log file. Returns a report object; writes only when apply. */
async function repairFile(file, { known, apply, backup }) {
  const isZstd = file.endsWith('.zstd')
  const raw = readFileSync(file)

  /** @type {Array<{start:number,end:number,text?:Buffer,marks:Array,type:string}>} */
  let pieces = []
  let tail // Buffer of bytes after the last complete frame (torn region), or undefined

  if (isZstd) {
    const { frames, tornStart } = scanZstdFrames(raw)
    if (tornStart !== undefined) tail = raw.subarray(tornStart)
    for (const frame of frames) {
      const plain = zstdDecompressSync(raw.subarray(frame.start, frame.end)).toString('utf8')
      const rewritten = rewritePlaintext(plain, known)
      if (rewritten.changed) {
        const encoded = await zstdCompress(Buffer.from(rewritten.text, 'utf8'), COMPRESSION_OPTIONS)
        pieces.push({ start: frame.start, end: frame.end, text: encoded, marks: rewritten.marks })
      } else {
        pieces.push({ start: frame.start, end: frame.end, text: undefined, marks: [] })
      }
    }
  } else {
    const plain = raw.toString('utf8')
    const rewritten = rewritePlaintext(plain, known)
    pieces = [{ start: 0, end: raw.length, text: rewritten.changed ? Buffer.from(rewritten.text, 'utf8') : undefined, marks: rewritten.marks }]
  }

  const marks = pieces.flatMap((p) => p.marks)
  const touchedFrames = pieces.filter((p) => p.text !== undefined).length
  const report = { file, totalMarks: marks.length, byType: {}, touchedFrames, applied: false, backupPath: undefined }

  if (marks.length > 0) {
    const counts = {}
    for (const mark of marks) counts[mark.type] = (counts[mark.type] ?? 0) + 1
    report.byType = counts
  }

  if (marks.length === 0 || !apply) return report

  // Assemble output: verbatim clean frames + recompressed dirty frames + torn tail.
  const parts = []
  for (const piece of pieces) {
    // Dirty frames contribute their recompressed bytes; clean frames are
    // copied verbatim from the original. Frames tile the input exactly, so
    // every byte of every complete frame is emitted exactly once.
    parts.push(piece.text !== undefined ? piece.text : raw.subarray(piece.start, piece.end))
  }
  const output = Buffer.concat(tail !== undefined ? [...parts, tail] : parts)

  // Self-verify BEFORE touching disk: rescan candidate, assert every row passes.
  verifyBuffer(isZstd ? output : output.toString('utf8'), isZstd, known, file)

  if (backup) {
    report.backupPath = `${file}.bak`
    copyFileSync(file, report.backupPath)
  }
  const tmp = `${file}.repair-tmp`
  writeFileSync(tmp, output)
  renameSync(tmp, file)
  report.applied = true
  return report
}

/** Assert the refusal predicate holds for every row of a (candidate) log. */
function verifyBuffer(buffer, isZstd, known, label) {
  let texts = []
  if (isZstd) {
    const { frames } = scanZstdFrames(buffer)
    texts = frames.map((f) => zstdDecompressSync(buffer.subarray(f.start, f.end)).toString('utf8'))
  } else {
    texts = [buffer.toString('utf8')]
  }
  let bad = 0
  for (const text of texts) {
    for (const line of text.split('\n')) {
      if (!line || !line.includes('"type"')) continue
      let row
      try { row = JSON.parse(line) } catch { continue }
      if (refuses(row, known)) bad += 1
    }
  }
  if (bad > 0) throw new Error(`verification failed for ${label}: ${bad} row(s) still refuse`)
}

/** Walk a root collecting session.jsonl[.zstd] paths. */
function collectLogs(root) {
  const out = []
  const visit = (dir) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const full = join(dir, entry.name)
      if (entry.isDirectory()) visit(full)
      else if (entry.name === 'session.jsonl' || entry.name === 'session.jsonl.zstd') out.push(full)
    }
  }
  visit(root)
  return out
}

async function main() {
  const argv = process.argv.slice(2)
  const flags = new Set(argv.filter((a) => a.startsWith('--')))
  const rest = argv.filter((a) => !a.startsWith('--'))
  const catalogIndex = argv.indexOf('--catalog')
  const catalog = catalogIndex >= 0 ? argv[catalogIndex + 1] : undefined
  const target = rest[0]

  if (!target || flags.has('--help')) {
    console.error('usage: node repair-session-log.mjs <session.jsonl[.zstd] | sessions-root> [--apply] [--no-backup] [--scan] [--catalog <file>]')
    process.exit(1)
  }
  const apply = flags.has('--apply')
  const backup = !flags.has('--no-backup')

  const { set: known, source } = await loadKnownTypes(catalog)
  console.log(`known-event catalog: ${known.size} types (${source})`)

  const files = flags.has('--scan') ? collectLogs(target) : [target]
  let affected = 0
  let failures = 0
  for (const file of files) {
    if (!existsSync(file)) {
      console.error(`skip (missing): ${file}`)
      failures += 1
      continue
    }
    try {
      const report = await repairFile(file, { known, apply, backup })
      const sizeMb = (statSync(file).size / 1048576).toFixed(2)
      if (report.totalMarks === 0) {
        console.log(`clean  ${file} (${sizeMb} MB)`)
      } else {
        affected += 1
        const detail = Object.entries(report.byType).map(([type, count]) => `${type}×${count}`).join(', ')
        const verb = report.applied ? 'FIXED ' : 'WOULD-FIX'
        const extra = report.applied ? (report.backupPath ? ` backup: ${report.backupPath}` : '') : ''
        console.log(`${verb}  ${file} (${sizeMb} MB) — ${detail}${extra}`)
      }
    } catch (error) {
      failures += 1
      console.error(`ERROR ${file}: ${error.message}`)
    }
  }
  console.log(apply ? `${affected} log(s) repaired.` : `${affected} log(s) would be repaired; rerun with --apply to write.`)
  process.exit(failures > 0 ? 1 : 0)
}

main().catch((error) => {
  console.error(error)
  process.exit(1)
})
