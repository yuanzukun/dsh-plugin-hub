/**
 * Humanize store — the preset-owned persistence service behind the flow
 * runtime, registered behind the composition's isolate realm so every mounting
 * session gets its own instance.
 *
 * Layout (under the resolved state root):
 *   flows/<slug>.draft.json            mutable authoring input
 *   flows/<slug>.<digest8>.lock.json   immutable FlowLock packages
 *   runs/<runId>/run.json              run header (lock id, review binding)
 *   runs/<runId>/events.jsonl          THE authority: append-only event log
 *   runs/<runId>/artifacts/<key>.txt   produced artifact payloads
 *   reviews/frv_<rand>/prepared.json   HMAC-signed review binding
 *   reviews/frv_<rand>/decision.json   one-shot terminal decision
 *   review-mac.key                     installation-level HMAC key
 *
 * Mirrors humanize-plugin's discipline: events are the replay authority,
 * snapshots are caches, and review records authenticate themselves with an
 * installation key so forged or corrupted bindings fail loud instead of
 * authorizing a run.
 * @module humanize/humanize-store
 */

import {
  mkdirSync, readFileSync, writeFileSync, appendFileSync, existsSync, readdirSync, renameSync,
} from 'node:fs'
import { createHmac, randomBytes } from 'node:crypto'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { stableStringify, identityOf, shortDigest, parseModelRef } from './flow-kernel.mjs'

/** Config gate: keep '' (inherit) and any well-formed reference. */
function parseModelRefSafe(ref) {
  const trimmed = typeof ref === 'string' ? ref.trim() : ''
  return trimmed.length === 0 || parseModelRef(trimmed) !== undefined
}

/** The directory holding this preset's plugins; the config file lives one level up. */
const PRESET_DIR = resolve(dirname(fileURLToPath(import.meta.url)), '..')

const DEFAULTS = Object.freeze({
  /** Where `.humanize/` lives per workspace, or a shared home-level root. */
  stateRootMode: 'workspace',
  /** Subagent provider used when a node does not name one. */
  defaultExecutor: 'spawn',
  /** Model reference ("provider/model" or "model") for agent nodes; '' inherits the session model. */
  nodeModelDefault: '',
  /** Concurrent node activations per run. */
  maxParallel: 2,
  /** Referee command budget when a verify entry does not set one. */
  verifyTimeoutMs: 600000,
})

export const name = 'humanize-store'

/** Also exported for direct testing outside a Cordis context. */
export { createStore }

export function apply(ctx) {
  const config = loadConfig()
  const dispose = ctx.provide('humanizeStore', createStore(config))
  if (dispose) ctx.effect(() => dispose, 'humanize-store')
}

/** Read `<preset>/humanize.config.json`, tolerating absence and bad JSON. */
function loadConfig() {
  const merged = { ...DEFAULTS }
  try {
    const raw = JSON.parse(readFileSync(join(PRESET_DIR, 'humanize.config.json'), 'utf8'))
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
      if (raw.stateRootMode === 'workspace' || raw.stateRootMode === 'home') merged.stateRootMode = raw.stateRootMode
      if (raw.defaultExecutor === 'spawn' || raw.defaultExecutor === 'fork') merged.defaultExecutor = raw.defaultExecutor
      if (typeof raw.nodeModelDefault === 'string' && parseModelRefSafe(raw.nodeModelDefault)) {
        merged.nodeModelDefault = raw.nodeModelDefault.trim()
      }
      if (Number.isSafeInteger(raw.maxParallel) && raw.maxParallel >= 1 && raw.maxParallel <= 16) merged.maxParallel = raw.maxParallel
      if (Number.isSafeInteger(raw.verifyTimeoutMs) && raw.verifyTimeoutMs > 0) merged.verifyTimeoutMs = raw.verifyTimeoutMs
    }
  } catch {
    // Absent or unreadable config keeps the documented defaults.
  }
  return merged
}

/**
 * Build the store. Every method takes the state root as its first argument:
 * the root depends on the CALLING SESSION's working directory, so it can never
 * be baked into one process-global instance.
 */
function createStore(config) {
  const store = {
    config,

    /** Absolute state root for a session working directory. */
    rootFor(cwd) {
      if (config.stateRootMode === 'home') return join(homedir(), '.dsh', 'humanize')
      return join(cwd || process.cwd(), '.humanize')
    },

    ensureRoot(root) {
      for (const part of ['', 'flows', 'runs', 'reviews']) {
        mkdirSync(join(root, part), { recursive: true })
      }
    },

    // ── drafts ────────────────────────────────────────────────────────────

    draftPath: (root, slug) => join(root, 'flows', `${slug}.draft.json`),
    writeDraft(root, doc) {
      store.ensureRoot(root)
      atomicWrite(store.draftPath(root, doc.name), stableStringify(doc))
    },
    readDraft(root, slug) {
      return readJsonIfPresent(store.draftPath(root, slug))
    },
    listDrafts(root) {
      return listJson(join(root, 'flows')).filter(entry => entry.name.endsWith('.draft.json'))
    },

    // ── locks ─────────────────────────────────────────────────────────────

    lockPath: (root, lockId) => join(root, 'flows', `${lockId}.lock.json`),
    writeLock(root, canonical) {
      store.ensureRoot(root)
      const { contentHash, lockId } = identityOf(canonical)
      const lockDoc = { lockId, contentHash, flow: canonical }
      atomicWrite(store.lockPath(root, lockId), stableStringify(lockDoc))
      return { lockDoc, lockId, contentHash }
    },
    readLock(root, lockId) {
      return readJsonIfPresent(store.lockPath(root, lockId))
    },
    listLocks(root) {
      return listJson(join(root, 'flows')).filter(entry => entry.name.endsWith('.lock.json'))
    },

    // ── runs ──────────────────────────────────────────────────────────────

    runDir: (root, runId) => join(root, 'runs', runId),
    newRunId() {
      const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..+$/, '').replace('T', '_')
      return `run_${stamp}_${randomBytes(2).toString('hex')}`
    },
    createRun(root, runId, meta) {
      mkdirSync(join(store.runDir(root, runId), 'artifacts'), { recursive: true })
      atomicWrite(join(store.runDir(root, runId), 'run.json'), stableStringify(meta))
    },
    readRunHeader(root, runId) {
      return readJsonIfPresent(join(store.runDir(root, runId), 'run.json'))
    },
    listRuns(root) {
      const dir = join(root, 'runs')
      if (!existsSync(dir)) return []
      try {
        return readdirSync(dir, { withFileTypes: true })
          .filter(entry => entry.isDirectory())
          .map(entry => entry.name)
      } catch {
        return []
      }
    },

    /**
     * Append one authoritative event. Sequence numbers are assigned here so
     * concurrent writers cannot interleave identities; appends go straight to
     * events.jsonl and nothing else is trusted for replay.
     */
    appendEvent(root, runId, event) {
      const dir = store.runDir(root, runId)
      mkdirSync(dir, { recursive: true })
      let seq = 0
      try {
        const existing = readFileSync(join(dir, 'events.jsonl'), 'utf8').trimEnd()
        if (existing.length > 0) {
          const lastLine = existing.slice(existing.lastIndexOf('\n') + 1)
          seq = (JSON.parse(lastLine).seq ?? 0) + 1
        }
      } catch {
        // First event of the run.
      }
      const record = { seq, ts: Date.now(), ...event }
      appendFileSync(join(dir, 'events.jsonl'), JSON.stringify(record) + '\n', 'utf8')
      return record
    },
    readEvents(root, runId) {
      try {
        return readFileSync(join(store.runDir(root, runId), 'events.jsonl'), 'utf8')
          .split('\n')
          .filter(line => line.trim().length > 0)
          .map(line => JSON.parse(line))
      } catch {
        return []
      }
    },

    artifactPath(root, runId, key) {
      return join(root, 'runs', runId, 'artifacts', `${shortDigest(key, 12)}_${safeName(key)}.txt`)
    },
    saveArtifact(root, runId, key, text) {
      const path = store.artifactPath(root, runId, key)
      mkdirSync(dirname(path), { recursive: true })
      atomicWrite(path, String(text ?? ''))
      return path
    },
    readArtifactText(path) {
      try {
        return readFileSync(path, 'utf8')
      } catch {
        return ''
      }
    },

    // ── reviews ───────────────────────────────────────────────────────────

    reviewDir: (root, reviewId) => join(root, 'reviews', reviewId),

    /**
     * Prepare one review binding for a lock: the canonical package plus the
     * binding metadata, serialized canonically and authenticated with the
     * installation HMAC key. Terminal decisions live in a separate file the
     * runtime trusts independently of any projection.
     */
    prepareReview(root, lockDoc) {
      store.ensureRoot(root)
      const reviewId = `frv_${randomBytes(6).toString('hex')}`
      const dir = store.reviewDir(root, reviewId)
      mkdirSync(dir, { recursive: true })
      const payload = {
        reviewId,
        createdAt: Date.now(),
        lockId: lockDoc.lockId,
        contentHash: lockDoc.contentHash,
        flowName: lockDoc.flow?.name,
      }
      const bytes = stableStringify(payload)
      atomicWrite(join(dir, 'prepared.json'), stableStringify({ payload, mac: macFor(root, bytes) }))
      return { reviewId, dir, payload }
    },

    /**
     * Write the terminal decision once. A second call — including a different
     * decision — is refused: terminal states are immutable, and reject/bypass
     * require a reason (humanize-plugin's single-decision-tool rule).
     */
    decideReview(root, reviewId, decision, reason) {
      const decisionPath = join(store.reviewDir(root, reviewId), 'decision.json')
      const existing = readJsonIfPresent(decisionPath)
      if (existing) {
        throw new Error(`review ${reviewId} already decided (${existing.payload.decision}); decisions are immutable`)
      }
      if (!['approved', 'rejected', 'bypassed'].includes(decision)) {
        throw new Error(`invalid decision "${decision}"`)
      }
      if (decision !== 'approved' && !(typeof reason === 'string' && reason.trim().length > 0)) {
        throw new Error(`"${decision}" requires a non-empty reason`)
      }
      const payload = { reviewId, decidedAt: Date.now(), decision, reason: typeof reason === 'string' ? reason : '' }
      const bytes = stableStringify(payload)
      atomicWrite(decisionPath, stableStringify({ payload, mac: macFor(root, bytes) }))
      return payload
    },

    /**
     * Read back a review binding for run authorization. Returns undefined when
     * absent; THROWS on forgery or corruption (bad MAC) or when the binding's
     * content hash does not match the presented lock. Only approved/bypassed
     * authorize a run; pending/rejected do not.
     */
    readReviewBinding(root, reviewId, expectedContentHash) {
      const prepared = readJsonIfPresent(join(store.reviewDir(root, reviewId), 'prepared.json'))
      if (!prepared) return undefined
      if (macFor(root, stableStringify(prepared.payload)) !== prepared.mac) {
        throw new Error(`review ${reviewId}: MAC mismatch (corrupted or forged binding)`)
      }
      if (prepared.payload.contentHash !== expectedContentHash) {
        throw new Error(`review ${reviewId} binds ${prepared.payload.contentHash}, not ${expectedContentHash}`)
      }
      const decided = readJsonIfPresent(join(store.reviewDir(root, reviewId), 'decision.json'))
      let decision = 'pending'
      if (decided) {
        if (macFor(root, stableStringify(decided.payload)) !== decided.mac) {
          throw new Error(`review ${reviewId}: decision MAC mismatch`)
        }
        decision = decided.payload.decision
      }
      return { reviewId, decision, flowName: prepared.payload.flowName, reason: decided?.payload.reason ?? '' }
    },

    listReviews(root) {
      const dir = join(root, 'reviews')
      if (!existsSync(dir)) return []
      try {
        return readdirSync(dir, { withFileTypes: true })
          .filter(entry => entry.isDirectory())
          .map(entry => entry.name)
      } catch {
        return []
      }
    },
  }
  return store

  /** Installation-level HMAC over canonical bytes; the key lives at `<root>/review-mac.key`. */
  function macFor(rootValue, bytes) {
    const keyPath = join(rootValue, 'review-mac.key')
    let key
    try {
      key = readFileSync(keyPath, 'utf8').trim()
      if (key.length < 32) throw new Error('short key')
    } catch {
      key = randomBytes(32).toString('hex')
      writeFileSync(keyPath, key + '\n', { encoding: 'utf8', mode: 0o600 })
    }
    return createHmac('sha256', key).update(bytes).digest('hex')
  }
}

function safeName(key) {
  return key.replace(/[^a-z0-9._-]/gi, '_').slice(0, 64)
}

function readJsonIfPresent(path) {
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch (error) {
    if (error?.code === 'ENOENT') return undefined
    throw error
  }
}

function listJson(dir) {
  if (!existsSync(dir)) return []
  try {
    return readdirSync(dir, { withFileTypes: true })
      .filter(entry => entry.isFile())
      .map(entry => ({ name: entry.name, path: join(dir, entry.name) }))
  } catch {
    return []
  }
}

/** Best-effort atomic write: temp file beside the target, then rename. */
function atomicWrite(path, text) {
  mkdirSync(dirname(path), { recursive: true })
  const temp = `${path}.${process.pid}.${randomBytes(3).toString('hex')}.tmp`
  writeFileSync(temp, text, 'utf8')
  try {
    renameSync(temp, path)
  } catch {
    // Same-directory rename can fail across odd filesystems; fall back in place.
    writeFileSync(path, text, 'utf8')
  }
}
