/**
 * Humanize tools — the model-facing surface of the flow runtime plus the
 * scheduler that executes locked flows.
 *
 * Tools registered here: flow_draft, flow_check, flow_lock, flow_list,
 * flow_show, flow_review_prepare, flow_review_decide, flow_run, flow_status,
 * flow_resume, flow_stop, trace_export, edit_anchored, hash_file.
 *
 * Runtime discipline ported from humanfia/humanize-plugin: append-only events
 * are the replay authority; a run's progress is always reconstructible from
 * events.jsonl, so a loop that stopped on Thursday carries on via flow_resume.
 * Node work runs on the subagents registry (spawn/fork providers); referee
 * commands run through the shell service so the sandbox and approval stack
 * stays exactly as privileged as the rest of the session.
 * @module humanize/tool-flow
 */

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import {
  checkFlow, canonicalizeFlow, evalPredicate, lockTamperReason, parseModelRef,
  sha256Hex, stableStringify, SLUG_PATTERN,
} from './flow-kernel.mjs'

/** Upper bound on fanout activations per route expansion. */
const MAX_FANOUT = 64

/** Per-artifact character budget injected into node prompts. */
const ARTIFACT_CONTEXT_CHARS = 6000

/** Poll cadence of the scheduling loop while nodes are in flight. */
const SCHEDULE_TICK_MS = 300

/** Runs scheduled in this process, keyed `<root>|<runId>`. */
const activeRuns = new Map()

export const name = 'humanize-flow'
export const inject = ['humanizeStore', 'tools']

export function apply(ctx) {
  const store = ctx.humanizeStore

  // ── methodology section ─────────────────────────────────────────────────
  const systemPrompt = ctx.get('systemPrompt')
  if (systemPrompt !== undefined) {
    const disposeSection = systemPrompt.section({
      name: 'humanize:method',
      order: 120,
      text: [
        '# Humanize discipline — we build the flow around the agent',
        '',
        'For multi-stage objectives (more than two coupled steps, anything long-running,',
        'anything that must survive interruption) drive the work through a Humanize flow:',
        'flow_draft → flow_check → flow_lock → flow_review_prepare → present review.md to the',
        'user → flow_review_decide → flow_run → poll flow_status → trace_export.',
        'Every stage carries its referee: verify commands whose exit code decides acceptance.',
        '"The review is the next prompt": never run an unreviewed lock; fold rejection reasons',
        'back into the draft instead of arguing with them. Small single-step tasks need no flow.',
        'When a run stops mid-way (session end, crash, cancellation), resume it with flow_resume;',
        'events.jsonl is the authority and completed stages never rerun.',
      ].join('\n'),
    })
    if (disposeSection) ctx.effect(() => disposeSection, 'humanize-method-section')
  }

  // ── shared argument guards ──────────────────────────────────────────────
  const requireString = (args, key) => {
    const value = args?.[key]
    if (typeof value !== 'string' || value.length === 0) throw new Error(`\`${key}\` must be a non-empty string`)
    return value
  }
  const requireAgent = (exec) => {
    if (!exec?.agent) throw new Error('this tool requires an owning agent session')
    return exec.agent
  }
  const cwdOf = (agent) => agent.session?.header?.cwd || process.cwd()
  const rootOf = (agent) => store.rootFor(cwdOf(agent))
  const readJsonFile = (path) => {
    try {
      return JSON.parse(readFileSync(path, 'utf8'))
    } catch {
      return undefined
    }
  }
  const writeFileEnsured = (path, text) => {
    mkdirSync(dirname(path), { recursive: true })
    writeFileSync(path, text, 'utf8')
  }

  /** Resolve a lock id (`flk_…`) or draft slug to the latest verified lock. */
  const loadLock = (root, ref) => {
    let lockDoc
    if (ref.startsWith('flk_')) {
      lockDoc = store.readLock(root, ref)
      if (!lockDoc) throw new Error(`lock ${ref} not found under ${root}`)
    } else {
      const candidates = store.listLocks(root)
        .map(entry => ({ name: entry.name, doc: readJsonFile(entry.path) }))
        .filter(entry => entry.doc?.flow?.name === ref)
        .sort((left, right) => left.name < right.name ? 1 : -1)
      lockDoc = candidates[0]?.doc
      if (!lockDoc) throw new Error(`no lock found for flow "${ref}" — run flow_lock first`)
    }
    const tamper = lockTamperReason(lockDoc)
    if (tamper) throw new Error(`lock rejected: ${tamper}`)
    return lockDoc
  }

  // ════════════════════════════════════════════════════════════════════════
  // flow_draft — whole-document authoring input (replaces the draft)
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_draft',
    description: 'Write (whole-document replace) a Humanize FlowDraft: a stage graph where every node '
      + 'carries agent instructions plus referee commands whose exit code decides acceptance. Send the '
      + 'COMPLETE flow every call — there is no partial update. Follow with flow_check.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['name', 'nodes'],
      properties: {
        name: { type: 'string', description: 'Flow slug: lowercase letters/digits/dots/dashes.' },
        description: { type: 'string', description: 'Goal statement and success criteria.' },
        model: { type: 'string', description: 'Default model for agent nodes: "provider/model" or "model". Omit/"" to inherit the session model.' },
        board: { type: 'object', description: 'Initial facts for route predicates, e.g. {"goal":"..."}.' },
        nodes: {
          type: 'array', description: 'Stages. Each: id/title/prompt/executor(spawn|fork|gate)/produces/verify/maxActivations.',
          items: {
            type: 'object', additionalProperties: false, required: ['id', 'verify'],
            properties: {
              id: { type: 'string', description: 'Stage id (slug).' },
              title: { type: 'string' },
              prompt: { type: 'string', description: 'Complete instruction for the stage subagent (spawn/fork).' },
              executor: { type: 'string', enum: ['spawn', 'fork', 'gate'], description: 'gate = referee-only milestone.' },
              model: { type: 'string', description: 'Model override for this stage\'s subagent: "provider/model" or "model". Wins over the flow-level model.' },
              produces: { type: 'array', items: { type: 'string' }, description: 'Artifact keys written on success.' },
              verify: {
                type: 'array', description: 'Referee commands; ALL must exit 0.',
                items: {
                  type: 'object', additionalProperties: false, required: ['command'],
                  properties: { command: { type: 'string' }, timeoutMs: { type: 'integer' } },
                },
              },
              maxActivations: { type: 'integer', description: 'Loop budget; default 3.' },
            },
          },
        },
        routes: {
          type: 'array', description: 'Edges: from/to/kind(on_success|on_failure)/when({exists|truthy:key})/forEach(artifact key).',
          items: {
            type: 'object', additionalProperties: false, required: ['from', 'to'],
            properties: {
              from: { type: 'string' }, to: { type: 'string' },
              kind: { type: 'string', enum: ['on_success', 'on_failure'] },
              when: {
                type: 'object', additionalProperties: false,
                properties: { exists: { type: 'string' }, truthy: { type: 'string' } },
              },
              forEach: { type: 'string', description: 'Expand target per element of an array artifact.' },
            },
          },
        },
      },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        written: { type: 'boolean' }, diagnostics: { type: 'integer' }, errors: { type: 'integer' },
      } },
      render: (_args, value) => [{
        type: 'text',
        text: `Draft written (${value.errors} error(s), ${value.diagnostics} diagnostic(s)). Run flow_check next.`,
      }],
    },
    presentCall: args => ({ card: 'generic', title: `Draft flow ${args?.name ?? ''}`, kind: 'other', rawInput: args }),
    async execute(args, exec) {
      const doc = {
        name: requireString(args, 'name'),
        description: typeof args.description === 'string' ? args.description : '',
        ...(typeof args.model === 'string' && args.model.trim() ? { model: args.model.trim() } : {}),
        board: args.board && typeof args.board === 'object' && !Array.isArray(args.board) ? args.board : {},
        nodes: Array.isArray(args.nodes) ? args.nodes : [],
        routes: Array.isArray(args.routes) ? args.routes : [],
      }
      if (!SLUG_PATTERN.test(doc.name)) throw new Error(`\`name\` must match ${String(SLUG_PATTERN)}`)
      store.writeDraft(rootOf(requireAgent(exec)), doc)
      const diagnostics = checkFlow(doc)
      return {
        written: true,
        diagnostics: diagnostics.length,
        errors: diagnostics.filter(entry => entry.severity === 'error').length,
      }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // flow_check
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_check',
    description: 'Validate a FlowDraft structurally (ids, routes, predicates, referee commands, cycles) '
      + 'and return diagnostics. Locking requires zero errors.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['name'],
      properties: { name: { type: 'string', description: 'Draft slug to check.' } },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        ok: { type: 'boolean' }, diagnostics: { type: 'array', items: { type: 'string' } },
      } },
      render: (_args, value) => [{
        type: 'text',
        text: value.ok ? 'No errors. Ready to flow_lock.' : `Errors:\n${value.diagnostics.join('\n')}`,
      }],
    },
    presentCall: args => ({ card: 'generic', title: `Check flow ${args?.name ?? ''}`, kind: 'other', rawInput: args }),
    async execute(args, exec) {
      const slug = requireString(args, 'name')
      const draft = store.readDraft(rootOf(requireAgent(exec)), slug)
      if (!draft) throw new Error(`draft "${slug}" not found — write it with flow_draft first`)
      const diagnostics = checkFlow(draft)
      return {
        ok: !diagnostics.some(entry => entry.severity === 'error'),
        diagnostics: diagnostics.map(entry => `${entry.severity} ${entry.path}: ${entry.message}`),
      }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // flow_lock
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_lock',
    description: 'Freeze a checked draft into an immutable FlowLock: canonicalized nodes/routes hashed '
      + 'into identity flk_<digest>. Reordered authoring input cannot forge the same id with different '
      + 'behavior; loading re-verifies both hashes.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['name'],
      properties: { name: { type: 'string', description: 'Draft slug to canonicalize and lock.' } },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        lockId: { type: 'string' }, contentHash: { type: 'string' }, warnings: { type: 'integer' },
      } },
      render: (_args, value) => [{
        type: 'text',
        text: `Locked as ${value.lockId} (${value.contentHash}); ${value.warnings} warning(s). Next: flow_review_prepare.`,
      }],
    },
    presentCall: args => ({ card: 'generic', title: `Lock flow ${args?.name ?? ''}`, kind: 'other', rawInput: args }),
    async execute(args, exec) {
      const slug = requireString(args, 'name')
      const root = rootOf(requireAgent(exec))
      const draft = store.readDraft(root, slug)
      if (!draft) throw new Error(`draft "${slug}" not found`)
      const diagnostics = checkFlow(draft)
      const errors = diagnostics.filter(entry => entry.severity === 'error')
      if (errors.length > 0) {
        throw new Error(`draft has ${errors.length} error(s); fix them before locking:\n`
          + errors.map(entry => `- ${entry.path}: ${entry.message}`).join('\n'))
      }
      const canonical = canonicalizeFlow(draft)
      const { lockDoc, lockId, contentHash } = store.writeLock(root, canonical)
      void lockDoc
      return { lockId, contentHash, warnings: diagnostics.filter(entry => entry.severity === 'warning').length }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // flow_list
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_list',
    description: 'List everything Humanize tracks under this workspace: drafts, locks, reviews, runs.',
    parameters: { type: 'object', additionalProperties: false, properties: {} },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: { report: { type: 'string' } } },
      render: (_args, value) => [{ type: 'text', text: value.report }],
    },
    async execute(_args, exec) {
      const root = rootOf(requireAgent(exec))
      const lines = [`State root: ${root}`, '', 'Drafts:']
      const drafts = store.listDrafts(root)
      lines.push(...(drafts.length > 0
        ? drafts.map(entry => `  - ${entry.name.replace(/\.draft\.json$/, '')}`)
        : ['  (none)']))
      lines.push('', 'Locks:')
      const locks = store.listLocks(root)
      lines.push(...(locks.length > 0
        ? locks.map(entry => {
            const doc = readJsonFile(entry.path)
            return `  - ${doc?.lockId ?? '?'}  ${doc?.flow?.name ?? '?'} (${doc?.contentHash ?? '?'})`
          })
        : ['  (none)']))
      lines.push('', 'Reviews:')
      const reviews = store.listReviews(root)
      lines.push(...(reviews.length > 0
        ? reviews.map(reviewId => {
            const binding = readReviewQuietly(root, reviewId)
            return `  - ${reviewId}  ${binding?.flowName ?? '?'}  ${binding?.decision ?? 'pending'}`
          })
        : ['  (none)']))
      lines.push('', 'Runs:')
      const runs = store.listRuns(root)
      lines.push(...(runs.length > 0
        ? runs.map(runId => {
            const header = store.readRunHeader(root, runId) ?? {}
            const state = replayRun(store.readEvents(root, runId))
            return `  - ${runId}  ${header.flowName ?? '?'}  ${state.status}`
          })
        : ['  (none)']))
      return { report: lines.join('\n') }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // flow_show
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_show',
    description: 'Render one flow (by lock id or draft slug) as a readable graph: stages, referee commands, routes.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['flow'],
      properties: { flow: { type: 'string', description: 'flk_… lock id or draft slug.' } },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: { graph: { type: 'string' } } },
      render: (_args, value) => [{ type: 'text', text: value.graph }],
    },
    async execute(args, exec) {
      const ref = requireString(args, 'flow')
      const root = rootOf(requireAgent(exec))
      const flow = ref.startsWith('flk_') ? store.readLock(root, ref)?.flow : store.readDraft(root, ref)
      if (!flow) throw new Error(`flow "${ref}" not found`)
      const lines = [`# ${flow.name}`, flow.description || '', '', 'Nodes:']
      for (const node of flow.nodes) {
        lines.push(`  ${node.id}${node.title && node.title !== node.id ? ` — ${node.title}` : ''}`
          + `  [${node.executor}${node.model ? ` · ${node.model}` : node.model === undefined && flow.model ? ` · ${flow.model}*` : ''}]`
          + `  max=${node.maxActivations}`
          + `\n      verify: ${node.verify.map(command => command.command).join(' && ')}`)
        if (Array.isArray(node.produces) && node.produces.length > 0) {
          lines.push(`      produces: ${node.produces.join(', ')}`)
        }
      }
      if (flow.model) lines.push(`\n(* = inherits the flow-level model "${flow.model}")`)
      lines.push('', 'Routes:')
      const routes = Array.isArray(flow.routes) ? flow.routes : []
      lines.push(...(routes.length > 0
        ? routes.map(route => {
            const condition = route.when
              ? ` ${stableStringify(route.when)}`
              : route.forEach ? ` foreach ${route.forEach}` : ''
            return `  ${route.from} → ${route.to}${route.kind === 'on_failure' ? ' [on failure]' : ''}${condition}`
          })
        : ['  (single-node flow)']))
      return { graph: lines.join('\n') }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // flow_review_prepare
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_review_prepare',
    description: 'Prepare the review package for a lock: HMAC-signed prepared record plus a human-readable '
      + 'review.md projection. The decision that follows is terminal and immutable.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['lock'],
      properties: { lock: { type: 'string', description: 'flk_… lock id (or draft slug for its latest lock).' } },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        reviewId: { type: 'string' }, reviewPath: { type: 'string' },
      } },
      render: (_args, value) => [{
        type: 'text',
        text: `Review ${value.reviewId} prepared at ${value.reviewPath}. Present it to the user, then call `
          + 'flow_review_decide with their verdict.',
      }],
    },
    presentCall: args => ({ card: 'generic', title: `Prepare review ${args?.lock ?? ''}`, kind: 'other', rawInput: args }),
    async execute(args, exec) {
      const agent = requireAgent(exec)
      const root = rootOf(agent)
      const lockDoc = loadLock(root, requireString(args, 'lock'))
      const { reviewId, dir, payload } = store.prepareReview(root, lockDoc)
      const markdown = renderReviewMarkdown(lockDoc, payload)
      const reviewPath = join(dir, 'review.md')
      writeFileEnsured(reviewPath, markdown)
      return { reviewId, reviewPath }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // flow_review_decide
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_review_decide',
    description: 'THE single decision tool for one prepared review: approve, reject, or bypass. Terminal '
      + 'and immutable — a second call is refused. reject/bypass require a reason. Only approved/bypassed '
      + 'bindings authorize flow_run.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['reviewId', 'decision'],
      properties: {
        reviewId: { type: 'string' },
        decision: { type: 'string', enum: ['approved', 'rejected', 'bypassed'] },
        reason: { type: 'string', description: 'Required for reject/bypass; recorded verbatim.' },
      },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        decision: { type: 'string' }, runnable: { type: 'boolean' },
      } },
      render: (_args, value) => [{
        type: 'text',
        text: value.runnable
          ? `Decision recorded: ${value.decision}. This lock may now flow_run.`
          : `Decision recorded: ${value.decision}. This lock cannot run; revise the draft instead.`,
      }],
    },
    presentCall: args => ({
      card: 'generic', title: `Decide review ${args?.reviewId ?? ''}: ${args?.decision ?? ''}`,
      kind: 'other', rawInput: args,
    }),
    async execute(args, exec) {
      const reviewId = requireString(args, 'reviewId')
      const decision = requireString(args, 'decision')
      const agent = requireAgent(exec)
      const payload = store.decideReview(rootOf(agent), reviewId, decision, args.reason)
      return { decision: payload.decision, runnable: decision === 'approved' || decision === 'bypassed' }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // flow_run
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_run',
    description: 'Execute a reviewed FlowLock. Verifies the HMAC-signed review binding (approved/bypassed '
      + 'only), then schedules ready nodes: agent nodes run on subagents, gate nodes are referee-only. '
      + 'Returns immediately with the run id — poll flow_status.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['lock', 'review'],
      properties: {
        lock: { type: 'string', description: 'flk_… lock id (or draft slug for its latest lock).' },
        review: { type: 'string', description: 'frv_… review id that approved (or bypassed) this exact lock.' },
      },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        runId: { type: 'string' }, entryNodes: { type: 'array', items: { type: 'string' } },
      } },
      render: (_args, value) => [{
        type: 'text',
        text: `Run ${value.runId} started; entry nodes: ${value.entryNodes.join(', ') || '(none)'}. Poll flow_status.`,
      }],
    },
    presentCall: args => ({ card: 'generic', title: `Run flow ${args?.lock ?? ''}`, kind: 'other', rawInput: args }),
    async execute(args, exec) {
      const agent = requireAgent(exec)
      const root = rootOf(agent)
      const lockDoc = loadLock(root, requireString(args, 'lock'))
      const reviewId = requireString(args, 'review')
      const binding = store.readReviewBinding(root, reviewId, lockDoc.contentHash)
      if (!binding) throw new Error(`review ${reviewId} not found`)
      if (binding.decision !== 'approved' && binding.decision !== 'bypassed') {
        throw new Error(`review ${reviewId} is ${binding.decision}; only approved/bypassed bindings authorize a run`)
      }
      const runId = store.newRunId()
      const cwd = cwdOf(agent)
      store.createRun(root, runId, {
        runId, lockId: lockDoc.lockId, contentHash: lockDoc.contentHash,
        flowName: lockDoc.flow.name, reviewId, decision: binding.decision, createdAt: Date.now(), cwd,
      })
      store.appendEvent(root, runId, { type: 'run/start', lockId: lockDoc.lockId, reviewId })
      scheduleIfIdle(root, runId, agent)
      const state = replayRun(store.readEvents(root, runId))
      const entryNodes = [...new Set(tasksFor(lockDoc.flow, root, runId, state).map(task => task.node))]
      return { runId, entryNodes }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // flow_status
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_status',
    description: 'Replay one run from its authoritative event log and report per-node status, activations, '
      + 'artifacts, and eligible next nodes. Works across process restarts.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['run'],
      properties: { run: { type: 'string', description: 'run_… id.' } },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: { report: { type: 'string' } } },
      render: (_args, value) => [{ type: 'text', text: value.report }],
    },
    async execute(args, exec) {
      const runId = requireString(args, 'run')
      const agent = requireAgent(exec)
      const root = rootOf(agent)
      const header = store.readRunHeader(root, runId)
      if (!header) throw new Error(`run ${runId} not found under ${root}`)
      const events = store.readEvents(root, runId)
      const state = replayRun(events)
      const lockDoc = store.readLock(root, header.lockId)
      const flow = lockDoc?.flow
      const ready = flow ? tasksFor(flow, root, runId, state) : []
      return { report: renderStatus(header, state, ready, activeRuns.has(`${root}|${runId}`)) }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // flow_resume
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_resume',
    description: 'Continue an interrupted or stopped run: replays events.jsonl and reschedules every '
      + 'eligible node. Completed stages never rerun ("a loop that stopped on Thursday carries on").',
    parameters: {
      type: 'object', additionalProperties: false, required: ['run'],
      properties: { run: { type: 'string', description: 'run_… id to resume.' } },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        runId: { type: 'string' }, resumedTasks: { type: 'integer' },
      } },
      render: (_args, value) => [{
        type: 'text',
        text: `Run ${value.runId} resumed with ${value.resumedTasks} eligible task(s). Poll flow_status.`,
      }],
    },
    presentCall: args => ({ card: 'generic', title: `Resume run ${args?.run ?? ''}`, kind: 'other', rawInput: args }),
    async execute(args, exec) {
      const runId = requireString(args, 'run')
      const agent = requireAgent(exec)
      const root = rootOf(agent)
      const header = store.readRunHeader(root, runId)
      if (!header) throw new Error(`run ${runId} not found`)
      if (activeRuns.has(`${root}|${runId}`)) throw new Error(`run ${runId} is already running in this process`)
      const state = replayRun(store.readEvents(root, runId))
      if (['finished', 'failed'].includes(state.status)) {
        throw new Error(`run ${runId} is already ${state.status}; nothing to resume`)
      }
      store.appendEvent(root, runId, { type: 'run/resume' })
      scheduleIfIdle(root, runId, agent)
      const lockDoc = store.readLock(root, header.lockId)
      const resumedTasks = lockDoc ? tasksFor(lockDoc.flow, root, runId, replayRun(store.readEvents(root, runId))).length : 0
      return { runId, resumedTasks }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // flow_stop
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'flow_stop',
    description: 'Cancel one running flow: aborts in-flight node activations and marks the run stopped. '
      + 'Progress up to the last settled event remains valid; flow_resume continues later.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['run'],
      properties: { run: { type: 'string', description: 'run_… id to stop.' } },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: { stopped: { type: 'boolean' } } },
      render: (_args, value) => [{
        type: 'text',
        text: value.stopped ? 'Stop requested; in-flight stages are being aborted.' : 'Run was not active in this process.',
      }],
    },
    async execute(args, exec) {
      const runId = requireString(args, 'run')
      const root = rootOf(requireAgent(exec))
      const entry = activeRuns.get(`${root}|${runId}`)
      if (!entry) return { stopped: false }
      entry.controller.abort(new Error('stopped by flow_stop'))
      return { stopped: true }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // trace_export
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'trace_export',
    description: 'Export one run\'s trace: "md" readable timeline, "chrome-json" span trace importable at '
      + 'ui.perfetto.dev, or "jsonl" raw event copy. Writes beside the run and returns the path.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['run'],
      properties: {
        run: { type: 'string' },
        format: { type: 'string', enum: ['md', 'chrome-json', 'jsonl'], description: 'Default md.' },
      },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        path: { type: 'string' }, preview: { type: 'string' },
      } },
      render: (_args, value) => [{ type: 'text', text: `Trace written to ${value.path}\n\n${value.preview}` }],
    },
    presentCall: args => ({ card: 'generic', title: `Export trace ${args?.run ?? ''}`, kind: 'other', rawInput: args }),
    async execute(args, exec) {
      const runId = requireString(args, 'run')
      const format = typeof args.format === 'string' ? args.format : 'md'
      const root = rootOf(requireAgent(exec))
      const header = store.readRunHeader(root, runId)
      if (!header) throw new Error(`run ${runId} not found`)
      const events = store.readEvents(root, runId)
      if (events.length === 0) throw new Error(`run ${runId} has no events`)
      let text
      let extension
      if (format === 'jsonl') {
        text = events.map(record => JSON.stringify(record)).join('\n') + '\n'
        extension = 'jsonl'
      } else if (format === 'chrome-json') {
        text = stableStringify(chromeTrace(header, events)) + '\n'
        extension = 'chrome.json'
      } else {
        text = renderTraceMarkdown(header, events)
        extension = 'md'
      }
      const path = join(store.runDir(root, runId), `trace.${extension}`)
      writeFileEnsured(path, text)
      return { path, preview: format === 'md' ? text.slice(0, 1500) : `${events.length} event(s)` }
    },
  })

  // ════════════════════════════════════════════════════════════════════════
  // edit_anchored — oh-my-humanize's hash-anchored edits
  // ════════════════════════════════════════════════════════════════════════
  ctx.tools.register({
    name: 'edit_anchored',
    description: 'Hash-anchored edit: replaces literal text only when the file\'s current SHA-256 matches '
      + 'expectSha256 (the hash hash_file reported for your last read/edit). Prevents editing a file that '
      + 'changed since you saw it — the "replace entire file" trap.',
    parameters: {
      type: 'object', additionalProperties: false,
      required: ['path', 'oldString', 'newString', 'expectSha256'],
      properties: {
        path: { type: 'string', description: 'Target file path (absolute or workspace-relative).' },
        oldString: { type: 'string', description: 'Literal text to replace; must appear exactly once unless replaceAll.' },
        newString: { type: 'string', description: 'Replacement text; empty deletes the match.' },
        expectSha256: { type: 'string', description: 'SHA-256 hex of the ENTIRE file as you last saw it.' },
        replaceAll: { type: 'boolean', description: 'Replace every match; default false.' },
      },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        applied: { type: 'boolean' }, nextSha256: { type: 'string' },
      } },
      render: (_args, value) => [{
        type: 'text',
        text: `Anchored edit applied. New file SHA-256: ${value.nextSha256} (chain it into your next expectSha256).`,
      }],
    },
    presentCall: args => ({ card: 'generic', title: `Anchored edit ${args?.path ?? ''}`, kind: 'other', rawInput: { path: args?.path } }),
    async execute(args, exec) {
      const agent = requireAgent(exec)
      const fsService = ctx.get('fs')
      if (fsService === undefined) throw new Error('filesystem service unavailable')
      const path = requireString(args, 'path')
      const oldString = requireString(args, 'oldString')
      const expected = requireString(args, 'expectSha256').toLowerCase()
      const target = await fsService.resolve(path, { cwd: cwdOf(agent), signal: exec.signal })
      const current = await fsService.readText(target, exec.signal)
      const actual = sha256Hex(current)
      if (actual !== expected) {
        throw new Error(`anchor mismatch: file SHA-256 is ${actual}, expected ${expected}. `
          + 'Re-read the file (hash_file) and retry with its current hash.')
      }
      const outcome = await fsService.editText(target, {
        oldString,
        newString: typeof args.newString === 'string' ? args.newString : '',
        replaceAll: args.replaceAll === true,
      }, undefined, exec.signal)
      return { applied: true, nextSha256: sha256Hex(outcome.after) }
    },
  })

  ctx.tools.register({
    name: 'hash_file',
    description: 'Compute the SHA-256 of a file\'s current UTF-8 text — the expectSha256 value edit_anchored demands.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['path'],
      properties: { path: { type: 'string' } },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: {
        sha256: { type: 'string' }, bytes: { type: 'integer' },
      } },
      render: (_args, value) => [{ type: 'text', text: `${value.sha256}  (${value.bytes} bytes)` }],
    },
    async execute(args, exec) {
      const agent = requireAgent(exec)
      const fsService = ctx.get('fs')
      if (fsService === undefined) throw new Error('filesystem service unavailable')
      const target = await fsService.resolve(requireString(args, 'path'), { cwd: cwdOf(agent), signal: exec.signal })
      const text = await fsService.readText(target, exec.signal)
      return { sha256: sha256Hex(text), bytes: Buffer.byteLength(text, 'utf8') }
    },
  })

  // ── model catalog — what the shelves actually stock ─────────────────────
  ctx.tools.register({
    name: 'model_catalog',
    description: 'List the provider routes and models this deployment can call, for choosing node/flow '
      + '`model` values in Humanize flows. Without arguments: registered providers. With `provider`: that '
      + 'provider\'s known models (adapter catalog; may query the endpoint). Reference a model as '
      + '"provider/model" or bare "model" in flow_draft.',
    parameters: {
      type: 'object', additionalProperties: false,
      properties: { provider: { type: 'string', description: 'Provider route id to enumerate models for.' } },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: { report: { type: 'string' } } },
      render: (_args, value) => [{ type: 'text', text: value.report }],
    },
    async execute(args, exec) {
      const llm = ctx.get('llm')
      if (llm === undefined) throw new Error('llm service unavailable')
      if (typeof args?.provider === 'string' && args.provider.length > 0) {
        const models = await llm.listModels(args.provider)
        const lines = [`Provider "${args.provider}" models:`]
        lines.push(...(models.length > 0
          ? models.map(model => `  - ${model.provider}/${model.id}${model.name ? `  (${model.name})` : ''}`
            + `${model.description ? ` — ${model.description}` : ''}`)
          : ['  (none disclosed)']))
        return { report: lines.join('\n') }
      }
      const providers = llm.listProviders()
      const lines = ['Registered provider routes:', ...(providers.length > 0
        ? providers.map(provider => `  - ${provider.id}${provider.name && provider.name !== provider.id ? `  (${provider.name})` : ''}`)
        : ['  (none)'])]
      const defaultModel = ctx.get('agentDefaultModel')
      if (defaultModel !== undefined && typeof defaultModel.currentSelection === 'function') {
        try {
          const selection = defaultModel.currentSelection()
          if (selection) {
            lines.push('', `Session default: ${[selection.provider, selection.model].filter(Boolean).join('/') || '(unspecified)'}`
              + ' — agent nodes inherit this when no model tier applies.')
          }
        } catch {
          // Selection is optional metadata; listing providers already succeeded.
        }
      }
      lines.push('', 'Call again with {"provider":"<id>"} to list one provider\'s models.')
      return { report: lines.join('\n') }
    },
  })

  // ── scheduler ───────────────────────────────────────────────────────────

  /**
   * Start the scheduling loop for a run unless this process already owns one.
   * The loop is fully event-sourced: every iteration re-reads events.jsonl,
   * computes eligibility from the replayed state, activates what fits under
   * maxParallel, and settles the run when nothing is active or eligible.
   */
  function scheduleIfIdle(root, runId, parentAgent) {
    const key = `${root}|${runId}`
    if (activeRuns.has(key)) return
    const controller = new AbortController()
    const entry = { controller }
    activeRuns.set(key, entry)
    entry.promise = runLoop(root, runId, parentAgent, controller.signal)
      .catch(error => {
        try {
          store.appendEvent(root, runId, { type: 'run/fail', error: String(error?.message ?? error) })
        } catch {
          // The log itself is gone; nothing further can be recorded.
        }
      })
      .finally(() => { activeRuns.delete(key) })
  }

  async function runLoop(root, runId, parentAgent, signal) {
    const header = store.readRunHeader(root, runId)
    if (!header) throw new Error(`run ${runId} vanished`)
    const lockDoc = store.readLock(root, header.lockId)
    if (!lockDoc) throw new Error(`lock ${header.lockId} missing for run ${runId}`)
    const flow = lockDoc.flow

    for (;;) {
      if (signal.aborted) break
      const state = replayRun(store.readEvents(root, runId))
      if (['finished', 'failed', 'stopped'].includes(state.status)) break

      const slots = Math.max(0, store.config.maxParallel - state.activeCount)
      const batch = tasksFor(flow, root, runId, state, true).slice(0, slots)
      if (batch.length === 0) {
        if (state.activeCount === 0) {
          const unhandled = unhandledFailures(flow, state)
          if (unhandled.length > 0) {
            store.appendEvent(root, runId, {
              type: 'run/fail',
              error: `stage(s) failed without an on_failure route: ${unhandled.join(', ')}`,
            })
          } else {
            store.appendEvent(root, runId, { type: 'run/finish' })
          }
          break
        }
        await delay(SCHEDULE_TICK_MS, signal)
        continue
      }
      for (const task of batch) {
        void activateNode(root, runId, flow, task, parentAgent, signal, header.cwd)
      }
      await delay(SCHEDULE_TICK_MS, signal)
    }
  }

  /** Execute one ready task (a real node or a fanout expansion) to a terminal event. */
  async function activateNode(root, runId, flow, task, parentAgent, signal, cwd) {
    const { node, activation, itemText } = task
    const nodeDef = flow.nodes.find(candidate => candidate.id === node)
    if (!nodeDef) {
      store.appendEvent(root, runId, {
        type: 'node/activation_end', node, activation, status: 'failed', error: 'node definition missing',
      })
      return
    }
    // Model selection: node.model > flow.model > config.nodeModelDefault > inherit session.
    const modelRef = nodeDef.executor !== 'gate'
      ? (nodeDef.model ?? flow.model ?? store.config.nodeModelDefault ?? '').trim()
      : ''
    const parsedModel = parseModelRef(modelRef)
    store.appendEvent(root, runId, {
      type: 'node/activation_start', node, activation, executor: nodeDef.executor,
      ...(modelRef ? { model: modelRef } : {}),
    })

    try {
      // 1. Agent work (skipped for gate milestones).
      let outputText = ''
      if (nodeDef.executor !== 'gate') {
        const subagents = ctx.get('subagents')
        if (subagents === undefined) throw new Error('subagents registry unavailable (delegation not composed)')
        const provider = nodeDef.executor === 'fork' ? 'fork' : 'spawn'
        const promptParts = [
          `You are executing ONE stage (${node}) of the Humanize flow "${flow.name}".`,
          nodeDef.prompt,
          itemText ? `Fanout item for THIS activation:\n${itemText}` : '',
          contextBlock(root, runId, flow),
          'Finish with a final message whose ENTIRE text is the artifact payload for this stage: '
            + `${(nodeDef.produces ?? []).join(', ') || '(describe the outcome)'}. No preamble, no commentary.`,
        ]
        // Model selection: node.model > flow.model > config.nodeModelDefault > inherit session.
        const run = await subagents.start(provider, {
          label: `flow:${flow.name}:${activation}`,
          prompt: [{ type: 'text', text: promptParts.filter(Boolean).join('\n\n') }],
          parent: parentAgent,
          signal,
          ...(parsedModel ? { agentOptions: parsedModel } : {}),
        })
        const result = await run.result
        outputText = textOf(result.output)
        if (result.stopReason !== 'stop' && result.stopReason !== 'completed') {
          store.appendEvent(root, runId, {
            type: 'node/activation_end', node, activation, status: 'failed',
            error: `subagent stopReason=${result.stopReason}: ${outputText.slice(0, 400)}`,
          })
          return
        }
      }

      // 2. Referee verification — "Lean accepts it, or it does not."
      const shell = ctx.get('shell')
      if (shell === undefined) throw new Error('shell service unavailable (referee commands cannot run)')
      for (const command of nodeDef.verify) {
        const spec = shell.resolve({
          command: command.command,
          workdir: cwd,
          timeoutMs: Number.isSafeInteger(command.timeoutMs) ? command.timeoutMs : store.config.verifyTimeoutMs,
          signal,
        })
        const startedAt = Date.now()
        const outcome = await shell.run(spec)
        const passed = outcome.exitCode === 0
        store.appendEvent(root, runId, {
          type: passed ? 'node/verify_ok' : 'node/verify_fail',
          node, activation, command: command.command,
          durationMs: Date.now() - startedAt,
          exitCode: outcome.exitCode,
          tail: tailOf(outcome),
        })
        if (!passed) {
          store.appendEvent(root, runId, {
            type: 'node/activation_end', node, activation, status: 'failed',
            error: `referee rejected: ${command.command} (exit ${outcome.exitCode})`,
            output: outputText.slice(0, ARTIFACT_CONTEXT_CHARS),
          })
          return
        }
      }

      // 3. Store produced artifacts.
      for (const artifactKey of nodeDef.produces ?? []) {
        const artifactPath = store.saveArtifact(root, runId, artifactKey, outputText)
        store.appendEvent(root, runId, {
          type: 'artifact/store', node, activation, key: artifactKey,
          path: artifactPath, bytes: Buffer.byteLength(outputText, 'utf8'),
        })
      }
      store.appendEvent(root, runId, { type: 'node/activation_end', node, activation, status: 'success' })
    } catch (error) {
      if (signal.aborted || error?.name === 'AbortError') {
        store.appendEvent(root, runId, { type: 'node/activation_aborted', node, activation })
        store.appendEvent(root, runId, { type: 'run/stop' })
      } else {
        store.appendEvent(root, runId, {
          type: 'node/activation_end', node, activation, status: 'failed',
          error: String(error?.message ?? error),
        })
      }
    }
  }

  // ── replay ──────────────────────────────────────────────────────────────

  /**
   * Fold the authoritative event log into a snapshot. Pure over the record
   * list: no filesystem access, so callers control what artifacts mean.
   */
  function replayRun(events) {
    const state = {
      status: 'running',
      nodes: new Map(),
      artifacts: new Map(),
      ready: [],
      activeCount: 0,
      startedAt: undefined,
      finishedAt: undefined,
    }
    for (const record of events) {
      switch (record.type) {
        case 'run/start': state.startedAt = record.ts; break
        case 'run/finish': state.status = 'finished'; state.finishedAt = record.ts; break
        case 'run/fail': state.status = 'failed'; state.finishedAt = record.ts; break
        case 'run/stop': if (state.status === 'running') state.status = 'stopped'; break
        case 'run/resume':
          if (state.status === 'stopped') state.status = 'running'
          break
        case 'artifact/store': state.artifacts.set(record.key, record.path); break
        case 'node/activation_start': {
          const entryState = nodeEntry(state, record.node)
          entryState.status = 'active'
          entryState.activations += 1
          break
        }
        case 'node/activation_end': {
          const entryState = nodeEntry(state, record.node)
          entryState.status = record.status
          if (record.status === 'failed') entryState.error = record.error
          break
        }
        case 'node/activation_aborted': {
          const entryState = nodeEntry(state, record.node)
          entryState.activations = Math.max(0, entryState.activations - 1)
          entryState.status = 'pending'
          break
        }
        default: break
      }
    }
    state.activeCount = [...state.nodes.values()].filter(entryState => entryState.status === 'active').length
    return state
  }

  function nodeEntry(state, id) {
    let entryState = state.nodes.get(id)
    if (!entryState) {
      entryState = { status: 'pending', activations: 0, error: undefined }
      state.nodes.set(id, entryState)
    }
    return entryState
  }

  /**
     Eligible tasks given a replayed state and the locked graph: entry nodes
     (no incoming edges) or nodes whose incoming edges all permit progress —
     sources terminal, predicates true against board ∪ artifacts. Fanout
     routes expand once per source-artifact version. Expansion is RECORDED
     only when `recordFanout` is set (the scheduler); observation stays
     read-only, and an early record would suppress the real expansion.
   */
  function tasksFor(flow, root, runId, state, recordFanout = false) {
    if (state.status !== 'running') return []
    const facts = factsView(flow, state)
    const incoming = new Map(flow.nodes.map(node => [node.id, []]))
    for (const route of flow.routes ?? []) {
      if (incoming.has(route.to)) incoming.get(route.to).push(route)
    }
    const expandedSignatures = new Set()
    for (const record of store.readEvents(root, runId)) {
      if (record.type === 'fanout/expanded') expandedSignatures.add(record.signature)
    }
    const tasks = []
    for (const node of flow.nodes) {
      const entryState = state.nodes.get(node.id) ?? { status: 'pending', activations: 0 }
      if (['active', 'success', 'failed'].includes(entryState.status)) continue
      if (entryState.activations >= node.maxActivations) continue
      const routes = incoming.get(node.id) ?? []
      const eligible = routes.length === 0 || routes.every(route => {
        const source = state.nodes.get(route.from)
        if (!source) return false
        if (route.kind === 'on_failure') return source.status === 'failed'
        if (source.status !== 'success') return false
        if (route.when === undefined) return true
        return evalPredicate(route.when, facts)
      })
      if (!eligible) continue

      const fanoutRoute = routes.find(route => typeof route.forEach === 'string')
      if (fanoutRoute) {
        const signature = `${fanoutRoute.from}->${fanoutRoute.to}@${state.artifacts.get(fanoutRoute.forEach) ?? ''}`
        if (expandedSignatures.has(signature)) continue
        const raw = store.readArtifactText(state.artifacts.get(fanoutRoute.forEach) ?? '')
        let items
        try { items = JSON.parse(raw) } catch { items = null }
        if (recordFanout) {
          store.appendEvent(root, runId, { type: 'fanout/expanded', signature, count: Array.isArray(items) ? items.length : 0 })
        }
        if (!Array.isArray(items) || items.length === 0) {
          tasks.push({ node: node.id, activation: `${node.id}#1`, itemText: '' })
        } else {
          for (const [index, item] of items.slice(0, MAX_FANOUT).entries()) {
            tasks.push({
              node: node.id,
              activation: `${node.id}#${index + 1}`,
              itemText: typeof item === 'string' ? item : stableStringify(item),
            })
          }
        }
      } else {
        tasks.push({ node: node.id, activation: `${node.id}#${entryState.activations + 1}` })
      }
    }
    return tasks
  }

  /** Predicate facts: initial board ∪ produced artifact texts. */
  function factsView(flow, state) {
    const facts = {}
    for (const [key, value] of Object.entries(flow.board ?? {})) facts[key] = value
    for (const [key, path] of state.artifacts) facts[key] = store.readArtifactText(path)
    return facts
  }

  /** Node ids that failed with no on_failure escape edge. */
  function unhandledFailures(flow, state) {
    const handled = new Set((flow.routes ?? [])
      .filter(route => route.kind === 'on_failure')
      .map(route => route.from))
    return [...state.nodes.entries()]
      .filter(([id, entryState]) => entryState.status === 'failed' && !handled.has(id))
      .map(([id]) => id)
  }

  // ── rendering ───────────────────────────────────────────────────────────

  function renderStatus(header, state, ready, inProcess) {
    const lines = [
      `Run ${header.runId} — flow "${header.flowName}" (${header.lockId})`,
      `Review: ${header.reviewId} (${header.decision})`,
      `Status: ${state.status}${state.status === 'running' && !inProcess ? ' (not owned by this process — flow_resume to continue)' : ''}`,
      `Started: ${state.startedAt ? new Date(state.startedAt).toISOString() : '?'}`
        + `   Finished: ${state.finishedAt ? new Date(state.finishedAt).toISOString() : '—'}`,
      '',
    ]
    if (state.nodes.size > 0) {
      lines.push('Nodes:')
      for (const [id, entryState] of state.nodes) {
        lines.push(`  ${id.padEnd(24)} ${entryState.status.padEnd(9)} activations=${entryState.activations}`
          + `${entryState.error ? `  error: ${String(entryState.error).slice(0, 200)}` : ''}`)
      }
    }
    if (ready.length > 0) {
      lines.push('', 'Eligible next:', ...ready.map(task => `  - ${task.activation}${task.itemText ? ' (fanout)' : ''}`))
    }
    if (state.artifacts.size > 0) {
      lines.push('', 'Artifacts:')
      for (const [key, path] of state.artifacts) lines.push(`  ${key} → ${path}`)
    }
    return lines.join('\n')
  }

  function renderReviewMarkdown(lockDoc, payload) {
    const flow = lockDoc.flow
    const lines = [
      `# Review ${payload.reviewId}`,
      '',
      `Flow: **${flow.name}**`,
      `Lock: \`${lockDoc.lockId}\``,
      `Content hash: \`${lockDoc.contentHash}\``,
      '',
      flow.description || '(no description)',
      '',
      '| # | Stage | Executor | Referee (all must pass) | Produces |',
      '|---|-------|----------|--------------------------|----------|',
    ]
    flow.nodes.forEach((node, index) => {
      lines.push(`| ${index + 1} | ${node.id} — ${node.title} | ${node.executor} | `
        + node.verify.map(command => `\`${command.command}\``).join('<br>')
        + ` | ${(node.produces ?? []).join(', ') || '—'} |`)
    })
    lines.push('', '## Routes', '')
    const routes = flow.routes ?? []
    if (routes.length === 0) lines.push('(single stage)')
    for (const route of routes) {
      const condition = route.when
        ? ` when ${stableStringify(route.when)}`
        : route.forEach ? ` for each element of \`${route.forEach}\`` : ''
      lines.push(`- ${route.from} → ${route.to}${route.kind === 'on_failure' ? ' (failure path)' : ''}${condition}`)
    }
    lines.push(
      '', '---', '',
      'Decide with `flow_review_decide`: `approved` authorizes execution; `rejected` / `bypassed` need a reason. Decisions are terminal.',
      '',
    )
    return lines.join('\n')
  }

  function renderTraceMarkdown(header, events) {
    const lines = [
      `# Trace — run ${header.runId}`,
      '',
      `Flow **${header.flowName}** · lock \`${header.lockId}\` · review \`${header.reviewId}\` (${header.decision})`,
      '',
      '| ts | seq | event | detail |',
      '|----|-----|-------|--------|',
    ]
    for (const record of events) {
      const { seq, ts, type, ...rest } = record
      const detail = Object.keys(rest).length === 0 ? '' : stableStringify(rest).slice(0, 220)
      lines.push(`| ${new Date(ts).toISOString()} | ${seq} | ${type} | ${detail} |`)
    }
    lines.push('')
    return lines.join('\n')
  }

  /** Chrome-JSON span trace importable at ui.perfetto.dev. */
  function chromeTrace(header, events) {
    const micro = ts => Math.round(ts * 1000)
    const pid = 1
    const traceEvents = [{
      ph: 'M', name: 'process_name', pid, tid: 0, args: { name: `humanize:${header.flowName}` },
    }]
    for (const record of events) {
      const thread = threadOf(record.activation)
      if (record.type === 'node/activation_start') {
        traceEvents.push({ ph: 'B', pid, tid: thread, ts: micro(record.ts), name: record.activation, cat: 'node' })
      }
      if (record.type === 'node/activation_end') {
        traceEvents.push({
          ph: 'E', pid, tid: thread, ts: micro(record.ts),
          name: record.activation, args: { status: record.status, error: record.error },
        })
      }
      if (record.type === 'node/verify_ok' || record.type === 'node/verify_fail') {
        traceEvents.push({
          ph: 'X', pid, tid: thread, ts: micro(record.ts - (record.durationMs ?? 0)),
          dur: Math.max(1, micro(record.durationMs ?? 0)),
          name: `verify: ${String(record.command).slice(0, 60)}`, cat: 'referee',
          args: { exitCode: record.exitCode },
        })
      }
    }
    return { traceEvents }
  }

  function threadOf(activation) {
    // Stable per-activation thread so concurrent spans do not nest falsely.
    let hash = 0
    const text = typeof activation === 'string' ? activation : ''
    for (let index = 0; index < text.length; index += 1) {
      hash = (hash * 31 + text.charCodeAt(index)) >>> 0
    }
    return 1 + (hash % 254)
  }

  /** Board ∪ artifact context injected into each node prompt. */
  function contextBlock(root, runId, flow) {
    const state = replayRun(store.readEvents(root, runId))
    const facts = factsView(flow, state)
    const parts = ['Current facts available to this stage:']
    let appendedCount = 0
    for (const [key, value] of Object.entries(facts)) {
      const text = typeof value === 'string' ? value : stableStringify(value)
      parts.push(`--- fact "${key}" ---\n${text.slice(0, ARTIFACT_CONTEXT_CHARS)}`)
      appendedCount += 1
    }
    if (appendedCount === 0) parts.push('(none yet)')
    return parts.join('\n\n')
  }

  /** Best-effort quiet review summary for listings; never throws. */
  function readReviewQuietly(root, reviewId) {
    try {
      return store.readReviewBinding(root, reviewId)
    } catch {
      return { decision: 'invalid-mac', flowName: '?' }
    }
  }
}

// ── module-local helpers ──────────────────────────────────────────────────

/** Join text content blocks into one string. */
function textOf(blocks) {
  if (!Array.isArray(blocks)) return ''
  return blocks
    .filter(block => block?.type === 'text' && typeof block.text === 'string')
    .map(block => block.text)
    .join('\n')
}

/** Bounded tail of a shell outcome for referee evidence. */
function tailOf(outcome) {
  const stdout = outcome?.stdout?.text ?? ''
  const stderr = outcome?.stderr?.text ?? ''
  const combined = (stdout + (stderr ? `\n[stderr]\n${stderr}` : '')).trimEnd()
  return combined.slice(-1200)
}

/** Cancellable sleep that resolves immediately on abort. */
function delay(ms, signal) {
  if (signal.aborted) return Promise.resolve()
  return new Promise(resolveLater => {
    const timer = setTimeout(done, ms)
    function done() {
      signal.removeEventListener('abort', done)
      clearTimeout(timer)
      resolveLater()
    }
    signal.addEventListener('abort', done, { once: true })
  })
}
