/**
 * Humanize flow kernel 鈥?pure document model, canonicalization, identity,
 * structural checking, and route predicates.
 *
 * Ported from the humanfia/humanize-plugin kernel concepts (Node, Contract,
 * Artifact, Board, Route, Event) into a dependency-free ES module so a
 * DeepSeek Harness agent preset can carry it beside its own composition.
 * No I/O happens here: everything is (document) 鈫?(value), which keeps the
 * module unit-testable and lets the store layer own persistence.
 *
 * Identity rule (mirrors FlowLock in humanize-plugin): semantically unordered
 * collections 鈥?nodes and routes 鈥?are canonicalized before both storage and
 * hashing; the lock id `flk_<digest16>` and the content hash are derived from
 * the same canonical bytes, so reordered authoring input cannot produce the
 * same id with different stored behavior. Loading recomputes and validates.
 * @module humanize/flow-kernel
 */

import { createHash } from 'node:crypto'

/** A structural diagnostic produced by {@link checkFlow}. */
export function diagnostic(severity, path, message) {
  return { severity, path, message }
}

/** Slug rule for flow names: filesystem- and id-safe. */
export const SLUG_PATTERN = /^[a-z0-9][a-z0-9._-]{0,63}$/

/**
 * Stable JSON serialization: object keys sorted recursively, arrays kept in
 * order (order IS semantic for arrays that are not canonicalized away),
 * indentation fixed. Two semantically equal canonical documents always
 * produce identical bytes.
 * @param value - any JSON value.
 * @returns the canonical serialization.
 */
export function stableStringify(value) {
  if (value === undefined) return 'null'
  if (value === null || typeof value !== 'object') return JSON.stringify(value)
  if (Array.isArray(value)) {
    return '[' + value.map(item => stableStringify(item)).join(',') + ']'
  }
  const keys = Object.keys(value).filter(key => value[key] !== undefined).sort()
  return '{' + keys.map(key => JSON.stringify(key) + ':' + stableStringify(value[key])).join(',') + '}'
}

/** SHA-256 of a UTF-8 string as lowercase hex. */
export function sha256Hex(text) {
  return createHash('sha256').update(text, 'utf8').digest('hex')
}

/** Short digest used inside artifact/board keys and file names. */
export function shortDigest(text, length = 8) {
  return sha256Hex(text).slice(0, length)
}

/**
 * The one predicate form: `exists` tests presence on the board/artifact map,
 * `truthy` additionally rejects empty text, `false`, and numeric zero 鈥?the
 * same two-predicate discipline humanize-plugin enforces (general expressions
 * are rejected at check time).
 */
export function isValidPredicate(when) {
  if (when === null || typeof when !== 'object') return false
  const keys = Object.keys(when)
  if (keys.length !== 1) return false
  const [kind, key] = [keys[0], when[keys[0]]]
  if ((kind !== 'exists' && kind !== 'truthy')) return false
  return typeof key === 'string' && key.length > 0
}

/**
 * Evaluate one validated predicate against current facts. Artifacts win over
 * board values for the same key (a produced artifact supersedes an initial
 * fact); absence fails both kinds.
 */
export function evalPredicate(when, facts) {
  const [kind] = Object.keys(when)
  const key = when[kind]
  const present = Object.prototype.hasOwnProperty.call(facts, key)
  if (kind === 'exists') return present
  if (!present) return false
  const value = facts[key]
  if (value === null || value === undefined) return false
  if (typeof value === 'string') return value.length > 0
  if (typeof value === 'number') return value !== 0
  if (typeof value === 'boolean') return value === true
  return true
}

/** Canonical sort signature of one route (unordered-collection membership). */
export function routeSignature(route) {
  return [
    route.from ?? '',
    route.to ?? '',
    route.kind ?? 'on_success',
    route.forEach ?? '',
    route.when ? stableStringify(route.when) : '',
  ].join('|')
}

/**
 * Parse a model reference: `"provider/model"` or bare `"model"`. Whitespace or
 * empty halves reject as undefined so callers fall back to the next tier.
 */
export function parseModelRef(ref) {
  if (typeof ref !== 'string') return undefined
  const trimmed = ref.trim()
  if (trimmed.length === 0 || /\s/.test(trimmed)) return undefined
  const slash = trimmed.indexOf('/')
  if (slash === -1) return { model: trimmed }
  const provider = trimmed.slice(0, slash)
  const model = trimmed.slice(slash + 1)
  if (provider.length === 0 || model.length === 0) return undefined
  return { provider, model }
}

/** Validate one flow document's shape and semantics; collect diagnostics. */
export function checkFlow(doc) {
  const diagnostics = []
  const push = (...args) => diagnostics.push(diagnostic(...args))
  if (doc === null || typeof doc !== 'object' || Array.isArray(doc)) {
    push('error', '$', 'flow must be a JSON object')
    return diagnostics
  }
  if (typeof doc.name !== 'string' || !SLUG_PATTERN.test(doc.name)) {
    push('error', '$.name', `flow name must match ${SLUG_PATTERN_SOURCE}`)
  }
  if (doc.description !== undefined && typeof doc.description !== 'string') {
    push('error', '$.description', 'description must be a string when present')
  }
  if (!Array.isArray(doc.nodes) || doc.nodes.length === 0) {
    push('error', '$.nodes', 'nodes must be a non-empty array')
    return diagnostics
  }
  const nodeIds = new Set()
  doc.nodes.forEach((node, index) => {
    const at = `$.nodes[${index}]`
    if (node === null || typeof node !== 'object' || Array.isArray(node)) {
      push('error', at, 'node must be a JSON object')
      return
    }
    if (typeof node.id !== 'string' || !SLUG_PATTERN.test(node.id)) {
      push('error', `${at}.id`, `node id must match ${SLUG_PATTERN_SOURCE}`)
      return
    }
    if (nodeIds.has(node.id)) push('error', `${at}.id`, `duplicate node id "${node.id}"`)
    nodeIds.add(node.id)
    if (typeof node.title !== 'undefined' && typeof node.title !== 'string') {
      push('error', `${at}.title`, 'title must be a string when present')
    }
    const executor = node.executor ?? 'spawn'
    if (executor !== 'spawn' && executor !== 'fork' && executor !== 'gate') {
      push('error', `${at}.executor`, 'executor must be "spawn", "fork", or "gate"')
    }
    if (executor !== 'gate' && typeof node.prompt !== 'string') {
      push('error', `${at}.prompt`, 'agent nodes require a prompt string')
    } else if (executor === 'gate' && node.prompt !== undefined) {
      push('warning', `${at}.prompt`, 'gate nodes never run an agent; prompt is ignored')
    }
    if (executor === 'gate' && node.model !== undefined) {
      push('warning', `${at}.model`, 'gate nodes never run an agent; model is ignored')
    }
    if (executor !== 'gate' && node.produces !== undefined && !Array.isArray(node.produces)) {
      push('error', `${at}.produces`, 'produces must be an array of artifact keys when present')
    }
    if ((executor === 'spawn' || executor === 'fork') && !Array.isArray(node.produces)) {
      push('warning', `${at}.produces`,
        'agent nodes usually produce at least one artifact; downstream routes cannot read a silent node')
    }
    if (Array.isArray(node.produces)) {
      node.produces.forEach((key, keyIndex) => {
        if (typeof key !== 'string' || !ARTIFACT_KEY_PATTERN.test(key)) {
          push('error', `${at}.produces[${keyIndex}]`, `artifact key must match ${ARTIFACT_KEY_SOURCE}`)
        }
      })
    }
    if (!Array.isArray(node.verify) || node.verify.length === 0) {
      push('error', `${at}.verify`, 'verify must be a non-empty array of referee commands')
    } else {
      node.verify.forEach((command, commandIndex) => {
        const at2 = `${at}.verify[${commandIndex}]`
        if (command === null || typeof command !== 'object' || Array.isArray(command) ||
            typeof command.command !== 'string' || command.command.trim().length === 0) {
          push('error', at2, 'each verify entry needs a non-empty "command" string')
        } else if (command.timeoutMs !== undefined &&
            (!Number.isSafeInteger(command.timeoutMs) || command.timeoutMs <= 0)) {
          push('error', `${at2}.timeoutMs`, 'timeoutMs must be a positive safe integer when present')
        }
      })
    }
    if (node.maxActivations !== undefined &&
        (!Number.isSafeInteger(node.maxActivations) || node.maxActivations < 1)) {
      push('error', `${at}.maxActivations`, 'maxActivations must be a positive safe integer when present')
    }
    if (node.model !== undefined && parseModelRef(node.model) === undefined) {
      push('error', `${at}.model`, 'model must be "provider/model" or "model" (no whitespace) when present')
    }
  })
  if (!nodeIds.size) return diagnostics

  // Flow-level default model for agent nodes.
  if (doc.model !== undefined && parseModelRef(doc.model) === undefined) {
    push('error', '$.model', 'model must be "provider/model" or "model" (no whitespace) when present')
  }

  // Routes: endpoints exist, predicates well-formed, no self-route.
  const routes = Array.isArray(doc.routes) ? doc.routes : []
  routes.forEach((route, index) => {
    const at = `$.routes[${index}]`
    if (route === null || typeof route !== 'object' || Array.isArray(route)) {
      push('error', at, 'route must be a JSON object')
      return
    }
    if (typeof route.from !== 'string' || !nodeIds.has(route.from)) {
      push('error', `${at}.from`, `route source "${route.from}" is not a known node id`)
    }
    if (typeof route.to !== 'string' || !nodeIds.has(route.to)) {
      push('error', `${at}.to`, `route target "${route.to}" is not a known node id`)
    }
    if (route.from === route.to) push('error', at, 'self-routes are not allowed')
    if (route.kind !== undefined && route.kind !== 'on_success' && route.kind !== 'on_failure') {
      push('error', `${at}.kind`, 'kind must be "on_success" or "on_failure" when present')
    }
    if (route.when !== undefined && !isValidPredicate(route.when)) {
      push('error', `${at}.when`, 'when must be exactly one of {"exists": key} or {"truthy": key}')
    }
    if (route.forEach !== undefined && typeof route.forEach !== 'string') {
      push('error', `${at}.forEach`, 'forEach must be an artifact key string when present')
    }
    if (route.when !== undefined && route.forEach !== undefined) {
      push('error', at, 'a route may carry either when or forEach, not both')
    }
  })

  // Graph sanity: entry nodes exist, cycle members need activation budgets.
  const incoming = new Map([...nodeIds].map(id => [id, 0]))
  for (const route of routes) {
    if (typeof route?.to === 'string' && nodeIds.has(route.to) &&
        typeof route?.from === 'string' && nodeIds.has(route.from) && route.from !== route.to) {
      incoming.set(route.to, incoming.get(route.to) + 1)
    }
  }
  if (![...incoming.values()].some(count => count === 0)) {
    push('error', '$.routes', 'every node has an incoming route: no entry node exists')
  }
  if (hasCycle(doc.nodes, routes)) {
    push('warning', '$.routes',
      'the graph contains a cycle; loop members re-activate until their maxActivations budget ends the run')
  }
  const roots = [...nodeIds].filter(id => incoming.get(id) === 0)
  if (roots.length > 1) {
    push('warning', '$', `multiple entry nodes (${roots.join(', ')}) activate in parallel at start`)
  }

  // Board: keys follow artifact-key syntax.
  if (doc.board !== undefined) {
    if (doc.board === null || typeof doc.board !== 'object' || Array.isArray(doc.board)) {
      push('error', '$.board', 'board must be a JSON object of initial facts')
    } else {
      for (const key of Object.keys(doc.board)) {
        if (!ARTIFACT_KEY_PATTERN.test(key)) {
          push('error', `$.board.${key}`, `board key must match ${ARTIFACT_KEY_SOURCE}`)
        }
      }
    }
  }
  return diagnostics
}

const SLUG_PATTERN_SOURCE = String(SLUG_PATTERN)
const ARTIFACT_KEY_PATTERN = /^[a-z0-9][a-z0-9._-]{0,63}(\[[a-z0-9][a-z0-9._-]{0,31}\])?$/
const ARTIFACT_KEY_SOURCE = String(ARTIFACT_KEY_PATTERN)

/** DFS cycle detection over valid edges only. */
function hasCycle(nodes, routes) {
  const adjacency = new Map()
  for (const route of routes) {
    if (typeof route?.from !== 'string' || typeof route?.to !== 'string') continue
    if (!adjacency.has(route.from)) adjacency.set(route.from, [])
    adjacency.get(route.from).push(route.to)
  }
  const visiting = new Set()
  const visited = new Set()
  const walk = (id) => {
    if (visited.has(id) || visiting.has(id)) return visiting.has(id)
    visiting.add(id)
    let cyclic = false
    for (const next of adjacency.get(id) ?? []) cyclic = walk(next) || cyclic
    visiting.delete(id)
    visited.add(id)
    return cyclic
  }
  let cyclic = false
  for (const node of nodes) {
    if (typeof node?.id === 'string') cyclic = walk(node.id) || cyclic
  }
  return cyclic
}

/**
 * Canonical form of a draft: nodes sorted by id, routes sorted by signature,
 * unknown fields dropped. The canonical document is what gets hashed, stored,
 * and executed 鈥?authoring-order noise cannot change behavior or identity.
 */
export function canonicalizeFlow(doc) {
  const flowModel = typeof doc.model === 'string' ? doc.model.trim() : undefined
  const canonical = {
    name: doc.name,
    description: typeof doc.description === 'string' ? doc.description : '',
    ...(parseModelRef(flowModel) ? { model: flowModel } : {}),
    board: doc.board && typeof doc.board === 'object' && !Array.isArray(doc.board)
      ? doc.board
      : {},
    nodes: [...doc.nodes]
      .map(node => ({
        id: node.id,
        title: typeof node.title === 'string' ? node.title : node.id,
        prompt: typeof node.prompt === 'string' ? node.prompt : '',
        executor: node.executor ?? 'spawn',
        produces: Array.isArray(node.produces) ? [...node.produces].sort() : [],
        verify: node.verify.map(command => (
          Number.isSafeInteger(command.timeoutMs)
            ? { command: command.command, timeoutMs: command.timeoutMs }
            : { command: command.command }
        )),
        maxActivations: Number.isSafeInteger(node.maxActivations) ? node.maxActivations : 3,
        ...(parseModelRef(typeof node.model === 'string' ? node.model.trim() : undefined)
          ? { model: node.model.trim() }
          : {}),
      }))
      .sort((left, right) => left.id < right.id ? -1 : left.id > right.id ? 1 : 0),
    routes: [...(Array.isArray(doc.routes) ? doc.routes : [])]
      .map(route => ({
        from: route.from,
        to: route.to,
        kind: route.kind ?? 'on_success',
        ...(isValidPredicate(route.when) ? { when: route.when } : {}),
        ...(typeof route.forEach === 'string' ? { forEach: route.forEach } : {}),
      }))
      .sort((left, right) => routeSignature(left) < routeSignature(right) ? -1 : 1),
  }
  return canonical
}

/** Lock identity pair derived from canonical bytes. */
export function identityOf(canonical) {
  const bytes = stableStringify(canonical)
  const digest = sha256Hex(bytes)
  return { bytes, contentHash: `sha256:${digest}`, lockId: `flk_${digest.slice(0, 16)}` }
}

/** Re-verify a stored lock document; returns the reason string when invalid. */
export function lockTamperReason(lockDoc) {
  if (lockDoc === null || typeof lockDoc !== 'object') return 'lock document missing'
  const { flow, diagnostics, lockId, contentHash } = lockDoc
  if (!flow || !lockId || !contentHash) return 'lock document missing required fields'
  const identity = identityOf(flow)
  if (identity.lockId !== lockId) return `lock id mismatch (stored ${lockId}, computed ${identity.lockId})`
  if (identity.contentHash !== contentHash) return `content hash mismatch (stored ${contentHash})`
  if (Array.isArray(diagnostics) && diagnostics.some(entry => entry?.severity === 'error')) {
    return 'stored lock still carries error diagnostics'
  }
  return undefined
}

/** Split an artifact key into base and optional fanout index ("k[3]" 鈫?["k","3"]). */
export function splitArtifactKey(key) {
  const match = /^([a-z0-9][a-z0-9._-]{0,63})(?:\[([a-z0-9][a-z0-9._-]{0,31})\])?$/.exec(key)
  if (!match) return [key, undefined]
  return [match[1], match[2]]
}
