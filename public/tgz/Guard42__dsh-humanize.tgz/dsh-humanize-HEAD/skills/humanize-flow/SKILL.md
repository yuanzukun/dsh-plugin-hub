---
name: humanize-flow
description: Author, review, run, and resume Humanize flows — stage graphs whose stages carry referee verification commands. Use when an objective spans multiple verifiable stages, must survive interruption, or should be reviewed before execution. Trigger on "flow", long multi-step builds/refactors/audits, or when the user wants checked and reviewed execution.
---

# Humanize flows — we build the flow around the agent

A flow is a declarative stage graph. Each stage pairs agent instructions
(`prompt`) with a **referee**: shell commands whose exit code decides whether
the stage counts. "Lean accepts it, or it does not" — success is never
self-reported; it is verified.

## The lifecycle

```
flow_draft → flow_check → flow_lock → flow_review_prepare → (user decides)
           → flow_review_decide → flow_run → flow_status … → trace_export
                                     └→ flow_resume (after any interruption)
```

1. **flow_draft** — write the COMPLETE flow document (whole-document replace).
2. **flow_check** — structural diagnostics; fix every error before locking.
3. **flow_lock** — canonicalize + SHA-256 → immutable `flk_<digest>` identity.
4. **flow_review_prepare** — HMAC-signed binding + human-readable `review.md`.
5. Show review.md to the user; they own the verdict.
6. **flow_review_decide** — THE single decision tool (`approved` / `rejected`
   / `bypassed`; reject/bypass need a reason). Terminal and immutable.
7. **flow_run** — verify the binding, schedule ready nodes, return a run id.
8. **flow_status** — replay events.jsonl; poll between other work.
9. **flow_resume** — after session end/crash/cancel; finished stages never rerun.
10. **trace_export** — readable timeline (`md`) or Perfetto-importable span trace.

## Document shape

```jsonc
{
  "name": "fix-build",                    // slug
  "description": "Goal + success criteria",
  "board": { "goal": "green build" },     // initial facts for predicates
  "nodes": [
    {
      "id": "implement",
      "title": "Make it compile",
      "prompt": "Complete instructions for this stage's subagent…",
      "executor": "spawn",                // spawn | fork | gate
      "produces": ["build.status"],       // artifacts written on success
      "verify": [{ "command": "pnpm -r build", "timeoutMs": 600000 }],
      "maxActivations": 3                 // loop budget
    },
    {
      "id": "gate-build-green",
      "executor": "gate",                 // referee-only milestone, no agent
      "verify": [{ "command": "node scripts/assert-artifact.js" }]
    }
  ],
  "routes": [
    { "from": "implement", "to": "audit" },
    { "from": "audit",    "to": "fix", "kind": "on_failure" },          // failure path…
    { "from": "fix",      "to": "audit" },                              // …forms a bounded loop
    { "from": "plan",     "to": "execute", "forEach": "plan.items" },   // fanout per element
    { "from": "audit",    "to": "skip", "when": { "exists": "audit.clean" } }
  ]
}
```

### Rules of authorship

- **Referee first.** Pick `verify` commands BEFORE prompts. A stage without an
  honest referee is theater. Prefer commands that already exist in the repo
  (tests, compilers, linters); write a tiny script only when nothing fits.
- **Prompts are complete briefs**, not hints: context, constraints, definition
  of done. The stage's subagent sees the prompt plus current facts, nothing else.
- **Artifacts are the handoff.** A node's final message becomes its artifact
  text verbatim. Downstream nodes read facts via routes; tell authors exactly
  what their artifact must contain (e.g. "a JSON array of file paths").
- **Predicates are two.** `{"exists": key}` or `{"truthy": key}` — presence,
  or non-empty/non-zero truth. No expressions; encode logic in stages.
- **Loops are bounded.** Back-edges are allowed; every loop member needs
  `maxActivations` (default 3) so a flapping referee cannot spin forever.
- **Failure paths are explicit.** Without an `on_failure` route from a failed
  stage, the whole run fails. Route failures into fix-up stages deliberately.
- **Fanout for parallelizable work.** `forEach` over an array artifact expands
  one activation per element (bounded by MAX_FANOUT=64), subject to
  `maxParallel`.
- **Small tasks need no flow.** Two coupled steps? Just do them. Ceremony is
  proportional to work.

## Executor choice

| executor | runs | use for |
|---|---|---|
| `spawn` | fresh subagent (no parent history) | independent implementation/research stages |
| `fork` | subagent seeded with parent history | stages needing conversation context |
| `gate` | referee commands only | milestones, CI-style checks, aggregation |

## Choosing stage models

Agent nodes may pin their own model; precedence is
**node `model` → flow-level `model` → preset config `nodeModelDefault` → the calling session's model**.
Format: `"provider/model"` or bare `"model"` (no whitespace) — e.g. `"deepseek/deepseek-reasoner"`.
Use it to put cheap fast models on mechanical stages (bulk fanout fixes) and stronger models on
design-heavy stages (architecture review). Gate nodes never run an agent, so their `model` is ignored.

**Discover what exists first**: call `model_catalog` (no arguments → provider routes + the session
default; with `{"provider":"<id>"}` → that route's models) before pinning values, so flows only
reference models this deployment can actually call.

Models are frozen into the lock's hash: changing a model means editing the draft and re-locking
(+ re-review) — "the run executes exactly what was reviewed". For A/B comparisons, author two
variants or two parallel nodes instead of trying to swap models mid-run.

```jsonc
{ "name": "migrate", "model": "deepseek/deepseek-chat",   // flow-wide default
  "nodes": [
    { "id": "mechanical-edits", "model": "deepseek/deepseek-chat", "prompt": "…", "verify": [...] },
    { "id": "arch-review",      "model": "deepseek/deepseek-reasoner", "prompt": "…", "verify": [...] }
  ] }
```

## Running and observing

- `flow_run` returns immediately. Poll `flow_status`; report progress to the
  user rather than blocking silently.
- Events are the authority (`runs/<id>/events.jsonl`). Status/snapshots are
  caches. Never trust memory over the log.
- After interruption: `flow_resume`. In-flight activations re-run; settled ones
  do not.
- Stop with `flow_stop`; export evidence with `trace_export` (md for humans,
  chrome-json for [ui.perfetto.dev](https://ui.perfetto.dev)).

## State layout

Everything lives under `<workspace>/.humanize/` (or the configured home root):
`flows/`, `runs/<runId>/{events.jsonl,artifacts/}`, `reviews/frv_<rand>/`,
`review-mac.key`. Flows version-control naturally alongside the code they govern.
