/**
 * dsh-humanize bundle installer bridge.
 *
 * Loaded once per deployment through the bundle's cordis.patch.yml row. On
 * startup it syncs the packaged agent preset (repo root = preset root) into
 * the DSH preset root so `dsh plugin add github:Guard42/dsh-humanize` yields
 * a working「Humanize 模式」preset with zero manual steps.
 *
 * Safety properties:
 *  - never throws (a failed sync warns and leaves the host boot untouched);
 *  - never overwrites user-modified files: a shipped-hash stamp records what
 *    this bundle version installed; files changed since are left as-is;
 *  - honors DSH_HOME and DSH_HUMANIZE_DEST for tests and non-default homes;
 *  - zero npm dependencies (node: builtins only — same red line as the preset).
 *
 * Installer-bridge design follows the precedent set by
 * ChongCyrus/Vibe-Mathematics (dsh-vibe-math).
 */
import { copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

/** Preset files carried by this bundle (repo root = preset root). */
export const MANIFEST = [
  'preset.yml',
  'agent.cordis.yml',
  'humanize.config.json',
  'README.md',
  'plugins/flow-kernel.mjs',
  'plugins/humanize-store.mjs',
  'plugins/tool-flow.mjs',
  'skills/humanize-flow/SKILL.md',
]

const sha256 = (data) => createHash('sha256').update(data).digest('hex')

/** Destination preset directory, honoring the usual overrides. */
export function resolveDestination(env = process.env) {
  if (env.DSH_HUMANIZE_DEST) return env.DSH_HUMANIZE_DEST
  const home = env.DSH_HOME || join(homedir(), '.dsh')
  return join(home, '.agent-presets', 'humanize')
}

function readShippedStamp(dest) {
  try {
    const parsed = JSON.parse(readFileSync(join(dest, '.dsh-humanize-bundle.json'), 'utf8'))
    return parsed.shipped ?? {}
  } catch {
    return {}
  }
}

/**
 * Sync MANIFEST from pkgRoot into dest. Files missing at dest, or still
 * byte-identical to the previously shipped version, are (re)copied; files the
 * user modified since our last shipment are reported in `skipped` untouched.
 * Returns { copied, skipped }.
 */
export function installPreset(pkgRoot, dest = resolveDestination(), log = console) {
  const shipped = readShippedStamp(dest)
  const copiedRel = []
  const skipped = []
  for (const rel of MANIFEST) {
    const from = join(pkgRoot, ...rel.split('/'))
    const to = join(dest, ...rel.split('/'))
    if (!existsSync(from)) {
      skipped.push(`${rel} (missing in bundle)`)
      continue
    }
    mkdirSync(dirname(to), { recursive: true })
    let current = null
    try {
      current = sha256(readFileSync(to))
    } catch {
      current = null
    }
    if (current !== null && shipped[rel] !== undefined && current !== shipped[rel]) {
      skipped.push(`${rel} (user-modified, left untouched)`)
      continue
    }
    copyFileSync(from, to)
    copiedRel.push(rel)
  }
  // Record exactly what this bundle version now ships, so future upgrades can
  // distinguish "still ours" from "user modified".
  try {
    mkdirSync(dest, { recursive: true })
    const shippedNow = {}
    for (const rel of MANIFEST) {
      const from = join(pkgRoot, ...rel.split('/'))
      if (existsSync(from)) shippedNow[rel] = sha256(readFileSync(from))
    }
    writeFileSync(
      join(dest, '.dsh-humanize-bundle.json'),
      JSON.stringify({ installer: 'dsh-humanize', shipped: shippedNow }, null, 2) + '\n',
    )
  } catch (err) {
    log.warn?.(`[dsh-humanize] could not record install stamp: ${err?.message ?? err}`)
  }
  return { copied: copiedRel.length, copiedRel, skipped }
}

export const name = 'humanize-preset-installer'

export function apply() {
  try {
    const pkgRoot = dirname(dirname(fileURLToPath(import.meta.url)))
    const dest = resolveDestination()
    const result = installPreset(pkgRoot, dest)
    if (result.skipped.length > 0) {
      console.warn(`[dsh-humanize] preset synced -> ${dest}; untouched: ${result.skipped.join(', ')}`)
    } else {
      console.log(`[dsh-humanize] preset synced (${result.copied}/${MANIFEST.length}) -> ${dest}`)
    }
  } catch (err) {
    console.warn(`[dsh-humanize] preset auto-install skipped: ${err?.message ?? err}`)
  }
}
