# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.1] - 2026-08-24

### Fixed

- **Sessions no longer become unloadable after using review tools.** The preset no longer writes
  custom `humanize/*` events into the session log (`agent.session.append` in
  `flow_review_prepare` / `flow_review_decide`). The stock harness persistence layer refuses to
  interpret a log containing an event type it does not know unless the envelope carries the
  `ignorable` marker, and that marker is not expressible through the public append API — so any
  session in which a review was prepared or decided failed history load and resume with
  `SessionFormatUnsupportedError`. Review state remains fully file-backed
  (`.humanize/reviews/<id>/prepared.json`, `decision.json`, `review.md`); visibility is carried by
  tool receipts and run event logs, which nothing consumed from the session log anyway.

### Added

- Bundle packaging (`package.json` + `cordis.patch.yml` + `bridge/installer.mjs`):
  installing as a DSH plugin (`dsh plugin --profile <profile> add
  github:Guard42/dsh-humanize`) auto-syncs the preset into the DSH preset root on
  startup; user-modified files are never overwritten on upgrade. Installer-bridge
  design follows the precedent set by ChongCyrus/Vibe-Mathematics.
- Star History section in both READMEs.
## [0.1.0] - 2026-08-24

First public release.

### Added

- Flow kernel (`plugins/flow-kernel.mjs`): pure-function document model, semantic
  canonicalization, SHA-256 lock identity (`flk_<digest>`), structural `flow_check`
  diagnostics and two-form route predicates.
- Persistence service (`plugins/humanize-store.mjs`): drafts, immutable locks,
  HMAC-signed terminal review store, append-only run event logs and artifacts.
- Model tool surface (`plugins/tool-flow.mjs`): 15 tools — `flow_draft`,
  `flow_check`, `flow_lock`, `flow_list`, `flow_show`, `flow_review_prepare`,
  `flow_review_decide`, `flow_run`, `flow_status`, `flow_resume`, `flow_stop`,
  `trace_export`, `edit_anchored`, `hash_file`, `model_catalog` — plus a
  replay-driven scheduler with bounded activation budgets and host-sandboxed
  referee command execution.
- `skills/humanize-flow`: skill teaching the model to author and drive flows
  under the Humanize discipline ("we build the flow around the agent").
- Composition (`agent.cordis.yml`) mounting the runtime inside an isolate realm
  beside the full standard capability set; persona, plan mode, compaction,
  delegation, workflows and goals included.
- One-line installers for Windows PowerShell and macOS/Linux bash with local and
  remote (codeload) modes, per-file SHA256 verification, and `-PresetName` /
  `PRESET_NAME` support to save domain-specialized variants (e.g.
  `humanize-ZZZZ`) side by side with the stock preset.
- `docs/design.md`: porting design spec; `docs/parity.md`: honest
  capability-parity audit against humanize2 / oh-my-humanize / humanize-plugin.
- Bilingual benchmark-grade README (中文 / English) with prominent attribution to
  the humanfia ecosystem and a customization & specialization chapter.
- GitHub Actions CI matrix (ubuntu + windows): smoke tests, composition check,
  docs check.

[0.1.0]: https://github.com/Guard42/dsh-humanize/releases/tag/v0.1.0
