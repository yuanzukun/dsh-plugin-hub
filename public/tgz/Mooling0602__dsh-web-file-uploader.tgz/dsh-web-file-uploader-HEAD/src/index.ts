// dsh-web-file-uploader — static host half (published dsh bundle)
//
// Thin seam over the canonical host core (src/core/host.ts): wires the
// transport (webServer HTTP routes), the filesystem (node:fs), hashing
// (node:crypto) and the attachment/llm services. All business logic lives in
// the core — edit that, not this file.
//
// Uploads are written directly into the DSH home data dir ($DSH_HOME/uploads,
// default ~/.dsh/uploads) with node:fs — the proper dsh data directory,
// bypassing the sandboxed fs abstraction.

import { createHash } from 'node:crypto'
import {
  copyFileSync, createReadStream, createWriteStream, existsSync, mkdirSync, readdirSync,
  readFileSync, renameSync, rmdirSync, statSync, unlinkSync, writeFileSync,
} from 'node:fs'
import { once } from 'node:events'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { createHostCore, errCode, errMsg } from './core/host.js'
import type {
  AttachmentsService, LlmService, PluginContext, PreStepDecision, PreStepPayload, WebServer,
} from './types.js'

export const name = 'dsh-web-file-uploader'

export const inject = ['webServer']

const dshHome = (): string => process.env.DSH_HOME || join(homedir(), '.dsh')

// Retention is persisted in our own JSON file inside the DSH home data dir,
// so the static bundle has NO external dependency on @deepseek-ai/schemastery
// or @deepseek-ai/dsh-settings (which are not resolvable from a local bundle).
const configPath = (): string => join(dshHome(), 'dsh-web-file-uploader.json')

const sanitizeName = (raw: unknown): string | null => {
  const n = String(raw || '').replace(/[\/\\\0]/g, '_').trim()
  if (!n || n === '.' || n === '..' || n.length > 255) return null
  return n
}

const uploadsDir = (): string => {
  const dir = join(dshHome(), 'uploads')
  mkdirSync(dir, { recursive: true })
  return dir
}

const sendJson = (res: ServerResponse, status: number, body: unknown): void => {
  const payload = Buffer.from(JSON.stringify(body), 'utf8')
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': payload.length })
  res.end(payload)
}

export function apply(ctx: PluginContext): void {
  const webServer = ctx.get<WebServer>('webServer')
  const llm = ctx.get<LlmService>('llm')
  const attachments = ctx.get<AttachmentsService>('attachments')
  if (webServer === undefined) return

  // Resolve the plugin config: persisted file > env > default.
  //   ttl              auto-cleanup retention
  //   replaceOfficial  replace the shell's "Add -> File" menu entry with ours
  //   alwaysShowButton keep the standalone composer button visible at all times
  //                    (see src/core/client.ts)
  //   maxFiles         max files one picker selection may upload; 0 = unlimited
  //   foldThreshold    send-time fold threshold; 2..100, default 100
  //   skipLocalUpload  reference Desktop local files instead of uploading
  //                    (default true; Desktop-only feature, off forces upload)
  let runtimeConfig = { ttl: '7d', replaceOfficial: false, alwaysShowButton: true, maxFiles: 100, foldThreshold: 100, skipLocalUpload: true }
  const readConfigFile = (): Record<string, unknown> | null => {
    try {
      const text = existsSync(configPath()) ? readFileSync(configPath(), 'utf8') : ''
      const parsed = text ? JSON.parse(text) : null
      if (parsed && typeof parsed === 'object') return parsed
    } catch {
      // ignore malformed file
    }
    return null
  }
  // Clamp a max-files value: integers only, 0 (unlimited) through a sane ceiling.
  const clampMaxFiles = (raw: unknown): number | undefined => {
    const n = typeof raw === 'number' ? raw : typeof raw === 'string' && raw.trim() !== '' ? Number(raw) : NaN
    if (!Number.isFinite(n)) return undefined
    return Math.max(0, Math.min(10000, Math.floor(n)))
  }
  // Fold threshold: integers only, 2..100 (the hard cap keeps the injected
  // context bounded).
  const clampFoldThreshold = (raw: unknown): number | undefined => {
    const n = typeof raw === 'number' ? raw : typeof raw === 'string' && raw.trim() !== '' ? Number(raw) : NaN
    if (!Number.isFinite(n)) return undefined
    return Math.max(2, Math.min(100, Math.floor(n)))
  }
  const getConfig = (): { ttl: string; replaceOfficial: boolean; alwaysShowButton: boolean; maxFiles: number; foldThreshold: number; skipLocalUpload: boolean } => {
    const fromFile = readConfigFile()
    let ttl = fromFile && typeof fromFile.ttl === 'string' && fromFile.ttl !== '' ? fromFile.ttl : undefined
    if (ttl === undefined && process.env && process.env.DSH_UPLOAD_TTL) ttl = process.env.DSH_UPLOAD_TTL
    if (ttl === undefined) ttl = runtimeConfig.ttl
    const replaceOfficial = fromFile && typeof fromFile.replaceOfficial === 'boolean'
      ? fromFile.replaceOfficial
      : runtimeConfig.replaceOfficial
    const alwaysShowButton = fromFile && typeof fromFile.alwaysShowButton === 'boolean'
      ? fromFile.alwaysShowButton
      : runtimeConfig.alwaysShowButton
    const skipLocalUpload = fromFile && typeof fromFile.skipLocalUpload === 'boolean'
      ? fromFile.skipLocalUpload
      : runtimeConfig.skipLocalUpload
    const maxFiles = clampMaxFiles(fromFile && fromFile.maxFiles) ?? runtimeConfig.maxFiles
    const foldThreshold = clampFoldThreshold(fromFile && fromFile.foldThreshold) ?? runtimeConfig.foldThreshold
    return { ttl, replaceOfficial, alwaysShowButton, maxFiles, foldThreshold, skipLocalUpload }
  }
  // Partial update: a caller that only knows about one field must not clear the
  // other, so the patch is merged over the resolved config.
  const setConfig = (patch: { ttl?: string; replaceOfficial?: boolean; alwaysShowButton?: boolean; maxFiles?: number; foldThreshold?: number; skipLocalUpload?: boolean }): void => {
    const next = getConfig()
    if (patch && patch.ttl != null) next.ttl = String(patch.ttl).trim()
    if (patch && typeof patch.replaceOfficial === 'boolean') next.replaceOfficial = patch.replaceOfficial
    if (patch && typeof patch.alwaysShowButton === 'boolean') next.alwaysShowButton = patch.alwaysShowButton
    if (patch && typeof patch.skipLocalUpload === 'boolean') next.skipLocalUpload = patch.skipLocalUpload
    const clampedMaxFiles = clampMaxFiles(patch ? patch.maxFiles : undefined)
    if (clampedMaxFiles !== undefined) next.maxFiles = clampedMaxFiles
    const clampedFold = clampFoldThreshold(patch ? patch.foldThreshold : undefined)
    if (clampedFold !== undefined) next.foldThreshold = clampedFold
    runtimeConfig = next
    try {
      // A fresh DSH_HOME may not exist yet; the write is the only thing that
      // needs it, so create it here rather than at module load.
      mkdirSync(dirname(configPath()), { recursive: true })
      writeFileSync(configPath(), JSON.stringify(next, null, 2))
    } catch {
      // non-fatal; in-memory value still applies
    }
  }

  const core = createHostCore({
    uploadsRoot: async () => dshHome(),
    // Streaming intake: the request body is written straight through while the
    // route hashes it, so file size is bounded by disk, not by memory.
    ensureDir: async (absDir) => {
      mkdirSync(absDir, { recursive: true })
    },
    hashFile: async (absPath) => {
      try {
        const hash = createHash('sha256')
        for await (const chunk of createReadStream(absPath)) hash.update(chunk)
        return hash.digest('hex')
      } catch {
        return null
      }
    },
    moveFile: async (from, to) => {
      try {
        renameSync(from, to)
        return { ok: true }
      } catch (err) {
        // rename cannot cross filesystems; fall back to copy + unlink.
        if (errCode(err) === 'EXDEV') {
          try {
            copyFileSync(from, to)
            unlinkSync(from)
            return { ok: true }
          } catch (err2) {
            return { ok: false, error: errMsg(err2) }
          }
        }
        return { ok: false, error: errMsg(err) }
      }
    },
    statPath: async (absPath) => {
      try {
        const st = statSync(absPath)
        return { size: st.size, isFile: st.isFile() }
      } catch {
        return null
      }
    },
    readBytes: async (absPath) => readFileSync(absPath),
    readTextFile: async (absPath) => {
      try {
        return existsSync(absPath) ? readFileSync(absPath, 'utf8') : null
      } catch {
        return null
      }
    },
    writeTextFile: async (absPath, content) => {
      mkdirSync(absPath.slice(0, absPath.lastIndexOf('/')), { recursive: true })
      writeFileSync(absPath, content)
    },
    deleteFile: async (absPath) => {
      try {
        unlinkSync(absPath)
        return { ok: true }
      } catch (err) {
        return { ok: false, error: errMsg(err) }
      }
    },
    listUploadRoots: async () => [dshHome()],
    listDir: async (absDir) => {
      try {
        return readdirSync(absDir)
      } catch {
        return null
      }
    },
    removeDir: async (absDir) => {
      try {
        rmdirSync(absDir)
        return true
      } catch {
        return false
      }
    },
    readConfig: getConfig,
    resolveModelInfo: (provider, model, signal) => (llm !== undefined ? llm.resolveModelInfo(provider, model, signal) : Promise.reject(new Error('llm unavailable'))),
    attachmentLimits: () => (attachments !== undefined && attachments.imageLimits ? attachments.imageLimits : null),
    saveImage: (input) => {
      if (attachments === undefined) return Promise.reject(new Error('attachments unavailable'))
      return attachments.saveImage(input)
    },
    probe: () => {},
    log: (...args) => console.log(...args),
  })

  // --- upload route ---------------------------------------------------------

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-web-file-uploader/upload',
    handler: async (req, res) => {
      let staging: string | null = null
      try {
        if (req.method !== 'POST') {
          res.writeHead(405)
          res.end()
          return
        }
        const url = new URL(req.url || '/', 'http://localhost')
        const rawName = sanitizeName(url.searchParams.get('name'))
        const sessionId = url.searchParams.get('session') || ''
        const cardId = url.searchParams.get('id') || ''
        const mime = url.searchParams.get('mime') || ''
        const declared = Number(url.searchParams.get('size')) || 0
        if (!rawName) {
          sendJson(res, 400, { ok: false, error: 'invalid file name' })
          return
        }

        // Streaming intake: the body goes to a staging file as it arrives while
        // the same pass hashes it — no base64, no whole-file buffer, so the only
        // bound left is disk space. commitStream publishes it under its final
        // name, or drops the staged copy when identical content is already
        // stored.
        const begun = await core.beginStream({ sessionId, id: cardId || undefined, name: rawName, mime, size: declared })
        if (!begun.ok) {
          sendJson(res, 400, begun)
          return
        }
        staging = begun.id!
        const hash = createHash('sha256')
        const out = createWriteStream(begun.tempPath!)
        try {
          for await (const chunk of req) {
            hash.update(chunk)
            if (!out.write(chunk)) await once(out, 'drain')
          }
          await new Promise<void>((resolve, reject) => {
            out.end((err?: Error) => (err ? reject(err) : resolve()))
          })
        } catch (err) {
          out.destroy()
          throw err
        }
        const result = await core.commitStream({ id: staging, sha256: hash.digest('hex') })
        staging = null
        sendJson(res, result.ok ? 200 : 400, result)
      } catch (err) {
        // A closed tab or a failed write must not leave a partial file behind.
        if (staging) {
          try {
            await core.abortStream({ id: staging })
          } catch {
            // best effort
          }
        }
        try {
          sendJson(res, 500, { ok: false, error: errMsg(err) })
        } catch {
          // the client is gone; the staged file is already dropped
        }
      }
    },
  }), 'dfu: upload route')

  // --- probe route: client-hashed preflight for an instant upload ------------
  //
  // The browser hashes the picked file locally and asks here first. A hit means
  // the content is already stored, so the reference is registered and the body
  // never travels. The query string carries metadata only; there is no body.

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-web-file-uploader/probe',
    handler: async (req, res) => {
      try {
        if (req.method !== 'POST') {
          res.writeHead(405)
          res.end()
          return
        }
        const url = new URL(req.url || '/', 'http://localhost')
        const result = await core.probeExisting({
          sessionId: url.searchParams.get('session') || '',
          id: url.searchParams.get('id') || '',
          name: url.searchParams.get('name') || '',
          mime: url.searchParams.get('mime') || '',
          size: Number(url.searchParams.get('size')) || 0,
          sha256: url.searchParams.get('sha256') || '',
        })
        // A miss is a normal answer, not a failure: the client uploads instead.
        sendJson(res, result.ok ? 200 : 404, result)
      } catch (err) {
        sendJson(res, 500, { ok: false, error: errMsg(err) })
      }
    },
  }), 'dfu: probe route')

  // --- remove route: called when the user closes an attachment card --------

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-web-file-uploader/remove',
    handler: async (req, res) => {
      try {
        if (req.method !== 'POST') {
          res.writeHead(405)
          res.end()
          return
        }
        const url = new URL(req.url || '/', 'http://localhost')
        const sessionId = url.searchParams.get('session') || ''
        const path = url.searchParams.get('path') || ''
        const cardId = url.searchParams.get('id') || ''
        if (!sessionId || (!path && !cardId)) {
          sendJson(res, 400, { ok: false, error: 'missing session or path' })
          return
        }
        const result = await core.remove({ sessionId, path: path || undefined, id: cardId || undefined })
        sendJson(res, result.ok ? 200 : 400, result)
      } catch (err) {
        sendJson(res, 500, { ok: false, error: errMsg(err) })
      }
    },
  }), 'dfu: remove route (keep file)')

  // --- delete route: trash can button permanently deletes the file --------

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-web-file-uploader/delete',
    handler: async (req, res) => {
      try {
        if (req.method !== 'POST') {
          res.writeHead(405)
          res.end()
          return
        }
        const url = new URL(req.url || '/', 'http://localhost')
        const sessionId = url.searchParams.get('session') || ''
        const path = url.searchParams.get('path') || ''
        const cardId = url.searchParams.get('id') || ''
        if (!sessionId || (!path && !cardId)) {
          sendJson(res, 400, { ok: false, error: 'missing session or path' })
          return
        }
        const result = await core.delete({ sessionId, path: path || undefined, id: cardId || undefined })
        sendJson(res, result.ok ? 200 : 400, result)
      } catch (err) {
        sendJson(res, 500, { ok: false, error: errMsg(err) })
      }
    },
  }), 'dfu: delete route (permanent)')

  // --- local-reference route: Desktop same-machine files, no upload --------
  // The Desktop shell resolves a picked file's real absolute path; with the
  // session running full access the composer registers it here instead of
  // uploading bytes. Only loopback callers may use it: the path belongs to the
  // same machine as the host (a remote page could name paths it cannot see).
  // The host stats the file, never copies it, and never deletes it.

  const isLoopbackRequest = (req: IncomingMessage): boolean => {
    const address = req.socket && req.socket.remoteAddress ? String(req.socket.remoteAddress) : ''
    return address === '' || address === '::1' || address === '::ffff:127.0.0.1' || address === '127.0.0.1'
  }

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-web-file-uploader/local',
    handler: async (req, res) => {
      try {
        if (req.method !== 'POST') {
          res.writeHead(405)
          res.end()
          return
        }
        if (!isLoopbackRequest(req)) {
          sendJson(res, 403, { ok: false, error: 'local references are only available from the host machine' })
          return
        }
        let body = ''
        for await (const chunk of req) body += chunk
        let parsed: Record<string, unknown> = {}
        try {
          parsed = JSON.parse(body || '{}')
        } catch {
          parsed = {}
        }
        const sessionId = typeof parsed.sessionId === 'string' ? parsed.sessionId : ''
        if (!sessionId) {
          sendJson(res, 400, { ok: false, error: 'missing session' })
          return
        }
        const cards: Array<{ id?: string; name?: string; mime?: string; size?: number; path: string }> = []
        const rawCards = Array.isArray(parsed.cards) ? parsed.cards : []
        for (const raw of rawCards) {
          if (!raw || typeof raw !== 'object') continue
          const item = raw as Record<string, unknown>
          const cardPath = typeof item.path === 'string' ? item.path : ''
          if (!cardPath) continue
          cards.push({
            id: typeof item.id === 'string' && item.id !== '' ? item.id : undefined,
            name: typeof item.name === 'string' ? item.name : undefined,
            mime: typeof item.mime === 'string' ? item.mime : undefined,
            size: Number.isFinite(Number(item.size)) ? Number(item.size) : undefined,
            path: cardPath,
          })
        }
        if (cards.length === 0) {
          sendJson(res, 400, { ok: false, error: 'no cards given' })
          return
        }
        const result = await core.registerLocal({ sessionId, cards })
        sendJson(res, result.ok ? 200 : 400, result)
      } catch (err) {
        sendJson(res, 500, { ok: false, error: errMsg(err) })
      }
    },
  }), 'dfu: local-reference route')

  // --- card-restore routes: the composer after a page reload ----------------
  // The composer keeps its attachment cards in client memory, so a reload drops
  // every card while this host still holds the references and keeps injecting
  // them into later messages. The client asks for them on mount and rebuilds
  // the cards, so the screen and the host agree again.

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-web-file-uploader/pending',
    handler: async (req, res) => {
      try {
        if (req.method !== 'GET') {
          res.writeHead(405)
          res.end()
          return
        }
        const url = new URL(req.url || '/', 'http://localhost')
        const sessionId = url.searchParams.get('session') || ''
        if (!sessionId) {
          sendJson(res, 400, { ok: false, error: 'missing session' })
          return
        }
        const rows = await core.pendingFor(sessionId)
        sendJson(res, 200, { ok: true, rows: rows })
      } catch (err) {
        sendJson(res, 500, { ok: false, error: errMsg(err) })
      }
    },
  }), 'dfu: pending route (restore composer cards)')

  // Thumbnails for restored cards. A live card streams its preview from the
  // picked File (a blob URL); after a reload that File is gone, so the pixels
  // come from the stored copy instead. Only a still-referenced path under an
  // upload root is served — the route never becomes a generic file reader.
  const thumbTypes: Record<string, string> = {
    png: 'image/png',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    webp: 'image/webp',
    gif: 'image/gif',
  }
  const MAX_THUMB_BYTES = 32 * 1024 * 1024

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-web-file-uploader/thumb',
    handler: async (req, res) => {
      try {
        if (req.method !== 'GET') {
          res.writeHead(405)
          res.end()
          return
        }
        const url = new URL(req.url || '/', 'http://localhost')
        const sessionId = url.searchParams.get('session') || ''
        const rawPath = url.searchParams.get('path') || ''
        if (!sessionId || !rawPath) {
          sendJson(res, 400, { ok: false, error: 'missing session or path' })
          return
        }
        const ext = rawPath.slice(rawPath.lastIndexOf('.') + 1).toLowerCase()
        const type = thumbTypes[ext]
        if (!type) {
          sendJson(res, 415, { ok: false, error: 'not a thumbnail-capable image' })
          return
        }
        // The path must still be live for THIS session and sit inside an upload
        // root, so a crafted query cannot read arbitrary files through here.
        const rows = await core.pendingFor(sessionId)
        if (!rows.some((r) => r.path === rawPath && r.exists)) {
          sendJson(res, 404, { ok: false, error: 'not referenced by this session' })
          return
        }
        const roots = [(dshHome() + '/uploads')]
        const inside = roots.some((root) => rawPath.indexOf(root + '/') === 0)
        if (!inside) {
          sendJson(res, 403, { ok: false, error: 'path outside the upload root' })
          return
        }
        const info = statSync(rawPath)
        if (!info.isFile()) {
          sendJson(res, 404, { ok: false, error: 'not a file' })
          return
        }
        if (info.size > MAX_THUMB_BYTES) {
          sendJson(res, 413, { ok: false, error: 'image too large for a thumbnail' })
          return
        }
        const bytes = readFileSync(rawPath)
        res.writeHead(200, {
          'content-type': type,
          'content-length': bytes.length,
          'cache-control': 'no-store',
        })
        res.end(bytes)
      } catch (err) {
        sendJson(res, 500, { ok: false, error: errMsg(err) })
      }
    },
  }), 'dfu: thumb route (restored card previews)')

  // --- list / delete-many routes: the settings "manage files" panel ---------

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-web-file-uploader/files',
    handler: async (req, res) => {
      try {
        if (req.method !== 'GET') {
          res.writeHead(405)
          res.end()
          return
        }
        const result = await core.list()
        sendJson(res, 200, result)
      } catch (err) {
        sendJson(res, 500, { ok: false, error: errMsg(err) })
      }
    },
  }), 'dfu: list route')

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-web-file-uploader/delete-many',
    handler: async (req, res) => {
      try {
        if (req.method !== 'POST') {
          res.writeHead(405)
          res.end()
          return
        }
        let body = ''
        for await (const chunk of req) body += chunk
        let parsed: Record<string, unknown> = {}
        try {
          parsed = JSON.parse(body || '{}')
        } catch {
          parsed = {}
        }
        const paths = Array.isArray(parsed.paths) ? parsed.paths.filter((p): p is string => typeof p === 'string' && !!p) : []
        if (paths.length === 0) {
          sendJson(res, 400, { ok: false, error: 'no paths given' })
          return
        }
        const sessionId = typeof parsed.sessionId === 'string' ? parsed.sessionId : ''
        const result = await core.deleteMany({ sessionId, paths })
        sendJson(res, result.ok ? 200 : 400, result)
      } catch (err) {
        sendJson(res, 500, { ok: false, error: errMsg(err) })
      }
    },
  }), 'dfu: delete-many route')

  // --- config route: settings UI reads / updates retention -----------------

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-web-file-uploader/config',
    handler: async (req, res) => {
      try {
        if (req.method !== 'GET' && req.method !== 'POST') {
          res.writeHead(405)
          res.end()
          return
        }
        const url = new URL(req.url || '/', 'http://localhost')
        const action = url.searchParams.get('action')
        if (action === 'get') {
          sendJson(res, 200, getConfig())
          return
        }
        if (action === 'set' && req.method === 'POST') {
          let body = ''
          for await (const chunk of req) {
            body += chunk
          }
          let parsed: Record<string, unknown> = {}
          try {
            parsed = JSON.parse(body || '{}')
          } catch {
            parsed = {}
          }
          const patch: { ttl?: string; replaceOfficial?: boolean; alwaysShowButton?: boolean; maxFiles?: number; foldThreshold?: number; skipLocalUpload?: boolean } = {}
          if (parsed.ttl != null) patch.ttl = String(parsed.ttl)
          if (typeof parsed.replaceOfficial === 'boolean') patch.replaceOfficial = parsed.replaceOfficial
          if (typeof parsed.alwaysShowButton === 'boolean') patch.alwaysShowButton = parsed.alwaysShowButton
          if (typeof parsed.skipLocalUpload === 'boolean') patch.skipLocalUpload = parsed.skipLocalUpload
          if (parsed.maxFiles != null) {
            const clamped = clampMaxFiles(parsed.maxFiles)
            if (clamped !== undefined) patch.maxFiles = clamped
          }
          if (parsed.foldThreshold != null) {
            const clamped = clampFoldThreshold(parsed.foldThreshold)
            if (clamped !== undefined) patch.foldThreshold = clamped
          }
          setConfig(patch)
          sendJson(res, 200, getConfig())
          return
        }
        sendJson(res, 400, { ok: false, error: 'bad action' })
      } catch (err) {
        sendJson(res, 500, { ok: false, error: errMsg(err) })
      }
    },
  }), 'dfu: config route')

  // --- pre-step injection ---------------------------------------------------

  ctx.on('agent/pre-step', (payload, next) =>
    core.preStep(payload as PreStepPayload, next as () => Promise<PreStepDecision>),
  )

  // Startup sweep over $DSH_HOME/uploads.
  try {
    core.collect()
  } catch {
    // non-fatal
  }
}
