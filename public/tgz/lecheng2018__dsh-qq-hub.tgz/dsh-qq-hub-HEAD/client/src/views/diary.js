import { useState, useEffect, Fragment, h } from '../core/react.js'
import { Card, Row, Btn, Select, Empty, ModOff, More } from '../ui/primitives.js'
import { useField } from '../ui/form.js'
import { setPath, timeAgo, cx } from '../core/utils.js'
import { get, post } from '../core/http.js'
import { modOn } from '../domain/nav.js'

const AUDIENCE_OPTIONS = [
  { value: 'all', label: '所有人可见' },
  { value: 'friends', label: '好友可见' },
  { value: 'selected', label: '部分好友可见' },
  { value: 'excluded', label: '部分好友不可见' },
  { value: 'self', label: '仅自己可见' },
]
const AUDIENCE_LABEL = Object.fromEntries(AUDIENCE_OPTIONS.map((o) => [o.value, o.label]))

/**
 * 日记素材来源：逐个会话显式授权（审计 S07）。
 * 过去无条件下「所有非 system 会话」的当天流水都进素材，私聊内容会被改写成
 * 第一人称说说发到空间。现在默认空 = 只写她自己的事，勾选才引用。
 */
function DiarySources({ draft, setDraft }) {
  const picked = new Set((draft.diary.includeChats || []).map(String))
  const [known, setKnown] = useState(null)
  useEffect(() => {
    get('/panel/chats').then((r) => { if (r.ok) setKnown(r.chats || []) }).catch(() => setKnown([]))
  }, [])
  // 候选：白名单群 + 聊过天的会话（含私聊）。名字能取到就显示名字。
  const nameOf = (cid) => {
    const hit = (known || []).find((c) => String(c.chatId) === cid)
    if (!hit) return cid
    const raw = String(hit.name || '').replace(/^QQ 群 · /, '')
    return raw && raw !== hit.id ? `${raw}（${cid}）` : cid
  }
  const candidates = Array.from(new Set([
    ...(draft.allow.groups || []).map((g) => `group:${g}`),
    ...(known || []).map((c) => String(c.chatId)),
    ...picked,
  ])).sort()
  const toggle = (cid) => {
    const next = new Set(picked)
    if (next.has(cid)) next.delete(cid)
    else next.add(cid)
    setDraft(setPath(draft, 'diary.includeChats', Array.from(next)))
  }
  return (
    <Row
      label="素材来源"
      hint="勾选哪些聊天的内容可以进日记素材。不勾选 = 日记只写她自己的事（今天画了什么、在想什么），不引用任何聊天记录。配图同理：她自己画的永远可用，别人会话里收的表情要在对应聊天勾选后才会被配上。"
    >
      {candidates.length
        ? <div className="ab-flex" style={{ flexWrap: 'wrap' }}>
          {candidates.map((cid) => (
            <button key={cid} type="button" className={cx('ab-chip', picked.has(cid) && 'on')} onClick={() => toggle(cid)}>
              {(picked.has(cid) ? '✓ ' : '') + nameOf(cid)}
            </button>
          ))}
        </div>
        : <span className="ab-muted ab-small">还没有聊过天的会话；先在「权限」页把群加进白名单。</span>}
      {picked.size === 0
        ? <div className="ab-note ab-small" style={{ marginTop: 6 }}>当前不引用任何聊天：日记只写她自己的事。</div>
        : null}
    </Row>
  )
}

/** 可见范围：固定范围存进配置；部分好友再配一份 QQ 名单。 */
function DiaryAudience({ draft, setDraft, toast }) {
  const mode = draft.diary.visibility
  const partial = mode === 'selected' || mode === 'excluded'
  const [friends, setFriends] = useState(null)
  const [query, setQuery] = useState('')
  const qqText = draft.diary.audienceQQs || ''
  const selected = Array.from(new Set(String(qqText).split(/[\s,，;；]+/).filter(Boolean)))
  const setList = (list) => setDraft(setPath(draft, 'diary.audienceQQs', Array.from(new Set(list)).join('\n')))
  const toggle = (qq) => setList(selected.includes(qq) ? selected.filter((q) => q !== qq) : [...selected, qq])
  return (
    <div>
      <Row label="谁能看" hint="和 QQ 空间的可见范围一致">
        <Select value={mode} options={AUDIENCE_OPTIONS} width={170} onChange={(v) => setDraft(setPath(draft, 'diary.visibility', v))} />
      </Row>
      {partial ? (
        <div style={{ marginTop: 10 }}>
          <div className="ab-flex" style={{ gap: 8, marginBottom: 8 }}>
            <Btn
              small kind="ghost"
              onClick={async () => { try { const r = await get('/diary/friends'); if (!r.ok) return toast(r.message || '读取好友失败'); setFriends(r.friends) } catch (e) { toast(e.message) } }}
            >
              从好友列表选择
            </Btn>
            <span className="ab-muted ab-small">已选 {selected.length} 人，只对之后发的说说生效</span>
          </div>
          {friends ? (
            <div style={{ marginBottom: 8 }}>
              <input className="ab-input" placeholder="搜索昵称或 QQ 号" value={query} onChange={(e) => setQuery(e.target.value)} />
              <div style={{ maxHeight: 220, overflow: 'auto', marginTop: 6 }}>
                {friends.filter((f) => (f.name + f.qq).toLowerCase().includes(query.toLowerCase())).map((f) => (
                  <label key={f.qq} style={{ display: 'block', padding: '4px 2px' }}>
                    <input type="checkbox" checked={selected.includes(f.qq)} onChange={() => toggle(f.qq)} />
                    {' ' + (f.name || '（无备注）') + '（' + f.qq + '）'}
                  </label>
                ))}
              </div>
            </div>
          ) : null}
          <textarea
            className="ab-textarea" style={{ minHeight: 64 }} placeholder="也可以直接填 QQ 号，一行一个"
            value={qqText} onChange={(e) => setDraft(setPath(draft, 'diary.audienceQQs', e.target.value))}
          />
          <div className="ab-small ab-muted" style={{ marginTop: 6 }}>{mode === 'selected' ? '名单为空时不会发布，也不会退回公开。' : '这些好友看不到之后的说说。'}</div>
        </div>
      ) : null}
    </div>
  )
}

function Diary({ st, draft, setDraft, toast }) {
  const f = useField(draft, setDraft)
  const [data, setData] = useState(null)
  const on = modOn(st, 'diary')
  const load = () => (on ? get('/diary/history').then((r) => { setData(r); if (r.warning) toast(r.warning) }).catch((e) => toast('日记状态刷新失败：' + e.message)) : null)
  useEffect(() => { load() }, [on])
  const social = modOn(st, 'qzone-social') ? <QzoneSocial draft={draft} setDraft={setDraft} toast={toast} /> : <ModOff name="空间互动" />
  if (!on) return <div className="ab-grid"><ModOff name="空间日记" />{social}</div>
  return (
    <div className="ab-grid">
      <Card
        title="空间日记" right={f.sw('diary.enabled')}
        desc="她每天会在 QQ 空间发几条说说，结合当天聊过的事，用自己的口吻写。写日记那一轮不会发到聊天里。"
      >
        <Row label="每天写几次">{f.num('diary.timesPerDay', { min: 0, max: 6 })}</Row>
        <Row label="时间段" hint="在这段时间里随机挑时间">
          {f.text('diary.windowStart', { size: 'sm' })}<span className="ab-muted">到</span>{f.text('diary.windowEnd', { size: 'sm' })}
        </Row>
        <Row label="两篇至少隔">{f.num('diary.minGapMinutes', { min: 0 })}<span className="ab-muted">分钟</span></Row>
        <Row label="字数">{f.num('diary.minChars', { min: 10 })}<span className="ab-muted">到</span>{f.num('diary.maxChars', { min: 20 })}<span className="ab-muted">字</span></Row>
        <Row label="日记配图" hint="开着时每篇会从「今天她画的图 / 今天收的表情包」里挑一张配上去；没有合适的就只发文字">{f.sw('diary.attachImage')}</Row>
        <DiarySources draft={draft} setDraft={setDraft} />
        <DiaryAudience draft={draft} setDraft={setDraft} toast={toast} />
      </Card>
      <Card
        title="写过的日记"
        right={(
          <div className="ab-flex">
            {data && data.next ? <span className="ab-muted ab-small">下一篇大约 {data.next}</span> : null}
            <Btn small kind="ghost" title="刷新空间状态" onClick={load}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="M20 7v5h-5M4 17v-5h5M6.1 7a7 7 0 0 1 11.6-1L20 9M4 15l2.3 3A7 7 0 0 0 17.9 17" /></svg>
            </Btn>
            <Btn small kind="primary" onClick={async () => { toast('她在写了…'); try { const r = await post('/diary/run', {}); toast(r.ok ? (r.dryRun ? '写好了（试运行，没真发）' : '发出去了') : r.message) } catch (e) { toast(e.message) } finally { await load() } }}>现在写一篇</Btn>
          </div>
        )}
      >
        {!data
          ? <Empty icon="⏳" text="加载中…" />
          : !data.items || data.items.length === 0
            ? <Empty icon="📔" text="还没写过日记。" />
            : (
              <div className="ab-list">
                {data.items.map((d, i) => (
                  <div key={i} className="ab-li">
                    <div className="meta">{new Date(d.at).toLocaleString()}<br />{d.deletedAt ? '已从空间删除' : d.dryRun ? '试运行' : d.ok ? (AUDIENCE_LABEL[d.visibility] || '已发布') : '失败'}</div>
                    <div className="body">{d.text}{d.error ? <div className="ab-small" style={{ color: 'var(--ab-err)' }}>{d.error}</div> : null}</div>
                    {d.tid && !d.deletedAt ? (
                      <Btn
                        small kind="ghost"
                        onClick={async () => {
                          if (!confirm('从 QQ 空间删除这条说说？')) return
                          try { const r = await post('/qzone/delete', { tid: d.tid }); toast(r.message) } catch (e) { toast(e.message) } finally { await load() }
                        }}
                      >
                        从空间删除
                      </Btn>
                    ) : null}
                  </div>
                ))}
              </div>
            )}
      </Card>
      {social}
    </div>
  )
}

const SOCIAL_KIND = { reply: '回复评论', comment: '评论', like: '点赞' }

/** 空间互动：回复自己说说下的评论、逛好友动态。 */
function QzoneSocial({ draft, setDraft, toast }) {
  const f = useField(draft, setDraft)
  const [s, setS] = useState(null)
  const load = () => get('/qzone/social/state').then(setS)
  useEffect(() => { load() }, [])
  return (
    <Card
      title="空间互动" right={f.sw('qzoneSocial.enabled')}
      desc="她会定期逛 QQ 空间：有人评论她的说说就回一句；刷到好友的说说，偶尔点个赞、评一句（你的说说她更爱评）。评论按她的人格现写；试运行时只记日志不发。"
    >
      <Row label="回复自己说说下的评论">{f.sw('qzoneSocial.replyOwn')}</Row>
      <Row label="评论好友的说说">{f.sw('qzoneSocial.commentFriends')}</Row>
      <Row label="顺手点赞">{f.sw('qzoneSocial.like')}</Row>
      <Row label="好友说说互动概率" hint="每条说说只判断一次">{f.percent('qzoneSocial.friendChance')}</Row>
      <Row label="你的说说互动概率">{f.percent('qzoneSocial.ownerChance')}</Row>
      <Row label="每天最多评论" hint="点赞不算">{f.range('qzoneSocial.maxPerDay', 0, 30, 1, (v) => v + ' 条')}</Row>
      <Row label="多久逛一次" hint="只在「主动搭话」里设的醒着时间内">{f.range('qzoneSocial.intervalMin', 10, 240, 10, (v) => v + ' 分钟')}</Row>
      <div className="ab-flex" style={{ marginTop: 10 }}>
        <span className="ab-muted ab-small">{s ? '今天评论了 ' + s.count + ' 条' + (s.lastRun ? '，上次逛是 ' + timeAgo(s.lastRun) : '') : ''}</span>
        <div className="ab-spacer" />
        <Btn small onClick={async () => { toast('她去逛空间了…'); const r = await post('/qzone/social/run'); toast(r.message, r.ok ? 'ok' : 'err'); load() }}>现在逛一次</Btn>
      </div>
      {s && s.history && s.history.length ? (
        <div className="ab-list" style={{ marginTop: 10 }}>
          {s.history.map((x, i) => (
            <div key={i} className="ab-li">
              <div className="meta">{timeAgo(x.at)}<br />{SOCIAL_KIND[x.kind] || x.kind}</div>
              <div className="body"><b>{x.who}</b>{x.post ? <span className="ab-muted"> 的「{x.post}」</span> : null}{x.text ? <div>{x.text}</div> : null}</div>
            </div>
          ))}
        </div>
      ) : null}
    </Card>
  )
}

export { Diary, DiaryAudience, QzoneSocial, AUDIENCE_OPTIONS, AUDIENCE_LABEL, SOCIAL_KIND }
