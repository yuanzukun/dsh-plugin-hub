import { askModel } from '../core/llm.js'
import { readChatLogSource } from '../chat/chat-log.js'
import { createMemoryExtractor } from './memory-extractor.js'
import { similarity, whenText } from './memory-core.js'
import { createMemoryReflection } from './memory-reflection.js'
import { createMemoryStyle } from './memory-style.js'
import { createMemoryDistillHistory } from './memory-distill-history.js'

export function createMemoryLearning({
  dsh, getConfig, hub, chatLog = hub, log, personaText, onDistillLearned,
  isActive, createGenerationSignal, generationOf,
  load, save, health, relatedTo,
  add, revise, supersede, scopeFromChatId,
  profileOf, setDerivedProfile, profileKeyOf,
  insightsOf, setDerivedInsights, styleOf, setDerivedStyle, personKey,
  distillOf, putDistill, reflectImpl, styleImpl, distillImpl,
}) {
  const sourceLog = chatLog?.listDays ? chatLog : { listDays: () => hub?.chatLogDays?.() || [], readDay: (day) => hub?.chatLogOf?.(day) || [] }
  const chatLogDays = () => sourceLog.listDays()
  const chatLogSnapshot = (day) => readChatLogSource(sourceLog, day)
  let batchRecoveryError = ''

  /** 导入旧档案第一步：让模型从一大段文字里挑出值得记的，返回候选（不直接存）。 */
  async function importCandidates(text) {
    const task = generationOf(null)
    const genSignal = task.signal
    try {
      const src = String(text || '').trim()
      if (!src) return []
      const chunks = []
      for (let i = 0; i < src.length && chunks.length < 6; i += 5000) chunks.push(src.slice(i, i + 5000))
      const out = []
      for (const part of chunks) {
        const r = await askModel(dsh, {
          cfg: getConfig(),
          system: '你帮一个叫「大肥鱼」的聊天角色从旧档案（设定、聊天笔记、以前的记忆文件）里挑出值得长期记住的事：别人的名字/称呼、喜好、身份、约定、重要经历、和她的关系。不要记她自己的人设和外貌（那些在人格里），不要记无关的说明文字。每条一句话、主语写清楚。只输出 JSON 数组，例如 [{"text":"小明喜欢吃辣","about":"小明","importance":0.6}]。',
          text: part,
          maxTokens: 2500,
          temperature: 0.2,
          signal: genSignal.signal,
        })
        const m = String(r).match(/\[[\s\S]*\]/)
        try { for (const x of m ? JSON.parse(m[0]) : []) if (x && x.text) out.push({ text: String(x.text).slice(0, 200), aboutName: String(x.about || ''), importance: Math.max(0, Math.min(1, Number(x.importance) || 0.5)) }) } catch (error) {}
      }
      const have = load().items
      const uniq = []
      for (const c of out) if (!have.some((m) => similarity(m.text, c.text) >= 0.6) && !uniq.some((u) => similarity(u.text, c.text) >= 0.6)) uniq.push(c)
      return uniq.slice(0, 80)
    } catch (error) {
      if (!genSignal.isValid()) return []
      throw error
    } finally {
      task.cleanup()
    }
  }


  /** 按这个人的记忆重写小档案（记忆少于 3 条的不写）。scope 限定只用哪个作用域的记忆来写。 */
  async function buildProfile(qq, scope = '', genSignal = null) {
    const task = generationOf(genSignal)
    genSignal = task.signal
    try {
      if (!isActive()) return false
      if (genSignal && !genSignal.isValid()) return false
    const cfg = getConfig()
    // 只用「这个作用域自己的」记忆写档案。
    // 以前还会把 global 记忆也喂进来（`|| scope === 'global'`），后果是：
    // 在陌生群里给主人写档案时，会把主人私聊里的私事混进去，提炼成一条 global 档案，
    // 于是「私事 → global → 哪里都能读」—— 等于绕过了所有隔离。
    // global 档案该由 global 自己那条线维护，不该由别的聊天代写。
    // scope 为空必须拒绝（fail-closed）：兜不住空 scope 就退化成全库，跨域污染重演。
    if (!String(scope || '').trim()) throw new Error('没说清用哪个作用域的记忆（private:/group:/global），拒绝重写')
    const sourceState = load()
    const sourceRev = sourceState.rev || 0
    const mine = sourceState.items
      .filter((m) => !m.invalidAt && String(m.about) === String(qq))
      .filter((m) => String(m.scope || '') === String(scope))
      .sort((a, b) => a.at - b.at)
    if (mine.length < 3) return false
    const name = mine.filter((m) => m.aboutName).at(-1)?.aboutName || ''
    const old = profileOf(qq, scope)?.text || ''
    let out = ''
    try {
      out = await askModel(dsh, {
        cfg,
        system: '你是「大肥鱼」。根据你记得的关于一个人的事，写一张给自己看的人物小档案：TA 是谁、怎么称呼、和你什么关系、性格和喜好、最近在忙什么。只写记忆里明确有的，不要推测性格、不要编，也不要写「应该」「可能」这种猜的话；旧档案和新记忆矛盾时以新记忆为准。用第三人称，一段话，100 字以内，不要标题和列表。',
        text: `${String(qq) === String(cfg.ownerQQ) ? `这是你的${cfg.ownerName || '主人'}。\n` : ''}旧档案：${old || '（还没有）'}\n\n记得的事（越往下越新）：\n${mine.slice(-40).map((m) => `- [${whenText(m.at)}] ${m.text}`).join('\n')}`,
        maxTokens: 1500,
        temperature: 0.3,
        signal: genSignal?.signal,
      })
    } catch (err) {
      if (genSignal && !genSignal.isValid()) return false
      throw err
    }
    if (!isActive() || (genSignal && !genSignal.isValid())) return false
    const text = String(out || '').trim().replace(/^[「"]|[」"]$/g, '')
    if (!text) throw new Error('模型没写出东西，等会儿再试')
      return setDerivedProfile(qq, text, name, scope, mine, sourceRev)
    } finally {
      task.cleanup()
    }
  }


  const defaultDistillHistory = createMemoryDistillHistory({
    dsh, getConfig, hub, chatLog, log, onDistillLearned,
    distillOf, putDistill, createGenerationSignal, generationOf, isActive,
  })
  function distillHistory(options) {
    return distillImpl?.history ? distillImpl.history(options) : defaultDistillHistory.history(options)
  }
  function learnDistillFromHistory(options) {
    return distillImpl?.learn ? distillImpl.learn(options) : defaultDistillHistory.learnFromHistory(options)
  }

  const defaultStyle = createMemoryStyle({
    dsh, getConfig, personaText, log,
    styles: () => load().styles || {}, styleOf, setDerivedStyle,
    createGenerationSignal, generationOf, isActive,
  })
  const defaultReflection = createMemoryReflection({
    dsh, getConfig, personaText, log,
    insightsOf, setDerivedInsights, styleOf,
    setStyle: (key, list, { sourceFingerprint }) => defaultStyle.noteStyle(key, list, sourceFingerprint),
    createGenerationSignal, generationOf, isActive,
  })
  function reflect(chat, transcript, genSignal = null) {
    return reflectImpl ? reflectImpl(chat, transcript, genSignal) : defaultReflection.reflect(chat, transcript, genSignal)
  }

  function commitExtracted(x, { chatId, cfg, known, about }) {
    const op = String(x.op || 'add')
    const target = known.get(String(x.id || '').replace(/^#/, ''))
    if (op === 'update' && target && target.source !== 'panel') return revise(target.id, x.text, x.importance)
    if (op === 'outdated' && target) {
      return supersede({
        oldId: target.id,
        text: x.text,
        aboutName: x.about || target.aboutName || '',
        about: about || target.about || '',
        importance: x.importance ?? target.importance ?? 0.5,
        source: 'auto',
        chatId,
        scope: scopeFromChatId(chatId),
        evidence: x.evidence,
        entity: x.entity,
        topic: x.topic,
      }).ok
    }
    const tags = Array.isArray(x.tags) ? x.tags.map((tag) => String(tag).slice(0, 8)).slice(0, 2) : []
    const result = add({
      text: x.text,
      aboutName: x.about || '',
      about,
      tags,
      importance: x.importance ?? 0.5,
      source: 'auto',
      chatId,
      scope: scopeFromChatId(chatId),
      evidence: x.evidence,
      entity: x.entity,
      topic: x.topic,
    })
    return result.ok && (result.id || result.updated)
  }

  const batchState = {
    get: (id) => load().extractionBatches?.[id],
    start: (batch, scope) => {
      const state = load()
      state.extractionBatches = { ...(state.extractionBatches || {}) }
      state.extractionBatches[batch.id] = { fingerprint: batch.fingerprint, scope, status: 'running', added: 0, at: Date.now() }
      try { save(state) } catch (error) {
        batchRecoveryError = `提炼批次 ${batch.id} 无法记录运行状态，自动整理已暂停：${error.message}`
        throw error
      }
    },
    fail: (batch, scope, error) => {
      const state = load()
      state.extractionBatches = { ...(state.extractionBatches || {}) }
      state.extractionBatches[batch.id] = {
        fingerprint: batch.fingerprint,
        scope,
        status: error.factsCommitted ? 'pending' : 'failed',
        added: Number(error.factsCommitted) || 0,
        error: error.message,
        at: Date.now(),
      }
      try { save(state) } catch (saveError) {
        batchRecoveryError = `提炼批次 ${batch.id} 无法记录失败状态，自动整理已暂停：${saveError.message}`
        throw saveError
      }
    },
    done: (batch, scope, added) => {
      const state = load()
      state.extractionBatches = { ...(state.extractionBatches || {}) }
      state.extractionBatches[batch.id] = { fingerprint: batch.fingerprint, scope, status: 'done', added, at: Date.now() }
      try { save(state) } catch (error) {
        batchRecoveryError = `提炼批次 ${batch.id} 已提交事实但进度未确认，自动整理已暂停：${error.message}`
        throw error
      }
    },
  }
  const extractor = createMemoryExtractor({
    dsh, getConfig, relatedTo, commit: commitExtracted, isActive,
    reflect, batchState, scopeOf: scopeFromChatId, recoveryError: () => batchRecoveryError, log,
    consolidation: {
      health, load, save, chatLogDays, chatLogSnapshot,
      learnSelfStyle, buildProfile, profileKeyOf, createGenerationSignal,
    },
  })
  function extractFacts(chatId, transcript, genSignal = null) {
    return extractor.extractFacts(chatId, transcript, genSignal)
  }
  function extractLines(chatId, lines, genSignal = null) {
    return extractor.extractLines(chatId, lines, genSignal)
  }

  const dayKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
  function consolidate(o = {}) {
    return extractor.consolidate(o)
  }

  function learnSelfStyle(genSignal = null) {
    return styleImpl ? styleImpl(genSignal) : defaultStyle.learnSelfStyle(genSignal)
  }

  /** 每分钟调一次：一天几个整理时间点（默认 04:00 / 16:00），到点且这个点今天还没跑过就整理。 */
  async function tick() {
    if (!isActive() || !health().ok) return
    const cfg = getConfig().memory
    if (!cfg.enabled || !cfg.dailyConsolidate) return
    const s = load()
    const today = dayKey()
    const now = new Date()
    const mins = now.getHours() * 60 + now.getMinutes()
    const runs = s.runs || {}
    const due = (cfg.consolidateTimes || []).filter((t) => {
      const [hh, mm] = String(t).split(':').map(Number)
      return mins >= hh * 60 + mm && runs[t] !== today
    })
    if (!due.length) return
    // 连今天到目前为止的聊天一起提炼；记着整理到第几行，下一次只处理新的
    const r = await consolidate({ includeToday: true })
    if (r.ok) {
      const s2 = load()
      s2.runs = { ...(s2.runs || {}) }
      for (const t of due) s2.runs[t] = today
      save(s2)
    }
  }


  return {
    api: {
      importCandidates, distillHistory, learnDistillFromHistory,
      buildProfile, reflect, learnSelfStyle, consolidate, tick,
    },
    reload: () => { batchRecoveryError = '' },
  }
}
