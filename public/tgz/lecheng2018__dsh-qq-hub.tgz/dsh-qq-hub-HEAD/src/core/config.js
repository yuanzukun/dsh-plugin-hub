// 插件配置：默认值 + 归一化 + 读写。配置文件 ~/.dsh/plugins-data/dsh-qq-hub/config.json（老安装沿用 aurabot/）

import { dataDir, readJson, writeJson } from './store.js'
import { DEFAULT_GROUP_POLICY } from '../chat/group-policy.js'
import { LEVELS, PROFILE_PERM_KEYS, PROFILE_PERM_LEVELS, profilePermDefault } from '../chat/access.js'
import { normalizeChatModels } from '../chat/chat-model.js'
import { DIARY_AUDIENCES } from '../features/qzone-audience.js'

// 配置结构版本：改了字段语义/默认值要 +1，方便将来按版本迁移老配置。
export const CONFIG_VERSION = 1

// 默认值一旦被外面改到，所有新装的用户都会跟着错，所以冻住。
// 注意要做「深」冻结，否则嵌套对象（model、visionHelper 等）仍然可改。
const deepFreeze = (o) => {
  if (!o || typeof o !== 'object' || Object.isFrozen(o)) return o
  for (const v of Object.values(o)) deepFreeze(v)
  return Object.freeze(o)
}

const DEFAULTS_RAW = {
  enabled: false, // 总开关：关着一句都不发
  dryRun: true, // 试运行：只记日志不真发
  setupDone: false, // 首次使用向导走完了没有
  botQQ: '', // 机器人 QQ 号（向导里填）
  ownerQQ: '', // 主人 QQ 号（向导里填）
  ownerName: '主人',
  ownerLevel: 'full', // full | social | chat
  profilePerms: { qqNickname: 'owner', qqSignature: 'owner', qqAvatar: 'owner', biliSign: 'owner', biliAvatar: 'owner', qqFriendRequest: 'owner', whitelist: 'owner', douyinBrowse: 'owner', douyinLike: 'owner', douyinComment: 'owner', douyinShareOwner: 'owner', douyinDm: 'owner' }, // 改资料类操作（含抖音浏览 / 点赞 / 评论 / 分享）的权限：off 关 / owner 仅主人私聊 / all 所有人。抖音项默认仅主人，总开关默认关
  longTasks: false, // 长任务模式：主人私聊（完整权限）额外挂 dsh-tool-jobs + dsh-tool-schedule，会多一点工具定义、稍慢
  turnTimeoutMs: 600000, // 单回合等待上限；超时释放调度槽，迟到回复不投递
  allow: { private: [], groups: [] }, // 主人永远能私聊，不用写进白名单
  // 用什么接 QQ：snowluma = 插件帮你管 SnowLuma（Windows）；onebot = 接你已有的 OneBot v11 机器人（NapCat、LLOneBot、Lagrange、Docker 里的 SnowLuma……），
  // 这时只按下面 snowluma.httpUrl / wsUrl / token 去连，不启动、不注入任何东西
  gateway: 'snowluma',
  workspaceDir: '',
  workspacePerChat: false, // 每个聊天单独建工作区（会多出很多工作区，默认关；跨聊天隔离靠会话作用域，不靠目录）, // QQ 会话放在哪个文件夹（DSH 里的「QQ Hub」工作区）；留空 = 默认（用户目录下 Aurabot\\qq-chats）
  // 发文件（#52）：默认开但限制很多——她只能把 QQ 工作区（workspaceDir）和 dirs 里列的目录中的文件当文件发出去；
  // 单个文件有大小上限；只有主人私聊里能触发（可以发给白名单里的人和群）。日志里会记下发了什么。
  files: { enabled: true, maxMB: 50, dirs: [] },
  // 危险命令确认（可选保护，默认关）：她在私聊里执行删根目录/格式化/关机/下载后直接执行等
  // 终端命令前，先发 QQ 私聊问主人，回复「确认」才执行；超时或「取消」就拦下。
  security: {
    dangerConfirm: false,
    // 身份泄露闸（移植自 surfcore）：出站前扫主人的 QQ 号 / 别的群号
    identityGuard: { enabled: true, mode: 'block' },
    // 面板入站防护（M1-A）：Host 白名单的额外放行名单（回环名与 IP 字面量默认放行）。
    // 用 DDNS 域名访问面板的在这里登记，如 ['nas.example.com']
    panel: { allowedHosts: [] },
  },
  snowluma: {
    dir: 'C:\\Aurabot\\snowluma', // 主人自己下载解压到这里（EULA 不允许自动部署）
    autoStart: true, // 随 DSH 启动它（只启动主人已安装并同意过协议的副本）
    webuiPort: 5099,
    webuiPassword: '', // 插件自动生成并保存（第一次启动 SnowLuma 时）；用来调 /api/processes 只给机器人号注入
    passwordAuto: false,
    autoAttach: true, // 自动给机器人号所在的 QQ 进程注入（绝不碰别的号）
    httpUrl: '', // 留空 = 从 SnowLuma 配置里自动读
    wsUrl: '',
    httpToken: '',
    wsToken: '',
  },
  model: { provider: '', model: '', reasoningEffort: 'low', vision: 'auto' }, // 留空 = 跟随 DSH 默认；vision: auto/on/off
  // 辅助看图模型（可选）：主模型看不了图时，临时把图片交给这个模型「看一眼」，
  // 把看到的内容转成文字交给主模型。主模型自己就能看图时不走这条路。
  // provider/model 留空 = 没配；只比较「同一个模型」还是「不同模型」，不做任何能力猜测。
  visionHelper: { enabled: false, provider: '', model: '', maxImages: 4, maxChars: 600, keepOriginal: true },
  // 会话轮换：一个聊天用太久就自动归档重开。
  // 为什么需要：服务端按**会话**累计上下文（真机 413 plugin_request_too_large：请求约 5.8 MiB、
  // 插件内存上限 64 MiB），纯文字长谈也会慢慢顶到上限；DSH 的上下文压缩管的是 token 窗口，
  // 管不到服务端那种按字节的会话额度。阈值同时看「回合数」和「会话年龄」，任一到了就换
  //（填 0 = 该项不启用；只留一项就是单条件轮换）。
  sessionRotation: { enabled: true, maxTurns: 300, maxAgeHours: 168 },
  // 图片进历史的预算（每个会话）：服务端对「会话累计上下文 + 图片」有硬上限
  //（真机 413 plugin_request_too_large：请求约 5.8 MiB / 插件内存上限 64 MiB）。
  // 图片块一旦进历史，之后每一轮都会重新发一遍，所以额度必须**按会话**累加着算，
  // 而不是每轮重置。额度用完后的新图只留一句占位文字，不再进上下文。
  imageBudget: { enabled: true, maxImages: 24, maxMiB: 12 },
  // 共享浏览器（抖音/小红书/红果/贴吧这些要开网页的模块共用一套）。
  // 一个浏览器进程、每模块一个标签页、任务串行：可用内存本来就小，多开必炸。
  // chromePath 留空 = 先用插件自带的（install:browser 装的那份），再找系统里的 Edge/Chrome/Chromium。
  browser: {
    enabled: true,
    chromePath: '', // 留空 = 自动找
    headless: false, // 默认有头（抖音/小红书会拦无头）；没桌面时靠自带 Xvfb 撑
    chrome: true, // 装的时候优先官方 Chrome（视频编解码更全）；false = 直接用 Debian chromium
    maxConcurrent: 2, // 同时最多几个模块在用浏览器
    idleMinutes: 10, // 没人用这么久就关掉浏览器（0 = 不自动关）
    minFreeMB: 600, // 可用内存低于这个值就不启动（0 = 不检查）
    vncLan: false, // 远程看画面是否开给局域网（默认只绑本机；要跨机器看得自己开，且有密码）
  },
  // 按聊天选模型（主人在面板「模型」页设）：私聊 QQ 号 > 群号 > 所有私聊 / 所有群默认 > 上面的全局模型；没写的一级退到下一级
  chatModels: { privateDefault: { provider: '', model: '', reasoningEffort: '' }, groupDefault: { provider: '', model: '', reasoningEffort: '' }, privates: {}, groups: {} },
  merge: { enabled: true, waitSec: 2.5, maxSec: 8, groupWaitSec: 5, groupMaxSec: 15 },
  // 分条：她自己断的句（|||）优先，字数只当兜底。群里句子短、私聊可以长一点。
  reply: { groupMaxChars: 40, privateMaxChars: 120, maxBubbles: 6, keepReports: true }, // 分条只走规则：她写的 ||| 优先，字数只当兜底
  imageGen: {
    enabled: false,
    provider: 'openai', // openai / custom；codex = 实验性订阅接法（需单独登录）
    baseUrl: '',
    apiKey: '',
    model: '',
    size: '1024x1024',
    shape: 'her', // 工具可选构图；her 时未指定就沿用 size
    stylePrompt: '', // 每次生图自动加在前面的风格描述
    ownerOnly: true, // 只有主人能让她画
    seeOwn: true, // 「让她画完自己看一眼」：开着才把画好的图交给她看
    galleryShown: 20, // 面板「她的画作」显示最近几张（1~50；只影响显示，不删文件）
    // 自定义接法：url 里可以用 {prompt} {model} {size} {width} {height}；params 是参数名/值（值里也能用这些占位符）
    custom: { method: 'GET', url: '', bodyType: 'json', responsePath: '', params: [] },
    // 实验性订阅接法；登录令牌独立保存在数据目录，不进入配置。
    codex: { model: 'gpt-image-2', quality: 'auto', background: 'auto' },
  },
  // 人设：current 是全局默认；personaMap 按聊天覆盖（形状和 chatModels 一致，优先级也一样）
  //   某个群/私聊单独指定 > 群默认/私聊默认 > current
  persona: {
    current: 'dafeiyu',
    privateDefault: '', // 留空 = 用 current
    groupDefault: '',
    privates: {}, // { '10000001': 'persona-id' }
    groups: {}, // { '333444555': 'persona-id' }
  },
  // 主人私聊里问起群里的事：把最近 24 小时的群聊流水补进这一轮（默认关，开启前先把群加进白名单）
  group: {
    ...DEFAULT_GROUP_POLICY, overrides: {},
    ownerBrief: { enabled: false, lines: 12, groups: [] },
    // 鱼群保护（移植自 surfcore）：同群同类 bot 太多时本轮不参与。名列表留空 = 用模块默认值
    fishGuard: { enabled: true },
    // 群发送配额：QQ 群每分钟最多 10 条，超了消息会真丢（等窗口/重试）
    quota: { enabled: true, perMinute: 10, reserve: 1 },
  },
  // 按群头衔不回：勾选的群里，专属头衔正好是 title 的成员（一般是别的机器人）说话、戳她都不理。没勾群就不起作用
  voice: {
    enabled: true,
    // auto = 先 edge-tts，不行用 Windows 语音；edge / windows / cosyvoice / gptsovits / http /
    // doubao / qwentts / mimo = 指定引擎（失败都会退回 edge-tts 或 Windows 语音）
    engine: 'auto',
    cosyvoice: { url: 'http://127.0.0.1:50000', mode: 'sft', spkId: '中文女', instruct: '', sampleRate: 22050 },
    gptsovits: { url: 'http://127.0.0.1:9880', refAudio: '', promptText: '', promptLang: 'zh', textLang: 'zh' },
    // 通用 HTTP TTS：GET 地址模板（{text} 替换成要念的话）；POST 时配请求头/请求体，
    // 可接火山豆包 / 阿里 / 讯飞这类要鉴权的云 TTS（JSON 里的 base64 音频自动解出）
    http: { urlTemplate: '', method: 'GET', headers: '', body: '' },
    // 豆包语音 2.0（火山引擎，语义移植上游社区模块 voice）：X-Api-Key 鉴权，流式 NDJSON 返回 base64 WAV 分片
    doubao: { apiKey: '', resourceId: 'seed-icl-2.0', speaker: 'S_1CmxEOek2', speechRate: 0, contextTexts: '', autoEmotion: true, timeout: 60 },
    // 阿里百炼 qwen-tts（DashScope SpeechSynthesizer；语义移植上游 qwen-tts 模块）
    qwentts: {
      apiKey: '', baseUrl: 'https://dashscope.aliyuncs.com', model: 'qwen-audio-3.1-tts-flash', voice: 'Cherry',
      speechRate: 1.0, sampleRate: 24000, seed: 20261, maxCharsPerSegment: 300, timeoutMs: 30000,
      instruction: '用日常聊天说话的语气，像在手机上随口跟朋友讲话，语速略快，不要播音腔。中文。',
    },
    // 小米 MiMo TTS（OpenAI 兼容 chat/completions；语义移植上游 aura-mimo 模块）：
    // voiceclone 模型用参考音频（本机路径）克隆音色，voicedesign 模型用音色描述
    mimo: { apiKey: '', apiBase: 'https://api.xiaomimimo.com/v1', model: 'mimo-v2.5-tts-voiceclone', stylePrompt: '', seedText: '', refAudio: '', timeout: 180 },
    voice: 'zh-CN-XiaoyiNeural',
    rate: '+0%',
    pitch: '+0Hz',
    autoChance: 0.15, // 短回复自动变语音的概率
    autoMaxChars: 80,
    asr: true, // 听语音
  },
  stickers: {
    enabled: true,
    faces: true, // 回复里能夹 QQ 自带的小黄脸（<face:名字>）
    autoChance: 0.35, // 文字回复自动配一张表情的概率
    collect: true, // 偷表情
    // 怎么偷：auto = 看到就收（默认，保持原行为）；ask = 她挑（先记着，喜欢才凭编号收）；owner = 只听主人的（只有主人语境下才提示/允许收）
    collectMode: 'auto',
    fromGroups: true,
    fromPrivate: true,
    maxPerHour: 20,
    maxLibrary: 300, // 表情库最多存多少张（QQ 收藏表情有上限），超了就清掉最少用的
    caption: true, // 用视觉模型起备注
  },
  diary: {
    enabled: true,
    timesPerDay: 2,
    windowStart: '10:00',
    windowEnd: '23:30',
    minGapMinutes: 180,
    attachImage: true, // 写日记时配一张图（优先今天她画的，其次今天收的表情包）
    minChars: 60,
    maxChars: 140,
    // 审计 S07：默认「仅自己可见」。日记素材可能来自多个会话（见 includeChats），
    // 出厂就公开等于把私聊内容默认推到好友圈。
    visibility: 'self', // all | friends | selected | self | excluded，和 QQ 空间自身的可见范围一致
    audienceQQs: '', // selected / excluded 时可见（或不可见）的好友 QQ 号，换行或逗号分隔
    // 审计 S07：哪些会话的聊天内容允许进入日记素材。空数组 = 不引用任何聊天，
    // 日记只写她自己的事（今天画了什么、在想什么）。
    // 过去无条件把「所有非 system 会话」的当天流水混成一份摘要交给模型，
    // 于是私聊内容会被改写成第一人称说说发到空间。
    includeChats: [],
  },
  // 本地接口：数据目录 local/ 里的脚本接管这几项（文件要在、开关要开）
  local: { tts: false, image: false, asr: false },
  bili: {
    enabled: false,
    sessdata: '', // B 站 Cookie 里的 SESSDATA（登录凭证）
    biliJct: '', // B 站 Cookie 里的 bili_jct（发评论要用）。两个都不填也能看视频，只是不能评论
    cookie: '', // 由上面两个拼出来给接口用；老配置的整串会自动拆到上面两个里
    autoBrowse: true, // 定时自己去刷
    intervalHours: 4, // 多久刷一轮
    maxRunsPerDay: 3,
    perRun: 3, // 一轮看几个视频
    keywords: [], // 额外想让她搜的方向（另外还会参考她的兴趣和记忆里你喜欢的东西）
    minViews: 5000, // 播放量门槛
    maxAgeDays: 60, // 只看最近多少天发的
    comment: true, // 自己发评论
    maxCommentsPerDay: 3,
    reply: true, // 回别人回她的评论
    maxRepliesPerDay: 6,
    shareToOwner: true, // 看到好玩的私聊分享给主人
    like: false, // 顺手点赞
    vision: false, // 可选：ffmpeg 抽帧交给视觉模型
    visionFrames: 6,
    ffmpegPath: '', // 留空从 PATH 查找
    shotChance: 0.35, // 刷完发截图给主人；0 = 不自动发
    shotLibrary: 300,
  },
  // 刷抖音：专用浏览器（独立登录资料，不碰你平时的浏览器），经 CDP 控制。浏览 / 点赞 / 评论 / 分享各项权限在 profilePerms.douyin*。
  douyin: {
    enabled: false, // 总开关：默认关，先在面板里扫码登录再打开
    autoBrowse: true, // 定时自己去刷
    intervalHours: 4,
    maxRunsPerDay: 3,
    perRun: 5, // 一轮看几个视频
    maxWatchPerDay: 30, // 每天最多看几个（手动让她刷也算；主人亲口让她找视频时不受这个限制）
    dwellMin: 8, // 每个视频停留的秒数（随机取一个）
    dwellMax: 40,
    browserPath: '', // 留空 = 自动找 Edge（找不到再找 Chrome / Chromium）；也可填完整路径
    shareBias: 'proactive', // stingy | normal | proactive：刷到好看的视频，分享给主人的积极程度
    ownerDm: true, // 主人在抖音上私信她时回（只认核对过的主人抖音号）
    dmPollMinutes: 3, // 隔几分钟看一次主人的抖音私信
    shareTo: 'douyin', // douyin = 在抖音里私信分享给主人（要先核对主人抖音号，没核对 / 发不出去就改发 QQ）| qq = QQ 私聊发链接 | both = 两边都发
    owner: { input: '', secUid: '', uid: '', nickname: '', confirmedInput: '' }, // 主人的抖音号：面板填抖音号 / 主页链接，「核对」后才写入 secUid（真·@主人只认它）
    caps: { like: 30, comment: 3, share: 5, atOwner: 3 }, // 每天上限（登录后前 newAccountDays 天减半）；atOwner = 评论里真·@主人
    gate: {
      maxWritesPerDay: 40, // 点赞 + 评论合计上限
      minWriteGapSec: 20, // 两次点赞 / 评论之间至少隔这么多秒
      newAccountDays: 3, // 首次登录起这么多天内，上限都减半
    },
  },
  // 刷小黑盒：用主人的账号逛游戏社区（读多写少）。点赞 / 评论 / 发帖各项权限在 profilePerms.heybox*。
  heybox: {
    enabled: false, // 总开关：默认关，先在面板里填 Cookie 再打开
    cookie: '', // 整串 Cookie（pkey 必须有；要写操作还得有 x_xhh_tokenid）
    autoBrowse: true, // 定时自己去逛（只读）
    intervalHours: 4, // 多久逛一圈
    maxRunsPerDay: 6, // 每天最多逛几轮
    perRun: 3, // 一圈看几条
    likeDaily: 10, // 每天最多点赞
    commentDaily: 3, // 每天最多评论
    maxPostsPerDay: 3, // 每天最多发帖（硬上限，多了容易被限）
    defaultTopic: 7214, // 发帖默认分区：7214 盒友杂谈 / 18745 数码硬件 / 806933 AI
    postStyle: 'mix', // 发帖风格：diary 大肥鱼日记 / news 热搜文 / mix 肥鱼热搜
  },
  qzoneSocial: {
    enabled: true,
    replyOwn: true, // 回复自己说说下别人的新评论
    commentFriends: true, // 逛好友动态，偶尔评论
    friendChance: 0.3, // 看到一条好友说说时互动（点赞 + 可能评论）的概率
    ownerChance: 0.7, // 主人的说说互动概率
    like: true, // 互动时顺手点赞
    maxPerDay: 8, // 每天最多评论几条（点赞不算）
    intervalMin: 30, // 多久逛一次空间
  },
  speakUp: {
    enabled: true, // 只在和主人的私聊里主动找你，群里不会
    idleMinutes: 40,
    minIntervalMinutes: 60,
    maxIntervalMinutes: 180,
    maxPerDay: 4,
    nudge: true, // 她问了你一句、你一直没回时，偶尔轻轻追一句
    awakeFrom: 8,
    awakeTo: 23,
    // 早安 / 晚安：到点必发一次（不参与随机间隔抽签），每天每种只发一次
    greeting: { enabled: true, morning: '08:00', night: '23:00' },
  },
  memory: { enabled: true, recallCount: 6, hintCount: 8, hintMaxChars: 600, dailyConsolidate: true, consolidateTimes: ['04:00', '16:00'], embeddings: { enabled: false, url: '', apiKey: '', model: 'BAAI/bge-m3', dim: 1024, timeoutMs: 8000, batch: 16, maxChars: 200 } }, // 每天这几个时间把临时记忆（聊天流水）整理进长期记忆、相处经验和说话方式；过了一天的流水整理完清空。embeddings：向量通道（1.4.4），默认关 —— 填一个 OpenAI 兼容的 /embeddings 端点（如 SiliconFlow BAAI/bge-m3）并 enabled: true 才启用语义召回
  // 挂起线索（US-019）：S1 规则层永远跑（零成本）；S2 慢思考每轮多一次小模型调用，
  // 所以默认只在私聊跑，群里关掉（群里每人一句就一次模型调用，成本压不住）。
  threads: { enabled: true, judge: true, judgeInGroups: false, judgeTimeoutMs: 15000, pruneIntervalMs: 60000 },
  // 多平台内容解析器（移植自 astrbot_plugin_multi_parser）
  multiParser: {
    enabled: false,              // 模块总开关，默认关
    inGroups: true,              // 群聊里要不要提供解析（关掉就只在私聊解析，群里连链接都不碰）
    inPrivate: true,             // 私聊里要不要提供解析
    disabledGroups: [],          // 这些群单独关掉（即使 inGroups 开着）
    feedToAi: true,              // 🌟 AI 注入开关（把标题、作者、正文摘要喂给当前大模型会话让它读懂并接话）
    sendMedia: true,             // 媒体发送开关（是否向 QQ 发送解析后的视频或图文）
    forwardMode: 'threshold',    // threshold / always / never
    imageThreshold: 2,           // 超过几张图自动转合并转发卡片
    maxVideoMB: 100,             // 视频直接发送上限 (MB)
    videoOverLimit: 'direct_link', // direct_link / group_file / notice
    platforms: {
      bilibili: true,
      douyin: true,
      redbook: true,
      weibo: true,
      zhihu: true,
      wechat: true,
      tieba: true,
      fanqie: true,
      github: true,
      xiaoheihe: true,
    },
    cookies: {
      bilibili: '',   // B站 Cookie，留空自动复用 bili.cookie
      weibo: '',      // 微博 Cookie (SUB 等)
      redbook: '',    // 小红书 Cookie (a1, web_session 等)
      zhihu: '',      // 知乎 Cookie (z_c0 等)
      tieba: '',      // 百度贴吧 Cookie (BDUSS 等)
      douyin: '',     // 抖音 Cookie
      xiaoheihe: '',  // 小黑盒 Cookie，留空自动复用 heybox.cookie
    },
  },
  tabs: {}, // 面板记住的小偏好
  // 模块：内置的和数据目录 modules/ 里自己写的。{ 模块id: { enabled, useBuiltin } }，没写的算开着
  // useBuiltin：自己写了同名模块，但想先用回内置的
  modules: {
    // 模块市场（分发半套）：默认 OFF；indexUrls 按序 failover；installed 记账
    market: { enabled: false, indexUrls: [], httpProxy: '', installed: {} },
  },
  safeMode: false, // 安全模式：自己写的模块一个都不加载（排查问题用）
  ext: {}, // 自己写的模块的设置：{ 模块id: {...} }
  // 联动：让别的程序、DSH 里别的会话和插件也能用她
  bridge: {
    dshTools: false, // DSH 里别的会话（比如你平时写代码的会话）能用工具让她发 QQ、查记忆
    http: false, // 开放 HTTP 接口（要带密钥）
    token: '', // 第一次打开时自动生成
    allowTargets: 'whitelist', // 外部能发给谁：whitelist = 白名单里的人和群；owner = 只能发给主人
  },
}

export const DEFAULTS = deepFreeze(DEFAULTS_RAW)

const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v)

function deepMerge(base, over) {
  if (!isObj(over)) return structuredClone(base)
  const out = structuredClone(base)
  for (const [k, v] of Object.entries(over)) {
    if (isObj(v) && isObj(out[k])) out[k] = deepMerge(out[k], v)
    else if (v !== undefined) out[k] = v
  }
  return out
}

const num = (v, d, lo, hi) => {
  const n = Number(v)
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d
}
const bool = (v, d) => (typeof v === 'boolean' ? v : d)
const qq = (v) => String(v ?? '').replace(/\D/g, '')
const qqList = (v) => [...new Set((Array.isArray(v) ? v : String(v || '').split(/[\s,，;；]+/)).map(qq).filter(Boolean))]
const hhmm = (v, d) => (/^\d{1,2}:\d{2}$/.test(String(v)) ? String(v) : d)

/**
 * 人设配置归一化。
 * 兼容三种老形状：字符串（直接是人设 id）、{ current }、以及新版带 personaMap 的对象。
 * 引用了不存在的人设一律清空（回落到上一级默认），避免面板上选到一个已经删掉的人格。
 */
function normalizePersona (p) {
  const ok = (id) => String(id || '').trim()
  if (typeof p === 'string') return { current: ok(p) || 'dafeiyu', privateDefault: '', groupDefault: '', privates: {}, groups: {} }
  const o = isObj(p) ? p : {}
  const mapIds = (m) => {
    const out = {}
    if (isObj(m)) {
      for (const [k, v] of Object.entries(m)) {
        if (String(k).startsWith('#')) continue // 临时占位行（如 #new...）绝不落盘，防止被洗成纯数字
        const key = String(k).replace(/\D/g, '')
        if (!key) continue
        // 值可以先空着：面板里「添加」一行、还没选人设就保存，那一行不该被悄悄丢掉。
        // 空值在 personaIdFor 里会被当成「没指定」往下落，不影响行为。
        out[key] = ok(v)
      }
    }
    return out
  }
  return {
    current: ok(o.current) || 'dafeiyu',
    privateDefault: ok(o.privateDefault),
    groupDefault: ok(o.groupDefault),
    privates: mapIds(o.privates),
    groups: mapIds(o.groups),
  }
}

export function normalize(raw) {
  const c = deepMerge(DEFAULTS, raw)
  c.enabled = bool(c.enabled, false)
  c.dryRun = bool(c.dryRun, true)
  c.botQQ = qq(c.botQQ)
  c.ownerQQ = qq(c.ownerQQ)
  c.gateway = c.gateway === 'onebot' ? 'onebot' : 'snowluma'
  // 只认绝对路径（Windows 的 D:\\… 或 Linux 的 /…），别的当没填
  c.workspaceDir = String(c.workspaceDir || '').trim()
  if (c.workspaceDir && !/^([a-zA-Z]:[\\/]|\/)/.test(c.workspaceDir)) c.workspaceDir = ''
  // 视觉能力：auto = 问 DSH 的模型元数据；on / off = 主人手动声明（覆盖元数据）
  c.model.vision = c.model.vision === 'on' || c.model.vision === 'off' ? c.model.vision : 'auto'
  // 辅助看图模型：参数都有上下界，避免面板填出离谱值把上下文撑爆
  if (!isObj(c.visionHelper)) c.visionHelper = {}
  c.visionHelper.enabled = bool(c.visionHelper.enabled, false)
  c.visionHelper.provider = String(c.visionHelper.provider || '').trim()
  c.visionHelper.model = String(c.visionHelper.model || '').trim()
  c.visionHelper.maxImages = Math.round(num(c.visionHelper.maxImages, 4, 1, 8))
  c.visionHelper.maxChars = Math.round(num(c.visionHelper.maxChars, 600, 100, 2000))
  c.visionHelper.keepOriginal = bool(c.visionHelper.keepOriginal, true)
  // 会话轮换：0 = 该项不启用；年龄留小数（排障/测试要能设成几十秒）
  if (!isObj(c.sessionRotation)) c.sessionRotation = {}
  c.sessionRotation.enabled = bool(c.sessionRotation.enabled, true)
  c.sessionRotation.maxTurns = Math.round(num(c.sessionRotation.maxTurns, 300, 0, 100000))
  c.sessionRotation.maxAgeHours = num(c.sessionRotation.maxAgeHours, 168, 0, 8760)
  // 图片进历史的预算：张数与字节都设上下界，面板填出离谱值也不会把会话一次性撑爆
  if (!isObj(c.imageBudget)) c.imageBudget = {}
  c.imageBudget.enabled = bool(c.imageBudget.enabled, true)
  c.imageBudget.maxImages = Math.round(num(c.imageBudget.maxImages, 24, 0, 200))
  c.imageBudget.maxMiB = Math.round(num(c.imageBudget.maxMiB, 12, 0, 128))
  // 共享浏览器：并发与内存水位都有上下界，别让面板填出「同时开 50 个」这种值
  if (!isObj(c.browser)) c.browser = {}
  c.browser.enabled = bool(c.browser.enabled, true)
  c.browser.chromePath = String(c.browser.chromePath || '').trim()
  c.browser.headless = bool(c.browser.headless, false)
  c.browser.chrome = bool(c.browser.chrome, true)
  c.browser.maxConcurrent = Math.round(num(c.browser.maxConcurrent, 2, 1, 4))
  c.browser.idleMinutes = Math.round(num(c.browser.idleMinutes, 10, 0, 240))
  c.browser.minFreeMB = Math.round(num(c.browser.minFreeMB, 600, 0, 8192))
  c.browser.vncLan = bool(c.browser.vncLan, false)
  c.setupDone = bool(c.setupDone, false)
  c.ownerLevel = LEVELS.includes(c.ownerLevel) ? c.ownerLevel : 'full'
  c.longTasks = bool(c.longTasks, false)
  c.turnTimeoutMs = Math.round(num(c.turnTimeoutMs, 600000, 60000, 7200000))
  c.chatModels = normalizeChatModels(c.chatModels)
  // 人设：兼容老配置（早期直接存字符串 / 只有 current 两种形状）。
  // 不在这里校验人设是否存在——config 不认识文件系统，校验放到 personas.js 里做。
  c.persona = normalizePersona(c.persona)
  c.profilePerms = Object.fromEntries(PROFILE_PERM_KEYS.map((k) => [k, PROFILE_PERM_LEVELS.includes(c.profilePerms?.[k]) ? c.profilePerms[k] : profilePermDefault(k)]))
  // 旧版 douyinDm 是「回别人私信」的权限，含义已不同（现在是主动发私信），老配置一律回到默认「仅主人」
  if (isObj(raw?.profilePerms) && 'douyinDm' in raw.profilePerms) c.profilePerms.douyinDm = profilePermDefault('douyinDm')
  c.allow = { private: qqList(c.allow.private), groups: qqList(c.allow.groups) }
  // 发文件：开关、大小上限、额外允许的目录（只认绝对路径；空行忽略）
  if (!isObj(c.files)) c.files = {}
  if (!isObj(c.security)) c.security = {}
  c.security.dangerConfirm = bool(c.security.dangerConfirm, false)
  if (!isObj(c.security.identityGuard)) c.security.identityGuard = { enabled: true, mode: 'block' }
  c.security.identityGuard.enabled = bool(c.security.identityGuard.enabled, true)
  c.security.identityGuard.mode = c.security.identityGuard.mode === 'warn' ? 'warn' : 'block'
  // 面板 Host 白名单（M1-A）：字符串/数组都收，非法值 fail-closed 到空列表（只放回环与 IP）
  if (!isObj(c.security.panel)) c.security.panel = { allowedHosts: [] }
  c.security.panel.allowedHosts = (Array.isArray(c.security.panel.allowedHosts)
    ? c.security.panel.allowedHosts
    : String(c.security.panel.allowedHosts ?? '').split(/[\s,，;；]+/))
    .map((s) => String(s).trim().toLowerCase()).filter(Boolean).slice(0, 20)
  c.files.enabled = bool(c.files.enabled, true)
  c.files.maxMB = num(c.files.maxMB, 50, 1, 2048)
  c.files.dirs = (Array.isArray(c.files.dirs) ? c.files.dirs : String(c.files.dirs || '').split(/[\n,，;；]+/))
    .map((s) => String(s).trim()).filter((s) => /^([a-zA-Z]:[\\/]|\/)/.test(s)).slice(0, 20)
  const g = c.group
  g.wakeWords = (Array.isArray(g.wakeWords) ? g.wakeWords : String(g.wakeWords || '').split(/[\s,，]+/)).map((s) => String(s).trim()).filter(Boolean)
  g.interjectChance = num(g.interjectChance, 0.15, 0, 1)
  // 群发送配额（QQ 每分钟 10 条，超了消息会真丢）
  if (!isObj(g.quota)) g.quota = {}
  g.quota.enabled = bool(g.quota.enabled, true)
  g.quota.perMinute = num(g.quota.perMinute, 10, 1, 200)
  g.quota.reserve = num(g.quota.reserve, 1, 0, 10)
  if (!isObj(g.fishGuard)) g.fishGuard = { enabled: true }
  g.fishGuard.enabled = bool(g.fishGuard.enabled, true)
  g.cooldownSec = num(g.cooldownSec, 90, 0, 86400)
  // 每小时**说话总条数**（令牌桶速率，不是「插话次数」——口径见 group-policy 的说明）。
  // 上限放到 200：老配置会按 (1+engagedMaxReplies) 折算一次，调整过的大值不该被夹掉。
  g.maxPerHour = num(g.maxPerHour, DEFAULT_GROUP_POLICY.maxPerHour, 0, 200)
  // 连聊预算：以前这两个键压根没归一化，0 会被 group-policy 的 `||` 兜回默认值。
  // 现在 0 就是 0（关掉连聊通道），面板也暴露出来了。
  g.engagedMaxReplies = num(g.engagedMaxReplies, DEFAULT_GROUP_POLICY.engagedMaxReplies, 0, 20)
  g.engagedMaxMs = num(g.engagedMaxMs, DEFAULT_GROUP_POLICY.engagedMaxMs, 0, 3600000)
  g.minRecentMessages = num(g.minRecentMessages, 3, 0, 100)
  g.activeWindowSec = num(g.activeWindowSec, 300, 30, 86400)
  if (!Array.isArray(g.quietHours) || g.quietHours.length !== 2) g.quietHours = DEFAULT_GROUP_POLICY.quietHours
  g.quietHours = g.quietHours.map((h) => num(h, 0, 0, 23))
  if (!isObj(g.overrides)) g.overrides = {}
  if (!isObj(g.ownerBrief)) g.ownerBrief = { enabled: false, lines: 12, groups: [] }
  g.ownerBrief.enabled = bool(g.ownerBrief.enabled, false)
  g.ownerBrief.lines = num(g.ownerBrief.lines, 12, 1, 30)
  g.ownerBrief.groups = qqList(g.ownerBrief.groups)
  c.voice.autoChance = num(c.voice.autoChance, 0.15, 0, 1)
  c.voice.autoMaxChars = num(c.voice.autoMaxChars, 80, 1, 500)
  c.stickers.autoChance = num(c.stickers.autoChance, 0.35, 0, 1)
  c.stickers.faces = c.stickers.faces !== false
  c.stickers.collectMode = ['ask', 'auto', 'owner'].includes(c.stickers.collectMode) ? c.stickers.collectMode : 'auto'
  c.stickers.maxPerHour = num(c.stickers.maxPerHour, 20, 0, 200)
  c.stickers.maxLibrary = num(c.stickers.maxLibrary, 300, 20, 2000)
  c.diary.timesPerDay = num(c.diary.timesPerDay, 2, 0, 6)
  c.diary.windowStart = hhmm(c.diary.windowStart, '10:00')
  c.diary.windowEnd = hhmm(c.diary.windowEnd, '23:30')
  c.diary.minGapMinutes = num(c.diary.minGapMinutes, 180, 0, 1440)
  c.diary.attachImage = bool(c.diary.attachImage, true)
  c.diary.minChars = num(c.diary.minChars, 60, 10, 500)
  c.diary.maxChars = num(c.diary.maxChars, 140, 20, 1000)
  c.diary.visibility = DIARY_AUDIENCES.includes(c.diary.visibility) ? c.diary.visibility : 'self'
  c.diary.audienceQQs = qqList(c.diary.audienceQQs).slice(0, 200).join('\n')
  // 审计 S07：只接受合法 chatId，去重、限 100 条。非法项直接丢弃（不让脏配置
  // 变成「匹配不到任何会话」以外的行为）。
  c.diary.includeChats = [...new Set(
    (Array.isArray(c.diary.includeChats) ? c.diary.includeChats : [])
      .map((x) => String(x || '').trim())
      .filter((x) => /^(private|group):\d+$/.test(x)),
  )].slice(0, 100)
  c.speakUp.idleMinutes = num(c.speakUp.idleMinutes, 40, 5, 1440)
  c.speakUp.nudge = bool(c.speakUp.nudge, true)
  c.speakUp.minIntervalMinutes = num(c.speakUp.minIntervalMinutes, 90, 5, 1440)
  c.speakUp.maxIntervalMinutes = Math.max(c.speakUp.minIntervalMinutes, num(c.speakUp.maxIntervalMinutes, 240, 5, 2880))
  c.speakUp.maxPerDay = num(c.speakUp.maxPerDay, 3, 0, 20)
  const q = c.qzoneSocial
  q.enabled = bool(q.enabled, true)
  q.replyOwn = bool(q.replyOwn, true)
  q.commentFriends = bool(q.commentFriends, true)
  q.like = bool(q.like, true)
  q.friendChance = num(q.friendChance, 0.3, 0, 1)
  q.ownerChance = num(q.ownerChance, 0.7, 0, 1)
  q.maxPerDay = num(q.maxPerDay, 8, 0, 50)
  q.intervalMin = num(q.intervalMin, 30, 5, 1440)
  for (const k of ['tts', 'image', 'asr']) c.local[k] = bool(c.local[k], false)
  const b = c.bili
  Object.assign(b, splitBiliCookie(b))
  for (const k of ['enabled', 'autoBrowse', 'comment', 'reply', 'shareToOwner', 'like', 'vision']) b[k] = bool(b[k], DEFAULTS.bili[k])
  b.visionFrames = Math.round(num(b.visionFrames, 6, 2, 12))
  b.ffmpegPath = String(b.ffmpegPath || '').trim()
  b.shotChance = num(b.shotChance, 0.35, 0, 1)
  b.shotLibrary = Math.round(num(b.shotLibrary, 300, 20, 2000))
  b.intervalHours = num(b.intervalHours, 4, 1, 48)
  b.maxRunsPerDay = num(b.maxRunsPerDay, 3, 0, 24)
  b.perRun = num(b.perRun, 3, 1, 8)
  b.minViews = num(b.minViews, 5000, 0, 1e8)
  b.maxAgeDays = num(b.maxAgeDays, 60, 0, 3650)
  b.maxCommentsPerDay = num(b.maxCommentsPerDay, 3, 0, 50)
  b.maxRepliesPerDay = num(b.maxRepliesPerDay, 6, 0, 100)
  b.keywords = (Array.isArray(b.keywords) ? b.keywords : String(b.keywords || '').split(/[\n,，]+/)).map((x) => String(x).trim()).filter(Boolean).slice(0, 30)
  const d = c.douyin
  d.enabled = bool(d.enabled, false)
  d.autoBrowse = bool(d.autoBrowse, true)
  d.intervalHours = num(d.intervalHours, 4, 1, 48)
  d.maxRunsPerDay = num(d.maxRunsPerDay, 3, 0, 24)
  d.perRun = num(d.perRun, 5, 1, 10)
  d.maxWatchPerDay = num(d.maxWatchPerDay, 30, 0, 200)
  d.dwellMin = num(d.dwellMin, 8, 3, 120)
  d.dwellMax = Math.max(d.dwellMin, num(d.dwellMax, 40, 3, 300))
  d.browserPath = String(d.browserPath || '').trim()
  d.shareTo = ['douyin', 'qq', 'both'].includes(d.shareTo) ? d.shareTo : 'douyin'
  d.ownerDm = bool(d.ownerDm, true)
  // 评论区接着聊（上游 2.3.8）：默认关，行为与升级前完全一致
  d.commentReply = bool(d.commentReply, false)
  d.commentReplyPollMinutes = Math.round(num(d.commentReplyPollMinutes, 5, 1, 60))
  // 分享卡片后补一句：默认关
  d.shareDmText = bool(d.shareDmText, false)
  d.shareDmTextChance = num(d.shareDmTextChance, 0.6, 0, 1)
  d.dmPollMinutes = num(d.dmPollMinutes, 3, 1, 60)
  d.shareBias = ['stingy', 'normal', 'proactive'].includes(d.shareBias) ? d.shareBias : d.shareBias === 'off' ? 'stingy' : 'proactive'
  if (!isObj(d.caps)) d.caps = {}
  if (raw?.douyin?.caps?.share == null && raw?.douyin?.caps?.shareOwner != null) d.caps.share = raw.douyin.caps.shareOwner // 1.0.x 叫 shareOwner
  d.caps = { like: num(d.caps.like, 30, 0, 300), comment: num(d.caps.comment, 3, 0, 30), share: num(d.caps.share, 5, 0, 30), atOwner: num(d.caps.atOwner, 3, 0, 30) }
  if (!isObj(d.owner)) d.owner = {}
  d.owner = Object.fromEntries(['input', 'secUid', 'uid', 'nickname', 'confirmedInput'].map((k) => [k, String(d.owner[k] ?? '').trim().slice(0, 400)]))
  if (!isObj(d.gate)) d.gate = {}
  d.gate = { maxWritesPerDay: num(d.gate.maxWritesPerDay, 40, 1, 500), minWriteGapSec: num(d.gate.minWriteGapSec, 20, 0, 600), newAccountDays: num(d.gate.newAccountDays, 3, 0, 30) }
  // 1.0.x 的 douyin-im / 私信相关设置都不用了
  for (const k of ['atOwnerOnLikeChance', 'minimize', 'socialInterruptBrowse', 'replyPollMinutes']) delete d[k]

  // 1.3.63：按头衔过滤整条下线（很多 bot 根本不挂头衔/普通号查不到头衔，形同虚设）；
  // 防 bot 对聊改由鱼名单 + 乒乓规则负责。清掉旧配置里的死键。
  delete c.titleFilter
  c.snowluma.webuiPort = num(c.snowluma.webuiPort, 5099, 1, 65535)
  // 老配置只有一个 consolidateAt：换成两个时间点（它 + 12 小时后）
  if (!Array.isArray(raw?.memory?.consolidateTimes) && raw?.memory?.consolidateAt) {
    const [hh, mm] = hhmm(raw.memory.consolidateAt, '04:00').split(':').map(Number)
    c.memory.consolidateTimes = [`${hh}:${String(mm).padStart(2, '0')}`, `${(hh + 12) % 24}:${String(mm).padStart(2, '0')}`]
  }
  delete c.memory.consolidateAt
  c.memory.consolidateTimes = [...new Set((Array.isArray(c.memory.consolidateTimes) ? c.memory.consolidateTimes : String(c.memory.consolidateTimes || '').split(/[\s,，]+/)).map((t) => hhmm(t, '')).filter(Boolean).map((t) => t.padStart(5, '0')))].sort().slice(0, 4)
  if (!c.memory.consolidateTimes.length) c.memory.consolidateTimes = ['04:00', '16:00']
  c.memory.recallCount = num(c.memory.recallCount, 6, 0, 20)
  // 聊天流水滚动保留（1.3.49 #5）：每天一个 JSONL，超期自动清理；14 天下限（整理和压缩都还要翻它）
  if (!isObj(c.chatlog)) c.chatlog = {}
  c.chatlog.keepDays = Math.round(num(c.chatlog.keepDays, 30, 14, 365))
  c.memory.hintCount = Math.round(num(c.memory.hintCount, 8, 1, 20)) // 每轮最多带几条记忆进提示词
  c.memory.hintMaxChars = Math.round(num(c.memory.hintMaxChars, 600, 120, 2000)) // 这些记忆合起来最多多少字
  // 向量通道（1.4.4）：默认全关。url 填了且 enabled 才启用（memory-vector 的 normalizeEmbeddingConfig 会再判一次）。
  if (!isObj(c.memory.embeddings)) c.memory.embeddings = {}
  const embCfg = c.memory.embeddings
  embCfg.enabled = bool(embCfg.enabled, false)
  embCfg.url = String(embCfg.url ?? '').trim()
  embCfg.apiKey = String(embCfg.apiKey ?? '').trim()
  embCfg.model = String(embCfg.model ?? '').trim()
  embCfg.dim = Math.round(num(embCfg.dim, 1024, 64, 4096))
  embCfg.timeoutMs = Math.round(num(embCfg.timeoutMs, 8000, 1000, 60000))
  embCfg.batch = Math.round(num(embCfg.batch, 16, 1, 64))
  embCfg.maxChars = Math.round(num(embCfg.maxChars, 200, 60, 400))
  // 挂起线索（US-019）：开关 + S2 判定范围与预算。judge 关掉就只剩 S1 规则层（零成本）。
  if (!isObj(c.threads)) c.threads = {}
  c.threads.enabled = bool(c.threads.enabled, true)
  c.threads.judge = bool(c.threads.judge, true)
  c.threads.judgeInGroups = bool(c.threads.judgeInGroups, false)
  c.threads.judgeTimeoutMs = Math.round(num(c.threads.judgeTimeoutMs, 15000, 1000, 60000))
  c.threads.pruneIntervalMs = Math.round(num(c.threads.pruneIntervalMs, 60000, 5000, 3600000))
  g.interests = (Array.isArray(g.interests) ? g.interests : String(g.interests || '').split(/[\s,，]+/)).map((s) => String(s).trim()).filter(Boolean)
  g.minRelevance = num(g.minRelevance, 0.25, 0, 1)
  c.merge.enabled = bool(c.merge.enabled, true)
  c.merge.waitSec = num(c.merge.waitSec, 2.5, 0, 30)
  c.merge.maxSec = Math.max(c.merge.waitSec, num(c.merge.maxSec, 8, 0, 60))
  c.merge.groupWaitSec = num(c.merge.groupWaitSec, 5, 0, 60)
  c.merge.groupMaxSec = Math.max(c.merge.groupWaitSec, num(c.merge.groupMaxSec, 15, 0, 120))
  if (!isObj(c.reply)) c.reply = {}
  c.reply.groupMaxChars = num(c.reply.groupMaxChars, 40, 10, 500)
  c.reply.privateMaxChars = num(c.reply.privateMaxChars, 120, 20, 2000)
  c.reply.maxBubbles = Math.round(Math.min(12, Math.max(1, Number(c.reply.maxBubbles) || 6))) // 一轮最多几条
  c.reply.keepReports = bool(c.reply.keepReports, true)
  // 1.3.43 删掉了「多问一次模型挑断点」：老配置里的残留在这里丢掉，别又跟着存回去。
  delete c.reply.llmSplit
  g.burstMax = num(g.burstMax, 8, 1, 50)
  g.burstWindowSec = num(g.burstWindowSec, 120, 10, 3600)
  if (!['auto', 'edge', 'windows', 'cosyvoice', 'gptsovits', 'http', 'doubao', 'qwentts', 'mimo'].includes(c.voice.engine)) c.voice.engine = 'auto'
  // 通用 HTTP TTS：手改 config 写脏了也不能把请求发歪（语义移植上游）
  if (!c.voice.http || typeof c.voice.http !== 'object' || Array.isArray(c.voice.http)) c.voice.http = { urlTemplate: '', method: 'GET', headers: '', body: '' }
  c.voice.http.urlTemplate = String(c.voice.http.urlTemplate ?? '').trim()
  const httpMethod = String(c.voice.http.method ?? '').trim().toUpperCase()
  c.voice.http.method = httpMethod === 'POST' ? 'POST' : 'GET' // 只认 GET/POST，其余（尤其 PUT）一律当 GET
  const headerText = (v) => {
    if (typeof v === 'string') return v
    if (Array.isArray(v)) return v.map(String).join('\n')
    if (v && typeof v === 'object') return Object.entries(v).map(([k, val]) => `${k}: ${val}`).join('\n')
    return v == null ? '' : String(v)
  }
  const bodyText = (v) => {
    if (typeof v === 'string') return v
    if (v && typeof v === 'object') { try { return JSON.stringify(v) } catch (error) { return '' } }
    return v == null ? '' : String(v)
  }
  c.voice.http.headers = headerText(c.voice.http.headers)
  c.voice.http.body = bodyText(c.voice.http.body)
  c.voice.cosyvoice.sampleRate = num(c.voice.cosyvoice.sampleRate, 22050, 8000, 48000)
  if (!['sft', 'instruct'].includes(c.voice.cosyvoice.mode)) c.voice.cosyvoice.mode = 'sft'
  // edge-tts 的语速 / 音调：只认 ±N% 和 ±NHz，写着玩的回落默认值，超范围的夹回来。
  // ⚠ 0 也必须带符号：面板的选项是 '+0%' / '+0Hz'，少了正号既对不上下拉框，
  //   又会让 `rate !== '+0%'` 成立、把 --rate=0% 传给 edge-tts（它会直接报错）。
  const signed = (n, unit) => (n < 0 ? '-' : '+') + Math.abs(n) + unit
  const pct = /^([+-]?\d{1,3})\s*%$/.exec(String(c.voice.rate || '').trim())
  c.voice.rate = signed(pct ? Math.max(-50, Math.min(50, Number(pct[1]))) : 0, '%')
  const hz = /^([+-]?\d{1,3})\s*Hz$/i.exec(String(c.voice.pitch || '').trim())
  c.voice.pitch = signed(hz ? Math.max(-80, Math.min(80, Number(hz[1]))) : 0, 'Hz')
  c.imageGen.enabled = bool(c.imageGen.enabled, false)
  c.imageGen.ownerOnly = bool(c.imageGen.ownerOnly, true)
  c.imageGen.seeOwn = bool(c.imageGen.seeOwn, true)
  if (!/^\d{3,4}x\d{3,4}$/.test(String(c.imageGen.size))) c.imageGen.size = '1024x1024'
  c.imageGen.galleryShown = Math.min(50, Math.max(1, Math.round(Number(c.imageGen.galleryShown) || 20)))
  c.imageGen.shape = ['her', 'square', 'portrait', 'landscape', 'wide'].includes(c.imageGen.shape) ? c.imageGen.shape : 'her'

  // provider：custom = 自己填接口（GET/POST + 自定义参数），其它按 OpenAI 兼容
  c.imageGen.provider = ['custom', 'codex'].includes(c.imageGen.provider) ? c.imageGen.provider : 'openai'
  if (!isObj(c.imageGen.codex)) c.imageGen.codex = { ...DEFAULTS.imageGen.codex }
  const igx = c.imageGen.codex
  igx.model = ['gpt-image-2', 'gpt-image-2.5-flare', 'gpt-image-2.5-sunburst'].includes(igx.model) ? igx.model : 'gpt-image-2'
  igx.quality = ['auto', 'low', 'medium', 'high', 'xhigh', 'max'].includes(igx.quality) ? igx.quality : 'auto'
  igx.background = ['auto', 'transparent', 'opaque'].includes(igx.background) ? igx.background : 'auto'
  if (!c.imageGen.custom || typeof c.imageGen.custom !== 'object') c.imageGen.custom = { ...DEFAULTS.imageGen.custom }
  const igc = c.imageGen.custom
  igc.method = String(igc.method || 'GET').toUpperCase() === 'POST' ? 'POST' : 'GET'
  igc.bodyType = igc.bodyType === 'form' ? 'form' : 'json'
  igc.url = String(igc.url || '').trim().slice(0, 2000)
  igc.responsePath = String(igc.responsePath || '').trim().slice(0, 200)
  igc.params = (Array.isArray(igc.params) ? igc.params : [])
    .map((p) => ({ key: String((p && p.key) || '').trim().slice(0, 60), value: String(p && p.value != null ? p.value : '').slice(0, 500) }))
    .filter((p) => p.key)
    .slice(0, 30)

  if (!isObj(c.modules)) c.modules = {}
  for (const [id, m] of Object.entries(c.modules)) {
    if (id === 'market') continue // market 是市场记账块，不是模块设置（下面单独归一化，默认 OFF）
    if (!isObj(m)) { delete c.modules[id]; continue }
    m.enabled = bool(m.enabled, true)
    m.useBuiltin = bool(m.useBuiltin, false)
  }
  if (!isObj(c.modules.market)) c.modules.market = {}
  const market = c.modules.market
  market.enabled = bool(market.enabled, false)
  // 索引源只收 https（缺陷：indexUrls 无协议白名单，可指向内网 http 服务）。
  market.indexUrls = Array.isArray(market.indexUrls) ? market.indexUrls.map((s) => String(s).trim()).filter((s) => /^https:\/\//i.test(s)).slice(0, 10) : []
  // 市场专用 HTTP 代理：不接受凭据/路径/查询，避免公开面板回传代理账号密码。
  try {
    const proxy = new URL(String(market.httpProxy || '').trim())
    market.httpProxy = ['http:', 'https:'].includes(proxy.protocol) && !proxy.username && !proxy.password && !proxy.search && !proxy.hash && proxy.pathname === '/'
      ? proxy.origin : ''
  } catch { market.httpProxy = '' }
  if (!isObj(market.installed)) market.installed = {}
  if (!isObj(c.ext)) c.ext = {}
  for (const k of Object.keys(c.ext)) if (!isObj(c.ext[k])) delete c.ext[k] // 传 null = 删掉这个模块的设置
  if (!isObj(c.multiParser)) c.multiParser = {}
  const mp = c.multiParser
  mp.enabled = bool(mp.enabled, false)
  mp.inGroups = bool(mp.inGroups, true)
  mp.inPrivate = bool(mp.inPrivate, true)
  if (!Array.isArray(mp.disabledGroups)) mp.disabledGroups = []
  mp.disabledGroups = mp.disabledGroups.map((g) => String(g).replace(/\D/g, '')).filter((g) => g.length >= 4).slice(0, 100)
  mp.feedToAi = bool(mp.feedToAi, true)
  mp.sendMedia = bool(mp.sendMedia, true)
  mp.forwardMode = ['threshold', 'always', 'never'].includes(mp.forwardMode) ? mp.forwardMode : 'threshold'
  mp.imageThreshold = num(mp.imageThreshold, 2, 1, 30)
  mp.maxVideoMB = num(mp.maxVideoMB, 100, 5, 500)
  mp.videoOverLimit = ['direct_link', 'group_file', 'notice'].includes(mp.videoOverLimit) ? mp.videoOverLimit : 'direct_link'
  if (!isObj(mp.platforms)) mp.platforms = {}
  for (const k of ['bilibili', 'douyin', 'redbook', 'weibo', 'zhihu', 'wechat', 'tieba', 'fanqie', 'github', 'xiaoheihe']) {
    mp.platforms[k] = bool(mp.platforms[k], true)
  }
  if (!isObj(mp.cookies)) mp.cookies = {}
  for (const k of ['bilibili', 'weibo', 'redbook', 'zhihu', 'tieba', 'douyin', 'xiaoheihe']) {
    mp.cookies[k] = String(mp.cookies[k] || '').trim()
  }

  c.safeMode = bool(c.safeMode, false)
  c.bridge.dshTools = bool(c.bridge.dshTools, false)
  c.bridge.http = bool(c.bridge.http, false)
  c.bridge.token = String(c.bridge.token || '')
  if (!['whitelist', 'owner'].includes(c.bridge.allowTargets)) c.bridge.allowTargets = 'whitelist'
  // 1.4.0-beta.4 起部分功能整体移除。deepMerge 会把老配置里的键原样带进来，
  // 只删 DEFAULTS 不够 —— 残留的 song / neteaseCookie 会绕过已删除的 SECRETS 脱敏条目
  // 明文回传面板。这里显式丢掉（含 modules 下的设置块与 voice 的翻唱参数）。
  delete c.song
  delete c.local.song
  delete c.mood
  delete c.modules.song
  delete c.modules.mood
  delete c.voice.songVoice
  delete c.voice.songPitch
  return c
}

// 面板里不回传原文的字段：路径（几层都行）
const SECRETS = [
  ['snowluma', 'webuiPassword'], ['snowluma', 'httpToken'], ['snowluma', 'wsToken'],
  ['imageGen', 'apiKey'],
  // 语音引擎的云端凭据：豆包 / 百炼 / MiMo（掩码 + 留空保存保留原值，同 imageGen 口径）
  ['voice', 'doubao', 'apiKey'],
  ['voice', 'qwentts', 'apiKey'],
  ['voice', 'mimo', 'apiKey'],
  ['bili', 'cookie'], ['bili', 'sessdata'], ['bili', 'biliJct'],
  ['heybox', 'cookie'], ['bridge', 'token'],
  ['multiParser', 'cookies', 'bilibili'],
  ['multiParser', 'cookies', 'weibo'],
  ['multiParser', 'cookies', 'redbook'],
  ['multiParser', 'cookies', 'zhihu'],
  ['multiParser', 'cookies', 'tieba'],
  ['multiParser', 'cookies', 'douyin'],
  ['multiParser', 'cookies', 'xiaoheihe'],
  // 向量通道 API Key（1.4.5）：模块 password 字段的动态登记（registerSecretField）在运行环境
  // 未生效（memory 是该机制首个使用者，疑似模块实例隔离问题，待查），静态清单双保险：
  // 掩码（publicConfig）与「留空保存保留原值」（mergeFromPanel）都依赖这份清单。
  ['ext', 'memory', 'vectorApiKey'],
  // 精排 API Key（#146）同口径进静态清单（缺陷：rerankApiKey 漏进 SECRETS，明文回传面板）。
  ['ext', 'memory', 'rerankApiKey'],
]
// 扩展模块设置里的密码类字段（模块加载时登记）：['ext', 模块id, 字段]
const extraSecrets = new Map()
export function registerSecretField(path) { extraSecrets.set(path.join('\u0000'), path) }
const allSecrets = () => [...SECRETS, ...extraSecrets.values()]
const parentOf = (obj, path, create) => {
  let cur = obj
  for (const k of path.slice(0, -1)) {
    if (!isObj(cur[k])) { if (!create) return null; cur[k] = {} }
    cur = cur[k]
  }
  return cur
}
const getAt = (obj, path) => { const p = parentOf(obj, path, false); return p ? p[path.at(-1)] : undefined }
// 这些密钥在面板里显示结尾几位（「已保存（结尾 …a1b2）」），方便认出存的是哪一份；完整值不回传
const HINTED = [['bili', 'sessdata'], ['bili', 'biliJct']]

/** 从一串 Cookie 里取某个值（「SESSDATA=xxx; bili_jct=yyy」）。 */
export function cookieValue(raw, key) {
  for (const part of String(raw || '').split(/;\s*/)) {
    const i = part.indexOf('=')
    if (i > 0 && part.slice(0, i).trim() === key) return part.slice(i + 1).trim()
  }
  return ''
}

/**
 * B 站 Cookie 整理成两个值：粘了整串 / 带了「SESSDATA=」前缀的都认得；老配置只有整串的拆开。
 * 返回 {sessdata, biliJct, cookie}，cookie 是拼好给接口用的。
 */
export function splitBiliCookie({ sessdata = '', biliJct = '', cookie = '' } = {}) {
  const a = String(sessdata || '').trim()
  const b = String(biliJct || '').trim()
  // 框里粘的是「xxx=…」这种整串或带前缀的：从里面取；纯值原样用
  const isRaw = (v) => /(^|;\s*)(SESSDATA|bili_jct)=/.test(v)
  let s = isRaw(a) ? '' : a
  let j = isRaw(b) ? '' : b
  for (const v of [a, b]) {
    if (!isRaw(v)) continue
    s = cookieValue(v, 'SESSDATA') || s
    j = cookieValue(v, 'bili_jct') || j
  }
  if (!s && !j && cookie) {
    s = cookieValue(cookie, 'SESSDATA')
    j = cookieValue(cookie, 'bili_jct')
  }
  return { sessdata: s, biliJct: j, cookie: [s && `SESSDATA=${s}`, j && `bili_jct=${j}`].filter(Boolean).join('; ') }
}

const FILE = () => dataDir('config.json')

/** 在某次更新里新增、会替她公开发东西的功能。以后再加这类功能，把配置键名加到这里。 */
export const OPT_IN_ON_UPDATE = ['qzoneSocial', 'bili', 'douyin']

/** group.maxPerHour 的语义版本。2 = 「每小时说话总条数」（令牌桶速率）；1/缺省 = 「每小时插话次数」。 */
export const GROUP_BUDGET_VERSION = 2

/**
 * 一次性迁移：`maxPerHour` 的口径从「每小时插话次数」改成「每小时说话总条数」。
 *
 * 老口径下这个数只数 interjectTimes，而每次插话成功还会白送 engagedMaxReplies 条「连聊」，
 * 所以真实上限是 `maxPerHour × (1 + engagedMaxReplies)`（实测 6 → 22.5 条/小时）。
 * 新口径直接数总条数，按同一个系数折算一次，升级后观感不变 —— 用户自己调过的大值同样折算，
 * 想再调低就去面板改（面板现在能看到连聊预算了）。
 *
 * 只折算一次：迁移完写 `budgetVersion`，以后不再碰用户的值。
 */
function migrateGroupBudget(raw) {
  if (!isObj(raw?.group)) return raw
  const g = raw.group
  if (g.budgetVersion === GROUP_BUDGET_VERSION) return raw
  const perHour = Number(g.maxPerHour)
  if (Number.isFinite(perHour) && perHour > 0) {
    const rawEngaged = Number(g.engagedMaxReplies)
    const engaged = Number.isFinite(rawEngaged) && rawEngaged > 0 ? rawEngaged : 0
    g.maxPerHour = Math.min(200, Math.round(perHour * (1 + engaged)))
  }
  g.budgetVersion = GROUP_BUDGET_VERSION
  return raw
}

export function loadConfig() {
  const raw = readJson(FILE(), {})
  // 老配置（向导上线前就填好了两个号）直接算向导已完成
  if (raw && raw.setupDone === undefined && raw.botQQ && raw.ownerQQ) raw.setupDone = true
  // 更新插件后新增的、会公开发东西的功能：老用户先关着，等他们自己在面板里打开（新安装照常默认开）
  if (raw && raw.setupDone) for (const k of OPT_IN_ON_UPDATE) if (raw[k] === undefined) raw[k] = { enabled: false }
  migrateGroupBudget(raw)
  return normalize(raw)
}

export function saveConfig(cfg) {
  const c = normalize(cfg)
  // config.json 明文含 webuiPassword/httpToken/wsToken/imageGen.apiKey/bridge.token，收紧到 0600（S5）
  writeJson(FILE(), c, { mode: 0o600 })
  return c
}

/** 给面板看的版本：密码 / token 不回传原文，只告诉有没有填。 */
export function publicConfig(cfg) {
  const c = structuredClone(cfg)
  for (const [g, k] of HINTED) c[g][`${k}Hint`] = c[g][k] ? '…' + String(c[g][k]).slice(-4) : ''
  for (const path of allSecrets()) {
    const p = parentOf(c, path, false)
    if (!p) continue
    const k = path.at(-1)
    p[`${k}Set`] = Boolean(p[k])
    p[k] = ''
  }
  return c
}

/** 面板保存时：没改的密码字段（空串）保留原值。 */
export function mergeFromPanel(current, incoming) {
  const next = deepMerge(current, incoming || {})
  for (const path of allSecrets()) {
    const v = getAt(incoming || {}, path)
    const p = parentOf(next, path, v !== undefined)
    if (!p) continue
    const k = path.at(-1)
    if (v === null) p[k] = '' // 明确传 null = 清空
    else if (v === undefined || v === '') p[k] = getAt(current, path) ?? ''
    delete p[`${k}Set`]
    delete p[`${k}Hint`]
  }
  // 主人的抖音 secUid / uid / 昵称只能由「核对」写入，面板存配置时保留原值
  next.douyin.owner = { ...next.douyin.owner, ...Object.fromEntries(['secUid', 'uid', 'nickname', 'confirmedInput'].map((k) => [k, current.douyin?.owner?.[k] ?? ''])) }
  // 联动密钥只由插件生成，面板不能改
  next.bridge.token = current.bridge?.token || ''
  // B 站：只改了其中一个值时，另一个保留；整串粘进来的会在 normalize 里拆开
  if (incoming?.bili && (incoming.bili.sessdata || incoming.bili.biliJct)) next.bili.cookie = ''
  // 按群单独设置：防局部 PATCH 抹掉其它群，同时保留群原有的内部字段（如 minRelevance）
  if (incoming?.group?.overrides !== undefined) {
    if (isObj(incoming.group.overrides)) {
      const isFullGroupSubmit = incoming.group.interjectChance !== undefined || incoming.group.wakeWords !== undefined || incoming.enabled !== undefined
      const baseOverrides = isFullGroupSubmit ? {} : { ...(current.group?.overrides || {}) }
      const merged = { ...baseOverrides }
      for (const [gid, over] of Object.entries(incoming.group.overrides)) {
        if (over === null) {
          delete merged[gid]
        } else if (isObj(over)) {
          merged[gid] = { ...(current.group?.overrides?.[gid] || {}), ...over }
        }
      }
      next.group.overrides = merged
    } else {
      next.group.overrides = {}
    }
  }
  // 按聊天选模型：两张表整张替换（deepMerge 会让删掉的条目又回来）
  if (incoming?.chatModels?.privates !== undefined) next.chatModels.privates = incoming.chatModels.privates
  if (incoming?.chatModels?.groups !== undefined) next.chatModels.groups = incoming.chatModels.groups
  // 按聊天选人设：两张表整张替换（deepMerge 会让删掉的条目又回来）
  if (incoming?.persona?.privates !== undefined) next.persona.privates = incoming.persona.privates
  if (incoming?.persona?.groups !== undefined) next.persona.groups = incoming.persona.groups
  if (incoming?.allow) next.allow = { ...current.allow, ...incoming.allow }
  return normalize(next)
}
