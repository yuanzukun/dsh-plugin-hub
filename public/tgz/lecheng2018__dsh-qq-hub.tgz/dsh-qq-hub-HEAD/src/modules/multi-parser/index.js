// 多平台内容解析器模块（移植自 astrbot_plugin_multi_parser）
//
// 1. 自动识别聊天中的链接，提取标题、作者、高清大图、无水印视频；
// 2. 具备【AI 注入开关 (feedToAi)】：将解析内容注入大模型上下文，让 AI 能读懂并参与聊天；
// 3. 支持 QQ 合并转发卡片与视频群文件转存，防刷屏。

import { extractUrls, parseUrl } from './parser.js'
import { deliverParseResult } from './delivery.js'
import { sweepMediaDir } from '../../douyin/media.js'

const ID = 'multi-parser'


/**
 * 这个聊天里要不要提供解析（纯函数，方便测）。
 *
 * 分三层：群开不开 → 私聊开不开 → 这个群有没有被单独关掉。
 * 默认全开，行为不变；关掉后**连链接都不碰**（不发卡片、不下载、不占带宽）。
 * @param {{kind?:string, chatId?:string, groupId?:string}} msg
 * @param {object} c multi-parser 配置
 */
export function allowedHere(msg, c = {}) {
  const kind = msg && msg.kind
  if (kind === 'group') {
    if (c.inGroups === false) return false
    const gid = String((msg && (msg.groupId || (String(msg.chatId || '').startsWith('group:') ? String(msg.chatId).slice(6) : ''))) || '')
    const off = Array.isArray(c.disabledGroups) ? c.disabledGroups.map(String) : []
    return !(gid && off.includes(gid))
  }
  if (kind === 'private') return c.inPrivate !== false
  // system 后台轮次不解析
  return false
}

export default {
  id: ID,
  name: '内容解析',
  version: '1.0.0',
  api: 1,
  tab: 'multiParser',
  description: '自动识别消息中的 B站/微博/小红书/知乎/微信/贴吧/番茄/GitHub等链接，发送无水印图文视频并支持AI上下文注入',
  defaults: {
    enabled: false,
    feedToAi: true,
    // 纯解析模式：解析出内容后只说这一条，不再让她接着聊
    // （她看不到视频画面，硬聊只能靠标题和口令里的字编，容易跑偏）
    muteAi: false,
    sendMedia: true,
    forwardMode: 'threshold',
    imageThreshold: 2,
    maxVideoMB: 100,
    videoOverLimit: 'direct_link',
  },
  setup(api) {
    // chatId -> { at, result } 记录最近解析的内容
    const recentParsed = new Map()

    // 启动兜底：正常情况下视频发完就删了，这里只收进程中途崩掉留下的孤儿文件。
    // 按 6 小时 + 500MB 双阈值扫，超出的清掉，免得长期跑把盘吃满。
    try {
      const dir = typeof api.workspaceDir === 'function' ? api.workspaceDir('multi-parser-media') : ''
      if (dir) {
        const r = sweepMediaDir(dir, { maxAgeMs: 6 * 3600_000, maxBytes: 500 * 1024 * 1024 })
        if (r.removed) api.log.info(`[multi-parser] 启动清理：删掉 ${r.removed} 个残留视频（${(r.bytes / 1024 / 1024).toFixed(1)} MB）`)
      }
    } catch (err) {
      api.log.debug?.('[multi-parser] 启动清理跳过：', err.message)
    }

    const cfg = () => {
      const g = api.config().multiParser || {}
      const full = api.config()
      const rawCookies = g.cookies || {}
      const cookies = {
        bilibili: rawCookies.bilibili || full.bili?.cookie || (full.bili?.sessdata ? `SESSDATA=${full.bili.sessdata}` : ''),
        douyin: rawCookies.douyin || '',
        redbook: rawCookies.redbook || '',
        weibo: rawCookies.weibo || '',
        zhihu: rawCookies.zhihu || '',
        tieba: rawCookies.tieba || '',
        xiaoheihe: rawCookies.xiaoheihe || full.heybox?.cookie || '',
      }
      return { ...g, platforms: g.platforms || {}, cookies }
    }

    // 🌟 AI 上下文注入机制：大模型对话前，若当前聊天有新鲜解析的内容，自动拼入提示词
    // 注意：视频类结果不注入——AI 看不到视频内容，注入只会让她对着链接干瞪眼
    api.context(({ chat }) => {
      const c = cfg()
      if (!c.enabled || !c.feedToAi) return ''

      const recent = recentParsed.get(chat?.chatId)
      if (!recent || Date.now() - recent.at > 3 * 60_000) return ''

      const r = recent.result
      // 视频一律不注入：她看不到画面，把标题喂给她只会让她对着几个字瞎猜
      // （以前只判 type==='video'，但抖音的 type 由 images.length 决定，
      //   带封面的作品会变成 gallery 从而漏进来，她就照着标题在那儿编）
      if (r.videoUrl || r.type === 'video') {
        // 只告诉她「收到一条视频」这个事实，不给标题、作者、数据，免得她去猜内容
        return `【系统提示：对方刚发来一条${r.platformName}视频，已经直接发到聊天里了。你没法看视频画面，所以不要猜测或编造视频内容，也不要就视频里的具体信息提问或装作看过。】`
      }

      const statLine = r.stat ? `\n数据：${r.stat}` : ''
      return `【系统提示：对方刚才在聊天中分享了一条来自 ${r.platformName} 的链接】\n` +
             `标题：《${r.title}》\n` +
             `作者：${r.author || '未知'}\n` +
             `内容摘要：${r.summary || '无'}${statLine}\n` +
             `（提示：你可以根据以上内容自然地接话、吐槽或发表看法，像真人一样随性交流，不要生硬背诵）`
    })

    // 监听进站消息，检测链接
    api.on('message', async (msg) => {
      const c = cfg()
      if (!c.enabled) return false
      // 群/私聊分流：群里不想让她解析时连链接都不碰（不然还是会发卡片、下载视频、占带宽）
      if (!allowedHere(msg, c)) return false

      const urls = extractUrls(msg.text)
      if (!urls.length) return false

      let handledAny = false

      for (const rawUrl of urls.slice(0, 3)) {
        try {
          const result = await parseUrl(rawUrl, { platforms: c.platforms, cookies: c.cookies, rawText: msg.text })
          if (!result) continue

          handledAny = true
          api.log.info(`[multi-parser] 成功解析 ${result.platformName} 链接: ${result.title}`)

          // 记录到最近解析表，供 AI 注入读取
          recentParsed.set(msg.chatId, { at: Date.now(), result })

          // 发送到 QQ
          if (c.sendMedia) {
            await deliverParseResult(api, msg.chatId, result, c)
          }
        } catch (err) {
          api.log.debug(`[multi-parser] 解析链接失败 (${rawUrl}):`, err.message)
        }
      }

      // 解析成功且关掉了「让她接着聊」→ 返回 true 表示这条消息被接管，她不会再回
      // （host 那边 claim('message') 返回真值就跳过唤醒）
      if (handledAny && c.muteAi) return true
      // 否则返回 false：让消息继续往后流转，模型可以同时参与回复
      return false
    })

    // 面板测试接口：手动输入链接测试解析效果
    api.route('/multi-parser/test', async (req) => {
      const body = await api.core.http.body(req)
      const input = String(body.url || '').trim()
      if (!input) return { ok: false, message: '请提供测试链接或口令文本' }

      try {
        const c = cfg()
        const urls = extractUrls(input)
        const targetUrl = urls[0] || input
        const result = await parseUrl(targetUrl, { platforms: c.platforms, cookies: c.cookies, rawText: input })
        if (!result) return { ok: false, message: '暂不支持该平台链接或解析失败' }
        return { ok: true, result }
      } catch (err) {
        return { ok: false, message: '解析异常：' + err.message }
      }
    })

    // 面板状态接口
    api.route('/multi-parser/status', async () => {
      const c = cfg()
      const ck = c.cookies || {}
      return {
        ok: true,
        active: c.enabled,
        recentCount: recentParsed.size,
        cookieStatus: {
          bilibili: Boolean(ck.bilibili),
          weibo: Boolean(ck.weibo),
          redbook: Boolean(ck.redbook),
          zhihu: Boolean(ck.zhihu),
          tieba: Boolean(ck.tieba),
          douyin: Boolean(ck.douyin),
          xiaoheihe: Boolean(ck.xiaoheihe),
        },
        platforms: [
          'bilibili (B站)', 'weibo (微博)', 'redbook (小红书)', 'zhihu (知乎)',
          'wechat (微信公众号)', 'tieba (百度贴吧)', 'fanqie (番茄小说)',
          'github (GitHub)', 'douyin (抖音)', 'xiaoheihe (小黑盒)',
        ],
      }
    })

    return {
      parse: (url) => parseUrl(url, { platforms: cfg().platforms, cookies: cfg().cookies }),
      recent: () => [...recentParsed.values()],
    }
  },
}
