// M2-D · Outbox：统一投递出口（纯模块；sender 注入，fake/真实 OneBot 适配器都实现同一签名）
//
// 职责（任务书 M2-D）：
//   - 统一投递条目 + 每聊天 FIFO + 授权复核 + dryRun + 取消 + 真实回执 + unknown；
//   - 三态结果如实返回：sent（带网关真实 messageId）/ failed（确定没发出去）/ unknown（副作用未知）；
//   - **unknown 绝不自动重试**——重试条件必须有状态依据（ADR-0001 红线）；
//   - 崩溃恢复（sending → unknown）由 delivery-ledger 承担，本层尊重台账不重放。
//
// 2026-11-08 复核修复（报告 §4.2/§4.3/§4.4/§5）：
//   - FIFO：enqueue 与链注册之间**不引入任何 await**——授权挪到出队时执行，
//     慢授权不再被后入队的快授权超车；撤权发生在排队期间也能拦住（出队重查台账 + 重跑 authorize）。
//   - 全局闸：enabled/dryRun 在出队时刻动态复核（注入回调），不依赖入口或命令分支的一次性快照。
//   - 身份泄露闸：guard 注入回调在唯一出站点生效，**force 不豁免**（命令回复同样可能带出别人的号）。
//   - force 的边界（2026-11-12 收窄）：只豁免「总开关关闭」，让 /on 这类命令在关闸后仍能回话；
//     它**不豁免 dryRun**（试运行就是不真发，与开闸是两件事），也不豁免身份闸。
//     以前 force 三者全豁免，默认姿态（总开关关 + 试运行开）下主人发 /status 就会真的发到 QQ。
//   - 台账 fail-closed：enqueue / sending 落盘失败 = 不发起物理发送。
//   - dispose：真实卸载——之后拒绝新请求，并把还在排队的条目落 cancelled。
//
// 2026-11-12 轮原子性修正（reserve/ticket）：
//   - 改前：轮内每条气泡 request 都把链写回 chains（把 reserve 建的闸覆盖掉），且都锚在
//     reserve 时刻的 previous 快照上 —— 于是「第一个气泡之后入队的写者」既不排在闸上、
//     也不排在气泡之后，实测同聊天两条物理发送同时在飞、别人的文字插进本轮两段气泡之间。
//   - 改后：chains 本轮期间恒为闸；轮内气泡走 ticket.tail 严格串行；release 会等本轮
//     最后一条气泡落地才开闸。语义仍是「轮原子性」：A1、A2 连续，B 排到本轮之后。
//
// 红线：本模块不做业务决策（不发主动发言、不改内容）；内容清洗/分条是适配层（M3-C）的事。

import { parseChatKey } from './chat-key.js'
import { createDeliveryLedger, newDeliveryId } from './delivery-ledger.js'

export { newDeliveryId }

/**
 * @param {object} o
 * @param {(action: string, params: object, opts?: object) => Promise<{messageId?: string, raw?: object}>} o.send
 *   物理发送注入点；抛错时 error.unknown === true 表示副作用未知。
 * @param {object} [o.ledger] 已有台账（缺省自建内存台账）
 * @param {(delivery: object) => Promise<boolean>} [o.authorize] 授权复核（缺省全放行；出队时执行）
 * @param {() => boolean} [o.dryRun] 全局试运行注入（出队时动态读取；true = 只记台账不实发）
 * @param {() => boolean} [o.enabled] 全局总开关注入（出队时动态读取；false = 不发）
 * @param {(delivery: object) => {ok: boolean, message?: string}} [o.guard] 身份泄露闸注入
 */
export function createOutbox({ send, ledger, authorize, dryRun, enabled, guard, currentTicket } = {}) {
  if (typeof send !== 'function') throw new TypeError('send 必须是函数')
  const book = ledger || createDeliveryLedger({})
  /** chatKey -> Promise（发送串行链，保证每聊天 FIFO） */
  const chains = new Map()
  /** 还没出队的 deliveryId（dispose 清理对象） */
  const pending = new Set()
  /** PR-1 直通模式登记：deliveryId -> {action, params, opts, receipt} */
  const passMap = new Map()
  // 临时会话（SnowLuma 能力补齐）：私聊 QQ → 最近一次临时会话的来源群。
  // 只有入站 ACL 放行的消息才登记（routeInboundCore 调 notePrivateSource）；
  // 回复私聊时带上 group_id，SnowLuma 才会送进临时会话。普通私聊不受影响。
  const privateSources = new Map()
  let disposed = false

  /**
   * 预留一轮的「会话占用」：返回 ticket（本轮气泡串行用）+ release（本轮结束时放行）。
   *
   * 契约（2026-11-12 修正，语义仍是「轮原子性」）：
   *   - `chains[chatKey]` 在本轮期间**始终是这道闸**：别的写者挂上来，等到 release 才发；
   *   - 本轮自己的气泡走 `ticket.tail`（绕开闸），气泡之间严格串行；
   *   - release 不只开闸，还要等本轮最后一条气泡落地——所以即便调用方提前 release，
   *     其他写者也绝不会插进本轮气泡中间。
   *
   * 改前：气泡 request 会把自己的链写回 chains，把闸覆盖掉；且每条气泡都锚在 reserve
   * 时刻的 `previous` 上（快照），于是轮内第 2 条之后的写者跟气泡互不排队 ——
   * 实测出现「同聊天两条物理发送同时在飞、其他写者的文字插在两段回复中间」。
   */
  function reserve(chatKey) {
    if (disposed) return null
    parseChatKey(chatKey)
    // tail：本轮已入队气泡的链尾（第一条从 previous 起算），轮内串行只认它
    const ticket = { chatKey, previous: chains.get(chatKey) || Promise.resolve(), tail: null, chain: null }
    let releaseGate
    const gate = new Promise((resolve) => { releaseGate = resolve })
    const chain = ticket.previous.catch(() => {}).then(() => gate)
    ticket.chain = chain
    chains.set(chatKey, chain)
    const cleanup = () => { if (chains.get(chatKey) === chain) chains.delete(chatKey) }
    chain.then(cleanup, cleanup)
    return {
      ticket,
      // 先等本轮气泡全部落地，再开闸：保证「别的写者排在本轮之后」而不只是「之后入队」
      release: () => {
        Promise.resolve(ticket.tail || ticket.previous).catch(() => {}).then(() => releaseGate())
      },
    }
  }

  /**
   * 请求发送（模块/核心统一入口）。
   * 消息模式使用 segments；直通模式使用 action + params + opts + receipt。
   * receipt=required 时无 messageId 必须记 unknown；optional 用于 upload/poke/qzone 等动作。
   */
  async function request(req) {
    if (disposed) throw new Error('outbox 已卸载')
    const chatKey = String(req?.chatKey ?? '')
    parseChatKey(chatKey)
    const passThrough = Boolean(req?.action)
    const segments = req?.segments ?? []
    if (!passThrough && (!Array.isArray(segments) || segments.length === 0)) {
      throw new TypeError('segments 必须是非空数组')
    }
    if (passThrough && (!req.params || typeof req.params !== 'object')) {
      throw new TypeError('直通模式必须提供 params')
    }
    const deliveryId = String(req?.deliveryId || newDeliveryId())
    if (passThrough) passMap.set(deliveryId, { action: req.action, params: req.params, opts: req.opts, receipt: req.receipt || 'required' })
    // 同步登记台账：FIFO 顺序 = enqueue 顺序（台账落盘失败 fail-closed 直接抛出，不发送）
    let rec
    try {
      rec = book.enqueue({
        deliveryId,
        chatKey,
        turnId: req?.turnId,
        sourceModuleId: req?.sourceModuleId,
        segments,
        note: req.note,
        action: passThrough ? req.action : undefined,
      })
    } catch (error) {
      passMap.delete(deliveryId)
      throw error
    }

    // 按次试运行：调用方显式语义，不排队（无 await 在 enqueue 与链注册之间插入任何东西）
    if (req?.dryRun === true) {
      passMap.delete(deliveryId)
      book.mark(deliveryId, 'cancelled', { reason: 'dryRun' })
      return { state: 'cancelled', deliveryId, reason: 'dryRun' }
    }

    // 每聊天 FIFO：链注册同步发生，慢授权不会被后入队的快授权超车。
    // 带票（轮内气泡）时串到「本轮上一条」而不是 reserve 时的快照，且**不写回 chains**——
    // 闸要一直留在 chains 里给别的写者排队，否则第一个气泡就会把闸覆盖掉（改前的 bug）。
    // 票是「按聊天」的：轮内跨聊天发送不得误用别的聊天的票，所以校验 chatKey。
    const inherited = currentTicket?.() || null
    const ticket = req?._outboxTicket || (inherited && inherited.chatKey === chatKey ? inherited : null)
    const prev = ticket
      ? (ticket.tail || ticket.previous || Promise.resolve())
      : (chains.get(chatKey) || Promise.resolve())
    const chain = prev.catch(() => {}).then(() => drainOne(rec, req))
    if (ticket) ticket.tail = chain
    else chains.set(chatKey, chain)
    pending.add(deliveryId)
    const cleanup = () => {
      pending.delete(deliveryId)
      passMap.delete(deliveryId)
      if (chains.get(chatKey) === chain) chains.delete(chatKey)
    }
    chain.then(cleanup, cleanup)
    return chain
  }

  /** 出队处理：台账复核 → 全局闸 → 授权（再复核台账）→ 身份闸 → sending 落盘 → 物理发送。 */
  async function drainOne(rec, req) {
    const { deliveryId, chatKey } = rec
    const force = req?.force === true

    let current = book.get(deliveryId)
    if (!current || current.state !== 'queued') {
      return { state: current?.state ?? 'cancelled', deliveryId, reason: '排队期间台账已变更（取消 / 重复请求）' }
    }

    // 试运行永不豁免：force 只用来让命令在总开关关着时能回话，不代表可以真发。
    // 顺序放在 enabled 之前，与 legacy sendSegments 同口径（先看「允不允许发」再看「发不发得出去」）。
    if (dryRun?.() === true) {
      book.mark(deliveryId, 'cancelled', { reason: 'dryRun' })
      return { state: 'cancelled', deliveryId, reason: 'dryRun' }
    }
    // 总开关：force 可豁免——这是 /on 的自救通道，关闸后主人还能把闸重新打开
    if (!force && enabled && !enabled()) {
      book.mark(deliveryId, 'cancelled', { reason: '总开关关闭' })
      return { state: 'cancelled', deliveryId, reason: '总开关关闭' }
    }

    const passInfo = passMap.get(deliveryId)
    const view = () => ({ ...current, action: passInfo?.action, params: passInfo?.params, note: current.note })

    if (authorize) {
      let ok = false
      try {
        ok = await authorize(view())
      } catch {
        ok = false
      }
      if (!ok) {
        book.mark(deliveryId, 'cancelled', { reason: 'authorize 拒绝' })
        return { state: 'cancelled', deliveryId, reason: 'authorize 拒绝' }
      }
      current = book.get(deliveryId)
      if (!current || current.state !== 'queued') {
        return { state: current?.state ?? 'cancelled', deliveryId, reason: '授权期间台账已变更（取消）' }
      }
    }

    // 身份泄露闸：force 不豁免——命令回复（/status 等）同样可能带出主人 QQ、别的群号
    if (guard) {
      try {
        const g = guard(view())
        if (g && g.ok === false) {
          book.mark(deliveryId, 'cancelled', { reason: `身份泄露闸：${g.message || ''}` })
          return { state: 'cancelled', deliveryId, reason: '身份泄露闸' }
        }
      } catch { /* 闸本身出错：legacy 同语义放行 */ }
    }

    // 标记 sending：关键落盘失败时不发起物理发送。
    try {
      book.mark(deliveryId, 'sending')
    } catch (error) {
      return { state: 'failed', deliveryId, reason: `台账 sending 落盘失败，fail-closed 未实发：${error?.message || error}` }
    }
    const pass = passMap.get(deliveryId)
    let action, params, opts, receipt
    if (pass) {
      action = pass.action; params = pass.params; opts = pass.opts; receipt = pass.receipt
    } else {
      const parsed = parseChatKey(chatKey)
      action = parsed.kind === 'group' ? 'send_group_msg' : 'send_private_msg'
      const sourceGroupId = parsed.kind === 'private' ? privateSources.get(parsed.id) : ''
      params = parsed.kind === 'group'
        ? { group_id: Number(parsed.id), message: req.segments }
        : { user_id: Number(parsed.id), ...(sourceGroupId ? { group_id: Number(sourceGroupId) } : {}), message: req.segments }
      receipt = 'required'
    }
    try {
      const result = await send(action, params, opts)
      if (receipt !== 'optional' && (result?.messageId == null || result.messageId === '')) {
        book.mark(deliveryId, 'unknown', { reason: '发送调用无异常但网关未回 messageId，不冒充 sent' })
        return { state: 'unknown', deliveryId, reason: '网关未回 messageId' }
      }
      book.mark(deliveryId, 'sent', result?.messageId != null && result.messageId !== '' ? { gatewayMessageId: result.messageId } : {})
      return {
        state: 'sent',
        deliveryId,
        ...(result?.messageId != null && result.messageId !== '' ? { gatewayMessageId: String(result.messageId) } : {}),
        ...(result?.raw !== undefined ? { raw: result.raw } : {}),
      }
    } catch (error) {
      if (error?.unknown === true) {
        book.mark(deliveryId, 'unknown', { reason: String(error?.message || '发送结果未知') })
        return { state: 'unknown', deliveryId, reason: String(error?.message || '发送结果未知') }
      }
      book.mark(deliveryId, 'failed', { reason: String(error?.message || error) })
      return { state: 'failed', deliveryId, reason: String(error?.message || error) }
    }
  }

  /** 取消还在队列里的投递（已 sending/sent 的不可取消）。 */
  function cancel(deliveryId, reason = '调用方取消') {
    const rec = book.get(deliveryId)
    if (!rec) return { state: 'unknown-delivery' }
    if (rec.state === 'queued') {
      book.mark(deliveryId, 'cancelled', { reason })
      return { state: 'cancelled' }
    }
    return { state: rec.state, reason: `已 ${rec.state}，不可取消` }
  }

  /** 卸载：拒绝新请求；还在排队的条目全部落 cancelled。 */
  function dispose() {
    if (disposed) return
    disposed = true
    privateSources.clear()
    for (const deliveryId of [...pending]) {
      try {
        const rec = book.get(deliveryId)
        if (rec && rec.state === 'queued') book.mark(deliveryId, 'cancelled', { reason: 'outbox 已卸载' })
      } catch { /* 单条清理失败不阻断卸载 */ }
    }
    pending.clear()
    passMap.clear()
    chains.clear()
  }

  /** 外部 legacy 媒体管线的发送补账：不重发、不参与队列。 */
  function recordExternal({ chatKey, sourceModuleId, segments, gatewayMessageId, state = 'sent', reason } = {}) {
    if (!ledger) return null
    const id = newDeliveryId()
    ledger.enqueue({ deliveryId: id, chatKey: String(chatKey), sourceModuleId: String(sourceModuleId || 'module'), segments: segments || [] })
    ledger.mark(id, 'sending')
    if (state === 'sent' && gatewayMessageId != null && gatewayMessageId !== '') {
      ledger.mark(id, 'sent', { gatewayMessageId: String(gatewayMessageId) })
    } else {
      ledger.mark(id, 'unknown', { reason: reason || 'external: 网关没回执' })
    }
    return id
  }

  /** 登记临时会话来源群（仅 ACL 放行后调用）；last-source-wins，空值不清除（同上游）。 */
  function notePrivateSource(userId, groupId) {
    const u = String(userId || '')
    const g = String(groupId || '')
    if (u && g && /^\d+$/.test(g)) privateSources.set(u, g)
  }

  return { request, reserve, cancel, dispose, recordExternal, notePrivateSource, ledger: book }
}
