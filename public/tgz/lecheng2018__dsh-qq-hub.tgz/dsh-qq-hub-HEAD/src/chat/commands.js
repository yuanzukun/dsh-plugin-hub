// QQ 里的主人命令：/silent /active 之类，直接在 QQ 上管她。只认主人；在总开关关着时也能用（所以 /on 才有用）。

import { dataDir, readJson, writeJson } from '../core/store.js'

/**
 * 解析命令：「/silent 30」→ { name: 'silent', arg: '30' }。不是命令返回 null。支持全角斜杠和中文别名。
 * extra：扩展模块加的命令 [{ name, aliases, desc, run }]，命中时返回 { name, arg, ext }；和内置同名时扩展的优先。
 */
export function parseCommand(text, extra = []) {
  const m = String(text || '').trim().match(/^[/／]\s*([A-Za-z0-9一-龥_-]+)\s*([\s\S]*)$/)
  if (!m) return null
  const word = m[1].toLowerCase()
  for (const c of extra) {
    const names = [c.name, ...(c.aliases || [])].map((x) => String(x).toLowerCase())
    if (names.includes(word)) return { name: c.name, arg: m[2].trim(), ext: c }
    // 中文命令后面直接跟内容：「/天气北京」
    const pre = names.filter((k) => /[一-龥]/.test(k) && word.startsWith(k)).sort((a, b) => b.length - a.length)[0]
    if (pre) return { name: c.name, arg: (m[1].slice(pre.length) + ' ' + m[2]).trim(), ext: c }
  }
  const name = ALIASES[word] || word
  if (COMMANDS[name]) return { name, arg: m[2].trim() }
  // 中文命令后面不加空格直接跟内容：「/记住我不吃香菜」
  const pre = Object.keys(ALIASES).filter((k) => /[一-龥]/.test(k) && word.startsWith(k)).sort((a, b) => b.length - a.length)[0]
  return pre ? { name: ALIASES[pre], arg: (m[1].slice(pre.length) + ' ' + m[2]).trim() } : null
}

const ALIASES = {
  闭嘴: 'silent', 安静: 'silent', 静音: 'silent', shutup: 'silent', mute: 'silent',
  说话: 'active', 醒醒: 'active', 解除静音: 'active', unmute: 'active',
  少说: 'quiet', 话少: 'quiet',
  多说: 'chatty', 话多: 'chatty',
  正常: 'normal',
  模型: 'model', 换模型: 'model',
  状态: 'status', 日记: 'diary', 记住: 'remember', 记一下: 'remember',
  重开: 'reset', 清空: 'new', 忘掉: 'new', 清记忆: 'new', 开机: 'on', 关机: 'off', 帮助: 'help', 命令: 'help', h: 'help',
}

const COMMANDS = {
  help: '看这份命令列表',
  silent: '在这里闭嘴（可带分钟数，如 /silent 30；不带就一直到 /active）',
  active: '解除闭嘴；在群里还会接着参与话题一会儿',
  quiet: '这个群里只在被叫到时说话，不插话',
  chatty: '这个群里话多一点，更爱插话',
  normal: '这个群恢复默认的插话频率',
  model: '看或换她用的模型：/model 看列表，/model 2 或 /model 名字 换，/model 默认 跟随 DSH',
  status: '看她现在的状态',
  diary: '马上写一篇空间日记',
  remember: '让她记住一件事，如 /remember 我不吃香菜',
  reset: '这个聊天重新开始（旧的对话在 DSH 侧栏里还能找回；记忆不动）',
  new: '清空这个聊天的记忆（小档案、相处经验、说话方式一起清）；对话不动，要重开对话用 /reset',
  on: '打开总开关',
  off: '关掉总开关（之后除了命令什么都不回）',
}

export const commandList = (extra = []) => [
  ...Object.entries(COMMANDS).map(([name, desc]) => ({ name, desc, aliases: Object.keys(ALIASES).filter((k) => ALIASES[k] === name && /[一-龥]/.test(k)) })),
  ...extra.map((c) => ({ name: c.name, desc: c.desc || '', aliases: c.aliases || [], module: c.module || '' })),
]

export function helpText(extra = []) {
  return '主人命令（也可以用中文，如 /闭嘴 /说话）：\n' + Object.entries(COMMANDS).map(([k, v]) => `/${k}  ${v}`).join('\n')
    + (extra.length ? '\n扩展模块加的：\n' + extra.map((c) => `/${c.name}  ${c.desc || ''}`).join('\n') : '')
}

/** 每个聊天的闭嘴状态：chatId → 到什么时候（毫秒，Infinity 写成 0 表示一直）。 */
export function createMutes() {
  const file = () => dataDir('mutes.json')
  const load = () => readJson(file(), {})
  return {
    muted(chatId, now = Date.now()) {
      const m = load()
      if (!(chatId in m)) return false
      if (m[chatId] === 0 || m[chatId] > now) return true
      delete m[chatId]
      writeJson(file(), m)
      return false
    },
    set(chatId, minutes) {
      const m = load()
      m[chatId] = minutes > 0 ? Date.now() + minutes * 60_000 : 0
      writeJson(file(), m)
    },
    clear(chatId) {
      const m = load()
      delete m[chatId]
      writeJson(file(), m)
    },
    until: (chatId) => load()[chatId],
  }
}

/**
 * 执行命令，返回要回给主人的话。
 * @param {object} deps { getConfig, setConfig, mutes, hub, memory, qzone, onebot }
 */
export async function runCommand(cmd, msg, deps) {
  const { getConfig, setConfig, mutes, hub, memory, qzone } = deps
  const cfg = getConfig()
  const inGroup = msg.kind === 'group'
  const here = inGroup ? '这个群' : '这里'
  const setGroup = (patch) => {
    const overrides = { ...(cfg.group.overrides || {}) }
    if (patch === null) delete overrides[msg.groupId]
    else overrides[msg.groupId] = { ...(overrides[msg.groupId] || {}), ...patch }
    setConfig({ ...cfg, group: { ...cfg.group, overrides } })
  }
  switch (cmd.name) {
    case 'help':
      return helpText(deps.extraCommands || [])
    case 'silent': {
      const min = Math.max(0, Math.min(7 * 24 * 60, Number.parseInt(cmd.arg, 10) || 0))
      mutes.set(msg.chatId, min)
      if (inGroup) hub.leaveTopic?.(msg.groupId)
      return min ? `好，我在${here}安静 ${min} 分钟` : `好，我在${here}先不说话了，想我了发 /active`
    }
    case 'active':
      mutes.clear(msg.chatId)
      if (inGroup) hub.joinTopic?.(msg.groupId)
      return inGroup ? '我回来啦' : '在呢'
    case 'quiet':
      if (!inGroup) return '这个命令要在群里用'
      setGroup({ interjectChance: 0 })
      return '好，这个群里没人叫我我就不插话'
    case 'chatty':
      if (!inGroup) return '这个命令要在群里用'
      setGroup({ interjectChance: 0.4, minRelevance: 0.1 })
      return '好耶，那我在这个群多说两句'
    case 'normal':
      if (!inGroup) return '这个命令要在群里用'
      setGroup(null)
      return '好，按平常的样子来'
    case 'status': {
      const st = hub.stats()
      const mu = mutes.until(msg.chatId)
      const lines = [
        `总开关：${cfg.enabled ? '开' : '关'}${cfg.dryRun ? '（试运行，不真发）' : ''}`,
        `今天：收到 ${st.received} 条，发出 ${st.sent} 条`,
        `${here}：${mu === undefined ? '正常说话' : mu === 0 ? '闭嘴中' : '闭嘴到 ' + new Date(mu).toLocaleTimeString().slice(0, 5)}`,
      ]
      if (inGroup) {
        const o = (cfg.group.overrides || {})[msg.groupId] || {}
        lines.push(`插话：${o.interjectChance === 0 ? '不插话' : o.interjectChance >= 0.4 ? '话多' : '默认'}`)
      }
      return lines.join('\n')
    }
    case 'model': {
      const list = deps.listModels ? await deps.listModels() : []
      const cur = cfg.model.provider && cfg.model.model ? cfg.model : null
      const label = (m) => (m.name && m.name !== m.model ? `${m.name}（${m.model}）` : m.model)
      if (!cmd.arg) {
        const def = deps.defaultModel?.()
        const head = cur ? `现在用的：${cur.model}` : `现在跟随 DSH 默认${def ? '：' + def.model : ''}`
        if (!list.length) return head + '\n（拿不到模型列表）'
        return head + '\n' + list.slice(0, 20).map((m, i) => `${i + 1}. ${label(m)}${cur && m.provider === cur.provider && m.model === cur.model ? '  ← 当前' : ''}`).join('\n') + '\n发 /model 序号 换，/model 默认 跟随 DSH'
      }
      if (/^(默认|default|auto|跟随)$/i.test(cmd.arg)) {
        setConfig({ ...cfg, model: { ...cfg.model, provider: '', model: '' } })
        return '好，换回跟随 DSH 的默认模型，下一句起生效'
      }
      const n = Number.parseInt(cmd.arg, 10)
      const q = cmd.arg.toLowerCase()
      const hit = String(n) === cmd.arg ? list[n - 1]
        : list.find((m) => m.model.toLowerCase() === q || String(m.name).toLowerCase() === q) || list.find((m) => m.model.toLowerCase().includes(q) || String(m.name).toLowerCase().includes(q))
      if (!hit) return `没找到「${cmd.arg}」这个模型，发 /model 看列表`
      setConfig({ ...cfg, model: { ...cfg.model, provider: hit.provider, model: hit.model } })
      return `好，换成 ${label(hit)} 了，下一句起生效`
    }
    case 'diary': {
      if (!qzone) return '空间日记没开'
      const r = await qzone.writeDiary()
      return r.ok ? (r.dryRun ? '写好了，不过现在是试运行，没真发' : '写好发出去啦，去空间看看') : '没写成：' + (r.message || '不知道为啥')
    }
    case 'remember': {
      if (!memory) return '记忆模块关着'
      if (!cmd.arg) return '要我记住什么呀？比如 /remember 我不吃香菜'
      // 传闻归因：--hearsay 显式标记，或「听X说」前缀（X 落 speaker）；其余按直接陈述。
      let arg = String(cmd.arg)
      let status = ''
      let speaker = ''
      if (/(^|\s)--hearsay(?=\s|$)/.test(arg)) { status = 'hearsay'; arg = arg.replace(/(^|\s)--hearsay(?=\s|$)/g, ' ').trim() }
      const heard = /^听(.{1,20}?)说[：:,，]?\s*/.exec(arg)
      if (heard) { status = 'hearsay'; speaker = heard[1]; arg = arg.slice(heard[0].length).trim() }
      if (!arg) return '要我记住什么呀？比如 /remember 我不吃香菜'
      // 群聊里记录实际发言人；私聊默认主人亲述（direct）
      if (!speaker && String(msg.chatId || '').startsWith('group:') && msg.userId) speaker = String(msg.userId)
      // 作用域跟着发命令的那个聊天走：在群里 /remember 的只在那群可见
      const sc = String(msg.chatId || '').startsWith('private:') || String(msg.chatId || '').startsWith('group:') ? String(msg.chatId) : 'global'
      const r = memory.add({ text: arg, aboutName: cfg.ownerName || '主人', about: cfg.ownerQQ, importance: 0.8, source: 'panel', chatId: msg.chatId, scope: sc, speaker, status })
      return r.ok ? '记住了' : '没记上：' + (r.message || '')
    }
    case 'reset':
      hub.resetChat(msg.chatId)
      return '好，我们重新开始'
    case 'new': {
      // 清当前聊天的记忆：条目 + 小档案 + 相处经验 + 说话方式。
      // 和 /reset 分工：/reset 重开对话（记忆不动），/new 清记忆（对话不动）。旧会话残留的记忆只能靠它清掉。
      if (!memory) return '记忆模块关着'
      if (typeof memory.clearScope !== 'function') return '这个版本的记忆模块不支持清理'
      const chat = { chatId: msg.chatId, kind: msg.kind, userId: msg.userId, groupId: msg.groupId }
      const r = memory.clearScope(chat)
      const n = (r.items || 0) + (r.profile || 0) + (r.insights || 0) + (r.style || 0)
      if (!n) return '这个聊天的记忆本来就是空的'
      const bits = []
      if (r.items) bits.push(`${r.items} 条记忆`)
      if (r.profile) bits.push(`${r.profile} 份小档案`)
      if (r.insights) bits.push(`${r.insights} 条相处经验`)
      if (r.style) bits.push(`${r.style} 条说话方式`)
      return `清掉了这个聊天的 ${bits.join('、')}。别处和 global 的记忆没动`
    }
    case 'on':
      setConfig({ ...cfg, enabled: true })
      return cfg.dryRun ? '总开关打开了（现在是试运行，我说的话只进日志）' : '我上线啦'
    case 'off':
      setConfig({ ...cfg, enabled: false })
      return '好，我先下线了。发 /on 叫我回来'
    default:
      return null
  }
}
