// QQ Hub · 宿主半边（DSH 插件入口）
//
// 让 DSH 里的 AI 以独立 QQ 号「大肥鱼」住在 QQ 里：
//   SnowLuma（OneBot v11）⇄ 本插件 ⇄ DSH 会话（QQ Hub 自带的 preset + 人格）
// 面板在侧栏「自动化任务」下面（网页半边见 client/client.js），这里提供它要的 /qq-hub/api/* 接口。
//
// 这个文件只管「核心」：配置、QQ 网关、聊天中枢、人格、面板接口、模块内核和联动。
// 表情、语音、记忆、空间、B 站、翻唱、生图……都是模块（src/modules/），能单独关掉，也能用自己写的替换。
//
// ⚠ 安全默认：总开关关、试运行开。不手动打开，一句都不会真的发到 QQ。

import { patchFnosFsync } from './core/fnos-fsync-patch.js'
patchFnosFsync() // 自动应用 fnOS 祖先目录耐久性同步容错，避免图片登记附件抛 EACCES

import { readFileSync, existsSync, writeFileSync, unlinkSync, statSync, mkdirSync } from 'node:fs'
import { dedupeModelList } from './core/models.js'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawn } from 'node:child_process'
import { loadConfig, saveConfig, publicConfig, mergeFromPanel } from './core/config.js'
import { createLogger } from './core/logger.js'
import { registerSecret, redact } from './core/redact.js'
import { createOneBotClient } from './onebot/client.js'
import { createSnowLumaManager, DOWNLOAD_PAGE } from './snowluma/manager.js'
import { createHub, workspaceDirOf } from './chat/hub.js'
import { createLocal, fileOf, toImageBuffer } from './local/local.js'
import { createGroupRoles } from './chat/group-roles.js'
import { defaultModel, askModel, modelReasoning, modelVision, clearReasoningCache, clearVisionCache } from './core/llm.js'
import { mimeOf } from './chat/inbound.js'
import { dataDir, ensureDir } from './core/store.js'
import { createUpdateChecker, changelogSection } from './core/update.js'
import { parseCommand, runCommand, createMutes, commandList } from './chat/commands.js'
import { listPersonas, readPersona, savePersona, deletePersona, currentPersonaText, personaIdFor, rulesText, seedPersonas } from './persona/personas.js'
import { createModules, API_VERSION } from './core/modules.js'
import { createBridge } from './core/bridge.js'
import { createDangerGuard } from './security/danger.js'
import { createUpstreamGapTracker, createSeenMessageIds, selectBackfill, describeDuration } from './chat/backfill.js'
import { BUILTINS } from './modules/index.js'
// RFC-0001 Phase 0（US-003）：遗留核心终端化 + FLAG_USE_PIPELINE 熔断开关
import { compose } from './kernel/compose.js'
import { createContext } from './kernel/context.js'
import { createLegacyHubFallback, isPipelineEnabled, legacyEventToEnvelope, unwrapPipelineError, LEGACY_DRIVER_ID } from './kernel/legacy-fallback.js'
import { createTracingMiddleware } from './kernel/mw-tracing.js'
// RFC-0001 Phase 1（US-005/006/007）：出口切换——pipeline 开启时 hub 的发送全部收口 ctx.reply → Dispatcher
import { createDispatcher } from './kernel/dispatcher.js'
import { createEgressMiddleware } from './kernel/mw-egress.js'
import { isEgressShadowEnabled } from './kernel/ctx-store.js'
import { createEgressFlushMiddleware, createEgressOnebot, createEgressSendHook, createEgressSender } from './kernel/mw-egress-cutover.js'
import { createAggregatorMiddleware, isIngressAggregatorEnabled } from './kernel/mw-aggregator.js'
// RFC-0001 Phase 2（US-009）：入口防御链——ratelimit/ACL/dedup 在出口记账之前短路无效流量
import { createRatelimitMiddleware, ratelimitOptionsFromEnv } from './kernel/mw-ratelimit.js'
import { createAclMiddleware } from './kernel/mw-acl.js'
import { createDedupMiddleware } from './kernel/mw-dedup.js'
// RFC-0001 Phase 3（US-010）：上下文装配中间件——人设预取 + 记忆检索；
// 记忆接管点在装配层的 contextProviders provider 包装（NEW_MEMORY_PIPELINE=true 才包）
import { createPersonaInjector, chatFromInbound } from './kernel/mw-persona.js'
import { createMemoryRetriever, createContextProviderTakeover, isNewMemoryPipelineEnabled } from './kernel/mw-memory.js'
// RFC-0001 Phase 3（US-011）：命令路由终端中间件——命中主人命令即 ctx.reply 应答并短路，未适配/抛错透传 legacy
import { createCommandRouterMiddleware } from './kernel/mw-command-router.js'
import { isOwner } from './chat/access.js'

export const name = 'qq-hub'
// 注意：不要把 userQuestions 写进 inject。
// cordis 4 的 Fiber._refresh() 会对 inject 里每个 key 做「实现必须存在」判定，
// 缺一个就把 epoch 设成 INACTIVE，插件永远不启动（这正是之前 /qq-hub/api/* 全 404 的根因）。
// userQuestions 在 0.2.2-alpha.2 运行时并不存在，所以只能运行时探测（见 setupUserQuestions）。
export const inject = ['agents', 'sessions', 'webServer', 'timer', 'workspaceRegistry', 'attachments', 'systemPrompt', 'llm']

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const PKG = (() => {
  try { return JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8')) } catch (error) { return { version: '?' } }
})()
const VERSION = PKG.version
const PREFIX = '/qq-hub/api'

export function apply(ctx) {
  const logger = createLogger({ dsh: ctx })
  const log = logger.child('core')
  let cfg = loadConfig()
  let mods = null
  let bridge = null
  const getConfig = () => cfg
  const secrets = () => { for (const k of ['webuiPassword', 'httpToken', 'wsToken']) registerSecret(cfg.snowluma[k]); registerSecret(cfg.imageGen.apiKey); registerSecret(cfg.bridge.token) }
  const setConfig = (next) => {
    const before = cfg
    cfg = saveConfig(next)
    // 改机器人号后旧连接的核对结果立刻失效，必须重新核对才能处理消息或完成向导。
    if (before.botQQ !== cfg.botQQ) {
      wrongAccount = ''
      if (onebotState === 'connected') onebot.restart()
    }
    secrets()
    if (bridge && before.bridge.dshTools !== cfg.bridge.dshTools) bridge.refresh()
    if (mods && (JSON.stringify(before.modules) !== JSON.stringify(cfg.modules) || before.safeMode !== cfg.safeMode)) mods.sync().catch(() => {})
    mods?.emit('config', cfg, before)
    return cfg
  }
  secrets()
  seedPersonas()

  // ---------- 人格与规则：通过提示词变量注入到 QQ Hub 的三个 preset ----------
  const variable = (n, fn) => ctx.effect(() => ctx.systemPrompt.variable(n, fn), `qq-hub: 变量 ${n}`)
  const rulesOpts = (kind) => (mods ? { off: mods.builtinOff(), extra: mods.rules(kind) } : {})
  // 扩展模块能整段改写人格和规则（同步：提示词变量不能等）
  const rewrite = (event, text, ...args) => { const r = mods ? mods.filterSync(event, text, ...args) : text; return typeof r === 'string' ? r : r === null ? '' : text }
  variable('qq_hub_persona', () => rewrite('persona', currentPersonaText(cfg.persona.current)))
  variable('qq_hub_rules_private', () => {
    const base = rewrite('rules', rulesText('private', cfg, rulesOpts('private')), 'private')
    // 危险命令确认开着时补一句：被拦下要如实告诉主人，别绕着写
    return base + (cfg.security && cfg.security.dangerConfirm
      ? '\n【危险命令】终端命令如果被安全策略拦下（删根目录/格式化/关机/下载后直接执行等），把命令原文和原因如实告诉主人，等主人回复「确认」后再重试；不要换一种写法绕过。'
      : '')
  })
  variable('qq_hub_rules_social', () => rewrite('rules', rulesText('social', cfg, rulesOpts('social')), 'social'))

  // ---------- QQ 网关 ----------
  const snowluma = createSnowLumaManager({
    getConfig,
    log: logger.child('snowluma'),
    // 控制台密码由插件自动生成并保存，用户不用管
    savePassword: (pw, auto = true) => setConfig({ ...cfg, snowluma: { ...cfg.snowluma, webuiPassword: pw, passwordAuto: auto } }),
  })
  const endpoint = () => {
    const s = cfg.snowluma
    // 接自己的 OneBot 时只认填的地址；用 SnowLuma 时没填的从它的配置里读
    const auto = cfg.gateway === 'onebot' || (s.httpUrl && s.wsUrl) ? null : snowluma.endpoint()
    return {
      httpUrl: s.httpUrl || auto?.httpUrl || '',
      wsUrl: s.wsUrl || auto?.wsUrl || '',
      httpToken: s.httpToken || auto?.httpToken || '',
      wsToken: s.wsToken || auto?.wsToken || '',
    }
  }
  let onebotState = 'stopped'
  // 连上后先核对登录的是不是机器人号，核对通过前不处理任何消息；不是就断开，不再自动重连
  let loginOk = false
  let wrongAccount = ''
  // 核对期间收到的事件先攒着：核对通过就补处理，核对失败就丢掉。
  // 直接丢弃的话，刚连上那几百毫秒里主人发的消息就没了（登录核对要等一次 get_login_info 往返）。
  let verifying = false
  let pendingEvents = []
  let hub = null // 遗留核心：US-003 起作为管道终端（开关关闭时仍直调）
  let dangerGuard = null // 危险命令确认（security.dangerConfirm 开着才生效）

  // 断线消息补收（Backfill）追踪器
  const gapTracker = createUpstreamGapTracker({
    file: dataDir('upstream-seen.json'),
    gapMs: Number(cfg.backfill?.gapMs) || 120_000,
    onError: (err) => log.debug('gapTracker 出错:', err.message)
  })
  const seenIds = createSeenMessageIds()
  let backfilling = false

  async function triggerBackfill({ since, gapMs }) {
    if (backfilling || cfg.backfill?.enabled === false) return
    backfilling = true
    const settle = Number(cfg.backfill?.settleMs) || 10_000
    if (settle > 0) await new Promise((r) => setTimeout(r, settle))
    try {
      log.info(`[backfill] 发现连接断档约 ${describeDuration(gapMs)}，开始拉取错过的历史消息...`)
      const groups = (cfg.allow?.groups || []).map(String)
      const privates = (cfg.allow?.private || []).map(String)
      const botQQ = String(cfg.botQQ || '')

      for (const gid of groups) {
        try {
          const res = await onebot.call('get_group_msg_history', { group_id: Number(gid), count: 30 })
          const msgs = Array.isArray(res?.messages) ? res.messages : []
          const { items } = selectBackfill(msgs, {
            key: `group:${gid}`,
            since,
            selfId: botQQ,
            seen: seenIds,
            config: cfg.backfill
          })
          for (const it of items) {
            seenIds.add(`group:${gid}`, it.event.message_id)
            await hub.onMessage(it.event, { backfill: true, gapMs, earliestAgeMs: it.ageMs })
          }
        } catch (e) {
          log.debug(`[backfill] 拉取群 ${gid} 历史失败:`, e.message)
        }
      }
      for (const uid of privates) {
        try {
          const res = await onebot.call('get_friend_msg_history', { user_id: Number(uid), count: 20 })
          const msgs = Array.isArray(res?.messages) ? res.messages : []
          const { items, skippedCommands } = selectBackfill(msgs, {
            key: `private:${uid}`,
            since,
            selfId: botQQ,
            seen: seenIds,
            config: cfg.backfill
          })
          if (skippedCommands.length && String(uid) === String(cfg.ownerQQ)) {
            const cmds = skippedCommands.map((c) => `「${c.text}」`).join('、')
            await hub.sendText(`private:${uid}`, `⚠️ 断线期间（约 ${describeDuration(gapMs)}）收到的管理命令 ${cmds} 未执行；如需执行请重新发送。`)
          }
          for (const it of items) {
            seenIds.add(`private:${uid}`, it.event.message_id)
            await hub.onMessage(it.event, { backfill: true, gapMs, earliestAgeMs: it.ageMs })
          }
        } catch (e) {
          log.debug(`[backfill] 拉取私聊 ${uid} 历史失败:`, e.message)
        }
      }
    } catch (err) {
      log.warn('[backfill] 补收历史消息异常:', err.message)
    } finally {
      backfilling = false
    }
  }
  async function checkLogin() {
    verifying = true
    pendingEvents = []
    try {
      let uin = ''
      try {
        const info = await onebot.call('get_login_info', {}, { timeoutMs: 10000 })
        uin = String(info?.user_id ?? '')
      } catch (error) {
        logger.child('onebot').warn('核对登录的 QQ 号失败：', error.message)
      }
      if (onebotState !== 'connected') return
      if (!uin) {
        // 核对不了就别用，断开后由看门狗重试
        onebot.stop()
        return
      }
      if (await snowluma.confirmLogin(uin)) {
        loginOk = true
        wrongAccount = ''
        // 把核对期间攒下的补上（按到达顺序）
        const queued = pendingEvents
        pendingEvents = []
        for (const ev of queued) handleEvent(ev)
      } else {
        wrongAccount = uin
        pendingEvents = []
        onebot.stop()
      }
    } finally {
      verifying = false
    }
  }
  /** 核对通过后的事件都在这里处理（onEvent 直接调，核对期间攒下的也会补到这里）。 */
  function handleEvent(ev) {
    if (!hub) return
    const gap = gapTracker.notePacket()
    if (gap && cfg.backfill?.enabled !== false) {
      triggerBackfill(gap)
    }
    if (ev.post_type === 'message' && ev.message_id) {
      const key = ev.message_type === 'group' ? `group:${ev.group_id}` : `private:${ev.user_id}`
      seenIds.add(key, ev.message_id)
    }
    // 模块能看到所有原始事件（加群、撤回、好友申请……），只看不拦
    mods?.emit('onebot', ev)
    if (ev.post_type === 'message' || ev.post_type === 'message_sent') {
      if (ev.post_type === 'message') {
        // 危险命令确认：主人的「确认 / 取消」回复先在这里截住，不交给聊天中枢
        if (dangerGuard && ev.message_type === 'private') {
          const text = Array.isArray(ev.message)
            ? ev.message.filter((seg) => seg && seg.type === 'text').map((seg) => String(seg.data?.text || '')).join('')
            : ''
          if (dangerGuard.handleReply(`private:${ev.user_id}`, ev.user_id, text)) return
        }
        const sink = (error) => log.error('处理消息出错：', (usePipeline ? unwrapPipelineError(error) : error).message)
        if (usePipeline) dispatchLegacyPipeline(ev).catch(sink)
        else hub.onMessage(ev).catch(sink)
      }
    } else if (ev.post_type === 'notice' && ev.notice_type === 'notify' && ev.sub_type === 'poke') {
      const sink = (error) => log.error('处理戳一戳出错：', (usePipeline ? unwrapPipelineError(error) : error).message)
      if (usePipeline) dispatchLegacyPipeline(ev).catch(sink)
      else hub.onPoke(ev).catch(sink)
    }
  }
  /** RFC-0001 熔断开关开启态的洋葱管道；关闭态（默认）恒为 null，装配见 createHub 之后。 */
  let legacyPipeline = null
  // US-008：入口合流中间件实例（dispose 由 ctx.effect 收尾统一回收定时器/挂起 ctx）
  let pipelineAggregator = null
  let useIngressAggregator = false
  /** 开启态：旧事件构造 RFC 信封 → kernel createContext → 整链 await 走管道（终端仍是旧 hub 入口）。 */
  async function dispatchLegacyPipeline(ev) {
    const ctx = createContext(legacyEventToEnvelope(ev), LEGACY_DRIVER_ID)
    // gemini38 缺陷2（父信号泄漏预炸点）接线：createContext 支持第 4 参 {signal}
    // （review A2 P1），转发闭包只有 abort/dispose 两条摘除出口；本调用点是全仓唯一
    // 生产实调用，若将来透传长命父信号（HTTP 断开/会话超时）而这里不收尾，监听闭包
    // 会逐事件线性累积。故在管道**真实 settle 之后**统一 dispose——必须 await 再
    // finally（同步 finally 会在派发前就摘掉监听，父取消在飞窗口直接失效）。
    // 现产未传父信号 → dispose 是空操作，默认/flag-off 路径行为逐字不变。
    try {
      return await legacyPipeline(ctx)
    } finally {
      ctx.dispose?.()
    }
  }
  const onebot = createOneBotClient({
    endpoint,
    log: logger.child('onebot'),
    onState: (s, d) => {
      onebotState = s
      if (s !== 'connected') { loginOk = false; pendingEvents = [] }
      else checkLogin().catch((error) => log.warn('核对登录号出错：', error.message))
      logger.child('onebot').info(`QQ 网关：${s}${d ? '（' + d + '）' : ''}`)
      mods?.emit('onebot/state', s)
    },
    onEvent: (ev) => {
      // 还没核对是机器人号：核对期间先攒着，核对通过后补处理
      if (!loginOk) {
        if (verifying) {
          pendingEvents.push(ev)
          if (pendingEvents.length > 200) pendingEvents.shift()
        }
        return
      }
      handleEvent(ev)
    },
  })
  const groupRoles = createGroupRoles({ onebot, getConfig, log: logger.child('chat') })
  const local = createLocal({ getConfig, log: logger })
  const mutes = createMutes()

  /**
   * DSH 里能用的所有模型：[{provider, model, name, reasoning}]。
   * reasoning 是 {efforts:[...], default} 或 null（null = 这个模型不支持思考强度，
   * 面板据此把「思考强度」置灰，免得选了之后整轮报错）。
   */
  async function listModels() {
    const llm = ctx.llm || ctx.get('llm')
    const out = []
    // DSH 可能把同一个 provider 报两遍、同一个模型返回多条，面板里就会出现
    // 两个一模一样的「Hy3 / fan-vision」。去重逻辑抽在 core/models.js 里。
    // （1.3.6 就接线了；真正的根因是这份远端修复一直没合并进本地运行的那份。）
    const groups = []
    for (const p of llm.listProviders() || []) {
      const provider = typeof p === 'string' ? p : p.provider || p.id || p.name
      if (!provider) continue
      try {
        groups.push({ provider, models: (await llm.listModels(provider)) || [] })
      } catch (error) {}
    }
    // dedupeModelList 已按 model id 合并掉「基础版 / 视觉版」这种同模型多 provider 的情况，
    // 这里优先用能看图的那个 provider 去问细项；它答不上来再退回任意一个。
    for (const item of dedupeModelList(groups)) {
      const { model, raw } = item
      // 选了能看图的那个 provider 就优先报它，免得下游又把它当看不见图的用
      const provider = item.preferred.provider
      // 合并时已经知道「任一 provider 说能看图」，这里再问一次只是兜底：
      // 只有明确查到 true 才升级，查不到（undefined）保持原判定，绝不因为查不到就把 true 降级。
      let vision = item.vision
      if (!vision) {
        try { if (await modelVision(ctx, provider, model) === true) vision = true } catch (error) {}
      }
      let reasoning = null
      try { reasoning = await modelReasoning(ctx, provider, model) } catch (error) {}
      // providers：合并前的全部来源（面板/诊断能看到这个模型到底挂在几家下）
      out.push({ provider, model, name: raw.name || model, reasoning, vision, providers: item.providers })    }
    if (out.length) modelCache = out
    return out
  }
  // 最近一次查到的模型列表：按聊天选的模型已经不在 DSH 里了，就退回下一级（同步取，hub 每条消息都要用）
  let modelCache = null
  setTimeout(() => { listModels().catch(() => {}) }, 3000).unref?.()

  // 聊天中枢找表情库、语音时，找的是当时在跑的那个模块；模块关着就当没有
  const use = (id) => mods?.use(id) || null
  const stickers = {
    match: (q) => use('stickers')?.match?.(q) ?? null,
    segmentFor: (it) => use('stickers')?.segmentFor?.(it) ?? null,
    markUsed: (md5) => use('stickers')?.markUsed?.(md5),
    pickForReply: (t) => use('stickers')?.pickForReply?.(t) ?? null,
    collect: async (s, chatId) => (use('stickers')?.collect ? use('stickers').collect(s, chatId) : { ok: false, reason: '表情包模块关着' }),
    library: () => use('stickers')?.library?.() ?? { items: [] },
  }
  const tts = {
    speak: async (text) => {
      const v = use('voice')
      if (!v?.speak) throw new Error('语音模块关着')
      return v.speak(text)
    },
  }

  // ---------- RFC-0001 Phase 1（US-007）：出口切换装配件（pipeline 开启态才注入） ----------
  // 关闭态（默认）：hub 拿到的还是原 onebot 客户端与原 hooks.send，旧路径逐字不动。
  // 开启态：两个注入点都在装配层，hub.js 零改动——
  //   hubOnebot   收口 send_group_msg / send_private_msg / upload_*_file
  //               （live 吞包入队、shadow 旧通道真发并记 hash）；
  //   hubSendHook 扩展模块改写语义不变，另记投递草稿（chatId/note/priority/delayMs）给出口认领。
  // FLAG_EGRESS_SHADOW=true → shadow 双算比对（先比对后切权），缺省 live。
  const usePipeline = isPipelineEnabled(process.env)
  const egressMode = usePipeline && isEgressShadowEnabled(process.env) ? 'shadow' : 'live'
  const hubOnebot = usePipeline
    ? createEgressOnebot({ onebot, mode: egressMode, log: logger.child('egress') })
    : onebot
  const hubSendHook = usePipeline
    ? createEgressSendHook({ legacySend: (message, info) => mods.filter('send', message, info), log: logger.child('egress') })
    : (message, info) => mods.filter('send', message, info)

  // ---------- RFC-0001 Phase 3（US-010）：记忆装配接管（NEW_MEMORY_PIPELINE 灰度位） ----------
  // 缺省关：contextProviders 仍是原函数本体的数组，与 US-009 逐字节等价（红线）。
  // 开（且仅当管道也开）：注入面**外面**包一层 takeover——ALS 有本轮 ctx、
  // mw-memory 已在 ctx.state 备好装配结果 → 直接供给 state 缓存，原 provider 零调用；
  // 任一条件不满足（flag off / 无 ctx / 中间件没跑到）→ 原 mods.contextFor（legacy 回退）。
  // hub.js 一行未动；接管面覆盖清单与已知边界（其余 api.context 模块 / 群 speakersOf 档案）
  // 见 src/kernel/mw-memory.js 头注。
  const baseContextProvider = (args) => mods.contextFor(args)
  const memoryAssemblyOn = usePipeline && isNewMemoryPipelineEnabled(process.env)
  const hubContextProviders = [
    memoryAssemblyOn
      ? createContextProviderTakeover({ provider: baseContextProvider, isNewPipeline: () => true, log: logger.child('memory-mw') })
      : baseContextProvider,
  ]

  hub = createHub({
    localApi: local,
    dsh: ctx,
    getConfig,
    log: logger.child('chat'),
    onebot: hubOnebot,
    stickers,
    tts,
    buildTools: (where) => mods.buildTools(where),
    // 会话上下文：只放模块给的（记忆、近况……）。
    // 按聊天换人设不在这里做——那会变成「系统卡 + 追加块」两套人设；
    // 现在由 hub 的 mount() 在 agent 作用域里遮蔽 {{qq_hub_persona}}，整份提示词只有一套人设。
    contextProviders: hubContextProviders,
    onActivity: (a) => mods.emit('activity', a),
    // 群聊话题和她的记忆有多相关（插话判断用）
    // 传 chat：话题相关度只在当前聊天可见的记忆里算，别处的记忆不该让她在群里「感兴趣」
    memoryScore: (text, chat) => use('memory')?.topicScore?.(text, chat) ?? 0,
    // QQ 里的主人命令（模块加的命令优先）
    onCommand: async (msg) => {
      const cmd = parseCommand(msg.text, mods.commands())
      if (!cmd) return null
      if (cmd.ext) return String((await cmd.ext.run(cmd.arg, msg)) ?? '')
      return runCommand(cmd, msg, { getConfig, setConfig, mutes, hub, mood: use('mood'), memory: use('memory'), qzone: use('diary'), song: use('song'), listModels, defaultModel: () => defaultModel(ctx, { model: {} }), extraCommands: mods.commands() })
    },
    isMuted: (chatId) => mutes.muted(chatId),
    moodEffects: () => use('mood')?.effects?.() ?? null,
    availableModels: () => modelCache,
    // 模块（重）启动代际：模块热重载后工具名没变、但实例换了，hub 要据此重挂工具（issue #73）
    toolsGeneration: () => (mods ? mods.generation?.() || 0 : 0),
    hooks: {
      message: (msg) => mods.claim('message', msg),
      // 专用卡（按聊天换人设）也过一次模块改写，和全局人设走同一条路
      persona: (text) => rewrite('persona', text),
      reply: (text, info) => mods.filter('reply', text, info),
      deniedTools: () => bridge?.deniedTools() || [],
      groupDecide: (decision, info) => mods.filter('group/decide', decision, info),
      prompt: (content, info) => mods.filter('prompt', content, info),
      items: (items, info) => mods.filter('reply/items', items, info),
      // US-007：开启态换成出口切换变体（内部照样先跑 mods.filter('send', …)，模块语义一字不动）
      send: hubSendHook,
      model: (sel, chat) => mods.filterSync('model', sel, chat),
      poke: (ev) => mods.claim('poke', ev),
      // security-lock 模块已移除：不再提供锁状态，approvals 的锁分支自然不会触发
    },
  })

  // ---------- RFC-0001 Phase 0/1：FLAG_USE_PIPELINE 熔断开关（US-003 / US-007） ----------
  // 开关关闭（默认）：handleEvent 直调 hub.onMessage/onPoke，与重构前完全一致，不装配管道。
  // 开关打开：onebot 实时事件流走 compose([tracing → ratelimit → acl → dedup → 边界 flush → egress → 入口合流 → 遗留终端])。
  // backfill 补收、deliver/pushToSession 等旁路入口不经管道（边界见 docs/rfc0001-mapping.md）。
  if (usePipeline) {
    // US-007：Dispatcher 的物理出口。sender 用的是**没被包装的**原 onebot 客户端，
    // 所以「旧通道直发」和「新链路下发」不会互相套娃；upload_*_file 保留 hub 的长超时
    // 与「网关看不到本机路径 → 改走 base64」回退（大小口径同 hub 的 30MB 上限）。
    const egressSender = createEgressSender({
      call: (action, params, opts) => onebot.call(action, params, opts),
      uploadFile: (file) => {
        const maxBytes = 30 * 1024 * 1024
        if (!existsSync(file) || !statSync(file).isFile() || statSync(file).size > maxBytes) return ''
        return 'base64://' + readFileSync(file).toString('base64')
      },
      log: logger.child('egress'),
    })
    // shaping 参数就是 chat/reply.js bubbleDelay 的口径（clamp 后 × 0.8~1.3 抖动）；
    // 当前投递的 payload 一律带 delayMs=0（US-007 拍板），所以这里只做兜底：
    // 谁以后给 payload 显式留空 delayMs，就自动按打字估时整形。
    // US-008 灰度位：入口合流是否装进管道（默认 false = 旧 pending 路径）
    useIngressAggregator = usePipeline && isIngressAggregatorEnabled(process.env)
    if (useIngressAggregator) {
      pipelineAggregator = createAggregatorMiddleware({
        getConfig: () => cfg,
        log: logger.child('aggregator'),
      })
    }
    const dispatcher = createDispatcher({
      mode: egressMode,
      sender: egressSender,
      log: logger.child('dispatcher'),
      shaping: { baseMs: 350, perCharMs: 110, minGapMs: 700, maxGapMs: 4500 },
    })
    // US-010：上下文装配两件（NEW_MEMORY_PIPELINE=true 才进管道；关时数组与 US-009 等价）。
    // - persona：hub 内部直读 personas.js（红线不动），本件为**预取 + 打点**，state 快照供
    //   观测与 Phase 4 消费；人设源每事件实时读 cfg + 人格卡文件（面板改卡下一事件即生效）。
    // - memory：检索 features/memory.js 现行 contextFor/listFor（每事件实时读=热重载），
    //   结果写 ctx.state；上面 hubContextProviders 的 takeover 层据此供给。
    // 拍板顺序：persona/memory 在 aggregator **之后**（lead 放行后为合并回合装配一次，
    // 同窗 followers 在聚合层就 abort，根本到不了检索），legacy 终端之前。
    const personaAssembly = createPersonaInjector({
      getPersona: (chat) => {
        const c = getConfig()
        const want = personaIdFor(chat, c)
        const globalId = (c.persona || {}).current || ''
        const p = want ? readPersona(want) : null
        return {
          id: want || globalId,
          name: p && p.name ? p.name : '',
          body: p && p.body ? p.body : currentPersonaText(want || globalId),
          perChat: Boolean(want && want !== globalId),
        }
      },
      log: logger.child('persona-mw'),
    })
    const memoryAssembly = createMemoryRetriever({
      // 注入面每事件现取：模块热重载（generation 变了换了实例）自动跟上
      memory: (() => {
        const m = () => use('memory')
        return {
          contextFor: (chat, sessionId) => m()?.contextFor?.(chat, sessionId) ?? '',
          listFor: (scopes, opts) => m()?.listFor?.(scopes, opts) ?? [],
        }
      })(),
      log: logger.child('memory-mw'),
    })
    // US-011：命令路由（无独立灰度位——拍板数组直接进管道；flag-off 整段不装配，零改动红线保住）。
    // 判定口径逐条对齐 hub.onMessage 的 legacy 命令闸门（hub.js:1350-1376）：
    //   - approvals.handleReply 与 slash 命令在正则上互斥（其 token 表不含斜杠），无需守卫；
    //   - hub.questions.has 命中 → 透传（legacy 顺序：交互提问先于命令闸门消费该文本）；
    //   - ext 模块命令 → 透传（ext.run 吃 hub 全套 msg 形状——images/forwards/replyId/raw——
    //     信封视图补齐不可信，矩阵诚实留给 legacy；questions.test 亦钉住该文本形态）；
    //   - 非主人 / 非斜杠开头 → 透传（isOwner 复用 chat/access.js，同 hub.js:1366 一份权威）；
    //   - 混有非 text 段（图/表情/录音/转发）→ 透传（legacy recentMedia.remember 先于命令闸门
    //     记媒体，接管会跳过记录——少拦一条命令换语义完整）。
    // handler 复用 host.js:423 legacy onCommand 同款 runCommand 与同一 deps 闭包（模块实例
    // 每事件现取，热重载跟上）；回复经 hub.sendSegments 在 ALS 里落出口切换包装器
    // → ctx.reply.enqueue，总开关 force 豁免 / 试运行 / 身份闸三道安全闸一字不动。
    const runOwnerCommand = async (cmd, msg) => {
      const reply = await runCommand(cmd, msg, { getConfig, setConfig, mutes, hub, mood: use('mood'), memory: use('memory'), qzone: use('diary'), song: use('song'), listModels, defaultModel: () => defaultModel(ctx, { model: {} }), extraCommands: mods.commands() })
      if (!reply) return // 空回复：mw 以零入队增量透传下游，复刻 legacy「命令没答话就继续当聊天」
      log.info(`主人命令 ${String(msg.text).trim().slice(0, 30)} → ${String(reply).split('\n')[0]}`)
      await hub.sendSegments(msg.chatId, [{ type: 'text', data: { text: String(reply) } }], String(reply).slice(0, 60), { force: true })
    }
    const pipelineCommandRouter = createCommandRouterMiddleware({
      parse: (ctx) => {
        const inbound = ctx?.inbound
        if (!inbound || inbound.type !== 'message') return null
        const text = String(inbound.rawText || '')
        if (!/^\s*[/／]/.test(text)) return null
        const chat = chatFromInbound(inbound)
        if (!chat) return null
        const c = getConfig()
        if (!isOwner(c, chat.userId || '')) return null
        if (Array.isArray(inbound.segments) && inbound.segments.some((seg) => seg.type !== 'text')) return null
        if (hub.questions?.has?.(chat.chatId)) return null
        const cmd = parseCommand(text, mods.commands())
        if (!cmd || cmd.ext) return null
        return { cmd, msg: { ...chat, nickname: c.ownerName || '主人', text } }
      },
      // 覆盖矩阵「router 直答」列：runCommand 的 deps 注入面全部 host 可达（含 hub 公开方法
      // stats/resetChat/joinTopic/leaveTopic），16 个内置命令逐一登记；未登记的自动透传。
      handlers: {
        help: runOwnerCommand, silent: runOwnerCommand, active: runOwnerCommand, quiet: runOwnerCommand,
        chatty: runOwnerCommand, normal: runOwnerCommand, model: runOwnerCommand, sing: runOwnerCommand,
        status: runOwnerCommand, mood: runOwnerCommand, diary: runOwnerCommand, remember: runOwnerCommand,
        reset: runOwnerCommand, new: runOwnerCommand, on: runOwnerCommand, off: runOwnerCommand,
      },
      log: logger.child('router'),
    })
    legacyPipeline = compose([
      // RFC Middleware 1（US-004）：最外层 tracing，回溯阶段一行 debug 打点 total/mw0/mw1/err
      createTracingMiddleware({ log: logger.child('trace') }),
      // US-009：入口防御链（RFC §2.1 Tracing→RateLimiter→ACL→Dedup→终端）。
      // 刻意放在出口 flush/egress 之前：被守卫 abort 的事件按 compose §2.2（US-008a）
      // 其后各级两级不进——出口链、聚合窗、旧核心都不为限流/无权/重传流量做记账；
      // 外层 tracing 的 bubble 照常收尾打点（aborted 标记，不计错误）。
      // 旋钮（US-012 配置化尾巴）：QQHUB_RL_CAPACITY / QQHUB_RL_REFILL_PER_SEC 装配期一次性
      // 读 env，非法值回构造缺省（30 突发 + 5/s 持续 / LRU 2048）——口径同四个管道开关，
      // 改 env 需重启；ACL 复用 chat/access.js 判定（fail-closed），
      // ratelimit/dedup 判定异常 fail-open。
      createRatelimitMiddleware({ ...ratelimitOptionsFromEnv(process.env), log: logger.child('ratelimit') }),
      createAclMiddleware({ getConfig: () => cfg, log: logger.child('acl') }),
      createDedupMiddleware({ log: logger.child('dedup') }),
      // US-007：边界 flush——必须在 egress 外层，回溯顺序才是「清洗 → 下发」
      createEgressFlushMiddleware({ dispatcher, log: logger.child('egress-shadow') }),
      // US-006：防思考泄漏截尾 + stripReasoning + 4000 字语义分条
      createEgressMiddleware({ log: logger.child('egress') }),
      // US-011：命令路由——必须在边界 flush/egress **内侧**（更深层）：命中入队的回复
      // 交给外层 bubble 清洗+drain 下发，与 legacy 流量同一出口路径；又必须在
      // aggregator/persona/memory/legacy **外侧**：命令不进聚合窗、不触发记忆检索，即时应答。
      // 未命中/未适配/抛错 → next() 透传（legacy 命令闸门复检兜底，双权威顺序不变）。
      pipelineCommandRouter,
      // US-008：入口合流防抖——必须紧贴遗留终端（在它之前 = 更外层），
      // 这样 followers 被 abort 时旧核心还没被派发，两级都不进，天然不会双发。
      // merge.* 参数与 hub 内部 pending 共用同一份配置，语义对齐 hub.enqueue。
      // 灰度：legacy 核心仍自持逐事件 Ingress，吞掉 followers 会让它只看得到 lead
      // 那一条报文（实测丢消息），所以本层另吃 FLAG_INGRESS_AGGREGATOR，默认不装；
      // Ingress 收编（US-009/Phase 3）后再并进 FLAG_USE_PIPELINE。
      ...(useIngressAggregator ? [pipelineAggregator] : []),
      // US-010：装配层在聚合之后、终端之前——lead 放行后为合并回合装配一次人设+记忆
      ...(memoryAssemblyOn ? [personaAssembly, memoryAssembly] : []),
      createLegacyHubFallback(hub),
    ])
    log.info(`RFC-0001 管道开关（FLAG_USE_PIPELINE）：开 — 事件走洋葱管道，遗留 hub 作终端；入口防御链=开（ratelimit/acl/dedup）；出口=${egressMode}（治理面实况=队列支路：router 命令直答与 hub 闸门透传回复；主聊天气泡由 turn/end 异步投递、落在终端 await 之后，命中包装器直发分支，不经队列/清洗/pacing/shadow 比对——见补评 F1）；入口合流=${useIngressAggregator ? '挂载（暂停透传，见 review A1/A2）' : '关（FLAG_INGRESS_AGGREGATOR）'}；上下文装配=${memoryAssemblyOn ? '开（persona/memory 接管，NEW_MEMORY_PIPELINE）' : '关（legacy provider 链）'}；命令路由=开（内置命令接管，ext/边界形态透传 legacy）}`)
  }

  // ---------- 面板接口的小工具 ----------
  const send = (res, code, body, type = 'application/json; charset=utf-8') => {
    try {
      res.statusCode = code
      res.setHeader?.('content-type', type)
      res.setHeader?.('cache-control', 'no-store')
      res.end?.(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body))
    } catch (error) {}
  }
  const readBody = async (req) => {
    let s = ''
    try { for await (const c of req) s += c } catch (error) {}
    try { return JSON.parse(s || '{}') } catch (error) { return {} }
  }
  /** 原样读请求体（上传大文件用），超过 max 字节就报错。 */
  const readRaw = async (req, max) => {
    const parts = []
    let n = 0
    for await (const c of req) {
      const b = Buffer.isBuffer(c) ? c : Buffer.from(c)
      n += b.length
      if (n > max) throw new Error(`文件太大了（最多 ${Math.round(max / 1024 / 1024)}MB）`)
      parts.push(b)
    }
    return Buffer.concat(parts)
  }
  const query = (req) => {
    try { return Object.fromEntries(new URL(req.url, 'http://x').searchParams) } catch (error) { return {} }
  }
  // 核心自己的接口登记成精确路径；模块的接口都走一个前缀路由，请求进来再查表
  // （模块随时开关、重新加载；关着的模块的接口回「模块没开」，面板不会白屏）
  const answer = async (res, fn) => {
    try {
      const r = await fn()
      if (r !== undefined) send(res, 200, r)
    } catch (error) {
      send(res, 200, { ok: false, message: redact(String(error && error.message ? error.message : error)) })
    }
  }
  const route = (path, handler) => ctx.effect(() => ctx.webServer.register({ kind: 'exact', path: PREFIX + path, handler: (req, res) => answer(res, () => handler(req, res)) }), `qq-hub: 路由 ${path}`)
  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: PREFIX, // DSH 按「路径 = 前缀 或 以 前缀/ 开头」匹配，前缀本身不带结尾的 /
    handler: (req, res) => answer(res, () => {
      let path = ''
      let qs = {}
      try {
        const u = new URL(req.url, 'http://x')
        path = u.pathname
        qs = Object.fromEntries(u.searchParams)
      } catch (error) {}
      // 模块的 handler 拿到的 req 是原始 IncomingMessage，**没有 query 属性**。
      // 以前模块里写 `req?.query?.xxx` 全是 undefined（token-guardian 的「现在压一次」、
      // memory-privacy 的 id/all、telemetry 的 days 都中招，2026-11-04 排查）。
      // 这里统一挂上去，内置模块和用户自写的扩展都能直接用 req.query。
      try { req.query = qs } catch (error) {}
      return mods.handle(path, req, res)
    }),
  }), 'qq-hub: 模块接口')

  // ---------- 模块 ----------
  const core = {
    hub, onebot, snowluma, local, groupRoles, mutes, logger, bridge: null,
    root: ROOT,
    ask: (opts) => askModel(ctx, { cfg: getConfig(), ...opts }),
    listModels,
    defaultModel: () => defaultModel(ctx, { model: {} }),
    http: { body: readBody, raw: readRaw, query, send },
    personas: { list: listPersonas, read: readPersona, current: () => currentPersonaText(cfg.persona.current) },
    getConfig, setConfig,
  }
  mods = createModules({ ctx, core, getConfig, setConfig, logger, version: VERSION, builtins: BUILTINS })
  bridge = createBridge({ ctx, getConfig, setConfig, hub, mods, log: logger.child('bridge'), version: VERSION, apiVersion: API_VERSION, overview: () => overview() })
  core.bridge = bridge
  core.modules = mods
  // 危险命令确认（可选保护）：DSH 在真正执行终端工具前会走 tools/pre-execute；
  // 这里只拦 bash / pwsh 的危险命令，其它工具和普通命令原样放行。
  dangerGuard = createDangerGuard({
    getConfig,
    log: logger.child('危险命令'),
    deliver: (chatId, text) => hub.sendText(chatId, text),
    chatOfSession: (sessionId) => { try { return hub.chatOfSession?.(sessionId) || '' } catch (error) { return '' } },
    ownerQQ: () => cfg.ownerQQ,
  })
  core.dangerGuard = dangerGuard
  ctx.effect(() => {
    let off = null
    try { off = ctx.on('tools/pre-execute', (exec, next) => dangerGuard.preExecute(exec, next)) } catch (error) { log.debug('挂危险命令确认失败：', error.message) }
    return () => { try { if (typeof off === 'function') off() } catch (error) {} }
  }, 'qq-hub: 危险命令确认')

  const sessionKey = (id) => {
    const s = String(id ?? '')
    return s.startsWith('session-') ? s.slice(8) : s
  }

  // ---------- 通用工具审批流 (approval/request) ----------
  // 接入 DSH 官方 approval seam：当模型调用敏感工具触发审批时，向主人 QQ 发送审批卡（支持 TOTP 权限锁）
  ctx.effect(() => {
    let off = null
    try {
      off = ctx.on('approval/request', async (req, next) => {
        try {
          const sid = sessionKey(req.agent?.session?.id || req.agent?.id)
          const chatId = hub.chatOfSession?.(sid)
          // 非 QQ 会话的 agent 请求，委托给下一个应答者
          if (!chatId) return next()

          let command = ''
          let args = null
          if (req.arguments) {
            args = req.arguments
            command = req.arguments.command || ''
          }
          return await hub.requestApproval(req, {
            chatId,
            sessionId: sid,
            command,
            args
          })
        } catch (error) {
          log.warn('审批处理异常：', error.message)
          return 'rejected'
        }
      })
    } catch (error) {
      log.debug('挂通用审批流失败：', error.message)
    }
    return () => { try { if (typeof off === 'function') off() } catch (error) {} }
  }, 'qq-hub: 通用工具审批')

  // ---------- 交互式提问 (userQuestions / ask_user_question) ----------
  // 接入 DSH 官方 userQuestions seam：当模型通过 ask_user_question 提问时，格式化为 A/B/C 选项卡发往 QQ
  function setupUserQuestions() {
    // 读 ctx.userQuestions 时如果没在 inject 里声明，Cordis 会直接抛，所以整段包起来，
    // 而且做成「有就接、没有就跳过」，绝不能让交互提问这个可选能力把整个插件带崩。
    let uq = null
    try { uq = ctx.userQuestions } catch (error) { log.debug('DSH 没提供 userQuestions（跳过交互提问桥接）：', error.message) }
    if (!uq) { try { uq = ctx.get?.('userQuestions') } catch (error) {} }
    if (!uq) return
    if (uq.provider) {
      const orig = uq.provider
      uq.provider = {
        async ask(req) {
          const sid = sessionKey(req.agent?.session?.id || req.agent?.id)
          const chatId = hub.chatOfSession?.(sid)
          if (chatId) {
            return await hub.askUserQuestion(chatId, req)
          }
          return await orig.ask(req)
        }
      }
      log.info('已将 QQ 交互提问桥接接入现有 userQuestions 提供方')
    } else if (typeof uq.registerProvider === 'function') {
      try {
        ctx.effect(() => {
          const off = uq.registerProvider({
            async ask(req) {
              const sid = sessionKey(req.agent?.session?.id || req.agent?.id)
              const chatId = hub.chatOfSession?.(sid)
              if (chatId) {
                return await hub.askUserQuestion(chatId, req)
              }
              throw new Error('当前会话不在 QQ 机器人管辖内')
            }
          })
          return () => { try { if (typeof off === 'function') off() } catch (error) {} }
        }, 'qq-hub: QQ交互提问提供方')
        log.info('已成功注册 QQ userQuestions 交互提问提供方')
      } catch (error) {
        log.debug('注册 userQuestions 失败：', error.message)
      }
    }
  }
  setupUserQuestions()

  // ---------- 桌宠端口注入（破「端口自举死锁」） ----------
  // pet 模块写 host.json 的 baseUrl 需要真实 Web 端口，而它自己监听不到（端口未知时只能写 null，
  // 客户端连不上 → 学不到 Host 头 → 死锁）。DSH 的 webServer 服务知道端口（ctx.webServer.port，
  // 取不到再退 DSH_WEB_URL）。注入时机：pet 每次启动/重载（module/start）+ boot 完成兜底各试一次；
  // Host 头学习仍保留，作端口漂移纠正。
  function webPortOf() {
    let port = Number(ctx?.webServer?.port)
    if (!Number.isInteger(port) || port <= 0 || port >= 65536) {
      try { port = Number(new URL(String(process.env.DSH_WEB_URL || '')).port) } catch { port = 0 }
    }
    return Number.isInteger(port) && port > 0 && port < 65536 ? port : 0
  }
  function injectPetPort() {
    const port = webPortOf()
    if (!port) return false
    try { return Boolean(use('pet')?.setWebPort?.(port)) } catch { return false }
  }
  mods.listen('module/start', (id) => { if (id === 'pet') injectPetPort() })

  const booted = mods.boot()
  booted.then(() => injectPetPort()).catch(() => {})
  booted.then(() => bridge.refresh())

  // ---------- 盯会话：一轮结束就发回 QQ ----------
  ctx.effect(() => {
    const off = ctx.on('session/event', (session, event) => {
      try {
        hub.onSessionEvent(session, event)
      } catch (error) {
        log.warn('会话事件处理出错：', error.message)
      }
      // 桌宠的「干活状态」动画 / 结束提醒：把同一条事件顺手转给 pet 模块（模块没开就是 null，纯旁路）
      try { use('pet')?.onSessionEvent?.(session, event) } catch (error) { log.debug?.('桌宠状态联动出错：', error.message) }
      // 真实用量信号：assistant/message 带 usage，转给模块（token-guardian 判定压缩用）。
      // 纯内存转发，不落盘、不开关、面板无痕 —— 用量遥测面板功能已按需求移除。
      try {
        const d = event && event.data
        if (event.type === 'assistant/message' && d && d.usage) {
          const sid = session && session.id
          mods.emit('session/usage', {
            sessionId: sid ? String(sid) : '',
            chatId: (sid && hub.chatOfSession?.(String(sid))) || '',
            model: (cfg.model && cfg.model.model) || '',
            usage: d.usage,
          })
        }
      } catch (error) { log.debug?.('用量转发出错：', error.message) }
    })
    return () => { try { if (typeof off === 'function') off() } catch (error) {} }
  }, 'qq-hub: 盯会话')

  // ---------- 启动 / 看门狗 ----------
  async function watchdog() {
    if (!cfg.enabled) {
      if (onebot.state !== 'stopped') onebot.stop()
      return
    }
    const own = cfg.gateway === 'snowluma' // 接别人的 OneBot 时不启动、不注入 SnowLuma
    const inst = snowluma.detect()
    if (own && inst.installed && cfg.snowluma.autoStart && !(await snowluma.running())) {
      const r = await snowluma.start()
      log.info('SnowLuma：', r.message)
    }
    // 上次连上的不是机器人号：等主人手动点「接入机器人号」或改设置再连
    if (wrongAccount) return
    if (onebot.state === 'stopped') onebot.start()
    if (own && cfg.snowluma.autoAttach && cfg.snowluma.webuiPassword && onebotState !== 'connected' && (await snowluma.running())) {
      const last = snowluma.lastAttach
      if (Date.now() - last.at > 60_000) {
        const r = await snowluma.attachBot()
        log.info('接入机器人号：', r.message)
      }
    }
  }
  const safe = (fn, label) => () => { Promise.resolve().then(fn).catch((error) => log.warn(`${label}出错：`, error.message)) }
  ctx.effect(() => ctx.interval(safe(watchdog, '看门狗'), 30_000), 'qq-hub: 看门狗')
  setTimeout(safe(watchdog, '看门狗'), 3000).unref?.()
  ctx.effect(() => () => {
    // US-008：管道里的合流中间件先卸（清窗口定时器 + 中止挂起 ctx），flag-off 时为 null
    try { pipelineAggregator?.dispose?.() } catch (error) { log.warn('入口合流卸载出错：', error.message) }
    hub.disposeRecentMedia()
    mods.dispose()
    onebot.stop()
    snowluma.dispose()
  }, 'qq-hub: 收尾')

  // ---------- 面板接口 ----------
  let consentCache = { at: 0, value: null }
  async function consented(running) {
    if (!running) return null
    if (Date.now() - consentCache.at < 30_000) return consentCache.value
    let value = null
    try { value = !(await snowluma.agreements()).consentRequired } catch (error) {}
    consentCache = { at: Date.now(), value }
    return value
  }

  async function overview() {
    const inst = snowluma.detect()
    const running = inst.installed ? await snowluma.running() : false
    let login = null
    if (onebotState === 'connected') {
      try {
        const info = await onebot.call('get_login_info', {}, { timeoutMs: 5000 })
        login = { uin: String(info?.user_id ?? ''), nickname: info?.nickname || '' }
      } catch (error) {}
    }
    const diary = use('diary')
    const memory = use('memory')
    return {
      ok: true,
      version: VERSION,
      apiVersion: API_VERSION,
      config: publicConfig(cfg),
      onebot: { state: onebotState, login, endpoint: { httpUrl: endpoint().httpUrl, wsUrl: endpoint().wsUrl }, problem: onebotState === 'connected' && loginOk ? '' : await connectionProblem() },
      snowluma: { ...inst, running, consented: await consented(running), owns: snowluma.ownsProcess, lastAttach: snowluma.lastAttach, downloadPage: DOWNLOAD_PAGE, webui: snowluma.webuiUrl() },
      stats: hub.stats(),
      // 模块关着时给个空壳，面板照常显示
      mood: use('mood')?.state?.() ?? { value: 0, label: '心情模块关着', reason: '', history: [] },
      stickers: { count: stickers.library().items.length },
      diary: diary ? { next: diary.nextTime(), last: diary.history()[0] || null } : { next: 0, last: null },
      qzoneSocial: use('qzone-social')?.state?.() ?? null,
      speakUp: use('speakup')?.state?.() ?? { count: 0 },
      purpose: purposeOverview(),
      pet: petStatus(),
      memory: { lastConsolidate: memory?.lastConsolidate?.() ?? 0 },
      avatar: avatarInfo(),
      voice: { edgeInstalled: use('voice')?.edgeInstalled?.() ?? false },
      song: use('song')?.status?.() ?? null,
      sessions: hub.sessions(),
      workspaceDir: workspaceDirOf(cfg),
      personas: listPersonas(),
      modules: mods.status(),
      bridge: { dshTools: cfg.bridge.dshTools, http: cfg.bridge.http, hasToken: Boolean(cfg.bridge.token), tools: bridge.deniedTools(), toolsService: Boolean(ctx.get?.('tools')) },
    }
  }

  // ---------- 面板：目的机制 / 桌宠 聚合 ----------
  // 面板令牌脱敏：任何 32 位以上的十六进制串（pet host-token、bridge token 等）只留尾 4 位。
  const HEX_RE = /[0-9a-f]{32,}/gi
  function redactTokens(value) {
    const walk = (v) => typeof v === 'string' ? v.replace(HEX_RE, (m) => '（已脱敏…' + m.slice(-4) + '）')
      : Array.isArray(v) ? v.map(walk)
      : v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).map(([k, x]) => /token|secret/i.test(k) && typeof x === 'string' && x ? [k, '（已脱敏…' + String(x).slice(-4) + '）'] : [k, walk(x)]))
      : v
    return walk(value)
  }
  // 「目的引擎」聚合：purpose 是默认关的独立内置模块，没开时 available=false，面板显示引导文案，不报错。
  // 安静时段真相 = speakUp 醒着窗口（与 purpose/module.js 的 purposeConfig 派生保持一致）。
  function purposeOverview() {
    const pu = use('purpose')
    const ext = (cfg.ext && cfg.ext.purpose) || {}
    const sp = cfg.speakUp || {}
    const pad2 = (n) => String(n % 24).padStart(2, '0')
    const awakeFrom = Number.isFinite(sp.awakeFrom) ? sp.awakeFrom : 8
    const awakeTo = Number.isFinite(sp.awakeTo) ? sp.awakeTo : 23
    const quiet = awakeTo >= 24 || awakeFrom >= awakeTo ? { quietStart: '00:00', quietEnd: '00:00' } : { quietStart: pad2(awakeTo) + ':00', quietEnd: pad2(awakeFrom) + ':00' }
    return {
      available: typeof pu?.status === 'function',
      enabled: ext.enabled === true,
      status: pu?.status?.() ?? null,
      count: pu?.state?.().count ?? 0,
      carrier: ext.carrier === 'pet' ? 'pet' : 'qq',
      petFallbackToQQ: ext.petFallbackToQQ !== false,
      quietStart: quiet.quietStart,
      quietEnd: quiet.quietEnd,
      dailyMax: Number.isFinite(sp.maxPerDay) ? sp.maxPerDay : null,
      awakeFrom,
      awakeTo,
    }
  }
  const petStatus = () => redactTokens(use('pet')?.status?.() ?? null)

  route('/state', async () => overview())

  // 工作区维护：宿主自带的删除入口在界面上，脚本化处理时没有门路，这里补两个只读/清理接口。
  // 背景：1.3.33 曾按聊天建子工作区（每个群一个「QQ Hub」），1.3.41 已改回共用主工作区，
  // 但那些已经建出来的子工作区要能被清掉（会话会落回「未分组」，文件夹自己删）。
  route('/workspaces/list', async () => {
    const reg = dsh.workspaceRegistry || dsh.get('workspaceRegistry')
    if (!reg) return { ok: false, message: '宿主没有 workspaceRegistry' }
    return {
      ok: true,
      workspaces: reg.list().map((w) => ({ id: w.id, title: w.title || '', path: w.path || '', sessions: (w.sessionIds || []).length })),
    }
  })

  route('/workspaces/delete', async (req) => {
    const body = await readBody(req)
    const ids = (Array.isArray(body?.ids) ? body.ids : [body?.id])
      .map((x) => String(x || '').trim())
      .filter(Boolean)
    if (!ids.length) return { ok: false, message: '没说要删哪个工作区' }
    const reg = dsh.workspaceRegistry || dsh.get('workspaceRegistry')
    if (!reg) return { ok: false, message: '宿主没有 workspaceRegistry' }
    const done = []
    const failed = []
    for (const id of ids) {
      const ws = reg.list().find((w) => String(w.id) === id)
      if (!ws) {
        failed.push({ id, message: '没这个工作区' })
        continue
      }
      try {
        // 先把这个工作区里还挂着的 QQ 会话收掉，否则删完工作区，会话再开会找不到落脚点
        for (const [chatId, ent] of Object.entries(hub.sessions() || {})) {
          const sid = String(ent?.sessionId || '')
          if (sid && (ws.sessionIds || []).includes(sid)) {
            try {
              await hub.resetChat(chatId)
              log.info('删工作区前先收了会话：' + chatId)
            } catch (error) {
              log.warn('收会话失败：' + chatId, error.message)
            }
          }
        }
        reg.delete(id)
        done.push({ id, title: ws.title || '', path: ws.path || '' })
        log.info('删掉工作区：' + (ws.title || '') + '（' + (ws.path || '') + '）')
      } catch (error) {
        failed.push({ id, message: error.message })
      }
    }
    return { ok: failed.length === 0, done, failed }
  })

  route('/save', async (req) => {
    const body = await readBody(req)
    const before = cfg
    // 控制台密码不能只改配置（SnowLuma 那边还是旧的）：拿出来单独去 SnowLuma 改
    const newPw = typeof body?.snowluma?.webuiPassword === 'string' ? body.snowluma.webuiPassword : ''
    if (body?.snowluma) delete body.snowluma.webuiPassword
    setConfig(mergeFromPanel(cfg, body))
    let pw = null
    if (newPw && newPw !== before.snowluma.webuiPassword) pw = await snowluma.setPassword(newPw)
    const changedConn = before.gateway !== cfg.gateway || ['httpUrl', 'wsUrl', 'httpToken', 'wsToken', 'dir'].some((k) => before.snowluma[k] !== cfg.snowluma[k])
    // 换了模型：思考强度和「能不能看图」的探测结果都得重来，不然要等 10 分钟缓存过期
    const changedModel = before.model.provider !== cfg.model.provider || before.model.model !== cfg.model.model
      // 按聊天分的模型表变了也算（否则只改群默认、全局没动时缓存不会刷新）
      || JSON.stringify(before.chatModels) !== JSON.stringify(cfg.chatModels)
    if (changedModel) { clearReasoningCache(); clearVisionCache() }
    // 模型配置一改就直接同步到已有会话：平时要等对方发下一条消息才切，
    // 冷群几小时不动，主人看到的就是「配了没生效」。
    if (changedModel) {
      Promise.resolve().then(() => hub.syncAllModels?.()).then((r) => {
        if (r && r.applied) log.info(`[模型] 保存后同步了 ${r.applied} 个会话`)
      }).catch((error) => log.debug('保存后同步模型失败：', error.message))
    }
    if (changedConn || before.botQQ !== cfg.botQQ) wrongAccount = ''
    if (changedConn && onebot.state !== 'stopped') onebot.restart()
    // 人设配置变了（全局 current / 分群分流表 / 群·私聊默认）：受影响的会话立刻重置。
    // 旧历史里的人设块清不掉，模型每轮花上万 token 仲裁「我到底是谁」（P0-5 同根因）。
    // agentFor 的 hook 下一轮也会兜底，这里提前到保存动作本身，冷群不用等消息进来。
    const personaChanged = JSON.stringify(before.persona || {}) !== JSON.stringify(cfg.persona || {})
    if (personaChanged) {
      let reset = 0
      try {
        for (const [chatId, entry] of Object.entries(hub.sessions() || {})) {
          if (!entry.personaId) continue
          const want = personaIdFor({ kind: chatId.startsWith('group:') ? 'group' : chatId.startsWith('private:') ? 'private' : 'system', groupId: chatId.slice(6), userId: chatId.slice(8) }, cfg)
          if (want && entry.personaId !== want) { hub.resetChat(chatId); reset++ }
        }
      } catch (error) {
        log.debug('人设配置变更后重置会话出错：', error.message)
      }
      if (reset) log.info(`[人设] 配置变更，重置了 ${reset} 个会话`)
    }
    if (!before.enabled && cfg.enabled) setTimeout(safe(watchdog, '看门狗'), 100)
    if (before.enabled && !cfg.enabled) onebot.stop()
    log.info(`设置已保存｜总开关 ${cfg.enabled ? '开' : '关'}｜试运行 ${cfg.dryRun ? '开' : '关'}`)
    await mods.sync().catch(() => {})
    if (pw && !pw.ok) return { ...(await overview()), ok: false, message: '其他设置保存了，但控制台密码没改：' + pw.message }
    return { ...(await overview()), message: '保存好了' + (pw ? '，' + pw.message : '') }
  })

  // ---------- 面板代理：目的引擎 / 桌宠 ----------
  // 统一走 /panel/* 前缀，避免和模块自注册的 /purpose/*、/pet/* 路由撞名；模块缺新接口时降级返回 available:false。
  // 面板「按聊天换人设」用：把机器人见过的群和私聊列出来，直接选，不用手打号码
  route('/panel/chats', async () => {
    try {
      const list = typeof hub.knownChats === 'function' ? hub.knownChats() : []
      return { ok: true, chats: list }
    } catch (error) {
      return { ok: false, chats: [], error: error.message }
    }
  })
  route('/panel/purpose/status', async () => ({ ok: true, purpose: purposeOverview(), pet: petStatus() }))
  route('/panel/purpose/preview', async () => {
    const pu = use('purpose')
    if (typeof pu?.preview !== 'function') return { ok: false, available: false, message: '目的引擎模块没在跑，没法预览' }
    return { ok: true, result: redactTokens(await pu.preview()) }
  })
  route('/panel/purpose/run', async () => {
    const pu = use('purpose')
    if (typeof pu?.run !== 'function') return { ok: false, available: false, message: '目的引擎模块没在跑' }
    const r = await pu.run('面板')
    const msg = r && { sent: '已经去找你了', silent: '她这轮想了想，决定不说（不硬发）', muted: '主人在私聊里让她闭嘴了', disabled: '目的引擎开关是关的' }[r.outcome]
    return { ok: !r || r.outcome !== 'disabled', message: msg || (r ? `这轮结束：${r.outcome}` : '没有结果'), result: redactTokens(r) }
  })
  route('/panel/purpose/config', async (req) => {
    const b = await readBody(req)
    const patch = {}
    const extPatch = {}
    if (typeof b.enabled === 'boolean') extPatch.enabled = b.enabled
    if (b.carrier === 'qq' || b.carrier === 'pet') extPatch.carrier = b.carrier
    if (typeof b.petFallbackToQQ === 'boolean') extPatch.petFallbackToQQ = b.petFallbackToQQ
    if (Object.keys(extPatch).length) patch.ext = { purpose: extPatch }
    const spPatch = {}
    for (const k of ['awakeFrom', 'awakeTo', 'maxPerDay']) if (Number.isFinite(b[k])) spPatch[k] = Math.max(0, Math.floor(b[k]))
    if (Object.keys(spPatch).length) patch.speakUp = spPatch
    if (!Object.keys(patch).length) return { ok: false, message: '没有可保存的字段' }
    setConfig(mergeFromPanel(cfg, patch))
    log.info(`面板已保存目的引擎设置｜${Object.keys(extPatch).map((k) => k + '=' + extPatch[k]).concat(Object.keys(spPatch).map((k) => k + '=' + spPatch[k])).join(' ')}`)
    return { ok: true, purpose: purposeOverview() }
  })
  route('/panel/pet/status', async () => ({ ok: true, pet: petStatus() }))
  // 桌宠页下方的设置项：碎碎念（桌宠自己的气泡流）+ 干活状态动画/结束提醒
  route('/panel/pet/config', async (req) => {
    const b = await readBody(req)
    const patch = {}
    for (const k of ['whisperEnabled', 'whisperPauseOnPetCarrier', 'workStatusEnabled', 'workBubble', 'workNotify']) {
      if (typeof b[k] === 'boolean') patch[k] = b[k]
    }
    if (b.whisperSource === 'model' || b.whisperSource === 'pool') patch.whisperSource = b.whisperSource
    for (const k of ['whisperMinMinutes', 'whisperMaxMinutes', 'whisperMaxPerDay']) {
      // 面板口径：间隔 1~9999 分钟、每日上限 0~9999 次（0 = 不发）
      if (Number.isFinite(b[k])) patch[k] = k === 'whisperMaxPerDay' ? Math.min(9999, Math.max(0, Math.floor(b[k]))) : Math.min(9999, Math.max(1, Math.floor(b[k])))
    }
    if (typeof b.whisperLines === 'string') patch.whisperLines = b.whisperLines.slice(0, 4000)
    // 行为大脑的模块级设置（AI 自己改不了，只有主人能改）。pet 是**内置模块**，
    // 它的 settings schema 不会渲染成表单（面板只给「用户自己复制出来的模块」生成），
    // 所以这里是这些开关唯一的写入通道——不补，关窗物理闸就永远打不开。
    for (const k of ['behaviorEnabled', 'behaviorIconMischiefEnabled', 'behaviorCloseWindowEnabled']) {
      if (typeof b[k] === 'boolean') patch[k] = b[k]
    }
    for (const [k, lo, hi] of [
      ['behaviorMinMinutes', 1, 9999],        // 铁律：最短 1 分钟
      ['behaviorMaxMinutes', 1, 9999],
      ['behaviorMaxPerDay', 0, 999999],
      ['behaviorIdleCursorMinutes', 1, 240],
      ['behaviorMoodCloseWindowBelow', 0, 100],
      ['behaviorIconQuarantineDays', 1, 365],
    ]) {
      if (Number.isFinite(b[k])) patch[k] = Math.min(hi, Math.max(lo, Math.round(b[k])))
    }
    if (typeof b.behaviorWindowWhitelist === 'string') patch.behaviorWindowWhitelist = b.behaviorWindowWhitelist.slice(0, 2000)
    if (typeof b.behaviorDisabledActions === 'string') patch.behaviorDisabledActions = b.behaviorDisabledActions.slice(0, 500)
    if (!Object.keys(patch).length) return { ok: false, message: '没有可保存的字段' }
    setConfig(mergeFromPanel(cfg, { ext: { pet: patch } }))
    log.info(`面板已保存桌宠设置｜${Object.keys(patch).map((k) => k + '=' + String(patch[k]).slice(0, 20)).join(' ')}`)
    return { ok: true, pet: petStatus() }
  })
  // 「现在碎碎念一句」：绕过排程与开关，但仍尊重专注模式（force 只跳排程类闸门）
  route('/panel/pet/whisper', async (req) => {
    const pet = use('pet')
    if (typeof pet?.whisperNow !== 'function') return { ok: false, available: false, message: '桌宠模块还没就绪，碎碎念不了' }
    const r = await pet.whisperNow({ force: true, reason: '面板' })
    const msg = r && r.ok ? `她嘟囔了一句：${r.text}` : ({ focus: '专注模式开着，先关掉再来', 'pet-offline': '桌宠没在跑，气泡发不出去', 'plugin-off': '插件总开关是关的', thinking: '上一句她还在想（工作区那条会话还没结束），等几秒再来' }[r && r.reason] || '这轮没说出来')
    return { ok: Boolean(r && r.ok), message: msg, result: redactTokens(r) }
  })
  route('/panel/pet/download', async () => {
    const pet = use('pet')
    if (typeof pet?.download !== 'function') return { ok: false, available: false, message: '桌宠模块还没就绪，装不了客户端' }
    return { ok: true, result: redactTokens(await pet.download()) }
  })
  route('/panel/pet/focus', async (req) => {
    const enabled = Boolean((await readBody(req)).enabled)
    const pet = use('pet')
    if (typeof pet?.setFocus !== 'function') return { ok: false, available: false, message: '桌宠模块还没就绪，改不了专注模式' }
    return { ok: true, result: redactTokens(await pet.setFocus(enabled)) }
  })
  // Electron 三键：安装（npmmirror 镜像）→ 启动（清 ELECTRON_RUN_AS_NODE 分离进程）→ 停止（杀 pid）
  route('/panel/pet/electron-install', async () => {
    const pet = use('pet')
    if (typeof pet?.electronInstall !== 'function') return { ok: false, available: false, message: '桌宠模块还没就绪，装不了 Electron' }
    return { ok: true, result: redactTokens(await pet.electronInstall()) }
  })
  route('/panel/pet/launch', async () => {
    const pet = use('pet')
    if (typeof pet?.launch !== 'function') return { ok: false, available: false, message: '桌宠模块还没就绪，启动不了桌宠' }
    return { ok: true, result: redactTokens(await Promise.resolve(pet.launch())) }
  })
  route('/panel/pet/stop', async () => {
    const pet = use('pet')
    if (typeof pet?.stop !== 'function') return { ok: false, available: false, message: '桌宠模块还没就绪，停不了桌宠' }
    return { ok: true, result: redactTokens(await Promise.resolve(pet.stop())) }
  })
  // ---------- 行为动作（设计稿 §8 测试通道）：面板「试一下」+ 每动作 AI 开关 + 图标隔离区 ----------
  // 全部代理到 pet 模块已暴露的函数（behaviorEmit / behaviorStatus / iconQuarantine / iconRestore）；
  // 模块没就绪或旧版本缺接口时降级 available:false，面板显示兜底文案不炸。
  route('/panel/pet/behavior/status', async () => {
    const pet = use('pet')
    if (typeof pet?.behaviorStatus !== 'function') return { ok: false, available: false, message: '桌宠模块还没就绪' }
    return { ok: true, behavior: redactTokens(pet.behaviorStatus()) }
  })
  // 「试一下」：手动触发默认 force=true（绕排程/专注/安静时段；桌宠离线时回执会显示 refused/failed）
  route('/panel/pet/behavior', async (req) => {
    const b = await readBody(req)
    const pet = use('pet')
    if (typeof pet?.behaviorEmit !== 'function') return { ok: false, available: false, message: '桌宠模块还没就绪，试不了' }
    const r = await pet.behaviorEmit({ action: b.action, params: b.params, say: b.say, force: b.force !== false, reason: 'panel' })
    const why = {
      'unknown-action': '没有这个动作',
      'emit-failed': '下发失败（看日志）',
      // 关窗物理闸：说清去哪里开，否则面板上只看到「这轮没演成」
      'close-window-disabled': '先在「行为与安全」卡里打开「允许 AI 关闭窗口」（物理闸，手动「试一下」也绕不过）',
      'empty-text': '「说话」动作要给一句台词再试',
    }
    return {
      ok: Boolean(r && r.ok),
      reason: (r && r.reason) || '',
      message: r && r.ok
        ? `已下发「${r.action}」${r.say ? `：${r.say}` : ''}，桌宠在跑就会演`
        : (why[r?.reason] || '这轮没演成'),
      result: redactTokens(r),
    }
  })
  // 每动作「进不进 AI 动作表」：写 ext.pet.behaviorDisabledActions（逗号分隔），与模块 settings 单一真相
  route('/panel/pet/behavior/actions', async (req) => {
    const b = await readBody(req)
    const action = String(b.action || '').trim().slice(0, 40)
    if (!action) return { ok: false, message: '缺动作名' }
    // 动作名白名单（来自模块的全表）：防止手滑/旧面板把垃圾动作名写进配置
    try {
      const st = use('pet')?.behaviorStatus?.()
      const known = new Set([...(st?.openActions || []), ...(st?.deferredActions || [])])
      if (known.size && !known.has(action)) return { ok: false, message: '没有这个动作：' + action }
    } catch (error) { /* 模块没就绪就不校验，别把开关卡死 */ }
    const cur = new Set(String(getConfig().ext?.pet?.behaviorDisabledActions || '').split(',').map((x) => x.trim()).filter(Boolean))
    if (b.on === false) cur.add(action); else cur.delete(action)
    setConfig(mergeFromPanel(cfg, { ext: { pet: { behaviorDisabledActions: [...cur].join(',') } } }))
    log.info(`面板已改 AI 动作表｜${action} → ${b.on === false ? '禁用' : '启用'}`)
    return { ok: true, disabledActions: [...cur] }
  })
  // 图标隔离区清单：{items:[{id,name,originalPath,at,reason}]}
  route('/panel/pet/behavior/quarantine', async () => {
    const pet = use('pet')
    if (typeof pet?.iconQuarantine !== 'function') return { ok: false, available: false, message: '图标隔离区接口还没就绪' }
    try { return { ok: true, items: pet.iconQuarantine() || [] } } catch (error) { return { ok: false, available: false, message: '隔离区清单读不了：' + String(error?.message || error) } }
  })
  // 「放回去」：rename 回原路径（原位置被占则改名），失败按原因给人话，别让面板只挂一句「没放回去」
  route('/panel/pet/behavior/restore', async (req) => {
    const b = await readBody(req)
    const pet = use('pet')
    if (typeof pet?.iconRestore !== 'function') return { ok: false, available: false, message: '归还接口还没就绪' }
    const r = await pet.iconRestore(String(b.id || '').slice(0, 64))
    const why = { 'not-found': '隔离区里没有这条记录（可能已经放回去了）', 'quarantine-file-gone': '隔离区里的文件已经不在了，这条记录已清掉', 'restore-failed': '放回去失败（看日志）' }
    return { ok: Boolean(r && r.ok), message: r && r.ok ? `「${r.name}」放回去了` : (why[r?.reason] || '没放回去：原位置可能没了，或图标已经被移走'), result: redactTokens(r) }
  })

  // 第三批：补偿道歉（心情 +8，并标记最近一条未道歉的关窗记录；不删记录）
  route('/panel/pet/behavior/apologize', async () => {
    const pet = use('pet')
    if (typeof pet?.windowApologize !== 'function') return { ok: false, available: false, message: '道歉接口还没就绪' }
    try {
      const r = pet.windowApologize()
      return {
        ok: Boolean(r && r.ok),
        message: r && r.ok ? (r.window ? `她为「${r.window}」道了歉` : '她道了歉') : '没有需要道歉的记录',
        result: redactTokens(r),
      }
    } catch (error) { return { ok: false, message: '道歉没成功：' + String(error?.message || error) } }
  })

  route('/logs', async (req) => {
    const q = query(req)
    return { ok: true, entries: logger.recent(Number(q.limit) || 300, { level: q.level || '', area: q.area || '' }) }
  })

  // SnowLuma
  route('/snowluma/start', async () => snowluma.start())
  route('/snowluma/stop', async () => snowluma.stop())
  route('/snowluma/attach', async () => {
    wrongAccount = ''
    snowluma.clearRejected()
    const r = await snowluma.attachBot()
    if (cfg.enabled && onebot.state === 'stopped') onebot.start()
    return r
  })
  route('/commands', async () => ({ ok: true, list: commandList(mods.commands()) }))
  // 更新：检查 GitHub 上有没有新版本；这次更新了什么
  const checkUpdate = createUpdateChecker({ pkg: PKG, log })
  route('/update/check', async (req) => checkUpdate({ force: query(req).force === '1' }))
  route('/changelog', async () => {
    let text = ''
    try { text = readFileSync(join(ROOT, 'CHANGELOG.md'), 'utf8') } catch (error) {}
    return { ok: true, version: VERSION, notes: changelogSection(text, VERSION) }
  })
  route('/snowluma/login-check', async () => ({ ...(await snowluma.canLogin()), passwordAuto: cfg.snowluma.passwordAuto, running: await snowluma.running() }))
  route('/snowluma/agreements', async () => {
    try { return { ok: true, ...(await snowluma.agreements()) } } catch (error) { return { ok: false, message: error.message } }
  })
  route('/snowluma/consent', async (req) => {
    const b = await readBody(req)
    if (b.agree !== true) return { ok: false, message: '要先勾选「我已阅读并同意」' }
    consentCache = { at: 0, value: null }
    return snowluma.consent(b.version)
  })
  route('/snowluma/reset-password', async () => snowluma.resetPassword())
  // 控制台密码：看一眼（打开 SnowLuma 自己的控制台要用）、自己设一个
  route('/snowluma/password', async () => ({ ok: true, password: snowluma.password(), auto: cfg.snowluma.passwordAuto }))
  route('/snowluma/set-password', async (req) => snowluma.setPassword(String((await readBody(req)).password || '')))
  route('/setup/done', async (req) => {
    const body = await readBody(req)
    if (!cfg.botQQ || !cfg.ownerQQ || cfg.botQQ === cfg.ownerQQ) return { ok: false, message: '先填好不同的机器人 QQ 和你的 QQ' }
    if (body.existingConnection && !(cfg.enabled && onebotState === 'connected' && loginOk)) return { ok: false, message: 'QQ 网关还没通过机器人号核对，请先连接并核对后再进入面板' }
    setConfig({ ...cfg, setupDone: true })
    log.info('首次使用向导完成')
    return { ...(await overview()), message: '设置完成，大肥鱼可以上线啦' }
  })
  route('/snowluma/processes', async () => {
    try { return { ok: true, list: await snowluma.processes() } } catch (error) { return { ok: false, message: error.message, list: [] } }
  })
  /** 连不上 QQ 网关时，按顺序找卡在哪一步，给一句人话。 */
  async function connectionProblem() {
    if (!cfg.enabled) return '总开关关着（右上角），打开后才会连'
    if (!cfg.botQQ) return '还没填机器人 QQ 号'
    if (cfg.gateway === 'onebot') {
      const ep = endpoint()
      if (!ep.wsUrl) return '还没填 OneBot 的 WebSocket 地址：在「连接」页填你的 OneBot v11 正向 WebSocket 地址（收消息要靠它；HTTP 可以不填）'
      if (wrongAccount) return `连上的是 ${wrongAccount}，不是机器人号 ${cfg.botQQ}，已经断开：让你的 OneBot 服务登录机器人号，再点「重新连接」`
      return `连 ${ep.wsUrl || ep.httpUrl} 没连上：确认你的 OneBot 服务开着、地址和 token 填对了（Docker 里的话，地址要用 DSH 能访问到的主机名 / 端口）`
    }
    const inst = snowluma.detect()
    if (!inst.installed && !(cfg.snowluma.wsUrl || cfg.snowluma.httpUrl)) return 'SnowLuma 没装好：' + inst.reason
    if (inst.installed && !(await snowluma.running())) return 'SnowLuma 没在运行：点上面的「启动」'
    if (snowluma.lowIntegrity) return 'SnowLuma 以「低完整性」运行，看不到 QQ 进程（多半是解压在了下载目录这类带安全标签的地方）：把它重新解压到一个普通目录（比如 D:\SnowLuma），在「连接」页改好目录再启动'
    const ep = endpoint()
    if (!ep.wsUrl && !ep.httpUrl) return 'SnowLuma 还没给机器人号开 OneBot 端口，也就是机器人号还没接入：确认机器人号的 QQ 已经登录，再点「接入机器人号」'
    if (wrongAccount) return `连上的是 ${wrongAccount}，不是机器人号 ${cfg.botQQ}，已经断开：只登着机器人号那个 QQ，再点「接入机器人号」`
    const la = snowluma.lastAttach
    if (la && la.at && !la.ok && la.message) return '接入机器人号没成功：' + la.message
    return `连 ${ep.wsUrl || ep.httpUrl} 没连上：确认机器人号的 QQ 开着、已经登录，并且 SnowLuma 控制台里这个号显示已接入`
  }
  route('/onebot/reconnect', async () => {
    if (!cfg.enabled) return { ok: false, message: await connectionProblem() }
    wrongAccount = ''
    onebot.restart()
    // 等几秒看结果，别只回一句「正在重连」
    for (let i = 0; i < 16 && !(onebotState === 'connected' && loginOk); i++) await new Promise((r) => setTimeout(r, 500))
    if (onebotState === 'connected' && loginOk) return { ok: true, message: '连上了' }
    return { ok: false, message: '没连上：' + (await connectionProblem()) }
  })
  route('/onebot/test', async () => {
    try {
      const info = await onebot.call('get_login_info', {}, { timeoutMs: 8000 })
      const uin = String(info?.user_id ?? '')
      return { ok: uin === cfg.botQQ, message: uin === cfg.botQQ ? `连上了：${info.nickname}（${uin}）` : `连上的是 ${uin}，不是机器人号 ${cfg.botQQ}！`, info }
    } catch (error) {
      return { ok: false, message: error.message }
    }
  })
  route('/test-send', async () => {
    if (!cfg.enabled) return { ok: false, message: '先打开总开关' }
    if (cfg.dryRun) return { ok: false, message: '现在是试运行，先关掉试运行再测' }
    const r = await hub.sendText(`private:${cfg.ownerQQ}`, '【QQ Hub 自测】已连通，这是一条自测消息～')
    return r ? { ok: true, message: '发给主人了，去 QQ 看看' } : { ok: false, message: '没发出去（看日志）' }
  })

  route('/sessions/reset', async () => {
    const n = hub.resetSessions()
    return { ok: true, message: n ? `归档了 ${n} 个会话，下一条消息起她会重新开始` : '本来就没有会话' }
  })

  // 人格
  route('/personas', async () => ({ ok: true, list: listPersonas(), current: cfg.persona.current }))
  route('/persona/get', async (req) => {
    const p = readPersona(query(req).id)
    return p ? { ok: true, persona: p } : { ok: false, message: '没有这个人格' }
  })
  route('/persona/save', async (req) => {
    const b = await readBody(req)
    const p = savePersona(b.id, b)
    // 人设正文变了：还在用旧正文的会话要重置（P1-4）。静态前缀 {{qq_hub_persona}} 是建会话时
    // 固化的，光改文件旧会话拿不到；不重置的话新旧两段人设会在历史里打架（P0-5 同根因）。
    let reset = 0
    try {
      for (const [chatId, entry] of Object.entries(hub.sessions() || {})) {
        if (entry.personaId === b.id) { hub.resetChat(chatId); reset++ }
      }
    } catch (error) {
      log.debug('人设保存后重置会话出错：', error.message)
    }
    return { ok: true, persona: p, message: reset > 0 ? `人格已保存，${reset} 个正在用的会话已重置，下一轮起生效` : '人格已保存，下一轮起生效' }
  })
  route('/persona/delete', async (req) => {
    const b = await readBody(req)
    if (b.id === cfg.persona.current) return { ok: false, message: '正在用的人格不能删' }
    deletePersona(b.id)
    return { ok: true, list: listPersonas() }
  })
  route('/persona/use', async (req) => {
    const b = await readBody(req)
    if (!readPersona(b.id)) return { ok: false, message: '没有这个人格' }
    // 只改 current，别把 persona 整块替换掉——否则按聊天配的人设会被一起清空
    setConfig({ ...cfg, persona: { ...(cfg.persona || {}), current: b.id } })
    log.info(`切换人格 → ${b.id}`)
    // 切完立刻重置正在用全局人设的会话：旧历史里的人设块清不掉，模型会逐条仲裁新旧人设
    //（agentFor 里按 personaId 比对的 hook 下一轮也会触发，这里提前到保存动作本身）。
    let reset = 0
    try {
      for (const [chatId, entry] of Object.entries(hub.sessions() || {})) {
        if (entry.personaId && entry.personaId === (cfg.persona && cfg.persona.current)) { hub.resetChat(chatId); reset++ }
      }
    } catch (error) {
      log.debug('切换人格后重置会话出错：', error.message)
    }
    return { ok: true, current: b.id, message: reset > 0 ? `切换好了，${reset} 个正在用的会话已重置，下一轮起生效` : '切换好了，下一轮回复起生效' }
  })
  // 人格页「AI 润色」：只改面板上这一节的文字，不保存；用不用由主人在面板里选
  route('/persona/polish', async (req) => {
    const b = await readBody(req)
    const title = String(b.title || '').slice(0, 30) || '开场（她是谁）'
    const text = String(b.text || '').slice(0, 4000)
    const others = (Array.isArray(b.others) ? b.others : []).map((x) => String(x).slice(0, 30)).slice(0, 20)
    const system = '你在帮人改一个 QQ 聊天角色的人设。人设按【标题】分节，你一次只改其中一节。' +
      '只输出这一节改好后的正文：不要写标题，不要加粗、不要 Markdown 标题，不要任何解释。原来是「- 」开头的条目就继续用条目，一条一行、短句。'
    const ask = [
      `角色：${String(b.name || '她').slice(0, 30)}`,
      `要改的这一节：${title}`,
      `人设里另外几节：${others.join('、') || '无'}（只是让你知道还有哪些，别把它们的内容写进这一节）`,
      text.trim()
        ? '要求：保留原来的设定和事实，不编新的身份信息；说得更具体、更像真人；删掉重复和空话；长度别超过原来的 1.5 倍。'
        : '要求：这一节还是空的，按这个角色和这一节的标题写 4 到 8 条。',
      text.trim() ? `原文：\n${text}` : '',
    ].filter(Boolean).join('\n')
    try {
      const out = String(await askModel(ctx, { cfg: getConfig(), system, text: ask, maxTokens: 1500, temperature: 0.6 }) || '')
        .replace(/^```[a-z]*\n?|\n?```$/g, '').replace(new RegExp('^【' + title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '】\\s*'), '').trim()
      return out ? { ok: true, text: out } : { ok: false, message: '模型没给出内容，再试一次' }
    } catch (error) {
      return { ok: false, message: '润色没成功：' + error.message }
    }
  })

  // 按群头衔不理：白名单里的群（带群名）+ 这些群里现有的头衔，面板里点一个就设成要过滤的那类

  // 本地接口
  const openFolder = (dir) => {
    mkdirSync(dir, { recursive: true })
    spawn('explorer.exe', [dir], { detached: true, stdio: 'ignore' }).unref()
    return { ok: true, message: '打开了' }
  }
  route('/local/status', async () => ({ ok: true, dir: local.dir(), list: local.status() }))
  route('/local/template', async (req) => {
    const slot = String((await readBody(req)).slot || '')
    if (!local.pathOf || !['tts', 'image', 'song', 'asr'].includes(slot)) return { ok: false, message: '没有这一项' }
    return local.template(slot)
  })
  route('/local/open', async () => openFolder(local.dir()))
  route('/local/test', async (req) => {
    const slot = String((await readBody(req)).slot || '')
    try {
      if (slot === 'tts') {
        const file = fileOf(await local.call('tts', { text: '你好呀，我是大肥鱼，这是本地语音测试。' }))
        if (!file || !existsSync(file)) return { ok: false, message: '脚本没返回音频文件' }
        return { ok: true, message: `念好了：${file}` }
      }
      if (slot === 'image') {
        const buf = await toImageBuffer(await local.call('image', { prompt: '一条胖乎乎的蓝色小鱼，可爱，插画', size: cfg.imageGen.size || '1024x1024' }))
        return { ok: true, message: `画好了（${Math.round(buf.length / 1024)} KB）`, image: buf.toString('base64') }
      }
      return { ok: false, message: '这一项没法单独试：翻唱换声去 QQ 里点首歌，语音识别发条语音条试试' }
    } catch (error) {
      return { ok: false, message: '出错了：' + error.message }
    }
  })

  // 模块（面板「扩展」页）
  route('/modules', async () => ({ ok: true, dir: mods.dir(), safeMode: cfg.safeMode, apiVersion: API_VERSION, list: mods.status(), prompt: mods.promptFor('') }))
  route('/modules/reload', async (req) => {
    const id = String((await readBody(req)).id || '')
    if (!id) { await mods.sync(); return { ok: true, message: '检查过了', list: mods.status() } }
    const m = await mods.reload(id)
    return { ok: Boolean(m && !m.error), message: m?.error ? '加载失败：' + m.error : '重新加载好了', list: mods.status() }
  })
  route('/modules/create', async (req) => {
    const b = await readBody(req)
    const r = mods.create(String(b.id || '').trim(), String(b.name || '').trim())
    if (r.ok) await mods.sync()
    return { ...r, list: mods.status(), prompt: r.ok ? mods.promptFor(String(b.id).trim()) : '' }
  })
  route('/modules/fork', async (req) => {
    const id = String((await readBody(req)).id || '')
    const r = mods.fork(id)
    if (r.ok) await mods.sync()
    return { ...r, list: mods.status(), prompt: r.ok ? mods.promptFor(id) : '' }
  })
  route('/modules/prompt', async (req) => ({ ok: true, prompt: mods.promptFor(String(query(req).id || '')) }))
  route('/modules/open', async (req) => {
    const id = String(query(req).id || '')
    return openFolder(id ? join(mods.dir(), id) : mods.dir())
  })
  // 模拟测试：不用上 QQ 就能试模块。发出去的消息只截下来给面板看，不真发
  // （模块直接调 api.onebot(...) 的操作不在此列，是真的会执行的）
  const simChat = (b) => {
    const owner = b.as !== 'other'
    const userId = owner ? cfg.ownerQQ : '10001'
    const group = b.kind === 'group'
    const groupId = String(b.groupId || cfg.allow.groups[0] || '10002')
    return { owner, userId, chat: group ? { chatId: `group:${groupId}`, kind: 'group', groupId, userId } : { chatId: `private:${userId}`, kind: 'private', userId } }
  }
  // 没有文字的（语音条、表情、图片）显示发送备注，比如「[语音·edge] 早呀」
  const sentLines = (sent) => sent.map((s) => ({ chatId: s.chatId, note: s.note, text: s.message.some((seg) => seg.type === 'text') ? s.message.map((seg) => (seg.type === 'text' ? seg.data.text : seg.type === 'reply' ? '' : `[${seg.type}]`)).join('') : s.note }))
  route('/modules/simulate', async (req) => {
    const b = await readBody(req)
    const { owner, userId, chat } = simChat(b)
    const text = String(b.text || '')
    const steps = []
    const msg = { ...chat, nickname: owner ? cfg.ownerName || '主人' : '路人', role: '', messageId: 'sim', text, mentioned: Boolean(b.mentioned), replyId: '', images: [], stickers: [], records: [], forwards: [], raw: { simulated: true } }
    const { sent } = await hub.capture(async () => {
      if (text) {
        const cmd = owner && /^\s*[/／]/.test(text) ? parseCommand(text, mods.commands()) : null
        if (cmd && cmd.ext) {
          const reply = String((await cmd.ext.run(cmd.arg, msg)) ?? '')
          steps.push(`命令 /${cmd.name}（模块「${cmd.ext.module}」）回：${reply || '（空）'}`)
          if (reply) await hub.sendText(chat.chatId, reply)
        } else if (cmd) {
          steps.push(`这是内置命令 /${cmd.name}，模拟里不执行（会真的改设置）`)
        } else if (await mods.claim('message', msg)) {
          steps.push('有模块接管了这条消息，她不会再回')
        } else {
          steps.push('没有模块接管，这条会交给她（模拟里不会真的让她想）')
        }
      }
      if (b.reply) {
        const items = await hub.deliver(chat.chatId, String(b.reply), { simulate: true })
        steps.push(items ? `她的回复经过模块改写后拆成 ${items.length} 条` : '她的回复被模块拦下了，不发')
      }
    })
    return { ok: true, steps, sent: sentLines(sent) }
  })
  route('/modules/tools', async (req) => {
    const q = query(req)
    const { owner, chat } = simChat(q)
    const level = owner && chat.kind === 'private' ? 'full' : 'social'
    return { ok: true, level, list: mods.buildTools({ chat, level, sessionId: 'sim' }).map((t) => ({ name: t.name, description: t.description, parameters: t.parameters })) }
  })
  route('/modules/tool', async (req) => {
    const b = await readBody(req)
    const { owner, userId, chat } = simChat(b)
    const level = owner && chat.kind === 'private' ? 'full' : 'social'
    const tool = mods.buildTools({ chat, level, sessionId: 'sim' }).find((t) => t.name === b.name)
    if (!tool) return { ok: false, message: `这个场合没有 ${b.name} 这个工具` }
    hub.simulateTurn('sim', [userId])
    const { result, sent } = await hub.capture(() => tool.execute(b.args && typeof b.args === 'object' ? b.args : {}, {}))
    return { ok: true, result, sent: sentLines(sent) }
  })
  route('/modules/panel', async (req, res) => {
    const src = mods.panelSource(String(query(req).id || ''))
    if (src === null) return send(res, 404, '')
    send(res, 200, src, 'text/javascript; charset=utf-8')
  })

  // 联动
  route('/bridge/token', async () => ({ ok: true, token: cfg.bridge.http ? bridge.ensureToken() : '' }))
  route('/bridge/token/reset', async () => ({ ok: true, token: bridge.resetToken(), message: '换了新密钥，旧的立刻失效' }))
  route('/bridge/examples', async (req) => ({ ok: true, ...bridge.examples(String(query(req).base || 'http://127.0.0.1:端口')) }))
  // 开放接口：都要带密钥
  const open = (path, fn) => route('/open' + path, async (req) => {
    if (!bridge.authorized(req)) return { ok: false, code: 401, message: cfg.bridge.http ? '密钥不对（请求头 Authorization: Bearer 密钥）' : '开放接口没打开（面板「扩展」→ 联动）' }
    return fn(req)
  })
  open('/info', async () => bridge.ops.info())
  open('/send', async (req) => bridge.ops.send(await readBody(req)))
  open('/think', async (req) => bridge.ops.think(await readBody(req)))
  open('/call', async (req) => bridge.ops.call(await readBody(req)))
  open('/events', async (req) => bridge.ops.events(query(req)))

  // 模型：列出 DSH 里可用的模型，测一下哪个回得快
  /** 把面板配的模型立刻应用到所有已有 QQ 会话（不用等对方发下一条消息）。 */
  route('/models/apply', async () => {
    try {
      const r = await hub.syncAllModels()
      if (r.applied) log.info(`[模型] 按面板配置切换了 ${r.applied} 个会话`)
      // 消息要如实反映：有失败就说失败，别在失败时还说「都和配置一致」
      const parts = []
      if (r.applied) parts.push(`切换了 ${r.applied} 个会话`)
      if (r.failed) parts.push(`${r.failed} 个切不了（会话可能已失效，发条消息让它重建）`)
      if (!r.applied && !r.failed) parts.push(`没有需要切的会话（都和配置一致）`)
      return { ok: r.failed === 0, ...r, message: parts.join('；') }
    } catch (error) {
      return { ok: false, message: error.message }
    }
  })

  route('/models', async (req) => {
    try {
      if (new URL(req.url, 'http://x').searchParams.get('refresh') === '1') { clearReasoningCache(); clearVisionCache() }
      return { ok: true, list: await listModels() }
    } catch (error) {
      return { ok: false, message: error.message, list: [] }
    }
  })
  route('/model/ping', async (req) => {
    const b = await readBody(req)
    const t = Date.now()
    try {
      const text = await askModel(ctx, { cfg: { model: { provider: b.provider, model: b.model } }, system: '只回复两个字：在呢', text: '在吗', maxTokens: 800 })
      return { ok: true, ms: Date.now() - t, text: text.slice(0, 40) }
    } catch (error) {
      return { ok: false, ms: Date.now() - t, message: error.message }
    }
  })

  // 形象图
  // 头像：自定义的放在数据目录（重装插件不丢），没有就用插件自带的大肥鱼
  const AVATAR = () => dataDir('avatar.img')
  const avatarInfo = () => {
    try { return { custom: true, at: statSync(AVATAR()).mtimeMs } } catch (error) { return { custom: false, at: 0 } }
  }
  route('/avatar', async (req, res) => {
    if (existsSync(AVATAR())) {
      const buf = readFileSync(AVATAR())
      return send(res, 200, buf, mimeOf(buf))
    }
    const p = join(ROOT, 'assets', 'dafeiyu.jpg')
    if (!existsSync(p)) return send(res, 404, '')
    send(res, 200, readFileSync(p), 'image/jpeg')
  })
  route('/avatar/upload', async (req) => {
    const b = await readBody(req)
    const buf = Buffer.from(String(b.data || '').replace(/^data:[^,]+,/, ''), 'base64')
    if (!buf.length || buf.length > 5 * 1024 * 1024) return { ok: false, message: '图片太大（最多 5MB）或是空的' }
    if (!mimeOf(buf).startsWith('image/')) return { ok: false, message: '只支持 PNG、JPG、GIF、WebP 图片' }
    ensureDir(dataDir())
    writeFileSync(AVATAR(), buf)
    log.info('换了面板头像')
    return { ok: true, message: '头像换好了', avatar: avatarInfo() }
  })
  route('/avatar/reset', async () => {
    try { unlinkSync(AVATAR()) } catch (error) {}
    return { ok: true, message: '恢复成默认头像了', avatar: avatarInfo() }
  })
  route('/avatar/sync-qq', async () => {
    const buf = existsSync(AVATAR()) ? readFileSync(AVATAR()) : readFileSync(join(ROOT, 'assets', 'dafeiyu.jpg'))
    try {
      await onebot.call('set_qq_avatar', { file: 'base64://' + buf.toString('base64') })
      return { ok: true, message: '已经设成机器人号的 QQ 头像' }
    } catch (error) {
      return { ok: false, message: 'QQ 头像没换成：' + error.message }
    }
  })

  log.info(`QQ Hub v${VERSION} 已加载｜总开关 ${cfg.enabled ? '开' : '关'}｜试运行 ${cfg.dryRun ? '开' : '关'}｜工作区 ${workspaceDirOf(cfg)}`)

  return {
    hub, onebot, snowluma, getConfig, setConfig, logger, modules: mods, bridge, ready: booted,
    get stickers() { return use('stickers') },
    get qzone() { return use('diary') },
    get mood() { return use('mood') },
    get memory() { return use('memory') },
  }
}
