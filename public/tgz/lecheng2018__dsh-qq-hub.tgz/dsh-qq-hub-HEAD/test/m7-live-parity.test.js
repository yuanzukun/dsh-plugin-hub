// m7 · 现网 22 项固化的回归钉（《全部修复汇总-20261109.md》对照落码）
//
// 背景：2026-11-09 把 fnOS 现网 1.3.65-test.20261108.5-local5 + 未固化 3 项整体合入
// （commit aa122ea），并转正 FLAG_MODULAR_CORE 默认开（0882ed8）。现网证据在报告与
// 真机日志；本文件是仓库侧的**行为钉**：每条对应报告一项，用 fake DSH + mock OneBot
// 直接打新核心工厂，缺了哪根接线测试就红。
// 引用历史补图、完整模块链路与真实出站由 e2e/modules 默认新核心套件共同覆盖；
// 当前状态见 docs/refactor/new-core-parity-ledger.md。

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { createModularCore } from '../src/host/modular-core.js'
import { checkIdentityLeak } from '../src/chat/identity-guard.js'
import { createFakeDsh } from './helpers/fake-dsh.js'
import { startMockOneBot } from './helpers/mock-onebot.js'
import { createOneBotClient } from '../src/onebot/client.js'

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const noopLog = { info() {}, warn() {}, debug() {}, error() {}, child: () => noopLog }
const OWNER = '10000001'
const BOT = '20000002'

/** 与 m4 同型夹具；coreOver 直插 createModularCore 的新增装配项（现网热修的那些）。 */
async function fixture({ brain = async () => '好呀', cfgOver = {}, coreOver = {}, modsOver = {} } = {}) {
  const mock = await startMockOneBot({ selfId: BOT })
  const dsh = createFakeDsh({ brain })
  const workspaceDir = mkdtempSync(join(tmpdir(), 'm7-ws-'))
  const cfg = {
    enabled: true, dryRun: false, botQQ: BOT, ownerQQ: OWNER, ownerName: '主人',
    allow: { private: [OWNER, '30003'], groups: ['777'] },
    longTasks: false,
    merge: { waitSec: 0.05, maxSec: 0.2, groupWaitSec: 0.05, groupMaxMs: 0.2, groupMaxSec: 0.2 },
    snowluma: { autoStart: false, autoAttach: false },
    workspaceDir, ...cfgOver,
  }
  const onebot = createOneBotClient({
    endpoint: () => ({ httpUrl: mock.httpUrl, wsUrl: '', httpToken: mock.token, wsToken: '' }),
    log: noopLog, retryDelays: [10, 10, 10],
  })
  const core = createModularCore({
    dsh: dsh.ctx, onebot,
    mods: { contextFor: async () => '', commands: () => [], use: () => null, ...modsOver },
    getConfig: () => cfg, logger: noopLog, log: noopLog,
    ...coreOver,
  })
  return { core, dsh, mock, cfg, onebot, workspaceDir }
}

const privEv = (over = {}) => ({
  post_type: 'message', message_type: 'private', sub_type: 'friend',
  self_id: Number(BOT), user_id: Number(OWNER), message_id: Math.floor(Math.random() * 1e9),
  time: Math.floor(Date.now() / 1000), sender: { user_id: Number(OWNER), nickname: '主人' },
  message: [{ type: 'text', data: { text: '在吗' } }], ...over,
})
const groupEv = (text = '在吗') => ({
  post_type: 'message', message_type: 'group', sub_type: 'normal',
  self_id: Number(BOT), group_id: 777, user_id: 555, message_id: Math.floor(Math.random() * 1e9),
  time: Math.floor(Date.now() / 1000), sender: { user_id: 555, nickname: '甲' },
  message: [{ type: 'at', data: { qq: Number(BOT) } }, { type: 'text', data: { text: ' ' + text } }],
})

/** 图片 URL 秒回 PNG 字节（同 m4 真机缺陷 10 的桩）；不桩的话新核的 15s 下载超时会拖死等待窗口。 */
function stubPngFetch(urls = ['x/y.png']) {
  const orig = globalThis.fetch
  globalThis.fetch = async (url, opt) => urls.some((part) => String(url).includes(part))
    ? { ok: true, arrayBuffer: async () => new Uint8Array([137, 80, 78, 71]).buffer }
    : orig(url, opt)
  return () => { globalThis.fetch = orig }
}

// —— A6/#6 入站聊天流水：ACL 放行后记一行，出站成功记 bot 行（记忆/蒸馏/黑话/日记的命门）——
test('流水接线：入站 (chatKey,昵称,文本,uid) + 出站成功 bot 行（报告 A 组 #6）', async () => {
  const rows = []
  const { core, mock } = await fixture({ brain: async () => '回你啦', coreOver: { logChat: (...a) => rows.push(a) } })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(600)
    assert.ok(rows.some((r) => r[0] === `private:${OWNER}` && r[1] === '主人' && r[2] === '在吗'), `入站行缺失：${JSON.stringify(rows)}`)
    const bot = rows.find((r) => r[1] === 'bot')
    assert.ok(bot && /回你啦/.test(bot[2]), 'bot 出站行缺失')
  } finally { await core.dispose(); await mock.close() }
})

// —— #17 当前参与者服务：说话人列表与主人权限来自同一状态 ——
test('说话人登记：当前 participants 服务记录 sessionId 对应的发送者（报告 C 组 #17）', async () => {
  const { core, mock } = await fixture()
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(600)
    const sid = Object.values(core.registry.snapshot())[0]?.sessionId
    assert.ok(sid, '未建立会话')
    assert.deepEqual(core.services.speakersOf(sid), [OWNER])
    assert.equal(core.services.turnHasOwner(sid), true)
  } finally { await core.dispose(); await mock.close() }
})

// —— #18 偷表情：入站表情/图片交给 stickers.collect 入口（ask 模式由 host 侧拦截，核心只转发）——
test('偷表情接线：collectInboundStickers 收到 (chatKey, segments, userId)（报告 C 组 #18）', async () => {
  const got = []
  const { core, mock } = await fixture({
    coreOver: { collectInboundStickers: (chatKey, segments, userId) => got.push([chatKey, segments.map((s) => s.type), userId]) },
  })
  const restore = stubPngFetch()
  try {
    await core.dispatchLegacyEvent(privEv({ message: [{ type: 'image', data: { url: 'https://x/y.png' } }] }))
    await sleep(600)
    assert.ok(got.some(([, types]) => types.includes('image')), `未收集：${JSON.stringify(got)}`)
  } finally { restore(); await core.dispose(); await mock.close() }
})

// —— #8 面板统计 + recentMedia（开旗后曾恒 0 / 丢失）——
test('统计与 recentMedia：入站 received、出站 sent、媒体段登记（报告 B 组 #8）', async () => {
  const stats = []
  const media = []
  const { core, mock } = await fixture({
    brain: async () => '嗯',
    coreOver: {
      onStats: (k) => stats.push(k),
      noteMedia: (chatKey, segments, userId) => media.push([String(chatKey), segments.map((s) => s.type), String(userId)]),
    },
  })
  const restore = stubPngFetch()
  try {
    await core.dispatchLegacyEvent(privEv({ message: [{ type: 'text', data: { text: '看这张图' } }, { type: 'image', data: { url: 'https://x/y.png' } }] }))
    await sleep(700)
    assert.ok(stats.includes('received'), 'received 计数缺失')
    assert.ok(stats.includes('sent'), 'sent 计数缺失')
    assert.ok(media.some(([ck, types, uid]) => ck === `private:${OWNER}` && types.includes('image') && uid === OWNER), `recentMedia 缺失：${JSON.stringify(media)}`)
  } finally { restore(); await core.dispose(); await mock.close() }
})

// —— A1/#1 模块工具挂载：会话级一次挂载、清单变化整套重挂、系统聊天不挂 ——
test('工具挂载：buildTools 按会话注册进 agent；名字清单变化整套重挂（报告 A 组 #1，26→66 的那条）', async () => {
  let generation = 0
  const buildTools = () => generation === 0
    ? [{ name: 'fake_ping', description: 'd', execute: async () => ({ ok: true }) }]
    : [{ name: 'fake_pong', description: 'd', execute: async () => ({ ok: true }) }]
  const { core, dsh, mock } = await fixture({ brain: async ({ toolNames }) => String(toolNames.includes('fake_pong') ? '有pong' : '有ping'), coreOver: { buildTools } })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(500)
    const sid = Object.values(core.registry.snapshot())[0]?.sessionId
    const agent = dsh.agents.get(sid)
    assert.ok(agent.tools.has('fake_ping'), '首轮未挂 fake_ping')
    generation = 1
    await core.dispatchLegacyEvent(privEv({ message_id: 987654, message: [{ type: 'text', data: { text: '再来' } }] }))
    await sleep(500)
    assert.ok(agent.tools.has('fake_pong') && !agent.tools.has('fake_ping'), '清单变化未整套重挂')
  } finally { await core.dispose(); await mock.close() }
})

// —— #7/3.1 上下文跟轮：holder 键必须是 sessionId（旧代码用 agent 对象键 → 永远冻结在第 1 轮）——
test('上下文跟轮：第 2 轮的 systemPrompt.context 内容是第 2 轮的（报告 3.1，WeakMap→sessionId 键）', async () => {
  let ver = 0
  const { core, dsh, mock } = await fixture({
    brain: async ({ ctxText }) => `看到[${ctxText}]`,
    modsOver: { contextFor: async () => `记忆第${++ver}版` },
  })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(500)
    await core.dispatchLegacyEvent(privEv({ message_id: 13579, message: [{ type: 'text', data: { text: '还有呢' } }] }))
    await sleep(500)
    assert.equal(dsh.turns.length, 2)
    const ctx1 = dsh.turns[0].ctxText
    const ctx2 = dsh.turns[1].ctxText
    assert.match(ctx1, /记忆第1版/, `第1轮上下文异常：${ctx1}`)
    assert.match(ctx2, /记忆第2版(?!.*记忆第1版)/, `上下文冻结或未更新：${ctx2}`)
  } finally { await core.dispose(); await mock.close() }
})

// —— #4/3.2 提示词变量兜底 + 同名 context 被占时「每会话只投一次」的落档路径 ——
test('落档只投一次：sp.context 被宿主占用（热重载残留）→ 第 1 轮拼进消息、第 2 轮不重复（报告 A #4、C #16）', async () => {
  let ver = 0
  const { core, dsh, mock } = await fixture({
    brain: async ({ text }) => `回:${text.slice(0, 8)}`,
    modsOver: { contextFor: async () => `背景板${++ver}` },
  })
  try {
    // 模拟热重载后宿主已占用 qq-hub-context：注册一律抛「已存在」
    const ctrl = dsh.ctx.get('sessionController')
    const orig = ctrl.resolveAgent.bind(ctrl)
    ctrl.resolveAgent = async (sid) => {
      const r = await orig(sid)
      if (r?.agent?.ctx?.systemPrompt) {
        r.agent.ctx.systemPrompt.context = () => { throw new Error('context qq-hub-context 已存在') }
      }
      return r
    }
    await core.dispatchLegacyEvent(privEv())
    await sleep(500)
    await core.dispatchLegacyEvent(privEv({ message_id: 24681, message: [{ type: 'text', data: { text: '第二段' } }] }))
    await sleep(500)
    assert.equal(dsh.turns.length, 2)
    assert.match(dsh.turns[0].userText, /【本聊天背景/, `落档路径未生效：${dsh.turns[0].userText}`)
    assert.doesNotMatch(dsh.turns[1].userText, /【本聊天背景/, '落档内容每轮重复注入（22 轮老毛病复发）')
  } finally { await core.dispose(); await mock.close() }
})

// —— #4(3.2) promptVars：按会话补注册宿主缺失的提示词变量（unknown → 整轮 error 的那条）——
test('promptVars 兜底：sp.variable 按会话补注册 rules 变量（报告 3.2）', async () => {
  const registered = []
  const { core, dsh, mock } = await fixture({
    brain: async () => '好',
    coreOver: { promptVars: { qq_hub_rules_private: () => '私规', qq_hub_rules_social: () => '群规' } },
  })
  try {
    const ctrl = dsh.ctx.get('sessionController')
    const orig = ctrl.resolveAgent.bind(ctrl)
    ctrl.resolveAgent = async (sid) => {
      const r = await orig(sid)
      if (r?.agent?.ctx?.systemPrompt && !r.__spPatched) {
        const sp = r.agent.ctx.systemPrompt
        const v = sp.variable.bind(sp)
        sp.variable = (n, fn) => { registered.push(n); return v(n, fn) }
        r.__spPatched = true
      }
      return r
    }
    await core.dispatchLegacyEvent(privEv())
    await sleep(500)
    assert.ok(registered.includes('qq_hub_rules_private') && registered.includes('qq_hub_rules_social'), `未补注册：${registered}`)
  } finally { await core.dispose(); await mock.close() }
})

// —— #5 语音水合：冻结成员对象 + 网关 fetch_ptt_text → 新对象换段，绝不原地赋值 ——
test('语音水合：record 段经网关转写拼进回合（冻结对象不炸）（报告 A #5 + 1.4）', async () => {
  const { core, dsh, mock } = await fixture({ brain: async ({ text }) => `听到[${text}]` })
  try {
    await core.dispatchLegacyEvent(privEv({ message: [{ type: 'record', data: { file: 'r.slk' } }] }))
    await sleep(800)
    assert.equal(dsh.turns.length, 1, '语音回合未跑起来')
    assert.match(dsh.turns[0].userText, /\[语音\] 今天想吃白米饭/, `未拼出转写文本：${dsh.turns[0].userText}`)
  } finally { await core.dispose(); await mock.close() }
})

// —— #11/#12 富媒体 & 小黄脸经当前 reply-delivery ——
test('富媒体出站：reply-delivery 转换 <sticker:> 与 <face:> 并经 Shared Outbox 发送', async () => {
  const { core, mock } = await fixture({
    brain: async ({ text }) => text.includes('表情') ? '<face:呲牙> 就这个' : '看这个<sticker:测试>',
    cfgOver: { stickers: { enabled: true, faces: true } },
    coreOver: {
      stickers: {
        match: () => ({ md5: 'sticker-md5', name: '测试', file: 'sticker.png' }),
        segmentFor: () => ({ type: 'image', data: { file: 'base64://c3RpY2tlcg==' } }),
        markUsed: () => {},
      },
      legacyDeliver: async () => { throw new Error('不得回退 legacyDeliver') },
    },
  })
  try {
    await core.dispatchLegacyEvent(privEv({ message: [{ type: 'text', data: { text: '发个表情' } }] }))
    await sleep(1000)
    await core.dispatchLegacyEvent(privEv({ message_id: 333444, message: [{ type: 'text', data: { text: '发个贴纸' } }] }))
    await sleep(1000)
    const sends = mock.sent('send_private_msg')
    const rawSends = JSON.stringify(sends)
    assert.match(rawSends, /"type":"face"/, '系统表情未转成 face 段')
    assert.match(rawSends, /"type":"image"/, '贴纸未转成 image 段')
    assert.doesNotMatch(rawSends, /face:|sticker:/, '原始标记漏发给 QQ')
  } finally { await core.dispose(); await mock.close() }
})

test('群聊戳一戳：新核心记住戳人者并经 Shared Outbox 戳回去', async () => {
  const { core, mock } = await fixture({ brain: async () => '<poke>' })
  try {
    await core.dispatchLegacyEvent({
      post_type: 'notice', notice_type: 'notify', sub_type: 'poke',
      self_id: Number(BOT), group_id: 777, user_id: 555, sender_id: 555, target_id: Number(BOT),
    })
    await sleep(1000)
    assert.deepEqual(mock.sent('send_poke').map((call) => call.params), [{ user_id: 555, group_id: 777 }])
  } finally { await core.dispose(); await mock.close() }
})

// —— #14/#15 预算守门员：新核心优先的 resetChat / chatKeyOfSession 反查 ——
test('resetChat 走新核心：归档 + 忘映射，反查 chatKey；unknown 会话返回 false（报告 B #14/#15）', async () => {
  const { core, dsh, mock } = await fixture({ brain: async () => '嗯' })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(500)
    const entry = core.registry.snapshot()[`private:${OWNER}`]
    assert.ok(entry?.sessionId, '首轮未建会话映射')
    assert.equal(core.chatKeyOfSession(entry.sessionId), `private:${OWNER}`, 'chatKeyOfSession 反查失败')
    assert.equal(core.resetChat(`private:${OWNER}`), true, 'resetChat 应成功')
    assert.equal(core.registry.snapshot()[`private:${OWNER}`], undefined, '映射未忘')
    assert.equal(core.resetChat(`private:${OWNER}`), false, '已忘的会话应返回 false')
    // 下一条消息开新会话（token-guardian 压缩生效的前提）
    await core.dispatchLegacyEvent(privEv({ message_id: 556677, message: [{ type: 'text', data: { text: '新的一轮' } }] }))
    await sleep(500)
    const fresh = core.registry.snapshot()[`private:${OWNER}`]
    assert.ok(fresh?.sessionId && fresh.sessionId !== entry.sessionId, '重置后未开新会话')
  } finally { await core.dispose(); await mock.close() }
})

// —— #10 身份闸私聊放宽：allowBareNumbers 只放裸号码，known-id 照拦 ——
test('身份闸：私聊 allowBareNumbers 放行端口/ID 长数字，known-id 与群聊仍拦（报告 B #10）', () => {
  const report = '部署说明：网关端口 13080，任务单 88930771，详见端口 11029 与批次 44200117。'
  const ig = checkIdentityLeak(report, { surface: '私聊消息', ids: ['10000001', '20000002'], allowIds: ['10000001'], allowBareNumbers: true, mode: 'block' })
  assert.equal(ig.ok, true, `私聊报告仍被吞：${ig.message}`)
  const inGroup = checkIdentityLeak(report, { surface: '群消息', ids: ['10000001', '20000002'], allowIds: ['777'], allowBareNumbers: false, mode: 'block' })
  assert.equal(inGroup.ok, false, '群聊裸号码必须仍拦')
  const leakKnown = checkIdentityLeak('他的号是 10001 楼主的 30003', { surface: '私聊消息', ids: ['30003'], allowIds: ['10000001'], allowBareNumbers: true, mode: 'block' })
  assert.equal(leakKnown.ok, false, 'known-id 形态不得被放宽吞掉')
})

// —— 转正补齐：回合开始亮「正在输入」（legacy 有、现网新核心此前没有）——
test('typing 平账：私聊回合亮 set_input_status(1)，群聊不亮（e2e #194 牵出的平账项）', async () => {
  const { core, mock } = await fixture({ brain: async () => '稍等就好' })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(600)
    const pings = mock.calls.filter((c) => c.action === 'set_input_status')
    assert.ok(pings.some((c) => c.params.user_id === Number(OWNER) && c.params.event_type === 1), '私聊未亮 typing')
    await core.dispatchLegacyEvent(groupEv('看看这个'))
    await sleep(600)
    const groupPings = mock.calls.filter((c) => c.action === 'set_input_status' && String(c.params.user_id) === '555')
    assert.equal(groupPings.length, 0, '群聊不该亮 typing')
  } finally { await core.dispose(); await mock.close() }
})

test('引用入站：get_msg 还原被引用正文和发送者，拼入当前 DSH 回合', async () => {
  const { core, dsh, mock } = await fixture({ brain: async ({ text }) => `读到[${text}]` })
  try {
    mock.state.messages = {}
    mock.state.messages['424242'] = {
      message_id: 424242,
      sender: { user_id: 30003, nickname: '引用者' },
      message: [{ type: 'text', data: { text: '需要保留的被引用原文' } }],
    }
    await core.dispatchLegacyEvent(privEv({
      message: [{ type: 'reply', data: { id: '424242' } }, { type: 'text', data: { text: '这个呢' } }],
    }))
    await sleep(700)
    assert.equal(dsh.turns.length, 1)
    assert.match(dsh.turns[0].userText, /需要保留的被引用原文/)
    assert.match(dsh.turns[0].userText, /引用者/)
    assert.match(dsh.turns[0].userText, /这个呢/)
  } finally { await core.dispose(); await mock.close() }
})

test('<reply:n> 与 <at:> 经 reply-delivery 处理，不再回退 legacyDeliver', async () => {
  const first = await fixture({
    brain: async () => '<reply:1>引用这条回复',
    coreOver: { legacyDeliver: async () => { throw new Error('不得回退 legacyDeliver') } },
  })
  try {
    await first.core.dispatchLegacyEvent(privEv({ message: [{ type: 'text', data: { text: '测试引用' } }] }))
    await sleep(1000)
    const rawSends = JSON.stringify(first.mock.sent('send_private_msg'))
    assert.match(rawSends, /引用这条回复/, '回复正文缺失')
    assert.doesNotMatch(rawSends, /<reply:1>/, 'reply 原始标记漏发给 QQ')
  } finally { await first.core.dispose(); await first.mock.close() }

  const second = await fixture({
    brain: async () => '<at:30003> 提醒一下',
    coreOver: { legacyDeliver: async () => { throw new Error('不得回退 legacyDeliver') } },
  })
  try {
    await second.core.dispatchLegacyEvent(groupEv('测试提醒'))
    await sleep(1000)
    const rawSends = JSON.stringify(second.mock.sent('send_group_msg'))
    assert.match(rawSends, /提醒一下/, '@ 正文缺失')
    assert.doesNotMatch(rawSends, /<at:30003>/, 'at 原始标记漏发给 QQ')
  } finally { await second.core.dispose(); await second.mock.close() }
})

test('群聊引用机器人消息：没有 @ 也按 repliedToBot 触发，并带被引用正文', async () => {
  const { core, dsh, mock } = await fixture({ brain: async ({ text }) => `群引用[${text}]` })
  try {
    mock.state.messages = {
      515151: {
        message_id: 515151,
        sender: { user_id: Number(BOT), nickname: '机器人' },
        message: [{ type: 'text', data: { text: '机器人之前发出的正文' } }],
      },
    }
    const ev = groupEv('接着这句说')
    ev.message = [{ type: 'reply', data: { id: '515151' } }, { type: 'text', data: { text: '接着这句说' } }]
    await core.dispatchLegacyEvent(ev)
    await sleep(700)
    assert.equal(dsh.turns.length, 1, '引用机器人消息没有触发群回合')
    assert.match(dsh.turns[0].userText, /机器人之前发出的正文/)
  } finally { await core.dispose(); await mock.close() }
})

test('提问工具生命周期：核心 dispose 会卸载本会话工具，热重载后可在共享 agent 重挂', async () => {
  const { core, dsh, mock } = await fixture({
    coreOver: {
      buildTools: () => [{ name: 'ask_user_question', description: 'd', execute: async () => ({ ok: true }) }],
    },
  })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(600)
    const sid = Object.values(core.registry.snapshot())[0]?.sessionId
    const agent = dsh.agents.get(sid)
    assert.ok(agent.tools.has('ask_user_question'), '首轮未挂提问工具')
    await core.dispose()
    assert.equal(agent.tools.has('ask_user_question'), false, 'dispose 后旧工具仍残留，下一次挂载会重复注册')
  } finally { await mock.close() }
})

test('合并转发：get_forward_msg 的消息正文和发送者进入当前回合', async () => {
  const { core, dsh, mock } = await fixture({ brain: async ({ text }) => `转发[${text}]` })
  try {
    mock.state.forwards = {
      'forward-1': [
        { sender: { user_id: 30003, nickname: '甲' }, message: [{ type: 'text', data: { text: '转发里的第一句' } }] },
        { sender: { user_id: 30004, nickname: '乙' }, message: [{ type: 'text', data: { text: '转发里的第二句' } }] },
      ],
    }
    await core.dispatchLegacyEvent(privEv({ message: [{ type: 'forward', data: { id: 'forward-1' } }] }))
    await sleep(700)
    assert.equal(dsh.turns.length, 1)
    assert.match(dsh.turns[0].userText, /转发里的第一句/)
    assert.match(dsh.turns[0].userText, /转发里的第二句/)
    assert.match(dsh.turns[0].userText, /甲/)
  } finally { await core.dispose(); await mock.close() }
})

test('慢工具：执行超过阈值先经 outbox 发提示，完成后清掉计时器', async () => {
  const { core, dsh, mock } = await fixture({
    brain: async ({ callTool }) => (await callTool('slow_work', {}))?.message || '没有结果',
    coreOver: {
      buildTools: () => [{
        name: 'slow_work', description: 'd', slow: '正在处理，请稍等',
        execute: async () => { await sleep(1600); return { ok: true, message: '完成了' } },
      }],
    },
  })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(2000)
    let texts = mock.sent('send_private_msg').map((x) => JSON.stringify(x.params?.message || x.params))
    assert.ok(texts.some((x) => x.includes('正在处理')), `慢工具提示未发：${JSON.stringify(texts)}`)
    assert.ok(texts.some((x) => x.includes('完成了')), `最终结果未发：${JSON.stringify(texts)}`)
    await core.dispatchLegacyEvent(privEv())
    await sleep(2000)
    texts = mock.sent('send_private_msg').map((x) => JSON.stringify(x.params?.message || x.params))
    assert.equal(texts.filter((x) => x.includes('正在处理')).length, 2, `每一轮慢工具都应有提示：${JSON.stringify(texts)}`)
  } finally { await core.dispose(); await mock.close() }
})

test('模块钩子：message/prompt/reply/items/send 与群策略/模型都进入新核心实际链路', async () => {
  const calls = []
  const moduleHooks = {
    message: async () => { calls.push('message'); return false },
    prompt: async (content) => { calls.push('prompt'); return content },
    reply: async (text) => { calls.push('reply'); return `${text}·改写` },
    items: async (items) => { calls.push('items'); return items },
    send: async (segments) => { calls.push('send'); return segments },
    groupDecide: async (decision) => { calls.push('groupDecide'); return decision },
    model: (selection) => { calls.push('model'); return selection },
  }
  const { core, dsh, mock } = await fixture({
    brain: async () => '原回复',
    coreOver: { moduleHooks },
  })
  try {
    await core.dispatchLegacyEvent(groupEv('调用钩子'))
    await sleep(700)
    for (const name of ['message', 'prompt', 'reply', 'items', 'send', 'groupDecide', 'model']) {
      assert.ok(calls.includes(name), `${name} 未接入：${JSON.stringify(calls)}`)
    }
    const sent = JSON.stringify(mock.sent('send_group_msg').map((x) => x.params))
    assert.match(sent, /原回复·改写/)
  } finally { await core.dispose(); await mock.close() }
})

test('模块 message 接管：返回 true 时不建会话、不调用 DSH', async () => {
  const { core, dsh, mock } = await fixture({ coreOver: { moduleHooks: { message: async () => true } } })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(300)
    assert.equal(dsh.turns.length, 0)
    assert.equal(Object.keys(core.registry.snapshot()).length, 0)
  } finally { await core.dispose(); await mock.close() }
})

test('主动任务回合：复用当前 QQ 会话且只生成不自动投递', async () => {
  const { core, dsh, mock } = await fixture({ brain: async ({ text }) => text.includes('主动生成') ? '主动文本' : '普通回复' })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(600)
    const entry = core.registry.snapshot()[`private:${OWNER}`]
    const sentBefore = mock.sent('send_private_msg').length
    const raw = await core.runPromptTurn(`private:${OWNER}`, '主动生成一段文字')
    assert.equal(raw, '主动文本')
    assert.equal(dsh.turns.length, 2)
    assert.equal(dsh.turns[1].sessionId, entry.sessionId, '主动任务不得创建另一套会话')
    assert.equal(mock.sent('send_private_msg').length, sentBefore, '只生成接口不得自动投递')
  } finally { await core.dispose(); await mock.close() }
})

test('主动任务与当前聊天共用串行道：前一轮未结束时不得并发驱动同一 DSH 会话', async () => {
  const started = []
  let release
  const blocker = new Promise((resolve) => { release = resolve })
  const { core, dsh, mock } = await fixture({
    brain: async ({ text }) => {
      if (text.includes('阻塞聊天')) { started.push('chat'); await blocker; return '聊天完成' }
      started.push('background')
      return '后台文本'
    },
  })
  try {
    await core.dispatchLegacyEvent(privEv({ message: [{ type: 'text', data: { text: '阻塞聊天' } }] }))
    await sleep(150)
    const pending = core.runPromptTurn(`private:${OWNER}`, '后台主动任务')
    await sleep(100)
    assert.deepEqual(started, ['chat'], '前台回合未结束时后台回合不能开始')
    release()
    assert.equal(await pending, '后台文本')
    assert.deepEqual(started, ['chat', 'background'])
    assert.equal(new Set(dsh.turns.map((turn) => turn.sessionId)).size, 1)
  } finally { await core.dispose(); await mock.close() }
})


test('补收入站：提示模型这些是断线期间的旧消息，并保留原始时间语义', async () => {
  const { core, dsh, mock } = await fixture()
  try {
    await core.dispatchBackfill(privEv({ time: Math.floor((Date.now() - 120_000) / 1000) }), { gapMs: 6 * 3600_000 })
    await sleep(600)
    const text = String(dsh.turns[0]?.userText || '')
    assert.match(text, /补收提示/)
    assert.match(text, /断线期间错过/)
    assert.match(text, /断开连接约 6 小时/)
    assert.match(text, /最早一条在约 2 分钟前/)
  } finally { await core.dispose(); await mock.close() }
})

test('activity：私聊/必回群消息的 direct 与主人 owner 权重和 legacy 一致', async () => {
  const events = []
  const { core, mock } = await fixture({
    modsOver: { emit: (name, event) => { if (name === 'activity') events.push(event) } },
  })
  try {
    await core.dispatchLegacyEvent(privEv())
    const ownerAt = {
      ...groupEv('主人点名'), user_id: Number(OWNER),
      sender: { user_id: Number(OWNER), nickname: '主人' },
    }
    await core.dispatchLegacyEvent(ownerAt)
    await core.dispatchLegacyEvent(groupEv('肥鱼 在吗'))
    await core.dispatchLegacyEvent({
      ...groupEv('普通旁听'), message: [{ type: 'text', data: { text: '普通旁听' } }],
    })
    const ownerPrivate = events.find((event) => event.chatId === `private:${OWNER}`)
    assert.equal(ownerPrivate?.direct, true)
    assert.equal(ownerPrivate?.owner, true)
    const directOwner = events.find((event) => event.chatId === 'group:777' && event.text.includes('主人点名'))
    assert.equal(directOwner?.direct, true, '@主人的群消息也是 direct')
    assert.equal(directOwner?.owner, true, '主人发言必须有 owner=true')
    const wake = events.find((event) => event.text.includes('肥鱼 在吗'))
    assert.equal(wake?.direct, true, '唤醒词形成的 must 轮也是 direct')
    assert.equal(wake?.owner, false)
    const passive = events.find((event) => event.text.includes('普通旁听'))
    assert.equal(passive?.direct, false)
    assert.equal(passive?.owner, false)
  } finally { await core.dispose(); await mock.close() }
})


test('入站文件：文本正文与二进制真实路径都进入新核心回合', async () => {
  const logs = []
  const log = { info: (...args) => logs.push(args.join(' ')), warn: (...args) => logs.push(args.join(' ')), debug: (...args) => logs.push(args.join(' ')), error: (...args) => logs.push(args.join(' ')), child: () => log }
  const { core, dsh, mock } = await fixture({ coreOver: { log, logger: log } })
  try {
    const textBody = '这是文本文件的实际正文：白米饭。'
    const event = privEv({
      message: [
        { type: 'file', data: { file_name: '说明.txt', base64: `base64://${Buffer.from(textBody).toString('base64')}` } },
        { type: 'file', data: { file_name: '资料.bin', base64: `base64://${Buffer.from([0, 1, 2, 3, 4]).toString('base64')}` } },
      ],
    })
    await core.dispatchLegacyEvent(event)
    await sleep(700)
    const text = String(dsh.turns[0]?.userText || '')
    assert.match(text, /说明\.txt/, `日志：${logs.join('\n')}`)
    assert.match(text, /白米饭/)
    assert.match(text, /【文件结束】/)
    assert.match(text, /资料\.bin/)
    const path = text.match(/已经存在 ([^，\n]+)，要看得用工具读/)?.[1]
    assert.ok(path && path.includes('qq-inbox'), `二进制应落盘并给出路径：${text}`)
    assert.equal(existsSync(path), true, '路径对应的真实文件必须存在')
  } finally { await core.dispose(); await mock.close() }
})


test('群文件：正文只进当前回合，后续群缓冲只保留文件摘要', async () => {
  const body = '不应重复注入的正文'.repeat(100)
  const { core, dsh, mock } = await fixture()
  try {
    await core.dispatchLegacyEvent(groupEv(''))
    await sleep(500)
    await core.dispatchLegacyEvent({
      ...groupEv(''), message_id: 818181,
      message: [{ type: 'at', data: { qq: Number(BOT) } }, { type: 'file', data: { file_name: '长文.txt', base64: `base64://${Buffer.from(body).toString('base64')}` } }],
    })
    await sleep(700)
    const fileTurn = dsh.turns.find((turn) => String(turn.userText).includes('长文.txt'))
    assert.match(String(fileTurn?.userText), /不应重复注入的正文/)
    await core.dispatchLegacyEvent(groupEv('下一句话'))
    await sleep(700)
    const next = dsh.turns.at(-1)
    assert.match(String(next?.userText), /\[文件 长文\.txt\]/)
    assert.doesNotMatch(String(next?.userText), /不应重复注入的正文/)
  } finally { await core.dispose(); await mock.close() }
})

test('文件/语音/视频有文本视图：流水和 activity 不再收到空文本', async () => {
  const chats = []
  const activities = []
  const { core, mock } = await fixture({
    coreOver: { logChat: (...args) => chats.push(args) },
    modsOver: { emit: (name, event) => { if (name === 'activity') activities.push(event) } },
  })
  try {
    await core.dispatchLegacyEvent(privEv({ message: [
      { type: 'file', data: { file_name: '说明.txt', base64: `base64://${Buffer.from('正文').toString('base64')}` } },
      { type: 'record', data: { file: 'voice.amr' } },
      { type: 'video', data: { file: 'video.mp4' } },
    ] }))
    await sleep(700)
    assert.match(String(chats[0]?.[2]), /\[文件 说明\.txt\]/)
    assert.match(String(chats[0]?.[2]), /\[语音\]/)
    assert.match(String(chats[0]?.[2]), /\[视频\]/)
    assert.match(String(activities[0]?.text), /\[文件 说明\.txt\]/)
  } finally { await core.dispose(); await mock.close() }
})


test('回合超时配置：面板可设分钟，配置归一化限制在 1～120 分钟', async () => {
  const { readFileSync } = await import('node:fs')
  const { normalize } = await import('../src/core/config.js')
  const source = readFileSync(new URL('../client/client.js', import.meta.url), 'utf8')
  assert.match(source, /turnTimeoutMs/)
  assert.match(source, /回合.*超时|回合等待/)
  assert.equal(normalize({ turnTimeoutMs: 1 }).turnTimeoutMs, 60_000)
  assert.equal(normalize({ turnTimeoutMs: 99999999 }).turnTimeoutMs, 7_200_000)
})

test('回合超时：提示用户且不立即归档；下一条消息重建，迟到回复不投递', async () => {
  let release
  const blocker = new Promise((resolve) => { release = resolve })
  const { core, dsh, mock } = await fixture({
    cfgOver: { turnTimeoutMs: 50 },
    brain: async ({ text }) => {
      if (text.includes('卡住')) { await blocker; return '迟到的旧回复' }
      return '已恢复'
    },
  })
  try {
    await core.dispatchLegacyEvent(privEv({ message: [{ type: 'text', data: { text: '卡住' } }] }))
    await sleep(250)
    const key = `private:${OWNER}`
    const timedOut = core.registry.peek(key)
    assert.ok(timedOut?.sessionId, '超时时不能立即归档并忘记会话')
    assert.equal(core.controller.runningTurnOf(key), null, '超时后旧回合必须释放调度槽')
    assert.ok(mock.sent('send_private_msg').some((call) => JSON.stringify(call.params.message).includes('超过')), '用户应收到明确的超时提示')
    await core.dispatchLegacyEvent(privEv())
    await sleep(600)
    assert.notEqual(core.registry.peek(key)?.sessionId, timedOut.sessionId, '下一条消息到来时才重建旧会话')
    assert.ok(mock.sent('send_private_msg').some((call) => JSON.stringify(call.params.message).includes('已恢复')), '后续消息必须仍能完成')
    assert.ok(!mock.sent('send_private_msg').some((call) => JSON.stringify(call.params.message).includes('迟到的旧回复')))
  } finally {
    release?.()
    await core.dispose()
    await mock.close()
  }
})

test('默认 modular 入站限流：同一用户刷屏被挡在回合外', async () => {
  const oldCapacity = process.env.QQHUB_RL_CAPACITY
  const oldRefill = process.env.QQHUB_RL_REFILL_PER_SEC
  process.env.QQHUB_RL_CAPACITY = '2'
  process.env.QQHUB_RL_REFILL_PER_SEC = '0'
  const { core, mock } = await fixture()
  try {
    const first = await core.dispatchLegacyEvent(groupEv('第一句'))
    const second = await core.dispatchLegacyEvent(groupEv('第二句'))
    const third = await core.dispatchLegacyEvent(groupEv('第三句'))
    assert.notEqual(first.handled, 'ratelimited')
    assert.notEqual(second.handled, 'ratelimited')
    assert.equal(third.handled, 'ratelimited')
  } finally {
    if (oldCapacity === undefined) delete process.env.QQHUB_RL_CAPACITY
    else process.env.QQHUB_RL_CAPACITY = oldCapacity
    if (oldRefill === undefined) delete process.env.QQHUB_RL_REFILL_PER_SEC
    else process.env.QQHUB_RL_REFILL_PER_SEC = oldRefill
    await core.dispose(); await mock.close()
  }
})

test('purpose 备忘格式污染：普通回合发送与 bot 流水都只保留人话', async () => {
  const chats = []
  const { core, mock } = await fixture({
    brain: async () => '这是正常回复\n【目的】邀请主人玩游戏\n【需求】玩\n【状态】完成\n【待续】无',
    coreOver: { logChat: (...args) => chats.push(args) },
  })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(600)
    const sent = mock.sent('send_private_msg').map((call) => JSON.stringify(call.params.message)).join('\n')
    assert.match(sent, /这是正常回复/)
    assert.doesNotMatch(sent, /【目的】|【需求】|【状态】|【待续】/)
    const bot = chats.find((row) => row[1] === 'bot')
    assert.equal(bot?.[2], '这是正常回复')
  } finally { await core.dispose(); await mock.close() }
})

test('JSON/XML 卡片：新核心保留分享标题和链接，不只给模型类型占位', async () => {
  const { core, dsh, mock } = await fixture()
  try {
    const card = JSON.stringify({ meta: { detail_1: { desc: '示例文章摘要', qqdocurl: 'https://example.com/article' } } })
    await core.dispatchLegacyEvent(privEv({
      message: [{ type: 'json', data: { data: card } }, { type: 'xml', data: { data: '<xml />' } }],
    }))
    await sleep(600)
    const text = String(dsh.turns[0]?.userText || '')
    assert.match(text, /示例文章摘要/)
    assert.match(text, /https:\/\/example\.com\/article/)
    assert.match(text, /\[卡片消息\]/)
    assert.doesNotMatch(text, /\[json\]/)
  } finally { await core.dispose(); await mock.close() }
})

test('会话 reset：旧 session 的上下文、人格和工具缓存被回收', async () => {
  const { core, dsh, mock } = await fixture({
    coreOver: { personaTextFor: () => '专用人格', promptVars: { qq_hub_rules_private: () => '规则' } },
  })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(600)
    assert.ok(core.stats().cacheEntries > 0, '首轮应建立会话缓存')
    assert.equal(core.resetChat(`private:${OWNER}`), true)
    assert.equal(core.stats().cacheEntries, 0, 'reset 后旧 session 缓存必须清理')
  } finally { await core.dispose(); await mock.close() }
})

// —— 群聊图片回归：没触发回复的那条表情，必须在下一段触发轮里作为图片块交给模型 ——
// 真机 2026-11-12：群里先发图、再 @ 她问「没看到表情包吗」，新核只把缓冲里的
// 「（图片/表情）」文字交给模型，触发轮 members 又没有图，于是她回复「具体啥样看不到」。
test('群聊补图：群闸放过的图片随下一段上下文登记成附件', async () => {
  const restore = stubPngFetch(['x/sticker.png'])
  const { core, dsh, mock } = await fixture({ brain: async () => '看到表情了' })
  try {
    // 纯图没有 @/唤醒词，群闸不触发回合；图必须留在群缓冲里。
    await core.dispatchLegacyEvent({
      ...groupEv(''), message_id: 818101,
      message: [{ type: 'image', data: { url: 'https://x/sticker.png', sub_type: 1, summary: '[动画表情]' } }],
    })
    await sleep(400)
    assert.equal(dsh.turns.length, 0, '纯图表情不该单独触发群回合')
    await core.dispatchLegacyEvent({
      ...groupEv('没看到表情包吗'), message_id: 818102,
    })
    await sleep(700)
    const turn = dsh.turns.at(-1)
    assert.match(String(turn?.userText), /图片\/表情/, '群缓冲仍应保留媒体占位文字')
    assert.ok(turn?.contentTypes.includes('image'), `图片块没进触发轮：${JSON.stringify(turn?.contentTypes)}`)
    assert.equal(turn?.images, 1, '同一张图不重复投喂')
    assert.doesNotMatch(String(turn?.userText), /没能把它下载下来|没能把它登记成附件/, '图片应下载并登记成功')
  } finally { restore(); await core.dispose(); await mock.close() }
})

test('群聊纯媒体：活跃/engaged 都不自行开回合，直接 @ 仍可带图回', async () => {
  const restore = stubPngFetch(['x/gate.png'])
  const { core, dsh, mock } = await fixture({
    brain: async () => '看到图了',
    cfgOver: { group: { interjectChance: 1, minRecentMessages: 0, minRelevance: 0, quietHours: [], fishGuard: { enabled: false } } },
  })
  const imageOnly = (id) => ({
    ...groupEv(''), message_id: id,
    message: [{ type: 'image', data: { url: 'https://x/gate.png', sub_type: 1 } }],
  })
  try {
    // 活跃群 + 100% 插话：旧逻辑会在这里错误地开回合。
    await core.dispatchLegacyEvent(imageOnly(818201))
    await sleep(400)
    assert.equal(dsh.turns.length, 0, '纯媒体不得靠随机插话自行开回合')

    await core.dispatchLegacyEvent({
      ...groupEv(''), message_id: 818202,
      message: [
        { type: 'at', data: { qq: Number(BOT) } },
        { type: 'image', data: { url: 'https://x/gate.png', sub_type: 1 } },
      ],
    })
    await sleep(700)
    assert.equal(dsh.turns.length, 1, '直接 @ 带图仍应进入回合')
    assert.match(String(dsh.turns[0]?.userText || ''), /不得猜图中的人物/)

    // 刚才已经说过话，engaged 状态也不能让下一条纯媒体自行开新回合。
    await core.dispatchLegacyEvent(imageOnly(818203))
    await sleep(400)
    assert.equal(dsh.turns.length, 1, 'engaged 状态下的纯媒体也不得自行开回合')
  } finally { restore(); await core.dispose(); await mock.close() }
})

test('群聊补图：触发轮自带图片时按地址去重，最多 4 张', async () => {
  const restore = stubPngFetch(['x/a.png', 'x/b.png', 'x/c.png', 'x/d.png', 'x/e.png'])
  const { core, dsh, mock } = await fixture()
  try {
    for (let i = 0; i < 5; i++) {
      await core.dispatchLegacyEvent({
        ...groupEv(''), message_id: 819100 + i,
        message: [{ type: 'image', data: { url: `https://x/${'abcde'[i]}.png`, sub_type: 1 } }],
      })
    }
    await sleep(400)
    // 第 6 条 @ 她，同时重复带上第一张图：members 与群缓冲都有它。
    await core.dispatchLegacyEvent({
      ...groupEv('看看这些'), message_id: 819200,
      message: [
        { type: 'at', data: { qq: Number(BOT) } },
        { type: 'text', data: { text: ' 看看这些' } },
        { type: 'image', data: { url: 'https://x/a.png', sub_type: 1 } },
      ],
    })
    await sleep(700)
    const turn = dsh.turns.at(-1)
    assert.equal(turn?.images, 4, `应去重且封顶 4 张，实际 ${turn?.images}`)
  } finally { restore(); await core.dispose(); await mock.close() }
})

// —— 按聊天人设 vs 全局卡（真机 2026-11-14，session-82cc1d03）：私聊系统提示词已是小鲸鱼专卡，
//    但 qq-hub-context 每轮还带一份全局豆包卡，两卡打架、模型听后注入的那张——按聊天人设名存实亡。
//    行为钉：专卡生效时人设 fragment 必须让位（上下文不再出现全局卡），跟随全局才注入全局卡。
test('按聊天人设：专卡生效时上下文不再注入全局卡；跟随全局的聊天仍注入', async () => {
  const { core, dsh, mock } = await fixture({
    coreOver: {
      personaText: () => '【全局人设卡】你是豆包',
      personaTextFor: (chat) => (chat?.kind === 'private' ? '【专用人设卡】你是小鲸鱼' : null),
    },
    // 垫一行非人设内容：证明上下文管线在跑，专卡缺席不是「整段上下文为空」的假阳性。
    modsOver: { contextFor: async () => '（模块上下文占位行）' },
  })
  try {
    await core.dispatchLegacyEvent(privEv())
    await sleep(600)
    const snapshot = core.registry.snapshot()
    const privSid = snapshot[`private:${OWNER}`]?.sessionId
    assert.ok(privSid, '私聊会话未建立')
    const privCtx = String(dsh.agents.get(String(privSid))?.contexts?.get('qq-hub-context')?.text?.() || '')
    assert.match(privCtx, /模块上下文占位行/, '上下文管线应正常产出')
    assert.doesNotMatch(privCtx, /全局人设卡/, '专卡生效时上下文不应再注入全局卡（两卡打架）')
    assert.doesNotMatch(privCtx, /专用人设卡/, '专卡走系统提示词变量，不该重复进上下文 fragment')

    await core.dispatchLegacyEvent(groupEv('群里冒个泡'))
    await sleep(700)
    const groupSid = Object.entries(core.registry.snapshot()).find(([k]) => k.startsWith('group:'))?.[1]?.sessionId
    const groupCtx = String(dsh.agents.get(String(groupSid))?.contexts?.get('qq-hub-context')?.text?.() || '')
    assert.match(groupCtx, /全局人设卡/, '跟随全局的聊天仍要注入全局卡')
  } finally { await core.dispose(); await mock.close() }
})
