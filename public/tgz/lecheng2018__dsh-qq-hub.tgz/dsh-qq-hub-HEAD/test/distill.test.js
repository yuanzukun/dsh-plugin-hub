// 蒸馏群友（重构模板版）：业界蒸馏结构——对话对(mes_example)> 口头禅+语境 / 句子架构 /
// 修辞(voice template)> never 词表 > 性格锚(可观察行为)；旧画像字段兼容渲染。
import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync } from 'node:fs'
import { readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  collectMemberLines, enoughEvidence, evidenceFunnel, describeFunnel, buildDistillPrompt, dedupConvo,
  parseDistillProfile, normalizeProfile, mergeProfile, renderDistillHint, safeParseJson, recognizedFields,
} from '../src/features/distill.js'

const L = (uid, text, t = 0) => ({ uid, text, t, who: 'u' + uid })

// 2026-11-12 真实事故：同一份充足证据（50 句可用）连续三次被判「空画像」。
// 日志里模型回包的键名是「句子架构」「口头禅」，另一次自创 {"learned_style":{...}}，
// 而解析只认 exchanges/syntax/... → 全落空 → 误报「原话不够代表说话风格」。
// 下面三种形态都按真实日志构造。
test('键名容错：中文键也能认出来（模型不按英文名回包是常态）', () => {
  const zh = parseDistillProfile(JSON.stringify({
    句子架构: ['先@对象，再接判断或动作', '“可能是…”先猜异常原因'],
    口头禅: ['斩了一波（说服务被批量限制时）', '可能是…（判断异常原因时）'],
    性格: ['遇登录问题先猜梯子或网络'],
    他从不: ['不用纯图片代替答复'],
  }))
  assert.deepEqual(zh.syntax, ['先@对象，再接判断或动作', '“可能是…”先猜异常原因'], '句子架构 → syntax')
  assert.equal(zh.catchphrases.length, 2, '口头禅 → catchphrases')
  assert.deepEqual(zh.persona, ['遇登录问题先猜梯子或网络'], '性格 → persona')
  assert.deepEqual(zh.never, ['不用纯图片代替答复'], '他从不 → never')
})

test('键名容错：自创外层命名空间也能拆开（learned_style 形态）', () => {
  const nested = parseDistillProfile(JSON.stringify({
    learned_style: {
      tone: '简短犀利，带嘲讽和挑衅意味',
      typical_phrases: ['活', '就这', '毫无水平', '闹麻了'],
      sentence_structure: ['短句连发'],
    },
  }))
  assert.equal(nested.tone[0], '简短犀利，带嘲讽和挑衅意味', 'tone 取到')
  assert.equal(nested.catchphrases.length, 4, 'typical_phrases → catchphrases')
  assert.deepEqual(nested.syntax, ['短句连发'], 'sentence_structure → syntax')
})

test('键名容错：英文原名优先于别名，不串字段', () => {
  const both = parseDistillProfile(JSON.stringify({
    syntax: ['英文原键'],
    句子架构: ['中文别名'],
    never: ['他不用客套话'],
    avoid: ['旧字段避免项'],
  }))
  assert.deepEqual(both.syntax, ['英文原键'], '同名时英文键优先')
  assert.deepEqual(both.never, ['他不用客套话'], 'never 不被 avoid 抢')
  assert.deepEqual(both.avoid, ['旧字段避免项'], '旧 avoid 仍可读')
})

test('截断容错：回包被截断时仍能抠出内容并报出识别到的字段', () => {
  // 真实日志形态：数组写到一半就断了
  const truncated = '{"句子架构":["先@对象，再接判断或动作","“可能是…”先猜异常原因"],"口头禅":["斩了一波'
  const obj = safeParseJson(truncated)
  assert.ok(obj, '截断也能补括号解析出对象')
  const fields = recognizedFields(obj)
  assert.equal(fields.syntax, 2, '截断后仍认出 syntax')
  // 完整回包时不要误判成截断
  assert.ok(safeParseJson('{"syntax":["短句"]}'), '完整 JSON 正常解析')
  assert.equal(safeParseJson('完全不是 JSON'), null)
})

test('证据清洗：复读转发只算一句，纯分享卡片/链接不算话', () => {
  const lines = [
    L('1', '[分享卡片：576k5YWs5ZGK]', 1),
    L('1', '兄弟们，刚挖到俩羊毛', 2),
    L('1', '[分享卡片：576k5YWs5ZGK]', 3),
    L('1', '兄弟们，刚挖到俩羊毛', 4),
    L('1', 'https://example.com/x', 5),
    L('2', '收到', 6),
  ]
  const out = collectMemberLines(lines, '1')
  assert.deepEqual(out.map((x) => x.text), ['兄弟们，刚挖到俩羊毛'], '同文去重 + 卡片/纯链接过滤')
  assert.equal(out[0].t, 2, '留最早一次的时间')
})

test('从群流水里只捞目标那个人的话，按时间正序', () => {
  const lines = [L('9', '晚点', 3), L('111', '草', 2), L('222', '哈哈哈', 1), L('111', '上号', 4)]
  assert.deepEqual(collectMemberLines(lines, '111').map((x) => x.text), ['草', '上号'])
  assert.deepEqual(collectMemberLines(lines, '999'), [], '没说过话就是空')
  assert.deepEqual(collectMemberLines(lines, ''), [], '没给 uid 不捞')
})

test('证据不足不学：门槛默认 20 句 / 120 字', () => {
  assert.equal(enoughEvidence([L('1', 'a'), L('1', 'b')]), false)
  const twenty = Array.from({ length: 20 }, (_, i) => L('1', '这是一句正常长度的话' + i))
  assert.equal(enoughEvidence(twenty), true, '20 句才够')
  const twentyShort = Array.from({ length: 20 }, () => L('1', '嗯'))
  assert.equal(enoughEvidence(twentyShort), false, '20 句但都是「嗯」，字数不够')
  assert.equal(enoughEvidence(twentyShort.slice(0, 15), { minMessages: 15 }), false)
})

test('证据漏斗：命中→去重→滤转发→可用，每一步丢多少都算清楚', () => {
  const lines = [
    L('1', '[分享卡片：某个公告]', 1),
    L('1', '[图片]', 2),
    L('1', 'https://example.com/x', 3),
    L('1', '就这', 4),
    L('1', '就这', 5),
    L('1', '就这', 6),
    L('1', '闹麻了', 7),
    L('1', '', 8),
    L('2', '别人的话不算', 9),
  ]
  const f = evidenceFunnel(lines, '1')
  assert.equal(f.hit, 8, '只算目标那个人的')
  assert.equal(f.junk, 3, '卡片/图片/纯链接')
  assert.equal(f.junk + f.duplicate + f.empty + f.usable, f.hit, '四项加起来等于命中')
  assert.equal(f.duplicate, 2, '「就这」出现三次，后两次算重复')
  assert.equal(f.usable, 2, '就这 + 闹麻了')
  assert.equal(f.empty, 1)
  const text = describeFunnel(f)
  assert.match(text, /翻到 8 条/)
  assert.match(text, /3 条是纯图片\/转发\/链接/)
  assert.match(text, /可用的 2 句/)
  assert.equal(describeFunnel({ hit: 0 }), '', '一条都没命中就不啰嗦')
  assert.equal(describeFunnel(null), '')
})

test('对话上下文去重：同 (uid,text) 三次以上视为会话重复注入，只留两次', () => {
  const rep = { uid: '1', text: '同一段上下文被连发' }
  const out = dedupConvo([rep, { uid: '2', text: 'b' }, { ...rep }, { ...rep }, { uid: '2', text: 'b' }])
  assert.equal(out.filter((x) => x.uid === '1').length, 2, '允许复读梗两次')
  assert.equal(out.filter((x) => x.uid === '2').length, 2)
})

test('解析模型回包：认 ```json 围栏与外层解释；新字段结构；坏数据返回 null', () => {
  const ok = parseDistillProfile('```json\n{"syntax":["句子极短"],"persona":["脾气急"],"catchphrases":["搞（催办时）"]}\n```')
  assert.deepEqual(ok.syntax, ['句子极短'])
  assert.deepEqual(ok.catchphrases, ['搞（催办时）'])
  const wrapped = parseDistillProfile('好的，结果如下：{"exchanges":["问：「怎么弄」\\n答：「重启」"],"never":[]} 以上。')
  assert.equal(wrapped.exchanges.length, 1)
  assert.equal(parseDistillProfile('我不知道'), null)
  assert.equal(parseDistillProfile(''), null)
})

test('画像归一与合并：新字段集，去空去重、新的在前、超上限截断', () => {
  const a = { syntax: Array.from({ length: 4 }, (_, i) => '旧' + i), persona: ['脾气急'], never: [] }
  const b = { syntax: ['新1', '新2'], persona: ['脾气急', '爱较真'], never: ['不用感谢'] }
  const m = mergeProfile(a, b)
  assert.equal(m.syntax.length, 3, 'syntax 上限 3 条')
  assert.equal(m.syntax[0], '新1', '新的在前')
  assert.deepEqual(m.persona, ['脾气急', '爱较真'], '相同条目去重')
  assert.deepEqual(m.never, ['不用感谢'])
  assert.deepEqual(normalizeProfile({ syntax: ['  ', 'x', 'x'] }).syntax, ['x'], '空串和重复丢掉')
})

test('注入模板：对话对最优先、口头禅带语境、never/锚齐备、边界收尾', () => {
  const hint = renderDistillHint('老王', {
    exchanges: ['问：「这个怎么弄」\n答：「你先重启试试」'],
    catchphrases: ['搞（催办时）'], syntax: ['长句靠逗号串'], rhetoric: ['出问题就自嘲'],
    never: ['从不说客套话'], persona: ['热心接话'],
  })
  assert.match(hint, /他怎么接话（学的是应对方式，内容绝不照搬）/, '对话对是最强信号，放最前')
  assert.match(hint, /口头禅：搞（催办时）｜句子：长句靠逗号串｜招式：出问题就自嘲/)
  assert.match(hint, /他从不：从不说客套话/)
  assert.match(hint, /他是这样的人：热心接话/)
  assert.match(hint, /群友语感参照「老王」——在这个群里回话时照着他的接法来/)
  assert.match(hint, /只借说话的方式，不借身份：你不是老王本人，别自称他、别替他表态/)
})

test('旧画像字段（style/samples/avoid 存量）兼容渲染，不至于白学', () => {
  const legacy = renderDistillHint('老王', { style: ['句子极短'], samples: ['就这？'], avoid: ['不长篇'], persona: [], tone: [] })
  assert.match(legacy, /他的原话（校准节奏用，绝不照抄内容）：「就这？」/)
  assert.match(legacy, /旧特征：句子极短/)
  assert.match(legacy, /他不会：不长篇/)
  assert.equal(renderDistillHint('老王', {}), '', '空画像不注入')
  // 回归：句数数字不能当原话
  assert.doesNotMatch(renderDistillHint('老王', { style: ['短句'], samples: 44 }), /「44」/)
})

test('提示词（新模板）：exchanges 首要、口头禅带「什么时候用」、never 词表、性格写可观察行为', () => {
  const p = buildDistillPrompt({
    name: '老王', uid: '111',
    memberLines: [L('111', '草 这也能崩')],
    context: [{ uid: '222', name: '小李', text: '这游戏又崩了？' }, { uid: '111', name: '老王', text: '草 这也能崩' }],
    others: ['小李：请问这个怎么弄呀'],
    old: { syntax: ['旧架构'], persona: [] },
  })
  assert.match(p.system, /exchanges（最重要）/, '对话对是首要产出')
  assert.match(p.system, /他的原话（逐字，别改写）/, '回答逐字')
  assert.match(p.system, /什么时候用/, '口头禅带语境')
  assert.match(p.system, /never：他从不用的词/, '负向词表')
  assert.match(p.system, /可观察行为/, '性格写行为不写标签')
  assert.match(p.system, /换成群里另一个人/, 'misreading 自检')
  // 键名只能用英文：中英并置会诱导模型输出「句子架构」这类中文键，
  // 而解析只认英文名 → 整份画像被判空（2026-11-12 真实事故）
  assert.match(p.system, /键名硬要求/, '明确要求英文键名')
  assert.match(p.system, /不要把键名翻译成中文/, '禁止中文键')
  assert.match(p.system, /别写 "learned_style"/, '禁止自创外层命名空间')
  assert.doesNotMatch(p.system, /syntax（句子架构）/, '不再中英并置')
  assert.doesNotMatch(p.system, /catchphrases（口头禅）/, '不再中英并置')
  assert.match(p.text, /群聊原文（用来挑一问一答的对话对/, '交错原文进 prompt')
  assert.match(p.text, /小李：这游戏又崩了？\n他：草 这也能崩/, '按 uid 标「他：」')
  assert.match(p.text, /句子架构：旧架构/, '旧画像按新字段回填')
})

// ---------------- 存储与接线 ----------------
async function freshStore(opts = {}) {
  process.env.AURABOT_DATA_DIR = mkdtempSync(join(tmpdir(), 'distill-'))
  const { createMemoryStore } = await import('../src/features/memory.js')
  const { normalize } = await import('../src/core/config.js')
  const cfg = normalize({ ownerQQ: '10000001', memory: { enabled: true } })
  const hub = {
    chatLogOf: opts.chatLogOf || (() => []),
    chatLogDays: opts.chatLogDays || (() => []),
    groupNames: new Map(opts.groupNames || []),
  }
  return createMemoryStore({ dsh: {}, getConfig: () => cfg, hub, log: () => {}, personaText: () => '' })
}

// #74：主人自己的发言在会话记录里被渲染成「主人：…」（不带 QQ 号，防泄露），
// 解析正则要求「名字(数字)：」，所以主人学自己永远只有老数据、句数不涨。
// chatlog 存真实 uid，必须优先用它。
test('#74 chatlog 是主证据源：主人自己的发言也能被收集（不受提示词脱敏影响）', async () => {
  const uid = '10000001'
  const chatlog = Array.from({ length: 18 }, (_, i) => ({
    t: 1000 + i, chatId: 'group:249729644', who: '主人', uid, text: '今天群里第 ' + i + ' 句话',
  }))
  chatlog.push(
    { t: 2000, chatId: 'group:249729644', who: '路人', uid: '555', text: '别人的话不算' },
    { t: 2001, chatId: 'group:999', who: '主人', uid, text: '别的群的话不该进这个群' },
    { t: 2002, chatId: 'group:249729644', who: '主人', uid, text: '[图片]' },
  )
  const mem = await freshStore({ chatLogDays: () => ['2026-11-12'], chatLogOf: () => chatlog })
  const hist = mem.distillHistory({ gid: '249729644' })
  assert.equal(hist.chatlogDays, 1, '报告 chatlog 覆盖天数')
  assert.equal(hist.chatlogLines, 20, 'chatlog 里这个群的全部行（18 + 路人 1 + 图片 1；别的群不算）')
  const mine = collectMemberLines(hist.lines.map((l) => ({ ...l, t: l.at })), uid)
  assert.equal(mine.length, 18, '主人的 18 句都进来了（不是 0）')
  assert.ok(!mine.some((x) => x.text.includes('别的群')), '按群 id 精确过滤：别的群的话不混进来')
  assert.equal(hist.total, 20, '群级总行数不含别的群')
})

test('#75 证据不足时提示带漏斗：说清命中多少、滤掉多少', async () => {
  const uid = '10000001'
  const rows = []
  for (let i = 0; i < 3; i++) rows.push({ t: i, chatId: 'group:123', who: '主人', uid, text: '就这' })
  rows.push({ t: 10, chatId: 'group:123', who: '主人', uid, text: '[图片]' })
  rows.push({ t: 11, chatId: 'group:123', who: '主人', uid, text: '咋不说话了' })
  const mem = await freshStore({ chatLogDays: () => ['2026-11-12'], chatLogOf: () => rows })
  const r = await mem.learnDistillFromHistory({ gid: '123', uid })
  assert.equal(r.ok, false, '证据不够不学')
  assert.match(r.message, /只有 2 句/, '去重后可用句数')
  assert.match(r.message, /翻到 5 条/, '漏斗：命中数')
  assert.match(r.message, /1 条是纯图片\/转发\/链接/, '漏斗：滤掉的图片')
  assert.match(r.message, /2 条是重复转发的同一句/, '漏斗：重复')
})

test('目标管理：加/去重/删（删的时候连带清掉画像）', async () => {
  const mem = await freshStore()
  assert.equal(mem.addDistillTarget({ gid: '123', uid: '456', name: '老王' }).ok, true)
  assert.equal(mem.addDistillTarget({ gid: '123', uid: '456' }).ok, false, '同一个不能重复加')
  assert.equal(mem.addDistillTarget({ gid: '', uid: '456' }).ok, false, '缺群号')
  assert.deepEqual(mem.distillTargets().map((t) => t.uid), ['456'])
  assert.equal(mem.removeDistillTarget('123', '456').ok, true)
  assert.deepEqual(mem.distillTargets(), [])
})

test('画像落库：新字段结构原样保存，证据条数进 evidenceCount', async () => {
  const mem = await freshStore()
  mem.addDistillTarget({ gid: '123', uid: '456', name: '老王' })
  mem.putDistill('123', '456', { syntax: ['句子短'], exchanges: ['问：「咋弄」\n答：「重启」'] }, 12)
  let p = mem.distillOf('123', '456')
  assert.deepEqual(p.syntax, ['句子短'])
  assert.deepEqual(p.exchanges, ['问：「咋弄」\n答：「重启」'])
  assert.equal(p.evidenceCount, 12)
  assert.ok(p.updatedAt > 0)
  mem.putDistill('123', '456', { syntax: ['爱用逗号'], persona: ['脾气急'] }, 20)
  p = mem.distillOf('123', '456')
  assert.equal(p.syntax[0], '爱用逗号', '新的在前')
  assert.equal(p.evidenceCount, 20, '证据条数取较大值')
  assert.equal(mem.distillList()[0].profile.persona[0], '脾气急')
})

test('旧坏数据自愈：samples 是句数（如 44）的存量画像，渲染与合并都不把它当原话', async () => {
  const broken = { style: ['短句'], persona: [], tone: [], samples: 44, updatedAt: 1 }
  const hint = renderDistillHint('老王', broken)
  assert.doesNotMatch(hint, /「44」/, '数字不能被渲染成原话')
  assert.match(hint, /短句/, '特征照常注入')
  const merged = mergeProfile(broken, { samples: ['真的服了'] })
  assert.deepEqual(merged.samples, ['真的服了'])
  const mem = await freshStore()
  mem.addDistillTarget({ gid: '123', uid: '456', name: '老王' })
  mem.putDistill('123', '456', { style: ['短句'], samples: 44 }, 0)
  mem.putDistill('123', '456', { samples: ['行吧'] }, 0)
  assert.equal(mem.distillOf('123', '456').evidenceCount, 44, '旧的数字 samples 被认作证据条数')
})

test('接线：整理不再学（管线移交 distill 模块）、群聊时注入、面板与接口都在', () => {
  const mem = readFileSync(new URL('../src/features/memory.js', import.meta.url), 'utf8')
  // #78 之后 memory.js 只是门面：档案与注入在 memory-archive.js，模型学习在 memory-learning.js
  const learn = readFileSync(new URL('../src/features/memory-distill-history.js', import.meta.url), 'utf8')
  const archive = readFileSync(new URL('../src/features/memory-archive.js', import.meta.url), 'utf8')
  // 结构红线：consolidate 不再耦合蒸馏管线（避免两边各跑一遍重复花钱），学习调度移交 distill 模块自身 tick
  assert.doesNotMatch(mem, /learnDistill\(/, 'consolidate 不再调用 learnDistill')
  assert.doesNotMatch(learn, /reasoningEffort: 'none'/, '蒸馏不再钉死关思考（推理模型会吃掉全部预算不回正文）')
  assert.match(archive, /renderDistillHint\(t\.name \|\| t\.uid, distillOf/, '群聊注入画像（档案侧）')
  assert.match(learn, /dedupConvo\(hist\.lines\)\.slice\(-80\)/, '历史学习传去重对话原文')
  // distill 模块自持 L0/L1 调度（activity 计数 + 定时 tick）
  const dist = readFileSync(new URL('../src/modules/distill/index.js', import.meta.url), 'utf8')
  assert.match(dist, /api\.on\('activity'/, '模块 L0 计数挂 activity')
  assert.match(dist, /shouldTriggerL1/, 'L1 批阈值在模块')
  // 新核心补 activity 发射（开旗后 hub 不被调用，否则模块永远收不到计数）
  const mc = readFileSync(new URL('../src/host/modular-core.js', import.meta.url), 'utf8')
  assert.match(mc, /emitActivity\(mods, inbound(?:,|\))/, '新核心 realtime 入口发 activity（含 direct/owner 参数）')
  const mod = readFileSync(new URL('../src/modules/distill/index.js', import.meta.url), 'utf8')
  assert.match(mod, /api\.route\('\/distill\/list'/)
  assert.match(mod, /api\.route\('\/distill\/card\/refresh'/)
  const client = readFileSync(new URL('../client/client.js', import.meta.url), 'utf8')
  assert.match(client, /function DistillPanel/, '面板有独立组件')
  assert.match(client, /蒸馏群友（学一个人的说话样子）/, '独立卡片')
})
