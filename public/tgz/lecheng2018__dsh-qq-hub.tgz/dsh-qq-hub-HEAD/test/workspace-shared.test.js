// 一个聊天一个工作区会把宿主的工作区列表撑爆（2026-11-05 实测：3 个群就 3 条同名工作区）。
// 默认改成所有 QQ 会话共用主工作区；要按聊天隔离得在配置里显式打开 workspacePerChat。
import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const CORE = readFileSync(join(ROOT, 'src/host/modular-core.js'), 'utf8')
const WORKSPACE = readFileSync(join(ROOT, 'src/chat/workspace.js'), 'utf8')
const CFG = readFileSync(join(ROOT, 'src/core/config.js'), 'utf8')

test('默认共用工作区，只有显式打开才按聊天建', () => {
  assert.match(CORE, /workspaceDirForChat\(getConfig\(\), chatKey\)/, '当前核心必须使用共享目录选择')
  assert.match(WORKSPACE, /cfg\?\.workspacePerChat !== true/, '共享纯函数必须显式判断开关')
})

test('配置里这个开关默认关', async () => {
  const { normalize } = await import('../src/core/config.js')
  assert.equal(normalize({}).workspacePerChat, false)
  assert.equal(normalize({ workspacePerChat: true }).workspacePerChat, true)
  assert.match(CFG, /workspacePerChat: false/)
})

test('系统会话（后台任务）永远走主工作区', () => {
  assert.match(WORKSPACE, /startsWith\('system:'\)/, 'system 会话不建子目录')
})
