# DSH QQ Hub

把 QQ 私聊和群聊接入 DeepSeek Harness（DSH）。插件以一个独立的 QQ 号「住」在 QQ 里：收发消息、看图听语音、维护按会话隔离的长期记忆，并提供桌面与手机自适应的管理面板。插件运行在 DSH 所在设备上，支持 fnOS NAS、Windows、Linux 和 Docker 部署。

[![Release](https://img.shields.io/github/v/release/lecheng2018/dsh-qq-hub?color=blue)](https://github.com/lecheng2018/dsh-qq-hub/releases)
[![Tests](https://img.shields.io/badge/tests-passing-success)](https://github.com/lecheng2018/dsh-qq-hub/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

当前版本：**v1.4.7-test.20261121.1**（测试版，主干含「断线补收整批被拒」与「Token 配额跨日永久熔断」两个真机修复；正式版仍为 v1.4.6）。自 v1.3.65 或任一 1.4.x-test 升级，请先阅读 [CHANGELOG.md](CHANGELOG.md) 中 1.4.6 的「升级须知（破坏性）」一节（六个内容模块改为「扩展 → 市场」按需安装）；版本历史与全部 test/beta 记录同在 [CHANGELOG.md](CHANGELOG.md)。

## 它是什么

- **接入层**：通过 OneBot v11 网关收发 QQ 消息。可用插件托管的 SnowLuma（Windows），也可接入已有的 NapCat、LLOneBot、Lagrange 等服务。
- **会话核心**：每条消息走固定链路 `SessionRegistry → TurnController → ContextAssembly → Shared Outbox`——限流、上下文装配、投递台账、身份泄露闸都在这条链路上，全部发送只有一个出口。
- **记忆**：按会话隔离的 Markdown 档案（`memory.md` 为唯一事实源），BM25 召回 + 遗忘曲线 + 每日整理、相处经验反思、语感学习与梦境巩固；私聊记忆在代码层物理隔离，群聊读不到。
- **表达**：语音（edge-tts / CosyVoice / GPT-SoVITS / Windows / 本地接口）、表情包库、QQ 小黄脸、图片收发、按规则分条与仿真打字律动。
- **主动生活流**：两条独立通路——「主动搭话」（轻量随机 + 追问）与「目的引擎」（素材 → 目标假设 → 目的，默认关闭）；两者共用道别静默期与每日 Token 配额熔断。
- **内容模块**：B 站、抖音、小黑盒、多平台链接解析、空间互动等，以模块形式按需安装（内置模块市场）；贴吧阅读等第三方扩展同理。
- **管理面板**：桌面与手机自适应的网页面板——设置向导、16 个内置功能标签页（扩展模块按需增加页面）、扩展模块系统与模拟测试。
- **远程协助**：主人可在 QQ 私聊中使用 DSH 的模型和已授权工具，接收提问卡片并审批高风险操作。
- **自行扩展**：可在数据目录添加模块，无需修改插件源码；支持热重载、fork 内置模块和面板模拟测试。

默认不会向所有私聊和群开放。机器人账号、主人账号、可用私聊和群都需要明确配置。

## 安装前准备

需要：

1. 已安装并能正常使用 DSH，已配置可用模型。
2. 一个作为机器人使用的 QQ 小号。
3. 一个兼容 OneBot v11 的 QQ 网关：
   - 已有 NapCat、LLOneBot、Lagrange 等服务时，直接使用其正向 WebSocket 地址。
   - Windows 也可使用 [SnowLuma](https://github.com/SnowLuma/SnowLuma/releases)，由插件辅助启动和接入。

OneBot 是插件与 QQ 网关之间的通信协议。它本身不是 QQ 登录服务，仍需单独安装和登录网关。

## 安装

### 在线安装

Windows 桌面版：

```powershell
& "$env:LOCALAPPDATA\Programs\DeepSeek Harness\resources\runtime\cli\bin\dsh.cmd" plugin --profile desktop add github:lecheng2018/dsh-qq-hub
```

fnOS、Linux 或 Docker 命令行：

```bash
dsh plugin --profile <你的-profile-名称> add github:lecheng2018/dsh-qq-hub
```

### 离线安装

从 [Releases](https://github.com/lecheng2018/dsh-qq-hub/releases) 下载所需版本的 `.tgz`，然后执行：

```bash
dsh plugin --profile <你的-profile-名称> add ./dsh-qq-hub-<版本号>.tgz
```

也可以在 DSH 的插件安装界面中选择该文件。安装后重启 DSH。

## 第一次配置

打开 DSH 左侧「自动化任务」中的 **QQ Hub**，按设置向导完成：

1. 填写机器人 QQ 小号和你自己的主人 QQ 号。
2. 选择网关：
   - **已有 OneBot 服务**：填写正向 WebSocket 地址；如果网关启用了访问令牌，也填写对应令牌。
   - **Windows SnowLuma**：填写安装目录，启动服务，阅读并同意其协议，再接入已登录机器人小号的 QQ 进程。
3. 添加允许使用的私聊和群。主人私聊不需要重复添加。
4. 检查网关是否已连接，以及插件核对出的登录号是否为机器人小号。
5. 先保持 **试运行** 开启，用主人账号发一句「在吗」。

试运行时，插件会处理消息并记录准备发送的内容，但不会真的发到 QQ。确认回复、权限和日志正常后，打开总开关并关闭试运行。

### 开放 HTTP 联动接口（可选）

面板读写和首次配置不需要联动密钥，身份认证由 DSH/fnOS 外层或反向代理负责。只有供其他程序调用的 `/open/*` 接口需要 `bridge.http: true` 和匹配的非空 `bridge.token`；开放接口默认关闭，不影响面板使用。

需要开放联动接口时，停止 DSH 并备份本机数据目录中的 `config.json`，再设置 `bridge.http` 和高强度随机 `bridge.token`。联动密钥不通过面板 API 回显或重置；完整步骤见[配置参考](docs/CONFIGURATION.md#开放-http-联动接口)。不要把面板或开放接口直接暴露到公网。

### fnOS / Docker 网络注意事项

- 如果 DSH 和 QQ 网关不在同一容器或同一设备，不要使用 `127.0.0.1`。
- 应填写网关所在设备或容器实际可访问的地址，并确认端口和容器端口映射已开放。
- 使用域名访问 QQ Hub 面板时，需要把域名加入 `config.json` 的 `security.panel.allowedHosts`；直接通过设备 IP 访问不需要这一项。

## 日常使用

以下命令只接受主人发送。即使总开关关闭，也可以用 `/on` 恢复。

| 命令 | 用途 |
|---|---|
| `/help` | 查看当前可用命令，包括扩展命令 |
| `/status` | 查看连接、收发和运行状态 |
| `/on`、`/off` | 打开、关闭插件总开关 |
| `/silent [分钟]` | 当前聊天暂停发言，可设自动恢复时间 |
| `/active` | 恢复当前聊天 |
| `/quiet`、`/chatty`、`/normal` | 调整当前群的插话档位 |
| `/model` | 查看模型；`/model 序号` 切换，`/model 默认` 跟随 DSH |
| `/remember 内容` | 在当前聊天的作用域中记住一件事 |
| `/reset` | 清空当前对话上下文，不删除长期记忆 |
| `/new` | 清除当前聊天的记忆，不动对话历史 |
| `/diary` | 立即写一篇 QQ 空间日记 |

## 在面板中管理

面板按「概览 / 人设 / 表达 / 平台 / 系统」五个分组组织 16 个内置功能标签页（安装扩展模块后会增加对应页面），桌面端为分组 + 标签两层导航（Alt+K 查找），手机端为底部分组栏 + 组内横滚页签。

- **概览**：收发统计、更新提示、快捷操作与最近日志。
- **连接**：网关、工作区和连接诊断；SnowLuma 的下载、协议同意、密码托管与机器人号接入。
- **人格**：按【标题】分节编辑人格卡，支持 AI 润色；可按群、按人指定人格。
- **权限**：当前档位概览、主人身份与白名单、权限档位与长任务模式、改资料类操作权限（按平台分页）、群管身份与 QQ 命令一览。
- **聊天**：连发合并、分条规则、回合超时、群插话策略、同类 bot 防刷屏、发文件与危险命令确认。
- **模型**：当前模型概览、全局模型与思考强度、看图（视觉能力与辅助看图）、按聊天覆盖、可用模型列表与「应用到现有会话」。
- **用量**：今日 Token 记账与逐会话分配、每日预算与主人占比、上下文压缩阈值、回复截断守卫。
- **记忆**：长期记忆库、人物小档案、相处经验与说话方式、召回记录与旧档案导入。
- **表达**：语音引擎与试听、语音识别、表情包库、生图接口与画作库。
- **平台**：空间日记；B 站、抖音、小黑盒、内容解析（从模块市场安装后出现）。
- **系统**：本地接口（ASR/TTS/生图脚本模板）、扩展模块管理、日志。

扩展系统支持关闭、复制内置模块来改、从模板新建和面板模拟测试；模块改坏时开启「安全模式」即可恢复。设置改动统一经底部保存栏提交（Ctrl/⌘+S），未保存的标签会标记小圆点。

## 常用配置

大多数设置在面板中修改后会立即保存。下面只列日常使用中最需要理解的项；字段路径和排障说明见 [配置参考](docs/CONFIGURATION.md)。

| 配置 | 用途 |
|---|---|
| `enabled`、`dryRun` | 总开关与试运行；排障时先确认这两项 |
| `ownerQQ`、`ownerLevel` | 主人账号及其私聊权限；完整权限包含本地工具，应谨慎授予 |
| `allow.private`、`allow.groups` | 允许对话的私聊和群白名单 |
| `workspaceDir` | QQ 会话工作区，也是默认允许发送文件的目录 |
| `model`、`chatModels` | 全局模型及按私聊/群覆盖；可按聊天选择视觉和思考强度 |
| `merge`、`reply` | 私聊和群聊的连发合并等待时间与分条上限 |
| `backfill` | 断线恢复后补收消息的范围、等待和数量上限 |
| `files` | 文件发送开关、大小上限和额外允许目录 |
| `voice`、`stickers` | 语音、表情和自动收藏行为 |
| `security` | 高风险命令确认、账号泄露检查和面板访问控制 |

### 模型选择顺序

按聊天指定的模型优先于全局模型：单个私聊或群 → 所有私聊/群默认 → 全局设置 → DSH 默认。指定的模型已从 DSH 删除时会退回下一级。

### 面板使用域名访问

插件会检查请求的 Host 和来源。直接通过设备 IP 访问通常无需额外配置；使用 fnOS DDNS 或其他域名时，把域名加入：

```json
{
  "security": {
    "panel": {
      "allowedHosts": ["nas.example.com"]
    }
  }
}
```

如果前面还有反向代理，应在代理层另外配置访问控制，不要只依赖公网暴露的插件面板。

## 模块依赖与限制

模块可以在「扩展」页单独停用。以下能力不是安装插件后就无条件可用：

自 1.4.5 起，**B 站、抖音、小黑盒、内容解析、空间互动与「投递异常」不再内置**，改为从面板「扩展 → 市场」按需安装（内容仓库 [dsh-qq-hub-mods](https://github.com/lecheng2018/dsh-qq-hub-mods)）；安装后行为与内置版一致，原有配置与数据保留。

自 1.4.7 起，**「QQ 增强」七件套不再内置**：闪传、群文件、在线与已读、社交动作、Ark 卡片、AI 语音、工作区文件。这些能力依赖 SnowLuma / QQ 侧的扩展动作，在当前网关与 QQ 版本上已无法工作，面板却仍显示「在跑」。实现已从核心移除，源码归档到商店仓库的 `modules/_qq-enhance/`（不发布），等重新开发并验证可用网关后再以市场模块发布。相关面板页与导航入口一并删除。

| 模块 | 需要准备 | 主要限制 |
|---|---|---|
| 语音识别与语音条 | 网关转写、本地 ASR 或可用的 TTS 服务 | 失败时应退回文字并说明原因 |
| 生图 | 可用的图片生成接口或已配置的本地接口 | 构图和尺寸能力取决于服务端 |
| B 站（商店模块） | 按需填写登录 Cookie；看画面还需 ffmpeg 和视觉模型 | 评论、改资料等写操作有独立权限和额度 |
| 抖音（商店模块） | 可用浏览器及扫码登录；NAS 无桌面时需显示环境 | 验证码、身份验证和平台风控会暂停写操作 |
| 小黑盒（商店模块） | 账号 Cookie；写操作还需相应令牌 | 浏览、评论、发帖分别受权限和频率限制 |
| 多平台解析（商店模块） | 无需准备即可解析公开内容 | 默认只进上下文与发媒体，不自动唤醒回复；部分平台 Cookie 可提升清晰度 |
| 贴吧阅读 | 可运行浏览器；也可使用其自带安装流程 | 只读，不提供发帖、回帖和点赞 |
| 目的引擎 | 无需额外准备 | 默认关闭；与「主动搭话」二选一开启，避免重复打扰 |

外部平台可能随时调整接口、验证码和风控策略。模块失败时不要反复重试写操作，先看日志和账号状态。

## 权限与安全

### 主人私聊权限很高

`ownerLevel` 默认为 `full`：主人私聊可使用 DSH 提供的本地命令和文件工具，实际操作权限取决于运行 DSH 的系统账号。如果主人 QQ、模型上下文或面板被攻陷，可能导致本机文件被读取、修改或删除，甚至执行系统命令。请只把可信账号设为主人；不需要本机工具时，改用 `social` 或 `chat`，并妥善保护 DSH 面板。

- 群聊和非主人私聊不加载本地命令、文件系统等电脑操作工具。
- 发文件仅限 QQ 工作区和面板额外允许的目录，并有单文件大小限制。
- 出站内容经过身份泄露闸：私聊和群聊都会拦截主人/机器人账号标识，群聊对裸长号码规则更严格。
- `security.dangerConfirm` **默认关闭**，因此默认 `full` 不会自动要求危险命令确认。可在安全设置中开启：命中规则时主人需在 QQ 私聊确认，取消或超时则拦截。
- 危险命令确认仅对 `bash`/`pwsh` 工具进行静态规则检测，并非沙箱或完整拦截器；动态拼装、未知变形或其他工具仍可能绕过，不能替代最小权限、系统隔离与备份。
- 网关令牌、Cookie 等凭据不会通过面板明文回显；日志会进行脱敏。

### 外部账号和模块

- QQ 机器人请使用小号。第三方网关和自动化操作存在账号限制或封禁风险。
- B 站、抖音、小黑盒等模块可能执行浏览、评论或发帖。请分别检查其权限和每日额度。
- 自行编写的模块与插件同进程运行，能使用你授予的接口。不要加载来源不可信的模块。
- 预发布版用于验证新功能，不建议未经测试直接替换稳定使用的生产实例。

## 自定义模块：最小示例

在数据目录创建 `modules/hello/index.mjs`：

```javascript
export default {
  id: 'hello',
  name: '问候示例',
  api: 1,
  setup(api) {
    api.on('message', async (msg) => {
      if (msg.text !== 'ping') return false
      await api.sendText(msg.chatId, 'pong')
      return true
    })

    api.command({
      name: 'hello',
      desc: '回复一句问候',
      run: (arg) => `你好${arg ? `，${arg}` : ''}`,
    })

    api.rule(() => '你可以在用户说 ping 时用 hello 模块回复 pong。')
  },
}
```

保存后，模块会在数秒内加载。它提供三项能力：

- 收到 `ping` 时回复 `pong`，并阻止该消息继续进入模型。
- 主人发送 `/hello 大家` 时得到扩展命令回复。
- 通过 `api.rule()` 向模型说明模块能力。

需要模型调用工具、读取配置、注册面板接口或定时任务时，查阅 [模块 API 文档](src/modules/API.md)。修改前可在「扩展」页使用模拟测试；真实发送仍受白名单、总开关和试运行约束。

## 数据与升级

默认数据目录：

```text
~/.dsh/plugins-data/dsh-qq-hub/
```

Windows 通常位于：

```text
%USERPROFILE%\.dsh\plugins-data\dsh-qq-hub\
```

老版本沿用已有的 `~/.dsh/plugins-data/aurabot/`。也可以通过 `DSH_QQ_HUB_DATA_DIR` 指定目录。

配置、人格、记忆、模块数据和日志都保存在数据目录，不在插件安装目录。升级前仍建议备份数据目录。覆盖安装后重启 DSH；不要直接修改 `node_modules` 来保存长期改动，因为下次升级会覆盖它。

长期记忆以 `memory/<作用域>/memory.md` 为事实源，运行进度与命中统计放在 `memory/state.json`。旧版 `memories.db` / `memories.json` 不会在插件启动时自动迁移，也不会被当作回退库读取。升级旧数据时，先停止插件写入、备份完整数据目录，再在插件目录用 Node.js 22.13+ 执行：

```sh
node scripts/migrate-memory-markdown.js "/实际的数据目录/dsh-qq-hub"
```

如果已有 `memory/` 却没有成功迁移凭据，迁移器会拒绝覆盖。新旧库并存须人工核对，不能直接删掉目录或反复迁移来“修复”；无作用域旧条目进入隔离区，不公开召回。成功后保留源文件与备份，再恢复插件。详细数据边界见 [配置说明](docs/CONFIGURATION.md#主要数据文件)。

手工编辑 `memory.md` 后，在面板「记忆库」点击「重新载入档案」。坏档案会显示文件和错误，自动整理暂停；修复后可再次载入。重载会取消在途整理并刷新索引；它不是旧库迁移入口。

整理批次出现「状态未确认」时，`GET /memory/batches` 可查看 running/pending 批次，`POST /memory/batches/resolve` 提交 `{ "id": "extract_…", "action": "retry" }` 可标记重试。pending 在人工核对已提交事实后也可提交 `action: "done"`；running 不能直接完成。未经恢复不会推进对应日期进度，也不要直接删除 `extractionBatches` 来绕过核对。

当前生产核心固定为 `SessionRegistry → TurnController → ContextAssembly → Shared Outbox`。旧 hub、pipeline、fallback、旧 SQLite 后端及其灰度开关已退出源码；设置旧环境变量不会恢复旧实现。需要回滚时必须停写并使用固定旧安装包，同时核对升级前数据备份，代码回滚不会自动回滚 Markdown 档案。

### 从 v1.3.65 升级

1.4.x 相对 v1.3.65 的破坏性变更：心情系统、翻唱与 RVC 变声、资讯池（RSS）与定时任务（scheduler）内置模块已移除；旧内核与旧 SQLite 后端退出源码；长期记忆迁移到 Markdown 档案（见上文）。完整清单见 [CHANGELOG.md](CHANGELOG.md) 的「移除（破坏性变更）」一节。移除功能的配置键会在加载时自动丢弃，数据文件自动改名留档，不会静默删除。

## 常见问题

### 完全收不到回复

依次检查：总开关、试运行、网关连接、私聊/群白名单和日志。群聊可先 @ 机器人测试。

### 网关地址正确但连不上

确认 WebSocket 服务已启动、令牌一致、端口可访问。在 fnOS/Docker 中重点检查 `127.0.0.1` 是否误指向 DSH 自己。

### 回复被身份检查拦下

查看日志中的脱敏拦截原因和投递异常收件箱。群聊中不要发送主人或其他受保护账号；普通文档编号在私聊中不会被当成账号拦截。

### 文件没有收到

检查是否实际调用文件上传，而不是只出现 `[file]` 文本；同时检查文件是否位于允许目录、是否超过大小限制，以及网关能否访问该路径。远程网关看不到 DSH 本机路径时，小文件会按配置尝试 base64 上传。

### 模块改坏了

在「扩展」页停用该模块，或开启安全模式。内置模块的自定义副本损坏时会回退到内置实现。

### 语音或浏览功能不可用

这些功能有额外依赖。语音需要可用的语音识别/合成服务；网页模块需要可用浏览器。具体错误以模块页面和日志为准。

更多操作说明见 [用户使用手册](docs/USER-MANUAL.md)。

## 开发与验证

项目使用 Node.js 原生测试框架，无需额外测试框架。完整开发环境、接口稳定性边界、贡献流程、基准测试和安全纪律见[开发指南](docs/DEVELOPMENT.md)与[贡献指南](CONTRIBUTING.md)。

```bash
npm ci
npm ci --prefix extensions/tieba-reader
npm run lint
npm run test:all
npm run benchmark
npm run smoke:pack
npm run pack:check
```

面板源码在 `client/src/`；改动后运行 `npm run build:client` 并提交同步后的 `client/client.js`。Verify 工作流会检查构建产物、运行合成基准并以独立临时 consumer 安装 tarball。普通 CI 不连接真实 QQ。

这份产物检查在本地也能单独跑，而且**只比对、不落盘**：

```bash
npm run check:client   # 退出码非 0 = 产物与 client/src 不同步，跑 npm run build:client 后一起提交
```

`npm ci` 会自动执行 `npm run setup:hooks`，把仓库内的 `.githooks/` 挂成本地钩子；其中的 `pre-push` 用同一条 `check:client` 在 push 之前就拦下「改了源码忘了重新提交产物」（紧急情况 `git push --no-verify` 可跳过，CI 仍会拦）。

### 文档入口

- 用户：[使用手册](docs/USER-MANUAL.md)、[配置参考](docs/CONFIGURATION.md)
- 开发者：[开发指南](docs/DEVELOPMENT.md)、[贡献指南](CONTRIBUTING.md)、[安全策略](SECURITY.md)
- 模块作者：[模块 API](src/modules/API.md)
- 维护者：[功能与测试矩阵](docs/refactor/feature-matrix.md)、[新核心验证台账](docs/refactor/new-core-parity-ledger.md)、[重构文档目录](docs/refactor/handoff.md)
- 发布历史：[CHANGELOG.md](CHANGELOG.md)

问题反馈请附上插件版本、部署环境、复现步骤和脱敏日志。

## 许可与致谢

- 代码使用 [MIT License](LICENSE)。
- 项目早期基于 [dsh-aurabot-qq](https://github.com/aureth-labs/dsh-aurabot-qq) 演进。
- 多平台内容解析设计参考 [astrbot_plugin_multi_parser](https://github.com/Qfxaile/astrbot_plugin_multi_parser)。
- 素材和第三方组件的许可说明见 [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md)。
