# 快捷绘图插件 · Quick Draw Tool

> 给你的 DSH 装上快捷的常驻绘图插件。

一个基于本地 ComfyUI 的 DSH 常驻画图面板插件：打开 DSH 即可在右下角看到"画图"入口，无需在对话中调用。

- 作者：尹本风（[Yinbenfeng](https://github.com/Yinbenfeng)）
- 仓库：[Yinbenfeng/dsh-plugin-quick-draw-Tool-](https://github.com/Yinbenfeng/dsh-plugin-quick-draw-Tool-)
- npm 包名：`dsh-plugin-quick-draw-tool`（暂未发布到 npm，从本仓库安装）

---

## 功能特性

- 右下角常驻"画图"入口，打开 DSH 即用。
- 两段提示词、宽高、步数、随机/指定种子。
- 图片预览、放大查看。
- 提示词2可保存为常驻预设按钮。
- 图片安全编号保存（绝不覆盖）。
- 一键部署固定版本 ComfyUI。
- 固定 ComfyUI v0.33.0，工作流零第三方自定义节点。

---

## 效果预览

示例图由本插件工作流（Krea 2 Turbo + Qwen 编码器）生成，仅作展示。

| 示例 1 | 示例 2 | 示例 3 |
|---|---|---|
| ![demo-1](docs/images/demo-1.png) | ![demo-2](docs/images/demo-2.png) | ![demo-3](docs/images/demo-3.png) |

---

## 安装

### 前置要求

1. Node.js `>=22.19`、Git、Python `3.12.x`。
2. 根据你的 NVIDIA 显卡驱动安装对应版本的 PyTorch（CUDA 版）。已验证组合：`2.13.0+cu130`。安装命令请参考 <https://pytorch.org>，例如：

   ```powershell
   pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu130
   ```

   > PyTorch 与显卡驱动由用户自行安装，插件不会替你做这件事。

### 第 1 步：安装插件

从 GitHub 安装：

```powershell
npm install git+https://github.com/Yinbenfeng/dsh-plugin-quick-draw-Tool-.git
```

把包加入 DSH Web Profile 的依赖和 bundle 列表：

```json
{
  "dependencies": {
    "dsh-plugin-quick-draw-tool": "git+https://github.com/Yinbenfeng/dsh-plugin-quick-draw-Tool-.git"
  },
  "dsh": {
    "profile": {
      "bundles": [
        "@deepseek-ai/dsh-base",
        "@deepseek-ai/dsh-web-app",
        "dsh-plugin-quick-draw-tool"
      ]
    }
  }
}
```

> 保留 profile 原有的 bundles，只把 `dsh-plugin-quick-draw-tool` 追加进去。

### 第 2 步：部署 ComfyUI

在项目目录运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1
```

脚本会克隆官方 ComfyUI 并固定到 `v0.33.0`（commit `2f35f4a`）。默认安装目录：

```text
%USERPROFILE%\.dsh\comfyui-drawing\ComfyUI
```

### 第 3 步：下载模型

模型**不随插件分发**，需要你按下表从官方页面下载，并放入 ComfyUI 根目录下的对应子目录。下表第一列为完整放置路径（默认安装目录下）：

| 文件 | 完整放置路径 | 下载页面 | 许可证 |
|---|---|---|---|
| `krea2_turbo_mxfp8.safetensors` | `%USERPROFILE%\.dsh\comfyui-drawing\ComfyUI\models\diffusion_models\krea2_turbo_mxfp8.safetensors` | <https://huggingface.co/Comfy-Org/Krea-2/tree/main/diffusion_models> | Krea 2 Community License（<https://www.krea.ai/krea-2-licensing>） |
| `qwen3vl_4b_fp8_scaled.safetensors` | `%USERPROFILE%\.dsh\comfyui-drawing\ComfyUI\models\text_encoders\qwen3vl_4b_fp8_scaled.safetensors` | <https://huggingface.co/Comfy-Org/Qwen3-VL/tree/main/text_encoders> | Apache-2.0 |
| `qwen_image_vae.safetensors` | `%USERPROFILE%\.dsh\comfyui-drawing\ComfyUI\models\vae\qwen_image_vae.safetensors` | <https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/tree/main/split_files/vae> | Apache-2.0 |

> **Krea 2 Turbo 注意**：该模型使用 Krea 2 Community License，包含年收入 100 万美元以下的商业使用门槛和内容过滤要求。下载前请先阅读并接受 <https://www.krea.ai/krea-2-licensing>。

你也可以随时运行检查脚本，缺失的模型会列出对应的下载页面：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\check.ps1
```

### 第 4 步：启动 ComfyUI

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\start-comfyui.ps1
```

ComfyUI 默认只监听 `127.0.0.1:8188`。

### 第 5 步：重启 DSH

重启 DSH 并打开页面，右下角即可看到"画图"按钮。点击即用：提示词 → 生成 → 预览 → 保存。

---

## 环境变量

| 变量 | 作用 | 默认值 |
|---|---|---|
| `DSH_COMFYUI_ROOT` | 脚本使用的 ComfyUI 安装目录 | `%USERPROFILE%\.dsh\comfyui-drawing\ComfyUI` |
| `DSH_COMFYUI_URL` | ComfyUI 服务地址 | `http://127.0.0.1:8188` |
| `DSH_COMFYUI_WORKFLOW` | API 工作流绝对路径 | 包内 `workflows/t2i-v7-api.json` |
| `DSH_COMFYUI_PRESETS` | 提示词2预设存储文件 | `%USERPROFILE%\.dsh\comfyui-prompt2-presets.json` |

---

## 开发

```powershell
npm run build
npm run check
npm test
```

生成的 `lib/` 由 `build` 重新构建，`prepack` 会自动跑测试。

---

## 许可证

插件原创代码采用 MIT。

第三方组件各自适用自己的许可证，详见 [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md)：ComfyUI（GPL-3.0）、Krea 2 Turbo（Krea 2 Community License）、Qwen 模型组件（Apache-2.0）。仓库与安装包均不包含任何模型权重。
