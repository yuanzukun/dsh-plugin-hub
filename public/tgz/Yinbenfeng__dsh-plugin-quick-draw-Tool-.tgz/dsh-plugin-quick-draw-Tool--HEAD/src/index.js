import { access, mkdir, readFile, stat, writeFile } from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import { fileURLToPath } from 'node:url'

export const name = 'dsh-plugin-quick-draw-tool'
export const inject = ['webServer']

const packageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const DEFAULT_URL = process.env.DSH_COMFYUI_URL || 'http://127.0.0.1:8188'
const WORKFLOW_PATH = process.env.DSH_COMFYUI_WORKFLOW || path.join(packageRoot, 'workflows', 't2i-v7-api.json')
const PRESETS_PATH = process.env.DSH_COMFYUI_PRESETS || path.join(os.homedir(), '.dsh', 'comfyui-prompt2-presets.json')
const MAX_BODY_BYTES = 64 * 1024
const MAX_IMAGE_BYTES = 64 * 1024 * 1024
const GENERATE_ROUTE = '/dsh-comfyui/generate'
const IMAGE_ROUTE = '/dsh-comfyui/image'
const SAVE_ROUTE = '/dsh-comfyui/save'
const PRESETS_ROUTE = '/dsh-comfyui/prompt2-presets'
const HEALTH_ROUTE = '/dsh-comfyui/health'

function json(res, status, value) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(value))
}

async function readJsonBody(req) {
  let size = 0
  const chunks = []
  for await (const chunk of req) {
    size += chunk.length
    if (size > MAX_BODY_BYTES) throw new Error('request body is too large')
    chunks.push(chunk)
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'))
}

function integer(value, fallback, min, max) {
  const parsed = Number(value)
  if (!Number.isInteger(parsed)) return fallback
  return Math.max(min, Math.min(max, parsed))
}

function imageUrl(image) {
  const params = new URLSearchParams({
    filename: String(image.filename || ''),
    subfolder: String(image.subfolder || ''),
    type: String(image.type || 'output'),
  })
  return `${IMAGE_ROUTE}?${params.toString()}`
}

async function comfy(pathname, init) {
  return fetch(`${DEFAULT_URL}${pathname}`, init)
}

async function waitForImage(promptId) {
  for (let attempt = 0; attempt < 240; attempt += 1) {
    await new Promise(resolve => setTimeout(resolve, 500))
    const response = await comfy(`/history/${encodeURIComponent(promptId)}`)
    if (!response.ok) continue
    const history = await response.json()
    const record = history[promptId]
    if (!record) continue
    if (record.status?.status_str === 'error') {
      throw new Error(`ComfyUI execution failed: ${JSON.stringify(record.status.messages || record.status).slice(0, 800)}`)
    }
    for (const output of Object.values(record.outputs || {})) {
      const image = Array.isArray(output.images) ? output.images[0] : undefined
      if (image) return image
    }
  }
  throw new Error('ComfyUI generation timed out')
}

async function generate(req, res) {
  if (req.method !== 'POST') return json(res, 405, { error: 'method not allowed' })
  try {
    const input = await readJsonBody(req)
    const prompt1 = String(input.prompt1 || '').trim()
    const prompt2 = String(input.prompt2 || '').trim()
    if (!prompt1 && !prompt2) return json(res, 400, { error: 'prompt1 or prompt2 is required' })
    const workflow = JSON.parse(await readFile(WORKFLOW_PATH, 'utf8'))
    const prompt = [prompt1, prompt2].filter(Boolean).join(' ')
    workflow['50'].inputs.value = prompt
    workflow['52'].inputs.value = integer(input.width, 1024, 64, 4096)
    workflow['53'].inputs.value = integer(input.height, 1024, 64, 4096)
    workflow['30:3'].inputs.steps = integer(input.steps, 8, 1, 100)
    workflow['30:3'].inputs.seed = Number.isSafeInteger(Number(input.seed)) && Number(input.seed) >= 0
      ? Number(input.seed)
      : Math.floor(Math.random() * 1125899906842624)
    const queuedResponse = await comfy('/prompt', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ prompt: workflow, client_id: `dsh-comfyui-${crypto.randomUUID()}` }),
    })
    const queuedText = await queuedResponse.text()
    if (!queuedResponse.ok) throw new Error(`ComfyUI /prompt HTTP ${queuedResponse.status}: ${queuedText.slice(0, 800)}`)
    const queued = JSON.parse(queuedText)
    if (!queued.prompt_id) throw new Error('ComfyUI response has no prompt_id')
    const image = await waitForImage(String(queued.prompt_id))
    json(res, 200, {
      filename: String(image.filename),
      subfolder: String(image.subfolder || ''),
      type: String(image.type || 'output'),
      viewUrl: imageUrl(image),
      seed: workflow['30:3'].inputs.seed,
    })
  } catch (error) {
    json(res, 500, { error: error instanceof Error ? error.message : String(error) })
  }
}

async function health(_req, res) {
  try {
    const response = await comfy('/system_stats')
    const text = await response.text()
    if (!response.ok) return json(res, response.status, { ok: false, error: text.slice(0, 500) })
    const data = JSON.parse(text)
    let workflow = true
    try { await access(WORKFLOW_PATH) } catch { workflow = false }
    json(res, 200, { ok: true, url: DEFAULT_URL, workflowPath: WORKFLOW_PATH, workflow, system: data.system || data })
  } catch (error) {
    json(res, 503, { ok: false, url: DEFAULT_URL, workflowPath: WORKFLOW_PATH, error: error instanceof Error ? error.message : String(error) })
  }
}

async function proxyImage(req, res) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return json(res, 405, { error: 'method not allowed' })
  try {
    const url = new URL(req.url || '', 'http://localhost')
    const params = new URLSearchParams({
      filename: url.searchParams.get('filename') || '',
      subfolder: url.searchParams.get('subfolder') || '',
      type: url.searchParams.get('type') || 'output',
    })
    const upstream = await comfy(`/view?${params.toString()}`)
    if (!upstream.ok) { res.writeHead(upstream.status); return res.end() }
    const length = Number(upstream.headers.get('content-length') || 0)
    if (length > MAX_IMAGE_BYTES) throw new Error('image exceeds size limit')
    const bytes = Buffer.from(await upstream.arrayBuffer())
    if (bytes.length > MAX_IMAGE_BYTES) throw new Error('image exceeds size limit')
    res.writeHead(200, { 'content-type': upstream.headers.get('content-type') || 'image/png', 'content-length': String(bytes.length), 'cache-control': 'private, max-age=3600' })
    if (req.method === 'HEAD') return res.end()
    res.end(bytes)
  } catch (error) { json(res, 500, { error: error instanceof Error ? error.message : String(error) }) }
}

function safeSegment(value, fallback) {
  const cleaned = String(value || '').trim().replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/g, '')
  return cleaned || fallback
}

async function saveImage(req, res) {
  if (req.method !== 'POST') return json(res, 405, { error: 'method not allowed' })
  try {
    const input = await readJsonBody(req)
    const basePath = String(input.savePath || '').trim()
    if (!path.isAbsolute(basePath)) return json(res, 400, { error: 'savePath must be absolute' })
    const targetDir = path.resolve(basePath)
    const baseName = safeSegment(input.saveName, 'image')
    const extension = path.extname(String(input.filename || '')).toLowerCase() || '.png'
    const params = new URLSearchParams({ filename: String(input.filename || ''), subfolder: String(input.sourceSubfolder || ''), type: String(input.sourceType || 'output') })
    const upstream = await comfy(`/view?${params.toString()}`)
    if (!upstream.ok) throw new Error(`failed to read ComfyUI image: HTTP ${upstream.status}`)
    const bytes = Buffer.from(await upstream.arrayBuffer())
    if (bytes.length === 0 || bytes.length > MAX_IMAGE_BYTES) throw new Error('invalid image size')
    await mkdir(targetDir, { recursive: true })
    for (let index = 1; index <= 9999; index += 1) {
      const candidate = path.join(targetDir, `${baseName}${String(index).padStart(2, '0')}${extension}`)
      try { await access(candidate) } catch {
        await writeFile(candidate, bytes, { flag: 'wx' })
        const saved = await stat(candidate)
        return json(res, 200, { savedPath: path.resolve(candidate), bytes: saved.size, filename: path.basename(candidate) })
      }
    }
    throw new Error('same-name image sequence exhausted')
  } catch (error) { json(res, 500, { error: error instanceof Error ? error.message : String(error) }) }
}

function normalizePresets(value) {
  if (!Array.isArray(value)) return []
  return value.slice(0, 200).map((item, index) => ({ id: String(item?.id || `preset-${index + 1}`), name: String(item?.name || '').trim().slice(0, 80), value: String(item?.value || '').trim().slice(0, 8000) })).filter(item => item.name && item.value)
}

async function presets(req, res) {
  try {
    if (req.method === 'GET') {
      try { return json(res, 200, { items: normalizePresets(JSON.parse(await readFile(PRESETS_PATH, 'utf8'))) }) } catch (error) { if (error?.code === 'ENOENT') return json(res, 200, { items: [] }); throw error }
    }
    if (req.method !== 'PUT') return json(res, 405, { error: 'method not allowed' })
    const input = await readJsonBody(req)
    const items = normalizePresets(input.items)
    await mkdir(path.dirname(PRESETS_PATH), { recursive: true })
    await writeFile(PRESETS_PATH, `${JSON.stringify(items, null, 2)}\n`, 'utf8')
    return json(res, 200, { items })
  } catch (error) { json(res, 500, { error: error instanceof Error ? error.message : String(error) }) }
}

export function apply(ctx) {
  const server = ctx.webServer
  ctx.effect(() => {
    const disposers = [
      server.register({ kind: 'exact', path: GENERATE_ROUTE, handler: generate }),
      server.register({ kind: 'exact', path: IMAGE_ROUTE, handler: proxyImage }),
      server.register({ kind: 'exact', path: SAVE_ROUTE, handler: saveImage }),
      server.register({ kind: 'exact', path: PRESETS_ROUTE, handler: presets }),
      server.register({ kind: 'exact', path: HEALTH_ROUTE, handler: health }),
    ]
    return () => disposers.reverse().forEach(dispose => dispose())
  }, 'dsh-plugin-quick-draw-tool routes')
}
