---
name: comfyui-drawing
description: 使用 DSH 右侧的 ComfyUI 画图面板生成、预览和保存图片。触发词：画图、生成图片、ComfyUI、文生图、t2i。
---

# ComfyUI 画图

优先使用 DSH 页面右侧的“画图”按钮打开面板。面板支持两段提示词、宽高、步数、随机种子、预览和安全编号保存。

运行要求：

- DSH Host 能访问配置的 ComfyUI 地址，默认 `http://127.0.0.1:8188`。
- ComfyUI 已安装仓库附带的 API 工作流所需模型。
- PyTorch 和模型由用户根据仓库 README 自行安装、下载并接受各自许可证。

失败时先检查面板中的“检查连接”，再运行仓库的 `scripts/check.ps1`。不要声称插件会自动安装 PyTorch、显卡驱动或模型。
