$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$manifest = Get-Content (Join-Path $root 'manifests\compatibility.json') -Raw | ConvertFrom-Json
$models = Get-Content (Join-Path $root 'manifests\models.json') -Raw | ConvertFrom-Json
$comfyRoot = if ($env:DSH_COMFYUI_ROOT) { $env:DSH_COMFYUI_ROOT } else { Join-Path $HOME '.dsh\comfyui-drawing\ComfyUI' }
$ok = $true
if (-not (Test-Path (Join-Path $comfyRoot 'main.py'))) { Write-Warning "ComfyUI is not installed at $comfyRoot"; $ok = $false }
try { & python -c "import torch; print(torch.__version__); print(torch.cuda.is_available())" } catch { Write-Warning 'PyTorch import failed'; $ok = $false }
foreach ($model in $models.models) {
  $file = Join-Path (Join-Path $comfyRoot $model.directory) $model.filename
  if (Test-Path $file) { Write-Host "FOUND $($model.filename)" } else { Write-Warning "MISSING $($model.filename) -> $($model.downloadPage)"; $ok = $false }
}
try { $health = Invoke-RestMethod 'http://127.0.0.1:8188/system_stats' -TimeoutSec 5; Write-Host "ComfyUI reachable: $($health.system.comfyui_version)" } catch { Write-Warning 'ComfyUI is not reachable at http://127.0.0.1:8188' ; $ok = $false }
if (-not $ok) { exit 1 }
Write-Host 'Environment check passed.'
