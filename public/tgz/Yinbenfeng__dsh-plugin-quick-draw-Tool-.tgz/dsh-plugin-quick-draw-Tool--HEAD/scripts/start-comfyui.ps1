$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$comfyRoot = if ($env:DSH_COMFYUI_ROOT) { $env:DSH_COMFYUI_ROOT } else { Join-Path $HOME '.dsh\comfyui-drawing\ComfyUI' }
if (-not (Test-Path (Join-Path $comfyRoot 'main.py'))) { throw "ComfyUI is not installed at $comfyRoot. Run setup.ps1 first." }
Push-Location $comfyRoot
try { & python main.py --listen 127.0.0.1 --port 8188 } finally { Pop-Location }
