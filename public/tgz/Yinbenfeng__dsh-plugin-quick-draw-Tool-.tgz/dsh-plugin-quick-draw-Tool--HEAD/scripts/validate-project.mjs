import { readFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(fileURLToPath(new URL('../package.json', import.meta.url)))
const workflow = JSON.parse(await readFile(join(root, 'workflows', 't2i-v7-api.json'), 'utf8'))
const manifest = JSON.parse(await readFile(join(root, 'manifests', 'compatibility.json'), 'utf8'))
const required = ['50', '52', '53', '30:3', '30:10', '30:11', '30:12', '30:8']
for (const id of required) if (!workflow[id]) throw new Error(`workflow node missing: ${id}`)
if (workflow['50'].class_type !== 'PrimitiveStringMultiline' || typeof workflow['50'].inputs.value !== 'string') throw new Error('prompt node must be built-in PrimitiveStringMultiline with value input')
if (workflow['52'].class_type !== 'PrimitiveInt' || workflow['53'].class_type !== 'PrimitiveInt') throw new Error('dimension nodes must be built-in PrimitiveInt')
if (manifest.customNodes.length !== 0) throw new Error('compatibility manifest unexpectedly requires custom nodes')
console.log('project manifest and workflow are valid')
