$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$manifest = Get-Content (Join-Path $root 'manifests\compatibility.json') -Raw | ConvertFrom-Json
$comfyRoot = if ($env:DSH_COMFYUI_ROOT) { $env:DSH_COMFYUI_ROOT } else { Join-Path $HOME '.dsh\comfyui-drawing\ComfyUI' }
Write-Host "DSH ComfyUI setup"
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git is required: https://git-scm.com/download/win' }
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw 'Python 3.12 is required: https://www.python.org/downloads/' }
$pythonVersion = (& python --version 2>&1).ToString()
Write-Host "Python: $pythonVersion"
try { & python -c "import torch; print('PyTorch:', torch.__version__); print('CUDA:', torch.cuda.is_available())" } catch { throw 'PyTorch is missing. Install a compatible build from https://pytorch.org/ and rerun this script.' }
if (-not (Test-Path $comfyRoot)) {
  git clone --branch $manifest.comfyui.tag --depth 1 $manifest.comfyui.repository $comfyRoot
} else { Write-Host "Using existing ComfyUI directory: $comfyRoot" }
Push-Location $comfyRoot
try {
  $dirty = git status --porcelain
  if ($dirty) { throw 'The ComfyUI checkout has local changes. Use a clean DSH_COMFYUI_ROOT or preserve those changes manually.' }
  git fetch --tags
  git checkout $manifest.comfyui.commit
  $filteredRequirements = Join-Path $env:TEMP 'dsh-comfyui-requirements.txt'
  Get-Content requirements.txt | Where-Object { $_ -notmatch '^\s*(torch|torchvision|torchaudio)(\s|[<>=!~;]|$)' } | Set-Content $filteredRequirements -Encoding UTF8
  try { & python -m pip install -r $filteredRequirements } finally { Remove-Item $filteredRequirements -Force -ErrorAction SilentlyContinue }
} finally { Pop-Location }
$modelsRoot = Join-Path $comfyRoot 'models'
foreach ($relative in @('diffusion_models', 'text_encoders', 'vae')) { New-Item -ItemType Directory -Force (Join-Path $modelsRoot $relative) | Out-Null }
Write-Host "ComfyUI pinned to $($manifest.comfyui.tag) / $($manifest.comfyui.commit)"
Write-Host "Model directories created under $modelsRoot"
Write-Host "Download the required weights listed in manifests\models.json, then run scripts\check.ps1."
