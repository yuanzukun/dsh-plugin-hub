# Third-party notices

The MIT license in this repository covers only the original DSH plugin code and original workflow configuration.

- DSH and Cordis: provided by DeepSeek Harness under their respective licenses.
- ComfyUI: installed from https://github.com/Comfy-Org/ComfyUI at tag `v0.33.0`, commit `2f35f4a08176d993cded35dac3332be4f7287f41`; GPL-3.0.
- Krea 2 Turbo model: not distributed by this project. Users download it separately and must accept the Krea 2 Community License: https://www.krea.ai/krea-2-licensing
- Qwen3-VL text encoder and Qwen Image VAE: not distributed by this project. Users download them separately from the official Comfy-Org repositories under their stated Apache-2.0 terms.

No model weights are included in this repository or npm package.
