import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { createRequire } from 'node:module'
import vm from 'node:vm'

const require = createRequire(import.meta.url)
const host = await import('../lib/index.js')

test('Host registers distinct exact routes and disposes every route', () => {
  const routes = []
  const disposed = []
  const server = {
    register(route) {
      routes.push(route)
      return () => disposed.push(route.path)
    },
  }
  const cleanups = []
  host.apply({
    webServer: server,
    effect(effect) {
      cleanups.push(effect())
    },
  })
  assert.deepEqual(routes.map(route => [route.kind, route.path]), [
    ['exact', '/dsh-comfyui/generate'],
    ['exact', '/dsh-comfyui/image'],
    ['exact', '/dsh-comfyui/save'],
    ['exact', '/dsh-comfyui/prompt2-presets'],
    ['exact', '/dsh-comfyui/health'],
  ])
  assert.ok(routes.every(route => typeof route.handler === 'function'))
  cleanups.forEach(cleanup => cleanup())
  assert.deepEqual(disposed, [
    '/dsh-comfyui/health',
    '/dsh-comfyui/prompt2-presets',
    '/dsh-comfyui/save',
    '/dsh-comfyui/image',
    '/dsh-comfyui/generate',
  ])
})

test('Client bundle registers the matching loader id and exports apply', async () => {
  const source = await readFile(new URL('../lib/client.js', import.meta.url), 'utf8')
  let definition
  const context = {
    window: { __ModuleLoader__: { load(value) { definition = value } } },
    module: { exports: {} },
    exports: {},
    console,
  }
  vm.runInNewContext(source, context)
  assert.equal(definition.id, 'dsh-plugin-quick-draw-tool')
  const React = { createElement: () => null, useState: () => [false, () => {}], useEffect: () => {} }
  const loaded = definition.factory(id => id === 'react' ? React : (() => { throw new Error(`unexpected require: ${id}`) })())
  assert.equal(typeof loaded.apply, 'function')
  assert.deepEqual(Array.from(loaded.inject), ['slots'])
})

test('package exports the client bundle through the declared subpath', async () => {
  const pkg = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'))
  assert.equal(pkg.exports['./client'], './lib/client.js')
  assert.equal(pkg.dsh.client.platform, 'web')
  assert.ok(pkg.files.includes('lib'))
})
