import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

const workflowUrl = new URL('../workflows/t2i-v7-api.json', import.meta.url)
const modelsUrl = new URL('../manifests/models.json', import.meta.url)

test('workflow uses only ComfyUI built-in modules expected by v0.33.0', async () => {
  const workflow = JSON.parse(await readFile(workflowUrl, 'utf8'))
  assert.equal(workflow['50'].class_type, 'PrimitiveStringMultiline')
  assert.equal(workflow['52'].class_type, 'PrimitiveInt')
  assert.equal(workflow['53'].class_type, 'PrimitiveInt')
  assert.equal(workflow['30:10'].inputs.unet_name, 'krea2_turbo_mxfp8.safetensors')
})

test('all model downloads remain manual', async () => {
  const manifest = JSON.parse(await readFile(modelsUrl, 'utf8'))
  assert.equal(manifest.models.length, 3)
  assert.ok(manifest.models.every(model => model.automaticDownload === false))
})
