// 重建 README 里由自检清单驱动的两块：自检代码块 + 合计项数。
// v0.19.6 起 README 改为功能向，更新日志移出到 CHANGELOG.md，本脚本不再改「目录结构」块。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const p = path.join(ROOT, 'README.md');
let rd = fs.readFileSync(p, 'utf8');

const SUITES = [
  ['smoke.mjs', 113, '平台判据 / 持久化 / 宿主 HTTP 面 / 排期 / ego 后端 / 客户端契约 / 安全边界'],
  ['features-v090.mjs', 31, '账号类型 / 密码库 / 账密代填 / 采集配置与调度 / 新路由'],
  ['features-v0101.mjs', 15, '登录账号查重 / 店铺配置导出导入（含坏数据与重复导入）'],
  ['features-v0110.mjs', 24, '采集数据层（台账缺口 / 导入校验与去重 / 空结果台账 / 查询）'],
  ['features-v0120.mjs', 23, '指标目录层（平台域名与指标数 / 跨平台校验 / metricId / /catalog）'],
  ['features-v0130.mjs', 27, '采集 DSL（编译 / 占位符 / 真实配方 / 登录守卫 / 产物 / HTTP 边界）'],
  ['features-v0140.mjs', 18, '下载落盘 + 采集作业编排（分批 / 重试 / 覆盖 / 交付）'],
  ['features-v0150.mjs', 22, '定时采集（mode 分流 / 待登录跳过 / 回写 / 登录过期自动代填）'],
  ['features-v0152.mjs', 12, '账号密码错的识别与暂停（提示分类 / 状态 / 超时保护）'],
  ['features-v0160.mjs', 19, '采集开关与时间统一到排期（迁移幂等 / tick 只认采集域）'],
  ['features-v0161.mjs', 35, '文案精简与占位符脱敏 / 小眼睛图标 / 下拉框样式 / 按钮尺寸稳定'],
  ['features-v0165.mjs', 20, '登录 iframe 内的账密代填（frame 候选顺序 / 真机壳页面）'],
  ['features-v0166.mjs', 20, '账号身份能力（拼多多不提供买家、抖音买家只走扫码 / 验证码）'],
  ['features-v0167.mjs', 13, '采集引擎四处修复（条件守卫 / 缺后处理能力 / 单日锚点 / 产物归集）'],
  ['features-v0168.mjs', 25, '后处理能力按需执行 / 页面数字字形还原 / 页面文字转指标'],
  ['features-v0169.mjs', 20, '补齐天猫 / 抖音 / 京东配方、登录过期按页面识别'],
  ['features-v0170.mjs', 18, '登录方式可选（账号密码代填 / 扫码或手动登录）'],
  ['features-v0171.mjs', 9, '抖店代填先切「邮箱登录」页签（真机对照实验）'],
  ['features-v0172.mjs', 13, '各平台「登录账号」提示 / 店铺 URL 接口'],
  ['features-v0173.mjs', 8, '代填时自动勾选「同意用户协议 / 隐私条款」'],
  ['features-v0174.mjs', 6, '六平台登录页实测 / 天猫买家入口改走淘宝登录页'],
  ['features-v0175.mjs', 7, '点「登录」按四条路径回退（按钮 / 文字 / 表单提交 / 回车）'],
  ['features-v0176.mjs', 8, '非标准选择器（`:visible` / `:text-is` / xpath `$`）与真实鼠标点击'],
  ['features-v0177.mjs', 9, '定时采集包含下载型配方（含缺陷复现）'],
  ['features-v0178.mjs', 11, '浏览器设置去掉说明性文案，只留可改的选项'],
  ['features-v0179.mjs', 12, '工具 output 声明 + 客户端报错落盘（设置页空白问题可定位）'],
  ['features-v0181.mjs', 12, '抖音买家入口是抖音精选（www.douyin.com/jingxuan）'],
  ['features-v0182.mjs', 12, 'ego 控制权硬停适配（不接管用户空间 / 备用窗口名）'],
  ['features-v0183.mjs', 12, '打开与检测按「平台 × 身份」取参数'],
  ['features-v0184.mjs', 18, '默认配置留给用户、登录态判据不再误判'],
  ['features-v0185.mjs', 9, 'ego 空间没有活页时新建一页（不再留下 https://x/ 空窗口）'],
  ['features-v0186.mjs', 12, 'ego 用户配置按平台共用（同平台同身份才分开）'],
  ['features-v0187.mjs', 19, '表单按平台+身份给提示（买家叫用户名 / 用户账户，卖家叫店铺名 / 登录账号）'],
  ['features-v0188.mjs', 11, '买家账号不做数据采集（不显示采集卡片、接口拒绝、定时只做检测）'],
  ['features-v0192.mjs', 9, '窗口在别处关掉后状态跟上（可见时每 10 秒对一次，不再一直显示「关闭浏览器」）'],
  ['features-v0198.mjs', 10, '窗口里已经登录时不再自动代填'],
  ['features-v0202.mjs', 10, '定时采集到点自己启动 ego（以前要手动先打开一次）'],
  ['features-v0203.mjs', 17, '本机浏览器扫描（Google Chrome、Microsoft Edge 与 ego lite）'],
  ['features-v0252.mjs', 7, '迁移工具补齐：补表格时也带店名，清理旧命名副本'],
  ['features-v02056.mjs', 19, '采集前检查登录态并自动代填 + 单任务硬超时'],
  ['features-v02057.mjs', 19, '页内取字节（fetchFile）：导出接口直取文件，不依赖浏览器下载事件'],
  ['features-v0255.mjs', 9, '采集中途被交还时自动接管（takeOverTaskSpace 后重放）'],
  ['features-v02054.mjs', 8, '窗口归用户控制时自动换一个新窗口继续采'],
  ['features-v0253.mjs', 7, '一次采集只生成一个工作簿（每个采集域一个工作表）'],
  ['features-v0251.mjs', 8, '采集数据命名带店名（作业目录、产物文件名、manifest）'],
  ['features-v02048.mjs', 8, '抖音搜索流量概况配方（流量转化有了可跑配方）'],
  ['features-v02047.mjs', 8, '拼多多推广概况配方（运营推广有了可跑配方）'],
  ['features-v02046.mjs', 8, '登录守卫的 detached 语义（隐藏的登录模板不再误判）'],
  ['features-v02045.mjs', 10, '拼多多流量与商品明细校准（读输入框、卡片指标解析）'],
  ['features-v02044.mjs', 8, '页面字体解码在主世界求值（部分解码不再整轮失败）'],
  ['features-v02043.mjs', 13, '采集域统一五项（去掉竞争洞察）'],
  ['features-v02042.mjs', 7, '采集内容保持内联勾选 + 保存采集域（简洁样式）'],
  ['features-v02041.mjs', 15, '商品 ID 自动补全（采集前抓店铺商品 ID）'],
  ['features-v02040.mjs', 9, '拼多多商品概况（读卡片 + 通用指标对解析）'],
  ['features-v02037.mjs', 12, '采集域决定跑哪些配方（域过滤、已校准门控、界面配方数）'],
  ['features-v02036.mjs', 7, 'ego 执行器把页内请求的结果正确写入产物（不再写成 [object Object]）'],
  ['features-v02035.mjs', 11, '登录页滑块自动滑到底（跨 frame 坐标换算、多套轨迹重试）'],
  ['features-v02034.mjs', 6, '接口在页内读取（不跳转到 JSON 页面、执行失败不静默）'],
  ['features-v02033.mjs', 6, '生意参谋接口改为页内请求（页面不离开首页）'],
  ['features-v02030.mjs', 12, 'JSON 型采集配方的指标解析（生意参谋趋势接口 → 指标表，指标在顶、日期在左）'],
  ['features-v02029.mjs', 8, 'ego lite CLI 位置（升级到新版本目录后仍能识别）'],
  ['features-v02027.mjs', 10, '「用户浏览器」的使用中标记按实际后端，点 ego lite 那一行能切回去'],
  ['features-v02024.mjs', 10, 'Microsoft Edge 支持（扫描列表、启动参数、界面图标）'],
  ['features-v02028.mjs', 9, '工具参数采集域枚举（修掉启动时 COLLECTION_DOMAINS 未定义与对象型参数校验）'],
  ['features-v0216.mjs', 6, '设置页显示采集数据保存在哪，并能一键打开目录'],
  ['features-v0217.mjs', 9, '数据目录可以看、可以打开、也可以换一个（可选把数据搬过去）'],
  ['features-v0218.mjs', 21, '采集数据命名规范（作业目录带时间与采集项、产物带采集项名、manifest、保留策略：默认采到多少留多少、只压纯失败作业、job.json 路径同步）'],
  ['features-v02025.mjs', 7, '用户浏览器点行即切换 / Edge 图标用官方标志'],
  ['features-v0197.mjs', 7, '浏览器设置面板的 hook 顺序（先跑 hook，再提前返回）'],
  ['features-v02059.mjs', 41, '执行器对齐 上游（真实键盘 type / pickdate 日期提交 / 下载硬超时与快照 / 下载门禁 / 重试分层）'],
  ['features-v02060.mjs', 22, '采集工作簿按「同店同天」归集五域（读回 xlsx/csv 表格、补齐其它作业的域、工作表顺序固定）'],
  ['features-v02061.mjs', 33, '退款配方批量搜索 + 真实键盘换行 → Enter（服务履约出数）、ego 用户配置可选与同平台同身份冲突校验'],
  ['features-v02063.mjs', 39, '退款类配方归档延迟（T+2）：配方可声明 t_minus、准备层不再硬塞统一窗口；坏配方显式停用、能跑的配方标校准'],
  ['features-v02065.mjs', 31, '采集数据目录按「店名_平台_尾号」命名（归属标记、老目录兼容、一键迁移）'],
  ['features-v02066.mjs', 41, '作业目录按「成品/日志」分层（执行记录进 logs、原始导出交付后清理，只留成品工作簿）'],
  ['features-v02068.mjs', 12, '工作簿表名带来源（多表导出不再出现 (N) 后缀）、同名表去重、工作簿读回按域名拆域'],
  ['features-v02067.mjs', 35, '下载型产物必进工作簿：认领孤儿下载与 outputs 文件、表名命名空间兼容、同域多表、退款配方域与归档窗口'],
  ['features-v02062.mjs', 31, '淘宝运营推广：阿里妈妈营销场景报表配方（页内取字节 + ZIP 自动解包）、门禁认 evaluate 产物'],
  ['platform.mjs', 12, '平台适配层契约 + macOS 分支（可在 Windows 上验证的部分）'],
];
const TOTAL = SUITES.reduce((n, s) => n + s[1], 0);

// ── 1) 「自检」代码块 ──────────────────────────────────────────────────────────
const codeStart = rd.indexOf('```powershell', rd.indexOf('## 自检'));
const codeEnd = rd.indexOf('\n```', codeStart);
if (codeStart < 0 || codeEnd < 0) throw new Error('找不到自检代码块');
const pad = (str, width) => str + ' '.repeat(Math.max(1, width - str.length));
const block = [
  ...SUITES.map(([file, n, desc]) => pad('node test/' + file, 31) + '# ' + n + ' 项：' + desc),
  'node test/live-probe.mjs pdd   # 真机链路：临时档案启动无头 Chrome，读取 cookie 后关闭 + 「慢跳转」回归',
  'node test/live-probe.mjs all   # 六个平台依次验证（建议逐个执行，共用档案会串 cookie）',
].join('\n');
rd = rd.slice(0, codeStart) + '```powershell\n' + block + rd.slice(codeEnd);

// ── 2) 「一次执行上述前 N 套」与合计项数 ──────────────────────────────────────
if (!rd.includes('`npm test` 一次执行上述前')) throw new Error('找不到「一次执行上述前 N 套」');
rd = rd.replace(/`npm test` 一次执行上述前 \d+ 套/, '`npm test` 一次执行上述前 ' + SUITES.length + ' 套');
if (!rd.includes('- 自检：**')) throw new Error('找不到顶部/尾部的合计项数行');
rd = rd.replace(/- 自检：\*\*\d+ 项\*\*/, '- 自检：**' + TOTAL + ' 项**');

fs.writeFileSync(p, rd, 'utf8');
console.log('TOTAL =', TOTAL, '| suites =', SUITES.length);
