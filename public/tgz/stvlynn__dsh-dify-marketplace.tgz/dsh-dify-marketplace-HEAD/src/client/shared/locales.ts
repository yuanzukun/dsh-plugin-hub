/**
 * Locale dictionaries. User-facing copy lives here, never in components.
 *
 * @module dsh-dify-marketplace/client/shared/locales
 */

export const en = {
  nav: 'Dify Marketplace',
  searchPlaceholder: 'Search plugins',
  search: 'Search',
  tabAll: 'All',
  tabModels: 'Models',
  tabTools: 'Tools',
  tabDatasources: 'Data Sources',
  tabTriggers: 'Triggers',
  tabAgent: 'Agent',
  tabExtensions: 'Extensions',
  tabBundles: 'Bundles',
  tabInstalled: 'Installed',
  marketplaceDown: 'Marketplace unreachable',
  daemonDown: 'Plugin daemon unreachable',
  daemonMissing: 'Plugin daemon is not configured',
  install: 'Install',
  installing: 'Installing…',
  uninstall: 'Uninstall',
  uninstalling: 'Uninstalling…',
  installed: 'Installed',
  credentials: 'Save credentials',
  noResults: 'No plugins in this view.',
  emptyBundles: 'The marketplace returned no bundles.',
  failed: 'Failed',
  close: 'Close',
} as const

export const zh: Record<keyof typeof en, string> = {
  nav: 'Dify 插件市场',
  searchPlaceholder: '搜索插件',
  search: '搜索',
  tabAll: '全部',
  tabModels: '模型',
  tabTools: '工具',
  tabDatasources: '数据源',
  tabTriggers: '触发器',
  tabAgent: 'Agent',
  tabExtensions: '扩展',
  tabBundles: '插件包',
  tabInstalled: '已安装',
  marketplaceDown: '市场不可访问',
  daemonDown: '插件守护进程不可访问',
  daemonMissing: '尚未配置插件守护进程',
  install: '安装',
  installing: '正在安装…',
  uninstall: '卸载',
  uninstalling: '正在卸载…',
  installed: '已安装',
  credentials: '保存凭证',
  noResults: '此视图没有插件。',
  emptyBundles: '市场未返回任何插件包。',
  failed: '失败',
  close: '关闭',
}

export const NS = 'dsh-dify-marketplace'

export type MessageKey = keyof typeof en
