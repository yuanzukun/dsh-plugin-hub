import { describe, expect, it } from 'vitest'
import {
  appendTranscript,
  recognitionConstructor,
  recognitionError,
  recognitionLanguage,
  transcriptFromResults,
  type SpeechRecognitionResultListLike,
} from '../src/client/speech.ts'

describe('appendTranscript', () => {
  it('joins Chinese speech without an artificial space', () => {
    expect(appendTranscript('帮我检查', '这个项目')).toBe('帮我检查这个项目')
  })

  it('separates English words', () => {
    expect(appendTranscript('check', 'this project')).toBe('check this project')
  })

  it('does not insert a space before punctuation', () => {
    expect(appendTranscript('完成了吗', '？')).toBe('完成了吗？')
  })

  it('preserves existing trailing whitespace', () => {
    expect(appendTranscript('hello ', 'world')).toBe('hello world')
  })
})

describe('browser helpers', () => {
  it('prefers the standard constructor and supports the WebKit prefix', () => {
    class Standard {}
    class WebKit {}
    expect(recognitionConstructor({ SpeechRecognition: Standard, webkitSpeechRecognition: WebKit })).toBe(Standard)
    expect(recognitionConstructor({ webkitSpeechRecognition: WebKit })).toBe(WebKit)
  })

  it('falls back to Chinese when the browser language is blank', () => {
    expect(recognitionLanguage('')).toBe('zh-CN')
    expect(recognitionLanguage('en-US')).toBe('en-US')
  })

  it('flattens preferred recognition alternatives', () => {
    const results = {
      0: { 0: { transcript: 'hello ' }, isFinal: true, length: 1 },
      1: { 0: { transcript: 'world' }, isFinal: false, length: 1 },
      length: 2,
    } satisfies SpeechRecognitionResultListLike
    expect(transcriptFromResults(results)).toBe('hello world')
  })

  it('maps permission failures without exposing browser details', () => {
    expect(recognitionError('not-allowed', true)).toBe('麦克风权限被拒绝')
    expect(recognitionError('not-allowed', false)).toBe('Microphone permission was denied')
  })
})
