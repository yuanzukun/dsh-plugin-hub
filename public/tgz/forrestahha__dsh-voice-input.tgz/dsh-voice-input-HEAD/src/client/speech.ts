/** Minimal Web Speech API contract used by the plugin and its test doubles. */
export interface SpeechRecognitionAlternativeLike {
  readonly transcript: string
}

/** One recognition result with its preferred alternative at index zero. */
export interface SpeechRecognitionResultLike {
  readonly 0: SpeechRecognitionAlternativeLike
  readonly isFinal: boolean
  readonly length: number
}

/** Array-like collection returned by a recognition event. */
export interface SpeechRecognitionResultListLike {
  readonly length: number
  readonly [index: number]: SpeechRecognitionResultLike
}

/** Recognition event fields consumed by the plugin. */
export interface SpeechRecognitionEventLike {
  readonly results: SpeechRecognitionResultListLike
}

/** Recognition error fields consumed by the plugin. */
export interface SpeechRecognitionErrorEventLike {
  readonly error: string
  readonly message?: string
}

/** Browser recognition instance used by the React control. */
export interface SpeechRecognitionLike {
  continuous: boolean
  interimResults: boolean
  lang: string
  maxAlternatives: number
  onend: (() => void) | null
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null
  onresult: ((event: SpeechRecognitionEventLike) => void) | null
  onstart: (() => void) | null
  abort(): void
  start(): void
  stop(): void
}

/** Constructor exposed by browsers implementing the Web Speech API. */
export type SpeechRecognitionConstructor = new () => SpeechRecognitionLike

interface SpeechWindow {
  SpeechRecognition?: SpeechRecognitionConstructor
  webkitSpeechRecognition?: SpeechRecognitionConstructor
}

const CJK = /[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]/
const LEADING_PUNCTUATION = /^[,.;:!?，。！？；：、)\]}]/

/** Resolve the standard or WebKit-prefixed recognition constructor. */
export function recognitionConstructor(value: unknown): SpeechRecognitionConstructor | undefined {
  if (typeof value !== 'object' || value === null) return undefined
  const candidate = value as SpeechWindow
  return candidate.SpeechRecognition ?? candidate.webkitSpeechRecognition
}

/** Choose a BCP-47 recognition language from the current browser. */
export function recognitionLanguage(language: string | undefined): string {
  const normalized = language?.trim()
  return normalized === undefined || normalized === '' ? 'zh-CN' : normalized
}

/** Join recognized speech to an existing draft without forcing spaces around CJK. */
export function appendTranscript(draft: string, transcript: string): string {
  const addition = transcript.trim()
  if (addition === '') return draft
  if (draft === '' || /\s$/.test(draft) || LEADING_PUNCTUATION.test(addition)) return draft + addition

  const previous = draft.at(-1) ?? ''
  const next = addition.at(0) ?? ''
  return CJK.test(previous) || CJK.test(next) ? draft + addition : `${draft} ${addition}`
}

/** Flatten the preferred alternative from all current recognition results. */
export function transcriptFromResults(results: SpeechRecognitionResultListLike): string {
  let transcript = ''
  for (let index = 0; index < results.length; index += 1) {
    const result = results[index]
    if (result === undefined || result.length === 0) continue
    transcript += result[0].transcript
  }
  return transcript.trim()
}

/** Map browser error codes to concise user-facing copy. */
export function recognitionError(error: string, chinese: boolean): string {
  const copy: Record<string, readonly [string, string]> = {
    'audio-capture': ['未检测到可用麦克风', 'No microphone is available'],
    'network': ['语音识别网络请求失败', 'Speech recognition network request failed'],
    'no-speech': ['没有检测到语音', 'No speech was detected'],
    'not-allowed': ['麦克风权限被拒绝', 'Microphone permission was denied'],
    'service-not-allowed': ['浏览器禁止使用语音识别服务', 'The browser blocked its speech service'],
  }
  const pair = copy[error]
  if (pair === undefined) return chinese ? `语音识别失败：${error}` : `Speech recognition failed: ${error}`
  return chinese ? pair[0] : pair[1]
}
