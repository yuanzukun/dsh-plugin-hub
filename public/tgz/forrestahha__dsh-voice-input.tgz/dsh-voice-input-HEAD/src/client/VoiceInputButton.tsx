import { useEffect, useRef, useState, type CSSProperties, type ReactElement } from 'react'
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import {
  appendTranscript,
  recognitionConstructor,
  recognitionError,
  recognitionLanguage,
  transcriptFromResults,
  type SpeechRecognitionLike,
} from './speech.ts'

/** Complete runtime props supplied by the conversation.input.right slot. */
export type VoiceInputButtonProps = PropsRuntime<'conversation.input.right'>

type Status = 'idle' | 'listening' | 'stopping' | 'error'

const buttonStyle: CSSProperties = {
  alignItems: 'center',
  background: 'transparent',
  border: 0,
  borderRadius: 999,
  color: 'var(--dsw-alias-label-tertiary)',
  cursor: 'pointer',
  display: 'inline-flex',
  height: 28,
  justifyContent: 'center',
  padding: 0,
  transition: 'background 120ms ease, color 120ms ease, transform 120ms ease',
  width: 28,
}

const activeStyle: CSSProperties = {
  background: 'var(--dsw-alias-state-error-tertiary, rgba(239, 68, 68, 0.14))',
  color: 'var(--dsw-alias-state-error-primary, #dc2626)',
  transform: 'scale(1.05)',
}

const disabledStyle: CSSProperties = {
  cursor: 'not-allowed',
  opacity: 0.4,
}

/** Microphone glyph kept inline so the plugin has no runtime UI-package dependency. */
function MicrophoneIcon({ active }: { active: boolean }): ReactElement {
  return (
    <svg aria-hidden="true" fill="none" height="17" viewBox="0 0 24 24" width="17">
      <rect
        fill={active ? 'currentColor' : 'none'}
        height="11"
        rx="4"
        stroke="currentColor"
        strokeWidth="1.8"
        width="7"
        x="8.5"
        y="2.5"
      />
      <path d="M5.5 10.5a6.5 6.5 0 0 0 13 0M12 17v4M8.5 21h7" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
    </svg>
  )
}

/** Composer microphone control backed by the browser's Web Speech API. */
export function VoiceInputButton({ input, inputActions }: VoiceInputButtonProps): ReactElement {
  const [status, setStatus] = useState<Status>('idle')
  const [error, setError] = useState<string | null>(null)
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null)
  const baselineRef = useRef('')
  const actionsRef = useRef(inputActions)
  actionsRef.current = inputActions

  const browserLanguage = typeof navigator === 'undefined' ? 'zh-CN' : recognitionLanguage(navigator.language)
  const chinese = browserLanguage.toLowerCase().startsWith('zh')
  const Constructor = typeof window === 'undefined' ? undefined : recognitionConstructor(window)
  const supported = Constructor !== undefined
  const locked = input.phase !== 'plain'
  const active = status === 'listening' || status === 'stopping'

  useEffect(() => () => {
    const recognition = recognitionRef.current
    recognitionRef.current = null
    recognition?.abort()
  }, [])

  const begin = (): void => {
    if (Constructor === undefined || locked) return

    const recognition = new Constructor()
    baselineRef.current = input.draft
    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = browserLanguage
    recognition.maxAlternatives = 1
    recognition.onstart = () => {
      setError(null)
      setStatus('listening')
    }
    recognition.onresult = (event) => {
      const transcript = transcriptFromResults(event.results)
      actionsRef.current.setDraft(appendTranscript(baselineRef.current, transcript))
    }
    recognition.onerror = (event) => {
      setError(recognitionError(event.error, chinese))
      setStatus('error')
    }
    recognition.onend = () => {
      if (recognitionRef.current === recognition) recognitionRef.current = null
      setStatus(current => current === 'error' ? current : 'idle')
    }
    recognitionRef.current = recognition

    try {
      recognition.start()
    } catch (reason) {
      recognitionRef.current = null
      const message = reason instanceof Error ? reason.message : String(reason)
      setError(chinese ? `无法启动语音识别：${message}` : `Could not start speech recognition: ${message}`)
      setStatus('error')
    }
  }

  const stop = (): void => {
    const recognition = recognitionRef.current
    if (recognition === null) return
    setStatus('stopping')
    recognition.stop()
  }

  const unsupported = chinese ? '当前浏览器不支持语音输入' : 'Voice input is not supported by this browser'
  const idle = chinese ? '开始语音输入' : 'Start voice input'
  const listening = chinese ? '停止语音输入' : 'Stop voice input'
  const label = !supported ? unsupported : error ?? (active ? listening : idle)
  const disabled = !supported || locked

  return (
    <button
      aria-label={label}
      aria-pressed={active}
      disabled={disabled}
      onClick={active ? stop : begin}
      onPointerEnter={(event) => {
        if (!disabled && !active) event.currentTarget.style.background = 'var(--dsw-alias-interactive-bg-hover)'
      }}
      onPointerLeave={(event) => {
        if (!active) event.currentTarget.style.background = 'transparent'
      }}
      style={{ ...buttonStyle, ...(active ? activeStyle : {}), ...(disabled ? disabledStyle : {}) }}
      title={label}
      type="button"
    >
      <MicrophoneIcon active={active} />
    </button>
  )
}
