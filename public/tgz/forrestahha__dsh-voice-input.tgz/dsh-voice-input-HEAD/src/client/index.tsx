import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { VoiceInputButton } from './VoiceInputButton.tsx'

/** Required client service. */
export const inject = ['slots']

/** Register the microphone immediately before the composer send button. */
export function apply(ctx: ClientContext): void {
  ctx.slots.inject('conversation.input.right', () => ctx.slots.register({
    name: 'conversation.input.right',
    id: 'voice-input',
    order: 10,
  }, VoiceInputButton))
}
