/**
 * Host half of the voice-input UI plugin. The browser implementation is
 * discovered through package.json's dsh.client declaration.
 */
export function apply(): void {}
