/** Minimal Web Speech API contract used by the plugin and its test doubles. */
export interface SpeechRecognitionAlternativeLike {
    readonly transcript: string;
}
/** One recognition result with its preferred alternative at index zero. */
export interface SpeechRecognitionResultLike {
    readonly 0: SpeechRecognitionAlternativeLike;
    readonly isFinal: boolean;
    readonly length: number;
}
/** Array-like collection returned by a recognition event. */
export interface SpeechRecognitionResultListLike {
    readonly length: number;
    readonly [index: number]: SpeechRecognitionResultLike;
}
/** Recognition event fields consumed by the plugin. */
export interface SpeechRecognitionEventLike {
    readonly results: SpeechRecognitionResultListLike;
}
/** Recognition error fields consumed by the plugin. */
export interface SpeechRecognitionErrorEventLike {
    readonly error: string;
    readonly message?: string;
}
/** Browser recognition instance used by the React control. */
export interface SpeechRecognitionLike {
    continuous: boolean;
    interimResults: boolean;
    lang: string;
    maxAlternatives: number;
    onend: (() => void) | null;
    onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
    onresult: ((event: SpeechRecognitionEventLike) => void) | null;
    onstart: (() => void) | null;
    abort(): void;
    start(): void;
    stop(): void;
}
/** Constructor exposed by browsers implementing the Web Speech API. */
export type SpeechRecognitionConstructor = new () => SpeechRecognitionLike;
/** Resolve the standard or WebKit-prefixed recognition constructor. */
export declare function recognitionConstructor(value: unknown): SpeechRecognitionConstructor | undefined;
/** Choose a BCP-47 recognition language from the current browser. */
export declare function recognitionLanguage(language: string | undefined): string;
/** Join recognized speech to an existing draft without forcing spaces around CJK. */
export declare function appendTranscript(draft: string, transcript: string): string;
/** Flatten the preferred alternative from all current recognition results. */
export declare function transcriptFromResults(results: SpeechRecognitionResultListLike): string;
/** Map browser error codes to concise user-facing copy. */
export declare function recognitionError(error: string, chinese: boolean): string;
//# sourceMappingURL=speech.d.ts.map