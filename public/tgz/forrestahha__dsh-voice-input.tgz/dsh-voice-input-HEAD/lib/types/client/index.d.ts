import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required client service. */
export declare const inject: string[];
/** Register the microphone immediately before the composer send button. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map