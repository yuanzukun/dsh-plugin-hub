import { type ReactElement } from 'react';
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Complete runtime props supplied by the conversation.input.right slot. */
export type VoiceInputButtonProps = PropsRuntime<'conversation.input.right'>;
/** Composer microphone control backed by the browser's Web Speech API. */
export declare function VoiceInputButton({ input, inputActions }: VoiceInputButtonProps): ReactElement;
//# sourceMappingURL=VoiceInputButton.d.ts.map