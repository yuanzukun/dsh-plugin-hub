/**
 * Host half of the voice-input UI plugin. The browser implementation is
 * discovered through package.json's dsh.client declaration.
 */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map