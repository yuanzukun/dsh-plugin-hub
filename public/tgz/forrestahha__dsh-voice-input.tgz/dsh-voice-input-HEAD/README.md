# dsh-voice-input

English | [简体中文](README.zh-CN.md)

Voice-to-text input for the [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) Web UI.

The plugin adds a microphone button immediately before the composer send button. It uses the browser's Web Speech API, streams recognition results into the current draft, and never submits the message automatically.

## Features

- Adds to the official `conversation.input.right` extension slot.
- Supports standard and WebKit-prefixed SpeechRecognition implementations.
- Uses the browser language, falling back to `zh-CN`.
- Preserves natural spacing for Chinese, Japanese, Korean, and Latin text.
- Stops recording when clicked again and aborts when the component unloads.
- Requires no additional API key or host-side service.

## Install

Install directly from GitHub into the Web profile:

```sh
dsh plugin --profile web add github:forrestahha/dsh-voice-input
dsh web
```

For a pinned installation:

```sh
dsh plugin --profile web add github:forrestahha/dsh-voice-input#v0.1.1
```

Open the Web UI, select a workspace, and click the microphone button. The browser asks for microphone access on first use.

## Browser support

The plugin requires `SpeechRecognition` or `webkitSpeechRecognition`. Chromium-based browsers provide the broadest support. Unsupported browsers show a disabled microphone button instead of failing at startup.

`localhost` is treated as a secure context by modern browsers. If Harness is served from another machine, use HTTPS or the browser may refuse microphone access.

## Privacy

The plugin does not store audio and does not add its own network calls. The Web Speech API implementation is controlled by the browser and may send audio to the browser vendor's speech service. Review your browser's privacy policy before recording sensitive material.

## Development

Requirements: Node.js `^22.19.0 || >=24.0.0` and pnpm 11.

```sh
pnpm install
pnpm check
```

Install a local checkout for integration testing:

```sh
dsh plugin --profile web add /absolute/path/to/dsh-voice-input
dsh web
```

## Design

The npm package is both a Harness bundle and a client plugin:

- `cordis.patch.yml` inserts the package into the selected profile.
- The Node entry is intentionally empty; `dsh.client` discovers `./client`.
- The browser entry registers `VoiceInputButton` in `conversation.input.right`.
- Harness supplies the current input state and `inputActions.setDraft()` through slot props.

No agent-loop, model, session-log, or Host API behavior is changed.

## License

MIT
