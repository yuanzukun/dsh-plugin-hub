const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('whaleDesktop', {
  onConfig(callback) {
    ipcRenderer.on('whale:config', (_event, snapshot) => callback(snapshot))
  },
  onKey(callback) {
    ipcRenderer.on('whale:key', (_event, payload) => callback(payload))
  },
  onBlur(callback) {
    ipcRenderer.on('whale:blur', () => callback())
  },
  onReleaseAll(callback) {
    ipcRenderer.on('whale:release-all', () => callback())
  },
  onGlobalKeys(callback) {
    ipcRenderer.on('whale:global-keys', () => callback())
  },
  onWindows(callback) {
    ipcRenderer.on('whale:windows', (_event, list) => callback(list))
  },
  onDisplay(callback) {
    ipcRenderer.on('whale:display', (_event, info) => callback(info))
  },
  onDisplaySwitch(callback) {
    ipcRenderer.on('whale:display-switch', (_event, payload) => callback(payload))
  },
  onRecall(callback) {
    ipcRenderer.on('whale:recall', () => callback())
  },
  onReturnClient(callback) {
    ipcRenderer.on('whale:return-client', () => callback())
  },
  requestDisplay(payload) {
    ipcRenderer.send('whale:request-display', payload || {})
  },
  setSnapTarget(payload) {
    ipcRenderer.send('whale:snap-window', payload || null)
  },
  onInputAnchor(callback) {
    ipcRenderer.on('whale:input-anchor', (_event, anchor) => callback(anchor))
  },
  requestInputAnchor() {
    ipcRenderer.send('whale:request-anchor')
  },
  onMouseFollow(callback) {
    ipcRenderer.on('whale:mouse-follow', (_event, payload) => callback(payload))
  },
  ready() {
    ipcRenderer.send('whale:ready')
  },
  rendererMounted() {
    ipcRenderer.send('whale:renderer-mounted')
  },
  sendConfig(snapshot) {
    ipcRenderer.send('whale:config', snapshot)
  },
  stopDesktop(snapshot) {
    ipcRenderer.send('whale:stop', snapshot || null)
  },
  setInteractive(interactive) {
    ipcRenderer.send('whale:interactive', Boolean(interactive))
  },
})
