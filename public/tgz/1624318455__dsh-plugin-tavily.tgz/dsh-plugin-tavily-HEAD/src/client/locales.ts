/** Locale bundles for the Tavily plugin card. */

/**
 * Locale keys the Tavily card renders. The namespace is merged into the
 * framework's {@link LocaleNamespaceMap} below so the renderer's typed `t`
 * seat accepts exactly these keys (plus the shared common vocabulary).
 */
export type TavilyCardLocaleKey =
  | 'tavilyTitle' | 'tavilyDescription'
  | 'tavilyApiKey' | 'tavilyApiKeyHint' | 'tavilyApiKeySet' | 'tavilyApiKeyUnset'
  | 'tavilyBaseUrl' | 'tavilyBaseUrlHint'
  | 'tavilyMaxResults' | 'tavilyMaxResultsHint'
  | 'tavilySearchDepth' | 'tavilySearchDepthHint'
  | 'tavilyTopic' | 'tavilyTopicHint'
  | 'tavilyIncludeAnswer' | 'tavilyIncludeAnswerHint'
  | 'tavilyIncludeRawContent' | 'tavilyIncludeRawContentHint'
  | 'tavilyTimeout' | 'tavilyTimeoutHint'
  | 'tavilyDays' | 'tavilyDaysHint'
  | 'tavilyEngine' | 'tavilyEngineHint' | 'engineTavily' | 'engineDeepseek'
  | 'tavilyCiteFormat' | 'tavilyCiteFormatHint' | 'citeFormatPlain' | 'citeFormatFootnote'
  | 'tavilyFallbackEngine' | 'tavilyFallbackEngineHint' | 'fallbackNone' | 'fallbackDeepseek'
  | 'wiringTitle' | 'wiringHint'
  | 'advancedTitle'
  | 'searchDepthBasic' | 'searchDepthAdvanced' | 'searchDepthFast' | 'searchDepthUltraFast'
  | 'topicGeneral' | 'topicNews' | 'topicFinance'
  | 'tavilyRetryMaxAttempts' | 'tavilyRetryMaxAttemptsHint'
  | 'tavilyCacheTtl' | 'tavilyCacheTtlHint'
  | 'tavilyCacheMaxEntries' | 'tavilyCacheMaxEntriesHint'
  | 'tavilyCacheBypassFresh' | 'tavilyCacheBypassFreshHint'
  | 'tavilyDebug' | 'tavilyDebugHint'
  | 'tavilyChunksPerSource' | 'tavilyChunksPerSourceHint'
  | 'tavilyTimeRange' | 'tavilyTimeRangeHint'
  | 'tavilyStartDate' | 'tavilyStartDateHint'
  | 'tavilyEndDate' | 'tavilyEndDateHint'
  | 'tavilyIncludeImages' | 'tavilyIncludeImagesHint'
  | 'tavilyIncludeImageDescriptions' | 'tavilyIncludeImageDescriptionsHint'
  | 'tavilyIncludeFavicon' | 'tavilyIncludeFaviconHint'
  | 'tavilyIncludeDomains' | 'tavilyIncludeDomainsHint'
  | 'tavilyExcludeDomains' | 'tavilyExcludeDomainsHint'
  | 'tavilyCountry' | 'tavilyCountryHint'
  | 'includeAnswerRecommended' | 'includeAnswerTrue' | 'includeAnswerAdvanced' | 'includeAnswerFalse'
  | 'rawContentFalse' | 'rawContentMarkdown' | 'rawContentText'
  | 'testApi' | 'testingApi' | 'testApiHint' | 'testApiNeedKey' | 'testApiKeyConfiguredNeedReentry' | 'testApiSuccess' | 'testApiFailed'
  | 'usageEstimateLabel' | 'usageEstimateCredits' | 'checkUsage' | 'checkingUsage' | 'checkUsageHint'
  | 'usageResultLabel' | 'usageResultOf' | 'usageResultSearch' | 'usageUnlimited' | 'usageFailed'
  | 'errorInvalidKey' | 'errorInsufficientCredits' | 'errorRateLimited'
  | 'errorServerDown' | 'errorTimeout' | 'errorNetwork' | 'errorHttp' | 'errorOther'
  | 'presetLabel' | 'presetPlaceholder' | 'presetHint'
  | 'presetDeepResearch' | 'presetQuickSummary' | 'presetNewsLive'
  | 'statusIdle' | 'statusChecking' | 'statusCheckingShort' | 'statusOk' | 'statusLow'
  | 'statusError' | 'statusNoKey' | 'statusRefresh' | 'statusHint'
  | 'statusRemaining' | 'statusOf' | 'statusFailed'
  | 'overridden' | 'configCovered' | 'reset' | 'readOnly' | 'expand' | 'collapse'
  | 'save' | 'saving' | 'discard' | 'unsaved' | 'saveFailed' | 'invalidNumber' | 'invalidList'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Tavily plugin card copy (the `web-search-tavily` settings namespace). */
    'settings.plugins.tavily': TavilyCardLocaleKey
  }
}

/** English copy. */
export const en: Record<TavilyCardLocaleKey, string> = {
  tavilyTitle: 'Web search (Tavily)',
  tavilyDescription: 'The Tavily search provider.',
  tavilyApiKey: 'API key',
  tavilyApiKeyHint: 'Stored outside the settings file. Leave blank to keep the current key.',
  tavilyApiKeySet: 'A key is configured.',
  tavilyApiKeyUnset: 'No key is configured; search is unavailable until one is.',
  tavilyBaseUrl: 'API Base URL',
  tavilyBaseUrlHint: 'Custom proxy/endpoint base; leave blank for https://api.tavily.com.',
  tavilyMaxResults: 'Max results',
  tavilyMaxResultsHint: 'Number of web results per search (1–20); blank uses 5.',
  tavilySearchDepth: 'Search depth',
  tavilySearchDepthHint: 'basic is fast/cheap; advanced performs deeper retrieval and costs more tokens.',
  tavilyTopic: 'Topic',
  tavilyTopicHint: 'general is the whole web; news prioritizes recency; finance targets market content.',
  tavilyIncludeAnswer: 'Generated answer',
  tavilyIncludeAnswerHint: 'Ask Tavily to generate an answer returned to the agent: quick (true/basic) or detailed (advanced).',
  tavilyIncludeRawContent: 'Raw page content',
  tavilyIncludeRawContentHint: 'Include cleaned page content in each result; format markdown/text. Greatly increases context token usage.',
  tavilyTimeout: 'Request timeout (ms)',
  tavilyTimeoutHint: 'Milliseconds before a search request is abandoned; blank uses 30000.',
  tavilyDays: 'Recency window (days)',
  tavilyDaysHint: 'Only results from the last N days; leave blank to disable.',
  tavilyEngine: 'Web search engine',
  tavilyEngineHint: 'Which provider answers web_search. Tavily (default): this plugin, keyless if no key. DeepSeek: the official DeepSeek search — switch back without uninstalling. This plugin is already elected as the web_search provider, so this toggle actually changes the engine (no manual yaml needed).',
  engineTavily: 'Tavily (default)',
  engineDeepseek: 'Official DeepSeek',
  tavilyCiteFormat: 'Citation format',
  tavilyCiteFormatHint: 'plain: Tavily’s generated answer alone. footnote: appends a numbered source block ([1] title — url…) so the model can cite by number.',
  citeFormatPlain: 'plain (answer only)',
  citeFormatFootnote: 'footnote (numbered sources)',
  tavilyFallbackEngine: 'Fallback engine',
  tavilyFallbackEngineHint: 'When Tavily fails with a service-side problem (timeout / network / 5xx), answer via the official DeepSeek search as a last resort. Key-level faults (429/401) never trigger it.',
  fallbackNone: 'none (default)',
  fallbackDeepseek: 'DeepSeek (automatic)',
  wiringTitle: 'Tavily is already selected as the web_search provider',
  wiringHint: 'Installing this plugin elects Tavily automatically (web.searchProvider: tavily), so web_search answers through Tavily out of the box. The “Web search engine” switch above then picks Tavily or the official DeepSeek provider. The snippet below is optional — only needed if you later override the provider in yaml by hand.',
  tavilyRetryMaxAttempts: 'Rate-limit retries',
  tavilyRetryMaxAttemptsHint: 'Extra attempts after a 429 response (0–5); waits honor retry-after with a bounded backoff.',
  tavilyCacheTtl: 'Cache TTL (seconds)',
  tavilyCacheTtlHint: 'Cache identical searches to save credits; 0 disables (0–3600).',
  tavilyCacheMaxEntries: 'Cache max entries',
  tavilyCacheMaxEntriesHint: 'Maximum cached searches (LRU cap); the oldest entry evicts past this (1–10000, default 200).',
  tavilyCacheBypassFresh: 'Skip cache for fresh queries',
  tavilyCacheBypassFreshHint: 'Do not cache news/finance searches or searches with a time window, so a “right now” question never gets a stale snapshot.',
  tavilyDebug: 'Debug logging',
  tavilyDebugHint: 'Log one concise line per search/extract (query excerpt, credits, cache state, duration, errors). Never logs keys or raw responses.',
  advancedTitle: '🔧 Advanced Tavily request parameters',
  searchDepthBasic: 'basic (balanced)',
  searchDepthAdvanced: 'advanced (deep, 2 credits)',
  searchDepthFast: 'fast (1 credit)',
  searchDepthUltraFast: 'ultra-fast (1 credit, lowest latency)',
  topicGeneral: 'general',
  topicNews: 'news',
  topicFinance: 'finance',
  tavilyChunksPerSource: 'Chunks per source',
  tavilyChunksPerSourceHint: 'Snippet chunks per source (1–3); larger is richer but uses more tokens.',
  tavilyTimeRange: 'Time range',
  tavilyTimeRangeHint: 'Recency preset (news/finance topics); e.g. day, week, month, year.',
  tavilyStartDate: 'Start date',
  tavilyStartDateHint: 'Include only results published/updated after this date (YYYY-MM-DD).',
  tavilyEndDate: 'End date',
  tavilyEndDateHint: 'Include only results published/updated before this date (YYYY-MM-DD).',
  tavilyIncludeImages: 'Include images',
  tavilyIncludeImagesHint: 'Collect query-related and per-source images. Note: the current seam does not yet surface images in results.',
  tavilyIncludeImageDescriptions: 'Image descriptions',
  tavilyIncludeImageDescriptionsHint: 'With “Include images”, add a description per image.',
  tavilyIncludeFavicon: 'Include favicon',
  tavilyIncludeFaviconHint: 'Request the favicon URL per result. Note: the current seam does not yet surface favicons in results.',
  tavilyIncludeDomains: 'Include domains',
  tavilyIncludeDomainsHint: 'Only these domains (comma/space separated), e.g. example.com, docs.example.org.',
  tavilyExcludeDomains: 'Exclude domains',
  tavilyExcludeDomainsHint: 'Skip these domains (comma/space separated), e.g. spam.com.',
  tavilyCountry: 'Country boost',
  tavilyCountryHint: 'Boost results from one country (general topic), e.g. japan, united-states.',
  includeAnswerRecommended: 'true (quick)',
  includeAnswerTrue: 'true (quick)',
  includeAnswerAdvanced: 'advanced (detailed)',
  includeAnswerFalse: 'false (none)',
  rawContentFalse: 'false (off)',
  rawContentMarkdown: 'true / markdown',
  rawContentText: 'text',
  testApi: 'Test API connection',
  testingApi: 'Testing…',
  testApiHint: 'Testing consumes one Tavily search credit.',
  testApiNeedKey: 'Enter an API key in the field above to test.',
  testApiKeyConfiguredNeedReentry: 'A key is configured, but browsers cannot read stored secrets. Re-enter the key above once to test it (it will not be saved again).',
  testApiSuccess: 'Connection successful — Tavily accepted the request.',
  testApiFailed: 'Connection failed:',
  usageEstimateLabel: 'Estimated cost for one search: ',
  usageEstimateCredits: 'credit(s),',
  checkUsage: 'Check usage',
  checkingUsage: 'Checking…',
  checkUsageHint: 'Checks current credit usage; like testing, a stored key must be re-entered once.',
  usageResultLabel: 'Usage: ',
  usageResultOf: ' / ',
  usageResultSearch: ' · ',
  usageUnlimited: 'unlimited',
  usageFailed: 'Usage check failed:',
  errorInvalidKey: 'Invalid API key — check the key, or create a new one on the Tavily dashboard.',
  errorInsufficientCredits: 'Insufficient credits — top up on the Tavily dashboard, or clear the key to run keyless.',
  errorRateLimited: 'Rate limited — wait a moment and retry; repeating 429s mean requests are too frequent.',
  errorServerDown: 'Tavily service error — wait and retry; if it persists, the service may be down.',
  errorTimeout: 'Request timed out — check the base URL or raise the request timeout.',
  errorNetwork: 'Network error — check the base URL and your connection to Tavily.',
  errorHttp: 'Tavily returned an unexpected HTTP error.',
  errorOther: 'Unexpected failure.',
  presetLabel: 'Parameter preset',
  presetPlaceholder: 'Choose a template…',
  presetHint: 'One click stages several advanced parameters (config-covered fields are left alone); press Save to apply.',
  presetDeepResearch: 'Deep research',
  presetQuickSummary: 'Quick summary',
  presetNewsLive: 'Live news',
  statusIdle: 'Status not checked',
  statusChecking: 'Checking status…',
  statusCheckingShort: 'Checking…',
  statusOk: '✓ Tavily ready',
  statusLow: '⚠ Credits low',
  statusError: '✗ API error',
  statusNoKey: 'No API key configured',
  statusRefresh: 'Refresh',
  statusHint: 'Shows the stored key’s credit/connectivity status (host-checked, no search credit cost).',
  statusRemaining: 'Remaining: ',
  statusOf: ' / ',
  statusFailed: 'Status check failed:',
  overridden: 'Overridden',
  configCovered: 'Covered by config file; edit the yaml to change.',
  reset: 'Reset to default',
  readOnly: 'This deployment stores settings read-only.',
  expand: 'Show settings',
  collapse: 'Hide settings',
  save: 'Save',
  saving: 'Saving…',
  discard: 'Discard',
  unsaved: 'Unsaved',
  saveFailed: 'The deployment did not accept these values; they were left for you to correct.',
  invalidNumber: 'Enter a valid number, or leave blank to use the default.',
  invalidList: 'One or more values are not accepted; separate entries with commas or spaces.',
}

/** Simplified Chinese copy. */
export const zh: Record<TavilyCardLocaleKey, string> = {
  tavilyTitle: '网页搜索（Tavily）',
  tavilyDescription: 'Tavily 搜索提供方。',
  tavilyApiKey: 'API Key',
  tavilyApiKeyHint: '不写入设置文件。留空表示保持当前密钥。',
  tavilyApiKeySet: '已配置密钥。',
  tavilyApiKeyUnset: '未配置密钥；配置之前搜索不可用。',
  tavilyBaseUrl: 'API Base URL',
  tavilyBaseUrlHint: '自定义代理/接口地址；留空使用 https://api.tavily.com。',
  tavilyMaxResults: '最大结果数',
  tavilyMaxResultsHint: '单次搜索返回的网页结果数量（1–20）；留空使用 5。',
  tavilySearchDepth: '搜索深度',
  tavilySearchDepthHint: 'basic 均衡；advanced 深度（2 积分）；fast/ultra-fast 更低延迟（1 积分）。',
  tavilyTopic: '搜索主题',
  tavilyTopicHint: 'general 通用搜索；news 新闻时效；finance 财经内容。',
  tavilyIncludeAnswer: '生成摘要答案',
  tavilyIncludeAnswerHint: '让 Tavily 直接生成摘要答案返回给 Agent：快速（true/basic）或详细（advanced）。',
  tavilyIncludeRawContent: '返回网页原始内容',
  tavilyIncludeRawContentHint: '返回网页清洗后的内容，格式 markdown/text；开启会大幅增加上下文 token 消耗。',
  tavilyTimeout: '请求超时（毫秒）',
  tavilyTimeoutHint: '搜索请求超时毫秒数；留空使用 30000。',
  tavilyDays: '时间窗口（天）',
  tavilyDaysHint: '只返回最近 N 天的结果；留空表示不限制。',
  tavilyEngine: '网页搜索引擎',
  tavilyEngineHint: '决定 web_search 由谁应答。Tavily（默认）：本插件，无 Key 走 keyless；DeepSeek：官方 DeepSeek——无需卸载即可切回。本插件已被自动选为 web_search 提供方，因此该开关真正切换引擎（不需要手动改 yaml）。',
  engineTavily: 'Tavily（默认）',
  engineDeepseek: '官方 DeepSeek',
  tavilyCiteFormat: '引用格式',
  tavilyCiteFormatHint: 'plain：仅返回 Tavily 生成摘要。footnote：追加编号来源块（[1] 标题 — url…），方便模型按编号引用。',
  citeFormatPlain: 'plain（仅摘要）',
  citeFormatFootnote: 'footnote（编号来源）',
  tavilyFallbackEngine: '兜底引擎',
  tavilyFallbackEngineHint: '当 Tavily 出现服务侧故障（超时/网络/5xx）时，自动改由官方 DeepSeek 搜索应答。Key 级故障（429/401）不触发兜底。',
  fallbackNone: 'none（默认）',
  fallbackDeepseek: 'DeepSeek（自动兜底）',
  wiringTitle: 'Tavily 已被自动选为 web_search 提供方',
  wiringHint: '安装本插件会自动选举 Tavily（web.searchProvider: tavily），因此 web_search 开箱即用 Tavily。上方「网页搜索引擎」开关可切换 Tavily 或官方 DeepSeek。下方片段为可选——仅在日后想手动在 yaml 覆盖提供方时使用。',
  tavilyRetryMaxAttempts: '限流重试次数',
  tavilyRetryMaxAttemptsHint: '收到 429 后的额外重试次数（0–5）；等待会遵循 retry-after 并做有界退避。',
  tavilyCacheTtl: '缓存时长（秒）',
  tavilyCacheTtlHint: '缓存相同的查询以节省额度；0 表示关闭（0–3600）。',
  tavilyCacheMaxEntries: '缓存条目上限',
  tavilyCacheMaxEntriesHint: '最多缓存的搜索条数（LRU 上限）；超出后淘汰最旧条目（1–10000，默认 200）。',
  tavilyCacheBypassFresh: '时效性查询跳过缓存',
  tavilyCacheBypassFreshHint: '不缓存 news/finance 主题或带时间窗口的搜索，保证“当前”问题不会命中陈旧快照。',
  tavilyDebug: '调试日志',
  tavilyDebugHint: '每次搜索/抓取输出一行精简日志（查询节选、积分、缓存命中、耗时、错误）。绝不记录密钥或原始响应。',
  advancedTitle: '🔧 高级 Tavily 请求参数',
  searchDepthBasic: 'basic（均衡）',
  searchDepthAdvanced: 'advanced（深度，2 积分）',
  searchDepthFast: 'fast（1 积分）',
  searchDepthUltraFast: 'ultra-fast（1 积分，最低延迟）',
  topicGeneral: 'general',
  topicNews: 'news',
  topicFinance: 'finance',
  tavilyChunksPerSource: '每个来源的片段数',
  tavilyChunksPerSourceHint: '每个来源返回的相关片段数（1–3）；越大越丰富但更耗 token。',
  tavilyTimeRange: '时间范围',
  tavilyTimeRangeHint: '时效预设（news/finance 主题），如 day、week、month、year。',
  tavilyStartDate: '开始日期',
  tavilyStartDateHint: '只返回该日期（YYYY-MM-DD）之后发布/更新的结果。',
  tavilyEndDate: '结束日期',
  tavilyEndDateHint: '只返回该日期（YYYY-MM-DD）之前发布/更新的结果。',
  tavilyIncludeImages: '包含图片',
  tavilyIncludeImagesHint: '收集与查询相关及每个来源的图片。注：当前 seam 尚未在结果中暴露图片。',
  tavilyIncludeImageDescriptions: '图片描述',
  tavilyIncludeImageDescriptionsHint: '开启“包含图片”后，为每张图片附带描述。',
  tavilyIncludeFavicon: '包含网站图标',
  tavilyIncludeFaviconHint: '请求每个结果的 favicon URL。注：当前 seam 尚未在结果中暴露 favicon。',
  tavilyIncludeDomains: '包含域名',
  tavilyIncludeDomainsHint: '只返回这些域名（逗号/空格分隔），如 example.com, docs.example.org。',
  tavilyExcludeDomains: '排除域名',
  tavilyExcludeDomainsHint: '排除这些域名（逗号/空格分隔），如 spam.com。',
  tavilyCountry: '国家加权',
  tavilyCountryHint: '偏向某一国家的结果（general 主题），如 japan、united-states。',
  includeAnswerRecommended: 'true（快速）',
  includeAnswerTrue: 'true（快速）',
  includeAnswerAdvanced: 'advanced（详细）',
  includeAnswerFalse: 'false（不生成）',
  rawContentFalse: 'false（关闭）',
  rawContentMarkdown: 'true / markdown',
  rawContentText: 'text',
  testApi: '测试API连接',
  testingApi: '测试中…',
  testApiHint: '测试会消耗一次Tavily搜索额度。',
  testApiNeedKey: '请在上方输入 API Key 后再测试。',
  testApiKeyConfiguredNeedReentry: '已检测到配置了密钥，但浏览器出于安全设计无法读取已保存的密钥；请在上方重新输入一次密钥来完成测试（不会重复保存）。',
  testApiSuccess: '连接成功 —— Tavily 已接受请求。',
  testApiFailed: '连接失败：',
  usageEstimateLabel: '单次搜索预估成本：',
  usageEstimateCredits: '积分，',
  checkUsage: '检查用量',
  checkingUsage: '检查中…',
  checkUsageHint: '检查当前额度使用情况；与测试一样，已保存的密钥需重新输入一次。',
  usageResultLabel: '用量：',
  usageResultOf: ' / ',
  usageResultSearch: ' · ',
  usageUnlimited: '不限',
  usageFailed: '用量检查失败：',
  errorInvalidKey: 'API Key 无效——请检查密钥，或在 Tavily 控制台重新创建。',
  errorInsufficientCredits: '额度不足——请在 Tavily 控制台充值，或清空 Key 使用 keyless 模式。',
  errorRateLimited: '请求被限流——请稍候重试；频繁 429 说明请求过于密集。',
  errorServerDown: 'Tavily 服务异常——请稍后重试；若持续失败可能是服务故障。',
  errorTimeout: '请求超时——请检查 Base URL 或调大请求超时时间。',
  errorNetwork: '网络错误——请检查 Base URL 及与 Tavily 的连接。',
  errorHttp: 'Tavily 返回了意外的 HTTP 错误。',
  errorOther: '未知错误。',
  presetLabel: '参数预设',
  presetPlaceholder: '选择一个模板…',
  presetHint: '一键暂存多组高级参数（被配置文件覆盖的字段不动）；点击「保存」后生效。',
  presetDeepResearch: '深度研究',
  presetQuickSummary: '快速摘要',
  presetNewsLive: '新闻实时',
  statusIdle: '尚未检查状态',
  statusChecking: '正在检查状态…',
  statusCheckingShort: '检查中…',
  statusOk: '✓ Tavily 正常',
  statusLow: '⚠ 额度不足',
  statusError: '✗ API 错误',
  statusNoKey: '未配置 API Key',
  statusRefresh: '刷新',
  statusHint: '显示已保存密钥的额度/连接状态（由服务端检查，不消耗搜索额度）。',
  statusRemaining: '剩余：',
  statusOf: ' / ',
  statusFailed: '状态检查失败：',
  overridden: '已覆盖',
  configCovered: '该参数已被配置文件覆盖，请修改 yaml。',
  reset: '恢复默认',
  readOnly: '本部署的设置为只读。',
  expand: '展开设置',
  collapse: '收起设置',
  save: '保存',
  saving: '保存中…',
  discard: '放弃修改',
  unsaved: '未保存',
  saveFailed: '本部署没有接受这些值，已保留供你修改。',
  invalidNumber: '请填有效数字；留空表示使用默认值。',
  invalidList: '存在无法接受的项；请用逗号或空格分隔各条目。',
}