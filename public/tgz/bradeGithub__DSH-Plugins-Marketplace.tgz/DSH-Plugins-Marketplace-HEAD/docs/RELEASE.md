# 发布规范（Release Standards）

本文件定义本仓库的**版本号规则、Tag 命名、Release 正文结构与发布流程**。与 [CHANGELOG.md](CHANGELOG.md)（变更记录）、[CONTRIBUTING.md](CONTRIBUTING.md)（贡献流程）区分：本文件只回答「怎么发一个版本」。
执行规范见 [GIT_HOOKS.md](GIT_HOOKS.md)，代码规范见 [CODING_STANDARDS.md](CODING_STANDARDS.md)。

<!-- TOC -->
- [1. 版本号（SemVer）](#1-版本号semver)
- [2. Tag 命名](#2-tag-命名)
  - [2.1 维护者签名 key 管理（per-maintainer 信任根）](#21-维护者签名-key-管理per-maintainer-信任根)
- [3. Release 正文结构](#3-release-正文结构)
- [4. 发布流程](#4-发布流程)
<!-- /TOC -->

## 1. 版本号（SemVer）

格式 `major.minor.patch`，按 [semver.org](https://semver.org)：

| 变更类型 | 段位 | 示例 |
|---|---|---|
| 破坏性变更（接口/字段/状态不兼容） | 升 major | `2.0.0` |
| 新特性 / 架构重构 | 升 minor | `1.5.5` → `1.6.0` |
| 修复（无新特性） | 升 patch | `1.6.0` → `1.6.1` |

- 破坏性 HTTP payload 字段/状态变更必须升 major（见 [TESTING.md §5.5 响应契约](TESTING.md)），新增可选字段仍可留在 minor。
- 发布前确认 `package.json` 的 `version` 与最新 Tag 一致、并已升到目标版本。

## 2. Tag 命名

- 格式：`v` + SemVer（`v1.6.0`），**SSH 签名的 annotated tag**（`git tag -s`，非 `-a`）——自更新完整性锚依赖签名验证（客户端 `lib/allowed-signers.js` 信任根，namespace=`git`）。
- 签名私钥：维护者本机离线 release key（`~/.ssh/dsh-release-{1,2}`），首次签名前配置：
  ```bash
  git config gpg.format ssh
  git config user.signingkey ~/.ssh/dsh-release-1.pub
  git config tag.gpgSign true   # 之后 git tag vX.Y.Z -m ... 即自动签名
  ```
- 硬门控：`pre-push` hook（`scripts/hooks/pre-push`）拦截未通过验签的 `v*` tag 推送及 `v*` tag 删除；`tag-verify.yml` CI 在 tag 推送后服务端复核告警。本地可用 `node scripts/verify-tag.mjs vX.Y.Z` 预验。
- 私钥带密码时，先装进 ssh-agent 再签名（`scripts/dev/load-release-keys.{sh,ps1}`）：Windows 需先启用 `ssh-agent` 服务（`Set-Service ssh-agent -StartupType Automatic; Start-Service ssh-agent`）并把 `gpg.ssh.program` 指向系统 `ssh-keygen.exe`（Git 自带 msys 版够不到 Windows agent）；macOS 用 `ssh-add --apple-use-keychain` 一次即永久（Keychain 持久化）；Linux 交给桌面 keyring。每次开机/登录装载一次即可，agent 会话内任意进程签名免交互。
- Tag 主题短标题：`vX.Y.Z — <一句主题> / <English subtitle>`。
- 只给已合并进上游 main 的提交打 Tag，不打分支上未发布的中间态。

### 2.1 维护者签名 key 管理（per-maintainer 信任根）

`lib/allowed-signers.js` 的 `ALLOWED_SIGNERS` 按**维护者**建模（不按机器）：每行 = 一位可独立发版的人，`signedBy` 即署名归因。

| 场景 | 流程 |
|---|---|
| 新维护者获得发版权 | 对方本机 `ssh-keygen -t ed25519 -f ~/.ssh/dsh-release-<id>` → 把 `.pub` 整行经普通 PR 追加进 `ALLOWED_SIGNERS` → **下一个由任一已信 key 签名的 release 起生效**。此后独立 `git tag -s` 发版，无需他人再签——信任委托是一次性入职，不是每次发版 |
| key 失窃 / 维护者退出 | 把该 key 的 base64 blob 移入 `REVOKED_KEYS`（同 PR 可一并加替换 key），由另一把仍可信的 key 签名的 release 下发 |
| 多机/主备 | 同一人可持多行（如 `release-lu` / `release-lu-backup`）；私钥分散存放，任一生效 |

约束（不可削弱）：私钥永不入库、永不跨人共享；信任根只读已安装 bundle 的这份常量（远端同名文件概不采信）；新增/吊销的生效点恒为「已信 key 签名的 release」——这是防信任自传播的语义本身，不是流程负担。

## 3. Release 正文结构

按主题分段，**无内容的段落省略**。段落标题不带 emoji（仓库全局禁 emoji，GitHub Release 同样遵循）。

结构为：`#` 标题行 → 各 `##` 主题段（按 §1 顺序，空段省略）→ `## 更新方式 / How to update`。主题段：

| 段落 | 内容 |
|---|---|
| `## 新增 / New` | 新特性，一行一条，注明 PR/issue 编号 |
| `## 修复 / Fix` | 修复，注明触发场景与 issue/PR 编号 |
| `## 重构 / Refactor` | 无行为变化的内部/架构调整 |
| `## 安全 / Security` | 安全加固（如有 CWE/外部贡献者致谢） |
| `## 工程 / Engineering` | 测试/CI/构建/基础设施（无用户可见变更时合并到本段） |
| `## 质量门 / Quality gate` | coverage、mutation、property、smoke、browser/install E2E 当前通过数 |
| `## 更新方式 / How to update` | 市场设置页检查更新并重启 dsh web；或 dsh CLI 重装 |

- 每项一行精要，**技术规范优先**（机制、后果、验证），非散文。
- 条目与 CHANGELOG 对应版本段**同源**（同一份事实，不在两处手抄不同措辞——CHANGELOG 为第一事实源，Release 正文由它凝练）。
- 外部贡献致谢：明确注明 `@handle（组织/项目）` 与该 PR 编号。

## 4. 发布流程

1. 基于最新 `upstream/main` 建 `release/vX.Y.Z` 分支。
2. 升 `package.json` 版本；把 CHANGELOG「未发布」区标题改为 `## vX.Y.Z — <日期>（<主题> / <English>）`，内容下移定版。
3. 规范批次提交（version bump / CHANGELOG 各一个 commit，见 [CONTRIBUTING.md](CONTRIBUTING.md)），推到 fork，建 PR 合入上游。
4. 合并后打签名 tag：`git tag -s vX.Y.Z -m "<主题>"`（需 §2 的 gpg.format=ssh + signingkey 配置；未签名的 tag 会被 pre-push hook 拒绝），推上游。
5. `gh release create vX.Y.Z --notes "<正文>"`（正文按 §3 结构），标记为 Latest（若非旧版热修复）。
