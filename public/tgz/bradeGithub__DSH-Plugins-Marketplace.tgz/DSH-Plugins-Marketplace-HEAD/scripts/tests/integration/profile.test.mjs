// 目标 profile 配置（issue #184）行为测试：
// - setTargetProfile 白名单校验（非法名回退 web，不抛）
// - 路径注入拒绝：../ 等穿越段不得进入路径常量
// - readTargetProfile：config.json 缺失/非法/目录不存在 → 回退 web
// - profile 路由：GET 读当前值；POST 保存（非法名 400 / 不存在目录 400 / 合法 200）
// - 写操作鉴权：POST 需 isWriteAllowed（LAN 无 token → 403）
//
// 独立文件的原因：profile 路径常量是模块级 let（import 时按 DSH_HOME 计算），
// 且 setTargetProfile 会重算它们——必须独立进程隔离。

import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, rmSync, existsSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";

// 必须在 import lib 之前设置临时 DSH_HOME
// 启动器环境隔离：在桌面端里跑测试时进程会带 DSH_PROFILE=desktop / DSH_PROFILE_DIR=…，
// 会让「无配置回退 web」的断言随宿主机变化（本文件断言的是无启动器信息时的老环境行为）。
// 启动器识别本身的用例见文件末尾「启动器 profile 识别」段与 unit/desktop-adaptation.test.mjs。
delete process.env.DSH_PROFILE;
delete process.env.DSH_PROFILE_DIR;
process.env.DSH_HOME = mkdtempSync(join(tmpdir(), "dsh-profile-test-")).replace(/\\/g, "/");
const home = process.env.DSH_HOME;
const marketRoot = join(home, "marketplace");
mkdirSync(marketRoot, { recursive: true });
// 建 web + desktop 两个 profile（desktop 模拟 hermes 客户端场景）
mkdirSync(join(home, "profiles", "web"), { recursive: true });
mkdirSync(join(home, "profiles", "desktop"), { recursive: true });
const configFile = join(marketRoot, "config.json");

const lib = await import("../../../lib/index.js");
const profileDomain = await import("../../../lib/domain/profile.js");

let pass = 0, fail = 0;
function check(name, actual, expected) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) pass++; else fail++;
  console.log(`${ok ? "PASS" : "FAIL"} ${name}: got ${JSON.stringify(actual)}, want ${JSON.stringify(expected)}`);
}

// ---- profile domain 访问器与切换订阅 ----
check("profile 域默认 profile", profileDomain.profileName(), "web");
check("profileNodeModules 访问器与当前 profile 同步", profileDomain.profileNodeModules(), lib.getProfileNodeModules(), true);
check("profileDir 访问器指向当前 profile", profileDomain.profileDir(), join(home, "profiles", "web"));
check("profilePatchFile 访问器指向当前 profile", profileDomain.profilePatchFile(), join(home, "profiles", "web", "cordis.patch.yml"));
check("profilePackageFile 访问器指向当前 profile", profileDomain.profilePackageFile(), join(home, "profiles", "web", "package.json"));
let profileChanges = 0;
const unsubscribe = profileDomain.onProfileChange(() => { profileChanges++; });
check("profile 订阅返回取消函数", typeof unsubscribe, "function");
profileDomain.setTargetProfile("desktop");
check("profile 域切换后访问器更新", profileDomain.profileNodeModules().includes(join("profiles", "desktop", "node_modules")), true);
check("profileDir 随切换更新", profileDomain.profileDir().includes(join("profiles", "desktop")), true);
check("profilePatchFile 随切换更新", profileDomain.profilePatchFile().includes(join("profiles", "desktop", "cordis.patch.yml")), true);
check("profilePackageFile 随切换更新", profileDomain.profilePackageFile().includes(join("profiles", "desktop", "package.json")), true);
profileDomain.setTargetProfile("desktop");
check("同 profile 设置仍触发订阅", profileChanges, 2);
unsubscribe();
profileDomain.setTargetProfile("web");
check("取消订阅后不再通知", profileChanges, 2);

// ---- setTargetProfile 白名单 ----
check("setTargetProfile 合法名生效", lib.setTargetProfile("desktop"), "desktop");
// 路径常量已重算（desktop）——Windows 分隔符兼容
check("setTargetProfile 后 PROFILE_NM 指向 desktop", lib.getProfileNodeModules().includes(join("profiles", "desktop", "node_modules")), true);
check("setTargetProfile 非法名回退 web", lib.setTargetProfile("../evil"), "web");
check("setTargetProfile 空串回退 web", lib.setTargetProfile(""), "web");
check("setTargetProfile 含点回退 web", lib.setTargetProfile("web.profile"), "web");
// 恢复 web（后续测试用）
lib.setTargetProfile("web");

// ---- readTargetProfile：config.json 缺失 → web（fromConfig=false，启动回调不覆盖显式设置）----
check("readTargetProfile 无配置回退 web", await lib.readTargetProfile(), { profile: "web", fromConfig: false, source: "default" });

// ---- readTargetProfile：非法名 → web ----
writeFileSync(configFile, JSON.stringify({ targetProfile: "../evil" }), "utf8");
check("readTargetProfile 非法名回退 web", await lib.readTargetProfile(), { profile: "web", fromConfig: false, source: "default" });

// ---- readTargetProfile：目录不存在 → web ----
writeFileSync(configFile, JSON.stringify({ targetProfile: "ghost" }), "utf8");
check("readTargetProfile 目录不存在回退 web", await lib.readTargetProfile(), { profile: "web", fromConfig: false, source: "default" });

// ---- readTargetProfile：合法 + 目录存在 → 生效（fromConfig=true）----
writeFileSync(configFile, JSON.stringify({ targetProfile: "desktop" }), "utf8");
check("readTargetProfile 合法配置生效", await lib.readTargetProfile(), { profile: "desktop", fromConfig: true, source: "config" });

// ---- readTargetProfile：损坏 JSON → web ----
writeFileSync(configFile, "{ broken", "utf8");
check("readTargetProfile 损坏 JSON 回退 web", await lib.readTargetProfile(), { profile: "web", fromConfig: false, source: "default" });

// ---- 启动器 profile 识别（桌面端）：无有效配置时目标跟随启动器给的 profile ----
{
  process.env.DSH_PROFILE_DIR = join(home, "profiles", "desktop");
  delete process.env.DSH_PROFILE;
  profileDomain.refreshCurrentProfile();
  check("启动器 profile 被识别", profileDomain.currentProfile()?.name, "desktop");
  check("isCurrentProfile 命中当前 profile", profileDomain.isCurrentProfile("desktop"), true);
  check("profileDir 按名字解析到启动器给的目录", profileDomain.profileDir("desktop"), join(home, "profiles", "desktop"));
  // 配置仍是损坏状态 → 回退到「当前 profile」而不是 web
  check("无有效配置时跟随启动器 profile", await lib.readTargetProfile(),
    { profile: "desktop", fromConfig: false, source: "current" });
  // 显式配置（且目录存在）仍然优先
  lib.setTargetProfile("desktop");
  check("目标切到当前 profile 后 profileDir 跟随启动器目录", profileDomain.profileDir(), join(home, "profiles", "desktop"));
  writeFileSync(configFile, JSON.stringify({ targetProfile: "web" }), "utf8");
  check("显式配置优先于启动器 profile", await lib.readTargetProfile(),
    { profile: "web", fromConfig: true, source: "config" });
  // 还原：无启动器信息（老环境）
  delete process.env.DSH_PROFILE_DIR;
  profileDomain.refreshCurrentProfile();
  check("还原后无当前 profile", profileDomain.currentProfile(), null);
  lib.setTargetProfile("web");
}

// ---- 切换 profile 后扫描缓存失效----
// profileScanCache 按当前 profile 的 node_modules 构建（列表「已安装」标注来源）。切换后必须重扫：
// 否则 desktop 已装插件在 web 列表仍标「已装」，切回时旧标注反向残留。
{
  mkdirSync(join(home, "profiles", "web", "node_modules", "alpha-pkg"), { recursive: true });
  writeFileSync(join(home, "profiles", "web", "node_modules", "alpha-pkg", "package.json"),
    JSON.stringify({ name: "alpha-pkg", version: "1.0.0" }), "utf8");
  mkdirSync(join(home, "profiles", "desktop", "node_modules", "beta-pkg"), { recursive: true });
  writeFileSync(join(home, "profiles", "desktop", "node_modules", "beta-pkg", "package.json"),
    JSON.stringify({ name: "beta-pkg", version: "2.0.0" }), "utf8");
  lib.setTargetProfile("web");
  let scan = await lib.scanProfilePackages();
  check("扫描缓存 web 含 alpha-pkg", scan.has("alpha-pkg"), true);
  check("扫描缓存 web 不含 beta-pkg", scan.has("beta-pkg"), false);
  lib.setTargetProfile("desktop");
  scan = await lib.scanProfilePackages();
  check("切换后扫描缓存重扫（desktop 含 beta-pkg）", scan.has("beta-pkg"), true);
  check("切换后扫描缓存反向失效（不含 alpha-pkg）", scan.has("alpha-pkg"), false);
  lib.setTargetProfile("web"); // 恢复（后续路由测试用）
}

// ---- profile 路由 ----
let registered = [];
const fakeCtx = {
  get: (s) => (s === "webServer" ? { register: (r) => registered.push(r) } : undefined),
  logger: { warn: () => {}, info: () => {} },
};
// 禁真实网络：apply() 会 detached 触发 getList() 预热与自更新 check()，
// 不拦的话真实 socket 拖住事件循环直到 TCP 超时（被拒后由调用方 catch 兜底）。
globalThis.fetch = () => Promise.reject(new Error("integration test: real network forbidden"));
lib.apply(fakeCtx);
const profileHandler = registered.find((h) => h.path === "/api/marketplace/profile")?.handler;
check("profile 路由已注册", !!profileHandler, true);

// 恢复合法配置（路由测试用）
writeFileSync(configFile, JSON.stringify({ targetProfile: "desktop" }), "utf8");
// apply 的 readTargetProfile 是异步的——路由测试前手动应用，模拟启动完成态
lib.setTargetProfile("desktop");

const mkReq = (method, body, host = "127.0.0.1") => {
  const bodyStr = body ? JSON.stringify(body) : "";
  return {
    method,
    headers: { "x-dsh-marketplace": "1", host: "127.0.0.1:3080" },
    socket: { remoteAddress: host },
    url: "/api/marketplace/profile",
    [Symbol.asyncIterator]() {
      let sent = false;
      return {
        next: async () => {
          if (!sent) { sent = true; return { value: Buffer.from(bodyStr), done: false }; }
          return { value: undefined, done: true };
        },
      };
    },
  };
};
const mkRes = () => {
  const out = { status: 0, body: null };
  return {
    writeHead: (s) => { out.status = s; },
    end: (b) => { try { out.body = JSON.parse(b); } catch { out.body = b; } },
    out,
  };
};

// GET：读当前值（desktop）
{
  const res = mkRes();
  await profileHandler(mkReq("GET"), res);
  check("profile GET 返回当前值", res.out.body?.profile, "desktop");
}
// POST 非法名 → 400
{
  const res = mkRes();
  await profileHandler(mkReq("POST", { profile: "../evil" }), res);
  check("profile POST 非法名 400", res.out.status, 400);
}
// POST 不存在目录 → 400
{
  const res = mkRes();
  await profileHandler(mkReq("POST", { profile: "ghost" }), res);
  check("profile POST 不存在目录 400", res.out.status, 400);
}
// POST 合法 → 200 + 即时生效
{
  const res = mkRes();
  await profileHandler(mkReq("POST", { profile: "desktop" }), res);
  check("profile POST 合法 200", res.out.status, 200);
  check("profile POST 返回新值", res.out.body?.profile, "desktop");
  check("profile POST 后 config.json 已写", JSON.parse(readFileSync(configFile, "utf8")).targetProfile, "desktop");
}
// POST 空值 → 400（必须显式给合法名）
{
  const res = mkRes();
  await profileHandler(mkReq("POST", { profile: "" }), res);
  check("profile POST 空值 400", res.out.status, 400);
}

// ---- 写操作鉴权：LAN Host 无 token → 403 ----
{
  const res = mkRes();
  await profileHandler(mkReq("POST", { profile: "desktop" }, "192.168.1.5"), res);
  check("profile POST LAN 无 token 403", res.out.status, 403);
}

// ---- 清理 ----
rmSync(home, { recursive: true, force: true });

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail === 0 ? 0 : 1);
