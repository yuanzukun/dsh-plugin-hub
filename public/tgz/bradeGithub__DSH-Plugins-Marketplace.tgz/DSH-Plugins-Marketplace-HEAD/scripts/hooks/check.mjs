#!/usr/bin/env node
// Git Hook 共享检查脚本：按需调用单个或多个检查项。
// 用法：
//   node scripts/hooks/check.mjs                      # 全量（pre-commit 全部检查）
//   node scripts/hooks/check.mjs --stage=pre-commit   # 提交前（syntax+tests+toc+secret）
//   node scripts/hooks/check.mjs --stage=commit-msg   # 提交信息校验
//   node scripts/hooks/check.mjs --only=syntax        # 仅语法检查
//   node scripts/hooks/check.mjs --only=secret        # 仅密钥扫描
//   node scripts/hooks/check.mjs --only=toc           # 仅 TOC 检测
//   node scripts/hooks/check.mjs --only=tests         # 仅 unit+integration
//   node scripts/hooks/check.mjs --help               # 用法说明
// 纯校验逻辑在 validate.mjs（可被 smoke-tests 覆盖），本文件只做编排。

import { execFileSync } from "node:child_process";
import { readFileSync, existsSync, mkdtempSync, rmSync } from "node:fs";
import { join, dirname } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";
import { SYNTAX_CHECK_FILES, validateSubject, extractSubject, parseHookConfig, DEFAULT_HOOK_CONFIG, detectSecret, classifyPrecommitTier } from "./validate.mjs";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..", "..");

// git 在 linked worktree 下调 hook 时会注入 GIT_DIR/GIT_INDEX_FILE（绝对路径指向
// 发起 worktree 的 gitdir/index）等内部变量；它们经 process.env 遗传给测试进程后，
// fixture 仓库的 git init/config/add/commit 会穿透写进主仓（实锤：fixture git add
// 把文件 stage 进主仓 index、config 落进主仓配置、git init 把 core.bare 写成 true）。
// 本进程的 git 调用靠 cwd 解析即可，直接删干净再 spawn 任何子进程。
for (const k of [
  "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY",
  "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_QUARANTINE_PATH", "GIT_PREFIX",
  "GIT_LITERAL_PATHSPECS", "GIT_AUTHOR_NAME", "GIT_AUTHOR_EMAIL", "GIT_AUTHOR_DATE",
  "GIT_COMMITTER_NAME", "GIT_COMMITTER_EMAIL", "GIT_COMMITTER_DATE", "GIT_EDITOR",
]) {
  delete process.env[k];
}

// 检查目标工作树：本地默认仓库根；测试（hook-check.test.mjs）与 CI 场景可覆盖。
const WORKTREE = process.env.CHECK_WORKTREE ?? ROOT;
const USAGE = `用法:
  node scripts/hooks/check.mjs [选项]

选项:
  --stage=<pre-commit|commit-msg|pre-push>  运行某个 git 阶段的检查集（默认 pre-commit）
  --only=<name>                    仅运行单项检查（syntax|tests|e2e|toc|secret|commit-msg|coverage）
  --help                           显示本帮助

示例:
  node scripts/hooks/check.mjs --only=secret    # 只扫密钥
  node scripts/hooks/check.mjs --stage=commit-msg "msgfile"`;

const arg = (name) => {
  const hit = process.argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? hit.slice(`--${name}=`.length) : undefined;
};

if (process.argv.includes("--help")) {
  console.log(USAGE);
  process.exit(0);
}

const stage = arg("stage") ?? "pre-commit";
const only = arg("only");
const validOnly = ["syntax", "tests", "e2e", "toc", "secret", "commit-msg", "coverage"];
if (only && !validOnly.includes(only)) {
  console.error(`[FAIL] 未知 --only 值 "${only}"，可选: ${validOnly.join(" | ")}`);
  process.exit(1);
}
const want = (name) => !only || only === name;

/** 读取仓库 .hooksrc 配置（不存在则返回默认）。 */
function loadHookConfig(root) {
  const p = join(root, ".hooksrc");
  if (!existsSync(p)) return { ...DEFAULT_HOOK_CONFIG };
  try {
    return parseHookConfig(readFileSync(p, "utf8"));
  } catch {
    return { ...DEFAULT_HOOK_CONFIG };
  }
}

/** 获取 staged 改动文件列表（本地）或相对基线的增量（CI）。 */
function stagedFiles() {
  const diffBase = process.env.CHECK_DIFF_BASE;
  const args = diffBase
    ? ["diff", "--name-only", `${diffBase}...HEAD`]
    : ["diff", "--cached", "--name-only"];
  const out = execFileSync("git", args, { cwd: WORKTREE, encoding: "utf8" });
  return out.split("\n").map((s) => s.trim()).filter(Boolean);
}

/**
 * 计算本次 pre-commit 的测试运行集（按改动内容分级，fail-safe 保守）：
 * docs/generated 跳过测试；tests-only 跑 unit 快层；命中核心/无法判定/hook 自改全量。
 * CI（CHECK_DIFF_BASE 或 DSH_REQUIRE_E2E）强制全量不降级。
 */
function resolveTestRun() {
  const cfg = loadHookConfig(WORKTREE);
  if (process.env.CHECK_DIFF_BASE || process.env.CI === "true") {
    return { runTests: "unit,integration", tier: "ci-full" };
  }
  const { runTests, tier } = classifyPrecommitTier(stagedFiles(), cfg);
  return { runTests, tier };
}

let failed = false;
const fail = (label, msg) => {
  console.error(`[FAIL] [${label}] ${msg}`);
  failed = true;
};

// ---- 1. 语法检查（与 CI 的 node --check 同步）----
function checkSyntax() {
  if (!want("syntax")) return;
  for (const f of SYNTAX_CHECK_FILES) {
    if (existsSync(join(ROOT, f))) {
      try {
        execFileSync("node", ["--check", f], { cwd: ROOT, stdio: "pipe" });
        console.log(`[OK] [syntax] ${f}`);
      } catch {
        fail("syntax", `${f} 语法错误`);
      }
    }
  }
}

// ---- 2. 测试金字塔（unit → integration → e2e）----
function checkTests() {
  if (!want("tests")) return;
  const driftDir = mkdtempSync(join(tmpdir(), "dsh-hook-drift-"));
  let resolved;
  // --only=tests 是显式全量请求，不走内容分级，恒跑 unit+integration
  if (only === "tests") {
    resolved = { runTests: "unit,integration", tier: "explicit-tests" };
  } else {
    try {
      resolved = resolveTestRun();
      console.log(`[tier] ${resolved.tier} → run.mjs --level=${resolved.runTests || "(skip)"}`);
    } catch (e) {
      // 无法读取 staged（非 git 工作树等）→ 保守退回全量快速门
      resolved = { runTests: "unit,integration", tier: "core" };
      console.warn(`[WARN] [tests] staged 读取失败，回退全量快速门: ${e.message}`);
    }
  }
  try {
    if (resolved.runTests === "none") {
      console.log("[OK] [tests] 仅文档/生成物改动，跳过测试快速门（CI 全量门兜底）");
    } else {
      // 常规提交只跑 unit（tests-only 快层）或 unit+integration（核心全量）；
      // e2e（真实 npm 安装）由 --only=e2e 或 CI 显式执行
      execFileSync("node", ["scripts/tests/run.mjs", `--level=${resolved.runTests}`], {
        cwd: ROOT,
        stdio: "inherit",
        env: { ...process.env, DRIFT_REPORT_FILE: join(driftDir, "drift-report.json") },
      });
      console.log("[OK] [tests] unit+integration 全部通过");
    }
  } catch {
    fail("tests", "unit+integration 存在失败项");
  } finally {
    rmSync(driftDir, { recursive: true, force: true });
  }
  healBundledIndex();
}

function checkE2e() {
  if (!want("e2e")) return;
  const driftDir = mkdtempSync(join(tmpdir(), "dsh-hook-e2e-drift-"));
  try {
    execFileSync("node", ["scripts/tests/run.mjs", "--level=e2e"], {
      cwd: ROOT,
      stdio: "inherit",
      env: {
        ...process.env,
        DSH_REQUIRE_E2E: "1",
        DRIFT_REPORT_FILE: join(driftDir, "drift-report.json")
      },
    });
    console.log("[OK] [e2e] 真实 Host/API 与安装 E2E 全部通过");
  } catch {
    fail("e2e", "真实 Host/API 或安装 E2E 未通过，或缺少必需前置工具");
  } finally {
    rmSync(driftDir, { recursive: true, force: true });
  }
}

/** bundled 索引完整性自愈：list-cache/installed-index 的测试隔离会临时把
 * registry.json/skills.json 替换为坏 JSON；若测试进程被超时强杀（SIGKILL 不触发
 * exit 恢复钩子）会残留损坏文件污染后续运行。校验 JSON 可解析，损坏则 git 恢复。 */
function healBundledIndex() {
  for (const f of ["registry.json", "skills.json"]) {
    const p = join(ROOT, f);
    if (!existsSync(p)) continue;
    try {
      JSON.parse(readFileSync(p, "utf8"));
    } catch {
      try {
        execFileSync("git", ["checkout", "--", f], { cwd: ROOT, stdio: "pipe" });
        console.log(`[WARN] ${f} 残留损坏（测试隔离未恢复），已从 git 恢复`);
      } catch {
        fail("tests", `${f} 损坏且 git 恢复失败`);
      }
    }
  }
}

// ---- 3. TOC 检测（tocLevel: error 阻断 / warn 仅提示 / off 跳过，默认 error）----
function checkToc() {
  if (!want("toc")) return;
  const tocCfg = loadHookConfig(ROOT);
  if (tocCfg.tocLevel === "off") return;
  try {
    const args = ["scripts/toc.mjs", "--check"];
    if ((tocCfg.tocExclude ?? []).length > 0) {
      args.push("--exclude=" + tocCfg.tocExclude.join(","));
    }
    execFileSync("node", args, { cwd: ROOT, stdio: "inherit" });
    console.log("[OK] [toc] 文档 TOC 有效");
  } catch {
    if (tocCfg.tocLevel === "error") {
      fail("toc", "文档 TOC 缺失或过期，请运行 node scripts/toc.mjs 重新生成");
    } else {
      console.warn("[WARN] [toc] 文档 TOC 缺失或过期（warn 等级，不阻断；可运行 node scripts/toc.mjs 重新生成）");
    }
  }
}

// ---- 4. 敏感密钥扫描（暂存文件；CI 模式扫与基线分支的增量）----
// 本地扫 git diff --cached（staged）；CHECK_DIFF_BASE 设置时（CI）改用
// `git diff --name-only <base>...HEAD`——checkout 后的 CI 无 staged 概念，
// 扫 PR 相对基线分支的实际变更（业界 gitleaks --log-opts 同语义）。
function checkSecret() {
  if (!want("secret")) return;
  const cfg = loadHookConfig(WORKTREE);
  if (cfg.secretLevel === "off") return;
  try {
    const diffBase = process.env.CHECK_DIFF_BASE;
    const diffArgs = diffBase
      ? ["diff", "--name-only", `${diffBase}...HEAD`]
      : ["diff", "--cached", "--name-only"];
    const staged = execFileSync("git", diffArgs, { cwd: WORKTREE, encoding: "utf8" });
    const files = staged.split("\n").map((s) => s.trim()).filter(Boolean);
    let found = 0;
    for (const f of files) {
      if (cfg.secretExclusions.some((ex) => f.includes(ex))) continue;
      if (!existsSync(join(WORKTREE, f))) continue;
      let content;
      try {
        content = readFileSync(join(WORKTREE, f), "utf8");
      } catch {
        continue; // 二进制/编码异常跳过
      }
      const r = detectSecret(content);
      if (r.found) {
        found++;
        console.error(`[FAIL] [secret] ${f}: 疑似密钥 ${r.samples.join(", ")}`);
      }
    }
    if (found > 0) {
      if (cfg.secretLevel === "error") {
        fail("secret", `${found} 个文件疑似包含密钥，禁止提交（可用 .hooksrc secretExclusions 排除，或确认后移除）`);
      } else {
        console.warn(`[WARN] [secret] ${found} 个文件疑似包含密钥（warn 等级，不阻断）`);
      }
    } else {
      console.log("[OK] [secret] 未发现疑似密钥");
    }
  } catch (e) {
    fail("secret", `密钥扫描失败: ${e.message}`);
  }
}

// ---- 5. 提交信息规范 ----
function checkCommitMsg() {
  if (!want("commit-msg")) return;
  const msgPath = process.argv.slice(2).find((a) => !a.startsWith("--")) ?? join(WORKTREE, ".git", "COMMIT_EDITMSG");
  if (!existsSync(msgPath)) {
    fail("commit-msg", `未找到提交信息文件: ${msgPath}`);
  } else {
    const subject = extractSubject(readFileSync(msgPath, "utf8"));
    const level = loadHookConfig(WORKTREE).emojiLevel ?? "error";
    const r = validateSubject(subject, { emojiLevel: level });
    if (r.ok) {
      console.log(`[OK] [commit-msg] ${subject}`);
      for (const w of r.warnings ?? []) {
        console.warn(`[WARN] [commit-msg] ${w}（warn 等级，不阻断）`);
      }
    } else {
      fail("commit-msg", r.reason);
    }
  }
}

// ---- 6. 覆盖率检查（hook 校验逻辑 100% 覆盖；含 e2e 全量，耗时 ~25s）----
// 常规提交不执行（见 pre-commit 分组）；CI/PR 前用 `--only=coverage` 手动或自动执行。
function checkCoverage() {
  if (!want("coverage")) return;
  try {
    execFileSync("node", ["scripts/coverage.mjs"], { cwd: ROOT, stdio: "inherit" });
    console.log("[OK] [coverage] 覆盖率达标");
  } catch {
    fail("coverage", "覆盖率未达 100%，请补充测试断言");
  }
}

if (stage === "pre-commit") {
  checkSyntax();
  checkTests();
  if (only === "e2e") checkE2e();
  checkToc();
  checkSecret();
  // coverage 不在此列：耗时长（e2e 真实 npm 安装 ~25s），由 --only=coverage / CI 执行
  // --only=commit-msg 时单独执行（无 --only 时静默跳过）
  if (only === "commit-msg") checkCommitMsg();
  if (only === "coverage") checkCoverage();
}
// ---- 7. 发布 tag 签名硬门控（pre-push）----
// git pre-push stdin 逐行喂 `<local ref> <local sha> <remote ref> <remote sha>`。
// 命中 refs/tags/v* 的推送必须是通过 lib/allowed-signers.js 信任根验签的
// annotated tag（verify-tag.mjs 复用 lib/domain/sshsig.js）；
// 删除 v* tag 一律拒绝（可用性保护，服务端删除走 GitHub 管理面不经本地 hook）。
// 非 v* tag 与分支推送不拦截。
function checkTagSignatures() {
  let stdinText = "";
  try {
    stdinText = readFileSync(0, "utf8"); // fd 0 = pre-push refs
  } catch {
    stdinText = ""; // 非 hook 手动执行且无管道输入：无可校验对象，放行
  }
  const tagRefs = stdinText.split("\n").map((l) => l.trim()).filter(Boolean)
    .map((l) => l.split(/\s+/))
    .filter((p) => (p[0] ?? "").startsWith("refs/tags/v"));
  if (tagRefs.length === 0) return;
  for (const [localRef, localSha] of tagRefs) {
    const tag = localRef.slice("refs/tags/".length);
    if (/^0+$/.test(localSha ?? "")) {
      fail("tags", `禁止推送删除发布 tag ${tag}（可用性保护；确需删除请走 GitHub 管理面）`);
      continue;
    }
    try {
      execFileSync("node", [join(ROOT, "scripts", "verify-tag.mjs"), tag], { cwd: WORKTREE, stdio: "inherit" });
      console.log(`[OK] [tags] ${tag} 签名验证通过`);
    } catch {
      fail("tags", `发布 tag ${tag} 未通过签名验证（须 git tag -s 用 release 私钥签 annotated tag，见 docs/RELEASE.md）`);
    }
  }
}

if (stage === "commit-msg") {
  checkCommitMsg();
}
if (stage === "pre-push") {
  checkTagSignatures();
}

if (failed) {
  console.error("\n[FAIL] Git Hook 检查未通过，请修复后重试。");
  process.exit(1);
}
console.log("\n[OK] 全部检查通过。");
