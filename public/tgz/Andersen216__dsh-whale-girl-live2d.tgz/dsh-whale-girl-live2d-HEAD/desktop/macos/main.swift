// 鲸鱼娘桌宠 · macOS 原生壳（方案 A）
// ————————————————————————————————————————————————————————————
// 做的事：开一个**透明、无边框、永远置顶**的窗口贴在你桌面上，里面跑插件的
// `/dsh-pet/standalone` 页面。于是桌宠不再只活在浏览器标签页里。
//
// 四个关键点，缺一个都不像「桌宠」：
//   1. 透明 + 无边框 + 无阴影：窗口本身看不见，只有鲸鱼娘和她的气泡
//   2. 永远置顶 + 跟随所有空间：切桌面、开全屏她都还在
//   3. **点击穿透**：鼠标压在她身上才收事件，其它地方事件直接穿到下面的 App。
//      判断「算不算在她身上」用页面里的 DSHPet.hitTest（alpha 掩码，不是方块），
//      另外把气泡/菜单/钱包/输入框这些面板也算进去，否则那些面板点不动。
//   4. 拖她 = 拖窗口（而不是在窗口里挪动她）；松手位置会记住，下次打开还在那儿。
//
// 编译见 tools/build-desktop-mac.sh；本文件不依赖任何第三方库。
import Cocoa
import WebKit

/// 宿主地址在启动时「发现」出来，不再写死 ——
/// 官方桌面版（Electron App，端口由它自己挑，实测 19387）和手动起的 `dsh web`（3080）
/// 都能连上。插件侧不用做任何改动。
var deskBase: String = "http://127.0.0.1:19387"
var petURL: String { deskBase + "/dsh-pet/standalone" }
// 窗口必须比「她 + 四周面板」大：说话框 370 宽、设置面板 393×471，
// 窗口太小时面板会被窗口本身裁掉（主人看到的「只剩一个角」就是这个原因）。
// 多出来的区域是透明的、而且点击穿透 —— 不影响你操作别的窗口。
// 窗口只留「够用」的大小：菜单面板 393×471、聊天框 370 宽，
// 加上她本人大约 200px 高，再留点余量 → 460×700 足够。
// 实测：透明窗口的面积越小，WindowServer 合成它就越省
//（鼠标连续移动时 WindowServer 66~79%，透明面积是它的直接成本）。
let WIN_W: CGFloat = 460
let WIN_H: CGFloat = 700
let K_X = "pet.win.x", K_Y = "pet.win.y", K_TOP = "pet.win.top", K_LOW = "perf.low"

/// 插件资源目录：优先用「装进 profile 的那份」，找不到再按 App 包相对位置找，
/// 这样不管 App 放在 dist/ 还是被拷到「应用程序」里都能定位到图标。
let assetsPath: String = {
    let profile = NSHomeDirectory() + "/.dsh/profiles/web/node_modules/dsh-whale-girl-live2d/assets"
    if FileManager.default.fileExists(atPath: profile) { return profile }
    let rel = Bundle.main.bundlePath + "/../../../../assets"
    return (rel as NSString).standardizingPath
}()

/// 普通无边框窗口 canBecomeKey 默认是 false —— 表现就是「网页里能点、但打不出字」。
/// 桌宠要能聊天，这个必须打开。
final class PetWindow: NSWindow {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }

    /// 拆掉 macOS 的「空气墙」。
    ///
    /// AppKit 默认会把窗口约束在屏幕内（不让顶部顶到菜单栏上面），对普通窗口是对的，
    /// 但桌宠是无边框、本来就该能拖到任何地方（包括半出屏）的窗口。
    /// 日志证据：拖动时窗口 y 每次都停在 150 —— 150 + 900(窗口高) = 1050 = 屏幕可用区顶边，
    /// 就是这条默认约束在拦。覆写成原样返回即可。
    override func constrainFrameRect(_ frameRect: NSRect, to screen: NSScreen?) -> NSRect {
        return frameRect
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKScriptMessageHandler {
    var win: NSWindow!
    var web: WKWebView!
    var status: NSStatusItem!
    var probe: Timer?
    var health: Timer?
    var activity: NSObjectProtocol?
    var lastHealth = ""
    // 收起态：贴边悬浮小球
    var ball: NSWindow?
    var ballWeb: WKWebView?
    var ballView: BallView?
    var ballDown = NSPoint.zero
    var ballAt = NSPoint.zero
    var ballMoved: CGFloat = 0
    var hiddenWatch: Timer?
    var shootWatch: Timer?
    var cursorFeed: Timer?
    var lastCursor: NSPoint?
    var health2: Timer?
    var launchedAt = Date()
    var failCount = 0
    var lastLogText = ""
    var lastLogAt = Date.distantPast

    var inside = false          // 鼠标当前是不是压在她（或她的面板）身上
    var overPanel = false       // 鼠标当前在不在她的面板上（面板里的拖动要交给网页）
    var panelGesture = false    // 这一次按下是发生在面板里（别抢它的拖动）
    var downAt = NSPoint.zero   // 按下时的鼠标位置（屏幕坐标）
    var winAt = NSPoint.zero    // 按下时的窗口位置
    var moved: CGFloat = 0      // 这次按下总共挪了多少像素
    var shellDrag = false       // 已经判定为「拖窗口」而不是「点她」

    // MARK: - 启动

    func applicationDidFinishLaunching(_ note: Notification) {
        NSApp.setActivationPolicy(.accessory)   // 不占 Dock、不抢焦点
        // 关键：别让 macOS 把「没人操作的透明窗口」判成 App Nap 而掐掉 requestAnimationFrame。
        // 被掐的症状极隐蔽：页面不报错、模型数据也加载了，但 rAF 永不触发 →
        // 前端启动流程停在「等一帧」那一步，于是既画不出她、也连不上事件流。
        // 日志超过 2MB 就滚掉，别让它无限长大
        let logPath = NSHomeDirectory() + "/.dsh/whalegirlpet.log"
        if let attrs = try? FileManager.default.attributesOfItem(atPath: logPath),
           let size = attrs[.size] as? Int, size > 2_000_000 {
            try? FileManager.default.removeItem(atPath: logPath)
        }
        // 构建指纹：确认「正在跑的」就是「刚编译的」（排查过好几次「改了没生效」）
        let exe = Bundle.main.executablePath ?? "?"
        let mt = (try? FileManager.default.attributesOfItem(atPath: exe)[.modificationDate] as? Date) ?? nil
        log("=== 启动 构建时间 \(mt.map { ISO8601DateFormatter().string(from: $0) } ?? "?") ===")
        beginAwake()
        makeWindow()
        makeWeb()
        makeStatusItem()
        makeBall()
        installMonitors()
        restorePosition()
        win.orderFrontRegardless()
        ensureVisible()
        load()
        // ——— 全屏视线追踪 ———
        // 页面的视线靠 mousemove 驱动，但**窗口外的鼠标移动它收不到**，所以她"不看我鼠标"。
        // 这里定时把全局光标位置合成成 mousemove 事件喂进页面 —— 前端一行都不用改，
        // 全屏任何位置她都能看过来。（只在鼠标真的动了时才喂，几乎不增加开销。）
        // 频率必须贴近网页版：浏览器原生 mousemove 每秒几十上百次，
        // 我们原来 60ms(≈16Hz) + 3px 死区 → 目标点是**跳着给的**，
        // 表现就是主人说的「一卡一卡、像齿轮没润滑油」。
        // 现在 16ms(≈60Hz) + 1px 死区，和网页版同一量级。
        cursorFeed = Timer.scheduledTimer(withTimeInterval: 0.016, repeats: true) { [weak self] _ in
            guard let self, self.win.isVisible, !self.shellDrag else { return }
            let m = NSEvent.mouseLocation
            if let last = self.lastCursor, abs(last.x - m.x) < 1, abs(last.y - m.y) < 1 { return }
            self.lastCursor = m
            let f = self.win.frame
            // ⚠️ 关键：把**整个屏幕**线性映射到窗口坐标里再喂给页面。
            // 原来直接用窗口坐标 → 鼠标一旦跑到窗口外（比如屏幕最右边），
            // 归一化后就超出范围被夹住 → 表现就是主人说的「鼠标到最右边她就不跟了」。
            // 映射之后：屏幕最左→0、最右→窗口宽，页面归一化正好拿到 ±1，全屏都能跟。
            let scr = (NSScreen.screens.first { $0.frame.contains(m) } ?? NSScreen.main)?.frame ?? f
            let nx = (m.x - scr.minX) / max(1, scr.width)
            let ny = 1 - (m.y - scr.minY) / max(1, scr.height)
            let x = Int(nx * f.width)
            let y = Int(ny * f.height)
            self.web.evaluateJavaScript(
                "window.dispatchEvent(new MouseEvent('mousemove',{clientX:\(x),clientY:\(y),bubbles:true}))",
                completionHandler: nil)
        }

        probe = Timer.scheduledTimer(withTimeInterval: 0.09, repeats: true) { [weak self] _ in
            self?.updateHit()
        }
        RunLoop.current.add(probe!, forMode: .common)
        // 页面里点「隐藏」→ 自动换成悬浮小球；这是她和壳子的约定
        launchedAt = Date()
        // 截图触发器：`touch ~/.dsh/whalegirlpet-shoot` → 立刻存一张她的快照并删掉触发器。
        // 用途：无头浏览器没有 WebGL、screencapture 又没屏幕录制权限，
        // 这是唯一能「证明她真的画出来了」的自查手段。
        shootWatch = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self else { return }
            let flag = NSHomeDirectory() + "/.dsh/whalegirlpet-shoot"
            guard FileManager.default.fileExists(atPath: flag) else { return }
            try? FileManager.default.removeItem(atPath: flag)
            self.saveShot()
            self.log("按触发器保存了快照 → ~/.dsh/whalegirlpet-shot.png")
        }
        hiddenWatch = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { [weak self] _ in
            self?.checkHidden()
        }
        RunLoop.current.add(hiddenWatch!, forMode: .common)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ app: NSApplication) -> Bool { false }

    // MARK: - 窗口

    func makeWindow() {
        win = PetWindow(
            contentRect: NSRect(x: 0, y: 0, width: WIN_W, height: WIN_H),
            styleMask: [.borderless], backing: .buffered, defer: false)
        win.isOpaque = false
        win.backgroundColor = .clear
        win.hasShadow = false
        win.level = .floating
        win.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
        win.ignoresMouseEvents = true          // 先全穿透，鼠标压到她身上再收事件
        win.isMovableByWindowBackground = false
        win.title = "DS 鲸鱼娘"
    }

    func makeWeb() {
        let cfg = WKWebViewConfiguration()
        // 把页面里的 console / 报错转发到原生日志：壳子里没有开发者工具，
        // 出问题时只能靠这个看它卡在哪一步。
        let ucc = WKUserContentController()
        ucc.add(self, name: "dshpetlog")
        ucc.add(self, name: "dshpetshell")   // 前端发指令：收起 / 展开 / 彻底退出
        let hook = """
        (function(){
          function send(t, a){
            try{
              var s = a.map(function(x){ try{ return typeof x === 'string' ? x : JSON.stringify(x) }catch(e){ return String(x) } }).join(' ');
              window.webkit.messageHandlers.dshpetlog.postMessage(t + ' ' + s);
            }catch(e){}
          }
          ['log','warn','error'].forEach(function(k){
            var o = console[k] ? console[k].bind(console) : function(){};
            console[k] = function(){ send(k, [].slice.call(arguments)); o.apply(null, arguments) };
          });
          window.addEventListener('error', function(e){ send('✗ window.onerror', [String(e.message) + ' @ ' + e.filename + ':' + e.lineno]) });
          window.addEventListener('unhandledrejection', function(e){ send('✗ unhandledrejection', [String(e.reason)]) });
          // 告诉前端「我在桌面壳里」：设置页会因此多出「收起成小球 / 彻底关闭」两项
          window.__DSHPET_SHELL__ = true;
          // 网页面自己那个「鲸鱼娘」小把手在壳子里不需要（壳子有原生小球），
          // 不藏掉的话收起时会先闪一下那个把手，看着很卡。
          try{
            var st = document.createElement('style');
            st.textContent = 'body.dshp-pet-hidden .dshp-tab{display:none!important}';
            (document.head || document.documentElement).appendChild(st);
          }catch(e){}
        })()
        """
        ucc.addUserScript(WKUserScript(source: hook, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        cfg.userContentController = ucc

        web = WKWebView(frame: win.contentView!.bounds, configuration: cfg)
        web.autoresizingMask = [.width, .height]
        web.navigationDelegate = self
        // 透明背景：三管齐下（WKWebView 的 drawsBackground 是私有键，先确认存在再设，避免崩）
        // 关掉 WKWebView 自己的白底。
        // 坑：老写法查的是 setDrawsBackground:，但那是私有属性 —— 运行时真名是
        // _setDrawsBackground:（KVC 会找到它），查 setDrawsBackground: 只会得到 false，
        // 于是一直以为「不支持」而跳过，白底就这么留了一路。
        if WKWebView.instancesRespond(to: NSSelectorFromString("_setDrawsBackground:")) {
            web.setValue(false, forKey: "drawsBackground")
            log("透明自检：已调用 _setDrawsBackground: 关掉 WebView 白底")
        } else {
            log("透明自检：这台系统没有 _setDrawsBackground:，改用 underPageBackgroundColor")
        }
        if WKWebView.instancesRespond(to: NSSelectorFromString("_setDrawsTransparentBackground:")) {
            web.setValue(true, forKey: "drawsTransparentBackground")
            log("透明自检：已调用 _setDrawsTransparentBackground:")
        }
        if #available(macOS 12.0, *) { web.underPageBackgroundColor = .clear }
        // 图层底色也清掉：窗口是透明的，但 NSView 图层默认可能带底色（「大白框」的头号嫌疑）
        web.wantsLayer = true
        web.layer?.backgroundColor = NSColor.clear.cgColor
        win.contentView?.wantsLayer = true
        win.contentView?.layer?.backgroundColor = NSColor.clear.cgColor
        win.contentView!.addSubview(web)
        clearBackdrops(web)          // WKWebView 内部的滚动视图默认是白底，必须拆掉
        dumpBackgroundMethods()
        log("透明自检：underPageBackgroundColor = \(web.underPageBackgroundColor)")
        // 3 秒后量一次真实像素：窗口角落应该是全透明（alpha=0）
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in self?.probeWindowAlpha() }
    }

    func makeStatusItem() {
        status = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        status.button?.title = "🐋"          // 菜单栏上的入口：没有它这个窗口就关不掉了
        status.button?.toolTip = "DS 鲸鱼娘桌宠"
        let m = NSMenu()
        m.addItem(withTitle: "重新加载", action: #selector(reload), keyEquivalent: "r")
        m.addItem(withTitle: "回到右下角（连她的位置一起归位）", action: #selector(resetPetPosition), keyEquivalent: "")
        m.addItem(withTitle: "收起成小球（贴边）", action: #selector(collapseToBall), keyEquivalent: "")
        m.addItem(withTitle: "展开桌宠", action: #selector(expandFromBall), keyEquivalent: "")
        let sizeItem = m.addItem(withTitle: "小球大小", action: nil, keyEquivalent: "")
        let sizeMenu = NSMenu()
        for (title, sel) in [("小（28）", #selector(setBallSmall)), ("中（36）", #selector(setBallMedium)), ("大（48）", #selector(setBallLarge))] {
            let it = sizeMenu.addItem(withTitle: title, action: sel, keyEquivalent: "")
            it.target = self
        }
        sizeItem.submenu = sizeMenu
        m.addItem(withTitle: "安装到「应用程序」（之后可双击打开）", action: #selector(installApp), keyEquivalent: "")
        let top = m.addItem(withTitle: "总在最前", action: #selector(toggleTop), keyEquivalent: "")
        top.state = (UserDefaults.standard.object(forKey: K_TOP) as? Bool ?? true) ? .on : .off
        m.addItem(.separator())
        let low = m.addItem(withTitle: "低性能模式（少动、省电）", action: #selector(toggleLowPower), keyEquivalent: "")
        low.state = (UserDefaults.standard.object(forKey: K_LOW) as? Bool ?? false) ? .on : .off
        m.addItem(withTitle: "保存一张截图（看效果用）", action: #selector(saveShot), keyEquivalent: "")
        m.addItem(withTitle: "打开自检页（浏览器）", action: #selector(openDiag), keyEquivalent: "")
        m.addItem(withTitle: "打开 DSH 插件设置目录", action: #selector(openHome), keyEquivalent: "")
        m.addItem(.separator())
        m.addItem(withTitle: "彻底退出桌宠", action: #selector(quitNow), keyEquivalent: "q")
        for it in m.items { it.target = self }
        status.menu = m
    }

    // MARK: - 拖动 / 点击

    func installMonitors() {
        NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .leftMouseDragged, .leftMouseUp]) {
            [weak self] e in
            guard let self else { return e }
            if let w = e.window, w === self.ball { return self.ballHandle(e) }
            return self.handle(e)
        }
    }

    func handle(_ e: NSEvent) -> NSEvent? {
        switch e.type {
        case .leftMouseDown:
            // 按下瞬间立刻重新判一次「鼠标下面是她还是面板」——
            // 否则会用 90ms 前的旧结果：鼠标刚扫过菜单就会判成「面板」，
            // 于是这次拖动被交给网页，只能在窗口范围内挪 → 主人感觉「有边界拖不动」。
            overPanel = false
            updateHit()
            refreshGeo()        // 点一下就刷一次几何：切页签/展开后缓存立刻跟上，避免下一次点不中
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) { [weak self] in
                guard let self else { return }
                self.log("按下判定: overPanel=\(self.overPanel) 鼠标=(\(Int(self.downAt.x)),\(Int(self.downAt.y)))")
            }
            downAt = NSEvent.mouseLocation
            winAt = win.frame.origin
            moved = 0
            shellDrag = false
            panelGesture = false
            // 点她 = 想跟她说话：把 App 激活、窗口变 key、焦点交给网页，
            // 否则无边框窗口收不到键盘事件（「能点但打不了字」就是这么来的）
            NSApp.activate(ignoringOtherApps: true)
            win.makeKeyAndOrderFront(nil)
            win.makeFirstResponder(web)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { [weak self] in
                guard let self else { return }
                self.log("键盘自检：isKeyWindow=\(self.win.isKeyWindow) firstResponder=\(String(describing: self.win.firstResponder))")
            }
            return e

        case .leftMouseDragged:
            // 在面板里按下 → 这是网页自己的拖动（拖滑块、选文字），一律放行。
            // 之前不分青红皂白把拖动都当「拖窗口」吃掉，结果设置里的滑块拖不动。
            // 拖动已经超过阈值：用「此刻」的判断决定归属。
            // 只在鼠标下面是真控件（滑块/按钮/输入框）时才留给网页，
            // 其余情况一律拖窗口 —— 这样整个屏幕都能拖。
            if overPanel { return e }
            let m = NSEvent.mouseLocation
            let dx = m.x - downAt.x, dy = m.y - downAt.y
            moved = max(moved, abs(dx) + abs(dy))
            if moved > 3 {
                if !shellDrag {
                    shellDrag = true
                    log("开始拖窗口: overPanel=\(overPanel) 起点=(\(Int(downAt.x)),\(Int(downAt.y)))")
                    // 告诉她「这次不算点我」：前端监听 pointercancel 会把按下状态清掉
                    web.evaluateJavaScript(
                        "document.dispatchEvent(new PointerEvent('pointercancel',{bubbles:true}))",
                        completionHandler: nil)
                    NSCursor.closedHand.push()
                }
                win.setFrameOrigin(NSPoint(x: winAt.x + dx, y: winAt.y + dy))
                return nil                          // 吃掉拖动，别让页面里那个「拖动她」的逻辑也动
            }
            return e

        case .leftMouseUp:
            panelGesture = false
            if shellDrag {
                log("拖动结束: 窗口移到 (\(Int(win.frame.minX)),\(Int(win.frame.minY)))")
                shellDrag = false
                NSCursor.pop()
                savePosition()
                return nil                          // 吃掉这次松手：拖窗口不该被当成「摸头」
            }
            savePosition()
            return e

        default:
            return e
        }
    }

    // MARK: - 点击穿透

    /// 这行 JS 决定「鼠标这个位置算不算在她身上」：
    /// ① 模型本体：用页面自己的 alpha 掩码命中判定
    /// ② 她的面板：气泡 / 菜单 / 钱包 / 输入框 / 工具条（不然那些点不动）
    /// 这行 JS 回答两个问题：鼠标下面是不是「她」、是不是「她的面板」。
    ///   panel = 面板/工具栏/气泡/输入框（有滑块、按钮，拖动要交给网页）
    ///   model = 她模型本体（拖动 = 拖窗口，点击 = 摸头）
    ///   none  = 空白处（点击穿透到桌面）
    let hitJS = """
    (function(){try{
      var x=__X__, y=__Y__;
      var el=document.elementFromPoint(x,y);
      var ui = !!(el && el.closest && el.closest('.dshp-panel,.dshp-menu,.dshp-hud,.dshp-bubble,.dshp-composer,.dshp-dock,.dshp-tab,.dshp-mail'));
      if (ui) {
        // 只有面板里真正的控件（滑块/按钮/输入框）才把拖动让给网页；
        // 面板的空白处按「她」处理 —— 否则点她头顶附近会判成面板，
        // 壳子就放弃拖窗口，于是只能在页面视口里挪（主人报的「拖不到屏幕上半部分」）。
        var ctl = el.closest && el.closest('input,textarea,button,select,a,[contenteditable],.dshp-dock');
        return ctl ? 'panel' : 'model';
      }
      if (window.DSHPet && DSHPet.hitTest && DSHPet.hitTest(x,y)) return 'model';
      return 'none';
    }catch(e){return 'none'}})()
    """

    /// 她的可见范围 + 各面板矩形（每 ~1 秒刷新一次就够：她动得很慢）
    /// 有了它，90% 的探针可以「本地算完」，不用每次进网页 —— 这是丝滑的关键。
    var lastIgnore: Bool?
    var geo: (stage: CGRect, panels: [CGRect])?
    var geoAt = Date.distantPast
    var statLocal = 0
    var statJS = 0

    func refreshGeo(_ done: (() -> Void)? = nil) {
        let js = """
        (function(){try{
          var r=document.querySelector('canvas');
          var st=r?r.getBoundingClientRect():{left:0,top:0,width:0,height:0};
          var ps=[];
          document.querySelectorAll('.dshp-panel,.dshp-hud,.dshp-bubble,.dshp-composer,.dshp-dock').forEach(function(e){
            var b=e.getBoundingClientRect(); if(b.width>4&&b.height>4) ps.push([b.left,b.top,b.width,b.height]);
          });
          return JSON.stringify({s:[st.left,st.top,st.width,st.height],p:ps});
        }catch(e){return null}})()
        """
        web.evaluateJavaScript(js) { [weak self] res, _ in
            guard let self, let str = res as? String, let d = str.data(using: .utf8),
                  let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any],
                  let a = o["s"] as? [Double], a.count == 4 else { return }
            let stage = CGRect(x: a[0], y: a[1], width: a[2], height: a[3])
            var panels: [CGRect] = []
            for raw in (o["p"] as? [[Double]] ?? []) where raw.count == 4 {
                panels.append(CGRect(x: raw[0], y: raw[1], width: raw[2], height: raw[3]))
            }
            let stageBox = stage.insetBy(dx: -6, dy: -6)      // 留一点余量，别在边缘抖
            self.geo = (stageBox, panels)
            self.geoAt = Date()
            done?()
        }
    }

    func updateHit() {
        if !win.isVisible { return }        // 收起成小球时主窗口不在屏幕上，没必要探
        // ⚠️ 拖动期间必须冻结探针：探针每 90ms 会把 ignoresMouseEvents 设成
        // 「鼠标不在她身上就穿透」。而拖动时鼠标**必然**会离开她身体 → 窗口立刻变成穿透 →
        // 拖动事件断掉 → 表现就是「只能在桌面的一小块区域里拖、拖不出去」。
        if shellDrag || panelGesture { return }
        let m = NSEvent.mouseLocation
        let f = win.frame
        // ——— 本地快速判定（不碰网页）———
        // 她只占窗口的一小块；鼠标不在她的范围、也不在任何面板里时，直接判「穿透」，
        // 省掉一次 IPC + elementFromPoint + 逐像素采样。这一步把 90% 的探针变成纯计算。
        // 缓存只信 1.2 秒；而且**必须留余量** ——
        // 主人反馈「设置里那些东西老点不着、点她也点不中」：切页签/换内容时面板高度会变，
        // 下半部分落到缓存矩形之外就被判成「空白」→ 点击直接穿透过去 ✗
        // 现在：① 矩形向外扩 40px ② 缓存过期时不猜、老老实实去问网页。
        let age = Date().timeIntervalSince(geoAt)
        if let g = geo, age < 1.2 {
            let p = CGPoint(x: m.x - f.minX, y: f.maxY - m.y)   // 转成页面坐标（原点在左上）
            let margin: CGFloat = 40
            let hitStage = g.stage.insetBy(dx: -margin, dy: -margin).contains(p)
            let hitPanel = g.panels.contains(where: { $0.insetBy(dx: -margin, dy: -margin).contains(p) })
            if !hitStage && !hitPanel {
                statLocal += 1
                if inside { setInside(false) }
                return
            }
        } else if age > 0.35 {
            refreshGeo()        // 缓存过期就立刻刷新，并且这一拍仍然走下面的「问网页」分支（不猜）
        }
        if !f.contains(m) { setInside(false); return }
        let x = m.x - f.minX
        let y = f.height - (m.y - f.minY)     // 屏幕坐标 → 网页坐标（左上原点）
        let js = hitJS.replacingOccurrences(of: "__X__", with: String(format: "%.1f", x))
                       .replacingOccurrences(of: "__Y__", with: String(format: "%.1f", y))
        web.evaluateJavaScript(js) { [weak self] v, _ in
            guard let self else { return }
            let kind = (v as? String) ?? "none"
            self.overPanel = (kind == "panel")
            let on = (kind != "none") || ((v as? Bool) ?? false)
            self.setInside(on)
        }
    }

    func setInside(_ v: Bool) {
        if v == inside { return }
        inside = v
        // ⚠️ 只在「真的变化」时才赋值。原来每个 tick（90ms）都赋一次，
        // 会让 WindowServer 反复重算窗口命中测试 —— 鼠标一动就卡的主因之一。
        let want = !v
        if lastIgnore == want { return }
        lastIgnore = want
        win.ignoresMouseEvents = want
    }

    // MARK: - 加载与位置

    /// 候选宿主：① 正在监听的「像 DSH 的」进程（官方桌面版 / dsh web）② 常见端口兜底
    /// 通行证文件里记录的宿主端口（插件写进去的，因机器而异 —— 不能写死）
    func deskPort() -> Int? {
        let p = NSHomeDirectory() + "/.dsh/dsh-live2d-pet-desktop.json"
        guard let d = FileManager.default.contents(atPath: p),
              let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any],
              let n = o["port"] as? Int, n > 0, n < 65536
        else { return nil }
        return n
    }

    /// 用户选的连接档位：auto（默认，自动挑）/ desktop（官方桌面版）/ web（dsh web）
    /// 主人反馈：她有时连网页版、有时连桌面版 → 会「串对话」，所以要能手动钉住并记住。
    func hostPref() -> String {
        return UserDefaults.standard.string(forKey: "dshpHostPref") ?? "auto"
    }
    func setHostPref(_ v: String) {
        UserDefaults.standard.set(v, forKey: "dshpHostPref")
        UserDefaults.standard.synchronize()
    }

    /// 候选宿主列表：**不靠端口号判断类型**（3080/19387 只是本机端口，别人可能完全不同）。
    /// 这里只负责「有哪些可能」，是网页版还是桌面版由 probeHost() 读宿主自己发出的
    /// 启动配置标记（desktop:true/false）来判定。
    /// 端口 → 属主进程名（lsof 的第一列）。用来判断这个宿主是官方桌面版还是 dsh web ——
    /// **通用判据，不看端口号**：桌面版宿主跑在 "DeepSeek Harness" 里，网页版是 node/dsh。
    var portOwners: [Int: String] = [:]

    func candidateBases() -> [String] {
        var ports: [Int] = []
        // ① 插件写下的真实端口（谁先开就写谁，所以「打开哪个都能连」）
        if let n = deskPort() { ports.append(n) }
        // ② 扫描本机所有监听端口（端口没监听时连接会被立刻拒绝，所以逐个探活很快）
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/sbin/lsof")
        p.arguments = ["-nP", "-iTCP", "-sTCP:LISTEN"]
        let pipe = Pipe()
        p.standardOutput = pipe
        p.standardError = FileHandle.nullDevice
        if (try? p.run()) != nil {
            let data = pipe.fileHandleForReading.readDataToEndOfFile()
            p.waitUntilExit()
            for line in String(decoding: data, as: UTF8.self).split(separator: "\n") {
                let l = String(line)
                guard l.contains("127.0.0.1:") || l.contains("*:") || l.contains("[::1]:") else { continue }
                if let r = l.range(of: #":(\d{2,5})\s*$"#, options: .regularExpression),
                   let port = Int(l[r].dropFirst().trimmingCharacters(in: .whitespaces)), port > 1023, port < 65536 {
                    ports.append(port)
                    let owner = l.split(separator: " ").first.map(String.init) ?? ""
                    if !owner.isEmpty { portOwners[port] = owner }
                }
            }
        }
        // ③ 兜底：万一上面都没找到（例如异常环境），至少试这几个常见端口
        ports += [19387, 3080, 8080, 3000]
        var seen = Set<Int>()
        return ports.filter { seen.insert($0).inserted }.map { "http://127.0.0.1:\($0)" }
    }

    /// 探一下某个宿主：200 = 就是它且票有效；401 = 插件在但票不对；其它 = 不是它
    /// 探测一个候选宿主：返回（HTTP 状态码, 类型）。
    ///
    /// **类型不靠端口号判断** —— 端口千差万别（3080/19387 只是本机的）。
    /// 判据是插件自己注入到前端里的启动配置：
    ///   宿主跑在 Electron 里（官方桌面版）→ `"desktop":true`
    ///   宿主是普通 Node（`dsh web`）      → `"desktop":false`
    /// 所以只要读一下它发出来的 pet.js 就知道它是哪一种。
    func probeHost(_ base: String, token: String) -> (code: Int, desktop: Bool?, version: String) {
        guard let u = URL(string: base + "/dsh-pet/pet.js") else { return (-1, nil, "") }
        var req = URLRequest(url: u)
        req.timeoutInterval = 1.8
        req.setValue("dsh_pet_desk=\(token)", forHTTPHeaderField: "Cookie")
        let sem = DispatchSemaphore(value: 0)
        var code = -1
        var kind: Bool?
        var version = ""
        URLSession.shared.dataTask(with: req) { data, resp, _ in
            if let h = resp as? HTTPURLResponse { code = h.statusCode }
            if let d = data, let text = String(data: d, encoding: .utf8) {
                if text.contains("\"desktop\":true") { kind = true }
                else if text.contains("\"desktop\":false") { kind = false }
                // 头部注释形如 /* dsh-live2d-pet 0.4.6 */ —— 用它判断这个宿主的前端新不新
                if let r = text.range(of: #"dsh-live2d-pet ([0-9]+\.[0-9]+\.[0-9]+)"#, options: .regularExpression) {
                    version = String(text[r]).replacingOccurrences(of: "dsh-live2d-pet ", with: "")
                }
            }
            sem.signal()
        }.resume()
        _ = sem.wait(timeout: .now() + 3.0)
        return (code, kind, version)
    }

    /// 这个宿主最近有多活跃（时间戳越大 = 越"正在干活"）。
    /// 主人要求：**哪个东西在跑任务就连哪个**，而不是永远连第一个（以前老挂网页端）。
    func activityOf(_ base: String, token: String) -> Int {
        guard let u = URL(string: base + "/dsh-pet/state") else { return 0 }
        var req = URLRequest(url: u)
        req.timeoutInterval = 1.5
        req.setValue("dsh_pet_desk=\(token)", forHTTPHeaderField: "Cookie")
        let sem = DispatchSemaphore(value: 0)
        var score = 0
        URLSession.shared.dataTask(with: req) { data, _, _ in
            if let d = data, let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] {
                let last = (o["lastEventAt"] as? Int) ?? 0
                let st = (o["status"] as? String) ?? ""
                // 正在跑的加权 60 秒，保证"在干活的"压过"刚闲下来的"
                score = last + ((st == "running" || st == "working") ? 60000 : 0)
            }
            sem.signal()
        }.resume()
        _ = sem.wait(timeout: .now() + 2.5)
        return score
    }

    func load() {
        guard let token = deskToken() else {
            log("还没拿到本地通行证（~/.dsh/dsh-live2d-pet-desktop.json）—— 插件可能还是旧版，5 秒后重试")
            retry(after: 5)
            return
        }
        DispatchQueue.global().async { [weak self] in
            guard let self else { return }
            let pref = self.hostPref()
            var okList: [(base: String, desktop: Bool?, score: Int, ver: String)] = []
            var fallback: String?
            for base in self.candidateBases() {
                let r = self.probeHost(base, token: token)
                if r.code == 200 {
                    // 类型判定：① 插件自报（desktop:true/false，最准）
                    //           ② 端口属主进程名（老插件也有这个信号，同样与端口号无关）
                    var kind = r.desktop
                    if kind == nil, let port = Int(base.split(separator: ":").last ?? "") {
                        let owner = self.portOwners[port] ?? ""
                        self.log("调试：属主表 \(self.portOwners) → 端口 \(port) 属主=\(owner.isEmpty ? "空" : owner)")
                        if owner.contains("DeepSeek") { kind = true }
                        else if owner.contains("node") || owner.contains("dsh") { kind = false }
                    }
                    let score = self.activityOf(base, token: token)
                    okList.append((base, kind, score, r.version))
                    self.log("候选宿主可用: \(base) 类型=\(kind == true ? "桌面版" : kind == false ? "网页版" : "未知") 前端版本=\(r.version.isEmpty ? "未知" : r.version) 活跃度=\(score)")
                } else if r.code == 401, fallback == nil {
                    fallback = base
                }
            }
            // 按用户档位挑：命中就选它；没命中就用第一个可用的（绝不让她连不上）
            var pick = pref == "desktop"
                ? okList.first { $0.desktop == true }
                : pref == "web" ? okList.first { $0.desktop == false } : nil
            // 没指定档位（或档位没命中）→ 先比**前端版本**（绝不能连到旧界面 ✗），
            // 版本相同再比活跃度（谁在跑任务就连谁）
            if pick == nil {
                pick = okList.sorted { a, b in
                    if a.ver != b.ver { return a.ver > b.ver }
                    return a.score > b.score
                }.first
            }
            if pick == nil { pick = okList.first }
            DispatchQueue.main.async {
                if let p = pick {
                    let label = p.desktop == true ? "桌面版" : p.desktop == false ? "网页版" : "未知类型"
                    self.log("连上宿主（\(label)，按档位 \(pref)，前端 \(p.ver.isEmpty ? "未知" : p.ver)）: \(p.base)")
                    self.start(base: p.base, token: token)
                } else if let fb = fallback {
                    self.log("找到宿主（票可能过期，先进去看）: \(fb)")
                    self.start(base: fb, token: token)
                } else {
                    self.showHint("没找到正在运行的 DSH —— 官方桌面版和 `dsh web` 都试过了。请先打开其中一个。")
                    self.retry(after: 5)
                }
            }
        }
    }

    /// 真正开始加载某个宿主
    func start(base: String, token: String) {
        deskBase = base
        guard let u = URL(string: petURL) else { return }
        // 把通行证写成 cookie：之后页面里的 pet.js、SSE、控制接口都会自动带上它，
        // 不用改前端任何一行。
        let props: [HTTPCookiePropertyKey: Any] = [
            .name: "dsh_pet_desk", .value: token, .domain: "127.0.0.1", .path: "/",
        ]
        guard let cookie = HTTPCookie(properties: props) else {
            log("通行证 cookie 构造失败，直接尝试加载")
            web.load(URLRequest(url: u))
            return
        }
        web.configuration.websiteDataStore.httpCookieStore.setCookie(cookie) { [weak self] in
            self?.log("通行证已就位，加载 \(petURL)")
            self?.web.load(URLRequest(url: u))
        }
    }

    /// 读插件写的通行证文件（插件每次启动会确保它在）
    func deskToken() -> String? {
        let p = NSHomeDirectory() + "/.dsh/dsh-live2d-pet-desktop.json"
        guard let d = FileManager.default.contents(atPath: p),
              let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any],
              let t = o["token"] as? String, t.count >= 16
        else { return nil }
        return t
    }

    func webView(_ w: WKWebView, didFinish navigation: WKNavigation!) {
        // 把「页面标题 + DSHPet 在不在」打出来：能一眼看出是加载了桌宠页还是加载了报错页
        w.evaluateJavaScript("document.title + ' | DSHPet=' + (window.DSHPet ? 'yes' : 'no')") {
            [weak self] v, _ in
            self?.log("页面加载完成 → \(v as? String ?? "?")")
            if (v as? String ?? "").contains("DSHPet=yes") { self?.failCount = 0 }
        }
        clearBackdrops(web)
        win.makeFirstResponder(web)
        // 启动时一定先把她展开：上次退出时如果是「隐藏」状态，页面会带着 hidden 类回来，
        // 壳子会立刻收成小球 —— 主人会以为「人没了」。先把状态清掉，要收再自己收。
        // 页面启动是异步的：它读完保存的布局后可能又把自己设成 hidden，
        // 所以启动后连补几次「展开」，确保主人一开 App 就能看到她。
        for delay in [0.8, 2.0, 4.0] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                self?.web.evaluateJavaScript("window.DSHPet && DSHPet.setHidden && DSHPet.setHidden(false)",
                                             completionHandler: nil)
                self?.applyLowPower()
            }
        }
        startHealthChecks()
        // 启动后把她的位置归位一次：窗口尺寸变过之后，旧坐标可能落在看不见的地方
        for delay in [1.5, 4.0] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                self?.web.evaluateJavaScript("window.DSHPet && DSHPet.resetPosition && DSHPet.resetPosition()",
                                             completionHandler: nil)
            }
        }
        // 启动 5 秒后自己也渲染一张小球图（开发诊断用，主人不用管）
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak self] in self?.saveBallShot("boot") }
        // （自动截图已取消：那是开发期看效果用的，一次全页重绘不便宜，改成菜单里手动点）
    }

    /// 页面里的 console / 报错转发过来的入口
    func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "dshpetlog" { log(String(describing: message.body)); return }
        guard message.name == "dshpetshell" else { return }
        // 前端 → 壳子的即时指令。走消息而不是轮询页面状态：
        // 点「收起」立刻开始动画，没有 0.5 秒的延迟感。
        // ⚠️ 防回环守卫（踩过大坑）：expandFromBall() 会调用页面的 setHidden(false)，
        // 页面又会回一条 "shown" —— 没有守卫就是无限递归：
        // 日志里出现过 **5472 万条「已展开桌宠」**，CPU 打满、收起按钮完全失效。
        // 规矩：只在「状态确实需要改变」时才动。
        switch String(describing: message.body) {
        case "hidden", "collapse":
            guard win.isVisible else { return }          // 已经是收起态 → 忽略
            collapseToBall()
        case "shown", "expand":
            guard ball?.isVisible == true else { return } // 已经是展开态 → 忽略
            expandFromBall()
        case "host:auto", "host:desktop", "host:web":
            // 设置页里那个「连接」开关：记住选择，然后立刻重新发现宿主
            let v = String(String(describing: message.body).dropFirst(5))
            setHostPref(v)
            log("连接档位切成 \(v) → 重新发现宿主")
            load()
        case "open-dsh":
            // 前端那个 ↗ 符号：用默认浏览器打开 DeepSeek Harness 界面
            if let u = URL(string: deskBase + "/") { NSWorkspace.shared.open(u) }
            log("已用浏览器打开 DSH 界面（\(deskBase)）")
        case "quit":
            quitNow()
        default:
            log("壳子收到未知指令：\(message.body)")
        }
    }

    /// 彻底退出（设置页里的「彻底关闭桌宠应用」也走这里）
    @objc func quitNow() {
        log("收到退出指令，正在关闭桌宠")
        UserDefaults.standard.synchronize()
        NSApp.terminate(nil)
    }

    /// 存一张她现在的样子到 ~/.dsh/whalegirlpet-shot.png
    /// （透明窗口没法用系统截图工具抓，只能从 WebView 里自己拍；做 UI 时用它看效果）
    @objc func saveShot() {
        web.takeSnapshot(with: WKSnapshotConfiguration()) { [weak self] img, err in
            guard let self else { return }
            guard let img, let tiff = img.tiffRepresentation,
                  let rep = NSBitmapImageRep(data: tiff),
                  let png = rep.representation(using: .png, properties: [:]) else {
                self.log("截图失败：\(err?.localizedDescription ?? "未知原因")")
                return
            }
            let path = NSHomeDirectory() + "/.dsh/whalegirlpet-shot.png"
            do {
                try png.write(to: URL(fileURLWithPath: path))
                self.log("已保存截图：\(path)（\(rep.pixelsWide)×\(rep.pixelsHigh)）")
            } catch {
                self.log("截图写盘失败：\(error.localizedDescription)")
            }
        }
    }

    /// 把自己拷到「应用程序」，之后就能像普通 App 一样双击打开（Launchpad / 聚焦都能搜到）
    @objc func installApp() {
        let src = Bundle.main.bundlePath
        let dir = NSHomeDirectory() + "/Applications"
        let dest = dir + "/" + (src as NSString).lastPathComponent
        do {
            try FileManager.default.createDirectory(atPath: dir, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: dest) { try FileManager.default.removeItem(atPath: dest) }
            try FileManager.default.copyItem(atPath: src, toPath: dest)
            log("已安装到「应用程序」：\(dest)")
            NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: dest)])
        } catch {
            log("安装到「应用程序」失败：\(error.localizedDescription)")
        }
    }

    /// 每 6 秒问一次页面「你到哪一步了」：模型有没有加载出来、事件流连上没有。
    /// 桌宠是透明的，出问题时「看不见」和「没启动」长得一样，只能靠这个区分。
    func startHealthChecks() {
        health?.invalidate()
        health = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            self?.log("探针统计：本地判定 \(self?.statLocal ?? 0) 次 / 进网页 \(self?.statJS ?? 0) 次（越少越省）")
            self?.statLocal = 0
            self?.statJS = 0
        }
        health2 = Timer.scheduledTimer(withTimeInterval: 20, repeats: true) { [weak self] _ in
            guard let self, self.win.isVisible else { return }
            let js = """
            (function(){try{
              var s = (window.DSHPet && window.DSHPet.state) || null;
              var out = {
                pet: !!window.DSHPet,
                model: !!(s && s.modelSize && s.modelSize.w),
                size: s && s.modelSize ? Math.round(s.modelSize.w)+'x'+Math.round(s.modelSize.h) : null,
                expr: s && s.expressions ? s.expressions.length : null,
                mood: s ? (s.mood || s.baseMood || null) : null,
                agent: s && s.agent ? s.agent.status : null,
                clients: window.__dshpetClients || null,
                webgl: (function(){ try{ var c=document.createElement('canvas'); return !!(c.getContext('webgl')||c.getContext('experimental-webgl')) }catch(e){ return false } })(),
                raf: (function(){
                  if (window.__rafMs === undefined) { try{ requestAnimationFrame(function(){ window.__rafMs = 1 }) }catch(e){} return 'armed' }
                  return window.__rafMs
                })(),
                err: window.__DSHPetError ? String(window.__DSHPetError).slice(0,160) : null,
                bg: getComputedStyle(document.body).backgroundColor + ' / ' + getComputedStyle(document.documentElement).backgroundColor,
                hidden: document.body.classList.contains('dshp-pet-hidden'),
                panels: (function(){
                  var out=[];
                  try{
                    document.querySelectorAll('[class*="dshp-"]').forEach(function(n){
                      var r=n.getBoundingClientRect(), c=getComputedStyle(n).backgroundColor;
                      if(r.width>150 && r.height>100 && c && c!=='rgba(0, 0, 0, 0)')
                        out.push(String(n.className).split(' ')[0]+':'+Math.round(r.width)+'x'+Math.round(r.height)+':'+c);
                    });
                  }catch(e){}
                  return out.slice(0,5);
                })(),
                boot: window.__dshpetBootDone === true
              };
              return JSON.stringify(out);
            }catch(e){ return 'probe error: ' + e.message }})()
            """
            self.web.evaluateJavaScript(js) { v, _ in
                // 只在状态变化时记录，免得日志文件一直长
                let line = v as? String ?? "?"
                if line != self.lastHealth {
                    self.lastHealth = line
                    self.log("健康检查 \(line)")
                }
            }
        }
        RunLoop.current.add(health!, forMode: .common)
    }

    func webView(_ w: WKWebView, didFailProvisionalNavigation nav: WKNavigation!, withError e: Error) {
        log("加载失败：\(e.localizedDescription) —— 5 秒后重试")
        failCount += 1
        if failCount >= 3 {
            showHint("没连上 DSH（\(petURL)）。<br>请确认：① 插件已装好 ② DSH 正在运行。<br>连上之后她会自动出现。")
        }
        retry(after: 5)
    }

    func webView(_ w: WKWebView, didFail nav: WKNavigation!, withError e: Error) {
        log("加载中断：\(e.localizedDescription) —— 5 秒后重试")
        retry(after: 5)
    }

    /// 状态码不是 200（比如通行证没生效被栅栏挡成 401）就当失败处理，别把错误页留在桌面上
    func webView(_ w: WKWebView, decidePolicyFor resp: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let http = resp.response as? HTTPURLResponse, http.statusCode != 200 {
            decisionHandler(.cancel)
            log("页面返回 HTTP \(http.statusCode) —— 3 秒后重试（若一直是 401：插件需要重启一次 DSH）")
            retry(after: 3)
            return
        }
        decisionHandler(.allow)
    }

    /// 让她「可见时满速、不可见时让系统降频」。
    ///
    /// 之前用的是 .latencyCritical（最激进的档）+ 一直不释放 —— 结果就是她永远满帧渲染，
    /// 浏览器里标签页不聚焦会自动降频、壳子里不会，所以主人在 Mac 上觉得又热又卡。
    /// 现在：只在她可见时申请，收起成小球就释放，让 macOS 的 App Nap 接管。
    func beginAwake() {
        if activity == nil {
            activity = ProcessInfo.processInfo.beginActivity(
                options: [.userInitiated], reason: "DS 鲸鱼娘可见时需要持续渲染")
        }
    }

    func endAwake() {
        if let a = activity {
            ProcessInfo.processInfo.endActivity(a)
            activity = nil
        }
    }

    /// 低性能模式：帧率 20、渲染分辨率 1 倍、去掉自言自语和自主动作
    @objc func toggleLowPower(_ item: NSMenuItem) {
        let on = !(UserDefaults.standard.object(forKey: K_LOW) as? Bool ?? false)
        UserDefaults.standard.set(on, forKey: K_LOW)
        item.state = on ? .on : .off
        applyLowPower()
    }

    func applyLowPower() {
        let on = UserDefaults.standard.object(forKey: K_LOW) as? Bool ?? false
        web.evaluateJavaScript("window.DSHPet && DSHPet.setLowPower && DSHPet.setLowPower(\(on))",
                               completionHandler: nil)
        // 把「连接档位」告诉页面，设置页里的三个按钮才能正确高亮
        web.evaluateJavaScript("window.DSHPet && DSHPet.setHostPref && DSHPet.setHostPref('\(hostPref())')",
                               completionHandler: nil)
    }

    /// 把视图树里所有「白色底」拆掉。
    /// 为什么需要：WKWebView 内部包着 NSScrollView，它的 drawsBackground 默认是 true（白），
    /// 而旧的 setDrawsBackground 私有键在新系统上已经没了 —— 这就是「大白框」的来源。
    /// 用运行时反射列出 WKWebView 上跟「背景 / 不透明」有关的私有方法名。
    /// 为什么要这么土：setDrawsBackground 这个老私有键在新系统上已经不存在了，
    /// 得知道现在到底叫什么才能把白底关掉。
    func dumpBackgroundMethods() {
        var count: UInt32 = 0
        guard let methods = class_copyMethodList(WKWebView.self, &count) else { return }
        var hits: [String] = []
        for i in 0..<Int(count) {
            let name = NSStringFromSelector(method_getName(methods[i]))
            let low = name.lowercased()
            if low.contains("background") || low.contains("opaque") || low.contains("draws") {
                hits.append(name)
            }
        }
        free(methods)
        // 同时看看父类 NSView 那边有没有相关可用的
        log("WKWebView 背景相关方法: " + (hits.isEmpty ? "（一个都没有）" : hits.joined(separator: ", ")))
    }

    @discardableResult
    func clearBackdrops(_ v: NSView) -> Int {
        var n = 0
        v.wantsLayer = true
        v.layer?.backgroundColor = NSColor.clear.cgColor
        if let sv = v as? NSScrollView {
            sv.drawsBackground = false
            sv.backgroundColor = .clear
            n += 1
        }
        for sub in v.subviews { n += clearBackdrops(sub) }
        return n
    }

    /// 把窗口内容渲染到位图里，量几个角落的像素 alpha：
    /// 全透明 = 修复成功；白色不透明 = 还有底没拆掉。
    func probeWindowAlpha() {
        let n = clearBackdrops(web)
        log("透明量测：又拆了一遍白底，本次找到 NSScrollView \(n) 个")

        func px(_ rep: NSBitmapImageRep?, _ label: String) {
            guard let rep else { log("\(label)：拿不到位图"); return }
            var out: [String] = []
            for (x, y) in [(3, 3), (Int(win.frame.width) - 4, 3), (3, Int(win.frame.height) - 4)] {
                if x < rep.pixelsWide, y < rep.pixelsHigh, let c = rep.colorAt(x: x, y: y) {
                    out.append(String(format: "(%d,%d)=r%.2f g%.2f b%.2f a%.2f",
                                      x, y, c.redComponent, c.greenComponent, c.blueComponent, c.alphaComponent))
                }
            }
            log("\(label)：\(out.joined(separator: "  "))")
        }

        // ① 对照实验：先把她自己的所有面板/气泡/工具栏藏掉，快照一次。
        //    如果这时角落还是白的，白底就与她无关，是 WebView 自己的。
        web.evaluateJavaScript("""
        (function(){var s=document.createElement('style');s.id='dshpet-probe-hide';
          s.textContent='[class*="dshp-"]{display:none!important}';document.head.appendChild(s);return 1})()
        """) { [weak self] _, _ in
            guard let self else { return }
            self.web.takeSnapshot(with: WKSnapshotConfiguration()) { img, _ in
                let rep = img.flatMap { $0.tiffRepresentation }.flatMap { NSBitmapImageRep(data: $0) }
                px(rep, "藏起她全部 UI 后的角落")
                self.web.evaluateJavaScript("var e=document.getElementById('dshpet-probe-hide'); e&&e.remove()",
                                            completionHandler: nil)
            }
        }

        // ② 网页内容自己的快照：它透明就说明白底来自 WebView 而不是页面
        web.takeSnapshot(with: WKSnapshotConfiguration()) { [weak self] img, err in
            guard let self else { return }
            let rep = img.flatMap { $0.tiffRepresentation }.flatMap { NSBitmapImageRep(data: $0) }
            px(rep, "网页快照角落" + (err == nil ? "" : "（err=\(err!.localizedDescription)）"))
        }

        // ② 窗口在屏幕上的真实样子（没有屏幕录制权限时拿不到，拿不到就说明权限不够）
        if let cg = CGWindowListCreateImage(.null, .optionIncludingWindow,
                                            CGWindowID(win.windowNumber), [.boundsIgnoreFraming]) {
            px(NSBitmapImageRep(cgImage: cg), "屏幕上的窗口角落")
        } else {
            log("屏幕上的窗口位图拿不到（缺「屏幕录制」权限，属正常，用网页快照判断）")
        }
    }

    /// 日志同时进 stderr 和 ~/.dsh/whalegirlpet.log，出问题时能直接看
    func log(_ s: String) {
        // 同一条消息 1 秒内只记一次：万一又出现循环，日志不会炸成几十万行
        let now = Date()
        if s == lastLogText && now.timeIntervalSince(lastLogAt) < 1 { return }
        lastLogText = s
        lastLogAt = now
        let line = "[\(now.formatted(date: .omitted, time: .standard))] \(s)\n"
        FileHandle.standardError.write(line.data(using: .utf8)!)
        let path = NSHomeDirectory() + "/.dsh/whalegirlpet.log"
        if let h = FileHandle(forWritingAtPath: path) {
            h.seekToEndOfFile(); h.write(line.data(using: .utf8)!); try? h.close()
        } else {
            try? line.write(toFile: path, atomically: true, encoding: .utf8)
        }
    }

    /// DSH 没起来时给一张可读的提示页（透明窗口里一片空白，用户不知道发生了什么）
    func showHint(_ detail: String) {
        let html = """
        <!doctype html><meta charset="utf-8"><style>
        html,body{margin:0;height:100%;background:transparent}
        body{display:flex;align-items:center;justify-content:center;
          font:13px/1.7 -apple-system,"PingFang SC",sans-serif;color:#fff;text-align:center}
        .box{background:rgba(18,22,34,.88);border:1px solid rgba(255,255,255,.18);
          border-radius:14px;padding:16px 20px;max-width:78%;backdrop-filter:blur(8px)}
        .t{font-weight:600;margin-bottom:6px;font-size:14px}
        .s{opacity:.72;font-size:12px}
        </style><body><div class="box">
        <div class="t">🐋 正在找 DSH…</div>
        <div class="s">\(detail)</div></div></body>
        """
        web.loadHTMLString(html, baseURL: nil)
    }

    /// DSH 还没启动 / 正在重启时不至于一片空白：过几秒自己再试
    func retry(after seconds: Double = 5) {
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) { [weak self] in self?.load() }
    }

    func savePosition() {
        UserDefaults.standard.set(Double(win.frame.origin.x), forKey: K_X)
        UserDefaults.standard.set(Double(win.frame.origin.y), forKey: K_Y)
    }

    func restorePosition() {
        let d = UserDefaults.standard
        guard d.object(forKey: K_X) != nil else { return resetPos() }
        var p = NSPoint(x: d.double(forKey: K_X), y: d.double(forKey: K_Y))
        // ⚠️ 这里必须「整个窗口都在可见区域里」，不只是「跟屏幕有交集」。
        // 踩过的坑：窗口从 560×620 放大到 900×760，旧坐标没变 ——
        // 窗口往右下长大，而她待在窗口**右下角**，于是被整个推到屏幕外，
        // 表现就是「怎么点都看不见她」，而且退出重开也没用（坐标存在偏好里）。
        if let vf = (NSScreen.main ?? NSScreen.screens.first)?.visibleFrame {
            p.x = min(max(p.x, vf.minX + 8), max(vf.minX + 8, vf.maxX - WIN_W - 8))
            p.y = min(max(p.y, vf.minY + 8), max(vf.minY + 8, vf.maxY - WIN_H - 8))
        }
        win.setFrameOrigin(p)
        log("恢复位置 → (\(Int(p.x)),\(Int(p.y))) 窗口 \(Int(WIN_W))×\(Int(WIN_H))")
    }

    // MARK: - 菜单动作

    /// 兜底自检：窗口（尤其是她所在的右下角那块）必须在屏幕可见范围内，否则搬回来
    func ensureVisible() {
        guard let vf = (NSScreen.main ?? NSScreen.screens.first)?.visibleFrame else { return }
        let f = win.frame
        if f.maxX > vf.maxX || f.minX < vf.minX || f.maxY > vf.maxY || f.minY < vf.minY {
            log("窗口跑到屏幕外了（\(Int(f.minX)),\(Int(f.minY)) \(Int(f.width))×\(Int(f.height))）→ 搬回右下角")
            resetPos()
        }
    }

    @objc func reload() { load() }

    /// 双击一个「已经在运行」的 App 时系统不会新起进程，只会激活它 ——
    /// 我们是后台型 App（无 Dock 图标），如果什么都不做，用户会以为「打不开」。
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if let b = ball, b.isVisible { expandFromBall() }
        if !NSScreen.screens.contains(where: { $0.visibleFrame.intersects(win.frame) }) { resetPos() }
        win.orderFrontRegardless()
        log("用户又点了一次图标 → 把桌宠叫到前面")
        return true
    }

    /// 连页面里的位置一起归位（她自己的坐标存在页面里，光搬窗口不够）
    @objc func resetPetPosition() {
        web.evaluateJavaScript("window.DSHPet && DSHPet.resetPosition && DSHPet.resetPosition()",
                               completionHandler: nil)
        resetPos()
    }

    @objc func resetPos() {
        guard let vf = (NSScreen.main ?? NSScreen.screens.first)?.visibleFrame else { return }
        win.setFrameOrigin(NSPoint(x: vf.maxX - WIN_W - 8, y: vf.minY + 8))
        savePosition()
    }

    @objc func toggleTop(_ item: NSMenuItem) {
        let on = !(UserDefaults.standard.object(forKey: K_TOP) as? Bool ?? true)
        UserDefaults.standard.set(on, forKey: K_TOP)
        item.state = on ? .on : .off
        win.level = on ? .floating : .normal
    }

    @objc func openDiag() {
        if let u = URL(string: deskBase + "/dsh-pet/diag") { NSWorkspace.shared.open(u) }
    }

    @objc func openHome() {
        NSWorkspace.shared.open(URL(fileURLWithPath: NSHomeDirectory() + "/.dsh"))
    }

    @objc func quit() { NSApp.terminate(nil) }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
