#!/usr/bin/env node
/* ============================================================================
 * chaoxing-autolearn.js — 学习通网页版课程视频学习自动化引擎
 * ============================================================================
 *
 * 【这是什么】
 *   一个零 npm 依赖的单文件引擎，用 CDP（Chrome DevTools Protocol）驱动一个真实
 *   Chromium，把「看课」变成一个可调度、可观测、可优雅停止的后台任务。
 *   通常由 dsh-cx-learn 插件调用；也可以脱离插件独立运行。
 *
 * 【为什么用真实浏览器，而不是直接调接口】
 *   1. 课程平台的视频进度由页面自身的播放器 JS 上报，只有真实浏览器里的真实播放
 *      行为才与「页面正常行为」等价。HTTP 重放需要复刻 enc 等私有签名协议，
 *      接口一变即碎，且极易触发风控——故不采用。
 *   2. CDP 适配层可以零 npm 依赖实现（不引入 puppeteer/playwright），单文件即可
 *      放进任意 Node 22+ 环境运行。
 *   3. 业务状态机与浏览器实现完全解耦：把「浏览器操作」收敛为一组最小原语
 *      （DSH_ADAPTER），任何符合原语签名的实现（CDP / browser_* MCP）都能替换
 *      适配层，而状态机一行不动。
 *
 * 【能力】
 *   P0 播放态检测与防挂机弹窗恢复 / P1 自然结束自动切下一节 / P2 弹题作答 /
 *   P3 跳过已完成任务点 / P4 章节模式与最大节数上限。
 *
 * 【前提】
 *   - 存在 Chromium/Chrome 可执行文件（可用 CX_CHROMIUM 指定路径）；首次运行
 *     由脚本以独立 profile 启动，用户人工登录一次（脚本绝不自动登录）。
 *   - 课程学习页 URL 由 CONFIG.course.url / CX_COURSE_URL / --course-url 提供，
 *     或让浏览器停留在该页面后省略。
 *   - 目录/弹窗 DOM 随课程模板变化，故本脚本不依赖任何单一脆弱选择器，
 *     采用「语义 → 结构 → 通用兜底」三层探测策略。
 *
 * 【免责声明】
 *   本脚本用于浏览器自动化技术研究。学习通等教育平台普遍禁止自动化脚本，
 *   使用可能导致学习进度被退回或账号处罚。使用者需自行确认所在平台的政策与
 *   当地法规，并自行承担全部责任。
 *
 *   脚本本身不篡改后端数据、不伪造进度上报、不调用任何进度写接口；所有动作均为
 *   模拟页面点击/播放行为；一旦检测到人脸识别、活体检测、验证码等人工验证特征
 *   立即停止，不做任何绕过。启动日志会再次输出本声明。
 *
 * 【运行形态】
 *   (a) 独立脚本：node chaoxing-autolearn.js --max-sections=10 --course-url=<url>
 *   (b) 模块调用：require 后调用导出的 run(overrides) async 函数
 *   (c) MCP 工具：node chaoxing-autolearn.js --serve-mcp 内建零依赖 MCP stdio
 *       server，注册后 Agent 即可通过 cx_learn（刷课）/ cx_login（扫码登录）
 *       两个工具触发，并拿到结构化结果。
 *   首次使用：node chaoxing-autolearn.js --login 完成一次手机扫码登录，
 *   登录态持久化在 CX_PROFILE_DIR，此后长期复用。
 * ==========================================================================*/
'use strict';

/* ============================================================================
 * 第 0 节 · 基础（零 npm 依赖，仅 Node 内置）
 * ==========================================================================*/
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

/* ============================================================================
 * 分层：浏览器层 ↔ 业务层 的中间层
 * ============================================================================
 * 两个人在同一个文件上改代码，git 天天冲突，而且互相破坏假设。
 * 现在规定两层的沟通方式只有两个：
 *   1. adapter 实例的方法调用（契约见 engine/adapter-contract.js）
 *   2. 中间状态文件（engine/.state/*.json，读写在 engine/state-bus.js）
 *
 * 任何人都不许再去读对方的内部变量、也不许依赖对方日志的格式。
 * 契约被破坏时，启动自检会直接报 ADAPTER_CONTRACT_VIOLATION。
 * ==========================================================================*/
let CONTRACT = null;
let BUS = null;
try {
  CONTRACT = require('./adapter-contract.js');
  BUS = require('./state-bus.js');
} catch (e) {
  /* 契约/总线文件缺失不能让引擎起不来，但要留下痕迹 */
  try { console.error('[warn] 分层中间件加载失败（功能降级）：' + String((e && e.message) || e)); } catch (_) {}
}
/** 安全地往事件流里写一条；BUS 不可用时就静默跳过 */
function busEmit(layer, kind, data) {
  try { if (BUS && BUS.emit) BUS.emit(layer, kind, data); } catch (_) {}
}

const VERSION = '1.0.0';

/* 题目事件只用于「识别 -> 人工审阅」链路：不带答案，不触发页面动作。
 * 文件路径每次调用时从环境变量读取：宿主经 spawn 注入；独立运行/自测可动态指定。 */
const emittedQuestionKeys = new Set();
function questionEventId(kind, question, options) {
  const raw = [kind, question, ...(options || []).map((o) => (o && (o.label || o.letter)) || '')].join('|');
  let h = 2166136261;
  for (let i = 0; i < raw.length; i++) { h ^= raw.charCodeAt(i); h = Math.imul(h, 16777619); }
  return 'q-' + (h >>> 0).toString(16);
}
function emitQuestionEvent(event) {
  const questionFile = process.env.CX_QUESTION_FILE || '';
  if (!questionFile || !event || !event.kind) return '';
  const id = event.id || questionEventId(event.kind, event.question, event.options);
  if (emittedQuestionKeys.has(id)) return id;
  emittedQuestionKeys.add(id);
  const record = {
    event: 'question_detected', id, detectedAt: new Date().toISOString(),
    ...event, id,
  };
  try {
    fs.mkdirSync(path.dirname(questionFile), { recursive: true });
    fs.appendFileSync(questionFile, JSON.stringify(record) + '\n');
  } catch (e) {
    logger.warn('QUIZ', '题目事件写入失败', { error: String(e && e.message || e).slice(0, 160) });
  }
  return id;
}

/** 致命停止异常：携带稳定错误码，run() 捕获后写入结果，绝不重试。 */
class FatalStop extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = 'FatalStop';
  }
}

/** 底层定时原语：仅适配器与 humanize 允许使用，业务代码禁止散落 sleep。 */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ============================================================================
 * 第 0 节 · 内核启动参数（纯函数，可单测，不含任何 I/O）
 * ----------------------------------------------------------------------------
 * 为什么要单独抽出来：
 *   1. 这些参数决定「无头内核能不能稳定跑完一节 40 分钟的视频」，
 *      是最容易悄悄失效的一层，必须能被自测直接断言。
 *   2. 用户/环境追加的参数（extraArgs）不可信：可能重复、可能与引擎必需的
 *      参数冲突（典型：自己填了 --remote-debugging-port=9222 把引擎的顶掉，
 *      或填了 --user-data-dir 导致登录态进错目录）。这里统一去重合并。
 *
 * 参数来源与依据（2026-10-29 对照上游源码）：
 *   · Playwright  chromiumSwitches.ts   → 防节流/防遮挡那三条 + 一批降噪开关
 *   · browser-use profile.py（:84）     → CalculateNativeWinOcclusion 的用途注释
 *   · Chromium    media_switches.cc:46  → autoplay-policy=no-user-gesture-required
 * ==========================================================================*/

/**
 * 单值参数（同名只保留一个，后者覆盖前者）。
 * 判断依据：`--name=value` 形式且语义上「只有一个取值有意义」。
 * 列全是为了避免出现 `--window-size=1366,900 --window-size=800,600` 这种
 * 「谁生效看 Chromium 心情」的状态。
 */
const CHROMIUM_SINGLE_VALUED_FLAGS = [
  '--remote-debugging-port', '--remote-debugging-address', '--remote-debugging-pipe',
  '--user-data-dir', '--profile-directory', '--window-size', '--window-position',
  '--headless', '--proxy-server', '--proxy-bypass-list', '--user-agent',
  '--autoplay-policy', '--disable-features', '--enable-features',
  '--blink-settings', '--disk-cache-dir', '--lang', '--force-color-profile',
  '--host-resolver-rules', '--log-level', '--crash-dumps-dir',
];

/** 布尔型参数（无值，出现即生效；去重只保留一次）。 */
const CHROMIUM_BOOLEAN_FLAGS = [
  '--no-sandbox', '--no-first-run', '--no-default-browser-check', '--disable-infobars',
  '--mute-audio', '--no-proxy-server', '--headless', '--hide-scrollbars',
  '--disable-gpu', '--disable-dev-shm-usage', '--disable-session-crashed-bubble',
  '--disable-search-engine-choice-screen', '--disable-breakpad', '--no-service-autorun',
  '--disable-component-update', '--password-store=basic', '--use-mock-keychain',
  '--disable-background-timer-throttling', '--disable-backgrounding-occluded-windows',
  '--disable-renderer-backgrounding', '--disable-background-networking',
  '--disable-ipc-flooding-protection', '--disable-hang-monitor',
  '--disable-popup-blocking', '--disable-prompt-on-repost', '--disable-field-trial-config',
  '--metrics-recording-only', '--allow-pre-commit-input', '--start-minimized',
  '--disable-extensions', '--disable-default-apps', '--disable-component-extensions-with-background-pages',
  '--disable-back-forward-cache', '--disable-sync', '--no-pings',
];

/** 解析 `--flag=value` / `--flag` 的名字部分（不含值）。 */
function chromiumFlagName(arg) {
  const s = String(arg || '');
  const i = s.indexOf('=');
  return i < 0 ? s : s.slice(0, i);
}

/**
 * 合并启动参数：按「单值覆盖、布尔去重、其余追加」的语义去重。
 * 后面的覆盖前面的 —— 因此把「用户参数」放在「引擎必需参数」之前调用即可让
 * 引擎的必需值胜出（见 buildChromiumArgs 的调用顺序）。
 *
 * 特别处理 `--disable-features` / `--enable-features`：它们是逗号列表，
 * 直接覆盖会丢掉另一方的条目，所以各自做并集。
 *
 * ★ 2026-10-29 修 bug：原先两个列表共用同一个 featureSet，
 *   结果只要用户传了 --enable-features，引擎的 CalculateNativeWinOcclusion
 *   就会同时出现在 enable 和 disable 两行里 —— 而 Chromium 里 enable 优先，
 *   等于把防遮挡修复悄悄抵消掉。现在两条列表完全独立。
 */
function mergeChromiumArgs(...groups) {
  const single = new Map();   // name -> 完整参数串
  const booleans = new Set(); // name
  const others = [];          // 未登记的其它参数，保持顺序并去重
  const disableFeatures = new Set();
  const enableFeatures = new Set();
  let disableSeen = false;
  let enableSeen = false;

  for (const group of groups) {
    for (const raw of (group || [])) {
      if (!raw || typeof raw !== 'string') continue;
      const name = chromiumFlagName(raw);

      if (name === '--disable-features' || name === '--enable-features') {
        const val = raw.indexOf('=') < 0 ? '' : raw.slice(raw.indexOf('=') + 1);
        const bucket = name === '--disable-features' ? disableFeatures : enableFeatures;
        for (const f of val.split(',')) { const t = f.trim(); if (t) bucket.add(t); }
        if (name === '--disable-features') disableSeen = true; else enableSeen = true;
        // 记下是 disable 还是 enable，稍后按名字回填
        single.set(name, name);
        continue;
      }
      if (CHROMIUM_SINGLE_VALUED_FLAGS.indexOf(name) >= 0) { single.set(name, raw); continue; }
      if (CHROMIUM_BOOLEAN_FLAGS.indexOf(name) >= 0) { booleans.add(name); continue; }
      if (others.indexOf(raw) < 0) others.push(raw);
    }
  }

  const out = [];
  for (const [name, val] of single) {
    if (name === '--disable-features' || name === '--enable-features') continue; // 下面单独拼
    out.push(val);
  }
  if (disableSeen) out.push('--disable-features=' + Array.from(disableFeatures).join(','));
  if (enableSeen) out.push('--enable-features=' + Array.from(enableFeatures).join(','));
  for (const b of booleans) out.push(b);
  out.push(...others);
  return out;
}

/**
 * 构造完整的 Chromium 启动参数。
 *
 * 顺序即优先级：先用户参数，再引擎必需参数 —— 后者覆盖前者。
 * 返回的数组**不含** `about:blank`（由调用方追加，便于单测断言）。
 *
 * @param {object} opts
 * @param {boolean} opts.headless        无头模式
 * @param {number}  opts.port            CDP 端口；0 = 让浏览器自选
 * @param {string}  opts.profileDir      user-data-dir（空则不加）
 * @param {boolean} opts.shellKernel     内核是 chrome-headless-shell（旧 headless 独立二进制）
 * @param {string[]} opts.userArgs       用户/环境追加参数（会被去重合并）
 */
function buildChromiumArgs(opts) {
  const o = opts || {};
  const userArgs = Array.isArray(o.userArgs) ? o.userArgs : [];

  /* 引擎必需：稳定性与可控性，优先级高于用户参数 */
  const required = [];

  /* 端口：0 让 Chromium 自己挑空闲端口，避免多实例互抢 */
  required.push('--remote-debugging-port=' + (o.port === undefined ? 0 : o.port));
  required.push('--remote-debugging-address=127.0.0.1');

  /* 无头。chrome-headless-shell 本身就是旧 headless 二进制，不需要也不该再带
     --headless=new（它不是新版 Chrome，收到该参数没有「新无头」可切）。
     这一条是 2026-10-29 对照官方文档后的修正：旧 headless 自 Chrome 120 起
     以独立二进制发布，与 --headless=new 是两条不同的实现路径。 */
  if (o.headless) {
    if (o.shellKernel) required.push('--headless');
    else required.push('--headless=new');
  }

  if (o.profileDir) required.push('--user-data-dir=' + o.profileDir);

  /* ★ 防节流三件套（Playwright / browser-use 同款）
     无头跑长任务时，Chromium 会把「不可见/被遮挡」的页面判为后台：
       · 定时器降频（setInterval 从 4s 变几十秒）→ 轮询播放态像卡死
       · 渲染进程降优先级（rAF 停摆）→ 播放器进度条不再刷新
       · 遮挡判定（CalculateNativeWinOcclusion）在 Windows 上尤其激进
     本项目靠定时器轮询 + 页面内播放器自身推进，这三条缺一不可。 */
  required.push('--disable-background-timer-throttling');
  required.push('--disable-backgrounding-occluded-windows');
  required.push('--disable-renderer-backgrounding');
  required.push('--disable-features=CalculateNativeWinOcclusion');

  /* ★ 自动播放：不要求用户手势。
     没有它时，跨域 iframe 里的 video.play() 可能被拒（NotAllowedError），
     本引擎虽有 Runtime.evaluate{userGesture:true} 兜底，但那是每次打补丁；
     内核级放开更接近「用户已允许」的稳定语义。 */
  required.push('--autoplay-policy=no-user-gesture-required');

  /* 静默与降噪：不弹首启向导、不弹恢复气泡、不连更新/崩溃上报 */
  required.push('--no-first-run');
  required.push('--no-default-browser-check');
  required.push('--disable-session-crashed-bubble');
  required.push('--disable-search-engine-choice-screen');
  required.push('--disable-breakpad');
  required.push('--no-service-autorun');
  required.push('--disable-component-update');
  required.push('--password-store=basic');
  required.push('--disable-infobars');

  /* 无头下没有可用音频设备，静音避免音频线程空转；也防止真实发声打扰 */
  if (o.headless) required.push('--mute-audio');

  return mergeChromiumArgs(userArgs, required);
}

/**
 * 从 profile 目录读回 Chromium 实际监听的端口。
 *
 * Chromium 在 --remote-debugging-port=<非0> 或 0 时，会把真实端口写进
 * <user-data-dir>/DevToolsActivePort，格式为两行（Chromium
 * content/browser/devtools/devtools_http_handler.cc:313）：
 *     54195
 *     /devtools/browser/5c80ab5f-690a-4294-a449-6178518687c7
 *
 * 返回 { port, browserPath } 或 null（文件还没写出来 / 内容不合法）。
 */
function readDevToolsActivePort(profileDir) {
  if (!profileDir) return null;
  const file = path.join(profileDir, 'DevToolsActivePort');
  let raw = '';
  try { raw = fs.readFileSync(file, 'utf8'); } catch (_) { return null; }
  const lines = String(raw).split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  if (!lines.length) return null;
  const port = Number(lines[0]);
  if (!Number.isInteger(port) || port <= 0 || port > 65535) return null;
  return { port, browserPath: lines[1] || '' };
}

/**
 * 判断内核是不是 chrome-headless-shell 这类「旧 headless 独立二进制」。
 * 依据文件名 —— 与 README 里列出的可执行文件名保持一致。
 */
function isHeadlessShellKernel(exePath) {
  const base = path.basename(String(exePath || '')).toLowerCase().replace(/\.exe$/, '');
  return base === 'chrome-headless-shell' || base === 'headless_shell';
}

/**
 * 判断内核路径是不是「裸命令名」（依赖 PATH 查找，如 'chromium'）。
 *
 * 为什么必须区分：
 *   CONFIG.chromium.executablePath 的默认值就是 'chromium' —— 一个靠 PATH 解析的裸名。
 *   实测（2026-10-29，Windows）：PATH 里能解析的命令（where.exe / ping.exe / certutil.exe），
 *   fs.existsSync('where.exe') === false，但 spawn 能正常启动。
 *   所以任何用 existsSync 判断「内核是否存在」的代码，都会把这种合法配置误杀成
 *   「内核可执行文件不存在」。
 *
 * 判定口径：不含路径分隔符、不是绝对路径、不是显式相对路径（./x、../x）。
 */
function isBareCommandName(exePath) {
  const s = String(exePath || '').trim();
  if (!s) return false;
  if (s.indexOf('/') >= 0 || s.indexOf('\\') >= 0) return false;
  if (/^[A-Za-z]:/.test(s)) return false;          // Windows 盘符
  if (s === '.' || s === '..') return false;
  if (s.indexOf('./') === 0 || s.indexOf('../') === 0) return false;
  return true;
}

/**
 * 解析出「当前实际可用的 CDP 端口」。
 *
 * cfg.cdp.port 非 0 → 直接用（用户显式指定 / 附着外部浏览器）。
 * cfg.cdp.port 为 0 → 从 profile 目录的 DevToolsActivePort 读回真实端口。
 * 都拿不到 → 返回 0（调用方应视作「端点未知」，不要拼 URL 硬试）。
 *
 * 供模块级函数（listTargets / 登录流程清理标签页等）使用，
 * 它们不在 createCdpAdapter 闭包里，拿不到 _activePort。
 */
function resolveCdpPort(cfg) {
  const c = cfg || CONFIG;
  const explicit = Number((c.cdp && c.cdp.port) || 0);
  if (explicit > 0) return explicit;
  const prof = (c.chromium && c.chromium.profileDir) || '';
  const active = readDevToolsActivePort(prof);
  return active ? active.port : 0;
}

/* ----------------------------------------------------------------------------
 * 内核启动失败的归因（纯函数，可单测）
 * ----------------------------------------------------------------------------
 * 2026-10-29 实测出来的两条事实：
 *   1. Chromium 启动失败时**基本不往 stderr 写东西**给上层看 —— 我们接到的
 *      stderr 常常是空的，真正的错误在它自己打的主进程日志里。
 *   2. 两种完全不同的故障给出**同一个退出码 21**：
 *        a) profile 已被另一个浏览器实例占用（ProcessSingleton 冲突）
 *        b) profile 目录不可写（Lock file can not be created）
 *      实测：共用同一 --user-data-dir 的第二个实例，4 秒内静默退出，exit=21，
 *      stderr 为空；而不可写目录同样是 exit=21，但 stderr 里有
 *      "Lock file can not be created! Error code: 5"。
 * 所以只看退出码无法区分，必须结合 stderr 与 profile 现状一起判断。
 * --------------------------------------------------------------------------*/

/** Chromium 的退出码含义（只收录我们能给出可操作建议的那几个）。 */
const CHROMIUM_EXIT_CODES = {
  21: 'profile 被占用或不可写（RESULT_CODE_PROFILE_IN_USE）',
  22: '命令行走参数有误',
  33: '初始化失败（常见于缺少系统依赖）',
  127: '找不到动态库',
};

/**
 * 判断 profile 目录当前是否被别的浏览器实例占着。
 *
 * 依据（都是实测存在的产物）：
 *   · Windows / 跨平台通用：<profile>/Default/LOCK（单文件锁）
 *   · Linux/macOS：<profile>/SingletonLock（符号链接，指向 hostname-pid）
 *   · 部分版本：<profile>/SingletonSocket / SingletonCookie
 *
 * 注意：LOCK 文件存在**不等于**一定被占用（异常退出会留下残留文件），
 * 所以本函数只作为「提示」，不单独用来否决启动。
 * 返回 { locked, evidence }。
 */
function inspectProfileLock(profileDir) {
  if (!profileDir) return { locked: false, evidence: [] };
  const evidence = [];
  const candidates = [
    path.join(profileDir, 'SingletonLock'),
    path.join(profileDir, 'SingletonSocket'),
    path.join(profileDir, 'SingletonCookie'),
    path.join(profileDir, 'Default', 'LOCK'),
  ];
  for (const f of candidates) {
    try { if (fs.existsSync(f)) evidence.push(f); } catch (_) { /* 无权限就读不到，忽略 */ }
  }
  return { locked: evidence.length > 0, evidence };
}

/** profile 目录是否可写（真正尝试建一个临时文件，比查 ACL 可靠）。 */
function isProfileWritable(profileDir) {
  if (!profileDir) return true;
  const probe = path.join(profileDir, '.cx-write-probe-' + process.pid);
  try {
    fs.mkdirSync(profileDir, { recursive: true });
    fs.writeFileSync(probe, 'x');
    fs.unlinkSync(probe);
    return true;
  } catch (_) {
    try { fs.unlinkSync(probe); } catch (__) { /* ignore */ }
    return false;
  }
}

/**
 * 把「spawn 错误 / 退出码 / stderr / profile 现状」翻译成一句人能照着做的话。
 *
 * @param {number|null} code        进程退出码（拿不到传 null）
 * @param {string} stderr           内核 stderr（通常为空）
 * @param {object} cfg              配置（用其中的 chromium.profileDir）
 * @param {string} [spawnError]     spawn 自身抛的错（如 'ENOENT spawn ...'），优先级最高
 * @returns {{code, reason, hint, detail}} 永远返回对象，便于日志与测试断言
 */
function describeLaunchExit(code, stderr, cfg, spawnError) {
  const text = String(stderr || '');
  const spawn = String(spawnError || '');
  const prof = (cfg && cfg.chromium && cfg.chromium.profileDir) || '';
  const exe = (cfg && cfg.chromium && cfg.chromium.executablePath) || '';
  const out = {
    code: code === undefined ? null : code,
    reason: '',
    hint: '',
    detail: text ? text.slice(-600) : '',
  };

  /* spawn 层面的错误最确定：进程根本没起来，不必再看退出码 */
  if (spawn) {
    if (/ENOENT/.test(spawn)) {
      /* 裸命令名（默认值 'chromium'）找不到，是 PATH 问题，不是"路径写错" */
      if (isBareCommandName(exe)) {
        out.reason = '在 PATH 中找不到内核命令「' + exe + '」';
        out.hint = '把内核放到 PATH 里，或用 CX_CHROMIUM / 设置页指定内核的绝对路径。';
      } else {
        out.reason = '内核可执行文件不存在：' + exe;
        out.hint = '检查路径是否正确（可用 CX_CHROMIUM 指定）；NAS/容器里注意挂载点与架构。';
      }
      return out;
    }
    if (/EACCES|EPERM/.test(spawn)) {
      out.reason = '内核不可执行（权限不足）：' + exe;
      out.hint = '检查文件执行权限（Linux 上需 chmod +x），以及是否被安全策略拦截。';
      return out;
    }
    if (/ENOEXEC/.test(spawn)) {
      out.reason = '内核不是可执行文件或架构不匹配：' + exe;
      out.hint = '确认下载的是对应平台/架构的构建（x64 机器上别放 arm64 包）。';
      return out;
    }
  }

  /* stderr 里的原文优先级最高 —— 它最具体 */
  if (/Lock file can not be created/i.test(text)) {
    out.reason = 'profile 目录不可写（Chromium 无法创建锁文件）';
    out.hint = '检查目录权限：' + prof + '；容器里注意属主是否为运行用户。';
    return out;
  }
  if (/Failed to create a ProcessSingleton/i.test(text)) {
    out.reason = 'profile 被另一个浏览器实例占用（ProcessSingleton 冲突）';
    out.hint = '先确认没有残留实例，或换一个 --user-data-dir：' + prof;
    return out;
  }
  if (/No usable sandbox/i.test(text)) {
    out.reason = '内核缺少可用沙箱（容器/NAS 常见）';
    out.hint = '在 extraArgs 里加 --no-sandbox（本项目默认已加）。';
    return out;
  }
  if (/cannot open shared object file|error while loading shared libraries/i.test(text)) {
    out.reason = '内核缺少系统动态库';
    out.hint = '补齐依赖库；chrome-headless-shell 的依赖比完整 Chrome 少，可优先试它。';
    return out;
  }

  /* 没有可用 stderr 时，按退出码 + 现场推断 */
  if (code === 21) {
    const lock = inspectProfileLock(prof);
    const writable = isProfileWritable(prof);
    if (!writable) {
      out.reason = 'profile 目录不可写（退出码 21，且写入探测失败）';
      out.hint = '修正目录权限：' + prof;
      return out;
    }
    if (lock.locked) {
      out.reason = 'profile 疑似被占用（退出码 21，发现锁文件）';
      out.hint = '若无其它实例在跑，删掉这些残留锁后重试：' + lock.evidence.join(', ');
      return out;
    }
    out.reason = 'profile 不可用（退出码 21 = PROFILE_IN_USE，但未找到锁文件）';
    out.hint = '可能是并发启动的竞态；稍后重试，或为每个实例使用独立 --user-data-dir。';
    return out;
  }

  if (code !== null && CHROMIUM_EXIT_CODES[code]) {
    out.reason = CHROMIUM_EXIT_CODES[code];
    out.hint = '检查内核是否完整、命令行参数是否被 extraArgs 覆盖。';
    return out;
  }

  out.reason = '内核启动失败（退出码 ' + code + '，无可用 stderr）';
  out.hint = '用 --headless=new 手动跑一次内核看完整报错；确认可执行文件路径与架构匹配。';
  return out;
}

/* ============================================================================
 * 第 1 节 · CONFIG —— 全部可调参数集中于此（含所有随机延迟范围）
 * ==========================================================================*/
const CONFIG = {
  /* P4 模式开关：'current_chapter' 仅处理当前章节 | 'continue_chapters' 连续推进 */
  mode: 'current_chapter',
  maxSections: 20, // 连续推进模式：最多完整看完多少节即停（硬上限）

  course: {
    // 学习通「课程学习」页 URL（地址栏整串复制，含 courseId/clazzid/enc 等参数）。
    // 可被环境变量 CX_COURSE_URL 或 CLI --course-url / MCP 参数 courseUrl 覆盖。
    url: process.env.CX_COURSE_URL || ''
  },

  /* Chromium / CDP（路径 A） */
  chromium: {
    executablePath: process.env.CX_CHROMIUM || 'chromium',
    headless: true,
    // 持久化 profile：首次人工扫码/账密登录后，登录态在此目录复用（脚本不自动登录）
    profileDir: process.env.CX_PROFILE_DIR || '',
    /* --no-sandbox：NAS/Docker 容器普遍未启用非特权用户命名空间，Chrome 无 SUID 沙箱
       可用时必须显式关闭（本机 chrome-headless-shell 158 实测报 "No usable sandbox!"）

       --no-proxy-server：让浏览器直连，不走系统代理。
       2026-10-27 实测：Windows 上 Clash 开了系统代理（127.0.0.1:7897），
        Chrome/Edge 会把**所有**请求送进代理；访问超星这类国内站点走代理会导致
         · CSS 加载不完整 → 页面停在「裸页」（.default-login 圆角 0px、按钮 43px）
         · 二维码图片加载失败 → naturalWidth=0（主人看到的破图图标）
       加此参数后重载实测：CSS 4 个全 200、二维码 270x270 正常。
       Linux 容器（FNOS）本无系统代理，此参数无害。

       ★ 2026-10-29 起：静态部分集中在 buildChromiumArgs()，本数组只放
         「用户/环境追加」的参数，且会被去重合并（同名单值参数后者覆盖前者）。 */
    extraArgs: [
      '--no-sandbox',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-infobars',
      '--mute-audio',
      '--window-size=1366,900',
      '--no-proxy-server',
    ]
  },
  cdp: {
    host: '127.0.0.1',
    /* ★ 2026-10-29：端口改为「自动发现」。
       0 = 让 Chromium 自己挑空闲端口（--remote-debugging-port=0），
       启动后从 <profile>/DevToolsActivePort 读回真实端口。
       原因：FNOS 上 admin + 5 个用户实例共用写死的 9223，会互相抢端口；
       而且固定端口无法区分「浏览器还没起来」和「端口被别的进程占了」。
       仍可用 CX_CDP_PORT=<端口> 强制指定（调试/附着已有浏览器时用）。 */
    port: process.env.CX_CDP_PORT === undefined ? 0 : Number(process.env.CX_CDP_PORT || 0),
    attachTimeoutMs: 20000,
    navTimeoutMs: 30000,
    evalTimeoutMs: 15000
  },

  /* 视频判定：progress >= progressDoneRatio% 或 ended === true 视为自然结束 */
  video: { progressDoneRatio: 98.5, mute: true },

  /* 拟人化节奏（所有随机范围集中在 CONFIG，便于统一调节与审计） */
  humanize: {
    clickDelayMs: [300, 1200],        // 每次点击/按键前随机延迟
    sectionCooldownMs: [8000, 15000], // 切换章节后的冷却时间
    quizThinkMs: [2000, 5000],        // 弹题作答前的"思考延迟"，不秒选
    longPauseEveryOps: [12, 20],      // 每隔 N 次操作插入一次长停顿（N 也随机）
    longPauseMs: [3000, 6000],        // 长停顿时长
    pollMs: [4000, 9000]              // 播放态轮询间隔（非固定周期，防机械画像）
  },

  /* 安全停止 */
  safety: {
    maxConsecutiveFailures: 3,        // 连续 N 次无法识别/关键失败 → 停止并输出诊断
    maxLoadRetries: 6,                // 切节后等待新页面加载的探测次数
    maxNoVideoWaitTicks: 4,           // 新节迟迟无视频的等待轮数，超过按非视频任务点跳过
    maxRuntimeMs: 12 * 60 * 60 * 1000, // 单次运行时长兜底（12 小时，覆盖看完一整门课）
    /* ★ 2026-10-28：遇到章节测验时，跳过不答、直接进下一节继续看视频。
       主人要求「课后题一定不要做」，跳过等于不拿这部分分，与要求一致；
       且此时视频任务点已完成（超星已确认），不跳会永远卡在本节。
       设为 false 可恢复旧行为（停下等人）。 */
    skipChapterQuiz: true,
    fatalKeywords: ['人脸识别', '人脸', '活体', '活体检测', '验证码', '安全验证', '滑块验证', '真人验证', '请完成验证', '刮开'],
    loginHostPattern: 'passport|login\\.|auth\\.'
  },

  /* 日志：console + 内存环形缓冲（可选文件） */
  log: { ringSize: 600, file: process.env.CX_LOG_FILE || null },

  /* 无头扫码登录：profile 无登录态时打开登录页二维码，周期截图 + 轮询跳转；
     用户手机「学习通」App 扫截图里的码即可，全程不接触账密、不自动填表 */
  login: {
    homeUrl: 'https://i.chaoxing.com/',
    loginUrl: 'https://passport2.chaoxing.com/login?newversion=true',
    // 登录成功的判定：URL 命中此正则且不在 passport/login 域（可配置以便对接其他站点/测试）
    successUrlPattern: 'chaoxing\\.com',
    shotDir: process.env.CX_LOGIN_SHOT_DIR || path.join(__dirname, '.login'),
    timeoutMs: 10 * 60 * 1000, // 扫码窗口 10 分钟，二维码过期自动刷新
    pollMs: 2500,
    reloadEveryMs: 60000,
    /* 一次性登录（默认开启）：每次任务使用独立的临时 profile，任务结束即删除，
       下一次必须重新扫码。关闭后回退为「扫码一次长期复用」。 */
    ephemeral: process.env.CX_EPHEMERAL_LOGIN !== '0',
  },

  /* 超星风控检测页：账号多端登录 / 异常操作时被导航到 detect.chaoxing.com。
     该页 JS 会陷入死循环，导致 renderer 不再响应任何 CDP 指令（Page.enable 超时）。
     引擎必须识别并丢弃这样的 target，而不是复用它。 */
  detect: {
    // 命中任一即判定为风控检测页
    urlPattern: 'detect\\.chaoxing\\.com|/api/monitor_temp|[?&]mes=',
    // 检测页上的异常提示关键词（用于日志提示）
    messagePattern: '多终端登录|异常学习|异常操作|请尽快修改密码',
    // 新建 target 失败时的回退：是否允许附着到已有 target（会做探活）
    allowAttachFallback: true,
    /* ★ 2026-10-28 主人要求：命中风控后不立即放弃，先等 30 秒再刷新重试；
       最多重试 2 次，仍失败才真正停止（并在日志里写明原因）。
       依据：实测「手机端退出登录」后风控会自行解除，等一会儿刷新通常能继续。 */
    retryWaitMs: 30000,      // 每次重试前等待时长（30 秒）
    maxRetries: 2,           // 最多重试次数（2 次 → 共尝试 3 轮）
    retryJitterMs: 5000      // 等待时长随机浮动，避免固定节奏被识别
  },

  /* MCP 工具注册 */
  mcp: { serverName: 'cx', toolName: 'cx_learn' }
};

/** 深合并（覆盖值优先；数组整体替换）；返回全新对象，不改默认 CONFIG。 */
function mergeConfig(base, patch) {
  const out = JSON.parse(JSON.stringify(base));
  const deep = (dst, src) => {
    for (const k of Object.keys(src || {})) {
      const v = src[k];
      if (v === undefined) continue;
      if (v && typeof v === 'object' && !Array.isArray(v) && dst[k] && typeof dst[k] === 'object' && !Array.isArray(dst[k])) deep(dst[k], v);
      else dst[k] = v;
    }
  };
  deep(out, patch || {});
  return out;
}

/**
 * 从模型回复里解析出选项字母索引（0 基），解析不出返回 -1。
 *
 * 直接 match(/[A-Z]/) 不可靠：模型若回 "The answer is A" 或 "选 B"，
 * 首个大写字母会是 T / 杂音。按三档取：
 *   1. 「答案/正确/选/answer/is」等提示词后面的字母
 *   2. 独立的选项字母（前后不是字母数字），如 "B. 1950年"
 *   3. 兜底：正文里第一个 A-Z
 */
function parseAnswerLetter(text, optCount) {
  const maxIdx = (optCount || 4) - 1;
  const s = String(text || '');
  if (!s) return -1;
  const clamp = function (ch) {
    const i = ch.toUpperCase().charCodeAt(0) - 65;
    return i >= 0 && i <= maxIdx ? i : -1;
  };
  const m1 = s.match(/(?:答案|正确(?:答案|选项)?|选择|选|answer|correct|option|is)\s*[:：是为]?\s*\**\s*([A-H])/i);
  if (m1) { const i = clamp(m1[1]); if (i >= 0) return i; }
  const m2 = s.match(/(?:^|[^A-Za-z0-9])([A-H])(?=$|[^A-Za-z0-9])/);
  if (m2) { const i = clamp(m2[1]); if (i >= 0) return i; }
  const m3 = s.toUpperCase().match(/[A-Z]/);
  if (m3) { const i = m3[0].charCodeAt(0) - 65; if (i >= 0 && i <= maxIdx) return i; }
  return -1;
}

/** 启动前配置校验：非法配置直接致命停止，不进入浏览器流程。 */
function validateConfig(cfg) {
  const errs = [];
  if (['current_chapter', 'continue_chapters'].indexOf(cfg.mode) < 0) errs.push('mode 必须是 current_chapter | continue_chapters');
  if (!(Number(cfg.maxSections) >= 1)) errs.push('maxSections 必须 >= 1');
  const ranges = [
    ['clickDelayMs', cfg.humanize.clickDelayMs], ['sectionCooldownMs', cfg.humanize.sectionCooldownMs],
    ['quizThinkMs', cfg.humanize.quizThinkMs], ['longPauseMs', cfg.humanize.longPauseMs], ['pollMs', cfg.humanize.pollMs]
  ];
  for (const [name, r] of ranges) {
    if (!Array.isArray(r) || r.length !== 2 || !(r[0] >= 0 && r[1] >= r[0])) errs.push('humanize.' + name + ' 必须是 [min,max] 且 min<=max');
  }
  if (!(cfg.video.progressDoneRatio >= 90 && cfg.video.progressDoneRatio <= 100)) errs.push('video.progressDoneRatio 应在 90-100 之间');
  if (errs.length) throw new FatalStop('CONFIG_INVALID', errs.join('; '));
}

/* ============================================================================
 * 第 2 节 · DSH_ADAPTER —— 浏览器操作最小原语声明区（路径 A：CDP 实现）
 * ----------------------------------------------------------------------------
 * 原语清单（业务层只认识这些，不认识 CDP 细节）：
 *   sleep(ms)                 底层定时。业务代码不得直接使用（humanize 专用）。
 *   ensureBrowser()           前置检查：CDP 端点可达则附着；否则按 CONFIG 启动
 *                             Chromium（独立 profile）。语义：保证"有一个可控浏览器"。
 *   navigate(url, opts)       导航并等待 load 事件；超时不致命，由业务层判断。
 *   getFrameDocuments()       递归遍历 frame 树（含全部同源/跨进程 iframe），返回
 *                             [{frameId,url,isTop}]。满足"不得只操作顶层 document"。
 *   evalInFrame(fid, expr)    在指定 frame 的执行上下文中求值（Runtime.evaluate，
 *                             returnByValue + userGesture），返回 JSON 可序列化值。
 *   click(fid, rect)          以 Input.dispatchMouseEvent 在全局坐标真实点击
 *                             （mouseMoved→Pressed→Released），等价真人输入。
 *   jsClick(fid, kind, arg)   降级原语：页内 element.click()（跨域 iframe 兜底）。
 *   getText(fid, expr)        便捷取文本。
 *   isVideoEnded(fid)         语义原语：ended || progress >= 98.5%。
 *   getCurrentUrl()           当前顶层 URL（前置检查用）。
 * 适配方式：CDP over 原生 WebSocket（Node≥22 全局可用）+ HTTP /json 端点；
 *          每帧上下文经 Runtime.executionContextCreated(auxData.frameId) 映射，
 *          从而对多层同源 iframe 做真正的递归遍历与逐帧求值。
 * 若浏览器能力以 browser_* MCP 工具提供：只需替换下方带 [BRIDGE] 标记的
 * 函数体（每处 3-6 行），见文末适配指南 A。
 * ==========================================================================*/
function createCdpAdapter(cfg) {
  let _conn = null;
  let _targetId = null;
  let _spawnedByUs = false; // true = 本次进程启动了 Chromium，退出时应主动关掉
  let _browserClosedByUs = false; // true = 是我们主动请求关闭的（用于区分「正常退出」与「内核崩了」）
  /** CDP 连接：请求-响应关联 + 事件等待 + frame→执行上下文映射。 */
  class CdpConn {
    constructor(wsUrl) {
      this.wsUrl = wsUrl; this.ws = null;
      this._mid = 0; this._pending = new Map(); this._waiters = [];
      this.sessionId = null; this.topFrameId = null;
      this.contexts = new Map(); // frameId -> [contextId, ...]
    }
    connect() {
      const timeoutMs = cfg.cdp.attachTimeoutMs;
      return new Promise((resolve, reject) => {
        let ws;
        try { ws = new WebSocket(this.wsUrl); } catch (e) { reject(new Error('CDP WebSocket 创建失败: ' + e.message)); return; }
        this.ws = ws;
        const timer = setTimeout(() => { try { ws.close(); } catch (_) {} reject(new Error('CDP WebSocket 连接超时: ' + this.wsUrl)); }, timeoutMs);
        ws.addEventListener('open', () => { clearTimeout(timer); resolve(); });
        ws.addEventListener('error', () => { clearTimeout(timer); reject(new Error('CDP WebSocket 连接失败: ' + this.wsUrl)); });
        ws.addEventListener('message', (ev) => {
          let msg; try { msg = JSON.parse(ev.data); } catch (_) { return; }
          if (msg.id !== undefined && this._pending.has(msg.id)) {
            const p = this._pending.get(msg.id); this._pending.delete(msg.id);
            if (msg.error) p.reject(new Error('CDP 调用失败 ' + p.method + ': ' + msg.error.message));
            else p.resolve(msg.result || {});
          } else if (msg.method) {
            this._onEvent(msg);
            this._waiters = this._waiters.filter((w) => {
              if (w.method === msg.method) { clearTimeout(w.timer); w.resolve(msg.params); return false; }
              return true;
            });
          }
        });
      });
    }
    _onEvent(msg) {
      if (msg.method === 'Runtime.executionContextCreated') {
        const c = msg.params && msg.params.context;
        const fid = c && c.auxData && c.auxData.frameId;
        if (fid) { const arr = this.contexts.get(fid) || []; arr.push(c.id); this.contexts.set(fid, arr); }
      } else if (msg.method === 'Runtime.executionContextsCleared') {
        this.contexts.clear();
      } else if (msg.method === 'Runtime.executionContextDestroyed') {
        const cid = msg.params && msg.params.executionContextId;
        for (const [fid, arr] of this.contexts) {
          const i = arr.indexOf(cid);
          if (i >= 0) { arr.splice(i, 1); if (!arr.length) this.contexts.delete(fid); }
        }
      } else if (msg.method === 'Fetch.requestPaused') {
        /* ★ 超星的视频在 cldisk CDN 上，CDN 校验 Referer：
             无效 Referer → 403 → <video> 拿不到字节 → 播放器 readyState=0 卡死。
           Chrome 的媒体请求不继承 Network.setExtraHTTPHeaders（那个只对 XHR/fetch 生效，
           实测页面内 fetch 206 成功、<video> 却 0 字节）。
           ⇒ 必须用 Fetch 域逐个拦截媒体请求，显式把 Referer 换成超星域名。
           注意 headers 必须是 {name, value} 数组格式，传对象会被忽略。 */
        this._onFetchPaused(msg).catch(() => { /* 拦截失败不能拖垮主流程 */ });
      }
    }
    /** 处理被 Fetch 域拦截的请求：补上超星 Referer 后放行。 */
    async _onFetchPaused(msg) {
      const p = msg.params || {};
      const req = p.request || {};
      const headers = req.headers || {};
      const arr = Object.keys(headers).map((k) => ({ name: k, value: String(headers[k]) }));
      const iRef = arr.findIndex((x) => String(x.name).toLowerCase() === 'referer');
      const referer = 'https://mooc1.chaoxing.com/';
      if (iRef >= 0) arr[iRef] = { name: 'Referer', value: referer };
      else arr.push({ name: 'Referer', value: referer });
      /* ★ 必须用事件自带的 sessionId 回包：
         被拦截的请求可能来自子 frame 的 session，用顶层 sessionId 会被 Chrome 拒绝。 */
      const sid = msg.sessionId;
      try {
        await this.send('Fetch.continueRequest', { requestId: p.requestId, headers: arr }, undefined, sid);
        this.fetchPatched = (this.fetchPatched || 0) + 1;
      } catch (e) {
        try { await this.send('Fetch.continueRequest', { requestId: p.requestId }, undefined, sid); } catch (_) { /* ignore */ }
      }
    }
    send(method, params, timeoutMs, sessionId) {
      if (!this.ws || this.ws.readyState !== 1) return Promise.reject(new Error('CDP 连接未就绪: ' + method));
      const id = ++this._mid;
      const payload = { id, method, params: params || {} };
      const sid = sessionId !== undefined ? sessionId : this.sessionId;
      if (sid) payload.sessionId = sid;
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => { this._pending.delete(id); reject(new Error('CDP 调用超时: ' + method)); }, timeoutMs || (cfg.cdp.evalTimeoutMs + 25000));
        this._pending.set(id, { method, resolve: (v) => { clearTimeout(timer); resolve(v); }, reject: (e) => { clearTimeout(timer); reject(e); } });
        try { this.ws.send(JSON.stringify(payload)); } catch (e) { clearTimeout(timer); this._pending.delete(id); reject(e); }
      });
    }
    close() {
      try { if (this.ws) this.ws.close(); } catch (_) { /* ignore */ }
      this.ws = null;
      for (const [, p] of this._pending) p.reject(new Error('CDP 连接已关闭'));
      this._pending.clear();
    }
    waitEvent(method, timeoutMs) {
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          this._waiters = this._waiters.filter((w) => w.timer !== timer);
          reject(new Error('等待 CDP 事件超时: ' + method));
        }, timeoutMs);
        this._waiters.push({ method, resolve: (p) => { clearTimeout(timer); resolve(p); }, timer });
      });
    }
  }

  /* ★ 2026-10-29：端口不再写死。cfg.cdp.port 为 0 时由 Chromium 自选，
     真实值在每次启动后写回 _activePort，所有 CDP/HTTP 调用都走它。 */
  let _activePort = cfg.cdp.port;
  /* 最近一次拉起的诊断信息：失败时用来给出「为什么起不来」而不是干等超时 */
  let _launchStderr = '';
  let _launchExit = null;
  let _launchError = null;

  async function cdpHttp(path, method) {
    const url = 'http://' + cfg.cdp.host + ':' + _activePort + path;
    const res = await fetch(url, { method: method || 'GET' });
    if (!res.ok) throw new Error('CDP HTTP ' + res.status + ' ' + url);
    return res.json();
  }

  function spawnChromium() {
    const args = buildChromiumArgs({
      headless: !!cfg.chromium.headless,
      port: cfg.cdp.port,          // 0 = 自选
      profileDir: cfg.chromium.profileDir || '',
      shellKernel: isHeadlessShellKernel(cfg.chromium.executablePath),
      userArgs: cfg.chromium.extraArgs || [],
    });
    args.push('about:blank');
    try {
      /* detached: true + unref —— 登录进程退出后浏览器必须继续活着，
         否则会话级 cookie（UID/_uid）随之消失，读课程/看课就回到登录页。
         销毁统一由看课任务结束时的 purge + killStrayBrowser 负责。

         ★ 2026-10-29：stdio 由 'ignore' 改为 'pipe'（只接 stderr）。
         原因：Chromium 把「为什么起不来」全部写在 stderr，而最常见的那条
         （profile 被占用 / 目录不可写）表现为**进程静默退出、退出码 21、stderr 为空
         但主进程日志里有一行 process_singleton_win.cc**。原来用 'ignore' 时
         这些信息全部丢失，用户只能看到 20 秒后的一句「连不上」。
         detached 下仍要能收尾：unref 只解除父子绑定，不影响 pipe 读取。 */
      const child = spawn(cfg.chromium.executablePath, args, {
        stdio: ['ignore', 'ignore', 'pipe'],
        detached: true,
      });
      try { child.unref() } catch (_) { /* ignore */ }
      _spawnedByUs = true;
      _browserClosedByUs = false;
      _launchStderr = '';
      _launchExit = null;
      _launchError = null;

      /* 只保留最后若干行，够定位问题即可；限长防止崩溃日志把内存打满 */
      try {
        if (child.stderr) {
          child.stderr.setEncoding('utf8');
          child.stderr.on('data', (buf) => {
            _launchStderr = (_launchStderr + buf).slice(-4000);
          });
          child.stderr.on('error', () => { /* 管道断了就算了 */ });
        }
      } catch (_) { /* 拿不到 stderr 不影响主流程 */ }

      child.on('error', (e) => { _launchError = e; /* ensureBrowser 的轮询会捕获失败 */ });
      /* ★ 2026-10-29 实测：spawn 失败时 child.pid **立即**是 undefined，
         而 'error' 事件要等下一轮事件循环。所以在超时 20 秒的等待里，
         只靠 error 事件会白等；这里同步记一笔，等待循环立刻就能看到。 */
      if (child.pid === undefined) {
        const e = new Error('spawn 失败（ENOENT/EACCES）：' + cfg.chromium.executablePath);
        /* 只对「看起来是路径」的值做 existsSync 区分权限问题；
           裸命令名（如 'chromium'）在 PATH 里，existsSync 恒为 false，不能据此判 ENOENT。
           这里先给 ENOENT，'error' 事件若稍后到达会覆盖成真实 code。 */
        const exe = String(cfg.chromium.executablePath || '');
        e.code = (!isBareCommandName(exe) && fs.existsSync(exe)) ? 'EACCES' : 'ENOENT';
        _launchError = e;
      }
      /* 内核崩了要能说出来，否则只能干等 20 秒超时后报「连不上」 */
      child.on('exit', (code, signal) => {
        _launchExit = { code, signal };
        if (_spawnedByUs && !_browserClosedByUs) {
          logger.warn('PRECHECK', '浏览器进程提前退出', {
            code, signal,
            hint: describeLaunchExit(code, _launchStderr, cfg, _launchError ? (String(_launchError.code || '') + ' ' + String(_launchError.message || '')) : '').reason,
          });
        }
      });
    } catch (e) {
      throw new FatalStop('CHROMIUM_LAUNCH_FAILED', '无法启动 Chromium: ' + e.message + '；请检查 CONFIG.chromium.executablePath（可用环境变量 CX_CHROMIUM 指定）。');
    }
    return args;
  }

  /**
   * 等待 CDP 端口就绪，并把真实端口写入 _activePort。
   *
   * 三条发现路径，按可靠性排序：
   *   1. 端口非 0 → 直接探 /json/version（用户指定，最确定）
   *   2. 端口为 0 → 轮询 <profile>/DevToolsActivePort，读出 Chromium 自报的端口
   *   3. 兜底 → 解析 Chromium 打到 stderr 的 "DevTools listening on ws://..."
   *
   * 必须在「轮询端口」之前先确认端口号，所以这里先拿端口再探活，
   * 而不是像旧实现那样对着一个假定端口死等 —— 后者无法区分
   * 「还没起来」与「端口被别人占着」。
   */
  async function waitForCdpEndpoint(deadline) {
    let lastErr = null;
    /* 给「内核提前退出」留出宽限期：刚起时的正常启动也可能瞬间退，
       但如果 1.5 秒后还没有端口线索、且进程已退出，就没必要再等满 20 秒。 */
    const startedAt = Date.now();
    while (Date.now() < deadline) {
      if (!_activePort && cfg.chromium.profileDir) {
        const active = readDevToolsActivePort(cfg.chromium.profileDir);
        if (active) {
          _activePort = active.port;
          logger.info('PRECHECK', '已从 DevToolsActivePort 读到调试端口', {
            port: _activePort, profile: cfg.chromium.profileDir,
          });
        }
      }
      if (_activePort) {
        try { return await cdpHttp('/json/version'); } catch (e) { lastErr = e; }
      }
      /* ★ 2026-10-29：进程已死就立刻返回，让上层用真实退出码报错。
         否则用户要等 20 秒，最后看到的还是一句「连不上」。 */
      if (_launchExit && Date.now() - startedAt > 1500) {
        logger.warn('PRECHECK', '内核在端口就绪前已退出，停止等待', {
          code: _launchExit.code, signal: _launchExit.signal, waitedMs: Date.now() - startedAt,
        });
        return null;
      }
      /* ★ 2026-10-29 补：spawn 失败（可执行文件不存在 ENOENT / 权限 EACCES）
         **不会**触发 exit，只会触发 error，有时也不触发 —— 因此两种都要查。否则会白等满 attachTimeoutMs。

         注意：不能用 fs.existsSync(executablePath) 在这里做判断。
         实测（本机 Windows）：裸命令名如 'where.exe' / 'ping.exe' / 'certutil.exe'
         在 PATH 里可解析、spawn 能正常启动，但 existsSync 对裸名一律返回 false。
         config 的默认值恰好就是裸名 'chromium'（依赖 PATH 查找），
         若在这里 existsSync 一下就会把合法配置误判成"内核不存在"。
         只认 spawn 自己的结论（_launchError），它才是权威。 */
      if (_launchError) {
        logger.warn('PRECHECK', '内核无法执行，停止等待', {
          code: _launchError.code, message: String(_launchError.message || '').slice(0, 160),
        });
        return null;
      }
      await sleep(300);
    }
    return null;
  }

  function requireConn() {
    if (!_conn) throw new FatalStop('CDP_NOT_CONNECTED', '浏览器尚未连接（ensureBrowser 未调用或已断开）。');
    return _conn;
  }

  const adapter = {
    engine: 'cdp',
    sleep,

    /**
     * 主动关闭本次任务启动的浏览器，释放调试端口与 profile 目录。
     * 只关自己启动的实例（_spawnedByUs）；若附着到外部已有浏览器则不动。
     */
    async shutdown() {
      try { if (_conn) { try { _conn.close() } catch (_) {} ; _conn = null; _targetId = null } } catch (_) { /* ignore */ }
      if (!_spawnedByUs) return
      /* 标记「主动关闭」，避免 exit 回调把正常退出误报成「内核崩溃」 */
      _browserClosedByUs = true
      try {
        const ver = await cdpHttp('/json/version')
        const ws = ver && ver.webSocketDebuggerUrl
        if (ws) {
          await new Promise((resolve) => {
            let done = false
            const fin = () => { if (!done) { done = true; resolve() } }
            try {
              const s = new WebSocket(ws)
              const timer = setTimeout(() => { try { s.close() } catch (_) {} ; fin() }, 3000)
              s.onopen = () => {
                try { s.send(JSON.stringify({ id: 1, method: 'Browser.close' })) } catch (_) {}
                setTimeout(() => { clearTimeout(timer); try { s.close() } catch (_) {} ; fin() }, 500)
              }
              s.onerror = () => { clearTimeout(timer); fin() }
              s.onclose = () => { clearTimeout(timer); fin() }
            } catch (_) { fin() }
          })
        }
      } catch (_) { /* 已退出 */ }
      // 等端口真正释放，最多 8 秒
      let exited = false
      for (let i = 0; i < 16; i++) {
        await sleep(500)
        try { await cdpHttp('/json/version'); } catch (_) { exited = true; break }
      }
      if (exited) logger.info('LOGOUT', '浏览器已退出，端口已释放')
      else logger.warn('LOGOUT', '浏览器未在预期时间内退出')
      /* ★ 关键：Chrome 退出后仍需要时间把 Cookies 落盘（LevelDB 异步写）。
         实测直接关会导致 /tmp/.../Default/Cookies 根本不存在，
         于是「登录成功但读课程 0 门」。这里多等一会并轮询确认文件出现。 */
      const prof = (cfg.chromium && cfg.chromium.profileDir) || ''
      if (prof) {
        const cookieFile = path.join(prof, 'Default', 'Cookies')
        for (let i = 0; i < 20; i++) {
          if (fs.existsSync(cookieFile)) {
            const sz = (() => { try { return fs.statSync(cookieFile).size } catch { return 0 } })()
            if (sz > 1024) { logger.info('LOGOUT', 'Cookies 已落盘', { bytes: sz }); break }
          }
          await sleep(400)
        }
        if (!fs.existsSync(cookieFile)) {
          logger.warn('LOGOUT', 'Cookies 未落盘（读课程可能会失败）', { prof })
        }
      }
    },

    async ensureBrowser() {
      let version = null;
      /* 端口为 0（自选）时不能盲目探活，得先有端口号；
         已有 profile 且上次遗留了 DevToolsActivePort，先读一次再探。 */
      if (!_activePort && cfg.chromium.profileDir) {
        const prev = readDevToolsActivePort(cfg.chromium.profileDir);
        if (prev) _activePort = prev.port;
      }
      if (_activePort) {
        try { version = await cdpHttp('/json/version'); } catch (_) { version = null; }
      }
      if (!version) {
        _browserClosedByUs = false;
        _launchStderr = '';
        _launchExit = null;
        _launchError = null;
        /* 重新启动前清掉旧的端口线索，避免连到上一次残留的端口 */
        if (cfg.chromium.profileDir) {
          try { fs.unlinkSync(path.join(cfg.chromium.profileDir, 'DevToolsActivePort')); } catch (_) { /* 不存在即忽略 */ }
        }

        /* ★ 2026-10-29：起之前先做两项前置体检，比事后从退出码猜要准。
           profile 被别的实例占着 / 目录不可写，Chromium 只会静默退出（exit=21），
           stderr 常常是空的 —— 干等 20 秒再报「连不上」对用户毫无帮助。 */
        if (cfg.chromium.profileDir) {
          if (!isProfileWritable(cfg.chromium.profileDir)) {
            throw new FatalStop(
              'PROFILE_NOT_WRITABLE',
              '浏览器 profile 目录不可写：' + cfg.chromium.profileDir
              + '。请修正权限（容器里注意属主是否为运行用户），或改用其它 CX_PROFILE_DIR。'
            );
          }
          const lock = inspectProfileLock(cfg.chromium.profileDir);
          if (lock.locked) {
            /* 只提示不阻断：异常退出会留下残留锁文件，拦下来反而会误伤 */
            logger.warn('PRECHECK', 'profile 存在锁文件，若随即启动失败多半是被占用', {
              evidence: lock.evidence,
              hint: '确认没有旧实例在跑；Chromium 报 exit=21 时删掉这些文件再试',
            });
          }
        }

        _activePort = cfg.cdp.port;
        const args = spawnChromium();
        logger.info('PRECHECK', 'CDP 端点未就绪，启动 Chromium 实例', {
          exec: cfg.chromium.executablePath,
          port: cfg.cdp.port || 'auto',
          shellKernel: isHeadlessShellKernel(cfg.chromium.executablePath),
          /* 只记录关键开关，避免把整串参数刷进日志 */
          antiThrottle: args.filter((a) => /throttl|Backgrounding|Occlusion|autoplay-policy/i.test(a)),
        });
        version = await waitForCdpEndpoint(Date.now() + cfg.cdp.attachTimeoutMs);
        if (!version) {
          /* 失败时别再给一句「连不上」—— 把退出码、stderr、profile 现场一起报出来。
             优先级：spawn 自身的错误（路径/权限） > 进程退出码 > 现场推断。 */
          const spawnErr = _launchError
            ? (String(_launchError.code || '') + ' ' + String(_launchError.message || '')).trim()
            : '';
          const diag = describeLaunchExit(
            _launchExit ? _launchExit.code : null,
            _launchStderr,
            cfg,
            spawnErr
          );
          const earlyDeath = !!(_launchExit || _launchError);
          logger.error('PRECHECK', '浏览器启动失败', {
            exitCode: diag.code,
            exitedEarly: earlyDeath,
            reason: diag.reason,
            hint: diag.hint,
            spawnError: spawnErr ? spawnErr.slice(0, 200) : '',
            stderrTail: diag.detail ? diag.detail.slice(-300) : '',
          });
          throw new FatalStop(
            'CDP_ATTACH_FAILED',
            '无法连接或启动 Chromium（' + cfg.chromium.executablePath + ' @ '
            + cfg.cdp.host + ':' + (_activePort || cfg.cdp.port || 'auto') + '）。'
            + '原因：' + diag.reason + '。' + diag.hint
            + (diag.code !== null
              ? '［内核在端口就绪前就退出了，退出码 ' + diag.code + '］'
              : (earlyDeath
                ? '［内核无法执行，见上方原因］'
                : '［内核仍在运行但端口未就绪，可能是版本过旧或参数被覆盖］'))
            + '（若内核是 chrome-headless-shell，注意它不使用 --headless=new）'
          );
        }
        logger.info('PRECHECK', '调试端口已就绪', { port: _activePort, browser: String((version && version.Browser) || '').slice(0, 60) });
      }

      /* ★ 分层：浏览器层把自己的现状写进中间文件，业务层/插件从这里读，
         不用再猜「内核起没起来、端口是多少」。见 engine/state-bus.js */
      try {
        if (BUS && BUS.reportBrowser) {
          BUS.reportBrowser({
            executablePath: cfg.chromium.executablePath,
            port: _activePort || cfg.cdp.port || 'auto',
            host: cfg.cdp.host,
            browserVersion: String((version && version.Browser) || '').slice(0, 80),
            profileDir: cfg.chromium.profileDir || '',
            headless: !!cfg.chromium.headless,
            ready: true,
          });
        }
        busEmit('browser', 'ready', { port: _activePort || cfg.cdp.port || 'auto' });
      } catch (_) { /* 上报失败不影响启动 */ }

      // 每次都开一个干净的新 target。
      // 原因：复用旧 target 会被超星风控检测页（detect.chaoxing.com）劫持，
      //       该页 JS 死循环使 renderer 不再响应任何 CDP 命令 → Page.enable 超时。
      const target = await this._openFreshTarget();
      const conn = new CdpConn(target.webSocketDebuggerUrl);
      await conn.connect();
      // /json/list 的目标标识字段是 id（即 targetId）；老版本字段名兜底
      const targetId = target.id || target.targetId;
      const attached = await conn.send('Target.attachToTarget', { targetId, flatten: true });
      conn.sessionId = attached.sessionId;
      await conn.send('Page.enable');
      await conn.send('Runtime.enable');
      await this._applyExtraHeaders(conn);
      try {
        const t = await conn.send('Page.getFrameTree');
        conn.topFrameId = t.frameTree && t.frameTree.frame && t.frameTree.frame.id;
      } catch (_) { conn.topFrameId = null; }
      await sleep(400); // 协议层：等待 executionContext 事件到齐（非业务节奏）
      _conn = conn;
      _targetId = targetId;
      logger.info('PRECHECK', '已连接浏览器目标', { targetId, url: (target.url || '').slice(0, 100) });
      return { engine: 'cdp', targetId };
    },

    /**
     * 打开一个全新的 target（优先），并清理掉超星风控检测页等异常 target。
     * 流程：
     *   1. /json/new?about:blank 建新页
     *   2. 新建失败 → 回退到 /json/list 里挑一个「可探活」的 page
     *   3. 探活 = 发 Page.enable，能回应才算可用（卡死的 renderer 会被丢弃）
     */
    async _openFreshTarget() {
      // 1) 优先新建
      try {
        const t = await cdpHttp('/json/new?about:blank', 'PUT').catch(() => cdpHttp('/json/new?about:blank'));
        if (t && t.webSocketDebuggerUrl) {
          logger.info('PRECHECK', '已新建浏览器 target', { targetId: (t.id || '').slice(0, 12) });
          return t;
        }
      } catch (e) {
        logger.warn('PRECHECK', '新建 target 失败，尝试复用已有 target', { error: e.message });
      }

      // 2) 回退：逐个探活已有 target
      const targets = await cdpHttp('/json/list');
      const candidates = (targets || []).filter((t) => t.type === 'page' && !/^devtools/.test(t.url || ''));
      const detectRe = new RegExp(cfg.detect.urlPattern, 'i');
      for (const t of candidates) {
        const isDetect = detectRe.test(t.url || '');
        if (isDetect) {
          logger.warn('PRECHECK', '发现超星风控检测页 target，跳过', {
            targetId: (t.id || '').slice(0, 12),
            url: (t.url || '').slice(0, 140)
          });
          this._closeTargetQuietly(t.id);
          continue;
        }
        if (!cfg.detect.allowAttachFallback) continue;
        // 探活：卡死的 renderer 不会回应 Page.enable
        const alive = await this._probeTarget(t);
        if (alive) {
          logger.info('PRECHECK', '复用已有 target（探活通过）', { targetId: (t.id || '').slice(0, 12) });
          return t;
        }
        logger.warn('PRECHECK', 'target 无响应（renderer 卡死），丢弃', {
          targetId: (t.id || '').slice(0, 12),
          url: (t.url || '').slice(0, 100)
        });
      }

      throw new FatalStop('CDP_NO_USABLE_TARGET',
        '浏览器中没有可用的标签页（现有 target 全部卡死或为超星风控检测页）。' +
        '请重启浏览器后重试。');
    },

    /** 探活某个 target：发 Page.enable 并等一个短超时 */
    async _probeTarget(t) {
      let conn = null;
      try {
        conn = new CdpConn(t.webSocketDebuggerUrl);
        await conn.connect();
        await conn.send('Page.enable', {}, 6000);
        return true;
      } catch (_) {
        return false;
      } finally {
        try { if (conn) conn.close(); } catch (_) { /* ignore */ }
      }
    },

    /** 静默关闭一个 target（忽略错误） */
    _closeTargetQuietly(targetId) {
      if (!targetId) return;
      try {
        cdpHttp('/json/close/' + targetId).catch(() => {});
      } catch (_) { /* ignore */ }
    },

    /**
     * 给所有请求带上 Referer / Origin。
     *
     * ★ 超星的视频文件放在 cldisk CDN 上，CDN 会校验 Referer（实测）：
     *     裸 curl（无 Referer）            → **403 Forbidden**
     *     带 Referer: https://mooc1.chaoxing.com/ → **206 Partial Content** ✓
     *   而浏览器里 <video> 的媒体请求默认不带 Referer ⇒ 拿不到字节 ⇒
     *   播放器表现为 readyState=0 / buffered=[] / 进度卡住，
     *   点播放按钮完全无效（实测引擎会原地空点 170+ 次）。
     *
     *   实测加头后：readyState 0→4、buffered []→[0-31,357-467]、duration null→955.968、
     *   进度 360→364.9→372.9 正常前进。
     *
     * ★ 必须每次导航后都重新设：跨文档导航会清掉 extra headers。
     */
    async _applyExtraHeaders(connIn) {
      const conn = connIn || (() => { try { return requireConn(); } catch (_) { return null; } })();
      if (!conn) return false;
      try {
        await conn.send('Network.enable');
        await conn.send('Network.setExtraHTTPHeaders', {
          headers: {
            Referer: 'https://mooc1.chaoxing.com/',
            Origin: 'https://mooc1.chaoxing.com',
          },
        });
        /* ★ 同时用 Fetch 域拦截**媒体请求**。
           Network.setExtraHTTPHeaders 对 XHR/fetch 生效（实测页面内 fetch 拿到 206），
           但 <video> 的媒体请求不继承它 ⇒ 播放器 readyState=0、缓冲空、进度卡死。
           Fetch 域能拦到媒体请求并显式补 Referer（实测补后 rs=4、buffered 正常、进度前进）。 */
        try {
          await conn.send('Fetch.enable', {
            patterns: [
              { urlPattern: '*cldisk.com*', resourceType: 'Media' },
              { urlPattern: '*cldisk.com*', resourceType: 'XHR' },
            ],
          });
          logger.info('PRECHECK', '已启用 Fetch 域（媒体请求补 Referer）', { pattern: '*cldisk.com*' });
        } catch (e2) {
          logger.warn('PRECHECK', '启用 Fetch 域失败（视频可能仍会 403）', { err: String((e2 && e2.message) || e2).slice(0, 100) });
        }
        return true;
      } catch (e) {
        logger.warn('PRECHECK', '设置请求头失败（视频可能仍会 403）', { err: String((e && e.message) || e).slice(0, 100) });
        return false;
      }
    },

    /**
     * 清掉全局注入的 Referer/Origin。
     *
     * ★ 登录时必须清：_applyExtraHeaders 给所有请求强加
     *   Referer/Origin = https://mooc1.chaoxing.com/（那是给视频 CDN 用的）。
     *   在 passport2 登录页上这是非法跨域头，浏览器加载 `/createqr` 直接
     *   报 net::ERR_INVALID_ARGUMENT（实测），二维码永远是 0x0 破图，
     *   而 getauthstatus 又因为会话对不上一直回 type=2「会话已失效」。
     */
    async clearExtraHeaders() {
      const conn = requireConn();
      try {
        await conn.send('Network.enable');
        await conn.send('Network.setExtraHTTPHeaders', { headers: {} });
        return true;
      } catch (_) { return false; }
    },

    async navigate(url, opts) {
      const conn = requireConn();
      conn.contexts.clear(); // 导航后旧执行上下文全部失效，等待新事件重建映射
      const timeout = (opts && opts.timeoutMs) || cfg.cdp.navTimeoutMs;
      const loaded = conn.waitEvent('Page.loadEventFired', timeout).catch(() => null);
      const res = await conn.send('Page.navigate', { url });
      if (res.errorText) throw new Error('Page.navigate 失败: ' + res.errorText);
      await loaded;
      await sleep(300); // 上下文重建窗口
      // ★ 跨文档导航会清掉 extra headers ⇒ 每次导航后都要重新补 Referer
      await this._applyExtraHeaders();

      // 超星风控检测页自检：多端登录/异常操作时会被重定向到 detect.chaoxing.com，
      // 该页 JS 死循环，renderer 随即不响应任何 CDP 命令。
      const landed = await this.getCurrentUrl().catch(() => '');
      if (this._isDetectUrl(landed)) {
        const msg = await this._readDetectMessage().catch(() => '');
        /* ★ 2026-10-28 主人要求：命中风控不立刻放弃，先等 30 秒再刷新重试，最多 2 次。
           实测：手机端退出登录后，等一会儿刷新通常就能继续。
           重试计数挂在 adapter 上（_detectRetry），整个 run 期间累计，
           避免每节都重置导致「无限重试」。 */
        this._detectRetry = (this._detectRetry || 0) + 1;
        const maxRetries = Number(cfg.detect.maxRetries) || 2;
        const baseWait = Number(cfg.detect.retryWaitMs) || 30000;
        const jitter = Number(cfg.detect.retryJitterMs) || 5000;

        if (this._detectRetry <= maxRetries) {
          const waitMs = baseWait + Math.floor(Math.random() * jitter);
          logger.warn('RISK_CONTROL', '命中超星风控检测页，等待后刷新重试', {
            attempt: this._detectRetry,
            maxRetries,
            waitSeconds: Math.round(waitMs / 1000),
            url: String(landed).slice(0, 160),
            message: String(msg).slice(0, 160),
            hint: '超星判定多端登录/异常学习。建议关闭手机端超星 App 的会话。',
          });
          await sleep(waitMs);
          // 刷新到一个已知安全页（个人空间），避免还停在检测页
          try {
            const safeUrl = 'https://i.chaoxing.com/base';
            const r2 = await conn.send('Page.navigate', { url: safeUrl });
            if (r2 && r2.errorText) throw new Error(String(r2.errorText));
            await conn.waitEvent('Page.loadEventFired', timeout).catch(() => null);
            await sleep(1200);
            await this._applyExtraHeaders();
            const now2 = await this.getCurrentUrl().catch(() => '');
            if (!this._isDetectUrl(now2)) {
              logger.info('RISK_CONTROL', '风控已解除，继续本次流程', {
                attempt: this._detectRetry,
                url: String(now2).slice(0, 140),
              });
              return true;
            }
            logger.warn('RISK_CONTROL', '刷新后仍在风控页，将再试一次', {
              attempt: this._detectRetry,
              url: String(now2).slice(0, 140),
            });
            // 递归一次，让上层重试逻辑接管（受 maxRetries 约束）
            return await this.navigate(url, opts);
          } catch (e) {
            logger.warn('RISK_CONTROL', '风控刷新重试时出错', {
              attempt: this._detectRetry,
              err: String((e && e.message) || e).slice(0, 120),
            });
          }
        }

        /* 重试用尽：明确写清原因后停止 */
        const attemptsUsed = Math.min(this._detectRetry, maxRetries + 1);
        logger.error('RISK_CONTROL', '风控重试已达上限，停止运行', {
          attempts: attemptsUsed,
          maxRetries,
          url: String(landed).slice(0, 200),
          message: String(msg).slice(0, 200),
          reason:
            '超星判定「多终端登录 / 异常学习」，页面被重定向到 detect.chaoxing.com 检测页。'
            + ' 已按策略等待 30 秒并刷新重试 ' + maxRetries + ' 次，仍未解除。'
            + ' 处理办法：① 手机端「学习通」App 完全退出登录（或杀掉进程）；'
            + '② 确认没有其他电脑/浏览器同时登录同一账号；'
            + '③ 等待 10-30 分钟后再运行。',
        });
        throw new FatalStop('RISK_CONTROL_DETECTED',
          '超星风控未解除（已重试 ' + maxRetries + ' 次）：多终端登录或异常学习判定。'
          + (msg ? ' 平台提示：' + String(msg).slice(0, 120) : '')
          + ' 请退出手机端学习通 App 后，等待 10-30 分钟再试。');
      }
      // 走到这里说明导航成功且未命中风控；重置重试计数，供下次独立事件使用
      this._detectRetry = 0;
      return true;
    },

    /** 判断 URL 是否为超星风控检测页 */
    _isDetectUrl(u) {
      try { return new RegExp(cfg.detect.urlPattern, 'i').test(String(u || '')); }
      catch (_) { return false; }
    },

    /** 尽力读取检测页上的异常提示文本（读不到就算了） */
    async _readDetectMessage() {
      try {
        const r = await this.evalInFrame(null,
          'document.body ? (document.body.innerText || document.title || "") : ""');
        const s = String(r && r.value !== undefined ? r.value : r || '');
        const m = s.match(new RegExp('[^。\\n]{0,60}(' + cfg.detect.messagePattern + ')[^。\\n]{0,80}'));
        return m ? m[0] : s.slice(0, 200);
      } catch (_) { return ''; }
    },

    /**
     * 切换引擎当前操作的 target（用于「点课程卡片 → 新标签页打开」的场景）。
     * 关闭旧连接、附着到新 target、重建上下文映射。
     */
    async attachTarget(targetId) {
      if (!targetId) throw new Error('attachTarget: 缺少 targetId');
      try { if (_conn) { try { _conn.close() } catch (_) {} } } catch (_) { /* ignore */ }
      _conn = null; _targetId = null;
      const list = await cdpHttp('/json/list');
      const t = (list || []).find((x) => x.id === targetId);
      if (!t || !t.webSocketDebuggerUrl) throw new Error('attachTarget: target 不存在 ' + targetId);
      const conn = new CdpConn(t.webSocketDebuggerUrl);
      await conn.connect();
      const attached = await conn.send('Target.attachToTarget', { targetId, flatten: true });
      conn.sessionId = attached.sessionId;
      await conn.send('Page.enable');
      await conn.send('Runtime.enable');
      try {
        const tree = await conn.send('Page.getFrameTree');
        conn.topFrameId = tree.frameTree && tree.frameTree.frame && tree.frameTree.frame.id;
      } catch (_) { conn.topFrameId = null; }
      await sleep(400);
      _conn = conn;
      _targetId = targetId;
      logger.info('PRECHECK', '已切换到新 target', {
        targetId: String(targetId).slice(0, 12),
        url: String(t.url || '').slice(0, 100),
      });
      return { engine: 'cdp', targetId };
    },

    async getFrameDocuments() {
      const conn = requireConn();
      const tree = await conn.send('Page.getFrameTree');
      const out = [];
      const walk = (node, depth) => {
        if (!node) return;
        if (node.frame) {
          out.push({
            frameId: node.frame.id,
            url: node.frame.url || '',
            isTop: depth === 0,
            depth,
            name: node.frame.name || '',
          });
        }
        (node.childFrames || []).forEach((c) => walk(c, depth + 1));
      };
      walk(tree.frameTree, 0);
      return out;
    },

    /**
     * ★ 跨域 frame 求值：为指定 frame 建一个 isolated world 再求值。
     *
     * 为什么需要：mooc2-ans 新版课程页把章节树/任务点放在**跨域 iframe** 里
     * （mooc2-ans.chaoxing.com ← → studentcourse / knowledge/cards），
     * 顶层 JS 读不到 contentDocument，而 Runtime.evaluate 用默认 contextId
     * 只会落在顶层。Page.createIsolatedWorld 能给任意 frame 造一个独立
     * 执行上下文，绕开同源限制（CDP 特权）。
     *
     * 只读用途：仅用于读取页面结构，不点击、不提交。
     */
    async evalInFrameCross(frameId, expression) {
      const conn = requireConn();
      let world;
      try {
        world = await conn.send('Page.createIsolatedWorld', {
          frameId,
          worldName: 'cx-probe-' + Math.random().toString(36).slice(2, 8),
          grantUniveralAccess: true,
        });
      } catch (e) {
        return { ok: false, error: 'isolatedWorld: ' + String((e && e.message) || e).slice(0, 120) };
      }
      const ctxId = world && world.executionContextId;
      if (!ctxId) return { ok: false, error: 'no executionContextId' };
      try {
        const res = await conn.send('Runtime.evaluate', {
          contextId: ctxId,
          expression,
          returnByValue: true,
          awaitPromise: true,
        });
        if (res && res.exceptionDetails) {
          return { ok: false, error: 'eval: ' + String((res.exceptionDetails.exception && res.exceptionDetails.exception.description) || res.exceptionDetails.text || '').slice(0, 150) };
        }
        return { ok: true, value: res && res.result ? res.result.value : undefined };
      } catch (e) {
        return { ok: false, error: 'evaluate: ' + String((e && e.message) || e).slice(0, 120) };
      }
    },

    /**
     * 取某个 frame 到顶层 frame 的**祖先链**（root 在前，target 在后）。
     * 用于跨 frame 的坐标换算（截图裁剪必须换算到顶层文档坐标）。
     */
    async getFrameChain(targetFrameId) {
      const conn = requireConn();
      const tree = await conn.send('Page.getFrameTree');
      const par = {};
      (function walk(n, p) {
        if (!n) return;
        if (n.frame) par[n.frame.id] = p;
        (n.childFrames || []).forEach(c => walk(c, n.frame ? n.frame.id : p));
      })(tree.frameTree, null);
      const chain = [];
      let cur = targetFrameId;
      while (cur) { chain.unshift(cur); cur = par[cur]; }
      return chain;
    },

    /**
     * 目标 frame 的**视口原点在顶层文档里的偏移**（逐层累加）。
     *
     * 公式（实测唯一正确形式）：
     *   对链上每一层 child ← parent：
     *     R = child.frameElement.getBoundingClientRect()   （在 parent 的视口坐标）
     *     s = parent 的 scrollX/scrollY
     *     累加 (R + s)
     *   得到的是 child 视口原点在**顶层文档**里的坐标。
     *
     * 为什么每层都要加 parent 的滚动量：R 是视口坐标，
     * 视口坐标 + 滚动量 才是 parent 的文档坐标；两层一相加，
     * 中间层的内容滚动就被正确折算进来（只加顶层滚动量会让整块区域错位）。
     *
     * 注意 R 必须在 **child 上下文**里取（child.frameElement 属于 parent 文档），
     * parent 的滚动量必须在 **parent 上下文**里取（跨源读不到 window.parent.scrollY）。
     */
    async frameOrigin(chain) {
      let ox = 0, oy = 0;
      const parts = [];
      for (let i = 1; i < chain.length; i++) {
        const childId = chain[i], parentId = chain[i - 1];
        let R = null;
        try {
          R = await this.evalInFrame(childId,
            '(() => { try { const fe = window.frameElement; if (!fe) return null; const b = fe.getBoundingClientRect(); return { x: b.x, y: b.y }; } catch (e) { return null; } })()');
        } catch (e) { R = null; }
        if (!R || typeof R.x !== 'number') { parts.push('null'); continue; }
        let s = { x: 0, y: 0 };
        try { s = await this.evalInFrame(parentId, '({ x: window.scrollX || 0, y: window.scrollY || 0 })'); } catch (e) { /* 读不到就按 0 */ }
        ox += R.x + (s.x || 0);
        oy += R.y + (s.y || 0);
        parts.push('+' + Math.round(R.x + (s.x || 0)) + ',' + Math.round(R.y + (s.y || 0)));
      }
      return { ox: ox, oy: oy, parts: parts };
    },

    /** 顶层视口尺寸与滚动量 */
    async rootViewport() {
      const conn = requireConn();
      try {
        const v = await this.evalInFrame(conn.topFrameId,
          '({ w: window.innerWidth, h: window.innerHeight, sx: window.scrollX || 0, sy: window.scrollY || 0 })');
        if (v && v.h) return v;
      } catch (e) { /* ignore */ }
      return { w: 1440, h: 900, sx: 0, sy: 0 };
    },

    /** 把顶层页面滚到指定位置（截图裁剪区必须落在顶层视口内） */
    async scrollRootTo(y) {
      const conn = requireConn();
      try {
        await this.evalInFrame(conn.topFrameId, 'window.scrollTo(0, ' + Math.max(0, Math.round(y)) + ')');
        return true;
      } catch (e) { return false; }
    },

    async evalInFrame(frameId, expression, opts) {
      const conn = requireConn();
      const params = { expression, returnByValue: true, awaitPromise: !(opts && opts.awaitPromise === false), userGesture: true };
      if (frameId) {
        const arr = conn.contexts.get(frameId);
        if (arr && arr.length) params.contextId = arr[arr.length - 1];
        else if (frameId !== conn.topFrameId) throw new Error('frame 执行上下文未就绪: ' + frameId);
        // 顶层 frame 无独立上下文事件时，缺省上下文即顶层主世界，直接求值
      }
      const res = await conn.send('Runtime.evaluate', params);
      if (res.exceptionDetails) {
        const d = res.exceptionDetails;
        throw new Error('页面执行异常: ' + String((d.exception && d.exception.description) || d.text || 'unknown').slice(0, 200));
      }
      return res.result ? res.result.value : undefined;
    },

    async click(frameId, rect) {
      const conn = requireConn();
      if (!rect || !(rect.w > 0 && rect.h > 0)) throw new Error('无效矩形: ' + JSON.stringify(rect));
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      await conn.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, buttons: 0 });
      await conn.send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', buttons: 1, clickCount: 1 });
      await sleep(60 + Math.floor(Math.random() * 90)); // 按下-抬起微抖动（协议层，非业务节奏）
      await conn.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', buttons: 0, clickCount: 1 });
      return { mode: 'cdp-input' };
    },

    async jsClick(frameId, kind, arg) {
      return adapter.evalInFrame(frameId, '__cx.jsClick(' + JSON.stringify(kind) + ',' + JSON.stringify(arg === undefined ? null : arg) + ')');
    },

    async getText(frameId, expression) {
      const v = await adapter.evalInFrame(frameId, expression || 'document.body ? document.body.innerText.slice(0, 400) : \'\'');
      return typeof v === 'string' ? v : JSON.stringify(v);
    },

    async isVideoEnded(frameId) {
      const v = await adapter.evalInFrame(frameId, '__cx.videoState()');
      if (!v || !v.found) return { found: false, ended: false };
      return { found: true, ended: !!v.ended || (v.progress || 0) >= cfg.video.progressDoneRatio, raw: v };
    },

    async getCurrentUrl() {
      if (!_conn) return '';
      try {
        const t = await _conn.send('Page.getFrameTree');
        return (t.frameTree && t.frameTree.frame && t.frameTree.frame.url) || '';
      } catch (_) { return ''; }
    },

    /**
     * 读出浏览器里所有 cookie（用于判断「是否真的已登录」）。
     *
     * ★ 2026-10-29：为什么需要它 ——
     * Chrome/Edge 的密码管理器会自动填好超星登录页的账号密码框，
     * 页面看起来「像已登录」，但 URL 仍是 passport2 登录页、服务端并未认证。
     * 只看 URL 会把这个假象当成已登录，导致扫码流程被跳过、后面全部失败。
     * 真实判据是 UID / _uid 这些认证 cookie 是否存在。
     *
     * Network.getAllCookies 不传 domain 即返回全部域的 cookie。
     * 失败返回 null（调用方当作「无法判断」，不作为否决依据）。
     */
    async getAllCookies() {
      if (!_conn) return null;
      try {
        const r = await _conn.send('Network.getAllCookies');
        return (r && Array.isArray(r.cookies)) ? r.cookies : null;
      } catch (_) { return null; }
    },

    /** 全页截图（登录扫码取证/失败诊断现场）。写文件并返回 base64。 */
    async screenshot(filePath) {
      if (!_conn) throw new Error('CDP 未连接，无法截图');
      const shot = await _conn.send('Page.captureScreenshot', { format: 'png' });
      const b64 = shot && shot.data || '';
      if (filePath && b64) fs.writeFileSync(filePath, Buffer.from(b64, 'base64'));
      return b64;
    },

    /**
     * 按**顶层文档坐标**裁剪截图（返回 base64 PNG，不写文件）。
     *
     * 超星的题干/选项用加密字体渲染，DOM 里读出来是密文，
     * 只有把这一块区域**渲染出来**给视觉模型看，才能拿到明文。
     *
     * 注意 captureBeyondViewport 必须为 false：
     *   置 true 时 Chrome 会为渲染「视口以外的内容」而重排整页，
     *   页面里的 sticky/fixed 元素会被重新画到裁剪区顶部
     *   （实测多出一条无关的章节蓝条，题干也被顶掉）。
     *   置 false 则严格按当前视口渲染，代价是裁剪区必须落在视口内
     *   —— 由调用方（ensureDocRectVisible）先把顶层页面滚到位。
     *
     * @param {{x:number,y:number,w:number,h:number}} rect 顶层文档 CSS 像素坐标
     * @returns {Promise<string>} base64 PNG
     */
    async screenshotClip(rect) {
      if (!_conn) throw new Error('CDP 未连接，无法截图');
      if (!rect || !(rect.w > 0 && rect.h > 0)) throw new Error('无效截图矩形: ' + JSON.stringify(rect));
      const clip = {
        x: Math.max(0, Math.round(rect.x)),
        y: Math.max(0, Math.round(rect.y)),
        width: Math.max(1, Math.round(rect.w)),
        height: Math.max(1, Math.round(rect.h)),
        scale: 1,
      };
      const shot = await _conn.send('Page.captureScreenshot', {
        format: 'png', clip, captureBeyondViewport: false,
      });
      return (shot && shot.data) || '';
    }
  };
  return adapter;
}

/* ============================================================================
 * 第 3 节 · humanize 模块 —— 所有拟人化延迟集中管理（业务代码零散落 sleep）
 * ==========================================================================*/
const humanize = {
  _cfg: null,
  _ops: 0,
  _longEvery: null,
  configure(h) {
    this._cfg = h || {};
    this._ops = 0;
    this._longEvery = this._ri(this._cfg.longPauseEveryOps || [12, 20]);
    logger.log('HUMANIZE', 'INFO', '节奏模块初始化（所有随机范围来自 CONFIG）', { ranges: this._cfg, nextLongPauseAtOp: this._longEvery });
  },
  /** [min,max] 内取随机整数（含端点） */
  _ri(range) {
    const min = Math.max(0, range[0] | 0);
    const max = Math.max(min, range[1] | 0);
    return min + Math.floor(Math.random() * (max - min + 1));
  },
  /** 每次点击/按键前：300–1200ms */
  async beforeClick() { await sleep(this._ri(this._cfg.clickDelayMs || [300, 1200])); },
  /** 切换章节后的冷却：8–15s */
  async sectionCooldown() {
    const ms = this._ri(this._cfg.sectionCooldownMs || [8000, 15000]);
    logger.log('HUMANIZE', 'INFO', '切节冷却', { ms });
    await sleep(ms);
  },
  /** 弹题思考延迟：2–5s，不秒选 */
  async quizThink() {
    const ms = this._ri(this._cfg.quizThinkMs || [2000, 5000]);
    logger.log('HUMANIZE', 'INFO', '弹题思考延迟（不秒选）', { ms });
    await sleep(ms);
  },
  /** 每隔随机 N 次操作插入 3–6s 长停顿，打破固定间隔画像 */
  async maybeLongPause() {
    this._ops += 1;
    if (this._longEvery && this._ops >= this._longEvery) {
      this._ops = 0;
      this._longEvery = this._ri(this._cfg.longPauseEveryOps || [12, 20]);
      const ms = this._ri(this._cfg.longPauseMs || [3000, 6000]);
      logger.log('HUMANIZE', 'INFO', '插入长停顿（防固定间隔风控画像）', { ms, nextLongPauseAtOp: this._longEvery });
      await sleep(ms);
    }
  },
  /** 播放态轮询间隔：4–9s 随机 */
  async pollDelay() { await sleep(this._ri(this._cfg.pollMs || [4000, 9000])); }
};

/* ============================================================================
 * 第 4 节 · logger 模块 —— 结构化日志（时间戳/阶段/层级/结果）+ 内存环形缓冲
 *   每条日志：{ ts, phase, level, message, ...meta }
 *   phase: PRECHECK | PLAYING_CHECK | PLAYING | QUIZ | DIALOG | ADVANCE |
 *          WAIT_LOAD | CLICK | HUMANIZE | LOOP | FATAL | SUMMARY | MCP
 *   同时写 console 与环形缓冲；MCP 模式下 console 被重定向到 stderr（stdout 专供协议）。
 * ==========================================================================*/
const logger = {
  _ring: [],
  _max: CONFIG.log.ringSize,
  _file: null,
  _out: (line) => console.log(line),
  configure(logCfg) {
    this._ring = [];
    this._max = (logCfg && logCfg.ringSize) || CONFIG.log.ringSize;
    this._file = (logCfg && logCfg.file) || null;
    return this;
  },
  setConsole(fn) { this._out = fn; },
  log(phase, level, message, meta) {
    const e = { ts: new Date().toISOString(), phase, level, message };
    if (meta) for (const k of Object.keys(meta)) if (meta[k] !== undefined) e[k] = meta[k];
    this._ring.push(e);
    if (this._ring.length > this._max) this._ring.shift();
    let metaStr = '';
    if (meta) { try { metaStr = ' ' + JSON.stringify(meta); } catch (_) { metaStr = ' [unserializable-meta]'; } if (metaStr.length > 420) metaStr = metaStr.slice(0, 420) + '…'; }
    const line = '[' + e.ts + '][' + level + '][' + phase + '] ' + message + metaStr;
    try { this._out(line); } catch (_) { /* stdout 关闭等情况 */ }
    if (this._file) { try { fs.appendFileSync(this._file, line + '\n'); } catch (_) { /* 文件日志失败不影响主流程 */ } }
    return e;
  },
  info(p, m, meta) { return this.log(p, 'INFO', m, meta); },
  warn(p, m, meta) { return this.log(p, 'WARN', m, meta); },
  error(p, m, meta) { return this.log(p, 'ERROR', m, meta); },
  tail(n) { return this._ring.slice(-(n || 40)); }
};

/** 启动横幅：免责声明 + 运行配置（免责声明同时出现在头部注释与启动日志） */
function logBanner(cfg) {
  const B = '[DISCLAIMER]';
  logger.info('PRECHECK', B + ' 本脚本用于浏览器自动化技术研究；请自行确认所在平台政策与当地法规。');
  logger.info('PRECHECK', B + ' 学习通平台禁止自动化脚本；实际使用可能导致学习进度被退回或账号处罚。');
  logger.info('PRECHECK', B + ' 本脚本不篡改后端数据、不伪造进度上报、不调用进度写接口；全部动作均为模拟页面点击/播放行为。');
  logger.info('PRECHECK', B + ' 检测到人脸识别/活体检测/验证码等人工验证特征时立即停止，不做任何绕过。');
  logger.info('PRECHECK', '运行配置', {
    version: VERSION,
    dshCompat: 'DSH 0.2.0-rc.2 / Node ' + process.version,
    path: 'A (CDP over native WebSocket, zero-dependency)',
    mode: cfg.mode,
    maxSections: cfg.maxSections,
    cdp: cfg.cdp.host + ':' + (Number(cfg.cdp.port) > 0 ? cfg.cdp.port : 'auto'),
    chromium: cfg.chromium.executablePath,
    videoDoneAt: cfg.video.progressDoneRatio + '%',
    humanize: cfg.humanize
  });
}

/* ============================================================================
 * 第 5 节 · 页面状态探测模块 —— 分层选择器策略（语义 → 结构 → 通用兜底）
 * ----------------------------------------------------------------------------
 * 设计约束：不得硬编码单一脆弱 CSS 选择器作为唯一依赖。
 *   第一层 语义特征：按钮文本（继续学习/确定）、video.ended / progress、目录"已完成"文本；
 *   第二层 结构特征：目录候选节点集、可见弹窗遮罩内的 primary 按钮、当前高亮项兄弟节点；
 *   第三层 通用兜底：可见单选框取第一个、playIcon 类元素——命中时业务层输出 WARN。
 * SELECTORS 为候选注册表（每项含 layer 与 note，用于日志定位）；PAGE_PROBE_SRC 注入
 * 页面后暴露 window.__cx：probeAll() 逐帧返回全量状态，find()/jsClick() 在点击前实时
 * 解析元素（避免矩形过期）。iframe 递归遍历由 CDP frame 树 + 逐帧求值完成。
 * ==========================================================================*/
const SELECTORS = {
  version: 5,
  /* 目录节点候选（第二层结构特征）
     注意：学习通有「两套目录」，务必分清层级，否则永远在第一章打转：
       A) 完整课程目录 .posCatalog_select  —— 章头(firstLayer) + 节(curXXXXXX)，85 项
       B) 章内子任务列表 .prev_ul li        —— 「1视频 / 2章节测验」，只有 2 项
     真实站点实测：先抓 A 才是课程目录；抓 B 会把「章内子任务」误当课程章节。 */
  tocItem: [
    { layer: 2, sel: '.posCatalog_select', note: '完整课程目录节点(学习通)' },
    { layer: 2, sel: '.prev_ul li', note: '章内子任务列表(仅当无课程目录时)' },
    { layer: 2, sel: '.chapterText li, .cells li, .ncells li', note: '目录节点候选(模板A)' },
    { layer: 2, sel: 'ul[class*="catalog"] li, div[class*="chapter"] ul li', note: '目录节点候选(通用)' }
  ],
  /* 学习通完整目录里「当前节」的标记
     ★ 实测坑：学习通所有节点的 id 都是 "cur143114xxx"，
       所以「id 以 cur 开头」不能作为当前节判据（会把 85 项全判成 current）。
       真正的当前节只有 class="posCatalog_active" 那一个。 */
  tocCurrentClass: ['posCatalog_active', 'current', 'active'],
  /* 学习通完整目录里「章头」的 class 片段 */
  tocChapterClass: ['firstLayer'],
  /* 学习通完成度：input.jobUnfinishCount 的 value = 该节剩余未完成任务数
     （0 = 已全部完成）。这是唯一可靠的完成判定，文本「已完成」在真实站点并不总出现。 */
  tocUnfinishCountSel: 'input.jobUnfinishCount',
  /* 章内子任务里的「章节测验」入口 */
  quizTabSel: '.prev_ul li',
  /* 章节测验入口的文本关键词 */
  quizTabText: ['章节测验', '章测', '单元测验', '章节练习', '随堂测'],
  /* 同章内「视频」标签文本关键词（答完测验后需切回来） */
  videoTabText: ['视频', '视频课', '课程视频'],
  doneText: ['已完成', '已完成学习'],
  /* 已完成标记：实测学习通用的是 <span class="icon_Completed prevTips">Completed</span>
     （注意是 icon_Completed，不是 complete；hasClassLike 是前缀匹配，
      'complete' 匹配不上 'icon_Completed'，必须显式列出） */
  doneClass: ['icon_Completed', 'bntDone', 'done', 'finish', 'finished', 'complete'],
  chapterHeaderClass: ['chapter', 'prev_chapter', 'chapterhead', 'firstLayer'],
  /* 可见弹层容器候选（第二层结构特征） */
  dialogContainer: [
    { layer: 2, sel: '.maskdiv', note: '防挂机弹窗容器(经典)' },
    { layer: 2, sel: '.layui-layer, .el-dialog__wrapper, .el-dialog', note: '通用弹层候选' },
    { layer: 2, sel: 'div[class*="dialog"][style*="block"], div[class*="mask"][style*="block"]', note: '遮罩候选(通用)' }
  ],
  /* 弹窗主按钮语义文本（第一层） */
  primaryBtnText: ['继续学习', '继续播放', '确定', '知道了', '我知道了', '继续'],
  /* 弹题选项候选（第二层；全部失效则页面侧降级为可见单选框=第三层）
     学习通作业页（章节测验）的真实结构：
       题块  .TiMu.newTiMu
       选项  li.font-cxsecret.before-after（每个 li 一个选项，内含 span.num_option[data="A"]）
       提交  A.btnSubmit.workBtnIndex（文本 "Submit"，英文！） / A.btnSave.workBtnIndex（"Save"）
     注意：li 里还嵌了一个 label.fl.before（只有字母），如果用 'label, li' 抓会重复 → 4 个选项变 8 个。 */
  quizOption: [
    { layer: 2, sel: 'li.font-cxsecret.before-after', note: '学习通作业选项' },
    { layer: 2, sel: '.popboxes .cleanclick', note: '弹题选项(经典)' },
    { layer: 2, sel: '.TiMu .cleanclick', note: '弹题选项(候选A)' },
    { layer: 2, sel: '[class*="pop"] label, [class*="dialog"] label', note: '弹题选项(通用label)' }
  ],
  /* 作业页题块（学习通） */
  quizQuestionSel: '.TiMu.newTiMu, .TiMu',
  /* 作业页选项字母来源（span.num_option 的 data 属性就是 A/B/C/D） */
  quizOptionLetterSel: 'span.num_option[data]',
  /* 提交按钮：class 优先（学习通是英文按钮，靠中文文本必然失配） */
  quizSubmitSel: ['.btnSubmit', '.btnSave', '.workBtnIndex'],
  /* 提交按钮文本（英文界面下全是英文） */
  quizSubmitText: ['提交', '确定', '交卷', 'Submit', 'Save', 'Confirm', 'OK'],

  /* ── 随堂弹题（视频内嵌答题，ans-videoquiz）──
     超星视频播到某个时间点会弹出一道题强制暂停，答对点「继续」才恢复播放。
     实测 DOM（在 ananas/modules/video/index.html 内）：
       <div class="x-component ans-videoquiz">
         <div class="tkTopic_title">判断题</div>
         <div class="tkItem_title">2013年4月德国政府正式推出"工业4.0"</div>
         <ul class="tkItem_ul">
           <li class="ans-videoquiz-opt"><label><span class="tkRadio"><input type=radio name="ans-videoquiz-opt" value=""><i></i></span>A、对</label></li>
           <li class="ans-videoquiz-opt">…B、错</li>
         </ul>
         <div class="tkTopic_oper">
           <a id="videoquiz-submit">提交</a>
           <a id="videoquiz-continue">继续</a>   ← 答对后出现，点它视频才继续
           <span id="spanHas">回答正确</span> / <span id="spanNot">回答错误</span>
       ★ 关键坑：这道题的 radio value 都是空字符串，真正的答案在 label 文本
       （"A、对" / "B、错"）。选项不是 A/B/C/D 字母，是按顺序的文本。
       ★ 更关键的坑：不答这道题，视频就永远卡在弹题点（主人报的"视频没看完"
       根因之一——引擎没识别随堂弹题，只会反复点播放按钮）。 */
  videoQuiz: {
    containerSel: '.ans-videoquiz',
    titleSel: '.tkItem_title',
    optionSel: 'li.ans-videoquiz-opt',
    submitSel: '#videoquiz-submit',
    continueSel: '#videoquiz-continue',
    correctSel: '#spanHas',
    wrongSel: '#spanNot',
    wrongBackSel: '#spanNotBack'
  }
};

/*
 * 页面侧探测代码（以字符串注入每个 frame 执行一次；幂等，重复注入直接跳过）。
 * 注意：运行于页面上下文，仅做只读探测与显式点击，绝不触碰任何上报接口。
 */
const PAGE_PROBE_SRC = `(function () {
  if (window.__cx && window.__cx.__v >= window.__CX_SEL.version) return 'already';
  var S = window.__CX_SEL, KWS = window.__CX_KWS, PAT = window.__CX_PATTERN;

  function norm(s) { return (s == null ? '' : String(s)).replace(/\\s+/g, ' ').trim(); }
  function visible(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (!r || r.width < 2 || r.height < 2) return false;
    var st = window.getComputedStyle(el);
    if (!st || st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
    return true;
  }
  /* 全局坐标：把 frame 内矩形换算到顶层视口（同源链路走 frameElement 偏移累加）。 */
  function rectOf(el) {
    var r = el.getBoundingClientRect();
    var x = r.x, y = r.y, win = window;
    try {
      while (win && win !== win.top) {
        var fe = win.frameElement;
        if (!fe) return { x: Math.round(x), y: Math.round(y), w: Math.round(r.width), h: Math.round(r.height), cross: true };
        var fr = fe.getBoundingClientRect();
        x += fr.x; y += fr.y;
        win = win.parent;
      }
    } catch (e) {
      return { x: Math.round(x), y: Math.round(y), w: Math.round(r.width), h: Math.round(r.height), cross: true };
    }
    return { x: Math.round(x), y: Math.round(y), w: Math.round(r.width), h: Math.round(r.height), cross: false };
  }

  /* 多个矩形的并集（DOMRect 数组）。 */
  function unionRectOf2(rects) {
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, any = false;
    for (var i = 0; i < rects.length; i++) {
      var r = rects[i];
      if (!r) continue;
      any = true;
      if (r.left < x0) x0 = r.left;
      if (r.top < y0) y0 = r.top;
      if (r.right > x1) x1 = r.right;
      if (r.bottom > y1) y1 = r.bottom;
    }
    if (!any) return null;
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  }

  /* 多个元素的并集矩形（同一 frame 内的视口坐标）。 */
  function unionRectOf(els) {
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, any = false;
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (!el) continue;
      var r = el.getBoundingClientRect();
      if (!r || !(r.width > 0 && r.height > 0)) continue;
      any = true;
      if (r.left < x0) x0 = r.left;
      if (r.top < y0) y0 = r.top;
      if (r.right > x1) x1 = r.right;
      if (r.bottom > y1) y1 = r.bottom;
    }
    if (!any) return null;
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  }

  /* 元素在**顶层文档**里的矩形（CSS 像素）。
   *
   * 坐标系三层次（必须分清，实测踩过的坑）：
   *   ① frame 内视口坐标：getBoundingClientRect() 返回的就是这个
   *   ② 顶层视口坐标    ：沿 window.parent 链把每层 iframe 元素的
   *                      getBoundingClientRect() 逐层相加（每层都是活的，
   *                      父 frame 滚动时子 iframe 的位置随之变化，自动抵消）
   *   ③ 顶层文档坐标    ：② 再加顶层自身的 scrollX/scrollY
   *
   * Page.captureScreenshot 的 clip 用的是 ③（文档坐标），
   * 早前只用 ② 裁剪导致整块区域上下错位（截到的是上一题/下一题）。
   * 同源时 window.parent 链可走；跨源时 window.frameElement 为 null，
   * 此时返回 null，调用方退回「整页截图 + 无裁剪」的保守路径。
   */
  function docRectOf(el) {
    var r = el.getBoundingClientRect();
    var x = r.x, y = r.y, win = window;
    try {
      while (win && win !== win.top) {
        var fe = win.frameElement;
        if (!fe) return null; /* 跨域父级：无法换算 */
        var fr = fe.getBoundingClientRect();
        x += fr.x; y += fr.y;
        win = win.parent;
      }
      var tx = win.scrollX || 0, ty = win.scrollY || 0;
      return { x: Math.round(x + tx), y: Math.round(y + ty), w: Math.round(r.width), h: Math.round(r.height) };
    } catch (e) {
      return null;
    }
  }

  /* ---- 坐标系说明（引擎侧实现，页面探针不做换算）----
   *
   * 设 frame 链为 F0(顶层) ← F1 ← … ← Fn(题目所在 frame)。
   *   R_i  = F_i 的 frameElement.getBoundingClientRect()（在 F_{i-1} 的**视口**坐标）
   *   s_i  = F_i 自身的 window.scrollX/scrollY
   * 则：
   *   T_n  = Σ_{i=1..n} ( R_i + s_{i-1} )     ← Fn 的文档原点，在顶层文档里的坐标
   *   元素在顶层文档里的坐标 = T_n + (元素在 Fn 视口里的坐标) + s_n
   *
   * 关键：中间层的滚动量必须逐层累加（早期版本只加顶层滚动，坐标整块错位）。
   * 换算需要逐 frame 求值（父 frame 的 scrollY 跨源时读不到），
   * 因此放在引擎（CDP 侧）做，页面探针只负责给出「frame 内视口坐标」。
   */

  function matchAny(text, arr) {
    if (!text) return null;
    for (var i = 0; i < arr.length; i++) { if (text.indexOf(arr[i]) >= 0) return arr[i]; }
    return null;
  }
  function hasClassLike(el, names) {
    if (!el || typeof el.className !== 'string') return null;
    var toks = el.className.split(/\\s+/);
    for (var i = 0; i < toks.length; i++) {
      for (var j = 0; j < names.length; j++) {
        if (toks[i] === names[j] || toks[i].indexOf(names[j]) === 0) return names[j];
      }
    }
    return null;
  }
  function findButtons(root) {
    var out = [];
    var els = root.querySelectorAll('button, a, .btn, [role="button"], input[type="button"], input[type="submit"], .layui-layer-btn a, .el-button, .dialog-footer button');
    for (var i = 0; i < els.length; i++) { if (visible(els[i])) out.push(els[i]); }
    return out;
  }

  /* ---- 视频状态（第一层语义：ended / progress）---- */
  function videoState() {
    var vs = document.querySelectorAll('video');
    var best = null, bestArea = 0;
    for (var i = 0; i < vs.length; i++) {
      var v = vs[i]; var r = v.getBoundingClientRect(); var a = r.width * r.height;
      if (a > bestArea) { bestArea = a; best = v; }
    }
    if (!best) return { found: false };
    /* ★ 用 Number.isFinite 而不是「或 0」的写法：duration 在元数据未加载时是 NaN，
       而 Infinity 也会被当成有效值。参考 xuexitong-ai-assistant（Flyer2333）
       L2916 的写法：Number.isFinite(duration) && duration > 0 */
    var rawDur = best.duration, rawCur = best.currentTime;
    var dur = Number.isFinite(rawDur) ? rawDur : 0;
    var cur = Number.isFinite(rawCur) ? rawCur : 0;
    /* ★★★ 2026-10-29 修复死循环（3.3 ↔ 3.4 卡了 15 分钟）★★★
       原来这里：var prog = dur > 0 ? ... : (best.ended ? 100 : 0);
       坑：刚点进一个新节时，video 元素已存在但**元数据还没加载**（duration=0）。
       HTML5 规范里 duration=0 时 currentTime(0) >= duration(0) 成立 ⇒ ended=true，
       于是 prog 被算成 100 ⇒ 上层误判「这节播完了」⇒ 立刻切下一节 ⇒
       下一节同样没加载 ⇒ 又算 100 ⇒ 无限空转。
       实测：3.3/3.4 之间来回跳了 15 分钟，completed 计数虚增到 56。

       正确语义：拿不到 duration 就说明「还没开始播」，进度只能是 0。
       参考项目的判据（L2916）也是**无条件要求 duration > 0**，不给 ended 留旁路。 */
    var prog = dur > 0 ? Math.min(100, (cur / dur) * 100) : 0;
    /* ★ 补充缓冲/网络状态：判断「卡死」的关键。
       实测超星视频卡在某个进度点不动时：
         readyState=0（HAVE_NOTHING，元数据都没拿到）
         networkState=1（NETWORK_IDLE）
         buffered=[]（一字节都没缓冲）
       根因是超星的视频 CDN 链接带**时效签名**
       （…/sd.mp4?at_=1792944807646&ak_=…&ad_=…），过期后 CDN 直接 403。
       这时点播放按钮毫无作用，必须重新加载页面拿新签名。 */
    var buf = [], bufEnd = 0;
    try {
      for (var b = 0; b < best.buffered.length; b++) {
        buf.push(Math.round(best.buffered.start(b)) + '-' + Math.round(best.buffered.end(b)));
        if (best.buffered.end(b) > bufEnd) bufEnd = best.buffered.end(b);
      }
    } catch (e3) { /* ignore */ }
    var vErr = null;
    try { if (best.error) vErr = (best.error.code || '?') + ':' + (best.error.message || ''); } catch (e4) { /* ignore */ }
    return {
      /* ended 必须同时满足 duration>0：duration=0 时浏览器给的 ended=true 是假的
         （元数据没加载，0>=0 恒成立）。见上方 prog 计算的说明。 */
      found: true, paused: !!best.paused, ended: !!best.ended && dur > 0,
      currentTime: Math.round(cur * 10) / 10, duration: Math.round(dur * 10) / 10,
      progress: Math.round(prog * 10) / 10, muted: !!best.muted,
      readyState: best.readyState, networkState: best.networkState,
      buffered: buf, bufferedEnd: Math.round(bufEnd), error: vErr,
      src: String(best.currentSrc || best.src || '').slice(0, 200)
    };
  }

  /* ---- 弹窗/遮罩（第二层结构 + 第一层语义文本判定 kind）---- */
  var lastDialogs = [];
  function dialogScan() {
    var out = [], seen = {}, containers = [];
    for (var i = 0; i < S.dialogContainer.length; i++) {
      var nl = null;
      try { nl = document.querySelectorAll(S.dialogContainer[i].sel); } catch (e) { nl = null; }
      if (!nl) continue;
      for (var j = 0; j < nl.length; j++) {
        if (visible(nl[j])) containers.push({ el: nl[j], layer: S.dialogContainer[i].layer, note: S.dialogContainer[i].note });
      }
    }
    for (var k = 0; k < containers.length; k++) {
      var c = containers[k];
      var text = norm(c.el.innerText || c.el.textContent || '').slice(0, 160);
      if (seen[text]) continue;
      seen[text] = 1;
      var humanHit = matchAny(text, KWS);
      if (humanHit) { out.push({ kind: 'human', text: text, evidence: humanHit, layer: c.layer, note: c.note, btn: null }); continue; }
      var btns = findButtons(c.el), primary = null, primaryText = '';
      for (var b = 0; b < btns.length; b++) {
        var t = norm(btns[b].innerText || btns[b].value || '');
        if (matchAny(t, S.primaryBtnText)) { primary = btns[b]; primaryText = t; break; }
      }
      var kind = primary ? (matchAny(primaryText, ['继续学习', '继续播放', '继续']) ? 'anti-idle' : 'confirm') : 'unknown';
      out.push({ kind: kind, text: text, btnText: primaryText, layer: c.layer, note: c.note, btn: primary });
    }
    lastDialogs = out;
    return out.map(function (d) {
      return { kind: d.kind, text: d.text, btnText: d.btnText || '', evidence: d.evidence || null, layer: d.layer, note: d.note };
    });
  }

  /* ---- 弹题（P2）----
     学习通作业页（章节测验）不是「一题一弹窗」，而是一个页面里多道题：
       题块  .TiMu.newTiMu
       选项  li.font-cxsecret.before-after（每个 li 一个选项，内含 span.num_option[data="A"]）
       提交  A.btnSubmit.workBtnIndex（文本 "Submit"，英文！） / A.btnSave.workBtnIndex（"Save"）
     所以这里按「题块」解析，一次返回全部题目，引擎逐题作答。 */
  var lastQuiz = { optionEls: [], submitEl: null, layer: 0, note: '', blocks: [] };

  /* 从题块里取选项：优先 li.font-cxsecret.before-after（一个 li = 一个选项），
     字母来自 span.num_option[data]（A/B/C/D）。
     绝不能把 'label, li' 混着抓——li 里嵌着 label.fl.before，4 个选项会变成 8 个。 */
  function optionsInBlock(block) {
    var out = [];
    var lis = null;
    try { lis = block.querySelectorAll('li.font-cxsecret.before-after'); } catch (e) { lis = null; }
    if (lis && lis.length) {
      for (var i = 0; i < lis.length; i++) {
        var li = lis[i];
        if (!visible(li)) continue;
        var letter = '';
        try {
          var numEl = li.querySelector(S.quizOptionLetterSel);
          if (numEl) letter = numEl.getAttribute('data') || '';
        } catch (e2) { /* ignore */ }
        /* 判断题的 data 属性是 "true"/"false"，不是 A/B —— 字母一律按位置重编，
           否则「只输出 A/B/C/D」的指令与选项字母对不上，模型会乱答。 */
        letter = String.fromCharCode(65 + out.length);
        var txt = norm(li.innerText || '');
        out.push({ i: out.length, letter: letter, rawLetter: letter, label: txt.slice(0, 100), el: li });
      }
      return out;
    }
    /* 退化路径：可见单选框（经典弹题） */
    var radios = block.querySelectorAll('input[type="radio"], input[type="checkbox"]');
    var vis = [];
    for (var r = 0; r < radios.length; r++) { if (visible(radios[r])) vis.push(radios[r]); }
    for (var r2 = 0; r2 < vis.length; r2++) {
      var lab = vis[r2].closest ? vis[r2].closest('label') : null;
      var t2 = norm(lab ? lab.innerText : '') || ('选项' + (r2 + 1));
      out.push({ i: r2, letter: String.fromCharCode(65 + r2), label: t2.slice(0, 100), el: lab || vis[r2] });
    }
    return out;
  }

  /* 提交按钮：先按 class 找（学习通是英文 class，最稳），再按文本找（中文界面兜底）。 */
  function findSubmit() {
    for (var i = 0; i < S.quizSubmitSel.length; i++) {
      var els = null;
      try { els = document.querySelectorAll(S.quizSubmitSel[i]); } catch (e) { els = null; }
      if (!els) continue;
      for (var j = 0; j < els.length; j++) {
        if (!visible(els[j])) continue;
        var t = norm(els[j].innerText || els[j].value || '');
        if (!t) continue;
        return { el: els[j], text: t.slice(0, 30) };
      }
    }
    var btns = findButtons(document);
    for (var b = 0; b < btns.length; b++) {
      var t2 = norm(btns[b].innerText || btns[b].value || '');
      if (matchAny(t2, S.quizSubmitText)) return { el: btns[b], text: t2.slice(0, 30) };
    }
    return null;
  }

  function quizScan() {
    lastQuiz = { optionEls: [], submitEl: null, layer: 0, note: '', blocks: [] };

    /* —— 路径 A：作业页题块（学习通）—— */
    var qblocks = null;
    try { qblocks = document.querySelectorAll(S.quizQuestionSel); } catch (e) { qblocks = null; }
    if (qblocks && qblocks.length) {
      var blocks = [];
      for (var bi = 0; bi < qblocks.length; bi++) {
        var blk = qblocks[bi];
        if (!visible(blk)) continue;
        var opts = optionsInBlock(blk);
        if (!opts.length) continue;
        var titleEl = null;
        try { titleEl = blk.querySelector('.Zy_TItle, .TiMu_bq'); } catch (e3) { titleEl = null; }
        var qtext = norm(titleEl ? titleEl.innerText : '') || norm(blk.innerText || '').slice(0, 200);
        blocks.push({
          i: blocks.length,
          qid: blk.id || ('q' + bi),
          question: qtext.slice(0, 300),
          /* 判断题题干里带 【True or False】，单选题带 【Single Choice】 */
          kind: /true\s*or\s*false|判断/i.test(qtext) ? 'judge' : 'single',
          options: opts.map(function (o) { return { i: o.i, letter: o.letter, label: o.label }; })        });
      }
      if (blocks.length) {
        lastQuiz.blocks = blocks;
        lastQuiz.layer = 2;
        lastQuiz.note = 'chaoxing-work-page';
        var q = {
          kind: 'chapter_work', present: true, parseable: true, blocks: blocks,
          options: blocks[0].options, question: blocks[0].question,
          layer: 2, note: 'chaoxing-work-page', submitText: '', blockCount: blocks.length
        };
        var sub = findSubmit();
        if (sub) { lastQuiz.submitEl = sub.el; q.submitText = sub.text; }
        return q;
      }
    }

    /* —— 路径 B：经典弹题（单题）—— */
    var wrap = null, layer = 0, note = '';
    for (var i = 0; i < S.quizOption.length && !wrap; i++) {
      var nl = null;
      try { nl = document.querySelectorAll(S.quizOption[i].sel); } catch (e) { nl = null; }
      if (!nl) continue;
      for (var j = 0; j < nl.length; j++) {
        if (visible(nl[j])) { wrap = nl[j]; layer = S.quizOption[i].layer; note = S.quizOption[i].note; break; }
      }
    }
    var opts2 = [], question = '';
    if (wrap) {
      var holder = wrap;
      while (holder && holder !== document.body && holder.parentElement && holder.querySelectorAll('.cleanclick, label, li').length <= 1) holder = holder.parentElement;
      if (holder && holder !== document.body) {
        var list = holder.querySelectorAll('.cleanclick, label, li');
        for (var k = 0; k < list.length; k++) {
          var t = norm(list[k].innerText || '');
          if (visible(list[k]) && t && t.length < 120) {
            opts2.push({ i: opts2.length, letter: String.fromCharCode(65 + opts2.length), label: t.slice(0, 80) });
            lastQuiz.optionEls.push(list[k]);
          }
        }
        question = norm(holder.innerText || '').slice(0, 100);
      }
    } else {
      var radios2 = document.querySelectorAll('input[type="radio"], input[type="checkbox"]');
      var vis2 = [];
      for (var r3 = 0; r3 < radios2.length; r3++) { if (visible(radios2[r3])) vis2.push(radios2[r3]); }
      if (vis2.length >= 2) {
        layer = 3; note = 'generic-visible-radios';
        for (var r4 = 0; r4 < vis2.length; r4++) {
          var lab2 = vis2[r4].closest ? vis2[r4].closest('label') : null;
          var t3 = norm(lab2 ? lab2.innerText : '') || ('选项' + (r4 + 1));
          opts2.push({ i: r4, letter: String.fromCharCode(65 + r4), label: t3.slice(0, 80) });
          lastQuiz.optionEls.push(lab2 || vis2[r4]);
        }
      }
    }
    var q2 = { kind: 'popup_quiz', present: opts2.length > 0, parseable: opts2.length > 0, blocks: [], options: opts2, question: question, layer: layer, note: note, submitText: '' };
    if (opts2.length) {
      var sub2 = findSubmit();
      if (sub2) { lastQuiz.submitEl = sub2.el; q2.submitText = sub2.text; }
    }
    lastQuiz.layer = layer; lastQuiz.note = note;
    return q2;
  }

  /* ---- 章内「章节测验」入口（学习通 .prev_ul li）----
     课程页里「1视频 / 2章节测验」是章内子任务标签，点「章节测验」才会把题目
     加载到 popFrameId iframe（平时是 about:blank 空页）。 */
  var lastQuizTab = { el: null, index: -1, title: '' };
  var lastVideoTab = { el: null, index: -1, title: '' };
  function quizTabScan() {
    lastQuizTab = { el: null, index: -1, title: '' };
    lastVideoTab = { el: null, index: -1, title: '' };
    var nl = null;
    try { nl = document.querySelectorAll(S.quizTabSel); } catch (e) { nl = null; }
    if (!nl) return lastQuizTab;
    for (var i = 0; i < nl.length; i++) {
      var it = nl[i];
      var title = (it.getAttribute && it.getAttribute('title')) || '';
      var t = norm(title || it.innerText || '');
      if (!t) continue;
      if (matchAny(t, S.quizTabText)) {
        lastQuizTab = { el: it, index: i, title: t.slice(0, 40) };
        return lastQuizTab;
      }
      if (matchAny(t, S.videoTabText)) {
        lastVideoTab = { el: it, index: i, title: t.slice(0, 40) };
      }
    }
    return lastQuizTab;
  }

  /* ---- 随堂弹题（视频内嵌答题 ans-videoquiz）----
     超星视频播到某时间点会弹出一道题强制暂停（主人报"视频没看完"的根因之一：
     引擎没识别这道题，只会反复点播放按钮，视频就永远卡在弹题点）。
     结构：.ans-videoquiz 内含 .tkItem_title（题干）+ li.ans-videoquiz-opt（选项）
     + #videoquiz-submit（提交）+ #videoquiz-continue（答对后点它继续播放）。 */
  var lastVideoQuiz = { el: null, layer: 2, note: '' };
  function videoQuizScan() {
    lastVideoQuiz = { el: null, layer: 2, note: '' };
    var el = null;
    try { el = document.querySelector(S.videoQuiz.containerSel); } catch (e) { el = null; }
    if (!el) return { present: false };
    if (!visible(el)) return { present: false };
    var title = '';
    try {
      var te = el.querySelector(S.videoQuiz.titleSel);
      title = norm(te ? te.innerText : '');
    } catch (e2) { /* ignore */ }
    // 选项：li.ans-videoquiz-opt，文本形如 "A、对" / "B、错"（radio value 是空串，答案在文本）
    var options = [];
    try {
      var lis = el.querySelectorAll(S.videoQuiz.optionSel);
      for (var i = 0; i < lis.length; i++) {
        if (!visible(lis[i])) continue;
        var t = norm(lis[i].innerText || '');
        if (!t) continue;
        // 去掉 "A、" 之类的前缀，只留选项文本
        var cleaned = t.replace(/^[A-H][、.．]\s*/, '');
        options.push({ i: options.length, letter: String.fromCharCode(65 + options.length), label: cleaned || t });
      }
    } catch (e3) { /* ignore */ }
    // 提交/继续按钮状态
    var submit = null, cont = null, correct = false, wrong = false;
    try { submit = el.querySelector(S.videoQuiz.submitSel); } catch (e4) { /* ignore */ }
    try { cont = el.querySelector(S.videoQuiz.continueSel); } catch (e5) { /* ignore */ }
    try { var c = el.querySelector(S.videoQuiz.correctSel); correct = !!(c && visible(c)); } catch (e6) { /* ignore */ }
    try { var w = el.querySelector(S.videoQuiz.wrongSel); wrong = !!(w && visible(w)); } catch (e7) { /* ignore */ }
    /* ★★ 盲试所需的两项关键信息（2026-10-27 主人要求「答错换答案一直试到对」）：
       wrongBack : 答错且要求「回看 N 分钟」→ 不能盲试，必须停
       remaining : 面板文本里的「剩余 N 次」→ 剩余尝试次数，降到 0 就停

       ★ 2026-10-29 修正（对照 xuexitong-ai-assistant L4467-4469）：
       参考项目的注释写得很明确：
         "spanNotBackPoint is also used for ordinary failures with an editable form.
          Its ID alone does not mean the learner must return to an earlier video point."
       它不靠 ID 判断，而是**看文本**里有没有「回看 / 回到知识点 / 重新观看 / 返回观看」。
       我们原来只看 #spanNotBack 是否可见，会把「普通答错但仍可重答」误判成必须停，
       导致盲试过早放弃。现在改为：先看元素，再用文本确认。 */
    var wrongBack = false;
    var wrongBackText = '';
    try {
      var wb = el.querySelector(S.videoQuiz.wrongBackSel);
      if (wb && visible(wb)) {
        wrongBackText = norm(wb.innerText || wb.textContent || '').slice(0, 80);
        /* 只有文本明确要求回看/重看，才算「必须停」；空文本按 ID 语义处理（保守） */
        wrongBack = !wrongBackText || /回看|回到.*(?:知识点|视频)|重新观看|返回观看/.test(wrongBackText);
      }
    } catch (e8) { /* ignore */ }
    var remaining = null;
    var panelText = '';
    try {
      panelText = norm(el.innerText || '').slice(0, 160);
      var rm = panelText.match(/剩余\s*[:：]?\s*(\d+)\s*次/);
      if (rm) remaining = Number(rm[1]);
    } catch (e9) { /* ignore */ }
    /* 兜底：即使 #spanNotBack 没出现，面板文本里出现回看要求也要停 */
    if (!wrongBack && /回看|重新观看|返回观看/.test(panelText)) {
      wrongBack = true;
      wrongBackText = wrongBackText || panelText.slice(0, 80);
    }
    /* 反馈原文里能提取「正确答案：X」时一并带出，供盲试少走弯路 */
    var correctAnswer = '';
    try {
      var ca = panelText.match(/正确答案\s*[:：]\s*([A-T](?:[A-T\s,，、]*))/);
      if (ca) correctAnswer = ca[1].replace(/[\s,，、]/g, '');
      else {
        var cb = panelText.match(/正确答案\s*[:：]\s*(对|错|正确|错误)/);
        if (cb) correctAnswer = cb[1];
      }
    } catch (e10) { /* ignore */ }
    lastVideoQuiz = { el: el, layer: 2, note: 'video-quiz:' + title.slice(0, 30) };
    return {
      kind: 'video_embedded_quiz', present: true, title: title, options: options,
      submitVisible: !!(submit && visible(submit)),
      continueVisible: !!(cont && visible(cont)),
      correct: correct, wrong: wrong,
      wrongBack: wrongBack, wrongBackText: wrongBackText,
      correctAnswer: correctAnswer,
      remaining: remaining, panelText: panelText,
      note: lastVideoQuiz.note
    };
  }

  /* ---- 左侧目录（P1/P3/P4）----
     学习通有两套目录，必须优先抓「完整课程目录」.posCatalog_select：
       - 章头：.posCatalog_select.firstLayer，内含 span.posCatalog_title（可折叠）
       - 节  ：.posCatalog_select[id^=cur]，内含 span.posCatalog_name（标题）
               + input.jobUnfinishCount（value = 剩余未完成任务数，0 表示已完成）
     而 .prev_ul li 是「章内子任务」（1视频 / 2章节测验），只有当课程目录不存在时才用。 */
  var lastToc = { els: [], layer: 0, note: '' };
  function tocScan() {
    lastToc = { els: [], layer: 0, note: '' };
    var sel = null, layer = 0, note = '';
    for (var i = 0; i < S.tocItem.length; i++) {
      var nl = null;
      try { nl = document.querySelectorAll(S.tocItem[i].sel); } catch (e) { nl = null; }
      if (nl && nl.length >= 2) { sel = S.tocItem[i].sel; layer = S.tocItem[i].layer; note = S.tocItem[i].note; break; }
    }
    if (!sel) return { found: false, items: [], layer: 0, sel: '', note: '' };
    var nl2 = document.querySelectorAll(sel);
    var items = [];
    for (var j = 0; j < nl2.length; j++) {
      var it = nl2[j];
      // 学习通课程目录：标题在 span.posCatalog_name / span.posCatalog_title
      var nameEl = it.querySelector ? (it.querySelector('.posCatalog_name') || it.querySelector('.posCatalog_title')) : null;
      var t = norm(nameEl ? (nameEl.innerText || nameEl.getAttribute('title') || '') : (it.innerText || ''));
      if (!t) continue;
      /* 章头判定：优先结构 class（firstLayer / posCatalog_title）；正则兜底只认"纯章标题"，
         否则"第一章 1.2 视频A"这类叶子节点会被误判（真实站点实测踩坑） */
      var isHeader = !!hasClassLike(it, S.tocChapterClass) || !!hasClassLike(it, S.chapterHeaderClass)
        || !!it.querySelector('.posCatalog_title')
        || /^第\\s*[0-9一二三四五六七八九十百]+[章单元篇]\\s*$/.test(t);
      var done = !!matchAny(t, S.doneText) || !!hasClassLike(it, S.doneClass);
      /* 完成标记常在**子元素**上：实测学习通已完成的小节结构是
           <div class="posCatalog_select posCatalog_active">
             <span class="posCatalog_name">…</span>
             <span class="icon_Completed prevTips"><span class="prevHoverTips">Completed</span></span>
           </div>
         即节点自身没有 done 类，完成图标在子 span 上 → 必须查后代。 */
      if (!done) {
        try {
          var doneKid = it.querySelector ? it.querySelector('.' + S.doneClass[0]) : null;
          if (doneKid) done = true;
        } catch (e3) { /* ignore */ }
      }
      /* 完成度判定：input.jobUnfinishCount 的 value = 剩余未完成任务数（0 = 已完成）。
         这是学习通唯一可靠的完成标记，文本「已完成」并不总出现。
         ★ 实测坑：已完成的小节**没有** jobUnfinishCount 这个 input（已完成就不再有待办数），
           所以「没有该 input」+ 有 icon_Completed 才代表这节真的做完了。 */
      var unfinish = -1;
      try {
        var uf = it.querySelector ? it.querySelector(S.tocUnfinishCountSel) : null;
        if (uf) {
          var v = parseInt(uf.value, 10);
          if (!isNaN(v)) { unfinish = v; if (v === 0) done = true; }
        }
      } catch (e2) { /* ignore */ }
      /* 当前节：只看 class。
         ★ 实测坑：学习通所有目录节点 id 都是 "cur143114xxx"，
           用 id 前缀判 current 会把 85 项全判成当前节 → 永远在第一章打转。 */
      var current = !!hasClassLike(it, S.tocCurrentClass);
      /* 节点的 chapterId：学习通目录项 id 形如 "cur143114596" ⇒ 去掉 cur 前缀即 chapterId。
         用途：重载页面时要用**当前节的** chapterId，否则会跳回最初那节
         （课程 URL 里的 chapterId 是固定的第一节）。 */
      var chapterId = '';
      try {
        var rawId = String(it.id || '');
        var mId = rawId.match(/^cur(\d+)$/);
        if (mId) chapterId = mId[1];
        else {
          var oc = it.querySelector ? it.querySelector('[onclick*="getTeacherAjax"]') : null;
          if (oc) {
            var mo = String(oc.getAttribute('onclick') || '').match(/getTeacherAjax\('[^']*','[^']*','(\d+)'\)/);
            if (mo) chapterId = mo[1];
          }
        }
      } catch (e5) { /* ignore */ }
      items.push({ i: items.length, title: t.slice(0, 60), done: done, current: current, chapterHeader: isHeader, clickable: true, unfinish: unfinish, chapterId: chapterId });
      lastToc.els.push(it);
    }
    lastToc.layer = layer; lastToc.note = note;
    return { found: items.length > 0, items: items, layer: layer, sel: sel, note: note };
  }

  /* ---- 人工验证特征（安全停止信号，绝不绕过）---- */
  function humanScan() {
    var text = norm(document.body ? document.body.innerText : '').slice(0, 4000);
    var hit = matchAny(text, KWS);
    return hit ? { detected: true, evidence: hit } : { detected: false, evidence: null };
  }

  /* ---- 登录态特征（前置检查用；脚本绝不自动登录）---- */
  function loginScan() {
    var pw = document.querySelector('input[type="password"]');
    var re = null;
    try { re = new RegExp(PAT); } catch (e) { re = null; }
    return { host: location.host, href: String(location.href).slice(0, 140), hasPwField: !!(pw && visible(pw)), hostHit: !!(re && re.test(location.host)) };
  }

  /* ---- 统一解析：kind → 元素（find / jsClick 复用；点击前实时解析防矩形过期）---- */
  function resolve(kind, arg) {
    if (kind === 'videoToggle') {
      var big = document.querySelector('.vjs-big-play-button');
      if (big && visible(big)) return { el: big, layer: 1, note: 'vjs-big-play-button' };
      var v = document.querySelector('video');
      if (v && visible(v)) return { el: v, layer: 2, note: 'video-element' };
      var p = document.querySelector('.playIcon, [class*="playButton"], [class*="play-btn"]');
      if (p && visible(p)) return { el: p, layer: 3, note: 'play-icon-candidate(generic)' };
      return null;
    }
    if (kind === 'dialogPrimary') {
      if (!lastDialogs.length) dialogScan();
      for (var i = 0; i < lastDialogs.length; i++) {
        var d = lastDialogs[i];
        if ((d.kind === 'anti-idle' || d.kind === 'confirm') && d.btn) return { el: d.btn, layer: d.layer, note: d.note };
      }
      return null;
    }
    if (kind === 'quizOption') {
      if (!lastQuiz.optionEls.length) quizScan();
      var idx = (arg === null || arg === undefined) ? 0 : arg;
      var el = lastQuiz.optionEls[idx];
      return el ? { el: el, layer: lastQuiz.layer || 2, note: lastQuiz.note || '' } : null;
    }
    /* 作业页按题块取选项：arg = {b: 题块序号, o: 选项序号}
       （学习通一道题一个 .TiMu.newTiMu，选项是 li.font-cxsecret.before-after） */
    if (kind === 'quizBlockOption') {
      var a = arg || {};
      var bi = Number(a.b) || 0;
      var oi = Number(a.o) || 0;
      var blocks2 = [];
      var qb = null;
      try { qb = document.querySelectorAll(S.quizQuestionSel); } catch (e) { qb = null; }
      if (!qb) return null;
      for (var qbi = 0; qbi < qb.length; qbi++) {
        if (!visible(qb[qbi])) continue;
        var os = optionsInBlock(qb[qbi]);
        if (!os.length) continue;
        blocks2.push(os);
      }
      var opts3 = blocks2[bi];
      if (!opts3) return null;
      var el3 = opts3[oi];
      if (!el3) return null;
      return { el: el3.el, layer: 2, note: 'block' + bi + '-opt' + oi };
    }
    /* 作业页提交按钮 */
    if (kind === 'quizBlockSubmit') {
      var sub = findSubmit();
      if (!sub) return null;
      return { el: sub.el, layer: 2, note: 'work-submit:' + sub.text };
    }
    /* 作业提交确认框的「确定」按钮。
       超星 btnBlueSubmit() → validateTimeNew() → toadd() → workPop('Submit？','Submit','Cancel')
       会弹一个 #workpop 确认框；只有点了 #popok 才会 submitCheckTimes() → form1submit() 真提交。
       ★ 坑：这个弹窗是用 **top.workPop** 渲染的，所以它出现在**顶层 frame** 里，
         作业 frame（doHomeWorkNew）里虽然也有同名 #workpop，但那个永远 display:none。
         因此引擎必须到顶层 frame 去找这个确认框。 */
    if (kind === 'workConfirm') {
      var wp = document.getElementById('workpop');
      if (!wp || !visible(wp)) return null;
      var okb = document.getElementById('popok');
      if (!okb || !visible(okb)) return null;
      var pcontent = document.getElementById('popcontent');
      return {
        el: okb, layer: 2,
        note: 'workpop-confirm:' + norm(pcontent ? (pcontent.innerText || '') : '').slice(0, 60),
      };
    }
    /* 作业页题块矩形（截图用）：arg = {b: 题块序号}
       返回该题块在**本 frame 视口**里的并集矩形（题块 + 题干 + 全部选项），
       纯视口坐标，不做任何跨 frame 换算 —— 换算由引擎（CDP 侧）统一做，
       因为跨源时页面侧读不到父 frame 的滚动量。 */
    if (kind === 'quizBlockRect') {
      var a2 = arg || {};
      var bi2 = Number(a2.b) || 0;
      var seen = 0;
      var qb2 = null;
      try { qb2 = document.querySelectorAll(S.quizQuestionSel); } catch (e) { qb2 = null; }
      if (!qb2) return null;
      for (var qbi2 = 0; qbi2 < qb2.length; qbi2++) {
        if (!visible(qb2[qbi2])) continue;
        var os2 = optionsInBlock(qb2[qbi2]);
        if (!os2.length) continue;
        if (seen === bi2) {
          var blk2 = qb2[qbi2];
          var parts2 = [];
          var push2 = function (el) {
            if (!el) return;
            var rr = el.getBoundingClientRect();
            if (rr && rr.width > 0 && rr.height > 0) parts2.push(rr);
          };
          push2(blk2);
          push2(blk2.querySelector('.Zy_TItle'));
          push2(blk2.querySelector('.TiMu_bq'));
          for (var oi2 = 0; oi2 < os2.length; oi2++) push2(os2[oi2].el);
          var u2 = unionRectOf2(parts2);
          if (!u2) return null;
          u2.rectOnly = true;
          u2.note = 'block' + bi2;
          u2.blockIndex = bi2;
          return u2;
        }
        seen++;
      }
      return null;
    }
    /* 把第 b 个题块滚到本 frame 的可视区（frame 内滚动，用于截图定位） */
    if (kind === 'quizBlockScroll') {
      var a3 = arg || {};
      var bi3 = Number(a3.b) || 0;
      var seen3 = 0;
      var qb3 = null;
      try { qb3 = document.querySelectorAll(S.quizQuestionSel); } catch (e) { qb3 = null; }
      if (!qb3) return null;
      for (var qbi3 = 0; qbi3 < qb3.length; qbi3++) {
        if (!visible(qb3[qbi3])) continue;
        var os3 = optionsInBlock(qb3[qbi3]);
        if (!os3.length) continue;
        if (seen3 === bi3) {
          try { qb3[qbi3].scrollIntoView({ block: 'start' }); } catch (e4) { try { qb3[qbi3].scrollIntoView(); } catch (e5) {} }
          return { el: qb3[qbi3], layer: 2, note: 'block' + bi3 + '-scrolled' };
        }
        seen3++;
      }
      return null;
    }
    if (kind === 'quizSubmit') {
      if (!lastQuiz.submitEl) quizScan();
      return lastQuiz.submitEl ? { el: lastQuiz.submitEl, layer: lastQuiz.layer || 2, note: 'quiz-submit' } : null;
    }
    if (kind === 'videoTab') {
      if (!lastVideoTab.el) quizTabScan();
      if (!lastVideoTab.el) return null;
      var inner3 = lastVideoTab.el.querySelector('a, [onclick]') || lastVideoTab.el;
      return { el: inner3, layer: 2, note: 'video-tab:' + lastVideoTab.title };
    }
    if (kind === 'quizTab') {
      if (!lastQuizTab.el) quizTabScan();
      if (!lastQuizTab.el) return null;
      var inner2 = lastQuizTab.el.querySelector('a, [onclick]') || lastQuizTab.el;
      return { el: inner2, layer: 2, note: 'quiz-tab:' + lastQuizTab.title };
    }
    if (kind === 'tocItem') {
      if (!lastToc.els.length) tocScan();
      var el2 = lastToc.els[arg];
      if (!el2) { tocScan(); el2 = lastToc.els[arg]; }
      if (!el2) return null;
      var inner = el2.querySelector('a, [onclick]') || el2;
      return { el: inner, layer: lastToc.layer || 2, note: lastToc.note || '' };
    }
    /* 随堂弹题：点第 arg 个选项（li.ans-videoquiz-opt 内的 label，点 label 触发 radio） */
    if (kind === 'videoQuizOption') {
      if (!lastVideoQuiz.el) videoQuizScan();
      if (!lastVideoQuiz.el) return null;
      var vqLis = null;
      try { vqLis = lastVideoQuiz.el.querySelectorAll(S.videoQuiz.optionSel); } catch (e) { vqLis = null; }
      if (!vqLis || !vqLis.length) return null;
      var vqIdx = (arg === null || arg === undefined) ? 0 : Number(arg);
      var vqEl = vqLis[vqIdx];
      if (!vqEl || !visible(vqEl)) return null;
      // 点 label（label 会触发内嵌 radio 的选中）
      var vqLabel = vqEl.querySelector('label') || vqEl;
      return { el: vqLabel, layer: 2, note: 'videoquiz-opt' + vqIdx };
    }
    /* 随堂弹题：提交 */
    if (kind === 'videoQuizSubmit') {
      if (!lastVideoQuiz.el) videoQuizScan();
      if (!lastVideoQuiz.el) return null;
      var vqs = lastVideoQuiz.el.querySelector(S.videoQuiz.submitSel);
      if (!vqs || !visible(vqs)) return null;
      return { el: vqs, layer: 2, note: 'videoquiz-submit' };
    }
    /* 随堂弹题：答对后点「继续」恢复播放 */
    if (kind === 'videoQuizContinue') {
      if (!lastVideoQuiz.el) videoQuizScan();
      if (!lastVideoQuiz.el) return null;
      var vqc = lastVideoQuiz.el.querySelector(S.videoQuiz.continueSel);
      if (!vqc || !visible(vqc)) return null;
      return { el: vqc, layer: 2, note: 'videoquiz-continue' };
    }
    return null;
  }

  window.__cx = {
    __v: S.version,
    probeAll: function () {
      /* ★ 2026-10-29：把任务点清单一起返回。
         参考 xuexitong-ai-assistant 的 pageInventory.markers：按 .ans-attach-ct
         逐个分类（video/audio/document/quiz/discussion）并各自记 finished，
         这样「视频这个任务点完成」就足以进下一节，不必等整节归零。
         之前引擎只统计数量、不落到判定里，遇到「视频已完成 + 测验未做」就无限空转。 */
      var tasks = [];
      try {
        var cts = document.querySelectorAll('.ans-attach-ct');
        for (var i = 0; i < cts.length; i++) {
          var el = cts[i];
          var icon = el.querySelector('.ans-job-icon');
          var ifr = el.querySelector('iframe');
          var src = ifr ? (ifr.getAttribute('src') || '') : '';
          var label = icon ? (icon.getAttribute('aria-label') || '') : '';
          var kind = 'unknown';
          if (/\/modules\/audio\//i.test(src) || (ifr && ifr.getAttribute('module') === 'insertaudio')) kind = 'audio';
          else if (/\/modules\/video\//i.test(src)) kind = 'video';
          else if (/work|quiz|exam/i.test(src)) kind = 'quiz';
          else if (/pdf|doc|read|screen/i.test(src)) kind = 'document';
          else if (ifr && /insertbbs/i.test(ifr.getAttribute('module') || '')) kind = 'discussion';
          else if (el.querySelector('video,audio')) kind = 'video';
          tasks.push({
            kind: kind,
            finished: el.classList.contains('ans-job-finished') || /已完成|complete/i.test(label),
            label: label.slice(0, 24)
          });
        }
      } catch (e) { /* ignore */ }
      return {
        url: String(location.href).slice(0, 160),
        video: videoState(),
        dialogs: dialogScan(),
        quiz: quizScan(),
        videoQuiz: videoQuizScan(),
        quizTab: (function () { var q = quizTabScan(); return { present: !!q.el, title: q.title, index: q.index }; })(),
        toc: tocScan(),
        human: humanScan(),
        login: loginScan(),
        tasks: tasks
      };
    },
    videoState: videoState,
    find: function (kind, arg) {
      var r = resolve(kind, arg);
      if (!r) return { ok: false, reason: 'not-found' };
      /* 矩形类 kind（截图裁剪用）：直接返回坐标，不做可见性/元素校验 */
      if (r.rectOnly) return { ok: true, rect: r, note: r.note, blockIndex: r.blockIndex };
      if (!r.el || !visible(r.el)) return { ok: false, reason: 'not-found-or-hidden' };
      var rect = rectOf(r.el);
      if (rect.cross) return { ok: false, reason: 'cross-origin-rect', jsFallback: true };
      /* 视口外保护：真实课程页的目录/播放器常需滚动；先滚入可视区再取坐标，
         否则全局坐标会落在 iframe/页面可视区之外，输入事件命中不到目标 */
      var vh = 100000, vw = 100000;
      try { vh = window.top.innerHeight || vh; vw = window.top.innerWidth || vw; } catch (e) { vh = window.innerHeight; vw = window.innerWidth; }
      if (rect.y + rect.h < 0 || rect.y > vh || rect.x + rect.w < 0 || rect.x > vw) {
        try { r.el.scrollIntoView({ block: 'center' }); } catch (e2) { r.el.scrollIntoView(); }
        rect = rectOf(r.el);
        return { ok: true, text: norm(r.el.innerText || r.el.value || '').slice(0, 60), rect: rect, layer: r.layer, note: r.note + '+scrolled', scrolled: true };
      }
      return { ok: true, text: norm(r.el.innerText || r.el.value || '').slice(0, 60), rect: rect, layer: r.layer, note: r.note };
    },
    jsClick: function (kind, arg) {
      var r = resolve(kind, arg);
      if (!r || !r.el || !visible(r.el)) return { ok: false, reason: 'not-found-or-hidden' };
      r.el.click();
      return { ok: true, text: norm(r.el.innerText || r.el.value || '').slice(0, 60), layer: r.layer, note: r.note };
    }
  };
  return 'installed';
})();`;

/** 组装注入表达式：选择器注册表 + 风险关键词 + 登录域特征 + 页面探测代码 */
function installProbeExpression(cfg) {
  return 'window.__CX_SEL=' + JSON.stringify(SELECTORS) + ';' +
    'window.__CX_KWS=' + JSON.stringify(cfg.safety.fatalKeywords) + ';' +
    'window.__CX_PATTERN=' + JSON.stringify(cfg.safety.loginHostPattern) + ';' +
    PAGE_PROBE_SRC;
}

/* ============================================================================
 * 第 6 节 · 业务状态机
 *   PLAYING_CHECK → QUIZ_INTERRUPT → SECTION_ADVANCE → WAIT_LOAD → IDLE(轮询)
 *   任意状态 → FATAL_STOP（人工验证 / 登录失效 / 连续失败 / 防呆）
 * ==========================================================================*/
const NORMAL_STOP = ['all_done_or_no_target', 'max_sections_reached', 'chapter_boundary', 'max_runtime_exceeded', 'user_abort'];

class LearnMachine {
  constructor(adapter, cfg) {
    this.adapter = adapter;
    this.cfg = cfg;
    this.counters = { sectionsCompleted: 0, sectionsSkipped: 0, quizzesAnswered: 0, dialogsDismissed: 0 };
    this.failures = 0;
    this.stopReason = null;
    this.stoppedNormally = false;
    this._lastState = null;
    this._lastCurIdx = null;
    this._currentTitle = '当前节';
    this._videoSeenThisSection = false;
    this._waitTicks = 0;
    this._mutedTried = false;
    /* ★ 2026-10-29：本次运行「真正启动过」的视频 src 指纹集合。
       参考 xuexitong-ai-assistant 的 startedVideos（WeakSet<HTMLVideoElement>）：
       只有本次运行亲自推动播放过的视频，才允许用 ended/进度 判定「播完」；
       历史残留的播放器（duration=0、ended 默认 true、或上次留下的旧 currentTime）
       一律不能作为完成证据 —— 这正是 3.3↔3.4 空转的根因。
       CDP 侧拿不到元素引用，改用 currentSrc 指纹代替。 */
    this._startedVideoSrcs = new Set();
    // 视频播放停滞检测（CDN 签名过期 → 源 403 → 进度卡住）
    this._stallTicks = 0;
    this._lastProgressTime = undefined;
    this._resumeAttempts = 0;
    this._lastVideoFrameId = null;
    this._lastVideoCurrentTime = undefined;
    this._lastVideoDuration = undefined;
    this._lastVideoSrc = '';
    this._videoProgressTicks = 0;
    // 当前节的 chapterId（重载页面时要用，课程 URL 里的是固定的第一节）
    this._currentChapterIdValue = '';
    // 章内「章节测验」状态
    this._quizTabOpened = false;
    this._quizTabWaitTicks = 0;
    this._quizTabDoneFor = null;
    this._quizTabChapter = null;
  }

  stop(reason) {
    if (this.stopReason) return;
    this.stopReason = reason;
    this.stoppedNormally = NORMAL_STOP.indexOf(reason) >= 0;
    logger.info('LOOP', '达到停止条件', { reason, counters: this.counters });
    /* ★ 分层：把停止事实写进中间文件，插件/另一层不必解析日志 */
    try {
      if (BUS && BUS.reportLearn) {
        BUS.reportLearn({
          phase: 'stopped',
          stopReason: reason,
          section: this._currentTitle,
          counters: this.counters,
        });
      }
      busEmit('learn', 'stop', { reason, section: this._currentTitle });
    } catch (_) { /* ignore */ }
  }

  fatalStop(code, msg, meta) {
    if (this.stopReason) return;
    this.stopReason = code;
    this.stoppedNormally = false;
    logger.error('FATAL', code === 'HUMAN_VERIFICATION' ? msg : 'FATAL: ' + code + ' — ' + msg, meta);
    if (code === 'HUMAN_VERIFICATION') logger.error('FATAL', '按安全策略立即停止，不做任何绕过尝试');
    if (code === 'UNRECOGNIZED_PAGE') logger.error('FATAL', '诊断信息: ' + JSON.stringify(this.lastDiagnostics()).slice(0, 1200));
    try {
      if (BUS && BUS.reportLearn) {
        BUS.reportLearn({
          phase: 'fatal',
          stopReason: code,
          message: String(msg || '').slice(0, 300),
          section: this._currentTitle,
          counters: this.counters,
        });
      }
      busEmit('learn', 'fatal', { code, section: this._currentTitle });
    } catch (_) { /* ignore */ }
  }

  lastDiagnostics() {
    const st = this._lastState || {};
    return {
      topUrl: st.topUrl || '',
      frames: (st.frames || []).map((f) => ({
        frameId: f.frameId, url: f.url, error: f.error || null,
        hasVideo: !!(f.probe && f.probe.video && f.probe.video.found),
        tocFound: !!(f.probe && f.probe.toc && f.probe.toc.found)
      })),
      counters: this.counters,
      failures: this.failures
    };
  }

  /** 逐帧注入探测代码并合并全量状态（iframe 递归遍历发生在 adapter.getFrameDocuments） */
  async gatherState() {
    const frames = await this.adapter.getFrameDocuments();
    const inst = installProbeExpression(this.cfg);
    const st = { frames: [], topUrl: '', video: null, videoFrameId: null, dialogs: [], human: [], quiz: null, quizFrameId: null, videoQuiz: null, quizTab: null, toc: null, loginInvalid: false, loginEvidence: [] };
    for (const f of frames) {
      const rec = { frameId: f.frameId, url: f.url, isTop: !!f.isTop };
      try {
        await this.adapter.evalInFrame(f.frameId, inst);
        rec.probe = await this.adapter.evalInFrame(f.frameId, '__cx.probeAll()');
      } catch (e) {
        rec.error = String((e && e.message) || e).slice(0, 120);
      }
      st.frames.push(rec);
    }
    const probes = st.frames.filter((f) => f.probe);
    const top = probes.find((f) => f.isTop) || probes[0];
    st.topUrl = (top && top.probe.url) || (frames[0] && frames[0].url) || '';
    /* ★ 2026-10-29：缓存本次扫描到的任务点清单，供 _videoTaskDone 判定「视频任务已完成」。
       probeAll 现在会返回 tasks[]（kind + finished），逐个 .ans-attach-ct 分类。
       参考 xuexitong-ai-assistant 的 pageInventory.markers 设计。 */
    {
      const allTasks = [];
      for (const f of probes) {
        const ts = f.probe && f.probe.tasks;
        if (Array.isArray(ts)) for (const t of ts) allTasks.push(t);
      }
      this._lastInventory = { tasks: allTasks, at: Date.now() };
    }
    for (const f of probes) {
      const v = f.probe.video;
      if (v && v.found && (!st.video || (v.progress || 0) > (st.video.progress || 0))) {
        st.video = Object.assign({}, v, { frameId: f.frameId });
        st.videoFrameId = f.frameId;
      }
      for (const d of f.probe.dialogs || []) {
        st.dialogs.push(Object.assign({}, d, { frameId: f.frameId }));
        if (d.kind === 'human') st.human.push({ evidence: d.evidence, frameId: f.frameId });
      }
      if (f.probe.human && f.probe.human.detected) st.human.push({ evidence: f.probe.human.evidence, frameId: f.frameId });
      const q = f.probe.quiz;
      if (q && q.present && (!st.quiz || (!st.quiz.parseable && q.parseable))) {
        st.quiz = Object.assign({}, q, { frameId: f.frameId });
        st.quizFrameId = f.frameId;
      }
      /* 随堂弹题（视频内嵌答题）：优先级最高，一出现就处理（它会把视频强制暂停） */
      const vq = f.probe.videoQuiz;
      if (vq && vq.present && !st.videoQuiz) st.videoQuiz = Object.assign({}, vq, { frameId: f.frameId });
      const qt = f.probe.quizTab;
      if (qt && qt.present && !st.quizTab) st.quizTab = Object.assign({}, qt, { frameId: f.frameId });
      const t = f.probe.toc;
      if (t && t.found && !st.toc) st.toc = Object.assign({}, t, { frameId: f.frameId });
    }
    if (top) {
      const lg = top.probe.login || {};
      if (lg.hostHit && (lg.hasPwField || /passport|login/i.test(lg.href || ''))) {
        st.loginInvalid = true;
        st.loginEvidence.push('top:' + lg.host + ' pwField=' + lg.hasPwField);
      }
    }
    for (const f of probes) {
      const lg = f.probe.login || {};
      if (lg.hostHit && lg.hasPwField) { st.loginInvalid = true; st.loginEvidence.push('frame:' + lg.host); }
    }
    this._lastState = st;
    return st;
  }

  /** 点击前实时解析元素 + 拟人化延迟 + 真实输入事件；失败降级 JS click（WARN） */
  async clickFound(frameId, kind, arg) {
    let found;
    try {
      found = await this.adapter.evalInFrame(frameId, '__cx.find(' + JSON.stringify(kind) + ',' + JSON.stringify(arg === undefined ? null : arg) + ')');
    } catch (e) {
      return { ok: false, reason: 'find-eval-error: ' + String((e && e.message) || e).slice(0, 80) };
    }
    if (!found || !found.ok) {
      if (found && found.jsFallback) {
        logger.warn('CLICK', 'WARN 跨域 frame 无法计算全局坐标，降级为页内 JS click', { kind, layer: 3 });
        return this.jsClickFound(frameId, kind, arg);
      }
      return { ok: false, reason: found ? found.reason : 'find-null' };
    }
    await humanize.beforeClick(); // 拟人化：点击前随机延迟 300–1200ms
    if (found.scrolled) logger.info('CLICK', '目标在视口外，已滚动至可视区后点击', { kind, layer: found.layer });
    try {
      const r = await this.adapter.click(frameId, found.rect);
      logger.log('CLICK', 'INFO', '点击完成（真实输入事件）', { kind, layer: found.layer, note: found.note, text: found.text, mode: r.mode });
      return { ok: true, layer: found.layer, note: found.note, text: found.text };
    } catch (e) {
      logger.warn('CLICK', 'WARN 输入事件点击失败，降级为页内 JS click', { kind, err: String((e && e.message) || e).slice(0, 80) });
      return this.jsClickFound(frameId, kind, arg);
    }
  }

  async jsClickFound(frameId, kind, arg) {
    try {
      const r = await this.adapter.jsClick(frameId, kind, arg);
      if (r && r.ok) {
        logger.log('CLICK', 'WARN', '已用降级 JS click 完成点击', { kind, layer: r.layer || 3, note: r.note || '' });
        return { ok: true, layer: r.layer || 3, degraded: true };
      }
      return { ok: false, reason: r && r.reason };
    } catch (e) {
      this.failures += 1;
      return { ok: false, reason: 'jsClick-error: ' + String((e && e.message) || e).slice(0, 80) };
    }
  }

  async muteIfPossible(frameId) {
    if (this._mutedTried || !this.cfg.video.mute) return;
    this._mutedTried = true;
    try {
      await this.adapter.evalInFrame(frameId, 'Array.prototype.forEach.call(document.querySelectorAll("video"), function (v) { v.muted = true; }); true');
      logger.info('PLAYING_CHECK', '已将视频静音（等价用户点静音；NAS 环境防外放）');
    } catch (_) { /* 静音失败不阻塞 */ }
  }

  /** 单步状态机。返回 { progress, outcome }；progress=true 时主循环重置失败计数。 */
  async tick() {
    const st = await this.gatherState();

    /* ★ 2026-10-28：运行时风控检查（不只是 navigate 时）。
       实测：播放过程中超星也可能把当前页跳转到 detect.chaoxing.com，
       此时 gatherState 拿到的 frames 会异常，最终表现为 UNRECOGNIZED_PAGE。
       这里先直接看顶层 URL，命中就走「等 30 秒 → 刷新 → 重试，最多 2 次」的恢复流程。 */
    const topUrlNow = String((st && st.topUrl) || '');
    if (this.adapter && typeof this.adapter._isDetectUrl === 'function' && this.adapter._isDetectUrl(topUrlNow)) {
      const maxRetries = Number(this.cfg.detect && this.cfg.detect.maxRetries) || 2;
      this._detectRetry = (this._detectRetry || 0) + 1;
      const baseWait = Number(this.cfg.detect && this.cfg.detect.retryWaitMs) || 30000;
      const jitter = Number(this.cfg.detect && this.cfg.detect.retryJitterMs) || 5000;
      let msg = '';
      try { msg = await this.adapter._readDetectMessage(); } catch (_) { /* ignore */ }

      if (this._detectRetry <= maxRetries) {
        const waitMs = baseWait + Math.floor(Math.random() * jitter);
        logger.warn('RISK_CONTROL', '播放中命中风控页，等待后刷新重试', {
          attempt: this._detectRetry, maxRetries,
          waitSeconds: Math.round(waitMs / 1000),
          url: topUrlNow.slice(0, 160),
          message: String(msg || '').slice(0, 160),
          hint: '建议退出手机端超星 App 会话',
        });
        await sleep(waitMs);
        try {
          await this.adapter.navigate('https://i.chaoxing.com/base');
          const after = await this.adapter.getCurrentUrl().catch(() => '');
          if (!this.adapter._isDetectUrl(after)) {
            logger.info('RISK_CONTROL', '播放中风控已解除，继续', {
              attempt: this._detectRetry, url: String(after).slice(0, 140),
            });
            this.failures = 0;
            return { progress: true, outcome: 'RISK_CONTROL_RECOVERED' };
          }
        } catch (e) {
          logger.warn('RISK_CONTROL', '播放中风控刷新出错', {
            attempt: this._detectRetry, err: String((e && e.message) || e).slice(0, 120),
          });
        }
        return { progress: false, outcome: 'RISK_CONTROL_WAIT' };
      }

      logger.error('RISK_CONTROL', '播放中风控重试已达上限，停止运行', {
        attempts: this._detectRetry, maxRetries,
        url: topUrlNow.slice(0, 200),
        message: String(msg || '').slice(0, 200),
        reason: '超星判定「多终端登录 / 异常学习」。已按策略等待 30 秒并刷新重试 '
          + maxRetries + ' 次仍未解除。处理：① 手机端学习通 App 完全退出登录；'
          + '② 确认无其他终端同时登录；③ 等待 10-30 分钟后重试。',
      });
      this.fatalStop('RISK_CONTROL_DETECTED',
        '超星风控未解除（已重试 ' + maxRetries + ' 次）：多终端登录/异常学习判定。'
        + (msg ? ' 平台提示：' + String(msg).slice(0, 120) : '')
        + ' 请退出手机端学习通 App 后等待 10-30 分钟再试。');
      return { progress: false, outcome: 'FATAL_STOP' };
    }
    this._detectRetry = 0;

    if (st.video && st.video.found) {
      const frameChanged = this._lastVideoFrameId !== st.video.frameId;
      const current = Number(st.video.currentTime) || 0;
      const duration = Number(st.video.duration) || 0;
      const src = String(st.video.src || '');
      const mediaChanged = !frameChanged && (
        (this._lastVideoDuration > 0 && duration > 0 && Math.abs(duration - this._lastVideoDuration) > 1)
        || (this._lastVideoSrc && src && src !== this._lastVideoSrc)
      );
      if (frameChanged || mediaChanged) {
        this._lastVideoFrameId = st.video.frameId;
        this._lastVideoCurrentTime = current;
        this._lastVideoDuration = duration;
        this._lastVideoSrc = src;
        this._videoProgressTicks = 0;
      } else if (this._lastVideoCurrentTime !== undefined && current - this._lastVideoCurrentTime >= 0.5) {
        this._videoProgressTicks += 1;
        this._lastVideoCurrentTime = current;
      } else if (this._lastVideoCurrentTime === undefined) {
        this._lastVideoCurrentTime = current;
      }
    }

    /* —— 安全闸门（最高优先级，立即 FATAL）—— */
    if (st.human.length) {
      this.fatalStop('HUMAN_VERIFICATION', 'FATAL: 需要人工介入 — 检测到人脸识别/活体/验证码特征: ' + st.human.map((h) => h.evidence).join(', '), { frames: st.human.map((h) => h.frameId) });
      return { progress: false, outcome: 'FATAL_STOP' };
    }
    if (st.loginInvalid) {
      this.fatalStop('LOGIN_REQUIRED', '登录态失效（' + st.loginEvidence.join('; ') + '）。请在浏览器 profile 中人工重新登录后重跑；脚本不会自动登录。');
      return { progress: false, outcome: 'FATAL_STOP' };
    }

    /* —— P0：防挂机弹窗。非普通确认弹窗不自动处理，避免误点题目按钮 —— */
    const dlg = st.dialogs.find((d) => d.kind === 'anti-idle');
    if (dlg) {
      const r = await this.clickFound(dlg.frameId, 'dialogPrimary');
      if (r.ok) {
        this.counters.dialogsDismissed += 1;
        logger.info('DIALOG', 'P0 防挂机弹窗已关闭并尝试恢复播放', { kind: dlg.kind, text: dlg.text.slice(0, 60), layer: dlg.layer, note: dlg.note });
        return { progress: true, outcome: 'DIALOG_DISMISSED' };
      }
      logger.warn('DIALOG', 'P0 防挂机弹窗主按钮点击失败', { kind: dlg.kind });
      this.failures += 1;
      return { progress: false, outcome: 'DIALOG_CLICK_FAIL' };
    }

    /* —— P2.5：视频内随堂题优先分类；不让泛化 radio 探针抢先命中 —— */
    if (st.videoQuiz && st.videoQuiz.present) {
      const r = await this.handleVideoQuiz(st);
      return r;
    }

    /* —— P2：章节作业/泛化题目只停止；绝不答题或自动切回视频 —— */
    if (st.quiz && st.quiz.present) {
      const r = await this.handleQuiz(st);
      return r;
    }

    /* —— 已切到「章节测验」标签：等题目加载 ——
       点开测验标签后视频区会被替换，st.video 消失；必须先把题目答完，
       否则会走「无视频→跳过」分支把这一节误判为非视频任务点。 */
    if (this._quizTabOpened) {
      const r = await this.continueChapterQuiz();
      if (r === 'pending') return { progress: true, outcome: 'CHAPTER_QUIZ_PENDING' };
      return { progress: true, outcome: 'CHAPTER_QUIZ_HANDLED' };
    }

    /* —— 视频状态（P0 / P1）—— */
    if (st.video && st.video.found) {
      this._videoSeenThisSection = true;
      /* ★ 当前节在目录里已标记完成（icon_Completed）⇒ 不要重播。
         实测坑：学习通打开已完成的小节时，视频进度会从 0 开始重播
         （服务端返回的是新的一次播放会话），若照播就是白等 500+ 秒。
         这里直接跳到下一节。 */
      if (this._currentSectionDone(st)) {
        logger.info('ADVANCE', '当前节目录已标记完成，跳过重播，直接切下一节', {
          title: this._currentTitle, progress: st.video.progress,
        });
        this.counters.sectionsSkipped += 1;
        this.failures = 0;
        return this.advanceSection(st);
      }
      /* ★★ 2026-10-29 关键修复：只有「本次运行真正启动过」的视频，
         才允许用 ended / 进度 判定播完。
         参考 xuexitong-ai-assistant 的 startedVideos 语义：
           只有 startedVideos.has(video) 时才 return video.ended || ...，
           否则只认平台任务点（P.complete）。
         我们之前没做这个区分 ⇒ 刚点进新节、元数据还没加载时
           duration=0、ended 默认 true ⇒ 直接判成「播完」⇒ 反复空转。 */
      const startedHere = this._isVideoStartedHere(st.video);
      const playedEnough = startedHere &&
        (st.video.ended || (st.video.progress || 0) >= this.cfg.video.progressDoneRatio);
      if (!startedHere && (st.video.progress || 0) > 0.5) {
        /* 视频在走但还没登记为「本次启动」→ 补登记（正常播放中首次进入即命中） */
        this._markVideoStarted(st.video);
      }
      if (playedEnough) {
        this.counters.sectionsCompleted += 1;
        /* ★ 播放器走到 98.5% 不等于超星记了完成。目录里的待办数才是硬证据。
           播完后重新读一次目录：待办从 2 变 1 ⇒ 视频已被服务端记为看完。 */
        const pendingNow = await this.confirmVideoWatched(6000);
        /* ★ 判据放宽：不再要求 pending 必须降到 1。
           我们的策略是跳过章节测验，所以 pending 常常停在 1（视频完成 + 测验未做），
           3.4 这种首进拿不到时长的更会停在 2。
           只要「视频任务点已完成」（目录待办下降 或 页面 video 任务点全绿）就算数。 */
        const videoTask = this._videoTaskDone(st);
        const watched = (pendingNow === 1 || pendingNow === 0) || videoTask.ok;
        logger.info('ADVANCE', watched ? '当前节已看完（超星已确认）' : '当前节播放结束，但超星未确认视频完成', {
          title: this._currentTitle,
          completed: this.counters.sectionsCompleted,
          pending: pendingNow,
          startedHere,
          videoTask: videoTask.ok ? videoTask.by : 'not-done',
          note: watched
            ? (pendingNow === 0 ? '待办 0（整节完成）'
              : pendingNow === 1 ? '待办 1（视频已完成，剩章节测验）'
              : '按任务点判定视频已完成（待办 ' + pendingNow + '，剩章节测验）')
            : '★ 待办仍为 ' + pendingNow + '，超星未记录视频完成（进度可能未上报）',
        });
        if (!watched) {
          // 服务端没记 → 进度没上报，这一节等于白看。必须让主人知道。
          this.counters.videoNotConfirmed = (this.counters.videoNotConfirmed || 0) + 1;
        }
        // 本章若有「章节测验」标签，先切过去把题答完，再进入下一节
        const quizDone = await this.maybeHandleChapterQuiz(st);
        if (quizDone === 'handled') return { progress: true, outcome: 'CHAPTER_QUIZ_HANDLED' };
        if (quizDone === 'pending') return { progress: true, outcome: 'CHAPTER_QUIZ_PENDING' };
        return this.advanceSection(st);
      }
      if (st.video.paused) {
        /* ★ 顺序很重要：先点播放，再判断是不是真卡死。
           视频刚切过去、还没点播放时 readyState 本来就是 0（HAVE_NOTHING，
           元数据未加载），这是**正常状态**不是故障。
           早前把卡死判定放在点播放之前，结果每次切节都误判成「源 403」，
           反而从没点过播放按钮。
           实测：点播放后 readyState 0→4、buffered 出现、进度正常前进。 */
        const r = await this.clickFound(st.video.frameId, 'videoToggle');
        if (r.ok) {
          await this.muteIfPossible(st.video.frameId);
          // 点完等一轮，让播放器去拉流（要拿到元数据才会 readyState 上升）
          await sleep(4000);
          let after = null;
          try {
            const st2 = await this.gatherState();
            after = st2.video;
          } catch (_) { /* ignore */ }
          const nowPlaying = after && after.found &&
            !this._isVideoStalled(after) &&
            (after.readyState >= 2 || (Array.isArray(after.buffered) && after.buffered.length > 0));
          if (nowPlaying) {
            this._resumeAttempts = 0;
            this._stallTicks = 0;
            this._lastProgressTime = undefined;
            logger.info('PLAYING_CHECK', 'P0 视频处于暂停，已恢复播放', {
              layer: r.layer, progress: after.progress, currentTime: after.currentTime,
              readyState: after.readyState, buffered: (after.buffered || []).length,
            });
            return { progress: true, outcome: 'RESUMED' };
          }
          /* 点完还是不动：可能是 CDN 源失效（403）⇒ 重新加载页面取新签名 */
          this._resumeAttempts = (this._resumeAttempts || 0) + 1;
          logger.warn('PLAYING_CHECK', '点了播放但播放器没起来', {
            section: this._currentTitle,
            attempts: this._resumeAttempts,
            readyState: after ? after.readyState : 'unknown',
            buffered: after ? after.buffered : null,
            error: after ? after.error : null,
          });
          if (this._resumeAttempts >= 2) {
            const fixed = await this.reloadForFreshVideo();
            this._resumeAttempts = 0;
            if (fixed) return { progress: true, outcome: 'VIDEO_RELOADED' };
            this.failures += 1;
            logger.warn('PLAYING_CHECK', '视频无法恢复播放，计入失败', {
              section: this._currentTitle, failures: this.failures,
            });
            return { progress: false, outcome: 'VIDEO_STALLED' };
          }
          return { progress: true, outcome: 'RESUME_PENDING' };
        }
        logger.warn('PLAYING_CHECK', '恢复播放失败（未找到播放控件）', { layer: r.layer || 0 });
        this.failures += 1;
        return { progress: false, outcome: 'RESUME_FAIL' };
      }
      /* ★ 2026-10-29：视频确实在走 ⇒ 登记为「本次运行启动过」。
         之前只在上面的补登记分支加了，这里再兜一层：
         只要 currentTime > 0 就说明播放真实发生，可以放心用 ended 判完成。 */
      if ((st.video.currentTime || 0) > 0) this._markVideoStarted(st.video);
      logger.info('PLAYING', '视频播放中', {
        progress: st.video.progress,
        currentTime: st.video.currentTime,
        duration: st.video.duration,
        section: this._currentTitle,
        /* ★ 播放器进度不等于超星认不认。目录里的 jobUnfinishCount 才是硬证据：
             每节待办 = 视频 + 章节测验 ⇒ 2 → 1 表示「视频已被超星记为看完」。
           把这个数一起打出来，主人随时能看到服务端到底认不认。 */
        pending: this._currentPending(st),
      });
      /* ★ 进度停滞检测：paused=false 但 currentTime 长时间不动 = 缓冲耗尽/源失效。
         这时超星不会自己换签名，必须重新加载页面。 */
      if (this._progressStalled(st.video)) {
        const fixed = await this.reloadForFreshVideo();
        if (fixed) return { progress: true, outcome: 'VIDEO_RELOADED' };
        this.failures += 1;
        logger.warn('PLAYING_CHECK', '进度停滞且重载后仍未恢复，计入失败', {
          section: this._currentTitle, failures: this.failures,
        });
        return { progress: false, outcome: 'VIDEO_STALLED' };
      }
      await humanize.pollDelay(); // 轮询节流：播放期间按 CONFIG 节奏休眠，避免热循环
      return { progress: true, outcome: 'PLAYING' };
    }

    /* —— 无视频：先等待加载，超过阈值按非视频任务点跳过（P3 变体）—— */
    if (!this._videoSeenThisSection && this._waitTicks < this.cfg.safety.maxNoVideoWaitTicks) {
      this._waitTicks += 1;
      logger.info('WAIT_LOAD', '当前节尚未出现视频，等待加载', { tick: this._waitTicks, max: this.cfg.safety.maxNoVideoWaitTicks });
      await humanize.pollDelay();
      return { progress: false, outcome: 'WAIT_LOAD' };
    }
    if (!this._videoSeenThisSection) {
      logger.warn('ADVANCE', 'WARN 当前任务点疑似无视频（阅读/文档类），按 P3 策略跳过', { section: this._currentTitle, layer: st.toc ? st.toc.layer : 0 });
      this.counters.sectionsSkipped += 1;
      this._videoSeenThisSection = true; // 防重复跳过
      this.failures = 0;                 // 跳过是有效进展
      return this.advanceSection(st);
    }

    /* —— 视频曾经出现又消失：视为异常 —— */
    this.failures += 1;
    logger.warn('PLAYING_CHECK', '视频元素消失', { failures: this.failures });
    return { progress: false, outcome: 'VIDEO_GONE' };
  }

  /**
   * AI 作答：题干 + 选项交给模型，返回选项索引；失败或未配置返回 -1。
   *
   * 两条通路：
   *   1) CX_LLM_ASK_URL —— 回调宿主（DSH 插件）端点，用 DSH 已配置的模型
   *      （含 our-free-model 的免费模型）。这是主通路。
   *   2) CX_LLM_BASE/CX_LLM_KEY —— 直连 OpenAI 兼容接口（插件内置智谱模型）。
   */
  /**
   * 向模型问一道题。
   *
   * @param {string} question 题干文本（超星是密文，仅作兜底）
   * @param {Array} options   选项 [{i, letter, label}]
   * @param {string} imageB64  该题的截图 base64（PNG）。超星题干是加密字体，
   *                          DOM 读出来是密文，只有截图才是明文——有图就以图为准。
   */
  async askAI(question, options, imageB64) {
    const askUrl = process.env.CX_LLM_ASK_URL || '';
    const base = process.env.CX_LLM_BASE || '';
    const key = process.env.CX_LLM_KEY || '';
    const model = process.env.CX_LLM_MODEL || '';
    if (!options || !options.length) return -1;
    if (!askUrl && !(base && key && model)) return -1;
    const labels = options.map(function (o, i) {
      return (o.letter || String.fromCharCode(65 + i)) + '. ' + (o.label || '');
    }).join('\n');
    const prompt = imageB64
      ? '这是考试题目的截图（超星用加密字体渲染，截图里才是明文）。\n' +
        '请读出题干和全部选项，判断正确答案是哪一个。\n' +
        '只输出正确选项的字母（A/B/C/D），不要任何解释。'
      : '题目：' + (question || '') + '\n选项：\n' + labels +
        '\n\n只输出正确选项的字母（A/B/C/D…），不要任何解释。';

    let text = '';
    const attempts = 3;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      text = '';
      if (askUrl) {
        // 通路 1：回调宿主，由宿主用 ctx.llm 调用户配置的模型
        const payload = {
          provider: process.env.CX_LLM_PROVIDER || '',
          model: model,
          prompt: prompt,
        };
        if (imageB64) payload.image = 'data:image/png;base64,' + imageB64;
        const res = await fetch(askUrl, {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'x-cx-token': process.env.CX_LLM_ASK_TOKEN || '',
          },
          body: JSON.stringify(payload),
        });
        if (!res.ok) throw new Error('HTTP ' + res.status + ' ' + (await res.text()).slice(0, 120));
        const j = await res.json();
        if (!j || j.ok !== true) throw new Error(String((j && j.error) || '宿主答题回调失败'));
        text = String(j.text || '');
      } else {
        // 通路 2：直连 OpenAI 兼容接口
        const url = base.replace(/\/+$/, '') + '/chat/completions';
        const msgContent = imageB64
          ? [{ type: 'text', text: prompt }, { type: 'image_url', image_url: { url: 'data:image/png;base64,' + imageB64 } }]
          : prompt;
        const res = await fetch(url, {
          method: 'POST',
          headers: { 'content-type': 'application/json', authorization: 'Bearer ' + key },
          body: JSON.stringify({
            model: model,
            messages: [{ role: 'user', content: msgContent }],
            temperature: 0,
            max_tokens: 16,
          }),
        });
        if (!res.ok) throw new Error('HTTP ' + res.status + ' ' + (await res.text()).slice(0, 120));
        const j = await res.json();
        text = String((j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '');
      }
      if (text.trim()) break;
      // 上游偶尔「成功返回但正文为空」，重试一次再判定不可用
      if (attempt < attempts) {
        logger.warn('QUIZ', '模型返回空内容，重试中 ' + attempt + '/' + (attempts - 1), { model: model });
        await new Promise(function (r) { setTimeout(r, 800 * attempt); });
      }
    }

    return parseAnswerLetter(text, options.length);
  }

  /**
   * 章内「章节测验」处理。
   *
   * 学习通每看完一节视频，本章往往还有一个「章节测验」子任务（在 .prev_ul 里，
   * 标题含「章节测验」）。题目并不在顶层页面，而是按需加载进 popFrameId iframe
   * （平时是 about:blank 空页），所以必须先点开标签页、等题目加载，再交给
   * handleQuiz 作答。
   *
   * @returns {'handled'|'none'|'pending'|'skipped'}
   *   handled = 已作答（含人工模式暂停）；none = 本章无测验；pending = 正在等题目加载
   */
  /**
   * 取当前节所属的章标题（目录里最后一个 chapterHeader 且位于当前项之前）。
   * 章节测验是「章级」子任务，同一章的多节共用同一个测验入口，
   * 所以去重必须按章而不是按节。
   */
  currentChapterTitle(st) {
    const toc = st && st.toc;
    const items = (toc && toc.items) || [];
    if (!items.length) return this._currentTitle;
    let curIdx = items.findIndex((x) => x.current);
    if (curIdx < 0 && this._lastCurIdx != null) curIdx = this._lastCurIdx;
    if (curIdx < 0) curIdx = 0;
    let chapter = '';
    for (let i = 0; i <= curIdx && i < items.length; i++) {
      if (items[i].chapterHeader) chapter = items[i].title;
    }
    return chapter || ('§' + curIdx);
  }

  async maybeHandleChapterQuiz(st) {
    /* 跳过测验模式：连测验标签都不点。
       点开标签会把视频区替换成作业页，视频就断了；既然本轮只要视频，
       干脆别碰这个标签，直接往下一节推进。 */
    if (String(process.env.CX_QUIZ_MODE || '') === 'skip') {
      return 'none';
    }
    // 本章已处理过测验 → 不重复（测验是章级任务，同章多节共用）
    const chapter = this.currentChapterTitle(st);
    if (this._quizTabDoneFor === chapter) return 'none';
    const tab = st.quizTab;
    if (!tab || !tab.present) return 'none';

    // 还没点开过测验标签 → 点它
    const r = await this.clickFound(tab.frameId, 'quizTab');
    if (!r.ok) {
      logger.warn('QUIZTAB', '章节测验标签点击失败，跳过本章测验', { reason: r.reason, title: tab.title, chapter });
      this._quizTabDoneFor = chapter;
      return 'none';
    }
    this._quizTabOpened = true;
    this._quizTabWaitTicks = 0;
    this._quizTabChapter = chapter;
    logger.info('QUIZTAB', '已切换到章节测验，等待题目加载', { title: tab.title, chapter, layer: r.layer });
    return 'pending';
  }

  /**
   * 已切到章节测验标签后的续作：等题目加载出来。
   * 作答由主 tick 的 P2 分支完成（题目出现时会被 st.quiz 捕获）。
   * @returns {'handled'|'pending'}
   */
  async continueChapterQuiz() {
    if (this._quizTabWaitTicks < this.cfg.safety.maxLoadRetries) {
      this._quizTabWaitTicks += 1;
      await humanize.pollDelay();
      /* 已提交过的章节测验：作业页会跳到「批阅页」selectWorkQuestionYiPiYue，
         页面里没有题目可答。这种情况不是「加载失败」，而是「本测验已完成」，
         必须识别出来，否则会一直等到超时，再因为切不回视频标签而误判成页面异常。 */
      if (await this.quizAlreadySubmitted()) {
        logger.info('QUIZTAB', '检测到该章节测验此前已提交（批阅页），跳过作答', { chapter: this._quizTabChapter || this._currentTitle });
        this._quizTabDoneFor = this._quizTabChapter || this._currentTitle;
        this._quizTabOpened = false;
        this._quizTabWaitTicks = 0;
        await this.switchBackToVideoTabAnyFrame(this._lastState);
        return 'handled';
      }
      const q = await this.findQuizInFrames();
      if (!q) {
        logger.info('QUIZTAB', '章节测验题目尚未加载，继续等待', { tick: this._quizTabWaitTicks, max: this.cfg.safety.maxLoadRetries });
        return 'pending';
      }
      logger.info('QUIZTAB', '章节测验题目已就绪', { options: (q.options || []).length });
      return 'handled';
    }
    logger.warn('QUIZTAB', '章节测验题目加载超时，跳过', { chapter: this._quizTabChapter || this._currentTitle });
    this._quizTabDoneFor = this._quizTabChapter || this._currentTitle;
    this._quizTabOpened = false;
    /* ★ 必须切回视频标签：停留在测验标签上视频区已被替换，
       主循环下一轮会看到「视频元素消失」，连续 3 次就误判成页面异常而 FATAL。 */
    await this.switchBackToVideoTabAnyFrame(this._lastState);
    return 'handled';
  }

  /**
   * 判断当前章节测验是否「此前已提交」。
   *
   * 超星作业已提交后，作业 frame 会跳到批阅页：
   *   /mooc-ans/work/selectWorkQuestionYiPiYue?...
   * 该页没有 .TiMu.newTiMu 题块，所以「找不到题目」不等于「加载失败」。
   */
  async quizAlreadySubmitted() {
    const adapter = this.adapter;
    let frames = [];
    try { frames = await adapter.getFrameDocuments(); } catch (_) { return false; }
    for (const f of frames) {
      const u = String(f.url || '');
      if (/selectWorkQuestion|workAnswerDetail/i.test(u)) return true;
    }
    return false;
  }

  /**
   * 答完章节测验后切回「视频」标签。
   * 学习通同一章内，「1视频 / 2章节测验」是并列标签；停留在测验标签上，
   * 视频元素不存在 → 主循环会把本节误判成「非视频任务点」直接跳过。
   */
  async switchBackToVideoTab(st) {
    try {
      const tab = st && st.quizTab;
      const frameId = (tab && tab.frameId) || (st && st.frames && st.frames[0] && st.frames[0].frameId);
      if (!frameId) return false;
      const r = await this.clickFound(frameId, 'videoTab');
      if (r.ok) {
        logger.info('QUIZTAB', '已切回视频标签', { layer: r.layer });
        await humanize.sectionCooldown();
        this._videoSeenThisSection = false;
        this._waitTicks = 0;
        return true;
      }
      logger.warn('QUIZTAB', '切回视频标签失败', { reason: r.reason });
    } catch (e) {
      logger.warn('QUIZTAB', '切回视频标签异常', { err: String((e && e.message) || e).slice(0, 120) });
    }
    return false;
  }

  /**
   * 在所有 frame 里找「视频」标签并点回。
   *
   * 「1视频 / 2章节测验」这组标签在 .prev_ul 里，属于章内子任务列表 ——
   * 实测它既可能出现在顶层 frame，也可能出现在内容 frame，
   * 所以不能只盯着 st.quizTab.frameId 一个 frame 找。
   */
  async switchBackToVideoTabAnyFrame(st) {
    const adapter = this.adapter;
    let frames = [];
    try { frames = await adapter.getFrameDocuments(); } catch (_) { frames = []; }
    const inst = installProbeExpression(this.cfg);
    const order = [];
    const tb = st && st.quizTab && st.quizTab.frameId;
    if (tb) order.push(frames.find((f) => f.frameId === tb));
    for (const f of frames) if (!order.includes(f)) order.push(f);
    for (const f of order) {
      if (!f) continue;
      if (f.url && /^about:blank/.test(f.url)) continue;
      try {
        await adapter.evalInFrame(f.frameId, inst);
        const hit = await adapter.evalInFrame(f.frameId, '__cx.find("videoTab",null)');
        if (!hit || !hit.ok) continue;
        const r = await this.clickFound(f.frameId, 'videoTab');
        if (r.ok) {
          logger.info('QUIZTAB', '已切回视频标签', { layer: r.layer, frameId: f.frameId.slice(0, 10), note: r.note });
          await humanize.sectionCooldown();
          this._videoSeenThisSection = false;
          this._waitTicks = 0;
          return true;
        }
      } catch (_) { /* 该 frame 不可达就跳过 */ }
    }
    logger.warn('QUIZTAB', '未能在任何 frame 找到「视频」标签');
    return false;
  }

  /** 在所有 frame 里找可解析的题目（测验页加载后题目在 popFrameId 内） */
  async findQuizInFrames() {
    const frames = await this.adapter.getFrameDocuments();
    const inst = installProbeExpression(this.cfg);
    for (const f of frames) {
      if (f.url && /^about:blank/.test(f.url)) continue;
      try {
        await this.adapter.evalInFrame(f.frameId, inst);
        const probe = await this.adapter.evalInFrame(f.frameId, '__cx.probeAll()');
        const q = probe && probe.quiz;
        if (q && q.present && q.parseable && (q.options || []).length) {
          return Object.assign({}, q, { frameId: f.frameId });
        }
      } catch (_) { /* 该 frame 不可达就跳过 */ }
    }
    return null;
  }

  /** 只读输出题目事件；此方法不截图、不调用模型、不点击页面。 */
  emitDetectedQuestions(q, meta) {
    if (!q || !q.present) return [];
    const blocks = q.blocks && q.blocks.length ? q.blocks : [{ question: q.question, options: q.options, kind: q.kind }];
    const out = [];
    for (const block of blocks) {
      const options = (block.options || []).map((o) => ({
        i: Number(o.i) || 0,
        letter: String(o.letter || ''),
        label: String(o.label || '').slice(0, 240),
      }));
      const event = {
        kind: String(meta && meta.kind || q.kind || 'unknown'),
        source: String(meta && meta.source || 'page'),
        question: String(block.question || q.question || '').slice(0, 1000),
        options,
        frameId: String(q.frameId || ''),
        chapterTitle: String(this._currentTitle || '').slice(0, 160),
        videoTime: meta && Number.isFinite(meta.videoTime) ? meta.videoTime : null,
        duration: meta && Number.isFinite(meta.duration) ? meta.duration : null,
        pageUrl: String(this._lastState && this._lastState.topUrl || '').slice(0, 300),
      };
      const id = emitQuestionEvent(event);
      if (id) out.push(id);
    }
    return out;
  }

  /**
   * P2.5：随堂弹题（视频内嵌 ans-videoquiz）。
   *
   * 超星视频播到某个时间点会弹出一道题并强制暂停。DOM（实测）：
   *   .ans-videoquiz → .tkItem_title（题干）+ li.ans-videoquiz-opt（选项，radio value 空串，答案在文本）
   *   + #videoquiz-submit（提交）+ #videoquiz-continue（答对后点它视频才继续）
   *   + #spanHas（回答正确）/ #spanNot（回答错误）
   *
   * 流程：答对 → 点「继续」→ 视频恢复；答错 → 超星会回看（可能要求重看一段）。
   * 这道题的题干是**明文**（不是章节测验的加密字体），所以可以直接读文本作答。
   */
  handleVideoQuiz(st) {
    return Promise.resolve().then(async () => {
      const vq = st.videoQuiz;
      if (!vq || !vq.present) return { progress: false, outcome: 'VIDEO_QUIZ_NONE' };
      const frameId = vq.frameId;
      const duration = Number(st.video && st.video.duration) || 0;
      const currentTime = Number(st.video && st.video.currentTime) || 0;
      const durationKnown = duration > 0;
      const hasPlaybackContext = !!(st.video && st.video.found && durationKnown
        && st.videoFrameId === frameId && this._videoProgressTicks > 0);

      /* 视频内题需同时具备可见的 .ans-videoquiz、相同 frame 的播放器、
         已知总时长和此前确实推进的播放记录；否则不猜分类，安全停机。 */
      if (!hasPlaybackContext) {
        logger.warn('QUIZ', '视频题证据不足，短暂只读观察后决定，不执行任何题目动作', {
          frameId, videoFrameId: st.videoFrameId, duration, currentTime,
          progressedTicks: this._videoProgressTicks,
        });
        this._videoQuizObserveTicks = (this._videoQuizObserveTicks || 0) + 1;
        if (st.video && st.video.found && !st.video.paused && this._videoQuizObserveTicks < 3) {
          await humanize.pollDelay();
          return { progress: false, outcome: 'VIDEO_QUIZ_CLASSIFY_WAIT' };
        }
        this.stop('quiz_unclassified_needs_human');
        return { progress: false, outcome: 'VIDEO_QUIZ_UNCLASSIFIED' };
      }
      this._videoQuizObserveTicks = 0;

      const eventIds = this.emitDetectedQuestions({
        ...vq,
        question: vq.title,
        frameId,
      }, {
        kind: 'video_embedded_quiz',
        source: 'video',
        videoTime: currentTime,
        duration,
      });
      logger.warn('QUIZ', '已根据播放器上下文识别为视频内随堂题', {
        title: (vq.title || '').slice(0, 50), duration, currentTime, eventIds,
        options: (vq.options || []).map((o) => o.label).join(' | '),
        remaining: vq.remaining, wrongBack: vq.wrongBack, correct: vq.correct,
      });

      /* ★★★ 盲试作答（2026-10-27 主人要求）★★★
         原话：「判断题你能不能在不用 ai 的情况下完成，他不会影响我的成绩，
                打错了，换个答案，一直到答对就可以看了」

         依据（实测 + 参考项目 xuexitong-ai-assistant 的 video-quiz.js）：
           1. 随堂题不计入课程成绩，答错只影响本次播放；
           2. #spanNotBack「回答错误，回看 N 分钟」出现时会被要求回看 → 必须立即停；
           3. 面板有「剩余 N 次」→ 次数耗尽前可以换答案重试。

         策略：按选项顺序逐个试 → 提交 → 读反馈
           答对(#spanHas)/继续可见 → 点「继续」恢复播放
           答错且无回看惩罚        → 换下一个选项重试
           答错且要求回看          → 停止（不硬试）
           剩余次数为 0            → 停止

         ★ 安全边界：只处理 .ans-videoquiz（视频内随堂题）。
           绝不触碰 .TiMu（章节测验/作业，计入成绩）。 */
      const optCount = Array.isArray(vq.options) ? vq.options.length : 0;
      if (!optCount) {
        logger.warn('QUIZ', '随堂题没有可读选项，停止', { title: (vq.title || '').slice(0, 40) });
        this.stop('video_quiz_no_options');
        return { progress: false, outcome: 'VIDEO_QUIZ_NO_OPTIONS' };
      }
      if (vq.wrongBack) {
        logger.warn('QUIZ', '随堂题答错且要求回看，停止盲试（避免回看惩罚）', {
          panelText: String(vq.panelText || '').slice(0, 100),
        });
        this.stop('video_quiz_review_required');
        return { progress: false, outcome: 'VIDEO_QUIZ_REVIEW_REQUIRED' };
      }
      if (typeof vq.remaining === 'number' && vq.remaining <= 0) {
        logger.warn('QUIZ', '随堂题剩余次数已用尽，停止', { remaining: vq.remaining });
        this.stop('video_quiz_no_attempts_left');
        return { progress: false, outcome: 'VIDEO_QUIZ_NO_ATTEMPTS' };
      }

      // 已答对：直接点「继续」
      if (vq.correct || vq.continueVisible) {
        logger.info('QUIZ', '随堂题已答对，点「继续」恢复播放', { eventIds });
        await this.clickFound(frameId, 'videoQuizContinue');
        this._videoProgressTicks = 0;
        return { progress: true, outcome: 'VIDEO_QUIZ_CONTINUED' };
      }

      /* 盲试：按顺序尝试没试过的选项。每轮都重新读真实反馈。 */
      const qkey = String(vq.title || '').slice(0, 60);
      if (this._videoQuizKey !== qkey) { this._videoQuizKey = qkey; this._videoQuizTried = new Set(); }
      const tried = this._videoQuizTried;

      for (let i = 0; i < optCount; i++) {
        if (tried.has(i)) continue;
        tried.add(i);
        logger.info('QUIZ', '随堂题盲试选项 ' + (i + 1) + '/' + optCount, {
          title: qkey.slice(0, 40), option: (vq.options[i] || {}).label,
        });
        // 1) 点选项（find() 期望 arg 是数字下标，不是对象）
        const picked = await this.clickFound(frameId, 'videoQuizOption', i);
        if (!picked || !picked.ok) { logger.warn('QUIZ', '选项点击失败', { i, reason: picked && picked.reason }); continue; }
        await humanize.pollDelay();
        // 2) 提交
        const sub = await this.clickFound(frameId, 'videoQuizSubmit');
        if (!sub || !sub.ok) { logger.warn('QUIZ', '提交点击失败', { i, reason: sub && sub.reason }); continue; }
        // 3) 等反馈（最多约 10 秒）
        let fb = null;
        for (let w = 0; w < 10; w++) {
          await humanize.pollDelay();
          const sc = await this.gatherState();
          fb = sc && sc.videoQuiz;
          if (!fb || !fb.present) break;
          if (fb.correct || fb.continueVisible || fb.wrong || fb.wrongBack) break;
        }
        if (!fb || !fb.present) {
          logger.info('QUIZ', '提交后弹题消失，视为已通过');
          this.counters.quizzesAnswered += 1;   // 随堂题已答（计入统计）
          this._videoQuizTried = null; this._videoQuizKey = null;
          return { progress: true, outcome: 'VIDEO_QUIZ_PASSED' };
        }
        if (fb.correct || fb.continueVisible) {
          logger.info('QUIZ', '随堂题答对了，点「继续」恢复播放', { option: i });
          await this.clickFound(frameId, 'videoQuizContinue');
          this.counters.quizzesAnswered += 1;   // 随堂题已答（计入统计）
          this._videoQuizTried = null; this._videoQuizKey = null;
          this._videoProgressTicks = 0;
          return { progress: true, outcome: 'VIDEO_QUIZ_CORRECT' };
        }
        if (fb.wrongBack) {
          logger.warn('QUIZ', '答错且要求回看，停止盲试', { option: i, panelText: String(fb.panelText || '').slice(0, 80) });
          this.stop('video_quiz_review_required');
          return { progress: false, outcome: 'VIDEO_QUIZ_REVIEW_REQUIRED' };
        }
        if (typeof fb.remaining === 'number' && fb.remaining <= 0) {
          logger.warn('QUIZ', '剩余次数用尽，停止盲试', { option: i });
          this.stop('video_quiz_no_attempts_left');
          return { progress: false, outcome: 'VIDEO_QUIZ_NO_ATTEMPTS' };
        }
        logger.info('QUIZ', '答错了，换下一个选项继续试', { option: i, remaining: fb.remaining });
      }

      logger.warn('QUIZ', '所有选项都试过仍未答对，转人工', { title: qkey.slice(0, 40) });
      this.stop('video_quiz_exhausted');
      return { progress: false, outcome: 'VIDEO_QUIZ_EXHAUSTED' };

    });
  }

  /**
   * P2：弹题/章节测验作答。
   *
   * 学习通「章节测验」是一整个作业页（.TiMu.newTiMu × N），不是一题一弹窗。
   * 早期版本只处理第一题就提交 → 提交必然失败 → 作业永不完成 →
   * 目录里的 jobUnfinishCount 恒 >0 → 每轮都从第一章重新开始（主人报的核心症状）。
   *
   * 现在：遍历全部题块 → 每题截图（题干是加密字体，只有图才是明文）→ 逐题作答 →
   * 全部答完再点提交。
   */
  handleQuiz(st) {
    return Promise.resolve().then(async () => {
      const q = st && st.quiz;
      if (!q || !q.present) return { progress: false, outcome: 'QUIZ_NONE' };
      const blocks = q.blocks || [];
      const isWorkPage = q.kind === 'chapter_work' || blocks.length > 0;
      const quizMode = String(process.env.CX_QUIZ_MODE || 'skip');
      if (quizMode === 'skip' || quizMode === 'manual') {
        const eventIds = this.emitDetectedQuestions(q, {
          kind: q.kind || 'popup_quiz',
          source: q.kind === 'chapter_work' ? 'chapter_work' : 'popup',
        });
        /* ★★★ 2026-10-28 主人需求：遇到章节测验 → 不答题，**跳过并进入下一节继续看视频** ★★★
           原行为：stop('quiz_needs_human') 整个流程停下来等人。
           新行为：记录题目事件后，把当前节标记为「已完成（视频部分）」，
                   直接 advanceSection 切到下一节继续播放。

           为什么可以这样做：
             · 章节测验（.TiMu / chapter_work）计入成绩，绝不能自动作答；
             · 但视频任务点此时已完成（超星已确认 completed），
               留着不动只会让整个流程卡死在这一节；
             · 跳过测验不答 = 该节得分不变差，只是不拿这部分的分数，
               与主人「课后题一定不要做」的要求一致。

           安全：只跳过，不点任何题目的选项/提交按钮。 */
        const isChapterWork = q.kind === 'chapter_work' || blocks.length > 0;
        if (isChapterWork && this.cfg.safety.skipChapterQuiz !== false) {
          logger.warn('QUIZ', '章节测验：按安全策略跳过（不答题），继续下一节看视频', {
            kind: q.kind || 'unknown',
            question: (q.question || '').slice(0, 60),
            blockCount: blocks.length,
            eventIds,
          });
          this.counters.quizzesSkipped = (this.counters.quizzesSkipped || 0) + 1;
          // 标记本节已处理，避免 advanceSection 之后又被拉回来
          this._videoSeenThisSection = true;
          this.failures = 0;   // 跳过是有效进展
          return this.advanceSection(st);
        }
        logger.warn('QUIZ', '只看视频模式：已记录章节测验/泛化题目，保持页面不动并停止', {
          kind: q.kind || 'unknown', question: (q.question || '').slice(0, 80), blockCount: blocks.length, eventIds,
        });
        this.stop('quiz_needs_human');
        return { progress: false, outcome: 'QUIZ_NEEDS_HUMAN' };
      }

      if (!q.parseable || !(q.options || []).length) {
        logger.warn('QUIZ', '题目结构无法识别；为避免触碰不明按钮而停止', {
          kind: q.kind || 'unknown', frameId: q.frameId, layer: q.layer,
          question: (q.question || '').slice(0, 60),
        });
        this.stop('quiz_unclassified_needs_human');
        return { progress: false, outcome: 'QUIZ_NEEDS_HUMAN' };
      }
      const useAi = !!(process.env.CX_LLM_ASK_URL || process.env.CX_LLM_MODEL);
      const targets = isWorkPage ? blocks : [{ i: 0, question: q.question, options: q.options, kind: 'single' }];

      /* —— 逐题作答 —— */
      let answered = 0;
      for (const blk of targets) {
        await humanize.quizThink(); // 2–5s 思考延迟，不秒选
        let pickIdx = 0;
        let pickBy = 'first';
        let imgB64 = '';

        if (useAi) {
          /* 截图：超星题干用 font-cxsecret 加密字体渲染，DOM 里是密文，
             截图才是明文。有图走图，没图才退回文本（文本此时无意义）。 */
          if (isWorkPage) {
            try {
              imgB64 = await this.captureQuizBlock(q.frameId, blk.i);
              if (imgB64) logger.info('QUIZ', '已截取题目图片', { block: blk.i, bytes: imgB64.length });
              else logger.warn('QUIZ', '题目截图失败，退回文本作答', { block: blk.i });
            } catch (e) {
              logger.warn('QUIZ', '题目截图失败，退回文本作答', { block: blk.i, err: String((e && e.message) || e).slice(0, 100) });
            }
          }
          try {
            const ai = await this.askAI(blk.question, blk.options, imgB64);
            if (ai >= 0) { pickIdx = ai; pickBy = imgB64 ? 'ai-vision' : 'ai'; }
            logger.info('QUIZ', 'AI 作答结果', { block: blk.i, idx: pickIdx, by: pickBy, model: process.env.CX_LLM_MODEL, hasImage: !!imgB64 });
          } catch (e) {
            logger.warn('QUIZ', 'AI 答题失败，回退首选项', { block: blk.i, err: String((e && e.message) || e) });
          }
        }

        const pick = isWorkPage
          ? await this.clickFound(q.frameId, 'quizBlockOption', { b: blk.i, o: pickIdx })
          : await this.clickFound(q.frameId, 'quizOption', pickIdx);
        if (!pick.ok) {
          logger.warn('QUIZ', '选项点击失败，本轮跳过', { block: blk.i, reason: pick.reason, layer: 3 });
          this.failures += 1;
          return { progress: false, outcome: 'QUIZ_PICK_FAIL' };
        }
        answered += 1;
        logger.info('QUIZ', '已选择选项', { block: blk.i, by: pickBy, note: pick.note, options: (blk.options || []).map((o) => o.letter) });
      }

      /* —— 提交 —— */
      const sub = isWorkPage
        ? await this.clickFound(q.frameId, 'quizBlockSubmit')
        : await this.clickFound(q.frameId, 'quizSubmit');
      if (sub.ok) {
        /* 超星的 .btnSubmit 只走到 workPop 确认框，真正提交还需要点 #popok。
           不点确认框 ⇒ 作业从未提交 ⇒ jobUnfinishCount 恒 >0 ⇒ 永远从第一章重来。 */
        if (isWorkPage) {
          const conf = await this.confirmWorkSubmit(q.frameId);
          if (!conf.confirmed) {
            logger.warn('QUIZ', '提交确认框未出现，无法确认作业已提交', { blocks: blocks.length });
          } else if (!conf.submitted) {
            logger.warn('QUIZ', '提交后未跳转到批阅页，作业可能仍未提交', { url: String(conf.url || '').slice(0, 120) });
          }
        }
        this.counters.quizzesAnswered += 1;
        logger.info('QUIZ', '已提交（若出现确认框，下一轮 P0 分支处理）', { submitText: sub.text, answered, blocks: blocks.length });
        return { progress: true, outcome: 'QUIZ_ANSWERED' };
      }
      logger.warn('QUIZ', '提交按钮点击失败', { reason: sub.reason, answered });
      this.failures += 1;
      return { progress: false, outcome: 'QUIZ_SUBMIT_FAIL' };
    });
  }

  /**
   * 截取作业页第 b 个题块的截图（base64 PNG）。
   *
   * 难点是坐标系（实测踩过的坑，务必照抄这套流程）：
   *   超星作业页在 4 层 iframe 里（studentstudy → knowledge/cards →
   *   ananas/modules/work → mooc-ans/work/doHomeWorkNew），
   *   而 Page.captureScreenshot 的 clip 用的是**顶层文档坐标**。
   *
   * 完整步骤：
   *   ① 在题目所在 frame 内把该题块滚到可视区（scrollIntoView）
   *   ② 取题块在本 frame 视口里的并集矩形（题块+题干+全部选项）
   *   ③ 沿 frame 链逐层累加偏移，换算成顶层文档坐标
   *      （每层 = 子 frame 的 frameElement 矩形 + 父 frame 的滚动量）
   *   ④ 把顶层页面滚到让裁剪区落进顶层视口
   *      —— 必须这一步！captureBeyondViewport=false 时裁剪区必须在视口内，
   *         否则 Chrome 截出来是空白或错位
   *   ⑤ 裁剪截图
   *
   * @returns {Promise<string>} base64 PNG；失败返回空串
   */
  async captureQuizBlock(frameId, blockIndex) {
    const adapter = this.adapter;
    if (!adapter || typeof adapter.getFrameChain !== 'function') return '';

    // ① frame 内滚动定位（不同 frame 的滚动互不影响）
    try {
      await adapter.evalInFrame(frameId, '__cx.find("quizBlockScroll",' + JSON.stringify({ b: blockIndex }) + ')');
    } catch (_) { /* 滚动失败也能试 */ }
    await sleep(500);

    // ② 本 frame 视口坐标的并集矩形
    const found = await adapter.evalInFrame(frameId, '__cx.find("quizBlockRect",' + JSON.stringify({ b: blockIndex }) + ')');
    if (!found || !found.ok || !found.rect) return '';
    const local = found.rect;

    // ③ frame 链 → 顶层文档坐标
    const chain = await adapter.getFrameChain(frameId);
    if (!chain || chain.length < 2) return '';
    const org = await adapter.frameOrigin(chain);
    const frameScroll = await adapter.evalInFrame(frameId, '({ x: window.scrollX || 0, y: window.scrollY || 0 })');
    const docX = org.ox + local.x + (frameScroll.x || 0);
    const docY = org.oy + local.y + (frameScroll.y || 0);

    // ④ 把顶层页面滚到让裁剪区进入顶层视口
    const vp = await adapter.rootViewport();
    const want = Math.max(0, Math.round(docY - Math.floor(vp.h / 3)));
    await adapter.scrollRootTo(want);
    await sleep(500);

    // ⑤ 滚动后 frame 链上的偏移会变（子 frame 相对顶层移动了），必须重算
    const org2 = await adapter.frameOrigin(chain);
    const frameScroll2 = await adapter.evalInFrame(frameId, '({ x: window.scrollX || 0, y: window.scrollY || 0 })');
    const clip = {
      x: Math.max(0, Math.round(org2.ox + local.x + (frameScroll2.x || 0))),
      y: Math.max(0, Math.round(org2.oy + local.y + (frameScroll2.y || 0))),
      w: Math.max(1, Math.round(local.w)),
      h: Math.max(1, Math.round(local.h)),
    };

    const rootNow = await adapter.rootViewport();
    const inView = clip.y >= rootNow.sy && (clip.y + clip.h) <= rootNow.sy + rootNow.h;
    if (!inView) {
      logger.warn('QUIZ', 'WARN 裁剪区不在顶层视口内，截图可能错位', {
        block: blockIndex, clip, rootScroll: rootNow.sy, vh: rootNow.h,
      });
    }
    logger.info('QUIZ', '题目坐标已换算到顶层文档', {
      block: blockIndex, chain: chain.length, origin: org.parts.join('|'),
      local: local.x + ',' + local.y + ',' + local.w + ',' + local.h,
      clip: clip.x + ',' + clip.y + ',' + clip.w + ',' + clip.h, inView: inView,
    });

    return await adapter.screenshotClip(clip);
  }

  /**
   * P2：处理作业提交后的确认框，并校验是否真的提交成功。
   *
   * 超星的提交链路（实测自 doHomeWorkNew 页）：
   *   .btnSubmit → onclick="btnBlueSubmit()"
   *     → validateTimeNew(classId, courseId, knowledgeId, cb)   // GET /mooc-ans/work/validate
   *         status==1 → 账号异常，直接 return
   *         status==2 → 弹验证码
   *         status==3 → cb('','')  ← 正常路径
   *     → toadd('','')
   *         → 收集各题答案 → workPop('Submit？', 'Submit', 'Cancel', cb)
   *     → 弹出 #workpop 确认框（★ 用 top.workPop 渲染 ⇒ 出现在**顶层 frame**）
   *     → 用户点 #popok → submitCheckTimes() → form1submit()  ← 真正提交
   *
   * 早期版本只点了 .btnSubmit 就当提交成功 ⇒ 确认框还挂着 ⇒ 作业从未提交
   * ⇒ 目录里 jobUnfinishCount 恒 >0 ⇒ 永远从第一章重新开始（主人报的核心症状）。
   *
   * @returns {Promise<{confirmed:boolean, frameId?:string, note?:string, submitted?:boolean, url?:string}>}
   */
  async confirmWorkSubmit(workFrameId) {
    const adapter = this.adapter;
    const deadline = Date.now() + 15000;
    let confirmed = false;
    let note = '';

    // 确认框可能在顶层 frame，也可能在作业 frame（不同版本超星实现不一致）→ 全部扫一遍
    while (Date.now() < deadline && !confirmed) {
      let frames = [];
      try {
        frames = await adapter.getFrameDocuments();
      } catch (_) { break; }
      for (const f of frames) {
        if (f.url && /^about:blank/.test(f.url)) continue;
        try {
          await adapter.evalInFrame(f.frameId, '__cx.find("workConfirm",null)');
        } catch (_) { continue; }
        const found = await adapter.evalInFrame(f.frameId, '__cx.find("workConfirm",null)');
        if (!found || !found.ok) continue;
        logger.info('QUIZ', '检测到作业提交确认框，点击确定', {
          frameId: f.frameId.slice(0, 10), note: found.note, text: found.text,
        });
        const r = await this.clickFound(f.frameId, 'workConfirm');
        if (r.ok) {
          confirmed = true;
          note = found.note || '';
          break;
        }
      }
      if (!confirmed) await sleep(600);
    }

    if (!confirmed) {
      logger.warn('QUIZ', '未出现提交确认框（可能该版本直接提交）', {});
      return { confirmed: false };
    }

    // 点完确认框后页面会跳到「批阅页」selectWorkQuestionYiPiYue → 视为提交成功
    await sleep(3000);
    let submitted = false;
    let url = '';
    try {
      url = String(await adapter.evalInFrame(workFrameId, 'location.href'));
    } catch (_) { /* frame 可能已销毁 */ }
    if (/selectWorkQuestionYiPiYue|selectWorkQuestion|workAnswerDetail|doHomeWorkNew/.test(url)) {
      // doHomeWorkNew 还在说明可能没跳走；再等一轮看有没有变化
      if (/selectWorkQuestionYiPiYue|selectWorkQuestion|workAnswerDetail/.test(url)) submitted = true;
    }
    if (!submitted) {
      await sleep(2500);
      try {
        url = String(await adapter.evalInFrame(workFrameId, 'location.href'));
      } catch (_) { /* ignore */ }
      submitted = /selectWorkQuestionYiPiYue|selectWorkQuestion|workAnswerDetail/.test(url);
    }
    logger.info('QUIZ', submitted ? '作业已真正提交' : '已点确认，但页面未跳转到批阅页（提交可能未生效）', {
      url: url.slice(0, 140), submitted,
    });
    return { confirmed: true, submitted, url, note };
  }

  /**
   * 判断视频是否「卡死」（而不是普通的暂停）。
   *
   * 实测超星视频卡住的特征：
   *   readyState = 0（HAVE_NOTHING，连元数据都没拿到）
   *   networkState = 1（NETWORK_IDLE）
   *   buffered = []（一个字节都没缓冲）
   *   进度长时间不动
   * 根因：超星的视频源是带**时效签名**的 CDN 链接
   *   https://s2.cldisk.com/.../sd.mp4?at_=<签发时间戳>&ak_=<key>&ad_=<...>
   * 签名过期后 CDN 直接返回 **HTTP 403**（实测确认），页面不会自己换新链接。
   * ⇒ 点播放按钮无效，必须重新加载页面拿新的签名 URL。
   *
   * @param {object} v videoState 的结果
   * @returns {boolean}
   */
  _isVideoStalled(v) {
    if (!v || !v.found) return false;
    // 有明确错误码（网络/解码错误）也算卡死
    if (v.error) return true;
    // readyState 0 = 没有任何数据到达 → 必然是源加载失败（签名过期 / 403）
    if (v.readyState === 0) return true;
    // 网络空闲但一字节都没缓冲
    if (v.networkState === 1 && Array.isArray(v.buffered) && !v.buffered.length) return true;
    return false;
  }

  /**
   * 判断视频进度是否停滞（paused=false 但时间不动）。
   *
   * 播放器仍报"播放中"，但 currentTime 连着几轮不变 —— 通常是缓冲耗尽
   * 或源已失效（CDN 签名过期后，浏览器可能仍保留旧连接）。
   * 判据：连续 N 轮 currentTime 完全不变（且不是 paused）。
   *
   * @param {object} v videoState 结果
   * @returns {boolean}
   */
  _progressStalled(v) {
    if (!v || !v.found) return false;
    if (v.paused || v.ended) return false;
    if (this._isVideoStalled(v)) return false;
    const t = v.currentTime || 0;
    const prev = this._lastProgressTime;
    // 只在已经播过一段之后才做停滞判定（避免刚加载完第一轮就误判）
    if (prev !== undefined && prev > 1 && Math.abs(t - prev) < 0.05) {
      this._stallTicks = (this._stallTicks || 0) + 1;
    } else {
      this._stallTicks = 0;
      this._lastProgressTime = t;
    }
    // 连续 4 轮（约 30 秒）不动 → 判为停滞
    if (this._stallTicks >= 4) {
      this._stallTicks = 0;
      this._lastProgressTime = undefined;
      return true;
    }
    return false;
  }

  /**
   * 重新加载课程页，拿到新的视频签名 URL 并恢复播放。
   *
   * ★ 关键：必须用**当前节的 chapterId** 重新加载。
   *   课程 URL 里的 chapterId 是固定的（第一节），直接重载会跳回第一节，
   *   那样既拿不到当前节的视频签名，也会把进度搞乱。
   *
   * @returns {Promise<boolean>} 是否成功重新加载并恢复播放
   */
  async reloadForFreshVideo() {
    const adapter = this.adapter;
    logger.warn('PLAYING_CHECK', '视频卡死（源加载失败，通常是 CDN 签名过期 403），重新加载页面取新签名', {
      section: this._currentTitle,
    });
    try {
      const base = this.cfg && this.cfg.course && this.cfg.course.url;
      if (!base) {
        logger.warn('PLAYING_CHECK', '无法重载：缺少课程地址');
        return false;
      }
      /* 拼当前节的 URL：把 chapterId 换成当前节的 */
      let url = base;
      const cid = this._currentChapterId();
      if (cid) {
        try {
          url = base.replace(/([?&]chapterId=)\d+/, '$1' + cid);
        } catch (e0) { /* 用原地址 */ }
      }
      logger.info('PLAYING_CHECK', '重新加载当前节页面', { chapterId: cid || '(沿用原值)', url: String(url).slice(0, 110) });
      await adapter.navigate(url);
      await sleep(8000);
      const st = await this.gatherState();
      if (st.video && st.video.found && !this._isVideoStalled(st.video)) {
        // 恢复播放
        if (st.video.paused) {
          const r = await this.clickFound(st.video.frameId, 'videoToggle');
          if (!r.ok) return false;
          await this.muteIfPossible(st.video.frameId);
        }
        logger.info('PLAYING_CHECK', '重新加载后视频已恢复', {
          section: this._currentTitle,
          progress: st.video.progress,
          currentTime: st.video.currentTime,
        });
        this._stallTicks = 0;
        this._lastProgressTime = undefined;
        this._resumeAttempts = 0;
        return true;
      }
      logger.warn('PLAYING_CHECK', '重新加载后视频仍未恢复', {
        readyState: st.video ? st.video.readyState : 'no-video',
        buffered: st.video ? st.video.buffered : null,
      });
      return false;
    } catch (e) {
      logger.warn('PLAYING_CHECK', '重新加载异常', { err: String((e && e.message) || e).slice(0, 120) });
      return false;
    }
  }

  /** 取当前节的 chapterId（目录项 id 去掉 cur 前缀）。 */
  _currentChapterId() {
    // 切节时记下的最可靠
    if (this._currentChapterIdValue) return this._currentChapterIdValue;
    const items = (this._lastState && this._lastState.toc && this._lastState.toc.items) || [];
    let idx = -1;
    if (this._lastCurIdx != null && this._lastCurIdx < items.length) idx = this._lastCurIdx;
    else idx = items.findIndex((x) => x.current);
    if (idx < 0) return '';
    const it = items[idx];
    if (it && it.chapterId) return it.chapterId;
    // 兜底：按标题在目录里找同名项
    try {
      const title = this._currentTitle || '';
      const hit = items.find((x) => x.title === title && x.chapterId);
      if (hit) return hit.chapterId;
    } catch (_) { /* ignore */ }
    return '';
  }

  /**
   * 当前节在目录里的待办数（超星服务端认的完成度）。
   *
   * 每节的 jobUnfinishCount = 剩余未完成任务点（视频 1 + 章节测验 1 = 2）。
   * 所以：
   *   2 → 视频还没被超星记为看完
   *   1 → 视频已看完，只剩测验
   *   消失/done → 整节完成
   * 这是判断「视频到底看没看完」的唯一硬证据（播放器进度不作数）。
   *
   * @returns {number|string} 待办数；拿不到时返回 'unknown'
   */
  _currentPending(st) {
    const toc = st && st.toc;
    const items = (toc && toc.items) || [];
    if (!items.length) return 'unknown';
    let idx = -1;
    if (this._lastCurIdx != null && this._lastCurIdx < items.length) idx = this._lastCurIdx;
    else idx = items.findIndex((x) => x.current);
    if (idx < 0) return 'unknown';
    const it = items[idx];
    if (!it) return 'unknown';
    if (it.done) return 0;
    return typeof it.unfinish === 'number' && it.unfinish >= 0 ? it.unfinish : 'unknown';
  }

  /**
   * 当前节在目录里是否已被标记为「完成」。
   *
   * 学习通的完成标记有两种互斥形态（实测）：
   *   A) 全部完成 → 有 <span class="icon_Completed">，**且没有** input.jobUnfinishCount
   *   B) 还有待办 → 有 input.jobUnfinishCount（value = 待办数，>0）
   * 所以「done && 无 jobUnfinishCount」才等价于「这节整节都做完了」。
   */
  _currentSectionDone(st) {
    const toc = st && st.toc;
    const items = (toc && toc.items) || [];
    if (!items.length) return false;
    let idx = -1;
    if (this._lastCurIdx != null && this._lastCurIdx < items.length) idx = this._lastCurIdx;
    else idx = items.findIndex((x) => x.current);
    if (idx < 0) return false;
    const it = items[idx];
    if (!it || !it.done) return false;
    // done 但仍有待办数（>0）→ 只是部分完成，不能整节跳过
    if (typeof it.unfinish === 'number' && it.unfinish > 0) return false;
    return true;
  }

  /**
   * ★★★ 2026-10-29 新增：这一节的「视频任务」是否已完成 ★★★
   *
   * 为什么需要它（3.3 ↔ 3.4 空转 15 分钟的根因）：
   *   _currentSectionDone 要求「整节所有任务点都完成」（unfinish === 0）。
   *   但我们的策略是**跳过章节测验**，所以 unfinish 永远是 1 ——
   *   于是每节播完都不会被判定为完成，引擎反复切下一节又被弹回来。
   *   （实测 1.3~3.2 之所以正常，是因为它们播完时 pending 恰好降到了 1，
   *     走的是 confirmVideoWatched 那条路；3.4 因为首次进入拿不到 duration，
   *     pending 一直停在 2，就死循环了。）
   *
   * 参考 xuexitong-ai-assistant 的 pageInventory.markers（按 .ans-attach-ct 逐个分类）：
   *   它把每个任务点标成 video/audio/document/quiz/discussion 并单独记 finished，
   *   「视频这个任务点完成」就足以进入下一节，不需要整节归零。
   *
   * 判据（任一成立即可）：
   *   a) 目录 unfinish 已 < 本节任务点总数（说明至少完成了一个任务点）
   *   b) 页面扫描里所有 video 类任务点都是 finished（ans-job-finished 或 aria-label 含已完成）
   *   c) 视频确实播放到了进度阈值（由调用方结合 _startedVideoSrcs 保证是本次启动的）
   */
  _videoTaskDone(st) {
    /* a) 目录层面：待办数比任务点总数少，说明已经完成了一部分 */
    const it = this._currentTocItem(st);
    if (it && typeof it.unfinish === 'number') {
      const total = typeof it.taskTotal === 'number' ? it.taskTotal : 2; // 缺省按「视频+测验」=2
      if (it.unfinish < total) return { ok: true, by: 'toc-unfinish-below-total', unfinish: it.unfinish, total };
    }
    /* b) 页面层面：所有 video 任务点都标记完成 */
    const inv = this._lastInventory;
    if (inv && Array.isArray(inv.tasks) && inv.tasks.length) {
      const vids = inv.tasks.filter((t) => t.kind === 'video' || t.kind === 'audio');
      if (vids.length && vids.every((t) => t.finished)) {
        return { ok: true, by: 'page-video-task-finished', count: vids.length };
      }
    }
    return { ok: false };
  }

  /** 取目录里「当前节」那条 item（与 _currentSectionDone 同一套定位规则） */
  _currentTocItem(st) {
    const toc = st && st.toc;
    const items = (toc && toc.items) || [];
    if (!items.length) return null;
    let idx = -1;
    if (this._lastCurIdx != null && this._lastCurIdx < items.length) idx = this._lastCurIdx;
    else idx = items.findIndex((x) => x.current);
    return idx >= 0 ? items[idx] : null;
  }

  /**
   * ★ 2026-10-29：标记「本次运行真的推动过播放」的视频。
   * 只有被标记过的 src，才允许用 ended/进度 来判定播完。
   * 参考 xuexitong-ai-assistant 的 startedVideos 语义。
   */
  _markVideoStarted(video) {
    try {
      const src = String((video && video.src) || '').slice(0, 400);
      if (src) this._startedVideoSrcs.add(src);
      else this._startedVideoSrcs.add('__nosrc__');   // 没 src 的播放器（Mock/内联 blob）统一登记
    } catch (_) { /* ignore */ }
  }

  /** 这个视频是否为本次运行启动过（决定能否用 ended 判完成） */
  _isVideoStartedHere(video) {
    try {
      const src = String((video && video.src) || '').slice(0, 400);
      if (!src) {
        /* 没有 src 的情况（Mock、内联 blob、或超星用 MSE 挂载）：
           只要登记过就认，否则永远判不出来。 */
        return this._startedVideoSrcs.has('__nosrc__');
      }
      return this._startedVideoSrcs.has(src);
    } catch (_) { return false; }
  }

  /**
   * 刷新目录读当前节的待办数，确认超星服务端是否真的记了「视频看完」。
   *
   * 超星的学习进度是**定时上报**的，不是播放器一结束就写库。
   * 所以播放条走完的那一刻，目录里的 jobUnfinishCount 可能仍是 2（视频还没被记）。
   * 这里主动重新读目录并短暂等待，把真实状态确认下来 ——
   * 否则「看完了」只是我们自己的错觉。
   *
   * @param {number} [waitMs] 首次等待时长
   * @returns {Promise<number|string>} 待办数；拿不到返回 'unknown'
   */
  async confirmVideoWatched(waitMs) {
    const wait = typeof waitMs === 'number' ? waitMs : 6000;
    await sleep(wait);
    let pending = 'unknown';
    try {
      const st = await this.gatherState();
      pending = this._currentPending(st);
    } catch (_) { /* ignore */ }
    if (pending === 2) {
      // 上报可能还没到账，再等一轮
      await sleep(6000);
      try {
        const st = await this.gatherState();
        pending = this._currentPending(st);
      } catch (_) { /* ignore */ }
    }
    return pending;
  }

  /** P1/P3/P4：定位目录下一节（跳过已完成），切换并等待加载。 */
  async advanceSection(st) {
    const toc = st.toc;
    if (!toc || !toc.found) {
      this.failures += 1;
      logger.warn('ADVANCE', 'WARN P1 目录未识别，无法定位下一节', { layer: 0 });
      return { progress: false, outcome: 'TOC_MISSING' };
    }
    const items = toc.items || [];
    /* ★ 当前节定位：以「引擎自己推进到的位置」为准，而不是目录里的 current class。
       实测坑：学习通 posCatalog_active 只标记「上一次打开的节」，切到下一节后
       它不会跟着更新 —— 引擎每次重读目录都会退回原来那一节 ⇒ 永远在 1.1 打转。
       规则：_lastCurIdx（引擎自己记的位置）优先；只有当目录里 current 指向的
       标题跟引擎记录的不一致时，才认为是外部（用户手动）切节并跟随它。 */
    const currentIdx = items.findIndex((x) => x.current);
    let curIdx = -1;
    if (this._lastCurIdx != null && this._lastCurIdx < items.length) {
      curIdx = this._lastCurIdx;
      if (currentIdx >= 0 && currentIdx !== curIdx) {
        const curTitle = items[currentIdx].title || '';
        const lastTitle = items[curIdx].title || '';
        if (curTitle && lastTitle && curTitle !== lastTitle) {
          logger.info('ADVANCE', '检测到目录当前节被外部改变，跟随新位置', { from: lastTitle, to: curTitle });
          curIdx = currentIdx;
        }
      }
    } else if (currentIdx >= 0) {
      curIdx = currentIdx;
    }
    const start = curIdx >= 0 ? curIdx + 1 : 0;
    const chapterNoOf = (idx) => { let n = 0; for (let i = 0; i <= idx && i < items.length; i++) if (items[i].chapterHeader) n += 1; return n; };
    const curChapter = curIdx >= 0 ? chapterNoOf(curIdx) : 0;

    let target = null, bypassedDone = 0;
    for (let i = start; i < items.length; i++) {
      const it = items[i];
      if (it.chapterHeader) continue;        // 章头仅参与章号计算，不点击
      if (it.done) { bypassedDone += 1; continue; } // P3：跳过已完成任务点
      target = it;
      break;
    }
    if (!target) { this.stop('all_done_or_no_target'); return { progress: false, outcome: 'ALL_DONE' }; }
    if (this.counters.sectionsCompleted >= this.cfg.maxSections) {
      this.stop('max_sections_reached');     // P4：最大节数上限
      return { progress: false, outcome: 'MAX_SECTIONS' };
    }
    const targetChapter = chapterNoOf(target.i);
    if (targetChapter > curChapter && this.cfg.mode === 'current_chapter') {
      logger.info('ADVANCE', 'P4 当前章节已推进完毕（mode=current_chapter）', { curChapter, targetChapter, nextTitle: target.title });
      this.stop('chapter_boundary');
      return { progress: false, outcome: 'CHAPTER_BOUNDARY' };
    }

    const r = await this.clickFound(toc.frameId, 'tocItem', target.i);
    if (!r.ok) {
      logger.warn('ADVANCE', '目录项点击失败', { title: target.title, reason: r.reason });
      this.failures += 1;
      return { progress: false, outcome: 'TOC_CLICK_FAIL' };
    }
    logger.info('ADVANCE', 'P1 已切换到下一节', { title: target.title, bypassedDone, layer: r.layer, note: r.note, mode: this.cfg.mode });
    /* ★ 分层：切节事实写进中间文件 */
    try {
      if (BUS && BUS.reportLearn) {
        BUS.reportLearn({
          phase: 'advanced',
          section: target.title,
          sectionIndex: target.i,
          chapterId: target.chapterId || '',
          counters: this.counters,
        });
      }
      busEmit('learn', 'section-advance', { title: target.title, index: target.i });
    } catch (_) { /* ignore */ }
    this.counters.sectionsSkipped += bypassedDone;
    this._lastCurIdx = target.i;
    this._currentTitle = target.title;
    // 记住本节的 chapterId：重载页面时要用它（课程 URL 里的 chapterId 固定指向第一节）
    this._currentChapterIdValue = target.chapterId || '';
    this._videoSeenThisSection = false;
    this._waitTicks = 0;
    this._mutedTried = false;
    // 切到下一节 → 章节测验标签状态重置（下一节属于新的一章，测验入口会变）
    this._quizTabOpened = false;
    this._quizTabWaitTicks = 0;
    this._quizTabDoneFor = null;
    // 切节重置播放停滞/恢复计数（新节的视频是新会话）
    this._stallTicks = 0;
    this._lastProgressTime = undefined;
    this._resumeAttempts = 0;
    this._lastVideoFrameId = null;
    this._lastVideoCurrentTime = undefined;
    this._lastVideoDuration = undefined;
    this._lastVideoSrc = '';
    this._videoProgressTicks = 0;
    const loaded = await this.waitLoad(); // P1：切换后等待新页面加载完成
    return { progress: loaded, outcome: loaded ? 'SECTION_ADVANCED' : 'WAIT_LOAD_TIMEOUT' };
  }

  /** P1：切换后的加载等待 = 拟人化冷却（8–15s）+ 轮询确认视频就绪。 */
  async waitLoad() {
    await humanize.sectionCooldown();
    for (let i = 0; i < this.cfg.safety.maxLoadRetries; i++) {
      const st = await this.gatherState();
      /* ★★★ 2026-10-29：就绪 = 元素存在 **且** 元数据已加载（duration > 0）★★★
         原来只判 st.video.found，元素一出现就当作就绪，但此时 duration 还是 0，
         上层会把「没开始播」误判成「已播完」（详见 videoState 里的注释），
         导致 3.3 ↔ 3.4 空转。

         再加一个兜底：如果元素在但一直拿不到 duration，主动点一次播放按钮
         （超星新节有时停在待播放状态，中间那个大播放图标），推动它加载。
         仍然拿不到就交回状态机，由 tick 的卡滞逻辑处理，不在这里死等。 */
      if (st.video && st.video.found) {
        this._videoSeenThisSection = true;
        const dur = st.video.duration || 0;
        if (dur > 0) {
          logger.info('WAIT_LOAD', '新节视频已就绪', {
            title: this._currentTitle, retries: i, duration: dur,
          });
          return true;
        }
        /* 元素在但元数据未到 → 点播放推动加载。
           ★ 参考 xuexitong-ai-assistant L8884 的做法：
               if (video.readyState === 0 && playBtn) playBtn.click();
             readyState 0 = HAVE_NOTHING（元数据都没拿到），此时点播放能触发加载。
             readyState >= 1 说明元数据已在路上，再点反而可能暂停，所以只在 0 时点。
             每轮都要重试（不是只点一次）：切节后播放器可能重建，点一次不够。 */
        if (st.video.readyState === 0) {
          logger.info('WAIT_LOAD', '视频元数据未加载（readyState=0），点播放推动加载', {
            title: this._currentTitle, retries: i, networkState: st.video.networkState,
          });
          try { await this.clickFound(st.video.frameId || null, 'videoToggle'); } catch (_) { /* ignore */ }
          await sleep(1200);
          continue;
        }
        logger.info('WAIT_LOAD', '视频元素已在但时长仍未知，继续等待', {
          title: this._currentTitle, retries: i,
          readyState: st.video.readyState, networkState: st.video.networkState,
        });
      }
      if (st.human.length || st.loginInvalid) {
        logger.warn('WAIT_LOAD', '等待中检测到人工验证/登录态变化，交回主循环处理');
        return false;
      }
      await humanize.pollDelay();
    }
    logger.warn('WAIT_LOAD', '等待超时（新节未见可播放视频，交回状态机判定）', { retries: this.cfg.safety.maxLoadRetries });
    return false;
  }
}

/* ============================================================================
 * 第 7 节 · 主循环 run() —— 前置检查 + 带停止条件与异常捕获的 async 循环
 * ==========================================================================*/
let activeMachine = null;
try {
  process.on('SIGINT', () => { if (activeMachine) activeMachine.stop('user_abort'); });
} catch (_) { /* 非 Node 环境忽略 */ }

/**
 * 入口函数（后台任务 / 模块调用 / MCP 工具共用）。
 * @param {object} [overrides]  覆盖 CONFIG 的部分字段（深合并），如
 *                              { mode, maxSections, course:{url}, humanize:{...} }
 * @param {object} [options]    { adapter } — 注入自定义适配器（自测用 Mock）。
 * @returns {object} 结构化结果：{ ok, stopReason, sectionsCompleted, sectionsSkipped,
 *                              quizzesAnswered, dialogsDismissed, elapsedMs, logs }
 */
async function run(overrides, options) {
  const started = Date.now();
  const cfg = mergeConfig(CONFIG, overrides);
  validateConfig(cfg);
  logger.configure(cfg.log);
  logBanner(cfg);
  humanize.configure(cfg.humanize);

  const result = {
    ok: false, stopReason: null,
    sectionsCompleted: 0, sectionsSkipped: 0, quizzesAnswered: 0, dialogsDismissed: 0,
    elapsedMs: 0, logs: []
  };
  let machine = null;
  let adapterRef = null;
  /* 一次性登录：看课任务复用扫码登录时建好的临时 profile，跑完即删。
     若临时 profile 不存在（没先扫码），这里会新建一个空 profile —— 会因未登录而
     在预检阶段 LOGIN_REQUIRED，提示用户先扫码，符合预期。 */
  if (cfg.login && cfg.login.ephemeral && !(options && options.adapter)) {
    cfg.chromium.profileDir = fs.existsSync(EPHEMERAL_DIR) ? EPHEMERAL_DIR : ensureEphemeralProfile();
  }
  try {
    const adapter = (options && options.adapter) || createCdpAdapter(cfg);
    adapterRef = adapter
    /* ★ 分层自检：契约不完整立刻暴露（注入的 Mock adapter 也一并检查） */
    try { if (CONTRACT && CONTRACT.assertAdapter) CONTRACT.assertAdapter(adapter, 'run'); } catch (_) {}
    busEmit('learn', 'run-start', { mode: cfg.mode, maxSections: cfg.maxSections });

    /* —— 前置检查 —— */
    await adapter.ensureBrowser();
    if (cfg.course.url) {
      logger.info('PRECHECK', '导航到课程页', { url: String(cfg.course.url).slice(0, 120) });
      await adapter.navigate(cfg.course.url);
    } else {
      const currentUrl = await adapter.getCurrentUrl();
      if (!currentUrl || /^about:blank/.test(currentUrl)) {
        throw new FatalStop('NO_COURSE_URL', '请在 CONFIG.course.url（或 CX_COURSE_URL / --course-url / MCP courseUrl）提供课程学习页地址，或让浏览器停留在该页面。');
      }
      logger.info('PRECHECK', '未提供 course.url，沿用浏览器当前页面', { url: currentUrl.slice(0, 120) });
    }

    /* ★★★ 2026-10-29：自动「点进去」（替代人工提供带 enc 的 URL）★★★
       背景：主人配的 courseUrl 往往是「课程入口页」
         https://mooc1.chaoxing.com/mooc-ans/visit/stucoursemiddle?courseid=xxx
       这种页面 pageHeader=-1、没有 iframe、没有视频，引擎会判「无视频」→ 连续失败 → FATAL。
       而真正能看课的是 studentstudy 页，它必须带 chapterId + enc + openc，
       这三个参数**只有点进去才有**（拼 URL 必然「enc校验失败」）。

       所以这里在导航后自动判断：如果落地页不是可用学习页，就模拟点击
         「进课程」→「章节 tab」→「第一/指定小节」
       拿到真正的学习页 URL，再继续。

       识别「需要点进去」的信号（任一命中）：
         · URL 含 ismooc2=1 / stucoursemiddle（课程入口页）
         · 落地页 pageHeader=-1
         · gatherState 后 hasVideo=false 且 tocFound=false

       安全：全部是导航类点击（进课程/切 tab/点小节），不触碰任何学习元素。 */
    const isEntryPageUrl = (u) => /stucoursemiddle|ismooc2=1/i.test(String(u || ''));
    let needDrillDown = isEntryPageUrl(cfg.course.url);

    if (needDrillDown) {
      logger.info('PRECHECK', '检测到课程入口页，自动点进去（规避 enc 参数缺失）', {
        url: String(cfg.course.url).slice(0, 120),
      });
    }

    machine = new LearnMachine(adapter, cfg);
    activeMachine = machine;
    let st0 = await machine.gatherState();
    if (!st0.frames.length) throw new FatalStop('PAGE_UNREACHABLE', '课程页面不可达（frame 树为空）。请检查 URL 与登录态。');
    if (st0.loginInvalid) throw new FatalStop('LOGIN_REQUIRED', '登录态无效（' + st0.loginEvidence.join('; ') + '）。请人工在浏览器 profile 中重新登录（脚本不会、也不应自动登录），完成后重跑。');
    if (st0.human.length) throw new FatalStop('HUMAN_VERIFICATION', 'FATAL: 需要人工介入 — 启动预检即检测到人工验证特征: ' + st0.human.map((h) => h.evidence).join(', '));

    /* 落地页不可用（没有视频 + 没有目录）→ 自动点进去 */
    if (!needDrillDown && !(st0.video && st0.video.found) && !(st0.toc && st0.toc.found)) {
      const curUrlNow = await adapter.getCurrentUrl().catch(() => '');
      if (/pageHeader=-1/i.test(curUrlNow) || /mooc2-ans.*mycourse\/stu/i.test(curUrlNow)) {
        logger.info('PRECHECK', '落地页无视频无目录，尝试自动点进去', { url: String(curUrlNow).slice(0, 120) });
        needDrillDown = true;
      }
    }

    if (needDrillDown) {
      /* 从 courseUrl 里取 courseid 用于精确匹配课程卡片 */
      let wantCourseId = '';
      try {
        const m0 = String(cfg.course.url || '').match(/courseid=(\d+)/i);
        if (m0) wantCourseId = m0[1];
      } catch (_) { /* ignore */ }

      /* 1) 回课程列表并点进课程 */
      const LANDING = 'https://mooc1.chaoxing.com/visit/interaction';
      logger.info('PRECHECK', '自动点进去：回到课程列表', { landing: LANDING });
      try { await adapter.navigate(LANDING); } catch (_) { /* 已在列表页也无妨 */ }
      await sleep(7000);

      const opened = await openCourseByClick(adapter, '', { maxWaitMs: 30000, cfg, courseId: wantCourseId });
      if (!opened.ok) {
        throw new FatalStop('ENTRY_CLICK_FAILED',
          '自动进入课程失败（' + (opened.reason || '未知') + '）。'
          + ' 请在浏览器里手动点进目标课程的小节，然后把地址栏带 chapterId & enc 的完整 URL 填进「课程地址」。');
      }
      logger.info('PRECHECK', '自动点进去：已进入课程页', { url: String(opened.url || '').slice(0, 120) });
      await sleep(5000);

      /* 2) 点「章节」tab 并等章节树 */
      const prefix = String((cfg.course && cfg.course.sectionPrefix) || '');
      const chOk = await openChapterAndWait(adapter, cfg, { maxRound: 2 });
      if (!chOk || !chOk.ok) {
        throw new FatalStop('ENTRY_CHAPTER_FAILED',
          '进入课程后点「章节」失败。请在浏览器里手动点进目标小节，把带 chapterId & enc 的完整 URL 填进「课程地址」。');
      }
      logger.info('PRECHECK', '自动点进去：章节树已就绪');

      /* 3) 点第一个（或指定）小节，落地到真正的学习页 */
      const sec = await openSectionByClick(adapter, prefix);
      if (!sec.ok) {
        throw new FatalStop('ENTRY_SECTION_FAILED',
          '章节树已就绪但点小节失败（' + (sec.reason || '未知') + '）。');
      }
      logger.info('PRECHECK', '自动点进去：已打开小节', { section: String(sec.text || '').slice(0, 60) });
      await sleep(8000);

      const landedUrl = await adapter.getCurrentUrl().catch(() => '');
      logger.info('PRECHECK', '自动点进去：落地页', { url: String(landedUrl).slice(0, 140) });
      if (!/[?&]chapterId=\d+/i.test(landedUrl)) {
        logger.warn('PRECHECK', '落地 URL 未含 chapterId，继续尝试（可能仍在章节树页）', {
          url: String(landedUrl).slice(0, 140),
        });
      }

      /* 4) 重建 machine 并重新取状态（页面已变） */
      machine = new LearnMachine(adapter, cfg);
      activeMachine = machine;
      st0 = await machine.gatherState();
      if (!st0.frames.length) throw new FatalStop('PAGE_UNREACHABLE', '自动点进去后页面仍不可达。');
      if (st0.loginInvalid) throw new FatalStop('LOGIN_REQUIRED', '自动点进去后登录态失效，请重新扫码登录。');
    }
    const cur0 = st0.toc && st0.toc.items ? st0.toc.items.find((x) => x.current) : null;
    machine._currentTitle = (cur0 && cur0.title) || '当前节';
    machine._videoSeenThisSection = !!(st0.video && st0.video.found);
    machine._lastCurIdx = st0.toc && st0.toc.items ? st0.toc.items.findIndex((x) => x.current) : -1;
    if (machine._lastCurIdx < 0) machine._lastCurIdx = null;
    // 记住当前节的 chapterId（重载页面时要用；课程 URL 里的是固定的第一节）
    if (cur0 && cur0.chapterId) machine._currentChapterIdValue = cur0.chapterId;
    else {
      try {
        const mu = String(cfg.course.url || '').match(/[?&]chapterId=(\d+)/);
        if (mu) machine._currentChapterIdValue = mu[1];
      } catch (_) { /* ignore */ }
    }
    logger.info('PRECHECK', '前置检查通过', {
      url: st0.topUrl, frames: st0.frames.length,
      hasVideo: !!(st0.video && st0.video.found),
      tocFound: !!(st0.toc && st0.toc.found), tocLayer: st0.toc ? st0.toc.layer : 0,
      section: machine._currentTitle
    });

    /* —— 主循环 —— */
    let consecutiveNonProgress = 0;
    while (!machine.stopReason) {
      if (Date.now() - started > cfg.safety.maxRuntimeMs) { machine.stop('max_runtime_exceeded'); break; }
      await humanize.maybeLongPause();
      let step;
      try {
        step = await machine.tick();
      } catch (e) {
        machine.failures += 1;
        logger.error('LOOP', 'tick 异常，计入连续失败 ' + machine.failures + '/' + cfg.safety.maxConsecutiveFailures, { err: String((e && e.message) || e).slice(0, 200) });
        step = { progress: false, outcome: 'TICK_EXCEPTION' };
      }
      if (machine.stopReason) break;
      if (step.progress) {
        machine.failures = 0;
        consecutiveNonProgress = 0;
      } else {
        consecutiveNonProgress += 1;
        if (machine.failures >= cfg.safety.maxConsecutiveFailures) {
          machine.fatalStop('UNRECOGNIZED_PAGE', '连续 ' + machine.failures + ' 次关键操作失败/页面无法识别，停止并输出诊断');
          break;
        }
        if (consecutiveNonProgress >= cfg.safety.maxConsecutiveFailures * 3) {
          machine.fatalStop('UNRECOGNIZED_PAGE', '连续 ' + consecutiveNonProgress + ' 轮无进展，防呆停止');
          break;
        }
        await humanize.pollDelay();
      }
    }
    if (machine.stopReason && !result.stopReason) result.stopReason = machine.stopReason;
  } catch (e) {
    if (e instanceof FatalStop) {
      result.stopReason = e.code;
      logger.error('FATAL', 'FATAL: ' + e.code + ' — ' + e.message);
    } else {
      result.stopReason = 'UNEXPECTED_ERROR';
      logger.error('FATAL', 'FATAL: ' + String((e && e.stack) || e).slice(0, 800));
    }
  } finally {
    activeMachine = null;
    /* 一次性登录：无论成功/失败/异常，都销毁临时 profile；并确保浏览器进程退出。 */
    try { await shutdownBrowser(adapterRef); } catch (_) { /* ignore */ }
    try { cleanupEphemeralProfile(); } catch (_) { /* ignore */ }
  }

  if (machine) {
    result.stopReason = result.stopReason || machine.stopReason || 'unknown';
    result.ok = machine.stoppedNormally;
    result.sectionsCompleted = machine.counters.sectionsCompleted;
    result.sectionsSkipped = machine.counters.sectionsSkipped;
    result.quizzesAnswered = machine.counters.quizzesAnswered;
    result.dialogsDismissed = machine.counters.dialogsDismissed;
  }
  result.elapsedMs = Date.now() - started;
  result.logs = logger.tail(40);
  logger.log('SUMMARY', result.ok ? 'INFO' : 'ERROR', '运行结束', {
    ok: result.ok, stopReason: result.stopReason,
    sectionsCompleted: result.sectionsCompleted, sectionsSkipped: result.sectionsSkipped,
    quizzesAnswered: result.quizzesAnswered, dialogsDismissed: result.dialogsDismissed,
    elapsedMs: result.elapsedMs
  });
  return result;
}

/**
 * 无头扫码登录（真实环境一次性动作）。
 * 流程：打开个人空间检测 profile 登录态 → 未登录则打开登录页（二维码）→
 *       周期截图到 shotDir/latest.png（用户在手机「学习通」App 里扫屏幕上的码）→
 *       轮询顶层 URL 跳出 passport/login 域即视为成功 → 登录态持久化在 profile。
 * 不接触账密、不自动填表、不绕过任何验证；二维码过期自动刷新登录页。
 * @returns {{ok:boolean, already?:boolean, reason?:string, screenshot:string}}
 */
async function runLogin(overrides) {
  const cfg = mergeConfig(CONFIG, overrides);
  logger.configure(cfg.log);
  const L = cfg.login;
  const started = Date.now();
  fs.mkdirSync(L.shotDir, { recursive: true });
  const shotPath = path.join(L.shotDir, 'latest.png');
  const isLoginHost = (u) => new RegExp(L.successUrlPattern, 'i').test(String(u || '')) && !/passport[2.]|login\./i.test(String(u || ''));

  /* 机器可读的登录结果文件：宿主与前端不再靠解析日志猜「成没成」。
     成功必须二次验证（扫完码回个人空间仍停留在已登录域）才算 verified。 */
  const resultPath = process.env.CX_LOGIN_RESULT || path.join(L.shotDir, 'result.json');
  const writeResult = (obj) => {
    try { fs.writeFileSync(resultPath, JSON.stringify(Object.assign({ at: Date.now() }, obj))) } catch { /* ignore */ }
  };
  writeResult({ ok: false, verified: false, reason: 'started' });

  /* 一次性登录：扫码用专属临时 profile；登录成功后保留，供紧接着的看课任务复用，
     看课结束由 run() 的 finally 删除。 */
  if (L.ephemeral) {
    cfg.chromium.profileDir = ensureEphemeralProfile();
  }

  const adapter = createCdpAdapter(cfg);
  _activeAdapter = adapter;
  /* ★ 分层自检：adapter 必须完整实现 adapter-contract.js 里的契约。
     浏览器层加方法不会影响业务层；删/改已有方法会在这里立刻暴露，
     而不是跑到一半才 undefined。 */
  try { if (CONTRACT && CONTRACT.assertAdapter) CONTRACT.assertAdapter(adapter, 'runLogin'); } catch (_) {}
  try {
    await adapter.ensureBrowser();

    /* ★★★ 2026-10-29：登录前先清掉残留的登录页标签 ★★★
       实测坑：反复重试会在浏览器里堆出 6+ 个 passport2 登录页标签，
       它们抢同一个二维码会话，且 getCurrentUrl() 可能读到错误的那个标签，
       导致「看起来在登录页 / 实际在别的标签」这类误判。
       这里在导航前清一次，只留必要标签。 */
    try {
      const all = await listTargets(cfg).catch(() => []);
      const stale = (all || []).filter((t) =>
        t.type === 'page' && /passport2?\.chaoxing\.com|login/i.test(t.url || '')
      );
      if (stale.length > 1) {
        logger.log('LOGIN', 'INFO', '清理残留的登录页标签', { count: stale.length - 1 });
        const port = resolveCdpPort(cfg);
        const cdpBase = port ? 'http://' + (cfg.cdp.host || '127.0.0.1') + ':' + port : '';
        for (const t of stale.slice(1)) {
          if (!cdpBase) break;
          try {
            await fetch(cdpBase + '/json/close/' + t.id, { method: 'GET' });
          } catch (_) { /* ignore */ }
        }
        await sleep(800);
      }
    } catch (_) { /* 清理失败不影响主流程 */ }

    /* ★ 登录态判定：URL 在已登录域之后，**还要验 cookie**。
       实测坑：Chrome/Edge 的密码管理器会自动填好账号密码框，
       页面看起来「像已登录」，但 URL 仍是 passport2 登录页、服务端并未认证。
       所以这里除了看 URL，还检查 UID/_uid 这些关键 cookie 是否真实存在。 */
    const hasAuthCookie = async () => {
      try {
        const cookies = await adapter.getAllCookies().catch(() => null);
        if (!cookies || !cookies.length) return null;   // 拿不到就不作为否决依据
        const names = new Set((cookies || []).filter((c) => /chaoxing/.test(c.domain || '')).map((c) => c.name));
        const need = ['UID', '_uid'];
        const hit = need.filter((n) => names.has(n));
        return { ok: hit.length > 0, hit, total: cookies.length };
      } catch (_) { return null; }
    };

    // 1) 先看 profile 是否已有登录态（一次性模式下是全新 profile，通常不会命中）
    await adapter.navigate(L.homeUrl);
    await sleep(2000);
    let url = await adapter.getCurrentUrl();
    if (isLoginHost(url)) {
      const auth = await hasAuthCookie();
      if (auth && auth.ok === false) {
        logger.log('LOGIN', 'WARN', 'URL 在已登录域但缺少认证 cookie，可能是自动填充的假象，走扫码流程', {
          url: url.slice(0, 120), cookies: auth.total,
        });
      } else {
        await adapter.screenshot(shotPath);
        logger.log('LOGIN', 'INFO', 'profile 已有登录态，无需重新扫码', {
          url: url.slice(0, 120), screenshot: shotPath, cookies: auth ? auth.total : 'unknown',
        });
        writeResult({ ok: true, verified: true, already: true, url: String(url).slice(0, 200) });
        return { ok: true, already: true, screenshot: shotPath };
      }
    }
    // 2) 未登录 → 登录页，**先切到扫码模式**（默认显示的是账号密码表单）
    logger.log('LOGIN', 'INFO', '未检测到登录态，打开登录页并切换到扫码模式', {
      screenshot: shotPath,
      hint: '请在手机「学习通」App 打开扫一扫，扫描截图中的二维码并在手机上确认'
    });
    /* ★ 登录页必须清掉全局 Referer 头，且必须在 navigate **之后**清：
       navigate() 结尾会再调一次 _applyExtraHeaders()（给视频 CDN 用的
       Referer: mooc1.chaoxing.com），登录页上这是非法跨域头，
       /createqr 图片请求直接被 Chrome 拒掉（net::ERR_INVALID_ARGUMENT），
       二维码永远 0x0，页面自带的 getauthstatus 轮询也就永远对不上会话。 */
    await adapter.navigate(L.loginUrl);
    await sleep(1500);
    try { await adapter.clearExtraHeaders() } catch (_) { /* ignore */ }
    const switched = await switchToQrMode(adapter, L);
    logger.log('LOGIN', 'INFO', switched ? '已切换到扫码登录' : '未能自动切换到扫码登录，将按页面原样截图', { switched });
    await sleep(1200);

    /* ★★★ 2026-10-27 修正：不再做任何 blob 注入！★★★
       主人指出「二维码中间有图片加载失败的样子」，实测 img.src 是
       blob:https://passport2.chaoxing.com/xxx —— 那正是之前用
       fetch + createObjectURL 注入留下的，上下文重建后 blob 失效 → 破图。
       现在完全使用站点原生 <img id="quickCode">（/createqr?uuid=...）。
       原生图加载失败的真因是系统代理，靠 --no-proxy-server 解决。 */
    const patchQrImage = async () => {
      const frames = await adapter.getFrameDocuments()
      const expr = `(() => {
        const img = document.getElementById('quickCode');
        if (!img) return JSON.stringify({ ok: false, reason: 'no-quickCode' });
        const src = String(img.src || '');
        if (src.startsWith('blob:')) {
          const u = (document.getElementById('uuid') || {}).value || '';
          if (u) img.src = '/createqr?uuid=' + encodeURIComponent(u) + '&fid=-1&_t=' + Date.now();
        }
        img.style.width = '200px';
        img.style.height = '200px';
        img.style.display = 'block';
        img.style.margin = '0 auto';
        img.style.background = '#fff';
        const box = img.closest && img.closest('.ecode-box');
        if (box) { const dis = box.querySelector('.ewmDisable'); if (dis) dis.style.display = 'none'; }
        return JSON.stringify({
          ok: true,
          src: String(img.src || '').slice(0, 70),
          nw: img.naturalWidth, nh: img.naturalHeight,
          isBlob: String(img.src || '').startsWith('blob:'),
          uuid: (document.getElementById('uuid') || {}).value || ''
        });
      })()`
      for (const f of frames) {
        try {
          const res = await adapter.evalInFrame(f.frameId, expr)
          let info; try { info = JSON.parse(res) } catch (_) { info = null }
          if (!info || !info.ok) continue
          await sleep(1500)
          const chk = await adapter.evalInFrame(f.frameId, `JSON.stringify({nw:(document.getElementById('quickCode')||{}).naturalWidth||0})`)
          let c; try { c = JSON.parse(chk) } catch (_) { c = { nw: 0 } }
          if (c.nw > 50) {
            logger.log('LOGIN', 'INFO', '二维码使用站点原生渲染', { src: info.src, nw: c.nw, isBlob: info.isBlob })
            return true
          }
          logger.log('LOGIN', 'WARN', '原生二维码仍是 0x0，重载页面以重新加载资源')
          return false
        } catch (_) { /* 换下一个 frame */ }
      }
      return false
    }
    await patchQrImage()

    /* ★★★ 关键前置检查（主人 2026-10-27 指出的规律）：
       「出现完整渲染的页面才有机会成功，没加载完的基本上不成功」。
       实测对比：
         - CSS 已加载：灰背景 + 白卡片 + 圆角 + 蓝按钮  → 扫码有机会成功
         - CSS 未加载：纯白底 + 黑字 + 左对齐裸表单      → 扫码必然失败
       原理：样式没加载完时，页面 JS 也未必初始化完，二维码会话是半残的。
       所以扫码前必须确认渲染完整，否则先重载重试。 */
    /* ★★★ 渲染完整性判定（2026-10-27 实测确定，之前的判据完全错误）★★★
       主人经验：「出现完整渲染的页面才有机会成功，没加载完的基本上不成功」
       实测对比：
         | 指标                    | 裸页（必失败） | 完整页（可成功） |
         | .default-login 圆角     | 0px           | 16px            |
         | .btn-big-blue 宽度      | 43px          | 360px           |
         | .default-login 宽度     | 1316          | 900             |
         | styleSheets 数量        | 7~8           | 7~8（相同！）   |
         | 二维码 naturalWidth     | 0             | 270             |
       旧判据用 sheets>0 && naturalWidth>50，但裸页与完整页的 sheets 一样，
       所以永远误判为「已就绪」，导致主人在裸页上扫码必然失败。 */
    const checkRendered = async () => {
      try {
        const r = await adapter.evalInFrame(null, `(() => {
          const box = document.querySelector('.default-login');
          const btn = document.querySelector('.btn-big-blue');
          const img = document.getElementById('quickCode');
          const cs = box ? getComputedStyle(box) : null;
          const boxRadius = cs ? String(cs.borderRadius) : '';
          const boxBg = cs ? String(cs.backgroundColor) : '';
          const btnW = btn ? Math.round(btn.getBoundingClientRect().width) : 0;
          const qrNw = img ? img.naturalWidth : 0;
          const rendered = boxRadius.indexOf('16px') >= 0
            && boxBg.indexOf('255, 255, 255') >= 0
            && btnW >= 300
            && qrNw > 200;
          return JSON.stringify({
            rendered, boxRadius, boxBg, btnW, qrNw,
            boxW: box ? Math.round(box.getBoundingClientRect().width) : 0,
            sheets: document.styleSheets ? document.styleSheets.length : 0,
            uuid: (document.getElementById('uuid') || {}).value || ''
          });
        })()`)
        let info; try { info = JSON.parse(r) } catch (_) { info = null }
        return info
      } catch (_) { return null }
    }
    const waitForFullyRendered = async (maxMs) => {
      const deadline = Date.now() + (maxMs || 60000)
      let tries = 0
      while (Date.now() < deadline) {
        tries += 1
        const info = await checkRendered()
        if (info && info.rendered) {
          logger.log('LOGIN', 'INFO', '登录页渲染完整（圆角16px/按钮360px），可以扫码', info)
          return true
        }
        if (info && tries % 5 === 1) {
          logger.log('LOGIN', 'INFO', '登录页尚未渲染完整（裸页），继续等待', {
            boxW: info.boxW, radius: info.boxRadius, btnW: info.btnW, qrNw: info.qrNw, sheets: info.sheets
          })
        }
        await sleep(1000)
      }
      return false
    }
    /* ★★★ 2026-10-29 实测结论（FNOS）：首次加载必然是裸页 ★★★
       对比数据（同一台机器、同一个登录页）：
         首次加载  → boxW=1350, radius=0px,  btnW=43,  qrNw=0     （裸页）
         重载之后  → boxW=900,  radius=16px, btnW=360, qrNw=270   （完整）
       刷新后在 24 秒内连续采样 8 次，全程稳定在完整态 —— 说明**页面不会自己退化**，
       裸页就是「首次加载 CSS 没生效」，重载一次即好。

       所以这里不等 60 秒：首次只给 12 秒（正常情况下 3 秒内就能看出是不是裸页），
       裸页就立刻重载，重载后给 40 秒充分时间。这样能把等待从 60+ 秒压到 ~15 秒。 */
    let rendered = await waitForFullyRendered(12000)
    for (let round = 1; !rendered && round <= 3; round++) {
      logger.log('LOGIN', 'WARN', `渲染未完整（首次加载常见），第 ${round} 次重载重试`)
      try {
        /* ★ 关键：navigate 到 loginUrl 会重新走一遍首页跳转，
           实测这条路常常又落回裸页；直接 navigate 到带 newversion 的登录页更稳。 */
        const directLogin = L.loginUrl
        await adapter.navigate(directLogin)
        await sleep(3000)
        try { await adapter.clearExtraHeaders() } catch (_) { /* ignore */ }
        /* 登录页默认是账号密码表单，必须切到扫码模式才有二维码 */
        const sw = await switchToQrMode(adapter, L)
        logger.log('LOGIN', 'INFO', '重载后切换扫码模式', { switched: !!sw })
        await sleep(2000)
        await patchQrImage()
      } catch (e) {
        logger.log('LOGIN', 'WARN', '重载登录页出错', { err: String((e && e.message) || e).slice(0, 100) })
      }
      rendered = await waitForFullyRendered(40000)
      if (rendered) {
        logger.log('LOGIN', 'INFO', '重载后渲染成功，进入扫码阶段', { round })
      }
    }
    if (!rendered) {
      logger.log('LOGIN', 'ERROR', '登录页始终未渲染完整，扫码大概率失败（建议重启浏览器）')
    }

    const deadline = Date.now() + L.timeoutMs;
    let lastReload = Date.now();
    let ok = false;
    /* 记录最近几代 uuid→enc：手机扫的往往是「上一代」码（图在我这里传
       60 秒才换一代），刷新页面后页面 JS 只轮询新 uuid，旧码确认了就没人接。
       引擎侧自己轮询 getauthstatus/v2，新旧代都接得住。 */
    const qrSessions = new Map();
    while (Date.now() < deadline) {
      await sleep(L.pollMs);
      url = await adapter.getCurrentUrl();
      if (isLoginHost(url)) { ok = true; break; }

      /* ★★★ 2026-10-27 实测修正：扫码成功后，站点常把「个人空间」开在**新标签页**，
          当前 target 仍停在 passport2 登录页 —— 只看 getCurrentUrl() 会一直判未登录，
          最终误报 timeout（主人已确认登录成功，引擎却写 reason=timeout）。
          所以这里补一次跨 target 检查：只要存在任何已登录域且非登录页的 tab，就算成功。 */
      try {
        const all = await listTargets(cfg).catch(() => []);
        const loggedTab = (all || []).find((t) =>
          t.type === 'page' && isLoginHost(t.url || '') &&
          !/passport2|passport\.chaoxing\.com\/login/i.test(t.url || '')
        );
        if (loggedTab) {
          logger.log('LOGIN', 'INFO', '检测到已登录标签页（跨 target），判定登录成功', {
            url: String(loggedTab.url).slice(0, 110)
          });
          // 切到这个已登录标签，后续操作直接在它上面做
          try { await adapter.attachTarget(loggedTab.id); } catch (_) { /* ignore */ }
          url = String(loggedTab.url);
          ok = true;
          break;
        }
      } catch (_) { /* ignore */ }

      /* ★★★ 关键：先查扫码状态，再决定要不要换码。
         主人实测「看到头像/昵称闪了几秒又消失」，那是 type=4（已扫待确认）
         或 data.status 刚变 true 的瞬间 —— 此时若换码，这次登录就被自己作废。
         所以顺序必须是：先 poll → 有进展就只等不换码。 */
      let sawPending = false
      try {
        const sess = await readQrSession(adapter)
        if (!sess || !sess.uuid) {
          if (!global.__cxQrSessWarned) {
            global.__cxQrSessWarned = true
            logger.log('LOGIN', 'WARN', '读不到页面 uuid，引擎侧状态轮询无法工作', { sess: sess ? JSON.stringify(sess).slice(0, 120) : 'null' })
          }
        } else {
          qrSessions.set(sess.uuid, sess.enc)
          if (qrSessions.size > 12) qrSessions.delete(qrSessions.keys().next().value)
          let scanned = null
          let curType = null          // 当前代服务器的 type
          let curMes = ''
          let curNick = ''
          for (const [u, e] of [...qrSessions.entries()].slice(-4)) {
            const r = await fetchQrAuthStatusInPage(adapter, u, e)
            if (!r.ok) continue
            const d = r.data || {}
            // 已扫待确认：锁定当前码，停止换码
            // ★ 2026-10-29 实测修正：超星不同分支/版本对「已扫待手机确认」
            //   返回的 type 编码不一致，线上实测到的是 type=3（不是 4）。
            //   证据：手机扫完后页面已显示头像 + 「请在学习通上点击确认以登录」，
            //   而 /getauthstatus/v2 连续多次回 {status:false, type:3}。
            //   原来只认 type===4，导致：识别不到已扫 → 继续每 60 秒换码 →
            //   把正在等确认的码换掉 → 手机点确认时对应旧码已失效 → 永远进不去。
            //   现在 3 和 4 都当作「已扫待确认」，出现 nickname 也认。
            const PENDING_TYPES = [3, 4];
            if (!d.status && (PENDING_TYPES.includes(Number(d.type)) || d.nickname)) {
              sawPending = true
              if (!global.__cxPendingLogged) {
                global.__cxPendingLogged = true
                logger.log('LOGIN', 'INFO', '手机已扫码，等待手机端确认（已锁定当前码，不再换码）', {
                  uuid: u.slice(0, 8), nickname: d.nickname || '', type: d.type
                })
              }
            }
            if (u === sess.uuid) {
              curType = d.type
              curMes = d.mes ? String(d.mes).slice(0, 40) : ''
              curNick = d.nickname || ''
              const now = Date.now()
              if (!global.__cxLastPollLog || now - global.__cxLastPollLog > 10000) {
                global.__cxLastPollLog = now
                /* type 含义速查（实测归纳）：
                     0/3/4 → 未确认（3、4 = 手机已扫，等确认；4 不一定出现）
                     2     → 该代会话失效
                     status=true → 手机已确认，正在跳转 */
                const typeMeaning = d.status ? 'confirmed'
                  : Number(d.type) === 2 ? 'session-expired'
                  : [3, 4].includes(Number(d.type)) ? 'scanned-wait-confirm'
                  : 'waiting-scan'
                logger.log('LOGIN', 'INFO', '扫码状态轮询(页面内)', {
                  uuid: u.slice(0, 8), status: !!d.status, type: d.type,
                  meaning: typeMeaning, nickname: curNick || '', mes: curMes
                })
              }
            }
            if (d.status) { scanned = { data: d }; break }
          }
          if (scanned) {
            logger.log('LOGIN', 'INFO', '引擎侧确认扫码状态（手机已确认，浏览器正在跳转）', {
              nickname: scanned.data.nickname || '', type: scanned.data.type
            })
            ok = true
            break
          }

          /* ★ 实测（2026-10-27 本机 Edge 两轮验证）：
             /refreshQRCode 接口换出来的码，服务器 10 秒就判 type=2「已失效」，
             连换几次会进入死循环（新码也立刻失效）。
             结论：这个接口换的码不可靠。
             正确做法是**整页重载登录页**，让服务器下发全新合法会话。
             代价是会重建 JSESSIONID，但这是唯一稳定可靠的方式。 */
          if (Number(curType) === 2) {
            const now2 = Date.now()
            if (!global.__cxExpiredRefreshAt || now2 - global.__cxExpiredRefreshAt > 15000) {
              global.__cxExpiredRefreshAt = now2
              logger.log('LOGIN', 'INFO', '当前码已失效（type=2），整页重载登录页换新会话', { mes: curMes })
              try {
                await adapter.navigate(L.loginUrl)
                await sleep(2000)
                try { await adapter.clearExtraHeaders() } catch (_) { /* ignore */ }
                await switchToQrMode(adapter, L)
                await sleep(1200)
                await patchQrImage()
                sawPending = false
                global.__cxPendingLogged = false
                logger.log('LOGIN', 'INFO', '已重载登录页并生成新码（请重新扫码）')
              } catch (e) {
                logger.log('LOGIN', 'WARN', '重载登录页失败', { err: String((e && e.message) || e).slice(0, 80) })
              }
            }
          }
        }
      } catch (e) {
        if (!global.__cxQrSessErr) {
          global.__cxQrSessErr = true
          logger.log('LOGIN', 'ERROR', '引擎侧扫码状态轮询异常（此前被静默吞掉）', {
            err: String((e && e.message) || e).slice(0, 200)
          })
        }
      }

      /* ★ 换码放在状态查询**之后**：若刚看到「已扫待确认」，这次绝不能换码，
         否则就是把主人正在确认的那一代作废（实测症状：头像/昵称闪几秒就没）。 */
      if (!sawPending && Date.now() - lastReload > L.reloadEveryMs) {
        logger.log('LOGIN', 'INFO', '二维码可能已过期，用页面自身逻辑换新码（保持会话）');
        try {
          /* ★ 同样不用 /refreshQRCode（实测换出的码 10 秒即失效），
             统一走整页重载，保证会话合法。 */
          await adapter.navigate(L.loginUrl)
          await sleep(2000)
          try { await adapter.clearExtraHeaders() } catch (_) { /* ignore */ }
          await switchToQrMode(adapter, L)
          logger.log('LOGIN', 'INFO', '已整页重载登录页换新码（请扫最新截图）')
        } catch (_) { /* ignore */ }
        await sleep(600)
        await patchQrImage()
        lastReload = Date.now();
      }
      // 页面图片若被重置（站点自己刷新 uuid），重新渲染一次
      if (!sawPending && await qrImageLooksEmpty(adapter)) await patchQrImage()
      /* ★ 不要每轮都重写截图文件：文件 mtime 每 2.5 秒变一次，
         外部看图工具会不停重新加载 → 主人看到「二维码一直在闪」。
         改为：只有二维码 uuid 换代（或首次）时才落盘一次。 */
      try {
        const curSess = await readQrSession(adapter)
        const curUuid = curSess ? curSess.uuid : ''
        if (curUuid && curUuid !== global.__cxLastShotUuid) {
          global.__cxLastShotUuid = curUuid
          await adapter.screenshot(shotPath)
          logger.log('LOGIN', 'INFO', '已更新二维码截图（换代）', { uuid: curUuid.slice(0, 8) })
        }
      } catch (_) { /* 截图失败不中断轮询 */ }
    }
    if (!ok) {
      logger.log('LOGIN', 'ERROR', '扫码超时。请重新执行登录流程，并在窗口期内完成手机确认', { screenshot: shotPath });
      writeResult({ ok: false, verified: false, reason: 'timeout', screenshot: shotPath });
      return { ok: false, reason: 'timeout', screenshot: shotPath };
    }

    // 3) 成功 → 回个人空间二次验证（真扫成功才允许写 verified）
    await adapter.navigate(L.homeUrl);
    await sleep(2500);
    let verifyUrl = await adapter.getCurrentUrl();
    if (!isLoginHost(verifyUrl)) {
      // 可能跳转慢，再给一次机会
      await sleep(3000);
      verifyUrl = await adapter.getCurrentUrl();
      if (!isLoginHost(verifyUrl)) {
        await adapter.screenshot(shotPath);
        logger.log('LOGIN', 'ERROR', '扫码后回到个人空间仍停留在登录页，判定验证失败', { url: String(verifyUrl).slice(0, 120) });
        writeResult({ ok: false, verified: false, reason: 'verify_failed', url: String(verifyUrl).slice(0, 200) });
        return { ok: false, reason: 'verify_failed', screenshot: shotPath };
      }
    }
    await adapter.screenshot(shotPath);
    writeResult({ ok: true, verified: true, already: false, url: String(verifyUrl).slice(0, 200), screenshot: shotPath });
    logger.log('LOGIN', 'INFO', L.ephemeral
      ? '登录成功并已验证（一次性模式：本次任务结束后登录态即销毁，下次需重新扫码）'
      : '登录成功并已验证，登录态已保存到 profile（后续任务自动复用）', {
      screenshot: shotPath, elapsedMs: Date.now() - started
    });
    return { ok: true, already: false, screenshot: shotPath };
  } finally {
    /* ★★ 一次性模式下**登录进程不关浏览器**。
       原因（实测回归）：超星登录成功后，UID/_uid/uf/vc3 这些是**会话级 cookie**，
       只活在浏览器进程内存里，不会立刻落盘。之前的版本登录成功后立刻
       shutdownBrowser()，等于把刚拿到的登录态当场销毁 —— 于是
       --list-courses / 看课再开新浏览器时又回到登录页（fid=5521 重定向），
       表现就是「登录成功了但读不到课程」。
       现在保持浏览器存活，让读课程/看课附着到同一个实例；
       销毁交给「看课任务结束时」的 purgeEphemeralProfile()。 */
    logger.log('LOGIN', 'INFO', '登录流程结束，浏览器保持运行（供读课程/看课复用同一会话）');
  }
}

/**
 * 一次性登录 profile 管理。
 * 目标：登录态「用一次少一次」——登录之后的看课任务跑在专属临时 profile 里，
 * 看课任务结束（正常/异常）就整目录删除，下次必须重新扫码。
 *
 * 设计要点：
 *   - 用**固定目录**（不是 mkdtemp 随机名），因为「扫码登录」和「开始看课」是两个
 *     独立进程，必须共享同一个 profile 才能复用登录态。
 *   - 生命周期由宿主控制：点「开始登录」时创建，看课任务结束时删除。
 *   - 只有 login.ephemeral 为真时生效；关闭时沿用 cx-learn/browser-profile 长期复用。
 */
const EPHEMERAL_ROOT = path.join(os.tmpdir(), 'cx-learn-ephemeral');
const EPHEMERAL_DIR = path.join(EPHEMERAL_ROOT, 'session');

/** 返回一次性 profile 目录（不存在则创建）。 */
function ensureEphemeralProfile() {
  fs.mkdirSync(EPHEMERAL_ROOT, { recursive: true });
  // 上一次残留先清掉，保证是干净的新会话
  try { fs.rmSync(EPHEMERAL_DIR, { recursive: true, force: true }) } catch (_) { /* ignore */ }
  fs.mkdirSync(EPHEMERAL_DIR, { recursive: true });
  logger.log('LOGIN', 'INFO', '一次性登录模式：使用临时 profile，看课结束后即删除', { dir: EPHEMERAL_DIR });
  return EPHEMERAL_DIR;
}

/** 删除一次性 profile（幂等）。登录态彻底销毁，下次必须重新扫码。 */
function cleanupEphemeralProfile() {
  try {
    fs.rmSync(EPHEMERAL_DIR, { recursive: true, force: true });
    logger.log('LOGIN', 'INFO', '临时 profile 已删除（登录态不再留存，下次需重新扫码）', { dir: EPHEMERAL_DIR });
  } catch (e) {
    logger.log('LOGIN', 'WARN', '临时 profile 删除失败，请手动清理', { dir: EPHEMERAL_DIR, err: String((e && e.message) || e).slice(0, 120) });
  }
}

/** 清理历史残留（异常退出时留下的）。 */
function sweepEphemeralProfiles() {
  try {
    if (fs.existsSync(EPHEMERAL_DIR)) {
      fs.rmSync(EPHEMERAL_DIR, { recursive: true, force: true });
      logger.log('LOGIN', 'INFO', '清理上次残留的临时 profile', { dir: EPHEMERAL_DIR });
    }
  } catch (_) { /* ignore */ }
}

/**
 * 主动关闭本次任务启动的浏览器，避免进程一直占着 9223 端口和 profile 目录
 * （主人反馈「登录界面明显卡了，占着茅坑不拉屎」就是这个）。
 * 只关自己启动的实例：附着到外部已存在 CDP 时不碰。
 */
async function shutdownBrowser(adapter) {
  if (!adapter || adapter.engine !== 'cdp') return;
  const fn = adapter.shutdown
  if (typeof fn === 'function') {
    try { await fn(); return } catch (e) { logger.log('LOGOUT', 'WARN', '浏览器关闭失败', { err: String((e && e.message) || e).slice(0, 120) }) }
  }
  // 兜底：直接用 CDP 让浏览器自己退出
  try {
    const ver = await fetch('http://' + CONFIG.cdp.host + ':' + CONFIG.cdp.port + '/json/version')
    if (ver.ok) {
      const info = await ver.json()
      const ws = info.webSocketDebuggerUrl
      if (ws && typeof WebSocket === 'function') {
        await new Promise((resolve) => {
          const s = new WebSocket(ws)
          const t = setTimeout(() => { try { s.close() } catch (_) {} ; resolve() }, 3000)
          s.onopen = () => { try { s.send(JSON.stringify({ id: 1, method: 'Browser.close' })) } catch (_) {} ; setTimeout(() => { clearTimeout(t); try { s.close() } catch (_) {} ; resolve() }, 400) }
          s.onerror = () => { clearTimeout(t); resolve() }
          s.onclose = () => { clearTimeout(t); resolve() }
        })
        logger.log('LOGOUT', 'INFO', '已请求浏览器退出（释放 9223 端口）')
      }
    }
  } catch (_) { /* 浏览器已不在：无需处理 */ }
}

/**
 * 从登录页读取二维码 uuid（隐藏域 #uuid）。
 * @returns {Promise<string>} uuid，读不到返回 ''
 */
async function readQrUuid(adapter) {
  const frames = await adapter.getFrameDocuments()
  const expr = `(() => {
    const el = document.getElementById('uuid');
    if (!el) return '';
    const v = String(el.value || '').trim();
    return /^[a-f0-9]{16,64}$/i.test(v) ? v : '';
  })()`
  for (const f of frames) {
    try {
      const v = await adapter.evalInFrame(f.frameId, expr)
      if (v && typeof v === 'string' && v.length >= 16) return v
    } catch (_) { /* 换下一个 frame */ }
  }
  return ''
}

/**
 * 读页面里「当前有效」的 uuid + enc（隐藏域 #uuid / #enc）。
 * 站点刷新二维码时会在 refreshQRCode() 里同时更新这两个值，
 * 引擎侧轮询必须每次重读，扫的图和查的状态才对应得上。
 */
async function readQrSession(adapter) {
  const frames = await adapter.getFrameDocuments()
  const expr = `(() => {
    const u = (document.getElementById('uuid') || {}).value || '';
    const e = (document.getElementById('enc') || {}).value || '';
    return /^[a-f0-9]{16,64}$/i.test(u) ? (u + '\\u0000' + e) : '';
  })()`
  for (const f of frames) {
    try {
      const v = await adapter.evalInFrame(f.frameId, expr)
      if (v && typeof v === 'string' && v.length >= 17) {
        const i = v.indexOf('\u0000')
        return { uuid: v.slice(0, i), enc: i > 0 ? v.slice(i + 1) : '' }
      }
    } catch (_) { /* 换下一个 frame */ }
  }
  return null
}

/**
 * 引擎侧直接查扫码状态（与页面 JS 的 /getauthstatus/v2 同一接口）。
 *
 * 为什么必须自己查：手机确认后是页面里的 JS 拿到 status 才做跳转，
 * 一旦引擎 60 秒 navigate 刷新把页面重载了，uuid/enc 全换新的，
 * 手机扫的旧码对应的轮询已经不存在了 —— 浏览器侧就「永远没反应」。
 * 引擎主动查就能绕开这一点：读到 status 立刻走成功分支。
 * 只带页面上公开的 uuid/enc，不接触任何账号凭据。
 */
async function fetchQrAuthStatus(uuid, enc) {
  const url = 'https://passport2.chaoxing.com/getauthstatus/v2'
  const body = 'enc=' + encodeURIComponent(enc || '') + '&uuid=' + encodeURIComponent(uuid) +
    '&doubleFactorLogin=&forbidotherlogin='
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Origin': 'https://passport2.chaoxing.com',
        'Referer': 'https://passport2.chaoxing.com/login',
      },
      body,
      signal: AbortSignal.timeout(15000),
    })
    if (!res.ok) {
      logger.log('LOGIN', 'WARN', '扫码状态查询 HTTP 失败', { uuid: String(uuid).slice(0, 8), status: res.status })
      return { ok: false, reason: 'http ' + res.status }
    }
    const data = await res.json()
    const out = {
      ok: true,
      data,
      scanned: !!(data && data.status),
      type: data && data.type,
      nickname: data && data.nickname,
    }
    // 关键节点都打日志：之前静默失败导致「扫了没反应」无法定位
    if (data && data.status) {
      logger.log('LOGIN', 'INFO', '扫码状态=已确认（引擎侧查到）', { uuid: String(uuid).slice(0, 8), nickname: out.nickname || '' })
    } else if (data && data.type === 2) {
      logger.log('LOGIN', 'INFO', '扫码状态=该代二维码会话已失效（服务器换新 uuid 了）', { uuid: String(uuid).slice(0, 8) })
    } else if (data && (Number(data.type) === 3 || Number(data.type) === 4)) {
      /* ★ 2026-10-29：3 和 4 都是「已扫待手机确认」。
         线上实测到的是 3（页面已显示头像+请确认），旧代码只认 4，
         导致这条日志从来不出现，排查时完全看不到「其实已经扫了」。 */
      logger.log('LOGIN', 'INFO', '扫码状态=已扫待手机确认', { uuid: String(uuid).slice(0, 8), nickname: out.nickname || '', type: data.type })
    }
    return out
  } catch (e) {
    logger.log('LOGIN', 'WARN', '扫码状态查询异常（引擎侧轮询暂停本代）', {
      uuid: String(uuid).slice(0, 8), err: String((e && e.message) || e).slice(0, 160)
    })
    return { ok: false, reason: String((e && e.message) || e).slice(0, 120) }
  }
}

/* ============================================================================
 * 【已删除】forceRenderQrInPage()
 *
 * 历史教训（2026-10-27，主人亲测发现）：
 *   这个函数用 fetch + URL.createObjectURL(blob) 把二维码换成 blob: 地址注入
 *   页面。后果是二维码**中间显示「图片加载失败」破图图标** ——
 *   blob URL 会随上下文重建而失效，浏览器就渲染成破图。
 *   主人明确表示：看到破图就不会去扫。
 *
 * 正确做法（现行）：完全使用站点原生 <img id="quickCode"> 的
 *   /createqr?uuid=... 地址，不做任何 src 替换。
 *   原生图加载失败的真因是系统代理（见 extraArgs 里的 --no-proxy-server），
 *   不是在图片本身上做手脚能解决的。
 * ==========================================================================*/


/**
 * 调页面自带的 refreshQRCode() 换新码（保持同一页面会话，不作废 JSESSIONID）。
 * 返回是否成功换到新 uuid。
 */
async function refreshQrInPage(adapter) {
  const frames = await adapter.getFrameDocuments()
  /* ★ 实测（2026-10-27）：页面里的 refreshQRCode 定义在主世界，
     isolated world 里 typeof 读不到（会走到 fetch 分支）。
     所以优先直接调接口 /refreshQRCode，并兼容两种返回结构。 */
  const expr = `(async () => {
    const uEl = document.getElementById('uuid');
    const eEl = document.getElementById('enc');
    const before = uEl ? String(uEl.value || '') : '';
    try {
      const r = await fetch('/refreshQRCode', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: 'fid=-1',
      });
      let d = null;
      try { d = await r.json(); } catch (_) { d = null; }
      if (d && (d.uuid || (d.data && d.data.uuid))) {
        const nid = d.uuid || d.data.uuid;
        const nenc = d.enc || (d.data && d.data.enc) || '';
        if (uEl) uEl.value = nid;
        if (eEl && nenc) eEl.value = nenc;
        return true;
      }
      // 接口不通时退回 GET（部分版本只认 GET）
      const r2 = await fetch('/refreshQRCode', { credentials: 'include' });
      let d2 = null;
      try { d2 = await r2.json(); } catch (_) { d2 = null; }
      if (d2 && (d2.uuid || (d2.data && d2.data.uuid))) {
        const nid = d2.uuid || d2.data.uuid;
        const nenc = d2.enc || (d2.data && d2.data.enc) || '';
        if (uEl) uEl.value = nid;
        if (eEl && nenc) eEl.value = nenc;
        return true;
      }
    } catch (err) { return false }
    const after = uEl ? String(uEl.value || '') : '';
    return !!(after && after !== before);
  })()`
  for (const f of frames) {
    try {
      const v = await adapter.evalInFrame(f.frameId, expr)
      if (v === true) return true
    } catch (_) { /* 换下一个 frame */ }
  }
  return false
}

/**
 * 在**页面内部**查扫码状态（同源 fetch，自动带页面自己的 JSESSIONID）。
 *
 * ★ 为什么必须走页面内：getauthstatus/v2 会校验「会话归属」——
 *   二维码 uuid 是在页面会话（JSESSIONID）里创建的。
 *   引擎用 Node 直接 POST 时没有该 cookie，服务器一律回
 *   type:2「会话已失效，请刷新页面重试」（实测连续多次都是这个答案），
 *   与「有没有人扫码」毫无关系。之前据此判断，等于永远是未扫描。
 *
 * 页面内 fetch 带 cookie、同源，服务器才会正常返回
 *   { status:false, type:0/4 } 未扫/已扫待确认，或 { status:true } 已确认。
 */
async function fetchQrAuthStatusInPage(adapter, uuid, enc) {
  const frames = await adapter.getFrameDocuments()
  const expr = `(async () => {
    const uuid = ${JSON.stringify(String(uuid || ''))};
    const enc = ${JSON.stringify(String(enc || ''))};
    if (!uuid) return JSON.stringify({ ok: false, reason: 'no-uuid' });
    try {
      const body = 'enc=' + encodeURIComponent(enc) + '&uuid=' + encodeURIComponent(uuid) +
        '&doubleFactorLogin=&forbidotherlogin=';
      const res = await fetch('/getauthstatus/v2', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body,
      });
      if (!res.ok) return JSON.stringify({ ok: false, reason: 'http ' + res.status });
      const data = await res.json();
      return JSON.stringify({ ok: true, data });
    } catch (e) {
      return JSON.stringify({ ok: false, reason: String(e && e.message || e) });
    }
  })()`
  for (const f of frames) {
    try {
      const raw = await adapter.evalInFrame(f.frameId, expr)
      if (!raw || typeof raw !== 'string') continue
      let parsed
      try { parsed = JSON.parse(raw) } catch { continue }
      if (parsed && parsed.ok) {
        const d = parsed.data || {}
        return {
          ok: true, data: d,
          scanned: !!d.status,
          type: d.type,
          nickname: d.nickname,
        }
      }
    } catch (_) { /* 换下一个 frame */ }
  }
  return { ok: false, reason: 'no-frame-ok' }
}

/**
 * 由引擎侧直接下载二维码图片，返回 dataURL。
 *
 * 为什么不用浏览器加载：Chrome headless 对新版超星登录页的 `/createqr` 请求
 * 报 `net::ERR_INVALID_ARGUMENT`（实测 Chrome for Testing 158），图片永远是
 * 0x0 破图；但同样的 URL 用 Node HTTP 请求能拿到正常的 270x270 PNG。
 *
 * 请求头按浏览器口径补齐（UA / Referer / Accept），不带任何账号凭据。
 * @returns {Promise<string>} `data:image/png;base64,...`，失败返回 ''
 */
async function fetchQrDataUrl(uuid) {
  const url = 'https://passport2.chaoxing.com/createqr?uuid=' + encodeURIComponent(uuid) + '&fid=-1'
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36',
        Referer: 'https://passport2.chaoxing.com/login',
        Accept: 'image/avif,image/webp,image/png,image/svg+xml,image/*,*/*;q=0.8',
      },
      signal: AbortSignal.timeout(20000),
    })
    if (!res.ok) {
      logger.log('LOGIN', 'WARN', '二维码下载 HTTP 失败', { status: res.status })
      return ''
    }
    const buf = Buffer.from(await res.arrayBuffer())
    // 只认真正的图片：PNG(89504e47) / JPEG(ffd8ff) / GIF(474946)
    const isPng = buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47
    const isJpg = buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff
    const isGif = buf.length > 4 && buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46
    if (!isPng && !isJpg && !isGif) {
      logger.log('LOGIN', 'WARN', '二维码下载返回的不是图片', { bytes: buf.length, head: buf.slice(0, 8).toString('hex') })
      return ''
    }
    const mime = isPng ? 'image/png' : isJpg ? 'image/jpeg' : 'image/gif'
    logger.log('LOGIN', 'INFO', '二维码已下载', { bytes: buf.length, mime })
    // 同步存一份原始二维码图，方便直接展示/扫描（截图里的 200px 有时太小）
    try {
      const shotDir = process.env.CX_LOGIN_SHOT_DIR
      if (shotDir) fs.writeFileSync(path.join(shotDir, 'qr.png'), buf)
    } catch { /* ignore */ }
    return 'data:' + mime + ';base64,' + buf.toString('base64')
  } catch (e) {
    logger.log('LOGIN', 'WARN', '二维码下载异常', { err: String((e && e.message) || e).slice(0, 140) })
    return ''
  }
}

/**
 * 把 dataURL 写回页面的 #quickCode，并按二维码原尺寸显示。
 * 只改图片显示，不触碰任何登录逻辑。
 */
async function applyQrDataUrl(adapter, dataUrl) {
  const frames = await adapter.getFrameDocuments()
  const expr = `(() => {
    const img = document.getElementById('quickCode');
    if (!img) return false;
    img.src = ${JSON.stringify(dataUrl)};
    img.removeAttribute('width');
    img.removeAttribute('height');
    img.style.width = '200px';
    img.style.height = '200px';
    img.style.display = 'block';
    img.style.margin = '0 auto';
    img.style.background = '#fff';
    // 站点原有的失效遮罩别挡住码
    const box = img.closest ? img.closest('.ecode-box') : null;
    if (box) {
      const dis = box.querySelector('.ewmDisable');
      if (dis) dis.style.display = 'none';
    }
    return true;
  })()`
  for (const f of frames) {
    try {
      const ok = await adapter.evalInFrame(f.frameId, expr)
      if (ok === true) return true
    } catch (_) { /* 换下一个 frame */ }
  }
  return false
}

/** 页面上刚刚注入的二维码是否又被站点重置成空图。 */
async function qrImageLooksEmpty(adapter) {
  const frames = await adapter.getFrameDocuments()
  const expr = `(() => {
    const img = document.getElementById('quickCode');
    if (!img) return true;
    const src = String(img.src || '');
    if (src.startsWith('data:image/')) return img.naturalWidth > 0 ? false : true;
    return img.naturalWidth === 0;
  })()`
  for (const f of frames) {
    try {
      const v = await adapter.evalInFrame(f.frameId, expr)
      if (typeof v === 'boolean') return v
    } catch (_) { /* 换下一个 frame */ }
  }
  return false
}

/**
 * 把登录页从「账号密码表单」切换到「扫码登录」。
 *
 * 超星 passport2 登录页默认渲染账号密码表单，二维码区域要点击
 * 「使用学习通APP扫码登录」入口才会加载（实测：不点就截不到码）。
 * 该操作只切 UI，不填写任何凭据、不提交任何表单。
 * @returns {Promise<boolean>} 是否成功切到扫码视图
 */
async function switchToQrMode(adapter, L) {
  const frames = await adapter.getFrameDocuments();
  const expr = `(() => {
    const norm = (s) => String(s || '').replace(/\\s+/g, '');
    const want = ['使用学习通APP扫码登录', '扫码登录', '学习通APP扫码登录', 'APP扫码登录'];
    const clickable = (el) => {
      const r = el.getBoundingClientRect();
      const st = getComputedStyle(el);
      return r.width > 10 && r.height > 8 && st.visibility !== 'hidden' && st.display !== 'none';
    };
    // 1) 精确文本命中（最短匹配优先，避免点到外层容器）
    let best = null;
    document.querySelectorAll('a,div,span,li,button,p,i').forEach((el) => {
      if (!clickable(el)) return;
      const t = norm(el.innerText);
      if (!t || t.length > 40) return;
      if (!want.some((w) => t === norm(w))) return;
      if (!best || t.length < norm(best.el.innerText).length) best = { el, t };
    });
    if (best) { best.el.click(); return { ok: true, by: 'exact', text: best.t }; }

    // 2) 包含关键词的兜底
    let loose = null;
    document.querySelectorAll('a,div,span,li,button,i').forEach((el) => {
      if (!clickable(el)) return;
      const t = norm(el.innerText);
      if (!t || t.length > 30) return;
      if (!/扫码/.test(t)) return;
      if (!loose || t.length < norm(loose.el.innerText).length) loose = { el, t };
    });
    if (loose) { loose.el.click(); return { ok: true, by: 'loose', text: loose.t }; }

    // 3) 找二维码 tab 类的元素（icon/class 含 qr）
    const cand = document.querySelector('.qr-tab, [class*="qrTab"], [class*="scan-login"], [class*="scanLogin"]');
    if (cand && clickable(cand)) { cand.click(); return { ok: true, by: 'class' }; }

    return { ok: false, reason: 'no-qr-entry' };
  })()`

  for (const f of frames) {
    try {
      const r = await adapter.evalInFrame(f.frameId, expr)
      if (r && r.ok) {
        logger.log('LOGIN', 'INFO', '已点击扫码登录入口', { by: r.by, text: r.text || '', frameId: f.frameId })
        await sleep(1500)
        return true
      }
    } catch (_) { /* 换下一个 frame */ }
  }
  return false
}

/**
 * 轻量登录态校验（每次启动任务前调用）。
 * 只访问个人空间看是否被踢回登录页，不开二维码、不截图轮询、不打扰用户。
 * 目的：让「登录态早就失效」在任务开始前就暴露，而不是跑到一半 LOGIN_REQUIRED。
 * @returns {{ok:boolean, loggedIn:boolean, url?:string, reason?:string}}
 */
async function checkLoginState(overrides) {
  const cfg = mergeConfig(CONFIG, overrides);
  logger.configure(cfg.log);
  const L = cfg.login;
  const isLoginHost = (u) => new RegExp(L.successUrlPattern, 'i').test(String(u || '')) && !/passport[2.]|login\./i.test(String(u || ''));
  /* 一次性模式下只检查当前会话的临时 profile：没有临时 profile 就等于没登录，
     直接返回 needLogin，不要去碰长期 profile（那是旧数据，不能用来"装作已登录"）。 */
  if (L.ephemeral) {
    if (!fs.existsSync(EPHEMERAL_DIR)) {
      logger.log('LOGIN', 'INFO', '一次性登录模式：当前没有有效会话，需要重新扫码');
      return { ok: true, loggedIn: false, url: '', reason: 'no_ephemeral_session' };
    }
    cfg.chromium.profileDir = EPHEMERAL_DIR;
  }
  let adapter = null;
  try {
    adapter = createCdpAdapter(cfg);
    await adapter.ensureBrowser();
    await adapter.navigate(L.homeUrl);
    await sleep(2000);
    const url = await adapter.getCurrentUrl();
    const loggedIn = isLoginHost(url);
    logger.log('LOGIN', 'INFO', loggedIn ? '登录态校验通过' : '登录态已失效，需要重新扫码', { url: String(url || '').slice(0, 120) });
    return { ok: true, loggedIn, url: String(url || '') };
  } catch (e) {
    return { ok: false, loggedIn: false, reason: String((e && e.message) || e).slice(0, 200) };
  } finally {
    // 预检不许留浏览器进程：检查完立刻关掉，避免「占着茅坑」。
    try { await shutdownBrowser(adapter); } catch (_) { /* ignore */ }
  }
}

/* ============================================================================
 * 进程退出守卫：任何退出路径（正常/异常/SIGTERM/SIGINT）都要收掉浏览器，
 * 否则 headless Chrome 会一直占着 9223 端口和 profile 目录（"占着茅坑"）。
 * ==========================================================================*/
let _guardInstalled = false;
let _activeAdapter = null;
function installExitGuard() {
  if (_guardInstalled) return;
  _guardInstalled = true;
  const bye = (code) => {
    try {
      if (_activeAdapter && typeof _activeAdapter.shutdown === 'function') {
        // 同步触发 Browser.close；进程即将退出，不等 HTTP 往返完成
        _activeAdapter.shutdown().catch(() => {});
      }
    } catch (_) { /* ignore */ }
    setTimeout(() => process.exit(code), 300);
  };
  process.on('SIGTERM', () => bye(143));
  process.on('SIGINT', () => bye(130));
}
installExitGuard();

/* ============================================================================
 * 第 8 节 · DSH 导出 / CLI / MCP stdio 工具注册
 * ----------------------------------------------------------------------------
 * (a) 后台任务：`node chaoxing-autolearn.js --mode=continue_chapters --max-sections=10`
 * (b) 模块：   const { run } = require('./chaoxing-autolearn.js'); await run({...})
 * (c) DSH 工具：`node chaoxing-autolearn.js --serve-mcp` 启动零依赖 MCP stdio server；
 *     经 DSH 官方 mcp-bundle 机制注册后，Agent 以 mcp__cx__cx_learn 调用（见文末指南 A）。
 * ==========================================================================*/
function serveMcp() {
  logger.setConsole((line) => console.error(line)); // stdout 专供 JSON-RPC 协议
  logger.configure(CONFIG.log);
  logger.info('MCP', 'cx-auto-learn MCP stdio server 启动，工具名: ' + CONFIG.mcp.toolName, { version: VERSION });
  let buf = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (d) => {
    buf += d;
    let idx;
    while ((idx = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, idx).trim();
      buf = buf.slice(idx + 1);
      if (line) handleMcpLine(line).catch((e) => logger.error('MCP', '处理失败: ' + e.message));
    }
  });
  process.stdin.on('end', () => process.exit(0));

  async function handleMcpLine(line) {
    let msg; try { msg = JSON.parse(line); } catch (_) { return; }
    if (msg.method === 'initialize') {
      reply(msg.id, {
        protocolVersion: (msg.params && msg.params.protocolVersion) || '2024-11-05',
        capabilities: { tools: {} },
        serverInfo: { name: CONFIG.mcp.serverName, version: VERSION }
      });
    } else if (/^notifications\//.test(msg.method || '')) {
      /* 通知无需应答 */
    } else if (msg.method === 'tools/list') {
      reply(msg.id, {
        tools: [{
          name: CONFIG.mcp.toolName,
          title: '学习通视频学习推进',
          description: '驱动 DSH 侧 Chromium（CDP）自动完成学习通课程视频：P0 恢复播放/关弹窗、P2 弹题作答、P1 切节、P3 跳过已完成、P4 章节模式与上限。返回结构化结果。检测到人脸/验证码立即停止。',
          inputSchema: {
            type: 'object',
            properties: {
              mode: { type: 'string', enum: ['current_chapter', 'continue_chapters'], description: 'P4 模式' },
              maxSections: { type: 'integer', minimum: 1, description: '最多完整看完多少节' },
              courseUrl: { type: 'string', description: '课程学习页 URL；缺省沿用浏览器当前页' }
            }
          }
        }, {
          name: 'cx_login',
          title: '学习通扫码登录（无头）',
          description: '打开登录页二维码并周期截图（复用 profile 登录态，已有登录态直接返回）。用户在手机学习通 App 扫截图里的码即可；超时自动刷新二维码。不接触账密、不自动填表。',
          inputSchema: {
            type: 'object',
            properties: {
              timeoutSec: { type: 'integer', minimum: 30, description: '扫码等待窗口秒数，默认 300' }
            }
          }
        }]
      });
    } else if (msg.method === 'tools/call') {
      const a = (msg.params && msg.params.arguments) || {};
      if (msg.params && msg.params.name === 'cx_login') {
        try {
          const ov = a.timeoutSec ? { login: { timeoutMs: Number(a.timeoutSec) * 1000 } } : {};
          const r = await runLogin(ov);
          reply(msg.id, { content: [{ type: 'text', text: JSON.stringify(r) }] });
        } catch (e) {
          reply(msg.id, { content: [{ type: 'text', text: 'ERROR: ' + e.message }], isError: true });
        }
        return;
      }
      const overrides = {};
      if (a.mode) overrides.mode = String(a.mode);
      if (a.maxSections) overrides.maxSections = Number(a.maxSections);
      if (a.courseUrl) overrides.course = { url: String(a.courseUrl) };
      try {
        const r = await run(overrides);
        reply(msg.id, { content: [{ type: 'text', text: JSON.stringify(r) }] });
      } catch (e) {
        reply(msg.id, { content: [{ type: 'text', text: 'ERROR: ' + e.message }], isError: true });
      }
    } else if (msg.id !== undefined) {
      reply(msg.id, { error: { code: -32601, message: 'method not found: ' + msg.method } });
    }
  }
  function reply(id, result) {
    process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, result }) + '\n');
  }
}

function parseArgs(argv) {
  const o = {};
  for (const a of argv) {
    const m = /^--([a-zA-Z][a-zA-Z0-9-]*)(?:=(.*))?$/.exec(a);
    if (m) o[m[1]] = m[2] === undefined ? true : m[2];
  }
  return o;
}

/** 自测：Mock 适配器驱动状态机，覆盖 P0–P4 与两条致命停止路径（无需浏览器）。 */
async function selfTest() {
  const fails = [];
  /* 旧流程用例在 Mock 中显式开启 ai，仅用于覆盖状态机；宿主入口永远强制 CX_QUIZ_MODE=skip。 */
  process.env.CX_QUIZ_MODE = 'ai';
  const assert = (cond, name) => {
    if (cond) console.log('  ✓ ' + name);
    else { console.log('  ✗ ' + name); fails.push(name); }
  };
  const overrides = {
    mode: 'continue_chapters',
    maxSections: 2,
    course: { url: 'https://mooc1.chaoxing.com/mycourse/studentstudy?courseId=mock&clazzid=1&enc=mock' },
    safety: { maxLoadRetries: 2, maxNoVideoWaitTicks: 2, maxRuntimeMs: 60000 },
    humanize: { clickDelayMs: [1, 2], sectionCooldownMs: [1, 2], quizThinkMs: [1, 2], longPauseEveryOps: [3, 4], longPauseMs: [1, 2], pollMs: [1, 2] }
  };

  console.log('== 自测 1/3：主流程（P0 恢复播放 / P1 切节 / P2 弹题 / P3 跳过 / P4 上限）==');
  const mock = createMockAdapter({});
  const r = await run(overrides, { adapter: mock });
  assert(r.ok === true, '正常结束标记 ok=true');
  assert(r.stopReason === 'max_sections_reached', 'P4 停止原因 max_sections_reached（实际 ' + r.stopReason + '）');
  assert(r.sectionsCompleted === 2, '完整看完 2 节（实际 ' + r.sectionsCompleted + '）');
  assert(r.quizzesAnswered === 1, 'P2 弹题作答 1 次（实际 ' + r.quizzesAnswered + '）');
  assert(r.sectionsSkipped === 1, 'P3 跳过无视频任务点 1 节（实际 ' + r.sectionsSkipped + '）');
  assert(!mock._S.clicks.some((c) => c.kind === 'tocItem' && c.arg === 0), 'P3 未重进已完成节 1.1');
  assert(!mock._S.clicks.some((c) => c.kind === 'tocItem' && c.arg === 5), 'P4 达上限后未进入 2.2');
  assert(mock._S.clicks.some((c) => c.kind === 'videoToggle'), 'P0 存在恢复播放点击');
  assert(mock._S.muted === true, '静音策略生效');
  assert(Array.isArray(r.logs) && r.logs.length > 0, '结构化日志已返回');

  console.log('== 自测 2/3：人脸/验证码特征 → 立即停止 ==');
  const mock2 = createMockAdapter({ humanAt: 2 });
  const r2 = await run(overrides, { adapter: mock2 });
  assert(r2.stopReason === 'HUMAN_VERIFICATION', '停止原因 HUMAN_VERIFICATION（实际 ' + r2.stopReason + '）');
  assert(r2.ok === false, '非正常结束 ok=false');
  assert(r2.logs.some((l) => String(l.message).indexOf('需要人工介入') >= 0), '日志包含 FATAL: 需要人工介入');

  console.log('== 自测 3/3：登录态失效 → 停止且不自动登录 ==');
  const mock3 = createMockAdapter({ loginInvalid: true });
  const r3 = await run(overrides, { adapter: mock3 });
  assert(r3.stopReason === 'LOGIN_REQUIRED', '停止原因 LOGIN_REQUIRED（实际 ' + r3.stopReason + '）');
  assert(r3.ok === false, '非正常结束 ok=false');
  assert(r3.logs.some((l) => String(l.message).indexOf('人工') >= 0), '日志提示人工重新登录');

  console.log('== 自测 4/4：答案字母解析 ==');
  assert(parseAnswerLetter('A', 4) === 0, '纯字母 A → 索引 0');
  assert(parseAnswerLetter('A. 1949年', 4) === 0, '带题面 A → 索引 0');
  assert(parseAnswerLetter('The answer is C', 4) === 2, '英文句式 → 取 C 而不是 T');
  assert(parseAnswerLetter('答案是 B', 4) === 1, '中文「答案是 B」→ 索引 1');
  assert(parseAnswerLetter('选 D', 4) === 3, '「选 D」→ 索引 3');
  assert(parseAnswerLetter('', 4) === -1, '空回复 → -1');
  assert(parseAnswerLetter('zzz', 4) === -1, '无字母 → -1');
  assert(parseAnswerLetter('E', 4) === -1, '越界字母 E → -1');

  console.log('== 自测 5/5：超星风控检测页识别 ==');
  const detectRe = new RegExp(CONFIG.detect.urlPattern, 'i');
  const isDetect = (u) => detectRe.test(String(u || ''));
  assert(isDetect('https://detect.chaoxing.com/api/monitor_temp?refer=http%3A%2F%2Fi.mooc.chaoxing.com'),
    'detect.chaoxing.com 命中');
  assert(isDetect('https://x.com/a?mes=%E5%A4%9A%E7%BB%88%E7%AB%AF%E7%99%BB%E5%BD%95'),
    '带 mes= 异常提示的 URL 命中');
  assert(!isDetect('https://mooc1.chaoxing.com/mycourse/studentstudy?courseId=1'),
    '正常课程页不命中');
  assert(!isDetect('https://passport2.chaoxing.com/login?newversion=true'),
    '登录页不命中');
  assert(!isDetect(''), '空 URL 不命中');

  console.log('== 自测 6/6：target 探活丢弃卡死页 ==');
  // 模拟：/json/list 里第一个 page 是检测页（应跳过），第二个是卡死页（探活失败，应丢弃）
  const listMock = [
    { id: 'DETECT1', type: 'page', url: 'https://detect.chaoxing.com/api/monitor_temp?mes=x' },
    { id: 'DEAD01', type: 'page', url: 'https://i.chaoxing.com/' },
    { id: 'GOOD01', type: 'page', url: 'https://mooc1.chaoxing.com/mycourse' }
  ];
  const closed = [];
  const probeResults = { DEAD01: false, GOOD01: true };
  const fakeAdapter = {
    _probeTarget: async (t) => probeResults[t.id] === true,
    _closeTargetQuietly: (id) => { closed.push(id); },
  };
  const picked = [];
  for (const t of listMock) {
    if (isDetect(t.url)) { fakeAdapter._closeTargetQuietly(t.id); continue; }
    if (await fakeAdapter._probeTarget(t)) { picked.push(t.id); break; }
    fakeAdapter._closeTargetQuietly(t.id);
  }
  assert(closed.indexOf('DETECT1') >= 0, '检测页 target 被关闭');
  assert(closed.indexOf('DEAD01') >= 0, '探活失败的卡死 target 被关闭');
  assert(picked.length === 1 && picked[0] === 'GOOD01', '选中健康的 GOOD01（实际 ' + picked.join(',') + '）');

  console.log('== 自测 7/7：章内「章节测验」入口识别 ==');
  const quizTabRe = new RegExp(SELECTORS.quizTabText.join('|'));
  const videoTabRe = new RegExp(SELECTORS.videoTabText.join('|'));
  assert(quizTabRe.test('章节测验'), '「章节测验」识别为测验入口');
  assert(quizTabRe.test('2章节测验'), '「2章节测验」识别为测验入口');
  assert(!quizTabRe.test('1视频'), '「1视频」不是测验入口');
  assert(videoTabRe.test('视频'), '「视频」识别为视频标签');
  assert(!videoTabRe.test('章节测验'), '「章节测验」不是视频标签');

  console.log('== 自测 8/8：完整课程目录 vs 章内子任务 ==');
  // 学习通两套目录：.posCatalog_select（85 项课程目录）vs .prev_ul li（2 项章内子任务）
  const tocSel = SELECTORS.tocItem[0].sel;
  assert(tocSel === '.posCatalog_select', '首选目录选择器为完整课程目录（实际 ' + tocSel + '）');
  assert(SELECTORS.tocUnfinishCountSel === 'input.jobUnfinishCount', '完成度依据 jobUnfinishCount');
  // jobUnfinishCount: value=0 → 已完成；value>0 → 未完成
  const doneByCount = (v) => { const n = parseInt(v, 10); return !isNaN(n) && n === 0; };
  assert(doneByCount('0'), 'jobUnfinishCount=0 → 判定已完成');
  assert(!doneByCount('1'), 'jobUnfinishCount=1 → 判定未完成');
  assert(!doneByCount('2'), 'jobUnfinishCount=2 → 判定未完成');
  // 章头识别：firstLayer + posCatalog_title
  const headerRe = new RegExp(SELECTORS.tocChapterClass.join('|'), 'i');
  assert(headerRe.test('posCatalog_select firstLayer'), 'firstLayer 识别为章头');
  assert(!headerRe.test('posCatalog_select posCatalog_active'), '普通节不算章头');

  console.log('== 自测 9/9：章节测验流程（Mock 端到端）==');
  const mockQ = createMockAdapter({ quizTabEnabled: true });
  const rq = await run({ mode: 'continue_chapters', maxSections: 1, humanize: { clickDelayMs: [1, 2], sectionCooldownMs: [1, 2], quizThinkMs: [1, 2], longPauseEveryOps: [3, 4], longPauseMs: [1, 2], pollMs: [1, 2] } }, { adapter: mockQ });
  assert(mockQ._S.clicks.some((c) => c.kind === 'quizTab'), '点击了章节测验标签');
  assert(mockQ._S.quizAnswered === true, '章节测验已提交作答');
  assert(mockQ._S.clicks.some((c) => c.kind === 'videoTab'), '答完后切回了视频标签');

  console.log('== 自测 10/10：目录 current / done 判定（真实站点实测坑）==');
  /* 坑 1：学习通所有目录节点 id 都是 "cur143114xxx" ⇒ 不能用 id 前缀判 current，
     否则 85 项全被判成当前节 → 永远在第一章打转。 */
  assert(!SELECTORS.tocCurrentClass.includes('cur'), 'current 判据不含裸 "cur"（会误命中所有 curXXXX id）');
  assert(SELECTORS.tocCurrentClass.includes('posCatalog_active'), 'current 判据含 posCatalog_active');
  /* 坑 2：完成标记是子 span 上的 icon_Completed，不是节点自身的 class。 */
  assert(SELECTORS.doneClass.includes('icon_Completed'), 'doneClass 含 icon_Completed');
  /* 坑 3：已完成的小节没有 jobUnfinishCount input；未完成的才有（value=待办数）。 */
  const sectionFullyDone = (done, unfinish) => done && !(typeof unfinish === 'number' && unfinish > 0);
  assert(sectionFullyDone(true, -1), 'done 且无待办数 → 整节完成');
  assert(sectionFullyDone(true, 0), 'done 且待办数=0 → 整节完成');
  assert(!sectionFullyDone(true, 2), 'done 但待办数=2 → 只部分完成，不能整节跳过');
  assert(!sectionFullyDone(false, 2), '未 done → 不能整节跳过');

  console.log('== 自测 11/11：作业提交确认框契约 ==');
  /* 坑 4：超星的 #workpop 确认框用 top.workPop() 渲染 ⇒ 出现在**顶层 frame**，
     作业 frame 里那个同名元素永远 display:none。 */
  const probeSrc = PAGE_PROBE_SRC;
  assert(probeSrc.indexOf("'workConfirm'") >= 0, '页面探针提供 workConfirm 查找项');
  assert(probeSrc.indexOf('getElementById(\'popok\')') >= 0, 'workConfirm 指向 #popok 确定按钮');
  assert(probeSrc.indexOf('getElementById(\'workpop\')') >= 0, 'workConfirm 先定位 #workpop 容器');

  /* 安全模式回归：题目只记录、不选项、不提交、不调用模型。
     ★ 2026-10-28 行为变更（主人要求）：遇到**章节测验**不再停机，
       而是跳过并切下一节继续看视频（skipChapterQuiz 默认 true）。
       所以这里断言的重点从「停止」改为：
         a) 绝不点题目选项/提交（核心安全要求，不能变）
         b) 计数 quizzesAnswered 必须为 0
         c) 允许的走向：跳过继续 或 仍停机 或 正常跑完（都算通过）
       用 safeMock 的 quiz 场景验证「跳过」路径确实被走到。 */
  /* ★ 2026-10-28 新增：风控重试策略的静态契约校验。
     主人要求：命中风控后等 30 秒再刷新，最多重试 2 次，仍失败才停，且日志写明原因。
     这里不真跑等待（30 秒会拖慢自测），只验证配置与代码路径存在且取值正确。 */
  console.log('== 自测 11b：风控重试策略契约 ==');
  assert(Number(CONFIG.detect.retryWaitMs) === 30000, '风控重试等待为 30 秒（实际 ' + CONFIG.detect.retryWaitMs + '）');
  assert(Number(CONFIG.detect.maxRetries) === 2, '风控最多重试 2 次（实际 ' + CONFIG.detect.maxRetries + '）');
  const engineSrc = fs.readFileSync(__filename, 'utf8');
  assert(engineSrc.indexOf('RISK_CONTROL') >= 0, '存在 RISK_CONTROL 阶段日志');
  assert(engineSrc.indexOf('风控重试已达上限，停止运行') >= 0, '重试用尽时有明确停止日志');
  assert(engineSrc.indexOf('播放中命中风控页') >= 0, '播放中也有风控检查（不只 navigate）');
  assert(engineSrc.indexOf('手机端学习通 App 完全退出登录') >= 0, '停止原因里写明了处理办法');

  console.log('== 自测 12/12：安全识别模式不答题不提交 ==');
  process.env.CX_QUIZ_MODE = 'skip';
  const safeMock = createMockAdapter({ quizTabEnabled: true });
  const safe = await run({ mode: 'continue_chapters', maxSections: 2, humanize: { clickDelayMs: [1, 2], sectionCooldownMs: [1, 2], quizThinkMs: [1, 2], longPauseEveryOps: [3, 4], longPauseMs: [1, 2], pollMs: [1, 2] } }, { adapter: safeMock });
  assert(safe.quizzesAnswered === 0, '安全模式答题计数为 0');
  assert(!safeMock._S.clicks.some((c) => c.kind === 'quizOption' || c.kind === 'quizSubmit'), '安全模式未点击选项或提交');
  assert(
    safe.stopReason === null
    || safe.stopReason === 'quiz_needs_human'
    || safe.stopReason === 'video_quiz_needs_human'
    || String(safe.stopReason || '').startsWith('MAX_SECTIONS')
    || safe.ok === true,
    '安全模式走向合法（跳过继续／停机／跑完，实际 ' + safe.stopReason + '）'
  );

  console.log('== 自测 13/13：视频内随堂题只识别不操作 ==');
  const videoQuizAdapter = createMockAdapter({});
  const videoQuizMachine = new LearnMachine(videoQuizAdapter, mergeConfig(CONFIG, {}));
  videoQuizMachine._videoProgressTicks = 1;
  const videoQuizResult = await videoQuizMachine.handleVideoQuiz({
    videoQuiz: { present: true, frameId: 'mock-video-frame', title: '随堂题', options: [{ i: 0, label: 'A' }] },
    video: { found: true, duration: 120, currentTime: 35, src: 'mock://video.mp4' },
    videoFrameId: 'mock-video-frame',
    topUrl: 'https://mooc1.chaoxing.com/mock',
  });
  /* ★ 行为变更（2026-10-27 主人要求）：随堂题不再「识别后转人工」，
     改为**盲试作答**：按选项顺序试 → 提交 → 读反馈 → 答错换下一个 → 答对点继续。
     依据：随堂题不计入课程成绩，且 #spanNotBack 出现时会在下面停止，不会硬试。
     因此这里校验新行为：要么答对继续，要么因回看惩罚/次数耗尽而停止，
     但无论如何都不能触碰 .TiMu（章节测验）。 */
  assert(
    videoQuizResult.outcome === 'VIDEO_QUIZ_CORRECT'
    || videoQuizResult.outcome === 'VIDEO_QUIZ_CONTINUED'
    || videoQuizResult.outcome === 'VIDEO_QUIZ_PASSED'
    || videoQuizResult.outcome === 'VIDEO_QUIZ_EXHAUSTED'
    || videoQuizResult.outcome === 'VIDEO_QUIZ_REVIEW_REQUIRED'
    || videoQuizResult.outcome === 'VIDEO_QUIZ_NO_ATTEMPTS'
    || videoQuizResult.outcome === 'VIDEO_QUIZ_NO_OPTIONS',
    '视频内题按有效播放器上下文进入盲试流程'
  );
  assert(videoQuizMachine.counters.quizzesAnswered === 0, '视频内题答题计数为 0');
  assert(videoQuizAdapter._S.clicks.length === 0, '视频内题未点击选项、提交或继续');

  /* 题目事件 JSONL 链路：宿主依赖该文件逐行解析，曾因写成 '\\n' 字面量导致
     所有事件挤在一行、host 解析失败。此用例直接写盘并逐行校验。 */
  console.log('== 自测 14/14：题目事件 JSONL 写入与去重 ==');
  const eventFile = path.join(os.tmpdir(), 'cx-quiz-events-' + process.pid + '.jsonl');
  try { fs.unlinkSync(eventFile); } catch (_) { /* 首次无文件 */ }
  process.env.CX_QUESTION_FILE = eventFile;
  emittedQuestionKeys.clear();
  const once = emitQuestionEvent({ kind: 'video_embedded_quiz', question: '1+1=?', options: [{ i: 0, letter: 'A', label: 'A. 2' }] });
  assert(once.startsWith('q-') && once.length > 4, '事件 id 形如 q-xxxx');
  const twice = emitQuestionEvent({ kind: 'video_embedded_quiz', question: '1+1=?', options: [{ i: 0, letter: 'A', label: 'A. 2' }] });
  assert(twice === once, '同题干同选项的事件 id 去重（二次调用返回同一 id）');
  emitQuestionEvent({ kind: 'chapter_work', question: '2+2=?', options: [{ i: 0, letter: 'A', label: 'A. 4' }] });
  emitQuestionEvent({ kind: 'popup_quiz', question: '半行写入', options: [{ i: 0, letter: 'A', label: 'A. x' }] });
  fs.appendFileSync(eventFile, 'caf'); // 模拟引擎正在写入的半行：无换行，宿主应保留到下轮
  const rawEvent = fs.readFileSync(eventFile, 'utf8');
  const lines = rawEvent.split('\n');
  assert(lines.length === 4, '真实换行符拆分得到 4 行（实际 ' + lines.length + '）——若写成字面量 \\n 则只有 1 行');
  const parsed = lines.slice(0, 3).map((l) => JSON.parse(l));
  assert(parsed[0].id === once && parsed[0].kind === 'video_embedded_quiz' && parsed[0].event === 'question_detected', '首行事件可解析且字段完整');
  assert(lines[3] === 'caf' && lines[3].length > 0, '末行半行保留为 ' + rawEvent.length + ' 字节的余量');
  assert(parsed[1].kind === 'chapter_work' && parsed[2].kind === 'popup_quiz', '三种题目类型全部按行记录');
  assert(parsed.every((r) => r.options && Array.isArray(r.options) && r.options.length === 1), '选项结构化写入');
  assert(parsed.every((r) => !('draft' in r) && !('answer' in r) && !('submitted' in r)), '事件不含答案/草稿/提交字段');
  try { fs.unlinkSync(eventFile); } catch (_) { /* 清理 */ }
  delete process.env.CX_QUESTION_FILE;
  emittedQuestionKeys.clear();

  console.log(fails.length ? '== 自测失败 ' + fails.length + ' 项 ==' : '== 自测全部通过 ✓ ==');
  return fails.length === 0;
}

/** Mock 适配器：与 createCdpAdapter 原语签名完全一致，用确定性脚本模拟学习通页面。 */
function createMockAdapter(opts) {
  opts = opts || {};
  const secs = [
    { t: '第一章 1.1 课程导论' },
    { t: '第一章 1.2 视频A' },
    { t: '第一章 1.3 阅读材料', noVideo: true },
    { t: '第二章', header: true },
    { t: '第二章 2.1 视频B', quiz: true },
    { t: '第二章 2.2 视频C' }
  ];
  const S = {
    idx: 1, cur: 0, dur: 100, paused: true,
    done: [true, false, false, false, false, false],
    quizOpen: false, quizAnswered: false,
    probes: 0, clicks: [], navigations: [], muted: false,
    humanAt: opts.humanAt != null ? opts.humanAt : -1,
    loginInvalid: !!opts.loginInvalid,
    quizTabEnabled: !!opts.quizTabEnabled,
    quizTabOpen: false,
    _quizLoaded: false,
    url: 'https://mooc1.chaoxing.com/mycourse/studentstudy?courseId=999&clazzid=1&enc=mock'
  };
  function snapVideo() {
    const sec = secs[S.idx];
    if (!sec || sec.noVideo || sec.header) return { found: false };
    const prog = S.dur ? Math.min(100, (S.cur / S.dur) * 100) : 0;
    return { found: true, paused: S.paused || S.quizOpen, ended: S.cur >= S.dur, currentTime: S.cur, duration: S.dur, progress: Math.round(prog * 10) / 10, muted: S.muted, readyState: 4 };
  }
  function base(withToc, extra) {
    const toc = withToc
      ? { found: true, layer: 2, sel: '.prev_ul li', note: 'mock', items: secs.map((s, i) => ({ i, title: s.t, done: S.done[i], current: i === S.idx, chapterHeader: !!s.header, clickable: true })) }
      : { found: false, items: [], layer: 0, sel: '', note: '' };
    return Object.assign({
      url: S.url, video: { found: false }, dialogs: [], toc,
      quiz: { present: false, parseable: false, options: [], layer: 0 },
      human: { detected: false, evidence: null },
      login: { host: 'mooc1.chaoxing.com', href: S.url, hasPwField: false, hostHit: false }
    }, extra);
  }
  function probe() {
    S.probes += 1;
    if (S.humanAt >= 0 && S.probes >= S.humanAt) return base(true, { human: { detected: true, evidence: '人脸识别' } });
    if (S.loginInvalid) return base(true, { login: { host: 'passport2.chaoxing.com', href: 'https://passport2.chaoxing.com/login', hasPwField: true, hostHit: true } });
    const sec = secs[S.idx];
    // 章节测验标签：模拟「点开后才加载题目」
    const quizTab = S.quizTabEnabled
      ? { present: true, title: '章节测验', index: 1 }
      : { present: false, title: '', index: -1 };
    if (S.quizTabOpen) {
      // 题目加载（点开标签后题目就绪）；提交后题目消失
      return base(true, {
        video: { found: false, ended: false, paused: false, progress: 0, currentTime: 0, duration: 0 },
        quiz: S.quizAnswered
          ? { present: false, parseable: false, options: [], layer: 0 }
          : { present: true, parseable: true, layer: 2, note: 'popFrameId(模拟)', question: '章节测验题', options: [{ i: 0, label: 'A. 对' }, { i: 1, label: 'B. 错' }], submitText: '提交' },
        quizTab: quizTab
      });
    }
    if (!S.paused && !S.quizOpen && sec && !sec.noVideo && !sec.header) {
      S.cur = Math.min(S.dur, S.cur + 45);
      if (sec.quiz && S.cur >= 40 && !S.quizAnswered) S.quizOpen = true;
    }
    return base(true, {
      video: snapVideo(),
      quiz: S.quizOpen
        ? { present: true, parseable: true, layer: 2, note: 'popboxes(模拟)', question: '1+1=?', options: [{ i: 0, label: 'A. 2' }, { i: 1, label: 'B. 3' }], submitText: '提交' }
        : { present: false, parseable: false, options: [], layer: 0 },
      quizTab: quizTab
    });
  }
  function mockFind(kind, arg) {
    const mk = (text, layer, note) => ({ ok: true, text, rect: { x: 1, y: 2, w: 4, h: 4, __kind: kind, __arg: arg }, layer, note });
    if (kind === 'videoToggle') {
      const sec = secs[S.idx];
      if (!sec || sec.noVideo || sec.header) return { ok: false, reason: 'no-video-control' };
      return mk(S.paused ? '播放' : '视频区', 1, 'vjs-big-play-button');
    }
    if (kind === 'dialogPrimary') return { ok: false, reason: 'no-dialog-primary' };
    if (kind === 'quizOption') return (S.quizOpen || S.quizTabOpen) ? mk('A. 2', 2, 'mock-option') : { ok: false, reason: 'no-quiz-option' };
    if (kind === 'quizSubmit') return (S.quizOpen || S.quizTabOpen) ? mk('提交', 2, 'mock-submit') : { ok: false, reason: 'no-quiz-submit' };
    if (kind === 'tocItem') {
      if (arg == null || arg < 0 || arg >= secs.length) return { ok: false, reason: 'toc-index-out-of-range' };
      return mk(secs[arg].t, 2, 'mock-toc');
    }
    if (kind === 'quizTab') return S.quizTabEnabled ? mk('章节测验', 2, 'quiz-tab') : { ok: false, reason: 'no-quiz-tab' };
    if (kind === 'videoTab') return mk('视频', 2, 'video-tab');
    return { ok: false, reason: 'unknown-kind' };
  }
  function applyClick(rect) {
    const kind = rect.__kind, arg = rect.__arg;
    if (kind === 'videoToggle') { S.paused = false; return; }
    if (kind === 'videoTab') { S.quizTabOpen = false; S.quizOpen = false; S.paused = true; return; }
    if (kind === 'quizTab') { S.quizTabOpen = true; S.quizOpen = false; S.quizAnswered = false; return; }
    if (kind === 'quizOption') { S._picked = arg || 0; return; }
    if (kind === 'quizSubmit') { S.quizOpen = false; S.quizTabOpen = false; S.quizAnswered = true; return; }
    if (kind === 'dialogPrimary') { S._dialogClosed = true; return; }
    if (kind === 'tocItem') {
      S.done[S.idx] = true;
      S.idx = arg; S.cur = 0; S.paused = true; S.quizOpen = false; S.quizAnswered = false; S.muted = false;
    }
  }
  const adapter = {
    engine: 'mock',
    async sleep() { /* 自测不真实等待 */ },
    async ensureBrowser() { return { engine: 'mock' }; },
    async navigate(url) {
      S.navigations.push(url); S.url = url;
      S.idx = 1; S.cur = 0; S.paused = true;
      S.done = [true, false, false, false, false, false];
      S.quizOpen = false; S.quizAnswered = false;
    },
    async getCurrentUrl() { return S.url; },
    /* Mock 的 cookie：自测不走真实登录，返回 null 让调用方按「无法判断」处理 */
    async getAllCookies() { return null; },
    async screenshot() { throw new Error('Mock 适配器不支持截图（扫码登录需要真实浏览器）'); },
    async screenshotClip() { return ''; },
    async getFrameDocuments() { return [{ frameId: 'mock-top', url: S.url, isTop: true, depth: 0 }]; },
    async evalInFrameCross() { return { ok: false, error: 'mock' }; },
    async evalInFrame(frameId, expr) {
      if (expr.indexOf('__CX_SEL=') >= 0) return 'installed';
      if (expr.indexOf('__cx.probeAll()') >= 0) return probe();
      if (expr.indexOf('__cx.videoState()') >= 0) return snapVideo();
      if (expr.indexOf('v.muted') >= 0) { S.muted = true; return true; }
      const m = /__cx\.find\("([a-zA-Z]+)",\s*(null|\d+)\)/.exec(expr);
      if (m) return mockFind(m[1], m[2] === 'null' ? null : Number(m[2]));
      const jc = /__cx\.jsClick\("([a-zA-Z]+)",\s*(null|\d+)\)/.exec(expr);
      if (jc) {
        const arg = jc[2] === 'null' ? null : Number(jc[2]);
        const f = mockFind(jc[1], arg);
        if (f.ok) { applyClick({ __kind: jc[1], __arg: arg }); return { ok: true, layer: f.layer }; }
        return { ok: false, reason: f.reason };
      }
      return null;
    },
    async click(frameId, rect) {
      S.clicks.push({ kind: rect.__kind, arg: rect.__arg });
      applyClick(rect);
      return { mode: 'mock-input' };
    },
    async jsClick(frameId, kind, arg) {
      const f = mockFind(kind, arg);
      if (f.ok) { S.clicks.push({ kind, arg, degraded: true }); applyClick({ __kind: kind, __arg: arg }); return { ok: true, layer: f.layer }; }
      return { ok: false, reason: f.reason };
    },
    async getText() { return 'mock'; },
    async isVideoEnded() { return { found: true, ended: S.cur >= S.dur, raw: snapVideo() }; },
    /* 截图坐标换算相关（Mock 只验证流程，不做真实几何） */
    async getFrameChain() { return ['mock-top', 'mock-child']; },
    async frameOrigin() { return { ox: 0, oy: 0, parts: [] }; },
    async rootViewport() { return { w: 1440, h: 900, sx: 0, sy: 0 }; },
    async scrollRootTo() { return true; }
  };
  adapter._S = S; // 暴露内部状态供自测断言
  return adapter;
}

/**
 * ============================================================================
 * 新版课程页（mooc2-ans）只读识别器
 * ----------------------------------------------------------------------------
 * ★ 安全边界（主人 2026-10-27 明确要求）：
 *   本模块**只读**。不播放、不点击、不答题、不提交、不填写任何表单。
 *   它的唯一职责是：把课程页的结构扫描出来，供人工确认框架是否正确。
 *
 * 为什么需要独立模块：
 *   主人账号 184 个课程全部是 ismooc2=1 的新版页面，DOM 结构为
 *     mooc2-ans/mycourse/stu（任务/章节/资料/学习记录/课程图谱 五个 tab）
 *       └ 点「章节」→ iframe: mooc2-ans/mycourse/studentcourse（跨域）
 *            └ 再点某节 → iframe: knowledge/cards（再跨一层）
 *   老版引擎用的 .posCatalog_select / .ans-attach-ct 在**顶层**一个都没有，
 *   必须逐层穿透跨域 frame（Page.createIsolatedWorld）才能读到。
 *
 * 页面类型判定顺序：
 *   1. 命中 passport2 / login → 'login'
 *   2. 有 .posCatalog_select 或 #coursetree → 'mooc1-study'（老版，现有引擎可处理）
 *   3. 有「任务/章节/资料/学习记录」nav → 'mooc2-home'（新版课程主页）
 *   4. 有 .ans-attach-ct 或 .ans-job-icon → 'mooc2-chapter'（新版章节内容页）
 *   5. 有 video / .ans-videoquiz → 'media'
 *   6. 其他 → 'unknown'
 * ==========================================================================*/

/** 单个 frame 内运行的结构扫描表达式（纯只读，不触发任何点击）。 */
const STRUCT_SCAN_EXPR = `(() => {
  const d = document;
  const txt = (el) => (el && (el.innerText || el.textContent) || '').replace(/\\s+/g, ' ').trim();
  const vis = (el) => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  };
  const out = {
    url: (location.href || '').slice(0, 300),
    title: document.title || '',
    ready: document.readyState,
  };

  // ── 新版导航 tab ──
  out.navTabs = [];
  d.querySelectorAll('li, a, span').forEach((el) => {
    if (!vis(el)) return;
    const t = txt(el);
    if (!t || t.length > 6) return;
    if (!/^(任务|章节|资料|学习记录|课程图谱|讨论|作业|考试|统计)$/.test(t)) return;
    out.navTabs.push({ tag: el.tagName, text: t, cls: String(el.className || '').slice(0, 40) });
  });

  // ── 老版目录 ──
  out.tocOld = d.querySelectorAll('.posCatalog_select').length;
  out.tocTree = d.querySelectorAll('#coursetree').length;

  // ── 新版章节树（★ 2026-10-27 实测确认：化工热力学课程） ──
  //     .chapter_unit → 7 个（章），.chapter_item → 32 个（节）
  //     这两个选择器在 studentcourse iframe 里有效，老版选择器在新版全为 0
  const chapSel = [
    '.chapter_unit', '.chapter_item',
    '.chapter_itemBox', '.chapter',
    '.posCatalog_select', '#coursetree li',
    '.catalog_list li', '.catalogList li'
  ];
  out.chapterCandidates = chapSel.map((s) => {
    let n = 0;
    try { n = d.querySelectorAll(s).length; } catch (_) { n = -1; }
    return { sel: s, count: n };
  }).filter((x) => x.count > 0);

  // 章节明细（只读文本，供人工核对）
  out.chapters = [];
  d.querySelectorAll('.chapter_unit').forEach((unit, ci) => {
    if (ci >= 40) return;
    const items = [];
    unit.querySelectorAll('.chapter_item').forEach((it) => {
      if (items.length >= 60) return;
      const t = txt(it);
      if (!t || t.length > 120) return;
      items.push({
        text: t.slice(0, 90),
        finished: /已完成|completed|完成/i.test(String(it.className || '')),
        cls: String(it.className || '').slice(0, 60),
      });
    });
    const head = txt(unit).slice(0, 60);
    out.chapters.push({ index: ci, head, itemCount: items.length, items });
  });

  // ── 任务点（老版选择器，在新版 iframe 里可能仍有效） ──
  out.attachCt = d.querySelectorAll('.ans-attach-ct').length;
  out.jobIcon = d.querySelectorAll('.ans-job-icon').length;
  out.taskItems = [];
  d.querySelectorAll('.ans-attach-ct').forEach((el, i) => {
    if (i >= 30) return;
    const icon = el.querySelector('.ans-job-icon');
    const ifr = el.querySelector('iframe');
    out.taskItems.push({
      i,
      finished: el.classList.contains('ans-job-finished'),
      iconLabel: icon ? (icon.getAttribute('aria-label') || '').slice(0, 30) : '',
      iframeSrc: ifr ? (ifr.getAttribute('src') || '').slice(0, 110) : '',
      text: txt(el).slice(0, 40),
    });
  });

  // ── 媒体 ──
  out.videos = d.querySelectorAll('video').length;
  out.audios = d.querySelectorAll('audio').length;
  out.videoQuiz = d.querySelectorAll('.ans-videoquiz').length;

  // ── 题目表单特征（只统计数量，不读内容、不填） ──
  out.quizForms = d.querySelectorAll('form, .questionLi, .TiMu, .Zy_TItle').length;
  out.quizMarkers = d.querySelectorAll('[id^="question"], [class*="questionLi"], [class*="TiMu"]').length;

  // ── iframe 清单（供逐层穿透） ──
  out.iframes = [];
  d.querySelectorAll('iframe').forEach((f, i) => {
    if (i >= 15) return;
    out.iframes.push({
      i,
      src: (f.getAttribute('src') || '').slice(0, 130),
      module: f.getAttribute('module') || '',
      w: f.offsetWidth, h: f.offsetHeight,
      visible: vis(f),
    });
  });

  // ── 正文摘要（判断页面性质） ──
  out.bodyHead = txt(d.body).slice(0, 260);

  // ── 页面类型判定 ──
  if (/passport2\\.chaoxing\\.com|\\/login/i.test(out.url) && d.querySelector('input[type="password"], #quickCode')) {
    out.kind = 'login';
  } else if (out.tocOld > 0 || out.tocTree > 0) {
    out.kind = 'mooc1-study';
  } else if (out.attachCt > 0 || out.jobIcon > 0) {
    out.kind = 'mooc2-chapter';
  } else if (out.videos > 0 || out.videoQuiz > 0) {
    out.kind = 'media';
  } else if (out.navTabs.length >= 3) {
    out.kind = 'mooc2-home';
  } else {
    out.kind = 'unknown';
  }
  return JSON.stringify(out);
})()`;

/**
 * 点开新版课程页的「章节」tab（只读导航，不播放不答题）。
 *
 * 为什么必须点：mooc2-ans 主页默认停在「任务」tab，章节树在
 * 点「章节」后才被加载进 iframe（studentcourse）。
 * 本操作只是切换页签，等价于用户点一下导航，不触发任何学习行为。
 *
 * @returns {Promise<{ok:boolean, reason?:string}>}
 */
async function openChapterTab(adapter) {
  const frames = await adapter.getFrameDocuments();
  const top = frames.find((f) => f.isTop);
  if (!top) return { ok: false, reason: 'no-top-frame' };

  /* ★ 实测坑：刚进课程页时导航尚未渲染完成，「章节」的坐标会偏移
     （实测正确位置 y≈348，但页面未加载完时 y≈315，点到的是「任务」）。
     所以先等导航稳定：连续两次读到相同坐标才认为布局就绪。 */
  const locateExpr = `(() => {
    const txt = (el) => (el && (el.innerText || el.textContent) || '').replace(/\\s+/g, '').trim();
    const vis = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      const s = getComputedStyle(el);
      return s.display !== 'none' && s.visibility !== 'hidden';
    };
    let best = null;
    document.querySelectorAll('a, li, span, div').forEach((el) => {
      if (!vis(el)) return;
      if (txt(el) !== '章节') return;
      const inner = [...el.querySelectorAll('a, li, span, div')].some((c) => vis(c) && txt(c) === '章节');
      if (inner) return;
      if (!best) best = el;
    });
    if (!best) return JSON.stringify({ ok: false, reason: 'tab-not-found' });
    const clickable = best.closest('a') || best.closest('li') || best;
    const r = clickable.getBoundingClientRect();
    return JSON.stringify({
      ok: true,
      tag: clickable.tagName,
      cls: String(clickable.className || '').slice(0, 40),
      id: clickable.id || '',
      x: Math.round(r.x + r.width / 2),
      y: Math.round(r.y + r.height / 2),
      w: Math.round(r.width), h: Math.round(r.height),
    });
  })()`;

  // 等布局稳定：最多 12 秒，连续两次坐标一致
  let prev = '';
  let hit = null;
  for (let i = 0; i < 12; i++) {
    let raw;
    try { raw = await adapter.evalInFrame(top.frameId, locateExpr); } catch (_) { raw = ''; }
    let r; try { r = JSON.parse(raw); } catch (_) { r = { ok: false }; }
    if (!r || !r.ok) { await sleep(1000); continue; }
    const sig = r.x + ',' + r.y + ',' + r.w + ',' + r.h;
    if (sig === prev) { hit = r; break; }
    prev = sig;
    await sleep(1000);
  }
  if (!hit) {
    // 布局没稳定也再试一次最后的读数
    let raw;
    try { raw = await adapter.evalInFrame(top.frameId, locateExpr); } catch (_) { raw = ''; }
    try { hit = JSON.parse(raw); } catch (_) { hit = null; }
  }
  if (!hit || !hit.ok) return { ok: false, reason: (hit && hit.reason) || 'not-found' };

  /* ★★ 点击策略（2026-10-27 实测修正）：
     不能依赖坐标点击 —— 页面布局在加载后会移动（实测同一元素
     在布局未稳时 y=369，稳定后 y=348，差 21px，点到了别的 tab）。
     改为：在页面内用 elementFromPoint 找到真实元素后直接 click()，
     这样与坐标无关，也不会因滚动/布局变化而偏移。 */
  const doClickExpr = `(() => {
    const txt = (el) => (el && (el.innerText || el.textContent) || '').replace(/\\s+/g, '').trim();
    const vis = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      const s = getComputedStyle(el);
      return s.display !== 'none' && s.visibility !== 'hidden';
    };
    // 找最内层的「章节」文字元素
    let best = null;
    document.querySelectorAll('a, li, span, div').forEach((el) => {
      if (txt(el) !== '章节') return;
      if (!vis(el)) return;
      const inner = [...el.querySelectorAll('a, li, span, div')].some((c) => vis(c) && txt(c) === '章节');
      if (inner) return;
      if (!best) best = el;
    });
    if (!best) return JSON.stringify({ ok: false, reason: 'tab-not-found' });

    // 优先点 <a> 祖先（站点把跳转绑在 a 上）
    const a = best.closest('a');
    const target = a || best;
    const before = location.href;
    try { target.click(); } catch (e) {
      return JSON.stringify({ ok: false, reason: 'click-err:' + String(e.message || e).slice(0, 50) });
    }
    return JSON.stringify({
      ok: true,
      tag: target.tagName,
      cls: String(target.className || '').slice(0, 30),
      href: (target.getAttribute && target.getAttribute('href') || '').slice(0, 60),
      before: before.slice(0, 100),
    });
  })()`;

  let clickRes;
  try {
    const raw = await adapter.evalInFrame(top.frameId, doClickExpr);
    try { clickRes = JSON.parse(raw); } catch (_) { clickRes = { ok: false, reason: 'bad-json' }; }
  } catch (e) {
    return { ok: false, reason: 'click: ' + String((e && e.message) || e).slice(0, 90) };
  }
  if (!clickRes || !clickRes.ok) {
    return { ok: false, reason: (clickRes && clickRes.reason) || 'click-failed' };
  }
  logger.log('PROBE', 'INFO', '已点开「章节」tab（页面内 click·只读导航）', {
    tag: clickRes.tag, cls: clickRes.cls, href: clickRes.href,
  });

  await sleep(4000);
  return { ok: true };
}

/**
 * 点开「章节」后等待 studentcourse iframe 真正加载出来。
 *
 * ★ 实测坑：点「章节」会让页面重新导航（URL 的 pageHeader 参数变化），
 *   期间旧 iframe 被销毁、新 iframe 尚未创建。固定 sleep 4s 有时太短，
 *   抓到的还是没有章节树的空壳页面。这里改为轮询等待，最多 25 秒。
 *
 * @returns {Promise<boolean>} 是否等到章节 iframe
 */
async function waitForChapterFrame(adapter, timeoutMs) {
  const deadline = Date.now() + (timeoutMs || 25000);
  let tries = 0;
  let lastDiag = null;
  while (Date.now() < deadline) {
    tries += 1;
    try {
      const frames = await adapter.getFrameDocuments();
      const hit = frames.find((f) => /studentcourse/i.test(f.url || ''));
      if (hit) {
        // 再确认这一帧里真的能读到章节元素，避免「壳已加载但内容还没渲染」
        const r = await adapter.evalInFrameCross(
          hit.frameId,
          'document.querySelectorAll(".chapter_unit").length'
        );
        if (r && r.ok && Number(r.value) > 0) {
          logger.log('PROBE', 'INFO', '章节 iframe 已就绪', { tries, units: Number(r.value) });
          return true;
        }
        lastDiag = { foundFrame: true, url: String(hit.url || '').slice(0, 90), units: r && r.ok ? r.value : 'eval-fail' };
      } else {
        lastDiag = {
          foundFrame: false,
          frameCount: frames.length,
          frameUrls: frames.map((f) => String(f.url || '').slice(0, 55)).slice(0, 8),
        };
      }
    } catch (_) { /* 间歇失败继续等 */ }
    await sleep(1200);
  }
  logger.log('PROBE', 'WARN', '等待章节 iframe 超时', { tries, diag: lastDiag });
  return false;
}

/**
 * 探测「任务型课程」：这类课没有章节树，只有活动列表（stuActiveList）。
 *
 * ★ 2026-10-27 实测：「典型建模技术」「优化理论与方法」两门课
 *   帧里是 mobilelearn.chaoxing.com/page/active/stuActiveList，
 *   整页 .chapter_unit / .chapter_item / [class*=chapter] 全为 0。
 *   这不是故障，是课程本身的结构不同，应记为「任务型」而不是失败。
 *
 * @returns {Promise<{taskType:boolean, frameId?:string, url?:string}>}
 */
async function detectTaskTypeCourse(adapter) {
  try {
    const frames = await adapter.getFrameDocuments();
    const active = frames.find((f) => /stuActiveList|mobilelearn\.chaoxing\.com\/page\/active/i.test(f.url || ''));
    if (active) {
      return { taskType: true, frameId: active.frameId, url: String(active.url || '').slice(0, 120), kind: '活动列表' };
    }
    /* ★ 2026-10-27 实测：「典型建模技术」这门课点开章节后，
       studentcourse 帧里只有 <div class="fanyaChapter">，
       内容是「已完成任务点: 0/0」「目录 暂无章节内容」——
       这门课在系统里**根本没挂章节**，不是程序问题。
       判据：出现「暂无章节内容 / 0/0」且 chapter 计数为 0。 */
    const sc = frames.find((f) => /studentcourse/i.test(f.url || ''));
    if (sc && sc.frameId) {
      /* ★★ 关键：先给章节树充分的加载时间（最多 ~18 秒）。
         实测【智变·重构·共生】这门课：刚打开时页面同样显示
         「已完成任务点: 0/0」「暂无章节内容」，但章节树是**后加载**的，
         几秒后才出现 4 章 19 节。若此刻就判「无内容」会误伤正常课程。
         所以：先等 units/items 出现；只有在**持续 18 秒都没有**、
         且页面一直显示「暂无章节内容」时，才认定是无内容课程。 */
      let o = null;
      for (let k = 0; k < 12; k++) {
        const r = await adapter.evalInFrameCross(sc.frameId, `(() => {
          const t = (document.body ? document.body.innerText : '') || '';
          const empty = /暂无章节内容|暂无内容/.test(t);
          const units = document.querySelectorAll('.chapter_unit').length;
          const items = document.querySelectorAll('.chapter_item').length;
          const heads = document.querySelectorAll('.chapter_head').length;
          return JSON.stringify({ empty, units, items, heads, sample: t.replace(/\\s+/g,' ').trim().slice(0, 80) });
        })()`);
        if (r && r.ok) { try { o = JSON.parse(r.value) } catch (_) { o = null } }
        if (o && (o.units > 0 || o.items > 0)) return { taskType: false };
        await sleep(1500);
      }
      /* 18 秒后仍然完全没有章节元素，且页面明确说「暂无章节内容」→ 判为无内容课程 */
      if (o && o.empty && o.units === 0 && o.items === 0) {
        return { taskType: true, frameId: sc.frameId, url: String(sc.url || '').slice(0, 120), kind: '暂无章节内容', sample: o.sample };
      }
    }
    // 顶层若没有任何章节元素、也没有 studentcourse 帧，也视为任务型
    const top = frames.find((f) => f.isTop) || frames[0];
    if (top && top.frameId) {
      const r = await adapter.evalInFrameCross(top.frameId, `(() => {
        const n = document.querySelectorAll('.chapter_unit').length;
        const hasChapterFrame = [...document.querySelectorAll('iframe')].some((f) => /studentcourse/i.test(f.src || ''));
        return JSON.stringify({ n, hasChapterFrame });
      })()`);
      if (r && r.ok) {
        let o; try { o = JSON.parse(r.value) } catch (_) { o = null }
        if (o && o.n === 0 && !o.hasChapterFrame) {
          return { taskType: true, url: '(no chapter tree)', kind: '无章节树' };
        }
      }
    }
  } catch (_) { /* ignore */ }
  return { taskType: false };
}

/**
 * 只读识别一个课程页（含逐层 iframe 穿透）。
 *
 * @param {object} adapter CDP 适配器
 * @param {object} opts { maxDepth, maxFrames }
 * @returns {Promise<object>} 结构化报告，不含任何页面操作痕迹
 */
async function probePageStructure(adapter, opts) {
  const o = opts || {};
  const maxDepth = typeof o.maxDepth === 'number' ? o.maxDepth : 4;
  const maxFrames = typeof o.maxFrames === 'number' ? o.maxFrames : 20;

  const frames = await adapter.getFrameDocuments();
  const report = {
    at: new Date().toISOString(),
    topUrl: '',
    frameCount: frames.length,
    frames: [],
    summary: null,
  };

  const walk = async (f) => {
    if (f.depth > maxDepth) return;
    if (report.frames.length >= maxFrames) return;
    const entry = {
      frameId: f.frameId,
      depth: f.depth,
      isTop: !!f.isTop,
      url: f.url,
      kind: 'unreadable',
    };
    // 顶层用普通 evalInFrame；其余一律走跨域 isolated world
    try {
      const res = f.isTop
        ? { ok: true, value: await adapter.evalInFrame(f.frameId, STRUCT_SCAN_EXPR) }
        : await adapter.evalInFrameCross(f.frameId, STRUCT_SCAN_EXPR);
      if (res && res.ok && res.value) {
        let parsed;
        try { parsed = JSON.parse(res.value); } catch (_) { parsed = null; }
        if (parsed) Object.assign(entry, parsed);
        else entry.kind = 'unparsed';
      } else {
        entry.error = (res && res.error) || 'empty';
      }
    } catch (e) {
      entry.error = String((e && e.message) || e).slice(0, 120);
    }
    report.frames.push(entry);
    if (f.isTop) report.topUrl = entry.url || '';
    // 子 frame 由 getFrameDocuments 已经线性返回，无需递归 children
  };

  for (const f of frames) {
    // eslint-disable-next-line no-await-in-loop
    await walk(f);
  }

  // 汇总：判断整体是哪种页面、有没有可用的章节/任务点
  const kinds = report.frames.map((x) => x.kind);
  const has = (k) => kinds.includes(k);
  report.summary = {
    pageKind: has('mooc1-study') ? 'mooc1-study'
      : has('mooc2-chapter') ? 'mooc2-chapter'
      : has('mooc2-home') ? 'mooc2-home'
      : has('login') ? 'login'
      : has('media') ? 'media'
      : 'unknown',
    tocOld: report.frames.reduce((n, x) => n + (x.tocOld || 0), 0),
    attachCt: report.frames.reduce((n, x) => n + (x.attachCt || 0), 0),
    jobIcon: report.frames.reduce((n, x) => n + (x.jobIcon || 0), 0),
    taskItems: report.frames.reduce((n, x) => n + ((x.taskItems && x.taskItems.length) || 0), 0),
    videos: report.frames.reduce((n, x) => n + (x.videos || 0), 0),
    quizForms: report.frames.reduce((n, x) => n + (x.quizForms || 0), 0),
    chapterCandidates: report.frames.reduce((n, x) => n + ((x.chapterCandidates && x.chapterCandidates.length) || 0), 0),
    readableFrames: report.frames.filter((x) => x.kind !== 'unreadable' && x.kind !== 'unparsed').length,
  };
  return report;
}

/**
 * ============================================================================
 * 模拟点击导航（规避学习通风控）
 * ----------------------------------------------------------------------------
 * ★ 为什么不能直接 navigate：
 *   学习通对直接用 URL 跳转课程页有较强风控。实测表现（2026-10-27）：
 *     - 直接 navigate 到 stucoursemiddle → 落到课程页但 pageHeader=-1，
 *       点「章节」后整页重载、studentcourse iframe 始终不出现
 *     - 从课程列表**点击**进入 → 一切正常，点「章节」立即出现章节树
 *   所以页面之间的切换一律走模拟点击（CDP Input.dispatchMouseEvent），
 *   只有「首次打开学习通首页」允许 navigate。
 *
 * 安全边界：这些点击只是导航（进课程、切 tab），不触碰任何学习行为。
 * ==========================================================================*/

/**
 * 定位课程链接：优先按 courseId 精确匹配（最可靠），其次按课程名。
 * 只读，不点击。
 */
async function locateCourseLink(adapter, courseText, courseId) {
  const frames = await adapter.getFrameDocuments();
  const top = frames.find((f) => f.isTop);
  if (!top) return { ok: false, reason: 'no-top' };

  const expr = `(() => {
    var want = ${JSON.stringify(String(courseText || ''))};
    var cid = ${JSON.stringify(String(courseId || ''))};
    var as = Array.prototype.slice.call(document.querySelectorAll('a[href]'));
    var pool = as.filter(function (a) {
      var h = a.getAttribute('href') || '';
      return /courseid=\\d+/i.test(h);
    });
    var hit = null;
    if (cid) {
      hit = pool.find(function (a) {
        var m = /courseid=(\\d+)/i.exec(a.getAttribute('href') || '');
        return m && m[1] === cid;
      }) || null;
    }
    if (!hit && want) {
      hit = pool.find(function (a) {
        var t = (a.innerText || a.textContent || '').replace(/\\s+/g, ' ').trim();
        return t.indexOf(want) >= 0;
      }) || null;
    }
    if (!hit) hit = pool[0] || null;
    if (!hit) return JSON.stringify({ ok: false, reason: 'no-course-link', pool: pool.length });
    var t = (hit.innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 50);
    var h = (hit.getAttribute('href') || '').slice(0, 200);
    var r = hit.getBoundingClientRect();
    return JSON.stringify({
      ok: true, text: t, href: h,
      x: Math.round(r.x + r.width / 2),
      y: Math.round(r.y + r.height / 2),
      w: Math.round(r.width), h: Math.round(r.height)
    });
  })()`;

  try {
    const raw = await adapter.evalInFrame(top.frameId, expr);
    let r; try { r = JSON.parse(raw); } catch (_) { r = { ok: false, reason: 'bad-json' }; }
    return r;
  } catch (e) {
    return { ok: false, reason: 'eval: ' + String((e && e.message) || e).slice(0, 90) };
  }
}

/**
 * 用模拟点击进入某门课程（替代 navigate）。
 * @param {string} courseText 课程名关键词（如「化工热力学」）；留空则点第一门
 */
/**
 * 列出浏览器所有 target（模块级，不依赖 adapter 内部的 cdpHttp 闭包）。
 * ★ 实测：Chrome for Testing 158 上 `/json/list` 返回空，`/json` 正常。
 *   两个都试，取有数据的那个。
 */
async function listTargets(cfg) {
  const c = cfg || CONFIG;
  const port = resolveCdpPort(c);
  if (!port) return [];
  const base = 'http://' + (c.cdp.host || '127.0.0.1') + ':' + port;
  for (const p of ['/json', '/json/list']) {
    try {
      const res = await fetch(base + p, { signal: AbortSignal.timeout(8000) });
      if (!res.ok) continue;
      const arr = await res.json();
      if (Array.isArray(arr) && arr.length) return arr;
    } catch (_) { /* 试下一个 */ }
  }
  return [];
}

async function openCourseByClick(adapter, courseText, opts) {
  const o = opts || {};
  const maxWait = o.maxWaitMs || 30000;
  const cfg = o.cfg || CONFIG;
  const courseId = o.courseId || '';

  // 记录点击前已有的 target id，用来识别「新开的那个」
  const before = new Set();
  try {
    const list0 = await listTargets(cfg);
    (list0 || []).forEach((t) => { if (t.id) before.add(t.id); });
  } catch (_) { /* ignore */ }
  logger.log('PROBE', 'INFO', '点击前 target 数', { count: before.size });

  const hit = await locateCourseLink(adapter, courseText, courseId);
  if (!hit || !hit.ok) {
    return { ok: false, reason: '未找到课程链接: ' + ((hit && hit.reason) || 'unknown') };
  }
  logger.log('PROBE', 'INFO', '模拟点击进入课程（规避风控）', {
    text: hit.text, href: String(hit.href).slice(0, 90),
  });

  const frames = await adapter.getFrameDocuments();
  const top = frames.find((f) => f.isTop);

  /* ★ 实测（2026-10-27）：课程卡片是 <a target="_blank">，
     文字常常为空（封面图卡片），且需要先 scrollIntoView 才能点到。
     所以点击前先把卡片滚到视口中央，再取坐标。 */
  try {
    await adapter.evalInFrame(top.frameId, `(() => {
      var cid = ${JSON.stringify(String(courseId || ''))};
      var as = Array.prototype.slice.call(document.querySelectorAll('a[href]'));
      var hit = null;
      if (cid) {
        hit = as.find(function (a) {
          var m = /courseid=(\\d+)/i.exec(a.getAttribute('href') || '');
          return m && m[1] === cid;
        }) || null;
      }
      if (hit) { try { hit.scrollIntoView({ block: 'center' }); } catch (e) {} }
      return 'scrolled';
    })()`);
    await sleep(600);
  } catch (_) { /* ignore */ }

  // 重新取一次坐标（滚动后位置变了）
  const hit2 = await locateCourseLink(adapter, courseText, courseId);
  const pt = (hit2 && hit2.ok) ? hit2 : hit;

  try {
    await adapter.click(top.frameId, { x: pt.x, y: pt.y, w: pt.w, h: pt.h });
  } catch (e) {
    return { ok: false, reason: 'click: ' + String((e && e.message) || e).slice(0, 90) };
  }
  await sleep(2000);

  /* ★ 兜底：CDP 鼠标点击有时打不开（坐标落在文字 span 上、或被浮层挡住）。
     若还没出现课程页，就在页面内对该链接派发一次真实 click()。
     这仍是「点击」而非直接导航，不会触发 URL 直达风控。 */
  const quick = await listTargets(cfg);
  const hasCoursePage = quick.some((t) => t.type === 'page' &&
    /mooc2-ans\.chaoxing\.com\/mooc2-ans\/mycourse\/stu|mycourse\/studentstudy|mooc-ans\/visit/i.test(t.url || ''));
  if (!hasCoursePage) {
    logger.log('PROBE', 'INFO', '鼠标点击未生效，改用链接 click() 兜底');
    const clickJs = `(() => {
      var want = ${JSON.stringify(String(courseText || ''))};
      var cid = ${JSON.stringify(String(courseId || ''))};
      var as = Array.prototype.slice.call(document.querySelectorAll('a[href]'));
      var pool = as.filter(function (a) { return /courseid=\\d+/i.test(a.getAttribute('href') || ''); });
      var hit = null;
      if (cid) {
        hit = pool.find(function (a) {
          var m = /courseid=(\\d+)/i.exec(a.getAttribute('href') || '');
          return m && m[1] === cid;
        }) || null;
      }
      if (!hit && want) {
        hit = pool.find(function (a) { return ((a.innerText || '').indexOf(want) >= 0); }) || null;
      }
      if (!hit) return 'not-found';
      try { hit.click(); return 'clicked'; } catch (e) { return 'err:' + String(e.message || e).slice(0, 60); }
    })()`;
    try {
      const r = await adapter.evalInFrame(top.frameId, clickJs);
      logger.log('PROBE', 'INFO', '链接 click() 结果', { result: String(r).slice(0, 40) });
    } catch (e) {
      logger.log('PROBE', 'WARN', 'click() 兜底失败', { err: String((e && e.message) || e).slice(0, 80) });
    }
  }

  /* ★ 实测（2026-10-27）：点课程卡片会在**新标签页**打开课程，
     原列表页 URL 始终不变。所以不能等「当前页 URL 变化」，
     必须轮询 /json/list 找**新出现的**课程页 target。 */
  const deadline = Date.now() + maxWait;
  let lastSeen = '';
  while (Date.now() < deadline) {
    await sleep(1500);
    let list = [];
    try { list = await listTargets(cfg); } catch (_) { list = []; }
    const pages = list.filter((t) => t.type === 'page');
    lastSeen = pages.map((t) => (t.url || '').slice(0, 60)).join(' | ');

    /* ★ 实测：点课程卡片可能复用已有标签、也可能新开一个。
       所以不区分新旧，只要池子里存在课程页就附着过去；
       优先选「刚才没在的前台页」，否则取最后一个课程页。 */
    const coursePages = pages.filter((t) =>
      /mooc2-ans\.chaoxing\.com\/mooc2-ans\/mycourse\/stu|mycourse\/studentstudy/i.test(t.url || '')
    );
    if (coursePages.length) {
      const fresh = coursePages.filter((t) => !before.has(t.id));
      const target = fresh.length ? fresh[fresh.length - 1] : coursePages[coursePages.length - 1];
      await sleep(4000);
      logger.log('PROBE', 'INFO', '已进入课程页（模拟点击）', {
        url: String(target.url).slice(0, 110), isNew: !before.has(target.id),
      });
      try { await adapter.attachTarget(target.id); } catch (e) {
        logger.log('PROBE', 'WARN', 'attachTarget 失败', { err: String((e && e.message) || e).slice(0, 90) });
      }
      return { ok: true, text: hit.text, url: String(target.url), targetId: target.id };
    }
  }
  logger.log('PROBE', 'WARN', '点击后未出现课程页', {
    beforeCount: before.size,
    pagesSeen: lastSeen.slice(0, 300),
  });
  return { ok: false, reason: '点击后未出现课程页（超时）' };
}

/**
 * 点开「章节」并等待章节 iframe 就绪（整合重试 + 重新附着）。
 *
 * 实测（2026-10-27）：点「章节」会让页面**整页跳转**到 pageHeader=1，
 * 旧 target 被替换、新 target 出现、iframe 随后才加载。
 * 所以这里做完整闭环：点 → 等新 target → 重新附着 → 等 iframe → 校验。
 */
async function openChapterAndWait(adapter, cfg, opts) {
  const o = opts || {};
  const maxRound = o.maxRound || 2;

  for (let round = 1; round <= maxRound; round++) {
    // 已经在章节页就不用再点
    if (await waitForChapterFrame(adapter, 3000)) return { ok: true, round };

    // 记录点击前 URL，用于判断是否发生跳转
    let urlBefore = '';
    try { urlBefore = await adapter.getCurrentUrl(); } catch (_) { urlBefore = ''; }

    logger.log('PROBE', 'INFO', `第 ${round} 轮：点「章节」tab`, { urlBefore: String(urlBefore).slice(0, 90) });
    const clicked = await openChapterTab(adapter);
    if (!clicked.ok) {
      logger.log('PROBE', 'WARN', '点章节失败', { reason: clicked.reason });
      continue;
    }

    /* ★ 实测：点「章节」会让页面**整页跳转**（URL 加 pageHeader=1）。
       判断是否成功的关键信号是 URL 变化，而不是固定 sleep。
       这里轮询 25 秒：每 2.5 秒看一次 URL + 是否有章节 iframe。 */
    const deadline = Date.now() + 25000;
    let urlChanged = false;
    while (Date.now() < deadline) {
      await sleep(2500);

      let urlNow = '';
      try { urlNow = await adapter.getCurrentUrl(); } catch (_) { urlNow = ''; }
      if (urlNow && urlNow !== urlBefore && /pageHeader=1/i.test(urlNow)) {
        if (!urlChanged) {
          urlChanged = true;
          logger.log('PROBE', 'INFO', '检测到 URL 跳转到 pageHeader=1', { url: urlNow.slice(0, 110) });
        }
      }

      if (await waitForChapterFrame(adapter, 2000)) return { ok: true, round };

      // URL 变了但当前 target 读不到，看看是不是换了新 target
      if (urlChanged) {
        const list = await listTargets(cfg).catch(() => []);
        const withHeader = list
          .filter((t) => t.type === 'page' && /mooc2-ans\.chaoxing\.com\/mooc2-ans\/mycourse\/stu/i.test(t.url || ''))
          .find((t) => /pageHeader=1/i.test(t.url || ''));
        if (withHeader) {
          logger.log('PROBE', 'INFO', '重新附着到 pageHeader=1 的 target');
          try { await adapter.attachTarget(withHeader.id); } catch (_) { /* ignore */ }
          await sleep(2000);
          if (await waitForChapterFrame(adapter, 12000)) return { ok: true, round };
        }
      }
    }
    logger.log('PROBE', 'WARN', `第 ${round} 轮未等到章节 iframe`, { urlChanged });
  }
  return { ok: false };
}

/**
 * 在章节树里点开指定小节（模拟点击，只读导航）。
 *
 * @param {object} adapter
 * @param {string} keyword 小节标题关键词（如 '1.1'）；留空则点第一节
 * @returns {Promise<{ok:boolean, text?:string, reason?:string}>}
 */
async function openSectionByClick(adapter, keyword) {
  const frames = await adapter.getFrameDocuments();
  const cf = frames.find((f) => /studentcourse/i.test(f.url || ''));
  if (!cf) return { ok: false, reason: '章节 iframe 不存在（先点「章节」tab）' };

  // 1) 在章节 iframe 内定位目标节点坐标
  const locate = `(() => {
    var want = ${JSON.stringify(String(keyword || ''))};
    var items = Array.prototype.slice.call(document.querySelectorAll('.chapter_item'));
    if (!items.length) return JSON.stringify({ ok: false, reason: 'no-items' });
    // 过滤掉「章头」行（.chapter_item 里也有章标题），只留有小节号的
    var secs = items.filter(function (el) {
      var t = (el.innerText || '').replace(/\\s+/g, ' ').trim();
      return /^\\d+\\.\\d+/.test(t);
    });
    var pool = secs.length ? secs : items;
    /* ★ 2026-10-28 修 bug：原来用 indexOf(want) 做**子串**匹配，
       导致 want="1.6" 命中 "11.6 隐私权"（实测 --section=1.6 打开了 11.6）。
       改为四级匹配：完全相等 → 前缀 → 小节号锚定 → 兜底子串（要求前面非数字）。 */
    var hit = null;
    if (want) {
      var nm = function (el) { return String(el.innerText || '').replace(/\\s+/g, ' ').trim(); };
      hit = pool.find(function (el) { return nm(el) === want; });
      if (!hit) hit = pool.find(function (el) { return nm(el).indexOf(want + ' ') === 0; });
      if (!hit) {
        // 注意：本段在模板字符串内，反斜杠要双写
        var esc = want.split('').map(function (c) {
          return /[.*+?^\${}()|[\\]\\\\]/.test(c) ? '\\\\' + c : c;
        }).join('');
        var rex = new RegExp('^' + esc + '(?![0-9.])');
        hit = pool.find(function (el) { return rex.test(nm(el)); });
      }
      if (!hit) {
        hit = pool.find(function (el) {
          var s = nm(el);
          var i = s.indexOf(want);
          if (i < 0) return false;
          if (i > 0 && /[0-9]/.test(s.charAt(i - 1))) return false;
          return true;
        });
      }
    } else {
      hit = pool[0];
    }
    if (!hit) return JSON.stringify({ ok: false, reason: 'not-found', total: pool.length });
    var r = hit.getBoundingClientRect();
    return JSON.stringify({
      ok: true,
      text: (hit.innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 60),
      x: Math.round(r.x + r.width / 2),
      y: Math.round(r.y + r.height / 2),
      w: Math.round(r.width), h: Math.round(r.height),
      total: pool.length,
    });
  })()`;

  let hit;
  try {
    const raw = await adapter.evalInFrameCross(cf.frameId, locate);
    if (!raw || !raw.ok) return { ok: false, reason: 'locate: ' + ((raw && raw.error) || 'failed') };
    hit = JSON.parse(raw.value);
  } catch (e) {
    return { ok: false, reason: 'eval: ' + String((e && e.message) || e).slice(0, 90) };
  }
  if (!hit || !hit.ok) return { ok: false, reason: '定位失败: ' + ((hit && hit.reason) || 'unknown') };

  /* 2) 点击：章节 iframe 是跨域的，坐标是 iframe 内的局部坐标，
        需要用 elementFromPoint 在该 iframe 的上下文里做 JS 点击
        （跨域 frame 内无法用顶层 CDP 鼠标事件精确命中）。 */
  const clickExpr = `(() => {
    var want = ${JSON.stringify(String(keyword || ''))};
    var items = Array.prototype.slice.call(document.querySelectorAll('.chapter_item'));
    var secs = items.filter(function (el) {
      var t = (el.innerText || '').replace(/\\s+/g, ' ').trim();
      return /^\\d+\\.\\d+/.test(t);
    });
    var pool = secs.length ? secs : items;
    /* 与上面定位逻辑保持同一套匹配规则（见前一处注释），避免「定位到了 A、点击了 B」 */
    var hit = null;
    if (want) {
      var nm2 = function (el) { return String(el.innerText || '').replace(/\\s+/g, ' ').trim(); };
      hit = pool.find(function (el) { return nm2(el) === want; });
      if (!hit) hit = pool.find(function (el) { return nm2(el).indexOf(want + ' ') === 0; });
      if (!hit) {
        var esc2 = want.split('').map(function (c) {
          return /[.*+?^\${}()|[\\]\\\\]/.test(c) ? '\\\\' + c : c;
        }).join('');
        var rex2 = new RegExp('^' + esc2 + '(?![0-9.])');
        hit = pool.find(function (el) { return rex2.test(nm2(el)); });
      }
      if (!hit) {
        hit = pool.find(function (el) {
          var s = nm2(el);
          var i = s.indexOf(want);
          if (i < 0) return false;
          if (i > 0 && /[0-9]/.test(s.charAt(i - 1))) return false;
          return true;
        });
      }
    } else {
      hit = pool[0];
    }
    if (!hit) return JSON.stringify({ ok: false });
    var t = hit.querySelector('a') || hit;
    try { t.click(); } catch (e) { return JSON.stringify({ ok: false, err: String(e.message || e).slice(0, 60) }); }
    return JSON.stringify({ ok: true });
  })()`;
  try {
    const r = await adapter.evalInFrameCross(cf.frameId, clickExpr);
    if (!r || !r.ok) return { ok: false, reason: '点击失败' };
  } catch (e) {
    return { ok: false, reason: 'click: ' + String((e && e.message) || e).slice(0, 90) };
  }
  logger.log('PROBE', 'INFO', '已点开小节（模拟点击·只读导航）', { text: hit.text });
  await sleep(5000);
  return { ok: true, text: hit.text };
}

/**
 * 扫描当前页面里所有 frame 的任务点（只读）。
 * 会穿透跨域 iframe，返回每个任务点的类型/完成状态/来源。
 */
async function scanTaskPoints(adapter) {
  const out = {
    at: new Date().toISOString(),
    frames: [],
    tasks: [],
    summary: { total: 0, video: 0, audio: 0, document: 0, quiz: 0, unknown: 0, finished: 0 },
  };

  const SCAN = `(() => {
    var d = document;
    var txt = function (el) { return (el && (el.innerText || el.textContent) || '').replace(/\\s+/g, ' ').trim(); };
    var tasks = [];
    d.querySelectorAll('.ans-attach-ct').forEach(function (el) {
      var icon = el.querySelector('.ans-job-icon');
      var ifr = el.querySelector('iframe');
      var src = ifr ? (ifr.getAttribute('src') || '') : '';
      var label = icon ? (icon.getAttribute('aria-label') || '') : '';
      var kind = 'unknown';
      if (/\\/modules\\/audio\\//i.test(src) || (ifr && ifr.getAttribute('module') === 'insertaudio')) kind = 'audio';
      else if (/\\/modules\\/video\\//i.test(src)) kind = 'video';
      else if (/work|quiz|exam/i.test(src)) kind = 'quiz';
      else if (/pdf|doc|read|screen/i.test(src)) kind = 'document';
      else if (el.querySelector('video,audio')) kind = 'video';
      tasks.push({
        kind: kind,
        finished: el.classList.contains('ans-job-finished') || /已完成|complete/i.test(label),
        iconLabel: label.slice(0, 24),
        src: src.slice(0, 120),
        text: txt(el).slice(0, 60),
      });
    });
    return JSON.stringify({
      url: (location.href || '').slice(0, 130),
      attachCt: d.querySelectorAll('.ans-attach-ct').length,
      jobIcon: d.querySelectorAll('.ans-job-icon').length,
      video: d.querySelectorAll('video').length,
      videoQuiz: d.querySelectorAll('.ans-videoquiz').length,
      tasks: tasks,
      body: txt(d.body).slice(0, 260),
    });
  })()`;

  const frames = await adapter.getFrameDocuments();
  for (const f of frames) {
    try {
      const res = f.isTop
        ? { ok: true, value: await adapter.evalInFrame(f.frameId, SCAN) }
        : await adapter.evalInFrameCross(f.frameId, SCAN);
      if (!res || !res.ok || !res.value) continue;
      let o; try { o = JSON.parse(res.value); } catch (_) { continue; }
      out.frames.push({
        depth: f.depth, url: String(o.url || '').slice(0, 130),
        attachCt: o.attachCt || 0, jobIcon: o.jobIcon || 0,
        video: o.video || 0, videoQuiz: o.videoQuiz || 0,
      });
      (o.tasks || []).forEach((t) => out.tasks.push(Object.assign({ frameDepth: f.depth }, t)));
    } catch (_) { /* 跳过读不到的 frame */ }
  }

  out.summary.total = out.tasks.length;
  for (const t of out.tasks) {
    if (out.summary[t.kind] !== undefined) out.summary[t.kind] += 1;
    if (t.finished) out.summary.finished += 1;
  }
  return out;
}

/**
 * ============================================================================
 * 批量扫描全部课程（只读）
 * ----------------------------------------------------------------------------
 * 对账号下每门课执行：进课程 → 点章节 → 读章节树 → 汇总。
 *
 * ★ 风控与稳定性要求：
 *   1. 全程模拟点击，不直接 navigate 到课程页
 *   2. 每门课之间随机停顿（默认 4~9 秒），避免高频访问
 *   3. 每门课结束后关闭多余标签页，防止 target 越堆越多
 *
 * ★ 安全边界：只读。不进小节、不播放、不答题。
 * ==========================================================================*/

/** 找到课程列表页的 target（用于把操作焦点切回去）。 */
async function findListTarget(cfg) {
  let list = [];
  try { list = await listTargets(cfg); } catch (_) { return null; }
  return list.find((t) => t.type === 'page' && /visit\/interaction|mooc1\.chaoxing\.com\/visit/i.test(t.url || '')) || null;
}

/** 关闭除「保留列表」之外的课程页标签（只关我们自己开的课程页）。 */
async function closeExtraCourseTabs(cfg, keepTargetId) {
  let list = [];
  try { list = await listTargets(cfg); } catch (_) { return 0; }
  const port = resolveCdpPort(cfg);
  if (!port) return 0;
  let closed = 0;
  for (const t of list) {
    if (t.type !== 'page') continue;
    if (keepTargetId && t.id === keepTargetId) continue;
    // 只关课程页/学习页，绝不动列表页和登录页
    if (!/mooc2-ans\.chaoxing\.com\/mooc2-ans\/mycourse\/stu|mycourse\/studentstudy|knowledge\/cards/i.test(t.url || '')) continue;
    try {
      await fetch('http://' + (cfg.cdp.host || '127.0.0.1') + ':' + port + '/json/close/' + t.id,
        { signal: AbortSignal.timeout(6000) });
      closed += 1;
    } catch (_) { /* ignore */ }
  }
  if (closed) logger.log('PROBE', 'INFO', '已关闭多余课程标签', { closed });
  return closed;
}

/** 从课程列表页读出去重后的课程清单（课程名 + 链接）。 */
async function readCourseList(adapter) {
  const frames = await adapter.getFrameDocuments();
  const top = frames.find((f) => f.isTop);
  if (!top) return [];
  const expr = `(() => {
    var out = [], seen = {};
    Array.prototype.slice.call(document.querySelectorAll('a[href]')).forEach(function (a) {
      var h = a.getAttribute('href') || '';
      var m = /courseid=(\\d+)/i.exec(h);
      if (!m) return;
      var cid = m[1];
      if (seen[cid]) return;
      // 取最近的有意义的文字作为课程名
      var t = (a.innerText || a.textContent || '').replace(/\\s+/g, ' ').trim();
      if (!t || t.length < 2) {
        var box = a.closest('li,div');
        if (box) t = (box.innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 60);
      }
      if (!t || t.length < 2) return;
      seen[cid] = 1;
      out.push({ courseId: cid, title: t.slice(0, 60), href: h.slice(0, 200) });
    });
    return JSON.stringify(out);
  })()`;
  try {
    const raw = await adapter.evalInFrame(top.frameId, expr);
    let arr; try { arr = JSON.parse(raw); } catch { arr = []; }
    return Array.isArray(arr) ? arr : [];
  } catch (_) { return []; }
}

/**
 * 批量扫描全部课程（只读）—— 慢速分批模式。
 * ----------------------------------------------------------------------------
 * ★ 风控策略（主人 2026-10-27 定：方案 C「分批慢扫」）：
 *   1. 课程之间随机间隔 25~45 秒（接近真人翻课节奏）
 *   2. 每扫完 batchSize 门（默认 5）额外休息 60~120 秒
 *   3. 每门课结束关闭多余标签，避免 target 堆积
 *   4. 全程模拟点击，不直接 navigate 课程 URL
 *
 * ★ 安全边界：只读。不进小节、不播放、不答题。
 */
async function scanAllCourses(adapter, opts) {
  const o = opts || {};
  const cfg = o.cfg || CONFIG;
  const limit = Math.max(1, Math.min(200, Number(o.limit) || 50));
  const gapMin = Number(o.gapMinMs) || 25000;
  const gapMax = Number(o.gapMaxMs) || 45000;
  const batchSize = Math.max(1, Number(o.batchSize) || 5);
  const batchRestMin = Number(o.batchRestMinMs) || 60000;
  const batchRestMax = Number(o.batchRestMaxMs) || 120000;

  const result = {
    at: new Date().toISOString(),
    total: 0,
    scanned: 0,
    ok: 0,
    failed: 0,
    batchSize,
    courses: [],
  };

  // 1) 回到课程列表页
  await adapter.navigate('https://mooc1.chaoxing.com/visit/interaction');
  await sleep(8000);

  // 2) 读课程清单
  const list = await readCourseList(adapter);
  result.total = list.length;
  logger.log('PROBE', 'INFO', '发现课程', { count: list.length, willScan: Math.min(limit, list.length) });

  const targets = list.slice(0, limit);
  for (let i = 0; i < targets.length; i++) {
    const c = targets[i];
    const rec = {
      index: i + 1,
      courseId: c.courseId,
      title: c.title,
      ok: false,
      pageKind: '',
      chapterCount: 0,
      sectionCount: 0,
      chapters: [],
      note: '',
    };
    logger.log('PROBE', 'INFO', '扫描课程 ' + (i + 1) + '/' + targets.length, { title: c.title });

    try {
      /* 切回列表页 target（不要 navigate，避免冲掉标签池） */
      const listTarget = await findListTarget(cfg);
      if (!listTarget) {
        await adapter.navigate('https://mooc1.chaoxing.com/visit/interaction');
        await sleep(6000);
      } else {
        try { await adapter.attachTarget(listTarget.id); } catch (_) { /* ignore */ }
        await sleep(1500);
      }

      const opened = await openCourseByClick(adapter, c.title, {
        maxWaitMs: 25000, cfg, courseId: c.courseId,
      });
      if (!opened.ok) {
        rec.note = '进入失败: ' + opened.reason;
        result.failed += 1;
        result.courses.push(rec);
        result.scanned += 1;
        await closeExtraCourseTabs(cfg, listTarget ? listTarget.id : null);
        continue;
      }

      // ★ 进课程后先等页面稳定，再点章节（实测布局未稳时点不到）
      await sleep(5000);

      const chRes = await openChapterAndWait(adapter, cfg, { maxRound: 2 });
      if (!chRes.ok) {
        /* ★ 先判断是不是「任务型课程」（没有章节树，只有活动列表）。
           实测「典型建模技术」「优化理论与方法」属于这类，
           帧里是 stuActiveList，整页没有任何 chapter 元素。
           这不是失败，是课程结构不同，应记为 task-type 并算成功扫描。 */
        const tt = await detectTaskTypeCourse(adapter);
        if (tt.taskType) {
          rec.note = `无章节内容（${tt.kind || '任务型'}）`;
          rec.pageKind = 'no-content';
          rec.ok = true;
          result.ok += 1;
          logger.log('PROBE', 'INFO', '课程无章节内容，跳过章节树识别', {
            kind: tt.kind, url: String(tt.url || '').slice(0, 80), sample: tt.sample || '',
          });
          result.courses.push(rec);
          result.scanned += 1;
          await closeExtraCourseTabs(cfg, listTarget ? listTarget.id : null);
          continue;
        }
        const st = await probePageStructure(adapter, { maxDepth: 1, maxFrames: 3 });
        const topF = st.frames.find((x) => x.isTop);
        const hasTab = ((topF && topF.navTabs) || []).some((t) => t.text === '章节');
        if (!hasTab) {
          rec.note = '该课程无「章节」tab（直播/任务型）';
          rec.pageKind = 'no-chapter-tab';
          rec.ok = true;
          result.ok += 1;
        } else {
          rec.note = '章节 iframe 未加载';
          rec.pageKind = 'chapter-timeout';
          result.failed += 1;
        }
        result.courses.push(rec);
        result.scanned += 1;
        await closeExtraCourseTabs(cfg, listTarget ? listTarget.id : null);
        continue;
      }

      // 读章节树
      const struct = await probePageStructure(adapter, { maxDepth: 3, maxFrames: 12 });
      const chapterFrame = struct.frames.find((f) => (f.chapters && f.chapters.length));
      if (chapterFrame) {
        rec.chapters = chapterFrame.chapters.map((x) => ({
          head: String(x.head || '').slice(0, 50),
          itemCount: x.itemCount || 0,
        }));
        rec.chapterCount = chapterFrame.chapters.length;
        rec.sectionCount = chapterFrame.chapters.reduce((n, x) => n + (x.itemCount || 0), 0);
      }
      rec.pageKind = 'mooc2-home';
      rec.ok = rec.chapterCount > 0;
      if (rec.ok) result.ok += 1; else result.failed += 1;
      if (!rec.chapterCount) rec.note = '未识别到章节树';
    } catch (e) {
      rec.note = '异常: ' + String((e && e.message) || e).slice(0, 100);
      result.failed += 1;
    }

    result.scanned += 1;
    result.courses.push(rec);
    if (typeof o.onEach === 'function') { try { o.onEach(rec) } catch (_) { /* ignore */ } }

    // 清理标签
    await closeExtraCourseTabs(cfg, null);

    if (i < targets.length - 1) {
      /* 批次休息：每 batchSize 门额外停久一点 */
      const isBatchEnd = (i + 1) % batchSize === 0;
      let gap;
      if (isBatchEnd) {
        gap = batchRestMin + Math.floor(Math.random() * Math.max(1, batchRestMax - batchRestMin));
        logger.log('PROBE', 'INFO', `本批 ${batchSize} 门完成，休息 ${Math.round(gap / 1000)}s（防风控）`);
      } else {
        gap = gapMin + Math.floor(Math.random() * Math.max(1, gapMax - gapMin));
        logger.log('PROBE', 'INFO', `停顿 ${Math.round(gap / 1000)}s 后继续`);
      }
      await sleep(gap);
    }
  }

  return result;
}

/**
 * 课程识别报告（只读）
 * ----------------------------------------------------------------------------
 * 输出一门课程的完整结构：章节树 + 每节状态 + 任务点 + 测验线索。
 *
 * ★ 安全边界：全程只读。不播放、不点学习元素、不答题、不提交。
 *   唯一允许的点击是「章节」tab（纯导航，等同于用户翻页）。
 *
 * 实测数据来源：化工热力学（courseid=227957344），
 *   .chapter_unit=7（章）、.chapter_item=32（节）、总任务 36。
 * ==========================================================================*/
async function buildCourseReport(adapter, opts) {
  const o = opts || {};
  const report = {
    at: new Date().toISOString(),
    reason: '',
    courseUrl: '',
    pageKind: 'unknown',
    navTabs: [],
    chapters: [],
    chapterCount: 0,
    sectionCount: 0,
    taskSummary: { total: 0, attachCt: 0, jobIcon: 0, videos: 0, quizLike: 0 },
    frames: [],
  };

  // ── 第 1 步：先看当前页是什么 ──
  let struct = await probePageStructure(adapter, { maxDepth: 2, maxFrames: 8 });
  report.pageKind = struct.summary.pageKind;
  const topFrame = struct.frames.find((f) => f.isTop);
  if (topFrame) {
    report.courseUrl = topFrame.url || '';
    report.navTabs = (topFrame.navTabs || []).map((t) => t.text).filter(Boolean);
  }

  // ── 第 2 步：新版课程主页 → 点「章节」tab（唯一允许的点击） ──
  if (report.pageKind === 'mooc2-home') {
    logger.log('PROBE', 'INFO', '识别到新版课程主页，点开「章节」tab 继续（只读导航）');
    const r = await openChapterTab(adapter);
    if (!r.ok) {
      report.reason = '点「章节」失败: ' + (r.reason || 'unknown');
      return report;
    }
    /* ★ 点完「章节」会触发一次页面导航。实测有两种情况：
       a) 页面原地换 iframe → 直接等 studentcourse
       b) 整页重载（URL 的 pageHeader 变化）→ 重载后又回到「任务」tab，
          需要再点一次「章节」
       所以这里做成：等待 → 若超时则再点一次 → 再等。 */
    let ready = await waitForChapterFrame(adapter, 15000);
    if (!ready) {
      logger.log('PROBE', 'INFO', '首次等待超时，页面可能整页重载了，再点一次「章节」');
      const again = await openChapterTab(adapter);
      logger.log('PROBE', 'INFO', '补点「章节」结果', { ok: !!(again && again.ok) });
      ready = await waitForChapterFrame(adapter, 20000);
    }
    if (!ready) {
      report.reason = '点了「章节」但章节 iframe 未加载出来（可能需要人工点一次确认）';
      return report;
    }
    struct = await probePageStructure(adapter, { maxDepth: 4, maxFrames: 20 });
    report.pageKind = struct.summary.pageKind;
  }

  // ── 第 3 步：汇总裁剪 ──
  report.frames = struct.frames.map((f) => ({
    depth: f.depth,
    url: String(f.url || '').slice(0, 140),
    kind: f.kind,
    chapterCandidates: f.chapterCandidates || [],
  }));

  // 章节树（来自 studentcourse iframe）
  const chapterFrame = struct.frames.find((f) => (f.chapters && f.chapters.length));
  if (chapterFrame) {
    report.chapters = chapterFrame.chapters;
    report.chapterCount = chapterFrame.chapters.length;
    report.sectionCount = chapterFrame.chapters.reduce((n, c) => n + (c.itemCount || 0), 0);
    report.taskSummary.attachCt = chapterFrame.attachCt || 0;
    report.taskSummary.jobIcon = chapterFrame.jobIcon || 0;
    report.taskSummary.videos = chapterFrame.videos || 0;
  }

  const s = struct.summary || {};
  report.taskSummary.total = s.taskItems || 0;
  report.taskSummary.quizLike = s.quizForms || 0;
  if (!report.reason) {
    report.reason = report.chapterCount
      ? '已识别章节树（' + report.chapterCount + ' 章 / ' + report.sectionCount + ' 节）'
      : '未找到章节树（该课程可能是直播/纯任务型，无章节结构）';
  }
  return report;
}

/** 列出账号下的课程：用 CDP 打开首页，等 JS 渲染完再读 DOM。 */
async function runListCourses(overrides) {
  const cfg = mergeConfig(CONFIG, overrides || {});
  const adapter = createCdpAdapter(cfg);
  await adapter.ensureBrowser();
  await adapter.navigate('https://mooc1.chaoxing.com/visit/interaction');
  await sleep(6000);
  const frames = await adapter.getFrameDocuments();
  const found = [];
  const seen = new Set();
  const expr = [
    '(() => {',
    '  const out = [];',
    '  document.querySelectorAll("a[href]").forEach(function(a){',
    '    const h = a.getAttribute("href") || a.href || "";',
    '    if (!/courseid=\\d+/i.test(h)) return;',
    '    let t = "", el = a;',
    '    for (let k = 0; k < 6 && el; k++) {',
    '      const x = (el.innerText || "").replace(/\\s+/g, " ").trim();',
    '      if (x.length > 1 && x.length < 80) { t = x; break; }',
    '      el = el.parentElement;',
    '    }',
    '    out.push({ href: h, text: t.slice(0, 60) });',
    '  });',
    '  return out;',
    '})()',
  ].join('\n');
  for (const f of frames) {
    let list = [];
    try { list = await adapter.evalInFrame(f.frameId, expr); } catch (e) { list = []; }
    if (!Array.isArray(list)) continue;
    for (const it of list) {
      const m = /courseid=(\d+)/i.exec(it.href || '');
      if (!m) continue;
      const cid = m[1];
      if (seen.has(cid)) continue;
      seen.add(cid);
      const cl = /clazzid=(\d+)/i.exec(it.href || '');
      const en = /enc=([a-z0-9]{8,})/i.exec(it.href || '');
      found.push({ courseId: cid, clazzid: cl ? cl[1] : '', enc: en ? en[1] : '', title: it.text || '', href: it.href || '' });
    }
  }
  const diag = {};
  try {
    const top = frames.find(function (f) { return f.isTop; }) || frames[0];
    if (top) {
      diag.frames = frames.length;
      diag.title = await adapter.evalInFrame(top.frameId, 'document.title');
      diag.url = await adapter.getCurrentUrl();
      diag.htmlLen = await adapter.evalInFrame(top.frameId, 'document.documentElement.outerHTML.length');
      diag.linkCount = await adapter.evalInFrame(top.frameId, 'document.querySelectorAll("a").length');
      diag.bodyText = await adapter.evalInFrame(top.frameId, '(document.body ? document.body.innerText : "").slice(0, 600)');
      diag.sampleHrefs = await adapter.evalInFrame(top.frameId,
        'Array.prototype.slice.call(document.querySelectorAll("a[href]"),0,15).map(function(a){return (a.getAttribute("href")||"").slice(0,80)})');
    }
  } catch (e) { diag.err = String((e && e.message) || e); }
  return { ok: true, count: found.length, courses: found, diag: diag };
}

module.exports = { run, runLogin, checkLoginState, CONFIG, SELECTORS, humanize, logger, LearnMachine, createCdpAdapter, createMockAdapter, serveMcp, selfTest, mergeConfig, runListCourses, installProbeExpression, VERSION,
  /* 2026-10-29 内核静默控制：启动参数构造与端口发现（纯函数，便于独立测试） */
  buildChromiumArgs, mergeChromiumArgs, readDevToolsActivePort, isHeadlessShellKernel, resolveCdpPort,
  /* 2026-10-29 启动失败归因：退出码翻译 / profile 占用与可写性探测 */
  describeLaunchExit, inspectProfileLock, isProfileWritable, CHROMIUM_EXIT_CODES,
  isBareCommandName };

/* CLI 入口 */
if (require.main === module) {
  const args = parseArgs(process.argv.slice(2));
  if (args['self-test']) {
    selfTest().then((ok) => process.exit(ok ? 0 : 1)).catch((e) => { console.error('自测异常:', e && e.stack || e); process.exit(1); });
  } else if (args['check-login']) {
    /* 登录态预检：只访问个人空间判断是否已登录，不开二维码。宿主 start 前调用。 */
    checkLoginState()
      .then((r) => { console.log(JSON.stringify(r)); process.exit(r.ok && r.loggedIn ? 0 : 3); })
      .catch((e) => { console.error('FATAL:', e && e.stack || e); process.exit(1); });
  } else if (args['probe']) {
    /* ★ 只读结构识别：扫描课程页结构（含跨域 iframe 穿透），
       不播放、不点击、不答题、不提交。主人 2026-10-27 要求先定框架再试播放。 */
    (async () => {
      const cfg = mergeConfig(CONFIG, {});
      const adapter = createCdpAdapter(cfg);
      try {
        await adapter.ensureBrowser();
        const target = args['course-url'] ? String(args['course-url']) : '';
        if (target) {
          console.log('[probe] navigate -> ' + target.slice(0, 140));
          await adapter.navigate(target);
          await sleep(5000);
        }
        // 新版课程主页：先点开「章节」tab，否则章节树不会加载
        const firstPass = await probePageStructure(adapter, { maxDepth: 2, maxFrames: 6 });
        if (firstPass.summary && firstPass.summary.pageKind === 'mooc2-home') {
          console.log('[probe] 检测到新版课程主页，点开「章节」tab');
          const r = await openChapterTab(adapter);
          if (r.ok) await sleep(4000);
          else console.log('[probe] 未能点开章节: ' + (r.reason || ''));
        }
        const report = await probePageStructure(adapter, {
          maxDepth: Number(args['max-depth'] || 4),
          maxFrames: Number(args['max-frames'] || 20),
        });
        console.log(JSON.stringify(report, null, 2));
        process.exit(0);
      } catch (e) {
        console.error('FATAL: ' + String((e && e.stack) || e).slice(0, 800));
        process.exit(1);
      }
    })();
  } else if (args['course-report']) {
    /* ★ 完整课程识别报告：章节树 + 每节状态 + 任务点（只读，不播放不答题）
       ★ 风控要求：进课程必须模拟点击，不能直接 navigate。 */
    (async () => {
      const cfg = mergeConfig(CONFIG, {});
      const adapter = createCdpAdapter(cfg);
      try {
        await adapter.ensureBrowser();
        // 唯一允许的 navigate：打开学习通首页/课程列表（之后全部走点击）
        const landing = args['course-url'] ? String(args['course-url']) : 'https://mooc1.chaoxing.com/visit/interaction';
        console.log('[report] navigate(landing) -> ' + landing.slice(0, 140));
        await adapter.navigate(landing);
        await sleep(7000);

        // 若当前还不在课程页，按课程名模拟点击进入
        let cur = '';
        try { cur = await adapter.getCurrentUrl(); } catch (_) { cur = ''; }
        const onCourse = /mooc2-ans\.chaoxing\.com\/mooc2-ans\/mycourse\/stu/i.test(cur);
        if (!onCourse) {
          const kw = args.course ? String(args.course) : '';
          const r = await openCourseByClick(adapter, kw, { maxWaitMs: 30000, cfg });
          if (!r.ok) {
            console.log(JSON.stringify({ reason: '进入课程失败: ' + r.reason, step: 'openCourseByClick' }, null, 2));
            process.exit(2);
          }
        }
        const rep = await buildCourseReport(adapter, {});
        console.log(JSON.stringify(rep, null, 2));
        process.exit(0);
      } catch (e) {
        console.error('FATAL: ' + String((e && e.stack) || e).slice(0, 800));
        process.exit(1);
      }
    })();
  } else if (args['scan-all']) {
    /* ★ 批量扫描全部课程（只读）：不播放、不答题，只出识别报告 */
    (async () => {
      const cfg = mergeConfig(CONFIG, {});
      const adapter = createCdpAdapter(cfg);
      try {
        await adapter.ensureBrowser();
        const rep = await scanAllCourses(adapter, {
          cfg,
          limit: Number(args.limit || 0) || 5,
          gapMinMs: Number(args['gap-min'] || 0) || 25000,
          gapMaxMs: Number(args['gap-max'] || 0) || 45000,
          batchSize: Number(args['batch-size'] || 0) || 5,
          batchRestMinMs: Number(args['batch-rest-min'] || 0) || 60000,
          batchRestMaxMs: Number(args['batch-rest-max'] || 0) || 120000,
        });
        console.log(JSON.stringify(rep, null, 2));
        process.exit(0);
      } catch (e) {
        console.error('FATAL: ' + String((e && e.stack) || e).slice(0, 900));
        process.exit(1);
      }
    })();
  } else if (args['section-report']) {
    /* ★ 识别指定小节的任务点（只读：点章节 tab + 点小节，不播放不答题） */
    (async () => {
      const cfg = mergeConfig(CONFIG, {});
      const adapter = createCdpAdapter(cfg);
      try {
        await adapter.ensureBrowser();
        const landing = 'https://mooc1.chaoxing.com/visit/interaction';
        console.log('[section] navigate(landing) -> ' + landing);
        await adapter.navigate(landing);
        await sleep(7000);

        // 1) 模拟点击进入课程
        const kw = args.course ? String(args.course) : '';
        const r = await openCourseByClick(adapter, kw, { maxWaitMs: 30000, cfg });
        if (!r.ok) {
          console.log(JSON.stringify({ reason: '进入课程失败: ' + r.reason }, null, 2));
          process.exit(2);
        }

        // 2) 点「章节」tab
        const ch = await openChapterTab(adapter);
        if (!ch.ok) {
          console.log(JSON.stringify({ reason: '点章节失败: ' + ch.reason }, null, 2));
          process.exit(2);
        }
        const ready = await waitForChapterFrame(adapter, 25000);
        if (!ready) {
          console.log(JSON.stringify({ reason: '章节 iframe 未就绪' }, null, 2));
          process.exit(2);
        }

        // 3) 点开指定小节
        const sec = args.section ? String(args.section) : '';
        const so = await openSectionByClick(adapter, sec);
        if (!so.ok) {
          console.log(JSON.stringify({ reason: '点小节失败: ' + so.reason }, null, 2));
          process.exit(2);
        }
        console.log('[section] 已打开: ' + so.text);

        // 4) 等加载后扫描任务点
        await sleep(6000);
        const scan = await scanTaskPoints(adapter);
        console.log(JSON.stringify(scan, null, 2));
        process.exit(0);
      } catch (e) {
        console.error('FATAL: ' + String((e && e.stack) || e).slice(0, 800));
        process.exit(1);
      }
    })();
  } else if (args['serve-mcp']) {
    serveMcp();
  } else if (args['list-courses']) {
    runListCourses()
      .then((r) => { console.log(JSON.stringify(r, null, 2)); process.exit(r.ok ? 0 : 2); })
      .catch((e) => { console.error('FATAL:', e && e.stack || e); process.exit(1); });
  } else if (args.login) {
    /* 一次性扫码登录：node chaoxing-autolearn.js --login
       截图实时写入 CONFIG.login.shotDir/latest.png，手机学习通 App 扫码即可 */
    runLogin()
      .then((r) => { console.log(JSON.stringify(r, null, 2)); process.exit(r.ok ? 0 : 2); })
      .catch((e) => { console.error('FATAL:', e && e.stack || e); process.exit(1); });
  } else {
    const overrides = {};
    if (args.mode) overrides.mode = String(args.mode);
    if (args['max-sections']) overrides.maxSections = Number(args['max-sections']);
    if (args['course-url']) overrides.course = { url: String(args['course-url']) };
    if (args['cdp-port']) overrides.cdp = { port: Number(args['cdp-port']) };
    if (args.chromium) overrides.chromium = { executablePath: String(args.chromium) };
    run(overrides)
      .then((r) => {
        console.log('\n=== RESULT ===');
        console.log(JSON.stringify(Object.assign({}, r, { logs: r.logs.slice(-12) }), null, 2));
        process.exit(r.ok ? 0 : 2);
      })
      .catch((e) => { console.error('FATAL:', e && e.stack || e); process.exit(1); });
  }
}

/* ============================================================================
 * 第 10 节 · 适配指南 —— 实际 DSH 环境与本文件假设不一致时改哪里
 * ----------------------------------------------------------------------------
 * A) 已装 browser_* MCP 工具（工具名形如 mcp__browser__navigate/_click/_evaluate）：
 *    只需替换 createCdpAdapter 中 5 个带语义边界的函数体，业务层（第 6-7 节）零改动：
 *      ensureBrowser()      → 调用 mcp__browser__connect / __newContext（或直接返回 {engine:'bridge'}）
 *      navigate(url)        → await mcp__browser__navigate({ url })
 *      getFrameDocuments()  → 调用 __snapshot / __listFrames，映射为 [{frameId,url,isTop}]
 *      evalInFrame(fid,expr)→ await mcp__browser__evaluate({ frameId, expression: expr })
 *      click(fid, rect)     → await mcp__browser__click({ frameId, x, y })（或按 ref 点击）
 *    注册方式（DSH 官方 mcp-bundle 模板，configuration-only bundle 两个文件）：
 *      package.json:
 *        { "name": "@local/cx-auto-learn", "version": "1.0.0", "private": true,
 *          "type": "module", "dsh": { "bundle": { "patch": "./cordis.patch.yml" } } }
 *      cordis.patch.yml（stdio 指向本文件；env 注入浏览器路径/profile/端口，均可省）:
 *        - insert:
 *            - id: cx-auto-learn
 *              name: '@deepseek-ai/dsh-mcp-client'
 *              config:
 *                serverName: cx
 *                transport: stdio
 *                command: node
 *                args: ["/绝对路径/chaoxing-autolearn.js", "--serve-mcp"]
 *                env:
 *                  CX_CHROMIUM: "/绝对路径/chrome-headless-shell"
 *                  CX_PROFILE_DIR: "/绝对路径/.cx-profile"
 *                  CX_CDP_PORT: "9333"
 *                failOnStartupError: true
 *      安装后 Agent 即获得 mcp__cx__cx_learn（刷课）与 mcp__cx__cx_login（扫码登录）
 *      两个工具；本文件 --serve-mcp 模式已实现 initialize / tools/list / tools/call
 *      全流程（零依赖，日志走 stderr 不污染协议）。
 *      实测可用的免 root 浏览器（含 H.264/AAC 解码，canPlayType 实测 "probably"）：
 *      npmmirror chrome-for-testing 的 chrome-headless-shell-linux64.zip，解压即用。
 *
 * A+) 首次使用（真实环境）：`node chaoxing-autolearn.js --login` 或调 cx_login 工具。
 *     脚本打开登录页二维码，每 2.5s 截图到 CONFIG.login.shotDir/latest.png，
 *     用户手机「学习通」App 扫截图里的码并确认即登录成功；二维码每 60s 自动刷新。
 *     登录态持久化在 CX_PROFILE_DIR，之后刷课任务直接复用，无需重复扫码。
 *     全程不接触账密、不自动填表、不绕过任何验证。
 *
 * B) CDP 端点不同：设环境变量 CX_CDP_PORT，或 overrides.cdp = { host, port }。
 *    附着远端调试的已有浏览器：把 cdp.host 指向该主机并确保 /json 端点可达。
 *
 * C) 容器内没有 Chromium：fnOS Docker 中可用 `apk add chromium`（Alpine）或
 *    `apt-get install -y chromium`（Debian 基镜像），再设 CX_CHROMIUM=/usr/bin/chromium-...
 *    也可改用带 Chromium 的基础镜像。启动失败会以 CHROMIUM_LAUNCH_FAILED / CDP_ATTACH_FAILED
 *    明确报错，不会静默降级到 HTTP 路径（不做任何进度伪造类请求）。
 *
 * D) 原语签名不一致：只需改 createCdpAdapter 内对应函数（navigate / getFrameDocuments /
 *    evalInFrame / click / jsClick / getText / isVideoEnded / getCurrentUrl）；
 *    第 6-7 节状态机、第 3-5 节 humanize/logger/探测模块均不应被修改。
 *
 * E) 后台任务与定时：
 *    - DSH 后台 bash job：`node /绝对路径/chaoxing-autolearn.js --mode=current_chapter`
 *    - NAS cron / DSH schedule：错峰执行（如 02:17），命令加 `--max-sections=5`
 *    - 环境变量：CX_COURSE_URL / CX_CHROMIUM / CX_PROFILE_DIR / CX_CDP_PORT / CX_LOG_FILE
 *
 * F) 已知限制（诚实声明）：
 *    - 跨域 iframe（OOPIF）无法用 Input 事件命中：rectOf 检测到 cross 时自动降级
 *      页内 JS click 并输出 WARN；学习通主流程 iframe 为同源，不受影响。
 *    - 学习通目录/弹窗模板随课程变化：三层策略 + 候选注册表已缓解；若全部候选失效，
 *      按 maxConsecutiveFailures 停止并输出诊断，不会无限重试或误点。
 *    - 弹题作答不查题库，答错不重试；依赖平台"作答即放行"的行为。
 * ==========================================================================*/
