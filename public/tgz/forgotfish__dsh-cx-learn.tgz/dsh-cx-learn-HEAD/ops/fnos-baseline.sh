#!/bin/sh
# fnos-baseline.sh —— 飞牛 fnOS 上 dsh-cx-learn 的**纯只读**基线采集（2026-10-30）
#
# 用途：一次性把排障需要的现场全部抓下来，人看的部分在上、机器可读 JSON 在末尾。
#      适合「出问题前后各跑一次，diff 两份 JSON」。
#
# 只读承诺：
#   · 只调用 systemctl is-active / show / list-units，不 start/stop/restart
#   · 只读文件，不写 /vol1；脚本本身不创建任何文件（输出走 stdout，重定向由调用者决定）
#   · 不 pkill / 不 killall / 不按进程名模糊杀
#   · 不打印 cookie / token / 口令：run.log 的凭据类行会被过滤，URL 的 cpi/enc/token 打码
#
# 单条采集失败不中断：每个采集块都容错，缺命令 / 没权限只显示 unavailable。
#
# 用法：
#   sh ops/fnos-baseline.sh                 # 人看 + 末尾 JSON
#   sh ops/fnos-baseline.sh > /tmp/base.txt # 存一份
#
# 环境变量（一般不用改）：
#   DSH_HOME       默认 /vol1/@apphome/fn-deepseek-harness
#   CX_PORT        默认 3290
#   CX_PLUGIN_DIR  默认 /vol1/@apphome/dsh-shared/lib/node_modules/dsh-cx-learn
#   CX_CHROME_PATH 默认 /vol1/@apphome/dsh-shared/browsers/chrome-linux64/chrome
#
# 退出码：0 = 采集完成（内容好坏看报告）；20 = 基础命令缺失，无法采集。

set -u

DSH_HOME=${DSH_HOME:-/vol1/@apphome/fn-deepseek-harness}
CX_PORT=${CX_PORT:-3290}
PLUGIN_DIR=${CX_PLUGIN_DIR:-/vol1/@apphome/dsh-shared/lib/node_modules/dsh-cx-learn}
CHROME=${CX_CHROME_PATH:-/vol1/@apphome/dsh-shared/browsers/chrome-linux64/chrome}
STATE_DIR=$DSH_HOME/cx-learn
API="http://127.0.0.1:$CX_PORT/api/cx-learn"

# ── 小工具 ──────────────────────────────────────────────────────────────────
if [ -t 1 ]; then
  RED=$(printf '\033[31m'); YEL=$(printf '\033[33m'); GRN=$(printf '\033[32m'); RST=$(printf '\033[0m')
else
  RED=''; YEL=''; GRN=''; RST=''
fi

sec()  { printf '\n== %s ==\n' "$*"; }
kv()   { printf '  %-24s %s\n' "$1" "$2"; }
good() { printf '  %s[OK]%s   %s\n' "$GRN" "$RST" "$*"; }
warn() { printf '  %s[!!]%s   %s\n' "$YEL" "$RST" "$*"; }
bad()  { printf '  %s[!!]%s   %s\n' "$RED" "$RST" "$*"; }
na()   { printf '  [--]   %s\n' "$*"; }

# JSON 字符串转义（用于单行标量）
esc() { printf '%s' "$1" | tr -d '\r' | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/\t/ /g'; }

# 有值 → "value"，空 → null（用于 JSON 片段）
jstr_or_null() {
  if [ -z "${1:-}" ]; then printf 'null'; else printf '"%s"' "$(esc "$1")"; fi
}
# 整数就用原样，否则 null
uint_or_null() {
  case "${1:-}" in
    ''|*[!0-9]*) printf 'null' ;;
    *) printf '%s' "$1" ;;
  esac
}

# 从 JSON 文件里取第一个 "key": "value"
jstr() {
  [ -f "${1:-}" ] || return 0
  grep -o "\"$2\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" "$1" 2>/dev/null | head -n 1 \
    | sed -e 's/^"[^"]*"[[:space:]]*:[[:space:]]*"//' -e 's/"$//'
}
# 取第一个 "key": 123 / true / null
jraw() {
  [ -f "${1:-}" ] || return 0
  grep -o "\"$2\"[[:space:]]*:[[:space:]]*[^,}]*" "$1" 2>/dev/null | head -n 1 \
    | sed -e 's/^"[^"]*"[[:space:]]*:[[:space:]]*//' -e 's/[[:space:]]*$//'
}
# HTTP 状态码；失败给 000（curl 失败时自己也会打 000，先抓值再判断，别拼成 "000000"）
http_code() {
  HC=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$1" 2>/dev/null)
  case "${HC:-}" in
    ''|*[!0-9]*) printf '000' ;;
    *) printf '%s' "$HC" ;;
  esac
}
# 过滤疑似凭据行（run.log 兜底：宁可少看一行，也不泄密）
scrub() { grep -viE 'cookie|authorization|password|passwd|secret|token=' ; }
# 打码 URL / JSON 里的会话参数（cpi、enc、token、二维码 uuid）
redact() {
  sed -e 's/\([?&]cpi=\)[^&" ]*/\1***/g' \
      -e 's/\([?&]enc=\)[^&" ]*/\1***/g' \
      -e 's/\([?&]token=\)[^&" ]*/\1***/g' \
      -e 's/\([?&]uuid=\)[^&" ]*/\1***/g' \
      -e 's/"uuid":"[^"]*"/"uuid":"***"/g'
}

AT=$(date '+%Y-%m-%dT%H:%M:%S%z' 2>/dev/null || echo unknown)

for need in cat date df awk sed grep; do
  command -v "$need" >/dev/null 2>&1 || { echo "缺少基础命令：$need" >&2; exit 20; }
done

printf 'fnOS baseline · dsh-cx-learn\n'
printf '采集时间 %s · 主机 %s · 执行者 %s\n' "$AT" "$(hostname 2>/dev/null || echo unknown)" "$(id -un 2>/dev/null || echo unknown)"

# ── 1. 主机 ─────────────────────────────────────────────────────────────────
sec '1. 主机 / 负载 / 内存'
HOST=$(hostname 2>/dev/null || echo unknown)
kv hostname "$HOST"

UPTIME_RAW=$(uptime 2>/dev/null || true)
kv uptime "${UPTIME_RAW:-unavailable}"

LOAD1=''; LOAD5=''; LOAD15=''
if [ -r /proc/loadavg ]; then
  set -- $(cat /proc/loadavg 2>/dev/null)
  LOAD1=${1:-}; LOAD5=${2:-}; LOAD15=${3:-}
fi
kv 'load (1/5/15)' "${LOAD1:-?} / ${LOAD5:-?} / ${LOAD15:-?}"

MEM_TOTAL_MB=''; MEM_AVAIL_MB=''; MEM_USED_MB=''
if command -v free >/dev/null 2>&1; then
  set -- $(free -m 2>/dev/null | awk '$1=="Mem:"{print $2, $3, $7}')
  MEM_TOTAL_MB=${1:-}; MEM_USED_MB=${2:-}; MEM_AVAIL_MB=${3:-}
  kv 'memory MB' "total=${MEM_TOTAL_MB:-?} used=${MEM_USED_MB:-?} available=${MEM_AVAIL_MB:-?}"
  if [ -n "${MEM_AVAIL_MB:-}" ] && [ "$MEM_AVAIL_MB" -lt 512 ] 2>/dev/null; then
    warn '可用内存 < 512MB，无头内核随时可能起不来'
  fi
else
  na 'free 不可用'
fi

# ── 2. 磁盘 ─────────────────────────────────────────────────────────────────
sec '2. 磁盘'
DISK_ROOT=$(df -h / 2>/dev/null | awk 'NR==2{print $2" total, "$3" used, "$4" avail, "$5}')
DISK_VOL1=$(df -h /vol1 2>/dev/null | awk 'NR==2{print $2" total, "$3" used, "$4" avail, "$5}')
kv '/'     "${DISK_ROOT:-unavailable}"
kv '/vol1' "${DISK_VOL1:-unavailable}"
ROOT_AVAIL_KB=$(df -k / 2>/dev/null | awk 'NR==2{print $4}')

# ── 3. /dev/shm ─────────────────────────────────────────────────────────────
sec '3. /dev/shm（无头内核崩溃头号原因）'
SHM_H=$(df -h /dev/shm 2>/dev/null | awk 'NR==2{print $2" total, "$3" used, "$4" avail ("$5")"}')
SHM_AVAIL_KB=$(df -k /dev/shm 2>/dev/null | awk 'NR==2{print $4}')
SHM_AVAIL_MB=''
case "${SHM_AVAIL_KB:-}" in
  ''|*[!0-9]*) SHM_AVAIL_MB='' ;;
  *) SHM_AVAIL_MB=$((SHM_AVAIL_KB / 1024)) ;;
esac
kv '/dev/shm' "${SHM_H:-unavailable}"
SHM_STATE=unknown
if [ -n "$SHM_AVAIL_MB" ]; then
  if [ "$SHM_AVAIL_MB" -lt 256 ]; then
    bad "/dev/shm 可用 ${SHM_AVAIL_MB}MB < 256MB —— 无头 Chrome 会随机崩溃"
    SHM_STATE=low
  else
    good "/dev/shm 可用 ${SHM_AVAIL_MB}MB（>= 256MB）"
    SHM_STATE=ok
  fi
else
  na '/dev/shm 容量读不到'
fi

# ── 4. OOM ──────────────────────────────────────────────────────────────────
sec '4. dmesg OOM（需要 root）'
OOM_STATE=unavailable
OOM_LINES=''
if command -v dmesg >/dev/null 2>&1; then
  DMESG_ALL=$(dmesg -T 2>/dev/null || true)
  if [ -n "$DMESG_ALL" ]; then
    OOM_LINES=$(printf '%s\n' "$DMESG_ALL" | grep -iE 'out of memory|oom-kill|oom_reaper|killed process' | tail -n 5)
    if [ -n "$OOM_LINES" ]; then
      OOM_STATE=found
      printf '%s\n' "$OOM_LINES" | sed 's/^/  /'
    else
      OOM_STATE=none
      good '最近没有 OOM 记录'
    fi
  else
    na 'unavailable（dmesg 需要 root，取不到内核缓冲区）'
  fi
else
  na 'unavailable（没有 dmesg 命令）'
fi

# ── 5. systemd ──────────────────────────────────────────────────────────────
sec '5. systemd 单元'
UNIT_STATE=$(systemctl is-active dsh-admin 2>/dev/null || true)
UNIT_SUB=$(systemctl show dsh-admin -p SubState --value 2>/dev/null || true)
UNIT_ENABLED=$(systemctl show dsh-admin -p UnitFileState --value 2>/dev/null || true)
ADMIN_PID=$(systemctl show dsh-admin -p MainPID --value 2>/dev/null || true)
kv 'dsh-admin' "${UNIT_STATE:-unknown}/${UNIT_SUB:-?} unit-file=${UNIT_ENABLED:-?} pid=${ADMIN_PID:-?}"
if [ "${UNIT_STATE:-}" = active ]; then good 'dsh-admin active'; else bad "dsh-admin 不是 active（${UNIT_STATE:-unknown}）"; fi

USERS_LINE=$(systemctl list-units 'dsh-user@*' --no-pager --no-legend 2>/dev/null | awk '{print $1"("$3"/"$4")"}' | tr '\n' ' ')
USER_COUNT=$(systemctl list-units 'dsh-user@*' --no-pager --no-legend 2>/dev/null | grep -c 'dsh-user@' || true)
kv 'dsh-user@*' "${USERS_LINE:-none}"
kv 'dsh-user@* 数量' "${USER_COUNT:-0}"

T_STATE=$(systemctl is-active dsh-proxy-idle.timer 2>/dev/null || true)
T_ENABLED=$(systemctl show dsh-proxy-idle.timer -p UnitFileState --value 2>/dev/null || true)
T_LAST=$(systemctl show dsh-proxy-idle.timer -p LastTriggerUSec --value 2>/dev/null || true)
kv 'dsh-proxy-idle.timer' "${T_STATE:-unknown} enabled=${T_ENABLED:-?} last=${T_LAST:-?}"
if [ "${T_STATE:-}" = active ]; then good 'proxy-idle timer active'; else warn 'proxy-idle timer 不是 active'; fi

P_STATE=$(systemctl is-active dsh-proxy-idle.service 2>/dev/null || true)
P_RESULT=$(systemctl show dsh-proxy-idle.service -p Result --value 2>/dev/null || true)
kv 'dsh-proxy-idle.service' "${P_STATE:-unknown} result=${P_RESULT:-?}"

# ── 6. 端口 3290-3296 ───────────────────────────────────────────────────────
sec '6. 端口 3290-3296（ss -ltnp）'
PORTS_JSON=''
PORTS_LIST=''
if command -v ss >/dev/null 2>&1; then
  PORTS_RAW=$(ss -ltnp 2>/dev/null | awk 'NR>1{split($4,a,":"); if (a[length(a)]>=3290 && a[length(a)]<=3296) print}')
  if [ -n "$PORTS_RAW" ]; then
    printf '%s\n' "$PORTS_RAW" | sed 's/^/  /'
    for p in $(printf '%s\n' "$PORTS_RAW" | awk '{split($4,a,":"); print a[length(a)]}' | sort -u); do
      PORTS_LIST="$PORTS_LIST $p"
      PORTS_JSON="$PORTS_JSON${PORTS_JSON:+,}$p"
    done
    kv '监听端口' "${PORTS_LIST# }"
  else
    bad '3290-3296 没有任何监听'
  fi
else
  na 'ss 不可用'
fi

# ── 7. 插件目录 ─────────────────────────────────────────────────────────────
sec '7. 插件目录（归属 / 权限 / 文件 MD5）'
PLUGIN_OWNER=''; PLUGIN_MODE=''; FILES_JSON=''; ENGINE_JS=''
if [ -d "$PLUGIN_DIR" ]; then
  kv path "$PLUGIN_DIR"
  PLUGIN_OWNER=$(stat -c '%U:%G' "$PLUGIN_DIR" 2>/dev/null || echo '?')
  PLUGIN_MODE=$(stat -c '%a' "$PLUGIN_DIR" 2>/dev/null || echo '?')
  kv 'owner:group' "$PLUGIN_OWNER"
  kv mode "$PLUGIN_MODE"
  case "$PLUGIN_MODE" in
    2775|775) good '目录权限符合预期（2775 / 775）' ;;
    *) warn "目录权限 $PLUGIN_MODE，期望 2775（setgid + 组可写）" ;;
  esac
  for f in index.js client.js package.json cordis.patch.yml engine/chaoxing-autolearn.js; do
    if [ -f "$PLUGIN_DIR/$f" ]; then
      MD5=$(md5sum "$PLUGIN_DIR/$f" 2>/dev/null | awk '{print $1}')
      SZ=$(stat -c '%s' "$PLUGIN_DIR/$f" 2>/dev/null || echo '')
      FM=$(stat -c '%a' "$PLUGIN_DIR/$f" 2>/dev/null || echo '')
      kv "$f" "md5=${MD5:-?} size=${SZ:-?} mode=${FM:-?}"
      FILES_JSON="$FILES_JSON${FILES_JSON:+,}{\"name\":\"$f\",\"md5\":$(jstr_or_null "${MD5:-}"),\"size\":$(uint_or_null "${SZ:-}"),\"mode\":\"${FM:-}\"}"
    else
      warn "$f 缺失"
      FILES_JSON="$FILES_JSON${FILES_JSON:+,}{\"name\":\"$f\",\"md5\":null}"
    fi
  done
  ENGINE_JS=$(ls -1 "$PLUGIN_DIR"/engine/*.js 2>/dev/null | wc -l | tr -d ' ')
  kv 'engine/*.js 数量' "${ENGINE_JS:-0}"
  ls -l "$PLUGIN_DIR"/engine/*.js 2>/dev/null | awk '{print "  "$1" "$3":"$4" "$5" "$9}'
else
  bad "插件目录不存在：$PLUGIN_DIR"
fi

# ── 8. 内核 ─────────────────────────────────────────────────────────────────
sec '8. 浏览器内核'
CHROME_VERSION=''
CHROME_EXEC=no
CHROME_META=''
if [ -f "$CHROME" ]; then
  [ -x "$CHROME" ] && CHROME_EXEC=yes
  CHROME_VERSION=$("$CHROME" --version 2>/dev/null | head -n 1 || true)
  CHROME_META=$(stat -c '%a %U:%G' "$CHROME" 2>/dev/null || echo '?')
  kv path "$CHROME"
  kv '可执行位' "$CHROME_EXEC（$CHROME_META）"
  kv version "${CHROME_VERSION:-unavailable}"
  if [ "$CHROME_EXEC" = yes ]; then good '内核存在且可执行'; else bad '内核存在但不可执行'; fi
else
  bad "内核不存在：$CHROME"
fi

# ── 9. 状态文件 ─────────────────────────────────────────────────────────────
sec '9. 状态文件（cx-learn）'
BROWSER_JSON=''; B_READY=''; B_PORT=''; B_HB=''; B_UPD=''
for cand in "$STATE_DIR/browser.json" "$PLUGIN_DIR/engine/.state/browser.json"; do
  if [ -f "$cand" ]; then BROWSER_JSON=$cand; break; fi
done
if [ -n "$BROWSER_JSON" ]; then
  kv 'browser.json' "$BROWSER_JSON"
  sed 's/^/  /' "$BROWSER_JSON" 2>/dev/null | head -n 20
  printf '\n'
  B_READY=$(jraw "$BROWSER_JSON" ready)
  B_PORT=$(jraw "$BROWSER_JSON" port)
  B_HB=$(jstr "$BROWSER_JSON" heartbeatAt)
  B_UPD=$(jstr "$BROWSER_JSON" updatedAt)
  printf '    %-20s %s\n' 'ready/port' "${B_READY:-?} / ${B_PORT:-?}"
  printf '    %-20s %s\n' 'heartbeatAt' "${B_HB:-missing（新字段未落盘，按 null 处理）}"
  printf '    %-20s %s\n' 'updatedAt' "${B_UPD:-?}"
else
  na "browser.json 不存在（$STATE_DIR/browser.json 与 $PLUGIN_DIR/engine/.state/browser.json 都没有）"
fi

ST_PID=''; ST_MODE=''; ST_STARTED=''
if [ -f "$STATE_DIR/state.json" ]; then
  kv 'state.json' "$STATE_DIR/state.json"
  redact < "$STATE_DIR/state.json" 2>/dev/null | sed 's/^/  /'
  ST_PID=$(jraw "$STATE_DIR/state.json" pid)
  ST_MODE=$(jstr "$STATE_DIR/state.json" mode)
  ST_STARTED=$(jraw "$STATE_DIR/state.json" startedAt)
else
  na 'state.json 不存在'
fi

# ── 10. run.log ─────────────────────────────────────────────────────────────
sec '10. run.log 最近 40 行（已过滤 cookie/token 类行）'
RUN_LOG=$STATE_DIR/run.log
ERR_TOTAL=''
if [ -f "$RUN_LOG" ]; then
  kv path "$RUN_LOG"
  kv size "$(stat -c '%s bytes, mtime %y' "$RUN_LOG" 2>/dev/null || echo '?')"
  ERR_TOTAL=$(grep -c '\[ERROR\]' "$RUN_LOG" 2>/dev/null || true)
  kv 'ERROR 行总数' "${ERR_TOTAL:-0}"
  printf '  --- 最近 ERROR（最多 5 条）---\n'
  grep '\[ERROR\]' "$RUN_LOG" 2>/dev/null | tail -n 5 | scrub | redact | sed 's/^/  /'
  printf '  --- tail -40 ---\n'
  tail -n 40 "$RUN_LOG" 2>/dev/null | scrub | redact | sed 's/^/  /'
else
  na "run.log 不存在：$RUN_LOG"
fi

# ── 11. HTTP 接口 ───────────────────────────────────────────────────────────
sec '11. HTTP 接口'
STATUS_CODE=$(http_code "$API/status")
HEALTH_CODE=$(http_code "$API/health")
kv '/status' "$STATUS_CODE"
case "$STATUS_CODE" in
  200) good '/status 200' ;;
  000) bad '/status 连不上（服务没起或端口不对）' ;;
  *)   bad "/status $STATUS_CODE" ;;
esac
kv '/health' "$HEALTH_CODE"
HEALTH_STATE=bad
if [ "$HEALTH_CODE" = 404 ]; then
  HEALTH_STATE=not_implemented
  na '/health 404 —— 未实现（Agent C 在做），不算失败'
elif [ "$HEALTH_CODE" = 200 ]; then
  HEALTH_STATE=ok
  good '/health 200'
else
  bad "/health $HEALTH_CODE"
fi

STATUS_OK=''; STATUS_RUNNING=''
if [ "$STATUS_CODE" = 200 ]; then
  # 直接读进变量，不落临时文件（本脚本承诺不写盘）
  STATUS_BODY=$(curl -s --max-time 5 "$API/status" 2>/dev/null || true)
  STATUS_OK=$(printf '%s' "$STATUS_BODY" | grep -o '"ok"[[:space:]]*:[[:space:]]*\(true\|false\)' | head -n 1 | sed 's/.*:[[:space:]]*//')
  STATUS_RUNNING=$(printf '%s' "$STATUS_BODY" | grep -o '"running"[[:space:]]*:[[:space:]]*\(true\|false\)' | head -n 1 | sed 's/.*:[[:space:]]*//')
  kv '  status.ok' "${STATUS_OK:-?}"
  kv '  status.running' "${STATUS_RUNNING:-?}"
fi

# ── 12. 代理 ────────────────────────────────────────────────────────────────
sec '12. dsh-proxy'
PROXY_BIN=$DSH_HOME/bin/dsh-proxy
PROXY_STATE=unknown
if [ -x "$PROXY_BIN" ]; then
  PROXY_OUT=$("$PROXY_BIN" status 2>&1 | head -n 1 || true)
  PROXY_STATE=${PROXY_OUT:-unknown}
  kv status "$PROXY_STATE"
  if [ "$PROXY_STATE" = on ]; then good '代理在跑'; else good "代理未开（$PROXY_STATE，属正常）"; fi
else
  na "找不到可执行的 $PROXY_BIN"
fi

# ── 机器可读 JSON ───────────────────────────────────────────────────────────
OOM_JSON='['
FIRST=1
if [ -n "$OOM_LINES" ]; then
  while IFS= read -r line; do
    [ "$FIRST" = 1 ] || OOM_JSON="$OOM_JSON,"
    OOM_JSON="$OOM_JSON$(jstr_or_null "$line")"
    FIRST=0
  done <<EOF_OOM
$OOM_LINES
EOF_OOM
fi
OOM_JSON="$OOM_JSON]"

printf '\n== 机器可读 JSON ==\n'
cat <<EOF
{
  "at": $(jstr_or_null "$AT"),
  "host": $(jstr_or_null "$HOST"),
  "uptime": $(jstr_or_null "${UPTIME_RAW:-}"),
  "load": {"1m": $(jstr_or_null "$LOAD1"), "5m": $(jstr_or_null "$LOAD5"), "15m": $(jstr_or_null "$LOAD15")},
  "mem": {"totalMB": $(uint_or_null "$MEM_TOTAL_MB"), "usedMB": $(uint_or_null "$MEM_USED_MB"), "availMB": $(uint_or_null "$MEM_AVAIL_MB")},
  "disk": {"root": $(jstr_or_null "$DISK_ROOT"), "vol1": $(jstr_or_null "$DISK_VOL1")},
  "shm": {"detail": $(jstr_or_null "$SHM_H"), "availMB": $(uint_or_null "$SHM_AVAIL_MB"), "state": "$SHM_STATE"},
  "oom": {"state": "$OOM_STATE", "lines": $OOM_JSON},
  "systemd": {
    "dsh-admin": {"active": $(jstr_or_null "${UNIT_STATE:-}"), "sub": $(jstr_or_null "${UNIT_SUB:-}"), "unitFile": $(jstr_or_null "${UNIT_ENABLED:-}"), "mainPid": $(uint_or_null "$ADMIN_PID")},
    "dsh-user-count": $(uint_or_null "$USER_COUNT"),
    "dsh-proxy-idle.timer": {"active": $(jstr_or_null "${T_STATE:-}"), "unitFile": $(jstr_or_null "${T_ENABLED:-}")},
    "dsh-proxy-idle.service": {"active": $(jstr_or_null "${P_STATE:-}"), "result": $(jstr_or_null "${P_RESULT:-}")}
  },
  "listen329x": [${PORTS_JSON}],
  "plugin": {"path": $(jstr_or_null "$PLUGIN_DIR"), "owner": $(jstr_or_null "$PLUGIN_OWNER"), "mode": $(jstr_or_null "$PLUGIN_MODE"), "engineJsCount": $(uint_or_null "$ENGINE_JS"), "files": [${FILES_JSON}]},
  "chromium": {"path": $(jstr_or_null "$CHROME"), "executable": "$CHROME_EXEC", "version": $(jstr_or_null "$CHROME_VERSION")},
  "browserJson": {"path": $(jstr_or_null "$BROWSER_JSON"), "ready": $(jstr_or_null "$B_READY"), "port": $(uint_or_null "$B_PORT"), "heartbeatAt": $(jstr_or_null "$B_HB"), "updatedAt": $(jstr_or_null "$B_UPD")},
  "state": {"pid": $(uint_or_null "$ST_PID"), "mode": $(jstr_or_null "$ST_MODE"), "startedAt": $(uint_or_null "$ST_STARTED")},
  "runLog": {"errorLines": $(uint_or_null "$ERR_TOTAL")},
  "http": {"status": "$STATUS_CODE", "health": "$HEALTH_CODE", "healthState": "$HEALTH_STATE", "statusOk": $(jstr_or_null "$STATUS_OK"), "running": $(jstr_or_null "$STATUS_RUNNING")},
  "proxy": $(jstr_or_null "$PROXY_STATE")
}
EOF

exit 0
