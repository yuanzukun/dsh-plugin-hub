#!/bin/bash
# deploy.sh —— 把本地 dsh-cx-learn 部署到飞牛，**带备份 + 自动回滚**
#
# ⚠️ 这个脚本会 `systemctl restart dsh-admin`。按团队契约（§0 / §5），
#    **只由主会话执行**；Agent B 只负责写脚本 + 做 --dry-run 验证。
#
# 用法：
#   bash ops/deploy.sh --src <本地插件目录> --dry-run   # 只打印命令，不落盘、不重启
#   sudo bash ops/deploy.sh --src <本地插件目录> --yes   # 真部署（需要 root）
#
# 参数：
#   --src <dir>         本地插件目录（必须含 index.js / client.js / engine/*.js）
#   --target <dir>      远端插件目录（默认 /vol1/@apphome/dsh-shared/lib/node_modules/dsh-cx-learn）
#   --backup-root <dir> 备份根目录（默认 /vol1/@apphome/dsh-shared/backups）
#   --port <n>          校验端口（默认 3290）
#   --wait <sec>        重启后等待秒数（默认 15）
#   --dry-run           只打印将要执行的命令，一个字节都不写、不重启
#   --yes               真部署必须显式加（防手滑）
#
# 退出码：
#   0  部署成功且校验通过
#   2  参数错 / 前置检查不过（什么都没动）
#   3  校验失败，已自动回滚且回滚后健康
#   4  校验失败且回滚后仍不健康（需人工介入，备份路径已打印）
#
# 红线：
#   · 只 restart dsh-admin 这一个服务，绝不 pkill / killall
#   · 只写 index.js / client.js / engine/*.js，不碰 engine/.state/
#   · 备份不成功就不往下走
#   · 回滚用「覆盖」而不是 rm -rf（插件目录里还有 .bak-* 历史文件）

set -uo pipefail

SRC=''
DRY=0
YES=0
TGT='/vol1/@apphome/dsh-shared/lib/node_modules/dsh-cx-learn'
BKROOT='/vol1/@apphome/dsh-shared/backups'
PORT=3290
WAIT=15

while [ $# -gt 0 ]; do
  case "$1" in
    --src) SRC=${2:-}; shift 2 ;;
    --src=*) SRC=${1#--src=}; shift ;;
    --target) TGT=${2:-}; shift 2 ;;
    --target=*) TGT=${1#--target=}; shift ;;
    --backup-root) BKROOT=${2:-}; shift 2 ;;
    --backup-root=*) BKROOT=${1#--backup-root=}; shift ;;
    --port) PORT=${2:-}; shift 2 ;;
    --port=*) PORT=${1#--port=}; shift ;;
    --wait) WAIT=${2:-}; shift 2 ;;
    --wait=*) WAIT=${1#--wait=}; shift ;;
    --dry-run) DRY=1; shift ;;
    --yes|-y) YES=1; shift ;;
    -h|--help) sed -n '2,32p' "$0"; exit 0 ;;
    *) echo "未知参数：$1（--help 看用法）" >&2; exit 2 ;;
  esac
done

log()  { printf '%s\n' "$*"; }
die()  { printf 'deploy: %s\n' "$*" >&2; exit 2; }
warn() { printf '[warn] %s\n' "$*"; }

# dry-run 只打印；真跑原样执行（参数里的空格不会被拆开）
run() {
  printf '+ %s\n' "$*"
  if [ "$DRY" = 0 ]; then "$@"; fi
}

# ── 前置检查 ────────────────────────────────────────────────────────────────
[ -n "$SRC" ] || die '缺少 --src <本地插件目录>'
[ -d "$SRC" ] || die "src 不是目录：$SRC"
for f in index.js client.js; do
  [ -f "$SRC/$f" ] || die "src 缺少 $f：$SRC/$f"
done
ls "$SRC"/engine/*.js >/dev/null 2>&1 || die "src 缺少 engine/*.js：$SRC/engine"
[ -d "$TGT" ] || die "远端目标目录不存在：$TGT"

if [ "$DRY" = 0 ]; then
  [ "$YES" = 1 ] || die '真部署必须显式加 --yes（先跑 --dry-run 看一眼命令序列）'
  [ "$(id -u 2>/dev/null || echo 1)" = 0 ] || die '真部署需要 root（chown / systemctl restart）：请用 sudo bash 运行'
  command -v curl >/dev/null 2>&1 || die '缺少 curl，无法做部署后校验'
fi

TS=$(date '+%Y%m%d-%H%M%S') || die 'date 失败'
BK="$BKROOT/dsh-cx-learn-$TS"
API="http://127.0.0.1:$PORT/api/cx-learn"

# 取 HTTP 状态码；连不上返回 000（curl 自己也会打 000，这里统一收敛，避免拼成 000000）
code_of() {
  C=$(curl -s -o "${2:-/dev/null}" -w '%{http_code}' --max-time "${3:-8}" "$1" 2>/dev/null)
  case "${C:-}" in
    ''|*[!0-9]*) printf '000' ;;
    *) printf '%s' "$C" ;;
  esac
}

log '=========================================================='
log " dsh-cx-learn 部署  src=$SRC"
log "                    target=$TGT"
log "                    backup=$BK"
[ "$DRY" = 1 ] && log ' 模式：DRY-RUN（只打印，不写盘、不重启）'
log '=========================================================='

# ── 1/7 前置检查 ────────────────────────────────────────────────────────────
log ''
log '[1/7] 前置检查'
ACT0=$(systemctl is-active dsh-admin 2>/dev/null || true)
log "  dsh-admin 当前：${ACT0:-unknown}"
CUR=$(code_of "$API/status" /dev/null 5)
log "  当前 /status：$CUR"
log "  待部署文件：$(cd "$SRC" && ls -1 index.js client.js engine/*.js 2>/dev/null | tr '\n' ' ')"

# ── 2/7 备份 ────────────────────────────────────────────────────────────────
log ''
log '[2/7] 备份（cp -a 整个插件目录，含 engine/.state/）'
run mkdir -p "$BKROOT"
run cp -a "$TGT" "$BK"
if [ "$DRY" = 1 ]; then
  log "  （dry-run 未真正备份；真跑时路径为 $BK）"
else
  [ -f "$BK/index.js" ] || die "备份失败：$BK/index.js 不存在，已中止（目标目录未被修改）"
  log "  备份完成：$BK"
fi

# ── 3/7 拷贝 ────────────────────────────────────────────────────────────────
log ''
log '[3/7] 拷贝 index.js / client.js / engine/*.js（不碰 engine/.state/）'
run install -m 0664 -o fn-deepseek-harness -g dshusers "$SRC/index.js" "$TGT/index.js"
run install -m 0664 -o fn-deepseek-harness -g dshusers "$SRC/client.js" "$TGT/client.js"
run mkdir -p "$TGT/engine"
for f in "$SRC"/engine/*.js; do
  [ -f "$f" ] || continue
  run install -m 0664 -o fn-deepseek-harness -g dshusers "$f" "$TGT/engine/$(basename "$f")"
done

# ── 4/7 归属 / 权限 ─────────────────────────────────────────────────────────
log ''
log '[4/7] 修归属与权限（chown fn-deepseek-harness、chgrp dshusers、目录 2775、文件 664）'
run chown -R fn-deepseek-harness "$TGT"
run chgrp -R dshusers "$TGT"
run find "$TGT" -type d -exec chmod 2775 {} +
run find "$TGT" -type f -exec chmod 664 {} +
# setgid 只对目录有意义，顶层目录再兜一次（防止被上一步意外清掉）
run chmod 2775 "$TGT"

# 拷贝完整性：内容不一致就别重启了（重启只会把坏文件加载进去）
if [ "$DRY" = 0 ]; then
  BAD=''
  for f in index.js client.js; do cmp -s "$SRC/$f" "$TGT/$f" || BAD="$BAD $f"; done
  for f in "$SRC"/engine/*.js; do
    b=$(basename "$f")
    cmp -s "$f" "$TGT/engine/$b" || BAD="$BAD engine/$b"
  done
  if [ -n "$BAD" ]; then
    log "  拷贝校验失败（内容不一致）：$BAD"
    log '  尚未重启，直接用备份覆盖回去…'
    run cp -a "$BK/." "$TGT/"
    run chown -R fn-deepseek-harness "$TGT"
    run chgrp -R dshusers "$TGT"
    run find "$TGT" -type d -exec chmod 2775 {} +
    run find "$TGT" -type f -exec chmod 664 {} +
    log "  已还原为部署前内容（服务未重启，仍在跑旧代码）。备份：$BK"
    exit 3
  fi
  log '  拷贝校验通过（md5 级内容一致）'
fi

# ── 5/7 重启 ────────────────────────────────────────────────────────────────
log ''
log '[5/7] 重启 dsh-admin（本脚本唯一允许的服务操作）'
run systemctl restart dsh-admin

# ── 6/7 校验 ────────────────────────────────────────────────────────────────
log ''
log "[6/7] 等待 ${WAIT}s 后校验"
if [ "$DRY" = 1 ]; then
  log "+ sleep $WAIT"
  log "+ systemctl is-active dsh-admin                              # 期望 active"
  log "+ curl -s -o /dev/null -w '%{http_code}' $API/status           # 期望 200"
  log "+ curl -s -o /dev/null -w '%{http_code}' $API/health           # 200 看 ok；404 跳过"
  log ''
  log '[7/7] 校验失败 → 自动回滚（dry-run 仅打印）'
  log "+ cp -a '$BK/.' '$TGT/'"
  log "+ chown -R fn-deepseek-harness '$TGT' && chgrp -R dshusers '$TGT'"
  log "+ find '$TGT' -type d -exec chmod 2775 {} + ; find '$TGT' -type f -exec chmod 664 {} +"
  log "+ systemctl restart dsh-admin"
  log ''
  log '手动回滚命令：'
  log "  sudo bash ops/rollback.sh --backup $BK"
  log ''
  log 'DRY-RUN 结束：没有写任何文件，没有重启任何服务。'
  exit 0
fi

sleep "$WAIT"

CHECK_FAIL=''
ACT=$(systemctl is-active dsh-admin 2>/dev/null || true)
log "  is-active = ${ACT:-unknown}"
[ "$ACT" = active ] || CHECK_FAIL="dsh-admin not active (${ACT:-unknown})"

if [ -z "$CHECK_FAIL" ]; then
  SC=$(code_of "$API/status")
  log "  /status   = $SC"
  [ "$SC" = 200 ] || CHECK_FAIL="/status $SC"
fi

HBODY=$(mktemp 2>/dev/null || echo "/tmp/.cxdeploy-health.$$")
if [ -z "$CHECK_FAIL" ]; then
  HB=$(code_of "$API/health" "$HBODY")
  if [ "$HB" = 404 ]; then
    log '  /health   = 404（未实现，按契约跳过，不影响部署判定）'
  elif [ "$HB" = 200 ]; then
    HOK=$(grep -o '"ok"[[:space:]]*:[[:space:]]*\(true\|false\)' "$HBODY" 2>/dev/null | head -n 1 | sed 's/.*:[[:space:]]*//')
    log "  /health   = 200 ok=${HOK:-?}"
    [ "${HOK:-}" = false ] && CHECK_FAIL='/health ok:false'
  else
    log "  /health   = $HB"
    CHECK_FAIL="/health $HB"
  fi
fi
rm -f "$HBODY" 2>/dev/null

# ── 7/7 结果 / 回滚 ─────────────────────────────────────────────────────────
log ''
if [ -z "$CHECK_FAIL" ]; then
  log '=========================================================='
  log ' 部署成功'
  log " 备份：$BK"
  log " 回滚命令：sudo bash ops/rollback.sh --backup $BK"
  log '=========================================================='
  exit 0
fi

log " 校验失败：$CHECK_FAIL"
log ' 开始自动回滚（覆盖回备份内容）…'
run cp -a "$BK/." "$TGT/"
if [ ! -f "$TGT/index.js" ]; then
  log " !! 回滚拷贝失败：$TGT/index.js 不存在。备份仍在：$BK"
  log " 手动回滚命令：sudo bash ops/rollback.sh --backup $BK"
  exit 4
fi
run chown -R fn-deepseek-harness "$TGT"
run chgrp -R dshusers "$TGT"
run find "$TGT" -type d -exec chmod 2775 {} +
run find "$TGT" -type f -exec chmod 664 {} +
run systemctl restart dsh-admin
sleep "$WAIT"
ACT2=$(systemctl is-active dsh-admin 2>/dev/null || true)
SC2=$(code_of "$API/status")
log " 回滚后 is-active=${ACT2:-unknown} /status=$SC2"
if [ "$ACT2" = active ] && [ "$SC2" = 200 ]; then
  log " 已回滚到部署前版本。备份保留在：$BK"
  log " 手动回滚命令：sudo bash ops/rollback.sh --backup $BK"
  exit 3
fi
log ' !! 回滚后仍不健康，需要人工介入 !!'
log " 备份目录：$BK"
log " 手动回滚命令：sudo bash ops/rollback.sh --backup $BK"
exit 4
