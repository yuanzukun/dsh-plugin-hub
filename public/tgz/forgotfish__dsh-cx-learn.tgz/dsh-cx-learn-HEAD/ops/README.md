# ops —— FNOS 运维脚本

本目录放运行在飞牛 fnOS 上的运维脚本，与插件本体（`index.js` / `client.js` / `engine/`）无关，
但属于同一套部署环境的配套工具。

---

## dsh-proxy-idle —— 代理闲置自动关闭

### 背景

飞牛上的 DSH 实例（`dsh-admin`，用户 `fn-deepseek-harness`）有自己的 mihomo 代理：

- 端口 `7893`（混合 HTTP+SOCKS5），控制口 `9093`
- 开关：`/vol1/@apphome/fn-deepseek-harness/bin/dsh-proxy on|off|status`
- **与主人自己的 7890 实例完全隔离**，互不影响

代理只在需要访问墙外服务时开（详见 `/vol1/@apphome/fn-deepseek-harness/AGENTS.md`）。
问题是：忘了关就会一直挂着，占内存、也失去「用完即关」的意义。

### 这个脚本做什么

每 5 分钟检查一次：**如果代理在跑，但 7893 上连续 30 分钟没有任何活跃连接，就自动关掉并通知**。

### 判据为什么看连接数而不是时间戳

`dsh-proxy on` 会在 `proxy/idle.state` 写一个时间戳，但它**只在 on 的那一刻写一次**，
之后不更新。用它判断「闲置」会把「一直在用」的情况也误判成闲置。

所以直接数端口上的 ESTABLISHED 连接：

```
空闲时:   0 个
传输中:   2 个   ← 实测能检测到
结束后:   0 个
```

### 逻辑

```
1. 代理没在跑（无 PID 文件 / 进程不存在）→ 清理标记，退出
2. 7893 上有活跃连接                    → 重置标记，退出
3. 无连接且无标记                        → 记录「首次观察到空闲」时间，退出
4. 无连接且已超 30 分钟                  → dsh-proxy off "闲置 N 分钟自动关闭"
```

### 安全边界

- **只在 dsh-proxy 自己的 PID 文件存在时才动手** → 不会碰主人的 7890 实例
- 关闭动作只调 `dsh-proxy off`（按 PID 精确杀），**不 pkill / 不 killall**
- 代理没跑时立即退出，零开销

### 部署位置（FNOS）

| 文件 | 目标路径 |
|---|---|
| `dsh-proxy-idle` | `/vol1/@apphome/fn-deepseek-harness/bin/dsh-proxy-idle`（chmod +x）|
| `dsh-proxy-idle.service` | `/etc/systemd/system/dsh-proxy-idle.service` |
| `dsh-proxy-idle.timer` | `/etc/systemd/system/dsh-proxy-idle.timer` |

### 安装

```bash
B=/vol1/@apphome/fn-deepseek-harness/bin
sudo cp dsh-proxy-idle "$B/dsh-proxy-idle"
sudo chmod +x "$B/dsh-proxy-idle"
sudo chown fn-deepseek-harness:fn-deepseek-harness "$B/dsh-proxy-idle"

sudo cp dsh-proxy-idle.service dsh-proxy-idle.timer /etc/systemd/system/
sudo chmod 644 /etc/systemd/system/dsh-proxy-idle.{service,timer}
sudo systemctl daemon-reload
sudo systemctl enable --now dsh-proxy-idle.timer
```

### 验证

```bash
# 看调度
systemctl list-timers dsh-proxy-idle.timer

# 手动跑一次
sudo systemctl start dsh-proxy-idle.service
systemctl show dsh-proxy-idle.service -p Result --value     # 应为 success

# 直接跑脚本看输出
sudo -u fn-deepseek-harness /vol1/@apphome/fn-deepseek-harness/bin/dsh-proxy-idle
```

### 调整闲置时长

改脚本第 25 行附近：

```bash
IDLE_SECONDS=1800          # 30 分钟，按需改
```

改完不需要 reload（timer 只是触发器，不读脚本内容）。

### 实测记录（2026-10-28）

| 测试 | 结果 |
|---|---|
| 代理在跑 + 空闲 → 创建 idle 标记 | ✅ `1793200161` |
| 重复运行 → 保留原标记不重建 | ✅ |
| 代理关闭 → 清理标记 | ✅ |
| 连接数检测（空闲/传输中/结束） | ✅ `0 / 2 / 0` |
| timer 调度 | ✅ 每 5 分钟 |
| service 执行结果 | ✅ `Result=success` |

---

## 已知小问题

`dsh-proxy status` 偶尔显示 `off`，即使进程还在跑。

原因：它用 `running() && port_up` 判断，而 `port_up()` 走 `/dev/tcp` 探测，
在某些时序下会失败。**不影响实际功能**（脚本内部的空闲检测用 `ss` 数连接，不依赖它），
只是会让人误判状态。待修。
