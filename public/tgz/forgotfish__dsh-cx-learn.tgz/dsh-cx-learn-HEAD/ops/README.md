# ops —— FNOS 运维脚本

本目录放运行在飞牛 fnOS 上的运维脚本，与插件本体（`index.js` / `client.js` / `engine/`）无关，
但属于同一套部署环境的配套工具。

---

## dsh-proxy-idle —— 代理闲置自动关闭

### 背景

飞牛上的 DSH 实例（`dsh-admin`，用户 `fn-deepseek-harness`）有自己的 mihomo 代理：

- 端口 `7893`（混合 HTTP+SOCKS5），控制口 `9093`
- 开关：`/vol1/@apphome/fn-deepseek-harness/bin/dsh-proxy on|off|status`
- **与主人自己的 7890 实例完全隔离**，互不影响

代理只在需要访问墙外服务时开（详见 `/vol1/@apphome/fn-deepseek-harness/AGENTS.md`）。
问题是：忘了关就会一直挂着，占内存、也失去「用完即关」的意义。

### 这个脚本做什么

每 5 分钟检查一次：**如果代理在跑，但 7893 上连续 30 分钟没有任何活跃连接，就自动关掉并通知**。

### 判据为什么看连接数而不是时间戳

`dsh-proxy on` 会在 `proxy/idle.state` 写一个时间戳，但它**只在 on 的那一刻写一次**，
之后不更新。用它判断「闲置」会把「一直在用」的情况也误判成闲置。

所以直接数端口上的 ESTABLISHED 连接：

```
空闲时:   0 个
传输中:   2 个   ← 实测能检测到
结束后:   0 个
```

### 逻辑

```
1. 代理没在跑（无 PID 文件 / 进程不存在）→ 清理标记，退出
2. 7893 上有活跃连接                    → 重置标记，退出
3. 无连接且无标记                        → 记录「首次观察到空闲」时间，退出
4. 无连接且已超 30 分钟                  → dsh-proxy off "闲置 N 分钟自动关闭"
```

### 安全边界

- **只在 dsh-proxy 自己的 PID 文件存在时才动手** → 不会碰主人的 7890 实例
- 关闭动作只调 `dsh-proxy off`（按 PID 精确杀），**不 pkill / 不 killall**
- 代理没跑时立即退出，零开销

### 部署位置（FNOS）

| 文件 | 目标路径 |
|---|---|
| `dsh-proxy-idle` | `/vol1/@apphome/fn-deepseek-harness/bin/dsh-proxy-idle`（chmod +x）|
| `dsh-proxy-idle.service` | `/etc/systemd/system/dsh-proxy-idle.service` |
| `dsh-proxy-idle.timer` | `/etc/systemd/system/dsh-proxy-idle.timer` |

### 安装

```bash
B=/vol1/@apphome/fn-deepseek-harness/bin
sudo cp dsh-proxy-idle "$B/dsh-proxy-idle"
sudo chmod +x "$B/dsh-proxy-idle"
sudo chown fn-deepseek-harness:fn-deepseek-harness "$B/dsh-proxy-idle"

sudo cp dsh-proxy-idle.service dsh-proxy-idle.timer /etc/systemd/system/
sudo chmod 644 /etc/systemd/system/dsh-proxy-idle.{service,timer}
sudo systemctl daemon-reload
sudo systemctl enable --now dsh-proxy-idle.timer
```

### 验证

```bash
# 看调度
systemctl list-timers dsh-proxy-idle.timer

# 手动跑一次
sudo systemctl start dsh-proxy-idle.service
systemctl show dsh-proxy-idle.service -p Result --value     # 应为 success

# 直接跑脚本看输出
sudo -u fn-deepseek-harness /vol1/@apphome/fn-deepseek-harness/bin/dsh-proxy-idle
```

### 调整闲置时长

改脚本第 25 行附近：

```bash
IDLE_SECONDS=1800          # 30 分钟，按需改
```

改完不需要 reload（timer 只是触发器，不读脚本内容）。

### 实测记录（2026-10-28）

| 测试 | 结果 |
|---|---|
| 代理在跑 + 空闲 → 创建 idle 标记 | ✅ `1793200161` |
| 重复运行 → 保留原标记不重建 | ✅ |
| 代理关闭 → 清理标记 | ✅ |
| 连接数检测（空闲/传输中/结束） | ✅ `0 / 2 / 0` |
| timer 调度 | ✅ 每 5 分钟 |
| service 执行结果 | ✅ `Result=success` |

---

## 已知小问题

`dsh-proxy status` 偶尔显示 `off`，即使进程还在跑。

原因：它用 `running() && port_up` 判断，而 `port_up()` 走 `/dev/tcp` 探测，
在某些时序下会失败。**不影响实际功能**（脚本内部的空闲检测用 `ss` 数连接，不依赖它），
只是会让人误判状态。待修。

---

## fnos-baseline 基线采集

### 背景

飞牛上的 DSH（`dsh-admin`，用户 `fn-deepseek-harness`）跑 6 个实例，共用一套
`dsh-cx-learn` 插件和一份 Chrome for Testing 内核。出问题时最耗时的不是修，
而是**凑现场**：服务状态、端口、插件归属、内核版本、`/dev/shm`、日志尾巴，
每次都要手敲一遍，还容易漏。

`fnos-baseline.sh` 就是把这些一次性打出来：**纯只读**，人看的部分在前面，
末尾附一份机器可读 JSON，方便「出事前跑一次、出事后跑一次」直接 diff。

### 采集内容

| 段 | 内容 |
|---|---|
| 1–2 | hostname / uptime / 负载 / 内存（total-used-available）/ `df -h /` 与 `/vol1` |
| 3 | `/dev/shm` 容量，**< 256MB 标红**（无头内核崩溃头号原因） |
| 4 | `dmesg -T` 最近 5 条 OOM 相关行；取不到（非 root）标 `unavailable`，不报错 |
| 5 | `dsh-admin`、`dsh-user@*`、`dsh-proxy-idle.timer` / `.service` 的 active 与 result |
| 6 | `ss -ltnp` 过滤 3290–3296，列出实际监听端口 |
| 7 | 插件目录归属 / 权限 / 5 个文件的 MD5 + size + mode |
| 8 | 内核 `--version` + 可执行位 |
| 9 | `browser.json`（两处都找：`$DSH_HOME/cx-learn/` 和 `<插件>/engine/.state/`）、`state.json` |
| 10 | `run.log` 的 ERROR 计数 + 最近 5 条 ERROR + `tail -40` |
| 11 | `/status` 与 `/health` 的 HTTP 码（404 标「未实现」，不算失败） |
| 12 | `dsh-proxy status` |

### 装法

脚本不常驻，建议放 bin 目录，随时手跑：

```bash
sudo cp ops/fnos-baseline.sh /vol1/@apphome/fn-deepseek-harness/bin/fnos-baseline.sh
sudo chmod +x /vol1/@apphome/fn-deepseek-harness/bin/fnos-baseline.sh
sudo chown fn-deepseek-harness:fn-deepseek-harness /vol1/@apphome/fn-deepseek-harness/bin/fnos-baseline.sh

# 跑一次，存到 /tmp（别往 /vol1 里堆报告）
/vol1/@apphome/fn-deepseek-harness/bin/fnos-baseline.sh > /tmp/baseline-$(date +%F-%H%M).txt
```

### 验证

```bash
bash -n ops/fnos-baseline.sh        # 语法
sh  -n ops/fnos-baseline.sh         # POSIX sh 也能过
sh ops/fnos-baseline.sh | tail -40  # 末尾应是一段合法 JSON（jq . 可验）
```

### 红线

- **只读**：不 start/stop/restart，不写 `/vol1`，不创建临时文件在插件目录里
- 不 `pkill` / `killall` / 按进程名模糊杀
- 输出会过滤 `cookie|authorization|password|secret|token=` 行，并把 URL 里的
  `cpi` / `enc` / `token` / `uuid` 打码；**新增采集项时请沿用这个过滤**
- 单条采集失败只降级成 `unavailable`，绝不中断整份报告

---

## cx-health-check 健康巡检

### 背景

`fnos-baseline.sh` 是「人工按需体检」，这个是把最关键的几项做成**每 5 分钟自动巡检**，
结果落成一行一条的 NDJSON，方便 `tail` / `jq` / 脚本消费。

退出码按 `docs/TEAM-CONTRACT-2026-10-30.md` §3.3：

| 码 | 含义 |
|---|---|
| 0 | 全部正常 |
| 10 | `dsh-admin` 不是 active |
| 11 | 端口 `3290` 未监听 |
| 12 | `/health` 非 200 或 `ok:false`（`/health` 不存在时回退看 `/status` 是否 200） |
| 13 | 内核二进制缺失 / 不可执行 |
| 14 | `/dev/shm` 可用 < 256MB |
| 15 | 任务在跑但 `browser.json` 的 `heartbeatAt` 超过 10 分钟没更新 |
| 20 | 脚本自身异常（依赖缺失 / 参数错） |

同时命中多条时按 10→11→12→13→14→15 取第一个当退出码，其余仍写进 `checks`。

### 为什么 /health 不存在时要回退

`/health` 是 Agent C 正在实现的新接口，当前返回 404。如果把它当失败，
在它上线前每次巡检都会报 12，等于给监控喂噪音。所以逻辑是：

```
/health == 200  → 看 body 里的 ok（true → 通过；false → 12）
/health == 404  → 退回 /status，200 即通过（记 httpMode=status-fallback）
/health 其它码  → 直接 12（5xx / 000 / 401 都算真问题，不回退、不掩盖）
```

`ok:false` **只在 /health 真的存在时才判**，`/status` 没有 ok 语义，不去猜。

### 为什么心跳字段缺失不报 15

`heartbeatAt` 是本次内核层新增字段，老版本不会写。契约 §3.1 明确要求
「字段缺失 → 按 null 处理，不得报错」。所以脚本对心跳的处理是：

| 情况 | checks.heartbeat | 退出码 |
|---|---|---|
| 任务没在跑 | `skip` | 不受影响 |
| 任务在跑，但 `browser.json` 不存在 / 没有 `heartbeatAt` | `missing` | **不报 15** |
| 有 `heartbeatAt` 但解析不了 | `unknown` | 不报 15 |
| 有且超过 600 秒 | `stale` | 15 |

### 落盘

都在 `$DSH_HOME/cx-learn/`（默认 `/vol1/@apphome/fn-deepseek-harness/cx-learn/`）：

```
health.ndjson   一行一条：{"at":"…","code":0,"ok":true,"checks":{…}}
                超过 2MB 轮转成 health.ndjson.1（只留一份，不铺满磁盘）
health.alert    异常时写一行摘要（<时间> code=<码> <原因>），恢复正常时自动删掉
```

### 装法

```bash
B=/vol1/@apphome/fn-deepseek-harness/bin
sudo cp ops/cx-health-check "$B/cx-health-check"
sudo chmod +x "$B/cx-health-check"
sudo chown fn-deepseek-harness:fn-deepseek-harness "$B/cx-health-check"

sudo cp ops/cx-health-check.service ops/cx-health-check.timer /etc/systemd/system/
sudo chmod 644 /etc/systemd/system/cx-health-check.{service,timer}
sudo systemctl daemon-reload
sudo systemctl enable --now cx-health-check.timer
```

### 验证

```bash
# 手动跑一次，直接看输出与退出码
sudo -u fn-deepseek-harness /vol1/@apphome/fn-deepseek-harness/bin/cx-health-check; echo "exit=$?"

# 只打印不落盘（试跑新版本时用这个，别污染 health.ndjson）
CX_NO_WRITE=1 sh ops/cx-health-check; echo "exit=$?"

# 看调度与上次结果
systemctl list-timers cx-health-check.timer
systemctl status cx-health-check.service --no-pager
journalctl -u cx-health-check.service -n 30 --no-pager

# 看历史
tail -5 /vol1/@apphome/fn-deepseek-harness/cx-learn/health.ndjson
cat /vol1/@apphome/fn-deepseek-harness/cx-learn/health.alert 2>/dev/null
```

### 环境变量

| 变量 | 默认 | 作用 |
|---|---|---|
| `DSH_HOME` | `/vol1/@apphome/fn-deepseek-harness` | state 目录根 |
| `CX_PORT` | `3290` | 被巡检实例的端口 |
| `CX_PLUGIN_DIR` | `/vol1/@apphome/dsh-shared/lib/node_modules/dsh-cx-learn` | 找 `engine/.state/browser.json` |
| `CX_CHROME_PATH` | `/vol1/@apphome/dsh-shared/browsers/chrome-linux64/chrome` | 内核路径 |
| `CX_HB_MAX_SEC` | `600` | 心跳最大年龄 |
| `CX_NO_WRITE` | `0` | 设 `1` 只打印不落盘 |

### 关于 unit 显示 failed

`cx-health-check.service` **故意不设** `SuccessExitStatus`：退出码 10–15 表示「发现了问题」，
让 unit 变 failed 后 `systemctl --failed` / 告警面板能直接看见，比只躺在 ndjson 里更容易被发现。
timer 的 `OnUnitActiveSec` 不受上次结果影响，仍然每 5 分钟照跑。

如果不想要红灯（比如接了别的告警通道，只想静默记录），在 `[Service]` 加一行即可：

```ini
SuccessExitStatus=0 10 11 12 13 14 15 20
```

### 实测记录（2026-10-30）

| 场景 | 结果 |
|---|---|
| 真实环境（`dsh-admin` active、`/health` 404） | `exit=0`，`httpMode=status-fallback` |
| 内核路径指向不存在文件 | `exit=13` |
| 端口改成 3399 | `exit=11` |
| mock `/health` 200 + `ok:false` | `exit=12` |
| mock `/health` 200 + `ok:true`，`heartbeatAt` 是几小时前 | `exit=15` |
| 同上但心跳新鲜 | `exit=0` |
| mock `/health` 404、`/status` 200 | `exit=0`（回退生效） |
| mock `/health` 500 | `exit=12`（不回退，直接判失败） |
| 伪造 `df` 报 `/dev/shm` 只剩 100MB | `exit=14` |
| 伪造 `systemctl` 报 inactive | `exit=10` |
| `env -i PATH=/nonexistent` | `exit=20` |
| NDJSON 写到 2.1MB 再跑一次 | 轮转成 `health.ndjson.1`，主文件重新开始；`health.alert` 在恢复正常后被删掉 |

### 红线

- **只读**：不重启、不 stop、不 kill、不装包、不改归属
- 只写 `$DSH_HOME/cx-learn/` 下的 `health.ndjson` / `health.alert`（没有权限就不写，只告警）
- 不 `pkill` / `killall`；不按进程名模糊杀
- 不输出 cookie / token / 口令（只报 HTTP 码和 `ok` 字段）

---

## deploy/rollback 部署与回滚

### 背景

`dsh-cx-learn` 的远端目录是 `/vol1/@apphome/dsh-shared/lib/node_modules/dsh-cx-learn/`，
被 `dsh-admin` 和 5 个 `dsh-user@*` 实例共享。手工 `cp` 最容易踩的三个坑：

1. **归属错了** → 别的用户读不到，插件静默不加载
2. **权限位丢了 setgid** → 新生成的文件不再继承 `dshusers` 组
3. **覆盖后没重启 / 重启后没验证** → 看到「部署完成」但其实服务没起来

所以做成脚本：**备份 → 拷贝 → 修归属 → 重启 → 校验 → 失败自动回滚**，
并把回滚命令打印出来。

> ⚠️ **这两个脚本会 `systemctl restart dsh-admin`。按团队契约，部署与回滚由主会话统一执行，
> 写脚本的 agent 只做 `--dry-run`。** 任何人跑真部署前请先看一遍 dry-run 输出。

### 用法

```bash
# 1. 先看命令序列（不写盘、不重启）
bash ops/deploy.sh --src /path/to/dsh-cx-learn --dry-run

# 2. 真部署（必须显式 --yes，且需要 root）
sudo bash ops/deploy.sh --src /path/to/dsh-cx-learn --yes
```

参数：

| 参数 | 默认 | 说明 |
|---|---|---|
| `--src <dir>` | 必填 | 本地插件目录，必须含 `index.js` / `client.js` / `engine/*.js` |
| `--target <dir>` | `/vol1/@apphome/dsh-shared/lib/node_modules/dsh-cx-learn` | 远端插件目录 |
| `--backup-root <dir>` | `/vol1/@apphome/dsh-shared/backups` | 备份根目录 |
| `--port <n>` | `3290` | 校验端口 |
| `--wait <sec>` | `15` | 重启后等待 |
| `--dry-run` | — | 只打印 |
| `--yes` | — | 真部署必填 |

### 步骤（deploy.sh）

```
1/7 前置检查    src 完整性、目标目录存在、curl 可用；打印当前 is-active 与 /status
2/7 备份        cp -a 整个插件目录 → $BACKUP_ROOT/dsh-cx-learn-YYYYmmdd-HHMMSS
                备份里没有 index.js 就中止（此时目标目录还没动过）
3/7 拷贝        index.js、client.js、engine/*.js
                —— 用 install -m 0664 -o fn-deepseek-harness -g dshusers 逐个落盘
                —— 不碰 engine/.state/（运行期状态，要保留）
4/7 归属权限    chown -R fn-deepseek-harness / chgrp -R dshusers
                目录 2775（setgid）/ 文件 664
                拷贝完整性校验：逐文件 cmp，内容不一致就直接用备份覆盖回去并退出 3
                —— 在重启之前拦下，服务仍在跑旧代码
5/7 重启        systemctl restart dsh-admin —— 全脚本唯一允许的服务操作
6/7 校验        sleep 15 → is-active == active → /status == 200
                → /health：200 看 ok，404 跳过并提示「未实现」
7/7 结果        成功：打印备份路径 + 回滚命令，退出 0
                失败：自动覆盖回备份 → 修归属 → 重启 → 再校验
                      回滚后健康 → 退出 3；回滚后还不健康 → 退出 4（要人介入）
```

退出码：`0` 成功 / `2` 参数或前置检查不过（什么都没动）/ `3` 失败并已还原成部署前内容
（拷贝后 `cmp` 不一致会在**重启前**直接还原；重启后校验失败则自动回滚，回滚后健康也退 3）
/ `4` 回滚后仍不健康（要人介入）。

### 回滚（rollback.sh）

```bash
# 交互式（会先问一次 y/N）
sudo bash ops/rollback.sh --backup /vol1/@apphome/dsh-shared/backups/dsh-cx-learn-20261030-073000

# 无人值守（跳过确认）
sudo bash ops/rollback.sh --backup <目录> --yes

# 只看会做什么
bash ops/rollback.sh --backup <目录> --dry-run
```

校验：备份目录必须存在、必须含 `index.js`；如果备份里有 `engine/`，
`engine/chaoxing-autolearn.js` 也必须在（防止拿半截备份还原）。

动作：`cp -a 备份/. → 目标`（**覆盖式**，不 `rm -rf` 目标目录 —— 里面还有 `.bak-*` 历史文件）
→ 修归属权限 → `systemctl restart dsh-admin` → 等 15s → `/status` 必须 200。

### 为什么不 `rm -rf` 目标目录再拷

插件目录里除了当前版本，还留着 `.bak-oss-20261025-192148/`、`engine/.bak-chaoxing-204629`
这类历史文件。整目录删除会把它们一起抹掉，而且一旦 `cp` 中途失败，目录就空了。
覆盖式还原最坏情况是「新文件残留」，比「目录空掉」好收拾得多。

### 验证

```bash
bash -n ops/deploy.sh && bash -n ops/rollback.sh
bash ops/deploy.sh --src . --dry-run | less      # 人工核对命令序列
bash ops/rollback.sh --backup <不存在的目录>      # 期望 exit=2 且不动作
```

### 红线

- **只 restart `dsh-admin`**，绝不 `pkill` / `killall` / 按进程名模糊杀
- 只写 `index.js`、`client.js`、`engine/*.js`；**不碰 `engine/.state/`**
- 备份不成功就中止，不许「先覆盖再说」
- 真部署必须 `--yes` + root；默认行为是只打印
- 部署完必须校验；校验不过必须自动回滚，不许留半成品
