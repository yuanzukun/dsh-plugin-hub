#!/bin/bash
# rollback.sh —— 从备份目录整体还原 dsh-cx-learn 并重启 dsh-admin
#
# ⚠️ 会 `systemctl restart dsh-admin`。按团队契约，**只由主会话执行**。
#
# 用法：
#   sudo bash ops/rollback.sh --backup /vol1/@apphome/dsh-shared/backups/dsh-cx-learn-20261030-073000
#   sudo bash ops/rollback.sh --backup <目录> --yes     # 跳过交互确认（无人值守用）
#   bash ops/rollback.sh --backup <目录> --dry-run      # 只打印，不写不重启
#
# 校验：
#   · 备份目录必须存在
#   · 必须含 index.js（不接受空目录 / 半截备份）
#   · 若备份里有 engine/，engine/chaoxing-autolearn.js 也必须在
#
# 退出码：
#   0  回滚成功且 /status 200
#   2  参数错 / 备份目录不合格（什么都没动）
#   3  回滚后校验失败
#
# 红线：只 restart dsh-admin；不 pkill / killall；不删目标目录（覆盖式还原）。

set -uo pipefail

BK=''
TGT='/vol1/@apphome/dsh-shared/lib/node_modules/dsh-cx-learn'
PORT=3290
WAIT=15
YES=0
DRY=0

while [ $# -gt 0 ]; do
  case "$1" in
    --backup) BK=${2:-}; shift 2 ;;
    --backup=*) BK=${1#--backup=}; shift ;;
    --target) TGT=${2:-}; shift 2 ;;
    --target=*) TGT=${1#--target=}; shift ;;
    --port) PORT=${2:-}; shift 2 ;;
    --port=*) PORT=${1#--port=}; shift ;;
    --wait) WAIT=${2:-}; shift 2 ;;
    --wait=*) WAIT=${1#--wait=}; shift ;;
    --yes|-y) YES=1; shift ;;
    --dry-run) DRY=1; shift ;;
    -h|--help) sed -n '2,26p' "$0"; exit 0 ;;
    *) echo "未知参数：$1（--help 看用法）" >&2; exit 2 ;;
  esac
done

log() { printf '%s\n' "$*"; }
die() { printf 'rollback: %s\n' "$*" >&2; exit 2; }

run() {
  printf '+ %s\n' "$*"
  if [ "$DRY" = 0 ]; then "$@"; fi
}

# ── 校验备份 ────────────────────────────────────────────────────────────────
[ -n "$BK" ] || die '缺少 --backup <备份目录>'
[ -d "$BK" ] || die "备份目录不存在：$BK"
[ -f "$BK/index.js" ] || die "备份目录里没有 index.js（不是有效备份）：$BK"
if [ -d "$BK/engine" ] && [ ! -f "$BK/engine/chaoxing-autolearn.js" ]; then
  die "备份里有 engine/ 但缺 chaoxing-autolearn.js，备份不完整：$BK"
fi
[ -d "$TGT" ] || die "远端目标目录不存在：$TGT"

if [ "$DRY" = 0 ]; then
  [ "$(id -u 2>/dev/null || echo 1)" = 0 ] || die '回滚需要 root（chown / systemctl restart）：请用 sudo bash 运行'
  if [ "$YES" != 1 ]; then
    log "即将用备份覆盖 $TGT 并重启 dsh-admin："
    log "  备份：$BK"
    printf '继续？[y/N] '
    read -r ans || ans=''
    case "$ans" in y|Y|yes|YES) : ;; *) log '已取消（什么都没动）'; exit 2 ;; esac
  fi
fi

API="http://127.0.0.1:$PORT/api/cx-learn"

log '=========================================================='
log " dsh-cx-learn 回滚  backup=$BK"
log "                     target=$TGT"
[ "$DRY" = 1 ] && log ' 模式：DRY-RUN（只打印，不写盘、不重启）'
log '=========================================================='

# ── 1/4 覆盖还原 ────────────────────────────────────────────────────────────
log ''
log '[1/4] 覆盖还原（cp -a 备份内容 → 目标；不删目标里的其它文件）'
run cp -a "$BK/." "$TGT/"

# ── 2/4 归属 / 权限 ─────────────────────────────────────────────────────────
log ''
log '[2/4] 修归属与权限'
run chown -R fn-deepseek-harness "$TGT"
run chgrp -R dshusers "$TGT"
run find "$TGT" -type d -exec chmod 2775 {} +
run find "$TGT" -type f -exec chmod 664 {} +
run chmod 2775 "$TGT"

# ── 3/4 重启 ────────────────────────────────────────────────────────────────
log ''
log '[3/4] 重启 dsh-admin'
run systemctl restart dsh-admin

# ── 4/4 校验 ────────────────────────────────────────────────────────────────
log ''
log "[4/4] 等待 ${WAIT}s 后校验 /status"
if [ "$DRY" = 1 ]; then
  log "+ sleep $WAIT"
  log "+ systemctl is-active dsh-admin"
  log "+ curl -s -o /dev/null -w '%{http_code}' $API/status      # 期望 200"
  log ''
  log 'DRY-RUN 结束：没有写任何文件，没有重启任何服务。'
  exit 0
fi

sleep "$WAIT"
ACT=$(systemctl is-active dsh-admin 2>/dev/null || true)
SC=$(curl -s -o /dev/null -w '%{http_code}' --max-time 8 "$API/status" 2>/dev/null)
case "${SC:-}" in ''|*[!0-9]*) SC=000 ;; esac
log "  is-active = ${ACT:-unknown}"
log "  /status   = $SC"

if [ "$ACT" = active ] && [ "$SC" = 200 ]; then
  log ''
  log ' 回滚成功。'
  log ' 建议再跑一次：sh ops/cx-health-check'
  exit 0
fi

log ''
log ' !! 回滚后仍不健康，需要人工介入 !!'
log " 备份目录：$BK"
exit 3
