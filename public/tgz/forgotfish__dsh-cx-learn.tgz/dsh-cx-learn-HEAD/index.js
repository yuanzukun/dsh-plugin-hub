/**
 * dsh-cx-learn —— host 半端
 * ============================================================================
 * 把「学习通自动看课」做成 DSH 插件：
 *   1. 引擎（engine/chaoxing-autolearn.js）原样保留，本插件只做**包装**：
 *      配置、进程生命周期、HTTP 接口、设置页 UI。
 *   2. 设置页（client.js）通过 /api/cx-learn/* 读写配置、看状态、扫码登录、启停任务。
 *   3. 运行期数据落在 $DSH_HOME/cx-learn/：
 *      config.json / state.json / run.log / .login/latest.png / browser-profile/
 *
 * 设计要点：
 *   - 浏览器内核与插件解耦：内核放在一个**共享目录**里，设置页可选择不同内核，
 *     换机器时只要把内核丢进那个目录就能直接用，不用改插件。
 *   - 默认安全模式只识别题目并暂停，题目进入人工审阅队列；不会自主答题、填空或提交。
 *   - 旧模型目录与答题接口保留作兼容/诊断，但正常启动入口强制使用 skip。
 * ============================================================================
 */
import { execFile, execFileSync, spawn } from 'node:child_process'
import { createServer } from 'node:http'
import {
  appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, unlinkSync, writeFileSync,
} from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'cx-learn'
/**
 * ★★★ inject 的最终结论（三次踩坑后）★★★
 *
 * cordis 的 inject **只识别数组形式**。写成对象 `{ webServer: {required:false} }`
 * 会被忽略 —— 表现为插件照样报 `cannot get property "webServer" without inject`
 * 并且在 apply() 构造函数里直接抛错（try/catch 抓不到，因为发生在取值那一刻）。
 *
 * 三次踩坑记录：
 *   坑1（2026-10-27 本机）：数组写全是「硬要求」，宿主缺服务 → 插件 pending
 *        → 阻塞整个 DSH 启动。本机 Electron 版缺 webServer/attachments。
 *   坑2（2026-10-28 FNOS）：为躲坑1 把 inject 砍成 ['llm'] → apply 里访问
 *        ctx.webServer 直接抛错 → 插件崩 → 设置页状态栏三项全空。
 *   坑3（本次）：试图用对象形式做「可选」→ cordis 不认，仍抛同样错误。
 *
 * 最终方案：**按目标环境写数组**。
 *   · FNOS（web/headless profile，Node 服务版）：webServer / llm / attachments 都存在 → 三个都写
 *   · 本机 Electron 版：缺 webServer/attachments → 只写 llm
 * 由环境变量 CX_INJECT_MINIMAL 控制：
 *   CX_INJECT_MINIMAL=1 → 只注入 llm（本机用）
 *   未设置            → 注入全部三个（FNOS 用）
 */
const _minimalInject = String(process.env.CX_INJECT_MINIMAL || '') === '1'
export const inject = _minimalInject
  ? ['llm']
  : ['webServer', 'llm', 'attachments']

const PLUGIN_DIR = dirname(fileURLToPath(import.meta.url))
const ENGINE = join(PLUGIN_DIR, 'engine', 'chaoxing-autolearn.js')
const DSH_HOME = process.env.DSH_HOME || process.env.HOME || '/tmp'
const STATE = join(DSH_HOME, 'cx-learn')
const CFG_FILE = join(STATE, 'config.json')
const STATE_FILE = join(STATE, 'state.json')
const LOG_FILE = join(STATE, 'run.log')
const QUESTION_FILE = join(STATE, 'questions.jsonl')

const questionQueue = []
const questionSeen = new Set()
let questionOffset = 0
let questionRemainder = ''

/**
 * 浏览器内核共享目录。
 * 每个子目录是一个内核，内核目录里放可执行文件（chrome / chromium / headless_shell）。
 * 这样换机器时只要把内核丢进这个目录，UI 上就能直接选，不用改插件。
 *
 * 解析顺序：
 *   1. 环境变量 CX_BROWSER_ROOT（显式指定，最高优先级）
 *   2. DSH_HOME/cx-learn/browsers（跟插件数据放一起，默认）
 *   3. 若干常见共享位置（fnOS / NAS 场景）
 */
const BROWSER_ROOT_CANDIDATES = [
  process.env.CX_BROWSER_ROOT,
  join(DSH_HOME, 'cx-learn', 'browsers'),
  '/vol1/@apphome/dsh-shared/browsers',
  '/opt/dsh-shared/browsers',
  join(PLUGIN_DIR, '.browser'),
].filter(Boolean)

/** 选定的内核根目录（启动时探测一次，探测不到就用第一个候选）。 */
const BROWSER_ROOT = BROWSER_ROOT_CANDIDATES.find((p) => {
  try { return statSync(p).isDirectory() } catch { return false }
}) || BROWSER_ROOT_CANDIDATES[0]

/** 系统里可能存在的 chromium 可执行名（按顺序探测）。 */
const SYSTEM_CHROMIUM_NAMES = ['chromium', 'chromium-browser', 'google-chrome', 'google-chrome-stable']

const DEFAULT_CFG = {
  courseUrl: '',
  mode: 'continue_chapters',
  maxSections: 5,
  videoDoneAt: '98.5%',
  // 浏览器内核：'' = 自动（优先共享区，其次系统）
  browserId: '',
  // 自定义内核路径（非空时优先于 browserId）
  chromiumPath: '',
  headless: true,
  /* 默认 skip 模式（2026-10-28 行为已更新）：
     · 视频内随堂题（.ans-videoquiz）：按选项顺序盲试，答错换下一个直到答对
       （主人确认随堂题不计入课程成绩）；遇「回看」惩罚或次数耗尽立即停。
     · 章节测验/作业（.TiMu）：只识别、记录，绝不作答、绝不提交；
       视频看完后直接 advanceSection 跳到下一节继续看。
     引擎侧对应开关：CONFIG.safety.skipChapterQuiz（默认 true）。 */
  quizMode: 'skip',
  // 答题模型 id，来源见 quizModelCatalog()（skip 模式下不请求模型）
  quizModel: '',
}

/**
 * 插件内置模型（智谱 OpenAI 兼容接口，key 取 ZHIPU_API_KEY）。
 * 这些不依赖 DSH 的 llm 服务，任何用户开箱即用。
 */
const BUILTIN_MODELS = {
  'zhipu:glm-4.7': {
    label: 'GLM-4.7（内置·智谱，答题准）',
    base: 'https://open.bigmodel.cn/api/paas/v4',
    model: 'glm-4.7',
  },
  'zhipu:glm-4.6': {
    label: 'GLM-4.6（内置·智谱）',
    base: 'https://open.bigmodel.cn/api/paas/v4',
    model: 'glm-4.6',
  },
  'zhipu:glm-5.3-flash': {
    label: 'GLM-5.3-Flash（内置·智谱，快省）',
    base: 'https://open.bigmodel.cn/api/paas/v4',
    model: 'glm-5.3-flash',
  },
}

let child = null
/** ctx.llm 句柄，装配时注入。 */
let llmCtx = null

const ensureDir = () => { if (!existsSync(STATE)) mkdirSync(STATE, { recursive: true }) }
const readJson = (p, fb) => { try { return JSON.parse(readFileSync(p, 'utf8')) } catch { return fb } }
const writeJson = (p, v) => { ensureDir(); writeFileSync(p, JSON.stringify(v, null, 2)) }
const nowLog = (s) => { ensureDir(); appendFileSync(LOG_FILE, `[plugin] ${new Date().toISOString()} ${s}\n`) }

const getCfg = () => ({ ...DEFAULT_CFG, ...readJson(CFG_FILE, {}) })
const saveCfg = (patch) => {
  const next = { ...getCfg(), ...(patch || {}) }
  writeJson(CFG_FILE, next)
  return next
}
/**
 * 是否有一轮任务在跑。
 * 不能只看内存里的 child：插件重启（DSH 重启 / 热重载）后 child 变 null，
 * 但引擎子进程可能还活着 —— 那样界面会显示「空闲」而实际还在刷课，
 * 主人点「开始看课」就会重复启动。所以额外用 pid 探活兜底。
 */
const running = () => {
  if (child && child.exitCode === null) return true
  const pid = Number(readJson(STATE_FILE, {}).pid || 0)
  if (!pid) return false
  try { process.kill(pid, 0); return true } catch { return false }
}

function readQuestionEvents() {
  let text = ''
  try { text = readFileSync(QUESTION_FILE, 'utf8') } catch { return }
  // 文件被轮换/清空时从头读；旧的半行也不能带到新文件。
  if (questionOffset > text.length) {
    questionOffset = 0
    questionRemainder = ''
  }
  const fresh = questionRemainder + text.slice(questionOffset)
  questionOffset = text.length
  const lines = fresh.split('\n')
  // 最后一段没有换行，说明引擎可能仍在写入；保留到下一轮再解析。
  questionRemainder = lines.pop() || ''
  for (const line of lines) {
    if (!line.trim()) continue
    try {
      const q = JSON.parse(line)
      if (!q.id || questionSeen.has(q.id)) continue
      questionSeen.add(q.id)
      questionQueue.push({ ...q, status: 'pending', draftedAt: null })
    } catch { /* 完整但损坏的记录丢弃；半行不会进入这里 */ }
  }
  while (questionQueue.length > 100) questionQueue.shift()
}

function questionDraft(q) {
  const title = q.kind === 'video_embedded_quiz' ? '[视频内随堂题]' : q.kind === 'chapter_work' ? '[章节测验]' : '[待确认题目]'
  const opts = Array.isArray(q.options) ? q.options.map((o) => (o.letter || '') + '. ' + (o.label || '')).join('\n') : ''
  const context = [
    title,
    q.chapterTitle ? '[来源章节] ' + q.chapterTitle : '',
    q.videoTime != null ? '[视频时间] ' + q.videoTime + 's / ' + (q.duration || '?') + 's' : '',
  ].filter(Boolean).join('\n')
  return context + '\n\n题目：' + (q.question || '') + (opts ? '\n选项：\n' + opts : '') +
    '\n\n请先分析这道题，但不要替我操作学习通页面。'
}

function tailLog(n = 40) {
  try {
    const t = readFileSync(LOG_FILE, 'utf8')
    return t.slice(-12000).split('\n').slice(-n).join('\n')
  } catch { return '' }
}

/* ── 浏览器内核目录 ─────────────────────────────────────────────────────── */

/** 在一个内核目录里找到可执行文件（chrome / chromium / headless_shell / chrome-headless-shell）。 */
function findBinaryIn(dir) {
  const names = ['chrome', 'chromium', 'chromium-browser', 'headless_shell', 'chrome-headless-shell']
  for (const n of names) {
    const p = join(dir, n)
    try { if (existsSync(p) && statSync(p).isFile()) return p } catch { /* ignore */ }
  }
  return ''
}

/** 扫描共享目录，列出所有可用内核。 */
function listBrowsers() {
  const out = []
  let entries = []
  try { entries = readdirSync(BROWSER_ROOT, { withFileTypes: true }) } catch { entries = [] }
  for (const e of entries) {
    if (!e.isDirectory()) continue
    const dir = join(BROWSER_ROOT, e.name)
    const bin = findBinaryIn(dir)
    if (!bin) continue
    let version = ''
    try {
      version = execFileSyncSafe(bin, '--version')
    } catch { version = '' }
    out.push({
      id: 'shared:' + e.name,
      label: '共享内核 · ' + e.name + (version ? '（' + version + '）' : ''),
      path: bin,
      source: 'shared',
    })
  }
  // 系统内核：按平台给候选路径，保证「换电脑装个 DSH 就能用」
  for (const [p, label] of systemBrowserCandidates()) {
    if (!existsSync(p)) continue
    let version = ''
    try { version = execFileSyncSafe(p, '--version') } catch { version = '' }
    out.push({
      id: 'system:' + label.replace(/\s+/g, '-'),
      label: '系统内核 · ' + label + (version ? '（' + version + '）' : ''),
      path: p,
      source: 'system',
    })
  }
  return out
}

/**
 * 各平台常见 Chrome / Edge / Chromium 安装路径。
 * 目标是「用户什么都不配，插件自己找到本机浏览器」。
 */
function systemBrowserCandidates() {
  const out = []
  if (process.platform === 'win32') {
    const roots = [
      process.env['PROGRAMFILES'] || 'C:\\Program Files',
      process.env['PROGRAMFILES(X86)'] || 'C:\\Program Files (x86)',
      process.env['LOCALAPPDATA'] || '',
    ].filter(Boolean)
    for (const r of roots) {
      out.push([join(r, 'Google\\Chrome\\Application\\chrome.exe'), 'Chrome'])
      out.push([join(r, 'Microsoft\\Edge\\Application\\msedge.exe'), 'Edge'])
      out.push([join(r, 'Chromium\\Application\\chrome.exe'), 'Chromium'])
    }
  } else if (process.platform === 'darwin') {
    out.push(['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', 'Chrome'])
    out.push(['/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', 'Edge'])
    out.push(['/Applications/Chromium.app/Contents/MacOS/Chromium', 'Chromium'])
    out.push(['/Applications/Brave Browser.app/Contents/MacOS/Brave Browser', 'Brave'])
  } else {
    for (const n of SYSTEM_CHROMIUM_NAMES) {
      for (const d of ['/usr/bin', '/usr/local/bin', '/opt/google/chrome', '/snap/bin']) {
        out.push([join(d, n), n])
      }
    }
  }
  return out
}

/** 同步取版本号（不抛异常）。 */
function execFileSyncSafe(bin, arg) {
  try {
    return String(execFileSync(bin, [arg], { timeout: 8000, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }) || '').trim()
  } catch { return '' }
}

/** 解析当前生效的浏览器内核路径。 */
function chromiumPath() {
  const cfg = getCfg()
  // 1) 自定义路径优先
  if (cfg.chromiumPath && existsSync(cfg.chromiumPath)) return cfg.chromiumPath
  // 2) 选中的内核
  const browsers = listBrowsers()
  if (cfg.browserId) {
    const hit = browsers.find((b) => b.id === cfg.browserId)
    if (hit) return hit.path
  }
  // 3) 自动：共享区第一个，其次系统
  const shared = browsers.find((b) => b.source === 'shared')
  if (shared) return shared.path
  const sys = browsers.find((b) => b.source === 'system')
  if (sys) return sys.path
  return 'chromium'
}

/* ── 答题模型目录 ──────────────────────────────────────────────────────── */

/**
 * 汇总可选取模型：
 *   - 用户 DSH 已配置的模型（ctx.llm.listProviders + listModels），
 *     包含 our-free-model / our-free-model-region 的免费模型；
 *   - 插件内置的智谱模型。
 * 返回 [{ id, label, provider, model, source }]
 */
async function quizModelCatalog() {
  const out = []
  // 用户已配置
  try {
    const providers = llmCtx?.llm?.listProviders?.() || []
    for (const p of providers) {
      const pid = p.id || p.provider
      if (!pid) continue
      let models = []
      try { models = await llmCtx.llm.listModels(pid) } catch { models = [] }
      for (const m of models) {
        const id = pid + '/' + m.id
        out.push({
          id,
          label: (m.name || m.id) + '（已配置·' + (p.name || pid) + '）',
          provider: pid,
          model: m.id,
          source: 'user',
        })
      }
    }
  } catch (e) {
    nowLog('listProviders/listModels 失败：' + String(e?.message ?? e))
  }
  // 插件内置
  for (const [id, v] of Object.entries(BUILTIN_MODELS)) {
    out.push({ id, label: v.label, provider: 'zhipu', model: v.model, source: 'builtin', base: v.base })
  }
  return out
}

/** 找到某个模型 id 对应的完整信息。 */
async function findModel(id) {
  const cat = await quizModelCatalog()
  return cat.find((m) => m.id === id) || null
}

/* ── 引擎进程 ──────────────────────────────────────────────────────────── */

function spawnEngine(args) {
  ensureDir()
  clearProfileLock()
  const cfg = getCfg()
  const env = {
    ...process.env,
    CX_CHROMIUM: chromiumPath(),
    // 一次性登录：profile 用临时目录，任务跑完即删（见 purgeEphemeralProfile）
    CX_PROFILE_DIR: ephemeralProfileDir(),
    // 登录结果写机器可读文件，宿主/前端不再靠解析日志猜状态
    CX_LOGIN_RESULT: join(STATE, '.login', 'result.json'),
    // 登录截图必须落在「当前用户」的 state 目录，否则多用户共用一份会互相覆盖
    CX_LOGIN_SHOT_DIR: join(STATE, '.login'),
    // 引擎只把识别到的题目追加到事件文件；该通道不包含答案与页面操作。
    CX_QUESTION_FILE: QUESTION_FILE,
    // 登录态用完就废：引擎跑在独立临时 profile 里
    CX_EPHEMERAL_LOGIN: '1',
  }
  // 强制安全闸门：本任务只负责观看视频，绝不自主答题或提交。
  // 即使旧 config.json 保存过 ai，也不能通过配置把真实作业答题打开。
  env.CX_QUIZ_MODE = 'skip'

  const c = spawn(process.execPath, [ENGINE, ...args], {
    cwd: STATE, env, stdio: ['ignore', 'pipe', 'pipe'],
  })
  c.stdout.on('data', (d) => { try { appendFileSync(LOG_FILE, d) } catch { /* ignore */ } })
  c.stderr.on('data', (d) => { try { appendFileSync(LOG_FILE, d) } catch { /* ignore */ } })
  c.on('exit', (code) => {
    try { appendFileSync(LOG_FILE, `\n[engine exit] code=${code}\n`) } catch { /* ignore */ }
    if (child === c) child = null
    // 一次性登录：看课任务结束即销毁登录态（含 --login 之外的所有引擎进程）
    if (isWatchRun(args)) purgeEphemeralProfile()
  })
  child = c
  return c
}

/** 判断这次 spawn 是不是「看课任务」（登录/预检/读课程/自测都不算）。 */
function isWatchRun(args) {
  const skip = ['--login', '--check-login', '--self-test', '--list-courses', '--serve-mcp']
  return !skip.some((f) => args.includes(f))
}

/**
 * 删除一次性登录 profile（登录态用完即废）。
 * profile 位置与引擎一致：$TMPDIR/cx-learn-ephemeral/session
 */
function purgeEphemeralProfile() {
  const dir = join(tmpdir(), 'cx-learn-ephemeral', 'session')
  // 登录结果文件也一起清，避免旧的 verified 残留误导 /login-state
  try { unlinkSync(join(STATE, '.login', 'result.json')) } catch { /* ignore */ }
  for (let i = 0; i < 6; i++) {
    try {
      rmSync(dir, { recursive: true, force: true })
      nowLog('login state purged: ' + dir)
      return true
    } catch (e) {
      // 浏览器刚退出时可能还占着文件，稍等重试
      try { execFileSyncSafe('sleep', '0.5') } catch { /* ignore */ }
    }
  }
  nowLog('purge login state failed: ' + dir)
  return false
}

/* ── host 端答题回调（给引擎子进程用） ────────────────────────────────── */

/** 引擎子进程拿不到 ctx.llm，所以 host 起一个 loopback 端点供它回调。 */
let askUrl = ''
let askToken = ''

function startAskServer() {
  if (askUrl) return
  const token = Math.random().toString(36).slice(2) + Date.now().toString(36)
  const srv = createServer(async (req, res) => {
    const chunks = []
    for await (const c of req) chunks.push(c)
    const raw = Buffer.concat(chunks).toString('utf8')
    const reply = (code, obj) => {
      const b = Buffer.from(JSON.stringify(obj))
      res.writeHead(code, { 'content-type': 'application/json', 'content-length': String(b.length) })
      res.end(b)
    }
    try {
      const hdr = req.headers['x-cx-token']
      if (hdr !== token) return reply(403, { ok: false, error: 'bad token' })
      const body = JSON.parse(raw || '{}')
      const provider = String(body.provider || '')
      const model = String(body.model || '')
      const prompt = String(body.prompt || '')
      const image = String(body.image || '')
      if (!provider || !model || !prompt) return reply(400, { ok: false, error: 'missing fields' })
      const text = await askViaLlm(provider, model, prompt, false, image)
      return reply(200, { ok: true, text })
    } catch (e) {
      return reply(500, { ok: false, error: String(e?.message ?? e) })
    }
  })
  srv.listen(0, '127.0.0.1', () => {
    const addr = srv.address()
    askUrl = 'http://127.0.0.1:' + addr.port + '/ask'
    askToken = token
    nowLog('ask server up at ' + askUrl)
  })
  srv.unref?.()
}

/** 最近一次调用的 chunk 摘要（调试用）。 */
let lastChunks = []

/**
 * 从模型回复里解析出选项字母。
 *
 * 直接 match(/[A-Z]/) 是不行的：模型若回 "The answer is A" 或 "选 B"，
 * 首个大写字母会是 T / B 之外的杂音。分三档取：
 *   1. 「答案/正确/选/answer/is」等提示词后面的字母（最可靠）
 *   2. 独立的选项字母（前后不是字母数字），如 "B. 1950年"
 *   3. 兜底：正文里第一个 A-Z
 */
function parseAnswerLetter(text, optCount) {
  const maxIdx = (optCount || 4) - 1
  const s = String(text || '')
  if (!s) return -1
  const clamp = (ch) => {
    const i = ch.toUpperCase().charCodeAt(0) - 65
    return i >= 0 && i <= maxIdx ? i : -1
  }
  // 1. 提示词后紧跟的字母
  const m1 = s.match(/(?:答案|正确(?:答案|选项)?|选择|选|answer|correct|option|is)\s*[:：是为]?\s*\**\s*([A-H])/i)
  if (m1) { const i = clamp(m1[1]); if (i >= 0) return i }
  // 2. 独立字母（前后不是字母数字）
  const m2 = s.match(/(?:^|[^A-Za-z0-9])([A-H])(?=$|[^A-Za-z0-9])/)
  if (m2) { const i = clamp(m2[1]); if (i >= 0) return i }
  // 3. 兜底
  const m3 = s.toUpperCase().match(/[A-Z]/)
  if (m3) { const i = m3[0].charCodeAt(0) - 65; if (i >= 0 && i <= maxIdx) return i }
  return -1
}

/**
 * 解析图片载荷：接受 data URL（data:image/png;base64,...）或裸 base64。
 * @returns {{mediaType: string, data: string}|null}
 */
function parseImagePayload(image) {
  const s = String(image || '').trim()
  if (!s) return null
  const m = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/s.exec(s)
  if (m) return { mediaType: m[1].toLowerCase(), data: m[2].replace(/\s+/g, '') }
  if (/^[A-Za-z0-9+/=\r\n]+$/.test(s) && s.length > 128) {
    return { mediaType: 'image/png', data: s.replace(/\s+/g, '') }
  }
  return null
}

/**
 * 把一张图片交给 Host 的附件存储，拿到 durable ref。
 *
 * ctx.attachments.admitPromptContent() 会校验字节、归一化（PNG→8bit sRGB，
 * 超限时重编码 JPEG/WebP）、按 sha256 内容寻址落盘，并返回
 * {type:'image', attachment:{attachmentId:'sha256:…', mediaType, bytes, width, height}}。
 * 这样才符合 DSH 的 attachmentId 契约（自己编 id 会被拒）。
 *
 * @returns {Promise<object|null>} admitted 的 image part，失败返回 null
 */
async function admitImage(img) {
  const store = llmCtx?.attachments
  if (!store?.admitPromptContent) {
    nowLog('附件服务不可用，跳过图片（ctx.attachments.admitPromptContent 缺失）')
    return null
  }
  try {
    const parts = await store.admitPromptContent([
      { type: 'image', mediaType: img.mediaType, data: img.data, name: 'cx-learn-quiz.png' },
    ])
    const admitted = parts.find((p) => p && p.type === 'image' && p.attachment)
    return admitted || null
  } catch (e) {
    nowLog('图片入附件存储失败：' + String(e?.message ?? e))
    return null
  }
}

/**
 * 用 ctx.llm 调一次模型，返回纯文本。
 *
 * 聚合路由（combo:recommended-free 之类）偶尔会**成功返回但正文为空**——
 * 不抛异常、不写日志，只是流里没有 text-delta。这在免费组上很常见。
 * 对答题这种「必须拿到一个字母」的场景，空响应等于没答上，
 * 所以这里对空结果做有限次重试（指数退避），避免一次抖动就判定模型不可用。
 */
async function askViaLlm(provider, model, prompt, debug, image) {
  if (!llmCtx?.llm?.stream) throw new Error('llm 服务不可用')
  /* 超星的题干/选项用加密字体渲染（font-cxsecret），DOM 里是密文，
     只有截图才能拿到明文。所以这里允许附带一张图片。

     DSH 的图片契约不是「随便塞个 url」：
       - 消息块必须是 {type:'image', attachment:{attachmentId:'sha256:<hex>', ...}}，
         attachmentId 由 Host 的附件存储按内容寻址生成，自己编会报
         "Attachment reference is invalid."
       - 正确姿势是走 ctx.attachments.admitPromptContent()：传入
         {type:'image', mediaType, data:<裸base64>}，由 Host 校验并落盘，
         返回带 durable ref 的 admitted part。
     所以这里把 data URL 解成裸 base64 后交给 attachments 处理。 */
  let content = [{ type: 'text', text: prompt }]
  const img = parseImagePayload(image)
  if (img) {
    const part = await admitImage(img)
    if (part) content = [{ type: 'text', text: prompt }, part]
    else nowLog('图片未能进入消息，本次按纯文本作答')
  }
  const options = {
    provider,
    model,
    messages: [{ role: 'user', content }],
    maxTokens: 32,
    purpose: 'cx-learn-quiz',
  }
  const attempts = 3
  let out = ''
  let seen = []
  try {
    for (let attempt = 1; attempt <= attempts; attempt++) {
      out = ''
      seen = []
      let failure = null
      for await (const chunk of llmCtx.llm.stream(options)) {
        if (debug && seen.length < 30) {
          seen.push({ type: chunk?.type, keys: Object.keys(chunk || {}), text: String(chunk?.text || '').slice(0, 80), reason: chunk?.reason ? JSON.stringify(chunk.reason).slice(0, 300) : undefined })
        }
        // 流协议里的文本增量是 type='text-delta'，正文在 chunk.text
        if (chunk && chunk.type === 'text-delta' && typeof chunk.text === 'string') out += chunk.text
        // 兜底：有些适配器直接给 block-end 的 text block
        else if (chunk && chunk.type === 'block-end' && chunk.block && chunk.block.type === 'text' && typeof chunk.block.text === 'string') out += chunk.block.text
        // finish 里带 error（余额不足 / 额度耗尽 / 鉴权失败）：这是硬失败，重试没有意义
        else if (chunk && chunk.type === 'finish' && chunk.reason && chunk.reason.kind === 'error') {
          const f = chunk.reason.failure || {}
          failure = { code: f.code || '', message: f.message || '模型调用失败', status: f.status }
        }
      }
      if (failure) {
        // 额度类/鉴权类错误直接抛出，附上上游给的建议
        const hint = failure.code === 'RATE_LIMIT' ? '（额度不足或限流，充值或换模型）'
          : failure.code === 'INVALID_CREDENTIAL' ? '（鉴权失败，检查 API Key）' : ''
        throw new Error('模型 ' + provider + '/' + model + ' 调用失败：' + failure.message + hint)
      }
      out = out.trim()
      if (out) break
      if (attempt < attempts) {
        nowLog('模型返回空内容，重试中 ' + attempt + '/' + (attempts - 1) + ' provider=' + provider + ' model=' + model)
        await new Promise((r) => setTimeout(r, 800 * attempt))
      }
    }
  } finally {
    if (debug) lastChunks = seen
  }
  return out
}

/* ── 业务动作 ──────────────────────────────────────────────────────────── */

function start(args = {}) {
  if (running()) return { ok: false, error: '已经有一轮在跑了，先停止' }
  const cfg = getCfg()
  const url = String(args.courseUrl || cfg.courseUrl || '').trim()
  if (!url) return { ok: false, error: '还没填课程地址（学习通 studentstudy 页 URL）' }
  if (!existsSync(ENGINE)) return { ok: false, error: '引擎文件缺失：engine/chaoxing-autolearn.js' }

  const mode = String(args.mode || cfg.mode || 'continue_chapters')
  const maxSections = Math.max(1, Math.min(200, Number(args.maxSections || cfg.maxSections) || 5))
  const argv = ['--mode=' + mode, '--max-sections=' + maxSections, '--course-url=' + url]

  try {
    const c = spawnEngine(argv)
    // 记 pid：插件重启后靠它探活，避免「界面空闲但实际还在跑」
    writeJson(STATE_FILE, { startedAt: Date.now(), mode, maxSections, url, pid: c.pid })
    nowLog('start pid=' + c.pid + ' mode=' + mode + ' max=' + maxSections)
    return { ok: true, pid: c.pid }
  } catch (e) {
    return { ok: false, error: '启动失败：' + (e?.message ?? e) }
  }
}

/**
 * 启动前的登录态预检（每次「开始看课」都会调）。
 * 单独跑一次引擎 --check-login：只访问个人空间判断是否已登录，不开二维码。
 * 返回 { ready:true } 表示可以开跑；{ ready:false, needLogin:true } 表示要先扫码。
 */
function precheckLogin() {
  return new Promise((resolve) => {
    if (!existsSync(ENGINE)) return resolve({ ready: false, error: '引擎文件缺失' })
    const env = {
      ...process.env,
      CX_CHROMIUM: chromiumPath(),
      CX_PROFILE_DIR: ephemeralProfileDir(),
      CX_LOGIN_SHOT_DIR: join(STATE, '.login'),
      // 与 spawnEngine 保持一致：一次性模式，只认当前会话的临时 profile
      CX_EPHEMERAL_LOGIN: '1',
    }
    let out = ''
    let done = false
    const finish = (r) => { if (!done) { done = true; resolve(r) } }
    let c
    try {
      c = spawn(process.execPath, [ENGINE, '--check-login'], {
        cwd: STATE, env, stdio: ['ignore', 'pipe', 'pipe'],
      })
    } catch (e) {
      return finish({ ready: false, error: '预检启动失败：' + (e?.message ?? e) })
    }
    c.stdout.on('data', (d) => { out += d })
    c.stderr.on('data', () => { /* 引擎日志走 stderr，预检不看 */ })
    c.on('error', (e) => finish({ ready: false, error: '预检进程错误：' + (e?.message ?? e) }))
    c.on('close', (code) => {
      const idx = out.lastIndexOf('{')
      if (idx < 0) return finish({ ready: false, error: '预检无输出（code=' + code + '）' })
      let j
      try { j = JSON.parse(out.slice(idx)) } catch { return finish({ ready: false, error: '预检结果解析失败' }) }
      if (j && j.ok && j.loggedIn) return finish({ ready: true, url: j.url })
      return finish({
        ready: false,
        needLogin: true,
        url: j && j.url,
        error: j && j.reason ? j.reason : '登录态已失效',
      })
    })
    // 兜底超时：预检不该超过 90 秒
    setTimeout(() => {
      try { c.kill('SIGKILL') } catch { /* ignore */ }
      finish({ ready: false, error: '登录态预检超时' })
    }, 90000).unref?.()
  })
}

function stop() {
  if (!running()) return { ok: false, error: '当前没有任务在跑' }
  const pid = child && child.exitCode === null ? child.pid : Number(readJson(STATE_FILE, {}).pid || 0)
  try {
    if (child && child.exitCode === null) child.kill('SIGTERM')
    else if (pid) process.kill(pid, 'SIGTERM')
  } catch { /* ignore */ }
  nowLog('stop requested pid=' + pid)
  // SIGTERM 可能让引擎来不及跑 finally，这里兜底关浏览器，避免一直占着 9223。
  setTimeout(() => { try { killStrayBrowser() } catch { /* ignore */ } }, 2500)
  // 清掉 pid，避免探活误判
  try {
    const st = readJson(STATE_FILE, {})
    delete st.pid
    writeJson(STATE_FILE, st)
  } catch { /* ignore */ }
  return { ok: true, pid }
}

/**
 * 兜底关掉残留的 headless Chrome。
 * 只在「本插件自己的 profile 目录」上动手，绝不碰其它 Chrome 实例。
 */
function killStrayBrowser() {
  const marker = join(tmpdir(), 'cx-learn-ephemeral')
  const legacy = join(STATE, 'browser-profile')
  let out = ''
  // 依次尝试几种 ps 写法，兼容不同发行版
  for (const args of [['-eo', 'pid=,args='], ['-eo', 'pid,args'], ['-ef']]) {
    try {
      out = String(execFileSync('ps', args, { timeout: 8000, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }) || '')
      if (out.trim()) break
    } catch { /* 换下一种 */ }
  }
  if (!out.trim()) { nowLog('killStrayBrowser: ps 输出为空'); return false }
  let killed = 0
  for (const line of out.split('\n')) {
    if (!line.includes('--remote-debugging-port')) continue
    if (!line.includes(marker) && !line.includes(legacy)) continue
    const m = /^\s*(\d+)/.exec(line)
    if (!m) continue
    try { process.kill(Number(m[1]), 'SIGKILL'); killed += 1 } catch (e) { /* ignore */ }
  }
  nowLog('killed stray browser procs: ' + killed)
  return killed > 0
}

function login() {
  if (running()) return { ok: false, error: '先停止当前任务，再点登录' }
  if (!existsSync(ENGINE)) return { ok: false, error: '引擎文件缺失' }
  try {
    const c = spawnEngine(['--login'])
    nowLog('login pid=' + c.pid)
    return { ok: true, pid: c.pid, hint: '约 10 秒后生成二维码，点「刷新二维码」' }
  } catch (e) {
    return { ok: false, error: '登录进程启动失败：' + (e?.message ?? e) }
  }
}

function qr() {
  // 引擎把截图写在 CX_LOGIN_SHOT_DIR（= 当前用户的 state/.login）下。
  // 优先给「纯二维码图」qr.png（270x270，扫起来最直接）；没有再回退整页截图。
  const shotDir = join(STATE, '.login')
  const rawQr = join(shotDir, 'qr.png')
  if (existsSync(rawQr)) {
    try {
      return {
        ok: true,
        dataUrl: 'data:image/png;base64,' + readFileSync(rawQr).toString('base64'),
        raw: true,
        mtime: statSync(rawQr).mtimeMs,
        path: rawQr,
      }
    } catch { /* fall through */ }
  }
  const candidates = [
    join(shotDir, 'latest.png'),
    join(PLUGIN_DIR, 'engine', '.login', 'latest.png'),
  ]
  for (const p of candidates) {
    if (!existsSync(p)) continue
    try {
      const b = readFileSync(p)
      return {
        ok: true,
        dataUrl: 'data:image/png;base64,' + b.toString('base64'),
        mtime: statSync(p).mtimeMs,
        path: p,
      }
    } catch { /* try next candidate */ }
  }
  return { ok: false, error: '还没有二维码（先点「扫码登录」，等 10 秒再点「刷新二维码」）' }
}

/**
 * 扫码登录进度（前端轮询用）。
 *
 * 以引擎写的机器可读结果文件（.login/result.json）为准，不再靠解析日志猜：
 *   - 引擎在跑        → waiting（等待扫码）
 *   - verified=true   → logged_in（扫完码且回个人空间验证通过）
 *   - reason=timeout  → timeout
 *   - profile 残留但未验证 → stale（上次中断了，登录态不可信，建议重扫）
 */
function loginState() {
  const out = { ok: true, state: 'idle', hint: '' }
  const hasProfile = existsSync(ephemeralProfileDir())
  let res = {}
  try { res = readJson(join(STATE, '.login', 'result.json'), {}) } catch { res = {} }

  if (running()) {
    out.state = 'waiting'
    out.hint = '等待扫码…'
    return out
  }
  if (res.verified && hasProfile) {
    out.state = 'logged_in'
    out.hint = res.already ? '登录态已就绪（无需扫码）' : '登录成功并已验证'
    return out
  }
  if (res.reason === 'timeout') {
    out.state = 'timeout'
    out.hint = '扫码超时，请重新点「开始登录」'
    return out
  }
  if (res.reason === 'verify_failed') {
    out.state = 'timeout'
    out.hint = '扫码后验证失败，请重新点「开始登录」'
    return out
  }
  if (hasProfile) {
    out.state = 'stale'
    out.hint = '上次扫码流程被中断，登录态未确认，请点「开始登录」重新扫码'
    return out
  }
  return out
}

/**
 * 一次性登录的 profile 目录（与引擎 EPHEMERAL_DIR 保持一致）。
 * 登录态只活在这个目录里；看课/读课程都必须用它，不能用旧的 browser-profile。
 */
function ephemeralProfileDir() {
  return join(tmpdir(), 'cx-learn-ephemeral', 'session')
}

/** 清掉残留的 Chrome 单实例锁（pkill 之后必然留下，不清会直接 abort）。 */
function clearProfileLock() {
  // 两个位置都清：一次性临时 profile + 历史长久 profile
  for (const dir of [ephemeralProfileDir(), join(STATE, 'browser-profile')]) {
    for (const f of ['SingletonLock', 'SingletonCookie', 'SingletonSocket']) {
      try {
        const p = join(dir, f)
        if (existsSync(p)) unlinkSync(p)
      } catch { /* ignore */ }
    }
  }
}

/** 读课程列表：跑引擎的 --list-courses（CDP 读渲染后的 DOM），解析 JSON。 */
function listCourses() {
  return new Promise((resolve) => {
    // 引擎在跑时不能起第二个 Chrome（同一 profile 并发会损坏 Cookie）
    if (running()) {
      return resolve({ ok: false, error: '正在看课，先停止再读取课程' })
    }
    const cp = chromiumPath()
    if (cp === 'chromium') return resolve({ ok: false, error: '没找到可用的浏览器内核' })
    if (!existsSync(ENGINE)) return resolve({ ok: false, error: '引擎文件缺失' })
    clearProfileLock()

    const env = {
      ...process.env,
      CX_CHROMIUM: cp,
      // 一次性登录模式下，登录态在临时 profile 里；读课程必须用同一份，否则读不到。
      CX_PROFILE_DIR: ephemeralProfileDir(),
      CX_LOGIN_SHOT_DIR: join(STATE, '.login'),
      CX_EPHEMERAL_LOGIN: '1',
    }
    execFile(process.execPath, [ENGINE, '--list-courses'], {
      cwd: STATE, env, maxBuffer: 16 * 1024 * 1024, timeout: 90000,
    }, (err, stdout) => {
      const out = String(stdout || '')
      // 引擎的日志也走 stdout，JSON 是最后那句 console.log
      const idx = out.lastIndexOf('\n{')
      const start = idx >= 0 ? idx + 1 : out.indexOf('{')
      if (start < 0) {
        return resolve({ ok: false, error: '引擎没有返回结果' + (err ? '：' + err.message : '') })
      }
      try {
        const j = JSON.parse(out.slice(start))
        if (j && j.ok) {
          return resolve({
            ok: true,
            count: j.count || 0,
            courses: (j.courses || []).map((c) => ({
              courseId: c.courseId,
              clazzid: c.clazzid || '',
              enc: c.enc || '',
              title: c.title || '',
              href: c.href || '',
            })),
          })
        }
        return resolve({ ok: false, error: (j && j.error) || '引擎返回异常' })
      } catch (e) {
        return resolve({ ok: false, error: '解析结果失败：' + String(e?.message ?? e) })
      }
    })
  })
}

async function status() {
  readQuestionEvents()
  const cfg = getCfg()
  const cp = chromiumPath()
  const browsers = listBrowsers()
  /* ★ 2026-10-28 修复设置页「环境未就绪 / 引擎缺失 / 内核未找到 / 数据目录为空」：
     原来这里 `const models = await quizModelCatalog()` 是**必需路径**，
     而 quizModelCatalog 会依次调用宿主的 llm.listProviders() / listModels()。
     若宿主 LLM 服务不可用、或远端请求超时（例如配了需要代理的中转模型），
     整个 status() 会长时间挂起 → 前端 fetch 拿不到响应 → st 为 null
     → 状态栏三项全空（连「数据目录」也是空，正是 st 为 null 的特征）。

     现在给模型目录加 2.5 秒超时 + 内置模型兜底，
     保证 status() 一定能快速返回引擎/内核/数据目录这些关键信息。 */
  let models = []
  try {
    models = (await Promise.race([
      quizModelCatalog(),
      new Promise((resolve) => setTimeout(() => resolve(null), 2500)),
    ])) || []
  } catch (e) {
    nowLog('status(): 取模型目录失败，已降级：' + String(e?.message ?? e))
    models = []
  }
  if (!models.length) {
    for (const [id, v] of Object.entries(BUILTIN_MODELS)) {
      models.push({ id, label: v.label, provider: 'zhipu', model: v.model, source: 'builtin', base: v.base })
    }
  }
  const active = models.find((m) => m.id === cfg.quizModel)
  return {
    ok: true,
    running: running(),
    pid: running() ? child.pid : null,
    state: readJson(STATE_FILE, {}),
    config: cfg,
    chromium: cp,
    chromiumReady: cp !== 'chromium' && existsSync(cp),
    browserRoot: BROWSER_ROOT,
    browsers,
    engineReady: existsSync(ENGINE),
    home: STATE,
    logTail: tailLog(25),
    quizMode: String(cfg.quizMode || 'manual'),
    quizModelLabel: active ? active.label : (cfg.quizModel || '未选择'),
    quizModelActive: active ? active.model : '',
    quizModels: models,
    builtinModels: Object.keys(BUILTIN_MODELS),
    zhipuReady: !!process.env.ZHIPU_API_KEY,
    llmReady: !!llmCtx?.llm?.listProviders,
    questions: questionQueue.map((q) => ({ ...q, draft: undefined })),
  }
}

function sendJson(res, code, obj) {
  const b = Buffer.from(JSON.stringify(obj))
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': String(b.length),
    'cache-control': 'no-store',
  })
  res.end(b)
}

async function readBody(req) {
  if (req.method !== 'POST' && req.method !== 'PUT') return {}
  const chunks = []
  for await (const c of req) chunks.push(c)
  const raw = Buffer.concat(chunks).toString('utf8')
  if (!raw) return {}
  try { return JSON.parse(raw) } catch { return {} }
}

export function apply(ctx, config) {
  ensureDir()
  llmCtx = ctx
  nowLog('mounted, plugin dir=' + PLUGIN_DIR)
  try { startAskServer() } catch (e) {
    nowLog('ask server 启动失败（不影响加载）：' + String(e?.message ?? e))
  }

  /* ★ 运行时能力探测。
     ★★★ 关键：访问 ctx.webServer 这个**动作本身**在 cordis 里就可能抛错
     （"cannot get property webServer without inject"）。
     所以必须用 try/catch 包住**取值**，不能只判断它是不是 undefined。 */
  let webServer = null
  try {
    webServer = ctx.webServer
  } catch (e) {
    nowLog('宿主未注入 webServer，设置页/HTTP 接口不可用（仅 CLI 模式）：' + String(e?.message ?? e))
    return
  }
  if (!webServer || typeof webServer.register !== 'function') {
    nowLog('警告：宿主无 webServer 服务，设置页/HTTP 接口不可用（仅 CLI 可用）')
    return
  }

  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: '/api/cx-learn',
    handler: async (req, res) => {
      const u = new URL(req.url, 'http://127.0.0.1')
      const path = u.pathname.replace(/^\/api\/cx-learn/, '') || '/'
      try {
        const body = await readBody(req)
        if (path === '/status' && req.method === 'GET') return sendJson(res, 200, await status())
        if (path === '/config' && req.method === 'GET') return sendJson(res, 200, { ok: true, config: getCfg() })
        if (path === '/config' && req.method === 'POST') return sendJson(res, 200, { ok: true, config: saveCfg(body) })
        if (path === '/models' && req.method === 'GET') return sendJson(res, 200, { ok: true, models: await quizModelCatalog() })
        if (path === '/questions' && req.method === 'GET') {
          readQuestionEvents()
          return sendJson(res, 200, {
            ok: true,
            questions: questionQueue.map((q) => ({ ...q, draft: undefined })),
          })
        }
        const draftMatch = path.match(/^\/questions\/([^/]+)\/draft$/)
        if (draftMatch && req.method === 'POST') {
          readQuestionEvents()
          const id = decodeURIComponent(draftMatch[1])
          const q = questionQueue.find((item) => item.id === id)
          if (!q) return sendJson(res, 404, { ok: false, error: '题目不存在或已被清理' })
          q.status = 'drafted'
          q.draftedAt = new Date().toISOString()
          // 只生成文本返回给 client；client 负责显式调用 setDraft，宿主不发送消息。
          return sendJson(res, 200, { ok: true, id, draft: questionDraft(q), submitted: false })
        }
        if (path === '/models/health' && req.method === 'POST') {
          // 批量探活：给模型列表标注「能不能用」，省得一个个试
          const models = await quizModelCatalog()
          const explicit = Array.isArray(body.models) && body.models.length
            ? body.models
            : null
          // 默认体检清单：优先聚合路由（我们自己的免费组，最稳），再补其他
          const preferred = models
            .filter((m) => m.source === 'user')
            .sort((a, b) => {
              const pri = (m) => (m.id.includes('combo:') ? 0 : m.id.includes('/free') ? 1 : 2)
              return pri(a) - pri(b)
            })
            .map((m) => m.id)
          const targets = explicit || preferred
          const limit = Math.min(Number(body.limit) || 12, targets.length)
          const opts = ['1949年', '1950年', '1978年', '1992年']
          const labels = opts.map((o, j) => String.fromCharCode(65 + j) + '. ' + o).join('\n')
          const prompt = '题目：中华人民共和国成立于哪一年？\n选项：\n' + labels +
            '\n\n只输出正确选项的字母（A/B/C/D…），不要任何解释。'

          /** 探活单个模型。 */
          const probeOne = async (id) => {
            const info = models.find((m) => m.id === id)
            if (!info) return { id, ok: false, error: '未知模型' }
            try {
              let text = ''
              if (info.source === 'builtin' && process.env.ZHIPU_API_KEY) {
                const bm = BUILTIN_MODELS[id]
                const url = String(bm.base).replace(/\/+$/, '') + '/chat/completions'
                const r = await fetch(url, {
                  method: 'POST',
                  headers: { 'content-type': 'application/json', authorization: 'Bearer ' + process.env.ZHIPU_API_KEY },
                  body: JSON.stringify({ model: info.model, messages: [{ role: 'user', content: prompt }], temperature: 0, max_tokens: 16 }),
                })
                if (!r.ok) throw new Error('HTTP ' + r.status)
                const j = await r.json()
                text = String(j?.choices?.[0]?.message?.content || '')
              } else {
                text = await askViaLlm(info.provider, info.model, prompt, false)
              }
              const idx = parseAnswerLetter(text, opts.length)
              if (idx < 0) {
                return { id, label: info.label, ok: false, answer: '', error: '模型无有效输出（重试后仍为空或未给出选项字母）' }
              }
              return { id, label: info.label, ok: true, answer: String.fromCharCode(65 + idx) }
            } catch (e) {
              return { id, label: info.label, ok: false, error: String(e?.message ?? e).slice(0, 160) }
            }
          }

          // 并发探活（最多 4 路）：串行时一个慢模型会把整轮拖到几分钟
          const CONCURRENCY = 4
          const results = new Array(limit)
          let cursor = 0
          const worker = async () => {
            while (true) {
              const i = cursor++
              if (i >= limit) return
              results[i] = await probeOne(targets[i])
            }
          }
          await Promise.all(Array.from({ length: Math.min(CONCURRENCY, limit) }, worker))
          return sendJson(res, 200, { ok: true, results, tested: limit, total: targets.length })
        }
        if (path === '/browsers' && req.method === 'GET') return sendJson(res, 200, { ok: true, browsers: listBrowsers(), root: BROWSER_ROOT })
        if (path === '/ask-test' && req.method === 'POST') {
          // 测试某个模型能不能答出一道题（用户点一下就知道模型通不通）
          // body.model 传完整 id（provider/model），也兼容只传 model 名
          const modelId = String(body.model || getCfg().quizModel || '')
          const question = String(body.question || '中华人民共和国成立于哪一年？')
          const opts = Array.isArray(body.options) && body.options.length
            ? body.options.map(String)
            : ['1949年', '1950年', '1978年', '1992年']
          const image = String(body.image || '')
          const info = await findModel(modelId)
          if (!info) return sendJson(res, 200, { ok: false, error: '未知模型：' + modelId })
          const labels = opts.map((o, i) => String.fromCharCode(65 + i) + '. ' + o).join('\n')
          const prompt = (image
            ? '这是一道考试题目的截图（超星用加密字体渲染，截图里才是明文）。\n' +
              '请读出题干和全部选项，判断正确答案是哪一个。\n' +
              '只输出正确选项的字母（A/B/C/D），不要任何解释。'
            : '题目：' + question + '\n选项：\n' + labels +
              '\n\n只输出正确选项的字母（A/B/C/D…），不要任何解释。')
          try {
            let text = ''
            if (info.source === 'builtin' && process.env.ZHIPU_API_KEY) {
              const bm = BUILTIN_MODELS[modelId]
              const url = String(bm.base).replace(/\/+$/, '') + '/chat/completions'
              const r = await fetch(url, {
                method: 'POST',
                headers: { 'content-type': 'application/json', authorization: 'Bearer ' + process.env.ZHIPU_API_KEY },
                body: JSON.stringify({ model: info.model, messages: [{ role: 'user', content: prompt }], temperature: 0, max_tokens: 16 }),
              })
              if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + (await r.text()).slice(0, 120))
              const j = await r.json()
              text = String(j?.choices?.[0]?.message?.content || '')
            } else {
              text = await askViaLlm(info.provider, info.model, prompt, body.debug === true, image)
            }
            const idx = parseAnswerLetter(text, opts.length)
            const out = {
              ok: true,
              model: modelId,
              label: info.label,
              raw: text.slice(0, 200),
              answer: idx >= 0 ? String.fromCharCode(65 + idx) : '',
            }
            if (body.debug === true && lastChunks.length) out.chunks = lastChunks
            return sendJson(res, 200, out)
          } catch (e) {
            const out = { ok: false, error: String(e?.message ?? e), model: modelId }
            if (body.debug === true && lastChunks.length) out.chunks = lastChunks
            return sendJson(res, 200, out)
          }
        }
        if (path === '/start' && req.method === 'POST') return sendJson(res, 200, start(body))
        // 每次开跑前刷新登录态：预检失效则明确告知需要扫码，避免跑到一半才 LOGIN_REQUIRED。
        if (path === '/check-login' && req.method === 'POST') {
          const r = await precheckLogin()
          return sendJson(res, 200, { ok: true, ...r })
        }
        if (path === '/start-precheck' && req.method === 'POST') {
          if (running()) return sendJson(res, 200, { ok: false, error: '已经有一轮在跑了，先停止' })
          const pre = await precheckLogin()
          if (!pre.ready) {
            return sendJson(res, 200, {
              ok: false,
              needLogin: true,
              error: (pre.error || '登录态已失效') + ' —— 请先点「开始登录」扫码，再开始看课',
              url: pre.url,
            })
          }
          return sendJson(res, 200, start(body))
        }
        if (path === '/stop' && req.method === 'POST') return sendJson(res, 200, stop())
        if (path === '/login' && req.method === 'POST') return sendJson(res, 200, login())
        if (path === '/qr' && req.method === 'GET') return sendJson(res, 200, qr())
        // 扫码登录进度：前端轮询它来判断「扫完了没」，成功就自动拉课程。
        if (path === '/login-state' && req.method === 'GET') return sendJson(res, 200, loginState())
        if (path === '/courses' && req.method === 'GET') return sendJson(res, 200, await listCourses())
        if (path === '/log' && req.method === 'GET') return sendJson(res, 200, { ok: true, log: tailLog(80) })
        return sendJson(res, 404, { ok: false, error: 'unknown ' + req.method + ' ' + path })
      } catch (e) {
        return sendJson(res, 500, { ok: false, error: String(e?.message ?? e) })
      }
    },
  }), 'cx-learn: /api/cx-learn 路由')

  ctx.effect(() => () => {
    try { child?.kill('SIGTERM') } catch { /* ignore */ }
    nowLog('unmounted, child killed')
  }, 'cx-learn: 卸载时收子进程')

  nowLog('ready, home=' + STATE)
}
