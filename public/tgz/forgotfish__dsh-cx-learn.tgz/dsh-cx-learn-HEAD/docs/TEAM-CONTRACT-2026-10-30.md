# 三目标并行施工契约 · 2026-10-30

> 三个 agent 同时改这个仓库。**先读这一份，再动手。**
> 上一份 `docs/LAYERS.md` 定义的是「浏览器层 ↔ 业务层」的边界；
> 这一份定义的是「本次三路并行」的**文件所有权**和**共享接口**。两者不冲突，都要遵守。

---

## 0. 用户已确认的范围（不可自行扩大）

| 项 | 确认结果 |
|---|---|
| 「浏览器内核修改」 | **只改引擎浏览器层代码**（启动参数 / CDP / 端口发现 / 健康心跳 / 崩溃恢复 / 失败归因）。**不动 Chromium 二进制，不编译源码。** |
| FNOS 远端 | **只读监测 + 备份后部署验证**。agent 只做只读采集和脚本编写；**部署与重启由主会话统一执行**。 |
| 改动清单 | 按下方三节列出的加固清单，不额外加功能。 |

---

## 1. 文件所有权（硬规则）

**只允许改自己那一栏的文件。** 需要改别人的文件 → 停下，在主会话里说明，不要自己动手。

| Agent | 目标 | 独占可写文件 |
|---|---|---|
| **A · 内核层** | 浏览器内核加固 | `engine/chaoxing-autolearn.js`（**仅浏览器层区段**，见 §2）<br>`engine/browser-health.js`（新建）<br>`engine/browser-kernel*.cjs`（测试）<br>`engine/adapter-contract.js`、`engine/state-bus.js`（**仅追加**）<br>`docs/LAYERS.md` |
| **B · 远端** | FNOS 监测与部署 | `ops/**`（含新建脚本、`ops/README.md`） |
| **C · 主程序** | 插件 host + 设置页 | `index.js`<br>`client.js`<br>`README.md`（仅 API 表与架构段） |

**任何人都不许碰**：`.git/`、`package.json`、`cordis.patch.yml`、`docs/memory/`、`docs/HANDOFF-2026-10-28.md`、`node_modules/`。

> `docs/memory/` 含明文口令，被 `.gitignore` 排除，**永不许提交**。

---

## 2. `engine/chaoxing-autolearn.js` 的边界（只有 A 能动）

这是 7400 行单文件。A **只能**改这些函数/区段：

```
chromiumFlagName / mergeChromiumArgs / buildChromiumArgs      ← 启动参数
readDevToolsActivePort / isHeadlessShellKernel / isBareCommandName / resolveCdpPort
inspectProfileLock / isProfileWritable / describeLaunchExit   ← 失败归因
class CdpConn 的前半段（连接、send、close、waitEvent）
createCdpAdapter 里：ensureBrowser / cdpHttp / spawnChromium / waitForCdpEndpoint
                      _openFreshTarget / _probeTarget / _closeTargetQuietly / shutdown
```

**不许改**：`LearnMachine` 及其全部方法、`PAGE_PROBE_SRC`、登录流程（`runLogin` / `readQrUuid` /
`fetchQrAuthStatus*` / `switchToQrMode`）、`selfTest`、`buildCourseReport`、`scanAllCourses`、
所有 `SELECTORS` 常量。

理由：业务层归 `docs/LAYERS.md` 的 B 层，本次不碰；登录卡 `type=3` 是独立阻塞项，
不在本次范围（要不要单开任务由主会话决定）。

---

## 3. 共享接口（三方必须一致，不许单方面改）

### 3.1 `engine/.state/browser.json`（A 写，B/C 读）

现有字段保持不动，**只允许追加**：

```jsonc
{
  "layer": "browser",
  "executablePath": "…", "port": 34319, "host": "127.0.0.1",
  "browserVersion": "Chrome/158.0.8122.0",
  "profileDir": "…", "headless": true, "ready": true,

  // ↓↓↓ 本次新增（A 负责写；缺失时 B/C 必须按 null 处理，不得报错）↓↓↓
  "pid": 12345,                    // 内核进程 pid；附着外部浏览器时为 null
  "alive": true,                   // 最近一次心跳探测结果
  "startedAt": "2026-10-30T00:00:00.000Z",
  "heartbeatAt": "2026-10-30T00:05:00.000Z",  // 每次心跳成功都要刷新
  "uptimeMs": 300000,
  "restarts": 0,                   // 本次任务内自动重启次数
  "lastExit": { "code": 21, "signal": null, "at": "…" } | null,
  "lastErrorKind": ""              // "" | "LAUNCH_FAILED" | "PROFILE_LOCKED"
                                   // | "CRASHED" | "TARGET_UNRESPONSIVE"
}
```

**读方规则**（写进代码，不是口头约定）：文件不存在 / JSON 坏 / 字段缺失 → 返回 `null`，
UI 显示 `—`，监测脚本记 `unknown`。**任何读方都不许因为字段缺失而抛错。**

### 3.2 `GET /api/cx-learn/health`（C 实现，B 消费）

要求：**不调 LLM、不读大文件、<200ms 返回**，任何异常都返回 200 + `ok:false`。

```jsonc
{
  "ok": true,
  "at": "2026-10-30T00:05:00.000Z",
  "engine":   { "ready": true, "path": "…" },
  "chromium": { "path": "…", "ready": true, "version": "Chrome/158.0.8122.0" },
  "browser":  { "alive": true, "port": 34319, "heartbeatAt": "…",
                "ageMs": 4200, "restarts": 0, "lastErrorKind": "" } | null,
  "task":     { "running": false, "pid": null, "startedAt": null },
  "home": "…"
}
```

失败时形如 `{ "ok": false, "at": "…", "error": "…" }`，**HTTP 状态码仍为 200**（监测脚本只看体里的 ok）。

### 3.3 监测脚本退出码（B 定义，主会话消费）

```
0  全部正常
10 dsh-admin 服务未 active
11 端口 3290 未监听
12 /health 返回非 200 或 ok:false
13 内核二进制缺失 / 不可执行
14 /dev/shm 可用 < 256MB（无头内核崩溃头号原因）
15 任务在跑但 browser.json 心跳超过 10 分钟未更新
20 脚本自身异常（参数错、依赖缺失）
```

---

## 4. 三节加固清单（验收标准）

### A · 浏览器内核层

1. **启动参数**：评估并（有依据地）补充 Linux 容器必需项（`--disable-dev-shm-usage` 等）。
   每条新增参数必须在注释里写明「为什么」，并补一条测试断言。**不许为了过测试删断言**；
   确需调整断言时，在提交信息里说明原因。
2. **健康心跳** `engine/browser-health.js`（新建，CommonJS，零依赖）：
   - `probeKernel({host, port, timeoutMs})` → `{ok, version}`，永不抛错；
   - `startHeartbeat({adapter, cfg, bus, intervalMs})` → 定时写 `browser.json` 新字段，
     返回 `stop()`；内核已死时置 `alive:false` 并写 `lastErrorKind:'CRASHED'`；
   - `stopHeartbeat()` 幂等。
3. **崩溃自动恢复**：`ensureBrowser` 后若 CDP 连接中途断开（`_conn` close 事件），
   允许**最多 2 次**自动重启（指数退避 2s / 6s），超过则抛 `FatalStop('BROWSER_CRASHED', …)`
   并写明已重启次数与最后一次退出码。**必须可关闭**（`cfg.cdp.autoRestart === false` 时不重启）。
4. **失败归因**：`describeLaunchExit` 补充 signal 分支（SIGKILL → 疑似 OOM）、
   `ENOSPC`（磁盘满）、`/dev/shm` 过小提示。仍返回 `{code, reason, hint, detail}` 形状不变。
5. **测试**：`node engine/browser-kernel.test.cjs` 全绿；新增 `engine/browser-health.test.cjs`
   覆盖 probeKernel 超时/拒绝、心跳字段形状、stop 幂等。纯函数，不需要真内核。

验收命令：
```powershell
$n = "C:\Users\rem\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
& $n --check engine\chaoxing-autolearn.js
& $n engine\chaoxing-autolearn.js --self-test      # 必须仍是 14/14
& $n engine\browser-kernel.test.cjs                # 必须全绿
& $n engine\browser-health.test.cjs                # 必须全绿
```

### B · FNOS 远端监测

1. `ops/fnos-baseline.sh`：**纯只读**采集基线（主机/负载/内存、`dsh-admin` 与
   `dsh-user@*` 单元状态、3290–3296 监听、插件目录归属与哈希、内核版本、`browser.json`、
   `run.log` 最近错误、磁盘、`/dev/shm`、`dsh-proxy status`、timer）。
2. `ops/cx-health-check` + `.service` + `.timer`（每 5 分钟）：按 §3.3 退出码检查，
   结果追加到 `<DSH_HOME>/cx-learn/health.ndjson`（一行一条 JSON）。
   **只写自己的 state 目录，绝不重启任何服务、不杀任何进程。**
3. `ops/deploy.sh`：备份 → 拷贝 → 修归属（`chgrp dshusers` / 目录 2775 / 文件 664）→
   重启 `dsh-admin` → 校验 `/status` 与 `/health` → 打印回滚命令。
   `ops/rollback.sh`：从备份目录整体还原并重启。
4. `ops/README.md` 补这三节的用法、安装、验证、红线。

红线：脚本里**不许**出现 `pkill` / `killall` / 按进程名模糊杀；重启只允许
`systemctl restart dsh-admin`（在 deploy.sh 里，且需主会话执行）。

验收：`bash -n` 全部脚本通过；`shellcheck` 若可用则无 error 级问题；
在 FNOS 的 `/tmp` 下用只读模式试跑 `cx-health-check` 一次并贴出输出。

### C · 主程序（host + 设置页）

1. `GET /api/cx-learn/health`（§3.2 契约），并从 `status()` 复用同一个采集函数
   （`collectHealth()`），避免两份逻辑漂移。
2. `status()` 增加 `browser` 字段（读 `browser.json`，失败为 `null`），其他字段一个不许删。
3. 设置页 UI 分两组：
   - **「浏览器环境」**：状态栏、内核选择、内核路径、内核目录说明、`重启内核` 按钮；
   - **「课程业务」**：课程地址、播放模式、答题方式、登录、运行控制、待处理题目、日志。
   分组只做视觉分区（小标题 + 间距），**不改任何已有控件的行为与文案含义**。
4. `POST /api/cx-learn/browser/restart`：只清本插件自己的 profile 进程
   （复用 `killStrayBrowser`）+ 删除 `browser.json` + 返回 `{ok, killed}`。
   **绝不允许**按进程名模糊杀，绝不允许碰 9223 上的生产 Chrome。
5. 状态栏新增一行：`内核：就绪 pid 1234 · CDP 34319 · 心跳 4s 前`，缺数据时显示 `—`。

验收命令：
```powershell
& $n --check index.js
& $n --check client.js
git diff --check
```

---

## 5. 通用红线

1. **不许跑真实课程**、不许答题、不许提交作业（FNOS 负载敏感，且 1.1 章节测验已被毁过一次）。
2. **不许重启 FNOS 服务**、不许杀生产 Chrome（`fn-deepseek-harness` 用户、9223 端口）。
3. **不许提交**（`git commit` / `git push` 由主会话统一做）。
4. **不许改 `package.json` 的依赖**（本项目零 npm 依赖是刻意设计）。
5. 报告里**不许出现明文口令、内网 IP、订阅 token**。
6. 遇到需要越界才能解决的问题 → 停下来，在结果里写清楚「需要什么、为什么」，不要自己绕过去。

---

## 6. FNOS 只读访问方式（仅 B 需要）

本机没有可用的 `python` 别名，用 DSH 自带的：

```powershell
$py = "C:\Users\rem\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
cd C:\Users\rem\WorkBuddy\2026-09-29-14-38-34
# 口令见 docs/memory/MEMORY.md（该目录被 .gitignore 排除，永不许提交）
$env:FNOS_USER='rem'; $env:FNOS_PASS='<见记忆归档>'
& $py fnos.py "<远程 shell 命令>"
```

**只读**。允许写 `/tmp` 下自建目录用于试跑脚本；**不许**写 `/vol1`、不许动 systemd、不许 restart。

---

## 7. 已知事实（别重复验证，浪费 10 分钟）

- 服务名是 **`dsh-admin`**（unit `dsh-admin.service`，enabled + active）。
  2026-10-30 00:26 实测：`is-active dsh-admin` → **active**；`is-active dssh-admin` → inactive，
  且 `/etc/systemd/system/dssh-admin.service` 不存在。
  ⚠️ 旧记忆（`docs/memory/INDEX.md` L58 / L368）写「实例服务名是 `dssh-admin`」—— **那是错的**，
  照它写会让所有查询返回 inactive，误判成服务挂了。以本行为准。
- 远端插件目录 `/vol1/@apphome/dsh-shared/lib/node_modules/dsh-cx-learn/` 的 5 个文件
  MD5 **与本地完全一致**，即当前无「远端落后」问题。
- `/api/cx-learn/status` 现在返回 **200**，后端正常；`/api/cx-learn/health` 目前 **404**（尚未实现）。
- 内核：`/vol1/@apphome/dsh-shared/browsers/chrome-linux64/chrome`，
  `Google Chrome for Testing 158.0.8122.0`。
- `/dev/shm` = **4.9G**（不是常见的 64MB 容器，`--disable-dev-shm-usage` 在此非必需，属低成本保险）。
- 内存 **9.9G total / 可用 6.3G**，负载 0.05。**已有一个孤儿内核占 1.3GB**（13 个进程，见 §8）。
- `engine/.state/` 已在 `.gitignore`，属运行期产物。

---

## 8. 2026-10-30 00:26 远端勘察新发现（影响优先级，必读）

### 8.1 内核泄漏：登录超时退出后会留下 13 个 Chrome 进程

**证据**
```
ps -o pid,user,etime,rss -p 572684  → fn-deepseek-harness, 已存活 21 分钟, RSS 252MB
同 user-data-dir 的进程共 13 个，合计 RSS 1335MB
run.log:5856  扫码超时，终止执行登录流程（等待手机端点击确认）
run.log:5873  [engine exit] code=2
```

**链路**：`--login` 超时 → 引擎 `process.exit(2)` → 宿主 `spawnEngine` 的 `exit` 回调
**只做 `purgeEphemeralProfile()`，没有 `killStrayBrowser()`** → 浏览器是 `detached+unref` 起的，
父进程死了它照样活着 → profile 删不掉（被占用）→ 占 1.3GB 直到下次 `stop()` 才被兜底清理。

**这条直接解释了记忆里「飞牛负载敏感 / 曾把内存压满」。**
这是**现有 bug**，不是本次要新增的功能 —— 明天必须先修，否则任何验证都会踩到它。

### 8.2 登录卡 `type=3` 的真实形态

`type:3` 持续 11 分钟（16:05→16:16），`uuid` 全程不变（`ddc36e0d`），`nickname` 恒空，
`mes="未登录"`，直到扫码超时。**`status:true` 一次都没出现** —— 即「已扫待确认」之后
服务端从未把会话推进到已登录。这与记忆里「主人确认 App 里没有确认按钮」吻合。

结论：这不是前端/换码节奏问题，而是**二维码会话与浏览器 cookie 的绑定问题**，
需要独立排查，不能塞进本次内核加固里顺手做。
