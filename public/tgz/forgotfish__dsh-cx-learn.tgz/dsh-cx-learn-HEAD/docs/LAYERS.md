# 分层约定：浏览器层 ↔ 业务层

> **两个人同时在改这个仓库，之前天天 git 冲突、互相破坏假设。**
> 这份文档定义两层的边界、沟通方式、以及谁不许碰什么。
> 改代码前先看一眼自己在哪一层。

---

## 为什么分层

原来的状况：

- 所有人都在 `engine/chaoxing-autolearn.js` 这一个 7400 行的文件上改
- 改「浏览器启动参数」的人，和改「视频完成判定」的人，改动落在相邻行 → **每次都要手工解冲突**
- 更糟的是**语义冲突**：A 调整了 `videoState()` 的返回字段，B 的判定逻辑静默读到 `undefined`，
  跑很久才发现「怎么一节都播不完」
- 日志格式也被两边同时改，谁也看不懂对方的输出

分层后：**两层只通过「契约 + 中间文件」沟通**，一层的内部改动不影响另一层。

---

## 两层各管什么

### A. 浏览器层（内核控制）

**职责**：把浏览器稳定地驱动起来。

| 管 | 不管 |
|---|---|
| 内核路径、启动参数、防节流开关 | 章节、任务点、弹题 |
| CDP 连接、target 管理、session | 视频「算不算看完」 |
| 页面导航、注入脚本、截图 | 目录推进、切节策略 |
| 端口自动发现、profile 管理 | 风控业务语义（只负责「检测到并报告」）|

**代码位置**：`engine/chaoxing-autolearn.js` 里的
`mergeChromiumArgs` / `buildChromiumArgs` / `readDevToolsActivePort` / `createCdpAdapter`

**近期改动**（这两个提交属于这一层）：
- `e1c8bf1` 无头内核静默控制 — 启动参数集中构造 + 调试端口自动发现
- `6150420` enable/disable features 共用集合导致防遮挡开关被抵消

### B. 业务层（学习状态机）

**职责**：判断「这节课到底看完没有」，并推进到下一节。

| 管 | 不管 |
|---|---|
| 目录解析、当前节定位 | 浏览器怎么起来的 |
| 视频完成判定、进度阈值 | 用哪个端口、哪个内核 |
| 随堂弹题盲试 | CDP 协议细节 |
| 章节测验跳过 | target 复用策略 |
| 风控停止/重试的业务决策 | 注入脚本怎么执行 |

**代码位置**：`LearnMachine` 类（`tick` / `advanceSection` / `handleVideoQuiz` /
`_videoTaskDone` / `confirmVideoWatched` 等）

---

## 沟通方式（只允许这两种）

### 1. 契约方法调用

业务层拿到一个 **adapter 实例**，只调用 `engine/adapter-contract.js` 里
`ADAPTER_METHODS` 声明过的方法。当前契约（13 个）：

```
生命周期   ensureBrowser / navigate / shutdown
状态读取   getCurrentUrl / getFrameDocuments / getAllCookies
页面求值   evalInFrame / getText
交互       click / jsClick / typeInto
取证       screenshot / screenshotClip
```

**规则**：

- ✅ 浏览器层**新增**方法 → 安全，业务层不受影响
- ❌ 浏览器层**删除或改签名**已有方法 → 必须同步改契约文件，否则启动自检报错
- ❌ 业务层**不许** `require` 浏览器层实现文件，只能拿 adapter 实例
- ❌ 浏览器层**不许**知道「章节」「任务点」「弹题」这些词

**启动自检**：`CONTRACT.assertAdapter(adapter, who)` 会在 `run()` / `runLogin()`
入口检查，缺方法直接打出 `ADAPTER_CONTRACT_VIOLATION` 并列出缺哪些。

### 2. 中间状态文件

路径定义在 `engine/adapter-contract.js` 的 `FILES`，读写走 `engine/state-bus.js`。

| 文件 | 谁写 | 谁读 | 内容 |
|---|---|---|---|
| `engine/.state/browser.json` | 浏览器层 | 业务层 / 插件 | 内核路径、CDP 端口、profile、版本、是否 headless；**健康心跳**：`pid` / `alive` / `startedAt` / `heartbeatAt` / `uptimeMs` / `restarts` / `lastExit` / `lastErrorKind` |
| `engine/.state/learn.json` | 业务层 | 浏览器层 / 插件 | 当前节、索引、计数器、停止原因 |
| `engine/.state/events.ndjson` | 双方 | 排查用 | 带时间戳的事件流，一行一条，2MB 自动轮转 |

#### `ready` 与 `alive` 的语义区别（2026-10-30）

| 字段 | 谁写 | 含义 | 什么时候变 |
|---|---|---|---|
| `ready` | `ensureBrowser` 一次 | 「启动成功过」 | 只在启动成功后置 `true`，心跳**永不覆盖** |
| `alive` | `browser-health` 心跳 | 「此刻还活着」 | 每次心跳（默认 15s）探 CDP `/json/version` 刷新 |

两者必须分开：用心跳结果去改 `ready` 会让 UI 和浏览器层判断打架
（例如内核崩了但 `ready` 仍为 true，`status()` 显示「就绪」而实际连不上）。

**心跳写文件时是「读回来合并」而不是覆盖** —— 只在已有对象上追加自己管的字段。
否则旧版本插件写进去的 `executablePath` / `profileDir` 会被冲掉，
设置页立刻显示「内核路径为空」。这条有测试钉住（`browser-health.test.cjs`）。

**用法**：

```js
const bus = require('./state-bus.js');

/* 浏览器层：报告自己起来了 */
bus.reportBrowser({ executablePath, port, host, browserVersion, profileDir, ready: true });

/* 业务层：报告切到下一节 */
bus.reportLearn({ phase: 'advanced', section: title, counters });

/* 双方都能：记一条事件 */
bus.emit('learn', 'section-advance', { title, index });
```

**规则**：

- ✅ **加字段**安全（对方读不到就是 `undefined`，自己处理）
- ❌ **改字段名/语义**必须先在这份文档里登记，双方同步
- ✅ 写入是**原子**的（先写 `.tmp` 再 rename），不会读到半个文件
- ✅ 读取**永不抛错**，坏文件当「没有」返回 `null`

---

## 实操：怎么避免再冲突

### 改动前

1. 先判断自己在哪一层（看上面两张表）
2. `git pull` 一次，确认基线
3. 只改自己那一层的文件/函数区段

### 提交前

```bash
# 看一眼自己改到了哪些函数
git diff --stat
git diff | grep '^@@'          # 看 hunk 的上下文标识

# 如果 hunk 落在对方那层的函数里 → 说明越界了，拆出去
```

### 提交信息里标明层

```
feat(browser): ...    ← 浏览器层
feat(learn): ...      ← 业务层
feat(ops): ...        ← 运维脚本
```

这样 `git log --oneline | grep '(browser)'` 就能只看自己那层的历史。

---

## 当前尚未拆完的部分

现在是**逻辑分层**（契约 + 中间文件），**文件还没物理拆开** ——
`chaoxing-autolearn.js` 里仍然两层共处。

### 为什么先不拆

- 单文件引擎是刻意的设计（零 npm 依赖、可直接拷到目标机运行）
- 物理拆成 `browser/` + `learn/` + `main.js` 会引入模块解析路径问题，
  而 FNOS 上插件是从 `node_modules` 软链加载的，路径一变就要重新验证部署
- **先让沟通方式固化下来**，冲突问题就解决了大半；等两层都稳定了再物理拆

### 将来要拆时的目标结构

```
engine/
  adapter-contract.js      ← 契约（已完成）
  state-bus.js             ← 中间总线（已完成）
  browser/
    args.js                ← mergeChromiumArgs / buildChromiumArgs
    launcher.js            ← 启动内核、端口发现
    cdp.js                 ← CdpConn / target 管理
    adapter.js             ← createCdpAdapter（组合上面几个）
  learn/
    state-machine.js       ← LearnMachine / tick
    video.js               ← 视频判定、弹题
    toc.js                 ← 目录解析、切节
  main.js                  ← CLI / run() / 自测
  chaoxing-autolearn.js    ← 保留为入口薄壳（向后兼容）
```

拆的时候**每步只动一层**，拆完立刻部署 FNOS 验证，不要一次拆完。

---

## 红线

1. **业务层不许为了绕过一个浏览器层 bug 而在业务层写 workaround** —— 去改浏览器层，
   或者把 bug 记录下来，别把复杂度堆在没有责任的那一层。
2. **浏览器层不许为了配合某个业务判定而改通用行为** —— 例如「因为视频判定需要，
   就把某个启动参数关掉」。通用参数只管通用正确性。
3. **不许再往同一个函数里同时塞两层逻辑** —— 需要跨层时，加契约方法或加中间文件字段。
4. **改契约必须同时改这份文档** —— 文档和 `adapter-contract.js` 不一致时，
   以 `adapter-contract.js` 为准，并立刻修文档。
