# 贡献指南

感谢参与。这个项目不大，但有几条约定能让它保持可用。

## 开发环境

- Node.js **22 或更高**（用到全局 `fetch` 和 `WebSocket`）
- DeepSeek Harness **0.2.0-rc.1 或更高**
- 一个 Chromium / Chrome 可执行文件（用于本地调试）

## 本地开发

```bash
git clone https://github.com/forgotfish/dsh-cx-learn.git
cd dsh-cx-learn

# 指向本地目录
dsh plugin --profile web add link:$PWD
```

改完代码重启对应的 DSH 实例即可生效。

## 代码结构

```
index.js                 host 半端：进程管理、HTTP 接口、配置、模型目录
client.js                设置页 UI
engine/chaoxing-autolearn.js   引擎：CDP 适配层 + 业务状态机（零依赖）
engine/package.json      把 engine/ 声明为 CommonJS（父目录是 ESM）
cordis.patch.yml         bundle 挂载声明
```

## 约定

1. **引擎保持零 npm 依赖。** 只用 Node 内置模块。若确实需要新依赖，先讨论。
2. **不要硬编码环境路径。** 路径要么走环境变量，要么走候选探测。  
   见 `index.js` 里的 `BROWSER_ROOT_CANDIDATES`。
3. **不要硬编码脆弱选择器。** 探测策略是「语义 → 结构 → 通用兜底」三层，  
   新增定位逻辑请沿用这个结构，不要只加一个 CSS 选择器。
4. **不要绕过人工验证。** 遇到人脸 / 活体 / 验证码一律立即停止。
5. **不碰后端接口。** 不调进度写接口、不伪造上报。
6. **新的可调参数集中到 `CONFIG`。** 包括所有随机延迟的范围。

## 提交前检查

```bash
node --check index.js
node --check client.js
node --check engine/chaoxing-autolearn.js
node engine/chaoxing-autolearn.js --self-test
```

## 提交信息

用祈使句写清楚做了什么，例如：

```
fix: 弹题结构变化时不要误点提交按钮
```

类型前缀：`feat` / `fix` / `docs` / `refactor` / `test` / `chore`。

## 报告 bug

请附上：

- DSH 版本、Node 版本、操作系统
- 浏览器内核版本
- `/api/cx-learn/log` 的相关片段
- 复现步骤

日志里可能含课程 ID 和 URL，贴之前请自行判断是否需要打码。

## 提问

开 issue 即可。涉及学习通页面 DOM 结构的讨论最有价值——  
那部分最容易随平台改版失效。
