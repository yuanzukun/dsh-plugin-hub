# Security Policy

## Supported versions

The latest published `0.1.x` release receives fixes.

## Reporting a vulnerability

Please report security issues privately through
[GitHub Security Advisories](https://github.com/nexlineai/dsh-tui/security/advisories/new)
rather than a public issue. Expect an initial response within a few days.

## Scope

`dsh-tui` is a terminal front end for the DeepSeek Harness agent runtime. It
does not implement sandboxing, permission enforcement, or credential storage
itself — those belong to the harness and are surfaced by the UI. Report issues
in that behavior upstream to
[deepseek-harness](https://github.com/deepseek-ai/deepseek-harness).

Relevant to this project:

- Terminal escape-sequence injection through model or tool output.
- Leaking credentials into rendered output, logs, or the session transcript.
- Misreporting the active permission preset or plan-mode state, since users
  rely on that display to know what the agent is allowed to do.

## Note on permissions

`danger-full-access` disables approval prompts by design. That is the
documented behavior of the preset, not a vulnerability.
