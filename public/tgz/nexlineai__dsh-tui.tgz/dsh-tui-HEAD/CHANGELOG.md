# Changelog

All notable changes to `dsh-tui`.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html). This project is a DeepSeek Harness *plugin*; versions track the UI surface, while the runtime compatibility it expects is declared in its peer dependencies.

## [0.1.2] — 2026-09-15

### Fixed
- **The TUI exited on the first prompt under DSH 0.1.5.** `Session.events` was removed in that release (`snapshotEvents()` replaced it). Six call sites still read the getter, so `summarize` received `undefined` and threw; the prompt handler's fire-and-forget async IIFE had `try/finally` and no `catch`, which turned the throw into an unhandled rejection that app-boot's fail-loud handler reported as `dsh: fatal load failure: TypeError: events is not iterable` before exiting. Reading the log now goes through `sessionEvents(session)` in `src/helpers.ts`, which prefers `snapshotEvents()` and falls back to the older getter, keeping the declared `@deepseek-ai/dsh-session` range honest.
- **`/settings` and bare `/permissions` killed the process.** Both pass the session log to `permissionPresets.current()`, whose parameter changed from the event array to the `Session` (0.1.5 folds the knobs itself). A blanket `.events` → `.snapshotEvents()` rewrite hands it an array and throws `TypeError: session.snapshotEvents is not a function`; they now call `presetOwner(session)`, which returns the value the running release expects.
- **A failed turn no longer ends the session.** The prompt handler catches the error, appends it as an error block in the conversation, and keeps the TUI running.

### Added
- Tests for both helpers: `snapshotEvents()` preferred over the getter, fallback to the getter on older harnesses, and unrecognised input.

## [0.1.1] — 2026-08-21

### Fixed
- **Install failure for consumers.** `@deepseek-ai/dsh-agent`, `dsh-llm`, and `dsh-session` are imported for values at runtime but were declared only as `devDependencies`, so importing the package from a clean install threw `ERR_MODULE_NOT_FOUND`. They are now real `dependencies`.
- **Unresolvable dependency tree.** The `@deepseek-ai/dsh-*` pins mixed the `0.0.1-rc.x` and `0.1.0-rc.x` generations, which cannot satisfy `dsh-agent`'s peer requirements. All harness packages are now aligned on `^0.1.0-rc.6`.
- **Wrong plugin identity.** The invariant companion registered itself as `@deepseek-ai/dsh-tui-app`, a name in the upstream vendor's namespace, instead of `@nexlineai/dsh-tui`.
- **Broken `exports` entry.** `./src/*` was declared but no `src/` directory ships in the tarball.
- Tool-call cards now correlate results by `callId`, so parallel tool calls no longer mark the wrong card as done (the first card previously stayed `running` forever).
- Tool-card bottom borders are measured from the status text rather than a hardcoded width, so `✖ error` and `⠋ running` cards are no longer 1 and 3 cells too wide.
- Text width is measured in terminal cells rather than code units, so CJK and emoji no longer break box alignment and wrapping.
- Overlong single words (long paths, URLs) are hard-broken instead of overflowing the pane.
- The on-screen conversation log is capped at 2000 entries; long sessions no longer slow down the render loop.

### Added
- CI on Node 20/22/24: typecheck, tests, build, plus a packaging smoke test that installs the tarball into a clean project and imports every entry point.
- `CONTRIBUTING.md`, `SECURITY.md`, and issue templates.
- `repository`, `bugs`, `homepage`, `author`, and `engines` metadata.
- Tests for width measurement, wrapping, and tool-result correlation (30 total).

## [0.1.0] — 2026-08-20

### Added
- Full-screen Claude Code / opencode-style terminal UI (alternate screen, header, scrollback, input bar, status bar).
- Live token streaming via `assistant/chunk` text deltas, with a `--no-streaming` / `/stream off` fallback.
- Reasoning ("thinking") display, streamed dim/italic, with `/reasoning on|off` and per-model effort selection.
- Box-drawn tool-call cards with lifecycle markers (`● running` → `✓ done` / `✖ error`) and arg/result previews.
- Lightweight markdown rendering for answers: fenced code blocks, inline code, bold, italic, headings, blockquotes, list bullets.
- Slash commands: `/help`, `/clear`, `/model`, `/resume`, `/compact`, `/permissions`, `/plan`, `/trajectory`, `/settings`, `/doctor`, `/version`, `/status`, `/reasoning`, `/stream`, `/exit`.
- Live model switching (mutates the shared `ModelSelectionRef`; persists via `agentDefaultModel.saveSelection`).
- Session listing and resume via `agents.resume()` with full history replay.
- Permission preset switching (read-only / workspace-write / danger-full-access) via `permissionPresets.set`.
- Plan-mode toggling via `planMode.set`.
- On-demand compaction via `compaction.compactNow`.
- Trajectory view with injected-context noise filtering.
- Environment diagnostics (`/doctor`): API key, workspace writability, model catalog, capability presence.
- Mouse-wheel scrollback (SGR reporting) plus `PgUp`/`PgDn`, with a `↑ N` scroll indicator.
- Emacs line editing (`Ctrl+A/E/U/K/W`), prompt history, slash-command tab completion, UTF-8 input.

### Fixed
- Status-bar redraw no longer scrolls the terminal (removed a trailing newline on the last row).
- `/stream` toggle now refreshes the status bar immediately.
- Streaming turns are no longer aborted by piped-stdin EOF (seed runs before readline opens; the loop settles between turns).
- Turn aggregation flushes the session before summarizing, matching the headless runner.
- User prompt wrapping only prefixes `❯` on the first line; code-block language tags are stripped.
