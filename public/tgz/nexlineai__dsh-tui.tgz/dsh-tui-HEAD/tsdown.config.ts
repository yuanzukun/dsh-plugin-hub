import { defineConfig } from 'tsdown'

export default defineConfig({
  entry: ['src/index.ts', 'src/invariant.ts', 'src/startup.ts'],
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'es2024',
  dts: true,
  clean: true,
  sourcemap: false,
  // The package is `"type": "module"`, so plain `.js` is already ESM. Keeping
  // the `.js` / `.d.ts` extensions matches the published `exports` map.
  outExtensions: () => ({ js: '.js', dts: '.d.ts' }),
  // Externalize everything resolved from the harness install; only this
  // package's own sources get bundled.
  external: [/^@deepseek-ai\//, 'commander'],
})
