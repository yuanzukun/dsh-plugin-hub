# Contributing to dsh-tui

Thanks for taking the time to contribute. Bug reports, terminal-compatibility
notes, and PRs are all welcome.

## Getting set up

```bash
git clone https://github.com/nexlineai/dsh-tui.git
cd dsh-tui
npm install
npm test
```

To run your working copy against a real harness:

```bash
npm run build
dsh plugin --profile tui add /absolute/path/to/dsh-tui
dsh --profile tui
```

## Before opening a PR

```bash
npm run typecheck   # tsc --noEmit, strict
npm test            # vitest
npm run build       # tsdown
```

CI runs all three on Node 20, 22, and 24, plus a packaging smoke test that
installs the built tarball into a clean project and imports every published
entry point. That job exists because a value import declared only as a
`devDependency` resolves fine in this repo but breaks for real users — if you
add an import, make sure the package is in `dependencies`.

## Code conventions

- TypeScript, strict, with `exactOptionalPropertyTypes`; no `any`.
- Every exported symbol carries a JSDoc comment.
- Pure, testable logic goes in `src/helpers.ts` (no Cordis context, no shared
  mutable state) and gets unit tests.
- Rendering code must measure text with `width()`, never `.length` — terminal
  cells and code units are not the same thing for CJK and emoji.

## Project layout

| Path | Role |
|---|---|
| `src/index.ts` | Cordis plugin: agent wiring, turn loop, slash commands |
| `src/ui.ts` | the terminal surface: input, layout, ANSI rendering |
| `src/helpers.ts` | pure formatting helpers |
| `src/startup.ts` | command-line flag parsing |
| `cordis.patch.yml` | the bundle patch that mounts the profile |

## Reporting bugs

Terminal issues are environment-specific, so please include your terminal
emulator and version, `$TERM`, the OS, the Node version, and the output of
`/version` and `/doctor` from inside the TUI.
