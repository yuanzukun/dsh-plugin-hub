# Announcement

Posted to the upstream "Show Your Plugins!" discussion:
https://github.com/deepseek-ai/deepseek-harness/discussions/3715

Still to do: the DeepSeek Harness Discord.

---

**`dsh-tui` — the DeepSeek Harness web UI, reimagined for the terminal.**

The official `dsh` ships a web UI and a one-shot headless mode, but no
interactive terminal agent. `dsh-tui` fills that gap as an installable plugin.

```
❯ read the LICENSE file and tell me its license

✻ thinking
  · The user wants me to read the LICENSE file and tell me its license.

┌─ ⏱ read ──────────────────────────────────────────────────────────────────┐
│ {"file_path": "~/project/LICENSE"}                                         │
└─ ✓ done ───────────────────────────────────────────────────────────────────┘

The project is licensed under the MIT License — free to use, copy, modify…

────────────────────────────────────────────────────────── 5s · 12→45 tok
```

**What it is**

- A full-screen Claude Code / opencode-style TUI for the **DeepSeek Harness agent** — tools, file editing, shell, subagents, sessions, permissions, plan mode. Not a model wrapper.
- **Live token streaming**, **reasoning blocks**, boxed **tool cards**, markdown rendering, scrollback, prompt history, tab-complete.
- **Slash commands**: `/model` (live switch + reasoning effort), `/resume`, `/compact`, `/permissions`, `/plan`, `/trajectory`, `/settings`, `/doctor`, `/version`, `/status`, `/reasoning`, `/stream`.

**Get it**

```bash
npx @deepseek-ai/dsh web --help          # install the official dsh first
dsh plugin --profile tui add @nexlineai/dsh-tui
dsh --profile tui
```

Published on npm as [`@nexlineai/dsh-tui`](https://www.npmjs.com/package/@nexlineai/dsh-tui) — **use v0.1.1 or later**; v0.1.0 could not be imported from a clean install.

Repo: https://github.com/nexlineai/dsh-tui · MIT · macOS + Linux · Node ≥ 20.

Feedback and PRs welcome.
