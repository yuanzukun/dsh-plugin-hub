# Publishing

## Where it lives

- npm: [`@nexlineai/dsh-tui`](https://www.npmjs.com/package/@nexlineai/dsh-tui)
- Repo: https://github.com/nexlineai/dsh-tui
- Topics: `dsh-plugin`, `deepseek-harness`, `cli`, `terminal`, `tui` — the
  `dsh-plugin` topic is how the harness ecosystem discovers plugins.

Upstream does not accept in-tree contributions (pull requests are disabled on
`deepseek-ai/deepseek-harness`); the intended model is plugin repos plus
GitHub Discussions.

## Release checklist

1. Update `CHANGELOG.md` — move entries under a new version heading.
2. Bump `version` in `package.json`.
3. `npm run typecheck && npm test && npm run build`
4. Verify the tarball contents: `npm pack --dry-run`
5. `npm publish` (`prepublishOnly` rebuilds; `publishConfig.access` is public).
6. Tag and push: `git tag v0.1.1 && git push --tags`
7. Create the GitHub release from the tag with the changelog section as notes.

## Dependency policy

The `@deepseek-ai/dsh-*` packages ship as a coordinated generation. The
`latest` npm tag on several of them still points at an older `0.0.1-rc.x`
line, so **do not trust `npm view <pkg> version`** — list all versions and pick
the current `0.1.0-rc.x` generation, which is what `dsh-agent` requires
through its peer dependencies. Mixing generations produces an unresolvable
peer-dependency tree.

Anything imported for a value at runtime belongs in `dependencies`, never
`devDependencies`. The CI packaging job installs the built tarball into a
clean project and imports every entry point specifically to catch that
mistake, which shipped in 0.1.0.
