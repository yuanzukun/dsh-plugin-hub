import assert from 'node:assert/strict'
import test from 'node:test'

import { loadClientBundle } from './client-bundle.mjs'

/**
 * 造一个和宿主同形状的 layout 桩：`panelInfo.getSnapshot()` 给当前面板，
 * `selectPanel(id)` 记录并改写。
 *
 * @param {string|null} initial 初始 activePanelId。
 * @returns {object} layout 桩。
 */
function fakeLayout(initial) {
  const state = { activePanelId: initial }
  const calls = []
  return {
    state,
    calls,
    panelInfo: { getSnapshot: () => ({ ...state }) },
    selectPanel(id) {
      calls.push(id)
      state.activePanelId = id
    },
  }
}

/** 记录监听器的 document 桩，`fire(type)` 触发 capture 监听。 */
function fakeDocument() {
  const listeners = new Map()
  return {
    hidden: false,
    listeners,
    addEventListener(type, fn) {
      if (!listeners.has(type)) listeners.set(type, [])
      listeners.get(type).push(fn)
    },
    removeEventListener(type, fn) {
      const rows = listeners.get(type) ?? []
      const index = rows.indexOf(fn)
      if (index >= 0) rows.splice(index, 1)
    },
    fire(type) {
      for (const fn of [...(listeners.get(type) ?? [])]) fn({ type })
    },
    count() {
      return [...listeners.values()].reduce((sum, rows) => sum + rows.length, 0)
    },
  }
}

test('没有用户手势的自动切换被拦下（宿主三条自动关闭路径都会走到这里）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
  })

  // 1) ui-layout 的 retainMainPanels：注册表瞬时缺条目 → activePanelId = null
  assert.equal(layout.selectPanel(null), false, '没手势的 selectPanel(null) 必须被拦下')
  // 2) ui-workspace 的 replaceMain(..., 'reveal')：openSession 内部关面板
  assert.equal(layout.selectPanel(null), false)
  // 3) 切到别的面板
  assert.equal(layout.selectPanel('paper-reader'), false)
  assert.deepEqual(layout.calls, [], '原方法一次都没被调到——面板没有被切走')
  assert.equal(layout.state.activePanelId, 'super-agent')

  guard()
})

test('用户手势（点击/按键/前进后退）之内的切换照常放行', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  let clock = 1_000
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => clock,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
  })

  for (const type of ['pointerdown', 'mousedown', 'keydown', 'popstate', 'hashchange']) {
    // 每种手势都当成「另一次点击」（真实里不会 10ms 内连发五种），步长要大于
    // 同一次点击的合并窗口（350ms）。
    clock += 400
    doc.fire(type)
    assert.equal(layout.selectPanel(null), undefined, `${type} 之后应当放行`)
    assert.deepEqual(layout.calls.at(-1), null)
    layout.selectPanel('super-agent') // 复位
  }
  assert.equal(layout.calls.filter((id) => id === null).length, 5)
  guard()
})

test('手势是一次性令牌：点开面板那一下不给随后的自动关闭背书', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout(null)
  const doc = fakeDocument()
  let clock = 1_000
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => clock,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
  })

  // 用户点左栏入口（pointerdown + 同一次点击的 mousedown）→ 打开面板，手势被消费
  doc.fire('pointerdown')
  clock += 20
  assert.equal(layout.selectPanel('super-agent'), undefined)
  assert.equal(layout.state.activePanelId, 'super-agent')
  doc.fire('mousedown') // 同一次点击的第二个事件，不能重新上膛
  clock += 5
  assert.equal(layout.selectPanel(null), false, 'pointerdown+mousedown 属同一次点击，只算一次手势')
  assert.equal(layout.state.activePanelId, 'super-agent')

  // 300ms 后宿主自动关面板（注册表抖动）：仍然要拦
  clock += 300
  assert.equal(layout.selectPanel(null), false, '打开面板的手势不能被随后的自动关闭复用')
  assert.equal(layout.state.activePanelId, 'super-agent')

  // 用户真的再点一下（另一次点击）：放行
  clock += 600
  doc.fire('pointerdown')
  clock += 20
  assert.equal(layout.selectPanel(null), undefined)
  assert.equal(layout.state.activePanelId, null)
  guard()
})

test('手势过期、打开本面板、面板不是我们时都不拦', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  let clock = 1_000
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => clock,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
  })

  doc.fire('pointerdown')
  clock += internals.NAV_GESTURE_WINDOW_MS + 1
  assert.equal(layout.selectPanel(null), false, '超出手势窗口的自动切换仍要拦')

  clock += 10
  assert.equal(layout.selectPanel('super-agent'), undefined, '打开本面板永远放行')

  layout.state.activePanelId = null
  assert.equal(layout.selectPanel(null), undefined, '面板本来就没开时不拦')
  layout.state.activePanelId = 'other-panel'
  assert.equal(layout.selectPanel(null), undefined, '已经不在我们面板上时不拦')
  guard()
})

test('插件卸载/条目真的消失时放行（不硬撑一个不存在的面板）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => false,
  })
  assert.equal(layout.selectPanel(null), undefined)
  assert.deepEqual(layout.calls, [null])
  guard()
})

test('解绑后恢复原方法、移除监听；关掉开关就完全不改宿主', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const original = layout.selectPanel
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
  })
  assert.notEqual(layout.selectPanel, original)
  assert.equal(doc.count(), 6, '五个手势监听 + 一个 visibilitychange（通知点击放行令牌）')
  guard()
  assert.equal(layout.selectPanel, original, '解绑后恢复')
  assert.equal(doc.count(), 0, '解绑后不留监听')

  const offLayout = fakeLayout('super-agent')
  const offDoc = fakeDocument()
  const offOriginal = offLayout.selectPanel
  const off = internals.installNavGuard({}, {
    layout: offLayout,
    document: offDoc,
    now: () => 1_000,
    storage: { getItem: () => 'off' },
    isRegistered: () => true,
  })
  assert.equal(offLayout.selectPanel, offOriginal, '关掉后不包装')
  assert.equal(offDoc.count(), 0, '关掉后不监听')
  assert.equal(internals.navGuardEnabled({ getItem: () => 'off' }), false)
  assert.equal(internals.navGuardEnabled({ getItem: () => null }), false, '默认关：没有开关值就不拦导航')
  assert.equal(internals.navGuardEnabled({ getItem: () => 'on' }), true, '只有显式 on 才启用')
  assert.equal(internals.navGuardEnabled({ getItem: () => { throw new Error('denied') } }), false)
  off()
})

test('默认关，且会拆掉上一版默认开启时留在 window 上的守卫', () => {
  const { __internals: internals, __window: win } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const original = layout.selectPanel
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
  })
  assert.notEqual(layout.selectPanel, original, '显式 on 时装上')
  assert.equal(layout.selectPanel(null), false)
  assert.ok(win[internals.NAV_GUARD_REGISTRY_KEY], '注册表在 window 上')

  // 新版默认关：同一页面再次 apply（HMR 重载）时，必须把上一版的守卫拆掉，
  // 不能因为「同一个 layout 已有主」就提前返回、继续拦原生导航。
  const noop = internals.installNavGuard({}, {
    layout,
    document: fakeDocument(),
    now: () => 2_000,
    storage: { getItem: () => null },
    isRegistered: () => true,
  })
  assert.equal(layout.selectPanel, original, '默认关时恢复宿主原方法')
  assert.equal(win[internals.NAV_GUARD_REGISTRY_KEY], undefined, '注册表清掉')
  assert.equal(layout.selectPanel(null), undefined, '放行原生导航')
  guard()
  noop()
})

test('宿主直接写 store（retainMainPanels）也会被拦：条目还在就恢复，条目没了就放行', async () => {
  const { __internals: internals } = loadClientBundle()
  const state = { activePanelId: 'super-agent' }
  const subscribers = new Set()
  const emit = () => { for (const fn of [...subscribers]) fn() }
  let registered = true
  const layout = {
    panelInfo: { getSnapshot: () => ({ ...state }), subscribe: (fn) => { subscribers.add(fn); return () => subscribers.delete(fn) } },
    selectPanel(id) { state.activePanelId = id; emit() },
  }
  const doc = fakeDocument()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => registered,
  })

  // ui-layout:410 —— 注册表瞬时缺条目，直接置 null，不经过 selectPanel
  state.activePanelId = null
  emit()
  await new Promise((resolve) => setTimeout(resolve, 5))
  assert.equal(state.activePanelId, 'super-agent', '条目还在：把面板恢复回来，用户不会被切走')

  // 条目真的没了（插件卸载）：不硬撑
  registered = false
  state.activePanelId = null
  emit()
  await new Promise((resolve) => setTimeout(resolve, 5))
  assert.equal(state.activePanelId, null, '条目消失时放行')

  // 用户自己关（有手势）时不恢复
  registered = true
  state.activePanelId = 'super-agent'
  doc.fire('pointerdown')
  state.activePanelId = null
  emit()
  await new Promise((resolve) => setTimeout(resolve, 5))
  assert.equal(state.activePanelId, null, '合法导航不被拉回')
  guard()
})

test('冻结的 layout / 缺失的 layout 都不会让插件崩', () => {
  const { __internals: internals } = loadClientBundle()
  const frozen = Object.freeze({ panelInfo: { getSnapshot: () => ({ activePanelId: 'super-agent' }) }, selectPanel() {} })
  const doc = fakeDocument()
  assert.doesNotThrow(() => {
    const dispose = internals.installNavGuard({}, { layout: frozen, document: doc, now: () => 1_000, storage: { getItem: () => 'on' } })
    dispose()
  })
  assert.doesNotThrow(() => internals.installNavGuard({}, { layout: undefined, document: undefined })())
})

test('同一个 layout 只包一层（ctx.inject 重复回调也不会叠包装）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const original = layout.selectPanel
  const first = internals.installNavGuard({}, { layout, document: doc, now: () => 1_000, storage: { getItem: () => 'on' }, isRegistered: () => true })
  const second = internals.installNavGuard({}, { layout, document: doc, now: () => 1_000, storage: { getItem: () => 'on' }, isRegistered: () => true })
  assert.equal(doc.count(), 6, '第二层不再挂监听')
  assert.equal(layout.selectPanel(null), false, '只有一层照样拦')
  second()
  assert.equal(layout.selectPanel(null), false, '一次解绑不会把守卫拆掉')
  first()
  assert.equal(layout.selectPanel, original, '真正解绑后恢复原方法')
  assert.equal(doc.count(), 0)
})

/** 造一个「主视图 retain 着 s-1」的 sessions 服务桩。 */
function fakeSessions(current = 's-1') {
  const byId = {}
  if (current !== undefined) byId[current] = { retainedBy: { mainView: 1 } }
  const opened = []
  return {
    opened,
    list: { getSnapshot: () => ({ byId, phase: 'ready' }) },
    // 宿主 0.1.6 的会话打开器之一，守卫必须和 openSession 一样包住。
    open: (target) => { opened.push(target) },
  }
}

/** 造一个记录 openSession 的 uiWorkspace 桩。 */
function fakeWorkspace() {
  const opened = []
  return {
    opened,
    openSession: (target) => { opened.push(target) },
  }
}

test('无手势的跨会话跳转被拦下（away-notify 的 pendingFocus 走 openSession，绕过 selectPanel）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })

  workspace.openSession('s-2')
  assert.deepEqual(workspace.opened, [], '没有手势：不切会话')
  const queued = internals.takePanelReveal()
  assert.equal(queued?.sessionId, 's-2', '降级成面板内定位提示')
  assert.equal(queued?.reason, 'blocked-switch')
  guard()
  assert.equal(typeof workspace.openSession, 'function')
})

test('默认关：away-notify 原生跳转（openSession / replaceMain / selectPanel）原样放行', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const sessions = fakeSessions('s-1')
  const originalOpen = workspace.openSession
  const originalSessionOpen = sessions.open
  const originalSelect = layout.selectPanel
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    // 缺省（没有 localStorage 开关）→ 默认放行
    now: () => 1_000,
    storage: { getItem: () => null },
    isRegistered: () => true,
    sessions,
    workspace,
  })

  assert.equal(workspace.openSession, originalOpen, '不包宿主对话打开器')
  assert.equal(sessions.open, originalSessionOpen, '不包 sessions.open')
  assert.equal(layout.selectPanel, originalSelect, '不包 selectPanel')
  assert.equal(doc.count(), 0, '不挂任何手势/可见性监听')

  // 模拟 away-notify「点通知 / 回到前台消费 pendingFocus」的宿主链路。
  workspace.openSession('s-2')
  layout.selectPanel(null)
  assert.deepEqual(workspace.opened, ['s-2'], '普通会话点通知照常跳回该会话')
  assert.deepEqual(layout.calls, [null], '面板按宿主语义让位，不会被我们抢回来')
  assert.equal(internals.takePanelReveal(), undefined, '不排队「定位」提示，不降级')
  guard()
})

test('点通知（页面内有手势）后同一个跳转放行；手势窗口过了就恢复拦截', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  let clock = 5_000
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => clock,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()

  doc.fire('pointerdown')
  workspace.openSession('s-2')
  assert.deepEqual(workspace.opened, ['s-2'], '点击引发的跳转照常')

  // 手势窗口（1.5s）过后，又一个「无人点」的 pendingFocus 回来 → 拦。
  clock += internals.NAV_GESTURE_WINDOW_MS + 500
  workspace.openSession('s-3')
  assert.deepEqual(workspace.opened, ['s-2'], '没有手势就拦')
  guard()
})

test('用户主动点会话（目标就是当前会话 / 启动时没有会话）都放行', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout(null)
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions(undefined),
    workspace,
  })

  workspace.openSession('s-1')
  assert.deepEqual(workspace.opened, ['s-1'], '还没有当前会话（启动/launch URL）→ 放行')
  workspace.openSession('s-1')
  assert.deepEqual(workspace.opened, ['s-1', 's-1'], '目标就是当前会话 → 放行')
  guard()
})

test('守卫还原时把 openSession 换回原函数（不留包装）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const original = workspace.openSession
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  assert.notEqual(workspace.openSession, original, '装上后是包装函数')
  guard()
  assert.equal(workspace.openSession, original, '还原必须换回宿主原函数')
})

test('sessions.open 也被包住：无手势跨会话被拦，还原后换回原函数', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const sessions = fakeSessions('s-1')
  const originalOpen = sessions.open
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions,
    workspace,
  })
  assert.notEqual(sessions.open, originalOpen, 'sessions.open 也是会话打开器，必须包住')
  sessions.open('s-2')
  assert.deepEqual(sessions.opened, [], '无手势的跨会话跳转被拦')
  assert.deepEqual(workspace.opened, [], '不会绕道 openSession')
  guard()
  assert.equal(sessions.open, originalOpen, '还原必须换回宿主原函数')
  sessions.open('s-2')
  assert.deepEqual(sessions.opened, ['s-2'], '还原后放行')
})

test('ctx.inject 回调重复跑也只包一层（还原后不留包装）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const workspace = fakeWorkspace()
  const original = workspace.openSession
  // 模拟宿主服务重启后再次回调：同一份 workspace 会被交给两次。
  const ctx = {
    inject: (deps, callback) => {
      callback({ uiWorkspace: workspace })
      callback({ uiWorkspace: workspace })
    },
  }
  const guard = internals.installNavGuard(ctx, {
    layout,
    document: fakeDocument(),
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
  })
  guard()
  assert.equal(workspace.openSession, original, '叠了两层的话还原只会拆掉最外层，守卫会泄漏')
})

test('我们不在台上（面板条目已消失）时不干预会话切换', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout(null)
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => false,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  workspace.openSession('s-2')
  assert.deepEqual(workspace.opened, ['s-2'])
  guard()
})

test('我们自己的用户意图导航（await 过、手势已过期）可以用显式授权放行', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 1_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()

  workspace.openSession('worker-1')
  assert.deepEqual(workspace.opened, [], '没有授权时照拦')

  internals.authorizeNavigation()
  workspace.openSession('worker-1')
  assert.deepEqual(workspace.opened, ['worker-1'], '显式授权后放行（「在会话中打开」）')
  guard()
})

/**
 * 通知点击的两种入口：
 *   ① 页面内 toast —— 有 pointerdown，走手势窗口；
 *   ② 系统通知   —— 由宿主用 OS 通知弹出，点击是 `dshnotify:` 协议把窗口置前
 *      （dsh-away-notify/lib/protocol.js），页面里**收不到任何指针事件**，唯一信号是
 *      文档从 hidden 回到 visible。
 */
test('切标签/最小化 1–5 秒回来：不跳（hidden→visible 不再当作点击信号）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  let clock = 10_000
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => clock,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()

  for (const away of [1_000, 3_000, 5_000]) {
    doc.hidden = true
    doc.fire('visibilitychange')
    clock += away
    doc.hidden = false
    doc.fire('visibilitychange')
    workspace.openSession('s-2')
    assert.deepEqual(workspace.opened, [], `离开 ${away}ms 回来不跳`)
    assert.equal(internals.takePanelReveal()?.sessionId, 's-2', '降级为面板内定位提示')
  }
  guard()
})

test('Alt-Tab（窗口一直 visible，只有 focus）不跳；离开太久回来也不跳', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  let clock = 20_000
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => clock,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()

  // 同一桌面 Alt-Tab：文档始终 visible，只有 window focus。
  workspace.openSession('s-2')
  assert.deepEqual(workspace.opened, [], 'Alt-Tab 不跳')

  // 离开很久（> 20s）再回来：典型 Alt-Tab 而不是「刚弹通知就点」。
  doc.hidden = true
  doc.fire('visibilitychange')
  clock += 60_000
  doc.hidden = false
  doc.fire('visibilitychange')
  workspace.openSession('s-3')
  assert.deepEqual(workspace.opened, [], '离开太久不跳')
  guard()
})

test('页面内 toast 点击（pointerdown）照常跳', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 30_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()
  doc.fire('pointerdown')
  workspace.openSession('s-2')
  assert.deepEqual(workspace.opened, ['s-2'], '页面内点 toast：跳')
  guard()
})

test('侧栏点会话 / 快捷键（手势）照常跳', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 40_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()
  doc.fire('keydown')
  workspace.openSession('s-2')
  assert.deepEqual(workspace.opened, ['s-2'], '快捷键：跳')
  guard()
})

test('通知以新标签页打开（?dshAwayNotifyFocus=）时也放行一次', () => {
  const bundle = loadClientBundle({}, { location: { search: '?dshAwayNotifyFocus=s-9' } })
  const { __internals: internals } = bundle
  const layout = fakeLayout(null)
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 50_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()
  workspace.openSession('s-9')
  assert.deepEqual(workspace.opened, ['s-9'], 'URL 参数带来的那次跳转放行')
  guard()
})

test('直接 replaceMain(…, "reveal") 的跨会话跳转也被拦（openSession 之外的关闭路径）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const replaced = []
  const workspace = {
    openSession: () => {},
    replaceMain: (target, _signal, panel) => { replaced.push([target, panel]) },
  }
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 60_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()

  workspace.replaceMain('s-2', undefined, 'reveal')
  assert.deepEqual(replaced, [], '无手势：拦')
  workspace.replaceMain('s-1', undefined, 'preserve')
  assert.deepEqual(replaced, [['s-1', 'preserve']], '启动/恢复（preserve）放行')
  guard()
})

test('确有通知信号（?dshAwayNotifyFocus=）时放行，且只放行那一条、只一次', () => {
  const bundle = loadClientBundle({}, { location: { search: '?dshAwayNotifyFocus=s-2' } })
  const { __internals: internals } = bundle
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const replaced = []
  const workspace = { replaceMain: (target, _signal, panel) => { replaced.push([target, panel]) } }
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 70_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()

  // 令牌绑定了 s-2：别的会话不受影响。
  workspace.replaceMain('s-3', undefined, 'reveal')
  assert.deepEqual(replaced, [], '令牌不适用于别的会话')
  workspace.replaceMain('s-2', undefined, 'reveal')
  assert.deepEqual(replaced, [['s-2', 'reveal']], '通知带来的那条：跳')
  workspace.replaceMain('s-2', undefined, 'reveal')
  assert.equal(replaced.length, 1, '同一条只能用一次')
  guard()
})

test('页面内 toast 点击（pointerdown）照常跳', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 30_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()
  doc.fire('pointerdown')
  workspace.openSession('s-2')
  assert.deepEqual(workspace.opened, ['s-2'], '页面内点 toast：跳')
  guard()
})

test('侧栏点会话 / 快捷键（手势）照常跳', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 40_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()
  doc.fire('keydown')
  workspace.openSession('s-2')
  assert.deepEqual(workspace.opened, ['s-2'], '快捷键：跳')
  guard()
})

test('通知以新标签页打开（?dshAwayNotifyFocus=）时也放行一次', () => {
  const bundle = loadClientBundle({}, { location: { search: '?dshAwayNotifyFocus=s-9' } })
  const { __internals: internals } = bundle
  const layout = fakeLayout(null)
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 50_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()
  workspace.openSession('s-9')
  assert.deepEqual(workspace.opened, ['s-9'], 'URL 参数带来的那次跳转放行')
  guard()
})

test('直接 replaceMain(…, "reveal") 的跨会话跳转也被拦（openSession 之外的关闭路径）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const replaced = []
  const workspace = {
    openSession: () => {},
    replaceMain: (target, _signal, panel) => { replaced.push([target, panel]) },
  }
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 60_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()

  workspace.replaceMain('s-2', undefined, 'reveal')
  assert.deepEqual(replaced, [], '无手势：拦')
  workspace.replaceMain('s-1', undefined, 'preserve')
  assert.deepEqual(replaced, [['s-1', 'preserve']], '启动/恢复（preserve）放行')
  guard()
})

test('切标签回来后的 replaceMain("reveal") 同样不跳（无点击信号）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const replaced = []
  const workspace = { replaceMain: (target, _signal, panel) => { replaced.push([target, panel]) } }
  let clock = 70_000
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => clock,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()

  doc.hidden = true
  doc.fire('visibilitychange')
  clock += 2_000
  doc.hidden = false
  doc.fire('visibilitychange')
  workspace.replaceMain('s-2', undefined, 'reveal')
  assert.deepEqual(replaced, [], '没有点击信号：不跳')
  guard()
})

test('守卫被外部换掉后，下一次可见性变化自愈（重新装回包装）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 80_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()
  const wrapped = layout.selectPanel

  // 模拟「我们的包装被别人还原/换掉」。
  layout.selectPanel = function unwrapped() {}
  doc.hidden = false
  doc.fire('visibilitychange')
  assert.equal(layout.selectPanel, wrapped, '自愈：装回原来的包装')
  guard()
})

test('拦下跨会话跳转时把 Super-agent 面板切到前台（定位提示条要能看见）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout(null)
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => 90_000,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()

  workspace.openSession('s-2')
  assert.deepEqual(workspace.opened, [], '不切会话')
  assert.deepEqual(layout.calls, ['super-agent'], '但把我们的面板切出来，让提示条可见')
  assert.equal(internals.takePanelReveal()?.sessionId, 's-2')
  guard()
})

test('最小化/窗口失焦后恢复且有待跳转会话：仍不跳（选方案 2，只留提示条）', () => {
  const { __internals: internals } = loadClientBundle()
  const layout = fakeLayout('super-agent')
  const doc = fakeDocument()
  const workspace = fakeWorkspace()
  let clock = 100_000
  const guard = internals.installNavGuard({}, {
    layout,
    document: doc,
    now: () => clock,
    storage: { getItem: () => 'on' },
    isRegistered: () => true,
    sessions: fakeSessions('s-1'),
    workspace,
  })
  internals.takePanelReveal()

  // 窗口失焦 → 最小化（hidden）→ 5 秒后恢复 → 聚焦，随后 pendingFocus 被消费。
  doc.hidden = true
  doc.fire('visibilitychange')
  clock += 5_000
  doc.hidden = false
  doc.fire('visibilitychange')
  workspace.openSession('s-9')

  assert.deepEqual(workspace.opened, [], '恢复窗口不自动跳（与切标签页同判）')
  assert.equal(internals.takePanelReveal()?.sessionId, 's-9', '降级为面板内定位提示条')
  guard()
})
