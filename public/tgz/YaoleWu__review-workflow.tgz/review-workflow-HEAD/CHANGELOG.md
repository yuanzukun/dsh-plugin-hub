# Changelog

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). This
project has not cut a tagged release yet; everything below has landed on
`main` under `0.1.0`.

## [0.1.0] - Unreleased

### Fixed

- Sanitization notice in `README.md` named the specific institutions it
  claimed to have removed, undermining its own point. Reworded to match the
  generalized wording already used in `README.en.md`.
- Registered skill payload could leak identity, host, or credential shapes
  through `host.js`; a pattern-based guard (`tests/host.test.mjs`) and a
  registry-level round-trip check (`tests/boot.test.mjs`) now cover it.
- Two silent faults in `tools/scan-tree.sh`: a `\b`-based rule that matched
  nothing under POSIX ERE, and an exemption applied after the matched text
  had already been reduced to a line number.
- Package scope: dropped an invented `@dsh-review` scope in favor of
  publishing as plain `review-workflow`.
- Author and install-path references corrected to `LeslieWylie` (no org
  transfer implied).

### Added

- Real executing test suite for `host.js` using Node's built-in `node:test`.
- `tests/boot.test.mjs`: boots a genuine `cordis` `Context`, loads the
  harness's own skill registry, and confirms the skill is reachable through
  it — not just through a stub.
- CI job (`no-identifiers-in-tree`) that runs `tools/scan-tree.sh` on every
  push and proves the scanner still fires on planted samples before trusting
  its verdict on the real tree.

## [0.1.0] - Initial release

- Generic multi-panelist review workflow skill: 6-step process with 6
  checkpoints, independent panelist scoring, anchor-then-Δ disagreement
  resolution, independent critic review, and incremental re-review support.
