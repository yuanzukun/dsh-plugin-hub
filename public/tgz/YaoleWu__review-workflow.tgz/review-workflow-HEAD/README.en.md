# dsh-review-workflow · Generic Multi-Panelist Review Workflow

[简体中文](README.md)

## What is this

A **generic multi-panelist review workflow** skill. Generalized from an internal collaboration-review process, suitable for any structured review scenario — project review, paper review, code review, design review, etc.

## Core Capabilities

| Module | Content |
|--------|---------|
| **6-Step Process + 6 Checkpoints** | Material completeness check → Bundle preparation → N-panelist parallel scoring → Aggregation → Critic review → Final decision |
| **N Independent Panelists** | Panelists run in isolated subagents, blind to each other, preventing bias contamination |
| **Anchor Consistency Check** | Two-phase disagreement resolution: anchor matching → Δ-level adjudication |
| **Independent Critic Review** | Isolated subagent reviews process compliance, challenges reasoning gaps |
| **Re-review Support** | Incremental re-review: only re-evaluate changed dimensions |
| **Configurable** | Review dimensions, scoring criteria, templates, panelist count all configurable |

## Install

```bash
dsh plugin --profile web add "github:LeslieWylie/review-workflow"
```

After restart, load the skill in any session:

```
load review-workflow
```

## Required Configuration

This skill requires project-level configuration (in the project's own skill or config files):

| Config | Description | Example |
|--------|-------------|---------|
| rubric | Review dimensions and scoring criteria | 5 dimensions, 5-point scale with anchor descriptions |
| bundle template | Review material bundle template | bundle.md |
| panelist prompt | Panelist prompt template | panelist-prompt.md |
| aggregation template | Aggregation report template | aggregation.md |
| critic template | Critic report template | critic-report.md |
| checklist | Material completeness checklist | proposal-checklist.md |
| panelist count | Number of panelists | 2 |
| score threshold | Pass/fail threshold per dimension | ≥3/5 |

## Design Principles

- **Scenario-agnostic**: Only defines the review process skeleton. Specific dimensions, criteria, and templates come from the project
- **Role isolation**: Panelists run independently, Critic in isolated session, preventing bias
- **Checkpoint enforcement**: Each step has a checkpoint; cannot proceed without passing
- **Auditable**: All intermediate artifacts saved to disk, fully traceable

## Sanitization Notice

This plugin was generalized from an internal collaboration-review process. All internal project references (specific project names, model names, internal tool paths, etc.) have been removed.

## Changelog

See [CHANGELOG.md](CHANGELOG.md).

## License

MIT