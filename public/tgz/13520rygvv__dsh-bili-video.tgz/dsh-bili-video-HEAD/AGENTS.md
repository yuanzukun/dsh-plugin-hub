# 给 AI 助手看的（本仓库 = 一个 DSH 插件：dsh-bili-video）

**这是两个人上游插件的合并版，不是从零写的。**

- 底座：`dsh-bili-subagent`（中文名「刷B站（子代理版）」，作者 Yuuyuko-uu，MIT；
  它自己又是 `c1overzz/dsh-bili-scroll` 的 fork）。提供 B站 那半：
  搜索 / 字幕 / 评论 / 弹幕 / 三连 / 回复 / 私信 / 登录 / 配置。
- 合进来：`dsh-video-storyboard`（作者 SAOS-3624，MIT）。提供「看画面」那半：
  `video_probe` / `video_storyboard` / `video_zoom` / `video_locate`（原件在 `vendor/storyboard/`）。

## 2026-10-29 主人拍板的两处改动（别再改回去）

1. **砍掉「自己刷视频」**：`bili_scan` 工具已删除、会话页那个「视频」卡片墙已下线。
   她不再自发去刷、也没有「帮我刷一轮」这个入口；要什么就当场说（搜 / 读某条）。
2. **两个插件合成一个**：B站 那批工具 + 看视频那四个工具同在一个包里。

保留没动的：搜索、字幕、评论、发评论 @ 人、三连、回复、私信、扫码登录、设置页。
谷时定时器与「收件箱提醒」机制仍在（默认 `autoMode: 'manual'` ⇒ 不会自动刷）。

## 装/改的时候

- `pythonPath` 指 `C:\Users\gao\.dsh\bili-duty\.venv\Scripts\python.exe`（家里那份，登录态也在家里）。
- 家里（`$DSH_HOME/bili-duty/`）：`config.json` / `mcp_server.py` / `duty.log` / `out/` / 登录凭证。
  **配置与运行数据不写进插件包目录。**
- `vendor/storyboard/src/index.js` 只认裸包名 `@deepseek-ai/dsh-tools`（桌面版 profile 不装这个 optional peer），
  所以 `index.js` 里 import 它之前先把 `DSH_TOOLS_PATH` 指到 `lib/dsh-tools-shim.mjs`。
- 依赖：ffmpeg/ffprobe 必需（本机已在 PATH）；yt-dlp 只在贴链接时用；ASR 需要 key 或本地服务（见 vendor/storyboard/docs）。
- 改完必须**重启 dsh**（bundle 层与 tools 层都要重启才重装）。别一边跑一边改 `node_modules`，
  会触发 HMR 把工具表抖一遍。
- 工具定义（名字/描述/参数）一改就作废 DSH 的前缀缓存，大会话等于重算一遍，很贵；改逻辑/提示词不影响缓存。