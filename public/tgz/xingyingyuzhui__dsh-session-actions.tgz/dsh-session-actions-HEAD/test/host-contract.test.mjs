// Host-contract tests: named exports, inject, route guard, export/delete handlers.
import assert from 'node:assert/strict'
import test from 'node:test'
import { EventEmitter } from 'node:events'
import { access, mkdir, rm, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join } from 'node:path'

const host = await import('../host.js')
const TEST_STATE_DIR = join(homedir(), '.dsh', 'dsh-session-actions-test-state')
host._internal.setStateDir(TEST_STATE_DIR)

function fakeCtx(sessions, extras = {}) {
  const routes = []
  const effects = []
  const ctx = {
    sessions: {
      get: (id) => sessions.get(id),
      list: () => [...sessions.values()],
    },
    get: (key) => {
      if (key === 'sessionPersistence') return extras.persistence
      if (key === 'sessionController') return extras.sessionController
      if (key === 'workspaceRegistry') return extras.workspaceRegistry
      return undefined
    },
    fiber: extras.fiber,
    registry: extras.registry,
    webServer: {
      register: (route) => {
        routes.push(route)
        return () => { const i = routes.indexOf(route); if (i >= 0) routes.splice(i, 1) }
      },
    },
    effect: (fn) => { effects.push(fn()) },
  }
  return { ctx, routes, effects }
}

function req(res, { method = 'POST', headers = {}, body = null } = {}) {
  const emitter = new EventEmitter()
  emitter.method = method
  emitter.headers = headers
  if (body != null) {
    queueMicrotask(() => {
      emitter.emit('data', Buffer.from(JSON.stringify(body)))
      emitter.emit('end')
    })
  } else {
    queueMicrotask(() => emitter.emit('end'))
  }
  return emitter
}

function res() {
  let status = null
  let body = ''
  return {
    writeHead: (code, headers) => { status = code },
    end: (text) => { body = text },
    status: () => status,
    body: () => (body ? JSON.parse(body) : null),
  }
}

const mkSession = (id, title, cwd, events) => ({
  id,
  events: [
    { type: 'session/title', data: { title } },
    ...events,
  ],
  header: { meta: { cwd } },
})

test('host exports name/inject/apply and injects webServer+sessions+sessionController', () => {
  assert.equal(host.name, 'dsh-session-actions')
  assert.deepEqual(host.inject, ['webServer', 'sessions', 'sessionController'])
  assert.equal(typeof host.apply, 'function')
})

test('apply registers the two POST routes and disposes them', () => {
  const { ctx, routes, effects } = fakeCtx(new Map())
  host.apply(ctx)
  assert.deepEqual(routes.map((r) => r.path).sort(), [
    '/dsh-session-actions/catalog',
    '/dsh-session-actions/delete',
    '/dsh-session-actions/export',
    '/dsh-session-actions/pins/get',
    '/dsh-session-actions/pins/set',
  ])
  assert.ok(routes.every((r) => r.kind === 'exact'))
  effects[0]()
  assert.equal(routes.length, 0)
})

test('guard rejects GET, missing csrf header and foreign origin', async () => {
  const sessions = new Map([['session-aaa', mkSession('session-aaa', 'S', '/w', [])]])
  const { ctx, routes } = fakeCtx(sessions)
  host.apply(ctx)
  const route = routes.find((r) => r.path === '/dsh-session-actions/export')

  const r1 = res()
  await route.handler(req(r1, { method: 'GET' }), r1)
  assert.equal(r1.status(), 405)

  const r2 = res()
  await route.handler(req(r2, { body: { sessionId: 'session-aaa' } }), r2)
  assert.equal(r2.status(), 403)

  const r3 = res()
  await route.handler(req(r3, {
    headers: { 'x-dsh-session-actions': '1', origin: 'https://evil.example' },
    body: { sessionId: 'session-aaa' },
  }), r3)
  assert.equal(r3.status(), 403)
})

test('export handler returns structured markdown with filename', async () => {
  const sessions = new Map([
    ['session-abc12345', mkSession('session-abc12345', '会话A', '/Users/qin/DSH', [
      { type: 'turn/start', data: {} },
      { type: 'user/message', data: { message: { content: [{ type: 'text', text: '你好' }] } } },
      { type: 'assistant/message', data: { message: { content: [
        { type: 'reasoning', text: '想一下' },
        { type: 'text', text: '你好！' },
      ] } } },
    ])],
  ])
  const { ctx, routes } = fakeCtx(sessions)
  host.apply(ctx)
  const route = routes.find((r) => r.path === '/dsh-session-actions/export')
  assert.ok(route)
  const r = res()
  await route.handler(req(r, {
    headers: { 'x-dsh-session-actions': '1' },
    body: { sessionId: 'session-abc12345' },
  }), r)
  const data = r.body()
  assert.equal(data.ok, true)
  assert.ok(data.markdown.includes('# 会话A'))
  assert.ok(data.markdown.includes('### 思考'))
  assert.ok(data.markdown.includes('想一下'))
  assert.equal(data.filename, '会话A.md')
})

test('export by title uses exact match only', async () => {
  const sessions = new Map([
    ['session-a1xxxx', mkSession('session-a1xxxx', '你好', '/w1', [])],
    ['session-a2xxxx', mkSession('session-a2xxxx', '你好，这是测试', '/w2', [])],
  ])
  const { ctx, routes } = fakeCtx(sessions)
  host.apply(ctx)
  const route = routes.find((r) => r.path === '/dsh-session-actions/export')
  const r = res()
  await route.handler(req(r, { headers: { 'x-dsh-session-actions': '1' }, body: { title: '你好' } }), r)
  const data = r.body()
  assert.equal(data.ok, true)
  assert.equal(data.sessionId, 'session-a1xxxx')
})

test('export by title matches and returns 409-style ambiguous payload', async () => {
  const sessions = new Map([
    ['session-a1', mkSession('session-a1', '同名', '/w1', [])],
    ['session-a2', mkSession('session-a2', '同名', '/w2', [])],
  ])
  const { ctx, routes } = fakeCtx(sessions)
  host.apply(ctx)
  const route = routes.find((r) => r.path === '/dsh-session-actions/export')
  const r = res()
  await route.handler(req(r, { headers: { 'x-dsh-session-actions': '1' }, body: { title: '同名' } }), r)
  const data = r.body()
  assert.equal(data.ok, false)
  assert.equal(data.ambiguous, true)
  assert.equal(data.candidates.length, 2)
})

test('delete handler rejects a short session id', async () => {
  const sessions = new Map([['session-xyz', mkSession('session-xyz', 'X', '/w', [])]])
  const { ctx, routes } = fakeCtx(sessions)
  host.apply(ctx)
  const route = routes.find((r) => r.path === '/dsh-session-actions/delete')
  const r = res()
  await route.handler(req(r, { headers: { 'x-dsh-session-actions': '1' }, body: { sessionId: 'session-xyz' } }), r)
  const data = r.body()
  assert.equal(data.ok, false)
  assert.ok(data.error)
})

test('delete handler removes a cold session directory', async () => {
  const sessionId = 'session-dsa-testdelete01'
  const dir = join(homedir(), '.dsh', 'sessions', '--dsa-test--', sessionId)
  await mkdir(dir, { recursive: true })
  await writeFile(join(dir, 'marker'), 'x')
  try {
    const persistence = {
      inspect: async () => ({ events: [], header: { id: sessionId, cwd: '/tmp' } }),
    }
    const { ctx, routes } = fakeCtx(new Map(), { persistence })
    host.apply(ctx)
    const route = routes.find((r) => r.path === '/dsh-session-actions/delete')
    const r = res()
    await route.handler(req(r, { headers: { 'x-dsh-session-actions': '1' }, body: { sessionId } }), r)
    const data = r.body()
    assert.equal(data.ok, true)
    assert.equal(data.sessionId, sessionId)
    await assert.rejects(() => access(dir))
  } finally {
    await rm(join(homedir(), '.dsh', 'sessions', '--dsa-test--'), { recursive: true, force: true })
  }
})

test('new Session Controller inspects and deletes a cold session', async () => {
  const sessionId = 'session-dsa-controller01'
  const dir = join(homedir(), '.dsh', 'sessions', '--dsa-controller--', sessionId)
  await mkdir(dir, { recursive: true })
  await writeFile(join(dir, 'marker'), 'x')
  try {
    const sessionController = {
      inspect: async (id) => ({
        meta: { id, cwd: '/tmp/controller' },
        events: [{ type: 'session/title', data: { title: 'Controller cold' } }],
      }),
      list: async () => ({ items: [{ sessionId, cwd: '/tmp/controller' }] }),
    }
    const { ctx, routes } = fakeCtx(new Map(), { sessionController })
    host.apply(ctx)
    const route = routes.find((r) => r.path === '/dsh-session-actions/delete')
    const r = res()
    await route.handler(req(r, {
      headers: { 'x-dsh-session-actions': '1' },
      body: { sessionId },
    }), r)
    const data = r.body()
    assert.equal(data.ok, true)
    assert.equal(data.sessionId, sessionId)
    await assert.rejects(() => access(dir))
  } finally {
    await rm(join(homedir(), '.dsh', 'sessions', '--dsa-controller--'), { recursive: true, force: true })
  }
})

test('new Session Controller includes cold sessions in the catalog', async () => {
  const sessionId = 'session-dsa-controller02'
  const sessionController = {
    inspect: async (id) => ({
      meta: { id, cwd: '/tmp/controller' },
      events: [{ type: 'session/title', data: { title: '历史会话' } }],
    }),
    list: async () => ({ items: [{ sessionId, cwd: '/tmp/controller' }] }),
  }
  const { ctx, routes } = fakeCtx(new Map(), { sessionController })
  host.apply(ctx)
  const route = routes.find((r) => r.path === '/dsh-session-actions/catalog')
  const r = res()
  await route.handler(req(r, { headers: { 'x-dsh-session-actions': '1' }, body: {} }), r)
  const data = r.body()
  assert.equal(data.ok, true)
  assert.deepEqual(data.sessions, [{ id: sessionId, title: '历史会话', cwd: '/tmp/controller' }])
})

test('delete handler unloads a live session via the lifecycle effect', async () => {
  const sessionId = 'session-dsa-testdelete02'
  const sessions = new Map([[sessionId, mkSession(sessionId, 'T', '/tmp', [])]])
  const dispose = () => { sessions.delete(sessionId) }
  Object.defineProperty(dispose, Symbol('effect'), {
    value: { label: `agentLoop.lifecycle(${sessionId})` },
  })
  const { ctx, routes } = fakeCtx(sessions, { fiber: { _disposables: [dispose] } })
  host.apply(ctx)
  const route = routes.find((r) => r.path === '/dsh-session-actions/delete')
  const r = res()
  await route.handler(req(r, { headers: { 'x-dsh-session-actions': '1' }, body: { sessionId } }), r)
  const data = r.body()
  assert.equal(data.ok, true)
  assert.equal(sessions.has(sessionId), false)
})

test('pins get/set persist sanitized session ids', async () => {
  const dir = join(homedir(), '.dsh', 'dsh-session-actions-test-pins')
  await rm(dir, { recursive: true, force: true })
  host._internal.setStateDir(dir)
  try {
    const { ctx, routes } = fakeCtx(new Map())
    host.apply(ctx)
    const get = routes.find((r) => r.path === '/dsh-session-actions/pins/get')
    const set = routes.find((r) => r.path === '/dsh-session-actions/pins/set')
    const empty = res()
    await get.handler(req(empty, { headers: { 'x-dsh-session-actions': '1' }, body: {} }), empty)
    assert.deepEqual(empty.body().sessionIds, [])

    const saved = res()
    await set.handler(req(saved, {
      headers: { 'x-dsh-session-actions': '1' },
      body: { sessionIds: ['session-pin-aaaaaa', 'nope', 'session-pin-aaaaaa', 'session-pin-bbbbbb'] },
    }), saved)
    assert.deepEqual(saved.body().sessionIds, ['session-pin-aaaaaa', 'session-pin-bbbbbb'])

    const again = res()
    await get.handler(req(again, { headers: { 'x-dsh-session-actions': '1' }, body: {} }), again)
    assert.deepEqual(again.body().sessionIds, ['session-pin-aaaaaa', 'session-pin-bbbbbb'])
  } finally {
    host._internal.setStateDir(TEST_STATE_DIR)
    await rm(dir, { recursive: true, force: true })
    await rm(TEST_STATE_DIR, { recursive: true, force: true })
  }
})
