import assert from 'node:assert/strict'
import test from 'node:test'
import {
  isSessionId,
  matchCatalog,
  resolveFromRow,
  sessionIdFromEl,
  sessionIdFromValue,
  titleOfRow,
} from '../session-identity.mjs'

function el(attrs = {}, children = []) {
  return {
    attrs,
    children,
    getAttribute(key) { return this.attrs[key] == null ? null : this.attrs[key] },
    setAttribute(key, value) { this.attrs[key] = String(value) },
    querySelector(sel) {
      if (sel === '[aria-label]') return this.children.find((child) => child.getAttribute('aria-label') != null) || null
      if (sel === '[class*="title"]') return this.children.find((child) => String(child.className || '').includes('title')) || null
      return null
    },
  }
}

test('isSessionId only accepts official session-* ids', () => {
  assert.equal(isSessionId('session-abcdef'), true)
  assert.equal(isSessionId('session-AB12-cd'), true)
  assert.equal(isSessionId('session-ab'), false)
  assert.equal(isSessionId('sess-abcdef'), false)
  assert.equal(isSessionId(''), false)
  assert.equal(isSessionId(null), false)
})

test('sessionIdFromValue reads string or object fields', () => {
  assert.equal(sessionIdFromValue('session-abcdef'), 'session-abcdef')
  assert.equal(sessionIdFromValue({ id: 'session-abcdef' }), 'session-abcdef')
  assert.equal(sessionIdFromValue({ sessionId: 'session-xyzxyz' }), 'session-xyzxyz')
  assert.equal(sessionIdFromValue({ id: 'nope' }), '')
})

test('sessionIdFromEl prefers stamped attribute then fiber walk', () => {
  const stamped = el({ 'data-session-id': 'session-stamped1' })
  assert.equal(sessionIdFromEl(stamped), 'session-stamped1')

  const fibered = el()
  fibered.__reactFiber$abc = {
    key: 'x',
    memoizedProps: { node: { id: 'session-fromnode' } },
    return: null,
  }
  assert.equal(sessionIdFromEl(fibered), 'session-fromnode')
})

test('titleOfRow reads zh/en aria labels then title text', () => {
  const zh = el({}, [el({ 'aria-label': '会话“你好”的操作' })])
  assert.equal(titleOfRow(zh), '你好')
  const en = el({}, [el({ 'aria-label': 'Session actions for Hello there' })])
  assert.equal(titleOfRow(en), 'Hello there')
  const titled = el({}, [{ className: 'row-title', textContent: '  Draft  ', getAttribute() { return null } }])
  assert.equal(titleOfRow(titled), 'Draft')
  assert.equal(titleOfRow(el()), '')
})

test('resolveFromRow uses exact catalog title and reports ambiguity', () => {
  const catalog = [
    { id: 'session-aaaaaa', title: '你好' },
    { id: 'session-bbbbbb', title: '你好' },
    { id: 'session-cccccc', title: '单独' },
  ]
  const unique = el({}, [el({ 'aria-label': '会话“单独”的操作' })])
  assert.deepEqual(resolveFromRow(unique, '', catalog), { sessionId: 'session-cccccc' })
  assert.equal(unique.getAttribute('data-session-id'), 'session-cccccc')

  const dup = el({}, [el({ 'aria-label': '会话“你好”的操作' })])
  const resolved = resolveFromRow(dup, '', catalog)
  assert.equal(resolved.title, '你好')
  assert.equal(resolved.candidates.length, 2)

  const stamped = el({ 'data-session-id': 'session-zzzzzz' })
  assert.deepEqual(resolveFromRow(stamped, '', catalog), { sessionId: 'session-zzzzzz' })
})

test('matchCatalog is exact title only', () => {
  const catalog = [{ id: 'session-aaaaaa', title: '你好世界' }]
  assert.deepEqual(matchCatalog(catalog, '你好'), [])
  assert.equal(matchCatalog(catalog, '你好世界').length, 1)
  assert.deepEqual(matchCatalog(catalog, ''), [])
})
