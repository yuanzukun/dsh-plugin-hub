import assert from 'node:assert/strict'
import test from 'node:test'
import { formatPinTime, reorderPinIds } from '../session-pin.mjs'
import { translate } from '../session-i18n.mjs'

const tZh = (key, params) => translate('zh', key, params)
const tEn = (key, params) => translate('en', key, params)
const NOW = Date.UTC(2026, 7, 17, 12, 0, 0)

test('formatPinTime uses relative buckets', () => {
  assert.equal(formatPinTime(null, tZh, NOW), '')
  assert.equal(formatPinTime(NOW - 10_000, tZh, NOW), '刚刚')
  assert.equal(formatPinTime(NOW - 10_000, tEn, NOW), 'now')
  assert.equal(formatPinTime(NOW - 3 * 60_000, tZh, NOW), '3分钟')
  assert.equal(formatPinTime(NOW - 5 * 3_600_000, tEn, NOW), '5h')
  assert.equal(formatPinTime(NOW - 3 * 86_400_000, tZh, NOW), '3天')
  assert.equal(formatPinTime(NOW - 60 * 86_400_000, tEn, NOW), '2mo')
  assert.equal(formatPinTime(NOW - 400 * 86_400_000, tZh, NOW), '1年')
})

test('reorderPinIds inserts before/after and no-ops same slot', () => {
  const ids = ['session-a', 'session-b', 'session-c']
  assert.deepEqual(reorderPinIds(ids, 'session-c', 'session-a', 'before'), ['session-c', 'session-a', 'session-b'])
  assert.deepEqual(reorderPinIds(ids, 'session-a', 'session-c', 'after'), ['session-b', 'session-c', 'session-a'])
  assert.equal(reorderPinIds(ids, 'session-a', 'session-b', 'before'), null)
  assert.equal(reorderPinIds(ids, 'missing', 'session-a', 'before'), null)
  assert.deepEqual(ids, ['session-a', 'session-b', 'session-c'])
})
