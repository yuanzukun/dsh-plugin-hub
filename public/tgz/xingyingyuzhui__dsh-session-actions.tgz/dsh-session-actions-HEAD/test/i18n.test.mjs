import assert from 'node:assert/strict'
import test from 'node:test'
import { interpolate, isZh, tWith, translate } from '../session-i18n.mjs'

test('translate interpolates both locales', () => {
  assert.equal(translate('zh', 'pinnedSection'), '置顶')
  assert.equal(translate('en', 'pinnedSection'), 'Pinned')
  assert.equal(translate('zh', 'pinMore', { name: '你好' }), '会话“你好”的操作')
  assert.equal(translate('en', 'pinMore', { name: 'hello' }), 'Session actions for hello')
  assert.equal(translate('zh', 'timeMinutes', { n: 3 }), '3分钟')
  assert.equal(translate('en', 'timeMinutes', { n: 3 }), '3min')
})

test('interpolate leaves unknown tokens and skips null params', () => {
  assert.equal(interpolate('hello {name}', null), 'hello {name}')
  assert.equal(interpolate('hello {name}', {}), 'hello {name}')
  assert.equal(interpolate('hello {name}', { name: 'Ada' }), 'hello Ada')
})

test('isZh follows locale.active and defaults to Chinese', () => {
  assert.equal(isZh({}), true)
  assert.equal(isZh({ locale: { getLocale: () => ({ active: 'en-US' }) } }), false)
  assert.equal(isZh({ locale: { getSnapshot: () => ({ active: 'zh-CN' }) } }), true)
})

test('tWith prefers official locale.bind then falls back', () => {
  const bound = tWith({
    locale: {
      getLocale: () => ({ active: 'en' }),
      bind: (ns) => {
        assert.equal(ns, 'dsh-session-actions')
        return (key) => key === 'exportMd' ? 'Export Markdown' : key
      },
    },
  }, 'exportMd')
  assert.equal(bound, 'Export Markdown')
  assert.equal(tWith({ locale: { getLocale: () => ({ active: 'en' }) } }, 'exportMd'), 'Export Markdown')
  assert.equal(tWith({}, 'exportMd'), '导出 Markdown')
})
