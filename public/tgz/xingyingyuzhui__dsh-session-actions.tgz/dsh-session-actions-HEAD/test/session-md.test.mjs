// Pure-logic tests: session events → structured Markdown.
import assert from 'node:assert/strict'
import test from 'node:test'
import { eventsToMarkdown, sessionTitle } from '../session-md.mjs'

test('sessionTitle prefers the last session/title event', () => {
  const events = [
    { type: 'session/title', data: { title: '旧标题' } },
    { type: 'session/title', data: { title: '新标题' } },
  ]
  assert.equal(sessionTitle(events), '新标题')
  assert.equal(sessionTitle([], '回退名'), '回退名')
})

test('eventsToMarkdown renders turns, user, think, tool calls and results', () => {
  const events = [
    { type: 'turn/start', data: {} },
    { type: 'user/message', data: { message: { content: [{ type: 'text', text: '帮我改一下配置' }] } } },
    { type: 'assistant/message', data: { message: { content: [
      { type: 'reasoning', text: '先看配置在哪' },
      { type: 'tool-call', name: 'read', id: 'c1', arguments: '{"file":"a.json"}' },
    ] } } },
    { type: 'tool/result', data: { result: { content: [{ type: 'text', text: '{"a":1}' }] } } },
    { type: 'assistant/message', data: { message: { content: [{ type: 'text', text: '改好了' }] } } },
    { type: 'turn/end', data: {} },
  ]
  const md = eventsToMarkdown(events, { title: '会话A', cwd: '/Users/qin/DSH', sessionId: 'session-abc' })
  assert.ok(md.includes('# 会话A'))
  assert.ok(md.includes('> 工作区: /Users/qin/DSH'))
  assert.ok(md.includes('## 回合 1'))
  assert.ok(md.includes('### 用户'))
  assert.ok(md.includes('帮我改一下配置'))
  assert.ok(md.includes('### 思考'))
  assert.ok(md.includes('先看配置在哪'))
  assert.ok(md.includes('### 工具调用 · read'))
  assert.ok(md.includes('"file": "a.json"'))
  assert.ok(md.includes('**工具结果**'))
  assert.ok(md.includes('{"a":1}'))
  assert.ok(md.includes('### 助手'))
  assert.ok(md.includes('改好了'))
})

test('eventsToMarkdown marks error results and tolerates unknown blocks', () => {
  const events = [
    { type: 'assistant/message', data: { message: { content: [
      { type: 'tool-call', name: 'bash', id: 'c2', arguments: 'exit 1' },
    ] } } },
    { type: 'tool/result', data: { result: { content: [{ type: 'text', text: 'boom' }], isError: true } } },
    { type: 'assistant/message', data: { message: { content: [{ type: 'future-block', x: 1 }] } } },
  ]
  const md = eventsToMarkdown(events)
  assert.ok(md.includes('工具结果（错误）'))
  assert.ok(md.includes('boom'))
  assert.ok(md.includes('future-block'))
})

test('eventsToMarkdown skips plugin-injected user messages', () => {
  const events = [
    { type: 'user/message', data: { message: { content: [{ type: 'text', text: 'Cordis update' }], source: { kind: 'plugin', plugin: 'cordis' } } } },
    { type: 'user/message', data: { message: { content: [{ type: 'text', text: '真人提问' }], source: { kind: 'user' } } } },
  ]
  const md = eventsToMarkdown(events)
  assert.ok(!md.includes('Cordis update'))
  assert.ok(md.includes('真人提问'))
})

test('eventsToMarkdown follows English headings', () => {
  const md = eventsToMarkdown([
    { type: 'turn/start', data: {} },
    { type: 'user/message', data: { message: { content: [{ type: 'text', text: 'Hi' }], source: { kind: 'user' } } } },
  ], { lang: 'en', title: 'S' })
  assert.ok(md.includes('## Turn 1'))
  assert.ok(md.includes('### User'))
})

test('eventsToMarkdown skips empty user messages', () => {
  const events = [
    { type: 'user/message', data: { message: { content: [] } } },
    { type: 'assistant/message', data: { message: { content: [{ type: 'text', text: 'hi' }] } } },
  ]
  const md = eventsToMarkdown(events)
  assert.ok(!md.includes('### 👤 用户'))
  assert.ok(md.includes('hi'))
})
