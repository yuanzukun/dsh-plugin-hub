export const SESSION_ID_RE = /^session-[A-Za-z0-9-]{6,}$/

export function isSessionId(value) {
  return typeof value === 'string' && SESSION_ID_RE.test(value)
}

export function reactFiber(el) {
  if (el == null) return null
  for (const key in el) {
    if (key.indexOf('__reactFiber$') === 0 || key.indexOf('__reactInternalInstance$') === 0) return el[key]
  }
  return null
}

export function sessionIdFromValue(value) {
  if (isSessionId(value)) return value
  if (value != null && typeof value === 'object') {
    if (isSessionId(value.id)) return value.id
    if (isSessionId(value.sessionId)) return value.sessionId
  }
  return ''
}

// Official session rows do not put the id on the DOM. The ⋯ menu is
// portaled, but its React fiber still walks back to SessionNodeItem.
export function sessionIdFromEl(el) {
  if (el == null) return ''
  const stamped = typeof el.getAttribute === 'function' ? el.getAttribute('data-session-id') : ''
  if (isSessionId(stamped)) return stamped
  let fiber = reactFiber(el)
  let hops = 0
  while (fiber != null && hops < 80) {
    const fromKey = sessionIdFromValue(fiber.key)
    if (fromKey) return fromKey
    const props = fiber.memoizedProps || fiber.pendingProps
    if (props != null) {
      const fromNode = sessionIdFromValue(props.node)
      if (fromNode) return fromNode
      const fromSid = sessionIdFromValue(props.sessionId)
      if (fromSid) return fromSid
    }
    fiber = fiber.return
    hops += 1
  }
  return ''
}

export function tagRow(row) {
  if (row == null) return ''
  const id = sessionIdFromEl(row)
  if (id) row.setAttribute('data-session-id', id)
  return id
}

export function titleOfRow(row) {
  if (row == null) return ''
  const button = row.querySelector('[aria-label]')
  if (button != null) {
    const label = button.getAttribute('aria-label') || ''
    const zh = label.match(/会话[“"](.+)[”"]的操作/)
    if (zh) return zh[1].trim()
    const en = label.match(/Session actions for (.+)$/)
    if (en) return en[1].trim()
  }
  const titleEl = row.querySelector('[class*="title"]')
  if (titleEl != null) {
    const text = (titleEl.textContent || '').trim()
    if (text !== '') return text
  }
  return ''
}

export function matchCatalog(catalog, title) {
  if (!title) return []
  return catalog.filter((row) => row.title === title)
}

export function resolveFromRow(row, lastSessionId, catalog) {
  const id = tagRow(row) || lastSessionId
  if (isSessionId(id)) return { sessionId: id }
  const title = titleOfRow(row)
  const hits = matchCatalog(catalog, title)
  if (hits.length === 1) {
    if (row) row.setAttribute('data-session-id', hits[0].id)
    return { sessionId: hits[0].id }
  }
  if (hits.length > 1) return { title, candidates: hits }
  if (title !== '') return { title }
  return null
}
