export const LOCALE_NS = 'dsh-session-actions'

export const COPY = {
  zh: {
    exportMd: '导出 Markdown',
    deleteSession: '删除会话',
    deleteTitle: '删除会话',
    deleteBody: '将永久删除该会话记录，无法恢复。',
    cancel: '取消',
    confirmDelete: '永久删除',
    pickTitle: '选择会话',
    fail: '操作失败',
    ok: '好',
    noSession: '无法识别会话',
    copyId: '复制会话 ID',
    copiedId: '已复制会话 ID',
    copyFail: '复制失败',
    pinSession: '置顶会话',
    unpinSession: '取消置顶',
    pinnedSection: '置顶',
    pinMore: '会话“{name}”的操作',
    timeNow: '刚刚',
    timeMinutes: '{n}分钟',
    timeHours: '{n}小时',
    timeDays: '{n}天',
    timeMonths: '{n}个月',
    timeYears: '{n}年',
    rename: '重命名',
    renameTitle: '重命名会话',
    renameConfirm: '保存',
    forkSession: '分叉会话',
    archiveSession: '归档会话',
  },
  en: {
    exportMd: 'Export Markdown',
    deleteSession: 'Delete session',
    deleteTitle: 'Delete session',
    deleteBody: 'This permanently deletes the session log. This cannot be undone.',
    cancel: 'Cancel',
    confirmDelete: 'Delete permanently',
    pickTitle: 'Choose a session',
    fail: 'Action failed',
    ok: 'OK',
    noSession: 'Could not identify the session',
    copyId: 'Copy session ID',
    copiedId: 'Session ID copied',
    copyFail: 'Could not copy',
    pinSession: 'Pin session',
    unpinSession: 'Unpin session',
    pinnedSection: 'Pinned',
    pinMore: 'Session actions for {name}',
    timeNow: 'now',
    timeMinutes: '{n}min',
    timeHours: '{n}h',
    timeDays: '{n}d',
    timeMonths: '{n}mo',
    timeYears: '{n}y',
    rename: 'Rename',
    renameTitle: 'Rename session',
    renameConfirm: 'Save',
    forkSession: 'Fork session',
    archiveSession: 'Archive session',
  },
}

export function activeLocaleId(ctx) {
  try {
    const snap = ctx.locale && (ctx.locale.getLocale ? ctx.locale.getLocale() : ctx.locale.getSnapshot())
    if (snap && typeof snap.active === 'string' && snap.active) return snap.active
  } catch { /* inject miss or missing locale */ }
  return 'zh'
}

export function isZh(ctx) {
  return String(activeLocaleId(ctx)).toLowerCase().indexOf('zh') === 0
}

export function interpolate(template, params) {
  if (params == null) return template
  return String(template).replace(/\{(\w+)\}/g, (match, name) => (
    Object.prototype.hasOwnProperty.call(params, name) ? String(params[name]) : match
  ))
}

export function translate(lang, key, params) {
  const table = COPY[lang] || COPY.en
  return interpolate(table[key] || COPY.en[key] || key, params)
}

export function tWith(ctx, key) {
  try {
    if (ctx.locale && typeof ctx.locale.bind === 'function') {
      const translated = ctx.locale.bind(LOCALE_NS)(key)
      if (translated && translated !== key) return translated
    }
  } catch { /* fall through */ }
  return translate(isZh(ctx) ? 'zh' : 'en', key)
}
