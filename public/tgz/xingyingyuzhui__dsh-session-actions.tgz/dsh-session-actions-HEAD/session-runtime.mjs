import { COPY, interpolate, isZh, tWith } from './session-i18n.mjs'
import {
  ATTR,
  CSS,
  ICON_COPY,
  ICON_EXPORT,
  ICON_PIN,
  ICON_TRASH,
  ITEM_ATTR,
  PIN_ATTR,
} from './session-styles.mjs'
import {
  isSessionId,
  resolveFromRow,
  sessionIdFromEl,
  tagRow,
} from './session-identity.mjs'
import { createPinUi } from './session-pin.mjs'

export function apply(ctx) {
  const doc = document
  let styleTag = null
  if (doc.head) {
    styleTag = doc.createElement('style')
    styleTag.setAttribute(ATTR, '')
    styleTag.textContent = CSS
    doc.head.appendChild(styleTag)
  }
  doc.body.setAttribute(ATTR, '')

  let lastRow = null
  let lastSessionId = ''
  let catalog = []
  let pinnedIds = []
  let localeDispose = function () {}
  let unsubLocale = function () {}
  let unsubSessions = function () {}

  try {
    if (ctx.locale && typeof ctx.locale.register === 'function') {
      localeDispose = ctx.locale.register('dsh-session-actions', COPY) || function () {}
    }
  } catch { /* namespace already registered on remount */ }

  function t(key, params) {
    return interpolate(tWith(ctx, key), params)
  }

  function lang() {
    return isZh(ctx) ? 'zh' : 'en'
  }

  const api = {}
  const pin = createPinUi(doc, api)

  function post(path, payload) {
    return fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-DSH-Session-Actions': '1' },
      body: JSON.stringify(payload),
    }).then((res) => {
      return res.json().catch(() => { return { ok: false, error: 'bad response' } })
    })
  }

  function refreshCatalog() {
    return post('/dsh-session-actions/catalog', {}).then((data) => {
      catalog = data && data.ok === true && Array.isArray(data.sessions) ? data.sessions : []
      return catalog
    }).catch(() => {
      catalog = []
      return catalog
    })
  }

  function payloadForAction() {
    let id = lastSessionId
    if (lastRow != null) id = tagRow(lastRow) || id
    if (isSessionId(id)) return { sessionId: id }
    return resolveFromRow(lastRow, lastSessionId, catalog)
  }

  function closeMenus() {
    pin.closeMenu()
    doc.body.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true, cancelable: true }))
    doc.body.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }))
  }

  function dialog(title, bodyText, actions) {
    const overlay = doc.createElement('div')
    overlay.className = 'dsa-overlay'
    const box = doc.createElement('div')
    box.className = 'dsa-dialog'
    const head = doc.createElement('div')
    head.className = 'dsa-dialog-head'
    head.textContent = title
    const body = doc.createElement('div')
    body.className = 'dsa-dialog-body'
    if (typeof bodyText === 'string') body.textContent = bodyText
    else body.appendChild(bodyText)
    const foot = doc.createElement('div')
    foot.className = 'dsa-dialog-actions'
    actions.forEach((action) => {
      const btn = doc.createElement('button')
      btn.type = 'button'
      btn.className = 'dsa-btn ' + (action.tone || '')
      btn.textContent = action.label
      btn.addEventListener('click', () => {
        overlay.remove()
        if (action.onClick) action.onClick()
      })
      foot.appendChild(btn)
    })
    box.appendChild(head)
    box.appendChild(body)
    box.appendChild(foot)
    overlay.appendChild(box)
    overlay.addEventListener('click', (event) => {
      if (event.target === overlay) overlay.remove()
    })
    doc.body.appendChild(overlay)
    return overlay
  }

  function alertError(message) {
    let text = String(message || '')
    if (text.indexOf('still live') !== -1) text = isZh(ctx) ? '会话还在运行，没能从内存里卸下。' : text
    else if (text.indexOf('files not found') !== -1) text = isZh(ctx) ? '找不到会话文件。' : text
    dialog(t('fail'), text, [{ label: t('ok'), tone: 'dsa-primary' }])
  }

  function downloadMarkdown(data) {
    const blob = new Blob([data.markdown], { type: 'text/markdown;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = doc.createElement('a')
    a.href = url
    a.download = data.filename || 'session.md'
    doc.body.appendChild(a)
    a.click()
    a.remove()
    setTimeout(() => { URL.revokeObjectURL(url) }, 3000)
  }

  function runExport(payload) {
    payload.lang = lang()
    return post('/dsh-session-actions/export', payload).then((data) => {
      if (data.ok !== true) {
        if (data.ambiguous === true) return pickCandidate(data.candidates, 'export')
        alertError(data.error)
        return
      }
      downloadMarkdown(data)
    }).catch((error) => { alertError(error) })
  }

  function clientSessions() {
    try {
      return ctx.sessions || null
    } catch {
      return null
    }
  }

  function clientWorkspaces() {
    try {
      return ctx.workspaces || null
    } catch {
      return null
    }
  }

  function toast(message) {
    const existing = doc.querySelector('.dsa-toast')
    if (existing != null) existing.remove()
    const el = doc.createElement('div')
    el.className = 'dsa-toast'
    el.setAttribute(ITEM_ATTR, '')
    el.textContent = message
    doc.body.appendChild(el)
    setTimeout(() => { if (el.parentNode) el.remove() }, 1800)
  }

  function copyText(text) {
    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      return navigator.clipboard.writeText(text)
    }
    return new Promise((resolve, reject) => {
      const ta = doc.createElement('textarea')
      ta.value = text
      ta.setAttribute('readonly', '')
      ta.style.cssText = 'position:fixed;left:-9999px;top:0'
      doc.body.appendChild(ta)
      ta.select()
      try {
        if (doc.execCommand('copy')) resolve()
        else reject(new Error('copy failed'))
      } catch (error) {
        reject(error)
      }
      ta.remove()
    })
  }

  function afterDelete(sessionId) {
    const sessions = clientSessions()
    if (sessions != null && sessions.list != null && typeof sessions.list.getSnapshot === 'function') {
      const snap = sessions.list.getSnapshot()
      if (snap != null && snap.current === sessionId && typeof sessions.clear === 'function') {
        sessions.clear()
      }
    }
    if (sessions != null && typeof sessions.refresh === 'function') {
      Promise.resolve(sessions.refresh()).catch(() => { /* list stream may already have dropped it */ })
    }
    const rows = doc.querySelectorAll('[role="treeitem"][data-session-id="' + sessionId + '"]')
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i]
      row.setAttribute('hidden', '')
      row.style.display = 'none'
    }
    if (lastSessionId === sessionId) lastSessionId = ''
    if (lastRow != null && lastRow.getAttribute('data-session-id') === sessionId) lastRow = null
    pin.remove(sessionId)
  }

  function runDelete(payload) {
    return post('/dsh-session-actions/delete', payload).then((data) => {
      if (data.ok !== true) {
        if (data.ambiguous === true) return pickCandidate(data.candidates, 'delete')
        alertError(data.error)
        return
      }
      try {
        afterDelete(data.sessionId || payload.sessionId)
      } catch {
        // Delete already committed; UI sync must not look like a failed delete.
      }
    }).catch((error) => { alertError(error) })
  }

  function withPayload(action, payload) {
    if (payload == null) {
      alertError(t('noSession'))
      return
    }
    if (payload.candidates) {
      pickCandidate(payload.candidates, action)
      return
    }
    if (payload.sessionId) lastSessionId = payload.sessionId
    if (action === 'export') runExport(payload)
    else if (action === 'copy') runCopy(payload)
    else if (action === 'pin') runPin(payload)
    else runDelete(payload)
  }

  function persistPins(next) {
    return pin.persist(next)
  }

  function runPin(payload) {
    const id = payload && payload.sessionId
    if (!isSessionId(id)) {
      alertError(t('noSession'))
      return
    }
    if (pin.isPinned(id)) persistPins(pinnedIds.filter((item) => item !== id))
    else persistPins(pinnedIds.concat([id]))
  }

  function handlePin() {
    const payload = payloadForAction()
    closeMenus()
    if (payload != null && payload.sessionId) {
      runPin(payload)
      return
    }
    refreshCatalog().then(() => { withPayload('pin', payloadForAction()) })
  }

  function relabelMenuItems() {
    const items = doc.querySelectorAll('[' + ITEM_ATTR + '][data-dsa-action]')
    for (let i = 0; i < items.length; i++) {
      const item = items[i]
      const action = item.getAttribute('data-dsa-action')
      const sid = item.getAttribute('data-session-id')
      const key = action === 'copy' ? 'copyId'
        : action === 'export' ? 'exportMd'
          : action === 'delete' ? 'deleteSession'
            : action === 'pin' ? (pin.isPinned(sid) ? 'unpinSession' : 'pinSession')
              : action === 'rename' ? 'rename'
                : action === 'fork' ? 'forkSession'
                  : action === 'archive' ? 'archiveSession'
                    : ''
      if (!key) continue
      const labelEl = item.querySelector('.dsa-menu-label')
      if (labelEl != null) labelEl.textContent = t(key)
    }
    const heading = doc.querySelector('[' + PIN_ATTR + '] .dsa-pin-heading-label')
    if (heading != null) heading.textContent = t('pinnedSection')
  }

  function runCopy(payload) {
    const id = payload && payload.sessionId
    if (!isSessionId(id)) {
      alertError(t('noSession'))
      return
    }
    copyText(id).then(() => {
      toast(t('copiedId'))
    }).catch(() => {
      alertError(t('copyFail'))
    })
  }

  function handleCopy() {
    const payload = payloadForAction()
    closeMenus()
    if (payload != null && payload.sessionId) {
      runCopy(payload)
      return
    }
    refreshCatalog().then(() => { withPayload('copy', payloadForAction()) })
  }

  function handleExport() {
    const payload = payloadForAction()
    closeMenus()
    if (payload != null && payload.sessionId) {
      runExport(payload)
      return
    }
    refreshCatalog().then(() => { withPayload('export', payloadForAction()) })
  }

  function handleDelete() {
    const payload = payloadForAction()
    closeMenus()
    dialog(t('deleteTitle'), t('deleteBody'), [
      { label: t('cancel'), tone: '' },
      {
        label: t('confirmDelete'), tone: 'dsa-danger',
        onClick: function () {
          if (payload != null && payload.sessionId) {
            runDelete(payload)
            return
          }
          refreshCatalog().then(() => { withPayload('delete', payloadForAction()) })
        },
      },
    ])
  }

  function pickCandidate(candidates, action) {
    const list = doc.createElement('div')
    ;(candidates || []).forEach((candidate) => {
      const row = doc.createElement('div')
      row.className = 'dsa-candidate'
      let line = candidate.title || candidate.id
      if (candidate.cwd) line += ' · ' + candidate.cwd
      row.textContent = line
      row.addEventListener('click', () => {
        const payload = { sessionId: candidate.id }
        if (action === 'export') runExport(payload)
        else runDelete(payload)
      })
      list.appendChild(row)
    })
    dialog(t('pickTitle'), list, [{ label: t('cancel'), tone: '' }])
  }

  function isSessionMenu(menu) {
    const text = menu.textContent || ''
    return /归档会话|Archive session|分叉会话|Fork session/.test(text)
  }

  function makeItem(label, danger, iconSvg, onClick, templateItem, sessionId, actionName) {
    const item = doc.createElement('button')
    item.type = 'button'
    item.setAttribute('role', 'menuitem')
    item.setAttribute(ITEM_ATTR, '')
    if (actionName) item.setAttribute('data-dsa-action', actionName)
    if (isSessionId(sessionId)) item.setAttribute('data-session-id', sessionId)
    item.className = 'dsa-menu-item' + (danger ? ' dsa-danger' : '')
    if (templateItem != null && templateItem.className) item.className += ' ' + templateItem.className
    const icon = doc.createElement('span')
    icon.className = 'dsa-menu-icon'
    if (templateItem != null) {
      const officialIcon = templateItem.querySelector('[class*="itemIcon"], [class*="icon"]')
      if (officialIcon != null && officialIcon.className) icon.className += ' ' + officialIcon.className
    }
    icon.innerHTML = iconSvg
    const labelEl = doc.createElement('span')
    labelEl.className = 'dsa-menu-label'
    if (templateItem != null) {
      const officialLabel = templateItem.querySelector('[class*="itemLabel"], [class*="label"]')
      if (officialLabel != null && officialLabel.className) labelEl.className += ' ' + officialLabel.className
    }
    labelEl.textContent = label
    item.appendChild(icon)
    item.appendChild(labelEl)
    item.addEventListener('click', (event) => {
      event.preventDefault()
      event.stopPropagation()
      const bound = item.getAttribute('data-session-id')
      if (isSessionId(bound)) lastSessionId = bound
      onClick()
    })
    return item
  }

  function ensureItems(menu) {
    if (menu.closest && menu.closest('[data-dar-menu]')) return
    if (menu.getAttribute('data-dar-menu') === '1') return
    if (!isSessionMenu(menu)) return
    if (menu.querySelector('[' + ITEM_ATTR + ']') != null) return
    const sessionId = sessionIdFromEl(menu) || tagRow(lastRow) || lastSessionId
    if (isSessionId(sessionId)) lastSessionId = sessionId
    const template = menu.querySelector('[role="menuitem"]')
    const sep = doc.createElement('div')
    sep.className = 'dsa-menu-sep'
    sep.setAttribute(ITEM_ATTR, '')
    sep.setAttribute('role', 'separator')
    if (template != null && template.parentNode != null && template.parentNode.parentNode === menu.querySelector('[role="presentation"]')) {
      const officialSep = menu.querySelector('[role="separator"]')
      if (officialSep != null && officialSep.className) sep.className = officialSep.className
    }
    const copyItem = makeItem(t('copyId'), false, ICON_COPY, handleCopy, template, sessionId, 'copy')
    const pinItem = makeItem(
      t(pin.isPinned(sessionId) ? 'unpinSession' : 'pinSession'),
      false, ICON_PIN, handlePin, template, sessionId, 'pin',
    )
    const exportItem = makeItem(t('exportMd'), false, ICON_EXPORT, handleExport, template, sessionId, 'export')
    const deleteItem = makeItem(t('deleteSession'), true, ICON_TRASH, handleDelete, template, sessionId, 'delete')
    const container = menu.querySelector('[role="presentation"]') || menu
    container.appendChild(sep)
    container.appendChild(copyItem)
    container.appendChild(pinItem)
    container.appendChild(exportItem)
    container.appendChild(deleteItem)
  }

  function scanMenus() {
    const rows = doc.querySelectorAll('[role="treeitem"]')
    for (let r = 0; r < rows.length; r++) {
      if (rows[r].querySelector('[aria-label]') != null) tagRow(rows[r])
    }
    const menus = doc.querySelectorAll('[role="menu"]')
    for (let i = 0; i < menus.length; i++) {
      const menu = menus[i]
      if (menu.offsetParent === null && menu.getBoundingClientRect().width === 0) continue
      ensureItems(menu)
    }
    if (!pin.isHovering()) pin.render()
  }

  let scheduled = false
  function requestScan(mutations) {
    if (mutations && mutations.length) {
      let outside = false
      for (let m = 0; m < mutations.length; m++) {
        const node = mutations[m].target
        if (!node || !node.closest || node.closest('[' + PIN_ATTR + ']') == null) {
          outside = true
          break
        }
      }
      if (!outside) return
    }
    if (scheduled) return
    scheduled = true
    const run = function () { scheduled = false; scanMenus() }
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(run)
    else run()
  }

  const capture = function (event) {
    const target = event.target
    if (pin.containsMenu(target)) pin.closeMenu()
    const row = target && typeof target.closest === 'function'
      ? target.closest('[role="treeitem"]')
      : null
    if (row != null && row.querySelector('[aria-label]') != null) {
      lastRow = row
      lastSessionId = tagRow(row) || lastSessionId
    }
  }
  doc.addEventListener('pointerdown', capture, true)
  doc.addEventListener('click', capture, true)

  api.t = t
  api.post = post
  api.getPinnedIds = function () { return pinnedIds }
  api.setPinnedIds = function (next) { pinnedIds = next }
  api.getCatalog = function () { return catalog }
  api.clientSessions = clientSessions
  api.clientWorkspaces = clientWorkspaces
  api.relabelMenuItems = relabelMenuItems
  api.setLast = function (id, official) {
    lastSessionId = id
    if (official != null) lastRow = official
  }
  api.makeItem = makeItem
  api.handleCopy = handleCopy
  api.handlePin = handlePin
  api.handleExport = handleExport
  api.handleDelete = handleDelete
  api.closeMenus = closeMenus
  api.dialog = dialog
  api.alertError = alertError

  ctx.effect(function () {
    const observer = new MutationObserver((mutations) => { requestScan(mutations) })
    observer.observe(doc.body, { childList: true, subtree: true })
    const timer = ctx.get('timer')
    const stopTimer = timer == null ? null : timer.interval(() => { scanMenus() }, 2000)
    refreshCatalog()
    post('/dsh-session-actions/pins/get', {}).then((data) => {
      if (data && data.ok === true && Array.isArray(data.sessionIds)) pinnedIds = data.sessionIds
      pin.render()
    }).catch(() => { /* start empty */ })
    try {
      if (ctx.locale && typeof ctx.locale.subscribe === 'function') {
        unsubLocale = ctx.locale.subscribe(() => {
          relabelMenuItems()
          pin.render()
        }) || function () {}
      }
    } catch { /* locale optional at subscribe time */ }
    try {
      const sessions = clientSessions()
      if (sessions != null && sessions.list != null && typeof sessions.list.subscribe === 'function') {
        unsubSessions = sessions.list.subscribe(() => { pin.render() }) || function () {}
      }
    } catch { /* sessions list optional */ }
    requestScan()
    const onResize = function () { pin.syncMetrics() }
    window.addEventListener('resize', onResize)
    return function () {
      observer.disconnect()
      if (stopTimer != null) stopTimer()
      unsubLocale()
      unsubSessions()
      localeDispose()
      pin.closeMenu()
      window.removeEventListener('resize', onResize)
      doc.removeEventListener('pointerdown', capture, true)
      doc.removeEventListener('click', capture, true)
      const overlays = doc.querySelectorAll('.dsa-overlay')
      for (let i = 0; i < overlays.length; i++) overlays[i].remove()
      const items = doc.querySelectorAll('[' + ITEM_ATTR + ']')
      for (let j = 0; j < items.length; j++) items[j].remove()
      const pins = doc.querySelectorAll('[' + PIN_ATTR + ']')
      for (let p = 0; p < pins.length; p++) pins[p].remove()
      if (styleTag != null) styleTag.remove()
      doc.body.removeAttribute(ATTR)
    }
  })
}
