export const ATTR = 'data-dsh-session-actions'
export const ITEM_ATTR = 'data-dsa-item'
export const PIN_ATTR = 'data-dsa-pin-section'

export const CSS = [
  'body[' + ATTR + '] .dsa-menu-sep{height:1px;margin:4px 8px;background:var(--dsw-alias-border-l2,rgba(127,127,127,.25))}',
  'body[' + ATTR + '] .dsa-menu-item{display:flex;align-items:center;gap:8px;width:100%;min-height:40px;padding:8px 10px;border:none;border-radius:10px;font-size:14px;line-height:22px;color:var(--dsw-alias-label-primary);cursor:pointer;user-select:none;white-space:nowrap;text-align:left;background:transparent}',
  'body[' + ATTR + '] .dsa-menu-item:hover{background:var(--dsw-alias-interactive-bg-hover)}',
  'body[' + ATTR + '] [' + ITEM_ATTR + '].dsa-danger,body[' + ATTR + '] [' + ITEM_ATTR + '].dsa-danger .dsa-menu-icon,body[' + ATTR + '] [' + ITEM_ATTR + '].dsa-danger .dsa-menu-label{color:var(--dsw-alias-state-error-primary,#ef4444)}',
  'body[' + ATTR + '] [' + ITEM_ATTR + '].dsa-danger:hover{background:var(--dsw-alias-interactive-bg-hover-danger,rgba(239,68,68,.12))}',
  'body[' + ATTR + '] .dsa-menu-icon{display:inline-flex;flex:none;width:16px;height:16px;align-items:center;justify-content:center;color:var(--dsw-alias-label-tertiary)}',
  'body[' + ATTR + '] .dsa-menu-label{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
  'body[' + ATTR + '] .dsa-overlay{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.45)}',
  'body[' + ATTR + '] .dsa-dialog{min-width:320px;max-width:420px;border:1px solid var(--dsw-alias-border-l2);border-radius:12px;background:var(--dsw-alias-bg-layer-3,#1b1e24);box-shadow:var(--dsw-shadow-lv3,0 12px 40px rgba(0,0,0,.4));font-size:13px;line-height:1.6}',
  'body[' + ATTR + '] .dsa-dialog-head{padding:14px 16px 4px;font-size:15px;font-weight:600;color:var(--dsw-alias-label-primary)}',
  'body[' + ATTR + '] .dsa-dialog-body{padding:8px 16px;color:var(--dsw-alias-label-secondary);word-break:break-all}',
  'body[' + ATTR + '] .dsa-dialog-actions{display:flex;justify-content:flex-end;gap:8px;padding:10px 16px 14px}',
  'body[' + ATTR + '] .dsa-btn{padding:6px 14px;border-radius:8px;border:1px solid var(--dsw-alias-border-l2);background:transparent;color:var(--dsw-alias-label-primary);cursor:pointer;font-size:13px}',
  'body[' + ATTR + '] .dsa-btn:hover{background:var(--dsw-alias-interactive-bg-hover)}',
  'body[' + ATTR + '] .dsa-btn.dsa-primary{background:var(--dsw-alias-brand-primary,#3b82f6);border-color:transparent;color:#fff}',
  'body[' + ATTR + '] .dsa-btn.dsa-danger{background:var(--dsw-alias-state-error-primary,#ef4444);border-color:transparent;color:#fff}',
  'body[' + ATTR + '] .dsa-candidate{padding:8px 12px;border-radius:8px;cursor:pointer;border:1px solid var(--dsw-alias-border-l2);margin-bottom:6px}',
  'body[' + ATTR + '] .dsa-candidate:hover{background:var(--dsw-alias-interactive-bg-hover)}',
  'body[' + ATTR + '] .dsa-toast{position:fixed;left:50%;bottom:28px;z-index:2147483001;transform:translateX(-50%);padding:8px 14px;border-radius:10px;background:var(--dsw-alias-bg-layer-3,#1b1e24);border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-primary);font-size:13px;line-height:20px;box-shadow:var(--dsw-shadow-lv3,0 8px 24px rgba(0,0,0,.28));pointer-events:none}',
  'body[' + ATTR + '] .dsa-pin-section{box-sizing:border-box;flex:none;margin:0 0 4px;padding:0;overflow:visible}',
  'body[' + ATTR + '] .dsa-input{width:100%;box-sizing:border-box;padding:6px 10px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:transparent;color:var(--dsw-alias-label-primary);font-size:13px}',
  'body[' + ATTR + '] .dsa-pin-heading{box-sizing:border-box;display:flex;align-items:center;gap:6px;width:100%;height:34px;padding:0 8px;border:none;border-radius:8px;background:transparent;color:var(--dsw-alias-label-primary);cursor:pointer;text-align:left}',
  'body[' + ATTR + '] .dsa-pin-heading:hover{background:var(--dsw-alias-interactive-bg-hover)}',
  'body[' + ATTR + '] .dsa-pin-slot{flex:none;width:16px;height:20px;display:inline-flex;align-items:center;justify-content:center;color:var(--dsw-alias-label-tertiary)}',
  'body[' + ATTR + '] .dsa-pin-heading .dsa-pin-chevron-slot{display:none}',
  'body[' + ATTR + '] .dsa-pin-heading:hover .dsa-pin-chevron-slot{display:inline-flex}',
  'body[' + ATTR + '] .dsa-pin-heading:hover .dsa-pin-icon{display:none}',
  'body[' + ATTR + '] .dsa-pin-chevron{transition:transform 150ms ease;transform:rotate(0deg)}',
  'body[' + ATTR + '] .dsa-pin-section:not(.dsa-pin-collapsed) .dsa-pin-chevron{transform:rotate(90deg)}',
  'body[' + ATTR + '] .dsa-pin-heading-label{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14px;line-height:20px;font-weight:400}',
  'body[' + ATTR + '] .dsa-pin-list{display:flex;flex-direction:column;gap:2px;margin-top:2px}',
  'body[' + ATTR + '] .dsa-pin-collapsed .dsa-pin-list{display:none}',
  'body[' + ATTR + '] .dsa-pin-row{box-sizing:border-box;display:flex;align-items:center;gap:0;width:100%;height:32px;padding:0 8px;border:none;border-radius:8px;background:transparent;color:var(--dsw-alias-label-primary);font-size:14px;line-height:20px;text-align:left;cursor:grab;pointer-events:auto;user-select:none;-webkit-user-drag:element}',
  'body[' + ATTR + '] .dsa-pin-row.dsa-pin-dragging{opacity:.55;cursor:grabbing}',
  'body[' + ATTR + '] .dsa-pin-row.dsa-pin-drop-before{box-shadow:inset 0 2px 0 var(--dsw-alias-state-business-primary,#3b82f6)}',
  'body[' + ATTR + '] .dsa-pin-row.dsa-pin-drop-after{box-shadow:inset 0 -2px 0 var(--dsw-alias-state-business-primary,#3b82f6)}',
  'body[' + ATTR + '] .dsa-pin-row:hover,body[' + ATTR + '] .dsa-pin-row.dsa-pin-hot,body[' + ATTR + '] .dsa-pin-row[aria-current="true"],body[' + ATTR + '] .dsa-pin-row.dsa-pin-menu-open{background:var(--dsw-alias-interactive-bg-hover)}',
  'body[' + ATTR + '] .dsa-pin-title{flex:1;min-width:0;margin:0 6px 0 4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14px;line-height:20px}',
  'body[' + ATTR + '] .dsa-pin-time{flex:none;font-size:12px;line-height:20px;color:var(--dsw-alias-label-tertiary)}',
  'body[' + ATTR + '] .dsa-pin-more-wrap{flex:none;display:none;align-items:center}',
  'body[' + ATTR + '] .dsa-pin-row:hover .dsa-pin-time,body[' + ATTR + '] .dsa-pin-row.dsa-pin-hot .dsa-pin-time,body[' + ATTR + '] .dsa-pin-row.dsa-pin-menu-open .dsa-pin-time{display:none}',
  'body[' + ATTR + '] .dsa-pin-row:hover .dsa-pin-more-wrap,body[' + ATTR + '] .dsa-pin-row.dsa-pin-hot .dsa-pin-more-wrap,body[' + ATTR + '] .dsa-pin-row.dsa-pin-menu-open .dsa-pin-more-wrap{display:inline-flex}',
  'body[' + ATTR + '] .dsa-pin-more{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;padding:0;border:none;border-radius:4px;background:transparent;color:var(--dsw-alias-label-tertiary);cursor:pointer}',
  'body[' + ATTR + '] .dsa-pin-more:hover{color:var(--dsw-alias-label-primary)}',
  'body[' + ATTR + '] .dsa-pin-fallback{position:fixed;z-index:2147483002;box-sizing:border-box;min-width:218px;max-width:360px;padding:4px;border:1px solid var(--dsw-alias-border-inverted,var(--dsw-alias-border-l2));border-radius:12px;background:var(--dsw-specific-menu,var(--dsw-alias-bg-layer-3,#1b1e24));box-shadow:var(--dsw-shadow-lv3,0 8px 24px rgba(0,0,0,.28))}',
  '@media (prefers-reduced-motion:reduce){body[' + ATTR + '] *{transition:none}}',
].join('\n')

export const ICON_EXPORT = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 2v8M5 5l3-3 3 3M3 10v3h10v-3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
export const ICON_COPY = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><rect x="5.5" y="5.5" width="7" height="8" rx="1.2" stroke="currentColor" stroke-width="1.4"/><path d="M4 10.5H3.7A1.2 1.2 0 0 1 2.5 9.3V3.7A1.2 1.2 0 0 1 3.7 2.5h5.6A1.2 1.2 0 0 1 10.5 3.7V4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>'
export const ICON_TRASH = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3.5 4.5h9M6 4.5V3h4v1.5M5 6.5v6h6v-6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
export const ICON_PIN = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8.8 2.6 13.4 7.2M6.2 5.2l4.6 4.6-2.2 1.1-3.5-3.5 1.1-2.2ZM6.8 10.4 3.4 13.8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
export const ICON_CHEVRON = '<svg class="dsa-pin-chevron" width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true"><path d="M4.25 2.82782L4.25 11.1722C4.25 11.6622 4.84243 11.9076 5.18891 11.5611L9.36109 7.38891C9.57588 7.17412 9.57588 6.82588 9.36109 6.61109L5.18891 2.43891C4.84243 2.09243 4.25 2.33782 4.25 2.82782Z" fill="currentColor"/></svg>'
export const ICON_MORE = '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><circle cx="3.5" cy="8" r="1.2"/><circle cx="8" cy="8" r="1.2"/><circle cx="12.5" cy="8" r="1.2"/></svg>'
export const ICON_EDIT = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M9.6 3.4 12.6 6.4 6 13H3v-3l6.6-6.6Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="m8.5 4.5 3 3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>'
export const ICON_FORK = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M5 3.5v5.2c0 1.3 1 2.3 2.3 2.3H11" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><circle cx="5" cy="3.2" r="1.4" stroke="currentColor" stroke-width="1.4"/><circle cx="11" cy="11" r="1.4" stroke="currentColor" stroke-width="1.4"/><circle cx="5" cy="12.8" r="1.4" stroke="currentColor" stroke-width="1.4"/></svg>'
export const ICON_ARCHIVE = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M2.8 4.2h10.4v2.2H2.8zM4 6.4V13h8V6.4M6.2 9h3.6" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round" stroke-linecap="round"/></svg>'
