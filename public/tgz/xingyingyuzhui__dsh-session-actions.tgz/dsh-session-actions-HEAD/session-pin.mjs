import {
  ITEM_ATTR,
  PIN_ATTR,
  ICON_ARCHIVE,
  ICON_CHEVRON,
  ICON_COPY,
  ICON_EDIT,
  ICON_EXPORT,
  ICON_FORK,
  ICON_MORE,
  ICON_PIN,
  ICON_TRASH,
} from './session-styles.mjs'
import { isSessionId, titleOfRow } from './session-identity.mjs'

export function formatPinTime(updatedAt, t, now) {
  if (updatedAt == null || !(updatedAt > 0)) return ''
  const stamp = now == null ? Date.now() : now
  const diff = Math.max(0, stamp - updatedAt)
  const MIN = 60000
  const HOUR = 3600000
  const DAY = 86400000
  if (diff < MIN) return t('timeNow')
  if (diff < HOUR) return t('timeMinutes', { n: Math.floor(diff / MIN) })
  if (diff < DAY) return t('timeHours', { n: Math.floor(diff / HOUR) })
  if (diff < 30 * DAY) return t('timeDays', { n: Math.floor(diff / DAY) })
  if (diff < 365 * DAY) return t('timeMonths', { n: Math.floor(diff / (30 * DAY)) })
  return t('timeYears', { n: Math.floor(diff / (365 * DAY)) })
}

export function reorderPinIds(pinnedIds, fromId, overId, half) {
  const next = pinnedIds.slice()
  const from = next.indexOf(fromId)
  const over = next.indexOf(overId)
  if (from < 0 || over < 0) return null
  next.splice(from, 1)
  let insertAt = next.indexOf(overId)
  if (insertAt < 0) insertAt = over > from ? over - 1 : over
  if (half === 'after') insertAt += 1
  if (insertAt < 0) insertAt = 0
  if (insertAt > next.length) insertAt = next.length
  next.splice(insertAt, 0, fromId)
  if (next.join('\0') === pinnedIds.join('\0')) return null
  return next
}

export function createPinUi(doc, api) {
  let pinMenuEl = null
  let pinDragging = ''
  let pinDidDrag = false
  let pinDropTarget = null
  let pinDropApplied = false
  let pinHovering = false
  let pinsCollapsed = false
  try { pinsCollapsed = localStorage.getItem('dsa-pins-collapsed') === '1' } catch { /* ignore */ }

  function isPinned(id) {
    return api.getPinnedIds().indexOf(id) !== -1
  }

  function clientSessions() {
    return api.clientSessions()
  }

  function sessionSummary(id) {
    const sessions = clientSessions()
    if (sessions != null && sessions.list != null && typeof sessions.list.getSnapshot === 'function') {
      const snap = sessions.list.getSnapshot()
      if (snap && snap.byId && snap.byId[id]) return snap.byId[id]
    }
    return null
  }

  function titleForSession(id) {
    const row = sessionSummary(id)
    if (row != null) return row.displayTitle || row.title || id
    const catalog = api.getCatalog()
    for (let i = 0; i < catalog.length; i++) {
      if (catalog[i].id === id) return catalog[i].title || id
    }
    const tagged = doc.querySelector('[role="treeitem"][data-session-id="' + id + '"]')
    const fromRow = titleOfRow(tagged)
    return fromRow || id
  }

  function currentSessionId() {
    const sessions = clientSessions()
    if (sessions == null || sessions.list == null || typeof sessions.list.getSnapshot !== 'function') return ''
    const snap = sessions.list.getSnapshot()
    return snap && snap.current ? snap.current : ''
  }

  function findSessionTree() {
    const trees = doc.querySelectorAll('[role="tree"]')
    for (let i = 0; i < trees.length; i++) {
      if (trees[i].querySelector('[role="treeitem"]')) return trees[i]
    }
    return trees[0] || null
  }

  function findPinHost() {
    const tree = findSessionTree()
    if (tree == null || tree.parentNode == null) return null
    return { parent: tree.parentNode, before: tree }
  }

  function findOfficialRow(id) {
    const rows = doc.querySelectorAll('[role="treeitem"][data-session-id="' + id + '"]')
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].closest('[' + PIN_ATTR + ']') == null) return rows[i]
    }
    return null
  }

  function setLast(id) {
    api.setLast(id, findOfficialRow(id))
  }

  function closePinMenu() {
    if (pinMenuEl != null) {
      pinMenuEl.remove()
      pinMenuEl = null
    }
    const openRows = doc.querySelectorAll('.dsa-pin-row.dsa-pin-menu-open')
    for (let i = 0; i < openRows.length; i++) openRows[i].classList.remove('dsa-pin-menu-open')
  }

  function setPinsCollapsed(next) {
    pinsCollapsed = next === true
    try { localStorage.setItem('dsa-pins-collapsed', pinsCollapsed ? '1' : '0') } catch { /* ignore */ }
    const section = doc.querySelector('[' + PIN_ATTR + ']')
    if (section == null) return
    if (pinsCollapsed) section.classList.add('dsa-pin-collapsed')
    else section.classList.remove('dsa-pin-collapsed')
    const heading = section.querySelector('.dsa-pin-heading')
    if (heading != null) heading.setAttribute('aria-expanded', pinsCollapsed ? 'false' : 'true')
  }

  function persistPins(next) {
    api.setPinnedIds(next.slice())
    renderPinSection()
    api.relabelMenuItems()
    return api.post('/dsh-session-actions/pins/set', { sessionIds: api.getPinnedIds() }).then((data) => {
      if (data && data.ok === true && Array.isArray(data.sessionIds)) api.setPinnedIds(data.sessionIds)
      renderPinSection()
      api.relabelMenuItems()
    }).catch(() => { /* keep local pins */ })
  }

  function promptRename(sessionId, currentTitle) {
    const input = doc.createElement('input')
    input.type = 'text'
    input.className = 'dsa-input'
    input.value = currentTitle || ''
    api.dialog(api.t('renameTitle'), input, [
      { label: api.t('cancel'), tone: '' },
      {
        label: api.t('renameConfirm'), tone: 'dsa-primary',
        onClick: function () {
          const name = String(input.value || '').trim()
          if (!name) return
          const sessions = clientSessions()
          const binding = sessions && typeof sessions.binding === 'function' ? sessions.binding(sessionId) : null
          const session = binding && binding.session
          if (session == null || typeof session.rename !== 'function') {
            api.alertError(api.t('noSession'))
            return
          }
          Promise.resolve(session.rename(name)).then((result) => {
            if (result && result.ok === false) {
              api.alertError(result.error && result.error.message ? result.error.message : result.error)
              return
            }
            renderPinSection()
          }).catch((error) => { api.alertError(error) })
        },
      },
    ])
    setTimeout(() => { input.focus(); input.select() }, 0)
  }

  function runFork(sessionId) {
    const sessions = clientSessions()
    if (sessions == null || typeof sessions.fork !== 'function') {
      api.alertError(api.t('noSession'))
      return
    }
    Promise.resolve(sessions.fork({ sessionId, increaseTitle: true })).then((childId) => {
      if (childId && typeof sessions.open === 'function') sessions.open(childId)
    }).catch((error) => { api.alertError(error) })
  }

  function runArchive(sessionId) {
    const workspaces = api.clientWorkspaces()
    if (workspaces == null || typeof workspaces.archiveSession !== 'function') {
      api.alertError(api.t('noSession'))
      return
    }
    Promise.resolve(workspaces.archiveSession(sessionId)).then(() => {
      if (isPinned(sessionId)) persistPins(api.getPinnedIds().filter((id) => id !== sessionId))
    }).catch((error) => { api.alertError(error) })
  }

  function openPinMenu(sessionId, anchor) {
    setLast(sessionId)
    closePinMenu()
    const menu = doc.createElement('div')
    menu.className = 'dsa-pin-fallback'
    menu.setAttribute('role', 'menu')
    menu.appendChild(api.makeItem(api.t('rename'), false, ICON_EDIT, () => {
      api.closeMenus()
      promptRename(sessionId, titleForSession(sessionId))
    }, null, sessionId, 'rename'))
    menu.appendChild(api.makeItem(api.t('forkSession'), false, ICON_FORK, () => {
      api.closeMenus()
      runFork(sessionId)
    }, null, sessionId, 'fork'))
    menu.appendChild(api.makeItem(api.t('archiveSession'), false, ICON_ARCHIVE, () => {
      api.closeMenus()
      runArchive(sessionId)
    }, null, sessionId, 'archive'))
    const sep = doc.createElement('div')
    sep.className = 'dsa-menu-sep'
    sep.setAttribute(ITEM_ATTR, '')
    sep.setAttribute('role', 'separator')
    menu.appendChild(sep)
    menu.appendChild(api.makeItem(api.t('copyId'), false, ICON_COPY, api.handleCopy, null, sessionId, 'copy'))
    menu.appendChild(api.makeItem(api.t('unpinSession'), false, ICON_PIN, api.handlePin, null, sessionId, 'pin'))
    menu.appendChild(api.makeItem(api.t('exportMd'), false, ICON_EXPORT, api.handleExport, null, sessionId, 'export'))
    menu.appendChild(api.makeItem(api.t('deleteSession'), true, ICON_TRASH, api.handleDelete, null, sessionId, 'delete'))
    doc.body.appendChild(menu)
    const rect = anchor.getBoundingClientRect()
    let left = rect.left
    let top = rect.bottom + 4
    const vw = window.innerWidth
    const vh = window.innerHeight
    const lw = menu.offsetWidth
    const lh = menu.offsetHeight
    left = Math.min(Math.max(left, 12), Math.max(12, vw - lw - 12))
    if (top + lh > vh - 12) top = Math.max(12, rect.top - lh - 4)
    menu.style.left = left + 'px'
    menu.style.top = top + 'px'
    pinMenuEl = menu
    const row = anchor.closest('.dsa-pin-row')
    if (row != null) row.classList.add('dsa-pin-menu-open')
  }

  function syncPinMetrics(section) {
    const tree = findSessionTree()
    if (tree == null || section.parentNode == null) return
    const official = tree.querySelector('[role="treeitem"]')
    if (official == null) return
    const box = official.getBoundingClientRect()
    const parentBox = section.parentNode.getBoundingClientRect()
    if (box.width < 40) return
    section.style.marginLeft = Math.max(0, box.left - parentBox.left) + 'px'
    section.style.width = box.width + 'px'
    section.style.marginRight = '0'
    section.style.paddingLeft = '0'
    section.style.paddingRight = '0'
    const officialTitle = official.querySelector('[class*="title"]')
    const ourLabel = section.querySelector('.dsa-pin-heading-label')
    if (officialTitle != null && ourLabel != null) {
      ourLabel.style.marginLeft = '0px'
      const delta = officialTitle.getBoundingClientRect().left - ourLabel.getBoundingClientRect().left
      if (Math.abs(delta) >= 0.5) ourLabel.style.marginLeft = delta + 'px'
    }
  }

  function pinTargetFromY(clientY) {
    const list = doc.querySelector('[' + PIN_ATTR + '] .dsa-pin-list')
    if (list == null) return null
    const rows = list.querySelectorAll('.dsa-pin-row')
    if (rows.length === 0) return null
    for (let i = 0; i < rows.length; i++) {
      const box = rows[i].getBoundingClientRect()
      const id = rows[i].getAttribute('data-session-id')
      if (!isSessionId(id)) continue
      if (clientY < box.top + box.height / 2) return { id, half: 'before', row: rows[i] }
    }
    const last = rows[rows.length - 1]
    return { id: last.getAttribute('data-session-id'), half: 'after', row: last }
  }

  function clearPinDropMarkers() {
    const marked = doc.querySelectorAll('.dsa-pin-drop-before, .dsa-pin-drop-after')
    for (let i = 0; i < marked.length; i++) {
      marked[i].classList.remove('dsa-pin-drop-before')
      marked[i].classList.remove('dsa-pin-drop-after')
    }
  }

  function setPinDropMarker(row, half) {
    clearPinDropMarkers()
    if (row != null) row.classList.add(half === 'after' ? 'dsa-pin-drop-after' : 'dsa-pin-drop-before')
  }

  function updatePinDropFromEvent(event) {
    if (!pinDragging) return false
    const target = pinTargetFromY(event.clientY)
    if (target == null || target.id === pinDragging) {
      pinDropTarget = null
      clearPinDropMarkers()
      return false
    }
    pinDropTarget = { id: target.id, half: target.half }
    setPinDropMarker(target.row, target.half)
    return true
  }

  function reorderPins(fromId, overId, half) {
    const next = reorderPinIds(api.getPinnedIds(), fromId, overId, half)
    if (next == null) return
    persistPins(next)
  }

  function applyPinDrop() {
    if (pinDropApplied || !pinDragging || pinDropTarget == null) return
    pinDropApplied = true
    reorderPins(pinDragging, pinDropTarget.id, pinDropTarget.half)
    pinDropTarget = null
    clearPinDropMarkers()
  }

  function bindPinRow(row, id) {
    row.draggable = true
    row.addEventListener('pointerenter', () => { row.classList.add('dsa-pin-hot') })
    row.addEventListener('pointerleave', () => { row.classList.remove('dsa-pin-hot') })
    row.addEventListener('click', (event) => {
      if (event.target.closest && event.target.closest('.dsa-pin-more')) return
      if (pinDidDrag) {
        event.preventDefault()
        event.stopPropagation()
        pinDidDrag = false
        return
      }
      event.preventDefault()
      setLast(id)
      const sessions = clientSessions()
      if (sessions != null && typeof sessions.open === 'function') sessions.open(id)
    })
    row.addEventListener('pointerdown', () => { setLast(id) }, true)
    row.addEventListener('dragstart', (event) => {
      if (event.target && event.target.closest && event.target.closest('.dsa-pin-more')) {
        event.preventDefault()
        return
      }
      pinDragging = id
      pinDidDrag = true
      pinDropApplied = false
      pinDropTarget = null
      pinHovering = true
      event.dataTransfer.effectAllowed = 'move'
      try { event.dataTransfer.setData('text/plain', id) } catch { /* ie */ }
      row.classList.add('dsa-pin-dragging')
    })
    row.addEventListener('dragend', () => {
      applyPinDrop()
      row.classList.remove('dsa-pin-dragging')
      clearPinDropMarkers()
      pinDragging = ''
      pinDropTarget = null
      setTimeout(() => { pinDidDrag = false }, 0)
    })
    row.addEventListener('dragover', (event) => {
      if (!pinDragging) return
      event.preventDefault()
      event.dataTransfer.dropEffect = 'move'
      updatePinDropFromEvent(event)
    })
    row.addEventListener('drop', (event) => {
      if (!pinDragging) return
      event.preventDefault()
      updatePinDropFromEvent(event)
      applyPinDrop()
    })
    const more = row.querySelector('.dsa-pin-more')
    if (more != null) {
      more.draggable = false
      more.addEventListener('click', (event) => {
        event.preventDefault()
        event.stopPropagation()
        api.setLast(id, findOfficialRow(id))
        openPinMenu(id, more)
      })
    }
  }

  function renderPinSection() {
    const pinnedIds = api.getPinnedIds()
    const existing = doc.querySelector('[' + PIN_ATTR + ']')
    if (pinnedIds.length === 0) {
      closePinMenu()
      if (existing != null) existing.remove()
      return
    }
    const host = findPinHost()
    if (host == null) return
    let section = existing
    if (section == null) {
      section = doc.createElement('div')
      section.setAttribute(PIN_ATTR, '')
      section.className = 'dsa-pin-section'
    }
    if (section.getAttribute('data-dsa-hover') !== '1') {
      section.setAttribute('data-dsa-hover', '1')
      section.addEventListener('pointerenter', () => { pinHovering = true })
      section.addEventListener('pointerleave', () => { pinHovering = false })
    }
    let heading = section.querySelector('.dsa-pin-heading')
    if (heading == null || heading.querySelector('.dsa-pin-icon') == null) {
      if (heading != null) heading.remove()
      heading = doc.createElement('button')
      heading.type = 'button'
      heading.className = 'dsa-pin-heading'
      const iconSlot = doc.createElement('span')
      iconSlot.className = 'dsa-pin-slot dsa-pin-icon'
      iconSlot.innerHTML = ICON_PIN
      const chevronSlot = doc.createElement('span')
      chevronSlot.className = 'dsa-pin-slot dsa-pin-chevron-slot'
      chevronSlot.innerHTML = ICON_CHEVRON
      const headingLabel = doc.createElement('span')
      headingLabel.className = 'dsa-pin-heading-label'
      heading.appendChild(iconSlot)
      heading.appendChild(chevronSlot)
      heading.appendChild(headingLabel)
      heading.addEventListener('click', (event) => {
        event.preventDefault()
        event.stopPropagation()
        setPinsCollapsed(!pinsCollapsed)
      })
      section.insertBefore(heading, section.firstChild)
    }
    if (section.querySelector('.dsa-pin-list') == null) {
      const list = doc.createElement('div')
      list.className = 'dsa-pin-list'
      section.appendChild(list)
    }
    if (section.getAttribute('data-dsa-drag') !== '1') {
      section.setAttribute('data-dsa-drag', '1')
      const onListDrag = (event) => {
        if (!pinDragging) return
        event.preventDefault()
        event.dataTransfer.dropEffect = 'move'
        updatePinDropFromEvent(event)
      }
      section.addEventListener('dragover', onListDrag)
      section.addEventListener('drop', (event) => {
        if (!pinDragging) return
        event.preventDefault()
        updatePinDropFromEvent(event)
        applyPinDrop()
      })
    }
    if (pinsCollapsed) section.classList.add('dsa-pin-collapsed')
    else section.classList.remove('dsa-pin-collapsed')
    if (section.parentNode !== host.parent || section.nextSibling !== host.before) {
      host.parent.insertBefore(section, host.before)
    }
    syncPinMetrics(section)
    const headingBtn = section.querySelector('.dsa-pin-heading')
    if (headingBtn != null) headingBtn.setAttribute('aria-expanded', pinsCollapsed ? 'false' : 'true')
    const headingLabelEl = section.querySelector('.dsa-pin-heading-label')
    if (headingLabelEl != null) headingLabelEl.textContent = api.t('pinnedSection')
    const listEl = section.querySelector('.dsa-pin-list')
    if (listEl == null) return
    const seen = {}
    const rows = listEl.querySelectorAll('.dsa-pin-row')
    for (let r = 0; r < rows.length; r++) {
      const existingId = rows[r].getAttribute('data-session-id')
      if (pinnedIds.indexOf(existingId) === -1) rows[r].remove()
      else seen[existingId] = rows[r]
    }
    const current = currentSessionId()
    for (let i = 0; i < pinnedIds.length; i++) {
      const id = pinnedIds[i]
      let row = seen[id]
      if (row == null) {
        row = doc.createElement('div')
        row.className = 'dsa-pin-row'
        row.setAttribute('data-session-id', id)
        const lead = doc.createElement('span')
        lead.className = 'dsa-pin-slot'
        const title = doc.createElement('span')
        title.className = 'dsa-pin-title'
        const time = doc.createElement('span')
        time.className = 'dsa-pin-time'
        const moreWrap = doc.createElement('span')
        moreWrap.className = 'dsa-pin-more-wrap'
        const more = doc.createElement('button')
        more.type = 'button'
        more.className = 'dsa-pin-more'
        more.innerHTML = ICON_MORE
        moreWrap.appendChild(more)
        row.appendChild(lead)
        row.appendChild(title)
        row.appendChild(time)
        row.appendChild(moreWrap)
        bindPinRow(row, id)
        listEl.appendChild(row)
      }
      if (row.querySelector('.dsa-pin-time') == null) {
        const insertedTime = doc.createElement('span')
        insertedTime.className = 'dsa-pin-time'
        const moreWrapEl = row.querySelector('.dsa-pin-more-wrap')
        if (moreWrapEl != null) row.insertBefore(insertedTime, moreWrapEl)
        else row.appendChild(insertedTime)
      }
      const label = row.querySelector('.dsa-pin-title')
      const name = titleForSession(id)
      if (label != null && label.textContent !== name) label.textContent = name
      const meta = sessionSummary(id)
      const timeEl = row.querySelector('.dsa-pin-time')
      const timeText = formatPinTime(meta && meta.updatedAt, api.t)
      if (timeEl != null && timeEl.textContent !== timeText) timeEl.textContent = timeText
      const moreBtn = row.querySelector('.dsa-pin-more')
      const moreLabel = api.t('pinMore', { name })
      if (moreBtn != null && moreBtn.getAttribute('aria-label') !== moreLabel) moreBtn.setAttribute('aria-label', moreLabel)
      if (id === current) row.setAttribute('aria-current', 'true')
      else row.removeAttribute('aria-current')
      if (row.parentNode !== listEl || listEl.children[i] !== row) {
        const ref = listEl.children[i] || null
        listEl.insertBefore(row, ref)
      }
    }
  }

  function removePin(sessionId) {
    const ids = api.getPinnedIds()
    if (ids.indexOf(sessionId) === -1) return
    api.setPinnedIds(ids.filter((id) => id !== sessionId))
    renderPinSection()
  }

  function syncMetrics() {
    const section = doc.querySelector('[' + PIN_ATTR + ']')
    if (section != null) syncPinMetrics(section)
  }

  function containsMenu(target) {
    return pinMenuEl != null && target && typeof target.closest === 'function'
      && !pinMenuEl.contains(target) && target.closest('.dsa-pin-more') == null
  }

  return {
    closeMenu: closePinMenu,
    render: renderPinSection,
    persist: persistPins,
    isPinned,
    remove: removePin,
    syncMetrics,
    isHovering: () => pinHovering,
    containsMenu,
    findOfficialRow,
    titleForSession,
  }
}
