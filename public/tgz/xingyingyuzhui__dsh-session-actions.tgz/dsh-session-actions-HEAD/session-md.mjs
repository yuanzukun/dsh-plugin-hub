// Pure session-log → Markdown renderer. No DOM, no ctx — host and tests share this.

const COPY = {
  zh: {
    session: '会话',
    workspace: '工作区',
    turn: '回合',
    user: '用户',
    think: '思考',
    tool: '工具调用',
    assistant: '助手',
    result: '工具结果',
    resultError: '工具结果（错误）',
  },
  en: {
    session: 'Session',
    workspace: 'Workspace',
    turn: 'Turn',
    user: 'User',
    think: 'Thinking',
    tool: 'Tool call',
    assistant: 'Assistant',
    result: 'Tool result',
    resultError: 'Tool result (error)',
  },
}

export function resolveLang(tag) {
  if (tag == null || String(tag).trim() === '') return 'zh'
  return String(tag).toLowerCase().indexOf('zh') === 0 ? 'zh' : 'en'
}

const textOf = (blocks) => {
  if (!Array.isArray(blocks)) return ''
  return blocks
    .filter((b) => b != null && b.type === 'text' && typeof b.text === 'string')
    .map((b) => b.text)
    .join('\n')
}

const prettyJson = (raw) => {
  if (typeof raw !== 'string') return JSON.stringify(raw, null, 2)
  try {
    return JSON.stringify(JSON.parse(raw), null, 2)
  } catch {
    return raw
  }
}

export function sessionTitle(events, fallback = '') {
  let title = null
  for (const event of events || []) {
    if (event.type !== 'session/title') continue
    const data = event.data || {}
    const value = data.title ?? data.text
    if (typeof value === 'string' && value.trim() !== '') title = value.trim()
  }
  return title || fallback
}

export function isHumanUserMessage(event) {
  const data = event && event.data
  const message = data && (data.message ?? data)
  const source = (message && message.source) || (data && data.source)
  if (source == null || source.kind == null) return true
  return source.kind === 'user'
}

function pushBlock(out, block, t) {
  if (block == null) return
  switch (block.type) {
    case 'reasoning':
      out.push('', `### ${t.think}`)
      out.push(String(block.text ?? ''))
      break
    case 'text':
      out.push('', `### ${t.assistant}`)
      out.push(String(block.text ?? ''))
      break
    case 'tool-call':
      out.push('', `### ${t.tool} · ${String(block.name ?? 'tool')}`)
      out.push('```json')
      out.push(prettyJson(block.arguments))
      out.push('```')
      break
    case 'tool-result':
      out.push('', block.isError === true ? `> **${t.resultError}**` : `> **${t.result}**`)
      out.push(textOf(block.content))
      break
    default:
      out.push('', '```json')
      out.push(JSON.stringify(block))
      out.push('```')
  }
}

export function eventsToMarkdown(events, opts = {}) {
  const lang = resolveLang(opts.lang)
  const t = COPY[lang]
  const title = opts.title || sessionTitle(events, opts.sessionId || t.session)
  const out = []
  out.push(`# ${title}`)
  const meta = []
  if (opts.cwd) meta.push(`${t.workspace}: ${opts.cwd}`)
  if (opts.sessionId) meta.push(`${t.session}: ${opts.sessionId}`)
  if (meta.length > 0) out.push('', `> ${meta.join(' · ')}`)
  let turn = 0
  for (const event of events || []) {
    if (event == null || typeof event.type !== 'string') continue
    switch (event.type) {
      case 'turn/start':
        turn += 1
        out.push('', `## ${t.turn} ${turn}`)
        break
      case 'user/message': {
        if (!isHumanUserMessage(event)) break
        const message = event.data?.message ?? event.data
        const content = message?.content ?? message?.blocks
        const text = textOf(content)
        if (text !== '') {
          out.push('', `### ${t.user}`)
          out.push(text)
        }
        break
      }
      case 'assistant/message': {
        const message = event.data?.message ?? event.data
        const blocks = message?.content ?? message?.blocks
        if (Array.isArray(blocks)) {
          for (const block of blocks) pushBlock(out, block, t)
        }
        break
      }
      case 'tool/result': {
        const result = event.data?.result ?? event.data?.message ?? event.data
        pushBlock(out, { type: 'tool-result', content: result?.content, isError: result?.isError }, t)
        break
      }
      default:
        break
    }
  }
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n'
}
