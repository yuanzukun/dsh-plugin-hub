// dsh-session-actions —— Host 面
//   POST /dsh-session-actions/export
//   POST /dsh-session-actions/delete
//   POST /dsh-session-actions/catalog
//   POST /dsh-session-actions/pins/get
//   POST /dsh-session-actions/pins/set
// 安全：仅 POST + 自定义请求头 + loopback Origin。
import { homedir } from 'node:os'
import { dirname, join, resolve, sep } from 'node:path'
import { access, mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { eventsToMarkdown, sessionTitle } from './session-md.mjs'

export const name = 'dsh-session-actions'
export const inject = ['webServer', 'sessions', 'sessionController']

const SESSION_ID_RE = /^session-[A-Za-z0-9-]{6,}$/
const BODY_CAP = 65536
const EXPORT_CAP = 2_000_000
const LOOPBACK_ORIGIN = /^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/
const SESSIONS_ROOT = join(homedir(), '.dsh', 'sessions')
let stateDir = join(homedir(), '.dsh', 'dsh-session-actions')
const pinsPath = () => join(stateDir, 'pins.json')

const sanitizePinIds = (ids) => {
  const out = []
  const seen = new Set()
  for (const id of Array.isArray(ids) ? ids : []) {
    if (typeof id !== 'string' || !SESSION_ID_RE.test(id) || seen.has(id)) continue
    seen.add(id)
    out.push(id)
  }
  return out
}

async function readPins() {
  try {
    const raw = JSON.parse(await readFile(pinsPath(), 'utf8'))
    return sanitizePinIds(raw && raw.sessionIds)
  } catch {
    return []
  }
}

async function writePins(ids) {
  const sessionIds = sanitizePinIds(ids)
  await mkdir(stateDir, { recursive: true })
  await writeFile(pinsPath(), JSON.stringify({ sessionIds }, null, 2) + '\n', 'utf8')
  return sessionIds
}

const readJsonBody = (req, cap = BODY_CAP) => new Promise((resolveBody, reject) => {
  let size = 0
  const chunks = []
  req.on('data', (chunk) => {
    size += chunk.length
    if (size > cap) {
      reject(new Error('body too large'))
      req.destroy()
      return
    }
    chunks.push(chunk)
  })
  req.on('end', () => {
    try {
      resolveBody(chunks.length === 0 ? {} : JSON.parse(Buffer.concat(chunks).toString('utf8')))
    } catch {
      reject(new Error('invalid json body'))
    }
  })
  req.on('error', reject)
})

const writeJson = (res, status, body) => {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
  res.end(JSON.stringify(body))
}

const guard = (req, res) => {
  if (req.method !== 'POST') {
    writeJson(res, 405, { ok: false, error: 'method not allowed' })
    return false
  }
  const headers = req.headers || {}
  if (headers['x-dsh-session-actions'] !== '1') {
    writeJson(res, 403, { ok: false, error: 'missing csrf header' })
    return false
  }
  const origin = headers.origin
  if (origin !== undefined && origin !== null && !LOOPBACK_ORIGIN.test(origin)) {
    writeJson(res, 403, { ok: false, error: 'origin not allowed' })
    return false
  }
  return true
}

const safeFile = (title) => {
  const base = String(title || 'session').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 80).trim()
  return (base || 'session') + '.md'
}

const headerCwd = (header) => header?.cwd ?? header?.meta?.cwd ?? null

const recordFromLive = (session) => ({
  id: session.id,
  events: session.events,
  cwd: headerCwd(session.header),
  title: sessionTitle(session.events, session.id),
  header: session.header,
})

const catalogFromLive = (sessions) => sessions.list().map((session) => ({
  id: session.id,
  title: sessionTitle(session.events, session.id),
  cwd: headerCwd(session.header),
}))

async function catalogFromController(sessions, sessionController) {
  if (sessionController == null || typeof sessionController.list !== 'function') return null
  let listed
  try {
    listed = await sessionController.list({}, new AbortController().signal)
  } catch {
    return null
  }
  const items = Array.isArray(listed) ? listed : listed?.items
  if (!Array.isArray(items)) return []
  return Promise.all(items.map(async (item) => {
    const id = item?.sessionId ?? item?.id
    if (typeof id !== 'string') return null
    const live = sessions.get(id)
    if (live !== undefined) {
      return {
        id,
        title: sessionTitle(live.events, id),
        cwd: headerCwd(live.header),
      }
    }
    try {
      const inspection = await sessionController.inspect(id)
      const events = inspection?.events || []
      const header = inspection?.meta || inspection?.header
      return { id, title: sessionTitle(events, id), cwd: headerCwd(header) }
    } catch {
      return { id, title: item?.title || id, cwd: item?.cwd || null }
    }
  })).then((rows) => rows.filter(Boolean))
}

async function catalog(sessions, sessionController) {
  const fromController = await catalogFromController(sessions, sessionController)
  return fromController ?? catalogFromLive(sessions)
}

async function inspectById(sessionController, sessionId) {
  if (sessionController == null || typeof sessionController.inspect !== 'function') return null
  try {
    const inspection = await sessionController.inspect(sessionId)
    const events = inspection?.events || []
    const header = inspection?.meta || inspection?.header
    return { events, header }
  } catch {
    return null
  }
}

async function loadById(sessions, persistence, sessionController, sessionId) {
  const live = sessions.get(sessionId)
  if (live !== undefined) return recordFromLive(live)
  const inspectedByController = await inspectById(sessionController, sessionId)
  if (inspectedByController != null) {
    return {
      id: sessionId,
      events: inspectedByController.events,
      cwd: headerCwd(inspectedByController.header),
      title: sessionTitle(inspectedByController.events, sessionId),
      header: inspectedByController.header,
    }
  }
  if (persistence != null && typeof persistence.inspect === 'function') {
    try {
      const inspection = await persistence.inspect(sessionId)
      const events = inspection.events || []
      const header = inspection.meta || inspection.header
      return {
        id: sessionId,
        events,
        cwd: headerCwd(header),
        title: sessionTitle(events, sessionId),
        header,
      }
    } catch {
      // The storage backend uses a not-found error for missing sessions.
    }
  }
  return null
}

async function resolveRecord(sessions, persistence, sessionController, body) {
  if (typeof body.sessionId === 'string' && SESSION_ID_RE.test(body.sessionId)) {
    const record = await loadById(sessions, persistence, sessionController, body.sessionId)
    if (record == null) return { error: 'session not found' }
    return { record }
  }
  const title = typeof body.title === 'string' ? body.title.trim() : ''
  if (title === '') return { error: 'missing session id' }
  const matched = (await catalog(sessions, sessionController)).filter((row) => row.title === title)
  if (matched.length === 0) return { error: 'session not found' }
  if (matched.length > 1) {
    return { ambiguous: true, candidates: matched }
  }
  const record = await loadById(sessions, persistence, sessionController, matched[0].id)
  if (record == null) return { error: 'session not found' }
  return { record }
}

const isSafeSessionDir = (dirPath, sessionId) => {
  const resolved = resolve(dirPath)
  const root = resolve(SESSIONS_ROOT)
  if (resolved === root || !resolved.startsWith(root + sep)) return false
  const base = resolved.split(sep).pop()
  return base === sessionId && SESSION_ID_RE.test(sessionId)
}

const effectLabel = (fn) => {
  if (typeof fn !== 'function') return ''
  for (const symbol of Object.getOwnPropertySymbols(fn)) {
    try {
      const meta = fn[symbol]
      if (meta != null && typeof meta === 'object' && typeof meta.label === 'string') return meta.label
    } catch {
      // ignore inaccessible symbol
    }
  }
  return ''
}

const collectFibers = (ctx) => {
  const fibers = []
  const seen = new Set()
  const add = (fiber) => {
    if (fiber == null || seen.has(fiber)) return
    seen.add(fiber)
    fibers.push(fiber)
  }
  add(ctx?.fiber)
  const registry = ctx?.registry
  if (registry != null && typeof registry.values === 'function') {
    for (const runtime of registry.values()) {
      if (runtime?.fibers == null) continue
      for (const fiber of runtime.fibers) add(fiber)
    }
  }
  return fibers
}

// Official create/resume keeps teardown on `agentLoop.lifecycle(<id>)`.
// Invoking that disposer stops the agent and detaches the live session.
async function disposeLiveSession(ctx, sessionId) {
  const label = `agentLoop.lifecycle(${sessionId})`
  for (const fiber of collectFibers(ctx)) {
    const disposables = fiber?._disposables
    if (disposables == null) continue
    for (const dispose of disposables) {
      if (typeof dispose !== 'function' || effectLabel(dispose) !== label) continue
      await Promise.resolve(dispose())
      return true
    }
  }
  return false
}

async function detachFromWorkspaces(ctx, sessionId) {
  const registry = typeof ctx.get === 'function' ? ctx.get('workspaceRegistry') : ctx.workspaceRegistry
  if (registry == null || typeof registry.list !== 'function') return
  for (const workspace of registry.list()) {
    if (workspace != null && typeof workspace.detachSession === 'function') {
      try {
        await workspace.detachSession(sessionId)
      } catch {
        // keep going; file delete is the source of truth
      }
    }
  }
}

async function collectSessionDirs(sessionId, persistence, header) {
  const targets = new Set()
  if (persistence != null && typeof persistence.locate === 'function' && header != null) {
    try {
      const location = persistence.locate(header)
      if (location != null && typeof location.path === 'string') {
        targets.add(dirname(location.path))
      }
    } catch {
      // fall through to directory scan
    }
  }
  try {
    const dirs = await readdir(SESSIONS_ROOT, { withFileTypes: true })
    for (const dir of dirs) {
      if (!dir.isDirectory()) continue
      targets.add(join(SESSIONS_ROOT, dir.name, sessionId))
    }
  } catch {
    // sessions root missing
  }
  return [...targets].filter((target) => isSafeSessionDir(target, sessionId))
}

const pathExists = async (target) => {
  try {
    await access(target)
    return true
  } catch {
    return false
  }
}

async function leftoverSessionDirs(sessionId, persistence, header) {
  const leftover = []
  for (const target of await collectSessionDirs(sessionId, persistence, header)) {
    if (await pathExists(target)) leftover.push(target)
  }
  return leftover
}

async function deleteSessionFiles(sessionId, persistence, header) {
  for (const target of await leftoverSessionDirs(sessionId, persistence, header)) {
    try {
      await rm(target, { recursive: true, force: true })
    } catch {
      // keep trying other locations
    }
  }
  return leftoverSessionDirs(sessionId, persistence, header)
}

export function apply(ctx) {
  const sessions = ctx.sessions
  if (sessions === undefined || typeof sessions.get !== 'function' || typeof sessions.list !== 'function') {
    throw new Error('dsh-session-actions: sessions service unavailable')
  }
  const persistence = typeof ctx.get === 'function' ? ctx.get('sessionPersistence') : ctx.sessionPersistence
  // New Harness versions expose cold-session inspection/listing through the
  // Session Controller. Keep this optional so older runtimes still load.
  const sessionController = typeof ctx.get === 'function'
    ? ctx.get('sessionController')
    : ctx.sessionController

  const handle = (req, res, fn) => {
    if (!guard(req, res)) return Promise.resolve()
    return readJsonBody(req)
      .then((body) => fn(body))
      .then((result) => writeJson(res, 200, result))
      .catch((error) => writeJson(res, 400, { ok: false, error: String((error && error.message) || error).slice(0, 500) }))
  }

  const catalogHandler = (req, res) => handle(req, res, async () => ({
    ok: true,
    sessions: await catalog(sessions, sessionController),
  }))

  const exportHandler = (req, res) => handle(req, res, async (body) => {
    const resolved = await resolveRecord(sessions, persistence, sessionController, body)
    if (resolved.error) return { ok: false, error: resolved.error }
    if (resolved.ambiguous) return { ok: false, ambiguous: true, candidates: resolved.candidates }
    const record = resolved.record
    const markdown = eventsToMarkdown(record.events, {
      title: record.title,
      cwd: record.cwd ?? undefined,
      sessionId: record.id,
      lang: body.lang,
    })
    if (markdown.length > EXPORT_CAP) return { ok: false, error: 'export too large' }
    return { ok: true, markdown, filename: safeFile(record.title), sessionId: record.id }
  })

  const deleteHandler = (req, res) => handle(req, res, async (body) => {
    const resolved = await resolveRecord(sessions, persistence, sessionController, body)
    if (resolved.error) return { ok: false, error: resolved.error }
    if (resolved.ambiguous) return { ok: false, ambiguous: true, candidates: resolved.candidates }
    const record = resolved.record
    const wasLive = sessions.get(record.id) !== undefined
    if (wasLive) {
      await disposeLiveSession(ctx, record.id)
      // session/disposed retirement flushes the log; wait so we delete the final files.
      try { await inspectById(sessionController, record.id) } catch { /* flushed or already gone */ }
      if (persistence != null && typeof persistence.inspect === 'function') {
        try { await persistence.inspect(record.id) } catch { /* flushed or already gone */ }
      }
    }
    await detachFromWorkspaces(ctx, record.id)
    const leftover = await deleteSessionFiles(record.id, persistence, record.header)
    if (sessions.get(record.id) !== undefined) {
      return { ok: false, error: 'session is still live; could not unload it' }
    }
    if (leftover.length > 0) return { ok: false, error: 'session files not found' }
    const pins = await readPins()
    const nextPins = pins.filter((id) => id !== record.id)
    if (nextPins.length !== pins.length) await writePins(nextPins)
    return { ok: true, sessionId: record.id }
  })

  const pinsGetHandler = (req, res) => handle(req, res, async () => ({
    ok: true,
    sessionIds: await readPins(),
  }))

  const pinsSetHandler = (req, res) => handle(req, res, async (body) => ({
    ok: true,
    sessionIds: await writePins(body && body.sessionIds),
  }))

  const disposeCatalog = ctx.webServer.register({ kind: 'exact', path: '/dsh-session-actions/catalog', handler: catalogHandler })
  const disposeExport = ctx.webServer.register({ kind: 'exact', path: '/dsh-session-actions/export', handler: exportHandler })
  const disposeDelete = ctx.webServer.register({ kind: 'exact', path: '/dsh-session-actions/delete', handler: deleteHandler })
  const disposePinsGet = ctx.webServer.register({ kind: 'exact', path: '/dsh-session-actions/pins/get', handler: pinsGetHandler })
  const disposePinsSet = ctx.webServer.register({ kind: 'exact', path: '/dsh-session-actions/pins/set', handler: pinsSetHandler })

  ctx.effect(() => () => {
    disposeCatalog()
    disposeExport()
    disposeDelete()
    disposePinsGet()
    disposePinsSet()
  })
}

export const _internal = {
  isSafeSessionDir,
  SESSION_ID_RE,
  deleteSessionFiles,
  disposeLiveSession,
  sanitizePinIds,
  readPins,
  writePins,
  setStateDir: (dir) => { stateDir = dir },
}
