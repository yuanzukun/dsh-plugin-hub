/**
 * dsh-weixin — 微信消息通道插件。
 *
 * 把微信变成 DSH 的入口：手机微信发消息 → weixin-agent-sdk（iLink 通道）→
 * 本插件把消息驱动进 DSH agent，并把最终回复发回微信。
 *
 * 会话连续性：每个微信对话（conversationId）复用一个 DSH agent，多次消息
 * 走同一个 session。进程/DSH 重启后清空对话记忆（文件改动不受影响）。
 */
import { randomUUID } from 'node:crypto'
import { installModelSelection } from '@deepseek-ai/dsh-agent'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { SessionId } from '@deepseek-ai/dsh-session'
import Schema from '@deepseek-ai/schemastery'
import { isLoggedIn, start } from 'weixin-agent-sdk'

export const name = 'dsh-weixin'

export const inject = ['agentDefaultModel', 'agents']

export const Config = Schema.object({
  /** agent 的工作目录；缺省用 DSH 启动目录。 */
  cwd: Schema.string(),
  /** 覆盖默认 provider 路由。 */
  provider: Schema.string(),
  /** 覆盖默认模型。 */
  model: Schema.string(),
})

/** 从 session 事件里汇总指定区间内最后一段 assistant 文本。 */
function summarize(events, firstSeq) {
  let started = false
  let text = ''
  for (const event of events) {
    if (event.seq < firstSeq) continue
    if (event.type === 'turn/start') {
      started = true
      continue
    }
    if (!started) continue
    if (event.type === 'assistant/message') {
      text = event.data.message.content
        .filter((block) => block.type === 'text')
        .map((block) => block.text)
        .join('')
    }
  }
  return text
}

export function apply(ctx, config) {
  // conversationId -> { agent, dispose }
  const conversations = new Map()

  function selectedModel() {
    const def = ctx.get('agentDefaultModel').currentSelection()
    return {
      provider: config.provider ?? def.provider,
      model: config.model ?? def.model,
    }
  }

  async function ensureAgent(conversationId) {
    const existing = conversations.get(conversationId)
    if (existing) return existing

    const selection = selectedModel()
    const agents = ctx.get('agents')
    const handle = await agents.create({
      sessionId: SessionId(`weixin-${randomUUID()}`),
      meta: { cwd: config.cwd ?? process.cwd() },
      agentOptions: { provider: selection.provider, model: selection.model },
      setup: (agentCtx) => {
        installModelSelection(agentCtx, { current: selection, assembled: undefined })
      },
    })
    await handle.agent.whenIdle()
    const entry = { agent: handle.agent, dispose: handle.dispose }
    conversations.set(conversationId, entry)
    return entry
  }

  const weixinAgent = {
    async chat(request) {
      try {
        const { agent } = await ensureAgent(request.conversationId)
        const firstSeq = agent.session.seq
        agent.followup(createUserMessage({
          content: [{ type: 'text', text: request.text }],
          source: { kind: 'user' },
        }))
        await agent.whenIdle()
        const text = summarize(agent.session.events, firstSeq)
        return { text: text || '（无回复）' }
      } catch (error) {
        return { text: `错误：${error instanceof Error ? error.message : String(error)}` }
      }
    },
    clearSession(conversationId) {
      const entry = conversations.get(conversationId)
      if (entry) {
        void entry.dispose()
        conversations.delete(conversationId)
      }
    },
  }

  ctx.effect(() => {
    if (!isLoggedIn()) {
      ctx.logger.warn(
        '[dsh-weixin] 未检测到微信登录凭证。请先运行 `npx weixin-acp login` 扫码登录，然后重启 DSH。',
      )
      return
    }
    const controller = new AbortController()
    start(weixinAgent, { abortSignal: controller.signal }).catch((error) => {
      ctx.logger.error('[dsh-weixin] 微信消息循环退出：', error)
    })
    return () => {
      controller.abort()
      for (const entry of conversations.values()) void entry.dispose()
      conversations.clear()
    }
  })
}
