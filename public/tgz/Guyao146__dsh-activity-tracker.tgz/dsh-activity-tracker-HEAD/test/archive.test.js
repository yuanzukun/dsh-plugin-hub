import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { zstdCompressSync } from 'node:zlib'
import { boundedArchiveRecords, buildArchivedSessionDetail, buildArchivedSessions, normalizeSessionId, removeArchivedSessionId, restoreArchivedSession } from '../lib/index.js'

test('normalizes prefixed and bare session ids', () => {
  assert.equal(normalizeSessionId('session-1234-abcd'), 'session-1234-abcd')
  assert.equal(normalizeSessionId('1234-abcd'), 'session-1234-abcd')
  assert.equal(normalizeSessionId('  '), '')
})

test('removes exactly one archived session regardless of id prefix', () => {
  const result = removeArchivedSessionId([
    'session-aaaa-bbbb',
    'cccc-dddd',
    'session-eeee-ffff',
  ], 'session-cccc-dddd')
  assert.equal(result.removed, true)
  assert.deepEqual(result.next, ['session-aaaa-bbbb', 'session-eeee-ffff'])
})

test('reports an already active session without changing archive state', () => {
  const source = ['session-aaaa-bbbb']
  const result = removeArchivedSessionId(source, 'cccc-dddd')
  assert.equal(result.removed, false)
  assert.deepEqual(result.next, source)
})

test('keeps the newest records in chronological order when bounded', () => {
  const records = Array.from({ length: 8 }, (_, index) => ({ seq: index + 1, text: 'row-' + (index + 1) }))
  const result = boundedArchiveRecords(records, 3, 1024)
  assert.equal(result.truncated, true)
  assert.deepEqual(result.records.map((record) => record.seq), [6, 7, 8])
})

test('applies the archive detail text budget without dropping the newest record', () => {
  const records = [
    { seq: 1, text: 'a'.repeat(10) },
    { seq: 2, text: 'b'.repeat(10) },
    { seq: 3, text: 'c'.repeat(10) },
  ]
  const result = boundedArchiveRecords(records, 10, 15)
  assert.equal(result.truncated, true)
  assert.deepEqual(result.records.map((record) => record.seq), [3])
})

test('lists, reads, and restores an archived session without deleting its log', async () => {
  const home = mkdtempSync(join(tmpdir(), 'dsat-archive-'))
  const previousHome = process.env.DSH_HOME
  const id = 'session-11111111-2222-4333-8444-555555555555'
  const directory = join(home, 'sessions', '--test--', id)
  const file = join(directory, 'session.jsonl.zstd')
  mkdirSync(directory, { recursive: true })
  const lines = [
    { type: 'session', cwd: '/tmp/archive-project', createdAt: 1000 },
    { type: 'session/title', time: 1100, data: { title: 'Archived fixture' } },
    { type: 'turn/start', time: 1200, data: {} },
    { type: 'user/message', seq: 1, time: 1300, data: { content: [{ type: 'text', text: 'hello archive' }] } },
    { type: 'assistant/message', seq: 2, time: 1400, data: { message: { content: [{ type: 'text', text: 'restorable reply' }], source: { model: 'fixture-model' } } } },
  ].map((event) => JSON.stringify(event)).join('\n') + '\n'
  writeFileSync(file, zstdCompressSync(Buffer.from(lines)))
  let state = { initialized: true, archivedSessionIds: [id] }
  const registry = {
    requireState: () => state,
    setState: async (next) => { state = next },
  }
  const ctx = { get: (name) => name === 'workspaceRegistry' ? registry : undefined }
  process.env.DSH_HOME = home
  try {
    const list = buildArchivedSessions(ctx)
    assert.equal(list.total, 1)
    assert.equal(list.sessions[0].title, 'Archived fixture')
    const detail = buildArchivedSessionDetail(ctx, id)
    assert.equal(detail.session.records.at(-1).text, 'restorable reply')
    const restored = await restoreArchivedSession(ctx, id)
    assert.deepEqual(restored, { ok: true, sessionId: id, archived: false })
    assert.deepEqual(state.archivedSessionIds, [])
    assert.equal(existsSync(file), true)
  } finally {
    if (previousHome === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previousHome
    rmSync(home, { recursive: true, force: true })
  }
})