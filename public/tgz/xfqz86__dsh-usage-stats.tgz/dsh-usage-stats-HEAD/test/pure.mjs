/**
 * 纯逻辑、账本折叠与协议/偏好逻辑的单测（node:test + 类型剥离直引源码）。
 *
 * 运行 `node --experimental-strip-types test/pure.mjs`（或 `pnpm test:pure`）：直接 import
 * `src/*.ts`，纯模块仅含可擦除类型语法（见 docs/STYLE.md §7）；额度查询的 fetch 经全局 mock，
 * 不产生真实外网请求，快照截断用内存 store、不碰 sqlite。
 *
 * 覆盖范围：
 *   - utils：日期与键（startOfDay/dateKeyOf/splitModelKey）、共享常量、effectiveQuotaTtl 按 min/max 夹取；
 *   - 额度展示与文本：goPercent/goLevelOf/goResetsAt、parseJsonLine/errorMessage/cacheTotal；
 *   - agg 口径：newAgg/ink（reasoning 不计 total、缺字段归零仍计次）、usable 收对话与压缩调用、
 *     拒 assistant/attempt；modelKeyOf 两处取源；
 *   - logs 行解析（坏行跳过不断流）；rawlog 代次识别与多帧 zstd（真实规模、明文、截断尾帧、坏帧）；
 *   - fork 继承前缀：inheritedCountOf/inheritedPrefixOf/liveEventsOf；
 *   - 手写严格贡献：方法表、收发合法拒非法、信封成功/错误分支（含模型明细与单日明细）；
 *   - 命名空间句柄：经 get 取、不暂存 ctx.remote；
 *   - 偏好设置：归一化与夹取、路径写入只带显式字段、表单视图引用稳定、解绑带表单身份
 *     （热重载不误清新表单）、不可用或只读时不发注定被拒的写入、旧 localStorage 迁移
 *     （等表单落定、成功写入才删旧键、不可用时保留）；配置串编解码（与独立 Base64 实现互通、
 *     容错与逐码失败语义、解码归一化、改动字段清单）与整份替换写入（默认值字段 unset、
 *     改动字段 set 且夹取、同一套写入守卫）；服务端条目 schema（字段全 volatile、解析值等于
 *     共享默认值、条目 id 与浏览器端常量一致）；
 *   - stats：格式化 / 会话分组与排序比较 / 时间范围 / 图表几何 / 模型范围与堆叠 / 最近活跃自然日 /
 *     快照构建与截断 / 会话明细聚合 / 模型明细合并 / 模型统计重定向（归一化、归并、候选过滤）；
 *   - 三额度 fixture：无 key、无 plan、非法归一、key 回退、go 缓存单飞。
 */
import { afterEach, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { constants, zstdCompressSync } from 'node:zlib';

import { ink, modelKeyOf, newAgg, usable } from '../src/host/agg.ts';
import { fetchDeepSeekBalance, queryDeepSeekBalance } from '../src/host/deepseekBalance.ts';
import { fetchGoQuota, queryGoQuota } from '../src/host/goquota.ts';
import { parseLine, parseLogLines } from '../src/host/logs.ts';
import { legacySettingsPatch, UsageSettingsSchema } from '../src/host/settings.ts';
import { decodeSessionLog, parseGenerationName, parseSessionLogName, scanZstdFrames } from '../src/host/rawlog.ts';
import { queryUpdateCheck } from '../src/host/update.ts';
import { classifyDependencySpec } from '../src/host/upgrade.ts';
import { METHOD_NAMES, USAGE_STATS_REMOTE } from '../src/remote/contribution.ts';
import {
  CONFIG_TRANSFER_FORMAT,
  CONFIG_TRANSFER_VERSION,
  changedSettingFields,
  decodeConfigTransfer,
  encodeConfigTransfer,
} from '../src/client/configTransfer.ts';
import {
  LEGACY_STORAGE_KEY,
  attachUsageSettings,
  clearLegacySettings,
  detachUsageSettings,
  migrateLegacySettings,
  readLegacySettings,
  replaceUsageSettings,
  replacementOps,
  settingOps,
  subscribeUsageSettings,
  updateUsageSettings,
  usageSettingsView,
} from '../src/client/settings.ts';
import { mountUsageStatsRemote, usageStatsRemote } from '../src/client/remote.ts';
import { createStore, inheritedCountOf, inheritedPrefixOf, liveEventsOf } from '../src/host/store.ts';
import { sessionDetail } from '../src/host/detail.ts';
import { snapshot } from '../src/host/snapshot.ts';
import { fetchZaiQuota } from '../src/host/zaiQuota.ts';
import {
  buildDateStack,
  buildModelStack,
  compareSessionGroup,
  dateRangeCutoff,
  dayTotal,
  filterModelsByRange,
  fmt,
  fmtFull,
  formatLastActive,
  fullDayLabel,
  groupSessions,
  heatGridOf,
  hitRateOfDay,
  lastActiveDayKind,
  mergeModelDetails,
  modelCatalog,
  modelRangeCutoff,
  modelRangeToDays,
  pctOf,
  pieFullCircleOf,
  pieSlicesOf,
  redirectModels,
  resolveRedirectKey,
  sessionGroupIds,
  shortId,
  todayOf,
  unusedRedirectSources,
  usageTotal,
} from '../src/client/stats.ts';
import {
  diffFromDefaults,
  DEEPSEEK_FETCH_DEFAULT_MINUTES,
  DEEPSEEK_FETCH_MIN_MINUTES,
  DAY_MS,
  GO_FETCH_DEFAULT_MINUTES,
  GO_FETCH_MIN_MINUTES,
  MODEL_REDIRECT_MAX_RULES,
  QUOTA_CACHE_TTL_MS,
  QUOTA_MIN_FETCH_MS,
  SERIES_MAX_DAYS,
  USAGE_SETTINGS_DEFAULTS,
  USAGE_SETTINGS_NAMESPACE,
  ZAI_FETCH_DEFAULT_MINUTES,
  ZAI_FETCH_MIN_MINUTES,
  cacheTotal,
  clampDeepSeekFetchMinutes,
  clampGoFetchMinutes,
  clampZaiFetchMinutes,
  dateKeyOf,
  effectiveQuotaTtl,
  errorMessage,
  goLevelOf,
  goPercent,
  goResetsAt,
  isCompleteRedirect,
  isNewerVersion,
  normalizeModelRedirects,
  normalizeUsageSettings,
  parseJsonLine,
  splitModelKey,
  startOfDay,
  updateRelation,
} from '../src/utils.ts';

/** 恢复被 mock 的全局 fetch，避免用例间污染。 */
const realFetch = globalThis.fetch;
afterEach(() => { globalThis.fetch = realFetch; });

/** 把全局 fetch 换成桩，返回 { restore }。 */
function mockFetch(handler) {
  globalThis.fetch = handler;
  return () => { globalThis.fetch = realFetch; };
}

/** 构造最小 fetch Response 桩。 */
const jsonResponse = (status, body) => ({
  status,
  ok: status >= 200 && status < 300,
  json: async () => body,
});

/** 构造凭据中心桩：resolve 恒返回 value。 */
const creds = (value) => ({ resolve: async () => ({ value }) });

/** 构造按序响应的凭据桩：元素为 Error 则抛错，否则返回 { value }（测 key 回退优先级）。 */
function seqCreds(actions) {
  let i = 0;
  return {
    resolve: async () => {
      const a = actions[Math.min(i, actions.length - 1)];
      i += 1;
      if (a instanceof Error) throw a;
      return { value: a };
    },
  };
}

/** 距今天 offset 天的本地零点（offset=0 为今天）。 */
function day(offset) {
  const d = new Date(startOfDay(Date.now()));
  d.setDate(d.getDate() - offset);
  return d.getTime();
}

/** 构造单日序列点。 */
function pt(offset, v, extra) {
  return {
    t: day(offset),
    input: v,
    output: 0,
    cacheRead: 0,
    cacheWrite: 0,
    reasoning: 0,
    calls: 1,
    ...extra,
  };
}

/** 构造会话明细条目。 */
function sess(id, over) {
  return {
    id,
    title: id,
    cwd: '',
    createdAt: 0,
    lastActive: 0,
    calls: 1,
    usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: 0 },
    parentSession: null,
    origin: null,
    delegationDepth: 0,
    ...over,
  };
}

/** 构造聚合计数。 */
function agg(total, calls) {
  return { input: total, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total, calls: calls ?? 1 };
}

describe('utils：日期与键', () => {
  it('startOfDay 落到本地零点且幂等', () => {
    const t = Date.now();
    const z = startOfDay(t);
    const d = new Date(z);
    assert.equal(d.getHours(), 0);
    assert.equal(d.getMinutes(), 0);
    assert.equal(d.getSeconds(), 0);
    assert.equal(d.getMilliseconds(), 0);
    assert.ok(z <= t);
    assert.equal(startOfDay(z), z);
  });

  it('dateKeyOf 为 YYYY-MM-DD', () => {
    const k = dateKeyOf(Date.now());
    assert.match(k, /^\d{4}-\d{2}-\d{2}$/);
  });

  it('splitModelKey 无分隔符时双 unknown', () => {
    assert.deepEqual(splitModelKey('p\0m'), { provider: 'p', model: 'm' });
    assert.deepEqual(splitModelKey('x'), { provider: 'unknown', model: 'unknown' });
    assert.deepEqual(splitModelKey(''), { provider: 'unknown', model: 'unknown' });
  });

  it('共享常量取值', () => {
    assert.equal(SERIES_MAX_DAYS, 366);
    assert.equal(DAY_MS, 86_400_000);
    assert.equal(QUOTA_MIN_FETCH_MS, 3 * 60 * 1000);
    assert.equal(QUOTA_CACHE_TTL_MS, 5 * 60 * 1000);
  });

  it('effectiveQuotaTtl 按 min/max 夹取', () => {
    assert.equal(effectiveQuotaTtl(undefined), 300_000);
    assert.equal(effectiveQuotaTtl(Number.NaN), 300_000);
    assert.equal(effectiveQuotaTtl(1), 180_000);
    assert.equal(effectiveQuotaTtl(0), 180_000);
    assert.equal(effectiveQuotaTtl(5), 300_000);
    assert.equal(effectiveQuotaTtl(10), 300_000);
  });
});

describe('utils：额度与文本', () => {
  it('goPercent 四舍五入并夹取', () => {
    assert.equal(goPercent({ percent: 12.4, resetsAt: '' }), 12);
    assert.equal(goPercent({ percent: 12.5, resetsAt: '' }), 13);
    assert.equal(goPercent({ percent: -5, resetsAt: '' }), 0);
    assert.equal(goPercent({ percent: 120, resetsAt: '' }), 100);
  });

  it('goLevelOf 三档边界', () => {
    assert.equal(goLevelOf(79.9), 'ok');
    assert.equal(goLevelOf(80), 'warn');
    assert.equal(goLevelOf(99.9), 'warn');
    assert.equal(goLevelOf(100), 'over');
  });

  it('goResetsAt 无时间返回空串', () => {
    const t = (k) => `[${k}]`;
    assert.equal(goResetsAt(t, { percent: 0, resetsAt: '' }), '');
    assert.ok(goResetsAt(t, { percent: 0, resetsAt: new Date().toISOString() }).includes('go.resetsAt'));
  });

  it('parseJsonLine 空行坏行回 null', () => {
    assert.equal(parseJsonLine(''), null);
    assert.equal(parseJsonLine('   '), null);
    assert.equal(parseJsonLine('not json'), null);
    assert.deepEqual(parseJsonLine('{"a":1}'), { a: 1 });
  });

  it('errorMessage 三形态', () => {
    assert.equal(errorMessage(new Error('boom')), 'boom');
    assert.equal(errorMessage({ message: 'm' }), 'm');
    assert.equal(errorMessage(42), '42');
  });

  it('cacheTotal 缺省归零', () => {
    assert.equal(cacheTotal({}), 0);
    assert.equal(cacheTotal({ cacheRead: 5 }), 5);
    assert.equal(cacheTotal({ cacheRead: 5, cacheWrite: 7 }), 12);
  });
});

describe('agg：口径', () => {
  it('newAgg 全零', () => {
    assert.deepEqual(newAgg(), { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: 0, calls: 0 });
  });

  it('ink 求和且 reasoning 不计 total', () => {
    const a = newAgg();
    ink(a, { inputTokens: 10, outputTokens: 5, cacheReadTokens: 3, cacheWriteTokens: 2, reasoningTokens: 100 });
    assert.equal(a.total, 20);
    assert.equal(a.reasoning, 100);
    assert.equal(a.calls, 1);
  });

  it('ink 缺字段归零仍计次', () => {
    const a = newAgg();
    ink(a, {});
    assert.equal(a.total, 0);
    assert.equal(a.calls, 1);
  });

  it('usable 放行带 usage 的计量事件（对话与压缩调用）', () => {
    assert.equal(usable({ type: 'assistant/message', data: { usage: {} } }), true);
    assert.equal(usable({ type: 'compaction/summary', data: { usage: {} } }), true);
    assert.equal(usable({ type: 'session' }), false);
    assert.equal(usable({ type: 'assistant/message', data: {} }), false);
    assert.equal(usable({ type: 'assistant/message' }), false);
    assert.equal(usable({ type: 'compaction/summary', data: {} }), false);
    assert.equal(usable({ type: 'compaction/summary' }), false);
    // assistant/attempt 的用量是流式中间态，会与同 turn 的 assistant/message 重复，不收
    assert.equal(usable({ type: 'assistant/attempt', data: { usage: {} } }), false);
  });

  it('modelKeyOf 缺失记 unknown', () => {
    assert.equal(modelKeyOf({ type: 'assistant/message', data: { message: { source: { provider: 'p', model: 'm' } } } }), 'p\0m');
    assert.equal(modelKeyOf({ type: 'assistant/message', data: {} }), 'unknown\0unknown');
    assert.equal(modelKeyOf({ type: 'assistant/message', data: { message: { source: { provider: '', model: '' } } } }), 'unknown\0unknown');
    // 压缩调用的模型身份在 data.provider/data.model，不在 message.source
    assert.equal(modelKeyOf({ type: 'compaction/summary', data: { provider: 'opencode-go', model: 'deepseek-v4-flash' } }), 'opencode-go\0deepseek-v4-flash');
    assert.equal(modelKeyOf({ type: 'compaction/summary', data: {} }), 'unknown\0unknown');
  });
});

describe('logs：行解析', () => {
  it('parseLine 非对象与坏行回 null', () => {
    assert.equal(parseLine(''), null);
    assert.equal(parseLine('x'), null);
    assert.equal(parseLine('{"a":1}'), null);
    assert.deepEqual(parseLine('{"type":"session"}'), { type: 'session' });
  });

  it('parseLogLines 跳坏行不断流', () => {
    const out = parseLogLines('{"type":"a"}\nbad\n\n{"type":"b"}');
    assert.equal(out.length, 2);
  });
});

/** 压缩一段文本为一帧：与 harness 一致带 checksum，覆盖帧头 checksum 分支。 */
const zstdFrame = (text) => zstdCompressSync(Buffer.from(text, 'utf8'), {
  params: { [constants.ZSTD_c_checksumFlag]: 1 },
});

describe('rawlog：代次识别与多帧 zstd 解码', () => {
  it('parseGenerationName 识别全代次，非规范名 -1', () => {
    assert.equal(parseGenerationName('session.jsonl.zstd'), 0);
    assert.equal(parseGenerationName('session.v2.jsonl.zstd'), 2);
    assert.equal(parseGenerationName('session.v3.jsonl.zstd'), 3);
    assert.equal(parseGenerationName('session.jsonl'), 0);
    assert.equal(parseGenerationName('session.v1.jsonl'), 1);
    assert.equal(parseGenerationName('session.v12.jsonl.zstd'), 12);
    for (const bad of [
      'session.lock', 'session.v0.jsonl.zstd', 'session.v01.jsonl.zstd',
      'SESSION.V2.JSONL.ZSTD', 'session.jsonl.zstd.tmp', 'notes.txt', '',
    ]) {
      assert.equal(parseGenerationName(bad), -1, bad);
    }
    assert.deepEqual(parseSessionLogName('session.v2.jsonl.zstd'), { generation: 2, compression: 'zstd' });
    assert.deepEqual(parseSessionLogName('session.jsonl'), { generation: 0, compression: 'none' });
    assert.equal(parseSessionLogName('session.lock'), null);
  });

  it('单帧解码等于原文，帧数 1', () => {
    const text = '{"type":"session","id":"s"}\n{"type":"assistant/message"}\n';
    const buffer = zstdFrame(text);
    assert.equal(decodeSessionLog(buffer, 'zstd'), text);
    assert.equal(scanZstdFrames(buffer).frames.length, 1);
    assert.equal(scanZstdFrames(buffer).tornStart, undefined);
  });

  it('多帧拼接逐帧解压得到完整文本', () => {
    const chunks = [
      '{"type":"session","id":"s"}\n',
      '{"type":"assistant/message","i":1}\n',
      '{"type":"assistant/message","i":2}\n{"type":"assistant/message","i":3}\n',
    ];
    const buffer = Buffer.concat(chunks.map(zstdFrame));
    assert.equal(decodeSessionLog(buffer, 'zstd'), chunks.join(''));
    assert.equal(scanZstdFrames(buffer).frames.length, chunks.length);
    // 帧区间连续覆盖整个文件且互不重叠
    const scan = scanZstdFrames(buffer);
    assert.equal(scan.frames[0].start, 0);
    assert.equal(scan.frames.at(-1).end, buffer.length);
    for (let i = 1; i < scan.frames.length; i += 1) {
      assert.equal(scan.frames[i].start, scan.frames[i - 1].end);
    }
  });

  it('真实规模形态：1400 段逐帧追加，解出行数一致', () => {
    // 模拟 harness append-only 写入：每帧若干条事件，首帧为会话头。
    const chunks = ['{"type":"session","id":"s"}\n'];
    for (let i = 1; i < 1400; i += 1) chunks.push(`{"type":"assistant/message","i":${i}}\n`);
    const buffer = Buffer.concat(chunks.map(zstdFrame));
    const scan = scanZstdFrames(buffer);
    assert.equal(scan.frames.length, 1400);
    const text = decodeSessionLog(buffer, 'zstd');
    assert.equal(text, chunks.join(''));
    assert.equal(text.split('\n').filter(Boolean).length, 1400);
  });

  it('未压缩明文原样返回，含中文多字节', () => {
    const text = '{"type":"session","title":"中文标题"}\n{"type":"assistant/message"}\n';
    assert.equal(decodeSessionLog(Buffer.from(text, 'utf8'), 'none'), text);
  });

  it('截断尾帧按 harness 语义只保留完整部分', () => {
    const a = '{"type":"session","id":"s"}\n';
    const b = '{"type":"assistant/message","i":1}\n{"type":"assistant/message","i":2}\n';
    const frameA = zstdFrame(a);
    const frameB = zstdFrame(b);
    // 尾帧 payload 被切断：该帧一个 block 都不完整，整帧丢弃
    const cutPayload = Buffer.concat([frameA, frameB.subarray(0, frameB.length - 12)]);
    assert.equal(decodeSessionLog(cutPayload, 'zstd'), a);
    assert.equal(scanZstdFrames(cutPayload).tornStart, frameA.length);
    // 尾帧仅缺 checksum：payload 完整，按 harness 迁移语义恢复明文
    const cutChecksum = Buffer.concat([frameA, frameB.subarray(0, frameB.length - 3)]);
    assert.equal(decodeSessionLog(cutChecksum, 'zstd'), a + b);
    // 只有不完整首帧：不抛错，返回空串
    const tornOnly = frameA.subarray(0, 8);
    assert.equal(scanZstdFrames(tornOnly).tornStart, 0);
    assert.equal(decodeSessionLog(tornOnly, 'zstd'), '');
  });

  it('空文件返回空串，坏帧抛错', () => {
    assert.equal(decodeSessionLog(Buffer.alloc(0), 'zstd'), '');
    assert.deepEqual(scanZstdFrames(Buffer.alloc(0)).frames, []);
    const badMagic = Buffer.from([0, 1, 2, 3]);
    assert.throws(() => scanZstdFrames(badMagic), /invalid frame magic at byte 0/);
    assert.throws(() => decodeSessionLog(badMagic, 'zstd'), /invalid frame magic at byte 0/);
    // 完整帧后跟坏 magic：结构非法，同 harness 语义抛错
    const trailingGarbage = Buffer.concat([zstdFrame('{"type":"a"}\n'), Buffer.from([9, 9, 9, 9])]);
    assert.throws(() => scanZstdFrames(trailingGarbage), /invalid frame magic at byte /);
    // 完整帧被篡改：帧校验失败抛错
    const tampered = Buffer.from(zstdFrame('{"type":"a"}\n'));
    tampered[tampered.length - 6] ^= 0xFF;
    assert.throws(() => decodeSessionLog(tampered, 'zstd'), /failed validation/);
  });
});

describe('fork 继承前缀：只折本会话自有事件', () => {
  it('inheritedPrefixOf 取最后一个 inherited 标记之后偏移一位', () => {
    const records = [
      { type: 'session', id: 'child', parentSession: 'parent' },
      { type: 'assistant/message', seq: 0 },
      { type: 'session/end-seed', seq: 1, data: { inherited: true } },
      { type: 'assistant/message', seq: 2 },
    ];
    assert.equal(inheritedPrefixOf(records), 2);
    // 无标记（普通会话）与自身 seed（resume，inherited 非 true）都不算继承
    assert.equal(inheritedPrefixOf([{ type: 'assistant/message', seq: 0 }]), 0);
    assert.equal(inheritedPrefixOf([{ type: 'session/end-seed', seq: 3, data: {} }]), 0);
    assert.equal(inheritedPrefixOf([]), 0);
    // 多个标记取最大 seq，坏记录跳过
    assert.equal(inheritedPrefixOf([null, 7, { type: 'session/end-seed', seq: 5, data: { inherited: true } }, { type: 'session/end-seed', seq: 3, data: { inherited: true } }]), 6);
  });

  it('liveEventsOf 丢继承前缀，保留无 seq 的 header 记录', () => {
    const records = [
      { type: 'session', id: 'child' },
      { type: 'assistant/message', seq: 0, data: { usage: { inputTokens: 1 } } },
      { type: 'session/end-seed', seq: 1, data: { inherited: true } },
      { type: 'assistant/message', seq: 2, data: { usage: { inputTokens: 9 } } },
    ];
    const live = liveEventsOf(records, 2);
    assert.deepEqual(live.map((r) => r.seq ?? 'header'), ['header', 2]);
    // inherited 为 0 时原样返回，不做拷贝
    assert.equal(liveEventsOf(records, 0), records);
  });

  it('inheritedCountOf 归一 harness 元数据', () => {
    assert.equal(inheritedCountOf(3), 3);
    assert.equal(inheritedCountOf(0), 0);
    assert.equal(inheritedCountOf(undefined), 0);
    assert.equal(inheritedCountOf(-2), 0);
    assert.equal(inheritedCountOf(Number.NaN), 0);
    assert.equal(inheritedCountOf('4'), 4);
  });
});

describe('remote：手写严格贡献', () => {
  it('12 个一元方法与服务一致', () => {
    assert.deepEqual([...METHOD_NAMES], [
      'snapshot', 'modelDetail', 'dateDetail', 'sessionDetail', 'rebuild', 'clear', 'seal', 'goQuota', 'deepseekBalance', 'zaiQuota', 'checkUpdate', 'upgrade',
    ]);
    assert.equal(USAGE_STATS_REMOTE.package, '@xfqz86/dsh-usage-stats');
    assert.deepEqual(
      USAGE_STATS_REMOTE.descriptors.map((d) => d.method),
      [...METHOD_NAMES],
    );
    for (const d of USAGE_STATS_REMOTE.descriptors) {
      assert.equal(d.service, 'usageStats');
      assert.equal(d.namespace, 'usageStats');
      assert.deepEqual(d.invocation, { kind: 'direct' });
      assert.equal(d.cancellation, undefined);
      for (const p of d.parameters) assert.equal(p.codec.mode, 'strict');
      assert.equal(d.result.mode, 'strict');
    }
  });

  it('更新检查请求与结果 schema 收发合法、拒非法', () => {
    const check = USAGE_STATS_REMOTE.descriptors.find((d) => d.method === 'checkUpdate');
    assert.ok(check && check.parameters.length === 1);
    const codec = check.parameters[0].codec;
    if (codec.mode !== 'strict') throw new Error('unreachable');
    const schema = codec.create();
    schema.parse({});
    schema.parse({ force: true });
    assert.throws(() => schema.parse({ force: 'yes' }));
    const result = check.result.create();
    const ok = { status: 'ok', latest: '0.6.0', url: 'https://example.com/v0.6.0', notes: '## 新增\n- 一键升级', publishedAt: 1_790_000_000_000, install: 'npm' };
    result.parse({ ok: true, value: ok });
    result.parse({ ok: true, value: { status: 'error', latest: null, url: 'https://example.com/releases', notes: null, publishedAt: null, install: 'local' } });
    // 判别联合收紧：ok 必须带版本号，error 的 latest 必须为 null；新增字段必须齐全。
    assert.throws(() => result.parse({ ok: true, value: { ...ok, latest: null } }));
    assert.throws(() => result.parse({ ok: true, value: { ...ok, install: 'other' } }));
    assert.throws(() => result.parse({ ok: true, value: { ...ok, notes: 1 } }));
    assert.throws(() => result.parse({ ok: true, value: { status: 'error', latest: null, url: 'https://example.com' } }));
  });

  it('升级请求与结果 schema 收发合法、拒非法', () => {
    const upgrade = USAGE_STATS_REMOTE.descriptors.find((d) => d.method === 'upgrade');
    assert.ok(upgrade && upgrade.parameters.length === 1);
    const codec = upgrade.parameters[0].codec;
    if (codec.mode !== 'strict') throw new Error('unreachable');
    const schema = codec.create();
    schema.parse({ version: '0.6.0' });
    assert.throws(() => schema.parse({}));
    assert.throws(() => schema.parse({ version: 1 }));
    const result = upgrade.result.create();
    result.parse({ ok: true, value: { status: 'ok', version: '0.6.0', restartRequired: true, reason: null } });
    result.parse({ ok: true, value: { status: 'error', version: '0.6.0', restartRequired: false, reason: 'network' } });
    assert.throws(() => result.parse({ ok: true, value: { status: 'ok', version: '0.6.0', restartRequired: false, reason: null } }));
    assert.throws(() => result.parse({ ok: true, value: { status: 'error', version: '0.6.0', restartRequired: false, reason: 'other' } }));
  });

  it('请求 schema 收发合法、拒非法', () => {
    const snap = USAGE_STATS_REMOTE.descriptors.find((d) => d.method === 'snapshot');
    assert.ok(snap && snap.parameters.length === 1);
    const codec = snap.parameters[0].codec;
    assert.equal(codec.mode, 'strict');
    if (codec.mode !== 'strict') throw new Error('unreachable');
    // 双形态都指向同一份 zod 定义：schema 供已发布版，create 供 checkout 新版。
    const schema = codec.create();
    assert.equal(schema, codec.schema);
    schema.parse({ sessionId: null });
    schema.parse({ sessionId: 's-1', limit: 500 });
    assert.throws(() => schema.parse({ sessionId: 42 }));
    assert.throws(() => schema.parse({ sessionId: null, limit: 'x' }));
  });

  it('模型明细请求与结果 schema 收发合法、拒非法', () => {
    const detail = USAGE_STATS_REMOTE.descriptors.find((d) => d.method === 'modelDetail');
    assert.ok(detail && detail.parameters.length === 1);
    const codec = detail.parameters[0].codec;
    assert.equal(codec.mode, 'strict');
    if (codec.mode !== 'strict') throw new Error('unreachable');
    const schema = codec.create();
    assert.equal(schema, codec.schema);
    schema.parse({ provider: 'p', model: 'm' });
    schema.parse({ provider: 'p', model: 'm', since: 1_700_000_000_000 });
    assert.throws(() => schema.parse({ model: 'm' }));
    assert.throws(() => schema.parse({ provider: 'p' }));
    assert.throws(() => schema.parse({ provider: 'p', model: 'm', since: 'x' }));
    // 结果缺字段整条被拒：host 必须字段齐全，不能少下发 sessions/daily
    const result = detail.result.create();
    assert.throws(() => result.parse({ ok: true, value: { provider: 'p', model: 'm' } }));
  });

  it('单日明细请求与结果 schema 收发合法、拒非法', () => {
    const detail = USAGE_STATS_REMOTE.descriptors.find((d) => d.method === 'dateDetail');
    assert.ok(detail && detail.parameters.length === 1);
    const codec = detail.parameters[0].codec;
    assert.equal(codec.mode, 'strict');
    if (codec.mode !== 'strict') throw new Error('unreachable');
    const schema = codec.create();
    assert.equal(schema, codec.schema);
    // day 只有本地日零点一种取值，非法值应在服务端归一，线路层只认数字。
    schema.parse({ day: 1_700_000_000_000 });
    assert.throws(() => schema.parse({}));
    assert.throws(() => schema.parse({ day: '2026-08-17' }));
    // 结果缺字段整条被拒：host 必须字段齐全，不能少下发 models/sessions
    const result = detail.result.create();
    assert.throws(() => result.parse({ ok: true, value: { day: 0, calls: 0 } }));
    const usage = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: 0 };
    result.parse({ ok: true, value: { day: 1_700_000_000_000, calls: 0, usage, models: [], sessions: [] } });
    // 模型行可省 series（单日不下发按日序列），但其余字段缺一即拒
    result.parse({
      ok: true,
      value: {
        day: 1_700_000_000_000,
        calls: 1,
        usage,
        models: [{ provider: 'p', model: 'm', calls: 1, usage }],
        sessions: [],
      },
    });
    assert.throws(() => result.parse({ ok: true, value: { day: 1, calls: 1, usage, models: [{ provider: 'p' }], sessions: [] } }));
  });

  it('会话明细请求与结果 schema 收发合法、拒非法', () => {
    const detail = USAGE_STATS_REMOTE.descriptors.find((d) => d.method === 'sessionDetail');
    assert.ok(detail && detail.parameters.length === 1);
    const codec = detail.parameters[0].codec;
    assert.equal(codec.mode, 'strict');
    if (codec.mode !== 'strict') throw new Error('unreachable');
    const schema = codec.create();
    assert.equal(schema, codec.schema);
    // 集合语义在服务端归一（去重、非字符串丢弃、未知 id 按 0），线路层只认字符串数组。
    schema.parse({ sessionIds: [] });
    schema.parse({ sessionIds: ['s-1', 's-2'] });
    assert.throws(() => schema.parse({}));
    assert.throws(() => schema.parse({ sessionIds: 's-1' }));
    assert.throws(() => schema.parse({ sessionIds: [1] }));
    // 结果缺字段整条被拒：host 必须字段齐全，不能少下发 daily/models/usage
    const result = detail.result.create();
    assert.throws(() => result.parse({ ok: true, value: { calls: 0 } }));
    const usage = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: 0 };
    result.parse({ ok: true, value: { calls: 0, usage, daily: [], models: [] } });
    // 模型行可省 series（会话明细不画该模型的按日图），但其余字段缺一即拒
    result.parse({
      ok: true,
      value: {
        calls: 1,
        usage,
        daily: [{ t: 1_700_000_000_000, input: 1, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, calls: 1 }],
        models: [{ provider: 'p', model: 'm', calls: 1, usage }],
      },
    });
    assert.throws(() => result.parse({ ok: true, value: { calls: 1, usage, daily: [], models: [{ provider: 'p' }] } }));
  });

  it('结果信封成功分支严格、错误分支透传', () => {
    const quota = USAGE_STATS_REMOTE.descriptors.find((d) => d.method === 'goQuota');
    assert.ok(quota);
    assert.equal(quota.result.mode, 'strict');
    if (quota.result.mode !== 'strict') throw new Error('unreachable');
    const schema = quota.result.create();
    assert.equal(schema, quota.result.schema);
    // 成功分支缺字段必须拒绝（值分支精确）。
    assert.throws(() => schema.parse({ ok: true, value: {} }));
    // 错误分支接受已知码与未知码（网关透传不断信封解析）。
    schema.parse({ ok: false, error: { code: 'usageStats/busy', message: 'busy', details: { operation: 'rebuild' } } });
    schema.parse({ ok: false, error: { code: 'gateway/internal', message: 'boom', details: {} } });
  });
});

describe('remote句柄：经 get 取命名空间服务', () => {
  it('不暂存 ctx.remote：子 scope 里对暂存句柄的属性访问报 without-inject', async () => {
    // 命名空间服务桩：只有 get 能拿到，remote 上故意不挂 usageStats 属性。
    const ns = { snapshot: async () => ({ ok: true, value: {} }) };
    let alive = false;
    const fakeCtx = {
      remote: { $mount: async () => { alive = true; return async () => { alive = false; }; } },
      get: (key) => (alive && key === 'remote.usageStats' ? ns : undefined),
    };
    assert.throws(() => usageStatsRemote(), /not mounted yet/);
    const dispose = await mountUsageStatsRemote(fakeCtx);
    // 若实现改回暂存 ctx.remote 再读 .usageStats，这里拿到的是 undefined。
    assert.equal(usageStatsRemote(), ns);
    await dispose();
    assert.throws(() => usageStatsRemote(), /not mounted yet/);
  });
});

describe('stats：格式化', () => {
  const en = () => '';
  it('fmt 中英紧凑', () => {
    assert.equal(fmt(null), '--');
    assert.equal(fmt(Number.NaN), '--');
    assert.equal(fmt(999), '999');
    assert.equal(fmt(1500, 'en'), '1.5K');
    assert.equal(fmt(1500, 'zh'), '1500');
    assert.equal(fmt(25_000, 'zh'), '2.5万');
    assert.equal(fmt(250_000_000, 'zh'), '2.5亿');
    assert.equal(fmt(2_000_000_000, 'en'), '2B');
    assert.equal(fmt(1500, en), '1.5K');
  });

  it('fmtFull 千分位与缺省', () => {
    assert.equal(fmtFull(1234567), '1,234,567');
    assert.equal(fmtFull(null), '--');
  });

  it('shortId 与 pctOf', () => {
    assert.equal(shortId(''), '--');
    assert.equal(shortId('short'), 'short');
    assert.equal(shortId('abcdefghij1234'), 'abcdef…1234');
    assert.equal(pctOf(12.5), '12.5%');
    assert.equal(pctOf(null), '--');
    assert.equal(pctOf(Number.NaN), '--');
  });

  it('dayTotal/usageTotal 缺省归零', () => {
    assert.equal(dayTotal({}), 0);
    assert.equal(dayTotal({ input: 1, cacheRead: 2 }), 3);
    assert.equal(usageTotal({ total: 7 }), 7);
    assert.equal(usageTotal(undefined), 0);
  });

  it('hitRateOfDay 分母零断开', () => {
    assert.equal(hitRateOfDay({}), null);
    assert.equal(hitRateOfDay({ input: 0, cacheRead: 0 }), null);
    assert.equal(hitRateOfDay({ input: 1, cacheRead: 3 }), 75);
  });

  it('formatLastActive 今天/昨天/更早与未知', () => {
    const t = (key) => (key === 'time.today' ? '今天' : key === 'time.yesterday' ? '昨天' : key);
    const today = new Date();
    today.setHours(9, 0, 0, 0);
    const yesterday = new Date(startOfDay(Date.now()));
    yesterday.setDate(yesterday.getDate() - 1);
    yesterday.setHours(20, 5, 0, 0);
    assert.equal(formatLastActive(today.getTime(), t), '今天 09:00');
    assert.equal(formatLastActive(yesterday.getTime(), t), '昨天 20:05');
    assert.equal(formatLastActive(new Date(2020, 0, 2, 3, 4).getTime(), t), '2020-01-02');
    assert.equal(formatLastActive(0, t), '--');
  });
});

describe('stats：会话分组', () => {
  it('子代理折叠到主会话并汇总', () => {
    const groups = groupSessions([
      sess('m1', { lastActive: 2, calls: 2, usage: agg(20, 2) }),
      sess('c1', { lastActive: 3, calls: 3, usage: agg(30, 3), parentSession: 'm1', origin: 'subagent', delegationDepth: 1 }),
    ]);
    assert.equal(groups.length, 1);
    assert.equal(groups[0].childCount, 1);
    assert.equal(groups[0].agg.calls, 5);
    assert.equal(groups[0].agg.usage.total, 50);
  });

  it('孤儿回落顶层', () => {
    const groups = groupSessions([
      sess('m1', { lastActive: 1 }),
      sess('c2', { lastActive: 2, parentSession: 'missing', origin: 'subagent', delegationDepth: 1 }),
    ]);
    assert.equal(groups.length, 2);
    assert.equal(groups[0].main.id, 'c2');
  });

  it('多级展平到根', () => {
    const groups = groupSessions([
      sess('m1', { lastActive: 1 }),
      sess('c1', { lastActive: 2, parentSession: 'm1', origin: 'subagent', delegationDepth: 1 }),
      sess('g', { lastActive: 3, parentSession: 'c1', origin: 'subagent', delegationDepth: 2 }),
    ]);
    assert.equal(groups.length, 1);
    assert.equal(groups[0].childCount, 2);
    assert.deepEqual(groups[0].children.map((c) => c.id), ['g', 'c1']);
  });

  it('成环不死循环', () => {
    const groups = groupSessions([
      sess('a', { lastActive: 1, parentSession: 'b', origin: 'subagent', delegationDepth: 1 }),
      sess('b', { lastActive: 2, parentSession: 'a', origin: 'subagent', delegationDepth: 1 }),
    ]);
    assert.equal(groups.length, 2);
  });

  it('sessionGroupIds 给出折叠集合：主会话 + 展平的全部子代理', () => {
    const groups = groupSessions([
      sess('m1', { lastActive: 1 }),
      sess('c1', { lastActive: 2, parentSession: 'm1', origin: 'subagent', delegationDepth: 1 }),
      sess('g', { lastActive: 3, parentSession: 'c1', origin: 'subagent', delegationDepth: 2 }),
    ]);
    assert.equal(groups.length, 1);
    // 子按 lastActive 降序（g 在 c1 前），集合含主会话与两级子代理
    assert.deepEqual(sessionGroupIds(groups[0]), ['m1', 'g', 'c1']);
  });
});

describe('stats：会话表排序比较', () => {
  // 面板会话 Tab 与模型明细的按会话表共用同一比较实现，这里锁住「同一列同一顺序」的口径
  const groups = groupSessions([
    sess('a', { title: 'Alpha', lastActive: 100, calls: 4, usage: agg(40, 4) }),
    sess('ac', { title: 'Child', lastActive: 300, calls: 6, usage: agg(60, 6), parentSession: 'a', origin: 'subagent', delegationDepth: 1 }),
    sess('b', { title: 'Beta', lastActive: 200, calls: 5, usage: agg(10, 5) }),
  ]);
  const a = groups.find((g) => g.main.id === 'a');
  const b = groups.find((g) => g.main.id === 'b');

  it('数值列取折叠后的分组合计', () => {
    assert.ok(a !== undefined && b !== undefined);
    assert.ok(compareSessionGroup('calls', a, b) > 0); // 10 vs 5
    assert.ok(compareSessionGroup('total', a, b) > 0); // 100 vs 10
    assert.ok(compareSessionGroup('input', a, b) > 0); // 100 vs 10
    assert.ok(compareSessionGroup('avg', a, b) > 0); // 每次调用 10 vs 2
  });

  it('文本列按标题、最近活跃按主会话时间', () => {
    assert.ok(a !== undefined && b !== undefined);
    assert.ok(compareSessionGroup('session', a, b) < 0); // Alpha < Beta
    assert.ok(compareSessionGroup('lastActive', a, b) < 0); // 主行 100 < 200，子会话的 300 不参与主行排序
  });
});

describe('stats：时间范围', () => {
  it('todayOf 取今日点', () => {
    assert.equal(todayOf([pt(1, 1), pt(0, 9)]).input, 9);
    assert.equal(todayOf([pt(2, 1), pt(1, 2)]), undefined);
  });

  it('modelRange 映射与 dateRange 复用', () => {
    assert.equal(modelRangeToDays('7d'), 7);
    assert.equal(modelRangeToDays('all'), null);
    const cutoff = modelRangeCutoff('7d');
    assert.equal(cutoff, startOfDay(cutoff));
    assert.equal(Math.round((startOfDay(Date.now()) - cutoff) / DAY_MS), 6);
    assert.equal(modelRangeCutoff('all'), null);
    assert.equal(dateRangeCutoff('all'), null);
  });
});

describe('stats：图表几何', () => {
  it('heatGridOf 空序列与今日格', () => {
    const g = heatGridOf([], 26);
    assert.equal(g.cols, 26);
    assert.equal(g.cells.length, 182);
    assert.equal(g.months.length, 26);
    assert.equal(g.cells.filter((c) => c.today).length, 1);
    assert.ok(g.cells.every((c) => c.lvl === 0));
    assert.equal(g.cells.find((c) => c.today).label, fullDayLabel(startOfDay(Date.now())));
  });

  it('heatGridOf 强度分四档', () => {
    const g = heatGridOf([pt(0, 100), pt(1, 10)], 2);
    const lvls = g.cells.map((c) => c.lvl);
    assert.ok(lvls.every((l) => l >= 0 && l <= 4));
    assert.equal(Math.max(...lvls), 4);
  });

  it('pieSlicesOf 最大余数总和 100', () => {
    const models = ['a', 'b', 'c'].map((m) => ({ provider: 'p', model: m, calls: 1, usage: agg(1, 1) }));
    const slices = pieSlicesOf(models);
    assert.equal(slices.length, 3);
    const sum = slices.reduce((s, x) => s + x.share, 0);
    assert.ok(Math.abs(sum - 100) < 1e-9);
    assert.deepEqual(pieSlicesOf([]), []);
  });

  it('pieFullCircleOf 单切片整圆', () => {
    const slices = pieSlicesOf([{ provider: 'p', model: 'only', calls: 1, usage: agg(5, 1) }]);
    assert.equal(pieFullCircleOf(slices), slices[0]);
    assert.equal(pieFullCircleOf([]), null);
  });
});

describe('stats：模型范围过滤与堆叠', () => {
  const mk = (id, series) => ({ provider: 'p', model: id, calls: series.length, usage: agg(series.reduce((s, x) => s + x.input, 0), series.length), series });

  it('all 原样排序，范围按 cutoff 过滤', () => {
    const old = pt(30, 100);
    const rec = pt(1, 10);
    const models = [mk('m1', [old, rec]), mk('m2', [rec])];
    assert.deepEqual(filterModelsByRange(models, 'all').map((m) => m.model), ['m1', 'm2']);
    const f = filterModelsByRange(models, '7d');
    assert.equal(f.length, 2);
    assert.equal(f[0].usage.total, 10);
    assert.equal(f[0].series.length, 1);
  });

  it('无细分旧快照在范围模式下跳过', () => {
    const models = [mk('m1', []), mk('m2', [pt(0, 5)])];
    assert.equal(filterModelsByRange(models, '7d').length, 1);
    assert.equal(filterModelsByRange(models, 'all').length, 2);
  });

  it('buildModelStack 形态与 all 上限 366', () => {
    const series = [];
    for (let i = 399; i >= 0; i -= 1) series.push(pt(i, 1));
    const stack = buildModelStack([mk('m1', series)], 'all');
    assert.equal(stack.days.length, 366);
    assert.ok(stack.maxTotal >= 1);
    assert.ok(stack.days.every((d) => d.segments.length > 0));
  });

  it('buildDateStack all 空回空，上限 366', () => {
    assert.deepEqual(buildDateStack([], 'all'), { days: [], maxTotal: 1 });
    const series = [];
    for (let i = 399; i >= 0; i -= 1) series.push(pt(i, 2));
    const stack = buildDateStack(series, 'all');
    assert.equal(stack.days.length, 366);
  });

  it('buildDateStack 7d 三段与命中率一致', () => {
    const stack = buildDateStack([pt(0, 4, { cacheRead: 12 })], '7d');
    assert.equal(stack.days.length, 7);
    const last = stack.days[6];
    assert.equal(last.segments.length, 2);
    assert.equal(hitRateOfDay(last), 75);
  });
});

describe('模型统计重定向：规则归一化', () => {
  const rule = (fromProvider, fromModel, toProvider, toModel) => ({ fromProvider, fromModel, toProvider, toModel });

  it('非数组、坏元素一律回退空表', () => {
    for (const bad of [undefined, null, 'x', 42, {}, [{}, null, 1, 'a', [], []]]) {
      assert.deepEqual(normalizeModelRedirects(bad), []);
    }
  });

  it('四字段取字符串并去首尾空白，非字符串记空串', () => {
    assert.deepEqual(
      normalizeModelRedirects([{ fromProvider: ' p1 ', fromModel: 'm1', toProvider: 1, toModel: null }]),
      [rule('p1', 'm1', '', '')],
    );
  });

  it('四项全空的条目丢弃，半填条目保留，超过上限截断', () => {
    assert.deepEqual(
      normalizeModelRedirects([{}, rule('', '', '', ''), rule('p1', '', '', '')]),
      [rule('p1', '', '', '')],
    );
    assert.equal(MODEL_REDIRECT_MAX_RULES, 50);
    const many = Array.from({ length: MODEL_REDIRECT_MAX_RULES + 5 }, (_, i) => rule(`p${i}`, 'm', 't', 'm'));
    assert.equal(normalizeModelRedirects(many).length, MODEL_REDIRECT_MAX_RULES);
  });

  it('完整性判定：四项都非空才参与归并', () => {
    assert.equal(isCompleteRedirect(rule('p', 'm', 't', 'n')), true);
    assert.equal(isCompleteRedirect(rule('p', '', 't', 'n')), false);
    assert.equal(isCompleteRedirect(rule('', 'm', 't', 'n')), false);
    assert.equal(isCompleteRedirect(rule('p', 'm', '', 'n')), false);
    assert.equal(isCompleteRedirect(rule('p', 'm', 't', '')), false);
  });

  it('偏好归一化贯通规则表，坏值回退空表', () => {
    assert.deepEqual(normalizeUsageSettings({}).modelRedirects, []);
    assert.deepEqual(normalizeUsageSettings({ modelRedirects: 'x' }).modelRedirects, []);
    assert.deepEqual(
      normalizeUsageSettings({ modelRedirects: [{ fromProvider: ' p ', fromModel: 'm', toProvider: 't', toModel: 'n' }] }).modelRedirects,
      [rule('p', 'm', 't', 'n')],
    );
  });
});

describe('模型统计重定向：归并', () => {
  const rule = (fromProvider, fromModel, toProvider, toModel) => ({ fromProvider, fromModel, toProvider, toModel });
  /** 构造模型行：usage 由四段之和得出 total，series 默认给一段今天的用量。 */
  const model = (provider, name, { input = 0, output = 0, cacheRead = 0, cacheWrite = 0, reasoning = 0, calls = 0, series = [] } = {}) => ({
    provider,
    model: name,
    calls,
    usage: { input, output, cacheRead, cacheWrite, reasoning, total: input + output + cacheRead + cacheWrite },
    series,
  });

  it('无规则时原样返回入参数组，来源表为空', () => {
    const models = [model('p1', 'a', { input: 10 }), model('p2', 'b', { input: 5 })];
    const out = redirectModels(models, []);
    assert.equal(out.models, models);
    assert.deepEqual([...out.mergedSources], []);
  });

  it('规则一条都没命中时同样原样返回', () => {
    const models = [model('p1', 'a', { input: 10 })];
    const out = redirectModels(models, [rule('p9', 'x', 'p1', 'a')]);
    assert.equal(out.models, models);
    assert.deepEqual([...out.mergedSources], []);
  });

  it('跨供应商同名模型并成一行：用量、调用数与日序列求和', () => {
    const models = [
      model('opencode-go', 'deepseek-v4-flash', { input: 100, output: 10, calls: 2, series: [{ ...pt(0, 100), output: 10, calls: 2 }] }),
      model('opencode-go-vision', 'deepseek-v4-flash', { input: 50, output: 5, calls: 1, series: [{ ...pt(0, 50), output: 5, calls: 1 }, pt(1, 1)] }),
    ];
    const out = redirectModels(models, [rule('opencode-go-vision', 'deepseek-v4-flash', 'opencode-go', 'deepseek-v4-flash')]);
    assert.equal(out.models.length, 1);
    assert.equal(out.models[0].provider, 'opencode-go');
    assert.equal(out.models[0].model, 'deepseek-v4-flash');
    assert.equal(out.models[0].usage.total, 165);
    assert.equal(out.models[0].usage.output, 15);
    assert.equal(out.models[0].calls, 3);
    // 日序列按天求和，且按时间升序（series[0] 是更早的那天）
    assert.equal(out.models[0].series.length, 2);
    assert.equal(out.models[0].series[0].input, 1);
    assert.equal(out.models[0].series[0].calls, 1);
    assert.equal(out.models[0].series[1].input, 150);
    assert.equal(out.models[0].series[1].calls, 3);
    assert.ok(out.models[0].series[0].t < out.models[0].series[1].t);
    assert.deepEqual(
      out.mergedSources.get('opencode-go\u0000deepseek-v4-flash'),
      ['opencode-go-vision\u0000deepseek-v4-flash'],
    );
  });

  it('链式规则一路解析到链尾，环内折到最靠前那条规则的目标', () => {
    const chain = [model('p', 'a', { input: 1 }), model('p', 'b', { input: 2 }), model('p', 'c', { input: 4 })];
    const chained = redirectModels(chain, [rule('p', 'a', 'p', 'b'), rule('p', 'b', 'p', 'c')]);
    assert.equal(chained.models.length, 1);
    assert.equal(chained.models[0].model, 'c');
    assert.equal(chained.models[0].usage.total, 7);
    assert.deepEqual(chained.mergedSources.get('p\u0000c'), ['p\u0000a', 'p\u0000b']);

    // 环 A→B、B→A：按列表顺序取 A→B（第一条）的目标 B，两行并成一行 B
    const cycle = [model('p', 'a', { input: 1 }), model('p', 'b', { input: 2 })];
    const folded = redirectModels(cycle, [rule('p', 'a', 'p', 'b'), rule('p', 'b', 'p', 'a')]);
    assert.equal(folded.models.length, 1);
    assert.equal(folded.models[0].model, 'b');
    assert.equal(folded.models[0].usage.total, 3);
    // 反过来写规则，存活的是 A
    const reversed = redirectModels(cycle, [rule('p', 'b', 'p', 'a'), rule('p', 'a', 'p', 'b')]);
    assert.equal(reversed.models.length, 1);
    assert.equal(reversed.models[0].model, 'a');
    // 自反规则不产生归并
    const self = redirectModels([model('p', 'a', { input: 1 })], [rule('p', 'a', 'p', 'a')]);
    assert.equal(self.models.length, 1);
    assert.deepEqual([...self.mergedSources], []);
  });

  it('同一来源取最上面一条，不完整与自反规则不生效', () => {
    const models = [model('p', 'a', { input: 1 }), model('t1', 'x', { input: 0 }), model('t2', 'x', { input: 0 })];
    const out = redirectModels(models, [
      rule('p', 'a', 't1', 'x'),
      rule('p', 'a', 't2', 'x'),
      rule('p', 'b', '', 't2', ),
    ]);
    const keys = out.models.map((m) => `${m.provider}/${m.model}`).sort();
    assert.deepEqual(keys, ['t1/x', 't2/x']);
    assert.equal(out.models.find((m) => m.model === 'x' && m.provider === 't1').usage.total, 1);
    assert.equal(out.models.find((m) => m.provider === 't2').usage.total, 0);
  });

  it('目标行不存在时按规则里的名字新建，按 total 降序排列', () => {
    const models = [model('p', 'a', { input: 10 }), model('q', 'z', { input: 3 })];
    const out = redirectModels(models, [rule('p', 'a', 'canonical', 'merged')]);
    assert.deepEqual(out.models.map((m) => `${m.provider}/${m.model}`), ['canonical/merged', 'q/z']);
    assert.equal(out.models[0].usage.total, 10);
    assert.deepEqual(out.mergedSources.get('canonical\u0000merged'), ['p\u0000a']);
  });

  it('旧快照缺 series 时不虚构日序列', () => {
    const noSeries = [{ provider: 'p', model: 'a', calls: 1, usage: { input: 1, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: 1 } }];
    const out = redirectModels(noSeries, [rule('p', 'a', 'q', 'b')]);
    assert.deepEqual(out.models[0].series, []);
  });

  it('resolveRedirectKey 逐跳解析，未命中即为自身', () => {
    const index = new Map([
      ['p\u0000a', { to: 'p\u0000b', order: 0 }],
      ['p\u0000b', { to: 'p\u0000c', order: 1 }],
    ]);
    assert.equal(resolveRedirectKey('p\u0000a', index), 'p\u0000c');
    assert.equal(resolveRedirectKey('p\u0000z', index), 'p\u0000z');
    assert.equal(resolveRedirectKey('p\u0000c', index), 'p\u0000c');
  });
});

describe('模型明细：按来源合并', () => {
  const usage = (input) => ({ input, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: input });
  const day = (t, input, calls) => ({ t, input, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, calls });
  const session = (id, { calls = 1, input = 0, lastActive = 0, title = '', cwd = '', createdAt = 0, parentSession = null, origin = null, delegationDepth = 0 } = {}) => ({
    id, title, cwd, createdAt, lastActive, calls, usage: usage(input), parentSession, origin, delegationDepth,
  });
  const detail = (provider, model, { input = 0, calls = 0, daily = [], sessions = [] } = {}) => ({
    provider, model, calls, usage: usage(input), daily, sessions,
  });

  it('空入参返回 null', () => {
    assert.equal(mergeModelDetails([], { provider: 'p', model: 'm' }), null);
  });

  it('用量、日序列与会话按 id 求和，会话元数据取首个非空，入参不被改写', () => {
    const d1 = detail('p1', 'm', {
      input: 10,
      calls: 2,
      daily: [day(1000, 10, 2)],
      sessions: [session('s1', { calls: 2, input: 10, lastActive: 5, parentSession: 'root', delegationDepth: 1 })],
    });
    const d2 = detail('p2', 'm', {
      input: 5,
      calls: 1,
      daily: [day(1000, 5, 1), day(2000, 7, 1)],
      sessions: [
        session('s1', { calls: 1, input: 5, lastActive: 9, title: '会话甲', cwd: '/w', createdAt: 42, delegationDepth: 2 }),
        session('s2', { calls: 1, input: 7, title: '会话乙' }),
      ],
    });
    const merged = mergeModelDetails([d1, d2], { provider: 'p', model: 'm' });
    assert.equal(merged.provider, 'p');
    assert.equal(merged.model, 'm');
    assert.equal(merged.calls, 3);
    assert.deepEqual(merged.usage, { input: 15, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: 15 });
    assert.deepEqual(merged.daily.map((p) => [p.t, p.input, p.calls]), [[1000, 15, 3], [2000, 7, 1]]);
    assert.deepEqual(
      merged.sessions.map((s) => [s.id, s.calls, s.usage.total, s.lastActive, s.title, s.cwd, s.createdAt, s.parentSession, s.delegationDepth]),
      [['s1', 3, 15, 9, '会话甲', '/w', 42, 'root', 2], ['s2', 1, 7, 0, '会话乙', '', 0, null, 0]],
    );
    // 合并在副本上做：归并行的明细与单模型明细同时在场时不能互相污染
    assert.equal(d1.sessions[0].calls, 2);
    assert.equal(d2.sessions[0].usage.total, 5);
    assert.equal(d1.daily[0].input, 10);
  });
});

describe('模型统计重定向：候选过滤（设置页自动完成）', () => {
  const model = (provider, name) => ({ provider, model: name, calls: 0, usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: 0 }, series: [] });

  it('catalog 按供应商与模型去重、排序', () => {
    const catalog = modelCatalog([
      model('zai-coding-cn', 'glm-5.3-flash'),
      model('opencode-go', 'deepseek-v4-flash'),
      model('opencode-go', 'deepseek-v4-flash'),
      model('opencode-go', 'mimo-v2.5'),
      model('opencode-go-vision', 'deepseek-v4-flash'),
    ]);
    assert.deepEqual([...catalog.keys()], ['opencode-go', 'opencode-go-vision', 'zai-coding-cn']);
    assert.deepEqual(catalog.get('opencode-go'), ['deepseek-v4-flash', 'mimo-v2.5']);
  });

  it('已配过的来源组合从候选里去掉，模型用光的供应商整条消失', () => {
    const catalog = modelCatalog([
      model('opencode-go', 'deepseek-v4-flash'),
      model('opencode-go', 'mimo-v2.5'),
      model('opencode-go-vision', 'deepseek-v4-flash'),
    ]);
    const used = new Set(['opencode-go-vision\u0000deepseek-v4-flash']);
    const free = unusedRedirectSources(catalog, used);
    // vision 只有一个模型且已被占用：整条供应商不再出现
    assert.deepEqual([...free.keys()], ['opencode-go']);
    assert.deepEqual(free.get('opencode-go'), ['deepseek-v4-flash', 'mimo-v2.5']);
    // 同一供应商只占用其中一个模型：供应商保留，只去掉那一个模型
    const partial = unusedRedirectSources(catalog, new Set(['opencode-go\u0000deepseek-v4-flash']));
    assert.deepEqual([...partial.keys()], ['opencode-go', 'opencode-go-vision']);
    assert.deepEqual(partial.get('opencode-go'), ['mimo-v2.5']);
    // 没占用任何组合时原样返回
    assert.deepEqual([...unusedRedirectSources(catalog, new Set()).keys()], [...catalog.keys()]);
  });
});

describe('lastActiveDayKind：最近活跃自然日判定', () => {
  // 固定本地时间 2026-09-14 09:30，用例不随当前时间漂移
  const now = new Date(2026, 8, 14, 9, 30).getTime();
  const at = (d, h, m) => new Date(2026, 8, d, h, m).getTime();

  it('按本地自然日划分，不用 24 小时窗', () => {
    assert.equal(lastActiveDayKind(at(14, 0, 1), now), 'today');
    // 昨天 23:59 距今不到 10 小时，24 小时窗会误判为今天
    assert.equal(lastActiveDayKind(at(13, 23, 59), now), 'yesterday');
    // 昨天 02:47，即用户报错的凌晨场景
    assert.equal(lastActiveDayKind(at(13, 2, 47), now), 'yesterday');
    assert.equal(lastActiveDayKind(at(12, 12, 0), now), 'earlier');
  });
});

describe('snapshot：构建与截断', () => {
  it('快照截断至 366 天且总量不受影响', () => {
    const store = createStore();
    const base = day(399);
    for (let i = 0; i < 400; i += 1) {
      const d = new Date(base);
      d.setDate(d.getDate() + i);
      const t = d.getTime();
      store.allDaily.set(t, agg(1, 1));
    }
    store.allAgg = agg(400, 400);
    store.models.set('p\0m', agg(400, 400));
    const md = new Map();
    for (const [t, a] of store.allDaily) md.set(t, { ...a });
    store.modelDaily.set('p\0m', md);
    const snap = snapshot(store, { getMeta: () => null }, null);
    assert.equal(snap.series.all.length, 366);
    assert.equal(snap.models[0].series.length, 366);
    assert.equal(snap.all.calls, 400);
    assert.equal(snap.models[0].calls, 400);
  });
});

describe('会话明细：集合聚合', () => {
  const d0 = new Date(2026, 4, 1).getTime();
  const d1 = new Date(2026, 4, 2).getTime();
  /** 构造聚合缓存里的一条会话：日桶与总桶。 */
  const info = (daily, allAgg) => ({ daily: new Map(daily), allAgg, maxSeq: -1, lastActive: 0 });

  it('合计按集合求和（含子会话），日序列升序并桶，模型行原始键总计降序', () => {
    const store = createStore();
    store.sessions.set('m', info([[d0, agg(10, 1)], [d1, agg(20, 2)]], agg(30, 3)));
    store.sessions.set('c', info([[d1, agg(5, 1)]], agg(5, 1)));
    // 账本桩：按集合返回原始 provider/model 行（服务端不做重定向归并）
    const ledger = {
      sessionModels: (ids) => [
        ...(ids.includes('c') ? [{ provider: 'a', model: 'm1', calls: 1, input: 30, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0 }] : []),
        ...(ids.includes('m') ? [{ provider: 'b', model: 'm2', calls: 1, input: 5, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0 }] : []),
      ],
    };
    const detail = sessionDetail(store, ledger, ['c', 'm']);
    // 合集 = 主 3 次 + 子 1 次，总计 35；日序列升序，d1 并桶后 3 次
    assert.equal(detail.calls, 4);
    assert.equal(detail.usage.total, 35);
    assert.deepEqual(detail.daily.map((p) => p.t), [d0, d1]);
    assert.equal(detail.daily[0].input, 10);
    assert.equal(detail.daily[1].input, 25);
    assert.equal(detail.daily[1].calls, 3);
    // 模型行按总计降序（a/m1 的 30 > b/m2 的 5），provider/model 为原始键
    assert.deepEqual(detail.models.map((m) => [m.provider, m.model, m.usage.total]), [['a', 'm1', 30], ['b', 'm2', 5]]);
  });

  it('未知 id 按 0 计不抛错；空集合恒字段齐全的空明细', () => {
    const store = createStore();
    store.sessions.set('m', info([], agg(0, 0)));
    const onlyMissing = sessionDetail(store, { sessionModels: () => [] }, ['missing']);
    assert.deepEqual(onlyMissing, {
      calls: 0,
      usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: 0 },
      daily: [],
      models: [],
    });
    const empty = sessionDetail(store, { sessionModels: () => [] }, []);
    assert.deepEqual(empty, onlyMissing);
  });

  it('只认「有桶」的日子：四段全 0、仅 reasoning 的日子也保留', () => {
    const store = createStore();
    const onlyReasoning = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 7, total: 0, calls: 1 };
    store.sessions.set('m', info([[d0, onlyReasoning]], { ...onlyReasoning }));
    const detail = sessionDetail(store, { sessionModels: () => [] }, ['m']);
    assert.equal(detail.daily.length, 1);
    assert.equal(detail.daily[0].reasoning, 7);
    assert.equal(detail.usage.total, 0);
    assert.equal(detail.calls, 1);
  });
});

describe('quota：go', () => {
  it('query TTL 内命中缓存，force 立即重拉不受下限约束', async () => {
    let calls = 0;
    const restore = mockFetch(async () => {
      calls += 1;
      return jsonResponse(200, { usage: { rolling: { percent: calls * 10, resetsAt: 'r' } } });
    });
    try {
      const a = await queryGoQuota(5, false, creds('k'));
      const b = await queryGoQuota(5, false, creds('k'));
      assert.equal(calls, 1);
      assert.equal(a, b);
      // force 完全绕过 TTL 与强制下限：距上次抓取再近也立即重拉官方端点
      const c = await queryGoQuota(5, true, creds('k'));
      assert.equal(calls, 2);
      assert.notEqual(c, a);
      assert.equal(c.rolling.percent, 20);
      // 重拉后缓存窗口以新抓取时间起算，TTL 内继续命中
      const d = await queryGoQuota(5, false, creds('k'));
      assert.equal(calls, 2);
      assert.equal(d, c);
    } finally {
      restore();
    }
  });

  it('无 key 不请求直接 no-key', async () => {
    let calls = 0;
    const restore = mockFetch(async () => {
      calls += 1;
      return jsonResponse(200, {});
    });
    try {
      const q = await fetchGoQuota(undefined);
      assert.equal(q.status, 'no-key');
      assert.equal(calls, 0);
    } finally {
      restore();
    }
  });

  it('key 去空格后透传', async () => {
    let auth = '';
    const restore = mockFetch(async (_url, init) => {
      auth = init.headers.authorization;
      return jsonResponse(200, { usage: {} });
    });
    try {
      await fetchGoQuota(creds('  k  '));
      assert.equal(auth, 'Bearer k');
    } finally {
      restore();
    }
  });

  it('401 判 no-key，非 2xx 与异构判 error', async () => {
    let restore = mockFetch(async () => jsonResponse(401, {}));
    try {
      assert.equal((await fetchGoQuota(creds('k'))).status, 'no-key');
    } finally {
      restore();
    }
    restore = mockFetch(async () => jsonResponse(500, {}));
    try {
      assert.equal((await fetchGoQuota(creds('k'))).status, 'error');
    } finally {
      restore();
    }
    restore = mockFetch(async () => jsonResponse(200, { usage: null }));
    try {
      assert.equal((await fetchGoQuota(creds('k'))).status, 'error');
    } finally {
      restore();
    }
    restore = mockFetch(async () => { throw new Error('down'); });
    try {
      assert.equal((await fetchGoQuota(creds('k'))).status, 'error');
    } finally {
      restore();
    }
  });

  it('403 EntitlementError（未订阅）判 no-plan，其余 401/403 仍判 no-key', async () => {
    let restore = mockFetch(async () => jsonResponse(403, {
      type: 'error',
      error: { type: 'EntitlementError', message: 'OpenCode Go subscription required.' },
    }));
    try {
      assert.equal((await fetchGoQuota(creds('k'))).status, 'no-plan');
    } finally {
      restore();
    }
    restore = mockFetch(async () => jsonResponse(403, {}));
    try {
      assert.equal((await fetchGoQuota(creds('k'))).status, 'no-key');
    } finally {
      restore();
    }
  });

  it('窗口归一化：合法保留、非法置 null', async () => {
    const restore = mockFetch(async () => jsonResponse(200, {
      usage: { rolling: { percent: 10.4, resetsAt: 'r' }, weekly: { percent: 'bad' }, monthly: null },
    }));
    try {
      const q = await fetchGoQuota(creds('k'));
      assert.equal(q.status, 'ok');
      assert.equal(q.rolling.percent, 10.4);
      assert.equal(q.weekly, null);
      assert.equal(q.monthly, null);
    } finally {
      restore();
    }
  });
});

describe('quota：deepseek', () => {
  it('无 key 与 401 判 no-key', async () => {
    assert.equal((await fetchDeepSeekBalance(undefined)).status, 'no-key');
    const restore = mockFetch(async () => jsonResponse(401, {}));
    try {
      assert.equal((await fetchDeepSeekBalance(creds('k'))).status, 'no-key');
    } finally {
      restore();
    }
  });

  it('余额归一化保留字符串、非法条目丢弃', async () => {
    const restore = mockFetch(async () => jsonResponse(200, {
      is_available: true,
      balance_infos: [
        { currency: 'CNY', total_balance: '12.34', granted_balance: 5, topped_up_balance: null },
        { currency: '', total_balance: '1' },
        'x',
      ],
    }));
    try {
      const q = await fetchDeepSeekBalance(creds('k'));
      assert.equal(q.status, 'ok');
      assert.equal(q.isAvailable, true);
      assert.equal(q.balances.length, 1);
      assert.deepEqual(q.balances[0], {
        currency: 'CNY',
        totalBalance: '12.34',
        grantedBalance: '5',
        toppedUpBalance: '0.00',
      });
    } finally {
      restore();
    }
  });

  it('非 boolean true 的 is_available 归一为 false', async () => {
    const restore = mockFetch(async () => jsonResponse(200, { is_available: 1, balance_infos: [] }));
    try {
      const q = await fetchDeepSeekBalance(creds('k'));
      assert.equal(q.status, 'ok');
      assert.equal(q.isAvailable, false);
    } finally {
      restore();
    }
  });

  it('key 按优先级回退', async () => {
    const restore = mockFetch(async () => jsonResponse(200, { is_available: true, balance_infos: [] }));
    try {
      const q = await queryDeepSeekBalance(5, false, seqCreds([new Error('x'), new Error('y'), new Error('z'), 'd']));
      assert.equal(q.status, 'ok');
    } finally {
      restore();
    }
  });
});

describe('quota：zai', () => {
  const T = 1_780_000_000_000;
  const okBody = {
    code: 200,
    success: true,
    data: {
      level: 'pro',
      limits: [
        { type: 'CREDIT_LIMIT', unit: 3, number: 5, percentage: 12.5, nextResetTime: T, currentValue: 10, usage: 100 },
        { type: 'TOKENS_LIMIT', unit: 6, number: 1, percentage: 50, nextResetTime: T },
        { type: 'TIME_LIMIT', currentValue: 5, usage: 20, nextResetTime: T },
      ],
    },
  };

  it('ok 三窗口与计划名', async () => {
    const restore = mockFetch(async () => jsonResponse(200, okBody));
    try {
      const q = await fetchZaiQuota(creds('k'));
      assert.equal(q.status, 'ok');
      assert.equal(q.plan, 'Z.ai pro');
      assert.equal(q.session.percent, 12.5);
      assert.equal(q.session.used, 10);
      assert.equal(q.session.limit, 100);
      assert.equal(q.weekly.percent, 50);
      assert.equal(q.webSearches.used, 5);
      assert.equal(q.webSearches.limit, 20);
      assert.equal(q.webSearches.percent, 25);
      assert.equal(new Date(q.session.resetsAt).getTime(), T);
    } finally {
      restore();
    }
  });

  it('无 key 与 401 判 no-key，无 plan 信号判 no-plan', async () => {
    assert.equal((await fetchZaiQuota(undefined)).status, 'no-key');
    let restore = mockFetch(async () => jsonResponse(403, {}));
    try {
      assert.equal((await fetchZaiQuota(creds('k'))).status, 'no-key');
    } finally {
      restore();
    }
    restore = mockFetch(async () => jsonResponse(200, { success: false, msg: '当前用户不存在coding plan' }));
    try {
      assert.equal((await fetchZaiQuota(creds('k'))).status, 'no-plan');
    } finally {
      restore();
    }
  });

  it('空 limits 为 ok 空数据，已识别但非法判 error', async () => {
    let restore = mockFetch(async () => jsonResponse(200, { code: 200, success: true, data: { level: 'pro', limits: [] } }));
    try {
      const q = await fetchZaiQuota(creds('k'));
      assert.equal(q.status, 'ok');
      assert.equal(q.plan, 'Z.ai pro');
      assert.equal(q.session, null);
    } finally {
      restore();
    }
    restore = mockFetch(async () => jsonResponse(200, {
      code: 200,
      success: true,
      data: { limits: [{ type: 'CREDIT_LIMIT', unit: 3, number: 5, nextResetTime: T }] },
    }));
    try {
      assert.equal((await fetchZaiQuota(creds('k'))).status, 'error');
    } finally {
      restore();
    }
  });

  it('全未知类型为 ok 空数据，缺 limits 判 error', async () => {
    let restore = mockFetch(async () => jsonResponse(200, {
      code: 200,
      success: true,
      data: { limits: [{ type: 'NOPE', unit: 1, number: 1 }] },
    }));
    try {
      const q = await fetchZaiQuota(creds('k'));
      assert.equal(q.status, 'ok');
      assert.equal(q.session, null);
    } finally {
      restore();
    }
    restore = mockFetch(async () => jsonResponse(200, { code: 200, success: true, data: {} }));
    try {
      assert.equal((await fetchZaiQuota(creds('k'))).status, 'error');
    } finally {
      restore();
    }
  });

  it('首个 key 解析失败回退到 ZAI_API_KEY', async () => {
    let auth = '';
    const restore = mockFetch(async (_url, init) => {
      auth = init.headers.authorization;
      return jsonResponse(200, okBody);
    });
    try {
      await fetchZaiQuota(seqCreds([new Error('x'), ' second ']));
      assert.equal(auth, 'Bearer second');
    } finally {
      restore();
    }
  });
});

// ---- 偏好设置：归一化、夹取、作用域存储与旧 localStorage 迁移（服务端设置文档为准）----

/** 构造设置作用域替身：持有一份快照，mutate 记录操作并按路径写回取值。 */
function fakeScope(initial) {
  const state = {
    status: initial?.status ?? 'ready',
    value: initial?.value,
    user: initial?.user,
    base: undefined,
    revision: 1,
    writable: initial?.writable ?? true,
    mode: 'host',
  };
  const listeners = new Set();
  const calls = [];
  // 快照对象引用稳定（与真实 ConfigForm 的 store 一致）：状态变更时才换新对象。
  let snapshot = { ...state };
  const publish = () => {
    snapshot = { ...state };
    for (const fn of listeners) fn();
  };
  const scope = {
    getSnapshot: () => snapshot,
    subscribe: (fn) => { listeners.add(fn); return () => listeners.delete(fn) },
    mutate: async (ops) => {
      calls.push(ops);
      for (const op of ops) {
        if (op.op === 'set') state.value = { ...state.value, [op.path[0]]: op.value };
      }
      state.user = { ...(state.user ?? {}), ...Object.fromEntries(ops.filter(o => o.op === 'set').map(o => [o.path[0], o.value])) };
      state.revision += 1;
      publish();
    },
  };
  return {
    scope,
    calls,
    state,
    listeners,
    /** 模拟异步落定：改状态并通知订阅者。 */
    apply: (patch) => { Object.assign(state, patch); publish(); },
  };
}

/** localStorage 替身：只有 getItem/removeItem 两个被用到的能力。 */
function fakeStorage(initial) {
  const map = new Map(Object.entries(initial ?? {}));
  return {
    store: map,
    getItem: (key) => (map.has(key) ? map.get(key) : null),
    removeItem: (key) => { map.delete(key); },
    has: (key) => map.has(key),
  };
}

/** 用 Buffer 独立造配置串：容错用例的数据不经过被测编码器，避免自证。 */
function configTextOf(payload) {
  return Buffer.from(JSON.stringify(payload), 'utf8').toString('base64');
}

describe('偏好设置：归一化与写入操作', () => {
  it('命名空间名与默认值自洽，坏值逐字段回退', () => {
    assert.equal(USAGE_SETTINGS_NAMESPACE, 'usage-stats');
    assert.deepEqual(normalizeUsageSettings(null), USAGE_SETTINGS_DEFAULTS);
    assert.deepEqual(normalizeUsageSettings(undefined), USAGE_SETTINGS_DEFAULTS);
    assert.deepEqual(normalizeUsageSettings({}), USAGE_SETTINGS_DEFAULTS);
    assert.deepEqual(
      normalizeUsageSettings({ goEnabled: 'on', showZaiInSidebar: 1, zaiFetchMinutes: 'soon' }),
      USAGE_SETTINGS_DEFAULTS,
    );
  });

  it('会话徽标开关默认开启，非布尔回退默认', () => {
    assert.equal(USAGE_SETTINGS_DEFAULTS.showSessionId, true);
    assert.equal(normalizeUsageSettings({}).showSessionId, true);
    assert.equal(normalizeUsageSettings({ showSessionId: false }).showSessionId, false);
    assert.equal(normalizeUsageSettings({ showSessionId: 'yes' }).showSessionId, true);
    assert.deepEqual(settingOps({ showSessionId: false }), [{ op: 'set', path: ['showSessionId'], value: false }]);
  });
  it('间隔夹到下限、小数取整，非有限值回退默认', () => {    assert.equal(normalizeUsageSettings({ goFetchMinutes: 1 }).goFetchMinutes, GO_FETCH_MIN_MINUTES);
    assert.equal(normalizeUsageSettings({ goFetchMinutes: 12.6 }).goFetchMinutes, 13);
    assert.equal(normalizeUsageSettings({ goFetchMinutes: Number.NaN }).goFetchMinutes, GO_FETCH_DEFAULT_MINUTES);
    assert.equal(normalizeUsageSettings({ deepseekFetchMinutes: 0 }).deepseekFetchMinutes, DEEPSEEK_FETCH_MIN_MINUTES);
    assert.equal(normalizeUsageSettings({ zaiFetchMinutes: -5 }).zaiFetchMinutes, ZAI_FETCH_MIN_MINUTES);
    assert.equal(ZAI_FETCH_DEFAULT_MINUTES, 5);
    assert.equal(clampGoFetchMinutes(Number.POSITIVE_INFINITY), GO_FETCH_DEFAULT_MINUTES);
    assert.equal(clampDeepSeekFetchMinutes(4.4), 4);
    assert.equal(clampZaiFetchMinutes(2), ZAI_FETCH_MIN_MINUTES);
  });

  it('局部偏好只生成显式字段的路径写入，间隔先夹取', () => {
    assert.deepEqual(settingOps({ goEnabled: false }), [{ op: 'set', path: ['goEnabled'], value: false }]);
    assert.deepEqual(settingOps({ zaiFetchMinutes: 1 }), [{ op: 'set', path: ['zaiFetchMinutes'], value: ZAI_FETCH_MIN_MINUTES }]);
    assert.deepEqual(settingOps({ goEnabled: undefined, deepseekEnabled: true }), [{ op: 'set', path: ['deepseekEnabled'], value: true }]);
    assert.deepEqual(settingOps({}), []);
  });

  it('迁移只写与默认值不同的字段', () => {
    assert.deepEqual(diffFromDefaults(USAGE_SETTINGS_DEFAULTS), {});
    assert.deepEqual(
      diffFromDefaults({ ...USAGE_SETTINGS_DEFAULTS, showGoInSidebar: false, zaiFetchMinutes: 9 }),
      { showGoInSidebar: false, zaiFetchMinutes: 9 },
    );
  });

  it('规则表整表写入，空表与非空表都不算用户改动', () => {
    const rules = [{ fromProvider: 'p1', fromModel: 'm', toProvider: 'p2', toModel: 'm' }];
    // 路径写入：整条数组一次 set，不做下标级增删
    assert.deepEqual(settingOps({ modelRedirects: rules }), [
      { op: 'set', path: ['modelRedirects'], value: rules },
    ]);
    // 归一化每次都新建数组：引用比较会把空表当成用户改动，故按 JSON 比较
    assert.deepEqual(diffFromDefaults(normalizeUsageSettings(null)), {});
    assert.deepEqual(diffFromDefaults({ ...USAGE_SETTINGS_DEFAULTS, modelRedirects: rules }), { modelRedirects: rules });
  });
});

describe('偏好设置：配置串编解码', () => {
  it('默认偏好往返一致，编码结果可被独立 Base64 实现解出同一份载荷', () => {
    const at = new Date('2026-10-13T00:00:00.000Z');
    const text = encodeConfigTransfer(USAGE_SETTINGS_DEFAULTS, at);
    // 独立实现（Buffer）解出载荷：编码结果不能只靠被测解码器自证。
    assert.deepEqual(JSON.parse(Buffer.from(text, 'base64').toString('utf8')), {
      format: CONFIG_TRANSFER_FORMAT,
      version: CONFIG_TRANSFER_VERSION,
      exportedAt: '2026-10-13T00:00:00.000Z',
      settings: USAGE_SETTINGS_DEFAULTS,
    });
    // 标准字母表带填充：单行、长度为 4 的倍数、只含 A-Za-z0-9+/ 与末尾填充。
    assert.match(text, /^[A-Za-z0-9+/]+={0,2}$/);
    assert.equal(text.length % 4, 0);
    assert.deepEqual(decodeConfigTransfer(text), {
      ok: true,
      settings: USAGE_SETTINGS_DEFAULTS,
      exportedAt: '2026-10-13T00:00:00.000Z',
    });
  });

  it('全字段改动与非 ASCII 模型名往返逐字一致', () => {
    const rules = [{ fromProvider: '内网', fromModel: '模型甲', toProvider: '正式', toModel: '模型乙' }];
    const next = {
      ...USAGE_SETTINGS_DEFAULTS,
      goEnabled: false,
      showGoInSidebar: false,
      goFetchMinutes: 11,
      deepseekEnabled: false,
      showDeepSeekInSidebar: false,
      deepseekFetchMinutes: 12,
      zaiEnabled: false,
      showZaiInSidebar: false,
      zaiFetchMinutes: 13,
      showSessionId: false,
      modelRedirects: rules,
    };
    const decoded = decodeConfigTransfer(encodeConfigTransfer(next));
    assert.equal(decoded.ok, true);
    assert.deepEqual(decoded.settings, next);
    assert.equal(typeof decoded.exportedAt, 'string');
    assert.equal(Number.isNaN(new Date(decoded.exportedAt).getTime()), false);
    // 中文经 UTF-8 落进载荷：独立实现读出的 JSON 里模型名逐字一致。
    const payload = JSON.parse(Buffer.from(encodeConfigTransfer(next), 'base64').toString('utf8'));
    assert.deepEqual(payload.settings.modelRedirects, rules);
  });

  it('容错：空白/换行、URL 安全字母表与缺填充都能解', () => {
    // 规则里带中文，编码结果同时含标准字母表的 + 与 /，URL 安全变体才有意义。
    const payload = {
      format: CONFIG_TRANSFER_FORMAT,
      version: CONFIG_TRANSFER_VERSION,
      exportedAt: null,
      settings: {
        showGoInSidebar: false,
        modelRedirects: [{ fromProvider: 'prov', fromModel: '万俎', toProvider: 'real', toModel: 'target' }],
      },
    };
    const text = configTextOf(payload);
    assert.match(text, /\+/);
    assert.match(text, /\//);
    const expected = { ok: true, settings: { ...USAGE_SETTINGS_DEFAULTS, ...payload.settings }, exportedAt: null };
    assert.deepEqual(decodeConfigTransfer(text), expected);
    // 首尾与内部空白、换行
    assert.deepEqual(decodeConfigTransfer(` \n${text}\t `), expected);
    assert.deepEqual(decodeConfigTransfer(text.replace(/(.{16})/g, '$1\n ')), expected);
    // URL 安全字母表 + 去掉填充
    const urlSafe = text.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    assert.notEqual(urlSafe, text);
    assert.deepEqual(decodeConfigTransfer(urlSafe), expected);
    // 缺填充可补：另取一个编码结果带填充的载荷，去掉填充仍能解。
    const padded = configTextOf({ format: CONFIG_TRANSFER_FORMAT, version: CONFIG_TRANSFER_VERSION, settings: { goEnabled: false } });
    assert.match(padded, /=+$/);
    assert.equal(decodeConfigTransfer(padded.replace(/=+$/, '')).ok, true);
  });

  it('失败语义逐码断言：空、非法字符、坏 JSON、错格式、错版本、settings 形状', () => {
    const errorOf = (text) => {
      const result = decodeConfigTransfer(text);
      assert.equal(result.ok, false, `应失败：${text.slice(0, 24)}`);
      return result.error;
    };
    assert.equal(errorOf(''), 'empty');
    assert.equal(errorOf(' \n\t '), 'empty');
    assert.equal(errorOf('not base64!!'), 'invalid-base64');
    assert.equal(errorOf('===='), 'invalid-base64');
    // 长度为 4n+1：补填充也解不开，归 invalid-base64
    assert.equal(errorOf('A'), 'invalid-base64');
    // 合法 Base64 但内容不是 JSON：与「合法 JSON 但不是对象」区分开
    assert.equal(errorOf(Buffer.from('{oops', 'utf8').toString('base64')), 'invalid-payload');
    // 非对象 JSON：没有 format 可读，按契约归 unknown-format
    assert.equal(errorOf(configTextOf(123)), 'unknown-format');
    assert.equal(errorOf(configTextOf(null)), 'unknown-format');
    assert.equal(errorOf(configTextOf([1, 2])), 'unknown-format');
    assert.equal(errorOf(configTextOf({ version: 1, settings: {} })), 'unknown-format');
    assert.equal(errorOf(configTextOf({ format: 'other', version: 1, settings: {} })), 'unknown-format');
    assert.equal(errorOf(configTextOf({ format: CONFIG_TRANSFER_FORMAT, version: 2, settings: {} })), 'unsupported-version');
    assert.equal(errorOf(configTextOf({ format: CONFIG_TRANSFER_FORMAT, version: '1', settings: {} })), 'unsupported-version');
    assert.equal(errorOf(configTextOf({ format: CONFIG_TRANSFER_FORMAT, version: 1 })), 'invalid-payload');
    assert.equal(errorOf(configTextOf({ format: CONFIG_TRANSFER_FORMAT, version: 1, settings: null })), 'invalid-payload');
    assert.equal(errorOf(configTextOf({ format: CONFIG_TRANSFER_FORMAT, version: 1, settings: [] })), 'invalid-payload');
    assert.equal(errorOf(configTextOf({ format: CONFIG_TRANSFER_FORMAT, version: 1, settings: 'x' })), 'invalid-payload');
    // 校验顺序：format 先于 version，version 先于 settings 形状
    assert.equal(errorOf(configTextOf({ format: 'other', version: 2, settings: null })), 'unknown-format');
    assert.equal(errorOf(configTextOf({ format: CONFIG_TRANSFER_FORMAT, version: 2, settings: null })), 'unsupported-version');
  });

  it('解码归一化：坏字段回退默认值、未知字段忽略、越界间隔夹取', () => {
    const text = configTextOf({
      format: CONFIG_TRANSFER_FORMAT,
      version: CONFIG_TRANSFER_VERSION,
      settings: { goEnabled: 'on', goFetchMinutes: 1, showZaiInSidebar: false, modelRedirects: '不是数组', 不认识: true },
    });
    const decoded = decodeConfigTransfer(text);
    assert.equal(decoded.ok, true);
    assert.deepEqual(decoded.settings, {
      ...USAGE_SETTINGS_DEFAULTS,
      goFetchMinutes: GO_FETCH_MIN_MINUTES,
      showZaiInSidebar: false,
    });
    // 规则表按 normalizeModelRedirects 清洗：坏条目丢弃、半填条目保留（界面继续填）。
    const rules = configTextOf({
      format: CONFIG_TRANSFER_FORMAT,
      version: CONFIG_TRANSFER_VERSION,
      settings: { modelRedirects: ['x', {}, { fromProvider: ' p ', fromModel: 'm' }] },
    });
    const parsed = decodeConfigTransfer(rules);
    assert.equal(parsed.ok, true);
    assert.deepEqual(parsed.settings.modelRedirects, [{ fromProvider: 'p', fromModel: 'm', toProvider: '', toModel: '' }]);
    // exportedAt 非字符串按 null，不参与校验。
    const numeric = configTextOf({ format: CONFIG_TRANSFER_FORMAT, version: 1, exportedAt: 42, settings: {} });
    assert.deepEqual(decodeConfigTransfer(numeric), { ok: true, settings: USAGE_SETTINGS_DEFAULTS, exportedAt: null });
  });

  it('changedSettingFields 按默认值键序给出改动字段', () => {
    const base = normalizeUsageSettings(null);
    assert.deepEqual(changedSettingFields(base, base), []);
    assert.deepEqual(changedSettingFields(base, { ...base, showSessionId: false }), ['showSessionId']);
    assert.deepEqual(
      changedSettingFields(base, { ...base, zaiFetchMinutes: 9, goEnabled: false }),
      ['goEnabled', 'zaiFetchMinutes'],
    );
    // 规则表按值比较：等值数组（逐条复制）不算改动，改过才算。
    const rules = [{ fromProvider: 'a', fromModel: 'b', toProvider: 'c', toModel: 'd' }];
    const withRules = { ...base, modelRedirects: rules };
    assert.deepEqual(changedSettingFields(withRules, { ...base, modelRedirects: rules.map((rule) => ({ ...rule })) }), []);
    assert.deepEqual(changedSettingFields(withRules, { ...base, modelRedirects: [] }), ['modelRedirects']);
    assert.deepEqual(changedSettingFields(base, withRules), ['modelRedirects']);
    // 键序即默认值声明序，全字段改动时与 Object.keys(USAGE_SETTINGS_DEFAULTS) 一致。
    const all = {
      goEnabled: false,
      showGoInSidebar: false,
      goFetchMinutes: 9,
      deepseekEnabled: false,
      showDeepSeekInSidebar: false,
      deepseekFetchMinutes: 9,
      zaiEnabled: false,
      showZaiInSidebar: false,
      zaiFetchMinutes: 9,
      showSessionId: false,
      modelRedirects: rules,
    };
    assert.deepEqual(changedSettingFields(base, all), Object.keys(USAGE_SETTINGS_DEFAULTS));
    assert.deepEqual(changedSettingFields(all, base), Object.keys(USAGE_SETTINGS_DEFAULTS));
  });
});

describe('偏好设置：作用域视图与写入', () => {
  afterEach(() => { detachUsageSettings(); });

  it('未绑定作用域时视图为默认值且不可写状态为 unavailable', () => {
    assert.deepEqual(usageSettingsView(), { settings: USAGE_SETTINGS_DEFAULTS, status: 'unavailable', writable: false });
    // 未绑定作用域：写入与订阅都不抛错
    updateUsageSettings({ goEnabled: false });
    assert.equal(typeof subscribeUsageSettings(() => {}), 'function');
  });

  it('绑定后视图取自作用域快照，同一快照引用稳定、坏值归一化', () => {
    const { scope } = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS, goFetchMinutes: 1 } });
    attachUsageSettings(scope);
    const first = usageSettingsView();
    assert.equal(first.status, 'ready');
    assert.equal(first.writable, true);
    assert.equal(first.settings.goFetchMinutes, GO_FETCH_MIN_MINUTES);
    assert.equal(usageSettingsView(), first);
  });

  it('写入走作用域 mutate，订阅转发作用域变更', async () => {
    const { scope, calls, listeners } = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS } });
    attachUsageSettings(scope);
    let notified = 0;
    const unsubscribe = subscribeUsageSettings(() => { notified += 1; });
    updateUsageSettings({ goFetchMinutes: 2, showDeepSeekInSidebar: false });
    await new Promise((r) => { setTimeout(r, 0); });
    assert.deepEqual(calls, [[
      { op: 'set', path: ['goFetchMinutes'], value: GO_FETCH_MIN_MINUTES },
      { op: 'set', path: ['showDeepSeekInSidebar'], value: false },
    ]]);
    assert.equal(notified, 1);
    unsubscribe();
    assert.equal(listeners.size, 0);
    assert.equal(usageSettingsView().settings.showDeepSeekInSidebar, false);
  });

  it('作用域落定为不可用或只读时不发注定被拒的写入，加载中照发', async () => {
    const unavailable = fakeScope({ value: undefined, status: 'unavailable' });
    attachUsageSettings(unavailable.scope);
    updateUsageSettings({ goEnabled: false });
    await new Promise((r) => { setTimeout(r, 0); });
    assert.deepEqual(unavailable.calls, []);

    const readOnly = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS }, writable: false });
    attachUsageSettings(readOnly.scope);
    updateUsageSettings({ goEnabled: false });
    await new Promise((r) => { setTimeout(r, 0); });
    assert.deepEqual(readOnly.calls, []);

    // 仍在加载：服务端可能接受，照发
    const loading = fakeScope({ value: undefined, status: 'loading' });
    attachUsageSettings(loading.scope);
    updateUsageSettings({ goEnabled: false });
    await new Promise((r) => { setTimeout(r, 0); });
    assert.deepEqual(loading.calls, [[{ op: 'set', path: ['goEnabled'], value: false }]]);
  });

  it('解绑带作用域身份：旧清理不会抹掉后挂上的新作用域（热重载）', () => {
    const first = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS, goFetchMinutes: 9 } });
    const second = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS, zaiFetchMinutes: 7 } });
    attachUsageSettings(first.scope);
    attachUsageSettings(second.scope);
    // 旧 fiber 的清理跑在新 apply 之后：只解绑自己那一个。
    detachUsageSettings(first.scope);
    assert.equal(usageSettingsView().settings.zaiFetchMinutes, 7);
    detachUsageSettings(second.scope);
    assert.deepEqual(usageSettingsView().settings, USAGE_SETTINGS_DEFAULTS);
    assert.equal(usageSettingsView().status, 'unavailable');
    // 省略参数仍是无条件解绑（测试与手动复位用）
    attachUsageSettings(first.scope);
    detachUsageSettings();
    assert.equal(usageSettingsView().status, 'unavailable');
  });

  it('解绑后写入不再落作用域，视图回退默认值', async () => {
    const { scope, calls } = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS } });
    attachUsageSettings(scope);
    detachUsageSettings();
    updateUsageSettings({ goEnabled: false });
    await new Promise((r) => { setTimeout(r, 0); });
    assert.deepEqual(calls, []);
    assert.deepEqual(usageSettingsView().settings, USAGE_SETTINGS_DEFAULTS);
  });
});

describe('偏好设置：整份替换写入', () => {
  afterEach(() => { detachUsageSettings(); });

  it('replacementOps：默认值字段 unset，改动字段 set 且间隔夹取', () => {
    assert.deepEqual(
      replacementOps(USAGE_SETTINGS_DEFAULTS),
      Object.keys(USAGE_SETTINGS_DEFAULTS).map((field) => ({ op: 'unset', path: [field] })),
    );
    const rules = [{ fromProvider: 'a', fromModel: 'b', toProvider: 'c', toModel: 'd' }];
    const next = { ...USAGE_SETTINGS_DEFAULTS, goFetchMinutes: 1, showSessionId: false, modelRedirects: rules };
    assert.deepEqual(replacementOps(next), [
      { op: 'unset', path: ['goEnabled'] },
      { op: 'unset', path: ['showGoInSidebar'] },
      { op: 'set', path: ['goFetchMinutes'], value: GO_FETCH_MIN_MINUTES },
      { op: 'unset', path: ['deepseekEnabled'] },
      { op: 'unset', path: ['showDeepSeekInSidebar'] },
      { op: 'unset', path: ['deepseekFetchMinutes'] },
      { op: 'unset', path: ['zaiEnabled'] },
      { op: 'unset', path: ['showZaiInSidebar'] },
      { op: 'unset', path: ['zaiFetchMinutes'] },
      { op: 'set', path: ['showSessionId'], value: false },
      { op: 'set', path: ['modelRedirects'], value: rules },
    ]);
  });

  it('replaceUsageSettings 一次提交整份 ops，覆盖旧用户段', async () => {
    const { scope, calls } = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS, goEnabled: false }, user: { goEnabled: false } });
    attachUsageSettings(scope);
    replaceUsageSettings({ ...USAGE_SETTINGS_DEFAULTS, zaiFetchMinutes: 1, showSessionId: false });
    await new Promise((r) => { setTimeout(r, 0); });
    assert.equal(calls.length, 1);
    const ops = calls[0];
    // 字段序稳定：与默认值声明序一致，等于默认值的字段发 unset（旧用户段随之消失）。
    assert.deepEqual(ops.map((op) => op.path[0]), Object.keys(USAGE_SETTINGS_DEFAULTS));
    assert.deepEqual(ops.filter((op) => op.op === 'set'), [
      { op: 'set', path: ['zaiFetchMinutes'], value: ZAI_FETCH_MIN_MINUTES },
      { op: 'set', path: ['showSessionId'], value: false },
    ]);
    assert.deepEqual(ops.filter((op) => op.op === 'unset'), [
      { op: 'unset', path: ['goEnabled'] },
      { op: 'unset', path: ['showGoInSidebar'] },
      { op: 'unset', path: ['goFetchMinutes'] },
      { op: 'unset', path: ['deepseekEnabled'] },
      { op: 'unset', path: ['showDeepSeekInSidebar'] },
      { op: 'unset', path: ['deepseekFetchMinutes'] },
      { op: 'unset', path: ['zaiEnabled'] },
      { op: 'unset', path: ['showZaiInSidebar'] },
      { op: 'unset', path: ['modelRedirects'] },
    ]);
  });

  it('replaceUsageSettings 守卫：不可用/只读不发写，解绑后不发，加载中照发', async () => {
    const unavailable = fakeScope({ value: undefined, status: 'unavailable' });
    attachUsageSettings(unavailable.scope);
    replaceUsageSettings({ ...USAGE_SETTINGS_DEFAULTS, showSessionId: false });
    await new Promise((r) => { setTimeout(r, 0); });
    assert.deepEqual(unavailable.calls, []);

    const readOnly = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS }, writable: false });
    attachUsageSettings(readOnly.scope);
    replaceUsageSettings({ ...USAGE_SETTINGS_DEFAULTS, showSessionId: false });
    await new Promise((r) => { setTimeout(r, 0); });
    assert.deepEqual(readOnly.calls, []);

    const detached = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS } });
    attachUsageSettings(detached.scope);
    detachUsageSettings();
    replaceUsageSettings({ ...USAGE_SETTINGS_DEFAULTS, showSessionId: false });
    await new Promise((r) => { setTimeout(r, 0); });
    assert.deepEqual(detached.calls, []);

    // 仍在加载：服务端可能接受，照发
    const loading = fakeScope({ value: undefined, status: 'loading' });
    attachUsageSettings(loading.scope);
    replaceUsageSettings({ ...USAGE_SETTINGS_DEFAULTS, showSessionId: false });
    await new Promise((r) => { setTimeout(r, 0); });
    assert.equal(loading.calls.length, 1);
  });
});

describe('偏好设置：旧 localStorage 迁移', () => {
  afterEach(() => { detachUsageSettings(); });

  it('读取旧值做归一化，坏 JSON 返回 null', () => {
    const storage = fakeStorage({ [LEGACY_STORAGE_KEY]: JSON.stringify({ goFetchMinutes: 1, zaiEnabled: false }) });
    assert.deepEqual(readLegacySettings(storage), { ...USAGE_SETTINGS_DEFAULTS, goFetchMinutes: GO_FETCH_MIN_MINUTES, zaiEnabled: false });
    assert.equal(readLegacySettings(fakeStorage({ [LEGACY_STORAGE_KEY]: '{oops' })), null);
    assert.equal(readLegacySettings(fakeStorage({})), null);
  });

  it('作用域就绪且无用户段时把旧偏好写进设置文档并删键', async () => {
    const { scope, calls } = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS } });
    const storage = fakeStorage({ [LEGACY_STORAGE_KEY]: JSON.stringify({ ...USAGE_SETTINGS_DEFAULTS, showGoInSidebar: false, zaiFetchMinutes: 9 }) });
    assert.equal(await migrateLegacySettings(scope, storage), true);
    assert.deepEqual(calls, [[
      { op: 'set', path: ['showGoInSidebar'], value: false },
      { op: 'set', path: ['zaiFetchMinutes'], value: 9 },
    ]]);
    assert.equal(storage.has(LEGACY_STORAGE_KEY), false);
  });

  it('用户已改过设置文档时不覆盖，旧键仍删除', async () => {
    const { scope, calls } = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS }, user: { goEnabled: false } });
    const storage = fakeStorage({ [LEGACY_STORAGE_KEY]: JSON.stringify({ ...USAGE_SETTINGS_DEFAULTS, showGoInSidebar: false }) });
    assert.equal(await migrateLegacySettings(scope, storage), false);
    assert.deepEqual(calls, []);
    assert.equal(storage.has(LEGACY_STORAGE_KEY), false);
  });

  it('作用域一直 loading 时等落定，超时后不写文档也不删旧键', async () => {
    const notReady = fakeScope({ value: undefined, status: 'loading' });
    const storage = fakeStorage({ [LEGACY_STORAGE_KEY]: JSON.stringify({ ...USAGE_SETTINGS_DEFAULTS, goEnabled: false }) });
    assert.equal(await migrateLegacySettings(notReady.scope, storage, 20), false);
    assert.deepEqual(notReady.calls, []);
    // 保留旧键：此刻没有可靠落点，删掉等于丢设置。
    assert.equal(storage.has(LEGACY_STORAGE_KEY), true);
  });

  it('loading 期间落定为就绪则照常迁移', async () => {
    const pending = fakeScope({ value: undefined, status: 'loading' });
    const storage = fakeStorage({ [LEGACY_STORAGE_KEY]: JSON.stringify({ ...USAGE_SETTINGS_DEFAULTS, goEnabled: false }) });
    const migrating = migrateLegacySettings(pending.scope, storage, 1_000);
    setTimeout(() => { pending.apply({ status: 'ready', value: { ...USAGE_SETTINGS_DEFAULTS } }); }, 10);
    assert.equal(await migrating, true);
    assert.deepEqual(pending.calls, [[{ op: 'set', path: ['goEnabled'], value: false }]]);
    assert.equal(storage.has(LEGACY_STORAGE_KEY), false);
  });

  it('服务端设置不可用或只读时保留旧键', async () => {
    const unavailable = fakeScope({ value: undefined, status: 'unavailable' });
    const storageA = fakeStorage({ [LEGACY_STORAGE_KEY]: JSON.stringify({ ...USAGE_SETTINGS_DEFAULTS, goEnabled: false }) });
    assert.equal(await migrateLegacySettings(unavailable.scope, storageA, 20), false);
    assert.deepEqual(unavailable.calls, []);
    assert.equal(storageA.has(LEGACY_STORAGE_KEY), true);

    const readOnly = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS }, writable: false });
    const storageB = fakeStorage({ [LEGACY_STORAGE_KEY]: JSON.stringify({ ...USAGE_SETTINGS_DEFAULTS, goEnabled: false }) });
    assert.equal(await migrateLegacySettings(readOnly.scope, storageB, 20), false);
    assert.deepEqual(readOnly.calls, []);
    assert.equal(storageB.has(LEGACY_STORAGE_KEY), true);
  });

  it('无旧键时不动作；旧值与默认值相同也不写文档', async () => {
    const { scope, calls } = fakeScope({ value: { ...USAGE_SETTINGS_DEFAULTS } });
    assert.equal(await migrateLegacySettings(scope, fakeStorage({})), false);
    const storage = fakeStorage({ [LEGACY_STORAGE_KEY]: JSON.stringify(USAGE_SETTINGS_DEFAULTS) });
    assert.equal(await migrateLegacySettings(scope, storage), false);
    assert.deepEqual(calls, []);
    assert.equal(storage.has(LEGACY_STORAGE_KEY), false);
    // clearLegacySettings 幂等且存储缺席时不抛错
    clearLegacySettings(storage);
    clearLegacySettings(undefined);
  });
});

// ---- 服务端偏好设置：条目 schema 与浏览器端命名空间对齐 ----

describe('偏好设置：服务端条目 schema', () => {
  it('字段全 volatile、默认值等于共享默认值（设置服务只投影 volatile 字段成表单）', () => {
    const resolved = UsageSettingsSchema({});
    // 逐字段取出引用背后的取值：全 volatile 才有表单，也只有 volatile 路径接受写入。
    const plain = {};
    for (const [field, value] of Object.entries(resolved)) {
      assert.equal(typeof value.get, 'function', `${field} 必须标 .volatile()`);
      plain[field] = value.get();
    }
    assert.deepEqual(plain, USAGE_SETTINGS_DEFAULTS);
    // 字段名一一对应：schema 少一个字段则该偏好永远取默认值，多一个字段则多出一份没人读的配置。
    assert.deepEqual(Object.keys(resolved).sort(), Object.keys(USAGE_SETTINGS_DEFAULTS).sort());
    // 单字段覆盖只影响该字段，其余仍是默认值。
    const overridden = UsageSettingsSchema({ showZaiInSidebar: false });
    assert.equal(overridden.showZaiInSidebar.get(), false);
    assert.equal(overridden.goFetchMinutes.get(), USAGE_SETTINGS_DEFAULTS.goFetchMinutes);
  });

  it('旧设置文档段转补丁：归一化、丢掉等于默认值的项、忽略未知字段', () => {
    // 段缺失或不是普通对象：没有可回收内容。
    assert.deepEqual(legacySettingsPatch(undefined), {});
    assert.deepEqual(legacySettingsPatch(null), {});
    assert.deepEqual(legacySettingsPatch([]), {});
    assert.deepEqual(legacySettingsPatch('usage-stats'), {});
    // 与默认值相同的字段不写：旧文档把用户改过的字段按原样存着，等于默认值就等于没改。
    assert.deepEqual(legacySettingsPatch({ goEnabled: true, deepseekEnabled: true }), {});
    // 坏值按归一化口径处理：非布尔回退默认（丢弃），越界间隔夹到下限，未知字段忽略。
    assert.deepEqual(
      legacySettingsPatch({ zaiEnabled: false, showZaiInSidebar: 'yes', zaiFetchMinutes: 0, 不认识: 1 }),
      { zaiEnabled: false, zaiFetchMinutes: ZAI_FETCH_MIN_MINUTES },
    );
    // 规则表整体回收（数组每次归一化都是新对象，必须按值比较）。
    const rules = [{ fromProvider: 'a', fromModel: 'b', toProvider: 'c', toModel: 'd' }];
    assert.deepEqual(legacySettingsPatch({ modelRedirects: rules }), { modelRedirects: rules });
  });

  it('条目 id 与浏览器端常量同源：cordis.patch.yml 的 insert id 必须能被 ctx.configForms 取到', () => {
    // 浏览器端按 USAGE_SETTINGS_NAMESPACE 取设置表单，profile 条目 id 是唯一的对接点；
    // 两侧漂移时偏好会静默退化为仅当前页面生效，故直接读补丁文件断言。
    const patch = readFileSync(new URL('../cordis.patch.yml', import.meta.url), 'utf8');
    const entry = patch.match(/^\s*- id: (\S+)/m);
    assert.ok(entry, 'cordis.patch.yml 必须声明插件条目 id');
    assert.equal(entry[1], USAGE_SETTINGS_NAMESPACE);
    assert.match(patch, /^\s*name: '@xfqz86\/dsh-usage-stats'$/m);
  });
});

// ---- 更新检查：版本比较、npm/GitHub 查询与缓存 ----

describe('更新检查', () => {
  const RELEASES = 'https://github.com/xfqz86/dsh-usage-stats/releases';
  const NOTES = '## 新增\n- 一键升级';
  const PUBLISHED = Date.parse('2026-10-21T08:00:00Z');

  it('isNewerVersion 只比较核心版本，忽略 v 前缀与预发布后缀', () => {
    assert.equal(isNewerVersion('0.6.0', '0.5.1'), true);
    assert.equal(isNewerVersion('v0.6.0', '0.5.1'), true);
    assert.equal(isNewerVersion('0.5.2-beta.1', '0.5.1'), true);
    assert.equal(isNewerVersion('0.5.1', '0.5.1'), false);
    assert.equal(isNewerVersion('0.5.1-beta.2', '0.5.1'), false);
    assert.equal(isNewerVersion('0.5.0', '0.5.1'), false);
    // 非法输入宁可漏报，不误报
    assert.equal(isNewerVersion('bad', '0.5.1'), false);
    assert.equal(isNewerVersion('0.6.0', 'bad'), false);
    assert.equal(isNewerVersion('', ''), false);
  });

  it('updateRelation 区分线上更新、已是最新与本地版本领先', () => {
    // 线上更高 → update
    assert.equal(updateRelation('0.6.0', '0.5.1'), 'update');
    assert.equal(updateRelation('v0.6.0', 'v0.5.1'), 'update');
    // 相等（含 v 前缀差异）→ latest
    assert.equal(updateRelation('0.5.1', '0.5.1'), 'latest');
    assert.equal(updateRelation('v0.5.1', '0.5.1'), 'latest');
    // 当前更高 → ahead，不能误报「已是最新」
    assert.equal(updateRelation('0.5.0', '0.5.1'), 'ahead');
    assert.equal(updateRelation('0.4.9', 'v0.5.1'), 'ahead');
    // 非法输入两个方向都不成立，按 latest 处理
    assert.equal(updateRelation('bad', '0.5.1'), 'latest');
    assert.equal(updateRelation('0.6.0', 'bad'), 'latest');
    assert.equal(updateRelation('', ''), 'latest');
  });

  it('classifyDependencySpec 区分 npm、本地与未知安装', () => {
    assert.equal(classifyDependencySpec('0.5.1'), 'npm');
    assert.equal(classifyDependencySpec('^0.5.1'), 'npm');
    assert.equal(classifyDependencySpec('~0.5.1'), 'npm');
    assert.equal(classifyDependencySpec('>=0.5.1'), 'npm');
    assert.equal(classifyDependencySpec('latest'), 'npm');
    assert.equal(classifyDependencySpec('*'), 'npm');
    assert.equal(classifyDependencySpec('link:/Users/x/dsh-usage-stats'), 'local');
    assert.equal(classifyDependencySpec('file:../pkg.tgz'), 'local');
    assert.equal(classifyDependencySpec('portal:../pkg'), 'local');
    assert.equal(classifyDependencySpec('workspace:*'), 'local');
    assert.equal(classifyDependencySpec('github:xfqz86/dsh-usage-stats'), 'local');
    assert.equal(classifyDependencySpec('git+https://example.com/x.git'), 'local');
    assert.equal(classifyDependencySpec('https://example.com/x.tgz'), 'local');
    assert.equal(classifyDependencySpec('./local-pkg'), 'local');
    assert.equal(classifyDependencySpec('/abs/local-pkg'), 'local');
    assert.equal(classifyDependencySpec('next'), 'unknown');
    assert.equal(classifyDependencySpec(undefined), 'unknown');
  });

  it('查询成功带说明与安装方式，缓存命中、install 变化与 force 都绕过', async () => {
    let calls = 0;
    mockFetch(async (url) => {
      calls += 1;
      if (String(url).includes('api.github.com')) {
        return jsonResponse(200, { body: NOTES, published_at: '2026-10-21T08:00:00Z', html_url: RELEASES + '/tag/v0.6.0' });
      }
      assert.match(String(url), /registry\.npmjs\.org/);
      return jsonResponse(200, { version: '0.6.0' });
    });
    const first = await queryUpdateCheck(true, 'npm');
    assert.deepEqual(first, {
      status: 'ok', latest: '0.6.0', url: RELEASES + '/tag/v0.6.0', notes: NOTES, publishedAt: PUBLISHED, install: 'npm',
    });
    assert.equal(calls, 2);
    // 缓存命中：同一安装方式不再发起 fetch
    const cached = await queryUpdateCheck(false, 'npm');
    assert.deepEqual(cached, first);
    assert.equal(calls, 2);
    // install 变化时缓存失效，重新查询；结果携带新的安装方式
    const local = await queryUpdateCheck(false, 'local');
    assert.deepEqual(local, { ...first, install: 'local' });
    assert.equal(calls, 4);
    // force 绕过缓存并刷新
    mockFetch(async (url) => {
      calls += 1;
      if (String(url).includes('api.github.com')) return jsonResponse(500, {});
      return jsonResponse(200, { version: 'v0.6.1' });
    });
    const forced = await queryUpdateCheck(true, 'npm');
    assert.deepEqual(forced, {
      status: 'ok', latest: '0.6.1', url: RELEASES + '/tag/v0.6.1', notes: null, publishedAt: null, install: 'npm',
    });
    assert.equal(calls, 6);
    // 失败不抛错、不覆盖成功缓存
    mockFetch(async () => {
      calls += 1;
      return jsonResponse(500, {});
    });
    const failed = await queryUpdateCheck(true, 'npm');
    assert.deepEqual(failed, { status: 'error', latest: null, url: RELEASES, notes: null, publishedAt: null, install: 'npm' });
    assert.equal(calls, 7);
    const stillCached = await queryUpdateCheck(false, 'npm');
    assert.deepEqual(stillCached, forced);
    assert.equal(calls, 7);
  });

  it('GitHub 说明失败不影响更新检查；非法版本与非 2xx 都归为 error', async () => {
    // npm 成功 + GitHub 失败：仍返回更新，notes/publishedAt 置 null
    mockFetch(async (url) => {
      if (String(url).includes('api.github.com')) return jsonResponse(500, {});
      return jsonResponse(200, { version: '0.6.0' });
    });
    assert.deepEqual(await queryUpdateCheck(true, 'npm'), {
      status: 'ok', latest: '0.6.0', url: RELEASES + '/tag/v0.6.0', notes: null, publishedAt: null, install: 'npm',
    });
    // 非法版本：只打 npm 一次
    mockFetch(async () => jsonResponse(200, { version: 'not-a-version' }));
    assert.deepEqual(await queryUpdateCheck(true, 'npm'), {
      status: 'error', latest: null, url: RELEASES, notes: null, publishedAt: null, install: 'npm',
    });
    mockFetch(async () => jsonResponse(200, {}));
    assert.deepEqual(await queryUpdateCheck(true, 'npm'), {
      status: 'error', latest: null, url: RELEASES, notes: null, publishedAt: null, install: 'npm',
    });
    mockFetch(async () => {
      throw new Error('offline');
    });
    assert.deepEqual(await queryUpdateCheck(true, 'npm'), {
      status: 'error', latest: null, url: RELEASES, notes: null, publishedAt: null, install: 'npm',
    });
  });
});
