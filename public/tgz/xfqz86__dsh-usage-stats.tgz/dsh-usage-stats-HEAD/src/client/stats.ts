/**
 * 用量统计界面的纯函数：格式化、分桶、曲线与热力图几何、模型统计重定向归并。
 * 不依赖 React / DOM，可单测，角标与模态窗共用。
 * 本地日划分、日期键 startOfDay、dateKeyOf、模型键拆分 splitModelKey 与规则完整性
 * isCompleteRedirect 来自 utils.ts；类型 SeriesPoint、UsageAgg、ModelRedirect 来自
 * types.ts，与 host 端共用，避免两端镜像漂移。
 */

import { DAY_MS, SERIES_MAX_DAYS, dateKeyOf, isCompleteRedirect, splitModelKey, startOfDay } from '../utils.ts';

import type { LocaleFn } from './locales.ts';
import type { ModelDetail, ModelRedirect, ModelStat, SeriesPoint, SessionStat, UsageAgg } from '../types.ts';

/** 判断是否为英文环境：支持传入 locale 字符串或翻译函数 t。 */
function isEnglishLocale(localeOrT?: string | LocaleFn): boolean {
  if (typeof localeOrT === 'function') {
    try {
      // 英文的 panel.summary.callsSuffix 为 ''，中文为 '次'
      const v = (localeOrT)('panel.summary.callsSuffix');
      if (v === '') return true;
    } catch { /* 忽略 */ }
    try {
      const v2 = (localeOrT)('footer.todayLabel');
      if (v2 === 'Today') return true;
    } catch { /* 忽略 */ }
    return false;
  }
  if (typeof localeOrT === 'string') {
    return localeOrT.startsWith('en');
  }
  return false;
}

/** 根据数值大小决定保留小数位：>=100 取0位，>=10 取1位，否则2位。 */
function decimals(v: number): number {
  if (v >= 100) return 0;
  if (v >= 10) return 1;
  return 2;
}

/** 紧凑 token 格式化：中文 1.2万 / 3.4亿，英文 1.2K / 3.4M / 1.2B。 */
export function fmt(n: number | null | undefined, localeOrT?: string | LocaleFn): string {
  if (n == null || Number.isNaN(n)) return '--';
  const trim = (v: number, d: number): string => String(v.toFixed(d)).replace(/\.0+$/, '').replace(/(\.\d*[1-9])0+$/, '$1');
  const isEn = isEnglishLocale(localeOrT);
  if (isEn) {
    if (n >= 1e12) { const v = n / 1e12; return trim(v, decimals(v)) + 'T'; }
    if (n >= 1e9) { const v = n / 1e9; return trim(v, decimals(v)) + 'B'; }
    if (n >= 1e6) { const v = n / 1e6; return trim(v, decimals(v)) + 'M'; }
    if (n >= 1e3) { const v = n / 1e3; return trim(v, decimals(v)) + 'K'; }
    return String(Math.round(n));
  }
  if (n >= 1e8) { const v = n / 1e8; return trim(v, decimals(v)) + '亿'; }
  if (n >= 1e4) { const v = n / 1e4; return trim(v, decimals(v)) + '万'; }
  return String(Math.round(n));
}

/** 完整 token 计数，千分位，英文、中文均用 en-US 千分位以保持数字一致性。 */
export function fmtFull(n: number | null | undefined, _localeOrT?: string | LocaleFn): string {
  if (n == null || Number.isNaN(n)) return '--';
  return Math.round(n).toLocaleString('en-US');
}

/** 短会话 id：前 6 位 + … + 后 4 位。 */
export function shortId(id: string): string {
  if (!id) return '--';
  const s = String(id);
  return s.length > 10 ? `${s.slice(0, 6)}…${s.slice(-4)}` : s;
}

/** total = input + output + cacheRead + cacheWrite，reasoning 不计入；缺省/坏值按 0。 */
export function dayTotal(b: SeriesPoint | Partial<UsageAgg>): number {
  return (b.input || 0) + (b.output || 0) + (b.cacheRead || 0) + (b.cacheWrite || 0);
}

export function usageTotal(u: UsageAgg): number {
  return u?.total || 0;
}

export function pctOf(v: number | null | undefined): string {
  return v === null || v === undefined || Number.isNaN(v) ? '--' : v + '%';
}

/** 按会话分组：主会话加其子代理，子代理折叠到主会话，孤儿回落顶层，多级展平到根。 */
export interface SessionGroup {
  main: SessionStat
  children: SessionStat[]
  agg: { calls: number; usage: UsageAgg }
  childCount: number
}

/** 将用量聚合相加，纯函数，返回新 UsageAgg。 */
function addUsage(a: UsageAgg, b: UsageAgg): UsageAgg {
  return {
    input: (a.input || 0) + (b.input || 0),
    output: (a.output || 0) + (b.output || 0),
    cacheRead: (a.cacheRead || 0) + (b.cacheRead || 0),
    cacheWrite: (a.cacheWrite || 0) + (b.cacheWrite || 0),
    reasoning: (a.reasoning || 0) + (b.reasoning || 0),
    total: (a.total || 0) + (b.total || 0),
  };
}

/** 按会话 id 分组：origin 为 subagent 且 parentSession 指向存在会话的子代理折叠到根主会话，孤儿回落顶层，多级展平。 */
export function groupSessions(list: SessionStat[]): SessionGroup[] {
  if (!list || list.length === 0) return [];
  const byId = new Map<string, SessionStat>();
  for (const s of list) byId.set(s.id, s);

  // 判定是否为子代理，需 parent 存在
  const isChild = (s: SessionStat): boolean =>
    s.origin === 'subagent' && typeof s.parentSession === 'string' && s.parentSession !== '' && byId.has(s.parentSession);

  // 找根主会话：从 parent 出发沿链上溯至不再是子代理的节点，多级展平，防环
  const findRoot = (parentId: string): string => {
    let cur = parentId;
    const seen = new Set<string>();
    while (true) {
      if (seen.has(cur)) break;
      seen.add(cur);
      const node = byId.get(cur);
      if (!node) break;
      const parentSession = node.parentSession;
      if (node.origin !== 'subagent' || typeof parentSession !== 'string' || parentSession === '' || !byId.has(parentSession)) break;
      cur = parentSession;
    }
    return cur;
  };

  const childrenMap = new Map<string, SessionStat[]>();
  const mains = new Set<string>();

  for (const s of list) {
    if (isChild(s)) {
      const parentSession = s.parentSession;
      if (typeof parentSession !== 'string' || parentSession === '') {
        mains.add(s.id);
        continue;
      }
      const rootId = findRoot(parentSession);
      if (byId.has(rootId)) {
        const arr = childrenMap.get(rootId);
        if (arr) arr.push(s);
        else childrenMap.set(rootId, [s]);
      } else {
        // 根不存在，理论上 isChild 已保证 parent 存在，此分支仅防御并发或环
        mains.add(s.id);
      }
    } else {
      mains.add(s.id);
    }
  }

  // 构建分组：每个主会话对应一个桶，子列表为归入该主的全部子代理
  const groups: SessionGroup[] = [];
  for (const mainId of mains) {
    const main = byId.get(mainId);
    if (!main) continue;
    const children = childrenMap.get(mainId) ?? [];
    // 子按 lastActive 降序
    children.sort((a, b) => (b.lastActive || 0) - (a.lastActive || 0));
    let calls = main.calls;
    let usage = { ...main.usage };
    for (const ch of children) {
      calls += ch.calls;
      usage = addUsage(usage, ch.usage);
    }
    groups.push({ main, children, agg: { calls, usage }, childCount: children.length });
  }

  // 若某个 childrenMap 的 key 未在 mains 中，如根本身是子代理但被展平到更高根，此情况已处理，剩余未覆盖的根可能是因主被归类为 child 却仍有子，需补漏
  for (const [rootId, children] of childrenMap) {
    if (mains.has(rootId)) continue;
    const main = byId.get(rootId);
    if (!main) continue;
    // root 本身是子代理但因链展平未被视为 main，仍需为其创建分组，兜底
    children.sort((a, b) => (b.lastActive || 0) - (a.lastActive || 0));
    let calls = main.calls;
    let usage = { ...main.usage };
    for (const ch of children) {
      calls += ch.calls;
      usage = addUsage(usage, ch.usage);
    }
    groups.push({ main, children, agg: { calls, usage }, childCount: children.length });
  }

  // 主会话按 lastActive 降序，与 snapshot 保持一致
  groups.sort((a, b) => (b.main.lastActive || 0) - (a.main.lastActive || 0));
  return groups;
}

/** 会话表排序键：面板会话 Tab 与模型明细的按会话表共用，同一列在两处同一比较。 */
export type SessionSortKey = 'session' | 'cacheRead' | 'input' | 'output' | 'total' | 'hitRate' | 'calls' | 'avg' | 'lastActive';

/**
 * 一个分组的折叠会话 id 集合：主会话 + 展平到它下面的全部子代理。
 * 会话明细请求的唯一构造点——明细必须与所点行同源（同一分组），
 * 在点击那一刻取一次并随弹窗冻结，之后不随快照轮询重算（见 `docs/API.md` §2.3）。
 */
export function sessionGroupIds(group: SessionGroup): string[] {
  return [group.main.id, ...group.children.map((child) => child.id)];
}

/**
 * 会话分组排序比较：两处会话表共用，保证同一排序键给出同一顺序。
 * 文本列按标题（缺标题回落 id）比较，数值列一律取折叠后的分组合计（子代理计入主会话）。
 * @param key - 排序键，与表头一一对应。
 * @param a - 左侧分组。
 * @param b - 右侧分组。
 * @returns 比较结果，方向由调用方经 stableSort 应用。
 */
export function compareSessionGroup(key: SessionSortKey, a: SessionGroup, b: SessionGroup): number {
  const agga = a.agg;
  const aggb = b.agg;
  switch (key) {
    case 'session': return (a.main.title || a.main.id || '').localeCompare(b.main.title || b.main.id || '', 'zh-Hans-CN');
    case 'calls': return (agga.calls || 0) - (aggb.calls || 0);
    case 'input': return (agga.usage.input || 0) - (aggb.usage.input || 0);
    case 'output': return (agga.usage.output || 0) - (aggb.usage.output || 0);
    case 'cacheRead': return (agga.usage.cacheRead || 0) - (aggb.usage.cacheRead || 0);
    case 'hitRate': return (hitRateOfDay(agga.usage) ?? -1) - (hitRateOfDay(aggb.usage) ?? -1);
    case 'total': return usageTotal(agga.usage) - usageTotal(aggb.usage);
    case 'avg': return (avgPerCall(usageTotal(agga.usage), agga.calls) ?? -1) - (avgPerCall(usageTotal(aggb.usage), aggb.calls) ?? -1);
    case 'lastActive': return (a.main.lastActive || 0) - (b.main.lastActive || 0);
    default: return 0;
  }
}

/** 本地日划分，utils.ts 单一事实来源。 */
export { startOfDay } from '../utils.ts';
export const dayLabel = (t: number): string => { const d = new Date(t); return (d.getMonth() + 1) + '/' + d.getDate(); };
export const fullDayLabel = (t: number): string => dateKeyOf(t);

/**
 * 最近活跃的自然日分类：按本地日历日比较，今天 / 昨天 / 更早。
 * 昨天用 setDate 回退一天再取零点，夏令时切换日也正确；不能用
 * 「距今不足 24 小时」判定，否则昨天凌晨的会话次日会被误标今天。
 */
export function lastActiveDayKind(lastActive: number, nowMs: number): 'today' | 'yesterday' | 'earlier' {
  const day = startOfDay(lastActive);
  if (day === startOfDay(nowMs)) return 'today';
  const yesterday = new Date(nowMs);
  yesterday.setDate(yesterday.getDate() - 1);
  if (day === startOfDay(yesterday.getTime())) return 'yesterday';
  return 'earlier';
}

/** 取序列中最新一天的点，底部角标读今日数据用。 */
export function todayOf(series: SeriesPoint[]): SeriesPoint | undefined {
  const today = startOfDay(Date.now());
  for (let i = series.length - 1; i >= 0; i--) {
    if (series[i].t === today) return series[i];
    if (series[i].t < today) break;
  }
  return undefined;
}

/** 热力图单个格子的数据，Codex 风格 26 周网格的一格。 */
export interface HeatGridCell {
  /** 当天 0 点时间戳。 */
  t: number
  /** 当天 total tokens，与曲线一致，input+output+cacheRead+cacheWrite。 */
  v: number
  /** 当天调用次数。 */
  calls: number
  /** 强度档 0..4：0 为无用量，底色加边框，1..4 按窗口最大值占比。 */
  lvl: number
  /** 是否今天，外框高亮。 */
  today: boolean
  /** yyyy-mm-dd 标签，tooltip 用。 */
  label: string
}

/** Codex 风格 26 周热力图：列为周，周一至周日自上而下，列优先。 */
export interface HeatGrid {
  /** 周数，列数。 */
  cols: number
  /** 列优先的格子序列：每周 7 格，周一至周日，从最老的一周排到本周。 */
  cells: HeatGridCell[]
  /** 每列即每周的月份标签：0..11 月索引，与上一列同月时为 null，不显示。 */
  months: (number | null)[]
}

/** 由日序列构建 Codex 风格 26 周热力图，列为周，行为周一至周日。 */
export function heatGridOf(series: SeriesPoint[], weeks = 26): HeatGrid {
  const byDate = new Map<string, SeriesPoint>();
  for (const p of series) if (p?.t != null) byDate.set(fullDayLabel(p.t), p);

  const today = startOfDay(Date.now());
  const end = new Date(today);
  // 对齐到本周周日，getDay() 返回周日为 0至周六为 6，(d+6)%7 映射为周一为 0至周日为 6。
  end.setDate(end.getDate() + (6 - ((end.getDay() + 6) % 7)));

  const cells: HeatGridCell[] = [];
  const months: (number | null)[] = [];
  let lastMonth = -1;
  for (let w = weeks - 1; w >= 0; w -= 1) {
    for (let i = 0; i < 7; i += 1) {
      const d = new Date(end);
      d.setDate(d.getDate() - (w * 7 + (6 - i)));
      const label = fullDayLabel(d.getTime());
      const day = byDate.get(label);
      const v = day ? dayTotal(day) : 0;
      cells.push({
        t: d.getTime(), v, calls: day?.calls ?? 0, lvl: 0,
        today: label === fullDayLabel(today), label,
      });
    }
    const m = new Date(end);
    m.setDate(m.getDate() - (w * 7 + 6)); // 该周周一，列首
    months.push(m.getMonth() !== lastMonth ? m.getMonth() : null);
    lastMonth = m.getMonth();
  }

  // 强度 4 档：按窗口内最大值占比分档。
  let max = 1;
  for (const c of cells) if (c.v > max) max = c.v;
  for (const c of cells) {
    if (c.v <= 0) continue;
    const ratio = c.v / max;
    if (ratio < 0.25) c.lvl = 1;
    else if (ratio < 0.5) c.lvl = 2;
    else if (ratio < 0.75) c.lvl = 3;
    else c.lvl = 4;
  }
  return { cols: weeks, cells, months };
}

/**
 * 最近活跃文案：0 表未知；自然日为今天显示「今天 HH:MM」、昨天显示「昨天 HH:MM」，
 * 更早显示完整日期。会话 Tab 与模型明细的会话表共用一份（STYLE §11）。
 */
export function formatLastActive(lastActive: number, t: LocaleFn): string {
  if (!lastActive) return '--';
  const time = new Date(lastActive).toTimeString().slice(0, 5);
  const kind = lastActiveDayKind(lastActive, Date.now());
  if (kind === 'today') return `${t('time.today')} ${time}`;
  if (kind === 'yesterday') return `${t('time.yesterday')} ${time}`;
  return fullDayLabel(lastActive);
}

/** 模型汇总时间范围：全部、1年、半年、3个月、1个月、14天、7天，默认 1 年。 */
export type ModelRange = '7d' | '14d' | '30d' | '90d' | '180d' | '365d' | 'all';

/** 模型范围对应的天数，all 返回 null。 */
export function modelRangeToDays(range: ModelRange): number | null {
  switch (range) {
    case '7d': return 7;
    case '14d': return 14;
    case '30d': return 30;
    case '90d': return 90;
    case '180d': return 180;
    case '365d': return 365;
    case 'all': return null;
    default: return null;
  }
}

/** 模型范围的起始零点，all 返回 null。 */
export function modelRangeCutoff(range: ModelRange): number | null {
  const days = modelRangeToDays(range);
  if (days == null) return null;
  const todayStart = startOfDay(Date.now());
  const d = new Date(todayStart);
  d.setDate(d.getDate() - (days - 1));
  return d.getTime();
}

// ---- 模型统计重定向：按用户规则把来源模型的用量并入目标模型 ----
// 归并在浏览器端做，服务端快照始终是原始行：设置页要拿原始「供应商 + 模型」
// 当规则候选，改规则也要立刻重算，不必等下一次轮询或重启。
// 规则表来自偏好设置（utils.ts 归一化，client/settings.ts 读写），模型页与日期、会话明细的按模型表消费。

/** 模型键：与账本、快照同一口径 `provider\0model`，utils.ts 的 splitModelKey 拆回。 */
function modelKeyOf(provider: string, model: string): string {
  return provider + '\u0000' + model;
}

/** 归并结果：模型行（按 total 降序）+ 每个目标行并进来的来源键，供界面提示。 */
export interface ModelRedirectResult {
  /** 归并后的模型行，无生效规则时原样返回入参数组。 */
  models: ModelStat[]
  /** 目标行键 → 该行并进来的来源键（按原行顺序，不含目标自身）。 */
  mergedSources: Map<string, string[]>
}

/** 规则索引的一条边：目标键 + 该规则在列表里的序号，序号用于环内择优。 */
export interface RedirectEdge {
  to: string
  order: number
}

/**
 * 解析规则链：沿「来源 → 目标」逐跳前进。
 * - 无匹配：该键自己就是目标（不归并）；
 * - 链式（A→B、B→C）：解析到链尾 C；
 * - 环形（A→B、B→A）：把环折到环内**最靠前那条规则的目标**上，即按列表顺序取优先级，
 *   与「同一来源只有最上面一条生效」同一口径，既不会死循环，也不会把用量改名换姓。
 */
export function resolveRedirectKey(key: string, index: ReadonlyMap<string, RedirectEdge>): string {
  const path: string[] = [];
  const seen = new Map<string, number>();
  let current = key;
  for (;;) {
    const repeated = seen.get(current);
    if (repeated !== undefined) {
      // current 是环入口：环上的边是 path[repeated..]，取序号最小者的目标作为归并目标
      let representative = current;
      let bestOrder = Number.POSITIVE_INFINITY;
      for (let i = repeated; i < path.length; i += 1) {
        const edge = index.get(path[i]);
        if (edge !== undefined && edge.order < bestOrder) {
          bestOrder = edge.order;
          representative = edge.to;
        }
      }
      return representative;
    }
    seen.set(current, path.length);
    path.push(current);
    const edge = index.get(current);
    if (edge === undefined) return current;
    current = edge.to;
  }
}

/** 建规则索引：跳过不完整规则与自反规则，同一来源只认最上面一条（列表顺序即优先级）。 */
function redirectIndexOf(rules: readonly ModelRedirect[]): Map<string, RedirectEdge> {
  const index = new Map<string, RedirectEdge>();
  for (const rule of rules) {
    if (!isCompleteRedirect(rule)) continue;
    const from = modelKeyOf(rule.fromProvider, rule.fromModel);
    const to = modelKeyOf(rule.toProvider, rule.toModel);
    if (from === to || index.has(from)) continue;
    index.set(from, { to, order: index.size });
  }
  return index;
}

/** 归并累加器：用量各字段与调用数求和，日序列按天求和。 */
interface RedirectAcc {
  usage: UsageAgg
  calls: number
  series: Map<number, SeriesPoint>
}

/**
 * 应用模型统计重定向：命中规则的来源行并入目标行——用量各字段与调用数求和、
 * 按日序列逐日求和（total 与 host 同口径，等于四段之和，不含 reasoning）；
 * 目标行在快照里不存在时按规则里的名字新建，只有真有用量才出现。
 * 没有一行命中时原样返回入参数组（引用不变，未配规则的行为逐字节一致）。
 */
export function redirectModels(models: ModelStat[], rules: readonly ModelRedirect[]): ModelRedirectResult {
  const index = redirectIndexOf(rules);
  const keys = models.map((m) => modelKeyOf(m.provider, m.model));
  const targets = keys.map((key) => resolveRedirectKey(key, index));
  if (targets.every((target, i) => target === keys[i])) {
    return { models, mergedSources: new Map() };
  }

  const accs = new Map<string, RedirectAcc>();
  const mergedSources = new Map<string, string[]>();
  for (let i = 0; i < models.length; i += 1) {
    const m = models[i];
    const target = targets[i];
    let acc = accs.get(target);
    if (acc === undefined) {
      acc = {
        usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: 0 },
        calls: 0,
        series: new Map(),
      };
      accs.set(target, acc);
    }
    acc.usage.input += m.usage.input || 0;
    acc.usage.output += m.usage.output || 0;
    acc.usage.cacheRead += m.usage.cacheRead || 0;
    acc.usage.cacheWrite += m.usage.cacheWrite || 0;
    acc.usage.reasoning += m.usage.reasoning || 0;
    acc.usage.total += m.usage.total || 0;
    acc.calls += m.calls || 0;
    for (const pt of m.series ?? []) {
      const day = acc.series.get(pt.t);
      if (day === undefined) {
        acc.series.set(pt.t, { ...pt });
        continue;
      }
      day.input += pt.input || 0;
      day.output += pt.output || 0;
      day.cacheRead += pt.cacheRead || 0;
      day.cacheWrite += pt.cacheWrite || 0;
      day.reasoning += pt.reasoning || 0;
      day.calls += pt.calls || 0;
    }
    if (target !== keys[i]) {
      const list = mergedSources.get(target);
      if (list === undefined) mergedSources.set(target, [keys[i]]);
      else list.push(keys[i]);
    }
  }

  const out: ModelStat[] = [];
  for (const [key, acc] of accs) {
    const { provider, model } = splitModelKey(key);
    out.push({
      provider,
      model,
      calls: acc.calls,
      usage: acc.usage,
      series: [...acc.series.values()].sort((a, b) => a.t - b.t),
    });
  }
  out.sort((a, b) => usageTotal(b.usage) - usageTotal(a.usage));
  return { models: out, mergedSources };
}

/**
 * 合并同一模型行的多份明细：模型统计重定向把若干来源并进一行，明细按来源各查一次，
 * 这里求和还原成一行——用量各字段与调用数相加，日序列按本地日相加，会话行按 id 相加
 * （最后活跃取最大，标题 / cwd / 创建时间与子代理归属取首个非空，层级取最大）。
 * 入参为空返回 null，调用方据此显示空态。
 */
export function mergeModelDetails(
  details: readonly ModelDetail[],
  target: { provider: string; model: string },
): ModelDetail | null {
  if (details.length === 0) return null;
  const usage: UsageAgg = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, total: 0 };
  let calls = 0;
  const days = new Map<number, SeriesPoint>();
  const sessions = new Map<string, SessionStat>();
  for (const detail of details) {
    usage.input += detail.usage.input || 0;
    usage.output += detail.usage.output || 0;
    usage.cacheRead += detail.usage.cacheRead || 0;
    usage.cacheWrite += detail.usage.cacheWrite || 0;
    usage.reasoning += detail.usage.reasoning || 0;
    usage.total += detail.usage.total || 0;
    calls += detail.calls || 0;
    for (const pt of detail.daily) {
      const day = days.get(pt.t);
      if (day === undefined) {
        days.set(pt.t, { ...pt });
        continue;
      }
      day.input += pt.input || 0;
      day.output += pt.output || 0;
      day.cacheRead += pt.cacheRead || 0;
      day.cacheWrite += pt.cacheWrite || 0;
      day.reasoning += pt.reasoning || 0;
      day.calls += pt.calls || 0;
    }
    for (const row of detail.sessions) {
      const merged = sessions.get(row.id);
      if (merged === undefined) {
        sessions.set(row.id, { ...row, usage: { ...row.usage } });
        continue;
      }
      merged.calls += row.calls || 0;
      merged.usage.input += row.usage.input || 0;
      merged.usage.output += row.usage.output || 0;
      merged.usage.cacheRead += row.usage.cacheRead || 0;
      merged.usage.cacheWrite += row.usage.cacheWrite || 0;
      merged.usage.reasoning += row.usage.reasoning || 0;
      merged.usage.total += row.usage.total || 0;
      if ((row.lastActive || 0) > (merged.lastActive || 0)) merged.lastActive = row.lastActive;
      if (!merged.title && row.title) merged.title = row.title;
      if (!merged.cwd && row.cwd) merged.cwd = row.cwd;
      if (!merged.createdAt && row.createdAt) merged.createdAt = row.createdAt;
      if (merged.parentSession === null && row.parentSession !== null) merged.parentSession = row.parentSession;
      if (merged.origin === null && row.origin !== null) merged.origin = row.origin;
      if ((row.delegationDepth || 0) > (merged.delegationDepth || 0)) merged.delegationDepth = row.delegationDepth;
    }
  }
  return {
    provider: target.provider,
    model: target.model,
    calls,
    usage,
    daily: [...days.values()].sort((a, b) => a.t - b.t),
    sessions: [...sessions.values()].sort((a, b) => (b.usage.total - a.usage.total) || a.id.localeCompare(b.id)),
  };
}

/**
 * 账本里的供应商 → 模型清单（各自去重、按字母序，供应商同样按字母序），
 * 设置页规则编辑器的自动完成候选以它为底：服务端快照不归并，这里拿到的就是真实来源。
 */
export function modelCatalog(models: readonly ModelStat[]): Map<string, string[]> {
  const catalog = new Map<string, string[]>();
  for (const m of models) {
    const list = catalog.get(m.provider);
    if (list === undefined) catalog.set(m.provider, [m.model]);
    else if (!list.includes(m.model)) list.push(m.model);
  }
  for (const list of catalog.values()) list.sort();
  return new Map([...catalog].sort((a, b) => a[0].localeCompare(b[0])));
}

/**
 * 按已用来源组合过滤候选：去掉 `used` 里已占用的「供应商 + 模型」，
 * 模型被用光的供应商整条不再出现——同一来源只有最上面一条规则生效，
 * 已配过的组合再选一次没有意义，来源的自动完成里就不该再出现。
 */
export function unusedRedirectSources(
  catalog: ReadonlyMap<string, string[]>,
  used: ReadonlySet<string>,
): Map<string, string[]> {
  const out = new Map<string, string[]>();
  for (const [provider, models] of catalog) {
    const free = models.filter((model) => !used.has(modelKeyOf(provider, model)));
    if (free.length > 0) out.set(provider, free);
  }
  return out;
}

/** 按时间范围过滤模型：基于各模型的 series 按日聚合，返回排序后的切片。 */
export function filterModelsByRange(models: ModelStat[], range: ModelRange): ModelStat[] {
  if (range === 'all') {
    return [...models].sort((a, b) => usageTotal(b.usage) - usageTotal(a.usage));
  }
  const cutoff = modelRangeCutoff(range);
  if (cutoff == null) return [...models].sort((a, b) => usageTotal(b.usage) - usageTotal(a.usage));
  const out: ModelStat[] = [];
  for (const m of models) {
    const series = (m as { series?: SeriesPoint[] }).series ?? [];
    // 没有按日序列（明细类接口不带 series）时该范围下置 0，避免误用全量
    if (!series || series.length === 0) continue;
    let input = 0; let output = 0; let cacheRead = 0; let cacheWrite = 0; let reasoning = 0; let total = 0; let calls = 0;
    const filteredSeries: SeriesPoint[] = [];
    for (const pt of series) {
      if ((pt.t ?? 0) >= cutoff) {
        filteredSeries.push(pt);
        input += pt.input || 0;
        output += pt.output || 0;
        cacheRead += pt.cacheRead || 0;
        cacheWrite += pt.cacheWrite || 0;
        reasoning += pt.reasoning || 0;
        total += (pt.input || 0) + (pt.output || 0) + (pt.cacheRead || 0) + (pt.cacheWrite || 0);
        calls += pt.calls || 0;
      }
    }
    if (total <= 0 && calls <= 0) continue;
    out.push({
      provider: m.provider,
      model: m.model,
      calls,
      usage: { input, output, cacheRead, cacheWrite, reasoning, total },
      series: filteredSeries,
    });
  }
  out.sort((a, b) => usageTotal(b.usage) - usageTotal(a.usage));
  return out;
}

/** 模型堆叠柱：为给定范围生成按日堆叠数据，横向滚动。 */
export interface ModelStackDay {
  t: number
  label: string
  total: number
  segments: { provider: string; model: string; total: number; calls: number }[]
}
export interface ModelStack {
  days: ModelStackDay[]
  maxTotal: number
  models: { provider: string; model: string }[]
}
export function buildModelStack(models: ModelStat[], range: ModelRange): ModelStack {
  const filtered = filterModelsByRange(models, range);
  // 维持与饼图一致的模型顺序，按过滤后 total 降序，堆叠自底向上按此顺序
  const modelOrder = filtered.map((m) => ({ provider: m.provider, model: m.model }));
  const byKey = new Map<string, ModelStat>();
  for (const m of filtered) byKey.set(m.provider + '\u0000' + m.model, m);
  // 生成日桶：与 buildDateStack 同款日历推进，避免 DST 漂移
  const days: number[] = [];
  const cutoff = modelRangeCutoff(range);
  if (cutoff != null) {
    const d = new Date(cutoff);
    const todayStart = startOfDay(Date.now());
    const n = modelRangeToDays(range) ?? 0;
    for (let i = 0; i < n; i += 1) {
      days.push(d.getTime());
      d.setDate(d.getDate() + 1);
      if (d.getTime() > todayStart) break;
    }
    // 保证包含今天
    if (days.length > 0 && days[days.length - 1] !== todayStart) {
      // 若 n 计算与 cutoff 略有偏差，补齐到今天，极少数 DST 边界
      const last = days[days.length - 1];
      const diff = Math.round((todayStart - last) / DAY_MS);
      if (diff > 0 && diff < 3) {
        for (let k = 1; k <= diff; k += 1) {
          const dd = new Date(last);
          dd.setDate(dd.getDate() + k);
          days.push(dd.getTime());
        }
      }
    }
  } else {
    // all：从最早一天到今天
    let earliest = Infinity;
    for (const m of filtered) {
      const s = (m as { series?: SeriesPoint[] }).series ?? [];
      for (const pt of s) if (pt.t < earliest) earliest = pt.t;
    }
    if (!Number.isFinite(earliest)) {
      // 无过滤后数据时回落到全量最早日或今天
      if (filtered.length === 0) return { days: [], maxTotal: 1, models: [] };
      earliest = startOfDay(Date.now());
    } else {
      earliest = startOfDay(earliest);
    }
    const todayStart = startOfDay(Date.now());
    let span = Math.max(1, Math.round((todayStart - earliest) / DAY_MS) + 1);
    // 限制最多一年宽度（共享上限，闰年 366 天），避免“全部”范围过宽
    if (span > SERIES_MAX_DAYS) {
      span = SERIES_MAX_DAYS;
      const d0 = new Date(todayStart);
      d0.setDate(d0.getDate() - (SERIES_MAX_DAYS - 1));
      earliest = d0.getTime();
    }
    const d = new Date(earliest);
    for (let i = 0; i < span; i += 1) {
      days.push(d.getTime());
      d.setDate(d.getDate() + 1);
    }
  }
  // 按日构建堆叠
  const byModelDay = new Map<string, Map<number, number>>();
  for (const m of filtered) {
    const key = m.provider + '\u0000' + m.model;
    const mp = new Map<number, number>();
    const s = (m as { series?: SeriesPoint[] }).series ?? [];
    for (const pt of s) mp.set(pt.t, dayTotal(pt));
    byModelDay.set(key, mp);
  }
  const stackDays: ModelStackDay[] = [];
  let maxTotal = 1;
  for (const t of days) {
    const segs: ModelStackDay['segments'] = [];
    let total = 0;
    for (const m of filtered) {
      const key = m.provider + '\u0000' + m.model;
      const mp = byModelDay.get(key);
      const v = mp?.get(t) ?? 0;
      if (v > 0) segs.push({ provider: m.provider, model: m.model, total: v, calls: 0 });
      total += v;
    }
    // 填充 calls，可选，tooltip 用
    for (const seg of segs) {
      const key = seg.provider + '\u0000' + seg.model;
      const mm = byKey.get(key);
      const s = (mm as { series?: SeriesPoint[] })?.series ?? [];
      const pt = s.find((p) => p.t === t);
      seg.calls = pt?.calls ?? 0;
    }
    // 自底向上保持 filtered 顺序
    stackDays.push({ t, label: dayLabel(t), total, segments: segs });
    if (total > maxTotal) maxTotal = total;
  }
  return { days: stackDays, maxTotal, models: modelOrder };
}

/** 日期范围，与模型范围同款枚举，日期 Tab 对齐 ModelsTab 的 7 档，含 1 年。 */
export type DateRange = '7d' | '14d' | '30d' | '90d' | '180d' | '365d' | 'all';

/** 日期范围对应的天数，all 返回 null，复用模型范围逻辑保持一致。 */
export function dateRangeToDays(range: DateRange): number | null {
  return modelRangeToDays(range);
}

/** 日期范围的起始零点，all 返回 null。 */
export function dateRangeCutoff(range: DateRange): number | null {
  return modelRangeCutoff(range);
}

/** 日期堆叠柱 token 键，与 UsageAgg 分量对应；日期趋势展示层仅用其中 input、output、cacheRead 三段。 */
export type DateTokenKey = 'input' | 'output' | 'cacheRead' | 'cacheWrite' | 'reasoning';

/** 日期堆叠柱的 token 类型与配色：趋势图仅展示输入、输出、缓存三段，缓存写入与推理不在此展示。 */
export const DATE_TOKEN_META: readonly { key: DateTokenKey; label: string; color: string }[] = [
  { key: 'input', label: '输入', color: '#4d6bfe' },
  { key: 'output', label: '输出', color: '#00b894' },
  { key: 'cacheRead', label: '缓存', color: '#fdcb6e' },
];

/** 缓存命中率折线颜色：避开 MODEL_PALETTE 十色，跨 Tab 不与模型饼图/堆叠色重叠；仅 date 模式出现。
 * AGENTS §3 的 design-token 约束针对界面静态样式，图表数据色豁免见 MODEL_PALETTE 注释。 */
export const HIT_RATE_COLOR = '#ff4757';

/** 缓存命中率：cacheRead 除以 cacheRead 与 input 之和乘 100，保留 1 位小数，分母为 0 时为 null 断点。 */
export function hitRateOfDay(d: { input?: number | null; cacheRead?: number | null }): number | null {
  const input = d.input ?? 0;
  const cacheRead = d.cacheRead ?? 0;
  const denom = input + cacheRead;
  if (denom <= 0) return null;
  return Math.round((cacheRead / denom) * 1000) / 10;
}

/** 平均每次调用：total / calls 取整；calls 为 0 时为 null。日期/会话/模型三表共用同一口径。 */
export function avgPerCall(total: number, calls: number): number | null {
  if (!calls || calls <= 0) return null;
  return Math.round(total / calls);
}

/** 本地化的日期堆叠元信息：趋势图仅返回输入、输出、缓存三段，未传 t 时回落中文。 */
export function getDateTokenMeta(t?: LocaleFn): readonly { key: DateTokenKey; label: string; color: string }[] {
  if (!t) return DATE_TOKEN_META;
  try {
    return [
      { key: 'input', label: t('table.input'), color: '#4d6bfe' },
      { key: 'output', label: t('table.output'), color: '#00b894' },
      { key: 'cacheRead', label: t('table.cacheRead'), color: '#fdcb6e' },
    ];
  } catch {
    return DATE_TOKEN_META;
  }
}

/** 日期堆叠柱：每日一柱，按 token 类型堆叠。 */
export interface DateStackDay {
  /** 当天 0 点时间戳。 */
  t: number
  /** 轴标签，月、日。 */
  label: string
  /** 当天 total，input+output+cacheRead+cacheWrite，不含 reasoning */
  total: number
  /** 当天调用次数 */
  calls: number
  /** 各分量，用于 tooltip、表格 */
  input: number
  output: number
  cacheRead: number
  cacheWrite: number
  reasoning: number
  /** 按 token 类型的分段，仅值大于 0 的段，避免渲染空层。 */
  segments: { key: DateTokenKey; label: string; value: number; color: string }[]
}

export interface DateStack {
  days: DateStackDay[]
  maxTotal: number
}

/** 由日序列构建日期堆叠柱数据，横向滚动，复用 buildModelStack 的日历推进逻辑避免 DST 漂移。 */
export function buildDateStack(series: SeriesPoint[], range: DateRange, localeT?: LocaleFn): DateStack {
  const byDate = new Map<number, SeriesPoint>();
  for (const p of series) if (p?.t != null) byDate.set(p.t, p);
  const days: number[] = [];
  const cutoff = dateRangeCutoff(range);
  if (cutoff != null) {
    const d = new Date(cutoff);
    const todayStart = startOfDay(Date.now());
    const n = dateRangeToDays(range) ?? 0;
    for (let i = 0; i < n; i += 1) {
      days.push(d.getTime());
      d.setDate(d.getDate() + 1);
      if (d.getTime() > todayStart) break;
    }
    if (days.length > 0 && days[days.length - 1] !== todayStart) {
      const last = days[days.length - 1];
      const diff = Math.round((todayStart - last) / DAY_MS);
      if (diff > 0 && diff < 3) {
        for (let k = 1; k <= diff; k += 1) {
          const dd = new Date(last);
          dd.setDate(dd.getDate() + k);
          days.push(dd.getTime());
        }
      }
    }
  } else {
    // all：从最早一天到今天
    let earliest = Infinity;
    for (const p of series) if (p.t != null && p.t < earliest) earliest = p.t;
    if (!Number.isFinite(earliest)) {
      return { days: [], maxTotal: 1 };
    }
    earliest = startOfDay(earliest);
    const todayStart = startOfDay(Date.now());
    let span = Math.max(1, Math.round((todayStart - earliest) / DAY_MS) + 1);
    // 与模型堆叠同款一年上限（共享常量），避免“全部”范围过宽
    if (span > SERIES_MAX_DAYS) {
      span = SERIES_MAX_DAYS;
      const d0 = new Date(todayStart);
      d0.setDate(d0.getDate() - (SERIES_MAX_DAYS - 1));
      earliest = d0.getTime();
    }
    const d = new Date(earliest);
    for (let i = 0; i < span; i += 1) {
      days.push(d.getTime());
      d.setDate(d.getDate() + 1);
    }
  }
  const stackDays: DateStackDay[] = [];
  let maxTotal = 1;
  for (const t of days) {
    const pt = byDate.get(t);
    const input = pt?.input ?? 0;
    const output = pt?.output ?? 0;
    const cacheRead = pt?.cacheRead ?? 0;
    const cacheWrite = pt?.cacheWrite ?? 0;
    const reasoning = pt?.reasoning ?? 0;
    const calls = pt?.calls ?? 0;
    const total = dayTotal(pt ?? { input, output, cacheRead, cacheWrite, reasoning, calls, t });
    const segs: DateStackDay['segments'] = [];
    const metaList = getDateTokenMeta(localeT);
    const tokenValues: Record<DateTokenKey, number> = { input, output, cacheRead, cacheWrite, reasoning };
    for (const meta of metaList) {
      const v = tokenValues[meta.key];
      if (v > 0) segs.push({ key: meta.key, label: meta.label, value: v, color: meta.color });
    }
    // 高度基准：仅按展示三段求和，不含缓存写入与推理；total 口径保持 dayTotal 不变，仅展示层过滤
    const visibleSum = input + output + cacheRead;
    if (visibleSum > maxTotal) maxTotal = visibleSum;
    stackDays.push({ t, label: dayLabel(t), total, calls, input, output, cacheRead, cacheWrite, reasoning, segments: segs });
  }
  if (stackDays.length === 0) return { days: [], maxTotal: 1 };
  return { days: stackDays, maxTotal: Math.max(1, maxTotal) };
}

/**
 * 图表数据驱动的系列配色，10 色循环，与热力图、三色条区分。
 * 说明：AGENTS §3 的「颜色一律 design token」针对界面静态样式；图表系列色
 * 是数据驱动调色板，同一颜色同时喂给 SVG fill 属性，CSS var() 在 fill
 * 属性中不解析，与 HTML 背景，故以 hex 字面量集中定义于此（MODEL_PALETTE、
 * DATE_TOKEN_META、HIT_RATE_COLOR 三处豁免之一）；调整系列配色只改这一处。
 */
export const MODEL_PALETTE = [
  '#4d6bfe',
  '#00b894',
  '#fdcb6e',
  '#e17055',
  '#a29bfe',
  '#fd79a8',
  '#00cec9',
  '#e84393',
  '#0984e3',
  '#6c5ce7',
] as const;
export function modelColorAt(index: number): string {
  return MODEL_PALETTE[index % MODEL_PALETTE.length];
}

/** 饼图几何：输入过滤后模型列表，输出扇区路径与占比。 */
export interface PieSlice {
  provider: string
  model: string
  total: number
  share: number
  startAngle: number
  endAngle: number
  path: string
  color: string
}
/** 饼图整圆判定容差：扇区扫角与 2π 的差小于该值视为覆盖整圆，浮点累计误差加浏览器零长弧省略防护。 */
export const PIE_FULL_EPSILON = 1e-6;

/**
 * 单一扇区覆盖整圆时返回该切片，否则返回 null。
 * SVG 弧的起终点重合即被整体省略、近似重合时各浏览器渲染不定，
 * 故组件层须对返回的切片改绘 <circle> 而非 path。
 */
export function pieFullCircleOf(slices: PieSlice[]): PieSlice | null {
  let best: PieSlice | null = null;
  for (const s of slices) {
    if (s.endAngle - s.startAngle >= Math.PI * 2 - PIE_FULL_EPSILON) best = s;
  }
  return best;
}

/**
 * 最大余数法占比：原始百分比配分到 0.1 精度并把余数按小数部分降序逐个补
 * 0.1%，保证总和恰为 100；饼图与模型表共用同一口径。
 */
export function largestRemainderPcts(raws: number[]): number[] {
  const floors = raws.map((v) => Math.floor(v * 10) / 10);
  const sumFloorsTenths = floors.reduce((a, b) => a + Math.round(b * 10), 0);
  const remainingTenths = 1000 - sumFloorsTenths;
  const order = raws.map((v, i) => ({ i, frac: v * 10 - Math.floor(v * 10) })).sort((a, b) => b.frac - a.frac);
  const shares = [...floors];
  for (let k = 0; k < remainingTenths && k < order.length; k += 1) {
    const idx = order[k].i;
    shares[idx] = Math.round((shares[idx] + 0.1) * 10) / 10;
  }
  return shares;
}

export function pieSlicesOf(models: ModelStat[]): PieSlice[] {
  const sum = models.reduce((s, m) => s + usageTotal(m.usage), 0);
  if (sum <= 0 || models.length === 0) return [];
  // 与 ModelsTab 表格一致：最大余数法 1 位小数占比，保证总和 100%
  const shares = largestRemainderPcts(models.map((m) => (usageTotal(m.usage) / sum) * 100));
  // 角度分配：按 raws 精确比例，避免 0.1% 舍入导致角度总和偏差
  let angle = -Math.PI / 2; // 从 12 点钟开始
  const slices: PieSlice[] = [];
  for (let i = 0; i < models.length; i += 1) {
    const m = models[i];
    const frac = usageTotal(m.usage) / sum;
    const sweep = frac * Math.PI * 2;
    const startAngle = angle;
    const endAngle = angle + sweep;
    // SVG 扇区路径，r 为 50，中心 60,60
    const r = 50;
    const cx = 60; const cy = 60;
    const x1 = cx + r * Math.cos(startAngle);
    const y1 = cy + r * Math.sin(startAngle);
    const x2 = cx + r * Math.cos(endAngle);
    const y2 = cy + r * Math.sin(endAngle);
    const largeArc = sweep > Math.PI ? 1 : 0;
    const path = `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`;
    slices.push({
      provider: m.provider,
      model: m.model,
      total: usageTotal(m.usage),
      share: shares[i] ?? 0,
      startAngle,
      endAngle,
      path,
      color: modelColorAt(i),
    });
    angle = endAngle;
  }
  return slices;
}
