/**
 * 偏好设置的 React hook（浏览器端）。
 *
 * 取值来自服务端 profile 配置文档（经设置表单，见 settings.ts），
 * 用 useSyncExternalStore 订阅表单快照：表单未就绪时先渲染默认值，
 * 服务端取值到达后自动刷新；写入走 updateUsageSettings 落配置文档，
 * 于是刷新页面、换浏览器、换机器都保持同一份偏好。
 *
 * 返回 [settings, update]：update 接受 Partial 局部合并并做夹取后写回。
 * 设置页另用 useUsageSettingsView 读存储状态，只在配置不可读/不可写时提示一行。
 */

import { useCallback, useSyncExternalStore } from 'react';

import { subscribeUsageSettings, updateUsageSettings, usageSettingsView } from './settings.ts';

import type { UsageSettingsView } from './settings.ts';
import type { UsageSettings } from '../types.ts';

/** 偏好设置 hook：读取即订阅服务端设置文档，同时支持三组额度偏好与会话徽标开关。 */
export function useUsageSettings(): [UsageSettings, (patch: Partial<UsageSettings>) => void] {
  const view = useSyncExternalStore(subscribeUsageSettings, usageSettingsView, usageSettingsView);
  const update = useCallback((patch: Partial<UsageSettings>) => {
    updateUsageSettings(patch);
  }, []);
  return [view.settings, update];
}

/** 偏好存储状态 hook：设置页据此在配置不可读/不可写时提示改动不会保存。 */
export function useUsageSettingsView(): UsageSettingsView {
  return useSyncExternalStore(subscribeUsageSettings, usageSettingsView, usageSettingsView);
}
