/**
 * 富内容 Tooltip：为需要多行排版或跟随鼠标的气泡提供 `content` 插槽与 `follow` 定位。
 * 基座 `@deepseek-ai/dsh-client-ui-primitives` 的 Tooltip 只接受纯文本 `label`，
 * 而本插件的额度明细、热力图单元格、比例条与归并来源标记需要多行排版；纯文字提示仍用基座。
 *
 * - `content` 插槽接受任意 React 节点或惰性求值函数，气泡容器用 div 支持块级排版；
 * - `follow` 让气泡水平跟随鼠标，用于比例条这类横向细长锚点。
 *
 * 用法：`<Tooltip content={() => <MyPanel />} side="top" delayMs={300}><span>…</span></Tooltip>`；
 * 样式见 `./Tooltip.module.css`。
 */

import { cloneElement, useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';

import css from './Tooltip.module.css';

import type { FocusEventHandler, MouseEventHandler, MutableRefObject, ReactElement, ReactNode, Ref } from 'react';

/** 气泡相对锚点的方位。 */
export type TooltipSide = 'right' | 'bottom' | 'top';

/** Tooltip 向锚点子元素注入的受控属性；子元素原有回调会在其前链式调用。 */
interface AnchorProps {
  ref?: Ref<HTMLElement> | undefined
  onMouseEnter?: MouseEventHandler | undefined
  onMouseMove?: MouseEventHandler | undefined
  onMouseLeave?: MouseEventHandler | undefined
  onFocus?: FocusEventHandler | undefined
  onBlur?: FocusEventHandler | undefined
}

/** 富内容插槽：任意 React 排版或惰性求值函数，仅在气泡可见时求值。 */
type TooltipContent = ReactNode | (() => ReactNode);

export function Tooltip({
  content,
  side,
  delayMs = 0,
  disabled = false,
  maxWidth,
  follow = false,
  children,
}: {
  /** 富内容插槽，任意组件排版。支持函数以惰性求值。 */
  content?: TooltipContent
  /** 相对锚点的方位，默认跟随时为 'bottom'，非跟随时为 'right'。 */
  side?: TooltipSide
  /** hover 延迟，单位毫秒，键盘聚焦仍立即显示。 */
  delayMs?: number
  /** 为 true 时抑制气泡；锚点仍原样渲染，避免切换时重挂导致过渡中断。 */
  disabled?: boolean
  /** 气泡宽度上限，单位像素，用于长文案超出默认 50vw 的场景。 */
  maxWidth?: number
  /** 为 true 时水平跟随鼠标；为 false 时为普通锚点定位。 */
  follow?: boolean
  /** 单个锚点元素；其原有 ref 为回调或对象，会与 Tooltip 的 ref 一并转发。 */
  children: ReactElement<AnchorProps>
}) {
  const anchor = useRef<HTMLElement | null>(null);
  // React 18 的 ref 不在 props 中，显式转发以避免包裹锚点后静默切断宿主 ref。
  const childRef = (children as ReactElement<AnchorProps> & { ref?: Ref<HTMLElement> }).ref;
  const mergedRef = useCallback((el: HTMLElement | null) => {
    anchor.current = el;
    if (typeof childRef === 'function') childRef(el);
    else if (childRef != null) (childRef as MutableRefObject<HTMLElement | null>).current = el;
  }, [childRef]);

  // 实际方位：未显式传入时，跟随态默认 'bottom'，普通态默认 'right'。
  const effectiveSide: TooltipSide = side ?? (follow ? 'bottom' : 'right');

  // 锚点边缘而非最终坐标：垂直翻转需基于对侧边缘重算气泡 top。
  const [pos, setPos] = useState<{ x: number; top: number; bottom: number } | null>(null);
  // 气泡实际方位，默认按请求 side，视口放不下时翻转。
  const [placement, setPlacement] = useState<TooltipSide>(effectiveSide);
  const bubble = useRef<HTMLDivElement | null>(null);
  const lastClientX = useRef<number>(0);

  // 插槽解析：函数仅在气泡可见时求值，避免每次渲染开销。
  const raw: TooltipContent | undefined = content;
  function getResolved(): ReactNode {
    if (pos === null) return null;
    if (raw === undefined) return null;
    if (typeof raw === 'function') return (raw as () => ReactNode)();
    return raw;
  }
  const resolved: ReactNode = getResolved();

  const isEmpty = resolved === null || resolved === undefined || resolved === '' || (typeof resolved === 'string' && resolved.trim() === '');

  function getY(): number {
    if (pos === null) return 0;
    if (placement === 'right') return pos.top + (pos.bottom - pos.top) / 2;
    if (placement === 'top') return pos.top - 8;
    return pos.bottom + 8;
  }
  const y = getY();

  const EDGE_MARGIN = 12;

  // 视口自适应：fixed 定位不感知边缘，靠近右边缘的气泡需水平内收，
  // 顶部/底部放不下时翻转到对侧，仅当对侧确实能放下时才翻转，避免震荡。
  // 每次先重置 base left，再度量，确保短文案或大视口能释放此前的偏移。
  useLayoutEffect(() => {
    if (pos === null) return;
    const fit = () => {
      const el = bubble.current;
      /* v8 ignore next -- pos 仅在气泡挂载时设置 */
      if (el === null) return;
      el.style.left = `${pos.x}px`;
      const r = el.getBoundingClientRect();
      let dx = 0;
      if (r.right > window.innerWidth - EDGE_MARGIN) dx = window.innerWidth - EDGE_MARGIN - r.right;
      if (r.left + dx < EDGE_MARGIN) dx = EDGE_MARGIN - r.left;
      el.style.left = `${pos.x + dx}px`;
      if (effectiveSide === 'right') return;
      const fitsBelow = pos.bottom + 8 + r.height <= window.innerHeight - EDGE_MARGIN;
      const fitsAbove = pos.top - 8 - r.height >= EDGE_MARGIN;
      if (placement === 'bottom' && !fitsBelow && fitsAbove) setPlacement('top');
      if (placement === 'top' && !fitsAbove && fitsBelow) setPlacement('bottom');
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, [effectiveSide, placement, pos, resolved]);

  const showTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // hover 与 focus 为独立触发：仅当两者皆清除时才隐藏气泡。
  const triggers = useRef({ hover: false, focus: false });

  const cancelShow = useCallback(() => {
    if (showTimer.current === null) return;
    clearTimeout(showTimer.current);
    showTimer.current = null;
  }, []);

  useEffect(() => {
    if (disabled) {
      cancelShow();
      triggers.current = { hover: false, focus: false };
      setPos(null);
    }
    return cancelShow;
  }, [cancelShow, disabled]);

  // 同步外部 side 变化到 placement，下次 show 时也会重置，此处保证受控更新及时。
  useEffect(() => {
    setPlacement(effectiveSide);
  }, [effectiveSide]);

  // 跟随时：用鼠标 X 作为气泡 left；非跟随时：用锚点几何居中/右侧。
  const computeFollowPos = useCallback((clientX: number) => {
    const el = anchor.current;
    if (el === null) return null;
    const r = el.getBoundingClientRect();
    return { x: clientX, top: r.top, bottom: r.bottom };
  }, []);

  const computeFixedPos = useCallback(() => {
    const el = anchor.current;
    if (el === null) return null;
    const r = el.getBoundingClientRect();
    return { x: effectiveSide === 'right' ? r.right + 10 : r.left + r.width / 2, top: r.top, bottom: r.bottom };
  }, [effectiveSide]);

  const show = useCallback((clientX?: number) => {
    if (disabled) return;
    if (follow) {
      const cx = clientX ?? lastClientX.current;
      const p = computeFollowPos(cx);
      if (p === null) return;
      setPlacement(effectiveSide);
      setPos(p);
      return;
    }
    const p = computeFixedPos();
    if (p === null) return;
    setPlacement(effectiveSide);
    setPos(p);
  }, [computeFixedPos, computeFollowPos, disabled, effectiveSide, follow]);

  const showAfterHoverDelay = useCallback((clientX?: number) => {
    cancelShow();
    if (delayMs <= 0) {
      show(clientX);
      return;
    }
    showTimer.current = setTimeout(() => {
      showTimer.current = null;
      show(clientX);
    }, delayMs);
  }, [cancelShow, delayMs, show]);

  const hide = useCallback(() => {
    cancelShow();
    if (!triggers.current.hover && !triggers.current.focus) setPos(null);
  }, [cancelShow]);

  // 内容是否为纯字符串：字符串沿用 pre-line 以支持 \n，富组件则包裹 .rich 重置为空白 normal。
  const isStringContent = typeof resolved === 'string';

  return (
    <>
      {cloneElement(children, {
        ref: mergedRef,
        onMouseEnter: (e: Parameters<MouseEventHandler>[0]) => {
          ;(children.props.onMouseEnter)?.(e);
          triggers.current.hover = true;
          if (follow) {
            lastClientX.current = (e as unknown as { clientX: number }).clientX;
            showAfterHoverDelay(lastClientX.current);
          } else {
            showAfterHoverDelay();
          }
        },
        onMouseMove: (e: Parameters<MouseEventHandler>[0]) => {
          ;(children.props.onMouseMove)?.(e);
          if (!follow) return;
          if (disabled) return;
          const cx = (e as unknown as { clientX: number }).clientX;
          lastClientX.current = cx;
          if (pos !== null) {
            const p = computeFollowPos(cx);
            if (p !== null) setPos(p);
          }
        },
        onMouseLeave: (e: Parameters<MouseEventHandler>[0]) => {
          ;(children.props.onMouseLeave)?.(e);
          triggers.current.hover = false;
          cancelShow();
          if (!triggers.current.focus) setPos(null);
        },
        onFocus: (e: Parameters<FocusEventHandler>[0]) => {
          ;(children.props.onFocus)?.(e);
          triggers.current.focus = true;
          cancelShow();
          if (follow) {
            // 键盘聚焦：居中显示，不跟随鼠标
            const el = anchor.current;
            if (el === null) return;
            const r = el.getBoundingClientRect();
            setPlacement(effectiveSide);
            setPos({ x: r.left + r.width / 2, top: r.top, bottom: r.bottom });
            return;
          }
          show();
        },
        onBlur: (e: Parameters<FocusEventHandler>[0]) => {
          ;(children.props.onBlur)?.(e);
          triggers.current.focus = false;
          hide();
        },
      })}
      {pos !== null && !isEmpty && (
        <div
          ref={bubble}
          className={css.bubble}
          data-side={placement}
          style={{ left: pos.x, top: y, ...(maxWidth === undefined ? {} : { maxWidth }) }}
          role="tooltip"
        >
          {isStringContent ? resolved : <div className={css.rich}>{resolved}</div>}
        </div>
      )}
    </>
  );
}
