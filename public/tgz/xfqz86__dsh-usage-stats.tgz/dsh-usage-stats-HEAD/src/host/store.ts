/**
 * 内存聚合缓存：由账本事件流折叠而来的派生统计，按天、会话、模型、模型×日、全量维度组织。
 *
 * 边界：账本（ledger.ts）持有 sqlite 事件流与会话元数据，本模块只做折叠与聚合，是快照
 * 的读取面；启动/重建走 scan.ts 的全量折叠，实时走 session/event 逐条折叠，共用
 * foldRecord 与账本追加路径。折叠语义、去重与 fork 继承前缀见 docs/ARCHITECTURE.md §4。
 * 所有操作都是 store 为首参的纯函数或折叠助手，可独立测试。
 */
import { startOfDay, errorMessage  } from '../utils.ts';

import { newAgg, ink, usable } from './agg.ts';
import { toLedgerEvent } from './ledger.ts';

import type { Agg, SessionInfo } from './agg.ts';
import type { Ledger, LedgerEvent } from './ledger.ts';
import type { TokenUsage } from '@deepseek-ai/dsh-llm';
import type { SessionEvent } from '@deepseek-ai/dsh-session';

/** 会话级状态，包含数值聚合与去重水位，标题与归属字段在账本 meta 中。 */
export interface UsageStore {
  sessions: Map<string, SessionInfo>
  models: Map<string, Agg>
  /** 按模型×日的细分，用于模型汇总的时间范围筛选与堆叠柱。 */
  modelDaily: Map<string, Map<number, Agg>>
  allAgg: Agg
  allDaily: Map<number, Agg>
  /** 账本余额计数：事件总数与去重跳过数。 */
  foldedEvents: number
  dedupSkipped: number
  /** 初始化/重建扫描的导入报告，语义见 scan.ts。 */
  scanning: boolean
  running: boolean
  scans: number
  failed: number
  rawSessions: number
  harnessSessions: number
  lastError: string | null
  scanError: string | null
  lastScanAt: number
}

/** 新建空聚合缓存。 */
export function createStore(): UsageStore {
  return {
    sessions: new Map(),
    models: new Map(),
    modelDaily: new Map(),
    allAgg: newAgg(),
    allDaily: new Map(),
    foldedEvents: 0,
    dedupSkipped: 0,
    scanning: false,
    running: false,
    scans: 0,
    failed: 0,
    rawSessions: 0,
    harnessSessions: 0,
    lastError: null,
    scanError: null,
    lastScanAt: 0,
  };
}

/** 取某日分桶计数，不存在则新建。 */
export function dayAgg(map: Map<number, Agg>, day: number): Agg {
  let a = map.get(day);
  if (!a) { a = newAgg(); map.set(day, a); }
  return a;
}

/** 取会话级状态，不存在则新建。 */
export function ensureSession(store: UsageStore, id: string): SessionInfo {
  let info = store.sessions.get(id);
  if (!info) {
    info = { daily: new Map(), allAgg: newAgg(), maxSeq: -1, lastActive: 0 };
    store.sessions.set(id, info);
  }
  return info;
}

/** 取某模型分桶计数，不存在则新建，key 为 provider 与 model 以 \0 拼接。 */
export function ensureModel(store: UsageStore, key: string): Agg {
  let agg = store.models.get(key);
  if (!agg) { agg = newAgg(); store.models.set(key, agg); }
  return agg;
}

/** 取某模型的按日分桶 Map，不存在则新建。 */
export function ensureModelDaily(store: UsageStore, key: string): Map<number, Agg> {
  let m = store.modelDaily.get(key);
  if (!m) { m = new Map(); store.modelDaily.set(key, m); }
  return m;
}

/** 把一次真实用量折进会话日桶 / 会话总桶 / 全量日桶 / 全量总桶。 */
export function foldUsage(store: UsageStore, info: SessionInfo, timeMs: number, u: TokenUsage): void {
  const day = startOfDay(timeMs);
  ink(dayAgg(info.daily, day), u);
  ink(info.allAgg, u);
  ink(dayAgg(store.allDaily, day), u);
  ink(store.allAgg, u);
  if (timeMs > info.lastActive) info.lastActive = timeMs;
}

/**
 * 从原始记录求 fork 继承前缀长度：最后一个 `session/end-seed`（`data.inherited === true`）
 * 之后偏移一位，即该会话从父会话复制来的事件数，与 harness 的 `inheritedEventCount` 同义。
 * 无标记返回 0。原始日志路径拿不到 harness 元数据，用标记事件兜底。
 */
export function inheritedPrefixOf(records: readonly unknown[]): number {
  let cut = -1;
  for (const record of records) {
    if (typeof record !== 'object' || record === null) continue;
    const r = record as { type?: unknown; seq?: unknown; data?: { inherited?: unknown } };
    if (r.type !== 'session/end-seed' || r.data?.inherited !== true) continue;
    const seq = r.seq;
    if (typeof seq === 'number' && Number.isFinite(seq) && seq > cut) cut = seq;
  }
  return cut + 1;
}

/**
 * 归一 harness 元数据里的 fork 继承前缀长度（`SessionLogSnapshot.inheritedEventCount`
 * 与 `SessionHandle.inheritedEventCount`）：非有限、负数与缺省一律按 0，即无继承。
 */
export function inheritedCountOf(value: unknown): number {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
}

/**
 * 只保留本会话自有事件，丢掉 fork 继承前缀，避免把父会话的用量在子会话下重复计入。
 * 继承前缀是日志的物理前缀（seq 从 0 起共 inherited 条），因此按 seq 判定；
 * 无 seq 的记录（会话种子 header）不属于事件序列，原样保留供 meta 抄录。
 */
export function liveEventsOf<T>(events: readonly T[], inherited: number): readonly T[] {
  if (!(inherited > 0)) return events;
  return events.filter((event) => {
    const seq = (event as { seq?: unknown }).seq;
    return typeof seq !== 'number' || seq >= inherited;
  });
}

/**
 * 折叠一条账本事件进聚合缓存，调用方保证事件唯一（PK 为 t、session_id、seq），
 * 本函数除零用量守卫外恒折叠，直接重调会翻倍。返回是否真正折叠，
 * 事件无用量时返回 false。seq>=0 时推进该会话的 maxSeq 水位，使重启恢复后
 * 实时路径同样能去重历史事件。
 * 若提供 ledger，则同步增量更新预统计物化表，挂起时跳过，由批量 persist 覆盖。
 */
export function foldLedgerEvent(store: UsageStore, ev: LedgerEvent, ledger?: Ledger): boolean {
  if (ev.input + ev.output + ev.cacheRead + ev.cacheWrite + ev.reasoning <= 0) return false;
  const usage: TokenUsage = {
    inputTokens: ev.input,
    outputTokens: ev.output,
    cacheReadTokens: ev.cacheRead,
    cacheWriteTokens: ev.cacheWrite,
    reasoningTokens: ev.reasoning,
  };
  const info = ensureSession(store, ev.sessionId);
  if (ev.seq >= 0 && ev.seq > info.maxSeq) info.maxSeq = ev.seq;
  foldUsage(store, info, ev.t, usage);
  const modelKey = ev.provider + '\u0000' + ev.model;
  ink(ensureModel(store, modelKey), usage);
  ink(dayAgg(ensureModelDaily(store, modelKey), startOfDay(ev.t)), usage);
  store.foldedEvents += 1;
  // 同步物化到预统计表，实时路径增量，批量导入时挂起。失败不抛错、
  // 不打断折叠，内存聚合仍是正确事实，仅记录日志与 lastError 供快照
  // 暴露；预统计缺失部分由下次启动的加载/重放路径自愈。
  if (ledger) {
    try {
      ledger.incrementAgg(ev);
    } catch (e) {
      console.error('[usage-stats] 预统计增量写入失败', e);
      store.lastError = errorMessage(e);
    }
  }
  return true;
}

/**
 * 处理一条原始记录，涵盖会话种子、session/title、计量事件（usable，含对话与压缩调用）三类：
 * 元数据写账本 meta；usable 事件经 seq 水位、seq=-1 主键、append 返回值三层去重后追加进账本
 * 并折叠进聚合缓存。初始化扫描与实时监听共用此路径，保证账本内事件唯一。
 * 全部同步，sqlite 即写即持久，无需等待落盘。
 * 预统计增量在此路径自动完成，挂起时跳过。
 */
export function foldRecord(
  store: UsageStore,
  ledger: Ledger,
  id: string,
  record: SessionEvent | {
    type: string;
    cwd?: unknown;
    createdAt?: unknown;
    parentSession?: unknown;
    origin?: unknown;
    delegationDepth?: unknown;
    data?: { title?: unknown; usage?: unknown };
  },
): void {
  if (record.type === 'session') {
    // 会话种子记录：cwd、createdAt、parentSession 等在顶层，属于 SessionHeader 字段。
    const rec = record as { cwd?: unknown; createdAt?: unknown; parentSession?: unknown; origin?: unknown; delegationDepth?: unknown };
    const createdAt = typeof rec.createdAt === 'number' ? rec.createdAt : undefined;
    const parentSession = typeof rec.parentSession === 'string' ? rec.parentSession : undefined;
    const origin = typeof rec.origin === 'string' ? rec.origin : undefined;
    const delegationDepth = typeof rec.delegationDepth === 'number' && Number.isFinite(rec.delegationDepth) ? rec.delegationDepth : undefined;
    ledger.setMeta(id, {
      cwd: typeof rec.cwd === 'string' ? rec.cwd : undefined,
      createdAt,
      lastActive: createdAt,
      parentSession,
      origin,
      delegationDepth,
    });
    return;
  }
  if (record.type === 'session/title') {
    const rec = record as { data?: { title?: unknown } };
    const title = rec.data?.title;
    ledger.setMeta(id, { title: typeof title === 'string' ? title : undefined });
    return;
  }
  const event = record as SessionEvent;
  if (!usable(event)) return;
  let ev: LedgerEvent | null;
  try {
    ev = toLedgerEvent(id, event);
  } catch {
    // 畸形事件如缺 message.source，不影响会话其余事件
    return;
  }
  if (ev === null) return;
  // 零用量事件不入账本：foldLedgerEvent 同样会跳过，提前返回避免 DB 膨胀；
  // 去重水位不受影响，此类事件本就不贡献统计。
  if (ev.input + ev.output + ev.cacheRead + ev.cacheWrite + ev.reasoning <= 0) return;
  // 用量路径统一使用账本事件的会话 id，toLedgerEvent 已做 TEXT 归一，
  // 保证水位、meta 与聚合三处键一致。
  const sid = ev.sessionId;
  const info = ensureSession(store, sid);
  // seq 水位去重：防止初始化扫描与实时监听或重扫双记同一事件。
  if (typeof ev.seq === 'number' && ev.seq >= 0 && ev.seq <= info.maxSeq) {
    store.dedupSkipped += 1;
    return;
  }
  // seq=-1 等未知序事件无法靠水位去重，用主键存在性校验，依 t+session+seq 幂等
  if (ev.seq < 0 && ledger.hasEventAt(ev.t, sid, ev.seq)) {
    store.dedupSkipped += 1;
    return;
  }
  const isNew = ledger.append(ev);
  if (!isNew) {
    store.dedupSkipped += 1;
    return;
  }
  // 同步更新会话元数据的 lastActive，即事件时间，保证 session_meta 不为空
  ledger.setMeta(sid, { lastActive: ev.t });
  foldLedgerEvent(store, ev, ledger);
}

/** 取会话 meta，缺省用空元数据，避免 snapshot 层判空。 */
export function metaOf(
  ledger: Ledger,
  id: string,
): {
    title: string;
    cwd: string;
    createdAt: number;
    lastActive: number;
    parentSession: string;
    origin: string;
    delegationDepth: number;
  } {
  const meta = ledger.getMeta(id);
  return meta ?? { title: '', cwd: '', createdAt: 0, lastActive: 0, parentSession: '', origin: '', delegationDepth: 0 };
}
