# dsh-usage-stats 开发规范（AGENTS.md）

本文件约束本仓库全部开发，任何 agent/协作者必须遵守；不可删除。用户侧说明见 `README.md`；本机私有与强时效内容见 `AGENTS.local.md`（不入库，`.gitignore` 排除，dsh 自动注入）。**本文件只写规则与不变量**，机制事实、协议细节、统计口径各有权威文档（见 §10 归属表），在此不复述；新增信息先查归属表、只写权威文件。

## 0. 红线：类型必须复用 deepseek-harness，禁止手写镜像

harness 每个包已导出完整精确的类型（`Context`/`ClientContext`/`SessionEvent`/`TokenUsage`/`PropsRuntime`/`InjectFace`/`Modal` 等）：**禁止**为 `ctx/slots/locale/session/primitives/注入服务` 手写结构、最小接口或 ambient 镜像，**必须** `import type` harness 导出，用法与 harness 的 `ui-cordis` 等包一致。

依赖声明（`package.json` 三段，版本以它为准、文档不抄写；`import type` 打包时剥离）：
- `dependencies`：随包安装的第三方运行时库（`@deepseek-ai/schemastery`、旧设置文档回收用的 `yaml`、基座路径解析用的 `dsh-home-paths`）。
- `peerDependencies`：由 dsh 安装包提供的框架单例（`@deepseek-ai/cordis`、`@deepseek-ai/dsh-typert-protocol`、`@deepseek-ai/dsh-credentials`），不随包安装，`devDependencies` 内必须镜像同 range。
- `devDependencies`：其余（构建/测试/纯类型）全进这里，直接安装、无 `paths` 映射。

值导入（`tsdown` host 侧 `neverBundle` 不打包）运行时解析：`dependencies` 走随包安装的副本，`peerDependencies` 走安装包单例；服务端除声明过的依赖外只引 Node 内置与本地模块，浏览器端只 `require` 冻结表模块（`react` 系 + `cordis` + `slots/primitives/dockkit/store`）；Client 贡献内联的 `zod` 构建期来自 dev、随浏览器 bundle 打包。

两端范式：
```ts
// —— 服务端（类表单服务，Loader 实例化）——
import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import type {} from '@deepseek-ai/dsh-session-query'         // ctx.sessionQuery
export default class UsageStatsService extends TypertRemoteService {
  static inject = ['sessionQuery', 'sessionPersistence']     // 全必需；可选服务不进 inject，调用处 ctx.get 判空
  @Remote('snapshot') snapshot(request: SnapshotRequest): UsageSnapshot { /* ... */ }
}
// —— 浏览器端 ——
import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'  // ctx.slots（PropsRuntime/PropsLocale/InjectFace）
import type {} from '@deepseek-ai/dsh-api-gateway/client'         // ctx.remote
export type Props = PropsRuntime<'sidebar.footer.action'> & PropsLocale<'dsh-usage-stats'>
export const inject = ['slots', 'locale', 'remote', 'configForms']
export async function apply(ctx: ClientContext): Promise<void> {
  const disposeMount = await mountUsageStatsRemote(ctx)
  ctx.effect(() => disposeMount, 'dsh-usage-stats: remote 挂载')
  ctx.locale.register(NS, { zh, en })
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({...}, props => <Comp {...props} />))
}
```
- 取命名空间服务必须经挂载上下文 `get('remote.usageStats')`（本仓库由 `usageStatsRemote()` 封装，每次调用实时解析），禁止暂存 `ctx.remote` 再读 `.usageStats`；文案字典按 `ui-cordis` 范式：`NS + zh satisfies Record<string,string> + UsageStatsKey=keyof typeof zh + declare module LocaleNamespaceMap + en satisfies Record<UsageStatsKey,string>`，`t('key')` 全量校验。

## 1. 术语
- 统一 **服务端（Host）/浏览器端（Client）**（对应 `dsh-host-*`/`dsh-client-*`，禁用“宿主半/客户端半”）：Host=`lib/index.js`（Node cordis 插件），Client=`lib/client.js`（经 `dsh.client` 注入的浏览器 bundle）。

## 2. 项目形态与部署
- 标准 cordis 组合包：`package.json` 声明 `dsh.bundle.patch=./cordis.patch.yml` 与 `dsh.client.inject/platform + exports./client`；无 `install.sh`/`dsh.plugin.json` 旁路，安装 `dsh plugin --profile web add "link:<路径>"`，卸载 `dsh plugin --profile web remove <name>`；`link:` 指向本仓库。
- `pnpm build` 后浏览器刷新即生效（服务端需重启 dsh）。`cordis.patch.yml` 仅一条 `usage-stats` 插入，不挂 `storage` 后端、不覆 `storage-domain`（账本自管理，见 `docs/ARCHITECTURE.md`）。

## 3. 代码规范
- **不使用 `any`**；`ctx` 用 harness 类型，业务数据用明确接口；类型仅定义 harness 未提供的（如 `UsageSnapshot`）。
- **风格与检查**：遵循 **Google TypeScript Style Guide**；`eslint.config.mjs`（flat config，`eslint 9 + typescript-eslint 8 + eslint-plugin-import-x + @stylistic`，分 `host/client/scripts` 三类 overrides）为唯一事实来源；新增代码须 `npx eslint .` 零 `errors`。
- 文件归属：纯逻辑置于无 React 模块（`src/utils.ts`/`src/host/agg.ts`/`src/client/stats.ts`）便于测试；**tsx 一组件一文件**；**协议类型集中 `src/types.ts`**（零运行时，host/client 各自 re-export），`src/utils.ts` 仅纯函数与共享常量；可复用通用组件归 `src/client/components`，`src/client/views` 放 Tab 级视图及其专属子视图与入口壳。
- **样式用 CSS Modules**（`*.module.css` + `import css`），与 `ui-sidebar/primitives` 一致；界面静态颜色优先 `var(--dsw-alias-*)`，固定语义的静态色/阴影用 `--dsw-static-*`/`--dsw-shadow-*`；不新增自定义属性兜底（见 `docs/STYLE.md` §8）；图表数据驱动调色板（`MODEL_PALETTE`/`DATE_TOKEN_META`/`HIT_RATE_COLOR`，集中定义于 `src/client/stats.ts`，`fill` 属性不解析 `var()`）是数据色豁免；禁止字符串 CSS（编译内联机制见 `docs/ARCHITECTURE.md` §6）。
- **注释中文**，标识符/类型/错误消息英文；文档中文。

## 4. 项目结构
目录与职责见 `docs/STRUCTURE.md`（`pnpm tree` 生成，勿手改）。入口：`src/host/index.ts`（Host）、`src/client/index.ts`（Client）；共用 `src/types.ts`（类型）、`src/utils.ts`（纯函数与共享常量）。各文件职责以头部注释为准。

## 5. 架构与数据流
- 不变量：**账本（Ledger）唯一事实来源，聚合（UsageStore）只读派生**；账本九表、数据流、折叠与去重、fork 继承前缀、清零墓碑的唯一权威是 `docs/ARCHITECTURE.md`——改 `ledger/store/agg/scan/rawlog` 相关代码前必读，本文件不复述。

## 6. 统计口径
- 精确口径唯一权威是 `docs/ARCHITECTURE.md` §5；统计口径变化必须递增账本 `user_version`（见该文件 §2），本文件不复述。

## 7. 构建
- 产物形态与 CSS 内联机制见 `docs/ARCHITECTURE.md` §6；构建命令见 §9。

## 8. 运行时与 Remote API
- **注入**：`static inject=['sessionQuery', 'sessionPersistence']`（全必需）；`credentials` 可选不进 inject，调用处 `ctx.get` 判空，缺席时额度查询直接返回 `no-key`，不读 env 与文件；偏好设置靠条目自带 `static Config`，不需注入 `settings`。先挂实时监听再 `bootstrap`。
- **接口**：`UsageStatsService`（`usageStats` 命名空间下全部一元 `@Remote` 方法）经网关 `POST /api/usageStats/<方法>` 调用，信任与认证由网关载体统一处理，不注册 HTTP 路由、不自建围栏。协议唯一权威是 `docs/API.md`，改签名必须同步实现体、手写贡献与该文件。Host 侧 SRC 分发（装饰器标记+实时绑定）；Client 侧自挂载 `src/remote/contribution.ts` 的手写严格贡献（独立仓库跑不了 harness 生成器管线）——只改实现体不动贡献。
- **偏好设置走 harness 用户设置体系，禁止 localStorage**：Host 以插件条目 Config 声明 `usage-stats` schema（`src/host/settings.ts`，字段须 `.volatile()`，默认值与 `USAGE_SETTINGS_DEFAULTS` 同源），Client 经 `configForms` 按条目 id 绑定读写（`src/client/settings.ts`）；字段语义与旧版迁移（含基座导入失败后的 settings.yaml.imported 回收）见 `docs/API.md` §5。

## 9. 验证
- **日常提交（dev 等）不强求本地门禁**：`ci.yml` 在 push 与 PR 上跑类型检查、生产构建、样式契约与冒烟测试、`prepare` 与打包校验，交给 CI 兜底；纯文档/注释改动不必跑检查。
- **发版前（打 tag 前）必须本地全量跑通**，这是发版硬门槛：
```bash
npx tsc --noEmit
npx eslint .              # 0 errors 为门禁
pnpm build
node --experimental-strip-types test/pure.mjs
node --experimental-strip-types test/smoke.mjs
node --experimental-strip-types test/styles.mjs
node test/client-bundle.mjs
node .agents/skills/release/scripts/verify-release.mjs   # 发布形态：生产构建 + 出 tarball + 包内容与 Remote 签名校验
```
- **发布形态必须单独验**：开发态掩盖生产态才暴露的问题——服务端产物一旦被压缩，Remote 方法参数名会被改写，而网关按方法源码文本取线路字段名，带参调用会被全量拒收。该脚本出包后还须在真实 dsh 上装机实测它产出的 tarball（本机流程见 `AGENTS.local.md`），只在发版前做。各测试的覆盖范围与断言清单以 `test/*.mjs` 头注释为准，本文件不复述；样式契约背景见 `docs/STYLE.md` §8，测试直引源码的可擦除语法要求见 `docs/STYLE.md` §7。

## 10. 文档与注释治理（一事一地）
**每类信息只有一个权威位置，其余最多一行指针，禁止复述；治理在每次会话执行，而不是靠一次性清理。**
- **先查后写**：新增任何文档/注释内容前，先查归属表并 grep 关键词，确认权威位置尚无该表述，然后只写权威位置；修改事实只改权威地，别处发现第二份完整表述即删、换指针；删除或迁移前确认权威地已含该信息（只迁移不丢失）。
- **同批与修即清**：改动任何文件时，受影响的注释与权威文档同批更新；路过发现的失效、重复文档/注释顺手清理，不留「代码已改、文档待补」的中间态。
- **注释的权威边界**：注释只对两件事是权威——文件职责（头部块注释首句，`docs/STRUCTURE.md` 的数据源）与代码自身说不出的局部约束；内容标准（只写 why、不复述代码、不复制文档、不写修复历史）见 `docs/STYLE.md` §6。
- 每份文档开头一句职责声明；用户文档（README/CHANGELOG/releases）允许用户语言概述，但不承载实现细节。本文件为注入稳定前缀，仅规则/不变量变化时改；纯代码改动不碰它。
- 发版同步：`package.json version` 变更必须同批追加 `CHANGELOG.md` 条目与 `docs/releases/v<版本>.md`（面向用户的更新说明，`release.yml` 强制存在），流程见 `.agents/skills/release/SKILL.md`（发版技能）；纯重构与文档整理在 CHANGELOG 简记一行；结构变化跑 `pnpm tree` 重生成 `docs/STRUCTURE.md`。
- **README 只用标准 Markdown**（很多站点不渲染内联 HTML）：徽章写 `[![alt](图)](链接)`；界面截图用一行缩略图表格（GitHub 正文实测 838px，5 列 ×140px 刚好满行），展示用的缩略图与补白图一律链接到 `docs/screenshot/` 根目录原图；关于页、更新说明这类截图不进 README。
- **截图资产**：原图放 `docs/screenshot/` 根目录，缩略图、补白居中图等派生图只放 `docs/screenshot/processed/`（由原图生成）；高清屏截图是 2 倍图，网页展示要按 1 倍折算（补透明画布居中），不要按原尺寸引用。

| 主题 | 权威文件 |
|---|---|
| 红线、规范、流程、验证门禁（规则） | 本文件（AGENTS.md） |
| 架构、数据流、账本/折叠/统计口径事实 | `docs/ARCHITECTURE.md` |
| Remote 线路协议、偏好设置协议 | `docs/API.md` |
| 风格与统一写法 | `docs/STYLE.md` |
| 发布与交付 | `.agents/skills/release/SKILL.md`（技能） |
| 目录结构与文件职责 | `docs/STRUCTURE.md`（生成） |
| 用户视角：功能、安装、设置 | `README.md` |
| 版本历史 | `CHANGELOG.md` + `docs/releases/` |

## 11. 提交（Conventional Commits）
格式 `type(scope): subject`（`type` 英文 `feat/fix/docs/style/refactor/perf/test/build/ci/chore/revert`，`scope` 可选 `client/host/build/docs/deps`，`subject` 中文小写无句号）；`body/footer` 中文，`BREAKING CHANGE:` 置脚注首行；一次提交一件事，禁 `wip/update`；验证按 §9 对应档位（发版前才需全量）。

## 12. 交付物
仅陈述最终确定的规则/架构/协议/实现，不写入过程备注与待定方案；过程内容走会话记录，不入库。
