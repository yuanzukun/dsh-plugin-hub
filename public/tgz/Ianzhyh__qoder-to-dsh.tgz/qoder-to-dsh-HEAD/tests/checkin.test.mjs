import test from 'node:test';
import assert from 'node:assert/strict';

import {
  ADDON_VALIDITY_FALLBACK_DAYS, addonBatches, beijingDateKey, beijingHour, campaignEndMs, campaignStartMs,
  checkinCanClaim, claimCampaigns, inCampaignWindow, summarizeCampaigns, summarizeCheckinAccounts, validityDaysOf,
} from '../lib/checkin.mjs';

const now = Date.UTC(2026, 9, 25, 4, 0, 0);
const sec = (ts) => Math.floor(ts / 1000);
const benefit = (overrides = {}) => ({
  actionType: 'CLAIM_BENEFIT',
  claimStatus: 'CLAIMABLE',
  campaignId: 'campaign-1',
  benefit: { amount: 100 },
  startAt: sec(now) - 3600,
  endAt: sec(now) + 3600,
  ...overrides,
});

test('Beijing date/hour helpers use UTC+8', () => {
  assert.equal(beijingDateKey(Date.UTC(2026, 9, 24, 17, 0, 0)), '2026-10-25');
  assert.equal(beijingDateKey(Date.UTC(2026, 9, 25, 15, 59, 0)), '2026-10-25');
  assert.equal(beijingDateKey(Date.UTC(2026, 9, 25, 16, 0, 0)), '2026-10-26');
  assert.equal(beijingHour(Date.UTC(2026, 9, 25, 2, 0, 0)), 10);
  assert.equal(campaignStartMs(benefit()), (sec(now) - 3600) * 1000);
  assert.equal(campaignEndMs(benefit()), (sec(now) + 3600) * 1000);
});

test('campaign window is inclusive at start and exclusive at end', () => {
  const campaign = { startAt: 100, endAt: 200 };
  assert.equal(inCampaignWindow(campaign, 100_000), true);
  assert.equal(inCampaignWindow(campaign, 199_999), true);
  assert.equal(inCampaignWindow(campaign, 200_000), false);
  assert.equal(inCampaignWindow(campaign, 99_999), false);
  assert.equal(inCampaignWindow({}, now), true, '没有窗口字段时不过滤');
});

function fakeDevice() {
  return {
    ready: true,
    version: 'test',
    reason: '',
    headers: {
      'Cosy-ClientType': '10',
      'Cosy-MachineId': 'machine-id-fixture',
      'Cosy-MachineToken': 'machine-token-fixture',
    },
  };
}

test('claimCampaigns claims a claimable benefit with device headers', async () => {
  const originalFetch = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url, options) => {
    calls.push({ url: String(url), options });
    if (String(url).includes('/campaigns/') && options.method === 'POST') {
      return new Response(JSON.stringify({
        status: 'CLAIMED', benefit: { amount: 100 },
      }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    return new Response(JSON.stringify({ campaigns: [benefit()] }), {
      status: 200, headers: { 'content-type': 'application/json' },
    });
  };
  try {
    const result = await claimCampaigns({
      region: 'cn',
      getToken: async () => 'token-fixture',
      now,
      deviceProvider: async () => fakeDevice(),
    });
    assert.equal(result.status, 'claimed');
    assert.equal(result.credits, 100);
    assert.equal(result.message, '签到成功 +100 Credits');
    assert.equal(calls.length, 2);
    assert.match(calls[0].url, /openapi\.qoder\.com\.cn\/sash\/api\/v1\/me\/campaigns$/);
    assert.match(calls[1].url, /\/campaigns\/campaign-1\/claim$/);
    assert.equal(calls[0].options.headers.authorization, 'Bearer token-fixture');
    assert.equal(calls[0].options.headers['Cosy-MachineToken'], 'machine-token-fixture');
    assert.ok(!JSON.stringify(result).includes('token-fixture'));
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('a claimed benefit with no advertised amount still counts as claimed', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url, options) => {
    if (String(url).includes('/campaigns/') && options.method === 'POST') {
      return new Response(JSON.stringify({ status: 'CLAIMED' }), {
        status: 200, headers: { 'content-type': 'application/json' },
      });
    }
    return new Response(JSON.stringify({ campaigns: [benefit({ benefit: {} })] }), {
      status: 200, headers: { 'content-type': 'application/json' },
    });
  };
  try {
    const result = await claimCampaigns({
      region: 'global',
      getToken: async () => 'token-fixture',
      now,
      deviceProvider: async () => fakeDevice(),
    });
    assert.equal(result.status, 'claimed', '上游确认已领取，不能因为金额为 0 就报错重试');
    assert.equal(result.credits, 0);
    assert.match(result.message, /已领取/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('claimCampaigns refreshes the active token once on 401', async () => {
  const originalFetch = globalThis.fetch;
  let getCount = 0;
  let refreshCount = 0;
  globalThis.fetch = async (url, options) => {
    if (String(url).includes('/campaigns/') && options.method === 'POST') {
      return new Response(JSON.stringify({ data: { status: 'CLAIMED', benefit: { amount: 50 } } }), { status: 200 });
    }
    getCount += 1;
    if (getCount === 1) return new Response('{"error":"expired"}', { status: 401 });
    assert.equal(options.headers.authorization, 'Bearer new-token');
    return new Response(JSON.stringify({ campaigns: [benefit()] }), { status: 200 });
  };
  try {
    const result = await claimCampaigns({
      region: 'global',
      getToken: async () => 'old-token',
      refreshToken: async () => { refreshCount += 1; return 'new-token'; },
      now,
      deviceProvider: async () => fakeDevice(),
    });
    assert.equal(refreshCount, 1);
    assert.equal(getCount, 2);
    assert.equal(result.status, 'claimed');
    assert.equal(result.credits, 50);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('claimCampaigns stops immediately when the caller cancels', async () => {
  const originalFetch = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = async () => { calls += 1; return new Response('{}'); };
  const controller = new AbortController();
  controller.abort(new Error('cancelled'));
  try {
    await assert.rejects(
      claimCampaigns({
        region: 'global',
        getToken: async () => { throw new Error('getToken should not run'); },
        now,
        deviceProvider: async () => fakeDevice(),
        signal: controller.signal,
      }),
      /cancelled/,
    );
    assert.equal(calls, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('claimCampaigns does not call the network without a device identity', async () => {
  const originalFetch = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = async () => { calls += 1; return new Response('{}'); };
  try {
    const result = await claimCampaigns({
      region: 'global',
      getToken: async () => 'token-fixture',
      now,
      deviceProvider: async () => ({ ready: false, reason: 'missing runtime-info', headers: {}, version: '' }),
    });
    assert.equal(result.status, 'device');
    assert.match(result.message, /runtime-info/);
    assert.equal(calls, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('summarizeCampaigns separates claimable, claimed, pending and other campaign types', () => {  const payload = {
    campaignUrl: 'https://qoder.com/campaign',
    campaigns: [
      benefit(),
      benefit({ campaignId: 'claimed', claimStatus: 'CLAIMED', benefit: { amount: 100 } }),
      benefit({ campaignId: 'other-type', actionType: 'VIEW_DETAILS', claimStatus: 'CLAIMED' }),
      benefit({ campaignId: 'expired', claimStatus: 'CLAIMABLE', startAt: sec(now) - 7200, endAt: sec(now) - 3600 }),
    ],
  };
  const summary = summarizeCampaigns(payload, now);
  assert.equal(summary.benefits.length, 3, 'VIEW_DETAILS 不算领取活动');
  assert.deepEqual(summary.claimable.map((item) => item.campaignId), ['campaign-1']);
  assert.deepEqual(summary.claimed.map((item) => item.campaignId), ['claimed']);
  assert.equal(summary.pending, false);
  assert.equal(summary.campaignUrl, 'https://qoder.com/campaign');
  assert.equal(summary.endAt, (sec(now) + 3600) * 1000);

  const pending = summarizeCampaigns({ campaigns: [benefit({ claimStatus: 'PENDING' })] }, now);
  assert.equal(pending.claimable.length, 0);
  assert.equal(pending.pending, true);

  const empty = summarizeCampaigns({ campaigns: [] }, now);
  assert.equal(empty.benefits.length, 0);
  assert.equal(empty.claimable.length, 0);
});

test('checkin summary separates waiting, unavailable and pending accounts', () => {
  const summary = summarizeCheckinAccounts([
    { today: true, status: 'claimed', credits: 100 },
    { today: true, status: 'already', credits: 50 },
    { today: false, status: 'idle', credits: 0 },
    { today: true, status: 'pending', credits: 0 },
    { today: false, status: 'waiting', credits: 0 },
    { today: true, status: 'unavailable', credits: 0 },
    { today: true, status: 'device', credits: 0 },
    { today: true, status: 'login', credits: 0 },
  ]);
  assert.equal(summary.total, 8);
  assert.equal(summary.done, 2);
  assert.equal(summary.claimed, 1);
  assert.equal(summary.already, 1);
  assert.equal(summary.credits, 150);
  assert.equal(summary.pending, 1, '只有 idle 是真正的待领取');
  assert.equal(summary.notOpen, 1, 'pending 是活动未下发/未开放，不能算待领取');
  assert.equal(summary.waiting, 1);
  assert.equal(summary.unavailable, 1);
  assert.equal(summary.errors, 2);

  const empty = summarizeCheckinAccounts([]);
  assert.deepEqual(empty, {
    total: 0, done: 0, claimed: 0, already: 0, credits: 0,
    pending: 0, notOpen: 0, waiting: 0, unavailable: 0, errors: 0,
  });
});

test('checkinCanClaim blocks closed windows but allows retrying a stale failure', () => {
  const base = { tokenReady: true, deviceAvailable: true };
  assert.equal(checkinCanClaim({ ...base, status: 'idle' }), true);
  assert.equal(checkinCanClaim({ ...base, status: 'pending' }), true);
  assert.equal(checkinCanClaim({ ...base, status: 'error' }), true);
  assert.equal(checkinCanClaim({ ...base, status: 'device' }), true, '设备恢复后允许重试旧失败');
  assert.equal(checkinCanClaim({ ...base, status: 'login' }), true, '重新登录后允许重试旧失败');
  assert.equal(checkinCanClaim({ ...base, status: 'waiting' }), false);
  assert.equal(checkinCanClaim({ ...base, status: 'unavailable' }), true, '无活动允许手动重试（活动可能刚下发）');
  assert.equal(checkinCanClaim({ ...base, status: 'claimed' }), false);
  assert.equal(checkinCanClaim({ ...base, status: 'already' }), false);
  assert.equal(checkinCanClaim({ tokenReady: false, deviceAvailable: true, status: 'error' }), false);
  assert.equal(checkinCanClaim({ tokenReady: true, deviceAvailable: false, status: 'error' }), false);
});

test('validityDaysOf reads the campaign validity in every shape the server used', () => {
  assert.equal(validityDaysOf({ validity: { days: 30 } }), 30);
  assert.equal(validityDaysOf({ validityDays: 7 }), 7);
  assert.equal(validityDaysOf({ validity: 14 }), 14);
  assert.equal(validityDaysOf({}), 0, '没给有效期不能编天数');
  assert.equal(validityDaysOf(undefined), 0);
});

test('addonBatches spreads the pooled remaining first-expire-first-consumed', () => {
  const now = Date.UTC(2026, 10, 3, 2, 0, 0);
  const day = 86400000;
  const ledger = [
    { key: 'cn:u1', at: now - 24 * day, credits: 100, validityDays: 0 },
    { key: 'cn:u1', at: now - 4 * day, credits: 100, validityDays: 0 },
    { key: 'cn:u1', at: now - 3 * day, credits: 100, validityDays: 30 },
  ];
  const view = addonBatches({ ledger, remaining: 250, now });

  // 最早那笔 100 被扣剩 50；三批都在有效期内；全部标 inferred（validityDays=0）。
  assert.equal(view.batches.length, 3);
  assert.equal(view.totalRemaining, 250);
  assert.equal(view.batches[0].remaining, 50, '最旧的批次先被消耗');
  assert.equal(view.batches[0].inferred, true);
  assert.equal(view.batches[2].inferred, false, '接口给了 validity 的批次是精确值');
  assert.equal(view.batches[2].validityDays, 30);
  assert.equal(view.nextExpiry, view.batches[0].expiresAt, '最近到期就是最早那批');
  assert.equal(view.fallbackDays, ADDON_VALIDITY_FALLBACK_DAYS);
});

test('addonBatches drops expired batches and reports untracked claims honestly', () => {
  const now = Date.UTC(2026, 10, 3, 2, 0, 0);
  const day = 86400000;
  const ledger = [
    { key: 'cn:u1', at: now - 40 * day, credits: 100, validityDays: 30 },
    { key: 'cn:u1', at: now - 2 * day, credits: 100, validityDays: 30 },
  ];
  const view = addonBatches({ ledger, remaining: 450, now });

  assert.equal(view.expiredCredits, 100, '过期批次的余额作废');
  assert.equal(view.batches.length, 2);
  assert.equal(view.batches[0].remaining, 100);
  assert.equal(view.batches[1].untracked, true, '账本没记到的领取单独成批');
  assert.equal(view.batches[1].remaining, 250);
  assert.equal(view.batches[1].expiresAt, 0, '没有记录就不能有日期');
  assert.equal(view.nextExpiry, view.batches[0].expiresAt);
});
