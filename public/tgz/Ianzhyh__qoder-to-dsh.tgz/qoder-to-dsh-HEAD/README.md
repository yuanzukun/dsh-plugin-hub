# qoder-to-dsh

把 **Qoder** 的模型额度原生接进 **DeepSeek Harness (DSH)**。当前版本 **1.5.1**。

这是一个纯 DSH 插件：没有本地桥进程，没有第二个端口，没有独立控制台。凭据读取、COSY 签名、模型目录、流式转发和设置面板都在 DSH 插件进程内完成。

> 非官方互操作性实现，只使用你自己合法授权的 Qoder 账号。上游协议可能随时变化。

## 设计

- **单进程**：插件内直接完成认证、目录、请求与面板，不存在“桥在跑但插件连不上”“控制台和请求用的不是同一份令牌”这类状态分裂。
- **原生 provider**：通过 `ctx.llm.registerAdapter(['qoder'], adapter)` 接入，模型直接出现在 DSH 选择器里。
- **同一份数据**：面板、模型选择器和真实请求共享同一份目录、偏好和额度状态。
- **本地优先**：凭据、偏好、用量和日志都保存在本机；面板只返回非敏感元数据。
- **数据驱动**：上下文档位、思考档位、价格倍率来自 Qoder 模型目录；上游新增字段时优先使用上游值。
- **不挡首包**：目录有缓存就先返回、过期后台刷新，并发调用合并成一次；模型准备阶段不再为了目录等上游往返。
- **启动不阻塞**：已登录启动时不在主线程扫描本机账号；桌面端 DPAPI key 在后台子进程预热，首次签到或账号页再读取候选账号。
- **低开销热路径**：请求体签名编码走 Buffer 码表，流式帧只做必要翻译；聊天传输用 keep-alive 复用连接，用量记录合并异步落盘。

## 界面

截图使用离线演示数据，不含真实账号信息；主题和窄屏布局跟随 DSH。

<p align="center">
  <img src="assets/screenshots/overview-light.png" width="49%" alt="概览（明亮）" />
  <img src="assets/screenshots/overview-dark.png" width="49%" alt="概览（深色）" />
</p>
<p align="center"><sub>概览：额度、签到、用量与路由状态在同一屏；明亮 / 深色主题一致。</sub></p>

<p align="center">
  <img src="assets/screenshots/models-dfmodel.png" width="62%" alt="模型参数" />
  <img src="assets/screenshots/narrow-checkin.png" width="27%" alt="窄屏签到" />
</p>
<p align="center"><sub>模型参数：200K / 400K / 1M 上下文档位、自动输出 32K、温度与快捷值；右侧为窄屏签到。</sub></p>

<p align="center">
  <img src="assets/screenshots/checkin-light.png" width="49%" alt="签到" />
  <img src="assets/screenshots/usage-credits.png" width="49%" alt="用量与 Credits" />
</p>
<p align="center"><sub>签到逐账号领取；Credits 只计实际扣费，免费与折扣显示为“已省”。</sub></p>

## 已验证

在 **DSH 0.2.1-rc.3 + Qoder 0.5.1** 实测（`desktop` profile，真实账号）：

- 插件正常加载，设置里出现 **Qoder** 页签；
- 自动只读导入本机 Qoder 桌面端登录态；数据目录搬迁（symlink / `location.v1.json`）后仍能定位；
- 当前账号模型、上下文档位、思考档位和价格倍率正确显示；
- 真实对话返回 `pong`，`reasoning-delta → text-delta → usage → finish(stop)` 完整；COSY 跟随客户端内置 CLI 版本（本次 1.1.79-hotfix.7）；
- 经 DSH 自己的 `llm` 服务以 `provider=qoder` 派发请求也返回 `pong`，模型选择器这条路径真实可用；
- 带 79 次工具调用的历史切换后仍能正常请求，不再触发 `Messages with role 'tool'...`；
- 目录按 `context_config` 显示 200K / 400K / 1M 档位，选中的值会写回请求的 `model_config.max_input_tokens`；
- 免费模型的 `billable: false` 请求不计入实扣，只显示为“已省”；
- 四个只读工具与 `/qoder` 命令注册成功，26 条面板数据路由挂载成功；
- 9 个页签（概览/签到/模型/试跑/用量/请求/账号/诊断/日志）在明暗主题和 380px 窄屏下可横滑（中英双语留到 1.5）；
- 账号别名、上移/下移、隐藏/恢复、切换落盘均可用；同一账号的多份桌面/CLI 快照合并成一行；
- 额度卡按包展示，支持同名不同到期日分组、不限量、账号不一致与旧构建提示；
- 请求页签支持模型筛选、仅失败、暂停刷新、复制单条与 CSV（BOM + 公式注入防护）；缓存列显示命中 tokens 与比例，用量页显示缓存命中率；
- 多枚 `pt-` PAT 可加密保存、切换、删除；切换后账号与模型目录同步刷新；
- 额度 7 天内到期/已过期显示徽标，对话页胶囊显示已用百分比；
- 诊断页新增客户端安装/协议/设备身份/数据目录/目录缓存/推理端点 6 项，并可复制脱敏诊断包；
- 明亮 / 深色主题跟随 DSH 的 `color-scheme`；
- 每日活动已用真实账号验证：国际版读取到已领取状态，国内版成功领取 Credits；
- 多账号列表能同时看到国际版 / 国内版本机登录，签到结果按账号分别记录。

`tests/live-adapter.mjs` 是协议层实机回归；`tests/verify-install.mjs`（`npm run verify`）是安装面自检；`tests/plugin-host.test.mjs` 用假的 DSH 服务加载真实插件入口，覆盖路由、工具、命令、偏好持久化与未登录保护，不联网。开发时另用本地离线渲染 harness 逐页截图，检查明暗主题、窄屏、失败态、参数保存、试跑取消、键盘与触控。

## 快速开始

### 1. 安装

> **装包 ≠ 启用。** 只写进 profile 的 `dependencies` 时，DSH 不会加载插件，也不会报错；必须同时出现在 `dsh.profile.bundles` 里。

三种安装形态，按使用场景选一种。

**A. Release 的 tgz（多数人用这个）**

从 [Releases](https://github.com/Ianzhyh/qoder-to-dsh/releases) 下载 `qoder-to-dsh-<version>.tgz`，在下载目录执行：

```bash
dsh plugin --profile desktop add ./qoder-to-dsh-1.5.1.tgz
```

正文里带该资产的 SHA-256，可以先核对再装。也可以在 DSH 里让 agent 直接按 URL 装：

```text
plugin_manager { action: "install_bundle", target: "https://github.com/Ianzhyh/qoder-to-dsh/releases/download/v1.5.1/qoder-to-dsh-1.5.1.tgz" }
```

**B. GitHub 直装（不落地文件）**

```bash
dsh plugin --profile desktop add github:Ianzhyh/qoder-to-dsh
```

**C. 本地目录 link（改代码时用）**

```bash
dsh plugin --profile desktop add link:/absolute/path/to/qoder-to-dsh
```

或在 DSH 里让 agent 执行 `plugin_manager` 的 `install_bundle`，`target` 传包的绝对目录。

装完确认 profile 的 `package.json` 里同时有依赖和 bundle 选择：

```json
{
  "dependencies": { "qoder-to-dsh": "link:/absolute/path/to/qoder-to-dsh" },
  "dsh": {
    "profile": {
      "bundles": ["@deepseek-ai/dsh-base", "@deepseek-ai/dsh-web-app", "qoder-to-dsh"]
    }
  }
}
```

用 A / B 安装时，`dependencies` 的值是版本号或 `github:` 规格，不是 `link:`，其余不变。

**装完自检**（只读，不会改动状态；需在仓库目录里执行）：

```bash
npm run verify              # 连运行中的 dsh 一起检查
npm run verify -- --offline # 只看文件和 profile 配置
```

它会检查「装包 ≠ 启用」、`link:` 是否指向本仓库、patch 里的 name 是否与包名一致、provider 是否注册、模型目录是否为空。任一项 FAIL 就退出码 1。

最后**完全退出 DSH 再打开**（托盘退出；插件在宿主启动时加载，只重开面板不会换掉已加载的代码）。

> 基线：dsh ≥ 0.2.1-rc.3（本项目实测与发版验证使用的版本）。更老的宿主可能没有 `registerAdapter` 或面板 `webServer.register`。

### 升级 / 回滚 / 卸载

- **升级**：安装新版本 tgz（或更新 GitHub / link 依赖）后完全退出 dsh 再打开。凭据、偏好、用量与目录都在 `<DSH_HOME>/qoder`，升级不会清空。
- **回滚**：重新安装上一版 tgz 并完全重启。数据文件保持向后兼容；降级前建议复制一份 `<DSH_HOME>/qoder` 作为备份。
- **卸载**：在 dsh 设置 → 插件中移除 `qoder-to-dsh`（或从 profile 的 `dependencies` / `dsh.profile.bundles` 删掉），然后完全退出 dsh。删除 `<DSH_HOME>/qoder` 会同时清除本机凭据、偏好、签到与用量记录。

### 2. 登录

打开 **设置 → Qoder**。首次使用会自动只读扫描本机 Qoder 桌面端 / CLI 的登录态：

- 有桌面端登录：直接出现账号与模型，无需再次授权；
- 没有：点“浏览器授权”，在打开的 Qoder 页面选择账号；或展开“使用 PAT / 访问令牌”；
- 国内版 / 国际版都支持，可在账号页切换；
- 本机登录了多个账号时，概览右上角可以一键切换当前账号，签到页会列出所有本机账号并分别领取。

凭据保存到 `<DSH_HOME>/qoder/auth.json`：Windows 上用 **DPAPI** 加密；其他平台退回 AES-256-GCM + 本机 0600 密钥文件。

### 3. 使用

在 DSH 模型选择器里选择任意 Qoder 模型。默认 provider 名是 `qoder`，模型 id 就是上游 key（例如 `qmodel_38max`、`auto`、`dmodel`）。

```text
/qoder status
/qoder models
/qoder usage
/qoder checkin [run]
/qoder diagnose
/qoder refresh
/qoder test [model]
/qoder login
/qoder logout
```

模型选择器里可以直接看到每个模型的思考档位（`low/medium/xhigh` 等）、上下文、图片能力和价格倍率。

## 功能

- **原生 provider**：不写 `settings.yaml`，不改 DSH 的模型路由配置。
- **流式对话**：思考内容、正文、工具调用、usage、AbortSignal 全链路透传；首包 90 秒 / 块间空闲 120 秒超时，超时以可见的 `TIMEOUT` 结束，不会无限挂起。
- **工具调用**：DSH 声明的 function tools 原样进入 Qoder 请求；工具结果回灌时剔除孤儿消息与空助手轮。
- **图片**：通过 DSH `attachments.readImage` 转 data URL，交给支持视觉的模型。
- **模型目录**：动态读取 `/algo/api/v2/model/list`；有缓存先展示、过期后台刷新，显式刷新仍等待上游；解析 `context_config`、`thinking_config`、`price_factor` 与谷时折扣；面板显示 200K / 400K / 1M 上下文档位、输出默认值、促销与官方标记。目录缓存带客户端 CLI 版本，客户端升级后自动后台刷新，不清空选择器。
- **模型参数**：每个模型可单独设置上下文窗口、默认思考档位、温度和最大输出，并提供自动 / 0 / 0.3 / 0.7 / 1 与 4K / 8K / 16K / 32K 快捷值。输出「自动」对齐 Qoder 官方 CLI 的 32K 默认；模型声明了输出上限时优先用上限。温度「自动」表示不传 `temperature`，由上游决定。保存后写进 `prefs.json`，DSH 下一次 `listModels` / `stream` 就使用新值，可一键恢复官方默认。
- **账号**：桌面端自动导入、OAuth 设备授权、PAT 导入、令牌自动刷新（`drt-` / `jrt-` / PAT 交换）。账号页支持别名、上移/下移、隐藏/恢复与切换落盘；同一账号的多份桌面/CLI 快照合并成一行，当前账号即使被隐藏也保留可见标记。切换仍只改插件，不动官方客户端登录态。
- **额度**：读取上游 `plan` 与 `quota`，归一化成可分组的多包结构；同名不同到期日分开显示、不限量显示 `∞`、额度接口 404/405 或上游 userId 与当前账号不一致会明确标注。7 天内到期和已过期会显示徽标；概览首屏就是额度卡，额度用尽会标红；对话页顶部胶囊也显示当前账号额度与已用百分比，临期会变黄。
- **每日签到**：读取本机 Qoder 客户端的 `runtime-info` 设备身份，查询 `campaigns` 并领取 `CLAIM_BENEFIT`；支持本机所有已登录账号、自动签到（默认开启）、手动逐账号领取，以及今日已领 / 未开放 / 无活动 / 未下发 / 缺设备 / 需登录等状态。活动每天 10:00（UTC+8）开放，DSH 运行期间对“未下发”和临时错误继续重试；缺设备或登录失效的账号当天不再空转，修好后可手动领取。非激活账号的令牌过期时会只读重读官方登录态，不拿刷新令牌去轮换官方凭据。可用 `QODER_CHECKIN=0` 彻底关闭自动签到。
- **多账号**：账号页首屏直接列出本机桌面端 / CLI 的国际版、国内版账号，概览也可展开切换；每个账号显示来源、到期时间和今日签到状态。当前仍只使用一个激活账号，不做池化或自动切号。
- **PAT 凭据库**：同一区域可保存多枚 `pt-` PAT，整文件用 DPAPI / AES-GCM 加密；账号页列出名称、区域、uid 尾号与上次使用时间，可切换或删除。切换时重新走 `jobToken/exchange`，不把短期访问令牌再抄一份；面板与诊断包永不返回 PAT。
- **用量**：本地记录请求数、tokens、缓存、推理 tokens、实际扣费 Credits、已省 Credits、首字 / 总耗时、客户端来源和账号尾号；面板支持最近 7 / 14 / 30 天、按模型与账号聚合、成功 / 失败筛选与上游错误详情，并可按天导出 CSV。Tokens 卡会显示缓存命中率，便于判断前缀缓存是否生效。只保留元数据，不记录对话内容。
- **请求明细**：独立页签，按时间/模型/状态/首字/耗时/输入输出/缓存/账号/Credits 展示最近请求；缓存列显示命中 tokens 与比例。支持模型筛选、仅失败、暂停轮询、复制单条和 CSV 导出（BOM、公式注入防护）。
- **Credits 分析**：近 12 个自然月的每日实际扣费热力图；按今天 / 7 天 / 30 天 / 月初至今 / 上个月切换，支持按全部、模型或客户端查看平滑趋势线、悬停明细和图例合计；免费模型不计入消耗，单独显示已省金额。图表支持键盘切换日期与点按查看明细。
- **试跑**：在面板里选择模型、输入 prompt，走真实上游并显示思考过程、回复、usage、首字 / 生成耗时 / tok/s 与思考 tokens；默认使用模型支持的最低思考档位以缩短等待，可切回已保存档位，本次选择不保存。结果同时计入用量；等待中可随时取消，面板中断会通过 `AbortSignal` 传到宿主与上游，不再继续等待（上游可能已产生少量计费）。未登录时对话页胶囊可直接发起浏览器授权。
- **诊断**：凭据、令牌、目录、原生路由、存储、偏好、额度、签到设备身份、PAT 凭据库、最近错误与运行环境；新增客户端安装/版本、COSY 协议版本、设备身份来源、数据目录搬迁、目录缓存账号与推理端点 6 项。日志自动脱敏，诊断包会把邮箱和 uid 截断后再复制。
- **面板**：概览 / 签到 / 模型 / 试跑 / 用量 / 请求 / 账号 / 诊断 / 日志；低饱和森林绿配色、带水平滑动高亮块的胶囊页签、自绘下拉菜单、账号栏底块、响应式布局，明暗主题跟随 DSH；无渐变、无 emoji、数字等宽，页签切换统一淡入上浮过渡并保留试跑状态，尊重 `prefers-reduced-motion`。首屏不会在状态未返回时误报未登录，读取失败会给出就地重试而不是无限骨架；页签、下拉、分段控件、图表和账号排序都有键盘路径。中英双语留到 1.5。
- **斜杠命令 + 4 个只读工具**：agent 可以自己回答“Qoder 现在能不能用、有哪些模型、今天花了多少”。

## 性能

- **本地准备**：目录命中缓存时，`prepareCall` 只是内存查表；组包、COSY 签名和请求体编码走 Buffer 码表，典型请求的本地开销在毫秒级。
- **不挡首包**：目录过期只触发后台刷新，显式刷新才等待上游；启动时不扫描本机账号，DPAPI key 在后台预热。
- **连接复用**：聊天请求使用持久化 keep-alive Agent，不再受 Node `fetch` 默认 4 秒空闲回收的限制；服务端主动断开时仍会正常重连。
- **流式与落盘**：SSE 帧到达即翻译并下发；用量记录内存合并后异步写入，不阻塞消息结束。
- **真正的大头**：首包与首字时间主要来自上游排队与思考 tokens。面板「试跑」会显示首字、生成耗时、tok/s 和思考 tokens，方便判断是网络、排队还是思考开销。

## 数据与安全

| 文件 | 内容 |
|---|---|
| `<DSH_HOME>/qoder/auth.json` | 加密凭据（DPAPI / AES-GCM）；面板永远不返回令牌 |
| `<DSH_HOME>/qoder/prefs.json` | 模型显示 / 默认 / 上下文 / 参数偏好 |
| `<DSH_HOME>/qoder/accounts.json` | 账号别名 / 顺序 / 隐藏与上次切换，只存展示元数据，不含令牌 |
| `<DSH_HOME>/qoder/pats.json` | 多枚 `pt-` PAT（整文件 DPAPI / AES-GCM 加密）；面板只读元数据 |
| `<DSH_HOME>/qoder/client.json` | 最近一次见到的 Qoder 客户端 app/CLI 版本，用于升级提示与目录刷新 |
| `<DSH_HOME>/qoder/checkin.json` | 自动签到开关、各账号最近一次签到结果（不含令牌） |
| `<DSH_HOME>/qoder/usage.json` | 最多 5000 条请求明细（不含 prompt / 回复；含实扣与已省 Credits、账号尾号） |
| `<DSH_HOME>/qoder/usage.daily.json` | 每日用量汇总，覆盖近 12 个月热力图；只有计数与 Credits，不存模型名、prompt 或回复 |
| `<DSH_HOME>/qoder/catalog.json` | 模型目录缓存 |
| `<DSH_HOME>/qoder/qoder.log` | 脱敏运行日志；超过 2MB 轮转为 `qoder.log.1`，只保留一份旧日志 |

安全约束：

- 只读扫描 Qoder 官方客户端文件，不修改官方登录态；
- 不把 access token / refresh token / machineToken 写进日志、面板响应或错误消息；
- 签到结果只保存账号标签、区域、状态和 Credits 数字，不保存任何令牌；
- 桌面端导入的凭据临近过期时，优先只读重读官方存储；只有读不到新令牌时才用 refresh token，避免同一个 `drt-` 的轮换影响官方客户端；
- 写接口与有副作用的 GET（`?rescan=1` / `?refresh=1` / 诊断刷新 / 账号与模型目录读取）要求 `x-qoder-panel: 1`（自定义头触发 CORS 预检，挡掉跨站简单请求）；这只防跨站与误触，不替代 dsh 自身的访问控制；
- 额度明细 / 升级链接只接受绝对 `http(s)` 地址，`javascript:` / `data:` / 协议相对链接会被丢弃；
- Windows 上优先用 DPAPI；受限环境回退 AES-256-GCM 时，诊断页会如实显示「本机密钥回退」，不会继续标成 DPAPI；
- 不新增监听端口；所有面板数据走 DSH 自己的 loopback Web 载体；
- 不内置任何密钥、账号或额度；COSY 公钥来自 Qoder 公开客户端协议，仅用于互操作。

## 已知限制

- **非官方路径**：Qoder 可能修改签名、模型 key 或上游 schema；失效时先看「诊断」页。
- **单激活账号**：模型请求始终使用当前激活的一个账号；支持在本机已登录的国际版 / 国内版账号之间切换，并会对所有本机账号执行每日签到；不做多账号池化、负载均衡、自动切号、代他人调用、转售或托管。
- **账号排序用按钮**：提供上移/下移按钮（可键盘聚焦），未做拖拽；别名最长 24 字，只存展示元数据。
- **PAT 凭据库只收 `pt-`**：`dt-` / `jt-` 仍可作为一次性令牌登录，但不会保存。切换 PAT 会重新换取短期令牌，因此需要网络；删除当前正在使用的 PAT 必须先在账号页切换或退出登录。
- **缓存命中率是前缀缓存**：按 `cached_tokens / prompt_tokens` 计算，只反映上游前缀缓存命中，不代表计费折扣；系统提示词、工具顺序和会话历史变化都会影响它。
- **额度到期是上游时间**：7 天预警取自 `quota.expiresAt` 或套餐 `end_date`；上游不返回到期时间时显示“不限期”，不要把预警当成账单承诺。
- **试跑会花额度**：面板的试跑和 `/qoder test` 都是真实上游请求，会计入上游 Credits；本地账本把它标成 `probe` 并排除在常规请求 / 热力图统计之外，但记录仍保留在明细里。只是验证链路时用最小 prompt。取消会把中断传到上游并停止等待，但已经产生的 token 仍可能被上游计入。
- **Credits 按上游实扣统计**：以 `usage.billable` 为准。Qoder 对免费模型也会返回原价 `credits`（`billable: false`），这部分显示为“已省”，不计入消耗；折扣请求同样只记实扣。旧版本留下的免费模型记录会按当前目录的免费标记只读修正统计，不改写原始 usage 文件。
- **上下文档位以 Qoder 的 `context_config` 为准**：DeepSeek-V4-Flash / Pro、Qwen3.8-Max 等模型提供 200K / 400K / 1M。旧版本误用 `max_input_tokens` 把档位砍成 180K / 96K，已修正；选择 1M 会写回请求的 `model_config.max_input_tokens`。上游仍可能按账号或网关策略截断，超长上下文请以诊断页和实际响应为准。
- **工具调用历史**：assistant 的 `tool_calls` 统一带空字符串 `content`（Qoder 网关不接受 `null`，否则会误报 `Messages with role 'tool'...`）；带工具调用的历史也能继续复用。
- **模型参数是本地偏好**：上下文窗口 / 思考档位 / 温度 / 最大输出只影响本插件发给上游的请求与 DSH 选择器，不会修改 Qoder 官方客户端设置；上游仍可能按自己的模型上限拒绝或截断。输出「自动」是 32K（Qoder 官方 CLI 默认），可手动调高；温度没有公开的聊天默认值，插件不猜。
- **签到也是非官方接口**：使用本机 Qoder 客户端 `runtime-info` 生成的设备身份，活动每天 10:00（UTC+8）后开放；平台可能调整活动或风控。自动签到默认开启，可在「签到」页关闭，或用 `QODER_CHECKIN=0` 禁用；DSH 没运行时不会签到。没有活动时会明确显示「无活动」或「未开放」，不会混进待领取或异常；缺设备 / 需登录的账号当天不自动重试。
- **错误码与重试**：10605 排队会按 `retryAfter` 自动等待（上限 60 秒）；110 日限、112 额度、430 版本门、12153 / TOKEN_EXPIRE 会话失效、内容审核和 114 试用受限不会被盲目重试；普通 401 / 403 仍会刷新一次令牌。
- **完成度**：只有思考内容、没有正文或工具调用时以 `EMPTY_RESPONSE` 结束；工具名为空/不合法或参数不是完整 JSON 时会拒绝写入会话并给出可见错误。
- **面板数据口径**：额度为 0 或字段缺失会显示 0 / `—`，诊断里缺失额度是 warn；目录、额度和用量都带更新时间，用量明细会标出试跑、账号尾号与“部分历史来自每日汇总”。版本漂移会在顶部提示，需完全退出 dsh 才能换代码。
- **超时是本地判定**：首包默认 90 秒、块间空闲默认 120 秒；可通过插件配置 `firstByteTimeoutMs` / `streamIdleTimeoutMs` 调整（0 表示不限）。超时只会停止本地等待，已经发出的上游请求仍可能产生少量 Credits。
- **用量写入是合并异步的**：正常退出与插件卸载会同步补写；进程被强制结束时，最后一条记录可能还没落盘。明细上限 5000 条，每日汇总独立保留 430 天并用它绘制 12 个月热力图；同一天只选明细或汇总其中一个来源，不会重复计数。多个 dsh 进程同时写同一数据目录时，汇总按最大值合并，可能少算而不是多算。只影响本地统计，对话内容仍然从不记录。
- **多账号只切换插件**：账号来自本机官方客户端的只读扫描；切换只改插件当前使用的账号，不会写入或退出官方客户端。
- **协议**：当前使用已实测的 COSY + `agent_chat_generation` 路径；COSY 版本和 OAuth UA 跟随客户端内置 CLI（本次 1.1.79-hotfix.7），可用 `QODER_COSY_VERSION` / `QODER_OAUTH_UA` 覆盖，`QODER_PROTOCOL=legacy` 一键回退到 1.1.75。更新版 Bearer 端点存在但模型 id 体系不同，未作为默认路径。
- **双语**：面板当前只有中文；完整英文界面留到 1.5，避免仓促机翻出现半中半英。
- **设备授权 / PAT**：协议流程已实现，离线回归覆盖 PAT、设备授权与过期令牌重试；本次实机验证主要走桌面端导入，欢迎用真实 PAT 补一次实机回归。
- **图片 / 工具调用**：取决于上游模型与账号能力；失败会以可见错误结束，不会伪造成功。
- **Windows 凭据导入**依赖 PowerShell DPAPI；无 PowerShell 的精简环境会退回 AES 本地密钥模式（仍不落明文 token），诊断页会显示实际的「本机密钥回退」。

## 故障排查

| 现象 | 先做什么 |
|---|---|
| 设置页一直 404 / 插件像没装 | 确认 profile 的 `dsh.profile.bundles` 里有 `qoder-to-dsh`，再**完全退出 dsh** 重开；只重开面板不会重新加载代码 |
| 升级后行为没变 | 旧代码仍在宿主进程里。托盘退出 dsh 再启动；热重载不会替换已注册的 provider |
| 模型选择器为空 | 设置 → Qoder → 账号确认已登录；点「刷新目录」；仍为空就看诊断页的目录错误 |
| 诊断显示「凭据恢复：corrupt」 | 本地 `auth.json` 无法解密。不会自动切到别的账号，请重新授权；必要时删除该文件再登录 |
| 凭据加密显示「本机密钥回退」 | 当前环境的 PowerShell / DPAPI 不可用，已退回 AES-256-GCM；功能不受影响，但请确保数据目录只有本机用户可读 |
| 回复半截 / 连接中断 | 检查网络或代理；诊断页看「最近错误」；`TRANSPORT` / `TIMEOUT` 可重试，换号导致的取消需要确认当前账号后重试 |
| 额度明细 / 升级链接不可点 | 上游返回的不是绝对 `http(s)` 地址，已被安全过滤；这不影响额度读取 |
| 热力图与最近列表对不上 | 明细只保留 5000 条，热力图优先用每日汇总；重度使用时热力图比“最近请求”列表更完整，属于预期行为 |
| 日志太大 | 超过 2MB 自动轮转为 `qoder.log.1`，只保留一份；可在诊断页查看最近日志 |

## 更新记录

每个版本的完整变更见 **[CHANGELOG.md](CHANGELOG.md)**；发布说明（含升级步骤与资产 SHA-256）见 [Releases](https://github.com/Ianzhyh/qoder-to-dsh/releases)。

当前版本 `1.5.1` 是 1.5.0 的缺陷收口：诊断包不再在检查详情里泄露邮箱/完整 uid；额度过期不足一天、只有 total 无 remaining、无限额度胶囊 `-1`、只有加量包时重复显示都已修正；当前账号隐藏后可恢复，隐藏行不再让上移/下移空转；PAT 切换后桌面登录/退出不再留下旧「当前」标记，凭据库写入失败不会把已成功的切换报成失败；账号切换后额度卡不再沿用上一个账号。`1.5.0` 在 1.4.0 基础上补四件日常会用到的事：多枚 `pt-` PAT 加密保存并在账号页一键切换/删除；请求明细和用量页展示缓存 tokens、缓存命中率；额度 7 天内到期、已过期会显示徽标；对话页额度胶囊补上已用百分比并对临期变黄。中英双语留到 1.6。`1.4.0` 对齐 **Qoder 0.5.1** 并补齐账号、额度、请求与诊断：COSY 版本/UA 跟随客户端内置 CLI（1.1.79-hotfix.7，可回退 1.1.75），读取 endpoint cache、`umid-cache.json` 与 `location.v1.json`；账号支持别名、上移/下移、隐藏/恢复、多快照合并与切换落盘；额度卡支持多包分组、不限量与账号不一致提示；新增请求明细页（筛选/暂停/CSV/公式注入防护）和独立日志页；诊断新增 6 项客户端/协议/缓存检查与脱敏诊断包；客户端升级后提示 401 重登并后台刷新目录。`1.3.1` 收口网关切换、取消语义与面板读接口的跨站保护：网关 5xx 切换不再挂死，取消/换号不再被当成可重试的传输错误，PAT 验证失败与凭据落盘失败都会如实报错；`/qoder/account` 与 `/qoder/models` 重新要求面板头。面板同时完成动效、材质与 rem 字阶打磨，图表切区间失败会标注仍在展示旧数据。`1.3.0` 把上游错误与完成度做成可信语义：10605 模型排队会按 retryAfter 自动等待，110 日限/430 版本门/12153 会话失效不再盲重试；只有思考内容、没有正文或工具调用时以 EMPTY_RESPONSE 结束；空工具名/非法参数会被拦下；额度为 0 或缺失时不再假绿；面板会提示版本漂移、说明参数生效范围，并给用量明细加试跑/账号/汇总标签。`1.2.1` 收口「静默失败与取消传播」：后台目录刷新失败会同步到面板，不再只写日志；`qoder_diagnose` 与诊断面板会响应宿主取消，签到在插件卸载/热重载后停止继续账号并取消在途请求。`1.2.0` 修「看起来成功、实际失败」与账号/用量边界：提前取消的流不再记成功、429 响应体含 credits 仍按可重试限流处理；换号/退出会取消在途请求，损坏的本地凭据不再静默切换账号；用量新增 12 个月每日汇总并把试跑单独标记，插件卸载会同步落盘；有副作用的面板 GET 需要面板头，额度链接只允许 http(s)。`1.1.4` 修「设置看起来生效、实际没生效」与账号切换竞态：温度现在真的写进上游参数、换号会清空模型目录、官方客户端的旧令牌不再覆盖插件刚刷新的令牌、目录响应中断不再变成未捕获异常、诊断不再被 20 秒客户端超时截断。`1.1.3` 修流结束、令牌刷新、换号与本地账本之间的竞态：截断的信封流不再被补成成功、并发刷新合并并隔离账号、无效 PAT 回滚、试跑取消会中止上游、目录缓存按账号隔离、清除用量不再被在途写盘复活。`1.1.2` 补齐面板在宿主刚启动、标签页在后台、账号刚切换时的行为。`1.1.1` 修掉三个「留到线上才暴露」的问题：断流被当成正常结束、不合法工具名导致整轮失败且不点名、面板请求没有超时。`1.1.0` 的要点是聊天 SSE 走持久连接、模型目录先返回后刷新、启动不再扫本机账号、凭据与用量异步落盘。详见 [v1.5.1 发布说明](docs/releases/v1.5.1.md)、[v1.5.0 发布说明](docs/releases/v1.5.0.md)、[v1.4.0 发布说明](docs/releases/v1.4.0.md)、[v1.3.1 发布说明](docs/releases/v1.3.1.md)、[v1.3.0 发布说明](docs/releases/v1.3.0.md)、[v1.2.1 发布说明](docs/releases/v1.2.1.md)、[v1.2.0 发布说明](docs/releases/v1.2.0.md)、[v1.1.4 发布说明](docs/releases/v1.1.4.md)、[v1.1.3 发布说明](docs/releases/v1.1.3.md)、[v1.1.2 发布说明](docs/releases/v1.1.2.md)、[v1.1.1 发布说明](docs/releases/v1.1.1.md) 与 [v1.1.0 发布说明](docs/releases/v1.1.0.md)。

## 开发

```bash
npm test                 # 纯函数 / 流翻译 / 传输 keep-alive / 目录单飞与 SWR / 编码等价 / 用量合并写 / 登录 / 签到 / Credits / 宿主路由 / 客户端 404 与后台轮询
npm run check            # 所有模块语法检查
npm run verify           # 安装自检：文件 / profile / 运行态（只读）
npm run test:live        # 实机回归：会真实调用一次 Qoder（消耗少量 Credits）
```

发版用的三个脚本：

```bash
npm run release:check    # 发版门禁：语法 + 全部用例 + 安装自检（--offline）
npm run pack:release     # 生成 qoder-to-dsh-<version>.tgz
npm run verify:release   # 校验 tgz：产物新鲜度 / 文件清单 / 双份版本号 / patch 名 / exports / locale / 文档版本 / sha256
```

`verify:release` 也可以传 Release 资产 URL，直接校验**已发布**的那一份（只在内存里解包，不写磁盘）：

```bash
npm run verify:release -- https://github.com/Ianzhyh/qoder-to-dsh/releases/download/v1.5.1/qoder-to-dsh-1.5.1.tgz
```

第三方许可与归属信息见 [NOTICE.md](NOTICE.md)。

## License

MIT。Qoder、DeepSeek Harness 及相关商标归各自所有者；本项目与官方无隶属关系。
