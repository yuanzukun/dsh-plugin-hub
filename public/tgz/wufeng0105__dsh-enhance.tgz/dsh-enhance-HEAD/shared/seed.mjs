/**
 * 首次数据目录的种子。
 *
 * bundle 安装（`dsh plugin --profile <p> add …`）没有安装器阶段，host 直接加载包里的插件；
 * 插件第一次 `apply()` 时把 `<home>/enhance/` 的两份文件补齐。
 *
 * 所以这里只做两件事：复用「审批种子规则」，以及一个**幂等**的补文件函数。
 * 已有内容一律不覆盖；任何 IO 失败都吞掉并回报，让插件继续走「读不到」的诊断路径，
 * 而不是启动即崩。
 *
 * @module shared/seed
 */

import { copyFileSync, existsSync, mkdirSync, readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { paths, readState, writeState } from './state.mjs'
import { defaultPresetApproval } from './preset-shape.mjs'

/**
 * 首装该种哪一档审批。
 *
 * 宿主在 `user-approval` 里先判档位策略（审批策略 `approval/policy`，不是本仓的开关档 `approval`）：
 * `never` 的档位在分发前就 `rejected`，我们种的 `allow` 永远轮不到。
 * 所以播种要看这台机器的实际默认档位，不能无条件种 `allow`：只要有一个目标 profile
 * 的 `defaultPreset` 是 `never`，就种 `ask`（问人，语义诚实）并带出是谁。
 *
 * @param {{ profile?: string, text: string }[]} patches
 * @returns {{ approval: 'allow' | 'ask', blockedBy: string | undefined }}
 */
export function decideApprovalSeed(patches) {
  for (const patch of patches) {
    const preset = defaultPresetApproval(String(patch?.text ?? ''))
    if (preset?.approval === 'never') {
      return { approval: 'ask', blockedBy: `${patch.profile ?? '?'}:${preset.name}` }
    }
  }
  return { approval: 'allow', blockedBy: undefined }
}

/** 扫 `<home>/profiles/<name>/cordis.patch.yml`，按同一规则决定种子。 */
export function seedApprovalForHome(home) {
  const dir = join(home, 'profiles')
  let entries
  try {
    entries = readdirSync(dir, { withFileTypes: true })
      .filter((entry) => entry.isDirectory())
      .map((entry) => {
        let text = ''
        try {
          text = readFileSync(join(dir, entry.name, 'cordis.patch.yml'), 'utf8')
        } catch {
          // 没有 patch 的 profile 不参与判断
        }
        return { profile: entry.name, text }
      })
  } catch {
    return 'allow'
  }
  return decideApprovalSeed(entries).approval
}

/**
 * 补齐 `<home>/enhance/`：
 *   - 目录不存在就建；
 *   - `content-scope.txt` 不存在时，从 `defaultTextPath`（包内默认文本）复制一份；
 *   - `state.json` 不存在时，按 `seedApprovalForHome()` 种下五个开关。
 *
 * 已存在的文件一个字节都不动。返回实际种了哪些，以及（如果有）失败原因。
 *
 * `identity.txt` 不在这里播种：品牌人设默认 `keep`，没有自定义文本要写。
 * 用户第一次在设置页选「自定义」时才创建它。
 *
 * @param {string} home
 * @param {string} [defaultTextPath]
 * @returns {{ textSeeded: boolean, stateSeeded: boolean, error?: string }}
 */
export function ensureEnhanceData(home, defaultTextPath) {
  const p = paths(home)
  const result = { textSeeded: false, stateSeeded: false }
  try {
    if (!existsSync(p.text) && typeof defaultTextPath === 'string' && existsSync(defaultTextPath)) {
      mkdirSync(p.dir, { recursive: true })
      copyFileSync(defaultTextPath, p.text)
      result.textSeeded = true
    }
  } catch (error) {
    result.error = `content-scope: ${String(error?.message ?? error)}`
  }
  try {
    const state = readState(p)
    if (state.degradedReason === 'missing') {
      // writeState 是整块重建：种子必须把 v4 五键带全，否则首装的那一刻身份就丢了默认值
      writeState(p, {
        enabled: true,
        contentScope: true,
        approval: seedApprovalForHome(home),
        identity: 'keep',
        hideHarness: false,
      })
      result.stateSeeded = true
    }
  } catch (error) {
    result.error = `${result.error === undefined ? '' : `${result.error}; `}state: ${String(error?.message ?? error)}`
  }
  return result
}
