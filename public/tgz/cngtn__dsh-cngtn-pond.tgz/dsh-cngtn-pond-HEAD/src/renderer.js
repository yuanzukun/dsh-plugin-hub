/**
 * renderer.js — the ASCII rasteriser, ported from the original site's `renderer.ts`.
 *
 * The fish are not drawn, they are *etched*: the pond is a grid of monospace
 * cells, each carrying one glyph, one glyph colour, one tile fill and one
 * tile alpha. Body coverage is sampled at five points per cell (centre plus
 * four quarter points), shading comes from a round-body luminance profile, and
 * glyph density encodes brightness — the halftone trick that makes a koi read
 * as ink on paper rather than as a vector sprite.
 *
 * Two details matter more than the rest, and both are preserved exactly:
 *
 *  - Glyph keys are hashed from *body* coordinates (`s`, `v`) and the koi id,
 *    never from screen position, so a glyph rides along with the skin instead
 *    of flickering every frame.
 *  - The two palettes are not inverses of each other. On dark, a koi is lighter
 *    than the paper and its glyphs are dark; on light, a koi is darker than the
 *    paper and its tiles are pale. Same algorithm, opposite contrast direction.
 */

import {
  bodyHalfWidth,
  classify,
  FLAG_BARBEL,
  FLAG_EYE,
  FLAG_FIN,
} from './shape.js';

import {
  clamp,
  hash3,
  BITE_LIFE,
  KOI_NODES,
  PELLET_LIFE,
  PELLET_SINK,
  RIPPLE_SPEED,
  rippleLife,
  smoothstep,
} from './world.js';

const DARK = {
  bg: [26, 25, 33],
  white: [236, 228, 218],
  red: [232, 96, 56],
  black: [92, 90, 108],
  // Asagi's back. Cooler and lighter than `black`, so the fish reads as blue-grey
  // rather than as a black fish with a blue belly.
  slate: [120, 132, 146],
  fin: [214, 206, 198],
  eye: [20, 20, 26],
  water: [255, 247, 240],
  shadow: [0, 0, 0],
  shadowAlpha: 0.55,
  pellet: [236, 170, 92],
  alpha: 0.8,
  depthFloor: 0.4,
  tile: [0.68, 0.98],
  hi: [
    [112, 22, 24],
    [168, 34, 28],
    [214, 58, 30],
    [240, 96, 34],
    [250, 138, 52],
    [255, 178, 96],
  ],
  ink: 0.42,
};

// Paper page: tiles are pale washes of the skin colour with dark glyphs etched on top.
const LIGHT = {
  bg: [245, 244, 241],
  white: [112, 108, 104],
  red: [204, 62, 28],
  black: [36, 33, 40],
  slate: [104, 116, 128],
  fin: [138, 132, 126],
  eye: [24, 22, 26],
  water: [38, 37, 35],
  shadow: [60, 58, 56],
  shadowAlpha: 0.2,
  pellet: [176, 108, 40],
  alpha: 0.9,
  depthFloor: 0.55,
  tile: [0.78, 0.55],
  hi: [
    [138, 24, 22],
    [184, 38, 24],
    [222, 62, 28],
    [238, 100, 38],
    [244, 140, 66],
    [248, 176, 116],
  ],
  ink: 0.45,
};

// Dense glyphs etched into each skin tile, sparse where it catches the light.
const TILE_GLYPHS = 't%SX8@#';
const SUBSAMPLES = [0.25, 0.25, 0.75, 0.25, 0.25, 0.75, 0.75, 0.75];

// A line glyph that follows a direction in screen space, for fin rays and ripple rings.
function lineGlyph(dx, dy) {
  const d = Math.hypot(dx, dy) || 1;
  if (Math.abs(dy) < 0.38 * d) return '-';
  if (Math.abs(dx) < 0.38 * d) return '|';
  return dx * dy > 0 ? '\\' : '/';
}

function valueNoise(x, y, seed) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const u = smoothstep(0, 1, x - xi);
  const v = smoothstep(0, 1, y - yi);
  const a = hash3(xi, yi, seed);
  const b = hash3(xi + 1, yi, seed);
  const c = hash3(xi, yi + 1, seed);
  const d = hash3(xi + 1, yi + 1, seed);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

function inPatch(m, s, vn, wobble) {
  return ((s - m.s) / m.rs) ** 2 + ((vn - m.v) / m.rv) ** 2 < 1 + wobble;
}

/** '#rrggbb' to [r, g, b]. */
function hexToRgb(hex) {
  const v = parseInt(hex.slice(1), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
}

/**
 * A six-stop ramp for one pigment, from shadowed to sunlit.
 *
 * The original theme had a single hard-coded vermilion ramp. A pond with more
 * than one colour needs the same *shape* of ramp for every pigment, so the stops
 * are derived from the accent itself: darken toward the page colour for the
 * shadowed end, lift toward the water colour for the lit end. That keeps every
 * fish shaded by the same logic, and stops a gold koi from reading as a red one
 * with a different hue.
 */
function rampFor(accent, palette) {
  const base = hexToRgb(accent);
  const shadow = palette.bg;
  const light = palette.water;
  return [
    mix(base, shadow, 0.55),
    mix(base, shadow, 0.3),
    base,
    mix(base, light, 0.18),
    mix(base, light, 0.38),
    mix(base, light, 0.58),
  ];
}

/**
 * Each koi gets a fixed set of markings, seeded by its id, so every fish carries
 * a clear pattern. The varieties are the ones a real pond is stocked with:
 *
 *  - kohaku  white, with an accent head and two or three saddles
 *  - sanke   kohaku plus small black spots
 *  - tancho  white, with a single accent disc on the crown
 *  - showa   black back, with accent and white patches
 *  - ogon    a single metallic colour, paler along the belly
 *  - asagi   slate back, accent along the belly
 *  - bekko   white, with black spots only
 *
 * \`base\` is what the body is where no patch applies; the lists are drawn over
 * it. Keeping the pattern in body coordinates is what makes a fish look like it
 * is swimming rather than like a texture sliding over it.
 */
export function koiMarkings(k) {
  const r = (j) => hash3(k.id, j, 41);
  const saddles = (count, start = 0.25, spanTotal = 0.42) => {
    const out = [];
    const span = spanTotal / count;
    for (let j = 0; j < count; j++) {
      out.push({
        s: start + span * (j + 0.5) + (r(10 + j) - 0.5) * span * 0.3,
        v: (r(20 + j) - 0.5) * 0.05,
        rs: span * (0.32 + r(30 + j) * 0.12),
        rv: 0.09 + r(40 + j) * 0.05,
      });
    }
    return out;
  };
  const spots = (count, spread = 0.44) => {
    const out = [];
    for (let j = 0; j < count; j++) {
      out.push({ s: 0.24 + r(60 + j) * spread, v: (r(70 + j) - 0.5) * 0.16, rs: 0.022, rv: 0.026 });
    }
    return out;
  };

  switch (k.variety) {
    case 'tancho':
      return { base: 'white', accent: [{ s: 0.11, v: 0, rs: 0.05, rv: 0.055 }], black: [], white: [] };
    case 'ogon':
      return { base: 'accent', accent: [], black: [], white: [] };
    case 'asagi':
      return { base: 'slate', accent: [{ s: 0.5, v: 0, rs: 0.34, rv: 0.2 }], black: [], white: [] };
    case 'bekko':
      return { base: 'white', accent: [], black: spots(6, 0.5), white: [] };
    case 'showa': {
      const white = [];
      const patches = 2 + Math.floor(r(40) * 2);
      for (let j = 0; j < patches; j++) {
        white.push({ s: 0.2 + r(80 + j) * 0.5, v: (r(90 + j) - 0.5) * 0.18, rs: 0.05, rv: 0.07 });
      }
      return { base: 'black', accent: saddles(2 + Math.floor(r(3) * 2)), black: [], white };
    }
    case 'sanke':
      return {
        base: 'white',
        accent: saddles(2 + Math.floor(r(3) * 2)),
        black: spots(4 + Math.floor(r(50) * 3)),
        white: [],
      };
    default: {
      const accent = [];
      if (r(0) < 0.75) accent.push({ s: 0.1, v: (r(1) - 0.5) * 0.03, rs: 0.055 + r(2) * 0.03, rv: 0.11 });
      accent.push(...saddles(2 + Math.floor(r(3) * 2)));
      return { base: 'white', accent, black: [], white: [] };
    }
  }
}

/**
 * The tone names each palette provides. Exported so a test can prove that every
 * variety's base tone exists in *both* palettes — the check that would have
 * caught the missing `slate` before it froze the pond.
 */
export function paletteTones() {
  return { dark: Object.keys(DARK), light: Object.keys(LIGHT) };
}

const packRgb = (c) => (c[0] << 16) | (c[1] << 8) | c[2];

const mix = (a, b, k) => [
  (a[0] + (b[0] - a[0]) * k) | 0,
  (a[1] + (b[1] - a[1]) * k) | 0,
  (a[2] + (b[2] - a[2]) * k) | 0,
];
const shade = (c, k) => [
  Math.min(255, c[0] * k) | 0,
  Math.min(255, c[1] * k) | 0,
  Math.min(255, c[2] * k) | 0,
];

/** Sample a colour ramp at t in [0, 1]. */
function ramp(stops, t) {
  const x = clamp(t, 0, 1) * (stops.length - 1);
  const i = Math.min(stops.length - 2, Math.floor(x));
  return mix(stops[i], stops[i + 1], x - i);
}

export class KoiRenderer {
  constructor(canvas, options = {}) {
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('2D canvas unavailable');
    this.ctx = ctx;
    this.dpr = 1;
    this.cw = 8;
    this.ch = 12;
    this.cols = 0;
    this.rows = 0;
    this.palette = options.isLight ? LIGHT : DARK;
    this.styles = new Map();
    this.markingCache = new Map();
    this.fontFamily = 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';
    /** Cell budget for the whole grid; the shell can be large, so it is capped. */
    this.maxCells = options.maxCells ?? 26000;

    this.energy = new Float32Array(0);
    this.energyTmp = new Float32Array(0);
    this.cellGlyph = new Uint16Array(0);
    this.cellColor = new Uint32Array(0);
    this.cellAlpha = new Float32Array(0);
    this.cellTile = new Uint32Array(0);
    this.cellTileAlpha = new Float32Array(0);
    this.cellDim = new Float32Array(0);
    this.cellShadow = new Uint8Array(0);

    this.spine = new Float32Array(KOI_NODES * 2);
    this.arc = new Float32Array(KOI_NODES);
    this.arcTotal = 1;
    this.flareLeft = 1;
    this.flareRight = 1;
    // Scratch outputs of sample(), to avoid allocating per sample.
    this.hit = { flag: 0, across: 1, du: 1, da: 0 };
    this.hitS = 0;
    this.hitV = 0;
    this.hitDist = 0;
    this.hitTx = 1;
    this.hitTy = 0;
    this.hitSeg = 0;
  }

  setTheme(isLight) {
    this.palette = isLight ? LIGHT : DARK;
  }

  /** Wipe the canvas and stop drawing — used when the user asks for no transparency. */
  clear() {
    const { ctx } = this;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    this.cellGlyph.fill(0);
    this.cellTileAlpha.fill(0);
    this.cellShadow.fill(0);
    this.energy.fill(0);
  }

  resize(width, height, dpr) {
    this.dpr = dpr;
    // Near-square tiles, large enough to read each etched glyph. On a very large
    // shell the tile grows instead of the grid exploding: the pond stays cheap.
    let cw = clamp(Math.round(width / 125), 8, 12);
    let ch = cw + 2;
    const budget = this.maxCells;
    while (Math.ceil(width / cw) * Math.ceil(height / ch) > budget && cw < 26) {
      cw += 1;
      ch = cw + 2;
    }
    this.cw = cw;
    this.ch = ch;
    this.cols = Math.ceil(width / cw);
    this.rows = Math.ceil(height / ch);
    this.ctx.canvas.width = Math.round(width * dpr);
    this.ctx.canvas.height = Math.round(height * dpr);

    const n = this.cols * this.rows;
    this.energy = new Float32Array(n);
    this.energyTmp = new Float32Array(n);
    this.cellGlyph = new Uint16Array(n);
    this.cellColor = new Uint32Array(n);
    this.cellAlpha = new Float32Array(n);
    this.cellTile = new Uint32Array(n);
    this.cellTileAlpha = new Float32Array(n);
    this.cellDim = new Float32Array(n).fill(1);
    this.cellShadow = new Uint8Array(n);
  }

  /**
   * Fade koi under these canvas-space boxes, easing back in over a few cells
   * around them.
   *
   * `groups` is a list of `{ boxes, floor }`: each group says how visible a koi
   * stays at the *centre* of its boxes, from 1 (untouched) down to 0 (gone). The
   * site has one such group — its prose block, at 0.15 — because prose is the
   * only thing drawn over the water. A shell has two: the places where bare text
   * sits on the water (fade gently, as the site does) and the transcript, where
   * every message is text over water and a koi must be a whisper or the words
   * stop being readable.
   */
  setDimBoxes(groups) {
    const { cols, rows, cw, ch, cellDim } = this;
    cellDim.fill(1);
    const pad = cw * 4;
    for (const group of groups) for (const b of group.boxes) {
      const floor = group.floor;
      // A `restore` group raises the floor rather than lowering it: used where a
      // block paints its own tint, so the water beneath it does not also have to
      // be faded. Groups run in order, so a restore after the dim wins.
      const restore = group.mode === 'restore';
      const c0 = Math.max(0, Math.floor((b.left - pad) / cw));
      const c1 = Math.min(cols - 1, Math.floor((b.right + pad) / cw));
      const r0 = Math.max(0, Math.floor((b.top - pad) / ch));
      const r1 = Math.min(rows - 1, Math.floor((b.bottom + pad) / ch));
      for (let r = r0; r <= r1; r++) {
        for (let c = c0; c <= c1; c++) {
          const x = c * cw + cw / 2;
          const y = r * ch + ch / 2;
          const d = Math.hypot(Math.max(b.left - x, 0, x - b.right), Math.max(b.top - y, 0, y - b.bottom));
          const i = r * cols + c;
          const target = floor + (1 - floor) * smoothstep(0, pad, d);
          cellDim[i] = restore ? Math.max(cellDim[i], target) : Math.min(cellDim[i], target);
        }
      }
    }
  }

  render(world, dt) {
    const { ctx, dpr, cols } = this;
    if (cols === 0) return;

    this.cellGlyph.fill(0);
    this.cellTileAlpha.fill(0);
    this.cellShadow.fill(0);
    // Deeper koi first, so the ones near the surface glide over them.
    for (const k of [...world.koi].sort((a, b) => a.depth - b.depth)) this.rasterizeKoi(k, world.time);
    this.depositWake(world);
    this.diffuse(dt);

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.font = `600 ${Math.round(this.ch * 0.72)}px ${this.fontFamily}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    this.drawShadows();
    this.drawWake();
    this.drawRipples(world);
    this.drawPellets(world);
    this.drawCells();
    this.drawBites(world);
    ctx.globalAlpha = 1;
  }

  style(rgb) {
    let s = this.styles.get(rgb);
    if (!s) {
      s = `rgb(${rgb >>> 16},${(rgb >>> 8) & 255},${rgb & 255})`;
      this.styles.set(rgb, s);
    }
    return s;
  }

  glyphAt(i, glyph, rgb, alpha) {
    const { ctx, cw, ch, cols } = this;
    ctx.globalAlpha = alpha;
    ctx.fillStyle = this.style(packRgb(rgb));
    ctx.fillText(glyph, (i % cols) * cw + cw / 2, ((i / cols) | 0) * ch + ch / 2);
  }

  cellIndex(x, y) {
    const c = Math.floor(x / this.cw);
    const r = Math.floor(y / this.ch);
    if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) return -1;
    return r * this.cols + c;
  }

  // ── koi ─────────────────────────────────────────────────────────────

  /** Find the nearest point on the render spine, then classify it against the koi's outline. */
  sample(px, py, L, from = 0, to = KOI_NODES - 2) {
    const { spine, arc } = this;
    let best = Infinity;
    let bestS = 0;
    let bestSign = 1;
    let past = 0;
    let ahead = 0;
    let lateral = 0;
    for (let n = from; n <= to; n++) {
      const ax = spine[n * 2];
      const ay = spine[n * 2 + 1];
      const sx = spine[(n + 1) * 2] - ax;
      const sy = spine[(n + 1) * 2 + 1] - ay;
      const len2 = sx * sx + sy * sy || 1;
      const raw = ((px - ax) * sx + (py - ay) * sy) / len2;
      const u = clamp(raw, 0, 1);
      const d2 = (px - ax - sx * u) ** 2 + (py - ay - sy * u) ** 2;
      if (d2 < best) {
        const len = Math.sqrt(len2);
        best = d2;
        bestS = (arc[n] + u * len) / this.arcTotal;
        bestSign = sx * (py - ay) - sy * (px - ax) >= 0 ? 1 : -1;
        past = n === KOI_NODES - 2 ? Math.max(0, raw - 1) * len : 0;
        ahead = n === 0 ? Math.max(0, -raw) * len : 0;
        lateral = Math.abs(sx * (py - ay) - sy * (px - ax)) / len;
        this.hitTx = sx / len;
        this.hitTy = sy / len;
        this.hitSeg = n;
      }
    }

    const a = Math.sqrt(best);
    this.hitDist = a;
    this.hitS = bestS;
    this.hitV = a * bestSign;
    return classify(
      bestS,
      a / L,
      past / L,
      bestSign > 0 ? this.flareLeft : this.flareRight,
      this.hit,
      ahead / L,
      lateral / L
    );
  }

  /**
   * Skin kind for a body point, from the koi's own markings pinned to body
   * coordinates. Returns a *kind* rather than a colour: the accent differs per
   * fish, so the caller resolves it against that fish's ramp.
   */
  skin(k, s, v, across) {
    const vn = v / k.length;
    // Belly edges and the tail stalk stay pale on every variety, which frames
    // the markings.
    if (across > 0.9 || s > 0.74) return 'white';
    // Ragged edges, so patches read as painted markings rather than ellipses.
    const wobble = (valueNoise(s * 14 + k.id, vn * 30, k.id + 3) - 0.5) * 0.6;
    const markings = this.markings(k);
    for (const m of markings.black) if (inPatch(m, s, vn, wobble)) return 'black';
    for (const m of markings.white) if (inPatch(m, s, vn, wobble)) return 'white';
    for (const m of markings.accent) if (inPatch(m, s, vn, wobble)) return 'accent';
    return markings.base;
  }

  /** Markings and ramp for one fish, cached by identity so a re-seed refreshes them. */
  markings(k) {
    const key = k.id + ':' + k.variety + ':' + k.accent;
    let m = this.markingCache.get(key);
    if (!m) {
      m = koiMarkings(k);
      this.markingCache.set(key, m);
    }
    return m;
  }

  /** The six-stop pigment ramp for one fish. */
  ramp(k) {
    const key = 'ramp:' + k.id + ':' + k.accent;
    let r = this.markingCache.get(key);
    if (!r) {
      r = rampFor(k.accent, this.palette);
      this.markingCache.set(key, r);
    }
    return r;
  }

  rasterizeKoi(k, t) {
    const { spine, arc, cw, ch, cols, rows, cellGlyph, cellColor, cellAlpha, cellTile, cellTileAlpha, palette } = this;
    const L = k.length;
    const nodes = k.nodes;
    // The body only undulates while the tail is beating; coasting koi hold
    // almost straight.
    const swim = 0.2 + 1.1 * k.beat;

    // Travelling body wave that grows toward the tail.
    for (let n = 0; n < KOI_NODES; n++) {
      const s = n / (KOI_NODES - 1);
      const a = Math.max(0, n - 1);
      const b = Math.min(KOI_NODES - 1, n + 1);
      let tx = nodes[a * 2] - nodes[b * 2];
      let ty = nodes[a * 2 + 1] - nodes[b * 2 + 1];
      const tl = Math.hypot(tx, ty) || 1;
      tx /= tl;
      ty /= tl;
      const amp = L * 0.04 * (0.05 + 0.95 * Math.pow(s, 2.2)) * swim;
      const off = amp * Math.sin(k.phase - s * 4.6);
      spine[n * 2] = nodes[n * 2] - ty * off;
      spine[n * 2 + 1] = nodes[n * 2 + 1] + tx * off;
    }
    arc[0] = 0;
    for (let n = 1; n < KOI_NODES; n++) {
      arc[n] =
        arc[n - 1] + Math.hypot(spine[n * 2] - spine[(n - 1) * 2], spine[n * 2 + 1] - spine[(n - 1) * 2 + 1]);
    }
    this.arcTotal = arc[KOI_NODES - 1] || 1;
    // Pectorals tuck in during a burst, scull in turn while coasting, and the
    // inner one spreads to brake on a turn.
    const spread = 1 - 0.25 * k.beat;
    const scull = 0.18 * (1 - k.beat) * Math.sin(k.finPhase);
    const bank = clamp(k.turn * 0.6, -0.35, 0.35);
    this.flareLeft = spread + scull - bank;
    this.flareRight = spread - scull + bank;

    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (let n = 0; n < KOI_NODES; n++) {
      minX = Math.min(minX, spine[n * 2]);
      maxX = Math.max(maxX, spine[n * 2]);
      minY = Math.min(minY, spine[n * 2 + 1]);
      maxY = Math.max(maxY, spine[n * 2 + 1]);
    }
    const reach = L * 0.26;
    const c0 = Math.max(0, Math.floor((minX - reach) / cw));
    const c1 = Math.min(cols - 1, Math.floor((maxX + reach) / cw));
    const r0 = Math.max(0, Math.floor((minY - reach) / ch));
    const r1 = Math.min(rows - 1, Math.floor((maxY + reach) / ch));
    if (c0 > c1 || r0 > r1) return;

    const diag = Math.hypot(cw, ch);
    // Near the surface a koi is brighter and its shadow falls farther away on
    // the floor.
    const shadowDc = Math.round((L * 0.07 * k.depth) / cw) + 1;
    const shadowDr = Math.round((L * 0.05 * k.depth) / ch) + 1;
    const dim = palette.alpha * (palette.depthFloor + (1 - palette.depthFloor) * k.depth);
    const [tile0, tile1] = palette.tile;
    const hit = this.hit;

    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const x = c * cw;
        const y = r * ch;
        const centerHit = this.sample(x + cw / 2, y + ch / 2, L);
        // Nothing reaches far from the spine at the waist, where the fins end.
        if (!centerHit && this.hitDist > L * (this.hitS > 0.4 && this.hitS < 0.62 ? 0.15 : 0.25) + diag) {
          // Distance to the spine changes by at most a cell per cell, so skip
          // cells that can't reach it.
          c += Math.max(0, Math.floor((this.hitDist - L * 0.25 - diag) / cw));
          continue;
        }
        // Sub-samples sit within a cell of the centre, so only the neighbouring
        // segments can be nearest.
        const from = Math.max(0, this.hitSeg - 2);
        const to = Math.min(KOI_NODES - 2, this.hitSeg + 2);
        let { flag, across } = hit;
        let s = this.hitS;
        let v = this.hitV;
        let tx = this.hitTx;
        let ty = this.hitTy;

        let hits = centerHit ? 1 : 0;
        // Points from the cell centre toward the covered side, i.e. across the
        // outline into the koi.
        let gx = 0;
        let gy = 0;
        // Cells well inside the body can't have a sub-sample outside it, so skip
        // straight to full coverage.
        const deepInside =
          centerHit &&
          flag !== FLAG_FIN &&
          flag !== FLAG_BARBEL &&
          s > 0.04 &&
          s < 0.72 &&
          bodyHalfWidth(s) * L - this.hitDist > diag * 0.35;
        if (deepInside) hits = 5;
        for (let q = 0; !deepInside && q < SUBSAMPLES.length; q += 2) {
          if (!this.sample(x + SUBSAMPLES[q] * cw, y + SUBSAMPLES[q + 1] * ch, L, from, to)) continue;
          gx += (SUBSAMPLES[q] - 0.5) * cw;
          gy += (SUBSAMPLES[q + 1] - 0.5) * ch;
          if (hits === 0) {
            ({ flag, across } = hit);
            s = this.hitS;
            v = this.hitV;
            tx = this.hitTx;
            ty = this.hitTy;
          }
          hits++;
        }
        if (hits === 0) continue;
        this.hitTx = tx;
        this.hitTy = ty;
        const coverage = hits / 5;
        const side = v >= 0 ? 1 : -1;

        const i = r * cols + c;
        // Body-anchored key so each glyph rides along with the skin.
        const key = (hash3(Math.round(s * 90), Math.round(v / (cw * 0.8)), k.id) * 4294967295) >>> 0;
        const solid = centerHit && coverage >= 0.6;

        let glyph = ' ';
        let rgb = palette.fin;
        let alpha = dim;
        let tile = null;
        let tileAlpha = 0;
        if (flag === FLAG_BARBEL) {
          // Drawn along the whisker: forward from the mouth and angled out to its
          // side.
          glyph = lineGlyph(-tx - side * ty * 0.7, -ty + side * tx * 0.7);
          rgb = shade(mix(palette.bg, palette.fin, 0.9), palette.ink + 0.3);
        } else if (flag === FLAG_EYE && solid) {
          tile = mix(palette.bg, palette.eye, 0.85);
          tileAlpha = dim;
          glyph = 'o';
          rgb = mix(palette.bg, palette.white, 0.9);
        } else if (flag === FLAG_FIN) {
          // Fins are a pale veil of tiles flecked with dots, so they never
          // compete with the body.
          tile = mix(palette.bg, palette.fin, 0.55);
          tileAlpha = dim * 0.45 * coverage;
          if (key % 2 === 0) {
            glyph = '.';
            alpha *= 0.6 * coverage;
          }
        } else {
          // Each skin cell is a tile washed in the skin colour, shaded like a
          // rounded back lit from the top-left, with a dense glyph etched on top.
          // Edge cells get a paler, empty tile.
          const skin = this.skin(k, s, v, across);
          const facing = side * (0.6 * ty - 0.8 * tx) * across;
          const lum = clamp(0.22 + 0.5 * Math.sqrt(1 - across * across) + 0.18 * facing, 0, 1);
          if (skin === 'accent') {
            // Pigment patches run the full ramp: shadowed at the flanks, lit
            // across the back. Each koi leans a little within its own hue, and a
            // slow body-pinned noise varies it like real pigment.
            const lean = (hash3(k.id, 5, 17) - 0.5) * 0.3;
            const grain = (valueNoise(s * 9 + k.id, (v / L) * 18, k.id + 21) - 0.5) * 0.25;
            // A band of shine travels down the body, like light sliding over wet
            // scales.
            const sheen = Math.max(0, Math.sin(s * 11 - t * 1.8 + k.id) - 0.7) / 0.3;
            tile = ramp(this.ramp(k), 0.15 + 0.8 * lum + lean + grain + sheen * 0.35);
          } else {
            // `?? palette.white` is deliberate: a variety whose tone is missing
            // from a palette must draw as a pale fish, not throw inside the
            // frame and stop the whole pond.
            const tone =
              (skin === 'black'
                ? palette.black
                : skin === 'slate'
                  ? palette.slate
                  : palette.white) ?? palette.white;
            tile = mix(palette.bg, tone, tile0 + (tile1 - tile0) * lum);
          }
          if (hits === 5) {
            const sc = c + shadowDc;
            const sr = r + shadowDr;
            if (sc < cols && sr < rows) this.cellShadow[sr * cols + sc] = 1;
            tileAlpha = dim;
            if (s < 0.035 && across < 0.6 && k.gulp > 0.5) {
              glyph = 'o';
              rgb = palette.eye;
            } else {
              const jitter = (key >>> 4) % 3;
              glyph = TILE_GLYPHS[clamp(Math.round((1 - lum) * 4) + jitter, 0, TILE_GLYPHS.length - 1)];
              rgb = shade(tile, palette.ink);
              // White skin is etched lightly so the red and black patches carry
              // the pattern.
              if (skin === 'white') alpha *= 0.6;
              // Scales glint on a staggered clock.
              const tick = Math.floor(t * 1.4 + (key % 997) / 97);
              if (hash3(key, tick, 7) < 0.03) tile = mix(tile, palette.bg, 0.45);
            }
          } else {
            tileAlpha = dim * coverage * 0.55;
            if (Math.hypot(gx, gy) > cw * 0.2 && key % 3 === 0) {
              glyph = '.';
              rgb = shade(tile, palette.ink);
            }
          }
        }
        if (glyph === ' ' && tileAlpha === 0) continue;
        cellTile[i] = tile ? packRgb(tile) : 0;
        cellTileAlpha[i] = tileAlpha;
        cellGlyph[i] = glyph.charCodeAt(0);
        cellColor[i] = packRgb(rgb);
        cellAlpha[i] = alpha;
      }
    }
  }

  drawCells() {
    const { ctx, cw, ch, cols, cellGlyph, cellColor, cellAlpha, cellTile, cellTileAlpha, cellDim } = this;
    for (let i = 0; i < cellGlyph.length; i++) {
      const code = cellGlyph[i];
      if (!code) continue;
      const x = (i % cols) * cw;
      const y = ((i / cols) | 0) * ch;
      if (cellTileAlpha[i] > 0) {
        ctx.globalAlpha = cellTileAlpha[i] * cellDim[i];
        ctx.fillStyle = this.style(cellTile[i]);
        ctx.fillRect(x + 1, y + 1, cw - 1, ch - 1);
      }
      if (code === 32) continue;
      ctx.globalAlpha = cellAlpha[i] * cellDim[i];
      ctx.fillStyle = this.style(cellColor[i]);
      ctx.fillText(String.fromCharCode(code), x + cw / 2, y + ch / 2 + 1);
    }
  }

  // ── water ───────────────────────────────────────────────────────────

  depositWake(world) {
    const { energy } = this;
    for (const k of world.koi) {
      for (let n = KOI_NODES - 4; n < KOI_NODES; n++) {
        const i = this.cellIndex(k.nodes[n * 2], k.nodes[n * 2 + 1]);
        if (i >= 0) energy[i] = Math.min(1.5, energy[i] + 0.035 + k.speed * 0.0012);
      }
    }
    if (world.pointer.active) {
      const i = this.cellIndex(world.pointer.x, world.pointer.y);
      if (i >= 0) energy[i] = Math.min(1.5, energy[i] + 0.12);
    }
  }

  /** Blur and decay so wakes spread like ripples and fade. */
  diffuse(dt) {
    const { cols, rows, energy, energyTmp: tmp } = this;
    const decay = Math.exp(-dt * 1.1);
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const i = r * cols + c;
        const l = c > 0 ? energy[i - 1] : energy[i];
        const rt = c < cols - 1 ? energy[i + 1] : energy[i];
        const u = r > 0 ? energy[i - cols] : energy[i];
        const d = r < rows - 1 ? energy[i + cols] : energy[i];
        tmp[i] = (energy[i] * 4 + l + rt + u + d) * 0.125 * decay;
      }
    }
    this.energy = tmp;
    this.energyTmp = energy;
  }

  drawShadows() {
    const { cellShadow, cellGlyph, cellDim, palette } = this;
    for (let i = 0; i < cellShadow.length; i++) {
      if (!cellShadow[i] || cellGlyph[i]) continue;
      this.glyphAt(i, ':', palette.shadow, palette.shadowAlpha * cellDim[i]);
    }
  }

  drawWake() {
    const { energy, cellGlyph, cellShadow, palette } = this;
    for (let i = 0; i < energy.length; i++) {
      const e = energy[i];
      if (e < 0.22 || cellGlyph[i] || cellShadow[i]) continue;
      this.glyphAt(i, e > 0.5 ? '-' : '.', palette.water, Math.min(1, (e - 0.22) * 1.4) * 0.35);
    }
  }

  /** Expanding rings drawn as ASCII circles: the glyph follows the ring's tangent. */
  drawRipples(world) {
    const { cw, ch, cols, rows, cellGlyph, palette } = this;
    for (const rp of world.ripples) {
      const age = world.time - rp.born;
      const life = rippleLife(rp);
      const fade = Math.pow(1 - age / life, 1.5) * rp.strength;
      for (let ring = 0; ring < 2; ring++) {
        const radius = Math.max(0, age - ring * 0.45) * RIPPLE_SPEED * (0.7 + 0.5 * rp.strength);
        if (radius < 2) continue;
        const band = cw * 0.6;
        const c0 = Math.max(0, Math.floor((rp.x - radius - cw) / cw));
        const c1 = Math.min(cols - 1, Math.floor((rp.x + radius + cw) / cw));
        const r0 = Math.max(0, Math.floor((rp.y - radius - ch) / ch));
        const r1 = Math.min(rows - 1, Math.floor((rp.y + radius + ch) / ch));
        const alpha = fade * (ring === 0 ? 0.55 : 0.3);
        for (let r = r0; r <= r1; r++) {
          for (let c = c0; c <= c1; c++) {
            const i = r * cols + c;
            if (cellGlyph[i]) continue;
            const dx = c * cw + cw / 2 - rp.x;
            const dy = r * ch + ch / 2 - rp.y;
            const d = Math.hypot(dx, dy);
            if (Math.abs(d - radius) > band) continue;
            const glyph = ring === 1 ? '.' : lineGlyph(-dy, dx);
            this.glyphAt(i, glyph, palette.water, alpha);
          }
        }
      }
    }
  }

  /** A bite flashes * over the koi's mouth, settling to + then a dot as the splash takes over. */
  drawBites(world) {
    const { palette } = this;
    for (const b of world.bites) {
      const i = this.cellIndex(b.x, b.y);
      if (i < 0) continue;
      const t = (world.time - b.born) / BITE_LIFE;
      const glyph = t < 0.35 ? '*' : t < 0.7 ? '+' : '.';
      this.glyphAt(i, glyph, palette.pellet, Math.min(1, palette.alpha * 1.6) * (1 - t * t));
    }
  }

  /** Pellets fall in (' then .), land as o with a splash, bob while floating, then dim to . as they sink. */
  drawPellets(world) {
    const { cellGlyph, palette, ch } = this;
    for (const p of world.pellets) {
      const age = world.time - p.born;
      if (!p.landed) {
        const fall = age / p.landAt;
        // Drawn a little above where it will land, closing in as it drops.
        const i = this.cellIndex(p.x, p.y - (1 - fall) * ch * 1.5);
        if (i < 0 || cellGlyph[i]) continue;
        this.glyphAt(i, fall < 0.5 ? "'" : '.', palette.pellet, palette.alpha * (0.5 + 0.4 * fall));
        continue;
      }
      const i = this.cellIndex(p.x, p.y);
      if (i < 0 || cellGlyph[i]) continue;
      const sink = smoothstep(PELLET_SINK, PELLET_LIFE, age);
      const bob = 0.8 + 0.2 * Math.sin(age * 3 + p.x);
      this.glyphAt(i, sink > 0.55 ? '.' : 'o', palette.pellet, palette.alpha * bob * (1 - 0.85 * sink));
    }
  }
}

