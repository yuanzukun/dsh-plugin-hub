/**
 * apply.js — the Client plugin body.
 *
 * Three effects, in the order the site layers itself: the pond first (so its
 * canvas exists before anything is measured), then the token layer, then the
 * stylesheet.
 *
 * `ctx.effect` runs its callback synchronously and takes the returned disposer,
 * so a failure inside one of them is caught here and reported with a real stack
 * instead of taking the whole web boot down as "entry failed". The theme is
 * allowed to be the only thing that works: if the canvas cannot be created, the
 * paper palette still applies.
 */

/** Layer identity for the token override; also the plugin's display id. */
const ID = '@cngtn/dsh-cngtn-pond';

/** Required Client services: the theme registry owns the token layer. */
const inject = ['theme'];

/**
 * Pond settings.
 *
 * Three sources, in increasing priority:
 *
 *  1. the defaults below;
 *  2. the bundle's own \`config\` in \`cordis.patch.yml\`, so a profile can ship a
 *     house style;
 *  3. what the user picked in the Pond panel, kept in \`localStorage\` so it
 *     survives a restart without any host write.
 *
 * The values are validated here rather than trusted: a config file is just
 * text, and an out-of-range count would either empty the pond or flood it.
 */
const STORAGE_KEY = 'cngtn-pond:settings';
const DEFAULTS = { fish: null, young: true, palette: 'mixed' };

function readStored() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw === null ? {} : JSON.parse(raw);
    return parsed !== null && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function normalizeSettings(raw) {
  const source = raw !== null && typeof raw === 'object' ? raw : {};
  const fish = Number.isFinite(source.fish) ? Math.min(12, Math.max(3, Math.round(source.fish))) : null;
  const palette = PALETTE_PRESETS.includes(source.palette) ? source.palette : DEFAULTS.palette;
  const young = typeof source.young === 'boolean' ? source.young : DEFAULTS.young;
  return { fish, young, palette };
}

function persistSettings(next) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // A blocked storage API must not stop the pond from changing.
  }
}

/** The live engine, so the panel and the console API can retune it in place. */
let activeEngine = null;

/**
 * The Host-backed config scope for this bundle, when one is reachable. It is the
 * source of truth: the plugin page's form writes here, and the pond follows it.
 * `localStorage` remains a cache and the fallback when no Host scope exists.
 */
let hostScope = null;

/** The settings the engine is currently drawing, so folds can skip no-ops. */
let appliedSettings = null;

/** What the settings wiring managed to reach; surfaced by `cngtnPond.diag()`. */
const diag = {
  slots: false,
  configForms: false,
  primitives: false,
  formModel: false,
  bundleConfigRegistered: false,
  injectCalled: false,
  hostScope: false,
  injectCallbackRan: false,
  settingsButtonRegistered: false,
  notes: [],
};

/**
 * Apply a settings patch.
 *
 * Two rules, and both were learned the hard way:
 *
 * 1. **The engine follows the user immediately.** A slider drag must not wait
 *    for a Host round-trip, and the panel must never show a value the pond is
 *    not drawing.
 * 2. **The Host write is debounced and latest-wins.** Firing one write per
 *    keystroke queued revisions that collided, and the fold from a superseded
 *    write could land last — a rapid palette cycle used to end on whichever
 *    value happened to win the race.
 *
 * The fold still applies an incoming value, but only when it differs from what
 * the engine already draws, so a debounced write echoing back is a no-op instead
 * of a re-seed.
 */
let hostWriteTimer = 0;

function scheduleHostWrite() {
  if (hostScope === null) return;
  if (hostWriteTimer !== 0) clearTimeout(hostWriteTimer);
  hostWriteTimer = setTimeout(() => {
    hostWriteTimer = 0;
    if (hostScope === null) return;
    const latest = normalizeSettings(readStored());
    try {
      const snapshot = hostScope.getSnapshot();
      if (!snapshot || !snapshot.writable) return;
      // Only the fields that actually differ, so an unchanged document is not
      // rewritten on every interaction.
      for (const field of ['fish', 'young', 'palette']) {
        const current = snapshot.value ? snapshot.value[field] : undefined;
        if (current !== latest[field]) hostScope.set(field, latest[field]);
      }
    } catch (error) {
      console.warn('[cngtn-pond] host write failed:', error && error.message);
    }
  }, 250);
}

function applySettings(patch) {
  const next = normalizeSettings({ ...readStored(), ...patch });
  persistSettings(next);
  applyToEngine(next);
  scheduleHostWrite();
  refreshPanel();
  return next;
}

/** Push a normalized settings object into the live engine. */
function applyToEngine(next) {
  // `setOptions` re-seeds the school, so an identical value must not be applied
  // twice: a fold that echoes what we just wrote would otherwise restart the
  // pond on every keystroke.
  if (
    appliedSettings !== null &&
    appliedSettings.fish === next.fish &&
    appliedSettings.young === next.young &&
    appliedSettings.palette === next.palette
  ) {
    return;
  }
  appliedSettings = { fish: next.fish, young: next.young, palette: next.palette };
  if (activeEngine === null) return;
  try {
    activeEngine.setOptions(next);
  } catch (error) {
    console.error('[cngtn-pond] settings failed:', error && error.message);
  }
}

/**
 * Follow the Host config scope.
 *
 * The plugin page's form saves through the Host, which is what the config
 * document is for; without this subscription the save would be recorded and the
 * pond would keep drawing the old school until a restart. Every ready snapshot
 * is folded into the cache and applied, so the form, the panel and the console
 * API all describe the same pond.
 */
function connectHostSettings(ctx) {
  let configForms;
  try {
    configForms = typeof ctx.get === 'function' ? ctx.get('configForms') : undefined;
  } catch {
    return;
  }
  if (!configForms || typeof configForms.get !== 'function') return;

  try {
    const scope = configForms.get('cngtn-pond');
    hostScope = scope;
    diag.hostScope = true;

    const fold = () => {
      try {
        const snapshot = scope.getSnapshot();
        if (!snapshot || snapshot.status !== 'ready' || !snapshot.value) return;
        const next = normalizeSettings({ ...readStored(), ...snapshot.value });
        persistSettings(next);
        applyToEngine(next);
        refreshPanel();
      } catch (error) {
        diag.notes.push('fold: ' + (error && error.message));
      }
    };

    ctx.effect(() => scope.subscribe(fold), 'cngtn-pond: host config');
    fold();
  } catch (error) {
    diag.notes.push('host scope: ' + (error && error.message));
    console.warn('[cngtn-pond] host config unavailable:', error && error.message);
  }
}

/**
 * Mount the pond behind the shell.
 *
 * The canvas is the body's first child and carries `z-index: -1`. That places it
 * above the body's own background (which is the paper) and below every in-flow
 * descendant, so the shell's panels paint over the water and only the regions
 * the stylesheet made transparent let it show. Appending it last would put it on
 * top of the sidebar instead — a positioned element at `z-index: 0` beats static
 * content.
 */
function mountPond(settings) {
  try {
    if (typeof document === 'undefined' || document.body === null) return () => {};

    // One canvas per document, even across a hot reload of this plugin.
    const stale = document.querySelector('#cngtn-pond-canvas');
    if (stale !== null) stale.remove();

    const canvas = document.createElement('canvas');
    canvas.id = 'cngtn-pond-canvas';
    canvas.setAttribute('aria-hidden', 'true');
    // The canvas never takes input, so a click anywhere still reaches the
    // control under it.
    canvas.style.pointerEvents = 'none';
    document.body.insertBefore(canvas, document.body.firstChild);

    let engine = null;
    try {
      engine = new PondEngine(canvas, {
        // The shell has less open water than a full-screen page: fewer fish, and
        // a cap on the grid so a very large window stays cheap.
        budget: 0.7,
        maxCells: 26000,
        fish: settings.fish,
        young: settings.young,
        palette: settings.palette,
      });
      activeEngine = engine;
    } catch (error) {
      canvas.remove();
      console.error('[cngtn-pond] engine unavailable:', error && error.message);
      return () => {};
    }

    // The shell swaps the palette by toggling an attribute on the body, not by
    // remounting anything, so the pond follows it with an observer.
    const paletteObserver = new MutationObserver(() => engine.setTheme(engine.readIsLight()));
    paletteObserver.observe(document.body, { attributes: true, attributeFilter: ['data-ds-dark-theme'] });

    return () => {
      paletteObserver.disconnect();
      engine.destroy();
      canvas.remove();
      if (activeEngine === engine) activeEngine = null;
    };
  } catch (error) {
    console.error('[cngtn-pond] mount failed:', error && (error.stack || error.message));
    return () => {};
  }
}

/** Insert the cngtn stylesheet once; the returned disposer removes it. */
function injectStyles() {
  try {
    if (typeof document === 'undefined' || document.head === null) return () => {};
    const tagId = ID + '/styles';
    const existing = document.querySelector('style[data-plugin-css="' + tagId + '"]');
    if (existing !== null) return () => existing.remove();
    const tag = document.createElement('style');
    tag.dataset.plugin = ID;
    tag.dataset.pluginCss = tagId;
    tag.textContent = buildStyles();
    document.head.appendChild(tag);
    return () => tag.remove();
  } catch (error) {
    console.error('[cngtn-pond] styles failed:', error && (error.stack || error.message));
    return () => {};
  }
}

/**
 * The Pond panel: three controls, no host form API.
 *
 * DSH's bundle-config slot hands a plugin a host-owned form whose shape is not
 * part of the published contract, so this panel is plain DOM instead: it renders
 * with the theme's own tokens, works whether or not the slot exists, and cannot
 * break the settings page if it fails.
 */
let panel = null;

function panelStyles() {
  return {
    position: 'fixed',
    top: '96px',
    right: '24px',
    width: '268px',
    zIndex: '60',
    padding: '14px 16px 12px',
    borderRadius: '12px',
    border: '0.5px solid var(--dsw-alias-border-l2)',
    backgroundColor: 'color-mix(in srgb, var(--dsw-alias-bg-overlay, #fbfaf7) 86%, transparent)',
    backdropFilter: 'blur(20px) saturate(150%)',
    WebkitBackdropFilter: 'blur(20px) saturate(150%)',
    boxShadow: 'var(--dsw-shadow-lv3)',
    color: 'var(--dsw-alias-label-primary)',
    font: 'var(--dsw-font-xs-13, 13px/20px var(--dsw-font-family))',
  };
}

function row() {
  const el = document.createElement('div');
  el.style.cssText = 'display:flex;align-items:center;gap:10px;margin-top:10px';
  return el;
}

function label(text) {
  const el = document.createElement('span');
  el.textContent = text;
  el.style.cssText = 'flex:0 0 58px;color:var(--dsw-alias-label-secondary)';
  return el;
}

/** The count the pond is actually drawing, so the slider never lies. */
function liveFishCount(fallback) {
  if (activeEngine !== null) {
    try {
      return activeEngine.world.koi.length;
    } catch {
      // fall through to the stored value
    }
  }
  return fallback;
}

function openPanel() {
  if (panel !== null && panel.isConnected) {
    panel.remove();
    panel = null;
    return;
  }
  if (typeof document === 'undefined' || document.body === null) return;

  const current = normalizeSettings(readStored());
  const card = document.createElement('div');
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-label', 'Pond settings');
  Object.assign(card.style, panelStyles());

  const head = row();
  head.style.marginTop = '0';
  const title = document.createElement('strong');
  title.textContent = 'Pond';
  title.style.cssText = 'flex:1;font-weight:600';
  const close = document.createElement('button');
  close.type = 'button';
  close.textContent = '×';
  close.setAttribute('aria-label', 'Close');
  close.style.cssText =
    'border:0;background:transparent;color:var(--dsw-alias-label-tertiary);font-size:16px;line-height:1;cursor:pointer;padding:2px 4px';
  close.addEventListener('click', () => openPanel());
  head.append(title, close);

  // Fish count.
  const fishRow = row();
  const fishLabel = label('Fish');
  const fish = document.createElement('input');
  fish.type = 'range';
  fish.min = '3';
  fish.max = '12';
  fish.step = '1';
  fish.value = String(current.fish ?? liveFishCount(5));
  fish.style.cssText = 'flex:1;accent-color:var(--dsw-alias-brand-primary)';
  const fishValue = document.createElement('span');
  fishValue.textContent = fish.value;
  fishValue.style.cssText = 'flex:0 0 18px;text-align:right;font-variant-numeric:tabular-nums';
  fish.addEventListener('input', () => {
    fishValue.textContent = fish.value;
    applySettings({ fish: Number(fish.value) });
  });
  fishRow.append(fishLabel, fish, fishValue);

  // Palette.
  const paletteRow = row();
  const paletteLabel = label('Colour');
  const palette = document.createElement('select');
  palette.style.cssText =
    'flex:1;min-width:0;padding:3px 6px;border-radius:6px;border:0.5px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:inherit;font:inherit';
  for (const [value, text] of [
    ['mixed', 'Mixed'],
    ['warm', 'Warm (red, gold)'],
    ['cool', 'Cool (blue, silver)'],
    ['mono', 'Ink only'],
  ]) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = text;
    palette.append(option);
  }
  palette.value = current.palette;
  palette.addEventListener('change', () => applySettings({ palette: palette.value }));
  paletteRow.append(paletteLabel, palette);

  // Young koi.
  const youngRow = row();
  const youngLabel = document.createElement('label');
  youngLabel.style.cssText = 'display:flex;align-items:center;gap:8px;color:var(--dsw-alias-label-secondary);cursor:pointer';
  const young = document.createElement('input');
  young.type = 'checkbox';
  young.checked = current.young;
  young.style.accentColor = 'var(--dsw-alias-brand-primary)';
  young.addEventListener('change', () => applySettings({ young: young.checked }));
  youngLabel.append(young, document.createTextNode('Two young koi'));
  youngRow.append(youngLabel);

  card.append(head, fishRow, paletteRow, youngRow);
  document.body.append(card);
  panel = card;
}

/** Re-read the stored values into an open panel, after a console-API change. */
function refreshPanel() {
  if (panel === null || !panel.isConnected) return;
  const current = normalizeSettings(readStored());
  const [fish, palette, young] = panel.querySelectorAll('input[type="range"], select, input[type="checkbox"]');
  if (fish) {
    fish.value = String(current.fish ?? liveFishCount(Number(fish.value)));
    const value = fish.nextElementSibling;
    if (value) value.textContent = fish.value;
  }
  if (palette) palette.value = current.palette;
  if (young) young.checked = current.young;
}

/** A console and script handle, so the pond can be retuned without the panel. */
function exposeApi() {
  if (typeof window === 'undefined') return;
  window.cngtnPond = {
    get: () => (activeEngine !== null ? activeEngine.getOptions() : normalizeSettings(readStored())),
    set: (patch) => applySettings(patch ?? {}),
    open: () => openPanel(),
    reset: () => applySettings(DEFAULTS),
    palettes: PALETTE_PRESETS,
    varieties: VARIETIES,
    /** What the settings wiring reached, for support and for the tests. */
    diag: () => ({ ...diag, notes: [...diag.notes] }),
    /** The live school, for checking what the pond actually drew. */
    list: () =>
      activeEngine === null
        ? []
        : activeEngine.world.koi.map((k) => ({ id: k.id, variety: k.variety, accent: k.accent })),
  };
}

/**
 * The bundle's own settings page.
 *
 * The Plugins page dispatches \`plugins.bundle.config\` with the bundle's package
 * name as the key, and renders whatever is registered there between the bundle's
 * description and its rows. Registering is what makes the pond settings appear
 * on the marketplace/plugins page rather than only in a floating panel.
 *
 * The form is the shell's own \`SettingsFormModel\`, driven by the Host-backed
 * config scope (\`configForms.get('cngtn-pond')\`), so Save, Discard, the dirty
 * flag and the write path behave like the shipped bundle forms.
 *
 * Services are reached through \`ctx.get\`, not \`ctx.inject\`: a dynamic client
 * package's ctx facade exposes optional lookup by name, while \`inject\` is a
 * framework verb it deliberately withholds. Everything is optional — if either
 * service is missing, the theme keeps working and the floating Pond panel plus
 * the console API remain.
 */
function registerBundleConfig(ctx) {
  let slots;
  let configForms;
  try {
    slots = typeof ctx.get === 'function' ? ctx.get('slots') : undefined;
    configForms = typeof ctx.get === 'function' ? ctx.get('configForms') : undefined;
  } catch (error) {
    console.warn('[cngtn-pond] settings services unavailable:', error && error.message);
    return;
  }
  diag.slots = !!slots && typeof slots.register === 'function';
  diag.configForms = !!configForms && typeof configForms.get === 'function';
  if (!diag.slots) {
    diag.notes.push('no slots service');
    console.warn('[cngtn-pond] no slots service; pond settings stay in the floating panel');
    return;
  }
  if (!diag.configForms) {
    diag.notes.push('no configForms service');
    console.warn('[cngtn-pond] no configForms service; pond settings stay in the floating panel');
    return;
  }

  let React;
  let primitives;
  try {
    React = require('react');
    primitives = require('@deepseek-ai/dsh-client-ui-primitives');
  } catch (error) {
    diag.notes.push('primitives: ' + (error && error.message));
    console.warn('[cngtn-pond] settings form unavailable:', error && error.message);
    return;
  }
  diag.primitives = true;
  const { SettingsForm, SettingsFormModel, SettingsValueField, settingsNumberField, settingsTextField } = primitives;
  if (!SettingsForm || !SettingsFormModel || !SettingsValueField || !settingsNumberField || !settingsTextField) {
    diag.notes.push('settings primitives incomplete');
    console.warn('[cngtn-pond] settings primitives missing; using the floating panel only');
    return;
  }

  try {
    const scope = configForms.get('cngtn-pond');
    const model = new SettingsFormModel(scope, [
      {
        ...settingsNumberField('fish'),
        parse: (text) => {
          const value = Number(text.trim());
          return Number.isInteger(value) && value >= 3 && value <= 12
            ? { kind: 'set', value }
            : undefined;
        },
      },
      {
        ...settingsTextField('palette'),
        parse: (text) => {
          const value = text.trim();
          return PALETTE_PRESETS.includes(value) ? { kind: 'set', value } : undefined;
        },
      },
    ]);

    // The bound snapshot carries the shell flags *and* one entry per field, which
    // is exactly what \`SettingsForm\` and \`SettingsValueField\` read.
    const state = model.bind(() => ({
      ...model.shell(),
      fish: model.field('fish'),
      palette: model.field('palette'),
    }));

    diag.formModel = true;
    ctx.effect(() => () => model.dispose(), 'cngtn-pond: config form');

    const LABELS = {
      title: 'Pond',
      description: 'How many koi swim behind the shell, and which colours they carry.',
      save: 'Save',
      saving: 'Saving…',
      saveFailed: 'Could not save. Try again.',
      unavailable: 'Settings are unavailable right now.',
      readOnly: 'This profile is read-only.',
      discard: 'Discard',
      reset: 'Reset',
      overridden: 'Overridden',
    };

    function PondConfig(props) {
      const view = props && props.view;
      const snapshot = props.usePondForm((value) => value);

      if (view === 'summary') {
        return React.createElement(
          'span',
          null,
          (snapshot.fish && snapshot.fish.text ? snapshot.fish.text : '—') +
            ' fish · ' +
            (snapshot.palette && snapshot.palette.text ? snapshot.palette.text : 'mixed')
        );
      }

      const disabled = !snapshot.writable || snapshot.saving;

      return React.createElement(
        SettingsForm,
        {
          labels: LABELS,
          state: snapshot,
          onSave: props.save,
          onDiscard: props.discard,
        },
        React.createElement(SettingsValueField, {
          id: 'cngtn-pond-fish',
          label: 'Fish (3–12)',
          text: snapshot.fish ? snapshot.fish.text : '',
          numeric: true,
          invalid: snapshot.fish ? snapshot.fish.invalid : false,
          invalidLabel: 'Enter a whole number between 3 and 12.',
          disabled,
          onEdit: (value) => props.edit('fish', value),
        }),
        React.createElement(SettingsValueField, {
          id: 'cngtn-pond-palette',
          label: 'Colour',
          text: snapshot.palette ? snapshot.palette.text : '',
          hint: 'mixed · warm · cool · mono',
          invalid: snapshot.palette ? snapshot.palette.invalid : false,
          invalidLabel: 'Use one of: mixed, warm, cool, mono.',
          disabled,
          onEdit: (value) => props.edit('palette', value),
        })
      );
    }

    diag.injectCalled = true;
    slots.inject('plugins.bundle.config', () => {
      diag.injectCallbackRan = true;
      try {
        const dispose = slots.register(
          {
            name: 'plugins.bundle.config',
            key: '@cngtn/dsh-cngtn-pond',
            // The framework turns each hook into a \`useXxx\` prop and spreads the
            // actions alongside it — the same face the shipped bundle forms use.
            inject: () => ({ hooks: { pondForm: state }, ...model.actions() }),
          },
          PondConfig
        );
        diag.bundleConfigRegistered = true;
        return dispose;
      } catch (error) {
        diag.notes.push('register threw: ' + (error && error.message));
        console.warn('[cngtn-pond] slot register failed:', error && error.message);
        return () => {};
      }
    });
  } catch (error) {
    diag.notes.push('register: ' + (error && error.message));
    console.warn('[cngtn-pond] bundle config registration failed:', error && error.message);
  }
}

/**
 * A "Pond" button in the Settings header, for the floating panel.
 *
 * Same service rule as the config form: \`ctx.get\`, never \`ctx.inject\`. Optional
 * throughout — if the slot is missing, the console API and the bundle's own
 * settings page still work.
 */
function installSettingsButton(ctx) {
  let slots;
  try {
    slots = typeof ctx.get === 'function' ? ctx.get('slots') : undefined;
  } catch {
    return;
  }
  if (!slots || typeof slots.register !== 'function') return;

  let React;
  try {
    React = require('react');
  } catch {
    return;
  }

  function PondButton() {
    return React.createElement(
      'button',
      {
        type: 'button',
        title: 'Pond settings',
        onClick: () => openPanel(),
        style: {
          height: '28px',
          padding: '0 10px',
          border: '0.5px solid var(--dsw-alias-border-l2)',
          borderRadius: '6px',
          background: 'transparent',
          color: 'var(--dsw-alias-label-secondary)',
          font: 'inherit',
          cursor: 'pointer',
        },
      },
      'Pond'
    );
  }

  try {
    slots.inject('settings.action', () =>
      slots.register({ name: 'settings.action', id: 'cngtn-pond', order: 20 }, PondButton)
    );
  } catch (error) {
    console.warn('[cngtn-pond] settings button unavailable:', error && error.message);
  }
}

/** Client plugin body: the pond, the token layer, then the stylesheet. */
function apply(ctx, config) {
  try {
    const theme = ctx.theme;
    // The Host config is the source of truth; the cache and the patch defaults
    // are only fallbacks. Connecting first means the very first seed already
    // uses the saved school.
    connectHostSettings(ctx);
    const settings = normalizeSettings({ ...(config ?? {}), ...readStored() });
    ctx.effect(() => mountPond(settings), 'cngtn-pond: koi pond');
    ctx.effect(() => theme.overrideTokens(ID, tokens), 'cngtn-pond: token layer');
    ctx.effect(() => injectStyles(), 'cngtn-pond: stylesheet');
    exposeApi();
    registerBundleConfig(ctx);
    installSettingsButton(ctx);
  } catch (error) {
    console.error('[cngtn-pond] apply failed:', error && (error.stack || error.message));
    throw error;
  }
}