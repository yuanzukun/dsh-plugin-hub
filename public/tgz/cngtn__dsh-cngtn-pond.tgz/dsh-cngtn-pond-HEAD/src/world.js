/**
 * world.js — the pond's physics, ported from the original site's `world.ts`.
 *
 * Nothing here touches the DOM or a canvas: this module owns koi, pellets,
 * ripples and bites, and steps them on a fixed 1/60s clock. Keeping it pure is
 * what lets the headless smoke test run 600 frames in Node and assert that no
 * spine node ever goes NaN.
 *
 * The port is deliberately literal. Every constant, every steering force and
 * every ordering decision is the one the site ships, because the whole point of
 * this theme is that the pond feels the same as the pond on the original site.
 */

export const TAU = Math.PI * 2;
export const KOI_NODES = 20;
export const RIPPLE_SPEED = 52;

export const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
const rand = (lo, hi) => lo + Math.random() * (hi - lo);

export function smoothstep(e0, e1, x) {
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
}

export function angleDiff(a, b) {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}

/** Deterministic integer hash to [0, 1), so textures stay pinned to the body. */
export function hash3(x, y, z) {
  let h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(z | 0, 1442695041);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

/**
 * Koi varieties, weighted the way a real pond is stocked: mostly white-and-red,
 * a few patterned, and one or two of the metallic or blue fish that give a
 * school its depth.
 *
 * Each entry is `[variety, weight]`. The renderer owns what each variety looks
 * like; this table only decides how often one appears.
 */
const VARIETY_WEIGHTS = [
  ['kohaku', 4],
  ['sanke', 3],
  ['tancho', 2],
  ['showa', 2],
  ['ogon', 2],
  ['asagi', 1],
  ['bekko', 1],
];
const TOTAL_WEIGHT = VARIETY_WEIGHTS.reduce((sum, [, w]) => sum + w, 0);

function pickVariety() {
  let r = Math.random() * TOTAL_WEIGHT;
  for (const [variety, weight] of VARIETY_WEIGHTS) {
    r -= weight;
    if (r <= 0) return variety;
  }
  return 'kohaku';
}

/**
 * The pigment each fish can carry. These are mid-tones on purpose: the renderer
 * shades them into a ramp, so a colour only has to be recognisable at the
 * middle of the body, not at both ends of the scale.
 */
export const ACCENTS = {
  vermilion: '#cc3e1c',
  orange: '#e0662a',
  gold: '#c9973a',
  yellow: '#d8b64a',
  crimson: '#a8231f',
  blue: '#5f7f95',
  silver: '#b9b3a9',
  ink: '#3a3630',
};

/** Accent pools by palette preset; `mixed` is the full range. */
export const ACCENT_PRESETS = {
  mixed: Object.keys(ACCENTS),
  warm: ['vermilion', 'orange', 'gold', 'yellow', 'crimson'],
  cool: ['blue', 'silver'],
  mono: ['ink'],
};

/** Valid values for the `palette` option, in menu order. */
export const PALETTE_PRESETS = ['mixed', 'warm', 'cool', 'mono'];

/** Valid variety names, in menu order. */
export const VARIETIES = VARIETY_WEIGHTS.map(([name]) => name);

function pickAccent(preset) {
  const pool = ACCENT_PRESETS[preset] ?? ACCENT_PRESETS.mixed;
  // The preset lists pigment *names*; a koi carries the hex, because that is
  // what the renderer turns into a ramp.
  return ACCENTS[pool[Math.floor(Math.random() * pool.length)]];
}

const push = { x: 0, y: 0 };

/** Sum of pushes away from every box within `margin` of (x, y), each scaled 0..1 by closeness. */
function repel(boxes, x, y, margin, out) {
  out.x = 0;
  out.y = 0;
  for (const b of boxes) {
    let ox = x - clamp(x, b.left, b.right);
    let oy = y - clamp(y, b.top, b.bottom);
    let d = Math.hypot(ox, oy);
    if (d > margin) continue;
    if (d < 1e-3) {
      // Inside the box: head for the nearest edge.
      const edges = [b.left - x, x - b.right, b.top - y, y - b.bottom];
      const nearest = edges.indexOf(Math.max(...edges));
      ox = nearest === 0 ? -1 : nearest === 1 ? 1 : 0;
      oy = nearest === 2 ? -1 : nearest === 3 ? 1 : 0;
      d = 0;
    }
    const len = Math.hypot(ox, oy) || 1;
    out.x += (ox / len) * (1 - d / margin);
    out.y += (oy / len) * (1 - d / margin);
  }
  return out;
}

export const PELLET_LIFE = 14;
export const BITE_LIFE = 0.45;
const RUSH_RANGE = 650;
const FEED_CALM = 2;
/** Uneaten pellets start to sink this many seconds in, fading out by PELLET_LIFE. */
export const PELLET_SINK = 9;
const THROW_RADIUS = 34;
const STARTLE_SPEED = 1100;
const MAX_PELLETS = 24;

/**
 * A pond. `budget` scales the population down for a shell that has less open
 * water than a full-screen page: the site seeds 3–6 adults plus two young koi,
 * the DSH theme asks for a smaller pond so the fish never crowd the panels.
 */
export class World {
  constructor(options = {}) {
    this.width = 0;
    this.height = 0;
    this.time = 0;
    this.koi = [];
    this.pellets = [];
    this.bites = [];
    this.ripples = [];
    this.pointer = { x: 0, y: 0, speed: 0, active: false };
    /** Page content the koi steer around, in canvas space. */
    this.avoid = [];
    /** Fraction of the site's population; 1 = the original, 0.7 = the DSH default. */
    this.budget = options.budget ?? 1;
    /**
     * User-facing knobs, all optional:
     *
     *  - `fish`: an exact adult count (3–12). Overrides `budget`.
     *  - `young`: whether the two small koi that keep to the deep water appear.
     *  - `palette`: which accent pool the fish draw from.
     */
    this.fish = Number.isFinite(options.fish) ? clamp(Math.round(options.fish), 3, 12) : null;
    this.young = options.young !== false;
    this.palette = PALETTE_PRESETS.includes(options.palette) ? options.palette : 'mixed';
    this.lastFeed = -Infinity;
  }

  /**
   * Adopt a new canvas size.
   *
   * The site seeds once, because its canvas is always correctly sized on the
   * first measurement. A shell is not that tidy: the canvas is inserted before
   * its stylesheet lands, so the first rect can be the 300×150 default and the
   * fish would then be trapped in that corner of a much larger pond. Seeding
   * again whenever the box changes by more than a quarter keeps the school
   * spread across whatever water it actually has.
   */
  resize(width, height) {
    const first = this.width === 0;
    const shrankOrGrew =
      !first &&
      (Math.abs(width - this.width) > this.width * 0.25 || Math.abs(height - this.height) > this.height * 0.25);
    this.width = width;
    this.height = height;
    if (first || shrankOrGrew) this.seed();
  }

  seed() {
    const { width: W, height: H } = this;
    const minSide = Math.min(W, H);
    const baseLength = clamp(minSide * 0.5, 170, 420);
    // The site's density is one adult per 240 000 px², floored at three and
    // capped at six. `budget` scales that down for a shell with less open water,
    // but the floor stays at three: a pond with two fish does not read as a pond,
    // it reads as two fish.
    const density = (W * H) / 240000;
    // `fish` is the *total* the user asked for, so the number in the panel is the
    // number in the pond. Without it the density estimate decides.
    const total = this.fish !== null ? this.fish : clamp(Math.round(density * this.budget), 3, 6);
    // Wide screens also get a couple of young koi that keep to the deep water,
    // for a sense of depth. They are part of the total, never extra, and only
    // appear when there is water and enough fish to spare.
    const young =
      this.young && W >= 1024 && this.budget >= 0.6 ? Math.min(2, Math.max(0, total - 3)) : 0;
    const count = Math.max(1, total - young);

    this.koi = [];
    for (let i = 0; i < count + young; i++) {
      const isYoung = i >= count;
      const length = baseLength * (isYoung ? rand(0.32, 0.45) : rand(0.6, 1));
      const depthMax = isYoung ? 0.72 : 1;
      const heading = rand(0, TAU);
      const x = rand(W * 0.1, W * 0.9);
      const y = rand(H * 0.1, H * 0.9);
      const nodes = new Float32Array(KOI_NODES * 2);
      const seg = length / (KOI_NODES - 1);
      for (let n = 0; n < KOI_NODES; n++) {
        nodes[n * 2] = x - Math.cos(heading) * seg * n;
        nodes[n * 2 + 1] = y - Math.sin(heading) * seg * n;
      }
      this.koi.push({
        id: i + 1,
        variety: pickVariety(),
        accent: pickAccent(this.palette),
        length,
        nodes,
        heading,
        speed: 20,
        phase: rand(0, TAU),
        turn: 0,
        wander: 0,
        curiosity: rand(0.35, 1),
        depth: rand(0.5, depthMax),
        depthTarget: rand(0.5, depthMax),
        depthMax,
        nextDive: rand(6, 18),
        nextSurface: rand(3, 14),
        nextWake: rand(0, 2),
        beat: 0,
        rush: 0,
        food: null,
        burstUntil: 0,
        nextBurst: rand(0, 3),
        finPhase: rand(0, TAU),
        startle: 0,
        fleeX: 0,
        fleeY: 0,
        gulp: 0,
      });
    }
  }

  /**
   * Apply new user settings. Population and palette changes re-seed the school,
   * which is the only honest way to change "how many fish" — moving existing
   * fish around would leave the pond with a different look than it reports.
   */
  setOptions(next = {}) {
    let reseed = false;
    if (next.fish !== undefined) {
      const value = Number.isFinite(next.fish) ? clamp(Math.round(next.fish), 3, 12) : null;
      if (value !== this.fish) {
        this.fish = value;
        reseed = true;
      }
    }
    if (next.young !== undefined && Boolean(next.young) !== this.young) {
      this.young = Boolean(next.young);
      reseed = true;
    }
    if (next.palette !== undefined && PALETTE_PRESETS.includes(next.palette) && next.palette !== this.palette) {
      this.palette = next.palette;
      reseed = true;
    }
    if (next.budget !== undefined && Number.isFinite(next.budget)) this.budget = next.budget;
    if (reseed && this.width > 0) this.seed();
    return { fish: this.fish, young: this.young, palette: this.palette };
  }

  /** Current settings, for a settings UI to render. */
  getOptions() {
    return { fish: this.fish, young: this.young, palette: this.palette };
  }

  /** A loose handful thrown at (x, y): each pellet lands a beat apart with its own splash, then drifts and sinks. */
  feed(x, y) {
    this.lastFeed = this.time;
    this.ripples.push({ x, y, born: this.time, strength: 0.35 });
    // A full pond takes no more food, rather than dropping old pellets out from
    // under koi already going for them.
    const count = Math.min(5 + Math.floor(Math.random() * 3), MAX_PELLETS - this.pellets.length);
    for (let k = 0; k < count; k++) {
      const a = rand(0, TAU);
      const r = Math.sqrt(Math.random()) * THROW_RADIUS;
      const drift = rand(2, 6);
      this.pellets.push({
        x: x + Math.cos(a) * r * 1.3,
        y: y + Math.sin(a) * r,
        born: this.time,
        landAt: rand(0.15, 0.45),
        landed: false,
        vx: Math.cos(a) * drift,
        vy: Math.sin(a) * drift,
      });
    }
  }

  step(dt) {
    this.time += dt;
    this.pointer.speed *= Math.exp(-dt * 8);
    for (const k of this.koi) this.stepKoi(k, dt);
    const t = this.time;
    this.pellets = this.pellets.filter((p) => t - p.born < PELLET_LIFE);
    for (const p of this.pellets) {
      if (!p.landed) {
        if (t - p.born < p.landAt) continue;
        p.landed = true;
        this.ripples.push({ x: p.x, y: p.y, born: t, strength: 0.1 });
        // The splash is what koi react to: every koi in range turns and bolts
        // for it at once.
        for (const k of this.koi) {
          if (Math.hypot(k.nodes[0] - p.x, k.nodes[1] - p.y) < RUSH_RANGE) k.rush = 1;
        }
        continue;
      }
      const damp = Math.exp(-dt * 0.2);
      p.vx *= damp;
      p.vy *= damp;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    this.ripples = this.ripples.filter((r) => t - r.born < rippleLife(r));
    this.bites = this.bites.filter((b) => t - b.born < BITE_LIFE);
  }

  stepKoi(k, dt) {
    const { width: W, height: H, pointer, time } = this;
    const L = k.length;
    const nodes = k.nodes;
    const hx = nodes[0];
    const hy = nodes[1];

    let dx = Math.cos(k.heading);
    let dy = Math.sin(k.heading);

    k.wander = clamp(k.wander + (Math.random() - 0.5) * dt * 2.4, -0.9, 0.9);
    dx += Math.cos(k.heading + k.wander) * 0.6;
    dy += Math.sin(k.heading + k.wander) * 0.6;

    const food = this.pickFood(k, hx, hy, Math.max(L * 1.6 + 220, k.rush > 0 ? RUSH_RANGE : 0));

    // A fast swipe close by spooks a koi: it bolts away, then calms down over a
    // couple of seconds. A koi already going for food ignores it; feeding beats
    // fear, and clicking to feed moves the mouse fast.
    const pointerD = Math.hypot(pointer.x - hx, pointer.y - hy);
    const feeding = time - this.lastFeed < FEED_CALM;
    if (!food && !feeding && pointer.active && pointer.speed > STARTLE_SPEED && pointerD < L * 0.9) {
      k.startle = 1;
      k.fleeX = pointer.x;
      k.fleeY = pointer.y;
    }
    k.startle = Math.max(0, k.startle - dt * 0.6);
    const fleeing = k.startle > 0.3 && !food;

    let chasing = false;
    let curious = false;
    let closing = 0;
    if (fleeing) {
      const ox = hx - k.fleeX;
      const oy = hy - k.fleeY;
      const d = Math.hypot(ox, oy) || 1;
      dx += (ox / d) * 4 * k.startle;
      dy += (oy / d) * 4 * k.startle;
    } else if (food) {
      const tx = food.x - hx;
      const ty = food.y - hy;
      const d = Math.hypot(tx, ty) || 1;
      dx += (tx / d) * 3;
      dy += (ty / d) * 3;
      chasing = true;
      closing = clamp(1 - d / (L * 1.2), 0, 1);
    } else if (pointer.active) {
      const tx = pointer.x - hx;
      const ty = pointer.y - hy;
      const d = Math.hypot(tx, ty) || 1;
      const range = 300;
      if (d < range) {
        // Swim up to the cursor, then circle under it rather than parking.
        const w = k.curiosity * (1 - d / range) * 2.2;
        const near = clamp(d / (L * 0.6), 0, 1);
        dx += ((tx / d) * near - (ty / d) * (1 - near)) * w;
        dy += ((ty / d) * near + (tx / d) * (1 - near)) * w;
        curious = true;
      }
    }

    for (const other of this.koi) {
      if (other === k) continue;
      const ohx = other.nodes[0];
      const ohy = other.nodes[1];
      if (Math.abs(ohx - hx) > L * 2 || Math.abs(ohy - hy) > L * 2) continue;
      for (let n = 0; n < KOI_NODES; n += 3) {
        const ox = hx - other.nodes[n * 2];
        const oy = hy - other.nodes[n * 2 + 1];
        const d = Math.hypot(ox, oy);
        // Koi going for food jostle in close, so personal space shrinks and
        // never outweighs the pull.
        const range = (L + other.length) * (food ? 0.12 : 0.28);
        if (d < range && d > 1e-3) {
          const w = (1 - d / range) * 2.4;
          dx += (ox / d) * w;
          dy += (oy / d) * w;
        }
      }
      // Loose shoaling: nearby koi drift the same way.
      if (!chasing && Math.hypot(ohx - hx, ohy - hy) < L * 1.6) {
        dx += Math.cos(other.heading) * 0.18;
        dy += Math.sin(other.heading) * 0.18;
      }
    }

    // Drift around page content rather than under it; food and the cursor can
    // still lure them across.
    repel(this.avoid, hx, hy, L * 0.4, push);
    dx += push.x * (chasing || curious ? 0.5 : 1.8);
    dy += push.y * (chasing || curious ? 0.5 : 1.8);

    // Let the body slip off-screen now and then, but always turn back.
    const over = Math.max(-hx, hx - W, -hy, hy - H);
    if (over > -L * 0.25) {
      const w = clamp((over + L * 0.25) / (L * 0.5), 0, 1) * 3.5;
      const toX = W / 2 - hx;
      const toY = H / 2 - hy;
      const d = Math.hypot(toX, toY) || 1;
      dx += (toX / d) * w;
      dy += (toY / d) * w;
    }

    const desired = Math.atan2(dy, dx);
    // Long bodies can't pivot on the spot: the turning circle grows with length.
    const agility =
      (1 + k.rush * 0.6) *
      Math.min(fleeing ? 3 : chasing ? 1.9 + closing : curious ? 1.2 : 0.7, (k.speed / L) * 4);
    const maxTurn = agility * dt;
    const turned = clamp(angleDiff(k.heading, desired), -maxTurn, maxTurn);
    k.heading += turned;
    k.turn += (turned / dt - k.turn) * Math.min(1, dt * 3);

    // Burst and coast: a few strong tail beats, then a long glide that bleeds
    // off speed. Chasing or fleeing koi beat without pause.
    if (time > k.nextBurst && time > k.burstUntil) {
      k.burstUntil = time + rand(0.7, 1.6);
      k.nextBurst = k.burstUntil + rand(1.2, 4);
    }
    const bursting = fleeing || chasing || time < k.burstUntil;
    k.beat += ((bursting ? 1 : 0) - k.beat) * Math.min(1, dt * 3);
    // Tail beats near the surface push small rings out behind the koi; gliding
    // or deep koi leave none.
    if (k.beat > 0.6 && k.depth > 0.65 && time > k.nextWake) {
      const tail = (KOI_NODES - 3) * 2;
      this.ripples.push({ x: nodes[tail], y: nodes[tail + 1], born: time, strength: 0.25 + 0.2 * k.depth });
      k.nextWake = time + rand(0.8, 1.6) / k.beat;
    }
    k.rush = Math.max(0, k.rush - dt * 0.7);
    const cruise = 12 + L * 0.05;
    const target =
      (1 + k.rush * 0.8) *
      (fleeing
        ? cruise * 3.2
        : chasing
          ? cruise * (1.9 + closing)
          : bursting
            ? cruise * (curious ? 1.6 : 1.35)
            : cruise * 0.45);
    k.speed += (target - k.speed) * Math.min(1, dt * (bursting ? 1.6 + k.rush * 3 : 0.35));
    k.phase += dt * (0.6 + k.beat * (2.2 + k.speed / 11));
    k.finPhase += dt * 2.4;
    k.gulp += ((chasing && closing > 0.55 ? 1 : 0) - k.gulp) * Math.min(1, dt * 6);

    // Koi drift between the deep and the surface, and rise for food.
    if (time > k.nextDive) {
      k.depthTarget = rand(0.5, k.depthMax);
      k.nextDive = time + rand(8, 20);
    }
    k.depth += ((chasing ? 1 : k.depthTarget) - k.depth) * Math.min(1, dt * (chasing ? 0.8 : 0.15));

    nodes[0] += Math.cos(k.heading) * k.speed * dt;
    nodes[1] += Math.sin(k.heading) * k.speed * dt;

    const seg = L / (KOI_NODES - 1);
    const maxBend = 0.16;
    let prevAngle = k.heading + Math.PI;
    for (let n = 1; n < KOI_NODES; n++) {
      const px = nodes[(n - 1) * 2];
      const py = nodes[(n - 1) * 2 + 1];
      let angle = Math.atan2(nodes[n * 2 + 1] - py, nodes[n * 2] - px);
      angle = prevAngle + clamp(angleDiff(prevAngle, angle), -maxBend, maxBend);
      nodes[n * 2] = px + Math.cos(angle) * seg;
      nodes[n * 2 + 1] = py + Math.sin(angle) * seg;
      prevAngle = angle;
    }

    const mouthR = L * 0.08 + 6;
    const before = this.pellets.length;
    this.pellets = this.pellets.filter(
      (p) => !p.landed || (p.x - nodes[0]) ** 2 + (p.y - nodes[1]) ** 2 > mouthR * mouthR
    );
    if (this.pellets.length < before) {
      this.ripples.push({ x: nodes[0], y: nodes[1], born: time, strength: 0.6 });
      this.bites.push({ x: nodes[0], y: nodes[1], born: time });
      k.nextSurface = time + rand(6, 16);
    } else if (time > k.nextSurface) {
      this.ripples.push({ x: nodes[0], y: nodes[1], born: time, strength: 0.3 });
      k.nextSurface = time + rand(8, 20);
    }
  }

  /** Keep the current target while it lasts; only switch for a pellet less than half as far away. */
  pickFood(k, x, y, range) {
    if (k.food && !this.pellets.includes(k.food)) k.food = null;
    const nearest = this.nearestPellet(x, y, range);
    if (!k.food) return (k.food = nearest);
    const current = Math.hypot(k.food.x - x, k.food.y - y);
    if (current > range * 1.3) k.food = nearest;
    else if (nearest && Math.hypot(nearest.x - x, nearest.y - y) < current * 0.5) k.food = nearest;
    return k.food;
  }

  nearestPellet(x, y, range) {
    let best = null;
    let bestD = range * range;
    for (const p of this.pellets) {
      if (!p.landed) continue;
      const d = (p.x - x) ** 2 + (p.y - y) ** 2;
      if (d < bestD) {
        bestD = d;
        best = p;
      }
    }
    return best;
  }
}

export function rippleLife(r) {
  return 2.2 + r.strength * 1.6;
}