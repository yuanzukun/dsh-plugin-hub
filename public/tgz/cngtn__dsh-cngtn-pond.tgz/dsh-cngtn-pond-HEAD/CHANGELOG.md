# Changelog

## 1.5.5

Turning the theme on stopped the window from being dragged by its titlebar: the
1.5.2 fix removed the frame's `::before` with `content: none`, and on the
desktop that pseudo-element is the shell's own drag region (40px,
`-webkit-app-region: drag`).

The strip survives again; only its paint is cleared, which the transparent
`--dsw-specific-sidebar-fill` token and the no-blur rules already handle.
Verified in a faithful DOM: the strip still exists with its drag region, and
the frame, the strip and the centre column all compute to rgba(0, 0, 0, 0).

## 1.5.4

The 1.5.3 clear was pointed one level too high: `[data-slot="root"] >
div:nth-child(2)` names the frame's sibling, not the centre column, which is
the frame's own second cell. The desktop kept its page-colour fill and the chat
stayed solid paper.

The clear now reads `[data-slot="root"] > div > div:nth-child(2)` — the frame's
second grid cell — still mirroring the shell's `data-windows-titlebar`
attribute so it stays ahead of the fill. Verified in a faithful DOM (frame as
the root anchor's child, the shell's titlebar fill competing): the column
computes to rgba(0, 0, 0, 0).

## 1.5.3

The 1.5.2 centre-column clear was written at zero specificity, and on the
desktop the shell's own `[data-windows-titlebar] .centerCol` rule — two
class-level tokens painting the page colour — outranked it. The chat rendered
as solid paper on desktop while the web surface stayed clear.

The clear now mirrors the shell's `data-windows-titlebar` attribute, so it sits
ahead of the fill in the cascade; the web path keeps the attribute-free rule.

## 1.5.2

Works on Host 0.2.2, where the shell renamed its frame hooks and rewrote the
Windows frame surface.

- **The pond shows through the chat again.** 0.2.2 renamed `[data-slot="main"]`
  and `[data-slot="sidebar"]`, so the rules that cleared the centre column and
  the style panel went quiet, and the pane's own page-colour fills covered the
  water. The transparency chain is re-expressed against the hooks 0.2.2 does
  publish: the window ground behind the frame, the frame's second grid cell,
  and the conversation pane, Chat view frame and scroll wrapper through the
  `[data-conversation-content]`, `[data-chat-flow]` and
  `[data-chat-turn-spacer]` hooks they contain.
- **The window corners read as transparent again.** 0.2.2 draws the content
  radius on the frame, so the frame's page-colour fill showed at the top-left
  corner inside the floating sidebar card; the frame's fill and its titlebar
  strip pseudo-element are cleared.
- **The right panel is a card again.** 0.2.2 anchors the panel to the frame's
  right edge and draws its own page-colour fill; the panel is inset, its fill
  cleared, and the frosted sheet moved to its `::before`.
- **Icons read as strokes.** The 16-unit-grid icons render with
  `geometricPrecision` and a slightly heavier stroke, so a 1-unit stroke at
  12–16px no longer fogs into a grey haze.
- Every new rule is scoped to a 0.2.2-only hook, so 0.2.1 hosts keep the
  previous behaviour, and the `prefers-reduced-transparency: reduce` path still
  gets flat paper.

## 1.5.1

The plugin is now named **Dsh-Pond-Koi** in the plugin manager, its localized
metadata and the README. The package id, executable name, bundle row id and
console API are unchanged, so existing installations continue to update in
place.

## 1.5.0

The three native Windows caption buttons now follow the theme.

The desktop preload reads `--dsw-specific-sidebar-fill`, converts it to
`rgba()`, and forwards it to `setTitleBarOverlay` over IPC, so that token — not
CSS — decides the colour of the minimise / maximise / close block. It was the
paper colour, so the block stayed opaque while the strip around it was water.

The token is now `transparent` in both modes, and the sidebar's own surfaces are
painted from `--dsw-alias-bg-base` instead, which is what they were mixing the
token into anyway. One value now drives both the panel and the native chrome.

Verified on the desktop app: the caption block reports
`rgba(0, 0, 0, 0)` and the pond runs behind it, in light and dark alike, with
the sidebar card unchanged.

The hover fill Electron paints behind a pressed caption button is still the
shell's own; a theme cannot reach it.

## 1.4.0

The right panel becomes the same floating card as the sidebar, in both its
docked and its expanded presentation.

- **Docked:** the panel is inset to the sidebar's 10/12/20/18px box, so the two
  panels share one inset, one 14px radius, one hairline and one progressive
  shadow. The grid track and the resize handle stay where the shell put them.
- **Expanded:** the card spans the conversation at the same inset, with the
  frosted sheet painted on its own pseudo-element. The transcript behind it is
  blurred rather than visible through it, and the column is raised above the
  centre column so nothing paints over the card.
- **One frame, no seam:** the dock pane's own flush hairline and single-sided
  radius are dropped, because they landed on top of the card's border and read
  as a second, darker line.
- **Closed means closed:** the card, the frosted sheet and the raised stacking
  are all gated on the panel's open state, so hiding the panel no longer leaves
  a sheet over the chat.

## 1.3.0

- The sidebar floats as a card: 14px radius, hairline, progressive shadow, and
  rows clipped to the card's corners.
- The Windows titlebar is transparent, so the pond reaches the top edge.
- The Host config is the single writer, so a saved form reaches the pond.

## 1.2.0

- Seven koi varieties, live pond settings, and the user's own font.
- A `cngtnPond` console API for the panel and for scripting.

## 1.1.0

- A schemastery `Config` on the Host half, so the pond settings render on the
  plugin page.

## 1.0.0

- First publishable bundle: paper-and-ink tokens, the frosted transparency
  chain, and the ASCII koi pond behind the shell.
