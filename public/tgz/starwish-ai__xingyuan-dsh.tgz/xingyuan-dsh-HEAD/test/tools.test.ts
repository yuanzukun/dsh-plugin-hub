/**
 * 工具层行为测试：registerTools(fakeCtx) 注册真实 defineTool 后直调 execute。
 * HITL 经 userQuestions 桩自动「确认」；agent 缺省为 undefined（事件发射跳过，
 * 会话卡回放语义由 loader.test 与客户端负责）。覆盖：
 * - 删除级联：任务/愿望删除时打卡记录与微行动状态一并清理（双平面共用收口）
 * - 批量创建：愿望库存进度即时联动（syncWishProgress 不缺位）
 * - 分类改名：global 颜色覆盖键随改名迁移（与页面动作同一口径）
 * - 写确认门闩：confirmWrites=false 时打卡不再弹卡；删除始终弹
 */
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'
import type { Context } from '@deepseek-ai/cordis'
import { registerTools } from '../src/preset/tools.js'
import type { Config } from '../src/preset/tools.js'
import { CONFIRM_OP_DEFAULTS, type ConfirmOp } from '../src/pref-policy.js'
import { createTask, claimTask, performCheckIn, saveMemory } from '../src/store.js'
import { startMicroAction, getMicroAction } from '../src/micro.js'
import { addDays, todayIso } from '../src/opportunity.js'
import type { WishRecord, XingyuanStore } from '../src/domain.js'
import { memoryStore } from './memory-store.js'

function makeConfig(confirmWrites: boolean, confirmOps?: Partial<Record<ConfirmOp, boolean>>): Config {
  return {
    batchWishLimit: 50,
    batchTaskLimit: 100,
    chartTrendDays: 14,
    chartDistributionDays: 30,
    chartMaxDays: 90,
    chartRankLimit: 10,
    chartRankMax: 20,
    confirmWrites,
    confirmOps: { ...CONFIRM_OP_DEFAULTS, ...confirmOps },
    confirmLang: 'zh',
  }
}

interface ToolDef {
  name: string
  execute: (args: never, exec: never) => Promise<unknown>
}

/** fake ctx：捕获注册的工具定义；userQuestions 桩记录询问次数并自动选 answer（默认「确认」）。 */
function setup(store: XingyuanStore, config: Config, answer = '确认'): {
  registered: ToolDef[]
  state: { asks: number }
  events: Array<{ kind: string; data: Record<string, unknown> }>
  run: (name: string, args: unknown) => Promise<unknown>
} {
  const registered: ToolDef[] = []
  const state = { asks: 0 }
  const events: Array<{ kind: string; data: Record<string, unknown> }> = []
  // agent 必须为真值：headless（无 agent）语义下 confirmAction 直接放行、不询问，
  // 门闩行为只能经「有 agent + userQuestions 桩」路径观测；事件记录器顺带可断言发射。
  const agent = { session: { append: (kind: string, data: Record<string, unknown>) => { events.push({ kind, data }) } } }
  const ctx = {
    xingyuan: store,
    tools: { register: (def: ToolDef) => registered.push(def) },
    userQuestions: {
      ask: async () => {
        state.asks += 1
        return { answers: [{ selected: [answer] }] }
      },
    },
  } as unknown as Context & { xingyuan: XingyuanStore }
  registerTools(ctx, config)
  const run = (name: string, args: unknown): Promise<unknown> => {
    const def = registered.find((tool) => tool.name === name)
    if (def === undefined) throw new Error(`工具未注册：${name}`)
    return def.execute(args as never, { agent, signal: undefined } as never)
  }
  return { registered, state, events, run }
}

async function seedWish(store: XingyuanStore, wishId: string, overrides: Partial<WishRecord> = {}): Promise<WishRecord> {
  const today = todayIso()
  const wish: WishRecord = {
    wishId,
    title: `愿望${wishId}`,
    categoryName: '学习',
    progress: 0,
    totalRequiredDays: 0,
    totalCompletedDays: 0,
    archived: false,
    createdAt: `${today}T00:00:00`,
    ...overrides,
  }
  await store.domain.table('wishes').put(wishId, wish)
  return wish
}

/** 建一个已领取、已打一次卡、已开始微行动的任务（删除级联的完整样本）。 */
async function seedLiveTask(store: XingyuanStore, name: string, wishId?: string): Promise<string> {
  const today = todayIso()
  const task = await createTask(store, {
    name,
    checkInCycle: 'daily',
    dueDate: addDays(today, 7),
    ...(wishId !== undefined ? { wishId } : {}),
  }, today)
  await claimTask(store, task.taskId, today)
  await performCheckIn(store, task.taskId, undefined, today)
  await startMicroAction(store, task.taskId, [
    { instruction: '第一步' },
    { instruction: '第二步' },
    { instruction: '第三步' },
  ])
  return task.taskId
}

describe('工具层：批量创建联动愿望进度', () => {
  it('batch_create_tasks：候选不进愿望进度分母（承诺口径），领取后计入', async () => {
    const store = memoryStore()
    const wishId = 'w-batch-sync'
    await seedWish(store, wishId)
    const today = todayIso()
    const { run } = setup(store, makeConfig(false))
    // 独立推算期望值：T1 daily 今天起至今天+3 共 4 个机会日；T2 once 无截止 = 1
    await run('batch_create_tasks', {
      tasks: [
        { wishId, name: 'T1', checkInCycle: 'daily', dueDate: addDays(today, 3) },
        { wishId, name: 'T2', checkInCycle: 'once' },
      ],
    })
    // 候选不进分母（§5.2 规则 7）：创建后愿望进度分母不变
    let stored = store.domain.table('wishes').get(wishId)!
    expect(stored.totalRequiredDays).toBe(0)
    expect(stored.totalCompletedDays).toBe(0)
    // 领取 T1 后其 4 天计入分母
    const t1 = [...store.domain.table('tasks').entries()].map(([, t]) => t).find((t) => t.name === 'T1')!
    await run('claim_task', { taskId: t1.taskId })
    stored = store.domain.table('wishes').get(wishId)!
    expect(stored.totalRequiredDays).toBe(4)
    expect(stored.totalCompletedDays).toBe(0)
  })
})

describe('工具层：写确认门闩（confirmWrites）', () => {
  it('check_in_task：confirmWrites=false 时不再弹确认卡，直接打卡成功', async () => {
    const store = memoryStore()
    const today = todayIso()
    const task = await createTask(store, { name: '静默打卡', checkInCycle: 'daily', dueDate: addDays(today, 3) }, today)
    await claimTask(store, task.taskId, today)
    const { run, state } = setup(store, makeConfig(false))
    const reply = await run('check_in_task', { taskId: task.taskId }) as string
    expect(reply).toContain('已为')
    expect(state.asks).toBe(0)
    expect([...store.domain.table('checkins').entries()]).toHaveLength(1)
  })

  it('check_in_task：confirmWrites=true 时弹一次确认卡', async () => {
    const store = memoryStore()
    const today = todayIso()
    const task = await createTask(store, { name: '确认打卡', checkInCycle: 'daily', dueDate: addDays(today, 3) }, today)
    await claimTask(store, task.taskId, today)
    const { run, state } = setup(store, makeConfig(true))
    await run('check_in_task', { taskId: task.taskId })
    expect(state.asks).toBe(1)
  })

  it('delete_task：删除始终弹确认卡（不受门闩控制）', async () => {
    const store = memoryStore()
    const taskId = await seedLiveTask(store, '必删任务')
    const { run, state } = setup(store, makeConfig(false))
    await run('delete_task', { taskId })
    expect(state.asks).toBe(1)
    expect(store.domain.table('tasks').get(taskId)).toBeUndefined()
  })

  it('claim_task：类目明细开启时弹卡（桩自动确认后领取成功）', async () => {
    const store = memoryStore()
    const today = todayIso()
    const task = await createTask(store, { name: '可领取', checkInCycle: 'daily', dueDate: addDays(today, 3) }, today)
    const { run, state } = setup(store, makeConfig(true, { claim: true }))
    await run('claim_task', { taskId: task.taskId })
    expect(state.asks).toBe(1)
    expect(store.domain.table('tasks').get(task.taskId)!.status).toBe('in_progress')
  })

  it('claim_task：默认免确认，直接领取不弹卡', async () => {
    const store = memoryStore()
    const today = todayIso()
    const task = await createTask(store, { name: '直接领取', checkInCycle: 'daily', dueDate: addDays(today, 3) }, today)
    const { run, state } = setup(store, makeConfig(true))
    await run('claim_task', { taskId: task.taskId })
    expect(state.asks).toBe(0)
    expect(store.domain.table('tasks').get(task.taskId)!.status).toBe('in_progress')
  })

  it('claim_task：总开关关闭时即使类目开启也不弹卡（一键静音）', async () => {
    const store = memoryStore()
    const today = todayIso()
    const task = await createTask(store, { name: '静默领取', checkInCycle: 'daily', dueDate: addDays(today, 3) }, today)
    const { run, state } = setup(store, makeConfig(false, { claim: true }))
    await run('claim_task', { taskId: task.taskId })
    expect(state.asks).toBe(0)
    expect(store.domain.table('tasks').get(task.taskId)!.status).toBe('in_progress')
  })

  it('update_task：类目明细开启时弹卡；保存记忆同理', async () => {
    const store = memoryStore()
    const taskId = await seedLiveTask(store, '待改任务')
    const { run, state } = setup(store, makeConfig(true, { update: true, memorySave: true }))
    await run('update_task', { taskId, name: '新名字' })
    await run('save_memory', { key: '生日', value: '5月15日', category: 'personal' })
    expect(state.asks).toBe(2)
    expect(store.domain.table('tasks').get(taskId)!.name).toBe('新名字')
    expect(store.domain.table('memories').get('生日')).toBeDefined()
  })

  it('check_in_task：用户在确认卡取消时不写库', async () => {
    const store = memoryStore()
    const today = todayIso()
    const task = await createTask(store, { name: '取消打卡', checkInCycle: 'daily', dueDate: addDays(today, 3) }, today)
    await claimTask(store, task.taskId, today)
    const { run, state } = setup(store, makeConfig(true), '再想想')
    const reply = await run('check_in_task', { taskId: task.taskId }) as string
    expect(state.asks).toBe(1)
    expect([...store.domain.table('checkins').entries()]).toHaveLength(0)
    expect(reply).toContain('已取消打卡')
  })

  it('update_memory：记忆保存类目开启时弹卡（归属 memorySave 而非 update）', async () => {
    const store = memoryStore()
    await store.domain.table('memories').put('生日', { key: '生日', value: '5月15日', category: 'personal', importance: 'medium', createdAt: 0 })
    const { run, state } = setup(store, makeConfig(true, { memorySave: true }))
    await run('update_memory', { key: '生日', value: '6月1日' })
    expect(state.asks).toBe(1)
    expect(store.domain.table('memories').get('生日')!.value).toBe('6月1日')
  })

  it('update_wish：修改类目默认关不弹卡；rename_wish_category 开启则弹', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-u')
    const off = setup(store, makeConfig(true))
    await off.run('update_wish', { wishId: 'w-u', title: '新标题' })
    expect(off.state.asks).toBe(0)
    const on = setup(store, makeConfig(true, { update: true }))
    await on.run('rename_wish_category', { oldName: '学习', newName: '进修' })
    expect(on.state.asks).toBe(1)
    expect(store.domain.table('wishes').get('w-u')!.categoryName).toBe('进修')
  })

  it('create_wish：总开关开启但 create 类目关闭时不弹卡', async () => {
    const store = memoryStore()
    const { run, state } = setup(store, makeConfig(true, { create: false }))
    await run('create_wish', { title: '无确认愿望', categoryName: '阅读' })
    expect(state.asks).toBe(0)
    expect([...store.domain.table('wishes').entries()]).toHaveLength(1)
  })

  it('check_in_task / cancel_check_in_task：类目明细各自关闭时不弹卡', async () => {
    const store = memoryStore()
    const today = todayIso()
    const task = await createTask(store, { name: '静默类目', checkInCycle: 'daily', dueDate: addDays(today, 3) }, today)
    await claimTask(store, task.taskId, today)
    const checkin = setup(store, makeConfig(true, { checkin: false }))
    await checkin.run('check_in_task', { taskId: task.taskId })
    expect(checkin.state.asks).toBe(0)
    expect(store.domain.table('checkins').get(store.checkinKey(task.taskId, today))).toBeDefined()
    const cancel = setup(store, makeConfig(true, { cancelCheckin: false }))
    await cancel.run('cancel_check_in_task', { taskId: task.taskId, checkInDate: today })
    expect(cancel.state.asks).toBe(0)
    expect(store.domain.table('checkins').get(store.checkinKey(task.taskId, today))).toBeUndefined()
  })

  it('rename_wish_category：分类不存在时校验先于确认报错，不弹卡', async () => {
    const store = memoryStore()
    const { run, state } = setup(store, makeConfig(true, { update: true }))
    await expect(run('rename_wish_category', { oldName: '不存在', newName: '无所谓' })).rejects.toThrow('分类「不存在」不存在')
    expect(state.asks).toBe(0)
  })
})

describe('工具层：分类改名迁移颜色覆盖键', () => {
  it('rename_wish_category：愿望批量改名，覆盖键随迁并补发 updated 事件', async () => {
    const store = memoryStore()
    const wishId = 'w-cat'
    await seedWish(store, wishId)
    await store.domain.global.set({
      ...store.domain.global.get(),
      categoryColors: { 学习: 'blue' },
    } as never)
    const { run, events } = setup(store, makeConfig(false))
    const reply = await run('rename_wish_category', { oldName: '学习', newName: '进修' }) as string
    expect(reply).toContain('1 个愿望')
    expect(store.domain.table('wishes').get(wishId)!.categoryName).toBe('进修')
    const global = store.domain.global.get() as { categoryColors?: Record<string, string> }
    expect(global.categoryColors?.['进修']).toBe('blue') // 覆盖键随迁（此前工具侧漏迁，孤儿键残留）
    expect(global.categoryColors?.['学习']).toBeUndefined()
    const wishEvents = events.filter((event) => event.kind === 'xingyuan/wish')
    expect(wishEvents).toHaveLength(1)
    expect((wishEvents[0]!.data as { op: string }).op).toBe('updated')
  })

  it('rename_wish_category：纯颜色覆盖分类（零愿望）改名合法，不再误报分类不存在', async () => {
    const store = memoryStore()
    await store.domain.global.set({
      ...store.domain.global.get(),
      categoryColors: { 空分类: 'green' },
    } as never)
    const { run, events } = setup(store, makeConfig(false))
    const reply = await run('rename_wish_category', { oldName: '空分类', newName: '新分类' }) as string
    expect(reply).toContain('没有愿望')
    const global = store.domain.global.get() as { categoryColors?: Record<string, string> }
    expect(global.categoryColors?.['新分类']).toBe('green')
    expect(global.categoryColors?.['空分类']).toBeUndefined()
    expect(events.filter((event) => event.kind === 'xingyuan/wish')).toHaveLength(0)
  })
})

describe('工具层：删除级联清理（打卡记录 + 微行动状态，不留孤儿）', () => {
  it('delete_task：级联清除打卡记录与微行动状态', async () => {
    const store = memoryStore()
    const taskId = await seedLiveTask(store, '每日阅读')
    const { run } = setup(store, makeConfig(false))
    await run('delete_task', { taskId })
    expect(store.domain.table('tasks').get(taskId)).toBeUndefined()
    expect([...store.domain.table('checkins').entries()]).toHaveLength(0)
    expect(getMicroAction(store, taskId)).toBeUndefined()
  })

  it('batch_delete_tasks：逐个级联清理', async () => {
    const store = memoryStore()
    const a = await seedLiveTask(store, '任务A')
    const b = await seedLiveTask(store, '任务B')
    const { run } = setup(store, makeConfig(false))
    const reply = await run('batch_delete_tasks', { taskIds: [a, b] }) as string
    expect(reply).toContain('成功 2 个')
    expect(store.domain.table('tasks').get(a)).toBeUndefined()
    expect(store.domain.table('tasks').get(b)).toBeUndefined()
    expect([...store.domain.table('checkins').entries()]).toHaveLength(0)
    expect(getMicroAction(store, a)).toBeUndefined()
    expect(getMicroAction(store, b)).toBeUndefined()
  })

  it('delete_wish：愿望、下属任务、打卡、微行动状态一并清理', async () => {
    const store = memoryStore()
    const wishId = 'w-del'
    await seedWish(store, wishId)
    const taskId = await seedLiveTask(store, '下属任务', wishId)
    const { run } = setup(store, makeConfig(false))
    await run('delete_wish', { wishId })
    expect(store.domain.table('wishes').get(wishId)).toBeUndefined()
    expect(store.domain.table('tasks').get(taskId)).toBeUndefined()
    expect([...store.domain.table('checkins').entries()]).toHaveLength(0)
    expect(getMicroAction(store, taskId)).toBeUndefined()
  })

  it('batch_delete_wishes：批量级联清理', async () => {
    const store = memoryStore()
    const w1 = 'w-b1'
    const w2 = 'w-b2'
    await seedWish(store, w1)
    await seedWish(store, w2)
    const t1 = await seedLiveTask(store, '甲任务', w1)
    const t2 = await seedLiveTask(store, '乙任务', w2)
    const { run } = setup(store, makeConfig(false))
    const reply = await run('batch_delete_wishes', { wishIds: [w1, w2] }) as string
    expect(reply).toContain('成功 2 个愿望')
    expect(store.domain.table('wishes').get(w1)).toBeUndefined()
    expect(store.domain.table('wishes').get(w2)).toBeUndefined()
    expect(store.domain.table('tasks').get(t1)).toBeUndefined()
    expect(store.domain.table('tasks').get(t2)).toBeUndefined()
    expect(getMicroAction(store, t1)).toBeUndefined()
    expect(getMicroAction(store, t2)).toBeUndefined()
  })
})

describe('工具面机械审计：HITL 超时与 ID 引用纪律（§5.4）', () => {
  /**
   * 会弹确认卡（读 userQuestions，可能阻塞 agent 回合）的全部工具。
   * 名单与下方源码推导逐字对拍——`complete_micro_step` 曾在名单里而代码从不弹卡
   * （§5.5「微行动步进 = 口头即授权，不设门闩」），已按事实面移除。
   */
  const HITL_WAITING = [
    'create_wish_with_tasks', 'create_wish', 'create_task', 'batch_create_tasks',
    'delete_wish', 'batch_delete_wishes', 'check_in_task', 'cancel_check_in_task',
    'delete_task', 'batch_delete_tasks', 'delete_memory', 'clear_all_memories',
    'update_wish', 'update_task', 'rename_wish_category', 'set_wish_category_color', 'claim_task',
    'save_memory', 'update_memory',
    'start_micro_action', 'restart_micro_action',
  ] as const

  /**
   * 从源码机械推导「会阻塞的工具」= execute 里出现 confirmAction( 的那些。
   * 手写名单会漏（本仓库曾漏 6 个），推导不会：新加工具若开始弹卡而未进名单，即红。
   */
  function blockingToolsFromSource(): string[] {
    const text = readFileSync(join(dirname(fileURLToPath(import.meta.url)), '../src/preset/tools.ts'), 'utf8')
    const blocks = text.split('defineTool({').slice(1)
    const out: string[] = []
    for (const block of blocks) {
      const name = /^\s*name: '([a-z_]+)'/m.exec(block)?.[1]
      if (name !== undefined && block.includes('confirmAction(')) out.push(name)
    }
    return out.sort()
  }

  it('阻塞工具名单与源码推导一致（双向：既不漏报也不虚报）', () => {
    expect(blockingToolsFromSource()).toEqual([...HITL_WAITING].sort())
  })

  it('HITL 等待类工具全部声明 timeoutMs=600_000（协作取消承诺）', () => {
    const store = memoryStore()
    const registered: Array<Record<string, unknown>> = []
    const agent = { session: { append: () => {} } }
    const ctx = {
      xingyuan: store,
      tools: { register: (def: Record<string, unknown>) => registered.push(def) },
      userQuestions: { ask: async () => ({ answers: [{ selected: ['确认'] }] }) },
    } as unknown as Parameters<typeof registerTools>[0]
    registerTools(ctx, makeConfig(true))
    const byName = new Map(registered.map((def) => [def.name as string, def]))
    expect(byName.size).toBe(49)
    for (const name of HITL_WAITING) {
      const def = byName.get(name)
      expect(def, `${name} 未注册`).toBeDefined()
      expect(def!['timeoutMs'], `${name} 缺 timeoutMs`).toBe(600_000)
    }
  })

  it('ID 类参数描述全部携带「取列表返回的真实值」纪律', () => {
    const store = memoryStore()
    const registered: Array<Record<string, unknown>> = []
    const ctx = {
      xingyuan: store,
      tools: { register: (def: Record<string, unknown>) => registered.push(def) },
      userQuestions: { ask: async () => ({ answers: [{ selected: ['确认'] }] }) },
    } as unknown as Parameters<typeof registerTools>[0]
    registerTools(ctx, makeConfig(true))
    for (const def of registered) {
      const parameters = (def.parameters ?? {}) as Record<string, { description?: string }>
      for (const [param, spec] of Object.entries(parameters)) {
        if (!/^(taskId|taskIds|wishId|wishIds)$/.test(param)) continue
        expect(spec.description ?? '', `${def.name as string}.${param} 缺 ID 纪律说明`).toContain('真实值')
      }
    }
  })
})

describe('工具层：达成闸门翻转联动（2026-09 承诺口径修订——翻转必须触达模型与卡面）', () => {
  /** 造一个「满进度而有候选」的待结算愿望：once 任务已领取并打卡完结 + 一个未领取候选。 */
  async function seedSettled(store: XingyuanStore): Promise<{ doneTaskId: string; candTaskId: string }> {
    const today = todayIso()
    await seedWish(store, 'w-gate')
    const done = await createTask(store, { wishId: 'w-gate', name: '冲刺交付', checkInCycle: 'once', dueDate: today }, today)
    await claimTask(store, done.taskId, today)
    const cand = await createTask(store, { wishId: 'w-gate', name: '复盘习惯', checkInCycle: 'daily', dueDate: addDays(today, 7) }, today)
    return { doneTaskId: done.taskId, candTaskId: cand.taskId }
  }

  it('check_in_task 触发进待结算：回包注明收尾路径，补发 wish 事件携 settled/pendingCount', async () => {
    const store = memoryStore()
    const { doneTaskId } = await seedSettled(store)
    const { run, events } = setup(store, makeConfig(false))
    const reply = await run('check_in_task', { taskId: doneTaskId }) as string
    expect(reply, '达成闸门翻转必须触达模型').toContain('就差最后一步')
    // 回包是逐字转述面：给模型的祈使句（第三人称「请让用户决定」「不要代做」）不得混入
    expect(reply).not.toContain('请让用户')
    expect(reply).not.toContain('不要代做')
    expect(reply).toContain('领了继续，或删掉就达成') // 收尾句固定句式（SETTLE_PHRASE 单源）
    const wishEvent = [...events].reverse().find((e) => e.kind === 'xingyuan/wish')
    expect(wishEvent, '任务工具达成翻转须补发愿望事件（卡面同步）').toBeDefined()
    const snapshot = (wishEvent!.data as { wish: Record<string, unknown> }).wish
    expect(snapshot.progress).toBe(100)
    expect(snapshot.settled).toBe(true)
    expect(snapshot.pendingCount).toBe(1)
  })

  it('delete_task 删除最后一个候选 = 收尾达成：回包注明 🎉，wish 事件定格达成', async () => {
    const store = memoryStore()
    const { candTaskId } = await seedSettled(store)
    const today = todayIso()
    const done = [...store.domain.table('tasks').entries()].map(([, t]) => t).find((t) => t.name === '冲刺交付')!
    await performCheckIn(store, done.taskId, undefined, today)
    const { run, events } = setup(store, makeConfig(false))
    const reply = await run('delete_task', { taskId: candTaskId }) as string
    expect(reply).toContain('已达成')
    const wishEvent = [...events].reverse().find((e) => e.kind === 'xingyuan/wish')
    const snapshot = (wishEvent!.data as { wish: Record<string, unknown> }).wish
    expect(snapshot.settled).toBe(false)
    expect(snapshot.pendingCount).toBe(0)
    expect(snapshot.achieved, '达成卡须带 achieved 位（聊天卡显已达成徽章，与页面/回包一致）').toBe(true)
    expect(store.domain.table('wishes').get('w-gate')!.archived).toBe(true)
  })

  it('get_wish_list：候选单列计数、满进度候选附收尾说明、删候选后达成 🎉（状态后缀同源 wishStatusNote）', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-plain')
    await createTask(store, { wishId: 'w-plain', name: '候选甲', checkInCycle: 'daily', dueDate: addDays(todayIso(), 7) }, todayIso())
    const { run } = setup(store, makeConfig(false))
    // 全候选愿望（无已领取任务）：计划中口径（与愿望页/详情同一称呼）
    const list1 = await run('get_wish_list', {}) as string
    expect(list1).toContain('还没开始（计划中，1 个任务待领取）')
    expect(list1).not.toContain('就差最后一步')
    // 待结算愿望：附收尾说明
    const { candTaskId } = await seedSettled(store)
    const today = todayIso()
    const done = [...store.domain.table('tasks').entries()].map(([, t]) => t).find((t) => t.name === '冲刺交付')!
    await performCheckIn(store, done.taskId, undefined, today)
    const list2 = await run('get_wish_list', {}) as string
    expect(list2).toContain('答应自己的都做到了，还有 1 个任务待领取')
    // 删除最后一个候选（收尾）→ 达成 🎉
    await run('delete_task', { taskId: candTaskId })
    const list3 = await run('get_wish_list', {}) as string
    expect(list3).toContain('已达成 🎉')
  })

  it('claim_task：daily 无截止日候选（requiredDays=0）不扩分母，领取最后一个候选直接达成（R1 确证入口）', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-claim')
    const today = todayIso()
    const done = await createTask(store, { wishId: 'w-claim', name: '有数任务', checkInCycle: 'once', dueDate: today }, today)
    await claimTask(store, done.taskId, today)
    await performCheckIn(store, done.taskId, undefined, today) // progress 100，有候选 → 待结算
    const zero = await createTask(store, { wishId: 'w-claim', name: '随心记录', checkInCycle: 'daily' }, today)
    expect(zero.requiredDays).toBe(0) // 前提：无截止日 daily 不进分母
    const { run, events } = setup(store, makeConfig(false))
    const reply = await run('claim_task', { taskId: zero.taskId }) as string
    expect(reply).toContain('已达成')
    expect(store.domain.table('wishes').get('w-claim')!.archived).toBe(true)
    const wishEvent = [...events].reverse().find((e) => e.kind === 'xingyuan/wish')
    expect(wishEvent, '领取致达成翻转须补发愿望事件').toBeDefined()
  })

  it('create_task 向已达成愿望追加候选：退档触达回包与愿望事件（不留假「已达成」卡）', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-back')
    const today = todayIso()
    const done = await createTask(store, { wishId: 'w-back', name: '唯一承诺', checkInCycle: 'once', dueDate: today }, today)
    await claimTask(store, done.taskId, today)
    await performCheckIn(store, done.taskId, undefined, today) // 100% 无候选 → 达成归档
    expect(store.domain.table('wishes').get('w-back')!.archived).toBe(true)
    const { run, events } = setup(store, makeConfig(false))
    const reply = await run('create_task', { wishId: 'w-back', name: '新想法', checkInCycle: 'once', dueDate: addDays(today, 2) }) as string
    expect(reply, '追加候选使愿望退档，模型必须知情').toContain('就差最后一步')
    const wishEvent = [...events].reverse().find((e) => e.kind === 'xingyuan/wish')
    expect(wishEvent, '退档同样补发愿望事件').toBeDefined()
    expect(store.domain.table('wishes').get('w-back')!.archived).toBe(false)
  })

  it('cancel_check_in_task 使已达成愿望回退：回包注明并补发事件（三方同源）', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-cancel')
    const today = todayIso()
    const done = await createTask(store, { wishId: 'w-cancel', name: '两步承诺', checkInCycle: 'daily', dueDate: addDays(today, 1) }, today)
    await claimTask(store, done.taskId, today)
    await performCheckIn(store, done.taskId, today, today)
    await performCheckIn(store, done.taskId, addDays(today, 1), today) // 2/2 达成
    expect(store.domain.table('wishes').get('w-cancel')!.archived).toBe(true)
    const { run } = setup(store, makeConfig(false))
    const reply = await run('cancel_check_in_task', { taskId: done.taskId, checkInDate: addDays(today, 1) }) as string
    expect(reply).toContain('取消达成')
    expect(store.domain.table('wishes').get('w-cancel')!.archived).toBe(false)
  })

  it('update_task 延长截止日使待结算愿望完成率跌破 100%：回退触达回包并补发事件（R2 确证缺口）', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-extend')
    const today = todayIso()
    const done = await createTask(store, { wishId: 'w-extend', name: '每日小事', checkInCycle: 'daily', dueDate: today }, today)
    await claimTask(store, done.taskId, today)
    await performCheckIn(store, done.taskId, today, today)
    const cand = await createTask(store, { wishId: 'w-extend', name: '候选', checkInCycle: 'once', dueDate: addDays(today, 5) }, today)
    // 此刻：1/1 满进度 + 1 候选 = 待结算
    const { run, events } = setup(store, makeConfig(false))
    const reply = await run('update_task', { taskId: done.taskId, dueDate: addDays(today, 10) }) as string
    expect(reply, '分母扩大跌破 100% = 退出待结算回进行中，模型必须知情').toContain('退出待收尾')
    const wishEvent = [...events].reverse().find((e) => e.kind === 'xingyuan/wish')
    expect(wishEvent, '回退同样补发愿望事件（卡面摘掉待结算定格）').toBeDefined()
    expect(store.domain.table('tasks').get(cand.taskId)!.status).toBe('pending') // 候选不受影响
  })

  it('batch_create_tasks 向已达成愿望追加候选：愿望退档行进批量回包（单遍前视图比对）', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-batch-back')
    const today = todayIso()
    const done = await createTask(store, { wishId: 'w-batch-back', name: '唯一承诺', checkInCycle: 'once', dueDate: today }, today)
    await claimTask(store, done.taskId, today)
    await performCheckIn(store, done.taskId, undefined, today)
    const { run } = setup(store, makeConfig(false))
    const reply = await run('batch_create_tasks', {
      tasks: [
        { wishId: 'w-batch-back', name: '新想法一', checkInCycle: 'once', dueDate: addDays(today, 2) },
        { wishId: 'w-batch-back', name: '新想法二', checkInCycle: 'weekly', dueDate: addDays(today, 30) },
      ],
    }) as string
    expect(reply).toContain('就差最后一步')
    expect(reply).not.toMatch(/🎉。/) // 行尾标点粘连回归锁
    expect(store.domain.table('wishes').get('w-batch-back')!.archived).toBe(false)
  })

  it('get_wish_detail：计划中愿望不报「进度 0%」、全候选双述消除、待结算附收尾句', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-d1')
    const today = todayIso()
    await createTask(store, { wishId: 'w-d1', name: '纯候选', checkInCycle: 'daily', dueDate: addDays(today, 7) }, today)
    const { run } = setup(store, makeConfig(false))
    const planning = await run('get_wish_detail', { wishId: 'w-d1' }) as string
    expect(planning).toContain('计划中')
    expect(planning).not.toContain('进度 0%')
    expect(planning).not.toContain('进度 100%（') // 无鬼态：未兑现承诺不虚报满进度
    // 已领取 0 天任务（daily 无截止）：claimedCount>0 非计划中，但 required=0 无应打天数——
    // 报「进度 0%」但用文字说明无截止日，绝不得渲染出「0/0 天」坏显示（终审 P1 回归锁）
    await seedWish(store, 'w-d2')
    const zero = await createTask(store, { wishId: 'w-d2', name: '随心记录', checkInCycle: 'daily' }, today)
    await claimTask(store, zero.taskId, today)
    const claimedZero = await run('get_wish_detail', { wishId: 'w-d2' }) as string
    expect(claimedZero).not.toContain('计划中')
    expect(claimedZero).not.toContain('0/0')
    expect(claimedZero).toContain('无截止日')
  })

  it('claim_task 领取多日候选（待结算→回退）：回包同时含退出待结算与新增承诺两句（R3 P2-1 锁）', async () => {
    const store = memoryStore()
    const { doneTaskId } = await seedSettled(store)
    const today = todayIso()
    await performCheckIn(store, doneTaskId, undefined, today) // 满进度+1候选 = 待结算
    const { run } = setup(store, makeConfig(false))
    const list = await run('get_task_list', { status: 'pending' }) as string
    const candId = /\[([^\]]+)\]/.exec(list)?.[1]!
    const reply = await run('claim_task', { taskId: candId }) as string
    expect(reply).toContain('退出待收尾')
    expect(reply).toContain('新增承诺')
    expect(store.domain.table('wishes').get('w-gate')!.progress).toBeLessThan(100)
  })

  it('batch_query_user_data：wish 行携 archived/settled/pendingCount 与口径声明（模型汇总不误报达成）', async () => {
    const store = memoryStore()
    await seedSettled(store)
    const { run } = setup(store, makeConfig(false))
    const raw = await run('batch_query_user_data', {}) as string
    const parsed = JSON.parse(raw) as {
      wishProgressCaliber: string
      wishes: Array<{ wishId: string; progress: number; archived: boolean; settled: boolean; pendingCount: number }>
    }
    expect(parsed.wishProgressCaliber).toContain('待收尾')
    const gated = parsed.wishes.find((w) => w.wishId === 'w-gate')!
    expect(gated.progress).toBe(0) // 未打卡：0/1
    expect(gated.archived).toBe(false)
    expect(gated.pendingCount).toBe(1)
  })

  it('create_wish 裸愿望事件携派生位：卡显「计划中」与愿望页同源（终审 B1 回归锁）', async () => {
    const store = memoryStore()
    const { run, events } = setup(store, makeConfig(false))
    await run('create_wish', { title: '读一本书', categoryName: '阅读' })
    const wishEvent = events.find((e) => e.kind === 'xingyuan/wish')
    expect(wishEvent, '创建必发愿望事件').toBeDefined()
    const snapshot = (wishEvent!.data as { wish: Record<string, unknown> }).wish
    // 旧缺陷：裸库存记录无派生位 → 卡降级渲染「进度 0%」，与愿望页「计划中」分叉
    expect(snapshot).toHaveProperty('planning', true)
    expect(snapshot).toHaveProperty('pendingCount', 0)
    expect(snapshot).toHaveProperty('settled', false)
    expect(snapshot).toHaveProperty('achieved', false)
  })

  it('claim_task 独立任务（无所属愿望）：不谎报「已计入愿望进度」（终审 B2 回归锁）', async () => {
    const store = memoryStore()
    const today = todayIso()
    const standalone = await createTask(store, { wishId: undefined, name: '独立小事', checkInCycle: 'daily', dueDate: addDays(today, 7) }, today)
    const { run } = setup(store, makeConfig(false))
    const reply = await run('claim_task', { taskId: standalone.taskId }) as string
    expect(reply).toContain('已领取')
    expect(reply).not.toContain('计入')
    expect(reply).not.toContain('愿望')
  })

  it('待收尾愿望增删候选（计数漂移不翻转）：回包不加戏、事件必补发（终审 S4 三方同源锁）', async () => {
    const store = memoryStore()
    const { doneTaskId } = await seedSettled(store)
    const today = todayIso()
    await performCheckIn(store, doneTaskId, undefined, today) // 满进度 + 1 候选 = 待收尾
    const { run, events } = setup(store, makeConfig(false))
    const reply = await run('create_task', { wishId: 'w-gate', name: '又一个想法', checkInCycle: 'once', dueDate: addDays(today, 3) }) as string
    expect(reply, '状态未翻转，回包不得再报「就差最后一步」').not.toContain('就差最后一步')
    const wishEvent = [...events].reverse().find((e) => e.kind === 'xingyuan/wish')
    expect(wishEvent, '待领取数已变而卡定格旧数 = 三方分叉，必须补发').toBeDefined()
    const snapshot = (wishEvent!.data as { wish: Record<string, unknown> }).wish
    expect(snapshot.pendingCount).toBe(2)
    expect(snapshot.settled).toBe(true)
  })
})

/**
 * 页面动作的工具面对拍（0.2.0-rc.1 随包新参考
 * `dsh-agent-preset/skills/cordis-plugin-development/references/user-actions.md`：
 * 「一个操作两个调用方」——插件 UI 对应用数据与配置的操作要同样暴露给 agent）。
 * 三处原先只有页面出口：分类颜色覆盖、清空全部记忆、非权限类偏好写入。
 * 锁的要点：① 与页面共用同一份存储收口；② 校验先于确认（不让用户白点一次卡）；
 * ③ 写后要读回比对，宿主没接受就报错，绝不含糊说「改好了」；
 * ④ 放宽安全策略的开关（confirmWrites/confirmOps）**不进工具参数**。
 */
describe('工具层：页面动作的工具面补齐（user-actions 口径）', () => {
  it('set_wish_category_color 写入 global 覆盖，与页面 category-color 同一份存储', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-color')
    const { run } = setup(store, makeConfig(false))
    const reply = await run('set_wish_category_color', { categoryName: '学习', colorKey: 'blue' }) as string
    expect(reply).toContain('blue')
    expect(store.domain.global.get().categoryColors).toEqual({ 学习: 'blue' })
  })

  it('set_wish_category_color：空串 = 清除覆盖（页面「跟随愿望」同语义）', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-color')
    const { run } = setup(store, makeConfig(false))
    await run('set_wish_category_color', { categoryName: '学习', colorKey: 'blue' })
    const reply = await run('set_wish_category_color', { categoryName: '学习', colorKey: '' }) as string
    expect(reply, '清除与改色是两种语义，回包不得混为一谈').toContain('恢复自动配色')
    expect(store.domain.global.get().categoryColors).toBeUndefined()
  })

  it('set_wish_category_color：分类不存在与未知色键都在弹卡前拒绝', async () => {
    const store = memoryStore()
    await seedWish(store, 'w-color')
    // 开着「修改」类确认再验：校验必须发生在弹卡之前，否则用户白点一次卡
    const { run, state } = setup(store, makeConfig(true, { update: true }))
    await expect(run('set_wish_category_color', { categoryName: '没这个分类', colorKey: 'blue' })).rejects.toThrow('不存在')
    await expect(run('set_wish_category_color', { categoryName: '学习', colorKey: 'chartreuse' })).rejects.toMatchObject({ code: 'bad_color_key' })
    expect(state.asks, '校验失败不该先弹卡再报错').toBe(0)
  })

  it('clear_all_memories：确认后清空并回包条数；取消则一条不动；删除类不受总开关影响', async () => {
    const store = memoryStore()
    await saveMemory(store, '生日', '3月1日', 'personal', 'high')
    await saveMemory(store, '职业', '教师', 'personal', 'medium')
    const ok = setup(store, makeConfig(false))
    expect(await ok.run('clear_all_memories', {})).toContain('已清空 2 条')
    expect(store.domain.table('memories').size).toBe(0)

    const keep = memoryStore()
    await saveMemory(keep, '生日', '3月1日', 'personal', 'high')
    const no = setup(keep, makeConfig(false), '取消')
    expect(await no.run('clear_all_memories', {})).toContain('已取消')
    expect(keep.domain.table('memories').size).toBe(1)
    expect(no.state.asks, '总开关关闭时删除类仍始终确认（ADR-0001）').toBe(1)
  })

  it('clear_all_memories：空库直接回，不弹卡', async () => {
    const { run, state } = setup(memoryStore(), makeConfig(true))
    expect(await run('clear_all_memories', {})).toContain('无需清空')
    expect(state.asks).toBe(0)
  })

  it('update_xingyuan_settings 写入即生效，get_xingyuan_settings 读到同一份', async () => {
    const store = memoryStore()
    const { run } = setup(store, makeConfig(false))
    const reply = await run('update_xingyuan_settings', { memoryInjectLimit: 20, confirmLang: 'en' }) as string
    expect(reply).toContain('记忆注入上限：20 条')
    expect(store.prefs().memoryInjectLimit).toBe(20)
    expect(store.prefs().confirmLang).toBe('en')
    const shown = await run('get_xingyuan_settings', {}) as string
    expect(shown).toContain('记忆注入上限：20 条')
    expect(shown).toContain('确认卡语言：en')
  })

  it('update_xingyuan_settings：显隐模式与勾项一并生效', async () => {
    const store = memoryStore()
    const { run } = setup(store, makeConfig(false))
    await run('update_xingyuan_settings', { tabVisibilityMode: 'show', hiddenTabs: ['growth', 'memory'] })
    expect(store.uiPrefs()).toEqual({ tabVisibilityMode: 'show', hiddenTabs: ['growth', 'memory'] })
  })

  it('update_xingyuan_settings：越界 / 未知标签 / 空参数都带稳定 code 拒绝且不落盘', async () => {
    const store = memoryStore()
    const { run } = setup(store, makeConfig(false))
    await expect(run('update_xingyuan_settings', { memoryInjectLimit: 999 })).rejects.toMatchObject({ code: 'bad_memory_limit' })
    await expect(run('update_xingyuan_settings', { hiddenTabs: ['bogus'] })).rejects.toMatchObject({ code: 'unknown_tab' })
    await expect(run('update_xingyuan_settings', {})).rejects.toMatchObject({ code: 'missing_field' })
    expect(store.prefs().memoryInjectLimit, '拒绝即不得半写').toBe(40)
    expect(store.uiPrefs().hiddenTabs).toEqual([])
  })

  it('update_xingyuan_settings：宿主没接受（读回仍旧值）时报 pref_write_rejected，不含糊说改好了', async () => {
    const base = memoryStore()
    const store: XingyuanStore = { ...base, setPrefs: async () => undefined }
    const { run } = setup(store, makeConfig(false))
    await expect(run('update_xingyuan_settings', { tabVisibilityMode: 'show' })).rejects.toMatchObject({ code: 'pref_write_rejected' })
  })

  it('放宽安全策略的开关不进工具参数（user-actions：授权类动作保持用户专属）', () => {
    const { registered } = setup(memoryStore(), makeConfig(false))
    const def = registered.find((tool) => tool.name === 'update_xingyuan_settings') as unknown as {
      parameters: Record<string, unknown>
      description: string
    }
    expect(Object.keys(def.parameters)).not.toContain('confirmWrites')
    expect(Object.keys(def.parameters)).not.toContain('confirmOps')
    expect(def.description, '描述要给出用户自助入口').toContain('设置 → 星愿')
    const shown = registered.find((tool) => tool.name === 'get_xingyuan_settings') as unknown as { description: string }
    expect(shown.description).toContain('只读')
  })
})
