/**
 * Loader 级真实组合测试（§4.3：手动 ctx.plugin() 不算）。
 * 经 cordis-plugin-loader 以 cordis.yml 语义启动最小完整组合：
 * storage hub → 星愿 sqlite 后端 → 领域路由（xingyuan→sqlite）→
 * system-prompt / user-questions / tools → bundle 主行（领域服务+/xingyuan/* 路由）→ preset 侧工具行。
 * 断言：模型可见工具面注册、领域落库回读、偏好写入落到主行 id、逐行 dispose 清理
 * （工具注销/服务注销/后端注销）。
 * 运行前置：pnpm build（preset 侧经 ./lib/preset/side.js 相对路径装载，与发布形态一致）。
 */
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import { Loader } from '@deepseek-ai/cordis-plugin-loader'
import { storageBackendServiceKey } from '@deepseek-ai/dsh-storage'
// 类型副作用：组合内各服务的 Context 声明合并
import type {} from '@deepseek-ai/dsh-storage'
import type {} from '@deepseek-ai/dsh-tools'
import { inject } from '../src/index.js'
import { SETTINGS_ENTRY_ID } from '../src/pref-policy.js'
import type { XingyuanStore } from '../src/domain.js'

const pkgRoot = join(dirname(fileURLToPath(import.meta.url)), '..')

/** 组合内由本测试创建的行（收尾倒序拆除）。 */
const ENTRIES = ['xingyuan-side', 'xingyuan', 'tools', 'user-questions', 'system-prompt', 'storage-domain', 'xingyuan-sqlite', 'storage'] as const

/**
 * 轮询等待服务出现。激活链（preset 发布 → 开领域 → provide）在 apply 返回后的
 * 微/宏任务中完成，registry 无公开的就绪事件可 await——只能观测其公开读取面。
 */
async function untilDefined<T>(get: () => T | undefined, what: string): Promise<T> {
  for (let i = 0; i < 500; i++) {
    const value = get()
    if (value !== undefined) return value
    await new Promise((resolve) => setTimeout(resolve, 10))
  }
  throw new Error(`等待超时：${what}`)
}

describe('loader 级组合启动', () => {
  let ctx: Context
  let loader: Loader
  /** settings 桩的观测面：主行 configure（关掉自动生成页）与 update（对话侧写偏好落点）。 */
  const settingsCalls: Array<{ ns: string; patch: unknown }> = []
  const configureCalls: unknown[] = []

  /** 装配一行（运行时接受 id 定位；类型层 Omit 掉了它——单一转接点注明）。 */
  async function mount(entry: { id: string; name: string; config?: unknown }): Promise<void> {
    await loader.create(entry as Parameters<Loader['create']>[0])
  }

  /** 模型可见工具名集合（registry 公开面 schemas()）。 */
  function visibleTools(): string[] {
    return ctx.tools.schemas().map((schema) => schema.name)
  }

  beforeAll(async () => {
    // 隔离：会话日志自愈扫 $DSH_HOME/sessions，指向临时目录即不触碰真实用户数据
    process.env.DSH_HOME = mkdtempSync(join(tmpdir(), 'xy-loader-'))
    ctx = new Context()
    // 宿主 boot 同款：baseUrl 挂 ctx 供裸包名解析；Loader 以插件行装载
    ctx.baseUrl = `${pathToFileURL(pkgRoot).href}/`
    // webServer 桩：bundle 主行 inject webServer；组合测试不启真实 HTTP 服务。
    // 契约对拍真实宿主：register 返回路由 disposer、重复 (kind,path) 抛错——
    // 重挂载测试据此验证 bundle 行经 ctx.effect 注销路由（否则重挂必炸重复路径）
    const registeredRoutes = new Set<string>()
    ctx.provide('webServer', {
      register(route: { kind: string; path: string }): () => void {
        const key = `${route.kind}:${route.path}`
        if (registeredRoutes.has(key)) throw new Error(`duplicate ${key} route`)
        registeredRoutes.add(key)
        return () => { registeredRoutes.delete(key) }
      },
    })
    // sessions 桩：bundle 主行 inject sessions（会话日志自愈的活会话枚举，session-log-repair.ts）；
    // 组合测试不建真实会话，DSH_HOME 已指向临时目录、扫描天然空转
    ctx.provide('sessions', { list: () => [] })
    // settings 桩：主行 inject settings（关掉自动生成页 + 对话侧写偏好的落点）。
    // 真机语义对拍：宿主按**行 id** 索引表单，故 ns 必须等于 SETTINGS_ENTRY_ID——
    // 两者不一致时设置整页与工具写入会一起静默失效（§5.8 同一类坑）。
    ctx.provide('settings', {
      configure: (presentation: unknown) => {
        configureCalls.push(presentation)
        return () => undefined
      },
      update: async (ns: string, patch: unknown) => {
        settingsCalls.push({ ns, patch })
      },
    })
    await ctx.plugin(Loader)
    loader = ctx.loader
    await mount({ id: 'storage', name: '@deepseek-ai/dsh-storage' })
    // 本包三行用相对路径：裸包名会从 loader 包自身位置解析（宿主经安装闭包解析，
    // 测试组合无闭包）；相对路径按 ctx.baseUrl 解析，装载同一份构建产物。
    await mount({ id: 'xingyuan-sqlite', name: './lib/sqlite.js', config: { path: ':memory:' } })
    await mount({ id: 'storage-domain', name: '@deepseek-ai/dsh-storage-domain', config: { backend: 'sqlite', routes: { xingyuan: 'sqlite' } } })
    await mount({ id: 'system-prompt', name: '@deepseek-ai/dsh-system-prompt' })
    await mount({ id: 'user-questions', name: '@deepseek-ai/dsh-user-questions' })
    await mount({ id: 'tools', name: '@deepseek-ai/dsh-tools' })
    await mount({ id: 'xingyuan', name: './lib/index.js' })
    await mount({ id: 'xingyuan-side', name: './lib/preset/side.js' })
  })

  afterAll(async () => {
    for (const id of ENTRIES) {
      try {
        await loader.remove(id)
      } catch {}
    }
  })

  it('bundle 主行打开领域并发布服务，落库可回读', async () => {
    const store = await untilDefined(() => ctx.xingyuan, 'xingyuan 服务')
    await store.domain.table('wishes').put('w-loader', {
      wishId: 'w-loader',
      title: '组合测试愿望',
      categoryName: '学习',
      progress: 0,
      totalRequiredDays: 0,
      totalCompletedDays: 0,
      archived: false,
      createdAt: '2026-08-24T00:00:00',
    })
    expect(store.domain.table('wishes').get('w-loader')?.title).toBe('组合测试愿望')
  })

  it('主行关掉宿主自动生成页，并把对话侧偏好写入落到主行 id', async () => {
    const store = await untilDefined(() => ctx.xingyuan, 'xingyuan 服务')
    expect(configureCalls, '本包自带设置整页 → configure({auto:false})').toContainEqual({ auto: false })
    settingsCalls.length = 0
    await store.setPrefs({ memoryInjectLimit: 20, hiddenTabs: ['growth'] })
    expect(settingsCalls).toEqual([
      { ns: SETTINGS_ENTRY_ID, patch: { memoryInjectLimit: 20, hiddenTabs: ['growth'] } },
    ])
  })

  it('preset 侧经 Loader 注册星愿工具面（模型可见 schemas）', () => {
    const names = visibleTools()
    for (const name of ['create_wish', 'create_task', 'check_in_task', 'search_wishes', 'get_wish_detail', 'generate_chart']) {
      expect(names).toContain(name)
    }
  })

  it('逐行 dispose：工具注销、领域服务注销、sqlite 后端注销', async () => {
    await loader.remove('xingyuan-side')
    const names = visibleTools()
    expect(names).not.toContain('create_wish')
    expect(names).not.toContain('check_in_task')

    await loader.remove('xingyuan')
    expect(ctx.xingyuan).toBeUndefined()

    await loader.remove('xingyuan-sqlite')
    expect(() => ctx.storage.backend.get('sqlite')).toThrow()
  })

  it('重挂载（HMR/升级路径）：拔除后整行可重建，路由 disposer 已注销不再抛重复注册', async () => {
    // dispose 测试已拔掉三行；重建顺序与 beforeAll 一致。若路由注册未经 ctx.effect
    // 挂载（disposer 被丢弃），此处的重复 /xingyuan 前缀注册会被桩按宿主契约抛错。
    // 注意 :memory: 库随行销毁——重挂载后是全新介质，落库断言用新写入验证
    await mount({ id: 'xingyuan-sqlite', name: './lib/sqlite.js', config: { path: ':memory:' } })
    await mount({ id: 'xingyuan', name: './lib/index.js' })
    await mount({ id: 'xingyuan-side', name: './lib/preset/side.js' })
    const store = await untilDefined(() => ctx.xingyuan, '重挂载后的 xingyuan 服务')
    await store.domain.table('wishes').put('w-remount', {
      wishId: 'w-remount',
      title: '重挂载愿望',
      categoryName: '学习',
      progress: 0,
      totalRequiredDays: 0,
      totalCompletedDays: 0,
      archived: false,
      createdAt: '2026-08-28T00:00:00',
    })
    expect(store.domain.table('wishes').get('w-remount')?.title).toBe('重挂载愿望')
    expect(visibleTools()).toContain('create_wish')
  })

  it('主行单独重载（HMR 只换主行的场景）：sqlite 行不动，重挂主行后领域可重开且介质数据仍在', async () => {
    // 官方 HMR 语义：dispose 只作用于被换的那一行，兄弟行（xingyuan-sqlite）存活。
    // unit.close() 若不释放单元占用，重开必抛 "already open on this backend"——
    // 插件就此死亡直到进程重启。sqlite 行未重挂 → :memory: 介质未销毁，重开领域
    // 应看到重载前写入的数据（同后端实例同一 DB 连接）。
    const storeBefore = await untilDefined(() => ctx.xingyuan, '重载前的 xingyuan 服务')
    await storeBefore.domain.table('wishes').put('w-mainrow-reload', {
      wishId: 'w-mainrow-reload',
      title: '主行重载存活愿望',
      categoryName: '学习',
      progress: 0,
      totalRequiredDays: 0,
      totalCompletedDays: 0,
      archived: false,
      createdAt: '2026-09-06T00:00:00',
    })
    await loader.remove('xingyuan')
    await mount({ id: 'xingyuan', name: './lib/index.js' })
    const store = await untilDefined(() => ctx.xingyuan, '主行单独重挂后的 xingyuan 服务')
    expect(store.domain.table('wishes').get('w-mainrow-reload')?.title).toBe('主行重载存活愿望')
  })
})

/**
 * 后端注册顺序无关激活（官方 storage.zh.md 契约）：
 * 「数据形式提供方注入 storageBackendServiceKey(name)，使自身激活不会与后端注册
 * 发生竞态」——bundle 主行必须靠依赖声明等待 sqlite 后端行，而非依赖 patch 的
 * 行顺序。
 */
describe('后端注册顺序无关激活', () => {
  it('主行 inject 声明 sqlite 后端生命周期键（声面契约：缺失即退回依赖 patch 行顺序）', () => {
    // 声明唯一出处是 src/index.ts（lib 产物由构建复制；lib 的行为面由上一测试的
    // 敌对顺序装载覆盖），此处直接对源码声明断言
    expect(inject).toContain(storageBackendServiceKey('sqlite'))
  })

  it('敌对顺序端到端：主行先于 sqlite 行发起装载，靠依赖声明等待而非失败', { timeout: 15_000 }, async () => {
    process.env.DSH_HOME = mkdtempSync(join(tmpdir(), 'xy-loader-order-'))
    const ctx2: Context = new Context()
    ctx2.baseUrl = `${pathToFileURL(pkgRoot).href}/`
    const registeredRoutes = new Set<string>()
    ctx2.provide('webServer', {
      register(route: { kind: string; path: string }): () => void {
        const key = `${route.kind}:${route.path}`
        if (registeredRoutes.has(key)) throw new Error(`duplicate ${key} route`)
        registeredRoutes.add(key)
        return () => { registeredRoutes.delete(key) }
      },
    })
    ctx2.provide('sessions', { list: () => [] })
    await ctx2.plugin(Loader)
    const loader2 = ctx2.loader
    const mount2 = (entry: { id: string; name: string; config?: unknown }) =>
      loader2.create(entry as Parameters<Loader['create']>[0])

    await mount2({ id: 'storage', name: '@deepseek-ai/dsh-storage' })
    await mount2({ id: 'storage-domain', name: '@deepseek-ai/dsh-storage-domain', config: { backend: 'sqlite', routes: { xingyuan: 'sqlite' } } })
    // 关键时序：主行先发起，此刻 sqlite 后端尚未注册。有依赖声明时 fiber 等待；
    // 无声明时 apply 立即执行并失败（backend-not-found），服务永不就绪 → untilDefined 超时红。
    const mainMount = mount2({ id: 'xingyuan', name: './lib/index.js' })
    mainMount.catch(() => {}) // 失败形态的拒绝先挂钩防未处理拒绝（红态由下方断言呈现）
    await mount2({ id: 'xingyuan-sqlite', name: './lib/sqlite.js', config: { path: ':memory:' } })
    const store = await untilDefined(() => ctx2.xingyuan, '顺序颠倒组合的 xingyuan 服务')
    await store.domain.table('wishes').put('w-order', {
      wishId: 'w-order',
      title: '顺序无关愿望',
      categoryName: '学习',
      progress: 0,
      totalRequiredDays: 0,
      totalCompletedDays: 0,
      archived: false,
      createdAt: '2026-09-06T00:00:00',
    })
    expect(store.domain.table('wishes').get('w-order')?.title).toBe('顺序无关愿望')
    for (const id of ['xingyuan', 'xingyuan-sqlite', 'storage-domain', 'storage']) {
      try { await loader2.remove(id) } catch {}
    }
  })
})
