# 星愿 XingYuan for DeepSeek Harness

[![npm version](https://img.shields.io/npm/v/@starwish-ai/xingyuan-dsh)](https://www.npmjs.com/package/@starwish-ai/xingyuan-dsh)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)
[![CI](https://github.com/starwish-ai/xingyuan-dsh/actions/workflows/ci.yml/badge.svg)](https://github.com/starwish-ai/xingyuan-dsh/actions/workflows/ci.yml)

简体中文 | [English](./README.en-US.md)

星愿是一个愿望与习惯养成助手，以 DeepSeek Harness 插件组合包 + Agent Preset 形式交付。

## 功能

- **对话驱动**：自然语言创建愿望 / 任务，自动查重相似项
- **机会日打卡**：周期任务打卡、补卡、取消、未来预勾，进度跨天恒为最新
- **承诺口径进度**：只有领取的任务算进度；达成 = 承诺全部完成且没有待领取的任务——
  做完但有没领的，愿望停在「待收尾」等你决定（领了继续，或删掉就达成），不催也不代劳
- **微行动拆解**：把无从下手的目标拆成 3–7 个小步，引导式逐个完成或跳过
- **成长体系**：等级 Lv.1–Lv.10、连续加成、统计卡与近 30 天柱状图
- **会话视图页**：今日 / 愿望 / 任务 / 日历 / 成长 / 记忆 六个标签页，页面按钮直连动作接口；
  默认仅星愿预设的会话显示，可在设置里切换「始终显示 / 始终隐藏」并按标签勾选
- **记忆**：重要记忆自动注入上下文（上限可配），支持增删改查与一键清空
- **图表**：15 种统计图表自动渲染为卡片
- **页面与对话同权**：页面上能做的（打卡 / 领取 / 删除 / 分类改名与配色 / 清空记忆 /
  调整偏好）都能直接在对话里说，走同一份业务收口，结果与回显一致；
  放宽安全策略的开关（写操作二次确认）例外，只能由本人在设置页改
- **安全确认**：写操作二次确认按类目细化（创建 / 打卡 / 取消打卡 / 领取 / 修改 / 保存记忆），删除始终确认不可关闭；默认与此前版本一致
- **主题适配**：深浅色跟随应用主题

工具只挂载在选择星愿 preset 的会话上，不影响其他会话。

## 安装

> 需要 DeepSeek Harness `0.1.7-rc.1` 或 `0.2.0-rc.1`（peer 依赖同时 admit 这两条版本线，
> 含 client 半侧的宿主包；0.1.7 重写了设置子系统，更早的宿主上本插件的 client 半侧不会激活；
> rc.1 起 dsh 会按 peer 范围**整包拒绝加载**不匹配的插件，本包的「每条线都放行」由测试锁死。
> 两版宿主的定时提醒能力不同，插件不把能力写死。升级 dsh 前先核对 [AGENTS.md](./AGENTS.md)
> 的升级要点）。

```sh
dsh plugin --profile web add @starwish-ai/xingyuan-dsh
```

启动 Web GUI 后，agent 选择器出现「星愿」即安装成功。

> 选择器里没有「星愿」？升级到本插件 `0.6.5-alpha.2` 以上——dsh 0.1.7 起宿主不再扫描
> `~/.dsh/.agent-presets/` 目录，预设改由插件补丁里的声明行注册，旧版本会静默不出现。

> 选择器里没有「星愿」？升级到本插件 `0.6.5-alpha.2` 以上——dsh 0.1.7 起宿主不再扫描
> `~/.dsh/.agent-presets/` 目录，预设改由插件补丁里的声明行注册，旧版本会静默不出现。

## 数据与备份

业务数据存于 `~/.dsh/xingyuan/xingyuan.sqlite`，卸载 / 升级均存活，备份只需拷贝该目录。
设置页里的**偏好**自 dsh 0.1.7 起改存 profile 文档
（`~/.dsh/profiles/<profile>/cordis.patch.yml` 的本插件行），不在上面的目录里——换机要
恢复偏好需额外拷贝该文件。

## 设置（Web GUI → 设置 → 星愿）

| 配置项 | 说明 |
| --- | --- |
| 教练风格 | 温柔 / 幽默 / 严格 |
| 用户画像 | 昵称、职业、兴趣 |
| 写操作二次确认 | 总开关 + 六个类目明细（创建 / 打卡 / 取消打卡 / 领取 / 修改 / 保存记忆）是否确认；删除始终确认、不可关闭 |
| 记忆注入上限 | 每次注入上下文的记忆条数上限（也可在对话里直接说「设成 20 条」） |
| 标签页显示 | 三态模式（跟随会话 / 始终显示 / 始终隐藏）+ 六个标签逐个勾选；默认跟随会话（后四项偏好均可在对话里调整） |
| 确认卡语言 | 对话中确认卡的显示语言（中文 / English；平台不向插件暴露界面语言，默认中文） |

## 开发

```sh
pnpm install
pnpm build   # tsc + tsdown（集成测试依赖 lib/ 产物）
pnpm test    # vitest
```

架构、领域口径与客户端开发纪律见 [AGENTS.md](./AGENTS.md)；贡献流程见
[CONTRIBUTING](./CONTRIBUTING.md)。

发布：推送 `v*` tag 自动构建并发布到 npm（预发布版本挂 `alpha` tag）。

## License

[MIT](./LICENSE)
