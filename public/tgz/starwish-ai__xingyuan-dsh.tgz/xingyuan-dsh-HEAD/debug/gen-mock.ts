/**
 * 视觉验证回路：用真实 STYLE_TEXT + 手写镜像 DOM 生成深/浅两主题的静态 mock 页，
 * 供浏览器截图核对客户端样式改版（客户端 React 页面无法脱离 dsh 壳运行，见 AGENTS.md §5.10）。
 *
 * 运行：npx vite-node debug/gen-mock.ts
 *   → 产出 debug/ui-mock.html（深色）与 debug/ui-mock-light.html（浅色），本地起静态服务截图核对。
 * 纪律：markup 为真实 tsx 输出的手写镜像，仅用于视觉核对；对应组件结构变更时须同步本文件。
 *
 * 场景覆盖（与页面一一对应）：日历 / 今日（含非星愿提示行）/ 愿望（任务区披露：收起默认态+展开态 / 卡内展开详情）/ 任务（分组卡+已完结行）/
 * 成长（英雄卡+强调 streak 统计+近30天柱图）/ 记忆（撰写卡+图标行动作）/
 * 设置（五分节面板：教练/画像/确认/偏好/标签页，开关类 row 行语法）/ 快速新建（任务轻表单）/ 空态·错误态·危险按钮（纯文字版式，插画已移除）。
 */
import { writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { STYLE_TEXT } from '../src/client/styles.js'

/** 壳令牌替身（mock 自给自足；取值贴近 dsh 壳深浅两套观感）。 */
const SHELL_LIGHT = `
  --dsw-alias-bg-layer-1:#ffffff;--dsw-alias-bg-layer-2:#f1f5f9;--dsw-alias-bg-overlay:#ffffff;
  --dsw-alias-bg-mask-1:rgba(15,23,42,.45);
  --dsw-alias-border-l1:#e2e8f0;--dsw-alias-border-l2:#cbd5e1;--dsw-alias-border-l3:#94a3b8;
  --dsw-alias-label-primary:#0f172a;--dsw-alias-label-secondary:#64748b;
  --dsw-alias-state-success-primary:#0f766e;`

const SHELL_DARK = `
  --dsw-alias-bg-layer-1:#1f2731;--dsw-alias-bg-layer-2:#2a3442;--dsw-alias-bg-overlay:#1a212c;
  --dsw-alias-bg-mask-1:rgba(0,0,0,.5);
  --dsw-alias-border-l1:#2e3947;--dsw-alias-border-l2:#3d4a5c;--dsw-alias-border-l3:#55647a;
  --dsw-alias-label-primary:#e6edf5;--dsw-alias-label-secondary:#8b98ab;
  --dsw-alias-state-success-primary:#34d399;`

// ===== 共享片段（镜像 src/client/ui.ts 的 IconTrash / IconEdit）=====
const ICON_TRASH = '<svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true" focusable="false" style="display:block;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><path d="M4 7h16"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/><path d="M6.5 7l.8 12a2 2 0 0 0 2 1.9h5.4a2 2 0 0 0 2-1.9l.8-12"/><path d="M10 11v6M14 11v6" opacity="0.55"/></svg>'
const ICON_EDIT = '<svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true" focusable="false" style="display:block;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><path d="M13.5 5l5.5 5.5"/><path d="M5 19l1-4L17.5 3.5a2.12 2.12 0 0 1 3 3L9 18z"/></svg>'
const ICON_CHEVRON = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" focusable="false" style="display:block;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><path d="M6 9l6 6 6-6"/></svg>'

/** 任务区披露开关（镜像 wishes.ts）：整行按钮 = 任务数 + 下箭头；展开态旋转由 aria-expanded 选择器驱动。 */
const wishToggle = (id: string, n: number, open: boolean): string =>
  `<button class="xy-wishtoggle" type="button" aria-expanded="${open}" aria-controls="${id}">${n} 个任务${ICON_CHEVRON}</button>`

// 2026 年 8 月：1 日周六（周一头），首行 7/27–8/2，末行 8/31 + 9/1–9/6；
// 27 = today + 待打卡（验证环与状态底共存），20 = 选中态
const CELL = (cls: string, n: string, tag = 'button'): string =>
  `<${tag} class="xy-cell ${cls}"${tag === 'button' ? ' type="button"' : ''}><span class="xy-daynum">${n}</span></${tag}>`

const week = (cells: string[]): string => `<div class="xy-week">${cells.join('')}</div>`

const calBody = [
  week([CELL('xy-outside', '27', 'span'), CELL('xy-outside', '28', 'span'), CELL('xy-outside', '29', 'span'), CELL('xy-outside', '30', 'span'), CELL('xy-outside', '31', 'span'), CELL('xy-c0', '1'), CELL('xy-c0', '2')]),
  week([CELL('xy-c1', '3'), CELL('xy-c3', '4'), CELL('xy-c1', '5'), CELL('xy-c0', '6'), CELL('xy-c1', '7'), CELL('xy-c3', '8'), CELL('xy-c3', '9')]),
  week([CELL('xy-c1', '10'), CELL('xy-c2', '11'), CELL('xy-c1', '12'), CELL('xy-c1', '13'), CELL('xy-c3', '14'), CELL('xy-c0', '15'), CELL('xy-c0', '16')]),
  week([CELL('xy-c1', '17'), CELL('xy-c1', '18'), CELL('xy-c2', '19'), CELL('xy-c1 xy-picked', '20'), CELL('xy-c1', '21'), CELL('xy-c0', '22'), CELL('xy-c0', '23')]),
  week([CELL('xy-c3', '24'), CELL('xy-c1', '25'), CELL('xy-c1', '26'), CELL('xy-c1 xy-today', '27'), CELL('xy-c1', '28'), CELL('xy-c1', '29'), CELL('xy-c1', '30')]),
  week([CELL('xy-c2', '31'), CELL('xy-outside', '1', 'span'), CELL('xy-outside', '2', 'span'), CELL('xy-outside', '3', 'span'), CELL('xy-outside', '4', 'span'), CELL('xy-outside', '5', 'span'), CELL('xy-outside', '6', 'span')]),
].join('\n')

/** 详情打卡格（镜像 detail.ts）：7 列周对齐网格。窗口 2026-08-27 前推含占位——
 * 真实数据按机会日稀疏返回，首格前置隐形占位（blank）是常态；今日格带 accent 环。 */
const DCELL = (tone: string, n: string, extra = ''): string =>
  `<span class="xy-dcell ${tone}${extra}" aria-hidden="true" ${tone !== 'xy-dcell-blank' ? `title="镜像格 ${n}"` : ''}>${tone === 'xy-dcell-blank' ? '' : n}</span>`

const BLANK = DCELL('xy-dcell-blank', '')
const DC = (n: string, extra = ''): string => DCELL('xy-dcell-checked', n, extra)
const DM = (n: string): string => DCELL('xy-dcell-missed', n)
const DF = (n: string): string => DCELL('xy-dcell-future', n)

// 5 行：窗口=截至今日末 28 格口径——8/2..8/27（26 日）+ 预勾 8/29、8/30（28 日未打卡
// 不进网格，27 后直接跳 29 演示稀疏）；today=8/27（周四，第 5 行）未打卡=future 底色
// + accent 环（today 环不覆盖状态底色）；首行前 6 占位（8/2=周日）演示错位对齐。
const dcells = [
  BLANK, BLANK, BLANK, BLANK, BLANK, BLANK,
  DC('2'),
  DC('3'), DM('4'), DC('5'), DC('6'), DM('7'), DC('8'), DC('9'),
  DC('10'), DM('11'), DC('12'), DC('13'), DC('14'), DM('15'), DC('16'),
  DC('17'), DC('18'), DM('19'), DC('20'), DC('21'), DM('22'), DC('23'),
  DC('24'), DC('25'), DC('26'), DF('27', ' xy-dcell-today'), DC('29'), DC('30'),
].join('')
const dgridSummary = '近 28 格窗口：已打 21（含预勾 2），漏打 6，今天待打卡'

const detailLegend = `
<div class="xy-legend">
  <span><i class="xy-dot xy-dcell-checked" aria-hidden="true"></i>已打卡</span>
  <span><i class="xy-dot xy-dcell-missed" aria-hidden="true"></i>未打卡</span>
  <span><i class="xy-dot xy-dcell-future" aria-hidden="true"></i>待打卡</span>
</div>`

/** 展开详情（镜像 detail.ts）：周对齐网格 + 操作区 [主操作][辅助][危险] 单行成组，无重复元信息行。 */
const detailOps = (id: string): string => `
<div class="xy-detail" id="${id}">
  <div>
    <span class="xy-quick-label">打卡记录</span>
    <div class="xy-detail-grid" role="img" aria-label="${dgridSummary}">${dcells}</div>
    ${detailLegend}
  </div>
  <div class="xy-detail-next">接下来的机会日：9月28日、10月5日、10月12日、10月19日</div>
  <div>
    <span class="xy-quick-label">微行动进度</span>
    <span class="xy-meta">尚未开始微行动拆解（可在对话里说「帮我拆解」）。</span>
  </div>
  <div>
    <span class="xy-quick-label">操作</span>
    <div class="xy-detail-ops">
      <button class="xy-btn xy-btn-primary" type="button">✓ 打卡</button>
      <button class="xy-btn" type="button" aria-label="撤销 8月30日 的打卡">取消打卡</button>
      <button class="xy-btn" type="button">让 AI 总结</button>
      <button class="xy-btn xy-btn-danger" type="button">删除</button>
    </div>
  </div>
</div>`

/** 任务行（镜像 task-line.ts）：状态词仅已完结保留（进行中/待领取由旁侧按钮自解释）。 */
const taskLine = (name: string, meta: string, actions: string): string => `
  <div class="xy-taskline">
    <span class="xy-taskname">${name}</span>
    <span class="xy-meta">${meta}</span>
    <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">${actions}</div>
  </div>`

/** 今日页（镜像 today.ts）：概览英雄卡（大号完成计数锚点）+ 待完成/已完成分组卡。 */
const todaySection = `
<div class="xy-page">
  <section class="xy-todayhero">
    <div class="xy-todayhero-top">
      <h2 class="xy-page-title">今日打卡 · 8月27日 周四</h2>
      <span class="xy-todayhero-num">2/5 · 40%</span>
    </div>
    <div class="xy-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="40" aria-label="今日打卡进度">
      <div class="xy-bar-fill" style="transform:scaleX(.4)"></div>
    </div>
  </section>
  <p class="xy-hint">当前会话未启用星愿预设：页面数据可浏览、操作可用，但对话中的星愿能力不可用。</p>
  <section class="xy-group">
    <h3 class="xy-group-head"><span class="xy-group-dot xy-group-dot-warn" aria-hidden="true"></span><span>待完成</span><span class="xy-group-count">3</span></h3>
    <ul class="xy-grouplist">
      <li class="xy-grouprow">
        <div class="xy-rowmain">
          <span class="xy-rowtitle">每天动手练习调用AI接口30分钟</span>
          <span class="xy-meta">每天 · AI token 自由 · 下班后先热身再上强度</span>
        </div>
        <button class="xy-btn xy-btn-primary" type="button">✓ 打卡</button>
      </li>
      <li class="xy-grouprow">
        <div class="xy-rowmain">
          <span class="xy-rowtitle">周末清晨拉伸十分钟</span>
          <span class="xy-meta">每周 · 身体健康</span>
        </div>
        <button class="xy-btn" type="button">领取</button>
      </li>
      <li class="xy-grouprow">
        <div class="xy-rowmain">
          <span class="xy-rowtitle">睡前阅读纸质书 20 页</span>
          <span class="xy-meta">每天 · 更好的睡眠</span>
        </div>
        <button class="xy-btn xy-btn-primary" type="button">✓ 打卡</button>
      </li>
    </ul>
  </section>
  <section class="xy-group">
    <h3 class="xy-group-head"><span class="xy-group-dot xy-group-dot-ok" aria-hidden="true"></span><span>已完成</span><span class="xy-group-count">2</span></h3>
    <ul class="xy-grouplist">
      <li class="xy-grouprow xy-done">
        <div class="xy-rowmain">
          <span class="xy-rowtitle"><span class="xy-done-glyph" aria-hidden="true">✓</span>晨间笔记三行</span>
          <span class="xy-meta">每天</span>
        </div>
        <button class="xy-btn" type="button">撤销</button>
      </li>
      <li class="xy-grouprow xy-done">
        <div class="xy-rowmain">
          <span class="xy-rowtitle"><span class="xy-done-glyph" aria-hidden="true">✓</span>喝够 8 杯水</span>
          <span class="xy-meta">每天</span>
        </div>
        <button class="xy-btn" type="button">撤销</button>
      </li>
    </ul>
  </section>
</div>`

/** 愿望页（镜像 wishes.ts）：卡头删除为图标幽灵危险键 + 卡内展开详情 + 任务行（无冗余状态词）；
 * 进度三态——计划中 / 进行中（待领取单列计数）/ 待收尾（满进度有待领取，附收尾指引行）；
 * 页头摘要三态各计各的（待收尾不混入「进行中」，与卡片称呼统一）。 **/
const wishSection = `
<div class="xy-page">
  <div class="xy-page-head">
    <h2 class="xy-page-title">我的愿望</h2>
    <span class="xy-meta">1 个进行中 · 1 个计划中 · 1 个待收尾</span>
    <div class="xy-page-actions"><button class="xy-btn" type="button">＋ 新建愿望</button><button class="xy-btn" type="button">分类管理</button></div>
  </div>
  <div class="xy-wishcard">
    <div class="xy-card-head">
      <span class="xy-badge xy-badge-cat" style="--cat-h:220;--cat-sbg:58;--cat-sfg:46;--cat-sbd:46">学习</span>
      <span class="xy-title">AI token 自由</span>
      <span class="xy-progress-num">进度 15%<span class="xy-meta"> · 1 个任务待领取</span></span>
      <button class="xy-btn xy-btn-danger xy-btn-icon" type="button" aria-label="删除 · AI token 自由" title="删除">${ICON_TRASH}</button>
    </div>
    <div class="xy-meta">拥有属于自己的 AI 接口额度与调用能力，想用就用，不受平台和次数限制。</div>
    <div class="xy-meta">预计完成 2026年11月24日</div>
    <div class="xy-bar"><div class="xy-bar-fill" style="transform:scaleX(.15)"></div></div>
${wishToggle('mock-wishtasks-1', 3, true)}
    <div class="xy-wishtasks" id="mock-wishtasks-1">
${taskLine('每周复盘token用量并优化调用方式', '每周 · 5/9 天 · 下次 9月28日 · 截止 10月19日', '<button class="xy-btn xy-btn-primary" type="button">提前打卡 9月28日</button><button class="xy-btn xy-btn-inline" type="button" aria-expanded="true">收起详情</button>')}
${detailOps("mock-detail-wish")}
${taskLine('每天动手练习调用AI接口30分钟', '每天 · 1/31 天 · 截止 9月23日', '<button class="xy-btn xy-btn-primary" type="button">✓ 打卡</button><button class="xy-btn xy-btn-inline" type="button" aria-expanded="false">展开详情</button>')}
${taskLine('每周读一篇 Agent 领域论文', '每周 · 领取后开始计 8 次', '<button class="xy-btn" type="button">领取</button><button class="xy-btn xy-btn-inline" type="button" aria-expanded="false">展开详情</button>')}
    </div>
  </div>
  <div class="xy-wishcard">
    <div class="xy-card-head">
      <span class="xy-badge xy-badge-cat" style="--cat-h:150;--cat-sbg:52;--cat-sfg:40;--cat-sbd:44">健康</span>
      <span class="xy-title">规律作息</span>
      <span class="xy-progress-num">进度 100%<span class="xy-meta"> · 2 个任务待领取</span></span>
      <button class="xy-btn xy-btn-danger xy-btn-icon" type="button" aria-label="删除 · 规律作息" title="删除">${ICON_TRASH}</button>
    </div>
    <div class="xy-bar"><div class="xy-bar-fill" style="transform:scaleX(1)"></div></div>
    <div class="xy-meta">答应自己的都做完了——待领取的领了继续，或删掉就达成</div>
${wishToggle('mock-wishtasks-2', 2, false)}
  </div>
  <div class="xy-wishcard">
    <div class="xy-card-head">
      <span class="xy-badge xy-badge-cat" style="--cat-h:280;--cat-sbg:56;--cat-sfg:44;--cat-sbd:45">生活</span>
      <span class="xy-title">整理书房</span>
      <span class="xy-progress-num">计划中<span class="xy-meta"> · 2 个任务待领取</span></span>
      <button class="xy-btn xy-btn-danger xy-btn-icon" type="button" aria-label="删除 · 整理书房" title="删除">${ICON_TRASH}</button>
    </div>
    <div class="xy-bar"><div class="xy-bar-fill" style="transform:scaleX(0)"></div></div>
${wishToggle('mock-wishtasks-3', 2, false)}
  </div>
</div>`

/** 任务页（镜像 tasks.ts）：进行中组（详情展开）+ 待领取组 + 已完结组（唯一保留状态词处）。 */
const tasksSection = `
<div class="xy-page">
  <div class="xy-page-head">
    <h2 class="xy-page-title">全部任务</h2>
    <span class="xy-meta">共 4 个</span>
    <div class="xy-page-actions"><button class="xy-btn" type="button">＋ 新建任务</button></div>
  </div>
  <section class="xy-group">
    <h3 class="xy-group-head"><span class="xy-group-dot xy-group-dot-accent" aria-hidden="true"></span><span>进行中</span><span class="xy-group-count">2</span></h3>
    <div class="xy-grouplist">
    <div class="xy-grouprow xy-taskrow">
${taskLine('每周复盘token用量并优化调用方式', '每周 · 5/9 天 · 下次 9月28日 · 截止 10月19日', '<button class="xy-btn xy-btn-primary" type="button">提前打卡 9月28日</button><button class="xy-btn xy-btn-inline" type="button" aria-expanded="true">收起详情</button>')}
${detailOps("mock-detail-task")}
    </div>
${taskLine('每天动手练习调用AI接口30分钟', '每天 · 1/31 天 · 截止 9月23日', '<button class="xy-btn xy-btn-primary" type="button">✓ 打卡</button><button class="xy-btn xy-btn-inline" type="button" aria-expanded="false">展开详情</button>')}
    </div>
  </section>
  <section class="xy-group">
    <h3 class="xy-group-head"><span class="xy-group-dot xy-group-dot-warn" aria-hidden="true"></span><span>待领取</span><span class="xy-group-count">1</span></h3>
    <div class="xy-grouplist">
${taskLine('每两周给相机传感器做一次清洁', '每周 · 领取后开始计 6 次', '<button class="xy-btn" type="button">领取</button><button class="xy-btn xy-btn-inline" type="button" aria-expanded="false">展开详情</button>')}
    </div>
  </section>
  <section class="xy-group">
    <h3 class="xy-group-head"><span class="xy-group-dot xy-group-dot-ok" aria-hidden="true"></span><span>已完结</span><span class="xy-group-count">1</span></h3>
    <div class="xy-grouplist">
${taskLine('试用新的深呼吸 App 两周', '每天 · 14/14 天 · 已完结', '')}
    </div>
  </section>
</div>`

/** 日历页（镜像 calendar.ts）。 */
const calSection = `
<div class="xy-page">
  <div class="xy-page-head xy-calnav">
    <button class="xy-btn" type="button" aria-label="上个月">‹</button>
    <h2 class="xy-page-title">2026年8月</h2>
    <button class="xy-btn" type="button" aria-label="下个月">›</button>
    <button class="xy-btn xy-calnav-back" type="button">回到本月</button>
  </div>
  <div class="xy-panel xy-calcard">
    <div class="xy-calhead">
      <span class="xy-calhead-cell">一</span><span class="xy-calhead-cell">二</span><span class="xy-calhead-cell">三</span><span class="xy-calhead-cell">四</span><span class="xy-calhead-cell">五</span><span class="xy-calhead-cell">六</span><span class="xy-calhead-cell">日</span>
    </div>
    <div class="xy-cal">
${calBody}
    </div>
    <div class="xy-legend">
      <span><i class="xy-dot xy-c0" aria-hidden="true"></i>无打卡安排</span>
      <span><i class="xy-dot xy-c1" aria-hidden="true"></i>待打卡</span>
      <span><i class="xy-dot xy-c2" aria-hidden="true"></i>部分完成</span>
      <span><i class="xy-dot xy-c3" aria-hidden="true"></i>全部完成</span>
    </div>
  </div>
  <div class="xy-daypanel" aria-live="polite">
    <div class="xy-daydetail">
      <h3 class="xy-section-title">8月27日 周四</h3>
      <ul class="xy-grouplist">
        <li class="xy-grouprow">
          <div class="xy-rowmain">
            <span class="xy-rowtitle">每天动手练习调用AI接口30分钟</span>
            <span class="xy-meta">每天 · 3/31 天 · 待打卡</span>
          </div>
          <button class="xy-btn xy-btn-primary" type="button">打卡这天</button>
        </li>
      </ul>
    </div>
  </div>
</div>`

/** 成长页（镜像 growth.ts）：等级英雄卡 + 统计（streak 强调卡、缺省「暂无」）+ 近30天柱图。 */
const GCOL = (mh: number, h: number, full = false): string =>
  `<button class="xy-growth-col${full ? ' xy-full' : ''}" type="button" aria-label="镜像柱">
     <div class="xy-growth-stack">${mh > 0 ? `<div class="xy-growth-missed" style="height:${mh}%"></div>` : ''}<div class="xy-growth-bar" style="height:${h}%"></div></div>
   </button>`

const GTICK = (left: number, align: string, label: string): string =>
  `<span class="xy-growth-tick" style="left:${left}%;transform:translateX(${align})">${label}</span>`

const growthSection = `
<div class="xy-page">
  <div class="xy-hero" style="background:linear-gradient(135deg, #1c4bb3, #2563eb)">
    <div class="xy-herobadge" style="background:#2563eb">Lv.4</div>
    <div class="xy-heromain">
      <div class="xy-meta xy-onhero">当前等级</div>
      <h2 class="xy-herotitle">Lv.4 · 坚持者</h2>
      <div class="xy-bar xy-bar-onhero"><div class="xy-bar-fill xy-bar-fill-solid" style="transform:scaleX(.66)"></div></div>
      <div class="xy-meta xy-onhero">660 / 1000 EXP</div>
    </div>
  </div>
  <div class="xy-meta xy-heroreward">当前等级权益：解锁高级教练风格</div>
  <div class="xy-stats">
    <div class="xy-statcard"><div class="xy-statnum">42</div><div class="xy-meta">累计打卡天数</div></div>
    <div class="xy-statcard xy-statcard-hot"><div class="xy-statnum">6</div><div class="xy-meta">连续坚持</div></div>
    <div class="xy-statcard"><div class="xy-statnum">13</div><div class="xy-meta">最长连续坚持</div></div>
    <div class="xy-statcard"><div class="xy-statnum">3</div><div class="xy-meta">累计愿望</div></div>
    <div class="xy-statcard"><div class="xy-statnum">1</div><div class="xy-meta">已实现愿望</div></div>
    <div class="xy-statcard xy-statcard-muted"><div class="xy-statnum">暂无</div><div class="xy-meta">累计任务</div></div>
    <div class="xy-statcard xy-statcard-muted"><div class="xy-statnum">暂无</div><div class="xy-meta">已达成任务</div></div>
  </div>
  <h3 class="xy-section-title">近 30 天打卡</h3>
  <div class="xy-panel">
    <div class="xy-tip" role="status"></div>
    <div class="xy-growth">
      ${GCOL(0, 30)}${GCOL(0, 55)}${GCOL(22, 40)}${GCOL(0, 70)}${GCOL(0, 45)}${GCOL(18, 60)}${GCOL(0, 80)}
      ${GCOL(0, 35)}${GCOL(0, 65)}${GCOL(0, 50)}${GCOL(25, 30)}${GCOL(0, 75)}${GCOL(0, 58)}${GCOL(0, 88, true)}
    </div>
    <div class="xy-growth-axis">
      ${GTICK(0, '0%', '8/3')}${GTICK(50, '-50%', '8/17')}${GTICK(100, '-100%', '8/27')}
    </div>
    <div class="xy-legend">
      <span><i class="xy-dot xy-dot-checked" aria-hidden="true"></i>已打卡</span>
      <span><i class="xy-dot xy-dot-gap" aria-hidden="true"></i>未完成缺口</span>
      <span class="xy-meta">蓝色为已打卡，斜纹为当日未完成缺口，绿色柱为全勤日；悬停或聚焦柱子可看逐日明细。</span>
    </div>
  </div>
  <h3 class="xy-section-title">等级说明</h3>
  <div class="xy-levels">
    <div class="xy-levelrow xy-levelhit"><span class="xy-lvnum" style="background:#2563eb;color:#fff">Lv.4</span><span class="xy-lvname">坚持者</span><span class="xy-meta">需要 600 经验</span><span class="xy-meta xy-lvreward">✓ 解锁高级教练风格</span></div>
    <div class="xy-levelrow"><span class="xy-lvnum">Lv.5</span><span class="xy-lvname">奋斗者</span><span class="xy-meta">需要 1000 经验</span><span class="xy-meta xy-lvreward">获得专属徽章</span></div>
  </div>
</div>`

/** 记忆页（镜像 memory.ts）：撰写卡 + 搜索行 + 分组列表（编辑/删除图标幽灵键）。 */
const MEMROW = (high: boolean, key: string, value: string, cat: string, imp: string, date: string): string => `
  <li class="xy-grouprow">
    <div class="xy-rowmain">
      <span class="xy-rowtitle">${high ? '<span class="xy-star-hi" aria-hidden="true">★</span>' : ''}${key}</span>
      <span class="xy-meta">${value}</span>
      <span class="xy-meta">${cat} · 重要度 ${imp} · ${date}</span>
    </div>
    <div class="xy-memactions">
      <button class="xy-btn xy-btn-icon" type="button" aria-label="编辑 · ${key}" title="编辑">${ICON_EDIT}</button>
      <button class="xy-btn xy-btn-danger xy-btn-icon" type="button" aria-label="删除 · ${key}" title="删除">${ICON_TRASH}</button>
    </div>
  </li>`

const memorySection = `
<div class="xy-page">
  <div class="xy-page-head">
    <h2 class="xy-page-title">记忆</h2>
    <span class="xy-meta">共 128 条 · 对话时按上限自动注入</span>
  </div>
  <div class="xy-compose">
    <input class="xy-input xy-input-grow" placeholder="键名（如：生日）" aria-label="键名" name="memory-key">
    <input class="xy-input xy-input-grow" placeholder="内容（如：3 月 5 日）" aria-label="内容" name="memory-value">
    <select class="xy-input" aria-label="分类" name="memory-category"><option>个人</option><option selected>其他</option></select>
    <select class="xy-input" aria-label="重要度" name="memory-importance"><option selected>中</option><option>高</option><option>低</option></select>
    <button class="xy-btn xy-btn-primary" type="button">＋ 添加</button>
  </div>
  <div class="xy-membar">
    <input type="search" class="xy-input xy-input-search" placeholder="搜索键名或内容…" aria-label="搜索键名或内容" name="memory-search">
  </div>
  <section class="xy-group">
    <ul class="xy-grouplist">
      ${MEMROW(true, '生日', '3 月 5 日，喜欢手工礼物多于贵重物品', '个人', '高', '2026年7月2日')}
      ${MEMROW(false, '咖啡口味', '拿铁少糖，下午两点后不喝咖啡因', '偏好', '中', '2026年7月18日')}
      ${MEMROW(false, '跑鞋尺码', '43 码，宽楦', '事件', '低', '2026年8月11日')}
    </ul>
  </section>
  <div class="xy-memfoot">
    <button class="xy-btn xy-btn-danger" type="button">清空全部记忆</button>
    <span class="xy-meta">删除与清空不可恢复；注入条数上限在 设置 → 星愿 调整。</span>
  </div>
</div>`

/** 设置页（镜像 settings.ts）：五分节面板卡；开关/枚举类设置用 row 行语法
 * （标签+说明在左、控件在右，行间 hairline），画像保持 label 在上的表单纵排；
 * 写操作确认独立成卡（总开关行 + 类目行列表 + 锁定行「始终开启」徽章）。 */
const settingsSection = `
<div class="xy-page">
  <div class="xy-settings">
    <section class="xy-panel">
      <h3 class="xy-panel-head">教练风格</h3>
      <div class="xy-seg" role="group" aria-label="教练风格">
        <button class="xy-seg-btn" type="button" aria-pressed="false">温柔型</button>
        <button class="xy-seg-btn xy-on" type="button" aria-pressed="true">严格型</button>
        <button class="xy-seg-btn" type="button" aria-pressed="false">幽默型</button>
      </div>
      <p class="xy-hint">决定对话语气与人设，也可在对话中说「对我严格一点」。</p>
    </section>
    <section class="xy-panel">
      <h3 class="xy-panel-head">昵称与画像</h3>
      <label class="xy-field"><span class="xy-quick-label">昵称</span><input class="xy-input xy-input-wide" placeholder="希望被怎么称呼" name="xy-nickname"></label>
      <label class="xy-field"><span class="xy-quick-label">职业</span><input class="xy-input xy-input-wide" placeholder="如：教师、产品经理" name="xy-occupation"></label>
      <label class="xy-field"><span class="xy-quick-label">兴趣</span><input class="xy-input xy-input-wide" placeholder="如：阅读、跑步" name="xy-interests"></label>
      <div class="xy-save-row">
        <button class="xy-btn xy-btn-primary" type="button">保存画像</button>
        <span class="xy-saved" role="status"><span aria-hidden="true">✓ </span>画像已保存</span>
      </div>
      <p class="xy-hint">留空的字段会被清除；画像与对话侧共享，对话里说「叫我小星」也会更新。</p>
    </section>
    <section class="xy-panel">
      <h3 class="xy-panel-head">写操作确认</h3>
      <label class="xy-setrow">
        <span class="xy-setrow-main"><span class="xy-setrow-label">总开关</span><span class="xy-setrow-desc">开启后按下方类目决定是否弹确认卡；关闭后除删除（始终确认）外一律直接执行。</span></span>
        <input type="checkbox" class="xy-toggle" name="confirmWrites" checked>
      </label>
      <div class="xy-confirm-ops" role="group" aria-label="确认类目">
        <span class="xy-op-group-head">确认类目</span>
        <div class="xy-setrows">
          <label class="xy-setrow"><span class="xy-setrow-main"><span class="xy-setrow-label">创建愿望/任务（含微行动拆解）</span></span><input type="checkbox" class="xy-toggle" name="confirmOps.create" checked></label>
          <label class="xy-setrow"><span class="xy-setrow-main"><span class="xy-setrow-label">打卡</span></span><input type="checkbox" class="xy-toggle" name="confirmOps.checkin" checked></label>
          <label class="xy-setrow"><span class="xy-setrow-main"><span class="xy-setrow-label">取消打卡</span></span><input type="checkbox" class="xy-toggle" name="confirmOps.cancelCheckin" checked></label>
          <label class="xy-setrow"><span class="xy-setrow-main"><span class="xy-setrow-label">领取任务</span></span><input type="checkbox" class="xy-toggle" name="confirmOps.claim"></label>
          <label class="xy-setrow"><span class="xy-setrow-main"><span class="xy-setrow-label">修改愿望/任务/分类</span></span><input type="checkbox" class="xy-toggle" name="confirmOps.update"></label>
          <label class="xy-setrow"><span class="xy-setrow-main"><span class="xy-setrow-label">保存记忆</span></span><input type="checkbox" class="xy-toggle" name="confirmOps.memorySave"></label>
          <div class="xy-setrow"><span class="xy-setrow-main"><span class="xy-setrow-label">删除（含批量、微行动重开）</span><span class="xy-setrow-desc">始终确认，不可关闭：删除不可恢复。</span></span><span class="xy-locked">始终开启</span></div>
        </div>
      </div>
      <span class="xy-hint">类目明细在总开关开启时生效；默认与之前版本一致。</span>
    </section>
    <section class="xy-panel">
      <h3 class="xy-panel-head">对话偏好</h3>
      <div class="xy-setrows">
        <label class="xy-setrow">
          <span class="xy-setrow-main"><span class="xy-setrow-label">记忆注入上限</span><span class="xy-setrow-desc">每次对话自动注入上下文的记忆条数上限（5-200，默认 40）；失焦后保存。</span></span>
          <input type="number" min="5" max="200" class="xy-input xy-input-num" name="memoryInjectLimit" inputmode="numeric" value="40">
        </label>
        <div class="xy-setrow">
          <span class="xy-setrow-main"><span class="xy-setrow-label">确认卡语言</span><span class="xy-setrow-desc">对话中写操作确认卡与问题的显示语言。确认卡无法自动跟随界面语言，需在此选择；默认中文。</span></span>
          <span class="xy-seg" role="group" aria-label="确认卡语言"><button class="xy-seg-btn xy-on" type="button" aria-pressed="true">中文</button><button class="xy-seg-btn" type="button" aria-pressed="false">English</button></span>
        </div>
      </div>
    </section>
    <section class="xy-panel">
      <h3 class="xy-panel-head">标签页显示</h3>
      <div class="xy-seg" role="group" aria-label="标签页显示">
        <button class="xy-seg-btn xy-on" type="button" aria-pressed="true">跟随会话</button>
        <button class="xy-seg-btn" type="button" aria-pressed="false">始终显示</button>
        <button class="xy-seg-btn" type="button" aria-pressed="false">始终隐藏</button>
      </div>
      <div class="xy-seg" role="group" aria-label="显示的标签页">
        <button class="xy-seg-btn xy-on" type="button" aria-pressed="true"><span aria-hidden="true">✓ </span>今日</button>
        <button class="xy-seg-btn xy-on" type="button" aria-pressed="true"><span aria-hidden="true">✓ </span>愿望</button>
        <button class="xy-seg-btn" type="button" aria-pressed="false">任务</button>
        <button class="xy-seg-btn xy-on" type="button" aria-pressed="true"><span aria-hidden="true">✓ </span>日历</button>
        <button class="xy-seg-btn xy-on" type="button" aria-pressed="true"><span aria-hidden="true">✓ </span>成长</button>
        <button class="xy-seg-btn xy-on" type="button" aria-pressed="true"><span aria-hidden="true">✓ </span>记忆</button>
      </div>
      <p class="xy-hint">跟随会话：仅星愿预设的会话显示标签页；其他会话自动隐藏。可单独勾选/取消各标签。</p>
    </section>
    <p class="xy-hint">业务数据存于本机 ~/.dsh/xingyuan/，备份即拷贝该目录。</p>
  </div>
</div>`

/** 快速新建（镜像 quick-create.ts）：虚线可书写面板 + 字段纵排标签。 */
const quickSection = `
<div class="xy-page">
  <form class="xy-quick">
    <span class="xy-meta">轻量表单适合简单记录；需要 AI 推荐拆解、微行动规划请直接对话描述。</span>
    <div class="xy-quick-row">
      <label class="xy-quick-field">
        <span class="xy-quick-label">任务名称</span>
        <input class="xy-input" maxlength="100" name="task-name" placeholder="要养成的习惯（如：每天背 20 个单词）">
      </label>
      <label class="xy-quick-field">
        <span class="xy-quick-label">重复周期</span>
        <select class="xy-input" name="task-cycle"><option>仅一次</option><option selected>每日</option><option>每周</option><option>每月</option></select>
      </label>
      <label class="xy-quick-field">
        <span class="xy-quick-label">截止日期（可选）</span>
        <input type="date" class="xy-input" name="task-due">
      </label>
    </div>
    <div class="xy-quick-actions"><button type="submit" class="xy-btn xy-btn-primary">创建</button></div>
  </form>
</div>`

/** 空态/错误态（镜像 ui.ts 的 PageEmpty / PageError）：纯文字版式。
 * 历史坑：旧版带 SVG 线稿插画，描边色依赖新式 CSS 取色函数在不支持的浏览器里
 * 整稿隐形、只剩 accent 点缀孤点——本场景同时陈列危险按钮（兼容令牌描边）
 * 供双主题核对。 */
const emptySection = `
<div class="xy-page">
  <div class="xy-page-center">
    <div class="xy-empty-title">还没有愿望</div>
    <div class="xy-meta xy-empty-hint">告诉我最想实现什么，我来帮你拆解成可坚持的计划。</div>
  </div>
</div>
<div class="xy-page">
  <div class="xy-page-center">
    <div class="xy-empty-title">还没有任务</div>
    <div class="xy-meta xy-empty-hint">告诉我你想养成的习惯，或从「愿望」页开始规划。</div>
  </div>
</div>
<div class="xy-page">
  <div class="xy-page-center">
    <div class="xy-empty-title">加载失败：服务暂不可用</div>
    <button class="xy-btn" type="button">重试</button>
  </div>
  <div style="display:flex;gap:10px;justify-content:center;padding:10px 0 22px">
    <button class="xy-btn xy-btn-danger" type="button">删除愿望</button>
    <button class="xy-btn xy-btn-primary" type="button">＋ 新建愿望</button>
  </div>
</div>`

const html = (dark: boolean): string => `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>[视觉 mock] 星愿视图样式核对（${dark ? 'dark' : 'light'}）</title>
<style>
  body{margin:0;${dark ? 'background:#141a22;' : SHELL_LIGHT}font-family:system-ui,-apple-system,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif}
  ${dark ? `body[data-ds-dark-theme]{${SHELL_DARK}}` : ''}
  .xy-page{background:var(--dsw-alias-bg-layer-1);margin-bottom:26px}
</style>
<style>${STYLE_TEXT}</style>
</head>
<body${dark ? ' data-ds-dark-theme' : ''}>
  <h1 style="color:var(--dsw-alias-label-primary);font-size:14px;padding:12px 20px 0">日历页</h1>
  ${calSection}
  <h1 style="color:var(--dsw-alias-label-primary);font-size:14px;padding:12px 20px 0">今日页</h1>
  ${todaySection}
  <h1 style="color:var(--dsw-alias-label-primary);font-size:14px;padding:12px 20px 0">愿望页 · 任务区披露（默认收起 / 展开态）+ 卡内展开详情（周对齐打卡网格 / 图标删除键）</h1>
  ${wishSection}
  <h1 style="color:var(--dsw-alias-label-primary);font-size:14px;padding:12px 20px 0">任务页 · 分组卡展开详情（已完结行保留状态词）</h1>
  ${tasksSection}
  <h1 style="color:var(--dsw-alias-label-primary);font-size:14px;padding:12px 20px 0">成长页</h1>
  ${growthSection}
  <h1 style="color:var(--dsw-alias-label-primary);font-size:14px;padding:12px 20px 0">记忆页</h1>
  ${memorySection}
  <h1 style="color:var(--dsw-alias-label-primary);font-size:14px;padding:12px 20px 0">设置页</h1>
  ${settingsSection}
  <h1 style="color:var(--dsw-alias-label-primary);font-size:14px;padding:12px 20px 0">快速新建 · 任务轻表单</h1>
  ${quickSection}
  <h1 style="color:var(--dsw-alias-label-primary);font-size:14px;padding:12px 20px 0">空态 / 错误态 / 危险按钮（纯文字版式 + 兼容令牌描边）</h1>
  ${emptySection}
</body>
</html>`

for (const dark of [true, false]) {
  const out = fileURLToPath(new URL(`./ui-mock${dark ? '' : '-light'}.html`, import.meta.url))
  writeFileSync(out, html(dark), 'utf8')
  console.log(`written: ${out} (${html(dark).length} bytes)`)
}
