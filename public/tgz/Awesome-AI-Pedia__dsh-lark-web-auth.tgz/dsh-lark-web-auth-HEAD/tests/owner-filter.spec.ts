/**
 * Owner-filter tests — the monkey-patch on `apiProxy.sessions` that hides
 * cross-owner data. Verifies:
 *   - list is filtered to only the caller's sessions
 *   - unauthenticated list returns empty items
 *   - owned methods (history/prompt/rename/…) 404 on non-owner access
 *   - dispose restores original method references
 */

import { describe, it, expect, beforeEach, vi } from "vitest";
import Database from "better-sqlite3";
import { createOwnerStore } from "../src/owner-store.ts";
import { installOwnerFilters, type PatchableApiProxy } from "../src/owner-filter.ts";
import { runWithAuth } from "../src/middleware.ts";
import type { Db } from "../src/db.ts";

function memDb(): Db {
	const raw = new Database(":memory:");
	raw.exec(`
		CREATE TABLE session_owner (session_id TEXT PRIMARY KEY, open_id TEXT NOT NULL,
			source TEXT NOT NULL, created_at INTEGER NOT NULL);
	`);
	return { raw, close: () => raw.close() };
}

/** Build a minimal PatchableApiProxy stub with recording spies. */
function mockApi(): {
	api: PatchableApiProxy;
	originalList: ReturnType<typeof vi.fn>;
	originalHistory: ReturnType<typeof vi.fn>;
	originalPrompt: ReturnType<typeof vi.fn>;
	originalCreate: ReturnType<typeof vi.fn>;
	originalHostEvents: ReturnType<typeof vi.fn>;
	originalMuxEvents: ReturnType<typeof vi.fn>;
} {
	const originalList = vi.fn(async (req: { rpcId?: unknown }) => ({
		rpcId: req.rpcId,
		result: {
			ok: true,
			value: {
				items: [
					{ sessionId: "s1", title: "A" },
					{ sessionId: "s2", title: "B" },
					{ sessionId: "s3", title: "C" },
				],
			},
		},
	}));
	const originalHistory = vi.fn(async (req: { rpcId?: unknown; payload?: { sessionId?: unknown } }) => ({
		rpcId: req.rpcId,
		result: { ok: true, value: { events: [], sessionId: req.payload?.sessionId } },
	}));
	const originalPrompt = vi.fn(async (req: { rpcId?: unknown; payload?: { sessionId?: unknown } }) => ({
		rpcId: req.rpcId,
		result: { ok: true, value: { accepted: true, sessionId: req.payload?.sessionId } },
	}));
	const originalCreate = vi.fn(async (req: { rpcId?: unknown }) => ({
		rpcId: req.rpcId,
		result: { ok: true, value: { sessionId: "s-created" } },
	}));
	const originalHostEvents = vi.fn((_req?: unknown) =>
		frames([
			{ payload: { type: "host/session-added", sessionId: "s1" } },
			{ payload: { type: "host/session-added", sessionId: "s2" } },
			{ payload: { type: "host/status", status: "ready" } },
		])
	);
	const originalMuxEvents = vi.fn((_req?: unknown) =>
		frames([
			{ payload: { type: "session/event", sessionId: "s1", event: "owned" } },
			{ payload: { type: "session/event", sessionId: "s2", event: "foreign" } },
			{ payload: { type: "inventory/updated" } },
		])
	);
	const api: PatchableApiProxy = {
		sessions: { list: originalList, history: originalHistory, prompt: originalPrompt, create: originalCreate },
		events: { host: originalHostEvents, mux: originalMuxEvents },
	};
	return { api, originalList, originalHistory, originalPrompt, originalCreate, originalHostEvents, originalMuxEvents };
}

async function* frames(items: unknown[]): AsyncIterable<unknown> {
	for (const item of items) yield item;
}

async function collect(iterable: AsyncIterable<unknown> | Promise<AsyncIterable<unknown>>): Promise<unknown[]> {
	const out: unknown[] = [];
	for await (const item of await iterable) out.push(item);
	return out;
}

describe("owner-filter", () => {
	let db: Db;
	beforeEach(() => {
		db = memDb();
	});

	it("list keeps only sessions owned by caller", async () => {
		const owners = createOwnerStore(db);
		owners.claim("s1", "ou_alice", "web", 1);
		owners.claim("s2", "ou_bob", "web", 2);
		owners.claim("s3", "ou_alice", "web", 3);
		const { api } = mockApi();
		installOwnerFilters(api, owners);
		const result = await runWithAuth({ openId: "ou_alice", name: "Alice" }, () =>
			api.sessions.list({ rpcId: "rpc-1" }),
		);
		const items = (result as {
			result: { value: { items: Array<{ sessionId: string }> } };
		}).result.value.items;
		expect(items.map((i) => i.sessionId).sort()).toEqual(["s1", "s3"]);
	});

	it("list returns empty items when unauthenticated", async () => {
		const owners = createOwnerStore(db);
		owners.claim("s1", "ou_alice", "web", 1);
		const { api } = mockApi();
		installOwnerFilters(api, owners);
		const result = await api.sessions.list({ rpcId: "rpc-42" });
		expect((result as { result: { value: { items: unknown[] } } }).result.value.items).toEqual([]);
	});

	it("history 404s when caller does not own the sessionId", async () => {
		const owners = createOwnerStore(db);
		owners.claim("s1", "ou_alice", "web", 1);
		const { api } = mockApi();
		installOwnerFilters(api, owners);
		const res = await runWithAuth({ openId: "ou_bob", name: "Bob" }, () =>
			api.sessions.history!({ rpcId: "rpc-7", payload: { sessionId: "s1" } }),
		);
		expect((res as { result: { error: { code: string } } }).result.error.code).toBe("session-not-found");
	});

	it("history delegates to original when caller owns the sessionId", async () => {
		const owners = createOwnerStore(db);
		owners.claim("s1", "ou_alice", "web", 1);
		const { api, originalHistory } = mockApi();
		installOwnerFilters(api, owners);
		await runWithAuth({ openId: "ou_alice", name: "Alice" }, () =>
			api.sessions.history!({ rpcId: "rpc-8", payload: { sessionId: "s1" } }),
		);
		expect(originalHistory).toHaveBeenCalledWith({ rpcId: "rpc-8", payload: { sessionId: "s1" } });
	});

	it("list exposes only the newest lark-link session per p2p chat", async () => {
		const owners = createOwnerStore(db);
		const oldId = "lark-link:dm:oc_chat:oldnonce:0";
		const newId = "lark-link:dm:oc_chat:newnonce:0";
		owners.claim(oldId, "ou_alice", "backfill", 1);
		owners.claim(newId, "ou_alice", "backfill", 2);
		const { api, originalList } = mockApi();
		originalList.mockResolvedValueOnce({
			rpcId: "rpc-dedupe",
			result: {
				ok: true,
				value: {
					items: [
						{ sessionId: newId, title: "New" },
						{ sessionId: oldId, title: "Old" },
					],
				},
			},
		});
		installOwnerFilters(api, owners);

		const result = await runWithAuth({ openId: "ou_alice", name: "Alice" }, () =>
			api.sessions.list({ rpcId: "rpc-dedupe" }),
		);

		const items = (result as {
			result: { value: { items: Array<{ sessionId: string }> } };
		}).result.value.items;
		expect(items.map((i) => i.sessionId)).toEqual([newId]);
	});

	it("owned methods rewrite stale lark-link session ids to the newest session for that chat", async () => {
		const owners = createOwnerStore(db);
		const oldId = "lark-link:dm:oc_chat:oldnonce:0";
		const newId = "lark-link:dm:oc_chat:newnonce:0";
		owners.claim(oldId, "ou_alice", "backfill", 1);
		owners.claim(newId, "ou_alice", "backfill", 2);
		const { api, originalList, originalPrompt } = mockApi();
		originalList.mockResolvedValue({
			rpcId: "rpc-list",
			result: {
				ok: true,
				value: {
					items: [
						{ sessionId: newId, title: "New" },
						{ sessionId: oldId, title: "Old" },
					],
				},
			},
		});
		installOwnerFilters(api, owners);

		await runWithAuth({ openId: "ou_alice", name: "Alice" }, () =>
			api.sessions.prompt!({ rpcId: "rpc-prompt", payload: { sessionId: oldId } }),
		);

		expect(originalPrompt).toHaveBeenCalledWith({ rpcId: "rpc-prompt", payload: { sessionId: newId } });
	});

	it("history 404s for unauthenticated caller (never leaks existence)", async () => {
		const owners = createOwnerStore(db);
		owners.claim("s1", "ou_alice", "web", 1);
		const { api } = mockApi();
		installOwnerFilters(api, owners);
		const res = await api.sessions.history!({ rpcId: "rpc-9", payload: { sessionId: "s1" } });
		expect((res as { result: { error: { code: string } } }).result.error.code).toBe("session-not-found");
	});

	it("create claims the returned session for the authenticated caller", async () => {
		const owners = createOwnerStore(db);
		const { api } = mockApi();
		installOwnerFilters(api, owners);
		await runWithAuth({ openId: "ou_alice", name: "Alice" }, () =>
			api.sessions.create!({ rpcId: "rpc-create", payload: {} }),
		);
		expect(owners.ownerOf("s-created")).toBe("ou_alice");
	});

	it("host events hide session-added frames for sessions the caller does not own", async () => {
		const owners = createOwnerStore(db);
		owners.claim("s1", "ou_alice", "web", 1);
		owners.claim("s2", "ou_bob", "web", 2);
		const { api } = mockApi();
		installOwnerFilters(api, owners);

		const result = await runWithAuth({ openId: "ou_alice", name: "Alice" }, () =>
			collect(api.events!.host!({})),
		);

		expect(result).toEqual([
			{ payload: { type: "host/session-added", sessionId: "s1" } },
			{ payload: { type: "host/status", status: "ready" } },
		]);
	});

	it("mux events hide session-scoped frames for sessions the caller does not own", async () => {
		const owners = createOwnerStore(db);
		owners.claim("s1", "ou_alice", "web", 1);
		owners.claim("s2", "ou_bob", "web", 2);
		const { api } = mockApi();
		installOwnerFilters(api, owners);

		const result = await runWithAuth({ openId: "ou_alice", name: "Alice" }, () =>
			collect(api.events!.mux!({})),
		);

		expect(result).toEqual([
			{ payload: { type: "session/event", sessionId: "s1", event: "owned" } },
			{ payload: { type: "inventory/updated" } },
		]);
	});

	it("host events wait for a newly-created session to be claimed before filtering it", async () => {
		const owners = createOwnerStore(db);
		const { api, originalHostEvents } = mockApi();
		originalHostEvents.mockReturnValueOnce(frames([
			{ payload: { type: "host/session-added", sessionId: "s-late" } },
		]));
		installOwnerFilters(api, owners);

		const resultPromise = runWithAuth({ openId: "ou_alice", name: "Alice" }, () =>
			collect(api.events!.host!({})),
		);
		setTimeout(() => owners.claim("s-late", "ou_alice", "lark-bot", 1), 10);

		await expect(resultPromise).resolves.toEqual([
			{ payload: { type: "host/session-added", sessionId: "s-late" } },
		]);
	});

	it("dispose restores original method references", async () => {
		const owners = createOwnerStore(db);
		const { api, originalList, originalCreate, originalHostEvents, originalMuxEvents } = mockApi();
		const dispose = installOwnerFilters(api, owners);
		expect(api.sessions.list).not.toBe(originalList);
		expect(api.sessions.create).not.toBe(originalCreate);
		expect(api.events!.host).not.toBe(originalHostEvents);
		expect(api.events!.mux).not.toBe(originalMuxEvents);
		dispose();
		expect(api.sessions.list).toBe(originalList);
		expect(api.sessions.create).toBe(originalCreate);
		expect(api.events!.host).toBe(originalHostEvents);
		expect(api.events!.mux).toBe(originalMuxEvents);
	});
});
