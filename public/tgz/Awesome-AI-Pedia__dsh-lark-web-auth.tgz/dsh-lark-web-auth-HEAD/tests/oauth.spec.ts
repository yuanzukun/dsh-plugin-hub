/**
 * OAuth handler tests — full flow against a mock Lark API. Verifies:
 *   - login redirect creates a state row and 302s to Feishu
 *   - callback rejects missing/invalid state
 *   - callback on success sets an httpOnly cookie and 302s to return_to
 *   - callback rejects Feishu errors with a 502
 *   - logout clears the cookie and deletes the row
 *   - /me returns 401 without cookie, 200 with valid cookie
 *   - safeReturnTo rejects open-redirect attempts
 */

import { describe, it, expect, beforeEach, vi } from "vitest";
import { IncomingMessage, ServerResponse } from "node:http";
import { Socket } from "node:net";
import { createOAuthHandlers, COOKIE_NAME } from "../src/oauth.ts";
import type { LarkClient } from "../src/lark-api.ts";
import type { SessionStore } from "../src/session-store.ts";
import type { AuthConfig } from "../src/types.ts";

// -- test doubles ----------------------------------------------------------

function makeReq(url: string, headers: Record<string, string> = {}): IncomingMessage {
	const req = new IncomingMessage(new Socket());
	req.url = url;
	req.method = "GET";
	req.headers = headers;
	return req;
}

interface CapturedRes {
	res: ServerResponse;
	statusCode(): number;
	body(): string;
	headers(): Record<string, string | string[] | number | undefined>;
}

function makeRes(): CapturedRes {
	const chunks: Buffer[] = [];
	// Build a minimal req to construct ServerResponse.
	const req = new IncomingMessage(new Socket());
	const res = new ServerResponse(req);
	const origWrite = res.write.bind(res);
	res.write = ((chunk: string | Buffer, ...rest: unknown[]) => {
		chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
		return origWrite(chunk as string, ...(rest as [never]));
	}) as typeof res.write;
	const origEnd = res.end.bind(res);
	res.end = ((chunk?: string | Buffer, ...rest: unknown[]) => {
		if (chunk) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk)));
		return origEnd(chunk as string, ...(rest as [never]));
	}) as typeof res.end;
	return {
		res,
		statusCode: () => res.statusCode,
		body: () => Buffer.concat(chunks).toString("utf8"),
		headers: () => res.getHeaders(),
	};
}

// -- mocks -----------------------------------------------------------------

function mockStore(): SessionStore {
	const oauthStates = new Map<string, { returnTo: string; createdAt: number }>();
	const logins = new Map<string, { openId: string; name: string; avatarUrl: string; createdAt: number; expiresAt: number }>();
	return {
		create: vi.fn((user, ttl, now) => {
			const t = `tok-${logins.size + 1}`;
			logins.set(t, { openId: user.openId, name: user.name, avatarUrl: user.avatarUrl, createdAt: now, expiresAt: now + ttl });
			return t;
		}),
		find: vi.fn((t, now) => {
			const l = logins.get(t);
			if (!l || l.expiresAt <= now) return undefined;
			return { token: t, openId: l.openId, name: l.name, avatarUrl: l.avatarUrl, createdAt: l.createdAt, expiresAt: l.expiresAt };
		}),
		revoke: vi.fn((t) => { logins.delete(t); }),
		gcExpired: vi.fn(() => 0),
		createOAuthState: vi.fn((returnTo, now) => {
			const s = `state-${oauthStates.size + 1}`;
			oauthStates.set(s, { returnTo, createdAt: now });
			return s;
		}),
		consumeOAuthState: vi.fn((s, _now) => {
			const row = oauthStates.get(s);
			if (!row) return undefined;
			oauthStates.delete(s);
			return { state: s, returnTo: row.returnTo, createdAt: row.createdAt };
		}),
		gcOAuthStates: vi.fn(() => 0),
	};
}

function mockLark(): LarkClient {
	return {
		authorizeUrl: vi.fn((redirect, state) => `https://passport.example/authorize?redirect_uri=${encodeURIComponent(redirect)}&state=${state}`),
		exchangeCode: vi.fn(async () => ({ userAccessToken: "user-access-1", expiresIn: 7200 })),
		userInfo: vi.fn(async () => ({ openId: "ou_alice", name: "Alice", avatarUrl: "http://a" })),
		openIdForP2pChat: vi.fn(async () => undefined),
	};
}

const cfg: AuthConfig = {
	enabled: true,
	appId: "cli_x",
	appSecret: "sec_x",
	publicBaseUrl: "https://web.example.com",
	cookieSecret: "0123456789abcdef0123456789abcdef",
	dbPath: ":memory:",
	cookieTtlDays: 7,
	domain: "feishu",
};

// -- tests -----------------------------------------------------------------

describe("oauth handlers", () => {
	let store: SessionStore;
	let lark: LarkClient;
	let handlers: ReturnType<typeof createOAuthHandlers>;

	beforeEach(() => {
		store = mockStore();
		lark = mockLark();
		handlers = createOAuthHandlers({ config: cfg, store, lark, now: () => 1_000_000 });
	});

	it("login → 302 to authorize URL with state", () => {
		const req = makeReq("/auth/lark/login");
		const cap = makeRes();
		handlers.loginRedirect(req, cap.res);
		expect(cap.statusCode()).toBe(302);
		const loc = cap.headers().location as string;
		expect(loc).toContain("passport.example/authorize");
		expect(loc).toContain("state=state-1");
		expect(loc).toContain("redirect_uri=");
	});

	it("login preserves return_to when safe", () => {
		const req = makeReq("/auth/lark/login?return_to=%2Fdashboard");
		const cap = makeRes();
		handlers.loginRedirect(req, cap.res);
		// State-1 was created with returnTo=/dashboard — verify via callback.
		expect((store.createOAuthState as ReturnType<typeof vi.fn>).mock.calls[0]?.[0]).toBe("/dashboard");
	});

	it("login rejects unsafe return_to (open-redirect)", () => {
		const req = makeReq("/auth/lark/login?return_to=https%3A%2F%2Fevil.com");
		const cap = makeRes();
		handlers.loginRedirect(req, cap.res);
		expect((store.createOAuthState as ReturnType<typeof vi.fn>).mock.calls[0]?.[0]).toBe("/");
	});

	it("login rejects protocol-relative return_to (//host)", () => {
		const req = makeReq("/auth/lark/login?return_to=%2F%2Fevil.com");
		const cap = makeRes();
		handlers.loginRedirect(req, cap.res);
		expect((store.createOAuthState as ReturnType<typeof vi.fn>).mock.calls[0]?.[0]).toBe("/");
	});

	it("callback happy path: sets cookie, 302 to return_to", async () => {
		// Seed a state.
		store.createOAuthState("/home", 1_000_000);
		const req = makeReq("/auth/lark/callback?code=abc&state=state-1");
		const cap = makeRes();
		await handlers.callback(req, cap.res);
		expect(cap.statusCode()).toBe(302);
		expect(cap.headers().location).toBe("/home");
		const setCookie = cap.headers()["set-cookie"];
		const cookieStr = Array.isArray(setCookie) ? setCookie.join("; ") : String(setCookie);
		expect(cookieStr).toContain(COOKIE_NAME);
		expect(cookieStr).toContain("HttpOnly");
		expect(cookieStr).toContain("Secure");
		expect(cookieStr).toContain("SameSite=Lax");
	});

	it("callback rejects missing code/state with 400", async () => {
		const req = makeReq("/auth/lark/callback?code=abc");
		const cap = makeRes();
		await handlers.callback(req, cap.res);
		expect(cap.statusCode()).toBe(400);
	});

	it("callback rejects invalid state with 400", async () => {
		const req = makeReq("/auth/lark/callback?code=abc&state=nonexistent");
		const cap = makeRes();
		await handlers.callback(req, cap.res);
		expect(cap.statusCode()).toBe(400);
		expect(cap.body()).toContain("invalid or expired state");
	});

	it("callback surfaces Feishu error param as 400", async () => {
		const req = makeReq("/auth/lark/callback?error=access_denied");
		const cap = makeRes();
		await handlers.callback(req, cap.res);
		expect(cap.statusCode()).toBe(400);
		expect(cap.body()).toContain("access_denied");
	});

	it("callback returns 502 when Lark API throws", async () => {
		store.createOAuthState("/", 1_000_000);
		(lark.exchangeCode as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error("network"));
		const req = makeReq("/auth/lark/callback?code=abc&state=state-1");
		const cap = makeRes();
		await handlers.callback(req, cap.res);
		expect(cap.statusCode()).toBe(502);
	});

	it("logout clears cookie and deletes session", () => {
		const req = makeReq("/auth/lark/logout", { cookie: `${COOKIE_NAME}=abc` });
		const cap = makeRes();
		handlers.logout(req, cap.res);
		expect(cap.statusCode()).toBe(204);
		expect(store.revoke).toHaveBeenCalledWith("abc");
		const setCookie = cap.headers()["set-cookie"];
		const cookieStr = Array.isArray(setCookie) ? setCookie.join("; ") : String(setCookie);
		expect(cookieStr).toContain("Max-Age=0");
	});

	it("/me returns 401 without cookie", () => {
		const req = makeReq("/auth/lark/me");
		const cap = makeRes();
		handlers.me(req, cap.res);
		expect(cap.statusCode()).toBe(401);
	});

	it("/me returns user info with a valid cookie", () => {
		// Seed a login the mock store already has.
		const t = store.create({ openId: "ou_alice", name: "Alice", avatarUrl: "http://a" }, 60_000, 1_000_000);
		const req = makeReq("/auth/lark/me", { cookie: `${COOKIE_NAME}=${t}` });
		const cap = makeRes();
		handlers.me(req, cap.res);
		expect(cap.statusCode()).toBe(200);
		const parsed = JSON.parse(cap.body()) as { openId: string; name: string };
		expect(parsed.openId).toBe("ou_alice");
		expect(parsed.name).toBe("Alice");
	});
});
