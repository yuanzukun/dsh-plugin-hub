/**
 * Store tests — session_store + owner_store + db migration.
 * Uses `:memory:` SQLite so no filesystem cleanup needed.
 */

import { describe, it, expect, beforeEach } from "vitest";
import Database from "better-sqlite3";
import type { Db } from "../src/db.ts";
import { createSessionStore, OAUTH_STATE_TTL_MS } from "../src/session-store.ts";
import { createOwnerStore } from "../src/owner-store.ts";

// Small helper — build an in-memory Db harness by inlining migrate step so we
// don't touch the disk-opening code path.
function memDb(): Db {
	const raw = new Database(":memory:");
	raw.pragma("journal_mode = MEMORY");
	// Copy migration DDL from db.ts — this test also guards the schema shape.
	raw.exec(`
		CREATE TABLE web_session (
			token TEXT PRIMARY KEY, open_id TEXT NOT NULL,
			name TEXT NOT NULL DEFAULT '', avatar_url TEXT NOT NULL DEFAULT '',
			created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
		);
		CREATE INDEX idx_web_session_open ON web_session(open_id);
		CREATE INDEX idx_web_session_expires ON web_session(expires_at);
		CREATE TABLE session_owner (
			session_id TEXT PRIMARY KEY, open_id TEXT NOT NULL,
			source TEXT NOT NULL, created_at INTEGER NOT NULL
		);
		CREATE INDEX idx_session_owner_user ON session_owner(open_id);
		CREATE TABLE oauth_state (
			state TEXT PRIMARY KEY, return_to TEXT NOT NULL DEFAULT '/',
			created_at INTEGER NOT NULL
		);
		CREATE INDEX idx_oauth_state_age ON oauth_state(created_at);
	`);
	return { raw, close: () => raw.close() };
}

describe("session-store", () => {
	let db: Db;
	beforeEach(() => {
		db = memDb();
	});

	it("creates and finds a login by token", () => {
		const store = createSessionStore(db);
		const t = store.create({ openId: "ou_a", name: "Alice", avatarUrl: "http://a" }, 60_000, 1_000);
		const row = store.find(t, 1_000);
		expect(row?.openId).toBe("ou_a");
		expect(row?.name).toBe("Alice");
	});

	it("returns undefined for an unknown token", () => {
		const store = createSessionStore(db);
		expect(store.find("nope", Date.now())).toBeUndefined();
	});

	it("treats an expired login as absent and deletes it", () => {
		const store = createSessionStore(db);
		const t = store.create({ openId: "ou_a", name: "Alice", avatarUrl: "" }, 1_000, 1_000);
		expect(store.find(t, 500)).toBeDefined();
		expect(store.find(t, 5_000)).toBeUndefined();
		// Second find is still undefined and doesn't crash.
		expect(store.find(t, 6_000)).toBeUndefined();
	});

	it("gcExpired removes only expired rows", () => {
		const store = createSessionStore(db);
		store.create({ openId: "ou_a", name: "", avatarUrl: "" }, 1_000, 1_000);
		store.create({ openId: "ou_b", name: "", avatarUrl: "" }, 10_000, 1_000);
		const removed = store.gcExpired(5_000);
		expect(removed).toBe(1);
	});

	it("revoke deletes the row", () => {
		const store = createSessionStore(db);
		const t = store.create({ openId: "ou_a", name: "", avatarUrl: "" }, 60_000, 1_000);
		store.revoke(t);
		expect(store.find(t, 1_000)).toBeUndefined();
	});

	it("consumeOAuthState returns the row once and rejects re-play", () => {
		const store = createSessionStore(db);
		const s = store.createOAuthState("/home", 1_000);
		const first = store.consumeOAuthState(s, 1_000);
		expect(first?.returnTo).toBe("/home");
		const second = store.consumeOAuthState(s, 1_000);
		expect(second).toBeUndefined();
	});

	it("consumeOAuthState treats an expired nonce as invalid AND deletes it", () => {
		const store = createSessionStore(db);
		const s = store.createOAuthState("/home", 1_000);
		const got = store.consumeOAuthState(s, 1_000 + OAUTH_STATE_TTL_MS + 1);
		expect(got).toBeUndefined();
		// Even a fresh-time consume returns undefined — the row is gone.
		expect(store.consumeOAuthState(s, 1_000)).toBeUndefined();
	});
});

describe("owner-store", () => {
	let db: Db;
	beforeEach(() => {
		db = memDb();
	});

	it("claim + ownerOf round-trips", () => {
		const store = createOwnerStore(db);
		store.claim("sess-1", "ou_a", "web", 100);
		expect(store.ownerOf("sess-1")).toBe("ou_a");
	});

	it("returns undefined for unknown sessionId", () => {
		const store = createOwnerStore(db);
		expect(store.ownerOf("nope")).toBeUndefined();
	});

	it("first claim wins — duplicate claim is silently ignored", () => {
		const store = createOwnerStore(db);
		store.claim("sess-1", "ou_a", "web", 100);
		store.claim("sess-1", "ou_b", "backfill", 200);
		expect(store.ownerOf("sess-1")).toBe("ou_a");
	});

	it("sessionsOf lists all ids for a user", () => {
		const store = createOwnerStore(db);
		store.claim("s1", "ou_a", "web", 1);
		store.claim("s2", "ou_a", "web", 2);
		store.claim("s3", "ou_b", "web", 3);
		expect(store.sessionsOf("ou_a").sort()).toEqual(["s1", "s2"]);
		expect(store.sessionsOf("ou_b")).toEqual(["s3"]);
	});

	it("count returns total rows", () => {
		const store = createOwnerStore(db);
		expect(store.count()).toBe(0);
		store.claim("s1", "ou_a", "web", 1);
		store.claim("s2", "ou_b", "web", 2);
		expect(store.count()).toBe(2);
	});
});
