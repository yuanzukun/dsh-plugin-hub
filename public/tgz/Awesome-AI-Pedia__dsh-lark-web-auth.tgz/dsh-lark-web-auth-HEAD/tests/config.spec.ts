/**
 * Unit tests for src/config.ts — env-driven config parsing and fail-fast
 * validation. No I/O.
 */

import { describe, it, expect } from "vitest";
import { parseConfig, ConfigError } from "../src/config.ts";

describe("parseConfig", () => {
	const valid = {
		enabled: true,
		appId: "cli_xxx",
		appSecret: "secret_yyy",
		publicBaseUrl: "https://web.example.com",
		cookieSecret: "0123456789abcdef0123456789abcdef",
		dbPath: "/tmp/test.sqlite",
		cookieTtlDays: 30,
		domain: "feishu",
	};

	it("accepts a fully-populated config", () => {
		const cfg = parseConfig(valid);
		expect(cfg.enabled).toBe(true);
		expect(cfg.appId).toBe("cli_xxx");
		expect(cfg.publicBaseUrl).toBe("https://web.example.com");
	});

	it("strips a trailing slash from publicBaseUrl", () => {
		const cfg = parseConfig({ ...valid, publicBaseUrl: "https://web.example.com///" });
		expect(cfg.publicBaseUrl).toBe("https://web.example.com");
	});

	it("returns a disabled shell without validating credentials when enabled=false", () => {
		const cfg = parseConfig({ enabled: false });
		expect(cfg.enabled).toBe(false);
		expect(cfg.appId).toBe("");
	});

	it("accepts 'true'/'false' strings for enabled (env-var path)", () => {
		expect(parseConfig({ ...valid, enabled: "true" }).enabled).toBe(true);
		expect(parseConfig({ ...valid, enabled: "false" }).enabled).toBe(false);
	});

	it("rejects empty appId", () => {
		expect(() => parseConfig({ ...valid, appId: "" })).toThrow(ConfigError);
	});

	it("rejects empty appSecret", () => {
		expect(() => parseConfig({ ...valid, appSecret: "" })).toThrow(ConfigError);
	});

	it("rejects publicBaseUrl without http(s) scheme", () => {
		expect(() => parseConfig({ ...valid, publicBaseUrl: "web.example.com" })).toThrow(ConfigError);
	});

	it("rejects short cookieSecret", () => {
		expect(() => parseConfig({ ...valid, cookieSecret: "short" })).toThrow(ConfigError);
	});

	it("rejects out-of-range cookieTtlDays", () => {
		expect(() => parseConfig({ ...valid, cookieTtlDays: 0 })).toThrow(ConfigError);
		expect(() => parseConfig({ ...valid, cookieTtlDays: 400 })).toThrow(ConfigError);
	});

	it("normalizes an unknown domain to feishu", () => {
		expect(parseConfig({ ...valid, domain: "unknown" }).domain).toBe("feishu");
		expect(parseConfig({ ...valid, domain: "lark" }).domain).toBe("lark");
	});

	it("expands ~/ in dbPath", () => {
		const cfg = parseConfig({ ...valid, dbPath: "~/foo.sqlite" });
		expect(cfg.dbPath).not.toContain("~");
		expect(cfg.dbPath.endsWith("/foo.sqlite")).toBe(true);
	});
});
