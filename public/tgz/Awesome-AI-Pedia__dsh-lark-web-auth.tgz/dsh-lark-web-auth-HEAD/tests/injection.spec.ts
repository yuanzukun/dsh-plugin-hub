/**
 * Injection tests — the string returned by `injectIntoIndex` must:
 *   - land before </head> when present
 *   - fall through to </body> when head missing
 *   - append when neither exists
 *   - contain both the fetch interceptor and the /me badge loader
 *   - be idempotent-guarded (installed flag)
 */

import vm from "node:vm";
import { describe, it, expect } from "vitest";
import { injectIntoIndex, buildLoginInjection } from "../src/index-injection.ts";

function scriptBody(): string {
	const snippet = buildLoginInjection();
	return snippet.replace(/^<script>/, "").replace(/<\/script>$/, "");
}

function makeBrowser(
	fetchImpl: (input: unknown, init?: unknown) => Promise<{ status: number }>,
	extraGlobals: Record<string, unknown> = {},
) {
	const listeners = new Map<string, Array<() => void>>();
	const location = {
		origin: "http://127.0.0.1:3080",
		pathname: "/workspace",
		search: "?q=1",
		hash: "#active",
		href: "http://127.0.0.1:3080/workspace?q=1#active",
	};
	const document = {
		readyState: "loading",
		addEventListener(name: string, cb: () => void) {
			const arr = listeners.get(name) ?? [];
			arr.push(cb);
			listeners.set(name, arr);
		},
		createElement() {
			return {
				setAttribute() {},
				addEventListener() {},
				appendChild() {},
			};
		},
		createTextNode(text: string) {
			return { text };
		},
		body: { appendChild() {} },
	};
	const window = {
		__larkWebAuthInstalled: false,
		fetch: fetchImpl,
		location,
		document,
	};
	const context = {
		window,
		document,
		location,
		URL,
		setTimeout,
		clearTimeout,
		console,
		...extraGlobals,
	};
	Object.assign(window, extraGlobals);
	vm.runInNewContext(scriptBody(), context);
	return { window, location, document, listeners };
}

describe("index-injection", () => {
	it("inserts before </head> when present", () => {
		const html = "<html><head><title>t</title></head><body></body></html>";
		const out = injectIntoIndex(html);
		expect(out.indexOf("<script>")).toBeLessThan(out.indexOf("</head>"));
		expect(out).toContain("<title>t</title>");
	});

	it("falls back to </body> when </head> missing", () => {
		const html = "<html><body>content</body></html>";
		const out = injectIntoIndex(html);
		expect(out.indexOf("<script>")).toBeLessThan(out.indexOf("</body>"));
	});

	it("appends when neither </head> nor </body> exists", () => {
		const html = "plain content";
		const out = injectIntoIndex(html);
		expect(out.startsWith("plain content")).toBe(true);
		expect(out).toContain("<script>");
	});

	it("snippet installs a fetch interceptor and loads /auth/lark/me", () => {
		const s = buildLoginInjection();
		expect(s).toContain("window.fetch");
		expect(s).toContain("/auth/lark/login");
		expect(s).toContain("/auth/lark/me");
		expect(s).toContain("/auth/lark/logout");
	});

	it("fetch 401 redirects to Feishu login with the current page as return_to", async () => {
		const { window, location } = makeBrowser(async () => ({ status: 401 }));

		await window.fetch("/api/session.list");

		expect(location.href).toBe("/auth/lark/login?return_to=%2Fworkspace%3Fq%3D1%23active");
	});

	it("XMLHttpRequest 401 redirects to Feishu login", () => {
		const callbacks: Array<() => void> = [];
		class FakeXHR {
			status = 401;
			open() {}
			send() {
				for (const cb of callbacks) cb();
			}
			addEventListener(name: string, cb: () => void) {
				if (name === "loadend") callbacks.push(cb);
			}
		}
		const browser = makeBrowser(async () => ({ status: 200 }), { XMLHttpRequest: FakeXHR });
		const xhr = new (browser.window as unknown as { XMLHttpRequest: typeof FakeXHR }).XMLHttpRequest();
		xhr.open();
		xhr.send();

		expect(browser.location.href).toBe("/auth/lark/login?return_to=%2Fworkspace%3Fq%3D1%23active");
	});

	it("snippet is idempotent-guarded", () => {
		const s = buildLoginInjection();
		expect(s).toContain("__larkWebAuthInstalled");
	});
});
