/**
 * API auth wrapper tests — dsh-client-connection owns the `/api` route, so the
 * plugin wraps that existing route and seeds AsyncLocalStorage from the login
 * cookie before the carrier calls apiProxy.
 */

import { describe, expect, it, vi } from "vitest";
import { IncomingMessage, ServerResponse } from "node:http";
import { Socket } from "node:net";
import type { Duplex } from "node:stream";
import { installApiAuthWrapper } from "../src/api-auth-wrapper.ts";
import { getAuthContext } from "../src/middleware.ts";
import { COOKIE_NAME } from "../src/oauth.ts";
import type { SessionStore } from "../src/session-store.ts";

type HttpHandler = (req: IncomingMessage, res: ServerResponse) => void | Promise<void>;
type UpgradeHandler = (req: IncomingMessage, socket: Duplex, head: Buffer) => void | Promise<void>;
type WebRoute = { kind: "prefix"; path: string; handler: HttpHandler };
type UpgradeRoute = { path: string; handler: UpgradeHandler };

function makeReq(url: string, headers: Record<string, string> = {}): IncomingMessage {
	const req = new IncomingMessage(new Socket());
	req.url = url;
	req.method = "POST";
	req.headers = headers;
	return req;
}

interface CapturedRes {
	res: ServerResponse;
	statusCode(): number;
	body(): string;
	headers(): Record<string, string | string[] | number | undefined>;
}

function makeRes(): CapturedRes {
	const chunks: Buffer[] = [];
	const req = new IncomingMessage(new Socket());
	const res = new ServerResponse(req);
	const origWrite = res.write.bind(res);
	res.write = ((chunk: string | Buffer, ...rest: unknown[]) => {
		chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
		return origWrite(chunk as string, ...(rest as [never]));
	}) as typeof res.write;
	const origEnd = res.end.bind(res);
	res.end = ((chunk?: string | Buffer, ...rest: unknown[]) => {
		if (chunk) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk)));
		return origEnd(chunk as string, ...(rest as [never]));
	}) as typeof res.end;
	return {
		res,
		statusCode: () => res.statusCode,
		body: () => Buffer.concat(chunks).toString("utf8"),
		headers: () => res.getHeaders(),
	};
}

function mockStore(): SessionStore {
	return {
		create: vi.fn(),
		find: vi.fn((token: string) => {
			if (token !== "tok-alice") return undefined;
			return {
				token,
				openId: "ou_alice",
				name: "Alice",
				avatarUrl: "",
				createdAt: 1,
				expiresAt: 10_000,
			};
		}),
		revoke: vi.fn(),
		gcExpired: vi.fn(() => 0),
		createOAuthState: vi.fn(),
		consumeOAuthState: vi.fn(),
		gcOAuthStates: vi.fn(() => 0),
	};
}

function mockWebServer() {
	const prefixes = new Map<string, WebRoute>();
	const upgrades = new Map<string, UpgradeRoute>();
	return {
		prefixes,
		upgrades,
		register: vi.fn((route: WebRoute) => {
			prefixes.set(route.path, route);
			return () => prefixes.delete(route.path);
		}),
		registerUpgrade: vi.fn((route: UpgradeRoute) => {
			upgrades.set(route.path, route);
			return () => upgrades.delete(route.path);
		}),
	};
}

describe("api-auth-wrapper", () => {
	it("rejects existing /api route requests without a valid login cookie", async () => {
		const webServer = mockWebServer();
		const handler = vi.fn((_req: IncomingMessage, res: ServerResponse) => {
			res.statusCode = 200;
			res.end("ok");
		});
		webServer.prefixes.set("/api", { kind: "prefix", path: "/api", handler });

		installApiAuthWrapper(webServer, { store: mockStore(), now: () => 1_000 });
		const cap = makeRes();
		await webServer.prefixes.get("/api")!.handler(makeReq("/api/session.list"), cap.res);

		expect(cap.statusCode()).toBe(401);
		expect(cap.headers()["content-type"]).toBe("application/json");
		expect(cap.body()).toContain("not-logged-in");
		expect(handler).not.toHaveBeenCalled();
	});

	it("seeds auth context for existing /api route requests with a valid cookie", async () => {
		const webServer = mockWebServer();
		let seenOpenId: string | undefined;
		webServer.prefixes.set("/api", {
			kind: "prefix",
			path: "/api",
			handler: (_req, res) => {
				seenOpenId = getAuthContext()?.openId;
				res.statusCode = 204;
				res.end();
			},
		});

		installApiAuthWrapper(webServer, { store: mockStore(), now: () => 1_000 });
		const cap = makeRes();
		await webServer.prefixes.get("/api")!.handler(
			makeReq("/api/session.list", { cookie: `${COOKIE_NAME}=tok-alice` }),
			cap.res,
		);

		expect(cap.statusCode()).toBe(204);
		expect(seenOpenId).toBe("ou_alice");
	});

	it("wraps future /api route registrations when loaded before client-connection", async () => {
		const webServer = mockWebServer();
		installApiAuthWrapper(webServer, { store: mockStore(), now: () => 1_000 });
		const handler = vi.fn((_req: IncomingMessage, res: ServerResponse) => {
			res.statusCode = 204;
			res.end();
		});
		webServer.register({ kind: "prefix", path: "/api", handler });

		const cap = makeRes();
		await webServer.prefixes.get("/api")!.handler(makeReq("/api/session.list"), cap.res);

		expect(cap.statusCode()).toBe(401);
		expect(handler).not.toHaveBeenCalled();
	});

	it("rejects unauthenticated api websocket upgrades", () => {
		const webServer = mockWebServer();
		const end = vi.fn();
		const socket = { end } as unknown as Duplex;
		const upgrade = vi.fn();
		webServer.upgrades.set("/api/events.mux", { path: "/api/events.mux", handler: upgrade });

		installApiAuthWrapper(webServer, { store: mockStore(), now: () => 1_000 });
		webServer.upgrades.get("/api/events.mux")!.handler(makeReq("/api/events.mux"), socket, Buffer.alloc(0));

		expect(upgrade).not.toHaveBeenCalled();
		expect(end).toHaveBeenCalledWith(expect.stringContaining("401 Unauthorized"));
	});
});
