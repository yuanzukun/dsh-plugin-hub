import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import Database from "better-sqlite3";
import type { Context } from "@deepseek-ai/cordis";
import type { Session } from "@deepseek-ai/dsh-session";
import { runBackfill } from "../src/backfill.ts";
import type { Db } from "../src/db.ts";
import type { LarkClient } from "../src/lark-api.ts";
import { createOwnerStore } from "../src/owner-store.ts";
import { installOwnerTracker } from "../src/owner-tracker.ts";

function memDb(): Db {
	const raw = new Database(":memory:");
	raw.exec(`
		CREATE TABLE session_owner (session_id TEXT PRIMARY KEY, open_id TEXT NOT NULL,
			source TEXT NOT NULL, created_at INTEGER NOT NULL);
	`);
	return { raw, close: () => raw.close() };
}

function larkClient(openId: string): LarkClient {
	return {
		authorizeUrl: vi.fn(),
		exchangeCode: vi.fn(),
		userInfo: vi.fn(),
		openIdForP2pChat: vi.fn(async () => openId),
	};
}

describe("lark-link ownership", () => {
	let db: Db;
	let oldHome: string | undefined;
	let tempDir: string;

	beforeEach(() => {
		db = memDb();
		oldHome = process.env.DSH_LARK_LINK_HOME;
		tempDir = mkdtempSync(join(tmpdir(), "lark-link-home-"));
		process.env.DSH_LARK_LINK_HOME = tempDir;
	});

	afterEach(() => {
		db.close();
		if (oldHome === undefined) delete process.env.DSH_LARK_LINK_HOME;
		else process.env.DSH_LARK_LINK_HOME = oldHome;
		rmSync(tempDir, { recursive: true, force: true });
	});

	it("backfills lark-link p2p sessions from the persisted route store", async () => {
		writeFileSync(
			join(tempDir, "routes.json"),
			JSON.stringify([
				{
					sessionKey: "dm:oc_fceab1ba704543ce3317443fe42cd04a",
					chatId: "oc_fceab1ba704543ce3317443fe42cd04a",
					chatType: "p2p",
				},
			]),
		);
		const sessionId = "lark-link:dm:oc_fceab1ba704543ce3317443fe42cd04a:mszpg299fev8:0";
		const owners = createOwnerStore(db);
		const ctx = {
			get(name: string) {
				if (name === "sessionPersistence") return { list: async () => [{ id: sessionId }] };
				return undefined;
			},
		} as unknown as Context;

		const result = await runBackfill(ctx, { owners, lark: larkClient("ou_user"), now: () => 123 });

		expect(result).toEqual({ scanned: 1, claimed: 1, skipped: 0 });
		expect(owners.ownerOf(sessionId)).toBe("ou_user");
	});

	it("claims new lark-link p2p sessions by parsing their session id", async () => {
		let listener: ((session: Session) => void) | undefined;
		const ctx = {
			on(_event: string, cb: (session: Session) => void) {
				listener = cb;
				return () => {};
			},
		} as unknown as Context;
		const owners = createOwnerStore(db);
		const sessionId = "lark-link:dm:oc_fceab1ba704543ce3317443fe42cd04a:mszpg299fev8:0";
		const lark = larkClient("ou_user");
		installOwnerTracker(ctx, { owners, lark, now: () => 456 });

		listener?.({ header: { id: sessionId } } as Session);
		await vi.waitFor(() => {
			expect(owners.ownerOf(sessionId)).toBe("ou_user");
		});
		expect(lark.openIdForP2pChat).toHaveBeenCalledWith("oc_fceab1ba704543ce3317443fe42cd04a");
	});
});
