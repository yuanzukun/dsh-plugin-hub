# 架构说明

给未来维护者看的实现文档。使用手册请看 [README](README.md)，部署请看 [DEPLOY](DEPLOY.md)。

## 一句话

在 DSH webserver 上加一组 `/auth/lark/*` 路由做 OAuth，用 SQLite 记 `sessionId → open_id` 归属；在 `apiProxy.sessions` 的方法上装饰过滤逻辑做数据隔离；用 `tapIndex` 往 SPA HTML 注入登录跳转脚本。全程不改 harness 核心。

## 模块图

```
                        ┌─────────────────────┐
   浏览器 ──/api/*──→   │  webServer          │  ←─ tapIndex 注入 <script>
                        │  register('/auth')  │
                        └──────────┬──────────┘
                                   │
             ┌─────────────────────┼─────────────────────┐
             ↓                     ↓                     ↓
        oauth.ts             middleware.ts        (client-connection
        4 个路由             AsyncLocalStorage     已有的 /api 路由)
             │                     │                     │
             ↓                     ↓                     ↓
     session-store.ts       auth ctx 传递         apiProxy.sessions.*
     lark-api.ts                                        │
                                                       ↓
                                                 owner-filter.ts
                                                 (monkey-patch list/history/...)
                                                       │
                                                       ↓
                                                 owner-store.ts
                                                 session_owner 表
                                                       ↑
                                              owner-tracker.ts
                                              (ctx.on('session/created'))
```

## 数据流：一次登录

```
1. GET /  →  webServer fallback → SPA index.html
   ↳ tapIndex 注入 <script>: 全局 fetch 拦 401
2. SPA 触发 /api/xxx → 401 (无 cookie)
3. 脚本捕获 401 → location.href='/auth/lark/login?return_to=/'
4. GET /auth/lark/login
   ↳ oauth.loginRedirect
   ↳ session-store.createOAuthState (随机 state 写 SQLite)
   ↳ 302 → https://passport.feishu.cn/.../authorize?state=xxx
5. 用户在飞书授权
6. GET /auth/lark/callback?code=...&state=...
   ↳ oauth.callback
   ↳ consumeOAuthState (校验 + 删)
   ↳ lark.exchangeCode (换 user_access_token)
   ↳ lark.userInfo (拿 open_id + name)
   ↳ session-store.create (写 web_session 行，生成 cookie token)
   ↳ Set-Cookie + 302 → /
7. 浏览器带 cookie 请求 /api/session.list
   ↳ middleware.requireAuth 校验 cookie，塞 AuthContext 进 ALS
   ↳ apiProxy.sessions.list (被 owner-filter 装饰过)
   ↳ 读原始 list → 过滤 items 中 owner == 当前 openId 的
   ↳ 返回给浏览器
```

## 关键设计决定

### 为什么用 monkey-patch 而不是 typert lookup wrapper？

调研发现 typert 的 `lookups.configure(key, resolver)` 对同一个 key **不允许重复注册**——`api-remotes` 已经注册了 `agent` 和 `session` resolver，我们没法覆盖。

替代方案是装饰 `ctx.apiProxy.sessions.*` 方法：

- 该 service 里 `this.sessions = api.sessions` 是普通 property
- API dispatch handler 里 `invoke: (api, r) => api.sessions.list(r)` 每次都从 api 上现读
- 所以插件加载时替换方法引用生效

优点：不改 harness 核心；缺点：如果 harness 未来把 sessions 改成 getter 或者冻结对象，就要调整。

### 为什么不改 SessionHeader 加 ownerId？

`SessionHeader` 的字段变化会 bump `SESSION_FORMAT_VERSION`（见 `packages/core/session/src/index.ts`），这是硬 break 变更。用旁路 SQLite 表存 owner 关系不影响 harness 核心，也更容易 backfill 和 migrate。

### 为什么 SPA 侧用注入脚本而不是改前端？

harness 的 `@deepseek-ai/dsh-web-frontend` 是独立包，改它意味着：
- fork 或本地补丁；
- 每次 harness 升级要重跑 diff；
- 增加 npm 发布负担。

用 `webServer.tapIndex()` 注入 `<script>` 拦截 401 + 挂用户 badge，只有 ~50 行 JS，零外部依赖，harness 前端源码保持干净。缺点：badge 是浮动定位，视觉集成度不如原生 UI；但对内部工具够用。

### AsyncLocalStorage 靠谱吗？

Node 22+ 里 ALS 跨 `await`、`setTimeout`、`Promise.then` 都稳定传播。唯一会丢的是：
- worker_threads 边界；
- 明确用 `setImmediate` 断链的第三方库（少见）。

harness webserver 单进程处理请求，从 HTTP handler 一路到 apiProxy 方法都在同一 async chain 里，安全。

### 为什么飞书 API 不用官方 SDK？

`@larksuiteoapi/node-sdk` 拉进 axios + form-data + 一堆 tsyringe 依赖，install 尺寸 15MB+。我们只用 4 个 endpoint：
- `oauth/token`
- `user_info`
- `tenant_access_token/internal`
- `im/v1/chats/{chatId}`

用 Node 22 内置 `fetch` 手写 ~100 行搞定，install 尺寸 < 200KB。

## 数据库

| 表 | 用途 | 增长模式 |
|---|---|---|
| `web_session` | httpOnly cookie ↔ open_id | 与登录数正相关；有 TTL，hourly GC |
| `session_owner` | DSH sessionId ↔ open_id | 单调增长；~= 用户创建的对话总数 |
| `oauth_state` | OAuth CSRF nonce | 10 分钟 TTL；hourly GC |

100 人日活 × 10 对话 = 1000 行 `session_owner`，100 KB 级别，SQLite 秒查。

## 已知 corner cases

1. **飞书 API 挂了**：backfill 会 skip，owner-tracker 会 warn 但不阻塞；用户仍能登录（用现有 web_session）。
2. **cookie 密钥旋转**：所有活跃 login 立即失效（cookie 里没签名，是 opaque token；数据库 lookup 失败即视为无效）。
3. **飞书用户改名/换头像**：cookie 里存的 name/avatar 不会自动更新，直到用户重新登录（TTL 后或主动 logout）。
4. **session 属主离职**：他名下的 session 无人可见，直到管理员手动改 `session_owner.open_id`。
5. **两个 tab 同时登录不同账号**：cookie 唯一，后登的覆盖前登的。这是浏览器机制，不是 bug。

## 依赖表

| 依赖 | 用途 | 可替换性 |
|---|---|---|
| `better-sqlite3` | 同步 SQLite | 换 `node-sqlite3` 要重写为 async；不换更省事 |
| `cookie` | RFC 6265 编解码 | 也可以自己写 60 行，但没必要 |
| Node 22+ 内置 `fetch` | 飞书 API 调用 | 无 |
| Node 22+ 内置 `AsyncLocalStorage` | 请求上下文 | 无替代 |

## 测试

```bash
pnpm test              # 46 个单测
pnpm test:watch        # 开发时用
pnpm build             # tsdown → dist/
```

覆盖率没做 100%（`backfill.ts` 和 `owner-tracker.ts` 有 fire-and-forget 的分支难覆盖），核心逻辑（config / stores / oauth / owner-filter / injection）都覆盖到了。

## 如果想合并进 order-service 上游

需要按 `packages/AGENTS.md` 补齐：

- `README.i18n.yaml` 双语记录
- `README.zh.md` 翻译
- `invariant.ts` 包必需（可以用 "No runtime invariant: this plugin exposes no session events" 的空 installer）
- 每个 export 加严格 JSDoc（本仓库已经写了 80%，缺一些）
- 通过 `pnpm run doc-sync` / `pnpm run hygiene` / `pnpm run test:coverage`（100% 逐文件）

预计 4~8 小时。
