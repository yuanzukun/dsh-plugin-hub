# 部署指南

从零到公网可用，分 4 步：飞书配置 → 服务器准备 → 安装启动 → 验证。

## 1. 飞书开放平台配置

### 1.1 新建或复用应用

- 打开 [https://open.feishu.cn/app](https://open.feishu.cn/app)
- 用管理员账号登录，进入"企业自建应用"
- 建议**复用你已有的 dsh-lark-link 应用**（一个应用可以同时做 bot 和网页登录），不用新建

### 1.2 添加网页应用能力

- 应用详情 → 「添加应用能力」→ 「网页」
- 主页地址填：`https://web.yourdomain.com`

### 1.3 配置重定向 URL

- 「安全设置」→ 「重定向 URL」
- 添加：`https://web.yourdomain.com/auth/lark/callback`
- **注意**：域名必须与 `LARK_WEB_BASE_URL` 一致；`http://localhost` 也可加进去用于本地调试

### 1.4 开通权限

- 「权限管理」→ 搜索并开通：
  - `contact:user.base:readonly` （拿 open_id + 姓名 + 头像）

### 1.5 记下凭证

- 「凭证与基础信息」记下 **App ID** 和 **App Secret**
- 修改后需重启插件

### 1.6 发版申请

- 「版本管理与发布」→ 创建版本 → 提交审批 → 管理员批准
- 未发版的应用只有开发者本人能用

---

## 2. 服务器准备

### 2.1 系统要求

- Node.js >= 22.19
- pnpm >= 9
- SQLite（`better-sqlite3` 自带，不用单独装）
- 磁盘：至少 100MB（用户 + 会话 owner 表）
- 内存：512MB（100 人并发峰值）

### 2.2 域名 + HTTPS

- 你需要一个指向服务器 IP 的域名，例如 `web.yourdomain.com`
- 证书由 Caddy 自动签（推荐）或你自备

### 2.3 Caddy 反代配置

创建 `/etc/caddy/Caddyfile`：

```caddy
web.yourdomain.com {
    # Let's Encrypt 会自动签证书
    reverse_proxy localhost:3080 {
        # SSE / WebSocket 长连接必须调
        flush_interval -1
        transport http {
            read_timeout 10m
            write_timeout 10m
        }
    }

    # 可选：把日志写文件
    log {
        output file /var/log/caddy/web-access.log
        format json
    }
}
```

启动 Caddy：

```bash
sudo systemctl enable --now caddy
sudo systemctl reload caddy
```

Caddy 会自动从 Let's Encrypt 拿证书（首次可能几秒钟）。

### 2.4 或使用 Nginx（如果你已用 nginx）

```nginx
server {
    listen 443 ssl http2;
    server_name web.yourdomain.com;

    ssl_certificate     /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://127.0.0.1:3080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;

        # SSE / WebSocket
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_buffering off;
        proxy_read_timeout 600s;
        proxy_send_timeout 600s;
    }
}
```

---

## 3. 安装和启动

### 3.1 装 DSH 主体（如果还没装）

参考 [DeepSeek Harness README](https://github.com/deepseek-ai/deepseek-harness#installation)。

### 3.2 装 dsh-lark-link（如果还没装）

```bash
dsh plugin --profile web add dsh-lark-link
```

按提示扫码授权飞书 bot。

### 3.3 装 dsh-lark-web-auth

```bash
dsh plugin --profile web add dsh-lark-web-auth
```

如果还未发布到 npm，从本地：

```bash
cd /path/to/dsh-lark-web-auth
pnpm build
dsh plugin --profile web add /path/to/dsh-lark-web-auth
```

### 3.4 配置环境变量

编辑 `~/.dsh/.env`（或 systemd 服务的 Environment=）：

```bash
LARK_WEB_APP_ID=cli_xxxxxxxxxx
LARK_WEB_APP_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
LARK_WEB_BASE_URL=https://web.yourdomain.com
LARK_WEB_COOKIE_SECRET=<32+ 字节随机串>
# 可选
LARK_WEB_DB_PATH=/data/dsh/lark-web-auth.sqlite
LARK_WEB_DOMAIN=feishu
```

生成 cookie 密钥：

```bash
openssl rand -base64 48 | tr -d '\n'
```

**注意**：`LARK_WEB_COOKIE_SECRET` 泄露等于所有用户被踢下线；换它会让所有活跃 session 立即失效。

### 3.5 systemd 服务（可选但推荐）

`/etc/systemd/system/dsh-web.service`：

```ini
[Unit]
Description=DeepSeek Harness Web
After=network.target

[Service]
Type=simple
User=dsh
WorkingDirectory=/home/dsh
EnvironmentFile=/home/dsh/.dsh/.env
ExecStart=/usr/bin/dsh --profile web
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

启动：

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now dsh-web
sudo systemctl status dsh-web
sudo journalctl -u dsh-web -f  # 看日志
```

---

## 4. 验证

### 4.1 检查启动日志

```bash
journalctl -u dsh-web -n 50
```

应看到：

```
[lark-web-auth] ready — publicBaseUrl=https://web.yourdomain.com dbPath=...
[lark-web-auth] backfill complete: scanned=X claimed=Y skipped=Z
```

`skipped > 0` 是正常的——存量数据依赖 lark-link 内部映射，多数会 skip。手动分配请看 [FAQ](#faq)。

### 4.2 浏览器访问

- 打开 `https://web.yourdomain.com`
- 应该自动跳转到 `https://passport.feishu.cn/suite/passport/oauth/authorize?...`
- 授权后回跳，看到 DSH 界面
- 右上角有小圆头像 + 姓名 + "退出" 按钮

### 4.3 隔离验证

用两个飞书账号 A 和 B 分别登录（用不同浏览器/无痕窗口）：

- A 登录，能看到 A 之前跟飞书 bot 聊过的对话（如果 backfill 成功）
- A 新建会话，能看到
- 用 A 的浏览器手动构造 URL `https://web.yourdomain.com/api/...?sessionId=<B的sessionId>`（如果知道的话），应该返回 404
- B 登录，看不到 A 的任何对话

### 4.4 cookie 验证

F12 → Application → Cookies：

- 有 `dsh_web_session` cookie
- `HttpOnly = true`
- `Secure = true`
- `SameSite = Lax`

---

## FAQ

### 存量对话看不到？

lark-link 的 session id 由内部 hash 生成，插件无法反解出 chat_id 做自动 backfill。方案：

1. **忽略**：让老对话消失，新对话正常隔离（推荐，最简单）
2. **手动分配**：登录 SQLite 库直接写：

```bash
sqlite3 ~/.dsh/lark-web-auth.sqlite
> INSERT INTO session_owner (session_id, open_id, source, created_at)
  VALUES ('<sessionId>', 'ou_xxx', 'manual', unixepoch()*1000);
```

### 换服务器/重启后用户要重新登录吗？

不用。登录态在 SQLite 里持久化，只要 `LARK_WEB_DB_PATH` 指向的文件在，重启保留。

### 想禁用登录临时排查？

```bash
LARK_WEB_AUTH_ENABLED=false
```

重启即可（此时所有对话对所有访问者可见——**仅限内网调试**）。

### cookie 密钥可以换吗？

可以，换了之后所有用户被踢下线，需要重新登录。

### 100 人以上够用吗？

理论上够（SQLite 单文件到千级并发无压力），但没做压测。超过 500 人建议评估切 Postgres。

### 如何审计谁访问了谁的数据？

当前版本无审计日志。如需，在 `packages/core/session/src/index.ts` 附近加一个 listener，把每次 owner-check 记到额外的表里。或提 issue。
