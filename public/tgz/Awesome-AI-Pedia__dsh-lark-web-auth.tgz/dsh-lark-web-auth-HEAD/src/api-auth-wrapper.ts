/**
 * Auth wrapper for the dsh browser carrier. `dsh-client-connection` owns the
 * `/api` prefix route, so this plugin cannot register that prefix itself. The
 * WebServer implementation stores route tables on ordinary properties; wrap
 * the existing route when present and patch future registrations for load-order
 * tolerance.
 */

import type { IncomingMessage, ServerResponse } from "node:http";
import type { Duplex } from "node:stream";
import {
	authContextFromRequest,
	requireAuth,
	runWithAuth,
	type MiddlewareDeps,
} from "./middleware.ts";

const API_PREFIX = "/api";
const MUX_EVENTS_PATH = "/api/events.mux";
const HOST_EVENTS_PATH = "/api/events.host";
const WRAPPED = Symbol("dsh-lark-web-auth-wrapped");

type HttpHandler = (req: IncomingMessage, res: ServerResponse) => void | Promise<void>;
type UpgradeHandler = (req: IncomingMessage, socket: Duplex, head: Buffer) => void | Promise<void>;

interface WebRoute {
	kind: "exact" | "prefix";
	path: string;
	handler: HttpHandler;
	[WRAPPED]?: true;
}

interface WebUpgradeRoute {
	path: string;
	handler: UpgradeHandler;
	[WRAPPED]?: true;
}

interface PatchableWebServer {
	register(route: WebRoute): () => void;
	registerUpgrade(route: WebUpgradeRoute): () => void;
	prefixes?: Map<string, WebRoute>;
	upgrades?: Map<string, WebUpgradeRoute>;
}

function unauthorizedUpgrade(socket: Duplex): void {
	socket.end([
		"HTTP/1.1 401 Unauthorized",
		"Connection: close",
		"Content-Type: application/json",
		"Content-Length: 25",
		"",
		'{"error":"not-logged-in"}',
	].join("\r\n"));
}

function isApiRoute(route: WebRoute): boolean {
	return route.kind === "prefix" && route.path === API_PREFIX;
}

function isApiUpgrade(route: WebUpgradeRoute): boolean {
	return route.path === MUX_EVENTS_PATH || route.path === HOST_EVENTS_PATH;
}

function wrapHttpRoute(route: WebRoute, deps: MiddlewareDeps): () => void {
	if (route[WRAPPED]) return () => undefined;
	const original = route.handler;
	route.handler = requireAuth(deps, original);
	route[WRAPPED] = true;
	return () => {
		route.handler = original;
		delete route[WRAPPED];
	};
}

function wrapUpgradeRoute(route: WebUpgradeRoute, deps: MiddlewareDeps): () => void {
	if (route[WRAPPED]) return () => undefined;
	const original = route.handler;
	route.handler = (req, socket, head) => {
		const auth = authContextFromRequest(deps, req);
		if (!auth) {
			unauthorizedUpgrade(socket);
			return;
		}
		return runWithAuth(auth, () => original(req, socket, head));
	};
	route[WRAPPED] = true;
	return () => {
		route.handler = original;
		delete route[WRAPPED];
	};
}

/** Install cookie authentication over dsh's `/api` HTTP and WebSocket routes. */
export function installApiAuthWrapper(webServer: PatchableWebServer, deps: MiddlewareDeps): () => void {
	const disposers: Array<() => void> = [];

	const existingApi = webServer.prefixes?.get(API_PREFIX);
	if (existingApi && isApiRoute(existingApi)) disposers.push(wrapHttpRoute(existingApi, deps));

	for (const path of [MUX_EVENTS_PATH, HOST_EVENTS_PATH]) {
		const existingUpgrade = webServer.upgrades?.get(path);
		if (existingUpgrade) disposers.push(wrapUpgradeRoute(existingUpgrade, deps));
	}

	const originalRegister = webServer.register.bind(webServer);
	webServer.register = (route) => {
		const wrapped = isApiRoute(route) ? { ...route } : route;
		const unwrap = isApiRoute(wrapped) ? wrapHttpRoute(wrapped, deps) : () => undefined;
		disposers.push(unwrap);
		const disposeRoute = originalRegister(wrapped);
		return () => {
			unwrap();
			disposeRoute();
		};
	};
	disposers.push(() => {
		webServer.register = originalRegister;
	});

	const originalRegisterUpgrade = webServer.registerUpgrade.bind(webServer);
	webServer.registerUpgrade = (route) => {
		const wrapped = isApiUpgrade(route) ? { ...route } : route;
		const unwrap = isApiUpgrade(wrapped) ? wrapUpgradeRoute(wrapped, deps) : () => undefined;
		disposers.push(unwrap);
		const disposeRoute = originalRegisterUpgrade(wrapped);
		return () => {
			unwrap();
			disposeRoute();
		};
	};
	disposers.push(() => {
		webServer.registerUpgrade = originalRegisterUpgrade;
	});

	return () => {
		for (const dispose of disposers.reverse()) dispose();
	};
}
