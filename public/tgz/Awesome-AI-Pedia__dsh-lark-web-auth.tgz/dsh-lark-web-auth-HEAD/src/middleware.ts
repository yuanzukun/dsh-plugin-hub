/**
 * Per-request auth propagation via AsyncLocalStorage. Handlers that need to
 * know who is calling read `getAuthContext()`. The middleware wrapping HTTP
 * routes calls `runWithAuth()` to seed the ALS store.
 *
 * ALS is stable in Node 22+ across `await` and setTimeout — safe for HTTP.
 * A worker_threads boundary would drop it, but the harness Web GUI runs in one
 * process here.
 */

import { AsyncLocalStorage } from "node:async_hooks";
import type { IncomingMessage, ServerResponse } from "node:http";
import { readCookie } from "./oauth.ts";
import type { SessionStore } from "./session-store.ts";
import type { AuthContext } from "./types.ts";

const als = new AsyncLocalStorage<AuthContext>();

/** Read the current request's authenticated user, or undefined if unauth. */
export function getAuthContext(): AuthContext | undefined {
	return als.getStore();
}

/** Run `fn` with an auth context bound to it (and every awaited descendant). */
export function runWithAuth<T>(auth: AuthContext, fn: () => T): T {
	return als.run(auth, fn);
}

/** Deps the middleware needs at request time. */
export interface MiddlewareDeps {
	store: SessionStore;
	now: () => number;
}

/** Resolve the authenticated user for one HTTP request, if its cookie is valid. */
export function authContextFromRequest(
	deps: MiddlewareDeps,
	req: IncomingMessage,
): AuthContext | undefined {
	const token = readCookie(req);
	const row = token ? deps.store.find(token, deps.now()) : undefined;
	if (!row) return undefined;
	return { openId: row.openId, name: row.name };
}

/**
 * Wrap an HTTP handler with cookie-based auth. On success the handler runs
 * inside an AsyncLocalStorage frame carrying the resolved AuthContext.
 * Unauthenticated requests receive a JSON 401 and the handler never runs.
 *
 * The wrapper does NOT special-case any paths — callers pick which routes are
 * public (`/auth/*`, static assets) and only wrap the private ones.
 */
export function requireAuth(
	deps: MiddlewareDeps,
	handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>,
): (req: IncomingMessage, res: ServerResponse) => Promise<void> {
	return async (req, res) => {
		const auth = authContextFromRequest(deps, req);
		if (!auth) {
			res.statusCode = 401;
			res.setHeader("content-type", "application/json");
			res.end(JSON.stringify({ error: "not-logged-in" }));
			return;
		}
		await runWithAuth(auth, () => Promise.resolve(handler(req, res)));
	};
}
