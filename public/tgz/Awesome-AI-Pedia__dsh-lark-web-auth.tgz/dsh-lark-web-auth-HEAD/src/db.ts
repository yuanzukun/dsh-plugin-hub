/**
 * SQLite database setup. Three tables:
 *   - web_session:   cookie token → open_id
 *   - session_owner: DSH sessionId → open_id
 *   - oauth_state:   in-flight OAuth authorize → CSRF nonce
 *
 * Uses better-sqlite3 (synchronous, single-file, WAL-safe for our load).
 * At 100 concurrent users this is orders of magnitude below its limits.
 */

import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import Database, { type Database as BetterSqliteDb } from "better-sqlite3";

/** Current schema version. Bump on any breaking table change and add migration. */
export const SCHEMA_VERSION = 1;

/** Handle around the SQLite connection with prepared statements pre-warmed. */
export interface Db {
	/** Underlying better-sqlite3 instance for ad-hoc queries. */
	readonly raw: BetterSqliteDb;
	/** Close the connection. Idempotent. */
	close(): void;
}

/** Open (creating and migrating if necessary) the plugin's SQLite database. */
export function openDb(path: string): Db {
	// Ensure parent dir exists — better-sqlite3 throws on missing dir.
	mkdirSync(dirname(path), { recursive: true });

	const raw = new Database(path);
	raw.pragma("journal_mode = WAL");
	raw.pragma("foreign_keys = ON");
	raw.pragma("busy_timeout = 5000");

	migrate(raw);

	return {
		raw,
		close() {
			try {
				raw.close();
			} catch {
				// Already closed — idempotent per contract.
			}
		},
	};
}

/**
 * Apply schema migrations from `user_version` to `SCHEMA_VERSION`. On a fresh
 * db `user_version` is 0 and every step runs; on an already-current db this is
 * a no-op. Migrations are declared in `MIGRATIONS` — never mutate a shipped
 * step, only append a new one.
 */
function migrate(db: BetterSqliteDb): void {
	const current = (db.pragma("user_version", { simple: true }) as number) ?? 0;
	if (current >= SCHEMA_VERSION) return;

	db.transaction(() => {
		for (let v = current + 1; v <= SCHEMA_VERSION; v++) {
			const step = MIGRATIONS[v];
			if (!step) throw new Error(`missing migration for schema version ${v}`);
			db.exec(step);
		}
		db.pragma(`user_version = ${SCHEMA_VERSION}`);
	})();
}

/** Ordered migrations. Index === target schema version. Index 0 unused. */
const MIGRATIONS: Record<number, string> = {
	1: `
		CREATE TABLE web_session (
			token       TEXT PRIMARY KEY,
			open_id     TEXT NOT NULL,
			name        TEXT NOT NULL DEFAULT '',
			avatar_url  TEXT NOT NULL DEFAULT '',
			created_at  INTEGER NOT NULL,
			expires_at  INTEGER NOT NULL
		);
		CREATE INDEX idx_web_session_open ON web_session(open_id);
		CREATE INDEX idx_web_session_expires ON web_session(expires_at);

		CREATE TABLE session_owner (
			session_id  TEXT PRIMARY KEY,
			open_id     TEXT NOT NULL,
			source      TEXT NOT NULL,
			created_at  INTEGER NOT NULL
		);
		CREATE INDEX idx_session_owner_user ON session_owner(open_id);

		CREATE TABLE oauth_state (
			state       TEXT PRIMARY KEY,
			return_to   TEXT NOT NULL DEFAULT '/',
			created_at  INTEGER NOT NULL
		);
		CREATE INDEX idx_oauth_state_age ON oauth_state(created_at);
	`,
};
