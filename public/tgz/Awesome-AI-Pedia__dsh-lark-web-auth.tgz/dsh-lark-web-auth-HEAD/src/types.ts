/**
 * Shared types for dsh-lark-web-auth. No runtime code — every value
 * declaration lives elsewhere.
 */

/** Plugin config after Cordis Config parsing. */
export interface AuthConfig {
	/** Master switch. Load with `false` to no-op (useful in test/dev). */
	enabled: boolean;
	/** Feishu self-built app credentials. */
	appId: string;
	appSecret: string;
	/** Public https URL (matches redirect URI registered in Lark console). */
	publicBaseUrl: string;
	/** Cookie signing/HMAC secret. */
	cookieSecret: string;
	/** SQLite file path; empty falls back to `~/.dsh/lark-web-auth.sqlite`. */
	dbPath: string;
	/** Login cookie lifetime. */
	cookieTtlDays: number;
	/** Lark region — controls OAuth base URL. */
	domain: "feishu" | "lark";
}

/** Row of `web_session` — one httpOnly cookie ↔ one logged-in user. */
export interface WebSessionRow {
	token: string;
	openId: string;
	name: string;
	avatarUrl: string;
	createdAt: number;
	expiresAt: number;
}

/** Row of `session_owner` — one DSH session ↔ its owning open_id. */
export interface SessionOwnerRow {
	sessionId: string;
	openId: string;
	source: "lark-bot" | "web" | "backfill";
	createdAt: number;
}

/** Row of `oauth_state` — one in-flight OAuth authorize ↔ CSRF nonce. */
export interface OAuthStateRow {
	state: string;
	returnTo: string;
	createdAt: number;
}

/** Feishu userinfo fields we depend on. */
export interface LarkUserInfo {
	openId: string;
	name: string;
	avatarUrl: string;
}

/** Per-request auth context, propagated via AsyncLocalStorage. */
export interface AuthContext {
	openId: string;
	name: string;
}
