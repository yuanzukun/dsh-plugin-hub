/**
 * SPA HTML injection — the in-page snippet that turns the harness Web GUI
 * into a login-aware app WITHOUT touching frontend source. Two behaviours:
 *
 *   1. Global `fetch` interceptor: on 401 from any `/api/*` call, redirect
 *      the whole page to `/auth/lark/login?return_to=<current>`. This is what
 *      pops the login flow when a user opens the page (or their cookie
 *      expires mid-session).
 *
 *   2. Top-right user badge: fetch `/auth/lark/me` on load; if present, render
 *      a small floating chip with the user's name/avatar and a logout button.
 *
 * Everything runs from one `<script>` tag injected before `</head>` via
 * `webServer.tapIndex`. No external asset loads, no dependency on frontend
 * bundle internals.
 */

/**
 * Build the injectable HTML fragment. The template is a plain string — no
 * user-controlled interpolation happens (the config toggles are read from
 * `/auth/lark/me` at runtime), so no escaping concerns.
 */
export function buildLoginInjection(): string {
	return `<script>(function(){
	if (window.__larkWebAuthInstalled) return;
	window.__larkWebAuthInstalled = true;

	// --- 1. network interceptors: 401 → redirect to login ----------------
	function currentReturnTo() {
		return encodeURIComponent(location.pathname + location.search + location.hash);
	}

	function shouldRedirectForUrl(raw) {
		try {
			var url = new URL(raw || location.href, location.href);
			if (url.origin !== location.origin) return false;
			if (url.pathname.indexOf('/auth/lark/login') === 0) return false;
			if (url.pathname.indexOf('/auth/lark/callback') === 0) return false;
			if (url.pathname.indexOf('/auth/lark/logout') === 0) return false;
			return true;
		} catch (e) {
			return true;
		}
	}

	function inputUrl(input) {
		if (typeof input === 'string') return input;
		if (input && input.url) return input.url;
		return location.href;
	}

	function redirectToLogin(rawUrl) {
		if (!shouldRedirectForUrl(rawUrl)) return;
		if (window.__larkWebAuthRedirecting) return;
		window.__larkWebAuthRedirecting = true;
		location.href = '/auth/lark/login?return_to=' + currentReturnTo();
	}

	var originalFetch = window.fetch.bind(window);
	window.fetch = function(input, init) {
		return originalFetch(input, init).then(function(res) {
			try {
				if (res.status === 401) redirectToLogin(inputUrl(input));
			} catch (e) { /* swallow */ }
			return res;
		});
	};

	if (typeof XMLHttpRequest !== 'undefined') {
		var OriginalXHR = XMLHttpRequest;
		window.XMLHttpRequest = function() {
			var xhr = new OriginalXHR();
			var requestUrl = location.href;
			var originalOpen = xhr.open;
			xhr.open = function(method, url) {
				requestUrl = url || location.href;
				return originalOpen.apply(xhr, arguments);
			};
			xhr.addEventListener('loadend', function() {
				try {
					if (xhr.status === 401) redirectToLogin(requestUrl);
				} catch (e) { /* swallow */ }
			});
			return xhr;
		};
		window.XMLHttpRequest.prototype = OriginalXHR.prototype;
	}

	// --- 2. user badge in top-right --------------------------------------
	function h(tag, attrs, children) {
		var el = document.createElement(tag);
		if (attrs) for (var k in attrs) {
			if (k === 'style') el.setAttribute('style', attrs[k]);
			else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), attrs[k]);
			else el.setAttribute(k, attrs[k]);
		}
		if (children) for (var i = 0; i < children.length; i++) {
			var c = children[i];
			el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
		}
		return el;
	}

	function mountBadge(user) {
		var badge = h('div', {
			id: 'lark-web-auth-badge',
			style: [
				'position:fixed', 'top:12px', 'right:12px',
				'z-index:2147483647',
				'display:flex', 'align-items:center', 'gap:8px',
				'padding:6px 12px',
				'background:rgba(20,20,28,0.85)',
				'color:#fff',
				'border-radius:20px',
				'font:12px/1 system-ui,-apple-system,sans-serif',
				'box-shadow:0 2px 8px rgba(0,0,0,0.2)',
				'backdrop-filter:blur(8px)',
			].join(';'),
		}, [
			user.avatarUrl ? h('img', {
				src: user.avatarUrl,
				style: 'width:20px;height:20px;border-radius:50%',
			}) : document.createTextNode(''),
			h('span', {}, [user.name || user.openId.slice(0, 8)]),
			h('button', {
				style: [
					'background:transparent', 'border:1px solid rgba(255,255,255,0.3)',
					'color:#fff', 'padding:2px 8px', 'border-radius:10px',
					'cursor:pointer', 'font-size:11px',
				].join(';'),
				onclick: function() {
					fetch('/auth/lark/logout', { method: 'POST' }).then(function() {
						location.href = '/auth/lark/login';
					});
				},
			}, ['退出']),
		]);
		document.body.appendChild(badge);
	}

	function loadBadge() {
		fetch('/auth/lark/me', { credentials: 'same-origin' })
			.then(function(r) { return r.ok ? r.json() : null; })
			.then(function(user) { if (user && user.openId) mountBadge(user); })
			.catch(function() { /* silent */ });
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', loadBadge);
	} else {
		loadBadge();
	}
})();</script>`;
}

/**
 * Inject the login snippet into an index.html body. Prefers inserting before
 * `</head>` for early fetch-interceptor install; falls back to `</body>` if
 * head isn't found, and appends at end as a last resort.
 */
export function injectIntoIndex(html: string): string {
	const snippet = buildLoginInjection();
	if (html.includes("</head>")) return html.replace("</head>", `${snippet}</head>`);
	if (html.includes("</body>")) return html.replace("</body>", `${snippet}</body>`);
	return html + snippet;
}
