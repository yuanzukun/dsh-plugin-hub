const LARK_LINK_PREFIX = "lark-link";

/**
 * dsh-lark-link session ids are built as:
 *   lark-link:${sessionKey}:${runNonce}:${generation}
 *
 * The sessionKey itself may contain colons, for example `dm:${chatId}`.
 */
export function larkLinkSessionKeyFromSessionId(sessionId: string): string | undefined {
	const parts = sessionId.split(":");
	if (parts[0] !== LARK_LINK_PREFIX || parts.length < 4) return undefined;
	return parts.slice(1, -2).join(":") || undefined;
}

/** Return the Feishu/Lark P2P chat id encoded by `dm:${chatId}` keys. */
export function p2pChatIdFromLarkLinkSessionKey(sessionKey: string): string | undefined {
	if (!sessionKey.startsWith("dm:")) return undefined;
	const chatId = sessionKey.slice("dm:".length);
	return chatId || undefined;
}

/** Extract the P2P chat id directly from a dsh-lark-link session id. */
export function p2pChatIdFromLarkLinkSessionId(sessionId: string): string | undefined {
	const sessionKey = larkLinkSessionKeyFromSessionId(sessionId);
	return sessionKey === undefined ? undefined : p2pChatIdFromLarkLinkSessionKey(sessionKey);
}
