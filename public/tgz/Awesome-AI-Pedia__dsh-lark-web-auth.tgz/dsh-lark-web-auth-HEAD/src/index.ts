/**
 * dsh-lark-web-auth — plugin entry.
 *
 * Wires:
 *   - config parsing & fail-fast validation
 *   - SQLite open + migrate
 *   - OAuth handlers under `/auth/lark/*` (registered on ctx.webServer)
 *   - index.html injection (fetch interceptor + user badge)
 *   - apiProxy method patches (owner-based filtering & 404-on-forbidden)
 *   - session/created listener (auto-owner assignment for new sessions)
 *   - one-shot backfill scan for pre-existing sessions
 *
 * Load order matters: this plugin MUST be inserted AFTER `api-remotes` in the
 * bundle patch (already enforced by the shipped cordis.patch.yml).
 */

import type { Context } from "@deepseek-ai/cordis";
import type { IncomingMessage, ServerResponse } from "node:http";
import type { RawConfig } from "./config.ts";
import { installApiAuthWrapper } from "./api-auth-wrapper.ts";
import { parseConfig } from "./config.ts";
import { openDb } from "./db.ts";
import { runBackfill } from "./backfill.ts";
import { injectIntoIndex } from "./index-injection.ts";
import { createLarkClient } from "./lark-api.ts";
import { createOAuthHandlers } from "./oauth.ts";
import { installOwnerFiltersWithClock, type PatchableApiProxy } from "./owner-filter.ts";
import { createOwnerStore } from "./owner-store.ts";
import { installOwnerTracker } from "./owner-tracker.ts";
import { createSessionStore } from "./session-store.ts";

export const name = "dsh-lark-web-auth";

/**
 * We do not declare `inject` at the top level because the plugin STARTS with
 * webServer alone and reaches optional services (`apiProxy`, `sessionPersistence`)
 * asynchronously — `ctx.inject(['apiProxy'], ...)` inside `apply()`.
 */
export const inject: string[] = ["webServer"];

/** Plugin config — passed through from cordis.yml / bundle patch. */
export type Config = RawConfig;

/**
 * Cordis plugin apply. Returns nothing; all cleanup is registered with
 * `ctx.effect()` / `ctx.on()` disposers so plugin dispose is clean.
 */
export function apply(ctx: Context, rawConfig: Config): void {
	const logger = {
		info(msg: string) {
			process.stdout.write(`[${new Date().toISOString()}] [INFO] ${msg}\n`);
		},
		warn(msg: string) {
			process.stdout.write(`[${new Date().toISOString()}] [WARN] ${msg}\n`);
		},
	};

	const config = parseConfig(rawConfig ?? {});
	if (!config.enabled) {
		logger.info("disabled by config");
		return;
	}

	// --- infra ---------------------------------------------------------------
	const db = openDb(config.dbPath);
	ctx.effect(() => () => db.close());

	const sessionStore = createSessionStore(db);
	const ownerStore = createOwnerStore(db);
	const lark = createLarkClient({
		appId: config.appId,
		appSecret: config.appSecret,
		domain: config.domain,
	});
	const now = () => Date.now();

	// --- OAuth routes (public — no auth wrapper) -----------------------------
	const oauth = createOAuthHandlers({ config, store: sessionStore, lark, now });

	const registerRoute = (
		path: string,
		handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>,
	): void => {
		ctx.effect(() =>
			(ctx as unknown as {
				webServer: { register(r: { kind: "exact"; path: string; handler: typeof handler }): () => void };
			}).webServer.register({ kind: "exact", path, handler }),
		);
	};

	registerRoute("/auth/lark/login", (req, res) => oauth.loginRedirect(req, res));
	registerRoute("/auth/lark/callback", (req, res) => oauth.callback(req, res));
	registerRoute("/auth/lark/logout", (req, res) => {
		if (req.method !== "POST") {
			res.statusCode = 405;
			res.end();
			return;
		}
		oauth.logout(req, res);
	});
	registerRoute("/auth/lark/me", (req, res) => oauth.me(req, res));

	// --- Guard dsh's existing /api carrier and WebSocket downlinks -----------
	ctx.effect(() =>
		installApiAuthWrapper(
			(ctx as unknown as {
				webServer: Parameters<typeof installApiAuthWrapper>[0];
			}).webServer,
			{ store: sessionStore, now },
		),
	);

	// --- Inject SPA HTML tap --------------------------------------------------
	ctx.effect(() =>
		(ctx as unknown as { webServer: { tapIndex(fn: (html: string) => string): () => void } })
			.webServer.tapIndex(injectIntoIndex),
	);

	// --- Owner tracker (listens for new sessions across the whole process) ---
	ctx.effect(() => installOwnerTracker(ctx, { owners: ownerStore, lark, now, ...(logger ? { logger } : {}) }));

	// --- apiProxy method patches + one-shot backfill (optional services) -----
	ctx.inject(["apiProxy"], (proxyCtx) => {
		const apiProxy = (proxyCtx as unknown as { apiProxy: PatchableApiProxy }).apiProxy;
		proxyCtx.effect(() => installOwnerFiltersWithClock(apiProxy, ownerStore, now));
	});

	// --- Backfill: fire once at load, do not block apply() --------------------
	void (async () => {
		try {
			await runBackfill(ctx, { owners: ownerStore, lark, now, ...(logger ? { logger } : {}) });
		} catch (err) {
			logger.warn(
				`backfill failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	})();

	// --- Periodic GC of expired login rows and stale OAuth states ------------
	const gcInterval = setInterval(() => {
		try {
			sessionStore.gcExpired(now());
			sessionStore.gcOAuthStates(now());
		} catch (err) {
			logger.warn(
				`gc failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	}, 60 * 60 * 1000); // hourly
	gcInterval.unref();
	ctx.effect(() => () => clearInterval(gcInterval));

	logger.info(
		`ready — publicBaseUrl=${config.publicBaseUrl} dbPath=${config.dbPath}`,
	);
}
