/**
 * Thin wrapper over Feishu / Lark REST APIs — only the endpoints this plugin
 * touches. Uses global `fetch` (Node 22+); no axios dependency to keep the
 * install lean.
 *
 * Docs:
 *   OAuth 2.0 for user access — https://open.feishu.cn/document/uAjLw4CM/ukTMukTMukTM/authentication-management/login-state-management
 *   Tenant access token —      https://open.feishu.cn/document/server-docs/authentication-management/access-token/tenant_access_token_internal
 *   Get chat info —            https://open.feishu.cn/document/server-docs/group/chat/get
 */

import type { LarkUserInfo } from "./types.ts";

/** Base URLs per region. */
const BASE_URL = {
	feishu: "https://open.feishu.cn",
	lark: "https://open.larksuite.com",
} as const;

/** Client bound to one Feishu app credential pair + region. */
export interface LarkClient {
	/** Build the browser-facing OAuth authorize URL. */
	authorizeUrl(redirectUri: string, state: string): string;
	/** Exchange an authorize code for the end-user's access token. */
	exchangeCode(code: string, redirectUri: string): Promise<{ userAccessToken: string; expiresIn: number }>;
	/** Fetch the logged-in user's basic profile. */
	userInfo(userAccessToken: string): Promise<LarkUserInfo>;
	/**
	 * Given a P2P chat_id, return the peer user's open_id. Used by backfill to
	 * translate `dm:${chatId}` session keys into owners. Requires a tenant
	 * access token (self-fetched, cached until expiry). Returns undefined on
	 * any non-P2P chat or failure.
	 */
	openIdForP2pChat(chatId: string): Promise<string | undefined>;
}

/** Config the client needs. */
export interface LarkClientDeps {
	appId: string;
	appSecret: string;
	domain: "feishu" | "lark";
	/** Optional injected fetch — tests pass a mock; production uses global fetch. */
	fetchImpl?: typeof fetch;
}

/**
 * Construct a LarkClient. The tenant token cache lives per instance — dispose
 * the plugin, dispose the client, drop the cache.
 */
export function createLarkClient(deps: LarkClientDeps): LarkClient {
	const base = BASE_URL[deps.domain];
	const doFetch: typeof fetch = deps.fetchImpl ?? fetch;

	let tenantToken: { token: string; expiresAt: number } | undefined;

	async function tenantAccessToken(now: number): Promise<string> {
		if (tenantToken && tenantToken.expiresAt > now + 60_000) return tenantToken.token;
		const res = await doFetch(`${base}/open-apis/auth/v3/tenant_access_token/internal`, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({ app_id: deps.appId, app_secret: deps.appSecret }),
		});
		if (!res.ok) throw new Error(`tenant_access_token http ${res.status}`);
		const json = (await res.json()) as { code: number; msg: string; tenant_access_token?: string; expire?: number };
		if (json.code !== 0 || !json.tenant_access_token) {
			throw new Error(`tenant_access_token failed: code=${json.code} msg=${json.msg}`);
		}
		tenantToken = {
			token: json.tenant_access_token,
			expiresAt: now + (json.expire ?? 7200) * 1000,
		};
		return tenantToken.token;
	}

	return {
		authorizeUrl(redirectUri, state) {
			const params = new URLSearchParams({
				app_id: deps.appId,
				redirect_uri: redirectUri,
				state,
			});
			return `${base}/open-apis/authen/v1/authorize?${params.toString()}`;
		},

		async exchangeCode(code, redirectUri) {
			const res = await doFetch(`${base}/open-apis/authen/v2/oauth/token`, {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify({
					grant_type: "authorization_code",
					client_id: deps.appId,
					client_secret: deps.appSecret,
					code,
					redirect_uri: redirectUri,
				}),
			});
			if (!res.ok) throw new Error(`oauth token http ${res.status}`);
			const json = (await res.json()) as {
				code?: number;
				error?: string;
				error_description?: string;
				access_token?: string;
				expires_in?: number;
			};
			if (json.error || !json.access_token) {
				throw new Error(`oauth token failed: ${json.error ?? "unknown"} ${json.error_description ?? ""}`);
			}
			return {
				userAccessToken: json.access_token,
				expiresIn: json.expires_in ?? 7200,
			};
		},

		async userInfo(userAccessToken) {
			const res = await doFetch(`${base}/open-apis/authen/v1/user_info`, {
				headers: { authorization: `Bearer ${userAccessToken}` },
			});
			if (!res.ok) throw new Error(`user_info http ${res.status}`);
			const json = (await res.json()) as {
				code: number;
				msg: string;
				data?: { open_id?: string; name?: string; avatar_url?: string };
			};
			if (json.code !== 0 || !json.data?.open_id) {
				throw new Error(`user_info failed: code=${json.code} msg=${json.msg}`);
			}
			return {
				openId: json.data.open_id,
				name: json.data.name ?? "",
				avatarUrl: json.data.avatar_url ?? "",
			};
		},

		async openIdForP2pChat(chatId) {
			const token = await tenantAccessToken(Date.now());
			const res = await doFetch(
				`${base}/open-apis/im/v1/chats/${encodeURIComponent(chatId)}?user_id_type=open_id`,
				{ headers: { authorization: `Bearer ${token}` } },
			);
			if (!res.ok) return undefined;
			const json = (await res.json()) as {
				code: number;
				data?: { chat_mode?: string; owner_id?: string; chat_type?: string };
			};
			if (json.code !== 0) return undefined;
			// P2P: owner_id is the peer (from the bot's perspective).
			if (json.data?.chat_mode !== "p2p") return undefined;
			return json.data.owner_id;
		},
	};
}
