/**
 * Listen for new-session Cordis events and record ownership under the caller's
 * open_id. Two code paths reach here:
 *
 *   1. Web GUI creates a session (via `api.sessions.create`) — the request
 *      handler runs inside an ALS frame set by our auth middleware, so
 *      `getAuthContext()` returns the caller.
 *
 *   2. dsh-lark-link creates a session for an inbound Feishu message — no ALS
 *      frame, but the session's Cordis id / initiator has a `dm:${chatId}`
 *      shape that we can reverse-map to an open_id via the async Lark API.
 *
 * The event carries the full `Session` object (see
 * packages/core/session/src/index.ts:54).
 */

import type { Context } from "@deepseek-ai/cordis";
import type { Session } from "@deepseek-ai/dsh-session";
import type { LarkClient } from "./lark-api.ts";
import { p2pChatIdFromLarkLinkSessionId } from "./lark-link-session.ts";
import { getAuthContext } from "./middleware.ts";
import type { OwnerStore } from "./owner-store.ts";

/** Deps for `installOwnerTracker`. */
export interface OwnerTrackerDeps {
	owners: OwnerStore;
	lark: LarkClient;
	now: () => number;
	/** Logger sink — plugin passes ctx.logger. */
	logger?: { info(msg: string): void; warn(msg: string): void };
}

/**
 * Attempt to extract a `dm:${chatId}` conversation key from a session's
 * initiator / metadata. dsh-lark-link's dsh-adapter constructs session ids
 * as `lark-link:${convKey}:${runNonce}:${generation}`. We try explicit header
 * metadata first, then parse the session id.
 */
function detectLarkChatId(session: Session): string | undefined {
	const header = session.header as unknown as { larkChatId?: unknown };
	if (typeof header.larkChatId === "string") return header.larkChatId;
	return p2pChatIdFromLarkLinkSessionId(String(session.header.id));
}

/**
 * Install a `session/created` listener that claims ownership. Returns a
 * disposer that removes the listener.
 */
export function installOwnerTracker(ctx: Context, deps: OwnerTrackerDeps): () => void {
	const disposer = ctx.on(
		"session/created" as never,
		((session: Session) => {
			const sessionId = session.header.id as unknown as string;
			if (deps.owners.ownerOf(sessionId) !== undefined) return; // already claimed

			// Path 1: web request context — synchronous, cheap.
			const auth = getAuthContext();
			if (auth) {
				deps.owners.claim(sessionId, auth.openId, "web", deps.now());
				return;
			}

			// Path 2: lark-link — async reverse lookup, fire-and-forget.
			const chatId = detectLarkChatId(session);
			if (chatId === undefined) return; // unknown origin — leave unowned

			void (async () => {
				try {
					const openId = await deps.lark.openIdForP2pChat(chatId);
					if (openId) deps.owners.claim(sessionId, openId, "lark-bot", deps.now());
				} catch (err) {
					deps.logger?.warn?.(
						`[lark-web-auth] failed to resolve owner for lark session ${sessionId}: ${
							err instanceof Error ? err.message : String(err)
						}`,
					);
				}
			})();
		}) as never,
		// Global listener — fires for every session in the process, not just
		// those inside a particular Scope.
		{ global: true } as never,
	);
	return () => {
		if (typeof disposer === "function") disposer();
	};
}
