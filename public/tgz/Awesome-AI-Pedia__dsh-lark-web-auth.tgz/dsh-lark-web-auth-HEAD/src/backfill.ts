/**
 * Startup one-shot backfill: assigns owners to sessions that already exist
 * before the plugin was loaded. Two sources:
 *
 *   - `ctx.sessionPersistence.list()` returns every cold session header
 *   - dsh-lark-link's persisted route store links each `dm:${chatId}` session
 *     key to its Feishu chat metadata
 *
 * For each unowned session id we derive the lark chat_id from lark-link's
 * session id/route store, then reverse-map chat_id → open_id via the Feishu
 * API and record ownership under `source='backfill'`.
 *
 * This is BEST-EFFORT: a session whose owner we cannot resolve stays unowned
 * (invisible to everyone until a maintainer assigns it). We log a count.
 */

import { existsSync, readFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import type { Context } from "@deepseek-ai/cordis";
import type { LarkClient } from "./lark-api.ts";
import { larkLinkSessionKeyFromSessionId, p2pChatIdFromLarkLinkSessionKey } from "./lark-link-session.ts";
import type { OwnerStore } from "./owner-store.ts";

/** Deps for `runBackfill`. */
export interface BackfillDeps {
	owners: OwnerStore;
	lark: LarkClient;
	now: () => number;
	logger?: { info(msg: string): void; warn(msg: string): void };
}

/**
 * lark-link persists per-chat routing state in its own state directory. The
 * route's `sessionKey` is the stable key embedded inside each DSH session id.
 */
interface LarkLinkRoute {
	sessionKey: string;
	chatId?: string;
	chatType?: string;
}

function larkLinkRoutesPath(): string {
	const dshHome = process.env.DSH_HOME ?? join(homedir(), ".dsh");
	return join(process.env.DSH_LARK_LINK_HOME ?? join(dshHome, "lark-link"), "routes.json");
}

function readLarkLinkRoutes(path = larkLinkRoutesPath()): Map<string, LarkLinkRoute> {
	if (!existsSync(path)) return new Map();
	const raw = JSON.parse(readFileSync(path, "utf8")) as unknown;
	if (!Array.isArray(raw)) return new Map();
	const routes = new Map<string, LarkLinkRoute>();
	for (const item of raw) {
		if (typeof item !== "object" || item === null) continue;
		const route = item as Record<string, unknown>;
		if (typeof route.sessionKey !== "string") continue;
		routes.set(route.sessionKey, {
			sessionKey: route.sessionKey,
			...(typeof route.chatId === "string" ? { chatId: route.chatId } : {}),
			...(typeof route.chatType === "string" ? { chatType: route.chatType } : {}),
		});
	}
	return routes;
}

/**
 * Read the lark-link live backend mapping if the plugin exposes it on ctx.
 * New conversations are also reversible from their session id, so this only
 * gives a slightly more direct path for currently tracked sessions.
 */
function tryReadLiveLarkSessionKey(ctx: Context, sessionId: string): string | undefined {
	// Look for common shapes lark-link might publish under. Use `ctx.get()`
	// exclusively — direct property access (ctx.larkLink) fails in strict mode
	// unless declared in `inject`, which we cannot do for optional siblings.
	const getFn = (ctx as unknown as { get?: (name: string) => unknown }).get;
	const larkService = typeof getFn === "function"
		? (getFn.call(ctx, "larkLink") ?? getFn.call(ctx, "lark"))
		: undefined;
	if (larkService === undefined) return undefined;
	const backend = (larkService as Record<string, unknown>).backend;
	if (!backend) return undefined;
	// If backend has a `keyForSessionId(sessionId): string | undefined`, we can
	// walk all persisted session ids and invert it. Fallback: no mapping.
	const keyFor = (backend as Record<string, unknown>).keyForSessionId;
	if (typeof keyFor !== "function") return undefined;

	const key = keyFor.call(backend, sessionId);
	return typeof key === "string" ? key : undefined;
}

function larkChatIdForSession(ctx: Context, sessionId: string, routes: Map<string, LarkLinkRoute>): string | undefined {
	const sessionKey = tryReadLiveLarkSessionKey(ctx, sessionId) ?? larkLinkSessionKeyFromSessionId(sessionId);
	if (sessionKey === undefined) return undefined;
	const route = routes.get(sessionKey);
	if (route !== undefined) {
		if (route.chatType !== undefined && route.chatType !== "p2p") return undefined;
		if (route.chatId) return route.chatId;
	}
	return p2pChatIdFromLarkLinkSessionKey(sessionKey);
}

/**
 * Run the backfill scan. Returns a summary count for logging.
 * Safe to call on every startup: `INSERT OR IGNORE` in owner-store makes it
 * idempotent.
 */
export async function runBackfill(ctx: Context, deps: BackfillDeps): Promise<{
	scanned: number;
	claimed: number;
	skipped: number;
}> {
	const persistence = ctx.get?.("sessionPersistence");
	if (persistence === undefined) {
		deps.logger?.info?.("[lark-web-auth] backfill: sessionPersistence not available, skipping");
		return { scanned: 0, claimed: 0, skipped: 0 };
	}

	let routes: Map<string, LarkLinkRoute>;
	try {
		routes = readLarkLinkRoutes();
	} catch (err) {
		deps.logger?.warn?.(
			`[lark-web-auth] backfill: failed to read lark-link routes: ${
				err instanceof Error ? err.message : String(err)
			}`,
		);
		routes = new Map();
	}

	let scanned = 0;
	let claimed = 0;
	let skipped = 0;
	const headers = await (persistence as { list: () => Promise<Array<{ id: string }>> }).list();
	for (const header of headers) {
		scanned++;
		const sessionId = header.id;
		if (deps.owners.ownerOf(sessionId) !== undefined) continue;

		// Try to derive the lark chat_id from lark-link's route store/session id.
		const chatId = larkChatIdForSession(ctx, sessionId, routes);
		if (chatId === undefined) {
			skipped++;
			continue;
		}
		try {
			const openId = await deps.lark.openIdForP2pChat(chatId);
			if (openId) {
				deps.owners.claim(sessionId, openId, "backfill", deps.now());
				claimed++;
			} else {
				skipped++;
			}
		} catch (err) {
			deps.logger?.warn?.(
				`[lark-web-auth] backfill: failed to resolve owner for ${sessionId}: ${
					err instanceof Error ? err.message : String(err)
				}`,
			);
			skipped++;
		}
	}

	deps.logger?.info?.(
		`[lark-web-auth] backfill complete: scanned=${scanned} claimed=${claimed} skipped=${skipped}`,
	);
	return { scanned, claimed, skipped };
}
