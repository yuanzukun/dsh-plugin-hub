/**
 * `web_session` table access — the cookie ↔ open_id mapping. Also owns:
 *  - fresh random token generation (256 bits from crypto),
 *  - expired-row garbage collection (called opportunistically on lookup),
 *  - OAuth state (CSRF nonce) create/consume — small enough to live here.
 */

import { randomBytes } from "node:crypto";
import type { Db } from "./db.ts";
import type { LarkUserInfo, OAuthStateRow, WebSessionRow } from "./types.ts";

/** OAuth `state` param TTL — a browser must complete the round-trip within this. */
export const OAUTH_STATE_TTL_MS = 10 * 60 * 1000;

/** Store facade over `web_session` + `oauth_state` tables. */
export interface SessionStore {
	/** Generate a fresh cookie token and persist a login row. */
	create(user: LarkUserInfo, ttlMs: number, now: number): string;
	/** Look up a login by cookie token. Returns undefined if missing or expired. */
	find(token: string, now: number): WebSessionRow | undefined;
	/** Delete a login row (logout). Idempotent. */
	revoke(token: string): void;
	/** Delete all expired login rows. Returns count. */
	gcExpired(now: number): number;

	/** Persist a new OAuth state nonce and its return_to path. */
	createOAuthState(returnTo: string, now: number): string;
	/** Consume an OAuth state — returns the row iff present and unexpired, then deletes it. */
	consumeOAuthState(state: string, now: number): OAuthStateRow | undefined;
	/** Drop stale unfinished OAuth flows. */
	gcOAuthStates(now: number): number;
}

/** Generate a URL-safe random token. 32 bytes = 256 bits of entropy. */
function randomToken(): string {
	return randomBytes(32).toString("base64url");
}

/** Row mapper — snake_case columns to camelCase fields. */
function toWebSession(row: {
	token: string;
	open_id: string;
	name: string;
	avatar_url: string;
	created_at: number;
	expires_at: number;
}): WebSessionRow {
	return {
		token: row.token,
		openId: row.open_id,
		name: row.name,
		avatarUrl: row.avatar_url,
		createdAt: row.created_at,
		expiresAt: row.expires_at,
	};
}

/** Row mapper for `oauth_state`. */
function toOAuthState(row: {
	state: string;
	return_to: string;
	created_at: number;
}): OAuthStateRow {
	return {
		state: row.state,
		returnTo: row.return_to,
		createdAt: row.created_at,
	};
}

/** Construct a SessionStore over an already-opened Db. */
export function createSessionStore(db: Db): SessionStore {
	const insertLogin = db.raw.prepare<[string, string, string, string, number, number]>(`
		INSERT INTO web_session (token, open_id, name, avatar_url, created_at, expires_at)
		VALUES (?, ?, ?, ?, ?, ?)
	`);
	const selectLogin = db.raw.prepare<[string]>(`
		SELECT token, open_id, name, avatar_url, created_at, expires_at
		FROM web_session WHERE token = ?
	`);
	const deleteLogin = db.raw.prepare<[string]>(`DELETE FROM web_session WHERE token = ?`);
	const deleteExpiredLogins = db.raw.prepare<[number]>(`DELETE FROM web_session WHERE expires_at <= ?`);

	const insertState = db.raw.prepare<[string, string, number]>(`
		INSERT INTO oauth_state (state, return_to, created_at) VALUES (?, ?, ?)
	`);
	const selectState = db.raw.prepare<[string]>(`
		SELECT state, return_to, created_at FROM oauth_state WHERE state = ?
	`);
	const deleteState = db.raw.prepare<[string]>(`DELETE FROM oauth_state WHERE state = ?`);
	const deleteExpiredStates = db.raw.prepare<[number]>(`DELETE FROM oauth_state WHERE created_at <= ?`);

	return {
		create(user, ttlMs, now) {
			const token = randomToken();
			insertLogin.run(token, user.openId, user.name, user.avatarUrl, now, now + ttlMs);
			return token;
		},
		find(token, now) {
			const raw = selectLogin.get(token) as
				| { token: string; open_id: string; name: string; avatar_url: string; created_at: number; expires_at: number }
				| undefined;
			if (!raw) return undefined;
			if (raw.expires_at <= now) {
				// Opportunistic cleanup of this specific expired row.
				deleteLogin.run(token);
				return undefined;
			}
			return toWebSession(raw);
		},
		revoke(token) {
			deleteLogin.run(token);
		},
		gcExpired(now) {
			const info = deleteExpiredLogins.run(now);
			return info.changes;
		},

		createOAuthState(returnTo, now) {
			const state = randomToken();
			insertState.run(state, returnTo, now);
			return state;
		},
		consumeOAuthState(state, now) {
			const raw = selectState.get(state) as
				| { state: string; return_to: string; created_at: number }
				| undefined;
			if (!raw) return undefined;
			// Always delete on consume — even expired, so a re-play returns undefined.
			deleteState.run(state);
			if (now - raw.created_at > OAUTH_STATE_TTL_MS) return undefined;
			return toOAuthState(raw);
		},
		gcOAuthStates(now) {
			const info = deleteExpiredStates.run(now - OAUTH_STATE_TTL_MS);
			return info.changes;
		},
	};
}
