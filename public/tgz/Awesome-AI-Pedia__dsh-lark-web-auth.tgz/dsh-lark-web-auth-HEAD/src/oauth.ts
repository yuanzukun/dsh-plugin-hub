/**
 * OAuth HTTP handlers — the four routes users hit during a login round-trip:
 *
 *   GET  /auth/lark/login          → 302 to Feishu authorize
 *   GET  /auth/lark/callback       → exchange code, set cookie, 302 home
 *   POST /auth/lark/logout         → clear cookie, delete row
 *   GET  /auth/lark/me             → JSON `{openId, name, avatarUrl}` or 401
 *
 * All routes are pure over their inputs — deps are injected so tests can
 * exercise the flow with a mock LarkClient and controlled clock.
 */

import type { IncomingMessage, ServerResponse } from "node:http";
import { serialize as serializeCookie, parse as parseCookie } from "cookie";
import type { LarkClient } from "./lark-api.ts";
import type { SessionStore } from "./session-store.ts";
import type { AuthConfig } from "./types.ts";

/** Cookie name — sent on every request the browser makes. */
export const COOKIE_NAME = "dsh_web_session";

/** Deps injected into each handler. */
export interface OAuthDeps {
	config: AuthConfig;
	store: SessionStore;
	lark: LarkClient;
	now: () => number;
}

/** Build the absolute redirect URI registered on the Feishu console. */
export function redirectUri(config: AuthConfig): string {
	return `${config.publicBaseUrl}/auth/lark/callback`;
}

/** Read the cookie token from a request; returns undefined if missing. */
export function readCookie(req: IncomingMessage): string | undefined {
	const header = req.headers["cookie"];
	if (!header) return undefined;
	const parsed = parseCookie(header);
	return parsed[COOKIE_NAME];
}

/** Build the `Set-Cookie` header for a new login. */
function buildSetCookie(token: string, ttlSeconds: number, secure: boolean): string {
	return serializeCookie(COOKIE_NAME, token, {
		httpOnly: true,
		secure,
		sameSite: "lax",
		path: "/",
		maxAge: ttlSeconds,
	});
}

/** Build the `Set-Cookie` header that clears the login cookie. */
function buildClearCookie(secure: boolean): string {
	return serializeCookie(COOKIE_NAME, "", {
		httpOnly: true,
		secure,
		sameSite: "lax",
		path: "/",
		maxAge: 0,
	});
}

/**
 * Validate a `return_to` param: must be a same-origin absolute path.
 * Prevents an open-redirect gadget (`/auth/lark/login?return_to=https://evil.com`).
 */
function safeReturnTo(raw: string | null): string {
	if (!raw) return "/";
	// Only accept root-relative paths, no scheme, no `//host` protocol-relative.
	if (raw.startsWith("/") && !raw.startsWith("//")) return raw;
	return "/";
}

/** Handler set — one per HTTP method+path pair. */
export interface OAuthHandlers {
	loginRedirect(req: IncomingMessage, res: ServerResponse): void;
	callback(req: IncomingMessage, res: ServerResponse): Promise<void>;
	logout(req: IncomingMessage, res: ServerResponse): void;
	me(req: IncomingMessage, res: ServerResponse): void;
}

/**
 * Build the four OAuth route handlers. `secureCookie` derives from
 * `publicBaseUrl` (https → true), so a dev http:// setup still works locally.
 */
export function createOAuthHandlers(deps: OAuthDeps): OAuthHandlers {
	const secureCookie = deps.config.publicBaseUrl.startsWith("https://");
	const ttlSeconds = deps.config.cookieTtlDays * 24 * 60 * 60;

	function loginRedirect(req: IncomingMessage, res: ServerResponse): void {
		const url = new URL(req.url ?? "/", "http://x");
		const returnTo = safeReturnTo(url.searchParams.get("return_to"));
		const state = deps.store.createOAuthState(returnTo, deps.now());
		const target = deps.lark.authorizeUrl(redirectUri(deps.config), state);
		res.statusCode = 302;
		res.setHeader("location", target);
		res.end();
	}

	async function callback(req: IncomingMessage, res: ServerResponse): Promise<void> {
		const url = new URL(req.url ?? "/", "http://x");
		const code = url.searchParams.get("code");
		const state = url.searchParams.get("state");
		const errorFromLark = url.searchParams.get("error");

		if (errorFromLark) {
			res.statusCode = 400;
			res.setHeader("content-type", "text/plain; charset=utf-8");
			res.end(`Feishu authorization failed: ${errorFromLark}`);
			return;
		}
		if (!code || !state) {
			res.statusCode = 400;
			res.setHeader("content-type", "text/plain; charset=utf-8");
			res.end("missing code or state");
			return;
		}
		const stateRow = deps.store.consumeOAuthState(state, deps.now());
		if (!stateRow) {
			res.statusCode = 400;
			res.setHeader("content-type", "text/plain; charset=utf-8");
			res.end("invalid or expired state");
			return;
		}

		let user;
		try {
			const { userAccessToken } = await deps.lark.exchangeCode(code, redirectUri(deps.config));
			user = await deps.lark.userInfo(userAccessToken);
		} catch (err) {
			res.statusCode = 502;
			res.setHeader("content-type", "text/plain; charset=utf-8");
			res.end(`Feishu API error: ${err instanceof Error ? err.message : String(err)}`);
			return;
		}

		const token = deps.store.create(user, ttlSeconds * 1000, deps.now());
		res.statusCode = 302;
		res.setHeader("location", stateRow.returnTo);
		res.setHeader("set-cookie", buildSetCookie(token, ttlSeconds, secureCookie));
		res.end();
	}

	function logout(req: IncomingMessage, res: ServerResponse): void {
		const token = readCookie(req);
		if (token) deps.store.revoke(token);
		res.statusCode = 204;
		res.setHeader("set-cookie", buildClearCookie(secureCookie));
		res.end();
	}

	function me(req: IncomingMessage, res: ServerResponse): void {
		const token = readCookie(req);
		const row = token ? deps.store.find(token, deps.now()) : undefined;
		if (!row) {
			res.statusCode = 401;
			res.setHeader("content-type", "application/json");
			res.end(JSON.stringify({ error: "not-logged-in" }));
			return;
		}
		res.statusCode = 200;
		res.setHeader("content-type", "application/json");
		res.end(JSON.stringify({
			openId: row.openId,
			name: row.name,
			avatarUrl: row.avatarUrl,
		}));
	}

	return { loginRedirect, callback, logout, me };
}
