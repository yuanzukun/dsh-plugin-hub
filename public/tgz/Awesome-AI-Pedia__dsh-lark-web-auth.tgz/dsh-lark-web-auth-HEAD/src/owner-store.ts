/**
 * `session_owner` table access — the DSH sessionId ↔ open_id mapping. This is
 * the ground truth for isolation: every lookup and list filter reads from here.
 *
 * Not merged with SessionStore because their lifecycles differ (session_owner
 * grows monotonically; web_session churns with login/logout/expiry).
 */

import type { Db } from "./db.ts";
import type { SessionOwnerRow } from "./types.ts";

/** Store facade over the `session_owner` table. */
export interface OwnerStore {
	/**
	 * Idempotent upsert of ownership. First writer wins; a second call with a
	 * different open_id for the same session is silently ignored (should not
	 * happen in practice — a session cannot change owner).
	 */
	claim(sessionId: string, openId: string, source: SessionOwnerRow["source"], now: number): void;
	/** Look up the owner of a session. Returns undefined for unowned sessions. */
	ownerOf(sessionId: string): string | undefined;
	/** Return all session ids owned by an open_id. */
	sessionsOf(openId: string): string[];
	/** Total ownership rows — for telemetry / diagnostics. */
	count(): number;
}

/** Construct an OwnerStore over an already-opened Db. */
export function createOwnerStore(db: Db): OwnerStore {
	// INSERT OR IGNORE — first writer wins, no error on duplicate.
	const insert = db.raw.prepare<[string, string, string, number]>(`
		INSERT OR IGNORE INTO session_owner (session_id, open_id, source, created_at)
		VALUES (?, ?, ?, ?)
	`);
	const selectOwner = db.raw.prepare<[string]>(`SELECT open_id FROM session_owner WHERE session_id = ?`);
	const selectByUser = db.raw.prepare<[string]>(`SELECT session_id FROM session_owner WHERE open_id = ?`);
	const selectCount = db.raw.prepare(`SELECT COUNT(*) as n FROM session_owner`);

	return {
		claim(sessionId, openId, source, now) {
			insert.run(sessionId, openId, source, now);
		},
		ownerOf(sessionId) {
			const row = selectOwner.get(sessionId) as { open_id: string } | undefined;
			return row?.open_id;
		},
		sessionsOf(openId) {
			const rows = selectByUser.all(openId) as Array<{ session_id: string }>;
			return rows.map((r) => r.session_id);
		},
		count() {
			const row = selectCount.get() as { n: number };
			return row.n;
		},
	};
}
