/**
 * Owner-based filtering for the `ctx.apiProxy` service. The strategy is
 * monkey-patching individual method references on `apiProxy.sessions`:
 *
 *   - `list`: filter items by owner
 *   - `history` / `models` / `selectModel` / `prompt` / `rename` / `cancel` /
 *     `fork` / `attachment` / `updateQueue`: check owner of `sessionId`;
 *     return `session-not-found` if not owned by current caller
 *   - `create`: allow, then on success record ownership under caller's open_id
 *   - `events.host` / `events.mux`: drop session-scoped live events for
 *     sessions the current caller does not own
 *
 * This runs INSIDE the API dispatch chain (see host-apiproxy handler.ts:91):
 *
 *   invoke: (api, r) => api.sessions.list(r)
 *
 * Every dispatch dereferences `api.sessions.list` fresh, so replacing that
 * property reference at plugin-load time redirects all future calls.
 *
 * Unauthenticated callers (no ALS auth) are always rejected with the SAME
 * `session-not-found` code as cross-owner access — no existence enumeration.
 */

import { getAuthContext } from "./middleware.ts";
import { larkLinkSessionKeyFromSessionId } from "./lark-link-session.ts";
import type { OwnerStore } from "./owner-store.ts";

/** `session-not-found` RPC shape emitted for both missing and forbidden. */
function notFound(req: AnyRequest, sessionId: unknown): AnyResponse {
	return {
		rpcId: req.rpcId,
		result: {
			ok: false,
			error: {
				code: "session-not-found",
				message: `session "${String(sessionId)}" not found`,
				details: { sessionId },
			},
		},
	};
}

/** Minimal request typing — we only touch `rpcId` and `payload.sessionId`. */
interface AnyRequest {
	rpcId?: unknown;
	payload?: { sessionId?: unknown };
}

/** Minimal response typing — we forward the concrete response verbatim. */
interface AnyResponse {
	rpcId?: unknown;
	result?: {
		ok?: boolean;
		value?: { items?: Array<{ sessionId?: unknown }>; sessionId?: unknown } | unknown;
		error?: unknown;
	};
}

type EventMethod = (...args: unknown[]) => AsyncIterable<unknown> | Promise<AsyncIterable<unknown>>;

/** The subset of apiProxy shape we care about. */
export interface PatchableApiProxy {
	sessions: {
		list: (req: AnyRequest) => Promise<AnyResponse>;
		history?: (req: AnyRequest) => Promise<AnyResponse>;
		models?: (req: AnyRequest) => Promise<AnyResponse>;
		selectModel?: (req: AnyRequest) => Promise<AnyResponse>;
		prompt?: (req: AnyRequest) => Promise<AnyResponse>;
		rename?: (req: AnyRequest) => Promise<AnyResponse>;
		cancel?: (req: AnyRequest) => Promise<AnyResponse>;
		fork?: (req: AnyRequest) => Promise<AnyResponse>;
		attachment?: (req: AnyRequest) => Promise<AnyResponse>;
		updateQueue?: (req: AnyRequest) => Promise<AnyResponse>;
		create?: (req: AnyRequest) => Promise<AnyResponse>;
		[key: string]: unknown;
	};
	events?: {
		host?: EventMethod;
		mux?: EventMethod;
		[key: string]: unknown;
	};
}

/** Methods that must reject requests targeting a session the caller does not own. */
const OWNED_METHODS = [
	"history",
	"models",
	"selectModel",
	"prompt",
	"rename",
	"cancel",
	"fork",
	"attachment",
	"updateQueue",
] as const;

const EVENT_OWNER_WAIT_MS = 1_000;
const EVENT_OWNER_POLL_MS = 25;

function delay(ms: number): Promise<void> {
	return new Promise((resolve) => setTimeout(resolve, ms));
}

function asObject(value: unknown): Record<string, unknown> | undefined {
	if (value === null || typeof value !== "object") return undefined;
	return value as Record<string, unknown>;
}

function sessionIdFromEventFrame(frame: unknown): string | undefined {
	const root = asObject(frame);
	const payload = asObject(root?.payload);
	if (typeof payload?.sessionId === "string") return payload.sessionId;
	const nestedPayload = asObject(payload?.payload);
	if (typeof nestedPayload?.sessionId === "string") return nestedPayload.sessionId;
	if (typeof root?.sessionId === "string") return root.sessionId;
	return undefined;
}

async function ownerOfAfterSettle(sessionId: string, owners: OwnerStore): Promise<string | undefined> {
	const deadline = Date.now() + EVENT_OWNER_WAIT_MS;
	let owner = owners.ownerOf(sessionId);
	while (owner === undefined && Date.now() < deadline) {
		await delay(EVENT_OWNER_POLL_MS);
		owner = owners.ownerOf(sessionId);
	}
	return owner;
}

async function shouldDeliverFrame(frame: unknown, openId: string | undefined, owners: OwnerStore): Promise<boolean> {
	const sessionId = sessionIdFromEventFrame(frame);
	if (sessionId === undefined) return true;
	if (openId === undefined) return false;
	return (await ownerOfAfterSettle(sessionId, owners)) === openId;
}

async function* filterEventFrames(
	source: AsyncIterable<unknown> | Promise<AsyncIterable<unknown>>,
	openId: string | undefined,
	owners: OwnerStore,
): AsyncIterable<unknown> {
	for await (const frame of await source) {
		if (await shouldDeliverFrame(frame, openId, owners)) yield frame;
	}
}

/**
 * Install owner filters on `apiProxy.sessions`. Returns a disposer that
 * restores original method references — so plugin dispose leaves the harness
 * in its pre-load state.
 */
export function installOwnerFilters(apiProxy: PatchableApiProxy, owners: OwnerStore): () => void {
	return installOwnerFiltersWithClock(apiProxy, owners, () => Date.now());
}

/**
 * Testable implementation of owner filters; production callers use
 * `installOwnerFilters()`.
 */
export function installOwnerFiltersWithClock(
	apiProxy: PatchableApiProxy,
	owners: OwnerStore,
	now: () => number,
): () => void {
	const originals = new Map<string, unknown>();
	const eventOriginals = new Map<"host" | "mux", EventMethod>();
	const larkCanonicalBySessionId = new Map<string, string>();

	// -- list: filter items by owner -----------------------------------------
	const originalList = apiProxy.sessions.list.bind(apiProxy.sessions);
	originals.set("list", apiProxy.sessions.list);
	function canonicalizeLarkItems(items: Array<{ sessionId?: unknown }>): Array<{ sessionId?: unknown }> {
		const canonicalByKey = new Map<string, string>();
		const visible: Array<{ sessionId?: unknown }> = [];
		for (const item of items) {
			const id = item.sessionId;
			if (typeof id !== "string") continue;
			const key = larkLinkSessionKeyFromSessionId(id);
			if (key === undefined) {
				visible.push(item);
				continue;
			}
			const canonical = canonicalByKey.get(key);
			if (canonical === undefined) {
				canonicalByKey.set(key, id);
				larkCanonicalBySessionId.set(id, id);
				visible.push(item);
			} else {
				larkCanonicalBySessionId.set(id, canonical);
			}
		}
		return visible;
	}

	async function refreshLarkCanonicalMap(openId: string, rpcId?: unknown): Promise<void> {
		const raw = await originalList({ rpcId });
		const result = raw.result;
		if (result?.ok !== true) return;
		const value = result.value as { items?: Array<{ sessionId?: unknown }> } | undefined;
		if (!Array.isArray(value?.items)) return;
		const owned = value.items.filter((item) => {
			const id = item.sessionId;
			return typeof id === "string" && owners.ownerOf(id) === openId;
		});
		canonicalizeLarkItems(owned);
	}

	async function canonicalSessionId(openId: string, sessionId: string, rpcId?: unknown): Promise<string> {
		const known = larkCanonicalBySessionId.get(sessionId);
		if (known !== undefined) return known;
		if (larkLinkSessionKeyFromSessionId(sessionId) === undefined) return sessionId;
		await refreshLarkCanonicalMap(openId, rpcId);
		return larkCanonicalBySessionId.get(sessionId) ?? sessionId;
	}

	apiProxy.sessions.list = async function patchedList(req) {
		const auth = getAuthContext();
		if (!auth) return { rpcId: req.rpcId, result: { ok: true, value: { items: [] } } };
		const raw = await originalList(req);
		const result = raw.result;
		if (result?.ok !== true) return raw;
		const value = result.value as { items?: Array<{ sessionId?: unknown }> } | undefined;
		const items = value?.items;
		if (!Array.isArray(items)) return raw;
		const kept = items.filter((item) => {
			const id = item.sessionId;
			if (typeof id !== "string") return false;
			return owners.ownerOf(id) === auth.openId;
		});
		const canonicalKept = canonicalizeLarkItems(kept);
		return {
			...raw,
			result: { ...result, value: { ...(value ?? {}), items: canonicalKept } },
		} as AnyResponse;
	};

	// -- owned methods: check sessionId ownership before delegating ----------
	for (const method of OWNED_METHODS) {
		const original = apiProxy.sessions[method];
		if (typeof original !== "function") continue;
		const bound = (original as (r: AnyRequest) => Promise<AnyResponse>).bind(apiProxy.sessions);
		originals.set(method, original);
		apiProxy.sessions[method] = async function patched(req: AnyRequest): Promise<AnyResponse> {
			const auth = getAuthContext();
			const sessionId = req.payload?.sessionId;
			if (!auth || typeof sessionId !== "string") return notFound(req, sessionId);
			if (owners.ownerOf(sessionId) !== auth.openId) return notFound(req, sessionId);
			const canonicalId = await canonicalSessionId(auth.openId, sessionId, req.rpcId);
			if (owners.ownerOf(canonicalId) !== auth.openId) return notFound(req, sessionId);
			const nextReq = canonicalId === sessionId
				? req
				: { ...req, payload: { ...(req.payload ?? {}), sessionId: canonicalId } };
			return bound(nextReq);
		};
	}

	// -- create: allow, then record ownership from ALS ----------------------
	const originalCreate = apiProxy.sessions.create;
	if (typeof originalCreate === "function") {
		const bound = originalCreate.bind(apiProxy.sessions);
		originals.set("create", originalCreate);
		apiProxy.sessions.create = async function patchedCreate(req: AnyRequest): Promise<AnyResponse> {
			const raw = await bound(req);
			const auth = getAuthContext();
			if (auth && raw.result?.ok === true) {
				const value = raw.result.value as { sessionId?: unknown } | undefined;
				if (typeof value?.sessionId === "string") {
					owners.claim(value.sessionId, auth.openId, "web", now());
				}
			}
			return raw;
		};
	}

	// -- events: filter live session events before the client sees them ------
	for (const method of ["host", "mux"] as const) {
		const original = apiProxy.events?.[method];
		if (typeof original !== "function") continue;
		const bound = original.bind(apiProxy.events) as EventMethod;
		eventOriginals.set(method, original as EventMethod);
		apiProxy.events![method] = function patchedEvents(...args: unknown[]): AsyncIterable<unknown> {
			const auth = getAuthContext();
			return filterEventFrames(bound(...args), auth?.openId, owners);
		};
	}

	return () => {
		for (const [name, fn] of originals) {
			(apiProxy.sessions as Record<string, unknown>)[name] = fn;
		}
		for (const [name, fn] of eventOriginals) {
			if (apiProxy.events) apiProxy.events[name] = fn;
		}
	};
}
