/**
 * Config parsing. Rejects loudly at load time when a required field is empty —
 * a misconfigured OAuth setup that appears to boot and then 500s on the first
 * login is worse than refusing to start.
 */

import { homedir } from "node:os";
import { join } from "node:path";
import type { AuthConfig } from "./types.ts";

/** Raw config shape received from cordis loader (all optional at wire level). */
export interface RawConfig {
	enabled?: boolean | string;
	appId?: string;
	appSecret?: string;
	publicBaseUrl?: string;
	cookieSecret?: string;
	dbPath?: string;
	cookieTtlDays?: number;
	domain?: string;
}

/** Config-error class so plugin `apply()` can distinguish a bad env from a bug. */
export class ConfigError extends Error {
	constructor(message: string) {
		super(`[lark-web-auth] config: ${message}`);
		this.name = "ConfigError";
	}
}

/** Parse a truthy env-string ("true", "1", "yes") into boolean. */
function parseBool(v: boolean | string | undefined, fallback: boolean): boolean {
	if (typeof v === "boolean") return v;
	if (v === undefined) return fallback;
	const lc = v.toLowerCase();
	return lc === "true" || lc === "1" || lc === "yes";
}

/** Expand a leading `~/` to the user's home directory. */
function expandHome(path: string): string {
	if (path.startsWith("~/")) return join(homedir(), path.slice(2));
	if (path === "~") return homedir();
	return path;
}

/**
 * Parse and validate raw config into an `AuthConfig`. Throws `ConfigError`
 * with a specific field name when any invariant is violated.
 */
export function parseConfig(raw: RawConfig): AuthConfig {
	const enabled = parseBool(raw.enabled, true);
	if (!enabled) {
		// When disabled, still return a well-formed object so plugin can early-return.
		return {
			enabled: false,
			appId: "",
			appSecret: "",
			publicBaseUrl: "",
			cookieSecret: "",
			dbPath: expandHome(raw.dbPath || "~/.dsh/lark-web-auth.sqlite"),
			cookieTtlDays: raw.cookieTtlDays ?? 30,
			domain: (raw.domain === "lark" ? "lark" : "feishu"),
		};
	}

	const appId = (raw.appId ?? "").trim();
	if (!appId) throw new ConfigError("appId is required (env LARK_WEB_APP_ID)");

	const appSecret = (raw.appSecret ?? "").trim();
	if (!appSecret) throw new ConfigError("appSecret is required (env LARK_WEB_APP_SECRET)");

	const publicBaseUrl = (raw.publicBaseUrl ?? "").trim();
	if (!publicBaseUrl) throw new ConfigError("publicBaseUrl is required (env LARK_WEB_BASE_URL)");
	if (!publicBaseUrl.startsWith("https://") && !publicBaseUrl.startsWith("http://")) {
		throw new ConfigError(`publicBaseUrl must start with https:// or http:// (got ${JSON.stringify(publicBaseUrl)})`);
	}
	// Reject trailing slash so callback URL concat is unambiguous.
	const baseUrl = publicBaseUrl.replace(/\/+$/, "");

	const cookieSecret = (raw.cookieSecret ?? "").trim();
	if (!cookieSecret) throw new ConfigError("cookieSecret is required (env LARK_WEB_COOKIE_SECRET)");
	if (cookieSecret.length < 16) {
		throw new ConfigError(`cookieSecret must be at least 16 chars (got ${cookieSecret.length})`);
	}

	const dbPath = expandHome((raw.dbPath ?? "").trim() || "~/.dsh/lark-web-auth.sqlite");

	const cookieTtlDays = raw.cookieTtlDays ?? 30;
	if (!Number.isFinite(cookieTtlDays) || cookieTtlDays < 1 || cookieTtlDays > 365) {
		throw new ConfigError(`cookieTtlDays must be in [1, 365] (got ${cookieTtlDays})`);
	}

	const domain = raw.domain === "lark" ? "lark" : "feishu";

	return {
		enabled: true,
		appId,
		appSecret,
		publicBaseUrl: baseUrl,
		cookieSecret,
		dbPath,
		cookieTtlDays,
		domain,
	};
}
