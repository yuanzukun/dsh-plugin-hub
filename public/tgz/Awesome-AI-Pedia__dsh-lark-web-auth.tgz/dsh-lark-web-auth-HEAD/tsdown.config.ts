// Build config for dsh-lark-web-auth.
// Host-only plugin: bundle src/index.ts → dist/index.js (ESM, node).
// @deepseek-ai/* stays external (harness provides at runtime).
// better-sqlite3 is a native module — must be external, never bundled.

import { defineConfig } from "tsdown";

export default defineConfig({
	entry: { index: "src/index.ts" },
	outDir: "dist",
	format: ["esm"],
	platform: "node",
	target: "es2024",
	dts: true,
	clean: true,
	fixedExtension: false,
	external: [
		/^@deepseek-ai\//,
		"better-sqlite3",
		"cookie",
		/^node:/,
	],
});
