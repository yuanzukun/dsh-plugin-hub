/**
 * Vitest config — Node environment (all tests are Node-side), ts source
 * resolved via native TS support (Node 22+) plus vitest's built-in transformer.
 */

import { defineConfig } from "vitest/config";

export default defineConfig({
	test: {
		environment: "node",
		include: ["tests/**/*.spec.ts"],
		coverage: {
			provider: "v8",
			include: ["src/**/*.ts"],
			exclude: ["src/types.ts"],
		},
	},
});
