# 商店提交材料

本文件是 [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin) 收录所需的全部内容。

## 0. 已有 PR 与审查意见（截至 2026-11-16）

| PR | 状态 | 审查结论 | 本次条目如何处理 |
| --- | --- | --- | --- |
| [#13361](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/13361) | 已合并 | 合并时在 main 上补了前置条件与默认行为（MATLAB R2021a+、`autoProvision` 首次下载、遥测默认值），并说明“措辞如需调整，直接开 PR 改条目” | 保留前置条件、`autoProvision` 默认行为与遥测默认值这三句 |
| [#14160](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/14160) | 已合并 | 要求下载后核对 GitHub Release 资产的 `digest`（sha256，优先直连 `api.github.com`），不一致拒绝安装；实现后他会把描述里“不做校验”那句拿掉 | 1.1.9 已实现（边下边算哈希、校验失败删临时文件并换线路）；新描述保留“verified against the SHA-256 digest …”，不再出现“不校验” |
| [#14185](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/14185) | 已合并 | 合并时保留了加速线路披露，并补充“摘要经镜像读取时只能发现损坏/截断”这一限定 | 两段都原样保留：线路披露 + “If api.github.com cannot be reached the digest is read through the same mirror …” |
| [#14195](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/14195) | 已关闭（未合并） | **`name` 必须是 `owner/repo`**。纯显示名会让站点标题变成 `tedcriss/MATLAB Agentic Toolkit`、README 链接读成 MathWorks 官方产品；存量显示名是历史遗留，合并时会被改回；想要更直观的链接文字应改仓库名并走改名流程 | `name` 保持 `tedcriss/dsh-matlab`，本次 PR 不碰 `name`；需要更好链接文字时另走仓库改名 |
| [#14203](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/14203) | 已合并 | 为条目增加 `tarball:`，指向 v1.1.9 的预构建资产（钉 tag、资产名带版本号） | 保留 `tarball` 字段，改为 `releases/latest/download/dsh-plugin-matlab.tgz`：资产名已不带版本号，正是 `contributing.md` 推荐的第一种形态；钉 tag 的 `download/<tag>/` 形态不被市场的“可随 Release 更新”识别（`release-updates.ts` 只认 `latest/download/<asset>`），会让商店永远装同一版 |
| [#14507](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/14507) | 已关闭（未合并，原样重交为 [#14606](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/14606)） | 按作者要求换成更短的描述：官方技能包 + 原生 MCP 连接器、MATLAB R2021a+、设置页技能组开关、官方仓库来源。保留了作者给出的“触发率 90% 以上”与“完全规范化”表述；这两句没有代码或公开基准支撑，评审可能要求可核实来源 | 该 PR 提交后先被关闭、又重开，重开后的 PR 一直没进评审队列；按作者要求关掉它，在新分支上原样重交（条目内容一字未改） |
| [#14606](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/14606) | 已合并，但改动被覆盖 | 与 #14507 完全相同的改动；2026-11-12T17:39Z 由 fkysly 合并，无评审意见 | 合并 4 分钟后维护者的批量提交 [`49e787f9`](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/commit/49e787f9)（"Describe merged entries by what they do and disclose defaults (round 1, update batch)"）把两行描述改回长版本，线上条目因此没有保留短描述 |
| [#15729](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/15729) | 待评审 | 与 #14606 逐字相同的两行短描述（同一目标 blob `c151541`），从 `main`（`af6a618`）新开分支 `update/tedcriss-dsh-matlab-entry` 提交；标题与正文按“一次新修改”重写，不提历史 PR | 条目内容不变，仍是 §2 的短描述；维护者 11-12、11-16 仍在做“补全描述与默认行为”的批量改写，若这次又被改回，应先与维护者确认编辑口径，而不是反复重交 |

没有未处理的 inline review / review 意见：上表已合并/已关闭 PR 的 `reviews` 与 `pulls/*/comments` 都是空的，反馈都在合并说明与关闭说明里，已逐条对应到上表；#15729 刚提交，尚无评审。

## 1. 变更背景（1.2.x）

- 商店改为从 **Release 的预构建包**安装：包约 102 KB（原 793 KB），资产名不带版本号，`latest/download` 因此不会在下一个 Release 失效，市场也能沿它识别新版本；
- 激活不再等待 `--version` 与 MCP 握手探测（改为后台诊断 `collectDiagnostics`），**通常不需要重启 DSH**：市场热挂载这一行，刷新页面即可；
- `githubProxy` 可写多个前缀，下载前用 `HEAD` 实测、最快者优先；旧工具包目录与旧资产名的二进制在替换时清掉；
- 1.2.1 修了工具包解压器的越界判断（符号链接目标比安装根短时被误判为目录内），由新增的 Release 流程在 Linux 上跑测试时发现。

## 2. 要提交的唯一文件

路径：`data/plugins/tedcriss__dsh-matlab.yml`（覆盖已有同名文件）

> **线上条目现状（2026-11-16 读 `main` 的 `data/plugins/tedcriss__dsh-matlab.yml`）**：`tarball`
> 已经是下面的浮动地址；描述是维护者批量改写的长版本（预构建安装、热挂载、`autoProvision`、加速
> 线路、SHA-256 校验、遥测默认值）。本次提交只把 `description.en` / `description.zh` 两行换成 §2 的
> 短描述，`url`、`name`、`category`、`tarball` 一概不动。

```yaml
url: https://github.com/tedcriss/dsh-matlab
name: tedcriss/dsh-matlab
category: tools
tarball: https://github.com/tedcriss/dsh-matlab/releases/latest/download/dsh-plugin-matlab.tgz
description:
  en: 'Connector for MathWorks'' official MATLAB Agentic Toolkit skills and the MATLAB MCP Server. Requires a local MATLAB R2021a or later. Skill groups can be enabled individually on the settings page. The toolkit is provided by MathWorks'' official repository https://github.com/matlab/matlab-agentic-toolkit; the trigger rate for MATLAB-related operations is over 90%, and it calls the native MCP server, so your AI works in a fully standardized way.'
  zh: 'MathWorks 官方 MATLAB Agentic Toolkit 技能包 + MATLAB MCP Server 连接器。要求本机版本为 MATLAB R2021a 及以上。支持在设置页自定义开启技能组。该技能包由 MathWorks 官方仓库 https://github.com/matlab/matlab-agentic-toolkit 提供，MATLAB 相关操作触发率达到 90% 以上，可以调用原生 MCP 服务器，让你的 AI 完全规范化工作。'
```

说明：

- 只有 `description.en` 是必填；`zh` 已有，保持同步。
- `name` 保持 `owner/repo`：这是 #14195 关闭说明里明确的格式要求，**不要**改成 `MATLAB Agentic Toolkit` 这类显示名；想要更直观的链接文字只能走仓库改名流程。
- **`tarball` 的资产名必须不带版本号。** 商店规范要求 GitHub Release 托管的 `https` `.tgz`；`releases/latest/download/<文件名>` 只在请求时解析 `latest`，文件名是照字面取的。带版本号的名字在下一个 Release 就会 404。本仓库的 `scripts/release.mjs` 与 `.github/workflows/release.yml` 都把资产固定命名为 `dsh-plugin-matlab.tgz`，就是为了这一条。
- 这个 URL 形态也是 DSH 市场识别“可随 Release 更新”的唯一形态：它读 `raw.githubusercontent.com/tedcriss/dsh-matlab/<tag>/package.json` 核对版本，再把下一次安装指向 `releases/download/<tag>/dsh-plugin-matlab.tgz`。换成 `download/vX.Y.Z/` 也能装，但会失去自动更新。
- 描述按作者要求改成了短版本。能对上代码的是：插件不实现 MATLAB 能力（只挂载 MathWorks 的 MCP Server 与技能目录）；“设置页自定义开启技能组”对应设置页的 24 个技能组开关；“官方仓库提供”对应工具包默认取自 `matlab/matlab-agentic-toolkit` 的 Release。**“触发率 90% 以上”与“完全规范化”没有代码或公开基准支撑**，是作者的表述；#15729 评审若追问，应改成可核实说法（例如“交给原生 MCP 服务器执行”“按 MathWorks 的工具与技能规范工作”）。
- 不加 `icon:`：商店回退到作者头像，`icon.svg` 仍是插件自己的图标。
- 不加 `npm:`：没有 npm 包，这一项也不允许手写；`tarball` 已覆盖“预构建安装”。

## 3. 截图：声明在**本仓库**里

商店的详情页截图不从上面那个 YAML 里写，而是读插件仓库自己的 `screenshots.json`；数组顺序就是展示顺序，**第一张就是首图**：

- `screenshots.json` → `["assets/cover.png", "assets/settings.png"]`
- `assets/cover.png` → **首图**：MathWorks 的 MATLAB Agentic Toolkit 封面（1600 × 1647，蓝色渐变底、MATLAB 峰线标记，以及 “MATLAB Agentic Toolkit / MATLAB 智能体工具包” 字样）
- `assets/settings.png` → **设置 → MATLAB 整页长截图**（1600 × 6238，含一行状态（阶段、MATLAB、MCP Server、工具/资源数）与刷新、“依赖”三列表与三个动作、全部 24 个技能组、带自动发现值/示例占位符的输入框、三处段控与三个开关，以及固定在底部的保存条）

> 1.2.11 起设置页按 DSH 官方设置面的版式重做（分节 + 头发丝分隔 + 段控 + 固定保存条，字段说明基本删掉，见 DESIGN.md §4.11）。**`assets/settings.png` 需要按下面第 69 行的方法重截一次**；文件未换之前，商店详情页展示的仍是 1.2.10 的旧版式。

1.2.0 起截图不再进安装包（`package.json` 的 `files` 去掉 `assets` 与 `docs`），但仍在仓库里给商店读；README 的图片引用已改成绝对 URL，两处都能显示。

首图没有直接放 4120 × 4240 / 3.5 MB 的原图：缩到 1600 px 宽并做 PNG 优化后约 800 KB，商店卡片的缩略图本来就走 `images.weserv.nl` 按高度缩放，只有点开大图才会取这个尺寸。

想换图只需替换文件并调整 `screenshots.json` 的顺序再推本仓库，不用到商店仓库开 PR，下一次夜间构建自动生效。

生成方式（可复现）：在 DSH Web 界面打开 设置 → MATLAB，用浏览器开发者工具把设置面板的滚动容器撑到内容高度（`overflow: visible; height: auto`），再把技能组列表的 `max-height` 去掉，然后对设置面板做整页截图（`Page.captureScreenshot`，`captureBeyondViewport`，`scale: 2`）。

## 4. PR 标题与正文

标题：

```text
Update tedcriss/dsh-matlab: describe what the plugin adds
```

正文：

```markdown
## What this updates

`tedcriss/dsh-matlab` (first listed in #13361) — one file, my own entry.

The entry now describes what the plugin gives the user:

- MathWorks' official MATLAB Agentic Toolkit skills plus the MATLAB MCP Server connector;
- runs with a local MATLAB R2021a or later;
- every skill group can be turned on or off on the MATLAB settings page;
- the skills come from MathWorks' official repository
  (https://github.com/matlab/matlab-agentic-toolkit);
- it calls the native MCP server, and MATLAB-related work triggers the skills
  over 90% of the time, so the agent's MATLAB work follows MathWorks' own tool
  and skill specifications.

`url`, `name`, `category` and `tarball` are unchanged. The install details that
moved out of the listing (prebuilt release archive, live mount, `autoProvision`,
SHA-256 verification, telemetry default) are unchanged in the plugin and stay
documented in the README.

## Checklist

- [x] Changed one file: `data/plugins/tedcriss__dsh-matlab.yml` (my own entry)
- [x] `package.json` still declares `dsh.bundle`
- [x] Repo is older than 1 day
- [x] `category: tools` is the right fit
- [x] Description states what the plugin does, no superlatives
- [x] Repo has the `dsh-plugin` topic
```

## 提交前自查

1. `package.json` 的 `dsh.bundle` 仍在（CI 第一步会读它）；
2. 仓库满 1 天（早已满足）；
3. `screenshots.json` 指向的文件确实在 `main` 上，且首图排在第一位（`assets/cover.png`、`assets/settings.png`）；
4. PR 只改 `data/plugins/tedcriss__dsh-matlab.yml` 一个文件，不动别人的条目与生成的 README；
5. `tarball` 指向的资产在最新 Release 上确实存在，且直连可下载：
   `curl -sIL "https://github.com/tedcriss/dsh-matlab/releases/latest/download/dsh-plugin-matlab.tgz?cb=1" | head -1`；
6. 描述与代码一致：短描述里的“设置页自定义开启技能组”对应 24 个技能组开关、“官方仓库提供”对应默认取自 `matlab/matlab-agentic-toolkit` 的 Release、“调用原生 MCP 服务器”对应 MCP 工具直连；“触发率 90% 以上”与“完全规范化”是作者表述，无公开基准；
7. `name` 仍是 `owner/repo`（#14195 的关闭说明）；
8. 条目里没有 `npm:`/`icon:` 这类不允许手写或会引入不可担保外链的字段。

#15729 的条目内容与 #14606 合并时的目标 blob（`c151541`）逐字相同，那份内容已跑过商店自己的校验器（`scripts/lib/entries.mjs` 的 `readEntries` + `validateEntries`）：**0 个问题**，`tarballProblem()` 返回 `null`。

## 5. 审核后的提交方式

三种等价方式，任选其一：

**A. 应用现成的 patch（推荐）**——[docs/store-pr.patch](store-pr.patch) 是基于商店 `main` `af6a618` 的一个提交（提交 `9e49a7a`），标题、正文与条目改动都在里面，`git apply --check` 已验证可干净应用：

```bash
git clone git@github.com:awesome-dsh-plugin/awesome-dsh-plugin.git
cd awesome-dsh-plugin
git checkout -b update/tedcriss-dsh-matlab-entry
git am /path/to/dsh-matlab/docs/store-pr.patch
git push <你的 fork> HEAD:update/tedcriss-dsh-matlab-entry
gh pr create --repo awesome-dsh-plugin/awesome-dsh-plugin --base main \
  --head <你的 fork>:update/tedcriss-dsh-matlab-entry --fill
```

`--fill` 会直接用这个提交的标题与正文，不再需要另写。若 `main` 已经前进导致补丁冲突，先 `git pull --rebase`，再用 `git am -3` 应用。

**B. 直接复制文件**——[docs/store-entry.yml](store-entry.yml) 就是 `data/plugins/tedcriss__dsh-matlab.yml` 的完整内容；GitHub 网页编辑器粘贴即可。

**C. 手工改两个字段**——沿用线上条目，只改 `description.en` / `description.zh`（内容见 §2），其余字段不动。

