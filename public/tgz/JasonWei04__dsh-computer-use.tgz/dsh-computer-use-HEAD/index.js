// dsh-computer-use · 电脑操作插件（web_ui 家族框架）
// 框架与 @linxin666/dsh-web-ui 全家桶一致：defineTool + installSettingsSection +
// systemPrompt.section + mountOnce 单实例守卫。多模态部分基于 dsh-tool-describe-image
// 的思路（OpenAI 兼容视觉端点 + 设置区），端点默认 Xiaomi MIMO；电脑操作复用此前
// ds_computeruse 经验（C# 助手 exe 内嵌源码，首次使用自动用系统 csc.exe 编译）。
//
// 工具：
//   computer_status      助手与 MIMO 状态
//   computer_screenshot  截屏 -> PNG，可选 MIMO 视觉分析
//   computer_action      单步操作（move/click/drag/scroll/type/keys/run/activate/
//                        windowrect/listwindows/sendchat）
//   computer_use         自主循环：截屏 -> MIMO 视觉决策 -> 执行，直到完成

import { defineTool } from '@deepseek-ai/dsh-tools'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'
import z from 'schemastery'

export const name = 'computer-use'
export const inject = ['subprocess', 'fs', 'systemPrompt', 'tools']

// ---------------------------------------------------------------------------
// 常量
// ---------------------------------------------------------------------------
const MIMO_BASE_DEFAULT = 'https://api.xiaomimimo.com/v1'
const MIMO_KEY_ENV = 'MIMO_API_KEY'
const CURL_CANDIDATES = ['curl.exe', 'curl', 'C:\\Windows\\System32\\curl.exe']
const PWSH_CANDIDATES = ['powershell.exe', 'powershell', 'pwsh', 'pwsh.exe', 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe']
const CSC_CANDIDATES = [
  'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe',
  'C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe',
]
const KEY_PROBE_INTERVAL_MS = 30000
const SECTION_ORDER = 152
const HELPER_VERSION = 'v9'
const DEFAULT_MAX_STEPS = 10

const COMPUTER_SETTINGS_NAMESPACE = settingsNamespace('dsh-computer-use')

// ---------------------------------------------------------------------------
// mountOnce —— 与 web_ui 全家桶同一份单实例守卫（Symbol 全局去重）
// ---------------------------------------------------------------------------
const MOUNTED = Symbol.for('dsh-web-ui.mounted-plugins')
function mountOnce(packageName, fn) {
  return (...args) => {
    const registry = globalThis
    const mounted = (registry[MOUNTED] ??= new Set())
    if (mounted.has(packageName)) return
    mounted.add(packageName)
    const ctx = args[0]
    ctx?.effect?.(() => () => { mounted.delete(packageName) })
    return fn(...args)
  }
}

// ---------------------------------------------------------------------------
// 配置（schemastery 结构同时充当设置区卡片 schema）
// ---------------------------------------------------------------------------
export const Config = z.object({
  baseURL: z.string().default(MIMO_BASE_DEFAULT),
  model: z.string().default(''),
  apiKeyEnv: z.string().role('credential-ref').default(MIMO_KEY_ENV),
  maxOutputTokens: z.number().step(1).min(1).default(4096),
  timeoutMs: z.number().step(1).min(1000).default(120000),
  helperExe: z.string().default(''),
  enabled: z.boolean().default(true),
  announceToAgent: z.boolean().default(true),
})

function resolveConfig(config) {
  const baseURL = (config.baseURL || MIMO_BASE_DEFAULT).trim().replace(/\/+$/, '')
  return {
    baseURL,
    model: (config.model || '').trim(),
    apiKeyEnv: (config.apiKeyEnv || MIMO_KEY_ENV).trim(),
    maxOutputTokens: config.maxOutputTokens || 4096,
    timeoutMs: config.timeoutMs || 120000,
    helperExe: (config.helperExe || '').trim(),
    enabled: config.enabled !== false,
    announceToAgent: config.announceToAgent !== false,
  }
}

const COMPUTER_GUIDANCE = '本机已安装 dsh-computer-use 插件（电脑操作）：截屏/录屏 + MIMO 视觉分析 + 真实鼠标键盘/窗口/程序控制。工具：computer_status 查看助手与视觉状态；computer_screenshot 截屏并可选让 Xiaomi MIMO 视觉模型分析屏幕（静态场景用）；computer_record 录屏抽帧让 MIMO 观察动态过程（滚动/滑动/动画/加载等动态场景用，一次看清避免反复截屏）；computer_action 执行单步操作（move/click/drag/scroll/type/keys/run/activate/windowrect/listwindows/sendchat）；computer_use 输入任务自动循环「观察（截屏或录屏）→视觉决策→执行」直到完成，循环结束自动清理临时截图与录屏帧。限制：操作真实桌面、消耗真实资源，先确认用户意图再执行；视觉由 MIMO 模型完成，坐标可能不准，复杂界面建议小步操作并回看观察结果。用户提到「电脑操作 / 操作电脑 / 自动点击 / 控制桌面」时即指本插件，请据此协作。'

// ---------------------------------------------------------------------------
// C# 电脑操作助手源码（内嵌，首次使用自动编译）
// ---------------------------------------------------------------------------
const HELPER_SOURCE = [
  '// dsh-computer-use 电脑操作助手 v9',
  '// 命令（argv[0]=命令名）：',
  '//   noop                      自检',
  '//   screenshot <outPath>      全屏截图 -> PNG',
  '//   record <outDir> <seconds> <fps> [quality]  录屏抽帧 -> JPEG（动态场景观察）',
  '//   move <x> <y>              移动鼠标',
  '//   click <button> <x> <y>    点击（left|right|middle|double）',
  '//   drag <x1> <y1> <x2> <y2>  拖拽',
  '//   scroll <dy>               滚轮（正=向下）',
  '//   type <text>               剪贴板 + Ctrl+V 输入文本',
  '//   keys <spec>               按键（SendKeys 风格，支持 {LWIN} {ENTER} {TAB} {ESC} 等）',
  '//   run <file> [args...]      启动程序并尝试置前',
  '//   activate <proc> [title]   激活窗口（进程名/标题）',
  '//   windowrect <proc> [title] 输出窗口矩形 "left top w h"',
  '//   listwindows               列出可见窗口（proc | title | left,top wxh | hwnd）',
  '//   sendchat <text>           微信发送：激活 -> 点输入框 -> 粘贴 -> 回车',
  'using System;',
  'using System.Collections.Generic;',
  'using System.Diagnostics;',
  'using System.Drawing;',
  'using System.Drawing.Imaging;',
  'using System.Globalization;',
  'using System.IO;',
  'using System.Runtime.InteropServices;',
  'using System.Text;',
  'using System.Threading;',
  'using System.Windows.Forms;',
  '',
  'public static class ComputerHelper',
  '{',
  '    [StructLayout(LayoutKind.Sequential)]',
  '    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }',
  '',
  '    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);',
  '',
  '    [DllImport("user32.dll")] static extern bool SetCursorPos(int X, int Y);',
  '    [DllImport("user32.dll")] static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);',
  '    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hWnd);',
  '    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);',
  '    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);',
  '    [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);',
  '    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hWnd);',
  '    [DllImport("user32.dll")] static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);',
  '    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);',
  '    [DllImport("user32.dll")] static extern short VkKeyScan(char ch);',
  '    [DllImport("user32.dll")] static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);',
  '',
  '    const uint MOUSEEVENTF_LEFTDOWN = 0x0002;',
  '    const uint MOUSEEVENTF_LEFTUP = 0x0004;',
  '    const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;',
  '    const uint MOUSEEVENTF_RIGHTUP = 0x0010;',
  '    const uint MOUSEEVENTF_MIDDLEDOWN = 0x0020;',
  '    const uint MOUSEEVENTF_MIDDLEUP = 0x0040;',
  '    const uint MOUSEEVENTF_WHEEL = 0x0800;',
  '    const uint KEYEVENTF_KEYUP = 0x0002;',
  '    const int SW_RESTORE = 9;',
  '',
  '    static readonly Dictionary<string, byte> KEYMAP = new Dictionary<string, byte>(StringComparer.OrdinalIgnoreCase)',
  '    {',
  '        { "LWIN", 0x5B }, { "RWIN", 0x5C },',
  '        { "ENTER", 0x0D }, { "RETURN", 0x0D }, { "TAB", 0x09 }, { "ESC", 0x1B }, { "ESCAPE", 0x1B },',
  '        { "UP", 0x26 }, { "DOWN", 0x28 }, { "LEFT", 0x25 }, { "RIGHT", 0x27 },',
  '        { "HOME", 0x24 }, { "END", 0x23 }, { "PGUP", 0x21 }, { "PAGEDOWN", 0x22 }, { "PAGEUP", 0x21 }, { "PGDN", 0x22 },',
  '        { "DELETE", 0x2E }, { "DEL", 0x2E }, { "BACKSPACE", 0x08 }, { "BS", 0x08 }, { "SPACE", 0x20 },',
  '        { "CAPSLOCK", 0x14 }, { "NUMLOCK", 0x90 }, { "SCROLLLOCK", 0x91 }, { "PRTSC", 0x2C },',
  '        { "ADD", 0x6B }, { "SUBTRACT", 0x6D }, { "MULTIPLY", 0x6A }, { "DIVIDE", 0x6F },',
  '        { "LCTRL", 0xA2 }, { "RCTRL", 0xA3 }, { "LSHIFT", 0xA0 }, { "RSHIFT", 0xA1 }, { "LALT", 0xA4 }, { "RALT", 0xA5 },',
  '    };',
  '',
  '    [STAThread]',
  '    public static int Main(string[] args)',
  '    {',
  '        if (args.Length < 1) { Console.WriteLine("usage: <cmd> ..."); return 0; }',
  '        string cmd = args[0].ToLowerInvariant();',
  '        try',
  '        {',
  '            switch (cmd)',
  '            {',
  '                case "noop": Console.WriteLine("noop v9"); return 0;',
  '                case "screenshot": return Screenshot(args);',
  '                case "record": return Record(args);',
  '                case "move": return Move(args);',
  '                case "click": return Click(args);',
  '                case "drag": return Drag(args);',
  '                case "scroll": return Scroll(args);',
  '                case "type": return Type(args);',
  '                case "keys": return Keys(args);',
  '                case "run": return Run(args);',
  '                case "activate": return Activate(args);',
  '                case "windowrect": return WindowRect(args);',
  '                case "listwindows": return ListWindows(args);',
  '                case "sendchat": return SendChat(args);',
  '                default: Console.WriteLine("unknown cmd: " + cmd); return 2;',
  '            }',
  '        }',
  '        catch (Exception ex) { Console.WriteLine("error: " + ex.Message); return 1; }',
  '    }',
  '',
  '    static int Screenshot(string[] args)',
  '    {',
  '        if (args.Length < 2) { Console.WriteLine("error: screenshot <outPath>"); return 2; }',
  '        Rectangle bounds = Screen.PrimaryScreen.Bounds;',
  '        using (Bitmap bmp = new Bitmap(bounds.Width, bounds.Height))',
  '        {',
  '            using (Graphics g = Graphics.FromImage(bmp))',
  '            {',
  '                g.CopyFromScreen(bounds.X, bounds.Y, 0, 0, bounds.Size);',
  '            }',
  '            bmp.Save(args[1], ImageFormat.Png);',
  '        }',
  '        Console.WriteLine("ok " + bounds.Width + "x" + bounds.Height + " -> " + args[1]);',
  '        return 0;',
  '    }',
  '',
  '    static int Record(string[] args)',
  '    {',
  '        // record <outDir> <seconds> <fps> [quality]',
  '        if (args.Length < 4) { Console.WriteLine("error: record <outDir> <seconds> <fps> [quality]"); return 2; }',
  '        string outDir = args[1];',
  '        double seconds;',
  '        double fps;',
  '        int quality = args.Length > 4 ? int.Parse(args[4], CultureInfo.InvariantCulture) : 70;',
  '        if (!double.TryParse(args[2], NumberStyles.Float, CultureInfo.InvariantCulture, out seconds) || seconds <= 0) { Console.WriteLine("error: invalid seconds"); return 2; }',
  '        if (!double.TryParse(args[3], NumberStyles.Float, CultureInfo.InvariantCulture, out fps) || fps <= 0) { Console.WriteLine("error: invalid fps"); return 2; }',
  '        try { Directory.CreateDirectory(outDir); } catch (Exception ex) { Console.WriteLine("error: cannot create outDir: " + ex.Message); return 1; }',
  '        Rectangle bounds = Screen.PrimaryScreen.Bounds;',
  '        int totalFrames = (int)Math.Ceiling(seconds * fps);',
  '        if (totalFrames > 120) { Console.WriteLine("error: too many frames (" + totalFrames + "), reduce seconds/fps"); return 2; }',
  '        ImageCodecInfo jpegCodec = null;',
  '        foreach (ImageCodecInfo codec in ImageCodecInfo.GetImageEncoders())',
  '            if (codec.FormatID == ImageFormat.Jpeg.Guid) { jpegCodec = codec; break; }',
  '        EncoderParameters encParams = new EncoderParameters(1);',
  '        encParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, (long)quality);',
  '        double intervalMs = 1000.0 / fps;',
  '        var sw = Stopwatch.StartNew();',
  '        for (int i = 0; i < totalFrames; i++)',
  '        {',
  '            using (Bitmap bmp = new Bitmap(bounds.Width, bounds.Height))',
  '            {',
  '                using (Graphics g = Graphics.FromImage(bmp))',
  '                {',
  '                    g.CopyFromScreen(bounds.X, bounds.Y, 0, 0, bounds.Size);',
  '                }',
  '                string path = Path.Combine(outDir, "frame_" + i.ToString("D3") + ".jpg");',
  '                try {',
  '                    if (jpegCodec != null) bmp.Save(path, jpegCodec, encParams);',
  '                    else bmp.Save(path, ImageFormat.Jpeg);',
  '                } catch (Exception ex) { Console.WriteLine("error: save frame failed: " + ex.Message); return 1; }',
  '                Console.WriteLine(path);',
  '            }',
  '            if (i < totalFrames - 1)',
  '            {',
  '                double targetMs = (i + 1) * intervalMs;',
  '                double waitMs = targetMs - sw.Elapsed.TotalMilliseconds;',
  '                if (waitMs > 0) Thread.Sleep((int)waitMs);',
  '            }',
  '        }',
  '        Console.WriteLine("ok " + totalFrames + " frames -> " + outDir);',
  '        return 0;',
  '    }',
  '',
  '    static int Move(string[] args)',
  '    {',
  '        if (args.Length < 3) { Console.WriteLine("error: move <x> <y>"); return 2; }',
  '        int x = int.Parse(args[1]); int y = int.Parse(args[2]);',
  '        SetCursorPos(x, y);',
  '        Console.WriteLine("ok moved " + x + "," + y);',
  '        return 0;',
  '    }',
  '',
  '    static int Click(string[] args)',
  '    {',
  '        if (args.Length < 4) { Console.WriteLine("error: click <button> <x> <y>"); return 2; }',
  '        string button = args[1].ToLowerInvariant();',
  '        int x = int.Parse(args[2]); int y = int.Parse(args[3]);',
  '        SetCursorPos(x, y);',
  '        Thread.Sleep(40);',
  '        uint down = MOUSEEVENTF_LEFTDOWN, up = MOUSEEVENTF_LEFTUP;',
  '        if (button == "right") { down = MOUSEEVENTF_RIGHTDOWN; up = MOUSEEVENTF_RIGHTUP; }',
  '        else if (button == "middle") { down = MOUSEEVENTF_MIDDLEDOWN; up = MOUSEEVENTF_MIDDLEUP; }',
  '        if (button == "double")',
  '        {',
  '            mouse_event(down, 0, 0, 0, UIntPtr.Zero); mouse_event(up, 0, 0, 0, UIntPtr.Zero);',
  '            Thread.Sleep(60);',
  '            mouse_event(down, 0, 0, 0, UIntPtr.Zero); mouse_event(up, 0, 0, 0, UIntPtr.Zero);',
  '        }',
  '        else',
  '        {',
  '            mouse_event(down, 0, 0, 0, UIntPtr.Zero); mouse_event(up, 0, 0, 0, UIntPtr.Zero);',
  '        }',
  '        Console.WriteLine("ok click " + button + " " + x + "," + y);',
  '        return 0;',
  '    }',
  '',
  '    static int Drag(string[] args)',
  '    {',
  '        if (args.Length < 5) { Console.WriteLine("error: drag <x1> <y1> <x2> <y2>"); return 2; }',
  '        int x1 = int.Parse(args[1]), y1 = int.Parse(args[2]), x2 = int.Parse(args[3]), y2 = int.Parse(args[4]);',
  '        SetCursorPos(x1, y1); Thread.Sleep(40);',
  '        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero); Thread.Sleep(80);',
  '        int steps = 20;',
  '        for (int i = 1; i <= steps; i++)',
  '        {',
  '            int cx = x1 + (x2 - x1) * i / steps;',
  '            int cy = y1 + (y2 - y1) * i / steps;',
  '            SetCursorPos(cx, cy); Thread.Sleep(12);',
  '        }',
  '        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero);',
  '        Console.WriteLine("ok drag " + x1 + "," + y1 + " -> " + x2 + "," + y2);',
  '        return 0;',
  '    }',
  '',
  '    static int Scroll(string[] args)',
  '    {',
  '        if (args.Length < 2) { Console.WriteLine("error: scroll <dy>"); return 2; }',
  '        int dy = int.Parse(args[1]);',
  '        mouse_event(MOUSEEVENTF_WHEEL, 0, 0, (uint)(dy * 120), UIntPtr.Zero);',
  '        Console.WriteLine("ok scroll " + dy);',
  '        return 0;',
  '    }',
  '',
  '    static int Type(string[] args)',
  '    {',
  '        if (args.Length < 2) { Console.WriteLine("error: type <text>"); return 2; }',
  '        string text = args[1];',
  '        Clipboard.SetText(text);',
  '        Thread.Sleep(80);',
  '        keybd_event(0x11, 0, 0, UIntPtr.Zero);',
  '        keybd_event(0x56, 0, 0, UIntPtr.Zero);',
  '        keybd_event(0x56, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '        keybd_event(0x11, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '        Console.WriteLine("ok typed " + text.Length + " chars");',
  '        return 0;',
  '    }',
  '',
  '    static int Keys(string[] args)',
  '    {',
  '        if (args.Length < 2) { Console.WriteLine("error: keys <spec>"); return 2; }',
  '        string spec = args[1];',
  '        for (int i = 0; i < spec.Length; i++)',
  '        {',
  '            char c = spec[i];',
  '            bool ctrl = false, alt = false, shift = false;',
  '            while (c == \'^\' || c == \'%\' || c == \'+\')',
  '            {',
  '                if (c == \'^\') ctrl = true; else if (c == \'%\') alt = true; else shift = true;',
  '                i++;',
  '                if (i >= spec.Length) break;',
  '                c = spec[i];',
  '            }',
  '            byte vk = 0; char literal = \'\\0\'; bool isLiteral = false;',
  '            if (c == \'{\')',
  '            {',
  '                int close = spec.IndexOf(\'}\', i);',
  '                if (close < 0) { Console.WriteLine("error: unmatched {"); return 2; }',
  '                string token = spec.Substring(i + 1, close - i - 1);',
  '                int fn;',
  '                byte mapped;',
  '                if (token.Length > 1 && (token[0] == \'F\' || token[0] == \'f\') && int.TryParse(token.Substring(1), out fn) && fn >= 1 && fn <= 24)',
  '                {',
  '                    vk = (byte)(0x6F + fn);',
  '                }',
  '                else if (KEYMAP.TryGetValue(token, out mapped)) { vk = mapped; }',
  '                else { Console.WriteLine("error: unknown key token {" + token + "}"); return 2; }',
  '                i = close;',
  '            }',
  '            else { literal = c; isLiteral = true; }',
  '            if (ctrl) keybd_event(0x11, 0, 0, UIntPtr.Zero);',
  '            if (alt) keybd_event(0x12, 0, 0, UIntPtr.Zero);',
  '            if (shift) keybd_event(0x10, 0, 0, UIntPtr.Zero);',
  '            if (isLiteral)',
  '            {',
  '                short scan = VkKeyScan(literal);',
  '                byte v = (byte)(scan & 0xFF);',
  '                bool needShift = (scan & 0x0100) != 0;',
  '                if (needShift) keybd_event(0x10, 0, 0, UIntPtr.Zero);',
  '                keybd_event(v, 0, 0, UIntPtr.Zero);',
  '                keybd_event(v, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '                if (needShift) keybd_event(0x10, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '            }',
  '            else',
  '            {',
  '                keybd_event(vk, 0, 0, UIntPtr.Zero);',
  '                keybd_event(vk, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '            }',
  '            if (shift) keybd_event(0x10, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '            if (alt) keybd_event(0x12, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '            if (ctrl) keybd_event(0x11, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '        }',
  '        Console.WriteLine("ok keys");',
  '        return 0;',
  '    }',
  '',
  '    static int Run(string[] args)',
  '    {',
  '        if (args.Length < 2) { Console.WriteLine("error: run <file> [args...]"); return 2; }',
  '        string file = args[1];',
  '        string rest = "";',
  '        int sp = file.IndexOf(\' \');',
  '        if (sp > 0) { rest = file.Substring(sp + 1).Trim(); file = file.Substring(0, sp); }',
  '        Process p = Process.Start(new ProcessStartInfo { FileName = file, Arguments = rest, UseShellExecute = true });',
  '        IntPtr h = IntPtr.Zero;',
  '        try',
  '        {',
  '            Thread.Sleep(900);',
  '            p.Refresh();',
  '            h = p.MainWindowHandle;',
  '            if (h == IntPtr.Zero)',
  '            {',
  '                keybd_event(0x12, 0, 0, UIntPtr.Zero);',
  '                keybd_event(0x12, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '                Thread.Sleep(200);',
  '                p.Refresh();',
  '                h = p.MainWindowHandle;',
  '            }',
  '        }',
  '        catch (Exception) { /* UseShellExecute 下部分进程拿不到窗口句柄，忽略 */ }',
  '        if (h != IntPtr.Zero)',
  '        {',
  '            ShowWindow(h, SW_RESTORE);',
  '            SetForegroundWindow(h);',
  '        }',
  '        Console.WriteLine("ok run pid=" + p.Id + " hwnd=" + h);',
  '        return 0;',
  '    }',
  '',
  '    static IntPtr FindWindow(string procFilter, string titleFilter)',
  '    {',
  '        IntPtr found = IntPtr.Zero;',
  '        EnumWindows(delegate (IntPtr h, IntPtr l)',
  '        {',
  '            uint pid;',
  '            GetWindowThreadProcessId(h, out pid);',
  '            string proc = "";',
  '            try { proc = Process.GetProcessById((int)pid).ProcessName; } catch { }',
  '            StringBuilder sb = new StringBuilder(512);',
  '            GetWindowText(h, sb, 512);',
  '            string title = sb.ToString();',
  '            bool procMatch = string.IsNullOrEmpty(procFilter)',
  '                || proc.IndexOf(procFilter, StringComparison.OrdinalIgnoreCase) >= 0;',
  '            bool titleMatch = string.IsNullOrEmpty(titleFilter)',
  '                || title.IndexOf(titleFilter, StringComparison.OrdinalIgnoreCase) >= 0;',
  '            bool hasTitle = title.Trim().Length > 0;',
  '            if (procMatch && titleMatch && hasTitle)',
  '            {',
  '                if (IsWindowVisible(h)) { found = h; return false; }',
  '                if (found == IntPtr.Zero) found = h;',
  '            }',
  '            return true;',
  '        }, IntPtr.Zero);',
  '        return found;',
  '    }',
  '',
  '    static int Activate(string[] args)',
  '    {',
  '        if (args.Length < 2) { Console.WriteLine("error: activate <proc> [title]"); return 2; }',
  '        IntPtr h = FindWindow(args[1], args.Length > 2 ? args[2] : "");',
  '        if (h == IntPtr.Zero) { Console.WriteLine("error: window not found for " + args[1]); return 1; }',
  '        keybd_event(0x12, 0, 0, UIntPtr.Zero);',
  '        keybd_event(0x12, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '        Thread.Sleep(100);',
  '        ShowWindow(h, SW_RESTORE);',
  '        SetForegroundWindow(h);',
  '        Console.WriteLine("ok activated hwnd=" + h);',
  '        return 0;',
  '    }',
  '',
  '    static int WindowRect(string[] args)',
  '    {',
  '        if (args.Length < 2) { Console.WriteLine("error: windowrect <proc> [title]"); return 2; }',
  '        IntPtr h = FindWindow(args[1], args.Length > 2 ? args[2] : "");',
  '        if (h == IntPtr.Zero) { Console.WriteLine("error: window not found"); return 1; }',
  '        RECT r;',
  '        GetWindowRect(h, out r);',
  '        Console.WriteLine("ok " + r.Left + " " + r.Top + " " + (r.Right - r.Left) + " " + (r.Bottom - r.Top));',
  '        return 0;',
  '    }',
  '',
  '    static int ListWindows(string[] args)',
  '    {',
  '        EnumWindows(delegate (IntPtr h, IntPtr l)',
  '        {',
  '            uint pid;',
  '            GetWindowThreadProcessId(h, out pid);',
  '            string proc = "";',
  '            try { proc = Process.GetProcessById((int)pid).ProcessName; } catch { }',
  '            StringBuilder sb = new StringBuilder(512);',
  '            GetWindowText(h, sb, 512);',
  '            string title = sb.ToString();',
  '            if (title.Trim().Length > 0 && IsWindowVisible(h))',
  '            {',
  '                RECT r;',
  '                GetWindowRect(h, out r);',
  '                Console.WriteLine(proc + " | " + title + " | " + r.Left + "," + r.Top + " " + (r.Right - r.Left) + "x" + (r.Bottom - r.Top) + " | " + h);',
  '            }',
  '            return true;',
  '        }, IntPtr.Zero);',
  '        return 0;',
  '    }',
  '',
  '    static int SendChat(string[] args)',
  '    {',
  '        if (args.Length < 2) { Console.WriteLine("error: sendchat <text>"); return 2; }',
  '        string text = args[1];',
  '        string[] candidates = new[] { "Weixin", "WeChat", "微信", "QQ" };',
  '        IntPtr h = IntPtr.Zero;',
  '        foreach (string c in candidates)',
  '        {',
  '            h = FindWindow(c, "");',
  '            if (h != IntPtr.Zero) break;',
  '        }',
  '        if (h == IntPtr.Zero) { Console.WriteLine("error: no chat window found"); return 1; }',
  '        keybd_event(0x12, 0, 0, UIntPtr.Zero);',
  '        keybd_event(0x12, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '        Thread.Sleep(100);',
  '        ShowWindow(h, SW_RESTORE);',
  '        SetForegroundWindow(h);',
  '        Thread.Sleep(400);',
  '        RECT r;',
  '        GetWindowRect(h, out r);',
  '        int w = r.Right - r.Left;',
  '        int hgt = r.Bottom - r.Top;',
  '        int cx = r.Left + (int)(w * 0.62);',
  '        int cy = r.Bottom - 55;',
  '        SetCursorPos(cx, cy);',
  '        Thread.Sleep(150);',
  '        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero);',
  '        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero);',
  '        Thread.Sleep(200);',
  '        Clipboard.SetText(text);',
  '        Thread.Sleep(80);',
  '        keybd_event(0x11, 0, 0, UIntPtr.Zero);',
  '        keybd_event(0x56, 0, 0, UIntPtr.Zero);',
  '        keybd_event(0x56, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '        keybd_event(0x11, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '        Thread.Sleep(120);',
  '        keybd_event(0x0D, 0, 0, UIntPtr.Zero);',
  '        keybd_event(0x0D, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);',
  '        Console.WriteLine("ok sendchat " + text.Length + " chars");',
  '        return 0;',
  '    }',
  '}',
].join('\n')

// ---------------------------------------------------------------------------
// 工具型小函数
// ---------------------------------------------------------------------------
function bytesToBase64(bytes) {
  const TABLE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
  const parts = []
  const len = bytes.length
  for (let i = 0; i < len; i += 3) {
    const b0 = bytes[i]
    const has1 = i + 1 < len
    const has2 = i + 2 < len
    const b1 = has1 ? bytes[i + 1] : 0
    const b2 = has2 ? bytes[i + 2] : 0
    const n = (b0 << 16) | (b1 << 8) | b2
    parts.push(TABLE[(n >> 18) & 63])
    parts.push(TABLE[(n >> 12) & 63])
    parts.push(has1 ? TABLE[(n >> 6) & 63] : '=')
    parts.push(has2 ? TABLE[n & 63] : '=')
  }
  return parts.join('')
}

function mediaTypeFromPath(path) {
  const p = String(path || '').toLowerCase()
  if (p.endsWith('.jpg') || p.endsWith('.jpeg')) return 'image/jpeg'
  if (p.endsWith('.webp')) return 'image/webp'
  if (p.endsWith('.gif')) return 'image/gif'
  return 'image/png'
}

function contentText(content) {
  if (typeof content === 'string') return content
  if (Array.isArray(content)) {
    return content.map((part) => {
      if (typeof part === 'string') return part
      if (part !== null && typeof part === 'object') {
        if (typeof part.text === 'string') return part.text
        if (typeof part.content === 'string') return part.content
      }
      return ''
    }).join('')
  }
  return ''
}

function pickVisionModel(ids, forced) {
  if (typeof forced === 'string' && forced.trim() !== '') return forced.trim()
  if (!Array.isArray(ids) || ids.length === 0) return undefined
  const visionish = ids.find((id) => /vl|vision|omni|multimodal|glm-4v|qwen[^,]*vl|gpt-4o|4o/i.test(id))
  if (visionish !== undefined) return visionish
  const general = ids.find((id) => /mimo|chat|instruct/i.test(id))
  return general !== undefined ? general : ids[0]
}

function maskKey(key) {
  if (typeof key !== 'string' || key.length < 8) return '(密钥过短)'
  return key.slice(0, 6) + '***' + key.slice(-2)
}

function parseJsonLoose(text) {
  const t = String(text || '').trim()
  if (t === '') return undefined
  const fenced = /```(?:json)?\s*([\s\S]*?)```/i.exec(t)
  const candidate = fenced !== null ? fenced[1].trim() : t
  try { return JSON.parse(candidate) } catch (e) { /* fall through */ }
  const start = candidate.indexOf('{')
  const end = candidate.lastIndexOf('}')
  if (start >= 0 && end > start) {
    try { return JSON.parse(candidate.slice(start, end + 1)) } catch (e) { /* fall through */ }
  }
  return undefined
}

// ---------------------------------------------------------------------------
// apply
// ---------------------------------------------------------------------------
export const apply = mountOnce('dsh-computer-use', applyImpl)

function applyImpl(ctx, entryConfig = {}) {
  let current = () => entryConfig
  installSettingsSection(ctx, COMPUTER_SETTINGS_NAMESPACE, Config, entryConfig, {
    setSource: (source) => { current = source },
    onChange: () => {},
    validate: () => {},
  })
  const cfg = () => resolveConfig(current())

  const state = {
    apiKey: undefined,
    apiKeySource: undefined,
    models: [],
    visionModel: undefined,
    status: 'initializing',
    lastError: undefined,
    lastKeyProbe: 0,
    helperExe: undefined,
    helperReady: false,
    stats: { screenshots: 0, records: 0, actions: 0, loops: 0, visionCalls: 0, failures: 0 },
  }

  // ---------- 子进程工具 ----------
  async function runCollect(candidates, args, opts) {
    const sp = ctx.subprocess
    const options = opts || {}
    let exe = null
    for (const c of candidates) {
      try { exe = await sp.resolveExecutable(c, undefined, options.signal); break } catch (e) { /* try next */ }
    }
    if (exe === null) exe = candidates[candidates.length - 1]
    const policy = ctx.get('sandboxPolicy')
    const cwd = policy !== undefined && typeof policy.workspaceRoot === 'string' ? policy.workspaceRoot : '.'
    const handle = sp.spawn({
      argv: [exe].concat(args),
      cwd,
      stdio: {
        stdin: options.stdin === undefined ? 'ignore' : { data: String(options.stdin) },
        stdout: { maxBytes: options.maxBytes || 2000000 },
        stderr: { maxBytes: 100000 },
      },
      graceMs: options.graceMs || 10000,
      ...(options.signal !== undefined ? { signal: options.signal } : {}),
    })
    const outcome = await handle.done
    const stdout = handle.collected.stdout !== undefined ? handle.collected.stdout.readFrom(0).text : ''
    const stderr = handle.collected.stderr !== undefined ? handle.collected.stderr.readFrom(0).text : ''
    return { exitCode: outcome.exitCode, stdout, stderr }
  }

  function workspaceRoot() {
    const policy = ctx.get('sandboxPolicy')
    return policy !== undefined && typeof policy.workspaceRoot === 'string' ? policy.workspaceRoot : '.'
  }

  function envOverride(name) {
    const le = ctx.get('launchEnvironment')
    if (le !== undefined && typeof le.get === 'function') {
      try {
        const entry = le.get(name)
        if (entry !== undefined && typeof entry.value === 'string' && entry.value.trim() !== '') return entry.value.trim()
      } catch (e) { /* ignore */ }
    }
    return undefined
  }

  // ---------- MIMO API 密钥/模型（沿用 multi-jiao 已验证逻辑） ----------
  async function detectApiKey() {
    const le = ctx.get('launchEnvironment')
    if (le !== undefined && typeof le.get === 'function') {
      try {
        const entry = le.get(cfg().apiKeyEnv)
        if (entry !== undefined && typeof entry.value === 'string' && entry.value.trim() !== '') {
          return { key: entry.value.trim(), source: 'launch-environment:' + String(entry.source || 'process') }
        }
      } catch (e) { /* fall through */ }
    }
    try {
      const res = await runCollect(PWSH_CANDIDATES, ['-NoProfile', '-NonInteractive', '-Command', "$v=[Environment]::GetEnvironmentVariable('" + cfg().apiKeyEnv + "','User'); if(-not $v){$v=[Environment]::GetEnvironmentVariable('" + cfg().apiKeyEnv + "','Machine')}; if(-not $v){$v=[Environment]::GetEnvironmentVariable('" + cfg().apiKeyEnv + "','Process')}; Write-Output $v"], { maxBytes: 10000 })
      const v = res.stdout.trim()
      if (res.exitCode === 0 && v !== '') return { key: v, source: 'os-environment' }
    } catch (e) { /* ignore */ }
    return undefined
  }

  async function fetchModels() {
    const res = await runCollect(CURL_CANDIDATES, ['-sS', '-m', '30', '-H', 'Authorization: Bearer ' + state.apiKey, cfg().baseURL + '/models'], { maxBytes: 2000000 })
    if (res.exitCode !== 0) throw new Error('models HTTP ' + res.exitCode + ': ' + ((res.stderr || res.stdout) || '').slice(0, 400))
    const parsed = JSON.parse(res.stdout)
    if (!Array.isArray(parsed.data)) throw new Error('models 响应缺少 data 数组')
    return parsed.data.map((m) => String((m && m.id) || '')).filter((id) => id !== '')
  }

  async function ensureApiKey() {
    if (state.apiKey !== undefined) return state.apiKey
    const now = Date.now()
    if (now - state.lastKeyProbe < KEY_PROBE_INTERVAL_MS) return undefined
    state.lastKeyProbe = now
    const found = await detectApiKey()
    if (found === undefined) return undefined
    state.apiKey = found.key
    state.apiKeySource = found.source
    if (state.models.length === 0) {
      try {
        const list = await fetchModels()
        state.models = list
        state.visionModel = pickVisionModel(list, cfg().model || undefined)
        state.status = 'ready'
        state.lastError = undefined
        console.log('[dsh-computer-use] MIMO 视觉就绪：API=' + cfg().baseURL + '，模型 ' + list.length + ' 个，视觉模型=' + (state.visionModel || '(未选中)'))
      } catch (err) {
        state.status = 'models-failed'
        state.lastError = String((err !== null && typeof err === 'object' && err.message) ? err.message : err)
        console.error('[dsh-computer-use] 获取模型列表失败：' + state.lastError)
      }
    }
    return state.apiKey
  }

  async function mimoChat(messages, opts) {
    const key = await ensureApiKey()
    if (key === undefined) throw new Error('未检测到 ' + cfg().apiKeyEnv + ' 环境变量，MIMO 视觉不可用')
    const options = opts || {}
    const model = options.model || state.visionModel
    if (model === undefined || model === '') throw new Error('尚未从 ' + cfg().baseURL + '/models 获取到可用模型，请检查 ' + cfg().apiKeyEnv + ' 与网络')
    const body = JSON.stringify({
      model,
      messages,
      max_tokens: options.maxTokens || cfg().maxOutputTokens,
      temperature: options.temperature === undefined ? 0.2 : options.temperature,
    })
    const timeoutMs = options.timeoutMs || cfg().timeoutMs
    let reqPath = null
    const fsSvc = ctx.fs
    try {
      reqPath = workspaceRoot() + '\\.dsh_computeruse_req.json'
      const target = await fsSvc.resolve(reqPath)
      await fsSvc.writeText(target, body)
    } catch (e) { reqPath = null }
    const dataArgs = reqPath !== null ? ['--data-binary', '@' + reqPath] : ['--data-binary', '@-']
    const res = await runCollect(CURL_CANDIDATES, ['-sS', '--fail-with-body', '-m', String(Math.floor(timeoutMs / 1000) + 1), '-X', 'POST', '-H', 'Authorization: Bearer ' + state.apiKey, '-H', 'Content-Type: application/json'].concat(dataArgs, [cfg().baseURL + '/chat/completions']), { stdin: reqPath !== null ? undefined : body, maxBytes: 4000000, signal: options.signal, graceMs: 15000 })
    state.stats.visionCalls++
    if (res.exitCode !== 0) {
      state.stats.failures++
      const detail = ((res.stdout || '') + ' | ' + (res.stderr || '')).slice(0, 600)
      throw new Error('MIMO HTTP 错误 ' + res.exitCode + ': ' + detail)
    }
    let parsed
    try { parsed = JSON.parse(res.stdout) } catch (e) {
      state.stats.failures++
      throw new Error('MIMO 返回非 JSON: ' + res.stdout.slice(0, 300))
    }
    const text = contentText(parsed.choices !== undefined && parsed.choices[0] !== undefined && parsed.choices[0].message !== undefined ? parsed.choices[0].message.content : '')
    if (text === '') {
      state.stats.failures++
      throw new Error('MIMO 返回空内容: ' + res.stdout.slice(0, 300))
    }
    return text
  }

  async function visionDescribe(imageBytes, mediaType, prompt, opts) {
    const url = 'data:' + mediaType + ';base64,' + bytesToBase64(imageBytes)
    return mimoChat([{ role: 'user', content: [{ type: 'text', text: prompt }, { type: 'image_url', image_url: { url } }] }], opts)
  }

  // 多帧视觉分析：录屏抽帧后把整段时间的画面一次交给 MIMO，
  // 让模型观察动态过程（滚动/动画/加载）而不是只看某一帧。
  async function visionDescribeFrames(frames, prompt, opts) {
    const content = [{ type: 'text', text: prompt }]
    for (const frame of frames) {
      content.push({
        type: 'image_url',
        image_url: { url: 'data:' + (frame.mediaType || 'image/jpeg') + ';base64,' + bytesToBase64(frame.bytes) },
      })
    }
    return mimoChat([{ role: 'user', content }], opts)
  }

  // 删除临时文件/目录（录屏帧目录、循环截图等）。ctx.fs 无删除 API，
  // 经 PowerShell Remove-Item 实现；失败仅记日志不阻断主流程。
  async function removeTempPath(pathStr) {
    try {
      await runCollect(PWSH_CANDIDATES, ['-NoProfile', '-NonInteractive', '-Command', "Remove-Item -LiteralPath '" + String(pathStr).replace(/'/g, "''") + "' -Recurse -Force -ErrorAction SilentlyContinue"], { maxBytes: 10000 })
    } catch (e) {
      console.warn('[dsh-computer-use] 清理临时文件失败 ' + pathStr + ': ' + String((e && e.message) || e))
    }
  }

  // 删除单个临时文件（PowerShell 单文件删除）
  async function removeTempFile(pathStr) {
    try {
      await runCollect(PWSH_CANDIDATES, ['-NoProfile', '-NonInteractive', '-Command', "Remove-Item -LiteralPath '" + String(pathStr).replace(/'/g, "''") + "' -Force -ErrorAction SilentlyContinue"], { maxBytes: 10000 })
    } catch (e) {
      console.warn('[dsh-computer-use] 清理临时文件失败 ' + pathStr + ': ' + String((e && e.message) || e))
    }
  }

  // ---------- C# 助手：按需编译 + 调用（源码内嵌，写到工作区再编译） ----------
  async function compileHelper(signal) {
    const csc = await (async () => {
      for (const c of CSC_CANDIDATES) {
        try { await ctx.subprocess.resolveExecutable(c, undefined, signal); return c } catch (e) { /* next */ }
      }
      return undefined
    })()
    if (csc === undefined) throw new Error('未找到 csc.exe，无法编译电脑操作助手')
    const root = workspaceRoot()
    const outExe = root + '\\.ds_computeruse_helper_' + HELPER_VERSION + '.exe'
    const csPath = root + '\\.ds_computeruse_helper_' + HELPER_VERSION + '.cs'
    const fsSvc = ctx.fs
    try {
      const target = await fsSvc.resolve(csPath)
      await fsSvc.writeText(target, HELPER_SOURCE)
    } catch (e) {
      throw new Error('写入助手源码失败: ' + String((e && e.message) || e))
    }
    // csc 需要正斜杠路径（此前经验：反斜杠在转义链中会丢失）
    const args = [
      '/nologo', '/target:exe', '/out:' + outExe.replace(/\\/g, '/'),
      '/codepage:65001',
      '/r:System.Drawing.dll', '/r:System.Windows.Forms.dll',
      csPath.replace(/\\/g, '/'),
    ]
    const res = await runCollect([csc], args, { maxBytes: 300000, signal, graceMs: 60000 })
    if (res.exitCode !== 0) {
      throw new Error('助手编译失败: ' + ((res.stdout || '') + ' | ' + (res.stderr || '')).slice(0, 600))
    }
    return outExe
  }

  async function ensureHelper(signal) {
    const configured = cfg().helperExe
    if (configured !== '' && configured !== undefined && configured !== null) {
      try { const t = await ctx.fs.resolve(configured); const info = await ctx.fs.stat(t); if (info.isFile()) { state.helperExe = configured; state.helperReady = true; return configured } } catch (e) { /* fall through */ }
    }
    if (state.helperExe !== undefined) {
      try { const t = await ctx.fs.resolve(state.helperExe); const info = await ctx.fs.stat(t); if (info.isFile()) { state.helperReady = true; return state.helperExe } } catch (e) { /* fall through */ }
    }
    const defaultPath = workspaceRoot() + '\\.ds_computeruse_helper_' + HELPER_VERSION + '.exe'
    try { const t = await ctx.fs.resolve(defaultPath); const info = await ctx.fs.stat(t); if (info.isFile()) { state.helperExe = defaultPath; state.helperReady = true; return defaultPath } } catch (e) { /* fall through */ }
    const exe = await compileHelper(signal)
    state.helperExe = exe
    state.helperReady = true
    return exe
  }

  async function helperRun(args, opts) {
    const exe = await ensureHelper(opts && opts.signal)
    const res = await runCollect([exe], args, { maxBytes: 1000000, signal: opts && opts.signal, graceMs: 30000 })
    return { exitCode: res.exitCode, stdout: (res.stdout || '').trim(), stderr: (res.stderr || '').trim() }
  }

  // ---------- 工具定义 ----------
  const tools = []

  tools.push(defineTool({
    name: 'computer_status',
    description: '查看 dsh-computer-use 电脑操作插件状态：C# 助手是否就绪、MIMO 视觉密钥/模型、统计与最近错误。',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    timeoutMs: 30000,
    async execute(_args, exec) {
      await ensureApiKey()
      let helper = '未检查'
      try {
        const exe = await ensureHelper(exec.signal)
        const probe = await helperRun(['noop'], { signal: exec.signal })
        helper = probe.exitCode === 0 ? '就绪 (' + exe + ') —— ' + probe.stdout : '异常（' + probe.stdout + ' ' + probe.stderr + '）'
      } catch (e) {
        helper = '不可用：' + String((e && e.message) || e)
      }
      const lines = [
        'dsh-computer-use · 电脑操作插件状态',
        '- C# 助手：' + helper,
        '- ' + cfg().apiKeyEnv + '：' + (state.apiKey !== undefined ? ('已检测（来源 ' + state.apiKeySource + '，' + maskKey(state.apiKey) + '）') : '未检测到'),
        '- API 地址：' + cfg().baseURL,
        '- 模型列表：' + (state.models.length > 0 ? state.models.length + ' 个：' + state.models.slice(0, 12).join(', ') : '（未获取）'),
        '- 当前视觉模型：' + (state.visionModel !== undefined ? state.visionModel : '（无）'),
        '- 统计：截屏 ' + state.stats.screenshots + '，录屏 ' + state.stats.records + '，操作 ' + state.stats.actions + '，自主循环 ' + state.stats.loops + '，视觉调用 ' + state.stats.visionCalls + '，失败 ' + state.stats.failures,
        '- 最近错误：' + (state.lastError !== undefined ? state.lastError : '（无）'),
        '- 工具：computer_status / computer_screenshot / computer_record / computer_action / computer_use',
      ]
      return lines.join('\n')
    },
  }))

  tools.push(defineTool({
    name: 'computer_screenshot',
    description: '截取当前屏幕并保存为 PNG（路径形如 ~/.dsh_computeruse_shot_N.png）。可选 analyze=true：把截图发给 Xiaomi MIMO 视觉模型，返回对屏幕内容、UI 元素与坐标的文字分析（供纯文本模型理解屏幕）。默认分析完成后自动删除临时截图文件；静态场景（看页面布局等）用本工具。',
    parameters: {
      analyze: { type: 'boolean', description: '是否让 MIMO 视觉模型分析截图内容（默认 false）。' },
      prompt: { type: 'string', description: 'analyze=true 时的分析指令（默认：描述屏幕可见内容、UI 元素及大致坐标）。' },
      model: { type: 'string', description: '可选：指定 MIMO 视觉模型 id，默认用自动选中的模型。' },
      keep: { type: 'boolean', description: '是否保留临时截图文件（默认 false=分析/使用后自动删除）。' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    timeoutMs: 180000,
    async execute(args, exec) {
      await ensureHelper(exec.signal)
      const fsSvc = ctx.fs
      const root = workspaceRoot()
      state.stats.screenshots++
      const shotPath = root + '\\.dsh_computeruse_shot_' + Date.now() + '.png'
      const res = await helperRun(['screenshot', shotPath], { signal: exec.signal })
      if (res.exitCode !== 0) {
        state.stats.failures++
        state.lastError = 'screenshot: ' + (res.stdout || res.stderr)
        throw new Error('截屏失败: ' + (res.stdout || res.stderr))
      }
      if (!args.analyze) {
        // 未分析：直接返回路径；默认不保留临时文件（避免堆积），keep=true 时保留
        const kept = args.keep === true
        if (!kept) await removeTempFile(shotPath)
        return kept ? '截图已保存：' + shotPath + '（' + res.stdout + '）' : '截图已获取：' + shotPath + '（' + res.stdout + '，临时文件已自动清理）'
      }
      let bytes
      try {
        const target = await fsSvc.resolve(shotPath)
        bytes = await fsSvc.readBytes(target, exec.signal, 15 * 1024 * 1024)
      } catch (e) {
        state.stats.failures++
        throw new Error('读取截图失败: ' + String((e && e.message) || e))
      }
      const prompt = (args.prompt || '请分析这张屏幕截图：描述当前可见的界面、UI 元素（按钮/输入框/菜单）及其大致坐标（像素），标注任何异常或需要注意的地方。')
      const text = await visionDescribe(bytes, 'image/png', prompt, { signal: exec.signal, model: args.model })
      if (args.keep !== true) await removeTempFile(shotPath)
      return '截图：' + shotPath + (args.keep === true ? '' : '（临时文件已自动清理）') + '\nMIMO 视觉分析：\n' + text
    },
  }))

  tools.push(defineTool({
    name: 'computer_record',
    description: '录屏一小段时间（动态场景观察）：把当前屏幕录制 seconds 秒、按 fps 抽帧为 JPEG，把整段时间的多帧画面一次交给 Xiaomi MIMO 视觉模型，观察动态过程（滚动、滑动、动画、加载、弹窗变化等）并返回内容与坐标分析。静态场景（看页面布局等）请用 computer_screenshot；动态场景（如微信里下滑找朋友圈、滚动列表）用本工具，可一次看清动态，避免反复截屏浪费时间。默认分析完成后自动删除临时帧文件。',
    parameters: {
      seconds: { type: 'number', description: '录制时长（秒），默认 4。' },
      fps: { type: 'number', description: '抽帧率（帧/秒），默认 2，总帧数上限 60。' },
      prompt: { type: 'string', description: '分析指令（默认：描述这段录屏中的动态过程、界面变化、元素及大致坐标）。' },
      model: { type: 'string', description: '可选：指定 MIMO 视觉模型 id，默认用自动选中的模型。' },
      keep: { type: 'boolean', description: '是否保留临时帧文件（默认 false=分析后自动删除）。' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    timeoutMs: 240000,
    async execute(args, exec) {
      await ensureHelper(exec.signal)
      const fsSvc = ctx.fs
      const root = workspaceRoot()
      state.stats.records++
      const seconds = Math.min(Math.max(args.seconds || 4, 1), 15)
      const fps = Math.min(Math.max(args.fps || 2, 0.5), 10)
      const dir = root + '\\.dsh_computeruse_record_' + Date.now()
      const res = await helperRun(['record', dir, String(seconds), String(fps)], { signal: exec.signal })
      if (res.exitCode !== 0) {
        state.stats.failures++
        state.lastError = 'record: ' + (res.stdout || res.stderr)
        throw new Error('录屏失败: ' + (res.stdout || res.stderr))
      }
      // 解析助手输出的帧路径（每行一个；最后一行是 "ok N frames"）
      const framePaths = (res.stdout || '').split('\n').map((l) => l.trim()).filter((l) => l !== '' && /\.jpg$/i.test(l) && l.startsWith(dir))
      if (framePaths.length === 0) {
        state.stats.failures++
        throw new Error('录屏未产出帧: ' + (res.stdout || res.stderr))
      }
      // 读取全部帧字节
      const frames = []
      for (const p of framePaths) {
        try {
          const target = await fsSvc.resolve(p)
          const bytes = await fsSvc.readBytes(target, exec.signal, 15 * 1024 * 1024)
          frames.push({ bytes, mediaType: 'image/jpeg' })
        } catch (e) {
          console.warn('[dsh-computer-use] 读取帧失败 ' + p + ': ' + String((e && e.message) || e))
        }
      }
      if (frames.length === 0) {
        state.stats.failures++
        throw new Error('读取录屏帧失败')
      }
      const prompt = (args.prompt || '这是一段屏幕录制的连续帧（按时间顺序）。请描述这段动态过程：屏幕上发生了什么变化（滚动/滑动/动画/加载/弹窗等）、当前界面有哪些元素（按钮/输入框/菜单）及其大致坐标（像素），以及任何需要注意的地方。')
      const text = await visionDescribeFrames(frames, prompt, { signal: exec.signal, maxTokens: 4096, temperature: 0.1, model: args.model })
      const summary = '录屏 ' + seconds + 's × ' + fps + 'fps，共 ' + frames.length + ' 帧'
      if (args.keep === true) {
        return '录屏帧已保存：' + dir + '（' + summary + '）\nMIMO 动态分析：\n' + text
      }
      await removeTempPath(dir)
      return '录屏完成：' + summary + '（临时帧已自动清理）\nMIMO 动态分析：\n' + text
    },
  }))

  tools.push(defineTool({
    name: 'computer_action',
    description: '对真实桌面执行单步电脑操作。action 可选：move(移动鼠标 x,y) / click(点击 button=left|right|middle|double, x,y) / drag(x1,y1,x2,y2) / scroll(dy 正=向下) / type(text 输入文本) / keys(按键串，如 {LWIN}{UP}、^{a}、{ENTER}) / run(command 启动程序) / activate(process 窗口进程名, title 可选) / windowrect(process,title 可选 -> 窗口矩形) / listwindows(列出可见窗口) / sendchat(text 向微信当前聊天发送)。',
    parameters: {
      action: { type: 'string', required: true, enum: ['move', 'click', 'drag', 'scroll', 'type', 'keys', 'run', 'activate', 'windowrect', 'listwindows', 'sendchat'], description: '要执行的操作。' },
      x: { type: 'integer', description: '坐标 X（move/click）。' },
      y: { type: 'integer', description: '坐标 Y（move/click）。' },
      button: { type: 'string', enum: ['left', 'right', 'middle', 'double'], description: 'click 的按键。' },
      x1: { type: 'integer', description: 'drag 起点 X。' },
      y1: { type: 'integer', description: 'drag 起点 Y。' },
      x2: { type: 'integer', description: 'drag 终点 X。' },
      y2: { type: 'integer', description: 'drag 终点 Y。' },
      dy: { type: 'integer', description: 'scroll 的滚轮格数（正=向下）。' },
      text: { type: 'string', description: 'type/sendchat 的文本。' },
      keys: { type: 'string', description: 'keys 的按键串，如 {LWIN}{UP}、^{a}、{ENTER}、{TAB}。' },
      command: { type: 'string', description: 'run 要启动的程序（可带参数）。' },
      process: { type: 'string', description: 'activate/windowrect 的进程名（如 notepad、Weixin）。' },
      title: { type: 'string', description: 'activate/windowrect 的可选窗口标题过滤。' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    timeoutMs: 60000,
    async execute(args, exec) {
      const a = args.action
      const argv = [a]
      switch (a) {
        case 'move':
          if (args.x === undefined || args.y === undefined) throw new Error('move 需要 x 与 y')
          argv.push(String(args.x), String(args.y))
          break
        case 'click':
          if (args.x === undefined || args.y === undefined) throw new Error('click 需要 x 与 y')
          argv.push(args.button || 'left', String(args.x), String(args.y))
          break
        case 'drag':
          if (args.x1 === undefined || args.y1 === undefined || args.x2 === undefined || args.y2 === undefined) throw new Error('drag 需要 x1 y1 x2 y2')
          argv.push(String(args.x1), String(args.y1), String(args.x2), String(args.y2))
          break
        case 'scroll':
          argv.push(String(args.dy || 0))
          break
        case 'type':
          if (args.text === undefined || args.text === '') throw new Error('type 需要 text')
          argv.push(args.text)
          break
        case 'keys':
          if (args.keys === undefined || args.keys === '') throw new Error('keys 需要 keys 参数')
          argv.push(args.keys)
          break
        case 'run':
          if (args.command === undefined || args.command === '') throw new Error('run 需要 command')
          argv.push(args.command)
          break
        case 'activate':
          if (args.process === undefined || args.process === '') throw new Error('activate 需要 process')
          argv.push(args.process)
          if (args.title !== undefined) argv.push(args.title)
          break
        case 'windowrect':
          if (args.process === undefined || args.process === '') throw new Error('windowrect 需要 process')
          argv.push(args.process)
          if (args.title !== undefined) argv.push(args.title)
          break
        case 'listwindows':
          break
        case 'sendchat':
          if (args.text === undefined || args.text === '') throw new Error('sendchat 需要 text')
          argv.push(args.text)
          break
        default:
          throw new Error('未知 action: ' + String(a))
      }
      state.stats.actions++
      const res = await helperRun(argv, { signal: exec.signal })
      if (res.exitCode !== 0) {
        state.stats.failures++
        state.lastError = a + ': ' + (res.stdout || res.stderr)
        throw new Error('操作 ' + a + ' 失败: ' + (res.stdout || res.stderr))
      }
      return '操作 ' + a + ' 完成：' + (res.stdout || '(无输出)')
    },
  }))

  tools.push(defineTool({
    name: 'computer_use',
    description: '自主电脑操作循环：给定一个任务（如「打开记事本输入一句话」「在微信里发送消息」），插件会循环执行「观察屏幕（截屏或录屏）→ 交给 MIMO 视觉模型决策下一步 → 用 computer_action 执行」，直到任务完成或达到 maxSteps。观察方式自动选择：静态界面（看布局/确认状态）用截屏，动态场景（滚动、滑动、动画、加载）用录屏抽帧，一次看清动态过程、避免反复截屏。循环结束后自动清理过程中产生的所有临时截图与录屏帧。每步返回决策与执行结果；结束后返回完整过程。',
    parameters: {
      task: { type: 'string', required: true, description: '要完成的电脑操作任务描述。' },
      maxSteps: { type: 'integer', description: '最大循环步数（默认 ' + DEFAULT_MAX_STEPS + '）。' },
      model: { type: 'string', description: '可选：指定 MIMO 视觉模型 id，默认用自动选中的模型。' },
      observe: { type: 'string', enum: ['auto', 'screenshot', 'record'], description: '观察方式：auto（默认，由 MIMO 按场景决定截屏/录屏）、screenshot（强制每步截屏）、record（强制每步录屏）。' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    timeoutMs: 900000,
    async execute(args, exec) {
      const maxSteps = args.maxSteps || DEFAULT_MAX_STEPS
      const fsSvc = ctx.fs
      const root = workspaceRoot()
      const log = []
      const tmpPaths = [] // 记录本次循环产生的临时截图/录屏目录，结束时统一清理
      state.stats.loops++
      const forceObserve = args.observe === 'screenshot' ? 'screenshot' : (args.observe === 'record' ? 'record' : undefined)
      const system = '你是一个电脑操作决策引擎。你通过观察屏幕（截图或录屏帧）来决定下一步操作。任务：' + args.task
        + '\n每次只能输出一个 JSON 对象，格式：{"action":"move|click|type|keys|scroll|run|activate|sendchat|done","x":数字,"y":数字,"button":"left","text":"...","keys":"...","command":"...","process":"...","reason":"为什么这么做"}'
        + '\n坐标基于截图像素（左上角为 0,0）。任务完成时输出 {"action":"done","reason":"总结"}。不要输出 JSON 以外的内容。'
        + (forceObserve === undefined
          ? '\n若下一步需要观察动态过程（如滚动列表、滑动屏幕、等待动画/加载），请在本步 JSON 中额外加 "next_observe":"record" 提示下一步用录屏；静态确认界面则加 "next_observe":"screenshot"。'
          : '')
      let done = false
      let lastDecision = ''
      let nextObserve = forceObserve || 'screenshot'
      for (let step = 1; step <= maxSteps && !done; step++) {
        if (exec.signal !== undefined && exec.signal.aborted) throw new Error('已取消')
        // 1) 观察：按 nextObserve 选择录屏或截屏
        let decisionText
        if (nextObserve === 'record') {
          // 录屏动态观察：3 秒 2fps 共 6 帧
          const recDir = root + '\\.dsh_computeruse_looprec_' + Date.now() + '_' + step
          const rec = await helperRun(['record', recDir, '3', '2'], { signal: exec.signal })
          if (rec.exitCode !== 0) {
            state.stats.failures++
            throw new Error('录屏失败: ' + (rec.stdout || rec.stderr))
          }
          const framePaths = (rec.stdout || '').split('\n').map((l) => l.trim()).filter((l) => /\.jpg$/i.test(l) && l.startsWith(recDir))
          tmpPaths.push(recDir)
          const frames = []
          for (const p of framePaths) {
            try {
              const target = await fsSvc.resolve(p)
              const bytes = await fsSvc.readBytes(target, exec.signal, 15 * 1024 * 1024)
              frames.push({ bytes, mediaType: 'image/jpeg' })
            } catch (e) { /* skip bad frame */ }
          }
          state.stats.screenshots += frames.length
          if (frames.length === 0) {
            state.stats.failures++
            throw new Error('录屏未产出帧: ' + (rec.stdout || rec.stderr))
          }
          decisionText = await visionDescribeFrames(frames, system + '\n\n这是第 ' + step + ' 步的录屏（' + frames.length + ' 帧，动态过程）。请输出你的下一步决策 JSON：', { signal: exec.signal, maxTokens: 4096, temperature: 0.1, model: args.model })
        } else {
          // 截屏静态观察
          const shotPath = root + '\\.dsh_computeruse_loop_' + Date.now() + '.png'
          tmpPaths.push(shotPath)
          state.stats.screenshots++
          const shot = await helperRun(['screenshot', shotPath], { signal: exec.signal })
          if (shot.exitCode !== 0) {
            state.stats.failures++
            throw new Error('截屏失败: ' + (shot.stdout || shot.stderr))
          }
          let bytes
          try {
            const target = await fsSvc.resolve(shotPath)
            bytes = await fsSvc.readBytes(target, exec.signal, 15 * 1024 * 1024)
          } catch (e) {
            state.stats.failures++
            throw new Error('读取截图失败: ' + String((e && e.message) || e))
          }
          decisionText = await visionDescribe(bytes, 'image/png', system + '\n\n这是第 ' + step + ' 步截图。请输出你的下一步决策 JSON：', { signal: exec.signal, maxTokens: 4096, temperature: 0.1, model: args.model })
        }
        const decision = parseJsonLoose(decisionText)
        if (decision === undefined || typeof decision.action !== 'string') {
          state.stats.failures++
          state.lastError = '第 ' + step + ' 步 MIMO 决策不是有效 JSON: ' + decisionText.slice(0, 300)
          log.push('第 ' + step + ' 步：MIMO 决策解析失败：' + decisionText.slice(0, 300))
          break
        }
        lastDecision = decisionText
        // 2) 根据模型指示决定下一步观察方式
        if (forceObserve === undefined) {
          nextObserve = decision.next_observe === 'record' ? 'record' : 'screenshot'
        }
        if (decision.action === 'done') {
          done = true
          log.push('第 ' + step + ' 步：任务完成 —— ' + (decision.reason || ''))
          break
        }
        // 3) 执行
        const argv = [decision.action]
        const push = (k) => { if (decision[k] !== undefined && decision[k] !== null) argv.push(String(decision[k])) }
        switch (decision.action) {
          case 'move': push('x'); push('y'); break
          case 'click': argv.push(decision.button || 'left'); push('x'); push('y'); break
          case 'drag': push('x1'); push('y1'); push('x2'); push('y2'); break
          case 'scroll': push('dy'); break
          case 'type': push('text'); break
          case 'keys': push('keys'); break
          case 'run': push('command'); break
          case 'activate': push('process'); push('title'); break
          case 'sendchat': push('text'); break
          case 'windowrect': push('process'); break
          default:
            state.stats.failures++
            log.push('第 ' + step + ' 步：MIMO 返回未知动作 ' + decision.action + '，中止循环')
            done = true
            continue
        }
        state.stats.actions++
        const out = await helperRun(argv, { signal: exec.signal })
        const outcome = out.exitCode === 0 ? (out.stdout || '(完成)') : ('失败: ' + (out.stdout || out.stderr))
        log.push('第 ' + step + ' 步：' + decision.action + ' ' + argv.slice(1).join(' ') + ' —— ' + outcome + '（理由：' + (decision.reason || '') + '）')
        if (out.exitCode !== 0) {
          state.stats.failures++
          state.lastError = decision.action + ': ' + (out.stdout || out.stderr)
        }
      }
      if (!done) log.push('达到最大步数 ' + maxSteps + '，循环结束（任务可能未完成）。')
      // 4) 循环结束：统一清理本次产生的全部临时截图与录屏帧
      for (const p of tmpPaths) {
        if (/\.png$/i.test(p)) await removeTempFile(p)
        else await removeTempPath(p)
      }
      log.push('已自动清理本次循环产生的 ' + tmpPaths.length + ' 个临时截图/录屏文件')
      return '任务：' + args.task + '\n' + log.join('\n') + '\n最后决策原文：\n' + lastDecision.slice(0, 1500)
    },
  }))

  for (const tool of tools) {
    ctx.tools.register(tool)
  }

  // ---------- 系统提示段 ----------
  if (cfg().announceToAgent) {
    ctx.systemPrompt.section({
      name: 'tool:dsh-computer-use',
      order: SECTION_ORDER,
      text: COMPUTER_GUIDANCE,
    })
  }

  // ---------- 启动自检 ----------
  void (async () => {
    try {
      await ensureHelper()
    } catch (e) {
      state.lastError = '助手初始化失败：' + String((e && e.message) || e)
      console.error('[dsh-computer-use] ' + state.lastError)
    }
    const key = await ensureApiKey()
    if (key === undefined) {
      state.status = 'no-api-key'
      state.lastError = '未检测到 ' + cfg().apiKeyEnv + '（已检查启动环境变量与系统/用户环境变量）'
      console.error('[dsh-computer-use] ' + state.lastError + '。视觉分析暂不可用，电脑操作不受影响；设置环境变量后自动重试。')
    }
  })()
}
