// dsh-computer-use 电脑操作助手 v9
// 编译：C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /nologo /target:exe
//       /out:<exe> /codepage:65001 /r:System.Drawing.dll /r:System.Windows.Forms.dll helper.cs
// 命令（argv[0]=命令名）：
//   noop                      自检
//   screenshot <outPath>      全屏截图 -> PNG
//   record <outDir> <seconds> <fps> [quality]  录屏抽帧 -> JPEG（动态场景观察）
//   move <x> <y>              移动鼠标
//   click <button> <x> <y>    点击（left|right|middle|double）
//   drag <x1> <y1> <x2> <y2>  拖拽
//   scroll <dy>               滚轮（正=向下）
//   type <text>               剪贴板 + Ctrl+V 输入文本
//   keys <spec>               按键（SendKeys 风格，支持 {LWIN} {ENTER} {TAB} {ESC} 等）
//   run <file> [args...]      启动程序并尝试置前
//   activate <proc> [title]   激活窗口（进程名/标题）
//   windowrect <proc> [title] 输出窗口矩形 "left top w h"
//   listwindows               列出可见窗口（proc | title | left,top wxh | hwnd）
//   sendchat <text>           微信发送：激活 -> 点输入框 -> 粘贴 -> 回车
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

public static class ComputerHelper
{
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }

    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")] static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    [DllImport("user32.dll")] static extern short VkKeyScan(char ch);
    [DllImport("user32.dll")] static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

    const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    const uint MOUSEEVENTF_LEFTUP = 0x0004;
    const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
    const uint MOUSEEVENTF_RIGHTUP = 0x0010;
    const uint MOUSEEVENTF_MIDDLEDOWN = 0x0020;
    const uint MOUSEEVENTF_MIDDLEUP = 0x0040;
    const uint MOUSEEVENTF_WHEEL = 0x0800;
    const uint KEYEVENTF_KEYUP = 0x0002;
    const int SW_RESTORE = 9;

    static readonly Dictionary<string, byte> KEYMAP = new Dictionary<string, byte>(StringComparer.OrdinalIgnoreCase)
    {
        { "LWIN", 0x5B }, { "RWIN", 0x5C },
        { "ENTER", 0x0D }, { "RETURN", 0x0D }, { "TAB", 0x09 }, { "ESC", 0x1B }, { "ESCAPE", 0x1B },
        { "UP", 0x26 }, { "DOWN", 0x28 }, { "LEFT", 0x25 }, { "RIGHT", 0x27 },
        { "HOME", 0x24 }, { "END", 0x23 }, { "PGUP", 0x21 }, { "PAGEDOWN", 0x22 }, { "PAGEUP", 0x21 }, { "PGDN", 0x22 },
        { "DELETE", 0x2E }, { "DEL", 0x2E }, { "BACKSPACE", 0x08 }, { "BS", 0x08 }, { "SPACE", 0x20 },
        { "CAPSLOCK", 0x14 }, { "NUMLOCK", 0x90 }, { "SCROLLLOCK", 0x91 }, { "PRTSC", 0x2C },
        { "ADD", 0x6B }, { "SUBTRACT", 0x6D }, { "MULTIPLY", 0x6A }, { "DIVIDE", 0x6F },
        { "LCTRL", 0xA2 }, { "RCTRL", 0xA3 }, { "LSHIFT", 0xA0 }, { "RSHIFT", 0xA1 }, { "LALT", 0xA4 }, { "RALT", 0xA5 },
    };

    [STAThread]
    public static int Main(string[] args)
    {
        if (args.Length < 1) { Console.WriteLine("usage: <cmd> ..."); return 0; }
        string cmd = args[0].ToLowerInvariant();
        try
        {
            switch (cmd)
            {
                case "noop": Console.WriteLine("noop v9"); return 0;
                case "screenshot": return Screenshot(args);
                case "record": return Record(args);
                case "move": return Move(args);
                case "click": return Click(args);
                case "drag": return Drag(args);
                case "scroll": return Scroll(args);
                case "type": return Type(args);
                case "keys": return Keys(args);
                case "run": return Run(args);
                case "activate": return Activate(args);
                case "windowrect": return WindowRect(args);
                case "listwindows": return ListWindows(args);
                case "sendchat": return SendChat(args);
                default: Console.WriteLine("unknown cmd: " + cmd); return 2;
            }
        }
        catch (Exception ex) { Console.WriteLine("error: " + ex.Message); return 1; }
    }

    static int Screenshot(string[] args)
    {
        if (args.Length < 2) { Console.WriteLine("error: screenshot <outPath>"); return 2; }
        Rectangle bounds = Screen.PrimaryScreen.Bounds;
        using (Bitmap bmp = new Bitmap(bounds.Width, bounds.Height))
        {
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.CopyFromScreen(bounds.X, bounds.Y, 0, 0, bounds.Size);
            }
            bmp.Save(args[1], ImageFormat.Png);
        }
        Console.WriteLine("ok " + bounds.Width + "x" + bounds.Height + " -> " + args[1]);
        return 0;
    }

    static int Record(string[] args)
    {
        // record <outDir> <seconds> <fps> [quality]
        if (args.Length < 4) { Console.WriteLine("error: record <outDir> <seconds> <fps> [quality]"); return 2; }
        string outDir = args[1];
        double seconds;
        double fps;
        int quality = args.Length > 4 ? int.Parse(args[4], CultureInfo.InvariantCulture) : 70;
        if (!double.TryParse(args[2], NumberStyles.Float, CultureInfo.InvariantCulture, out seconds) || seconds <= 0) { Console.WriteLine("error: invalid seconds"); return 2; }
        if (!double.TryParse(args[3], NumberStyles.Float, CultureInfo.InvariantCulture, out fps) || fps <= 0) { Console.WriteLine("error: invalid fps"); return 2; }
        try { Directory.CreateDirectory(outDir); } catch (Exception ex) { Console.WriteLine("error: cannot create outDir: " + ex.Message); return 1; }
        Rectangle bounds = Screen.PrimaryScreen.Bounds;
        int totalFrames = (int)Math.Ceiling(seconds * fps);
        if (totalFrames > 120) { Console.WriteLine("error: too many frames (" + totalFrames + "), reduce seconds/fps"); return 2; }
        ImageCodecInfo jpegCodec = null;
        foreach (ImageCodecInfo codec in ImageCodecInfo.GetImageEncoders())
            if (codec.FormatID == ImageFormat.Jpeg.Guid) { jpegCodec = codec; break; }
        EncoderParameters encParams = new EncoderParameters(1);
        encParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, (long)quality);
        double intervalMs = 1000.0 / fps;
        var sw = Stopwatch.StartNew();
        for (int i = 0; i < totalFrames; i++)
        {
            using (Bitmap bmp = new Bitmap(bounds.Width, bounds.Height))
            {
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.CopyFromScreen(bounds.X, bounds.Y, 0, 0, bounds.Size);
                }
                string path = Path.Combine(outDir, "frame_" + i.ToString("D3") + ".jpg");
                try {
                    if (jpegCodec != null) bmp.Save(path, jpegCodec, encParams);
                    else bmp.Save(path, ImageFormat.Jpeg);
                } catch (Exception ex) { Console.WriteLine("error: save frame failed: " + ex.Message); return 1; }
                Console.WriteLine(path);
            }
            if (i < totalFrames - 1)
            {
                double targetMs = (i + 1) * intervalMs;
                double waitMs = targetMs - sw.Elapsed.TotalMilliseconds;
                if (waitMs > 0) Thread.Sleep((int)waitMs);
            }
        }
        Console.WriteLine("ok " + totalFrames + " frames -> " + outDir);
        return 0;
    }

    static int Move(string[] args)
    {
        if (args.Length < 3) { Console.WriteLine("error: move <x> <y>"); return 2; }
        int x = int.Parse(args[1]); int y = int.Parse(args[2]);
        SetCursorPos(x, y);
        Console.WriteLine("ok moved " + x + "," + y);
        return 0;
    }

    static int Click(string[] args)
    {
        if (args.Length < 4) { Console.WriteLine("error: click <button> <x> <y>"); return 2; }
        string button = args[1].ToLowerInvariant();
        int x = int.Parse(args[2]); int y = int.Parse(args[3]);
        SetCursorPos(x, y);
        Thread.Sleep(40);
        uint down = MOUSEEVENTF_LEFTDOWN, up = MOUSEEVENTF_LEFTUP;
        if (button == "right") { down = MOUSEEVENTF_RIGHTDOWN; up = MOUSEEVENTF_RIGHTUP; }
        else if (button == "middle") { down = MOUSEEVENTF_MIDDLEDOWN; up = MOUSEEVENTF_MIDDLEUP; }
        if (button == "double")
        {
            mouse_event(down, 0, 0, 0, UIntPtr.Zero); mouse_event(up, 0, 0, 0, UIntPtr.Zero);
            Thread.Sleep(60);
            mouse_event(down, 0, 0, 0, UIntPtr.Zero); mouse_event(up, 0, 0, 0, UIntPtr.Zero);
        }
        else
        {
            mouse_event(down, 0, 0, 0, UIntPtr.Zero); mouse_event(up, 0, 0, 0, UIntPtr.Zero);
        }
        Console.WriteLine("ok click " + button + " " + x + "," + y);
        return 0;
    }

    static int Drag(string[] args)
    {
        if (args.Length < 5) { Console.WriteLine("error: drag <x1> <y1> <x2> <y2>"); return 2; }
        int x1 = int.Parse(args[1]), y1 = int.Parse(args[2]), x2 = int.Parse(args[3]), y2 = int.Parse(args[4]);
        SetCursorPos(x1, y1); Thread.Sleep(40);
        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero); Thread.Sleep(80);
        int steps = 20;
        for (int i = 1; i <= steps; i++)
        {
            int cx = x1 + (x2 - x1) * i / steps;
            int cy = y1 + (y2 - y1) * i / steps;
            SetCursorPos(cx, cy); Thread.Sleep(12);
        }
        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero);
        Console.WriteLine("ok drag " + x1 + "," + y1 + " -> " + x2 + "," + y2);
        return 0;
    }

    static int Scroll(string[] args)
    {
        if (args.Length < 2) { Console.WriteLine("error: scroll <dy>"); return 2; }
        int dy = int.Parse(args[1]);
        mouse_event(MOUSEEVENTF_WHEEL, 0, 0, (uint)(dy * 120), UIntPtr.Zero);
        Console.WriteLine("ok scroll " + dy);
        return 0;
    }

    static int Type(string[] args)
    {
        if (args.Length < 2) { Console.WriteLine("error: type <text>"); return 2; }
        string text = args[1];
        Clipboard.SetText(text);
        Thread.Sleep(80);
        keybd_event(0x11, 0, 0, UIntPtr.Zero);
        keybd_event(0x56, 0, 0, UIntPtr.Zero);
        keybd_event(0x56, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
        keybd_event(0x11, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
        Console.WriteLine("ok typed " + text.Length + " chars");
        return 0;
    }

    static int Keys(string[] args)
    {
        if (args.Length < 2) { Console.WriteLine("error: keys <spec>"); return 2; }
        string spec = args[1];
        for (int i = 0; i < spec.Length; i++)
        {
            char c = spec[i];
            bool ctrl = false, alt = false, shift = false;
            while (c == '^' || c == '%' || c == '+')
            {
                if (c == '^') ctrl = true; else if (c == '%') alt = true; else shift = true;
                i++;
                if (i >= spec.Length) break;
                c = spec[i];
            }
            byte vk = 0; char literal = '\0'; bool isLiteral = false;
            if (c == '{')
            {
                int close = spec.IndexOf('}', i);
                if (close < 0) { Console.WriteLine("error: unmatched {"); return 2; }
                string token = spec.Substring(i + 1, close - i - 1);
                int fn;
                byte mapped;
                if (token.Length > 1 && (token[0] == 'F' || token[0] == 'f') && int.TryParse(token.Substring(1), out fn) && fn >= 1 && fn <= 24)
                {
                    vk = (byte)(0x6F + fn);
                }
                else if (KEYMAP.TryGetValue(token, out mapped)) { vk = mapped; }
                else { Console.WriteLine("error: unknown key token {" + token + "}"); return 2; }
                i = close;
            }
            else { literal = c; isLiteral = true; }
            if (ctrl) keybd_event(0x11, 0, 0, UIntPtr.Zero);
            if (alt) keybd_event(0x12, 0, 0, UIntPtr.Zero);
            if (shift) keybd_event(0x10, 0, 0, UIntPtr.Zero);
            if (isLiteral)
            {
                short scan = VkKeyScan(literal);
                byte v = (byte)(scan & 0xFF);
                bool needShift = (scan & 0x0100) != 0;
                if (needShift) keybd_event(0x10, 0, 0, UIntPtr.Zero);
                keybd_event(v, 0, 0, UIntPtr.Zero);
                keybd_event(v, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                if (needShift) keybd_event(0x10, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
            }
            else
            {
                keybd_event(vk, 0, 0, UIntPtr.Zero);
                keybd_event(vk, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
            }
            if (shift) keybd_event(0x10, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
            if (alt) keybd_event(0x12, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
            if (ctrl) keybd_event(0x11, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
        }
        Console.WriteLine("ok keys");
        return 0;
    }

    static int Run(string[] args)
    {
        if (args.Length < 2) { Console.WriteLine("error: run <file> [args...]"); return 2; }
        string file = args[1];
        string rest = "";
        int sp = file.IndexOf(' ');
        if (sp > 0) { rest = file.Substring(sp + 1).Trim(); file = file.Substring(0, sp); }
        Process p = Process.Start(new ProcessStartInfo { FileName = file, Arguments = rest, UseShellExecute = true });
        IntPtr h = IntPtr.Zero;
        try
        {
            Thread.Sleep(900);
            p.Refresh();
            h = p.MainWindowHandle;
            if (h == IntPtr.Zero)
            {
                keybd_event(0x12, 0, 0, UIntPtr.Zero);
                keybd_event(0x12, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                Thread.Sleep(200);
                p.Refresh();
                h = p.MainWindowHandle;
            }
        }
        catch (Exception) { /* UseShellExecute 下部分进程拿不到窗口句柄，忽略 */ }
        if (h != IntPtr.Zero)
        {
            ShowWindow(h, SW_RESTORE);
            SetForegroundWindow(h);
        }
        Console.WriteLine("ok run pid=" + p.Id + " hwnd=" + h);
        return 0;
    }

    static IntPtr FindWindow(string procFilter, string titleFilter)
    {
        IntPtr found = IntPtr.Zero;
        EnumWindows(delegate (IntPtr h, IntPtr l)
        {
            uint pid;
            GetWindowThreadProcessId(h, out pid);
            string proc = "";
            try { proc = Process.GetProcessById((int)pid).ProcessName; } catch { }
            StringBuilder sb = new StringBuilder(512);
            GetWindowText(h, sb, 512);
            string title = sb.ToString();
            bool procMatch = string.IsNullOrEmpty(procFilter)
                || proc.IndexOf(procFilter, StringComparison.OrdinalIgnoreCase) >= 0;
            bool titleMatch = string.IsNullOrEmpty(titleFilter)
                || title.IndexOf(titleFilter, StringComparison.OrdinalIgnoreCase) >= 0;
            bool hasTitle = title.Trim().Length > 0;
            if (procMatch && titleMatch && hasTitle)
            {
                if (IsWindowVisible(h)) { found = h; return false; }
                if (found == IntPtr.Zero) found = h;
            }
            return true;
        }, IntPtr.Zero);
        return found;
    }

    static int Activate(string[] args)
    {
        if (args.Length < 2) { Console.WriteLine("error: activate <proc> [title]"); return 2; }
        IntPtr h = FindWindow(args[1], args.Length > 2 ? args[2] : "");
        if (h == IntPtr.Zero) { Console.WriteLine("error: window not found for " + args[1]); return 1; }
        keybd_event(0x12, 0, 0, UIntPtr.Zero);
        keybd_event(0x12, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
        Thread.Sleep(100);
        ShowWindow(h, SW_RESTORE);
        SetForegroundWindow(h);
        Console.WriteLine("ok activated hwnd=" + h);
        return 0;
    }

    static int WindowRect(string[] args)
    {
        if (args.Length < 2) { Console.WriteLine("error: windowrect <proc> [title]"); return 2; }
        IntPtr h = FindWindow(args[1], args.Length > 2 ? args[2] : "");
        if (h == IntPtr.Zero) { Console.WriteLine("error: window not found"); return 1; }
        RECT r;
        GetWindowRect(h, out r);
        Console.WriteLine("ok " + r.Left + " " + r.Top + " " + (r.Right - r.Left) + " " + (r.Bottom - r.Top));
        return 0;
    }

    static int ListWindows(string[] args)
    {
        EnumWindows(delegate (IntPtr h, IntPtr l)
        {
            uint pid;
            GetWindowThreadProcessId(h, out pid);
            string proc = "";
            try { proc = Process.GetProcessById((int)pid).ProcessName; } catch { }
            StringBuilder sb = new StringBuilder(512);
            GetWindowText(h, sb, 512);
            string title = sb.ToString();
            if (title.Trim().Length > 0 && IsWindowVisible(h))
            {
                RECT r;
                GetWindowRect(h, out r);
                Console.WriteLine(proc + " | " + title + " | " + r.Left + "," + r.Top + " " + (r.Right - r.Left) + "x" + (r.Bottom - r.Top) + " | " + h);
            }
            return true;
        }, IntPtr.Zero);
        return 0;
    }

    static int SendChat(string[] args)
    {
        if (args.Length < 2) { Console.WriteLine("error: sendchat <text>"); return 2; }
        string text = args[1];
        string[] candidates = new[] { "Weixin", "WeChat", "微信", "QQ" };
        IntPtr h = IntPtr.Zero;
        foreach (string c in candidates)
        {
            h = FindWindow(c, "");
            if (h != IntPtr.Zero) break;
        }
        if (h == IntPtr.Zero) { Console.WriteLine("error: no chat window found"); return 1; }
        keybd_event(0x12, 0, 0, UIntPtr.Zero);
        keybd_event(0x12, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
        Thread.Sleep(100);
        ShowWindow(h, SW_RESTORE);
        SetForegroundWindow(h);
        Thread.Sleep(400);
        RECT r;
        GetWindowRect(h, out r);
        int w = r.Right - r.Left;
        int hgt = r.Bottom - r.Top;
        int cx = r.Left + (int)(w * 0.62);
        int cy = r.Bottom - 55;
        SetCursorPos(cx, cy);
        Thread.Sleep(150);
        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero);
        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero);
        Thread.Sleep(200);
        Clipboard.SetText(text);
        Thread.Sleep(80);
        keybd_event(0x11, 0, 0, UIntPtr.Zero);
        keybd_event(0x56, 0, 0, UIntPtr.Zero);
        keybd_event(0x56, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
        keybd_event(0x11, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
        Thread.Sleep(120);
        keybd_event(0x0D, 0, 0, UIntPtr.Zero);
        keybd_event(0x0D, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
        Console.WriteLine("ok sendchat " + text.Length + " chars");
        return 0;
    }
}
