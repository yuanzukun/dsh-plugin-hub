# dsh-session-delete

[![DSH plugin](https://img.shields.io/badge/DSH-plugin-111827)](https://github.com/topics/dsh-plugin)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

[English](README.en.md) | 简体中文

一个面向 DeepSeek Harness Web 的开源插件：在会话三点菜单中增加“删除会话”，并通过二次确认降低误删风险。项目遵循 DSH 插件的 `package.json` bundle/client 格式，不修改官方侧边栏源码。

## 插件介绍

插件只处理 DSH 默认 JSONL 会话持久化后端。它会在用户明确确认后删除目标会话目录；活动会话会先停止 agent、等待写入完成，再清理运行态注册。无法确认会话身份、后端不兼容或目标越过持久化根目录时，插件会拒绝操作。

插件不发起网络请求、不读取凭据、不收集或上传会话内容。永久删除不可恢复，需要保留记录时请使用 DSH 自带的“归档会话”。

## 功能

- 在现有“归档会话”下方增加“删除会话”，不替换官方侧边栏。
- 删除前显示会话名称、不可恢复提示和强制确认复选框。
- 删除活动会话前停止 agent、等待写入完成并清理运行时注册项。
- 只支持官方 JSONL 会话持久化后端；其他后端会拒绝操作并保留数据。
- 递归删除前校验目标位于 JSONL 持久化根目录之下。
- 不发起网络请求，不收集或上传会话内容。

## 环境要求

- DeepSeek Harness `0.1.0-rc.6` 或兼容版本
- Node.js 20 或更高版本
- `web` profile
- 默认 JSONL 会话持久化后端

## 安装

从 GitHub 安装标准 DSH bundle：

```sh
dsh plugin --profile web add github:StarsTom/dsh-session-delete
```

安装后完整重启 DSH Web 服务，再刷新页面。`dsh.bundle` 会自动把插件加入 profile；不要再向 profile 的 `cordis.patch.yml` 手工插入同一个插件，否则会产生重复 loader id，导致 DSH 启动失败。

开发时可以从本地目录安装：

```sh
cd /path/to/dsh-session-delete
dsh plugin --profile web add .
```

## 使用方法

1. 在左侧会话列表中找到目标会话。
2. 点击会话右侧三点按钮。
3. 选择“删除会话”。
4. 核对会话名称，勾选确认项后点击“永久删除”。

永久删除无法恢复。需要保留记录时请使用官方“归档会话”。

## 卸载

```sh
dsh plugin --profile web remove dsh-session-delete
```

重启 DSH Web 服务后生效。卸载插件不会删除任何会话。

## 工作方式与兼容性

当前 DSH 公共 slot 尚未暴露会话菜单扩展点，因此浏览器端只在检测到官方“归档会话”菜单项时追加入口。DSH 后续若调整侧边栏 DOM 或菜单文案，插件会停止注入，而不会替换或破坏原菜单。

服务端 RPC 仅接受 loopback 权限。删除流程只使用 DSH 注入的 `sessions`、`agents` 和 `sessionPersistence` 服务，不读取凭据，也不访问网络。删除失败时返回脱敏错误，绝对路径和文件系统细节只保留在本机 DSH 日志中。

## 开发与验证

```sh
npm run check
npm test
npm pack --dry-run
```

测试覆盖活动会话、冷会话、持久化写入退役等待、目录删除、根目录越界拒绝、重复会话名拒绝和确认契约。真实删除前仍应在不含重要数据的测试 profile 中验证。

## 版本

当前版本：`0.1.3`。完整记录见 [CHANGELOG.md](CHANGELOG.md)。

## 社区与反馈

- [DSH 插件社区主题](https://github.com/topics/dsh-plugin)
- [提交问题或建议](https://github.com/StarsTom/dsh-session-delete/issues)
- [源代码仓库](https://github.com/StarsTom/dsh-session-delete)

本项目是个人开源插件，不代表 DeepSeek 官方；请先在 disposable profile 中验证，再处理重要会话。

## 许可证

[MIT](LICENSE)
