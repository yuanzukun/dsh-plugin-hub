import assert from "node:assert/strict";
import { readFile, readdir, stat } from "node:fs/promises";
import { dirname, join, relative } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const manifest = JSON.parse(await readFile(join(root, "package.json"), "utf8"));

/**
 * 递归列出发布白名单中的普通文件。
 *
 * @param {string} path - package.json files 字段解析后的绝对路径。
 * @returns {Promise<string[]>} 可读取并参与隐私扫描的绝对文件路径。
 */
async function listFiles(path) {
  const entries = await readdir(path, { withFileTypes: true });
  const nested = await Promise.all(entries.map((entry) => {
    const target = join(path, entry.name);
    return entry.isDirectory() ? listFiles(target) : [target];
  }));
  return nested.flat();
}

/**
 * 展开 npm files 白名单；不存在的路径由文件 API 直接报错，使发布检查失败。
 *
 * @returns {Promise<string[]>} 去重后的发布文件列表，始终包含 package.json。
 */
async function publishFiles() {
  const files = [join(root, "package.json")];
  for (const item of manifest.files) {
    const target = join(root, item);
    const info = await stat(target);
    files.push(...(info.isDirectory() ? await listFiles(target) : [target]));
  }
  return [...new Set(files)];
}

/**
 * 枚举将提交到 GitHub 的公开文件，排除版本控制目录和本地生成物。
 *
 * @param {string} directory - 当前仓库目录。
 * @returns {Promise<string[]>} 需要执行隐私扫描的仓库文件绝对路径。
 *
 * 设计意图：npm 的 files 白名单不能覆盖 GitHub 仓库中的测试、CI 和文档；
 * 公开仓库扫描必须覆盖这些文件，避免只验证 tarball 却把本机信息推上 GitHub。
 */
async function repositoryFiles(directory) {
  const ignoredDirectories = new Set([".git", "node_modules", "dist", "release"]);
  const ignoredFiles = new Set(["dsh-session-delete-0.1.2.tgz"]);
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(entries.flatMap((entry) => {
    if (entry.isDirectory() && ignoredDirectories.has(entry.name)) return [];
    if (entry.isFile() && (ignoredFiles.has(entry.name) || entry.name.endsWith(".tgz"))) return [];
    const target = join(directory, entry.name);
    return entry.isDirectory() ? [repositoryFiles(target)] : [[target]];
  }));
  return nested.flat(Infinity);
}

assert.equal(manifest.name, "dsh-session-delete");
assert.match(manifest.version, /^\d+\.\d+\.\d+$/);
assert.equal(manifest.license, "MIT");
assert.equal(manifest.dsh?.bundle?.patch, "./cordis.patch.yml");
assert.equal(manifest.repository?.url, "git+https://github.com/StarsTom/dsh-session-delete.git");
assert.ok(manifest.keywords.includes("dsh-plugin"));

const forbidden = [
  ["Windows absolute path", /(?:^|[\s"'`(])(?:[A-Za-z]:[\\/])/m],
  ["user home path", /(?:^|[\s"'`(])(?:\/Users\/|\/home\/|\\Users\\)/m],
  ["local file dependency", /\b(?:file|link):[^\s"']+/i],
  ["private key", /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
  ["credential assignment", /(?:api[_-]?key|access[_-]?token|secret|password|passwd)\s*[:=]\s*["'][^"']{8,}["']/i],
];

const packageFiles = await publishFiles();
const publicFiles = await repositoryFiles(root);
for (const path of [...new Set([...packageFiles, ...publicFiles])]) {
  const content = await readFile(path, "utf8");
  for (const [label, pattern] of forbidden) {
    assert.doesNotMatch(content, pattern, `${relative(root, path)} contains ${label}`);
  }
}

console.log(`release privacy check passed (package: ${packageFiles.length}, repository: ${publicFiles.length} files)`);
