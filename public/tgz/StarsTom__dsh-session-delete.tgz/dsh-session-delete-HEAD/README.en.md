# dsh-session-delete

[![DSH plugin](https://img.shields.io/badge/DSH-plugin-111827)](https://github.com/topics/dsh-plugin)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

English | [简体中文](README.md)

Adds a **Delete session** item to the DeepSeek Harness Web session menu. A destructive action cannot run until the user opens a second confirmation dialog and checks the acknowledgement box.

## Features

- Appends **Delete session** below the existing archive action without replacing the shipped sidebar.
- Shows the session name, an irreversible-action warning, and a required acknowledgement checkbox.
- Stops an active agent, drains persistence writes, and detaches live registry entries before deletion.
- Supports the official JSONL session persistence backend only; unsupported backends are rejected without deleting data.
- Confirms that the recursive deletion target is below the JSONL persistence root.
- Makes no network requests and does not collect or upload session content.

## Requirements

- DeepSeek Harness `0.1.0-rc.6` or a compatible release
- Node.js 20 or later
- The `web` profile
- The default JSONL session persistence backend

## Install

Install the standard DSH bundle from GitHub:

```sh
dsh plugin --profile web add github:StarsTom/dsh-session-delete
```

Fully restart the DSH Web service, then refresh the page. The `dsh.bundle` manifest mounts the plugin automatically. Do not also add the same plugin to the profile `cordis.patch.yml`, because duplicate loader ids prevent startup.

For local development:

```sh
cd /path/to/dsh-session-delete
dsh plugin --profile web add .
```

## Use

1. Find the target in the left session list.
2. Open the session's three-dot menu.
3. Select **Delete session**.
4. Verify the name, check the acknowledgement, and choose **Delete permanently**.

Permanent deletion cannot be undone. Use the built-in archive action when the record should be retained.

## Uninstall

```sh
dsh plugin --profile web remove dsh-session-delete
```

Restart the DSH Web service. Removing the plugin does not delete sessions.

## Design and compatibility

The current public DSH slot contract does not expose session-menu contributions. The client therefore appends its action only when it finds the shipped archive item. If a later DSH release changes that menu's DOM or labels, the plugin stops injecting instead of replacing or damaging the original menu.

The host RPC requires loopback authority. The deletion flow uses only the injected `sessions`, `agents`, and `sessionPersistence` services; it does not read credentials or access the network.

## Development

```sh
npm run check
npm test
npm pack --dry-run
```

The smoke test covers active and cold sessions, persistence retirement, directory removal, and rejection of a persistence-root deletion target. Test real deletion in a disposable profile before using it with important data.

## Version

Current version: `0.1.3`. See [CHANGELOG.md](CHANGELOG.md).

## Community and feedback

- [DSH plugin topic](https://github.com/topics/dsh-plugin)
- [Issues and suggestions](https://github.com/StarsTom/dsh-session-delete/issues)
- [Source repository](https://github.com/StarsTom/dsh-session-delete)

This is an independently maintained open-source plugin and is not an official DeepSeek product. Test it in a disposable profile before using it with important sessions.

## License

[MIT](LICENSE)
