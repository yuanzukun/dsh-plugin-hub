import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { access, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { apply } from "../lib/index.js";

async function exists(path) {
  try {
    await access(path);
    return true;
  } catch {
    return false;
  }
}

function fixture({ cold, directory, sessionId, persistenceRoot = dirname(directory) }) {
  const header = { id: sessionId };
  const session = { id: sessionId, header, events: [] };
  const sessionsStore = new Map();
  const agentsStore = new Map();
  const retirementReads = [];
  let handler;
  let channel;
  let created = false;
  let disposed = false;
  let preparedDisposed = false;
  let cancelled = false;
  let agentScopeDisposed = false;
  let directoryExistedWhenDetached;

  const persistence = {
    root: persistenceRoot,
    coordinator: { retirements: new Map() },
    locate() {
      return { kind: "jsonl", path: join(directory, "session.jsonl") };
    },
    async list() {
      return [header];
    },
    async readFrom(id) {
      retirementReads.push(id);
    },
    async prepare() {
      return {
        session,
        [Symbol.dispose]() {
          preparedDisposed = true;
        },
      };
    },
  };

  const sessions = {
    store: sessionsStore,
    get(id) {
      return sessionsStore.get(id)?.session;
    },
    async flush() {},
    enter(candidate) {
      sessionsStore.set(candidate.id, { id: candidate.id, session: candidate });
      return () => {
        directoryExistedWhenDetached = existsSync(directory);
        sessionsStore.delete(candidate.id);
        disposed = true;
      };
    },
    announce() {
      created = true;
    },
  };

  const agent = {
    id: sessionId,
    session,
    cancel() {
      cancelled = true;
    },
    async whenIdle() {},
    ctx: {
      fiber: {
        async dispose() {
          agentScopeDisposed = true;
        },
      },
    },
  };

  const agents = {
    store: agentsStore,
    get(id) {
      return agentsStore.get(id)?.agent;
    },
    detachEntered(entry) {
      agentsStore.delete(entry.id);
    },
  };

  if (cold) {
    sessions.enter = (candidate) => {
      sessionsStore.set(candidate.id, { id: candidate.id, session: candidate });
      return () => {
        directoryExistedWhenDetached = existsSync(directory);
        sessionsStore.delete(candidate.id);
        disposed = true;
      };
    };
  } else {
    sessionsStore.set(sessionId, {
      id: sessionId,
      session,
      detach() {
        directoryExistedWhenDetached = existsSync(directory);
        sessionsStore.delete(sessionId);
        disposed = true;
      },
    });
    agentsStore.set(sessionId, { id: sessionId, agent });
  }

  const ctx = {
    connection: {
      rpc: {
        handle(registeredChannel, next) {
          channel = registeredChannel;
          handler = next;
          return async () => {};
        },
      },
    },
    sessions,
    agents,
    sessionPersistence: persistence,
  };
  apply(ctx);
  assert.equal(typeof handler, "function");

  return {
    handler,
    get channel() {
      return channel;
    },
    directory,
    sessionId,
    retirementReads,
    get state() {
      return {
        created,
        disposed,
        preparedDisposed,
        cancelled,
        agentScopeDisposed,
        directoryExistedWhenDetached,
      };
    },
  };
}

const liveDirectory = await mkdtemp(join(tmpdir(), "dsh-session-delete-live-"));
await writeFile(join(liveDirectory, "session.jsonl"), "live");
const live = fixture({ cold: false, directory: liveDirectory, sessionId: "live-session" });
assert.equal(live.channel, "/dsh-session-delete");
const liveWithoutConfirmation = await live.handler("delete", { sessionId: live.sessionId });
assert.equal(liveWithoutConfirmation.ok, false);
assert.equal(liveWithoutConfirmation.error.message, "Explicit confirmation is required.");
assert.equal(await exists(live.directory), true);

const liveResult = await live.handler("delete", { sessionId: live.sessionId, confirmed: true });
assert.deepEqual(liveResult, { ok: true, value: { deleted: true, sessionId: live.sessionId } });
assert.equal(await exists(live.directory), false);
assert.deepEqual(live.state, {
  created: false,
  disposed: true,
  preparedDisposed: false,
  cancelled: true,
  agentScopeDisposed: true,
  directoryExistedWhenDetached: false,
});
assert.deepEqual(live.retirementReads, [live.sessionId]);

const coldDirectory = await mkdtemp(join(tmpdir(), "dsh-session-delete-cold-"));
await writeFile(join(coldDirectory, "session.jsonl"), "cold");
const cold = fixture({ cold: true, directory: coldDirectory, sessionId: "cold-session" });
const coldResult = await cold.handler("delete", { sessionId: cold.sessionId, confirmed: true });
assert.deepEqual(coldResult, { ok: true, value: { deleted: true, sessionId: cold.sessionId } });
assert.equal(await exists(cold.directory), false);
assert.deepEqual(cold.state, {
  created: true,
  disposed: true,
  preparedDisposed: true,
  cancelled: false,
  agentScopeDisposed: false,
  directoryExistedWhenDetached: false,
});
assert.deepEqual(cold.retirementReads, [cold.sessionId]);

// 根目录自身绝不能成为递归删除目标，即使伪造的 locate() 返回了合法日志文件名。
const unsafeRoot = await mkdtemp(join(tmpdir(), "dsh-session-delete-root-"));
await writeFile(join(unsafeRoot, "session.jsonl"), "must-not-delete");
const unsafe = fixture({
  cold: false,
  directory: unsafeRoot,
  persistenceRoot: unsafeRoot,
  sessionId: "unsafe-session",
});
const unsafeResult = await unsafe.handler("delete", { sessionId: unsafe.sessionId, confirmed: true });
assert.equal(unsafeResult.ok, false);
assert.equal(unsafeResult.error.code, "internal");
assert.equal(unsafeResult.error.message, "Session deletion failed.");
assert.doesNotMatch(JSON.stringify(unsafeResult), /outside the JSONL persistence root|dsh-session-delete-root-/);
assert.equal(await exists(unsafeRoot), true);
assert.deepEqual(unsafe.state, {
  created: false,
  disposed: false,
  preparedDisposed: false,
  cancelled: false,
  agentScopeDisposed: false,
  directoryExistedWhenDetached: undefined,
});

await rm(live.directory, { recursive: true, force: true });
await rm(cold.directory, { recursive: true, force: true });
await rm(unsafeRoot, { recursive: true, force: true });
console.log("session-delete smoke test passed");
