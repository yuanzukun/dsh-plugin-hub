import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const source = await readFile(join(root, "lib", "client.js"), "utf8");
const marker = "return { apply, inject };";
assert.equal(source.split(marker).length, 2, "client test hook marker must remain unique");

// 只在隔离 VM 中暴露纯解析函数；发布文件保持原始 ModuleLoader 契约，不增加测试 API。
const instrumented = source.replace(marker, "return { apply, inject, __test: { resolveSessionId } };");
let registration;
const context = vm.createContext({
  window: {
    __ModuleLoader__: {
      load(next) {
        registration = next;
      },
    },
  },
});
vm.runInContext(instrumented, context, { filename: "client.js" });
assert.equal(registration.id, "dsh-session-delete");

const plugin = registration.factory((id) => {
  if (id === "react") return {};
  if (id === "@deepseek-ai/dsh-client-ui-primitives") return { RiskConfirmation() {} };
  throw new Error(`unexpected client dependency: ${id}`);
});
const resolveSessionId = plugin.__test.resolveSessionId;

/** 构造最小 DSH 客户端快照，验证标题只能映射到唯一身份。 */
function sessions(items) {
  return {
    list: {
      getSnapshot() {
        return {
          ids: items.map((item) => item.id),
          byId: Object.fromEntries(items.map((item) => [item.id, item])),
        };
      },
    },
  };
}

assert.equal(resolveSessionId(sessions([{ id: "one", displayTitle: "唯一标题" }]), { title: "唯一标题" }), "one");
assert.equal(resolveSessionId(sessions([
  { id: "first", displayTitle: "同名会话" },
  { id: "second", displayTitle: "同名会话" },
]), { title: "同名会话" }), null);
assert.equal(resolveSessionId(sessions([]), { title: "不存在" }), null);

assert.match(source, /target === null \|\| busy \|\| !acknowledged/);
assert.match(source, /\{ sessionId, confirmed: true \}/);
assert.match(source, /setAttribute\("aria-label", labels\.deleteLabel\)/);
assert.doesNotMatch(source, /sameTitle\.indexOf|candidates\[position\]/);

console.log("client smoke test passed");
