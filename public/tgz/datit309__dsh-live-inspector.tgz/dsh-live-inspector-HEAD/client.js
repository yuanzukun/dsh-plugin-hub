window.__ModuleLoader__.load({
  id: 'dsh-live-inspector',
  factory(require) {
    const React = require('react');
    const h = React.createElement;

    const TAB_ID = 'dsh-live-inspector';
    const TAB_KIND = 'git-tree';
    const FILE_ADDRESS_PREFIX = 'dsh-resource://file/';
    const MAX_RENDERED_DIFF_ROWS = 150;
    const MAX_LINE_CHARACTERS = 400;

    // Global registry of per-session states
    const sessionStates = new Map();
    let currentMountedSessionId = null;
    let globalCtx = null;

    const listeners = new Set();
    let notifyTimer = null;
    function notify() {
      if (notifyTimer) return;
      notifyTimer = setTimeout(() => {
        notifyTimer = null;
        for (const listener of listeners) {
          try {
            listener();
          } catch (e) {
            console.warn('[dsh-live-inspector] listener error:', e);
          }
        }
      }, 40);
    }

    function getSessionState(sid) {
      if (!sid) return null;
      let s = sessionStates.get(sid);
      if (!s) {
        s = {
          sessionId: sid,
          files: {}, // path -> { path, name, dir, ext, status, active, timestamp, line, count, diffs: [] }
          activePath: null,
          filter: 'all',
          searchQuery: '',
          selectedPath: null,
          processedSeqs: new Set(),
          autoOpenOpenedThisTurn: false,
          reviewUrl: null
        };
        sessionStates.set(sid, s);
      }
      return s;
    }

    function resolveCurrentSessionId() {
      // 1. sidebarRight mounted session
      try {
        const sid = globalCtx?.sidebarRight?.mounted?.getSnapshot();
        if (sid) return sid;
      } catch {}

      // 2. Session currently visible in Main View
      try {
        const list = globalCtx?.sessions?.list?.getSnapshot();
        if (list && list.byId) {
          for (const id in list.byId) {
            if ((list.byId[id]?.retainedBy?.mainView ?? 0) > 0) {
              return id;
            }
          }
        }
      } catch {}

      // 3. Fallback to cached session
      if (currentMountedSessionId) return currentMountedSessionId;

      // 4. Fallback to newest session
      try {
        const ids = globalCtx?.sessions?.list?.getSnapshot()?.ids;
        if (ids && ids.length > 0) return ids[ids.length - 1];
      } catch {}

      return null;
    }

    function encodeSegment(s) {
      return encodeURIComponent(s).replace(/%3A/gi, ':');
    }
    function encodePath(p) {
      return p.split('/').map(encodeSegment).join('/');
    }
    function sessionFileAddress(sessionId, path) {
      const normalized = path.replace(/\\/g, '/').replace(/^(?:\.\/)+/, '');
      return FILE_ADDRESS_PREFIX + 'session/' + encodeSegment(sessionId) + '/' + encodePath(normalized);
    }

    // High-precision token/word-level diff with guard against huge lines
    function wordDiff(oldStr, newStr) {
      if (!oldStr && !newStr) return { oldParts: [], newParts: [] };
      if (!oldStr) return { oldParts: [], newParts: [{ text: newStr, changed: true }] };
      if (!newStr) return { oldParts: [{ text: oldStr, changed: true }], newParts: [] };
      if (oldStr === newStr) {
        return {
          oldParts: [{ text: oldStr, changed: false }],
          newParts: [{ text: newStr, changed: false }]
        };
      }

      // Performance cap on extremely long minified lines
      if (oldStr.length > MAX_LINE_CHARACTERS || newStr.length > MAX_LINE_CHARACTERS) {
        return {
          oldParts: [{ text: oldStr.slice(0, MAX_LINE_CHARACTERS) + (oldStr.length > MAX_LINE_CHARACTERS ? '…' : ''), changed: true }],
          newParts: [{ text: newStr.slice(0, MAX_LINE_CHARACTERS) + (newStr.length > MAX_LINE_CHARACTERS ? '…' : ''), changed: true }]
        };
      }

      const tokenRegex = /(\s+|[a-zA-Z0-9_$]+|[^\s\w])/g;
      const oldTokens = oldStr.match(tokenRegex) || [oldStr];
      const newTokens = newStr.match(tokenRegex) || [newStr];

      let prefix = 0;
      while (prefix < oldTokens.length && prefix < newTokens.length && oldTokens[prefix] === newTokens[prefix]) {
        prefix++;
      }

      let suffix = 0;
      while (
        suffix < (oldTokens.length - prefix) &&
        suffix < (newTokens.length - prefix) &&
        oldTokens[oldTokens.length - 1 - suffix] === newTokens[newTokens.length - 1 - suffix]
      ) {
        suffix++;
      }

      const oldPrefix = oldTokens.slice(0, prefix).join('');
      const oldMid = oldTokens.slice(prefix, oldTokens.length - suffix).join('');
      const oldSuffix = oldTokens.slice(oldTokens.length - suffix).join('');

      const newPrefix = newTokens.slice(0, prefix).join('');
      const newMid = newTokens.slice(prefix, newTokens.length - suffix).join('');
      const newSuffix = newTokens.slice(newTokens.length - suffix).join('');

      return {
        oldParts: [
          { text: oldPrefix, changed: false },
          { text: oldMid, changed: true },
          { text: oldSuffix, changed: false }
        ].filter(p => p.text.length > 0),
        newParts: [
          { text: newPrefix, changed: false },
          { text: newMid, changed: true },
          { text: newSuffix, changed: false }
        ].filter(p => p.text.length > 0)
      };
    }

    // Professional line-aligned split diff calculation
    function computeSplitDiff(oldText, newText, startLine = 1) {
      let rawOldLines = typeof oldText === 'string' ? oldText.split('\n') : [];
      let rawNewLines = typeof newText === 'string' ? newText.split('\n') : [];

      let prefixCount = 0;
      while (prefixCount < rawOldLines.length && prefixCount < rawNewLines.length && rawOldLines[prefixCount] === rawNewLines[prefixCount]) {
        prefixCount++;
      }

      let suffixCount = 0;
      while (
        suffixCount < (rawOldLines.length - prefixCount) &&
        suffixCount < (rawNewLines.length - prefixCount) &&
        rawOldLines[rawOldLines.length - 1 - suffixCount] === rawNewLines[rawNewLines.length - 1 - suffixCount]
      ) {
        suffixCount++;
      }

      const oldDiff = rawOldLines.slice(prefixCount, rawOldLines.length - suffixCount);
      const newDiff = rawNewLines.slice(prefixCount, rawNewLines.length - suffixCount);

      const rows = [];
      let curOldNo = startLine;
      let curNewNo = startLine;

      // Prefix context lines (up to 3)
      const contextPrefixStart = Math.max(0, prefixCount - 3);
      for (let i = contextPrefixStart; i < prefixCount; i++) {
        rows.push({
          left: { no: curOldNo + i, text: rawOldLines[i], kind: 'context', parts: [{ text: rawOldLines[i], changed: false }] },
          right: { no: curNewNo + i, text: rawNewLines[i], kind: 'context', parts: [{ text: rawNewLines[i], changed: false }] }
        });
      }
      curOldNo += prefixCount;
      curNewNo += prefixCount;

      // Changed lines (aligned side-by-side with word-level diffing)
      const maxDiff = Math.max(oldDiff.length, newDiff.length);
      for (let i = 0; i < maxDiff; i++) {
        const oldL = i < oldDiff.length ? oldDiff[i] : null;
        const newL = i < newDiff.length ? newDiff[i] : null;

        let parts = { oldParts: [], newParts: [] };
        if (oldL !== null && newL !== null) {
          parts = wordDiff(oldL, newL);
        } else if (oldL !== null) {
          parts.oldParts = [{ text: oldL, changed: true }];
        } else if (newL !== null) {
          parts.newParts = [{ text: newL, changed: true }];
        }

        const leftCell = oldL !== null ? {
          no: curOldNo + i,
          text: oldL,
          kind: 'del',
          parts: parts.oldParts
        } : null;

        const rightCell = newL !== null ? {
          no: curNewNo + i,
          text: newL,
          kind: 'add',
          parts: parts.newParts
        } : null;

        rows.push({ left: leftCell, right: rightCell });
      }
      curOldNo += oldDiff.length;
      curNewNo += newDiff.length;

      // Suffix context lines (up to 3)
      const suffixLines = Math.min(3, suffixCount);
      for (let i = 0; i < suffixLines; i++) {
        const oldIdx = rawOldLines.length - suffixCount + i;
        const newIdx = rawNewLines.length - suffixCount + i;
        rows.push({
          left: { no: curOldNo + i, text: rawOldLines[oldIdx], kind: 'context', parts: [{ text: rawOldLines[oldIdx], changed: false }] },
          right: { no: curNewNo + i, text: rawNewLines[newIdx], kind: 'context', parts: [{ text: rawNewLines[newIdx], changed: false }] }
        });
      }

      const truncated = rows.length > MAX_RENDERED_DIFF_ROWS;
      const displayRows = truncated ? rows.slice(0, MAX_RENDERED_DIFF_ROWS) : rows;

      return {
        rows: displayRows,
        totalRows: rows.length,
        truncated: truncated,
        oldLinesCount: rawOldLines.length,
        newLinesCount: rawNewLines.length,
        delCount: oldDiff.length,
        addCount: newDiff.length
      };
    }

    // GitHub-style 5-square diffstat mini bar
    function DiffStatBar({ addCount, delCount }) {
      const total = addCount + delCount;
      if (total === 0) return null;
      const greenBoxes = Math.min(5, Math.max(addCount > 0 ? 1 : 0, Math.round((addCount / total) * 5)));
      const redBoxes = Math.min(5 - greenBoxes, Math.max(delCount > 0 ? 1 : 0, 5 - greenBoxes));
      const grayBoxes = Math.max(0, 5 - greenBoxes - redBoxes);

      return h('span', {
        title: '+' + addCount + ' / -' + delCount,
        style: { display: 'inline-flex', gap: '2px', alignItems: 'center' }
      },
        Array.from({ length: greenBoxes }).map((_, i) =>
          h('span', { key: 'g' + i, style: { width: '5px', height: '5px', borderRadius: '1px', background: '#10b981' } })
        ),
        Array.from({ length: redBoxes }).map((_, i) =>
          h('span', { key: 'r' + i, style: { width: '5px', height: '5px', borderRadius: '1px', background: '#ef4444' } })
        ),
        Array.from({ length: grayBoxes }).map((_, i) =>
          h('span', { key: 'gr' + i, style: { width: '5px', height: '5px', borderRadius: '1px', background: 'rgba(255,255,255,0.15)' } })
        )
      );
    }

    // Extension Badge
    function FileExtBadge({ ext }) {
      let bg = 'rgba(255,255,255,0.06)';
      let color = 'inherit';
      let label = (ext || '').toUpperCase().slice(0, 4);

      if (ext === 'ts' || ext === 'tsx') {
        bg = 'rgba(49, 120, 198, 0.2)';
        color = '#60a5fa';
      } else if (ext === 'js' || ext === 'jsx') {
        bg = 'rgba(247, 223, 30, 0.2)';
        color = '#facc15';
      } else if (ext === 'json') {
        bg = 'rgba(16, 185, 129, 0.2)';
        color = '#34d399';
      } else if (ext === 'css' || ext === 'scss') {
        bg = 'rgba(236, 72, 153, 0.2)';
        color = '#f472b6';
      } else if (ext === 'md') {
        bg = 'rgba(168, 85, 247, 0.2)';
        color = '#c084fc';
      }

      return h('span', {
        style: {
          padding: '1px 4px',
          borderRadius: '3px',
          fontSize: '9px',
          fontWeight: 700,
          fontFamily: 'monospace',
          background: bg,
          color: color,
          flexShrink: 0
        }
      }, label || 'FILE');
    }

    function extractFilePathAndDiff(name, argsRaw) {
      if (!argsRaw) return null;
      let args = argsRaw;
      if (typeof argsRaw === 'string') {
        try {
          args = JSON.parse(argsRaw);
        } catch {
          return null;
        }
      }
      if (!args || typeof args !== 'object') return null;

      if (name === 'edit') {
        const fp = args.file_path || args.path;
        if (typeof fp === 'string' && fp.length > 0) {
          return {
            path: fp,
            status: 'M',
            line: typeof args.offset === 'number' ? args.offset : undefined,
            diff: {
              oldText: typeof args.old_string === 'string' ? args.old_string : null,
              newText: typeof args.new_string === 'string' ? args.new_string : null
            }
          };
        }
      }

      if (name === 'str_replace_editor') {
        const fp = args.path;
        if (typeof fp === 'string' && fp.length > 0) {
          return {
            path: fp,
            status: 'M',
            diff: {
              oldText: typeof args.old_str === 'string' ? args.old_str : null,
              newText: typeof args.new_str === 'string' ? args.new_str : null
            }
          };
        }
      }

      if (name === 'write' || name === 'write_file' || name === 'create_file') {
        const fp = args.file_path || args.path;
        if (typeof fp === 'string' && fp.length > 0) {
          const content = typeof args.content === 'string' ? args.content : null;
          return {
            path: fp,
            status: 'A',
            line: typeof args.offset === 'number' ? args.offset : undefined,
            diff: {
              oldText: null,
              newText: content,
              isNewFile: true
            }
          };
        }
      }

      if (name === 'read' || name === 'view') {
        const fp = args.file_path || args.path;
        if (typeof fp === 'string' && fp.length > 0) {
          return {
            path: fp,
            status: 'R',
            line: typeof args.offset === 'number' ? args.offset : undefined
          };
        }
      }

      // Serena code intelligence and AST surgery tools
      if (typeof name === 'string' && (name.includes('serena') || name.includes('replace_symbol') || name.includes('insert_after') || name.includes('insert_before') || name.includes('replace_in_files'))) {
        const fp = args.relative_path || args.file_path || args.path;
        if (typeof fp === 'string' && fp.length > 0) {
          const newText = typeof args.body === 'string' ? args.body : (typeof args.repl === 'string' ? args.repl : null);
          const oldText = typeof args.needle === 'string' ? args.needle : null;
          return {
            path: fp,
            status: 'M',
            diff: (newText || oldText) ? { oldText, newText } : null
          };
        }
      }

      return null;
    }

    function recordFile(sessionId, filePath, status, line, diff, seq) {
      const state = getSessionState(sessionId);
      if (!state) return;

      const cleanPath = filePath.replace(/\\/g, '/').replace(/^(?:\.\/)+/, '');
      const parts = cleanPath.split('/');
      const name = parts.pop() || cleanPath;
      const dir = parts.join('/') || '.';
      const ext = name.includes('.') ? name.split('.').pop() : '';

      let nextStatus = status;
      const existing = state.files[cleanPath];
      if (existing) {
        if (existing.status === 'M' || status === 'M') {
          nextStatus = 'M';
        } else if (existing.status === 'A' && status === 'R') {
          nextStatus = 'A';
        }
      }

      for (const k in state.files) {
        state.files[k].active = false;
      }

      const diffs = existing?.diffs ? [...existing.diffs] : [];
      if (diff && (diff.oldText !== null || diff.newText !== null)) {
        const diffId = seq ? 'seq-' + seq : String(diff.oldText || '') + '->' + String(diff.newText || '');
        const alreadyExists = diffs.some(d => d.id === diffId);
        if (!alreadyExists) {
          diffs.push({
            id: diffId,
            oldText: diff.oldText,
            newText: diff.newText,
            isNewFile: diff.isNewFile || false,
            line: line || 1,
            time: Date.now()
          });
        }
      }

      state.files[cleanPath] = {
        path: cleanPath,
        name: name,
        dir: dir,
        ext: ext,
        status: nextStatus,
        active: true,
        line: line,
        timestamp: Date.now(),
        count: (existing ? existing.count : 0) + 1,
        diffs: diffs
      };
      state.activePath = cleanPath;

      if (!state.selectedPath || nextStatus === 'M' || nextStatus === 'A') {
        state.selectedPath = cleanPath;
      }
    }

    function clearActive(sessionId) {
      const state = getSessionState(sessionId);
      if (!state) return;
      let changed = false;
      if (state.activePath !== null) {
        state.activePath = null;
        changed = true;
      }
      for (const k in state.files) {
        if (state.files[k].active) {
          state.files[k].active = false;
          changed = true;
        }
      }
      if (changed) notify();
    }

    function openSingleFile(sessionId, filePath, line) {
      if (!sessionId) {
        console.warn('[dsh-live-inspector] Cannot open file: no active session');
        return;
      }
      const url = sessionFileAddress(sessionId, filePath);
      const options = line ? { params: { line } } : undefined;
      console.info('[dsh-live-inspector] Opening file:', url, options);

      if (globalCtx?.sidebarRight && typeof globalCtx.sidebarRight.openResourceIn === 'function') {
        try {
          globalCtx.sidebarRight.openResourceIn(sessionId, url, options);
          return;
        } catch (e) {
          console.warn('[dsh-live-inspector] openResourceIn error:', e);
        }
      }
      if (globalCtx?.sidebarRight && typeof globalCtx.sidebarRight.openResource === 'function') {
        try {
          globalCtx.sidebarRight.openResource(url, options);
          return;
        } catch (e) {
          console.warn('[dsh-live-inspector] openResource error:', e);
        }
      }
    }

    function openResourceUrl(sessionId, url) {
      if (globalCtx?.sidebarRight && typeof globalCtx.sidebarRight.openResourceIn === 'function') {
        try {
          globalCtx.sidebarRight.openResourceIn(sessionId, url);
          return;
        } catch (e) {
          console.warn('[dsh-live-inspector] openResourceIn error:', e);
        }
      }
      if (globalCtx?.sidebarRight && typeof globalCtx.sidebarRight.openResource === 'function') {
        try {
          globalCtx.sidebarRight.openResource(url);
          return;
        } catch (e) {
          console.warn('[dsh-live-inspector] openResource error:', e);
        }
      }
    }

    function renderParts(parts, kind) {
      if (!parts || parts.length === 0) return null;
      return parts.map((p, i) => {
        if (!p.changed) return h('span', { key: i }, p.text);
        if (kind === 'del') {
          return h('span', {
            key: i,
            style: {
              background: 'rgba(239, 68, 68, 0.4)',
              color: '#fff',
              borderRadius: '2px',
              padding: '0 2px',
              fontWeight: 600
            }
          }, p.text);
        }
        return h('span', {
          key: i,
          style: {
            background: 'rgba(16, 185, 129, 0.4)',
            color: '#fff',
            borderRadius: '2px',
            padding: '0 2px',
            fontWeight: 600
          }
        }, p.text);
      });
    }

    // Side-by-Side Split Diff View
    function SplitDiffView({ computed, wrapLines }) {
      const { rows, truncated, totalRows } = computed;
      const emptyHatch = 'repeating-linear-gradient(45deg, rgba(255,255,255,0.015), rgba(255,255,255,0.015) 6px, rgba(0,0,0,0.1) 6px, rgba(0,0,0,0.1) 12px)';

      return h('div', {
        style: {
          display: 'grid',
          gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)',
          border: '1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.1))',
          borderRadius: '6px',
          overflow: 'hidden',
          fontFamily: 'var(--ds-font-family-code, "JetBrains Mono", monospace)',
          fontSize: '11px',
          background: 'var(--dsw-alias-bg-layer-2, rgba(0,0,0,0.28))'
        }
      },
        // Left Column Header (Original / Before)
        h('div', {
          style: {
            gridColumn: '1 / 2',
            padding: '5px 10px',
            background: 'rgba(239, 68, 68, 0.12)',
            borderBottom: '1px solid rgba(239, 68, 68, 0.22)',
            borderRight: '1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.1))',
            color: '#f87171',
            fontWeight: 600,
            fontSize: '10px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }
        },
          h('span', null, '◀ ORIGINAL (BEFORE)'),
          h('span', { style: { opacity: 0.8, fontSize: '9px' } }, '-' + computed.delCount + ' lines')
        ),

        // Right Column Header (Modified / After)
        h('div', {
          style: {
            gridColumn: '2 / 3',
            padding: '5px 10px',
            background: 'rgba(16, 185, 129, 0.12)',
            borderBottom: '1px solid rgba(16, 185, 129, 0.22)',
            color: '#34d399',
            fontWeight: 600,
            fontSize: '10px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }
        },
          h('span', null, '▶ MODIFIED (AFTER)'),
          h('span', { style: { opacity: 0.8, fontSize: '9px' } }, '+' + computed.addCount + ' lines')
        ),

        // Synchronized Aligned Rows
        h('div', {
          style: {
            gridColumn: '1 / -1',
            maxHeight: '480px',
            overflowY: 'auto',
            overflowX: wrapLines ? 'hidden' : 'auto'
          }
        },
          rows.map((row, idx) => {
            const left = row.left;
            const right = row.right;

            return h('div', {
              key: idx,
              style: {
                display: 'grid',
                gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)',
                minHeight: '22px',
                lineHeight: '22px',
                borderBottom: '0.5px solid rgba(255,255,255,0.02)'
              }
            },
              // LEFT CELL
              h('div', {
                style: {
                  display: 'flex',
                  minWidth: 0,
                  borderRight: '1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.1))',
                  background: left ? (left.kind === 'del' ? 'rgba(239, 68, 68, 0.08)' : 'transparent') : emptyHatch
                }
              },
                h('div', {
                  style: {
                    width: '36px',
                    flexShrink: 0,
                    textAlign: 'right',
                    paddingRight: '6px',
                    userSelect: 'none',
                    fontSize: '10px',
                    color: left?.kind === 'del' ? '#f87171' : 'var(--dsw-alias-label-tertiary, #666)',
                    background: left?.kind === 'del' ? 'rgba(239, 68, 68, 0.16)' : 'transparent',
                    borderRight: '1px solid rgba(255,255,255,0.05)'
                  }
                }, left ? String(left.no) : ''),
                h('div', {
                  style: {
                    flex: 1,
                    minWidth: 0,
                    padding: '0 8px',
                    whiteSpace: wrapLines ? 'pre-wrap' : 'pre',
                    wordBreak: wrapLines ? 'break-all' : 'normal',
                    color: left?.kind === 'del' ? '#fca5a5' : 'var(--dsw-alias-label-secondary, #bbb)'
                  }
                }, left ? renderParts(left.parts, left.kind) : '')
              ),

              // RIGHT CELL
              h('div', {
                style: {
                  display: 'flex',
                  minWidth: 0,
                  background: right ? (right.kind === 'add' ? 'rgba(16, 185, 129, 0.08)' : 'transparent') : emptyHatch
                }
              },
                h('div', {
                  style: {
                    width: '36px',
                    flexShrink: 0,
                    textAlign: 'right',
                    paddingRight: '6px',
                    userSelect: 'none',
                    fontSize: '10px',
                    color: right?.kind === 'add' ? '#34d399' : 'var(--dsw-alias-label-tertiary, #666)',
                    background: right?.kind === 'add' ? 'rgba(16, 185, 129, 0.16)' : 'transparent',
                    borderRight: '1px solid rgba(255,255,255,0.05)'
                  }
                }, right ? String(right.no) : ''),
                h('div', {
                  style: {
                    flex: 1,
                    minWidth: 0,
                    padding: '0 8px',
                    whiteSpace: wrapLines ? 'pre-wrap' : 'pre',
                    wordBreak: wrapLines ? 'break-all' : 'normal',
                    color: right?.kind === 'add' ? '#86efac' : 'var(--dsw-alias-label-secondary, #bbb)'
                  }
                }, right ? renderParts(right.parts, right.kind) : '')
              )
            );
          }),

          truncated ? h('div', {
            style: {
              padding: '6px 12px',
              color: 'var(--dsw-alias-label-tertiary, #888)',
              fontStyle: 'italic',
              fontSize: '11px',
              textAlign: 'center',
              background: 'rgba(0,0,0,0.2)'
            }
          }, '... and ' + (totalRows - MAX_RENDERED_DIFF_ROWS) + ' more lines (open editor to view full file)') : null
        )
      );
    }

    // Unified Diff View
    function UnifiedDiffView({ computed, wrapLines }) {
      const { rows, truncated, totalRows } = computed;

      return h('div', {
        style: {
          border: '1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.1))',
          borderRadius: '6px',
          overflow: 'hidden',
          fontFamily: 'var(--ds-font-family-code, "JetBrains Mono", monospace)',
          fontSize: '11px',
          background: 'var(--dsw-alias-bg-layer-2, rgba(0,0,0,0.28))',
          maxHeight: '480px',
          overflowY: 'auto',
          overflowX: wrapLines ? 'hidden' : 'auto'
        }
      },
        rows.map((row, idx) => {
          if (row.left?.kind === 'context') {
            return h('div', {
              key: idx,
              style: {
                display: 'flex',
                lineHeight: '22px',
                minHeight: '22px',
                color: 'var(--dsw-alias-label-secondary, #bbb)',
                borderBottom: '0.5px solid rgba(255,255,255,0.02)'
              }
            },
              h('span', { style: { width: '36px', textAlign: 'right', paddingRight: '6px', opacity: 0.5, userSelect: 'none' } }, String(row.left.no)),
              h('span', { style: { width: '36px', textAlign: 'right', paddingRight: '6px', opacity: 0.5, userSelect: 'none' } }, String(row.right.no)),
              h('span', { style: { width: '18px', textAlign: 'center', opacity: 0.3 } }, ' '),
              h('span', { style: { flex: 1, paddingRight: '8px', whiteSpace: wrapLines ? 'pre-wrap' : 'pre', wordBreak: wrapLines ? 'break-all' : 'normal' } }, row.left.text)
            );
          }

          const elements = [];
          if (row.left && row.left.kind === 'del') {
            elements.push(h('div', {
              key: 'del-' + idx,
              style: {
                display: 'flex',
                lineHeight: '22px',
                minHeight: '22px',
                background: 'rgba(239, 68, 68, 0.09)',
                color: '#fca5a5',
                borderBottom: '0.5px solid rgba(255,255,255,0.02)'
              }
            },
              h('span', { style: { width: '36px', textAlign: 'right', paddingRight: '6px', color: '#f87171', background: 'rgba(239, 68, 68, 0.16)', userSelect: 'none' } }, String(row.left.no)),
              h('span', { style: { width: '36px', textAlign: 'right', paddingRight: '6px', background: 'rgba(239, 68, 68, 0.16)', userSelect: 'none' } }, ''),
              h('span', { style: { width: '18px', textAlign: 'center', color: '#ef4444', fontWeight: 700 } }, '-'),
              h('span', { style: { flex: 1, paddingRight: '8px', whiteSpace: wrapLines ? 'pre-wrap' : 'pre', wordBreak: wrapLines ? 'break-all' : 'normal' } }, renderParts(row.left.parts, 'del'))
            ));
          }
          if (row.right && row.right.kind === 'add') {
            elements.push(h('div', {
              key: 'add-' + idx,
              style: {
                display: 'flex',
                lineHeight: '22px',
                minHeight: '22px',
                background: 'rgba(16, 185, 129, 0.09)',
                color: '#86efac',
                borderBottom: '0.5px solid rgba(255,255,255,0.02)'
              }
            },
              h('span', { style: { width: '36px', textAlign: 'right', paddingRight: '6px', background: 'rgba(16, 185, 129, 0.16)', userSelect: 'none' } }, ''),
              h('span', { style: { width: '36px', textAlign: 'right', paddingRight: '6px', color: '#34d399', background: 'rgba(16, 185, 129, 0.16)', userSelect: 'none' } }, String(row.right.no)),
              h('span', { style: { width: '18px', textAlign: 'center', color: '#10b981', fontWeight: 700 } }, '+'),
              h('span', { style: { flex: 1, paddingRight: '8px', whiteSpace: wrapLines ? 'pre-wrap' : 'pre', wordBreak: wrapLines ? 'break-all' : 'normal' } }, renderParts(row.right.parts, 'add'))
            ));
          }
          return elements;
        }),

        truncated ? h('div', {
          style: {
            padding: '6px 12px',
            color: 'var(--dsw-alias-label-tertiary, #888)',
            fontStyle: 'italic',
            fontSize: '11px',
            textAlign: 'center',
            background: 'rgba(0,0,0,0.2)'
          }
        }, '... and ' + (totalRows - MAX_RENDERED_DIFF_ROWS) + ' more lines (open editor to view full file)') : null
      );
    }

    // Detail Inspector for the Selected File
    function SelectedFileDiffInspector({ file, currentSid }) {
      const [viewMode, setViewMode] = React.useState('split'); // 'split' | 'unified'
      const [wrapLines, setWrapLines] = React.useState(true);
      const [activeDiffIdx, setActiveDiffIdx] = React.useState(0);

      if (!file) {
        return h('div', {
          style: {
            padding: '48px 16px',
            textAlign: 'center',
            color: 'var(--dsw-alias-label-tertiary, #666)',
            fontSize: '12px'
          }
        },
          h('div', { style: { fontSize: '24px', marginBottom: '8px' } }, '🌿'),
          h('div', { style: { fontWeight: 500 } }, 'No file selected'),
          h('div', { style: { fontSize: '11px', marginTop: '4px', opacity: 0.8 } }, 'Select a file above to inspect its diff side-by-side.')
        );
      }

      const diffs = file.diffs || [];
      const hasDiffs = diffs.length > 0;
      const currentDiff = diffs[activeDiffIdx] || diffs[0];

      const computed = React.useMemo(() => {
        if (!currentDiff) return null;
        return computeSplitDiff(currentDiff.oldText, currentDiff.newText, currentDiff.line || 1);
      }, [currentDiff?.id, currentDiff?.oldText, currentDiff?.newText]);

      return h('div', {
        style: {
          display: 'flex',
          flexDirection: 'column',
          flex: 1,
          minHeight: 0,
          background: 'var(--dsw-alias-bg-base, transparent)'
        }
      },
        // Detail Header
        h('div', {
          style: {
            padding: '8px 14px',
            borderBottom: '1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.08))',
            background: 'var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.03))',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '8px'
          }
        },
          // Left: Identity & Badges
          h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', minWidth: 0 } },
            h(FileExtBadge, { ext: file.ext }),
            h('span', {
              style: {
                padding: '1px 6px',
                borderRadius: '3px',
                fontSize: '10px',
                fontWeight: 700,
                fontFamily: 'monospace',
                background: file.status === 'M' ? 'rgba(245, 158, 11, 0.2)' : file.status === 'A' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(59, 130, 246, 0.2)',
                color: file.status === 'M' ? '#f59e0b' : file.status === 'A' ? '#10b981' : '#60a5fa',
                border: '1px solid ' + (file.status === 'M' ? 'rgba(245, 158, 11, 0.4)' : file.status === 'A' ? 'rgba(16, 185, 129, 0.4)' : 'rgba(59, 130, 246, 0.4)')
              }
            }, file.status === 'M' ? 'MODIFIED' : file.status === 'A' ? 'CREATED' : 'READ'),

            h('div', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } },
              h('span', { style: { fontWeight: 600, fontSize: '13px', color: 'var(--dsw-alias-label-primary, inherit)' } }, file.name),
              file.dir !== '.' ? h('span', { style: { marginLeft: '6px', fontSize: '11px', color: 'var(--dsw-alias-label-tertiary, #888)' } }, file.dir) : null
            ),

            computed ? h(DiffStatBar, { addCount: computed.addCount, delCount: computed.delCount }) : null
          ),

          // Right: Action buttons
          h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px' } },
            hasDiffs ? h('button', {
              onClick: () => setWrapLines(v => !v),
              title: wrapLines ? 'Disable line wrapping' : 'Enable line wrapping',
              style: {
                padding: '2px 6px',
                borderRadius: '4px',
                fontSize: '10px',
                cursor: 'pointer',
                border: '1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.1))',
                background: wrapLines ? 'rgba(255,255,255,0.08)' : 'transparent',
                color: 'var(--dsw-alias-label-secondary, #999)'
              }
            }, 'Wrap') : null,

            hasDiffs ? h('div', {
              style: {
                display: 'flex',
                background: 'var(--dsw-alias-bg-layer-2, rgba(255,255,255,0.06))',
                borderRadius: '4px',
                padding: '2px',
                border: '1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.1))'
              }
            },
              h('button', {
                onClick: () => setViewMode('split'),
                title: 'Side-by-Side 2 columns',
                style: {
                  padding: '2px 7px',
                  borderRadius: '3px',
                  fontSize: '10px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  border: 'none',
                  background: viewMode === 'split' ? 'var(--dsw-alias-brand-primary, #2563eb)' : 'transparent',
                  color: viewMode === 'split' ? '#fff' : 'var(--dsw-alias-label-secondary, #999)'
                }
              }, '◫ Split'),
              h('button', {
                onClick: () => setViewMode('unified'),
                title: 'Unified 1 column',
                style: {
                  padding: '2px 7px',
                  borderRadius: '3px',
                  fontSize: '10px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  border: 'none',
                  background: viewMode === 'unified' ? 'var(--dsw-alias-brand-primary, #2563eb)' : 'transparent',
                  color: viewMode === 'unified' ? '#fff' : 'var(--dsw-alias-label-secondary, #999)'
                }
              }, '☰ Unified')
            ) : null,

            h('button', {
              onClick: () => openSingleFile(currentSid, file.path, file.line),
              title: 'Open full file in Editor',
              style: {
                padding: '3px 8px',
                borderRadius: '4px',
                fontSize: '11px',
                fontWeight: 500,
                border: '1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.18))',
                background: 'var(--dsw-alias-bg-layer-2, rgba(255,255,255,0.08))',
                color: 'inherit',
                cursor: 'pointer'
              }
            }, '↗ Open Editor')
          )
        ),

        // Revisions tabs if multiple edits
        diffs.length > 1 ? h('div', {
          style: {
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '6px 14px',
            borderBottom: '1px solid rgba(255,255,255,0.06)',
            background: 'rgba(0,0,0,0.12)'
          }
        },
          h('span', { style: { fontSize: '10px', color: 'var(--dsw-alias-label-tertiary, #777)' } }, 'Revisions:'),
          diffs.map((d, idx) =>
            h('button', {
              key: d.id || idx,
              onClick: () => setActiveDiffIdx(idx),
              style: {
                padding: '2px 8px',
                borderRadius: '10px',
                fontSize: '10px',
                fontWeight: 500,
                cursor: 'pointer',
                border: activeDiffIdx === idx ? '1px solid var(--dsw-alias-brand-primary, #3b82f6)' : '1px solid transparent',
                background: activeDiffIdx === idx ? 'rgba(59, 130, 246, 0.18)' : 'transparent',
                color: activeDiffIdx === idx ? '#60a5fa' : 'var(--dsw-alias-label-secondary, #888)'
              }
            }, 'Hunk #' + (idx + 1))
          )
        ) : null,

        // Diff Viewer Body
        h('div', {
          style: {
            padding: '10px 14px',
            flex: 1,
            overflowY: 'auto'
          }
        },
          computed ? (
            viewMode === 'split' ? h(SplitDiffView, { computed, wrapLines }) : h(UnifiedDiffView, { computed, wrapLines })
          ) : (
            h('div', {
              style: {
                padding: '32px 16px',
                textAlign: 'center',
                color: 'var(--dsw-alias-label-tertiary, #666)',
                fontSize: '12px'
              }
            }, file.status === 'R' ? 'File was accessed for read only in this session.' : 'No line diff recorded.')
          )
        )
      );
    }

    // GitTree Tab Title Chip
    function GitTreeTitle() {
      const [activeSid, setActiveSid] = React.useState(resolveCurrentSessionId);
      const [, setTick] = React.useState(0);

      React.useEffect(() => {
        const sync = () => {
          const sid = resolveCurrentSessionId();
          setActiveSid(sid);
          setTick(t => t + 1);
        };
        const unsubMounted = globalCtx?.sidebarRight?.mounted?.subscribe(sync);
        listeners.add(sync);
        return () => {
          if (unsubMounted) unsubMounted();
          listeners.delete(sync);
        };
      }, []);

      const sessionData = getSessionState(activeSid);
      const fileList = sessionData ? Object.values(sessionData.files) : [];
      const changesCount = fileList.filter(f => f.status === 'M' || f.status === 'A').length;

      return h('span', { style: { display: 'inline-flex', alignItems: 'center', gap: '6px' } },
        h('span', null, 'Git Tree'),
        changesCount > 0 ? h('span', {
          style: {
            fontSize: '11px',
            lineHeight: '14px',
            padding: '1px 5px',
            borderRadius: '10px',
            background: 'var(--dsw-alias-brand-primary, #2563eb)',
            color: '#fff',
            fontWeight: 600
          }
        }, String(changesCount)) : null
      );
    }

    // Main Tab Body Component
    function GitTreeBody(props) {
      const propSid = props?.sessionId;
      const [activeSid, setActiveSid] = React.useState(() => propSid || resolveCurrentSessionId());
      const [, setTick] = React.useState(0);
      const [listCollapsed, setListCollapsed] = React.useState(false);

      React.useEffect(() => {
        const sync = () => {
          const sid = propSid || resolveCurrentSessionId();
          setActiveSid(sid);
          setTick(t => t + 1);
        };
        const unsubMounted = globalCtx?.sidebarRight?.mounted?.subscribe(sync);
        listeners.add(sync);
        return () => {
          if (unsubMounted) unsubMounted();
          listeners.delete(sync);
        };
      }, [propSid]);

      const currentSid = propSid || activeSid || resolveCurrentSessionId();
      const sessionData = getSessionState(currentSid);

      const [filter, setFilter] = React.useState(sessionData ? sessionData.filter : 'all');
      const [search, setSearch] = React.useState(sessionData ? sessionData.searchQuery : '');

      const fileList = sessionData ? Object.values(sessionData.files) : [];
      const modifiedFiles = fileList.filter(f => f.status === 'M');
      const addedFiles = fileList.filter(f => f.status === 'A');
      const readFiles = fileList.filter(f => f.status === 'R');

      if (sessionData && !sessionData.selectedPath && fileList.length > 0) {
        sessionData.selectedPath = (modifiedFiles[0] || addedFiles[0] || fileList[0]).path;
      }

      const selectedFile = sessionData && sessionData.selectedPath ? sessionData.files[sessionData.selectedPath] : null;

      let visible = fileList;
      if (filter === 'changes') {
        visible = visible.filter(f => f.status === 'M' || f.status === 'A');
      } else if (filter === 'reads') {
        visible = visible.filter(f => f.status === 'R');
      }

      if (search.trim().length > 0) {
        const q = search.toLowerCase();
        visible = visible.filter(f => f.path.toLowerCase().includes(q));
      }

      visible.sort((a, b) => {
        if (a.active !== b.active) return a.active ? -1 : 1;
        const rank = s => (s === 'M' ? 3 : s === 'A' ? 2 : 1);
        if (rank(a.status) !== rank(b.status)) return rank(b.status) - rank(a.status);
        return b.timestamp - a.timestamp;
      });

      function handleClear() {
        if (sessionData) {
          sessionData.files = {};
          sessionData.activePath = null;
          sessionData.selectedPath = null;
          sessionData.reviewUrl = null;
          notify();
        }
      }

      function selectFile(path) {
        if (sessionData) {
          sessionData.selectedPath = path;
          notify();
        }
      }

      return h('div', {
        style: {
          display: 'flex',
          flexDirection: 'column',
          height: '100%',
          overflow: 'hidden',
          fontFamily: 'var(--dsw-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif)',
          color: 'var(--dsw-alias-label-primary, inherit)',
          fontSize: '13px',
          background: 'var(--dsw-alias-bg-base, transparent)'
        }
      },
        // Top Toolbar
        h('div', {
          style: {
            padding: '10px 14px',
            borderBottom: '1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.08))',
            background: 'var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.025))'
          }
        },
          h('div', {
            style: {
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '8px'
            }
          },
            h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 600, fontSize: '13px' } },
              h('span', null, '🌿 Source Control & Diff Inspector'),
              h('span', {
                style: {
                  fontSize: '11px',
                  color: 'var(--dsw-alias-label-tertiary, #888)',
                  fontWeight: 'normal'
                }
              }, '(' + fileList.length + ' files)')
            ),

            h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px' } },
              sessionData?.reviewUrl ? h('button', {
                onClick: () => openResourceUrl(currentSid, sessionData.reviewUrl),
                title: 'Open full turn review in comparison tab',
                style: {
                  background: 'rgba(37, 99, 235, 0.16)',
                  border: '1px solid rgba(37, 99, 235, 0.4)',
                  color: 'var(--dsw-alias-brand-primary, #60a5fa)',
                  cursor: 'pointer',
                  fontSize: '11px',
                  fontWeight: 600,
                  padding: '2px 8px',
                  borderRadius: '4px'
                }
              }, '🔍 Review All') : null,

              h('button', {
                onClick: () => setListCollapsed(v => !v),
                title: listCollapsed ? 'Expand file list' : 'Collapse file list',
                style: {
                  background: 'none',
                  border: 'none',
                  color: 'var(--dsw-alias-label-secondary, #888)',
                  cursor: 'pointer',
                  fontSize: '11px',
                  padding: '2px 6px'
                }
              }, listCollapsed ? '▼ Files' : '▲ Collapse'),

              h('button', {
                onClick: handleClear,
                title: 'Clear changes for this session',
                style: {
                  background: 'none',
                  border: 'none',
                  color: 'var(--dsw-alias-label-secondary, #888)',
                  cursor: 'pointer',
                  fontSize: '11px',
                  padding: '2px 6px'
                }
              }, 'Clear')
            )
          ),

          // Active indicator banner if running
          (sessionData && sessionData.activePath) ? h('div', {
            style: {
              padding: '6px 10px',
              borderRadius: '6px',
              background: 'rgba(16, 185, 129, 0.12)',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              color: '#10b981',
              fontSize: '12px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              marginBottom: '6px'
            }
          },
            h('span', {
              style: {
                width: '7px',
                height: '7px',
                borderRadius: '50%',
                background: '#10b981',
                boxShadow: '0 0 6px #10b981',
                display: 'inline-block'
              }
            }),
            h('span', { style: { fontWeight: 500 } }, 'Agent active:'),
            h('span', {
              style: {
                fontFamily: 'var(--ds-font-family-code, monospace)',
                fontWeight: 600,
                textOverflow: 'ellipsis',
                overflow: 'hidden',
                whiteSpace: 'nowrap'
              }
            }, sessionData.activePath)
          ) : null,

          // Filter chips & Search
          !listCollapsed ? h('div', null,
            h('div', { style: { display: 'flex', gap: '6px', alignItems: 'center' } },
              h('button', {
                onClick: () => {
                  setFilter('all');
                  if (sessionData) sessionData.filter = 'all';
                },
                style: {
                  padding: '2px 8px',
                  borderRadius: '10px',
                  border: filter === 'all' ? '1px solid var(--dsw-alias-brand-primary, #3b82f6)' : '1px solid transparent',
                  background: filter === 'all' ? 'rgba(59, 130, 246, 0.15)' : 'transparent',
                  color: 'inherit',
                  cursor: 'pointer',
                  fontSize: '11px'
                }
              }, 'All (' + fileList.length + ')'),

              h('button', {
                onClick: () => {
                  setFilter('changes');
                  if (sessionData) sessionData.filter = 'changes';
                },
                style: {
                  padding: '2px 8px',
                  borderRadius: '10px',
                  border: filter === 'changes' ? '1px solid #f59e0b' : '1px solid transparent',
                  background: filter === 'changes' ? 'rgba(245, 158, 11, 0.15)' : 'transparent',
                  color: filter === 'changes' ? '#f59e0b' : 'inherit',
                  cursor: 'pointer',
                  fontSize: '11px',
                  fontWeight: (modifiedFiles.length + addedFiles.length) > 0 ? 600 : 'normal'
                }
              }, 'Changes (' + (modifiedFiles.length + addedFiles.length) + ')'),

              h('button', {
                onClick: () => {
                  setFilter('reads');
                  if (sessionData) sessionData.filter = 'reads';
                },
                style: {
                  padding: '2px 8px',
                  borderRadius: '10px',
                  border: filter === 'reads' ? '1px solid #3b82f6' : '1px solid transparent',
                  background: filter === 'reads' ? 'rgba(59, 130, 246, 0.15)' : 'transparent',
                  color: filter === 'reads' ? '#3b82f6' : 'inherit',
                  cursor: 'pointer',
                  fontSize: '11px'
                }
              }, 'Reads (' + readFiles.length + ')')
            ),

            h('input', {
              type: 'text',
              placeholder: 'Filter files in this session...',
              value: search,
              onChange: e => {
                setSearch(e.target.value);
                if (sessionData) sessionData.searchQuery = e.target.value;
              },
              style: {
                width: '100%',
                boxSizing: 'border-box',
                marginTop: '6px',
                padding: '4px 8px',
                borderRadius: '4px',
                fontSize: '11px',
                border: '1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.12))',
                background: 'var(--dsw-alias-bg-layer-2, rgba(0,0,0,0.15))',
                color: 'inherit',
                outline: 'none'
              }
            })
          ) : null
        ),

        // Files Tree List Pane (Top)
        !listCollapsed ? h('div', {
          style: {
            maxHeight: '190px',
            overflowY: 'auto',
            padding: '6px 8px',
            borderBottom: '1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.1))',
            background: 'var(--dsw-alias-bg-layer-1, rgba(0,0,0,0.1))'
          }
        },
          visible.length === 0 ? h('div', {
            style: {
              padding: '16px 8px',
              textAlign: 'center',
              color: 'var(--dsw-alias-label-tertiary, #666)',
              fontSize: '11px'
            }
          }, 'No files touched in this session yet.') :
          visible.map(f => {
            const isSelected = selectedFile?.path === f.path;
            const badgeStyle = f.status === 'M'
              ? { bg: 'rgba(245, 158, 11, 0.16)', text: '#f59e0b', border: 'rgba(245, 158, 11, 0.35)', label: 'M' }
              : f.status === 'A'
              ? { bg: 'rgba(16, 185, 129, 0.16)', text: '#10b981', border: 'rgba(16, 185, 129, 0.35)', label: 'A' }
              : { bg: 'rgba(59, 130, 246, 0.12)', text: '#60a5fa', border: 'rgba(59, 130, 246, 0.25)', label: 'R' };

            const diffCount = f.diffs ? f.diffs.length : 0;

            return h('div', {
              key: f.path,
              onClick: () => selectFile(f.path),
              style: {
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '4px 8px',
                margin: '1px 0',
                borderRadius: '4px',
                cursor: 'pointer',
                borderLeft: isSelected ? '3px solid var(--dsw-alias-brand-primary, #3b82f6)' : (f.active ? '3px solid #10b981' : '3px solid transparent'),
                background: isSelected ? 'rgba(59, 130, 246, 0.14)' : (f.active ? 'rgba(16, 185, 129, 0.08)' : 'transparent'),
                transition: 'background 0.1s ease'
              }
            },
              h('div', {
                style: {
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  minWidth: 0,
                  flex: 1
                }
              },
                h('span', {
                  title: f.status === 'M' ? 'Modified' : f.status === 'A' ? 'Created' : 'Read',
                  style: {
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '16px',
                    height: '16px',
                    borderRadius: '3px',
                    fontSize: '10px',
                    fontWeight: 700,
                    fontFamily: 'monospace',
                    background: badgeStyle.bg,
                    color: badgeStyle.text,
                    border: '1px solid ' + badgeStyle.border,
                    flexShrink: 0
                  }
                }, badgeStyle.label),

                h('div', {
                  style: {
                    minWidth: 0,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap'
                  }
                },
                  h('span', {
                    style: {
                      fontWeight: isSelected ? 600 : 500,
                      fontFamily: 'var(--ds-font-family-code, monospace)',
                      color: isSelected ? 'var(--dsw-alias-brand-primary, #60a5fa)' : 'inherit',
                      fontSize: '12px'
                    }
                  }, f.name),
                  f.dir !== '.' ? h('span', {
                    style: {
                      marginLeft: '6px',
                      fontSize: '10px',
                      color: 'var(--dsw-alias-label-tertiary, #777)'
                    }
                  }, f.dir) : null
                )
              ),

              h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px', flexShrink: 0 } },
                diffCount > 0 ? h('span', {
                  style: {
                    fontSize: '10px',
                    color: '#f59e0b',
                    background: 'rgba(245, 158, 11, 0.12)',
                    padding: '1px 5px',
                    borderRadius: '8px'
                  }
                }, diffCount + ' diff') : null,

                h('button', {
                  onClick: (e) => {
                    e.stopPropagation();
                    openSingleFile(currentSid, f.path, f.line);
                  },
                  title: 'Open in Editor',
                  style: {
                    padding: '1px 6px',
                    borderRadius: '3px',
                    fontSize: '10px',
                    border: '1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.12))',
                    background: 'transparent',
                    color: 'var(--dsw-alias-label-secondary, #888)',
                    cursor: 'pointer'
                  }
                }, 'View')
              )
            );
          })
        ) : null,

        // Selected File Diff Inspector (Bottom)
        h(SelectedFileDiffInspector, {
          file: selectedFile,
          currentSid
        })
      );
    }

    // React Error Boundary Component to guarantee no white screens ever
    class SafeGitTreeBody extends React.Component {
      constructor(props) {
        super(props);
        this.state = { hasError: false, error: null };
      }
      static getDerivedStateFromError(error) {
        return { hasError: true, error: error };
      }
      componentDidCatch(error, info) {
        console.error('[dsh-live-inspector] Caught render error:', error, info);
      }
      render() {
        if (this.state.hasError) {
          return h('div', {
            style: {
              padding: '24px 16px',
              fontFamily: 'sans-serif',
              color: 'var(--dsw-alias-label-primary, inherit)'
            }
          },
            h('div', { style: { color: '#ef4444', fontWeight: 600, marginBottom: '6px' } }, '⚠️ Live Inspector encountered a rendering issue'),
            h('div', { style: { fontSize: '11px', color: '#888', marginBottom: '12px' } }, String(this.state.error?.message || this.state.error)),
            h('button', {
              onClick: () => this.setState({ hasError: false, error: null }),
              style: {
                padding: '4px 12px',
                borderRadius: '4px',
                cursor: 'pointer',
                background: 'var(--dsw-alias-brand-primary, #2563eb)',
                color: '#fff',
                border: 'none',
                fontSize: '12px'
              }
            }, 'Reload View')
          );
        }
        return h(GitTreeBody, this.props);
      }
    }

    return {
      inject: ['sidebarRight', 'sidebarRightTabs', 'slots', 'sessions'],
      apply(ctx) {
        globalCtx = ctx;
        const sessionUnsubscribes = new Map();

        // Register tab type into sidebarRightTabs
        if (ctx.sidebarRightTabs && typeof ctx.sidebarRightTabs.register === 'function') {
          ctx.effect(() => {
            return ctx.sidebarRightTabs.register({
              id: TAB_ID,
              kind: TAB_KIND,
              priority: 'builtin',
              title: () => 'Git Tree',
              guide: [{
                id: 'git-tree',
                order: 1,
                title: () => 'Git Tree',
                description: () => 'Source control changes and professional side-by-side diff'
              }]
            });
          }, 'dsh-live-inspector: git-tree tab registration');
        }

        // Register tab body into sidebar.right.pane.tab
        ctx.effect(() => {
          return ctx.slots.inject('sidebar.right.pane.tab', () => ctx.slots.register({
            name: 'sidebar.right.pane.tab',
            key: TAB_ID
          }, SafeGitTreeBody));
        }, 'dsh-live-inspector: git-tree body slot');

        // Register live tab title into sidebar.right.pane.tab.title
        ctx.effect(() => {
          return ctx.slots.inject('sidebar.right.pane.tab.title', () => ctx.slots.register({
            name: 'sidebar.right.pane.tab.title',
            key: TAB_ID
          }, GitTreeTitle));
        }, 'dsh-live-inspector: git-tree title slot');

        function ensureTabOpen(sid) {
          const targetSid = sid || resolveCurrentSessionId();
          if (!targetSid) return;

          const sessionData = getSessionState(targetSid);
          if (sessionData && sessionData.autoOpenOpenedThisTurn) return;

          try {
            let opened = false;
            if (ctx.sidebarRight) {
              if (typeof ctx.sidebarRight.openTabIn === 'function') {
                ctx.sidebarRight.openTabIn(targetSid, TAB_KIND);
                opened = true;
              } else if (typeof ctx.sidebarRight.openTab === 'function') {
                ctx.sidebarRight.openTab(TAB_KIND);
                opened = true;
              }

              // Also ensure sidebar is expanded if collapsed
              try {
                const actions = typeof ctx.sidebarRight.actionsFor === 'function'
                  ? ctx.sidebarRight.actionsFor(targetSid)
                  : null;
                if (actions && typeof actions.setExpanded === 'function') {
                  actions.setExpanded(targetSid, true);
                }
              } catch {}
            }

            if (opened && sessionData) {
              sessionData.autoOpenOpenedThisTurn = true;
            }
          } catch (e) {
            console.debug('[dsh-live-inspector] openTab deferred:', e);
          }
        }

        function processEntries(sessionId, entries, isInitialScan = false) {
          if (!Array.isArray(entries) || entries.length === 0) return;
          const sessionData = getSessionState(sessionId);
          if (!sessionData) return;

          for (const entry of entries) {
            if (!entry || entry.type !== 'event' || !entry.event) continue;
            const ev = entry.event;

            // Strict sequence de-duplication: each event is processed exactly once
            if (typeof ev.seq === 'number') {
              if (sessionData.processedSeqs.has(ev.seq)) continue;
              sessionData.processedSeqs.add(ev.seq);
            }

            if (ev.type === 'turn/start') {
              if (!isInitialScan) {
                sessionData.autoOpenOpenedThisTurn = false;
              }
              clearActive(sessionId);
            }

            if (ev.type === 'tool/call' && ev.data) {
              const toolName = ev.data.name;
              const extracted = extractFilePathAndDiff(toolName, ev.data.arguments);
              if (extracted && extracted.path) {
                recordFile(sessionId, extracted.path, extracted.status, extracted.line, extracted.diff, ev.seq);
                if (!isInitialScan) {
                  ensureTabOpen(sessionId);
                }
              }
            }

            if (ev.type === 'tool/result' && ev.data && ev.data.meta && Array.isArray(ev.data.meta.diffs)) {
              for (const df of ev.data.meta.diffs) {
                if (df && df.path) {
                  recordFile(sessionId, df.path, 'M', undefined, { oldText: df.oldText, newText: df.newText }, ev.seq);
                }
              }
              if (!isInitialScan) {
                ensureTabOpen(sessionId);
              }
            }

            if (ev.type === 'step/end' || ev.type === 'turn/end' || ev.type === 'workspace/changes') {
              clearActive(sessionId);
            }

            if (ev.type === 'workspace/changes' && ev.data) {
              if (typeof ev.data.turn === 'number') {
                sessionData.reviewUrl = 'dsh-resource://changes-review/session/' + encodeSegment(sessionId) + '/' + ev.seq + '/' + ev.data.turn;
              }
              if (!isInitialScan) {
                ensureTabOpen(sessionId);
              }
            }
          }

          notify();
        }

        function bindSession(sessionId) {
          if (!sessionId || sessionUnsubscribes.has(sessionId)) return;

          try {
            const binding = ctx.sessions?.binding(sessionId);
            if (binding && binding.eventSource && typeof binding.eventSource.subscribe === 'function') {
              // Initial scan of historical entries
              const initialSnapshot = binding.eventSource.getSnapshot();
              if (initialSnapshot && Array.isArray(initialSnapshot.entries)) {
                processEntries(sessionId, initialSnapshot.entries, true);
              }

              // Subscribe to real-time events
              const unsub = binding.eventSource.subscribe(() => {
                const snapshot = binding.eventSource.getSnapshot();
                if (!snapshot) return;
                const change = snapshot.change;
                if (change && Array.isArray(change.entries)) {
                  processEntries(sessionId, change.entries, false);
                } else if (change && change.kind === 'settle-assistant' && change.entry) {
                  processEntries(sessionId, [change.entry], false);
                } else if (Array.isArray(snapshot.entries)) {
                  // Fallback: processEntries automatically filters via processedSeqs
                  processEntries(sessionId, snapshot.entries, false);
                }
              });
              sessionUnsubscribes.set(sessionId, unsub);
            }
          } catch (e) {
            console.warn('[dsh-live-inspector] Failed to bind session:', sessionId, e);
          }
        }

        function syncAllSessions() {
          try {
            const list = ctx.sessions?.list?.getSnapshot();
            if (list && list.byId) {
              for (const id in list.byId) {
                bindSession(id);
              }
            }
          } catch (e) {
            console.warn('[dsh-live-inspector] syncAllSessions error:', e);
          }
        }

        // Subscribe to sessions.list to automatically bind all sessions
        if (ctx.sessions?.list) {
          ctx.effect(() => {
            const unsub = ctx.sessions.list.subscribe(() => {
              syncAllSessions();
              notify();
            });
            syncAllSessions();
            return () => {
              if (unsub) unsub();
            };
          }, 'dsh-live-inspector: all sessions list subscriber');
        }

        // Watch active session on screen
        if (ctx.sidebarRight && ctx.sidebarRight.mounted) {
          ctx.effect(() => {
            const unsub = ctx.sidebarRight.mounted.subscribe(() => {
              const sid = ctx.sidebarRight.mounted.getSnapshot();
              currentMountedSessionId = sid;
              if (sid) {
                bindSession(sid);
                notify();
              }
            });

            const initialSid = ctx.sidebarRight.mounted.getSnapshot();
            currentMountedSessionId = initialSid;
            if (initialSid) {
              bindSession(initialSid);
              notify();
            }

            return () => {
              if (unsub) unsub();
            };
          }, 'dsh-live-inspector: sidebarRight mounted subscriber');
        }

        // Clean up session subscriptions when plugin unloads
        ctx.effect(() => {
          return () => {
            for (const [, release] of sessionUnsubscribes) {
              try {
                release();
              } catch {}
            }
            sessionUnsubscribes.clear();
          };
        }, 'dsh-live-inspector: all session subscriptions cleanup');

        console.info('[dsh-live-inspector] Fully guarded & de-duplicated Git Tree active.');
      }
    };
  }
});
