# Changelog

## [0.1.0] - 2026-08-17

Initial release.

### Added

- `novel_profile` — generate/refresh character personality profile cards: five-dimension personality, motivations, fears, values, speech style, behavioral habits, emotional triggers, weaknesses, current growth arc, and consistency red lines; also collects full names/aliases.
- `novel_appearance` — local-only appearance weight & share statistics: mentions/paragraphs/dialogue counts, per-chapter distribution, weight score, share ranking, protagonist/supporting tiers, and suspected unregistered characters.
- `novel_deviation` — behavioral-drift detection against profile cards, distinguishing unforeshadowed OOC flips from justified character growth.
- `novel_profiler_status` — character consistency overview (card ↔ profile comparison, weights, unregistered characters).
- `dsh.bundle` manifest for `dsh plugin add` installation, plus a Windows install script.
