/**
 * dsh-character-profiler · 本地验证脚本（不经过 DSH 会话，直接驱动引擎）
 * 用法：node test-local.mjs [--stats] [--profile maryanna-houston] [--deviation maryanna-houston]
 * 依赖：DSH_WRITING_API_KEY 环境变量，或从 ~/.dsh/profiles/web/cordis.patch.yml 提取 tool-writing 的 apiKey。
 */
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

const PROFILE_DIR = path.join(os.homedir(), ".dsh", "profiles", "web");
const ENGINE_ENTRY = path.join(PROFILE_DIR, "node_modules", "dsh-tool-writing", "lib", "engine.js");
const { NovelEngine } = await import("file:///" + ENGINE_ENTRY.replace(/\\/g, "/"));

const { computeAppearance, renderStatsReport } = await import("./lib/stats.js");
const { generateProfile } = await import("./lib/profile.js");
const { detectDeviation, renderDeviationReport } = await import("./lib/deviation.js");
const { listCharacterCards, resolveCharacterNames, listProfiles } = await import("./lib/project.js");

function resolveApiKey() {
  if (process.env.DSH_WRITING_API_KEY) return process.env.DSH_WRITING_API_KEY;
  if (process.env.DEEPSEEK_API_KEY) return process.env.DEEPSEEK_API_KEY;
  try {
    const patch = fs.readFileSync(path.join(PROFILE_DIR, "cordis.patch.yml"), "utf8");
    const m = patch.match(/apiKey:\s*['"]?([^'"\s]+)/);
    if (m) return m[1];
  } catch (e) {}
  return "";
}

const args = process.argv.slice(2);
const projectRoot = path.resolve(argValue(args, "--root") || process.cwd());
const apiKey = resolveApiKey();
if (!apiKey) { console.error("未找到 apiKey（DSH_WRITING_API_KEY 或 profile patch）"); process.exit(1); }

const engine = new NovelEngine({
  projectRoot: projectRoot,
  apiKey: apiKey,
  model: "deepseek-v4-flash",
  deepModel: "deepseek-v4-pro",
  baseURL: "https://api.deepseek.com"
});

const profilesDir = "lore/profiles";
console.log("=== 项目：" + projectRoot + " ===");

if (args.includes("--stats") || args.length === 0) {
  console.log("\n\n########## 出场统计（本地） ##########");
  const stats = await computeAppearance(engine, { profilesDir: profilesDir });
  const profiles = {};
  for (const p of await listProfiles(engine, profilesDir)) profiles[p.key] = p;
  console.log(renderStatsReport(stats, profiles));
}

const profArg = argValue(args, "--profile");
if (profArg) {
  console.log("\n\n########## 性格侧写生成：" + profArg + " ##########");
  const cards = await listCharacterCards(engine);
  const card = cards.find(function (c) { return c.key === profArg || c.title === profArg; });
  if (!card) { console.error("找不到角色：" + profArg); process.exit(1); }
  const r = await resolveCharacterNames(engine, card, profilesDir);
  const out = await generateProfile(engine, { profilesDir: profilesDir, maxTokens: 4096 }, {
    card: card, names: r.names, scope: undefined, signal: undefined, deep: true
  });
  console.log("已写入：" + out.rel + "（" + out.markdown.length + " 字符）");
  console.log(out.markdown.slice(0, 1200));
}

const devArg = argValue(args, "--deviation");
if (devArg) {
  console.log("\n\n########## 偏离检测：" + devArg + " ##########");
  const result = await detectDeviation(engine, { profilesDir: profilesDir, maxConcurrency: 2 }, {
    character: devArg, scope: undefined, signal: undefined
  });
  console.log(renderDeviationReport(result, "卡纳维尔"));
}

function argValue(args, name) {
  const i = args.indexOf(name);
  return i >= 0 && i + 1 < args.length ? args[i + 1] : null;
}
