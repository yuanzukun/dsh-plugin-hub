/**
 * dsh-character-profiler · unit tests
 * 纯函数单元测试：不依赖引擎/网络/LLM，`node --test test/` 直接运行。
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  splitParagraphs,
  isDialogueParagraph,
  countMentions,
  deriveShortNames
} from "../lib/project.js";
import { levelOf } from "../lib/stats.js";

test("splitParagraphs: 按空行分段", () => {
  const paras = splitParagraphs("第一段。\n\n第二段。\n\n第三段。");
  assert.equal(paras.length, 3);
  assert.equal(paras[0], "第一段。");
  assert.equal(paras[2], "第三段。");
});

test("splitParagraphs: 剔除标题与分隔线，空输入返回空数组", () => {
  assert.deepEqual(splitParagraphs(undefined), []);
  assert.deepEqual(splitParagraphs(""), []);
  assert.deepEqual(splitParagraphs("# 标题\n\n正文"), ["正文"]);
  assert.deepEqual(splitParagraphs("---\n\n正文"), ["正文"]);
});

test("splitParagraphs: 段内多行合并为单段", () => {
  const paras = splitParagraphs("第一行\n第二行\n\n新段");
  assert.equal(paras[0], "第一行\n第二行");
});

test("isDialogueParagraph: 引号段识别", () => {
  assert.equal(isDialogueParagraph("他说：「你好」"), true);
  assert.equal(isDialogueParagraph("她说\"好的\""), true);
  assert.equal(isDialogueParagraph("普通的叙述段。"), false);
});

test("countMentions: 长名优先匹配，短名不吞长名", () => {
  assert.equal(countMentions("玛丽安娜叫玛丽去吃饭。", ["玛丽安娜", "玛丽"]), 2);
  assert.equal(countMentions("玛丽安娜·霍斯顿出门了。", ["玛丽安娜·霍斯顿", "玛丽"]), 1);
});

test("countMentions: 短于两字的别称跳过，空输入返回 0", () => {
  assert.equal(countMentions("阿走了。", ["阿"]), 0);
  assert.equal(countMentions("", ["玛丽"]), 0);
  assert.equal(countMentions("没有提及。", []), 0);
});

test("deriveShortNames: 从全名推导简称", () => {
  const names = deriveShortNames("玛丽安娜·霍斯顿");
  assert.equal(names[0], "玛丽安娜·霍斯顿");
  assert.ok(names.includes("玛丽安娜"));
  assert.ok(names.includes("霍斯顿"));
  assert.ok(names.includes("玛丽"));
  assert.deepEqual(deriveShortNames(""), []);
});

test("levelOf: 档位阈值", () => {
  assert.equal(levelOf(0.18), "主角");
  assert.equal(levelOf(0.06), "重要配角");
  assert.equal(levelOf(0.02), "配角");
  assert.equal(levelOf(0.0199), "龙套");
  assert.equal(levelOf(0), "龙套");
});
