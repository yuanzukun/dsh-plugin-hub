# dsh-character-profiler 一键安装脚本
# 把本插件安装到 DSH web profile（C:\Users\<用户>\.dsh\profiles\web）
# 用法：右键「使用 PowerShell 运行」，或：
#   powershell -ExecutionPolicy Bypass -File install.ps1
# 安装完成后需重启 dsh web 才会生效（会中断当前 GUI 会话，请先保存工作）。

$ErrorActionPreference = "Stop"
$pluginDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$profileDir = Join-Path $env:USERPROFILE ".dsh\profiles\web"

if (-not (Test-Path $profileDir)) {
    Write-Host "未找到 web profile 目录：$profileDir" -ForegroundColor Red
    exit 1
}

Write-Host "==> 插件目录：$pluginDir" -ForegroundColor Cyan
Write-Host "==> 目标 profile：$profileDir" -ForegroundColor Cyan

# ── 0. 无 BOM UTF-8 写入（避免 PowerShell 5.1 的 BOM 破坏 JSON/YAML） ────────
function Write-NoBom([string]$Path, [string]$Text) {
    [System.IO.File]::WriteAllText($Path, $Text, (New-Object System.Text.UTF8Encoding($false)))
}

# ── 1. 安装包到 profile（优先 pnpm add file:，失败则直接复制目录） ──────────
$installed = $false
$pnpm = Get-Command pnpm -ErrorAction SilentlyContinue
if ($pnpm) {
    Write-Host "==> 使用 pnpm 安装（file: 本地包）……" -ForegroundColor Cyan
    try {
        Push-Location $profileDir
        pnpm add "file:$pluginDir" 2>&1 | ForEach-Object { Write-Host "    $_" }
        Pop-Location
        if (Test-Path (Join-Path $profileDir "node_modules\dsh-character-profiler\package.json")) {
            $installed = $true
        }
    } catch {
        Write-Host "    pnpm 安装失败，改用直接复制。" -ForegroundColor Yellow
        try { Pop-Location } catch {}
    }
}
if (-not $installed) {
    Write-Host "==> 直接复制插件目录到 node_modules……" -ForegroundColor Cyan
    $dest = Join-Path $profileDir "node_modules\dsh-character-profiler"
    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
    robocopy $pluginDir $dest /E /XD node_modules .git /XF test-local.mjs > $null
    if ($LASTEXITCODE -ge 8) { Write-Host "复制失败（robocopy 退出码 $LASTEXITCODE）" -ForegroundColor Red; exit 1 }
    $installed = $true
    Write-Host "    已复制（未写锁文件；建议之后在 profile 目录执行 pnpm install 固化依赖）" -ForegroundColor Yellow
}

# ── 2. 把插件加入 profile 的 bundles 列表（dsh.profile.bundles） ─────────────
$pkgPath = Join-Path $profileDir "package.json"
$pkg = Get-Content $pkgPath -Raw | ConvertFrom-Json
if ($pkg.dsh.profile.bundles -contains "dsh-character-profiler") {
    Write-Host "==> bundles 已包含 dsh-character-profiler，跳过。" -ForegroundColor DarkGray
} else {
    Write-Host "==> 更新 bundles 列表……" -ForegroundColor Cyan
    $pkg.dsh.profile.bundles = @($pkg.dsh.profile.bundles) + "dsh-character-profiler"
    $json = $pkg | ConvertTo-Json -Depth 20
    Write-NoBom $pkgPath $json
    Write-Host "    bundles 已加入 dsh-character-profiler。" -ForegroundColor Green
}

# ── 3. 在 profile 的 cordis.patch.yml 登记插件行（apiKey 由插件运行时自动继承
#       dsh-tool-writing 行的配置，这里只声明行、不复制 key） ─────────────────
$patchPath = Join-Path $profileDir "cordis.patch.yml"
$patch = Get-Content $patchPath -Raw
if ($patch -match '(?m)^\s*- id: character-profiler\s*$') {
    Write-Host "==> cordis.patch.yml 已包含 character-profiler 行，跳过。" -ForegroundColor DarkGray
} else {
    Write-Host "==> 在 cordis.patch.yml 登记 character-profiler 行……" -ForegroundColor Cyan
    $add = @"

# dsh-character-profiler: 角色性格侧写/出场统计/偏离检测；API 配置自动继承 dsh-tool-writing 行（无需复制 key）
- id: character-profiler
  name: dsh-character-profiler
"@
    Write-NoBom $patchPath ($patch.TrimEnd() + "`r`n" + $add)
    Write-Host "    行已登记（apiKey 由插件运行时自动继承 tool-writing 配置）。" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "安装完成！下一步：重启 dsh web（关闭当前窗口后重新运行启动命令）。" -ForegroundColor Green
Write-Host "重启后在写作会话中即可使用 4 个新工具：" -ForegroundColor Green
Write-Host "  novel_profile          生成/更新角色性格侧写档案" -ForegroundColor White
Write-Host "  novel_appearance       统计角色出场权重与占比" -ForegroundColor White
Write-Host "  novel_deviation        检测角色行为与侧写的偏离程度" -ForegroundColor White
Write-Host "  novel_profiler_status  角色一致性总览" -ForegroundColor White
Write-Host "============================================================" -ForegroundColor Green
