import { Buffer } from 'node:buffer'
import { describe, expect, it } from 'vitest'
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { resolveNativeInvocation, runNativeCommand, type SpawnSync } from '../scripts/native-command.mjs'

const ROOT = dirname(fileURLToPath(new URL('../package.json', import.meta.url)))

function successfulSpawn(calls: Array<{ command: string; args: readonly string[]; options: unknown }>): SpawnSync {
  return (command, args, options) => {
    calls.push({ command, args, options })
    return { status: 0 }
  }
}

function decodedPayload(invocation: { readonly args: readonly string[] }) {
  const payload = invocation.args.at(-1)
  if (payload === undefined) throw new Error('expected PowerShell payload')
  return JSON.parse(Buffer.from(payload, 'base64').toString('utf8')) as unknown
}

describe('native command execution', () => {
  it('passes every argument directly without a command interpreter', () => {
    const calls: Array<{ command: string; args: readonly string[]; options: unknown }> = []
    const hostile = 'https://registry.example.test/&echo INJECTED'

    runNativeCommand('pnpm', ['install', `--registry=${hostile}`], 'C:\\workspace', {
      platform: 'linux',
      spawnSync: successfulSpawn(calls),
    })

    expect(calls).toEqual([{
      command: 'pnpm',
      args: ['install', `--registry=${hostile}`],
      options: {
        cwd: 'C:\\workspace',
        shell: false,
        stdio: 'inherit',
        windowsHide: true,
      },
    }])
  })

  it('bypasses Windows npm and pnpm cmd shims through trusted JavaScript entrypoints', () => {
    const environment = {
      npm_execpath: 'C:\\pnpm\\dist\\pnpm.cjs',
      npm_node_execpath: 'C:\\node\\node.exe',
    }
    const hostile = '--registry=https://registry.example.test/&echo INJECTED'

    expect(resolveNativeInvocation('pnpm', ['install', hostile], {
      platform: 'win32', env: environment, execPath: 'C:\\fallback\\node.exe',
    })).toEqual({
      command: 'C:\\node\\node.exe',
      args: ['C:\\pnpm\\dist\\pnpm.cjs', 'install', hostile],
    })
    expect(resolveNativeInvocation('npm', ['pack', hostile], {
      platform: 'win32', env: environment, execPath: 'C:\\fallback\\node.exe',
    })).toEqual({
      command: 'C:\\node\\node.exe',
      args: ['C:\\node\\node_modules\\npm\\bin\\npm-cli.js', 'pack', hostile],
    })
    const explicitShim = resolveNativeInvocation('pnpm', ['install', hostile], {
      platform: 'win32',
      env: { npm_execpath: 'C:\\setup\\bin\\pnpm.cmd' },
      execPath: 'C:\\node\\node.exe',
      pwshPath: 'C:\\pwsh\\pwsh.exe',
      wrapperPath: 'C:\\repo\\scripts\\run-native-command.ps1',
    })
    expect(explicitShim.command).toBe('C:\\pwsh\\pwsh.exe')
    expect(explicitShim.args.slice(0, -1)).toEqual([
      '-NoLogo', '-NoProfile', '-NonInteractive', '-File',
      'C:\\repo\\scripts\\run-native-command.ps1', '-Payload',
    ])
    expect(decodedPayload(explicitShim)).toEqual({
      command: 'C:\\setup\\bin\\pnpm.cmd', args: ['install', hostile],
    })
    const discoveredShim = resolveNativeInvocation('pnpm', ['install', hostile], {
      platform: 'win32',
      env: {},
      execPath: 'C:\\node\\node.exe',
      findExecutable: () => 'C:\\setup\\bin\\pnpm.CMD',
      pwshPath: 'C:\\pwsh\\pwsh.exe',
      wrapperPath: 'C:\\repo\\scripts\\run-native-command.ps1',
    })
    expect(discoveredShim.command).toBe('C:\\pwsh\\pwsh.exe')
    expect(decodedPayload(discoveredShim)).toEqual({
      command: 'C:\\setup\\bin\\pnpm.CMD', args: ['install', hostile],
    })
    expect(resolveNativeInvocation('pnpm', ['install'], {
      platform: 'win32',
      env: { PNPM_HOME: 'C:\\setup-pnpm\\node_modules\\@pnpm\\exe' },
      execPath: 'C:\\node\\node.exe',
      isFile: path => path === 'C:\\setup-pnpm\\node_modules\\@pnpm\\exe\\pnpm.exe',
    })).toEqual({
      command: 'C:\\setup-pnpm\\node_modules\\@pnpm\\exe\\pnpm.exe',
      args: ['install'],
    })
  })

  it('fails loudly when the native process cannot start or exits nonzero', () => {
    expect(() => runNativeCommand('pnpm', ['install'], '.', {
      platform: 'linux',
      spawnSync: () => ({ status: null, error: Object.assign(new Error('missing'), { code: 'ENOENT' }) }),
    })).toThrow(/missing/)
    expect(() => runNativeCommand('pnpm', ['install'], '.', {
      platform: 'linux',
      spawnSync: () => ({ status: 7 }),
    })).toThrow(/exit code 7/)
  })

  it('routes every packaging launcher through the shared shell-free boundary', () => {
    for (const name of [
      'install-dsh-tarballs.mjs',
      'publish-release.mjs',
      'verify-packed-delegation.mjs',
      'verify-profile-install.mjs',
      'verify-reproducible-pack.mjs',
    ]) {
      const source = readFileSync(join(ROOT, 'scripts', name), 'utf8')
      expect(source, name).toContain("from './native-command.mjs'")
      expect(source, name).not.toMatch(/ComSpec|cmd\.exe|['"]\/c['"]/)
    }
  })
})
