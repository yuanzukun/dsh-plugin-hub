import { describe, expect, it } from 'vitest'
import { NO_START_CAPABILITIES } from '@deepseek-ai/dsh-subagent'
import type { Config } from '../src/config.ts'
import { compileCatalog, compileDelegationPlan, type RuntimeSnapshot } from '../src/compiler.ts'
import { createResourceSnapshot, promptContentDigest } from '../src/resources.ts'

const base: Config = {
  toolName: 'legion',
  enableRunInBackground: true,
  defaultProfile: 'quick',
  profiles: {
    quick: {
      description: 'Fast focused work.',
      subagentProvider: 'spawn',
      maxDepth: 2,
      defaultRunInBackground: true,
      result: 'text',
    },
    review: {
      description: 'Independent review.',
      subagentProvider: 'spawn',
      maxDepth: 2,
      defaultRunInBackground: false,
      result: 'review-v1',
      toolFilter: { deny: ['write'] },
    },
  },
}

const spawn: RuntimeSnapshot = {
  providers: {
    spawn: {
      capabilities: { agentOptions: true, outputSchema: true, depthLimit: true, toolFilter: true, persona: true },
      continuable: true,
    },
  },
}

describe('compileCatalog', () => {
  it('materializes detached effective profiles and stable digests', () => {
    const first = compileCatalog(base, spawn)
    const reordered = compileCatalog({
      ...base,
      profiles: { review: base.profiles.review!, quick: base.profiles.quick! },
    }, spawn)

    expect(Object.keys(first.activeSpecialists)).toEqual(['quick', 'review'])
    expect(first.specialists.quick).toMatchObject({
      name: 'quick', active: true, defaultMode: 'continuable',
      allowedModes: ['foreground', 'continuable'], result: 'text',
    })
    expect(first.specialists.review).toMatchObject({
      name: 'review', active: true, defaultMode: 'foreground',
      allowedModes: ['foreground'], result: 'review-v1',
    })
    expect(first.policyDigest).toMatch(/^sha256:[a-f0-9]{64}$/)
    expect(first.catalogDigest).toMatch(/^sha256:[a-f0-9]{64}$/)
    expect(reordered.policyDigest).toBe(first.policyDigest)
    expect(reordered.catalogDigest).toBe(first.catalogDigest)
    expect(first.diagnostics).toEqual([])

    expect(Object.isFrozen(first)).toBe(true)
    expect(Object.isFrozen(first.specialists)).toBe(true)
    expect(Object.isFrozen(first.specialists.review)).toBe(true)
    expect(Object.isFrozen(first.specialists.review?.toolFilter?.deny)).toBe(true)
    expect(() => {
      ;(first.specialists.review!.toolFilter!.deny as string[]).push('edit')
    }).toThrow(TypeError)
    expect(base.profiles.review?.toolFilter?.deny).toEqual(['write'])
  })

  it('rejects unknown authored fields before they can influence policy digests', () => {
    expect(() => compileCatalog({
      ...base,
      profiles: {
        quick: { ...base.profiles.quick!, typo: true },
      },
    } as unknown as Config, spawn)).toThrow(/unknown field.*typo/)
  })

  it('rejects ambiguous or contradictory authored route candidates', () => {
    const profile = base.profiles.quick!
    expect(() => compileCatalog({
      ...base,
      profiles: {
        quick: {
          ...profile,
          agentOptions: { provider: 'legacy', model: 'legacy-model' },
          routes: [{ id: 'exact', provider: 'route', model: 'model' }],
        },
      },
    }, spawn)).toThrow(/cannot combine routes with legacy agentOptions/)
    const routeProfile = profile
    expect(() => compileCatalog({
      ...base,
      profiles: {
        quick: {
          ...routeProfile,
          routes: [
            { id: 'same', provider: 'route', model: 'one' },
            { id: 'same', provider: 'route', model: 'two' },
          ],
        },
      },
    }, spawn)).toThrow(/repeats route id/)
    expect(() => compileCatalog({
      ...base,
      profiles: {
        quick: {
          ...routeProfile,
          routes: [{
            id: 'bad-output', provider: 'route', model: 'model', maxTokens: 100,
            constraints: { minEffectiveOutputTokens: 200 },
          }],
        },
      },
    }, spawn)).toThrow(/maxTokens is below minEffectiveOutputTokens/)
  })

  it('materializes omitted result defaults before hashing', () => {
    const explicit = compileCatalog(base, spawn)
    const legacyQuick = { ...base.profiles.quick! }
    delete legacyQuick.result
    const legacy = compileCatalog({
      ...base,
      profiles: { ...base.profiles, quick: legacyQuick },
    }, spawn)

    expect(legacy.specialists.quick?.result).toBe('text')
    expect(legacy.policyDigest).toBe(explicit.policyDigest)
  })

  it('keeps an unavailable provider as an inactive warning without failing the catalog', () => {
    const catalog = compileCatalog(base, { providers: {} })

    expect(catalog.activeSpecialists).toEqual({})
    expect(catalog.diagnostics).toEqual([
      expect.objectContaining({
        code: 'PROFILE_PROVIDER_UNAVAILABLE', severity: 'warning', specialist: 'quick',
      }),
      expect.objectContaining({
        code: 'PROFILE_PROVIDER_UNAVAILABLE', severity: 'warning', specialist: 'review',
      }),
      expect.objectContaining({
        code: 'DEFAULT_PROFILE_INACTIVE', severity: 'warning', specialist: 'quick',
      }),
    ])
  })

  it('reports stable foreground capability errors', () => {
    const catalog = compileCatalog(base, {
      providers: {
        spawn: {
          capabilities: NO_START_CAPABILITIES,
          continuable: true,
        },
      },
    })

    expect(catalog.specialists.quick?.active).toBe(true)
    expect(catalog.specialists.review?.active).toBe(false)
    expect(catalog.diagnostics.map(item => item.code)).toEqual([
      'PROFILE_DEPTH_UNSUPPORTED',
      'PROFILE_TOOL_FILTER_UNSUPPORTED',
      'PROFILE_OUTPUT_SCHEMA_UNSUPPORTED',
    ])
  })

  it('rejects profiles whose provider cannot honor Agent option overrides', () => {
    const unsupported: RuntimeSnapshot = {
      providers: {
        spawn: {
          capabilities: { agentOptions: false, outputSchema: true, depthLimit: true, toolFilter: true, persona: true },
          continuable: true,
        },
      },
    }
    for (const override of [
      { agentOptions: { provider: 'models', model: 'fast' } },
      { routes: [{ id: 'exact', provider: 'models', model: 'fast' }] },
    ] as const) {
      const profile = { ...base.profiles.quick!, ...override, defaultRunInBackground: false }
      const catalog = compileCatalog({ ...base, profiles: { quick: profile }, defaultProfile: 'quick' }, unsupported)
      expect(catalog.activeSpecialists.quick).toBeUndefined()
      expect(catalog.diagnostics).toContainEqual(expect.objectContaining({
        code: 'PROFILE_AGENT_OPTIONS_UNSUPPORTED',
        severity: 'error',
        specialist: 'quick',
      }))
    }
  })

  it('rejects an invocation mode not supported by the provider snapshot', () => {
    const catalog = compileCatalog({
      ...base,
      profiles: { quick: base.profiles.quick! },
      defaultProfile: 'quick',
    }, {
      providers: {
        spawn: {
          capabilities: NO_START_CAPABILITIES,
          continuable: true,
        },
      },
    })

    expect(catalog.activeSpecialists.quick?.allowedModes).toEqual(['continuable'])
    expect(() => compileDelegationPlan(catalog, {
      description: 'force foreground',
      prompt: 'Work.',
      runInBackground: false,
    })).toThrow(/does not support foreground execution/)
  })

  it('rejects structured result contracts on the continuable default path', () => {
    const catalog = compileCatalog({
      ...base,
      profiles: {
        review: { ...base.profiles.review!, defaultRunInBackground: true },
      },
      defaultProfile: 'review',
    }, spawn)

    expect(catalog.activeSpecialists).toEqual({})
    expect(catalog.diagnostics.map(item => item.code)).toEqual([
      'PROFILE_STRUCTURED_BACKGROUND_UNSUPPORTED',
      'DEFAULT_PROFILE_INACTIVE',
    ])
  })

  it('rejects invalid delegation text at the public compiler seam', () => {
    const catalog = compileCatalog(base, spawn)
    expect(() => compileDelegationPlan(catalog, {
      description: '   ',
      prompt: 'Work.',
    })).toThrow(/non-empty bounded strings/)
    expect(() => compileDelegationPlan(catalog, {
      description: 'Work.',
      prompt: 'x'.repeat(100_001),
    })).toThrow(/non-empty bounded strings/)
    expect(() => compileDelegationPlan(catalog, {
      description: 'Work.',
      prompt: 'Run.',
      runInBackground: 'yes',
    } as never)).toThrow(/invocation fields are invalid/)
    expect(() => compileDelegationPlan(catalog, {
      description: 'Work.',
      prompt: 'Run.',
      hidden: true,
    } as never)).toThrow(/invocation fields are invalid/)
    let reads = 0
    const accessor = { description: 'Work.', prompt: 'Run.' }
    Object.defineProperty(accessor, 'profile', {
      enumerable: true,
      get() { reads += 1; return 'quick' },
    })
    expect(() => compileDelegationPlan(catalog, accessor as never)).toThrow(/plain data/)
    expect(reads).toBe(0)
  })

  it('accepts the canonical Specialist invocation field and keeps the retired alias exclusive', () => {
    const catalog = compileCatalog(base, spawn)
    expect(compileDelegationPlan(catalog, {
      specialist: 'review',
      description: 'review change',
      prompt: 'Review the patch.',
    }).specialist).toBe('review')
    expect(() => compileDelegationPlan(catalog, {
      specialist: 'review',
      profile: 'review',
      description: 'review change',
      prompt: 'Review the patch.',
    })).toThrow(/specialist and deprecated profile cannot be combined/)
    expect(() => compileDelegationPlan(catalog, {
      specialist: 'missing',
      description: 'review change',
      prompt: 'Review the patch.',
    })).toThrow(/unknown Specialist "missing"/)
  })

  it('compiles one invocation to detached plan data and a structured schema', () => {
    const catalog = compileCatalog(base, spawn)
    const plan = compileDelegationPlan(catalog, {
      profile: 'review',
      description: 'review change',
      prompt: 'Review the patch.',
    })

    expect(plan).toMatchObject({
      specialist: 'review',
      mode: 'foreground',
      subagentProvider: 'spawn',
      label: 'review change',
      prompt: 'Review the patch.',
      result: 'review-v1',
      maxDepth: 2,
      toolFilter: { deny: ['write'] },
      outputSchema: {
        type: 'object',
        required: ['verdict', 'summary', 'findings', 'verification'],
      },
    })
    expect(() => {
      plan.toolFilter!.deny!.push('edit')
    }).toThrow(TypeError)
    expect(catalog.activeSpecialists.review?.toolFilter?.deny).toEqual(['write'])
  })

  it('refuses a structured profile when invocation forces background execution', () => {
    const catalog = compileCatalog(base, spawn)
    expect(() => compileDelegationPlan(catalog, {
      profile: 'review',
      description: 'review change',
      prompt: 'Review the patch.',
      runInBackground: true,
    })).toThrow(/foreground-only result contract/)
  })

  it('compiles loaded prompt fragments into persona and resource-aware catalog identity', () => {
    const resourceConfig: Config = {
      ...base,
      resourceRoots: { local: 'resources' },
      maxResourceBytes: 65536,
      profiles: {
        quick: {
          ...base.profiles.quick!,
          promptFiles: [{ root: 'local', path: 'prompts/quick.md' }],
        },
      },
      defaultProfile: 'quick',
    }
    expect(() => compileCatalog(resourceConfig, spawn)).toThrow(/resource snapshot does not satisfy/)

    const first = compileCatalog(resourceConfig, spawn, createResourceSnapshot({
      quick: [{
        reference: 'local:prompts/quick.md',
        bytes: 5,
        utf8Bom: false,
        digest: promptContentDigest('First'),
        content: 'First',
      }],
    }))
    const second = compileCatalog(resourceConfig, spawn, createResourceSnapshot({
      quick: [{
        reference: 'local:prompts/quick.md',
        bytes: 6,
        utf8Bom: false,
        digest: promptContentDigest('Second'),
        content: 'Second',
      }],
    }))
    const plan = compileDelegationPlan(first, {
      description: 'resource task',
      prompt: 'Work.',
      runInBackground: false,
    })

    expect(first.policyDigest).toBe(second.policyDigest)
    expect(first.catalogDigest).not.toBe(second.catalogDigest)
    expect(first.resourceDigest).not.toBe(second.resourceDigest)
    expect(plan.persona).toContain('## Legion profile instruction: local:prompts/quick.md')
    expect(plan.persona).toContain('First')
    expect(plan.resourceDigest).toBe(first.resourceDigest)
    expect(plan.promptFragments[0]?.content).toBe('First')
    expect(Object.isFrozen(plan)).toBe(true)
    expect(Object.isFrozen(plan.promptFragments)).toBe(true)
    expect(Object.isFrozen(plan.promptFragments[0])).toBe(true)
  })

  it('requires provider system/persona composition for foreground prompt fragments', () => {
    const resourceConfig: Config = {
      ...base,
      resourceRoots: { local: 'resources' },
      profiles: {
        quick: {
          ...base.profiles.quick!,
          defaultRunInBackground: false,
          promptFiles: [{ root: 'local', path: 'quick.md' }],
        },
      },
    }
    const resources = createResourceSnapshot({
      quick: [{
        reference: 'local:quick.md',
        bytes: 5,
        utf8Bom: false,
        digest: promptContentDigest('Rules'),
        content: 'Rules',
      }],
    })
    const catalog = compileCatalog(resourceConfig, {
      providers: {
        spawn: {
          continuable: false,
          capabilities: { agentOptions: true, outputSchema: true, depthLimit: true, toolFilter: true, persona: false },
        },
      },
    }, resources)
    expect(catalog.diagnostics).toContainEqual(expect.objectContaining({
      code: 'PROFILE_PERSONA_UNSUPPORTED',
      severity: 'error',
      specialist: 'quick',
    }))

    const continuable = compileCatalog({
      ...resourceConfig,
      profiles: {
        quick: { ...resourceConfig.profiles.quick!, defaultRunInBackground: true },
      },
    }, {
      providers: {
        spawn: {
          continuable: true,
          capabilities: { agentOptions: true, outputSchema: true, depthLimit: true, toolFilter: true, persona: false },
        },
      },
    }, resources)
    expect(continuable.activeSpecialists.quick?.defaultMode).toBe('continuable')
    expect(continuable.activeSpecialists.quick?.allowedModes).toEqual(['continuable'])
  })

  it('uses explicit LLM adapter topology to activate routed profiles without inventing offline facts', () => {
    const profile = base.profiles.quick!
    const routed: Config = {
      ...base,
      profiles: {
        quick: {
          ...profile,
          routes: [{ id: 'exact', provider: 'models', model: 'model' }],
        },
      },
    }
    const offlineUnknown = compileCatalog(routed, spawn)
    expect(offlineUnknown.activeSpecialists.quick).toBeDefined()

    const missing = compileCatalog(routed, { ...spawn, llmProviders: [] })
    expect(missing.activeSpecialists.quick).toBeUndefined()
    expect(missing.diagnostics).toContainEqual(expect.objectContaining({
      code: 'PROFILE_LLM_ADAPTER_UNAVAILABLE',
      severity: 'warning',
      specialist: 'quick',
    }))

    const registered = compileCatalog(routed, { ...spawn, llmProviders: ['models'] })
    expect(registered.activeSpecialists.quick).toBeDefined()
    expect(registered.policyDigest).toBe(missing.policyDigest)
    expect(registered.catalogDigest).not.toBe(missing.catalogDigest)
  })

  it('requires foreground persona composition for route-specific instructions', () => {
    const profile = base.profiles.quick!
    const routed: Config = {
      ...base,
      profiles: {
        quick: {
          ...profile,
          routes: [{
            id: 'exact', provider: 'route', model: 'model', instructions: 'Route policy.',
          }],
          defaultRunInBackground: false,
        },
      },
    }
    const catalog = compileCatalog(routed, {
      providers: {
        spawn: {
          continuable: false,
          capabilities: { agentOptions: true, outputSchema: true, depthLimit: true, toolFilter: true, persona: false },
        },
      },
    })
    expect(catalog.diagnostics).toContainEqual(expect.objectContaining({
      code: 'PROFILE_PERSONA_UNSUPPORTED',
      specialist: 'quick',
    }))
  })

  it('changes only catalogDigest when provider runtime facts change', () => {
    const first = compileCatalog(base, spawn)
    const second = compileCatalog(base, {
      providers: {
        spawn: {
          capabilities: { agentOptions: true, outputSchema: true, depthLimit: true, toolFilter: true, persona: true },
          continuable: false,
        },
      },
    })

    expect(second.policyDigest).toBe(first.policyDigest)
    expect(second.catalogDigest).not.toBe(first.catalogDigest)
  })
})
