import {
  ArtifactName,
  CANONICAL_CONFIG_VERSION,
  CohortName,
  CohortRunId,
  MemberSlotName,
  ProfileName,
  SpecialistName,
  StrategyName,
  TeamName,
  TeamRunId,
  acpSpecialist,
  assertAcpSpecialistCompatible,
  defineCohort,
  defineStrategy,
  defineStrategyFor,
  defineTeam,
  exportCurrentConfigDocument,
  materializeCurrentConfigWithDiagnostics,
  type ArtifactName as ArtifactNameType,
  type CatalogDigest,
  type CatalogLayer,
  type CohortName as CohortNameType,
  type CohortRunId as CohortRunIdType,
  type CohortRunOutcome,
  type CompiledCatalog,
  type CompiledCohort,
  type CompiledSpecialistCatalog,
  type CompiledTeam,
  type ConfigDeprecationDiagnostic,
  type ConfigExportTarget,
  type ConfigVersion,
  type CurrentConfig,
  type DelegationInvocation,
  type DelegationPlan,
  type Diagnostic,
  type ErrorDiagnosticCode,
  type ExplainViewV1,
  type LegionConfig,
  type ProfileExplainView,
  type PolicyDigest,
  type ProfileName as ProfileNameType,
  type ResourceDigest,
  type RoutePlan,
  type RoutePlanDigest,
  type SpecialistName as SpecialistNameType,
  type SpecialistSpec,
  type StairStepPolicySpec,
  type StrategyName as StrategyNameType,
  type TeamName as TeamNameType,
  type TeamRunId as TeamRunIdType,
  type TeamRunOutcome,
  type WarningDiagnosticCode,
} from '../src/index.ts'

type Equal<Left, Right> =
  (<Value>() => Value extends Left ? 1 : 2) extends
  (<Value>() => Value extends Right ? 1 : 2) ? true : false
type Assert<Value extends true> = Value

export type CatalogPolicyDigestContract = Assert<Equal<CompiledCatalog['policyDigest'], PolicyDigest>>
export type PlanCatalogDigestContract = Assert<Equal<DelegationPlan['catalogDigest'], CatalogDigest>>
export type PlanResourceDigestContract = Assert<Equal<DelegationPlan['resourceDigest'], ResourceDigest>>

const config: LegionConfig = {
  toolName: 'legion',
  enableRunInBackground: true,
  defaultProfile: 'quick',
  profiles: {
    quick: {
      description: 'Fast work.',
      subagentProvider: 'spawn',
      maxDepth: 2,
      defaultRunInBackground: true,
    },
  },
}

const routedConfig: LegionConfig = {
  toolName: 'legion',
  enableRunInBackground: true,
  profiles: {
    deep: {
      description: 'Deep work.',
      subagentProvider: 'spawn',
      routes: [{
        id: 'strong',
        provider: 'provider',
        model: 'model',
        constraints: { minContextTokens: 64_000, minEffectiveOutputTokens: 8192 },
      }],
      maxDepth: 2,
      defaultRunInBackground: false,
    },
  },
}

const currentNounConfig: CurrentConfig = {
  configVersion: 3,
  toolName: 'legion',
  enableRunInBackground: true,
  defaultSpecialist: 'deep',
  specialists: routedConfig.profiles,
  cohorts: {
    coding: { description: 'Coding.', members: { executor: { specialist: 'deep' } } },
  },
}
const currentLayer: CatalogLayer<(typeof currentNounConfig.specialists)['deep']> = {
  id: 'current',
  specialists: currentNounConfig.specialists,
  cohorts: currentNounConfig.cohorts!,
  disable: { specialists: ['unused'], cohorts: ['unused'] },
}
const invalidCurrentMember: NonNullable<CurrentConfig['cohorts']> = {
  invalid: {
    description: 'Invalid.',
    members: {
      worker: {
        // @ts-expect-error Current v3 Member Slots use specialist.
        profile: 'deep',
      },
    },
  },
}
const invalidCurrentLayer: CatalogLayer<SpecialistSpecForTypeTest> = {
  id: 'invalid',
  disable: {
    // @ts-expect-error Current Catalog Layers use specialists.
    profiles: ['legacy'],
  },
}
type SpecialistSpecForTypeTest = (typeof currentNounConfig.specialists)['deep']
const currentVersion: ConfigVersion = 3
const currentTarget: ConfigExportTarget = 3
const migrationDiagnostic: ConfigDeprecationDiagnostic = {
  code: 'LEGION_CONFIG_KEY_DEPRECATED',
  severity: 'warning',
  path: 'config.defaultProfile',
  replacement: 'config.defaultSpecialist',
  removalVersion: '2.0.0',
  message: 'deprecated',
}

const invocation: DelegationInvocation = {
  profile: 'quick',
  description: 'fast work',
  prompt: 'Work.',
}

const specialist: SpecialistNameType = SpecialistName('quick')
const cohort: CohortNameType = CohortName('coding')
const cohortRun: CohortRunIdType = CohortRunId('team-run-123e4567-e89b-42d3-a456-426614174000')
const profile: ProfileNameType = ProfileName('quick')
const team: TeamNameType = TeamName('coding')
const strategy: StrategyNameType = StrategyName('independent-review')
const artifact: ArtifactNameType = ArtifactName('evidence')
const member = MemberSlotName('executor')
const teamRun: TeamRunIdType = TeamRunId('team-run-123e4567-e89b-42d3-a456-426614174000')
const profileAsString: string = profile
const currentMaterialized = materializeCurrentConfigWithDiagnostics(currentNounConfig)
const currentExport = exportCurrentConfigDocument(currentNounConfig)
const acpSpecialistConfig: SpecialistSpec = acpSpecialist({
  id: 'codex',
  title: 'Codex',
  description: 'Delegate to Codex.',
  command: 'codex-acp',
  entrypoint: 'verified',
})
assertAcpSpecialistCompatible('codex', acpSpecialistConfig)
const canonicalVersion: typeof CANONICAL_CONFIG_VERSION = currentExport.configVersion
export type CompiledCatalogAliasContract = Assert<Equal<CompiledCatalog, CompiledSpecialistCatalog>>
export type CompiledCohortAliasContract = Assert<Equal<CompiledTeam, CompiledCohort>>
export type CohortRunAliasContract = Assert<Equal<TeamRunOutcome, CohortRunOutcome>>
void config
void routedConfig
void currentNounConfig
void currentLayer
void invalidCurrentMember
void invalidCurrentLayer
void currentVersion
void currentTarget
void migrationDiagnostic
void invocation
void profileAsString
void specialist
void cohort
void cohortRun
void currentMaterialized
void currentExport
void acpSpecialistConfig
void canonicalVersion
void defineCohort
void team
void strategy
void artifact
void member
void teamRun

declare const policy: PolicyDigest
declare const catalog: CatalogDigest
declare const resource: ResourceDigest
const policyAsString: string = policy
const catalogAsString: string = catalog
const resourceAsString: string = resource
void policyAsString
void catalogAsString
void resourceAsString

// @ts-expect-error TeamRunId and TeamName are distinct identities.
const teamFromRun: TeamNameType = teamRun
void teamFromRun

// @ts-expect-error CatalogDigest and PolicyDigest are distinct identities.
const wrongPolicy: PolicyDigest = catalog
// @ts-expect-error ResourceDigest and CatalogDigest are distinct identities.
const wrongCatalog: CatalogDigest = resource
// @ts-expect-error Plain strings have not crossed the checked digest constructor.
const uncheckedPolicy: PolicyDigest = 'sha256:deadbeef'
// @ts-expect-error Plain strings have not crossed the checked profile constructor.
const uncheckedProfile: ProfileNameType = 'quick'
// @ts-expect-error Team and Strategy identities are not interchangeable.
const wrongTeam: TeamNameType = strategy
// @ts-expect-error Artifact and Team identities are not interchangeable.
const wrongArtifact: ArtifactNameType = team
void wrongPolicy
void wrongCatalog
void uncheckedPolicy
void uncheckedProfile
void wrongTeam
void wrongArtifact

// @ts-expect-error Error diagnostic codes cannot carry warning severity.
const invalidDiagnostic: Diagnostic = {
  code: 'PROFILE_DEPTH_UNSUPPORTED',
  severity: 'warning',
  message: 'invalid',
  profile,
}
void invalidDiagnostic

const invalidReasoningConfig: LegionConfig = {
  ...routedConfig,
  profiles: {
    deep: {
      ...routedConfig.profiles.deep!,
      routes: [{
        id: 'invalid',
        provider: 'provider',
        model: 'model',
        constraints: {
          // @ts-expect-error Reasoning constraints wait for an upstream per-child effort override seam.
          reasoning: 'forbidden',
        },
      }],
    },
  },
}
void invalidReasoningConfig

const stairStepPolicy: StairStepPolicySpec = {
  kind: 'stair-step',
  plannerMember: 'executor',
  verifierMember: 'reviewer',
  advancement: 'continuous',
  pauseOn: ['verification-failure', 'no-progress'],
}
void stairStepPolicy

const typedStrategy = defineStrategy({
  description: 'Typed pipeline.',
  cohort: 'coding',
  stages: [
    {
      kind: 'delegate',
      id: 'execute',
      member: 'executor',
      inputs: [{ artifact: 'objective', contract: 'objective-v1' }],
      output: { artifact: 'evidence', contract: 'text' },
      prompt: 'Execute.',
    },
    {
      kind: 'delegate',
      id: 'review',
      member: 'reviewer',
      inputs: [{ artifact: 'evidence', contract: 'text' }],
      output: { artifact: 'review', contract: 'review-v1' },
      prompt: 'Review.',
    },
  ],
  completion: { artifact: 'review', contract: 'review-v1' },
  limits: {
    maxAgents: 2,
    maxConcurrent: 1,
    deadlineMs: 60_000,
    maxOutputBytes: 64_000,
  },
  memberFailure: 'fail',
})
void typedStrategy
const codingTeam = defineTeam('coding', {
  description: 'Coding.',
  members: {
    executor: { specialist: 'deep' },
    reviewer: { specialist: 'review' },
  },
})
defineStrategyFor(codingTeam, typedStrategy)

// @ts-expect-error A Strategy member must name a slot in its typed Team.
defineStrategyFor(codingTeam, {
  ...typedStrategy,
  stages: [{ ...typedStrategy.stages[0], member: 'missing' }],
})

// @ts-expect-error A stage cannot consume an artifact produced by a later stage.
defineStrategy({
  description: 'Invalid forward reference.',
  cohort: 'coding',
  stages: [{
    kind: 'delegate',
    id: 'first',
    member: 'executor',
    inputs: [{ artifact: 'future', contract: 'text' }],
    output: { artifact: 'result', contract: 'text' },
    prompt: 'Invalid.',
  }],
  completion: { artifact: 'result', contract: 'text' },
  limits: {
    maxAgents: 1,
    maxConcurrent: 1,
    deadlineMs: 60_000,
    maxOutputBytes: 64_000,
  },
  memberFailure: 'fail',
})

// @ts-expect-error Artifact contracts must match the previously produced artifact.
defineStrategy({
  ...typedStrategy,
  stages: [
    typedStrategy.stages[0],
    {
      ...typedStrategy.stages[1],
      inputs: [{ artifact: 'evidence', contract: 'review-v1' }],
    },
  ],
})

const requiredSlotsTeam = defineTeam('required-slots', {
  description: 'Required slots.',
  members: {
    first: { specialist: 'deep', minParticipants: 1 },
    second: { specialist: 'review', minParticipants: 1 },
  },
})
// @ts-expect-error A typed Strategy must cover every Team slot with positive minimum participation.
defineStrategyFor(requiredSlotsTeam, {
  description: 'Misses a required slot.', team: 'required-slots',
  stages: [{
    kind: 'delegate', id: 'first', member: 'first',
    inputs: [{ artifact: 'objective', contract: 'objective-v1' }],
    output: { artifact: 'result', contract: 'text' }, prompt: 'Run first.',
  }],
  completion: { artifact: 'result', contract: 'text' },
  limits: { maxAgents: 1, maxConcurrent: 1, deadlineMs: 60_000, maxOutputBytes: 64_000 },
  memberFailure: 'fail',
})

// @ts-expect-error Completion must reference an existing single artifact with the same contract.
defineStrategy({
  ...typedStrategy,
  completion: { artifact: 'review', contract: 'text' },
})

// @ts-expect-error Active profiles must expose at least one allowed mode.
const invalidActiveProfile: ProfileExplainView = {
  kind: 'active-profile',
  name: profile,
  subagentProvider: 'spawn',
  description: 'invalid',
  defaultMode: 'foreground',
  allowedModes: [],
  resultContract: 'text',
  route: {},
}
void invalidActiveProfile

declare const explain: ExplainViewV1
const explainPolicy: PolicyDigest = explain.policyDigest
void explainPolicy

export function routePlanIdentity(plan: RoutePlan): RoutePlanDigest {
  if (plan.kind === 'selected-route-plan') {
    const selectedId: string = plan.selected.id
    void selectedId
  }
  return plan.planDigest
}

export function outcomeKind(outcome: TeamRunOutcome): TeamRunOutcome['kind'] {
  switch (outcome.kind) {
    case 'completed': return outcome.kind
    case 'degraded': return outcome.kind
    case 'cancelled': return outcome.kind
    case 'failed': return outcome.kind
    default: {
      const neverOutcome: never = outcome
      return neverOutcome
    }
  }
}

export function diagnosticCodeClass(diagnostic: Diagnostic): WarningDiagnosticCode | ErrorDiagnosticCode {
  if (diagnostic.severity === 'warning') {
    const warning: WarningDiagnosticCode = diagnostic.code
    return warning
  }
  const error: ErrorDiagnosticCode = diagnostic.code
  return error
}
