import type { CompiledSpecialistCatalog, EffectiveSpecialist } from './compiler.ts'
import { deepFreeze, sha256Digest } from './internal/value.ts'
import type {
  ArtifactContract,
  StrategyLimits,
  StrategySpec,
  StairStepPolicySpec,
  StrategyStageSpec,
  CohortSpec,
} from './orchestration-contract.ts'
import {
  ArtifactName,
  MemberSlotName,
  StrategyGenerationId,
  StrategyName,
  StrategyPlanDigest,
  CohortName,
  type ArtifactName as ArtifactNameType,
  type MemberSlotName as MemberSlotNameType,
  type SpecialistName,
  type StrategyGenerationId as StrategyGenerationIdType,
  type StrategyName as StrategyNameType,
  type StrategyPlanDigest as StrategyPlanDigestType,
  type CohortName as CohortNameType,
} from './identity.ts'

export type OrchestrationDiagnosticCode =
  | 'TEAM_EMPTY'
  | 'TEAM_PROFILE_UNKNOWN'
  | 'TEAM_PROFILE_INACTIVE'
  | 'TEAM_SLOT_MIN_EXCEEDS_MAX'
  | 'TEAM_MEMBER_LIMIT_EXCEEDED'
  | 'TEAM_CONCURRENCY_LIMIT_EXCEEDED'
  | 'STRATEGY_TEAM_UNKNOWN'
  | 'STRATEGY_STAGE_DUPLICATE'
  | 'STRATEGY_STAGE_DEPENDENCY_DUPLICATE'
  | 'STRATEGY_STAGE_DEPENDENCY_UNKNOWN'
  | 'STRATEGY_STAGE_DEPENDENCY_SELF'
  | 'STRATEGY_STAGE_DEPENDENCY_CYCLE'
  | 'STRATEGY_ADVANCEMENT_MEMBER_UNKNOWN'
  | 'STRATEGY_ADVANCEMENT_LIMIT_INVALID'
  | 'STRATEGY_ADVANCEMENT_PAUSE_DUPLICATE'
  | 'STRATEGY_MEMBER_UNKNOWN'
  | 'STRATEGY_MEMBER_CARDINALITY_UNSATISFIED'
  | 'STRATEGY_ARTIFACT_UNKNOWN'
  | 'STRATEGY_ARTIFACT_FORWARD_REFERENCE'
  | 'STRATEGY_ARTIFACT_DUPLICATE'
  | 'STRATEGY_ARTIFACT_CONTRACT_MISMATCH'
  | 'STRATEGY_OBJECTIVE_INVALID'
  | 'STRATEGY_ARTIFACT_AVAILABILITY_MISMATCH'
  | 'STRATEGY_PROFILE_RESULT_MISMATCH'
  | 'STRATEGY_CONTINUABLE_ARTIFACT_UNSUPPORTED'
  | 'STRATEGY_COMPLETION_UNKNOWN_ARTIFACT'
  | 'STRATEGY_COMPLETION_CONTRACT_MISMATCH'
  | 'STRATEGY_AGENT_LIMIT_EXCEEDED'
  | 'STRATEGY_CONCURRENCY_LIMIT_EXCEEDED'
  | 'STRATEGY_UNUSED_ARTIFACT'
  | 'STRATEGY_PARTIAL_POLICY_UNUSED'
  | 'STRATEGY_PARTIAL_POLICY_CONFLICT'
  | 'STRATEGY_LIMIT_WIDENING'
  | 'STRATEGY_LIMIT_UNSATISFIABLE'
  | 'STRATEGY_REQUEST_INVALID'
  | 'STRATEGY_UNKNOWN'

export interface OrchestrationDiagnostic {
  readonly code: OrchestrationDiagnosticCode
  readonly severity: 'warning' | 'error'
  readonly message: string
  readonly team?: string
  readonly strategy?: string
  readonly stage?: string
}

export interface CompiledMemberSlot {
  readonly name: MemberSlotNameType
  readonly specialist: SpecialistName
  readonly minParticipants: number
  readonly maxParticipants: number
  readonly tags: readonly string[]
  readonly active: boolean
}

export interface CompiledCohort {
  readonly name: CohortNameType
  readonly description: string
  readonly members: Readonly<Record<string, CompiledMemberSlot>>
  readonly maxMembers: number
  readonly maxConcurrentMembers: number
}
/** @deprecated Use CompiledCohort. */
export type CompiledTeam = CompiledCohort

export type ArtifactAvailability = 'required' | 'degraded' | 'optional'

export interface CompiledArtifact {
  readonly name: ArtifactNameType
  readonly contract: ArtifactContract
  readonly collection: boolean
  readonly availability: ArtifactAvailability
  readonly producer?: string
}

/** Non-enumerable compatibility read used only by the frozen durable V1 adapter. */
interface DurablePrimitiveV1Compatibility {
  readonly profile: SpecialistName
}

interface PrimitiveBase extends DurablePrimitiveV1Compatibility {
  readonly stage: string
  readonly member: MemberSlotNameType
  readonly specialist: SpecialistName
  readonly inputs: readonly ArtifactNameType[]
  readonly output: CompiledArtifact
  readonly prompt: string
  readonly after: readonly string[]
}

export interface DelegatePrimitive extends PrimitiveBase {
  readonly kind: 'dsh-delegate'
  readonly mode: 'foreground' | 'continuable'
}

export interface FanoutPrimitive extends PrimitiveBase {
  readonly kind: 'dsh-subagent-fanout'
  readonly count: number
  readonly minSuccess: number
  readonly allowDegraded: boolean
}

export type DshPrimitive = DelegatePrimitive | FanoutPrimitive

function durableCompatiblePrimitive<Value extends { readonly specialist: SpecialistName }>(
  value: Value,
): Value & DurablePrimitiveV1Compatibility {
  const primitive = { ...value } as Value & DurablePrimitiveV1Compatibility
  Object.defineProperty(primitive, 'profile', {
    value: value.specialist,
    enumerable: false,
    configurable: false,
    writable: false,
  })
  return deepFreeze(primitive)
}

function serializeLegacyPrimitives(primitives: readonly DshPrimitive[]): readonly Record<string, unknown>[] {
  return primitives.map(primitive => primitive.kind === 'dsh-subagent-fanout'
    ? {
        kind: primitive.kind,
        stage: primitive.stage,
        member: primitive.member,
        profile: primitive.specialist,
        inputs: primitive.inputs,
        output: primitive.output,
        prompt: primitive.prompt,
        count: primitive.count,
        minSuccess: primitive.minSuccess,
        allowDegraded: primitive.allowDegraded,
        after: primitive.after,
      }
    : {
        kind: primitive.kind,
        stage: primitive.stage,
        member: primitive.member,
        profile: primitive.specialist,
        inputs: primitive.inputs,
        output: primitive.output,
        prompt: primitive.prompt,
        mode: primitive.mode,
        after: primitive.after,
      })
}

export interface CompiledStrategyTemplate {
  readonly name: StrategyNameType
  readonly description: string
  readonly cohort: CohortNameType
  readonly primitives: readonly DshPrimitive[]
  readonly artifacts: Readonly<Record<string, CompiledArtifact>>
  readonly completion: {
    readonly artifact: ArtifactNameType
    readonly contract: ArtifactContract
  }
  readonly advancement?: Readonly<Required<StairStepPolicySpec>>
  readonly limits: Readonly<StrategyLimits>
  readonly memberFailure: 'fail' | 'allow-partial'
  readonly active: boolean
}

export class OrchestrationCompileError extends Error {
  readonly diagnostics: readonly OrchestrationDiagnostic[]

  constructor(diagnostics: readonly OrchestrationDiagnostic[]) {
    super(
      'dsh-legion: invalid orchestration catalog: '
      + diagnostics.filter(item => item.severity === 'error').map(item => `${item.code}: ${item.message}`).join('; '),
    )
    this.name = 'OrchestrationCompileError'
    this.diagnostics = diagnostics.map(item => ({ ...item }))
  }
}

export interface CompiledOrchestrationCatalog {
  readonly cohorts: Readonly<Record<string, CompiledCohort>>
  readonly strategies: Readonly<Record<string, CompiledStrategyTemplate>>
  readonly diagnostics: readonly OrchestrationDiagnostic[]
  readonly digest: `sha256:${string}`
  readonly generationId: StrategyGenerationIdType
  readonly specialistPolicyDigest: string
  readonly specialistCatalogDigest: string
}

export interface StrategyCompileRequest {
  readonly strategy: string
  readonly objective: string
  readonly limits?: Partial<StrategyLimits>
}

declare const compiledStrategyPlanBrand: unique symbol
const compiledStrategyPlansKey = Symbol.for('dsh-legion.compiled-strategy-plans.v1')
const globalRegistry = globalThis as unknown as Record<PropertyKey, unknown>
const existingCompiledStrategyPlans = globalRegistry[compiledStrategyPlansKey]
const compiledStrategyPlans = existingCompiledStrategyPlans instanceof WeakSet
  ? existingCompiledStrategyPlans as WeakSet<object>
  : new WeakSet<object>()
globalRegistry[compiledStrategyPlansKey] = compiledStrategyPlans

/** Non-enumerable compatibility read used only by the frozen durable V1 adapter. */
interface DurablePlanV1Compatibility {
  readonly team: CohortNameType
}

export interface CompiledStrategyPlan extends DurablePlanV1Compatibility {
  readonly [compiledStrategyPlanBrand]: true
  readonly kind: 'compiled-strategy-plan'
  readonly strategy: StrategyNameType
  readonly cohort: CohortNameType
  readonly objective: string
  readonly objectiveDigest: `sha256:${string}`
  readonly generationId: StrategyGenerationIdType
  readonly planDigest: StrategyPlanDigestType
  readonly primitives: readonly DshPrimitive[]
  readonly artifacts: Readonly<Record<string, CompiledArtifact>>
  readonly completion: CompiledStrategyTemplate['completion']
  readonly advancement?: CompiledStrategyTemplate['advancement']
  readonly limits: Readonly<StrategyLimits>
  readonly memberFailure: 'fail' | 'allow-partial'
}

export type StrategyCompileResult =
  | {
      readonly ok: true
      readonly plan: CompiledStrategyPlan
      readonly diagnostics: readonly OrchestrationDiagnostic[]
    }
  | {
      readonly ok: false
      readonly diagnostics: readonly OrchestrationDiagnostic[]
    }

function push(
  diagnostics: OrchestrationDiagnostic[],
  code: OrchestrationDiagnosticCode,
  severity: 'warning' | 'error',
  message: string,
  location: { team?: string; strategy?: string; stage?: string } = {},
): void {
  diagnostics.push({ code, severity, message, ...location })
}

function compiledCohort(
  name: string,
  spec: CohortSpec,
  profiles: CompiledSpecialistCatalog,
  diagnostics: OrchestrationDiagnostic[],
): CompiledCohort | undefined {
  const startErrors = diagnostics.length
  const members: Record<string, CompiledMemberSlot> = {}
  const entries = Object.entries(spec.members).sort(([left], [right]) => left.localeCompare(right))
  if (entries.length === 0) push(diagnostics, 'TEAM_EMPTY', 'error', `Cohort "${name}" has no members`, { team: name })
  let sumMin = 0
  let sumMax = 0
  for (const [slot, authored] of entries) {
    let profile: EffectiveSpecialist | undefined = profiles.specialists[authored.specialist]
    if (profile === undefined) {
      push(
        diagnostics,
        'TEAM_PROFILE_UNKNOWN',
        'error',
        `Cohort "${name}" member "${slot}" references unknown Specialist "${authored.specialist}"`,
        { team: name },
      )
      continue
    }
    const min = authored.minParticipants ?? 1
    const max = authored.maxParticipants ?? 1
    if (min > max) {
      push(
        diagnostics,
        'TEAM_SLOT_MIN_EXCEEDS_MAX',
        'error',
        `Cohort "${name}" member "${slot}" minParticipants exceeds maxParticipants`,
        { team: name },
      )
      continue
    }
    if (!profile.active) {
      push(
        diagnostics,
        'TEAM_PROFILE_INACTIVE',
        'warning',
        `Cohort "${name}" member "${slot}" currently uses inactive Specialist "${authored.specialist}"`,
        { team: name },
      )
    }
    sumMin += min
    sumMax += max
    members[slot] = deepFreeze({
      name: MemberSlotName(slot),
      specialist: profile.name,
      minParticipants: min,
      maxParticipants: max,
      tags: [...new Set(authored.tags ?? [])].sort(),
      active: profile.active,
    })
  }
  const maxMembers = spec.limits?.maxMembers ?? sumMax
  const maxConcurrentMembers = spec.limits?.maxConcurrentMembers ?? maxMembers
  if (sumMax > 16 || maxMembers < sumMin || maxMembers > 16) {
    push(
      diagnostics,
      'TEAM_MEMBER_LIMIT_EXCEEDED',
      'error',
      `Cohort "${name}" maxMembers must contain required members and stay within the compiler ceiling`,
      { team: name },
    )
  }
  if (maxConcurrentMembers > maxMembers) {
    push(
      diagnostics,
      'TEAM_CONCURRENCY_LIMIT_EXCEEDED',
      'error',
      `Cohort "${name}" maxConcurrentMembers exceeds maxMembers`,
      { team: name },
    )
  }
  if (diagnostics.slice(startErrors).some(item => item.severity === 'error')) return undefined
  return deepFreeze({
    name: CohortName(name),
    description: spec.description,
    members,
    maxMembers,
    maxConcurrentMembers,
  })
}

function stageOutput(
  stage: StrategyStageSpec,
  availability: ArtifactAvailability,
): CompiledArtifact {
  return deepFreeze({
    name: ArtifactName(stage.output.artifact),
    contract: stage.output.contract,
    collection: stage.kind === 'fanout',
    availability,
    producer: stage.id,
  })
}

function expectedAgentCount(stage: StrategyStageSpec): number {
  return stage.kind === 'fanout' ? stage.count : 1
}


function hasStrategyDependencyCycle(spec: StrategySpec): boolean {
  const ids = spec.stages.map(stage => stage.id)
  const known = new Set(ids)
  const outgoing = new Map(ids.map(id => [id, new Set<string>()]))
  const indegree = new Map(ids.map(id => [id, 0]))
  const producerByArtifact = new Map(
    spec.stages.map(stage => [stage.output.artifact, stage.id]),
  )
  const addEdge = (from: string, to: string): void => {
    if (!known.has(from) || !known.has(to) || outgoing.get(from)?.has(to)) return
    outgoing.get(from)?.add(to)
    indegree.set(to, (indegree.get(to) ?? 0) + 1)
  }
  for (const stage of spec.stages) {
    for (const dependency of stage.after ?? []) addEdge(dependency, stage.id)
    for (const input of stage.inputs) {
      const producer = producerByArtifact.get(input.artifact)
      if (producer !== undefined) addEdge(producer, stage.id)
    }
  }
  const ready = ids.filter(id => indegree.get(id) === 0).sort()
  let visited = 0
  while (ready.length > 0) {
    const id = ready.shift()!
    visited += 1
    for (const successor of outgoing.get(id) ?? []) {
      const remaining = (indegree.get(successor) ?? 0) - 1
      indegree.set(successor, remaining)
      if (remaining === 0) {
        ready.push(successor)
        ready.sort()
      }
    }
  }
  return visited !== ids.length
}

function compileStrategyTemplate(
  name: string,
  spec: StrategySpec,
  team: CompiledCohort | undefined,
  profiles: CompiledSpecialistCatalog,
  diagnostics: OrchestrationDiagnostic[],
): CompiledStrategyTemplate | undefined {
  const startErrors = diagnostics.length
  if (team === undefined) {
    push(
      diagnostics,
      'STRATEGY_TEAM_UNKNOWN',
      'error',
      `Strategy "${name}" references unavailable Cohort "${spec.cohort}"`,
      { strategy: name },
    )
    return undefined
  }
  if (spec.advancement !== undefined) {
    if (team.members[spec.advancement.plannerMember] === undefined) {
      push(
        diagnostics,
        'STRATEGY_ADVANCEMENT_MEMBER_UNKNOWN',
        'error',
        `strategy "${name}" advancement references unavailable planner member "${spec.advancement.plannerMember}"`,
        { strategy: name },
      )
    }
    if (team.members[spec.advancement.verifierMember] === undefined) {
      push(
        diagnostics,
        'STRATEGY_ADVANCEMENT_MEMBER_UNKNOWN',
        'error',
        `strategy "${name}" advancement references unavailable verifier member "${spec.advancement.verifierMember}"`,
        { strategy: name },
      )
    }
    if (spec.advancement.maxNoProgressMilestones! > spec.advancement.maxMilestones!) {
      push(
        diagnostics,
        'STRATEGY_ADVANCEMENT_LIMIT_INVALID',
        'error',
        `strategy "${name}" maxNoProgressMilestones exceeds maxMilestones`,
        { strategy: name },
      )
    }
    if (new Set(spec.advancement.pauseOn).size !== spec.advancement.pauseOn!.length) {
      push(
        diagnostics,
        'STRATEGY_ADVANCEMENT_PAUSE_DUPLICATE',
        'error',
        `strategy "${name}" advancement pauseOn contains duplicate reasons`,
        { strategy: name },
      )
    }
  }
  if (hasStrategyDependencyCycle(spec)) {
    push(
      diagnostics,
      'STRATEGY_STAGE_DEPENDENCY_CYCLE',
      'error',
      `strategy "${name}" contains a dependency cycle`,
      { strategy: name },
    )
  }
  const effectiveLimits: StrategyLimits = {
    ...spec.limits,
    maxConcurrent: Math.min(
      spec.limits.maxConcurrent,
      spec.limits.maxAgents,
      team.maxConcurrentMembers,
    ),
  }
  const allOutputs = new Map(spec.stages.map((stage, index) => [stage.output.artifact, index]))
  const allStageIds = new Set(spec.stages.map(stage => stage.id))
  const artifacts: Record<string, CompiledArtifact> = {
    objective: deepFreeze({
      name: ArtifactName('objective'),
      contract: 'objective-v1',
      collection: false,
      availability: 'required',
    }),
  }
  const stageIds = new Set<string>()
  const primitives: DshPrimitive[] = []
  const memberDemand = new Map(Object.keys(team.members).map(member => [member, 0]))
  let agents = 0
  let largestParallel = 1
  let hasDegraded = false
  for (const [index, stage] of spec.stages.entries()) {
    const location = { strategy: name, stage: stage.id }
    const stageDiagnosticStart = diagnostics.length
    if (stageIds.has(stage.id)) {
      push(diagnostics, 'STRATEGY_STAGE_DUPLICATE', 'error', `strategy "${name}" repeats stage "${stage.id}"`, location)
      continue
    }
    stageIds.add(stage.id)
    const after = [...(stage.after ?? [])].sort()
    if (new Set(after).size !== after.length) {
      push(diagnostics, 'STRATEGY_STAGE_DEPENDENCY_DUPLICATE', 'error', `strategy "${name}" stage "${stage.id}" repeats an after dependency`, location)
    }
    for (const dependency of after) {
      if (dependency === stage.id) {
        push(diagnostics, 'STRATEGY_STAGE_DEPENDENCY_SELF', 'error', `strategy "${name}" stage "${stage.id}" cannot depend on itself`, location)
      } else if (!allStageIds.has(dependency)) {
        push(diagnostics, 'STRATEGY_STAGE_DEPENDENCY_UNKNOWN', 'error', `strategy "${name}" stage "${stage.id}" references unknown stage "${dependency}"`, location)
      }
    }
    const member = team.members[stage.member]
    if (member === undefined) {
      push(
        diagnostics,
        'STRATEGY_MEMBER_UNKNOWN',
        'error',
        `strategy "${name}" stage "${stage.id}" references unknown member "${stage.member}"`,
        location,
      )
      continue
    }
    const inputNames: ArtifactNameType[] = []
    for (const input of stage.inputs) {
      const artifact = artifacts[input.artifact]
      if (artifact === undefined) {
        const producerIndex = allOutputs.get(input.artifact)
        push(
          diagnostics,
          producerIndex !== undefined && producerIndex > index
            ? 'STRATEGY_ARTIFACT_FORWARD_REFERENCE'
            : 'STRATEGY_ARTIFACT_UNKNOWN',
          'error',
          `strategy "${name}" stage "${stage.id}" cannot consume artifact "${input.artifact}"`,
          location,
        )
        continue
      }
      if (artifact.contract !== input.contract
        || artifact.collection !== (input.collection ?? false)) {
        push(
          diagnostics,
          'STRATEGY_ARTIFACT_CONTRACT_MISMATCH',
          'error',
          `strategy "${name}" stage "${stage.id}" input "${input.artifact}" has incompatible contract or cardinality`,
          location,
        )
      }
      if (artifact.availability === 'degraded' && input.optional !== true
        || artifact.availability === 'required' && input.optional === true) {
        push(
          diagnostics,
          'STRATEGY_ARTIFACT_AVAILABILITY_MISMATCH',
          'error',
          `strategy "${name}" stage "${stage.id}" optionality disagrees with artifact "${input.artifact}" availability`,
          location,
        )
      }
      inputNames.push(artifact.name)
    }
    if (artifacts[stage.output.artifact] !== undefined) {
      push(
        diagnostics,
        'STRATEGY_ARTIFACT_DUPLICATE',
        'error',
        `strategy "${name}" repeats artifact "${stage.output.artifact}"`,
        location,
      )
      continue
    }
    const profile = profiles.specialists[member.specialist]
    if (profile === undefined || profile.result !== stage.output.contract) {
      push(
        diagnostics,
        'STRATEGY_PROFILE_RESULT_MISMATCH',
        'error',
        `Strategy "${name}" stage "${stage.id}" output ${stage.output.contract} does not match Specialist "${member.specialist}" result`,
        location,
      )
    }
    if (stage.kind === 'delegate' && stage.mode === 'continuable') {
      push(
        diagnostics,
        'STRATEGY_CONTINUABLE_ARTIFACT_UNSUPPORTED',
        'error',
        `strategy "${name}" stage "${stage.id}" cannot await a continuable artifact`,
        location,
      )
    }
    if (stage.kind !== 'fanout' && member.minParticipants > 1) {
      push(
        diagnostics,
        'STRATEGY_MEMBER_CARDINALITY_UNSATISFIED',
        'error',
        `strategy "${name}" stage "${stage.id}" selects one participant from a multi-participant slot`,
        location,
      )
    }
    if (stage.kind === 'fanout') {
      if (stage.count > member.maxParticipants || stage.count < member.minParticipants) {
        push(
          diagnostics,
          'STRATEGY_MEMBER_CARDINALITY_UNSATISFIED',
          'error',
          `strategy "${name}" stage "${stage.id}" fanout count is outside member capacity`,
          location,
        )
      }
      if (stage.minSuccess > stage.count || !stage.allowDegraded && stage.minSuccess !== stage.count) {
        push(
          diagnostics,
          'STRATEGY_MEMBER_CARDINALITY_UNSATISFIED',
          'error',
          `strategy "${name}" stage "${stage.id}" has invalid minSuccess`,
          location,
        )
      }
      largestParallel = Math.max(largestParallel, stage.count)
      hasDegraded ||= stage.allowDegraded && stage.minSuccess < stage.count
    }
    if (diagnostics.slice(stageDiagnosticStart).some(item => item.severity === 'error')) continue
    memberDemand.set(
      stage.member,
      Math.max(memberDemand.get(stage.member) ?? 0, expectedAgentCount(stage)),
    )
    const availability: ArtifactAvailability = stage.kind === 'fanout'
      && stage.allowDegraded
      && stage.minSuccess < stage.count
      ? 'degraded'
      : 'required'
    const output = stageOutput(stage, availability)
    artifacts[stage.output.artifact] = output
    agents += expectedAgentCount(stage)
    if (stage.kind === 'fanout') {
      primitives.push(durableCompatiblePrimitive({
        kind: 'dsh-subagent-fanout',
        stage: stage.id,
        member: member.name,
        specialist: member.specialist,
        inputs: inputNames,
        output,
        prompt: stage.prompt,
        count: stage.count,
        minSuccess: stage.minSuccess,
        allowDegraded: stage.allowDegraded,
        after,
      }))
    } else {
      primitives.push(durableCompatiblePrimitive({
        kind: 'dsh-delegate',
        stage: stage.id,
        member: member.name,
        specialist: member.specialist,
        inputs: inputNames,
        output,
        prompt: stage.prompt,
        mode: stage.kind === 'delegate' ? stage.mode ?? 'foreground' : 'foreground',
        after,
      }))
    }
  }
  for (const member of Object.values(team.members)) {
    if ((memberDemand.get(String(member.name)) ?? 0) < member.minParticipants) {
      push(
        diagnostics,
        'STRATEGY_MEMBER_CARDINALITY_UNSATISFIED',
        'error',
        `strategy "${name}" does not satisfy required participation for member "${member.name}"`,
        { strategy: name },
      )
    }
  }
  const participatingMembers = [...memberDemand.values()].reduce((total, demand) => total + demand, 0)
  if (participatingMembers > team.maxMembers) {
    push(
      diagnostics,
      'STRATEGY_MEMBER_CARDINALITY_UNSATISFIED',
      'error',
      `Strategy "${name}" requires ${String(participatingMembers)} Cohort participants but maxMembers is ${String(team.maxMembers)}`,
      { strategy: name },
    )
  }
  if (agents > spec.limits.maxAgents) {
    push(
      diagnostics,
      'STRATEGY_AGENT_LIMIT_EXCEEDED',
      'error',
      `strategy "${name}" worst-case agents ${String(agents)} exceeds a hard limit`,
      { strategy: name },
    )
  }
  if (largestParallel > effectiveLimits.maxConcurrent) {
    push(
      diagnostics,
      'STRATEGY_CONCURRENCY_LIMIT_EXCEEDED',
      'error',
      `Strategy "${name}" concurrency cannot satisfy its fanout/Cohort limits`,
      { strategy: name },
    )
  }
  const completion = artifacts[spec.completion.artifact]
  if (completion === undefined) {
    push(
      diagnostics,
      'STRATEGY_COMPLETION_UNKNOWN_ARTIFACT',
      'error',
      `strategy "${name}" completion references unknown artifact "${spec.completion.artifact}"`,
      { strategy: name },
    )
  } else if (completion.contract !== spec.completion.contract || completion.collection) {
    push(
      diagnostics,
      'STRATEGY_COMPLETION_CONTRACT_MISMATCH',
      'error',
      `strategy "${name}" completion contract does not match artifact`,
      { strategy: name },
    )
  }
  if (spec.memberFailure === 'fail' && hasDegraded) {
    push(
      diagnostics,
      'STRATEGY_PARTIAL_POLICY_CONFLICT',
      'error',
      `strategy "${name}" has degraded fanout but memberFailure is fail`,
      { strategy: name },
    )
  }
  if (spec.memberFailure === 'allow-partial' && !hasDegraded) {
    push(
      diagnostics,
      'STRATEGY_PARTIAL_POLICY_UNUSED',
      'warning',
      `strategy "${name}" allows partial failure but has no degraded fanout`,
      { strategy: name },
    )
  }
  const consumed = new Set(spec.stages.flatMap(stage => stage.inputs.map(input => input.artifact)))
  for (const artifact of Object.keys(artifacts)) {
    if (artifact !== 'objective'
      && artifact !== spec.completion.artifact
      && !consumed.has(artifact)) {
      push(
        diagnostics,
        'STRATEGY_UNUSED_ARTIFACT',
        'warning',
        `strategy "${name}" artifact "${artifact}" is unused`,
        { strategy: name },
      )
    }
  }
  if (diagnostics.slice(startErrors).some(item => item.severity === 'error') || completion === undefined) {
    return undefined
  }
  return deepFreeze({
    name: StrategyName(name),
    description: spec.description,
    cohort: team.name,
    primitives,
    artifacts,
    completion: { artifact: completion.name, contract: completion.contract },
    ...spec.advancement === undefined ? {} : { advancement: spec.advancement as Required<StairStepPolicySpec> },
    limits: effectiveLimits,
    memberFailure: spec.memberFailure,
    active: primitives.every(primitive => team.members[primitive.member]?.active === true),
  })
}

export function assertOrchestrationCatalogUsable(catalog: CompiledOrchestrationCatalog): void {
  const errors = catalog.diagnostics.filter(item => item.severity === 'error')
  if (errors.length > 0) throw new OrchestrationCompileError(errors)
}

/** Compile layered Cohort/Strategy data against one already-compiled Specialist catalog. */
export function compileOrchestrationCatalog(
  profiles: CompiledSpecialistCatalog,
): CompiledOrchestrationCatalog {
  const diagnostics: OrchestrationDiagnostic[] = []
  const cohorts: Record<string, CompiledCohort> = {}
  for (const name of Object.keys(profiles.cohorts).sort()) {
    const team = compiledCohort(name, profiles.cohorts[name]!, profiles, diagnostics)
    if (team !== undefined) cohorts[name] = team
  }
  const strategies: Record<string, CompiledStrategyTemplate> = {}
  for (const name of Object.keys(profiles.strategies).sort()) {
    const spec = profiles.strategies[name]!
    const strategy = compileStrategyTemplate(name, spec, cohorts[spec.cohort], profiles, diagnostics)
    if (strategy !== undefined) strategies[name] = strategy
  }
  const identity = {
    version: 1,
    kind: 'legion-orchestration-catalog',
    profilePolicyDigest: profiles.policyDigest,
    profileCatalogDigest: profiles.catalogDigest,
    teams: cohorts,
    strategies,
  }
  const catalogDigest = sha256Digest(identity)
  return deepFreeze({
    cohorts,
    strategies,
    diagnostics,
    digest: catalogDigest,
    generationId: StrategyGenerationId(catalogDigest),
    specialistPolicyDigest: profiles.policyDigest,
    specialistCatalogDigest: profiles.catalogDigest,
  })
}

function narrowedLimits(
  authored: StrategyLimits,
  requested: Partial<StrategyLimits> | undefined,
  diagnostics: OrchestrationDiagnostic[],
  strategy: string,
): StrategyLimits | undefined {
  if (requested === undefined) return { ...authored }
  const result = { ...authored }
  const allowed = new Set<keyof StrategyLimits>([
    'maxAgents', 'maxConcurrent', 'deadlineMs', 'maxOutputBytes',
  ])
  const unknown = Object.keys(requested).filter(key => !allowed.has(key as keyof StrategyLimits))
  if (unknown.length > 0) {
    push(
      diagnostics,
      'STRATEGY_REQUEST_INVALID',
      'error',
      `strategy "${strategy}" invocation limits contain unknown field(s): ${unknown.sort().join(', ')}`,
      { strategy },
    )
    return undefined
  }
  for (const key of Object.keys(requested) as Array<keyof StrategyLimits>) {
    const value = requested[key]
    if (value === undefined) continue
    if (!Number.isSafeInteger(value) || value < 1 || value > authored[key]) {
      push(
        diagnostics,
        'STRATEGY_LIMIT_WIDENING',
        'error',
        `strategy "${strategy}" invocation limit "${key}" must narrow the catalog limit`,
        { strategy },
      )
      return undefined
    }
    result[key] = value
  }
  return result
}

export function renderOrchestrationGuidance(catalog: CompiledOrchestrationCatalog): string {
  const strategies = Object.values(catalog.strategies)
    .filter(strategy => strategy.active)
    .sort((left, right) => String(left.name).localeCompare(String(right.name)))
  if (strategies.length === 0) return ''
  return [
    'Configured bounded Cohort Strategies (use the strategy argument instead of specialist):',
    ...strategies.map(strategy =>
      `- \`${strategy.name}\`: ${strategy.description} `
      + `(cohort: ${strategy.cohort}; max agents: ${String(strategy.limits.maxAgents)}; foreground)`),
    'Strategy calls are foreground and return completed, degraded, cancelled, or failed outcomes.',
  ].join('\n')
}

export function assertCompiledStrategyPlan(plan: CompiledStrategyPlan): void {
  if (typeof plan !== 'object'
    || plan === null
    || !compiledStrategyPlans.has(plan)) {
    throw new Error('dsh-legion: Strategy Plan was not produced by this compiler generation')
  }
  const objectiveDigest = sha256Digest({ version: 1, kind: 'legion-objective', objective: plan.objective })
  const identity = {
    version: 1,
    kind: 'legion-strategy-plan',
    generationId: plan.generationId,
    strategy: plan.strategy,
    team: plan.cohort,
    objectiveDigest,
    primitives: serializeLegacyPrimitives(plan.primitives),
    artifacts: plan.artifacts,
    completion: plan.completion,
    ...plan.advancement === undefined ? {} : { advancement: plan.advancement },
    limits: plan.limits,
    memberFailure: plan.memberFailure,
  }
  if (plan.objectiveDigest !== objectiveDigest
    || StrategyPlanDigest(sha256Digest(identity)) !== plan.planDigest) {
    throw new Error('dsh-legion: compiled Strategy Plan digest does not match its policy')
  }
}

/** Bind one objective and optional narrowing limits to a compiled Strategy template. */
export function compileStrategy(
  catalog: CompiledOrchestrationCatalog,
  input: unknown,
): StrategyCompileResult {
  const diagnostics: OrchestrationDiagnostic[] = []
  if (typeof input !== 'object' || input === null || Array.isArray(input)) {
    push(diagnostics, 'STRATEGY_REQUEST_INVALID', 'error', 'strategy request must be a plain object')
    return deepFreeze({ ok: false, diagnostics })
  }
  const prototype = Object.getPrototypeOf(input)
  if (prototype !== Object.prototype && prototype !== null) {
    push(diagnostics, 'STRATEGY_REQUEST_INVALID', 'error', 'strategy request must be a plain object')
    return deepFreeze({ ok: false, diagnostics })
  }
  const source = input as Record<string, unknown>
  const unknown = Object.keys(source).filter(key => !['strategy', 'objective', 'limits'].includes(key))
  if (unknown.length > 0
    || typeof source.strategy !== 'string'
    || typeof source.objective !== 'string'
    || source.limits !== undefined
      && (typeof source.limits !== 'object'
        || source.limits === null
        || Array.isArray(source.limits)
        || ![Object.prototype, null].includes(Object.getPrototypeOf(source.limits)))) {
    push(diagnostics, 'STRATEGY_REQUEST_INVALID', 'error', 'strategy request has invalid or unknown fields')
    return deepFreeze({ ok: false, diagnostics })
  }
  const request: StrategyCompileRequest = {
    strategy: source.strategy,
    objective: source.objective,
    ...source.limits === undefined ? {} : { limits: source.limits as Partial<StrategyLimits> },
  }
  const strategy = catalog.strategies[request.strategy]
  if (strategy === undefined) {
    push(
      diagnostics,
      'STRATEGY_UNKNOWN',
      'error',
      `unknown or invalid strategy "${request.strategy}"`,
      { strategy: request.strategy },
    )
    return deepFreeze({ ok: false, diagnostics })
  }
  if (!strategy.active) {
    push(
      diagnostics,
      'TEAM_PROFILE_INACTIVE',
      'error',
      `Strategy "${request.strategy}" currently requires an inactive Specialist`,
      { strategy: request.strategy },
    )
    return deepFreeze({ ok: false, diagnostics })
  }
  const objective = request.objective.trim()
  if (objective.length === 0 || objective.length > 100_000) {
    push(
      diagnostics,
      'STRATEGY_OBJECTIVE_INVALID',
      'error',
      'strategy objective must be a non-empty bounded string',
      { strategy: request.strategy },
    )
    return deepFreeze({ ok: false, diagnostics })
  }
  const limits = narrowedLimits(strategy.limits, request.limits, diagnostics, request.strategy)
  if (limits === undefined) return deepFreeze({ ok: false, diagnostics })
  const requiredAgents = strategy.primitives.reduce(
    (total, primitive) => total + (primitive.kind === 'dsh-subagent-fanout' ? primitive.count : 1),
    0,
  )
  const requiredConcurrent = strategy.primitives.reduce(
    (largest, primitive) => Math.max(
      largest,
      primitive.kind === 'dsh-subagent-fanout' ? primitive.count : 1,
    ),
    1,
  )
  if (limits.maxAgents < requiredAgents
    || limits.maxConcurrent < requiredConcurrent) {
    push(
      diagnostics,
      'STRATEGY_LIMIT_UNSATISFIABLE',
      'error',
      `strategy "${request.strategy}" invocation limits cannot execute the compiled primitive graph`,
      { strategy: request.strategy },
    )
    return deepFreeze({ ok: false, diagnostics })
  }
  const objectiveDigest = sha256Digest({ version: 1, kind: 'legion-objective', objective })
  const planIdentity = {
    version: 1,
    kind: 'legion-strategy-plan',
    generationId: catalog.generationId,
    strategy: strategy.name,
    team: strategy.cohort,
    objectiveDigest,
    primitives: serializeLegacyPrimitives(strategy.primitives),
    artifacts: strategy.artifacts,
    completion: strategy.completion,
    ...strategy.advancement === undefined ? {} : { advancement: strategy.advancement },
    limits,
    memberFailure: strategy.memberFailure,
  }
  const plan = {
    kind: 'compiled-strategy-plan',
    strategy: strategy.name,
    cohort: strategy.cohort,
    objective,
    objectiveDigest,
    generationId: catalog.generationId,
    planDigest: StrategyPlanDigest(sha256Digest(planIdentity)),
    primitives: strategy.primitives,
    artifacts: strategy.artifacts,
    completion: strategy.completion,
    ...strategy.advancement === undefined ? {} : { advancement: strategy.advancement },
    limits,
    memberFailure: strategy.memberFailure,
  } as unknown as CompiledStrategyPlan
  Object.defineProperty(plan, 'team', {
    value: strategy.cohort,
    enumerable: false,
    configurable: false,
    writable: false,
  })
  compiledStrategyPlans.add(plan)
  deepFreeze(plan)
  return deepFreeze({ ok: true, plan, diagnostics })
}
