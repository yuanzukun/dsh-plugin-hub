import { defineConfig } from 'tsdown'

export default defineConfig({
  entry: ['src/index.ts'],
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'es2024',
  fixedExtension: false,
  deps: { neverBundle: [/^@deepseek-ai\//] },
  tsconfig: 'tsconfig.host.json',
  dts: true,
  clean: false,
})
