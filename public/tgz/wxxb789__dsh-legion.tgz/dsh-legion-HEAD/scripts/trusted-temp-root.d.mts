export function trustedTempRoot(): string
