import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    environment: 'node',
    environmentMatchGlobs: [['test/client-smoke.test.js', 'jsdom']],
    include: ['test/**/*.test.js'],
  },
})
