/**
 * dsh-update-notifier — browser half (lazy client bundle).
 *
 * Registers a PERSISTENT `sidebar.footer.action` entry in the sidebar footer:
 * a quiet version badge (DSH-native look via ui-primitives) that always shows
 * the installed version. When npm `latest` exceeds it, the badge lights a red
 * StateDot and the click-through Modal offers: copy the update command, ignore
 * this version, or snooze. Up-to-date / error / unknown states open an info
 * Modal with a check-now action. Polls /dsh-update-check every 5 minutes.
 */
if (typeof window !== 'undefined' && typeof window.__ModuleLoader__ !== 'undefined') {
  window.__ModuleLoader__.load({
    id: 'dsh-update-notifier',
    factory: (require) => {
      var module = { exports: {} }
      var exports = module.exports
      var react = require('react')
      var ui = require('@deepseek-ai/dsh-client-ui-primitives')

      var CHECK_PATH = '/dsh-update-check'
      var IGNORE_KEY = 'dsh-update-notifier.ignoredVersion'
      var POLL_MS = 300000
      var FALLBACK_UPDATE_CMD = 'npm install -g @deepseek-ai/dsh@latest'

      // ── inline copies of client/core.js (see test/client-core.test.js) ──
      function parsePayload(payload) {
        if (payload === null || typeof payload !== 'object') return null
        if (typeof payload.state !== 'string') return null
        return {
          state: payload.state,
          current: typeof payload.current === 'string' ? payload.current : null,
          latest: typeof payload.latest === 'string' ? payload.latest : null,
          fetchedAt: Number.isFinite(payload.fetchedAt) ? payload.fetchedAt : 0,
          error: typeof payload.error === 'string' ? payload.error : null,
          updateHint: typeof payload.updateHint === 'string' ? payload.updateHint : null,
        }
      }
      function dotVisible(payload, ignored, snoozed) {
        if (snoozed) return false
        if (payload === null || payload.state !== 'update-available') return false
        if (payload.latest === null) return false
        if (ignored !== null && ignored === payload.latest) return false
        return true
      }
      function badgeLabel(payload) {
        if (payload === null || payload.state === 'checking') return '…'
        if (payload.current === null || payload.current === '') return '—'
        return 'v' + payload.current
      }
      function panelMode(payload) {
        if (payload === null || payload.state === 'checking') return 'checking'
        if (payload.state === 'update-available') return 'update-available'
        if (payload.state === 'up-to-date') return 'up-to-date'
        if (payload.state === 'error') return 'error'
        return 'unknown'
      }
      function timeAgo(fetchedAt, now) {
        if (fetchedAt <= 0) return 'never'
        var minutes = Math.max(0, Math.floor(((now || Date.now()) - fetchedAt) / 60000))
        if (minutes < 1) return 'just now'
        if (minutes < 60) return minutes + 'm ago'
        var hours = Math.floor(minutes / 60)
        if (hours < 24) return hours + 'h ago'
        return Math.floor(hours / 24) + 'd ago'
      }
      // ── end inline copies ──

      function readIgnored() {
        try { return window.localStorage.getItem(IGNORE_KEY) } catch { return null }
      }
      function writeIgnored(value) {
        try {
          if (value === null) window.localStorage.removeItem(IGNORE_KEY)
          else window.localStorage.setItem(IGNORE_KEY, value)
        } catch { /* storage unavailable: ignore is memory-only for this session */ }
      }

      var ROW_STYLE = { display: 'flex', justifyContent: 'space-between', gap: 12, padding: '3px 0' }

      function InfoRows(props) {
        var payload = props.payload
        var rows = [
          { k: 'Current', v: payload && payload.current ? payload.current : '—' },
          { k: 'Latest', v: payload && payload.latest ? payload.latest : '—' },
          { k: 'Checked', v: timeAgo(payload ? payload.fetchedAt : 0) },
        ]
        return react.createElement('div', null, rows.map(function (row) {
          return react.createElement('div', { key: row.k, style: ROW_STYLE },
            react.createElement('span', null, row.k),
            react.createElement('b', null, row.v))
        }))
      }

      function FooterActions(props) {
        return react.createElement('div', { style: { display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 12 } }, props.children)
      }

      function UpdateAction(props) {
        var wide = props.wide === true
        var useState = react.useState
        var useEffect = react.useEffect
        var useRef = react.useRef
        var useCallback = react.useCallback

        var payloadBox = useState(null)
        var payload = payloadBox[0]
        var setPayload = payloadBox[1]
        var ignoredBox = useState(readIgnored())
        var ignored = ignoredBox[0]
        var setIgnored = ignoredBox[1]
        var snoozedBox = useState(false)
        var snoozed = snoozedBox[0]
        var setSnoozed = snoozedBox[1]
        var openBox = useState(false)
        var open = openBox[0]
        var setOpen = openBox[1]
        var copiedBox = useState(false)
        var copied = copiedBox[0]
        var setCopied = copiedBox[1]
        // One-click update: 0 = idle, 1 = armed (confirm), 2 = in flight.
        var updateStepBox = useState(0)
        var updateStep = updateStepBox[0]
        var setUpdateStep = updateStepBox[1]
        var updateStatusBox = useState(null)
        var updateStatus = updateStatusBox[0]
        var setUpdateStatus = updateStatusBox[1]
        var lastFetchedRef = useRef(0)
        // Height of the Settings row, measured at runtime so the badge can be
        // pulled onto its right side (dsh-balance-style negative-margin trick).
        var pullDownBox = useState(36)
        var pullDown = pullDownBox[0]
        var setPullDown = pullDownBox[1]
        var wrapRef = useRef(null)

        var refresh = useCallback(function (force) {
          fetch(CHECK_PATH + (force ? '?force=1' : ''))
            .then(function (r) { return r.json() })
            .then(function (j) {
              var parsed = parsePayload(j)
              setPayload(parsed)
              if (parsed && parsed.fetchedAt !== lastFetchedRef.current) {
                lastFetchedRef.current = parsed.fetchedAt
                setSnoozed(false) // a fresh check result clears the snooze
              }
            })
            .catch(function () { /* keep last payload; badge shows the last known state */ })
        }, [])

        useEffect(function () {
          refresh(false)
          var id = setInterval(function () { refresh(false) }, POLL_MS)
          var onVisibility = function () { if (!document.hidden) refresh(false) }
          document.addEventListener('visibilitychange', onVisibility)
          return function () {
            clearInterval(id)
            document.removeEventListener('visibilitychange', onVisibility)
          }
        }, [refresh])

        // Measure the Settings row below us so the badge can sit on its right
        // side; re-measure whenever the wide/rail layout toggles.
        useEffect(function () {
          if (!wide) return
          var wrapper = wrapRef.current
          if (wrapper === null) return
          var row = wrapper.parentElement ? wrapper.parentElement.nextElementSibling : null
          if (row !== null && row.offsetHeight > 0) {
            setPullDown(row.offsetHeight)
          }
        }, [wide, label])

        var mode = panelMode(payload)
        var visible = dotVisible(payload, ignored, snoozed)
        var label = badgeLabel(payload)
        var updateCmd = (payload && payload.updateHint) || FALLBACK_UPDATE_CMD
        var close = function () { setOpen(false); setCopied(false) }

        // Dot semantics: red = update available, green = current, amber = can't tell.
        var dotState = visible ? 'error' : (mode === 'up-to-date' ? 'done' : 'warning')

        var modalTitle = visible ? '发现新版本 · Update available' : 'DSH 版本 · Version'
        var modalBody = null
        var footer = null

        if (mode === 'checking') {
          modalBody = react.createElement('div', null, '检查中…')
        } else if (mode === 'update-available') {
          modalBody = react.createElement('div', null,
            react.createElement(InfoRows, { payload: payload }),
            react.createElement('div', {
              style: {
                display: 'flex', gap: 8, marginTop: 10, padding: '8px 10px',
                border: '1px solid var(--dsw-alias-border-secondary, rgba(255,255,255,0.1))',
                borderRadius: 6, fontSize: 12, fontFamily: 'var(--dsw-font-mono, monospace)',
                alignItems: 'center', justifyContent: 'space-between',
              },
            },
              react.createElement('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, updateCmd),
              react.createElement(ui.Button, {
                variant: 'ghost', size: 'sm',
                icon: react.createElement(ui.IconCopyOutline16, { size: 14 }),
                title: '复制命令',
                'aria-label': '复制命令',
                onClick: function () {
                  ui.writeClipboard(updateCmd).then(
                    function () { setCopied(true) },
                    function () { /* clipboard unavailable: keep the hint visible */ })
                },
              }),
            copied ? react.createElement('div', { style: { marginTop: 6, fontSize: 12, opacity: 0.8 } },
              '已复制 ✓ 请在终端执行更新命令，然后重启 dsh。') : null),
            updateStatus !== null ? react.createElement('div', { style: { marginTop: 8, fontSize: 12, opacity: 0.9 } }, updateStatus) : null)
          footer = react.createElement(FooterActions, null,
            react.createElement(ui.Button, {
              variant: 'primary', size: 'sm',
              disabled: updateStep === 2,
              onClick: function () {
                if (updateStep === 0) {
                  setUpdateStep(1) // first click arms, second click fires
                  return
                }
                if (updateStep !== 1) return
                setUpdateStep(2)
                setUpdateStatus('正在启动更新…')
                fetch(CHECK_PATH + '/update', { method: 'POST' })
                  .then(function (r) {
                    if (r.status === 404 || r.status === 405) {
                      // The server predates the update route: plugin files were
                      // refreshed on disk but the running dsh is still the old one.
                      setUpdateStep(1)
                      setUpdateStatus('当前 dsh 进程仍是旧版插件，请先重启 dsh（npm exec @deepseek-ai/dsh web），再回来点更新。')
                      return null
                    }
                    return r.json().catch(function () { return null })
                  })
                  .then(function (j) {
                    if (j === null) return // handled above
                    if (j.status === 'restarting') {
                      setUpdateStatus('更新已启动，dsh 即将重启，请稍后刷新页面。')
                    } else if (j.status === 'updated') {
                      setUpdateStatus('已更新到最新版，请重启 dsh 生效。')
                    } else if (j.status === 'failed') {
                      setUpdateStep(1)
                      setUpdateStatus('自动更新失败，请复制上方命令手动执行：' + (j.output || ''))
                    } else if (j.status === 'nothing-to-update') {
                      setUpdateStep(1)
                      setUpdateStatus('当前没有可用更新，请刷新后再试。')
                    } else {
                      setUpdateStep(1)
                      setUpdateStatus('自动更新失败，请复制上方命令手动执行。')
                    }
                  })
                  .catch(function () {
                    // The server may already be exiting — the request dying here
                    // usually means the restart is in flight.
                    setUpdateStatus('更新已发起，dsh 可能正在重启，请稍后刷新页面。')
                  })
              },
            }, updateStep === 0 ? '立即更新' : (updateStep === 1 ? '确认更新？dsh 将重启' : '更新中…')),
            react.createElement(ui.Button, { variant: 'ghost', size: 'sm', onClick: function () { writeIgnored(payload.latest); setIgnored(payload.latest) } }, '忽略此版本'),
            react.createElement(ui.Button, { variant: 'ghost', size: 'sm', onClick: function () { setSnoozed(true); close() } }, '稍后再说'))
        } else if (mode === 'up-to-date') {
          modalBody = react.createElement('div', null,
            react.createElement(InfoRows, { payload: payload }),
            react.createElement('div', { style: { marginTop: 8, fontSize: 12, opacity: 0.8 } }, '已是最新版本 ✓'))
          footer = react.createElement(FooterActions, null,
            react.createElement(ui.Button, { variant: 'ghost', size: 'sm', onClick: function () { refresh(true) } }, '立即检查'))
        } else if (mode === 'error') {
          modalBody = react.createElement('div', null,
            react.createElement(InfoRows, { payload: payload }),
            react.createElement('div', { style: { marginTop: 8, fontSize: 12, color: 'var(--dsw-alias-state-error-primary, #f87171)' } },
              '检查失败：' + (payload && payload.error ? payload.error : 'unknown')))
          footer = react.createElement(FooterActions, null,
            react.createElement(ui.Button, { variant: 'ghost', size: 'sm', onClick: function () { refresh(true) } }, '立即检查'))
        } else {
          // unknown: installed version unresolvable, hide the dot's alarm but keep the badge visible.
          modalBody = react.createElement('div', null,
            react.createElement(InfoRows, { payload: payload }),
            react.createElement('div', { style: { marginTop: 8, fontSize: 12, opacity: 0.8 } }, '无法识别本地 dsh 版本'))
          footer = react.createElement(FooterActions, null,
            react.createElement(ui.Button, { variant: 'ghost', size: 'sm', onClick: function () { refresh(true) } }, '立即检查'))
        }

        // The shell stacks footer actions ABOVE the Settings row by design
        // (no beside-Settings seam exists). Right-align within that row so it
        // reads as a quiet status line rather than another menu item.
        var dot = react.createElement(ui.StateDot, { state: dotState, size: 10 })
        var trigger = react.createElement(ui.Button, {
          variant: 'ghost', size: 'sm',
          onClick: function () { setOpen(true) },
          title: 'dsh-update-notifier',
        }, wide ? react.createElement(react.Fragment, null,
          react.createElement('span', { style: { display: 'inline-flex', marginRight: 6 } }, dot),
          react.createElement('span', null, label)) : dot)

        // Wide: pull the badge down onto the right side of the Settings row
        // (marginTop shifts it, marginBottom compensates the stack height).
        var wrapper = react.createElement('div', {
          ref: wrapRef,
          style: wide ? {
            marginLeft: 'auto',
            marginTop: pullDown,
            marginBottom: -pullDown,
            position: 'relative',
            zIndex: 1,
            opacity: 0.85,
          } : undefined,
        }, trigger)

        return react.createElement(react.Fragment, null,
          wrapper,
          react.createElement(ui.Modal, {
            open: open,
            onClose: close,
            title: modalTitle,
            closeLabel: '关闭',
          }, modalBody, footer))
      }

      var inject = ['slots']
      function apply(ctx) {
        ctx.effect(function () {
          var dispose = ctx.slots.register({
            name: 'sidebar.footer.action',
            id: 'dsh-update-notifier',
            order: 1, // first footer action = directly to the right of Settings
          }, UpdateAction)
          return function () { dispose() }
        }, 'dsh-update-notifier: footer action')
      }

      exports.apply = apply
      exports.inject = inject
      return module.exports
    },
  })
}
