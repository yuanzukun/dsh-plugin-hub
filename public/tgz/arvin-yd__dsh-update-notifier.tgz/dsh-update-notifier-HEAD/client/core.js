/**
 * dsh-update-notifier: pure client-side helpers (no DOM, unit-testable).
 * @module dsh-update-notifier/client/core
 */

/**
 * Validate a /dsh-update-check payload into a plain object.
 * @param {unknown} payload
 * @returns {{state: string, current: string|null, latest: string|null, fetchedAt: number, error: string|null, updateHint: string|null}|null}
 */
export function parseCheckPayload(payload) {
  if (payload === null || typeof payload !== 'object') return null
  if (typeof payload.state !== 'string') return null
  return {
    state: payload.state,
    current: typeof payload.current === 'string' ? payload.current : null,
    latest: typeof payload.latest === 'string' ? payload.latest : null,
    fetchedAt: Number.isFinite(payload.fetchedAt) ? payload.fetchedAt : 0,
    error: typeof payload.error === 'string' ? payload.error : null,
    updateHint: typeof payload.updateHint === 'string' ? payload.updateHint : null,
  }
}

/**
 * Dot visibility: update available, not snoozed, not ignored (ignore is
 * latest-version string equality — no semver needed in the browser bundle).
 * @param {{state: string, latest: string|null}|null} payload
 * @param {string|null} ignoredVersion
 * @param {boolean} snoozed
 * @returns {boolean}
 */
export function decideDotVisible(payload, ignoredVersion, snoozed) {
  if (snoozed) return false
  if (payload === null || payload.state !== 'update-available') return false
  if (payload.latest === null) return false
  if (ignoredVersion !== null && ignoredVersion === payload.latest) return false
  return true
}

/**
 * Human-friendly age for the panel's "last checked" line.
 * @param {number} fetchedAt - epoch ms, 0 = never.
 * @param {number} [now] - injectable clock for tests.
 * @returns {string}
 */
export function formatTimeAgo(fetchedAt, now = Date.now()) {
  if (fetchedAt <= 0) return 'never'
  const minutes = Math.max(0, Math.floor((now - fetchedAt) / 60000))
  if (minutes < 1) return 'just now'
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.floor(hours / 24)}d ago`
}

/**
 * Badge label for the persistent footer entry.
 * `…` while the first check is pending; `—` when the installed version is
 * unknown; otherwise `v<current>`.
 * @param {{state: string, current: string|null}|null} payload
 * @returns {string}
 */
export function decideBadgeLabel(payload) {
  if (payload === null || payload.state === 'checking') return '…'
  if (payload.current === null || payload.current === '') return '—'
  return `v${payload.current}`
}

/**
 * Which modal content the panel should render.
 * @param {{state: string}|null} payload
 * @returns {'update-available'|'up-to-date'|'error'|'unknown'|'checking'}
 */
export function decidePanelMode(payload) {
  if (payload === null || payload.state === 'checking') return 'checking'
  if (payload.state === 'update-available') return 'update-available'
  if (payload.state === 'up-to-date') return 'up-to-date'
  if (payload.state === 'error') return 'error'
  return 'unknown'
}
