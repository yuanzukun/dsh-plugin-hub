import { describe, expect, it } from 'vitest'
import { decideBadgeLabel, decideDotVisible, decidePanelMode, formatTimeAgo, parseCheckPayload } from '../client/core.js'

describe('parseCheckPayload', () => {
  it('parses a valid payload', () => {
    expect(parseCheckPayload({ state: 'update-available', current: '0.1.0-rc.5', latest: '0.1.0-rc.6', fetchedAt: 100, error: null, updateHint: 'npm install -g x' }))
      .toEqual({ state: 'update-available', current: '0.1.0-rc.5', latest: '0.1.0-rc.6', fetchedAt: 100, error: null, updateHint: 'npm install -g x' })
  })
  it('defaults a missing updateHint to null', () => {
    expect(parseCheckPayload({ state: 'up-to-date' }).updateHint).toBeNull()
  })
  it('rejects malformed payloads', () => {
    expect(parseCheckPayload(null)).toBeNull()
    expect(parseCheckPayload('x')).toBeNull()
    expect(parseCheckPayload({})).toBeNull()
    expect(parseCheckPayload({ state: 42 })).toBeNull()
  })
})

describe('decideDotVisible', () => {
  const available = { state: 'update-available', current: 'a', latest: 'b', fetchedAt: 1, error: null }
  it('visible only for update-available, unsnoozed, unignored', () => {
    expect(decideDotVisible(available, null, false)).toBe(true)
    expect(decideDotVisible(available, 'b', false)).toBe(false) // ignored this version
    expect(decideDotVisible(available, 'a', false)).toBe(true)  // older ignore does not apply
    expect(decideDotVisible(available, null, true)).toBe(false) // snoozed
  })
  it('hidden for any other state', () => {
    for (const state of ['checking', 'up-to-date', 'unknown', 'error']) {
      expect(decideDotVisible({ ...available, state }, null, false)).toBe(false)
    }
    expect(decideDotVisible(null, null, false)).toBe(false)
  })
})

describe('formatTimeAgo', () => {
  it('formats ages', () => {
    const now = 30 * 24 * 3600000 // 30 days in ms, large enough for all offsets below
    expect(formatTimeAgo(0, now)).toBe('never')
    expect(formatTimeAgo(now - 500, now)).toBe('just now')
    expect(formatTimeAgo(now - 5 * 60000, now)).toBe('5m ago')
    expect(formatTimeAgo(now - 3 * 3600000, now)).toBe('3h ago')
    expect(formatTimeAgo(now - 26 * 3600000, now)).toBe('1d ago')
  })
})

describe('decideBadgeLabel', () => {
  it('shows … while the first check is pending', () => {
    expect(decideBadgeLabel(null)).toBe('…')
    expect(decideBadgeLabel({ state: 'checking', current: '0.1.0-rc.5' })).toBe('…')
  })
  it('shows — when the installed version is unknown', () => {
    expect(decideBadgeLabel({ state: 'unknown', current: null })).toBe('—')
    expect(decideBadgeLabel({ state: 'unknown', current: '' })).toBe('—')
  })
  it('prefixes the current version otherwise, regardless of update state', () => {
    expect(decideBadgeLabel({ state: 'up-to-date', current: '0.1.0-rc.6' })).toBe('v0.1.0-rc.6')
    expect(decideBadgeLabel({ state: 'update-available', current: '0.1.0-rc.5' })).toBe('v0.1.0-rc.5')
    expect(decideBadgeLabel({ state: 'error', current: '0.1.0-rc.6' })).toBe('v0.1.0-rc.6')
  })
})

describe('decidePanelMode', () => {
  it('maps states to modal modes', () => {
    expect(decidePanelMode(null)).toBe('checking')
    expect(decidePanelMode({ state: 'checking' })).toBe('checking')
    expect(decidePanelMode({ state: 'update-available' })).toBe('update-available')
    expect(decidePanelMode({ state: 'up-to-date' })).toBe('up-to-date')
    expect(decidePanelMode({ state: 'error' })).toBe('error')
    expect(decidePanelMode({ state: 'unknown' })).toBe('unknown')
  })
})
