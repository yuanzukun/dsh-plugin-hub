import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import path from 'node:path'
import { apply, resolveInstalledVersion } from '../src/index.js'

const spawnMock = vi.fn(() => ({ unref: vi.fn(), on: vi.fn() }))
const execMock = vi.fn((_cmd, _opts, cb) => cb(null, 'updated\n', ''))

vi.mock('node:child_process', () => ({
  spawn: (...args) => spawnMock(...args),
  exec: (...args) => execMock(...args),
}))

const SAVED_ARGV1 = process.argv[1]

function makeFakeCtx() {
  const effects = []
  const injects = []
  const ctx = {
    effect: (fn, label) => {
      // Real Cordis ctx.effect runs the callback immediately and returns its disposer.
      const dispose = fn()
      effects.push({ fn, label, dispose })
      return dispose
    },
    inject: (deps, fn) => { injects.push({ deps, fn }) },
    logger: { warn: vi.fn() },
  }
  return { ctx, effects, injects }
}

describe('resolveInstalledVersion', () => {
  it('reads version from a resolvable package.json', () => {
    // Our own package.json is resolvable from the test file's URL (test/ → repo root).
    const version = resolveInstalledVersion(import.meta.url, '../package.json')
    expect(version).toBe('0.5.2')
  })
  it('returns null when the package cannot be resolved', () => {
    expect(resolveInstalledVersion(import.meta.url, './definitely-missing-package/package.json')).toBeNull()
  })
  it('falls back to resolving from the running dsh bin (probe 2)', () => {
    const saved = process.argv[1]
    process.argv[1] = path.join(process.cwd(), 'test/fixtures/argv-dsh/bin/dsh.js')
    try {
      expect(resolveInstalledVersion()).toBe('1.2.3')
    } finally {
      process.argv[1] = saved
    }
  })
  it('falls back to the walk-up package probe (probe 3, dev clones)', () => {
    const saved = process.argv[1]
    process.argv[1] = path.join(process.cwd(), 'test/fixtures/argv-root/lib/bin.js')
    try {
      expect(resolveInstalledVersion()).toBe('9.8.7')
    } finally {
      process.argv[1] = saved
    }
  })
})

describe('apply', () => {
  let fetchMock
  beforeEach(() => { fetchMock = vi.fn(); vi.stubGlobal('fetch', fetchMock) })
  afterEach(() => { vi.unstubAllGlobals(); vi.useRealTimers() })

  it('polls the registry, caches the result, and serves it over the webServer route', async () => {
    vi.useFakeTimers()
    fetchMock.mockResolvedValue({
      ok: true,
      json: async () => ({ 'dist-tags': { latest: '9.9.9' } }),
    })

    const { ctx, effects, injects } = makeFakeCtx()
    apply(ctx, {})
    // The poll loop effect registered with a 10s first-run delay.
    expect(effects[0].label).toBe('dsh-update-notifier: check loop')

    await vi.advanceTimersByTimeAsync(10000)
    expect(fetchMock).toHaveBeenCalledTimes(1)
    expect(fetchMock.mock.calls[0][0]).toBe('https://registry.npmjs.org/@deepseek-ai%2fdsh')

    // webServer is optional; a headless composition gets no route.
    expect(injects).toHaveLength(1)
    expect(injects[0].deps).toEqual(['webServer'])

    const webCtx = { effect: (fn) => fn(), webServer: { register: vi.fn() } }
    injects[0].fn(webCtx)
    // Two routes: the check endpoint and the update endpoint.
    expect(webCtx.webServer.register).toHaveBeenCalledTimes(2)
    const { path, handler } = webCtx.webServer.register.mock.calls[0][0]
    expect(path).toBe('/dsh-update-check')

    const res = { writeHead: vi.fn(), end: vi.fn() }
    await handler({ method: 'GET', url: '/dsh-update-check' }, res)
    const body = JSON.parse(res.end.mock.calls[0][0])
    // Outside a real dsh tree, @deepseek-ai/dsh cannot be resolved, so the
    // installed version is unknown — the decision matrix itself (including
    // update-available for rc.5 → rc.6) is covered by test/domain.test.js.
    expect(body.state).toBe('unknown')
    expect(body.current).toBeNull()
    expect(body.latest).toBe('9.9.9')
    // vitest's argv[1] is not an npx cache path, so the hint assumes global npm.
    expect(body.updateHint).toBe('npm install -g @deepseek-ai/dsh@latest')

    // force=1 triggers an immediate re-check (with 2s cooldown).
    await vi.advanceTimersByTimeAsync(3000)
    await handler({ method: 'GET', url: '/dsh-update-check?force=1' }, res)
    expect(fetchMock).toHaveBeenCalledTimes(2)
    vi.useRealTimers()
  })

  it('rejects non-GET methods with 405', async () => {
    const { ctx, injects } = makeFakeCtx()
    apply(ctx, {})
    const webCtx = { effect: (fn) => fn(), webServer: { register: vi.fn() } }
    injects[0].fn(webCtx)
    const { handler } = webCtx.webServer.register.mock.calls[0][0]
    const res = { writeHead: vi.fn(), end: vi.fn() }
    await handler({ method: 'POST', url: '/dsh-update-check' }, res)
    expect(res.writeHead).toHaveBeenCalledWith(405, { Allow: 'GET, HEAD' })
    expect(res.end).toHaveBeenCalledWith()
  })

  it('marks the state error and logs when the registry call fails', async () => {
    vi.useFakeTimers()
    fetchMock.mockRejectedValue(new Error('ECONNRESET'))
    const { ctx, effects, injects } = makeFakeCtx()
    apply(ctx, {})
    await vi.advanceTimersByTimeAsync(10000)
    const webCtx = { effect: (fn) => fn(), webServer: { register: vi.fn() } }
    injects[0].fn(webCtx)
    const { handler } = webCtx.webServer.register.mock.calls[0][0]
    const res = { writeHead: vi.fn(), end: vi.fn() }
    await handler({ method: 'GET', url: '/dsh-update-check' }, res)
    const body = JSON.parse(res.end.mock.calls[0][0])
    expect(body.state).toBe('error')
    expect(body.error).toBe('ECONNRESET')
    expect(ctx.logger.warn).toHaveBeenCalledWith('[dsh-update-notifier] check failed: ECONNRESET')
    vi.useRealTimers()
  })

  it('npx install: update endpoint spawns the detached new dsh and exits', async () => {
    vi.useFakeTimers()
    process.argv[1] = path.join(process.cwd(), 'test/fixtures/npx-install/.npm/_npx/abc123/bin/dsh.js')
    const exitSpy = vi.spyOn(process, 'exit').mockImplementation(() => {})
    fetchMock.mockResolvedValue({ ok: true, json: async () => ({ 'dist-tags': { latest: '0.1.0-rc.6' } }) })

    const { ctx, injects } = makeFakeCtx()
    apply(ctx, {})
    await vi.advanceTimersByTimeAsync(10000)

    const webCtx = { effect: (fn) => fn(), webServer: { register: vi.fn() } }
    injects[0].fn(webCtx)
    // Two routes: the check endpoint and the update endpoint.
    expect(webCtx.webServer.register).toHaveBeenCalledTimes(2)
    const { path: updatePath, handler } = webCtx.webServer.register.mock.calls[1][0]
    expect(updatePath).toBe('/dsh-update-check/update')

    const res = { writeHead: vi.fn(), end: vi.fn() }
    await handler({ method: 'POST', url: '/dsh-update-check/update' }, res)
    expect(spawnMock).toHaveBeenCalledWith('npm', ['exec', '--yes', '@deepseek-ai/dsh@latest', 'web'], expect.any(Object))
    const body = JSON.parse(res.end.mock.calls[0][0])
    expect(body.status).toBe('restarting')
    expect(res.writeHead).toHaveBeenCalledWith(202, expect.any(Object))

    await vi.advanceTimersByTimeAsync(1200)
    expect(exitSpy).toHaveBeenCalledWith(0)
    exitSpy.mockRestore()
    process.argv[1] = SAVED_ARGV1
    vi.useRealTimers()
  })

  it('global install: update endpoint runs npm install -g and reports the result', async () => {
    vi.useFakeTimers()
    process.argv[1] = path.join(process.cwd(), 'test/fixtures/argv-dsh/bin/dsh.js') // version 1.2.3, not npx
    fetchMock.mockResolvedValue({ ok: true, json: async () => ({ 'dist-tags': { latest: '9.9.9' } }) })

    const { ctx, injects } = makeFakeCtx()
    apply(ctx, {})
    await vi.advanceTimersByTimeAsync(10000)

    const webCtx = { effect: (fn) => fn(), webServer: { register: vi.fn() } }
    injects[0].fn(webCtx)
    const { handler } = webCtx.webServer.register.mock.calls[1][0]
    const res = { writeHead: vi.fn(), end: vi.fn() }
    await handler({ method: 'POST', url: '/dsh-update-check/update' }, res)
    expect(execMock).toHaveBeenCalledWith('npm install -g @deepseek-ai/dsh@latest', expect.any(Object), expect.any(Function))
    const body = JSON.parse(res.end.mock.calls[0][0])
    expect(body.status).toBe('updated')
    expect(res.writeHead).toHaveBeenCalledWith(200, expect.any(Object))
    process.argv[1] = SAVED_ARGV1
    vi.useRealTimers()
  })

  it('update endpoint refuses when no update is available', async () => {
    process.argv[1] = SAVED_ARGV1
    const { ctx, injects } = makeFakeCtx()
    apply(ctx, {})
    const webCtx = { effect: (fn) => fn(), webServer: { register: vi.fn() } }
    injects[0].fn(webCtx)
    const { handler } = webCtx.webServer.register.mock.calls[1][0]
    const res = { writeHead: vi.fn(), end: vi.fn() }
    await handler({ method: 'POST', url: '/dsh-update-check/update' }, res)
    expect(res.writeHead).toHaveBeenCalledWith(409, expect.any(Object))
    expect(JSON.parse(res.end.mock.calls[0][0]).status).toBe('nothing-to-update')
  })
})
