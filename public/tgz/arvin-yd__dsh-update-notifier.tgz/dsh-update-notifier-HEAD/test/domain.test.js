import { describe, expect, it } from 'vitest'
import { decideUpdateState, detectUpdateHint, parseRegistryLatest, resolveConfig } from '../src/domain.js'

describe('parseRegistryLatest', () => {
  it('extracts the latest dist-tag', () => {
    expect(parseRegistryLatest({ 'dist-tags': { latest: '0.1.0-rc.6', next: '0.1.0-rc.6' } })).toBe('0.1.0-rc.6')
  })
  it('returns null for null / non-object / missing dist-tags', () => {
    expect(parseRegistryLatest(null)).toBeNull()
    expect(parseRegistryLatest('x')).toBeNull()
    expect(parseRegistryLatest({})).toBeNull()
    expect(parseRegistryLatest({ 'dist-tags': {} })).toBeNull()
    expect(parseRegistryLatest({ 'dist-tags': { latest: 42 } })).toBeNull()
  })
})

describe('decideUpdateState', () => {
  it('update-available when latest is newer', () => {
    expect(decideUpdateState({ current: '0.1.0-rc.5', latest: '0.1.0-rc.6' })).toBe('update-available')
    expect(decideUpdateState({ current: '0.1.0-rc.6', latest: '1.0.0' })).toBe('update-available')
  })
  it('up-to-date when equal or installed is newer', () => {
    expect(decideUpdateState({ current: '0.1.0-rc.6', latest: '0.1.0-rc.6' })).toBe('up-to-date')
    expect(decideUpdateState({ current: '9.9.9', latest: '0.1.0-rc.6' })).toBe('up-to-date')
  })
  it('error when latest is missing, unknown when current is missing', () => {
    expect(decideUpdateState({ current: '0.1.0-rc.5', latest: null })).toBe('error')
    expect(decideUpdateState({ current: null, latest: '0.1.0-rc.6' })).toBe('unknown')
    expect(decideUpdateState({ current: 'not-a-version', latest: '0.1.0-rc.6' })).toBe('unknown')
  })
})

describe('resolveConfig', () => {
  it('applies defaults', () => {
    expect(resolveConfig(undefined)).toEqual({ checkIntervalMs: 21600000, timeoutMs: 5000 })
    expect(resolveConfig({})).toEqual({ checkIntervalMs: 21600000, timeoutMs: 5000 })
  })
  it('keeps positive numeric overrides', () => {
    expect(resolveConfig({ checkIntervalMs: 1000, timeoutMs: 200 })).toEqual({ checkIntervalMs: 1000, timeoutMs: 200 })
  })
  it('rejects garbage values', () => {
    expect(resolveConfig({ checkIntervalMs: -1, timeoutMs: 'x' })).toEqual({ checkIntervalMs: 21600000, timeoutMs: 5000 })
  })
})

describe('detectUpdateHint', () => {
  it('npx-cache installs re-fetch via npm exec with an explicit tag', () => {
    expect(detectUpdateHint('/Users/me/.npm/_npx/abc123/node_modules/.bin/dsh')).toBe('npm exec @deepseek-ai/dsh@latest web')
  })
  it('everything else assumes a global npm install', () => {
    expect(detectUpdateHint('/usr/local/lib/node_modules/@deepseek-ai/dsh/lib/bin.js')).toBe('npm install -g @deepseek-ai/dsh@latest')
    expect(detectUpdateHint(undefined)).toBe('npm install -g @deepseek-ai/dsh@latest')
  })
})
