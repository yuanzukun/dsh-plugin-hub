// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const captured = {}
let bundleApply = null
let bundleInject = null

beforeEach(async () => {
  vi.resetModules()
  const react = await import('react')
  const uiPrimitives = {
    StateDot: () => null,
    Button: () => null,
    Modal: () => null,
    IconCopyOutline16: () => null,
    writeClipboard: () => Promise.resolve(),
  }
  window.__ModuleLoader__ = {
    load: ({ id, factory }) => {
      captured.id = id
      const requireStub = (name) => {
        if (name === 'react') return react
        if (name === '@deepseek-ai/dsh-client-ui-primitives') return uiPrimitives
        throw new Error(`unexpected require: ${name}`)
      }
      captured.exports = factory(requireStub)
    },
  }
  await import('../client/client.js')
  bundleApply = captured.exports.apply
  bundleInject = captured.exports.inject
})

afterEach(() => {
  delete window.__ModuleLoader__
})

describe('client bundle registration', () => {
  it('loads under the expected module id with inject=["slots"]', () => {
    expect(captured.id).toBe('dsh-update-notifier')
    expect(bundleInject).toEqual(['slots'])
  })

  it('registers the sidebar.footer.action slot on apply', () => {
    const register = vi.fn(() => () => {})
    const ctx = { effect: (fn) => { fn(); return () => {} }, slots: { register } }
    bundleApply(ctx)
    expect(register).toHaveBeenCalledTimes(1)
    const [meta, component] = register.mock.calls[0]
    expect(meta).toMatchObject({ name: 'sidebar.footer.action', id: 'dsh-update-notifier' })
    expect(typeof component).toBe('function')
  })
})
