/**
 * dsh-update-notifier — server half.
 *
 * 1. Resolves the installed `@deepseek-ai/dsh` version once at startup.
 * 2. Polls the npm registry for the `latest` dist-tag (default every 6h,
 *    first run 10s after startup, never blocking).
 * 3. Caches the decision and serves it on `GET /dsh-update-check`
 *    (`?force=1` re-checks with a 2s cooldown) via the optional `webServer`
 *    service, so headless compositions are unaffected.
 *
 * @module dsh-update-notifier
 */
import { createRequire } from 'node:module'
import { existsSync, readFileSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { exec, spawn } from 'node:child_process'
import { decideUpdateState, detectUpdateHint, parseRegistryLatest, REGISTRY_URL, resolveConfig } from './domain.js'

export { decideUpdateState, detectUpdateHint, parseRegistryLatest, REGISTRY_URL, resolveConfig } from './domain.js'

export const name = 'dsh-update-notifier'

/** Kick off the one-click update for npx-cache installs: spawn the new dsh in
 * a detached process (it fetches @latest first, so it can take a while) and
 * let the caller exit so the new server can bind the port. */
export function launchNpxUpdate() {
  const child = spawn('npm', ['exec', '--yes', '@deepseek-ai/dsh@latest', 'web'], {
    detached: true,
    stdio: 'ignore',
    env: process.env,
  })
  // An unhandled 'error' event (e.g. npm missing from PATH) would crash the
  // whole dsh process; swallow it — the panel already tells the user to retry
  // or copy the command.
  child.on('error', () => {})
  child.unref()
}

/** Install the update for global-npm installs; resolves with status + output tail. */
export function runGlobalUpdate() {
  return new Promise((resolve) => {
    exec('npm install -g @deepseek-ai/dsh@latest', { timeout: 120000 }, (error, stdout, stderr) => {
      resolve({
        status: error === null ? 'updated' : 'failed',
        output: `${stdout}${stderr}`.trim().slice(-500),
      })
    })
  })
}

/** Read a resolved package.json object's version, or null when invalid. */
function versionOf(pkg) {
  const version = pkg?.version
  return typeof version === 'string' && version.length > 0 ? version : null
}

/**
 * Probe 3: walk up from `startDir` and return the version of the first
 * package.json whose name starts with `@deepseek-ai/dsh` (covers dev clones
 * of the monorepo, whose root package is `@deepseek-ai/dsh-root`).
 * @param {string} startDir
 * @returns {string|null}
 */
function probeDshPackageWalkUp(startDir) {
  let dir = path.resolve(startDir)
  for (;;) {
    const candidate = path.join(dir, 'package.json')
    if (existsSync(candidate)) {
      try {
        const pkg = JSON.parse(readFileSync(candidate, 'utf8'))
        if (typeof pkg.name === 'string' && pkg.name.startsWith('@deepseek-ai/dsh')) {
          const version = versionOf(pkg)
          if (version !== null) return version
        }
      } catch { /* unreadable package.json: keep walking */ }
    }
    const parent = path.dirname(dir)
    if (parent === dir) return null
    dir = parent
  }
}

/**
 * Resolve the installed DSH version. Three probes, in order:
 * 1. `@deepseek-ai/dsh/package.json` from the plugin's own location
 *    (npm-installed plugins live inside the dsh dependency tree);
 * 2. the same specifier from the running `dsh` bin (global npm installs);
 * 3. walk-up probe for any `@deepseek-ai/dsh*` package.json (dev clones).
 * @param {string} [fromUrl] - base URL for probe 1 (defaults to this module).
 * @param {string} [specifier] - package.json specifier for probes 1 and 2.
 * @returns {string|null} version string, or null when unresolvable.
 */
export function resolveInstalledVersion(fromUrl, specifier = '@deepseek-ai/dsh/package.json') {
  const base = fromUrl ?? import.meta.url
  try {
    const version = versionOf(createRequire(base)(specifier))
    if (version !== null) return version
  } catch { /* probe 1 miss */ }
  if (process.argv[1]) {
    try {
      const version = versionOf(createRequire(process.argv[1])(specifier))
      if (version !== null) return version
    } catch { /* probe 2 miss */ }
    const fromBin = probeDshPackageWalkUp(path.dirname(process.argv[1]))
    if (fromBin !== null) return fromBin
  }
  return probeDshPackageWalkUp(path.dirname(fileURLToPath(base)))
}

/**
 * Install the check loop and the optional web route.
 * @param {import('@deepseek-ai/cordis').Context} ctx - plugin context.
 * @param {Record<string, unknown>|undefined} config - row config from cordis.patch.yml.
 */
export function apply(ctx, config) {
  const conf = resolveConfig(config)
  const current = resolveInstalledVersion()

  const updateHint = detectUpdateHint(process.argv[1])

  /** @type {{state: string, current: string|null, latest: string|null, fetchedAt: number, error: string|null, updateHint: string}} */
  let cache = { state: 'checking', current, latest: null, fetchedAt: 0, error: null, updateHint }
  let inflight = null

  const check = () => {
    if (inflight !== null) return inflight
    inflight = (async () => {
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), conf.timeoutMs)
      try {
        const res = await fetch(REGISTRY_URL, { signal: controller.signal })
        if (!res.ok) throw new Error(`registry HTTP ${res.status}`)
        const latest = parseRegistryLatest(await res.json())
        cache = {
          state: decideUpdateState({ current, latest }),
          current,
          latest,
          fetchedAt: Date.now(),
          error: latest === null ? 'malformed-registry-response' : null,
          updateHint,
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        // Stale-while-error: keep the last good state once one exists.
        cache = {
          state: cache.state === 'checking' ? 'error' : cache.state,
          current,
          latest: cache.latest,
          fetchedAt: cache.fetchedAt,
          error: message,
          updateHint,
        }
        ctx.logger?.warn(`[dsh-update-notifier] check failed: ${message}`)
      } finally {
        clearTimeout(timer)
        inflight = null
      }
    })()
    return inflight
  }

  ctx.effect(() => {
    let timer = null
    const run = () => {
      void check().then(() => {
        timer = setTimeout(run, conf.checkIntervalMs)
      })
    }
    timer = setTimeout(run, 10000) // first check 10s after startup
    return () => clearTimeout(timer)
  }, 'dsh-update-notifier: check loop')

  // Optional webServer: serve the cached decision to the browser half.
  ctx.inject(['webServer'], (webCtx) => {
    webCtx.effect(() => webCtx.webServer.register({
      kind: 'exact',
      path: '/dsh-update-check',
      async handler(req, res) {
        if (req.method !== 'GET' && req.method !== 'HEAD') {
          res.writeHead(405, { Allow: 'GET, HEAD' })
          res.end()
          return
        }
        const parsedUrl = new URL(req.url ?? '/', 'http://127.0.0.1')
        const force = parsedUrl.searchParams.get('force') === '1'
        if (force && (Date.now() - cache.fetchedAt > 2000 || cache.state === 'checking')) {
          await check()
        }
        const body = JSON.stringify(cache)
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-store',
          'Content-Length': Buffer.byteLength(body),
        })
        res.end(req.method === 'HEAD' ? undefined : body)
      },
    }), 'dsh-update-notifier: route')

    const isNpx = typeof process.argv[1] === 'string' && process.argv[1].includes('.npm/_npx/')
    webCtx.effect(() => webCtx.webServer.register({
      kind: 'exact',
      path: '/dsh-update-check/update',
      async handler(req, res) {
        if (req.method !== 'POST') {
          res.writeHead(405, { Allow: 'POST' })
          res.end()
          return
        }
        if (cache.state !== 'update-available') {
          res.writeHead(409, { 'Content-Type': 'application/json; charset=utf-8' })
          res.end(JSON.stringify({ status: 'nothing-to-update' }))
          return
        }
        if (isNpx) {
          launchNpxUpdate()
          const body = JSON.stringify({ status: 'restarting', hint: updateHint })
          res.writeHead(202, {
            'Content-Type': 'application/json; charset=utf-8',
            'Content-Length': Buffer.byteLength(body),
          })
          res.end(body)
          // Give the response time to flush, then exit so the detached new
          // process can bind the port.
          setTimeout(() => process.exit(0), 1200)
          return
        }
        const result = await runGlobalUpdate()
        const body = JSON.stringify(result)
        res.writeHead(result.status === 'updated' ? 200 : 500, {
          'Content-Type': 'application/json; charset=utf-8',
          'Content-Length': Buffer.byteLength(body),
        })
        res.end(body)
      },
    }), 'dsh-update-notifier: update route')
  })
}
