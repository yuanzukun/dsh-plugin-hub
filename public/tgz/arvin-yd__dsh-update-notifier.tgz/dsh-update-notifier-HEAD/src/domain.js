/**
 * dsh-update-notifier: pure host-side decision logic (unit-testable, no I/O).
 * @module dsh-update-notifier/domain
 */
import semver from 'semver'

/** npm registry metadata endpoint for the official umbrella package. */
export const REGISTRY_URL = 'https://registry.npmjs.org/@deepseek-ai%2fdsh'

/**
 * Extract the `latest` dist-tag from an npm registry JSON document.
 * @param {unknown} doc - parsed registry response body.
 * @returns {string|null} latest version string, or null when malformed.
 */
export function parseRegistryLatest(doc) {
  if (doc === null || typeof doc !== 'object') return null
  const tags = doc['dist-tags']
  if (tags === null || typeof tags !== 'object') return null
  const latest = tags.latest
  return typeof latest === 'string' && latest.length > 0 ? latest : null
}

/**
 * Decide the host-side update state from the two version facts.
 * `ignored` is layered on top by the client; the host stays stateless.
 * @param {{current: string|null, latest: string|null}} facts
 * @returns {'checking'|'update-available'|'up-to-date'|'unknown'|'error'} state
 */
export function decideUpdateState({ current, latest }) {
  if (latest === null) return 'error'
  if (current === null || current === '') return 'unknown'
  try {
    return semver.gt(latest, current) ? 'update-available' : 'up-to-date'
  } catch {
    return 'unknown'
  }
}

/**
 * Normalize plugin config with defaults.
 * @param {Record<string, unknown>|undefined} config
 * @returns {{checkIntervalMs: number, timeoutMs: number}}
 */
export function resolveConfig(config) {
  const c = config ?? {}
  return {
    checkIntervalMs: Number.isFinite(c.checkIntervalMs) && c.checkIntervalMs > 0 ? c.checkIntervalMs : 21600000, // 6h
    timeoutMs: Number.isFinite(c.timeoutMs) && c.timeoutMs > 0 ? c.timeoutMs : 5000,
  }
}

/**
 * Guess the shell command that updates this dsh installation.
 * npx-cache installs (`npm exec @deepseek-ai/dsh web`) re-fetch on the next
 * `npm exec` with an explicit tag; everything else assumes a global npm install.
 * @param {string|undefined} argv1 - process.argv[1] of the running dsh process.
 * @returns {string} copyable update command (a restart is always required).
 */
export function detectUpdateHint(argv1) {
  if (typeof argv1 === 'string' && argv1.includes('.npm/_npx/')) {
    return 'npm exec @deepseek-ai/dsh@latest web'
  }
  return 'npm install -g @deepseek-ai/dsh@latest'
}
