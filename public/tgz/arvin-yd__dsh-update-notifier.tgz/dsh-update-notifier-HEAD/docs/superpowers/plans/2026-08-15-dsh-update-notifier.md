# dsh-update-notifier Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build and publish `dsh-update-notifier`, a DeepSeek Harness plugin that shows a red-dot footer badge in the Web UI when npm's `@deepseek-ai/dsh@latest` is newer than the installed version.

**Architecture:** Host half (`src/index.js`, plain ESM, no build) polls the npm registry every 6h, caches the result, and exposes it on a `GET /dsh-update-check` endpoint via the optional `webServer` service. Browser half (`client/client.js`, lazy-CJS bundle loaded by `window.__ModuleLoader__`) registers a `sidebar.footer.action` slot entry (red dot + panel) and polls the endpoint every 5 minutes. All decision logic is pure functions unit-tested with vitest; the browser bundle is validated by a jsdom smoke test.

**Tech Stack:** plain modern JavaScript (ESM + one CJS-style lazy bundle — mirrors dsh-undo and dsh-balance, zero build step), Node 22+ global `fetch`, `semver@^7.8.1` (runtime dep), vitest + jsdom (dev deps), react 18 (dev dep for the smoke test).

**Reference artifacts (proven community plugins):** `dsh-undo@0.2.0` (bundle mount + host entry shape), `dsh-balance@0.1.7` (client bundle shape + webServer route + dsh.client.inject declaration).

**Spec deviations (deliberate refinements, approved via plan):**
1. "Ignored" is tracked **client-side** (localStorage) instead of host storage: the host endpoint stays stateless; ignore compares latest-version string equality, so no semver needed in the browser bundle.
2. Client persistence uses `localStorage` (guarded, memory fallback) instead of the DSH storage service — the client bundle has no reachable storage service and dsh-balance proves localStorage-free client state is the norm; spec's "无存储降级为内存态" is preserved.
3. `update-service` state machine: host computes `checking|update-available|up-to-date|unknown|error`; the `ignored` state is layered on top in the client's dot decision.

Repo root for all paths below: `<repo>` (= `/tmp/dsh-contrib/dsh-update-notifier`).

---

## File structure

| File | Responsibility |
|---|---|
| `<repo>/package.json` | npm metadata, exports, `dsh.bundle`/`dsh.client` contract, deps |
| `<repo>/cordis.patch.yml` | bundle patch: mounts the plugin row + default config |
| `<repo>/LICENSE` | MIT |
| `<repo>/README.md`, `README.zh.md` | docs: features, install, config, FAQ |
| `<repo>/vitest.config.js` | vitest config (jsdom only for the smoke test) |
| `<repo>/src/domain.js` | pure host logic: registry parsing, version decision, config |
| `<repo>/src/index.js` | host wiring: resolve installed version, poll loop, HTTP route |
| `<repo>/client/core.js` | pure client logic: payload parsing, dot decision, time formatting |
| `<repo>/client/client.js` | browser bundle: `__ModuleLoader__` load, slot registration, React UI |
| `<repo>/test/domain.test.js` | unit tests for src/domain.js |
| `<repo>/test/host.test.js` | unit tests for src/index.js (mocked fetch/ctx/timers) |
| `<repo>/test/client-core.test.js` | unit tests for client/core.js |
| `<repo>/test/client-smoke.test.js` | jsdom smoke test for the browser bundle |

---

### Task 1: Repo scaffold

**Files:**
- Create: `<repo>/package.json`, `<repo>/cordis.patch.yml`, `<repo>/LICENSE`, `<repo>/vitest.config.js`, `<repo>/README.md`, `<repo>/README.zh.md`

- [ ] **Step 1.1: Create `<repo>/package.json`**

```json
{
  "name": "dsh-update-notifier",
  "version": "0.1.0",
  "description": "Red-dot update checker for DeepSeek Harness: warns in the sidebar footer when a newer @deepseek-ai/dsh release exists on npm.",
  "type": "module",
  "main": "./src/index.js",
  "exports": {
    ".": "./src/index.js",
    "./client": "./client/client.js",
    "./client/core": "./client/core.js",
    "./package.json": "./package.json"
  },
  "files": [
    "src",
    "client",
    "cordis.patch.yml",
    "README.md",
    "README.zh.md",
    "LICENSE"
  ],
  "scripts": {
    "test": "vitest run"
  },
  "dsh": {
    "bundle": {
      "patch": "./cordis.patch.yml"
    },
    "client": {
      "platform": "web",
      "inject": [
        "@deepseek-ai/dsh-client-runtime",
        "@deepseek-ai/dsh-client-ui-sidebar"
      ]
    }
  },
  "dependencies": {
    "semver": "^7.8.1"
  },
  "peerDependencies": {
    "@deepseek-ai/cordis": "^4.0.1"
  },
  "devDependencies": {
    "jsdom": "^27.0.0",
    "react": "^18.2.0",
    "vitest": "^4.1.8"
  },
  "engines": {
    "node": ">=22.0.0"
  },
  "keywords": [
    "dsh",
    "dsh-plugin",
    "deepseek-harness",
    "update-checker"
  ],
  "license": "MIT"
}
```

- [ ] **Step 1.2: Create `<repo>/cordis.patch.yml`**

```yaml
# dsh-update-notifier bundle layer: one plugin row.
# Install: dsh plugin --profile web add dsh-update-notifier
# Config overrides (write into $DSH_HOME/profiles/web/cordis.patch.yml):
#   - id: dsh-update-notifier
#     config:
#       checkIntervalMs: 21600000   # host re-check interval (default 6h)
#       timeoutMs: 5000             # registry fetch timeout
- insert:
    - id: dsh-update-notifier
      name: dsh-update-notifier
      config:
        checkIntervalMs: 21600000
        timeoutMs: 5000
```

- [ ] **Step 1.3: Create `<repo>/LICENSE`** (MIT, year 2026, copyright arvin-yd)

```text
MIT License

Copyright (c) 2026 arvin-yd

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

- [ ] **Step 1.4: Create `<repo>/vitest.config.js`**

```js
import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    environment: 'node',
    environmentMatchGlobs: [['test/client-smoke.test.js', 'jsdom']],
    include: ['test/**/*.test.js'],
  },
})
```

- [ ] **Step 1.5: Create placeholder `<repo>/README.md` and `<repo>/README.zh.md`** — final content comes in Task 5. For now:

```markdown
# dsh-update-notifier

(WIP) Red-dot update checker for DeepSeek Harness.
```

- [ ] **Step 1.6: Install dev dependencies and verify the suite runner boots**

Run (from `<repo>`): `pnpm install`
Expected: exit 0; `node_modules/.bin/vitest` exists.

- [ ] **Step 1.7: Init git and commit**

```bash
cd <repo> && git init
git config user.name "arvin-yd"
git config user.email "194348967+arvin-yd@users.noreply.github.com"
git add -A && git commit -m "chore: scaffold dsh-update-notifier plugin package"
```

---

### Task 2: Pure host domain logic (`src/domain.js`)

**Files:**
- Create: `<repo>/src/domain.js`
- Test: `<repo>/test/domain.test.js`

- [ ] **Step 2.1: Write the failing test `<repo>/test/domain.test.js`**

```js
import { describe, expect, it } from 'vitest'
import { decideUpdateState, parseRegistryLatest, resolveConfig } from '../src/domain.js'

describe('parseRegistryLatest', () => {
  it('extracts the latest dist-tag', () => {
    expect(parseRegistryLatest({ 'dist-tags': { latest: '0.1.0-rc.6', next: '0.1.0-rc.6' } })).toBe('0.1.0-rc.6')
  })
  it('returns null for null / non-object / missing dist-tags', () => {
    expect(parseRegistryLatest(null)).toBeNull()
    expect(parseRegistryLatest('x')).toBeNull()
    expect(parseRegistryLatest({})).toBeNull()
    expect(parseRegistryLatest({ 'dist-tags': {} })).toBeNull()
    expect(parseRegistryLatest({ 'dist-tags': { latest: 42 } })).toBeNull()
  })
})

describe('decideUpdateState', () => {
  it('update-available when latest is newer', () => {
    expect(decideUpdateState({ current: '0.1.0-rc.5', latest: '0.1.0-rc.6' })).toBe('update-available')
    expect(decideUpdateState({ current: '0.1.0-rc.6', latest: '1.0.0' })).toBe('update-available')
  })
  it('up-to-date when equal or installed is newer', () => {
    expect(decideUpdateState({ current: '0.1.0-rc.6', latest: '0.1.0-rc.6' })).toBe('up-to-date')
    expect(decideUpdateState({ current: '9.9.9', latest: '0.1.0-rc.6' })).toBe('up-to-date')
  })
  it('error when latest is missing, unknown when current is missing', () => {
    expect(decideUpdateState({ current: '0.1.0-rc.5', latest: null })).toBe('error')
    expect(decideUpdateState({ current: null, latest: '0.1.0-rc.6' })).toBe('unknown')
    expect(decideUpdateState({ current: 'not-a-version', latest: '0.1.0-rc.6' })).toBe('unknown')
  })
})

describe('resolveConfig', () => {
  it('applies defaults', () => {
    expect(resolveConfig(undefined)).toEqual({ checkIntervalMs: 21600000, timeoutMs: 5000 })
    expect(resolveConfig({})).toEqual({ checkIntervalMs: 21600000, timeoutMs: 5000 })
  })
  it('keeps positive numeric overrides', () => {
    expect(resolveConfig({ checkIntervalMs: 1000, timeoutMs: 200 })).toEqual({ checkIntervalMs: 1000, timeoutMs: 200 })
  })
  it('rejects garbage values', () => {
    expect(resolveConfig({ checkIntervalMs: -1, timeoutMs: 'x' })).toEqual({ checkIntervalMs: 21600000, timeoutMs: 5000 })
  })
})
```

- [ ] **Step 2.2: Run the test to verify it fails**

Run: `cd <repo> && pnpm test -- test/domain.test.js`
Expected: FAIL — `Cannot find module '../src/domain.js'`.

- [ ] **Step 2.3: Create `<repo>/src/domain.js`**

```js
/**
 * dsh-update-notifier: pure host-side decision logic (unit-testable, no I/O).
 * @module dsh-update-notifier/domain
 */
import semver from 'semver'

/** npm registry metadata endpoint for the official umbrella package. */
export const REGISTRY_URL = 'https://registry.npmjs.org/@deepseek-ai%2fdsh'

/**
 * Extract the `latest` dist-tag from an npm registry JSON document.
 * @param {unknown} doc - parsed registry response body.
 * @returns {string|null} latest version string, or null when malformed.
 */
export function parseRegistryLatest(doc) {
  if (doc === null || typeof doc !== 'object') return null
  const tags = doc['dist-tags']
  if (tags === null || typeof tags !== 'object') return null
  const latest = tags.latest
  return typeof latest === 'string' && latest.length > 0 ? latest : null
}

/**
 * Decide the host-side update state from the two version facts.
 * `ignored` is layered on top by the client; the host stays stateless.
 * @param {{current: string|null, latest: string|null}} facts
 * @returns {'checking'|'update-available'|'up-to-date'|'unknown'|'error'} state
 */
export function decideUpdateState({ current, latest }) {
  if (latest === null) return 'error'
  if (current === null || current === '') return 'unknown'
  try {
    return semver.gt(latest, current) ? 'update-available' : 'up-to-date'
  } catch {
    return 'unknown'
  }
}

/**
 * Normalize plugin config with defaults.
 * @param {Record<string, unknown>|undefined} config
 * @returns {{checkIntervalMs: number, timeoutMs: number}}
 */
export function resolveConfig(config) {
  const c = config ?? {}
  return {
    checkIntervalMs: Number.isFinite(c.checkIntervalMs) && c.checkIntervalMs > 0 ? c.checkIntervalMs : 21600000, // 6h
    timeoutMs: Number.isFinite(c.timeoutMs) && c.timeoutMs > 0 ? c.timeoutMs : 5000,
  }
}
```

- [ ] **Step 2.4: Run the tests to verify they pass**

Run: `cd <repo> && pnpm test -- test/domain.test.js`
Expected: PASS, 9 tests.

- [ ] **Step 2.5: Commit**

```bash
cd <repo> && git add src/domain.js test/domain.test.js && git commit -m "feat: pure domain logic for update decision"
```

---

### Task 3: Host wiring (`src/index.js`)

**Files:**
- Create: `<repo>/src/index.js`
- Test: `<repo>/test/host.test.js`

- [ ] **Step 3.1: Write the failing test `<repo>/test/host.test.js`**

```js
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { apply, resolveInstalledVersion } from '../src/index.js'

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

function makeFakeCtx() {
  const effects = []
  const injects = []
  const ctx = {
    effect: (fn, label) => { effects.push({ fn, label }); return () => {} },
    inject: (deps, fn) => { injects.push({ deps, fn }) },
    logger: { warn: vi.fn() },
  }
  return { ctx, effects, injects }
}

describe('resolveInstalledVersion', () => {
  it('reads version from a resolvable package.json', () => {
    // Our own package.json is resolvable from the test file's URL.
    const version = resolveInstalledVersion(import.meta.url, './package.json')
    expect(version).toBe('0.1.0')
  })
  it('returns null when the package cannot be resolved', () => {
    expect(resolveInstalledVersion(import.meta.url, './definitely-missing-package/package.json')).toBeNull()
  })
})

describe('apply', () => {
  let fetchMock
  beforeEach(() => { fetchMock = vi.fn(); vi.stubGlobal('fetch', fetchMock) })
  afterEach(() => { vi.unstubAllGlobals(); vi.useRealTimers() })

  it('polls the registry, caches the result, and serves it over the webServer route', async () => {
    vi.useFakeTimers()
    fetchMock.mockResolvedValue({
      ok: true,
      json: async () => ({ 'dist-tags': { latest: '9.9.9' } }),
    })

    const { ctx, effects, injects } = makeFakeCtx()
    apply(ctx, {})
    // The poll loop effect registered with a 10s first-run delay.
    expect(effects[0].label).toBe('dsh-update-notifier: check loop')

    await vi.advanceTimersByTimeAsync(10000)
    expect(fetchMock).toHaveBeenCalledTimes(1)
    expect(fetchMock.mock.calls[0][0]).toBe('https://registry.npmjs.org/@deepseek-ai%2fdsh')

    // webServer is optional; a headless composition gets no route.
    expect(injects).toHaveLength(1)
    expect(injects[0].deps).toEqual(['webServer'])

    const webCtx = { effect: (fn) => fn(), webServer: { register: vi.fn() } }
    injects[0].fn(webCtx)
    expect(webCtx.webServer.register).toHaveBeenCalledTimes(1)
    const { path, handler } = webCtx.webServer.register.mock.calls[0][0]
    expect(path).toBe('/dsh-update-check')

    const res = { writeHead: vi.fn(), end: vi.fn() }
    await handler({ method: 'GET', url: '/dsh-update-check' }, res)
    const body = JSON.parse(res.end.mock.calls[0][0])
    // Host installed version is '0.1.0' (own package.json) vs latest 9.9.9.
    expect(body.state).toBe('update-available')
    expect(body.current).toBe('0.1.0')
    expect(body.latest).toBe('9.9.9')

    // force=1 triggers an immediate re-check (with 2s cooldown).
    await vi.advanceTimersByTimeAsync(3000)
    await handler({ method: 'GET', url: '/dsh-update-check?force=1' }, res)
    expect(fetchMock).toHaveBeenCalledTimes(2)
    vi.useRealTimers()
  })

  it('rejects non-GET methods with 405', async () => {
    const { ctx, injects } = makeFakeCtx()
    apply(ctx, {})
    const webCtx = { effect: (fn) => fn(), webServer: { register: vi.fn() } }
    injects[0].fn(webCtx)
    const { handler } = webCtx.webServer.register.mock.calls[0][0]
    const res = { writeHead: vi.fn(), end: vi.fn() }
    await handler({ method: 'POST', url: '/dsh-update-check' }, res)
    expect(res.writeHead).toHaveBeenCalledWith(405, { Allow: 'GET, HEAD' })
    expect(res.end).toHaveBeenCalledWith()
  })

  it('marks the state error and logs when the registry call fails', async () => {
    vi.useFakeTimers()
    fetchMock.mockRejectedValue(new Error('ECONNRESET'))
    const { ctx, effects, injects } = makeFakeCtx()
    apply(ctx, {})
    await vi.advanceTimersByTimeAsync(10000)
    const webCtx = { effect: (fn) => fn(), webServer: { register: vi.fn() } }
    injects[0].fn(webCtx)
    const { handler } = webCtx.webServer.register.mock.calls[0][0]
    const res = { writeHead: vi.fn(), end: vi.fn() }
    await handler({ method: 'GET', url: '/dsh-update-check' }, res)
    const body = JSON.parse(res.end.mock.calls[0][0])
    expect(body.state).toBe('error')
    expect(body.error).toBe('ECONNRESET')
    expect(ctx.logger.warn).toHaveBeenCalledWith('[dsh-update-notifier] check failed: ECONNRESET')
    vi.useRealTimers()
  })
})
```

- [ ] **Step 3.2: Run the test to verify it fails**

Run: `cd <repo> && pnpm test -- test/host.test.js`
Expected: FAIL — `Cannot find module '../src/index.js'`.

- [ ] **Step 3.3: Create `<repo>/src/index.js`**

```js
/**
 * dsh-update-notifier — server half.
 *
 * 1. Resolves the installed `@deepseek-ai/dsh` version once at startup.
 * 2. Polls the npm registry for the `latest` dist-tag (default every 6h,
 *    first run 10s after startup, never blocking).
 * 3. Caches the decision and serves it on `GET /dsh-update-check`
 *    (`?force=1` re-checks with a 2s cooldown) via the optional `webServer`
 *    service, so headless compositions are unaffected.
 *
 * @module dsh-update-notifier
 */
import { createRequire } from 'node:module'
import { decideUpdateState, parseRegistryLatest, REGISTRY_URL, resolveConfig } from './domain.js'

export { decideUpdateState, parseRegistryLatest, REGISTRY_URL, resolveConfig } from './domain.js'

export const name = 'dsh-update-notifier'

/**
 * Resolve the installed DSH version from its published package.json.
 * @param {string} [fromUrl] - base URL for module resolution (defaults to this module).
 * @param {string} [specifier] - package.json specifier to resolve.
 * @returns {string|null} version string, or null when unresolvable.
 */
export function resolveInstalledVersion(fromUrl, specifier = '@deepseek-ai/dsh/package.json') {
  try {
    const requireFrom = createRequire(fromUrl ?? import.meta.url)
    const version = requireFrom(specifier).version
    return typeof version === 'string' && version.length > 0 ? version : null
  } catch {
    return null
  }
}

/**
 * Install the check loop and the optional web route.
 * @param {import('@deepseek-ai/cordis').Context} ctx - plugin context.
 * @param {Record<string, unknown>|undefined} config - row config from cordis.patch.yml.
 */
export function apply(ctx, config) {
  const conf = resolveConfig(config)
  const current = resolveInstalledVersion()

  /** @type {{state: string, current: string|null, latest: string|null, fetchedAt: number, error: string|null}} */
  let cache = { state: 'checking', current, latest: null, fetchedAt: 0, error: null }
  let inflight = null

  const check = () => {
    if (inflight !== null) return inflight
    inflight = (async () => {
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), conf.timeoutMs)
      try {
        const res = await fetch(REGISTRY_URL, { signal: controller.signal })
        if (!res.ok) throw new Error(`registry HTTP ${res.status}`)
        const latest = parseRegistryLatest(await res.json())
        cache = {
          state: decideUpdateState({ current, latest }),
          current,
          latest,
          fetchedAt: Date.now(),
          error: latest === null ? 'malformed-registry-response' : null,
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        // Stale-while-error: keep the last good state once one exists.
        cache = {
          state: cache.state === 'checking' ? 'error' : cache.state,
          current,
          latest: cache.latest,
          fetchedAt: cache.fetchedAt,
          error: message,
        }
        ctx.logger?.warn(`[dsh-update-notifier] check failed: ${message}`)
      } finally {
        clearTimeout(timer)
        inflight = null
      }
    })()
    return inflight
  }

  ctx.effect(() => {
    let timer = null
    const run = () => {
      void check().then(() => {
        timer = setTimeout(run, conf.checkIntervalMs)
      })
    }
    timer = setTimeout(run, 10000) // first check 10s after startup
    return () => clearTimeout(timer)
  }, 'dsh-update-notifier: check loop')

  // Optional webServer: serve the cached decision to the browser half.
  ctx.inject(['webServer'], (webCtx) => {
    webCtx.effect(() => webCtx.webServer.register({
      kind: 'exact',
      path: '/dsh-update-check',
      async handler(req, res) {
        if (req.method !== 'GET' && req.method !== 'HEAD') {
          res.writeHead(405, { Allow: 'GET, HEAD' })
          res.end()
          return
        }
        const parsedUrl = new URL(req.url ?? '/', 'http://127.0.0.1')
        const force = parsedUrl.searchParams.get('force') === '1'
        if (force && (Date.now() - cache.fetchedAt > 2000 || cache.state === 'checking')) {
          await check()
        }
        const body = JSON.stringify(cache)
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-store',
          'Content-Length': Buffer.byteLength(body),
        })
        res.end(req.method === 'HEAD' ? undefined : body)
      },
    }), 'dsh-update-notifier: route')
  })
}
```

- [ ] **Step 3.4: Run the tests to verify they pass**

Run: `cd <repo> && pnpm test -- test/host.test.js`
Expected: PASS, 5 tests.

- [ ] **Step 3.5: Commit**

```bash
cd <repo> && git add src/index.js test/host.test.js && git commit -m "feat: host half — registry poll loop and /dsh-update-check route"
```

---

### Task 4: Pure client logic (`client/core.js`)

**Files:**
- Create: `<repo>/client/core.js`
- Test: `<repo>/test/client-core.test.js`

- [ ] **Step 4.1: Write the failing test `<repo>/test/client-core.test.js`**

```js
import { describe, expect, it } from 'vitest'
import { decideDotVisible, formatTimeAgo, parseCheckPayload } from '../client/core.js'

describe('parseCheckPayload', () => {
  it('parses a valid payload', () => {
    expect(parseCheckPayload({ state: 'update-available', current: '0.1.0-rc.5', latest: '0.1.0-rc.6', fetchedAt: 100, error: null }))
      .toEqual({ state: 'update-available', current: '0.1.0-rc.5', latest: '0.1.0-rc.6', fetchedAt: 100, error: null })
  })
  it('rejects malformed payloads', () => {
    expect(parseCheckPayload(null)).toBeNull()
    expect(parseCheckPayload('x')).toBeNull()
    expect(parseCheckPayload({})).toBeNull()
    expect(parseCheckPayload({ state: 42 })).toBeNull()
  })
})

describe('decideDotVisible', () => {
  const available = { state: 'update-available', current: 'a', latest: 'b', fetchedAt: 1, error: null }
  it('visible only for update-available, unsnoozed, unignored', () => {
    expect(decideDotVisible(available, null, false)).toBe(true)
    expect(decideDotVisible(available, 'b', false)).toBe(false) // ignored this version
    expect(decideDotVisible(available, 'a', false)).toBe(true)  // older ignore does not apply
    expect(decideDotVisible(available, null, true)).toBe(false) // snoozed
  })
  it('hidden for any other state', () => {
    for (const state of ['checking', 'up-to-date', 'unknown', 'error']) {
      expect(decideDotVisible({ ...available, state }, null, false)).toBe(false)
    }
    expect(decideDotVisible(null, null, false)).toBe(false)
  })
})

describe('formatTimeAgo', () => {
  it('formats ages', () => {
    const now = 60 * 60 * 1000
    expect(formatTimeAgo(0, now)).toBe('never')
    expect(formatTimeAgo(now - 500, now)).toBe('just now')
    expect(formatTimeAgo(now - 5 * 60000, now)).toBe('5m ago')
    expect(formatTimeAgo(now - 3 * 3600000, now)).toBe('3h ago')
    expect(formatTimeAgo(now - 26 * 3600000, now)).toBe('1d ago')
  })
})
```

- [ ] **Step 4.2: Run the test to verify it fails**

Run: `cd <repo> && pnpm test -- test/client-core.test.js`
Expected: FAIL — `Cannot find module '../client/core.js'`.

- [ ] **Step 4.3: Create `<repo>/client/core.js`**

```js
/**
 * dsh-update-notifier: pure client-side helpers (no DOM, unit-testable).
 * @module dsh-update-notifier/client/core
 */

/**
 * Validate a /dsh-update-check payload into a plain object.
 * @param {unknown} payload
 * @returns {{state: string, current: string|null, latest: string|null, fetchedAt: number, error: string|null}|null}
 */
export function parseCheckPayload(payload) {
  if (payload === null || typeof payload !== 'object') return null
  if (typeof payload.state !== 'string') return null
  return {
    state: payload.state,
    current: typeof payload.current === 'string' ? payload.current : null,
    latest: typeof payload.latest === 'string' ? payload.latest : null,
    fetchedAt: Number.isFinite(payload.fetchedAt) ? payload.fetchedAt : 0,
    error: typeof payload.error === 'string' ? payload.error : null,
  }
}

/**
 * Dot visibility: update available, not snoozed, not ignored (ignore is
 * latest-version string equality — no semver needed in the browser bundle).
 * @param {{state: string, latest: string|null}|null} payload
 * @param {string|null} ignoredVersion
 * @param {boolean} snoozed
 * @returns {boolean}
 */
export function decideDotVisible(payload, ignoredVersion, snoozed) {
  if (snoozed) return false
  if (payload === null || payload.state !== 'update-available') return false
  if (payload.latest === null) return false
  if (ignoredVersion !== null && ignoredVersion === payload.latest) return false
  return true
}

/**
 * Human-friendly age for the panel's "last checked" line.
 * @param {number} fetchedAt - epoch ms, 0 = never.
 * @param {number} [now] - injectable clock for tests.
 * @returns {string}
 */
export function formatTimeAgo(fetchedAt, now = Date.now()) {
  if (fetchedAt <= 0) return 'never'
  const minutes = Math.max(0, Math.floor((now - fetchedAt) / 60000))
  if (minutes < 1) return 'just now'
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.floor(hours / 24)}d ago`
}
```

- [ ] **Step 4.4: Run the tests to verify they pass**

Run: `cd <repo> && pnpm test -- test/client-core.test.js`
Expected: PASS, 5 tests.

- [ ] **Step 4.5: Commit**

```bash
cd <repo> && git add client/core.js test/client-core.test.js && git commit -m "feat: pure client logic for dot visibility and payload parsing"
```

---

### Task 5: Browser bundle (`client/client.js`)

**Files:**
- Create: `<repo>/client/client.js`
- Test: `<repo>/test/client-smoke.test.js`

- [ ] **Step 5.1: Write the failing smoke test `<repo>/test/client-smoke.test.js`**

```js
// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const captured = {}
let bundleApply = null
let bundleInject = null

beforeEach(async () => {
  vi.resetModules()
  window.__ModuleLoader__ = {
    load: ({ id, factory }) => {
      captured.id = id
      const requireStub = (name) => {
        if (name === 'react') return require('react')
        throw new Error(`unexpected require: ${name}`)
      }
      captured.exports = factory(requireStub)
    },
  }
  await import('../client/client.js')
  bundleApply = captured.exports.apply
  bundleInject = captured.exports.inject
})

afterEach(() => {
  delete window.__ModuleLoader__
})

describe('client bundle registration', () => {
  it('loads under the expected module id with inject=["slots"]', () => {
    expect(captured.id).toBe('dsh-update-notifier')
    expect(bundleInject).toEqual(['slots'])
  })

  it('registers the sidebar.footer.action slot on apply', () => {
    const register = vi.fn(() => () => {})
    const ctx = { effect: (fn) => { fn(); return () => {} }, slots: { register } }
    bundleApply(ctx)
    expect(register).toHaveBeenCalledTimes(1)
    const [meta, component] = register.mock.calls[0]
    expect(meta).toMatchObject({ name: 'sidebar.footer.action', id: 'dsh-update-notifier' })
    expect(typeof component).toBe('function')
  })
})
```

- [ ] **Step 5.2: Run the test to verify it fails**

Run: `cd <repo> && pnpm test -- test/client-smoke.test.js`
Expected: FAIL — the dynamic import of `../client/client.js` errors (file missing) and `bundleApply` stays undefined.

- [ ] **Step 5.3: Create `<repo>/client/client.js`** — self-contained lazy bundle (mirrors dsh-balance's shape; the three pure helpers are intentional inline copies of `client/core.js`, kept in sync by review — the bundle cannot import the ESM module):

```js
/**
 * dsh-update-notifier — browser half (lazy client bundle).
 *
 * Registers a `sidebar.footer.action` entry in the sidebar footer:
 * a version badge that lights a red dot when the host reports a newer
 * @deepseek-ai/dsh release on npm. The panel shows current vs latest,
 * last-checked time, and offers: open npm, ignore this version,
 * snooze, and re-check now. Polls /dsh-update-check every 5 minutes.
 */
if (typeof window !== 'undefined' && typeof window.__ModuleLoader__ !== 'undefined') {
  window.__ModuleLoader__.load({
    id: 'dsh-update-notifier',
    factory: (require) => {
      var module = { exports: {} }
      var exports = module.exports
      var react = require('react')

      var CHECK_PATH = '/dsh-update-check'
      var NPM_PAGE = 'https://www.npmjs.com/package/@deepseek-ai/dsh'
      var IGNORE_KEY = 'dsh-update-notifier.ignoredVersion'
      var POLL_MS = 300000

      // ── inline copies of client/core.js (see test/client-core.test.js) ──
      function parsePayload(payload) {
        if (payload === null || typeof payload !== 'object') return null
        if (typeof payload.state !== 'string') return null
        return {
          state: payload.state,
          current: typeof payload.current === 'string' ? payload.current : null,
          latest: typeof payload.latest === 'string' ? payload.latest : null,
          fetchedAt: Number.isFinite(payload.fetchedAt) ? payload.fetchedAt : 0,
          error: typeof payload.error === 'string' ? payload.error : null,
        }
      }
      function dotVisible(payload, ignored, snoozed) {
        if (snoozed) return false
        if (payload === null || payload.state !== 'update-available') return false
        if (payload.latest === null) return false
        if (ignored !== null && ignored === payload.latest) return false
        return true
      }
      function timeAgo(fetchedAt, now) {
        if (fetchedAt <= 0) return 'never'
        var minutes = Math.max(0, Math.floor(((now || Date.now()) - fetchedAt) / 60000))
        if (minutes < 1) return 'just now'
        if (minutes < 60) return minutes + 'm ago'
        var hours = Math.floor(minutes / 60)
        if (hours < 24) return hours + 'h ago'
        return Math.floor(hours / 24) + 'd ago'
      }
      // ── end inline copies ──

      function readIgnored() {
        try { return window.localStorage.getItem(IGNORE_KEY) } catch { return null }
      }
      function writeIgnored(value) {
        try {
          if (value === null) window.localStorage.removeItem(IGNORE_KEY)
          else window.localStorage.setItem(IGNORE_KEY, value)
        } catch { /* storage unavailable: ignore is memory-only for this session */ }
      }

      var CSS_ID = 'dsh-update-notifier/styles.css'
      if (typeof document !== 'undefined' && document.querySelector('style[data-plugin-css="' + CSS_ID + '"]') === null) {
        var tag = document.createElement('style')
        tag.dataset.plugin = 'dsh-update-notifier'
        tag.dataset.pluginCss = CSS_ID
        tag.textContent = [
          '.dsun_root{position:relative;display:inline-flex;align-items:center}',
          '.dsun_btn{display:inline-flex;align-items:center;gap:6px;border:none;background:transparent;cursor:pointer;padding:4px 6px;border-radius:6px;color:var(--dsw-alias-label-secondary,#9ca3af);font-size:12px;line-height:16px}',
          '.dsun_btn:hover{background:var(--dsw-alias-surface-hover,rgba(255,255,255,0.06))}',
          '.dsun_dot{width:7px;height:7px;border-radius:50%;background:transparent;transition:background-color .2s ease}',
          '.dsun_btn_dot .dsun_dot{background:var(--dsw-alias-state-error-primary,#ef4444);box-shadow:0 0 0 2px rgba(239,68,68,0.2)}',
          '.dsun_panel{position:absolute;bottom:calc(100% + 8px);left:0;z-index:9999;min-width:280px;max-width:92vw;background:var(--dsw-alias-surface-elevated,#1e1e24);border:1px solid var(--dsw-alias-border-secondary,rgba(255,255,255,0.08));border-radius:10px;box-shadow:0 12px 32px rgba(0,0,0,0.45);padding:14px 16px;color:var(--dsw-alias-label-primary,#f3f4f6);font-size:12px;line-height:1.5}',
          '.dsun_panel_title{font-weight:600;margin-bottom:8px}',
          '.dsun_row{display:flex;justify-content:space-between;gap:12px;padding:2px 0;color:var(--dsw-alias-label-secondary,#9ca3af)}',
          '.dsun_row b{color:var(--dsw-alias-label-primary,#f3f4f6);font-variant-numeric:tabular-nums}',
          '.dsun_actions{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}',
          '.dsun_actions button{border:1px solid var(--dsw-alias-border-secondary,rgba(255,255,255,0.12));background:transparent;color:var(--dsw-alias-label-primary,#f3f4f6);border-radius:6px;padding:4px 10px;font-size:12px;cursor:pointer}',
          '.dsun_actions button:hover{background:var(--dsw-alias-surface-hover,rgba(255,255,255,0.06))}',
          '.dsun_primary{border-color:var(--dsw-alias-state-info-primary,#3b82f6)!important;color:var(--dsw-alias-state-info-primary,#60a5fa)!important}',
          '.dsun_error{color:var(--dsw-alias-state-error-primary,#f87171)}',
        ].join('\n')
        document.head.appendChild(tag)
      }

      function UpdatePanel(props) {
        var payload = props.payload
        var actions = props.actions
        var rows = []
        rows.push(react.createElement('div', { className: 'dsun_row', key: 'cur' },
          react.createElement('span', null, 'Current'), react.createElement('b', null, payload && payload.current ? payload.current : 'unknown')))
        rows.push(react.createElement('div', { className: 'dsun_row', key: 'lat' },
          react.createElement('span', null, 'Latest'), react.createElement('b', null, payload && payload.latest ? payload.latest : '—')))
        rows.push(react.createElement('div', { className: 'dsun_row', key: 'time' },
          react.createElement('span', null, 'Checked'), react.createElement('b', null, timeAgo(payload ? payload.fetchedAt : 0))))
        if (payload && payload.error) {
          rows.push(react.createElement('div', { className: 'dsun_row dsun_error', key: 'err' },
            react.createElement('span', null, 'Error'), react.createElement('b', null, payload.error)))
        }
        return react.createElement('div', { className: 'dsun_panel' },
          react.createElement('div', { className: 'dsun_panel_title' }, 'dsh-update-notifier'),
          rows,
          react.createElement('div', { className: 'dsun_actions' },
            react.createElement('button', { className: 'dsun_primary', onClick: actions.openNpm }, 'Open npm'),
            react.createElement('button', { onClick: actions.ignore }, 'Ignore this version'),
            react.createElement('button', { onClick: actions.snooze }, 'Later'),
            react.createElement('button', { onClick: actions.refreshNow }, 'Check now')))
      }

      function UpdateAction(props) {
        var wide = props.wide === true
        var useState = react.useState
        var useEffect = react.useEffect
        var useRef = react.useRef
        var useCallback = react.useCallback

        var payloadBox = useState(null)
        var payload = payloadBox[0]
        var setPayload = payloadBox[1]
        var ignoredBox = useState(readIgnored())
        var ignored = ignoredBox[0]
        var setIgnored = ignoredBox[1]
        var snoozedBox = useState(false)
        var snoozed = snoozedBox[0]
        var setSnoozed = snoozedBox[1]
        var openBox = useState(false)
        var open = openBox[0]
        var setOpen = openBox[1]
        var lastFetchedRef = useRef(0)

        var refresh = useCallback(function (force) {
          fetch(CHECK_PATH + (force ? '?force=1' : ''))
            .then(function (r) { return r.json() })
            .then(function (j) {
              var parsed = parsePayload(j)
              setPayload(parsed)
              if (parsed && parsed.fetchedAt !== lastFetchedRef.current) {
                lastFetchedRef.current = parsed.fetchedAt
                setSnoozed(false) // a fresh check result clears the snooze
              }
            })
            .catch(function () { /* keep last payload; the panel shows the last state */ })
        }, [])

        useEffect(function () {
          refresh(false)
          var id = setInterval(function () { refresh(false) }, POLL_MS)
          var onVisibility = function () { if (!document.hidden) refresh(false) }
          document.addEventListener('visibilitychange', onVisibility)
          return function () {
            clearInterval(id)
            document.removeEventListener('visibilitychange', onVisibility)
          }
        }, [refresh])

        var visible = dotVisible(payload, ignored, snoozed)
        var label = payload && payload.latest ? 'v' + payload.latest : 'Update'
        var actions = {
          toggle: function () { setOpen(!open) },
          refreshNow: function () { refresh(true) },
          ignore: function () {
            var latest = payload && payload.latest
            writeIgnored(latest)
            setIgnored(latest)
          },
          snooze: function () { setSnoozed(true); setOpen(false) },
          openNpm: function () { window.open(NPM_PAGE, '_blank', 'noopener') },
        }

        return react.createElement('div', { className: 'dsun_root' },
          react.createElement('button', {
            className: 'dsun_btn' + (visible ? ' dsun_btn_dot' : ''),
            title: 'dsh-update-notifier',
            onClick: actions.toggle,
          },
            react.createElement('span', { className: 'dsun_dot' }),
            wide ? react.createElement('span', { className: 'dsun_label' }, label) : null),
          open ? react.createElement(UpdatePanel, { payload: payload, actions: actions }) : null)
      }

      var inject = ['slots']
      function apply(ctx) {
        ctx.effect(function () {
          var dispose = ctx.slots.register({
            name: 'sidebar.footer.action',
            id: 'dsh-update-notifier',
            order: 100,
          }, UpdateAction)
          return function () { dispose() }
        }, 'dsh-update-notifier: footer action')
      }

      exports.apply = apply
      exports.inject = inject
      return module.exports
    },
  })
}
```

- [ ] **Step 5.4: Run the smoke test to verify it passes**

Run: `cd <repo> && pnpm test -- test/client-smoke.test.js`
Expected: PASS, 2 tests (module id/inject + slot registration meta).

- [ ] **Step 5.5: Run the full suite**

Run: `cd <repo> && pnpm test`
Expected: PASS, all 21 tests across 4 files.

- [ ] **Step 5.6: Commit**

```bash
cd <repo> && git add client/client.js test/client-smoke.test.js && git commit -m "feat: browser bundle — sidebar.footer.action red-dot badge and panel"
```

---

### Task 6: READMEs and publication

**Files:**
- Modify: `<repo>/README.md`, `<repo>/README.zh.md`

- [ ] **Step 6.1: Replace `<repo>/README.md`**

````markdown
# dsh-update-notifier

Red-dot update checker for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) (`dsh`).

Adds an entry to the sidebar footer that lights a red dot whenever the published
[`@deepseek-ai/dsh`](https://www.npmjs.com/package/@deepseek-ai/dsh) `latest` version on npm
is newer than your installed one. Click it for a panel with current → latest,
last-checked time, and actions: open the npm page, ignore this version,
snooze, or re-check now.

**This is a community plugin, not an official DeepSeek product.**

## How it works

- **Host half** (`src/index.js`): resolves your installed DSH version once at startup,
  polls the npm registry (default: first check 10s after startup, then every 6h),
  and serves the cached decision on `GET /dsh-update-check` via the optional
  `webServer` service. Headless compositions are unaffected.
- **Browser half** (`client/client.js`): registers a `sidebar.footer.action` slot entry
  and polls the endpoint every 5 minutes (and on tab focus). "Ignore" persists in
  `localStorage` until a newer version appears; "Later" hides the dot until the next
  fresh check result.

## Install

```sh
dsh plugin --profile web add dsh-update-notifier
```

## Config

Defaults live in `cordis.patch.yml`; override in `$DSH_HOME/profiles/web/cordis.patch.yml`:

```yaml
- id: dsh-update-notifier
  config:
    checkIntervalMs: 21600000   # host re-check interval (default 6h)
    timeoutMs: 5000             # registry fetch timeout (ms)
```

## Development

```sh
pnpm install
pnpm test
```

## License

MIT
````

- [ ] **Step 6.2: Replace `<repo>/README.zh.md`**

````markdown
# dsh-update-notifier

[DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（`dsh`）的社区更新提醒插件。

当 npm 上 [`@deepseek-ai/dsh`](https://www.npmjs.com/package/@deepseek-ai/dsh) 的 `latest`
版本高于你的本地安装版本时，侧边栏左下角图标亮起红点。点击弹出面板：
当前版本 → 最新版本、上次检查时间，以及 [打开 npm 页面] [忽略此版本] [稍后再说] [立即检查]。

**社区插件，非 DeepSeek 官方产品。**

## 原理

- **服务端**（`src/index.js`）：启动时解析本地 DSH 版本；默认启动 10 秒后首次检查 npm
  registry，之后每 6 小时一次；结果缓存在 `GET /dsh-update-check`（可选 `webServer`
  服务，headless 组合不受影响）。
- **浏览器端**（`client/client.js`）：注册 `sidebar.footer.action` 插槽，每 5 分钟轮询一次
  （切回标签页立即刷新）。"忽略此版本"存于 `localStorage`，直到出现更高版本才再次提醒；
  "稍后再说"仅隐藏本次，下一次新检查结果出现时恢复。

## 安装

```sh
dsh plugin --profile web add dsh-update-notifier
```

## 配置

默认值在 `cordis.patch.yml`；覆盖写进 `$DSH_HOME/profiles/web/cordis.patch.yml`：

```yaml
- id: dsh-update-notifier
  config:
    checkIntervalMs: 21600000   # 服务端复查间隔（默认 6 小时）
    timeoutMs: 5000             # registry 请求超时（毫秒）
```

## 开发

```sh
pnpm install
pnpm test
```

## 许可证

MIT
````

- [ ] **Step 6.3: Commit**

```bash
cd <repo> && git add README.md README.zh.md && git commit -m "docs: bilingual README with install and config"
```

- [ ] **Step 6.4: Create the public GitHub repo and push**

```bash
cd <repo>
gh repo create arvin-yd/dsh-update-notifier --public --source . --push
gh repo edit arvin-yd/dsh-update-notifier --add-topic dsh-plugin --add-topic deepseek-harness
```

Expected: repo exists at https://github.com/arvin-yd/dsh-update-notifier with all commits; the ecosystem radar (awesome-dsh-plugins) auto-discovers it within 8h.

- [ ] **Step 6.5: (Optional) Publish to npm so `dsh plugin add dsh-update-notifier` works by name**

Run (only if the user wants npm distribution; radar pickup works without it):
`cd <repo> && npm publish --access public`
Expected: `+ dsh-update-notifier@0.1.0`. Requires `npm login` first.

---

### Task 7: End-to-end verification against the real harness (concrete, time-boxed)

**Files:** none (verification only). Uses the clone at `/tmp/dsh-contrib/deepseek-harness` (master is `0.1.0-rc.5`; npm `latest` is `0.1.0-rc.6`, so a working install MUST show the red dot).

- [ ] **Step 7.1: Build the harness web app**

```bash
cd /tmp/dsh-contrib/deepseek-harness
pnpm install
pnpm run build:lib
pnpm run build:web
```

Expected: exit 0 (takes several minutes; the earlier `build:lib:host` pass in this repo is precedent).

- [ ] **Step 7.2: Install the plugin into a web profile (local dir form)**

```bash
cd /tmp/dsh-contrib/deepseek-harness
node apps/cli/lib/bin.js plugin --profile web add /tmp/dsh-contrib/dsh-update-notifier
node apps/cli/lib/bin.js --profile web web
```

Expected: server starts; `curl http://127.0.0.1:<port>/dsh-update-check` returns JSON with `"state":"update-available"`, `"current":"0.1.0-rc.5"`, `"latest":"0.1.0-rc.6"`.

- [ ] **Step 7.3: Verify the UI badge**

Open the served Web UI in a browser. Expected: the sidebar footer shows the badge with a red dot and `v0.1.0-rc.6`; the panel shows Current `0.1.0-rc.5` → Latest `0.1.0-rc.6`; "Ignore this version" clears the dot and it survives a page reload.

- [ ] **Step 7.4: Record the verification**

Append a short `VERIFICATION.md` to `<repo>` with the date, dsh version, endpoint JSON output, and UI screenshot description; commit:

```bash
cd <repo> && git add VERIFICATION.md && git commit -m "docs: end-to-end verification against dsh 0.1.0-rc.5"
```

If the local harness cannot be brought up (environment limits), skip 7.2-7.3, note it in `VERIFICATION.md`, and rely on the 21-test vitest suite plus the registration smoke test as the completion evidence.

---

## Self-Review

**Spec coverage:** current-version → Task 3 `resolveInstalledVersion`; version-source → Task 3 `check()`; update-service state machine → Task 2 `decideUpdateState` + Task 4 `decideDotVisible` (ignored layered client-side, deviation #1 documented); check-scheduler → Task 3 (10s first / 6h loop / `?force=1` manual); state-store → Task 5 localStorage with guarded memory fallback (deviation #2 documented); ui → Task 5; error handling → Tasks 3 & 5 (405/error state/stale-while-error/panel error row); testing → Tasks 2-5; release → Task 6. All spec sections covered.

**Placeholder scan:** every step carries complete code or exact commands; no TBD/TODO; no "similar to Task N".

**Type/name consistency:** `parseRegistryLatest`, `decideUpdateState`, `resolveConfig`, `resolveInstalledVersion`, `parseCheckPayload`, `decideDotVisible`, `formatTimeAgo` are defined once and referenced identically in tests; endpoint path `/dsh-update-check` and `IGNORE_KEY` match across host/client/tests; plugin id `dsh-update-notifier` matches in package.json, cordis.patch.yml, bundle id, and slot registration.
