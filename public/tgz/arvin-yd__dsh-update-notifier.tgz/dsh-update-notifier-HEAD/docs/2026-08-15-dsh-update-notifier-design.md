# dsh-update-notifier — 设计文档（spec v1）

> 状态：已获用户批准（2026-08-15）｜作者：arvin-yd｜许可证：MIT
> 关联愿景：《DSH 飞书私人助手 — 整体架构文档》的能力层之外围体验组件，独立成库。

## 1. 目标

在 DeepSeek Harness（DSH）Web UI 的侧边栏左下角（官方 `sidebar.footer.action` 插槽）
常驻一个更新提醒按钮：检测到 npm 上 `@deepseek-ai/dsh` 的 `latest` 版本高于本地安装版本时
亮红点，点击弹出面板查看版本对比并跳转更新。

**为什么需要**：DSH 官方几乎每日发版（本仓库 rc.5 时 npm latest 已是 rc.6），
社区有"已装插件"更新雷达（dsh-update-radar），但 **DSH 本体** 的更新提醒是生态空白。

## 2. 非目标（v1 YAGNI）

- 自动升级 / 一键升级（仅提示与跳转）
- changelog 拉取（npm registry 不提供 changelog 接口）
- 设置页、自定义检查间隔、next 通道
- 会话内提示、推送通知
- 多版本展示

## 3. 决策记录（来自需求澄清）

| 决策点 | 结论 |
|---|---|
| 提醒形态 | 红点 + 点击面板（不打扰） |
| 更新通道 | 只跟 npm `latest` dist-tag，零配置 |
| 检查频率 | 启动后延迟 10s 首查，之后每 6h 轮询 + 面板手动"立即检查" |
| 忽略行为 | "忽略此版本"持久化，直到出现更高版本才重新亮红点 |
| 当前版本来源 | `createRequire` 解析 `@deepseek-ai/dsh/package.json`，失败→unknown（隐藏红点） |
| 版本比较 | `semver.gt`（semver 已在 DSH 依赖树内） |
| UI 挂点 | `sidebar.footer.action`（kind: list, scope: root） |

## 4. 架构与模块

单一 Cordis 插件，包名 `@dsh-external/dsh-update-notifier`，6 个模块：

```text
┌──────────────┐   ┌───────────────┐   ┌──────────────┐
│ current-ver  │──▶│ update-service│◀──│ version-src  │
│ (本地解析)    │   │ (semver 比较)  │   │ (npm latest) │
└──────────────┘   └──────┬───────┘   └──────────────┘
                          │ 结果状态
                ┌─────────▼─────────┐
                │ check-scheduler   │  启动首查(延迟10s)/6h轮询/手动触发
                └─────────┬─────────┘
                ┌─────────▼─────────┐   ┌──────────────┐
                │ state-store       │◀─▶│ ui (footer)  │
                │ ignoredVersion    │   │ 红点+面板      │
                └───────────────────┘   └──────────────┘
```

### 4.1 current-version
- `createRequire(import.meta.url)` 解析 `@deepseek-ai/dsh/package.json` 的 `version` 字段。
- 解析失败（git 安装/路径不可达）→ `{ status: 'unknown' }`，UI 隐藏红点。
- 版本号不符合 semver → `{ status: 'unparseable' }`，不亮红点。

### 4.2 version-source
- GET `https://registry.npmjs.org/@deepseek-ai%2fdsh`，5 秒超时，无外部 CLI 依赖。
- 解析 `dist-tags.latest`；响应异常/超时 → `{ status: 'error' }`。

### 4.3 update-service
- 输入：本地版本 + 远端版本；输出统一状态机：
  `checking | up-to-date | update-available(latest) | ignored | error | unknown`
- 忽略逻辑：`latest > ignoredVersion` 时重新进入 `update-available`。

### 4.4 check-scheduler
- 插件挂载后延迟 10 秒首查（避免拖慢启动）；之后每 6 小时轮询。
- 面板"立即检查"手动触发；检查全程异步、绝不阻塞 UI/启动。
- 上次检查时间与结果状态进入 UI 面板展示。

### 4.5 state-store
- 通过 DSH storage 服务持久化 `{ ignoredVersion: string | null, lastCheckedAt, lastResult }`。
- 无 storage 服务时降级为内存态（重启后重查，无副作用）。

### 4.6 ui
- 注册 `sidebar.footer.action`（root scope）图标按钮。
- 宽侧栏态：图标 + "新版本 vX.Y.Z" 文案 + 红点；折叠 rail 态：仅图标 + 红点。
- 点击弹面板：当前版本 → 最新版本、上次检查时间、按钮组
  [前往 npm 页面] [忽略此版本] [稍后再说] [立即检查]。
  - "稍后再说"：不持久化，仅隐藏本次提醒；下一次检查（6h 后或重启）若仍可用则再次亮红点。
  - "忽略此版本"：持久化，直到出现更高版本才重新亮红点。
- `error` 态面板内显示"上次检查失败"，不弹全局错误。

## 5. 数据流

```text
启动 → (10s) 首查 → current-version + version-source 并行
     → update-service 状态机 → state-store 持久化 → ui 渲染
     → [6h 定时 | 手动] 重复检查
```

## 6. 错误处理

| 场景 | 行为 |
|---|---|
| 网络失败 / registry 异常 / 超时 | 静默；面板显示"上次检查失败"+时间；可手动重试 |
| 本地版本无法解析 | 隐藏红点；面板显示"无法识别本地版本" |
| registry 返回畸形 JSON | 同 error 态，不抛出未捕获异常 |
| storage 不可用 | 内存态降级，功能不受阻 |

## 7. 测试与验证

- **单元测试（vitest，表驱动）**：
  - 版本比较：rc 序列/相等/降级/畸形版本号
  - registry 响应解析：正常 fixture / 缺失 dist-tags / 超时
  - 忽略持久化：ignored → 更高版本出现 → 重新亮红点
  - UI：mock 各状态渲染（红点显隐、rail/wide 文案）
- **端到端验证（真实场景）**：本机安装 rc.5，npm latest=rc.6 → 预期亮红点；
  模拟忽略 rc.6 → 红点消失 → 重启后仍忽略（持久化生效）。
- 验证命令：`pnpm -C <repo> test`、`pnpm -C <repo> typecheck`。

## 8. 发布

- 仓库 `arvin-yd/dsh-update-notifier`（MIT），打 `dsh-plugin` topic → 雷达 8h 内自动收录。
- 安装方式：**以 profile bundle 挂载为主**（对齐社区 project-blueprint 的形态：
  一个 npm 包 + cordis.patch.yml 挂载自身）；实施第一步先镜像一个现有社区插件的
  package.json/cordis.patch.yml 结构，确保与官方当前机制一致。
- 命名：`dsh-*` 社区前缀，注明非官方项目。

## 9. 风险

| 风险 | 应对 |
|---|---|
| registry 字段变更（dist-tags 结构） | 解析失败走 error 态，不影响使用 |
| DSH 版本号跳出 rc 序列（如 1.0.0） | semver 标准比较天然支持 |
| 官方后续自带此功能 | 插件退役成本低；届时在 README 标注"官方已内置" |
