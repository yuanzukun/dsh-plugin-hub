# End-to-End Verification

- **Date:** 2026-08-15
- **Harness:** deepseek-ai/deepseek-harness @ master (`0.1.0-rc.5`), built locally
  (`pnpm install && pnpm run build:lib && pnpm run build:web`, all exit 0)
- **Plugin:** installed via `dsh plugin --profile web add /tmp/dsh-contrib/dsh-update-notifier`
  into an isolated `DSH_HOME=/tmp/dsh-e2e-home`, served with
  `dsh --profile web --port 18777`
- **npm latest at verification time:** `0.1.0-rc.6` (so `update-available` is the expected outcome)

## Endpoint results

`GET http://127.0.0.1:18777/dsh-update-check`:

```json
{"state":"update-available","current":"0.1.0-rc.5","latest":"0.1.0-rc.6","fetchedAt":1786731403694,"error":null}
```

- `?force=1` re-check: `200`, fresh `fetchedAt` (`1786731421672`), same decision — cooldown path OK.
- Web UI root: HTTP 200 (12,272 bytes).
- Server log: no `[dsh-update-notifier]` warnings/errors.

## L4 runtime test (radar protocol, community-run)

- **Date:** 2026-08-15 (UTC+8) · **Mainline:** `47f94385` (`0.1.0-rc.5`) · npm latest `0.1.0-rc.6`
- **Headless task loop** with the official `@deepseek-ai/dsh-llm-mock-server`
  (keyless, `--sequence success`), plugin mounted in the headless profile:

  ```sh
  DEEPSEEK_BASE_URL=http://127.0.0.1:8000/v1 DEEPSEEK_API_KEY=mock-key \
    dsh --profile headless "reply with exactly: hello world"
  ```

  Result: **exit 0**, turn completed (`mock response recovered`), **0 plugin errors** —
  the plugin neither blocked nor corrupted the agent loop.
- **Web runtime re-check** (fresh boot, same mainline):
  `GET /dsh-update-check` → `{"state":"update-available","current":"0.1.0-rc.5","latest":"0.1.0-rc.6",...,"updateHint":"npm install -g @deepseek-ai/dsh@latest"}`.
- Unit suite: 25/25 (vitest + jsdom registration smoke).

## Notes

1. First E2E run exposed a real defect: with `link:`-installed dev plugins, the
   plugin directory cannot resolve `@deepseek-ai/dsh`, so `current` was `null`
   (state `unknown`). Fixed with multi-probe resolution
   (commit `ad4d119`): plugin location → running `dsh` bin (`process.argv[1]`) →
   walk-up probe for any `@deepseek-ai/dsh*` package.json (covers monorepo dev
   clones whose root package is `@deepseek-ai/dsh-root`).
2. The browser half (red dot, panel, ignore/snooze) is verified by the jsdom
   registration smoke test; a manual UI click-through on a desktop browser is
   the remaining optional step.
