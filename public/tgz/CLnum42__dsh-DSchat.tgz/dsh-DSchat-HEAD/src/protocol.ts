/**
 * Shared wire surface of dsh-DSchat: API paths, transcript data model, and
 * engine status views. Imported by both the host routes and the browser panel
 * (the client bundle inlines it — there is no shared runtime identity).
 */

/** How one DSchat message was produced (drives the panel's message rendering). */
export type DSchatRole = 'user' | 'assistant'

/**
 * One source a web reply cites.
 *
 * The web numbers its SOURCES 1..M per answer, and writes `[citation:N]` into
 * the markdown — the marker carries no URL, so without this table a citation
 * could only ever render as a bare number (the reported "显示为数字注释，点不开").
 * The engine collects the URLs while the reply streams (and from the web's own
 * stored fragments when recovering a conversation), in the very order the web
 * numbered them, so `sources[N - 1]` IS citation N.
 */
export interface DSchatSource {
  readonly url: string
  /** The result's title when the page reported one. */
  readonly title?: string
}

/** One transcript message (markdown text). */
export interface DSchatMessage {
  /** Local stable id. */
  readonly id: string
  readonly role: DSchatRole
  /** Markdown body. */
  readonly content: string
  /** Unix epoch ms. */
  readonly ts: number
  /** True while the engine is still streaming this message. */
  readonly streaming?: boolean
  /** Set when the exchange failed (content may be partial). */
  readonly error?: string
  /**
   * How long the model spent on this reply's reasoning, in ms.
   *
   * Measured by the engine while the reply streamed: from the first reasoning
   * fragment to the first answer fragment (see `streamReply`). It is the only
   * honest source for the panel's 「已思考（用时 X 分 Y 秒）」 line — the page's
   * own timer is not part of the stored transcript.
   *
   * Absent for a reply that carried no reasoning, for one still thinking, and
   * for a transcript RECOVERED from the web (the history endpoint stores the
   * reasoning text but no timing), where the panel says 「已思考」 with no
   * duration rather than inventing one.
   */
  readonly thinkingMs?: number
  /** Local absolute paths of images attached to a user message. */
  readonly attachments?: string[]
  /**
   * Search sources this reply cites, in the web's own citation order.
   *
   * Absent when the reply used no search (and for transcripts recovered from
   * the DOM, where the page exposes no URL table).
   */
  readonly sources?: readonly DSchatSource[]
}

/** One web chat session transcript (persisted locally). */
export interface DSchatTranscript {
  readonly id: string
  title: string
  readonly createdAt: number
  updatedAt: number
  /** Model the chat currently runs on the web (deepseek-chat / deepseek-reasoner). */
  model: string
  /** Replaced wholesale when a recover brings back a more complete history. */
  messages: DSchatMessage[]
  /** True while an assistant reply is streaming. */
  streaming: boolean
  /**
   * Web session id (`/a/chat/s/<id>`) this transcript was recovered from.
   *
   * This — not the title — is a web conversation's real identity: titles
   * repeat, get renamed, and the old title-only dedup made a second recover of
   * the same conversation a no-op (so a short import could never be repaired).
   *
   * Since v0.8 the panel stamps it on the conversation the user is chatting in
   * (see `DeepSeekWebEngine.stampWebSessionId`), which is what lets a LATER
   * sync recognize that conversation instead of importing a second copy of it.
   */
  webSessionId?: string
  /**
   * True when the reader pinned this conversation to the top of the list.
   *
   * The local counterpart of the web's own 置顶: the pinned rows are listed
   * above everything else, under their own 「置顶」 heading. Persisted here
   * rather than read from the web on every render because it is the reader's
   * own arrangement of THEIR list — the panel's list is not the web's list, so
   * it cannot borrow the web's pin state wholesale. A conversation synced for
   * the first time still INHERITS the web's `pinned` flag once, on creation.
   */
  pinned?: boolean
  /** Epoch ms of the pin, used to order the pinned rows newest-first. */
  pinnedAt?: number
}

/**
 * One conversation as the LIST routes report it: no message bodies.
 *
 * `/state` used to answer with every transcript in full — 5.86 MB on this
 * machine's 215-conversation store, re-sent every 1.5 s to a panel that renders
 * one conversation. The summary is what the parts that scan the list actually
 * need: the sidebar row, the counts, the streaming flag (`phaseOf` reads it) and
 * the delta logic. Anything that needs the text asks `/chat` for that ONE
 * conversation — see {@link DSchatChatView}.
 */
export interface DSchatChatSummary {
  readonly id: string
  readonly title: string
  readonly createdAt: number
  readonly updatedAt: number
  readonly model: string
  readonly streaming: boolean
  /** How many messages the conversation has (the sidebar's row label). */
  readonly messageCount: number
  readonly webSessionId?: string
  /** True when the reader pinned this conversation (see {@link DSchatTranscript}). */
  readonly pinned?: boolean
  readonly pinnedAt?: number
}

/**
 * A summary with its messages attached — what the panel renders.
 *
 * `loaded` distinguishes "this conversation is empty" from "its body has not
 * been fetched yet", which the message list alone cannot say. A chat that is not
 * loaded renders as a summary and is fetched the moment it is opened.
 */
export interface DSchatChatView extends DSchatChatSummary {
  readonly messages: DSchatMessage[]
  readonly loaded?: boolean
}

/**
 * The panel's own snapshot: the wire state, with whichever bodies it has fetched.
 *
 * `mergeTail` and every renderer work on this, so the summarization happened at
 * the transport edge and nowhere else.
 */
export interface DSchatView extends Omit<DSchatState, 'chats'> {
  readonly chats: DSchatChatView[]
}

/** One conversation as listed by the web sidebar. */
export interface WebChatSummary {
  title: string
  /**
   * Session id carried by the row's own `/a/chat/s/<id>` href. Absent only if
   * the markup changed; callers then fall back to title matching.
   */
  sessionId?: string
  /**
   * The web account's own 置顶 flag.
   *
   * Read from `/api/v0/chat_session/fetch_page` (the DOM has no such field —
   * the pinned rows simply render under a 「置顶」 heading). A conversation
   * synced for the first time inherits it, so a fresh install starts out
   * arranged the way the web already had it.
   */
  pinned?: boolean
  /**
   * The web's own `updated_at`, in epoch ms (the endpoint reports seconds).
   *
   * Real conversation time, as opposed to the moment of the local import: the
   * sidebar's date groups (今天 / 昨天 / …) are derived from it, and the local
   * list used to show the sync run's clock for every conversation it touched.
   * Absent on the DOM fallback, which has no timestamps at all.
   */
  updatedAt?: number
}

/**
 * Where a recovered transcript actually came from.
 *
 * `history-api` — the page's own authenticated history endpoint (one request,
 * the whole conversation, markdown + thinking).
 * `page-cache` — the app's persisted IndexedDB cache (used when the endpoint
 * is unavailable, and after opening a conversation the page had not cached).
 * `dom` — last resort: open the conversation and harvest the virtualised list.
 */
export type RecoverSource = 'history-api' | 'page-cache' | 'dom'

/** What syncing one web conversation into the local store produced. */
export interface RecoverResult {
  readonly ok: boolean
  readonly chatId?: string
  readonly title?: string
  readonly sessionId?: string
  /** True when a new local transcript was created. */
  readonly created?: boolean
  /** True when an existing transcript changed at all. */
  readonly updated?: boolean
  /**
   * Messages the store did not have and the sync appended.
   *
   * A sync is a MERGE: the messages already stored keep their ids, timestamps
   * and locally measured extras, and only what was missing is written. These
   * four counters are what the panel and the agent report back, so a reader can
   * tell "3 new turns" from "1 truncated reply completed".
   */
  readonly added?: number
  /** Stored messages the web had written out in full (a truncated copy, completed). */
  readonly completed?: number
  /** Stored messages whose text the web changed (an edit or a regeneration). */
  readonly replaced?: number
  /** Stored messages the web copy does not contain (kept, never dropped). */
  readonly kept?: number
  /** Number of messages the web copy carried. */
  readonly messageCount?: number
  readonly source?: RecoverSource
  /**
   * True when the web answered `40029 TOO_MANY_REQUESTS`.
   *
   * Its own flag rather than a sentence in `error`, because the batch sync has
   * to ACT on it: hammering the history endpoint for every conversation in a
   * long list earns a rate limit part-way through, and the old behaviour —
   * silently treating the throttled answer as "the endpoint has nothing" and
   * falling through to opening each conversation in the page — turned a
   * one-second read into a navigation per conversation. The reader is told to
   * wait and try again instead.
   */
  readonly rateLimited?: boolean
  readonly error?: string
}

/**
 * Structured engine error codes so callers (panel / agent tools) can act on a
 * failure instead of only printing it: NEED_LOGIN → prompt the login window;
 * PAGE_CHANGED → the DeepSeek page/stream protocol moved and the plugin likely
 * needs an upgrade; TIMEOUT → generation exceeded the reply window; NETWORK →
 * browser launch / HTTP / connectivity failure.
 */
export type DSchatErrorCode = 'NEED_LOGIN' | 'PAGE_CHANGED' | 'TIMEOUT' | 'NETWORK' | 'BUSY'

/**
 * Every structured code a `/api/dsh-dschat` route can fail with.
 *
 * A superset of the engine's codes, because the routes fail for reasons the
 * engine never sees. Every failure carries one so the PANEL can render its own
 * localized sentence (`tr('error.' + code)`) instead of printing the host's
 * Chinese detail into an English interface — which is what it used to do for
 * every one of these, since only five of the routes answered with a code at all.
 *
 * `error` still travels beside the code: it is the specific, technical detail
 * (which path, which field, what the OS said), used as the fallback when a code
 * has no sentence yet and read by the agent tools, which have no dictionary.
 */
export type DSchatApiCode =
  | DSchatErrorCode
  /** The route's own trust fence refused the request (not from this machine). */
  | 'LOOPBACK'
  /** A destructive route was reached with the wrong HTTP method. */
  | 'METHOD'
  /** Cross-origin request: `Origin`/`Sec-Fetch-Site` did not name this server. */
  | 'ORIGIN'
  /** Missing or stale `x-dschat-token`. */
  | 'CSRF'
  /** A path outside the directory the route is allowed to touch. */
  | 'PATH'
  /** A required field is missing or malformed. */
  | 'BAD_REQUEST'
  /** The request body was too large to read. */
  | 'TOO_LARGE'
  /** The named conversation / attachment / session does not exist. */
  | 'NOT_FOUND'
  /** A host-side failure with no better classification (a write, an export). */
  | 'INTERNAL'

/** Coarse engine state for the panel. */
export type EngineState = 'stopped' | 'launching' | 'ready' | 'error'

/**
 * The fine-grained phase the panel's status gauge renders. Derived from the
 * coarse state plus login/busy/streaming so the user always sees which step the
 * engine is on — the single biggest "why is nothing happening" complaint about
 * the previous panel.
 */
export type DSchatPhase =
  | 'stopped'
  | 'launching'
  | 'need-login'
  | 'ready'
  | 'thinking'
  | 'streaming'
  | 'error'

/** Snapshot the panel polls. */
export interface DSchatState {
  readonly engine: EngineState
  readonly engineError?: string
  /** null = unknown yet; false = browser up but not logged in; true = chat page ready. */
  readonly loggedIn: boolean | null
  readonly pageUrl?: string
  /** Deep-think (R1) toggle state read from the page. */
  readonly deepThink: boolean
  /** Internet-search toggle state read from the page. */
  readonly search: boolean
  readonly activeChatId?: string
  /**
   * Conversation SUMMARIES. The message bodies live behind `/chat?id=`, because
   * this snapshot is polled every 1.5 s and used to carry the whole store.
   */
  readonly chats: DSchatChatSummary[]
  /** True while a message is being sent / replied (serialized engine busy). */
  readonly busy: boolean
  /**
   * True while a just-created chat's page work is still on the engine queue.
   * The panel has already switched to the empty conversation; this drives the
   * "preparing" hint so the pause is explained instead of looking stuck.
   */
  readonly preparingNewChat?: boolean
  /** Epoch ms when the current turn started (panel renders the elapsed timer). */
  readonly busySince?: number
  /** Last send error, transient for the panel to display. */
  readonly lastError?: string
  /** Structured code for the last error (so the panel can show a targeted action). */
  readonly lastErrorCode?: DSchatErrorCode
  /**
   * A transcript-store problem (an unreadable file that was quarantined, or a
   * write that failed), reported once so the reader learns it before the
   * history looks inexplicably empty.
   */
  readonly storeWarning?: string
  /**
   * Per-run CSRF token the panel echoes in `x-dschat-token` on every mutating
   * call. Delivered here because `/state` is already the panel's first request;
   * see the routes module header for why the fence needs it.
   */
  readonly csrfToken?: string
  /** The RUNNING bundle's version (injected at build time; '' in a raw bundle). */
  readonly version?: string
  /** ISO timestamp of that build. */
  readonly build?: string
}

/**
 * One streaming tail response — the cheap, high-frequency feed the panel uses
 * while a reply is in flight.
 *
 * `/state` answers with the WHOLE store (2.6 MB on a 108-chat history) and, on
 * the way out, asks the page for its toggle states; polling that at the ~100 ms
 * a smooth reply needs would cost more than the reply itself. `/tail` answers
 * with one message, expressed as a delta against what the previous response
 * handed over, so a tick usually carries a few dozen new characters.
 */
export interface DSchatTail {
  readonly ok: boolean
  /** Chat this tail describes (the requested one, or the active chat). */
  readonly chatId?: string
  readonly activeChatId?: string
  /** True while a turn is in flight — the panel's signal to keep tailing. */
  readonly busy: boolean
  readonly busySince?: number
  /** The chat's own streaming flag. */
  readonly streaming: boolean
  readonly title?: string
  readonly updatedAt?: number
  readonly messageCount?: number
  /**
   * The chat's last assistant message, as `content = local.slice(0, head) + tail`.
   *
   * `head` is the length of the prefix this message shares with what the
   * PREVIOUS tail response carried; a `head` of 0 means the client's copy was
   * not usable (it desynced, or the message is new) and `tail` is the whole
   * body. Applying that one rule is all the client needs.
   */
  readonly message?: {
    readonly id: string
    readonly role: DSchatRole
    readonly ts: number
    readonly streaming: boolean
    readonly error?: string
    /**
     * Reasoning duration in ms, once the model has started answering.
     *
     * Carried on the tail — not only on the finished message — because the
     * label under the reasoning is rendered the moment the reasoning ends, and
     * the answer then streams for another minute with the tail as the only
     * feed.
     */
    readonly thinkingMs?: number
    /** Full content length in UTF-16 units (the client's next `at`). */
    readonly length: number
    readonly head: number
    readonly tail: string
    /**
     * Search sources collected so far, in citation order.
     *
     * Carried on the tail — not only on the finished message — because the
     * source URLs arrive DURING the reply (the search step precedes the answer
     * that cites it), so a citation chip can be clickable the moment it renders.
     */
    readonly sources?: readonly DSchatSource[]
  } | null
  readonly error?: string
}

/**
 * True when a stored reply body carries answer text AFTER its thinking block.
 *
 * The engine renders reasoning and answer into ONE markdown string, with the
 * reasoning wrapped in a leading `<details>` block. That makes the boundary
 * between 「还在思考」 and 「开始回答」 a property of the string, and both halves
 * need it: the engine times the reasoning with it (from the first snippet of
 * reasoning to the first snippet of answer), and the panel renders the two
 * halves apart.
 *
 * A message with no thinking block at all is all answer, so any content counts.
 * An UNTERMINATED block counts as "no answer yet" — the closer is written by the
 * engine only once the reasoning is complete, so its absence means the model is
 * still thinking.
 *
 * @param markdown - the stored message body.
 */
export function hasAnswerBody(markdown: string): boolean {
  const text = markdown.trimStart()
  if (!text.startsWith('<details>')) return text !== ''
  const close = text.indexOf('</details>')
  if (close < 0) return false
  return text.slice(close + '</details>'.length).trim() !== ''
}

/**
 * A finished thinking block, matched only at the START of a message.
 *
 * The closing tag is required: while the model is still reasoning the engine has
 * only written the opener (see {@link hasAnswerBody}), and treating the text
 * after an unterminated `</summary>` as the answer would hand the reader half a
 * chain of thought in place of a reply.
 */
const THINKING_BLOCK = /^<details>\s*<summary>[^<]*<\/summary>([\s\S]*?)<\/details>/

/** True for the engine thinking wrapper, closed or still streaming. */
export function opensWithThinking(content: string): boolean {
  return content.trimStart().startsWith('<details>')
}

/**
 * Answer text of a stored assistant message: the content with a LEADING thinking
 * block removed.
 *
 * Conservative on purpose — only a block that OPENS the message counts, so a
 * reply that legitimately discusses `<details>` further down is untouched.
 * A block whose closer has not arrived yet has no answer to hand back, so this
 * returns '' rather than the reasoning.
 *
 * Shared by the panel (复制 / 引用 read the answer, never the reasoning) and the
 * host half's transfer (a harness session gets the conversation, not the
 * scratchpad and the pages it browsed).
 *
 * @param content - the stored message body.
 */
export function answerBody(content: string): string {
  const text = content.trimStart()
  if (!text.startsWith('<details>')) return content.trim()
  const closed = THINKING_BLOCK.exec(text)
  if (closed === null) return ''
  return text.slice(closed[0].length).trim()
}

/**
 * Reasoning text of a stored assistant message, '' when it carries none.
 *
 * Used only where the EXACT source text matters (复制思考过程), so whitespace is
 * preserved as the model produced it.
 *
 * @param content - the stored message body.
 */
export function thinkingBody(content: string): string {
  const text = content.trimStart()
  if (!text.startsWith('<details>')) return ''
  const closed = THINKING_BLOCK.exec(text)
  if (closed !== null) return (closed[1] ?? '').trim()
  const opener = text.indexOf('</summary>')
  return opener < 0 ? '' : text.slice(opener + '</summary>'.length).trim()
}

/**
 * Derive the panel phase from a state snapshot. Pure so both halves (and tests)
 * agree on what the gauge shows.
 */
export function phaseOf(state: Pick<DSchatState, 'engine' | 'loggedIn' | 'busy' | 'chats'>): DSchatPhase {
  if (state.engine === 'error') return 'error'
  if (state.engine === 'launching') return 'launching'
  if (state.engine === 'stopped') return state.loggedIn === false ? 'need-login' : 'stopped'
  if (state.loggedIn === false) return 'need-login'
  if (state.busy) return state.chats.some(chat => chat.streaming) ? 'streaming' : 'thinking'
  return 'ready'
}

/**
 * Normalize a wire source list.
 *
 * POSITIONS ARE THE CONTRACT (`sources[N - 1]` is `[citation:N]`), so an entry
 * is never dropped — that would renumber every source after it and silently
 * point a claim at the wrong page. An entry the page did not name a URL for is
 * kept as an empty-url placeholder and renders as a plain, unclickable chip.
 * Only a wholly empty table becomes `undefined` (a reply that cited nothing has
 * no table at all).
 *
 * @param input - the list as it arrived (`undefined`/empty = no search).
 */
export function sourcesOf(input: readonly DSchatSource[] | undefined): DSchatSource[] | undefined {
  if (input === undefined || input.length === 0) return undefined
  // Trailing placeholders carry no number anyone can cite, so they are trimmed;
  // an interior one must stay (see above).
  let end = input.length
  while (end > 0 && (input[end - 1]?.url ?? '') === '') end--
  if (end === 0) return undefined
  return input.slice(0, end).map(source => (source?.title === undefined ? { url: source?.url ?? '' } : { url: source.url, title: source.title }))
}

/**
 * True when two source tables are the same list.
 *
 * The tail resends the whole table (numbering is positional), so without this
 * every tick would produce a fresh array and defeat React's identity bail-out —
 * the panel folds a tail ~10×/s.
 */
export function sameSources(left: readonly DSchatSource[] | undefined, right: readonly DSchatSource[] | undefined): boolean {
  if (left === right) return true
  if (left === undefined || right === undefined) return false
  if (left.length !== right.length) return false
  return left.every((source, index) => source.url === right[index]?.url && source.title === right[index]?.title)
}

/**
 * Fold one {@link DSchatTail} response into the panel's snapshot.
 *
 * The other half of the /tail contract: the host computes `head`/`tail` from
 * what it last sent, and this applies it as `content.slice(0, head) + tail`.
 * Both live here — rather than one on each side — because they are one
 * agreement, and a change to either that the other does not follow is a
 * corrupted transcript rather than a visible error.
 *
 * Returns the SAME object when nothing changed, which matters: the panel folds
 * a response in ~10×/s and React bails out of re-rendering only on identity.
 * Pure, so the merge is testable without a browser.
 */
export function mergeTail(state: DSchatView, tail: DSchatTail): DSchatView {
  const status = {
    busy: tail.busy,
    busySince: tail.busySince,
    activeChatId: tail.activeChatId ?? state.activeChatId,
  }
  const statusChanged = state.busy !== status.busy
    || state.busySince !== status.busySince
    || state.activeChatId !== status.activeChatId

  const chatId = tail.chatId
  const chatIndex = chatId === undefined ? -1 : state.chats.findIndex(chat => chat.id === chatId)
  const message = tail.message ?? null
  if (chatIndex < 0 || message === null) return statusChanged ? { ...state, ...status } : state

  const chat = state.chats[chatIndex]
  // A conversation whose body has not been fetched holds no messages; the tail
  // then starts it from the delta alone, which is exactly `head: 0`.
  const position = (chat.messages ?? []).findIndex(item => item.id === message.id)
  const existing = position < 0 ? undefined : chat.messages[position]
  const content = (existing?.content ?? '').slice(0, message.head) + message.tail
  /*
   * Sources are sent whole on every tail (small, and numbering must never be
   * patched up incrementally), so an arrival is either a new table or the same
   * one — compare by URL list to keep React's identity bail-out working.
   */
  const sources = sourcesOf(message.sources) ?? existing?.sources
  const sourcesChanged = !sameSources(existing?.sources, sources)
  /*
   * The reasoning duration arrives ONCE, on the first tail after the answer
   * starts. It is never cleared: a tail that omits it (an older host, a tick
   * that raced the measurement) must not make the label fall back to 「思考中」.
   */
  const thinkingMs = message.thinkingMs ?? existing?.thinkingMs
  const messageChanged = existing === undefined
    || existing.content !== content
    || existing.streaming !== message.streaming
    || existing.error !== message.error
    || existing.thinkingMs !== thinkingMs
    || sourcesChanged
  const chatChanged = chat.streaming !== tail.streaming
    || (tail.updatedAt !== undefined && chat.updatedAt !== tail.updatedAt)
  if (!messageChanged && !chatChanged && !statusChanged) return state

  const merged: DSchatMessage = {
    ...(existing ?? {}),
    id: message.id,
    role: message.role,
    content,
    ts: message.ts,
    streaming: message.streaming,
    error: message.error,
    ...(thinkingMs === undefined ? {} : { thinkingMs }),
    ...(sources === undefined ? {} : { sources }),
  }
  return {
    ...state,
    ...status,
    chats: state.chats.map((item, i) => (i === chatIndex
      ? {
          ...item,
          streaming: tail.streaming,
          updatedAt: tail.updatedAt ?? item.updatedAt,
          /*
           * The count follows the body. A tail that APPENDS a message is the one
           * case where the sidebar would otherwise understate a conversation
           * until the next `/state` — and it is the visible case, because the
           * reply the reader is watching is the message being counted.
           */
          messageCount: position < 0 ? item.messageCount + 1 : item.messageCount,
          messages: position < 0
            ? [...item.messages, merged]
            : item.messages.map((candidate, j) => (j === position ? merged : candidate)),
        }
      : item)),
  }
}

/** Engine-level operation results surfaced to agent tools. */
export interface SendResult {
  readonly ok: boolean
  readonly chatId?: string
  readonly reply?: string
  readonly error?: string
  /** Structured error code (when ok is false) for actionable handling. */
  readonly code?: DSchatErrorCode
  /**
   * True when the USER message reached the transcript even though the turn
   * failed (the reply never started).
   *
   * The panel needs this to know what a failed send means: `stored` set means
   * the message is already visible in the conversation and the right repair is
   * 「重试」, while `stored` unset means nothing was recorded and the draft must
   * go back into the composer — putting it back in the other case would
   * duplicate the message on the next send.
   */
  readonly stored?: boolean
  /**
   * True when the turn ended because someone asked it to (a stop click, the
   * agent's `dschat_stop`) rather than because the reply finished.
   *
   * Carried so `ok: true` is not read as "the model said all of this": the
   * reply is what had been generated when the turn was ended, and the agent's
   * render says so.
   */
  readonly stopped?: boolean
}

/** Result of transferring a transcript into harness mode. */
export interface TransferResult {
  readonly ok: boolean
  readonly sessionId?: string
  readonly filePath?: string
  /** True when the session was attached to a workspace (grouped); false = ungrouped. */
  readonly attached?: boolean
  /** Workspace id the session landed in, when attached. */
  readonly workspaceId?: string
  /** True when the brief was appended to an existing session instead of a new one. */
  readonly continued?: boolean
  readonly error?: string
}

/**
 * The hand-off text a transfer WOULD write (the `/transfer-preview` answer).
 *
 * Carried whole so the panel can show the reader exactly what will become the
 * new session's first message — and edit it — before anything is created.
 */
export interface TransferPreview {
  readonly ok: boolean
  /** The exact markdown that will seed the session, including the provenance footer. */
  readonly markdown?: string
  /** True when an LLM brief was produced. */
  readonly distilled?: boolean
  /** The mode actually used after the config default was applied. */
  readonly mode?: TransferMode
  /** True when distillation was requested but could not run (raw text is used). */
  readonly fallback?: boolean
  /** Why not, in the reader's terms — present only when `fallback`. */
  readonly fallbackReason?: string
  readonly provider?: string
  readonly model?: string
  readonly error?: string
}

/**
 * How a transfer seeds the new harness session: 'distill' condenses the web
 * conversation into an executable task brief via the harness LLM; 'raw'
 * replays the full transcript verbatim. The web panel lets the user choose.
 */
export type TransferMode = 'distill' | 'raw'

/**
 * Result of `wake` (and of `openLoginWindow`): whether a usable page is up, and
 * whether it is the user's turn.
 *
 * `loginWindow` is the flag the panel acts on: when it is true a VISIBLE window
 * is already open and waiting for a human, so the panel must NOT ask for one
 * again — asking used to dispose the fresh window and open a second one.
 */
export interface WakeResult {
  readonly ok: boolean
  /** null = no page to judge; false = the page is on the sign-in screen. */
  readonly loggedIn: boolean | null
  /** True when this call actually launched a browser. */
  readonly launched: boolean
  /** True when a visible login window is (now) open and waiting for the user. */
  readonly loginWindow?: boolean
  /** True when a live page was reused instead of a new one being launched. */
  readonly reused?: boolean
  readonly error?: string
}

/** API path constants shared by host routes and the browser panel. */
export const DSCHAT_API = {
  state: '/api/dsh-dschat/state',
  /**
   * The per-run CSRF token on its own, for a client that must re-arm after a
   * host restart without paying for a whole `/state` snapshot.
   */
  token: '/api/dsh-dschat/token',
  /**
   * Cheap streaming feed: one message, as a delta. Polled fast while a reply is
   * in flight; `/state` stays the slow, authoritative, whole-store snapshot.
   */
  tail: '/api/dsh-dschat/tail',
  context: '/api/dsh-dschat/context',
  /**
   * Start the web engine for someone who wants to type, in the right mode.
   *
   * Split from `openLogin` because they are different requests: this one means
   * "I want to chat" (reuse the persisted session, stay out of the way), while
   * `openLogin` means "give me the visible window" and is the escalation taken
   * only when the wake reports a sign-in page.
   */
  /**
   * One conversation WITH its messages.
   *
   * The counterpart of the summarized `/state`: the panel asks for the body of
   * the conversation it is about to render, and of the one a reply is streaming
   * into. `id` omitted means the active conversation.
   */
  chat: '/api/dsh-dschat/chat',
  /**
   * Which conversations contain a string, answered by the HOST.
   *
   * The panel used to filter the list by scanning every message it held, which
   * only worked because `/state` carried the whole store. With summaries there
   * is nothing local to scan, and fetching 215 bodies to answer one keystroke is
   * worse than the problem being solved — so the scan happens where the data is.
   *
   * NAMED APART FROM `search` ON PURPOSE: that key is the WEB-SEARCH toggle
   * (`/search`, a POST with `{ enabled }`), and an earlier revision gave this
   * route the same key. A later key silently wins in an object literal, so
   * `DSCHAT_API.search` resolved to the toggle and this route became
   * unreachable: every message search was a POST-less GET to a write-guarded
   * route, i.e. a 405 the panel reported to nobody. `route-surface.test.ts`
   * now fails when two endpoints share a key.
   */
  searchConversations: '/api/dsh-dschat/search-conversations',
  wake: '/api/dsh-dschat/wake',
  openLogin: '/api/dsh-dschat/open-login',
  closeBrowser: '/api/dsh-dschat/close-browser',
  newChat: '/api/dsh-dschat/new-chat',
  restore: '/api/dsh-dschat/restore',
  attach: '/api/dsh-dschat/attach',
  /**
   * Read one stored attachment's bytes back, for the composer's thumbnails.
   *
   * A GET carrying the absolute path of a file `attach` already wrote. The host
   * answers 404 when that path is outside the attachment directory, has been
   * pruned, or is not a file — the composer then falls back to a name-only chip
   * rather than showing a broken image.
   */
  attachment: '/api/dsh-dschat/attachment',
  send: '/api/dsh-dschat/send',
  /**
   * 重新生成 one answer: re-ask its question and REPLACE the reply.
   *
   * A separate route from `send` because the transcript operation is different,
   * not the browser work: `send` appends a new turn, this one reuses a question
   * already stored and removes the answer it replaces (see
   * `DeepSeekWebEngine.regenerate`). Going through `send` would have shown the
   * question twice.
   */
  regenerate: '/api/dsh-dschat/regenerate',
  /**
   * 分享 one answer: create a PUBLIC link for it on the reader's web account.
   *
   * NOT a clipboard action: the page's own 分享 is `POST /api/v0/share/create`
   * behind a confirm dialog whose body is the warning 「任何获得链接的人都可以查看
   * 你分享的对话」. The panel asks for that confirmation before it calls this.
   */
  share: '/api/dsh-dschat/share',
  /**
   * 点赞 / 点踩 one answer ON THE WEB PAGE.
   *
   * The feedback lives on the reader's DeepSeek account, not in this store, so
   * the engine finds the answer's own row in the page and presses the page's own
   * control. `chatId` + `messageId` are the local identity of the answer; the
   * host resolves them to the page's row.
   */
  feedback: '/api/dsh-dschat/feedback',
  stop: '/api/dsh-dschat/stop',
  deepThink: '/api/dsh-dschat/deep-think',
  /** The WEB-SEARCH toggle (a POST with `{ enabled }`) — not conversation search. */
  search: '/api/dsh-dschat/search',
  transfer: '/api/dsh-dschat/transfer',
  /**
   * Build the hand-off text without writing it, so the reader can see (and
   * edit) what a transfer would put in the new session's first message.
   */
  transferPreview: '/api/dsh-dschat/transfer-preview',
  exportFile: '/api/dsh-dschat/export',
  /**
   * Remember the folder 「导出 markdown」 should write into.
   *
   * Set from the export dialog (the native picker, or a path typed by hand) and
   * persisted on the host, so every later export — and the settings card — uses
   * the reader's last choice without asking again.
   */
  exportDir: '/api/dsh-dschat/export-dir',
  renameChat: '/api/dsh-dschat/rename',
  deleteChat: '/api/dsh-dschat/delete',
  /**
   * Pin / unpin one conversation in the local list (the 置顶 of the web's own
   * sidebar). A local arrangement — the web's own pin state is only READ, to
   * seed a conversation the first time it is synced.
   */
  pinChat: '/api/dsh-dschat/pin',
  clearChats: '/api/dsh-dschat/clear',
  webChats: '/api/dsh-dschat/web-chats',
  recover: '/api/dsh-dschat/recover',
  /**
   * Mirror the web's 置顶 flags and conversation times onto conversations that
   * are ALREADY stored. Separate from `recover` because it reads no history:
   * one request fixes the arrangement of the whole list.
   */
  syncPins: '/api/dsh-dschat/sync-pins',
  /**
   * Read-only diagnostics for the page scrapers. Exists because a failed
   * recover used to report only "读取网页会话历史失败（页面可能已改版）", which
   * cannot be acted on; this reports what the page actually contains.
   */
  probePage: '/api/dsh-dschat/probe-page',
} as const
