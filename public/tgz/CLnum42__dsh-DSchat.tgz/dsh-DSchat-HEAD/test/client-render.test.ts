/**
 * Render smoke test for the browser half.
 *
 * A panel that throws while rendering blanks its slot entry (the shell logs
 * `slot entry crashed in '<slot>'` and renders nothing), and that failure is
 * invisible until someone opens the UI. This test renders both components to
 * static markup with React itself, so a bad element, a broken hook or a
 * mistyped prop fails here instead of in front of the user.
 *
 * Effects do not run under static rendering, which is exactly what we want: the
 * assertion is "the initial screen renders", not "the network works".
 *
 * Run with: node --test test/
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { build } from 'esbuild'
import { mkdtempSync, rmSync } from 'node:fs'

import { join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const root = join(fileURLToPath(new URL('.', import.meta.url)), '..')

/**
 * Bundle the two panel components into one importable ESM file.
 *
 * React stays external and the bundle is written INSIDE the package, so both
 * the bundle and `react-dom/server` resolve the same React instance — two
 * copies would null the hook dispatcher and fail every render.
 */
async function loadComponents() {
  const dir = mkdtempSync(join(root, '.tmp-client-test-'))
  const outfile = join(dir, 'components.mjs')
  const entry = join(dir, 'entry.tsx')
  const { writeFileSync } = await import('node:fs')
  writeFileSync(entry, `
    export { DSchatPanel, thoughtLabel, openExternalLink } from ${JSON.stringify(join(root, 'src/client/panel/DSchatPanel.tsx'))}
    export { DSchatStatus } from ${JSON.stringify(join(root, 'src/client/panel/DSchatStatus.tsx'))}
    export { Markdown, Thinking, SourceList, sourceRows } from ${JSON.stringify(join(root, 'src/client/panel/Markdown.tsx'))}
    export { MessageActions, messageActions } from ${JSON.stringify(join(root, 'src/client/panel/answer-actions.tsx'))}
    export { QaPicker, qaTurns, selectableTurns, selectedMessageIds } from ${JSON.stringify(join(root, 'src/client/panel/qa-picker.tsx'))}
  `, 'utf8')
  await build({
    entryPoints: [entry],
    outfile,
    bundle: true,
    format: 'esm',
    platform: 'node',
    jsx: 'automatic',
    logLevel: 'silent',
    external: ['react', 'react-dom', 'react/jsx-runtime', 'react/jsx-dev-runtime'],
  })
  const mod = await import(pathToFileURL(outfile).href)
  const server = await import('react-dom/server')
  const react = await import('react')
  return { ...mod, renderToStaticMarkup: server.renderToStaticMarkup, createElement: react.createElement, dir }
}

/** A stub API whose every call stays pending — static rendering never awaits. */
function stubApi() {
  const never = new Promise(() => undefined)
  return {
    state: () => never,
    context: () => never,
    send: () => never,
    stop: () => never,
    newChat: () => never,
    wake: () => never,
    openLogin: () => never,
    closeBrowser: () => never,
    setDeepThink: () => never,
    setSearch: () => never,
    transfer: () => never,
    exportFile: () => never,
    renameChat: () => never,
    deleteChat: () => never,
    clearChats: () => never,
    webChats: () => never,
    recover: () => never,
    restore: () => never,
    attach: () => never,
  }
}

const deps = {
  api: stubApi() as never,
  tt: (key: string) => key,
  openSession: () => undefined,
  pickDirectory: async () => null,
  createWorkspace: async () => ({ workspaceId: 'w', title: 'w' }),
}

test('DSchatPanel renders its initial screen', async () => {
  const { DSchatPanel, renderToStaticMarkup, createElement, dir } = await loadComponents()
  try {
    const html = renderToStaticMarkup(createElement(DSchatPanel, deps as never))
    assert.ok(html.length > 0, 'panel produced markup')
    // The shell of the panel, the list's trigger and its composer must all be
    // present. The list's PANEL is not: it returns null while closed, and a
    // static render has no localStorage, which means the documented default —
    // open — applies. See the open/closed test below for the other half.
    assert.match(html, /dsh-dschat-header/)
    assert.match(html, /dsh-dschat-tbtn-sessions/)
    assert.match(html, /dsh-dschat-composer/)
    assert.match(html, /dsh-dschat-phase/)
    // With no snapshot yet the status gauge must read as not-started, not blank.
    assert.match(html, /status\.stopped/)
    assert.match(html, /empty\.title/)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * The append target list comes from the shell's own session list (`main`'s
 * `useSessions` standard prop). Rendering with that hook present is the smoke
 * test for the selector plumbing: a hook-order slip or a bad snapshot shape
 * would throw here instead of inside the running panel.
 */
/**
 * The composer's tool row, asserted on real markup rather than on the source.
 *
 * Three controls in two groups, in the order the reader uses them: 深度思考 and
 * 智能搜索 on the left, then the spacer, then 附件 immediately left of the send
 * circle. The pills describe what the message will ask for; 附件 and 发送 both
 * act on it now, so they sit together on the right — the grouping
 * chat.deepseek.com's own composer uses (its paperclip is the send button's
 * left-hand neighbour).
 *
 * 「上传文件」 is a bare glyph now, matching chat.deepseek.com's own composer, so
 * the words live on the accessible name rather than in the row. The assertion
 * reads them from there: a control whose label only exists in a tooltip is
 * invisible to a screen reader, and that is the failure this guards.
 */
test('the composer groups 深度思考 + 智能搜索 on the left, 附件 + 发送 on the right', async () => {
  const { DSchatPanel, renderToStaticMarkup, createElement, dir } = await loadComponents()
  try {
    const html = renderToStaticMarkup(createElement(DSchatPanel, deps as never))
    const header = html.slice(html.indexOf('dsh-dschat-header'), html.indexOf('dsh-dschat-body'))
    const composer = html.slice(html.indexOf('dsh-dschat-composer'))

    assert.equal(/toggle\.deepThink|toggle\.search/.test(header), false, 'the toggles are not header chrome')
    assert.match(composer, /dsh-dschat-toggle/, '深度思考 / 智能搜索 render as composer pills')

    const think = composer.indexOf('toggle.deepThink')
    const search = composer.indexOf('toggle.search')
    /*
     * The LAST spacer, not the first.
     *
     * The action row above the card (会话列表 / 搜索 / 新对话 … DSH 迁移) has one
     * of its own, and it comes first in the markup. The grouping this test
     * guards is the TOOL row's, one spacer further down.
     */
    const spacer = composer.lastIndexOf('dsh-dschat-spacer')
    const upload = composer.indexOf('composer.upload')
    const send = composer.indexOf('dsh-dschat-send')
    assert.ok(think > -1 && search > -1 && upload > -1, 'all three controls are in the tool row')
    assert.ok(think < search, '深度思考 comes before 智能搜索')
    assert.ok(spacer > search, 'the spacer separates the two groups')
    assert.ok(spacer < upload, '附件 is on the RIGHT of the spacer, with the send control')
    assert.ok(upload < send, 'and immediately LEFT of 发送, where the page puts its paperclip')
    // The hidden Finder input travels with the button it belongs to.
    assert.ok(composer.indexOf('dsh-dschat-fileinput') > spacer, 'the file input moved with it')
    assert.match(composer, /dsh-dschat-attach/, 'the attach control is the official glyph button')
    assert.match(composer, /aria-label="composer\.upload"/, 'and it still names itself for assistive tech')
    // The two pills wear the web app's own artwork, not a bolt and a globe.
    assert.match(composer, /viewBox="0 0 16 16"/, 'the pills carry inline SVG glyphs')

    // No second attach affordance: the paperclip that opened the in-app file
    // browser is gone, so the hidden Finder input is the only file control.
    assert.equal(/composer\.attach\.hint/.test(composer), false, 'the duplicate attach button is gone')
    assert.equal(/picker\.open/.test(composer), false, 'and so is the in-app picker it opened')
    assert.match(composer, /dsh-dschat-fileinput/, 'the Finder input stays')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * One click, one browser.
 *
 * Reported: clicking the offline composer started a browser, and typing then
 * started a SECOND one before the conversation worked. The click went to
 * `openLogin` (a headed, always-relaunching window) while the send path went to
 * `ensureBrowser` — two different browsers for one intention.
 *
 * These assertions pin the shape of the fix: focus wakes the engine, and the
 * visible login window is reached only as the wake's escalation. It is a source
 * assertion rather than a rendered one because static rendering never runs a
 * handler; the behaviour behind it is covered against the engine in
 * host-smoke.test.ts ("the first wake on an empty profile...", "one launch
 * serves every concurrent caller").
 */
test('the composer wakes the engine instead of forcing a login window', async () => {
  const { readFileSync } = await import('node:fs')
  const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')

  const input = panel.indexOf("className: 'dsh-dschat-input'")
  const focus = panel.slice(input, panel.indexOf('onChange:', input))
  assert.ok(/void ensureReady\(\)/.test(focus), 'focusing the composer wakes the engine')
  assert.equal(
    /openLogin\(\)/.test(focus), false,
    'focus must not go straight to the visible login window — that is the relaunch that made one click cost two browsers',
  )

  const ready = panel.slice(panel.indexOf('const ensureReady'), panel.indexOf('const retry'))
  assert.ok(ready.includes('api.wake()'), 'the wake is the first request')
  assert.ok(
    ready.indexOf('api.wake()') < ready.indexOf('api.openLogin()'),
    'and the login window is the escalation, not the opening move',
  )
  assert.ok(
    /woken\.loginWindow !== true/.test(ready),
    'a wake that already opened the login window must not be asked for a second one',
  )
  // The panel must also relay the wake's failure instead of silently doing nothing.
  assert.ok(ready.includes('toast.wake.failed'), 'a failed wake is reported')
  // ...and it must survive meeting a host that has no /wake route at all: the
  // browser half is reloaded on its own (a page refresh) while the host half
  // waits for a Harness restart, so the 404 pairing is a real state.
  assert.ok(/HTTP 404/.test(ready), 'a host without /wake falls back instead of breaking the composer')

  /*
   * Enter on a composer whose engine is down wakes it rather than dropping the
   * message: the reader pressed Enter, which is an unambiguous intent. The wake
   * lives in `deliver` — the one path every send takes, whether it was typed or
   * drained from the queue — so there is exactly one place that can forget it.
   */
  const deliver = panel.slice(panel.indexOf('const deliver = useCallback'), panel.indexOf('const drainOutbox'))
  assert.ok(/await ensureReady\(\)/.test(deliver), 'sending wakes a down engine first')
  /*
   * ...and a start that ends on the sign-in screen reports itself in the
   * conversation (with 「打开登录窗口」 on the same card) instead of as a toast.
   */
  assert.ok(deliver.includes("return 'failed'"), 'a failed start hands the message back to the caller')
  assert.ok(panel.includes('engine.notice.needLogin'), 'being signed out is reported as a notice')
})

/**
 * The header's two halves, and the controls that live on the action row instead.
 *
 * The controls exist because the conversation list and 新对话 had no visible
 * entry point: the list was permanent (with no way to give the conversation the
 * full width), and the only 新对话 button sat above that list. They used to live
 * in the header; they now sit in the action row directly above the composer,
 * next to the conversation they act on.
 *
 * The header keeps identity (the whale + the product name) and the engine's
 * state lamp, which is also the entry to the engine menu. 会话列表 has moved
 * between the two strips twice, and the rule that settles it is WHERE ITS PANEL
 * OPENS: the list is a popover that hangs upward off its trigger (the same one
 * 迁移 opens), so the trigger has to sit at the bottom of the panel — in the
 * header, the only room above it is the 52px title strip, and the list would
 * have to open downward over the conversation it lists. See `actions()`.
 *
 * The list's panel IS rendered by default (a reader who has never touched the
 * toggle gets the list), so this asserts the initial screen: the brand, one
 * lamp, the three labelled buttons on the action row, 会话列表 lit as pressed,
 * and the popover on screen with its search box.
 */
test('the header carries the whale mark and the lamp, and the controls moved to the action row', async () => {
  const { DSchatPanel, renderToStaticMarkup, createElement, dir } = await loadComponents()
  const { readFileSync } = await import('node:fs')
  const css = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
  const panelSource = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')
  try {
    const html = renderToStaticMarkup(createElement(DSchatPanel, deps as never))
    const header = html.slice(html.indexOf('dsh-dschat-header'), html.indexOf('dsh-dschat-body'))
    const composer = html.slice(html.indexOf('dsh-dschat-composer'), html.indexOf('dsh-dschat-phase'))
    /*
     * The action row on its own, because the list's POPOVER is rendered inside
     * the composer too (the trigger and its panel share a wrapper), and that
     * panel contains the search box — which legitimately carries
     * `rail.search.hint`. Counting buttons over the whole composer would count
     * the popover's own controls as row verbs, and looking for the search hint
     * there would find the list's box rather than a button.
     */
    const actions = composer.slice(
      composer.indexOf('dsh-dschat-actions'),
      composer.indexOf('dsh-dschat-card'),
    )

    /*
     * Identity first, status after: the whale names the product, the lamp
     * reports whether its engine is up. Both removals have to be asserted as
     * ABSENT, or a later edit could quietly reintroduce a pseudo-button here.
     */
    const brand = header.indexOf('dsh-dschat-brand')
    const lamp = header.indexOf('dsh-dschat-lamp')
    assert.ok(brand > -1, 'the product mark is in the header')
    assert.ok(lamp > -1, 'and the state lamp beside it')
    assert.ok(brand < lamp, 'identity leads, status follows')
    assert.match(header, /brand\.title/, 'the header names the product it is talking to')

    // The mark renders the house artwork at its own ratio, not on the icon grid.
    assert.match(header, /viewBox="0 0 23\.16 17\.04"/, 'the official fish geometry')
    assert.match(header, /data-phase="stopped"/, 'with no snapshot yet it claims nothing')

    /*
     * The conversation's verbs are the ACTION ROW's: 会话列表 / 新对话 on the
     * left, then the two that take something OUT of the panel — 迁移, and
     * 导出 markdown at the very end. All are labelled (dsh-dschat-tbtn) — the
     * row is where a reader looks for "a new chat", so a glyph-only square there
     * was a control they had to already know.
     *
     * 导出 used to be an entry in the title bar's ··· menu. It is asserted HERE,
     * as the row's last button, because that move is the requirement: it is a
     * verb about the conversation, and the reader who wants the conversation in a
     * file should not have to look in a menu — nor find it twice.
     *
     * 会话列表's label is the VISIBLE noun (action.sessions) while its tooltip
     * and accessible name are the sentence, which is why the assertion looks for
     * rail.hide here: the list is rendered (see the comment above), so the
     * trigger says what pressing it will do.
     *
     * 搜索 is deliberately NOT one of them: it duplicated the list's own search
     * box, which is on screen whenever the list is (the default). What it
     * uniquely did — reach search with the list closed — belongs to ⌘K, and the
     * assertion below makes sure ⌘K still does it.
     */
    assert.equal(
      (actions.match(/dsh-dschat-tbtn[" ]/g) ?? []).length, 4,
      'four labelled buttons on the action row',
    )
    const sessions = actions.indexOf('rail.hide')
    const fresh = actions.indexOf('action.newChat.hint')
    const transfer = actions.indexOf('dsh-dschat-tbtn-transfer')
    const exportAt = actions.indexOf('dsh-dschat-tbtn-export')
    assert.ok(sessions > -1 && fresh > -1, 'each button carries its own label')
    assert.ok(sessions < fresh, 'in the order 会话列表, 新对话')
    assert.ok(
      fresh < transfer && transfer < exportAt,
      'the two outbound verbs close the row: 迁移, then 导出 markdown last',
    )
    /*
     * The row has no SEARCH button, and the ⌘K hint is not a button's tooltip
     * either: it sits on the popover's own input, below the trigger, which is
     * where the feature lives. One advertisement, in one place.
     */
    assert.ok(
      actions.indexOf('title="rail.search.hint"') > actions.indexOf('dsh-dschat-listpop'),
      'the ⌘K hint is on the list popover\'s input, not on a row button',
    )
    /*
     * NOT aria-pressed. That attribute belongs to a toggle button, and while the
     * list WAS a column that never went away, "pressed" was the honest reading.
     * A popover is a thing that opens: the state it reports is `aria-expanded`,
     * and the button that owns it is the same one that closes it.
     */
    assert.match(actions, /aria-expanded="true"/, 'the trigger reports an open menu while the list is shown')
    assert.match(actions, /aria-haspopup="dialog"/, 'and says what it opens')
    assert.equal(actions.includes('aria-pressed'), false, 'a popover trigger is not a toggle button')
    for (const key of ['action.sessions', 'action.newChat']) {
      assert.ok(actions.includes(key), `the button carries the visible word for ${key}`)
    }
    /*
     * And the popover itself is a sibling of that button inside one wrapper —
     * the wrapper is what makes `.dsh-dschat-pop` anchor to the trigger rather
     * than to the panel (see the note on the lamp's wrapper for the bug that
     * rule exists to prevent). Its search box is inside the popover, i.e. it
     * advertises the shortcut from the list rather than from the row.
     */
    assert.match(actions, /dsh-dschat-pop-wrap/, 'the trigger and its panel share a positioned wrapper')
    assert.match(actions, /dsh-dschat-listpop/, 'and the panel is the list, not a form')
    assert.ok(
      actions.indexOf('dsh-dschat-listpop') > actions.indexOf('dsh-dschat-tbtn-sessions'),
      'the panel follows the trigger inside that wrapper',
    )

    /*
     * The search it dropped is still reachable, and by the path that has to work
     * in every state: the shortcut goes through `openSearch()`, which opens the
     * list before focusing. The direct `searchRef.current?.focus()` this
     * replaced was a no-op whenever the list was closed — the box is not in the
     * DOM then — so the old code silently lost the shortcut in exactly the state
     * where a keyboard path matters most.
     *
     * Comments are stripped before matching: the fix's own comment names the
     * call it warns against, and prose must not trip a code-level guard.
     */
    const code = panelSource.replace(/\/\*[\s\S]*?\*\//g, '')
    const shortcut = code.slice(
      code.indexOf("event.key.toLowerCase() === 'k'"),
      code.indexOf("event.key === '/'"),
    )
    assert.ok(shortcut.includes('openSearch()'), '⌘K opens the search through the same path the button used')
    assert.equal(
      /searchRef\.current\?\.focus\(\)/.test(shortcut), false,
      'and never focuses the ref directly: it is null while the list is closed',
    )
    /* The list's own box advertises the shortcut it now owns. */
    assert.match(
      panelSource.slice(panelSource.indexOf('dsh-dschat-search')),
      /title: tr\('rail\.search\.hint'\)/,
      'the search box carries the ⌘K hint the removed button used to hold',
    )

    /*
     * The engine menu is at the TITLE BAR's right end — after the drag spacer,
     * i.e. the header's last child — and NOT on the action row. Those four
     * entries (运行状态 / 导出 markdown / 打开登录窗口 / 关闭浏览器) are about the
     * panel and its browser, not about this conversation, and the row below
     * belongs to the conversation.
     */
    const more = header.indexOf('more.hint')
    assert.ok(more > -1, 'the engine menu has a visible home')
    assert.ok(more > header.indexOf('dsh-dschat-spacer'), 'at the title bar\'s right end, after the drag region')
    assert.equal(
      composer.includes('more.hint'), false,
      'and it is no longer on the action row',
    )
    assert.equal(
      (header.match(/dsh-dschat-tbtn[" ]/g) ?? []).length, 1,
      'the header carries exactly one of those buttons: the 「···」',
    )
    assert.equal(
      composer.includes('dsh-dschat-btn-primary'), false,
      'and 迁移 is no longer a filled primary chip inside the row',
    )

    /*
     * The lamp's panel is the status sentence and NOTHING else. It held these
     * same four entries once; a `moreItem` left behind here would mean the menu
     * exists in two places, which is how the header ends up carrying commands
     * twice.
     *
     * The four keys ARE in the header now — the engine menu lives there — so the
     * assertion is that they belong to the MENU and not to the lamp's panel:
     * the panel is one line of text, with no menu rows inside it.
     *
     * The panel itself is closed in a static render (the component returns null
     * for it), so its own positive half — the sentence, and the absence of
     * buttons — is measured in a real browser by scripts/ui-shot.mjs.
     */
    assert.equal(
      composer.includes('dsh-dschat-pop-status') || header.includes('dsh-dschat-pop-status'), false,
      'no panel is rendered until a trigger opens one',
    )
    const lampPanel = css.slice(
      css.indexOf('.dsh-dschat-pop-status .dsh-dschat-lamp-status'),
      css.indexOf('}', css.indexOf('.dsh-dschat-pop-status .dsh-dschat-lamp-status')),
    )
    assert.ok(lampPanel.includes('border-bottom: none'), 'the lamp\'s panel styles the sentence, and only that')
    assert.equal(
      /dsh-dschat-menu-item/.test(css.slice(css.indexOf('.dsh-dschat-pop-status'), css.indexOf('.dsh-dschat-pop-status') + 400)),
      false,
      'and carries no menu rows of its own',
    )

    assert.equal(header.includes('panel.title'), false, 'the redundant panel name is gone')
    assert.equal(header.includes('dsh-dschat-status'), false, 'and so is the status chip')
    assert.equal(header.includes('dsh-dschat-vsep'), false, 'with the divider that framed it')

    /*
     * The header carries the mark and the lamp and NOTHING else. 会话列表 is the
     * one control that came back here once (while the list was a centred dialog)
     * and left again, so this is the assertion that pins the answer: a control
     * whose panel opens upward cannot live in the top strip.
     */
    assert.equal(
      header.includes('dsh-dschat-tbtn-sessions'), false,
      'the list trigger is not in the header: its panel opens upward',
    )
    assert.match(html, /dsh-dschat-listpop/, 'and the list is on screen without any interaction')
    assert.match(html, /dsh-dschat-search/, 'with its search box')
    assert.equal(
      html.includes('dsh-dschat-modal'), false,
      'the list is anchored to its trigger, not a centred dialog',
    )
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * The composer's right-hand keyboard hint is gone.
 *
 * 「⌘K 搜索」 sat between the paperclip and the send circle — the one strip this
 * row has to spare — where a keycap plus a label reads as a second, dead send
 * button. The SHORTCUT still works, so this asserts that the advertisement is
 * gone rather than the feature, and that the controls sharing the row survived.
 */
test('the composer no longer advertises the ⌘K search shortcut', async () => {
  const { DSchatPanel, renderToStaticMarkup, createElement, dir } = await loadComponents()
  try {
    const html = renderToStaticMarkup(createElement(DSchatPanel, deps as never))
    const composer = html.slice(html.indexOf('dsh-dschat-composer'), html.indexOf('dsh-dschat-phase'))
    assert.equal(composer.includes('dsh-dschat-tools-hint'), false, 'no hint span in the tool row')
    assert.equal(composer.includes('⌘K'), false, 'no keycap either')
    assert.equal(composer.includes('composer.hint.search'), false, 'and no locale lookup for it')
    assert.match(composer, /dsh-dschat-toggle/, '深度思考 / 智能搜索')
    assert.match(composer, /dsh-dschat-attach/, '附件')
    assert.match(composer, /dsh-dschat-send/, '发送')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * A closed conversation list is ABSENT, not hidden.
 *
 * The panel reads the choice from localStorage, so both states are reachable in
 * a static render. The list returns `null` rather than a `display: none` box:
 * a hidden subtree keeps its rows in the tab order and its search box focusable,
 * which is a phantom menu nobody can see — the same "controls that are not on
 * screen are still reachable" bug class this panel has already been bitten by
 * once, when a zero-width sidebar kept its resize handle.
 */
test('a closed conversation list leaves the DOM entirely', async () => {
  const { DSchatPanel, renderToStaticMarkup, createElement, dir } = await loadComponents()
  const globals = globalThis as { window?: unknown }
  const hadWindow = 'window' in globals
  const store = new Map<string, string>()
  const render = (): string => renderToStaticMarkup(createElement(DSchatPanel, deps as never))
  try {
    globals.window = {
      localStorage: {
        getItem: (key: string) => store.get(key) ?? null,
        setItem: (key: string, value: string) => { store.set(key, value) },
        removeItem: (key: string) => { store.delete(key) },
      },
    }

    store.set('dsh-dschat.rail.open', '0')
    const closed = render()
    assert.equal(/dsh-dschat-listpop/.test(closed), false, 'no list panel is rendered')
    assert.equal(/dsh-dschat-search/.test(closed), false, 'and no search box survives it')
    assert.equal(/dsh-dschat-item\b/.test(closed), false, 'with no rows in the tab order')
    assert.match(closed, /dsh-dschat-tbtn-sessions/, 'the trigger is still on the action row')
    assert.match(closed, /rail\.show/, 'offering the list back')
    assert.match(closed, /aria-expanded="false"/, 'and reporting itself closed')
    assert.match(closed, /dsh-dschat-composer/, 'while the conversation keeps its composer')

    /*
     * '0' is the only value that means closed: a first-run reader (nothing
     * stored) and any other value both get the list. That default is why the
     * upgrade from the sidebar version opens the list rather than losing it, and
     * it is asserted here because a change to `!== '0'` would be silent.
     */
    store.delete('dsh-dschat.rail.open')
    assert.match(render(), /dsh-dschat-listpop/, 'an unset preference shows the list')
    store.set('dsh-dschat.rail.open', '1')
    assert.match(render(), /dsh-dschat-listpop/, 'and so does an explicit open')
  } finally {
    if (hadWindow) globals.window = undefined
    else delete globals.window
    rmSync(dir, { recursive: true, force: true })
  }
})

test('DSchatPanel renders against the shell session list', async () => {
  const { DSchatPanel, renderToStaticMarkup, createElement, dir } = await loadComponents()
  try {
    const useSessions = (selector: (list: unknown) => unknown) => selector({
      byId: {
        'session-cold': { sessionId: 'session-cold', updatedAt: 20, agentAvailable: false, title: '冷会话' },
        'session-open': { sessionId: 'session-open', updatedAt: 30, agentAvailable: true, running: true, title: '运行中' },
        'session-blank': { sessionId: 'session-blank', updatedAt: 10, agentAvailable: false, blank: true },
      },
    })
    const html = renderToStaticMarkup(createElement(DSchatPanel, { ...deps, useSessions } as never))
    assert.match(html, /dsh-dschat-header/)
    assert.match(html, /dsh-dschat-composer/)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * A citation marker must reach the page it cites.
 *
 * The marker carries a number only, so this is the pair of contracts that make
 * it useful: `[citation:N]` resolves against the reply's OWN source table
 * (positional — `sources[N - 1]`), and the resulting anchor goes through the
 * same click path as any other link. A marker whose source is unknown must stay
 * the plain chip it always was rather than becoming a link to a guessed URL.
 */
test('a citation marker links to the source the reply names, and only then', async () => {
  const { Markdown, createElement, renderToStaticMarkup, dir } = await loadComponents()
  try {
    const written: string[] = []
    const tree = Markdown({
      source: '结论[citation:2]，另有[citation:1,2] 和 [citation:9]。',
      sources: [
        { url: 'https://a.example/1', title: '甲页' },
        { url: 'https://b.example/2' },
      ],
      sourcesLabel: '参考来源（2）',
      onOpenLink: (href: string) => { written.push(href); return true },
    }) as never

    const anchors: Array<Record<string, unknown>> = []
    const walk = (node: unknown): void => {
      if (Array.isArray(node)) { for (const child of node) walk(child); return }
      if (node === null || typeof node !== 'object') return
      const element = node as { type?: unknown; props?: Record<string, unknown> }
      if (element.type === 'a' && element.props !== undefined) anchors.push(element.props)
      walk(element.props?.children)
    }
    walk(tree)

    // Three citation links: the third marker names a source that does not
    // exist, so it stays a plain chip. The source ROWS are collapsed (they are
    // covered by `sourceRows` below), which is why they are not counted here.
    assert.equal(anchors.length, 3, 'every known citation is a link')
    assert.equal(anchors[0]?.href, 'https://b.example/2', 'citation 2 is the SECOND source')
    assert.equal(anchors[1]?.href, 'https://a.example/1', 'a list marker expands in order')
    assert.equal(anchors[2]?.href, 'https://b.example/2')
    assert.equal(anchors[0]?.target, '_blank', 'an unrouted click still falls back to the system browser')

    let prevented = 0
    ;(anchors[0]?.onClick as (event: unknown) => void)({ button: 0, preventDefault: () => { prevented++ } })
    assert.deepEqual(written, ['https://b.example/2'], 'the citation click reaches the panel link handler')
    assert.equal(prevented, 1, 'and the anchor does not ALSO open a window')

    const html = renderToStaticMarkup(tree)
    assert.ok(html.includes('参考来源（2）'), 'the source list is labelled, with its count')
    assert.ok(html.includes('dsh-dschat-citation'), 'the chips keep their class')
    assert.ok(html.includes('>9<'), 'a citation with no source is still shown, as a plain chip')
    assert.equal(html.includes('dsh-dschat-source-no'), false, 'the rows are collapsed by default')
    assert.match(html, /aria-expanded="false"/, 'and the heading says so')

    // No table at all: the chips must NOT become anchors, and no list appears.
    const bare = renderToStaticMarkup(Markdown({ source: '结论[citation:3]。', sourcesLabel: '参考来源（1）' }) as never)
    assert.ok(bare.includes('dsh-dschat-cite'), 'the marker still renders as a citation chip')
    assert.equal(bare.includes('<a '), false, 'a citation with no source table is never a link')
    assert.equal(bare.includes('参考来源'), false, 'and there is no source list to show')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * A transcript link must land in the machine's own browser.
 *
 * The panel used to route links into a column of its own (or into the shell's
 * right Sidebar, which refuses to open anything while a global main panel is on
 * screen) — that is the 「点开跑到系统浏览器去了」 complaint, inverted. Now there is
 * one destination, and it is the OS browser: `window.open` is the shell's own
 * external-link path (the Electron main process answers it with
 * `shell.openExternal` and denies the popup).
 *
 * Both halves are exercised: the destination (`openExternalLink`, with a stand-in
 * for `window`) and the anchor contract in `Markdown` (reported, default-
 * prevented when taken, left to `target="_blank"` when declined).
 */
test('a transcript link opens in the machine browser, and only for web schemes', async () => {
  const { Markdown, openExternalLink, createElement, dir } = await loadComponents()
  const globals = globalThis as { window?: unknown }
  const hadWindow = 'window' in globals
  const opened: Array<[string, string, string]> = []
  try {
    globals.window = {
      open: (url: string, target: string, features: string) => { opened.push([url, target, features]) },
    }

    assert.equal(openExternalLink('https://example.com/a'), true)
    assert.equal(openExternalLink('http://127.0.0.1:19387/ui'), true)
    assert.deepEqual(opened[0], ['https://example.com/a', '_blank', 'noopener,noreferrer'])
    assert.deepEqual(opened[1], ['http://127.0.0.1:19387/ui', '_blank', 'noopener,noreferrer'])

    // Anything that is not a web page is refused rather than handed to the OS:
    // a mailto: or a harness-internal URL must not become an external app call.
    for (const href of ['mailto:a@b.c', 'javascript:alert(1)', 'dsh-resource://file/session/x/y', 'not a url']) {
      assert.equal(openExternalLink(href), false, `${href} is not a page`)
    }
    assert.equal(opened.length, 2, 'only the http(s) links were opened')

    // The anchor side: a plain click is reported and default-prevented when the
    // handler took it, so the link is opened exactly once.
    const written: unknown[] = []
    const tree = Markdown({ source: 'see [the docs](https://example.com/a) and [x](https://example.com/b)', onOpenLink: (href: string) => { written.push(href); return true } }) as never
    const anchors: Array<Record<string, unknown>> = []
    const walk = (node: unknown): void => {
      if (Array.isArray(node)) { for (const child of node) walk(child); return }
      if (node === null || typeof node !== 'object') return
      const element = node as { type?: unknown; props?: Record<string, unknown> }
      if (element.type === 'a' && element.props !== undefined) anchors.push(element.props)
      walk(element.props?.children)
    }
    walk(tree)
    assert.equal(anchors.length, 2, 'both links render as anchors')
    assert.equal(anchors[0]?.href, 'https://example.com/a')
    assert.equal(anchors[0]?.target, '_blank', 'the untouched default is the system browser too')

    let prevented = 0
    const click = (event: Record<string, unknown>): void => {
      (anchors[0]?.onClick as (event: unknown) => void)({ button: 0, preventDefault: () => { prevented++ }, ...event })
    }
    click({})
    assert.deepEqual(written, ['https://example.com/a'], 'a plain click is handed to the host')
    assert.equal(prevented, 1, 'and the anchor does not ALSO open a window')

    click({ metaKey: true })
    assert.equal(written.length, 1, 'a modifier click is the user\'s own gesture and is never intercepted')
    assert.equal(prevented, 1)

    // A handler that declines leaves the click alone, so `target="_blank"`
    // (which the desktop shell also routes to the system browser) takes over.
    const declined = Markdown({ source: '[x](https://example.com/c)', onOpenLink: () => false }) as never
    const other: Array<Record<string, unknown>> = []
    const collect = (node: unknown): void => {
      if (Array.isArray(node)) { for (const child of node) collect(child); return }
      if (node === null || typeof node !== 'object') return
      const element = node as { type?: unknown; props?: Record<string, unknown> }
      if (element.type === 'a' && element.props !== undefined) other.push(element.props)
      collect(element.props?.children)
    }
    collect(declined)
    let fallbackPrevented = 0
    ;(other[0]?.onClick as (event: unknown) => void)({ button: 0, preventDefault: () => { fallbackPrevented++ } })
    assert.equal(fallbackPrevented, 0, 'a declined link keeps its native behaviour')
  } finally {
    if (!hadWindow) delete globals.window
    rmSync(dir, { recursive: true, force: true })
  }
})

test('DSchatStatus renders its initial screen', async () => {
  const { DSchatStatus, renderToStaticMarkup, createElement, dir } = await loadComponents()
  try {
    const html = renderToStaticMarkup(createElement(DSchatStatus, { ...deps } as never))
    assert.ok(html.length > 0, 'the status card produced markup')
    assert.match(html, /dsh-dschat-status/)
    assert.match(html, /status\.title/)
    assert.match(html, /settings\.status/)
    assert.match(html, /settings\.runtime/)
    assert.match(html, /settings\.actions/)
    // Before the context route answers, the runtime card shows the loading line
    // rather than an empty section.
    assert.match(html, /settings\.loading/)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('the client module envelope and its slot registrations are intact', async () => {
  const { readFileSync } = await import('node:fs')
  const bundle = readFileSync(join(root, 'lib/client.js'), 'utf8')
  // The loader keys factories by id, so the id must equal the package name.
  assert.match(bundle, /id: "dsh-dschat"/)
  assert.match(bundle, /window\.__ModuleLoader__\.load\(/)
  // Both declared surfaces must be registered somewhere in the bundle.
  for (const slot of ['sidebar.panellist', 'main']) {
    assert.ok(bundle.includes(`name: "${slot}"`) || bundle.includes(`"${slot}"`), `registers ${slot}`)
  }
  /*
   * And DSchat must NOT claim a page in the shell's Settings.
   *
   * It used to register `settings.section`, which put a whole page in Settings
   * for a card that is read-only and belongs next to the panel it describes.
   * The plugin's actual configuration is the Config form the shell renders on
   * the Plugins page; the status card is now 「运行状态」 in the panel's own menu.
   */
  assert.equal(
    bundle.includes('"settings.section"'), false,
    'DSchat does not occupy a page of its own in Settings',
  )
  // React must come from the shell's module table, never be bundled.
  assert.match(bundle, /require\("react"\)/)
  assert.ok(!bundle.includes('@deepseek-ai/dsh-client-ui-primitives'), 'no harness Client package is imported')
})

/**
 * Slot names this plugin registers into, with the inject faces the mounted
 * component reads off its props. A registration that omits a face renders an
 * error state (or crashes the shell's slot entry) and is invisible offline
 * unless the registration itself is exercised — which is what this test does.
 */
const REQUIRED_FACES: Record<string, string[]> = {
  'sidebar.panellist': [],
  main: ['api', 'tt', 'openSession', 'pickDirectory', 'createWorkspace'],
}

/**
 * Build the real client entry and run `apply` against a recording context.
 *
 * The context mirrors the two things that actually matter here: `slots.inject`
 * gates a registration on the owning slot existing (a bare `register` for a slot
 * declared by another subtree is dropped), and `slots.register` receives the
 * registration object plus the component.
 */
async function runClientApply(options: { services?: Record<string, unknown> } = {}) {
  const dir = mkdtempSync(join(root, '.tmp-client-entry-'))
  const outfile = join(dir, 'entry.mjs')
  await build({
    entryPoints: [join(root, 'src/client/index.ts')],
    outfile,
    bundle: true,
    format: 'esm',
    platform: 'node',
    jsx: 'automatic',
    logLevel: 'silent',
    external: ['react', 'react-dom', 'react/jsx-runtime', 'react/jsx-dev-runtime'],
  })
  const mod = await import(pathToFileURL(outfile).href) as {
    apply(ctx: unknown): void
  }

  const registrations: Array<{ slot: string; reg: Record<string, unknown>; component: unknown }> = []
  const injected: string[] = []
  const warnings: string[] = []

  const ctx = {
    effect(factory: () => void | (() => void)) { factory(); return () => undefined },
    // The shell publishes its lookups on the context; the entry reads the
    // Sidebar and the Remote carrier through here at CALL time.
    get(name: string) { return options.services?.[name] },
    locale: {
      register: () => () => undefined,
      bind: () => (key: string) => key,
      subscribe: () => () => undefined,
    },
    slots: {
      // A slot the shell has not declared yet never calls back — model that as
      // "the registration simply never happens".
      inject(name: string, callback: () => void) { injected.push(name); callback(); return () => undefined },
      register(reg: Record<string, unknown>, component: unknown) {
        registrations.push({ slot: String(reg.name), reg, component })
        return () => undefined
      },
    },
  }

  const originalWarn = console.warn
  console.warn = (...args: unknown[]) => { warnings.push(args.map(String).join(' ')) }
  try {
    mod.apply(ctx)
  } finally {
    console.warn = originalWarn
  }
  return { registrations, injected, warnings, dispose: () => rmSync(dir, { recursive: true, force: true }) }
}

test('every slot is registered through inject, with the faces its component needs', async () => {
  // The style effect touches document; static markup rendering needs no DOM.
  const globals = globalThis as { document?: unknown }
  const hadDocument = 'document' in globals
  if (!hadDocument) {
    globals.document = { createElement: () => ({ dataset: {}, remove() {} }), head: { appendChild() {} } }
  }
  const { registrations, injected, warnings, dispose } = await runClientApply()
  try {
    // A registration failure is swallowed into a console.warn by design, so a
    // warning here means a surface silently went missing.
    assert.deepEqual(warnings.filter(w => w.includes('[dsh-dschat]')), [], 'no swallowed registration failure')

    for (const slot of Object.keys(REQUIRED_FACES)) {
      assert.ok(injected.includes(slot), `${slot} registered through slots.inject`)
    }

    assert.equal(registrations.length, 2, 'exactly two surfaces register (sidebar row + center panel)')
    for (const [slot, faces] of Object.entries(REQUIRED_FACES)) {
      const entry = registrations.find(r => r.slot === slot)
      assert.ok(entry !== undefined, `${slot} has a registration`)
      if (faces.length === 0) continue
      const inject = entry.reg.inject
      assert.equal(typeof inject, 'function', `${slot} carries an inject face`)
      const provided = (inject as () => Record<string, unknown>)()
      for (const face of faces) {
        assert.ok(provided[face] !== undefined, `${slot} injects "${face}"`)
      }
    }

    // `label` must be a thunk so the shell re-reads localized text per projection.
    for (const { slot, reg } of registrations) {
      if (slot === 'main') continue
      assert.equal(typeof reg.label, 'function', `${slot} label is a thunk`)
    }
  } finally {
    dispose()
    if (!hadDocument) delete globals.document
  }
})

/**
 * PANEL_CSS is one backtick-delimited template literal, so a stray backtick in a
 * CSS comment ends the string early and the rest parses as an EXPRESSION —
 * "`.dsh-dschat-msg-line`" became `` `str`.dsh - dschat - msg - line ``, which
 * esbuild happily compiles and which then throws `dschat is not defined` at run
 * time, inside the browser half, where the only symptom is a blank panel.
 * Backticks in the file's own JSDoc header are legal, so only the body is checked.
 */
test('PANEL_CSS template literal is not terminated early', async () => {
  const { readFileSync } = await import('node:fs')
  const source = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
  const marker = 'export const PANEL_CSS = `'
  const open = source.indexOf(marker)
  assert.ok(open > -1, 'the PANEL_CSS declaration is present')
  // Everything between the opening delimiter and the LAST backtick in the file is
  // template BODY, so it may not contain one.
  const body = source.slice(open + marker.length, source.lastIndexOf('`'))
  const stray = body.split('`').length - 1
  assert.equal(stray, 0, `PANEL_CSS body contains ${stray} stray backtick(s); each one ends the literal early`)
})

/**
 * Floating surfaces and the primary button both used tokens that invert with
 * the theme instead of following the accent:
 *
 *   alias-bg-overlay -> opaque #e9ecf2 light / opaque #61666b DARK, so a menu
 *                       painted with it is a light slab on the dark panel;
 *   button-primary-fill -> brand-primary, i.e. near-white in dark mode, which
 *                       made the transfer button the brightest thing on screen.
 *
 * Measured in a real browser (Chromium + the harness token sheet): the toggle
 * and the primary button now composite to the same fill in both themes
 * (#e6edfc light, #222835 dark) and the menu surface tracks the panel instead
 * of fighting it. These guards exist because neither mistake is visible in a
 * unit test — both render fine, just wrong.
 */
test('floating surfaces use the menu material, not the overlay token', async () => {
  const { readFileSync } = await import('node:fs')
  const css = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
  assert.ok(
    css.includes('--dschat-surface: var(--dsw-specific-menu'),
    'the shared surface token is derived from --dsw-specific-menu',
  )
  assert.equal(
    /var\(\s*--dsw-alias-bg-overlay\s*\)/.test(css), false,
    'no surface may paint --dsw-alias-bg-overlay: it is opaque panel grey in dark mode, not a floating material',
  )
  // The token NAME may still be mentioned in prose; only usage is banned.
  // Line-anchored: the row's own override rule ends with the same selector text.
  const popMatch = /^\.dsh-dschat-pop \{/m.exec(css)
  assert.ok(popMatch !== null, '.dsh-dschat-pop is styled')
  assert.ok(
    /var\(--dschat-surface\)/.test(css.slice(popMatch.index, css.indexOf('}', popMatch.index))),
    '.dsh-dschat-pop must paint var(--dschat-surface)',
  )
  /*
   * NEITHER message row is a floating surface any more.
   *
   * Both sit in the message's own flow — the answer's under the answer, the
   * reader's under the bubble — which is what "look like the official page" means
   * for these rows. A raised card behind 28px glyphs would read as a widget
   * dropped into the transcript, so this asserts the two placement rules stay
   * free of surface/background/shadow declarations.
   */
  for (const selector of ['.dsh-dschat-msg-acts[data-mod="answer"] {', '.dsh-dschat-msg-acts[data-mod="user"] {']) {
    const start = css.indexOf(selector)
    assert.ok(start > -1, `${selector} is styled`)
    const rule = css.slice(start, css.indexOf('}', start))
    assert.match(rule, /position:\s*relative/, `${selector} is an in-flow row`)
    assert.equal(
      /background\s*:|box-shadow\s*:|border\s*:/.test(rule), false,
      `${selector} must not paint a floating surface`,
    )
  }
})

/**
 * The composer's row opens UPWARD; everything in the title bar opens DOWNWARD.
 *
 * The action row's triggers are at the bottom of the panel, so a menu that grew
 * down from one of them would cover the input card it acts on and would have to
 * fit in the 60-odd pixels between the card and the phase line. Measured in a
 * real browser before the change: the 迁移 panel opened at y=627 downward, over
 * the textarea.
 *
 * The title bar is the mirror image: an upward panel there opened at y=-35 —
 * above the window entirely. So the shared rule is inverted once, for the strip,
 * and every control that strip gains later inherits the right answer.
 *
 * These assertions are about the ANCHOR (`bottom` for the row, `top` for the
 * header) rather than about pixel values. The second half is why the anchor
 * arithmetic is worth a guard at all: it only holds while the wrapper is the
 * trigger's own size. As a stretched flex item of the 36px action row, the
 * wrapper made `bottom: calc(100% + 8px)` resolve to 36px instead of 8px — a gap
 * that changes with whatever else is in the row, which no unit test would have
 * caught on its own.
 */
test('the composer\'s menus open upward, and the title bar\'s open downward', async () => {
  const { readFileSync } = await import('node:fs')
  const css = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
  /*
   * Matched at the START OF A LINE, not by substring: `.dsh-dschat-pop {` occurs
   * inside `.dsh-dschat-msg-acts[data-mod="answer"] > .dsh-dschat-pop {` too, and
   * a plain indexOf finds whichever comes first in the file — which is how this
   * test started asserting the row's override instead of the shared rule.
   */
  const ruleOf = (selector) => {
    const match = new RegExp(`^${selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')} \\{`, 'm').exec(css)
    assert.ok(match !== null, `${selector} is styled`)
    const start = match.index
    return css.slice(start, css.indexOf('}', start))
  }

  const pop = ruleOf('.dsh-dschat-pop')
  assert.match(pop, /bottom:\s*calc\(100% \+ 8px\)/, 'panels anchor above their trigger by default')
  assert.equal(
    /[^-]top:/.test(pop), false,
    'and declare no top offset: both offsets set would stretch the box between them',
  )
  assert.ok(pop.includes('right: 0'), 'opening to the left of a right-hand trigger')

  const anchor = ruleOf('.dsh-dschat-pop-wrap')
  assert.ok(anchor.includes('position: relative'), 'the wrapper is the containing block')
  assert.ok(
    anchor.includes('align-self: center'),
    'and stays the trigger\'s own size rather than stretching to the action row\'s height',
  )

  /*
   * The header's inversion. It is keyed on the STRIP, not on the lamp or the
   * 「···」: one rule covers both, and a third control added up there cannot get
   * it wrong.
   */
  const header = ruleOf('.dsh-dschat-header .dsh-dschat-pop')
  assert.ok(header.includes('top: calc(100% + 8px)'), 'the title bar\'s panels open downward, into the transcript')
  assert.ok(header.includes('bottom: auto'), 'which means the shared bottom anchor must be cleared')
  assert.equal(
    ruleOf('.dsh-dschat-lamp-wrap > .dsh-dschat-pop').includes('bottom: auto'), false,
    'and the lamp rule no longer repeats it — the strip owns that decision now',
  )
  assert.equal(
    /\.dsh-dschat-actions[^{]*\.dsh-dschat-pop\s*\{/.test(css), false,
    'the action row must NOT override the anchor: it is the strip the upward default is for',
  )
})

/**
 * The transfer button and the composer pills are the SAME tint triplet.
 *
 * They used to be two recipes in two colour families: the pills mixed three
 * different `static-deepseek-*` values (a #edf3fe fill, a #4868b2 border, a
 * #7aaaff label) while 「在 Harness 中继续」 took a 13% `state-business-primary`
 * tint — four blues for one meaning, which is what 「配色不统一」 meant in
 * practice. A later pass collapsed those into one accent, and this one replaces
 * the *mixing* with the web app's actual steps.
 *
 * They now share one rule shape: the --dschat-tint fill, the --dschat-tint-line
 * hairline, and --dschat-on-accent-tint for the label — the exact pair
 * deepseek.com paints its own 深度思考 pill with (deepseek-50 on deepseek-300 in
 * deepseek-500; deepseek-900 on deepseek-600 in deepseek-400). The panel's own
 * palette block is the single place those resolve, so one edit moves all four
 * controls.
 *
 * What must NOT come back is the mistake that produced the old rules:
 * `button-primary-fill` resolves to brand-primary, near-white in dark mode (the
 * reported 「太白了」), and the inverted foreground family is its dark half. So
 * the assertions below are about the FAMILY each rule draws from, not about
 * matching percentages.
 */
test('the primary button and the composer pills stay on the accent family', async () => {
  const { readFileSync } = await import('node:fs')
  const css = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
  const ruleOf = (selector) => {
    const start = css.indexOf(`${selector} {`)
    assert.ok(start > -1, `${selector} is styled`)
    return css.slice(start, css.indexOf('}', start))
  }
  /*
   * The whole sheet must stay off the harness's deepseek statics.
   *
   * Two of their steps are the old blues (500 is #4176e6, 400 #7aaaff) while
   * the web app paints #3964fe and #5686fe at the same two names, so ANY rule
   * that reaches for the static is a rule that silently keeps the palette the
   * reader asked to replace. The literals live in the palette block; nothing
   * else reads them from the harness. Comments are stripped first, because the
   * block's own explanation has to name the tokens it refuses.
   */
  assert.equal(
    /--dsw-static-deepseek-/.test(css.replace(/\/\*[\s\S]*?\*\//g, '')), false,
    'no rule may read the harness deepseek ramp: its 400/500 are the old blues',
  )
  const primary = ruleOf('.dsh-dschat-btn-primary')
  assert.ok(primary.includes('var(--dschat-tint)'), 'the primary fill is the tint step')
  assert.ok(primary.includes('var(--dschat-tint-line)'), 'with the tint hairline around it')
  assert.equal(
    /var\(\s*--dsw-alias-button-primary-(fill|hover|dimmed)\s*\)/.test(primary), false,
    'no button-primary-* token: that family inverts with the theme and goes white in dark mode',
  )
  assert.equal(
    primary.includes('label-primary-foreground'), false,
    'the primary fill is a tint, so its label cannot be the on-accent foreground colour',
  )
  assert.ok(ruleOf('.dsh-dschat-btn-primary:hover').includes('--dschat-on-accent-tint'), 'the hover label stays readable')

  /*
   * The action row's own buttons are the same argument in a different shape.
   *
   * 「DSH 迁移」 left the primary family when it moved onto the row: one line
   * above a card whose primary action is a 16px accent circle, a filled blue
   * chip competed with the send button and made the loudest thing in a row of
   * four quiet glyphs the one control that is not the message. So rest is
   * transparent and quiet, and the accent comes back only where it MEANS
   * something — hover, and the open state that says "this button owns the panel
   * on screen now". The open state wears the same tint triplet as the pills;
   * the inverted button-primary-* family must not appear at all.
   */
  const tbtn = ruleOf('.dsh-dschat-tbtn')
  assert.ok(tbtn.includes('background: transparent'), 'the toolbar button rests unfilled')
  assert.ok(tbtn.includes('color: var(--dschat-tx-2)'), 'and quiet, like the glyphs beside it')
  assert.equal(
    /border:\s*1px solid var\(--dsw/.test(tbtn), false,
    'rest draws no visible border — only the open state does',
  )
  const tbtnOn = ruleOf('.dsh-dschat-tbtn-on')
  assert.ok(tbtnOn.includes('var(--dschat-tint)'), 'the open state is the tint step, like the pills')
  assert.ok(tbtnOn.includes('var(--dschat-tint-line)'), 'with the tint hairline on it')
  assert.equal(
    /button-primary-(fill|hover|dimmed)/.test(
      [tbtn, tbtnOn, ruleOf('.dsh-dschat-tbtn:hover'), ruleOf('.dsh-dschat-tbtn:disabled')].join('\n'),
    ),
    false,
    'never the theme-inverting button-primary-* family, which goes white in dark mode',
  )

  /*
   * The pills: ONE recipe for both states, sliced from the selector to the
   * closing brace at column zero — this rule is a two-line selector list and
   * the single-line helper above would read the first line as if it were the
   * whole rule.
   */
  const toggleStart = css.indexOf('.dsh-dschat-toggle.dsh-dschat-toggle-on,')
  assert.ok(toggleStart > -1, 'the on-state pill is styled')
  const toggle = css.slice(toggleStart, css.indexOf('\n}', toggleStart))
  assert.ok(toggle.includes('background: var(--dschat-tint)'), 'the on-state fill is the tint step')
  assert.ok(toggle.includes('border-color: var(--dschat-tint-line)'), 'and its border is the tint hairline')
  assert.ok(toggle.includes('var(--dschat-on-accent-tint)'), 'and its label is the tint-label token')
  assert.equal(
    /--dsw-static-deepseek-\d+/.test(toggle), false,
    'the pill no longer reaches past the panel palette for a raw static: that was the fourth blue',
  )
  /*
   * There is deliberately NO dark branch for the pill any more.
   *
   * The old sheet needed two of them (the static ramp does not flip with the
   * theme, so the light #edf3fe fill had to be re-stated as #34415b by hand,
   * and the label had to be named twice more to survive the cascade). A rule
   * that reads its colours from the panel palette needs neither — so a dark
   * toggle rule reappearing here would mean somebody had bypassed the palette
   * again.
   */
  assert.equal(
    /body\[data-ds-dark-theme\][^{]*dsh-dschat-toggle-on/.test(css),
    false,
    'the on-pill has no theme branch: the palette tokens already carry both themes',
  )
})

/**
 * Every place this panel pairs `button-primary-dimmed` with a label, in both
 * themes, measured against the real palette:
 *
 *   label-primary-foreground -> 1.16:1 light / 1.97:1 dark (invisible)
 *   label-secondary          -> 4.98:1 light / 6.37:1 dark
 *
 * The dimmed fill is light grey in light mode and dark grey in dark mode; the
 * *-foreground family is its inverse in both, so they cancel out. This is the
 * same mistake that produced the user-visible "有点暗" and the bright white
 * primary button, so it gets a guard rather than a comment.
 */
test('a dimmed fill never carries an on-accent foreground colour', async () => {
  const { readFileSync } = await import('node:fs')
  const css = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
  // Comments are stripped first: the fix's own explanation names the token it
  // warns against, and prose must not trip a declaration-level guard.
  const declarationsOnly = css.replace(/\/\*[\s\S]*?\*\//g, '')
  const offenders = []
  const ruleRe = /([^{}]+)\{([^}]*)\}/g
  for (const [, selector, decls] of declarationsOnly.matchAll(ruleRe)) {
    if (!decls.includes('button-primary-dimmed')) continue
    if (decls.includes('label-primary-foreground') || decls.includes('label-primary-inverted')) {
      offenders.push(selector.trim())
    }
  }
  assert.deepEqual(offenders, [], `these rules put an on-accent colour on a dimmed fill: ${offenders.join(', ')}`)
  /*
   * The disabled send button is the one place the pairing is now deliberately
   * absent, and it has to SAY so — the reason the guard above exists is that
   * `background` alone lets the enabled colour leak through, and the disabled
   * rule inherits its background from the enabled rule directly above it.
   *
   * The design it implements is the web app's own: the accent circle stays the
   * accent circle and the label keeps the accent's ink, so the contrast argument
   * that produced the old grey-dimmed fill no longer applies to it. What must
   * never come back is the old shape of the fix: a `button-primary-dimmed` fill
   * (light grey in light mode, dark grey in dark mode) under an on-accent glyph.
   */
  const sendStart = declarationsOnly.search(/(^|\})\s*button\.dsh-dschat-send:disabled\s*\{/)
  assert.ok(sendStart > -1, 'the disabled send rule is styled on its element')
  const send = declarationsOnly.slice(declarationsOnly.indexOf('{', sendStart) + 1)
  const sendRule = send.slice(0, send.indexOf('}'))
  /*
   * The disabled disc is MIXED, not faded, and that is the fix for a reported
   * defect rather than a preference.
   *
   * `opacity` fades the glyph with the fill: at 0.4 the arrow over a
   * 40%-transparent accent is the same tone as the disc under it, and the
   * reader cannot tell a disabled send button from a broken one. Mixing the
   * accent into the card dims the circle while the arrow keeps its full
   * strength — so the dimming figure must NOT come back as an opacity.
   */
  assert.ok(sendRule.includes('color-mix'), 'the disabled disc dims by mixing toward the card surface')
  const opacity = /(?:^|;)\s*opacity\s*:\s*([^;]+)/.exec(sendRule)
  assert.equal(
    Boolean(opacity) && Number.parseFloat(opacity[1]) < 1, false,
    'and not by fading the control, which would fade the arrow with it',
  )
  assert.equal(
    /button-primary-(dimmed|fill)/.test(sendRule), false,
    'nor by swapping in the theme-inverting primary family',
  )
  /*
   * The arrow itself: the panel opens with `.dsh-dschat button { color: inherit }`
   * at (0,1,1), so a single-class `.dsh-dschat-send` LOSES and the glyph is
   * painted in the panel's inherited ink — dark on the deep blue disc, the
   * reported 「与蓝色背景的反差不够」. The element must be named.
   */
  assert.ok(
    declarationsOnly.includes('button.dsh-dschat-send {'),
    'the enabled send rule names its element, or the blanket button rule outranks it',
  )
  assert.ok(
    declarationsOnly.includes('color: var(--dschat-on-accent)'),
    'and the arrow takes the accent ink, which flips with the accent in both themes',
  )
})

/**
 * The macOS window chrome band.
 *
 * The Electron window is titleBarStyle "hiddenInset" with the traffic lights at
 * x=16, floating over the page. The shell reserves that band with
 * --dsh-frame-leading-clearance, set on the frame only while
 * [data-sidebar-collapsed] is on: 160px, or 84px in fullscreen, and unset on
 * Web and Windows, where a real title bar owns the space. Its own Conversation
 * header reads the variable, so it always starts at the clearance edge; the
 * sidebar's 280px column usually hides the problem, and collapsing it exposes
 * the panel's flat 14px inset — the rail toggle, brand mark and brand name were
 * painted under the traffic lights and under the shell's own 打开侧边栏 /
 * 新建会话 controls (the shell.leading seat, ending at 152px).
 *
 * Measured against the live GUI (Chromium + the harness sheet, sidebar
 * collapsed, html[data-platform=darwin]): padding-inline-start 14px -> 160px,
 * first header control at x=160. Expanded stays 14px; collapsed fullscreen
 * resolves to the shell's own 84px.
 *
 * This is a guard rather than a comment because nothing about the mistake is
 * visible in a unit test or at the default window size — it only shows up in
 * one platform, one sidebar state, at the top-left corner of the screen.
 */
test('the header clears the macOS window chrome band', async () => {
  const { readFileSync } = await import('node:fs')
  const css = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
  const ruleOf = (selector) => {
    const start = css.indexOf(`${selector} {`)
    assert.ok(start > -1, `${selector} is styled`)
    return css.slice(start, css.indexOf('}', start))
  }

  const header = ruleOf('.dsh-dschat-header')
  assert.ok(
    header.includes('var(--dsh-frame-leading-clearance'),
    'the header must read the shell chrome clearance, the same variable the shell Conversation header consumes',
  )
  assert.match(
    header,
    /max\(\s*14px\s*,\s*var\(--dsh-frame-leading-clearance,\s*0px\)\s*\)/,
    'the clearance must be floored at the plain 14px inset so Web, Windows and an expanded sidebar are unchanged',
  )
  assert.ok(header.includes('padding-inline:'), 'the chrome clearance applies to the leading edge only')
  assert.equal(
    /[^-\w]padding:\s*0\s+14px/.test(header), false,
    'a flat padding shorthand would shadow the leading inset again',
  )

  /*
   * One nowrap row with no wrap point: when the window cannot fit it, something
   * must give instead of pushing the controls off the edge.
   *
   * What gives is the run of empty space — and it is now the only thing that
   * can, because the header holds three fixed boxes: the brand, the lamp, and
   * the 「···」 menu button (which the spacer has to stay to the right of, since
   * that is where a title bar's menu lives). None of them may shrink: a squashed
   * mark is a broken logo, the lamp is the only readout of the engine's state,
   * and the menu is the only way to reach 导出 markdown.
   */
  assert.ok(ruleOf('.dsh-dschat-spacer').includes('flex: 1'), 'the spacer is the flexible child')
  const brand = ruleOf('.dsh-dschat-brand')
  assert.ok(brand.includes('flex: none'), 'the brand is a fixed box — it may never be squeezed')
  assert.equal(brand.includes('min-width: 0'), false, 'and it never shrinks below its own size')
  const lamp = ruleOf('.dsh-dschat-lamp')
  assert.ok(lamp.includes('flex: none'), 'the lamp is a fixed box too')
  assert.equal(lamp.includes('min-width: 0'), false, 'and it never shrinks below its own size')
  /*
   * The action row is BELOW the header, so it may wrap or scroll on its own
   * terms — but its controls still must not be shrunk into each other by a
   * narrow column, which is why each keeps `flex: none` as well. Since v0.4.1
   * that is the same rule the header's menu button uses, because they are the
   * same button.
   */
  for (const selector of ['.dsh-dschat-tbtn']) {
    assert.ok(ruleOf(selector).includes('flex: none'), `${selector} keeps its controls at full size`)
    assert.ok(ruleOf(selector).includes('white-space: nowrap'), `${selector} never wraps its label`)
  }
})

/**
 * The panel must take its smooth updates from `/tail` (one message, as a delta)
 * and NEVER from `/state` (the whole store — 2,581,434 bytes on a real 108-chat
 * history) at streaming speed.
 *
 * Reporting symptom: the reply appeared "一大段一大段" — paragraphs at a time.
 * The cause was this loop polling the full store every 600 ms to move a few
 * dozen new characters, so the panel believed it was streaming while it was
 * really sampling. Both halves are pinned: the fast feed exists, and the slow
 * snapshot no longer speeds up.
 */
test('the streaming feed is the tail poll, not a fast /state poll', async () => {
  const { readFileSync } = await import('node:fs')
  const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')

  assert.ok(/api\.tail\(/.test(panel), 'the panel polls the tail feed')
  assert.ok(/POLL_TAIL_MS/.test(panel), 'at its own fast interval')

  const fast = /const POLL_TAIL_MS = (\d+)/.exec(panel)
  assert.ok(fast !== null, 'the tail interval is a named constant')
  assert.ok(Number(fast[1]) <= 150, `the tail interval is fast enough to read as continuous (got ${fast[1]} ms)`)

  const idle = /const POLL_IDLE_MS = ([\d_]+)/.exec(panel)
  assert.ok(idle !== null, 'the /state interval is a named constant')
  assert.ok(
    Number(idle[1].replaceAll('_', '')) >= 1_000,
    `/state must stay slow — it serializes every transcript (got ${idle[1]} ms)`,
  )
  assert.equal(
    /POLL_STREAM_MS/.test(panel), false,
    'no fast /state interval may come back: that is the paragraph-sized update',
  )
  // The delta rule itself lives in `mergeTail` (protocol.ts) so the host's
  // `head`/`tail` and the panel's apply are one piece of code; the panel must
  // route every tail response through it rather than assigning the body.
  assert.ok(/mergeTail\(/.test(panel), 'the panel folds a tail through the shared merge')
  const protocol = readFileSync(join(root, 'src/protocol.ts'), 'utf8')
  assert.ok(
    /\.slice\(0, message\.head\)\s*\+\s*message\.tail/.test(protocol),
    'the merge applies the head/tail delta rather than replacing the message',
  )
  // Tailing must start on send, not when /state next reports busy: the gap
  // between Enter and the first token is exactly when the panel looked stuck.
  assert.ok(/TAIL_AFTER_SEND_MS/.test(panel), 'sending arms the tail loop immediately')
  // The one place the fast loop may need a full snapshot (a chat the panel has
  // not seen yet) must be throttled to the slow cadence — otherwise the
  // fallback quietly becomes the fast whole-store poll this replaced.
  assert.match(
    panel,
    /lastReconcileRef\.current\s*>=\s*POLL_IDLE_MS/,
    'the tail loop throttles its /state fallback',
  )
})

/**
 * Reported bug: pressing 引用 on a reply put the literal
 * `> <details><summary>思考过程</summary>` into the composer.
 *
 * Cause: the stored message is ONE string whose first line is the thinking
 * wrapper, and the quote action took `content.split('\n')[0]`. The behaviour
 * itself is pinned in test/reply.test.ts; this one pins the panel to that
 * helper, because the tempting one-liner is still sitting right there.
 */
test('quoting and copying a reply go through the reply splitter', async () => {
  const { readFileSync } = await import('node:fs')
  const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')
  /*
   * The ACTION ROW lives in its own module now (answer-actions.tsx) so its order
   * can be asserted without a rendered transcript; the splitter is still what
   * feeds it, from the panel. Both halves are read here, because the bug this
   * guards was a property of the PAIR: the panel decides what "the reply" is, and
   * the row is where 复制 / 引用 / 复制思考过程 are wired to it.
   */
  const actions = readFileSync(join(root, 'src/client/panel/answer-actions.tsx'), 'utf8')

  assert.ok(/from '\.\/reply\.ts'/.test(panel), 'the panel imports the splitter')
  assert.ok(/replyBody\(message\.content\)/.test(panel), 'copy takes the answer, not the reasoning')
  assert.ok(/firstLine\(message\.content\)/.test(panel), 'quote takes the answer, not the reasoning')
  assert.equal(
    /:(?:^|[^.\w])message\.content\.split\('\\n'\)\[0\]/.test(panel), false,
    "quoting must never take the raw first line: that line IS the <details> opener",
  )
  // The reasoning is still reachable — as its own action, never folded back
  // into the copy button (which is what the bug report was really about).
  assert.ok(/thinkingBody\(message\.content\)/.test(panel), 'the reasoning is offered separately')
  assert.ok(/msg\.copyThinking/.test(actions), 'and its action is labelled')
})

/**
 * Reported bug: the top bar was blank and double-clicking it did nothing.
 *
 * The desktop shell turns `data-window-drag` into a draggable region; this panel
 * is a full-width seat at the top of the window, so without the attribute its
 * header covered the only strip the user could grab.
 *
 * Deliberately asserted as an ATTRIBUTE and not as CSS: the drag rule has to
 * stay in the shell's sheet, because the control-exclusion rule
 * (`:is(button,…){-webkit-app-region:no-drag}`) lives there too. A plugin sheet
 * that declared `drag` would make the header's own buttons undraggable.
 */
test('the panel header is a window drag region', async () => {
  const { readFileSync } = await import('node:fs')
  const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')
  const cssSource = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
  // Comments are not CSS: the file documents the shell's rule on purpose.
  const css = cssSource.replace(/\/\*[\s\S]*?\*\//g, '')

  assert.match(
    panel,
    /'data-window-drag': true/,
    "the panel must claim the shell's drag hook or the title bar stays dead",
  )
  assert.equal(
    /-webkit-app-region/.test(css), false,
    'the drag property itself must stay in the shell sheet, which also excludes the controls',
  )
})

/**
 * Reported bug: "输入框可以复制和拖动图片进去，但其他文件似乎不行".
 *
 * Two independent image-only filters did it — the drop/paste handler and the
 * engine's `accept*="image"` selector — and both had to go, because either one
 * alone still refuses a PDF.
 */
test('dropped and pasted files are not filtered down to images', async () => {
  const { readFileSync } = await import('node:fs')
  const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')
  const engine = readFileSync(join(root, 'src/engine/engine.ts'), 'utf8')
  const routes = readFileSync(join(root, 'src/routes.ts'), 'utf8')

  assert.ok(/isAttachableFile/.test(panel), 'the drop/paste filter has a name that is not about images')
  assert.equal(
    /isImageFile/.test(panel), false,
    'a file.type.startsWith(image/) filter is what silently ate every PDF and .docx',
  )
  assert.ok(/filter\(isAttachableFile\)/.test(panel), 'both handlers route through it')

  // The page is the authority on types; the engine may only prefer an input
  // that accepts documents, never require an image one.
  assert.equal(
    /accept\*="image" i\]'\]/.test(engine), false,
    'the image-only selector list made images the only attachable type',
  )
  assert.ok(/attachFiles\(/.test(engine), 'the engine uploads files, not images')
  assert.equal(/attachImages\(/.test(engine), false, 'and no image-only entry point is left behind')

  // A nameless attachment must not inherit the old blanket `.png`: the web page
  // reads the extension, so a `.docx` named `x.png` is refused there instead of
  // here, where the reason is still visible.
  assert.equal(
    /return '\.png'/.test(routes), false,
    'the extension fallback may not claim every unknown file is an image',
  )
  assert.ok(/SAFE_EXTENSION/.test(routes), 'and it is an allow-list, not the caller-supplied name')
})

/**
 * The conversation list is no longer user-sized — it is user-ROOMED.
 *
 * The rail was a fixed 238px column with a drag handle. Both are gone: the list
 * is a popover that hangs off its trigger, so it has no width of its own to set
 * (the stylesheet pins it to 迁移's 348px) and no edge to drag. What replaced
 * the handle is a MEASURED ceiling: the panel writes the trigger's real distance
 * from the top of the body — less the popover's own 8px gap and 2px of air —
 * onto the wrapper as `--dschat-list-avail`, and the stylesheet spends it as the
 * popover's max-height.
 *
 * A static render cannot measure anything (there is no layout), so this asserts
 * the CONTRACT rather than the number: the effect exists, it measures the body
 * rather than the panel, it is re-run on layout changes, and the value is the
 * one the stylesheet reads. The number itself is checked in a real browser —
 * three window sizes, in scripts/dialog-preview.mjs — because that is the only
 * place a layout number means anything.
 */
test('the list popover takes a measured height from its trigger, not a dragged width', async () => {
  const { dir } = await loadComponents()
  const { readFileSync } = await import('node:fs')
  try {
    const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')
    const css = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
    const code = panel.replace(/\/\*[\s\S]*?\*\//g, '')

    // No drag machinery survives: not the pointer dance, not the clamp, not the
    // width key it persisted.
    assert.equal(
      /pointermove|clampRailWidth|storedRailWidth|RAIL_WIDTH|rail\.width/.test(code), false,
      'no drag-to-resize plumbing is left',
    )
    assert.equal(/data-rail-drag/.test(code), false, 'and no in-flight drag marker')

    // The measurement: named hook, right anchor, right units, and a real value.
    assert.match(code, /useLayoutEffect\(/, 'the ceiling is measured in a layout effect, before paint')
    assert.match(code, /closest\('\.dsh-dschat-body'\)/, 'measured from the body, so the header is not handed to the popover')
    assert.equal(
      /closest\('\.dsh-dschat'\)/.test(code), false,
      'measuring from the panel would put the popover under the header on a short window',
    )
    assert.match(code, /setProperty\('--dschat-list-avail'/, 'and published as the variable the stylesheet reads')
    assert.match(code, /typeof ResizeObserver === 'undefined'/, 'guarded for an environment without it')
    assert.match(code, /new ResizeObserver\(measure\)/, 're-measured when layout changes, not once at mount')
    assert.match(code, /observer\.observe\(body\)/, 'observing the body, which is the box that changes with the window')

    /*
     * The other half of the contract: the variable is what the popover's
     * max-height is, and the fallback only applies when it is absent. A typo in
     * either name would silently drop the ceiling back to the panel-wide
     * default.
     *
     * The 640px cap is asserted as part of the rule rather than left loose: it is
     * the number that says "a very tall window still gets a menu, not a second
     * page", and it was 520 until that cap turned out to be what a tall window hit
     * first — the "有点矮" report. Changing it is a deliberate act.
     */
    assert.match(
      css,
      /\.dsh-dschat-pop-wrap > \.dsh-dschat-listpop \{\s*max-height: min\(var\(--dschat-list-avail, 100vh\), 640px\)/,
      'the stylesheet spends the measured value as the popover ceiling',
    )
    /*
     * And the measurement reserves ONLY the trigger gap: the popover's own 8px
     * between itself and the button. A second subtracted offset is slack taken
     * out of the list a second time, which is exactly the bug this pins — the
     * first version subtracted 10 (8 + 2) and lost the rows.
     */
    assert.match(code, /const TRIGGER_GAP = 8\b/, 'the only offset reserved is the popover\'s own trigger gap')
    assert.equal(
      /POPOVER_GAP/.test(code), false,
      'and there is no second gutter: it would shorten the list for nothing',
    )

    /*
     * And the two behaviours that hang off the same wrapper: the outside click
     * that dismisses, and the row click that closes. Both are asserted in the
     * PANEL SOURCE because a static render runs no effects; both are exercised
     * for real by scripts/list-dismiss-check.mjs.
     */
    assert.match(code, /addEventListener\('pointerdown'/, 'a press outside the menu closes it')
    assert.match(code, /listWrapRef\.current\?\.contains\(target\)/, 'and a press inside it does not')
    const openChat = code.slice(code.indexOf('function openChat'), code.indexOf('function chatRow'))
    assert.ok(openChat.includes('closeList()'), 'picking a conversation closes the list it was picked from')

    assert.equal(/toggleSide|sideColumn|data-rail=|rightbar\./.test(panel), false, 'no right-column plumbing is left')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * The reasoning row: a real disclosure with the turn's measured duration.
 *
 * The engine stores reasoning inside a `<details>` wrapper, which is the right
 * format for a transcript and the wrong thing to render: the browser's own
 * marker and type scale ignore the panel's theme, and the summary would say
 * whatever the engine wrote instead of how long the model actually thought. The
 * panel therefore splits the reasoning off and hands it to `Thinking`.
 *
 * Three states of the label are pinned here, because each one is a different
 * claim to the reader: a running thought, a measured one, and one recovered
 * from the web (whose history has the text but no timing).
 */
test('the reasoning row is a disclosure with a measured duration', async () => {
  const { Markdown, Thinking, thoughtLabel, renderToStaticMarkup, createElement, dir } = await loadComponents()
  try {
    const tr = (key: string, values?: Record<string, string>): string => {
      const templates: Record<string, string> = {
        'msg.thought': '已思考',
        'msg.thought.running': '思考中…',
        'msg.thought.seconds': '已思考（用时 {seconds} 秒）',
        'msg.thought.minutes': '已思考（用时 {minutes} 分 {seconds} 秒）',
      }
      const template = templates[key] ?? key
      return values === undefined
        ? template
        : template.replace(/\{(\w+)\}/g, (_, name: string) => values[name] ?? '')
    }

    assert.equal(thoughtLabel(undefined, true, tr), '思考中…', 'a reply still thinking says so')
    assert.equal(thoughtLabel(undefined, false, tr), '已思考', 'a recovered reply has no time to claim')
    assert.equal(thoughtLabel(400, false, tr), '已思考（用时 1 秒）', 'a sub-second thought is not "0 秒"')
    assert.equal(thoughtLabel(12_400, false, tr), '已思考（用时 12 秒）')
    assert.equal(thoughtLabel(72_000, false, tr), '已思考（用时 1 分 12 秒）')
    assert.equal(thoughtLabel(60_000, false, tr), '已思考（用时 1 分 0 秒）')

    // The block renders as a button + body, and the body stays closed: the
    // answer is what the reader came for.
    const html = renderToStaticMarkup(createElement(Thinking, {
      source: '先看约束，再算一遍。',
      label: '已思考（用时 12 秒）',
    } as never))
    assert.match(html, /dsh-dschat-think-head/, 'the row is the panel\'s own control')
    assert.match(html, /已思考（用时 12 秒）/, 'and it carries the measured duration')
    assert.match(html, /aria-expanded="false"/, 'collapsed by default')
    assert.equal(/<details|<summary/.test(html), false, 'no raw details element is rendered')
    assert.equal(/先看约束/.test(html), false, 'a collapsed row does not render its reasoning')

    // A `<details>` block arriving inside markdown (the engine's stored format,
    // or a message an author wrote) goes through the SAME disclosure.
    const viaMarkdown = renderToStaticMarkup(createElement(Markdown, {
      source: '<details><summary>思考过程</summary>\n\n推理内容\n\n</details>\n\n答案。',
    } as never))
    assert.equal(/<details|<summary/.test(viaMarkdown), false, 'the markdown path renders no raw details either')
    assert.match(viaMarkdown, /dsh-dschat-think-head/)
    assert.match(viaMarkdown, /思考过程/, 'a foreign block keeps its own summary text')
    assert.match(viaMarkdown, /答案。/, 'and the answer stays visible')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * The reasoning row's two faces, which are MUTUALLY EXCLUSIVE.
 *
 * This is the reported bug, and the reason these assertions are shaped as
 * "the one is absent whenever the other is present" rather than as two
 * independent checks: the row used to keep its summary line mounted and simply
 * append the body under it, so a reader who watched a thought finish saw a
 * 「思考中…」 row with the entire reasoning printed below it — both faces at
 * once. The reader asked for one or the other, and for the collapsed line to be
 * what they meet by default.
 *
 * The three states, all readable from markup alone:
 *
 *   - collapsed (the default) → the summary line, and NO reasoning in the DOM;
 *   - expanded → the reasoning, and NO summary line;
 *   - still reasoning (`thinkingMs` absent, `streaming` true) → ALSO the
 *     collapsed line, carrying the live one-line 「思考中：<最新的思考内容>」 view
 *     instead of a label. This is the state that changed: the row used to open
 *     ITSELF for the duration of the thought, so a reasoner unfolded a
 *     screenful of text on every turn and folded it back once the answer
 *     arrived. It now stays closed until the reader opens it.
 *
 * The live line is a tail view: the prefix is its own element so it can never be
 * scrolled or truncated away, and the text sits in a clipping window the panel
 * shifts by a measured overflow.
 *
 * The OPEN face cannot be reached from a static render (nothing clicks), so the
 * browser pass (scripts/ui-shot.mjs) drives it for real; what is pinned here is
 * that the two faces are mutually exclusive whichever way each is reached.
 */
test('a reasoning row shows either its summary line or its text, never both', async () => {
  const { Thinking, renderToStaticMarkup, createElement, dir } = await loadComponents()
  const HEAD = /dsh-dschat-think-head/
  const BODY = /dsh-dschat-think-body/
  try {
    // 1. Collapsed — what a finished thought looks like with no interaction, and
    // what every message in the transcript shows.
    const collapsed = renderToStaticMarkup(createElement(Thinking, {
      source: '先看约束，再算一遍。',
      label: '已思考（用时 12 秒）',
    } as never))
    assert.match(collapsed, HEAD, 'the row is the panel\'s own control')
    assert.match(collapsed, /已思考（用时 12 秒）/, 'and it carries the measured duration')
    assert.match(collapsed, /aria-expanded="false"/, 'collapsed by default')
    assert.equal(BODY.test(collapsed), false, 'the collapsed face renders no body')
    assert.equal(/先看约束/.test(collapsed), false, 'and keeps the reasoning out of the DOM')
    assert.equal(/dsh-dschat-think-live/.test(collapsed), false, 'a finished thought shows no live line')

    /*
     * 2. STILL REASONING. The row is born collapsed and STAYS collapsed — the
     * reasoning is not in the DOM — but the one visible line is the live view,
     * so 「思考中：…」 and a tail of the newest text are on screen the whole time.
     * Nothing the reader needs is hidden; only the screenful is.
     */
    const running = renderToStaticMarkup(createElement(Thinking, {
      source: '先看约束：迁移过去的上下文必须自洽。\n\n再算一遍预算。',
      label: '思考中…',
      liveLabel: '思考中：',
      streaming: true,
    } as never))
    assert.match(running, HEAD, 'a running thought still shows its one line')
    assert.match(running, /aria-expanded="false"/, 'and does not open itself')
    assert.equal(BODY.test(running), false, 'the running reasoning is NOT unfolded into the transcript')
    assert.match(running, /dsh-dschat-think-live/, 'the line is the live tail view instead of a label')
    assert.match(running, /dsh-dschat-think-live-prefix/, 'whose prefix is its own element, so it cannot be clipped away')
    assert.match(running, /再算一遍预算。/, 'and whose text is the newest part of the thought')
    assert.equal(/dsh-dschat-think-label/.test(running), false, 'the plain 「已思考」 label does not also render')

    /*
     * 3. The open face, reached the way the browser pass reaches it: a row the
     * reader opened while it was running, then the duration arrives (`thinkingMs`
     * stamped, `streaming` still true for the rest of the reply). The open face
     * is what is on screen, and the summary line is NOT beside it.
     *
     * A static render produces the INITIAL (closed) state only, so this drives
     * the FACE directly through the same props the open row carries — see the
     * `expanded` fixture the browser pass also uses.
     */
    const expanded = renderToStaticMarkup(createElement(Thinking, {
      source: '先看约束：迁移过去的上下文必须自洽。\n\n再算一遍预算。',
      label: '思考中…',
      liveLabel: '思考中：',
      streaming: true,
      defaultOpen: true,
    } as never))
    assert.match(expanded, BODY, 'the opened thought shows its text')
    assert.match(expanded, /data-open="true"/, 'the row says it is open')
    assert.equal(HEAD.test(expanded), false, 'and the summary line is NOT also on screen')
    assert.equal(/dsh-dschat-think-live/.test(expanded), false, 'so no live line is rendered either')
    assert.match(expanded, /先看约束：迁移过去的上下文必须自洽。/, 'the reasoning itself is what is on screen')
    assert.match(expanded, /role="button"/, 'the expanded body is its own collapse control')
    assert.match(expanded, /aria-expanded="true"/, 'and reports itself as expanded')

    // 4. Recovered from the web: no timing to claim, and nothing to watch. This
    // must NOT be mistaken for the live state — it is a finished thought whose
    // duration was never measured.
    const recovered = renderToStaticMarkup(createElement(Thinking, {
      source: '历史里只有推理文本。',
      label: '已思考',
      liveLabel: '思考中：',
      streaming: false,
    } as never))
    assert.match(recovered, /已思考/, 'a recovered thought says so')
    assert.equal(/dsh-dschat-think-live/.test(recovered), false, 'and is not rendered as a running one')
    assert.equal(/历史里只有推理文本/.test(recovered), false, 'a closed row renders no reasoning')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * The source rows themselves, which the collapsed list keeps out of the DOM.
 *
 * Positions are the contract — `[citation:N]` indexes this table — so a row
 * the page named no URL for must keep its slot and render as plain text rather
 * than being dropped (which would silently point every later citation at the
 * wrong page).
 */
test('every source row keeps its number and links only when it has a URL', async () => {
  const { sourceRows, createElement, renderToStaticMarkup, dir } = await loadComponents()
  try {
    const rows = sourceRows([
      { url: 'https://a.example/1', title: '甲页' },
      { url: '' },
      { url: 'https://c.example/3' },
    ]) as never
    const html = renderToStaticMarkup(createElement('ol', null, rows) as never)

    assert.equal((html.match(/dsh-dschat-source-no/g) ?? []).length, 3, 'three numbered rows')
    assert.equal((html.match(/<a /g) ?? []).length, 2, 'the URL-less row is not a link')
    assert.match(html, />1<[\s\S]*甲页/)
    assert.match(html, /dsh-dschat-source-plain/, 'the placeholder renders as plain text')
    assert.match(html, /href="https:\/\/c\.example\/3"/, 'and the row after it keeps its own URL')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * Reported bug: "点击后没有出现新会话，更没有打开新会话" — and, after that one was
 * fixed, "打开后看到的是上一次的蒸馏上下文".
 *
 * Both symptoms came from the same shape of mistake: a navigation the shell
 * refuses (`sessions.retain: unknown session <id>`) was swallowed inside a
 * try/catch, so the click left the reader on whatever session was already on
 * screen. Retrying is necessary (the Client list learns the new row over a
 * different socket) but not sufficient — the panel must also SAY when even the
 * retries ran out.
 */
test('the transfer reports a navigation the shell could not take', async () => {
  const { readFileSync } = await import('node:fs')
  const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')
  const entry = readFileSync(join(root, 'src/client/index.ts'), 'utf8')
  const locales = readFileSync(join(root, 'src/client/locales.ts'), 'utf8')

  assert.ok(/Promise<boolean>/.test(entry), 'the navigation reports its outcome instead of returning void')
  assert.ok(/resolve\(false\)/.test(entry), 'a refused navigation resolves false — it is a branch, not a log line')
  assert.ok(/OPEN_SESSION_ATTEMPTS/.test(entry), 'and it still retries while the Client list catches up')
  assert.ok(/refreshProjections/.test(entry), 'warming the title projection keeps the new row from being blank')

  assert.ok(/toast\.open\.failed/.test(panel), 'the panel surfaces a failed navigation to the reader')
  assert.ok(/opened === false/.test(panel), 'only an explicit false toasts: a face that returns nothing is not a failure')
  assert.ok(
    /'toast\.open\.failed'/.test(locales),
    'and the message is localized, like every other string in this panel',
  )

  /*
   * The transfer popover must not remember the previous "append to an existing
   * session" choice: its default target is the most recently updated cold
   * session, i.e. the LAST transfer — so a stale selection silently writes the
   * new brief into the previous session and the reader sees the previous
   * distillation where they expected a fresh session.
   */
  assert.match(
    panel,
    /if \(!transferOpen\) \{\s*setTransferTarget\('new'\)/,
    'opening the transfer popover always starts from "新建会话"',
  )
})

/**
 * Reported bugs: "先出现参考来源，然后是流式输出的内容" — the source list rendered
 * while the reply was still streaming, so it stood alone at the top of an empty
 * message and was pushed down as the answer grew above it.
 *
 * The web numbers its sources as soon as the search step returns, which is
 * BEFORE the first token of the answer, and the engine stores the table the
 * moment it exists (it has to: the table is the only copy of the URLs).
 * Withholding `sourcesLabel` while `streaming` is what orders the transcript the
 * way the page itself ends up — answer, then sources — and the CHIPS stay live,
 * because `sources` is still handed over on every tick.
 */
test('the source list waits for the reply to finish, while citation chips stay live', async () => {
  const { Markdown, renderToStaticMarkup, createElement, dir } = await loadComponents()
  const { readFileSync } = await import('node:fs')
  try {
    const sources = [{ url: 'https://example.com/a', title: 'A' }]
    const streaming = renderToStaticMarkup(createElement(Markdown, {
      source: '正文 [citation:1]',
      sources,
    } as never))
    const settled = renderToStaticMarkup(createElement(Markdown, {
      source: '正文 [citation:1]',
      sources,
      sourcesLabel: '参考来源（1）',
    } as never))

    assert.equal(/dsh-dschat-sources/.test(streaming), false, 'no source list while streaming')
    assert.match(streaming, /dsh-dschat-citation/, 'but the citation chip is still rendered')
    assert.match(streaming, /href="https:\/\/example\.com\/a"/, 'and it is still a link to its source')

    assert.match(settled, /dsh-dschat-sources/, 'the list appears once the reply is complete')
    assert.match(settled, /参考来源（1）/, 'with the count the panel formatted')
    assert.equal(/dsh-dschat-source-no/.test(settled), false, 'and stays folded until the reader asks')

    // The panel is what withholds the heading, keyed on `streaming`, and what
    // formats the count into it.
    const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')
    assert.match(
      panel,
      /sources === undefined \|\| message\.streaming === true\s*\? \{\}\s*: \{ sourcesLabel/,
      'the panel withholds the heading while the reply streams',
    )
    assert.match(panel, /tr\('msg\.sources\.count'/, 'and passes the count through the locale')
    /*
     * The TABLE must go over on every tick, not only once the reply settles:
     * it is what makes the chips clickable while the answer is still arriving.
     * Dropping it (the label is right there, after all) leaves the numbers
     * rendering as dead chips for the whole stream, which is silent — the
     * panel still looks fine, the links just are not links.
     */
    assert.match(
      panel,
      /\.\.\.\(sources === undefined \? \{\} : \{ sources \}\)/,
      'the panel hands the citation table over unconditionally',
    )
  }
  finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * Every `tr('…')` key the browser half asks for must exist in the dictionary.
 *
 * Locale keys are strings looked up at render time, so a typo — or a key that
 * was removed from the dictionary while a component kept asking for it — is
 * invisible to TypeScript and to a render test: the panel happily prints
 * `msg.sources.count` to the user. That is not hypothetical; it shipped once in
 * this exact file and was caught only by looking at a screenshot.
 *
 * The dictionary is read as SOURCE rather than imported so the guard also fails
 * when the key exists in one language and not the other.
 */
test('every locale key the panel asks for exists in both dictionaries', async () => {
  const { readFileSync, readdirSync } = await import('node:fs')
  const locales = readFileSync(join(root, 'src/client/locales.ts'), 'utf8')
  const zh = locales.slice(locales.indexOf('export const zh'), locales.indexOf('export const en'))
  const en = locales.slice(locales.indexOf('export const en'))
  const keysOf = (block: string): Set<string> =>
    new Set([...block.matchAll(/^  '([^']+)':/gm)].map(match => match[1] as string))

  const asked = new Set<string>()
  for (const file of readdirSync(join(root, 'src/client/panel'))) {
    const source = readFileSync(join(root, 'src/client/panel', file), 'utf8')
    for (const match of source.matchAll(/\btr\('([^']+)'/g)) asked.add(match[1] as string)
    for (const match of source.matchAll(/\btt\('([^']+)'/g)) asked.add(match[1] as string)
  }
  const entry = readFileSync(join(root, 'src/client/index.ts'), 'utf8')
  for (const match of entry.matchAll(/\btt\('([^']+)'/g)) asked.add(match[1] as string)

  assert.ok(asked.size > 20, `the scan found the panel's copy (${asked.size} keys)`)
  const zhKeys = keysOf(zh)
  const enKeys = keysOf(en)
  assert.deepEqual([...asked].filter(key => !zhKeys.has(key)), [], 'every key exists in zh')
  assert.deepEqual([...asked].filter(key => !enKeys.has(key)), [], 'every key exists in en')
  assert.deepEqual(
    [...zhKeys].filter(key => !enKeys.has(key)),
    [],
    'and the two dictionaries stay the same size',
  )
})

/**
 * The entry point's NAME is part of the localization, not decoration.
 *
 * The sidebar row and the panel title come from the same two keys, and until
 * this was fixed the Chinese dictionary said 「Chat」 — the English word inside
 * an otherwise Chinese UI, which is what made a bilingual reader conclude the
 * plugin had no Chinese at all. Both halves are asserted here because the pair
 * is the requirement: 聊天 in Chinese, Chat in English.
 */
test('the sidebar entry is 聊天 in Chinese and Chat in English', async () => {
  const { readFileSync } = await import('node:fs')
  const locales = readFileSync(join(root, 'src/client/locales.ts'), 'utf8')
  const zh = locales.slice(locales.indexOf('export const zh'), locales.indexOf('export const en'))
  const en = locales.slice(locales.indexOf('export const en'))
  const valueOf = (block: string, key: string): string | undefined =>
    new RegExp(`^  '${key}': '(.*)',$`, 'm').exec(block)?.[1]

  assert.equal(valueOf(zh, 'nav.label'), '聊天', 'the Chinese entry is 聊天')
  assert.equal(valueOf(en, 'nav.label'), 'Chat', 'the English entry is Chat')
  assert.equal(valueOf(zh, 'panel.title'), '聊天', 'the Chinese panel title follows it')
  assert.equal(valueOf(en, 'panel.title'), 'Chat', 'the English panel title follows it')
})

/**
 * No Chinese may leak into the English dictionary.
 *
 * The audit that produced this test found the English half carrying CJK
 * punctuation (`Synced 「x」`) and, worse, hosts of hardcoded Chinese strings
 * that no dictionary scan could see. A dictionary is trivially checkable, so it
 * is checked: every English value is ASCII apart from the ellipsis, the em dash
 * and the typographic quotes the copy already uses deliberately.
 */
test('the English dictionary carries no CJK', async () => {
  const { readFileSync } = await import('node:fs')
  const locales = readFileSync(join(root, 'src/client/locales.ts'), 'utf8')
  const en = locales.slice(locales.indexOf('export const en'))
  const cjk = /[\u3000-\u303f\u3400-\u4dbf\u4e00-\u9fff\uff00-\uffef]/
  const offenders: string[] = []
  for (const match of en.matchAll(/^  '([^']+)': '(.*)',$/gm)) {
    const [, key, value] = match
    // The brand line is a product name, not copy: it may be written either way.
    if (key === 'brand.title') continue
    if (cjk.test(value ?? '')) offenders.push(`${key}: ${value}`)
  }
  assert.deepEqual(offenders, [], 'English copy must not contain Chinese characters or CJK punctuation')
})

/**
 * The answer's action row: WHICH controls, in WHICH order, under the answer.
 *
 * Two contracts live in this one row, and both are asserted here rather than
 * through a rendered transcript (which would need a `/state` response, and the
 * static renderer has no effects at all):
 *
 *   1. the reader's contract — the row the reader asked for, mirroring
 *      chat.deepseek.com's own: 复制 · 重新生成 · 喜欢 · 不喜欢 · 分享, with 朗读
 *      deliberately absent, and this panel's 复制思考过程 / 引用到输入框 after
 *      them. Position is what makes it "参考官方网页"; a reorder is a regression
 *      even if every button still exists.
 *   2. the WIRE contract — `DeepSeekWebEngine.reactInner` presses the page's
 *      buttons by INDEX (2 = 喜欢, 3 = 不喜欢), because the page's controls carry
 *      no label to match on. That index is only right while this row's first five
 *      controls are the page's first five in the page's order.
 */
test('the reply action row mirrors the web page: 复制 · 重新生成 · 喜欢 · 不喜欢 · 分享', async () => {
  const { MessageActions, messageActions, renderToStaticMarkup, createElement, dir } = await loadComponents()
  try {
    const calls: string[] = []
    const row = messageActions({
      isUser: false,
      reply: '答案正文',
      thinking: '思考过程',
      quoted: '第一行',
      share: '# t',
      tr: (key: string) => key,
      busy: false,
      regeneratingId: undefined,
      messageId: 'a1',
      reaction: undefined,
      feedbackId: undefined,
      onCopyReply: () => { calls.push('copy') },
      onCopyThinking: () => { calls.push('copy-thinking') },
      onQuote: () => { calls.push('quote') },
      onEdit: () => { calls.push('edit') },
      onShare: () => { calls.push('share') },
      onRegenerate: () => { calls.push('regenerate') },
      onLike: () => { calls.push('like') },
      onDislike: () => { calls.push('dislike') },
    } as never)

    assert.deepEqual(
      row.map(action => action.key),
      ['copy', 'regenerate', 'like', 'dislike', 'share', 'sep', 'copy-thinking', 'quote'],
      'the page\'s five controls lead, in the page\'s order, a hairline, then this panel\'s two',
    )
    // The seven controls and the hairline: the separator is NOT a control, so it
    // carries neither a label nor an accessible name.
    assert.deepEqual(
      row.filter(action => action.key !== 'sep').map(action => action.title),
      ['msg.copy', 'msg.regenerate', 'msg.like', 'msg.dislike', 'msg.share', 'msg.copyThinking', 'msg.quote'],
    )
    assert.equal(row.some(action => action.key === 'speak'), false, '朗读 is deliberately not carried')

    // Every control names itself: the page hides its names in a hover tooltip,
    // which is exactly what an assistive-technology user cannot reach.
    const html = renderToStaticMarkup(createElement(MessageActions, {
      isUser: false,
      reply: '答案正文',
      thinking: '思考过程',
      quoted: '第一行',
      share: '# t',
      tr: (key: string) => key,
      busy: false,
      regeneratingId: undefined,
      messageId: 'a1',
      reaction: undefined,
      feedbackId: undefined,
      onCopyReply: () => undefined,
      onCopyThinking: () => undefined,
      onQuote: () => undefined,
      onEdit: () => undefined,
      onShare: () => undefined,
      onRegenerate: () => undefined,
      onLike: () => undefined,
      onDislike: () => undefined,
    } as never))
    assert.match(html, /data-mod="answer"/, 'the answer row is the in-flow placement')
    assert.equal(
      (html.match(/aria-label=/g) ?? []).length,
      7,
      'each of the seven controls carries its accessible name',
    )
    // The chosen rating is a state the reader can see again, not a toast.
    const liked = messageActions({
      isUser: false, reply: 'a', thinking: '', quoted: '', share: '', tr: (key: string) => key,
      busy: false, regeneratingId: undefined, messageId: 'a1', reaction: 'like', feedbackId: undefined,
      onCopyReply: () => undefined, onCopyThinking: () => undefined, onQuote: () => undefined,
      onEdit: () => undefined, onShare: () => undefined, onRegenerate: () => undefined,
      onLike: () => undefined, onDislike: () => undefined,
    } as never)
    assert.equal(liked.find(action => action.key === 'like')?.on, true, 'a liked answer shows it as chosen')
    assert.equal(liked.find(action => action.key === 'like')?.title, 'msg.like.on', 'and its tooltip clears it')

    /*
     * The page answers one question at a time, so 重新生成 is unavailable while a
     * turn runs — and the tooltip is where the REASON is, because a disabled
     * control with no explanation is the version of this a reader reports as
     * broken.
     */
    const whileBusy = messageActions({
      isUser: false, reply: 'a', thinking: '', quoted: '', share: '', tr: (key: string) => key,
      busy: true, regeneratingId: undefined, messageId: 'a1', reaction: undefined, feedbackId: undefined,
      onCopyReply: () => undefined, onCopyThinking: () => undefined, onQuote: () => undefined,
      onEdit: () => undefined, onShare: () => undefined, onRegenerate: () => undefined,
      onLike: () => undefined, onDislike: () => undefined,
    } as never)
    assert.equal(whileBusy.find(action => action.key === 'regenerate')?.disabled, true)
    assert.equal(whileBusy.find(action => action.key === 'regenerate')?.title, 'msg.regenerate.busy')

    const working = messageActions({
      isUser: false, reply: 'a', thinking: '', quoted: '', share: '', tr: (key: string) => key,
      busy: false, regeneratingId: 'a1', messageId: 'a1', reaction: undefined, feedbackId: undefined,
      onCopyReply: () => undefined, onCopyThinking: () => undefined, onQuote: () => undefined,
      onEdit: () => undefined, onShare: () => undefined, onRegenerate: () => undefined,
      onLike: () => undefined, onDislike: () => undefined,
    } as never)
    assert.equal(working.find(action => action.key === 'regenerate')?.busy, true, 'the pressed button spins')

    // The reader's own turn keeps its two controls, and its own placement.
    const user = messageActions({
      isUser: true, reply: '问题', thinking: '', quoted: '问题', share: '', tr: (key: string) => key,
      busy: false, regeneratingId: undefined, messageId: 'u1', reaction: undefined, feedbackId: undefined,
      onCopyReply: () => undefined, onCopyThinking: () => undefined, onQuote: () => undefined,
      onEdit: () => undefined, onShare: () => undefined, onRegenerate: () => undefined,
      onLike: () => undefined, onDislike: () => undefined,
    } as never)
    assert.deepEqual(user.map(action => action.key), ['copy', 'edit'], 'a question is copied or edited, not rated')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * The answer's controls appear only once the answer has stopped arriving.
 *
 * The row used to be one of the first things the reader met under a LIVE reply:
 * 复制 sat under a half-written sentence, 分享 offered to publish a turn the page
 * did not have yet, and 重新生成 explained itself as 「正在生成，稍后再试」 for a
 * control whose only honest state was "not yet". A control that cannot do its job
 * is worse than no control — which is already this plugin's reason for leaving
 * 朗读 out entirely.
 *
 * Rendered rather than read as source, because the requirement is that no button
 * REACHES THE DOM: a row hidden by CSS would still be tab-focusable and would
 * still be announced by a screen reader.
 */
test('a reply that is still streaming has no action row yet', async () => {
  const { MessageActions, renderToStaticMarkup, createElement, dir } = await loadComponents()
  try {
    const answer = {
      isUser: false, reply: '半句话', thinking: '思考过程', quoted: '半句话', share: '# t',
      tr: (key: string) => key, busy: true, arriving: true, regeneratingId: undefined,
      messageId: 'a1', reaction: undefined, feedbackId: undefined,
      onCopyReply: () => undefined, onCopyThinking: () => undefined, onQuote: () => undefined,
      onEdit: () => undefined, onShare: () => undefined, onRegenerate: () => undefined,
      onLike: () => undefined, onDislike: () => undefined,
    }
    assert.equal(
      renderToStaticMarkup(createElement(MessageActions, answer as never)),
      '',
      'a reply that is still arriving renders no controls at all — not even the row',
    )
    // The SAME message gets its full row the moment the stream stops: the gate is
    // the arrival, not the identity of the message or the panel's turn flag.
    const settled = renderToStaticMarkup(createElement(MessageActions, { ...answer, busy: false, arriving: false } as never))
    assert.match(settled, /dsh-dschat-msg-acts/)
    assert.equal((settled.match(/aria-label=/g) ?? []).length, 7, 'and it is the complete row')
    /*
     * The reader's own turn is not an answer and never streams: its 复制 / 修改
     * have to be there the moment the question is on screen, or the panel would
     * have taken away a control nobody asked about.
     */
    const question = renderToStaticMarkup(createElement(MessageActions, { ...answer, isUser: true, arriving: false } as never))
    assert.match(question, /data-mod="user"/)
    assert.deepEqual(
      [...question.matchAll(/aria-label="([^"]+)"/g)].map(match => match[1]),
      ['msg.copy', 'msg.edit'],
      'the question keeps its two controls',
    )
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

/**
 * Which flag the panel hands the row.
 *
 * The module gate above is only half the requirement: the panel is what decides
 * that a message is still arriving, and it has to use the MESSAGE's own flag. The
 * panel-wide `busy`/`streaming` is true for the whole transcript while any turn
 * runs, so gating on it would strip the controls off every FINISHED answer too —
 * the reader would lose 复制 on an old reply for as long as a new one generates.
 */
test('the panel gates the action row on the message\'s own streaming flag', async () => {
  const { readFileSync } = await import('node:fs')
  const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')

  assert.match(
    panel,
    /arriving:\s*message\.streaming === true/,
    'the row follows the message it belongs to',
  )
  assert.equal(
    /arriving:\s*busy/.test(panel),
    false,
    'the turn-wide flag would take the row off finished answers as well',
  )
})

/**
 * The answer's action row is the 反馈 form's containing block.
 *
 * The 点踩 form is a CHILD of that row and opens upward from it, so the row has to
 * be positioned. It was static, and because the whole message is
 * `position: relative`, the form silently resolved its offsets against the MESSAGE
 * instead: measured in the rendered check, the form's `rect.top` was -421 while
 * the row it belongs to sat at 144 — i.e. the form opened entirely off the top of
 * the panel, with nothing on screen to explain why. Nothing in a markup-only test
 * catches that, which is why this asserts the CSS rule by name.
 */
test('the answer action row anchors its own popovers', async () => {
  const { readFileSync } = await import('node:fs')
  const css = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
  // Comments are not CSS, and this file documents the bug on purpose.
  const rules = css.replace(/\/\*[\s\S]*?\*\//g, '')
  const start = rules.indexOf('.dsh-dschat-msg-acts[data-mod="answer"] {')
  assert.ok(start > -1, 'the answer row has its own placement rule')
  const rule = rules.slice(start, rules.indexOf('}', start))
  assert.match(rule, /position:\s*relative/, 'the row must be the form\'s containing block')
  assert.match(rule, /margin-top:/, 'and keep the tightening against the answer above it')

  /*
   * The form itself must also stay OUT of the message's flow: absolute, so it
   * cannot push the transcript around when it opens.
   */
  const formStart = rules.indexOf('.dsh-dschat-msg-acts[data-mod="answer"] > .dsh-dschat-pop {')
  assert.ok(formStart > -1, 'the answer row anchors whichever panel is open')
  const formRule = rules.slice(formStart, rules.indexOf('}', formStart))
  assert.match(formRule, /left:\s*0/, 'anchored to the row\'s leading edge, not the message\'s')
  assert.match(formRule, /right:\s*auto/, 'and not the shared rule\'s trailing edge')
})

/**
 * The Q&A picker, RENDERED — the part of the selection rule a data test cannot
 * see: that both halves of a turn carry the same checked state, and that pressing
 * either one reports the turn (not the message).
 *
 * The binding is the requirement: clearing the question must clear the answer,
 * and clearing the answer must clear the question. There is one flag per turn
 * and both rows read it, so the two rows of a chosen turn are `aria-checked=true`
 * together and `false` together — which is also what a screen reader announces.
 */
test('the Q&A picker binds a question and its answer to one checkbox state', async () => {
  const { QaPicker, qaTurns, renderToStaticMarkup, createElement } = await loadComponents()
  const messages = [
    { id: 'q1', role: 'user', content: '第一问？', ts: 1 },
    { id: 'a1', role: 'assistant', content: '第一答。', ts: 2 },
    { id: 'q2', role: 'user', content: '第二问？', ts: 3 },
    { id: 'a2', role: 'assistant', content: '第二答。', ts: 4 },
  ]
  const turns = qaTurns(messages)
  const pressed: string[] = []
  const html = renderToStaticMarkup(createElement(QaPicker, {
    turns,
    selected: new Set(['q1']),
    onToggle: (id: string) => { pressed.push(id) },
    onAll: () => { pressed.push('all') },
    onNone: () => { pressed.push('none') },
    mode: 'export',
    answerLabel: 'DeepSeek',
    tr: (key: string, values?: Record<string, string>) => `${key}${values === undefined ? '' : JSON.stringify(values)}`,
  } as never))

  // One block per turn, and each block holds BOTH halves — question and answer.
  assert.equal((html.match(/dsh-dschat-qa-turn/g) ?? []).length, 2, 'one block per turn')
  assert.equal((html.match(/role="checkbox"/g) ?? []).length, 5, 'the 全选 control plus two rows per turn')
  assert.equal((html.match(/aria-checked="true"/g) ?? []).length, 2, 'the chosen turn: BOTH of its halves, and nothing else')
  // 全选 is unchecked while only one of the two turns is chosen.
  assert.match(html, /class="dsh-dschat-qa-all"[^>]*aria-checked="false"/, '全选 is not checked for a partial selection')
  // The chosen turn's two rows are checked TOGETHER, and the other turn's are
  // unchecked together: that is the binding, visible in the markup.
  assert.match(html, /aria-checked="true"[^>]*>[^<]*<span class="dsh-dschat-qa-box"[^>]*>[\s\S]*?msg\.you[\s\S]*?第一问？/)
  assert.match(html, /aria-checked="false"/, 'the unchosen turn is not checked')
  assert.match(html, /qa\.count\{&quot;count&quot;:&quot;1&quot;\}/, 'the count is the number of CHOSEN TURNS, not messages')

  // A streaming answer is visible but cannot be shared: the share-mode picker
  // does not offer it at all.
  const streaming = qaTurns([...messages, { id: 'q3', role: 'user', content: '第三问？', ts: 5 }, { id: 'a3', role: 'assistant', content: '', ts: 6, streaming: true }])
  const shareHtml = renderToStaticMarkup(createElement(QaPicker, {
    turns: streaming,
    selected: new Set(['q1', 'q3']),
    onToggle: () => undefined,
    onAll: () => undefined,
    onNone: () => undefined,
    mode: 'share',
    answerLabel: 'DeepSeek',
    tr: (key: string, values?: Record<string, string>) => `${key}${values === undefined ? '' : JSON.stringify(values)}`,
  } as never))
  assert.equal(/第三问？/.test(shareHtml), false, 'a turn the page cannot share is not offered in 分享 mode')
  assert.match(shareHtml, /qa\.count\{&quot;count&quot;:&quot;1&quot;\}/, 'and does not count toward the selection')
})

/**
 * 导出 markdown's new home, and the removal of its old one.
 *
 * The request was explicit about both halves: the button belongs at the END of
 * the row under the conversation, and the 「···」 menu must stop offering a second
 * copy of it. A source-level assertion is the right level for the second half —
 * the menu is closed in a static render, so nothing on screen shows what it holds.
 */
test('导出 markdown lives on the action row, not in the ··· menu', async () => {
  const { readFileSync } = await import('node:fs')
  const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')
  const code = panel.replace(/\/\*[\s\S]*?\*\//g, '')

  const menu = code.slice(code.indexOf('function moreMenu()'), code.indexOf('function lampMenu()'))
  assert.equal(/action\.exportFile/.test(menu), false, 'the ··· menu no longer offers 导出 markdown')
  assert.equal(/action\.exportFile/.test(code), false, 'and nothing else uses the old menu label')

  // The button is the row's LAST control, after the migration popover.
  const actions = code.slice(code.indexOf('function actions()'), code.indexOf(' * The engine menu'))
  assert.match(actions, /dsh-dschat-tbtn-export/, 'the action row carries the export button')
  assert.ok(
    actions.indexOf('transferPopover()') < actions.indexOf('dsh-dschat-tbtn-export'),
    'after 迁移, i.e. at the end of the row',
  )
  assert.match(actions, /tr\('action\.export'\)/, 'with its own short label')
  assert.match(actions, /tr\('action\.export\.hint'\)/, 'and the full name in its tooltip')

  /*
   * ONE picker, opened by both verbs. The old in-row 分享 confirmation is gone:
   * a selection over the whole conversation does not fit under one answer, and
   * two surfaces for one question would drift apart.
   */
  assert.match(code, /createElement\(QaPicker/, 'the picker is the panel\'s own component')
  assert.equal(/shareForm\(/.test(code), false, 'the old in-row 分享 form is gone')
  assert.match(code, /openSharePicker\(message\)/, '分享 opens the picker on the pressed turn')
  assert.match(code, /onClick: openExportPicker/, '导出 opens the same picker with everything ticked')
  assert.ok(
    code.indexOf("setQaSelection(new Set(turn === undefined ? [] : [turn.id]))") > -1,
    '分享 preselects exactly the pressed turn — the page\'s own enterSelection behaviour',
  )
  assert.ok(
    code.indexOf("setQaSelection(new Set(selectableTurns(turns, 'export').map(turn => turn.id)))") > -1,
    '导出 preselects everything',
  )
})

/**
 * 接力, and the mark it does NOT wear.
 *
 * Two changes to the same button, and both are about what the control promises:
 *
 *   1. the label. 迁移 named the MECHANISM (a plugin moving a conversation into
 *      a harness session) where the row needs the OUTCOME — the conversation is
 *      handed over and someone else carries it from there. It is also two words
 *      shorter, which matters on a row that shares its width with three others;
 *   2. no disclosure caret. It was there because this button opens a popover,
 *      but a caret is the mark for an inline fold: it gave the button an
 *      "expanded / collapsed" face it does not have. `aria-expanded` and the
 *      open menu say what is actually true.
 *
 * Asserted against the source and the dictionary rather than a rendered row: the
 * press opens a popover, which a static render never reaches.
 */
test('接力 replaces 迁移 on the hand-off button, and the disclosure caret is gone', async () => {
  const { readFileSync } = await import('node:fs')
  const panel = readFileSync(join(root, 'src/client/panel/DSchatPanel.tsx'), 'utf8')
  const css = readFileSync(join(root, 'src/client/panel/styles.ts'), 'utf8')
  const locales = readFileSync(join(root, 'src/client/locales.ts'), 'utf8')
  const zh = locales.slice(locales.indexOf('export const zh'), locales.indexOf('export const en'))
  const en = locales.slice(locales.indexOf('export const en'))
  const valueOf = (block: string, key: string): string | undefined =>
    new RegExp(`^  '${key}': '(.*)',$`, 'm').exec(block)?.[1]

  assert.equal(valueOf(zh, 'transfer.short'), '接力', 'the button reads 接力')
  assert.equal(valueOf(en, 'transfer.short'), 'Hand off', 'and Hand off in English')

  const transfer = panel.slice(
    panel.indexOf('function transferPopover'),
    panel.indexOf('transferOpen && createElement', panel.indexOf('function transferPopover')),
  )
  assert.match(transfer, /tr\('transfer\.short'\)/, 'the label comes from the dictionary')
  assert.match(transfer, /SwapIcon/, 'with the swap glyph that says "hand this over"')
  assert.equal(/CaretIcon/.test(transfer), false, 'and no caret, which promised an inline fold')
  assert.equal(/dsh-dschat-tbtn-caret/.test(panel), false, 'the caret markup is gone from the row')
  assert.equal(/tbtn-caret/.test(css), false, 'and its transform rule with it')
})
