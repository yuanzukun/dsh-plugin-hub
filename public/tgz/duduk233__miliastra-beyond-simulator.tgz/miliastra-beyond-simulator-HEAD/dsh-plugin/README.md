# 千星沙箱 DSH 插件

静态Host + Client适配层。编辑状态按DSH `sessionId`隔离，复用Studio Controller与持久Worker。上级：[项目文档树](../README.md#文档树)。

## 安装与更新

插件需要Node.js22+，Harness 0.2.2宿主要求Node.js24.9+；GitHub源码安装另需Git。以下为CLI Web安装示例，Desktop内置命令与profile操作见[恢复指引](docs/session-recovery.md#用户恢复步骤)。任选一种：

```powershell
dsh plugin --profile web add dsh-plugin-beyond-simulator
dsh plugin --profile web add github:1475505/miliastra-beyond-simulator
dsh plugin --profile web add ./release/dsh-plugin-beyond-simulator-2.3.1.tgz
```

更新也用`add`，之后重启Harness；`dsh --profile web --dump-config`检查加载，`dsh web`启动。tarball文件名以当次`release/manifest.json`为准，在其他目录安装时使用绝对路径。

源码安装入口是仓库根，`prepare`负责构建；`dsh-plugin/`只是内部包。pnpm若拒绝构建，按实际错误批准本插件或精确Git依赖键。预构建包无需源码和构建工具；详见[分发说明](../DISTRIBUTION.md#harness-安装入口)。

## 文档与功能入口

- [完整使用指南](../docs/user-guide.md)：单篇包含新手快速入门、使用说明和常见问题，适用于 Web / Harness 共用编辑器。
- [GitHub Releases](https://github.com/1475505/miliastra-beyond-simulator/releases)：公开发布说明与安装包。
- [模拟器操作Skill](../skill/SKILL.md)：工具工作流；构建复制到包内`dsh-plugin/skill.md`，通过独立skills组件注册`qxqy-simulator`。
- [游戏制作预设](../agent/wonderland-lua-builder/README.md)：源码、七步流程与行为评估。构建嵌入声明式预设，并携带旧宿主目录副本；已有用户副本不覆盖。
- [升级后会话无法加载与历史恢复](docs/session-recovery.md)：预设入口兼容、用户覆盖修正、原始日志位置与导出。
- [共用编辑器](../editor-ui/README.md)：UI、Lua、服务端逻辑、主题、语言、字体与试玩窗口。
- [Studio专题](../studio/README.md#专题树)：图片/音频/动效缓存、输入、部分导出、索引与脚本同步。

Host Tools为`qxqy_script_sync`、`qxqy_studio_get/patch/export/play/load`、`qxqy_studio_ui_screenshot/play_screenshot`。截图使用Host PNG，无需可见标签页；动效视频帧的省略提示见[动效边界](../studio/docs/ui-vfx-playback.md#截图与-gia-边界)。

工作区绑定DSH会话原始工程根。存档发现复用Studio，支持大于8MiB的存档，选最近50项并返回`discovery`限制/诊断；指定工作区内路径不受列表筛选限制。加载成功记住相对路径，省略保存路径时写回；未绑定时返回`{ bound:false, archives:[] }`。手动保存见[顶栏「保存存档」](../docs/user-guide.md#files)。

## 快速上手

右下角「快速上手」提供「下载示例，开始实操」及「用当前存档继续」。下载校验、示例来源配置与五阶段流程见 [Web 快速上手](../web/README.md#快速上手)，DSH 同样支持 `QXQY_QUICK_START_URL`，下载失败保留当前工程并可重试；显式空地址禁用下载。

每个真实 DSH 对话保留原工程和独立教学副本。打开示例不写盘、不覆盖原存档，清除发布者的脚本同步路径；首次保存使用独立的 `tutorials/` 建议路径。切换前停止旧试玩，HTTP、AI 工具及新试玩共同操作当前副本；「返回原工程」恢复原编辑与保存关联，再次打开示例复用已有修改。刷新或重开模拟器页恢复宿主内当前副本及各自浏览器引导进度，不创建虚假的 Harness 对话。宿主重启会丢失未保存副本，重启前须保存。

若欢迎页只有「用当前存档继续」，先确认实际加载的 DSH 插件版本：2.3.0 漏接下载入口，2.3.1 补齐。安装更新后完整重启宿主并刷新页面；只更新 Web 包或刷新旧后台不能补齐 DSH 接口。回归 `test/quick-start.test.mjs` 通过实际 ModuleLoader bundle、HTTP 和注册 AI 工具验证下载、重试、原工程保护、刷新恢复与返回。

<a id="harness-02-兼容性"></a>
<a id="harness-021-兼容性"></a>
## 宿主兼容契约

- 宿主准入与 npm peer 的预发布匹配规则不同；兼容范围以根 `package.json` 为准，不用忽略 peer 代替适配。依据：[插件兼容](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.2.0-rc.2/packages/boot/plugin-manager/README.md#version-compatibility-and-exemptions)。
- 新版默认使用声明式预设；构建从主维护源生成注册项与旧目录副本，更新旧 `.agent-presets` 不一定生效。Persona 变量与用户副本处理见[预设说明](../agent/wonderland-lua-builder/README.md#persona-工作目录变量兼容性)，`list-agents` 入口及持久化接口见[会话恢复](docs/session-recovery.md)。
- 嵌入预设的 `baseUrl` 可能来自合成 profile，Skill 须按安装包定位；旧目录预设才使用相邻 `skills/`。`test:harness` 验证正文及 `references/workflow.md` 可读，不能只检查菜单可见。
- 子智能体选模使用官方 `modelSelection/modelDiscovery` 能力声明；白名单由 Host 管理，设置何时生效取决于宿主版本，见[预设模型选择](../agent/wonderland-lua-builder/README.md#子智能体模型选择)。
- 模拟器绑定会话原始工程 cwd；Shell 切目录不切换编辑工程。工具定义、JSON 输出、附件、HTTP 路由、ModuleLoader 与 `conversation.view` 由适配层对接，共享 VM/存档不按宿主版本另建分支。子代理与 Agent Team 调度由官方插件处理，旧 `backgroundMode` 不构成新版同步等待承诺。

<a id="desktop-内嵌试玩208"></a>
## Desktop 内嵌试玩

Desktop 拒绝页面子窗口时，编辑器先将代码和逻辑草稿提交到当前会话，再打开同源全屏 iframe 试玩。关闭、返回和 Escape 等待 stop 成功，失败可重试，编辑器保持挂载；完整生命周期见[共用编辑器](../editor-ui/README.md#试玩窗口与内嵌兜底)。

## 故障定位

### PTC 模式无法启动试玩

[#28](https://github.com/1475505/miliastra-beyond-simulator/issues/28)：若宿主以 `node --input-type=module --eval ...` 启动，2.3.3 的试玩 Worker 会继承 `--input-type=module`。该参数只适用于字符串输入；Worker 的入口是文件 `worker.js`，因此 `qxqy_studio_play` 在 `start` 时即报 `ERR_INPUT_TYPE_NOT_ALLOWED`。共享 Controller 通过 `execArgv: []` 隔离宿主启动参数。安装含修复的 DSH 插件构建后，重启 Harness 生效。

[回归用例](test/plugin.test.mjs) 在 Windows / Node.js 24.15.0 和 22.23.2 下按上述方式加载插件构建并调用注册工具：默认工程修复前同错，修复后可以开始、停止试玩（`observed / simulator / not_required`）。验证范围是插件和 Worker，未运行反馈者的完整 Harness PTC 会话。

### Desktop protobuf 导入失败

完整 protobufjs 编入 Host/Worker，使 GIA 解析独立于宿主共享 CommonJS 导出。旧包报 `hu.parse is not a function` 时，更新插件、保存工作并从托盘完整退出 Harness 后启动；禁用/启用无法清除失败的 ESM 导入缓存。`test/protobuf-bundle.test.mjs` 验证独立进程中的依赖隔离与 GIA 往返；原 Desktop0.2.1-rc.2 窗口的完整触发链和回验未确认。

<a id="路由重复注册2011"></a>
### 路由重复注册

`webserver: duplicate prefix route "/qxqy-simulator/api"` 不足以证明重复安装。HTTP 路由的注销函数由 `ctx.effect` 管理，部分注册失败回滚；卸载等待 Worker 退出并拒绝迟到请求。更新并完整重启可清除旧残留；真实同时挂载冲突仍报错，不覆盖其他组件。`test/lifecycle.test.mjs` 覆盖重启、依赖重载、回滚及 HTTP/工具共用 Registry；反馈者原始 Desktop 再激活事件未复现。

## 验证入口与边界

构建/安装检查统一见[分发验收](../DISTRIBUTION.md#验收入口与证据范围)。`test:packages` 覆盖 dsh-tools 0.1.0-rc.6、0.2.0-rc.2、0.2.1-rc.2、0.2.2-rc.1；`test:harness` 默认 0.2.2-rc.1，也可传入已安装版本的 `lib/bin.js` 路径。请按所测 CLI 的 `engines.node` 选择 Node（Desktop 使用自带运行时）；Web/MCP 查各自清单。浏览器语言验收另设 `QXQY_BROWSER`。

`test/plugin.test.mjs` 与 `test/lifecycle.test.mjs` 只维护宿主协议、注册工具、会话隔离和 Worker 生命周期；共享编辑、存档、GIA 与 PNG 的功能回归归 Studio，安装包与真实 Harness 检查继续验证交付边界。

Windows 真实 Web 宿主已验证预设恢复、工具、附件、试玩和重启：Node 24.21.0 / Harness 0.2.1-rc.2，以及 Node 24.22.3 / Harness 0.2.2-rc.1、0.2.2-rc.5、0.2.3-alpha.2（`observed / simulator / not_required`）。不涵盖真实模型/Agent Team、完整签名 Desktop、Linux/macOS、SSH 或子路径 public-url 部署。Windows 隔离 Git 安装可用 `npm_config_package_import_method=copy` 避免已加载 Canvas DLL 的 unlink/EPERM 冲突；文件占用与构建审批拒绝应分别处理。
