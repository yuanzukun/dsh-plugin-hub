import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { spawn } from 'node:child_process'
import { once } from 'node:events'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createWebServer } from '../server.js'
import { createStudio } from '../../studio/index.js'

// Optional real Chromium UI check; no global browser/profile or external samples.
// QXQY_BROWSER=<Chrome/Edge executable> node --test test/script-sync-browser.test.mjs
test('browser buttons save configuration, preview without copying, and explicitly confirm copy', { skip: !process.env.QXQY_BROWSER, timeout: 45000 }, async t => {
  const temp = mkdtempSync(join(tmpdir(), 'qxqy-sync-browser-'))
  const workspace = join(temp, 'workspace')
  const target = join(temp, 'client/default_import_file')
  mkdirSync(join(workspace, 'game'), { recursive: true }); mkdirSync(join(target, 'game'), { recursive: true })
  const studio = createStudio()
  studio.patch({ op: 'addScript', path: 'game/main.lua', source: '-- browser new' })
  writeFileSync(join(workspace, 'game.save.json'), JSON.stringify(studio.archiveData()))
  writeFileSync(join(target, 'game/main.lua'), '-- browser old')
  const app = await createWebServer({ workspace, initialPath: 'game.save.json', port: 0 })
  const browser = spawn(process.env.QXQY_BROWSER, ['--headless=new', '--no-first-run', '--no-default-browser-check', '--disable-gpu', '--remote-debugging-port=0', `--user-data-dir=${join(temp, 'profile')}`, 'about:blank'], { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true })
  let socket
  t.after(async () => {
    if (socket?.readyState === 1) socket.close()
    if (browser.exitCode === null) { const exited = once(browser, 'exit'); browser.kill(); await exited }
    await app.close()
    rmSync(temp, { recursive: true, force: true, maxRetries: 10, retryDelay: 200 })
  })
  const endpoint = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Browser CDP startup timeout')), 15000)
    let stderr = ''
    browser.stderr.on('data', chunk => { stderr += chunk; const match = stderr.match(/DevTools listening on (ws:\/\/[^\s]+)/); if (match) { clearTimeout(timer); resolve(match[1]) } })
    browser.once('error', reject)
  })
  socket = new WebSocket(endpoint)
  await once(socket, 'open')
  const pending = new Map()
  let sequence = 0
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data)
    const callbacks = pending.get(message.id)
    if (!callbacks) return
    pending.delete(message.id)
    if (message.error) callbacks.reject(new Error(message.error.message)); else callbacks.resolve(message.result)
  })
  const send = (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const id = ++sequence
    pending.set(id, { resolve, reject }); socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
  const created = await send('Target.createTarget', { url: 'about:blank' })
  const { sessionId } = await send('Target.attachToTarget', { targetId: created.targetId, flatten: true })
  const evaluate = async expression => {
    const result = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }, sessionId)
    if (result.exceptionDetails) throw new Error(JSON.stringify(result.exceptionDetails))
    return result.result.value
  }
  const wait = async expression => {
    for (let i = 0; i < 100; i++) { if (await evaluate(expression)) return; await new Promise(resolve => setTimeout(resolve, 100)) }
    throw new Error(`Browser wait failed: ${expression}\n${await evaluate('document.body.innerText')}`)
  }
  const click = async text => {
    const result = await evaluate(`(() => { const b = [...document.querySelectorAll('button')].find(b => b.textContent === ${JSON.stringify(text)}); if (!b || b.disabled) return false; b.click(); return true })()`)
    assert.equal(result, true, `click ${text}`)
  }
  const fill = (label, value) => evaluate(`(() => { const el = [...document.querySelectorAll('label')].find(e => e.textContent.includes(${JSON.stringify(label)})).querySelector('input'); Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, ${JSON.stringify(value)}); el.dispatchEvent(new Event('input', { bubbles: true })); })()`)
  await send('Page.enable', {}, sessionId)
  await send('Page.addScriptToEvaluateOnNewDocument', { source: `
    const originalFetch = window.fetch
    window.syncTest = { hold: '', counts: {} }
    window.fetch = async (url, options) => {
      const action = String(url).split('/').pop(), body = JSON.parse(options?.body || '{}')
      const key = action === 'script-sync' ? body.action : action
      if (['save', 'preview', 'script-sync-apply'].includes(key)) {
        syncTest.counts[key] = (syncTest.counts[key] || 0) + 1
        if (syncTest.hold === key) await new Promise(resolve => { syncTest.release = resolve })
      }
      return originalFetch(url, options)
    }
  ` }, sessionId)
  await send('Page.navigate', { url: `${app.url}/editor` }, sessionId)
  await wait(`!!document.querySelector('.qxsim-editor-nav')`)
  await click('Lua 脚本')
  await wait(`!![...document.querySelectorAll('summary')].find(e => e.textContent.includes('实机脚本同步'))`)
  await evaluate(`[...document.querySelectorAll('summary')].find(e => e.textContent.includes('实机脚本同步')).click()`)
  await fill('项目脚本文件夹', 'game')
  await fill('千星沙箱脚本文件夹', target)
  await fill('游戏里的项目子文件夹', 'game')
  assert.equal(await evaluate(`document.querySelector('[aria-label="复制路径示例"]').innerText.includes(${JSON.stringify(`${target.replaceAll('\\', '/')}/game/main.lua`)})`), true)
  assert.equal(await evaluate(`document.querySelector('[data-quick-start-target="sync-actions"]').disabled`), true)
  assert.equal(await evaluate(`document.getElementById(document.querySelector('[data-quick-start-target="sync-actions"]').getAttribute('aria-describedby')).textContent.includes('保存设置')`), true, 'unavailable action explains what to do first')
  await evaluate(`syncTest.hold = 'save'`)
  await click('保存设置')
  await wait(`document.querySelector('[data-quick-start-target="sync-settings"] [aria-busy=true]')?.textContent === '保存设置'`)
  assert.equal(await evaluate(`document.querySelector('[data-quick-start-target="sync-settings"] [aria-busy=true]').disabled`), true)
  assert.equal(await evaluate(`document.querySelector('[data-quick-start-target="sync-settings"] [aria-busy=true]').classList.contains('primary')`), true)
  await evaluate(`document.querySelector('[data-quick-start-target="sync-settings"] [aria-busy=true]').click()`)
  await wait(`syncTest.counts.save === 1 && typeof syncTest.release === 'function'`)
  await evaluate(`syncTest.hold = ''; syncTest.release()`)
  await wait(`!![...document.querySelectorAll('button')].find(e => e.textContent === '保存存档并查看更新' && !e.disabled)`)
  assert.equal(JSON.parse(readFileSync(join(workspace, 'game.save.json'), 'utf8')).scriptSync.clientImportRoot, target)
  assert.equal(await evaluate(`syncTest.counts.save`), 1, 'saving settings cannot be submitted twice while busy')
  assert.equal(await evaluate(`document.querySelector('[data-quick-start-target="sync-actions"]').classList.contains('primary')`), true)
  await evaluate(`syncTest.hold = 'preview'`)
  await click('保存存档并查看更新')
  await wait(`typeof syncTest.release === 'function' && syncTest.counts.preview === 1`)
  assert.equal(await evaluate(`document.querySelector('[data-quick-start-target="sync-actions"]').getAttribute('aria-busy')`), 'true')
  assert.equal(readFileSync(join(target, 'game/main.lua'), 'utf8'), '-- browser old')
  await evaluate(`document.querySelector('[data-quick-start-target="sync-actions"]').click(); syncTest.hold = ''; syncTest.release()`)
  await wait(`!!document.querySelector('[aria-label="脚本同步确认"]')`)
  assert.equal(await evaluate(`syncTest.counts.preview`), 1)
  assert.equal(await evaluate(`document.querySelector('[data-quick-start-target="sync-confirm"] .primary').textContent`), '确认复制 1 个脚本')
  assert.equal(await evaluate(`document.querySelector('[data-quick-start-target="sync-actions"]').classList.contains('primary')`), false, 'the explicit copy confirmation becomes the main action')
  assert.equal(readFileSync(join(target, 'game/main.lua'), 'utf8'), '-- browser old')
  await click('暂不复制')
  assert.equal(readFileSync(join(target, 'game/main.lua'), 'utf8'), '-- browser old')
  await click('保存存档并查看更新')
  await wait(`!![...document.querySelectorAll('button')].find(e => e.textContent === '确认复制 1 个脚本' && !e.disabled)`)
  await evaluate(`syncTest.hold = 'script-sync-apply'`)
  await click('确认复制 1 个脚本')
  await wait(`syncTest.counts['script-sync-apply'] === 1`)
  assert.equal(await evaluate(`!!document.querySelector('.qxsim-sync-message[aria-busy=true]')`), true, 'copying retains visible progress after the confirmation list closes')
  assert.equal(readFileSync(join(target, 'game/main.lua'), 'utf8'), '-- browser old')
  await evaluate(`syncTest.hold = ''; syncTest.release()`)
  await wait(`document.body.innerText.includes('脚本已复制到千星沙箱')`)
  assert.equal(await evaluate(`document.body.innerText.includes('回到千星沙箱，保存关卡并重新试玩')`), true)
  assert.equal(readFileSync(join(target, 'game/main.lua'), 'utf8'), '-- browser new')
})
