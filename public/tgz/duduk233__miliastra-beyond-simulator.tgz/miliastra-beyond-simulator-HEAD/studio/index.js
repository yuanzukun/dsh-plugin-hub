import { existsSync, readFileSync } from 'node:fs'
import { createHash, randomUUID } from 'node:crypto'
import { normalizeScriptSync } from './script-sync-config.js'
import { basename, dirname, isAbsolute, join, resolve } from 'node:path'
import { isDeepStrictEqual } from 'node:util'
import { applyPatch, createProject, snapshotProject } from './ui/project.js'
import { assertSaveVersion } from './ui/migrate-layout.js'
import { createDefaultClientTemplateProject, createDefaultProject, findNode, sanitizeNode, walk } from './ui/authoring.js'
import {
  startPlay,
  stepPlay,
  playSnapshot,
  injectPlayKey,
  injectPlayClick,
  injectPlayPointer,
  stopPlay,
  setPlayVar,
  getPlayVar,
  sendPlaySignal,
  setPlayView,
  playAdapter,
} from './play/session.js'
import { caseFromHistory, normalizeCase } from './autotest/format.js'
import { replayCase } from './autotest/runner.js'
import { compileProject } from './play/compile.js'
import { toJson, assertNoUndefined } from './json.js'
import { filterLogs } from './log/collect.js'
import { CANVAS_PRESETS } from './constants.js'
import { MAX_PLAYERS, PLAYER_SLOTS, normalizePlayerCount, normalizePlayerIndex, normalizeServerLogic } from 'qxqy-server'
import { exportGia, exportCombinedGia, importGia, inspectGia, validateGiaCompatibility, validateServerGiaCompatibility, exportScriptGia, importScriptGia, isScriptGia } from './gia/codec.js'
import { GUID_MAX, GUID_MIN, collectUsedGuids, isStoredGuid, isValidGuid, nextFreeGuid } from './gia/guid.js'
import { collectClientNodes } from './gia/client-order.js'
import { scriptGuidSignature } from './control-guid-lua.js'
import { clientExportChoices, prepareClientExport } from './gia/partial-export.js'

// 脚本与测试从 qxqy-studio 包入口直接消费这些 GIA 工具导出。
export { exportGia, exportCombinedGia, importGia, inspectGia, validateGiaCompatibility, validateServerGiaCompatibility, exportScriptGia, importScriptGia, isScriptGia }

const ENTITY_LABELS = {
  Level: '关卡',
  PlayerSelf: '当前玩家',
  AvatarSelf: '当前角色',
  ...Object.fromEntries(PLAYER_SLOTS.map((name, i) => [name, `玩家${i + 1}`])),
  ...Object.fromEntries(Array.from({ length: MAX_PLAYERS }, (_, i) => [`Avatar${i + 1}`, `角色${i + 1}`])),
}

function listServerVars(server, playerCount = 1) {
  const bags = server?.vars || {}
  const out = []
  const count = Number(playerCount) > 0 ? Number(playerCount) : 1
  const types = ['Level', 'PlayerSelf', 'AvatarSelf']
  if (count > 1) {
    for (let i = 1; i <= count; i += 1) types.push(`Player${i}`, `Avatar${i}`)
  }
  const seen = new Set()
  for (const entityType of types) {
    if (seen.has(entityType) || !bags[entityType]) continue
    seen.add(entityType)
    const bag = bags[entityType] || {}
    for (const name of Object.keys(bag)) {
      out.push(toJson({
        entityType,
        entityLabel: ENTITY_LABELS[entityType] || entityType,
        name,
        type: bag[name]?.type || '',
        value: bag[name]?.value ?? null,
      }))
    }
  }
  return out
}

const SAVE_FORMAT = 'qxqy-simulator-save'
const SCRIPT_BUNDLE_FORMAT = 'qxqy-simulator-scripts'
const SERVER_ASSET = 'server-control-template'
const CLIENT_ASSET = 'client-control-template'
const ASSET_LABELS = {
  [SERVER_ASSET]: '服务器控件模板',
  [CLIENT_ASSET]: '客户端控件模板',
}

function assetKey(assetType) {
  return assetType === CLIENT_ASSET ? 'client' : 'server'
}

function controlGuid(value) {
  const numeric = typeof value === 'number' || (typeof value === 'string' && /^\d+$/.test(value.trim()))
  if (!numeric || !isValidGuid(value)) {
    throw new Error(`控件索引必须是 ${GUID_MIN}–${GUID_MAX}（0x40000000–0x403FFFFF）范围内的整数`)
  }
  return Number(value)
}

// Both ends of historical changes may predate the export range constraint.
function legacyControlGuid(value) {
  const numeric = typeof value === 'number' || (typeof value === 'string' && /^\d+$/.test(value.trim()))
  const guid = Number(value)
  if (!numeric || !isStoredGuid(guid)) {
    throw new Error('控件索引必须是 1–2147483647 范围内的整数')
  }
  return guid
}

function readControlGuidChanges(raw = []) {
  if (!Array.isArray(raw)) throw new Error('controlGuidChanges 必须是数组')
  const ids = new Set()
  return raw.map((entry) => {
    if (!entry || typeof entry.id !== 'string' || !entry.id || ids.has(entry.id)
      || ![SERVER_ASSET, CLIENT_ASSET].includes(entry.controlAsset)
      || typeof entry.controlId !== 'string' || !entry.controlId || typeof entry.controlName !== 'string') {
      throw new Error('controlGuidChanges 包含无效或重复的变更记录')
    }
    ids.add(entry.id)
    if (entry.batchId !== undefined && (typeof entry.batchId !== 'string' || !entry.batchId)) {
      throw new Error('controlGuidChanges 包含无效的 batchId')
    }
    if (entry.scriptSignature !== undefined && !/^[a-f0-9]{64}$/.test(entry.scriptSignature)) {
      throw new Error('controlGuidChanges 包含无效的 scriptSignature')
    }
    return {
      id: entry.id, controlAsset: entry.controlAsset, controlId: entry.controlId, controlName: entry.controlName,
      oldGuid: legacyControlGuid(entry.oldGuid), newGuid: legacyControlGuid(entry.newGuid),
      ...(entry.batchId ? { batchId: entry.batchId } : {}),
      ...(entry.scriptSignature ? { scriptSignature: entry.scriptSignature } : {}),
    }
  })
}

function normalizeScriptGuid(raw) {
  const candidates = [raw?.guid, raw?.id]
  for (const value of candidates) {
    const guid = Number(value)
    if (isStoredGuid(guid)) return guid
  }
  return 0
}

function normalizeScriptEntry(raw) {
  const rawAsset = String(raw?.controlAsset || '')
  const guid = normalizeScriptGuid(raw)
  return {
    id: guid ? String(guid) : String(raw?.id || ''),
    guid,
    path: String(raw?.path || ''),
    source: String(raw?.source || ''),
    controlId: String(raw?.controlId || ''),
    controlAsset: rawAsset === CLIENT_ASSET || rawAsset === 'client' ? CLIENT_ASSET
      : rawAsset === SERVER_ASSET || rawAsset === 'server' ? SERVER_ASSET
        : '',
  }
}

function seedScriptList(seed) {
  const list = []
  const push = (raw, controlAsset = '') => {
    if (!raw) return
    if (raw.path || raw.source) {
      const entry = normalizeScriptEntry(raw)
      list.push(controlAsset ? { ...entry, controlAsset } : entry)
    }
  }
  if (Array.isArray(seed?.assets?.scripts)) {
    for (const raw of seed.assets.scripts) {
      if (raw && (raw.path || raw.source)) list.push(normalizeScriptEntry(raw))
    }
    return list
  }
  push(seed?.assets?.server?.script, SERVER_ASSET)
  push(seed?.assets?.client?.script, CLIENT_ASSET)
  if (seed && seed.format !== SAVE_FORMAT) {
    push(seed?.script)
    for (const raw of seed?.scripts || []) push(raw)
  }
  return list
}

function defaultProject(assetType) {
  return createProject(assetType === CLIENT_ASSET
    ? createDefaultClientTemplateProject()
    : createDefaultProject())
}

const UNBOUND_WORKSPACE_NAME = '未绑定'
const DEFAULT_SAVE_NAME = '未命名存档'
const DEFAULT_PROJECT_NAME = '未命名界面'


function findWorkspaceRoot(start) {
  let dir = start
  for (let i = 0; i < 8; i++) {
    if (existsSync(join(dir, 'simulator', 'studio')) && existsSync(join(dir, 'lua'))) return dir
    const parent = dirname(dir)
    if (parent === dir) break
    dir = parent
  }
  return start
}

function describeWorkspace(path) {
  if (!path) return { name: UNBOUND_WORKSPACE_NAME, path: '', bound: false }
  return { name: basename(path), path, bound: true }
}

function resolveWorkspaceFile(relOrAbs, cwd = process.cwd()) {
  if (isAbsolute(relOrAbs) && existsSync(relOrAbs)) return relOrAbs
  const start = cwd || process.cwd()
  const root = findWorkspaceRoot(start)
  const fromRoot = resolve(root, relOrAbs)
  if (existsSync(fromRoot)) return fromRoot
  const fromCwd = resolve(start, relOrAbs)
  if (existsSync(fromCwd)) return fromCwd
  throw new Error('script file not found: ' + relOrAbs)
}

export function createStudio(seed, options = {}) {
  if (seed?.format === SAVE_FORMAT) assertSaveVersion(seed.version)
  let migrationWarnings = []
  // 显示用的工作区必须是会话 cwd 本身，缺省保持未绑定，绝不回退到宿主 process.cwd()。
  // 仓库根只用于解析相对路径脚本，不改写顶栏身份。
  let workspacePath = typeof options.workspacePath === 'string' && options.workspacePath
    ? options.workspacePath
    : ''
  const isSave = seed?.format === SAVE_FORMAT && seed.assets
  let controlGuidChanges = readControlGuidChanges(seed?.controlGuidChanges)
  let scriptSync = normalizeScriptSync(seed?.scriptSync)
  const seededProject = isSave ? null : createProject(seed, { warnings: migrationWarnings })
  // In-process Web hibernation restores our own archive verbatim. Import
  // normalization can change empty fields (null -> ''), invalidating a saved
  // fingerprint even though no edit occurred. Never use this for file imports.
  const restoring = Boolean(isSave && options.restoreSession)
  const projects = restoring ? structuredClone({ server: seed.assets.server, client: seed.assets.client }) : {
    server: isSave && seed.assets.server ? createProject(seed.assets.server, { warnings: migrationWarnings }) : defaultProject(SERVER_ASSET),
    client: isSave && seed.assets.client ? createProject(seed.assets.client, { warnings: migrationWarnings }) : defaultProject(CLIENT_ASSET),
  }
  if (seededProject) projects[assetKey(seededProject.meta.assetType)] = seededProject
  let activeAssetType = isSave && seed.activeAssetType === CLIENT_ASSET
    ? CLIENT_ASSET
    : seededProject?.meta.assetType || SERVER_ASSET
  // 显式存档名（renameSave / 导入存档包写入）优先；否则用中性默认名，不跟目录名漂。
  let explicitSaveName = isSave && seed.meta?.name ? String(seed.meta.name) : ''
  const currentSaveName = () => explicitSaveName || DEFAULT_SAVE_NAME
  if (!seed?.meta?.name && projects.server.meta.name === '未命名界面控件组') {
    projects.server.meta.name = DEFAULT_PROJECT_NAME
  }
  let scripts = []
  const usedScriptGuids = new Set()
  function refreshUsedGuids() {
    usedScriptGuids.clear()
    collectUsedGuids(projects.server.root, usedScriptGuids)
    collectUsedGuids(projects.client.root, usedScriptGuids, { skipServerContainer: true })
    for (const script of scripts) {
      if (isStoredGuid(script.guid)) usedScriptGuids.add(Number(script.guid))
    }
  }
  function allocateScriptGuid(preferred = 0) {
    refreshUsedGuids()
    const guid = isStoredGuid(preferred) && !usedScriptGuids.has(Number(preferred))
      ? Number(preferred)
      : nextFreeGuid(usedScriptGuids)
    usedScriptGuids.add(guid)
    return guid
  }
  function adoptScript(raw) {
    const entry = normalizeScriptEntry(raw)
    const guid = allocateScriptGuid(entry.guid)
    return { ...entry, guid, id: String(guid) }
  }
  absorbScripts(seedScriptList(seed))
  let serverLogic = normalizeServerLogic(seed?.serverLogic)
  let play = null
  // 试玩侧设备画布：显式指定后粘性生效（隐式重启沿用），playStop 后回到跟随编辑器画布。
  let playCanvasId = ''
  let playPlayerCount = 1
  let playViewPlayerIndex = 1

  function normalizePlayCanvasId(raw) {
    const key = String(raw || '').trim()
    if (!key) return ''
    if (!CANVAS_PRESETS[key]) {
      throw new Error(`unknown canvas preset: ${key} (available: ${Object.keys(CANVAS_PRESETS).join(', ')})`)
    }
    return key
  }

  const currentProject = () => projects[assetKey(activeAssetType)]

  function findControlTarget(controlId) {
    if (!controlId) return null
    for (const [key, project] of [['server', projects.server], ['client', projects.client]]) {
      const node = findNode(project.root, controlId)
      if (node && node.kind !== 'server-container') return { key, node }
    }
    return null
  }

  function resolveScriptTarget(script) {
    if (!script.controlId) return null
    const assetKey = script.controlAsset === CLIENT_ASSET ? 'client' : script.controlAsset === SERVER_ASSET ? 'server' : null
    if (assetKey) {
      const node = findNode(projects[assetKey].root, script.controlId)
      if (node && node.kind !== 'server-container') return { key: assetKey, node }
      return null
    }
    return findControlTarget(script.controlId)
  }

  function reconcileScriptMounts() {
    for (const script of scripts) {
      if (script.controlId && !resolveScriptTarget(script)) {
        script.controlId = ''
        script.controlAsset = ''
      }
    }
  }

  function scriptMountFromGenericSlot(guid) {
    if (!isStoredGuid(guid)) return null
    for (const [assetType, project] of [[SERVER_ASSET, projects.server], [CLIENT_ASSET, projects.client]]) {
      let controlId = ''
      walk(project.root, (node) => {
        if (!controlId && (node.scriptMappingIds || []).includes(Number(guid))) controlId = node.id
      })
      if (controlId) return { controlId, controlAsset: assetType }
    }
    return null
  }

  function rewriteGenericScriptGuid(mount, previousGuid, nextGuid) {
    const project = projects[assetKey(mount.controlAsset)]
    const node = project && findNode(project.root, mount.controlId)
    if (!node) return
    node.scriptMappingIds = (node.scriptMappingIds || []).map((guid) => (
      Number(guid) === Number(previousGuid) ? Number(nextGuid) : guid
    ))
  }
  reconcileScriptMounts()

  function describeScripts() {
    return scripts.map((script) => {
      const target = resolveScriptTarget(script)
      const assetType = target ? (target.key === 'client' ? CLIENT_ASSET : SERVER_ASSET) : ''
      return toJson({
        id: script.id,
        guid: script.guid || 0,
        path: script.path || '',
        source: script.source || '',
        controlId: script.controlId || '',
        controlAsset: script.controlAsset || assetType,
        controlName: target?.node.name || '',
        assetType,
        assetLabel: target ? ASSET_LABELS[assetType] : '',
        mounted: Boolean(target),
      })
    })
  }

  function mountTargetRows() {
    const out = []
    const collect = (project, assetType) => {
      walk(project.root, (node) => {
        if (node.kind === 'server-container') return
        out.push(toJson({ id: node.id, name: node.name, kind: node.kind, assetType, assetLabel: ASSET_LABELS[assetType] }))
      })
    }
    collect(projects.server, SERVER_ASSET)
    collect(projects.client, CLIENT_ASSET)
    return out
  }

  const factoryRoots = {
    client: sanitizeNode(createDefaultClientTemplateProject().root),
    server: sanitizeNode(createDefaultProject().root),
  }

  function isFactoryDefaultProject(project) {
    // Normalize both trees as on import so a save/reload preserves the comparison.
    return isDeepStrictEqual(sanitizeNode(project.root), factoryRoots[assetKey(project.meta.assetType)])
  }

  function safeFilePart(name, fallback) {
    const cleaned = String(name || '').replace(/[\\/:*?"<>|]/g, '-').trim()
    return cleaned || fallback
  }

  function assetExportStem(project) {
    const save = safeFilePart(currentSaveName(), DEFAULT_SAVE_NAME)
    const kind = project.meta?.assetType === CLIENT_ASSET ? '客户端控件模板' : '服务器控件模板'
    return `${save} · ${kind}`
  }

  function buildCombinedControlProject() {
    const hostRoot = (projects.server.root.children || []).find((node) => node.kind === 'container')
      || projects.server.root.children?.[0]
    if (!hostRoot) throw new Error('整合包需要服务端客户端控件容器下至少有一个根控件')
    return exportCombinedGia(projects.server, projects.client, {
      scripts,
      fileName: `${safeFilePart(currentSaveName(), DEFAULT_SAVE_NAME)} · 整合包.gia`,
    })
  }

  function saveDescriptor() {
    const describe = (project) => ({
      type: project.meta.assetType,
      name: project.meta.name,
      sourceFile: project.meta.sourceFile || '',
    })
    return {
      format: SAVE_FORMAT,
      name: currentSaveName(),
      activeAssetType,
      assets: {
        server: describe(projects.server),
        client: describe(projects.client),
        scripts: describeScripts(),
      },
    }
  }

  function archiveData() {
    return toJson(archiveRecord())
  }

  function archiveRecord() {
    return {
      format: SAVE_FORMAT,
      version: 4,
      meta: { name: currentSaveName() },
      activeAssetType,
      serverLogic,
      controlGuidChanges,
      scriptSync,
      assets: {
        server: projects.server,
        client: projects.client,
        scripts: scripts.map((script) => ({
          id: script.id,
          guid: script.guid || 0,
          path: script.path || '',
          source: script.source || '',
          controlId: script.controlId || '',
          controlAsset: script.controlAsset || '',
        })),
      },
    }
  }

  // Archives also carry the last editor view. Browsing a different asset,
  // selecting a node, or advancing a revision is not an edit to the game.
  let authoringHash
  function contentHash() {
    if (authoringHash === undefined) {
      const { activeAssetType, ...record } = archiveRecord()
      for (const key of ['server', 'client']) {
        const { version, selectedId, canvasId, keyHintDevice, ...asset } = record.assets[key]
        record.assets[key] = asset
      }
      authoringHash = createHash('sha256').update(JSON.stringify(record)).digest('hex')
    }
    return authoringHash
  }

  function get() {
    const project = currentProject()
    const snap = snapshotProject(project)
    snap.workspace = describeWorkspace(workspacePath)
    snap.save = saveDescriptor()
    snap.scripts = describeScripts()
    snap.mountTargets = mountTargetRows()
    snap.serverLogic = serverLogic
    snap.migrationWarnings = [...migrationWarnings]
    snap.controlGuidChanges = toJson(controlGuidChanges)
    if (activeAssetType === CLIENT_ASSET) {
      const ordered = collectClientNodes(project, true)
      snap.clientGuidAutofill = {
        count: ordered.length,
        templateCount: ordered.filter(({ parent }) => parent?.kind === 'server-container').length,
        selectedOffset: ordered.findIndex(({ node }) => node.id === snap.selectedId),
      }
    }
    snap.scriptSync = toJson(scriptSync)
    assertNoUndefined(snap)
    return snap
  }

  function checkRevision(op) {
    const project = currentProject()
    if (op.expectedRevision !== undefined && Number(op.expectedRevision) !== project.version) {
      throw new Error(`revision conflict: expected ${op.expectedRevision}, current ${project.version}`)
    }
    return project
  }

  function setScriptMount(script, controlId, controlAsset = '') {
    const value = String(controlId || '')
    if (value) {
      const asset = controlAsset === CLIENT_ASSET ? CLIENT_ASSET : controlAsset === SERVER_ASSET ? SERVER_ASSET : ''
      const probe = { controlId: value, controlAsset: asset }
      if (!resolveScriptTarget(probe)) throw new Error('挂载目标必须是存档内的客户端控件或客户端控件模板')
      script.controlAsset = asset
    } else {
      script.controlAsset = ''
    }
    script.controlId = value
  }

  function applyScriptOp(op) {
    const project = checkRevision(op)
    if (op.op === 'addScript') {
      const script = adoptScript({ path: String(op.path || ''), source: String(op.source || ''), controlId: '', controlAsset: '' })
      if (op.controlId !== undefined && op.controlId !== '') setScriptMount(script, op.controlId, op.controlAsset)
      scripts.push(script)
    } else if (op.op === 'updateScript') {
      const script = scripts.find((row) => row.id === op.id)
      if (!script) throw new Error(`脚本不存在: ${op.id}`)
      if (op.controlId !== undefined) setScriptMount(script, op.controlId, op.controlAsset)
      if (op.path !== undefined) script.path = String(op.path)
      if (op.source !== undefined) script.source = String(op.source)
    } else if (op.op === 'removeScript') {
      const before = scripts.length
      scripts = scripts.filter((row) => row.id !== op.id)
      if (scripts.length === before) throw new Error(`脚本不存在: ${op.id}`)
    }
    project.version += 1
    return get()
  }

  function setControlGuid(op) {
    const project = checkRevision(op)
    const node = findNode(project.root, op.id ?? project.selectedId)
    if (!node) throw new Error('控件不存在，请重新选择后修改索引')
    // The server asset has a real GIA container; the client asset's holder is
    // only an authoring root and has no exported control identity.
    if (node.kind === 'server-container' && activeAssetType !== SERVER_ASSET) {
      throw new Error('客户端模板列表根节点不是真实控件，不能修改索引')
    }
    const guid = controlGuid(op.guid)
    legacyControlGuid(node.guid)
    if (op.autoFillClientGuids !== undefined && typeof op.autoFillClientGuids !== 'boolean') {
      throw new Error('autoFillClientGuids 必须是布尔值')
    }
    const automatic = op.autoFillClientGuids === true
    if (automatic && activeAssetType !== CLIENT_ASSET) {
      throw new Error('自动填充仅支持客户端模板列表；服务端界面的索引需单独填写')
    }
    const targets = automatic ? collectClientNodes(project, true).map(({ node }) => node) : [node]
    const base = guid - targets.indexOf(node)
    const mappings = targets.map((target, offset) => ({
      node: target, oldGuid: legacyControlGuid(target.guid), newGuid: controlGuid(base + offset),
    }))
    const changes = mappings.filter(({ oldGuid, newGuid }) => oldGuid !== newGuid)
    if (!changes.length) return get()
    const remap = new Map(mappings.map(({ oldGuid, newGuid }) => [oldGuid, newGuid]))
    if (remap.size !== mappings.length) throw new Error('客户端模板存在重复旧索引，无法自动填充；请先消除歧义')
    const targetSet = new Set(targets)
    const nodes = []
    for (const entry of Object.values(projects)) {
      walk(entry.root, (candidate) => {
        if (entry === projects.client && candidate.kind === 'server-container') return
        nodes.push({ node: candidate, project: entry })
      })
    }
    const occupied = new Map([
      ...nodes.filter((entry) => !targetSet.has(entry.node)).map(({ node }) => [Number(node.guid), node.name]),
      ...scripts.map((script) => [Number(script.guid), script.path || 'Lua 脚本']),
    ])
    for (const { newGuid } of changes) {
      if (occupied.has(newGuid)) throw new Error(`控件索引 ${newGuid} 已被「${occupied.get(newGuid)}」占用；请先填写它的实际索引。本次未修改任何索引。`)
    }
    // These three fields are explicit GUID references. Internal ids, button
    // state ids, image ids and Lua numbers must never be replaced by value.
    const references = []
    const collectReference = (owner, key, entry) => {
      const value = owner?.[key]
      if ((typeof value === 'number' || (typeof value === 'string' && /^\d+$/.test(value.trim())))
        && remap.has(Number(value)) && remap.get(Number(value)) !== Number(value)) {
        references.push({ owner, key, project: entry.project, oldGuid: Number(value), newGuid: remap.get(Number(value)) })
      }
    }
    for (const entry of nodes) {
      collectReference(entry.node, 'referencedPrefabId', entry)
      collectReference(entry.node, 'itemPrefabId', entry)
      collectReference(entry.node.giaRaw, 'templateRefSlot', entry)
    }
    const occurrences = new Map()
    for (const { node } of nodes) occurrences.set(Number(node.guid), (occurrences.get(Number(node.guid)) || 0) + 1)
    for (const { oldGuid } of references) {
      if (occurrences.get(oldGuid) !== 1) throw new Error(`旧索引 ${oldGuid} 在多棵资产树中重复，无法确定模板引用归属；请先消除歧义后修改`)
    }
    // All validation is complete before changing either tree or the ledger.
    // One batch is a simultaneous permutation, never a chain of replacements.
    const batchId = automatic ? randomUUID() : ''
    const scriptSignature = scriptGuidSignature(scripts)
    for (const { node, oldGuid, newGuid } of changes) {
      node.guid = newGuid
      controlGuidChanges.push({
        id: randomUUID(), controlAsset: activeAssetType, controlId: node.id,
        controlName: node.name, oldGuid, newGuid, scriptSignature, ...(batchId ? { batchId } : {}),
      })
    }
    const changedProjects = new Set([project])
    for (const { owner, key, project: referencedProject, newGuid } of references) {
      owner[key] = typeof owner[key] === 'string' ? String(newGuid) : newGuid
      changedProjects.add(referencedProject)
    }
    for (const changed of changedProjects) changed.version += 1
    return get()
  }

  function acknowledgeControlGuidChanges(op) {
    const project = checkRevision(op)
    if (!Array.isArray(op.changeIds) || !op.changeIds.length
      || op.changeIds.some((id) => typeof id !== 'string' || !controlGuidChanges.some((change) => change.id === id))) {
      throw new Error('请明确指定已核对 Lua 引用的有效索引变更记录 changeIds')
    }
    const acknowledged = new Set(op.changeIds)
    controlGuidChanges = controlGuidChanges.filter((change) => !acknowledged.has(change.id))
    project.version += 1
    return get()
  }

  function patch(op) {
    if (!op || typeof op !== 'object') throw new Error('patch requires op')
    if (!['select', 'pick', 'selectAsset', 'setCanvas', 'setKeyHintDevice'].includes(op.op)) authoringHash = undefined
    if (op.op === 'setScriptSync') {
      const project = checkRevision(op)
      scriptSync = normalizeScriptSync(op.config)
      project.version += 1
      return get()
    }
    if (op.op === 'setControlGuid') return setControlGuid(op)
    if (op.op === 'acknowledgeControlGuidChanges') return acknowledgeControlGuidChanges(op)
    if (op.op === 'setServerLogic') {
      const project = checkRevision(op)
      serverLogic = normalizeServerLogic(op.logic)
      project.version += 1
      return get()
    }
    if (op.op === 'addScript' || op.op === 'updateScript' || op.op === 'removeScript') {
      return applyScriptOp(op)
    }
    if (op.op === 'selectAsset') {
      activeAssetType = op.assetType === CLIENT_ASSET ? CLIENT_ASSET : SERVER_ASSET
      return get()
    }
    if (op.op === 'renameSave') {
      const name = String(op.name || '').trim()
      if (!name) throw new Error('存档名称不能为空')
      explicitSaveName = name
      return get()
    }
    if (op.op === 'newAsset') {
      const project = checkRevision(op)
      activeAssetType = op.assetType === CLIENT_ASSET ? CLIENT_ASSET : SERVER_ASSET
      const next = defaultProject(activeAssetType)
      next.version = project.version + 1
      projects[assetKey(activeAssetType)] = next
      controlGuidChanges = controlGuidChanges.filter((change) => change.controlAsset !== activeAssetType)
      reconcileScriptMounts()
      return get()
    }
    applyPatch(currentProject(), op)
    reconcileScriptMounts()
    return get()
  }

  function scriptsInProject(assetType) {
    return scripts.filter((script) => {
      const target = resolveScriptTarget(script)
      return Boolean(target && (target.key === 'client') === (assetType === CLIENT_ASSET))
    })
  }

  function exportChoices() {
    return toJson({ assetType: CLIENT_ASSET, revision: projects.client.version,
      rows: clientExportChoices(projects.client, scriptsInProject(CLIENT_ASSET)) })
  }

  function partialExport(options = {}) {
    if (options.expectedRevision !== undefined && options.expectedRevision !== projects.client.version) {
      throw new Error('revision conflict: reload export choices')
    }
    const eligible = scripts.filter(script => !script.controlId || resolveScriptTarget(script)?.key === 'client')
    const result = prepareClientExport(projects.client, eligible, options)
    if (options.canvasId) {
      if (!CANVAS_PRESETS[options.canvasId]) throw new Error(`unknown canvas preset: ${options.canvasId}`)
      result.project.canvasId = options.canvasId
    }
    return result
  }

  function exportPreview(options = {}) {
    const result = partialExport(options)
    return toJson({ snapshot: snapshotProject(result.project), selection: result.selection, warnings: result.warnings })
  }

  function exportData(format = 'json', requestedAssetType = '', options = {}) {
    const result = exportDataRaw(format, requestedAssetType, options)
    if (controlGuidChanges.length && !['save', 'archive'].includes(String(format).toLowerCase())) {
      const warnings = controlGuidChanges.map((change) => `控件索引待核对 Lua 引用：${ASSET_LABELS[change.controlAsset]} / ${change.controlName} (${change.controlId})：${change.oldGuid} → ${change.newGuid}。请按语义更新脚本中的控件索引引用，核对后确认变更记录 ${change.id}；不要全局替换同值数字。`)
      result.warnings = [...new Set([...(result.warnings || []), ...warnings])]
    }
    return result
  }

  function exportDataRaw(format = 'json', requestedAssetType = '', options = {}) {
    const normalized = String(format).toLowerCase()
    if (normalized === 'gia-partial') {
      const partial = partialExport(options)
      const result = exportGia(partial.project, { scripts: partial.scripts, includeScriptMappings: true })
      const label = partial.selection.templateCount === 1 ? partial.project.root.children[0].name : '部分组合'
      return toJson({ filename: `${safeFilePart(currentSaveName(), DEFAULT_SAVE_NAME)} · ${safeFilePart(label, '部分组合')}.gia`,
        mimeType: 'application/octet-stream', encoding: 'base64', data: result.buffer.toString('base64'),
        selection: partial.selection, warnings: [...new Set([...partial.warnings, ...result.warnings])] })
    }
    if (normalized === 'save' || normalized === 'archive') {
      const data = Buffer.from(JSON.stringify(archiveData(), null, 2), 'utf8')
      return toJson({
        filename: `${currentSaveName().replace(/[\\/:*?"<>|]/g, '-')} · 资产包.json`,
        mimeType: 'application/json',
        encoding: 'base64',
        data: data.toString('base64'),
        warnings: [],
      })
    }
    if (normalized === 'save-gia' || normalized === 'archive-gia') {
      // 官方编辑器中三类资产本就是独立 GIA 文件（UIControlGroup / UIControlTemplate 列表 / script.gia），
      // 没有单文件混合格式的证据，因此资产包 GIA 以多文件交付，不捏造合并格式。
      // 另一类 UI 若仍是出厂默认且当前没在看、也没有脚本挂上去，就不要夹带进压缩包，
      // 否则用户会以为「页面上的 Flappy Fish」导出成了「Lua实例化面板」。
      const files = []
      const warnings = []
      const collect = (format, assetType = '') => {
        const result = exportData(format, assetType)
        files.push(toJson({
          filename: result.filename,
          mimeType: result.mimeType,
          encoding: result.encoding,
          data: result.data,
          warnings: result.warnings || [],
        }))
        warnings.push(...(result.warnings || []))
      }
      const includeUi = (assetType, skipMessage) => {
        const project = projects[assetKey(assetType)]
        const visible = assetType === activeAssetType
        const mounted = scripts.some((script) => script.controlAsset === assetType && script.controlId)
        if (!visible && isFactoryDefaultProject(project) && !mounted) {
          warnings.push(skipMessage)
          return
        }
        collect('gia', assetType)
      }
      includeUi(SERVER_ASSET, '服务器控件模板仍是默认橱窗，未改动且当前未显示，已从资产包 GIA 中省略。')
      includeUi(CLIENT_ASSET, '客户端控件模板仍是默认「Lua实例化面板」，未改动且当前未显示，已从资产包 GIA 中省略。')
      if (scripts.some((script) => script.path || script.source)) collect('scripts-gia')
      if (!files.length) {
        throw new Error('资产包 GIA 没有可导出的已改动项；请先编辑当前界面，或改用「当前界面 GIA」。')
      }
      return toJson({
        format: 'qxqy-gia-package',
        files,
        warnings: [...new Set(warnings)],
      })
    }
    if (normalized === 'gia-combined' || normalized === 'combined-gia' || normalized === 'combined') {
      const result = buildCombinedControlProject()
      return toJson({
        filename: `${safeFilePart(currentSaveName(), DEFAULT_SAVE_NAME)} · 整合包.gia`,
        mimeType: 'application/octet-stream',
        encoding: 'base64',
        data: result.buffer.toString('base64'),
        warnings: [...new Set(result.warnings || [])],
      })
    }
    if (normalized === 'scripts') {
      const bundle = toJson({
        format: SCRIPT_BUNDLE_FORMAT,
        version: 1,
        scripts: scripts.map((script) => toJson({
          id: script.id,
          guid: script.guid || 0,
          path: script.path || '',
          source: script.source || '',
          controlId: script.controlId || '',
          controlAsset: script.controlAsset || '',
        })),
      })
      const data = Buffer.from(JSON.stringify(bundle, null, 2), 'utf8')
      return toJson({
        filename: `${safeFilePart(currentSaveName(), DEFAULT_SAVE_NAME)} · 脚本.json`,
        mimeType: 'application/json',
        encoding: 'base64',
        data: data.toString('base64'),
        warnings: [],
      })
    }
    if (normalized === 'scripts-gia' || normalized === 'scriptsgia') {
      const result = exportScriptGia(scripts)
      return toJson({
        filename: `${safeFilePart(currentSaveName(), DEFAULT_SAVE_NAME)} · 脚本.gia`,
        mimeType: 'application/octet-stream',
        encoding: 'base64',
        data: result.buffer.toString('base64'),
        warnings: result.warnings,
      })
    }
    if (normalized === 'lua') {
      const script = scripts.find((row) => row.id === requestedAssetType)
        || scripts.find((row) => row.path === requestedAssetType)
      if (!script) throw new Error('没有可导出的 Lua 脚本，请先在“Lua 脚本”页创建')
      const filename = basename(script.path || '') || `qxqy-script-${script.id}`
      return toJson({
        filename: /\.lua$/i.test(filename) ? filename : `${filename}.lua`,
        mimeType: 'text/x-lua',
        encoding: 'base64',
        data: Buffer.from(script.source || '', 'utf8').toString('base64'),
        warnings: [],
      })
    }
    const project = requestedAssetType
      ? projects[assetKey(requestedAssetType)]
      : currentProject()
    const baseName = assetExportStem(project)
    if (normalized === 'json') {
      const payload = toJson({
        ...project, scripts: scriptsInProject(project.meta.assetType),
        controlGuidChanges: controlGuidChanges.filter((change) => change.controlAsset === project.meta.assetType),
      })
      const data = Buffer.from(JSON.stringify(payload, null, 2), 'utf8')
      return toJson({
        filename: `${baseName}.json`,
        mimeType: 'application/json',
        encoding: 'base64',
        data: data.toString('base64'),
        warnings: [],
      })
    }
    if (normalized === 'gia') {
      const result = exportGia(project, project.meta.assetType === CLIENT_ASSET
        ? { scripts: scriptsInProject(CLIENT_ASSET) }
        : {})
      const excludedScripts = project.meta.assetType === CLIENT_ASSET ? [] : scriptsInProject(SERVER_ASSET)
      if (excludedScripts.length) result.warnings.unshift(`当前服务器控件 GIA 不包含 ${excludedScripts.length} 个 Lua 脚本的源码；请使用「资产包 GIA 整合包」，或另行导入脚本包并核对挂载。`)
      return toJson({
        filename: `${baseName}.gia`,
        mimeType: 'application/octet-stream',
        encoding: 'base64',
        data: result.buffer.toString('base64'),
        warnings: result.warnings,
      })
    }
    throw new Error(`unsupported export format: ${format}`)
  }

  function absorbScripts(rawList) {
    for (const raw of rawList) {
      const entry = normalizeScriptEntry(raw)
      if (!entry.path && !entry.source) continue
      const genericMount = entry.controlId ? null : scriptMountFromGenericSlot(entry.guid)
      const script = adoptScript(genericMount ? { ...entry, ...genericMount } : entry)
      if (genericMount && script.guid !== entry.guid) {
        // A separately imported UI asset can share a GUID with the inactive
        // default tree. Keep the newly allocated script GUID and repair the
        // GenericSlot reference so the restored mount remains exportable.
        rewriteGenericScriptGuid(genericMount, entry.guid, script.guid)
      }
      if (script.controlId && !resolveScriptTarget(script)) {
        script.controlId = ''
        script.controlAsset = ''
      }
      scripts.push(script)
    }
  }

  function importData(format, base64, filename = '') {
    authoringHash = undefined
    const normalized = String(format || '').toLowerCase()
    if (typeof base64 !== 'string' || !base64) throw new Error('import data is required')
    const bytes = Buffer.from(base64, 'base64')
    let next
    let warnings = []
    let metadata = {}
    let importedGiaScripts = []
    if (normalized === 'json') {
      try {
        next = JSON.parse(bytes.toString('utf8'))
      } catch {
        throw new Error('JSON 文件无效')
      }
      if (next?.project) next = next.project
      if (next?.format === SAVE_FORMAT && next?.assets) {
        assertSaveVersion(next.version)
        // Prepare the complete archive (including scripts and the GUID-change
        // ledger) before committing; no validation failure may partially import.
        const preparedStudio = createStudio(next)
        warnings.push(...preparedStudio.get().migrationWarnings)
        const prepared = preparedStudio.archiveData()
        projects.server = prepared.assets.server
        projects.client = prepared.assets.client
        migrationWarnings = [...warnings]
        activeAssetType = next.activeAssetType === CLIENT_ASSET ? CLIENT_ASSET : SERVER_ASSET
        explicitSaveName = String(next.meta?.name || basename(filename).replace(/\.json$/i, '') || explicitSaveName)
        serverLogic = prepared.serverLogic
        scripts = prepared.assets.scripts
        controlGuidChanges = prepared.controlGuidChanges
        scriptSync = prepared.scriptSync
        usedScriptGuids.clear()
        return toJson({ snapshot: get(), warnings, metadata: { format: SAVE_FORMAT } })
      }
    } else if (normalized === 'lua') {
      scripts.push(adoptScript({
        path: basename(filename || 'imported.lua'),
        source: bytes.toString('utf8'),
        controlId: '',
      }))
      return toJson({ snapshot: get(), warnings, metadata: { assetType: 'lua-script' } })
    } else if (normalized === 'gia') {
      if (isScriptGia(bytes)) {
        const imported = importScriptGia(bytes)
        absorbScripts(imported.scripts)
        return toJson({ snapshot: get(), warnings: imported.warnings, metadata: imported.metadata })
      }
      const imported = importGia(bytes)
      next = imported.project
      warnings = imported.warnings
      metadata = imported.metadata
      if (imported.clientProject) {
        projects.client = createProject(imported.clientProject)
        controlGuidChanges = controlGuidChanges.filter((change) => change.controlAsset !== CLIENT_ASSET)
        warnings.push('整合包已拆回「UI控件-服务端」与「UI控件-客户端」；客户端模板边界已保留。')
      }
      const mountByGuid = new Map()
      const collectMounts = (project, controlAsset) => {
        if (!project) return
        walk(project.root, (node) => {
          for (const guid of node.scriptMappingIds || []) {
            const existing = mountByGuid.get(Number(guid))
            if (existing) {
              warnings.push(`脚本 GUID ${guid} 同时挂载到多个控件，已保留“${existing.controlAsset === SERVER_ASSET ? '服务端' : '客户端'}”目标。`)
              continue
            }
            mountByGuid.set(Number(guid), { controlId: node.id, controlAsset })
          }
        })
      }
      collectMounts(imported.project, imported.project.meta.assetType)
      collectMounts(imported.clientProject, CLIENT_ASSET)
      importedGiaScripts = (imported.scripts || []).map((script) => (
        mountByGuid.has(Number(script.guid))
          ? { ...script, ...mountByGuid.get(Number(script.guid)) }
          : script
      ))
    } else {
      throw new Error(`unsupported import format: ${format}`)
    }
    const importedProject = createProject(next, { warnings })
    const importedChanges = readControlGuidChanges(next?.controlGuidChanges)
    if (importedChanges.some((change) => change.controlAsset !== importedProject.meta.assetType)) {
      throw new Error('单资产 JSON 的索引变更记录必须属于当前导入资产')
    }
    const nextChanges = readControlGuidChanges([
      ...controlGuidChanges.filter((change) => change.controlAsset !== importedProject.meta.assetType),
      ...importedChanges,
    ])
    migrationWarnings = [...warnings]
    const key = assetKey(importedProject.meta.assetType)
    projects[key] = importedProject
    controlGuidChanges = nextChanges
    activeAssetType = importedProject.meta.assetType
    const project = projects[key]
    if (filename) {
      project.meta.name = basename(filename).replace(/\.(json|gia)$/i, '') || project.meta.name
      project.meta.sourceFile = basename(filename)
      project.meta.sourceFormat = normalized
    }
    // Resolve mounts only after the imported control tree exists. Resolving
    // against the previous tree silently clears valid client-template mounts.
    absorbScripts(importedGiaScripts)
    absorbScripts(next?.scripts || [])
    if (next?.script && (next.script.path || next.script.source)) {
      absorbScripts([next.script])
    }
    return toJson({ snapshot: get(), warnings, metadata })
  }

  function pick(x, y) {
    applyPatch(currentProject(), { op: 'pick', x, y })
    return get()
  }

  // 会话工作区可能在首个 HTTP/工具调用时才可知。只改显示与脚本解析根，不改存档名。
  function setWorkspace(path) {
    const next = typeof path === 'string' && path ? path : ''
    if (!next || next === workspacePath) return
    workspacePath = next
  }

  function resolveScriptSource(script) {
    let source = script.source || ''
    if (!source.trim() && script.path.trim()) {
      try {
        source = readFileSync(resolveWorkspaceFile(script.path, workspacePath), 'utf8')
      } catch (err) {
        throw new Error(`脚本 ${script.path} 读取失败: ${err?.message || err}`)
      }
    }
    return source
  }

  function playStart(options = {}) {
    const requested = normalizePlayCanvasId(options.canvasId)
    if (requested) playCanvasId = requested
    if (options.playerCount !== undefined && options.playerCount !== null && options.playerCount !== '') {
      playPlayerCount = normalizePlayerCount(options.playerCount)
      if (playViewPlayerIndex > playPlayerCount) playViewPlayerIndex = 1
    }
    if (options.viewPlayerIndex !== undefined && options.viewPlayerIndex !== null && options.viewPlayerIndex !== '') {
      playViewPlayerIndex = normalizePlayerIndex(options.viewPlayerIndex, playPlayerCount)
    }
    if (play) stopPlay(play)
    const resolvedScripts = scripts.map((script) => {
      try {
        return {
          id: script.id,
          guid: script.guid || 0,
          path: script.path || script.id,
          source: resolveScriptSource(script),
          controlId: script.controlId || '',
          controlAsset: script.controlAsset || '',
        }
      } catch (err) {
        return { id: script.id, guid: script.guid || 0, path: script.path || script.id, source: `error([==[ ${String(err.message).replace(/]=+]/g, '] =]')} ])`, controlId: script.controlId || '', controlAsset: script.controlAsset || '' }
      }
    })
    const byAsset = (assetKey) => resolvedScripts.filter((script) => {
      const probe = { controlId: script.controlId, controlAsset: script.controlAsset }
      const target = script.controlId ? resolveScriptTarget(probe) : null
      return Boolean(target && target.key === assetKey)
    })
    play = startPlay(projects.server, {
      templatesProject: projects.client,
      scripts: resolvedScripts,
      sceneScripts: byAsset('server'),
      templateScripts: byAsset('client'),
      serverConfig: { logic: serverLogic },
      canvasId: playCanvasId,
      playerCount: playPlayerCount,
      viewPlayerIndex: playViewPlayerIndex,
      language: options.language || '',
      keyHintDevice: options.keyHintDevice ?? projects.server.keyHintDevice ?? 'auto',
    })
    return playGet(options)
  }

  // 多设备试玩：切换设备 = 以该设备画布重建运行时（新生命周期，与真机换设备一致）。
  function playSetCanvas(rawCanvasId, options = {}) {
    const canvasId = normalizePlayCanvasId(rawCanvasId)
    if (!canvasId) throw new Error('playSetCanvas requires canvasId')
    return playStart({ ...options, canvasId })
  }

  function playGet(options = {}) {
    if (!play) return toJson({ running: false, tree: [], logs: [], serverLogs: [], serverVars: [] })
    const snap = playSnapshot(play, options)
    snap.running = true
    snap.logs = filterLogs(snap.logs)
    snap.serverLogs = filterLogs(snap.server?.logs || [])
    snap.serverVars = listServerVars(snap.server, snap.playerCount || 1)
    return snap
  }

  function playStep(dt, options = {}) {
    if (!play) playStart()
    stepPlay(play, dt)
    if (options.observe === false) {
      return toJson({
        running: true,
        time: play.runtime.clock.time,
        frame: play.runtime.clock.frame,
        paused: !!play.debugPaused,
        levelTimePaused: !!play.runtime.clock.paused,
        playerCount: play.playerCount || 1,
        viewPlayerIndex: play.viewPlayerIndex || 1,
      })
    }
    return playGet(options)
  }

  function playRun(frames = 0) {
    playStart()
    const n = Math.max(0, Number(frames) || 0)
    for (let i = 0; i < n; i++) stepPlay(play, 1 / 30)
    return playGet()
  }

  function playStop() {
    if (play) stopPlay(play)
    play = null
    playCanvasId = ''
    playPlayerCount = 1
    playViewPlayerIndex = 1
    return toJson({ running: false, tree: [], logs: [], serverLogs: [], serverVars: [] })
  }

  function playSetView(playerIndex, options = {}) {
    const session = requirePlay()
    playViewPlayerIndex = setPlayView(session, playerIndex)
    return options.observe === false ? null : playGet(options)
  }

  function playKey(typeName, options = {}) {
    if (!play) throw new Error('play session has not started')
    injectPlayKey(play, typeName)
    return options.observe === false ? null : playGet(options)
  }

  function playClick(name, options = {}) {
    if (!play) throw new Error('play session has not started')
    injectPlayClick(play, name)
    return options.observe === false ? null : playGet(options)
  }

  function playPointer(type, x, y, options = {}) {
    if (!play) throw new Error('play session has not started')
    injectPlayPointer(play, type, x, y, options)
    return options.observe === false ? null : playGet(options)
  }

  function playPause(options = {}) {
    if (!play) return options.observe === false ? null : playGet(options)
    playAdapter(play).pause()
    return options.observe === false ? null : playGet(options)
  }

  function playResume(options = {}) {
    if (!play) return options.observe === false ? null : playGet(options)
    playAdapter(play).resume()
    return options.observe === false ? null : playGet(options)
  }

  function requirePlay() {
    if (!play) throw new Error('play session has not started')
    return play
  }

  function playServerGet(entityType, name) {
    const session = requirePlay()
    if (!entityType && !name) {
      const snap = playGet()
      return toJson({ vars: snap.serverVars || [] })
    }
    return toJson({
      entityType: String(entityType || ''),
      name: String(name || ''),
      value: getPlayVar(session, entityType, name),
    })
  }

  function playServerSet(entityType, name, value) {
    const session = requirePlay()
    setPlayVar(session, entityType, name, value)
    return playGet()
  }

  function playServerSend(name, params = [], target = 'PlayerSelf') {
    const session = requirePlay()
    sendPlaySignal(session, name, params, target)
    return playGet()
  }

  function playHistory() {
    const snap = playGet()
    return toJson({
      events: snap.history || [],
      case: caseFromHistory(snap.history || [], { playerCount: snap.playerCount || 1 }),
    })
  }

  function playSaveCase(raw = {}) {
    const snap = playGet()
    const spec = normalizeCase({
      name: raw.name || '',
      dt: raw.dt,
      playerCount: raw.playerCount || snap.playerCount || 1,
      events: raw.events || snap.history || [],
      asserts: raw.asserts || [],
    })
    return toJson(spec)
  }

  function playRunCase(rawCase, options = {}) {
    const spec = normalizeCase(rawCase)
    playStart({ ...options, playerCount: options.playerCount || spec.playerCount || 1 })
    const session = requirePlay()
    session.recording = false
    try {
      return replayCase(playAdapter(session), rawCase)
    } finally {
      session.recording = true
    }
  }

  // 轻量状态：worker 时钟每 tick 轮询用，禁止构建全量快照。
  function playStatus() {
    if (!play) return { running: false, paused: false, time: 0, frame: 0, playerCount: 1, viewPlayerIndex: 1 }
    const clock = play.runtime.clock
    return {
      running: true,
      paused: !!play.debugPaused,
      levelTimePaused: !!clock.paused,
      time: clock.time,
      frame: clock.frame,
      playerCount: play.playerCount || 1,
      viewPlayerIndex: play.viewPlayerIndex || 1,
    }
  }

  const api = {
    get,
    patch,
    setWorkspace,
    exportData,
    exportChoices,
    exportPreview,
    importData,
    pick,
    playStart,
    playSetCanvas,
    playSetView,
    playGet,
    playStatus,
    playStep,
    playRun,
    playStop,
    playKey,
    playClick,
    playPointer,
    playPause,
    playResume,
    playServerGet,
    playServerSet,
    playServerSend,
    playHistory,
    playSaveCase,
    playRunCase,
    archiveData,
    contentHash,
  }
  Object.defineProperty(api, '_project', { enumerable: false, get: currentProject })
  return api
}
