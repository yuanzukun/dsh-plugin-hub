# 客户端控件支持状态与基础滚动

上级：[Studio](../README.md#专题树)。范围是当前源码中的编辑、Lua运行时和Web/DSH/PNG试玩；“可用”不代表真机已验证。11类控件均可创建、配置公共变换、保存JSON，并按已知子集交换GIA。编辑器可创建、Lua字段可写和试玩有效是不同层次。

## 支持矩阵

| 控件 | 当前可用 | 主要缺口 |
|---|---|---|
| 容器节点 | 层级、锚点、位置/缩放/XYZ 旋转投影、显隐/激活、脚本挂载、子控件查询、动态实例与 sibling 排序；`showCursor` 参与光标回调门控。新建容器默认打开常驻光标（模拟器策略；官方字段表默认关）。GIA/JSON 导入和显式 `false` 保持原值 | 导航隔离、按键/点击穿透屏蔽字段可保存/读写，但没有完整对应行为；手柄导航不完整 |
| 文本框 | 文本、字号/颜色/背景/描边、横纵对齐、整行容纳裁切、Lua 更新；字号自适应、最小字号及统一换行；Unity 基础富文本 `b/i/size/color`，编辑预览/PNG/Pixi 共用排版 | 富文本仅支持下述子集；字体度量、整行容纳、混合字号与自适应细节为模拟器策略 |
| 图片 | 100001–100006 六类代理图元、白名单图片素材、颜色/透明度、独立宽高拉伸、XYZ 旋转投影与背面镜像；[Lua 试玩支持横向／纵向／径向进度填充](../README.md#图片填充渲染边界)；图元／素材透明轮廓遮罩、向内羽化与区域反转 | 未知素材显示缺失框；编辑画布不执行 Lua。遮罩与径向填充为模拟器显示策略，真机保真范围另列 |
| 预设按钮 | 默认、悬停、按下、不可用四态，可共用直接子控件；射线/交互开关；光标事件与按键监听 | 深色按钮本体为模拟器占位，不导出为原生皮肤；完整手柄导航与焦点外观未实现 |
| 光标检测区域 | 射线命中、进入/离开、按下/抬起/点击、拖拽生命周期、坐标/位移；祖先 `showCursor` 门控 | 单活动指针策略，未完整模拟多点触控；与真机的复杂穿透规则不完全一致 |
| 文本视窗 | 文本显示、基础富文本、字号自适应、统一分行、纵向滚轮/拖动/触摸、滚动条轨道点击和滑块拖动、边界限制、内容变更后重算、PNG/Pixi 输出 | 无惯性/回弹、无手柄滚动；交互/滚动条开关 GIA 映射未核实 |
| 网格视窗 | `RefreshItems` 模板项实例化与复用；横纵向排列、AutoWrap/Fixed；滚轮/拖拽/触摸/滚动条；裁切与命中；`scrollProgress`（含 Tween）、`ScrollToItemAt`、数量/尺寸/间隔/边距/内容长度查询 | 完整实例化，未做虚拟列表；单次最多 2000 项；惯性/回弹/手柄滚动未实现；部分 GIA 配置未映射；布局、索引等采取下述模拟器策略 |
| 模板引用控件 | 公共变换、旧文本形式引用索引保存与读回；非 UTF-8 引用配置按原始字节导入/保存/导出 | 非空原生引用的目标编码尚未确认，不会自动展开目标模板；不透明配置保留时禁止改写目标索引。显式 `game.InstantiateClientUIControl` 是另一条已支持能力 |
| 按键提示 | 键鼠/手柄枚举下拉、40×40 基础键帽、长键名与组合键横向展开；编辑画布/PNG/Pixi 共用绘制、Lua 增量更新；可选择键鼠或手柄图标预览 | 近似原生外观；完整 GIA 数字映射、实际改键/手柄型号/触屏与菜单导航图标未还原，见下节 |
| 界面动效 | 素材选择、浏览器 C/T 合成、独立实例、动效/音效/全局层级字段；`PlayAnimation` 重播、`StopAnimation` 清除；按需缓存、失败隔离 | Host PNG 省略视频帧并给出 assetWarnings；非空 GIA 配置待核实；时序/声音/原生尺寸采用[预览策略](ui-vfx-playback.md) |
| 全屏动效 | 素材选择、浏览器全屏 cover 播放、固定控件下层、动效索引/音效字段；共用缓存与故障隔离 | 同上；无专属 Play/Stop Lua API，cover 与自动开始是预览策略 |

公共能力也有保真边界：[旋转与缩放](#xy-旋转投影2026-10-12)使用三维层级合成后的平面投影，不等于完整的真机三维渲染；手柄配置存取不代表导航事件/最近邻寻路已实现。字段可写但效果未实现的情况，应以上表和对应渲染实现为准。

<a id="按键提示图标2026-11-05"></a>
## 按键提示图标

### 使用与预览策略

- 检视器的「键鼠按键／手柄按键」使用官方枚举名称，选项同时标注默认物理键。Lua 使用 `Enum.KeyboardKeyCode` / `Enum.ControllerKeyCode` 赋值，读回保持枚举身份，`None` 清除本体图像。按键提示只影响视觉，响应仍由按键监听决定。
- 鼠标左键对应 `Enum.KeyboardKeyCode.NormalAttackKey`（普通攻击），右键对应 `Enum.KeyboardKeyCode.SprintKey`（冲刺）；下拉以「鼠标左键／鼠标右键」标注。两者使用40×40透明底鼠标轮廓，对应半边按钮深色着色，编辑画布、PNG和试玩共用；左右着色为近似预览样式。
- 单键以40×40为基准，键鼠用浅色圆角键帽、深色字符；手柄用高亮方向的十字键、肩键、彩色面键及 `LB + 按键` 组合。长键名和组合键居中横向展开；高度随控件高度缩放，单键帽可随配置宽度加宽，图标不反向改写 RectTransform 或输入范围。父变换、显隐、遮罩仍作用于图像。
- 编辑器顶栏「按键图标预览」支持 `auto / keyboard / controller`，保存于当前 UI 资产的 `keyHintDevice`。`auto` 跟随画布对应设备；触屏暂隐藏。试玩默认读取服务端 UI 资产的设置；试玩页底部可覆盖选择并重开本局，Host `start/device` 也接受 `keyHintDevice`。此项只选择图标，`game.GetDevice()`、画布布局和输入事件仍跟随原设备配置。
- 未识别的数字键码、依赖导航配置的手柄菜单确认／返回，显示 `?`；不会把未知数字当枚举表顺序。触屏隐藏、尺寸扩展、字体、手柄轮廓、菜单占位均是模拟器策略，不代表全部原生素材与设备行为。

### 数据与 GIA 边界

- JSON 支持枚举名称和原始有符号32位数字，数字导入后原样保留；不从物理键名或枚举序号猜 GIA 编码。当前独立样本仅确认键鼠 `field502=24 → CraftspersonKey1`；默认 `1/1` 作为空提示预览及 `None` 的导出策略，手柄501槽完整语义仍未确认。
- 新选择优先于旧 `giaRaw`，避免画面已换键但 GIA 静默导出旧值。已知名称可导出；没有已核实数字映射的名称明确报错。需要 GIA 的其他键位可在官方编辑器配置，或保留空槽并在 Lua 启动时设置枚举。
- `key-hints.js` 维护名称、默认物理键和 wire 边界；`play/key-hint-paint.js` 共用于编辑器 Canvas、Host PNG 与 Pixi 自有纹理。同尺寸换键重绘并上传原纹理；尺寸变化、None、隐藏、销毁均释放旧自有纹理，单边栅格上限4096。

### 来源与验证

- 字段及物理键：2026-10-24 官方 API 本地快照，完整工作区 `knowledge/guide/Lua客户端UI脚本API.md` 的 `ClientUIKeyHintControl` 和两类 KeyCode 表；`documented / official_document`。GIA 单变量样本范围见 `knowledge/ui/03_客户端控件字段表.md`「按键提示」。
- 外观与约40×40基础尺寸：用户2026-11-05提供的两张键鼠/手柄原生截图和文字说明（聊天附件，原件待补；客户端版本/平台未提供），`provided_unverified / device`。当前是参考近似绘制，精确字形、缩放和扩展行为 `device_status=pending`。
- 回归：`test/key-hints.test.mjs`（键位、枚举、几何/像素、增量和资源释放）；`test/gia-observed-fields.test.mjs`（独立 wire 与清空）；`web/test/key-hints-browser.test.mjs`（实际编辑、GPU 上传及重开选择）。

<a id="预设按钮四态与占位外观2026-11-02"></a>
## 预设按钮四态与占位外观

- 四态依次是默认／悬停／按下／不可用，Authoring 字段为 `defaultChildId/hoverChildId/pressedChildId/unavailableChildId`，GIA `ButtonPresetConfig` 对应 `501/502/503/504`。不可用优先于按下、悬停，空闲回默认；点击不会留下独立的“选中态”。Lua 的 `interactable` 变化在下一次输出或命中前刷新状态。
- 每态绑定一个直接子控件，四态可以共用节点。先选出当前状态的目标，再对去重后的节点更新显隐；未被任何状态引用的装饰子控件不受四态管理。没有绑定的状态不借用其他槽。
- 本体保留模拟器占位，编辑器、PNG、Pixi 统一使用 `#202020` 深灰黑底，保留按下压暗；辅助边框、编辑标签和底色不写入 GIA，也不作为真机默认皮肤的证明。实际样式由状态子控件提供，整体色差未由此关闭。
- 旧 JSON 不自动迁移：`selectedChildId` 不再读取／写入／接受 patch，默认态需重新绑定；已有 `unavailableChildId` 保持不可用语义，导出写504槽。旧 GIA 按实际 wire 槽位读取。

依据：用户对照截图确认首尾槽显示为默认／不可用（原件待补，客户端版本和平台未知，`observed / device`，限配置显示）；2026-10-24 官方预设按钮本地快照 `mhdbkf04v6y8` §三.1 同样列默认／悬停／按下／不可用。字段映射综合判断为 `inferred`；原生运行切换及重导出仍 `device_status=pending`。同一节点填满四槽的样本不能独立证明各槽语义。

回归：`test/gia-observed-fields.test.mjs`（四个独立状态槽）；`test/layout.test.mjs`（优先级、共用、空槽、Lua 切换和销毁）；`test/pixi-cache.test.mjs`（Pixi/PNG 占位色）。

<a id="基础富文本2026-10-20"></a>
## 基础富文本

文本框和文本视窗的 `text` 自动解析以下 Unity legacy UI 富文本子集，无需开关：

| 语法 | 效果 |
|---|---|
| `<b>粗体</b>`、`<i>斜体</i>` | 可互相嵌套，也可重复嵌套同种标签；闭合后恢复外层样式 |
| `<size=12>小字</size>` | 正整数、绝对 UI 像素字号；支持带引号的参数 |
| `<color=red>红字</color>` | Unity 文档列出的 22 个颜色名（含别名）；`green=#008000`、`lime=#00ff00` |
| `<color=#FF0000>红字</color>` | 六位 RGB，不透明 |
| `<color=#FF000080>半透明红字</color>` | 八位 **RGBA**，最后两位是 Alpha；与控件内部 ARGB 数值顺序不同 |

例如：`普通 <color=red><b>红色粗体</b></color> <i>斜体</i> <size=12>小字</size>`。标签名和颜色名大小写不敏感，参数可用单/双引号包裹，等号周围不接受空格。未知标签、无效参数、未闭合及交叉闭合的未配对标签保留为字面文字；合法的内层配对仍可生效。不是 HTML 解释器，不解析实体、不创建 DOM 标签。`u`、`s`、`br`、`material`、`quad`、TMP 扩展及相对/百分比字号不在支持范围；换行使用实际换行符。

### 排版、渲染与保留策略

- `play/rich-text.js` 解析配对标签和样式栈，`play/text-layout.js` 按样式测量并输出分行/分段。有效标签不占宽度；关闭标签后恢复控件默认或外层颜色/字号。运行时、JSON 和 GIA 始终保留原始 `text`，不把解析后的文字写回存档。
- 混合字号逐行取最大字号 ×1.2 为行高，共用字母基线；文本框额外容纳余量按全文最大显示字号 ×0.25+4 计算。自适应只调整未指定 `<size>` 的基础字号，显式字号保持绝对值；到最小字号仍溢出时，文本框仅绘制能完整容纳的前缀行（见下方整行可见性），文本视窗滚动。逐字符换行、样式段之间的字偶距、混合字号基线和拟合均是模拟器策略。
- `play/rich-text-paint.js` 为编辑器 Canvas、PNG 和 Pixi 共用绘制代码，保留对齐、描边、视窗裁切、滚动及本地字体。富文本视窗按实际变高行块计算滚动长度，只栅格化可见视窗。
- Pixi 富文本每个控件持有一张自有 Canvas 纹理，同尺寸文字/样式更新原位重绘并上传；普通/富文本切换、尺寸变化与销毁释放自有纹理。单边上限4096像素，超大控件等比降低栅格分辨率，不按全文高度分配纹理。普通文本继续使用既有 Pixi Text 更新/缓存路径。

### 来源与验证

- 语法来源：[Unity 2018.4 Manual / Rich Text](https://docs.unity3d.com/2018.4/Documentation/Manual/StyledText.html)（2026-10-20 核对），属于 Unity 文档。千星本地 Lua API 未声明富文本语法契约，不能据使用 Unity 推定全部文本组件行为。
- 千星实机的语法兼容范围、混合字号/自适应、异常标签处理及精确字形仍 `device_status=pending`。
- 回归：`test/rich-text.test.mjs`（语法、颜色/Alpha、排版、Lua 增量、滚动、原文保留与纹理释放）；`web/test/rich-text-browser.test.mjs`（编辑 Canvas、WebGL、扁平回退和连续更新）。

<a id="模板引用-gia-导入2026-10-18"></a>
## 模板引用 GIA 导入

原生 `client_list.json` / `server_container.json` 只覆盖空引用槽；官方教程的第三方抓取副本（2026-09-25）未说明非空绑定的 GIA wire 编码。不能从空槽推断目标 GUID 布局，也不能把合成字节往返当原生绑定验证。

当前保留策略：

1. `Details.templateRefSlot` / `Data.empty76` 按 bytes 解码；非文本内层配置与非空外层槽以 Base64 放入 `giaRaw`，JSON 重载及 GIA 重导出保持原字节，兼容空槽与模拟器旧纯文本引用。
2. 只有已识别 UI 单元进入布局；脚本映射从主图及 `Root.accessories` 提取，其他未支持依赖返回丢失范围警告。
3. 脚本挂载按实际资产类型，在新控件树就绪后恢复。

原生非空绑定仍未解码，运行时不自动展开目标模板；不透明引用中可能嵌有资产索引，当前不会猜测重写。普通名称/布局编辑允许，改写此类目标索引明确拒绝。任意未知资产往返和原生编辑器回导未验证，`device_status=pending`。

回归：`test/gia-reference.test.mjs`，覆盖内外槽字节保留、空/旧文本槽、编辑拒绝原子性、非 UI 依赖、脚本挂载及坏 UI 报错。

<a id="pixel-link-整合包静态排查2026-10-29"></a>
### pixel-link 未解决边界

结论：**真机无法识别的根因未确认**。用户已报告恢复引用并补源码后仍失败（`provided_unverified / device / failed`），不要求重复该失败修正。输入哈希、受测源码/Web版本、对照包和候选身份统一见完整工作区 `probes/pixel-link-gia-20261029/audit.json`；最新失败包、报错及客户端版本仍缺。

- 旧包将目标索引按 UTF-8 写入77槽，但原生目标编码未知，不能认定这是根因；`bytes` 保留不证明绑定有效。外层关系和编号未发现异常，空源码是独立的运行内容缺失，也不能把混合 Root.graph、空 Info.related 或目录式 Lua 路径一概判非法。
- 清空引用槽及显式实例化候选仅用于识别问题，真机结果均未确认；它们不是已修复玩法，详情与文件身份保留在上述审计记录。

<a id="字号自适应2026-10-14"></a>
## 字号自适应

`adaptiveFontSize` / `minimumFontSize` 参与编辑预览、PNG 与 Pixi 排版，客户端 GIA 的 `TextConfig(75).adaptive(502)` 读写自适应开关。

- `play/text-layout.js` 在本地尺寸中测量并缓存分行；编辑布局、试玩 PNG/扁平 paint/Pixi 共用最终字号和显式行列表。开关、最小字号、文本、尺寸变化均重算并进入增量更新；缩放/XYZ 投影在排版之后应用。Lua `fontSize` 和保存配置保持请求值，不被实际显示字号覆盖。编辑预览将同一结果按画布缩放显示。
- **模拟器策略**：字符边界换行，左右各2 UI单位留白，行高为字号的1.2倍；文本框按下节另计块占位，自适应在 `[min(最小字号, 配置字号), 配置字号]` 中选能容纳全部行的最大正整数字号；到下限仍溢出时，文本框仅绘制完整前缀行、文本视窗继续滚动。固定字号不缩小，不加全局字号下限。文本视窗先尝试适配，无空间时为滚动条保留宽度。字体使用宿主配置或本机回退字体，官方精确换行/小数字号拟合及抗锯齿未还原；富文本与混合字号规则见上节。
- API 依据为完整知识工作区本地 `Lua客户端UI脚本API.md` 的 `adaptiveFontSize:boolean` 与 `minimumFontSize:integer`（`documented / official_document`）；拟合算法是模拟器策略，`device_status=pending`，不能由字段名或 PNG 推断真机精确算法。
- GIA必须按消息类型区分：客户端 `TextConfig(75)` 的自适应为502、描边关闭为506；旧素材组 `TextBox(19)` 的自适应才是506。旧消息的 `503=1` 含义未知，不映射为visible，不替换新版 `TextConfig.field503=12`；旧素材组的完整语义导入不在支持范围。
- 回归：`test/text-autosize.test.mjs` 覆盖独立字号期望、Lua 增量、开关/下限、尺寸/滚动、换行、投影隔离和 PNG/Pixi；`test/gia-observed-fields.test.mjs` 固定原生观察字节；`web/test/local-font.test.mjs` 验证真实字体、DOM和WebGL字号更新。测试属于 `observed / simulator`。

<a id="19-选取字号占位模型2026-10-18"></a>
<a id="文本框整行可见性22-c2026-10-20"></a>
### 文本框占位与整行可见性

采用 [PR #19](https://github.com/1475505/miliastra-beyond-simulator/pull/19) 的测量模型：PC/UI 缩放1.2，客户端版本、字体及原始卡片缺失，属于 `provided_unverified / device / pending`，不是官方跨字体契约。该模型不关闭 [#22](https://github.com/1475505/miliastra-beyond-simulator/issues/22) 原工程的其他缺字原因。

- 文本框需求高度为 `行数 × 字号 × 1.2 + 字号 × 0.25 + 4`。空文本不占高度；`contentHeight` 只计行块，`blockInset` 是容纳余量，不推断上下 padding。宽度由实际字体 `measureText` 测量，二分选择能完整容纳的最大整数字号。例如160×40两行、字号40/最小10，选择13。
- 换行和自适应后保留能完整容纳的最长前缀；等字号行数为 `min(实际行数, max(0, floor((框高 - (0.25×最终字号 + 4)) / (1.2×最终字号))))`，容许浮点误差。一行也放不下时仅绘制底色；先裁行再对齐。文本视窗不加此余量，保留连续滚动和边缘裁切，没有全局10或16像素隐藏门槛。
- `play/text-layout.js` 输出 `visibleLineCount/visibleContentHeight` 供 DOM、PNG、扁平 paint 和 Pixi 共用，保留全文布局和请求的 Lua/JSON/GIA 值；外部缩放/旋转在本地容纳判定后应用。字形着色范围受字体影响，fontSize 不是每字固定宽高。
- 富文本累计变高行块，余量取全文最大显示字号；显式 `<size>` 不随基础字号缩小。该扩展为模拟器策略，真机未确认。
- 回归沿用 `test/text-autosize.test.mjs` 与 `web/test/local-font.test.mjs`，覆盖边界、底色/描边、行块对齐、Lua 增量及 GPU 字形清除/恢复。

<a id="xy-旋转投影2026-10-12"></a>
## X/Y 旋转投影

右侧「变换」可编辑旋转 X/Y/Z，MCP/Controller `set` 支持 `rotationX`、`rotationY`、`rotationZ`，沿用四平台同步开关。JSON 保留三轴；GIA `RectTransform.field508` 的 float field 1/2/3 对应 X/Y/Z，导入导出均保留，零分量继续省略、零向量保留空 message。Lua 方法、字段与 Tween 更新共同进入同一变换链。

单轴依据是 ROTXY-20261011-v2 的 PC 真机截图和 126 条采样（完整知识工作区 `knowledge/fact.md` / `probes/image-rotation-xy-20261011/device-20261011.md`）：矩形图片 X 沿高度压缩/翻面，Y 沿宽度压缩/翻面；90° 侧立无面、120/180° 背面可见，子角标继承，GIA/方法/字段一致。实际客户端版本未提供；不将生成包的 7.1.0 当客户端版本。

父子组合依据是 2026-11-21 的 IMGGEOM PC 回传（完整知识工作区 `probes/image-transform-type/device-20261121.md`，客户端版本未知，截图原件待补）。相对 100×42 的基准矩形，父子 Y `+45°/+45°` 侧立，`+45°/−45°` 恢复为原宽；反向组父 `localScaleZ=2` 后约为 1.5 倍宽。局部布局尺寸仍是 100×42。

- **组合策略**：`ui/layout.js` 先解算未变换的锚点和尺寸，在各自轴心应用局部 XYZ 缩放与 Z-X-Y 欧拉旋转（`Ry * Rx * Rz`），保留深度合成父子后再正交投影。参考 `ugc-tool` `7bdf307` 的主动画画布；通用混合轴顺序仍是模拟器策略。保留背面镜像，不做透视、深度排序或深度平面裁切；层序不变。
- DOM 编辑器、编辑 PNG、试玩 PNG/扁平 paint、Pixi WebGL 使用同一投影策略。填充、切片仍在控件本地绘制；遮罩和视窗按自身投影裁切。选择和命中使用各自的投影矩形：侧立的面本身不命中，未裁切的布局父级不拦下转回正面的子控件。这些是模拟器规则，不是 IMGGEOM 对真机命中或裁切的验证。
- 回归：`test/rotation-xy.test.mjs` 覆盖 R0–R3 宽度、侧立／翻面、父字段／方法／Tween 的增量、轴心与选择；`web/test/image-mask-browser.test.mjs` 检查 WebGL 像素、遮罩、视窗与扁平回退；`test/gia-observed-fields.test.mjs` 验证独立 wire 字节。测试不读取外部探针文件。

<a id="命中转发祖先矩形只在视口处裁切2026-11-04"></a>
## 命中转发：祖先矩形只在视口处裁切

布局宿主（容器、按钮、网格、文本视窗、模板引用）即使指针在自己矩形外，也继续转给子节点；控件自身命中仍检查自身矩形。网格、文本视窗按视口矩形裁切内容。实现位于 `play/session.js`。

采用此策略的依据为 UGUI 逐图元矩形命中模型及 4ASCEND 用户“溢出父矩形的按钮在真机可点”回传；缺少原生坐标和对照用例，`device_status=pending`。遮罩对点击的影响、旋转父级及穿透屏蔽与几何裁切关系未独立确认。

回归：`test/layout.test.mjs` 验证零尺寸父容器下的溢出热区及区域外点击；`test/scroll.test.mjs` 验证视口裁切。

<a id="基础矩形遮罩2026-10-11"></a>
<a id="基础矩形遮罩"></a>
## 图片遮罩与羽化

MASK v1 的 PC 真机回传确认：`enableMask` 裁切图片的后代，不裁切兄弟；`imageColor` alpha=0 不取消遮罩。像素羽化从对应两边向内衰减，羽化宽度 0 仍是硬边。真机两组软边并非逐像素相同：不透明遮罩组有较亮条带，具体合成过程未确认，详见完整工作区 `knowledge/fact.md` 的 MASK v1 条目。

取形和羽化沿用 [Miliastra-image-editor-webui `103025f`](https://github.com/1475505/Miliastra-image-editor-webui/tree/103025f)；反转边界按 [`3b60f6a`](https://github.com/1475505/Miliastra-image-editor-webui/commit/3b60f6a00a24ca0991fe9014363cace658ff5d40) 对齐：

- **取形**：100001–100006 使用矩形、椭圆、三角、四角星、五角星、圆环代理。圆环内半轴为外半轴的80%，图片本体与遮罩采用同一几何；宽高分别缩放。白名单静态／Prefab 图片取素材原始 alpha，保留孔洞、半透明和留白，按 Basic／Stretch 先缩放或切片。图片着色与着色 alpha 不改变遮罩；进度填充仍只裁图片本体。
- **羽化**：矩形沿四边线性向内；其它轮廓沿启用的 X/Y 轴双向扫描到透明像素，孔洞同样算边缘，覆盖率取原 alpha 与各轴渐变的最小值。Pixel 使用 `softEdgeWidthX/Y`；Percentage 使用 `轴尺寸 × (1-clamp(range,0,100)/100)/2`，其中 range 对应 `horizontalSoftRange/verticalSoftRange`。100为硬边、0为从两边渐变到中心；非当前模式的字段仍保留，不回写保存值。旧版忽略范围字段、将像素宽度当百分比的近似已替代。
- **反转与合成**：先计算取形和羽化，只在遮罩自身的矩形内取 `1-alpha`，框外仍裁掉。这个矩形随控件变换，不是屏幕上的轴对齐包围盒。零尺寸或投影侧立的遮罩在正向、反向都不显示内容；反转实心矩形硬遮罩也不显示内容，这与关闭遮罩不同。按遮罩身份先合成整组（包括图片自身），再应用一次覆盖率；兄弟独立、嵌套逐层相乘。
- **资源与边界**：轮廓栅格最长边1536（另加透明边界）；缺失／加载中的素材取空覆盖，反向也最多显示遮罩框内。异步加载及显式刷新会重绘静态场景，迟到结果不覆盖新来源／ID；Host 的 `assetWarnings` 与图片预览继续报告加载失败。点击命中仍按原布局矩形。

证据：[图片编辑器 #1](https://github.com/1475505/Miliastra-image-editor-webui/issues/1) 报告真机开启反转后，移离矩形遮罩的圆环仍不可见（`provided_unverified / device`，版本未知）；`3b60f6a` 是其网页预览修复，不是真机实现。反转时的半透明边缘、非矩形轮廓、百分比及精确合成仍 `device_status=pending`。以下回归只验证模拟器。

- PNG 与 Pixi 的树形及扁平回退使用相同分组边界，重叠子图不会叠加同一个遮罩的覆盖率；独立兄弟遮罩即使几何相同也分别合成。
- PNG 两种方向都在与目标画布相交的遮罩包围盒内合成，像素按逆矩阵回到本地矩形采样。
- Pixi 外层保留视窗裁切，内层执行图片遮罩；两者独立更新和释放。正向矩形硬边使用 Graphics，轮廓／羽化使用自有 alpha Sprite。反向直接把框内补集写入纹理，不对整个画面取反。相同栅格尺寸复用纹理，删除时释放；不销毁共享素材纹理。
- 实现：`play/image-mask.js` 保存描述、采样与分组；`play/image-mask-raster.js` 绘制轮廓和扫描羽化；`assets/primitives.js` 共用代理几何。`session.js` 的场景指纹比较 `reverseMaskArea`、`horizontalSoftRange`、`verticalSoftRange`；Lua 单独写入其中任一字段，或 Tween 推进范围值，都能在下一次读取场景时更新试玩和试玩截图，不必同时改位置或素材。扁平回退保留遮罩素材身份。动效平面也使用同一覆盖率。
- 回归入口：`test/image-mask.test.mjs` 覆盖六种形状、孔洞、半透明、切片、羽化、嵌套、零尺寸、旋转、高 DPI 和 Lua 增量；`web/test/image-mask-browser.test.mjs` 核对 WebGL、PNG、编辑 DOM 和扁平回退，包含圆环与反向矩形完全错开的 0°／45°／90° 对照。动效组合见 `web/test/ui-vfx.test.mjs`。浏览器用例通过 `QXQY_BROWSER` 启用。

<a id="编辑画布遮罩与羽化2026-10-20"></a>
### 编辑画布遮罩与羽化

`ui/inspector.js` 为编辑盒附加祖先遮罩链与层级可见性，复用试玩的 `imageMaskSpec/groupMaskedPaint`；透明图片的遮罩、子孙裁切、嵌套、零尺寸和投影随布局一起更新。

- `editor-ui/mask-preview.js` 将同一遮罩下的 DOM 内容分组合成，再应用一次 alpha 遮罩；轮廓、羽化和框内反转共用 `paintMaskCanvas`，局部栅格单边上限2048。遮罩用完整仿射矩阵映射到画布；修改属性、变换或刷新素材会直接更新。
- 编辑器PNG复用试玩的裁剪包围盒分组合成。DOM选框/控制点与PNG选框最后单独绘制，不参与羽化，不因选中控件而把其图像提升层序。隐藏祖先或左树关闭画布可见性时，其后代不显示；遮罩范围外仍可通过控件树选取，编辑点击继续按布局矩形判断。
- 回归沿用上述遮罩用例及 `fixtures/image-mask.mjs`，覆盖祖先链、选框、检视器提交和树可见性。边界沿用试玩策略；编辑预览不执行 Lua。

<a id="基础滚动2026-10-02"></a>
## 基础滚动

### 使用

- **文本视窗**：在检视器填写超过视窗高度的文本，开启“允许滚动交互”，进入试玩后直接滚轮或拖动。隐藏滚动条仍可滚动。文本变短、字号或尺寸变化会重新测量并限制偏移。
- **网格视窗**：配置“列表项模板索引”、尺寸/间距/排列，在运行脚本中调用 `RefreshItems(itemCount, callback)`。编辑器“预览数量”不自动生成运行条目。只有 `RefreshItems` 管理的模板项随列表移动和裁切；静态子控件保持原位。
- **试玩滚轮**：鼠标停在纵向视窗或其列表按钮上，向上拨显示后面的行／项，向下拨显示前面的行／项。选在列表中段对照，可避开首尾限位。
- **工具/回放**：使用 `pointer` 的 `type: "wheel"`，传 `x/y/deltaX/deltaY`。例如 `{"type":"wheel","x":600,"y":450,"deltaY":48}`。这里是转换后的画布增量：正 `deltaY` 往后滚动。浏览器只在输入时反转 DOM `deltaY`；已有录制按原值回放。横向列表优先使用 `deltaX`，没有横向量时使用 `deltaY`。`type: "cancel"` 结束当前指针事务，不产生点击。
- 编辑视图保持静态布局；滚动在试玩生效。运行偏移保存在各玩家的运行时控件上，停止/重开复位，不写回 Authoring JSON。

### 明确采用的模拟器策略

以下是模拟器可用性策略，不宣称为官方行为：

1. 单活动鼠标/触点，无惯性、弹性或手柄滚动；`interactable=false` 禁止原生滚动；网格还检查 `raycastTarget`。滚动命中遵循当前显示树，遮挡在上的可交互控件不会把滚轮传给无亲缘关系的下层视窗。嵌套视窗取命中链中最近的可滚动祖先，不做到边缘后继续传递。
2. 滚动条为简单 8px 轨道、最短 18px 滑块；点击轨道把滑块中心定位到指针，拖动按轨道有效行程换算。浏览器像素/行/页滚轮单位转为画布单位，行按 16 CSS px、页按一视口。内容拖动按控件本地变换换算。
3. 文本在宿主端用本机字体测量、按字符换行，行高 `fontSize × 1.2`；溢出时从顶部开始滚动，内容不溢出时遵循垂直对齐。PNG/Pixi 使用同一份分行和偏移；Pixi 只绘制可见行附近的文字，避免长文本生成超大纹理。字体栅格仍可能不同。
4. 网格项索引 **0 起始**，非本列表项返回 `-1`；`scrollProgress` 限制在 `[0,1]`，0 为顶部/左侧，1 为底部/右侧。`ScrollToItemAt` 的 Top/Center/Bottom 在横向对应左/中/右。
5. 纵向按行填充，横向按列填充；AutoWrap 根据交叉轴空间计算项数；Fixed 使用 `layoutConstraintFixedCount`，最小 1。`padding1X/Y` 暂解释为左/上，`padding2X/Y` 为右/下；cell 最小 1，间距/边距最小 0。这一边距映射尚无真机证据。
6. `RefreshItems` 同步为全部项调用 `(control,index)` 回调，同模板项按索引复用，减少数量时销毁尾项，更换模板后重建；新项激活，模板脚本沿用已有实例化生命周期。没有可见区虚拟化，最多 2000 项；递归刷新同一网格、无效数量/模板明确报错。同步回调完成后释放自身引用。
7. 滚动过程中不额外触发列表项 Click；拖动由内建滚动消费，不同时派发列表项 Drag。滑块盖在列表项之上，输入和显示使用同一视窗裁切。

### API 依据与证据

- API依据：历史本地 `Lua客户端UI脚本API.md` 快照SHA256 `4A43F93F2B322BE8336FF33D9CB07B3BC3A8D4C8A931A45D18F90E4E64941BAB` 声明视窗 `interactable/showScrollBar`、网格字段及七个方法和滚动枚举（`documented / official_document`）；范围、索引起点与间距方向按上述模拟器策略处理。
- 自动回归：`test/scroll.test.mjs` 使用独立几何预期覆盖命中、布局、Lua 回调/复用/定位/Tween/释放、PNG/Pixi 裁切及回放；`test/browser-session.test.mjs` 覆盖滚轮单位、多指过滤及取消；`test/gia-loss-warnings.test.mjs` 覆盖 JSON 保留与 GIA 损失提示。
- 浏览器回归：`web/test/scroll-browser.test.mjs`，覆盖滚轮、拖拽、滚动条、触摸、Worker 输入与 GPU 裁切。
- 滚轮上下方向依据用户对旧版“模拟器和真机相反”的反馈调整（`provided_unverified / device / pending`，原件待补）；浏览器用例核对按钮列表和文本视窗在两个方向的响应。真机的系统滚动设置、每格距离未核实。
- GIA：视窗交互/滚动条、列表模板、方向/排列字段仅保证JSON/Lua，未核实wire映射不猜写，导出时明确提示；已知尺寸/间距及文本字段沿用原编解码。

### 实现入口

| 路径 | 职责 |
|---|---|
| `client/lua-runtime/src/grid.js`、`scene.js`、`runtime.js` | 网格 API、条目生命周期、布局/进度与 Lua 参数桥接 |
| `studio/play/scroll.js`、`scroll-geometry.js` | 文本测量、滚动条和裁切几何 |
| `studio/play/session.js` | 输入仲裁、运行偏移、scene/paint、命中 |
| `studio/play/browser-session.js` | 滚轮/指针/取消与 CSS→画布坐标 |
| `studio/play/pixi-renderer.js`、`studio/host-png.js` | 内容偏移、滚动条和视窗裁切 |
| `studio/host/worker.js`、`studio/autotest/` | 输入透传、录制与确定性回放 |

## 验证与加载

本页回归验证模拟器行为，不能扩大各节真机证据范围。既有浏览器观察主要为 Windows / Node22 / Pixi8.20 / Edge + SwiftShader（`observed / simulator`）；浏览器用例需配置 `QXQY_BROWSER`，未配置时跳过。源码更新后运行 `pnpm build`，重启实际加载代码的 Web/MCP/Harness 宿主并刷新页面；只构建不会替运行中的进程重载模块。
