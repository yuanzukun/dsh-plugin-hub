import { test } from 'node:test'
import assert from 'node:assert/strict'
import { basename, join } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import {
  applyInspectorToTransform,
  canvasBox,
  classifyAnchor,
  computeRect,
  createRectTransform,
  inspectorFromRect,
  setAnchorPreset,
} from '../ui/layout.js'
import { readCurrentTransform, syncPlatformTransforms } from '../ui/sync.js'
import { createNode, walk } from '../ui/authoring.js'
import { hitTest, layoutTree } from '../ui/inspector.js'
import { createProject } from '../ui/project.js'
import { assignGuids } from '../gia/codec.js'
import { compileProject } from '../play/compile.js'
import { hitPlayControl, injectPlayPointer, paintList, runtimeLayout, runtimeTransforms } from '../play/session.js'
import { createStudio, inspectGia, validateGiaCompatibility, validateServerGiaCompatibility } from '../index.js'
import { createRuntime } from '../../client/lua-runtime/src/index.js'
import { assertNoUndefined } from '../json.js'
import { CANVAS_PRESETS, PLATFORMS } from '../constants.js'

test('fullscreen stretch @1600×900 shows center 800,450 size 1600×900', () => {
  const parent = canvasBox('pc-16-9')
  const rt = createRectTransform({ layout: 'stretch' })
  const box = computeRect(parent, rt)
  const vis = inspectorFromRect(box)
  assert.equal(vis.posX, 800)
  assert.equal(vis.posY, 450)
  assert.equal(vis.width, 1600)
  assert.equal(vis.height, 900)
  assert.equal(classifyAnchor(rt), 'stretch')
  assert.equal(rt.offset.x, 0)
  assert.equal(rt.size.x, 0)
})

test('center 100×40 at default offset sits on canvas center', () => {
  const parent = canvasBox('pc-16-9')
  const rt = createRectTransform({ layout: 'center', size: [100, 40] })
  const vis = inspectorFromRect(computeRect(parent, rt))
  assert.equal(vis.posX, 800)
  assert.equal(vis.posY, 450)
  assert.equal(vis.width, 100)
  assert.equal(vis.height, 40)
  assert.equal(classifyAnchor(rt), 'center')
})

test('authoring preview and selection inherit parent scale while retaining local RectTransform values', () => {
  const root = createNode('container', { id: 'scale-root', isRootContainer: true })
  const child = createNode('image', { id: 'scale-child' })
  root.children.push(child)
  const rootTransform = root.transformByPlatform.KEYBOARD
  rootTransform.scale = { x: 2, y: 0.5, z: 1 }
  const childTransform = child.transformByPlatform.KEYBOARD
  childTransform.offset = { x: 100, y: 50 }
  childTransform.size = { x: 100, y: 100 }

  const { boxes } = layoutTree(root, 'pc-16-9')
  const childBox = boxes['scale-child']
  assert.equal(childBox.left, 850)
  assert.equal(childBox.bottom, 450)
  assert.equal(childBox.width, 100)
  assert.equal(childBox.height, 100)
  assert.equal(childBox.renderLeft, 900)
  assert.equal(childBox.renderBottom, 450)
  assert.equal(childBox.renderWidth, 200)
  assert.equal(childBox.renderHeight, 50)
  assert.equal(hitTest([childBox], 1090, 475), 'scale-child')
  assert.equal(hitTest([childBox], 1110, 475), null)
})

test('sync preserves fluid stretch axes across device canvases', () => {
  const source = createRectTransform({ layout: 'stretch' })
  const maps = syncPlatformTransforms({
    transformByPlatform: createNode('image').transformByPlatform,
    source,
    canvasId: 'pc-16-9',
    syncAllDevices: true,
  })
  const mobile = computeRect(canvasBox('mobile-16-9'), maps.TOUCHSCREEN)
  assert.equal(mobile.width, 1280)
  assert.equal(mobile.height, 720)
  assert.equal(maps.TOUCHSCREEN.size.x, 0)
  assert.equal(maps.TOUCHSCREEN.size.y, 0)
})

test('one unchanged top-left RectTransform preserves its pixel inset', () => {
  const p16 = canvasBox('pc-16-9')
  let rt = setAnchorPreset(createRectTransform({ layout: 'center', size: [200, 40] }), 'top-left')
  rt = applyInspectorToTransform(p16, rt, { posX: 120, posY: 860, width: 200, height: 40 })
  const vis16 = inspectorFromRect(computeRect(p16, rt))
  assert.ok(Math.abs(vis16.posX - 120) < 1e-4)
  assert.ok(Math.abs(vis16.posY - 860) < 1e-4)
  const p21 = canvasBox('pc-21-9')
  const vis21 = inspectorFromRect(computeRect(p21, rt))
  assert.ok(Math.abs(vis21.posX - 120) < 1e-4, `x ${vis21.posX}`)
  assert.ok(Math.abs(vis21.posY - 860) < 1e-4, `y ${vis21.posY}`)
})

test('sync projects between platforms while same-platform viewports share the pixel inset', () => {
  const sourceParent = canvasBox('pc-16-9')
  let source = setAnchorPreset(createRectTransform({ layout: 'center', size: [200, 40] }), 'top-left')
  source = applyInspectorToTransform(sourceParent, source, { posX: 120, posY: 860, width: 200, height: 40 })
  const maps = syncPlatformTransforms({
    transformByPlatform: createNode('image').transformByPlatform,
    source,
    canvasId: 'pc-16-9',
    syncAllDevices: true,
  })
  const wide = inspectorFromRect(computeRect(canvasBox('pc-21-9'), maps.KEYBOARD))
  const mobile = inspectorFromRect(computeRect(canvasBox('mobile-16-9'), maps.TOUCHSCREEN))
  assert.equal(classifyAnchor(maps.KEYBOARD), 'top-left')
  assert.equal(wide.posX, 120)
  assert.equal(wide.posY, 860)
  assert.equal(mobile.posX, 96)
  assert.equal(mobile.posY, 688)
})

test('sync on projects position to canonical platform canvas ratios', () => {
  const source = createRectTransform({ layout: 'center', size: [80, 80], offset: [10, 20] })
  const map = syncPlatformTransforms({
    transformByPlatform: createNode('image').transformByPlatform,
    source,
    canvasId: 'pc-16-9',
    syncAllDevices: true,
  })
  assert.deepEqual(map.KEYBOARD.offset, { x: 10, y: 20 })
  assert.ok(Math.abs(map.CONTROLLER_CONSOLE.offset.x - 10) < 1e-4)
  assert.ok(Math.abs(map.CONTROLLER_CONSOLE.offset.y - 20) < 1e-4)
  assert.deepEqual(map.TOUCHSCREEN.offset, { x: 8, y: 16 })
  assert.deepEqual(map.CONTROLLER_MOBILE.offset, { x: 8, y: 16 })
  for (const p of PLATFORMS) assert.deepEqual(map[p].size, { x: 80, y: 80 })
})

test('sync off writes only the current platform slot', () => {
  const initial = syncPlatformTransforms({
    transformByPlatform: createNode('image').transformByPlatform,
    source: createRectTransform({ layout: 'center', size: [80, 80], offset: [0, 0] }),
    canvasId: 'pc-16-9',
    syncAllDevices: true,
  })
  const next = syncPlatformTransforms({
    transformByPlatform: initial,
    source: createRectTransform({ layout: 'center', size: [80, 80], offset: [40, 5] }),
    canvasId: 'pc-16-9',
    syncAllDevices: false,
  })
  assert.deepEqual(next.KEYBOARD.offset, { x: 40, y: 5 })
  assert.deepEqual(next.TOUCHSCREEN.offset, { x: 0, y: 0 })
  assert.deepEqual(next.CONTROLLER_CONSOLE.offset, { x: 0, y: 0 })
})

test('inspector pos/size invert then forward within 1e-4', () => {
  const parent = canvasBox('mobile-19.5-9')
  let rt = setAnchorPreset(createRectTransform({ size: [80, 80] }), 'bottom-right')
  const want = { posX: 1400, posY: 80, width: 90, height: 70 }
  rt = applyInspectorToTransform(parent, rt, want)
  const got = inspectorFromRect(computeRect(parent, rt))
  assert.ok(Math.abs(got.posX - want.posX) < 1e-4)
  assert.ok(Math.abs(got.posY - want.posY) < 1e-4)
  assert.ok(Math.abs(got.width - want.width) < 1e-4)
  assert.ok(Math.abs(got.height - want.height) < 1e-4)
})

test('studio.get is lossless JSON: no undefined; container has no text', () => {
  const studio = createStudio()
  const snap = studio.get()
  assertNoUndefined(snap)
  const raw = JSON.stringify(snap)
  assert.equal(raw.includes('undefined'), false)
  const container = snap.root.children[0]
  assert.equal(container.kind, 'container')
  assert.equal(Object.hasOwn(container, 'text'), false)
  assert.equal(typeof container.isolateNavigation, 'boolean')
  const text = container.children.find((c) => c.kind === 'textbox')
  assert.equal(typeof text.text, 'string')
  assert.equal(text.minimumFontSize, 20)
  const button = container.children.find((c) => c.kind === 'button')
  assert.equal(button.clickAudioId, 50888)
})

test('textbox / image / button fields round-trip via patch', () => {
  const studio = createStudio()
  studio.patch({ op: 'select', id: 'n2' })
  studio.patch({ op: 'set', key: 'text', value: 'HELLO' })
  studio.patch({ op: 'set', key: 'fontSize', value: 32 })
  studio.patch({ op: 'set', key: 'adaptiveFontSize', value: true })
  studio.patch({ op: 'set', key: 'fontColor', value: '#FF0000' })
  studio.patch({ op: 'select', id: 'n3' })
  studio.patch({ op: 'set', key: 'imageId', value: 100005 })
  studio.patch({ op: 'set', key: 'enableMask', value: true })
  studio.patch({ op: 'select', id: 'n4' })
  studio.patch({ op: 'set', key: 'interactable', value: false })
  const snap = studio.get()
  const text = snap.root.children[0].children.find((c) => c.id === 'n2')
  assert.equal(text.text, 'HELLO')
  assert.equal(text.fontSize, 32)
  assert.equal(text.adaptiveFontSize, true)
  assert.equal(text.fontColor, 0xffff0000)
  const image = snap.root.children[0].children.find((c) => c.id === 'n3')
  assert.equal(image.imageId, 100005)
  assert.equal(image.enableMask, true)
  const button = snap.root.children[0].children.find((c) => c.id === 'n4')
  assert.equal(button.interactable, false)
})

test('compile GetUICanvasSize matches preset; instantiate stays out of authoring', () => {
  const studio = createStudio()
  studio.patch({ op: 'setCanvas', canvasId: 'mobile-4-3' })
  const compiled = compileProject(studio._project)
  assert.equal(compiled.canvasWidth, 1280)
  assert.equal(compiled.canvasHeight, 960)
  const rt = createRuntime({ canvasWidth: compiled.canvasWidth, canvasHeight: compiled.canvasHeight })
  const root = rt.addRoot(compiled.root)
  rt.registerTemplate(99, { kind: 'textbox', name: 'Dyn', text: 'x' })
  rt.mountScript({
    path: 't',
    control: root,
    source: `
function OnStart()
  local c = game.InstantiateClientUIControl(99, script.object)
  print("dyn", c.name)
end
`,
  })
  assert.match(rt.logs.map((l) => l.text).join('\n'), /dyn\tDyn/)
  assert.equal(studio.get().root.children[0].children.some((c) => c.name === 'Dyn'), false)
  const [w, h] = [rt.canvasWidth, rt.canvasHeight]
  assert.equal(w, 1280)
  assert.equal(h, 960)
})

test('play with pasted lua source logs print', () => {
  const studio = createStudio()
  studio.patch({
    op: 'addScript',
    controlId: 'n1',
    source: `
function OnStart()
  local w, h = game.GetUICanvasSize()
  print("canvas", w, h)
end
`,
    path: 'inline',
  })
  const snap = studio.playStart()
  assert.equal(snap.canvasWidth, 1600)
  assert.equal(snap.canvasHeight, 900)
  assert.match(snap.logs.map((l) => l.text).join('\n'), /canvas\t1600\t900/)
  studio.playStop()
})

test('changing pos syncs between platform parent rectangles', () => {
  const studio = createStudio()
  studio.patch({ op: 'select', id: 'n2' })
  studio.patch({ op: 'set', key: 'posX', value: 200 })
  studio.patch({ op: 'set', key: 'posY', value: 100 })
  const node = studio._project.root.children[0].children.find((c) => c.id === 'n2')
  const kb = readCurrentTransform(node.transformByPlatform, 'pc-16-9')
  const touch = readCurrentTransform(node.transformByPlatform, 'mobile-16-9')
  const pcRect = inspectorFromRect(computeRect(canvasBox('pc-16-9'), kb))
  const mobileRect = inspectorFromRect(computeRect(canvasBox('mobile-16-9'), touch))
  assert.equal(pcRect.posX, 200)
  assert.equal(pcRect.posY, 100)
  assert.equal(mobileRect.posX, 160)
  assert.equal(mobileRect.posY, 80)
  assert.equal(mobileRect.width, pcRect.width)
  assert.equal(mobileRect.height, pcRect.height)
})

test('rotation Z follows transform ordering, syncs to every canvas, and compiles into play', () => {
  const studio = createStudio()
  studio.patch({ op: 'select', id: 'n2' })
  studio.patch({ op: 'set', key: 'rotationZ', value: 30 })
  const snap = studio.get()
  const keys = snap.inspector.fields.map((field) => field.key)
  assert.ok(keys.indexOf('width') < keys.indexOf('rotationZ'))
  assert.ok(keys.indexOf('rotationZ') < keys.indexOf('anchorType'))
  assert.equal(snap.boxes.find((box) => box.id === 'n2').rotationZ, 30)
  const node = studio._project.root.children[0].children.find((control) => control.id === 'n2')
  for (const canvasId of Object.keys(CANVAS_PRESETS)) {
    assert.equal(readCurrentTransform(node.transformByPlatform, canvasId).rotation.z, 30, canvasId)
  }
  const compiled = compileProject(studio._project)
  assert.equal(compiled.root.children.find((control) => control.authoringId === 'n2').localRotationZ, 30)
  const play = studio.playStart({ inspect: true })
  assert.equal(play.tree[0].children.find((control) => control.authoringId === 'n2').localRotationZ, 30)
  studio.playStop()
})

test('add allocates unique ids and every successful patch increments revision', () => {
  const studio = createStudio()
  const v1 = studio.get().version
  const added = studio.patch({ op: 'add', kind: 'textbox', parentId: 'n1', expectedRevision: v1 })
  assert.equal(added.version, v1 + 1)
  const ids = added.tree.map((row) => row.id)
  assert.equal(new Set(ids).size, ids.length)
  assert.equal(added.selectedId, 'n12')
  assert.throws(
    () => studio.patch({ op: 'set', key: 'text', value: 'stale', expectedRevision: v1 }),
    /revision conflict/,
  )
})

test('invalid numeric fields are rejected instead of becoming null', () => {
  const studio = createStudio()
  const before = studio.get()
  assert.throws(() => studio.patch({ op: 'set', key: 'posX', value: 'abc' }), /finite number/)
  const after = studio.get()
  assert.equal(after.version, before.version)
  assert.equal(after.inspector.fields.find((f) => f.key === 'posX').value, 500)
})

test('play inherits a parent localScale for child paint and pointer hit testing without mutating child localScale', () => {
  const runtime = createRuntime({ canvasWidth: 1600, canvasHeight: 900 })
  const root = runtime.addRoot({
    active: true,
    kind: 'container',
    name: 'ScaleRoot',
    anchorMinX: 0,
    anchorMinY: 0,
    anchorMaxX: 1,
    anchorMaxY: 1,
    pivotX: 0.5,
    pivotY: 0.5,
    localScaleX: 2,
    localScaleY: 0.5,
    children: [
      {
        kind: 'image',
        name: 'Visual',
        active: true,
        anchorMinX: 0.5,
        anchorMinY: 0.5,
        anchorMaxX: 0.5,
        anchorMaxY: 0.5,
        anchoredPositionX: 100,
        anchoredPositionY: 50,
        sizeDeltaX: 100,
        sizeDeltaY: 100,
        pivotX: 0.5,
        pivotY: 0.5,
        imageId: 100001,
      },
      {
        kind: 'cursor',
        name: 'Hit',
        active: true,
        anchorMinX: 0.5,
        anchorMinY: 0.5,
        anchorMaxX: 0.5,
        anchorMaxY: 0.5,
        anchoredPositionX: 100,
        anchoredPositionY: 50,
        sizeDeltaX: 100,
        sizeDeltaY: 100,
        pivotX: 0.5,
        pivotY: 0.5,
      },
    ],
  })
  const session = { runtime }
  const visual = root.children[0]
  const hit = root.children[1]
  const boxes = runtimeLayout(session)
  const transforms = runtimeTransforms(session, boxes)
  const paint = paintList(session, boxes).find((item) => item.id === visual.Id)

  // RectTransform layout values stay local; inherited scale exists only in
  // the final world transform, matching the device observation.
  assert.equal(visual.localScaleX, 1)
  assert.equal(visual.localScaleY, 1)
  assert.equal(boxes.get(visual.Id).width, 100)
  assert.equal(boxes.get(visual.Id).height, 100)
  assert.equal(transforms.get(visual.Id).a, 2)
  assert.equal(transforms.get(visual.Id).d, 0.5)
  assert.equal(paint.width, 200)
  assert.equal(paint.height, 50)
  assert.equal(paint.left, 900)
  assert.equal(paint.bottom, 450)

  // (1090, 475) is inside only the scaled child rectangle. It would miss the
  // old unscaled box whose right edge is 950.
  assert.equal(hitPlayControl(session, 1090, 475), hit)
  assert.equal(hitPlayControl(session, 1110, 475), null)
})

test('a zero-size anchor container forwards the pointer to a cursor child that overflows it', () => {
  const runtime = createRuntime({ canvasWidth: 1280, canvasHeight: 720 })
  const root = runtime.addRoot({
    active: true,
    kind: 'container',
    name: 'Menu',
    anchorMinX: 0,
    anchorMinY: 0,
    anchorMaxX: 1,
    anchorMaxY: 1,
    sizeDeltaX: 0,
    sizeDeltaY: 0,
    pivotX: 0.5,
    pivotY: 0.5,
    showCursor: true,
    children: [
      {
        kind: 'container',
        name: 'ExitLayer',
        active: true,
        anchorMinX: 0,
        anchorMinY: 1,
        anchorMaxX: 0,
        anchorMaxY: 1,
        sizeDeltaX: 0,
        sizeDeltaY: 0,
        pivotX: 0.5,
        pivotY: 0.5,
        children: [
          {
            kind: 'cursor',
            name: 'ExitHit',
            active: true,
            anchorMinX: 0,
            anchorMinY: 1,
            anchorMaxX: 0,
            anchorMaxY: 1,
            anchoredPositionX: 39,
            anchoredPositionY: -30.5,
            sizeDeltaX: 52,
            sizeDeltaY: 39,
            pivotX: 0.5,
            pivotY: 0.5,
            raycastTarget: true,
          },
        ],
      },
    ],
  })
  const session = { runtime }
  const exitLayer = root.children[0]
  const hot = exitLayer.children[0]
  // The anchor container is a single point in the top-left corner; the visible
  // button and its hot zone overflow it, the way the menu's 退出 button does.
  assert.equal(exitLayer.sizeDeltaX, 0)
  assert.equal(hitPlayControl(session, 39, 690), hot)
  assert.equal(hitPlayControl(session, 200, 690), null, 'a point away from the hot zone still hits nothing')
  let clicks = 0
  hot.AddCursorEventListener('CursorClick', () => { clicks += 1 })
  injectPlayPointer(session, 'click', 39, 690, { silent: true })
  assert.equal(clicks, 1)
  runtime.destroy()
})

test('later play roots cover earlier roots for pointer hits', () => {
  const runtime = createRuntime({ canvasWidth: 1600, canvasHeight: 900 })
  const back = runtime.addRoot({
    active: true,
    kind: 'cursor',
    name: 'BackRoot',
    anchorMinX: 0,
    anchorMinY: 0,
    anchorMaxX: 1,
    anchorMaxY: 1,
    sizeDeltaX: 0,
    sizeDeltaY: 0,
    pivotX: 0.5,
    pivotY: 0.5,
  })
  const front = runtime.addRoot({
    active: true,
    kind: 'cursor',
    name: 'FrontRoot',
    anchorMinX: 0,
    anchorMinY: 0,
    anchorMaxX: 1,
    anchorMaxY: 1,
    sizeDeltaX: 0,
    sizeDeltaY: 0,
    pivotX: 0.5,
    pivotY: 0.5,
  })
  const session = { runtime }
  assert.equal(hitPlayControl(session, 800, 450), front)
  assert.notEqual(hitPlayControl(session, 800, 450), back)
})

test('play pointer hits earlier siblings before a later full-screen tap area', () => {
  const studio = createStudio()
  studio.patch({ op: 'set', id: 'n3', key: 'anchorType', value: 'stretch' })
  studio.patch({ op: 'set', id: 'n3', key: 'posX', value: 800 })
  studio.patch({ op: 'set', id: 'n3', key: 'posY', value: 450 })
  studio.patch({ op: 'set', id: 'n3', key: 'width', value: 1600 })
  studio.patch({ op: 'set', id: 'n3', key: 'height', value: 900 })
  const front = studio.patch({ op: 'add', kind: 'cursor', parentId: 'n1', name: 'FrontTap' })
  studio.patch({ op: 'set', id: front.selectedId, key: 'anchorType', value: 'stretch' })
  studio.patch({ op: 'set', id: front.selectedId, key: 'posX', value: 800 })
  studio.patch({ op: 'set', id: front.selectedId, key: 'posY', value: 450 })
  studio.patch({ op: 'set', id: front.selectedId, key: 'width', value: 1600 })
  studio.patch({ op: 'set', id: front.selectedId, key: 'height', value: 900 })
  studio.patch({
    op: 'addScript',
    controlId: 'n1',
    path: 'inline',
    source: `
function OnStart()
  script.object.showCursor = true
  local back = script.object:FindChild("光标检测区域")
  back:AddCursorEventListener(Enum.CursorEventType.CursorClick, function()
    print("tap-back")
  end)
  local front = script.object:FindChild("FrontTap")
  front:AddCursorEventListener(Enum.CursorEventType.CursorClick, function()
    print("tap-front")
  end)
end
`,
  })
  studio.playStart()
  const after = studio.playPointer('click', 80, 80)
  const logs = after.logs.map((entry) => entry.text).join('\n')
  assert.match(logs, /tap-back/)
  assert.doesNotMatch(logs, /tap-front/)
  studio.playStop()
})

test('play pointer does not reach a cursor nested under an image', () => {
  const studio = createStudio()
  const panel = studio.patch({ op: 'add', kind: 'image', parentId: 'n1', name: 'Panel' })
  studio.patch({ op: 'set', id: panel.selectedId, key: 'width', value: 400 })
  studio.patch({ op: 'set', id: panel.selectedId, key: 'height', value: 300 })
  studio.patch({ op: 'add', kind: 'cursor', parentId: panel.selectedId, name: 'NestedHit' })
  studio.patch({
    op: 'addScript',
    controlId: 'n1',
    path: 'inline',
    source: `
function OnStart()
  script.object.showCursor = true
  local hit = script.object:FindChild("NestedHit")
  hit:AddCursorEventListener(Enum.CursorEventType.CursorClick, function()
    print("nested-hit")
  end)
end
`,
  })
  studio.playStart()
  const after = studio.playPointer('click', 800, 450)
  assert.doesNotMatch(after.logs.map((entry) => entry.text).join('\n'), /nested-hit/)
  studio.playStop()
})

test('image and pressed-button fields survive compile and pointer play', () => {
  const studio = createStudio()
  studio.patch({ op: 'select', id: 'n9' })
  studio.patch({ op: 'set', key: 'enableMask', value: true })
  studio.patch({ op: 'set', key: 'enableSoftEdge', value: true })
  studio.patch({ op: 'set', key: 'enableFill', value: true })
  studio.patch({ op: 'set', key: 'reverseMaskArea', value: true })
  studio.patch({ op: 'set', key: 'visible', value: false })
  studio.patch({ op: 'select', id: 'n6' })
  const pressed = studio.patch({ op: 'add', kind: 'image', parentId: 'n6', name: '按下态' })
  studio.patch({ op: 'set', id: 'n6', key: 'pressedChildId', value: pressed.selectedId })
  studio.patch({
    op: 'addScript',
    controlId: 'n1',
    path: 'inline',
    source: `
function OnStart()
  script.object.showCursor = true
  local button = script.object:FindChild("预设按钮")
  button:AddCursorEventListener(Enum.CursorEventType.CursorClick, function()
    print("button-clicked")
  end)
end
`,
  })
  const compiled = compileProject(studio._project)
  const image = compiled.root.children.find((node) => node.authoringId === 'n9')
  const button = compiled.root.children.find((node) => node.authoringId === 'n6')
  assert.equal(image.enableMask, true)
  assert.equal(image.enableSoftEdge, true)
  assert.equal(image.enableFill, true)
  assert.equal(image.reverseMaskArea, true)
  assert.equal(image.fillAmount, 1)
  assert.equal(button.pressedChildId, pressed.selectedId)
  studio.playStart()
  studio.playPointer('down', 800, 450)
  const down = studio.playGet({ inspect: true })
  const downButton = down.tree[0].children.find((node) => node.authoringId === 'n6')
  assert.equal(downButton.pressed, true)
  assert.equal(downButton.children.find((node) => node.authoringId === pressed.selectedId).visible, true)
  studio.playPointer('up', 800, 450)
  const up = studio.playGet({ inspect: true })
  const upButton = up.tree[0].children.find((node) => node.authoringId === 'n6')
  assert.equal(upButton.pressed, false)
  assert.equal(upButton.children.find((node) => node.authoringId === pressed.selectedId).visible, false)
  assert.match(up.logs.map((entry) => entry.text).join('\n'), /button-clicked/)
  studio.playStop()
})

test('preset button resolves default, hover, pressed and unavailable child states', () => {
  const studio = createStudio()
  const stateIds = {}
  for (const [key, name] of [
    ['defaultChildId', '默认态'],
    ['hoverChildId', '悬停态'],
    ['pressedChildId', '按下态'],
    ['unavailableChildId', '不可用态'],
  ]) {
    const added = studio.patch({ op: 'add', kind: 'image', parentId: 'n6', name })
    stateIds[key] = added.selectedId
    studio.patch({ op: 'set', id: 'n6', key, value: added.selectedId })
  }
  const visibleState = () => {
    const snapshot = studio.playGet({ inspect: true })
    const button = snapshot.tree[0].children.find((node) => node.authoringId === 'n6')
    return button.children.filter((child) => child.visible).map((child) => child.authoringId)
  }
  studio.playStart()
  assert.deepEqual(visibleState(), [stateIds.defaultChildId])
  studio.playPointer('move', 800, 450)
  assert.deepEqual(visibleState(), [stateIds.hoverChildId])
  studio.playPointer('down', 800, 450)
  assert.deepEqual(visibleState(), [stateIds.pressedChildId])
  studio.playPointer('up', 800, 450)
  assert.deepEqual(visibleState(), [stateIds.hoverChildId])
  studio.playPointer('move', 10, 10)
  assert.deepEqual(visibleState(), [stateIds.defaultChildId])
  studio.playStop()
  studio.patch({ op: 'set', id: 'n6', key: 'interactable', value: false })
  studio.playStart()
  assert.deepEqual(visibleState(), [stateIds.unavailableChildId])
  studio.playStop()
  studio.patch({ op: 'set', id: 'n6', key: 'interactable', value: true })
  studio.patch({ op: 'set', id: 'n6', key: 'defaultChildId', value: null })
  studio.patch({ op: 'remove', id: stateIds.defaultChildId })
  studio.playStart()
  assert.deepEqual(visibleState(), [], 'an unconfigured default slot does not display another state')
  studio.playStop()
})

test('preset button can share a node across any or all states without later slots hiding it', () => {
  const studio = createStudio()
  const keys = ['defaultChildId', 'hoverChildId', 'pressedChildId', 'unavailableChildId']
  const shared = studio.patch({ op: 'add', kind: 'image', parentId: 'n6', name: 'shared' }).selectedId
  const other = studio.patch({ op: 'add', kind: 'image', parentId: 'n6', name: 'other' }).selectedId
  const decoration = studio.patch({ op: 'add', kind: 'image', parentId: 'n6', name: 'decoration' }).selectedId
  // Check all pairings, including non-adjacent slots and all four sharing a node.
  for (const mask of [3, 5, 6, 9, 10, 12, 15]) {
    for (const [i, key] of keys.entries()) studio.patch({ op: 'set', id: 'n6', key, value: mask & (1 << i) ? shared : other })
    const check = index => {
      const button = studio.playGet({ inspect: true }).tree[0].children.find(node => node.authoringId === 'n6')
      assert.deepEqual(button.children.filter(child => child.visible).map(child => child.authoringId).sort(),
        [mask & (1 << index) ? shared : other, decoration, ...(mask === 15 ? [other] : [])].sort(), `mask=${mask}, state=${keys[index]}`)
    }
    studio.patch({ op: 'set', id: 'n6', key: 'interactable', value: true })
    studio.playStart()
    check(0)
    studio.playPointer('move', 800, 450)
    check(1)
    studio.playPointer('down', 800, 450)
    check(2)
    studio.playPointer('up', 800, 450)
    check(1)
    studio.playPointer('move', 10, 10)
    check(0)
    studio.playStop()
    studio.patch({ op: 'set', id: 'n6', key: 'interactable', value: false })
    studio.playStart()
    check(3)
    studio.playStop()
  }
})

test('Lua interactable changes refresh button state without moving the pointer', () => {
  const studio = createStudio()
  const ids = {}
  for (const key of ['defaultChildId', 'hoverChildId', 'pressedChildId', 'unavailableChildId']) {
    ids[key] = studio.patch({ op: 'add', kind: 'image', parentId: 'n6', name: key }).selectedId
    studio.patch({ op: 'set', id: 'n6', key, value: ids[key] })
  }
  studio.patch({ op: 'addScript', controlId: 'n6', path: 'toggle-button.lua', source: `
function OnStart() script:EnableUpdate(true) end
function OnUpdate()
  script.object.interactable = not script.object.interactable
end
` })
  const visible = () => studio.playGet({ inspect: true }).tree[0].children.find(node => node.authoringId === 'n6')
    .children.filter(child => child.visible).map(child => child.authoringId)
  studio.playStart()
  assert.deepEqual(visible(), [ids.defaultChildId])
  studio.playPointer('down', 800, 450)
  assert.deepEqual(visible(), [ids.pressedChildId])
  studio.playStep(1 / 30)
  assert.deepEqual(visible(), [ids.unavailableChildId], 'disabled takes priority even during a press')
  studio.playPointer('up', 800, 450)
  studio.playStep(1 / 30)
  assert.deepEqual(visible(), [ids.defaultChildId])
  studio.playStop()
  const runtime = createRuntime()
  const button = runtime.addRoot({ kind: 'button', name: 'button' })
  assert.ok(runtime.buttonControls.has(button))
  runtime.destroyControl(button)
  assert.equal(runtime.buttonControls.has(button), false, 'destroyed buttons leave the state registry')
  runtime.destroy()
})

test('inspector exposes labeled enum options and native-color field metadata', () => {
  const studio = createStudio()
  const snap = studio.get()
  const fields = Object.fromEntries(snap.inspector.fields.map((field) => [field.key, field]))
  assert.equal(fields.anchorType.type, 'enum')
  assert.ok(fields.anchorType.options.some(option => option.value === 'center'))
  assert.ok(fields.horizontalAlignment.options.some(option => option.value === 'Left'))
  assert.equal(fields.fontColor.type, 'color')
  assert.equal(fields.bgColor.type, 'color')
  assert.equal(fields.outlineColor.type, 'color')
  assertNoUndefined(snap)
})

test('pick hits the centered preset button when the covering first sibling stays in place', () => {
  const studio = createStudio()
  studio.patch({ op: 'set', id: 'n11', key: 'visible', value: false })
  const after = studio.patch({ op: 'pick', x: 800, y: 450 })
  assert.equal(after.selectedId, 'n6')
})

test('earlier siblings paint over later siblings so a full-screen last child sits under the stage', () => {
  const studio = createStudio()
  const snap = studio.get()
  const names = snap.boxes.filter((box) => box.kind !== 'container' && box.kind !== 'server-container').map((box) => box.name)
  assert.equal(names[0], '全屏动效')
  assert.equal(names.at(-1), '文本框')
  const painted = studio.patch({ op: 'pick', x: 500, y: 700 })
  assert.notEqual(painted.selectedId, 'n11')
})

test('all eleven client control types are authorable without exposing protocol fields', () => {
  const studio = createStudio()
  const snap = studio.get()
  const kinds = snap.tree.filter((row) => row.kind !== 'server-container').map((row) => row.kind)
  assert.deepEqual(kinds, ['container', 'textbox', 'cursor', 'reference', 'grid', 'button', 'textwindow', 'keyhint', 'image', 'animation', 'fullscreen'])
  studio.patch({ op: 'select', id: 'n5' })
  const grid = studio.get().inspector.fields
  assert.equal(grid.some((field) => field.key.startsWith('giaRaw.')), false)
  assert.equal(grid.some((field) => field.raw || field.wire || field.key === 'protocolNote'), false)
})

test('business fields edit GIA slots while unknown values remain hidden and lossless', () => {
  const source = createStudio()
  source.patch({ op: 'set', id: 'n10', key: 'animationId', value: 'effect-index-1007' })
  source.patch({ op: 'set', id: 'n4', key: 'referencedPrefabId', value: 'template-index-2008' })
  source.patch({ op: 'set', id: 'n5', key: 'previewCount', value: 12 })
  source.patch({ op: 'set', id: 'n10', key: 'giaRaw.genericField501', value: 37 })
  source.patch({ op: 'set', id: 'n10', key: 'giaRaw.footerField505', value: 91 })
  source.patch({ op: 'set', id: 'n5', key: 'giaRaw.gridField507', value: 17 })
  source.patch({ op: 'set', id: 'n8', key: 'giaRaw.keyHintField502', value: 23 })
  source.patch({ op: 'set', id: 'n9', key: 'fillType', value: 'Radial90' })
  source.patch({ op: 'set', id: 'n2', key: 'giaRaw.textAlign', value: 9 })

  source.patch({ op: 'select', id: 'n10' })
  const effectInspector = source.get().inspector.fields
  const effectField = effectInspector.find((field) => field.key === 'animationId')
  assert.equal(effectField.value, 'effect-index-1007')
  assert.equal(effectField.type, 'string')
  assert.equal(effectInspector.some((field) => field.key.startsWith('giaRaw.') || field.raw || field.wire), false)

  const exported = source.exportData('gia')
  const target = createStudio()
  target.importData('gia', exported.data, exported.filename)
  const nodes = new Map()
  walk(target._project.root, (node) => nodes.set(node.kind, node))
  assert.equal(nodes.get('animation').animationId, 'effect-index-1007')
  assert.equal(nodes.get('animation').giaRaw.effectSlot, 'effect-index-1007')
  assert.equal(nodes.get('reference').referencedPrefabId, 'template-index-2008')
  assert.equal(nodes.get('grid').previewCount, 12)
  assert.equal(nodes.get('animation').giaRaw.genericField501, 37)
  assert.equal(nodes.get('animation').giaRaw.footerField505, 91)
  assert.equal(nodes.get('grid').giaRaw.gridField507, 17)
  assert.equal(nodes.get('keyhint').giaRaw.keyHintField502, 23)
  assert.equal(nodes.get('image').giaRaw.imageFillType, 3)
  assert.equal(nodes.get('textbox').giaRaw.textAlign, 9)

  const exportedAgain = target.exportData('gia')
  const verify = createStudio()
  verify.importData('gia', exportedAgain.data, exportedAgain.filename)
  const verifiedNodes = new Map()
  walk(verify._project.root, (node) => verifiedNodes.set(node.kind, node))
  assert.equal(verifiedNodes.get('animation').animationId, 'effect-index-1007')
  assert.equal(verifiedNodes.get('reference').referencedPrefabId, 'template-index-2008')
  assert.equal(verifiedNodes.get('grid').previewCount, 12)
  assert.equal(verifiedNodes.get('grid').giaRaw.gridField507, 17)
  assert.equal(verifiedNodes.get('image').giaRaw.imageFillType, 3)
  assert.equal(verifiedNodes.get('textbox').giaRaw.textAlign, 9)
})

test('JSON and GIA export-import round-trip supported control kinds in-process', () => {
  const studio = createStudio()
  const gia = studio.exportData('gia')
  const bytes = Buffer.from(gia.data, 'base64')
  assert.deepEqual(inspectGia(bytes), {
    gameVersion: '7.1.0', graphName: '客户端控件容器', accessories: 11,
    assetType: 'server-control-template', templateCount: 0,
  })
  const imported = studio.importData('gia', gia.data, 'round-trip.gia')
  assert.equal(imported.snapshot.meta.name, 'round-trip')
  assert.equal(imported.snapshot.tree.some((row) => row.kind === 'grid'), true)
  assert.equal(imported.snapshot.tree.some((row) => row.kind === 'fullscreen'), true)
  assertNoUndefined(imported.snapshot)
  const json = studio.exportData('json')
  const fromJson = studio.importData('json', json.data, 'authoring.json')
  assert.equal(fromJson.snapshot.meta.name, 'authoring')
})

test('updated textbox, image and four-state button settings survive GIA export-import', () => {
  const source = createStudio()
  source.patch({ op: 'set', id: 'n2', key: 'adaptiveFontSize', value: true })
  source.patch({ op: 'set', id: 'n2', key: 'enableOutline', value: false })
  source.patch({ op: 'set', id: 'n2', key: 'horizontalAlignment', value: 'Middle' })
  source.patch({ op: 'set', id: 'n9', key: 'enableMask', value: true })
  source.patch({ op: 'set', id: 'n9', key: 'enableSoftEdge', value: true })
  source.patch({ op: 'set', id: 'n9', key: 'softEdgeMode', value: 'Pixel' })
  source.patch({ op: 'set', id: 'n9', key: 'enableFill', value: true })
  source.patch({ op: 'set', id: 'n9', key: 'fillType', value: 'Radial180' })
  source.patch({ op: 'set', id: 'n9', key: 'reverseMaskArea', value: true })
  source.patch({ op: 'set', id: 'n6', key: 'interactable', value: false })
  source.patch({ op: 'set', id: 'n6', key: 'raycastTarget', value: false })
  for (const [key, name] of [
    ['defaultChildId', '导出默认态'],
    ['hoverChildId', '导出悬停态'],
    ['pressedChildId', '导出按下态'],
    ['unavailableChildId', '导出不可用态'],
  ]) {
    const added = source.patch({ op: 'add', kind: 'image', parentId: 'n6', name })
    source.patch({ op: 'set', id: 'n6', key, value: added.selectedId })
  }

  const gia = createStudio(source.archiveData()).exportData('gia')
  const target = createStudio()
  target.importData('gia', gia.data, 'updated-fields.gia')
  const nodes = []
  walk(target._project.root, (node) => nodes.push(node))
  const textbox = nodes.find((node) => node.kind === 'textbox')
  assert.equal(textbox.adaptiveFontSize, true)
  assert.equal(textbox.enableOutline, false)
  assert.equal(textbox.horizontalAlignment, 'Middle')
  const image = nodes.find((node) => node.kind === 'image' && node.name === '图片')
  assert.equal(image.enableMask, true)
  assert.equal(image.enableSoftEdge, true)
  assert.equal(image.softEdgeMode, 'Pixel')
  assert.equal(image.enableFill, true)
  assert.equal(image.fillType, 'Radial180')
  assert.equal(image.reverseMaskArea, true)
  const button = nodes.find((node) => node.kind === 'button')
  assert.equal(button.interactable, false)
  assert.equal(button.raycastTarget, false)
  for (const key of ['defaultChildId', 'hoverChildId', 'pressedChildId', 'unavailableChildId']) {
    assert.ok(button[key], key)
    assert.equal(button.children.find(child => child.id === button[key]).name, {
      defaultChildId: '导出默认态', hoverChildId: '导出悬停态', pressedChildId: '导出按下态', unavailableChildId: '导出不可用态',
    }[key])
  }
  assertNoUndefined(target.get())
})

test('server GIA writes image fill color and reverses sibling order to match official samples', () => {
  const studio = createStudio()
  studio.patch({ op: 'set', id: 'n9', key: 'imageColor', value: 0xff5cb0d6 })
  const before = studio.get().root.children[0].children.map((node) => node.name)
  assert.deepEqual(before[0], '文本框')
  assert.deepEqual(before.at(-1), '全屏动效')

  const exported = studio.exportData('gia')
  const compatibility = validateServerGiaCompatibility(Buffer.from(exported.data, 'base64'))
  assert.equal(compatibility.valid, true, compatibility.errors.join('\n'))
  assert.deepEqual(compatibility.controls[0].children.map((guid) => {
    return compatibility.controls.find((control) => control.id === guid)?.kind
  }), ['fullscreen', 'animation', 'image', 'keyhint', 'textwindow', 'button', 'grid', 'reference', 'cursor', 'textbox'])

  const target = createStudio()
  target.importData('gia', exported.data, 'color-order.gia')
  const after = []
  walk(target._project.root, (node, parent) => {
    if (parent?.kind === 'container' && parent.name === '容器节点') after.push(node.name)
  })
  assert.deepEqual(after, before)
  const image = []
  walk(target._project.root, (node) => { if (node.kind === 'image') image.push(node) })
  assert.equal(image[0].imageColor >>> 0, 0xff5cb0d6)
})

test('five canvas presets report GetUICanvasSize-matching sizes', () => {
  const studio = createStudio()
  const expect = {
    'pc-16-9': [1600, 900],
    'pc-21-9': [2100, 900],
    'mobile-16-9': [1280, 720],
    'mobile-19.5-9': [1560, 720],
    'mobile-4-3': [1280, 960],
  }
  for (const [id, wh] of Object.entries(expect)) {
    studio.patch({ op: 'setCanvas', canvasId: id })
    const compiled = compileProject(studio._project)
    assert.equal(compiled.canvasWidth, wh[0], id)
    assert.equal(compiled.canvasHeight, wh[1], id)
    assert.equal(studio.get().canvas.width, wh[0])
    assert.equal(studio.get().canvas.height, wh[1])
  }
})

test('new asset exports all eleven client controls as independently validated templates', () => {
  const kinds = ['container', 'textbox', 'cursor', 'reference', 'grid', 'button', 'textwindow', 'keyhint', 'image', 'animation', 'fullscreen']
  const labels = ['容器节点', '文本框', '光标检测区域', '模板引用控件', '网格视窗', '预设按钮', '文本视窗', '按键提示', '图片', '界面动效', '全屏动效']
  const server = createNode('server-container', { id: 'sc-all', name: '客户端控件模板' })
  server.children = kinds.map((kind, index) => createNode(kind, {
    id: `all-${index + 1}`,
    guid: 1073742200 + index,
    name: labels[index],
    ...(kind === 'image' ? { imageId: 0 } : {}),
  }))
  const studio = createStudio({
    version: 1,
    layoutSchemaVersion: 2,
    meta: {
      name: '全部客户端控件', assetType: 'client-control-template', sourceFormat: 'authoring',
      gameVersion: '7.0.50', giaOwnerUid: 114514, giaTimestamp: 1787410000,
      giaFileId: 1073741840, giaFileName: 'qxqy-client-controls-all.gia',
    },
    canvasId: 'pc-16-9', selectedId: 'all-1',
    script: { controlId: 'all-1', path: '', source: '' }, root: server,
  })
  const exported = studio.exportData('gia')
  const bytes = Buffer.from(exported.data, 'base64')
  const compatibility = validateGiaCompatibility(bytes)
  assert.equal(compatibility.valid, true, compatibility.errors.join('\n'))
  assert.equal(compatibility.templateCount, 11)
  assert.equal(compatibility.accessoryCount, 0)
  assert.deepEqual(compatibility.templates.map((item) => item.kind), kinds)
  assert.equal(compatibility.templates.every((item) => item.relatedPresent && item.relatedGuids.length === 0), true)
  assert.equal(compatibility.units.every((unit) => unit.template && unit.parent === 0 && unit.children.length === 0), true)
  assert.deepEqual(compatibility.explicitEmpty, { field17: 22, rectField508: 44 })
  const imported = createStudio().importData('gia', exported.data, exported.filename)
  assert.equal(imported.snapshot.asset.templateCount, 11)
  assert.deepEqual(imported.snapshot.tree.map((row) => row.kind), kinds)
})

test('new client template project exports one instantiable template with child controls', () => {
  const studio = createStudio()
  const snap = studio.patch({ op: 'newAsset', assetType: 'client-control-template' })
  assert.equal(snap.asset.type, 'client-control-template')
  assert.equal(snap.asset.templateCount, 1)
  assert.equal(snap.tree[0].name, 'Lua实例化面板')
  assert.equal(snap.tree[0].depth, 0)
  assert.equal(snap.boxes.some((box) => box.name === '确认按钮'), true)
  const added = studio.patch({ op: 'addTemplate', kind: 'image', name: '图标模板' })
  assert.equal(added.asset.templateCount, 2)
  assert.equal(added.tree.find((row) => row.name === '图标模板').depth, 0)
  assert.equal(added.boxes.length, 1)
  assert.equal(added.inspector.guid, 1073742105)
  const exported = studio.exportData('gia')
  const compatibility = validateGiaCompatibility(Buffer.from(exported.data, 'base64'))
  assert.equal(compatibility.valid, true, compatibility.errors.join('\n'))
  assert.match(compatibility.filePath, /^114514-\d+-1073741829-\\客户端控件模板列表\.gia$/u)
  assert.deepEqual(compatibility.templates.map((item) => [item.kind, item.actualIndex]), [
    ['container', 2], ['image', 7],
  ])
  assert.deepEqual(compatibility.templates.map((item) => item.relatedPresent), [true, true])
  assert.deepEqual(compatibility.templates.map((item) => item.relatedGuids), [[], []])
  assert.deepEqual(compatibility.explicitEmpty, { field17: 12, rectField508: 24 })
  assert.deepEqual(inspectGia(Buffer.from(exported.data, 'base64')), {
    gameVersion: '7.1.0', graphName: 'Lua实例化面板', accessories: 4,
    assetType: 'client-control-template', templateCount: 2,
  })
  const target = createStudio()
  const imported = target.importData('gia', exported.data, exported.filename)
  assert.equal(imported.snapshot.asset.type, 'client-control-template')
  assert.equal(imported.snapshot.root.children.length, 2)
  assert.equal(imported.snapshot.tree.some((row) => row.name === '模板标题'), true)
  assert.equal(compileProject(target._project).root.name, 'Lua实例化面板')
})

test('client template hierarchy can reparent controls, preserve nesting, and export multiple template roots', () => {
  const studio = createStudio()
  studio.patch({ op: 'newAsset', assetType: 'client-control-template' })
  studio.patch({ op: 'reparent', id: 'n2', parentId: 'n4' })
  studio.patch({ op: 'reparent', id: 'n3', parentId: 'sc1' })
  const moved = studio.patch({ op: 'moveSibling', id: 'n2', direction: 'up' })
  assert.equal(moved.asset.templateCount, 2)
  assert.equal(moved.tree.find((row) => row.id === 'n3').depth, 0)
  assert.equal(moved.tree.find((row) => row.id === 'n2').parentId, 'n4')
  assert.equal(moved.tree.find((row) => row.id === 'n2').depth, 2)
  assert.deepEqual(moved.tree.find((row) => row.id === 'n2').ancestorIds, ['n1', 'n4'])

  const exported = studio.exportData('gia')
  const bytes = Buffer.from(exported.data, 'base64')
  const compatibility = validateGiaCompatibility(bytes)
  assert.equal(compatibility.valid, true, compatibility.errors.join('\n'))
  assert.equal(compatibility.templateCount, 2)
  assert.deepEqual(compatibility.templates.map((item) => [item.kind, item.actualIndex, item.relatedPresent, item.relatedGuids]), [
    ['container', 2, true, []],
    ['image', 4, true, []],
  ])
  assert.equal(compatibility.accessoryCount, 3)

  const target = createStudio()
  const imported = target.importData('gia', exported.data, exported.filename)
  assert.equal(imported.snapshot.asset.templateCount, 2)
  assert.equal(imported.snapshot.tree.find((row) => row.name === '模板标题').depth, 2)
  assert.equal(imported.snapshot.tree.find((row) => row.name === '模板图标').depth, 0)
})

test('workspace option keeps the session cwd and uses neutral default names', () => {
  const nested = fileURLToPath(new URL('../', import.meta.url)).replace(/[/\\]+$/, '')
  const studio = createStudio(undefined, { workspacePath: nested })
  const snap = studio.get()
  assert.equal(snap.workspace.bound, true)
  assert.equal(snap.workspace.name, 'studio')
  assert.equal(snap.workspace.path, nested)
  assert.equal(snap.save.name, '未命名存档')
  assert.equal(snap.meta.name, '未命名界面')
})

test('unbound studio never falls back to the process startup directory', () => {
  const studio = createStudio()
  const snap = studio.get()
  assert.equal(snap.workspace.bound, false)
  assert.equal(snap.workspace.name, '未绑定')
  assert.equal(snap.workspace.path, '')
  assert.equal(snap.save.name, '未命名存档')
  assert.equal(snap.meta.name, '未命名界面')
})

test('setWorkspace retargets display only and never auto names', () => {
  const repoRoot = fileURLToPath(new URL('../../../', import.meta.url)).replace(/[/\\]+$/, '')
  const outsideRepo = tmpdir()
  const studio = createStudio(undefined, { workspacePath: outsideRepo })
  assert.equal(studio.get().workspace.name, basename(outsideRepo))
  assert.equal(studio.get().save.name, '未命名存档')
  assert.equal(studio.get().meta.name, '未命名界面')

  studio.setWorkspace(repoRoot)
  assert.equal(studio.get().workspace.name, basename(repoRoot))
  assert.equal(studio.get().workspace.path, repoRoot)
  assert.equal(studio.get().save.name, '未命名存档')
  assert.equal(studio.get().meta.name, '未命名界面')

  studio.patch({ op: 'renameSave', name: '我的存档' })
  studio.setWorkspace(outsideRepo)
  assert.equal(studio.get().save.name, '我的存档')
  assert.equal(studio.get().workspace.name, basename(outsideRepo))
})

test('new and unassigned server containers prefer 1073741847 while client controls start at 1073741850', () => {
  const studio = createStudio()
  assert.equal(studio.get().root.guid, 1073741847)
  assert.equal(studio.get().root.children[0].guid, 1073741850)
  studio.patch({ op: 'newAsset', assetType: 'server-control-template' })
  assert.equal(studio.get().root.guid, 1073741847)
  assert.equal(studio.archiveData().assets.client.root.guid, 0, 'the synthetic client holder has no assigned GUID')
  const server = createNode('server-container', { id: 'sc1', guid: 0, name: '客户端控件容器' })
  const root = createNode('container', { id: 'n1', guid: 0, name: '容器节点', isRootContainer: true })
  server.children.push(root)
  const project = createProject({
    version: 1,
    layoutSchemaVersion: 2,
    meta: { name: 'guid-base', assetType: 'server-control-template' },
    canvasId: 'pc-16-9',
    selectedId: 'n1',
    root: server,
  })
  const map = assignGuids(project)
  assert.equal(map.get('sc1'), 1073741847)
  assert.equal(map.get('n1'), 1073741850)
  assert.equal(createStudio().importData('gia', studio.exportData('gia').data).snapshot.root.guid, 1073741847)
})

test('assignGuids keeps later stored ids instead of filling from 1073742000', () => {
  const server = createNode('server-container', { id: 'sc1', guid: 0, name: '客户端控件容器' })
  const root = createNode('container', { id: 'n1', guid: 0, name: '容器节点', isRootContainer: true })
  const image = createNode('image', { id: 'n2', guid: 1073741889, name: '网格视窗模板' })
  const text = createNode('textbox', { id: 'n3', guid: 0, name: '文本框' })
  root.children.push(image, text)
  server.children.push(root)
  const project = createProject({
    version: 1,
    layoutSchemaVersion: 2,
    meta: { name: 'guid-preserve', assetType: 'server-control-template' },
    canvasId: 'pc-16-9',
    selectedId: 'n2',
    root: server,
  })
  const map = assignGuids(project)
  assert.equal(map.get('n2'), 1073741889)
  assert.equal(project.root.children[0].children[0].guid, 1073741889)
  assert.equal(map.get('sc1'), 1073741847)
  assert.equal(map.get('n1'), 1073741890)
  assert.equal(map.get('n3'), 1073741891)
  assert.deepEqual([...new Set(map.values())].length, map.size)
})

test('server allocation avoids an occupied preferred index and preserves existing server GUIDs', () => {
  for (const occupied of ['child', 'external']) {
    const project = createProject()
    project.root.guid = 0
    const used = new Set()
    if (occupied === 'child') project.root.children[0].guid = 1073741847
    else used.add(1073741847)
    const before = project.root.children.map(node => node.guid)
    const map = assignGuids(project, used)
    assert.equal(map.get('sc1'), 1073741861, `${occupied} retains 1073741847; the server falls back above the used range`)
    assert.deepEqual(project.root.children.map(node => node.guid), before)
  }
  for (const guid of [1073741850, 1073742200, 1500000000]) {
    const archive = createStudio().archiveData()
    archive.assets.server.root.guid = guid
    archive.assets.server.root.children[0].guid = 1073742300
    const studio = createStudio(archive)
    assert.equal(studio.get().root.guid, guid)
    assert.equal(studio.get().root.guid, guid, 'repeated snapshots cannot reset a stored server index')
    assert.deepEqual(studio.get().controlGuidChanges, [])
    const saved = createStudio(JSON.parse(Buffer.from(studio.exportData('save').data, 'base64')))
    assert.equal(saved.get().root.guid, guid)
  }
})

test('imported save archives keep their explicit name over workspace auto naming', () => {
  const source = createStudio()
  const exported = source.exportData('save')
  const target = createStudio(undefined, { workspacePath: tmpdir() })
  const imported = target.importData('json', exported.data, exported.filename)
  const payload = JSON.parse(Buffer.from(exported.data, 'base64').toString('utf8'))
  assert.equal(imported.snapshot.save.name, payload.meta.name)
})
