// Build script: host half (ESM) + client half (__ModuleLoader__ bundle).
import { build } from 'esbuild'
import { readFileSync } from 'node:fs'

const pkg = JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf8'))

// --- host half: lib/index.js (ESM, node platform) ---
await build({
  entryPoints: ['src/index.ts'],
  bundle: true,
  format: 'esm',
  platform: 'node',
  target: 'node20',
  external: ['node:*', '@deepseek-ai/*', 'schemastery', 'ws'],
  outfile: 'lib/index.js',
  logLevel: 'info',
})

// --- client half: lib/client.js (CJS wrapped in __ModuleLoader__.load) ---
const id = pkg.name
const banner =
  'window.__ModuleLoader__.load({id:' +
  JSON.stringify(id) +
  ',factory:(require)=>{var module={exports:{}};var exports=module.exports;'
const footer = 'return module.exports;}});'

await build({
  entryPoints: ['src/client/index.tsx'],
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: ['chrome120'],
  jsx: 'automatic',
  external: ['react', 'react-dom/client', 'react/jsx-runtime', '@deepseek-ai/*'],
  outfile: 'lib/client.js',
  banner: { js: banner },
  footer: { js: footer },
  logLevel: 'info',
})

console.log('build done:', pkg.name)
