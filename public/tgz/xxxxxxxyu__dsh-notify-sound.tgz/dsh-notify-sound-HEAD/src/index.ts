/**
 * dsh-notify-sound host half: watches session events for turn/end (the agent
 * finished replying), pushes a notification over WebSocket to connected
 * pages, and serves the bundled sound files plus the preferences API.
 * Preferences live in the DSH settings service (namespace dsh-notify-sound).
 */
import { readdir, readFile, stat } from 'node:fs/promises'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { WebSocket, WebSocketServer } from 'ws'
import z from 'schemastery'
import { settingsNamespace } from '@deepseek-ai/dsh-settings'
import { isTrustedApiRequest, trustedHostsOf } from './trust-fence.ts'

export const name = 'dsh-notify-sound'
export const inject = ['webServer', 'loader', 'settings']

const NS = 'dsh-notify-sound'
const API_PREFIX = '/notify-sound/api'
const SOUND_PREFIX = '/notify-sound/sounds'
const WS_PATH = '/notify-sound/ws'
/** Directory of this host-half module (lib/); sounds live at the package root. */
const SOUNDS_DIR = fileURLToPath(new URL('../sounds/', import.meta.url))
const SOUND_RE = /^[a-z0-9-]+\.aac$/

/** User-facing preferences (validated by the settings service). */
export const PrefsSchema = z.object({
  enabled: z.boolean().default(true),
  sound: z.string().default('staplebops-01.aac'),
  volume: z.number().min(0).max(1).default(0.8),
})

// ---------------------------------------------------------------- wire helpers

function writeJson(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(body))
}

function writeOk(res: ServerResponse, value: unknown): void {
  writeJson(res, 200, { ok: true, value })
}

function writeError(res: ServerResponse, status: number, code: string, message: string): void {
  writeJson(res, status, { ok: false, error: { code, message } })
}

// ---------------------------------------------------------------- settings face

type PrefsView = { value: unknown; revision: unknown }

let settingsFace: { get: () => PrefsView; update: (patch: unknown, expectedRevision?: unknown) => Promise<PrefsView> } = {
  get: () => ({ value: undefined, revision: undefined }),
  update: async () => ({ value: undefined, revision: undefined }),
}

// ---------------------------------------------------------------- plugin body

export function apply(ctx: any): void {
  // Register the preferences namespace with the DSH settings service.
  ctx.inject(['settings'], (sctx: any) => {
    const ns = settingsNamespace(NS)
    sctx.settings.register(ns, PrefsSchema)
    const viewOf = (): PrefsView => {
      const descriptor = sctx.settings.describe({ redactSecrets: true }).find((c: any) => c.ns === ns)
      return descriptor === void 0
        ? { value: void 0, revision: void 0 }
        : { value: descriptor.value, revision: descriptor.revision }
    }
    settingsFace = {
      get: viewOf,
      update: async (patch, expectedRevision) => {
        await sctx.settings.update(ns, patch, expectedRevision)
        return viewOf()
      },
    }
  })

  const fence = (req: IncomingMessage) => isTrustedApiRequest(req, trustedHostsOf(ctx))

  // --- WebSocket: push turn/end notifications to connected pages ---
  const wss = new WebSocketServer({ noServer: true })
  ctx.effect(() => ctx.webServer.registerUpgrade({
    path: WS_PATH,
    handler: (req: IncomingMessage, socket: any, head: any) => {
      if (!fence(req)) {
        socket.destroy()
        return
      }
      wss.handleUpgrade(req, socket, head, (ws) => {
        ws.on('error', () => { /* ignore */ })
        ws.on('close', () => { /* ignore */ })
      })
    },
  }), 'dsh-notify-sound: notification WebSocket')

  const broadcast = (payload: unknown) => {
    const text = JSON.stringify(payload)
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) client.send(text)
    }
  }

  // --- Session events: the moment the agent finished replying ---
  const disposeEvents = ctx.on('session/event', (session: unknown, event: any) => {
    try {
      if (event !== null && typeof event === 'object' && event.type === 'turn/end') {
        broadcast({ type: 'turn/end', at: Date.now() })
      }
    } catch { /* ignore */ }
  })

  ctx.effect(() => () => {
    disposeEvents()
    wss.close()
  }, 'dsh-notify-sound: teardown')

  // --- API: sound list + preferences ---
  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: API_PREFIX,
    handler: async (req: IncomingMessage, res: ServerResponse) => {
      if (!fence(req)) {
        writeError(res, 403, 'forbidden', 'forbidden')
        return
      }
      if (req.method !== 'POST') {
        writeError(res, 405, 'method-error', 'method not allowed')
        return
      }
      const pathname = new URL(req.url ?? '/', 'http://dsh.internal').pathname
      const method = pathname.startsWith(API_PREFIX + '/') ? pathname.slice(API_PREFIX.length + 1) : undefined
      try {
        if (method === 'sounds.list') {
          const names = (await readdir(SOUNDS_DIR)).filter((n) => SOUND_RE.test(n)).sort()
          writeOk(res, { sounds: names })
          return
        }
        if (method === 'prefs.get') {
          writeOk(res, settingsFace.get())
          return
        }
        if (method === 'prefs.update') {
          const body = await readJsonBody(req)
          const patch = body?.patch
          if (patch === null || typeof patch !== 'object') {
            writeError(res, 400, 'bad-request', 'patch object required')
            return
          }
          writeOk(res, await settingsFace.update(patch, body?.expectedRevision))
          return
        }
        writeError(res, 404, 'not-found', 'unknown notify-sound API method')
      } catch (error) {
        writeError(res, 500, 'internal', error instanceof Error ? error.message : String(error))
      }
    },
  }), 'dsh-notify-sound: api routes')

  // --- Sound files: serve bundled .aac (allowlisted names only) ---
  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: SOUND_PREFIX,
    handler: async (req: IncomingMessage, res: ServerResponse) => {
      if (!fence(req)) {
        res.writeHead(403)
        res.end('forbidden')
        return
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        res.writeHead(405)
        res.end()
        return
      }
      const name = /^\/notify-sound\/sounds\/([a-z0-9-]+\.aac)$/.exec(new URL(req.url ?? '/', 'http://dsh.internal').pathname)?.[1]
      if (name === undefined) {
        res.writeHead(404)
        res.end('not found')
        return
      }
      try {
        const info = await stat(join(SOUNDS_DIR, name))
        if (!info.isFile()) throw new Error('not a file')
        const body = await readFile(join(SOUNDS_DIR, name))
        res.writeHead(200, {
          'content-type': 'audio/aac',
          'cache-control': 'public, max-age=86400',
          'content-length': body.length,
        })
        if (req.method === 'HEAD') res.end()
        else res.end(body)
      } catch {
        res.writeHead(404)
        res.end('not found')
      }
    },
  }), 'dsh-notify-sound: sound files route')
}

/** Read and parse the JSON request body (bounded). */
async function readJsonBody(req: IncomingMessage): Promise<any> {
  const chunks: Buffer[] = []
  let total = 0
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    total += buffer.length
    if (total > 1 << 20) throw new Error('request body too large')
    chunks.push(buffer)
  }
  const text = Buffer.concat(chunks).toString('utf8')
  if (text.trim() === '') return {}
  return JSON.parse(text)
}
