/**
 * dsh-notify-sound client half: connects to the plugin's notification
 * WebSocket, plays the selected sound when the agent finishes replying
 * (turn/end), and contributes a Settings section (sound / volume / on-off
 * with per-sound preview).
 */
import { useEffect, useState } from 'react'

const API = '/notify-sound/api'
const WS_PATH = '/notify-sound/ws'
const SOUNDS_PATH = '/notify-sound/sounds'

/** Module-level shared prefs (written by the settings section, read by the player). */
const prefsState = {
  enabled: true,
  sound: 'staplebops-01.aac',
  volume: 0.8,
}

// ---------------------------------------------------------------- api helpers

async function call<T>(method: string, payload: unknown = {}): Promise<T> {
  const res = await fetch(`${API}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
  const parsed = await res.json().catch(() => null)
  if (!res.ok || parsed?.ok !== true) {
    throw new Error(parsed?.error?.message ?? `HTTP ${res.status}`)
  }
  return parsed.value as T
}

// ---------------------------------------------------------------- player

/** Play the selected sound once (re-entrant: restarts when called again). */
function playSound(sound: string, volume: number) {
  try {
    const audio = new Audio(`${SOUNDS_PATH}/${sound}`)
    audio.volume = Math.max(0, Math.min(1, volume))
    audio.play().catch(() => { /* autoplay blocked before user gesture */ })
  } catch { /* ignore */ }
}

/** Keep one fresh Audio element per play (no shared instance churn issues). */
let lastAudio: HTMLAudioElement | null = null
function playCurrent() {
  const p = prefsState
  if (!p.enabled) return
  try {
    if (lastAudio) {
      lastAudio.pause()
      lastAudio = null
    }
    const audio = new Audio(`${SOUNDS_PATH}/${p.sound}`)
    audio.volume = p.volume
    lastAudio = audio
    audio.play().catch(() => { /* ignore */ })
  } catch { /* ignore */ }
}

/** WebSocket pump: reconnect forever, play on turn/end. */
function connectPlayer() {
  let ws: WebSocket | null = null
  let stopped = false
  let timer: number | undefined

  const connect = () => {
    if (stopped) return
    try {
      ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}${WS_PATH}`)
    } catch {
      scheduleReconnect()
      return
    }
    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(String(event.data))
        if (msg?.type === 'turn/end') playCurrent()
      } catch { /* ignore */ }
    }
    ws.onclose = () => scheduleReconnect()
    ws.onerror = () => { try { ws?.close() } catch { /* ignore */ } }
  }
  const scheduleReconnect = () => {
    if (stopped) return
    timer = window.setTimeout(connect, 3000)
  }
  connect()
  return () => {
    stopped = true
    if (timer !== undefined) window.clearTimeout(timer)
    try { ws?.close() } catch { /* ignore */ }
  }
}

// ---------------------------------------------------------------- settings section

const rowStyle: React.CSSProperties = {
  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
  gap: '12px', padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.08)',
}
const labelStyle: React.CSSProperties = { fontSize: 13, color: '#e6edf3' }
const descStyle: React.CSSProperties = { fontSize: 12, color: '#9da7b3', marginTop: 2 }
const selectStyle: React.CSSProperties = {
  background: '#1b1b22', color: '#e6edf3', border: '1px solid rgba(255,255,255,0.15)',
  borderRadius: 8, padding: '6px 10px', fontSize: 13, minWidth: 180,
}
const buttonStyle: React.CSSProperties = {
  background: 'rgba(255,255,255,0.08)', color: '#e6edf3', border: '1px solid rgba(255,255,255,0.15)',
  borderRadius: 8, padding: '6px 14px', fontSize: 13, cursor: 'pointer',
}

function SettingsSection() {
  const [enabled, setEnabled] = useState(prefsState.enabled)
  const [sound, setSound] = useState(prefsState.sound)
  const [volume, setVolume] = useState(prefsState.volume)
  const [sounds, setSounds] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const [list, view] = await Promise.all([
          call<{ sounds: string[] }>('sounds.list'),
          call<{ value?: any }>('prefs.get'),
        ])
        if (cancelled) return
        const names = list.sounds
        setSounds(names)
        const v = view?.value
        if (v && typeof v === 'object') {
          if (typeof (v as any).enabled === 'boolean') setEnabled((v as any).enabled)
          if (typeof (v as any).sound === 'string' && names.includes((v as any).sound)) setSound((v as any).sound)
          if (typeof (v as any).volume === 'number') setVolume((v as any).volume)
        }
        if (!names.includes(sound)) setSound('staplebops-01.aac')
        setLoading(false)
      } catch (e) {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : String(e))
          setLoading(false)
        }
      }
    })()
    return () => { cancelled = true }
  }, [])

  const persist = async (patch: Record<string, unknown>) => {
    try {
      await call('prefs.update', { patch, expectedRevision: undefined })
      setError('')
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }

  const onToggle = (next: boolean) => {
    setEnabled(next)
    prefsState.enabled = next
    void persist({ enabled: next })
  }
  const onSound = (next: string) => {
    setSound(next)
    prefsState.sound = next
    void persist({ sound: next })
  }
  const onVolume = (next: number) => {
    setVolume(next)
    prefsState.volume = next
    void persist({ volume: next })
  }
  const preview = () => {
    try {
      const audio = new Audio(`${SOUNDS_PATH}/${sound}`)
      audio.volume = volume
      audio.play().catch(() => { /* ignore */ })
    } catch { /* ignore */ }
  }

  return (
    <div style={{ padding: '4px 2px' }}>
      {loading && <div style={descStyle}>加载中…</div>}
      {error !== '' && <div style={{ ...descStyle, color: '#f2a1a1' }}>{error}</div>}
      {!loading && error === '' && (
        <>
          <div style={rowStyle}>
            <div>
              <div style={labelStyle}>回复完成提示音</div>
              <div style={descStyle}>AI 回复完毕后播放提示音</div>
            </div>
            <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer', gap: 6 }}>
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => onToggle(e.target.checked)}
                style={{ width: 15, height: 15, accentColor: '#4f8cff' }}
              />
              <span style={labelStyle}>{enabled ? '已开启' : '已关闭'}</span>
            </label>
          </div>

          <div style={rowStyle}>
            <div>
              <div style={labelStyle}>提示音</div>
              <div style={descStyle}>选择回复完成时播放的音效</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <select value={sound} onChange={(e) => onSound(e.target.value)} style={selectStyle}>
                {sounds.map((name) => (
                  <option key={name} value={name}>{name.replace(/\.aac$/, '')}</option>
                ))}
              </select>
              <button type="button" onClick={preview} style={buttonStyle} title="试听">试听</button>
            </div>
          </div>

          <div style={rowStyle}>
            <div>
              <div style={labelStyle}>音量</div>
              <div style={descStyle}>{Math.round(volume * 100)}%</div>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={volume}
              onChange={(e) => onVolume(Number(e.target.value))}
              style={{ width: 180, accentColor: '#4f8cff' }}
            />
          </div>
        </>
      )}
    </div>
  )
}

// ---------------------------------------------------------------- plugin body

/** Services required before mounting. */
export const inject: string[] = ['slots', 'connection']

/** Client plugin body. */
export function apply(ctx: any): void {
  ctx.effect(() => {
    // Load prefs into the shared state (best effort).
    call<{ value?: any }>('prefs.get').then((view) => {
      const v = view?.value
      if (v && typeof v === 'object') {
        if (typeof (v as any).enabled === 'boolean') prefsState.enabled = (v as any).enabled
        if (typeof (v as any).sound === 'string') prefsState.sound = (v as any).sound
        if (typeof (v as any).volume === 'number') prefsState.volume = (v as any).volume
      }
    }).catch(() => { /* ignore */ })
    return connectPlayer()
  }, 'dsh-notify-sound: player')

  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'notify-sound',
    order: 100,
    label: () => '提示音',
    inject: () => ({}),
  }, SettingsSection))
}
