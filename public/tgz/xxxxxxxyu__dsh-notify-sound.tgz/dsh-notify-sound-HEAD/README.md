# dsh-notify-sound

DSH (DeepSeek Harness) web 插件：**AI 回复完毕后自动播放提示音**。

支持在 DSH 设置页中随时更换音效（内置 44 个音效）、调整音量、开关。

## 功能

- 回合结束（agent 回复完毕）自动播放提示音，通过 WebSocket 实时推送，零轮询
- 默认音效 staplebops-01.aac
- 设置页（设置 → 提示音）：开/关、音效选择、音量调节、试听
- 设置即时保存，重启后保留（存储在 DSH 设置服务，全局生效）
- 音效文件内置在插件中，无需联网

## 安装

要求：DSH web profile（dsh web），Node.js >= 20。

````
# 从 GitHub 安装
dsh plugin --profile web add git+https://github.com/<you>/dsh-notify-sound.git

# 或本地开发安装
cd C:/Users/<you>/.dsh/profiles/web
pnpm add file:/path/to/dsh-notify-sound
````

安装后确认包已加入 dsh.profile.bundles，然后**重启 dsh 服务**生效。

## 设置

打开 DSH 设置页，左侧导航出现"提示音"：

| 设置项 | 说明 |
| --- | --- |
| 回复完成提示音 | 开关（默认开启） |
| 提示音 | 下拉选择音效（44 个），选中即生效 |
| 试听 | 播放当前选中的音效 |
| 音量 | 0 ~ 100% 滑块 |

## 架构

- 后端（src/index.ts）：监听会话事件中的 turn/end（回合结束）→ WebSocket 广播；
  提供音效静态路由（/notify-sound/sounds/<name>.aac）与偏好 API
  （/notify-sound/api/sounds.list | prefs.get | prefs.update）；偏好存储在
  DSH 设置服务（namespace dsh-notify-sound）。
- 前端（src/client/index.tsx）：连接通知 WebSocket，收到 turn/end 播放所选音效；
  注册 DSH 设置页 settings.section 插槽。
- 所有路由经过与 /api 网关相同的浏览器信任围栏（loopback / 同源校验）。

## 开发构建

````
npm install
npm run build   # 产出 lib/index.js + lib/client.js
````

## 音效来源

内置音效（sounds/*.aac，alert / bip-bop / nope / staplebops / yup 系列）来自
[Stephanvs/opencode-sfx](https://github.com/Stephanvs/opencode-sfx)，MIT 许可，
版权归其作者所有，详见 sounds/LICENSE。

## 许可

MIT License —— 插件代码见 LICENSE；音效版权归 opencode-sfx 作者。
