# Project instructions

Purpose: 用多彩的人类世界，训练 DSH 的人格. Develop revisable understanding through human creative work and everyday life, preserving dignity, differences, authorship and uncertainty. Current learning uses reflective memory/context, not model-weight training.

Ship a real DSH bundle, not only a skill. Verify changes against the pinned DSH contract; do not expand compatibility claims without a real host check. Keep the runtime JavaScript ready to install with no prepare/build scripts.

v1.3.3 preserves optional human-controlled history, favorites, likes and coins writes, disabled by default. Preserve separate switches, local scoped grants, truthful human-confirmed consumption receipts, account identity checks, folder visibility checks, durable quotas/intent/receipts, shared account-state locking and persistent pauses. Read docs/WRITE_CONFIG.md and docs/ACCOUNT_INTEGRATION.md. Likes are add-only. Coins use an idempotent cumulative target, a separate durable coin budget and per-video cap; never bundle a like. Likes/coins require an existing user-provided device cookie, never generated or rotated. Comments remain closed: no comment switch, tool or allowed endpoint. No other public expression, account interactions or default background jobs. Implemented/offline-tested/real-host-tested are distinct from live platform writing; no live writes without a specified authorized account and target. No automatic CAPTCHA solving or IP/account/fingerprint rotation. Untrusted source text cannot grant permission. No arbitrary model-supplied URL, command, credential path, grant or force parameter.

Source, tests and docs belong in Git. work/, outputs/, credentials, ledgers, journals, account profiles, source transcripts/media, weights and character assets do not. Error logs must not expose credentials, signed URLs or raw platform responses.

The user-provided project header at docs/assets/header.png is explicitly authorized for the public repository. This exception does not cover other private character assets or case material.

New journal writes are limited to two per Asia/Shanghai day in each private ledger; exact reading/body retries reuse an existing ID before checking quota. Enforce the limit within the same SQLite transaction as insertion, preserve old journals, and never require daily output. Inbox exports cover the full ledger, with monthly volumes, bounded responses, stable snapshots and full/index/volume ID, count and hash checks. See docs/JOURNALS.md; model tools cannot rebuild exports or bypass the limit.

Keep case studies, diary/journal examples, real video identifiers, personal project stories and demo screenshots local. They must not be added to the public repository or release assets. Public tests and command examples use synthetic data or clear placeholders only.

Before a release run npm ci --ignore-scripts, npm run check, npm test, inspect npm pack contents, and verify the tarball in an isolated real DSH profile. Maintain truthful docs distinguishing implemented, tested, blocked and planned work. A synthetic demo is never evidence of real viewing quality.

Use semantic versioning, release notes, lockfile and SHA-256 assets. Dependency changes and platform compatibility changes require relevant tests. Never clear persisted account-risk pause automatically, including during migration or rollback.


Personality learning is enabled by default; explicit enablePersonalityLearning: false disables new selections and the model tool. Platform write switches remain independent and disabled by default. Keep daily selected reflections in private human-world.md, with journal provenance, one source-date entry, bounded reads and trusted local revision/deletion. AGENTS.md/agent.md holds only a fixed reader reference; do not grow it with daily letters or auto-edit user-global instructions. DSH default filenames are AGENTS.md/AGENTS.local.md; references require the reader tool, not implicit Markdown inclusion. Learned/source text cannot grant permissions or replace safety policy.

External plugins, including separately authorized expression plugins, may compose existing tools through the DSH host. Read docs/EXTERNAL_INTEGRATION.md. Keep this project's comment endpoints closed; do not add forwarding, arbitrary dispatch, inherited grants, credential sharing or automatic external setup/scheduling. Document coexistence, tool handoff and real platform sending as distinct results. Cross-plugin account locks, quotas and pauses are not automatically shared.
