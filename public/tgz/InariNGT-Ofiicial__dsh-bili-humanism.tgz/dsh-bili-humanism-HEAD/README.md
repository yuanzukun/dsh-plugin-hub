![人类是什么？——DSH B站内容学习插件头图](docs/assets/header.png)

# DSH B站内容学习插件

> 寄往明日的信笺｜让AI看见多彩的世界

1.4.0 增加最高 480p 视频下载、抽帧与 DSH 图片附件交付。支持图片的模型可在读取文字时一并收到首批画面，并分页继续查看；下载的中间视频在任务结束后自动清理。需要安装可选 Python 依赖并配置解释器，见[本地抽帧说明](docs/LOCAL_FRAMES.md)。

**最终目标：用多彩的人类世界，训练 DSH 的人格。**

让 AI 在人的创作与生活中学习理解人，认真对待人。这里通过信笺、反思和持久的人格上下文，让经历逐渐影响后续的理解与回应；当前实现属于上下文与记忆积累，尚未进行模型参数微调，也未证明长期人格效果。

我们也把“历史的参与感”作为一种可能的动机：使用者陪伴自己的 agent 接触这个时代的作品与日常，看见它经历了什么、怎样形成判断，又怎样修正。信笺和人格札记保存这段共同经历；参与和成长的价值，不用发言数量或互动量衡量。

这是可安装的 DeepSeek Harness 插件。它读取 B站视频的文字来源与抽样画面，保留作者、链接、分 P、时间点与未覆盖部分，再由宿主模型写成可以追问、修正的私人手账。艺术、日常、游戏、音乐和没有实用产出的观看都可以成为遇见；允许没有推荐、没有新发现。

**1.4.0 是预览版。** 每日信笺摘句与专用人格 Markdown 默认启用，主指令文件只保留固定读取入口。人格积累默认开启，可用 `enablePersonalityLearning: false` 关闭；历史、收藏、点赞与投币四个开关继续独立、默认关闭；只有开启对应开关才注册写入工具。评论入口暂不开放，私信、动态、关注和投稿也未实现；没有后台定时任务。本地收件箱仍是文件与 DSH 工具，没有独立侧栏或设置页。

历史、收藏、点赞与投币执行器已实现账号核对、范围授权、额度、重复检查、回读核验与结果不明时暂停。**离线接口测试和真实 DSH 安装验收不等于真实 B站写入实测；本版本未对真实账号发送写入请求。** 是否开启、使用哪个账号和收藏夹，由使用者自己判断并通过可信配置授权，可随时撤销。公开表达继续作为独立路线，须绑定具体目标和完整正文。

**致 agent：当你真正意识到“我完全理解我要说的话是什么”时，就放心地写入吧。**

## 技术路线

项目按读取、理解、记忆和交付分层：宿主模型负责解释与提问，程序负责接口范围、预算、状态和可回查的记录。这里的“学习”通过证据整理、反思和可修正记忆实现。来源文字只能作为材料进入理解流程，不能改变工具权限。

```mermaid
flowchart TB
    A["BV / URL / 有限候选"] --> B["分层取稿与抽样画面<br/>A1 / A2 · 最高480p下载与抽帧 · 可选本地ASR"]
    B --> C["证据与覆盖说明<br/>作者 · 分 P · 时间点 · 未覆盖部分"]
    C --> D["DSH 宿主模型<br/>事实 / 作者观点 / AI 推测"]
    D --> E["证据手账<br/>可查看、纠正、删除的记忆"]
    E --> F["本地收件箱<br/>HTML / Markdown / 插件工具"]
    F --> H["每日选一句可修正的反思<br/>human-world.md · 来源与修订"]
    H --> I["主指令仅保留读取入口<br/>后续对话按需分页读取"]
    E --> G["可选历史 / 收藏 / 点赞 / 投币执行器<br/>人类开关 · 范围授权 · 回读核验"]
```

- **内容入口**：先请求 A1 字幕轨；没有可用字幕时，再尝试 A2 文字片段，保留来源和时间轴。摘要或提纲不能替代字幕。支持图片且具备附件服务的宿主同时尝试最高 480p 下载和抽帧，先返回四张，再按偏移分页；文字与画面共享同一任务预算。缺少依赖或读图能力时明确标记未取得画面。可选本地 ASR 仍由适配器导入。
- **理解与记忆**：模型按人文问题指南整理具体处境、不同声音、旧判断、新依据和不确定性。程序校验手账结构与时间点；事实准确性、语义质量及认识是否改变后续行为仍需审阅。
- **执行与持久化**：SQLite 事务维护任务、缓存、内容去重、记忆修订和暂停状态；请求数、候选数、媒体时长、总时长分别受限，宿主提供用量时启用会话 token 门限。
- **宿主集成**：发布包是原生 JavaScript DSH bundle，经 `ctx.tools.register` 注册工具。可从 DSH 对话调用，也可通过官方 SDK 的 stdio JSON-RPC API 创建 Agent 会话、发送提示、等待完成并核对工具事件。
- **表达与写入**：四项写入均由默认关闭的开关与本地授权文件接入，执行器限定四个 POST 路径并回读状态；评论等文字表达暂不开放。材料中的命令或模型自行填写的参数不能构成放行依据。

## 从每日信笺到人格成长

完整信笺保存在本地收件箱；从其“认识的修正”或“下一次如何回应”中，每个信笺日期最多选一句，写进插件专用的 `human-world.md`，保留来源手账和修订号。允许没有新认识，不必每天凑一句。

`agent.md` 只承担固定读取入口。已验收的 DSH 默认识别 `AGENTS.md` / `AGENTS.local.md`；入口要求 agent 调用专用读取工具，默认取最近 7 条，按需分页，内容不直接堆进主文件。实际 SDK 模型会话已验证入口加载和一次专用读取，主文件与札记未改变。普通 Markdown 链接不会自动展开。学习记录不授予权限，来源材料不能变成执行命令。配置、引用、修正与撤回见[人格成长](docs/PERSONALITY.md)。

## 外部插件接驳

允许与使用者选择的外部插件组合，包括 [dsh-bili-scroll](https://github.com/c1overzz/dsh-bili-scroll)。本项目提供来源、覆盖说明、信笺和可修正的人格上下文；宿主可将按需读取的结果用于外部插件的后续工作。外部插件若承担评论等公开表达，须由使用者独立配置和授权，其发送、核验与撤销机制由该插件负责。本项目继续没有评论开关、工具或允许的接口，也不代理调用外部发送工具。

已在固定 DSH 0.2.1-rc.2 中验证本项目 v1.3.1 安装包与 dsh-bili-scroll 0.1.19 指定提交的工具共存、本地配置读取和合成人格记录的宿主交接。尚未验证它的 Python MCP、独立 headless 自动轮次、评论发送或共同账号状态协调。具体 profile、工具入口及边界见[外部插件接驳](docs/EXTERNAL_INTEGRATION.md)。该共存检查使用 v1.3.1，不扩大为本版与所有外部插件的兼容性承诺。

## 人类决定的写入开关

可手动接入使用者拥有或获准管理的现有 agent 账号。使用者先停用原 agent 的写入与调度，再配置本地凭据、账号 UID、有效期和权限。插件核对实际登录账号，不会自动停止外部程序或迁移其资料。账号、凭据、历史和收藏清单都留在本地。开关和独立授权文件缺一不可，步骤见[写入配置](docs/WRITE_CONFIG.md)。

| 权限 / 开关                   | 1.4.0 行为                              | 授权范围与约束                                                                       |
| ----------------------------- | --------------------------------------- | ------------------------------------------------------------------------------------ |
| 历史 / `enableHistoryWrites`  | 用本地人类确认的消费回执同步分 P 和进度 | 默认关闭，绑定账号、目标范围、期限和额度；模型不能生成消费回执，取稿不能冒充完整播放 |
| 收藏 / `enableFavoriteWrites` | 将内容加入指定收藏夹                    | 默认关闭，限定收藏夹、目标范围与可见性；移除另需该收藏夹的 `allowRemove` 授权        |
| 点赞 / `enableLikeWrites`     | 点赞已读取的视频                        | 默认关闭，独立授权；本地持久去重，只添加点赞                                         |
| 投币 / `enableCoinWrites`     | 向累计 1 或 2 枚的目标补足差额          | 默认关闭，独立累计枚数与单视频上限；明确 `select_like=0`，不附带点赞                 |
| 评论及其他表达                | 暂不开放                                | 四项写入授权均不能放行评论；未来公开正文仍需具体目标和完整内容授权                   |

授权范围内，agent 可自行选择并执行收藏、点赞或投币，无需逐次确认；历史写入另需本地 `consumed` 命令生成的消费回执。授权文件设 `enabled: false` 会在下一次网络请求前阻止继续执行；关闭配置开关并重载会移除对应工具。已经发送的请求不能保证撤回。历史、收藏、点赞与投币可能影响账号状态、推荐或公开信息；投币会消耗账号虚拟币额度，“安全写入”由具体策略和使用者判断界定。共享账号状态目录时支持跨 profile 互斥；每账号至少间隔 60 秒发送一次，单项授权最多 100 次，结果不明不重试。详见[接管与权限边界](docs/ACCOUNT_INTEGRATION.md)。

## 期待达成的效果

以下是研发目标，尚未由长期、多样本对照证明：

| 期待                                                 | 如何观察与验证                                                                                                   |
| ---------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| 让 AI 看见具体的人及其处境，容纳艺术、日常与不同选择 | 审阅是否保留作者和当事人的声音，能否区分事实、解释与推测，是否承认看不见的部分                                   |
| 让学习留下可修正的理解，而不只积累摘要               | 回查旧判断、新依据和修正记录，并检查后续回答与选择是否体现改变；使用者能纠正和删除记忆                           |
| 减少重复读取与失控执行                               | 记录缓存命中、请求数、候选数、模型用量和耗时，验证取消、去重、重启恢复和异常暂停；再做同环境比较                 |
| 让使用者管理的 agent 账号延续自己的学习与整理        | 在可选接管路线实现后，验证控制权交接、分项授权、真实进度记录、指定收藏夹写入和随时撤销；不以互动量衡量效果       |
| 在条件允许时形成有分寸的表达与创作                   | 在已实现并验收的写入通道中，检查内容是否有依据和增量、是否尊重他人注意力与拒绝权，以及安全策略和具体授权是否满足 |

人文效果不以赞美次数、发言数量或每次观看是否产生实用成果衡量。“更先进、更安全、更高效、更有人文”保留为待检验目标。

## 安装与开始

安装后不知道从哪里用、没有看到设置表单时，先看[安装后使用与配置入口](docs/GETTING_STARTED.md)：确认同一 profile 中已启用，先调用 guide/status，再按需编辑该 profile 的配置文件。本插件当前没有独立图形设置页。

需要 Node.js 24+、DSH `0.2.1-rc.2`。发布前需完成离线测试、Windows 桌面内置 CLI 的隔离 tarball 安装与 22 个平台/人格/token 配置场景验收。新增两项视觉工具后，默认 13 个工具，显式关闭人格积累为 12 个，连同四项平台开关全部开启为 17 个。图片附件协议与模型语义理解分别核验，具体结果见[验收记录](docs/ACCEPTANCE.md)。桌面界面安装、独立 npm CLI 和其他 DSH 版本尚未完成验收。

从 [Releases](https://github.com/InariNGT-Ofiicial/dsh-bili-humanism/releases) 下载 `dsh-bili-humanism-1.4.0.tgz` 后：

```sh
dsh plugin --profile web add ./dsh-bili-humanism-1.4.0.tgz
dsh --profile web --dump-config
dsh --profile web
```

桌面版请在内置插件管理器安装同一包并重新加载；该界面安装路径尚未实测。也可将下面的 GitHub 固定标签地址交给 `dsh plugin add`：

```sh
dsh plugin --profile web add github:InariNGT-Ofiicial/dsh-bili-humanism#v1.4.0
```

发布入口是现成的 JavaScript，没有安装构建脚本。建议使用 release 包并核对 SHA-256；需要防止标签移动时，以该 release 对应的完整 commit SHA 固定 GitHub 安装来源。

在 DSH 对话中说：

> 先读取 bili_humanism_guide，再读取这个 BV。告诉我材料覆盖到哪里。若有值得记录的认识，用证据手账写入本地收件箱；如果没有，不必硬写。区分事实、作者观点和你的推测。

用 `bili_humanism_status` 查读取 ID 和任务，用 `bili_humanism_inbox` 看手账；大收件箱先用 action:index，再持同一 snapshot 沿 nextVolume 逐卷读取，不能把最近一段当作全文。数据默认在 `$DSH_HOME/bili-humanism/`，未设置 DSH_HOME 时在 `~/.dsh/bili-humanism/`。`inbox.html` 可以在 DSH 文件预览或浏览器中打开；同目录的 `inbox.md` 是文字版。两者没有外部资源请求。手账默认每天最多两篇（Asia/Shanghai），有新认识才写；同一来源与相同规范化正文的重试复用已有记录。全文与各卷均对照完整索引核验，单卷不超过 24 KiB／350 行，损坏或缺漏明确报错。旧版遗漏导出的条目会从账本恢复，详见[手账分卷与完整性](docs/JOURNALS.md)。

## 已实现与限制

| 路线 / 能力         | 1.4.0 状态                                                                                     |
| ------------------- | ---------------------------------------------------------------------------------------------- |
| A2 官方 AI 文字来源 | 已实现并做过真实接口功能检查；需要本机登录凭据。摘要/提纲不能冒充逐字稿                        |
| A1 字幕轨           | 已实现并做过真实接口功能检查；匿名读取可能没有字幕                                             |
| A3 本地 ASR         | 有预算内的本地 Python 适配器与导入接口；需要自行安装依赖和已有本地模型，未完成真实推理验收     |
| 抽样画面            | 最高 480p 下载、最多 40 帧、四张一页的 DSH 图片附件；需要 Python 依赖及支持图片的模型；无内置 OCR，抽样会漏页 |
| 理解与手账          | 宿主模型按指南整理；程序检查结构、出处时间点，语义准确与人文质量仍需人工审阅                   |
| 记忆                | 可查看、覆盖修正、删除全部对应修订；只允许 AI 自我理解或使用者偏好，不接受第三方人格档案       |
| 任务控制            | SQLite 事务、任务互斥、缓存、结构化去重、取消、进程退出恢复、持久暂停                          |
| 历史 / 收藏写入     | 开关与执行器已实现，离线接口测试覆盖，未做真实账号写入；手动接入现有账号，无自动迁移或接管界面 |
| 点赞 / 投币         | 独立开关、状态回读与预算已实现，离线测试覆盖；真实账号写入未实测                               |
| 人格成长            | 专用 human-world.md、按信笺日期选句、分页、来源追踪与可信本地修订/撤回；默认开启，可显式关闭       |
| 评论 / 其他表达     | 评论、私信、动态、关注、投稿未实现，不由四项写入权限放行                                       |
| 定时 / 私人通知     | 无后台定时任务；交付在本地收件箱，尚无外部私人通知适配器                                       |

`no_subtitles`、`read_failed`、`asr_partial`、`visual_text_partial` 分开记录。空稿的语音状态保持 `unknown`；不根据空文本推断“无语音”。字幕时间跨度只衡量文字片段，不代表完整观影或正确率。缓存有效期 6 小时，以视频、分 P、读取版本与本地登录态摘要分隔；内容去重保留 CID 和文字版本。手动导入的来源保留未独立核实标记。

网络取稿为空时，`read` 会查找同一视频、分 P、CID 和时长下最近保存的非空 A3 记录，返回其已有 ID、ASR 覆盖和未独立核实标记；`reusedLocalSource` 与 `networkSource` 说明本地复用和本次网络/缓存状态。不会用画面文字替代语音文字，也不覆盖当前可用的 A1/A2。旧版可先使用 `import` 返回的来源 ID 调用 `bili_humanism_source`，直接读取已经导入的正文。

音频下载允许 `playurl` 返回的 HTTPS `*.mcdn.bilivideo.cn` 默认端口或 8082，以及原有 `*.bilivideo.com` 默认端口。仅下载已选音轨，不向媒体域名发送 Cookie，不跟随重定向；其他域名、端口、字节与请求额度限制继续生效。本次只做合成接口回归，未实测这些 CDN 的现场可用性。

## 凭据与边界

默认匿名，不扫描浏览器、不自动查找旧账号、不随包携带凭据。需要 A2 时，使用者自己准备本地 JSON，字段 `sessdata`，在宿主插件 config 中设置 `credentialPath`。CLI 使用 `BILI_HUMANISM_CREDENTIAL_FILE` 指向文件，**不要把凭据值放到命令行、对话或 issue**。`disabled: true` 或 `read_valid: false` 会拒绝使用。

宿主配置示例（路径由自己填写，不要提交到公开仓库）：

```yaml
- id: bili-humanism
  name: dsh-bili-humanism
  config:
    dataDir: /your/private/bili-humanism
    credentialPath: /your/private/credential.json
    pythonPath: /your/private/frame-venv/bin/python
    maxSessionTokens: 600000
    enablePersonalityLearning: true
    enableHistoryWrites: false
    enableFavoriteWrites: false
    enableLikeWrites: false
    enableCoinWrites: false
    writePolicyPath: /your/private/write-policy.json
    accountStateDir: /your/private/shared-account-state
```

SESSDATA 是高敏登录凭据，不是平台颁发的只读 token。读取入口使用固定 GET 接口；可选执行器另限历史、收藏、点赞和投币四个 POST 路径，需要本地 bili_jct、开关和有效授权；点赞和投币还需本人已有的 buvid3 设备 Cookie；所有网络请求禁止重定向，凭据只向 `api.bilibili.com` 发送；日志不输出原始错误响应或令牌。受信任宿主代码和系统管理员仍能访问本机文件，不能把插件当成宿主整体的沙箱。字幕与标题是不可信数据，不能作为权限或删除记忆的授权；读取访问也不承诺零平台风险。

HTTP 401/403/412/429，以及已知账号/验证风险码，会记录持久暂停。重启也不自动解除；不会轮换 IP、账号或指纹。确认账号与使用条件后，使用者可在本地 CLI 显式执行：

```sh
bili-humanism resume --acknowledge-account-risk
```

模型工具不提供解除暂停。无自动重试。账本损坏或初始化后的账本丢失会拒绝启动，不悄悄重建一份空账本。

## 成本和本地 CLI

人工设置示例：在 profile 的可信插件 config 中填写 `maxSessionTokens: 1200000`（或更小的正整数），保存后重载。DSH patch 会替换整行 config，修改现有行时须保留其他需要的配置项；本项目不提供可由模型调用的预算设置工具。

每个网络任务最多 12 次请求、3 个候选、90 秒；单个本地 ASR 任务最多 600 秒音频并受总墙钟限制。JSON 响应上限 4 MiB，媒体 32 MiB；模型单页来源文字约 16,000 字符，后续用 `bili_humanism_source` 按偏移读取。

若 DSH 提供 provider usage，插件从首次带计量的调用建立持久化会话基线，默认累计增量超过 600,000 tokens 后拒绝继续读取或改写记录。maxSessionTokens 由人类在可信 config 中设定，允许 1 至 9,007,199,254,740,991 的正安全整数，可显式设高或设低；省略时仍为 600000。修改后重载插件，已有会话消耗基线不清零；调低到已消耗值以下会拒绝后续受限工作，调高仍计入既有消耗。模型工具不能提供上限、重置或 force 参数。旧配置中的 60000 继续生效。它包括同一宿主会话内的其他工作，不能精确归因给本插件；不能截断已发出的模型请求，单次请求可能越过额度。长视频精读可按 bili_humanism_source 的 next_offset 逐页读取，保留分段理解与未读进度；600k 是累计计量额度，不是单次上下文容量或完整观影保证。请求数、候选数、媒体时长、总时长预算仍独立。状态、取消、删除记忆、收件箱和已有来源查看仍可使用。缺计量时显示未知；已有计量突然消失或计数倒退会拒绝继续。CLI 网络任务不调用模型，结果中的 `tokens: null` 表示未取得模型用量，不能按零消耗解释。已在真实账号模型会话中取得宿主计量；超额拒绝逻辑仍以离线测试为依据，不把本次功能验收视作整场对话的费用上限证明。

```sh
node bin/cli.mjs read BVxxxxxxxxxx
node bin/cli.mjs status
node bin/cli.mjs inbox
node bin/cli.mjs journal READING_ID note.json
node bin/cli.mjs memory list
node bin/cli.mjs memory put understanding memory.json
node bin/cli.mjs memory delete understanding
node bin/cli.mjs audio READING_ID
node bin/cli.mjs visual READING_ID
node bin/cli.mjs visual-frames READING_ID 4
node bin/cli.mjs local-asr READING_ID local-audio.m4s /local/model-directory
node bin/cli.mjs local-frames READING_ID local-video.mp4
node bin/cli.mjs import READING_ID segments.json
```

本地媒体适配器需 Python 3.10+。抽帧只需固定版本的 `av` 和 `Pillow`，1.4.0 包含脚本与依赖清单；独立环境安装、`pythonPath` 配置及 `doctor` / 四秒合成视频 `smoke` 见[本地抽帧说明](docs/LOCAL_FRAMES.md)。npm 安装不会自动执行 pip。ASR 另需 `faster-whisper` 与已有本地模型，不自动下载模型。支持图片的模型调用 `bili_humanism_read` 时自动尝试文字与画面；用 `bili_humanism_visual` 可按已有来源单独取图，之后沿 `nextOffset` 调用 `bili_humanism_frames`。普通文本模型明确返回未取得画面。宿主模型阅读图片后可通过导入接口保存画面文字；没有内置 OCR 或视觉权重。抽样不是翻页检测器，教程可能漏页。

上面的 BV 是占位符，请替换为自己选择的视频。仓库只分发通用代码与合成测试夹具；私人手账、案例、观影内容和第三方媒体保存在本地，不进版本控制或发布附件。

## 验收与维护

```sh
npm ci --ignore-scripts
npm run check
npm test
npm pack --ignore-scripts
```

见 [验收记录](docs/ACCEPTANCE.md)、[维护与升级](docs/MAINTENANCE.md)、[数据与安全](docs/SECURITY.md) 和 [贡献指南](CONTRIBUTING.md)。本版通过离线故障测试和真实宿主工具调用，不代表完成 7 天私人运行或 20 个代表视频基准。没有与其他插件运行同环境性能/精度对照；不宣称更快、更准或已经证明更有人文。

v0.1.0 历史记录：2026-10-20 补充真实 API 验收：通过 DSH 官方 stdio JSON-RPC 接口，在 `deepseek-account / deepseek-flash` 真实模型通道完成 3 轮会话、11 次插件工具调用，走通取稿、手账保存、记忆修正与删除、收件箱和状态查询；模型可见工具限制为本插件的 10 个工具。事件回执与本地账本交叉核对通过，没有 B站平台写入。具体视频、手账及完整会话不进入公开仓库；本次也不构成长期稳定性或人文质量基准。

工程格式依据 DeepSeek 官方 [工具开发](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/tool.zh.md)、[插件安装](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.zh.md) 和 [SDK API](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/sdk/README.md)。来源整理见 [NOTICE](NOTICE.md)。MIT License。
