# DG-LAB for DeepSeek Harness

让 DeepSeek Harness 中的 AI 通过工具操作 **DG-LAB** 设备（郊狼 / 负鼠 / 灵猫），
并在 Web GUI 中提供**扫码配对面板**：用 DG-LAB 4 APP 扫描二维码即可把手机接入本机控制方。

## 特性一览

- **10 个 AI 工具**（`dglab_*`）：连接 / 状态 / 设备刷新 / 强度（绝对、相对、临时）/ 波形 / 清理 / 断开
- **扫码配对面板**：二维码 SVG 本地生成，默认左下角、可拖动（位置记忆）
- **电刺激指令确认**：AI 指令弹窗三选一（执行一次 / 永久允许 / 拒绝），偏好按会话记忆
- **跨会话共享连接**：任意会话共用一条 DG-LAB 连接，新会话直接看到已配对设备
- **每次对话自动刷新设备状态**：静默刷新缓存（不注入提示词），AI 用工具查询时总是最新
- **设备中文名与参数**：负鼠 / 郊狼 / 灵猫 类型中文显示，强度步长等参数工具内校验并给出明确错误

## 快速开始

### 一键安装

```bash
dsh plugin --profile web add "github:lindog114514/dsh-dglab#main"
```



### 重启 dsh web

```bash
# 结束当前 dsh web 进程后重新运行：
dsh web
```

### 验证安装

```bash
dsh --profile web --dump-config | findstr dglab   # 输出应包含 dglab 行
```

重启后：聊天输入框左侧出现二维码按钮 → 点开面板 → 「连接」→ 手机 DG-LAB 4 APP 扫码。

## 使用流程

1. 打开控制台面板（输入框左侧二维码按钮），点「连接」。
2. 手机 DG-LAB 4 APP 扫描面板二维码（APP 需已登录并支持 V4 扫码）。
3. APP 接入后，面板 / `dglab_status` 显示设备（slotId、中文类型名、当前强度）。
4. 让 AI 控制（会弹确认框），或面板手动操作（±强度 / 播放波形 / 清除）。

## 联系作者 

QQ群:870333220

## License

MIT（dglab-kit / qrcode-generator 均为 MIT）。