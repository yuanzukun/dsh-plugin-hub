# 重启 dsh web（应用新安装/更新的插件组合）。
# 用法：powershell -ExecutionPolicy Bypass -File scripts/restart-web.ps1
$bin = Join-Path $env:APPDATA 'npm\node_modules\@deepseek-ai\dsh\lib\bin.js'
if (-not (Test-Path $bin)) {
  $bin = Join-Path (Split-Path (Get-Command node).Source -Parent) 'node_modules\@deepseek-ai\dsh\lib\bin.js'
}
Write-Host "dsh bin: $bin"

# 结束现有 dsh web 实例（排除自身与 npx 包装）
Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object {
  $_.CommandLine -like '*@deepseek-ai*dsh*bin.js*web*'
} | ForEach-Object {
  Write-Host "stopping PID $($_.ProcessId): $($_.CommandLine)"
  Stop-Process -Id $_.ProcessId -Force
}
Start-Sleep -Seconds 2

# 重新启动（在当前目录打开新窗口）
Start-Process node -ArgumentList "`"$bin`" web" -WorkingDirectory (Get-Location)
Write-Host "dsh web restarting... 请稍等几秒后刷新 http://127.0.0.1:3080"
