import { DglabSocket, DGLAB_SOCKET_VERSION } from '../lib/vendor/dglab-kit/dist/index.js';

async function tryReconnect(label) {
  const socket = new DglabSocket({ url: 'wss://trex.dungeon-lab.cn/v4', version: DGLAB_SOCKET_VERSION.V4, connectTimeout: 5000, responseTimeout: 5000 });
  socket.on('state', (s, p) => console.log('  [state]', p, '->', s));
  socket.on('error', (e) => console.log('  [error]', e?.message || e));
  try {
    const r1 = await socket.connect();
    console.log(label, 'connect#1 targetId =', r1.targetId);
    socket.disconnect();
    await new Promise((r) => setTimeout(r, 300));
    console.log(label, 'after disconnect state =', socket.state, '| targetId =', socket.targetId);
    const r2 = await socket.connect();
    console.log(label, 'connect#2 targetId =', r2.targetId, '| state =', socket.state);
    socket.disconnect();
    console.log(label, 'OK: reconnect works');
  } catch (e) {
    console.log(label, 'FAIL:', e.message || e);
  }
  console.log('');
}
await tryReconnect('same-socket');
process.exit(0);
