import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
const require = createRequire(import.meta.url);

const pluginPath = require.resolve('dsh-dglab', { paths: ['C:\\Users\\lenovo\\.dsh\\profiles\\web'] });
const mod = await import(pathToFileURL(pluginPath).href);

const routes = [];
const ctx = {
  config: { relayUrl: 'wss://trex.dungeon-lab.cn/v4' },
  effect: (fn) => fn(),
  tools: { register: () => {} },
  webServer: { register: (spec) => routes.push(spec) },
};
mod.apply(ctx);
const handler = routes[0].handler;
console.log('[route]', routes[0].kind, routes[0].path);

// --- fake req/res helpers ---
function makeReq(method, path, body) {
  return {
    method, url: path,
    headers: { host: '127.0.0.1:3080', origin: 'http://127.0.0.1:3080' },
    on: (ev, cb) => { if (ev === 'data' && body) cb(Buffer.from(JSON.stringify(body))); if (ev === 'end') cb(); if (ev === 'error') {} },
  };
}
function makeRes() {
  const out = { status: 0, body: '', headers: null, ended: false, writes: [], closeCbs: [] };
  out.writeHead = (code, headers) => { out.status = code; out.headers = headers; };
  out.end = (b) => { out.body = b || ''; out.ended = true; };
  out.write = (chunk) => { out.writes.push(String(chunk)); };
  out.on = (ev, cb) => { if (ev === 'close') out.closeCbs.push(cb); };
  return out;
}

// 1) idle status
let res = makeRes();
await handler(makeReq('GET', '/api/dglab?session=e2e1'), res);
console.log('[1 idle]', res.status, res.body, '| thresholds=', JSON.stringify(JSON.parse(res.body).pressureThresholds));

// 2) connect (real relay)
res = makeRes();
await handler(makeReq('POST', '/api/dglab/connect', { session: 'e2e1' }), res);
console.log('[2 connect]', res.status, res.body.slice(0, 220));

// 3) status after connect
res = makeRes();
await handler(makeReq('GET', '/api/dglab?session=e2e1'), res);
console.log('[3 status]', res.status, res.body.slice(0, 260));

// 3.5) cross-session sharing: another session sees the SAME connection
res = makeRes();
await handler(makeReq('GET', '/api/dglab?session=another-session'), res);
console.log('[3.5 cross-session status]', res.status, 'state=' + JSON.parse(res.body).state, 'targetId=' + (JSON.parse(res.body).targetId || 'null'));

// 4) SSE stream: should receive a status frame immediately
res = makeRes();
await handler(makeReq('GET', '/api/dglab/events?session=e2e1'), res);
console.log('[4 sse]', res.status, 'writes:', JSON.stringify(res.writes).slice(0, 220));
// trigger a broadcast via second status fetch? state change happens on disconnect
res = makeRes();
await handler(makeReq('POST', '/api/dglab/disconnect', { session: 'e2e1' }), res);
console.log('[5 disconnect]', res.status, res.body);
// close sse
for (const cb of res.closeCbs) cb();

// 6.5) /add fast-path validation: invalid delta rejected quickly, missing session rejected
res = makeRes();
const t0 = Date.now();
await handler(makeReq('POST', '/api/dglab/add', { session: 'e2e1', clientId: 'x', slotId: 'y', channel: 'A', delta: 99999 }), res);
console.log('[7 add invalid delta]', res.status, res.body, '(' + (Date.now() - t0) + 'ms)');

res = makeRes();
await handler(makeReq('POST', '/api/dglab/add', { session: 'e2e1', clientId: 'x', slotId: 'y', channel: 'A', delta: 'abc' }), res);
console.log('[8 add non-numeric]', res.status, res.body);

res = makeRes();
await handler(makeReq('POST', '/api/dglab/add', { session: 'no-such-session' }), res);
console.log('[9 add missing entry]', res.status, res.body);

res = makeRes();
await handler(makeReq('POST', '/api/dglab/intensity', { session: 'e2e1', clientId: 'x', slotId: 'y', channel: 'A', value: 'abc' }), res);
console.log('[10 intensity non-numeric]', res.status, res.body);

// 6.8) confirm route fast paths
res = makeRes();
await handler(makeReq('POST', '/api/dglab/confirm', { id: 'nope', choice: 'once' }), res);
console.log('[11 confirm unknown id]', res.status, res.body);

res = makeRes();
await handler(makeReq('POST', '/api/dglab/confirm', { id: 'cfm-x', choice: 'maybe' }), res);
console.log('[12 confirm unknown id + choice]', res.status, res.body);

// 6.5) pressure thresholds: save + appear in status
res = makeRes();
await handler(makeReq('POST', '/api/dglab/thresholds', { session: 'e2e1', orgasm: 7.9, calm: 2.5 }), res);
console.log('[13 thresholds save]', res.status, res.body);
res = makeRes();
await handler(makeReq('GET', '/api/dglab?session=e2e1'), res);
const st = JSON.parse(res.body);
console.log('[14 thresholds in status]', res.status, JSON.stringify(st.pressureThresholds));
res = makeRes();
await handler(makeReq('POST', '/api/dglab/thresholds', { session: 'e2e1', orgasm: 'abc', calm: 1 }), res);
console.log('[15 thresholds invalid orgasm]', res.status, res.body);

// 6) disconnect removes nothing (socket kept); check state after disconnect
res = makeRes();
await handler(makeReq('GET', '/api/dglab?session=e2e1'), res);
console.log('[6 status after disconnect]', res.status, res.body.slice(0, 200));
process.exit(0);