/**
 * 构建 dsh-dglab 客户端 bundle：把 qrcode-generator（UMD）与 client core
 * 打包进 window.__ModuleLoader__.load({ id: "dsh-dglab", factory }) 工厂。
 * 运行：node scripts/build-client.js
 */
import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const qrSource = readFileSync(join(root, "lib", "vendor", "qrcode", "qrcode.js"), "utf8");
const coreSource = readFileSync(join(root, "src", "client.core.js"), "utf8");

const qrWrapper = `(function () {
  var module = { exports: {} };
  var exports = module.exports;
${qrSource}
  window.__DGLAB_QRCODE__ = module.exports;
})();
`;

const bundle = `window.__ModuleLoader__.load({
  id: "dsh-dglab",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
    let react = require("react");
${qrWrapper}
${coreSource}
    return module.exports;
  }
});
`;

writeFileSync(join(root, "lib", "client.js"), bundle, "utf8");
console.log("built lib/client.js, bytes:", bundle.length);
