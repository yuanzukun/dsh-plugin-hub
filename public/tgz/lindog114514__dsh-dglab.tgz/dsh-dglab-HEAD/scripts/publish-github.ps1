# 初始化 Git 仓库并准备推送到 GitHub
# 用法：powershell -ExecutionPolicy Bypass -File scripts/publish-github.ps1 <GitHub仓库URL>
# 例如：scripts/publish-github.ps1 https://github.com/yourname/dsh-dglab.git

param([Parameter(Mandatory=$true)][string]$RepoUrl)

$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if (Test-Path ".git") { Write-Host "已存在 .git，跳过 init" } else { git init | Out-Null; Write-Host "git init done" }
git add -A
if (git diff --cached --quiet) { Write-Host "无待提交变更" } else { git commit -m "feat: dsh-dglab - DG-LAB 控制插件" | Out-Null; Write-Host "commit done" }
git branch -M main
if (-not (git remote | Select-String "origin")) { git remote add origin $RepoUrl; Write-Host "remote added" } else { Write-Host "remote 已存在" }
Write-Host ""
Write-Host "准备推送，执行：  git push -u origin main"
Write-Host "用户安装命令（用自己的用户名替换）："
Write-Host "  dsh plugin --profile web add "github:用户名/dsh-dglab#main""
