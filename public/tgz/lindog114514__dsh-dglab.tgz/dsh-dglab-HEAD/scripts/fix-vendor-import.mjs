import { readFileSync, writeFileSync } from 'node:fs';
const p = 'C:\\Users\\lenovo\\Desktop\\dglabhml\\dsh-dglab\\lib\\vendor\\dglab-kit\\dist\\index.js';
const text = readFileSync(p, 'utf8');
if (text.includes('import eventemitter3 from "../../eventemitter3/index.js";')) {
  console.log('already patched');
} else if (text.includes('import eventemitter3 from "eventemitter3";')) {
  writeFileSync(p, text.replace('import eventemitter3 from "eventemitter3";', 'import eventemitter3 from "../../eventemitter3/index.js";'));
  console.log('patched, bytes:', text.length);
} else {
  console.log('WARN: import line not found');
}
