import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
const require = createRequire(import.meta.url);

const pluginPath = require.resolve('dsh-dglab', { paths: ['C:\\Users\\lenovo\\.dsh\\profiles\\web'] });
console.log('resolved plugin at:', pluginPath);
const mod = await import(pathToFileURL(pluginPath).href);
console.log('exports:', Object.keys(mod).join(', '));
console.log('name:', mod.name, '| inject:', JSON.stringify(mod.inject), '| Config:', JSON.stringify(mod.Config));

const registered = [];
const routes = [];
const ctx = {
  config: { relayUrl: 'wss://trex.dungeon-lab.cn/v4' },
  effect: (fn) => fn(),
  tools: { register: (t) => registered.push(t.name) },
  webServer: { register: (spec) => routes.push(spec) },
};
mod.apply(ctx);
console.log('tools registered (' + registered.length + '):', registered.join(', '));
console.log('routes registered:', JSON.stringify(routes.map(r => r.kind + ' ' + r.path)));


// ── 电刺激工具守卫：无 SSE 面板连接时应被拒绝（不真实执行） ──
const captured = [];
{
  const ctx2 = {
    config: { relayUrl: 'wss://trex.dungeon-lab.cn/v4' },
    effect: (fn) => fn(),
    tools: { register: (t) => captured.push(t) },
    webServer: { register: () => {} },
  };
  mod.apply(ctx2);
}
const addTool = captured.find((t) => t.name === 'dglab_add_intensity');
const execStub = { agent: { session: { id: 'guard-test-session' } } };
try {
  await addTool.execute({ clientId: 'c1', slotId: 's1', channel: 'A', value: 5 }, execStub);
  console.log('GUARD: FAIL — should have been rejected');
} catch (error) {
  console.log('GUARD: rejected as expected →', error.message.slice(0, 60));
}
const statusTool = captured.find((t) => t.name === 'dglab_status');
const statusDef = await statusTool.execute({}, execStub);
console.log('GUARD: status tool still works → ok =', statusDef.ok);


// ── 设备状态自动刷新钩子：注册存在、返回空文本（不注入提示词）、连接时静默刷新 ──
const contexts = [];
{
  const ctx3 = {
    config: { relayUrl: 'wss://trex.dungeon-lab.cn/v4' },
    effect: (fn) => fn(),
    tools: { register: () => {} },
    webServer: { register: () => {} },
    systemPrompt: { context: (c) => { contexts.push(c); return () => {}; } },
  };
  mod.apply(ctx3);
}
const refreshCtx = contexts.find((c) => c.name === 'dglab-devices-refresh');
if (!refreshCtx) {
  console.log('REFRESH: FAIL — dglab-devices-refresh hook not registered');
} else {
  const before = refreshCtx.text({});
  console.log('REFRESH: registered; text before connect =', JSON.stringify(before));
  console.log('REFRESH: no prompt injection (empty text) =', before === '');
  const connectTool2 = captured.find((t) => t.name === 'dglab_connect');
  const disconnectTool2 = captured.find((t) => t.name === 'dglab_disconnect');
  try {
    const r = await connectTool2.execute({}, execStub);
    const after = refreshCtx.text({});
    console.log('REFRESH: connected; text =', JSON.stringify(after));
    console.log('REFRESH: still empty after connect =', after === '');
    await disconnectTool2.execute({}, execStub);
    console.log('REFRESH: disconnected after test');
  } catch (error) {
    console.log('REFRESH: connect failed →', error.message);
  }
}


// ── 重连测试：断开后重新连接应重建 socket、拿到新 targetId 并进入等待配对 ──
{
  const connectT = captured.find((t) => t.name === 'dglab_connect');
  const disconnectT = captured.find((t) => t.name === 'dglab_disconnect');
  try {
    const c1 = await connectT.execute({}, execStub);
    console.log('RECONNECT: connect#1 targetId =', c1.data.targetId, '| state =', c1.data.state);
    await disconnectT.execute({}, execStub);
    const c2 = await connectT.execute({}, execStub);
    console.log('RECONNECT: connect#2 targetId =', c2.data.targetId, '| state =', c2.data.state);
    const ok = c2.data.targetId && c2.data.targetId !== c1.data.targetId && c2.data.state === 'waiting_for_peer';
    console.log('RECONNECT: rebuilt with new targetId & waiting_for_peer =', ok);
    await disconnectT.execute({}, execStub);
  } catch (error) {
    console.log('RECONNECT: failed →', error.message);
  }
}
