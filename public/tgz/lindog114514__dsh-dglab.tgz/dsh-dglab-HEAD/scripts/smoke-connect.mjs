import { DglabSocket, DGLAB_SOCKET_STATE, DGLAB_SOCKET_VERSION } from '../lib/vendor/dglab-kit/dist/index.js';

const socket = new DglabSocket({ url: 'wss://trex.dungeon-lab.cn/v4', version: DGLAB_SOCKET_VERSION.V4, connectTimeout: 8000, responseTimeout: 8000 });
socket.on('state', (state, prev) => console.log('[state]', prev, '->', state));
socket.on('error', (e) => console.log('[error]', e?.message || e));
try {
  const { targetId } = await socket.connect();
  console.log('[connected] targetId =', targetId);
  const appSocketUrl = 'wss://trex.dungeon-lab.cn/v4/?tid=' + encodeURIComponent(targetId);
  const qrUrl = 'https://dungeon-lab.cn/s/?v=1&action=socket&url=' + encodeURIComponent(appSocketUrl);
  console.log('[qrUrl]', qrUrl);
  console.log('[state]', socket.state);
  await new Promise((r) => setTimeout(r, 1500));
  socket.disconnect();
  console.log('[done] disconnected, state =', socket.state);
  process.exit(0);
} catch (e) {
  console.error('[FAIL]', e);
  process.exit(1);
}
