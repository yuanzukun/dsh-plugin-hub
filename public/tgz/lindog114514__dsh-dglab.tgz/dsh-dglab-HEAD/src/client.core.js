// ─────────────────────────────────────────────────────────────
// dsh-dglab client core（React-free JSX，react.createElement 手写）
// 在 bundle 构建时被包进 window.__ModuleLoader__.load({ id: "dsh-dglab", factory })
// ─────────────────────────────────────────────────────────────

// 二维码编码器由构建脚本在下方注入：window.__DGLAB_QRCODE__
// 共享状态：面板开合 + 最新状态数据 + 错误
let snapshot = { open: false, data: null, error: null, sessionId: null, busy: false, confirmation: null };
const listeners = new Set();
function getSnapshot() { return snapshot; }
function subscribe(listener) { listeners.add(listener); return () => { listeners.delete(listener); }; }
function emit(patch) {
  snapshot = Object.assign({}, snapshot, patch);
  for (const l of listeners) l();
}

const inject = ["slots", "timer"];

const RELAY_DEFAULT = "wss://trex.dungeon-lab.cn/v4";

// 常用内置波形（与 host 端 COYOTE_WAVEFORMS 对齐；服务端会校验）
const WAVEFORMS = [
  ["BUBBLE", "气泡"], ["RHYTHM", "律动"], ["AIR_WAVES", "电波"], ["DANCE", "舞步"],
  ["CLIMB", "攀登"], ["PULSE", "脉冲"], ["BREATHING", "呼吸"], ["TIDE", "潮汐"],
  ["HEARTBEAT", "心跳"], ["RAINFALL", "细雨"], ["EXTRUSTION", "挤压"], ["SHADE", "树荫"],
  ["TEMPO_TAP", "节拍"], ["SIGNAL", "信号"], ["TEASE_1", "挑逗 1"], ["TEASE_2", "挑逗 2"],
];

const STATE_LABEL = {
  idle: "未连接",
  connecting: "连接中…",
  waiting_for_peer: "等待 APP 扫码接入",
  paired: "已配对",
  disconnected: "已断开",
};
const STATE_COLOR = {
  idle: "var(--dsw-alias-label-tertiary, #888)",
  connecting: "var(--dsw-alias-state-info-label, #2b7de9)",
  waiting_for_peer: "var(--dsw-alias-state-warn-label, #b8860b)",
  paired: "var(--dsw-alias-state-success-label, #2e9e5b)",
  disconnected: "var(--dsw-alias-state-danger-label, #d64545)",
};

function apiBase() { return "/api/dglab"; }

async function postJson(path, body) {
  const res = await fetch(apiBase() + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
    cache: "no-store",
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((json && json.error) || "HTTP " + res.status);
  return json;
}

async function fetchStatus(sid) {
  const res = await fetch(apiBase() + "?session=" + encodeURIComponent(sid), { cache: "no-store" });
  if (!res.ok) throw new Error("HTTP " + res.status);
  return res.json();
}

// 二维码 → SVG（qrcode-generator，构建时注入）
function qrSvg(text, size) {
  try {
    const qr = window.__DGLAB_QRCODE__(0, "M");
    qr.addData(text);
    qr.make();
    const count = qr.getModuleCount();
    const margin = 4;
    const cell = size / (count + margin * 2);
    const parts = [];
    for (let r = 0; r < count; r += 1) {
      for (let c = 0; c < count; c += 1) {
        if (qr.isDark(r, c)) {
          const x = (c + margin) * cell, y = (r + margin) * cell;
          parts.push("M" + x + "," + y + "h" + cell + "v" + cell + "h-" + cell + "z");
        }
      }
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' + size + '" height="' + size +
      '" viewBox="0 0 ' + size + " " + size + '" shape-rendering="crispEdges">' +
      '<rect width="' + size + '" height="' + size + '" fill="#ffffff"/>' +
      '<path fill="#111111" d="' + parts.join("") + '"/></svg>';
  } catch (error) {
    return null;
  }
}

// SSE 实时推送
let sse = null;
function openSse(sid) {
  closeSse();
  try {
    sse = new EventSource(apiBase() + "/events?session=" + encodeURIComponent(sid));
    sse.onmessage = (event) => {
      try {
        const frame = JSON.parse(event.data);
        if (frame && frame.t === "status") emit({ data: frame.status, error: null });
        else if (frame && frame.t === "confirm") emit({ confirmation: frame.confirmation, error: null });
      } catch (error) { /* ignore */ }
    };
    sse.onerror = () => { /* EventSource 会自动重连 */ };
  } catch (error) { /* ignore */ }
}
function closeSse() {
  if (sse) { try { sse.close(); } catch (error) { /* ignore */ } sse = null; }
}

// 面板位置：null = 默认左下角；拖拽后记忆 left/top（localStorage）
let panelPos = null;
try {
  const saved = window.localStorage.getItem("dsh-dglab-pos");
  if (saved) {
    const parsed = JSON.parse(saved);
    if (parsed && typeof parsed.left === "number" && typeof parsed.top === "number") panelPos = parsed;
  }
} catch (error) { /* ignore */ }

function bindSession(sid) {
  if (typeof sid !== "string" || sid === "") return;
  if (snapshot.sessionId === sid) return;
  closeSse();
  emit({ sessionId: sid, data: null, error: null });
  refresh(sid);
  openSse(sid);
}

async function refresh(sid) {
  try {
    const data = await fetchStatus(sid);
    emit({ data, error: null });
  } catch (error) {
    emit({ error: error instanceof Error ? error.message : String(error) });
  }
}

async function runAction(sid, path, body) {
  if (snapshot.busy) return;
  emit({ busy: true, error: null });
  try {
    await postJson(path, Object.assign({ session: sid }, body || {}));
    await refresh(sid);
  } catch (error) {
    emit({ error: error instanceof Error ? error.message : String(error) });
  } finally {
    emit({ busy: false });
  }
}

// 用户对 AI 指令确认框的选择：once / always / rejected
async function confirmChoice(id, choice) {
  emit({ busy: true, error: null });
  try {
    await postJson("/confirm", { id, choice });
    emit({ confirmation: null });
    await refresh(snapshot.sessionId);
  } catch (error) {
    emit({ confirmation: null, error: error instanceof Error ? error.message : String(error) });
  } finally {
    emit({ busy: false });
  }
}

// 样式
function ensureStyles() {
  if (document.getElementById("dsh-dglab-styles")) return;
  const style = document.createElement("style");
  style.id = "dsh-dglab-styles";
  style.textContent = [
    ".dsh-dglab-toggle-btn{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;flex:none;border:none;border-radius:8px;background:transparent;color:var(--dsw-alias-label-secondary,#666);cursor:pointer;padding:0;position:relative;}",
    ".dsh-dglab-toggle-btn:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(0,0,0,0.06));}",
    ".dsh-dglab-toggle-btn.is-open{background:var(--dsw-alias-state-warn-tertiary,rgba(255,180,0,0.15));color:var(--dsw-alias-state-warn-label,#b8860b);}",
    ".dsh-dglab-badge{position:absolute;top:-2px;right:-2px;min-width:14px;height:14px;border-radius:7px;background:var(--dsw-alias-state-success-primary,#2e9e5b);color:#fff;font-size:10px;line-height:14px;text-align:center;padding:0 3px;box-sizing:border-box;pointer-events:none;}",
    ".dsh-dglab-panel *{box-sizing:border-box;}",
    ".dsh-dglab-panel::-webkit-scrollbar{width:6px;}",
    ".dsh-dglab-panel::-webkit-scrollbar-thumb{background:var(--dsw-alias-border-l2,rgba(0,0,0,0.15));border-radius:3px;}",
  ].join("\n");
  document.head.appendChild(style);
}

const QR_ICON_PATHS = [
  "M3 3h4v4H3zM9 3h4v4H9zM3 9h4v4H3zM9 9h1v1H9zM12 9h1v1h-1zM9 12h1v1H9zM12 12h1v1h-1zM13 13h1v1h-1zM13 3h1v4h-1zM3 13h4v1H3zM13 13h1v1h-1zM9 14h4v1H9zM14 9h1v4h-1z",
];

function QrIcon(props) {
  const size = props.size || 16;
  return react.createElement("svg", {
    width: size, height: size, viewBox: "0 0 16 16", fill: "currentColor",
    style: { flexShrink: 0, verticalAlign: "-2px" },
  }, QR_ICON_PATHS.map((d, i) => react.createElement("path", { key: i, d: d })));
}

function Panel() {
  const snap = react.useSyncExternalStore(subscribe, getSnapshot);
  const data = snap.data;
  const state = data && data.state ? data.state : "idle";
  const paired = data && Array.isArray(data.clients) ? data.clients.length : 0;
  const stateLabel = STATE_LABEL[state] || state;
  const stateColor = STATE_COLOR[state] || "#888";
  const ref = react.useRef(null);
  const [pos, setPos] = react.useState(panelPos);

  const startDrag = (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const startX = e.clientX, startY = e.clientY;
    const move = (ev) => {
      const left = Math.max(0, Math.min(window.innerWidth - rect.width, rect.left + ev.clientX - startX));
      const top = Math.max(0, Math.min(window.innerHeight - rect.height, rect.top + ev.clientY - startY));
      panelPos = { left, top };
      setPos(panelPos);
    };
    const up = () => {
      document.removeEventListener("mousemove", move);
      document.removeEventListener("mouseup", up);
      try { window.localStorage.setItem("dsh-dglab-pos", JSON.stringify(panelPos)); } catch (error) { /* ignore */ }
    };
    document.addEventListener("mousemove", move);
    document.addEventListener("mouseup", up);
  };

  const header = react.createElement("div", {
    onMouseDown: startDrag,
    style: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px", cursor: "move", userSelect: "none", touchAction: "none" },
  },
    react.createElement("div", { style: { fontSize: "14px", fontWeight: 600, color: "var(--dsw-alias-label-primary, #222)" } },
      "DG-LAB 控制台", " ",
      react.createElement("span", { style: { fontSize: "10px", color: "var(--dsw-alias-label-tertiary, #999)" } }, "⠿ 拖动")),
    react.createElement("button", {
      type: "button", onClick: () => emit({ open: false }),
      style: { border: "none", background: "transparent", cursor: "pointer", color: "var(--dsw-alias-label-tertiary, #888)", fontSize: "16px", lineHeight: "16px", padding: "2px 4px" },
    }, "✕"),
  );

  const statusRow = react.createElement("div", {
    style: { display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px", fontSize: "13px" },
  },
    react.createElement("span", { style: { width: "8px", height: "8px", borderRadius: "4px", background: stateColor, flex: "none" } }),
    react.createElement("span", { style: { color: "var(--dsw-alias-label-primary, #222)" } }, stateLabel),
    paired > 0 ? react.createElement("span", { style: { color: "var(--dsw-alias-label-tertiary, #888)", fontSize: "12px" } }, "· " + paired + " 个 APP 接入") : null,
  );

  const errorRow = snap.error ? react.createElement("div", {
    style: { marginBottom: "8px", fontSize: "12px", color: "var(--dsw-alias-state-danger-label, #d64545)", wordBreak: "break-all" },
  }, snap.error) : null;

  // AI 电刺激指令确认
  const confirmBlock = snap.confirmation ? react.createElement("div", {
    style: {
      border: "1px solid var(--dsw-alias-state-warn-border, rgba(184,134,11,0.5))",
      background: "var(--dsw-alias-state-warn-tertiary, rgba(255,180,0,0.10))",
      borderRadius: "8px", padding: "10px", marginBottom: "8px",
    },
  },
    react.createElement("div", { style: { fontSize: "12px", fontWeight: 600, color: "var(--dsw-alias-state-warn-label, #b8860b)", marginBottom: "4px" } },
      "⚠ AI 请求执行电刺激操作"),
    react.createElement("div", { style: { fontSize: "12px", color: "var(--dsw-alias-label-primary, #222)", wordBreak: "break-all", marginBottom: "8px" } },
      snap.confirmation.detail || ""),
    react.createElement("div", { style: { display: "flex", gap: "6px" } },
      react.createElement("button", {
        type: "button", disabled: snap.busy,
        onClick: () => confirmChoice(snap.confirmation.id, "once"),
        style: Object.assign({ flex: 1 }, buttonStyle(true, snap.busy)),
      }, "执行一次"),
      react.createElement("button", {
        type: "button", disabled: snap.busy,
        onClick: () => confirmChoice(snap.confirmation.id, "always"),
        style: Object.assign({ flex: 1 }, buttonStyle(false, snap.busy)),
      }, "永久允许"),
      react.createElement("button", {
        type: "button", disabled: snap.busy,
        onClick: () => confirmChoice(snap.confirmation.id, "rejected"),
        style: Object.assign({ flex: 1 }, buttonStyle(false, snap.busy)),
      }, "拒绝"),
    ),
  ) : null;

  const body = [];
  if (!data || state === "idle" || state === "disconnected") {
    body.push(react.createElement("div", { key: "empty", style: { color: "var(--dsw-alias-label-tertiary, #888)", fontSize: "12px", marginBottom: "8px" } },
      "尚未连接。点击下方按钮建立连接，然后用 DG-LAB 4 APP 扫描二维码。"));
  }
  if (data && data.qrUrl && (state === "waiting_for_peer" || state === "paired")) {
    const svg = qrSvg(data.qrUrl, 240);
    body.push(react.createElement("div", { key: "qr", style: { display: "flex", flexDirection: "column", alignItems: "center", gap: "6px", marginBottom: "8px" } },
      svg ? react.createElement("div", {
        style: { background: "#fff", borderRadius: "8px", padding: "6px", width: "252px", height: "252px", display: "flex", alignItems: "center", justifyContent: "center" },
        dangerouslySetInnerHTML: { __html: svg },
      }) : null,
      react.createElement("div", { style: { fontSize: "12px", color: "var(--dsw-alias-label-secondary, #555)" } },
        state === "paired" ? "已配对 ✓ 可重新扫码接入更多 APP" : "用 DG-LAB 4 APP 扫描二维码连接"),
      react.createElement("div", {
        style: { fontSize: "10px", color: "var(--dsw-alias-label-tertiary, #999)", wordBreak: "break-all", maxWidth: "300px", textAlign: "center", userSelect: "all" },
      }, data.qrUrl),
    ));
  }
  if (state === "paired" && data.clients.length === 0) {
    body.push(react.createElement("div", { key: "nodev", style: { fontSize: "12px", color: "var(--dsw-alias-label-tertiary, #888)", margin: "4px 0" } },
      "APP 已接入，但没有暴露设备（请确认 APP 中已连接设备）。"));
  }

  // 设备控制
  if (data && Array.isArray(data.clients)) {
    for (const client of data.clients) {
      for (const device of client.devices || []) {
        body.push(react.createElement(DeviceCard, { key: client.clientId + "-" + device.slotId, clientId: client.clientId, device: device, sid: snap.sessionId, busy: snap.busy }));
      }
    }
  }

  const actionRow = react.createElement("div", { key: "actions", style: { display: "flex", gap: "8px", marginTop: "8px" } },
    state === "idle" || state === "disconnected" || state === "connecting"
      ? react.createElement("button", {
        type: "button",
        disabled: snap.busy || state === "connecting",
        onClick: () => runAction(snap.sessionId, "/connect", {}),
        style: buttonStyle(true, snap.busy || state === "connecting"),
      }, state === "connecting" ? "连接中…" : "连接")
      : react.createElement("button", {
        type: "button",
        disabled: snap.busy,
        onClick: () => runAction(snap.sessionId, "/disconnect", {}),
        style: buttonStyle(false, snap.busy),
      }, "断开"),
    react.createElement("button", {
      type: "button",
      disabled: snap.busy,
      onClick: () => refresh(snap.sessionId),
      style: buttonStyle(false, snap.busy),
    }, "刷新"),
  );

  return react.createElement("div", {
    className: "dsh-dglab-panel",
    ref,
    style: {
      position: "fixed",
      left: pos ? pos.left : "12px",
      top: pos ? pos.top : undefined,
      bottom: pos ? undefined : "12px",
      width: "340px", maxHeight: "calc(100vh - 96px)",
      overflowY: "auto", background: "var(--dsw-alias-bg-overlay, #ffffff)", border: "1px solid var(--dsw-alias-border-l2, rgba(0,0,0,0.12))",
      borderRadius: "12px", padding: "12px 14px", boxShadow: "0 8px 30px rgba(0,0,0,0.18)", zIndex: 100,
      fontSize: "13px", lineHeight: "1.5",
    },
  }, [header, statusRow, errorRow, confirmBlock].concat(body).concat([actionRow]));
}

function buttonStyle(primary, disabled) {
  return {
    flex: 1, padding: "6px 0", borderRadius: "8px", cursor: disabled ? "not-allowed" : "pointer",
    fontSize: "13px", opacity: disabled ? 0.5 : 1,
    border: primary ? "none" : "1px solid var(--dsw-alias-border-l2, rgba(0,0,0,0.15))",
    background: primary ? "var(--dsw-alias-interactive-primary, #2b7de9)" : "transparent",
    color: primary ? "#fff" : "var(--dsw-alias-label-secondary, #555)",
  };
}

// 灵猫（气压传感器）设备卡片：实时气压 + 高潮/冷静阈值
function PressureCard(props) {
  const { device, sid, busy } = props;
  const snap = react.useSyncExternalStore(subscribe, getSnapshot);
  const thresholds = (snap.data && snap.data.pressureThresholds) || {};
  const [orgasm, setOrgasm] = react.useState("");
  const [calm, setCalm] = react.useState("");
  const [saved, setSaved] = react.useState(false);
  react.useEffect(() => {
    setOrgasm(thresholds.orgasm != null ? String(thresholds.orgasm) : "");
    setCalm(thresholds.calm != null ? String(thresholds.calm) : "");
  }, [thresholds.orgasm, thresholds.calm]);

  const pressure = Number(device.pressure);
  const pressureLabel = Number.isFinite(pressure) ? pressure.toFixed(2) + " kPa" : "--";

  const save = async () => {
    if (busy) return;
    emit({ busy: true, error: null });
    try {
      await postJson("/thresholds", { session: sid, orgasm: parseFloat(orgasm), calm: parseFloat(calm) });
      setSaved(true);
      setTimeout(() => setSaved(false), 1500);
      await refresh(sid);
    } catch (error) {
      emit({ error: error instanceof Error ? error.message : String(error) });
    } finally {
      emit({ busy: false });
    }
  };

  const inputStyle = {
    width: "72px", background: "var(--dsw-alias-bg-module-platform, #ffffff)",
    color: "var(--dsw-alias-label-primary, #111111)",
    border: "1px solid var(--dsw-alias-border-l2, rgba(0,0,0,0.15))",
    borderRadius: "6px", fontSize: "12px", padding: "3px 6px", flex: "none",
  };

  return react.createElement("div", {
    style: { border: "1px solid var(--dsw-alias-border-l1, rgba(0,0,0,0.08))", borderRadius: "8px", padding: "10px", marginTop: "8px", background: "var(--dsw-alias-bg-module-platform, rgba(0,0,0,0.02))" },
  },
    react.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "6px" } },
      react.createElement("span", { style: { fontWeight: 600, color: "var(--dsw-alias-label-primary, #222)" } }, device.name || device.slotId),
      react.createElement("span", { style: { fontSize: "11px", color: "var(--dsw-alias-label-tertiary, #888)" } }, (device.typeLabel || device.type || "未知设备") + " · " + String(device.slotId || "")),
    ),
    react.createElement("div", { style: { display: "flex", alignItems: "baseline", gap: "8px", marginTop: "8px" } },
      react.createElement("span", { style: { fontSize: "12px", color: "var(--dsw-alias-label-secondary, #555)" } }, "实时气压"),
      react.createElement("span", {
        style: { fontSize: "26px", fontWeight: 700, color: "var(--dsw-alias-state-info-label, #2b7de9)", fontVariantNumeric: "tabular-nums" },
      }, pressureLabel),
    ),
    react.createElement("div", { style: { display: "flex", alignItems: "center", gap: "6px", marginTop: "10px" } },
      react.createElement("span", { style: { fontSize: "11px", color: "var(--dsw-alias-label-tertiary, #888)", flex: "none" } }, "高潮气压"),
      react.createElement("input", {
        type: "number", step: "0.01", min: 0, value: orgasm, placeholder: "kPa",
        onChange: (e) => setOrgasm(e.target.value), style: inputStyle,
      }),
      react.createElement("span", { style: { fontSize: "11px", color: "var(--dsw-alias-label-tertiary, #888)", flex: "none" } }, "冷静气压"),
      react.createElement("input", {
        type: "number", step: "0.01", min: 0, value: calm, placeholder: "kPa",
        onChange: (e) => setCalm(e.target.value), style: inputStyle,
      }),
      react.createElement("button", {
        type: "button", disabled: busy,
        onClick: save,
        style: {
          border: "1px solid var(--dsw-alias-border-l2, rgba(0,0,0,0.15))", background: "transparent",
          color: saved ? "var(--dsw-alias-state-success-label, #2e9e5b)" : "var(--dsw-alias-label-secondary, #555)",
          borderRadius: "6px", cursor: busy ? "not-allowed" : "pointer",
          fontSize: "11px", padding: "3px 12px", opacity: busy ? 0.5 : 1, flex: "none", marginLeft: "auto",
        },
      }, saved ? "已保存 ✓" : "保存"),
    ),
  );
}

function DeviceCard(props) {
  const { clientId, device, sid, busy } = props;
  const [wave, setWave] = react.useState("BUBBLE");
  const [duration, setDuration] = react.useState(5000);
  const strengths = (device && device.strengths) || {};
  const strengthOf = (ch) => {
    const n = Number(strengths[ch]);
    return Number.isFinite(n) ? String(n) : "--";
  };

  if (device.type === "BMTR_1") {
    return react.createElement(PressureCard, { device: device, sid: sid, busy: busy });
  }

  const stepBtn = (ch, delta) => react.createElement("button", {
    type: "button", key: "d" + delta, disabled: busy,
    onClick: () => runAction(sid, "/add", { clientId, slotId: device.slotId, channel: ch, delta }),
    title: (delta > 0 ? "增加 " : "降低 ") + Math.abs(delta),
    style: {
      minWidth: "30px", border: "1px solid var(--dsw-alias-border-l2, rgba(0,0,0,0.15))",
      background: "transparent", color: "var(--dsw-alias-label-secondary, #555)",
      borderRadius: "6px", cursor: busy ? "not-allowed" : "pointer",
      fontSize: "12px", padding: "2px 0", opacity: busy ? 0.5 : 1,
    },
  }, delta > 0 ? "+" + delta : String(delta));

  const channelRow = (ch) => react.createElement("div", {
    key: ch, style: { display: "flex", alignItems: "center", gap: "6px", marginTop: "6px" },
  },
    react.createElement("span", { style: { width: "14px", fontSize: "11px", color: "var(--dsw-alias-label-tertiary, #888)", flex: "none" } }, ch),
    [-10, -1, 1, 10].map((delta) => stepBtn(ch, delta)),
    react.createElement("span", { style: { fontSize: "11px", color: "var(--dsw-alias-label-tertiary, #888)", marginLeft: "auto" } },
      "强度 " + strengthOf(ch)),
    react.createElement("button", {
      type: "button", disabled: busy,
      onClick: () => runAction(sid, "/clear", { clientId, slotId: device.slotId, channel: ch }),
      style: {
        border: "1px solid var(--dsw-alias-border-l2, rgba(0,0,0,0.15))", background: "transparent",
        color: "var(--dsw-alias-label-secondary, #555)", borderRadius: "6px", cursor: busy ? "not-allowed" : "pointer",
        fontSize: "11px", padding: "2px 8px", opacity: busy ? 0.5 : 1, flex: "none",
      },
    }, "清除"),
  );

  const fieldStyle = {
    background: "var(--dsw-alias-bg-module-platform, #ffffff)",
    color: "var(--dsw-alias-label-primary, #111111)",
    border: "1px solid var(--dsw-alias-border-l2, rgba(0,0,0,0.15))",
    borderRadius: "6px", fontSize: "12px", padding: "3px 4px",
  };

  const waveformRow = react.createElement("div", { key: "wave", style: { display: "flex", alignItems: "center", gap: "6px", marginTop: "8px" } },
    react.createElement("select", {
      value: wave, onChange: (e) => setWave(e.target.value),
      style: Object.assign({ flex: 1, minWidth: 0 }, fieldStyle),
    }, WAVEFORMS.map(([name, label]) => react.createElement("option", {
      key: name, value: name, style: { color: "#111111", background: "#ffffff" },
    }, label + " (" + name + ")"))),
    react.createElement("input", {
      type: "number", min: 200, step: 100, value: duration,
      onChange: (e) => setDuration(Number(e.target.value)),
      title: "时长 ms",
      style: Object.assign({ width: "64px", flex: "none" }, fieldStyle),
    }),
    react.createElement("button", {
      type: "button", disabled: busy,
      onClick: () => runAction(sid, "/waveform", { clientId, slotId: device.slotId, channel: "A", waveform: wave, duration }),
      style: {
        border: "1px solid var(--dsw-alias-border-l2, rgba(0,0,0,0.15))", background: "transparent",
        color: "var(--dsw-alias-label-secondary, #555)", borderRadius: "6px", cursor: busy ? "not-allowed" : "pointer",
        fontSize: "11px", padding: "2px 10px", opacity: busy ? 0.5 : 1, flex: "none",
      },
    }, "播放"),
  );

  return react.createElement("div", {
    style: { border: "1px solid var(--dsw-alias-border-l1, rgba(0,0,0,0.08))", borderRadius: "8px", padding: "8px 10px", marginTop: "8px", background: "var(--dsw-alias-bg-module-platform, rgba(0,0,0,0.02))" },
  },
    react.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "6px" } },
      react.createElement("span", { style: { fontWeight: 600, color: "var(--dsw-alias-label-primary, #222)" } }, device.name || device.slotId),
      react.createElement("span", { style: { fontSize: "11px", color: "var(--dsw-alias-label-tertiary, #888)" } }, (device.typeLabel || device.type || "未知设备") + " · " + String(device.slotId || "")),
    ),
    react.createElement("div", { style: { fontSize: "11px", color: "var(--dsw-alias-label-tertiary, #888)", marginTop: "2px" } },
      "按钮为相对增减（V4 协议），右侧显示各通道当前强度"),
    channelRow("A"),
    channelRow("B"),
    waveformRow,
  );
}

function apply(ctx) {
  ensureStyles();
  const slots = ctx.get("slots");
  if (slots === undefined) return;
  slots.inject("conversation.input.left", () => slots.register(
    { name: "conversation.input.left", id: "dsh-dglab-toggle" },
    (props) => {
      const snap = react.useSyncExternalStore(subscribe, getSnapshot);
      const useSessions = props && typeof props.useSessions === "function" ? props.useSessions : null;
      const current = useSessions ? useSessions((s) => s && s.current) : undefined;
      const sid = (props && props.sessionId) || current;
      react.useEffect(() => {
        if (snap.open) bindSession(sid);
      }, [snap.open, sid]);
      return react.createElement("div", { style: { display: "inline-flex", alignItems: "center" } },
        react.createElement("button", {
          type: "button",
          className: "dsh-dglab-toggle-btn" + (snap.open ? " is-open" : ""),
          title: "DG-LAB 控制台",
          onClick: () => emit({ open: !snap.open }),
        },
          react.createElement(QrIcon, { size: 16 }),
          snap.data && snap.data.clients && snap.data.clients.length > 0
            ? react.createElement("span", { className: "dsh-dglab-badge" }, String(snap.data.clients.length))
            : null,
        ),
        snap.open ? react.createElement(Panel, {}) : null,
      );
    },
  ));
}

exports.apply = apply;
exports.inject = inject;