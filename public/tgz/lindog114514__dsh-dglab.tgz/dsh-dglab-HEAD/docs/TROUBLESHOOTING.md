# 常见问题排查

## 强度调整报错

| 错误 | 原因 | 解决 |
| --- | --- | --- |
| value_must_be_multiple_of_10 | 负鼠设备强度步长为 10 | 改用 ±10 的倍数（工具会自动校验；UI 按钮固定 ±10/±1） |
| 无法读取当前强度（intensityA/B 或 strength） | 设备未上报当前强度 | 先调用 dglab_devices 刷新，或改用 dglab_add_intensity 相对增减 |
| socket-response-timeout | APP 未在 8 秒内响应 | 确认手机 APP 在线、设备连接正常；波形长任务会阻塞等待 |
| 用户拒绝执行该电刺激操作 | 确认框被拒 / 超时 / 无面板 | 打开面板后重试，或选择「永久允许」 |

## 连接问题

- **扫码无反应**：确认 DG-LAB 4 APP 已登录并支持 V4 扫码；二维码在等待配对状态才有效。
- **controller_not_found**：二维码过期（控制方空闲超时或被断开），重新连接生成新二维码。
- **面板显示未连接但之前已配对**：进程重启后共享连接丢失，需要重新 dglab_connect / 面板「连接」。
- **断开后点「连接」无反应、无法回到二维码界面**：已修复——断开后的 socket 无法复用（dglab-kit 会直接返回旧 targetId 而不重连），插件现在会在重连时重建 socket，拿到**新的 targetId 与二维码**。若仍异常，重启插件后重试。
- **新会话看不到设备**：连接是跨会话共享的；若进程重启过，任何会话都需重新连接。

## UI 问题

- **波形下拉文字看不清**：已强制 option 白底黑字；若仍异常，清浏览器缓存后刷新。
- **面板位置不理想**：直接拖标题栏即可；位置存 localStorage，删 dsh-dglab-pos 恢复默认左下角。
- **面板没出现按钮**：conversation.input.left 插槽由官方 UI 提供；确认插件已加载（重启后）。

## 修改代码后不生效

- host 代码（lib/index.js）与 client bundle 都在**启动时加载**，改动后必须重启 dsh web：
  powershell -ExecutionPolicy Bypass -File scripts/restart-web.ps1
- client 源码改动后先 node scripts/build-client.js 再重启。

## 测试 / 验证

```bash
dsh --profile web --dump-config | findstr dglab   # 组合配置包含 dglab 行
curl "http://127.0.0.1:3080/api/dglab?session=test"  # 状态路由 200
node scripts/module-test.mjs                       # 模块自检
node scripts/e2e-http.mjs                          # 端到端路由测试
```

## 安全提醒

- 电刺激为敏感操作：AI 指令经确认框拦截；面板手动操作请自行把握强度。
- 强度调整后需播放波形才实际输出；初次测试建议低强度 + 短时长。
- 「永久允许」会让该会话跳过确认，请确认你信任当前会话的任务。