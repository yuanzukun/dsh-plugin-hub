# 开发指南

## 目录结构

```
dsh-dglab/
├── package.json            # 插件包元数据（dsh.bundle.patch / dsh.client）
├── cordis.patch.yml        # 组合补丁：挂载 dglab 行
├── README.md               # 入口文档
├── docs/                   # 详细文档
├── lib/
│   ├── index.js            # host 半（工具 + 路由 + 共享连接 + 确认机制）
│   ├── client.js           # client 半 bundle（构建产物，勿手改）
│   └── vendor/             # vendored 依赖（dglab-kit / eventemitter3 / qrcode）
├── src/
│   └── client.core.js      # client 源码（构建时合并 qrcode-generator）
└── scripts/
    ├── build-client.js     # 构建 lib/client.js
    ├── module-test.mjs     # 模块加载 + 工具/路由/守卫/刷新钩子自检
    ├── e2e-http.mjs        # 端到端 HTTP 路由测试（真实连接中继）
    ├── smoke-connect.mjs   # 最小连接冒烟测试
    └── restart-web.ps1     # 重启 dsh web
```

## 构建

```bash
node scripts/build-client.js   # 重新生成 lib/client.js（qrcode-generator + client.core）
```

## 测试

```bash
node scripts/module-test.mjs   # 10 工具注册 / 路由 / 守卫拒绝 / 刷新钩子
node scripts/e2e-http.mjs      # 状态 / 连接 / SSE / 确认路由 / 参数校验 / 跨会话共享
node scripts/smoke-connect.mjs # 真实中继连接冒烟
```

## Vendored 依赖

- lib/vendor/dglab-kit：dglab-kit 1.0.3 发行 dist（npm pack dglab-kit@1.0.3 提取）。使用 Node 22+ 全局 WebSocket，仅依赖 eventemitter3。
- node_modules/eventemitter3（插件内）：dglab-kit dist 的裸导入解析目标。
- lib/vendor/qrcode/qrcode.js：qrcode-generator 2.0.4（UMD），构建时注入 client bundle，用于本地 SVG 二维码。

## Host / Client 双端说明

### Host 半（lib/index.js）

- 导出 name / inject（webServer, tools, systemPrompt）/ apply(ctx, config)。
- 模块级状态：sharedEntry（共享连接）、ALLOW_ALWAYS（会话确认偏好）、pendingConfirmations。
- apply 注册：10 个工具、/api/dglab prefix 路由、systemPrompt.context 静默刷新钩子。
- 配置（cordis.patch.yml 的 dglab 行 config）：relayUrl 可覆盖默认中继。

### Client 半（lib/client.js）

- 格式：window.__ModuleLoader__.load({ id: "dsh-dglab", factory })，factory 内 require("react")。
- inject：["slots", "timer"]；注册 conversation.input.left 插槽按钮。
- 模块级共享状态 + useSyncExternalStore；面板/按钮/确认框共用。
- 与 host 通信：fetch /api/dglab/* + EventSource /api/dglab/events。

## 发布 / 安装

```bash
dsh plugin --profile web add "C:\path\to\dsh-dglab"   # pnpm link 到 profile
# 组合配置验证：
dsh --profile web --dump-config | findstr dglab
# 重启：
powershell -ExecutionPolicy Bypass -File scripts/restart-web.ps1
```

## 修改流程建议

1. 改 src/client.core.js 后运行 node scripts/build-client.js。
2. 改 lib/index.js 后运行 node --check lib/index.js + 两个测试脚本。
3. 本地验证：dsh --profile web --dump-config 确认组合；重启后打开面板实测。
4. 临时实例验证（不打扰现有实例）：node <dsh bin> web --port 3090，验证后关闭。