# V4 协议要点与限制

（完整协议见 dglab-kit README 的「V4 协议参考」章节与官方协议仓库。）

## 连接模型

- 控制方连接中继：wss://trex.dungeon-lab.cn/v4 → 服务器返回 hello，clientId 即控制方 targetId。
- APP 被控方通过 wss://.../v4?tid=<targetId> 接入（二维码内容）。
- 接入后 APP 上报 devices.snapshot，之后 devices.patch / slots.patch 增量。
- 控制方 5 分钟无 APP 接入会收到 idle_timeout 并被断开。

## 消息结构

```json
{ "type": "message", "clientId": "<APP clientId>", "data": { "t": "req", "reqId": "...", "m": "device.op", "data": { "s": "slot-a", "t": 7, "c": 0, "p": 1, "v": 0 } } }
```

常用 RPC：devices.get、ping、device.op、device.op.clear。

## 关键限制（本插件适配点）

| 限制 | 说明 |
| --- | --- |
| SetIntensity(t=7) 仅接受 v:0 | 非零绝对值需用 AddIntensity(t=3) 相对增减 |
| AddIntensity(t=3) 的 v 可正可负 | 负鼠步长 10；郊狼 1 起步 |
| SetTempIntensity(t=4) 接受任意 v | 持续任务，结束自动归零 |
| AppendPulseData(t=0) 需要 v 帧 + d 时长 | 每 100ms 消费一帧；hex 帧必须完整字节对 |
| p 优先级默认 1 | 0/1/2 可选，省略按 1 |
| device.op 响应延迟 | 任务完成/被清理/被替换/断开后才响应；长时间任务注意超时 |
| device.op.clear | 清理全部 / 指定设备 / 指定通道 |
| 仅调强度不输出 | 必须播放波形才产生刺激 |

## 错误码示例

| 错误码 | 含义 |
| --- | --- |
| value_must_be_multiple_of_10 | 强度步长不满足（负鼠） |
| invalid_operate | 未注册的任务类型（如 AppendPulse/ClearPulse/SetVar） |
| controller_not_found | APP 接入时 targetId 不存在 |
| socket-response-timeout | 等待 APP 响应超时（默认 8 秒） |

## 与蓝牙层的差异

- 蓝牙层负鼠强度 0-200、B3 指令任意值；V4/APP 层映射为 0-100 且步长 10。
- 郊狼蓝牙层 B0 指令含强度解读方式（相对/绝对）；V4 层拆分为 AddIntensity/SetIntensity 动作。
- 灵猫气压数据（D0）由 APP 透传进 props，本插件探测 pressure 等字段。