# AI 工具 API 完全参考

所有工具名以 `dglab_` 为前缀。强度 / 波形类工具（`guard` 标记）执行前会弹出确认框
（执行一次 / 永久允许 / 拒绝），确认偏好按会话记忆。

> 通用规则：仅调整强度不会产生刺激输出，必须播放波形设备才会正常运作。

## dglab_connect

- 用途：建立到 DG-LAB 中继服务器的连接，获得 `targetId` 与配对二维码地址。
- 连接为跨会话共享；已连接时复用。
- 参数：
  - `url`（可选）：WebSocket 中继地址，默认 `wss://trex.dungeon-lab.cn/v4`
- 返回：`{ ok, data: { targetId, qrUrl, state } }`
- 说明：二维码 URL 形如 `https://dungeon-lab.cn/s/?v=1&action=socket&url=...`，用户用 DG-LAB 4 APP 扫描即可接入。

## dglab_status

- 用途：查看当前连接状态（socket 状态、targetId、二维码、已接入 APP 与设备列表）。
- 调用时会异步触发一次设备列表刷新（fire-and-forget），返回当前缓存快照。
- 参数：无。
- 返回：`{ ok, data: { state, targetId, qrUrl, relayUrl, lastError, clients[] } }`
  - `state`：`idle | connecting | waiting_for_peer | paired | disconnected`
  - `clients[]`：每个 APP 一个，含 `clientId`、`devices[]`（`slotId/name/type/typeLabel/props/strengths`）
  - `devices[].pressure`：气压传感器（灵猫）当前气压值，单位 kPa；无则 `null`
  - `pressureThresholds`：用户设定的气压阈值 `{ orgasm, calm }`（kPa），跨会话共享，AI 可据此判断状态

## dglab_devices

- 用途：向指定已接入 APP 请求最新设备列表（设备插入/移除后刷新缓存）。
- 参数：`clientId`（必填）。
- 返回：`{ ok, data: { clientId, devices[] } }`。

## dglab_set_intensity

- 用途：将指定设备通道的强度设置为绝对数值（0-100）。`guard` 确认。
- 参数：`clientId`、`slotId`、`channel`（A/B）、`value`（0-100）。
- 行为：`value=0` 走原生 `SetIntensity` 归零；非零值以设备当前上报强度（`intensityA/B` 或 `strength`）
  为基准计算差值，用 `AddIntensity` 相对增减。读不到当前强度时给出明确错误。
- 注意：V4 协议 `SetIntensity(t=7)` 仅接受 0；负鼠设备步长为 10。

## dglab_add_intensity

- 用途：在当前强度基础上相对增减（value 可为负）。`guard` 确认。
- 参数：`clientId`、`slotId`、`channel`（A/B）、`value`（变化量）。
- 校验：必须为数字，建议 |value| ≤ 100；负鼠设备需为 10 的倍数（否则 APP 返回 `value_must_be_multiple_of_10`）。
- 返回：`{ ok, data: { clientId, slotId, channel, confirmed, delta } }`。

## dglab_set_temp_intensity

- 用途：设置临时强度，持续 `duration` 毫秒后自动恢复（归零）。`guard` 确认。
- 参数：`clientId`、`slotId`、`channel`、`value`（0-100）、`duration`（毫秒）。
- 注意：临时强度任务本身可能不产生输出，配合波形播放更可靠。

## dglab_send_waveform

- 用途：向指定设备通道下发波形（内置波形名或原始帧），持续 `duration` 毫秒。`guard` 确认。
- 参数：`clientId`、`slotId`、`channel`、`waveform`（内置名，与 `frames` 二选一）、`frames`（原始十六进制帧数组）、`duration`（毫秒）。
- 说明：**播放波形是让设备实际产生刺激输出的必要步骤**；帧每 100ms 消费一帧。

## dglab_waveforms

- 用途：列出内置波形目录（名称 + 中文/英文标签），供 `dglab_send_waveform` 使用。
- 参数：无。返回 `{ ok, data: { waveforms[] } }`。

## dglab_clear

- 用途：清理任务。传 `slotId+channel` 清理指定通道；不传 `slotId` 清理该 APP 全部任务。
- 参数：`clientId`（必填）、`slotId`（可选）、`channel`（可选，配合 slotId）。

## dglab_disconnect

- 用途：断开共享连接（所有会话回到未连接）。
- 参数：无。

## 返回值统一结构

所有工具返回 `{ ok: boolean, data?: object, message?: string }`，失败时抛错（错误信息为中文说明）。
确认被拒绝 / 超时 / 无面板时，强度类工具会抛出包含原因的明确错误。