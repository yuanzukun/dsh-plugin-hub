import { promises as fs } from 'node:fs'
import path from 'node:path'
import os from 'node:os'

export const name = 'dsh-purge'
export const inject = ['commands']

/* ── filesystem helpers ──────────────────────────────────────────────── */

function dshHome() {
  return process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
}
const registryFile = () => path.join(dshHome(), 'storages', 'workspace.json')
const sessionsRoot = () => path.join(dshHome(), 'sessions')

export async function loadRegistryFile() {
  return JSON.parse(await fs.readFile(registryFile(), 'utf8'))
}

export async function saveRegistryFile(data) {
  const target = registryFile()
  const tmp = `${target}.tmp-${process.pid}`
  await fs.writeFile(tmp, JSON.stringify(data, null, 2), 'utf8')
  await fs.rename(tmp, target)
}

/** Every on-disk directory belonging to a session id (normally exactly one). */
export async function sessionDirs(sessionId) {
  const root = sessionsRoot()
  let entries
  try {
    entries = await fs.readdir(root, { withFileTypes: true })
  } catch {
    return []
  }
  const found = []
  for (const entry of entries) {
    if (!entry.isDirectory()) continue
    const candidate = path.join(root, entry.name, sessionId)
    try {
      if ((await fs.stat(candidate)).isDirectory()) found.push(candidate)
    } catch {
      /* not in this bucket */
    }
  }
  return found
}

/** Remove a session's log directory. Returns how many were removed. */
export async function removeSessionFiles(sessionId) {
  const dirs = await sessionDirs(sessionId)
  for (const dir of dirs) await fs.rm(dir, { recursive: true, force: true })
  return dirs.length
}

/**
 * The live WorkspaceRegistry (host service). Prefers the in-memory object so the
 * sidebar updates immediately; falls back to editing the JSON file otherwise.
 */
function liveRegistry(ctx) {
  if (ctx === undefined) return undefined
  for (const serviceName of ['workspace', 'workspaces', 'workspaceRegistry']) {
    try {
      const service = ctx.get(serviceName)
      if (service !== undefined && typeof service.delete === 'function') return service
    } catch {
      /* service absent in this composition */
    }
  }
  return undefined
}

function dropId(list, id) {
  return Array.isArray(list) ? list.filter((item) => item !== id) : []
}

/* ── operations ──────────────────────────────────────────────────────── */

export async function purgeSession(sessionId, ctx) {
  const registry = liveRegistry(ctx)

  if (registry !== undefined) {
    // Archive FIRST and without `stopActivity`: if the session still has running
    // work the registry refuses, and nothing has been deleted yet. Passing
    // stopActivity would silently kill that work, which is not ours to decide.
    await registry.archiveSession(sessionId)
    try {
      await registry.detachSession(sessionId)
    } catch {
      /* session was never attached to a workspace */
    }
    const dirs = await removeSessionFiles(sessionId)
    return { kind: 'session', sessionId, dirs, via: 'registry', live: true }
  }

  const dirs = await removeSessionFiles(sessionId)

  // Fallback: no host service (tests / older builds) — edit the durable store.
  const data = await loadRegistryFile()
  for (const workspace of Object.values(data.tables?.workspaces ?? {})) {
    if (Array.isArray(workspace.sessionIds)) workspace.sessionIds = dropId(workspace.sessionIds, sessionId)
  }
  data.global ??= {}
  data.global.archivedSessionIds = dropId(data.global.archivedSessionIds, sessionId)
  data.global.pinnedSessionIds = dropId(data.global.pinnedSessionIds, sessionId)
  await saveRegistryFile(data)
  return { kind: 'session', sessionId, dirs, via: 'file', live: false }
}

export async function workspaceOfSession(sessionId) {
  const data = await loadRegistryFile()
  for (const [id, workspace] of Object.entries(data.tables?.workspaces ?? {})) {
    if (Array.isArray(workspace.sessionIds) && workspace.sessionIds.includes(sessionId)) {
      return { id, workspace }
    }
  }
  return undefined
}

export async function purgeWorkspace(workspaceId, ctx) {
  const data = await loadRegistryFile()
  const record = data.tables?.workspaces?.[workspaceId]
  if (record === undefined) return { kind: 'workspace', workspaceId, missing: true, sessions: 0, dirs: 0 }

  const sessionIds = Array.isArray(record.sessionIds) ? [...record.sessionIds] : []
  let dirs = 0
  for (const id of sessionIds) dirs += await removeSessionFiles(id)

  const registry = liveRegistry(ctx)
  if (registry !== undefined) {
    await registry.delete(workspaceId)
    return { kind: 'workspace', workspaceId, title: record.title, sessions: sessionIds.length, dirs, via: 'registry', live: true }
  }

  const tables = data.tables ?? {}
  delete tables.workspaces[workspaceId]
  data.tables = tables
  data.global ??= {}
  data.global.workspaceIds = dropId(data.global.workspaceIds, workspaceId)
  data.global.archivedSessionIds = (data.global.archivedSessionIds ?? []).filter((id) => !sessionIds.includes(id))
  data.global.pinnedSessionIds = (data.global.pinnedSessionIds ?? []).filter((id) => !sessionIds.includes(id))
  if (data.global.defaultWorkspaceId === workspaceId) delete data.global.defaultWorkspaceId
  await saveRegistryFile(data)
  return { kind: 'workspace', workspaceId, title: record.title, sessions: sessionIds.length, dirs, via: 'file', live: false }
}

function usage() {
  return [
    '用法：',
    '  /purge session <sessionId>      彻底删除某个会话（日志目录 + 注册记录）',
    '  /purge workspace <workspaceId>  彻底删除某个工作区及其全部会话',
    '  /purge workspace-of <sessionId> 删除该会话所属的工作区',
    '  /purge here                     删除当前会话',
  ].join('\n')
}

/* ── plugin ──────────────────────────────────────────────────────────── */

export function apply(ctx, config = {}) {
  if (config.enabled === false) return

  ctx.effect(() => ctx.commands.register({
    name: 'purge',
    description: '彻底删除会话或工作区（含磁盘文件，不可恢复）',
    input: { hint: 'session <id> | workspace <id> | workspace-of <id> | here' },
    handler: async ({ agent, rawInput }) => {
      const argv = String(rawInput ?? '').trim().split(/\s+/).filter(Boolean)
      const action = (argv[0] ?? '').toLowerCase()
      const currentSession = agent?.session?.id ?? agent?.sessionId

      try {
        if (action === 'session' && argv[1]) {
          const result = await purgeSession(argv[1], ctx)
          return { kind: 'success', text: `已彻底删除会话 ${result.sessionId}（日志目录 ${result.dirs} 个，通道 ${result.via}）` }
        }
        if (action === 'workspace' && argv[1]) {
          const result = await purgeWorkspace(argv[1], ctx)
          if (result.missing) return { kind: 'error', text: `找不到工作区 ${argv[1]}` }
          return { kind: 'success', text: `已彻底删除工作区「${result.title ?? result.workspaceId}」，连带 ${result.sessions} 个会话、${result.dirs} 个日志目录（通道 ${result.via}）` }
        }
        if (action === 'workspace-of' && argv[1]) {
          const owner = await workspaceOfSession(argv[1])
          if (owner === undefined) return { kind: 'error', text: `会话 ${argv[1]} 没有归属的工作区` }
          const result = await purgeWorkspace(owner.id, ctx)
          return { kind: 'success', text: `已彻底删除工作区「${result.title ?? owner.id}」，连带 ${result.sessions} 个会话、${result.dirs} 个日志目录（通道 ${result.via}）` }
        }
        if (action === 'here') {
          if (!currentSession) return { kind: 'error', text: '当前没有可删除的会话' }
          const result = await purgeSession(currentSession, ctx)
          return { kind: 'success', text: `当前会话已彻底删除（日志目录 ${result.dirs} 个，通道 ${result.via}）` }
        }
        return { kind: 'error', text: usage() }
      } catch (error) {
        return { kind: 'error', text: `删除失败：${error?.message ?? String(error)}` }
      }
    },
  }), 'dsh-purge: /purge command')
}
