# Changelog

## 1.0.1

- 移除 README 中指向不存在截图的占位图片（npm 页面不再显示破图）
- 不再打包 docs/ 下的内部说明文件

## 1.0.0

首个公开版本。

- 会话行「⋯」菜单新增「彻底删除会话」「彻底删除所在工作区」
- 新增 `/purge` 命令：`session` / `workspace` / `workspace-of` / `here`
- 工作区删除走宿主 `WorkspaceRegistry.delete()`，侧栏即时更新
- 会话删除：删日志目录 + `detachSession` + `archiveSession` 隐藏（核心无删除会话 API）
- 删除前检查活动工作，有任务在跑时拒绝执行、不删任何文件
- 自绘对话框：显示目标名称、Esc 关闭、进度与失败原因可见
- 删除会话不再刷新页面；仅删除工作区时刷新一次以清理陈旧选中状态
