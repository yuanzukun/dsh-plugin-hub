# dsh-purge · 彻底删除（会话 / 工作区）

> 真正把 DSH 的会话和工作区从磁盘上删掉，而不是只取消注册。
>
> `npm i @manbaout-08/dsh-purge` · MIT · 支持 DSH 0.2.x（web / desktop）

DSH 内置的删除是「取消注册」，不是真删：删掉工作区后会话会掉进「未分组」，会话本身则**根本没有删除入口**（核心设计：会话只能归档）。

这个插件补上真删能力。

## 入口

**会话行「⋯」菜单**（排在「复制 Session ID」下面，带分隔线）：

| 菜单项 | 行为 |
|---|---|
| 彻底删除会话 | 删除该会话的磁盘日志目录 + 从工作区摘除 + 归档隐藏（见下方说明） |
| 彻底删除所在工作区 | 删除该工作区名下所有会话的日志目录 + 通过 Registry 删除工作区注册，侧栏即时消失 |

**斜杠命令**：

```
/purge session <sessionId>        删单个会话
/purge workspace <workspaceId>    删工作区及其全部会话
/purge workspace-of <sessionId>   删该会话所属的工作区
/purge here                       删当前会话
```

## 行为说明

- **工作区**：走宿主内存里的 `WorkspaceRegistry.delete()`，内存与 `workspace.json` 一起更新，不需要刷新页面，也不会留下「未分组」残渣。
- **会话**：核心没有删除会话的 API，sessions 服务的内存目录无法移除。所以实际做法是「删日志文件 → detach → archive」：文件真没了，行从主视图消失，仅「已归档会话」里可能残留一个打不开的幽灵条目，重启 DSH 后彻底消失。
- **只动会话日志与注册记录**，工作区对应的磁盘目录（你的工程文件）永远不碰。
- 删除不可撤销，没有回收站。

## 开关

三选一：

1. `cordis.patch.yml` 里把 `enabled: true` 改成 `false`
2. 插件管理器里禁用 `dsh-purge`
3. 删掉 `node_modules/dsh-purge` 与 patch 里的对应段落

## 安装位置

```
源码     <workspace>\purge-plugin\
已安装   %USERPROFILE%\.dsh\profiles\desktop\node_modules\dsh-purge\
配置     %USERPROFILE%\.dsh\profiles\desktop\cordis.patch.yml
```

改源码后复制到已安装目录，**重启 DSH** 生效（客户端模块不热替换）。

## 结构

```
index.js           宿主：删除引擎 + /purge 命令
client.js          浏览器：菜单项 + 自绘对话框
cordis.patch.yml   插件注册行
locale/{zh,en}.json 插件管理器里显示的名称与简介
icon.svg           图标
test.mjs           删除引擎单元测试（node test.mjs）
```

## 已知限制

- 工作区行的「⋯」菜单无法扩展（侧栏只暴露会话级 slot），所以「删工作区」入口挂在会话菜单里。
- 会话删除后，其 id 可能短暂残留在归档集合中，重启后清空。
