﻿import { promises as fs } from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import assert from 'node:assert/strict'

const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'dsh-purge-test-'))
process.env.DSH_HOME = tmp

const { purgeSession, purgeWorkspace, loadRegistryFile, sessionDirs } = await import('./index.js')

const sessA = 'session-aaaa'
const sessB = 'session-bbbb'
const sessC = 'session-cccc'

async function makeSession(bucket, id) {
  const dir = path.join(tmp, 'sessions', bucket, id)
  await fs.mkdir(dir, { recursive: true })
  await fs.writeFile(path.join(dir, 'session.v4.jsonl.zstd'), 'x')
  return dir
}

await makeSession('--w-a--', sessA)
await makeSession('--w-a--', sessB)
await makeSession('--w-c--', sessC)

await fs.mkdir(path.join(tmp, 'storages'), { recursive: true })
await fs.writeFile(path.join(tmp, 'storages', 'workspace.json'), JSON.stringify({
  unit: { name: 'workspace', version: 2 },
  global: {
    initialized: true,
    defaultWorkspaceId: 'w-a',
    workspaceIds: ['w-a', 'w-c'],
    archivedSessionIds: [sessA, sessC],
    pinnedSessionIds: [sessB],
  },
  tables: {
    workspaces: {
      'w-a': { path: 'C:\\x', title: 'A', sessionIds: [sessA, sessB], createdAt: '', updatedAt: '' },
      'w-c': { path: 'C:\\y', title: 'C', sessionIds: [sessC], createdAt: '', updatedAt: '' },
    },
  },
}), 'utf8')

// 1) session purge removes the log dir and every registry reference
const r1 = await purgeSession(sessA)
assert.equal(r1.dirs, 1, 'one log dir removed')
assert.equal((await sessionDirs(sessA)).length, 0, 'dir gone')
let reg = await loadRegistryFile()
assert.deepEqual(reg.tables.workspaces['w-a'].sessionIds, [sessB], 'removed from workspace membership')
assert.deepEqual(reg.global.archivedSessionIds, [sessC], 'removed from archived')
assert.deepEqual(reg.global.pinnedSessionIds, [sessB], 'pinned untouched')

// 2) workspace purge removes every owned session and the registration
const r2 = await purgeWorkspace('w-a')
assert.equal(r2.sessions, 1, 'one remaining session in w-a')
assert.equal(r2.dirs, 1, 'its log dir removed')
assert.equal((await sessionDirs(sessB)).length, 0, 'w-a session dir gone')
reg = await loadRegistryFile()
assert.equal(reg.tables.workspaces['w-a'], undefined, 'workspace row removed')
assert.deepEqual(reg.global.workspaceIds, ['w-c'], 'removed from workspaceIds')
assert.equal(reg.global.defaultWorkspaceId, undefined, 'default pointer cleared')
assert.deepEqual(reg.global.pinnedSessionIds, [], 'pinned cleared of owned session')
assert.deepEqual(reg.tables.workspaces['w-c'].sessionIds, [sessC], 'other workspace intact')
assert.equal((await sessionDirs(sessC)).length, 1, 'unrelated session file kept')

// 3) purging a missing workspace is a no-op, not a crash
const r3 = await purgeWorkspace('nope')
assert.equal(r3.missing, true)

await fs.rm(tmp, { recursive: true, force: true })
console.log('ALL PASS')
