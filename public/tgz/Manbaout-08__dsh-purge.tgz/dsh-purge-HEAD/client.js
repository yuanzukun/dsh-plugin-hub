/**
 * dsh-purge — browser half.
 *
 * Two rows in the session row "..." menu. Each one:
 *   1. opens a styled in-page dialog (no window.confirm),
 *   2. runs `/purge session <id>` or `/purge workspace-of <id>` through the
 *      Client command bridge, so the Host performs the real deletion,
 *   3. reloads the page on success so the sidebar drops the stale row,
 *      and shows the Host's own error text on failure.
 */
window.__ModuleLoader__.load({
  id: 'dsh-purge',
  factory: (require) => {
    var react = require('react')
    var h = react.createElement
    var exports = {}

    var MenuItemButton = null
    try {
      MenuItemButton = require('@deepseek-ai/dsh-client-ui-primitives').MenuItemButton
    } catch (_) {
      MenuItemButton = null
    }

    // ── styled dialog (plain DOM, so it outlives the unmounting menu) ──────
    var STYLE_ID = 'dsh-purge-dialog-style'
    var CSS =
      '.__dp_mask{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;' +
      'background:rgba(0,0,0,.45);animation:__dp_fade .12s ease-out}' +
      '@keyframes __dp_fade{from{opacity:0}to{opacity:1}}' +
      '@keyframes __dp_rise{from{opacity:0;transform:translateY(6px) scale(.985)}to{opacity:1;transform:none}}' +
      '.__dp_card{width:340px;max-width:calc(100vw - 48px);border-radius:14px;padding:20px 20px 16px;' +
      'background:var(--dsw-alias-bg-layer-1,#1e1e22);color:var(--dsw-alias-label-primary,#e8e8ea);' +
      'border:1px solid var(--dsw-alias-border-l2,rgba(255,255,255,.12));' +
      'box-shadow:0 18px 48px rgba(0,0,0,.35);animation:__dp_rise .16s ease-out;font-family:inherit}' +
      '.__dp_title{font-size:15px;font-weight:600;line-height:1.4;margin:0 0 8px}' +
      '.__dp_body{font-size:13px;line-height:1.6;color:var(--dsw-alias-label-secondary,#a7a7ad);' +
      'margin:0 0 18px;white-space:pre-wrap;word-break:break-word;max-height:180px;overflow:auto}' +
      '.__dp_actions{display:flex;justify-content:flex-end;gap:8px}' +
      '.__dp_btn{border:1px solid var(--dsw-alias-border-l2,rgba(255,255,255,.14));background:transparent;' +
      'color:inherit;font:inherit;font-size:13px;padding:7px 16px;border-radius:9px;cursor:pointer;' +
      'transition:background .12s,opacity .12s}' +
      '.__dp_btn:hover:not(:disabled){background:rgba(127,127,127,.14)}' +
      '.__dp_btn:disabled{opacity:.55;cursor:default}' +
      '.__dp_danger{border-color:transparent;background:var(--dsw-alias-state-error-primary,#e5484d);color:#fff}' +
      '.__dp_danger:hover:not(:disabled){filter:brightness(1.08)}'

    function ensureStyle() {
      if (document.getElementById(STYLE_ID)) return
      var el = document.createElement('style')
      el.id = STYLE_ID
      el.textContent = CSS
      document.head.appendChild(el)
    }

    /** Modal dialog; resolves true on confirm, false on cancel. */
    function openDialog(options) {
      ensureStyle()
      var mask = document.createElement('div')
      mask.className = '__dp_mask'
      var card = document.createElement('div')
      card.className = '__dp_card'

      var title = document.createElement('div')
      title.className = '__dp_title'
      title.textContent = options.title

      var body = document.createElement('div')
      body.className = '__dp_body'
      body.textContent = options.body || ''

      var actions = document.createElement('div')
      actions.className = '__dp_actions'

      var cancel = document.createElement('button')
      cancel.className = '__dp_btn'
      cancel.type = 'button'
      cancel.textContent = options.cancelText || '取消'

      var confirm = document.createElement('button')
      confirm.className = '__dp_btn' + (options.danger ? ' __dp_danger' : '')
      confirm.type = 'button'
      confirm.textContent = options.confirmText || '确定'

      actions.appendChild(cancel)
      actions.appendChild(confirm)
      card.appendChild(title)
      card.appendChild(body)
      card.appendChild(actions)
      mask.appendChild(card)
      document.body.appendChild(mask)

      var settled = false
      function onKey(event) {
        if (event.key === 'Escape') finish(false)
      }
      function finish(value) {
        if (settled) return
        settled = true
        document.removeEventListener('keydown', onKey)
        mask.remove()
        if (options.onSettle) options.onSettle(value)
      }

      cancel.addEventListener('click', function () { finish(false) })
      confirm.addEventListener('click', function () { finish(true) })
      if (!options.blocking) {
        mask.addEventListener('click', function (event) { if (event.target === mask) finish(false) })
        document.addEventListener('keydown', onKey)
      }

      return { close: function () { finish(false) }, element: mask }
    }

    function infoDialog(title, text) {
      return new Promise(function (resolve) {
        openDialog({
          title: title,
          body: text,
          confirmText: '知道了',
          cancelText: '关闭',
          onSettle: function () { resolve() },
        })
      })
    }

    function confirmDialog(title, text) {
      return new Promise(function (resolve) {
        openDialog({
          title: title,
          body: text,
          confirmText: '彻底删除',
          cancelText: '取消',
          danger: true,
          onSettle: resolve,
        })
      })
    }

    function busyDialog(title, text) {
      return openDialog({
        title: title,
        body: text,
        confirmText: '处理中…',
        cancelText: '请稍候',
        blocking: true,
      })
    }

    // Set in apply(); kept at module scope so the menu rows can call it.
    var executeCommand = null

    async function purge(sessionId, commandLine, titles, targetTitle, refresh) {
      var heading = targetTitle ? titles.confirmTitle + '「' + targetTitle + '」' : titles.confirmTitle
      var confirmed = await confirmDialog(heading, titles.confirmBody)
      if (!confirmed) return
      if (executeCommand === null) {
        await infoDialog('插件未就绪', '客户端命令桥接还没建立，请重启 DSH 后再试。')
        return
      }
      var progress = busyDialog('正在删除…', '正在从磁盘移除，请稍候。')
      try {
        var res = await executeCommand(sessionId, commandLine)
        progress.close()
        if (!res || res.ok !== true) {
          var code = res && res.error ? res.error.code : 'no-response'
          var msg = res && res.error ? res.error.message : '客户端没有收到宿主响应'
          await infoDialog('删除失败', code + '\n' + msg + '\n\n命令：' + commandLine)
          return
        }
        if (res.value === undefined) {
          await infoDialog('命令未被识别', '宿主返回了空结果。\n\n命令：' + commandLine)
          return
        }
        if (res.value.kind === 'error') {
          await infoDialog('删除失败', (res.value.text || '宿主拒绝执行') + '\n\n命令：' + commandLine)
          return
        }
        await infoDialog('已彻底删除', res.value.text || '完成')
        // Only a workspace purge needs the reload: its row is a sidebar group whose
        // selection state a plugin cannot reset. Deleting one session updates the
        // sidebar through the archived-set stream, so reloading would just flash.
        if (refresh === true) window.location.reload()
      } catch (error) {
        progress.close()
        await infoDialog('删除失败', String((error && error.message) || error) + '\n\n命令：' + commandLine)
      }
    }

    function Row(props) {
      var state = react.useState(false)
      var busy = state[0]
      var setBusy = state[1]
      var openState = props.useMenuOpenState
      var menu = openState ? openState() : [false, function () {}]
      var setMenuOpen = menu[1]

      function onSelect() {
        if (busy) return
        setMenuOpen(false)
        setBusy(true)
        purge(props.sessionId, props.commandLine, props.titles, props.title, props.refresh)
          .catch(function () {})
          .then(function () { setBusy(false) })
      }

      var label = busy ? props.label + '…' : props.label
      if (MenuItemButton) {
        return h(MenuItemButton, { separatorBefore: props.separatorBefore, onSelect: onSelect }, label)
      }
      return h(
        'button',
        {
          role: 'menuitem',
          type: 'button',
          onClick: onSelect,
          style: { display: 'block', width: '100%', textAlign: 'left' },
        },
        label,
      )
    }

    function makeRow(config) {
      return function PurgeMenuItem(props) {
        return h(Row, {
          label: config.label,
          commandLine: config.line(props.sessionId),
          titles: config.titles,
          title: props.displayTitle,
          refresh: config.refresh === true,
          separatorBefore: config.separatorBefore,
          sessionId: props.sessionId,
          useMenuOpenState: props.useMenuOpenState,
        })
      }
    }

    var DeleteSession = makeRow({
      label: '彻底删除会话',
      separatorBefore: true,
      line: function (id) { return '/purge session ' + id },
      titles: {
        confirmTitle: '彻底删除这个会话？',
        confirmBody: '会话日志文件与工作区里的注册记录会一并从磁盘删除。\n此操作不可撤销，也不会进回收站。',
      },
    })

    var DeleteWorkspace = makeRow({
      label: '彻底删除所在工作区',
      refresh: true,
      line: function (id) { return '/purge workspace-of ' + id },
      titles: {
        confirmTitle: '彻底删除所在工作区？',
        confirmBody: '这个工作区里的全部会话都会被删除，不只是当前这一个。\n磁盘上的工程目录不受影响，消失的是所有对话记录。\n此操作不可撤销。删除成功后页面会刷新一次。',
      },
    })

    exports.inject = ['slots', 'remote', 'remote.commands']
    exports.apply = function apply(ctx) {
      executeCommand = function (sessionId, line) {
        return ctx.remote.commands.execute(sessionId, line, [])
      }

      function register(id, order, Component) {
        ctx.slots.inject('sidebar.workspaces.session.menu.item', function () {
          return ctx.slots.register(
            { name: 'sidebar.workspaces.session.menu.item', id: id, order: order },
            Component,
          )
        })
      }

      register('dsh-purge.delete-session', 500, DeleteSession)
      register('dsh-purge.delete-workspace', 510, DeleteWorkspace)
    }

    return exports
  },
})
