/**
 * Resident / On-demand / Disabled capability projection policy for the DeepSeek
 * Harness.
 *
 * @module @daweifu/capability-menu (policy plugin)
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { PromptAssembly } from '@deepseek-ai/dsh-system-prompt';
import { type CapabilityKind } from './registry.ts';
import { type McpInput, type McpLocation, type McpUpdateInput, type SkillLocation } from './locations.ts';
/**
 * Canonical policy classes, mirroring the registry's `CapabilityKind`.
 *
 * - `resident`: the capability is on the dsh-native exposure surface — tools in
 *   `assembly.tools` (the request `tools` payload), skills in the
 *   `<available_skills>` catalog — so the model can call/load it single-hop.
 * - `on-demand`: absent from the native surface but discoverable in the
 *   persistent meta registry; the model reaches it via `meta_search` then
 *   `meta_invoke` (catalog-resident, load/execute on demand).
 * - `disabled`: neither resident nor discoverable nor executable.
 */
export type CapabilityClass = 'resident' | 'on-demand' | 'disabled';
/**
 * A single classify rule: an exact name or a `*`-glob pattern.
 * A pattern matches a capability id (`mcp__<server>__<raw>`, a native tool
 * name, or a bare skill name) or a server name (`server:<name>`).
 */
export interface PolicyRule {
    /** Whether the rule is a literal exact name (`*` free) or a glob pattern. */
    readonly wildcard: boolean;
    /** The normalized pattern/literal this rule represents. */
    readonly pattern: string;
    /** When non-empty, this rule only applies to the given capability kind. */
    readonly kind?: CapabilityKind;
    /** When `'server'`, the pattern is matched against the server name only. */
    readonly target: 'id' | 'server';
}
/**
 * Per-kind explicit configuration. `resident`/`on-demand`/`disabled` are
 * ordered lists of exact-name / glob rules. Empty lists mean "nothing
 * explicitly classified", so the default (`resident`) applies.
 */
export interface CapabilitySetConfig {
    /** Explicitly-Resident rule list (exact name or glob). */
    resident?: string[];
    /** Explicitly-On-demand rule list (exact name or glob). */
    'on-demand'?: string[];
    /** Explicitly-Disabled rule list (exact name or glob); wins over everything. */
    disabled?: string[];
}
/** Resident / On-demand / Disabled projection policy configuration. */
export interface Config {
    /** Tool classification: `tools.resident` / `tools.on-demand` / `tools.disabled`. */
    tools?: CapabilitySetConfig;
    /** Skill classification: `skills.resident` / `skills.on-demand` / `skills.disabled`. */
    skills?: CapabilitySetConfig;
    /**
     * Tool names that are ALWAYS kept resident and can never be classified
     * On-demand or Disabled. Default `[meta_search, meta_invoke]`.
     */
    metaTools?: string[];
    /**
     * Patch file holding the MCP server rows the 能力菜单 UI manages. Defaults
     * to the home-level layer (`~/.dsh/cordis.patch.yml`) — the same file as any
     * hand-written `@deepseek-ai/dsh-mcp-client` rows, so both are managed in one
     * place. dsh owns the mounting; this plugin only edits the file.
     */
    patchFile?: string;
    /** Skill root that UI skill registration links into. Defaults to `~/.dsh/skills`. */
    skillsDir?: string;
    /** UI tier moves; defaults beside `patchFile`, outside dsh's watched patch paths. */
    stateFile?: string;
    /** Milliseconds to coalesce tier changes before persisting them. */
    persistDebounceMs?: number;
}
/** Validate and default the policy configuration. */
export declare const Config: z<Config>;
export declare const DEFAULT_META_TOOLS: readonly ["meta_search", "meta_invoke"];
/**
 * Convert a user-facing rule string into a normalized {@link PolicyRule}.
 * - `server:<name>` → server-targeted rule (`target: 'server'`).
 * - `server:<name>:*` → server-targeted glob over that server's tools.
 * - contains `*` → glob (target `id`).
 * - otherwise → literal exact name.
 */
export declare function parseRule(rule: string): PolicyRule;
/** Compile a `*`-glob into a RegExp (escaped, `*` → `.*`). */
export declare function compileGlob(pattern: string): RegExp;
/** A compiled rule set for one capability kind. */
export interface CompiledCapabilityRules {
    readonly resident: readonly PolicyRule[];
    readonly onDemand: readonly PolicyRule[];
    readonly disabled: readonly PolicyRule[];
}
/** Compile a {@link CapabilitySetConfig} into fast-matchable rules. */
export declare function compileSet(set?: CapabilitySetConfig): CompiledCapabilityRules;
/** Candidate fields a rule is matched against. */
export interface MatchTarget {
    /** Capability id: `mcp__<server>__<raw>`, a native tool name, or a bare skill name. */
    readonly id: string;
    /** Model-facing name (for skills it equals the id; for MCP tools the public `mcp__...` name). */
    readonly name: string;
    /** Server name for tools; undefined for skills. */
    readonly server?: string;
    /** Capability kind. */
    readonly kind: CapabilityKind;
    /** Rule kind the candidates belong to (mirrors `kind` for tool/skill rule sets). */
    readonly ruleKind: CapabilityKind;
}
/**
 * Classify a capability against compiled rules. Priority (hit stops the walk):
 * disabled-exact > disabled-wildcard > resident-exact > on-demand-exact >
 * resident-wildcard > on-demand-wildcard > default (resident). `disabled` is a
 * control decision, so it beats an explicit `resident` rule. Within
 * resident/on-demand an exact name beats a wildcard, so the management UI can
 * pin a single capability to a class even when a broader wildcard rule says
 * otherwise (e.g. `tools.resident: ['mcp__gongfeng__*']` must not silently win
 * over an explicit per-tool `on-demand` rule).
 */
export declare function classify(compiled: CompiledCapabilityRules, target: MatchTarget, metaTools?: ReadonlySet<string> | readonly string[]): CapabilityClass;
/**
 * One capability's classification, as surfaced to a management UI.
 * `class` is the machine-facing value; `classLabel` is a human-friendly
 * display that ties the residency strategy to the model-facing relationship.
 */
export interface CapabilityClassification {
    readonly id: string;
    readonly kind: CapabilityKind;
    /** Model-facing name (tool name or skill bare name). */
    readonly name: string;
    /** Server namespace for tools (`built-in` for harness-native tools); undefined for skills. */
    readonly server?: string;
    /** Skill source root label, present only for skills. */
    readonly source?: string;
    /**
     * Agent preset this skill belongs to, present only for skills collected from
     * a preset's standing scope. The management surface uses it to group preset
     * skills and to keep "纳入管理" (which would globalise the skill) off them.
     */
    readonly preset?: string;
    /**
     * The skill's own directory on disk, present only for skills whose provider
     * has one. The 纳入管理 confirmation shows it so the operator sees which
     * directory is about to be linked, not just the root it came from.
     */
    readonly path?: string;
    readonly class: CapabilityClass;
    /** Human-friendly display label for the classification. */
    readonly classLabel: string;
    /** True when this capability is a mandatory meta tool (always Resident). */
    readonly mandatory: boolean;
}
/**
 * The `ctx.capabilityPolicy` service surface.
 */
export interface CapabilityPolicyService {
    /** Classify a tool by its public name (`mcp__<server>__<raw>` or meta tool). */
    classifyTool(name: string): CapabilityClass;
    /** Classify a skill by its bare name. */
    classifySkill(name: string): CapabilityClass;
    /** True when a tool is Resident (or a mandatory meta tool). */
    isResidentTool(name: string): boolean;
    /** True when a skill is Resident. */
    isResidentSkill(name: string): boolean;
    /** True when a tool is Disabled. */
    isDisabledTool(name: string): boolean;
    /** True when a skill is Disabled. */
    isDisabledSkill(name: string): boolean;
    /**
     * True when a capability (by id and `kind`) is Disabled. `kind` disambiguates
     * a bare name shared by a tool and a skill.
     */
    isDisabledCapability(id: string, kind?: CapabilityKind): boolean;
    /** Tool names that are always kept Resident. */
    metaTools(): readonly string[];
    /** Resolve a capability's id to a class; pass `kind` to disambiguate a bare name. */
    classifyCapability(id: string, kind?: CapabilityKind): CapabilityClass;
    /** Rules resident for the registry/other consumers. */
    toolRules(): CompiledCapabilityRules;
    skillRules(): CompiledCapabilityRules;
    /** Current (resolved) policy config. */
    getConfig(): Config;
    /** Replace a subset of the policy config and recompile rules immediately. */
    updateConfig(partial: Partial<Config>): Promise<void>;
    /**
     * Classify every capability currently indexed by `ctx.capability` (the
     * registry sibling). Returns an empty array when the registry is not mounted.
     */
    classifyAll(): readonly CapabilityClassification[];
    /** MCP servers declared in the patch file, in file order. */
    listLocations(): Promise<McpLocation[]>;
    /** Declare a new MCP server. Rejects a duplicate `serverName`. */
    addLocation(input: McpInput): Promise<string>;
    /** Remove a declared MCP server. */
    removeLocation(id: string): Promise<boolean>;
    /** Replace a declared server's connection config (`serverName` is immutable). */
    updateLocation(id: string, input: McpUpdateInput): Promise<boolean>;
    /** Skill entries under the user root, plus project entries the skill index knows about. */
    listSkillLocations(): Promise<SkillLocation[]>;
    /**
     * Register a skill directory by linking it into the user root, or into
     * `<projectRoot>/.dsh/skills` when `projectPath` names a path inside a project
     * (the project root is derived from it the way dsh derives it). Returns the
     * entry path actually written.
     */
    addSkillLocation(dir: string, projectPath?: string): Promise<string>;
    /** Import one public GitHub skill subdirectory into a managed skill root. */
    importSkillFromGitHub(url: string, projectPath?: string): Promise<string>;
    /** Unregister a skill entry; `entryDir` addresses a project entry, omit it for the user root. */
    removeSkillLocation(name: string, entryDir?: string): Promise<boolean>;
    /** Repoint a registered skill entry at a different directory. */
    updateSkillLocation(name: string, dir: string, entryDir?: string): Promise<boolean>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        capabilityPolicy: CapabilityPolicyService;
    }
}
/**
 * Keep Resident tools and their matching web guidance in one assembly.
 */
export declare function projectAssemblyTools(assembly: PromptAssembly, service: CapabilityPolicyService): PromptAssembly;
/** Build the policy plugin. */
export declare const name = "capability-menu-policy";
export declare const inject: string[];
export declare function apply(ctx: Context, config?: Config): Promise<void>;
//# sourceMappingURL=policy.d.ts.map