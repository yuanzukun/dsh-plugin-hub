/**
 * Host-side Typert gateway exposing the server-side `ctx.capabilityPolicy`
 * management surface (see `src/policy.ts`) to the browser. Built as
 * `lib/server/remote.js` and mounted by the package root entry (`src/index.ts`).
 *
 * Consumed by the browser bundle under `src/client` via
 * `ctx.remote.capabilityPolicy.classifyAll()` / `getConfig()` /
 * `updateConfig()`.
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { CapabilityClassification, CapabilityPolicyService, Config as CapabilityPolicyConfig } from '../policy.ts';
import type { CapabilityDetail, SkillDirEntry, CapabilityService, CapabilityDiagnostics, SearchMetadata, SearchMetadataUpdate } from '../registry.ts';
import type { McpInput, McpLocation, McpUpdateInput, SkillLocation, SkillUpdateStatus } from '../locations.ts';
import { type SelfUpdateStatus } from './self-update.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        capabilityPolicy: CapabilityPolicyService;
        capability: CapabilityService;
    }
}
/** Effective exposure rules and the current on-demand search summaries. */
export interface CatalogDocs {
    /** Effective rules (`getConfig()` + `metaTools()`), rendered as YAML. */
    readonly policyYaml: string;
    readonly summaryMaxChars: number;
    readonly searchSettingsEnabled: boolean;
    readonly onDemand: readonly {
        readonly id: string;
        readonly kind: 'tool' | 'skill';
        readonly summary: string;
        readonly server?: string;
    }[];
}
/**
 * Host-side remote face for the 能力菜单 tab. Every method delegates to the
 * policy service installed by `@daweifu/capability-menu/policy`; the registry
 * sibling (`capability`) must be mounted for `classifyAll` to return anything.
 *
 * The service registers under a distinct key (`capabilityPolicyGateway`) so it
 * does not collide with the `capabilityPolicy` service the policy plugin
 * provides; the Typert wire namespace is still `capabilityPolicy` (matching
 * the client remote descriptors), and the gateway reads the real policy
 * service through `this.ctx.capabilityPolicy`.
 */
export declare class CapabilityPolicyGateway extends TypertRemoteService {
    static inject: string[];
    constructor(ctx: Context);
    checkSelfUpdate(): Promise<SelfUpdateStatus>;
    installSelfUpdate(version: string): Promise<void>;
    switchSelfToNpm(version: string): Promise<void>;
    /** Current (resolved) policy config. */
    getConfig(): CapabilityPolicyConfig;
    /** Replace a subset of the policy config (recompile rules + rewrite catalog). */
    updateConfig(partial: Partial<CapabilityPolicyConfig>): Promise<void>;
    /** Classify every capability currently indexed by `ctx.capability`. */
    classifyAll(): CapabilityClassification[];
    /** Explain filtered, overridden, broken, empty, and unbrowseable inventory states. */
    getDiagnostics(): CapabilityDiagnostics;
    /**
     * Rebuild the capability catalog now and resolve once it has converged.
     * The UI calls this after registering a new source (an MCP server or a
     * skill directory) so the list reflects it without waiting for the
     * scheduler's debounce window.
     */
    refresh(): Promise<void>;
    /** Resolve one capability's full detail (schema, description; skill body optional). */
    getDetail(id: string): Promise<CapabilityDetail | undefined>;
    getSearchMetadata(id: string, kind: 'tool' | 'skill'): SearchMetadata | undefined;
    updateSearchMetadata(input: SearchMetadataUpdate): Promise<void>;
    updateSummaryMaxChars(value: number): Promise<void>;
    /** List a skill's directory children (one level deep; optional subpath). */
    listSkillDir(id: string, relPath?: string): Promise<SkillDirEntry[] | undefined>;
    /** Read a text file inside a skill's directory. */
    readSkillFile(id: string, relPath: string): Promise<string | undefined>;
    /** Return the effective rules and summaries from the same index as meta_search. */
    getCatalogDocs(): Promise<CatalogDocs>;
    /** MCP servers declared in the patch file. */
    listLocations(): Promise<McpLocation[]>;
    /** Declare a new MCP server. */
    addLocation(input: McpInput): Promise<string>;
    /** Remove a declared MCP server. */
    removeLocation(id: string): Promise<boolean>;
    /** Replace a declared MCP server's connection config. */
    updateLocation(id: string, input: McpUpdateInput): Promise<boolean>;
    /**
     * Skill entries the operator can manage: everything under the user root, plus
     * the project-scoped entries the skill index knows about.
     *
     * dsh discovers a project's skills from `<projectRoot>/.dsh/skills` and
     * `<projectRoot>/.agents/skills` for whichever project the *session* cwd sits
     * in, so reading the user root alone cannot see them. The index records each
     * skill's own directory, which is what lets these rows be edited and removed
     * rather than merely listed.
     */
    listSkillLocations(): Promise<SkillLocation[]>;
    /**
     * Register a skill directory: into the user root by default, or into a
     * project's `.dsh/skills` when `projectPath` names a path inside that project.
     * Returns the entry path actually written so the UI can report it.
     */
    addSkillLocation(dir: string, projectPath?: string): Promise<string>;
    /** Clone and validate the selected directory from a public GitHub skill URL. */
    importSkillFromGitHub(url: string, projectPath?: string): Promise<string>;
    /**
     * Adopt a skill that already lives in a user-level root this plugin reads but
     * does not manage (`~/.agents/skills`, custom dirs) by linking its own
     * directory into the user root. The content is untouched — this is exactly how
     * the entries already in `~/.dsh/skills` are set up — and the skill becomes
     * editable afterwards. Returns the entry path written.
     *
     * A skill that ships inside an agent preset is refused: linking it into the
     * user root would make it global, which is the opposite of what a preset
     * skill is for. It is also the same check the UI applies (it hides the button),
     * repeated here because the source label alone cannot tell a preset's
     * `customSkillDirs` from a user's.
     */
    adoptSkillLocation(name: string): Promise<string>;
    /** Unregister a skill entry; `entryDir` addresses a project entry. */
    removeSkillLocation(name: string, entryDir?: string): Promise<boolean>;
    /** Repoint a registered skill entry at a different directory. */
    updateSkillLocation(name: string, dir: string, entryDir?: string): Promise<boolean>;
    checkSkillUpdate(name: string, entryDir?: string): Promise<SkillUpdateStatus>;
    associateGitHubSkillSource(name: string, url: string, entryDir?: string): Promise<SkillUpdateStatus>;
    updateSkillFromGitHub(name: string, entryDir?: string): Promise<{
        revision: string;
    }>;
    /**
     * The registry's catalog version — one number, cheap enough to poll. The
     * management page uses it to notice changes the wire never announces (a file
     * dropped into an already-registered skill directory reindexes the host via
     * `skills/change`, which is not a forwarded event), and only re-reads
     * `classifyAll` when the number actually moved.
     *
     * Appended at the end of the class on purpose: the client-side descriptors in
     * `src/client/remote.ts` carry each method's `sourceLocation` line, and
     * inserting here would shift every line below it.
     */
    catalogVersion(): number;
}
/** Register the remote gateway on a context. */
export declare const name = "capability-menu-remote";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
//# sourceMappingURL=remote.d.ts.map