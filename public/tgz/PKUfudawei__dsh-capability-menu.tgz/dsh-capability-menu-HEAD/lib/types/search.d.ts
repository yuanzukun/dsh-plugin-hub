/**
 * Model-facing `meta_search` tool: capability catalog search + detail.
 *
 * @module @daweifu/capability-menu (search plugin)
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { CapabilityDetail, CapabilitySummary } from './registry.ts';
export declare const name = "capability-menu-search";
export declare const inject: string[];
/** Model-facing `meta_search` configuration. */
export interface Config {
    /** Maximum results returned in list mode (default 20). */
    maxResults?: number;
}
/** Validate and default the tool configuration. */
export declare const Config: z<Config>;
/** Canonical list-mode result. */
export interface MetaSearchListResult {
    readonly mode: 'list';
    /** Matching On-demand capabilities in the caller scope, before truncation. */
    readonly total: number;
    readonly returned: number;
    readonly truncated: boolean;
    readonly results: CapabilitySummary[];
    readonly hint: string;
}
/** Canonical detail-mode result. */
export interface MetaSearchDetailResult {
    readonly mode: 'detail';
    readonly result: CapabilityDetail;
}
/** Canonical tool result: one of the two modes. */
export type MetaSearchResult = MetaSearchListResult | MetaSearchDetailResult;
/**
 * Register the `meta_search` tool.
 *
 * - Mode A (list, default): search by keyword/tag/server and return a bounded candidate list.
 * - Mode B (detail): pass a candidate's exact id to inspect its full description and tool schema or Skill usage guidance before invocation.
 *
 * Validation rules enforced here:
 * - `query` and `id` are mutually exclusive.
 */
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=search.d.ts.map