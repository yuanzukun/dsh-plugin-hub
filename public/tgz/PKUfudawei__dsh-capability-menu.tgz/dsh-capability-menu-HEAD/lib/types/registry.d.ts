/**
 * Unified capability catalog for the DeepSeek Harness.
 *
 * @module @daweifu/capability-menu (registry plugin)
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ScopeKey } from '@deepseek-ai/dsh-scope';
import type { JsonSchemaNode } from '@deepseek-ai/dsh-tools';
import { BUILT_IN_SERVER, MCP_ID_PREFIX } from './constants.ts';
export { BUILT_IN_SERVER, MCP_ID_PREFIX };
/**
 * Kinds of capability the catalog can hold.
 * - `tool`:   action capability — executes a concrete action (an MCP tool or a
 *   harness-native tool cataloged under the reserved `built-in` server).
 * - `skill`:  action capability — loads the method/instructions for a task.
 */
export type CapabilityKind = 'tool' | 'skill';
/**
 * Stable invocation actions a capability can declare. Each kind maps to one
 * canonical action; a new kind only deserves a new value here when it
 * introduces a new action (not a new flavor of an existing one).
 * `execute` = run the concrete action (a tool — MCP or native — via `ctx.tools.execute`);
 * `load`    = load the method/instructions (a skill).
 */
export type CapabilityAction = 'execute' | 'load';
/**
 * Tool names that never enter the capability catalog: this plugin's own
 * control plane (`meta_search`/`meta_invoke`, always Resident) and the
 * reserved Code Mode presentation transport (`run_code`).
 *
 * Tool ids (the key everything else uses) are the REAL registered tool name:
 * MCP tools are registered as `mcp__<server>__<raw>` by the harness MCP client
 * and natives keep their bare name (`bash`/`read`/…). Skills have no
 * name-level namespace: a skill's id IS its bare name and `kind` disambiguates
 * it from a same-named tool.
 */
export declare const CATALOG_EXCLUDED_TOOLS: ReadonlySet<string>;
/** Capability-stable origin metadata used by search filters and detail views. */
export interface CapabilityOrigin {
    /** Human/namespace label: an MCP server name, the reserved `built-in` for native tools, or a skill provider. */
    readonly provider: string;
    /** Server namespace, present only for `kind: 'tool'` (`built-in` for native tools). */
    readonly serverName?: string;
    /** Local skill path, present only for `kind: 'skill'`. */
    readonly path?: string;
    /** Skill source root label (`project-dsh`/`user-agents`/…), present only for skills. */
    readonly source?: string;
    /**
     * Agent preset whose standing scope this skill was collected from, present
     * only for skills that live in a preset layer.
     *
     * A preset's own `skill-filesystem` mounts its `skills/` directory through
     * `customSkillDirs`, so such a skill is labelled `source: 'custom'` — the
     * same label a user-configured `customSkillDirs` entry gets. The source
     * label therefore cannot tell the two apart; this field is what the
     * management surface groups on ("预设技能" vs. a user's custom root).
     */
    readonly preset?: string;
}
/** Objective and subjective usage statistics, written back from `tools/result`. */
export interface CapabilityStats {
    readonly uses: number;
    readonly successes: number;
    readonly failures: number;
    readonly totalMs: number;
    readonly lastUsedAt?: number;
}
/** One indexed capability. */
export interface CapabilityRecord {
    /** Stable identifier: `mcp__<server>__<raw>`, a native tool name, or a bare skill name. */
    readonly id: string;
    readonly kind: CapabilityKind;
    /** The canonical invocation action(s) this capability exposes. */
    readonly actions: readonly CapabilityAction[];
    /** Model-facing name (the tool name or skill name without prefix). */
    readonly name: string;
    readonly description: string;
    /** Skill-only extra routing guidance. */
    readonly whenToUse?: string;
    readonly origin: CapabilityOrigin;
    /** Full parameter schema (MCP inputSchema / empty object for skills). */
    readonly parameters: JsonSchemaNode;
    readonly invocation: {
        modelInvocable: boolean;
        userInvocable: boolean;
    };
    readonly tags: readonly string[];
    readonly stats: CapabilityStats;
    /** Token-trimmed short description used by `meta_search` list mode. */
    readonly summary: string;
}
/** Lightweight list-mode projection of one capability (no full schema). */
export interface CapabilitySummary {
    readonly id: string;
    readonly kind: CapabilityKind;
    readonly name: string;
    readonly summary: string;
    readonly server?: string;
    /** Skill source root label, present only for `kind: 'skill'`. */
    readonly source?: string;
    /** Agent preset id, present only for skills collected from a preset scope. */
    readonly preset?: string;
    readonly path?: string;
    readonly tags: readonly string[];
    readonly success_rate?: number;
    readonly uses: number;
}
/** Full detail projection, including the parameter schema. */
export interface CapabilityDetail {
    readonly id: string;
    readonly kind: CapabilityKind;
    readonly actions: readonly CapabilityAction[];
    readonly name: string;
    readonly description: string;
    readonly whenToUse?: string;
    readonly parameters: JsonSchemaNode;
    readonly output?: JsonSchemaNode;
    readonly origin: CapabilityOrigin;
    readonly tags: readonly string[];
    readonly stats: CapabilityStats;
}
/** Search filter options. */
export interface MetaSearchOptions {
    readonly kind?: CapabilityKind | 'all';
    readonly server?: string | undefined;
    readonly tag?: string | undefined;
    /** Maximum number of results to return. */
    readonly maxResults?: number;
    /** Zero-based result offset. */
    readonly offset?: number;
    /**
     * Viewing scope. Retained for caller ergonomics and optional authorization
     * checks, but the policy does NOT use it to filter visibility — On-demand
     * capabilities must remain searchable regardless of the caller's projection.
     */
    readonly scope?: ScopeKey | undefined;
    /** Query string for keyword matching; only matches are returned, with exact id/name first. */
    readonly query?: string;
    /** Exact capability id. */
    readonly id?: string;
    /** Whether to include the full body for skills in `getDetail` (default false). */
    readonly detailIncludesBody?: boolean;
}
/** Runtime detail resolution context. */
export interface MetaLookupContext {
    readonly cwd?: string | undefined;
    readonly signal?: AbortSignal | undefined;
    readonly scope?: ScopeKey | undefined;
}
/** One direct child in a skill directory listing. */
export interface SkillDirEntry {
    readonly name: string;
    readonly type: 'file' | 'directory';
}
export interface CapabilityDiagnostics {
    readonly unavailableSkills: readonly {
        readonly name: string;
        readonly source: string;
        readonly preset?: string;
    }[];
    readonly shadowedSkills: readonly {
        readonly name: string;
        readonly selectedFrom: string;
        readonly shadowedFrom: string;
    }[];
    readonly brokenPresets: readonly {
        readonly id: string;
        readonly reason: string;
    }[];
    readonly unbrowseableSkills: readonly {
        readonly name: string;
        readonly reason: string;
    }[];
    readonly undocumentedSkills: readonly {
        readonly name: string;
        readonly summary: string;
    }[];
    readonly catalog: {
        readonly state: 'empty' | 'ready';
        readonly count: number;
    };
}
/** User-owned text used only for discovery; the provider's definition stays intact. */
export interface SearchMetadata {
    readonly id: string;
    readonly kind: CapabilityKind;
    readonly defaultDescription: string;
    readonly description?: string;
    readonly maxChars: number;
}
export interface SearchMetadataUpdate {
    readonly id: string;
    readonly kind: CapabilityKind;
    /** Empty or provider-identical text restores the provider-derived description. */
    readonly description: string;
}
/** The `ctx.capability` service surface. */
export interface CapabilityService {
    /** Enumerate the current catalog (optionally filtered). */
    search(options?: MetaSearchOptions): CapabilitySummary[];
    /**
     * Resolve one record by id, or undefined. Pass `kind` when the caller knows
     * it (tools and skills may share a bare name, e.g. a skill named `bash`);
     * without `kind` a same-name tool/skill pair resolves to undefined.
     */
    get(id: string, kind?: CapabilityKind): CapabilityRecord | undefined;
    /**
     * Resolve one record's full detail (schema, output; skill body optional).
     * `kind` has the same disambiguation semantics as {@link get}.
     */
    getDetail(id: string, kind?: CapabilityKind, context?: MetaLookupContext): Promise<CapabilityDetail | undefined>;
    /**
     * List a skill's directory children (one level deep). The directory is
     * resolved from the skill's own provider path, never from caller input;
     * `relPath` (optional, relative to the skill root) descends into a child
     * directory.
     */
    listSkillDir(id: string, relPath?: string): Promise<SkillDirEntry[] | undefined>;
    /**
     * Read a text file inside a skill's directory, addressed by a relative path
     * that is resolved against and confined to the skill root. Binary files
     * (content containing NUL) return undefined.
     */
    readSkillFile(id: string, relPath: string): Promise<string | undefined>;
    /**
     * Indexed skills whose provider exposes a filesystem directory, as
     * `{ name, skillDir }` where `skillDir` is `<entryDir>/<name>`.
     */
    skillDirs(): ReadonlyArray<{
        readonly name: string;
        readonly skillDir: string;
        readonly source?: string;
    }>;
    diagnostics(): CapabilityDiagnostics;
    /** Return the current number of indexed capabilities. */
    size(): number;
    /**
     * Monotonic catalog version. It advances only when a rebuild finishes
     * applying, so a caller that compares two samples learns "the catalog really
     * moved" without re-reading the rows — which is what lets the management UI
     * poll a single number instead of `classifyAll` on every tick.
     *
     * Not guaranteed to increase across a plugin restart (the counter is
     * in-process), so compare with `!==`, never with `>`.
     */
    version(): number;
    /**
     * Rebuild the catalog from the current tool/skill registries; resolves when
     * done. In production the registry rebuilds automatically on `tools/change`
     * / `skills/change`; this public handle is for tests and external orchestrators
     * that want to force a rebuild.
     */
    refresh(): Promise<void>;
    /**
     * Ask for a rebuild without waiting for it. The scheduler coalesces bursts,
     * so a caller that changes something repeatedly (the management UI cycling
     * a classification) triggers one rebuild, not one per call.
     */
    requestRefresh(): void;
    getSearchMetadata(id: string, kind: CapabilityKind): SearchMetadata | undefined;
    updateSearchMetadata(input: SearchMetadataUpdate): Promise<void>;
    summaryMaxChars(): number;
    searchSettingsEnabled(): boolean;
    updateSummaryMaxChars(value: number): Promise<void>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        capability: CapabilityService;
    }
}
/** Registry configuration. */
export interface Config {
    /** Maximum summary length in characters (min 20). */
    summaryMaxChars?: number;
    /** Whether to include the skill body in `getDetail` results (default false). */
    detailIncludesBody?: boolean;
    /**
     * Maximum search results returned (default 20). No upper bound is enforced:
     * callers that need the whole catalog (the policy's `classifyAll`) pass a
     * very large value on purpose, so capping here would silently truncate the
     * management surface.
     */
    maxResults?: number;
    /** Experience-weighting intensity for ranking (0 disables, default 0.1). */
    weighting?: number;
    /** Shared menu state; set to the policy entry's stateFile when customizing its path. */
    stateFile?: string;
    /**
     * Debounce window (ms) applied to catalog rebuilds triggered by
     * `tools/change` / `skills/change`. The skill/preset lifecycle emits these
     * events in bursts, and a rebuild's own registry access can emit further
     * ones, so rebuilding once per event produced an unbounded CPU storm. The
     * scheduler runs at most one rebuild at a time and coalesces a burst into a
     * single follow-up after this window. Set to `0` to disable debouncing
     * (every event still gets at most one coalesced rebuild, never a concurrent
     * one). Default 200.
     */
    refreshDebounceMs?: number;
}
/** Validate and default the registry configuration. */
export declare const Config: z<Config>;
/** Build the registry plugin. */
export declare const name = "capability-menu-registry";
export declare const inject: string[];
export declare function apply(ctx: Context, config?: Config): Promise<void>;
/** Derive the server namespace from an `mcp__<server>__<raw>` name. */
export declare function serverNameOf(publicName: string): string;
//# sourceMappingURL=registry.d.ts.map