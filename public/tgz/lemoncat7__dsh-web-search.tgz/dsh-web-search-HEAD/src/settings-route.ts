/** Same-origin HTTP bridge used by the plugin's browser settings card. */

import type { IncomingHttpHeaders, IncomingMessage, ServerResponse } from 'node:http'

/** Exact same-origin route owned by this plugin. */
export const SETTINGS_PATH = '/lemoncat7-web-search/settings'

/** Credential status safe to render in a browser. */
export interface CredentialStatus {
  readonly configured: boolean
  readonly writable: boolean
}

/** Complete browser settings snapshot; it never contains credential values. */
export interface BrowserSettingsSnapshot {
  readonly config: unknown
  readonly credentials: {
    readonly brave: CredentialStatus
    readonly tavily: CredentialStatus
    readonly gemini: CredentialStatus
  }
}

/** Safe summary returned after exercising one provider with a real query. */
export interface SettingsTestResult {
  readonly provider: string
  readonly resultCount: number
  readonly durationMs: number
  readonly firstTitle?: string | undefined
}

export interface EngineProbeResult {
  readonly name: string
  readonly categories: readonly string[]
  readonly enabledByDefault: boolean
  readonly tested: boolean
  readonly available: boolean
  readonly resultCount: number
  readonly truncated: boolean
  readonly durationMs: number
  readonly error?: string
}

/** Server operations exposed through the same-origin settings route. */
export interface SettingsApi {
  readonly read: () => Promise<BrowserSettingsSnapshot>
  readonly write: (config: unknown, apiKey: string | undefined) => Promise<BrowserSettingsSnapshot>
  readonly test: (config: unknown, apiKey: string | undefined) => Promise<SettingsTestResult>
  readonly discoverEngines: (config: unknown, query: string) => Promise<readonly EngineProbeResult[]>
}

interface RequestHeaders {
  readonly headers: IncomingHttpHeaders
}

/** Browser same-host requests, or the official Desktop origin on loopback. */
export function isTrustedSettingsRequest(request: RequestHeaders, requireOrigin: boolean): boolean {
  const rawHost = singleHeader(request.headers, 'host')
  if (rawHost === undefined) return false
  let host: URL
  try {
    host = new URL(`http://${rawHost}`)
  } catch {
    return false
  }
  const origin = singleHeader(request.headers, 'origin')
  // Desktop's custom scheme is cross-site relative to its local HTTP bridge.
  // Match the serialized origin exactly: no wildcard schemes, ports or paths.
  if (origin === 'dsh-app://app' && ['127.0.0.1', '[::1]', 'localhost'].includes(host.hostname)
    && host.username === '' && host.password === '' && host.pathname === '/' && host.search === '' && host.hash === '') return true
  if (singleHeader(request.headers, 'sec-fetch-site') === 'cross-site') return false
  if (request.headers.origin !== undefined && origin === undefined) return false
  if (origin === undefined) return !requireOrigin
  try {
    const source = new URL(origin)
    return (source.protocol === 'http:' || source.protocol === 'https:') && source.host === host.host
  } catch {
    return false
  }
}

/** Build the GET/PUT route handler without exposing DSH services to HTTP code. */
export function settingsHandler(api: SettingsApi) {
  return async (request: IncomingMessage, response: ServerResponse): Promise<void> => {
    if (request.method === 'GET') {
      if (!isTrustedSettingsRequest(request, false)) return forbidden(response)
      return json(response, 200, await api.read())
    }
    if (request.method !== 'PUT' && request.method !== 'POST') {
      response.writeHead(405, { allow: 'GET, POST, PUT' })
      response.end()
      return
    }
    if (!isTrustedSettingsRequest(request, true)) return forbidden(response)
    if (singleHeader(request.headers, 'content-type')?.split(';', 1)[0] !== 'application/json') {
      return json(response, 415, { error: 'content-type must be application/json' })
    }
    let input: unknown
    try {
      input = JSON.parse(await readBody(request, 16 * 1024))
    } catch (error: unknown) {
      return json(response, 400, { error: error instanceof Error ? error.message : String(error) })
    }
    if (!isRecord(input) || !('config' in input) || !isRecord(input.config)) {
      return json(response, 400, { error: 'config must be an object' })
    }
    const apiKey = input.apiKey
    if (apiKey !== undefined && (typeof apiKey !== 'string' || apiKey.length > 8_192)) {
      return json(response, 400, { error: 'apiKey must be a string of at most 8192 characters' })
    }
    try {
      const value = request.method === 'POST'
        ? input.action === 'discover-engines'
          ? await api.discoverEngines(input.config, searchQuery(input.query))
          : await api.test(input.config, apiKey)
        : await api.write(input.config, apiKey)
      return json(response, 200, value)
    } catch (error: unknown) {
      return json(response, 400, { error: error instanceof Error ? error.message : String(error) })
    }
  }
}

function searchQuery(value: unknown): string {
  if (value === undefined) return 'DeepSeek'
  if (typeof value !== 'string' || value.trim().length === 0 || value.length > 200) throw new Error('query must be a non-empty string of at most 200 characters')
  return value.trim()
}

async function readBody(request: IncomingMessage, maximum: number): Promise<string> {
  const chunks: Buffer[] = []
  let length = 0
  for await (const chunk of request) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    length += buffer.length
    if (length > maximum) throw new Error(`request body exceeds ${String(maximum)} bytes`)
    chunks.push(buffer)
  }
  return Buffer.concat(chunks).toString('utf8')
}

function singleHeader(headers: IncomingHttpHeaders, name: string): string | undefined {
  const value = headers[name]
  return typeof value === 'string' ? value : undefined
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function forbidden(response: ServerResponse): void {
  json(response, 403, { error: 'Forbidden: untrusted settings request origin' })
}

function json(response: ServerResponse, status: number, value: unknown): void {
  const body = JSON.stringify(value)
  response.writeHead(status, {
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'x-content-type-options': 'nosniff',
  })
  response.end(body)
}
