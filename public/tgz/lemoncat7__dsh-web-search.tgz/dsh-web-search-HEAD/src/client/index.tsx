/** Browser settings card for the multi-provider search plugin. */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings-plugins/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { PropsLocale, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots'
import { useEffect, useState, type CSSProperties, type ReactNode } from 'react'
import { en, zh, type WebSearchMultiLocaleKey } from './locales.ts'
import { settingsSurfaceCss } from '../settings-surface.js'
import { readSettingsResponse } from '../settings-response.js'

const SETTINGS_PATH = '/lemoncat7-web-search/settings'
const LOCALE_NAMESPACE = 'lemoncat7-web-search'
const STYLE_ID = 'lemoncat7-web-search-settings-style'
const settingsCss = `
.dsh-web-search-settings{list-style:none;overflow:hidden;border:1px solid var(--dsw-alias-border-l2);border-radius:12px;background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary);transition:border-color .16s,background .16s}
.dsh-web-search-settings:hover{border-color:var(--dsw-alias-label-dimmed)}
.dsh-web-search-settings.is-open{border-color:var(--dsw-alias-label-dimmed);background:var(--dsw-alias-bg-layer-2)}
.dsh-web-search-settings__header{appearance:none;display:flex;width:100%;box-sizing:border-box;align-items:center;gap:12px;padding:14px 16px;border:0;border-radius:12px;background:transparent;color:inherit;text-align:left;cursor:pointer;font:inherit}
.dsh-web-search-settings__header:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:-2px}
.dsh-web-search-settings__copy{display:flex;min-width:0;flex:1;flex-direction:column;gap:4px}
.dsh-web-search-settings__copy strong{font-size:15px;font-weight:600;line-height:1.4}
.dsh-web-search-settings__copy small{overflow:hidden;color:var(--dsw-alias-label-tertiary);font-size:13px;line-height:1.5;text-overflow:ellipsis;white-space:nowrap}
.dsh-web-search-settings__summary{display:flex;flex:none;align-items:center;gap:10px;color:var(--dsw-alias-label-tertiary);font-size:12px;white-space:nowrap}
.dsh-web-search-settings__summary[data-dirty="true"]{padding:1px 8px;border-radius:999px;background:var(--dsw-alias-bg-module-platform);color:var(--dsw-alias-label-secondary);font-size:11px;font-weight:500;line-height:17px}
.dsh-web-search-settings__summary i{width:8px;height:8px;border-right:1.5px solid currentColor;border-bottom:1.5px solid currentColor;transform:rotate(45deg);transition:transform .16s}
.dsh-web-search-settings.is-open .dsh-web-search-settings__summary i{transform:rotate(225deg)}
.dsh-web-search-settings__body{margin:0 16px;padding-bottom:8px;border-top:1px solid var(--dsw-alias-border-l2)}
@media(max-width:640px){.dsh-web-search-settings__summary{font-size:0}.dsh-web-search-settings__copy small{white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}}
@media(prefers-reduced-motion:reduce){.dsh-web-search-settings,.dsh-web-search-settings__summary i{transition:none}}
`

function installSettingsStyles(): void {
  if (document.getElementById(STYLE_ID) !== null) return
  const style = document.createElement('style')
  style.id = STYLE_ID
  style.textContent = settingsCss + settingsSurfaceCss
  document.head.append(style)
}

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Copy for the multi-provider web-search settings card. */
    'lemoncat7-web-search': WebSearchMultiLocaleKey
  }
}

type Provider = 'searxng' | 'wikipedia' | 'tavily' | 'brave' | 'gemini'

interface SearchConfig {
  provider: Provider
  requestTimeoutMs: number
  searxng: { baseURL: string; language: string; categories?: string | undefined; engines?: string[] | undefined; retryCount: number; safeSearch: 0 | 1 | 2 }
  wikipedia: { language: string }
  tavily: { apiKeyEnv: string; searchDepth: 'basic' | 'advanced' | 'fast' | 'ultra-fast'; topic: 'general' | 'news' | 'finance' }
  gemini: { apiKeyEnv: string; model: string }
  brave: { apiKeyEnv: string; country?: string | undefined; searchLanguage?: string | undefined; safeSearch: 'off' | 'moderate' | 'strict' }
}

interface CredentialState {
  configured: boolean
  writable: boolean
}

interface SettingsSnapshot {
  config: SearchConfig
  credentials: { brave: CredentialState; tavily: CredentialState; gemini: CredentialState }
}

interface SettingsTestResult {
  provider: Provider
  resultCount: number
  durationMs: number
  firstTitle?: string | undefined
}

interface EngineProbeResult {
  name: string
  categories: string[]
  enabledByDefault: boolean
  tested: boolean
  available: boolean
  resultCount: number
  truncated: boolean
  durationMs: number
  error?: string
}

const field = (first = false): CSSProperties => ({ display: 'flex', flexDirection: 'column', gap: 6, padding: '12px 0', ...first ? {} : { borderTop: '1px solid var(--dsw-alias-border-l2)' } })
const fieldHead: CSSProperties = { display: 'flex', alignItems: 'center', gap: 8 }
const input: CSSProperties = { width: '100%', lineHeight: 1.5 }
const label: CSSProperties = { flex: 1, minWidth: 0, fontSize: 13, fontWeight: 500, lineHeight: 1.5, color: 'var(--dsw-alias-label-primary)' }
const hint: CSSProperties = { margin: 0, color: 'var(--dsw-alias-label-tertiary)', fontSize: 12, fontWeight: 400, lineHeight: 1.5 }
const footer: CSSProperties = { display: 'flex', flexWrap: 'wrap', justifyContent: 'flex-end', alignItems: 'center', gap: 8, padding: '12px 0 4px', borderTop: '1px solid var(--dsw-alias-border-l2)' }
const button: CSSProperties = { appearance: 'none', minHeight: 34, padding: '8px 13px', border: 0, borderRadius: 10, background: 'var(--ps-hover)', color: 'var(--ps-text)', cursor: 'pointer', font: 'inherit', fontSize: 13, lineHeight: 1.5 }
const primaryButton: CSSProperties = { ...button, background: 'var(--ps-accent)', color: 'var(--ps-on-accent)' }
const disabledButton: CSSProperties = { opacity: 0.4, cursor: 'default' }
const statusText: CSSProperties = { flex: 1, minWidth: 150, margin: 0, fontSize: 12, lineHeight: 1.5 }
const notice: CSSProperties = { margin: '12px 0 0', padding: '10px 12px', borderRadius: 8, background: 'var(--dsw-alias-bg-module-platform)', color: 'var(--dsw-alias-label-secondary)', fontSize: 12, lineHeight: 1.6 }

/** Client runtime dependencies. */
export const inject = ['slots', 'locale']

/** Register one plugin-owned card in DSH's existing plugin settings page. */
export function apply(ctx: ClientContext): void {
  installSettingsStyles()
  ctx.effect(() => ctx.locale.register(LOCALE_NAMESPACE, { zh, en }), 'lemoncat7-web-search: dictionaries')
  ctx.slots.inject('settings.plugins.tab', () => ctx.slots.register({
    name: 'settings.plugins.tab',
    id: 'lemoncat7-web-search',
    label: () => '网页搜索',
    locale: LOCALE_NAMESPACE,
  }, MultiSearchSettingsCard))
}

/** Multi-provider form backed by the plugin's same-origin Host route. */
export function MultiSearchSettingsCard({ t }: PropsLocale<typeof LOCALE_NAMESPACE>) {
  const [open, setOpen] = useState(false)
  const [snapshot, setSnapshot] = useState<SettingsSnapshot>()
  const [draft, setDraft] = useState<SearchConfig>()
  const [apiKey, setApiKey] = useState('')
  const [dirty, setDirty] = useState(false)
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState(false)
  const [testResult, setTestResult] = useState<SettingsTestResult>()
  const [error, setError] = useState<string>()

  const load = async () => {
    try {
      const next = await requestSettings()
      setSnapshot(next)
      setDraft(next.config)
      setApiKey('')
      setDirty(false)
      setTestResult(undefined)
      setError(undefined)
    } catch (failure: unknown) {
      setError(failure instanceof Error ? failure.message : String(failure))
    }
  }
  useEffect(() => { void load() }, [])

  const edit = (next: SearchConfig) => {
    setDraft(next)
    setDirty(true)
    setTestResult(undefined)
    setError(undefined)
  }
  const save = async () => {
    if (draft === undefined) return
    setSaving(true)
    setError(undefined)
    try {
      const next = await requestSettings({ config: draft, ...(apiKey === '' ? {} : { apiKey }) })
      setSnapshot(next)
      setDraft(next.config)
      setApiKey('')
      setDirty(false)
      setTestResult(undefined)
    } catch (failure: unknown) {
      setError(failure instanceof Error ? failure.message : String(failure))
    } finally {
      setSaving(false)
    }
  }
  const test = async () => {
    if (draft === undefined) return
    setTesting(true)
    setTestResult(undefined)
    setError(undefined)
    try {
      setTestResult(await testSettings({ config: draft, ...(apiKey === '' ? {} : { apiKey }) }))
    } catch (failure: unknown) {
      setError(failure instanceof Error ? failure.message : String(failure))
    } finally {
      setTesting(false)
    }
  }

  return (
    <li className={`dsh-plugin-settings dsh-web-search-settings${open ? ' is-open' : ''}`}>
      <button type="button" className="dsh-web-search-settings__header" aria-expanded={open} aria-label={t(open ? 'card.collapse' : 'card.expand')} onClick={() => { setOpen(value => !value) }}>
        <span className="dsh-web-search-settings__copy"><strong>{t('card.name')}</strong><small>{t('card.description')}</small></span>
        <span className="dsh-web-search-settings__summary" data-dirty={dirty || apiKey !== '' ? 'true' : 'false'}>{dirty || apiKey !== '' ? t('status.unsaved') : draft === undefined ? t('status.loading') : draft.provider}<i aria-hidden="true" /></span>
      </button>
      {open ? <div className="dsh-web-search-settings__body">
          {draft === undefined ? <p role="status">{t('status.loading')}</p> : <>
            <div>
              <SelectField first label={t('field.provider')} value={draft.provider} onChange={value => { edit({ ...draft, provider: value as Provider }); setApiKey('') }}>
                <option value="searxng">{t('provider.searxng')}</option>
                <option value="wikipedia">{t('provider.wikipedia')}</option>
                <option value="tavily">{t('provider.tavily')}</option>
                <option value="brave">{t('provider.brave')}</option>
                <option value="gemini">{t('provider.gemini')}</option>
              </SelectField>
              <TextField label={t('field.timeout')} type="number" value={String(draft.requestTimeoutMs)} onChange={value => { edit({ ...draft, requestTimeoutMs: Number(value) }) }} hint={t('field.timeoutHint')} />
            </div>
            <ProviderFields t={t} draft={draft} snapshot={snapshot} apiKey={apiKey} setApiKey={(value) => { setApiKey(value); setDirty(true); setTestResult(undefined); setError(undefined) }} edit={edit} />
          </>}
          <div style={footer}>
            <button type="button" style={{ ...button, ...(saving || testing || !valid(draft) ? disabledButton : {}) }} disabled={saving || testing || !valid(draft)} onClick={() => { void test() }}>{t(testing ? 'action.testing' : 'action.test')}</button>
            {error === undefined && testResult === undefined ? <span style={statusText} /> : null}
            {error === undefined || testResult !== undefined ? null : <p role="alert" style={{ ...statusText, color: 'var(--dsw-alias-label-error)' }}>{t('status.failure')}{error}</p>}
            {testResult === undefined ? null : <p role="status" style={{ ...statusText, color: 'var(--dsw-alias-label-success, #2f9e62)' }}>{t('status.success', { count: testResult.resultCount, duration: testResult.durationMs })}{testResult.firstTitle === undefined ? '' : ` · ${testResult.firstTitle}`}</p>}
            <button type="button" style={{ ...button, ...(!dirty || saving || testing ? disabledButton : {}) }} disabled={!dirty || saving || testing} onClick={() => { if (snapshot !== undefined) { setDraft(snapshot.config); setApiKey(''); setDirty(false); setTestResult(undefined); setError(undefined) } }}>{t('action.discard')}</button>
            <button type="button" style={{ ...primaryButton, ...(!dirty || saving || testing || !valid(draft) ? disabledButton : {}) }} disabled={!dirty || saving || testing || !valid(draft)} onClick={() => { void save() }}>{t(saving ? 'action.saving' : 'action.save')}</button>
          </div>
      </div> : null}
    </li>
  )
}

function ProviderFields(props: { t: TranslateNS<typeof LOCALE_NAMESPACE>; draft: SearchConfig; snapshot?: SettingsSnapshot | undefined; apiKey: string; setApiKey: (value: string) => void; edit: (next: SearchConfig) => void }) {
  const { draft } = props
  const [engineQuery, setEngineQuery] = useState('DeepSeek')
  const [engineProbes, setEngineProbes] = useState<EngineProbeResult[]>()
  const [discovering, setDiscovering] = useState(false)
  const [engineError, setEngineError] = useState<string>()
  const discover = async () => {
    setDiscovering(true); setEngineError(undefined)
    try { setEngineProbes(await discoverEngines(draft, engineQuery)) }
    catch (error: unknown) { setEngineError(error instanceof Error ? error.message : String(error)) }
    finally { setDiscovering(false) }
  }
  const toggleEngine = (engine: string) => {
    const selected = new Set(draft.searxng.engines ?? [])
    if (selected.has(engine)) selected.delete(engine); else selected.add(engine)
    props.edit({ ...draft, searxng: { ...draft.searxng, engines: [...selected] } })
  }
  if (draft.provider === 'searxng') return <>
    <p style={notice}><strong>{props.t('searxng.noticeTitle')}</strong><br />{props.t('searxng.noticeBody')}</p>
    <TextField label={props.t('searxng.url')} value={draft.searxng.baseURL} onChange={baseURL => { props.edit({ ...draft, searxng: { ...draft.searxng, baseURL } }) }} hint={props.t('searxng.urlHint')} />
    <TextField label={props.t('searxng.language')} value={draft.searxng.language} onChange={language => { props.edit({ ...draft, searxng: { ...draft.searxng, language } }) }} hint={props.t('searxng.languageHint')} />
    <TextField label={props.t('searxng.categories')} value={draft.searxng.categories ?? ''} onChange={categories => { props.edit({ ...draft, searxng: { ...draft.searxng, ...(categories === '' ? { categories: undefined } : { categories }) } }) }} hint={props.t('searxng.categoriesHint')} />
    <TextField label={props.t('searxng.retryCount')} type="number" value={String(draft.searxng.retryCount)} onChange={retryCount => { props.edit({ ...draft, searxng: { ...draft.searxng, retryCount: Number(retryCount) } }) }} hint={props.t('searxng.retryCountHint')} />
    <SelectField label={props.t('field.safeSearch')} value={String(draft.searxng.safeSearch)} onChange={value => { props.edit({ ...draft, searxng: { ...draft.searxng, safeSearch: Number(value) as 0 | 1 | 2 } }) }}><option value="0">{props.t('safeSearch.off')}</option><option value="1">{props.t('safeSearch.moderate')}</option><option value="2">{props.t('safeSearch.strict')}</option></SelectField>
    <section style={field()} aria-label={props.t('searxng.engines')}>
      <span style={label}>{props.t('searxng.engines')}</span>
      <span style={hint}>{props.t('searxng.enginesHint')}</span>
      <div style={{ display: 'flex', gap: 8 }}>
        <input style={{ ...input, flex: 1 }} value={engineQuery} maxLength={200} onChange={event => { setEngineQuery(event.target.value) }} aria-label={props.t('searxng.probeQuery')} />
        <button type="button" style={{ ...button, ...(discovering || engineQuery.trim() === '' ? disabledButton : {}) }} disabled={discovering || engineQuery.trim() === ''} onClick={() => { void discover() }}>{props.t(discovering ? 'searxng.probing' : 'searxng.probe')}</button>
      </div>
      {engineError ? <p role="alert" style={{ ...hint, color: 'var(--dsw-alias-label-error)' }}>{engineError}</p> : null}
      {engineProbes ? <div style={{ display: 'grid', gap: 6, maxHeight: 320, overflow: 'auto' }}>
        {engineProbes.map(engine => <label key={engine.name} style={{ display: 'grid', gridTemplateColumns: '20px minmax(100px, 1fr) auto auto', alignItems: 'center', gap: 8, padding: '7px 8px', borderRadius: 8, background: 'var(--dsw-alias-bg-module-platform)' }} title={engine.error}>
          <input type="checkbox" checked={(draft.searxng.engines ?? []).includes(engine.name)} onChange={() => { toggleEngine(engine.name) }} />
          <span style={{ fontSize: 13, color: 'var(--dsw-alias-label-primary)' }}>{engine.name}</span>
          <span style={{ maxWidth: 150, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12, color: engine.available ? 'var(--dsw-alias-label-success, #2f9e62)' : engine.tested ? 'var(--dsw-alias-label-error)' : 'var(--dsw-alias-label-tertiary)' }}>{engine.available ? `${engine.resultCount}${engine.truncated ? '+' : ''} 条` : engine.tested ? engine.error || '不可用' : '未测试'}</span>
          <span style={{ minWidth: 58, textAlign: 'right', fontSize: 12, color: 'var(--dsw-alias-label-tertiary)' }}>{engine.tested ? `${engine.durationMs} ms` : '—'}</span>
        </label>)}
      </div> : null}
    </section>
  </>
  if (draft.provider === 'wikipedia') return <>
    <TextField label={props.t('wikipedia.language')} value={draft.wikipedia.language} onChange={language => { props.edit({ ...draft, wikipedia: { language } }) }} hint={props.t('wikipedia.languageHint')} />
  </>
  const credential = props.snapshot?.credentials[draft.provider]
  if (draft.provider === 'gemini') return <>
    <p style={notice}><strong>{props.t('gemini.noticeTitle')}</strong><br />{props.t('gemini.noticeBody')}</p>
    <PasswordField t={props.t} provider="gemini" value={props.apiKey} state={credential} onChange={props.setApiKey} />
    <TextField label={props.t('gemini.model')} value={draft.gemini.model} onChange={model => { props.edit({ ...draft, gemini: { ...draft.gemini, model } }) }} hint={props.t('gemini.modelHint')} />
  </>
  return <>
    <PasswordField t={props.t} provider={draft.provider} value={props.apiKey} state={credential} onChange={props.setApiKey} />
    {draft.provider === 'tavily' ? <>
      <SelectField label={props.t('tavily.depth')} value={draft.tavily.searchDepth} onChange={searchDepth => { props.edit({ ...draft, tavily: { ...draft.tavily, searchDepth: searchDepth as SearchConfig['tavily']['searchDepth'] } }) }}><option value="basic">Basic</option><option value="advanced">Advanced</option><option value="fast">Fast</option><option value="ultra-fast">Ultra fast</option></SelectField>
      <SelectField label={props.t('tavily.topic')} value={draft.tavily.topic} onChange={topic => { props.edit({ ...draft, tavily: { ...draft.tavily, topic: topic as SearchConfig['tavily']['topic'] } }) }}><option value="general">General</option><option value="news">News</option><option value="finance">Finance</option></SelectField>
    </> : <>
      <TextField label={props.t('brave.country')} value={draft.brave.country ?? ''} onChange={country => { props.edit({ ...draft, brave: { ...draft.brave, ...(country === '' ? { country: undefined } : { country }) } }) }} hint={props.t('brave.countryHint')} />
      <TextField label={props.t('brave.language')} value={draft.brave.searchLanguage ?? ''} onChange={searchLanguage => { props.edit({ ...draft, brave: { ...draft.brave, ...(searchLanguage === '' ? { searchLanguage: undefined } : { searchLanguage }) } }) }} hint={props.t('brave.languageHint')} />
      <SelectField label={props.t('field.safeSearch')} value={draft.brave.safeSearch} onChange={safeSearch => { props.edit({ ...draft, brave: { ...draft.brave, safeSearch: safeSearch as SearchConfig['brave']['safeSearch'] } }) }}><option value="off">{props.t('safeSearch.off')}</option><option value="moderate">{props.t('safeSearch.moderate')}</option><option value="strict">{props.t('safeSearch.strict')}</option></SelectField>
    </>}
  </>
}

function TextField(props: { label: string; value: string; onChange: (value: string) => void; hint?: string; type?: 'text' | 'number'; first?: boolean }) {
  return <label style={field(props.first)}><span style={label}>{props.label}</span><input style={input} type={props.type ?? 'text'} value={props.value} onChange={event => { props.onChange(event.target.value) }} />{props.hint === undefined ? null : <span style={hint}>{props.hint}</span>}</label>
}

function SelectField(props: { label: string; value: string; onChange: (value: string) => void; children: ReactNode; first?: boolean }) {
  return <label style={field(props.first)}><span style={label}>{props.label}</span><select style={input} value={props.value} onChange={event => { props.onChange(event.target.value) }}>{props.children}</select></label>
}

function PasswordField(props: { t: TranslateNS<typeof LOCALE_NAMESPACE>; provider: 'brave' | 'tavily' | 'gemini'; value: string; state?: CredentialState | undefined; onChange: (value: string) => void }) {
  const reference = props.provider === 'brave' ? 'BRAVE_SEARCH_API_KEY' : props.provider === 'tavily' ? 'TAVILY_API_KEY' : 'GEMINI_API_KEY'
  const configured = props.state?.configured === true
  const writable = props.state?.writable !== false
  return <label style={field()}><span style={fieldHead}><span style={label}>API Key</span><span style={{ borderRadius: 999, padding: '1px 8px', fontSize: 11, lineHeight: '17px', color: 'var(--dsw-alias-label-tertiary)' }}>{props.t(configured ? 'credential.configured' : 'credential.missing')}</span></span><input style={input} type="password" autoComplete="off" value={props.value} disabled={!writable} onChange={event => { props.onChange(event.target.value) }} /><span style={hint}>{writable ? props.t('credential.writableHint', { reference }) : props.t('credential.readonlyHint')}</span></label>
}

function valid(config: SearchConfig | undefined): boolean {
  if (config === undefined || !Number.isInteger(config.requestTimeoutMs) || config.requestTimeoutMs < 1_000 || config.requestTimeoutMs > 55_000) return false
  if (config.provider === 'searxng') {
    try {
      const url = new URL(config.searxng.baseURL)
      return (url.protocol === 'http:' || url.protocol === 'https:') && config.searxng.language.trim() !== ''
        && Number.isInteger(config.searxng.retryCount) && config.searxng.retryCount >= 0 && config.searxng.retryCount <= 3
    } catch {
      return false
    }
  }
  if (config.provider === 'gemini') return /^[a-z0-9][a-z0-9._-]{0,99}$/.test(config.gemini.model)
  return config.provider !== 'wikipedia' || /^[a-z][a-z0-9-]{0,19}$/.test(config.wikipedia.language)
}

async function requestSettings(input?: { config: SearchConfig; apiKey?: string }): Promise<SettingsSnapshot> {
  return request<SettingsSnapshot>(input === undefined ? 'GET' : 'PUT', input)
}

async function testSettings(input: { config: SearchConfig; apiKey?: string }): Promise<SettingsTestResult> {
  return request<SettingsTestResult>('POST', input)
}

async function discoverEngines(config: SearchConfig, query: string): Promise<EngineProbeResult[]> {
  return request<EngineProbeResult[]>('POST', { action: 'discover-engines', config, query })
}

async function request<T>(method: 'GET' | 'POST' | 'PUT', input?: { config: SearchConfig; apiKey?: string; action?: 'discover-engines'; query?: string }): Promise<T> {
  const response = await fetch(SETTINGS_PATH, input === undefined ? { method } : {
    method,
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  })
  return readSettingsResponse<T>(response)
}
