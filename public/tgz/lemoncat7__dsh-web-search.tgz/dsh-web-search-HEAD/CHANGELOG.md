# Changelog

## 0.3.2

- Support the official `dsh-app://app` Desktop origin on the loopback settings bridge, including cross-site fetch metadata.
- Keep untrusted origins blocked; return structured 403 errors and handle non-JSON HTTP failures without masking them as JSON parsing errors.
- Target DSH `0.1.7-rc.2`; 54 automated tests, type checks, build and package checks pass. Real Desktop validation remains pending.

## 0.2.1

- Migrate the host, settings, credentials, tools, and client UI integration to DeepSeek Harness `0.1.2-rc.1`.
- Build and deployment-test the release on the DSH `0.1.2-rc.1` API family.

## 0.1.2

- Provide the standard DSH `web_fetch` capability alongside `web_search`.
- Add bounded `web_source` inspection for procedures that require raw HTML or script-embedded evidence removed by readable-page conversion.
- Reuse the plugin-scoped proxy for direct public-page retrieval.
- Block local, private, reserved, credential-bearing, non-HTTP, and binary fetch targets; revalidate bounded redirects and cap response bodies.

## 0.1.1

- Discover general-purpose engines from the configured SearXNG `/config` endpoint.
- Probe engines with bounded concurrency and sort usable engines by measured latency.
- Let each DSH client select the engines sent with every SearXNG search request.
- Add configurable retry count for failed or empty SearXNG searches.

## 0.1.0-alpha.3

- Provide one stable DSH-native `web_search` tool backed by SearXNG, Wikipedia, Tavily, Brave, or Gemini.
- Add bilingual settings, credential-backed API-key editing, and real draft testing.
- Default new installations to keyless Chinese Wikipedia.
- Add a plugin-scoped `DSH_WEB_SEARCH_PROXY` transport without changing networking for other DSH services.
- Support exact same-origin settings access through a protected remote DSH reverse proxy.
- Validate external JSON, reject redirects, cap responses at 2 MiB, and preserve caller cancellation.
- Target DSH 0.1.1-rc.2 on Node.js 22.19/24.
