/**
 * Genuine OpenCode tool definitions (description + JSON schema), captured from
 * the official client. Since 2026-10-14 the Zen free-tier gate validates the
 * definition — not just the name — of every tool it recognises, so synthesised
 * stubs are rejected with 403 FreeTierError. These definitions are used for the
 * core tools this adapter injects into an agent-shaped payload.
 *
 * Provenance: captured from the official OpenCode client by the opencode2api
 * project (GPL-3.0-or-later, https://github.com/jasonxu114514/opencode2api,
 * internal/gateway/opencode_tools.json) and cross-checked against the client's
 * own wire traffic. Keep this file in sync when upstream rotates tool schemas.
 */
export interface OpenCodeToolDefinition {
  description: string
  parameters: Record<string, unknown>
}

export const OPENCODE_TOOL_DEFINITIONS: Record<string, OpenCodeToolDefinition> = {
  "edit": {
    "description": "Edit the contents of a file by finding and replacing exact text. When editing text from Read output, preserve the exact indentation (tabs or spaces) and omit the line-number prefix, such as `1: `. Never include the prefix in oldString or newString. Write line breaks as \\n; the file's existing CRLF or LF line endings are matched and preserved. To change line endings themselves, make oldString and newString differ only in \\r; that edit applies to the exact bytes. If there is no exact match, the edit retries while ignoring typographic quote, dash, and space variants, then trailing whitespace on each line. The edit fails if oldString is not found. By default, oldString must identify a UNIQUE location. Multiple matches FAIL unless replaceAll is true. Add more surrounding context to disambiguate, or set replaceAll to true to replace every occurrence. Use replaceAll when the change should apply to every occurrence, such as renaming a variable.",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "newString": {
          "description": "Text to replace oldString with (must differ from oldString)",
          "type": "string"
        },
        "oldString": {
          "description": "Exact text to find and replace",
          "type": "string"
        },
        "path": {
          "description": "File to edit",
          "type": "string"
        },
        "replaceAll": {
          "description": "Whether to replace every occurrence of oldString. When false, oldString must match exactly once. Defaults to false.",
          "type": "boolean"
        }
      },
      "required": [
        "path",
        "oldString",
        "newString"
      ],
      "type": "object"
    }
  },
  "execute": {
    "description": "Run JavaScript in a confined Code Mode runtime to script tool calls and HTTP requests and compose their results.\n`fetch` is available for HTTP requests. Imports, direct filesystem access, and timers are unavailable; all other external access goes through `tools`.\nWithin `{ code }`, the only callable tools are those explicitly listed in the Code Mode catalog instructions or returned by the `search` function. Inside `{ code }`, ignore tools shown outside the Code Mode catalog. They are not available in the Code Mode runtime.\nCall tools through `tools` using only exact paths and signatures from the catalog. Do not infer or normalize tool names; preserve bracket notation such as `tools.<namespace>[\"tool-name\"](input)`.\nPrefer an explicit `return`; if omitted, the final top-level expression becomes the result.\nAwait every call whose completion matters; pending calls are interrupted when execution ends. Run independent calls concurrently with `Promise.allSettled`.",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "code": {
          "type": "string"
        }
      },
      "required": [
        "code"
      ],
      "type": "object"
    }
  },
  "glob": {
    "description": "Search file paths using a glob pattern (examples: \"**/*.ts\", \"src/**/*.tsx\").",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "hidden": {
          "description": "Include hidden files and directories (default: false).",
          "type": "boolean"
        },
        "limit": {
          "description": "Maximum number of matching files to return (default: 100)",
          "exclusiveMinimum": 0,
          "type": "integer"
        },
        "path": {
          "description": "Directory to search. Defaults to the current working directory.",
          "type": "string"
        },
        "pattern": {
          "description": "Glob pattern to match files against",
          "type": "string"
        }
      },
      "required": [
        "pattern"
      ],
      "type": "object"
    }
  },
  "grep": {
    "description": "Search file contents using ripgrep's regular expression syntax or literal text matching. Use it to locate specific code, symbols, or text patterns, and narrow searches with `path` or `include`. Returns matching file paths, line numbers, and line previews.",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "caseSensitive": {
          "description": "Use case-sensitive matching (default: true).",
          "type": "boolean"
        },
        "include": {
          "description": "Glob pattern to filter files (for example, \"*.js\" or \"*.{ts,tsx}\")",
          "type": "string"
        },
        "limit": {
          "description": "Maximum number of matching lines to return (default: 100)",
          "exclusiveMinimum": 0,
          "type": "integer"
        },
        "literal": {
          "description": "Treat `pattern` as exact text instead of a regular expression (default: false).",
          "type": "boolean"
        },
        "path": {
          "description": "File or directory to search. Defaults to the current working directory.",
          "type": "string"
        },
        "pattern": {
          "description": "Regular expression or literal text to match in file contents.",
          "minLength": 1,
          "type": "string"
        }
      },
      "required": [
        "pattern"
      ],
      "type": "object"
    }
  },
  "question": {
    "description": "Use this tool when you need to ask the user questions during execution. This allows you to:\n1. Gather user preferences or requirements\n2. Clarify ambiguous instructions\n3. Get decisions on implementation choices as you work\n4. Offer choices to the user about what direction to take.\n\nUsage notes:\n- A \"Type your own answer\" option is added automatically; don't include a separate option for free form answers\n- Set `multiple: true` to allow selecting more than one option\n- If you recommend a specific option, make that the first option in the list and add \"(Recommended)\" at the end of the label",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "questions": {
          "description": "Questions to ask",
          "items": {
            "additionalProperties": false,
            "properties": {
              "header": {
                "description": "Very short label (max 30 chars)",
                "type": "string"
              },
              "multiple": {
                "type": "boolean"
              },
              "options": {
                "description": "Available choices",
                "items": {
                  "additionalProperties": false,
                  "properties": {
                    "description": {
                      "description": "Explanation of choice",
                      "type": "string"
                    },
                    "label": {
                      "description": "Display text (1-5 words, concise)",
                      "type": "string"
                    }
                  },
                  "required": [
                    "label",
                    "description"
                  ],
                  "type": "object"
                },
                "type": "array"
              },
              "question": {
                "description": "Complete question",
                "type": "string"
              }
            },
            "required": [
              "question",
              "header",
              "options"
            ],
            "type": "object"
          },
          "minItems": 1,
          "type": "array"
        }
      },
      "required": [
        "questions"
      ],
      "type": "object"
    }
  },
  "read": {
    "description": "Read the contents of a file or directory. Supports text files, images, and PDFs. Images and PDFs are presented directly to the model. Each text line is prefixed by its 1-based line number as <line>: <content>. The prefix is for reference and is not part of the file content. Directory entries are returned one per line. Use offset and limit to read large files or directories in sections. Prefer one larger read over many small slices, and use grep to find specific content in large files.",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "limit": {
          "description": "The maximum number of lines or directory entries to read (defaults to and capped at 2000)",
          "minimum": 0,
          "type": "integer"
        },
        "offset": {
          "description": "The line or directory entry to start reading from (1-based)",
          "minimum": 0,
          "type": "integer"
        },
        "path": {
          "description": "File or directory to read",
          "type": "string"
        }
      },
      "required": [
        "path"
      ],
      "type": "object"
    }
  },
  "shell": {
    "description": "Execute a shell command and return its output. Commands run on Windows using powershell. Quote file paths containing spaces or special characters. Prefer dedicated tools over shell commands when possible. When output is large, the full result is saved to a file and a truncated preview is returned. Rely on automatic truncation unless filtering the output is more useful. Commands accept an optional timeout, background commands have no timeout by default. Background commands return immediately, and you will be notified when they complete.",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "background": {
          "description": "Run the command in the background and return immediately (useful for dev servers and long-running builds). You do not need to use '&' at the end of the command when using this parameter. You will be notified when it completes. DO NOT poll for completion.",
          "type": "boolean"
        },
        "command": {
          "description": "Shell command string to execute",
          "type": "string"
        },
        "timeout": {
          "description": "Timeout in milliseconds. Set to 0 to disable the timeout. Defaults to 120000 for foreground commands. Background commands have no timeout by default.",
          "minimum": 0,
          "type": "integer"
        },
        "workdir": {
          "description": "Working directory to execute the command in. Defaults to the current working directory. When possible, avoid changing directories in the command and set the working directory here instead.",
          "type": "string"
        }
      },
      "required": [
        "command"
      ],
      "type": "object"
    }
  },
  "skill": {
    "description": "Load a specialized skill's instructions and resources into the current conversation when the task at hand matches its description.\n\nThe skill ID must match an available skill or a skill explicitly referenced by the user.",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "id": {
          "description": "The ID of an available skill or a skill explicitly referenced by the user",
          "type": "string"
        }
      },
      "required": [
        "id"
      ],
      "type": "object"
    }
  },
  "subagent": {
    "description": "Spawns an agent in a child session to work on the specified task.\nThe output includes a sessionID you can pass back later to continue that specific conversation with the subagent.\nNew child sessions start with fresh context, so include all relevant context and instructions when you don't pass a sessionID.\nForeground (default) runs the subagent to completion and returns its final response.\nBackground mode (background=true) launches it asynchronously and returns immediately; you are notified when it finishes.\nUse background only for independent work that can run while you continue elsewhere.\n\nAvailable subagents:\n- explore: Fast agent specialized for exploring codebases. Use this when you need to quickly find files by patterns (eg. \"src/components/**/*.tsx\"), search code for keywords (eg. \"API endpoints\"), or answer questions about the codebase (eg. \"how do API endpoints work?\"). When calling this agent, specify the desired thoroughness level: \"quick\" for basic searches, \"medium\" for moderate exploration, or \"very thorough\" for comprehensive analysis across multiple locations and naming conventions.\n- general: General-purpose agent for researching complex questions and executing multi-step tasks. Use this agent to execute multiple units of work in parallel.",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "agent": {
          "description": "The type of specialized agent to use for this task. If the user asks for a subagent by a name that is not one of the available subagents, they most likely mean a model: pick a suitable agent and pass the name through the model parameter instead.",
          "type": "string"
        },
        "background": {
          "description": "Run the subagent in the background and return immediately. You will be notified when it completes. DO NOT sleep, poll, or proactively check on its progress.",
          "type": "boolean"
        },
        "description": {
          "description": "A short 3-5 word label for the task, displayed to the user",
          "type": "string"
        },
        "model": {
          "description": "NEVER set this unless the user explicitly asks for a particular model or variant. The value is written as \"providerID/modelID\", or \"providerID/modelID#variant\" to include a variant. Do not guess the ID: look the model up with the models tool, filtering to your own provider first.",
          "type": "string"
        },
        "prompt": {
          "description": "The task for the subagent to perform",
          "type": "string"
        },
        "sessionID": {
          "description": "Continue a specific previous subagent conversation by passing its sessionID. Calls without a sessionID start a new conversation.",
          "pattern": "^ses",
          "type": "string"
        }
      },
      "required": [
        "agent",
        "description",
        "prompt"
      ],
      "type": "object"
    }
  },
  "webfetch": {
    "description": "Fetch content from an HTTP or HTTPS URL and return it as text, markdown, or HTML. Markdown is the default.\n\nUse a more targeted tool when one is available. This tool is read-only. Large text results may be replaced with a preview while the complete output is retained in managed storage.",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "format": {
          "description": "The format to return the content in. Defaults to markdown.",
          "enum": [
            "text",
            "markdown",
            "html"
          ],
          "type": "string"
        },
        "timeout": {
          "description": "Optional timeout in seconds (maximum: 120)",
          "exclusiveMinimum": 0,
          "maximum": 120,
          "type": "number"
        },
        "url": {
          "description": "The HTTP or HTTPS URL to fetch content from",
          "type": "string"
        }
      },
      "required": [
        "url"
      ],
      "type": "object"
    }
  },
  "websearch": {
    "description": "Search the web using the user's selected search integration. Use this for current information beyond knowledge cutoff.\n\nThe current year is 2026. Use this year when searching for recent information or current events.",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "query": {
          "description": "Websearch query",
          "type": "string"
        }
      },
      "required": [
        "query"
      ],
      "type": "object"
    }
  },
  "write": {
    "description": "Writes a file to the local filesystem, overwriting if one exists.\n\nMissing parent directories are created automatically.\n\nUse this tool to create new files or overwrite existing files. For partial changes, use the edit tool instead.",
    "parameters": {
      "additionalProperties": false,
      "properties": {
        "content": {
          "description": "Content to write to the file",
          "type": "string"
        },
        "path": {
          "description": "Path to the file to write to",
          "type": "string"
        }
      },
      "required": [
        "path",
        "content"
      ],
      "type": "object"
    }
  }
}
