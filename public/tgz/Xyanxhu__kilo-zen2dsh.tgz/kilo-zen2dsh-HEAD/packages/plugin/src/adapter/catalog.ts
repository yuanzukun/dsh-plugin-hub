import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'

import { outputCeilingForWindow } from './budget.ts'
import {
  OPENCODE_CAPABILITIES_URL,
  enrichZenModels,
  fetchOpenCodeCapabilities,
  type OpenCodeModelCapability,
} from './opencode-capabilities.ts'
import { opencodeUserAgent } from './opencode-identity.ts'

/**
 * Kilo's public OpenAI-compatible gateway.  The gateway deliberately keeps
 * the model directory separate from the chat endpoint: `/models` is public,
 * while unauthenticated completion requests are restricted to free models.
 */
export const KILO_API_BASE_URL = 'https://api.kilo.ai'
export const KILO_GATEWAY_BASE_URL = `${KILO_API_BASE_URL}/api/gateway`
export const KILO_MODELS_URL = `${KILO_GATEWAY_BASE_URL}/models`
/** OpenCode Zen's public OpenAI-compatible API root. */
export const OPENCODE_ZEN_BASE_URL = 'https://opencode.ai/zen'
export const OPENCODE_ZEN_GATEWAY_BASE_URL = `${OPENCODE_ZEN_BASE_URL}/v1`
export const OPENCODE_ZEN_MODELS_URL = `${OPENCODE_ZEN_GATEWAY_BASE_URL}/models`
/**
 * Base URL of the keyless free-tier lane. Since 2026-10-14 the anonymous lane
 * moved off `/zen` onto its own host; keyed traffic keeps using
 * `OPENCODE_ZEN_BASE_URL`. Both serve `/v1/models` and the inference paths.
 */
export const OPENCODE_ZEN_ANONYMOUS_BASE_URL = 'https://opencode.ai/inference'
export const OPENCODE_ZEN_ANONYMOUS_GATEWAY_BASE_URL = `${OPENCODE_ZEN_ANONYMOUS_BASE_URL}/v1`
/**
 * Public placeholder used by OpenCode itself when no Zen account key exists.
 * Source: https://github.com/anomalyco/opencode/blob/dev/packages/opencode/src/provider/provider.ts
 */
export const OPENCODE_ZEN_ANONYMOUS_API_KEY = 'public'
/** @deprecated Use OPENCODE_ZEN_BASE_URL for Zen or KILO_GATEWAY_BASE_URL for Kilo. */
export const ZEN_BASE_URL = OPENCODE_ZEN_BASE_URL
/**
 * Kilo's free lane is keyless.  Keep this export for callers that used the
 * old adapter's anonymous-key option, but deliberately make the default an
 * empty string so neither discovery nor completion sends Authorization.
 * A non-empty value is treated as an explicitly configured gateway token.
 */
export const ANONYMOUS_API_KEY = ''
export const KILO_USER_AGENT = 'kilo2dsh'

/**
 * A deliberately small bootstrap list.  It is only used while the public
 * catalog is unavailable; the live Kilo response is authoritative afterwards.
 * Keep this list to Kilo's stable virtual free routes rather than pinning
 * partner models that can disappear between catalog refreshes.
 */
export const staticFreeModels: string[] = [
  'kilo-auto/free',
  'openrouter/free',
]

/** Reserved for IDs seen in the catalog but not yet verified by a chat call. */
export const staticFreeCandidates: string[] = []

/**
 * OpenCode's documented Zen free models plus the reference project's
 * previously verified `hy3-free` route. The live `/v1/models` response is
 * authoritative; this list is only used while discovery is unavailable.
 * Zen's model endpoint currently returns IDs without pricing/capability data,
 * so the free suffix and the explicit `big-pickle` exception are the safe
 * local signal.
 * Source: https://dev.opencode.ai/docs/zen (free-model pricing/endpoints).
 */
export const zenStaticFreeModels: string[] = [
  'big-pickle',
  'hy3-free',
  'mimo-v2.5-free',
  'ling-3.0-flash-fin-free',
  'nemotron-3-ultra-free',
  'nemotron-3.5-lightning-free',
  'muse-spark-1.2-contributor-free',
]

/** Reserved for IDs observed in a live Zen catalog but not yet verified locally. */
export const zenStaticFreeCandidates: string[] = ['deepseek-v4-flash-free', 'laguna-s-2.1-free']

/**
 * Zen free models verified to accept image input (asked to describe a 1x1
 * red PNG and answered correctly through the anonymous lane). Zen's model
 * directory publishes no capability metadata, so without this table
 * dsh-llm projects these models text-only and strips pasted images before
 * dispatch. Extend as more models are verified.
 */
export const ZEN_VISION_MODEL_IDS: ReadonlySet<string> = new Set([
  'mimo-v2.6-flash-free',
  'mimo-v2.5-free',
  'space-bunny-free',
])

export interface KiloPricing {
  prompt?: string | number | null
  completion?: string | number | null
  input?: string | number | null
  output?: string | number | null
  input_cache_read?: string | number | null
  input_cache_write?: string | number | null
}

export interface KiloArchitecture {
  input_modalities?: string[] | null
  output_modalities?: string[] | null
  modality?: string | null
  [key: string]: unknown
}

export interface KiloModel {
  id: string
  name?: string
  description?: string
  context_length?: number | string | null
  /** OpenAI/DSH spelling used by a few compatible model directories. */
  contextWindow?: number | string | null
  context_window?: number | string | null
  max_context_tokens?: number | string | null
  max_completion_tokens?: number | string | null
  /** OpenAI/DSH spellings used by compatible model directories. */
  maxTokens?: number | string | null
  max_tokens?: number | string | null
  max_output_tokens?: number | string | null
  pricing?: KiloPricing | null
  architecture?: KiloArchitecture | null
  top_provider?: {
    context_length?: number | string | null
    contextWindow?: number | string | null
    context_window?: number | string | null
    max_completion_tokens?: number | string | null
    maxTokens?: number | string | null
    max_tokens?: number | string | null
    max_output_tokens?: number | string | null
    [key: string]: unknown
  } | null
  /** Optional provider-directory limit objects. */
  limit?: Record<string, unknown> | null
  limits?: Record<string, unknown> | null
  per_request_limits?: Record<string, unknown> | null
  supported_parameters?: string[] | null
  isFree?: boolean
  /** Older gateway deployments used snake_case for the same flag. */
  is_free?: boolean
  deprecated?: boolean
  mayTrainOnYourPrompts?: boolean
  opencode?: {
    ai_sdk_provider?: string
    family?: string
    prompt?: string
    variants?: Record<string, unknown>
    [key: string]: unknown
  } | null
  [key: string]: unknown
}

export interface KiloModelInfo {
  id: string
  name: string
  /** One-line model description, when the catalog carries one. */
  description?: string
  contextWindow: number
  maxTokens: number
  inputModalities: string[]
  reasoning: boolean
  /**
   * Selectable reasoning-effort ids for this model, in display order, or
   * undefined when the catalog advertises no reasoning control at all. DSH only
   * offers the levels an adapter declares here, and it rejects an undeclared
   * effort before provider I/O, so this list doubles as the accepted set.
   */
  reasoningEfforts?: string[]
  supportsTools: boolean
}

export interface AnonymousDecision {
  allowed: boolean
  source: string
  /** True when the decision came from a live, explicit catalog record. */
  known: boolean
}

export interface ModelPrice {
  input?: number
  output?: number
  deprecated: boolean
  /** Optional authoritative Kilo free flag (not present in old fixtures). */
  free?: boolean
}

const DEFAULT_CONTEXT_WINDOW = 262144
const DEFAULT_MAX_TOKENS = 32768

/**
 * The Kilo gateway currently rejects completion requests above 524288 tokens
 * even when an upstream catalog record advertises a larger value (MiniMax-M3
 * currently reports 943718). Keep this as a gateway compatibility ceiling;
 * model-specific limits below it still win.
 */
export const KILO_GATEWAY_MAX_OUTPUT_TOKENS = 524_288

export interface ModelInfoOptions {
  /** Gateway-specific output ceiling; null disables the compatibility cap. */
  gatewayMaxOutputTokens?: number | null
  /**
   * Vision-capable model ids keyed exactly. Zen's public `/v1/models`
   * records carry no capability metadata at all, so vision-capable free
   * models would otherwise be projected text-only and dsh-llm would strip
   * image input before dispatch. An override adds image to the declared
   * modalities; it never removes one.
   */
  visionOverrides?: ReadonlySet<string>
}

function optionalTrim(value: string | undefined): string | undefined {
  const trimmed = value?.trim()
  return trimmed ? trimmed : undefined
}

function asFiniteNumber(value: unknown): number | undefined {
  if (typeof value === 'number') return Number.isFinite(value) ? value : undefined
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value)
    return Number.isFinite(parsed) ? parsed : undefined
  }
  return undefined
}

function positiveInteger(value: unknown): number | undefined {
  const parsed = asFiniteNumber(value)
  if (parsed === undefined || parsed <= 0) return undefined
  return Math.min(Number.MAX_SAFE_INTEGER, Math.max(1, Math.floor(parsed)))
}

function normalizedGatewayMaxOutputTokens(value: number | null | undefined): number | null {
  if (value === null) return null
  return positiveInteger(value) ?? KILO_GATEWAY_MAX_OUTPUT_TOKENS
}

/** Accept the boolean spellings used by JSON gateways without guessing unknown values. */
function explicitBoolean(value: unknown): boolean | undefined {
  if (typeof value === 'boolean') return value
  if (typeof value === 'number' && (value === 0 || value === 1)) return value === 1
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase()
    if (normalized === 'true' || normalized === '1' || normalized === 'yes') return true
    if (normalized === 'false' || normalized === '0' || normalized === 'no') return false
  }
  return undefined
}

function isZero(value: unknown): boolean {
  const parsed = asFiniteNumber(value)
  return parsed !== undefined && parsed === 0
}

function modelId(value: string | KiloModel | unknown): string {
  if (typeof value === 'string') return value.trim()
  if (value && typeof value === 'object' && typeof (value as { id?: unknown }).id === 'string') {
    return (value as { id: string }).id.trim()
  }
  return ''
}

function hasFreeSuffix(id: string): boolean {
  const lower = id.toLowerCase()
  return lower === 'kilo-auto/free' || lower === 'openrouter/free' || lower.endsWith(':free') || lower.endsWith('-free')
}

function hasZenFreeName(id: string): boolean {
  const lower = id.toLowerCase()
  return lower === 'big-pickle' || lower.endsWith(':free') || lower.endsWith('-free')
}

/**
 * Decide whether a Kilo model is part of the free lane.
 *
 * Kilo's `isFree` flag is authoritative.  The suffix checks are intentional
 * compatibility fallbacks for older gateway deployments and for OpenRouter's
 * conventional `:free` IDs.  Zero pricing is accepted only for a recognised
 * free ID/router; this avoids accidentally treating incomplete pricing data as
 * anonymous access.
 */
export function isFreeModel(value: string | KiloModel | unknown): boolean {
  const id = modelId(value)
  if (!id) return false

  if (value && typeof value === 'object' && !Array.isArray(value)) {
    const model = value as KiloModel
    if (explicitBoolean(model.deprecated) === true) return false
    // Match Kilo/QwenPaw field precedence exactly: camelCase first, then the
    // legacy snake_case spelling. Only absent flags use the name fallback.
    const camelFlag = explicitBoolean(model.isFree)
    if (camelFlag !== undefined) return camelFlag
    const snakeFlag = explicitBoolean(model.is_free)
    if (snakeFlag !== undefined) return snakeFlag
    const pricing = model.pricing ?? undefined
    const prompt = pricing?.prompt ?? pricing?.input
    const completion = pricing?.completion ?? pricing?.output
    if (hasFreeSuffix(id)) return true
    // Kilo-native routers have a stable free namespace.  For vendor models,
    // require the explicit `:free`/`-free` suffix above.
    return isZero(prompt) && isZero(completion) && (/^kilo-auto\//i.test(id) || /^openrouter\//i.test(id))
  }

  return hasFreeSuffix(id)
}

/**
 * Decide whether a model exposed by OpenCode Zen belongs to its free lane.
 * Zen's public `/v1/models` records do not currently include pricing or an
 * `isFree` flag, so only the documented `*-free`/`*:free` names and the
 * documented `big-pickle` exception are accepted. Explicit flags, when a
 * future deployment supplies them, remain authoritative.
 */
export function isZenFreeModel(value: string | KiloModel | unknown): boolean {
  const id = modelId(value)
  if (!id) return false
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    const model = value as KiloModel
    if (explicitBoolean(model.deprecated) === true) return false
    const camelFlag = explicitBoolean(model.isFree)
    if (camelFlag !== undefined) return camelFlag
    const snakeFlag = explicitBoolean(model.is_free)
    if (snakeFlag !== undefined) return snakeFlag
  }
  return hasZenFreeName(id)
}

function isTextOutputModel(model: KiloModel): boolean {
  const output = model.architecture?.output_modalities
  if (!Array.isArray(output) || output.length === 0) return true
  return !output.some((modality) => String(modality).trim().toLowerCase() === 'image')
}

function supportsTools(model: KiloModel): boolean {
  const parameters = model.supported_parameters
  // Kilo treats a missing capability list as optimistic/compatible.
  return !Array.isArray(parameters) || parameters.length === 0 || parameters.some((parameter) => String(parameter).trim().toLowerCase() === 'tools')
}

/**
 * Reasoning-effort ids every reasoning-capable Kilo model is offered.
 *
 * OpenRouter-flavoured gateways accept the nested `reasoning: { effort }`
 * object that pi-ai's `openrouter` thinking format emits. Measured against the
 * live gateway on `qwen/qwen3.8-27b:free` (reasoning tokens for one step-by-step
 * prompt): `minimal`/`low` 399, `medium`/`high` 429, `xhigh`/`max` 499, so the
 * high tiers are real and distinct rather than aliases of `high`. `xhigh` and
 * `max` also answered 200 on every other free model probed
 * (`stepfun/step-3.7-flash:free`, `nvidia/nemotron-3-super-120b-a12b:free`,
 * `apodex/apodex-1.1-mini:free`, `dots-studio/dots-3-note-preview:free`), so
 * the full pi-ai scale is offered.
 */
const KILO_REASONING_EFFORTS = ['minimal', 'low', 'medium', 'high', 'xhigh', 'max'] as const

/**
 * Whether this record advertises any reasoning control.
 *
 * `supported_parameters` mirrors OpenRouter's capability list: `reasoning` and
 * `include_reasoning` mean the nested reasoning object is accepted, and
 * `reasoning_effort` additionally means the OpenAI-style scalar is accepted.
 * 307 of the live catalog's 401 records list at least one of them, including
 * every free-lane model.
 */
function supportsReasoning(model: KiloModel): boolean {
  const parameters = model.supported_parameters
  if (!Array.isArray(parameters)) return false
  return parameters.some((parameter) => {
    const name = String(parameter).trim().toLowerCase()
    return name === 'reasoning' || name === 'include_reasoning' || name === 'reasoning_effort'
  })
}

function normalizeModel(raw: unknown): KiloModel | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null
  const candidate = raw as Record<string, unknown>
  if (typeof candidate.id !== 'string' || candidate.id.trim() === '') return null
  const model: KiloModel = { ...(candidate as KiloModel), id: candidate.id.trim() }
  model.name = typeof candidate.name === 'string' && candidate.name.trim() !== '' ? candidate.name.trim() : model.id
  return model
}

/** Decode Kilo's `{ data: [...] }` model response, deduplicating IDs. */
export function decodeKiloModels(data: unknown): KiloModel[] {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return []
  const rows = (data as { data?: unknown }).data
  if (!Array.isArray(rows)) return []
  const seen = new Set<string>()
  const models: KiloModel[] = []
  for (const row of rows) {
    const model = normalizeModel(row)
    if (!model || seen.has(model.id)) continue
    seen.add(model.id)
    models.push(model)
  }
  return models
}

/** OpenAI-shaped ID helper retained for sidecar/provider integrations. */
export function decodeKiloModelIds(data: unknown): string[] {
  return decodeKiloModels(data).map((model) => model.id)
}

/** Backwards-compatible alias used by early adapters. */
export const decodeModels = decodeKiloModels

/**
 * Compatibility decoder for the reference project's models.dev fixture shape.
 * Kilo no longer needs a second metadata service, but keeping this helper
 * makes migrations and downstream tests source-compatible.
 */
export function decodeModelsDev(data: unknown): Map<string, ModelPrice> {
  const kiloModels = decodeKiloModels(data)
  if (kiloModels.length > 0) {
    const result = new Map<string, ModelPrice>()
    for (const model of kiloModels) {
      const pricing = model.pricing ?? {}
      result.set(model.id, {
        input: asFiniteNumber(pricing.prompt ?? pricing.input),
        output: asFiniteNumber(pricing.completion ?? pricing.output),
        deprecated: model.deprecated === true,
        free: isFreeModel(model),
      })
    }
    return result
  }

  if (!data || typeof data !== 'object' || Array.isArray(data)) return new Map()
  const providers = data as Record<string, unknown>
  const keys = Object.keys(providers).sort((left, right) => {
    const rank = (key: string): number => {
      const lower = key.toLowerCase()
      if (lower === 'kilo' || lower === 'kilo-gateway') return 0
      if (lower.includes('kilo')) return 1
      if (lower === 'opencode' || lower === 'opencode-zen' || lower === 'opencode_zen') return 2
      if (lower.includes('opencode')) return 3
      return 4
    }
    return rank(left) - rank(right) || left.localeCompare(right)
  })
  for (const key of keys) {
    const provider = providers[key]
    if (!provider || typeof provider !== 'object' || Array.isArray(provider)) continue
    const models = (provider as { models?: unknown }).models
    if (!models || typeof models !== 'object' || Array.isArray(models)) continue
    const result = new Map<string, ModelPrice>()
    for (const [modelKey, raw] of Object.entries(models as Record<string, unknown>)) {
      if (!raw || typeof raw !== 'object' || Array.isArray(raw)) continue
      const record = raw as Record<string, unknown>
      const id = typeof record.id === 'string' && record.id.length > 0 ? record.id : modelKey
      const cost = (record.cost ?? record.pricing ?? {}) as Record<string, unknown>
      result.set(id, {
        input: asFiniteNumber(cost.input ?? cost.prompt),
        output: asFiniteNumber(cost.output ?? cost.completion),
        deprecated: metadataDeprecated(record),
      })
    }
    if (result.size > 0) return result
  }
  return new Map()
}

function metadataDeprecated(model: Record<string, unknown>): boolean {
  if (model.deprecated === true) return true
  const status = String(model.status ?? model.lifecycle ?? '').toLowerCase()
  return status === 'deprecated' || status === 'retired' || status === 'disabled' || model.deprecated_at != null || model.retirement_date != null
}

export function modelInfo(model: KiloModel, options: ModelInfoOptions = {}): KiloModelInfo {
  const modelRecord = model as unknown as Record<string, unknown>
  const records: Record<string, unknown>[] = [modelRecord]
  for (const candidate of [model.top_provider, model.limit, model.limits, model.per_request_limits]) {
    if (candidate && typeof candidate === 'object' && !Array.isArray(candidate)) {
      records.push(candidate as Record<string, unknown>)
    }
  }

  // Directory implementations disagree on whether limits live on the model,
  // top_provider, or a nested `limit(s)` object.  Taking the smallest positive
  // declaration is conservative and handles providers that report a smaller
  // effective context than their marketing-level model record.
  const positiveLimits = (keys: readonly string[]): number[] => {
    const values: number[] = []
    for (const record of records) {
      for (const key of keys) {
        const limit = positiveInteger(record[key])
        if (limit !== undefined) values.push(limit)
      }
    }
    return values
  }

  const contextLimits = positiveLimits(['context_length', 'contextWindow', 'context_window', 'max_context_tokens', 'context'])
  const contextWindow = contextLimits.length > 0 ? Math.min(...contextLimits) : DEFAULT_CONTEXT_WINDOW
  const outputLimits = positiveLimits([
    'max_completion_tokens',
    'maxTokens',
    'max_tokens',
    'max_output_tokens',
    'output_tokens',
    'output',
  ])
  const advertisedMax = outputLimits.length > 0 ? Math.min(...outputLimits) : DEFAULT_MAX_TOKENS
  // The output budget can never exceed the combined context, the selected
  // gateway's compatibility ceiling, or the share of the window the harness can
  // afford to reserve on every request. This is what DSH materializes as
  // `defaultMaxTokens` and what compaction-basic reserves before it can derive a
  // pressure threshold, so a directory advertising "output = 90% of the window"
  // (Kilo's free lane does) is translated here instead of passed through — see
  // adapter/budget.ts.
  const gatewayMax = normalizedGatewayMaxOutputTokens(options.gatewayMaxOutputTokens) ?? Number.MAX_SAFE_INTEGER
  const maxTokens = Math.min(advertisedMax, contextWindow, gatewayMax, outputCeilingForWindow(contextWindow))
  const declaredInput = Array.isArray(model.architecture?.input_modalities)
    ? model.architecture!.input_modalities!.map(String).filter(Boolean)
    : ['text']
  if (!declaredInput.includes('text')) declaredInput.unshift('text')
  const description =
    typeof model.description === 'string' && model.description.trim() !== '' ? model.description.trim() : undefined
  // DSH/pi-ai can only express text and image; a gateway that also lists
  // video/audio still accepts both, so the extra modalities are dropped here.
  const inputModalities = declaredInput.filter((modality) => modality === 'text' || modality === 'image')
  if (inputModalities.length === 0) inputModalities.push('text')
  if (options.visionOverrides?.has(model.id) && !inputModalities.includes('image')) inputModalities.push('image')
  const reasoning = supportsReasoning(model)
  return {
    id: model.id,
    name: typeof model.name === 'string' && model.name.length > 0 ? model.name : model.id,
    ...(description === undefined ? {} : { description }),
    contextWindow,
    maxTokens,
    inputModalities,
    reasoning,
    // No defaultEffort on purpose: leaving the choice to the provider measured
    // the *strongest* observed tier (499 reasoning tokens, equal to `xhigh` and
    // `max`), so pinning a lower level would silently make every session think
    // less than the model would on its own. The selector shows "provider
    // default" until a level is chosen.
    ...(reasoning ? { reasoningEfforts: [...KILO_REASONING_EFFORTS] } : {}),
    supportsTools: supportsTools(model),
  }
}

export interface CatalogSnapshot {
  status: 'pending' | 'ready' | 'stale' | 'error'
  total: number
  exposed: number
  lastRefresh?: string
}

export interface CatalogOptions {
  refreshSeconds?: number
  cachePath?: string
  /** Base URL ending in `/api/gateway`, overridable for tests/self-hosting. */
  gatewayBaseUrl?: string
  /** @deprecated Use gatewayBaseUrl. Accepted for source compatibility. */
  zenBaseUrl?: string
  /** Fully qualified models URL; takes precedence over gatewayBaseUrl. */
  modelsUrl?: string
  /** @deprecated Kilo publishes pricing in /models; this is ignored. */
  metadataUrl?: string
  /** Optional Kilo token.  Omit it to use the public anonymous lane. */
  apiKey?: string
  /** Custom anonymous token for compatible gateway deployments. */
  anonymousKey?: string
  /** Static bootstrap IDs used only before a live snapshot is available. */
  staticModels?: readonly string[]
  /** Static IDs that may be admitted while discovery is pending. */
  staticCandidates?: readonly string[]
  /** Provider-specific free-model classifier. Defaults to Kilo rules. */
  freePredicate?: (value: string | KiloModel | unknown) => boolean
  /** User-Agent sent to the model directory. */
  userAgent?: string
  /** Provider-specific model-directory fetcher. */
  fetchCatalog?: CatalogFetcher
  /**
   * OpenCode capability catalog used to fill the limits, modality and
   * capability metadata that Zen's minimal `/v1/models` directory omits.
   * Defaults to https://models.opencode.ai/api.json; an empty string
   * disables the enrichment. Only the Zen catalog consults it.
   */
  capabilitiesUrl?: string
  /** Human-readable provider label used in diagnostics. */
  catalogLabel?: string
  /** Additional headers sent to the model directory. */
  extraHeaders?: Record<string, string>
  /** Require an explicit `tools` capability for exposed agent models. */
  requireTools?: boolean
  /** Gateway-specific output ceiling; null disables the Kilo compatibility cap. */
  gatewayMaxOutputTokens?: number | null
  fetchImpl?: typeof fetch
  now?: () => number
  onRefresh?: (status: CatalogSnapshot, lastError: string) => void
  startupRetryMs?: number
  staleAfterMs?: number
}

export type CatalogFetcher = (
  modelsUrl: string,
  fetchImpl: typeof fetch,
  options?: FetchKiloModelsOptions,
) => Promise<KiloModel[]>

const FETCH_TIMEOUT_MS = 30_000
const CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000

interface ModelCache {
  updatedAt: number
  models: KiloModel[]
}

/**
 * Live Kilo model directory.  Unlike the OpenCode implementation it does not
 * need a second models.dev request: Kilo publishes `isFree` and pricing in
 * the same response as the live catalog.
 */
export class ModelCatalog {
  #models = new Map<string, KiloModel>()
  #updatedAt = 0
  #lastError = ''
  #refreshSeconds: number
  #cachePath?: string
  #modelsUrl: string
  #apiKey?: string
  #anonymousKey: string
  #staticModels: string[]
  #staticCandidates: string[]
  #freePredicate: (value: string | KiloModel | unknown) => boolean
  #userAgent: string
  #extraHeaders: Record<string, string>
  #fetchCatalog: CatalogFetcher
  #catalogLabel: string
  #requireTools: boolean
  #gatewayMaxOutputTokens: number | null
  #fetch: typeof fetch
  #now: () => number
  #timer: NodeJS.Timeout | null = null
  #stopped = false
  #onRefresh?: (status: CatalogSnapshot, lastError: string) => void
  #startupRetryMs: number
  #staleAfterMs: number

  constructor(options: CatalogOptions = {}) {
    this.#refreshSeconds = Math.max(1, options.refreshSeconds ?? 300)
    this.#cachePath = options.cachePath
    const gatewayBase = optionalTrim(options.gatewayBaseUrl) ?? optionalTrim(options.zenBaseUrl) ?? KILO_GATEWAY_BASE_URL
    this.#modelsUrl = optionalTrim(options.modelsUrl) ?? `${gatewayBase.replace(/\/+$/, '')}/models`
    this.#apiKey = options.apiKey?.trim() || undefined
    // Preserve an explicitly supplied empty string: Zen callers can use it to
    // request a truly header-less deployment instead of falling back to
    // `public`. Whitespace-only values are treated as empty as well.
    this.#anonymousKey = options.anonymousKey === undefined ? ANONYMOUS_API_KEY : options.anonymousKey?.trim() ?? ''
    this.#staticModels = [...(options.staticModels ?? staticFreeModels)]
    this.#staticCandidates = [...(options.staticCandidates ?? staticFreeCandidates)]
    this.#freePredicate = options.freePredicate ?? isFreeModel
    this.#userAgent = options.userAgent?.trim() || KILO_USER_AGENT
    this.#extraHeaders = { ...(options.extraHeaders ?? {}) }
    this.#fetchCatalog = options.fetchCatalog ?? fetchKiloModelCatalog
    this.#catalogLabel = options.catalogLabel?.trim() || 'Kilo'
    this.#requireTools = options.requireTools ?? true
    this.#gatewayMaxOutputTokens = normalizedGatewayMaxOutputTokens(options.gatewayMaxOutputTokens)
    this.#fetch = options.fetchImpl ?? fetch
    this.#now = options.now ?? Date.now
    this.#onRefresh = options.onRefresh
    this.#startupRetryMs = Math.max(0, options.startupRetryMs ?? 15_000)
    this.#staleAfterMs = Math.max(1, options.staleAfterMs ?? 10 * 60 * 1000)
  }

  async start(): Promise<void> {
    await this.refreshOnce()
    let attempts = 0
    while (this.#models.size === 0 && attempts < 4 && !this.#stopped) {
      attempts += 1
      if (this.#startupRetryMs > 0) await new Promise((resolve) => setTimeout(resolve, this.#startupRetryMs))
      if (this.#stopped) return
      await this.refreshOnce()
    }
    if (this.#stopped) return
    this.#timer = setInterval(() => void this.refreshOnce(), this.#refreshSeconds * 1000)
    this.#timer.unref?.()
  }

  stop(): void {
    this.#stopped = true
    if (this.#timer) {
      clearInterval(this.#timer)
      this.#timer = null
    }
  }

  async refreshOnce(): Promise<void> {
    await this.refreshGateway()
    try {
      this.#onRefresh?.(this.snapshot(), this.#lastError)
    } catch {
      // Observers must never break a refresh loop.
    }
  }

  async refreshGateway(): Promise<void> {
    try {
      const models = await this.#fetchCatalog(this.#modelsUrl, this.#fetch, {
        apiKey: this.#apiKey,
        anonymousKey: this.#anonymousKey,
        userAgent: this.#userAgent,
        extraHeaders: this.#extraHeaders,
      })
      if (models.length === 0) throw new Error(`${this.#catalogLabel} models endpoint returned an empty list`)
      this.#models = new Map(models.map((model) => [model.id, model]))
      this.#updatedAt = this.#now()
      this.#lastError = ''
      if (this.#cachePath) await saveModelCache(this.#cachePath, models, this.#updatedAt)
    } catch (err) {
      // A cached catalog is useful during a transient Kilo outage, but never
      // replaces a newer live snapshot.
      if (this.#cachePath && this.#models.size === 0) {
        const cached = await loadModelCache(this.#cachePath, this.#now()).catch(() => null)
        if (cached && cached.models.length > 0) {
          this.#models = new Map(cached.models.map((model) => [model.id, model]))
          this.#updatedAt = cached.updatedAt
          this.#lastError = err instanceof Error ? err.message : String(err)
          return
        }
      }
      this.#lastError = err instanceof Error ? err.message : String(err)
    }
  }

  /** Compatibility method for callers that used the old Zen naming. */
  async refreshZen(): Promise<void> {
    return this.refreshGateway()
  }

  decision(model: string): AnonymousDecision {
    const id = model.trim()
    const live = this.#models.get(id)
    if (live) {
      if (!this.#freePredicate(live)) return { allowed: false, source: 'catalog_paid', known: true }
      if (!isTextOutputModel(live)) return { allowed: false, source: 'catalog_output_unsupported', known: true }
      if (this.#requireTools && !supportsTools(live)) return { allowed: false, source: 'catalog_tools_unsupported', known: true }
      return { allowed: true, source: 'catalog_free', known: true }
    }
    if (this.#models.size === 0) {
      if (this.#staticModels.includes(id) || this.#staticCandidates.includes(id)) {
        return { allowed: true, source: 'static_verified', known: false }
      }
      if (this.#freePredicate(id)) return { allowed: true, source: 'name_free_pending', known: false }
      return { allowed: false, source: 'catalog_pending', known: false }
    }
    return { allowed: false, source: 'catalog_missing', known: false }
  }

  /** IDs exposed to DSH: live free text models, or static bootstrap IDs. */
  list(): string[] {
    if (this.#models.size === 0) return [...this.#staticModels]
    const out: string[] = []
    for (const model of this.#models.values()) {
      if (this.decision(model.id).allowed) out.push(model.id)
    }
    return out.sort()
  }

  listDetails(): KiloModelInfo[] {
    const details: KiloModelInfo[] = []
    for (const id of this.list()) {
      const model = this.#models.get(id)
      const options = { gatewayMaxOutputTokens: this.#gatewayMaxOutputTokens }
      details.push(model ? modelInfo(model, options) : modelInfo({ id, name: id }, options))
    }
    return details
  }

  get(model: string): KiloModel | undefined {
    return this.#models.get(model.trim())
  }

  snapshot(): CatalogSnapshot {
    const age = this.#updatedAt === 0 ? Infinity : this.#now() - this.#updatedAt
    const stale = this.#updatedAt !== 0 && age > this.#staleAfterMs
    return {
      status: this.#updatedAt === 0 ? (this.#lastError ? 'error' : 'pending') : stale ? 'stale' : 'ready',
      total: this.#models.size,
      exposed: this.list().length,
      ...(this.#updatedAt !== 0 ? { lastRefresh: new Date(this.#updatedAt).toISOString() } : {}),
    }
  }

  get lastError(): string {
    return this.#lastError
  }

  get modelsUrl(): string {
    return this.#modelsUrl
  }
}

/** Capability metadata is refetched at most this often (the document is static for weeks). */
const CAPABILITY_TTL_MS = 6 * 60 * 60 * 1000

/**
 * Wrap Zen's models fetcher with capability enrichment. The capability
 * document (models.opencode.ai/api.json) is memoized for six hours; a
 * transport or HTTP failure leaves the unenriched records in place —
 * discovery must never depend on the metadata service.
 */
function enrichingZenFetcher(capabilitiesUrl: string): CatalogFetcher {
  let cached: { capabilities: Map<string, OpenCodeModelCapability>; at: number } | null = null
  return async (modelsUrl, fetchImpl, options = {}) => {
    const models = await fetchZenCatalogAtUrl(modelsUrl, fetchImpl, options)
    try {
      const now = Date.now()
      if (cached === null || now - cached.at > CAPABILITY_TTL_MS) {
        const capabilities = await fetchOpenCodeCapabilities(capabilitiesUrl, fetchImpl, {
          userAgent: options.userAgent?.trim() || defaultOpenCodeZenUserAgent(),
          signal: options.signal,
        })
        cached = { capabilities, at: now }
      }
      return enrichZenModels(models, cached.capabilities)
    } catch {
      // Stale-but-valid metadata still beats the hard-coded fallbacks.
      if (cached !== null) return enrichZenModels(models, cached.capabilities)
      return models
    }
  }
}

/**
 * OpenCode Zen variant of ModelCatalog. It keeps a separate cache and free
 * classifier because Zen's `/v1/models` response is a minimal OpenAI list,
 * unlike Kilo's richer gateway records. The default fetcher enriches those
 * bare records with the limits and capability flags from OpenCode's public
 * capability catalog, so DSH sees real context windows instead of the
 * 256K/32K fallbacks.
 */
export class ZenModelCatalog extends ModelCatalog {
  constructor(options: CatalogOptions = {}) {
    // The keyless lane and the keyed lane live on different hosts since
    // 2026-10-14. An explicit base always wins, but the default follows the
    // lane: no account key means anonymous traffic on /inference.
    const defaultBase = options.apiKey?.trim() ? OPENCODE_ZEN_BASE_URL : OPENCODE_ZEN_ANONYMOUS_BASE_URL
    const zenGateway = normalizeZenGatewayUrl(
      optionalTrim(options.gatewayBaseUrl) ?? optionalTrim(options.zenBaseUrl) ?? defaultBase,
    )
    const capabilitiesUrl =
      options.capabilitiesUrl === undefined ? OPENCODE_CAPABILITIES_URL : options.capabilitiesUrl.trim()
    const defaultFetcher = capabilitiesUrl === '' ? fetchZenCatalogAtUrl : enrichingZenFetcher(capabilitiesUrl)
    super({
      ...options,
      gatewayBaseUrl: zenGateway,
      modelsUrl: optionalTrim(options.modelsUrl) ?? `${zenGateway}/models`,
      anonymousKey: options.anonymousKey ?? OPENCODE_ZEN_ANONYMOUS_API_KEY,
      staticModels: options.staticModels ?? zenStaticFreeModels,
      staticCandidates: options.staticCandidates ?? zenStaticFreeCandidates,
      freePredicate: options.freePredicate ?? isZenFreeModel,
      userAgent: options.userAgent?.trim() || defaultOpenCodeZenUserAgent(),
      extraHeaders: { 'x-opencode-client': 'cli', ...(options.extraHeaders ?? {}) },
      fetchCatalog: options.fetchCatalog ?? defaultFetcher,
      catalogLabel: options.catalogLabel ?? 'OpenCode Zen',
      gatewayMaxOutputTokens: options.gatewayMaxOutputTokens ?? null,
    })
  }
}

export interface FetchKiloModelsOptions {
  apiKey?: string
  anonymousKey?: string
  userAgent?: string
  extraHeaders?: Record<string, string>
  signal?: AbortSignal
}

/** Provider-neutral spelling for Zen callers; fields are identical. */
export type FetchZenModelsOptions = FetchKiloModelsOptions

/** Fetch and decode the full Kilo model catalog. */
export async function fetchKiloModelCatalog(
  modelsUrl: string,
  fetchImpl: typeof fetch = fetch,
  options: FetchKiloModelsOptions = {},
): Promise<KiloModel[]> {
  const token = options.apiKey?.trim() || options.anonymousKey?.trim()
  const response = await fetchWithTimeout(
    fetchImpl,
    modelsUrl,
    {
      method: 'GET',
      headers: {
        accept: 'application/json',
        'user-agent': options.userAgent?.trim() || KILO_USER_AGENT,
        ...(options.extraHeaders ?? {}),
        ...(token ? { authorization: `Bearer ${token}` } : {}),
      },
      signal: options.signal,
    },
  )
  if (!response.ok) throw new Error(`Kilo models endpoint returned HTTP ${response.status}`)
  const models = decodeKiloModels(await response.json())
  if (models.length === 0) throw new Error('Kilo models endpoint returned an empty list')
  return models
}

/**
 * ID-only convenience helper.  It mirrors the old adapter's fetch function
 * while using Kilo's documented `/models` endpoint and anonymous semantics.
 */
export async function fetchKiloModels(
  gatewayOrModelsUrl: string,
  fetchImpl: typeof fetch = fetch,
  optionsOrUserAgent: FetchKiloModelsOptions | string = {},
): Promise<string[]> {
  const modelsUrl = /\/models(?:\/)?$/.test(gatewayOrModelsUrl)
    ? gatewayOrModelsUrl
    : `${gatewayOrModelsUrl.replace(/\/+$/, '')}/models`
  const options = typeof optionsOrUserAgent === 'string' ? { userAgent: optionsOrUserAgent } : optionsOrUserAgent
  return (await fetchKiloModelCatalog(modelsUrl, fetchImpl, options)).map((model) => model.id)
}

/** Fetch and decode OpenCode Zen's `/v1/models` catalog. */
export async function fetchZenModelCatalog(
  zenBaseOrModelsUrl: string,
  fetchImpl: typeof fetch = fetch,
  options: FetchKiloModelsOptions = {},
): Promise<KiloModel[]> {
  const modelsUrl = normalizeZenModelsUrl(zenBaseOrModelsUrl)
  return fetchZenCatalogAtUrl(modelsUrl, fetchImpl, options)
}

/**
 * Zen's anonymous lane uses the public placeholder and OpenCode-compatible
 * client marker. An explicitly supplied key replaces `public` as usual.
 */
export async function fetchZenCatalogAtUrl(
  modelsUrl: string,
  fetchImpl: typeof fetch = fetch,
  options: FetchKiloModelsOptions = {},
): Promise<KiloModel[]> {
  const configuredApiKey = options.apiKey?.trim()
  const configuredAnonymousKey =
    options.anonymousKey === undefined ? undefined : options.anonymousKey?.trim() ?? ''
  const token = configuredApiKey || configuredAnonymousKey || (configuredAnonymousKey === '' ? '' : OPENCODE_ZEN_ANONYMOUS_API_KEY)
  const response = await fetchWithTimeout(
    fetchImpl,
    modelsUrl,
    {
      method: 'GET',
      headers: {
        accept: 'application/json',
        'user-agent': options.userAgent?.trim() || defaultOpenCodeZenUserAgent(),
        'x-opencode-client': 'cli',
        ...(options.extraHeaders ?? {}),
        ...(token ? { authorization: `Bearer ${token}` } : {}),
      },
      signal: options.signal,
    },
  )
  if (!response.ok) throw new Error(`OpenCode Zen models endpoint returned HTTP ${response.status}`)
  const models = decodeKiloModels(await response.json())
  if (models.length === 0) throw new Error('OpenCode Zen models endpoint returned an empty list')
  return models
}

/** Old ID-only spelling retained for callers of the original Zen adapter. */
export async function fetchZenModels(
  zenBaseOrModelsUrl: string,
  fetchImpl: typeof fetch = fetch,
  optionsOrUserAgent: FetchKiloModelsOptions | string = {},
): Promise<string[]> {
  const options = typeof optionsOrUserAgent === 'string' ? { userAgent: optionsOrUserAgent } : optionsOrUserAgent
  return (await fetchZenModelCatalog(zenBaseOrModelsUrl, fetchImpl, options)).map((model) => model.id)
}

export function normalizeZenModelsUrl(value: string): string {
  const trimmed = (value.trim() || OPENCODE_ZEN_BASE_URL).replace(/\/+$/, '')
  if (/\/models$/i.test(trimmed)) return trimmed
  if (/\/v1$/i.test(trimmed)) return `${trimmed}/models`
  return `${trimmed}/v1/models`
}

export function normalizeZenGatewayUrl(value: string): string {
  const trimmed = (value.trim() || OPENCODE_ZEN_BASE_URL).replace(/\/+$/, '')
  return /\/v1$/i.test(trimmed) ? trimmed : `${trimmed}/v1`
}

function defaultOpenCodeZenUserAgent(): string {
  // Discovery and inference must present the same client identity; the
  // shared implementation lives in opencode-identity.ts.
  return opencodeUserAgent()
}

async function fetchWithTimeout(
  fetchImpl: typeof fetch,
  input: string,
  init: RequestInit,
  timeoutMs = FETCH_TIMEOUT_MS,
): Promise<Response> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  const signal = init.signal
  const abort = () => controller.abort(signal?.reason)
  if (signal) {
    if (signal.aborted) abort()
    else signal.addEventListener('abort', abort, { once: true })
  }
  try {
    return await fetchImpl(input, { ...init, signal: controller.signal })
  } finally {
    clearTimeout(timer)
    signal?.removeEventListener('abort', abort)
  }
}

async function saveModelCache(path: string, models: KiloModel[], updatedAt: number): Promise<void> {
  const cache: ModelCache = { updatedAt, models }
  const tmp = `${path}.${process.pid}.tmp`
  await mkdir(dirname(path), { recursive: true })
  await writeFile(tmp, JSON.stringify(cache), 'utf8')
  await rm(path, { force: true })
  await rename(tmp, path)
}

async function loadModelCache(path: string, now: number): Promise<ModelCache> {
  const raw = JSON.parse(await readFile(path, 'utf8')) as ModelCache
  if (!Number.isFinite(raw.updatedAt) || now - raw.updatedAt > CACHE_TTL_MS) throw new Error('Kilo model cache too old')
  const models = decodeKiloModels({ data: raw.models })
  if (models.length === 0) throw new Error('Kilo model cache is empty')
  return { updatedAt: raw.updatedAt, models }
}

/** Default cache location next to the plugin data directory. */
export function defaultCachePath(dataDir: string): string {
  return join(dataDir, 'kilo-models.json')
}

/** Default cache location for the independent OpenCode Zen catalog. */
export function defaultZenCachePath(dataDir: string): string {
  return join(dataDir, 'zen-models.json')
}

// ---------------------------------------------------------------------------
// Compatibility helpers for code that used the old models.dev decision API.
// They are intentionally conservative and are useful to downstream tests and
// sidecar users while all runtime decisions above use Kilo's live records.
// ---------------------------------------------------------------------------

export function decide(model: string, prices: Map<string, ModelPrice>, ready: boolean): AnonymousDecision {
  if (!ready || prices.size === 0) {
    return isFreeModel(model)
      ? { allowed: true, source: 'name_free_pending', known: false }
      : { allowed: false, source: 'metadata_pending', known: false }
  }
  const price = prices.get(model)
  if (!price) return isFreeModel(model) ? { allowed: true, source: 'name_free', known: false } : { allowed: false, source: 'metadata_model_missing', known: false }
  if (price.free !== undefined) {
    return price.free && !price.deprecated
      ? { allowed: true, source: 'metadata_free', known: true }
      : { allowed: false, source: price.deprecated ? 'metadata_deprecated' : 'metadata_paid', known: true }
  }
  if (!price.deprecated && price.input === 0 && price.output === 0) return { allowed: true, source: 'metadata_free', known: true }
  return { allowed: false, source: price.deprecated ? 'metadata_deprecated' : 'metadata_paid', known: true }
}
