# dsh-opencode-go-autosync

DeepSeek Harness 插件：一键把 [models.opencode.ai/api.json](https://models.opencode.ai/api.json) 的 `opencode-go` 模型目录同步为 DSH 模型供应商 `opencode-go-autosync`。

已有 `opencode-go-autosync` 时只刷新模型列表；不存在时一键创建，无需手动更新 `settings.yaml`。

## 为什么需要它

DSH 的 `llm-pi-ai` 通过 `@earendil-works/pi-ai` 的内置目录提供 `opencode-go` 供应商，其模型列表是 **打包时** 的静态快照（`dist/providers/data/opencode-go.json`，当前 19 个模型），只有随 `pi-ai` 发版、再随 DSH 升级才会更新。

而上游 `https://models.opencode.ai/api.json` 是动态目录（当前 `opencode-go` 28 个模型，持续新增/下线），二者会随时间产生缺口：新模型在设置页选不到，已下线模型的 `contextWindow / reasoningEfforts` 也可能过时。`llm-pi-ai` 文档亦明确标注 *A route's catalog never refreshes itself*，`discovery` 的 `GET /models` 也只返回 `id`，拿不到 `contextWindow / reasoningEfforts / compat` 等富元数据，因此否则需要手动维护 `settings.yaml` 中的模型列表。

本插件把这一转换搬进运行时：设置页一个按钮（可选定时）`fetch(api.json) → 映射 → mutate llm-pi-ai.providers.opencode-go-autosync`，首次创建自定义供应商并写入 `api / baseURL / compat / apiKeyEnv`，之后仅覆盖 `models`，保留你已配的密钥与地址，从此无需手动更新。

---

## 功能

- **一键创建/更新**：设置页按钮读取上游 `https://models.opencode.ai/api.json` 的 `opencode-go`，写入 `llm-pi-ai.providers.opencode-go-autosync`。
- **只动模型列表**：已存在供应商时，仅覆盖 `models`，保留你配过的 `apiKeyEnv / baseURL / compat` 等字段。
- **完整字段映射**：`limit.context→contextWindow / limit.output→maxTokens / modalities→input / reasoning+reasoning_options→reasoningEfforts`（`none→off:none`，其余直通；非推理模型写 `reasoningEfforts: false`）。
- **自动过滤弃用模型**：上游标记 `status: "deprecated"` 的模型不会写入目标（上游只打标不删除，并通常已放出替代版）。
- **可选自动同步**：配置 `autoSync: true` 后每 6 小时（可配）自动刷新一次。

## 安装

### 前置

- DSH 已安装（`pnpm dsh --help` 可用），profile 建议 `web`。

### 从 GitHub 安装

```sh
pnpm dsh plugin --profile web add github:CJYLZS/dsh-opencode-go-autosync
```

或先克隆再本地安装（注意 `./`）：

```sh
git clone https://github.com/CJYLZS/dsh-opencode-go-autosync.git
pnpm dsh plugin --profile web add file:./dsh-opencode-go-autosync
# 也可用绝对路径：pnpm dsh plugin --profile web add file:/abs/path/to/dsh-opencode-go-autosync
```

安装后重启 DSH：

```sh
pnpm dsh --profile web
```

卸载：

```sh
pnpm dsh plugin --profile web remove dsh-opencode-go-autosync
```

## 使用

1. 打开 DSH 设置页 → **Plugins**，找到 **Opencode Go 同步** 卡片。
2. 点 **一键创建/更新**。首次会创建 `opencode-go-autosync`，再次点击仅刷新模型列表。
3. **预览上游** 可不落盘查看上游模型数。

> 目标供应商名默认为 `opencode-go-autosync`，可在插件配置中改为任意名字（如 `opencode-go-custom`）。

## API Key 配置

本插件不存密钥，只把供应商的 `apiKeyEnv` 指向一个环境变量名，密钥由 DSH 凭据体系解析。

### 1. 设置供应商的凭据引用

- 设置页：模型 → 选中 `opencode-go-autosync` → `apiKeyEnv` 填 `OPENCODE_API_KEY`（或 `OPENCODE_GO_CUSTOM_API_KEY` 等自定义名）。
- 或直接编辑 `~/.dsh/settings.yaml`：

```yaml
llm-pi-ai:
  providers:
    opencode-go-autosync:
      apiKeyEnv: OPENCODE_API_KEY
      api: openai-completions
      baseURL: https://opencode.ai/zen/go/v1
      compat:
        thinkingFormat: openai
        supportsReasoningEffort: true
```

插件首次创建时会自动写入上述 `api / baseURL / compat / apiKeyEnv` 默认值（`apiKeyEnv` 取上游 `env[0]`，默认为 `OPENCODE_API_KEY`）。

### 2. 写入密钥值

任选其一（优先级：设置凭据 > 环境变量）：

- **推荐**：DSH 设置页的凭据/密钥管理中，为 `OPENCODE_API_KEY` 填入真实 key（存入 `~/.dsh/.credentials.yaml`，设置页脱敏显示）。
- 或在启动 DSH 的环境中导出：

```sh
export OPENCODE_API_KEY="sk-..."
pnpm dsh --profile web
```

- 或写入 `~/.dsh/.env` / 项目 `.env`（被 `loadLayeredEnv` 载入）：

```
OPENCODE_API_KEY=sk-...
```

验证：设置页中该供应商显示已配置；对话选 `opencode-go-autosync` 下任意模型可正常出流。

## 插件配置

`cordis.patch.yml` 中 `opencode-go-sync` 的 `config`：

| 字段 | 默认 | 说明 |
|---|---|---|
| `sourceURL` | `https://models.opencode.ai/api.json` | 上游目录地址 |
| `sourceProvider` | `opencode-go` | 上游 JSON 中的 provider key |
| `targetProvider` | `opencode-go-autosync` | 写入 `llm-pi-ai.providers.<key>` 的目标名 |
| `targetApiKeyEnv` | 上游 `env[0]` | 覆盖目标的 `apiKeyEnv`（不设则用上游默认值） |
| `targetBaseURL` | 上游 `api` | 覆盖目标的 `baseURL` |
| `targetCompat` | `{thinkingFormat: openai, supportsReasoningEffort: true}` | 覆盖目标的 `compat` |
| `extraIds` | `[]` | 额外保留的私有模型 id（如 `hy3-preview`），上游没有时仍以空条目写入 |
| `autoSync` | `false` | 是否定时自动同步 |
| `autoSyncIntervalMs` | `21600000` (6h) | 自动同步间隔，最小 60s |

示例（`profiles/web/cordis.patch.yml` 覆盖）：

```yaml
- id: opencode-go-sync
  config:
    extraIds: [hy3-preview, muse-spark-1.2]
    autoSync: true
    autoSyncIntervalMs: 43200000
```

## 常见问题

- **`file:.tmp/...` 安装失败 `LINKED_PKG_DIR_NOT_FOUND`**：本地路径必须带 `./`，写 `file:./.tmp/...` 或 `file:/abs/...`。
- **上游拉取失败**：按钮会回显 `sync-failed: HTTP ...`，检查网络或 `sourceURL`。
- **密钥未生效**：确认 `apiKeyEnv` 指向的变量名与凭据/环境变量一致，且 DSH 已重启载入。

## 许可

MIT
