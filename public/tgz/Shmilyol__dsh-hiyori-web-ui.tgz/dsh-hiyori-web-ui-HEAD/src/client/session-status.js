function hasError(snapshot) {
  if (typeof snapshot?.hasError === 'boolean') {
    return snapshot.hasError
  }
  return Boolean(
    snapshot?.openError
    || snapshot?.promptError
    || snapshot?.lastAgentError,
  )
}

function latestTurnNumber(turnTimings) {
  let latest = 0
  if (turnTimings) {
    for (const turn of turnTimings.keys()) {
      if (turn > latest) latest = turn
    }
  }
  return latest
}

export function toSessionSignal(snapshot) {
  return {
    running: Boolean(snapshot?.running),
    hasError: hasError(snapshot),
    turnEndCount: snapshot?.turnEnds?.size ?? 0,
    turn: latestTurnNumber(snapshot?.turnTimings),
  }
}

export function classifySessionTransition(
  previous,
  next,
  { runningSince = null, now = Date.now() } = {},
) {
  if (hasError(next) && !hasError(previous)) {
    return 'error'
  }
  if (previous?.running && !next?.running) {
    return 'complete'
  }
  if (
    next?.running
    && runningSince !== null
    && now - runningSince >= 800
  ) {
    return 'loading'
  }
  return null
}

export function subscribeToSession(session, onSnapshot) {
  onSnapshot(session.getSnapshot())
  return session.subscribe(() => {
    onSnapshot(session.getSnapshot())
  })
}
