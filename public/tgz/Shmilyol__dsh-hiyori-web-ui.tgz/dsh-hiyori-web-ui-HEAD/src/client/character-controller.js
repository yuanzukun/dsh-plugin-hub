import { createDialogueEngine } from './dialogue-engine.js'
import { toSessionSignal } from './session-status.js'
import { normalizePersonality, PERSONALITY_LINES, rulesFor, streakTier, longrunTier } from './personalities.js'
import { DEFAULT_MODEL } from '../shared/protocol.js'

const IDLE_AFTER_MS = 3 * 60 * 1000
const IDLE_REPEAT_MS = 10 * 60 * 1000
const INTERACTION_COOLDOWN_MS = 1000
const RANDOM_MOTION_MIN_MS = 12 * 1000
const RANDOM_MOTION_MAX_MS = 24 * 1000
const SWITCH_COOLDOWN_MS = 500
const SWITCH_DURATION_MS = 4500
const LONG_RUN_MILESTONES = [20000, 60000, 120000, 240000]
const LONG_RUN_REPEAT_MS = 120000

const COMPLETE_MOTION = { gentle: 'Tap', tsundere: 'Flick', obedient: 'Tap', genki: 'FlickUp', lazy: 'FlickDown' }
const COMPLETE_EXPRESSION = { gentle: 'joy', tsundere: 'proud', obedient: 'joy', genki: 'joy', lazy: 'sleepy' }
const ERROR_MOTION = { gentle: 'FlickDown', tsundere: 'Flick', obedient: 'FlickDown', genki: 'Flick', lazy: 'FlickDown' }
const ERROR_EXPRESSION = { gentle: 'sad', tsundere: 'angry', obedient: 'sad', genki: 'joy', lazy: 'sleepy' }
const STREAK_MOTION = { gentle: 'FlickUp', tsundere: 'Flick', obedient: 'FlickUp', genki: 'FlickUp', lazy: 'FlickDown' }
const STREAK_EXPRESSION = { gentle: 'joy', tsundere: 'proud', obedient: 'joy', genki: 'proud', lazy: 'sleepy' }
const RECOVERED_MOTION = { gentle: 'Flick', tsundere: 'Flick', obedient: 'Tap', genki: 'FlickUp', lazy: 'FlickDown' }
const RECOVERED_EXPRESSION = { gentle: 'relief', tsundere: 'proud', obedient: 'joy', genki: 'joy', lazy: 'sleepy' }
const BASE_EXPRESSION = { gentle: 'joy', tsundere: 'proud', obedient: 'joy', genki: 'joy', lazy: 'sleepy' }
const IDLE_MOTIONS = {
  gentle: ['Tap', 'Flick'],
  tsundere: ['Flick'],
  obedient: ['Tap', 'Flick'],
  genki: ['FlickUp', 'Flick'],
  lazy: ['FlickDown'],
}
const LONG_RUN_MOTION = { gentle: 'Tap', tsundere: 'Flick', obedient: 'Tap', genki: 'FlickUp', lazy: 'FlickDown' }
const LONG_RUN_EXPRESSION = {
  gentle: { start: null, warm: 'joy', deep: 'relief', marathon: 'joy', grind: 'relief' },
  tsundere: { start: null, warm: 'proud', deep: 'angry', marathon: 'proud', grind: 'proud' },
  obedient: { start: null, warm: 'joy', deep: 'joy', marathon: 'joy', grind: 'relief' },
  genki: { start: 'joy', warm: 'joy', deep: 'joy', marathon: 'proud', grind: 'joy' },
  lazy: { start: 'sleepy', warm: 'sleepy', deep: 'sleepy', marathon: 'sleepy', grind: 'sleepy' },
}

function randomMotionId(pool, random) {
  const index = Math.min(pool.length - 1, Math.max(0, Math.floor(random() * pool.length)))
  return pool[index]
}

function randomMotionDelay(random) {
  return RANDOM_MOTION_MIN_MS + random() * (RANDOM_MOTION_MAX_MS - RANDOM_MOTION_MIN_MS)
}

function nextLongrunDelay(elapsedMs) {
  for (const milestone of LONG_RUN_MILESTONES) {
    if (elapsedMs < milestone) return milestone - elapsedMs
  }
  return LONG_RUN_REPEAT_MS
}

export function createCharacterController({
  timer,
  now = Date.now,
  random = Math.random,
  personality = 'gentle',
  llmSay = null,
  model = DEFAULT_MODEL,
  showBubble,
  dismissBubble,
  playMotion = () => {},
  playExpression = () => {},
}) {
  const dialogue = createDialogueEngine({ random, rules: rulesFor(personality) })
  let previousSession = null
  let greeted = false
  let destroyed = false
  let cancelLoading = null
  let cancelIdle = null
  let cancelBubble = null
  let cancelRandomMotion = null
  let cancelLongrun = null
  let runningSince = null
  let lastInteractionAt = -Infinity
  let currentPersonality = personality
  let lastSwitchAt = -Infinity
  let streakCount = 0
  let sessionSwitchPending = false
  let context = 'neutral'
  let currentModel = model
  let llmSayFn = llmSay
  let generation = 0
  let pendingAbort = null

  function cancel(disposerName) {
    if (disposerName === 'loading') {
      cancelLoading?.()
      cancelLoading = null
    } else if (disposerName === 'idle') {
      cancelIdle?.()
      cancelIdle = null
    } else if (disposerName === 'bubble') {
      cancelBubble?.()
      cancelBubble = null
    } else if (disposerName === 'random-motion') {
      cancelRandomMotion?.()
      cancelRandomMotion = null
    } else if (disposerName === 'longrun') {
      cancelLongrun?.()
      cancelLongrun = null
    }
  }

  function cancelLlm() {
    generation += 1
    if (pendingAbort !== null) {
      pendingAbort.abort()
      pendingAbort = null
      dismissBubble()
    }
  }

  function armBubble(slot) {
    cancelBubble = timer.timeout(() => {
      cancelBubble = null
      dialogue.dismiss()
      dismissBubble()
      playExpression(BASE_EXPRESSION[currentPersonality])
    }, Math.max(0, slot.expiresAt - now()))
  }

  function planFor(event, vars = {}) {
    if (event === 'complete') {
      if (context === 'recovered') {
        return { motion: RECOVERED_MOTION[currentPersonality], expression: RECOVERED_EXPRESSION[currentPersonality] }
      }
      if (context === 'rising') {
        return { motion: STREAK_MOTION[currentPersonality], expression: STREAK_EXPRESSION[currentPersonality] }
      }
      return { motion: COMPLETE_MOTION[currentPersonality], expression: COMPLETE_EXPRESSION[currentPersonality] }
    }
    if (event === 'streak') {
      return { motion: STREAK_MOTION[currentPersonality], expression: STREAK_EXPRESSION[currentPersonality] }
    }
    if (event === 'error') {
      return { motion: ERROR_MOTION[currentPersonality], expression: ERROR_EXPRESSION[currentPersonality] }
    }
    if (event === 'loading') {
      return {
        motion: currentPersonality === 'genki' ? 'FlickUp' : 'Flick',
        expression: currentPersonality === 'lazy' ? 'sleepy' : null,
      }
    }
    if (event === 'session') {
      return { motion: currentPersonality === 'genki' ? 'FlickUp' : 'Flick', expression: null }
    }
    if (event === 'longrun') {
      const tier = longrunTier(vars.elapsed)
      return {
        motion: LONG_RUN_MOTION[currentPersonality],
        expression: LONG_RUN_EXPRESSION[currentPersonality][tier],
      }
    }
    return null
  }

  function emit(event, vars = {}) {
    if (destroyed) {
      return null
    }
    const slot = dialogue.reserve(event, now(), vars)
    if (slot === null) {
      return null
    }
    cancel('bubble')
    const plan = planFor(event, vars)
    if (plan) {
      if (plan.motion) playMotion(plan.motion)
      if (plan.expression) playExpression(plan.expression)
    }

    let currentGeneration = generation
    const finish = (text) => {
      if (destroyed || generation !== currentGeneration) {
        return
      }
      pendingAbort = null
      dialogue.fill(slot, text)
      slot.expiresAt = now() + slot.durationMs
      showBubble(slot)
      armBubble(slot)
    }

    if (llmSayFn !== null) {
      generation += 1
      currentGeneration = generation
      pendingAbort?.abort()
      pendingAbort = new AbortController()
      showBubble({ ...slot, text: '……' })
      llmSayFn({ event, personality: currentPersonality, vars, model: currentModel, signal: pendingAbort.signal })
        .then(
          (text) => finish(text == null ? dialogue.localLine(slot, vars) : text),
          () => finish(dialogue.localLine(slot, vars)),
        )
    } else {
      finish(dialogue.localLine(slot, vars))
    }
    return slot
  }

  function announceSwitch(personalityId) {
    const lines = PERSONALITY_LINES[personalityId].switch
    const index = Math.min(lines.length - 1, Math.max(0, Math.floor(random() * lines.length)))
    cancel('bubble')
    showBubble({
      ruleId: 'switch',
      text: lines[index],
      priority: 105,
      expiresAt: now() + SWITCH_DURATION_MS,
    })
    cancelBubble = timer.timeout(() => {
      cancelBubble = null
      dialogue.dismiss()
      dismissBubble()
    }, SWITCH_DURATION_MS)
  }

  function armIdle(delay = IDLE_AFTER_MS) {
    cancel('idle')
    if (destroyed) {
      return
    }
    cancelIdle = timer.timeout(() => {
      cancelIdle = null
      emit('idle')
      armIdle(IDLE_REPEAT_MS)
    }, delay)
  }

  function armRandomMotion() {
    cancel('random-motion')
    if (destroyed) {
      return
    }
    cancelRandomMotion = timer.timeout(() => {
      cancelRandomMotion = null
      playMotion(randomMotionId(IDLE_MOTIONS[currentPersonality], random))
      armRandomMotion()
    }, randomMotionDelay(random))
  }

  function armLongrun() {
    cancel('longrun')
    if (destroyed) {
      return
    }
    const elapsed = now() - runningSince
    cancelLongrun = timer.timeout(() => {
      cancelLongrun = null
      emit('longrun', { elapsed: now() - runningSince })
      armLongrun()
    }, nextLongrunDelay(elapsed))
  }

  return {
    setPersonality(id, { announce = true } = {}) {
      const next = normalizePersonality(id)
      if (destroyed || next === currentPersonality) {
        return
      }
      currentPersonality = next
      dialogue.setRules(rulesFor(next))
      playExpression(BASE_EXPRESSION[next])
      if (announce) {
        const timestamp = now()
        if (timestamp - lastSwitchAt >= SWITCH_COOLDOWN_MS) {
          lastSwitchAt = timestamp
          announceSwitch(next)
          playMotion(randomMotionId(IDLE_MOTIONS[next], random))
        }
      }
      armIdle()
    },
    setLlmSay(fn) {
      if (destroyed) {
        return
      }
      llmSayFn = fn ?? null
      if (llmSayFn === null) {
        cancelLlm()
      }
    },
    setModel(id) {
      if (destroyed) {
        return
      }
      if (typeof id === 'string' && id.length > 0) {
        currentModel = id
      }
    },
    runtimeReady() {
      if (destroyed || greeted) {
        return
      }
      greeted = true
      playExpression(BASE_EXPRESSION[currentPersonality])
      if (sessionSwitchPending) {
        sessionSwitchPending = false
        emit('session')
      } else {
        const hour = new Date(now()).getHours()
        emit(hour < 11
          ? 'greeting-morning'
          : hour < 18
            ? 'greeting-daytime'
            : 'greeting-evening')
      }
      armIdle()
      armRandomMotion()
    },
    runtimeHit(area) {
      if (destroyed || area !== 'Body') {
        return false
      }
      const timestamp = now()
      if (timestamp - lastInteractionAt < INTERACTION_COOLDOWN_MS) {
        return false
      }
      lastInteractionAt = timestamp
      emit('body-click')
      playMotion('Tap@Body')
      armIdle()
      return true
    },
    runtimeError() {
      emit('error')
    },
    sessionSwitched(switched) {
      if (destroyed || !switched) {
        return
      }
      if (greeted) {
        emit('session')
      } else {
        sessionSwitchPending = true
      }
    },
    dismiss() {
      cancelLlm()
      cancel('bubble')
      dialogue.dismiss()
      dismissBubble()
    },
    pointerActivity() {
      armIdle()
    },
    sessionChanged() {
      previousSession = null
      cancel('loading')
      cancel('longrun')
      cancelLlm()
      runningSince = null
      streakCount = 0
      context = 'neutral'
    },
    sessionSnapshot(snapshot) {
      if (destroyed) {
        return
      }
      const next = toSessionSignal(snapshot)
      const previous = previousSession
      previousSession = next

      const turnAdvanced = next.turn > 0 && next.turn !== previous?.turn
      if (next.running && (!previous?.running || turnAdvanced)) {
        cancel('loading')
        if (context !== 'down') {
          context = 'working'
        }
        runningSince = now()
        armLongrun()
        cancelLoading = timer.timeout(() => {
          cancelLoading = null
          emit('loading')
        }, 800)
      }
      if (previous?.running && !next.running) {
        cancel('loading')
        cancel('longrun')
        runningSince = null
        if (!next.hasError) {
          streakCount += 1
          if (streakTier(streakCount)) {
            context = 'rising'
            if (!emit('streak', { n: streakCount })) {
              emit('complete')
            }
          } else {
            context = context === 'down' ? 'recovered' : 'neutral'
            emit('complete')
          }
        }
      }
      if (next.hasError && !previous?.hasError) {
        streakCount = 0
        context = 'down'
        emit('error')
      }
      armIdle()
    },
    destroy() {
      if (destroyed) {
        return
      }
      destroyed = true
      cancel('loading')
      cancel('idle')
      cancel('bubble')
      cancel('random-motion')
      cancel('longrun')
      cancelLlm()
      dialogue.dismiss()
    },
  }
}
