export const CHARACTER_CSS = String.raw`
.gal-character-frame-host {
  position: fixed;
  right: 18px;
  bottom: 0;
  width: 280px;
  height: 250px;
  z-index: 30;
  pointer-events: none;
}
.gal-character-frame-host.gal-hidden {
  display: none;
}
.gal-character-root {
  position: fixed;
  right: 18px;
  bottom: 0;
  width: 280px;
  height: 250px;
  z-index: 30;
  pointer-events: none;
}
.gal-character-stage {
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.gal-character-frame {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
  background: transparent;
  pointer-events: none;
}
.gal-character-hit {
  position: absolute;
  z-index: 1;
  display: block;
  margin: 0;
  padding: 0;
  border: 0;
  background: transparent;
  color: transparent;
  cursor: pointer;
}
.gal-character-hit-body {
  /* 只覆盖头部与上半身：避开底部输入栏的发送/暂停按钮（按钮位于视口底部约 14–48px 处） */
  left: 70px;
  top: 6px;
  width: 140px;
  height: 132px;
  clip-path: polygon(30% 0, 70% 0, 88% 100%, 12% 100%);
  pointer-events: auto;
}
.gal-character-hit:focus-visible {
  outline: 2px solid var(--dsw-alias-brand-primary);
  outline-offset: -3px;
}
.gal-character-bubble {
  position: absolute;
  right: 190px;
  bottom: 155px;
  width: max-content;
  max-width: min(300px, calc(100vw - 224px));
  padding: 10px 13px;
  border: 1px solid rgba(201, 169, 106, 0.58);
  border-radius: 12px;
  color: var(--dsw-alias-label-primary);
  background: color-mix(in srgb, var(--dsw-alias-bg-layer-1) 94%, transparent);
  box-shadow: var(--dsw-shadow-lv2);
  font-size: 13px;
  line-height: 1.55;
  text-align: left;
  pointer-events: auto;
  cursor: pointer;
  animation: gal-character-bubble-in 160ms ease-out;
}
.gal-character-bubble::after {
  content: '';
  position: absolute;
  right: -7px;
  bottom: 18px;
  width: 12px;
  height: 12px;
  border-top: 1px solid rgba(201, 169, 106, 0.58);
  border-right: 1px solid rgba(201, 169, 106, 0.58);
  background: inherit;
  transform: rotate(45deg);
}
.gal-character-tools {
  position: absolute;
  z-index: 2;
  top: 10px;
  right: 40px;
  display: flex;
  gap: 6px;
  opacity: 0;
  transform: translateY(4px);
  transition: opacity 160ms ease, transform 160ms ease;
  pointer-events: none;
}
.gal-character-tools::before {
  content: '';
  position: absolute;
  top: -8px;
  right: 100%;
  width: 28px;
  height: 64px;
}
.gal-character-root:hover .gal-character-tools,
.gal-character-tools:focus-within {
  opacity: 1;
  transform: none;
  pointer-events: auto;
}
.gal-character-tool,
.gal-character-restore {
  border: 1px solid rgba(201, 169, 106, 0.55);
  border-radius: 999px;
  color: var(--dsw-alias-label-secondary);
  background: var(--dsw-alias-bg-layer-1);
  box-shadow: var(--dsw-shadow-lv1);
  cursor: pointer;
}
.gal-character-tool {
  padding: 5px 9px;
  font-size: 12px;
}
.gal-character-tool:hover,
.gal-character-restore:hover {
  color: var(--dsw-alias-brand-primary);
  background: var(--dsw-alias-interactive-bg-hover-solid);
}
.gal-character-tool:focus-visible,
.gal-character-restore:focus-visible,
.gal-character-bubble:focus-visible {
  outline: 2px solid var(--dsw-alias-brand-primary);
  outline-offset: 2px;
}
.gal-character-restore {
  position: fixed;
  right: 14px;
  bottom: 14px;
  z-index: 30;
  padding: 6px 11px;
  font-size: 12px;
  pointer-events: auto;
}
@keyframes gal-character-bubble-in {
  from { opacity: 0; transform: translateY(4px); }
  to { opacity: 1; transform: translateY(0); }
}
@media (prefers-reduced-motion: reduce) {
  .gal-character-tools,
  .gal-character-bubble {
    animation: none;
    transition: none;
  }
}

/* 性格选择器（原生 36px 胶囊，与设置页其它控件一致） */
.gal-personality-row { align-items: flex-start; }
.gal-personality-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
}
.gal-personality-chip {
  flex: none;
  height: 36px;
  padding: 0 14px;
  border: none;
  border-radius: 18px;
  background: var(--dsw-alias-bg-module-platform);
  color: var(--dsw-alias-label-primary);
  font: inherit;
  font-size: 14px;
  line-height: 22px;
  cursor: pointer;
  transition: background-color 0.15s, color 0.15s;
}
.gal-personality-chip:hover {
  background: var(--dsw-alias-interactive-bg-hover);
}
/* 选中态：品牌色文字 + 品牌浅底 */
.gal-personality-chip[data-active="true"] {
  background: var(--dsw-alias-interactive-bg-active);
  color: var(--dsw-alias-brand-primary);
}
.gal-personality-chip:focus-visible { outline: 2px solid var(--dsw-alias-border-l4); outline-offset: 1px; }
`
