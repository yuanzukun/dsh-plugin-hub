export const PERSONALITY_KEY = 'sakura-vn-personality-v1'

export const PERSONALITIES = [
  { id: 'gentle', label: '温柔' },
  { id: 'tsundere', label: '傲娇' },
  { id: 'obedient', label: '乖巧' },
  { id: 'genki', label: '元气' },
  { id: 'lazy', label: '慵懒' },
]

const PERSONALITY_IDS = new Set(PERSONALITIES.map((personality) => personality.id))

export const EVENT_RULES = [
  { id: 'error', event: 'error', priority: 100, cooldownMs: 1000, durationMs: 6000 },
  { id: 'body', event: 'body-click', priority: 80, cooldownMs: 1000, durationMs: 4500 },
  { id: 'complete', event: 'complete', priority: 60, cooldownMs: 5000, durationMs: 4500 },
  { id: 'streak', event: 'streak', priority: 55, cooldownMs: 1000, durationMs: 4500 },
  { id: 'loading', event: 'loading', priority: 40, cooldownMs: 30000, durationMs: 4000 },
  { id: 'longrun', event: 'longrun', priority: 35, cooldownMs: 1000, durationMs: 4500 },
  { id: 'session', event: 'session', priority: 30, cooldownMs: 5000, durationMs: 4500 },
  { id: 'morning', event: 'greeting-morning', priority: 20, cooldownMs: 86400000, durationMs: 5000 },
  { id: 'daytime', event: 'greeting-daytime', priority: 20, cooldownMs: 86400000, durationMs: 5000 },
  { id: 'evening', event: 'greeting-evening', priority: 20, cooldownMs: 86400000, durationMs: 5000 },
  { id: 'idle', event: 'idle', priority: 10, cooldownMs: 600000, durationMs: 4000 },
]

export const PERSONALITY_LINES = {
  gentle: {
    error: ['呜……这次我没做好，对不起。', '遇到了一点困难，让我再试一次好吗？'],
    body: ['我在这里。', '今天也一起加油吧。'],
    complete: ['我完成啦，谢谢你的信任～', '这次的任务，我好好地做完啦。', '搞定了，能帮上你的忙真好。'],
    loading: ['我开始啦，正在认真做，稍等哦。', '我开工了，马上就好。'],
    session: ['我跟着你到新会话啦。', '换会话了？我陪你一起。'],
    morning: ['早上好，今天也请多关照。'],
    daytime: ['你好，今天也一起加油吧。'],
    evening: ['晚上好，辛苦啦。'],
    idle: ['还在这里哦。', '要不要休息一下？'],
    streak: {
      first: ['连续 3 次成功……原来我这么靠谱呀。', '三次连击达成，谢谢你的信任～'],
      hot: ['连续 5 次了，感觉状态越来越好了。', '5 连胜！我已经不是新手啦。'],
      big: ['连续 10 次！今天的我，真的很厉害吧？', '10 连胜达成，可以小小得意一下吗？'],
      legend: ['连续 {n} 次，连我自己都有点佩服自己了。', '第 {n} 连胜……谢谢你一直让我帮忙。'],
    },
    longrun: {
      start: ['我开工啦，正埋头做着，你稍安勿躁。', '开始认真做了，有进展我就告诉你。'],
      warm: ['做了一会儿，一切顺利，我继续。', '还在稳步推进，你放心交给我。'],
      deep: ['这活比想的费工夫，不过我会一点点做完。', '还在攻坚，我给自己打打气，继续。'],
      marathon: ['已经做了好一阵，我没停，还在努力。', '进度还在往前走，我稳住，继续。'],
      grind: ['还在干，我不会半途而废的。', '我还在认真做，做完就告诉你。'],
    },
    switch: ['嗯，我会一直这样陪着你的。'],
  },
  tsundere: {
    error: ['哼、才、才不是我的失误！是任务太刁钻了！', '笨、笨蛋！再让我试一次，这次一定行！'],
    body: ['才、才不是在等你摸我！', '干、干嘛突然碰我啦！'],
    complete: ['哼，这种任务，本小姐随手就搞定啦！', '看、看到了吧？这点小事可难不倒我！', '才、才不是特意做给你看的，只是顺手而已！'],
    loading: ['我、我在认真干活啦，别催！', '给、给我一点时间，我可不想交出差劲的东西！'],
    session: ['哼，又换会话？我跟上就是了。', '换会话也不提前说一声，哼！'],
    morning: ['早、早上好。才不是特意等你起床呢！'],
    daytime: ['哟，又在忙啦？哼，随便你。'],
    evening: ['晚、晚上好……今天辛苦了。'],
    idle: ['喂，别晾着我不管啊！', '哼，我才不会觉得无聊呢！'],
    streak: {
      first: ['哼，才、才 3 次而已，别大惊小怪的！', '三连胜？哼，这不是理所当然的吗！'],
      hot: ['5 连胜……哼，我只是没给你失败的机会而已！', '连续 5 次搞定，看、看到了吧！'],
      big: ['十连胜……怎么样，这下服气了吧？', '哼，10 次算什么，我还能继续呢！'],
      legend: ['连续 {n} 次……哼，你、你可别太得意，是我在帮你！', '第 {n} 连胜，哼，夸我的话就免了吧……才怪。'],
    },
    longrun: {
      start: ['哼，开工就开工，这点活才难不倒我！', '我、我已经在做啦，才不用你盯着！'],
      warm: ['哼，做了一会儿了，一切尽在掌握。', '还没完，但、但这是我在认真做，别小看我。'],
      deep: ['这、这活有点硬……不过本小姐偏要啃下来！', '还没好……哼，我可不打算认输。'],
      marathon: ['都、都做了这么久，我可没偷懒，继续！', '哼，长跑而已，我撑得住，你等着。'],
      grind: ['我还在拼，才不会半途而废呢！', '别、别以为我会放弃，我偏要干完它。'],
    },
    switch: ['哼，要我换种方式陪你？可、可以啦。'],
  },
  obedient: {
    error: ['对不起……这次我没做好。', '是我笨手笨脚了，再给我一次机会好吗？'],
    body: ['嗯嗯，我在呢。', '谢谢你来找我。'],
    complete: ['我完成了！希望能帮到你～', '做好啦，这是我的心意，请收下。', '我尽力做完啦，你……还满意吗？'],
    loading: ['我正在努力做，马上就好～', '我会好好完成的，请再等我一下。'],
    session: ['我跟着你到新会话啦，继续加油。', '嗯，我们换个地方继续。'],
    morning: ['早安，今天也一起加油吧。'],
    daytime: ['你好呀，今天也要好好照顾自己哦。'],
    evening: ['晚上好，今天辛苦啦，休息一下吧。'],
    idle: ['我一直都在哦。', '要不要靠着我休息一会儿？'],
    streak: {
      first: ['连续三次都成功了，好开心！', '三次连击！我会继续努力的～'],
      hot: ['连续五次完成，感觉好充实呀。', '5 连胜了！谢谢你的信任。'],
      big: ['十连胜……这是我们一起的成果呢。', '连续十次成功，好有成就感！'],
      legend: ['连续 {n} 次都成功了，我会一直努力的。', '第 {n} 连胜……能帮上你真好。'],
    },
    longrun: {
      start: ['我开工了，会认真做完的，请放心～', '开始努力啦，有进度就向你汇报～'],
      warm: ['做了一会儿，一切正常，我会继续加油的～', '还在认真做，谢谢你的信任，我会努力的。'],
      deep: ['这个任务有点难，但我会一点一点做完的。', '还在努力中，我不会偷懒的，请相信我～'],
      marathon: ['已经努力好久了，但我不会停下的。', '还有一段，我会坚持做完，给你一个交代。'],
      grind: ['我还在加油，会一直做到完成为止。', '我会坚持到底的，请再等等我～'],
    },
    switch: ['好呀，以后就这样陪你。'],
  },
  genki: {
    error: ['呜哇——这次失手了！没关系，再来一次，看我的！', '啊呀，翻车了翻车了，我马上重来，这次一定行！'],
    body: ['嘿！找我玩吗？', '耶，被你发现了！'],
    complete: ['搞定搞定！我超厉害的，快夸夸我！', '耶——！任务完成！给我鼓个掌嘛！', '太棒啦！我又帮上忙了，好有成就感！'],
    loading: ['我开工啦！正在火力全开，马上就好！', '冲鸭——！我马上搞定，等着我的好消息！'],
    session: ['新会话！出发出发！', '换会话咯，我又跟着你啦！'],
    morning: ['早——上好！今天也元气满满！'],
    daytime: ['嗨嗨！今天想做什么呀？'],
    evening: ['晚上好！今天也要开心到最后哦！'],
    idle: ['嘿嘿，我在呢，来陪我玩嘛！', '好无聊哦，讲个有趣的事给我听嘛！'],
    streak: {
      first: ['三连胜！我的状态火热！', '连续三次成功！耶——！'],
      hot: ['五连胜！我是不是超厉害！', '5 连胜达成，快给我鼓掌！'],
      big: ['十连胜！！超级无敌厉害！', '10 次全胜！今天的我火力全开！'],
      legend: ['连续 {n} 次全胜！我已经是无敌的了！', '第 {n} 连胜！快、夸、我！'],
    },
    longrun: {
      start: ['开工开工！火力全开，冲鸭——！', '交给我！现在正拼尽全力，等我好消息！'],
      warm: ['还在冲刺！一切顺利，能量满格！', '干了一会儿了，超顺的，继续冲！'],
      deep: ['这活有点硬，不过超燃的，我越战越勇！', '还没完！但我不累，继续战斗！'],
      marathon: ['马拉松模式！我体力无限，继续冲！', '已经好久啦，但我超强的，撑得住！'],
      grind: ['还在全力冲刺！给我喊声加油嘛！', '我还在拼！不干完不罢休！'],
    },
    switch: ['换性格咯——元气模式，全开！'],
  },
  lazy: {
    error: ['唔……搞砸了。……嘛，再试一次呗。', '啊……没弄好。……算了，我再来。'],
    body: ['嗯……找我？', '啊……被你发现了。'],
    complete: ['唔……做完了。夸我？……随你啦。', '搞定……终于可以歇一会儿了。'],
    loading: ['唔……我在做啦，别催……', '哈啊……正在慢慢弄……'],
    session: ['哦……换会话了呀，我跟上……', '唔……新会话？……随便啦，我在。'],
    morning: ['早……这么早就起来啦……'],
    daytime: ['哈啊……今天也……随便啦。'],
    evening: ['晚上好……差不多该休息了吧……'],
    idle: ['嗯……还在这里哦。', '要不要一起发会儿呆……'],
    streak: {
      first: ['唔……连续 3 次了。……还行吧。', '三连胜……嗯，意料之中……'],
      hot: ['5 次了……唔，有点累，但还是完成了……', '连续 5 次……还算顺利……'],
      big: ['十连胜……啊，好想歇会儿……不过，还不错……', '连续 10 次……嗯，辛苦我自己了……'],
      legend: ['连续 {n} 次……唔，数都懒得数了……', '第 {n} 连胜……好了好了，我继续……'],
    },
    longrun: {
      start: ['唔……开工了，慢慢做啦……', '我在做哦，就是……稍微慢一点，别急。'],
      warm: ['做了一会儿……哈啊，还在做，没停……', '唔……进度还行吧，我在慢慢推进……'],
      deep: ['这活好麻烦啊……不过都做一半了，继续……', '哈啊……还没完，让我缓一缓再继续……'],
      marathon: ['都、都干这么久了……好累，但我会做完的……', '还没结束……我瘫一下下，再爬起来继续……'],
      grind: ['我……还在干，没跑路……别担心。', '哈啊……继续继续，干完就能躺了……'],
    },
    switch: ['嗯……换种懒懒的方式陪你……'],
  },
}

export function normalizePersonality(id) {
  return PERSONALITY_IDS.has(id) ? id : 'gentle'
}

export function streakTier(count) {
  if (count === 3) return 'first'
  if (count === 5) return 'hot'
  if (count === 10) return 'big'
  if (count >= 15 && count % 5 === 0) return 'legend'
  return undefined
}

export function longrunTier(elapsedMs) {
  if (elapsedMs >= 360000) return 'grind'
  if (elapsedMs >= 240000) return 'marathon'
  if (elapsedMs >= 120000) return 'deep'
  if (elapsedMs >= 60000) return 'warm'
  if (elapsedMs >= 20000) return 'start'
  return undefined
}

export function rulesFor(personalityId) {
  const id = normalizePersonality(personalityId)
  const lines = PERSONALITY_LINES[id]
  return EVENT_RULES.map((rule) => ({
    ...rule,
    lines: rule.id === 'streak'
      ? (vars) => PERSONALITY_LINES[id].streak[streakTier(vars.n)]
      : rule.id === 'longrun'
        ? (vars) => PERSONALITY_LINES[id].longrun[longrunTier(vars.elapsed)]
        : lines[rule.id],
  }))
}

export function loadPersonalityPreference(storage) {
  try {
    return normalizePersonality(storage?.getItem(PERSONALITY_KEY))
  } catch {
    return 'gentle'
  }
}

export function savePersonalityPreference(storage, personalityId) {
  try {
    storage?.setItem(PERSONALITY_KEY, normalizePersonality(personalityId))
  } catch {
    // Storage can be disabled without disabling the personality for this page.
  }
}
