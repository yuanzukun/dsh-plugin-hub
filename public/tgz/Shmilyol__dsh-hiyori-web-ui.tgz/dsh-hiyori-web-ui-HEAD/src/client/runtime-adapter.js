import {
  makeCommand,
  parseRuntimeEvent,
  RUNTIME_PAGE,
} from '../shared/protocol.js'

const FRAME_CLASS = 'gal-character-frame'

// Live2D 跑在独立沙箱 iframe 里。DSH shell 在切换会话时会重挂载 overlay 的 React 树，
// 若 iframe 是 React 树的子节点，就会被销毁重建、模型重新初始化（可见的闪烁）。
// 因此 iframe 的生命周期提升到模块级单例：只创建一次，重挂载时被新 adapter「收养」，
// 只有硬销毁（关闭角色/运行时出错/插件停止）才真正拆除。
let sharedFrame = null
let sharedReady = false
let sharedListener = null
let sharedCancelTimeout = null
let sharedOnEvent = null

function clearSharedTimeout() {
  if (sharedCancelTimeout !== null) {
    sharedCancelTimeout()
    sharedCancelTimeout = null
  }
}

function post(type, payload = {}) {
  sharedFrame?.contentWindow?.postMessage(makeCommand(type, payload), '*')
}

function onSharedMessage(event) {
  if (
    sharedFrame === null
    || event.origin !== 'null'
    || event.source !== sharedFrame.contentWindow
  ) {
    return
  }
  const parsed = parseRuntimeEvent(event.data)
  if (parsed === null) {
    return
  }
  if (parsed.type === 'ready') {
    sharedReady = true
    clearSharedTimeout()
  }
  sharedOnEvent?.(parsed)
}

export function createRuntimeAdapter({
  window: browserWindow = window,
  document: browserDocument = document,
  timer,
  onEvent,
  readyTimeoutMs = 10000,
}) {
  let detached = false
  sharedOnEvent = onEvent
  if (sharedListener === null) {
    sharedListener = onSharedMessage
    browserWindow.addEventListener('message', sharedListener)
  }

  return {
    mount(container) {
      if (detached) {
        return
      }
      if (sharedFrame === null || sharedFrame.isConnected === false) {
        sharedFrame = browserDocument.createElement('iframe')
        sharedFrame.className = FRAME_CLASS
        sharedFrame.title = '桃濑日和'
        sharedFrame.src = RUNTIME_PAGE
        sharedFrame.setAttribute('sandbox', 'allow-scripts')
        sharedFrame.setAttribute('referrerpolicy', 'no-referrer')
        sharedFrame.addEventListener('error', () => {
          if (!detached && !sharedReady) {
            clearSharedTimeout()
            sharedOnEvent?.({ type: 'error', code: 'runtime-frame' })
          }
        })
        container.append(sharedFrame)
        sharedReady = false
        sharedCancelTimeout = timer.timeout(() => {
          sharedCancelTimeout = null
          if (!sharedReady) {
            sharedOnEvent?.({ type: 'error', code: 'runtime-timeout' })
          }
        }, readyTimeoutMs)
      } else if (sharedReady) {
        // 收养已就绪的常驻 iframe：立即向新 sink 回报 ready，模型无需重载
        sharedOnEvent?.({ type: 'ready' })
      }
    },
    lookAt(x, y) {
      if (sharedReady) {
        post('pointer', { x, y })
      }
    },
    playMotion(id) {
      if (sharedReady) {
        post('motion', { id })
      }
    },
    playExpression(id) {
      if (sharedReady) {
        post('expression', { id })
      }
    },
    destroy() {
      // 软销毁：只摘掉本 adapter 的 sink，iframe 与模型保持存活，供下一次挂载收养
      if (detached) {
        return
      }
      detached = true
      if (sharedOnEvent === onEvent) {
        sharedOnEvent = null
      }
    },
    destroyRuntime() {
      // 硬销毁：真正拆除常驻 iframe、监听器与就绪状态（软销毁后仍可调用，幂等）
      clearSharedTimeout()
      if (sharedReady) {
        post('destroy')
      }
      if (sharedListener !== null) {
        browserWindow.removeEventListener('message', sharedListener)
        sharedListener = null
      }
      sharedFrame?.remove()
      sharedFrame = null
      sharedReady = false
      if (sharedOnEvent === onEvent) {
        sharedOnEvent = null
      }
      detached = true
    },
  }
}
