export const initialCharacterState = {
  enabled: true,
  hidden: false,
  ready: false,
  bubble: null,
  error: null,
}

export function reduceCharacterState(state, action) {
  if (action.type === 'hide') {
    return { ...state, hidden: true, bubble: null }
  }
  if (action.type === 'restore') {
    return { ...state, hidden: false }
  }
  if (action.type === 'disable') {
    return {
      ...state,
      enabled: false,
      hidden: false,
      bubble: null,
    }
  }
  if (action.type === 'enable') {
    return { ...state, enabled: true }
  }
  if (action.type === 'bubble') {
    return { ...state, bubble: action.bubble }
  }
  if (action.type === 'dismiss') {
    return { ...state, bubble: null }
  }
  if (action.type === 'ready') {
    return { ...state, ready: true, error: null }
  }
  if (action.type === 'error') {
    return { ...state, error: action.code, ready: false }
  }
  return state
}
