import { buildLlmMessages } from './llm-prompt.js'
import { DEFAULT_MODEL, SAY_PATH } from '../shared/protocol.js'

export const MODEL_KEY = 'sakura-vn-model-v1'

export function loadModelPreference(storage) {
  try {
    const value = storage?.getItem(MODEL_KEY)
    return typeof value === 'string' && value.length > 0 ? value : DEFAULT_MODEL
  } catch {
    return DEFAULT_MODEL
  }
}

export function saveModelPreference(storage, model) {
  try {
    storage?.setItem(MODEL_KEY, model)
  } catch {
    // Storage can be disabled without disabling the model preference for this page.
  }
}

export function createLlmProvider({
  fetchImpl = fetch,
  sayPath = SAY_PATH,
  timeoutMs = 8000,
  defaultModel = DEFAULT_MODEL,
} = {}) {
  return {
    async say({ event, personality, vars, model = defaultModel, recent = [], signal } = {}) {
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), timeoutMs)
      const onAbort = () => controller.abort()
      signal?.addEventListener('abort', onAbort)
      try {
        const response = await fetchImpl(sayPath, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ model, messages: buildLlmMessages({ personality, event, vars, recent }) }),
          signal: controller.signal,
        })
        if (!response.ok) return null
        const json = await response.json()
        if (json?.ok === true && typeof json?.text === 'string') return json.text
        return null
      } catch {
        return null
      } finally {
        clearTimeout(timer)
        signal?.removeEventListener('abort', onAbort)
      }
    },
  }
}
