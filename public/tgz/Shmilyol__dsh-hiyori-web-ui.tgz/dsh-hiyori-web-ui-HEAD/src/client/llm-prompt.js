import { ANTI_REPEAT_RULES, EVENT_CARDS, HARD_RULES, PERSONALITY_PROFILES, examplesFor } from './dialogue-handbook.js'
import { normalizePersonality } from './personalities.js'

function render(template, vars) {
  return template.replace(/\{(\w+)\}/g, (match, key) => (key in vars ? String(vars[key]) : match))
}

function minuteVars(vars) {
  return typeof vars.elapsed === 'number'
    ? { ...vars, elapsed: Math.max(1, Math.round(vars.elapsed / 60000)) }
    : vars
}

export function buildLlmMessages({ personality, event, vars = {}, recent = [] }) {
  const id = normalizePersonality(personality)
  const profile = PERSONALITY_PROFILES[id]
  const card = EVENT_CARDS[event] ?? { summary: `发生了一件事（${event}）`, angles: [] }

  const system = [
    '你是桃濑日和，常驻在 DeepSeek Harness 界面右下角的 Live2D 陪伴角色。',
    `你的性格是「${profile.label}」：${profile.voice}。`,
    `口头习惯：${profile.tics.join('；')}。`,
    `态度：${profile.attitude}。`,
    `避免：${profile.avoids.join('；')}。`,
    HARD_RULES,
    ANTI_REPEAT_RULES,
  ].join('\n')

  const examples = examplesFor(id, event, vars)
  const userParts = [
    `${render(card.summary, minuteVars(vars))}。`,
    `可选语气角度：${card.angles.join(' / ')}。`,
    '从上面角度里挑一个，结合性格说一句话。',
  ]
  if (examples.length > 0) userParts.push(`口吻参考（不要照抄）：${examples.join(' ；')}`)
  if (recent.length > 0) userParts.push(`最近说过：${recent.join(' ；')}`)

  return [
    { role: 'system', content: system },
    { role: 'user', content: userParts.join('\n') },
  ]
}
