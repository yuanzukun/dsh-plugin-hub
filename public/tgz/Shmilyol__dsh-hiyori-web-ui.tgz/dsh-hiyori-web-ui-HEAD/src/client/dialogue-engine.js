import { rulesFor } from './personalities.js'

export const DEFAULT_RULES = rulesFor('gentle')

export function createDialogueEngine({ rules = DEFAULT_RULES, random = Math.random } = {}) {
  const byEvent = new Map(rules.map((rule) => [rule.event, rule]))
  const lastAt = new Map()
  const lastLine = new Map()
  let active = null

  function reserve(event, now = Date.now()) {
    const rule = byEvent.get(event)
    if (!rule || now - (lastAt.get(rule.id) ?? -Infinity) < rule.cooldownMs) return null
    if (active && active.expiresAt > now && active.priority > rule.priority) return null
    lastAt.set(rule.id, now)
    const slot = {
      ruleId: rule.id,
      text: '',
      priority: rule.priority,
      durationMs: rule.durationMs,
      expiresAt: now + rule.durationMs,
      rule,
    }
    active = slot
    return slot
  }

  function localLine(slot, vars = {}) {
    const rule = slot.rule
    const pool = typeof rule.lines === 'function' ? rule.lines(vars) : rule.lines
    const previous = lastLine.get(rule.id)
    const candidates = pool.filter((line) => line !== previous)
    const selected = candidates.length ? candidates : pool
    const chosen = selected[Math.min(selected.length - 1, Math.max(0, Math.floor(random() * selected.length)))]
    return chosen.replace(/\{(\w+)\}/g, (match, key) => (key in vars ? String(vars[key]) : match))
  }

  function fill(slot, text) {
    slot.text = text
    lastLine.set(slot.ruleId, text)
    return slot
  }

  function trigger(event, now = Date.now(), vars = {}) {
    const slot = reserve(event, now)
    if (slot === null) return null
    return fill(slot, localLine(slot, vars))
  }

  return {
    setRules(nextRules) {
      byEvent.clear()
      for (const rule of nextRules) {
        byEvent.set(rule.event, rule)
      }
    },
    reserve,
    localLine,
    fill,
    trigger,
    dismiss() { active = null },
    current(now = Date.now()) {
      if (active?.expiresAt <= now) active = null
      return active
    },
  }
}
