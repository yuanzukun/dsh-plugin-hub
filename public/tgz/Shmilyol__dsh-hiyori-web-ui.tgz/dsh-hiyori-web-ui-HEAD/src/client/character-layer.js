import { createCharacterController } from './character-controller.js'
import {
  initialCharacterState,
  reduceCharacterState,
} from './character-state.js'
import { createRuntimeAdapter } from './runtime-adapter.js'
import { subscribeToSession } from './session-status.js'
import { DEFAULT_MODEL, STATUS_PATH } from '../shared/protocol.js'

const PREFERENCE_KEY = 'sakura-vn-character-v1'
const SESSION_KEY = 'sakura-vn-last-session-v1'

export const GAZE_DEAD_ZONE_PX = 32

function normalizeAxis(offset, toLeftEdge, toRightEdge) {
  const magnitude = Math.abs(offset)
  if (magnitude <= GAZE_DEAD_ZONE_PX) {
    return 0
  }
  if (offset > 0) {
    return Math.min(1, (magnitude - GAZE_DEAD_ZONE_PX) / Math.max(1, toRightEdge - GAZE_DEAD_ZONE_PX))
  }
  return Math.max(-1, -((magnitude - GAZE_DEAD_ZONE_PX) / Math.max(1, toLeftEdge - GAZE_DEAD_ZONE_PX)))
}

export function gazeFromPointer(clientX, clientY, viewportWidth, viewportHeight, anchorRect) {
  const viewWidth = Math.max(1, Number(viewportWidth) || 1)
  const viewHeight = Math.max(1, Number(viewportHeight) || 1)
  const anchorX = anchorRect.left + anchorRect.width / 2
  const anchorY = anchorRect.top + anchorRect.height / 2
  const dx = Number(clientX) - anchorX
  const dy = Number(clientY) - anchorY
  const x = normalizeAxis(dx, anchorX, viewWidth - anchorX)
  const y = normalizeAxis(dy, anchorY, viewHeight - anchorY)
  return { x, y: y === 0 ? 0 : -y }
}

export function loadHiddenPreference(storage) {
  try {
    return storage?.getItem(PREFERENCE_KEY) === 'hidden'
  } catch {
    return false
  }
}

export function saveHiddenPreference(storage, hidden) {
  try {
    storage?.setItem(PREFERENCE_KEY, hidden ? 'hidden' : 'visible')
  } catch {
    // Storage can be disabled without disabling the character for this page.
  }
}

export function loadLastSession(storage) {
  try {
    return storage?.getItem(SESSION_KEY) ?? ''
  } catch {
    return ''
  }
}

export function saveLastSession(storage, sessionId) {
  try {
    if (sessionId) {
      storage?.setItem(SESSION_KEY, sessionId)
    } else {
      storage?.removeItem(SESSION_KEY)
    }
  } catch {
    // Storage can be disabled without disabling session detection for this page.
  }
}

export function CharacterLayer({
  enabled,
  personality,
  llmSay = null,
  model = DEFAULT_MODEL,
  timer,
  sessions,
  currentSessionId,
  frameHost,
  onStatus,
}) {
  const [state, dispatch] = React.useReducer(
    reduceCharacterState,
    null,
    () => ({
      ...initialCharacterState,
      enabled,
      hidden: loadHiddenPreference(window.localStorage),
    }),
  )
  const [assetPhase, setAssetPhase] = React.useState('idle')
  const adapterRef = React.useRef(null)
  const controllerRef = React.useRef(null)
  const personalityRef = React.useRef(personality)
  const llmSayRef = React.useRef(llmSay)
  const modelRef = React.useRef(model)

  React.useEffect(() => {
    personalityRef.current = personality
  }, [personality])
  React.useEffect(() => { llmSayRef.current = llmSay }, [llmSay])
  React.useEffect(() => { modelRef.current = model }, [model])

  React.useEffect(() => {
    dispatch({ type: enabled ? 'enable' : 'disable' })
  }, [enabled])

  React.useEffect(() => {
    if (!enabled) {
      setAssetPhase('idle')
      onStatus('off')
      return undefined
    }
    let active = true
    setAssetPhase('checking')
    onStatus('checking')
    fetch(STATUS_PATH)
      .then((response) => {
        if (!response.ok) throw new Error(`status ${response.status}`)
        return response.json()
      })
      .then((status) => {
        if (!active) return
        if (status?.ready === true && status.basePath === '/__sakura_live2d') {
          setAssetPhase('ready')
          onStatus('ready')
        } else {
          setAssetPhase('missing')
          onStatus('missing')
        }
      })
      .catch(() => {
        if (!active) return
        setAssetPhase('missing')
        onStatus('missing')
      })
    return () => {
      active = false
    }
  }, [enabled, onStatus])

  React.useEffect(() => {
    if (!enabled || assetPhase !== 'ready') {
      return undefined
    }
    const controller = createCharacterController({
      timer,
      personality: personalityRef.current,
      llmSay: llmSayRef.current,
      model: modelRef.current,
      showBubble: (bubble) => dispatch({ type: 'bubble', bubble }),
      dismissBubble: () => dispatch({ type: 'dismiss' }),
      playMotion: (id) => adapterRef.current?.playMotion(id),
      playExpression: (id) => adapterRef.current?.playExpression(id),
    })
    controllerRef.current = controller
    return () => {
      controller.destroy()
      if (controllerRef.current === controller) {
        controllerRef.current = null
      }
    }
  }, [assetPhase, enabled, timer])

  React.useEffect(() => {
    controllerRef.current?.setPersonality(personality, { announce: !state.hidden })
  }, [assetPhase, enabled, personality])

  React.useEffect(() => {
    controllerRef.current?.setLlmSay(llmSay)
  }, [assetPhase, enabled, llmSay])

  React.useEffect(() => {
    controllerRef.current?.setModel(model)
  }, [assetPhase, enabled, model])

  React.useEffect(() => {
    if (
      !enabled
      || assetPhase !== 'ready'
      || frameHost === null
      || controllerRef.current === null
    ) {
      if (adapterRef.current !== null) {
        adapterRef.current.destroyRuntime()
        adapterRef.current = null
      }
      return undefined
    }
    const controller = controllerRef.current
    let adapter
    adapter = createRuntimeAdapter({
      timer,
      onEvent(event) {
        if (event.type === 'ready') {
          dispatch({ type: 'ready' })
          controller.runtimeReady()
        } else if (event.type === 'hit') {
          controller.runtimeHit(event.area)
        } else if (event.type === 'error') {
          dispatch({ type: 'error', code: event.code })
          controller.runtimeError()
          onStatus('error')
          adapter.destroyRuntime()
          if (adapterRef.current === adapter) {
            adapterRef.current = null
          }
        }
      },
    })
    adapterRef.current = adapter
    adapter.mount(frameHost)
    return () => {
      adapter.destroy()
    }
  }, [assetPhase, enabled, frameHost, onStatus, timer])

  React.useEffect(() => {
    frameHost?.classList.toggle('gal-hidden', !enabled || state.hidden)
  }, [enabled, frameHost, state.hidden])

  React.useEffect(() => {
    if (
      !enabled
      || assetPhase !== 'ready'
      || controllerRef.current === null
    ) {
      return undefined
    }
    const controller = controllerRef.current
    const storedSession = loadLastSession(window.localStorage)
    saveLastSession(window.localStorage, currentSessionId)
    controller.sessionChanged()
    controller.sessionSwitched(Boolean(storedSession && currentSessionId && storedSession !== currentSessionId))
    if (!currentSessionId) {
      return undefined
    }
    const session = sessions.binding(currentSessionId)?.session
    if (!session) {
      return undefined
    }
    return subscribeToSession(
      session,
      (snapshot) => controller.sessionSnapshot(snapshot),
    )
  }, [assetPhase, currentSessionId, enabled, sessions])

  React.useEffect(() => {
    if (!enabled || state.hidden || assetPhase !== 'ready') {
      return undefined
    }
    let frame = 0
    let pending = null
    let lastActivityAt = 0

    const flushPointer = () => {
      frame = 0
      if (!pending) return
      adapterRef.current?.lookAt(pending.x, pending.y)
      pending = null
    }
    const onPointerMove = (event) => {
      if (frameHost === null) {
        return
      }
      pending = gazeFromPointer(
        event.clientX,
        event.clientY,
        window.innerWidth,
        window.innerHeight,
        frameHost.getBoundingClientRect(),
      )
      if (frame === 0) {
        frame = window.requestAnimationFrame(flushPointer)
      }
      const now = Date.now()
      if (now - lastActivityAt >= 1000) {
        lastActivityAt = now
        controllerRef.current?.pointerActivity()
      }
    }
    const onPointerDown = () => controllerRef.current?.pointerActivity()
    const onPointerLeave = (event) => {
      if (event.relatedTarget === null) {
        adapterRef.current?.lookAt(0, 0)
      }
    }
    const onBlur = () => adapterRef.current?.lookAt(0, 0)

    window.addEventListener('pointermove', onPointerMove, { passive: true })
    window.addEventListener('pointerdown', onPointerDown, { passive: true })
    window.addEventListener('pointerout', onPointerLeave, { passive: true })
    window.addEventListener('blur', onBlur)
    return () => {
      window.removeEventListener('pointermove', onPointerMove)
      window.removeEventListener('pointerdown', onPointerDown)
      window.removeEventListener('pointerout', onPointerLeave)
      window.removeEventListener('blur', onBlur)
      if (frame !== 0) {
        window.cancelAnimationFrame(frame)
      }
    }
  }, [assetPhase, enabled, state.hidden, frameHost])

  const hide = () => {
    controllerRef.current?.dismiss()
    saveHiddenPreference(window.localStorage, true)
    dispatch({ type: 'hide' })
  }
  const restore = () => {
    saveHiddenPreference(window.localStorage, false)
    dispatch({ type: 'restore' })
  }
  const dismiss = () => controllerRef.current?.dismiss()
  const interact = (area) => controllerRef.current?.runtimeHit(area)

  if (!enabled || !state.enabled || assetPhase !== 'ready') {
    return null
  }
  if (state.hidden) {
    return React.createElement('button', {
      className: 'gal-character-restore',
      type: 'button',
      onClick: restore,
      title: '恢复虚拟角色',
    }, '唤回日和')
  }

  const children = [
    React.createElement('div', {
      key: 'stage',
      className: 'gal-character-stage',
      'aria-label': '虚拟角色 桃濑日和',
    }),
    React.createElement('button', {
      key: 'hit-body',
      className: 'gal-character-hit gal-character-hit-body',
      type: 'button',
      onClick: () => interact('Body'),
      'aria-label': '与桃濑日和互动',
    }),
  ]
  if (state.bubble) {
    children.push(React.createElement('button', {
      key: 'bubble',
      className: 'gal-character-bubble',
      type: 'button',
      onClick: dismiss,
      title: '关闭气泡',
    }, state.bubble.text))
  }
  children.push(React.createElement('div', {
    key: 'tools',
    className: 'gal-character-tools',
  },
  React.createElement('button', {
    className: 'gal-character-tool',
    type: 'button',
    onClick: hide,
  }, '隐藏')))

  return React.createElement('div', {
    className: 'gal-character-root',
    'data-ready': state.ready ? 'true' : 'false',
  }, ...children)
}
