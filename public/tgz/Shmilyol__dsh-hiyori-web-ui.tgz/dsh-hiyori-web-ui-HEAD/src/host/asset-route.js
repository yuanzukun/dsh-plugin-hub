import { ASSET_PREFIX } from '../shared/protocol.js'

const MIME = new Map([
  ['.html', 'text/html; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.moc3', 'application/octet-stream'],
  ['.wav', 'audio/wav'],
])

function extension(path) {
  for (const suffix of [...MIME.keys()].sort((left, right) => right.length - left.length)) {
    if (path.endsWith(suffix)) {
      return suffix
    }
  }
  return ''
}

function relativeAssetPath(url) {
  try {
    const rawPath = String(url ?? '').split('?', 1)[0].split('#', 1)[0]
    if (!rawPath.startsWith(`${ASSET_PREFIX}/`)) {
      return null
    }
    const decoded = decodeURIComponent(rawPath.slice(ASSET_PREFIX.length + 1))
    if (!decoded || decoded.includes('..') || decoded.includes('\\') || decoded.startsWith('/')) {
      return null
    }
    return decoded
  } catch {
    return null
  }
}

export function createAssetHandler({ fs, manifest, maxBytes = 32 * 1024 * 1024 }) {
  return async function handle(req, res) {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { allow: 'GET, HEAD' })
      res.end()
      return
    }

    const relative = relativeAssetPath(req.url)
    if (
      relative === null
      || !Object.hasOwn(manifest.files, relative)
      || typeof manifest.files[relative] !== 'object'
    ) {
      res.writeHead(404)
      res.end()
      return
    }

    const entry = manifest.files[relative]
    if (!Number.isSafeInteger(entry.size) || entry.size < 0 || entry.size > maxBytes) {
      res.writeHead(413)
      res.end()
      return
    }

    const headers = {
      'content-type': MIME.get(extension(relative)) ?? 'application/octet-stream',
      'content-length': String(entry.size),
      'cache-control': relative === 'runtime/index.html' || relative === 'runtime/companion-bridge.js'
        ? 'no-cache'
        : 'public, max-age=31536000, immutable',
      'access-control-allow-origin': '*',
      'x-content-type-options': 'nosniff',
    }
    if (req.method === 'HEAD') {
      res.writeHead(200, headers)
      res.end()
      return
    }

    try {
      const target = await fs.resolve(entry.path)
      const bytes = await fs.readBytes(target, undefined, maxBytes)
      if (bytes.byteLength !== entry.size) {
        throw new Error('Asset size differs from the install manifest')
      }
      res.writeHead(200, headers)
      res.end(bytes)
    } catch {
      res.writeHead(500)
      res.end()
    }
  }
}
