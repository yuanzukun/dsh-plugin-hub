import {
  ASSET_PREFIX,
  CHAT_CONFIG_PATH,
  MODELS_PATH,
  SAY_PATH,
  STATUS_PATH,
} from '../shared/protocol.js'
import { createAssetHandler } from './asset-route.js'
import { inspectAssetStatus } from './asset-status.js'
import { createChatHandlers } from './chat-route.js'
import { createDeepSeekClient } from './deepseek.js'

const manifest = __LIVE2D_MANIFEST__

const name = 'dsh-hiyori-web-ui'
const inject = ['webServer', 'fs', 'credentials']

function sendJson(res, value) {
  const body = JSON.stringify(value)
  res.writeHead(200, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': String(Buffer.byteLength(body)),
    'cache-control': 'no-cache',
    'access-control-allow-origin': '*',
    'x-content-type-options': 'nosniff',
  })
  res.end(body)
}

function apply(ctx) {
  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: ASSET_PREFIX,
    handler: createAssetHandler({ fs: ctx.fs, manifest }),
  }))
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: STATUS_PATH,
    handler: async (req, res) => {
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        res.writeHead(405, { allow: 'GET, HEAD' })
        res.end()
        return
      }
      sendJson(res, await inspectAssetStatus(ctx.fs, manifest))
    },
  }))

  const deepseek = createDeepSeekClient({ credentials: ctx.credentials })
  const chat = createChatHandlers({ deepseek, credentials: ctx.credentials })
  ctx.effect(() => ctx.webServer.register({ kind: 'exact', path: SAY_PATH, handler: chat.say }))
  ctx.effect(() => ctx.webServer.register({ kind: 'exact', path: MODELS_PATH, handler: chat.models }))
  ctx.effect(() => ctx.webServer.register({ kind: 'exact', path: CHAT_CONFIG_PATH, handler: chat.chatConfig }))
}

export { name, inject, apply }
