import { CREDENTIAL_REF } from '../shared/protocol.js'

const DEFAULT_BASE_URL = 'https://api.deepseek.com'
const DEFAULT_MAX_TOKENS = 64
const THINKING_MODELS = new Set(['deepseek-v4-pro', 'deepseek-reasoner'])

export function createDeepSeekClient({
  credentials,
  fetchImpl = fetch,
  baseURL = DEFAULT_BASE_URL,
  maxTokens = DEFAULT_MAX_TOKENS,
} = {}) {
  async function resolveKey() {
    const resolved = await credentials.resolve(CREDENTIAL_REF)
    return resolved?.value
  }

  async function complete({ model, messages, signal }) {
    const key = await resolveKey()
    if (!key) {
      throw Object.assign(new Error('DeepSeek API key is not configured'), { code: 'MISSING_KEY' })
    }
    const body = { model, stream: false, max_tokens: maxTokens, messages }
    if (!THINKING_MODELS.has(model)) {
      body.temperature = 0.9
    }
    let response
    try {
      response = await fetchImpl(`${baseURL}/chat/completions`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
        body: JSON.stringify(body),
        signal,
      })
    } catch (err) {
      throw Object.assign(new Error('DeepSeek request failed'), { code: 'NETWORK', cause: err })
    }
    if (!response.ok) {
      throw Object.assign(new Error(`DeepSeek responded ${response.status}`), { code: `HTTP_${response.status}` })
    }
    let json
    try {
      json = await response.json()
    } catch (err) {
      throw Object.assign(new Error('DeepSeek returned an unparseable response'), { code: 'NETWORK', cause: err })
    }
    const text = json?.choices?.[0]?.message?.content
    if (typeof text !== 'string' || text.trim() === '') {
      throw Object.assign(new Error('DeepSeek returned an empty completion'), { code: 'EMPTY' })
    }
    return text.trim()
  }

  async function listModels({ signal } = {}) {
    const key = await resolveKey()
    if (!key) return []
    try {
      const response = await fetchImpl(`${baseURL}/models`, {
        headers: { authorization: `Bearer ${key}` },
        signal,
      })
      if (!response.ok) return []
      const json = await response.json()
      return (json?.data ?? [])
        .map((entry) => entry?.id)
        .filter((id) => typeof id === 'string' && id.length > 0)
    } catch {
      return []
    }
  }

  return { complete, listModels }
}
