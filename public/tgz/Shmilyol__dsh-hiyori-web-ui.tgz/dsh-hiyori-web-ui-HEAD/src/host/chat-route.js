import { CREDENTIAL_REF, DEFAULT_MODEL } from '../shared/protocol.js'

const MAX_BODY_BYTES = 16 * 1024

function sendJson(res, status, value) {
  const body = JSON.stringify(value)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': String(Buffer.byteLength(body)),
    'cache-control': 'no-cache',
    'x-content-type-options': 'nosniff',
  })
  res.end(body)
}

function methodNotAllowed(res, allow) {
  res.writeHead(405, { allow })
  res.end()
}

async function readJsonBody(req) {
  const chunks = []
  let total = 0
  for await (const chunk of req) {
    const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    total += bytes.byteLength
    if (total > MAX_BODY_BYTES) {
      const err = new Error('request body too large')
      err.statusCode = 413
      throw err
    }
    chunks.push(bytes)
  }
  if (chunks.length === 0) return {}
  let parsed
  try {
    parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'))
  } catch {
    const err = new Error('invalid JSON body')
    err.statusCode = 400
    throw err
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    const err = new Error('invalid JSON body')
    err.statusCode = 400
    throw err
  }
  return parsed
}

function normalizeModel(value) {
  return typeof value === 'string' && value.length > 0 && value.length <= 128 ? value : DEFAULT_MODEL
}

export function maskKey(key) {
  const value = typeof key === 'string' ? key : ''
  if (value === '') return ''
  if (value.length <= 8) return '****'
  return `${value.slice(0, 7)}****${value.slice(-4)}`
}

export function createChatHandlers({ deepseek, credentials }) {
  async function say(req, res) {
    if (req.method !== 'POST') return methodNotAllowed(res, 'POST')
    let body
    try {
      body = await readJsonBody(req)
    } catch (err) {
      return sendJson(res, err.statusCode ?? 400, { ok: false, code: 'BAD_REQUEST' })
    }
    const model = normalizeModel(body.model)
    const messages = Array.isArray(body.messages) ? body.messages : []
    if (messages.length === 0) {
      return sendJson(res, 400, { ok: false, code: 'BAD_REQUEST' })
    }
    try {
      const text = await deepseek.complete({ model, messages })
      return sendJson(res, 200, { ok: true, text })
    } catch (err) {
      if (err?.code === 'MISSING_KEY') {
        return sendJson(res, 200, { ok: false, code: 'missing_key' })
      }
      return sendJson(res, 502, { ok: false, code: 'upstream_error' })
    }
  }

  async function models(req, res) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return methodNotAllowed(res, 'GET, HEAD')
    return sendJson(res, 200, { models: await deepseek.listModels() })
  }

  async function getConfig(req, res) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return methodNotAllowed(res, 'GET, HEAD')
    const info = await credentials.describe(CREDENTIAL_REF)
    let masked = ''
    if (info?.configured) {
      const resolved = await credentials.resolve(CREDENTIAL_REF)
      masked = maskKey(resolved?.value)
    }
    return sendJson(res, 200, { configured: Boolean(info?.configured), masked })
  }

  async function setConfig(req, res) {
    if (req.method !== 'POST') return methodNotAllowed(res, 'POST')
    let body
    try {
      body = await readJsonBody(req)
    } catch (err) {
      return sendJson(res, err.statusCode ?? 400, { ok: false, code: 'BAD_REQUEST' })
    }
    const key = typeof body.apiKey === 'string' ? body.apiKey.trim() : ''
    try {
      if (key === '') {
        await credentials.unset(CREDENTIAL_REF)
      } else {
        await credentials.set(CREDENTIAL_REF, key)
      }
    } catch {
      return sendJson(res, 409, { ok: false, code: 'not_writable' })
    }
    const info = await credentials.describe(CREDENTIAL_REF)
    return sendJson(res, 200, { ok: true, configured: Boolean(info?.configured) })
  }

  async function chatConfig(req, res) {
    if (req.method === 'GET' || req.method === 'HEAD') return getConfig(req, res)
    if (req.method === 'POST') return setConfig(req, res)
    return methodNotAllowed(res, 'GET, POST')
  }

  return { say, models, chatConfig }
}
