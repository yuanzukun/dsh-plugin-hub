export const ASSET_PREFIX = '/__sakura_live2d'
export const RUNTIME_PAGE = `${ASSET_PREFIX}/runtime/index.html`
export const STATUS_PATH = `${ASSET_PREFIX}/status`
export const SAY_PATH = `${ASSET_PREFIX}/say`
export const MODELS_PATH = `${ASSET_PREFIX}/models`
export const CHAT_CONFIG_PATH = `${ASSET_PREFIX}/chat-config`
export const CREDENTIAL_REF = 'HIYORI_DEEPSEEK_API_KEY'
export const DEFAULT_MODELS = ['deepseek-v4-flash', 'deepseek-v4-pro']
export const DEFAULT_MODEL = 'deepseek-v4-flash'

const MOTIONS = new Set([
  'Idle',
  'Flick',
  'FlickDown',
  'FlickUp',
  'Tap',
  'Tap@Body',
  'Flick@Body',
])

const EXPRESSIONS = new Set([
  'joy',
  'sad',
  'angry',
  'proud',
  'shy',
  'sleepy',
  'relief',
  'surprise',
])

function clamp(value) {
  return Math.max(-1, Math.min(1, Number(value) || 0))
}

export function makeCommand(type, payload = {}) {
  if (type === 'pointer') {
    return {
      source: 'sakura-vn-parent',
      type,
      x: clamp(payload.x),
      y: clamp(payload.y),
    }
  }
  if (type === 'motion' && MOTIONS.has(payload.id)) {
    return { source: 'sakura-vn-parent', type, id: payload.id }
  }
  if (type === 'expression' && EXPRESSIONS.has(payload.id)) {
    return { source: 'sakura-vn-parent', type, id: payload.id }
  }
  if (type === 'destroy') {
    return { source: 'sakura-vn-parent', type }
  }
  throw new TypeError(`Unsupported companion command: ${type}`)
}

export function parseRuntimeEvent(value) {
  if (value === null || typeof value !== 'object' || value.source !== 'sakura-vn-runtime') {
    return null
  }
  if (value.type === 'ready') {
    return { type: 'ready' }
  }
  if (value.type === 'error' && typeof value.code === 'string') {
    return { type: 'error', code: value.code.slice(0, 64) }
  }
  if (value.type === 'hit' && value.area === 'Body') {
    return { type: 'hit', area: value.area }
  }
  return null
}
