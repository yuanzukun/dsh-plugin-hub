import { build } from 'esbuild'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname, isAbsolute, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)))
const HOST_ENTRY = fileURLToPath(new URL('../src/host/plugin.js', import.meta.url))
const CLIENT_ENTRY = fileURLToPath(new URL('./client-template.js', import.meta.url))
const REACT_SHIM = fileURLToPath(new URL('./react-shim.js', import.meta.url))
const DEFAULT_MANIFEST = fileURLToPath(new URL('../assets/live2d/manifest.json', import.meta.url))
export const HOST_OUTPUT_PATH = fileURLToPath(new URL('../lib/index.js', import.meta.url))
export const CLIENT_OUTPUT_PATH = fileURLToPath(new URL('../lib/client.js', import.meta.url))

const PLUGIN_ID = 'dsh-hiyori-web-ui'

function expandManifestPaths(manifestPath, stored) {
  const root = dirname(resolve(manifestPath))
  const files = {}
  for (const [key, entry] of Object.entries(stored.files ?? {})) {
    const path = resolve(root, entry.path)
    const child = relative(root, path)
    if (child === '..' || child.startsWith(`..${process.platform === 'win32' ? '\\' : '/'}`) || isAbsolute(child)) {
      throw new Error(`Manifest path is outside the install directory: ${entry.path}`)
    }
    files[key] = { ...entry, path }
  }
  return { ...stored, files }
}

/** Build the Host plugin as an ES module exporting `{ name, inject, apply }`. */
export async function buildHostModule({
  manifestPath = DEFAULT_MANIFEST,
  write = true,
  outputPath = HOST_OUTPUT_PATH,
} = {}) {
  const stored = JSON.parse(await readFile(manifestPath, 'utf8'))
  const manifest = expandManifestPaths(manifestPath, stored)
  const result = await build({
    entryPoints: [HOST_ENTRY],
    bundle: true,
    format: 'esm',
    write: false,
    legalComments: 'none',
    define: { __LIVE2D_MANIFEST__: JSON.stringify(manifest) },
  })
  const body = result.outputFiles[0].text
  if (write) {
    await mkdir(dirname(outputPath), { recursive: true })
    await writeFile(outputPath, body)
  }
  return body
}

/** Build the browser Client bundle as a `window.__ModuleLoader__.load` module. */
export async function buildClientBundle({
  write = true,
  outputPath = CLIENT_OUTPUT_PATH,
} = {}) {
  const result = await build({
    entryPoints: [CLIENT_ENTRY],
    bundle: true,
    format: 'cjs',
    external: ['react', 'react/jsx-runtime', 'react-dom'],
    inject: [REACT_SHIM],
    write: false,
    legalComments: 'none',
    charset: 'utf8',
  })
  const body = result.outputFiles[0].text.replace(/\n+$/, '\n')
  const client = `window.__ModuleLoader__.load({
  id: ${JSON.stringify(PLUGIN_ID)},
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
${body}
    return module.exports;
  }
});
`
  if (write) {
    await mkdir(dirname(outputPath), { recursive: true })
    await writeFile(outputPath, client)
  }
  return client
}

export async function buildPackage({
  manifestPath = DEFAULT_MANIFEST,
  write = true,
} = {}) {
  const host = await buildHostModule({ manifestPath, write })
  const client = await buildClientBundle({ write })
  return { host, client }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const manifestPath = process.argv[2]
  if (manifestPath) await buildPackage({ manifestPath })
  else await buildPackage()
}
