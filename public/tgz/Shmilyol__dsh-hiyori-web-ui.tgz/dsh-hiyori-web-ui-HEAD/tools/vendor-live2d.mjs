import { createHash } from 'node:crypto'
import { createReadStream, createWriteStream } from 'node:fs'
import {
  access,
  cp,
  mkdir,
  mkdtemp,
  readFile,
  readdir,
  rename,
  rm,
  stat,
  writeFile,
} from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, dirname, join, relative, resolve, sep } from 'node:path'
import { spawn } from 'node:child_process'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { fileURLToPath, pathToFileURL } from 'node:url'

export const SDK_VERSION = '5-r.5'
export const SAMPLES_COMMIT = 'ed1e0b714826d92469b9e51cacc3346f4e393f03'
export const FRAMEWORK_COMMIT = '198a3769c26ca3d7b600e932590433badd392edd'
export const SAMPLES_ARCHIVE =
  `https://github.com/Live2D/CubismWebSamples/archive/${SAMPLES_COMMIT}.tar.gz`
export const FRAMEWORK_ARCHIVE =
  `https://github.com/Live2D/CubismWebFramework/archive/${FRAMEWORK_COMMIT}.tar.gz`

const PROJECT_ROOT = dirname(dirname(fileURLToPath(import.meta.url)))
const OUTPUT_ROOT = join(PROJECT_ROOT, 'assets', 'live2d')
const ALLOWED_DOWNLOAD_HOSTS = new Set(['github.com', 'codeload.github.com'])
const MODEL_SOURCE_NAME = 'hiyori_pro_t11.model3.json'
const MODEL_PUBLIC_NAME = 'Hiyori.model3.json'
const CORE_PUBLIC_FILES = [
  'live2dcubismcore.js',
  'LICENSE.md',
  'RedistributableFiles.txt',
]

async function exists(path) {
  return access(path).then(() => true, () => false)
}

async function requireFile(path) {
  const info = await stat(path).catch(() => undefined)
  if (!info?.isFile()) throw new Error(`Missing required file: ${path}`)
}

function collectModelReferences(model) {
  const refs = model.FileReferences ?? {}
  const values = [refs.Moc, refs.Physics, refs.Pose, refs.DisplayInfo, ...(refs.Textures ?? [])]
  for (const expression of refs.Expressions ?? []) values.push(expression.File)
  for (const motions of Object.values(refs.Motions ?? {})) {
    for (const motion of motions) values.push(motion.File, motion.Sound)
  }
  return values.filter(Boolean)
}

export function validateSdkArchiveName(sdkZip) {
  const name = basename(String(sdkZip ?? '')).toLowerCase()
  if (!name.endsWith('.zip') || !name.includes(SDK_VERSION)) {
    throw new Error(`Cubism SDK archive filename must identify ${SDK_VERSION}`)
  }
}

export async function validateHiyori(hiyoriRoot) {
  const model = JSON.parse(await readFile(join(hiyoriRoot, MODEL_SOURCE_NAME), 'utf8'))
  for (const referenced of collectModelReferences(model)) {
    await requireFile(join(hiyoriRoot, referenced))
  }
  const refs = model.FileReferences ?? {}
  const motions = Object.values(refs.Motions ?? {}).flat()
  const hitNames = (model.HitAreas ?? []).map((area) => area.Name)
  if (refs.Expressions !== undefined) throw new Error('Hiyori Pro must not depend on Expressions')
  if (refs.Textures?.length !== 2) throw new Error('Hiyori Pro requires exactly two textures')
  if (motions.length !== 10) throw new Error('Hiyori Pro requires exactly ten motions')
  if (hitNames.length !== 1 || hitNames[0] !== 'Body') {
    throw new Error('Hiyori Pro requires only the Body hit area')
  }
  if (!Object.hasOwn(refs.Motions ?? {}, 'Tap@Body')) {
    throw new Error('Hiyori Pro requires the Tap@Body motion group')
  }
  return model
}

async function walk(root, dir = root) {
  const result = []
  const entries = await readdir(dir, { withFileTypes: true })
  entries.sort((left, right) => left.name.localeCompare(right.name))
  for (const entry of entries) {
    const path = join(dir, entry.name)
    if (entry.isDirectory()) result.push(...await walk(root, path))
    if (entry.isFile()) result.push(path)
  }
  return result
}

async function sha256(path) {
  const hash = createHash('sha256')
  for await (const chunk of createReadStream(path)) hash.update(chunk)
  return hash.digest('hex')
}

export async function buildManifest(root) {
  const publicRoot = join(root, 'public')
  const files = {}
  for (const path of await walk(publicRoot)) {
    const key = relative(publicRoot, path).split(sep).join('/')
    const info = await stat(path)
    files[key] = {
      path: `public/${key}`,
      size: info.size,
      sha256: await sha256(path),
    }
  }
  const manifest = {
    sdkVersion: SDK_VERSION,
    samplesCommit: SAMPLES_COMMIT,
    frameworkCommit: FRAMEWORK_COMMIT,
    model: 'Hiyori',
    files,
  }
  await writeFile(join(root, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`)
  return manifest
}

function spawnChecked(command, args, options = {}) {
  return new Promise((resolvePromise, rejectPromise) => {
    const child = spawn(command, args, { stdio: 'inherit', ...options })
    child.once('error', rejectPromise)
    child.once('exit', (code, signal) => {
      if (code === 0) return resolvePromise()
      rejectPromise(new Error(
        `${command} failed with ${signal ? `signal ${signal}` : `exit code ${code}`}`,
      ))
    })
  })
}

async function download(url, outputPath) {
  let current = new URL(url)
  for (let redirects = 0; redirects <= 5; redirects += 1) {
    if (!ALLOWED_DOWNLOAD_HOSTS.has(current.hostname)) {
      throw new Error(`Refusing download host: ${current.hostname}`)
    }
    const response = await fetch(current, { redirect: 'manual' })
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get('location')
      if (!location) throw new Error(`Download redirect has no location: ${current}`)
      current = new URL(location, current)
      continue
    }
    if (!response.ok || response.body === null) {
      throw new Error(`Download failed (${response.status}): ${current}`)
    }
    await pipeline(Readable.fromWeb(response.body), createWriteStream(outputPath, { flags: 'wx' }))
    return
  }
  throw new Error(`Too many redirects while downloading: ${url}`)
}

async function downloadAndExtract(url, destination, work) {
  await mkdir(destination, { recursive: true })
  const archive = join(work, `${basename(destination)}.tar.gz`)
  await download(url, archive)
  await spawnChecked('tar', ['-xzf', archive, '-C', destination, '--strip-components=1'])
}

async function findCoreDirectories(root) {
  const found = []
  async function visit(dir) {
    const entries = await readdir(dir, { withFileTypes: true })
    if (basename(dir) === 'Core' && entries.some((entry) => entry.name === 'live2dcubismcore.js')) {
      found.push(dir)
      return
    }
    for (const entry of entries) {
      if (entry.isDirectory()) await visit(join(dir, entry.name))
    }
  }
  await visit(root)
  return found
}

async function extractSdkCore(sdkZip, destination) {
  await mkdir(destination, { recursive: true })
  await spawnChecked('unzip', ['-q', resolve(sdkZip), '-d', destination])
  const roots = await findCoreDirectories(destination)
  if (roots.length !== 1) {
    throw new Error(`Expected exactly one Core directory in SDK zip, found ${roots.length}`)
  }
  for (const name of CORE_PUBLIC_FILES) await requireFile(join(roots[0], name))
  return roots[0]
}

async function prepareSources(work, coreRoot, hiyoriDir) {
  const samplesRoot = join(work, 'samples')
  const resourcesRoot = join(samplesRoot, 'Samples', 'Resources')
  const demoRoot = join(samplesRoot, 'Samples', 'TypeScript', 'Demo')
  await rm(join(samplesRoot, 'Framework'), { recursive: true, force: true })
  await rm(join(samplesRoot, 'Core'), { recursive: true, force: true })
  await cp(join(work, 'framework'), join(samplesRoot, 'Framework'), { recursive: true })
  await cp(coreRoot, join(samplesRoot, 'Core'), { recursive: true })
  await rm(resourcesRoot, { recursive: true, force: true })
  await mkdir(join(resourcesRoot, 'Hiyori'), { recursive: true })
  await cp(hiyoriDir, join(resourcesRoot, 'Hiyori'), { recursive: true })
  await cp(
    join(hiyoriDir, MODEL_SOURCE_NAME),
    join(resourcesRoot, 'Hiyori', MODEL_PUBLIC_NAME),
  )
  await rm(join(resourcesRoot, 'Hiyori', MODEL_SOURCE_NAME), { force: true })
  await mkdir(join(demoRoot, 'public'), { recursive: true })
  await cp(
    join(PROJECT_ROOT, 'runtime', 'bridge', 'companion-bridge.js'),
    join(demoRoot, 'public', 'companion-bridge.js'),
  )
  const patchPath = join(PROJECT_ROOT, 'runtime', 'patches', '5-r.5-companion.patch')
  await spawnChecked('git', ['apply', '--check', patchPath], { cwd: samplesRoot })
  await spawnChecked('git', ['apply', patchPath], { cwd: samplesRoot })
  return demoRoot
}

async function buildRuntime(demoRoot) {
  await spawnChecked('npm', ['install'], { cwd: demoRoot })
  await spawnChecked('npm', ['run', 'test'], { cwd: demoRoot })
  await spawnChecked('npm', ['run', 'build:prod'], { cwd: demoRoot })
}

async function stageAssets({ candidate, demoRoot, hiyoriDir, coreRoot }) {
  const publicRoot = join(candidate, 'public')
  const runtimeRoot = join(publicRoot, 'runtime')
  const distRoot = join(demoRoot, 'dist')
  await mkdir(runtimeRoot, { recursive: true })
  await cp(join(distRoot, 'index.html'), join(runtimeRoot, 'index.html'))
  await cp(join(distRoot, 'assets'), join(runtimeRoot, 'assets'), { recursive: true })
  await cp(join(distRoot, 'companion-bridge.js'), join(runtimeRoot, 'companion-bridge.js'))
  await mkdir(join(runtimeRoot, 'Core'), { recursive: true })
  for (const name of CORE_PUBLIC_FILES) {
    await cp(join(coreRoot, name), join(runtimeRoot, 'Core', name))
  }
  await mkdir(join(publicRoot, 'Resources', 'Hiyori'), { recursive: true })
  await cp(hiyoriDir, join(publicRoot, 'Resources', 'Hiyori'), { recursive: true })
  await cp(
    join(hiyoriDir, MODEL_SOURCE_NAME),
    join(publicRoot, 'Resources', 'Hiyori', MODEL_PUBLIC_NAME),
  )
  await rm(join(publicRoot, 'Resources', 'Hiyori', MODEL_SOURCE_NAME), { force: true })
  await rm(join(publicRoot, 'Resources', 'Hiyori', '.DS_Store'), { force: true })
  await cp(
    join(demoRoot, 'dist', 'Framework', 'Shaders', 'WebGL'),
    join(publicRoot, 'Framework', 'Shaders', 'WebGL'),
    { recursive: true },
  )
  const indexPath = join(runtimeRoot, 'index.html')
  const index = await readFile(indexPath, 'utf8')
  await writeFile(indexPath, index.replaceAll('src="/assets/', 'src="./assets/'))
  await mkdir(join(candidate, 'licenses'), { recursive: true })
  await cp(
    join(dirname(hiyoriDir), 'ReadMe.txt'),
    join(candidate, 'licenses', 'Hiyori-Pro-ReadMe.txt'),
  )
  await buildManifest(candidate)
}

export async function publishAssets(candidate, outputRoot = OUTPUT_ROOT) {
  const backup = `${outputRoot}.backup-${process.pid}-${Date.now()}`
  const hadPrevious = await exists(outputRoot)
  await mkdir(dirname(outputRoot), { recursive: true })
  try {
    if (hadPrevious) await rename(outputRoot, backup)
    await rename(candidate, outputRoot)
    if (hadPrevious) await rm(backup, { recursive: true, force: true })
  } catch (error) {
    await rm(outputRoot, { recursive: true, force: true })
    if (hadPrevious && await exists(backup)) await rename(backup, outputRoot)
    throw error
  }
}

export function parseVendorArgs(argv) {
  const options = { sdkZip: null, hiyoriDir: null }
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index]
    if (argument !== '--sdk-zip' && argument !== '--hiyori-dir') {
      throw new Error(`Unknown argument: ${argument}`)
    }
    const value = argv[index + 1]
    if (!value || value.startsWith('--')) throw new Error(`${argument} requires a path`)
    if (argument === '--sdk-zip') options.sdkZip = value
    if (argument === '--hiyori-dir') options.hiyoriDir = value
    index += 1
  }
  if (!options.sdkZip) throw new Error('Missing required --sdk-zip')
  if (!options.hiyoriDir) throw new Error('Missing required --hiyori-dir')
  return options
}

export async function vendorLive2D({ sdkZip, hiyoriDir }) {
  validateSdkArchiveName(sdkZip)
  await requireFile(resolve(sdkZip))
  await validateHiyori(resolve(hiyoriDir))
  const work = await mkdtemp(join(tmpdir(), 'sakura-live2d-vendor-'))
  const candidate = join(work, 'candidate')
  try {
    const coreRoot = await extractSdkCore(sdkZip, join(work, 'sdk'))
    await downloadAndExtract(SAMPLES_ARCHIVE, join(work, 'samples'), work)
    await downloadAndExtract(FRAMEWORK_ARCHIVE, join(work, 'framework'), work)
    const demoRoot = await prepareSources(work, coreRoot, resolve(hiyoriDir))
    await buildRuntime(demoRoot)
    await stageAssets({ candidate, demoRoot, hiyoriDir: resolve(hiyoriDir), coreRoot })
    await publishAssets(candidate)
    console.log(`Bundled 桃濑日和 Live2D resources at ${OUTPUT_ROOT}`)
    return 0
  } finally {
    await rm(work, { recursive: true, force: true })
  }
}

async function main() {
  process.exitCode = await vendorLive2D(parseVendorArgs(process.argv.slice(2)))
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.message : String(error))
    process.exitCode = 1
  })
}
