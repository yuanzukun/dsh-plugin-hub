// esbuild `inject` shim: replaces the free `React` global inside the bundled
// client modules with the platform's React module (resolved via the client
// module loader's `require("react")` seed at runtime).
import * as React from 'react'

export { React }
