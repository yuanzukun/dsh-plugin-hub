import { createHash } from 'node:crypto'
import { createReadStream } from 'node:fs'
import { access, readFile, readdir, stat } from 'node:fs/promises'
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path'
import { spawn } from 'node:child_process'
import { fileURLToPath, pathToFileURL } from 'node:url'

const PROJECT_ROOT = dirname(dirname(fileURLToPath(import.meta.url)))
const REQUIRED_ASSETS = [
  'runtime/index.html',
  'runtime/Core/live2dcubismcore.js',
  'Resources/Hiyori/Hiyori.model3.json',
  'Resources/Hiyori/hiyori_pro_t11.2048/texture_00.png',
  'Resources/Hiyori/hiyori_pro_t11.2048/texture_01.png',
]

function spawnChecked(command, args, { cwd } = {}) {
  return new Promise((resolvePromise, rejectPromise) => {
    const child = spawn(command, args, { cwd, stdio: 'inherit' })
    child.once('error', rejectPromise)
    child.once('exit', (code, signal) => {
      if (code === 0) return resolvePromise()
      rejectPromise(new Error(
        `${command} failed with ${signal ? `signal ${signal}` : `exit code ${code}`}`,
      ))
    })
  })
}

async function sha256(path) {
  const hash = createHash('sha256')
  for await (const chunk of createReadStream(path)) hash.update(chunk)
  return hash.digest('hex')
}

async function walk(root, dir = root) {
  const files = []
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name)
    if (entry.isDirectory()) files.push(...await walk(root, path))
    if (entry.isFile()) files.push(relative(root, path).split(sep).join('/'))
  }
  return files.sort()
}

export function parseSetupArgs(argv) {
  if (argv.length > 0) throw new Error(`Unknown argument: ${argv[0]}`)
  return {}
}

export async function verifyBundledAssets({ projectRoot = PROJECT_ROOT } = {}) {
  const root = join(projectRoot, 'assets', 'live2d')
  const manifestPath = join(root, 'manifest.json')
  const manifest = JSON.parse(await readFile(manifestPath, 'utf8'))
  if (manifest.sdkVersion !== '5-r.5' || manifest.model !== 'Hiyori') {
    throw new Error('Bundled Live2D manifest must identify Hiyori on SDK 5-r.5')
  }
  const entries = Object.entries(manifest.files ?? {})
  if (entries.length === 0) throw new Error('Bundled Live2D manifest has no resources')
  for (const key of REQUIRED_ASSETS) {
    if (!Object.hasOwn(manifest.files, key)) {
      throw new Error(`Bundled Live2D manifest is missing required resource: ${key}`)
    }
  }
  const publicKeys = await walk(join(root, 'public'))
  const manifestKeys = entries.map(([key]) => key).sort()
  if (
    publicKeys.length !== manifestKeys.length
    || publicKeys.some((key, index) => key !== manifestKeys[index])
  ) {
    throw new Error('Bundled Live2D public files do not match the manifest')
  }
  for (const [key, entry] of entries) {
    const target = resolve(root, entry.path)
    const child = relative(root, target)
    if (
      child === ''
      || child === '..'
      || child.startsWith(`..${sep}`)
      || isAbsolute(child)
      || !child.startsWith(`public${sep}`)
    ) {
      throw new Error(`Bundled resource path escapes assets/live2d: ${key}`)
    }
    const info = await stat(target)
    if (!info.isFile() || !Number.isSafeInteger(entry.size) || info.size !== entry.size) {
      throw new Error(`Bundled resource size mismatch: ${key}`)
    }
    if (!/^[a-f0-9]{64}$/.test(entry.sha256) || await sha256(target) !== entry.sha256) {
      throw new Error(`Bundled resource sha256 mismatch: ${key}`)
    }
  }
  return manifest
}

async function defaultVerifyOutputs(projectRoot) {
  const outputs = [
    join(projectRoot, 'lib', 'index.js'),
    join(projectRoot, 'lib', 'client.js'),
  ]
  const results = await Promise.all(outputs.map(async (path) => {
    const info = await stat(path).catch(() => undefined)
    return info?.isFile() && info.size > 0
  }))
  return results.every(Boolean)
}

export async function runSetup({
  argv = process.argv.slice(2),
  projectRoot = PROJECT_ROOT,
  dependencyReady = () => access(join(projectRoot, 'node_modules', 'esbuild')).then(
    () => true,
    () => false,
  ),
  verifyAssets = () => verifyBundledAssets({ projectRoot }),
  runCommand = spawnChecked,
  buildClient,
  buildHost,
  verifyOutputs = () => defaultVerifyOutputs(projectRoot),
  write = console.log,
} = {}) {
  parseSetupArgs(argv)
  const nodeMajor = Number.parseInt(process.versions.node.split('.')[0], 10)
  if (nodeMajor < 20) {
    throw new Error(`Node.js 20 or newer is required; current version is ${process.versions.node}`)
  }

  write('正在校验仓库内置的桃濑日和 Live2D 资源…')
  await verifyAssets()

  if (!await dependencyReady()) {
    write('正在安装项目构建依赖…')
    await runCommand('npm', ['install'], { cwd: projectRoot })
  }

  const buildClientBody = buildClient ?? (await import('./build-package.mjs')).buildClientBundle
  const buildHostBody = buildHost ?? (await import('./build-package.mjs')).buildHostModule
  await buildClientBody()
  await buildHostBody({
    manifestPath: join(projectRoot, 'assets', 'live2d', 'manifest.json'),
  })

  if (!await verifyOutputs()) {
    throw new Error('构建完成，但未找到有效的 Host 和 Client 输出。')
  }
  write('桃濑日和资源校验完成。已生成 lib/index.js（主机端）和 lib/client.js（浏览器端）。')
  write(`下一步：运行  npx @deepseek-ai/dsh plugin --profile web add ${resolve(projectRoot)}  把插件常驻安装进 web 配置。`)
  return 0
}

async function main() {
  process.exitCode = await runSetup()
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.message : String(error))
    process.exitCode = 1
  })
}
