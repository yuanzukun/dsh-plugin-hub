/* ============================================================================
 * DSH 伴侣 — Client 端：暖色皮肤与桃濑日和伴侣。
 * 说明：背景色开关关闭时，背景 token 经 :has() 门控自动回归应用原值；装饰
 *       token 始终开启。官方 token 经 theme.overrideTokens 的 disposer 移除；
 *       停止插件即完全还原。
 * ========================================================================== */

import { CharacterLayer } from '../src/client/character-layer.js'
import { CHARACTER_CSS } from '../src/client/styles.js'
import { PERSONALITIES, loadPersonalityPreference, savePersonalityPreference } from '../src/client/personalities.js'
import { CHAT_CONFIG_PATH, DEFAULT_MODEL, DEFAULT_MODELS, MODELS_PATH } from '../src/shared/protocol.js'
import { createLlmProvider, loadModelPreference, saveModelPreference } from '../src/client/llm-provider.js'

/* ---- 样式注入：常驻插件没有 styles.insert，用 <style> 标签 + 卸载时移除 ---- */
function insertStyle(css) {
  const el = document.createElement('style')
  el.setAttribute('data-plugin', 'dsh-hiyori-web-ui')
  el.textContent = css
  document.head.append(el)
  return () => el.remove()
}

/* ---- 共享状态 store（跨 Slot 组件共享；内存态，插件生命周期有效） ---- */
const store = (() => {
  let state = {
    bg: true,
    sakura: true,
    character: true,
    characterStatus: 'checking',
    personality: 'gentle',
    model: DEFAULT_MODEL,
    chatConfigured: false,
    chatMasked: '',
    chatModels: DEFAULT_MODELS.slice(),
  }
  const subs = new Set()
  return {
    get: () => state,
    set: (patch) => {
      state = { ...state, ...patch }
      subs.forEach((f) => f(state))
    },
    sub: (f) => {
      subs.add(f)
      return () => subs.delete(f)
    },
  }
})()

/* ---- 官方主题 token 覆盖（亮/暗双套）。
   背景色（BG_TOKENS）随「背景颜色」开关叠加/移除；
   装饰 token（DECOR_TOKENS）始终开启，仅在插件卸载时移除。 ---- */
const BG_TOKENS = {
  '--dsw-alias-bg-base': { light: '#F6F0E4', dark: '#1F1917' },
  '--dsw-alias-bg-layer-1': { light: '#FBF6EC', dark: '#251E1B' },
  '--dsw-alias-bg-layer-2': { light: '#F3EADA', dark: '#2B2320' },
  '--dsw-alias-bg-overlay': { light: '#FBF6EC', dark: '#171210' },
  '--dsw-specific-sidebar-fill': { light: '#F1E8D8', dark: '#1A1513' },
}
const DECOR_TOKENS = {
  '--dsw-alias-border-l1': { light: 'rgba(62,47,35,0.08)', dark: 'rgba(242,232,213,0.08)' },
  '--dsw-alias-border-l2': { light: 'rgba(62,47,35,0.14)', dark: 'rgba(242,232,213,0.14)' },
  '--dsw-alias-brand-primary': { light: '#B03A2E', dark: '#D34B3C' },
  '--dsw-alias-label-primary': { light: '#3E2F23', dark: '#F2E8D5' },
  '--dsw-alias-label-secondary': { light: '#6E5C49', dark: '#CDBCA6' },
  '--dsw-alias-state-error-primary': { light: '#B3402F', dark: '#E07B6A' },
  '--dsw-alias-state-success-primary': { light: '#6E8B5E', dark: '#8FAE7A' },
  '--dsw-alias-state-warn-primary': { light: '#C98A3D', dark: '#D9A05B' },
}

/* ---- 皮肤 CSS：背景色经 :has() 门控随开关切换，装饰 token 无条件常驻 ---- */
const SKIN_CSS = String.raw`
/* ===== 变量层：背景色（受「背景颜色」开关门控） ===== */
@supports selector(:has(.gal-scene)) {
  body:has(.gal-scene[data-gal-state="on"]) {
    --dsw-alias-bg-layer-3: #EDE2CE;
    --dsw-alias-bg-mask-1: rgba(62,47,35,0.35);
    --dsw-alias-bg-mask-2: rgba(62,47,35,0.16);
    --dsw-alias-bg-mask-3: rgba(30,18,10,0.5);
    --dsw-alias-bg-skeleton: rgba(176,58,46,0.06);
    --dsw-alias-bg-module-platform: #EFE6D3;
    --dsw-alias-bg-multi-select: #EFE6D3;
  }
  body[data-ds-dark-theme]:has(.gal-scene[data-gal-state="on"]) {
    --dsw-alias-bg-layer-3: #322923;
    --dsw-alias-bg-mask-1: rgba(10,6,4,0.55);
    --dsw-alias-bg-mask-2: rgba(10,6,4,0.30);
    --dsw-alias-bg-mask-3: rgba(10,6,4,0.55);
    --dsw-alias-bg-skeleton: rgba(242,232,213,0.07);
    --dsw-alias-bg-module-platform: #322923;
    --dsw-alias-bg-multi-select: #322923;
  }
}
/* 不支持 :has() 的浏览器：背景色无法门控，默认常驻（开） */
@supports not selector(:has(.gal-scene)) {
  body {
    --dsw-alias-bg-layer-3: #EDE2CE;
    --dsw-alias-bg-mask-1: rgba(62,47,35,0.35);
    --dsw-alias-bg-mask-2: rgba(62,47,35,0.16);
    --dsw-alias-bg-mask-3: rgba(30,18,10,0.5);
    --dsw-alias-bg-skeleton: rgba(176,58,46,0.06);
    --dsw-alias-bg-module-platform: #EFE6D3;
    --dsw-alias-bg-multi-select: #EFE6D3;
  }
  body[data-ds-dark-theme] {
    --dsw-alias-bg-layer-3: #322923;
    --dsw-alias-bg-mask-1: rgba(10,6,4,0.55);
    --dsw-alias-bg-mask-2: rgba(10,6,4,0.30);
    --dsw-alias-bg-mask-3: rgba(10,6,4,0.55);
    --dsw-alias-bg-skeleton: rgba(242,232,213,0.07);
    --dsw-alias-bg-module-platform: #322923;
    --dsw-alias-bg-multi-select: #322923;
  }
}

/* ===== 变量层：装饰 token（始终开启） ===== */
body {
  --dsw-alias-border-inverted: rgba(62,47,35,0.10);
  --dsw-alias-border-inverted2: rgba(62,47,35,0.14);
  --dsw-alias-border-l2-darkmode-thin: rgba(62,47,35,0.10);
  --dsw-alias-border-l3: rgba(62,47,35,0.20);
  --dsw-alias-border-l4: rgba(62,47,35,0.26);
  --dsw-alias-brand-primary-invert: #F7EBD8;
  --dsw-alias-brand-text: #8E2F25;
  --dsw-alias-button-contrast-fill: #6B4A3A;
  --dsw-alias-button-elevated-fill: #FBF6EC;
  --dsw-alias-button-floating-fill: #FBF6EC;
  --dsw-alias-button-floating-hover: #F3EADA;
  --dsw-alias-button-ghost-active-border: #C9A96A;
  --dsw-alias-button-ghost-active-fill: #F3EADA;
  --dsw-alias-button-ghost-active-hover: #EDE2CE;
  --dsw-alias-button-info-fill: #C85A44;
  --dsw-alias-button-info-hover: #B84A36;
  --dsw-alias-button-primary-dimmed: #E8DCC8;
  --dsw-alias-button-primary-fill: #B03A2E;
  --dsw-alias-button-primary-hover: #9E3227;
  --dsw-alias-button-tool-bar-fill: rgba(176,58,46,0.18);
  --dsw-alias-button-tool-bar-fill-invisible: rgba(176,58,46,0.10);
  --dsw-alias-button-tool-bar-hover: rgba(176,58,46,0.26);
  --dsw-alias-interactive-bg-active: rgba(176,58,46,0.12);
  --dsw-alias-interactive-bg-hover: rgba(176,58,46,0.07);
  --dsw-alias-interactive-bg-hover-accent: rgba(176,58,46,0.14);
  --dsw-alias-interactive-bg-hover-danger: rgba(179,64,47,0.08);
  --dsw-alias-interactive-bg-hover-solid: #F3EADA;
  --dsw-alias-label-caption: #9B8A75;
  --dsw-alias-label-dimmed: #B7A892;
  --dsw-alias-label-primary-bluish: #5A4432;
  --dsw-alias-label-primary-dimmed: #4A3829;
  --dsw-alias-label-primary-foreground: #FBF6EC;
  --dsw-alias-label-primary-inverted: #FBF6EC;
  --dsw-alias-label-tertiary: #8A7761;
  --dsw-alias-markdown-citation: #F1E8D5;
  --dsw-alias-markdown-code-block: #F1E8D5;
  --dsw-alias-markdown-code-block-banner: #EADFC8;
  --dsw-alias-markdown-code-segment-selected: #FBF6EC;
  --dsw-alias-markdown-code-segment-unselected: #F3EADA;
  --dsw-alias-markdown-inline-code: #F1E8D5;
  --dsw-alias-markdown-placeholder: #EFE6D3;
  --dsw-alias-markdown-tag: #F3EADA;
  --dsw-alias-scrollbar-bg-l1: rgba(176,58,46,0.14);
  --dsw-alias-scrollbar-bg-l2: rgba(176,58,46,0.14);
  --dsw-alias-scrollbar-hover-l1: rgba(176,58,46,0.30);
  --dsw-alias-scrollbar-hover-l2: rgba(176,58,46,0.30);
  --dsw-alias-state-business-primary: #A63A2C;
  --dsw-alias-state-business-tertiary: #F1E8D5;
  --dsw-alias-state-success-secondary: #8FAE7A;
  --dsw-alias-state-success-tertiary: #E4EDDB;
  --dsw-alias-state-warn-label: #9A6B2F;
  --dsw-alias-state-warn-secondary: #D9A05B;
  --dsw-alias-state-warn-tertiary: #F5E8D2;
  --dsw-alias-toast-bg: #6B4A3A;
  --dsw-alias-tooltip-bg: #4A3829;
  --dsw-specific-bubble: #F3EAD8;
  --dsw-specific-bubble-highlight: #E8DCC0;
  --dsw-specific-input-major: #FBF6EC;
  --dsw-specific-login-input: #FBF6EC;
  --dsw-specific-menu: #F3EADA;
  --dsw-specific-selector: #EFE6D3;
  --dsw-specific-sidebar-nav-item-active: #EFE6D3;
  --dsw-specific-sidebar-nav-item-active-accent: #B03A2E;
  --dsw-specific-sidebar-nav-item-hover: #F3EADA;
  --dsw-specific-tip: #EFE6D3;
  --dsw-font-family: "Noto Serif SC","Source Han Serif SC","Songti SC","STSong","SimSun","PingFang SC","Microsoft YaHei",serif;
  --dsw-shadow-lv1: 0 2px 4px rgba(120,70,40,0.08);
  --dsw-shadow-lv2: 0 4px 12px rgba(120,70,40,0.06), 0 2px 8px rgba(120,70,40,0.10);
  --dsw-shadow-lv3: 0 0 1px rgba(120,70,40,0.18), 0 12px 32px rgba(120,70,40,0.12);
}
body[data-ds-dark-theme] {
  --dsw-alias-border-inverted: rgba(242,232,213,0.10);
  --dsw-alias-border-inverted2: rgba(242,232,213,0.14);
  --dsw-alias-border-l2-darkmode-thin: rgba(242,232,213,0.10);
  --dsw-alias-border-l3: rgba(242,232,213,0.18);
  --dsw-alias-border-l4: rgba(242,232,213,0.24);
  --dsw-alias-brand-primary-invert: #2A211C;
  --dsw-alias-brand-text: #E8D5C5;
  --dsw-alias-button-contrast-fill: #4A3A30;
  --dsw-alias-button-elevated-fill: #2B2320;
  --dsw-alias-button-floating-fill: #2B2320;
  --dsw-alias-button-floating-hover: #322923;
  --dsw-alias-button-ghost-active-border: #C9A96A;
  --dsw-alias-button-ghost-active-fill: #322923;
  --dsw-alias-button-ghost-active-hover: #3A302A;
  --dsw-alias-button-info-fill: #C85A44;
  --dsw-alias-button-info-hover: #D46850;
  --dsw-alias-button-primary-dimmed: #4A3A30;
  --dsw-alias-button-primary-fill: #C0392B;
  --dsw-alias-button-primary-hover: #D34B3C;
  --dsw-alias-button-tool-bar-fill: rgba(211,75,60,0.30);
  --dsw-alias-button-tool-bar-fill-invisible: rgba(211,75,60,0.16);
  --dsw-alias-button-tool-bar-hover: rgba(211,75,60,0.42);
  --dsw-alias-interactive-bg-active: rgba(242,232,213,0.14);
  --dsw-alias-interactive-bg-hover: rgba(242,232,213,0.08);
  --dsw-alias-interactive-bg-hover-accent: rgba(242,232,213,0.22);
  --dsw-alias-interactive-bg-hover-danger: rgba(224,123,106,0.16);
  --dsw-alias-interactive-bg-hover-solid: #322923;
  --dsw-alias-label-caption: #8F7F6C;
  --dsw-alias-label-dimmed: #6E5F4E;
  --dsw-alias-label-primary-bluish: #E8D5C5;
  --dsw-alias-label-primary-dimmed: #D8C8B2;
  --dsw-alias-label-primary-foreground: #2A211C;
  --dsw-alias-label-primary-inverted: #2A211C;
  --dsw-alias-label-tertiary: #A99882;
  --dsw-alias-markdown-citation: #322923;
  --dsw-alias-markdown-code-block: #2A211C;
  --dsw-alias-markdown-code-block-banner: #322923;
  --dsw-alias-markdown-code-segment-selected: #3A302A;
  --dsw-alias-markdown-code-segment-unselected: #2E2622;
  --dsw-alias-markdown-inline-code: #3A302A;
  --dsw-alias-markdown-placeholder: #322923;
  --dsw-alias-markdown-tag: #322923;
  --dsw-alias-scrollbar-bg-l1: rgba(242,232,213,0.12);
  --dsw-alias-scrollbar-bg-l2: rgba(242,232,213,0.12);
  --dsw-alias-scrollbar-hover-l1: rgba(242,232,213,0.28);
  --dsw-alias-scrollbar-hover-l2: rgba(242,232,213,0.28);
  --dsw-alias-state-business-primary: #D46850;
  --dsw-alias-state-business-tertiary: #3A302A;
  --dsw-alias-state-success-secondary: #8FAE7A;
  --dsw-alias-state-success-tertiary: #2E3A28;
  --dsw-alias-state-warn-label: #D9A05B;
  --dsw-alias-state-warn-secondary: #D9A05B;
  --dsw-alias-state-warn-tertiary: #3A3020;
  --dsw-alias-toast-bg: #4A3A30;
  --dsw-alias-tooltip-bg: #3A302A;
  --dsw-specific-bubble: #2E2622;
  --dsw-specific-bubble-highlight: #3A302A;
  --dsw-specific-input-major: #2B2320;
  --dsw-specific-login-input: #322923;
  --dsw-specific-menu: #2B2320;
  --dsw-specific-selector: #322923;
  --dsw-specific-sidebar-nav-item-active: #322923;
  --dsw-specific-sidebar-nav-item-active-accent: #D34B3C;
  --dsw-specific-sidebar-nav-item-hover: #2B2320;
  --dsw-specific-tip: #322923;
  --dsw-font-family: "Noto Serif SC","Source Han Serif SC","Songti SC","STSong","SimSun","PingFang SC","Microsoft YaHei",serif;
  --dsw-shadow-lv1: 0 2px 4px rgba(0,0,0,0.3);
  --dsw-shadow-lv2: 0 4px 12px rgba(0,0,0,0.25), 0 2px 8px rgba(0,0,0,0.35);
  --dsw-shadow-lv3: 0 0 1px rgba(0,0,0,0.5), 0 12px 32px rgba(0,0,0,0.4);
}

/* ===== 场景层 ===== */
.gal-scene { position: fixed; inset: 0; z-index: 0; pointer-events: none; overflow: hidden; }
.gal-veil { position: absolute; inset: 0;
  background:
    linear-gradient(180deg, rgba(110,72,96,0.20) 0%, rgba(110,72,96,0.07) 22%, rgba(110,72,96,0) 44%),
    linear-gradient(0deg, rgba(70,38,26,0.14) 0%, rgba(70,38,26,0.05) 18%, rgba(70,38,26,0) 34%); }
body[data-ds-dark-theme] .gal-veil {
  background:
    linear-gradient(180deg, rgba(84,54,84,0.26) 0%, rgba(84,54,84,0.09) 24%, rgba(84,54,84,0) 46%),
    linear-gradient(0deg, rgba(46,24,16,0.20) 0%, rgba(46,24,16,0.07) 20%, rgba(46,24,16,0) 36%); }

/* 金角边框 */
.gal-frame { position: absolute; inset: 14px; z-index: 1;
  background:
    linear-gradient(#C9A96A,#C9A96A) left top / 30px 1.5px no-repeat,
    linear-gradient(#C9A96A,#C9A96A) left top / 1.5px 30px no-repeat,
    linear-gradient(#C9A96A,#C9A96A) right top / 30px 1.5px no-repeat,
    linear-gradient(#C9A96A,#C9A96A) right top / 1.5px 30px no-repeat,
    linear-gradient(#C9A96A,#C9A96A) left bottom / 30px 1.5px no-repeat,
    linear-gradient(#C9A96A,#C9A96A) left bottom / 1.5px 30px no-repeat,
    linear-gradient(#C9A96A,#C9A96A) right bottom / 30px 1.5px no-repeat,
    linear-gradient(#C9A96A,#C9A96A) right bottom / 1.5px 30px no-repeat;
  opacity: 0.32; }

/* 樱花瓣 */
.gal-petals { position: absolute; inset: 0; z-index: 1; overflow: hidden; }
.gal-petal { position: absolute; top: -6vh; width: 9px; height: 9px; opacity: 0.55;
  border-radius: 50% 0 50% 50%;
  background: linear-gradient(135deg, #F0C3CC, #DD9DB0);
  animation: gal-fall var(--gal-fall-dur, 11s) linear infinite;
  animation-delay: var(--gal-fall-delay, 0s); }
body[data-ds-dark-theme] .gal-petal { opacity: 0.38; }
@keyframes gal-fall {
  0%   { transform: translate3d(0, -6vh, 0) rotate(0deg); }
  100% { transform: translate3d(var(--gal-fall-x, 4vw), 108vh, 0) rotate(680deg); }
}

/* 头部开关按钮 */
.gal-hdr-btn { display: inline-flex; align-items: center; justify-content: center;
  width: 30px; height: 30px; border: none; border-radius: 8px;
  background: transparent; color: var(--dsw-alias-label-secondary);
  cursor: pointer; transition: background-color 0.15s, color 0.15s; }
.gal-hdr-btn:hover { background: var(--dsw-alias-interactive-bg-hover); }
.gal-hdr-btn[data-active="true"] { color: var(--dsw-alias-brand-primary); }
.gal-hdr-btn:focus-visible { outline: 2px solid var(--dsw-alias-border-l4); outline-offset: 1px; }
.gal-hdr-btn svg { width: 16px; height: 16px; }

/* 头部樱花显隐 chip（点击切换，金边=开，无框=关） */
.gal-toggle-chip { display: inline-flex; align-items: center; height: 26px; padding: 0 10px;
  border: 1px solid transparent; border-radius: 8px; background: transparent;
  cursor: pointer; transition: background-color 0.15s, border-color 0.15s, color 0.15s; }
.gal-toggle-chip:hover { background: var(--dsw-alias-interactive-bg-hover); }
.gal-toggle-chip[data-active="true"] { border-color: rgba(201,169,106,0.55); }
.gal-toggle-chip .gal-toggle-label { font-size: 12px; line-height: 18px; color: var(--dsw-alias-label-secondary); white-space: nowrap; }
.gal-toggle-chip[data-active="true"] .gal-toggle-label { color: var(--dsw-alias-brand-primary); }
.gal-toggle-chip:focus-visible { outline: 2px solid var(--dsw-alias-border-l4); outline-offset: 1px; }

/* 桃濑日和配置分区（与 DSH 原生设置页一致：分隔行 + 16px 上下留白 + 36px 胶囊控件） */
.gal-hiyori-section { max-width: 720px; display: flex; flex-direction: column; }
.gal-hiyori-heading { color: var(--dsw-alias-label-primary); margin: 0; padding: 20px 0 4px; font-size: 16px; font-weight: 500; line-height: 24px; }
.gal-hiyori-row { border-bottom: 1px solid var(--dsw-alias-border-l2); display: flex; align-items: center; gap: 8px; padding: 16px 0; }
.gal-hiyori-row:last-child { border-bottom: none; }
.gal-hiyori-rowText { display: flex; flex-direction: column; flex: 1; gap: 4px; min-width: 0; padding-right: 48px; }
.gal-hiyori-title { color: var(--dsw-alias-label-primary); font-size: 14px; font-weight: 400; line-height: 22px; }
.gal-hiyori-hint { color: var(--dsw-alias-label-tertiary); font-size: 12px; line-height: 18px; }
/* 开关（精致版：渐变轨道 + 白色滑块 + 弹性反馈，checked 用品牌 token） */
.gal-skin-switch { position: relative; flex: none; width: 46px; height: 26px; margin: 0; }
.gal-skin-switch input { position: absolute; inset: 0; opacity: 0; margin: 0; cursor: pointer; z-index: 1; }
.gal-skin-switch .gal-skin-track { position: absolute; inset: 0; border-radius: 999px;
  background: var(--dsw-alias-interactive-bg-hover-solid);
  border: 1px solid var(--dsw-alias-border-l2);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.08);
  transition: background-color 0.2s ease, border-color 0.2s ease; }
.gal-skin-switch .gal-skin-thumb { position: absolute; top: 3px; left: 3px; width: 20px; height: 20px;
  border-radius: 50%; background: #FFFFFF;
  box-shadow: 0 1px 3px rgba(0,0,0,0.28), 0 0 1px rgba(0,0,0,0.12);
  transition: transform 0.2s cubic-bezier(0.2, 0.8, 0.3, 1.1), width 0.2s ease, background-color 0.2s ease; }
.gal-skin-switch input:checked + .gal-skin-track {
  background: var(--dsw-alias-button-primary-fill);
  border-color: var(--dsw-alias-button-primary-fill); }
.gal-skin-switch input:checked + .gal-skin-track + .gal-skin-thumb {
  transform: translateX(20px);
  background: #FFF7EA; }
.gal-skin-switch input:active + .gal-skin-track + .gal-skin-thumb { width: 23px; }
.gal-skin-switch input:checked:active + .gal-skin-track + .gal-skin-thumb { width: 23px; transform: translateX(17px); }
.gal-skin-switch input:focus-visible + .gal-skin-track { outline: 2px solid var(--dsw-alias-border-l4); outline-offset: 2px; }

/* API Key 行：输入框 + 保存/清除按钮同一行（按钮不压缩、文字不换行） */
.gal-apikey-controls { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.gal-apikey-input { flex: none; width: 180px; height: 36px; padding: 0 12px;
  border: 1px solid var(--dsw-alias-border-l2); border-radius: 18px;
  background: var(--dsw-specific-input-major); color: var(--dsw-alias-label-primary);
  font: inherit; font-size: 14px; }
.gal-apikey-input:focus-visible { outline: 2px solid var(--dsw-alias-border-l4); outline-offset: 1px; }
.gal-skin-chip { flex: none; white-space: nowrap; height: 36px; padding: 0 14px;
  border: none; border-radius: 18px; font: inherit; font-size: 14px; line-height: 22px; cursor: pointer;
  background: var(--dsw-alias-bg-module-platform); color: var(--dsw-alias-label-primary); }
.gal-skin-chip:hover { background: var(--dsw-alias-interactive-bg-hover); }
.gal-skin-chip:disabled { opacity: 0.5; cursor: default; }
/* 模型选择器（自绘下拉：触发胶囊 + 菜单，与设置页其它下拉一致） */
.gal-hiyori-select { position: relative; display: inline-flex; }
.gal-hiyori-select-trigger { flex: none; display: inline-flex; align-items: center; gap: 12px; height: 36px; padding: 0 14px;
  border: none; border-radius: 18px; background: var(--dsw-alias-bg-module-platform); color: var(--dsw-alias-label-primary);
  font: inherit; font-size: 14px; line-height: 22px; cursor: pointer; }
.gal-hiyori-select-trigger:hover { background: var(--dsw-alias-interactive-bg-hover); }
.gal-hiyori-select-trigger:focus-visible { outline: 2px solid var(--dsw-alias-border-l4); outline-offset: 1px; }
.gal-hiyori-select-value { white-space: nowrap; }
.gal-hiyori-select-chevron { flex: none; width: 14px; height: 14px; color: var(--dsw-alias-label-secondary); }
.gal-hiyori-select-menu { position: absolute; top: calc(100% + 4px); right: 0; z-index: 1000; min-width: 200px;
  max-height: 260px; overflow-y: auto; padding: 4px; border: 1px solid var(--dsw-alias-border-l1);
  border-radius: 12px; background: var(--dsw-specific-menu); box-shadow: var(--dsw-shadow-lv3);
  display: flex; flex-direction: column; }
.gal-hiyori-select-option { text-align: left; padding: 8px 12px; border: none; border-radius: 8px; background: transparent;
  color: var(--dsw-alias-label-primary); font: inherit; font-size: 14px; line-height: 22px; cursor: pointer; white-space: nowrap; }
.gal-hiyori-select-option:hover { background: var(--dsw-alias-interactive-bg-hover); }
.gal-hiyori-select-option-active { background: var(--dsw-alias-interactive-bg-active); color: var(--dsw-alias-brand-primary); }

/* 无障碍：减少动态 */
@media (prefers-reduced-motion: reduce) {
  .gal-petal { animation: none !important; }
}
`

/* ---- 樱花瓣布局（少量、确定性，避免随机跳动） ---- */
const PETALS = [
  { l: '6%', d: '0s', dur: '12s', x: '4vw', s: 8 },
  { l: '18%', d: '-5s', dur: '14s', x: '3vw', s: 7 },
  { l: '32%', d: '-9s', dur: '11s', x: '-3vw', s: 8 },
  { l: '46%', d: '-3s', dur: '15s', x: '4vw', s: 6 },
  { l: '58%', d: '-11s', dur: '12s', x: '-4vw', s: 8 },
  { l: '70%', d: '-7s', dur: '13.5s', x: '3vw', s: 7 },
  { l: '82%', d: '-2s', dur: '11.5s', x: '4vw', s: 8 },
  { l: '92%', d: '-13s', dur: '14.5s', x: '-3vw', s: 6 },
]

/* ---- 组件 ---- */

function useStore() {
  const [state, setState] = React.useState(store.get())
  React.useEffect(() => store.sub((s) => setState(s)), [])
  return state
}

/** 全屏场景：帷幔 + 樱花 + 金角边框（点击穿透） */
function SceneLayer() {
  const state = useStore()
  const on = state.bg
  const petals = state.sakura
  const children = [
    React.createElement('div', { key: 'veil', className: 'gal-veil' }),
  ]
  if (petals) {
    children.push(React.createElement('div', { key: 'petals', className: 'gal-petals', 'aria-hidden': 'true' },
      PETALS.map((p, i) => React.createElement('span', {
        key: i,
        className: 'gal-petal',
        style: {
          left: p.l,
          width: p.s,
          height: p.s,
          animationDuration: p.dur,
          animationDelay: p.d,
          ['--gal-fall-x']: p.x,
        },
      })),
    ))
  }
  children.push(React.createElement('div', { key: 'frame', className: 'gal-frame' }))
  return React.createElement('div', {
    className: 'gal-scene',
    'data-gal-state': on ? 'on' : 'off',
  }, ...children)
}

/** 头部显隐 chip（点击切换；边框/文字颜色指示状态） */
function ToggleChip({ label, active, title, onChange }) {
  return React.createElement('button', {
    className: 'gal-toggle-chip',
    type: 'button',
    'data-active': active ? 'true' : 'false',
    'aria-pressed': active ? 'true' : 'false',
    title,
    onClick: () => onChange(!active),
  }, React.createElement('span', { className: 'gal-toggle-label' }, label))
}

/** 头部樱花开关（文本 + 开关） */
function SakuraToggleHeader() {
  const state = useStore()
  const active = state.sakura
  return React.createElement(ToggleChip, {
    label: '樱花',
    active,
    title: active ? '关闭樱花' : '开启樱花',
    onChange: (v) => store.set({ sakura: v }),
  })
}

/** 设置页背景颜色开关 */
function BackgroundRow() {
  const state = useStore()
  return React.createElement('div', { className: 'gal-hiyori-row' },
    React.createElement('div', { className: 'gal-hiyori-rowText' },
      React.createElement('span', { className: 'gal-hiyori-title' }, '背景颜色'),
      React.createElement('span', { className: 'gal-hiyori-hint' }, '暖色背景；关闭后还原默认背景色'),
    ),
    React.createElement('label', { className: 'gal-skin-switch' },
      React.createElement('input', {
        type: 'checkbox',
        checked: state.bg,
        onChange: (e) => store.set({ bg: e.target.checked }),
      }),
      React.createElement('span', { className: 'gal-skin-track' }),
      React.createElement('span', { className: 'gal-skin-thumb' }),
    ),
  )
}

const updateCharacterStatus = (characterStatus) => store.set({ characterStatus })

function refreshChatConfig() {
  fetch(CHAT_CONFIG_PATH)
    .then((response) => (response.ok ? response.json() : { configured: false, masked: '' }))
    .then((config) => store.set({
      chatConfigured: config?.configured === true,
      chatMasked: typeof config?.masked === 'string' ? config.masked : '',
    }))
    .catch(() => store.set({ chatConfigured: false, chatMasked: '' }))
  fetch(MODELS_PATH)
    .then((response) => (response.ok ? response.json() : { models: [] }))
    .then((data) => {
      const models = Array.isArray(data?.models) && data.models.length > 0 ? data.models : DEFAULT_MODELS.slice()
      store.set({ chatModels: models })
    })
    .catch(() => store.set({ chatModels: DEFAULT_MODELS.slice() }))
}

/** 设置页虚拟角色开关与本地资源状态。 */
function CharacterRow() {
  const state = useStore()
  const hint = state.characterStatus === 'missing'
    ? '桃濑日和资源校验失败；请重新拉取仓库后运行 npm run setup:live2d'
    : state.characterStatus === 'error'
      ? '桃濑日和加载失败；界面皮肤仍可使用'
      : state.characterStatus === 'checking'
        ? '正在检查本地桃濑日和资源…'
        : '右下角桃濑日和；只读取时间、页面、状态和鼠标交互'

  return React.createElement('div', { className: 'gal-hiyori-row' },
    React.createElement('div', { className: 'gal-hiyori-rowText' },
      React.createElement('span', { className: 'gal-hiyori-title' }, '虚拟角色'),
      React.createElement('span', { className: 'gal-hiyori-hint' }, hint),
    ),
    React.createElement('label', { className: 'gal-skin-switch' },
      React.createElement('input', {
        type: 'checkbox',
        checked: state.character,
        onChange: (event) => store.set({ character: event.target.checked }),
      }),
      React.createElement('span', { className: 'gal-skin-track' }),
      React.createElement('span', { className: 'gal-skin-thumb' }),
    ),
  )
}

/** 设置页性格选择器。 */
function PersonalityRow() {
  const state = useStore()
  return React.createElement('div', { className: 'gal-hiyori-row' },
    React.createElement('div', { className: 'gal-hiyori-rowText' },
      React.createElement('span', { className: 'gal-hiyori-title' }, '性格'),
      React.createElement('span', { className: 'gal-hiyori-hint' }, '桃濑日和的口吻；切换后立刻生效'),
    ),
    React.createElement('div', { className: 'gal-personality-chips', role: 'radiogroup', 'aria-label': '性格' },
      PERSONALITIES.map((personality) => React.createElement('button', {
        key: personality.id,
        type: 'button',
        role: 'radio',
        'aria-checked': state.personality === personality.id ? 'true' : 'false',
        className: 'gal-personality-chip',
        'data-active': state.personality === personality.id ? 'true' : 'false',
        title: `切换到${personality.label}性格`,
        onClick: () => {
          savePersonalityPreference(window.localStorage, personality.id)
          store.set({ personality: personality.id })
        },
      }, personality.label)),
    ),
  )
}

function ApiKeyRow() {
  const state = useStore()
  const [value, setValue] = React.useState('')
  const [busy, setBusy] = React.useState(false)
  const [error, setError] = React.useState('')

  const locked = state.chatConfigured

  const save = async () => {
    setBusy(true)
    setError('')
    try {
      const response = await fetch(CHAT_CONFIG_PATH, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ apiKey: value }),
      })
      if (!response.ok) {
        setError('保存失败：后端未就绪，请重启 dsh web 后重试')
        return
      }
      setValue('')
      refreshChatConfig()
    } finally {
      setBusy(false)
    }
  }

  const clear = async () => {
    setBusy(true)
    setError('')
    try {
      const response = await fetch(CHAT_CONFIG_PATH, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ apiKey: '' }),
      })
      if (!response.ok) {
        setError('清除失败：后端未就绪，请重启 dsh web 后重试')
        return
      }
      refreshChatConfig()
    } finally {
      setBusy(false)
    }
  }

  return React.createElement('div', { className: 'gal-hiyori-row' },
    React.createElement('div', { className: 'gal-hiyori-rowText' },
      React.createElement('span', { className: 'gal-hiyori-title' }, 'DeepSeek API Key'),
      React.createElement('span', { className: 'gal-hiyori-hint' },
        error || (state.chatConfigured ? '已配置；台词由 DeepSeek 生成' : '配置后日和的性格更加鲜明')),
    ),
    React.createElement('div', { className: 'gal-apikey-controls' },
      React.createElement('input', {
        type: state.chatConfigured ? 'text' : 'password',
        className: 'gal-apikey-input',
        placeholder: 'sk-…',
        value: state.chatConfigured ? (state.chatMasked || '') : value,
        disabled: busy || locked,
        onChange: (event) => setValue(event.target.value),
      }),
      React.createElement('button', {
        type: 'button',
        className: 'gal-skin-chip',
        disabled: busy || value.trim() === '',
        onClick: save,
      }, '保存'),
      state.chatConfigured
        ? React.createElement('button', { type: 'button', className: 'gal-skin-chip', disabled: busy, onClick: clear }, '清除')
        : null,
    ),
  )
}

function ModelRow() {
  const state = useStore()
  const models = state.chatModels.length > 0 ? state.chatModels : DEFAULT_MODELS
  const [open, setOpen] = React.useState(false)
  const wrapRef = React.useRef(null)

  React.useEffect(() => {
    if (!open) return undefined
    const onPointerDown = (event) => {
      if (wrapRef.current && !wrapRef.current.contains(event.target)) setOpen(false)
    }
    const onKeyDown = (event) => {
      if (event.key === 'Escape') setOpen(false)
    }
    document.addEventListener('pointerdown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open])

  const choose = (id) => {
    saveModelPreference(window.localStorage, id)
    store.set({ model: id })
    setOpen(false)
  }

  return React.createElement('div', { className: 'gal-hiyori-row' },
    React.createElement('div', { className: 'gal-hiyori-rowText' },
      React.createElement('span', { className: 'gal-hiyori-title' }, '模型'),
      React.createElement('span', { className: 'gal-hiyori-hint' }, '台词由所选 DeepSeek 模型生成'),
    ),
    React.createElement('div', { className: 'gal-hiyori-select', ref: wrapRef },
      React.createElement('button', {
        type: 'button',
        className: 'gal-hiyori-select-trigger',
        'aria-haspopup': 'listbox',
        'aria-expanded': open ? 'true' : 'false',
        onClick: () => setOpen(!open),
      },
        React.createElement('span', { className: 'gal-hiyori-select-value' }, state.model),
        React.createElement('svg', {
          className: 'gal-hiyori-select-chevron',
          viewBox: '0 0 16 16',
          fill: 'none',
          'aria-hidden': 'true',
        },
        React.createElement('path', {
          d: 'M4 6l4 4 4-4',
          stroke: 'currentColor',
          strokeWidth: 1.5,
          strokeLinecap: 'round',
          strokeLinejoin: 'round',
        })),
      ),
      open ? React.createElement('div', { className: 'gal-hiyori-select-menu', role: 'listbox' },
        models.map((id) => React.createElement('button', {
          key: id,
          type: 'button',
          role: 'option',
          'aria-selected': id === state.model ? 'true' : 'false',
          className: 'gal-hiyori-select-option' + (id === state.model ? ' gal-hiyori-select-option-active' : ''),
          onClick: () => choose(id),
        }, id)),
      ) : null,
    ),
  )
}

/** 桃濑日和配置分区：汇总所有角色相关设置。 */
function HiyoriSection() {
  return React.createElement('div', { className: 'gal-hiyori-section' },
    React.createElement('h2', { className: 'gal-hiyori-heading' }, '桃濑日和配置'),
    React.createElement(BackgroundRow),
    React.createElement(CharacterRow),
    React.createElement(PersonalityRow),
    React.createElement(ApiKeyRow),
    React.createElement(ModelRow),
  )
}

/* ---- 插件入口 ---- */
async function apply(ctx) {
  store.set({
    personality: loadPersonalityPreference(window.localStorage),
    model: loadModelPreference(window.localStorage),
  })

  const llmProvider = createLlmProvider({ fetchImpl: window.fetch.bind(window) })
  refreshChatConfig()

  /* 1) 官方主题 token（亮/暗双套）。
     装饰 token（DECOR_TOKENS）始终开启；背景色 token（BG_TOKENS）随「背景颜色」开关叠加/移除。
     theme 硬注入：常驻包在 apply 时不一定先有 theme，若用 ctx.get 软读会被跳过，
     导致背景等主 token 不生效（参考 dsh-client-ui-layout 的 inject: ["slots","theme"]）。 */
  const theme = ctx.theme
  let bgDisposer = null
  let decorDisposer = null
  const applyBg = (on) => {
    if (on) {
      if (bgDisposer === null) bgDisposer = theme.overrideTokens('sakura-vn-bg', BG_TOKENS)
    } else if (bgDisposer !== null) {
      bgDisposer()
      bgDisposer = null
    }
  }
  decorDisposer = theme.overrideTokens('sakura-vn-decor', DECOR_TOKENS)
  applyBg(true)
  ctx.effect(() => () => {
    if (bgDisposer !== null) bgDisposer()
    if (decorDisposer !== null) decorDisposer()
  })
  const unsubscribe = store.sub((s) => applyBg(s.bg))
  ctx.effect(() => unsubscribe)

  /* 2) 皮肤 CSS */
  ctx.effect(() => insertStyle(SKIN_CSS))
  ctx.effect(() => insertStyle(CHARACTER_CSS))

  /* 2.5) 常驻角色 iframe 容器：挂在 body 下、由插件生命周期管理。
     切换会话时 DSH shell 会重挂载 overlay 的 React 树，若 iframe 是树内子节点就会被
     销毁重建、Live2D 模型重新初始化（可见闪烁）；挂在 body 下则模型常驻、无闪烁。 */
  const frameHost = document.createElement('div')
  frameHost.className = 'gal-character-frame-host'
  document.body.append(frameHost)
  ctx.effect(() => () => {
    frameHost.remove()
  })

  /* 3) 插槽注入 */
  const slots = ctx.slots

  function CharacterOverlay(props) {
    const state = useStore()
    const currentSessionId = props.useSessions((snapshot) => snapshot.current)
    return React.createElement(CharacterLayer, {
      enabled: state.character,
      personality: state.personality,
      llmSay: state.chatConfigured ? llmProvider.say : null,
      model: state.model,
      timer: ctx.timer,
      sessions: ctx.sessions,
      currentSessionId,
      frameHost,
      onStatus: updateCharacterStatus,
    })
  }

  slots.inject('shell.overlay', () => slots.register(
    { name: 'shell.overlay', id: 'sakura-vn-scene', order: -100 },
    () => React.createElement(SceneLayer),
  ))
  slots.inject('shell.overlay', () => slots.register(
    { name: 'shell.overlay', id: 'sakura-vn-character', order: 100 },
    CharacterOverlay,
  ))
  slots.inject('conversation.session.header.actions', () => slots.register(
    { name: 'conversation.session.header.actions', id: 'gal-sakura', order: 30, label: '樱花' },
    () => React.createElement(SakuraToggleHeader),
  ))
  slots.inject('settings.section', () => slots.register(
    { name: 'settings.section', id: 'hiyori-config', order: 25, label: '桃濑日和配置' },
    () => React.createElement(HiyoriSection),
  ))
}

export const name = 'dsh-hiyori-web-ui'
export const inject = ['slots', 'sessions', 'timer', 'theme']
export { apply }
