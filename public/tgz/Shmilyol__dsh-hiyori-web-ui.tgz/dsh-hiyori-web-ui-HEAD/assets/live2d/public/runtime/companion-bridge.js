const PARENT_SOURCE = 'sakura-vn-parent'
const GAZE_GAIN_X = 1.75
const GAZE_GAIN_Y = 2
const GAZE_IDLE_MS = 5000
let failed = false
let gazeActive = false
let gazeIdleTimer = null
let gazeCanvas = null
const capturedCanvases = new WeakSet()

function amplifyGaze(value, gain) {
  return Math.max(-1, Math.min(1, (Number(value) || 0) * gain))
}

function setGazeActive(active) {
  if (gazeActive === active) return
  gazeActive = active
  window.dispatchEvent(new CustomEvent('sakura-gaze-active', {
    detail: active,
  }))
}

function stopGaze() {
  if (gazeIdleTimer !== null) {
    window.clearTimeout(gazeIdleTimer)
    gazeIdleTimer = null
  }
  if (gazeCanvas !== null) {
    gazeCanvas.dispatchEvent(new PointerEvent('pointercancel', {
      bubbles: true,
    }))
    capturedCanvases.delete(gazeCanvas)
    gazeCanvas = null
  }
  setGazeActive(false)
}

function armGazeIdle(canvas) {
  if (gazeIdleTimer !== null) window.clearTimeout(gazeIdleTimer)
  gazeCanvas = canvas
  setGazeActive(true)
  gazeIdleTimer = window.setTimeout(stopGaze, GAZE_IDLE_MS)
}

function send(type, detail = {}) {
  // 不透明 iframe 的自身 origin 是 "null"，不能作为 targetOrigin（父页面不是不透明源），
  // 必须用 '*' 才能把 ready/hit/error 送达父页面。
  window.parent.postMessage(
    { source: 'sakura-vn-runtime', type, ...detail },
    '*',
  )
}

window.__sakuraCompanion = Object.freeze({ send })

window.addEventListener('message', (event) => {
  // 运行时 iframe 由 sandbox="allow-scripts"（无 allow-same-origin）创建，是不透明源，
  // window.location.origin 恒为 "null"；父页面消息的 origin 是真实源。因此只能靠
  // event.source 识别父页面，不能与自身 "null" origin 比较（否则父页面命令会被全部丢弃）。
  if (event.source !== window.parent) {
    return
  }
  const message = event.data
  if (message?.source !== PARENT_SOURCE) {
    return
  }

  const canvas = document.querySelector('canvas')
  if (message.type === 'pointer' && canvas) {
    const rect = canvas.getBoundingClientRect()
    const gazeX = amplifyGaze(message.x, GAZE_GAIN_X)
    const gazeY = amplifyGaze(message.y, GAZE_GAIN_Y)
    const clientX = rect.left + ((gazeX + 1) / 2) * rect.width
    const clientY = rect.top + ((1 - gazeY) / 2) * rect.height
    armGazeIdle(canvas)
    const wasCaptured = capturedCanvases.has(canvas)
    if (!wasCaptured) {
      canvas.dispatchEvent(new PointerEvent('pointerdown', {
        clientX,
        clientY,
        bubbles: true,
      }))
      capturedCanvases.add(canvas)
    }
    const movePointer = () => canvas.dispatchEvent(
      new PointerEvent('pointermove', { clientX, clientY, bubbles: true }),
    )
    movePointer()
    // Cubism 5-r.5 applies the saved touch before recording the latest move.
    if (wasCaptured) movePointer()
  } else if (message.type === 'motion') {
    window.dispatchEvent(new CustomEvent('sakura-motion', {
      detail: message.id,
    }))
  } else if (message.type === 'expression') {
    window.dispatchEvent(new CustomEvent('sakura-expression', {
      detail: message.id,
    }))
  } else if (message.type === 'destroy') {
    stopGaze()
    window.dispatchEvent(new Event('beforeunload'))
  }
})

function reportFailure(code) {
  if (failed) {
    return
  }
  failed = true
  send('error', { code })
}

window.addEventListener('error', () => reportFailure('runtime-error'))
window.addEventListener('unhandledrejection', () => reportFailure('runtime-rejection'))
