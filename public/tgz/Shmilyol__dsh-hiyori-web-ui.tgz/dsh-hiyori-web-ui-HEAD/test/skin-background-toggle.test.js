import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

test('settings show a background-color switch instead of a skin master switch', async () => {
  const template = await readFile('tools/client-template.js', 'utf8')
  assert.match(template, /'背景颜色'/)
  assert.match(template, /暖色背景；关闭后还原默认背景色/)
  assert.doesNotMatch(template, /'DSH 伴侣'/)
  assert.doesNotMatch(template, /皮肤总开关/)
  assert.match(template, /state\.bg/)
  assert.doesNotMatch(template, /state\.skin/)
  // 樱花开关不再依赖背景/皮肤开关
  assert.match(template, /const active = state\.sakura/)
})

test('background tokens stay gated while decoration tokens are always-on', async () => {
  const template = await readFile('tools/client-template.js', 'utf8')
  // 两组官方 token 分离
  assert.match(template, /const BG_TOKENS = \{/)
  assert.match(template, /const DECOR_TOKENS = \{/)
  // 用不同 namespace 叠加，避免互相覆盖
  assert.match(template, /sakura-vn-bg/)
  assert.match(template, /sakura-vn-decor/)
  // 背景色 token 仍由 :has() 门控（bg-layer-3 在 gated body 内）
  assert.match(template, /body:has\(\.gal-scene\[data-gal-state="on"\]\)\s*\{[\s\S]*?--dsw-alias-bg-layer-3/)
  // 装饰 token 移出门控，落在无条件 body 块内
  assert.match(template, /body\s*\{\s*--dsw-alias-border-inverted/)
  assert.match(template, /body\[data-ds-dark-theme\]\s*\{\s*--dsw-alias-border-inverted/)
})
