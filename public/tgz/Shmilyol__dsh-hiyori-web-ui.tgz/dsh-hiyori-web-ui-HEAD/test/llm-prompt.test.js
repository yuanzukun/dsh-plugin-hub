import assert from 'node:assert/strict'
import test from 'node:test'
import { buildLlmMessages } from '../src/client/llm-prompt.js'

test('builds system + user messages with persona and event', () => {
  const messages = buildLlmMessages({ personality: 'tsundere', event: 'complete', vars: {} })
  assert.equal(messages.length, 2)
  assert.equal(messages[0].role, 'system')
  assert.equal(messages[1].role, 'user')
  assert.match(messages[0].content, /桃濑日和/)
  assert.match(messages[0].content, /傲娇/)
  assert.match(messages[1].content, /任务刚刚完成/)
})

test('renders vars into the user hint', () => {
  const messages = buildLlmMessages({ personality: 'gentle', event: 'streak', vars: { n: 5 } })
  assert.match(messages[1].content, /5/)
})

test('falls back to gentle for an unknown personality', () => {
  const messages = buildLlmMessages({ personality: 'robot', event: 'complete', vars: {} })
  assert.match(messages[0].content, /温柔/)
})

test('unknown events still get a generic instruction', () => {
  const messages = buildLlmMessages({ personality: 'genki', event: 'mystery', vars: {} })
  assert.match(messages[1].content, /mystery/)
})

test('system carries the personality profile and hard rules', () => {
  const messages = buildLlmMessages({ personality: 'tsundere', event: 'complete', vars: {} })
  const system = messages[0].content
  assert.match(system, /傲娇/)
  assert.match(system, /口是心非/)
  assert.match(system, /不超过 30 个字/)
  assert.match(system, /不要照抄示例/)
})

test('system does not disclose other personalities (progressive disclosure)', () => {
  const messages = buildLlmMessages({ personality: 'lazy', event: 'complete', vars: {} })
  assert.doesNotMatch(messages[0].content, /元气满满/)
  assert.doesNotMatch(messages[0].content, /口是心非/)
})

test('user carries event summary, angles and an example line', () => {
  const messages = buildLlmMessages({ personality: 'gentle', event: 'complete', vars: {} })
  const user = messages[1].content
  assert.match(user, /任务刚刚完成/)
  assert.match(user, /可选语气角度/)
  assert.match(user, /邀功得意/)
  assert.match(user, /口吻参考/)
})

test('recent lines are disclosed when provided', () => {
  const messages = buildLlmMessages({ personality: 'gentle', event: 'complete', vars: {}, recent: ['上一条台词'] })
  assert.match(messages[1].content, /最近说过/)
  assert.match(messages[1].content, /上一条台词/)
})

test('longrun elapsed is rendered in minutes', () => {
  const messages = buildLlmMessages({ personality: 'gentle', event: 'longrun', vars: { elapsed: 120000 } })
  assert.match(messages[1].content, /2 分钟/)
  assert.doesNotMatch(messages[1].content, /120000/)
})
