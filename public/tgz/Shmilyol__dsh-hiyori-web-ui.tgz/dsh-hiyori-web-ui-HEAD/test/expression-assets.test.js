import assert from 'node:assert/strict'
import { readFile, readdir } from 'node:fs/promises'
import test from 'node:test'

const EXPRESSIONS = ['joy', 'sad', 'angry', 'proud', 'shy', 'sleepy', 'relief', 'surprise']

test('model3.json references exactly the eight expressions', async () => {
  const model = JSON.parse(await readFile('assets/live2d/public/Resources/Hiyori/Hiyori.model3.json', 'utf8'))
  assert.deepEqual(model.FileReferences.Expressions.map((entry) => entry.Name), EXPRESSIONS)
})

test('every expression file is a valid Live2D expression with parameters', async () => {
  const dir = 'assets/live2d/public/Resources/Hiyori/expressions'
  const files = await readdir(dir)
  for (const id of EXPRESSIONS) {
    assert.ok(files.includes(`hiyori_${id}.exp3.json`), id)
    const parsed = JSON.parse(await readFile(`${dir}/hiyori_${id}.exp3.json`, 'utf8'))
    assert.equal(parsed.Type, 'Live2D Expression')
    assert.ok(Array.isArray(parsed.Parameters) && parsed.Parameters.length > 0, id)
    for (const p of parsed.Parameters) {
      assert.equal(typeof p.Id, 'string')
      assert.equal(typeof p.Value, 'number')
    }
  }
})

test('sleepy expression overwrites eyes to a half-closed value', async () => {
  const sleepy = JSON.parse(await readFile(
    'assets/live2d/public/Resources/Hiyori/expressions/hiyori_sleepy.exp3.json',
    'utf8',
  ))
  const eyeOpen = sleepy.Parameters.filter(
    (p) => p.Id === 'ParamEyeLOpen' || p.Id === 'ParamEyeROpen',
  )
  assert.equal(eyeOpen.length, 2)
  for (const p of eyeOpen) {
    // 眼部参数 0=闭眼、1=睁眼；"眯一半"用绝对值 0.5，且必须 Overwrite（默认 Additive 会把 0.5 当偏移，
    // 反而把眼睛加得更开，而不是半闭）。
    assert.equal(p.Blend, 'Overwrite', `${p.Id} 应使用 Overwrite，实际 Blend=${p.Blend}`)
    assert.ok(p.Value > 0 && p.Value < 1, `${p.Id} 应为半眯（0<Value<1），实际 ${p.Value}`)
  }
})
