import assert from 'node:assert/strict'
import test from 'node:test'
import { createChatHandlers, maskKey } from '../src/host/chat-route.js'

function responseRecorder() {
  return {
    status: 0, headers: {}, body: undefined,
    writeHead(status, headers = {}) { this.status = status; this.headers = headers },
    end(body) { this.body = body },
  }
}

function request(method, payload) {
  return {
    method,
    async *[Symbol.asyncIterator]() {
      if (payload !== undefined) yield Buffer.from(JSON.stringify(payload))
    },
  }
}

function parse(res) {
  return JSON.parse(res.body.toString('utf8'))
}

const credentials = {
  async describe() { return { configured: true, writable: true } },
  async resolve() { return { value: 'sk-abcdef123456', source: 'file' } },
  async set() {},
  async unset() {},
}

test('say rejects non-POST with 405', async () => {
  const handlers = createChatHandlers({ deepseek: {}, credentials })
  const res = responseRecorder()
  await handlers.say(request('GET'), res)
  assert.equal(res.status, 405)
  assert.equal(res.headers.allow, 'POST')
})

test('say returns the generated text', async () => {
  const deepseek = { async complete({ model, messages }) { return `[${model}]${messages[0].content}` } }
  const handlers = createChatHandlers({ deepseek, credentials })
  const res = responseRecorder()
  await handlers.say(request('POST', { model: 'deepseek-v4-flash', messages: [{ role: 'user', content: 'hi' }] }), res)
  assert.equal(res.status, 200)
  assert.equal(parse(res).ok, true)
  assert.equal(parse(res).text, '[deepseek-v4-flash]hi')
})

test('say returns missing_key when the client has no key', async () => {
  const deepseek = { async complete() { throw Object.assign(new Error('x'), { code: 'MISSING_KEY' }) } }
  const handlers = createChatHandlers({ deepseek, credentials })
  const res = responseRecorder()
  await handlers.say(request('POST', { model: 'deepseek-v4-flash', messages: [{ role: 'user', content: 'hi' }] }), res)
  assert.equal(res.status, 200)
  assert.deepEqual(parse(res), { ok: false, code: 'missing_key' })
})

test('say returns 502 on an upstream error', async () => {
  const deepseek = { async complete() { throw new Error('boom') } }
  const handlers = createChatHandlers({ deepseek, credentials })
  const res = responseRecorder()
  await handlers.say(request('POST', { model: 'x', messages: [{ role: 'user', content: 'hi' }] }), res)
  assert.equal(res.status, 502)
  assert.deepEqual(parse(res), { ok: false, code: 'upstream_error' })
})

test('say returns 400 when messages are missing', async () => {
  const handlers = createChatHandlers({ deepseek: {}, credentials })
  const res = responseRecorder()
  await handlers.say(request('POST', { model: 'deepseek-v4-flash' }), res)
  assert.equal(res.status, 400)
})

test('say defaults an invalid model name', async () => {
  let seen
  const deepseek = { async complete(args) { seen = args.model } }
  const handlers = createChatHandlers({ deepseek, credentials })
  const res = responseRecorder()
  await handlers.say(request('POST', { model: 42, messages: [{ role: 'user', content: 'hi' }] }), res)
  assert.equal(seen, 'deepseek-v4-flash')
})

test('models returns the live list', async () => {
  const deepseek = { async listModels() { return ['deepseek-v4-flash', 'deepseek-v4-pro'] } }
  const handlers = createChatHandlers({ deepseek, credentials })
  const res = responseRecorder()
  await handlers.models(request('GET'), res)
  assert.deepEqual(parse(res), { models: ['deepseek-v4-flash', 'deepseek-v4-pro'] })
})

test('chatConfig GET reports configured state with a masked key', async () => {
  const handlers = createChatHandlers({ deepseek: {}, credentials })
  const res = responseRecorder()
  await handlers.chatConfig(request('GET'), res)
  assert.equal(res.status, 200)
  assert.deepEqual(parse(res), { configured: true, masked: 'sk-abcd****3456' })
})

test('maskKey masks the middle and collapses short or absent keys', () => {
  assert.equal(maskKey('sk-abcdef123456'), 'sk-abcd****3456')
  assert.equal(maskKey('short'), '****')
  assert.equal(maskKey(''), '')
  assert.equal(maskKey(undefined), '')
})

test('chatConfig POST stores a trimmed key and reports configured', async () => {
  let setValue
  const creds = {
    async describe() { return { configured: true } },
    async set(ref, value) { setValue = value },
    async unset() {},
  }
  const handlers = createChatHandlers({ deepseek: {}, credentials: creds })
  const res = responseRecorder()
  await handlers.chatConfig(request('POST', { apiKey: '  sk-abc  ' }), res)
  assert.equal(setValue, 'sk-abc')
  assert.deepEqual(parse(res), { ok: true, configured: true })
})

test('chatConfig POST with empty key unsets', async () => {
  let unsetCalled = false
  const creds = {
    async describe() { return { configured: false } },
    async set() {},
    async unset() { unsetCalled = true },
  }
  const handlers = createChatHandlers({ deepseek: {}, credentials: creds })
  const res = responseRecorder()
  await handlers.chatConfig(request('POST', { apiKey: '   ' }), res)
  assert.equal(unsetCalled, true)
  assert.deepEqual(parse(res), { ok: true, configured: false })
})

test('chatConfig POST returns 409 when the credential is not writable', async () => {
  const creds = {
    async describe() { return { configured: true } },
    async set() { throw new Error('read-only shadow') },
    async unset() {},
  }
  const handlers = createChatHandlers({ deepseek: {}, credentials: creds })
  const res = responseRecorder()
  await handlers.chatConfig(request('POST', { apiKey: 'sk-x' }), res)
  assert.equal(res.status, 409)
  assert.deepEqual(parse(res), { ok: false, code: 'not_writable' })
})

test('say returns 400 on a null JSON body', async () => {
  const handlers = createChatHandlers({ deepseek: {}, credentials })
  const res = responseRecorder()
  await handlers.say(request('POST', null), res)
  assert.equal(res.status, 400)
})

test('chatConfig POST returns 400 on a null JSON body', async () => {
  const handlers = createChatHandlers({ deepseek: {}, credentials })
  const res = responseRecorder()
  await handlers.chatConfig(request('POST', null), res)
  assert.equal(res.status, 400)
})
