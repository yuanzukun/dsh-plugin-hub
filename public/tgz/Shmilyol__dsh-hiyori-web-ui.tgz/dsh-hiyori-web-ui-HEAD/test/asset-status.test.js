import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import test from 'node:test'
import { inspectAssetStatus } from '../src/host/asset-status.js'

const hash = createHash('sha256').update('data').digest('hex')

const manifest = {
  sdkVersion: '5-r.5',
  model: 'Hiyori',
  files: {
    'runtime/index.html': { path: '/install/index.html', size: 4, sha256: hash },
    'runtime/Core/live2dcubismcore.js': { path: '/install/core.js', size: 4, sha256: hash },
    'Resources/Hiyori/Hiyori.model3.json': {
      path: '/install/Hiyori.model3.json', size: 4, sha256: hash,
    },
    'Resources/Hiyori/hiyori_pro_t11.2048/texture_00.png': {
      path: '/install/texture_00.png', size: 4, sha256: hash,
    },
    'Resources/Hiyori/hiyori_pro_t11.2048/texture_01.png': {
      path: '/install/texture_01.png', size: 4, sha256: hash,
    },
  },
}

function fileSystem({ missing = null, wrongSize = null } = {}) {
  return {
    async resolve(path) {
      if (path === missing) throw new Error('missing')
      return path
    },
    async readBytes(path) {
      return new TextEncoder().encode(path === wrongSize ? 'bad' : 'data')
    },
  }
}

test('reports ready only after hashing runtime, Core, Hiyori model and both textures', async () => {
  assert.deepEqual(await inspectAssetStatus(fileSystem(), manifest), {
    ready: true,
    basePath: '/__sakura_live2d',
    sdkVersion: '5-r.5',
    model: 'Hiyori',
  })
})

test('hashes required assets when the Host sandbox has no Web Crypto global', async () => {
  const descriptor = Object.getOwnPropertyDescriptor(globalThis, 'crypto')
  Object.defineProperty(globalThis, 'crypto', {
    configurable: true,
    value: undefined,
  })
  try {
    assert.deepEqual(await inspectAssetStatus(fileSystem(), manifest), {
      ready: true,
      basePath: '/__sakura_live2d',
      sdkVersion: '5-r.5',
      model: 'Hiyori',
    })
  } finally {
    if (descriptor) {
      Object.defineProperty(globalThis, 'crypto', descriptor)
    } else {
      delete globalThis.crypto
    }
  }
})

test('reports missing without exposing file details when a required asset is unavailable', async () => {
  const status = await inspectAssetStatus(
    fileSystem({ missing: '/install/core.js' }),
    manifest,
  )
  assert.deepEqual(status, { ready: false })
})

test('reports missing when a required file no longer matches manifest size', async () => {
  const status = await inspectAssetStatus(
    fileSystem({ wrongSize: '/install/Hiyori.model3.json' }),
    manifest,
  )
  assert.deepEqual(status, { ready: false })
})

test('reports missing when bytes match size but not the manifest hash', async () => {
  const altered = structuredClone(manifest)
  altered.files['runtime/index.html'].sha256 = '0'.repeat(64)
  assert.deepEqual(await inspectAssetStatus(fileSystem(), altered), { ready: false })
})

test('reports missing when the manifest does not identify Hiyori on SDK 5-r.5', async () => {
  const altered = structuredClone(manifest)
  altered.model = 'Other'
  assert.deepEqual(await inspectAssetStatus(fileSystem(), altered), { ready: false })
})
