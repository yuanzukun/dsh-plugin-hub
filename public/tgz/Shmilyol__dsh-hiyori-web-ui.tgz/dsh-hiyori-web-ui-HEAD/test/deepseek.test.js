import assert from 'node:assert/strict'
import test from 'node:test'
import { createDeepSeekClient } from '../src/host/deepseek.js'

function jsonResponse(ok, status, body) {
  return { ok, status, json: async () => body }
}

function credentialsWith(key) {
  return { async resolve() { return key ? { value: key, source: 'file' } : undefined } }
}

const MESSAGES = [
  { role: 'system', content: '你是桃濑日和。' },
  { role: 'user', content: '任务刚完成。' },
]

test('complete posts a bearer-authenticated non-streaming request', async () => {
  let captured
  const fetchImpl = async (url, options) => {
    captured = { url, options }
    return jsonResponse(true, 200, { choices: [{ message: { content: ' 完成啦 ' } }] })
  }
  const client = createDeepSeekClient({ credentials: credentialsWith('sk-test'), fetchImpl })
  const text = await client.complete({ model: 'deepseek-v4-flash', messages: MESSAGES })
  assert.equal(text, '完成啦')
  assert.equal(captured.url, 'https://api.deepseek.com/chat/completions')
  assert.equal(captured.options.headers.authorization, 'Bearer sk-test')
  const body = JSON.parse(captured.options.body)
  assert.equal(body.model, 'deepseek-v4-flash')
  assert.equal(body.stream, false)
  assert.equal(body.max_tokens, 64)
  assert.deepEqual(body.messages, MESSAGES)
  assert.equal(body.temperature, 0.9)
})

test('omits temperature for thinking models', async () => {
  let captured
  const fetchImpl = async (url, options) => {
    captured = options
    return jsonResponse(true, 200, { choices: [{ message: { content: 'x' } }] })
  }
  const client = createDeepSeekClient({ credentials: credentialsWith('sk'), fetchImpl })
  await client.complete({ model: 'deepseek-v4-pro', messages: MESSAGES })
  assert.equal(JSON.parse(captured.body).temperature, undefined)
})

test('ignores reasoning_content and uses the final content', async () => {
  const fetchImpl = async () => jsonResponse(true, 200, {
    choices: [{ message: { reasoning_content: '思考过程', content: '最终台词' } }],
  })
  const client = createDeepSeekClient({ credentials: credentialsWith('sk'), fetchImpl })
  assert.equal(await client.complete({ model: 'deepseek-v4-flash', messages: MESSAGES }), '最终台词')
})

test('throws a coded error on non-2xx', async () => {
  const fetchImpl = async () => jsonResponse(false, 500, {})
  const client = createDeepSeekClient({ credentials: credentialsWith('sk'), fetchImpl })
  await assert.rejects(
    () => client.complete({ model: 'deepseek-v4-flash', messages: MESSAGES }),
    (err) => err.code === 'HTTP_500',
  )
})

test('throws EMPTY on an empty completion', async () => {
  const fetchImpl = async () => jsonResponse(true, 200, { choices: [{ message: { content: '  ' } }] })
  const client = createDeepSeekClient({ credentials: credentialsWith('sk'), fetchImpl })
  await assert.rejects(
    () => client.complete({ model: 'deepseek-v4-flash', messages: MESSAGES }),
    (err) => err.code === 'EMPTY',
  )
})

test('throws MISSING_KEY when the credential is absent', async () => {
  let called = false
  const fetchImpl = async () => { called = true }
  const client = createDeepSeekClient({ credentials: credentialsWith(null), fetchImpl })
  await assert.rejects(
    () => client.complete({ model: 'deepseek-v4-flash', messages: MESSAGES }),
    (err) => err.code === 'MISSING_KEY',
  )
  assert.equal(called, false)
})

test('listModels parses ids and returns [] when unconfigured or failing', async () => {
  const ok = createDeepSeekClient({
    credentials: credentialsWith('sk'),
    fetchImpl: async () => jsonResponse(true, 200, { data: [{ id: 'deepseek-v4-flash' }, { id: '' }, {}] }),
  })
  assert.deepEqual(await ok.listModels(), ['deepseek-v4-flash'])

  const missing = createDeepSeekClient({ credentials: credentialsWith(null), fetchImpl: async () => { throw new Error('no') } })
  assert.deepEqual(await missing.listModels(), [])

  const nonOk = createDeepSeekClient({ credentials: credentialsWith('sk'), fetchImpl: async () => jsonResponse(false, 401, {}) })
  assert.deepEqual(await nonOk.listModels(), [])

  const rejects = createDeepSeekClient({ credentials: credentialsWith('sk'), fetchImpl: async () => { throw new Error('net') } })
  assert.deepEqual(await rejects.listModels(), [])
})

test('throws a coded NETWORK error when the request fails', async () => {
  const fetchImpl = async () => { throw new Error('fetch failed') }
  const client = createDeepSeekClient({ credentials: credentialsWith('sk'), fetchImpl })
  await assert.rejects(
    () => client.complete({ model: 'deepseek-v4-flash', messages: MESSAGES }),
    (err) => err.code === 'NETWORK',
  )
})
