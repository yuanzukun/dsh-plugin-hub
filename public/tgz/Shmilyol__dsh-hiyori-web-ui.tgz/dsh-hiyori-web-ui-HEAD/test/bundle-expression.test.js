import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

test('runtime bundle listens for expression events and reaches setExpression', async () => {
  const bundle = await readFile('assets/live2d/public/runtime/assets/index-BFXHG4mV.js', 'utf8')
  assert.match(bundle, /sakura-expression/)
  assert.match(bundle, /setExpression/)
})
