import assert from 'node:assert/strict'
import test from 'node:test'
import {
  classifySessionTransition,
  subscribeToSession,
  toSessionSignal,
} from '../src/client/session-status.js'

const base = {
  running: false,
  openError: null,
  promptError: null,
  lastAgentError: null,
  turnEnds: new Map(),
}

test('reports loading only after the 800ms threshold', () => {
  const running = { ...base, running: true }
  assert.equal(
    classifySessionTransition(base, running, { runningSince: 0, now: 799 }),
    null,
  )
  assert.equal(
    classifySessionTransition(base, running, { runningSince: 0, now: 800 }),
    'loading',
  )
})

test('reports completion on running true to false', () => {
  assert.equal(
    classifySessionTransition({ ...base, running: true }, base, { now: 1000 }),
    'complete',
  )
})

test('reports only a generic error signal', () => {
  assert.equal(
    classifySessionTransition(
      base,
      { ...base, promptError: new Error('private error text') },
      { now: 1000 },
    ),
    'error',
  )
})

test('does not repeat an unchanged error signal', () => {
  const error = new Error('private error text')
  assert.equal(
    classifySessionTransition(
      { ...base, promptError: error },
      { ...base, promptError: error },
      { now: 1000 },
    ),
    null,
  )
})

test('subscribes through the observable snapshot contract only', () => {
  const snapshots = [{ running: false }, { running: true }]
  let index = 0
  let listener
  let disposed = false
  const session = {
    getSnapshot() {
      return snapshots[index]
    },
    subscribe(callback) {
      listener = callback
      return () => {
        disposed = true
      }
    },
  }
  const seen = []
  const unsubscribe = subscribeToSession(session, (snapshot) => seen.push(snapshot))
  index = 1
  listener()
  unsubscribe()
  assert.deepEqual(seen, snapshots)
  assert.equal(disposed, true)
})

test('projects only generic status fields and drops error content', () => {
  const signal = toSessionSignal({
    ...base,
    running: true,
    promptError: new Error('private error text'),
    turnEnds: new Map([[1, 123]]),
    messages: ['private message'],
  })
  assert.deepEqual(signal, {
    running: true,
    hasError: true,
    turnEndCount: 1,
    turn: 0,
  })
  assert.doesNotMatch(JSON.stringify(signal), /private/)
})

test('reports the latest turn number from the in-window turn timings', () => {
  const signal = toSessionSignal({
    ...base,
    running: true,
    turnTimings: new Map([
      [3, { startTime: 1000, endTime: 2000 }],
      [4, { startTime: 3000 }],
    ]),
  })
  assert.equal(signal.turn, 4)
})
