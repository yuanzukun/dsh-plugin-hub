import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { cp, mkdir, mkdtemp, readFile, readdir, rm, stat } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, relative, sep } from 'node:path'
import { promisify } from 'node:util'
import test from 'node:test'
import { verifyBundledAssets } from '../tools/setup-live2d.mjs'

const ROOT = join(process.cwd(), 'assets', 'live2d')
const PUBLIC = join(ROOT, 'public')
const execFileAsync = promisify(execFile)

async function walk(dir) {
  const files = []
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name)
    if (entry.isDirectory()) files.push(...await walk(path))
    if (entry.isFile()) files.push(path)
  }
  return files.sort()
}

function references(model) {
  const refs = model.FileReferences
  return [
    refs.Moc,
    refs.Physics,
    refs.Pose,
    refs.DisplayInfo,
    ...refs.Textures,
    ...Object.values(refs.Motions).flat().map((motion) => motion.File),
    ...(refs.Expressions ?? []).map((expression) => expression.File),
  ]
}

test('bundles a complete hash-locked Hiyori runtime and keeps licenses private', async () => {
  const manifest = JSON.parse(await readFile(join(ROOT, 'manifest.json'), 'utf8'))
  assert.equal(manifest.sdkVersion, '5-r.5')
  assert.equal(manifest.samplesCommit, 'ed1e0b714826d92469b9e51cacc3346f4e393f03')
  assert.equal(manifest.frameworkCommit, '198a3769c26ca3d7b600e932590433badd392edd')
  assert.equal(manifest.model, 'Hiyori')

  const publicFiles = (await walk(PUBLIC)).map((path) => relative(PUBLIC, path).split(sep).join('/'))
  assert.deepEqual(Object.keys(manifest.files).sort(), publicFiles)
  assert.ok(Object.keys(manifest.files).every((key) => !key.startsWith('licenses/')))
  for (const [key, entry] of Object.entries(manifest.files)) {
    assert.equal(entry.path, `public/${key}`)
    const bytes = await readFile(join(ROOT, entry.path))
    assert.equal(entry.size, bytes.byteLength, key)
    assert.equal(entry.sha256, createHash('sha256').update(bytes).digest('hex'), key)
  }

  const licenses = new Map([
    ['licenses/Hiyori-Pro-ReadMe.txt', '4bcae2db95031260cac487cffefef5fabcb5501b29656f424a61a156ef6d2c3e'],
    ['public/runtime/Core/LICENSE.md', 'b81e37048010ef1d336106151201a0323c3309cae44aecdedf57831fe88fa991'],
    ['public/runtime/Core/RedistributableFiles.txt', 'd16c123688299e1e69a7f5ebc01b3bd75a8d408c024002a7d35b2aae94003f8c'],
  ])
  for (const [path, expected] of licenses) {
    const bytes = await readFile(join(ROOT, path))
    assert.equal(createHash('sha256').update(bytes).digest('hex'), expected, path)
  }
})

test('hash-locked public assets survive a core.autocrlf=true checkout', async (context) => {
  const temporary = await mkdtemp(join(tmpdir(), 'sakura-autocrlf-'))
  context.after(() => rm(temporary, { recursive: true, force: true }))
  const source = join(temporary, 'source')
  const checkout = join(temporary, 'checkout')
  await mkdir(source)
  await cp('.gitattributes', join(source, '.gitattributes'))
  await cp('assets', join(source, 'assets'), { recursive: true })

  const git = (args, cwd = source) => execFileAsync('git', args, { cwd })
  await git(['init', '-q'])
  await git(['config', 'core.autocrlf', 'false'])
  await git(['config', 'user.name', 'Live2D Test'])
  await git(['config', 'user.email', 'live2d-test@example.invalid'])
  await git(['add', '.gitattributes', 'assets'])
  await git(['-c', 'commit.gpgSign=false', 'commit', '-qm', 'fixture'])
  await git([
    '-c', 'core.autocrlf=true',
    'clone', '-q', '--no-local', source, checkout,
  ], temporary)

  await verifyBundledAssets({ projectRoot: checkout })
})

test('publishes the original Hiyori Pro references under the canonical model name', async () => {
  const modelRoot = join(PUBLIC, 'Resources', 'Hiyori')
  const model = JSON.parse(await readFile(join(modelRoot, 'Hiyori.model3.json'), 'utf8'))
  assert.deepEqual(model.HitAreas.map((area) => area.Name), ['Body'])
  assert.equal(model.FileReferences.Expressions.map((expression) => expression.Name).length, 8)
  assert.equal(model.FileReferences.Textures.length, 2)
  const motions = Object.values(model.FileReferences.Motions).flat()
  assert.equal(motions.length, 10)
  assert.ok(Object.hasOwn(model.FileReferences.Motions, 'Tap@Body'))
  for (const referenced of references(model)) {
    assert.ok((await stat(join(modelRoot, referenced))).isFile(), referenced)
  }
})

test('runtime URLs resolve index-local code and public-root model and shaders', async () => {
  const index = await readFile(join(PUBLIC, 'runtime', 'index.html'), 'utf8')
  assert.match(index, /src="\.\/assets\/index-[^"]+\.js"/)
  assert.match(index, /src\s*=\s*"\.\/Core\/live2dcubismcore\.js"/)
  assert.match(index, /src="\.\/companion-bridge\.js"/)

  const bundleName = (await readdir(join(PUBLIC, 'runtime', 'assets')))
    .find((name) => /^index-.*\.js$/.test(name))
  assert.ok(bundleName)
  const bundle = await readFile(join(PUBLIC, 'runtime', 'assets', bundleName), 'utf8')
  assert.match(bundle, /\.\.\/Resources\//)
  assert.match(bundle, /\.\.\/Framework\/Shaders\/WebGL\//)
  assert.match(bundle, /Hiyori/)
  assert.match(bundle, /Tap@Body/)
  assert.doesNotMatch(bundle, /[`"'](?:Mao|Haru|Natori|Wanko|Ren)[`"']/)
})
