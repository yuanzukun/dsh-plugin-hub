import assert from 'node:assert/strict'
import test from 'node:test'
import { createRuntimeAdapter } from '../src/client/runtime-adapter.js'

function createHarness() {
  const listeners = new Map()
  const frameListeners = new Map()
  const sent = []
  const timeouts = new Set()
  let removals = 0
  let createCount = 0
  const classList = {
    classes: new Set(),
    toggle(name, force) {
      if (force) this.classes.add(name)
      else this.classes.delete(name)
    },
    contains(name) {
      return this.classes.has(name)
    },
  }
  const contentWindow = {
    postMessage(message, origin) {
      sent.push({ message, origin })
    },
  }
  const frame = {
    className: '',
    title: '',
    src: '',
    contentWindow,
    isConnected: true,
    attributes: {},
    classList,
    setAttribute(name, value) {
      this.attributes[name] = value
    },
    addEventListener(type, listener) {
      frameListeners.set(type, listener)
    },
    removeEventListener(type, listener) {
      if (frameListeners.get(type) === listener) frameListeners.delete(type)
    },
    remove() {
      removals += 1
      this.isConnected = false
    },
  }
  const browserWindow = {
    location: { origin: 'http://localhost:3080' },
    addEventListener(type, listener) {
      const group = listeners.get(type) ?? new Set()
      group.add(listener)
      listeners.set(type, group)
    },
    removeEventListener(type, listener) {
      listeners.get(type)?.delete(listener)
    },
  }
  const browserDocument = {
    createElement(name) {
      assert.equal(name, 'iframe')
      createCount += 1
      return frame
    },
  }
  const container = {
    append(child) {
      assert.equal(child, frame)
    },
  }
  return {
    browserDocument,
    browserWindow,
    container,
    contentWindow,
    frame,
    timer: {
      timeout(callback) {
        timeouts.add(callback)
        return () => timeouts.delete(callback)
      },
    },
    sent,
    emit(data, { origin = 'null', source = contentWindow } = {}) {
      for (const listener of listeners.get('message') ?? []) {
        listener({ data, origin, source })
      }
    },
    expireTimeouts() {
      for (const callback of [...timeouts]) {
        timeouts.delete(callback)
        callback()
      }
    },
    listenerCount(type) {
      return listeners.get(type)?.size ?? 0
    },
    removalCount() {
      return removals
    },
    createCount() {
      return createCount
    },
  }
}

test('mounts a script-only opaque-origin runtime iframe', () => {
  const harness = createHarness()
  const adapter = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    onEvent() {},
    timer: harness.timer,
  })
  adapter.mount(harness.container)
  assert.equal(harness.frame.src, '/__sakura_live2d/runtime/index.html')
  assert.equal(harness.frame.attributes.sandbox, 'allow-scripts')
  assert.equal(harness.frame.title, '桃濑日和')
  adapter.destroyRuntime()
})

test('posts normalized pointer messages only after ready', () => {
  const harness = createHarness()
  const events = []
  const adapter = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    onEvent: (event) => events.push(event),
    timer: harness.timer,
  })
  adapter.mount(harness.container)
  adapter.lookAt(2, -2)
  assert.equal(harness.sent.length, 0)

  harness.emit({ source: 'sakura-vn-runtime', type: 'ready' })
  adapter.lookAt(2, -2)
  assert.deepEqual(harness.sent.at(-1), {
    message: {
      source: 'sakura-vn-parent',
      type: 'pointer',
      x: 1,
      y: -1,
    },
    origin: '*',
  })
  assert.deepEqual(events, [{ type: 'ready' }])
  adapter.destroyRuntime()
})

test('ignores messages from another source or origin', () => {
  const harness = createHarness()
  const events = []
  const adapter = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    onEvent: (event) => events.push(event),
    timer: harness.timer,
  })
  adapter.mount(harness.container)
  harness.emit(
    { source: 'sakura-vn-runtime', type: 'hit', area: 'Body' },
    { origin: 'https://evil.invalid' },
  )
  harness.emit(
    { source: 'sakura-vn-runtime', type: 'hit', area: 'Body' },
    { source: {} },
  )
  assert.deepEqual(events, [])
  adapter.destroyRuntime()
})

test('plays validated Hiyori motion groups after ready', () => {
  const harness = createHarness()
  const adapter = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    timer: harness.timer,
    onEvent() {},
  })
  adapter.mount(harness.container)
  harness.emit({ source: 'sakura-vn-runtime', type: 'ready' })
  const motionGroups = ['Idle', 'Flick', 'FlickDown', 'FlickUp', 'Tap', 'Tap@Body', 'Flick@Body']
  for (const id of motionGroups) adapter.playMotion(id)
  assert.deepEqual(harness.sent.slice(-motionGroups.length).map(({ message }) => message),
    motionGroups.map((id) => ({ source: 'sakura-vn-parent', type: 'motion', id })))
  assert.throws(() => adapter.playMotion('TapBody'), /Unsupported/)
  assert.equal('setExpression' in adapter, false)
  adapter.destroyRuntime()
})

test('soft destroy keeps the live frame for the next adapter to adopt', () => {
  const harness = createHarness()
  const firstEvents = []
  const secondEvents = []
  const first = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    onEvent: (event) => firstEvents.push(event),
    timer: harness.timer,
  })
  first.mount(harness.container)
  harness.emit({ source: 'sakura-vn-runtime', type: 'ready' })
  first.destroy()
  first.destroy()

  assert.equal(harness.createCount(), 1)
  assert.equal(harness.removalCount(), 0)

  const second = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    onEvent: (event) => secondEvents.push(event),
    timer: harness.timer,
  })
  second.mount(harness.container)
  assert.equal(harness.createCount(), 1)
  assert.deepEqual(secondEvents, [{ type: 'ready' }])
  second.lookAt(2, -2)
  assert.deepEqual(harness.sent.at(-1).message, {
    source: 'sakura-vn-parent',
    type: 'pointer',
    x: 1,
    y: -1,
  })
  second.destroyRuntime()
})

test('destroyRuntime tears down the frame, listener and ready state', () => {
  const harness = createHarness()
  const adapter = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    onEvent() {},
    timer: harness.timer,
  })
  adapter.mount(harness.container)
  harness.emit({ source: 'sakura-vn-runtime', type: 'ready' })
  adapter.destroyRuntime()
  adapter.destroyRuntime()
  assert.equal(harness.removalCount(), 1)
  assert.equal(harness.listenerCount('message'), 0)
  assert.equal(
    harness.sent.filter(({ message }) => message.type === 'destroy').length,
    1,
  )

  const events = []
  const next = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    onEvent: (event) => events.push(event),
    timer: harness.timer,
  })
  next.mount(harness.container)
  assert.equal(harness.createCount(), 2)
  assert.deepEqual(events, [])
  next.destroyRuntime()
})

test('hard destroy still tears down after a soft destroy', () => {
  const harness = createHarness()
  const adapter = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    onEvent() {},
    timer: harness.timer,
  })
  adapter.mount(harness.container)
  harness.emit({ source: 'sakura-vn-runtime', type: 'ready' })
  adapter.destroy()
  adapter.destroyRuntime()
  assert.equal(harness.removalCount(), 1)
  assert.equal(harness.listenerCount('message'), 0)
  assert.equal(
    harness.sent.filter(({ message }) => message.type === 'destroy').length,
    1,
  )
})

test('posts expression commands only after ready', () => {
  const harness = createHarness()
  const adapter = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    onEvent() {},
    timer: harness.timer,
  })
  adapter.mount(harness.container)
  adapter.playExpression('joy')
  assert.equal(harness.sent.length, 0)
  harness.emit({ source: 'sakura-vn-runtime', type: 'ready' })
  adapter.playExpression('proud')
  assert.deepEqual(harness.sent.at(-1), {
    message: { source: 'sakura-vn-parent', type: 'expression', id: 'proud' },
    origin: '*',
  })
  adapter.destroyRuntime()
})

test('reports an error when the runtime never becomes ready', () => {
  const harness = createHarness()
  const events = []
  const adapter = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    timer: harness.timer,
    onEvent: (event) => events.push(event),
  })
  adapter.mount(harness.container)
  harness.expireTimeouts()
  assert.deepEqual(events, [{ type: 'error', code: 'runtime-timeout' }])
  adapter.destroyRuntime()
})

test('ready cancels the runtime load timeout', () => {
  const harness = createHarness()
  const events = []
  const adapter = createRuntimeAdapter({
    window: harness.browserWindow,
    document: harness.browserDocument,
    timer: harness.timer,
    onEvent: (event) => events.push(event),
  })
  adapter.mount(harness.container)
  harness.emit({ source: 'sakura-vn-runtime', type: 'ready' })
  harness.expireTimeouts()
  assert.deepEqual(events, [{ type: 'ready' }])
  adapter.destroyRuntime()
})
