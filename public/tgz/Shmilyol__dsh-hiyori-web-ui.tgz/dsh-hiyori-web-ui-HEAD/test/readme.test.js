import assert from 'node:assert/strict'
import { access, readFile } from 'node:fs/promises'
import test from 'node:test'

test('README gives users the bundled Hiyori setup and DSH activation flow', async () => {
  const readme = await readFile('README.md', 'utf8')
  assert.match(readme, /git clone/)
  assert.match(readme, /npm install/)
  assert.match(readme, /npm run setup:live2d/)
  assert.match(readme, /预构建|已包含.*Hiyori|Hiyori.*运行资源/s)
  assert.match(readme, /lib\/index\.js/)
  assert.match(readme, /lib\/client\.js/)
  assert.match(readme, /dsh plugin --profile web add/)
  assert.match(readme, /dsh plugin --profile web remove dsh-hiyori-web-ui/)
  assert.match(readme, /npx @deepseek-ai\/dsh web/)
  assert.match(readme, /重启.*保留|常驻/)
  assert.doesNotMatch(readme, /cordis_define/)
  assert.doesNotMatch(readme, /cordis_run/)
  assert.match(readme, /桃濑日和/)
  assert.match(readme, /本作品的角色在运用株式会社Live2D的著作物素材样本时依据了株式会社Live2D规定的协议。本作品完全根据制作者的自我裁量制作而成。/)
  assert.match(readme, /不读取对话内容/)
  assert.match(readme, /加载.*完成.*错误|loading.*complete.*error/i)
  assert.match(readme, /暖色、温柔/)
  assert.doesNotMatch(readme, /和风/)
  for (const forbidden of [
    /CubismSdkForWeb/, /--sdk-zip/, /install-live2d/, /\bMao\b/, /Downloads/, /拖.*zip/, /Chrome.*卡顿|下载.*卡顿/,
  ]) assert.doesNotMatch(readme, forbidden)
})

test('README embeds the current product screenshots and interaction animation', async () => {
  const readme = await readFile('README.md', 'utf8')
  const screenshots = [
    'docs/readme/hero.png',
    'docs/readme/interaction.png',
    'docs/readme/settings.png',
  ]

  for (const screenshot of screenshots) {
    assert.match(readme, new RegExp(screenshot.replaceAll('/', '\\/')))
    await access(screenshot)
    const bytes = await readFile(screenshot)
    assert.deepEqual([...bytes.subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10])
  }

  const animation = 'docs/readme/hiyori-mouse-follow.gif'
  assert.match(readme, new RegExp(animation.replaceAll('/', '\\/')))
  await access(animation)
  const animationBytes = await readFile(animation)
  assert.match(animationBytes.subarray(0, 6).toString('ascii'), /^GIF8[79]a$/)

  for (const obsolete of [
    'docs/readme/personalities.png',
    'docs/readme/ai-dialogue.png',
    'docs/screenshots/hero.png',
    'docs/screenshots/character-interaction.png',
    'docs/screenshots/settings.png',
    'docs/screenshots/hiyori-demo.gif',
  ]) assert.doesNotMatch(readme, new RegExp(obsolete.replaceAll('/', '\\/')))
})

test('Live2D license notes describe the bundled Core and Hiyori assets', async () => {
  const notes = await readFile('docs/live2d-licenses.md', 'utf8')
  assert.match(notes, /assets\/live2d\/public\/runtime\/Core\/live2dcubismcore\.js/)
  assert.match(notes, /assets\/live2d\/public\/Resources\/Hiyori/)
  assert.match(notes, /ed1e0b714826d92469b9e51cacc3346f4e393f03/)
  assert.match(notes, /198a3769c26ca3d7b600e932590433badd392edd/)
  assert.match(notes, /Kani Biimu/)
  assert.match(notes, /Live2D Open Software License Agreement/)
  assert.match(notes, /Sample Model Terms/)
  assert.match(notes, /Free Material License Agreement/)
  assert.match(notes, /不得脱离本插件单独再分发/)
  assert.match(notes, /vendor-live2d|维护者/)
})
