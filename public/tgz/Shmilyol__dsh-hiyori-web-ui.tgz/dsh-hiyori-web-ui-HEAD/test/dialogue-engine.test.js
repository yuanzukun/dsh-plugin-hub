import assert from 'node:assert/strict'
import test from 'node:test'
import { createDialogueEngine, DEFAULT_RULES } from '../src/client/dialogue-engine.js'
import { PERSONALITY_LINES, rulesFor } from '../src/client/personalities.js'

const rules = [
  { id: 'idle', event: 'idle', priority: 10, cooldownMs: 600000, durationMs: 4000, lines: ['idle'] },
  { id: 'loading', event: 'loading', priority: 40, cooldownMs: 0, durationMs: 4000, lines: ['loading'] },
  { id: 'complete', event: 'complete', priority: 60, cooldownMs: 0, durationMs: 4000, lines: ['complete'] },
  { id: 'motion', event: 'motion', priority: 70, cooldownMs: 1000, durationMs: 4000, lines: ['motion'] },
  { id: 'click', event: 'body-click', priority: 80, cooldownMs: 1000, durationMs: 4000, lines: ['click'] },
  { id: 'error', event: 'error', priority: 100, cooldownMs: 0, durationMs: 4000, lines: ['error'] },
  { id: 'greeting', event: 'greeting', priority: 20, cooldownMs: 0, durationMs: 4000, lines: ['greeting'] },
]

test('priority order is error > body-click > motion > complete > loading > greeting > idle', () => {
  assert.deepEqual([...rules].sort((a, b) => b.priority - a.priority).map((r) => r.event), ['error', 'body-click', 'motion', 'complete', 'loading', 'greeting', 'idle'])
})

test('higher-priority events replace lower-priority bubbles', () => {
  const engine = createDialogueEngine({ rules, random: () => 0 })
  assert.equal(engine.trigger('idle', 0).ruleId, 'idle')
  assert.equal(engine.trigger('error', 1).ruleId, 'error')
})

test('lower-priority events do not replace an active high-priority bubble', () => {
  const engine = createDialogueEngine({ rules, random: () => 0 })
  engine.trigger('error', 0)
  assert.equal(engine.trigger('loading', 100), null)
})

test('event cooldown blocks repeated clicks', () => {
  const engine = createDialogueEngine({ rules, random: () => 0 })
  assert.ok(engine.trigger('body-click', 0))
  assert.equal(engine.trigger('body-click', 500), null)
  assert.ok(engine.trigger('body-click', 1001))
})

test('same rule avoids repeating a line when another line exists', () => {
  const custom = [{ ...rules.find((r) => r.event === 'body-click'), lines: ['one', 'two'] }]
  const engine = createDialogueEngine({ rules: custom, random: () => 0 })
  assert.equal(engine.trigger('body-click', 0).text, 'one')
  engine.dismiss()
  assert.equal(engine.trigger('body-click', 1001).text, 'two')
})

test('dismiss and current clear expired bubbles', () => {
  const engine = createDialogueEngine({ rules, random: () => 0 })
  engine.trigger('body-click', 0)
  assert.equal(engine.current(3999).text, 'click')
  assert.equal(engine.current(4000), null)
  engine.trigger('body-click', 5000)
  engine.dismiss()
  assert.equal(engine.current(5000), null)
})

test('production rules include all required events and timing', () => {
  assert.deepEqual(DEFAULT_RULES.map((rule) => rule.event), ['error', 'body-click', 'complete', 'streak', 'loading', 'longrun', 'session', 'greeting-morning', 'greeting-daytime', 'greeting-evening', 'idle'])
  assert.ok(DEFAULT_RULES.every((rule) => rule.durationMs >= 4000 && rule.durationMs <= 6000))
  assert.equal(DEFAULT_RULES.find((rule) => rule.event === 'idle').cooldownMs, 600000)
  assert.equal(DEFAULT_RULES.find((rule) => rule.event === 'body-click').cooldownMs, 1000)
})

test('setRules swaps the line source while keeping cooldown memory', () => {
  const engine = createDialogueEngine({ rules: DEFAULT_RULES, random: () => 0 })
  assert.ok(engine.trigger('error', 0))
  assert.equal(engine.trigger('error', 500), null)
  engine.setRules(rulesFor('tsundere'))
  assert.equal(engine.trigger('error', 500), null)
  const bubble = engine.trigger('error', 1000)
  assert.ok(PERSONALITY_LINES.tsundere.error.includes(bubble.text))
})

test('setRules keeps the per-rule non-repeat memory across the swap', () => {
  const engine = createDialogueEngine({ rules: rulesFor('gentle'), random: () => 0 })
  engine.trigger('error', 0)
  engine.setRules(rulesFor('tsundere'))
  const bubble = engine.trigger('error', 2000)
  assert.ok(PERSONALITY_LINES.tsundere.error.includes(bubble.text))
  assert.equal(bubble.text, PERSONALITY_LINES.tsundere.error[0])
})

test('setRules preserves the active bubble priority guard', () => {
  const engine = createDialogueEngine({ rules: rulesFor('gentle'), random: () => 0 })
  engine.trigger('error', 0)
  engine.setRules(rulesFor('genki'))
  assert.equal(engine.trigger('body-click', 0), null)
})

test('function lines resolve per trigger with vars and {n} placeholders render', () => {
  const rules = [{
    id: 'streak', event: 'streak', priority: 55, cooldownMs: 0, durationMs: 4000,
    lines: (vars) => [vars.n === 3 ? '连续 3 次成功' : '连续 {n} 次成功'],
  }]
  const engine = createDialogueEngine({ rules, random: () => 0 })
  const first = engine.trigger('streak', 0, { n: 3 })
  assert.equal(first.text, '连续 3 次成功')
  engine.dismiss()
  const second = engine.trigger('streak', 1000, { n: 5 })
  assert.equal(second.text, '连续 5 次成功')
})

test('plain array lines pass through untouched without vars', () => {
  const rules = [
    { id: 'complete', event: 'complete', priority: 60, cooldownMs: 0, durationMs: 4000, lines: ['完成啦'] },
  ]
  const engine = createDialogueEngine({ rules, random: () => 0 })
  assert.equal(engine.trigger('complete', 0).text, '完成啦')
})

test('production streak rules resolve tier lines and render the count', () => {
  const engine = createDialogueEngine({ rules: rulesFor('gentle'), random: () => 0 })
  const bubble = engine.trigger('streak', 0, { n: 15 })
  assert.equal(bubble.text, '连续 15 次，连我自己都有点佩服自己了。')
})

test('non-repeat picks from the filtered pool without going out of bounds', () => {
  const custom = [{ id: 'e', event: 'e', priority: 60, cooldownMs: 0, durationMs: 4000, lines: ['A', 'B'] }]
  const engine = createDialogueEngine({ rules: custom, random: () => 0.9 })
  assert.equal(engine.trigger('e', 0).text, 'B')
  engine.dismiss()
  assert.equal(engine.trigger('e', 1000).text, 'A')
  engine.dismiss()
  assert.equal(engine.trigger('e', 2000).text, 'B')
})

test('reserve + localLine + fill reproduce trigger', () => {
  const engine = createDialogueEngine({ rules, random: () => 0 })
  const slot = engine.reserve('body-click', 0)
  assert.equal(slot.ruleId, 'click')
  assert.equal(slot.priority, 80)
  assert.equal(engine.fill(slot, engine.localLine(slot, {})).text, 'click')
})

test('reserve returns null within the cooldown window', () => {
  const engine = createDialogueEngine({ rules, random: () => 0 })
  engine.trigger('body-click', 0)
  assert.equal(engine.reserve('body-click', 500), null)
})

test('fill records the final text so localLine can keep avoiding repeats', () => {
  const custom = [{ ...rules.find((r) => r.event === 'body-click'), lines: ['one', 'two'] }]
  const engine = createDialogueEngine({ rules: custom, random: () => 0 })
  const first = engine.reserve('body-click', 0)
  engine.fill(first, 'a model-generated line')
  engine.dismiss()
  const second = engine.reserve('body-click', 1001)
  assert.equal(engine.localLine(second, {}), 'one')
})
