import assert from 'node:assert/strict'
import test from 'node:test'
import { createAssetHandler } from '../src/host/asset-route.js'

function responseRecorder() {
  return {
    status: 0,
    headers: {},
    headersSent: false,
    body: undefined,
    writeHead(status, headers = {}) {
      this.status = status
      this.headers = headers
      this.headersSent = true
    },
    end(body) {
      this.body = body
    },
  }
}

const manifest = {
  files: {
    'runtime/index.html': { path: '/installed/runtime/index.html', size: 12 },
    'runtime/assets/app.js': { path: '/installed/runtime/assets/app.js', size: 8 },
    'Resources/Hiyori/hiyori_pro_t11.moc3': {
      path: '/installed/Resources/Hiyori/hiyori_pro_t11.moc3',
      size: 4,
    },
  },
}

test('rejects traversal and files outside the manifest', async () => {
  const handler = createAssetHandler({ fs: {}, manifest })
  const urls = [
    '/__sakura_live2d/../secret',
    '/__sakura_live2d/%2e%2e/secret',
    '/__sakura_live2d/unknown',
    '/__sakura_live2d/__proto__',
  ]
  for (const url of urls) {
    const res = responseRecorder()
    await handler({ method: 'GET', url }, res)
    assert.equal(res.status, 404)
  }
})

test('allows only GET and HEAD', async () => {
  const handler = createAssetHandler({ fs: {}, manifest })
  const res = responseRecorder()
  await handler({ method: 'POST', url: '/__sakura_live2d/runtime/index.html' }, res)
  assert.equal(res.status, 405)
  assert.equal(res.headers.allow, 'GET, HEAD')
})

test('serves a known file with strict headers', async () => {
  const fs = {
    async resolve(path) {
      return { kind: 'file', path }
    },
    async readBytes() {
      return Uint8Array.from([1, 2, 3, 4])
    },
  }
  const handler = createAssetHandler({ fs, manifest })
  const res = responseRecorder()
  await handler(
    { method: 'GET', url: '/__sakura_live2d/Resources/Hiyori/hiyori_pro_t11.moc3' },
    res,
  )
  assert.equal(res.status, 200)
  assert.equal(res.headers['content-type'], 'application/octet-stream')
  assert.equal(res.headers['x-content-type-options'], 'nosniff')
  assert.equal(res.headers['access-control-allow-origin'], '*')
  assert.deepEqual(res.body, Uint8Array.from([1, 2, 3, 4]))
})

test('HEAD returns headers without reading bytes', async () => {
  let reads = 0
  const fs = {
    async resolve(path) {
      return { kind: 'file', path }
    },
    async readBytes() {
      reads += 1
    },
  }
  const handler = createAssetHandler({ fs, manifest })
  const res = responseRecorder()
  await handler({ method: 'HEAD', url: '/__sakura_live2d/runtime/assets/app.js' }, res)
  assert.equal(res.status, 200)
  assert.equal(reads, 0)
  assert.equal(res.body, undefined)
})

test('rejects files larger than the configured cap', async () => {
  const handler = createAssetHandler({ fs: {}, manifest, maxBytes: 3 })
  const res = responseRecorder()
  await handler(
    { method: 'GET', url: '/__sakura_live2d/Resources/Hiyori/hiyori_pro_t11.moc3' },
    res,
  )
  assert.equal(res.status, 413)
})

test('reports a file read failure as 500 before sending success headers', async () => {
  const fs = {
    async resolve(path) {
      return { kind: 'file', path }
    },
    async readBytes() {
      throw new Error('disk unavailable')
    },
  }
  const handler = createAssetHandler({ fs, manifest })
  const res = responseRecorder()
  await handler({ method: 'GET', url: '/__sakura_live2d/runtime/index.html' }, res)
  assert.equal(res.status, 500)
  assert.deepEqual(res.headers, {})
})

test('rejects a file whose current byte length differs from the manifest', async () => {
  const fs = {
    async resolve(path) {
      return path
    },
    async readBytes() {
      return new Uint8Array(3)
    },
  }
  const handler = createAssetHandler({ fs, manifest })
  const res = responseRecorder()
  await handler({ method: 'GET', url: '/__sakura_live2d/runtime/index.html' }, res)
  assert.equal(res.status, 500)
  assert.equal(res.body, undefined)
})

test('serves mutable runtime entry files as no-cache and static assets as immutable', async () => {
  const fs = {
    async resolve(path) {
      return path
    },
    async readBytes() {
      return new Uint8Array(0)
    },
  }
  const withBridge = {
    files: {
      ...manifest.files,
      'runtime/companion-bridge.js': {
        path: '/installed/runtime/companion-bridge.js',
        size: 0,
      },
    },
  }
  const handler = createAssetHandler({ fs, manifest: withBridge })
  for (const file of ['runtime/index.html', 'runtime/companion-bridge.js']) {
    const res = responseRecorder()
    await handler({ method: 'HEAD', url: `/__sakura_live2d/${file}` }, res)
    assert.equal(res.status, 200)
    assert.equal(res.headers['cache-control'], 'no-cache')
  }
  const asset = responseRecorder()
  await handler({ method: 'HEAD', url: '/__sakura_live2d/runtime/assets/app.js' }, asset)
  assert.equal(asset.status, 200)
  assert.equal(asset.headers['cache-control'], 'public, max-age=31536000, immutable')
})
