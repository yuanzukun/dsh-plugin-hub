import assert from 'node:assert/strict'
import test from 'node:test'
import {
  ASSET_PREFIX,
  CHAT_CONFIG_PATH,
  CREDENTIAL_REF,
  DEFAULT_MODEL,
  DEFAULT_MODELS,
  MODELS_PATH,
  SAY_PATH,
  makeCommand,
  parseRuntimeEvent,
} from '../src/shared/protocol.js'

test('uses a same-origin reserved asset prefix', () => {
  assert.equal(ASSET_PREFIX, '/__sakura_live2d')
})

test('clamps pointer commands to normalized coordinates', () => {
  assert.deepEqual(makeCommand('pointer', { x: 3, y: -2 }), {
    source: 'sakura-vn-parent',
    type: 'pointer',
    x: 1,
    y: -1,
  })
})

test('accepts only installed Hiyori motion groups', () => {
  const motionGroups = [
    'Idle',
    'Flick',
    'FlickDown',
    'FlickUp',
    'Tap',
    'Tap@Body',
    'Flick@Body',
  ]
  for (const id of motionGroups) {
    assert.deepEqual(makeCommand('motion', { id }), {
      source: 'sakura-vn-parent',
      type: 'motion',
      id,
    })
  }
  assert.throws(() => makeCommand('motion', { id: 'TapBody' }), /Unsupported/)
  assert.throws(() => makeCommand('motion', { id: 'Unknown' }), /Unsupported/)
})

test('accepts only installed expression ids', () => {
  const expressions = ['joy', 'sad', 'angry', 'proud', 'shy', 'sleepy', 'relief', 'surprise']
  for (const id of expressions) {
    assert.deepEqual(makeCommand('expression', { id }), {
      source: 'sakura-vn-parent',
      type: 'expression',
      id,
    })
  }
  assert.throws(() => makeCommand('expression', { id: 'exp_01' }), /Unsupported/)
  assert.throws(() => makeCommand('expression', { id: 'Joy' }), /Unsupported/)
})

test('accepts only Body hit runtime events', () => {
  assert.deepEqual(
    parseRuntimeEvent({ source: 'sakura-vn-runtime', type: 'hit', area: 'Body' }),
    { type: 'hit', area: 'Body' },
  )
  assert.equal(parseRuntimeEvent({ source: 'other', type: 'hit', area: 'Head' }), null)
  assert.equal(parseRuntimeEvent({ source: 'sakura-vn-runtime', type: 'hit', area: 'Head' }), null)
  assert.equal(parseRuntimeEvent({ source: 'sakura-vn-runtime', type: 'hit', area: 'Face' }), null)
})

test('exposes the LLM chat routes and defaults under the asset prefix', () => {
  assert.equal(SAY_PATH, '/__sakura_live2d/say')
  assert.equal(MODELS_PATH, '/__sakura_live2d/models')
  assert.equal(CHAT_CONFIG_PATH, '/__sakura_live2d/chat-config')
  assert.equal(CREDENTIAL_REF, 'HIYORI_DEEPSEEK_API_KEY')
  assert.equal(DEFAULT_MODEL, 'deepseek-v4-flash')
  assert.deepEqual(DEFAULT_MODELS, ['deepseek-v4-flash', 'deepseek-v4-pro'])
})
