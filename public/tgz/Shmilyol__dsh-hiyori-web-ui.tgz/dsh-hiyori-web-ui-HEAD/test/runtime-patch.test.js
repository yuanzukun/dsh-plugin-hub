import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'
import { runInNewContext } from 'node:vm'

function addedLines(patch) {
  return patch.split('\n')
    .filter((line) => line.startsWith('+') && !line.startsWith('+++'))
    .map((line) => line.slice(1))
    .join('\n')
}

test('fixed runtime patch targets only Hiyori and reports only Body hits', async () => {
  const patch = await readFile('runtime/patches/5-r.5-companion.patch', 'utf8')
  const added = addedLines(patch)
  assert.match(added, /ModelDir: string\[\] = \['Hiyori'\]/)
  assert.match(added, /area: 'Body'/)
  assert.doesNotMatch(added, /area: 'Head'|setExpression|sakura-expression|Mao/)
  for (const id of ['Idle', 'Flick', 'FlickDown', 'FlickUp', 'Tap', 'Tap@Body', 'Flick@Body']) {
    assert.match(added, new RegExp(`'${id.replace('@', '@')}'`))
  }
  assert.match(added, /startRandomMotion\(\s*motionId,/)
  assert.match(added, /startRandomMotion\(\s*'Idle',/)
  assert.match(added, /setTimeout/)
})

test('fixed runtime patch makes the Vite build and WebGL canvas transparent', async () => {
  const patch = await readFile('runtime/patches/5-r.5-companion.patch', 'utf8')
  const added = addedLines(patch)
  assert.match(added, /base: '\.\/'/)
  assert.match(added, /ResourcesPath = '\.\.\/Resources\/'/)
  assert.match(added, /ShaderPath = '\.\.\/Framework\/Shaders\/WebGL\/'/)
  assert.match(added, /clearColor\(0\.0, 0\.0, 0\.0, 0\.0\)/)
  assert.match(added, /model-load/)
  assert.match(added, /crossOrigin = 'anonymous'/)
})

test('bridge accepts parent commands by source, not by the opaque iframe origin', async () => {
  const bridge = await readFile('runtime/bridge/companion-bridge.js', 'utf8')
  // 不透明 iframe 的 window.location.origin 恒为 "null"，不能用它与父页面 origin 比较。
  assert.doesNotMatch(bridge, /event\.origin !== window\.location\.origin/)
  assert.match(bridge, /event\.source !== window\.parent/)
  assert.match(bridge, /sakura-vn-parent/)
  assert.match(bridge, /sakura-motion/)
  assert.match(bridge, /expression/)
})

test('bridge applies the final vertical pointer position despite Cubism move lag', async () => {
  const bridge = await readFile('runtime/bridge/companion-bridge.js', 'utf8')
  const listeners = new Map()
  const pointerEvents = []
  let cubismTouchY = null
  let appliedY = null
  const parent = { postMessage() {} }
  const canvas = {
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 280, height: 250 }),
    dispatchEvent(event) {
      pointerEvents.push(event.type)
      if (event.type === 'pointerdown') {
        cubismTouchY = event.clientY
      } else if (event.type === 'pointermove') {
        // Cubism 5-r.5 applies the saved touch before recording this event.
        appliedY = cubismTouchY
        cubismTouchY = event.clientY
      }
    },
  }
  class PointerEvent {
    constructor(type, init) {
      this.type = type
      this.clientY = init.clientY
    }
  }
  // 运行时 iframe 由 sandbox="allow-scripts"（无 allow-same-origin）创建，为不透明源：
  // window.location.origin 是 "null"，而父页面消息的 origin 是真实源。桥接层必须靠
  // event.source === window.parent 识别父页面，不能拿 origin 与 "null" 比较。
  const window = {
    location: { origin: 'null' },
    parent,
    clearTimeout() {},
    setTimeout() {
      return 1
    },
    addEventListener(type, listener) {
      listeners.set(type, listener)
    },
    dispatchEvent() {},
  }
  runInNewContext(bridge, {
    CustomEvent: class {},
    Event: class {},
    Object,
    PointerEvent,
    document: { querySelector: () => canvas },
    window,
  })

  const sendPointer = (y) => listeners.get('message')({
    origin: 'http://127.0.0.1:3080',
    source: parent,
    data: { source: 'sakura-vn-parent', type: 'pointer', x: 0, y },
  })
  sendPointer(1)
  sendPointer(-1)

  assert.equal(appliedY, 250)
  assert.deepEqual(pointerEvents, [
    'pointerdown',
    'pointermove',
    'pointermove',
    'pointermove',
  ])
})

test('bridge reports runtime events to the parent with a wildcard target origin', async () => {
  const bridge = await readFile('runtime/bridge/companion-bridge.js', 'utf8')
  const sent = []
  const window = {
    // 不透明 iframe 的自身 origin 是 "null"，不能作为 targetOrigin（父页面不是不透明源），
    // 必须用 '*' 才能把 ready/hit/error 送到父页面。
    location: { origin: 'null' },
    parent: {
      postMessage(message, origin) {
        sent.push({ message, origin })
      },
    },
    clearTimeout() {},
    setTimeout() {
      return 1
    },
    addEventListener() {},
    dispatchEvent() {},
  }
  runInNewContext(bridge, {
    CustomEvent: class {},
    Event: class {},
    Object,
    PointerEvent: class {},
    document: { querySelector: () => null },
    window,
  })
  window.__sakuraCompanion.send('ready')
  assert.equal(sent.length, 1)
  assert.equal(sent[0].origin, '*')
  assert.equal(sent[0].message.source, 'sakura-vn-runtime')
  assert.equal(sent[0].message.type, 'ready')
})
