import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { mkdir, mkdtemp, readFile, realpath, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import test from 'node:test'
import {
  parseSetupArgs,
  runSetup,
  verifyBundledAssets,
} from '../tools/setup-live2d.mjs'

async function touch(path, data = 'data') {
  await mkdir(dirname(path), { recursive: true })
  await writeFile(path, data)
}

function runNode(args, cwd) {
  return new Promise((resolvePromise, rejectPromise) => {
    const child = spawn(process.execPath, args, { cwd, stdio: ['ignore', 'pipe', 'pipe'] })
    let stdout = ''
    let stderr = ''
    child.stdout.setEncoding('utf8')
    child.stderr.setEncoding('utf8')
    child.stdout.on('data', (chunk) => { stdout += chunk })
    child.stderr.on('data', (chunk) => { stderr += chunk })
    child.once('error', rejectPromise)
    child.once('exit', (code) => resolvePromise({ code, stdout, stderr }))
  })
}

test('setup accepts no arguments and rejects every installer argument', () => {
  assert.deepEqual(parseSetupArgs([]), {})
  assert.throws(() => parseSetupArgs(['--sdk-zip', '/tmp/sdk.zip']), /Unknown argument/)
  assert.throws(() => parseSetupArgs(['--accept-license']), /Unknown argument/)
})

test('verifies every bundled manifest file by size and sha256', async () => {
  const root = await mkdtemp(join(tmpdir(), 'sakura-setup-'))
  const required = [
    'runtime/index.html',
    'runtime/Core/live2dcubismcore.js',
    'Resources/Hiyori/Hiyori.model3.json',
    'Resources/Hiyori/hiyori_pro_t11.2048/texture_00.png',
    'Resources/Hiyori/hiyori_pro_t11.2048/texture_01.png',
  ]
  const assetRoot = join(root, 'assets', 'live2d')
  for (const key of required) await touch(join(assetRoot, 'public', key))
  const digest = createHash('sha256').update('data').digest('hex')
  await touch(join(assetRoot, 'manifest.json'), JSON.stringify({
    sdkVersion: '5-r.5',
    model: 'Hiyori',
    files: Object.fromEntries(required.map((key) => [key, {
      path: `public/${key}`,
      size: 4,
      sha256: digest,
    }])),
  }))

  const manifest = await verifyBundledAssets({ projectRoot: root })
  assert.equal(manifest.model, 'Hiyori')

  await writeFile(join(assetRoot, 'public', 'runtime', 'index.html'), 'dAta')
  await assert.rejects(
    () => verifyBundledAssets({ projectRoot: root }),
    /sha256/i,
  )

  await writeFile(join(assetRoot, 'public', 'runtime', 'index.html'), 'data')
  await touch(join(assetRoot, 'public', 'runtime', 'unlisted.js'))
  await assert.rejects(
    () => verifyBundledAssets({ projectRoot: root }),
    /manifest|unlisted/i,
  )
})

test('setup installs build dependencies then generates client and host from bundled assets', async () => {
  const commands = []
  const builds = []
  const messages = []
  const manifest = { model: 'Hiyori' }

  const result = await runSetup({
    argv: [],
    projectRoot: '/project',
    dependencyReady: async () => false,
    verifyAssets: async () => manifest,
    runCommand: async (command, args) => { commands.push([command, args]) },
    buildClient: async () => { builds.push('client') },
    buildHost: async (options) => { builds.push(options.manifestPath) },
    verifyOutputs: async () => true,
    write: (message) => messages.push(message),
  })

  assert.equal(result, 0)
  assert.deepEqual(commands, [['npm', ['install']]])
  assert.deepEqual(builds, [
    'client',
    join('/project', 'assets', 'live2d', 'manifest.json'),
  ])
  assert.match(messages.join('\n'), /桃濑日和/)
  assert.match(messages.join('\n'), /lib\/index\.js/)
  assert.match(messages.join('\n'), /lib\/client\.js/)
  assert.match(messages.join('\n'), /npx @deepseek-ai\/dsh plugin --profile web add \/project/)
  assert.doesNotMatch(messages.join('\n'), /SDK|许可|下载/)
})

test('package exposes the bundled Live2D setup command', async () => {
  const packageJson = JSON.parse(await readFile('package.json', 'utf8'))
  assert.equal(packageJson.scripts['setup:live2d'], 'node tools/setup-live2d.mjs')
})

test('setup reports missing bundled assets before importing optional build dependencies', async () => {
  const root = await realpath(await mkdtemp(join(tmpdir(), 'sakura-cold-')))
  const tools = join(root, 'tools')
  await mkdir(tools, { recursive: true })
  await writeFile(join(root, 'package.json'), '{"type":"module"}\n')
  await writeFile(
    join(tools, 'setup-live2d.mjs'),
    await readFile(join('tools', 'setup-live2d.mjs'), 'utf8'),
  )

  const result = await runNode([join(tools, 'setup-live2d.mjs')], root)

  assert.equal(result.code, 1)
  assert.match(result.stdout, /桃濑日和/)
  assert.match(result.stderr, /manifest|资源/i)
  assert.doesNotMatch(result.stderr, /esbuild|ERR_MODULE_NOT_FOUND/)
})
