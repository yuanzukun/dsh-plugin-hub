import assert from 'node:assert/strict'
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import test from 'node:test'
import {
  buildClientBundle,
  buildHostModule,
} from '../tools/build-package.mjs'

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)))

test('host module embeds absolute manifest paths as an ES module plugin', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'sakura-host-'))
  await mkdir(join(dir, 'public', 'runtime'), { recursive: true })
  const manifestPath = join(dir, 'manifest.json')
  await writeFile(
    manifestPath,
    JSON.stringify({
      sdkVersion: '5-r.5',
      model: 'Hiyori',
      files: {
        'runtime/index.html': { path: 'public/runtime/index.html', size: 12 },
      },
    }),
  )
  const body = await buildHostModule({ manifestPath, write: false })
  assert.match(body, /dsh-hiyori-web-ui/)
  assert.match(body, /5-r\.5/)
  assert.ok(body.includes(dir))
  assert.match(body, /export\s*\{[\s\S]*apply/)
  assert.match(body, /webServer/)
  assert.match(body, /fs/)
  assert.match(body, /credentials/)
  assert.match(body, /deepseek-v4-flash/)
  assert.match(body, /maskKey/)
  // The persistent host exposes the asset status over an HTTP route, not harness.handle.
  assert.match(body, /register/)
  assert.match(body, /__sakura_live2d/)
  assert.doesNotMatch(body, /harness\.handle/)
})

test('host module rejects manifest paths outside the install directory', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'sakura-host-'))
  const manifestPath = join(dir, 'manifest.json')
  await writeFile(
    manifestPath,
    JSON.stringify({
      sdkVersion: '5-r.5',
      model: 'Hiyori',
      files: { secret: { path: '../secret', size: 1 } },
    }),
  )
  await assert.rejects(
    () => buildHostModule({ manifestPath, write: false }),
    /outside the install directory/,
  )
})

test('client bundle registers a __ModuleLoader__ module with named exports', async () => {
  const body = await buildClientBundle({ write: false })
  assert.match(body, /window\.__ModuleLoader__\.load\(\{/)
  assert.match(body, /id: "dsh-hiyori-web-ui"/)
  assert.match(body, /require\("react"\)/)
  assert.match(body, /\["slots", "sessions", "timer", "theme"\]/)
  assert.match(body, /exports\.apply|apply: \(\) => apply/)
  // The persistent client fetches status over HTTP and injects style tags,
  // so the dynamic-only seats must be gone.
  assert.match(body, /fetch\(/)
  assert.match(body, /__sakura_live2d/)
  assert.match(body, /data-plugin/)
  assert.doesNotMatch(body, /styles\.insert/)
  assert.doesNotMatch(body, /host\.call/)
  assert.doesNotMatch(body, /SakuraVnClient/)
  assert.doesNotMatch(body, /^\s*import\s/m)
})

test('client bundle bundles the character overlay and settings surface', async () => {
  const body = await buildClientBundle({ write: false })
  assert.match(body, /sakura-vn-character/)
  assert.match(body, /虚拟角色/)
  assert.match(body, /桃濑日和/)
  assert.match(body, /gal-character-frame-host/)
  assert.match(body, /sakura-vn-personality-v1/)
  assert.match(body, /DeepSeek API Key/)
  assert.match(body, /deepseek-v4-flash/)
  assert.match(body, /chat-config/)
  assert.match(body, /sakura-vn-model-v1/)
  assert.match(body, /保存失败：后端未就绪/)
  assert.match(body, /chatMasked/)
  assert.match(body, /配置后日和的性格更加鲜明/)
  assert.match(body, /桃濑日和配置/)
  assert.match(body, /settings\.section/)
  assert.match(body, /gal-hiyori-row/)
  assert.doesNotMatch(body, /settings\.general\.item/)
  assert.doesNotMatch(body, /Mao/)
})

test('client bundle bundles the longrun tiered copy', async () => {
  const body = await buildClientBundle({ write: false })
  assert.match(body, /马拉松模式/)
  assert.match(body, /没跑路/)
})

test('bundle patch declares its row under insert, not as an id-override', async () => {
  const patch = await readFile(join(ROOT, 'cordis.patch.yml'), 'utf8')
  assert.match(patch, /insert:/)
  assert.match(patch, /id: hiyori-web-ui/)
  assert.match(patch, /name: dsh-hiyori-web-ui/)
})
