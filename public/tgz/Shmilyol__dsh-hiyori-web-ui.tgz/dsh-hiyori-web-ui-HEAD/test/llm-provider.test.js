import assert from 'node:assert/strict'
import test from 'node:test'
import { createLlmProvider, loadModelPreference, saveModelPreference } from '../src/client/llm-provider.js'

const SAY = '/__sakura_live2d/say'

test('say posts model + messages and returns the text', async () => {
  let captured
  const fetchImpl = async (url, options) => {
    captured = { url, options }
    return { ok: true, json: async () => ({ ok: true, text: '模型台词' }) }
  }
  const provider = createLlmProvider({ fetchImpl, sayPath: SAY, timeoutMs: 5000 })
  const text = await provider.say({ event: 'complete', personality: 'gentle', vars: {}, model: 'deepseek-v4-flash' })
  assert.equal(text, '模型台词')
  assert.equal(captured.url, SAY)
  assert.equal(captured.options.method, 'POST')
  const body = JSON.parse(captured.options.body)
  assert.equal(body.model, 'deepseek-v4-flash')
  assert.equal(body.messages.length, 2)
})

test('say returns null on a non-ok response', async () => {
  const fetchImpl = async () => ({ ok: false, status: 502, json: async () => ({}) })
  const provider = createLlmProvider({ fetchImpl, timeoutMs: 5000 })
  assert.equal(await provider.say({ event: 'error', personality: 'gentle', vars: {}, model: 'x' }), null)
})

test('say returns null on a network error', async () => {
  const fetchImpl = async () => { throw new Error('offline') }
  const provider = createLlmProvider({ fetchImpl, timeoutMs: 5000 })
  assert.equal(await provider.say({ event: 'error', personality: 'gentle', vars: {}, model: 'x' }), null)
})

test('say returns null after the timeout aborts the request', async () => {
  const fetchImpl = async (url, options) => new Promise((_, reject) => {
    options.signal.addEventListener('abort', () => reject(new Error('aborted')))
  })
  const provider = createLlmProvider({ fetchImpl, timeoutMs: 20 })
  assert.equal(await provider.say({ event: 'error', personality: 'gentle', vars: {}, model: 'x' }), null)
})

test('model preference persists and defaults to flash', () => {
  const values = new Map()
  const storage = {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
  }
  assert.equal(loadModelPreference(storage), 'deepseek-v4-flash')
  saveModelPreference(storage, 'deepseek-v4-pro')
  assert.equal(loadModelPreference(storage), 'deepseek-v4-pro')
})

test('say forwards recent lines into the messages', async () => {
  let captured
  const fetchImpl = async (url, options) => {
    captured = options
    return { ok: true, json: async () => ({ ok: true, text: 'x' }) }
  }
  const provider = createLlmProvider({ fetchImpl, timeoutMs: 5000 })
  await provider.say({ event: 'complete', personality: 'gentle', vars: {}, model: 'deepseek-v4-flash', recent: ['上一句'] })
  const body = JSON.parse(captured.body)
  assert.match(body.messages[1].content, /最近说过/)
  assert.match(body.messages[1].content, /上一句/)
})
