import assert from 'node:assert/strict'
import test from 'node:test'
import {
  EVENT_RULES,
  PERSONALITIES,
  PERSONALITY_KEY,
  PERSONALITY_LINES,
  loadPersonalityPreference,
  longrunTier,
  normalizePersonality,
  rulesFor,
  savePersonalityPreference,
  streakTier,
} from '../src/client/personalities.js'

const EVENT_IDS = [
  'error', 'body', 'complete', 'streak', 'loading', 'longrun', 'session',
  'morning', 'daytime', 'evening', 'idle', 'switch',
]

test('exposes five personalities with gentle first as the default', () => {
  assert.deepEqual(PERSONALITIES.map((personality) => personality.id), ['gentle', 'tsundere', 'obedient', 'genki', 'lazy'])
  assert.deepEqual(PERSONALITIES.map((personality) => personality.label), ['温柔', '傲娇', '乖巧', '元气', '慵懒'])
})

test('every personality fills a non-empty line list for every event', () => {
  for (const personality of PERSONALITIES) {
    for (const id of EVENT_IDS) {
      const lines = PERSONALITY_LINES[personality.id][id]
      if (id === 'streak') {
        assert.deepEqual(Object.keys(lines), ['first', 'hot', 'big', 'legend'], `${personality.id}.streak`)
        for (const tierLines of Object.values(lines)) {
          assert.ok(Array.isArray(tierLines) && tierLines.length > 0, `${personality.id}.streak tier`)
          assert.ok(tierLines.every((line) => typeof line === 'string' && line.length > 0))
        }
      } else if (id === 'longrun') {
        assert.deepEqual(Object.keys(lines), ['start', 'warm', 'deep', 'marathon', 'grind'], `${personality.id}.longrun`)
        for (const tierLines of Object.values(lines)) {
          assert.ok(Array.isArray(tierLines) && tierLines.length > 0, `${personality.id}.longrun tier`)
          assert.ok(tierLines.every((line) => typeof line === 'string' && line.length > 0))
        }
      } else {
        assert.ok(Array.isArray(lines) && lines.length > 0, `${personality.id}.${id}`)
        assert.ok(lines.every((line) => typeof line === 'string' && line.length > 0))
      }
    }
  }
})

test('rulesFor preserves rule structure and maps the personality lines', () => {
  const rules = rulesFor('tsundere')
  assert.equal(rules.length, EVENT_RULES.length)
  for (const rule of rules) {
    const structure = EVENT_RULES.find((entry) => entry.id === rule.id)
    assert.equal(rule.event, structure.event)
    assert.equal(rule.priority, structure.priority)
    assert.equal(rule.cooldownMs, structure.cooldownMs)
    assert.equal(rule.durationMs, structure.durationMs)
    if (rule.id === 'streak' || rule.id === 'longrun') {
      assert.equal(typeof rule.lines, 'function')
    } else {
      assert.deepEqual(rule.lines, PERSONALITY_LINES.tsundere[rule.id])
    }
  }
})

test('rulesFor does not route the switch confirmation through the engine', () => {
  for (const personality of PERSONALITIES) {
    const rules = rulesFor(personality.id)
    assert.ok(rules.every((rule) => rule.id !== 'switch'))
  }
})

test('unknown personalities fall back to gentle', () => {
  assert.equal(normalizePersonality('gentle'), 'gentle')
  assert.equal(normalizePersonality('tsundere'), 'tsundere')
  assert.equal(normalizePersonality('unknown'), 'gentle')
  assert.equal(normalizePersonality(undefined), 'gentle')
  assert.equal(normalizePersonality(null), 'gentle')
})

test('flipped task-status events have at least two lines per personality', () => {
  for (const personality of PERSONALITIES) {
    for (const id of ['complete', 'error', 'loading', 'session']) {
      assert.ok(PERSONALITY_LINES[personality.id][id].length >= 2, `${personality.id}.${id}`)
    }
  }
})

test('task-status lines speak in the agent first person', () => {
  assert.ok(PERSONALITY_LINES.gentle.complete.some((line) => line.includes('我完成')))
  assert.ok(PERSONALITY_LINES.gentle.error.some((line) => line.includes('我')))
  assert.ok(PERSONALITY_LINES.gentle.loading.some((line) => line.includes('我')))
  assert.ok(PERSONALITY_LINES.gentle.session.some((line) => line.includes('我')))
})

test('streakTier maps milestone counts to tiers', () => {
  assert.equal(streakTier(3), 'first')
  assert.equal(streakTier(5), 'hot')
  assert.equal(streakTier(10), 'big')
  assert.equal(streakTier(15), 'legend')
  assert.equal(streakTier(20), 'legend')
  assert.equal(streakTier(25), 'legend')
  assert.equal(streakTier(0), undefined)
  assert.equal(streakTier(1), undefined)
  assert.equal(streakTier(2), undefined)
  assert.equal(streakTier(4), undefined)
  assert.equal(streakTier(6), undefined)
  assert.equal(streakTier(11), undefined)
})

test('rulesFor streak resolver picks the tier lines for a milestone count', () => {
  const rules = rulesFor('gentle')
  const streakRule = rules.find((rule) => rule.id === 'streak')
  assert.deepEqual(streakRule.lines({ n: 3 }), PERSONALITY_LINES.gentle.streak.first)
  assert.deepEqual(streakRule.lines({ n: 10 }), PERSONALITY_LINES.gentle.streak.big)
  assert.deepEqual(streakRule.lines({ n: 20 }), PERSONALITY_LINES.gentle.streak.legend)
})

test('longrunTier maps elapsed durations to tiers', () => {
  assert.equal(longrunTier(20000), 'start')
  assert.equal(longrunTier(60000), 'warm')
  assert.equal(longrunTier(120000), 'deep')
  assert.equal(longrunTier(240000), 'marathon')
  assert.equal(longrunTier(360000), 'grind')
  assert.equal(longrunTier(480000), 'grind')
  assert.equal(longrunTier(19999), undefined)
  assert.equal(longrunTier(0), undefined)
})

test('rulesFor longrun resolver picks the tier lines for an elapsed duration', () => {
  const rules = rulesFor('gentle')
  const longrunRule = rules.find((rule) => rule.id === 'longrun')
  assert.deepEqual(longrunRule.lines({ elapsed: 60000 }), PERSONALITY_LINES.gentle.longrun.warm)
  assert.deepEqual(longrunRule.lines({ elapsed: 240000 }), PERSONALITY_LINES.gentle.longrun.marathon)
  assert.deepEqual(longrunRule.lines({ elapsed: 360000 }), PERSONALITY_LINES.gentle.longrun.grind)
})

test('persists only the personality id and falls back on failures', () => {
  const values = new Map()
  const storage = {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
  }
  assert.equal(loadPersonalityPreference(storage), 'gentle')
  savePersonalityPreference(storage, 'genki')
  assert.equal(loadPersonalityPreference(storage), 'genki')
  assert.deepEqual([...values.keys()], [PERSONALITY_KEY])
  const broken = {
    getItem() { throw new Error('blocked') },
    setItem() { throw new Error('blocked') },
  }
  assert.equal(loadPersonalityPreference(broken), 'gentle')
  assert.doesNotThrow(() => savePersonalityPreference(broken, 'lazy'))
})
