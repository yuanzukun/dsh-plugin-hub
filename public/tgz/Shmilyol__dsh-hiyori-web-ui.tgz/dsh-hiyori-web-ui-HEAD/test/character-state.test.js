import assert from 'node:assert/strict'
import test from 'node:test'
import {
  initialCharacterState,
  reduceCharacterState,
} from '../src/client/character-state.js'

test('hide keeps only the restore affordance state', () => {
  assert.deepEqual(
    reduceCharacterState(
      { ...initialCharacterState, bubble: { text: 'hello' } },
      { type: 'hide' },
    ),
    { ...initialCharacterState, hidden: true, bubble: null },
  )
})

test('the settings switch removes actor and restore state', () => {
  assert.deepEqual(
    reduceCharacterState(
      { ...initialCharacterState, hidden: true, bubble: { text: 'hello' } },
      { type: 'disable' },
    ),
    {
      ...initialCharacterState,
      enabled: false,
      hidden: false,
      bubble: null,
    },
  )
})

test('runtime error retains the generic code only', () => {
  const state = reduceCharacterState(initialCharacterState, {
    type: 'error',
    code: 'webgl-unavailable',
  })
  assert.equal(state.ready, false)
  assert.equal(state.error, 'webgl-unavailable')
})
