import assert from 'node:assert/strict'
import test from 'node:test'
import {
  ANTI_REPEAT_RULES,
  EVENT_CARDS,
  HARD_RULES,
  PERSONALITY_PROFILES,
  examplesFor,
} from '../src/client/dialogue-handbook.js'
import { PERSONALITY_LINES } from '../src/client/personalities.js'

const EVENT_KEYS = [
  'error', 'body-click', 'complete', 'streak', 'loading', 'longrun', 'session',
  'greeting-morning', 'greeting-daytime', 'greeting-evening', 'idle', 'switch',
]

test('every personality has a full profile', () => {
  for (const id of Object.keys(PERSONALITY_LINES)) {
    const p = PERSONALITY_PROFILES[id]
    assert.ok(p, `missing profile for ${id}`)
    assert.ok(p.label.length > 0)
    assert.ok(p.voice.length > 0)
    assert.ok(Array.isArray(p.tics) && p.tics.length > 0)
    assert.ok(p.attitude.length > 0)
    assert.ok(Array.isArray(p.avoids) && p.avoids.length > 0)
  }
})

test('every event has a summary and non-empty angles', () => {
  for (const event of EVENT_KEYS) {
    const card = EVENT_CARDS[event]
    assert.ok(card, `missing card for ${event}`)
    assert.ok(card.summary.length > 0)
    assert.ok(Array.isArray(card.angles) && card.angles.length > 0)
  }
})

test('examplesFor returns real local lines for a plain event', () => {
  const lines = examplesFor('gentle', 'complete', {})
  assert.deepEqual(lines, PERSONALITY_LINES.gentle.complete.slice(0, 2))
})

test('examplesFor maps body-click to the body lines', () => {
  assert.deepEqual(examplesFor('gentle', 'body-click', {}), PERSONALITY_LINES.gentle.body.slice(0, 2))
})

test('examplesFor resolves streak and longrun tiers', () => {
  assert.deepEqual(examplesFor('gentle', 'streak', { n: 15 }), PERSONALITY_LINES.gentle.streak.legend.slice(0, 2))
  assert.deepEqual(examplesFor('gentle', 'longrun', { elapsed: 120000 }), PERSONALITY_LINES.gentle.longrun.deep.slice(0, 2))
})

test('examplesFor returns [] for an unknown event', () => {
  assert.deepEqual(examplesFor('gentle', 'mystery', {}), [])
})

test('handbook exports the hard and anti-repeat rules', () => {
  assert.ok(HARD_RULES.length > 0)
  assert.ok(ANTI_REPEAT_RULES.length > 0)
})
