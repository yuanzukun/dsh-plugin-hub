import assert from 'node:assert/strict'
import test from 'node:test'
import { createCharacterController } from '../src/client/character-controller.js'
import { PERSONALITY_LINES } from '../src/client/personalities.js'

function createClock() {
  let now = 0
  let nextId = 1
  const tasks = new Map()
  return {
    now: () => now,
    timeout(callback, delay) {
      const id = nextId
      nextId += 1
      tasks.set(id, { at: now + delay, callback })
      return () => tasks.delete(id)
    },
    advance(milliseconds) {
      const target = now + milliseconds
      while (true) {
        const due = [...tasks.entries()]
          .filter(([, task]) => task.at <= target)
          .sort((left, right) => left[1].at - right[1].at)[0]
        if (!due) break
        const [id, task] = due
        tasks.delete(id)
        now = task.at
        task.callback()
      }
      now = target
    },
    pending: () => tasks.size,
  }
}

test('applies delayed loading, click, completion and error priority', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })

  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  clock.advance(799)
  assert.equal(bubbles.length, 0)
  clock.advance(1)
  assert.equal(bubbles.at(-1).ruleId, 'loading')

  controller.runtimeHit('Body')
  assert.equal(bubbles.at(-1).ruleId, 'body')

  controller.sessionSnapshot({
    running: false,
    promptError: new Error('private text'),
    turnEnds: new Map([[1, 800]]),
  })
  assert.equal(bubbles.at(-1).ruleId, 'error')
  assert.doesNotMatch(JSON.stringify(bubbles), /private text/)
})

test('runtime ready greets once for the local time period', () => {
  const clock = createClock()
  const bubbles = []
  const morning = new Date(2026, 7, 14, 8, 0, 0).getTime()
  const controller = createCharacterController({
    timer: clock,
    now: () => morning,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.runtimeReady()
  controller.runtimeReady()
  assert.deepEqual(bubbles.map((bubble) => bubble.ruleId), ['morning'])
})

test('pointer activity postpones idle and idle repeats no sooner than ten minutes', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.pointerActivity()
  clock.advance(179999)
  assert.equal(bubbles.length, 0)
  controller.pointerActivity()
  clock.advance(180000)
  assert.equal(bubbles.at(-1).ruleId, 'idle')
  const count = bubbles.length
  clock.advance(599999)
  assert.equal(bubbles.length, count)
  clock.advance(1)
  assert.equal(bubbles.length, count + 1)
})

test('destroy cancels loading, idle and bubble timers idempotently', () => {
  const clock = createClock()
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble() {},
    dismissBubble() {},
  })
  controller.pointerActivity()
  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  controller.runtimeHit('Body')
  assert.ok(clock.pending() > 0)
  controller.destroy()
  controller.destroy()
  assert.equal(clock.pending(), 0)
})

test('runtime ready schedules random interaction motions until destroyed', () => {
  const clock = createClock()
  const motions = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble() {},
    dismissBubble() {},
    playMotion: (id) => motions.push(id),
  })
  controller.runtimeReady()
  assert.deepEqual(motions, [])
  clock.advance(12000)
  assert.deepEqual(motions, ['Tap'])
  clock.advance(12000)
  assert.deepEqual(motions, ['Tap', 'Tap'])
  const count = motions.length
  controller.destroy()
  clock.advance(12000)
  assert.equal(motions.length, count)
})

test('user dismissal clears the active bubble and its timer', () => {
  const clock = createClock()
  let dismissals = 0
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble() {},
    dismissBubble: () => {
      dismissals += 1
    },
  })
  controller.runtimeHit('Body')
  controller.dismiss()
  assert.equal(dismissals, 1)
  assert.equal(clock.pending(), 1)
})

test('runtime failures use the same generic error bubble', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.runtimeError()
  assert.equal(bubbles.at(-1).ruleId, 'error')
})

test('changing sessions cancels pending state and does not complete the previous session', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })

  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  controller.sessionChanged()
  controller.sessionSnapshot({ running: false, turnEnds: new Map() })
  clock.advance(800)

  assert.deepEqual(bubbles, [])
})

test('only body clicks trigger Tap@Body with a one-second action cooldown', () => {
  const clock = createClock()
  const motions = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble() {},
    dismissBubble() {},
    playMotion: (id) => motions.push(id),
  })

  assert.equal(controller.runtimeHit('Head'), false)
  assert.equal(controller.runtimeHit('Body'), true)
  assert.equal(controller.runtimeHit('Body'), false)
  clock.advance(1000)
  assert.equal(controller.runtimeHit('Body'), true)

  assert.deepEqual(motions, ['Tap@Body', 'Tap@Body'])
})

test('a higher-priority error bubble does not block an accepted body action', () => {
  const clock = createClock()
  const motions = []
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
    playMotion: (id) => motions.push(id),
  })

  controller.runtimeError()
  assert.equal(controller.runtimeHit('Body'), true)
  assert.equal(controller.runtimeHit('Body'), false)

  assert.deepEqual(motions, ['FlickDown', 'Tap@Body'])
  assert.deepEqual(bubbles.map((bubble) => bubble.ruleId), ['error'])
})

test('completion plays a light interaction motion', () => {
  const clock = createClock()
  const motions = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble() {},
    dismissBubble() {},
    playMotion: (id) => motions.push(id),
  })
  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  controller.sessionSnapshot({ running: false, turnEnds: new Map([[1, 1]]) })
  assert.deepEqual(motions, ['Tap'])
})

test('an active error bubble suppresses the completion line and its motion', () => {
  const clock = createClock()
  const motions = []
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
    playMotion: (id) => motions.push(id),
  })

  controller.runtimeError()
  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  controller.sessionSnapshot({ running: false, turnEnds: new Map([[1, 1]]) })

  assert.deepEqual(motions, ['FlickDown'])
  assert.deepEqual(bubbles.map((bubble) => bubble.ruleId), ['error'])
})

test('a fresh controller in a switched session says the session line instead of greeting', () => {
  const clock = createClock()
  const bubbles = []
  const morning = new Date(2026, 7, 14, 8, 0, 0).getTime()
  const controller = createCharacterController({
    timer: clock,
    now: () => morning,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.sessionSwitched(true)
  controller.runtimeReady()
  controller.runtimeReady()
  assert.equal(bubbles.at(-1).ruleId, 'session')
  assert.ok(PERSONALITY_LINES.gentle.session.includes(bubbles.at(-1).text))
})

test('a live session switch after ready emits the session line immediately', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.runtimeReady()
  const before = bubbles.length
  controller.sessionSwitched(true)
  assert.equal(bubbles.length, before + 1)
  assert.equal(bubbles.at(-1).ruleId, 'session')
})

test('sessionSwitched without a real switch is a no-op', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.runtimeReady()
  const before = bubbles.length
  controller.sessionSwitched(false)
  assert.equal(bubbles.length, before)
})

test('an errored completion never plays the success motion', () => {
  const clock = createClock()
  const motions = []
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
    playMotion: (id) => motions.push(id),
  })
  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  controller.sessionSnapshot({
    running: false,
    promptError: new Error('private'),
    turnEnds: new Map([[1, 1]]),
  })
  assert.deepEqual(motions, ['FlickDown'])
  assert.equal(bubbles.at(-1).ruleId, 'error')
})

test('uses the configured initial personality for dialogue', () => {
  const clock = createClock()
  const bubbles = []
  const morning = new Date(2026, 7, 14, 8, 0, 0).getTime()
  const controller = createCharacterController({
    timer: clock,
    now: () => morning,
    random: () => 0,
    personality: 'tsundere',
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.runtimeReady()
  assert.equal(bubbles.at(-1).ruleId, 'morning')
  assert.ok(PERSONALITY_LINES.tsundere.morning.includes(bubbles.at(-1).text))
})

test('setPersonality swaps rules and announces in the new personality', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.setPersonality('genki')
  assert.equal(bubbles.at(-1).ruleId, 'switch')
  assert.ok(PERSONALITY_LINES.genki.switch.includes(bubbles.at(-1).text))
  controller.runtimeHit('Body')
  assert.ok(PERSONALITY_LINES.genki.body.includes(bubbles.at(-1).text))
})

test('setPersonality is idempotent for the current personality', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    personality: 'lazy',
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.setPersonality('lazy')
  assert.deepEqual(bubbles, [])
})

test('setPersonality after destroy is a no-op', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.destroy()
  controller.setPersonality('genki')
  assert.deepEqual(bubbles, [])
})

test('setPersonality without announce still swaps the dialogue', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.setPersonality('obedient', { announce: false })
  assert.deepEqual(bubbles, [])
  controller.runtimeHit('Body')
  assert.ok(PERSONALITY_LINES.obedient.body.includes(bubbles.at(-1).text))
})

test('rapid personality switches announce only once', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.setPersonality('genki')
  controller.setPersonality('lazy')
  assert.equal(bubbles.filter((bubble) => bubble.ruleId === 'switch').length, 1)
  controller.runtimeHit('Body')
  assert.ok(PERSONALITY_LINES.lazy.body.includes(bubbles.at(-1).text))
})

function completeTurn(controller, clock) {
  clock.advance(5001)
  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  controller.sessionSnapshot({ running: false, turnEnds: new Map([[1, 1]]) })
}

test('milestone completions emit a tiered streak bubble instead of complete', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  completeTurn(controller, clock)
  assert.equal(bubbles.at(-1).ruleId, 'complete')
  completeTurn(controller, clock)
  assert.equal(bubbles.at(-1).ruleId, 'complete')
  completeTurn(controller, clock)
  assert.equal(bubbles.at(-1).ruleId, 'streak')
  assert.equal(bubbles.at(-1).text, PERSONALITY_LINES.gentle.streak.first[0])
})

test('an error resets the streak count', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  completeTurn(controller, clock)
  completeTurn(controller, clock)
  completeTurn(controller, clock)
  assert.equal(bubbles.at(-1).ruleId, 'streak')
  clock.advance(5001)
  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  controller.sessionSnapshot({ running: false, promptError: new Error('x'), turnEnds: new Map([[1, 1]]) })
  assert.equal(bubbles.at(-1).ruleId, 'error')
  clock.advance(6000)
  completeTurn(controller, clock)
  assert.equal(bubbles.at(-1).ruleId, 'complete')
})

test('switching sessions resets the streak count', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  completeTurn(controller, clock)
  completeTurn(controller, clock)
  controller.sessionChanged()
  completeTurn(controller, clock)
  assert.equal(bubbles.at(-1).ruleId, 'complete')
})

test('streak legend lines render the actual streak count', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  for (let i = 0; i < 15; i += 1) {
    completeTurn(controller, clock)
  }
  assert.equal(bubbles.at(-1).ruleId, 'streak')
  assert.equal(bubbles.at(-1).text, '连续 15 次，连我自己都有点佩服自己了。')
})

function createRecordedController() {
  const clock = createClock()
  const bubbles = []
  const motions = []
  const expressions = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
    playMotion: (id) => motions.push(id),
    playExpression: (id) => expressions.push(id),
  })
  return { clock, controller, bubbles, motions, expressions }
}

test('complete motion and expression follow the personality', () => {
  const gentle = createRecordedController()
  completeTurn(gentle.controller, gentle.clock)
  assert.deepEqual(gentle.motions, ['Tap'])
  assert.deepEqual(gentle.expressions, ['joy'])

  const tsun = createRecordedController()
  tsun.controller.setPersonality('tsundere', { announce: false })
  completeTurn(tsun.controller, tsun.clock)
  assert.deepEqual(tsun.motions, ['Flick'])
  assert.deepEqual(tsun.expressions, ['proud', 'proud'])

  const lazy = createRecordedController()
  lazy.controller.setPersonality('lazy', { announce: false })
  completeTurn(lazy.controller, lazy.clock)
  assert.deepEqual(lazy.motions, ['FlickDown'])
  assert.deepEqual(lazy.expressions, ['sleepy', 'sleepy'])
})

test('error motion and expression follow the personality', () => {
  const gentle = createRecordedController()
  gentle.controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  gentle.controller.sessionSnapshot({ running: false, promptError: new Error('x'), turnEnds: new Map([[1, 1]]) })
  assert.deepEqual(gentle.motions, ['FlickDown'])
  assert.deepEqual(gentle.expressions, ['sad'])

  const tsun = createRecordedController()
  tsun.controller.setPersonality('tsundere', { announce: false })
  tsun.controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  tsun.controller.sessionSnapshot({ running: false, promptError: new Error('x'), turnEnds: new Map([[1, 1]]) })
  assert.deepEqual(tsun.motions, ['Flick'])
  assert.deepEqual(tsun.expressions, ['proud', 'angry'])
})

test('a milestone streak uses the rising context motion and expression', () => {
  const c = createRecordedController()
  completeTurn(c.controller, c.clock)
  completeTurn(c.controller, c.clock)
  completeTurn(c.controller, c.clock)
  assert.equal(c.bubbles.at(-1).ruleId, 'streak')
  assert.deepEqual(c.motions.at(-1), 'FlickUp')
  assert.deepEqual(c.expressions.at(-1), 'joy')
})

test('a completion right after an error uses the recovered context', () => {
  const c = createRecordedController()
  c.controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  c.controller.sessionSnapshot({ running: false, promptError: new Error('x'), turnEnds: new Map([[1, 1]]) })
  c.clock.advance(6000)
  completeTurn(c.controller, c.clock)
  assert.equal(c.bubbles.at(-1).ruleId, 'complete')
  assert.deepEqual(c.motions.at(-1), 'Flick')
  assert.deepEqual(c.expressions.at(-1), 'relief')
})

test('loading plays the working motion and expression', () => {
  const c = createRecordedController()
  c.controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  c.clock.advance(800)
  assert.equal(c.bubbles.at(-1).ruleId, 'loading')
  assert.deepEqual(c.motions, ['Flick'])
  assert.deepEqual(c.expressions, [])
})

test('setPersonality replays the new personality motion and expression', () => {
  const lazy = createRecordedController()
  lazy.controller.setPersonality('lazy')
  assert.deepEqual(lazy.motions, ['FlickDown'])
  assert.deepEqual(lazy.expressions, ['sleepy'])

  const genki = createRecordedController()
  genki.controller.setPersonality('genki')
  assert.deepEqual(genki.motions, ['FlickUp'])
  assert.deepEqual(genki.expressions, ['joy'])

  const tsundere = createRecordedController()
  tsundere.controller.setPersonality('tsundere')
  assert.deepEqual(tsundere.motions, ['Flick'])
  assert.deepEqual(tsundere.expressions, ['proud'])
})

test('setPersonality without announce still applies the base expression', () => {
  const c = createRecordedController()
  c.controller.setPersonality('lazy', { announce: false })
  assert.deepEqual(c.motions, [])
  assert.deepEqual(c.expressions, ['sleepy'])
  c.controller.runtimeHit('Body')
  assert.ok(PERSONALITY_LINES.lazy.body.includes(c.bubbles.at(-1).text))
})

test('runtime ready applies the personality base expression', () => {
  const c = createRecordedController()
  c.controller.runtimeReady()
  assert.deepEqual(c.expressions, ['joy'])
})

test('idle random motion comes from the current personality pool', () => {
  const lazy = createRecordedController()
  lazy.controller.setPersonality('lazy', { announce: false })
  lazy.motions.length = 0
  lazy.expressions.length = 0
  lazy.controller.runtimeReady()
  lazy.clock.advance(12000)
  assert.deepEqual(lazy.motions, ['FlickDown'])
})

test('event expression falls back to the base expression when the bubble expires', () => {
  const c = createRecordedController()
  c.controller.setPersonality('tsundere', { announce: false })
  c.expressions.length = 0
  c.controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  c.controller.sessionSnapshot({ running: false, promptError: new Error('x'), turnEnds: new Map([[1, 1]]) })
  assert.deepEqual(c.expressions, ['angry'])
  c.clock.advance(6000)
  assert.deepEqual(c.expressions, ['angry', 'proud'])
})

function longrunBubbles(bubbles) {
  return bubbles.filter((bubble) => bubble.ruleId === 'longrun')
}

test('a long-running turn emits tiered longrun lines at each milestone', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  clock.advance(20000)
  assert.ok(PERSONALITY_LINES.gentle.longrun.start.includes(longrunBubbles(bubbles).at(-1).text))
  clock.advance(40000)
  assert.ok(PERSONALITY_LINES.gentle.longrun.warm.includes(longrunBubbles(bubbles).at(-1).text))
  clock.advance(60000)
  assert.ok(PERSONALITY_LINES.gentle.longrun.deep.includes(longrunBubbles(bubbles).at(-1).text))
  clock.advance(120000)
  assert.ok(PERSONALITY_LINES.gentle.longrun.marathon.includes(longrunBubbles(bubbles).at(-1).text))
  clock.advance(120000)
  assert.ok(PERSONALITY_LINES.gentle.longrun.grind.includes(longrunBubbles(bubbles).at(-1).text))
})

test('completing the turn cancels pending longrun lines', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  clock.advance(10000)
  controller.sessionSnapshot({ running: false, turnEnds: new Map([[1, 1]]) })
  clock.advance(30000)
  assert.equal(longrunBubbles(bubbles).length, 0)
})

test('changing sessions cancels pending longrun lines', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  controller.sessionChanged()
  clock.advance(30000)
  assert.equal(longrunBubbles(bubbles).length, 0)
})

test('a new turn while still running restarts the longrun milestones', () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.sessionSnapshot({
    running: true,
    turnEnds: new Map(),
    turnTimings: new Map([[1, { startTime: 0 }]]),
  })
  clock.advance(20000)
  assert.equal(longrunBubbles(bubbles).length, 1)
  assert.ok(PERSONALITY_LINES.gentle.longrun.start.includes(longrunBubbles(bubbles).at(-1).text))

  // A second turn begins without `running` dipping false (multi-turn kick or a
  // coalesced idle frame): longrun must restart at the new turn's 20s milestone.
  controller.sessionSnapshot({
    running: true,
    turnEnds: new Map(),
    turnTimings: new Map([
      [1, { startTime: 0, endTime: 20000 }],
      [2, { startTime: 20000 }],
    ]),
  })
  clock.advance(20000)
  assert.equal(longrunBubbles(bubbles).length, 2)
  assert.ok(PERSONALITY_LINES.gentle.longrun.start.includes(longrunBubbles(bubbles).at(-1).text))
})

test('longrun plays the personality signature motion and stage expression', () => {
  const gentle = createRecordedController()
  gentle.controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  gentle.clock.advance(120000)
  assert.equal(gentle.bubbles.at(-1).ruleId, 'longrun')
  assert.deepEqual(gentle.motions.at(-1), 'Tap')
  assert.deepEqual(gentle.expressions.at(-1), 'relief')

  const tsun = createRecordedController()
  tsun.controller.setPersonality('tsundere', { announce: false })
  tsun.controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  tsun.clock.advance(120000)
  assert.deepEqual(tsun.motions.at(-1), 'Flick')
  assert.deepEqual(tsun.expressions.at(-1), 'angry')

  const genki = createRecordedController()
  genki.controller.setPersonality('genki', { announce: false })
  genki.controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  genki.clock.advance(240000)
  assert.deepEqual(genki.motions.at(-1), 'FlickUp')
  assert.deepEqual(genki.expressions.at(-1), 'proud')

  const lazy = createRecordedController()
  lazy.controller.setPersonality('lazy', { announce: false })
  lazy.controller.sessionSnapshot({ running: true, turnEnds: new Map() })
  lazy.clock.advance(20000)
  assert.deepEqual(lazy.motions.at(-1), 'FlickDown')
  assert.deepEqual(lazy.expressions.at(-1), 'sleepy')
})

test('model path shows a thinking bubble then replaces it with the model text', async () => {
  const clock = createClock()
  const bubbles = []
  let resolveSay
  const llmSay = () => new Promise((resolve) => { resolveSay = resolve })
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    llmSay,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.runtimeHit('Body')
  assert.equal(bubbles.at(-1).text, '……')
  resolveSay('模型台词')
  await Promise.resolve()
  assert.equal(bubbles.at(-1).ruleId, 'body')
  assert.equal(bubbles.at(-1).text, '模型台词')
})

test('model failure falls back to the local line', async () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    llmSay: async () => null,
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.runtimeHit('Body')
  await Promise.resolve()
  assert.equal(bubbles.at(-1).ruleId, 'body')
  assert.ok(PERSONALITY_LINES.gentle.body.includes(bubbles.at(-1).text))
})

test('a newer event supersedes an in-flight model response', async () => {
  const clock = createClock()
  const bubbles = []
  const pending = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    llmSay: () => new Promise((resolve) => pending.push(resolve)),
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.runtimeHit('Body')
  clock.advance(1001)
  controller.runtimeHit('Body')
  pending[1]('新台词')
  await Promise.resolve()
  assert.equal(bubbles.at(-1).text, '新台词')
  pending[0]('旧台词')
  await Promise.resolve()
  assert.equal(bubbles.at(-1).text, '新台词')
})

test('setModel updates the model used by later model calls', async () => {
  const clock = createClock()
  const seen = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    llmSay: async (request) => { seen.push(request.model); return 'x' },
    showBubble() {},
    dismissBubble() {},
  })
  controller.setModel('deepseek-v4-pro')
  controller.runtimeHit('Body')
  await Promise.resolve()
  assert.deepEqual(seen, ['deepseek-v4-pro'])
})

test('model rejection falls back to the local line', async () => {
  const clock = createClock()
  const bubbles = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    llmSay: async () => { throw new Error('boom') },
    showBubble: (bubble) => bubbles.push(bubble),
    dismissBubble() {},
  })
  controller.runtimeHit('Body')
  await Promise.resolve()
  assert.equal(bubbles.at(-1).ruleId, 'body')
  assert.ok(PERSONALITY_LINES.gentle.body.includes(bubbles.at(-1).text))
})

test('a superseded model request is aborted', async () => {
  const clock = createClock()
  const signals = []
  const controller = createCharacterController({
    timer: clock,
    now: clock.now,
    random: () => 0,
    llmSay: (request) => { signals.push(request.signal); return new Promise(() => {}) },
    showBubble() {},
    dismissBubble() {},
  })
  controller.runtimeHit('Body')
  assert.equal(signals[0].aborted, false)
  clock.advance(1001)
  controller.runtimeHit('Body')
  assert.equal(signals[0].aborted, true)
  assert.equal(signals[1].aborted, false)
})
