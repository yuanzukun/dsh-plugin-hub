import assert from 'node:assert/strict'
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import test from 'node:test'
import {
  buildManifest,
  FRAMEWORK_ARCHIVE,
  FRAMEWORK_COMMIT,
  parseVendorArgs,
  publishAssets,
  SAMPLES_ARCHIVE,
  SAMPLES_COMMIT,
  validateHiyori,
  validateSdkArchiveName,
} from '../tools/vendor-live2d.mjs'

async function touch(root, relative, data = 'x') {
  const path = join(root, relative)
  await mkdir(dirname(path), { recursive: true })
  await writeFile(path, data)
}

test('requires explicit fixed-version SDK and Hiyori Pro inputs', () => {
  assert.deepEqual(parseVendorArgs([
    '--sdk-zip', '/downloads/CubismSdkForWeb-5-r.5.zip',
    '--hiyori-dir', '/downloads/hiyori_pro/runtime',
  ]), {
    sdkZip: '/downloads/CubismSdkForWeb-5-r.5.zip',
    hiyoriDir: '/downloads/hiyori_pro/runtime',
  })
  assert.throws(() => parseVendorArgs([]), /--sdk-zip/)
  assert.throws(() => parseVendorArgs(['--sdk-zip', '/tmp/sdk.zip']), /--hiyori-dir/)
  assert.throws(() => parseVendorArgs(['--accept-license']), /Unknown argument/)
})

test('pins official source archives to immutable release commits', () => {
  assert.match(SAMPLES_ARCHIVE, new RegExp(SAMPLES_COMMIT))
  assert.match(FRAMEWORK_ARCHIVE, new RegExp(FRAMEWORK_COMMIT))
  assert.doesNotMatch(SAMPLES_ARCHIVE, /refs\/tags/)
  assert.doesNotMatch(FRAMEWORK_ARCHIVE, /refs\/tags/)
})

test('rejects an SDK archive that is not labeled for 5-r.5', () => {
  assert.throws(
    () => validateSdkArchiveName('/downloads/CubismSdkForWeb-5-r.4.zip'),
    /5-r\.5/,
  )
  validateSdkArchiveName('/downloads/CubismSdkForWeb-5-r.5.zip')
})

test('validates every Hiyori Pro model reference', async () => {
  const root = await mkdtemp(join(tmpdir(), 'sakura-hiyori-'))
  await touch(root, 'hiyori_pro_t11.model3.json', JSON.stringify({
    FileReferences: {
      Moc: 'hiyori_pro_t11.moc3',
      Textures: ['hiyori_pro_t11.2048/texture_00.png', 'hiyori_pro_t11.2048/texture_01.png'],
      Motions: {
        Idle: Array.from({ length: 10 }, (_, index) => ({
          File: `motion/hiyori_m${String(index + 1).padStart(2, '0')}.motion3.json`,
        })),
      },
    },
    HitAreas: [{ Name: 'Body' }],
  }))
  await touch(root, 'hiyori_pro_t11.moc3')
  await touch(root, 'hiyori_pro_t11.2048/texture_00.png')
  await touch(root, 'hiyori_pro_t11.2048/texture_01.png')
  for (let index = 1; index <= 9; index += 1) {
    await touch(root, `motion/hiyori_m${String(index).padStart(2, '0')}.motion3.json`)
  }

  await assert.rejects(() => validateHiyori(root), /hiyori_m10/)
})

test('manifest includes only public files and labels the bundled Hiyori runtime', async () => {
  const root = await mkdtemp(join(tmpdir(), 'sakura-manifest-'))
  await touch(root, 'public/runtime/index.html', '<html></html>')
  await touch(root, 'licenses/Hiyori-Pro-ReadMe.txt', 'not served')
  const manifest = await buildManifest(root)
  assert.equal(manifest.sdkVersion, '5-r.5')
  assert.equal(manifest.model, 'Hiyori')
  assert.deepEqual(Object.keys(manifest.files), ['runtime/index.html'])
  assert.equal(manifest.files['runtime/index.html'].path, 'public/runtime/index.html')
  const onDisk = JSON.parse(await readFile(join(root, 'manifest.json'), 'utf8'))
  assert.deepEqual(onDisk, manifest)
})

test('publishes into a new parent and restores prior assets when publication fails', async () => {
  const root = await mkdtemp(join(tmpdir(), 'sakura-publish-'))
  const candidate = join(root, 'candidate')
  const output = join(root, 'nested', 'live2d')
  await touch(candidate, 'marker.txt', 'new')
  await publishAssets(candidate, output)
  assert.equal(await readFile(join(output, 'marker.txt'), 'utf8'), 'new')

  await assert.rejects(() => publishAssets(join(root, 'missing'), output))
  assert.equal(await readFile(join(output, 'marker.txt'), 'utf8'), 'new')
})
