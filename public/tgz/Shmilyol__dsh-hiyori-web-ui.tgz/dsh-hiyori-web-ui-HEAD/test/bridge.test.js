import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

test('bridge forwards expression messages as a runtime event', async () => {
  const [source, vendored] = await Promise.all([
    readFile('runtime/bridge/companion-bridge.js', 'utf8'),
    readFile('assets/live2d/public/runtime/companion-bridge.js', 'utf8'),
  ])
  assert.match(source, /message\.type === 'expression'/)
  assert.match(source, /sakura-expression/)
  assert.equal(source, vendored)
})
