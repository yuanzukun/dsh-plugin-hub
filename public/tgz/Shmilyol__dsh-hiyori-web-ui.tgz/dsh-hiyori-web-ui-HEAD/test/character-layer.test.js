import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'
import {
  gazeFromPointer,
  loadHiddenPreference,
  loadLastSession,
  saveHiddenPreference,
  saveLastSession,
} from '../src/client/character-layer.js'

test('maps horizontal gaze relative to the character anchor with a dead zone and asymmetric saturation', () => {
  const anchor = { left: 700, top: 700, width: 200, height: 200 }
  assert.deepEqual(gazeFromPointer(800, 800, 1000, 1000, anchor), { x: 0, y: 0 })
  assert.deepEqual(gazeFromPointer(820, 800, 1000, 1000, anchor), { x: 0, y: 0 })
  assert.deepEqual(gazeFromPointer(384, 800, 1000, 1000, anchor), { x: -0.5, y: 0 })
  assert.deepEqual(gazeFromPointer(916, 800, 1000, 1000, anchor), { x: 0.5, y: 0 })
  assert.deepEqual(gazeFromPointer(0, 800, 1000, 1000, anchor), { x: -1, y: 0 })
  assert.deepEqual(gazeFromPointer(1000, 800, 1000, 1000, anchor), { x: 1, y: 0 })
})

test('maps vertical gaze with screen-y inversion so upward is positive', () => {
  const anchor = { left: 700, top: 700, width: 200, height: 200 }
  assert.deepEqual(gazeFromPointer(800, 0, 1000, 1000, anchor), { x: 0, y: 1 })
  assert.deepEqual(gazeFromPointer(800, 384, 1000, 1000, anchor), { x: 0, y: 0.5 })
  assert.deepEqual(gazeFromPointer(800, 800, 1000, 1000, anchor), { x: 0, y: 0 })
  assert.deepEqual(gazeFromPointer(800, 916, 1000, 1000, anchor), { x: 0, y: -0.5 })
  assert.deepEqual(gazeFromPointer(800, 1000, 1000, 1000, anchor), { x: 0, y: -1 })
})

test('persists only the hidden boolean', () => {
  const values = new Map()
  const storage = {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
    removeItem: (key) => values.delete(key),
  }
  assert.equal(loadHiddenPreference(storage), false)
  saveHiddenPreference(storage, true)
  assert.equal(loadHiddenPreference(storage), true)
  assert.equal(values.size, 1)
})

test('persists the last session id and clears it when empty', () => {
  const values = new Map()
  const storage = {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
    removeItem: (key) => values.delete(key),
  }
  assert.equal(loadLastSession(storage), '')
  saveLastSession(storage, 'session-a')
  assert.equal(loadLastSession(storage), 'session-a')
  saveLastSession(storage, '')
  assert.equal(loadLastSession(storage), '')
  assert.equal(values.size, 0)
})

test('only one explicit Body region intercepts page clicks', async () => {
  const [layer, styles, template] = await Promise.all([
    readFile('src/client/character-layer.js', 'utf8'),
    readFile('src/client/styles.js', 'utf8'),
    readFile('tools/client-template.js', 'utf8'),
  ])
  assert.match(layer, /gal-character-hit gal-character-hit-body/)
  assert.doesNotMatch(layer, /hit-head|Head|expression|Mao/)
  assert.match(layer, /唤回日和/)
  assert.match(layer, /虚拟角色 桃濑日和/)
  assert.match(layer, /与桃濑日和互动/)
  assert.doesNotMatch(layer, /换动作|motionId|next-motion/)
  assert.match(styles, /\.gal-character-root\s*\{[\s\S]*?width: 280px;[\s\S]*?height: 250px;[\s\S]*?pointer-events: none/)
  assert.match(styles, /\.gal-character-stage[\s\S]*?pointer-events: none/)
  assert.match(styles, /\.gal-character-frame[\s\S]*?pointer-events: none/)
  assert.match(styles, /\.gal-character-hit-body[\s\S]*?pointer-events: auto/)
  assert.doesNotMatch(styles, /gal-character-hit-head/)
  assert.match(template, /右下角桃濑日和/)
  assert.doesNotMatch(template, /Mao/)
})

test('hover tools render above the Body hit target', async () => {
  const styles = await readFile('src/client/styles.js', 'utf8')
  assert.match(styles, /\.gal-character-tools\s*\{[\s\S]*?z-index: 2;/)
})

test('forwards personality to the layer and swaps it live', async () => {
  const layer = await readFile('src/client/character-layer.js', 'utf8')
  assert.match(layer, /personality/)
  assert.match(layer, /personalityRef/)
  assert.match(layer, /setPersonality/)
})

test('personality selector styles exist in the skin stylesheet', async () => {
  const styles = await readFile('src/client/styles.js', 'utf8')
  assert.match(styles, /\.gal-personality-chips/)
  assert.match(styles, /\.gal-personality-chip/)
})

test('detects session switches across reloads and no longer observes routes', async () => {
  const layer = await readFile('src/client/character-layer.js', 'utf8')
  assert.match(layer, /sakura-vn-last-session-v1/)
  assert.match(layer, /loadLastSession/)
  assert.match(layer, /saveLastSession/)
  assert.match(layer, /sessionSwitched/)
  assert.doesNotMatch(layer, /installRouteObserver/)
})

test('keeps the runtime frame in a persistent body-level host', async () => {
  const [layer, template, styles] = await Promise.all([
    readFile('src/client/character-layer.js', 'utf8'),
    readFile('tools/client-template.js', 'utf8'),
    readFile('src/client/styles.js', 'utf8'),
  ])
  assert.match(layer, /frameHost/)
  assert.match(layer, /gal-hidden/)
  assert.match(layer, /destroyRuntime/)
  assert.match(template, /gal-character-frame-host/)
  assert.match(template, /frameHost\.remove\(\)/)
  assert.match(styles, /\.gal-character-frame-host\s*\{[\s\S]*?z-index: 30;/)
  assert.match(styles, /\.gal-character-frame-host\.gal-hidden\s*\{\s*display: none;/)
})

test('forwards expression playback into the controller', async () => {
  const layer = await readFile('src/client/character-layer.js', 'utf8')
  assert.match(layer, /playExpression/)
})
