# Social Preview Design

## Objective

Create a GitHub Social Preview for `dsh-hiyori-web-ui` that connects the DeepSeek whale motif with the repository's Live2D companion, Hiyori. The result should feel warmer and gentler than the blue promotional image used by `dsh-web-ui`, while remaining recognizable as part of the same DeepSeek Harness ecosystem.

## Deliverable

- One production PNG at 1280 × 640 pixels.
- The final asset will be stored under `docs/social-preview/` with a descriptive filename.
- The image must remain legible at GitHub card and link-preview sizes.

## Approved Content

The image contains only these two text lines:

1. `dsh-hiyori-web-ui`
2. `桃濑日和 · DSH 伴侣`

There is no English eyebrow, marketing slogan, feature-pill list, or other copy.

## Composition

- Use the approved “dual protagonist” layout.
- Reserve the left 60–65% for the title block and breathing room.
- Place a large blue DeepSeek whale as a soft background totem across the center-right. It should be clearly recognizable as a whale but remain lower contrast than Hiyori.
- Place Hiyori at the right foreground in her recognizable full-body design. She is the sharpest and highest-contrast character element.
- Keep the whale and Hiyori visually distinct rather than merging their anatomy or costume.
- Use a thin, restrained gold corner frame and a few cherry-blossom petals to connect the preview with the repository UI.

## Color and Mood

Use the approved “cream sea breeze” direction:

- warm ivory and pale cream for the background;
- soft whale blue and muted deep blue for the whale;
- Hiyori's existing warm cream cardigan, dark skirt, brown hair, and blue ribbon;
- pale cherry-blossom pink as a sparse accent;
- dark warm brown for primary text;
- very light gold for corner-line decoration.

The mood is gentle, polished, companionable, and calm. Avoid a dark deep-sea scene, hard neon lighting, or a monochrome blue wash.

## Typography

- Keep `dsh-hiyori-web-ui` on one line in all final outputs.
- Make the repository name the dominant visual element on the left.
- Use the approved soft geometric display treatment: rounded letterforms with a subtle dark-brown-to-whale-blue color transition and minimal highlight/shadow depth.
- The art treatment must not reduce the legibility of the hyphens or individual letters.
- Render `桃濑日和 · DSH 伴侣` larger than a conventional caption, but clearly subordinate to the repository name.
- Use a refined Chinese serif or similarly gentle display face for the subtitle.

## Source References

- `docs/readme/hero.png` establishes the repository's warm cream, soft pink, and brown UI language.
- `assets/live2d/public/Resources/Hiyori/hiyori_pro_t11.2048/texture_00.png` and `texture_01.png` establish Hiyori's official face, hair, clothing, ribbon, and palette.
- The `dsh-web-ui` Social Preview establishes the ecosystem precedent of a large repository title on the left and a character-led illustration on the right. This design retains that hierarchy without copying its blue monochrome treatment or feature-pill row.

## Generation and Assembly

1. Generate the illustration layer with the whale, Hiyori, cream background, petals, and gold corner accents.
2. Preserve Hiyori's key design details using the local Live2D references.
3. Treat generated text as disposable if letterforms are inaccurate.
4. Add or correct the two approved text lines during final assembly so spelling, punctuation, single-line layout, and typographic hierarchy are exact.
5. Crop or resize to exactly 1280 × 640 without stretching the characters.

## Acceptance Criteria

- Canvas is exactly 1280 × 640.
- `dsh-hiyori-web-ui` is spelled exactly and appears on one line.
- `桃濑日和 · DSH 伴侣` is spelled exactly and is visibly larger than a small caption.
- No English slogan or feature labels appear.
- The whale reads as a background totem; Hiyori reads as the foreground companion.
- Hiyori retains her brown twin-tail hairstyle, blue eyes, cream cardigan, sailor-style collar and blue ribbon, dark pleated skirt, dark knee socks, and brown loafers.
- The warm cream background remains dominant, with blue and pink used as accents.
- The image remains readable and compositionally balanced when viewed at 640 × 320.
- No watermark, accidental text, malformed hands, duplicated limbs, or cropped character parts remain.
