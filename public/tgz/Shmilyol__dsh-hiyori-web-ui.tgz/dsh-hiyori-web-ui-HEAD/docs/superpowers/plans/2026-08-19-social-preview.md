# Social Preview Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Generate, validate, and save a 1280 × 640 GitHub Social Preview that combines the DeepSeek whale motif with Hiyori and the approved single-line artistic title.

**Architecture:** Use the built-in image-generation workflow with local visual references for Hiyori, repository palette, and the reference repository's composition. Iterate through visual inspection and targeted image edits, then save one final PNG under `docs/social-preview/` and verify dimensions and thumbnail readability.

**Tech Stack:** Built-in image generation, local PNG references, macOS image metadata tools, Git.

---

### Task 1: Generate the Production Draft

**Files:**
- Reference: `docs/readme/interaction.png`
- Reference: `docs/readme/hero.png`
- Reference: `/tmp/dsh-web-ui-social-preview.png`
- Create: built-in generated image under the image-generation output directory

- [ ] **Step 1: Confirm all visual references exist**

Run:

```bash
test -f docs/readme/interaction.png
test -f docs/readme/hero.png
test -f /tmp/dsh-web-ui-social-preview.png
```

Expected: all three commands exit with status 0 and print no errors.

- [ ] **Step 2: Generate one 2:1 production draft with the built-in image tool**

Use these reference roles:

- `docs/readme/interaction.png`: identity and costume reference for Hiyori;
- `docs/readme/hero.png`: warm cream, pink, brown, and gold repository palette reference;
- `/tmp/dsh-web-ui-social-preview.png`: left-title/right-character hierarchy reference only.

Use this prompt:

```text
Use case: ads-marketing
Asset type: GitHub repository Social Preview, exact 2:1 landscape composition, intended final size 1280 × 640
Primary request: Create a polished anime-style repository banner combining a large gentle DeepSeek blue whale motif with the official Hiyori character. Use a dual-protagonist layout: title block on the left, whale as a soft background totem across the center-right, Hiyori as the crisp full-body foreground character on the far right.
Input images: Image 1 is the identity and costume reference for Hiyori; Image 2 is the repository palette and mood reference; Image 3 is layout hierarchy reference only and must not be copied stylistically.
Scene/backdrop: warm ivory and pale cream gradient with subtle depth, a restrained thin gold corner frame, and only a few pale cherry-blossom petals.
Subject: Hiyori must retain brown twin-tail hair with red hair accessories, large blue eyes, cream cardigan, dark sailor collar, blue ribbon, dark pleated skirt, dark knee socks, and brown loafers. The whale is large, calm, blue, softly translucent, and clearly behind Hiyori. Do not merge Hiyori's anatomy or costume with the whale.
Style/medium: refined soft anime key art with clean contours, gentle painterly shading, premium open-source project branding, not chibi, not photorealistic.
Composition/framing: reserve the left 60–65 percent as clean readable space; Hiyori full body on the right with no cropped feet or hair; whale behind her and extending toward center; balanced at thumbnail size.
Lighting/mood: soft morning light, gentle, companionable, calm, polished.
Color palette: warm ivory dominant; soft whale blue and muted deep blue accents; Hiyori's official warm cream, brown, navy, and blue; sparse cherry-blossom pink; very light gold linework.
Text (verbatim): "dsh-hiyori-web-ui" on one line as the dominant large title; "桃濑日和 · DSH 伴侣" as a large but subordinate subtitle.
Typography: soft geometric display lettering for the repository name, rounded and artistic, subtle dark-brown-to-whale-blue transition, every hyphen and letter fully legible; refined Chinese serif subtitle; keep both lines horizontal.
Constraints: exactly two text lines; repository name must stay on one line; preserve Hiyori identity and clothing; no cropped character parts; no watermark.
Avoid: English slogan, eyebrow text, feature pills, extra words, dark deep-sea background, neon cyberpunk lighting, monochrome blue wash, distorted hands, extra fingers, duplicated limbs, malformed text, merged whale-girl anatomy.
```

Expected: one landscape draft with the approved composition, palette, text hierarchy, and complete Hiyori figure.

### Task 2: Inspect and Correct the Draft

**Files:**
- Inspect: built-in generated draft from Task 1
- Create: corrected generated image when any acceptance criterion fails

- [ ] **Step 1: Inspect the generated draft at full size**

Check these exact items:

```text
1. dsh-hiyori-web-ui is exact and appears on one line.
2. 桃濑日和 · DSH 伴侣 is exact and visibly larger than a small caption.
3. No third text line or accidental characters appear.
4. Hiyori matches the local reference and has a complete body.
5. The whale is behind Hiyori and does not merge with her anatomy.
6. Warm cream remains the dominant background color.
7. The left title and right characters remain balanced at thumbnail scale.
```

Expected: either all seven checks pass or a short list of concrete failures is recorded for the next edit.

- [ ] **Step 2: Apply one targeted built-in image edit when needed**

Use the generated draft as the edit target and repeat all invariants. Change only failed items. Example correction prompt for text or scale failures:

```text
Edit only the title area. Keep the whale, Hiyori, background, palette, petals, gold corner frame, lighting, and all character details unchanged. Render the dominant title exactly as "dsh-hiyori-web-ui" on one horizontal line in a larger soft geometric artistic font. Render the subtitle exactly as "桃濑日和 · DSH 伴侣", larger than before but still subordinate. Remove any other text. Preserve the exact 2:1 composition and leave the full Hiyori figure uncropped.
```

Expected: corrected image passes all seven inspection checks.

- [ ] **Step 3: Inspect the corrected image again**

Repeat the seven-item checklist from Step 1.

Expected: all checks pass before saving the asset.

### Task 3: Save and Verify the Repository Asset

**Files:**
- Create: `docs/social-preview/dsh-hiyori-web-ui-social-preview.png`

- [ ] **Step 1: Create the destination directory**

Run:

```bash
mkdir -p docs/social-preview
```

Expected: `docs/social-preview/` exists.

- [ ] **Step 2: Copy the approved generated image into the repository**

Set the task-specific `SOCIAL_PREVIEW_SOURCE` variable to the absolute path returned by the built-in image tool, then run:

```bash
test -n "$SOCIAL_PREVIEW_SOURCE"
test -f "$SOCIAL_PREVIEW_SOURCE"
cp "$SOCIAL_PREVIEW_SOURCE" docs/social-preview/dsh-hiyori-web-ui-social-preview.png
```

Expected: the destination PNG exists and is non-empty.

- [ ] **Step 3: Verify exact dimensions**

Run:

```bash
sips -g pixelWidth -g pixelHeight docs/social-preview/dsh-hiyori-web-ui-social-preview.png
```

Expected:

```text
pixelWidth: 1280
pixelHeight: 640
```

If the generated image is not already 1280 × 640, use a centered 2:1 crop followed by Lanczos resampling:

```bash
/opt/homebrew/bin/ffmpeg -y \
  -i docs/social-preview/dsh-hiyori-web-ui-social-preview.png \
  -vf "crop='min(iw,ih*2)':'min(ih,iw/2)',scale=1280:640:flags=lanczos" \
  -frames:v 1 /tmp/dsh-hiyori-social-preview-normalized.png
cp /tmp/dsh-hiyori-social-preview-normalized.png docs/social-preview/dsh-hiyori-web-ui-social-preview.png
sips -g pixelWidth -g pixelHeight docs/social-preview/dsh-hiyori-web-ui-social-preview.png
```

Expected: the final metadata reports 1280 × 640. Reinspect the result and reject the crop if it cuts the title or any part of Hiyori.

- [ ] **Step 4: Inspect the final repository PNG and a 640 × 320 preview**

Open the final PNG for visual inspection. Create a temporary 640 × 320 preview with:

```bash
sips --resampleHeightWidth 320 640 docs/social-preview/dsh-hiyori-web-ui-social-preview.png --out /tmp/dsh-hiyori-social-preview-640.png
```

Inspect both images.

Expected: title and subtitle remain readable, Hiyori and the whale remain recognizable, and no edge is clipped.

- [ ] **Step 5: Verify repository state**

Run:

```bash
git status --short
```

Expected: the new Social Preview PNG is listed; the user's pre-existing `README.md` modification remains separate and untouched.

- [ ] **Step 6: Commit only the Social Preview asset**

Run:

```bash
git add docs/social-preview/dsh-hiyori-web-ui-social-preview.png
git commit -m "docs: add repository social preview"
```

Expected: one commit containing only the final PNG.
