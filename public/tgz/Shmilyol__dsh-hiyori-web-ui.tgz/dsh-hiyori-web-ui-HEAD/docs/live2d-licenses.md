# Live2D 资源与发布边界

仓库已随版本发布可运行的 Live2D 资源。普通用户无需下载 SDK、运行 vendor 工具或重新生成这些文件。

## 随仓库发布的资源

- Cubism Core redistributable files：`assets/live2d/public/runtime/Core/live2dcubismcore.js`、`LICENSE.md`、`RedistributableFiles.txt`。
- Hiyori Pro runtime：`assets/live2d/public/Resources/Hiyori/`，包含模型、纹理、物理/姿势配置和十个动作。
- Cubism Web Framework + Samples build：`assets/live2d/public/Framework/Shaders/` 与 `assets/live2d/public/runtime/`。
- 资源清单：`assets/live2d/manifest.json`，其中固定了 Samples commit `ed1e0b714826d92469b9e51cacc3346f4e393f03` 和 Framework commit `198a3769c26ca3d7b600e932590433badd392edd`。

角色是 Live2D 原创角色桃濑日和（Hiyori Pro）。插画：Kani Biimu；模型：Live2D。随附说明见 `assets/live2d/licenses/Hiyori-Pro-ReadMe.txt`。

## 官方条款

使用或再分发前请阅读适用的官方文本：[Live2D Open Software License Agreement](https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html)、[Live2D Sample Model Terms（Cubism 示例模型使用条款）](https://www.live2d.com/eula/live2d-sample-model-terms_en.html)、[Live2D Free Material License Agreement（无偿提供素材使用授权协议）](https://www.live2d.com/eula/live2d-free-material-license-agreement_en.html) 和 [Core proprietary license](https://www.live2d.com/eula/live2d-proprietary-software-license-agreement_en.html)。

这些 Core、Hiyori、Framework/Samples 文件不适用仓库其他代码的许可。不得脱离本插件单独再分发角色资源；使用时应保留角色设计细节和许可文件。以上是资源来源与发布边界说明，不构成超出官方条款的法律结论。

## 维护者说明

`tools/vendor-live2d.mjs` 以及固定 commit 仅供维护者重新生成和校验 vendor 资源时使用。用户运行 `npm run setup:live2d` 时只校验仓库已有资源并生成插件文件，不会下载或构建 Live2D SDK。
