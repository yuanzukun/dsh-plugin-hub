/**
 * merge-tool-calls — browser half.
 *
 * Shadows the shipped `tool.call.toolview` entries for every grouped tool at
 * priority -1 (the keyed slot's shadowing rule: lowest priority renders). An
 * empty `tools` config means every built-in generic-family tool
 * (see {@link ALL_TOOL_NAMES}); a non-empty list is an explicit whitelist.
 * The shadowed component merges consecutive calls of one tool in the chat flow
 * into a single card with compact child rows.
 *
 * @module @dsh-external/dsh-plugin-merge-tool-calls/client
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type MergeToolCallsConfig } from '../types.ts';
import { type MergeToolCallsKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Copy for the merged tool-call rows. */
        'merge-tool-calls': MergeToolCallsKey;
    }
}
/** Required services: the slot registry (toolview shadowing) and locale. */
export declare const inject: string[];
/**
 * Register one shadowed toolview per grouped tool.
 * @param ctx - client root context.
 * @param config - row config; defaults apply when the loader passes none.
 */
export declare function apply(ctx: ClientContext, config?: Partial<MergeToolCallsConfig>): void;
