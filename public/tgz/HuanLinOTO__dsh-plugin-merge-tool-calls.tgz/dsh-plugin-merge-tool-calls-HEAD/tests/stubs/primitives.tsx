/** Test double for @deepseek-ai/dsh-client-ui-primitives (see vitest.config.ts alias). */
import { type ReactNode } from 'react'

export function DisclosureRow({
  title, open, expandable, collapsedContent, children, onToggle, expandOnRowClick,
  className, rowClassName, titleClassName, icon,
}: {
  title: string
  open: boolean
  expandable: boolean
  onToggle: () => void
  expandOnRowClick?: boolean
  keepContentWhenOpen?: boolean
  collapsedContent?: ReactNode
  children?: ReactNode
  className?: string
  rowClassName?: string
  leadingClassName?: string
  chevronClassName?: string
  titleClassName?: string
  icon?: ReactNode
}) {
  const classList = [className].filter(Boolean).join(' ')
  const rowClassList = [rowClassName].filter(Boolean).join(' ')
  const titleClassList = [titleClassName].filter(Boolean).join(' ')
  return (
    <div className={classList || undefined} data-testid="disclosure" data-open={open || undefined} data-expandable={expandable || undefined}>
      <div className={rowClassList || undefined} data-testid="disclosure-row" role={expandOnRowClick ? 'button' : undefined} onClick={expandOnRowClick ? onToggle : undefined}>
        {icon}
        <span className={titleClassList || undefined}>{title}</span>
        {collapsedContent}
      </div>
      {open && children}
    </div>
  )
}

export function ReadBlock({ label }: { label?: string; lines?: unknown[]; totalLines?: number; lang?: string; maxLines?: number; labels?: unknown }) {
  return <div data-testid="readblock">{label}</div>
}

export function SearchBlock({ kind }: { kind?: string; files?: unknown[]; paths?: string[]; truncated?: boolean; total?: number; maxLines?: number; labels?: unknown }) {
  return <div data-testid="searchblock">{kind}</div>
}

export function DiffBlock({ diffs }: { diffs?: unknown[]; maxLines?: number; labels?: unknown }) {
  return <div data-testid="diffblock">{Array.isArray(diffs) ? diffs.length : 0} hunks</div>
}

export function TerminalBlock({ command }: { command?: string; cwd?: string; home?: string; output?: string; exitCode?: number; signal?: string; running?: boolean; maxLines?: number; labels?: unknown }) {
  return <div data-testid="terminalblock">{command}</div>
}

export function WebBlock({ kind }: { kind?: string; url?: string; answer?: string; sources?: unknown[]; statusCode?: number; truncated?: boolean; labels?: unknown }) {
  return <div data-testid="webblock">{kind}</div>
}

export function StateDot({ state }: { state: string }) {
  return <span data-testid="statedot" data-state={state} />
}

export function IconBrowseOutlineRegular() {
  return <span data-testid="icon-browse" />
}

export function IconSearchOutlineRegular() {
  return <span data-testid="icon-search" />
}

export function IconApiOutlineRegular() {
  return <span data-testid="icon-api" />
}

export function IconEditOutlineRegular() {
  return <span data-testid="icon-edit" />
}

export function IconCodeOutlineRegular() {
  return <span data-testid="icon-code" />
}

export function IconSparkleRegular() {
  return <span data-testid="icon-sparkle" />
}
