// @vitest-environment jsdom
/** Component spec: MergedToolRow renders the run card / hides continuations. */
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, describe, expect, it } from 'vitest'
import type { ChatNodeStore, ChatSnapshot, ToolCallBlock } from '@deepseek-ai/dsh-client-ui-chat/client'
import { MergedToolRow, type MergedToolRowProps } from '../src/client/rows.tsx'
import type { MergeToolCallsConfig } from '../src/types.ts'

;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const CFG: MergeToolCallsConfig = { tools: ['read', 'grep', 'glob'], groupBy: 'adjacent', maxGroupSize: 8 }

const T = ((key: string, params?: Record<string, unknown>) => {
  const dict: Record<string, string> = {
    running: 'Running', failed: 'Failed', stopped: 'Interrupted',
    expand: 'Expand', collapse: 'Collapse', more: '+{n}',
    countFiles: '{n} Files', countQueries: '{n} Queries',
    countCommands: '{n} Commands', countPrograms: '{n} Programs',
    countCalls: '{n} Calls',
  }
  const raw = dict[key] ?? key
  return params === undefined ? raw : raw.replace(/\{(\w+)\}/g, (_, name: string) => String(params[name]))
}) as MergedToolRowProps['t']

function runningCall(callId: string, name: string, argsRaw = '{}'): ToolCallBlock {
  return { phase: 'start', callId, name, argsRaw, turn: 1, step: 1, time: 0, subCalls: [] }
}

function preparingCall(callId: string, name: string): ToolCallBlock {
  return { phase: 'preparing', callId, name, turn: 1, step: 1, time: 0, subCalls: [] }
}

function settledRead(callId: string, path: string): ToolCallBlock {
  return {
    kind: 'tool-result', seq: 1, time: 0, callId,
    call: { name: 'read', argsRaw: JSON.stringify({ file_path: path }) },
    callTime: 0,
    content: [{ type: 'text', text: `<path>${path}</path>\n<type>file</type>\n<content>\nhello\n</content>` }],
    isError: false,
    meta: { path, offset: 1, lines: [{ number: 1, text: 'hello' }], totalLines: 1 },
    subCalls: [],
  }
}

function settledWrite(callId: string, path: string): ToolCallBlock {
  return {
    kind: 'tool-result', seq: 1, time: 0, callId,
    call: { name: 'write', argsRaw: JSON.stringify({ file_path: path }) },
    callTime: 0, content: [], isError: false,
    subCalls: [],
  }
}

const NODE_KEY = (id: string) => `k:${id}`

function snapshotOf(ids: string[], byId: Record<string, { callId: string; block: ToolCallBlock }>): ChatSnapshot {
  const order = ids.map(NODE_KEY)
  const nodes = new Map<string, unknown>()
  for (const [key, entry] of Object.entries(byId)) {
    nodes.set(NODE_KEY(entry.callId), {
      key: NODE_KEY(entry.callId), kind: 'tool-call', id: entry.callId, target: 'chat', anchorSeq: 0,
      location: {
        kind: 'step',
        turn: { turn: 1, start: undefined, end: undefined, status: 'closed', steps: [], data: { get: () => undefined } },
        step: { turn: 1, step: 1, start: undefined, end: undefined, status: 'closed', data: { get: () => undefined } },
      },
      visibility: 'visible', data: { root: entry.block },
    })
  }
  const store: ChatNodeStore = { get: nodeKey => nodes.get(nodeKey) as never, values: () => [...nodes.values()] as never }
  return {
    order,
    nodes: store,
    locations: undefined as never,
    navigation: undefined as never,
    timeline: { turnOrder: [], turns: new Map() },
    legacy: undefined as never,
  } as ChatSnapshot
}

function render(partial: Partial<MergedToolRowProps> & { callId: string; useChat: MergedToolRowProps['useChat'] }) {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  const props = {
    toolName: 'read',
    phase: 'start',
    block: runningCall(partial.callId, 'read'),
    cwd: undefined,
    home: undefined,
    openFile: () => {},
    loadImage: (async () => '') as never,
    inspect: undefined,
    t: T,
    cfg: CFG,
    useDisclosure: (() => [false, { open: () => {}, close: () => {}, toggle: () => {} }]) as never,
    useToolCallArgumentsPartial: () => '',
    ...partial,
  } as MergedToolRowProps
  act(() => {
    root.render(<MergedToolRow {...props} />)
  })
  return { container, root }
}

function unmount(root: Root) {
  act(() => { root.unmount() })
  document.body.innerHTML = ''
}

afterEach(() => {
  document.body.innerHTML = ''
})

describe('MergedToolRow', () => {
  it('renders the run card for the first call, with one child row per call (including the first)', () => {
    const snapshot = snapshotOf(['a', 'b', 'c'], {
      a: { callId: 'a', block: settledRead('a', 'foo.ts') },
      b: { callId: 'b', block: settledRead('b', 'bar.ts') },
      c: { callId: 'c', block: settledRead('c', 'baz.ts') },
    })
    const useChat = ((selector: (s: ChatSnapshot) => unknown) => selector(snapshot)) as MergedToolRowProps['useChat']
    const { container, root } = render({ callId: 'a', useChat })
    expect(container.querySelector('[data-testid="disclosure"]')).not.toBeNull()
    // Main row shows the variant title and the merged-count summary.
    const titleRow = container.querySelector('.mtc-title-row')
    expect(titleRow!.textContent).toContain('Read')
    expect(titleRow!.textContent).toContain('3 Files')
    // The first call's file path is NOT on the main row — it lives on a child row.
    expect(titleRow!.textContent).not.toContain('foo.ts')
    // Three child rows (all calls, including the first), each showing its file path.
    const toggles = container.querySelectorAll('.mtc-child-row')
    expect(toggles.length).toBe(3)
    expect(toggles[0]!.textContent).toContain('foo.ts')
    expect(toggles[1]!.textContent).toContain('bar.ts')
    expect(toggles[2]!.textContent).toContain('baz.ts')
    // No `+n` suffix — the count is the summary now.
    expect(container.textContent).not.toContain('+2')
    unmount(root)
  })

  it('renders nothing for a continuation call (seat stays empty)', () => {
    const snapshot = snapshotOf(['a', 'b'], {
      a: { callId: 'a', block: settledRead('a', 'foo.ts') },
      b: { callId: 'b', block: settledRead('b', 'bar.ts') },
    })
    const useChat = ((selector: (s: ChatSnapshot) => unknown) => selector(snapshot)) as MergedToolRowProps['useChat']
    const { container, root } = render({ callId: 'b', useChat })
    expect(container.children.length).toBe(0)
    unmount(root)
  })

  it('renders a lightweight argument-free row for a preparing call', () => {
    const snapshot = snapshotOf(['a'], { a: { callId: 'a', block: preparingCall('a', 'read') } })
    const useChat = ((selector: (s: ChatSnapshot) => unknown) => selector(snapshot)) as MergedToolRowProps['useChat']
    const { container, root } = render({
      callId: 'a',
      phase: 'preparing',
      block: preparingCall('a', 'read'),
      useChat,
      // The optional raw argument prefix streams in while preparing.
      useToolCallArgumentsPartial: () => '{"file_path":"foo',
    })
    const row = container.querySelector('.mtc-row')
    expect(row).not.toBeNull()
    expect(row!.getAttribute('data-state')).toBe('preparing')
    // Variant title/icon without reading `argsRaw` (PreparingToolCall has none).
    expect(container.textContent).toContain('Read')
    // The raw argument prefix is shown while preparing.
    expect(container.textContent).toContain('{"file_path":"foo')
    // Preparing is never expandable and never merges into child rows here.
    expect(container.querySelectorAll('.mtc-child-row').length).toBe(0)
    expect(container.querySelector('[data-testid="disclosure"]')?.getAttribute('data-expandable')).toBeNull()
    unmount(root)
  })

  it('collapses child rows by default and reveals them on main row click', () => {
    const snapshot = snapshotOf(['a', 'b', 'c'], {
      a: { callId: 'a', block: settledRead('a', 'foo.ts') },
      b: { callId: 'b', block: settledRead('b', 'bar.ts') },
      c: { callId: 'c', block: settledRead('c', 'baz.ts') },
    })
    const useChat = ((selector: (s: ChatSnapshot) => unknown) => selector(snapshot)) as MergedToolRowProps['useChat']
    const { container, root } = render({ callId: 'a', useChat })
    // The animated children-collapse wrapper exists and is closed by default.
    const collapse = container.querySelector('.mtc-children-collapse')
    expect(collapse).not.toBeNull()
    expect(collapse!.getAttribute('data-open')).toBeNull()
    // Child rows stay in the DOM (grid-template-rows keeps them for the slide).
    expect(container.querySelectorAll('.mtc-child-row').length).toBe(3)
    // Clicking the main row toggles the children block open.
    const titleRow = container.querySelector('.mtc-title-row') as HTMLDivElement
    act(() => { titleRow.click() })
    expect(collapse!.getAttribute('data-open')).not.toBeNull()
    // Clicking again collapses it.
    act(() => { titleRow.click() })
    expect(collapse!.getAttribute('data-open')).toBeNull()
    unmount(root)
  })

  it('expands a child row to reveal its file content on click', () => {
    const snapshot = snapshotOf(['a', 'b'], {
      a: { callId: 'a', block: settledRead('a', 'foo.ts') },
      b: { callId: 'b', block: settledRead('b', 'bar.ts') },
    })
    const useChat = ((selector: (s: ChatSnapshot) => unknown) => selector(snapshot)) as MergedToolRowProps['useChat']
    const { container, root } = render({ callId: 'a', useChat })
    expect(container.querySelectorAll('[data-testid="readblock"]').length).toBe(0) // collapsed
    // The first child row is the first call (foo.ts) — its inline content card
    // opens on click, independent of the main row's children-collapse.
    const row = container.querySelector('.mtc-child-row') as HTMLDivElement
    act(() => { row.click() })
    const blocks = container.querySelectorAll('[data-testid="readblock"]')
    expect(blocks.length).toBe(1) // the child's card body; the main row stays collapsed
    expect(blocks[0]!.textContent).toContain('foo.ts')
    unmount(root)
  })

  it('renders a read child path as an open-file link (sidebar preview)', () => {
    const snapshot = snapshotOf(['a', 'b'], {
      a: { callId: 'a', block: settledRead('a', 'foo.ts') },
      b: { callId: 'b', block: settledRead('b', 'bar.ts') },
    })
    const useChat = ((selector: (s: ChatSnapshot) => unknown) => selector(snapshot)) as MergedToolRowProps['useChat']
    const opened: string[] = []
    const { container, root } = render({
      callId: 'a',
      useChat,
      openFile: (path: string) => { opened.push(path) },
    })
    // The first child row is the first call (foo.ts) — its path is the open-file link.
    const link = container.querySelector('.mtc-child-path-link') as HTMLButtonElement
    expect(link).not.toBeNull()
    act(() => { link.click() })
    expect(opened).toEqual(['foo.ts'])
    // The link's stopPropagation must not toggle the row's inline expand.
    expect(container.querySelectorAll('[data-testid="readblock"]').length).toBe(0)
    unmount(root)
  })

  it('falls back to a plain single row when the call is not a chat tool-call node', () => {
    const snapshot = snapshotOf([], {})
    const useChat = ((selector: (s: ChatSnapshot) => unknown) => selector(snapshot)) as MergedToolRowProps['useChat']
    const { container, root } = render({ callId: 'subcall', useChat })
    expect(container.querySelector('[data-testid="disclosure"]')).not.toBeNull()
    expect(container.querySelectorAll('.mtc-child-row').length).toBe(0)
    unmount(root)
  })

  it('merges non-read tools with their variant title and expandable child rows', () => {
    const snapshot = snapshotOf(['a', 'b'], {
      a: { callId: 'a', block: runningCall('a', 'bash') },
      b: { callId: 'b', block: runningCall('b', 'bash') },
    })
    const useChat = ((selector: (s: ChatSnapshot) => unknown) => selector(snapshot)) as MergedToolRowProps['useChat']
    const { container, root } = render({ callId: 'a', toolName: 'bash', cfg: { ...CFG, tools: [] }, useChat })
    expect(container.textContent).toContain('Bash')
    // A running bash still carries its args as the IN body, so the row expands.
    const row = container.querySelector('.mtc-child-row') as HTMLDivElement
    expect(row.dataset.static).toBeUndefined()
    expect(row.getAttribute('role')).toBe('button')
    unmount(root)
  })

  it('keeps a running read child row static (nothing to expand)', () => {
    const snapshot = snapshotOf(['a', 'b'], {
      a: { callId: 'a', block: { ...runningCall('a', 'read'), argsRaw: JSON.stringify({ file_path: 'a.ts' }) } },
      b: { callId: 'b', block: { ...runningCall('b', 'read'), argsRaw: JSON.stringify({ file_path: 'b.ts' }) } },
    })
    const useChat = ((selector: (s: ChatSnapshot) => unknown) => selector(snapshot)) as MergedToolRowProps['useChat']
    const { container, root } = render({ callId: 'a', cfg: { ...CFG, tools: [] }, useChat })
    const row = container.querySelector('.mtc-child-row') as HTMLDivElement
    expect(row.dataset.static).toBe('true')
    expect(row.getAttribute('role')).toBeNull()
    act(() => { row.click() })
    expect(container.querySelectorAll('[data-testid="readblock"]').length).toBe(0)
    unmount(root)
  })

  it('renders a write child path as an open-file link (file tools openable)', () => {
    const snapshot = snapshotOf(['a', 'b'], {
      a: { callId: 'a', block: settledWrite('a', 'out.ts') },
      b: { callId: 'b', block: settledWrite('b', 'out2.ts') },
    })
    const useChat = ((selector: (s: ChatSnapshot) => unknown) => selector(snapshot)) as MergedToolRowProps['useChat']
    const opened: string[] = []
    const { container, root } = render({
      callId: 'a',
      toolName: 'write',
      cfg: { ...CFG, tools: [] },
      useChat,
      openFile: (path: string) => { opened.push(path) },
    })
    expect(container.textContent).toContain('Write')
    // The first child row is the first call (out.ts) — its path is the open-file link.
    const link = container.querySelector('.mtc-child-path-link') as HTMLButtonElement
    expect(link).not.toBeNull()
    act(() => { link.click() })
    expect(opened).toEqual(['out.ts'])
    unmount(root)
  })
})
