/**
 * OpenCode Go usage dock — the whole browser surface.
 *
 * A floating dock: a compact glassy badge shows all three quota
 * windows (滚/周/月) with threshold-colored percentages plus the 5h-rolling
 * window's live reset countdown; clicking it toggles a glassy panel with the
 * full window rows, a manual refresh button, and clear error / unconfigured
 * states. In minimal mode the dock collapses to a single larger 5h-rolling
 * ring (the toggle lives in the panel header). The dock is draggable — grab
 * the badge with pointer events and drop it anywhere; its position persists
 * in localStorage, and the panel auto-flips top/bottom and left/right so it
 * stays inside the viewport. The dock is mounted through a body portal by
 * `client/index.tsx` and follows DSH design tokens (`--dsw-alias-*`), so it
 * blends with either theme. Reuses the shared `StateDot` and `Button`
 * primitives so the dock's affordances stay visually consistent with DSH.
 * @module dsh-opencode-go-usage/client/dock
 */

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import type { PointerEvent as ReactPointerEvent, ReactElement } from 'react'
import { StateDot, Button } from '@deepseek-ai/dsh-client-ui-primitives'
import type { OpenCodeUsageState } from '../types.ts'
import {
  clampDockPosition, computePanelLayout, fetchState, formatRelative,
  formatRemaining, formatRemainingCompact, percentTone, refreshState,
  remainingRatio, stateHasUsage, usageWindows,
  type DockPosition, type PanelLayout, type WindowView,
} from './usage-model.ts'
import styles from './usage.module.css'

/** Poll cadence: fast while the panel is open, calm while collapsed. */
const OPEN_POLL_MS = 10_000
const COLLAPSED_POLL_MS = 60_000

/** Pointer travel (px) beyond which a press counts as a drag, not a click. */
const DRAG_THRESHOLD_PX = 4

/** localStorage keys for persisted dock preferences. */
const STORAGE_POS_KEY = 'dsh-opencode-go-usage.position'
const STORAGE_MINIMAL_KEY = 'dsh-opencode-go-usage.minimal'

/** Active pointer-drag session on the badge. */
interface DragSession {
  pointerId: number
  startX: number
  startY: number
  originX: number
  originY: number
  sizeW: number
  sizeH: number
  moved: boolean
}

/** Whether the user asked the OS to cut non-essential motion. */
function prefersReducedMotion(): boolean {
  return typeof window !== 'undefined'
    && typeof window.matchMedia === 'function'
    && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

/** Read a persisted dock position; tolerates corrupt or absent storage. */
function loadPosition(): DockPosition | null {
  if (typeof window === 'undefined') return null
  try {
    const raw = window.localStorage.getItem(STORAGE_POS_KEY)
    if (raw === null) return null
    const parsed = JSON.parse(raw) as Partial<DockPosition>
    if (typeof parsed.x !== 'number' || !Number.isFinite(parsed.x)
      || typeof parsed.y !== 'number' || !Number.isFinite(parsed.y)) return null
    return { x: parsed.x, y: parsed.y }
  } catch {
    return null
  }
}

/** Read the persisted minimal-mode flag. */
function loadMinimal(): boolean {
  if (typeof window === 'undefined') return false
  try {
    return window.localStorage.getItem(STORAGE_MINIMAL_KEY) === '1'
  } catch {
    return false
  }
}

/** Clamp a dock position so the badge stays fully inside the viewport. */
function clampToViewport(pos: DockPosition, sizeW: number, sizeH: number): DockPosition {
  return clampDockPosition(pos, { w: sizeW, h: sizeH }, { w: window.innerWidth, h: window.innerHeight })
}

/** Root state: the dock itself. */
export function UsageDock(): ReactElement {
  const [open, setOpen] = useState(false)
  // Closing drives the exit animation: set first, the `usage-pop-out` reverse
  // tweens play, and onAnimationEnd finally flips `open` to false.
  const [closing, setClosing] = useState(false)
  const [state, setState] = useState<OpenCodeUsageState | null>(null)
  const [refreshing, setRefreshing] = useState(false)
  // Re-rendered once a second so badge and panel countdowns stay live.
  const [now, setNow] = useState(() => Date.now())
  // Minimal mode: the dock collapses to a single 5h-rolling ring.
  const [minimal, setMinimal] = useState(loadMinimal)
  // Dragged position; null keeps the CSS default bottom-right placement.
  const [pos, setPos] = useState<DockPosition | null>(loadPosition)
  // Measured badge / panel sizes, used for clamping and panel flipping.
  const [badgeSize, setBadgeSize] = useState<{ w: number; h: number } | null>(null)
  const [panelSize, setPanelSize] = useState<{ w: number; h: number } | null>(null)
  const [dragging, setDragging] = useState(false)

  const badgeRef = useRef<HTMLButtonElement | null>(null)
  const panelRef = useRef<HTMLElement | null>(null)
  const dragRef = useRef<DragSession | null>(null)
  // Set when a press ended as a drag, so the following click event (browsers
  // still fire it after pointer capture) is swallowed instead of toggling.
  const suppressClickRef = useRef(false)

  // Poll the host cache; interval follows the open state.
  useEffect(() => {
    let alive = true
    const tick = async (): Promise<void> => {
      try {
        const next = await fetchState()
        if (alive) setState(next)
      } catch {
        // Keep the last sample; transient network failures must not blank the dock.
      }
    }
    void tick()
    const id = window.setInterval(() => { void tick() }, open ? OPEN_POLL_MS : COLLAPSED_POLL_MS)
    return () => {
      alive = false
      window.clearInterval(id)
    }
  }, [open])

  // Countdown ticker: always on (the badge shows the rolling countdown too).
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000)
    return () => window.clearInterval(id)
  }, [])

  // Persist the dragged position (and re-clamp after the first measure).
  useEffect(() => {
    if (pos === null) return
    try {
      window.localStorage.setItem(STORAGE_POS_KEY, JSON.stringify(pos))
    } catch {
      // Storage unavailable (private mode): the position just does not persist.
    }
  }, [pos])

  useEffect(() => {
    try {
      if (minimal) window.localStorage.setItem(STORAGE_MINIMAL_KEY, '1')
      else window.localStorage.removeItem(STORAGE_MINIMAL_KEY)
    } catch {
      // Storage unavailable: the choice just does not persist.
    }
  }, [minimal])

  // Keep the badge inside the viewport when the window resizes. Pure
  // functional updates keep the listener fresh without re-registering.
  useEffect(() => {
    if (badgeSize === null) return
    const onResize = (): void => {
      setPos((prev) => {
        if (prev === null) return prev
        return clampToViewport(prev, badgeSize.w, badgeSize.h)
      })
    }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [badgeSize])

  // Measure the badge whenever its content (minimal mode) or position changes,
  // and re-clamp a persisted position that has drifted out of the viewport.
  useLayoutEffect(() => {
    const badge = badgeRef.current
    if (badge === null) return
    const next = { w: badge.offsetWidth, h: badge.offsetHeight }
    setBadgeSize((prev) => (prev !== null && prev.w === next.w && prev.h === next.h ? prev : next))
    setPos((prev) => {
      if (prev === null) return prev
      const clamped = clampToViewport(prev, next.w, next.h)
      return clamped.x === prev.x && clamped.y === prev.y ? prev : clamped
    })
  }, [minimal, pos?.x, pos?.y])

  // Measure the panel once it is visible, so flipping can use its real size.
  useLayoutEffect(() => {
    if (!open || closing) return
    const panel = panelRef.current
    if (panel === null) return
    const next = { w: panel.offsetWidth, h: panel.offsetHeight }
    setPanelSize((prev) => (prev !== null && prev.w === next.w && prev.h === next.h ? prev : next))
  }, [open, closing, minimal])

  const openPanel = (): void => {
    setClosing(false)
    setOpen(true)
  }

  const requestClose = (): void => {
    if (!open) return
    // Under reduced motion, skip the exit tween and unmount right away so the
    // panel does not sit waiting for an onAnimationEnd that never fires.
    if (prefersReducedMotion()) {
      setClosing(false)
      setOpen(false)
      return
    }
    setClosing(true)
  }

  const handlePanelAnimationEnd = (): void => {
    if (closing) {
      setClosing(false)
      setOpen(false)
    }
  }

  const handleRefresh = async (): Promise<void> => {
    if (refreshing) return
    setRefreshing(true)
    try {
      setState(await refreshState())
      setNow(Date.now())
    } catch {
      // The next poll will surface host-side health; keep the current sample.
    } finally {
      setRefreshing(false)
    }
  }

  // --- Badge dragging -----------------------------------------------------

  const beginDrag = (event: ReactPointerEvent<HTMLButtonElement>): void => {
    if (event.pointerType === 'mouse' && event.button !== 0) return
    const rect = event.currentTarget.getBoundingClientRect()
    const origin = pos ?? { x: rect.left, y: rect.top }
    dragRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      originX: origin.x,
      originY: origin.y,
      sizeW: rect.width,
      sizeH: rect.height,
      moved: false,
    }
    event.currentTarget.setPointerCapture(event.pointerId)
  }

  const moveDrag = (event: ReactPointerEvent<HTMLButtonElement>): void => {
    const session = dragRef.current
    if (session === null || session.pointerId !== event.pointerId) return
    const dx = event.clientX - session.startX
    const dy = event.clientY - session.startY
    if (!session.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD_PX) return
    session.moved = true
    setDragging(true)
    setPos(clampToViewport(
      { x: session.originX + dx, y: session.originY + dy },
      session.sizeW,
      session.sizeH,
    ))
  }

  const finishDrag = (event: ReactPointerEvent<HTMLButtonElement>): void => {
    const session = dragRef.current
    if (session === null || session.pointerId !== event.pointerId) return
    dragRef.current = null
    setDragging(false)
    // A real drag must not toggle the panel: the click that follows pointer
    // capture is suppressed once.
    if (session.moved) suppressClickRef.current = true
  }

  // Pointer capture can be cancelled by the browser (e.g. a touch gesture
  // being taken over); no click follows, so the next real click must not be
  // swallowed by a suppression flag left over from a moved session.
  const cancelDrag = (event: ReactPointerEvent<HTMLButtonElement>): void => {
    const session = dragRef.current
    if (session === null || session.pointerId !== event.pointerId) return
    dragRef.current = null
    setDragging(false)
  }

  const handleBadgeClick = (): void => {
    if (suppressClickRef.current) {
      suppressClickRef.current = false
      return
    }
    if (open) requestClose()
    else openPanel()
  }

  // --- Panel placement (follows the dragged badge, stays in the viewport) --

  const panelLayout: PanelLayout | null = useMemo(() => {
    if (pos === null || badgeSize === null || panelSize === null) return null
    return computePanelLayout(pos, badgeSize, panelSize, {
      w: window.innerWidth,
      h: window.innerHeight,
    })
  }, [pos, badgeSize, panelSize])

  const handleToggleMinimal = (): void => {
    setMinimal((prev) => !prev)
  }

  const windows = usageWindows(stateHasUsage(state) ? state.usage : undefined)
  const rolling = windows.find((window) => window.key === 'rolling')
  // Minimal mode shows only the 5h-rolling window everywhere.
  const visibleWindows = minimal
    ? (rolling !== undefined ? [rolling] : [])
    : windows

  // State-dot semantics map onto the shared StateDot states:
  // connecting → ongoing, live → done, stale → warning, error/unconfigured → error.
  const dotState = state === null ? 'ongoing'
    : state.health.status === 'ok' ? 'done'
    : stateHasUsage(state) ? 'warning'
    : 'error'

  // ErrorBox variant: an info tone for connecting / unconfigured prompts, an
  // error tone for real fetch failures (the previous single warn tone
  // conflated both).
  const errorVariant = state === null || state.health.status === 'unconfigured' ? 'info' : 'error'

  return (
    <div
      className={styles.dock}
      data-positioned={pos !== null ? 'true' : undefined}
      style={pos !== null ? { left: pos.x, top: pos.y } : undefined}
    >
      <button
        ref={badgeRef}
        type="button"
        className={styles.badge}
        data-dragging={dragging ? 'true' : undefined}
        onClick={handleBadgeClick}
        onPointerDown={beginDrag}
        onPointerMove={moveDrag}
        onPointerUp={finishDrag}
        onPointerCancel={cancelDrag}
        title="OpenCode Go 用量：滚/周/月配额 + 5h 滚动重置倒计时（拖拽可移动）"
        aria-expanded={open}
        aria-label="OpenCode Go 用量"
      >
        {minimal ? (
          rolling !== undefined ? (
            // Minimal mode: a single 5h-rolling ring at the badge's regular
            // mini size; only the ring and its centered percent remain.
            <Ring window={rolling} now={now} size={36} />
          ) : (
            <span className={styles.badgeText}>Go —</span>
          )
        ) : (
          windows.length > 0 ? (
            <>
              {windows.map((window) => (
                <Ring
                  key={window.key}
                  window={window}
                  now={now}
                  size={36}
                />
              ))}
              {rolling !== undefined && (
                <span className={styles.badgeCountdown} title="5h 滚动窗口重置倒计时">
                  <span className={styles.badgeCountdownIcon} aria-hidden="true">↻</span>
                  <span className={styles.badgeCountdownValue}>
                    {formatRemainingCompact(rolling.resetsAt, now)}
                  </span>
                </span>
              )}
            </>
          ) : (
            <span className={styles.badgeText}>Go —</span>
          )
        )}
        {/* Minimal mode keeps strictly the single ring; the health dot would
            be the only other element on the badge, so it stays hidden. */}
        {!minimal && <StateDot state={dotState} size={9} />}
      </button>
      {open && (
        <section
          ref={panelRef}
          className={styles.panel}
          data-closing={closing || undefined}
          data-below={panelLayout?.below ? 'true' : undefined}
          data-left={panelLayout?.useLeft ? 'true' : undefined}
          style={panelLayout?.useLeft ? { left: panelLayout.leftOffset } : undefined}
          role="dialog"
          aria-label="OpenCode Go 用量"
          onAnimationEnd={handlePanelAnimationEnd}
        >
          <header className={styles.panelHeader}>
            <div className={styles.panelTitle}>
              <span className={styles.panelLogo} aria-hidden="true">◈</span>
              <span>OpenCode Go 用量</span>
              <span className={styles.healthLabel}>
                {state === null ? '连接中…'
                  : state.health.status === 'ok' ? '实时'
                  : stateHasUsage(state) ? '数据过期'
                  : '异常'}
              </span>
            </div>
            <div className={styles.panelHeaderActions}>
              <button
                type="button"
                role="switch"
                aria-checked={minimal}
                className={styles.minimalSwitch}
                onClick={handleToggleMinimal}
                title="极简模式：仅显示 5h 滚动环"
              >
                <span className={styles.minimalSwitchLabel}>极简</span>
                <span className={styles.minimalSwitchTrack} aria-hidden="true">
                  <span className={styles.minimalSwitchThumb} />
                </span>
              </button>
              <button
                type="button"
                className={styles.iconButton}
                onClick={requestClose}
                aria-label="关闭"
              >
                ✕
              </button>
            </div>
          </header>

          {state !== null && stateHasUsage(state) ? (
            <div className={styles.windows}>
              {visibleWindows.map((window) => (
                <WindowRow key={window.key} window={window} now={now} />
              ))}
              {visibleWindows.length === 0 && (
                <p className={styles.emptyNote}>用量服务未返回任何窗口数据。</p>
              )}
            </div>
          ) : (
            <div className={styles.errorBox} data-variant={errorVariant}>
              <p className={styles.errorTitle}>
                {state === null ? '正在连接用量服务…'
                  : state.health.status === 'unconfigured' ? '尚未配置 API Key'
                  : '用量获取失败'}
              </p>
              <p className={styles.errorDetail}>
                {state === null
                  ? '如果长时间停留在该状态，请检查 dsh 服务是否运行了 dsh-opencode-go-usage 插件。'
                  : state.health.error}
              </p>
              {state !== null && state.health.status === 'unconfigured' && (
                <p className={styles.errorHint}>
                  配置方法：打开 Web 设置 → 模型，选择「官方渠道 · OpenCode Go」，填入 API Key
                  后稍候片刻即会自动生效。
                </p>
              )}
            </div>
          )}

          <footer className={styles.panelFooter}>
            <span className={styles.updatedAt}>
              {state === null ? '' : `更新于 ${formatRelative(state.usageFetchedAt ?? state.health.fetchedAt, now)}`}
              {state !== null && stateHasUsage(state) && state.health.status !== 'ok' && (
                <span className={styles.staleNote}> · 刷新失败，显示上次数据</span>
              )}
            </span>
            <a
              className={styles.consoleLink}
              href="https://opencode.ai/auth"
              target="_blank"
              rel="noopener noreferrer"
              title="在浏览器中打开 OpenCode Go 控制台"
            >
              控制台 <span aria-hidden="true">↗</span>
            </a>
            <Button
              variant="outline"
              size="sm"
              type="button"
              onClick={() => { void handleRefresh() }}
              disabled={refreshing}
            >
              {refreshing ? '刷新中…' : '立即刷新'}
            </Button>
          </footer>
        </section>
      )}
    </div>
  )
}

/** One quota window row: ring + labels + countdown. The ring mirrors the
   collapsed badge's double ring (used-percent outer + brand-blue remaining-
   time inner), and inline legend dots restate the color coding for the row:
   a green/amber/red dot before "已用" restates the usage ring color, a blue
   dot before "重置于" restates the inner remaining-time ring color. */
function WindowRow({ window, now }: { window: WindowView; now: number }): ReactElement {
  const remaining = Math.max(0, 100 - window.percent)
  const tone = percentTone(window.percent)
  return (
    <div className={styles.windowRow}>
      <Ring window={window} now={now} />
      <div className={styles.windowBody}>
        <div className={styles.windowName}>
          <span>{window.label}</span>
          <span className={styles.windowSublabel}>{window.sublabel}</span>
        </div>
        <div className={styles.windowMeta}>
          <span className={styles.usedText}>
            <span className={styles.rowDot} data-tone={tone} aria-hidden="true" />
            已用 {window.percent}%
          </span>
          <span className={styles.remainingText}>剩余 {remaining}%</span>
        </div>
        <div className={styles.countdown}>
          <span className={styles.rowDot} data-tone="time" aria-hidden="true" />
          重置于 {formatRemaining(window.resetsAt, now)}
        </div>
      </div>
    </div>
  )
}

/**
 * Double ring for one quota window, shared by the collapsed badge (size 36),
 * the expanded panel row (size 50), and minimal mode's single 5h-rolling ring
 * (size 36). The outer ring shows the *remaining* quota share as an arc (full
 * ring at 0% used, shrinking as quota is spent) and is threshold-colored by
 * spent share: green <60% spent / orange ≥60% / red ≥85% — so a low remaining
 * share reads as red. The inner ring is the share of the window period still
 * left before its reset, drawn in the DS brand tone
 * (`--dsw-alias-state-business-primary`) and hugging the outer ring with no
 * visible gap so the two read as one bicolored band. Rounded caps switch to
 * butt at both ends of the arc (0% and 100% remaining) so neither an empty
 * nor a full ring shows a phantom or bumpy seam, and the dash transition
 * tweens in for a smooth shrink on refresh. The centered text shows the
 * remaining percent. Fixed SVG dimensions keep the layout stable regardless
 * of font fallback or zoom.
 * @param window - the projected quota window view (percent, reset, periodMs).
 * @param now - current epoch ms (drives the inner remaining-time arc).
 * @param size - outer diameter in px (50 for the panel, 36 for the badge).
 */
export function Ring({ window, now, size = 50 }: {
  window: WindowView
  now: number
  size?: number
}): ReactElement {
  const stroke = size >= 44 ? 5 : 3.5
  const timeStroke = size >= 44 ? 3 : 2.5
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const used = Math.min(100, Math.max(0, window.percent))
  // Outer ring is the remaining quota share: 100% - used. A 0%-used window
  // therefore draws a full ring, and the ring empties as quota is consumed.
  const quotaLeft = 100 - used
  const dash = (circumference * quotaLeft) / 100
  const ringEmpty = quotaLeft <= 0
  const ringFull = quotaLeft >= 100
  const tone = percentTone(used)

  // Inner ring hugs the outer ring tight (zero gap): its center radius sits
  // exactly at the outer ring's inner edge minus half the inner stroke, so the
  // two colored strokes touch edge-to-edge as one band.
  const timeRadius = radius - (stroke + timeStroke) / 2
  const timeCircumference = 2 * Math.PI * timeRadius
  const remaining = remainingRatio(window.resetsAt, window.periodMs, now)
  const timeDash = timeCircumference * remaining
  const timeEmpty = remaining <= 0

  return (
    <svg
      className={styles.ring}
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      role="img"
      aria-label={`${window.label}剩余额度 ${Math.round(quotaLeft)}%，窗口剩余时间 ${Math.round(remaining * 100)}%`}
    >
      <circle
        className={styles.ringTrack}
        cx={size / 2}
        cy={size / 2}
        r={radius}
        strokeWidth={stroke}
        fill="none"
      />
      <circle
        className={styles.ringBar}
        data-tone={tone}
        data-zero={ringEmpty ? 'true' : 'false'}
        data-full={ringFull ? 'true' : 'false'}
        cx={size / 2}
        cy={size / 2}
        r={radius}
        strokeWidth={stroke}
        fill="none"
        strokeDasharray={`${dash} ${circumference - dash}`}
        strokeDashoffset={circumference / 4}
        strokeLinecap={ringEmpty || ringFull ? 'butt' : 'round'}
      />
      <circle
        className={styles.ringTimeTrack}
        cx={size / 2}
        cy={size / 2}
        r={timeRadius}
        strokeWidth={timeStroke}
        fill="none"
      />
      <circle
        className={styles.ringTimeBar}
        data-zero={timeEmpty ? 'true' : 'false'}
        cx={size / 2}
        cy={size / 2}
        r={timeRadius}
        strokeWidth={timeStroke}
        fill="none"
        strokeDasharray={`${timeDash} ${timeCircumference - timeDash}`}
        strokeDashoffset={timeCircumference / 4}
        strokeLinecap={timeEmpty ? 'butt' : 'round'}
      />
      <text
        className={size >= 44 ? styles.ringText : styles.badgeRingText}
        x="50%"
        y="50%"
        dominantBaseline="central"
        textAnchor="middle"
      >
        {Math.round(quotaLeft)}%
      </text>
    </svg>
  )
}