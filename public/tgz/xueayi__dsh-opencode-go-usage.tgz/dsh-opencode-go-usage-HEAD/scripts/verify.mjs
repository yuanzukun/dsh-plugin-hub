#!/usr/bin/env node
/**
 * Offline smoke verification for dsh-opencode-usage.
 *
 * Runs the pure usage-parsing rules and the browser dock display projections
 * against fixed fixtures. Requires a prior `pnpm build` (lib/ present).
 * Does not touch the network or any running DSH instance.
 *
 * Usage: node scripts/verify.mjs
 */

import { parseUsageBody, fetchOpenCodeUsage } from '../lib/usage.js'
import {
  clampDockPosition, computePanelLayout, PANEL_GAP_PX, formatRelative,
  formatRemaining, formatRemainingCompact, percentTone, remainingRatio,
  stateHasUsage, usageWindows, WINDOW_PERIOD_MS,
} from '../lib/client/usage-model.js'

let failures = 0
function check(label, condition, detail = '') {
  if (condition) {
    console.log(`  PASS  ${label}`)
  } else {
    failures += 1
    console.error(`  FAIL  ${label}${detail ? ` — ${detail}` : ''}`)
  }
}

console.log('usage parse')
{
  const sample = parseUsageBody({
    usage: {
      rolling: { status: 'ok', percent: 51, resetsAt: '2026-08-15T19:40:30.751Z' },
      weekly: { status: 'ok', percent: 32, resetsAt: '2026-08-17T00:00:00.751Z' },
      monthly: { status: 'ok', percent: 16, resetsAt: '2026-09-15T07:08:59.751Z' },
    },
  })
  check('parses a full sample', sample !== undefined)
  check('rolling percent', sample?.rolling?.percent === 51, String(sample?.rolling?.percent))
  check('monthly percent', sample?.monthly?.percent === 16, String(sample?.monthly?.percent))
  check('resetsAt kept verbatim', sample?.weekly?.resetsAt === '2026-08-17T00:00:00.751Z')

  check('rejects a non-object body', parseUsageBody(null) === undefined)
  check('rejects a missing usage key', parseUsageBody({ foo: 1 }) === undefined)
  check('rejects a malformed window', parseUsageBody({ usage: { rolling: { status: 'ok' } } }) === undefined)
  const partial = parseUsageBody({ usage: { rolling: { status: 'ok', percent: 1, resetsAt: 'x' } } })
  check('accepts a partial sample with one window', partial?.rolling?.percent === 1)
  check('drops unknown window keys', partial?.monthly === undefined)
}

console.log('fetch failure path')
{
  const failure = await fetchOpenCodeUsage('not-a-url', 'sk-test', 2000)
    .then(() => 'resolved')
    .catch((error) => error instanceof Error ? error.message : 'non-error')
  check('fetch rejects with a user-facing message', failure !== 'resolved' && failure.length > 0, failure)
}

console.log('state model')
{
  const withData = {
    usage: { rolling: { status: 'ok', percent: 1, resetsAt: 'x' } },
    usageFetchedAt: 1,
    health: { status: 'error', fetchedAt: 2, error: 'boom' },
  }
  const withoutData = { health: { status: 'unconfigured', fetchedAt: 3, error: 'no key' } }
  check('state with usage is usable', stateHasUsage(withData) === true)
  check('state without usage is not usable', stateHasUsage(withoutData) === false)
  check('null state is not usable', stateHasUsage(null) === false)
  const windows = usageWindows(withData.usage)
  check('windows still project from kept data', windows.length === 1 && windows[0].percent === 1)
}

console.log('dock projections')
{
  const now = Date.parse('2026-08-15T12:00:00.000Z')
  const usage = {
    rolling: { status: 'ok', percent: 51, resetsAt: '2026-08-15T19:40:30.751Z' },
    monthly: { status: 'ok', percent: 16, resetsAt: '2026-09-15T07:08:59.751Z' },
  }
  const windows = usageWindows(usage)
  check('windows in display order', windows.map((w) => w.key).join(',') === 'rolling,monthly', windows.map((w) => w.key).join(','))
  check('weekly dropped when absent', windows.length === 2, String(windows.length))
  check('labels', windows[0]?.label === '5h 滚动' && windows[1]?.label === '本月')

  check('tone ok below 60', percentTone(16) === 'ok')
  check('tone warn at 60', percentTone(60) === 'warn')
  check('tone danger at 85', percentTone(85) === 'danger')
  check('tone clamps unknown', percentTone(Number.NaN) === 'ok')

  check('countdown days+hours', formatRemaining(Date.parse('2026-08-19T12:00:00.000Z'), now) === '4天0小时')
  check('countdown hours+minutes', formatRemaining(Date.parse('2026-08-15T15:30:00.000Z'), now) === '3小时30分')
  check('countdown minutes+seconds', formatRemaining(Date.parse('2026-08-15T12:05:30.000Z'), now) === '5分30秒')
  check('countdown seconds', formatRemaining(Date.parse('2026-08-15T12:00:45.000Z'), now) === '45秒')
  check('countdown expired', formatRemaining(now - 1000, now) === '已重置')

  check('compact days', formatRemainingCompact(Date.parse('2026-08-19T12:00:00.000Z'), now) === '4d')
  check('compact days+hours', formatRemainingCompact(Date.parse('2026-08-18T15:00:00.000Z'), now) === '3d3h')
  check('compact hours+minutes', formatRemainingCompact(Date.parse('2026-08-15T15:30:00.000Z'), now) === '3h30m')
  check('compact minutes+seconds', formatRemainingCompact(Date.parse('2026-08-15T12:05:07.000Z'), now) === '5m07s')
  check('compact seconds', formatRemainingCompact(Date.parse('2026-08-15T12:00:09.000Z'), now) === '9s')
  check('compact expired', formatRemainingCompact(now - 1000, now) === '已重置')

  check('relative just now', formatRelative(now, now + 3000) === '刚刚')
  check('relative seconds', formatRelative(now, now + 30_000) === '30秒前')
  check('relative minutes', formatRelative(now, now + 5 * 60_000) === '5分钟前')
  check('relative hours', formatRelative(now, now + 3 * 3_600_000) === '3小时前')
  check('relative days', formatRelative(now, now + 50 * 3_600_000) === '2天前')

  check('rolling period is 5h', WINDOW_PERIOD_MS.rolling === 5 * 60 * 60 * 1000)
  check('weekly period is 7d', WINDOW_PERIOD_MS.weekly === 7 * 24 * 60 * 60 * 1000)
  check('monthly period is 30d', WINDOW_PERIOD_MS.monthly === 30 * 24 * 60 * 60 * 1000)
  check('remaining half', remainingRatio(now + 30 * 60 * 1000, 60 * 60 * 1000, now) === 0.5)
  check('remaining full clamps to 1', remainingRatio(now + 90 * 60 * 1000, 60 * 60 * 1000, now) === 1)
  check('remaining expired is 0', remainingRatio(now - 1000, 60 * 60 * 1000, now) === 0)
  check('remaining guards bad inputs', remainingRatio(Number.NaN, 60 * 60 * 1000, now) === 0)
  const view = usageWindows({ rolling: { status: 'ok', percent: 51, resetsAt: '2026-08-15T19:40:30.751Z' } })[0]
  check('window carries its period', view?.periodMs === WINDOW_PERIOD_MS.rolling, String(view?.periodMs))
}

console.log('dock dragging')
{
  const viewport = { w: 1000, h: 800 }

  const inside = clampDockPosition({ x: 50, y: 60 }, { w: 90, h: 48 }, viewport)
  check('clamp keeps interior position', inside.x === 50 && inside.y === 60)

  const leftTop = clampDockPosition({ x: -20, y: -5 }, { w: 90, h: 48 }, viewport)
  check('clamp pulls back from top-left', leftTop.x === 0 && leftTop.y === 0)

  const rightBottom = clampDockPosition({ x: 1000, y: 900 }, { w: 90, h: 48 }, viewport)
  check('clamp pulls back from bottom-right', rightBottom.x === 910 && rightBottom.y === 752)

  const oversized = clampDockPosition({ x: -10, y: 100 }, { w: 1200, h: 1000 }, viewport)
  check('clamp clamps oversized badges to zero', oversized.x === 0 && oversized.y === 0)
}

console.log('dock panel flipping')
{
  const viewport = { w: 1000, h: 800 }
  const badge = { w: 90, h: 48 }
  const panel = { w: 362, h: 300 }

  const below = computePanelLayout({ x: 800, y: 20 }, badge, panel, viewport)
  check('panel flips below near the top', below.below === true, String(below.below))

  const above = computePanelLayout({ x: 800, y: 400 }, badge, panel, viewport)
  check('panel stays above lower down', above.below === false, String(above.below))

  const rightAligned = computePanelLayout({ x: 500, y: 400 }, badge, panel, viewport)
  check('panel right-aligned by default', rightAligned.useLeft === false && rightAligned.leftOffset === 0)

  const leftAligned = computePanelLayout({ x: 0, y: 400 }, badge, panel, viewport)
  check('panel flips left-aligned near the left edge', leftAligned.useLeft === true && leftAligned.leftOffset === 0)

  const narrow = { w: 500, h: 800 }
  const nudged = computePanelLayout({ x: 200, y: 400 }, badge, panel, narrow)
  check('left-aligned panel nudged back inside a narrow viewport', nudged.useLeft === true && nudged.leftOffset < 0, String(nudged.leftOffset))
  check('nudged panel fits the viewport', nudged.leftOffset + 200 >= 0 && 200 + panel.w + nudged.leftOffset <= narrow.w)

  check('panel gap constant is positive', PANEL_GAP_PX === 12, String(PANEL_GAP_PX))
  const threshold = computePanelLayout({ x: 500, y: panel.h + PANEL_GAP_PX - 1 }, badge, panel, viewport)
  const clear = computePanelLayout({ x: 500, y: panel.h + PANEL_GAP_PX }, badge, panel, viewport)
  check('flip threshold honours the gap', threshold.below === true && clear.below === false)
}

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`)
  process.exit(1)
}
console.log('\nall checks passed')
