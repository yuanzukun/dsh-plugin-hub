/**
 * Pure display projections for the OpenCode Go usage dock.
 *
 * No React, no DOM: every function here is trivially unit-testable, mirroring
 * the host-side purity split. The dock renders the three quota windows as
 * rings with a live reset countdown; tones follow a soft threshold so the
 * panel stays calm until usage climbs.
 * @module dsh-opencode-go-usage/client/model
 */
import type { OpenCodeUsageData, OpenCodeUsageState } from '../types.ts';
/** One quota window in display order. */
export interface WindowView {
    key: 'rolling' | 'weekly' | 'monthly';
    /** Short Chinese label for the panel row. */
    label: string;
    /** English label kept for recognizability. */
    sublabel: string;
    /** Percent already used, 0–100. */
    percent: number;
    /** Epoch millis when the window resets. */
    resetsAt: number;
    /** Full window period in millis (drives the remaining-time ring). */
    periodMs: number;
}
/** Tone thresholds for usage rings; `danger` ≥ 85%, `warn` ≥ 60%. */
export type UsageTone = 'ok' | 'warn' | 'danger';
/** Top-left viewport position of the dock badge. */
export interface DockPosition {
    x: number;
    y: number;
}
/** A measured badge or panel box. */
export interface BoxSize {
    w: number;
    h: number;
}
/** Panel placement relative to the dock wrapper (the badge box). */
export interface PanelLayout {
    /** Panel opens below the badge instead of above (top edge would clip). */
    below: boolean;
    /** Panel is left-aligned with the badge instead of right-aligned. */
    useLeft: boolean;
    /** Left offset relative to the badge in px when `useLeft`; negative only
       when left-aligning would overflow the right edge, nudging the panel back
       inside the viewport. */
    leftOffset: number;
}
/** Gap between the badge and the panel, in px. */
export declare const PANEL_GAP_PX = 12;
/**
 * Clamp a dock position so the badge stays fully inside the viewport.
 * `size` is the badge box; oversized badges clamp to zero.
 */
export declare function clampDockPosition(pos: DockPosition, size: BoxSize, viewport: {
    w: number;
    h: number;
}): DockPosition;
/**
 * Decide where the panel sits relative to the badge: above by default,
 * flipping below when the top edge would clip, and right-aligned by default,
 * flipping to left-aligned (with a negative nudge when needed) when the badge
 * sits close enough to the left edge that a right-aligned panel would clip.
 */
export declare function computePanelLayout(pos: DockPosition, badgeSize: BoxSize, panelSize: BoxSize, viewport: {
    w: number;
    h: number;
}): PanelLayout;
/** Window periods: rolling is a fixed 5h, weekly a fixed 7d; monthly uses a
 *  30-day approximation of the subscription cycle (the API only reports the
 *  next reset instant, so the exact cycle cannot be derived). */
export declare const WINDOW_PERIOD_MS: Record<WindowView['key'], number>;
/** Project a usage sample into ordered window views (missing windows dropped). */
export declare function usageWindows(usage: OpenCodeUsageData | undefined): WindowView[];
/**
 * Fraction of the window period still left before the reset, 0–1; the
 * badge's inner ring draws this as its remaining arc. Returns 0 once the
 * reset instant has passed (the next refresh will report a fresh window).
 */
export declare function remainingRatio(resetsAt: number, periodMs: number, now: number): number;
/** Tone for a used percentage (invalid numbers clamp to `ok`). */
export declare function percentTone(percent: number): UsageTone;
/** Compact Chinese countdown until a reset instant. */
export declare function formatRemaining(resetsAt: number, now: number): string;
/** Minimal countdown for tight surfaces (the dock badge): `4d3h`, `3h25m`, `12m05s`, `9s`. */
export declare function formatRemainingCompact(resetsAt: number, now: number): string;
/** Human-readable age of a sample. */
export declare function formatRelative(fetchedAt: number, now: number): string;
/** Whether a state carries usable quota windows (kept across failed refreshes). */
export declare function stateHasUsage(state: OpenCodeUsageState | null): state is OpenCodeUsageState & {
    usage: OpenCodeUsageData;
};
/** Fetch the current cached sample from the plugin route. */
export declare function fetchState(): Promise<OpenCodeUsageState>;
/** Ask the host for an immediate refresh and return the new sample. */
export declare function refreshState(): Promise<OpenCodeUsageState>;
