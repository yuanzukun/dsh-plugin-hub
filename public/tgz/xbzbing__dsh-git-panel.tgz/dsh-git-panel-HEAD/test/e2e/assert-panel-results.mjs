import assert from 'node:assert/strict'

export function assertPanelResults(out, realInput, errors) {
  assert.equal(out.error, undefined, out.error)
  assert.deepEqual(out.slots.sort(), ['conversation.input.left', 'conversation.view', 'plugins.bundle.config'])
  assert.equal(out.pillHasDirty, true, 'dirty pill shows the orange git class')
  assert.equal(out.viewOrder, 30, 'panel is ordered after Chat/Trajectory')
  assert.equal(out.tabCount, 3, 'three sub-tabs')
  assert.equal(out.dirtyDefault, true, 'opening a dirty Git workspace defaults to Changes')
  assert.deepEqual(out.sameFingerprintPolling, {
    panelRenders: 0, pillRenders: 0, queries: ['diff', 'diff', 'stash-list', 'stash-list'],
    freshDiff: true, nonTipStashRemoved: true, relativeStatsUpdated: true,
  }, 'same-business polls keep Panel/pill idle while refreshing current diff, stash and relative time')
  assert.deepEqual(out.confirmationState, {
    sameFingerprint: {
      discardArmed: true, draftPreserved: true, suggestCallsBeforeConfirmation: 0, suggestConfirmed: true,
    },
    businessChanged: {
      rowRetained: true, discardReset: true, draftPreserved: true, firstClicksOnlyArm: true,
    },
  }, 'same-fingerprint polling preserves armed discard/suggest confirmations while business changes reset them')
  assert.deepEqual(out.fetchFailureFeedback, [
    {
      entry: 'toolbar', singleFlight: true, failureActions: ['fetch'], visible: true,
      errorText: 'error.authFailed', detailAvailable: true, clearedOnRetry: true,
      restoredAfterSuccess: true, retryQueries: ['authors', 'branches', 'history', 'tags'],
    },
    {
      entry: 'statusbar', singleFlight: true, failureActions: ['fetch'], visible: true,
      errorText: 'fetch refused: statusbar', detailAvailable: true, clearedOnRetry: true,
      restoredAfterSuccess: true, retryQueries: ['authors', 'branches', 'history', 'tags'],
    },
  ], 'both fetch entrances expose failures, share busy, and recover on retry')
  assert.deepEqual(out.sameFingerprintAction, {
    kind: 'stash-drop', queriesAfterAction: ['diff', 'stash-list'], queriesAfterOldPoll: ['diff', 'stash-list'],
  }, 'action accept refreshes one batch and an older held poll cannot refresh again')
  assert.deepEqual(out.sameFingerprintOverviewClock, {
    before: 'time.justNow', after: 'time.minutesAgo{"n":1}', queries: ['authors', 'branches', 'history', 'tags'],
  }, 'Overview clock advances on query ticks even with the same business snapshot and history array')
  assert.deepEqual(out.tagCreateRefresh, {
    action: { kind: 'tag-create', name: 'p1-refresh-tag', commit: 'fixed-clock-commit' },
    queries: ['authors', 'branches', 'history', 'tags'], snapshots: 0, panelRenders: 0, sameBusiness: true,
  }, 'a real tag-create UI operation refreshes one local batch without a snapshot tick or business publish')
  assert.deepEqual(out.toolbarFetchRefresh, {
    kind: 'fetch', queries: ['authors', 'branches', 'history', 'tags'],
    queriesAfterOldPoll: ['authors', 'branches', 'history', 'tags'],
  }, 'the history toolbar fetch routes through accept and refreshes one batch even with an older held poll')
  assert.deepEqual(out.snapshotErrorRecovery, {
    errorShown: true, queriesWhileFailed: [], remounted: true,
    queries: ['authors', 'branches', 'history', 'tags'], overviewActive: true,
  }, 'a snapshot failure unmounts Git tabs and recovery remounts only the active query batch once')
  assert.deepEqual(out.secondaryFailuresKeepBranches, [
    { kind: 'tags', injected: true, visible: true, error: false },
    { kind: 'authors', injected: true, visible: true, error: false },
  ], 'secondary query failures must not replace successful branches with an error pane')
  assert.deepEqual(out.repeatedDiffReloads, { firstLoaded: true, requests: 1, revision: 2, freshRendered: true, loading: false, snapshots: 0 },
    'reopening the same diff must request and render fresh data without a snapshot tick')
  assert.equal(out.visibilityNoHiddenImageStage, true, 'a binary diff completed hidden cannot start image-side queries')
  assert.equal(out.visibilityWaitsForSnapshot, true, 'restoring Changes waits for one fresh snapshot before queries')
  assert.deepEqual(out.visibilityChangesCatchup, ['diff', 'stash-list'], 'restored Changes issues one batch, hidden overview stays idle')
  assert.equal(out.visibilityOverviewWaits, true, 'restoring Overview does not query using the pre-hide snapshot')
  assert.deepEqual(out.visibilityOverviewCatchup, ['authors', 'branches', 'history', 'tags'], 'restored Overview issues one batch, hidden Changes stays idle')
  assert.equal(out.visibilityFilesNoQueries, true, 'Files active leaves resident overview/Changes idle after restore')
  assert.equal(out.noInitialFileListing, true, 'dirty default does not fetch hidden file-browser data')
  assert.equal(out.fontDefault, '13px', 'panel keeps the existing default font size')
  assert.equal(out.fontIncreased, '14px', 'font control increases panel text size')
  assert.equal(out.fontStored, '1', 'font adjustment writes the host config field')
  assert.equal(out.fontReset, '13px', 'font reset restores default size')
  assert.equal(out.fontPressedDefault, true, 'the default font step is marked as pressed')
  assert.equal(out.fontPressedIncreased, true, 'the pressed step follows the current font size')
  assert.equal(out.fontPressedReset, true, 'resetting returns the pressed mark to the middle step')
  assert.equal(out.fontWriteFailRolledBack, true, 'a failed config write rolls the optimistic font step back')
  assert.equal(out.fontPressedStyle, true, 'the pressed step uses the business tint and bold weight')
  assert.equal(out.wideLayout, 'wide', 'a wide panel uses the three-column wide layout')
  assert.equal(out.wideShowsControls, true, 'a wide panel shows the trailing controls')
  assert.equal(out.wideShowsLabel, true, 'a wide panel shows the tab labels')
  assert.equal(out.wideShowsVersion, true, 'a wide panel shows the version cluster')
  assert.equal(out.wideLabelFull, 'tab.overview', 'the wide layout keeps the long tab label')
  assert.equal(out.versionIconAligned, true, 'the update-check glyph is centred on its label line')
  assert.equal(out.narrowLayout, 'compact', 'a phone-width panel switches to the compact layout')
  assert.equal(out.narrowFontUnmounted, true, 'the compact layout drops the font stepper (config page owns it)')
  assert.equal(out.narrowShowsLabel, true, 'the compact layout shows the short tab labels')
  assert.equal(out.narrowShortLabel, 'tab.overviewShort', 'compact swaps in the short label key')
  assert.equal(out.narrowIndicatorTracksTab, true, 'the compact indicator tracks the selected column')
  assert.equal(out.narrowKeepsIcon, true, 'the compact tab keeps its icon')
  assert.equal(out.narrowHidesVersion, true, 'the compact layout does not mount the version cluster')
  assert.ok(out.narrowTabBarRows < 60, `the compact tab bar stays a single row (${out.narrowTabBarRows}px)`)
  assert.equal(out.tinyShowsLabel, true, 'a very narrow panel still shows the short labels')
  assert.equal(out.tinyKeepsIcon, true, 'a very narrow panel keeps the tab icons')
  assert.equal(out.tinyFontUnmounted, true, 'a very narrow compact panel still has no font stepper')
  assert.equal(out.restoresLayout, 'wide', 'widening the panel restores the wide layout')
  assert.equal(out.restoresLabel, true, 'widening the panel restores the tab labels')
  assert.equal(out.restoresVersion, true, 'widening the panel restores the version cluster')
  assert.equal(out.restoresFont, true, 'widening the panel restores the font stepper')
  assert.equal(out.hasStats, true, 'stats bar rendered')
  assert.equal(out.hasCommitBox, true, 'commit box rendered')
  assert.equal(out.squeezedLayout, 'compact', 'a 400px desktop panel is the compact layout')
  assert.equal(out.squeezedKeepsEditor, true, 'a squeezed desktop panel keeps the full commit editor (not a phone)')
  assert.equal(out.squeezedNoCommitBar, true, 'no folded commit bar on a desktop viewport')
  assert.equal(out.squeezedNoFoldControl, true, 'no fold control when the editor cannot fold')
  assert.equal(out.squeezedShowsAi, true, 'the AI entry stays visible in a squeezed desktop panel (issue #66)')
  assert.equal(out.squeezedPressKeepsEditor, true, 'a press outside the editor leaves it open when it cannot fold')
  assert.equal(out.commitActionsNowrap, true, 'AI suggest / Commit labels never wrap to a second line')
  assert.equal(out.commitActionsInsideRow, true, 'the commit actions stay inside the panel at phone width')
  assert.equal(out.amendLabelSingleLine, true, 'the Amend label stays on one line')
  assert.equal(out.compactStatsShowsTimes, true, 'a narrow but tall panel keeps the change/commit timestamps')
  assert.equal(out.compactKeepsEditorWhenTall, true, 'a narrow but tall panel keeps the full commit editor')
  assert.equal(out.compactStatsNoToggle, true, 'compact has no stats disclosure control')
  assert.equal(out.crampedStatsOneLine, true, 'a narrow and short panel collapses the stats to a single row')
  assert.equal(out.crampedStatsNoTimes, true, 'only two scarce axes drop the change/commit timestamps')
  assert.equal(out.crampedCommitBar, true, 'a narrow and short panel folds the commit editor')
  assert.equal(out.restoredStatsTimes, true, 'regaining height restores the timestamps')
  assert.equal(out.restoredCommitEditor, true, 'regaining height restores the full editor')
  assert.equal(out.wideStatsShowsTimes, true, 'the wide stats bar still shows the timestamps')
  assert.equal(out.hasAmend, true, 'amend checkbox present')
  assert.equal(out.hasStashBtn, true, 'stash button present in the changes toolbar')
  assert.equal(out.stashRows, 1, 'the stash list expands to its one entry')
  assert.equal(out.stashDropHint, true, 'the stash drop confirm shows the AI hint')
  assert.equal(out.stashDropEscClosed, true, 'Escape dismisses the stash drop confirm')
  assert.equal(out.stashPushOpened, true, 'the stash push dialog opens from the toolbar button')
  assert.equal(out.stashPushHint, true, 'the stash push dialog shows the AI hint')
  assert.equal(out.stashPushEscClosed, true, 'Escape dismisses the stash push dialog')
  assert.equal(out.commitDisabledEmpty, true, 'commit button is disabled without a message')
  assert.equal(out.commitEnabledWithMessage, true, 'commit button enables once a message is typed')
  assert.equal(out.commitPrimaryHoverKeepsColor, true, 'primary button defines a hover style that keeps its color')
  assert.equal(out.suggestLocksMessage, true, 'commit message box is read-only while AI suggest is in flight')
  assert.equal(out.suggestLocksAmend, true, 'amend toggle is disabled while AI suggest is in flight')
  assert.equal(out.suggestUnlocksMessage, true, 'message box and amend unlock once the suggestion lands')
  assert.equal(out.suggestFieldSpinner, true, 'a loading indicator renders inside the message field while generating')
  assert.equal(out.suggestFieldSpinnerPlatform, true, 'the field loader is the platform ongoing mark, not a ring the plugin draws')
  assert.equal(out.suggestFieldSpinnerAria, true, 'the decorative loader is hidden from assistive tech')
  assert.equal(out.suggestFieldSpinnerInside, true, 'the spinner is laid out inside the message field')
  assert.equal(out.suggestFieldSpinnerGone, true, 'the field spinner disappears once the suggestion lands')
  assert.equal(out.suggestFilled, true, 'the suggestion fills the message box')
  assert.equal(out.changeRows, 7, 'seven change rows (two modified text + three untracked entries + image + svg)')
  assert.equal(out.truncatedReloadAction, 'stage-all', 'the truncated phase re-delivers the snapshot through stage-all')
  assert.equal(out.noticeHasClose, true, 'notice banners carry a close button')
  assert.equal(out.noticeDismissed, true, 'closing a notice hides it until its text changes')
  assert.match(out.truncatedNotice, /changes\.truncatedCap/, 'a capped change list says so instead of silently dropping rows')
  assert.match(out.truncatedNotice, /"n":2/, 'the cap wording carries the visible-item count')
  assert.ok(out.truncatedHeads.some((head) => head.includes('(1200)')), 'a group whose rows fell past the cap still shows the full stat count')
  assert.ok(out.truncatedHeads.some((head) => head.includes('(4)')), 'visible groups keep the full counts too')
  assert.ok(out.incompleteNotices.some((text) => text.includes('changes.untrackedCollapsed')), 'a collapsed untracked side says so')
  assert.ok(out.incompleteNotices.some((text) => text.includes('changes.truncatedLossy')), 'a clipped stream uses the lossy wording')
  assert.equal(out.incompleteNotices.length, 2, 'both incompleteness notices render together')
  assert.equal(out.imagePanes, 2, 'image diff renders both panes in split mode')
  assert.equal(out.imageImgs, 2, 'both panes render an image')
  assert.equal(out.imageSrcOk, true, 'panes carry data URL images')
  assert.deepEqual(out.imageHeads, ['diff.before', 'diff.after'], 'pane labels before/after')
  assert.equal(out.imageSingle, true, 'after-mode collapses to one pane')
  assert.equal(out.imageSingleHead, 'diff.after', 'the single pane keeps its label')
  assert.equal(out.svgHasToggle, true, 'an SVG diff shows the render/source toggle bar')
  assert.equal(out.svgRenderDefault, true, 'an SVG diff defaults to the rendered comparison')
  assert.equal(out.svgSourceShowsDiff, true, 'switching an SVG to source shows the text diff')
  assert.equal(out.svgRenderRestored, true, 'switching an SVG back to render restores the comparison')
  assert.equal(out.hasBranchList, true, 'branch list rendered on overview')
  assert.equal(out.statusBarShown, true, 'the wide left column renders the status bar')
  assert.equal(out.statusRepoHref, 'https://github.com/owner/repo', 'the status bar links to the parsed GitHub repo page')
  assert.equal(out.statusSyncedShown, true, 'a synced branch shows the up-to-date state')
  assert.equal(out.statusNoPullWhenSynced, true, 'a synced branch offers no pull button')
  assert.equal(out.statusNoPushWhenSynced, true, 'a synced branch offers no push button')
  assert.equal(out.statusAheadPushShown, true, 'a strictly-ahead branch offers a push button')
  assert.equal(out.statusPushDirect, true, 'one click on push runs the push without a confirm dialog')
  assert.equal(out.statusPushNoDialog, true, 'no dialog opens for a fast-forward-only push')
  assert.equal(out.statusPushErrorInBar, true, 'a refused push surfaces in the status bar error slot')
  assert.equal(out.statusLateErrorSetup, true, 'the scoped-failure case parks the push and the snapshot in time')
  assert.equal(out.statusLateErrorSuppressed, true, 'a failure that lands after the checkout moved paints nothing')
  assert.equal(out.statusLateErrorNewScope, true, 'the status bar keeps reporting the new checkout')
  assert.equal(out.statusNoUpstreamNoPush, true, 'a branch without an upstream offers no push button')
  assert.equal(out.statusPublishShown, true, 'a branch without an upstream offers a publish button')
  assert.equal(out.statusPublishConfirmOpened, true, 'publish opens a second-reminder confirm dialog')
  assert.equal(out.searchFullHint, true, 'a wide search box shows the full message/hash hint')
  assert.equal(out.searchShortHint, true, 'a narrow search box drops the hint to the short placeholder')
  assert.equal(out.searchHintRestored, true, 'widening the search box restores the full hint')
  assert.equal(out.commitRows, 2, 'two commit rows')
  assert.equal(out.hasGraph, true, 'commit graph svg rendered')
  assert.equal(out.hasDetailFileRow, true, 'selecting a commit lists its changed files')
  assert.equal(out.hasChangeSummary, true, 'commit detail shows a change summary row')
  assert.equal(out.summaryHasFileCount, true, 'summary carries the file-count label')
  assert.equal(out.summaryAdd, '+12', 'summary shows added lines')
  assert.equal(out.summaryDel, '\u22124', 'summary shows deleted lines')
  assert.equal(out.summaryStickyWide, true, 'the change summary stays sticky in the wide layout')
  assert.equal(out.treeDirRowShown, true, 'changed-file tree shows a folder row')
  assert.equal(out.treeChildVisibleDefault, true, 'folder is expanded by default')
  assert.equal(out.treeDirExpandedDefault, true, 'folder row reports aria-expanded=true by default')
  assert.equal(out.treeChildHiddenAfterCollapse, true, 'clicking the folder collapses its children')
  assert.equal(out.treeDirCollapsedAttr, true, 'collapsed folder reports aria-expanded=false')
  assert.equal(out.treeChildVisibleAfterReexpand, true, 'clicking again re-expands the folder')
  assert.equal(out.treeDirFocusable, true, 'folder row is keyboard-focusable (tabIndex 0)')
  assert.equal(out.treeChildHiddenAfterKeyToggle, true, 'Enter on the folder collapses it')
  assert.equal(out.treeChildVisibleAfterKeyReexpand, true, 'Enter again re-expands it')
  assert.equal(out.hasCreateTagBtn, true, 'commit detail shows a create-tag action')
  assert.equal(out.tagModalOpened, true, 'the create-tag dialog opens')
  assert.equal(out.tagModalHint, true, 'the create-tag dialog shows the AI hint')
  assert.equal(out.tagModalClosed, true, 'the create-tag dialog closes via its close button')
  assert.equal(out.hasRevertBtn, true, 'commit detail shows a revert action')
  assert.equal(out.revertModalHint, true, 'the revert confirm shows the AI hint')
  assert.equal(out.hasResetBtn, true, 'commit detail shows a reset action')
  assert.equal(out.resetModeCount, 3, 'the reset dialog offers soft/mixed/hard')
  assert.equal(out.resetHardAck, true, 'hard mode reveals the acknowledgement')
  assert.equal(out.resetConfirmDisabledBeforeAck, true, 'hard reset confirm is disabled until acknowledged')
  assert.equal(out.resetConfirmEnabledAfterAck, true, 'acknowledging enables the hard reset confirm')
  assert.equal(out.resetModalClosed, true, 'Escape dismisses the reset dialog')
  assert.equal(out.hasModal, true, 'clicking a file opens the diff modal')
  assert.equal(out.modalHasDiff, true, 'the modal renders a unified diff (default view)')
  assert.equal(out.modalWordSyntax, true, 'word emphasis retains DSH syntax colors')
  assert.equal(out.modalViewLabel, 'diff.fileView', 'the dialog offers a read-only file view')
  assert.equal(out.modalFileView, true, 'the file view renders the shared CodePreview')
  assert.deepEqual(out.modalFileLines, ['line0', 'line1', 'line2'], 'the file view shows the complete version body, not the diff rows')
  assert.equal(out.modalVersionQuery?.path, out.modalPathText, 'the version read names the open file')
  assert.equal(out.modalVersionQuery?.base, 'commit', 'a commit overlay reads the commit blob')
  assert.equal(typeof out.modalVersionQuery?.commit, 'string', 'the read carries the commit it belongs to')
  assert.deepEqual(out.modalFileViewControls, { modes: 3, expand: true }, 'the file view keeps the whole toolbar, not a stub of it')
  // Every icon in that row uses the platform's instant bubble: no native title
  // (its browser delay cannot be shortened), the control's own label as the
  // bubble text, and the bubble portalled out of the modal's clipped box. The
  // expected labels are spelled out so a control that loses its label cannot
  // pass by comparing two nulls.
  const MODAL_TIP_LABELS = {
    view: 'diff.backToDiff',
    copy: 'diff.copyAfter',
    expand: 'diff.expandAll',
    split: 'diff.toSplit',
    before: 'diff.before',
    after: 'diff.after',
    close: 'common.close',
  }
  assert.deepEqual(Object.keys(out.modalTooltips).sort(), Object.keys(MODAL_TIP_LABELS).sort(), 'the modal bar is covered control by control')
  for (const [name, expected] of Object.entries(MODAL_TIP_LABELS)) {
    const tip = out.modalTooltips[name]
    assert.ok(tip !== null, `the ${name} control is found by its selector`)
    assert.equal(tip.label, expected, `${name}: the accessible name is the control's own label`)
    assert.equal(tip.title, null, `${name}: no native title (the slow browser tooltip)`)
    assert.equal(tip.tip, expected, `${name}: the platform tooltip carries that label`)
    assert.equal(tip.portal, 'true', `${name}: the bubble is portalled out of the clipped modal`)
  }
  // Without that export the hint must survive as the native title, never vanish.
  assert.deepEqual(
    out.modalFallbackTooltips,
    {
      view: { label: 'diff.fileView', title: 'diff.fileView', tip: null },
      close: { label: 'common.close', title: 'common.close', tip: null },
    },
    'a shell without the platform Tooltip falls back to the native title',
  )
  assert.equal(out.modalFileViewReopened, true, 'the file view can be reopened for the control round')
  assert.equal(out.modalFileViewModeReturned, true, 'a diff-mode switch in the file view returns to the diff')
  assert.equal(out.modalFileViewModeApplied, true, 'and applies the mode it names')
  assert.equal(out.modalFileViewExpandPresent, true, 'the expand control stays mounted in the file view')
  assert.equal(out.modalCopyLabel, 'diff.copyAfter', 'the copy action names the post-change content')
  assert.equal(out.modalCopyFeedback, true, 'copying confirms on the shared feedback clock')
  assert.equal(out.modalCopyLive, 'diff.copyAfterDone', 'the confirmation reaches the live region')
  assert.equal(out.modalCopyText, 'line0\nline1\nline2\n', 'the clipboard receives the complete version body')
  assert.equal(out.modalVersionQueriesAfterCopy, 1, 'copy reuses the file view read instead of querying again')
  assert.equal(out.modalBackToDiff, true, 'leaving the file view restores the diff')
  assert.equal(out.modalBeforeCopyLabel, 'diff.copyAfter', 'the copy action keeps its post-change meaning in the before view')
  assert.equal(out.modalBeforeCopyText, 'line0\nline1\nline2\n', 'copying in the before view still writes the post-change body')
  assert.equal(out.modalUnifiedRestored, true, 'the before toggle returns to the unified diff')
  // Degraded versions: visible reason, copy disabled with that reason as its
  // label, and never an empty file view standing in for the real content.
  assert.deepEqual(
    { text: out.modalTooLarge?.text, disabled: out.modalTooLarge?.disabled, label: out.modalTooLarge?.label, tip: out.modalTooLarge?.tip, file: out.modalTooLarge?.fileView, openedOn: out.modalTooLarge?.beforeLabel },
    { text: 'diff.versionTooLarge', disabled: true, label: 'diff.versionTooLarge', tip: 'diff.versionTooLarge', file: false, openedOn: 'diff.fileView' },
    'an over-limit version explains itself and cannot be copied',
  )
  assert.deepEqual(
    { text: out.modalAbsent?.text, disabled: out.modalAbsent?.disabled, label: out.modalAbsent?.label, tip: out.modalAbsent?.tip, file: out.modalAbsent?.fileView, openedOn: out.modalAbsent?.beforeLabel },
    { text: 'diff.versionAbsent', disabled: true, label: 'diff.versionAbsent', tip: 'diff.versionAbsent', file: false, openedOn: 'diff.fileView' },
    'a version without this file says so instead of showing an empty body',
  )
  assert.deepEqual(
    { text: out.modalBinary?.text, disabled: out.modalBinary?.disabled, label: out.modalBinary?.label, tip: out.modalBinary?.tip, file: out.modalBinary?.fileView, openedOn: out.modalBinary?.beforeLabel },
    { text: 'diff.versionBinary', disabled: true, label: 'diff.versionBinary', tip: 'diff.versionBinary', file: false, openedOn: 'diff.fileView' },
    'a non-text version explains itself and cannot be copied',
  )
  // 展开全部: the same icon-only control the changes pane uses, in the same box.
  assert.deepEqual(
    { text: out.modalExpand?.text, glyph: out.modalExpand?.glyph, aria: out.modalExpand?.aria, pressed: out.modalExpand?.pressed },
    { text: '', glyph: true, aria: 'diff.expandAll', pressed: 'false' },
    'the commit-diff modal expands through an icon button, not a text button',
  )
  // The drawn box is asserted pixel-by-pixel by changes-diff-modal (this runner
  // injects no theme variables, so themed borders compute to their initials).
  assert.ok((out.modalIconBoxRule?.css ?? '').includes('border'), 'the bordered icon-box rule covers the modal bar')
  assert.ok((out.modalIconBoxRule?.css ?? '').includes('25px'), 'that rule pins the control height to the mode seg line')
  assert.equal(out.staleSegExpandRule, null, 'the old text-button rule for the expand control is gone')
  assert.equal(out.diffFindOpened, true, 'Ctrl+F opens Find inside the diff modal')
  assert.ok(out.diffFindHits >= 1, 'the diff Find highlights matches')
  assert.equal(out.diffFindActive, 1, 'exactly one diff match is the active hit')
  assert.ok(/^1\/\d+$/.test(out.diffFindCount || ''), 'the diff Find shows an active/total count')
  assert.ok(out.diffFindCaseInsensitiveHits >= 1, 'diff Find is case-insensitive by default: COUNT matches count')
  assert.equal(out.diffFindCaseSensitiveHits, 0, 'enabling Match case in the diff Find drops mismatched-case matches')
  assert.equal(out.diffFindClosedModalKept, true, 'Esc closes diff Find without closing the modal')
  assert.equal(out.modalClosedByEsc, true, 'Esc closes the modal')
  assert.equal(out.modalClosedByBtn, true, 'the close button closes the modal')
  assert.equal(out.livePillJump, true, 'pill jump still takes the active panel to Changes')
  assert.ok(out.filesTreeRows >= 3, 'files tab lists the root directory entries')
  assert.equal(out.ignoredRowsDimmed, true, 'Git ignored files and directories appear translucent')
  assert.equal(out.folderIcon, 'closed', 'collapsed directory rows use the closed folder glyph')
  assert.equal(out.folderIconOpen, 'open', 'an expanded directory row switches to the open folder glyph')
  assert.ok(out.filesTreeRowsAfterExpand > out.filesTreeRows, 'expanding a directory reveals its children')
  assert.equal(out.emptyDirHintShown, true, 'an expanded empty directory shows a hint row instead of only flipping the folder glyph')
  assert.equal(out.emptyDirHintIndented, true, 'the empty-directory hint sits one level under its directory')
  assert.equal(out.dirRowAriaExpanded, true, 'the expanded directory row reports aria-expanded (the hint row itself carries no state)')
  assert.equal(out.filesCodeShown, true, 'selecting a text file shows the code preview')
  assert.equal(out.selectAllWrapFocused, true, 'clicking the preview makes the read-only code region focusable')
  assert.equal(out.selectAllWrapText.trimEnd(), 'const x = 1\nconst y = 2', `Ctrl+A selects the code body only — no line numbers, no diff chrome (${JSON.stringify(out.selectAllWrapText)})`)
  assert.ok(!out.selectAllWrapNotes.includes('files.selectAllPartial'), 'a fully mounted file needs no partial-selection warning')
  assert.equal(out.txtRowSelected, true, 'the selected file row carries the active class')
  assert.equal(out.selectionStyled, true, 'the travelling fill carries the primary-tinted highlight (shared --gp-select-* token)')
  assert.equal(out.officialCodeHighlight, true, 'code preview renders syntax spans from the DSH highlighter')
  assert.equal(out.codeIconPath, 'src/index.ts', 'code file glyph receives its relative path for official type classification')
  assert.equal(out.filesRefreshShown, true, 'a refresh control sits in the status bar above the file tree')
  assert.equal(out.refreshRelistedRoot, true, 'refresh re-lists the root directory')
  assert.equal(out.refreshRelistedOpenDir, true, 'refresh re-lists every expanded directory')
  assert.equal(out.refreshRereadSelectedFile, true, 'refresh re-reads the selected file')
  assert.equal(out.refreshNewEntryShown, true, 'a file added outside the panel appears after refresh')
  assert.equal(out.refreshContentUpdated, true, 'file content changed outside the panel is picked up by refresh')
  assert.equal(out.refreshReenabled, true, 'the refresh control re-enables once the re-reads settle')
  assert.equal(out.copiedPath, 'src/index.ts', 'preview copies the selected file path relative to browse root')
  assert.equal(out.copyFeedback, 'files.pathCopied src/index.ts', 'the filename button confirms the clipboard write on its label')
  assert.equal(out.copyFeedbackReset, true, 'late copy of previous file cannot change current file feedback')
  assert.equal(out.copyDeniedFeedback, true, 'clipboard denial shows an actionable failure state')
  assert.equal(out.pathCopyIsButton, true, 'the filename itself is the copy control')
  assert.equal(out.noSeparatePathButton, true, 'no separate copy-relative-path button is left beside the filename')
  // Parity with the diff headers: same mark placement (the check takes the
  // directory's slot) and the same self-expiring confirmation.
  assert.deepEqual(out.pathCopyShape, { copied: true, dir: false, check: true, name: 'index.ts' }, 'the filename shows a check in the directory slot while copied')
  assert.deepEqual(out.pathCopyReverted, { copied: false, dir: true, aria: 'files.copyPath src/index.ts' }, 'the filename confirmation clears itself like the diff headers')
  // Root-level file: the name is an element like the nested shape's, so it can
  // elide (the button clips) and take the hover underline.
  // Line-number gutter: three digits by default, four once a file needs them —
  // the column follows --gp-gutter-w, so it is no longer wider than the numbers.
  const GUTTER_PAD = 10
  assert.equal(out.smallGutter?.varValue, 'calc(3ch + 10px)', 'a short file takes the three-digit gutter')
  // Bounds, not a magic pixel width: the column must fit three digits plus the
  // cell padding and not reserve much beyond them. The digit width is measured in
  // the gutter's own font, so a platform with a wider fallback font still passes.
  assert.ok((out.smallGutter?.cellW ?? 0) >= (out.smallGutter?.digitW ?? 0) + GUTTER_PAD, `the three-digit gutter fits its digits (${out.smallGutter?.cellW} vs ${out.smallGutter?.digitW})`)
  assert.ok((out.smallGutter?.cellW ?? 99) <= (out.smallGutter?.digitW ?? 0) + GUTTER_PAD + 4, `and reserves no fourth digit (${out.smallGutter?.cellW} vs ${out.smallGutter?.digitW})`)
  assert.equal(out.bigGutter?.varValue, 'calc(4ch + 10px)', 'a 5101-line file widens the gutter to four digits')
  assert.equal(out.bigGutter?.cellW, out.bigGutter?.colW, 'the gutter cell fills its column exactly')
  assert.ok((out.bigGutter?.cellW ?? 0) >= (out.bigGutter?.digitW ?? 0) + GUTTER_PAD, `the four-digit gutter fits its digits too (${out.bigGutter?.cellW} vs ${out.bigGutter?.digitW})`)
  assert.ok((out.bigGutter?.cellW ?? 0) > (out.smallGutter?.cellW ?? 0), 'and the wide gutter is wider than the short one')
  assert.equal(out.rootPathShape?.text, 'README.md', `a root-level file shows its name (got ${JSON.stringify(out.rootPathShape)})`)
  assert.equal(out.rootPathShape?.hasDir, false, 'a root-level file has no directory half')
  assert.equal(out.rootPathShape?.root, true, 'and its name carries the root modifier')
  assert.equal(out.rootPathShape?.overflow, 'hidden', 'the name owns its elision')
  assert.equal(out.rootPathShape?.ellipsis, 'ellipsis', 'long root-level names elide instead of being clipped')
  assert.equal(out.rootPathShape?.shrinkable, true, 'the name is what shrinks when there is no directory to give way')
  assert.deepEqual(out.contentCopyShape, { copied: true, check: true }, 'the copy-content icon confirms on the same clock')
  assert.deepEqual(out.contentCopyLive, { text: 'files.contentCopied', aria: 'polite' }, 'the copy-content confirmation also reaches screen readers through its live region')
  assert.equal(out.contentCopyReverted, true, 'the copy-content confirmation also clears itself')
  assert.equal(out.filesImageShown, true, 'selecting an image shows the inline image preview')
  assert.equal(out.svgRendersByDefault, true, 'an SVG renders as a picture on selection')
  assert.equal(out.svgModeSegShown, true, 'an SVG offers the source/render switcher')
  assert.equal(out.svgSourceShowsMarkup, true, 'the SVG source face shows the markup instead of the picture')
  assert.equal(out.svgSourceWrapOffered, true, 'the SVG source face carries the code controls (wrap)')
  assert.equal(out.svgRenderRestoresImage, true, 'switching back restores the rendered SVG')
  assert.equal(out.svgSingleRead, true, 'both SVG faces come from one file-content read')
  assert.equal(out.svgCopyContentShown, true, 'an SVG offers copy-source beside copy-path')
  assert.equal(out.svgCopyContentCopiesMarkup, true, 'copying an SVG writes its markup, not the data URL')
  assert.equal(out.zoomDiffBars, 2, 'each diff image pane renders its own zoom bar')
  assert.equal(out.zoomBarShown, true, 'the file preview shows the zoom bar')
  assert.equal(out.zoomPctBefore, '100%', 'the fit label starts at the fit percentage')
  assert.equal(out.zoomWheelZoomed, true, 'ctrl+wheel (pinch) zooms the image')
  assert.equal(out.zoomPctAfter, '120%', 'a pinch step applies the 1.2x scale factor')
  assert.equal(out.zoomPlainWheelNoop, true, 'a plain wheel leaves zoom alone so panning stays native')
  assert.equal(out.zoomDblClickFit, true, 'double click returns to fit')
  assert.equal(out.zoomFitPressed, true, 'fit reports aria-pressed while active')
  assert.equal(out.zoomLightboxShown, true, 'the fullscreen lightbox opens')
  assert.equal(out.zoomLightboxClosed, true, 'Escape closes the lightbox')
  assert.equal(out.zoomLightboxImagePressKeeps, true, 'pressing the lightbox image keeps it open')
  assert.equal(out.zoomLightboxBackdropCloses, true, 'pressing the lightbox empty area closes it')
  assert.equal(out.zoomInZoomed, true, 'the zoom bar steps the zoom level up')
  assert.equal(out.zoomFitLabelHonest, true, 'after resizing while zoomed, the fit label matches the rendered size')
  assert.equal(out.zoomResetsOnNewImage, true, 'switching images resets the zoom instead of carrying it over')
  assert.equal(out.zoomFitTracksViewport, true, 'the fit label tracks a viewport resize at the size actually rendered')
  assert.equal(out.zoomAboveNaturalRendered, true, 'zooming past 100% really grows the rendered image, not just the label')
  assert.equal(out.zoomAboveNaturalScrolls, true, 'zooming past 100% extends the scrollable area instead of fake-panning')
  assert.equal(out.zoomImgClickNoFullscreen, true, 'a click on the image does not open the lightbox (fullscreen lives in the zoom bar)')
  assert.equal(out.zoomPanScrollable, true, 'a zoomed image overflows its viewport, so it can be panned')
  assert.equal(out.zoomPanImgNotDraggable, true, 'the image opts out of the browser native drag so a mouse drag pans instead')
  assert.equal(out.zoomFitCursor, 'zoom-in', 'the fit viewport advertises click-to-zoom, not a drag')
  assert.equal(out.zoomGrabCursor, 'grab', 'the zoomed viewport advertises drag-to-pan')
  assert.equal(out.zoomDragPanned, true, 'dragging with the mouse pans the zoomed image')
  assert.equal(out.zoomDragKeepsMode, true, 'a drag never doubles as a double click that changes the zoom')
  assert.equal(out.zoomTouchNotTakenOver, true, 'touch presses keep native scrolling instead of being taken over')
  assert.equal(out.zoomGestureScales, true, "Safari's gesture events scale the image")
  assert.equal(out.zoomDiffPanesIndependent, true, 'each comparison pane zooms on its own')
  assert.equal(out.zoomDiffResetsOnFileSwitch, true, 'a new diff file drops the panes\u2019 zoom instead of carrying it over')
  assert.equal(out.wideModeSegShown, true, 'the wide toolbar uses the official two-choice segmented control')
  assert.equal(out.wideModePanelsResolve, true, 'each wide mode tab controls its own tabpanel')
  assert.equal(out.wideHasFullscreen, true, 'the wide toolbar carries the fullscreen reading entry')
  assert.equal(out.wideFullscreenShown, true, 'the reader shows the live preview restyled as a dialog, not a second render')
  assert.equal(out.wideFullscreenBar, true, 'the reader bar puts the browser-fullscreen toggle immediately left of close')
  assert.equal(out.readerScreenToggleLabeled, true, 'the reader\'s fullscreen toggle is a labelled button, not a clone of the icon that opened the card')
  assert.equal(out.readerScreenIconDistinct, true, 'the two fullscreen controls draw different glyphs at the bar row height')
  assert.equal(out.wideFullscreenClosed, true, 'Escape closes the reader and keeps the preview mounted')
  assert.equal(out.markdownRenderedDefault, true, 'Markdown defaults to the rendered view')
  assert.equal(out.markdownSourceShown, true, 'source button shows the code view')
  assert.equal(out.wideSourceHasWrap, true, 'the wide source toolbar carries the word-wrap toggle')
  assert.equal(out.markdownRenderRestored, true, 'render button restores official MarkdownText')
  // A stuck code banner must sit flush: the pane's inset lives on the inner body,
  // never on the scroll box (padding there leaves a band above the banner).
  // Symptom first, mechanism second: the leak is what the user sees, and the
  // padding split is only the way it is prevented.
  assert.equal(out.markdownStickyBanner?.scrolled, true, 'the probe actually scrolled the markdown pane')
  assert.equal(out.markdownStickyBanner?.rowsAboveBanner, 0, 'no code row paints above a stuck code banner')
  assert.equal(out.markdownStickyBanner?.scPaddingTop, '0px', 'the markdown scroll box carries no padding')
  assert.equal(out.markdownStickyBanner?.bodyPaddingTop, '16px', 'the inset lives on the inner markdown body')
  assert.equal(out.mermaidRendered, true, 'a mermaid fence renders the diagram via the lazy chunk with surrounding markdown intact')
  assert.equal(out.mermaidFallback, true, 'a diagram the engine rejects falls back to the plain code block')
  assert.equal(out.htmlSourceDefault, true, 'HTML defaults to the source view, never auto-rendered')
  assert.equal(out.htmlRenderShown, true, 'switching HTML to render mounts the preview iframe')
  assert.equal(out.htmlFrameSandbox, 'allow-scripts', 'the HTML iframe runs scripts but stays a unique opaque origin (no allow-same-origin)')
  assert.equal(out.htmlInteractiveDefault, true, 'a small HTML document keeps the interactive preview by default')
  assert.equal(out.htmlStaticToggle, true, 'the JS toggle drops script permission and injects the static CSP')
  assert.equal(out.htmlStaticHint, true, 'a script-rendered page explains the blank static preview and offers to run it')
  assert.equal(out.htmlStaticNoMask, true, 'a srcdoc (static) preview shows no loading mask')
  assert.equal(out.htmlScriptsRestored, true, 'toggling JS back restores the interactive preview')
  assert.equal(out.htmlLoadingMask, true, 'the blob frame is masked until load, then the mask is click-through and hidden from AT')
  assert.equal(out.htmlReaderReusesFrame, true, 'opening the reader reuses the rendered HTML frame instead of reloading the page')
  assert.equal(out.htmlReaderClosedKeepsFrame, true, 'closing the reader keeps the same frame and restores the toolbar')
  assert.equal(out.htmlReaderKeepsDocument, true, 'opening and closing the reader never reloads the page document')
  assert.equal(out.screenFullRefused, true, 'a refused full-screen request leaves the reader open and the toggle off')
  assert.equal(out.screenFullBlocked, true, 'a Permissions-Policy lockout (TypeError) is reported as blocked, with its own reason')
  assert.equal(out.screenFullNoResponse, true, 'a request the host never settles is reported after the watchdog, not left silent')
  assert.equal(out.screenFullUnsupported, true, 'an engine with no requestFullscreen API is reported as unsupported instead of throwing')
  assert.equal(out.screenFullGranted, true, 'a granted request flips the toggle from the browser state')
  assert.equal(out.screenFullExited, true, 'pressing it again leaves full screen once and resets the toggle')
  assert.equal(out.htmlMaskLoadingState, true, 'a frame that never reports keeps the mask (and blocks the pointer) until the fallback')
  assert.equal(out.htmlMaskIgnoresForeignMessage, true, 'a paint report from anywhere but the frame itself is refused')
  assert.equal(out.htmlMaskFallbackReady, true, 'the load fallback lifts the mask even when the page CSP blocks the report')
  assert.equal(out.htmlHeavyAsks, true, 'a heavy document asks in a modal before its frame is mounted (no page scripts run uninvited)')
  assert.equal(out.htmlHeavyKeptSource, true, 'cancelling closes the question without mounting a frame')
  assert.equal(out.htmlHeavyOpensLocally, true, 'a non-loopback GUI offers no local-open button and says the file is remote')
  assert.equal(out.htmlHeavyAsksAgain, true, 'declining is not an approval: the question comes back')
  assert.equal(out.htmlHeavyRuns, true, 'approving mounts the frame and runs the page')
  assert.equal(out.htmlMaskSlowClickThrough, true, 'a slow frame stops the mask from taking clicks, so the panel stays usable')
  assert.equal(out.htmlMaskSlowHasStop, true, 'a slow frame offers a way out of the wait')
  assert.equal(out.htmlMaskSlowCounts, true, 'a slow frame counts the wait instead of only spinning')
  assert.equal(out.htmlStopUnmounts, true, 'stopping the render unmounts the frame and returns the source view')
  assert.equal(out.htmlFrameUsesBlob, true, 'the interactive HTML body travels as a blob: URL (own renderer process)')
  assert.equal(out.htmlFrameHasPageBytes, true, 'the HTML iframe carries the page bytes (blob document, no network)')
  assert.equal(out.htmlRunsPageScript, true, 'the interactive frame really executes the page scripts')
  assert.equal(out.htmlStaticBlocksScript, true, 'the static preview really blocks them')
  assert.equal(out.htmlAssetPacked, true, 'a relative stylesheet is inlined as a data: URL in the srcdoc')
  assert.equal(out.htmlAssetCssRead, true, 'the stylesheet is read through the host file-content route, not the network')
  assert.equal(out.htmlAssetSandbox, 'allow-scripts', 'the packed HTML iframe keeps the opaque-origin sandbox')
  assert.equal(out.htmlAssetBundleHasCss, true, 'the inlined data: URL carries the stylesheet text')
  assert.equal(out.htmlAssetFallback, true, 'a missing asset abandons the pack and the plain page bytes render')
  assert.equal(out.htmlAssetMissingRead, true, 'the missing asset was actually read and refused, not skipped')
  assert.equal(out.bigHighlightOff, true, 'a large text file skips highlighting and shows the notice')
  assert.equal(out.bigNoSyntaxSpans, true, 'a large text file renders plain text (no syntax spans)')
  assert.equal(out.bigLineFull, true, 'an over-long line renders in full (no truncation marker anywhere)')
  assert.equal(out.bigWrapDisabled, true, 'a file over the wrap cap keeps the toggle visible but disabled')
  assert.ok(out.bigMountedRows > 0 && out.bigMountedRows < out.bigTotalLines, `virtualized: mounts a window (${out.bigMountedRows}), not all ${out.bigTotalLines} rows`)
  assert.ok(out.selectAllVirtualText > 0, 'Ctrl+A still selects the mounted rows on a virtualized file')
  assert.ok(out.selectAllVirtualNotes.includes('files.selectAllPartial'), 'the virtualized selection warns that it may be incomplete')
  assert.equal(out.selectAllVirtualDidNotMountAll, true, 'the shortcut never mounts the whole file')
  assert.ok(!out.selectAllVirtualNotesAfterPress.includes('files.selectAllPartial'), 'the next press drops the partial-selection warning')
  assert.equal(out.bigSpacerHeight, out.bigTotalLines * 20, 'the virtual spacer height reflects the full line count')
  assert.equal(out.bigSelectionSurvived, true, 'a text selection survives scrolling away from the rows it covers')
  assert.ok(out.bigSelectionMounted < 200, `only the selected and visible spans mount while selecting (${out.bigSelectionMounted} rows, not the whole file)`)
  assert.equal(out.bigSelectionScrolled, true, 'the survival check really scrolled the code view away from the selection')
  assert.equal(out.findOpened, true, 'Ctrl+F opens the in-panel find while the preview is visible')
  assert.equal(out.findHitCount, 2, 'the query highlights every match in the file')
  assert.equal(out.findActiveCount, 1, 'exactly one match is the active hit')
  assert.equal(out.findCountLabel, '1/2', 'the count shows the active index and total')
  assert.equal(out.findCountAfterNext, '2/2', 'next-match navigation advances the active index')
  assert.equal(out.findNoMatchLabel, 'files.findNoMatch', 'a query with no results shows the no-match label')
  assert.equal(out.findCaseInsensitiveHits, 2, 'case-insensitive by default: CONST matches lowercase const')
  assert.equal(out.findCaseButtonActive, true, 'the Match case toggle reflects its active state')
  assert.equal(out.findCaseSensitiveHits, 0, 'enabling Match case drops mismatched-case matches')
  assert.equal(out.findCaseSensitiveLabel, 'files.findNoMatch', 'case-sensitive no-match shows the no-match label')
  assert.equal(out.findClosed, true, 'Esc closes the find box')
  assert.equal(out.propsBtnShown, true, 'the preview toolbar shows the properties entry')
  assert.equal(out.propsOpened, true, 'the properties dialog opens from the toolbar')
  assert.equal(out.propsTitle, 'files.propsTitle', 'the dialog bar carries the properties title')
  assert.deepEqual(out.propsGroups, ['files.propsGroupStats', 'files.propsGroupTime'], 'a text file gets the size/stats and time groups')
  assert.equal(out.propsName, 'a.txt', 'the name row shows the file name')
  assert.equal(out.propsTypeKey, 'files.propsTypeFmt', 'the type row renders the language/ext label')
  assert.equal(out.propsRelPath, 'a.txt', 'the relative-path row copies the browse-relative path')
  assert.equal(out.propsAbsPath, 'fixture-repo/a.txt', 'the absolute-path row shows the root-prefixed path')
  assert.equal(out.propsSize, '24 B', 'a sub-KiB size stays exact')
  assert.equal(out.propsSizeSub, null, 'a sub-KiB size omits the raw-byte parenthetical')
  assert.equal(out.propsLines, '2', 'the stats block shows the line count')
  assert.equal(out.propsMtime, true, 'the time group shows an absolute timestamp')
  assert.deepEqual(out.propsBadges, ['files.propsTrackedYes', 'files.stModified'], 'the footer states tracked + modified once')
  assert.equal(out.propsCopiedAbs, 'fixture-repo/a.txt', 'copying the path row writes the root-prefixed path')
  assert.equal(out.propsCopyFeedback, 'files.pathCopied', 'the footer confirms the copy')
  assert.equal(out.propsClosed, true, 'Escape closes the properties dialog')
  assert.deepEqual(out.propsUntrackedBadges, ['files.propsUntracked'], 'an untracked file states untracked exactly once')
  assert.deepEqual(out.propsUntrackedDirBadges, ['files.propsUntracked'], 'a file inside an untracked directory reads untracked, not tracked')
  assert.deepEqual(out.propsUntrackedNestedBadges, ['files.propsUntracked'], 'a file under a directory-level untracked entry reads untracked via its ancestor')
  assert.deepEqual(out.propsIgnoredBadges, ['files.ignored'], 'an ignored file states only the ignored fact')
  assert.equal(out.propsImageDimsRow, true, 'an image gets its natural size probed onto the dialog')
  assert.deepEqual(out.propsImageBadges, ['files.propsTrackedYes'], 'an unchanged tracked image carries no working-tree chip')
  assert.equal(out.propsSizeKiB, '1.5 KB', 'a rounded size steps to the display unit')
  assert.equal(out.propsSizeKiBSub, 'files.propsSizeBytes', 'a rounded size carries the raw byte count parenthetical')
  assert.deepEqual(out.copyBtnText, ['<icon>'], 'a text document offers copy content (icon) and no path text button')
  assert.deepEqual(out.copyBtnImage, [], 'an image shows no copy buttons at all (the filename still copies)')
  assert.deepEqual(out.copyBtnBinary, [], 'a binary file shows no copy-content button')
  assert.deepEqual(out.copyBtnTooLarge, [], 'a document over the copy envelope shows no copy-content button')
  // The content control is a glyph, not a phrase: label on aria, no text, and
  // it must line up with the text button it is joined to.
  assert.deepEqual(
    { aria: out.copyContentIcon?.aria, text: out.copyContentIcon?.text, glyph: out.copyContentIcon?.glyph },
    { aria: 'files.copyContent', text: '', glyph: true },
    'the copy-content control is an icon button with its label on aria',
  )
  assert.ok(out.copyContentIcon?.width <= 32, `the copy-content button is a square icon, not a text pill (${out.copyContentIcon?.width}px wide)`)
  assert.equal(out.copyContentIcon?.height, out.copyContentIcon?.peerHeight, "the copy glyph matches the toolbar's other icon buttons")
  assert.equal(out.copyContentIconOnImage, null, 'an image preview shows no copy-content control at all')
  assert.ok(out.copyTip !== null, 'hovering the content-copy icon raises a tip')
  assert.equal(out.copyTip?.text, 'files.copyContent', "the tip's label is the copy-content phrase")
  assert.equal(out.copyTip?.onBody, true, 'the tip is portaled to the body (no clipping ancestor)')
  assert.equal(out.copyTip?.nativeTitle, null, 'the icon carries no native title (the tip is the one hint)')
  assert.equal(out.copyTip?.below, true, 'the tip opens below the toolbar control, into the preview area')
  assert.equal(out.copyTip?.withinPanel, true, 'the tip stays inside the panel instead of spilling over the next pane')
  assert.equal(out.copyTip?.hoverDismissed, true, 'moving off the icon dismisses the hover tip')
  assert.equal(out.copyTip?.hiddenOnClick, true, 'pressing the control dismisses its own tip')
  assert.equal(out.copyTip?.feedbackTip, 'files.contentCopied', 'inside the confirmation window the tip reports the outcome (the live region is screen-reader only)')
  assert.equal(out.copyTip?.focused, 'files.copyContent', 'keyboard focus raises the same hint')
  assert.equal(out.copyTip?.dismissed, true, 'blur or a press elsewhere dismisses a focus-raised tip')
  assert.equal(out.placeholderBinary, 'files.binary', 'a binary file says so in the preview')
  assert.equal(out.placeholderTooLarge, 'files.tooLarge', 'an over-cap document says why it is not shown')
  assert.equal(out.preUnmountFilesActive, true, 'before the switch the Files tab is active')
  assert.ok(out.preUnmountSelected, 'before the switch a file is selected')
  assert.equal(out.preUnmountChildVisible, true, 'before the switch the expanded dir shows its child')
  assert.equal(out.restoredFilesActive, true, 'a quick return restores the Files sub-tab')
  assert.equal(out.restoredChildVisible, true, 'a quick return keeps the expanded directory open')
  assert.equal(out.restoredSelected, out.preUnmountSelected, 'a quick return keeps the same file selected')
  assert.equal(out.restoredPreviewShown, true, 'a quick return restores the file preview')

  // Branch switch (wide): per-row switch button, confirm + stash choice,
  // run payload, refusal kept in the dialog.
  assert.equal(out.switchNoFixedEntry, true, 'the left column has no fixed switch entry any more')
  assert.equal(out.branchPrimaryFirst, true, 'the primary branch (main) leads the local list')
  assert.equal(out.graphShownOnAuthorFilter, true, 'an author filter retains the evidence-based graph')
  assert.equal(out.branchDirRow, true, 'refs sharing a path prefix fold into a directory row')
  assert.equal(out.branchDirLabel, 'origin', 'the directory row is labelled with the directory name')
  assert.equal(out.branchDirHasFolder, true, 'a directory row carries a folder glyph, not a branch icon')
  assert.equal(out.branchLeafHasNoFolder, true, 'a leaf ref row keeps its branch icon')
  assert.equal(out.branchDirHasNoCount, true, 'directory rows no longer show a ref count')
  assert.equal(out.branchDirExpandedDefault, true, 'top-level directories start expanded')
  assert.equal(out.branchDirIndentedFromSection, true, 'a directory row is indented past its section chevron')
  assert.equal(out.branchNestedDirCollapsed, true, 'deeper directories start collapsed')
  assert.equal(out.branchNestedDirExpands, true, 'a nested directory expands on click')
  assert.equal(out.branchNestedLeafIndented, true, 'a nested ref label sits right of its directory label')
  assert.equal(out.branchNestedDirRecollapses, true, 'a nested directory collapses again')
  assert.equal(out.branchLeafIndented, true, 'a nested ref label sits right of its directory label')
  assert.equal(out.branchRowLeftSquare, true, 'branch rows are square on the left, flush with the panel edge')
  assert.equal(out.branchRowRightRounded, true, 'branch rows keep their rounded right end')
  assert.equal(out.branchDirCollapsedHidesChild, true, 'collapsing a directory hides its nested refs')
  assert.equal(out.branchDirReexpanded, true, 'expanding a directory lists its nested refs again')
  assert.deepEqual(out.switchBtnRows, ['feature', 'origin/release'],
    'only rows with a switch target carry the button (not the current branch or the remote resolving to it)')
  assert.equal(out.switchBtnHidden, true, 'the switch button is hidden until the row is hovered')
  assert.equal(out.switchBtnHoverRule, true, 'one grouped rule reveals the switch button on hover and on row focus')
  assert.equal(out.switchBtnShownOnRowFocus, true, 'focusing the row reveals the switch button')
  assert.equal(out.switchBtnHiddenAgain, true, 'blurring the row hides the switch button again')
  assert.equal(out.switchBtnTitleTrack, true, 'a remote row without a local branch says it creates a tracking branch')
  assert.equal(out.switchBtnTitleLocal, true, 'a local row titles a plain switch')
  assert.equal(out.switchBtnNoFilter, true, 'clicking the switch button does not toggle the history filter')
  assert.equal(out.switchCancelRunsNothing, true, 'closing the confirm runs no checkout')
  assert.equal(out.switchConfirmOpened, true, 'picking a row opens the switch confirm')
  assert.equal(out.switchConfirmBody, true, 'the confirm states the from → to switch')
  assert.equal(out.switchTrackingNote, true, 'a remote row explains the local branch it will create and track')
  assert.equal(out.switchDirtyWarn, true, 'a dirty work tree is called out before switching')
  assert.equal(out.switchStashChoice, true, 'the dirty work tree offers the stash-first choice')
  assert.equal(out.switchDefaultNoStash, true, 'the default is a plain switch, not a stash')
  assert.equal(out.switchStashRelabel, true, 'choosing stash relabels the confirm button')
  assert.deepEqual(out.switchAction, {
    kind: 'branch-checkout', name: 'release', createFrom: 'origin/release', stashMessage: 'switch.stashMessage',
  }, 'the confirm runs the tracking checkout, stashing first when chosen')
  assert.equal(out.switchModalClosed, true, 'a landed switch closes the dialog')
  assert.equal(out.switchReloadedBranches, true, 'a landed switch reloads the branch list')
  assert.equal(out.switchSyncStateFresh, true, 'the switch itself refreshes the sync state (no manual refresh needed)')
  assert.equal(out.switchAutoCheckSync, true, "a landed switch checks the new branch's remote state on its own")
  assert.equal(out.switchRefusalShown, true, 'a refused switch shows the refusal inside the dialog')
  assert.equal(out.switchRefusalStaysOpen, true, 'a refused switch keeps the dialog open for another choice')
  assert.equal(out.switchRelistsFiles, true, 'a branch switch makes the Files tab re-list the root')
  assert.equal(out.switchClearsFileSelection, true, 'a branch switch drops the Files tab selection')

  assert.ok(realInput !== null && realInput.before.rendered > realInput.before.natural, `real input: zooming past 100% grows the rendered image (${JSON.stringify(realInput?.before)})`)
  assert.ok(realInput !== null && realInput.after.left > realInput.before.left && realInput.after.top > realInput.before.top, `real input: a mouse drag pans the zoomed image (${JSON.stringify(realInput?.before)} -> ${JSON.stringify(realInput?.after)})`)
  assert.equal(realInput?.after.pct, realInput?.before.pct, 'real input: a drag leaves the zoom level untouched')
  assert.equal(realInput?.after.lightbox, false, 'real input: a drag never opens the lightbox')
  // Exactly two console errors are the behaviour under test, not defects:
  // the static preview of page.html blocks that page's inline script (the
  // sandbox denies it), and csp.html blocks the preview's own paint report
  // with its `script-src 'none'` — the fallback path. Both must actually
  // appear, so a silent regression cannot hide behind the allow list; every
  // other console error stays fatal.
  const expectedErrors = [
    { pattern: /frame is sandboxed and the 'allow-scripts' permission is not set/, seen: 'the static preview blocks the page script' },
    { pattern: /Content Security Policy directive 'script-src 'none''.*has been blocked/, seen: 'the CSP fixture blocks the paint report' },
  ]
  for (const expected of expectedErrors) {
    assert.ok(errors.some((message) => expected.pattern.test(message)), `expected console error missing (${expected.seen}): ${JSON.stringify(errors)}`)
  }
  assert.deepEqual(
    errors.filter((message) => !expectedErrors.some((expected) => expected.pattern.test(message))),
    [],
    'no console errors: ' + JSON.stringify(errors),
  )
}
