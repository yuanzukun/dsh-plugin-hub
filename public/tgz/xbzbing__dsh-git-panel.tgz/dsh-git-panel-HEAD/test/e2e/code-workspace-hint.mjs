/**
 * E2E: the workspace-file hint row and the enable action (issue #125, ADR-0035).
 *
 * A cwd that holds a `.code-workspace` file is the whole point of the setting,
 * but with the setting `off` the panel used to say nothing at all: the feature
 * existed only for someone who already knew the config key. The repository list
 * now states what it found and offers the one-click switch, and it renders that
 * row even when it has no checkout to list (a hub directory: the case the
 * feature was built for). A configured but unusable file states why instead of
 * leaving an empty list unexplained.
 *
 * The enable path is end to end here: the click writes `codeWorkspace: auto`
 * through the settings form and the list is fetched again until the host
 * answers with the roots — the hint must not be a dead label.
 *
 * Also pins the row rule the same release changed: a worktree of the session's
 * own repository outside the cwd is selectable, not a disabled row.
 *
 * Fully isolated — a local file:// harness, no dsh server, no running instance.
 */
import { chromium } from 'playwright-core'
import assert from 'node:assert/strict'
import { fileURLToPath } from 'node:url'
import { dirname, resolve } from 'node:path'

const DIR = dirname(fileURLToPath(import.meta.url))
const harness = 'file://' + resolve(DIR, 'harness.html')

const SNAP = {
  root: 'fixture-repo', branch: 'main', head: 'de54fc0', unborn: false, dirty: false,
  staged: 0, modified: 0, untracked: 0, ahead: 0, behind: 0, hasUpstream: true,
  remote: null, lastCommit: null, changes: [],
  stats: { fileCount: 0, staged: 0, modified: 0, untracked: 0, insertions: 0, deletions: 0, lastChangeAt: null, headCommittedAt: null },
  truncated: false, refreshIntervalMs: 0, showInputPill: true,
  defaultDiffView: 'unified', checkedAt: Date.now(),
}

const WORKSPACE = { path: '', root: '/mock/hub', name: 'hub', kind: 'workspace', role: 'main', branch: 'main' }
const EXTERNAL = { path: '../service-a', root: '/mock/service-a', name: 'service-a', kind: 'external', role: 'repo', label: 'API' }
// The row this release made selectable: a worktree of the session's own
// repository, created outside the cwd. No `disabled` field — the host only
// emits one when no relative selector exists (another Windows drive).
const OUTSIDE_WORKTREE = { path: '../spike', root: '/mock/spike', name: 'spike', kind: 'nested', role: 'linked', branch: 'spike' }

/** The few strings this runner asserts on; every other key renders as itself. */
const DICT = {
  'repos.workspaceAvailable': 'Found {file}: its repositories can join the list',
  'repos.workspaceMany': 'Found {n} workspace files: choose one in the plugin settings',
  'repos.workspaceEnable': 'Enable',
  'repos.workspaceEnabling': 'Enabling…',
  'repos.workspaceMissing': 'Workspace file {file} not found',
  'repos.workspaceInvalid': 'Workspace file unusable',
  'repos.workspaceInvalidName': 'The setting does not name a workspace file',
  'repos.workspaceInvalidLink': 'Workspace file {file} is a symlink out of the directory',
  'repos.workspaceInvalidNotFile': 'Workspace file {file} is not a regular file',
  'repos.workspaceInvalidSize': 'Workspace file {file} is too large to read',
  'repos.workspaceInvalidRead': 'Workspace file {file} could not be read',
  'repos.workspaceInvalidParse': 'Workspace file {file} could not be parsed',
  'repos.workspaceAmbiguous': 'Several workspace files: auto-detect cannot choose',
  'repos.workspaceEmpty': 'Workspace file enabled, but none of its folders is a repository',
  'repos.workspaceEnableFailed': 'Could not turn it on: the setting was not written',
}

const browser = await chromium.launch()

/**
 * Mount the panel with one repo-list answer. `withForm` decides whether the
 * settings service exists — the enable action hides itself without it.
 *
 * `snapshotError` mounts the browser-only layout (a cwd that is not a checkout),
 * which is where the notice bar carries the offer. `writeResult` decides what the
 * settings form answers, so a refused write can be driven. Both default to the
 * plain Git layout, which is what most scenarios want.
 */
async function mount({ repos, repoWorkspace, withForm = true, snapshotError = null, writeResult = true, applyOnWrite = false }) {
  const page = await browser.newPage({ viewport: { width: 1200, height: 820 } })
  const errors = []
  page.on('pageerror', (e) => errors.push('PAGEERROR ' + e.message))
  page.on('console', (msg) => { if (msg.type() === 'error') errors.push(msg.text()) })
  await page.goto(harness)
  await page.addScriptTag({ path: resolve(DIR, 'client.js') })
  await page.addScriptTag({ path: resolve(DIR, 'mock-rpc.mjs') })
  await page.evaluate(async ({ snap, listed, workspace, withForm, snapshotError, writeResult, applyOnWrite, dict }) => {
    const { fixture, connection } = window.createGitPanelMock(snap)
    fixture.repos = listed
    if (workspace !== undefined) fixture.repoWorkspace = workspace
    // The mock replays this once and then falls back to the snapshot, which is
    // how a browser-only session (no checkout at the cwd) starts.
    if (snapshotError !== null) fixture.snapshotError = snapshotError
    const calls = []
    const mockCall = connection.rpc.call
    connection.rpc.call = async (channel, endpoint, payload) => {
      const request = payload && payload.args && payload.args.request
      if (endpoint === 'dbGitPanel/query' && request && request.query && request.query.kind === 'repo-list') calls.push(1)
      return mockCall(channel, endpoint, payload)
    }
    const value = { showInputPill: true, placement: 'all', codeWorkspace: 'off' }
    const settings = { view: { namespaces: [{ ns: 'dbGitPanel', schema: { dict: { showInputPill: {}, placement: {}, codeWorkspace: {} } }, value }] }, status: 'ready' }
    const configForms = {
      describe: () => ({ getSnapshot: () => settings, subscribe: () => () => {}, ensure: async () => {} }),
      get: () => ({
        getSnapshot: () => ({ status: 'ready', value, revision: 0, writable: true }),
        subscribe: () => () => {},
        set: async (field, next) => {
          window.__gpWrites = [...(window.__gpWrites ?? []), [field, next]]
          // An enabled host answers the next read with the file recognised, its
          // roots listed, and a worktree of the own repository outside the cwd —
          // the row this release made selectable.
          if (applyOnWrite && field === 'codeWorkspace' && writeResult) {
            fixture.repoWorkspace = { state: 'applied', file: '/mock/hub/lab.code-workspace', roots: 2 }
            fixture.repos = [
              { path: '', root: '/mock/hub', name: 'hub', kind: 'workspace', role: 'main', branch: 'main' },
              { path: '../service-a', root: '/mock/service-a', name: 'service-a', kind: 'external', role: 'repo', label: 'API' },
              { path: '../spike', root: '/mock/spike', name: 'spike', kind: 'nested', role: 'linked', branch: 'spike' },
            ]
          }
          return writeResult
        },
      }),
    }
    const services = withForm ? { connection, configForms } : { connection }
    window.__gpRepoListCalls = () => calls.length
    window.__gpRegistered = {}
    const registered = window.__gpRegistered
    const ctx = {
      get: (k) => services[k],
      effect: (cb) => { try { cb() } catch { /* ignore */ } },
      on: () => () => {},
      inject: (_deps, cb) => cb(ctx),
      slots: {
        inject: (name, provider) => provider(),
        register: (reg, component) => { registered[reg.name] = { reg, component }; return () => {} },
      },
      locale: { register: () => () => {}, bind: () => (key, params) => (dict[key] ?? key).replace(/\{(\w+)\}/g, (_, k) => String(params?.[k] ?? '')) },
    }
    window.__getLoaded().apply(ctx)
    const view = registered['conversation.view']
    if (!view) throw new Error('conversation.view was not registered')
    window.ReactDOM.createRoot(document.getElementById('panel'))
      .render(view.component({ sessionId: 'sess-1' }))
    await new Promise((r) => setTimeout(r, 500))
  }, { snap: SNAP, listed: repos, workspace: repoWorkspace, withForm, snapshotError, writeResult, applyOnWrite, dict: DICT })
  return { page, errors }
}

try {
  // ── 1. A hub with one workspace file: the block appears just to say so ──
  {
    const { page, errors } = await mount({
      repos: [],
      repoWorkspace: { state: 'available', file: '/mock/hub/lab.code-workspace', count: 1 },
    })
    const boot = await page.evaluate(() => {
      const hint = document.querySelector('.gp-repolist__hint')
      return {
        block: document.querySelector('.gp-repolist') !== null,
        rows: document.querySelectorAll('.gp-repolist__item').length,
        hint: hint === null ? null : hint.textContent,
        button: hint === null ? null : hint.querySelector('.gp-repolist__hint-act')?.textContent ?? null,
        warn: hint === null ? null : hint.classList.contains('gp-repolist__hint--warn'),
      }
    })
    assert.equal(boot.block, true, 'a hub with a workspace file renders the block (it used to be hidden)')
    assert.equal(boot.rows, 0, 'the offer adds no repository rows')
    assert.match(boot.hint, /lab\.code-workspace/, 'the row names the file it found')
    assert.equal(boot.button, 'Enable', 'the row carries the one-click switch')
    assert.equal(boot.warn, false, 'an offer is not a warning')
    assert.deepEqual(errors, [])
    await page.close()
  }

  // ── 2. Without the settings service there is nothing to click ────────────
  {
    const { page } = await mount({
      repos: [],
      repoWorkspace: { state: 'available', file: '/mock/hub/lab.code-workspace', count: 1 },
      withForm: false,
    })
    const act = await page.evaluate(() => document.querySelector('.gp-repolist__hint-act') === null)
    assert.equal(act, true, 'the switch hides when it could not write')
    await page.close()
  }

  // ── 3. Enabling it: the write lands and the list is fetched again ────────
  {
    const { page, errors } = await mount({
      repos: [],
      repoWorkspace: { state: 'available', file: '/mock/hub/lab.code-workspace', count: 1 },
      applyOnWrite: true,
    })
    await page.click('.gp-repolist__hint-act')
    const written = await page.evaluate(() => window.__gpWrites)
    assert.deepEqual(written, [['codeWorkspace', 'auto']], 'the switch writes the setting through the settings form')

    // The list is read again after the write settles; the roots replace the
    // offer once they arrive.
    await page.waitForFunction(() => document.querySelector('.gp-repolist__hint') === null, null, { timeout: 6000 })
    const after = await page.evaluate(() => ({
      rows: [...document.querySelectorAll('.gp-repolist__name')].map((el) => el.textContent),
      calls: window.__gpRepoListCalls(),
      disabled: [...document.querySelectorAll('.gp-repolist__item')].map((el) => el.classList.contains('gp-repolist__item--disabled')),
    }))
    // The family groups first (own checkout, then its worktrees), then the
    // foreign roots; within a group the host's order is preserved.
    assert.deepEqual(after.rows, ['hub', 'spike', 'API'], 'the roots the file certifies become rows')
    assert.ok(after.calls >= 2, 'the list was fetched again after the write')
    assert.deepEqual(after.disabled, [false, false, false], 'a worktree outside the cwd is selectable, not a dead row')
    assert.deepEqual(errors, [])
    await page.close()
  }

  // ── 4. A configured file that cannot be used says why ───────────────────
  {
    const { page } = await mount({
      repos: [WORKSPACE, EXTERNAL],
      repoWorkspace: { state: 'missing', file: '/mock/hub/gone.code-workspace' },
    })
    const hint = await page.evaluate(() => {
      const el = document.querySelector('.gp-repolist__hint')
      return {
        text: el?.textContent ?? null,
        warn: el?.classList.contains('gp-repolist__hint--warn') ?? null,
        noAction: el?.querySelector('.gp-repolist__hint-act') === null,
      }
    })
    assert.match(hint.text, /gone\.code-workspace/, 'a typo names the file it could not find')
    assert.match(hint.text, /not found/)
    assert.equal(hint.warn, true, 'a configured-but-unusable file is a warning')
    assert.equal(hint.noAction, true, 'nothing to enable here: the row is a statement')
    await page.close()
  }

  // ── 4b. An unusable file says which check refused it ────────────────────
  {
    // One message covered a malformed setting, a symlink out of the cwd, a
    // directory in the file's place, an oversized file, an unreadable file and
    // unparsable content — six repairs behind one sentence (ADR-0035).
    const { page } = await mount({
      repos: [WORKSPACE, EXTERNAL],
      repoWorkspace: { state: 'invalid', reason: 'parse', file: '/mock/hub/lab.code-workspace' },
    })
    const hint = await page.evaluate(() => {
      const el = document.querySelector('.gp-repolist__hint')
      return {
        text: el?.textContent ?? null,
        warn: el?.classList.contains('gp-repolist__hint--warn') ?? null,
      }
    })
    assert.match(hint.text, /could not be parsed/, 'the row names the failed check')
    assert.match(hint.text, /lab\.code-workspace/, 'and the file it refused')
    assert.equal(hint.warn, true, 'an unusable file is a warning')
    await page.close()
  }

  // ── 4c. A host that predates the reason still explains itself ────────────
  {
    // Old host, same state, no `reason`: the generic message is the honest
    // answer, because `invalid` alone does not say which check failed.
    const { page } = await mount({
      repos: [WORKSPACE, EXTERNAL],
      repoWorkspace: { state: 'invalid', file: '/mock/hub/lab.code-workspace' },
    })
    const text = await page.evaluate(() => document.querySelector('.gp-repolist__hint')?.textContent ?? null)
    assert.match(text, /unusable/, 'the generic message is still shown')
    assert.doesNotMatch(text, /could not be parsed|too large|symlink|regular file/, 'and it does not name a check the host never reported')
    await page.close()
  }

  // ── 5. No hint and one checkout: the block stays out of the way ──────────
  {
    const { page } = await mount({ repos: [WORKSPACE] })
    const seen = await page.evaluate(() => ({
      block: document.querySelector('.gp-repolist') !== null,
      hint: document.querySelector('.gp-repolist__hint') !== null,
    }))
    assert.equal(seen.block, false, 'one checkout is not a choice')
    assert.equal(seen.hint, false)
    await page.close()
  }

  // ── 6. Several candidates: stated, but nothing to click ──────────────────
  {
    const { page } = await mount({
      repos: [WORKSPACE, OUTSIDE_WORKTREE],
      repoWorkspace: { state: 'available', count: 2 },
    })
    const hint = await page.evaluate(() => {
      const el = document.querySelector('.gp-repolist__hint')
      return { text: el?.textContent ?? null, act: el?.querySelector('.gp-repolist__hint-act') ?? null }
    })
    assert.match(hint.text, /2 workspace files/, 'the count is stated')
    assert.equal(hint.act, null, 'auto cannot choose between them, so there is no switch to offer')
    await page.close()
  }

  // ── 7. Enabled but nothing to show: the row says which state the file is in ─
  {
    const { page } = await mount({
      repos: [WORKSPACE],
      repoWorkspace: { state: 'applied', file: '/mock/hub/lab.code-workspace', roots: 0 },
    })
    const hint = await page.evaluate(() => {
      const el = document.querySelector('.gp-repolist__hint')
      return {
        text: el?.textContent ?? null,
        warn: el?.classList.contains('gp-repolist__hint--warn') ?? null,
        noAction: el?.querySelector('.gp-repolist__hint-act') === null,
      }
    })
    assert.match(hint.text, /enabled/, 'an enabled file with no checkout says so instead of doing nothing')
    assert.equal(hint.warn, true, 'it is a warning: the feature is on and produces nothing')
    assert.equal(hint.noAction, true, 'nothing to click — the file is already read')
    await page.close()
  }

  // ── 8. A file whose roots the list already carries is not "empty" ────────
  {
    // The host merges a root the list already carries (a worktree of the
    // session's own repository) into that row and reports `roots`, so the rows
    // alone cannot tell "names nothing" from "names something already listed".
    // Reading `kind: 'external'` as the signal stated the opposite.
    const { page } = await mount({
      repos: [WORKSPACE, OUTSIDE_WORKTREE],
      repoWorkspace: { state: 'applied', file: '/mock/hub/lab.code-workspace', roots: 1 },
    })
    const seen = await page.evaluate(() => ({
      hint: document.querySelector('.gp-repolist__hint')?.textContent ?? null,
      rows: [...document.querySelectorAll('.gp-repolist__name')].map((el) => el.textContent),
    }))
    assert.equal(seen.hint, null, 'one stated root is not an empty workspace, even with no external row')
    assert.deepEqual(seen.rows, ['hub', 'spike'])
    await page.close()
  }

  // ── 9. Browser-only layout: the notice bar carries the offer ─────────────
  {
    // A cwd that is not a checkout has no Git pane, so the switcher's offer has
    // nowhere to land. This is the layout the issue was filed from.
    const { page, errors } = await mount({
      repos: [],
      repoWorkspace: { state: 'available', file: '/mock/hub/lab.code-workspace', count: 1 },
      snapshotError: { code: 'not-a-git-repo', cwd: '/mock/hub' },
      applyOnWrite: true,
    })
    const boot = await page.evaluate(() => {
      const notice = document.querySelector('.gp-notice')
      const act = notice?.querySelector('.gp-notice__act') ?? null
      return {
        notice: notice?.textContent ?? null,
        act: act?.textContent ?? null,
        warn: notice?.classList.contains('gp-notice--warn') ?? null,
      }
    })
    assert.match(boot.notice, /lab\.code-workspace/, 'the browser states which file it found')
    assert.equal(boot.act, 'Enable', 'and offers the same one-click switch')
    assert.equal(boot.warn, false, 'an offer is not a warning')

    await page.click('.gp-notice__act')
    assert.deepEqual(await page.evaluate(() => window.__gpWrites), [['codeWorkspace', 'auto']], 'the notice writes too')
    await page.waitForFunction(() => document.querySelector('.gp-notice') === null, null, { timeout: 6000 })
    assert.deepEqual(errors, [])
    await page.close()
  }

  // ── 10. A warning the browser shows is actually coloured like one ────────
  {
    const { page } = await mount({
      repos: [],
      repoWorkspace: { state: 'missing', file: '/mock/hub/gone.code-workspace' },
      snapshotError: { code: 'not-a-git-repo', cwd: '/mock/hub' },
    })
    const tone = await page.evaluate(() => {
      const notice = document.querySelector('.gp-notice--warn')
      return { text: notice?.textContent ?? null, color: notice === null ? null : getComputedStyle(notice).color }
    })
    assert.match(tone.text, /not found/)
    // Same trap as above, from the other side: `.gp-notice--warn` has to win
    // over the later `.gp-notice` colour declaration to be a warning at all.
    assert.equal(tone.color, 'rgb(224, 152, 46)', 'the warning tone reaches the rendered colour')
    await page.close()
  }

  // ── 11. A refused write says so instead of looking like a dead button ────
  {
    const { page } = await mount({
      repos: [],
      repoWorkspace: { state: 'available', file: '/mock/hub/lab.code-workspace', count: 1 },
      writeResult: false,
    })
    await page.click('.gp-repolist__hint-act')
    // The write is a round-trip through the settings form, so wait for the
    // refusal to land rather than reading one frame after the click.
    await page.waitForFunction(() => (window.__gpWrites ?? []).length === 1)
    await page.waitForFunction(() => /not written/.test(document.querySelector('.gp-repolist__hint')?.textContent ?? ''))
    const after = await page.evaluate(() => {
      const hint = document.querySelector('.gp-repolist__hint')
      return {
        text: hint?.textContent ?? null,
        warn: hint?.classList.contains('gp-repolist__hint--warn') ?? null,
        act: hint?.querySelector('.gp-repolist__hint-act') ?? null,
      }
    })
    assert.match(after.text, /not written/, 'the failure is stated, not swallowed')
    assert.equal(after.warn, true, 'and reads as a warning')
    assert.equal(after.act, null, 'the offer makes room for the explanation')
    await page.close()
  }

  // ── 12. The browser's notice carries the same per-reason wording ─────────
  {
    // A second render site with its own state branch: the reason has to reach
    // the notice bar too, not only the switcher's hint row.
    const { page } = await mount({
      repos: [],
      repoWorkspace: { state: 'invalid', reason: 'size', file: '/mock/hub/lab.code-workspace' },
      snapshotError: { code: 'not-a-git-repo', cwd: '/mock/hub' },
    })
    const notice = await page.evaluate(() => ({
      text: document.querySelector('.gp-notice')?.textContent ?? null,
      warn: document.querySelector('.gp-notice--warn') !== null,
    }))
    assert.match(notice.text, /too large/, 'the notice names the failed check')
    assert.match(notice.text, /lab\.code-workspace/, 'and the file it refused')
    assert.equal(notice.warn, true, 'it reads as a warning')
    await page.close()
  }

  console.log('code-workspace-hint: all assertions passed')
} finally {
  await browser.close()
}
