/**
 * E2E (merged into run3): portaled modals on a phone-sized viewport (they live outside .gp-panel,
 * so they adapt via viewport media queries, not the panel layout attribute).
 * Asserts: small confirm dialogs stay content-height (the tall near-fullscreen
 * sizing must not leak onto .gp-modal--sm — it used to stretch them to 90vh
 * with a huge dead area below the text), and the commit file-diff modal keeps
 * a tappable backdrop strip above/below itself.
 *
 * Isolated file:// harness, no dsh server. Requires test/e2e/setup.mjs first.
 */
import assert from 'node:assert/strict'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { dirname, resolve } from 'node:path'

// Merged into run3.mjs: there is no standalone scenario here to run. Fail
// loudly if someone points a script or a gate at this file directly.
if (process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.error('phone-modals-scenario is merged into run3.mjs: run node test/e2e/run3.mjs')
  process.exit(1)
}

const DIR = dirname(fileURLToPath(import.meta.url))
const harness = 'file://' + resolve(DIR, 'harness.html')

const FIXTURE_ROOT = 'fixture-repo'

const SNAP = {
  root: FIXTURE_ROOT, branch: 'main', head: 'de54fc0', unborn: false, dirty: true,
  staged: 0, modified: 2, untracked: 0, ahead: 0, behind: 0, hasUpstream: true,
  remote: null, lastCommit: null,
  changes: [
    { path: 'a.txt', status: 'modified', staged: false, isDirectory: false },
    { path: 'b.txt', status: 'modified', staged: false, isDirectory: false },
  ],
  stats: { fileCount: 2, staged: 0, modified: 2, untracked: 0, insertions: 3, deletions: 0, lastChangeAt: Date.now(), headCommittedAt: null },
  truncated: false, refreshIntervalMs: 0, showInputPill: true, defaultDiffView: 'unified', checkedAt: Date.now(),
}

const DIFF = 'diff --git a/a.txt b/a.txt\n--- a/a.txt\n+++ b/a.txt\n@@ -1,2 +1,3 @@\n line1\n+line1.5\n line2\n line3\n'

/** Run this scenario on the caller's browser; it owns only its own page. */
export async function run(browser) {
const page = await browser.newPage({ viewport: { width: 390, height: 844 } })
const errors = []
page.on('console', (msg) => { if (msg.type() === 'error') errors.push(msg.text()) })
page.on('pageerror', (e) => errors.push('PAGEERROR ' + e.message))
await page.goto(harness)
await page.addScriptTag({ path: resolve(DIR, 'client.js') })

const out = await page.evaluate(async ({ snap, diff }) => {
  const result = {}
  const connection = {
    rpc: {
      call: async (_ch, endpoint, payload) => {
        const request = payload && payload.args && payload.args.request
        if (endpoint === 'dbGitPanel/snapshot') return { ok: true, value: { ok: true, value: snap } }
        if (endpoint === 'dbGitPanel/query') {
          const q = request.query
          if (q.kind === 'branches') return { ok: true, value: { ok: true, value: { kind: 'branches', current: 'main', defaultBranch: null, local: [{ name: 'feature', shortHash: 'd196623' }, { name: 'main', shortHash: 'de54fc0' }], remote: [] } } }
          if (q.kind === 'tags') return { ok: true, value: { ok: true, value: { kind: 'tags', tags: [] } } }
          if (q.kind === 'authors') return { ok: true, value: { ok: true, value: { kind: 'authors', authors: ['Tester'] } } }
          if (q.kind === 'history') return { ok: true, value: { ok: true, value: { kind: 'history', total: 1, commits: [{ hash: 'de54fc0bbb', shortHash: 'de54fc0', subject: 'init: first commit', author: 'Tester', dateIso: new Date().toISOString(), parents: [], refs: [] }] } } }
          if (q.kind === 'show') return { ok: true, value: { ok: true, value: { kind: 'show', ref: q.ref, commit: { hash: 'de54fc0bbb', shortHash: 'de54fc0', subject: 'init: first commit', author: 'Tester', dateIso: new Date().toISOString() }, body: '', stats: [{ path: 'a.txt', status: 'modified' }], insertions: 1, deletions: 0 } } }
          if (q.kind === 'diff') return { ok: true, value: { ok: true, value: { kind: 'diff', path: q.path, text: diff, newLines: 4 } } }
          if (q.kind === 'worktree-stats') return { ok: true, value: { ok: true, value: { kind: 'worktree-stats', stats: { fileCount: 2, staged: 0, modified: 2, untracked: 0, insertions: 3, deletions: 0, lastChangeAt: Date.now(), headCommittedAt: null } } } }
        }
        return { ok: false, error: { code: 'git-error', message: 'unhandled ' + endpoint } }
      },
    },
  }
  const registered = {}
  const services = { connection }
  const ctx = {
    get: (k) => services[k],
    effect: (cb) => { try { cb() } catch (e) { /* ignore */ } },
    on: () => () => {},
    inject: (_d, cb) => cb(ctx),
    slots: { inject: (_n, p) => p(), register: (reg, component) => { registered[reg.name] = { reg, component }; return () => {} } },
    locale: { register: () => () => {}, bind: () => (k) => k },
  }
  window.__getLoaded().apply(ctx)
  const ReactDOM = window.ReactDOM
  const panelHost = document.getElementById('panel')
  ReactDOM.createRoot(panelHost).render(registered['conversation.view'].component({ sessionId: 'sess-1' }))
  await new Promise((r) => setTimeout(r, 500))

  const tabByText = (t) => [...document.querySelectorAll('.gp-panel [role="tab"]')].find((x) => (x.textContent || '').includes(t))

  // A small confirm dialog (branch switch) opened from the overview branch row.
  tabByText('overview')?.click()
  await new Promise((r) => setTimeout(r, 300))
  const switchBtn = [...document.querySelectorAll('.gp-branch-row__switch')][0]
  if (switchBtn) { switchBtn.style.visibility = 'visible'; switchBtn.click() }
  await new Promise((r) => setTimeout(r, 200))
  const sm = document.querySelector('.gp-modal--sm')
  result.smShown = sm !== null
  if (sm) {
    const rect = sm.getBoundingClientRect()
    result.smHeight = Math.round(rect.height)
    // Content-sized: comfortably under half the viewport (it used to be 90vh).
    result.smContentSized = rect.height < window.innerHeight * 0.6
    result.smVerticallyCentered = Math.abs(rect.top - (window.innerHeight - rect.height) / 2) < 2
  }
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
  await new Promise((r) => setTimeout(r, 200))
  result.smClosed = document.querySelector('.gp-modal--sm') === null

  // The commit file-diff modal must keep a tappable backdrop strip AND its
  // compact two-row bar — the latter keys off the panel-width breakpoint, so
  // the panel host shrinks to a phone width here.
  panelHost.style.width = '390px'
  await new Promise((r) => setTimeout(r, 200))
  document.querySelector('.gp-commit-row')?.click()
  await new Promise((r) => setTimeout(r, 400))
  const treeRow = [...document.querySelectorAll('.gp-tree-row')].find((n) => (n.textContent || '').includes('a.txt'))
  result.detailTreeRow = treeRow !== undefined
  treeRow?.click()
  await new Promise((r) => setTimeout(r, 400))
  const modal = document.querySelector('.gp-modal:not(.gp-modal--sm)')
  result.diffModalShown = modal !== null
  if (modal) {
    const rect = modal.getBoundingClientRect()
    result.diffTopGap = Math.round(rect.top)
    result.diffBottomGap = Math.round(window.innerHeight - rect.bottom)
    result.diffFits = rect.top >= -0.5 && rect.bottom <= window.innerHeight + 0.5
    // The header path doubles as the copy control here too (same as the
    // changes toolbar): click writes the relative path, the confirmation is
    // a check mark + tints + the live region — the visible path stays put.
    window.__copiedPath = null
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: async (text) => { window.__copiedPath = text } } })
    const mpath = modal.querySelector('.gp-modal__path--copy')
    result.modalPathTag = mpath === null ? null : mpath.tagName
    result.modalPathTitle = mpath === null ? null : mpath.getAttribute('title')
    mpath?.click()
    await new Promise((r) => setTimeout(r, 150))
    result.modalPathCopied = window.__copiedPath
    const mcopy = modal.querySelector('.gp-modal__path--copy')
    result.modalPathFeedback = {
      cls: mcopy !== null && mcopy.classList.contains('gp-modal__path--copied'),
      check: (mcopy?.querySelector('svg') ?? null) !== null,
      name: mcopy?.querySelector('.gp-modal__name')?.textContent ?? null,
      live: mcopy?.querySelector('.gp-copy-live')?.textContent ?? null,
    }
    // The modal bar splits into two rows on compact: header row (icon, path,
    // hash, stats, expand) and a controls row (mode switches + bordered close
    // at its far right).
    const rows = [...modal.querySelectorAll('.gp-modal__bar-row')]
    result.barRows = rows.length
    const ctrlRow = modal.querySelector('.gp-modal__bar-row--controls')
    result.barCtrlRowHasModes = ctrlRow?.querySelector('.gp-diff__modes') !== null
    result.barCtrlRowHasClose = ctrlRow?.querySelector('.gp-modal__close') !== null
    // The border uses the platform theme variable (undefined in the isolated
    // harness), which would invalidate the shorthand — define it first.
    document.documentElement.style.setProperty('--dsw-alias-border-l2', '#888')
    result.barCloseBordered = ctrlRow !== null
      ? getComputedStyle(ctrlRow.querySelector('.gp-modal__close')).borderTopWidth === '1px'
      : false
    if (ctrlRow) {
      const closeRect = ctrlRow.querySelector('.gp-modal__close').getBoundingClientRect()
      const rowRect = ctrlRow.getBoundingClientRect()
      result.barCloseAtRowEnd = Math.abs(rowRect.right - closeRect.right) <= 2
      const modeBtns = [...ctrlRow.querySelectorAll('.gp-diff__modes .gp-diff__mode')]
      const tops = modeBtns.map((b) => Math.round(b.getBoundingClientRect().top))
      result.barModesOneLine = modeBtns.length === 2 && new Set(tops).size === 1
      const widths = modeBtns.map((b) => Math.round(b.getBoundingClientRect().width))
      result.barModesEvenWidth = widths.length === 2 && Math.max(...widths) - Math.min(...widths) <= 2
    }
  }
  return result
}, { snap: SNAP, diff: DIFF })

try {
  assert.equal(errors.length, 0, 'no console errors: ' + JSON.stringify(errors))
  assert.equal(out.smShown, true, 'the branch-switch confirm dialog opens')
  assert.equal(out.smContentSized, true, 'the small dialog is content-sized, not near-fullscreen')
  assert.equal(out.smVerticallyCentered, true, 'the small dialog is vertically centered')
  assert.equal(out.smClosed, true, 'Escape dismisses the dialog')
  assert.equal(out.detailTreeRow, true, 'the commit detail file tree renders')
  assert.equal(out.diffModalShown, true, 'the commit file-diff modal opens')
  assert.equal(out.diffFits, true, 'the diff modal fits inside the viewport')
  assert.ok(out.diffTopGap >= 20, 'a tappable backdrop strip remains above the diff modal: ' + out.diffTopGap)
  assert.ok(out.diffBottomGap >= 20, 'a tappable backdrop strip remains below the diff modal: ' + out.diffBottomGap)
  assert.equal(out.modalPathTag, 'BUTTON', 'the modal header path is a button')
  assert.equal(out.modalPathCopied, out.modalPathTitle, 'clicking the header path copies the relative path')
  assert.equal(out.modalPathFeedback.cls, true, 'the modal header shows the confirmation state')
  assert.equal(out.modalPathFeedback.check, true, 'the modal header shows the check mark')
  assert.equal(out.modalPathFeedback.name, 'a.txt', 'the filename stays on screen')
  assert.equal(out.modalPathFeedback.live, 'files.pathCopied', 'the phrase rides the live region')
  assert.equal(out.barRows, 2, 'the compact modal bar splits into two rows')
  assert.equal(out.barCtrlRowHasModes, true, 'the second row holds the mode switches')
  assert.equal(out.barCtrlRowHasClose, true, 'the second row holds the close button')
  assert.equal(out.barCloseBordered, true, 'the close button carries a border')
  assert.equal(out.barCloseAtRowEnd, true, 'the close button sits at the far right of the second row')
  assert.equal(out.barModesOneLine, true, 'the mode switches sit side by side on one line')
  assert.equal(out.barModesEvenWidth, true, 'the mode switches are evenly sized')
  console.log('e2e phone-modals (in run3): PASS', JSON.stringify(out))
} finally {
  await page.close()
}
}
