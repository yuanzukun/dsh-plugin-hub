/**
 * Action-plan tests: GitAction → git command sequences, including amend and
 * per-path commit, plus path-safety guards.
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { isSafePath, isSafeRev, isSafeBranchName, isSafeRemoteName, planAction, planRemoteBranchDelete, splitRemoteTrackingRef, classifyActionFailure, mergeIsOurs } from '../../lib/testkit.mjs'

test('isSafePath rejects absolute paths and .. traversal', () => {
  // POSIX assumptions: dsh runs on POSIX, so `C:\x` is a relative name here
  // (backslash is a normal path char) and passes; `.git/config` is in-repo and
  // low-risk. The rules that matter — absolute, empty, `..` escape — are covered.
  assert.equal(isSafePath('src/a.ts'), true)
  assert.equal(isSafePath('dir with spaces/файл.txt'), true)
  assert.equal(isSafePath(''), false)
  assert.equal(isSafePath('/etc/passwd'), false)
  assert.equal(isSafePath('../outside'), false)
  assert.equal(isSafePath('a/../../b'), false)
})

test('isSafeRev rejects option-injection and rev metacharacters', () => {
  assert.equal(isSafeRev('main'), true)
  assert.equal(isSafeRev('feature/x'), true)
  assert.equal(isSafeRev('0a1b2c3d'), true)
  assert.equal(isSafeRev(''), false)
  assert.equal(isSafeRev('--output=/tmp/pwn'), false, 'dash-prefixed → git option')
  assert.equal(isSafeRev('-f'), false)
  assert.equal(isSafeRev('a b'), false, 'whitespace')
  assert.equal(isSafeRev('HEAD~1'), false)
  assert.equal(isSafeRev('a..b'), false, 'rev range')
  assert.equal(isSafeRev('HEAD@{0}'), false)
  assert.equal(isSafeRev('a:b'), false)
  assert.equal(isSafeRev('a*'), false)
})

test('isSafeBranchName adds the leading-slash rule on top of isSafeRev', () => {
  assert.equal(isSafeBranchName('main'), true)
  assert.equal(isSafeBranchName('/abs'), false)
  assert.equal(isSafeBranchName('-f'), false)
})

test('commit without paths is a single git commit', () => {
  const plan = planAction({ kind: 'commit', message: 'hello' }, false)
  assert.deepEqual(plan.argv, [['git', 'commit', '-m', 'hello']])
})

test('commit --amend carries the amend flag', () => {
  const plan = planAction({ kind: 'commit', message: 'fixed', amend: true }, false)
  assert.deepEqual(plan.argv, [['git', 'commit', '--amend', '-m', 'fixed']])
})

test('amend with an empty message reuses the previous message via --no-edit', () => {
  const plan = planAction({ kind: 'commit', message: '', amend: true }, false)
  assert.deepEqual(plan.argv, [['git', 'commit', '--amend', '--no-edit']])
})

test('empty non-amend commit is rejected', () => {
  const plan = planAction({ kind: 'commit', message: '  ' }, false)
  assert.equal(plan.error, 'empty-message')
})

test('per-path commit stages then commits the chosen paths', () => {
  const plan = planAction({ kind: 'commit', message: 'm', paths: ['a.txt', 'b.txt'] }, false)
  assert.deepEqual(plan.argv, [
    ['git', 'add', '--', 'a.txt', 'b.txt'],
    ['git', 'commit', '-m', 'm', '--', 'a.txt', 'b.txt'],
  ])
})

test('unsafe path in a commit is rejected', () => {
  const plan = planAction({ kind: 'commit', message: 'm', paths: ['../evil'] }, false)
  assert.equal(plan.error, 'invalid-path')
})

test('unstage uses rm --cached when unborn, restore otherwise', () => {
  const unborn = planAction({ kind: 'unstage', paths: ['a.txt'] }, true)
  assert.deepEqual(unborn.argv, [['git', 'rm', '--cached', '-r', '--', 'a.txt']])
  const born = planAction({ kind: 'unstage', paths: ['a.txt'] }, false)
  assert.deepEqual(born.argv, [['git', 'restore', '--staged', '--', 'a.txt']])
})

test('stage-all / fetch produce their fixed commands', () => {
  assert.deepEqual(planAction({ kind: 'stage-all' }, false).argv, [['git', 'add', '-A']])
  assert.deepEqual(planAction({ kind: 'fetch' }, false).argv, [['git', 'fetch', '--all', '--prune']])
})

test('stage / discard produce path-scoped commands', () => {
  assert.deepEqual(planAction({ kind: 'stage', paths: ['a.txt'] }, false).argv, [['git', 'add', '--', 'a.txt']])
  assert.deepEqual(planAction({ kind: 'discard', paths: ['a.txt'] }, false).argv, [['git', 'restore', '--', 'a.txt']])
  assert.equal(planAction({ kind: 'stage', paths: ['../evil'] }, false).error, 'invalid-path')
})

test('unstage-all uses rm --cached . when unborn, restore --staged . otherwise', () => {
  assert.deepEqual(planAction({ kind: 'unstage-all' }, true).argv, [['git', 'rm', '--cached', '-r', '--', '.']])
  assert.deepEqual(planAction({ kind: 'unstage-all' }, false).argv, [['git', 'restore', '--staged', '--', '.']])
})

test('branch-checkout guards the name and ends the command with -- (no path fallback)', () => {
  // The trailing `--` is not `--end-of-options` (checkout rejects that): it stops
  // a name that is also a path from being restored from the index.
  assert.deepEqual(
    planAction({ kind: 'branch-checkout', name: 'feature/x' }, false).argv,
    [['git', 'checkout', 'feature/x', '--']],
  )
  assert.equal(planAction({ kind: 'branch-checkout', name: '-f' }, false).error, 'invalid-name')
  assert.equal(planAction({ kind: 'branch-checkout', name: '/abs' }, false).error, 'invalid-name')
  assert.equal(planAction({ kind: 'branch-checkout', name: '.' }, false).error, 'invalid-name', 'git checkout . would revert the work tree')
  assert.equal(planAction({ kind: 'branch-checkout', name: 'v1.' }, false).error, 'invalid-name')
  assert.equal(planAction({ kind: 'branch-checkout', name: 'x.lock' }, false).error, 'invalid-name')
})

test('branch-checkout with createFrom creates the local branch and tracks the remote ref', () => {
  // A remote row must never run `git checkout origin/x` (that detaches HEAD);
  // `-b <name> --track` is the deterministic create-and-track form.
  assert.deepEqual(
    planAction({ kind: 'branch-checkout', name: 'feature', createFrom: 'origin/feature' }, false).argv,
    [['git', 'checkout', '-b', 'feature', '--track', 'origin/feature', '--']],
  )
  assert.equal(
    planAction({ kind: 'branch-checkout', name: 'x', createFrom: '--upload-pack=/tmp/pwn' }, false).error,
    'invalid-name',
    'the tracking ref is validated just like the branch name',
  )
  assert.equal(planAction({ kind: 'branch-checkout', name: 'x', createFrom: '-b' }, false).error, 'invalid-name')
})

test('branch-checkout with stashMessage stashes first (untracked included) and then switches', () => {
  const plan = planAction(
    { kind: 'branch-checkout', name: 'dev', createFrom: 'origin/dev', stashMessage: '  auto stash  ' },
    false,
  )
  assert.deepEqual(plan.argv, [
    ['git', 'stash', 'push', '-u', '-m', 'auto stash'],
    ['git', 'checkout', '-b', 'dev', '--track', 'origin/dev', '--'],
  ])
  assert.deepEqual(
    planAction({ kind: 'branch-checkout', name: 'dev', stashMessage: '   ' }, false).argv,
    [['git', 'checkout', 'dev', '--']],
    'a blank stash message is not a stash step',
  )
})

test('tag-create builds a lightweight tag and guards name + commit', () => {
  assert.deepEqual(
    planAction({ kind: 'tag-create', name: 'v1.0', commit: 'abc123' }, false).argv,
    [['git', 'tag', '--end-of-options', 'v1.0', 'abc123']],
  )
  assert.equal(planAction({ kind: 'tag-create', name: '-f', commit: 'abc123' }, false).error, 'invalid-name')
  assert.equal(planAction({ kind: 'tag-create', name: 'v1', commit: '--output=x' }, false).error, 'invalid-name')
})

test('tag-create with a message builds an annotated tag (-a -m)', () => {
  assert.deepEqual(
    planAction({ kind: 'tag-create', name: 'v1.0', commit: 'abc123', message: 'release' }, false).argv,
    [['git', 'tag', '-a', '-m', 'release', '--end-of-options', 'v1.0', 'abc123']],
  )
  // A blank/whitespace message degrades to a lightweight tag (no -a).
  assert.deepEqual(
    planAction({ kind: 'tag-create', name: 'v1.0', commit: 'abc123', message: '   ' }, false).argv,
    [['git', 'tag', '--end-of-options', 'v1.0', 'abc123']],
  )
})

test('tag-delete guards the name and passes it after --end-of-options', () => {
  assert.deepEqual(planAction({ kind: 'tag-delete', name: 'v1.0' }, false).argv, [['git', 'tag', '-d', '--end-of-options', 'v1.0']])
  assert.equal(planAction({ kind: 'tag-delete', name: '-d' }, false).error, 'invalid-name')
})

test('branch-delete plans the safe -d first and the forced -D only when asked', () => {
  assert.deepEqual(
    planAction({ kind: 'branch-delete', name: 'feature/x' }, false).argv,
    [['git', 'branch', '-d', '--end-of-options', 'feature/x']],
  )
  assert.deepEqual(
    planAction({ kind: 'branch-delete', name: 'feature/x', force: true }, false).argv,
    [['git', 'branch', '-D', '--end-of-options', 'feature/x']],
  )
  // The name reaches argv only after the same guard checkout/tag deletion uses.
  assert.equal(planAction({ kind: 'branch-delete', name: '-f' }, false).error, 'invalid-name')
  assert.equal(planAction({ kind: 'branch-delete', name: '--force' }, false).error, 'invalid-name')
  assert.equal(planAction({ kind: 'branch-delete', name: 'a b' }, false).error, 'invalid-name')
})

test('set-upstream validates the remote before runAction resolves the branch', () => {
  // The branch never crosses the wire; the planner only screens the one field
  // the request carries, so a hostile remote can never reach the later argv.
  assert.equal(planAction({ kind: 'set-upstream', remote: '--upload-pack=/tmp/pwn' }, false).error, 'invalid-name')
  assert.equal(isSafeRemoteName('origin'), true)
  assert.equal(isSafeRemoteName('origin name'), false, 'whitespace cannot reach an argv element')
})

test('branch-delete-remote plans a server-side delete of the full heads ref', () => {
  assert.deepEqual(
    planRemoteBranchDelete('origin', 'feature/x').argv,
    [['git', 'push', '--delete', 'origin', 'refs/heads/feature/x']],
  )
  // The full destination ref is what makes a same-named tag unreachable.
  assert.equal(planRemoteBranchDelete('--upload-pack=/tmp/pwn', 'x').error, 'invalid-name')
  assert.equal(planRemoteBranchDelete('origin', '-f').error, 'invalid-name')
  assert.equal(planRemoteBranchDelete('origin', '').error, 'invalid-name')
})

test('splitRemoteTrackingRef resolves the remote from the configured names, longest first', () => {
  assert.deepEqual(splitRemoteTrackingRef('refs/remotes/origin/feature/x', ['origin']), { remote: 'origin', branch: 'feature/x' })
  // A remote name may contain '/': the longest configured prefix wins instead of
  // splitting at the first slash (which would address remote 'foo').
  assert.deepEqual(splitRemoteTrackingRef('refs/remotes/foo/bar/topic/x', ['foo', 'foo/bar']), { remote: 'foo/bar', branch: 'topic/x' })
  assert.deepEqual(splitRemoteTrackingRef('refs/remotes/origin/x', ['origin', 'upstream']), { remote: 'origin', branch: 'x' })
  assert.equal(splitRemoteTrackingRef('refs/remotes/origin/x', ['upstream']), null, 'no configured remote matches')
  assert.equal(splitRemoteTrackingRef('refs/remotes/origin/x', []), null)
  assert.equal(splitRemoteTrackingRef('refs/heads/origin/x', ['origin']), null, 'not a remote-tracking ref')
  assert.equal(splitRemoteTrackingRef('refs/remotes/origin/', ['origin']), null, 'empty branch')
  assert.equal(splitRemoteTrackingRef('refs/remotes/origin/-f', ['origin']), null, 'unsafe branch stays out')
})

test('planAction refuses an unresolved remote delete instead of guessing', () => {
  const plan = planAction({ kind: 'branch-delete-remote', ref: 'refs/remotes/origin/x' }, false)
  assert.equal(plan.error, 'invalid-name')
})

test('planAction refuses the Git Flow actions (the flow runner executes them)', () => {
  const actions = [
    { kind: 'flow-start', flow: 'feature', branch: 'feature/x', base: 'develop' },
    {
      kind: 'flow-finish', flow: 'feature', branch: 'feature/x', target: 'develop',
      strategy: 'merge', message: 'finish',
    },
    { kind: 'flow-integrate', develop: 'develop' },
  ]
  for (const action of actions) {
    const plan = planAction(action, false)
    assert.equal(plan.error, 'git-error', `${action.kind} must not be planned into a bare argv`)
    assert.equal('argv' in plan, false)
  }
})

test('stash-push builds push with/without a message', () => {
  assert.deepEqual(planAction({ kind: 'stash-push' }, false).argv, [['git', 'stash', 'push']])
  assert.deepEqual(planAction({ kind: 'stash-push', message: 'wip' }, false).argv, [['git', 'stash', 'push', '-m', 'wip']])
  assert.deepEqual(planAction({ kind: 'stash-push', message: '  ' }, false).argv, [['git', 'stash', 'push']])
})

test('stash apply/pop/drop reference stash@{N} from a validated integer index', () => {
  assert.deepEqual(planAction({ kind: 'stash-apply', index: 0, sha: 'x' }, false).argv, [['git', 'stash', 'apply', '--end-of-options', 'stash@{0}']])
  assert.deepEqual(planAction({ kind: 'stash-pop', index: 2, sha: 'x' }, false).argv, [['git', 'stash', 'pop', '--end-of-options', 'stash@{2}']])
  assert.deepEqual(planAction({ kind: 'stash-drop', index: 1, sha: 'x' }, false).argv, [['git', 'stash', 'drop', '--end-of-options', 'stash@{1}']])
  assert.equal(planAction({ kind: 'stash-drop', index: -1, sha: 'x' }, false).error, 'invalid-index')
  assert.equal(planAction({ kind: 'stash-apply', index: 1.5, sha: 'x' }, false).error, 'invalid-index')
})

test('revert builds a no-edit reverse commit and guards the commit', () => {
  assert.deepEqual(
    planAction({ kind: 'revert', commit: 'abc123' }, false).argv,
    [['git', 'revert', '--no-edit', '--end-of-options', 'abc123']],
  )
  assert.equal(planAction({ kind: 'revert', commit: '--output=x' }, false).error, 'invalid-name')
})

test('reset builds --soft/--mixed/--hard, guards the commit, and rejects a bad mode', () => {
  assert.deepEqual(planAction({ kind: 'reset', commit: 'abc123', mode: 'soft' }, false).argv, [['git', 'reset', '--soft', 'abc123', '--']])
  assert.deepEqual(planAction({ kind: 'reset', commit: 'abc123', mode: 'mixed' }, false).argv, [['git', 'reset', '--mixed', 'abc123', '--']])
  assert.deepEqual(planAction({ kind: 'reset', commit: 'abc123', mode: 'hard' }, false).argv, [['git', 'reset', '--hard', 'abc123', '--']])
  assert.equal(planAction({ kind: 'reset', commit: '-f', mode: 'hard' }, false).error, 'invalid-name')
  assert.equal(planAction({ kind: 'reset', commit: 'abc123', mode: 'bogus' }, false).error, 'invalid-name')
})

test('classifyActionFailure orders conflict before nothing-to-commit, and maps codes', () => {
  // A stash pop conflict prints BOTH "CONFLICT" and "no changes added to commit";
  // conflict must win (git keeps the stash → recoverable).
  const popConflict = classifyActionFailure('Auto-merging a\nCONFLICT (content): Merge conflict in a\nno changes added to commit', '', 1)
  assert.equal(popConflict.code, 'conflict')
  assert.equal(classifyActionFailure('', 'fatal: Unable to create .git/index.lock: File exists', 128).code, 'index-busy')
  // A commit with nothing staged prints its refusal on stdout (exit 1) and
  // leaves stderr empty; with untracked files present the wording differs.
  const nothing = classifyActionFailure('nothing to commit, working tree clean', '', 1)
  assert.equal(nothing.code, 'nothing-to-commit')
  assert.equal(nothing.message, '')
  assert.equal(classifyActionFailure('', 'nothing added to commit but untracked files present', 1).code, 'nothing-to-commit')
  assert.equal(classifyActionFailure('', "error: tag 'nope' not found.", 1).code, 'not-found')
  assert.equal(classifyActionFailure('', "error: branch 'nope' not found", 1).code, 'not-found')
  assert.equal(classifyActionFailure('', 'is not a valid reference', 1).code, 'not-found')
  // Branch delete: an unmerged branch is a refusal the dialog turns into its
  // forced step, while a branch that is still a HEAD anywhere is a hard stop
  // (the older and newer git wordings are both classified).
  assert.equal(classifyActionFailure('', "error: the branch 'dev' is not fully merged", 1).code, 'branch-unmerged')
  // Remote delete: a ref the remote no longer has is a not-found (it wins over
  // the generic "failed to push" line), while a server-side refusal stays a
  // push rejection.
  assert.equal(classifyActionFailure('', "error: unable to delete 'refs/heads/x': remote ref does not exist\nerror: failed to push some refs", 1).code, 'not-found')
  assert.equal(classifyActionFailure('', ' ! [remote rejected] x (deletion prohibited)\nerror: failed to push some refs', 1).code, 'push-rejected')
  assert.equal(classifyActionFailure('', "error: cannot delete branch 'dev' used by worktree at '/tmp/wt'", 1).code, 'branch-checked-out')
  assert.equal(classifyActionFailure('', "error: Cannot delete branch 'dev' checked out at '/tmp/wt'", 1).code, 'branch-checked-out')
  assert.equal(classifyActionFailure('', 'error: Your local changes to the following files would be overwritten by merge', 1).code, 'local-changes-block')
  // A switch refused because the target branch is checked out in another worktree.
  assert.equal(classifyActionFailure('', "fatal: 'dev' is already used by worktree at '/tmp/wt'", 128).code, 'branch-in-use')
  assert.equal(classifyActionFailure('', "fatal: 'dev' is already checked out at '/tmp/wt'", 128).code, 'branch-in-use')
  // A checkout target that is neither a ref nor a path. The sibling message git
  // prints for `git add <missing path>` ("did not match any files") must NOT be
  // swallowed by this rule — only the "known to git" form is a ref miss.
  assert.equal(classifyActionFailure('', "error: pathspec 'nope' did not match any file(s) known to git", 1).code, 'not-found')
  assert.equal(classifyActionFailure('', "fatal: pathspec 'a.txt' did not match any files", 128).code, 'git-error')
  assert.equal(classifyActionFailure('', 'error: Your local changes would be overwritten by checkout', 1).code, 'local-changes-block')
  assert.equal(classifyActionFailure('', 'error: The following untracked working tree files would be overwritten by checkout:\n\tdev.txt', 1).code, 'local-changes-block')
  assert.equal(classifyActionFailure('', 'something else entirely', 1).code, 'git-error')
})

test('branch-create plans a plain branch write at the validated start point (#118)', () => {
  assert.deepEqual(
    planAction({ kind: 'branch-create', name: 'feature/x', start: 'refs/heads/main' }, false).argv,
    [['git', 'branch', '--end-of-options', 'feature/x', 'refs/heads/main']],
  )
  // The start point may be a full hash (commit row) or a remote-tracking ref —
  // an address no bare short name could shadow reaches argv only after the guard.
  assert.deepEqual(
    planAction({ kind: 'branch-create', name: 'x', start: 'a'.repeat(40) }, false).argv,
    [['git', 'branch', '--end-of-options', 'x', 'a'.repeat(40)]],
  )
  assert.equal(planAction({ kind: 'branch-create', name: '-f', start: 'refs/heads/main' }, false).error, 'invalid-name')
  assert.equal(planAction({ kind: 'branch-create', name: 'x', start: '--force' }, false).error, 'invalid-name')
  assert.equal(planAction({ kind: 'branch-create', name: 'x', start: 'a b' }, false).error, 'invalid-name')
})

test('pull-merge is resolved before planning, never planned as a bare command (ADR-0036)', () => {
  // The upstream ref must come from HEAD, the fetch needs the configured
  // remote, and the merge needs its own abort path; a plan that reached the
  // generic runner would be missing all three.
  assert.equal(planAction({ kind: 'pull-merge' }, false).error, 'invalid-name')
})

test('mergeIsOurs only accepts the merge this action started (ADR-0036)', () => {
  const before = 'a'.repeat(40)
  const tip = 'b'.repeat(40)
  assert.equal(mergeIsOurs(before, tip, before, tip), true, 'HEAD unchanged and MERGE_HEAD is our upstream tip')
  assert.equal(mergeIsOurs(before, tip, 'c'.repeat(40), tip), false, 'HEAD moved: the merge belongs to another actor')
  assert.equal(mergeIsOurs(before, tip, before, 'c'.repeat(40)), false, 'MERGE_HEAD is another commit')
  assert.equal(mergeIsOurs('', tip, '', tip), false, 'no pre-merge HEAD establishes nothing')
  assert.equal(mergeIsOurs(before, '', before, ''), false, 'no resolved upstream tip establishes nothing')
})

test('branch-merge and cherry-pick pass a validated ref after --end-of-options (#118)', () => {
  assert.deepEqual(
    planAction({ kind: 'branch-merge', name: 'refs/heads/feature/x' }, false).argv,
    [['git', 'merge', '--end-of-options', 'refs/heads/feature/x']],
  )
  assert.equal(planAction({ kind: 'branch-merge', name: '-X ours' }, false).error, 'invalid-name')
  assert.equal(planAction({ kind: 'branch-merge', name: 'a b' }, false).error, 'invalid-name')
  assert.deepEqual(
    planAction({ kind: 'cherry-pick', commit: 'abc123' }, false).argv,
    [['git', 'cherry-pick', '--end-of-options', 'abc123']],
  )
  assert.equal(planAction({ kind: 'cherry-pick', commit: '--output=x' }, false).error, 'invalid-name')
})

test('classifyActionFailure maps the branch-create and pick outcomes (#118)', () => {
  // A taken name: nothing was created, and the dialog asks for another one.
  assert.equal(classifyActionFailure('', "fatal: a branch named 'main' already exists", 128).code, 'branch-exists')
  // An unknown start point for `git branch`.
  assert.equal(classifyActionFailure('', "fatal: not a valid object name: 'nosuchref'", 128).code, 'not-found')
  // An empty cherry-pick prints git's "nothing to commit" over a clean tree;
  // the sequencer state it leaves behind is cleaned up by runAction, not here.
  assert.equal(
    classifyActionFailure('The previous cherry-pick is now empty, possibly due to conflict resolution.\nnothing to commit, working tree clean', '', 1).code,
    'nothing-to-commit',
  )
  // A merge/cherry-pick conflict classifies as the conflict the abort path keys on.
  assert.equal(classifyActionFailure('Auto-merging f\nCONFLICT (content): Merge conflict in f', '', 1).code, 'conflict')
})

test('a merge target that resolves nowhere is a not-found, not a raw git error (#118)', () => {
  // `git merge` prints this one to stdout (exit 1), unlike most ref misses.
  assert.equal(classifyActionFailure('merge: refs/heads/nope - not something we can merge', '', 1).code, 'not-found')
})
