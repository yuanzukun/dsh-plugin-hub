/**
 * pushIntent / canPublish: which remote write the sync controls may offer.
 *
 * The panel has exactly one upload control per surface, so these predicates are
 * the single gate for both the overview status bar and the changes toolbar. A
 * branch that only exists locally must offer a publish (creating a same-named
 * remote branch cannot overwrite anything — issue #63), while a detached HEAD,
 * an unborn repository and a repo with no remote must all stay unavailable.
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { canPush, canPublish, pushIntent } from '../../lib/testkit.mjs'

const REMOTE = { name: 'origin', url: 'git@github.com:owner/repo.git', webUrl: 'https://github.com/owner/repo', host: 'github.com', hostKind: 'github' }

/** A snapshot with every precondition satisfied; each test varies one field. */
function snap(overrides = {}) {
  return {
    branch: 'feature/x', head: 'abc1234', unborn: false,
    hasUpstream: false, ahead: 0, behind: 0, remote: REMOTE,
    ...overrides,
  }
}

test('a local-only branch with commits and a remote can be published', () => {
  assert.equal(canPublish(snap()), true)
  assert.equal(pushIntent(snap()), 'publish')
})

test('publish is offered even when the local-only branch has no commits ahead of anything', () => {
  // ahead/behind are meaningless without an upstream; only the remote write
  // matters, so any count still publishes.
  for (const counts of [{ ahead: 0, behind: 0 }, { ahead: 5, behind: 0 }, { ahead: 0, behind: 3 }]) {
    assert.equal(pushIntent(snap(counts)), 'publish', `ahead/behind ${JSON.stringify(counts)} still publishes`)
  }
})

test('a detached HEAD has no branch to publish', () => {
  assert.equal(canPublish(snap({ branch: null })), false)
  assert.equal(pushIntent(snap({ branch: null })), null)
})

test('an unborn repository has nothing to publish', () => {
  // git cannot push a branch whose commit does not exist yet: `push -u origin
  // HEAD` fails with "src refspec HEAD does not match any".
  assert.equal(canPublish(snap({ unborn: true, head: null })), false)
  assert.equal(pushIntent(snap({ unborn: true, head: null })), null)
  // A snapshot without a usable HEAD is treated the same way.
  assert.equal(canPublish(snap({ head: '' })), false)
  assert.equal(canPublish(snap({ head: null })), false)
})

test('a repository with no remote has nowhere to publish to', () => {
  assert.equal(canPublish(snap({ remote: null })), false)
  assert.equal(pushIntent(snap({ remote: null })), null)
})

test('an existing upstream is never published, only pushed when strictly ahead', () => {
  const upstream = { hasUpstream: true }
  assert.equal(pushIntent(snap({ ...upstream, ahead: 3, behind: 0 })), 'push')
  assert.equal(canPublish(snap({ ...upstream, ahead: 3, behind: 0 })), false, 'a branch with an upstream is never published')
  // Nothing to send: neither intent applies.
  assert.equal(pushIntent(snap({ ...upstream, ahead: 0, behind: 0 })), null)
  // Diverged: deliberately offered neither (the user must reconcile first).
  assert.equal(pushIntent(snap({ ...upstream, ahead: 2, behind: 3 })), null)
  // Strictly behind: pull territory, never an upload.
  assert.equal(pushIntent(snap({ ...upstream, ahead: 0, behind: 4 })), null)
})

test('push and publish can never both apply to one snapshot', () => {
  const cases = [
    snap(), snap({ branch: null }), snap({ unborn: true }), snap({ remote: null }),
    snap({ hasUpstream: true, ahead: 5, behind: 0 }), snap({ hasUpstream: true, ahead: 0, behind: 0 }),
  ]
  for (const snapshot of cases) {
    assert.ok(!(canPush(snapshot) && canPublish(snapshot)), `both intents on ${JSON.stringify(snapshot)}`)
  }
})
