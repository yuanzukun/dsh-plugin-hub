/**
 * GitAction → command sequence construction + execution.
 */
import { randomUUID } from 'node:crypto'
import { tmpdir } from 'node:os'
import { dirname, isAbsolute, join, sep } from 'node:path'
import type { SnapshotDeps, GitPanelConfig } from './core.js'
import { mapWorkspaceFailure, resolveWorkspace, runCommand, snapshotForSession } from './core.js'
import { parseStatus } from './parser.js'
import { isSafeBranchName, isSafePath, isSafeRemoteName, isSafeRev } from './validate.js'
import type { GitAction, GitActionRequest, GitActionResult, GitErrorCode } from './types.js'

export { isSafePath }

interface CommandPlan {
  readonly argv: readonly (readonly string[])[]
}
type PlanResult = CommandPlan | { readonly error: GitErrorCode; readonly message?: string }

function withPaths(prefixes: readonly (readonly string[])[], paths: readonly string[]): PlanResult {
  if (paths.length === 0) return { error: 'invalid-path', message: 'no paths given' }
  for (const path of paths) {
    if (!isSafePath(path)) return { error: 'invalid-path', message: `unsafe path: ${path}` }
  }
  return { argv: prefixes.map((prefix) => [...prefix, ...paths]) }
}

/**
 * Split a remote-tracking ref into its configured remote and the branch below
 * it. The remote is matched against the configured names with the longest
 * prefix winning, because a remote name may itself contain `/`: splitting at
 * the first slash would address the wrong server (`foo/bar` vs `foo`). Null
 * when the ref names no configured remote or no safe branch below it.
 */
export function splitRemoteTrackingRef(
  ref: string, remotes: readonly string[],
): { readonly remote: string; readonly branch: string } | null {
  const prefix = 'refs/remotes/'
  if (!ref.startsWith(prefix)) return null
  const rest = ref.slice(prefix.length)
  let best: string | null = null
  for (const remote of remotes) {
    if (!isSafeRemoteName(remote) || !rest.startsWith(`${remote}/`)) continue
    if (best === null || remote.length > best.length) best = remote
  }
  if (best === null) return null
  const branch = rest.slice(best.length + 1)
  return branch !== '' && isSafeBranchName(branch) ? { remote: best, branch } : null
}

/** Plan a remote branch deletion. The destination is the full `refs/heads/…`
 * ref, so a tag sharing the branch's name can never be what `--delete` hits. */
export function planRemoteBranchDelete(remote: string, branch: string, expectedOid?: string): PlanResult {
  if (!isSafeRemoteName(remote)) return { error: 'invalid-name', message: `unsafe remote name: ${remote}` }
  if (!isSafeBranchName(branch)) return { error: 'invalid-name', message: `unsafe branch name: ${branch}` }
  if (expectedOid !== undefined && !isSafeRev(expectedOid)) return { error: 'invalid-name', message: `unsafe expected remote oid: ${expectedOid}` }
  return {
    argv: [[
      'git', 'push',
      ...(expectedOid === undefined ? [] : [`--force-with-lease=refs/heads/${branch}:${expectedOid}`]),
      '--delete', remote, `refs/heads/${branch}`,
    ]],
  }
}

/** Build the git command sequence for an action. */
export function planAction(action: GitAction, unborn: boolean): PlanResult {
  switch (action.kind) {
    case 'stage':
      return withPaths([['git', 'add', '--']], action.paths)
    case 'stage-all':
      return { argv: [['git', 'add', '-A']] }
    case 'unstage':
      return unborn
        ? withPaths([['git', 'rm', '--cached', '-r', '--']], action.paths)
        : withPaths([['git', 'restore', '--staged', '--']], action.paths)
    case 'unstage-all':
      return unborn
        ? { argv: [['git', 'rm', '--cached', '-r', '--', '.']] }
        : { argv: [['git', 'restore', '--staged', '--', '.']] }
    case 'discard':
      return withPaths([['git', 'restore', '--']], action.paths)
    case 'discard-all':
      // Unreachable from runAction: the executor resolves `discard-all` into a
      // concrete `discard` (fresh status → paths) before planning. Kept as a
      // typed refusal so a future caller cannot plan it into a bare restore.
      return { error: 'invalid-path', message: 'discard-all must be resolved to paths before planning' }
    case 'commit': {
      // A mixed selection needs a temporary index (runIndexOnlyCommit); refusing
      // here keeps a future caller from silently staging every path instead.
      if ((action.indexOnly?.length ?? 0) > 0) {
        return { error: 'git-error', message: 'indexOnly commits are planned by runIndexOnlyCommit' }
      }
      const message = action.message.trim()
      const amend = action.amend === true
      if (message === '' && !amend) return { error: 'empty-message' }
      // amend + empty message: reuse the previous message. Without -m and with
      // no TTY (`stdin:'ignore'`) git would abort asking for a message, so pass
      // --no-edit to keep the existing one.
      const amendFlag = amend ? ['--amend'] : []
      const msgArgs = message === '' ? ['--no-edit'] : ['-m', message]
      if (action.paths === undefined || action.paths.length === 0) {
        return { argv: [['git', 'commit', ...amendFlag, ...msgArgs]] }
      }
      const staged = withPaths([['git', 'add', '--']], action.paths)
      if ('error' in staged) return staged
      const commitCmd = ['git', 'commit', ...amendFlag, ...msgArgs, '--', ...action.paths]
      return { argv: [...staged.argv, commitCmd] }
    }
    case 'branch-checkout': {
      if (!isSafeBranchName(action.name)) return { error: 'invalid-name', message: `unsafe branch name: ${action.name}` }
      // The trailing `--` disambiguates a name that is also a work-tree path:
      // `git checkout f.txt` restores that file from the index and exits 0
      // (`git checkout .` would revert the whole work tree), which the panel
      // would report as a successful switch. As a trailing separator it is not
      // `--end-of-options` — every git version accepts it; isSafeBranchName
      // still rules out a leading dash, which is the option-position surface.
      let checkout = ['git', 'checkout', action.name, '--']
      if (action.createFrom !== undefined) {
        // A remote row: create the local branch explicitly and set its upstream.
        // `-b <name> --track <ref>` is deterministic — `git checkout <remote>/<x>`
        // would detach HEAD instead, and DWIM name inference depends on config.
        if (!isSafeBranchName(action.createFrom)) return { error: 'invalid-name', message: `unsafe tracking ref: ${action.createFrom}` }
        checkout = ['git', 'checkout', '-b', action.name, '--track', action.createFrom, '--']
      }
      const msg = action.stashMessage?.trim() ?? ''
      // Stash-then-switch (the dirty-work-tree path the dialog offers): the
      // checkout alone would be refused, so the changes go to the stash first.
      // `-u` folds untracked files in as well — git also refuses a switch when
      // an untracked file is one the target branch tracks.
      return { argv: msg === '' ? [checkout] : [['git', 'stash', 'push', '-u', '-m', msg], checkout] }
    }
    case 'fetch':
      return { argv: [['git', 'fetch', '--all', '--prune']] }
    case 'pull-ff':
      // `--ff-only` can only advance HEAD to the upstream tip; it refuses (exit
      // non-zero, work tree untouched) when the branches diverged, so there is
      // no merge/rebase or conflict path to handle here.
      return { argv: [['git', 'pull', '--ff-only']] }
    case 'pull-merge':
      // Resolved in runPullMerge: the upstream ref must come from HEAD, the
      // fetch needs the configured remote, and the merge needs its own abort
      // path. A plan that reached here would be missing all three.
      return { error: 'invalid-name', message: 'pull-merge must be resolved before planning' }
    case 'push':
      // Plain `git push` (never --force): it pushes the current branch to its
      // configured upstream and the remote refuses a non-fast-forward, so a
      // diverged branch (never offered by the UI) can only be rejected, not
      // overwritten.
      return { argv: [['git', 'push']] }
    case 'publish':
      // Publish a branch with no upstream yet. The remote name comes from the
      // primary remote the client holds; revalidate it so a hostile local
      // remote name can never reach the option position. `HEAD` names the
      // current branch as the destination (no refspec to validate).
      if (!isSafeRemoteName(action.remote)) return { error: 'invalid-name', message: `unsafe remote name: ${action.remote}` }
      return { argv: [['git', 'push', '-u', action.remote, 'HEAD']] }
    case 'set-upstream':
      // Resolved in runAction: the branch must come from HEAD (never the wire),
      // and the probes need the repository. The remote name is still validated
      // here, so a hostile value cannot reach that later argv.
      if (!isSafeRemoteName(action.remote)) return { error: 'invalid-name', message: `unsafe remote name: ${action.remote}` }
      return { error: 'invalid-name', message: 'set-upstream must be resolved before planning' }
    case 'tag-create': {
      if (!isSafeBranchName(action.name)) return { error: 'invalid-name', message: `unsafe tag name: ${action.name}` }
      if (!isSafeRev(action.commit)) return { error: 'invalid-name', message: `unsafe commit: ${action.commit}` }
      const msg = action.message?.trim() ?? ''
      // A message makes it an annotated tag (-a -m); otherwise a lightweight tag.
      const flags = msg === '' ? [] : ['-a', '-m', msg]
      return { argv: [['git', 'tag', ...flags, '--end-of-options', action.name, action.commit]] }
    }
    case 'tag-delete':
      if (!isSafeBranchName(action.name)) return { error: 'invalid-name', message: `unsafe tag name: ${action.name}` }
      return { argv: [['git', 'tag', '-d', '--end-of-options', action.name]] }
    case 'branch-delete': {
      if (!isSafeBranchName(action.name)) return { error: 'invalid-name', message: `unsafe branch name: ${action.name}` }
      // `-d` is git's own safety check: it refuses a branch that is not fully
      // merged (and one still checked out anywhere). `-D` is only sent after the
      // client's second, explicit acknowledgement. Only refs/heads is touched:
      // no remote ref is ever deleted from the panel.
      return { argv: [['git', 'branch', action.force === true ? '-D' : '-d', '--end-of-options', action.name]] }
    }
    case 'branch-delete-remote':
      // Resolved in runAction against the configured remotes before planning:
      // the wire carries the full tracking ref, and guessing the remote/branch
      // boundary from a slash could name the wrong server.
      return { error: 'invalid-name', message: 'branch-delete-remote must be resolved before planning' }
    case 'branch-create': {
      if (!isSafeBranchName(action.name)) return { error: 'invalid-name', message: `unsafe branch name: ${action.name}` }
      if (!isSafeRev(action.start)) return { error: 'invalid-name', message: `unsafe start point: ${action.start}` }
      // No checkout — a pure ref write (issue #118). `--end-of-options` keeps a
      // name or start point that looks like an option out of the option
      // position; git branch accepts it (checkout/reset below do not).
      return { argv: [['git', 'branch', '--end-of-options', action.name, action.start]] }
    }
    case 'branch-merge': {
      if (!isSafeBranchName(action.name)) return { error: 'invalid-name', message: `unsafe branch name: ${action.name}` }
      // Plain merge: fast-forward when possible, a merge commit otherwise —
      // never --no-ff / --rebase / --force. A conflict leaves MERGE_HEAD, so
      // runAction aborts it (see sequenceAbortPlan) instead of parking the
      // shared worktree mid-merge.
      return { argv: [['git', 'merge', '--end-of-options', action.name]] }
    }
    case 'cherry-pick': {
      if (!isSafeRev(action.commit)) return { error: 'invalid-name', message: `unsafe commit: ${action.commit}` }
      // Single commit only (the panel never sends a range). Conflicts and an
      // empty result both leave sequencer state behind; runAction aborts them.
      return { argv: [['git', 'cherry-pick', '--end-of-options', action.commit]] }
    }
    case 'stash-push': {
      const msg = action.message?.trim() ?? ''
      // `-m` makes the stash subject the user's text; without it git auto-labels
      // ("WIP on <branch>: …"). `--` would need a pathspec, so it is omitted.
      return { argv: [msg === '' ? ['git', 'stash', 'push'] : ['git', 'stash', 'push', '-m', msg]] }
    }
    case 'stash-apply':
    case 'stash-pop':
    case 'stash-drop': {
      if (!Number.isSafeInteger(action.index) || action.index < 0) {
        return { error: 'invalid-index', message: `invalid stash index: ${action.index}` }
      }
      const verb = action.kind === 'stash-apply' ? 'apply' : action.kind === 'stash-pop' ? 'pop' : 'drop'
      // `stash@{N}` is built from a validated non-negative integer, never raw
      // user text; `--end-of-options` keeps it an operand belt-and-suspenders.
      return { argv: [['git', 'stash', verb, '--end-of-options', `stash@{${action.index}}`]] }
    }
    case 'revert': {
      if (!isSafeRev(action.commit)) return { error: 'invalid-name', message: `unsafe commit: ${action.commit}` }
      // `--no-edit` keeps git from opening an editor (there is no TTY); the
      // default reverse-commit message is used.
      return { argv: [['git', 'revert', '--no-edit', '--end-of-options', action.commit]] }
    }
    case 'reset': {
      if (!isSafeRev(action.commit)) return { error: 'invalid-name', message: `unsafe commit: ${action.commit}` }
      if (action.mode !== 'soft' && action.mode !== 'mixed' && action.mode !== 'hard') {
        return { error: 'invalid-name', message: `invalid reset mode: ${String(action.mode)}` }
      }
      // No `--end-of-options` either: older git rejects it outright ("must
      // come before non-option arguments"); isSafeRev rules out a leading dash.
      // The trailing `--` keeps a commit-ish that is also a path (a file named
      // like a branch) out of the pathspec position.
      return { argv: [['git', 'reset', `--${action.mode}`, action.commit, '--']] }
    }
    case 'commit-checkout': {
      if (!isSafeRev(action.commit)) return { error: 'invalid-name', message: `unsafe commit: ${action.commit}` }
      // Same shape as `branch-checkout`: no `--end-of-options` (older git
      // rejects it on checkout), and the trailing `--` keeps a commit-ish that
      // is also a path out of the pathspec position. With no path after it, `--`
      // still means "check out this revision": HEAD detaches at the commit and
      // the work tree follows it, so uncommitted changes it would overwrite make
      // git refuse the whole checkout.
      return { argv: [['git', 'checkout', action.commit, '--']] }
    }
    case 'flow-start':
    case 'flow-finish':
    case 'flow-integrate':
      // Unreachable from runAction: the run endpoint routes these to the flow
      // runner before planning (flow-ops.ts), which needs probes and a
      // multi-step sequence rather than one argv.
      return { error: 'git-error', message: 'flow actions are executed by the flow runner' }
  }
}

/** True when a command outcome failed specifically on the git index lock. */
function isIndexBusy(outcome: Awaited<ReturnType<typeof runCommand>>): boolean {
  if (!('run' in outcome) || outcome.run.exitCode === 0) return false
  return /index\.lock|Unable to create.*index|another git process/i.test(outcome.run.stderr + outcome.run.stdout)
}

/**
 * The wire error for a probe that never ran (spawn failure) or never finished
 * (timeout / cancellation); null when it produced a result. A probe that broke
 * says nothing about the repository state it was meant to observe, so folding
 * it into the action's own verdict would report a condition that was never
 * established — e.g. a timed-out `symbolic-ref` is not a detached HEAD.
 */
function probeFailure(outcome: Awaited<ReturnType<typeof runCommand>>): Extract<GitActionResult, { ok: false }> | null {
  if ('failure' in outcome) {
    return { ok: false, error: { code: 'git-unavailable', message: outcome.failure instanceof Error ? outcome.failure.message : String(outcome.failure) } }
  }
  if (outcome.run.cancelled) return { ok: false, error: { code: 'cancelled' } }
  if (outcome.run.timedOut) return { ok: false, error: { code: 'timeout' } }
  return null
}

/** Strip an embedded credential (`scheme://user:token@host`) from a git
 * message so a token in a remote URL never reaches the RPC reply or logs. */
export function scrubCredentials(text: string): string {
  return text.replace(/([a-z][a-z0-9+.-]*:\/\/)[^/@\s]*@/gi, '$1')
}

/**
 * Classify a non-zero git exit into a wire error code + message. Order is
 * semantic and must not be reshuffled:
 *  - conflict first — a stash apply/pop conflict prints both "CONFLICT …" and
 *    "no changes added to commit", so it must win over the nothing-to-commit
 *    rule below (git keeps the stash entry on conflict → recoverable).
 *  - index.lock busy (another process holds the lock).
 *  - nothing-to-commit / no changes added (a real commit no-op).
 *  - not-found (missing ref / tag / stash, or a checkout target that resolves
 *    to neither a ref nor a path).
 *  - branch-in-use (the target branch is checked out in another worktree).
 *  - branch-checked-out / branch-unmerged (a branch delete git refused: the
 *    branch is still somebody's HEAD, or it holds unmerged commits).
 *  - branch-exists (`git branch` refused a name that is already taken).
 *  - local-changes-block (a dirty-worktree refusal; neutral wording covers both
 *    `git checkout` and `git stash apply`).
 *  - revert-merge (reverting a merge commit without a mainline parent — git
 *    refuses before touching the work tree, so it is a plain refusal).
 *  - git-error fallback (surface the repo's own stderr).
 */
export function classifyActionFailure(stdout: string, stderr: string, exitCode: number): { code: GitErrorCode; message: string } {
  const combined = stderr + stdout
  // Network git errors echo the remote URL verbatim, which may embed a
  // credential (`https://user:token@host/…`); strip it so a token never lands
  // in the RPC message or logs (matches remote.ts stripping it from hrefs).
  const err = scrubCredentials(stderr.trim())
  // Anchored at line start: a staged file may be named `CONFLICT-notes.md`, and
  // the "nothing added to commit" output lists it as ` M CONFLICT-notes.md`.
  if (/^(?:CONFLICT \(|CONFLICT:|Merge conflict|needs merge|error: could not restore untracked)/m.test(combined)) {
    return { code: 'conflict', message: err || 'merge conflict' }
  }
  if (/index\.lock|Unable to create.*index|another git process/i.test(combined)) {
    return { code: 'index-busy', message: err }
  }
  if (/nothing to commit|nothing added to commit|no changes added/i.test(combined)) {
    return { code: 'nothing-to-commit', message: err }
  }
  if (/No such ref|not a valid reference|not a valid object name|not something we can merge|invalid reference|is not a stash|no tag|tag .* not found|branch '[^']*' not found|remote ref does not exist|unknown revision|bad revision|Could not parse object|ambiguous argument|did not match any file\(s\) known to git/i.test(combined)) {
    return { code: 'not-found', message: err || 'not found' }
  }
  // The branch exists but is checked out in another worktree of this repo:
  // git refuses the switch (detaching it there would corrupt that worktree).
  if (/is already used by worktree|already checked out at/i.test(combined)) {
    return { code: 'branch-in-use', message: err || 'branch is checked out in another worktree' }
  }
  // A branch delete git refused because the branch is still a HEAD somewhere:
  // this worktree ("used by worktree at …") or a linked one ("checked out at …",
  // older wording). Deleting it would leave that checkout without its branch.
  if (/cannot delete branch .* (?:used by .*worktree|checked out at)/i.test(combined)) {
    return { code: 'branch-checked-out', message: err || 'branch is checked out' }
  }
  // Safe delete (`-d`) refused: the branch has commits not merged into its
  // upstream (or HEAD). Nothing was deleted, so the client may ask again with an
  // explicit force acknowledgement.
  if (/is not fully merged/i.test(combined)) {
    return { code: 'branch-unmerged', message: err || 'branch is not fully merged' }
  }
  // `git branch` refused a taken name (issue #118): nothing was created, and
  // the message names the exact name so the dialog can ask for another one.
  if (/a branch named .* already exists/i.test(combined)) {
    return { code: 'branch-exists', message: err || 'branch already exists' }
  }
  // A network git command (fetch/pull/push) that failed because no usable
  // credentials were available. GIT_TERMINAL_PROMPT=0 turns an interactive
  // prompt into "terminal prompts disabled", so these fail fast rather than hang.
  // Only signals that name authentication itself: ssh prints "Could not read
  // from remote repository" for every transport failure (unknown host,
  // connection refused), so that line stays out and falls through to git-error.
  if (/Authentication failed|could not read (Username|Password)|terminal prompts disabled|Permission denied \(publickey\)|Host key verification failed/i.test(combined)) {
    return { code: 'auth-failed', message: err || 'authentication failed' }
  }
  // `git push` rejected by the remote: the remote advanced, so the push is not a
  // fast-forward. Checked before the pull `not-ff` branch because the wording
  // overlaps ("non-fast-forward").
  if (/\[rejected\]|Updates were rejected|failed to push some refs|fetch first|tip of your current branch is behind/i.test(combined)) {
    return { code: 'push-rejected', message: err || 'push rejected (remote has new commits; fetch first)' }
  }
  // `git pull --ff-only` on diverged branches: a clean refusal that leaves the
  // work tree untouched, distinct from a dirty-tree block below.
  if (/Not possible to fast-forward|cannot fast-forward|not a fast-forward|Need to specify how to reconcile divergent branches/i.test(combined)) {
    return { code: 'not-ff', message: err || 'cannot fast-forward (branches diverged)' }
  }
  if (/would be overwritten by (checkout|merge)|local changes|overwritten by merge|Your local changes/i.test(stderr)) {
    return { code: 'local-changes-block', message: err }
  }
  // Reverting a merge commit without a mainline parent: git refuses before
  // creating REVERT_HEAD, so this is a plain refusal (no stuck state) that the
  // panel surfaces with a clear message instead of the raw hint.
  if (/is a merge but no -m|mainline parent/i.test(combined)) {
    return { code: 'revert-merge', message: err || 'cannot revert a merge commit from the panel' }
  }
  return { code: 'git-error', message: err || `git exited ${exitCode}` }
}

/**
 * Commit a selection that mixes both sides of the changes list. The
 * `indexOnly` paths are committed from the index exactly as staged — re-staging
 * them would fold unstaged hunks into the commit and undo a partial
 * `git add -p`; the remaining paths are staged from the work tree first, as a
 * whole-file pick means. The commit is assembled in a temporary index seeded
 * from HEAD, so paths staged outside the selection stay staged and never enter
 * this commit.
 */
async function runIndexOnlyCommit(
  deps: SnapshotDeps,
  root: string,
  action: Extract<GitAction, { kind: 'commit' }>,
  unborn: boolean,
  signal: AbortSignal | undefined,
): Promise<{ ok: true; output: string } | { ok: false; error: Extract<GitActionResult, { ok: false }>['error'] }> {
  const indexOnly = [...new Set(action.indexOnly ?? [])]
  const paths = action.paths ?? []
  for (const path of [...paths, ...indexOnly]) {
    if (!isSafePath(path)) return { ok: false, error: { code: 'invalid-path', message: `unsafe path: ${path}` } }
  }
  if (indexOnly.length === 0) return { ok: false, error: { code: 'invalid-path', message: 'indexOnly needs at least one path' } }
  const indexOnlySet = new Set(indexOnly)
  const worktreePaths = paths.filter((path) => !indexOnlySet.has(path))
  const indexFile = join(tmpdir(), `dsh-git-panel-${randomUUID()}.index`)
  const env = { GIT_INDEX_FILE: indexFile }

  /** Run one step of the commit and turn a broken run into a wire error. */
  const step = async (
    argv: readonly string[],
    extra?: { readonly data?: string; readonly env?: boolean },
  ): Promise<{ stdout: string } | { error: Extract<GitActionResult, { ok: false }>['error'] }> => {
    const outcome = await runCommand(
      deps.run, argv, root, 'commit-index', signal,
      extra?.data === undefined && extra?.env !== true ? undefined : { ...(extra?.data !== undefined ? { data: extra.data } : {}), ...(extra?.env === true ? { env } : {}) },
    )
    if ('failure' in outcome) {
      return { error: { code: 'git-unavailable', message: outcome.failure instanceof Error ? outcome.failure.message : String(outcome.failure) } }
    }
    if (outcome.run.cancelled) return { error: { code: 'cancelled' } }
    if (outcome.run.timedOut) return { error: { code: 'timeout' } }
    if (outcome.run.exitCode !== 0) {
      const failure = classifyActionFailure(outcome.run.stdout, outcome.run.stderr, outcome.run.exitCode ?? -1)
      return { error: { code: failure.code, message: failure.message } }
    }
    return { stdout: outcome.run.stdout }
  }

  try {
    const base = await step(['git', 'read-tree', unborn ? '--empty' : 'HEAD'], { env: true })
    if ('error' in base) return { ok: false, error: base.error }

    // Whole-file side: stage from the work tree into the real index (the
    // long-standing behaviour), then mirror those entries into the temp one.
    if (worktreePaths.length > 0) {
      const added = await step(['git', 'add', '--', ...worktreePaths])
      if ('error' in added) return { ok: false, error: added.error }
    }
    const copy = [...worktreePaths, ...indexOnly]
    const listed = await step(['git', 'ls-files', '-s', '-z', '--', ...copy])
    if ('error' in listed) return { ok: false, error: listed.error }
    const lines = listed.stdout.split('\0').filter((record) => record !== '')
    if (lines.length > 0) {
      const applied = await step(['git', 'update-index', '-z', '--index-info'], { data: listed.stdout, env: true })
      if ('error' in applied) return { ok: false, error: applied.error }
    }
    const present = new Set(lines.map((record) => record.slice(record.indexOf('\t') + 1)))
    // A selected path with no entry is a staged deletion — for a worktree-side
    // pick too: `git add` recorded the deletion, so `ls-files` no longer lists
    // it. The temp index was seeded from HEAD, so every such entry has to be
    // dropped explicitly or the commit would keep the deleted file.
    const missing = [...new Set([...worktreePaths, ...indexOnly])].filter((path) => !present.has(path))
    if (missing.length > 0) {
      const removed = await step(['git', 'update-index', '--force-remove', '--', ...missing], { env: true })
      if ('error' in removed) return { ok: false, error: removed.error }
    }
    // A staged rename carries its deletion on the old path, which the path list
    // may not mention (the list is keyed by the new path): drop it too, or the
    // commit would keep both sides.
    const renamed = await step(['git', 'diff', '--cached', '--name-status', '-z', '-M', '--', ...indexOnly])
    if ('error' in renamed) return { ok: false, error: renamed.error }
    const fields = renamed.stdout.split('\0').filter((field) => field !== '')
    const oldPaths: string[] = []
    for (let i = 0; i < fields.length; i += 1) {
      if (!fields[i]!.startsWith('R')) continue
      const from = fields[i + 1]
      i += 2
      if (from !== undefined && !indexOnlySet.has(from)) oldPaths.push(from)
    }
    if (oldPaths.length > 0) {
      const dropped = await step(['git', 'update-index', '--force-remove', '--', ...oldPaths], { env: true })
      if ('error' in dropped) return { ok: false, error: dropped.error }
    }

    const message = action.message.trim()
    const amendFlag = action.amend === true ? ['--amend'] : []
    // amend + empty message: reuse the previous message (no TTY for an editor).
    const msgArgs = message === '' ? ['--no-edit'] : ['-m', message]
    const committed = await step(['git', 'commit', ...amendFlag, ...msgArgs], { env: true })
    if ('error' in committed) return { ok: false, error: committed.error }
    return { ok: true, output: committed.stdout.trim() }
  } finally {
    await deps.fs.remove(indexFile).catch(() => undefined)
  }
}

/**
 * The abort plan for a write that parks a sequencer / merge state behind when
 * it fails: revert, merge and cherry-pick. The panel offers no conflict
 * resolution — and the state would also block the shared-worktree dsh AI's own
 * commits — so a conflict is aborted immediately: `--abort` restores the pre-op
 * state (unrelated dirty changes are preserved). Returns the argv, the probe
 * label and the codes for "aborted cleanly" / "still stuck"; null for any other
 * action or failure, where nothing was left behind.
 *
 * A cherry-pick whose patch is empty also parks state (CHERRY_PICK_HEAD over a
 * clean tree); it reports its own code once the abort cleared it.
 */
function sequenceAbortPlan(
  action: GitAction,
  failure: GitErrorCode,
): { readonly argv: readonly string[]; readonly probe: string; readonly code: GitErrorCode; readonly stuck: GitErrorCode } | null {
  const plan = (argv: readonly string[], probe: string, code: GitErrorCode, stuck: GitErrorCode) => ({ argv, probe, code, stuck })
  if (action.kind === 'revert' && failure === 'conflict') return plan(['git', 'revert', '--abort'], 'revert-abort', 'revert-conflict', 'revert-stuck')
  if (action.kind === 'branch-merge' && failure === 'conflict') return plan(['git', 'merge', '--abort'], 'merge-abort', 'merge-conflict', 'merge-stuck')
  if (action.kind === 'cherry-pick' && failure === 'conflict') return plan(['git', 'cherry-pick', '--abort'], 'pick-abort', 'pick-conflict', 'pick-stuck')
  if (action.kind === 'cherry-pick' && failure === 'nothing-to-commit') return plan(['git', 'cherry-pick', '--abort'], 'pick-abort', 'pick-empty', 'pick-stuck')
  return null
}

/**
 * True when the repository already sits in an operation that owns the index and
 * the work tree (merge / rebase / cherry-pick / revert). `pull-merge` refuses
 * rather than stacking a second one; the same probe is why any `MERGE_HEAD`
 * seen after its own merge belongs to that merge, so aborting it is safe.
 */
async function repositoryBusy(
  deps: SnapshotDeps,
  root: string,
): Promise<{ readonly busy: boolean } | { readonly error: Extract<GitActionResult, { ok: false }>['error'] }> {
  for (const marker of ['MERGE_HEAD', 'CHERRY_PICK_HEAD', 'REVERT_HEAD']) {
    const probe = await runCommand(deps.run, ['git', 'rev-parse', '--quiet', '--verify', marker], root, 'merge-busy', deps.signal)
    const broke = probeFailure(probe)
    if (broke !== null) return { error: broke.error }
    if ('run' in probe && probe.run.exitCode === 0) return { busy: true }
  }
  // A rebase keeps no ref that `rev-parse --verify` can address in every phase,
  // so the sequencer directories are the reliable signal.
  for (const dir of ['rebase-merge', 'rebase-apply']) {
    const pathProbe = await runCommand(deps.run, ['git', 'rev-parse', '--git-path', dir], root, 'merge-busy', deps.signal)
    const broke = probeFailure(pathProbe)
    if (broke !== null) return { error: broke.error }
    if (!('run' in pathProbe) || pathProbe.run.exitCode !== 0) continue
    const reported = pathProbe.run.stdout.trim()
    if (reported === '') continue
    const absolute = isAbsolute(reported) ? reported : join(root, reported)
    const present = await deps.fs.stat(absolute).then(() => true).catch(() => false)
    if (present) return { busy: true }
  }
  return { busy: false }
}

/**
 * True only when the on-disk merge is the one this action started: HEAD has not
 * moved since the pre-merge probe, and MERGE_HEAD is exactly the upstream tip
 * this action merged. A merge that appeared during the network fetch — from the
 * shared-worktree dsh agent or a second panel — fails the check and is left
 * untouched.
 */
export function mergeIsOurs(
  headBefore: string, upstreamTip: string, headNow: string, mergeHead: string,
): boolean {
  return headBefore !== '' && upstreamTip !== '' && headBefore === headNow && mergeHead === upstreamTip
}

/** What the on-disk merge state is after a failed merge: none, someone else's,
 * ours and cleaned up, or ours and the cleanup itself failed. */
export type MergeCleanup = 'absent' | 'foreign' | 'aborted' | 'stuck'

/**
 * Abort a merge only when `mergeIsOurs` proves it is the one this action
 * started. A foreign state is reported, never aborted: its conflict resolution
 * may be somebody's in-flight work.
 */
async function cleanupOwnMerge(
  deps: SnapshotDeps,
  root: string,
  headBefore: string,
  upstreamTip: string,
  signal: AbortSignal | undefined,
): Promise<MergeCleanup> {
  const [headProbe, mergeHeadProbe] = await Promise.all([
    runCommand(deps.run, ['git', 'rev-parse', '--verify', 'HEAD'], root, 'merge-cleanup-head', signal),
    runCommand(deps.run, ['git', 'rev-parse', '--quiet', '--verify', 'MERGE_HEAD'], root, 'merge-cleanup-head', signal),
  ])
  // A probe that never produced a result establishes nothing: do not abort.
  if ('failure' in mergeHeadProbe || mergeHeadProbe.run.cancelled || mergeHeadProbe.run.timedOut) return 'foreign'
  if (mergeHeadProbe.run.exitCode !== 0) return 'absent'
  const headNow = 'run' in headProbe && headProbe.run.exitCode === 0 ? headProbe.run.stdout.trim() : ''
  if (!mergeIsOurs(headBefore, upstreamTip, headNow, mergeHeadProbe.run.stdout.trim())) return 'foreign'
  let abort = await runCommand(deps.run, ['git', 'merge', '--abort'], root, 'merge-abort', signal)
  if (isIndexBusy(abort)) {
    await new Promise((resolve) => setTimeout(resolve, 150))
    abort = await runCommand(deps.run, ['git', 'merge', '--abort'], root, 'merge-abort-retry', signal)
  }
  return 'run' in abort && abort.run.exitCode === 0 ? 'aborted' : 'stuck'
}

/**
 * `pull-merge`: fetch the current branch's upstream and merge it into HEAD.
 * This is the additive half of a diverged sync — it never rewrites a commit and
 * never touches the remote. The client follows a successful reply with the
 * ordinary `push`, which is a fast-forward because the merge brought the
 * upstream tip into HEAD. Conflicts are aborted back to the pre-merge state
 * (the panel has no conflict UI); a foreign in-progress operation is refused
 * before anything runs.
 */
async function runPullMerge(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  request: GitActionRequest,
  root: string,
  headProbe: Awaited<ReturnType<typeof runCommand>>,
  unborn: boolean,
): Promise<GitActionResult> {
  const fail = (code: GitErrorCode, message: string): GitActionResult => ({ ok: false, error: { code, message } })

  const headBroke = probeFailure(headProbe)
  if (headBroke !== null) return headBroke
  if (unborn) return fail('no-branch', 'no commits to merge')
  // The ownership witness for a later cleanup: a merge is ours only while HEAD
  // still points at the commit this action saw before it started.
  const headBefore = 'run' in headProbe && headProbe.run.exitCode === 0 ? headProbe.run.stdout.trim() : ''

  const branchProbe = await runCommand(deps.run, ['git', 'symbolic-ref', '--quiet', '--short', 'HEAD'], root, 'merge-branch', deps.signal)
  const branchBroke = probeFailure(branchProbe)
  if (branchBroke !== null) return branchBroke
  const branch = 'run' in branchProbe && branchProbe.run.exitCode === 0 ? branchProbe.run.stdout.trim() : ''
  if (branch === '') return fail('no-branch', 'detached HEAD: no branch to sync')
  if (!isSafeBranchName(branch)) return fail('invalid-name', 'HEAD names an unsafe branch')

  const busy = await repositoryBusy(deps, root)
  if ('error' in busy) return { ok: false, error: busy.error }
  if (busy.busy) return fail('operation-in-progress', 'a merge, rebase or cherry-pick is already in progress')

  // The upstream ref is resolved here, never taken from the wire. `@{upstream}`
  // is a fixed literal (ADR-0007); only the resolved full ref reaches argv.
  const upstreamProbe = await runCommand(deps.run, ['git', 'rev-parse', '--symbolic-full-name', '@{upstream}'], root, 'merge-upstream', deps.signal)
  const upstreamBroke = probeFailure(upstreamProbe)
  if (upstreamBroke !== null) return upstreamBroke
  if (!('run' in upstreamProbe) || upstreamProbe.run.exitCode !== 0) return fail('no-upstream', 'the current branch has no upstream')
  const upstreamRef = upstreamProbe.run.stdout.trim()
  if (!isSafeRev(upstreamRef)) return fail('invalid-name', 'the upstream ref is unsafe to pass to git')
  if (!upstreamRef.startsWith('refs/remotes/') && !upstreamRef.startsWith('refs/heads/')) {
    return fail('no-upstream', 'the upstream is not a branch ref')
  }

  // Fetch only the remote that owns the upstream. `git pull` is deliberately
  // avoided: its behaviour depends on pull.rebase / pull.ff and it would hide
  // which half failed. A local upstream (branch.<name>.remote = .) needs none.
  if (upstreamRef.startsWith('refs/remotes/')) {
    const remotesProbe = await runCommand(deps.run, ['git', 'remote'], root, 'merge-remotes', deps.signal)
    const remotesBroke = probeFailure(remotesProbe)
    if (remotesBroke !== null) return remotesBroke
    if (!('run' in remotesProbe) || remotesProbe.run.exitCode !== 0) {
      const detail = 'run' in remotesProbe ? scrubCredentials(remotesProbe.run.stderr.trim()) : ''
      return fail('git-error', detail || 'git remote failed')
    }
    const remotes = remotesProbe.run.stdout.split('\n').map((line: string) => line.trim()).filter((line: string) => line !== '')
    const target = splitRemoteTrackingRef(upstreamRef, remotes)
    if (target === null) return fail('no-upstream', 'the upstream ref names no configured remote')

    const fetched = await runCommand(deps.run, ['git', 'fetch', '--prune', target.remote], root, 'merge-fetch', deps.signal)
    if ('failure' in fetched) {
      return fail('git-unavailable', fetched.failure instanceof Error ? fetched.failure.message : String(fetched.failure))
    }
    if (fetched.run.cancelled) return fail('cancelled', 'fetch cancelled')
    if (fetched.run.timedOut) return fail('timeout', 'fetch timed out')
    if (fetched.run.exitCode !== 0) {
      const failure = classifyActionFailure(fetched.run.stdout, fetched.run.stderr, fetched.run.exitCode ?? -1)
      return { ok: false, error: failure }
    }
  }

  // The ref must still resolve after the fetch; a remote branch deleted
  // between the snapshot and now leaves nothing to merge. The resolved hash is
  // also the ownership witness for a later cleanup.
  const tipProbe = await runCommand(deps.run, ['git', 'rev-parse', '--quiet', '--verify', upstreamRef], root, 'merge-upstream-verify', deps.signal)
  const tipBroke = probeFailure(tipProbe)
  if (tipBroke !== null) return tipBroke
  if (!('run' in tipProbe) || tipProbe.run.exitCode !== 0) return fail('upstream-missing', 'the upstream branch no longer exists')
  const upstreamTip = tipProbe.run.stdout.trim()
  if (!/^[0-9a-f]{40,64}$/i.test(upstreamTip)) return fail('git-error', 'cannot resolve the upstream tip')

  // Re-check after the network fetch: a merge or rebase started while this
  // action waited is not ours to finish or abort. The window is now only the
  // few local probes between here and the merge.
  const busyAfterFetch = await repositoryBusy(deps, root)
  if ('error' in busyAfterFetch) return { ok: false, error: busyAfterFetch.error }
  if (busyAfterFetch.busy) return fail('operation-in-progress', 'another merge, rebase or cherry-pick started while fetching')

  // Behind is all that decides whether a merge is needed. Ahead is not
  // required: a behind-only branch merges as a fast-forward, which is still a
  // safe additive step (the client only offers sync when both counts are > 0).
  const counts = await runCommand(deps.run, ['git', 'rev-list', '--count', `HEAD..${upstreamTip}`], root, 'merge-counts', deps.signal)
  const countsBroke = probeFailure(counts)
  if (countsBroke !== null) return countsBroke
  if (!('run' in counts) || counts.run.exitCode !== 0) return fail('git-error', 'cannot count the upstream commits')
  const behind = Number(counts.run.stdout.trim())
  if (!Number.isSafeInteger(behind) || behind < 0) return fail('git-error', 'cannot count the upstream commits')

  let output = ''
  if (behind > 0) {
    const merged = await runCommand(
      deps.run,
      ['git', 'merge', '--ff', '--no-edit', '--no-autostash', '--end-of-options', upstreamRef],
      root, 'pull-merge', deps.signal,
    )
    if ('failure' in merged) {
      return fail('git-unavailable', merged.failure instanceof Error ? merged.failure.message : String(merged.failure))
    }
    if (merged.run.cancelled || merged.run.timedOut) {
      // The killed git may still have written MERGE_HEAD. Clean up only a merge
      // this action owns, and do it without the action's signal: that signal is
      // already aborted, so reusing it would cancel the cleanup too.
      const cleanup = await cleanupOwnMerge(deps, root, headBefore, upstreamTip, undefined)
      if (cleanup === 'stuck') return fail('merge-stuck', 'merge cleanup failed after cancellation')
      return merged.run.cancelled
        ? fail('cancelled', 'merge cancelled')
        : fail('timeout', 'merge timed out')
    }
    output = merged.run.stdout || merged.run.stderr
    if (merged.run.exitCode !== 0) {
      const failure = classifyActionFailure(merged.run.stdout, merged.run.stderr, merged.run.exitCode ?? -1)
      // Another process owns the index: touching the merge state now could
      // abort its operation, so report the contention unchanged.
      if (failure.code === 'index-busy') return { ok: false, error: failure }
      const cleanup = await cleanupOwnMerge(deps, root, headBefore, upstreamTip, undefined)
      if (cleanup === 'aborted') {
        // A real conflict keeps its dedicated code so the client shows the
        // "aborted, work tree restored" copy; any other failure keeps its own.
        return { ok: false, error: { code: failure.code === 'conflict' ? 'merge-conflict' : failure.code, message: failure.message } }
      }
      if (cleanup === 'stuck') return { ok: false, error: { code: 'merge-stuck', message: failure.message } }
      if (cleanup === 'foreign') return fail('operation-in-progress', 'another merge appeared during the sync; nothing was aborted')
      return { ok: false, error: failure }
    }
  }

  const snapshot = await snapshotForSession(deps, config, request.sessionId, { repo: request.repo })
  if (!snapshot.ok) return { ok: false, error: { code: 'git-error', message: 'snapshot after action failed' } }
  return { ok: true, snapshot: snapshot.value, output: output.trim() }
}

/**
 * Attach the current branch to its same-named remote-tracking branch without
 * touching the remote. Offered when that branch already exists at HEAD on at
 * least one candidate remote, so `publish` would push nothing and only the
 * local tracking config is missing.
 *
 * The probes run here rather than in `planAction` because the branch must be
 * resolved from HEAD, never taken from the request. A tracking config that
 * appeared after the snapshot refuses the write: replacing a deliberate
 * upstream with the chosen remote would silently lose that choice.
 */
async function runSetUpstream(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  request: GitActionRequest,
  action: Extract<GitAction, { kind: 'set-upstream' }>,
  root: string,
  headProbe: Awaited<ReturnType<typeof runCommand>>,
  unborn: boolean,
): Promise<GitActionResult> {
  if (!isSafeRemoteName(action.remote)) {
    return { ok: false, error: { code: 'invalid-name', message: `unsafe remote name: ${action.remote}` } }
  }
  const headBroke = probeFailure(headProbe)
  if (headBroke !== null) return headBroke
  if (unborn) return { ok: false, error: { code: 'no-branch', message: 'no commits to set an upstream on' } }

  const branchProbe = await runCommand(deps.run, ['git', 'symbolic-ref', '--quiet', '--short', 'HEAD'], root, 'set-upstream-branch', deps.signal)
  const branchBroke = probeFailure(branchProbe)
  if (branchBroke !== null) return branchBroke
  const branch = 'run' in branchProbe && branchProbe.run.exitCode === 0 ? branchProbe.run.stdout.trim() : ''
  if (branch === '') return { ok: false, error: { code: 'no-branch', message: 'detached HEAD: no branch to attach' } }
  if (!isSafeBranchName(branch)) return { ok: false, error: { code: 'invalid-name', message: 'HEAD names an unsafe branch' } }

  // Non-zero means `@{upstream}` does not resolve (the expected "no upstream");
  // exit 0 means another actor configured one after the snapshot.
  const upstreamProbe = await runCommand(deps.run, ['git', 'rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{upstream}'], root, 'set-upstream-existing', deps.signal)
  const upstreamBroke = probeFailure(upstreamProbe)
  if (upstreamBroke !== null) return upstreamBroke
  if ('run' in upstreamProbe && upstreamProbe.run.exitCode === 0) {
    return { ok: false, error: { code: 'has-upstream', message: 'branch already has an upstream' } }
  }

  // The wire carries a remote *name*; a stale or hostile request must not name
  // an arbitrary tracking ref. `git branch --set-upstream-to` would refuse an
  // unconfigured remote anyway, but checking here reports a localized condition
  // and never reaches the config write.
  const remotesProbe = await runCommand(deps.run, ['git', 'remote'], root, 'set-upstream-remotes', deps.signal)
  const remotesBroke = probeFailure(remotesProbe)
  if (remotesBroke !== null) return remotesBroke
  if (!('run' in remotesProbe) || remotesProbe.run.exitCode !== 0) {
    return { ok: false, error: { code: 'git-error', message: 'git remote failed' } }
  }
  const remotes = remotesProbe.run.stdout.split('\n').map((line) => line.trim()).filter((line) => line !== '')
  if (!remotes.includes(action.remote)) {
    return { ok: false, error: { code: 'upstream-missing', message: 'the remote is not configured' } }
  }

  const ref = `refs/remotes/${action.remote}/${branch}`
  const existsProbe = await runCommand(deps.run, ['git', 'rev-parse', '--verify', '--quiet', '--end-of-options', ref], root, 'set-upstream-ref', deps.signal)
  const existsBroke = probeFailure(existsProbe)
  if (existsBroke !== null) return existsBroke
  if (!('run' in existsProbe) || existsProbe.run.exitCode !== 0) {
    return { ok: false, error: { code: 'upstream-missing', message: 'the same-named remote branch no longer exists' } }
  }

  const res = await runCommand(deps.run, ['git', 'branch', `--set-upstream-to=${ref}`, '--end-of-options', branch], root, 'set-upstream', deps.signal)
  if ('failure' in res) {
    return { ok: false, error: { code: 'git-unavailable', message: res.failure instanceof Error ? res.failure.message : String(res.failure) } }
  }
  if (res.run.cancelled) return { ok: false, error: { code: 'cancelled' } }
  if (res.run.timedOut) return { ok: false, error: { code: 'timeout' } }
  if (res.run.exitCode !== 0) {
    return { ok: false, error: classifyActionFailure(res.run.stdout, res.run.stderr, res.run.exitCode ?? -1) }
  }

  const snapshot = await snapshotForSession(deps, config, request.sessionId, { repo: request.repo })
  if (!snapshot.ok) return { ok: false, error: { code: 'git-error', message: 'snapshot after action failed' } }
  return { ok: true, snapshot: snapshot.value, output: res.run.stdout.trim() }
}

/** Execute a management action, returning the fresh snapshot on success. */
export async function runAction(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  request: GitActionRequest,
): Promise<GitActionResult> {
  const workspace = await resolveWorkspace(deps, request.sessionId, request.repo, config.codeWorkspace)
  if (!workspace.ok) return { ok: false, error: mapWorkspaceFailure(workspace.failure) }
  const root = workspace.root

  // Detect unborn for correct unstage semantics.
  const headProbe = await runCommand(deps.run, ['git', 'rev-parse', '--verify', 'HEAD'], root, 'head-probe', deps.signal)
  const unborn = !('run' in headProbe) || headProbe.run.exitCode !== 0

  // Publish needs a branch for git to derive the remote destination from. Bare
  // `HEAD` is not enough on a detached HEAD or in an unborn repository: git
  // answers with a refspec hint instead of a name. Probe it here (the client's
  // snapshot may already be stale) and refuse with a clear code, so that hint
  // never surfaces as a raw git error. The command itself keeps the literal
  // `HEAD` (ADR-0007) — no ref reaches argv from the RPC. A probe that never
  // ran or never finished reports its own condition: it established nothing
  // about the branch, so it must not be read as a detached HEAD.
  if (request.action.kind === 'publish') {
    const headBroke = probeFailure(headProbe)
    if (headBroke !== null) return headBroke
    if (unborn) return { ok: false, error: { code: 'no-branch', message: 'no commits to publish' } }
    const branchProbe = await runCommand(deps.run, ['git', 'symbolic-ref', '--quiet', '--short', 'HEAD'], root, 'publish-branch', deps.signal)
    const branchBroke = probeFailure(branchProbe)
    if (branchBroke !== null) return branchBroke
    const branch = 'run' in branchProbe && branchProbe.run.exitCode === 0 ? branchProbe.run.stdout.trim() : ''
    if (branch === '') return { ok: false, error: { code: 'no-branch', message: 'detached HEAD: no branch to publish' } }
  }

  if (request.action.kind === 'set-upstream') {
    return runSetUpstream(deps, config, request, request.action, root, headProbe, unborn)
  }

  if (request.action.kind === 'pull-merge') {
    return runPullMerge(deps, config, request, root, headProbe, unborn)
  }

  // Stash is a stack addressed by position; under a shared worktree another
  // actor can push/pop/drop between the list query and this action, shifting
  // every index. Resolve `stash@{N}` to its SHA now and reject if it no longer
  // matches the entry the client acted on — otherwise a drop could destroy the
  // wrong (unrecoverable) stash. TOCTOU window is cut to this rev-parse.
  const act = request.action
  if (act.kind === 'stash-apply' || act.kind === 'stash-pop' || act.kind === 'stash-drop') {
    if (!Number.isSafeInteger(act.index) || act.index < 0) {
      return { ok: false, error: { code: 'invalid-index', message: `invalid stash index: ${act.index}` } }
    }
    const probe = await runCommand(deps.run, ['git', 'rev-parse', '--verify', '--quiet', '--end-of-options', `stash@{${act.index}}`], root, 'stash-verify', deps.signal)
    const sha = 'run' in probe && probe.run.exitCode === 0 ? probe.run.stdout.trim() : ''
    if (sha === '' || sha !== act.sha) {
      return { ok: false, error: { code: 'not-found', message: 'stash entry changed; refresh and retry' } }
    }
  }

  // `discard-all` carries no paths on the wire: the host re-runs status itself
  // and refuses when the stream was lossy (a clipped read cannot honestly back
  // an "every change" claim). The resolved working-tree paths then ride the
  // normal `discard` pipeline below, keeping the untracked deletion guards
  // (nested-repo refusal, per-path re-check) in one place.
  if (request.action.kind === 'discard-all') {
    const status = await runCommand(deps.run, ['git', 'status', '--porcelain=v1', '-z', '--untracked-files=all'], root, 'discard-all-status', deps.signal)
    if ('failure' in status) return { ok: false, error: { code: 'git-unavailable', message: status.failure instanceof Error ? status.failure.message : String(status.failure) } }
    if (status.run.cancelled) return { ok: false, error: { code: 'cancelled' } }
    if (status.run.timedOut) return { ok: false, error: { code: 'timeout' } }
    if (status.run.exitCode !== 0) {
      const failure = classifyActionFailure(status.run.stdout, status.run.stderr, status.run.exitCode ?? -1)
      return { ok: false, error: failure }
    }
    if (status.run.stdoutLossy) {
      return { ok: false, error: { code: 'status-lossy', message: 'status output was clipped; refusing to discard an incomplete change set' } }
    }
    const all = parseStatus(status.run.stdout)
    // Working-tree side only: staged-only entries are out of scope (same
    // contract as the picked batch), so `:w` picks are the whole target set.
    const paths = [...new Set(all.filter((c) => !c.staged).map((c) => c.path))].sort()
    if (paths.length === 0) {
      const snapshot = await snapshotForSession(deps, config, request.sessionId, { repo: request.repo })
      if (!snapshot.ok) return { ok: false, error: { code: 'git-error', message: 'snapshot after action failed' } }
      return { ok: true, snapshot: snapshot.value, output: '' }
    }
    request = { ...request, action: { kind: 'discard', paths } }
  }

  // Discard of an untracked path can't go through `git restore` (pathspec does
  // not match a known file); delete those from the work tree directly, with a
  // realpath-containment check, and let git restore only the tracked ones.
  if (request.action.kind === 'discard') {
    const removed = await discardUntracked(deps, config, root, request.sessionId, request.repo, request.action.paths)
    if (removed !== null) {
      if (!removed.ok) return removed.result
      if (removed.remainingTracked.length === 0) {
        const snapshot = await snapshotForSession(deps, config, request.sessionId, { repo: request.repo })
        if (!snapshot.ok) return { ok: false, error: { code: 'git-error', message: 'snapshot after action failed' } }
        return { ok: true, snapshot: snapshot.value, output: '' }
      }
      request = { ...request, action: { kind: 'discard', paths: removed.remainingTracked } }
    }
  }

  // A selection that mixes both sides commits from a temporary index (see
  // runIndexOnlyCommit); it is not a fixed argv sequence, so it runs before the
  // planner.
  if (request.action.kind === 'commit' && (request.action.indexOnly?.length ?? 0) > 0) {
    const committed = await runIndexOnlyCommit(deps, root, request.action, unborn, deps.signal)
    if (!committed.ok) return committed
    const snap = await snapshotForSession(deps, config, request.sessionId, { repo: request.repo })
    if (!snap.ok) return { ok: false, error: { code: 'git-error', message: 'snapshot after action failed' } }
    return { ok: true, snapshot: snap.value, output: committed.output }
  }

  // A remote branch delete names a tracking ref; resolve it to the configured
  // remote + branch here so `--delete` addresses refs/heads/<branch> on the
  // exact server. `git remote` is local and cheap; the longest configured name
  // wins (`foo/bar` over `foo`) because a remote name may contain a slash.
  let plan: PlanResult
  if (request.action.kind === 'branch-delete-remote') {
    const remotesRes = await runCommand(deps.run, ['git', 'remote'], root, 'remote-list', deps.signal)
    if ('failure' in remotesRes) {
      return { ok: false, error: { code: 'git-unavailable', message: remotesRes.failure instanceof Error ? remotesRes.failure.message : String(remotesRes.failure) } }
    }
    if (remotesRes.run.cancelled) return { ok: false, error: { code: 'cancelled' } }
    if (remotesRes.run.timedOut) return { ok: false, error: { code: 'timeout' } }
    if (remotesRes.run.exitCode !== 0) {
      return { ok: false, error: { code: 'git-error', message: scrubCredentials(remotesRes.run.stderr.trim()) || 'git remote failed' } }
    }
    const remotes = remotesRes.run.stdout.split('\n').map((line: string) => line.trim()).filter((line: string) => line !== '')
    const target = splitRemoteTrackingRef(request.action.ref, remotes)
    if (target === null) {
      return { ok: false, error: { code: 'not-found', message: 'the remote-tracking ref names no configured remote' } }
    }
    const tracking = await runCommand(deps.run, ['git', 'rev-parse', '--verify', '--quiet', '--end-of-options', request.action.ref], root, 'remote-branch-oid', deps.signal)
    if ('failure' in tracking) {
      return { ok: false, error: { code: 'git-unavailable', message: tracking.failure instanceof Error ? tracking.failure.message : String(tracking.failure) } }
    }
    if (tracking.run.cancelled) return { ok: false, error: { code: 'cancelled' } }
    if (tracking.run.timedOut) return { ok: false, error: { code: 'timeout' } }
    if (tracking.run.exitCode !== 0 || !isSafeRev(tracking.run.stdout.trim())) {
      return { ok: false, error: { code: 'upstream-missing', message: `remote-tracking ref is stale: ${request.action.ref}` } }
    }
    plan = planRemoteBranchDelete(target.remote, target.branch, tracking.run.stdout.trim())
  } else {
    plan = planAction(request.action, unborn)
  }
  if ('error' in plan) return { ok: false, error: { code: plan.error, ...(plan.message ? { message: plan.message } : {}) } }

  // A "stash then switch" checkout is planned as [stash, checkout]; both the
  // no-op stash guard below and the partial-failure code depend on knowing which
  // step is the stash (step 0).
  const stashing = request.action.kind === 'branch-checkout' && (request.action.stashMessage?.trim() ?? '') !== ''
  let lastOutput = ''
  // A per-path commit is two steps (add then commit); on failure include which
  // argv failed so the caller isn't left guessing whether the add or the commit
  // broke (the sequence is not atomic — the add may have staged already).
  for (let step = 0; step < plan.argv.length; step += 1) {
    const argv = plan.argv[step]!
    let outcome = await runCommand(deps.run, argv, root, 'action', deps.signal)
    // Shared-worktree contention: another git process (often the dsh AI agent)
    // holds .git/index.lock. Retry once after a short delay before surfacing a
    // friendly "git busy" error instead of the raw lock message.
    if (isIndexBusy(outcome)) {
      await new Promise((resolve) => setTimeout(resolve, 150))
      outcome = await runCommand(deps.run, argv, root, 'action-retry', deps.signal)
    }
    const where = plan.argv.length > 1 ? ` (step ${step + 1}/${plan.argv.length}: ${argv.join(' ')})` : ''
    // Stash-then-switch, step 2: the stash already succeeded, so the work tree
    // changed no matter how this step fails — a git refusal, a timeout, a
    // cancelled or unavailable git alike. Report every shape through the one
    // code that tells the caller the changes are in the stash (recoverable),
    // with the underlying reason riding along, rather than a plain error that
    // reads as "nothing happened".
    const stashChangedWorkTree = stashing && step > 0
    if ('failure' in outcome) {
      const message = outcome.failure instanceof Error ? outcome.failure.message : String(outcome.failure)
      return { ok: false, error: { code: stashChangedWorkTree ? 'stash-switch-failed' : 'git-unavailable', message: message + where } }
    }
    if (outcome.run.cancelled) {
      return { ok: false, error: stashChangedWorkTree ? { code: 'stash-switch-failed', message: 'cancelled' + where } : { code: 'cancelled' } }
    }
    if (outcome.run.timedOut) {
      return { ok: false, error: stashChangedWorkTree ? { code: 'stash-switch-failed', message: 'timed out' + where } : { code: 'timeout' } }
    }
    lastOutput = outcome.run.stdout || outcome.run.stderr
    if (outcome.run.exitCode !== 0) {
      const failure = classifyActionFailure(outcome.run.stdout, outcome.run.stderr, outcome.run.exitCode ?? -1)
      // A plain git refusal after a landed stash: same partial state, see above.
      if (stashChangedWorkTree) {
        return { ok: false, error: { code: 'stash-switch-failed', message: failure.message + where } }
      }
      // Cherry-picking a merge commit refuses exactly like reverting one (a
      // mainline parent is required); remap so the copy names the operation
      // the user actually ran. That refusal parks no state of its own.
      const code = request.action.kind === 'cherry-pick' && failure.code === 'revert-merge' ? 'pick-merge' : failure.code
      // A conflict (or an empty cherry-pick) parks merge/sequencer state the
      // panel has no way to finish — and which would also block the
      // shared-worktree dsh AI's own commits. Abort immediately to restore the
      // pre-op state (unrelated dirty changes are preserved by --abort). The
      // abort can itself lose the index.lock race (the very contention this
      // feature guards), so verify it (with the same one-shot retry) and, only
      // if it cleared the state, report the cancelled operation; otherwise tell
      // the user the repo is still mid-operation rather than falsely claiming
      // the work tree is untouched.
      const seq = sequenceAbortPlan(request.action, code)
      if (seq !== null) {
        let abort = await runCommand(deps.run, seq.argv, root, seq.probe, deps.signal)
        if (isIndexBusy(abort)) {
          await new Promise((resolve) => setTimeout(resolve, 150))
          abort = await runCommand(deps.run, seq.argv, root, `${seq.probe}-retry`, deps.signal)
        }
        const aborted = 'run' in abort && abort.run.exitCode === 0
        return aborted
          ? { ok: false, error: { code: seq.code, message: failure.message + where } }
          : { ok: false, error: { code: seq.stuck, message: failure.message + where } }
      }
      return { ok: false, error: { code, message: failure.message + where } }
    }
    // `git stash push` with nothing to stash (e.g. only untracked files, or only
    // ignored ones) prints "No local changes to save" and exits 0 — a silent
    // no-op that would look like a successful stash. Surface it as a failure so
    // the UI reports it. For the stash-then-switch path the blocking changes are
    // evidently not stashable by this flow, so report the block instead of
    // jumping into a checkout that is about to be refused all over again.
    if ((request.action.kind === 'stash-push' || stashing) && /No local changes to save/i.test(outcome.run.stdout + outcome.run.stderr)) {
      const message = (outcome.run.stdout.trim() || 'No local changes to save') + where
      return { ok: false, error: { code: stashing ? 'local-changes-block' : 'git-error', message } }
    }
  }

  const snapshot = await snapshotForSession(deps, config, request.sessionId, { repo: request.repo })
  if (!snapshot.ok) {
    return { ok: false, error: { code: 'git-error', message: 'snapshot after action failed' } }
  }
  return { ok: true, snapshot: snapshot.value, output: lastOutput.trim() }
}

/**
 * Whether a work-tree directory is a repository of its own: a nested repo or a
 * submodule (`.git`, directory or file) or a bare repository (no `.git`, but a
 * `HEAD` file beside the `objects/` and `refs/` directories). `discard` refuses
 * all of them — a recursive delete would take a whole repository's history with
 * it (issue #46).
 */
async function looksLikeRepository(deps: SnapshotDeps, target: string): Promise<boolean> {
  try {
    await deps.fs.stat(join(target, '.git'))
    return true
  } catch { /* not a nested repo / submodule — check the bare layout below */ }
  const head = await pathKind(deps, join(target, 'HEAD'))
  const refs = await pathKind(deps, join(target, 'refs'))
  const objects = await pathKind(deps, join(target, 'objects'))
  // `HEAD` is a file; `refs` and `objects` are directories. A path that is not
  // readable but is a symlink still counts: that is a shared store which is not
  // mounted right now, and the markers beside it are real data — refusing is
  // the safe direction. Only genuinely wrong types (a plain file where a
  // directory belongs) disqualify the entry.
  if (!head.present || head.directory === true) return false
  const directoryLike = (kind: PathKind): boolean => kind.present && kind.directory !== false
  return directoryLike(refs) && directoryLike(objects)
}

interface PathKind {
  /** The path exists; a dangling symlink counts as existing. */
  readonly present: boolean
  /** `true`/`false` when stat resolved it, `null` when only the link is known. */
  readonly directory: boolean | null
}

async function pathKind(deps: SnapshotDeps, path: string): Promise<PathKind> {
  try {
    return { present: true, directory: (await deps.fs.stat(path)).isDirectory() }
  } catch {
    return { present: (await deps.fs.symlinkTarget(path)) !== null, directory: null }
  }
}

/** The path's own entry (never followed), or null when nothing is there. */
async function lstatOrNull(
  deps: SnapshotDeps,
  path: string,
): Promise<{ isFile(): boolean; isDirectory(): boolean; isSymbolicLink(): boolean } | null> {
  try {
    return await deps.fs.lstat(path)
  } catch {
    return null
  }
}

/**
 * Split a discard request into untracked paths (deleted from the work tree
 * directly, since `git restore` can't touch them) and tracked paths (left for
 * the git command). Returns null when the action doesn't need this split
 * (no untracked path among the request). Each unlink is realpath-contained to
 * the repository root before it runs.
 */
async function discardUntracked(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  root: string,
  sessionId: string,
  repo: string | undefined,
  paths: readonly string[],
): Promise<null | { ok: true; remainingTracked: readonly string[] } | { ok: false; result: GitActionResult }> {
  const snap = await snapshotForSession(deps, config, sessionId, { repo })
  if (!snap.ok) return null
  const untrackedSet = new Set(snap.value.changes.filter((c) => c.status === 'untracked').map((c) => c.path))
  const untracked = paths.filter((p) => untrackedSet.has(p))
  if (untracked.length === 0) return null
  const tracked = paths.filter((p) => !untrackedSet.has(p))
  // Refuse the whole request (before removing anything) when an untracked
  // directory entry is itself a repository: a nested repo, a submodule or a bare
  // repository shows up as one directory entry, and a recursive delete would take
  // the entire inner repository with it. A plain directory that merely *contains*
  // a repo is still discarded as a whole — that boundary is deliberate (#46).
  // The remove loop below re-checks each directory right before its own removal:
  // only that instant can still see a repository appear after this scan.
  const directoryEntries = new Set(snap.value.changes.filter((c) => c.isDirectory === true).map((c) => c.path))
  for (const path of untracked) {
    if (!directoryEntries.has(path)) continue
    if (!(await looksLikeRepository(deps, join(root, path)))) continue
    return { ok: false, result: { ok: false, error: { code: 'nested-repo', message: `repository directory: ${path}` } } }
  }
  let rootReal: string
  try {
    rootReal = await deps.fs.realpath(root)
  } catch {
    return { ok: false, result: { ok: false, error: { code: 'git-error', message: 'repository root unavailable' } } }
  }
  // Remove every untracked target, collecting failures: a removal that did not
  // happen must not come back as a successful discard (a directory without
  // `recursive`, a permission error, …). Paths already gone stay gone — the
  // caller gets an error instead of a silent no-op.
  const failures: string[] = []
  let removedCount = 0
  for (const path of untracked) {
    if (!isSafePath(path)) return { ok: false, result: { ok: false, error: { code: 'invalid-path', message: `unsafe path: ${path}` } } }
    const target = join(root, path)
    const link = await lstatOrNull(deps, target)
    if (link === null) {
      // Nothing at that path: the entry is already gone (another process, or a
      // refresh that raced). Continuing is truthful — there is nothing to undo.
      continue
    }
    // A dangling symlink resolves to nothing, so `realpath` below cannot place
    // it; contain the link's own directory instead. `fs.remove` deletes the
    // link itself, never the target, so this is the same containment rule as a
    // regular entry — without it the link would be silently left behind.
    const targetReal = await deps.fs.realpath(target).catch(() => null)
    const containReal = targetReal ?? (link.isSymbolicLink()
      ? await deps.fs.realpath(dirname(target)).catch(() => null)
      : null)
    if (containReal === null || (containReal !== rootReal && !containReal.startsWith(rootReal + sep))) {
      return { ok: false, result: { ok: false, error: { code: 'invalid-path', message: `path escapes repository: ${path}` } } }
    }
    // Last-moment re-check: the pre-flight above can be raced by a repository
    // appearing under a directory target after it scanned. Statting again
    // immediately before the removal narrows that window to the few syscalls
    // between this call and the `rm` itself. Nothing has been removed yet in
    // the normal case, so the refusal still means "the batch is untouched"; if
    // it fires after earlier paths were deleted, say so with its own code —
    // the generic copy would read as if the whole batch had been skipped.
    if (await looksLikeRepository(deps, target)) {
      const code = removedCount === 0 ? 'nested-repo' : 'nested-repo-partial'
      const detail = removedCount === 0 ? '' : `; ${removedCount} path(s) already removed`
      return { ok: false, result: { ok: false, error: { code, message: `repository directory: ${path}${detail}` } } }
    }
    try {
      await deps.fs.remove(target)
      removedCount += 1
    } catch (e) {
      failures.push(`${path}: ${e instanceof Error ? e.message : String(e)}`)
    }
  }
  if (failures.length > 0) {
    // Named shortfalls: which paths failed, and that the tracked half of the
    // request never ran because the untracked deletions are attempted first.
    const skipped = tracked.length > 0 ? `; ${tracked.length} tracked path(s) not restored` : ''
    return {
      ok: false,
      result: { ok: false, error: { code: 'git-error', message: `could not discard ${failures.length} path(s): ${failures.join('; ')}${skipped}` } },
    }
  }
  return { ok: true, remainingTracked: tracked }
}
