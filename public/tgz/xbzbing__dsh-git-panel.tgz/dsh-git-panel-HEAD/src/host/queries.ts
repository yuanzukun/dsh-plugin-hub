/**
 * Read-only query endpoint: history / diff / image-diff / show / branches /
 * tags / authors / last-commit-message / worktree-stats.
 */
import { randomUUID } from 'node:crypto'
import { isAbsolute, join, relative, sep } from 'node:path'
import type { SnapshotDeps, GitPanelConfig } from './core.js'
import { listSessionRepos, mapWorkspaceFailure, resolveBrowseRoot, resolveWorkspace, runCommand, snapshotForSession } from './core.js'
import { exactPathspec, historyPathspec, isGitInternalPath, isSafePath, isSafeRev, validateHistoryPathSearch } from './validate.js'
import { walkHistoryTopology } from './history-topology.js'
import { commitFromFields, parseBranches, parseGraphLog, parseNameStatus, parseStashList, parseTags, sumNumstat } from './parser.js'
import type { DirEntry, GitBranch, GitFileStat, GitQueryRequest, GitQueryResponse, GraphCommit, ModelCatalogFailure, ModelCatalogGroup, ModelCatalogModel, StashEntry } from './types.js'
import { imageMimeFor, isEditablePath, isHistoryHashSearch, isHistoryFiltered, DIFF_CONTEXT_DEFAULT, DIFF_CONTEXT_MAX, DIFF_COUNT_READ_MAX, EDIT_MAX_BYTES, FILE_COPY_MAX_BYTES, FILE_LINES_MAX_LINES, FILE_LINES_READ_MAX, SVG_MIME } from './types.js'
import type { FileEditInfo } from './types.js'
import { editInfo, sha256Hex } from './edit-info.js'
import { isPackageSegment, projectSourceRoots, sourceRootOf, MAX_PACKAGE_READS, MAX_PACKAGE_SEGMENTS, PACKAGE_DEADLINE_MS, SOURCE_SETS } from './package-tree.js'

const GRAPH_FORMAT = '--format=%H%x1f%h%x1f%P%x1f%an%x1f%aI%x1f%D%x1f%s%x1e'

/**
 * Merge commits: git's default diff is the *combined* one, which lists only
 * files that differ from every parent and has hunks only where the result
 * differs from all of them — a per-file `git show <merge> -- <path>` therefore
 * often serves just the commit header, i.e. no code. Every commit surface of
 * the panel is a first-parent reader instead (the change set the merge brought
 * into its first parent), so the file list, the +/- totals and the per-file
 * diff all describe the same diff. `--numstat` already defaults to first-parent
 * for merges; this flag pins all three commands to that same view, matching
 * image-diff's explicit `<commit>^1` side.
 */
const FIRST_PARENT_DIFF = '--diff-merges=first-parent'

/**
 * Refs the history graph and the author dropdown both walk: the standard
 * visible branches/remotes/tags plus HEAD. `--all` officially means "refs/
 * along with HEAD", so HEAD must ride along — otherwise a detached-HEAD
 * chain (bisect, rebase in flight, checkout <sha>) disappears from both
 * surfaces — while the hidden refs `--all` drags in (refs/original from a
 * rebase, refs/notes) stay excluded (issue #9 follow-up).
 */
const VISIBLE_REFS: readonly string[] = ['--branches', '--remotes', '--tags', 'HEAD']

export async function runQuery(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  request: GitQueryRequest,
): Promise<GitQueryResponse> {
  const q = request.query
  // Model catalog for the config form: reads ctx.llm only, no workspace.
  if (q.kind === 'model-catalog') {
    try {
      return await queryModelCatalog(deps)
    } catch (error) {
      return { ok: false, error: { code: 'git-error', message: error instanceof Error ? error.message : String(error) } }
    }
  }
  // Repository discovery needs no work tree: it reports the cwd's own
  // repository (when it has one) plus, when `detectCheckouts` is on, the
  // worktrees and nested repositories below it — which is what lets the panel
  // offer a repository picker before anything is selected.
  if (q.kind === 'repo-list') {
    const listed = await listSessionRepos(deps, request.sessionId, config.detectCheckouts, undefined, config.codeWorkspace)
    if (!listed.ok) return { ok: false, error: listed.error }
    // Spread rather than rebuild: the value carries the workspace-file
    // recognition state, and rebuilding it here silently dropped that state
    // before it reached the only path the panel fetches repo-list through.
    return { ok: true, value: { ...listed.value, kind: 'repo-list' } }
  }

  // The file browser works outside a git repository too: resolve a plain
  // directory root (work-tree top when in a repo, else the session cwd) so
  // dir-list / file-content still function; every git-backed query keeps
  // requiring a real work tree.
  if (q.kind === 'dir-list' || q.kind === 'file-content') {
    const browse = await resolveBrowseRoot(deps, request.sessionId, request.repo, config.codeWorkspace)
    if (!browse.ok) return { ok: false, error: browse.error }
    try {
      return q.kind === 'dir-list'
        ? await queryDirList(deps, config, browse.root, q, browse.isGitRepo)
        : await queryFileContent(deps, config, browse.root, q)
    } catch (error) {
      return { ok: false, error: { code: 'git-error', message: error instanceof Error ? error.message : String(error) } }
    }
  }

  const workspace = await resolveWorkspace(deps, request.sessionId, request.repo, config.codeWorkspace)
  if (!workspace.ok) return { ok: false, error: mapWorkspaceFailure(workspace.failure) }
  const root = workspace.root

  try {
    switch (q.kind) {
      case 'history': return await queryHistory(deps, root, q)
      case 'diff': return await queryDiff(deps, root, q)
      case 'file-lines': return await queryFileLines(deps, config, root, q)
      case 'image-diff': return await queryImageDiff(deps, config, root, q)
      case 'show': return await queryShow(deps, root, q.ref)
      case 'branches': return await queryBranches(deps, root)
      case 'tags': return await queryTags(deps, root)
      case 'stash-list': return await queryStashList(deps, root)
      case 'authors': return await queryAuthors(deps, root)
      case 'last-commit-message': return await queryLastCommitMessage(deps, root)
      case 'worktree-stats': return await queryWorktreeStats(deps, config, request.sessionId, request.repo)
      case 'pull-preview': return await queryPullPreview(deps, root)
      case 'push-preview': return await queryPushPreview(deps, root)
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    return { ok: false, error: { code: 'git-error', message } }
  }
}

async function queryHistory(
  deps: SnapshotDeps,
  root: string,
  q: Extract<GitQueryRequest['query'], { kind: 'history' }>,
): Promise<GitQueryResponse> {
  // Clamp paging: the host is the trust boundary; a huge limit walks all of
  // history into the output cap, a non-number is a git fatal.
  const limit = Number.isFinite(q.limit) ? Math.min(500, Math.max(1, Math.trunc(q.limit))) : 100
  const skip = Number.isFinite(q.skip) ? Math.max(0, Math.trunc(q.skip)) : 0
  // Topological order is layoutGraph's contract (children before parents);
  // the default date order interleaves rebased chains once committer dates
  // skew, splitting a linear history into phantom parallel lanes.
  // `--decorate=full` makes %D emit full ref paths (refs/heads/…, refs/remotes/…,
  // refs/tags/…) so parseRefs can tell a slashed local branch from a remote ref
  // and not misclassify it (which mislabeled the current-branch chip).
  const args = ['git', 'log', '--topo-order', '--decorate=full', GRAPH_FORMAT, `--max-count=${limit}`, `--skip=${skip}`]
  if (q.search !== undefined && typeof q.search !== 'string') {
    return { ok: false, error: { code: 'invalid-name', message: 'history search must be a string' } }
  }
  const pathInput = validateHistoryPathSearch(q.pathSearch)
  if (!pathInput.ok) return { ok: false, error: { code: 'invalid-name', message: pathInput.message } }
  const search = q.search?.trim() ?? ''
  const pathSearch = pathInput.value
  if (search !== '' && pathSearch !== '') {
    return { ok: false, error: { code: 'invalid-name', message: 'history search fields are mutually exclusive' } }
  }
  // The file-history filter names one exact repository path. It is exclusive
  // with every other filter: the substring search answers "which commits touch
  // something like this", the exact path answers "what happened to this file",
  // and a menu that asks the second never wants the first misread.
  let exactPath: string | null = null
  if (q.exactPath !== undefined) {
    if (typeof q.exactPath !== 'string' || !isSafePath(q.exactPath) || /[\x00-\x1f\x7f-\x9f]/.test(q.exactPath)) {
      return { ok: false, error: { code: 'invalid-name', message: `unsafe exact path: ${q.exactPath}` } }
    }
    if (q.exactPath === '' || pathSearch !== '' || search !== '' || q.author !== undefined || q.since !== undefined) {
      return { ok: false, error: { code: 'invalid-name', message: 'history search fields are mutually exclusive' } }
    }
    exactPath = q.exactPath
  }
  const hexJump = pathSearch === '' && exactPath === null && isHistoryHashSearch(search)
  const filtered = isHistoryFiltered({ ...q, pathSearch: pathSearch || (exactPath !== null ? exactPath : undefined) })
  // Exactly the flags pushed below (one source, so they can never disagree). An
  // effective filter hides commits — and therefore parents — from the page
  // itself, which is what makes the raw-ancestry walk necessary; a ref-only walk
  // still sees every commit. A whitespace-only author/since is a real filter
  // (`--author=' '` matches names containing a space), so only undefined/'' are
  // absent.
  const author = q.author ?? ''
  const since = q.since ?? ''
  const searchFilter = search !== ''
  const authorFilter = author !== ''
  const sinceFilter = since !== ''
  const countArgs = ['git', 'rev-list', '--count']
  // Untrusted ref/author filters must never reach an option position: reject a
  // dash-prefixed / metacharacter ref (the `--output=` file-write vector) and
  // pass the ref after `--end-of-options`, which git treats as a bare operand.
  // The trailing `--` ends the revision list, so an operand that shares its
  // name with a work-tree path stays a revision instead of becoming an
  // ambiguous argument (a branch like `observatory` next to `observatory/`, or
  // the literal HEAD next to a file named `HEAD`). Both the page log and the
  // count walk need it.
  if (!hexJump) {
    // The same filter set feeds both the page log and the total-count walk.
    const filters: string[] = []
    if (searchFilter) filters.push('-i', '-E', `--grep=${search}`)
    if (authorFilter) filters.push(`--author=${author}`)
    if (sinceFilter) filters.push(`--since=${since}`)
    if (q.ref !== undefined && q.ref !== '') {
      if (!isSafeRev(q.ref)) return { ok: false, error: { code: 'invalid-name', message: `unsafe ref: ${q.ref}` } }
      filters.push('--end-of-options', q.ref)
    } else {
      filters.push(...VISIBLE_REFS)
    }
    filters.push('--')
    if (pathSearch !== '') filters.push(historyPathspec(pathSearch))
    else if (exactPath !== null) filters.push(exactPathspec(exactPath))
    args.push(...filters)
    countArgs.push(...filters)
  } else {
    // Hash jump: `search` is already constrained to [0-9a-f]{7,40} by
    // isHistoryHashSearch. The trailing `--` ends the revision list, so a
    // work-tree file named like the hash cannot make the argument ambiguous.
    args.push('--end-of-options', search, '--')
  }
  // Run the page log and the total count concurrently (the count is a second
  // full history walk; serializing it roughly doubled the first-page latency).
  const [res, countRes] = await Promise.all([
    runCommand(deps.run, args, root, 'history', deps.signal),
    hexJump ? Promise.resolve(null) : runCommand(deps.run, countArgs, root, 'history-count', deps.signal),
  ])
  if (!('run' in res)) return { ok: false, error: { code: 'git-unavailable' } }
  if (res.run.cancelled) return { ok: false, error: { code: 'cancelled' } }
  if (res.run.timedOut) return { ok: false, error: { code: 'timeout' } }
  if (res.run.exitCode !== 0) {
    // Only a hash-jump miss or a genuine unknown/empty ref is an empty page;
    // every other non-zero exit surfaces as an error instead of a silent
    // "no commits" that would also mask malformed input. "ambiguous argument"
    // is deliberately not an empty page: with the `--` above it means git
    // really could not decide what the operand was, and hiding that is what
    // made a broken ref filter look like a branch without commits.
    const stderr = res.run.stderr.trim()
    if (hexJump || /unknown revision|bad revision|does not have any commits/i.test(stderr)) {
      // A filtered empty page still carries the field, so the client can tell
      // "filtered, no ancestry" from "unfiltered / old host".
      return { ok: true, value: { kind: 'history', commits: [], total: 0, pathSearchSupported: true, ...(filtered ? { topology: [] } : {}) } }
    }
    return { ok: false, error: { code: 'git-error', message: stderr || `git exited ${res.run.exitCode}` } }
  }
  // A lossy read keeps the stream's tail, and this stream is newest-first: the
  // head of what was dropped is exactly the latest commits (HEAD included)
  // while the count above stays complete. Serving the survivors would render a
  // history that silently omits the present, so the page fails instead — the
  // client keeps its previous list and offers a retry.
  if (res.run.stdoutLossy) {
    return { ok: false, error: { code: 'git-error', message: 'git log output exceeded the output cap' } }
  }
  const commits: GraphCommit[] = parseGraphLog(res.run.stdout)
  // Hash-jump ignores ref/author/since filters and starts the walk at the
  // commit itself, so a total is meaningless; -1 (the initial value) tells the
  // client to page by "did the last page fill" instead of a fixed count.
  let total = -1
  if (!hexJump && countRes !== null && 'run' in countRes && countRes.run.exitCode === 0) {
    const n = Number(countRes.run.stdout.trim())
    if (Number.isFinite(n)) total = n
  }
  // A filtered page is missing most of its parents, so one bounded auxiliary
  // walk supplies the raw ancestry. An empty page has nothing to walk, and an
  // unfiltered/hash-jump page omits the field entirely (no extra command).
  const topology = filtered
    ? (commits.length === 0 ? [] : await walkHistoryTopology(deps.run, root, commits.map((c) => c.hash), deps.signal))
    : undefined
  return { ok: true, value: { kind: 'history', commits, total, pathSearchSupported: true, ...(topology !== undefined ? { topology } : {}) } }
}

async function queryDiff(
  deps: SnapshotDeps,
  root: string,
  q: Extract<GitQueryRequest['query'], { kind: 'diff' }>,
): Promise<GitQueryResponse> {
  if (!isSafePath(q.path)) return { ok: false, error: { code: 'invalid-path', message: q.path } }
  // Git's own directory is metadata, not workspace content — and the untracked
  // fallback below compares with `--no-index`, which bypasses git's exclusion
  // and would read `config` (with its remote URL) out as a new file.
  if (isGitInternalPath(q.path)) return { ok: false, error: { code: 'invalid-path', message: q.path } }
  // Context lines around each change; DIFF_CONTEXT_MAX shows the whole file
  // (expand-all). Clamp to a sane ceiling to bound output.
  const ctx = q.context !== undefined && Number.isFinite(q.context)
    ? Math.max(0, Math.min(DIFF_CONTEXT_MAX, Math.floor(q.context)))
    : DIFF_CONTEXT_DEFAULT
  const unified = `-U${ctx}`
  let args: string[]
  if (q.base === 'staged') {
    args = ['git', 'diff', unified, '--cached', '--', q.path]
  } else if (q.base === 'commit') {
    if (!isSafeRev(q.commit)) return { ok: false, error: { code: 'invalid-name', message: `unsafe commit: ${q.commit}` } }
    args = ['git', 'show', unified, FIRST_PARENT_DIFF, '--end-of-options', q.commit, '--', q.path]
  } else if (q.base === 'rev') {
    // "Compare with a revision": old side `<rev>`, new side the working file.
    // Full refs (refs/heads/x, refs/remotes/o/x, refs/tags/x) ride in the
    // caller's value; a bare name stays bare — `--end-of-options` plus the
    // trailing `--` keep it an operand either way.
    if (!isSafeRev(q.rev)) return { ok: false, error: { code: 'invalid-name', message: `unsafe rev: ${q.rev}` } }
    // A revision comparison is one file. A directory path answers with a
    // multi-file diff, which this single-pane reply cannot express: the view
    // would draw the second file's headers as a changed line. Reject it here so
    // a caller that offers the entry anyway gets an error instead of nonsense.
    const stat = await deps.fs.stat(join(root, q.path)).catch(() => null)
    if (stat !== null && stat.isDirectory()) {
      return { ok: false, error: { code: 'invalid-path', message: `not a file: ${q.path}` } }
    }
    // The working path may be gone (a directory deleted here, still present in
    // the revision): ask the revision what its own entry is.
    if (await revSideIsTree(deps, root, `${q.rev}:${q.path}`)) {
      return { ok: false, error: { code: 'invalid-path', message: `not a file in ${q.rev}: ${q.path}` } }
    }
    args = ['git', 'diff', unified, '--end-of-options', q.rev, '--', q.path]
  } else if (q.base === 'worktree') {
    // worktree: unstaged diff; for untracked files use --no-index against /dev/null.
    args = ['git', 'diff', unified, '--', q.path]
  } else {
    // An unknown base must not silently become a work-tree diff: the caller
    // asked for a comparison against something this host does not model, and
    // the work-tree answer would read as the right shape with wrong content.
    return { ok: false, error: { code: 'invalid-name', message: `unknown diff base` } }
  }
  const res = await runCommand(deps.run, args, root, 'diff', deps.signal)
  if (!('run' in res)) return { ok: false, error: { code: 'git-unavailable' } }
  if (res.run.cancelled) return { ok: false, error: { code: 'cancelled' } }
  if (res.run.timedOut) return { ok: false, error: { code: 'timeout' } }
  // `git diff <rev>` answers a revision it does not know (a branch deleted since
  // the picker listed it) with `fatal: bad revision` and *empty* stdout, exit
  // 128. Serving that would read as "no differences" against a ref that does not
  // exist. The staged and work-tree forms have no operand to get wrong — an
  // unmatched pathspec exits 0 there — so the same check is a no-op for them.
  if (res.run.exitCode !== 0) {
    return { ok: false, error: { code: 'git-error', message: res.run.stderr.trim() || 'git diff failed' } }
  }
  // A lossy run dropped output at the runner's collect/spill ceiling, and a
  // lossy read keeps the stream's *tail*: this single-file diff lost its header
  // and opening hunks, so what survived starts mid-diff. Surviving hunks still
  // carry git's own line numbers, but the +/- counts under-report, and the lost
  // opening returns as an ordinary collapsible gap whose revealed lines come
  // from the new side — a changed line would show as unchanged context. Serve it
  // (the remaining hunks are readable) but flag it: `readNewSide` refuses a
  // lossy `git show` (count → 0), while a worktree side is read off disk and its
  // count does not degrade.
  let truncated = res.run.stdoutLossy
  let text = res.run.stdout
  // A truly untracked file produces no `git diff` output; synthesize one with
  // --no-index. Gate on the file being untracked (ls-files --error-unmatch
  // fails for it) so a clean *tracked* path isn't rendered as an all-new file.
  if (q.base === 'worktree' || q.base === 'rev') {
    const tracked = await runCommand(deps.run, ['git', 'ls-files', '--error-unmatch', '--', q.path], root, 'diff-tracked-probe', deps.signal)
    const isUntracked = !('run' in tracked) || tracked.run.exitCode !== 0
    if (isUntracked) {
      // A revision comparison of an untracked path is the case `git diff <rev>`
      // cannot answer: it compares the rev's tree with the *index*, so the path
      // reads as a deletion of the rev's blob and the working file never shows.
      // Compose that one by hand; it falls back to the empty-side form below
      // when the rev has no such path either.
      const synthesized = q.base === 'rev' ? await revBlobAgainstWorktree(deps, root, q, unified) : null
      // The revision holds the path but its blob cannot be put side by side
      // with the working file: serving the caller's `git diff <rev>` answer
      // would silently show "deleted" for a file that exists. Say what happened.
      if (synthesized !== null && synthesized.kind === 'failed') {
        return { ok: false, error: { code: 'git-error', message: 'compare unavailable' } }
      }
      if (synthesized !== null && synthesized.kind === 'diff') {
        truncated = truncated || synthesized.truncated
        text = synthesized.text
      } else if (text.trim() === '') {
        // No old side to compare against (`none`, or a work-tree diff with no
        // output): the path is all-new.
        const noIndex = await runCommand(deps.run, ['git', 'diff', unified, '--no-index', '--', '/dev/null', q.path], root, 'diff-untracked', deps.signal)
        if ('run' in noIndex) {
          truncated = truncated || noIndex.run.stdoutLossy
          text = noIndex.run.stdout
        }
      }
    }
  }
  return {
    ok: true,
    value: {
      kind: 'diff', path: q.path, text,
      newLines: await countNewSideLines(deps, root, q, text),
      ...(truncated ? { truncated: true as const } : {}),
    },
  }
}

/**
 * A scratch name for the synthesized old side: unique per call, so two panels
 * comparing at once cannot collide. It lives in the repository's own git
 * directory — `<root>/.git` is a *file* in a linked worktree or submodule, and
 * writing there would fail — which also keeps it out of the working tree, so it
 * can never show up as an untracked change of the very repository being
 * compared.
 */
async function compareScratchPath(deps: SnapshotDeps, root: string, path: string): Promise<string | null> {
  const res = await runCommand(deps.run, ['git', 'rev-parse', '--git-path', '.'], root, 'compare-scratch-dir', deps.signal)
  if (!('run' in res) || res.run.exitCode !== 0) return null
  const dir = res.run.stdout.trim()
  if (dir === '') return null
  // A linked worktree answers with an absolute path under the main checkout's
  // git directory; a plain repository answers `.git`.
  const base = isAbsolute(dir) ? dir : join(root, dir)
  // A random leaf, not `pid`+counter: a process killed between the write and
  // the unlink leaves the file behind, and a later run could reuse the same
  // name (pid reuse) only to fail on `wx` and degrade to an error. The random
  // name makes a collision impossible in practice.
  const leaf = path.replace(/[\\/]+/g, '-').replace(/[^A-Za-z0-9._-]/g, '_').slice(-60)
  return join(base, `gp-compare-${randomUUID()}-${leaf}`)
}

/** How the synthesized old side of a revision comparison came out.
 *
 * `none` is "there is nothing to synthesize": the revision has no such path,
 * or the working file is gone (a staged `git rm`), and the caller's own
 * `git diff <rev>` answer is the right one. `failed` is *not* the same thing:
 * the revision holds content, so falling back to the caller's "deleted" answer
 * would be a lie about a file that exists.
 */
type RevSideResult =
  | { readonly kind: 'none' }
  | { readonly kind: 'diff'; readonly text: string; readonly truncated: boolean }
  | { readonly kind: 'failed' }

/**
 * Whether a revision stores a directory at the repository-relative path.
 * A single-file comparison cannot express a tree (its diff lists more than one
 * file), and the working path may be gone while the revision still has one.
 */
async function revSideIsTree(deps: SnapshotDeps, root: string, spec: string): Promise<boolean> {
  const res = await runCommand(deps.run, ['git', 'cat-file', '-t', '--end-of-options', spec], root, 'rev-side-type', deps.signal)
  return 'run' in res && res.run.exitCode === 0 && res.run.stdout.trim() === 'tree'
}

/**
 * The old side of a revision comparison when the working path is untracked:
 * `git diff <rev> -- <path>` compares the rev's tree against the index and
 * reports the path as deleted, which is true about the index and wrong about
 * what the user asked for. Write the rev's blob to a scratch file and let
 * `--no-index` compare it with the working file, so both sides are real.
 */
async function revBlobAgainstWorktree(
  deps: SnapshotDeps,
  root: string,
  q: Extract<GitQueryRequest['query'], { kind: 'diff'; base: 'rev' }>,
  unified: string,
): Promise<RevSideResult> {
  if (!isSafeRev(q.rev)) return { kind: 'failed' }
  const spec = `${q.rev}:${q.path}`
  const blob = await runCommand(deps.run, ['git', 'cat-file', '-e', '--end-of-options', spec], root, 'rev-old-probe', deps.signal)
  if (!('run' in blob) || blob.run.exitCode !== 0) return { kind: 'none' }
  const old = await runCommand(deps.run, ['git', 'show', '--end-of-options', spec], root, 'rev-old-side', deps.signal)
  if (!('run' in old) || old.run.exitCode !== 0 || old.run.stdoutLossy) return { kind: 'failed' }
  const scratch = await compareScratchPath(deps, root, q.path)
  if (scratch === null) return { kind: 'failed' }
  try {
    await deps.fs.writeExclusive(scratch, Buffer.from(old.run.stdout, 'utf8'), 0o600)
  } catch {
    return { kind: 'failed' }
  }
  try {
    // The path may be gone from the working tree (a staged `git rm`): `--no-index`
    // then has a face to compare against nothing and its output is not the
    // two-sided answer the view needs. The revision still has content and the
    // caller's own `git diff <rev> -- path` already described the deletion.
    const stat = await deps.fs.stat(join(root, q.path)).catch(() => null)
    if (stat === null) return { kind: 'none' }
    const rel = relative(root, scratch)
    const res = await runCommand(deps.run, ['git', 'diff', unified, '--no-index', '--', rel, q.path], root, 'diff-untracked', deps.signal)
    // `--no-index` exits 0 and prints nothing when the two sides are identical.
    // That is a valid answer (an empty diff), not a missing one: otherwise the
    // caller keeps the deletion hunk the first command produced.
    if (!('run' in res)) return { kind: 'failed' }
    return { kind: 'diff', text: res.run.stdout, truncated: res.run.stdoutLossy }
  } finally {
    // A leftover scratch file inside .git is invisible but wrong to leave
    // behind; a failed unlink must not turn a served diff into an error.
    await deps.fs.unlink(scratch).catch(() => {})
  }
}

/**
 * Lines in the diff's new-side version — the fact that decides whether hidden
 * context can follow the last hunk. git caps trailing context at -U, so a full
 * trailing run in `text` is ambiguous on its own: the hunk may be mid-file, or
 * the file may end exactly there. The count resolves it, and it comes from the
 * same source the diff compared against (see readNewSide), so the view and the
 * file agree.
 *
 * 0 means "no new side, or the count is not trustworthy" (deleted file, missing
 * blob, failed/truncated read, no hunk to follow, working file above
 * DIFF_COUNT_READ_MAX): the view then hides the trailing expand control rather
 * than offering one that could not reveal anything.
 */
/** The version a diff's new side comes from: the work tree for a work-tree or
 * revision comparison (a revision is the OLD side), the index for staged, the
 * commit for a stored diff. `file-lines` and the line count read through this,
 * so neither can describe a different file than the diff did. */
function newSideQuery(
  q: Extract<GitQueryRequest['query'], { kind: 'diff' }>,
): Extract<GitQueryRequest['query'], { kind: 'diff' }> {
  if (q.base !== 'rev') return q
  return { kind: 'diff', path: q.path, base: 'worktree', ...(q.context === undefined ? {} : { context: q.context }) }
}

async function countNewSideLines(
  deps: SnapshotDeps,
  root: string,
  q: Extract<GitQueryRequest['query'], { kind: 'diff' }>,
  diffText: string,
): Promise<number> {
  // Without a hunk no gap row can exist, so the count cannot matter — and a
  // binary / empty diff then costs no read at all.
  if (!diffText.includes('@@')) return 0
  // The working file is read by us, uncapped by the runner: bound the read that
  // only feeds this count (file-lines, the expansion path, stays uncapped).
  const side = await readNewSide(deps, root, newSideQuery(q), { worktreeMaxBytes: DIFF_COUNT_READ_MAX })
  if (!side.ok || side.text === null) return 0
  return countLines(side.text)
}

/** Number of lines in `content` under the same convention as splitLines (one
 * trailing newline does not start a new line). Counting without splitting keeps
 * the poll-path read from allocating one string per line just to read `.length`. */
export function countLines(content: string): number {
  if (content === '') return 0
  let lines = 1
  for (let at = content.indexOf('\n'); at !== -1; at = content.indexOf('\n', at + 1)) lines++
  return content.endsWith('\n') ? lines - 1 : lines
}

/** Split file content into lines, dropping one trailing newline element so the
 * count matches the file's real line count (shared by the count and the slice). */
function splitLines(content: string): string[] {
  const all = content.split('\n')
  if (all[all.length - 1] === '') all.pop()
  return all
}

/**
 * A slice of a file's post-change content for on-demand context expansion. The
 * source version mirrors the diff's new side: worktree reads the working file
 * (a symlink as its target text, which is the blob git compares), staged reads
 * the index blob, commit reads `<commit>:<path>`. The whole file is materialized
 * then sliced in-process — expansion targets small ranges and git offers no
 * cheap "print lines m..n of a blob" primitive.
 */
async function queryFileLines(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  root: string,
  q: Extract<GitQueryRequest['query'], { kind: 'file-lines' }>,
): Promise<GitQueryResponse> {
  if (!isSafePath(q.path) || hasGitSegment(q.path)) return { ok: false, error: { code: 'invalid-path', message: q.path } }
  const start = Number.isFinite(q.start) ? Math.max(1, Math.floor(q.start)) : 1
  // `end` is client-supplied and used to be uncapped: one gap with a huge count
  // asked for the whole file, and a worktree side was read with no byte limit.
  // Both the range and the read are bounded now (the client splits a bigger
  // gap into several requests).
  const requested = Number.isFinite(q.end) ? Math.max(start, Math.floor(q.end)) : start
  const end = Math.min(requested, start + FILE_LINES_MAX_LINES - 1)
  const side = await readNewSide(deps, root, q, { worktreeMaxBytes: FILE_LINES_READ_MAX, worktreeTooLargeError: true })
  if (!side.ok) return { ok: false, error: { code: side.code, message: side.message } }
  // A side that does not exist (deleted file, missing blob) has no lines: an
  // empty EOF slice is the truthful answer and lets the caller drop its gap.
  return sliceLines(q.path, side.text ?? '', start, end, config.maxBytes)
}

/** New-side text of a diff, or null when that side has no content. */
type NewSideRead =
  | { readonly ok: true; readonly text: string | null }
  | { readonly ok: false; readonly code: 'invalid-name' | 'git-unavailable' | 'cancelled' | 'timeout' | 'git-error'; readonly message: string }

/** git says "this version has no such path" in exactly these shapes; every
 * other non-zero exit (bad rev, corrupt object) is a real failure. */
const ABSENT_SIDE_RE = /does not exist in|exists on disk, but not in the index|no such path/i

/**
 * Read the version a diff's RIGHT side compares against — the single source of
 * truth shared by gap expansion (`file-lines`) and the new-side line count, so
 * a revealed slice and a reported count can never describe different files.
 *
 * `worktree` reads the working file itself (the index is the LEFT side of an
 * unstaged diff — reading it would reveal stale lines), `staged` reads the
 * index blob, `commit` the commit blob. `worktreeMaxBytes` bounds the read: a
 * file over the bound reads as `null` (count = unknown) for the count-only
 * caller, and as an error for the caller passing `worktreeTooLargeError`
 * (`file-lines`), which must not turn a huge file into an empty EOF slice.
 */
async function readNewSide(
  deps: SnapshotDeps,
  root: string,
  q: Extract<GitQueryRequest['query'], { kind: 'diff' | 'file-lines' }>,
  opts?: { readonly worktreeMaxBytes?: number; readonly worktreeTooLargeError?: boolean },
): Promise<NewSideRead> {
  if (q.base === 'worktree') {
    const read = await readWorktreeSide(deps, root, q.path, opts?.worktreeMaxBytes)
    if ('tooLarge' in read) {
      return opts?.worktreeTooLargeError === true
        ? { ok: false, code: 'git-error', message: `worktree file exceeds the read limit: ${q.path}` }
        : { ok: true, text: null }
    }
    return { ok: true, text: 'text' in read ? read.text : null }
  }
  if (q.base === 'commit' && !isSafeRev(q.commit)) return { ok: false, code: 'invalid-name', message: `unsafe commit: ${q.commit}` }
  // A revision comparison's new side is the work tree; reading the index here
  // would reveal stale lines. Callers map the base before asking (newSideQuery).
  if (q.base === 'rev') return { ok: false, code: 'invalid-name', message: 'rev base has no stored new side' }
  const spec = q.base === 'commit' ? `${q.commit}:${q.path}` : `:${q.path}`
  const res = await runCommand(deps.run, ['git', 'show', '--end-of-options', spec], root, 'new-side', deps.signal)
  if (!('run' in res)) return { ok: false, code: 'git-unavailable', message: 'git unavailable' }
  if (res.run.cancelled) return { ok: false, code: 'cancelled', message: 'cancelled' }
  if (res.run.timedOut) return { ok: false, code: 'timeout', message: 'timed out' }
  if (res.run.exitCode !== 0) {
    // "That version does not contain this path" is a missing side (a deleted
    // file reads as an empty one); anything else must stay an error rather than
    // masquerade as empty — a bad rev or a corrupt object would otherwise look
    // exactly like a deleted file.
    return ABSENT_SIDE_RE.test(res.run.stderr)
      ? { ok: true, text: null }
      : { ok: false, code: 'git-error', message: res.run.stderr.trim() || 'git show failed' }
  }
  // A lossy read means the runner dropped output at its collect/spill ceiling:
  // what survived is the stream's *tail* (the head is what gets dropped), so a
  // count or a slice from it would be a plausible lie. Refuse it instead (the
  // count degrades to 0 = unknown).
  if (res.run.stdoutLossy) return { ok: false, code: 'git-error', message: 'git show output exceeded the output cap' }
  return { ok: true, text: res.run.stdout }
}

/**
 * Working file as the diff's new side: the LINK TEXT for a symlink (git stores
 * that as the blob, so following the link would describe a different file), CRLF
 * normalized like the blob git compares, else the file's own text. `maxBytes`
 * bounds the read; over the bound reports `tooLarge`, not "no content known".
 */
async function readWorktreeSide(deps: SnapshotDeps, root: string, path: string, maxBytes?: number): Promise<WorktreeTextRead> {
  const file = join(root, path)
  const link = await deps.fs.symlinkTarget(file)
  if (link !== null) return { text: link }
  const read = await readWorktreeText(deps, root, path, maxBytes)
  if ('text' in read) {
    // core.autocrlf rewrites the working file on checkout, so the bytes on disk
    // can carry CRLF while the diff (and the blob it compares) is LF; revealing
    // the raw bytes would show a \r the diff never had. Line count is unaffected.
    return { text: read.text.replace(/\r\n/g, '\n') }
  }
  return read
}

/** A worktree text read: the file's text, nothing readable at that path, or a
 * file larger than the caller's byte bound — which is NOT "the side is empty",
 * so the distinction survives up to the query that decides what to report. */
type WorktreeTextRead = { readonly text: string } | { readonly absent: true } | { readonly tooLarge: true }

/** Read a worktree file as text when it is inside the root and browsable:
 * symlink-contained, `.git` excluded (its config can carry a remote token), a
 * regular file (a FIFO would hold the read — and a libuv thread — forever), and
 * within `maxBytes` when a caller bounds it. */
async function readWorktreeText(
  deps: SnapshotDeps,
  root: string,
  path: string,
  maxBytes?: number,
): Promise<WorktreeTextRead> {
  if (hasGitSegment(path)) return { absent: true }
  const file = join(root, path)
  if ((await isInsideRoot(deps, root, file, true)) !== 'inside') return { absent: true }
  try {
    const info = await deps.fs.stat(file)
    if (!info.isFile()) return { absent: true }
    if (maxBytes !== undefined && info.size > maxBytes) return { tooLarge: true }
    const buf = await deps.fs.readFile(file)
    return { text: buf.toString('utf8') }
  } catch {
    return { absent: true }
  }
}

/** Slice `content` to 1-based lines start..end, flagging when end hit EOF.
 * `maxBytes` stops the slice early rather than shipping a reply the transport
 * would choke on: the caller asks for the following range while `eof` is false. */
function sliceLines(path: string, content: string, start: number, end: number, maxBytes?: number): GitQueryResponse {
  const all = splitLines(content)
  const from = Math.min(start, all.length + 1)
  const to = Math.min(end, all.length)
  const lines: string[] = []
  let bytes = 0
  for (let i = from - 1; i < to; i += 1) {
    const line = all[i]!
    bytes += Buffer.byteLength(line, 'utf8') + 1
    if (maxBytes !== undefined && lines.length > 0 && bytes > maxBytes) break
    lines.push(line)
  }
  const eof = from - 1 + lines.length >= all.length
  return { ok: true, value: { kind: 'file-lines', path, start: from, lines, eof } }
}

// ── image diff ─────────────────────────────────────────────────────────────

/** One image side: base64 payload, an over-cap flag, or absent (no such side). */
type ImageSide = { readonly data: string } | { readonly tooLarge: true } | undefined

/**
 * Old/new image sides for a binary image, mirroring the text diff's sources:
 * worktree rows compare index vs working file, staged rows HEAD vs index,
 * commit rows parent vs commit — so each pane matches the code pane's meaning.
 * Each side is capped at `config.maxBytes` (profile-configurable): as base64
 * inside one JSON envelope, two capped sides bound the RPC payload.
 */
async function queryImageDiff(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  root: string,
  q: Extract<GitQueryRequest['query'], { kind: 'image-diff' }>,
): Promise<GitQueryResponse> {
  if (!isSafePath(q.path)) return { ok: false, error: { code: 'invalid-path', message: q.path } }
  if (isGitInternalPath(q.path)) return { ok: false, error: { code: 'invalid-path', message: q.path } }
  if (q.base === 'commit' && !isSafeRev(q.commit)) return { ok: false, error: { code: 'invalid-name', message: `unsafe commit: ${q.commit}` } }
  if (q.base === 'rev' && !isSafeRev(q.rev)) return { ok: false, error: { code: 'invalid-name', message: `unsafe rev: ${q.rev}` } }
  const mime = imageMimeFor(q.path)
  if (mime === null) return { ok: true, value: { kind: 'image-diff', path: q.path, mime } }
  // One picture, not a directory: a directory name can still end in an image
  // suffix (`assets.png/`), and a revision-side tree resolves to an oid that
  // blobSide cannot read — a half-answer the view draws as a broken side.
  const stat = await deps.fs.stat(join(root, q.path)).catch(() => null)
  if (stat !== null && stat.isDirectory()) {
    return { ok: false, error: { code: 'invalid-path', message: `not a file: ${q.path}` } }
  }
  if ((q.base === 'rev' || q.base === 'commit')
    && await revSideIsTree(deps, root, `${q.base === 'rev' ? q.rev : q.commit}:${q.path}`)) {
    return { ok: false, error: { code: 'invalid-path', message: `not a file: ${q.path}` } }
  }

  // Old side: the stored version being compared against; the work tree for a
  // revision comparison, whose picture is read from disk like the work-tree case.
  const oldSpec = q.base === 'staged'
    ? `HEAD:${q.path}`
    : q.base === 'commit' ? `${q.commit}^1:${q.path}` : q.base === 'rev' ? `${q.rev}:${q.path}` : `:${q.path}`
  const newSpec = q.base === 'staged' ? `:${q.path}` : q.base === 'commit' ? `${q.commit}:${q.path}` : null
  const [oldOid, newOid] = await Promise.all([
    resolveOid(deps, root, oldSpec),
    newSpec === null ? Promise.resolve(undefined) : resolveOid(deps, root, newSpec),
  ])

  // A path the revision does not carry is a legitimate one-sided answer (the
  // picture arrived later); a revision the repository does not know is not.
  // Both leave `oldOid` undefined, and only asking the revision itself tells
  // them apart — without this the work-tree side alone would render as "added".
  if (oldOid === undefined && (q.base === 'rev' || q.base === 'commit')) {
    const rev = q.base === 'rev' ? q.rev : q.commit
    const known = await runCommand(deps.run, ['git', 'rev-parse', '--verify', '--end-of-options', `${rev}^{commit}`], root, 'rev-exists', deps.signal)
    if (!('run' in known)) return { ok: false, error: { code: 'git-unavailable' } }
    if (known.run.cancelled) return { ok: false, error: { code: 'cancelled' } }
    if (known.run.timedOut) return { ok: false, error: { code: 'timeout' } }
    if (known.run.exitCode !== 0) {
      return { ok: false, error: { code: 'git-error', message: `unknown revision: ${rev}` } }
    }
  }

  const cap = config.maxBytes
  const gitDir = oldOid !== undefined || newOid !== undefined ? await absoluteGitDir(deps, root) : ''
  const [oldSide, newSide] = await Promise.all([
    oldOid === undefined ? Promise.resolve(undefined) : blobSide(deps, gitDir, oldOid, cap),
    newOid !== undefined
      ? blobSide(deps, gitDir, newOid, cap)
      : q.base === 'worktree' || q.base === 'rev' ? worktreeSide(deps, root, q.path, cap) : Promise.resolve(undefined),
  ])
  const sides = [oldSide, newSide]
  if (sides.some((s) => s !== undefined && 'tooLarge' in s)) {
    return { ok: true, value: { kind: 'image-diff', path: q.path, mime, tooLarge: true } }
  }
  const old64 = sides[0] !== undefined && !('tooLarge' in sides[0]) ? sides[0].data : undefined
  const new64 = sides[1] !== undefined && !('tooLarge' in sides[1]) ? sides[1].data : undefined
  return {
    ok: true,
    value: {
      kind: 'image-diff', path: q.path, mime,
      ...(old64 !== undefined ? { old: `data:${mime};base64,${old64}` } : {}),
      ...(new64 !== undefined ? { new: `data:${mime};base64,${new64}` } : {}),
    },
  }
}

/** Resolve `<rev>:<path>` to a full object id; absent spec → undefined. */
async function resolveOid(deps: SnapshotDeps, root: string, spec: string): Promise<string | undefined> {
  const res = await runCommand(deps.run, ['git', 'rev-parse', '--verify', '--quiet', spec], root, 'image-oid', deps.signal)
  if (!('run' in res) || res.run.exitCode !== 0) return undefined
  const oid = res.run.stdout.trim()
  return /^[0-9a-f]{40}$|^[0-9a-f]{64}$/.test(oid) ? oid : undefined
}

async function absoluteGitDir(deps: SnapshotDeps, root: string): Promise<string> {
  const res = await runCommand(deps.run, ['git', 'rev-parse', '--absolute-git-dir'], root, 'git-dir', deps.signal)
  if (!('run' in res) || res.run.exitCode !== 0) throw new Error('git dir unavailable')
  return res.run.stdout.trim()
}

/**
 * Raw blob bytes: `unpack-file` writes the object to a temp file (stdout is a
 * lossy utf8 decode and cannot carry binary), created in the git dir — which
 * must be the cwd so the temp file never shows up as an untracked worktree
 * entry. The printed name is charset-checked before it is joined and read.
 */
async function blobSide(deps: SnapshotDeps, gitDir: string, oid: string, cap: number): Promise<ImageSide> {
  const sizeRes = await runCommand(deps.run, ['git', 'cat-file', '-s', oid], gitDir, 'image-size', deps.signal)
  if (!('run' in sizeRes) || sizeRes.run.exitCode !== 0) return undefined
  const size = Number(sizeRes.run.stdout.trim())
  if (!Number.isFinite(size)) return undefined
  if (size > cap) return { tooLarge: true }
  const nameRes = await runCommand(deps.run, ['git', 'unpack-file', oid], gitDir, 'image-unpack', deps.signal)
  if (!('run' in nameRes) || nameRes.run.exitCode !== 0) return undefined
  const name = nameRes.run.stdout.trim()
  if (!/^[A-Za-z0-9._-]+$/.test(name)) return undefined
  const file = join(gitDir, name)
  try {
    const buf = await deps.fs.readFile(file)
    if (buf.length > cap) return { tooLarge: true }
    return { data: buf.toString('base64') }
  } catch {
    return undefined
  } finally {
    await deps.fs.remove(file).catch(() => {})
  }
}

/** The working-tree file (absent when deleted). A symlink whose realpath
 * escapes the repository root is refused, so an untrusted clone cannot point
 * `evil.png → ~/.ssh/id_rsa` and have its bytes base64'd into the image pane. */
async function worktreeSide(deps: SnapshotDeps, root: string, path: string, cap: number): Promise<ImageSide> {
  if (hasGitSegment(path)) return undefined
  try {
    const file = join(root, path)
    if ((await isInsideRoot(deps, root, file, true)) !== 'inside') return undefined
    const info = await deps.fs.stat(file)
    if (!info.isFile()) return undefined
    if (info.size > cap) return { tooLarge: true }
    const buf = await deps.fs.readFile(file)
    if (buf.length > cap) return { tooLarge: true }
    return { data: buf.toString('base64') }
  } catch {
    return undefined
  }
}

// ── file browser ─────────────────────────────────────────────────────────

/** Max entries returned for one directory listing (bounds RPC + render). */
const DIR_ENTRY_CAP = 2000

/**
 * List one working-tree directory, one level down. `.git` is skipped; the path
 * is validated (`isSafePath`) and its realpath is confirmed inside the root so
 * a symlinked subdirectory cannot escape. Entries are sorted dirs-first then by
 * name and capped at DIR_ENTRY_CAP.
 *
 * With the `packages` flag (and the config switch on) a directory project's
 * `src` skeleton is projected into source-root rows and directory entries
 * inside a source root carry their folded package chain; both are purely
 * additive, so a client that does not ask still gets the physical tree.
 */
async function queryDirList(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  root: string,
  q: Extract<GitQueryRequest['query'], { kind: 'dir-list' }>,
  isGitRepo: boolean,
): Promise<GitQueryResponse> {
  const requested = q.path
  if ((requested !== '' && !isSafePath(requested)) || hasGitSegment(requested)) return { ok: false, error: { code: 'invalid-path', message: requested } }
  // One spelling for the containment check, the joins, the source-root
  // conventions and the response: a doubly-slashed path would otherwise miss
  // every convention tail while the same directory reads back fine.
  const rel = requested.replace(/\/{2,}/g, '/').replace(/\/+$/, '')
  const dir = rel === '' ? root : join(root, rel)
  const inside = await isInsideRoot(deps, root, dir, true)
  if (inside === 'missing') return { ok: false, error: { code: 'file-not-found', message: rel } }
  if (inside === 'outside') return { ok: false, error: { code: 'invalid-path', message: rel } }
  let raw: ReadonlyArray<{ name: string; isDirectory: boolean }>
  try {
    raw = await deps.fs.readdir(dir)
  } catch (error) {
    return { ok: false, error: { code: 'git-error', message: error instanceof Error ? error.message : 'readdir failed' } }
  }
  const filtered = raw.filter((e) => e.name !== '.git')
  filtered.sort((a, b) => compareDirEntries({ name: a.name, dir: a.isDirectory }, { name: b.name, dir: b.isDirectory }))
  const truncated = filtered.length > DIR_ENTRY_CAP
  const slice = truncated ? filtered.slice(0, DIR_ENTRY_CAP) : filtered
  const ignored = isGitRepo ? await ignoredEntries(deps, root, rel, slice.map((e) => e.name)) : new Set<string>()
  let entries: DirEntry[] = await Promise.all(slice.map(async (e) => {
    const ignoreFlag = ignored.has(e.name) ? { ignored: true } : {}
    if (e.isDirectory) return { name: e.name, dir: true, ...ignoreFlag }
    let size: number | undefined
    try { size = (await deps.fs.stat(join(dir, e.name))).size } catch { size = undefined }
    return { name: e.name, dir: false, ...(size !== undefined ? { size } : {}), ...ignoreFlag }
  }))
  const packages = q.packages === true && config.compactPackages
  // A truncated parent listing already lost entries; projecting on top of it
  // could hide the `src` row while its replacement is incomplete.
  if (packages && !truncated) {
    const projected = await projectSourceTree(deps, root, dir, rel, entries, ignored, isGitRepo)
    if (projected !== null) entries = projected
  }
  if (packages) entries = await foldPackageChains(deps, root, rel, entries)
  return { ok: true, value: { kind: 'dir-list', path: rel, entries, truncated } }
}

/**
 * Replace the `src` entry of one listing with the source roots and other
 * children below it (`src/main/java`, `src/main/resources`, …), hiding the
 * Maven skeleton's two fixed levels. Null keeps the physical tree: `src`
 * holds a file, a source set does not read as directories only, no real
 * source root is projected, or the result would exceed the entry cap.
 */
async function projectSourceTree(
  deps: SnapshotDeps,
  root: string,
  dir: string,
  rel: string,
  entries: readonly DirEntry[],
  ignored: ReadonlySet<string>,
  isGitRepo: boolean,
): Promise<DirEntry[] | null> {
  // Inside a source root `src` is an ordinary package name, not the layout.
  if (sourceRootOf(rel) !== null) return null
  if (!entries.some((entry) => entry.name === 'src' && entry.dir)) return null
  // An ignored `src` is generated output (or explicitly excluded): leave it
  // where Git's own view puts it.
  if (isGitRepo && ignored.has('src')) return null
  const srcDir = join(dir, 'src')
  if ((await isInsideRoot(deps, root, srcDir, true)) !== 'inside') return null
  let srcRaw: ReadonlyArray<{ name: string; isDirectory: boolean }>
  try {
    srcRaw = await deps.fs.readdir(srcDir)
  } catch {
    return null
  }
  const srcChildren = srcRaw.filter((entry) => !hasGitSegment(entry.name))
  // A file directly under `src` (a script, a manifest) has no source-root
  // home; keeping the physical tree is the only lossless answer.
  if (srcChildren.some((entry) => !entry.isDirectory)) return null
  const setChildren = new Map<string, readonly string[]>()
  for (const set of SOURCE_SETS) {
    if (!srcChildren.some((entry) => entry.name === set)) continue
    const setDir = join(srcDir, set)
    if ((await isInsideRoot(deps, root, setDir, true)) !== 'inside') return null
    let children: ReadonlyArray<{ name: string; isDirectory: boolean }>
    try {
      children = await deps.fs.readdir(setDir)
    } catch {
      return null
    }
    const visible = children.filter((entry) => !hasGitSegment(entry.name))
    // Same rule one level down, so a file under `src/main` is never hidden
    // behind a projected subdirectory.
    if (visible.some((entry) => !entry.isDirectory)) return null
    setChildren.set(set, visible.map((entry) => entry.name))
  }
  const projected = projectSourceRoots(srcChildren.map((entry) => entry.name), setChildren)
  if (projected === null) return null
  // A projected row can itself be excluded (`src/main/resources` is generated
  // in many projects); ask Git once for the whole page, like the parent
  // listing does, so the ignore state is not lost at this level.
  const ignoredProjected = isGitRepo ? await ignoredEntries(deps, root, rel, projected) : new Set<string>()
  const rows: DirEntry[] = projected.map((name) => ({
    name,
    dir: true,
    ...(sourceRootOf(name) === name ? { sourceRoot: true as const } : {}),
    ...(ignoredProjected.has(name) ? { ignored: true as const } : {}),
  }))
  const merged = [...entries.filter((entry) => entry.name !== 'src'), ...rows]
  if (merged.length > DIR_ENTRY_CAP) return null
  // The listing contract is dirs-first; a bare name sort would interleave
  // `pom.xml` between the projected source roots.
  merged.sort(compareDirEntries)
  return merged
}

/** The ordering every listing renders: directories first, then by name. */
function compareDirEntries(a: { readonly name: string; readonly dir: boolean }, b: { readonly name: string; readonly dir: boolean }): number {
  if (a.dir !== b.dir) return a.dir ? -1 : 1
  return a.name.localeCompare(b.name)
}

/**
 * Fold each directory entry below a source root through a run of single-child
 * package directories. The walk is bounded in segments, directory reads and
 * wall-clock time; the cap is shared by every row in this listing, so a wide
 * source root costs one listing's worth of reads. A run that stops at the cap
 * still names a real directory, so the client can expand it.
 */
async function foldPackageChains(
  deps: SnapshotDeps,
  root: string,
  rel: string,
  entries: DirEntry[],
): Promise<DirEntry[]> {
  if (sourceRootOf(rel) === null) return entries
  const deadline = Date.now() + PACKAGE_DEADLINE_MS
  const budget = { reads: 0 }
  return Promise.all(entries.map(async (entry) => {
    if (!entry.dir || !isPackageSegment(entry.name)) return entry
    const chain = await packageChain(deps, root, rel, entry.name, deadline, budget)
    return chain === null ? entry : { ...entry, chain }
  }))
}

async function packageChain(
  deps: SnapshotDeps,
  root: string,
  parentRel: string,
  name: string,
  deadline: number,
  budget: { reads: number },
): Promise<{ path: string; label: string } | null> {
  const segments = [name]
  let target = parentRel === '' ? name : `${parentRel}/${name}`
  while (segments.length < MAX_PACKAGE_SEGMENTS) {
    if (budget.reads >= MAX_PACKAGE_READS || Date.now() > deadline) break
    // Reserve the slot before the first await: every row in this listing walks
    // concurrently, and reserving afterwards would let all of them pass the
    // guard and exceed the shared budget.
    budget.reads += 1
    // The entry came from a listing of the same root, but each hop is a new
    // realpath decision: a symlinked package directory must not extend the
    // chain outside the work tree.
    const resolved = await resolveInsideRoot(deps, root, join(root, target), true)
    if (resolved.state !== 'inside') break
    let raw: ReadonlyArray<{ name: string; isDirectory: boolean }>
    try {
      raw = await deps.fs.readdir(resolved.real)
    } catch {
      break
    }
    const children = raw.filter((entry) => entry.name !== '.git')
    // Only a single directory can be folded; one file, several siblings or a
    // non-identifier name ends the run at a real, inspectable directory.
    if (children.length !== 1) break
    const only = children[0]
    if (!only.isDirectory || !isPackageSegment(only.name)) break
    segments.push(only.name)
    target = `${target}/${only.name}`
  }
  return segments.length > 1 ? { path: target, label: segments.join('.') } : null
}

/** Check only the visible directory page; Git handles nested and negated rules. */
async function ignoredEntries(deps: SnapshotDeps, root: string, parent: string, names: readonly string[]): Promise<Set<string>> {
  const ignored = new Set<string>()
  const paths = names.map((name) => parent === '' ? name : `${parent}/${name}`)
  // Bound each argv batch by both count and bytes (especially for deep paths).
  for (let index = 0; index < paths.length;) {
    const batch: string[] = []
    let bytes = 0
    while (index < paths.length && batch.length < 128) {
      const candidate = paths[index]
      const size = Buffer.byteLength(candidate) + 1
      if (batch.length > 0 && bytes + size > 32 * 1024) break
      batch.push(candidate)
      bytes += size
      index++
    }
    const result = await runCommand(deps.run, ['git', 'check-ignore', '-z', '--stdin'], root, 'dir-ignore', deps.signal, `${batch.join('\0')}\0`)
    if ('failure' in result || result.run.timedOut || result.run.cancelled || result.run.stdoutLossy || ![0, 1].includes(result.run.exitCode ?? -1)) continue
    const matches = new Set(result.run.stdout.split('\0'))
    for (const path of batch) if (matches.has(path)) ignored.add(parent === '' ? path : path.slice(parent.length + 1))
  }
  return ignored
}

/**
 * Read one working-tree file for preview. Images (by extension) return a base64
 * data URL; otherwise a UTF-8/binary probe decides between a text body and a
 * bare binary marker. Text reads floor at the copy envelope; an SVG — markup as
 * well as picture — uses the same floor and above the image cap is served as
 * source instead of a data URL. Over the byte cap → `tooLarge`. Path is
 * validated and confirmed inside the root (symlink-guarded) before any read.
 */
async function queryFileContent(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  root: string,
  q: Extract<GitQueryRequest['query'], { kind: 'file-content' }>,
): Promise<GitQueryResponse> {
  if (!isSafePath(q.path) || hasGitSegment(q.path)) return { ok: false, error: { code: 'invalid-path', message: q.path } }
  const file = join(root, q.path)
  const inside = await isInsideRoot(deps, root, file, true)
  // A gone file is a real state (the tree still lists it), not a bad path:
  // report it separately so the preview can say the file no longer exists.
  if (inside === 'missing') return { ok: false, error: { code: 'file-not-found', message: q.path } }
  if (inside === 'outside') return { ok: false, error: { code: 'invalid-path', message: q.path } }
  let info: { size: number; mtimeMs: number }
  try {
    info = await deps.fs.stat(file)
  } catch (error) {
    return { ok: false, error: { code: isMissingPath(error) ? 'file-not-found' : 'git-error', message: error instanceof Error ? error.message : 'stat failed' } }
  }
  const mime = imageMimeFor(q.path)
  // An SVG is markup, so it is copyable content like any document: it floors at
  // the copy envelope too, and only the data URL is held to config.maxBytes.
  // Every other image keeps config.maxBytes as its whole cap.
  const isSvg = mime === SVG_MIME
  const cap = mime === null || isSvg ? Math.max(config.maxBytes, FILE_COPY_MAX_BYTES) : config.maxBytes
  // Same over-cap response whether the size trips at stat or after read (the
  // post-read length guards a grow-during-read race). size/mtimeMs ride along
  // on every variant (incl. tooLarge) — the properties dialog needs them and
  // the stat has already run.
  const statFields = { size: info.size, mtimeMs: Math.round(info.mtimeMs) }
  const tooLargeOf = async (): Promise<GitQueryResponse> => ({ ok: true, value: {
    kind: 'file-content', path: q.path, variant: mime !== null ? 'image' : 'text', tooLarge: true, ...statFields,
    ...(mime === null ? await editFieldsFor(deps, config, file, q.path, null) : {}),
  } })
  if (info.size > cap) return tooLargeOf()
  let buf: Buffer
  try {
    buf = await deps.fs.readFile(file)
  } catch (error) {
    return { ok: false, error: { code: isMissingPath(error) ? 'file-not-found' : 'git-error', message: error instanceof Error ? error.message : 'read failed' } }
  }
  if (buf.length > cap) return tooLargeOf()
  if (mime !== null) {
    // An SVG is a picture and also markup, so this one read answers both faces
    // of its preview; bytes that are not text leave it image-only.
    const source = isSvg && !isBinaryBuffer(buf) ? buf.toString('utf8') : undefined
    // Past the image cap a picture is not worth base64-inlining into the
    // response — but an SVG's markup is still readable and copyable, so it
    // degrades to the source face instead of failing the preview outright.
    if (isSvg && buf.length > config.maxBytes) {
      if (source === undefined) return tooLargeOf()
      return { ok: true, value: {
        kind: 'file-content', path: q.path, variant: 'text',
        content: source, lines: countLines(source), absolutePath: file,
        ...statFields,
      } }
    }
    return { ok: true, value: {
      kind: 'file-content', path: q.path, variant: 'image',
      dataUrl: `data:${mime};base64,${buf.toString('base64')}`,
      ...(source === undefined ? {} : { content: source, lines: countLines(source) }),
      ...statFields,
    } }
  }
  if (isBinaryBuffer(buf)) return { ok: true, value: { kind: 'file-content', path: q.path, variant: 'binary', ...statFields } }
  const content = buf.toString('utf8')
  const lines = countLines(content)
  // `absolutePath` feeds the client's Markdown image resolver: relative image
  // destinations join beside the document, so the document's own absolute
  // path is the one fact the browser cannot derive from the relative tree.
  const editFields = await editFieldsFor(deps, config, file, q.path, buf)
  return { ok: true, value: { kind: 'file-content', path: q.path, variant: 'text', content, lines, absolutePath: file, ...statFields, ...editFields } }
}

/**
 * Edit facts for one text read: present only while editing is enabled and both
 * the requested name and the realpath's name are on the allow-list (a link
 * `notes.md -> run.sh` must not open a script for editing). `buf` null = the
 * file was over the read cap and never read.
 */
export async function editFieldsFor(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  file: string,
  rel: string,
  buf: Buffer | null,
): Promise<{ sha256?: string; edit?: FileEditInfo }> {
  if (!config.allowFileEdit || !isEditablePath(rel)) return {}
  let real: string
  try { real = await deps.fs.realpath(file) } catch { return {} }
  if (!isEditablePath(real)) return {}
  if (buf === null || buf.length > EDIT_MAX_BYTES) return { edit: { ok: false, reason: 'too-large' } }
  const sha256 = sha256Hex(buf)
  const edit = editInfo(buf)
  if (edit.ok && !(await deps.fs.writable(real))) return { sha256, edit: { ok: false, reason: 'read-only' } }
  return { sha256, edit }
}

/** Do not expose Git metadata even through an explicit RPC path. */
export function hasGitSegment(path: string): boolean {
  // Case-insensitive: a case-insensitive file system serves `.git` for `.GIT`
  // and realpath keeps the spelling it was given, so an exact compare would
  // leave `.GIT/config` readable.
  return path.split(/[\\/]/).some((segment) => segment.toLowerCase() === '.git')
}

/** Whether a path resolves inside the browse root, outside its .git tree, or
 * is absent (a deleted entry still listed by a stale tree). */
export type PathState = 'inside' | 'outside' | 'missing'

function isMissingPath(error: unknown): boolean {
  return (error as NodeJS.ErrnoException | null)?.code === 'ENOENT'
}

/**
 * Where `path` sits relative to `root` after symlinks are followed: the one
 * containment check shared by every endpoint that touches a browsable file.
 */
export async function isInsideRoot(deps: SnapshotDeps, root: string, path: string, hideGit = false): Promise<PathState> {
  return (await resolveInsideRoot(deps, root, path, hideGit)).state
}

/** `isInsideRoot` plus the realpath it checked (set only when `inside`), so a
 * caller that goes on to touch the file uses exactly the path that passed. */
export async function resolveInsideRoot(
  deps: SnapshotDeps, root: string, path: string, hideGit = false,
): Promise<{ state: 'inside'; real: string } | { state: 'outside' | 'missing' }> {
  try {
    const real = await deps.fs.realpath(path)
    const rootReal = await deps.fs.realpath(root)
    if (real !== rootReal && !real.startsWith(rootReal + sep)) return { state: 'outside' }
    return !hideGit || !hasGitSegment(real.slice(rootReal.length + 1)) ? { state: 'inside', real } : { state: 'outside' }
  } catch (error) {
    return { state: isMissingPath(error) ? 'missing' : 'outside' }
  }
}

/** Heuristic binary probe: a NUL byte in the first 8KB marks non-text. */
function isBinaryBuffer(buf: Buffer): boolean {
  const n = Math.min(buf.length, 8192)
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true
  return false
}

async function queryShow(deps: SnapshotDeps, root: string, ref: string): Promise<GitQueryResponse> {
  if (!isSafeRev(ref)) return { ok: false, error: { code: 'invalid-name', message: `unsafe ref: ${ref}` } }
  // hash / short / subject / author / date / body — body last so a bounded
  // split folds any stray 0x1f (crafted subject/metadata) back into the body,
  // keeping the five leading fields aligned.
  const metaFormat = '--format=%H%x1f%h%x1f%s%x1f%an%x1f%aI%x1f%b'
  // `^{commit}` peels an annotated tag to the commit it names; without it `-s`
  // prints the tag header first and the hash field carries that text instead.
  const spec = `${ref}^{commit}`
  const [metaRes, statRes, numstatRes] = await Promise.all([
    runCommand(deps.run, ['git', 'show', '-s', metaFormat, '--end-of-options', spec], root, 'show-meta', deps.signal),
    runCommand(deps.run, ['git', 'show', FIRST_PARENT_DIFF, '--name-status', '-z', '--format=', '--end-of-options', spec], root, 'show-stat', deps.signal),
    runCommand(deps.run, ['git', 'show', FIRST_PARENT_DIFF, '--numstat', '--format=', '--end-of-options', spec], root, 'show-numstat', deps.signal),
  ])
  if (!('run' in metaRes)) return { ok: false, error: { code: 'git-unavailable' } }
  if (metaRes.run.cancelled) return { ok: false, error: { code: 'cancelled' } }
  if (metaRes.run.timedOut) return { ok: false, error: { code: 'timeout' } }
  if (metaRes.run.exitCode !== 0) {
    return { ok: false, error: { code: 'git-error', message: metaRes.run.stderr.trim() || 'unknown ref' } }
  }
  const parts = metaRes.run.stdout.split('\x1f')
  const commit = commitFromFields(parts)
  const body = commit === null ? '' : parts.slice(5).join('\x1f').trim()
  // A lossy read keeps the stream's tail: the file list lost its head (so the
  // first record is a fragment) and the +/- totals lost whole rows. Report the
  // numbers as partial instead of presenting either half as the commit's scope.
  const statLossy = 'run' in statRes && statRes.run.stdoutLossy
  const numstatLossy = 'run' in numstatRes && numstatRes.run.stdoutLossy
  const truncated = statLossy || numstatLossy
  const stats: GitFileStat[] = 'run' in statRes && statRes.run.exitCode === 0 && !statLossy
    ? parseNameStatus(statRes.run.stdout)
    : []
  // Line totals come from the same first-parent diff as the file list (the
  // flag above pins `--numstat`, which already defaulted to first-parent for
  // merges), so the summary can never pair one diff's file count with another
  // diff's +/-. Binary rows ("-") are skipped by sumNumstat.
  const { insertions, deletions } = stats.length > 0 && 'run' in numstatRes && numstatRes.run.exitCode === 0 && !numstatLossy
    ? sumNumstat(numstatRes.run.stdout)
    : { insertions: 0, deletions: 0 }
  return { ok: true, value: { kind: 'show', ref, commit, body, stats, insertions, deletions, ...(truncated ? { truncated: true as const } : {}) } }
}

async function queryBranches(deps: SnapshotDeps, root: string): Promise<GitQueryResponse> {
  // The full ref rides along: the short name is ambiguous for a branch and tag
  // that share a name, and a remote-tracking HEAD spells as its remote.
  // `%(symref)` is non-empty exactly for those symbolic rows, which the parser
  // drops — filtering by a `/HEAD` name suffix would also hide a real branch
  // that happens to end in `/HEAD`.
  const fmt = '--format=%(refname:short)%00%(objectname:short)%00%(upstream:track)%00%(refname)%00%(symref)'
  const [localRes, remoteRes, currentRes, defaultRes] = await Promise.all([
    runCommand(deps.run, ['git', 'for-each-ref', '--sort=-committerdate', fmt, 'refs/heads'], root, 'branches-local', deps.signal),
    runCommand(deps.run, ['git', 'for-each-ref', '--sort=-committerdate', fmt, 'refs/remotes'], root, 'branches-remote', deps.signal),
    runCommand(deps.run, ['git', 'symbolic-ref', '--quiet', '--short', 'HEAD'], root, 'branch-current', deps.signal),
    runCommand(deps.run, ['git', 'symbolic-ref', '--quiet', '--short', 'refs/remotes/origin/HEAD'], root, 'branch-default', deps.signal),
  ])
  const local: GitBranch[] = 'run' in localRes && localRes.run.exitCode === 0 ? parseBranches(localRes.run.stdout) : []
  const remote: GitBranch[] = 'run' in remoteRes && remoteRes.run.exitCode === 0
    ? parseBranches(remoteRes.run.stdout)
    : []
  const current = 'run' in currentRes && currentRes.run.exitCode === 0 ? currentRes.run.stdout.trim() || null : null
  let defaultBranch: string | null = null
  if ('run' in defaultRes && defaultRes.run.exitCode === 0) {
    const raw = defaultRes.run.stdout.trim()
    defaultBranch = raw.replace(/^origin\//, '') || null
  }
  return { ok: true, value: { kind: 'branches', current, defaultBranch, local, remote } }
}

async function queryTags(deps: SnapshotDeps, root: string): Promise<GitQueryResponse> {
  const res = await runCommand(deps.run, ['git', 'for-each-ref', '--sort=-creatordate', '--format=%(refname:short)%00%(objectname:short)%00%(refname)', 'refs/tags'], root, 'tags', deps.signal)
  const tags: GitBranch[] = 'run' in res && res.run.exitCode === 0 ? parseTags(res.run.stdout) : []
  return { ok: true, value: { kind: 'tags', tags } }
}

async function queryStashList(deps: SnapshotDeps, root: string): Promise<GitQueryResponse> {
  // `git stash list` is `git log -g refs/stash`; a custom format with -z gives
  // NUL-separated records of selector / reflog-subject / relative-time, which
  // parseStashList turns into { index, message, branch, relTime }. No stash
  // ref (never stashed) exits non-zero → an empty list, not an error.
  const res = await runCommand(deps.run, ['git', 'stash', 'list', '-z', '--format=%gd%x1f%H%x1f%gs%x1f%cr'], root, 'stash-list', deps.signal)
  const entries: StashEntry[] = 'run' in res && res.run.exitCode === 0 ? parseStashList(res.run.stdout) : []
  return { ok: true, value: { kind: 'stash-list', entries } }
}

async function queryAuthors(deps: SnapshotDeps, root: string): Promise<GitQueryResponse> {
  // Same refset as the history graph so an author picked from this list can
  // never point the graph at a chain it does not display (and vice versa).
  const res = await runCommand(deps.run, ['git', 'log', ...VISIBLE_REFS, '--format=%an', '--max-count=2000'], root, 'authors', deps.signal)
  const authors = 'run' in res && res.run.exitCode === 0
    ? [...new Set(res.run.stdout.split('\n').map((s) => s.trim()).filter((s) => s !== ''))].sort((a, b) => a.localeCompare(b))
    : []
  return { ok: true, value: { kind: 'authors', authors } }
}

async function queryLastCommitMessage(deps: SnapshotDeps, root: string): Promise<GitQueryResponse> {
  const res = await runCommand(deps.run, ['git', 'log', '-1', '--format=%B'], root, 'last-message', deps.signal)
  const message = 'run' in res && res.run.exitCode === 0 ? res.run.stdout.replace(/\n+$/, '') : ''
  return { ok: true, value: { kind: 'last-commit-message', message } }
}

/**
 * Preview the incoming fast-forward: commits + diffstat between HEAD and its
 * upstream. All local (the objects are already fetched once `behind > 0`), so
 * it never touches the network. A branch without an upstream reports
 * `hasUpstream:false` with zeroed counts; the `@{upstream}` token is a fixed
 * literal (never user input), kept an operand with `--end-of-options`.
 */
async function queryPullPreview(deps: SnapshotDeps, root: string): Promise<GitQueryResponse> {
  const empty = { kind: 'pull-preview', hasUpstream: false, commits: 0, files: 0, insertions: 0, deletions: 0 } as const
  const commitsRes = await runCommand(deps.run, ['git', 'rev-list', '--count', '--end-of-options', 'HEAD..@{upstream}', '--'], root, 'pull-preview-count', deps.signal)
  // A non-zero exit means no upstream (or unborn): report "no upstream".
  if (!('run' in commitsRes) || commitsRes.run.exitCode !== 0) return { ok: true, value: empty }
  const commits = Number(commitsRes.run.stdout.trim()) || 0
  const diffRes = await runCommand(deps.run, ['git', 'diff', '--numstat', '--end-of-options', 'HEAD', '@{upstream}', '--'], root, 'pull-preview-diff', deps.signal)
  // A failed diffstat must not read as "0 files": the preview would claim an
  // empty change set that was never measured (a path named like a rev is the
  // way in — the trailing `--` now keeps revisions operands).
  if (!('run' in diffRes)) return { ok: false, error: { code: 'git-unavailable' } }
  if (diffRes.run.exitCode !== 0) {
    return { ok: false, error: { code: 'git-error', message: diffRes.run.stderr.trim() || 'diffstat failed' } }
  }
  const files = diffRes.run.stdout.split('\n').filter((l) => l.trim() !== '').length
  const { insertions, deletions } = sumNumstat(diffRes.run.stdout)
  return { ok: true, value: { kind: 'pull-preview', hasUpstream: true, commits, files, insertions, deletions } }
}

async function queryPushPreview(deps: SnapshotDeps, root: string): Promise<GitQueryResponse> {
  const empty = { kind: 'push-preview', hasUpstream: false, commits: 0, files: 0, insertions: 0, deletions: 0 } as const
  // Outgoing range is the mirror of pull-preview: commits on HEAD not yet on the
  // upstream. A non-zero exit means no upstream (or unborn) → "no upstream".
  const commitsRes = await runCommand(deps.run, ['git', 'rev-list', '--count', '--end-of-options', '@{upstream}..HEAD', '--'], root, 'push-preview-count', deps.signal)
  if (!('run' in commitsRes) || commitsRes.run.exitCode !== 0) return { ok: true, value: empty }
  const commits = Number(commitsRes.run.stdout.trim()) || 0
  const diffRes = await runCommand(deps.run, ['git', 'diff', '--numstat', '--end-of-options', '@{upstream}', 'HEAD', '--'], root, 'push-preview-diff', deps.signal)
  // A failed diffstat must not read as "0 files": the preview would claim an
  // empty change set that was never measured (a path named like a rev is the
  // way in — the trailing `--` now keeps revisions operands).
  if (!('run' in diffRes)) return { ok: false, error: { code: 'git-unavailable' } }
  if (diffRes.run.exitCode !== 0) {
    return { ok: false, error: { code: 'git-error', message: diffRes.run.stderr.trim() || 'diffstat failed' } }
  }
  const files = diffRes.run.stdout.split('\n').filter((l) => l.trim() !== '').length
  const { insertions, deletions } = sumNumstat(diffRes.run.stdout)
  return { ok: true, value: { kind: 'push-preview', hasUpstream: true, commits, files, insertions, deletions } }
}

async function queryWorktreeStats(
  deps: SnapshotDeps,
  config: GitPanelConfig,
  sessionId: string,
  repo: string | undefined,
): Promise<GitQueryResponse> {
  // The worktree stats now live on the snapshot (single source of git spawns);
  // this endpoint just reads them so a bare stats request stays cheap.
  const snapshot = await snapshotForSession(deps, config, sessionId, { repo })
  if (!snapshot.ok) return { ok: false, error: { code: 'git-error', message: 'snapshot failed' } }
  return { ok: true, value: { kind: 'worktree-stats', stats: snapshot.value.stats } }
}

/**
 * Aggregate ctx.llm providers / models / reasoning metadata for the config
 * form. Each provider and model lookup is isolated into `failures` so one
 * broken adapter never blanks the whole catalog; providers run in parallel
 * because `listModels` / `resolveModelInfo` may be remote-backed, while the
 * input order is kept for a stable listing.
 *
 * The host `LlmRuntime` implements catalog methods with `this.registration(...)`,
 * so bind the service as receiver before detaching — an unbound call throws
 * on every provider and blanks the catalog.
 */
async function queryModelCatalog(deps: SnapshotDeps): Promise<GitQueryResponse> {
  const llm = deps.getLlm?.()
  const empty = { kind: 'model-catalog' as const, groups: [], failures: [] }
  if (llm === undefined || typeof llm.listModels !== 'function') {
    return { ok: true, value: empty }
  }
  const listModels = llm.listModels.bind(llm)
  const resolveModelInfo = typeof llm.resolveModelInfo === 'function' ? llm.resolveModelInfo.bind(llm) : undefined
  const providers = llm.listProviders?.() ?? []
  const results = await Promise.all(providers.map(async (provider): Promise<ModelCatalogGroup | ModelCatalogFailure | null> => {
    const name = provider.name ?? provider.id
    let listed: readonly { readonly id: string; readonly name?: string }[]
    try {
      listed = await listModels(provider.id)
    } catch (error) {
      return { id: provider.id, name, message: error instanceof Error ? error.message : String(error) }
    }
    const models: ModelCatalogModel[] = await Promise.all(listed.map(async (model): Promise<ModelCatalogModel> => {
      const entry: ModelCatalogModel = { id: model.id, name: model.name ?? model.id }
      if (resolveModelInfo === undefined) return entry
      try {
        const info = await resolveModelInfo(provider.id, model.id, deps.signal)
        const reasoning = info.reasoning
        if (reasoning !== undefined && reasoning.efforts.length > 0) {
          return {
            ...entry,
            reasoning: {
              efforts: reasoning.efforts.map((effort) => ({ id: effort.id, name: effort.name })),
            },
          }
        }
      } catch {
        // Metadata is advisory; the model still appears without efforts.
      }
      return entry
    }))
    // A provider that lists zero models is dropped entirely, not a failure.
    if (models.length === 0) return null
    return { id: provider.id, name, models }
  }))
  const groups: ModelCatalogGroup[] = []
  const failures: ModelCatalogFailure[] = []
  for (const one of results) {
    if (one === null) continue
    if ('models' in one) groups.push(one)
    else failures.push(one)
  }
  return { ok: true, value: { kind: 'model-catalog', groups, failures } }
}
