/**
 * dsh-git-panel host half: Cordis + typert Remote service.
 *
 * `GitPanelService` binds the `gitPanel` namespace and exposes three @Remote
 * endpoints (snapshot / run / query) that delegate to the framework-neutral
 * command layer. Host services (subprocess / sessions / sessionPersistence)
 * are adapted into a structural `SnapshotDeps` face.
 */
import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import type { Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
import { readFile, readdir, realpath, rm, stat } from 'node:fs/promises'
import { createGitRunner, type SubprocessLike } from './git.ts'
import { normalizeConfig, snapshotForSession, type GitPanelConfig, type SnapshotDeps } from './core.ts'
import { runAction } from './actions.ts'
import { runQuery } from './queries.ts'
import { runSuggest } from './suggest.ts'
import type { AgentDefaultModelFace, LlmFace } from './llm-face.ts'
import { checkLatestVersion, readVersionInfo } from './version.ts'
import type { GitActionRequest, GitActionResult, GitQueryRequest, GitQueryResponse, GitSnapshotRequest, GitSnapshotResult, GitSuggestRequest, GitSuggestResult, GitVersionInfo, GitVersionRequest } from './types.ts'

export type {
  GitSnapshot, GitSnapshotResult, GitSnapshotRequest, GitFailure, GitCommit, GraphCommit, GitRef,
  GitChange, GitChangeStatus, GitAction, GitActionRequest, GitActionResult, GitErrorCode,
  GitQuery, GitQueryRequest, GitQueryResponse, GitQueryResult, GitBranch, GitFileStat, WorktreeStats, StashEntry,
  GitVersionRequest, GitVersionInfo, DiffViewMode, GraphStyle, DirEntry, ResetMode,
  GitSuggestRequest, GitSuggestResult, GitRemote, RemoteHostKind,
} from './types.ts'
export { normalizeConfig, DEFAULT_CONFIG, snapshotForSession, resolveWorkspace, parsePrimaryRemote } from './core.ts'
export { createGitRunner } from './git.ts'
export { parseStatus, parseGraphLog, parseBranches, parseNameStatus, parseStashList, parseTags, sumNumstat } from './parser.ts'
export { parseRemote, classifyHost } from './remote.ts'
export { isSafePath, planAction, runAction, classifyActionFailure } from './actions.ts'
export { runQuery } from './queries.ts'
export { runSuggest } from './suggest.ts'
export { readVersionInfo, checkLatestVersion, compareVersions, parseRepository } from './version.ts'

/** Structural slice of the Cordis sessions store (live cwd). */
interface SessionsService {
  get(id: string): { readonly header?: { readonly cwd?: string } } | undefined
}

/** Structural slice of the sessionPersistence service (persisted cwd). */
interface SessionPersistenceLike {
  stat(id: string): Promise<{ readonly header?: { readonly cwd?: string } } | undefined>
}

export class GitPanelService extends TypertRemoteService {
  static inject = ['subprocess', 'sessions', 'sessionPersistence']

  /**
   * Config schema surfaced on the plugin detail page. `showInputPill` and
   * `defaultDiffView` are `.volatile()`, so the settings host renders them as
   * live-editable controls; the operational limits stay profile-only and out
   * of the UI form.
   */
  static Config = Schema.object({
    showInputPill: Schema.boolean().default(true).volatile().description('显示输入框的 Git 分支标记'),
    defaultDiffView: Schema.union([
      Schema.const('unified').description('统一视图（单栏行内对比）'),
      Schema.const('split').description('并排视图（左右分栏对比）'),
    ]).default('unified').volatile().description('差异对比默认视图'),
    graphStyle: Schema.union([
      Schema.const('parallel').description('平行线（VSCode 风格，分支各占一列）'),
      Schema.const('compact').description('紧凑（git log 风格，共享祖先合并为一列）'),
    ]).default('parallel').volatile().description('提交历史图线条样式'),
    suggestEnabled: Schema.boolean().default(true).volatile().description('提交框显示 AI 生成按钮'),
  })

  private readonly deps: SnapshotDeps
  private config: GitPanelConfig
  private readonly rawConfig: unknown

  constructor(ctx: Context, config: unknown) {
    super(ctx, 'gitPanel')
    this.rawConfig = config
    this.config = normalizeConfig(config)
    this.deps = this.buildDeps(ctx, this.config)
  }

  private buildDeps(ctx: Context, config: GitPanelConfig): SnapshotDeps {
    const rootCache = new Map<string, string>()
    const rootNegCache = new Map<string, number>()
    const get = (key: string): unknown => (ctx as unknown as { get(k: string): unknown }).get(key)
    const fs: SnapshotDeps['fs'] = {
      realpath, stat: async (p) => stat(p), readFile,
      readdir: async (p) => (await readdir(p, { withFileTypes: true })).map((e) => ({ name: e.name, isDirectory: e.isDirectory() })),
      remove: async (p) => { await rm(p, { force: true }) },
    }
    // `static inject` gates activation on subprocess, so it is always present
    // here; the runner throws only if a future refactor drops that guard.
    const subprocess = get('subprocess') as SubprocessLike | undefined
    const run = subprocess === undefined
      ? { run: async (): Promise<never> => { throw new Error('subprocess service unavailable') } }
      : createGitRunner(subprocess, config.timeoutMs, config.maxBytes)
    const sessions = get('sessions') as SessionsService | undefined
    const persistence = get('sessionPersistence') as SessionPersistenceLike | undefined
    return {
      run,
      fs,
      sessions: {
        liveCwd: (id) => sessions?.get(id)?.header?.cwd,
        persistedMeta: async (id) => {
          if (persistence === undefined) return undefined
          try {
            const snap = await persistence.stat(id)
            return snap?.header?.cwd === undefined ? undefined : { cwd: snap.header.cwd }
          } catch {
            return undefined
          }
        },
      },
      rootCache,
      rootNegCache,
      // Optional model services, resolved per request so a provider fiber that
      // activates late or restarts is picked up — absent in deployments without
      // a model backend, where the suggest endpoint reports `llm-unavailable`
      // rather than failing activation (kept out of `static inject` on purpose).
      getLlm: () => get('llm') as LlmFace | undefined,
      getAgentDefaultModel: () => get('agentDefaultModel') as AgentDefaultModelFace | undefined,
    }
  }

  @Remote('snapshot')
  async snapshot(request: GitSnapshotRequest, signal?: AbortSignal): Promise<GitSnapshotResult> {
    return snapshotForSession(this.withSignal(signal), this.liveConfig(), request.sessionId)
  }

  @Remote('run')
  async run(request: GitActionRequest, signal?: AbortSignal): Promise<GitActionResult> {
    return runAction(this.withSignal(signal), this.liveConfig(), request)
  }

  @Remote('query')
  async query(request: GitQueryRequest, signal?: AbortSignal): Promise<GitQueryResponse> {
    return runQuery(this.withSignal(signal), this.liveConfig(), request)
  }

  @Remote('suggest')
  async suggest(request: GitSuggestRequest, signal?: AbortSignal): Promise<GitSuggestResult> {
    return runSuggest(this.withSignal(signal), this.liveConfig(), request)
  }

  @Remote('version')
  async version(request: GitVersionRequest): Promise<GitVersionInfo> {
    // The only endpoint that reads/parses package.json; a missing or corrupt
    // manifest must degrade to a typed value, not reject the RPC.
    try {
      return request.check === true ? await checkLatestVersion() : await readVersionInfo()
    } catch (error) {
      return { current: '0.0.0', updateAvailable: false, checkedRemote: false, error: error instanceof Error ? error.message : 'version unavailable' }
    }
  }

  /** Re-read config so a live-edited volatile field (showInputPill) is current. */
  private liveConfig(): GitPanelConfig {
    this.config = normalizeConfig(this.rawConfig)
    return this.config
  }

  private withSignal(signal?: AbortSignal): SnapshotDeps {
    if (signal === undefined) return this.deps
    return { ...this.deps, signal }
  }
}

export default GitPanelService
