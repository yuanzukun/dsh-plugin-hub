/**
 * Git command execution over the host subprocess service.
 *
 * Only a tiny slice of the subprocess contract is needed; it is declared
 * structurally here so the plugin builds standalone while staying wire
 * compatible with the host `subprocess` service.
 */
import { readFile } from 'node:fs/promises'

interface CollectDisposition {
  readonly collect: {
    readonly maxBytes: number
    readonly spill?: { readonly maxBytes: number }
  }
}

interface SpawnSpec {
  readonly argv: readonly string[]
  readonly cwd: string
  readonly stdio: {
    readonly stdin: 'ignore' | { readonly data: string }
    readonly stdout: CollectDisposition
    readonly stderr: CollectDisposition
  }
  readonly graceMs: number
  readonly signal?: AbortSignal
  /** Explicit child env entries merged onto the service's scrubbed base. */
  readonly env?: Readonly<Record<string, string | undefined>>
}

interface OutputRead {
  readonly text: string
  readonly lossy: boolean
  readonly spillPath?: string
}

interface SpawnHandle {
  readonly done: Promise<{ readonly exitCode: number | null; readonly signal: NodeJS.Signals | null }>
  readonly collected: {
    readonly stdout?: { readFrom(fromByte: number): OutputRead }
    readonly stderr?: { readFrom(fromByte: number): OutputRead }
  }
}

/** Minimal subprocess service face the adapter consumes. */
export interface SubprocessLike {
  spawn(spec: SpawnSpec): SpawnHandle
}

export interface GitRunResult {
  readonly exitCode: number | null
  readonly stdout: string
  readonly stderr: string
  readonly timedOut: boolean
  /** The caller's own signal aborted the run (navigation/reset), not our timeout. */
  readonly cancelled: boolean
  readonly stdoutLossy: boolean
}

export interface GitRunner {
  run(argv: readonly string[], opts: {
    readonly cwd: string
    readonly signal?: AbortSignal
    readonly stdinData?: string
    /** Extra child env entries, merged over the runner's own git env. */
    readonly env?: Readonly<Record<string, string | undefined>>
  }): Promise<GitRunResult>
}

/**
 * Adapt the subprocess service into a `GitRunner` with a per-command timeout.
 * A timed-out run resolves (never rejects) with `timedOut: true`; only
 * spawn-level failures (e.g. git not installed) reject.
 */
export function createGitRunner(subprocess: SubprocessLike, timeoutMs: number, maxBytes: number): GitRunner {
  const spillMaxBytes = maxBytes * 16
  return {
    async run(argv, opts) {
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), timeoutMs)
      try {
        const signal = opts.signal === undefined
          ? controller.signal
          : AbortSignal.any([controller.signal, opts.signal])
        const handle = subprocess.spawn({
          argv,
          cwd: opts.cwd,
          env: {
            // Never let a network command (fetch/pull) block on an interactive
            // credential or host-key prompt: with stdin ignored git would hang
            // until the timeout. GIT_TERMINAL_PROMPT=0 makes it fail fast instead,
            // and is harmless for the non-network commands that share this runner.
            GIT_TERMINAL_PROMPT: '0',
            // Read-only commands (`status`, `diff`) refresh the stat cache and
            // write `.git/index` behind an `index.lock`; a user or agent running
            // `git add` at that moment then fails on the lock. Optional locks off
            // keeps those refresh writes out of the index; commands that must
            // write it (add/commit/restore) take their own lock as usual.
            GIT_OPTIONAL_LOCKS: '0',
            // Path arguments are work-tree paths from git's own output, never
            // patterns: with pathspec expansion on, a name containing glob
            // metacharacters (`app/[id].tsx`) or magic (`:/`) also matches other
            // files, so a discard would rewrite them. Applied per command (see
            // usesLiteralPathspecs): commands that consume pathspecs themselves
            // (`check-ignore`, `stash -u`) reject or misread the literal flag.
            ...(usesLiteralPathspecs(argv) ? { GIT_LITERAL_PATHSPECS: '1' } : {}),
            ...opts.env,
          },
          stdio: {
            stdin: opts.stdinData === undefined ? 'ignore' : { data: opts.stdinData },
            stdout: { collect: { maxBytes, spill: { maxBytes: spillMaxBytes } } },
            stderr: { collect: { maxBytes, spill: { maxBytes: spillMaxBytes } } },
          },
          graceMs: 200,
          signal,
        })
        let outcome: Awaited<SpawnHandle['done']>
        try {
          outcome = await handle.done
        } catch (error) {
          const cancelled = opts.signal?.aborted === true && !controller.signal.aborted
          if (controller.signal.aborted || opts.signal?.aborted === true) {
            return { exitCode: null, stdout: '', stderr: '', timedOut: !cancelled, cancelled, stdoutLossy: false }
          }
          throw error
        }
        const stdout = handle.collected.stdout?.readFrom(0)
        const stderr = handle.collected.stderr?.readFrom(0)
        const resolved = await resolveStdout(stdout)
        // Distinguish our timeout from a caller-driven abort (navigation/reset):
        // the latter must not be surfaced as a `timeout` error state.
        const cancelled = opts.signal?.aborted === true && !controller.signal.aborted
        return {
          exitCode: outcome.exitCode,
          stdout: resolved.text,
          stderr: stderr?.text ?? '',
          timedOut: controller.signal.aborted,
          cancelled,
          stdoutLossy: resolved.lossy,
        }
      } finally {
        clearTimeout(timer)
      }
    },
  }
}

/**
 * Subcommands that receive a work-tree path list after `--` from this plugin.
 * Only for those does pathspec expansion have to be off (a name containing glob
 * metacharacters, `app/[id].tsx`, must not match other files), and the list is
 * the guard: `git check-ignore` and `git stash push` consume pathspecs
 * themselves and go fatal under `GIT_LITERAL_PATHSPECS`, so adding a `--` to
 * either must not turn the flag on for them. Subcommands absent here keep the
 * default expansion whatever their argv looks like; for a `--` that only ends
 * an option list (`log`, `rev-list`) that is a no-op either way.
 */
const LITERAL_PATHSPEC_COMMANDS: ReadonlySet<string> = new Set([
  'add', 'commit', 'checkout', 'diff', 'ls-files', 'reset', 'restore', 'rm', 'show', 'update-index',
])

function usesLiteralPathspecs(argv: readonly string[]): boolean {
  const command = argv[1]
  return command !== undefined && LITERAL_PATHSPEC_COMMANDS.has(command) && argv.includes('--')
}

/** Resolve stdout: the in-memory tail, or the spill file when the read was lossy. */
async function resolveStdout(read: OutputRead | undefined): Promise<{ text: string; lossy: boolean }> {
  if (read === undefined) return { text: '', lossy: false }
  if (!read.lossy || read.spillPath === undefined) return { text: read.text, lossy: read.lossy }
  try {
    return { text: await readFile(read.spillPath, 'utf8'), lossy: false }
  } catch {
    return { text: read.text, lossy: true }
  }
}
