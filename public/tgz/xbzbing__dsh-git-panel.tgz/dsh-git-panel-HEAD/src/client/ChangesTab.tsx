/**
 * Changes tab: stats bar + uncommitted change list (checkboxes) + commit box
 * (with Amend) on the left; the selected file's diff on the right.
 */
import { createElement as h, useEffect, useMemo, useRef, useState } from 'react'
import type { JSX } from 'react'
import { queryAs, type GitPanelRemote } from './rpc.js'
import { useChangesData } from './changes-hooks.js'
import { pageVisibility } from './visibility.js'
import { useGitQuerySignal } from './registry.js'
import type { GitAction, GitChange, GitErrorCode, GitSnapshot, StashEntry } from './types.js'
import type { GitKey } from './locales.js'
import { ChangeStats } from './ChangeStats.js'
import { DiffView, diffSummary, type DiffMode } from './DiffView.js'
import { ArrowLeftIcon, ChevronIcon, SparkleIcon, StashIcon, TrashIcon } from './icons.js'
import { statusChar, statusClass } from './status.js'
import { useResizableColumn } from './resizable.js'
import { segButtons } from './seg.js'
import { renderAiHint, renderConfirmModal, renderModalFooter, renderModalShell } from './ops-modals.js'
import { buildTops, windowRange } from './virtual-list.js'
import { useViewportTracker } from './use-viewport.js'
import { pickDiscardTargets } from './discard-targets.js'
import { DiscardPickedModal } from './DiscardPickedModal.js'
import { useHoverTip } from './tip.js'
import { ChangesToolbar } from './ChangesToolbar.js'
import { PushModal } from './PushModal.js'

interface ChangesTabProps {
  readonly remote: GitPanelRemote
  readonly sessionId: string
  readonly visible?: boolean
  readonly snapshot: GitSnapshot
  readonly onAction: (action: GitAction) => Promise<{ ok: boolean; error?: string }>
  readonly onRefresh: () => Promise<void>
  /** Compact (single-column drill-in) layout for a narrow panel. */
  readonly compact: boolean
  readonly t: (key: GitKey, params?: Record<string, string | number>) => string
}

type GroupKey = 'staged' | 'unstaged' | 'untracked'

// Change-list virtualization: only the rows in (or near) the viewport mount, so
// a work tree with thousands of changes (issue #16) renders ~a screenful of
// nodes instead of all of them. Heights are fixed per row kind so the window
// math is exact; the CSS pins .gp-file-row / .gp-group-head to these values.
const VROW_H = 28
const VHEAD_H = 26
const VOVERSCAN = 8
// Assumed viewport height before the first layout measurement, so the initial
// paint mounts a bounded window instead of the whole list.
const VIEWPORT_FALLBACK = 600

type ListItem =
  | { readonly kind: 'head'; readonly g: { key: GroupKey; labelKey: GitKey; count: number; collapsible: boolean } }
  | { readonly kind: 'row'; readonly c: GitChange }

export function ChangesTab({ remote, sessionId, visible = true, snapshot, onAction, onRefresh, compact, t }: ChangesTabProps): JSX.Element {
  const { queryVisible, queryKey } = useGitQuerySignal(sessionId, visible, snapshot.root)
  const [selected, setSelected] = useState<ReadonlySet<string>>(new Set())
  const [message, setMessage] = useState('')
  const [amend, setAmend] = useState(false)
  const [actionBusy, setBusy] = useState(false)
  const [pushOpen, setPushOpen] = useState(false)
  const [pushBusy, setPushBusy] = useState(false)
  const busy = actionBusy || pushBusy
  const [error, setError] = useState<string | null>(null)
  const [closed, setClosed] = useState<ReadonlySet<GroupKey>>(new Set())
  const [armedDiscard, setArmedDiscard] = useState<string | null>(null)
  const [discardPickedOpen, setDiscardPickedOpen] = useState(false)
  const { stashes, diffPath, diffData, expanded, showDiff } = useChangesData(
    remote, sessionId, snapshot, queryVisible, () => setError(t('error.generic')), queryKey,
  )
  const [diffMode, setDiffMode] = useState<DiffMode>(() => snapshot.defaultDiffView)
  const [amendPrefilled, setAmendPrefilled] = useState(false)
  const [suggesting, setSuggesting] = useState(false)
  const [armedSuggest, setArmedSuggest] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)
  // Compact drill-in: 'list' shows the change list + commit box, 'diff' the
  // selected file's diff. Ignored by the wide layout (both columns at once).
  const [pane, setPane] = useState<'list' | 'diff'>('list')
  // Stash stack (queried on demand), its collapse state, the push dialog, and
  // the drop-confirm target index.
  const [stashClosed, setStashClosed] = useState(true)
  const [stashPushOpen, setStashPushOpen] = useState(false)
  const [stashDrop, setStashDrop] = useState<StashEntry | null>(null)
  const msgRef = useRef<HTMLTextAreaElement | null>(null)
  // Virtualized change-list viewport, tracked by the shared hook (re-attaches
  // across the compact list↔diff remount).
  const { setEl: setListEl, viewport } = useViewportTracker()
  // Row action hints: the icon-only buttons explain themselves on hover, via the
  // shared fast tooltip (ported to body so the list's overflow cannot clip it).
  const { tipProps, tipNode, hideTip } = useHoverTip({ placement: 'above', maxWidth: 300 })

  const staged = useMemo(() => snapshot.changes.filter((c) => c.staged).sort(byPath), [snapshot])
  const unstaged = useMemo(() => snapshot.changes.filter((c) => !c.staged && c.status !== 'untracked').sort(byPath), [snapshot])
  const untracked = useMemo(() => snapshot.changes.filter((c) => c.status === 'untracked').sort(byPath), [snapshot])

  const allGroups: Array<{ key: GroupKey; labelKey: GitKey; items: GitChange[] }> = [
    { key: 'staged', labelKey: 'changes.groupStaged', items: staged },
    { key: 'unstaged', labelKey: 'changes.groupUnstaged', items: unstaged },
    { key: 'untracked', labelKey: 'changes.groupUntracked', items: untracked },
  ]
  // A capped list is only a prefix of the change set, but `stats` still counts
  // everything: keep a group visible (and its header honest) even when every one
  // of its rows fell past the cap. The record is exhaustive over GroupKey so a
  // future group cannot silently inherit another group's count.
  const counts: Record<GroupKey, number> = {
    staged: snapshot.stats.staged,
    unstaged: snapshot.stats.modified,
    untracked: snapshot.stats.untracked,
  }
  const groups = allGroups.filter((g) => g.items.length > 0 || (snapshot.truncated && counts[g.key] > 0))

  // Flatten the visible (non-collapsed) groups into one row list and precompute
  // each item's top offset, so the list can mount only the viewport window.
  const { items, tops, totalH } = useMemo(() => {
    const items: ListItem[] = []
    for (const g of groups) {
      const count = snapshot.truncated ? counts[g.key] : g.items.length
      items.push({ kind: 'head', g: { key: g.key, labelKey: g.labelKey, count, collapsible: g.items.length > 0 } })
      if (!closed.has(g.key)) for (const c of g.items) items.push({ kind: 'row', c })
    }
    const tops = buildTops(items.map((it) => (it.kind === 'head' ? VHEAD_H : VROW_H)))
    return { items, tops, totalH: tops[items.length]! }
    // staged/unstaged/untracked already memoize on snapshot; closed drives collapse.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [staged, unstaged, untracked, closed, snapshot.truncated, snapshot.stats])

  // Mounted window [first, last): the items overlapping the viewport, padded by
  // VOVERSCAN rows each side. Before the first layout measurement a fallback
  // height bounds the initial paint.
  const effHeight = viewport.height > 0 ? viewport.height : VIEWPORT_FALLBACK
  const { first, last } = windowRange(tops, viewport.top, effHeight, VOVERSCAN * VROW_H)

  // A hovered row can vanish without a mouseleave — the virtualized window
  // slides, or a snapshot refresh replaces the list — so drop the bubble with
  // whichever of those moved.
  useEffect(() => { hideTip() }, [first, last, snapshot, hideTip])

  // Prune selection to living paths (avoid a stale path aborting a commit).
  // Selection keys are `path:s`/`path:w`; a key survives only if a change with
  // that path and side still exists.
  useEffect(() => {
    setSelected((prev) => {
      if (prev.size === 0) return prev
      const alive = new Set(snapshot.changes.map((c) => c.path + (c.staged ? ':s' : ':w')))
      const next = new Set<string>()
      let changed = false
      for (const k of prev) { if (alive.has(k)) next.add(k); else changed = true }
      return changed ? next : prev
    })
  }, [snapshot])

  // Prefill amend message from the last commit when the box is toggled on empty.
  useEffect(() => {
    if (!queryVisible || !pageVisibility.isVisible() || !amend || amendPrefilled || message.trim() !== '') return
    let alive = true
    void remote.query({ sessionId, query: { kind: 'last-commit-message' } }).then((res) => {
      const msg = queryAs(res, 'last-commit-message')
      if (alive && msg !== null) {
        setMessage(msg.message)
        setAmendPrefilled(true)
      }
    })
    return () => { alive = false }
  }, [amend, amendPrefilled, message, remote, sessionId, queryVisible])

  // Path pruning belongs to the data hook even while hidden; keep compact
  // navigation in sync without gating local selection/draft cleanup.
  useEffect(() => { if (diffPath === null) setPane('list') }, [diffPath])

  // Disarm a pending discard confirmation when the snapshot changes (the row
  // may be gone) so the destructive "click again" state can't linger.
  useEffect(() => { setArmedDiscard(null) }, [snapshot])
  // Same for the suggest-overwrite confirmation: a fresh snapshot means the
  // message-in-box context may have moved on.
  useEffect(() => { setArmedSuggest(false) }, [snapshot])

  // Batch discard targets: the selected working-tree paths, plus the staged-only
  // picks the confirm dialog reports as unaffected instead of dropping silently.
  const discardTargets = useMemo(() => pickDiscardTargets(selected), [selected])

  // A snapshot that removes every checked row empties the target set; close the
  // dialog rather than letting a stale "open" flag pop it back on the next pick.
  useEffect(() => {
    if (discardPickedOpen && discardTargets.paths.length === 0) setDiscardPickedOpen(false)
  }, [discardPickedOpen, discardTargets])

  const toggle = (path: string): void => {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(path)) next.delete(path); else next.add(path)
      return next
    })
  }

  const run = async (action: GitAction): Promise<boolean> => {
    if (busy) return false
    setBusy(true)
    setError(null)
    setNotice(null)
    try {
      const result = await onAction(action)
      if (!result.ok) { setError(result.error ?? t('error.generic')); return false }
      return true
    } catch (e) {
      setError(e instanceof Error ? e.message : t('error.generic'))
      return false
    } finally {
      setBusy(false)
    }
  }

  const commit = async (): Promise<void> => {
    const text = message.trim()
    if (text === '' && !amend) { setError(t('error.emptyMessage')); return }
    // Selection keys carry a :s/:w side suffix; commit works on bare paths.
    const paths = selected.size > 0 ? [...new Set([...selected].map((k) => k.replace(/:[sw]$/, '')))] : undefined
    const ok = await run({ kind: 'commit', message: text, ...(paths ? { paths } : {}), ...(amend ? { amend: true } : {}) })
    if (ok) { setMessage(''); setSelected(new Set()); setAmend(false); setAmendPrefilled(false) }
  }

  // Stash: push the current changes (optional message), then apply / pop / drop
  // stack entries. Controller accept supplies one query signal for the fresh stack.
  const stashPush = async (message: string): Promise<void> => {
    const ok = await run({ kind: 'stash-push', ...(message.trim() !== '' ? { message } : {}) })
    if (ok) setStashPushOpen(false)
  }
  const stashApply = (index: number, sha: string): void => { void run({ kind: 'stash-apply', index, sha }) }
  const stashPop = (index: number, sha: string): void => { void run({ kind: 'stash-pop', index, sha }) }
  const stashDropConfirmed = async (index: number, sha: string): Promise<void> => {
    const ok = await run({ kind: 'stash-drop', index, sha })
    if (ok) setStashDrop(null)
  }
  // Batch discard of the checked files' working-tree changes (already confirmed
  // by the dialog). The refreshed snapshot prunes the now-clean rows, and the
  // selection with them.
  const discardPicked = async (): Promise<void> => {
    const paths = [...discardTargets.paths]
    if (paths.length === 0) { setDiscardPickedOpen(false); return }
    const ok = await run({ kind: 'discard', paths })
    if (ok) setDiscardPickedOpen(false)
  }

  /** Map a suggest-endpoint failure to display text; the provider detail rides along. */
  const suggestErrorText = (code: GitErrorCode, detail: string | undefined): string => {
    switch (code) {
      case 'empty-diff': return t('error.emptyDiff')
      case 'llm-unavailable': return t('error.llmUnavailable')
      case 'suggest-disabled': return t('error.suggestDisabled')
      case 'llm-error':
      case 'llm-output': return detail === undefined ? t('error.llmFailed') : `${t('error.llmFailed')}: ${detail}`
      default: return detail ?? t('error.generic')
    }
  }

  // Generate a commit message from the current changes (scoped to the
  // selection) and fill the box. On failure the typed error shows above; the
  // user's existing draft is never overwritten by a failed generation. In
  // amend mode a non-empty box holds the previous commit's message as the
  // reference, so replacing it takes a second click (armed pattern, like
  // discard).
  const suggest = async (): Promise<void> => {
    if (suggesting) return
    if (amend && !armedSuggest && message.trim() !== '') {
      setArmedSuggest(true)
      setError(null)
      setNotice(t('commit.suggestOverwrite'))
      return
    }
    setArmedSuggest(false)
    // Selection keys carry a :s/:w side suffix; the suggestion scopes to bare paths.
    const paths = selected.size > 0 ? [...new Set([...selected].map((k) => k.replace(/:[sw]$/, '')))] : undefined
    setSuggesting(true)
    setError(null)
    setNotice(null)
    try {
      const res = await remote.suggest({ sessionId, ...(paths && paths.length > 0 ? { paths } : {}) })
      if (res.ok) {
        setMessage(res.value.message)
        if (res.value.truncated === true) setNotice(t('commit.suggestTruncated'))
        msgRef.current?.focus()
      } else {
        setError(suggestErrorText(res.error.code, res.error.message))
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : t('error.generic'))
    } finally {
      setSuggesting(false)
    }
  }

  const toggleGroup = (key: GroupKey): void => {
    setClosed((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key); else next.add(key)
      return next
    })
  }

  const summary = diffData !== null && diffData.text !== '' ? diffSummary(diffData.text) : null

  // The left change-list column is drag-resizable; the right diff column takes
  // the rest. Width persists across mounts.
  const leftCol = useResizableColumn({ storageKey: 'gp.changes.left', initial: 380, min: 220, reserve: 200, edge: 'end' })

  // Open a file's diff; in compact drill into the diff pane.
  const openDiff = (path: string, base: 'worktree' | 'staged'): void => {
    void showDiff(path, base)
    if (compact) setPane('diff')
  }

  // Compact drops side-by-side (no room) and renders split as unified instead.
  const diffModes: DiffMode[] = compact ? ['unified', 'before', 'after'] : ['unified', 'split', 'before', 'after']
  const effDiffMode: DiffMode = compact && diffMode === 'split' ? 'unified' : diffMode

  const leftChildren = [
    h(ChangeStats, { key: 'stats', stats: snapshot.stats, t }),
    h(ChangesToolbar, {
      key: 'toolbar', snapshot, busy, hasDiscardTargets: discardTargets.paths.length > 0,
      onStageAll: () => void run({ kind: 'stage-all' }),
      onUnstageAll: () => void run({ kind: 'unstage-all' }),
      onDiscard: () => { setError(null); setDiscardPickedOpen(true) },
      onStash: () => { setError(null); setStashPushOpen(true) },
      onPush: () => { hideTip(); setPushOpen(true) },
      onRefresh, t,
    }),
    error !== null ? h('div', { key: 'err', className: 'gp-feedback' }, error) : null,
    notice !== null ? h('div', { key: 'notice', className: 'gp-notice' }, notice) : null,
    // The list can be incomplete in two independent ways; both are surfaced so
    // an entry never disappears from the panel without an explanation. They
    // appear after a poll, so `role="status"` announces them once.
    snapshot.untrackedCollapsed === true
      ? h('div', { key: 'collapsed', className: 'gp-notice', role: 'status' }, t('changes.untrackedCollapsed'))
      : null,
    snapshot.truncated
      ? h('div', { key: 'truncated', className: 'gp-notice', role: 'status' }, t(
        snapshot.truncatedReason === 'lossy'
          ? 'changes.truncatedLossy'
          : snapshot.truncatedReason === 'cap' ? 'changes.truncatedCap' : 'changes.truncatedUnknown',
        { n: snapshot.changes.length },
      ))
      : null,
    h('div', { key: 'list', className: 'gp-changes__list', ref: setListEl },
      snapshot.changes.length === 0
        ? h('div', { className: 'gp-empty' }, t('changes.noChanges'))
        : h('div', { className: 'gp-changes__vlist', style: { height: totalH } },
          items.slice(first, last).map((it, k) => {
            const idx = first + k
            if (it.kind === 'head') {
              const g = it.g
              // A group kept only for its full count (every row fell past the cap)
              // has nothing to toggle: render a static head instead of a chevron
              // that silently does nothing.
              return h('div', {
                key: `h:${g.key}`, className: 'gp-changes__vrow', style: { top: tops[idx], height: VHEAD_H },
              }, h('div', {
                className: `gp-group-head${g.collapsible ? '' : ' gp-group-head--static'}`,
                ...(g.collapsible ? { onClick: () => toggleGroup(g.key) } : {}),
              }, [
                g.collapsible
                  ? h(ChevronIcon, { key: 'chev', size: 12, open: !closed.has(g.key) })
                  : h('span', { key: 'chev', className: 'gp-group-head__chev-spacer' }),
                `${t(g.labelKey)} (${g.count})`,
              ]))
            }
            // A path staged AND modified appears in two rows; key selection /
            // active / armed by path+side so acting on one row doesn't light up
            // the other.
            const c = it.c
            const rowKey = c.path + (c.staged ? ':s' : ':w')
            return h('div', {
              key: rowKey, className: 'gp-changes__vrow', style: { top: tops[idx], height: VROW_H },
            }, renderFileRow(c, {
              selected: selected.has(rowKey),
              active: diffPath?.path === c.path && diffPath.base === (c.staged ? 'staged' : 'worktree'),
              busy,
              armed: armedDiscard === rowKey,
              onToggle: () => toggle(rowKey),
              onOpen: () => openDiff(c.path, c.staged ? 'staged' : 'worktree'),
              onStage: () => void run(c.staged ? { kind: 'unstage', paths: [c.path] } : { kind: 'stage', paths: [c.path] }),
              onDiscard: () => {
                if (armedDiscard === rowKey) { void run({ kind: 'discard', paths: [c.path] }); setArmedDiscard(null) }
                else setArmedDiscard(rowKey)
              },
              tipProps,
              hideTip,
              t,
            }))
          }))),
    // stash list (collapsible)
    stashes.length > 0 ? h('div', { key: 'stashes', className: 'gp-stash' }, [
      h('div', { key: 'head', className: 'gp-group-head', onClick: () => setStashClosed((v) => !v) }, [
        h(ChevronIcon, { key: 'chev', size: 12, open: !stashClosed }),
        `${t('stash.section')} (${stashes.length})`,
      ]),
      stashClosed ? null : h('div', { key: 'items' }, stashes.map((s) => renderStashRow(s, {
        busy,
        onApply: () => stashApply(s.index, s.sha),
        onPop: () => stashPop(s.index, s.sha),
        onDrop: () => { setError(null); setStashDrop(s) },
        t,
      }))),
    ]) : null,
    // commit box
    h('div', { key: 'box', className: 'gp-commitbox' }, [
      h('div', {
        key: 'msg',
        className: `gp-commitbox__msg-wrap${suggesting ? ' gp-commitbox__msg-wrap--busy' : ''}`,
      }, [
        h('textarea', {
          key: 'ta',
          className: 'gp-commitbox__msg',
          placeholder: t('commit.placeholder'),
          value: message,
          ref: msgRef,
          // Locked while a suggestion is in flight so typing can't race the
          // incoming message (readOnly, not disabled: focus() lands on success).
          readOnly: suggesting,
          'aria-busy': suggesting,
          onChange: (e: { target: { value: string } }) => setMessage(e.target.value),
        }),
        // Spinner inside the field itself: the lock should read as "working",
        // not as a broken input. Decorative — aria-busy above carries the state.
        suggesting
          ? h('span', { key: 'spin', className: 'gp-commitbox__spin', 'aria-hidden': 'true' })
          : null,
      ]),
      h('div', { key: 'row', className: 'gp-commitbox__row' }, [
        h('label', { key: 'amend', className: 'gp-commitbox__amend' }, [
          h('input', { key: 'cb', type: 'checkbox', className: 'gp-check', checked: amend, disabled: suggesting, onChange: () => { setAmend((v) => !v); setAmendPrefilled(false) } }),
          t('commit.amend'),
        ]),
        h('div', { key: 'actions', className: 'gp-commitbox__actions' }, [
          snapshot.suggestEnabled !== false
            ? h('button', {
              key: 'suggest', type: 'button', className: 'gp-btn',
              disabled: busy || suggesting || snapshot.changes.length === 0,
              onClick: () => void suggest(),
              title: t('commit.suggest'),
            }, [h(SparkleIcon, { key: 'ic', size: 13 }), suggesting ? t('commit.suggesting') : t('commit.suggest')])
            : null,
          h('button', { key: 'commit', type: 'button', className: 'gp-btn gp-btn--primary', disabled: busy || suggesting || message.trim() === '', onClick: () => void commit() }, t('commit.commit')),
        ]),
      ]),
    ]),
  ]

  const diffBlock = diffPath === null
    ? h('div', { className: 'gp-empty' }, t('changes.selectFile'))
    : h('div', { className: 'gp-diff' }, [
      h('div', { key: 'tb', className: `gp-diff__toolbar${compact ? ' gp-diff__toolbar--compact' : ''}` }, (() => {
        const back = compact
          ? h('button', { key: 'back', type: 'button', className: 'gp-subhead__back', onClick: () => setPane('list') }, [h(ArrowLeftIcon, { key: 'i', size: 14 }), t('changes.backToList')])
          : null
        const path = h('span', { key: 'path', className: 'gp-diff__path' }, diffPath.path)
        const sum = summary ? h('span', { key: 'sum', className: 'gp-stats__item', style: { marginLeft: 'auto' } }, [
          h('span', { key: 'a', className: 'gp-stats__add' }, `+${summary.add}`), ' ',
          h('span', { key: 'd', className: 'gp-stats__del' }, `\u2212${summary.del}`),
        ]) : null
        const expand = h('button', {
          key: 'expand', type: 'button',
          className: `gp-seg__btn gp-diff__expand${expanded ? ' gp-seg__btn--active' : ''}`,
          style: summary || compact ? {} : { marginLeft: 'auto' },
          disabled: effDiffMode !== 'split' && effDiffMode !== 'unified',
          title: t(expanded ? 'diff.collapse' : 'diff.expandAll'),
          onClick: () => void showDiff(diffPath.path, diffPath.base, !expanded),
        }, t(expanded ? 'diff.collapse' : 'diff.expandAll'))
        const seg = h('div', { key: 'seg', className: 'gp-seg' },
          segButtons<DiffMode>(diffModes, effDiffMode, setDiffMode, (m) => t(`diff.${m}` as GitKey)))
        // One row cannot fit back + path + stats + expand + mode seg at phone
        // widths (the seg buttons squeezed into stacked wrapping); compact
        // splits the controls onto a dedicated second row instead.
        if (compact) {
          return [
            h('div', { key: 'row1', className: 'gp-diff__toolbar-row' }, [back, path, sum]),
            h('div', { key: 'row2', className: 'gp-diff__toolbar-row gp-diff__toolbar-row--controls' }, [expand, seg]),
          ]
        }
        return [back, path, sum, expand, seg]
      })()),
      diffData === null
        ? h('div', { key: 'scroll', className: 'gp-diff__scroll' }, h('div', { className: 'gp-empty' }, t('common.loading')))
        : h(DiffView, { key: 'diff', visible: queryVisible, text: diffData.text, mode: effDiffMode, path: diffPath.path, remote, sessionId, base: diffPath.base, expanded, truncated: diffData.truncated === true, newLines: diffData.newLines, t }),
    ])

  // Write-op dialogs (stash push / stash drop / batch discard), portaled;
  // rendered by both layouts.
  const modals: (JSX.Element | null)[] = [
    pushOpen ? h(PushModal, { key: 'remote-push', remote, sessionId, snapshot, onAction, onClose: () => setPushOpen(false), onBusyChange: setPushBusy, t }) : null,
    stashPushOpen ? h(StashPushModal, { key: 'push', onClose: () => setStashPushOpen(false), onStash: stashPush, error, t }) : null,
    stashDrop !== null ? renderConfirmModal({
      title: t('stash.dropTitle'),
      body: t('stash.dropConfirm', { name: stashDrop.message }),
      confirmLabel: t('stash.drop'),
      danger: true,
      error,
      onConfirm: () => void stashDropConfirmed(stashDrop.index, stashDrop.sha),
      onClose: () => setStashDrop(null),
      t,
    }) : null,
    discardPickedOpen && discardTargets.paths.length > 0
      ? h(DiscardPickedModal, {
        key: 'discard-picked',
        paths: discardTargets.paths,
        stagedOnly: discardTargets.stagedOnly,
        snapshot,
        busy,
        error,
        onConfirm: () => void discardPicked(),
        onClose: () => setDiscardPickedOpen(false),
        t,
      })
      : null,
  ]

  // Compact: a single column drilling from the change list into the diff.
  if (compact) {
    return h('div', { className: 'gp-changes gp-changes--compact' }, [
      ...modals,
      tipNode,
      pane === 'diff'
        ? h('div', { key: 'right', className: 'gp-changes__right' }, diffBlock)
        : h('div', { key: 'left', className: 'gp-changes__left' }, leftChildren),
    ])
  }

  return h('div', { className: 'gp-changes' }, [
    ...modals,
    tipNode,
    // left
    h('div', { key: 'left', className: 'gp-changes__left', style: { flex: `0 0 ${leftCol.width}px` } }, leftChildren),
    leftCol.divider,
    // right diff
    h('div', { key: 'right', className: 'gp-changes__right' }, diffBlock),
  ])
}

interface StashPushCbs {
  onClose: () => void
  onStash: (message: string) => void | Promise<void>
  error: string | null
  t: (key: GitKey, params?: Record<string, string | number>) => string
}

/** Portaled dialog: an optional message for the stash about to be pushed.
 * renderModalShell owns the SSR/portal guard, so this is a single component. */
function StashPushModal({ onClose, onStash, error, t }: StashPushCbs): JSX.Element | null {
  const [message, setMessage] = useState('')
  return renderModalShell({
    onClose, title: t('stash.title'), icon: h(StashIcon, { size: 15 }),
    portalKey: 'stash-push-modal', t,
    body: [
      h('input', {
        key: 'msg', className: 'gp-input', placeholder: t('stash.messagePlaceholder'), value: message, autoFocus: true,
        onChange: (e: { target: { value: string } }) => setMessage(e.target.value),
        onKeyDown: (e: { key: string }) => { if (e.key === 'Enter') void onStash(message) },
      }),
      renderAiHint(t),
      error !== null ? h('div', { key: 'err', className: 'gp-feedback' }, error) : null,
    ],
    footer: renderModalFooter({ onClose, onConfirm: () => void onStash(message), confirmLabel: t('stash.save'), confirmDisabled: false, danger: false, t }),
  })
}

interface StashRowCbs {
  busy: boolean
  onApply: () => void
  onPop: () => void
  onDrop: () => void
  t: (key: GitKey, params?: Record<string, string | number>) => string
}

function renderStashRow(s: StashEntry, cb: StashRowCbs): JSX.Element {
  return h('div', { key: s.index, className: 'gp-stash-row' }, [
    h('div', { key: 'info', className: 'gp-stash-row__info' }, [
      h('span', { key: 'm', className: 'gp-stash-row__msg', title: s.message }, s.message),
      h('span', { key: 'meta', className: 'gp-stash-row__meta' }, [
        s.branch !== null ? h('span', { key: 'b' }, cb.t('stash.onBranch', { branch: s.branch })) : null,
        s.relTime !== '' ? h('span', { key: 't' }, s.relTime) : null,
      ]),
    ]),
    h('div', { key: 'act', className: 'gp-stash-row__actions' }, [
      h('button', { key: 'apply', type: 'button', className: 'gp-btn gp-btn--sm', disabled: cb.busy, onClick: cb.onApply }, cb.t('stash.apply')),
      h('button', { key: 'pop', type: 'button', className: 'gp-btn gp-btn--sm', disabled: cb.busy, onClick: cb.onPop }, cb.t('stash.pop')),
      h('button', { key: 'drop', type: 'button', className: 'gp-icon-btn', disabled: cb.busy, title: cb.t('stash.drop'), onClick: cb.onDrop }, h(TrashIcon, { size: 14 })),
    ]),
  ])
}

function byPath(a: GitChange, b: GitChange): number {
  return a.path.localeCompare(b.path)
}

interface RowActions {
  selected: boolean
  active: boolean
  busy: boolean
  armed: boolean
  onToggle: () => void
  onOpen: () => void
  onStage: () => void
  onDiscard: () => void
  /** Hover explanation for the icon-only row buttons (see `tip.tsx`). */
  tipProps: (text: string) => Record<string, unknown>
  hideTip: () => void
  t: (key: GitKey, params?: Record<string, string | number>) => string
}

function renderFileRow(c: GitChange, a: RowActions): JSX.Element {
  const name = c.path.split('/').pop() ?? c.path
  const dir = c.path.includes('/') ? c.path.slice(0, c.path.lastIndexOf('/')) : ''
  return h('div', { key: c.path + (c.staged ? ':s' : ':w'), className: `gp-file-row${a.active ? ' gp-file-row--active' : ''}`, onClick: a.onOpen }, [
    h('input', { key: 'cb', type: 'checkbox', className: 'gp-check', checked: a.selected, onClick: (e: Event) => e.stopPropagation(), onChange: a.onToggle }),
    h('span', { key: 'st', className: `gp-status-badge ${statusClass(c.status)}` }, statusChar[c.status] ?? '?'),
    h('span', { key: 'nm', className: 'gp-tree-name', title: c.path }, [name, dir ? h('span', { key: 'd', style: { color: 'var(--dsw-alias-label-tertiary)', marginLeft: 6, fontSize: 11 } }, dir) : null]),
    h('span', { key: 'act', className: 'gp-file-row__actions' }, [
      // Icon-only buttons carry their meaning in a fast hover tooltip + an
      // aria-label, never a bare glyph (issue #40: the ↺ read as a mystery).
      h('button', {
        key: 'stg', type: 'button', className: 'gp-icon-btn',
        'aria-label': c.staged ? a.t('changes.unstage') : a.t('changes.stage'),
        disabled: a.busy,
        ...a.tipProps(c.staged ? a.t('changes.unstageTip') : a.t('changes.stageTip')),
        onClick: (e: Event) => { e.stopPropagation(); a.hideTip(); a.onStage() },
      }, c.staged ? '\u2212' : '+'),
      // Discard is a working-tree operation (`git restore --`), so it lives on
      // the working-tree side only: an index-side row has nothing to discard
      // (and a staged delete makes the command fail outright).
      c.staged ? null : h('button', {
        key: 'dis', type: 'button', className: 'gp-icon-btn',
        'aria-label': a.armed ? a.t('changes.discardConfirm') : a.t('changes.discard'),
        style: a.armed ? { color: 'var(--dsw-alias-state-error-primary)' } : {},
        disabled: a.busy,
        ...a.tipProps(a.armed ? a.t('changes.discardTipArmed') : a.t('changes.discardTip')),
        onClick: (e: Event) => { e.stopPropagation(); a.hideTip(); a.onDiscard() },
      }, '\u21ba'),
    ]),
  ])
}
