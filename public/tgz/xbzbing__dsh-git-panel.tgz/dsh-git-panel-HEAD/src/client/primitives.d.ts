/**
 * Minimal ambient surface for the platform's Markdown and code highlighter.
 * @deepseek-ai/dsh-client-ui-primitives is a web-shell platform seed listed
 * in package.json `dsh.client.inject`, external to the plugin bundle. These
 * declarations mirror its public MarkdownText and code-highlighting types.
 */
declare module '@deepseek-ai/dsh-client-ui-primitives' {
  import type { JSX } from 'react'

  export interface MarkdownCodeLabels {
    copyLabel: string
    copiedLabel: string
  }
  export interface MarkdownLabels {
    code: MarkdownCodeLabels
    footnotes: string
  }
  export interface HighlightSpan {
    text: string
    style: import('react').CSSProperties
  }
  export type CodeHighlighter = (code: string) => HighlightSpan[][] | undefined
  export function languageForPath(path: string): string | undefined
  export function useCodeHighlighter(language: string | undefined): CodeHighlighter
  /** Async Clipboard API with an `execCommand('copy')` fallback for insecure
   * contexts (a remote plain-HTTP origin has no `navigator.clipboard`). */
  export function writeClipboard(text: string): Promise<boolean>
  export const FileTypeIcon: (props: ({ readonly path: string } | { readonly kind: 'folder' }) & { readonly size?: number; readonly className?: string }) => JSX.Element | null
  export const MarkdownText: (props: {
    text: string
    labels: MarkdownLabels
    variant?: 'body' | 'compact'
    streaming?: boolean
  }) => JSX.Element
}
