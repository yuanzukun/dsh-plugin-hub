/**
 * Test kit barrel: re-exports the pure client algorithms so `node --test`
 * can import them from a built ESM bundle (lib/testkit.mjs) without a
 * TypeScript loader. Not part of the plugin runtime.
 */
export { parseStatus, parseGraphLog, parseBranches, parseNameStatus, parseTags, parseStashList, sumNumstat, parseRefs } from '../host/parser.js'
export { parseRemote, classifyHost } from '../host/remote.js'
export { parsePrimaryRemote } from '../host/core.js'
export { isSafePath, isSafeRev, isSafeBranchName, isSafeRemoteName } from '../host/validate.js'
export { planAction, classifyActionFailure } from '../host/actions.js'
export { buildSideBySide, summarize, isBinaryDiff, isAddOnlyDiff, isDeleteOnlyDiff, extractAddedContent, extractDeletedContent, isImagePath, isSvgPath, intraLineDiff, spliceGap, contextRowsFromLines, flattenToUnified, GAP_STEP } from './diff.js'
export { buildFileTree } from './file-tree.js'
export { layoutGraph, graphWidth } from './git-graph.js'
export { gitPanelRemoteOf, queryAs, hasSession } from './rpc.js'
export { splitHighlightSpans } from './code-spans.js'
export { buildTops, lowerBound, windowRange } from './virtual-list.js'
export { activateGitTab, isGitTabActive, returnToConversation, stashSubTab, recentSubTab } from './jump.js'
