/**
 * diff 视图：工具栏 / 路径复制 / 滚动区 / seg / 展开 / 换行。
 *
 * 层叠顺序即本文件的挂载顺序（见 styles.ts 的 CSS_PARTS）：写在后面的模块
 * 覆盖前面的，同一模块内越靠后的规则越优先。要让新规则赢过某条既有规则，
 * 就写在它所在的模块之后。颜色一律走 --dsw-alias-* 变量，深浅色主题才一致。
 */
export const CSS = `
/* diff view */
.gp-diff{flex:1;min-height:0;display:flex;flex-direction:column}
.gp-diff__toolbar{display:flex;align-items:center;gap:8px;padding:6px 10px;border-bottom:1px solid var(--dsw-alias-border-l2);flex:none}
/* Compact diff pane: controls (expand-all + mode seg) live on their own
 * second row — one row cannot fit them at phone widths without the seg
 * buttons wrapping into a squeezed stack. */
.gp-diff__toolbar--compact{flex-wrap:wrap;row-gap:6px}
.gp-diff__toolbar-row{display:flex;align-items:center;gap:8px;min-width:0}
.gp-diff__toolbar-row:first-child{flex:1 1 100%}
.gp-diff__toolbar-row--controls{flex:1 1 100%;flex-wrap:wrap}
.gp-diff__toolbar-row--controls .gp-diff__expand{flex:none}
/* View-mode switches are three fixed-size icon targets, so the compact
 * controls row never has to give them room by wrapping labels. */
.gp-diff__modes{display:inline-flex;align-items:center;gap:4px;flex:none}
/* The compare glyph is two panes side by side; once the split view is on it
 * turns 90° to mirror the stacked layout, and its label names the way back. */
.gp-diff__mode .gp-diff__compare-icon{transition:transform .12s ease}
.gp-diff__mode[aria-pressed="true"] .gp-diff__compare-icon{transform:rotate(90deg)}
/* The filename stays whole: the directory part shrinks first (flex-shrink
 * only applies to it), eliding from its LEFT — a right-to-left run keeps the
 * tail ("…client/OverviewTab.tsx") — and the full relative path rides on the
 * title tooltip. Mirrors what the file-diff modal shows. */
/* The header path IS the copy control: a bare button (reset) whose click
 * writes the relative path to the clipboard. The confirmation never replaces
 * the visible text (a bare text node wraps when the toolbar squeezes the
 * button below the phrase's width): success swaps the directory slot for a
 * check mark and tints the name, failure only tints it. The hover underline
 * is the affordance. Font shorthand first so font-size can re-pin after. */
.gp-diff__path{position:relative;display:flex;align-items:baseline;min-width:0;overflow:hidden;background:none;border:0;padding:0;margin:0;font:inherit;font-size:12px;color:inherit;text-align:left;cursor:pointer;border-radius:4px}
.gp-diff__path:hover .gp-diff__path-name{text-decoration:underline}
.gp-diff__path:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:2px}
.gp-diff__path--copied{color:var(--dsw-alias-state-success-primary)}
.gp-diff__path--copied svg{margin-right:2px}
.gp-diff__path--copied .gp-diff__path-name{color:var(--dsw-alias-state-success-primary)}
.gp-diff__path--error{color:var(--dsw-alias-state-error-primary)}
.gp-diff__path--error .gp-diff__path-name{color:var(--dsw-alias-state-error-primary)}
/* Visually-hidden live region: the copy confirmation is announced to screen
 * readers without entering the toolbar's layout at all. */
.gp-copy-live{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;border:0}
.gp-diff__path-dir{direction:rtl;unicode-bidi:isolate;flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-tertiary)}
.gp-diff__path-sep{flex:none;color:var(--dsw-alias-label-tertiary)}
.gp-diff__path-name{flex:none;color:var(--dsw-alias-label-primary);font-weight:600}
/* Same root-level shape as the files toolbar: the name alone has to shrink. */
.gp-diff__path-name--root{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.gp-diff__expand:disabled{opacity:.45;cursor:not-allowed}
/* Icon controls in the diff toolbar and the commit-diff modal bar wear the same
 * bordered box as the files preview's glyph buttons, at the mode seg's height
 * (25px: its 1px border + 5px padding + the 13px line box the seg pins), so each
 * row reads as one control strip. Pressed (card up / expanded) takes the
 * business tint. The seg's line box is explicit in its own rule — left to the
 * font's default it drifts with whatever mono/sans fallback the platform picks,
 * and the two controls stop matching. */
.gp-diff__toolbar .gp-icon-btn,.gp-modal__bar .gp-icon-btn{width:28px;height:25px;border:1px solid var(--dsw-alias-border-l2);border-radius:6px;background:var(--dsw-alias-bg-layer-1)}
.gp-diff__toolbar .gp-icon-btn:hover:not(:disabled),.gp-modal__bar .gp-icon-btn:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}
.gp-diff__toolbar .gp-icon-btn:disabled,.gp-modal__bar .gp-icon-btn:disabled{opacity:.5;cursor:default}
.gp-diff__toolbar .gp-icon-btn[aria-pressed="true"],.gp-modal__bar .gp-icon-btn[aria-pressed="true"]{background:color-mix(in srgb,var(--dsw-alias-state-business-primary) 12%,transparent);color:var(--dsw-alias-state-business-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-business-primary) 35%,transparent)}
/* The diff enlarged IN PLACE: the same inline .gp-diff node restyled into the
 * card (the fullscreen reader's trick — ADR-0016), so the DiffView never
 * remounts: no second highlight/image pass, no state loss. Geometry mirrors
 * .gp-modal; the backdrop sits at 999, the card at 1000, both portaled-free
 * (fixed positioning escapes the pane — no transform ancestor in the panel). */
.gp-diff--card{position:fixed;inset:0;margin:auto;z-index:1000;width:min(920px,86vw);height:min(680px,82vh);min-width:0;max-height:100vh;display:flex;flex-direction:column;background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l1,var(--dsw-alias-border-l2));border-radius:14px;overflow:hidden;box-shadow:0 24px 64px rgba(0,0,0,.32),0 4px 12px rgba(0,0,0,.18);animation:gp-modal-in .18s cubic-bezier(.16,1,.3,1)}
/* The card's toolbar reads as a modal bar (same padding + surface). */
.gp-diff--card .gp-diff__toolbar{padding:11px 12px 11px 14px;background:var(--dsw-alias-bg-layer-2)}
.gp-diff-backdrop{position:fixed;inset:0;z-index:999;background:color-mix(in srgb,var(--dsw-alias-bg-base,#000) 62%,transparent);animation:gp-fade-in .12s ease}
.gp-seg{display:inline-flex;border:1px solid var(--dsw-alias-border-l2);border-radius:7px;overflow:hidden;background:var(--dsw-alias-bg-layer-1)}
.gp-seg__btn{border:0;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:11px;line-height:13px;white-space:nowrap;padding:5px 10px;cursor:pointer;transition:background .12s ease,color .12s ease}
.gp-seg__btn:hover{background:var(--dsw-alias-interactive-bg-hover)}
.gp-seg__btn--active{background:var(--dsw-alias-state-business-primary);color:#fff}
.gp-seg__btn--active:hover{background:var(--dsw-alias-state-business-primary)}
.gp-diff__scroll{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;font-family:var(--dsw-font-mono,monospace);font-size:12px}
/* DiffView owns its scroller (the wrap fills the pane, the Find bar sits above
 * the scrolling body) so the row window knows its viewport height on the first
 * paint. */
.gp-diff__wrap{flex:1;min-height:0;display:flex;flex-direction:column}
.gp-diff__wrap .gp-find{flex:none}
/* Height band reserving the rows outside the mounted window; spans every grid
 * column, so it takes a grid row of its own. */
.gp-diff__spacer{pointer-events:none}
/* Line-number gutters are sized by --gp-gutter-w, set on the scroll container
 * from the highest line number on screen (gutterWidth): three digits wide by
 * default, wider only when a side actually reaches four. */
.gp-diff__side{display:grid;grid-template-columns:var(--gp-gutter-w,calc(3ch + 10px)) 1fr var(--gp-gutter-w,calc(3ch + 10px)) 1fr}
/* unified (inline) layout: old|new line-number gutters + a sign column + one
 * shared code column; add/del tint the gutters, sign and code together. */
.gp-diff__unified{display:grid;grid-template-columns:var(--gp-gutter-w,calc(3ch + 10px)) var(--gp-gutter-w,calc(3ch + 10px)) 18px 1fr}
/* before/after single column: one line-number gutter + code */
.gp-diff__single{display:grid;grid-template-columns:var(--gp-gutter-w,calc(3ch + 10px)) 1fr}
.gp-diff-uni__sign{text-align:center;user-select:none;font-size:11px;line-height:20px;color:var(--dsw-alias-label-tertiary)}
.gp-diff-uni__sign.gp-diff-row--add{color:var(--dsw-alias-state-success-primary)}
.gp-diff-uni__sign.gp-diff-row--del{color:var(--dsw-alias-state-error-primary)}
.gp-diff-cell{padding:0 4px;white-space:pre-wrap;word-break:break-all;line-height:20px}
.gp-diff-no{color:var(--dsw-alias-label-tertiary);text-align:right;padding:0 5px;user-select:none;font-size:11px;line-height:20px;background:color-mix(in srgb,var(--dsw-alias-label-primary) 4%,transparent);border-right:1px solid var(--dsw-alias-border-l2)}
.gp-diff-no--pick{cursor:pointer;position:relative}
.gp-diff-no--pick:hover{color:var(--dsw-alias-state-business-primary);background-image:linear-gradient(color-mix(in srgb,var(--dsw-alias-state-business-primary) 12%,transparent),color-mix(in srgb,var(--dsw-alias-state-business-primary) 12%,transparent))}
/* The "+" that says a line can be picked, shown while the pointer is anywhere
 * on the line (the platform's review tab does the same). The rows are flat grid
 * cells with no row element, so the code cell's hover reaches back to its
 * gutter through :has(). The badge belongs to the gutter cell, so a click on it
 * is a click on the gutter; it sits just right of the gutter — over the
 * unified view's sign column, or the start of the code — and leaves the number
 * readable. It is centered on the row's height, so a wrapped line shows it
 * beside the middle of its text. In the unified view the new-side number
 * carries it; a deletion has only an old-side number, whose badge skips the
 * empty new-side column. Pointer hover only: a touch has no hover to reveal it.
 * The badge's box and the gutter's own hover are separate rules from the
 * :has() list: a browser without :has() drops that whole list, and still shows
 * the badge while the pointer is on the number itself. */
@media (hover:hover){
.gp-diff-no--pick::after{position:absolute;z-index:2;top:50%;transform:translateY(-50%);left:calc(100% + 1px);width:18px;height:18px;border-radius:4px;background:var(--dsw-alias-label-primary);color:var(--dsw-alias-bg-layer-1);font-size:14px;font-weight:600;line-height:18px;text-align:center}
.gp-diff-no--pick:hover::after{content:'+'}
.gp-diff-no--pick:has(+ .gp-diff-cell:hover)::after,
.gp-diff-no--pick:has(+ .gp-diff-uni__sign:hover)::after,
.gp-diff-no--pick:has(+ .gp-diff-uni__sign + .gp-diff-uni__code:hover)::after,
.gp-diff-no--pick:has(+ .gp-diff-no:not(.gp-diff-no--pick) + .gp-diff-uni__sign:hover)::after,
.gp-diff-no--pick:has(+ .gp-diff-no:not(.gp-diff-no--pick) + .gp-diff-uni__sign + .gp-diff-uni__code:hover)::after{content:'+'}
.gp-diff-no--pick:has(+ .gp-diff-no)::after{left:calc(200% + 2px)}
}
.gp-diff-no--pick:focus{outline:none}
.gp-diff-no--pick:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:-2px}
/* Diff line comments (ADR-0039): gutters and code keep their add/del base color
 * under a business-colored image layer. The selected gutter layer wins over
 * hover, so a picked deletion still reads as a deletion. */
.gp-diff-no.gp-diff-no--sel,.gp-diff-no.gp-diff-no--sel:hover{color:var(--dsw-alias-state-business-primary);background-image:linear-gradient(color-mix(in srgb,var(--dsw-alias-state-business-primary) 20%,transparent),color-mix(in srgb,var(--dsw-alias-state-business-primary) 20%,transparent))}
.gp-diff-cell--sel{background-image:linear-gradient(color-mix(in srgb,var(--dsw-alias-state-business-primary) 14%,transparent),color-mix(in srgb,var(--dsw-alias-state-business-primary) 14%,transparent))}
.gp-review{flex:none;display:flex;flex-direction:column;gap:6px;padding:8px 10px;border-top:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1)}
.gp-review__head{display:flex;flex-wrap:wrap;align-items:baseline;column-gap:8px;row-gap:2px;font-size:12px}
.gp-review__title{font-weight:600;color:var(--dsw-alias-label-primary)}
.gp-review__hint{font-size:11px;color:var(--dsw-alias-label-tertiary)}
.gp-review__stale{font-size:12px;color:var(--dsw-alias-state-warn-primary)}
.gp-review__input{box-sizing:border-box;width:100%;min-height:56px;max-height:160px;resize:vertical;padding:6px 8px;border:1px solid var(--dsw-alias-border-l2);border-radius:6px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px;line-height:18px}
.gp-review__input:focus{outline:none;border-color:var(--dsw-alias-state-business-primary)}
.gp-review__error{font-size:12px;color:var(--dsw-alias-state-error-primary)}
.gp-review__actions{display:flex;justify-content:flex-end;gap:6px}
/* Change rows own only the base color; hover/selection own background-image. */
.gp-diff-row--add{background-color:color-mix(in srgb,var(--dsw-alias-state-success-primary) 15%,transparent);box-shadow:inset 2px 0 0 color-mix(in srgb,var(--dsw-alias-state-success-primary) 55%,transparent)}
.gp-diff-row--del{background-color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 15%,transparent);box-shadow:inset 2px 0 0 color-mix(in srgb,var(--dsw-alias-state-error-primary) 55%,transparent)}
/* Only the code cell carries the line's 2px leading edge: one bar per side in
 * split and one in unified, always at the code column's left edge. Gutters and
 * the unified sign column share the row tint but not the inset edge — copying
 * it would draw parallel rails a few pixels apart and divide the number and
 * sign columns into colored strips. */
.gp-diff-no.gp-diff-row--add,.gp-diff-no.gp-diff-row--del,
.gp-diff-uni__sign.gp-diff-row--add,.gp-diff-uni__sign.gp-diff-row--del{box-shadow:none}
.gp-diff-row--hunk{background:color-mix(in srgb,var(--dsw-alias-state-business-primary) 6%,transparent);color:var(--dsw-alias-state-business-primary);padding:3px 8px;font-size:11px;font-weight:600;border-top:1px solid var(--dsw-alias-border-l2);border-bottom:1px solid var(--dsw-alias-border-l2)}
/* collapsed-context band with expand controls (spans both sides). A gap is
 * always immediately followed by a hunk header (or the file end), so it omits
 * its own bottom border and lets the hunk's top border be the single divider —
 * otherwise the two 1px borders stack into a fat 2px line. */
.gp-diff-row--gap{display:flex;align-items:center;justify-content:center;gap:6px;padding:2px 10px;background:color-mix(in srgb,var(--dsw-alias-state-business-primary) 6%,transparent);border-top:1px solid var(--dsw-alias-border-l2)}
.gp-gap__btn{display:inline-flex;align-items:center;height:20px;padding:0 9px;border:1px solid var(--dsw-alias-border-l2);border-radius:999px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-state-business-primary);font:inherit;font-size:11px;cursor:pointer;white-space:nowrap;transition:background .12s ease}
.gp-gap__btn:hover{background:var(--dsw-alias-interactive-bg-hover)}
.gp-gap__btn:disabled{opacity:.55;cursor:default}
/* word-level intra-line change emphasis: a deeper add/del tint over the row
 * background so the exact changed tokens stand out. */
.gp-diff-word{border-radius:3px;padding:0 1px}
.gp-diff-word--add{background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 38%,transparent)}
.gp-diff-word--del{background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 38%,transparent)}
/* image comparison: old/new panes (split) or one pane (before/after) */
.gp-imgcmp{display:grid;grid-template-columns:1fr 1fr;gap:1px;height:100%;background:var(--dsw-alias-border-l2)}
.gp-imgcmp--single{grid-template-columns:1fr}
.gp-imgcmp__pane{display:flex;flex-direction:column;min-width:0;min-height:0;background:var(--dsw-alias-bg-layer-2)}
.gp-imgcmp__head{flex:none;padding:4px 10px;font-size:11px;color:var(--dsw-alias-label-tertiary);border-bottom:1px solid var(--dsw-alias-border-l2)}
.gp-imgcmp__img{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;display:flex;align-items:flex-start;justify-content:flex-start;padding:10px;background-color:var(--dsw-alias-bg-layer-1);background-image:linear-gradient(45deg,color-mix(in srgb,var(--dsw-alias-label-primary) 5%,transparent) 25%,transparent 25%,transparent 50%,color-mix(in srgb,var(--dsw-alias-label-primary) 5%,transparent) 50%,color-mix(in srgb,var(--dsw-alias-label-primary) 5%,transparent) 75%,transparent 75%);background-size:16px 16px}
.gp-imgcmp__img img{max-width:100%;max-height:100%;object-fit:contain;image-rendering:auto}
.gp-imgcmp__missing{flex:1;display:flex;align-items:center;justify-content:center;color:var(--dsw-alias-label-tertiary);font-size:12px;background:var(--dsw-alias-bg-layer-1)}
/* SVG diff: render/source toggle bar above the rendered comparison or source diff */
.gp-svgdiff{display:flex;flex-direction:column;height:100%;min-height:0}
.gp-svgdiff__bar{flex:none;display:flex;justify-content:flex-end;padding:6px 10px;border-bottom:1px solid var(--dsw-alias-border-l2)}
.gp-svgdiff__body{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden}
.gp-feedback{padding:6px 10px;font-size:12px;color:var(--dsw-alias-state-error-primary);background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 10%,transparent);display:flex;align-items:center;gap:8px}
/* Dismissible error banner: the message line is centred on a one-line banner;
 * when the message wraps, the close control drops to the bottom-right corner. */
.gp-feedback--dismissible .gp-feedback__close{align-self:flex-end}
.gp-feedback__text{flex:1 1 auto;min-width:0}
.gp-feedback__close{flex:none;display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;padding:0;border:0;border-radius:5px;background:transparent;color:inherit;cursor:pointer;opacity:.75}
.gp-feedback__close:hover{opacity:1;background:var(--dsw-alias-interactive-bg-hover)}
.gp-feedback__close:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:-2px}
.gp-notice{padding:6px 10px;font-size:12px;color:var(--dsw-alias-label-secondary);background:color-mix(in srgb,var(--dsw-alias-label-secondary) 10%,transparent);display:flex;align-items:center;gap:8px}
/* Dismissible banner: the text takes the free width, the close button pins right. */
.gp-notice__text{flex:1 1 auto;min-width:0}
.gp-notice__close{flex:none;display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;margin:-2px -4px -2px 0;padding:0;border:0;border-radius:5px;background:transparent;color:var(--dsw-alias-label-tertiary);cursor:pointer}
.gp-notice__close:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.gp-notice__close:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:-2px}
`
