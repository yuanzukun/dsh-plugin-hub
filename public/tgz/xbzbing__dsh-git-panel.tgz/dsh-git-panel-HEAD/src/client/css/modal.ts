/**
 * 弹窗：文件 diff 弹窗 / 小对话框 / 文件属性面板。
 *
 * 层叠顺序即本文件的挂载顺序（见 styles.ts 的 CSS_PARTS）：写在后面的模块
 * 覆盖前面的，同一模块内越靠后的规则越优先。要让新规则赢过某条既有规则，
 * 就写在它所在的模块之后。颜色一律走 --dsw-alias-* 变量，深浅色主题才一致。
 */
export const CSS = `
/* commit file-diff modal (overview → click a file): a centered dialog over a
 * dimmed backdrop, closed by Esc / backdrop click / the close button. */
.gp-modal-backdrop{position:fixed;inset:0;z-index:1000;display:flex;align-items:center;justify-content:center;padding:40px;background:color-mix(in srgb,var(--dsw-alias-bg-base,#000) 62%,transparent);backdrop-filter:blur(2px);animation:gp-fade-in .12s ease}
@keyframes gp-fade-in{from{opacity:0}to{opacity:1}}
.gp-modal{display:flex;flex-direction:column;position:relative;width:min(920px,86vw);height:min(680px,82vh);border:1px solid var(--dsw-alias-border-l1,var(--dsw-alias-border-l2));border-radius:14px;background:var(--dsw-alias-bg-layer-2);box-shadow:0 24px 64px rgba(0,0,0,.32),0 4px 12px rgba(0,0,0,.18);overflow:hidden;animation:gp-modal-in .18s cubic-bezier(.16,1,.3,1)}
@keyframes gp-modal-in{from{transform:translateY(12px) scale(.97);opacity:0}to{transform:none;opacity:1}}
.gp-modal__bar{display:flex;align-items:center;gap:10px;padding:11px 12px 11px 14px;border-bottom:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2);flex:none}
.gp-modal__fileicon{display:inline-flex;align-items:center;color:var(--dsw-alias-label-tertiary);flex:none}
.gp-modal__path{font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;min-width:0}
/* Copy-enabled variant of the header path (file-diff modal): button reset +
 * affordance + inline confirmation tint. Kept in a modifier so plain modal
 * titles sharing .gp-modal__path never pick up a pointer cursor. */
.gp-modal__path--copy{position:relative;background:none;border:0;padding:0;margin:0;font:inherit;font-size:13px;color:inherit;text-align:left;cursor:pointer;border-radius:4px}
.gp-modal__path--copy:hover .gp-modal__name{text-decoration:underline}
.gp-modal__path--copy:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:2px}
.gp-modal__path--copied{color:var(--dsw-alias-state-success-primary);text-overflow:clip}
.gp-modal__path--copied svg{margin-right:2px}
.gp-modal__path--copied .gp-modal__name{color:var(--dsw-alias-state-success-primary)}
.gp-modal__path--error{color:var(--dsw-alias-state-error-primary);text-overflow:clip}
.gp-modal__path--error .gp-modal__name{color:var(--dsw-alias-state-error-primary)}
.gp-modal__dir{color:var(--dsw-alias-label-tertiary)}
.gp-modal__name{color:var(--dsw-alias-label-primary);font-weight:600}
.gp-modal__hash{font-family:var(--dsw-font-mono,ui-monospace,monospace);font-size:11px;color:var(--dsw-alias-label-tertiary);padding:2px 7px;border-radius:6px;background:var(--dsw-alias-bg-layer-3,var(--dsw-alias-bg-layer-1));flex:none}
.gp-modal__sum{display:inline-flex;align-items:center;gap:8px;font-size:12px;font-family:var(--dsw-font-mono,ui-monospace,monospace);flex:none}
.gp-modal__close{flex:none}
/* Compact modal bar: two rows (header / mode seg + close), mirroring the
 * changes-pane toolbar. The seg stretches evenly and the bordered close
 * button pins to the row's far right. */
.gp-modal__bar-row{display:flex;align-items:center;gap:8px;min-width:0;flex:1 1 100%}
.gp-modal__bar-row--controls{flex-wrap:wrap}
.gp-modal__bar-row--controls .gp-seg{flex:1 1 auto;min-width:max-content}
.gp-modal__bar-row--controls .gp-seg .gp-seg__btn{flex:1 1 0;min-width:max-content}
.gp-modal__bar-row--controls .gp-modal__close{margin-left:auto;border:1px solid var(--dsw-alias-border-l2);border-radius:7px}
/* The reader card's labelled fullscreen toggle, at the icon buttons' height. */
.gp-modal__bar .gp-files__fs-screen{flex:none;height:25px;gap:5px;padding:0 8px;font-size:12px}
.gp-modal__bar .gp-files__fs-screen[aria-pressed="true"]{background:color-mix(in srgb,var(--dsw-alias-state-business-primary) 12%,transparent);color:var(--dsw-alias-state-business-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-business-primary) 35%,transparent)}
.gp-modal__scroll{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden;font-family:var(--dsw-font-mono,monospace);font-size:12px;background:var(--dsw-alias-bg-layer-2)}
/* The read-only file view owns its own scroller (CodePreview does the
 * windowing); the modal body only gives it a bounded flex column. */
.gp-modal__file{flex:1;min-height:0;display:flex;flex-direction:column}
.gp-modal__copy--copied{color:var(--dsw-alias-state-success-primary)}
.gp-modal__copy--error{color:var(--dsw-alias-state-error-primary)}

/* small dialog (tag create/delete, stash push/drop): auto-height form modal */
.gp-modal--sm{width:min(460px,92vw);height:auto;max-height:min(560px,86vh)}
.gp-modal__form{flex:1;min-height:0;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:10px}
.gp-modal__confirmtext{font-size:13px;line-height:1.6;color:var(--dsw-alias-label-primary);white-space:pre-wrap;word-break:break-word}
/* busy overlay (e.g. pull in flight): a scrim + spinner + indeterminate bar */
.gp-modal__overlay{position:absolute;inset:0;z-index:2;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:20px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2) 82%,transparent);backdrop-filter:blur(1.5px);border-radius:inherit;animation:gp-fade-in .12s ease}
.gp-modal__overlay-label{font-size:12px;color:var(--dsw-alias-label-secondary)}
@keyframes gp-fade-in{from{opacity:0}to{opacity:1}}
.gp-modal__check{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--dsw-alias-label-secondary);cursor:pointer;user-select:none}
.gp-input{width:100%;box-sizing:border-box;height:30px;padding:0 10px;border:1px solid var(--dsw-alias-border-l2);border-radius:6px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:13px}
.gp-input:focus{outline:none;border-color:var(--dsw-alias-state-business-primary)}
.gp-input--area{height:auto;min-height:60px;padding:8px 10px;resize:vertical;line-height:1.5}
.gp-modal__footer{flex:none;display:flex;justify-content:flex-end;gap:8px;padding:10px 14px;border-top:1px solid var(--dsw-alias-border-l2)}
.gp-modal__hint{font-size:11px;line-height:1.5;color:var(--dsw-alias-label-tertiary)}
/* Git Flow dialogs: a heading, labelled fields and the finish-strategy list.
 * A little wider than the plain confirm so the branch preview and the tag
 * field keep their label and value on one line. */
.gp-modal--flow{width:min(520px,94vw);max-height:min(680px,88vh);container-type:inline-size}
/* A dialog raised by the Git panel belongs to the panel: its backdrop fills the
 * panel's box (the panel is positioned) instead of dimming the whole window.
 * The layer still sits above the compact branch sheet — that sheet is portaled
 * to the body at z-index 1000, and a flow dialog opened from it must render
 * above it, not behind. The frame is capped to the panel so a narrow sidebar
 * keeps the dialog scrollable instead of overflowing it. */
.gp-modal-backdrop--contained{position:absolute;inset:0;z-index:1001;padding:16px}
.gp-modal-backdrop--contained .gp-modal--flow{width:min(520px,100%);max-height:100%}
/* The guide and the live previews share the branch colours and quiet surfaces. */
.gp-modal--flow-about .gp-modal__form{gap:14px}
.gp-flow-about__intro{margin:0;color:var(--dsw-alias-label-secondary);font-size:13px;line-height:1.55}
.gp-flow-about__branches{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));margin:0;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-alias-bg-layer-1)}
.gp-flow-about__branches > div{padding:9px 11px;min-width:0}
.gp-flow-about__branches > div + div{border-inline-start:1px solid var(--dsw-alias-border-l2)}
.gp-flow-about__branches dt{font-size:13px;font-weight:600}
.gp-flow-about__branches dd{margin:3px 0 0;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:1.45}
.gp-flow-about__diagram{display:grid;gap:6px;margin:0;padding:10px 11px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-alias-bg-layer-1);min-width:0}
.gp-flow-about__diagram figcaption{font-size:12px;font-weight:600;color:var(--dsw-alias-label-secondary)}
.gp-flow-about__diagram svg{display:block;width:100%;height:auto}
.gp-flow-about__guide{stroke:var(--dsw-alias-border-l2);stroke-dasharray:2 4;vector-effect:non-scaling-stroke}
.gp-flow-about__edge{fill:none;stroke:var(--gp-flow-lane);stroke-width:1.8;stroke-linecap:round;vector-effect:non-scaling-stroke}
.gp-flow-about__edge--back{stroke-dasharray:4 3}
.gp-flow-about__dot{fill:var(--dsw-alias-bg-layer-1);stroke:var(--gp-flow-lane);stroke-width:1.5;vector-effect:non-scaling-stroke}
.gp-flow-about__lane-label,.gp-flow-about__version{font-family:var(--dsw-font-mono,ui-monospace,monospace);font-size:12px;fill:var(--dsw-alias-label-primary)}
.gp-flow-about__lane-label{font-weight:600}
.gp-flow-about__version{fill:var(--dsw-alias-label-secondary)}
.gp-flow-about__legend{display:flex;flex-wrap:wrap;gap:6px 14px;color:var(--dsw-alias-label-secondary);font-size:11px}
.gp-flow-about__legend span{display:inline-flex;align-items:center;gap:5px}
.gp-flow-about__legend-tag::before{content:'#';font-weight:600}
.gp-flow-about__legend-back::before{content:'';width:12px;border-top:1px dashed currentColor}
@container (max-width:380px){.gp-flow-about__lane-label,.gp-flow-about__version{font-size:16px}}
.gp-flow-about__footer{align-items:center;justify-content:space-between}
.gp-flow-about__actions{display:inline-flex;align-items:center;gap:8px;flex-wrap:wrap}
.gp-flow-about__source{display:inline-flex;align-items:center;gap:4px;color:var(--dsw-alias-label-secondary);font-size:12px;text-decoration:none}
.gp-flow-about__source:hover,.gp-flow-about__source:focus-visible{color:var(--dsw-alias-label-primary);text-decoration:underline}
.gp-flow__heading{font-size:16px;font-weight:600;line-height:1.3;color:var(--dsw-alias-label-primary)}
.gp-flow__field{display:flex;align-items:center;gap:8px;min-width:0}
.gp-flow__field--stack{flex-direction:column;align-items:stretch;gap:6px}
.gp-flow__label{flex:none;font-size:12px;color:var(--dsw-alias-label-secondary)}
.gp-flow__field .gp-input{flex:1 1 auto;min-width:0;width:auto}
.gp-flow__branch-picker{flex:1 1 auto;min-width:0}
.gp-flow__branch-picker > span{display:block;width:100%}
.gp-flow__branch-picker .gp-select-trigger.gp-flow__select{width:100%;max-width:none;min-height:30px;justify-content:space-between;text-align:start;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l2)}
/* The finish target when it is not a choice (a feature / release lands on
 * develop): a value, not a disabled control, so it does not look editable. */
.gp-flow__target{flex:1 1 auto;min-width:0;font-size:13px;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-mono,ui-monospace,monospace);overflow-wrap:anywhere}
.gp-flow__preview{padding-left:2px;font-size:11px;color:var(--dsw-alias-label-tertiary);overflow-wrap:anywhere}
.gp-flow__modes{display:flex;flex-direction:column;gap:8px;padding:2px 0}
.gp-flow__mode{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--dsw-alias-label-primary);cursor:pointer;user-select:none}
.gp-flow__check--off{color:var(--dsw-alias-label-tertiary);cursor:default}
.gp-flow__hint{font-size:11px;line-height:1.5;color:var(--dsw-alias-label-tertiary)}
/* Preview edges each have one labelled arrow. Remote effects sit under the
 * affected branch, and the whole sequence stacks when the panel gets narrow. */
.gp-flow-map{display:grid;gap:10px;min-width:0;padding:10px 11px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-alias-bg-layer-1)}
.gp-flow-map__head{font-size:12px;font-weight:600;color:var(--dsw-alias-label-secondary)}
.gp-flow-chain{display:flex;align-items:flex-start;gap:6px;min-width:0}
.gp-flow-chain__col{display:grid;flex:1 1 0;gap:4px;min-width:0}
.gp-flow-chain__h{flex:0 0 auto;white-space:nowrap;display:grid;justify-items:center;gap:1px;padding-top:1px;text-align:center}
.gp-flow-chain__h,.gp-flow-chain__v{color:var(--dsw-alias-label-secondary);font-size:10px;line-height:1.25;overflow-wrap:anywhere}
.gp-flow-arrow{display:block;width:22px;height:12px;flex:none;color:var(--dsw-alias-state-business-primary)}
.gp-flow-arrow--down{transform:rotate(90deg)}
.gp-flow-chain__remote{display:grid;gap:4px;min-width:0}
.gp-flow-chain__v{display:flex;align-items:center;gap:1px;min-height:16px}
.gp-flow-chain__v--del,.gp-flow-chain__v--del .gp-flow-arrow,.gp-flow-map__delete{color:var(--dsw-alias-state-error-primary)}
.gp-flow-map__node{--gp-flow-lane:var(--dsw-alias-label-tertiary);display:flex;flex-wrap:wrap;align-items:center;gap:4px 6px;min-width:0;min-height:29px;padding:4px 7px;border:1px solid var(--dsw-alias-border-l2);border-radius:6px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);font-size:11px;line-height:1.35;box-sizing:border-box}
.gp-flow-map__node--main,.gp-flow-about__lane--main{--gp-flow-lane:var(--dsw-alias-state-success-primary)}
.gp-flow-map__node--develop,.gp-flow-about__lane--develop{--gp-flow-lane:var(--dsw-alias-state-business-primary)}
.gp-flow-map__node--feature,.gp-flow-about__lane--feature{--gp-flow-lane:var(--dsw-alias-state-warn-primary)}
.gp-flow-map__node--release,.gp-flow-about__lane--release{--gp-flow-lane:var(--dsw-alias-label-primary)}
.gp-flow-map__node--hotfix,.gp-flow-about__lane--hotfix{--gp-flow-lane:var(--dsw-alias-state-error-primary)}
.gp-flow-map__dot{width:6px;height:6px;border-radius:50%;flex:none;background:var(--gp-flow-lane)}
.gp-flow-map__name{min-width:0;flex:1 1 0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:var(--dsw-font-mono,ui-monospace,monospace)}
.gp-flow-map__node--new{border-style:dashed;border-color:color-mix(in srgb,var(--gp-flow-lane) 45%,var(--dsw-alias-border-l2));background:color-mix(in srgb,var(--gp-flow-lane) 7%,var(--dsw-alias-bg-layer-2))}
.gp-flow-map__node--gone{border-color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 40%,var(--dsw-alias-border-l2))}
.gp-flow-map__node--gone .gp-flow-map__name{text-decoration:line-through;text-decoration-color:var(--dsw-alias-state-error-primary)}
.gp-flow-map__node--remote{min-height:24px;font-size:10px}
.gp-flow-map__delete{font-size:10px;overflow-wrap:anywhere}
.gp-flow-map__tag,.gp-flow-map__publish-tags code{padding:1px 4px;border-radius:4px;background:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 15%,var(--dsw-alias-bg-layer-2));color:var(--dsw-alias-label-primary);font-size:10px;overflow-wrap:anywhere}
.gp-flow-map__tag{min-width:0;max-width:100%}
.gp-flow-map__tag-label{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}
.gp-flow-map__publish-tags{display:flex;flex-wrap:wrap;align-items:center;gap:5px;min-width:0;font-size:10px;color:var(--dsw-alias-label-secondary)}
.gp-flow-map__publish-tags code{min-width:0}
.gp-flow-map__note{padding-top:6px;border-top:1px solid var(--dsw-alias-border-l2);font-size:11px;color:var(--dsw-alias-state-error-primary)}
@container (max-width:380px){
  .gp-flow-chain{flex-direction:column;align-items:stretch;gap:2px}
  .gp-flow-chain__col,.gp-flow-chain__h{flex:none}
  .gp-flow-chain__h{display:flex;flex-direction:row-reverse;justify-content:flex-end;align-items:center;gap:2px;text-align:start;min-height:18px}
  .gp-flow-chain__h .gp-flow-arrow{transform:rotate(90deg)}
  .gp-flow-chain__remote{margin-inline-start:14px;padding-inline-start:6px;border-inline-start:1px solid var(--dsw-alias-border-l2)}
}
.gp-btn--sm{height:24px;padding:0 8px;font-size:11px}
.gp-btn--danger{border-color:transparent;background:var(--dsw-alias-state-error-primary);color:#fff}
.gp-btn--danger:hover:not(:disabled){background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 85%,#000);color:#fff}

/* file properties dialog: grouped label/value rows. Emphasis comes from
 * weight/color (bold name & numbers, tinted Git chips), not from layout.
 * Groups after the first are separated by a hairline so the section titles
 * read as dividers instead of floating among the rows. */
.gp-props__group{display:flex;flex-direction:column;gap:2px}
.gp-props__group + .gp-props__group{border-top:1px solid var(--dsw-alias-border-l2);padding-top:10px;margin-top:2px}
.gp-props__group-title{font-size:12px;font-weight:650;letter-spacing:0.01em;color:var(--dsw-alias-label-primary);margin-bottom:5px}
.gp-props__row{display:flex;align-items:baseline;gap:12px;min-height:22px}
.gp-props__label{flex:none;width:84px;color:var(--dsw-alias-label-secondary);font-size:12px}
.gp-props__value{flex:1;min-width:0;display:flex;flex-wrap:wrap;align-items:baseline;justify-content:flex-end;gap:6px;color:var(--dsw-alias-label-primary);font-size:12px;text-align:right;overflow-wrap:anywhere}
.gp-props__strong{font-weight:650;font-variant-numeric:tabular-nums}
.gp-props__sub{color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}
.gp-props__mono{font-family:var(--dsw-font-mono,monospace);font-size:11px;user-select:all}
/* Path values are copy targets (hover shows the affordance). */
.gp-props__copy{border:0;background:transparent;padding:2px 4px;margin:-2px 0;font:inherit;color:inherit;text-align:right;cursor:pointer;border-radius:5px;min-width:0}
.gp-props__copy:hover{background:var(--dsw-alias-interactive-bg-hover)}
.gp-props__copy:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:1px}
.gp-props__copy .gp-props__mono{font-size:11px}
/* Footer status bar: Git chips pinned left, copy feedback right, both
 * vertically centered; always rendered (fixed height) so feedback never
 * resizes the dialog. */
.gp-props__statusbar{min-height:34px;padding:6px 14px;justify-content:space-between;align-items:center;border-top:1px solid var(--dsw-alias-border-l2)}
.gp-props__footer-chips{display:inline-flex;flex-wrap:wrap;align-items:center;gap:6px;min-width:0}
/* Copy feedback: info blue at reduced presence — success green would clash
 * with the green "tracked" chip on the same bar. */
.gp-props__copied{font-size:12px;font-weight:600;color:color-mix(in srgb,var(--dsw-alias-state-business-primary) 60%,transparent);white-space:nowrap}
.gp-props__copied--err{color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 75%,transparent)}
/* Git chips: status colors arrive via gp-status--* (currentColor-based),
 * painted as a soft tinted pill so states pop without shouting. */
.gp-props__badge{display:inline-block;padding:1.5px 9px;border-radius:999px;font-size:11px;font-weight:600;line-height:1.5;border:1px solid color-mix(in srgb,currentColor 30%,transparent);background:color-mix(in srgb,currentColor 12%,transparent);white-space:nowrap}
.gp-props__badge--ok{color:var(--dsw-alias-state-success-primary)}
.gp-props__badge--muted{color:var(--dsw-alias-label-tertiary)}
/* comparison pickers (file menu → compare with a branch / tag / revision): a
 * fixed-height list dialog. The head (file + search) and the key hints stay put;
 * only the list scrolls, so the virtualized rows always have a bounded viewport.
 * One highlight per list: the pointer moves the keyboard cursor rather than
 * painting a second hover fill. */
.gp-modal--picker{width:min(540px,92vw)}
.gp-modal--picker .gp-modal__form{padding:0;gap:0;overflow:hidden}
.gp-compare__head{flex:none;display:flex;flex-direction:column;gap:10px;padding:12px 14px;border-bottom:1px solid var(--dsw-alias-border-l1,var(--dsw-alias-border-l2))}
.gp-compare__file{display:flex;align-items:center;gap:6px;min-width:0;font-size:12px;line-height:18px}
.gp-compare__file-icon{display:inline-flex;flex:none;color:var(--dsw-alias-label-tertiary)}
.gp-compare__dir{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-tertiary);margin-right:-6px}
.gp-compare__name{flex:0 0 auto;max-width:75%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-primary);font-weight:600}
.gp-compare__search{position:relative;display:flex;align-items:center;height:34px;padding:0 10px 0 32px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-alias-bg-layer-1);box-sizing:border-box;cursor:text;transition:border-color .12s ease,box-shadow .12s ease}
.gp-compare__search:focus-within{border-color:var(--dsw-alias-state-business-primary);box-shadow:0 0 0 3px color-mix(in srgb,var(--dsw-alias-state-business-primary) 16%,transparent)}
.gp-compare__search-icon{position:absolute;left:10px;top:50%;transform:translateY(-50%);display:inline-flex;color:var(--dsw-alias-label-tertiary);pointer-events:none}
.gp-compare__filter{flex:1;min-width:0;height:100%;padding:0;border:0;outline:none;background:transparent;color:var(--dsw-alias-label-primary);font:inherit;font-size:13px}
.gp-compare__filter::placeholder{color:var(--dsw-alias-label-tertiary)}
.gp-compare__total{flex:none;margin-left:8px;font-size:11px;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-tertiary)}
.gp-compare__list{flex:none;height:min(340px,48vh);padding:4px 6px;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;box-sizing:border-box}
.gp-compare__heading{display:flex;align-items:center;gap:6px;padding:6px 10px 0;box-sizing:border-box;font-size:11px;font-weight:600;letter-spacing:.02em;color:var(--dsw-alias-label-tertiary);user-select:none}
.gp-compare__count{padding:0 6px;border-radius:999px;font-weight:500;line-height:16px;font-variant-numeric:tabular-nums;background:color-mix(in srgb,var(--dsw-alias-label-primary) 7%,transparent)}
.gp-compare__row{display:flex;align-items:center;gap:9px;padding:0 10px;box-sizing:border-box;border-radius:7px;font-size:13px;color:var(--dsw-alias-label-primary);cursor:pointer;user-select:none}
.gp-compare__row--active{background:var(--dsw-alias-interactive-bg-hover)}
.gp-compare__icon{display:inline-flex;flex:none;width:16px;justify-content:center;color:var(--dsw-alias-label-tertiary)}
.gp-compare__row--active .gp-compare__icon{color:var(--dsw-alias-label-secondary)}
.gp-compare__icon--current,.gp-compare__row--active .gp-compare__icon--current{color:var(--dsw-alias-state-warn-primary,var(--dsw-alias-state-business-primary))}
.gp-compare__label{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.gp-compare__badge{margin-left:0}
.gp-compare__hash{flex:none;font-family:var(--dsw-font-mono,ui-monospace,monospace);font-size:11px;color:var(--dsw-alias-label-tertiary)}
.gp-compare__body{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:3px}
.gp-compare__meta{display:flex;align-items:center;gap:8px;min-width:0;font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary);white-space:nowrap}
.gp-compare__meta .gp-compare__hash{padding:0 5px;border-radius:4px;background:color-mix(in srgb,var(--dsw-alias-label-primary) 7%,transparent)}
.gp-compare__author{min-width:0;overflow:hidden;text-overflow:ellipsis}
.gp-compare__when{flex:none}
.gp-compare__author+.gp-compare__when::before{content:"·";margin-right:8px}
.gp-compare__state{display:flex;align-items:center;justify-content:center;gap:8px;height:100%;font-size:12px;color:var(--dsw-alias-label-tertiary)}
.gp-compare__more{display:flex;justify-content:center;padding:8px 0 10px}
.gp-compare__more-btn{height:26px;padding:0 14px;font-size:12px}
.gp-compare__keys{flex:none;padding:7px 14px;border-top:1px solid var(--dsw-alias-border-l1,var(--dsw-alias-border-l2));font-size:11px;color:var(--dsw-alias-label-tertiary)}
@media (hover:none){.gp-compare__keys{display:none}}
`
