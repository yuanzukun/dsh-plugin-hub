/**
 * Plugin detail page config form (the `plugins.bundle.config` slot body).
 *
 * Renders the `showInputPill` switch bound to this bundle's volatile Config
 * field through the settings `configForms` service — the openviking-manager
 * detail-page pattern (explicit slot registration; no auto-generated form
 * exists). The mirror namespace is discovered by schema shape, so the form
 * follows the Host entry id instead of assuming it.
 */
import { createElement as h, useEffect, useMemo, useState } from 'react'
import type { ChangeEvent, JSX } from 'react'
import { resyncAll } from './registry'
import { segButtons } from './seg'
import type { ClientCtx, ConfigFormsFace, SettingsNamespaceView } from './rpc'
import type { GraphStyle } from './types'
import type { GitKey } from './locales'

interface PillConfigProps {
  readonly ctx: ClientCtx
  readonly t: (key: GitKey, params?: Record<string, string | number>) => string
}

/** The settings namespace whose schema declares `showInputPill` (ours). */
function findNamespace(namespaces: readonly SettingsNamespaceView[]): string | undefined {
  for (const row of namespaces) {
    const dict = (row.schema as { dict?: Record<string, unknown> } | undefined)?.dict
    if (dict !== undefined && 'showInputPill' in dict) return row.ns
    if (JSON.stringify(row.schema).includes('showInputPill')) return row.ns
  }
  return undefined
}

type DiffView = 'unified' | 'split'

export function PillConfig({ ctx, t }: PillConfigProps): JSX.Element {
  const [, setTick] = useState(0)
  const [busy, setBusy] = useState(false)
  const [failed, setFailed] = useState(false)
  const [pending, setPending] = useState<boolean | null>(null)
  const [pendingView, setPendingView] = useState<DiffView | null>(null)
  const [pendingGraph, setPendingGraph] = useState<GraphStyle | null>(null)
  const [pendingSuggest, setPendingSuggest] = useState<boolean | null>(null)
  const bump = (): void => { setTick((n) => n + 1) }

  const forms = ctx.get('configForms') as ConfigFormsFace | undefined
  // Memoize the describe/get faces per source so a host that returns a fresh
  // face each render doesn't tear down and re-open the subscriptions below.
  const mirror = useMemo(() => forms?.describe(), [forms])

  useEffect(() => {
    if (mirror === undefined) return
    void mirror.ensure()
    return mirror.subscribe(bump)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mirror])

  // Resolved once per mirror view (not per render): the schema scan is the
  // only costly step and the namespaces rarely change identity.
  const view = mirror?.getSnapshot().view
  const ns = useMemo(() => (view === undefined ? undefined : findNamespace(view.namespaces)), [view])
  const form = useMemo(() => (forms !== undefined && ns !== undefined ? forms.get(ns) : undefined), [forms, ns])

  useEffect(() => {
    if (form === undefined) return
    return form.subscribe(bump)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form])

  const snap = form?.getSnapshot()
  const loaded = form !== undefined && snap !== undefined && snap.status === 'ready'
  const mirrorStatus = mirror?.getSnapshot().status
  const checked = pending ?? (typeof snap?.value?.showInputPill === 'boolean' ? (snap.value.showInputPill as boolean) : true)
  const diffView: DiffView = pendingView ?? (snap?.value?.defaultDiffView === 'split' ? 'split' : 'unified')
  const graphStyle: GraphStyle = pendingGraph ?? (snap?.value?.graphStyle === 'compact' ? 'compact' : 'parallel')
  const suggestEnabled = pendingSuggest ?? (typeof snap?.value?.suggestEnabled === 'boolean' ? (snap.value.suggestEnabled as boolean) : true)

  // Write one config field, then resync so the pill/tab-dot reflect it without
  // waiting for the next poll; `clearPending` resets that field's optimistic
  // value. A snapshot already in flight when the write lands wins the first
  // resync with pre-write values, so a second re-pull bounds that race.
  const commitField = async (field: string, next: unknown, clearPending: () => void): Promise<void> => {
    if (form === undefined) return
    setFailed(false)
    setBusy(true)
    try {
      const ok = await form.set(field, next)
      clearPending()
      if (!ok) setFailed(true)
      else { resyncAll(); setTimeout(() => resyncAll(), 1000) }
    } catch {
      clearPending()
      setFailed(true)
    } finally {
      setBusy(false)
    }
  }

  const toggle = (next: boolean): Promise<void> => {
    setPending(next)
    return commitField('showInputPill', next, () => setPending(null))
  }

  const setView = (next: DiffView): Promise<void> => {
    if (next === diffView) return Promise.resolve()
    setPendingView(next)
    return commitField('defaultDiffView', next, () => setPendingView(null))
  }

  const setGraph = (next: GraphStyle): Promise<void> => {
    if (next === graphStyle) return Promise.resolve()
    setPendingGraph(next)
    return commitField('graphStyle', next, () => setPendingGraph(null))
  }

  const toggleSuggest = (next: boolean): Promise<void> => {
    setPendingSuggest(next)
    return commitField('suggestEnabled', next, () => setPendingSuggest(null))
  }

  if (forms === undefined) return h('p', { className: 'gp-cfg__hint' }, t('cfg.notLoaded'))
  if (!loaded) {
    if (mirrorStatus === 'idle' || mirrorStatus === 'loading') return h('p', { className: 'gp-cfg__hint' }, t('common.loading'))
    return h('p', { className: 'gp-cfg__hint' }, t('cfg.notLoaded'))
  }

  return h('div', { className: 'gp-cfg' }, [
    h('h3', { key: 'title', className: 'gp-cfg__title' }, t('cfg.title')),
    h('label', { key: 'row', className: 'gp-cfg__row' }, [
      h('input', {
        key: 'switch', type: 'checkbox', role: 'switch', className: 'gp-cfg__switch',
        checked, disabled: busy || snap?.writable === false,
        onChange: (e: ChangeEvent<HTMLInputElement>) => { void toggle(e.currentTarget.checked) },
      }),
      h('span', { key: 'text', className: 'gp-cfg__text' }, t('cfg.toggle')),
    ]),
    h('p', { key: 'hint', className: 'gp-cfg__hint' }, t('cfg.hint')),
    h('h3', { key: 'difftitle', className: 'gp-cfg__title', style: { marginTop: 6 } }, t('cfg.diffTitle')),
    h('div', { key: 'diffseg', className: 'gp-seg gp-cfg__seg' },
      segButtons<DiffView>(['unified', 'split'], diffView, (v) => { void setView(v) },
        (v) => t(v === 'unified' ? 'cfg.diffUnified' : 'cfg.diffSplit'), busy || snap?.writable === false)),
    h('p', { key: 'diffhint', className: 'gp-cfg__hint' }, t('cfg.diffHint')),
    h('h3', { key: 'graphtitle', className: 'gp-cfg__title', style: { marginTop: 6 } }, t('cfg.graphTitle')),
    h('div', { key: 'graphseg', className: 'gp-seg gp-cfg__seg' },
      segButtons<GraphStyle>(['parallel', 'compact'], graphStyle, (v) => { void setGraph(v) },
        (v) => t(v === 'parallel' ? 'cfg.graphParallel' : 'cfg.graphCompact'), busy || snap?.writable === false)),
    h('p', { key: 'graphhint', className: 'gp-cfg__hint' }, t('cfg.graphHint')),
    h('h3', { key: 'sgtitle', className: 'gp-cfg__title', style: { marginTop: 6 } }, t('cfg.suggestTitle')),
    h('label', { key: 'sgrow', className: 'gp-cfg__row' }, [
      h('input', {
        key: 'switch', type: 'checkbox', role: 'switch', className: 'gp-cfg__switch',
        checked: suggestEnabled, disabled: busy || snap?.writable === false,
        onChange: (e: ChangeEvent<HTMLInputElement>) => { void toggleSuggest(e.currentTarget.checked) },
      }),
      h('span', { key: 'text', className: 'gp-cfg__text' }, t('cfg.suggestToggle')),
    ]),
    h('p', { key: 'sghint', className: 'gp-cfg__hint' }, t('cfg.suggestHint')),
    failed ? h('p', { key: 'error', className: 'gp-cfg__err', role: 'alert' }, t('cfg.saveFailed')) : null,
  ])
}
