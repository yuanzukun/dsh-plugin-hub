/**
 * Plugin detail page config form (the `plugins.bundle.config` slot body).
 *
 * Renders the `showInputPill` switch bound to this bundle's volatile Config
 * field through the settings `configForms` service — the openviking-manager
 * detail-page pattern (explicit slot registration; no auto-generated form
 * exists). The mirror namespace is discovered by schema shape, so the form
 * follows the Host entry id instead of assuming it.
 */
import { createElement as h, useEffect, useMemo, useRef, useState } from 'react'
import type { ChangeEvent, JSX } from 'react'
import { Menu, type MenuItem } from '@deepseek-ai/dsh-client-ui-primitives'
import { findNamespace, resyncAfterWrite } from './config-write.js'
import { ChevronIcon, RepoIcon, ScreenIcon, SlidersIcon, SparkleIcon } from './icons.js'
import { normalizePlacement } from './placement.js'
import { segButtons } from './seg.js'
import { effortForModel, modelForProvider } from './model-route.js'
import { selectTrigger } from './select-trigger.js'
import { gitPanelRemoteOf, queryAs } from './rpc.js'
import type { ClientCtx, ConfigFormsFace } from './rpc.js'
import type { ChangesViewMode, FontDelta, GitPanelPlacement, GraphStyle, ModelCatalogGroup, SuggestLanguage } from './types.js'
import { EDITABLE_EXTENSIONS, EDITABLE_FILENAMES, REPO_LIMITS, SUGGEST_LANGUAGES, SUGGEST_LANGUAGE_DEFAULT, SUGGEST_LIMITS } from './types.js'
import type { GitKey } from './locales.js'

interface PillConfigProps {
  readonly ctx: ClientCtx
  readonly t: (key: GitKey, params?: Record<string, string | number>) => string
}

type DiffView = 'unified' | 'split'

/** Config sections; only `basic` boots expanded. */
type SectionId = 'basic' | 'view' | 'suggest' | 'repos'

/** Section marks: identity at a glance while a section's body is collapsed. */
const SECTION_GLYPH: Record<SectionId, (props: { readonly size?: number }) => JSX.Element> = {
  basic: SlidersIcon,
  view: ScreenIcon,
  suggest: SparkleIcon,
  repos: RepoIcon,
}

/** Per-section icon tone: three semantic hues plus a neutral for the section
 * whose colour would read as a warning. Drives the `--<tone>` chip modifier. */
const SECTION_TONE: Record<SectionId, 'business' | 'success' | 'warn' | 'neutral'> = {
  basic: 'business',
  view: 'success',
  suggest: 'warn',
  repos: 'neutral',
}

/** Catalog load lifecycle for the model cascading selects. */
type CatalogStatus = 'idle' | 'loading' | 'ready' | 'error'

/** Model-catalog is host-level; the request type still carries sessionId. */
const SESSION_PLACEHOLDER = ''

// Suggest-limit display units, derived from the host units in SUGGEST_LIMITS
// (bytes / tokens / ms) so the form's ranges and fallbacks cannot drift from
// what normalizeConfig actually enforces. The divisions are exact (guarded by
// test) and the fallbacks mirror the host DEFAULT_CONFIG.
const MAX_KIB = { min: SUGGEST_LIMITS.maxBytes.min / 1024, max: SUGGEST_LIMITS.maxBytes.max / 1024 }
const TIMEOUT_S = { min: SUGGEST_LIMITS.timeoutMs.min / 1000, max: SUGGEST_LIMITS.timeoutMs.max / 1000 }

/** Clamp a display value into its range, mirroring the host-side enforcement
 * (normalizeConfig floors, so the form floors too — same rounding everywhere). */
function clampDisplay(v: number, range: { readonly min: number; readonly max: number }): number {
  return Math.min(range.max, Math.max(range.min, Math.floor(v)))
}

/** Parse a numeric draft; null when blank/unparseable (caller keeps the current value). */
function parseDraft(raw: string): number | null {
  const trimmed = raw.trim()
  if (trimmed === '') return null
  const n = Number(trimmed)
  return Number.isFinite(n) ? n : null
}

export function PillConfig({ ctx, t }: PillConfigProps): JSX.Element {
  const [, setTick] = useState(0)
  const [busy, setBusy] = useState(false)
  const [failed, setFailed] = useState(false)
  const [pending, setPending] = useState<boolean | null>(null)
  const [pendingPlacement, setPendingPlacement] = useState<GitPanelPlacement | null>(null)
  const [pendingView, setPendingView] = useState<DiffView | null>(null)
  const [pendingChangesView, setPendingChangesView] = useState<ChangesViewMode | null>(null)
  const [pendingGraph, setPendingGraph] = useState<GraphStyle | null>(null)
  const [pendingFont, setPendingFont] = useState<FontDelta | null>(null)
  const [pendingSuggest, setPendingSuggest] = useState<boolean | null>(null)
  const [pendingDetect, setPendingDetect] = useState<boolean | null>(null)
  const [pendingFollow, setPendingFollow] = useState<boolean | null>(null)
  const [pendingFold, setPendingFold] = useState<boolean | null>(null)
  const [pendingEdit, setPendingEdit] = useState<boolean | null>(null)
  const [pendingPackages, setPendingPackages] = useState<boolean | null>(null)
  // Workspace file: three states in one string value (`off` / `auto` / a file
  // name). `customOpen` shows the name box before a name exists; `draftName`
  // keeps typing local until Enter or blur commits.
  const [pendingWorkspace, setPendingWorkspace] = useState<string | null>(null)
  const [customOpen, setCustomOpen] = useState(false)
  const [draftName, setDraftName] = useState<string | null>(null)
  const [workspaceNameInvalid, setWorkspaceNameInvalid] = useState(false)
  // Picking another mode while the name box is focused must write once, not
  // twice: the blur commits the name and the click commits the mode, in that
  // order, so the mode the user just picked would be overwritten by a write
  // they were already abandoning. The press is the signal, and it arrives
  // before the blur.
  const skipNameCommit = useRef(false)
  const [openSections, setOpenSections] = useState<Record<SectionId, boolean>>({ basic: true, view: false, suggest: false, repos: false })
  const [pendingLang, setPendingLang] = useState<SuggestLanguage | null>(null)
  // Numeric drafts are local edit state: onChange only updates the draft so
  // typing is never blocked mid-edit; blur/Enter parses, clamps and commits.
  const [draftMaxKib, setDraftMaxKib] = useState<string | null>(null)
  const [draftOutputTokens, setDraftOutputTokens] = useState<string | null>(null)
  const [draftTimeout, setDraftTimeout] = useState<string | null>(null)
  const [draftRepoLimit, setDraftRepoLimit] = useState<string | null>(null)
  // Model catalog: host-level providers / models / efforts.
  const [catalog, setCatalog] = useState<readonly ModelCatalogGroup[]>([])
  const [catalogFailures, setCatalogFailures] = useState<readonly { id: string; name: string; message: string }[]>([])
  const [catalogStatus, setCatalogStatus] = useState<CatalogStatus>('idle')
  // In-flight model-route write: the optimistic value while the write is in
  // flight — and, for an incomplete pair (provider without model), until the
  // next selection, because the host drops that half from the live config so
  // the snapshot alone cannot hold "provider picked".
  const [pendingRoute, setPendingRoute] = useState<{ provider: string; model: string; effort: string } | null>(null)
  // Platform Menu is controlled; the caller toggles open state per row.
  const [providerOpen, setProviderOpen] = useState(false)
  const [modelOpen, setModelOpen] = useState(false)
  const [effortOpen, setEffortOpen] = useState(false)
  const bump = (): void => { setTick((n) => n + 1) }

  const forms = ctx.get('configForms') as ConfigFormsFace | undefined
  // Memoize the describe/get faces per source so a host that returns a fresh
  // face each render doesn't tear down and re-open the subscriptions below.
  const mirror = useMemo(() => forms?.describe(), [forms])

  useEffect(() => {
    if (mirror === undefined) return
    void mirror.ensure()
    return mirror.subscribe(bump)
  }, [mirror])

  // Resolved once per mirror view (not per render): the schema scan is the
  // only costly step and the namespaces rarely change identity.
  const view = mirror?.getSnapshot().view
  const ns = useMemo(() => (view === undefined ? undefined : findNamespace(view.namespaces)), [view])
  const form = useMemo(() => (forms !== undefined && ns !== undefined ? forms.get(ns) : undefined), [forms, ns])

  useEffect(() => {
    if (form === undefined) return
    return form.subscribe(bump)
  }, [form])

  const snap = form?.getSnapshot()
  const loaded = form !== undefined && snap !== undefined && snap.status === 'ready'
  const mirrorStatus = mirror?.getSnapshot().status
  const checked = pending ?? (typeof snap?.value?.showInputPill === 'boolean' ? (snap.value.showInputPill as boolean) : true)
  const placement: GitPanelPlacement = pendingPlacement ?? normalizePlacement(snap?.value?.placement)
  const diffView: DiffView = pendingView ?? (snap?.value?.defaultDiffView === 'split' ? 'split' : 'unified')
  const changesView: ChangesViewMode = pendingChangesView ?? (snap?.value?.changesView === 'tree' ? 'tree' : 'flat')
  const graphStyle: GraphStyle = pendingGraph ?? (snap?.value?.graphStyle === 'compact' ? 'compact' : 'parallel')
  const fontDelta: FontDelta = pendingFont
    ?? (snap?.value?.fontDelta === -1 || snap?.value?.fontDelta === 1 ? (snap.value.fontDelta as FontDelta) : 0)
  const suggestEnabled = pendingSuggest ?? (typeof snap?.value?.suggestEnabled === 'boolean' ? (snap.value.suggestEnabled as boolean) : true)
  const detectCheckouts = pendingDetect ?? (typeof snap?.value?.detectCheckouts === 'boolean' ? (snap.value.detectCheckouts as boolean) : true)
  const filesFollowRepo = pendingFollow ?? (typeof snap?.value?.filesFollowRepo === 'boolean' ? (snap.value.filesFollowRepo as boolean) : false)
  const collapseReposOnPick = pendingFold ?? (typeof snap?.value?.collapseReposOnPick === 'boolean' ? (snap.value.collapseReposOnPick as boolean) : false)
  const allowFileEdit = pendingEdit ?? (typeof snap?.value?.allowFileEdit === 'boolean' ? (snap.value.allowFileEdit as boolean) : true)
  const compactPackages = pendingPackages ?? (typeof snap?.value?.compactPackages === 'boolean' ? (snap.value.compactPackages as boolean) : true)
  const snapshotWorkspace = typeof snap?.value?.codeWorkspace === 'string' ? (snap.value.codeWorkspace as string).trim() : ''
  const rawWorkspace = pendingWorkspace ?? snapshotWorkspace
  const workspaceMode: 'off' | 'auto' | 'custom' = rawWorkspace === 'auto' ? 'auto' : rawWorkspace === '' || rawWorkspace === 'off' ? 'off' : 'custom'
  const showWorkspaceName = customOpen || workspaceMode === 'custom'
  const workspaceName = draftName ?? (workspaceMode === 'custom' ? rawWorkspace : '')
  const rawLang = snap?.value?.suggestLanguage
  const suggestLanguage: SuggestLanguage = pendingLang
    ?? (typeof rawLang === 'string' && (SUGGEST_LANGUAGES as readonly string[]).includes(rawLang) ? rawLang as SuggestLanguage : SUGGEST_LANGUAGE_DEFAULT)
  // Display values: derive from the RAW snapshot value into the display unit,
  // clamped into range so the form shows what the host will actually enforce
  // (an out-of-range value written outside this form is clamped host-side too).
  const suggestMaxKib = clampDisplay(
    typeof snap?.value?.suggestMaxBytes === 'number' ? (snap.value.suggestMaxBytes as number) / 1024 : SUGGEST_LIMITS.maxBytes.default / 1024,
    MAX_KIB,
  )
  const suggestOutputTokens = clampDisplay(
    typeof snap?.value?.suggestMaxOutputTokens === 'number' ? (snap.value.suggestMaxOutputTokens as number) : SUGGEST_LIMITS.maxOutputTokens.default,
    SUGGEST_LIMITS.maxOutputTokens,
  )
  const suggestTimeoutS = clampDisplay(
    typeof snap?.value?.suggestTimeoutMs === 'number' ? (snap.value.suggestTimeoutMs as number) / 1000 : SUGGEST_LIMITS.timeoutMs.default / 1000,
    TIMEOUT_S,
  )
  const repoLimit = clampDisplay(
    typeof snap?.value?.repoLimit === 'number' ? (snap.value.repoLimit as number) : REPO_LIMITS.default,
    REPO_LIMITS,
  )
  // Model route: pending write wins over the snapshot. Provider alone drives
  // the model row; model alone drives the effort row. The effort select is
  // blank until both halves of the pair are set.
  const rawProvider = typeof snap?.value?.suggestProvider === 'string' ? (snap.value.suggestProvider as string) : ''
  const rawModel = typeof snap?.value?.suggestModel === 'string' ? (snap.value.suggestModel as string) : ''
  const rawEffort = typeof snap?.value?.suggestReasoningEffort === 'string' ? (snap.value.suggestReasoningEffort as string) : ''
  const uiProvider = pendingRoute?.provider ?? rawProvider
  const uiModel = pendingRoute !== null ? pendingRoute.model : (rawProvider !== '' ? rawModel : '')
  const uiEffort = pendingRoute !== null ? pendingRoute.effort : rawEffort
  const fixedEffort = uiProvider !== '' && uiModel !== '' ? uiEffort : ''
  const activeGroup = catalog.find((g) => g.id === uiProvider)
  const activeModel = activeGroup?.models.find((m) => m.id === uiModel)
  const efforts = activeModel?.reasoning?.efforts

  // Load the host catalog once the config form is readable; reload on demand.
  const loadCatalog = (): void => {
    setCatalogStatus('loading')
    void gitPanelRemoteOf(ctx)
      .query({ sessionId: SESSION_PLACEHOLDER, query: { kind: 'model-catalog' } })
      .then((res) => {
        const value = queryAs(res, 'model-catalog')
        if (value === null) {
          setCatalogStatus('error')
          return
        }
        setCatalog(value.groups)
        setCatalogFailures(value.failures)
        setCatalogStatus('ready')
      })
      .catch(() => { setCatalogStatus('error') })
  }

  useEffect(() => {
    if (!loaded) return
    if (catalogStatus !== 'idle') return
    loadCatalog()
    // Intentionally once per form load: reload is the retry button's job.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded])

  // Write one config field, then resync so the pill/tab-dot reflect it without
  // waiting for the next poll; `clearPending` resets that field's optimistic
  // value. A snapshot already in flight when the write lands wins the first
  // resync with pre-write values, so a second re-pull bounds that race.
  const commitField = async (field: string, next: unknown, clearPending: () => void): Promise<void> => {
    if (form === undefined) return
    setFailed(false)
    setBusy(true)
    try {
      const ok = await form.set(field, next)
      clearPending()
      if (!ok) setFailed(true)
      else resyncAfterWrite()
    } catch {
      clearPending()
      setFailed(true)
    } finally {
      setBusy(false)
    }
  }

  const toggle = (next: boolean): Promise<void> => {
    setPending(next)
    return commitField('showInputPill', next, () => setPending(null))
  }

  const setPlacement = (next: GitPanelPlacement): Promise<void> => {
    if (next === placement) return Promise.resolve()
    setPendingPlacement(next)
    return commitField('placement', next, () => setPendingPlacement(null))
  }

  const setView = (next: DiffView): Promise<void> => {
    if (next === diffView) return Promise.resolve()
    setPendingView(next)
    return commitField('defaultDiffView', next, () => setPendingView(null))
  }

  const setChangesView = (next: ChangesViewMode): Promise<void> => {
    if (next === changesView) return Promise.resolve()
    setPendingChangesView(next)
    return commitField('changesView', next, () => setPendingChangesView(null))
  }

  const setGraph = (next: GraphStyle): Promise<void> => {
    if (next === graphStyle) return Promise.resolve()
    setPendingGraph(next)
    return commitField('graphStyle', next, () => setPendingGraph(null))
  }

  const setFont = (next: FontDelta): Promise<void> => {
    if (next === fontDelta) return Promise.resolve()
    setPendingFont(next)
    return commitField('fontDelta', next, () => setPendingFont(null))
  }

  const toggleSuggest = (next: boolean): Promise<void> => {
    setPendingSuggest(next)
    return commitField('suggestEnabled', next, () => setPendingSuggest(null))
  }

  const toggleDetect = (next: boolean): Promise<void> => {
    setPendingDetect(next)
    return commitField('detectCheckouts', next, () => setPendingDetect(null))
  }

  const toggleFilesFollow = (next: boolean): Promise<void> => {
    setPendingFollow(next)
    return commitField('filesFollowRepo', next, () => setPendingFollow(null))
  }

  const toggleFoldOnPick = (next: boolean): Promise<void> => {
    setPendingFold(next)
    return commitField('collapseReposOnPick', next, () => setPendingFold(null))
  }

  const toggleFileEdit = (next: boolean): Promise<void> => {
    setPendingEdit(next)
    return commitField('allowFileEdit', next, () => setPendingEdit(null))
  }

  const togglePackages = (next: boolean): Promise<void> => {
    setPendingPackages(next)
    return commitField('compactPackages', next, () => setPendingPackages(null))
  }

  // The workspace setting has three states, and only one of them carries text:
  // the segmented control writes `off` / `auto` directly, while "specific file"
  // reveals the name box and writes on Enter or blur.
  // The workspace field is the one commit the form holds optimistically until
  // the settings mirror agrees: its third state owns a text box, and a write
  // that clears the pending value on the way back would unmount the box the
  // user is typing in. A late answer clears it after a bound, so a rejected
  // write cannot pin the form to a value the host does not have.
  const writeWorkspace = async (next: string): Promise<void> => {
    if (form === undefined) return
    setFailed(false)
    setBusy(true)
    setPendingWorkspace(next)
    try {
      const ok = await form.set('codeWorkspace', next)
      if (!ok) {
        setPendingWorkspace(null)
        setFailed(true)
      } else {
        resyncAfterWrite()
      }
    } catch {
      setPendingWorkspace(null)
      setFailed(true)
    } finally {
      setBusy(false)
    }
  }

  useEffect(() => {
    if (pendingWorkspace === null) return
    if (snapshotWorkspace === pendingWorkspace) {
      setPendingWorkspace(null)
      setDraftName(null)
      setCustomOpen(false)
      return
    }
    const settle = setTimeout(() => { setPendingWorkspace(null) }, 2000)
    return () => { clearTimeout(settle) }
  }, [pendingWorkspace, snapshotWorkspace])

  const setWorkspaceMode = (next: 'off' | 'auto' | 'custom'): void => {
    setWorkspaceNameInvalid(false)
    if (next === 'custom') {
      setCustomOpen(true)
      if (workspaceMode === 'custom') setDraftName(null)
      return
    }
    setCustomOpen(false)
    setDraftName(null)
    if (next === workspaceMode) return
    void writeWorkspace(next)
  }

  const commitWorkspaceName = (): void => {
    if (skipNameCommit.current) {
      skipNameCommit.current = false
      return
    }
    const name = (draftName ?? '').trim()
    // An empty box is how the user leaves "specific file" without naming one:
    // close it and fall back to the value the host actually has, instead of
    // pinning the control to a state that was never written.
    if (name === '') {
      setWorkspaceNameInvalid(false)
      setDraftName(null)
      setCustomOpen(false)
      return
    }
    // The host validates the shape too; refusing it here keeps a typo from
    // reaching the config (a malformed value is an `invalid` state, not `off`).
    const shaped = name.length <= 255 && name !== '.' && name !== '..' && !/[/\\\0]/.test(name) && name.endsWith('.code-workspace')
    if (!shaped) {
      setWorkspaceNameInvalid(true)
      return
    }
    setWorkspaceNameInvalid(false)
    // The box stays up until the mirror carries the name, so the user's text
    // does not blink out between the write and the next settings read.
    setDraftName(name)
    void writeWorkspace(name)
  }

  const setLanguage = (next: SuggestLanguage): Promise<void> => {
    if (next === suggestLanguage) return Promise.resolve()
    setPendingLang(next)
    return commitField('suggestLanguage', next, () => setPendingLang(null))
  }

  // Write the three route fields together. Empty string is the host's "absent"
  // spelling. An incomplete pair (provider without model) is dropped host-side,
  // so on success the optimistic value is kept until the next selection; every
  // other outcome — including any write failure — drops it and falls back to
  // the snapshot, matching the other pendingX fields.
  const writeModelRoute = async (
    provider: string,
    model: string,
    effort: string,
  ): Promise<void> => {
    if (form === undefined) return
    setFailed(false)
    setBusy(true)
    setPendingRoute({ provider, model, effort })
    let ok = false
    try {
      const okP = await form.set('suggestProvider', provider)
      const okM = await form.set('suggestModel', model)
      const okE = await form.set('suggestReasoningEffort', effort)
      ok = okP && okM && okE
      if (!ok) setFailed(true)
      else resyncAfterWrite()
    } catch {
      setFailed(true)
    } finally {
      setBusy(false)
      if (provider === '' || model !== '' || !ok) setPendingRoute(null)
    }
  }

  const setProvider = (next: string): Promise<void> => {
    if (next === '') return writeModelRoute('', '', '')
    // Keep the model only if it belongs to the new provider, and the effort
    // only if the kept model still advertises it (same rule as setModel).
    const keepModel = modelForProvider(catalog, next, uiModel)
    const keepEffort = effortForModel(catalog, next, keepModel, uiEffort)
    return writeModelRoute(next, keepModel, keepEffort)
  }

  const setModel = (next: string): Promise<void> => {
    if (next === '') return writeModelRoute(uiProvider, '', '')
    // Drop a stale effort when the new model does not advertise it.
    const keepEffort = effortForModel(catalog, uiProvider, next, uiEffort)
    return writeModelRoute(uiProvider, next, keepEffort)
  }

  const setEffort = (next: string): Promise<void> =>
    writeModelRoute(uiProvider, uiModel, next)

  // Commit one numeric draft: parse → clamp to the display-unit range → write
  // in storage units (KiB→bytes, s→ms, tokens as-is; a plain count passes 1).
  // The clamped value is HELD as the draft until the write lands (optimistic,
  // like the pendingX pattern above — clearing early would flash the pre-write
  // live value); commitField clears it on completion, so a failure falls back
  // to the live value beside the error line. A blank/unparseable draft just
  // reverts to the live value without writing.
  const commitNumber = (
    raw: string | null,
    range: { readonly min: number; readonly max: number },
    scale: number,
    field: string,
    setDraft: (v: string) => void,
    clearDraft: () => void,
  ): Promise<void> => {
    const parsed = raw === null ? null : parseDraft(raw)
    if (parsed === null) { clearDraft(); return Promise.resolve() }
    const clamped = Math.min(range.max, Math.max(range.min, Math.floor(parsed)))
    setDraft(String(clamped))
    return commitField(field, clamped * scale, clearDraft)
  }

  const commitMaxKib = (raw: string | null): Promise<void> =>
    commitNumber(raw, MAX_KIB, 1024, 'suggestMaxBytes', setDraftMaxKib, () => setDraftMaxKib(null))

  const commitOutputTokens = (raw: string | null): Promise<void> =>
    commitNumber(raw, SUGGEST_LIMITS.maxOutputTokens, 1, 'suggestMaxOutputTokens', setDraftOutputTokens, () => setDraftOutputTokens(null))

  const commitTimeout = (raw: string | null): Promise<void> =>
    commitNumber(raw, TIMEOUT_S, 1000, 'suggestTimeoutMs', setDraftTimeout, () => setDraftTimeout(null))

  const commitRepoLimit = (raw: string | null): Promise<void> =>
    commitNumber(raw, REPO_LIMITS, 1, 'repoLimit', setDraftRepoLimit, () => setDraftRepoLimit(null))

  // Platform Menu rows: the same dropdown surface as the overview author /
  // since filters. Trigger is ours; Menu never closes itself, so onSelect closes.
  const providerItems: readonly MenuItem[] = [
    { id: '', label: t('cfg.suggestModelSession') },
    ...catalog.map((g) => ({ id: g.id, label: g.name })),
  ]
  const modelItems: readonly MenuItem[] = [
    { id: '', label: t('cfg.suggestModelPick') },
    ...(activeGroup?.models ?? []).map((m) => ({ id: m.id, label: m.name })),
  ]
  const effortItems: readonly MenuItem[] = [
    { id: '', label: t('cfg.suggestEffortUnset') },
    ...(efforts ?? []).map((eff) => ({ id: eff.id, label: eff.name })),
  ]
  const renderMenuTrigger = (
    open: boolean,
    label: string,
    toggle: () => void,
    disabled: boolean,
  ): JSX.Element => selectTrigger(open, label, toggle, { disabled, extraClass: 'gp-cfg__select-trigger' })
  const menuDisabled = busy || snap?.writable === false
  const providerLabel = uiProvider === ''
    ? t('cfg.suggestModelSession')
    : catalog.find((g) => g.id === uiProvider)?.name ?? uiProvider
  const modelLabel = uiModel === ''
    ? t('cfg.suggestModelPick')
    : activeModel?.name ?? uiModel
  const effortLabel = fixedEffort === ''
    ? t('cfg.suggestEffortUnset')
    : efforts?.find((eff) => eff.id === fixedEffort)?.name ?? fixedEffort
  const providerMenu = h(Menu, {
    key: 'provider',
    open: providerOpen,
    onClose: () => setProviderOpen(false),
    items: providerItems,
    selectedId: uiProvider,
    onSelect: (id: string) => {
      setProviderOpen(false)
      void setProvider(id)
    },
    align: 'start',
    portal: true,
    className: 'gp-cfg__menu',
    anchor: renderMenuTrigger(providerOpen, providerLabel, () => setProviderOpen((v) => !v), menuDisabled || catalogStatus === 'loading'),
  })
  const modelMenu = h(Menu, {
    key: 'model',
    open: modelOpen,
    onClose: () => setModelOpen(false),
    items: modelItems,
    selectedId: uiModel,
    onSelect: (id: string) => {
      setModelOpen(false)
      void setModel(id)
    },
    align: 'start',
    portal: true,
    className: 'gp-cfg__menu',
    anchor: renderMenuTrigger(modelOpen, modelLabel, () => setModelOpen((v) => !v), menuDisabled || activeGroup === undefined),
  })
  const effortMenu = h(Menu, {
    key: 'effort',
    open: effortOpen,
    onClose: () => setEffortOpen(false),
    items: effortItems,
    selectedId: fixedEffort,
    onSelect: (id: string) => {
      setEffortOpen(false)
      void setEffort(id)
    },
    align: 'start',
    portal: true,
    className: 'gp-cfg__menu',
    anchor: renderMenuTrigger(effortOpen, effortLabel, () => setEffortOpen((v) => !v), menuDisabled),
  })

  if (forms === undefined) return h('p', { className: 'gp-cfg__hint' }, t('cfg.notLoaded'))
  if (!loaded) {
    if (mirrorStatus === 'idle' || mirrorStatus === 'loading') return h('p', { className: 'gp-cfg__hint' }, t('common.loading'))
    return h('p', { className: 'gp-cfg__hint' }, t('cfg.notLoaded'))
  }

  // One collapsible section: a header button (aria-expanded / aria-controls)
  // over a body that hides while collapsed; only `basic` boots expanded. The
  // header's mark chip is decorative — the title names the button. The body is
  // a column of fields; the section tone also tints the body's guide rule.
  const section = (id: SectionId, title: string, body: readonly (JSX.Element | null)[]): JSX.Element =>
    h('section', { key: id, className: `gp-cfg__section gp-cfg__section--${SECTION_TONE[id]}` }, [
      h('button', {
        key: 'hd',
        type: 'button',
        className: 'gp-cfg__section-hd',
        'aria-expanded': openSections[id] ? 'true' : 'false',
        'aria-controls': `gp-cfg-sec-${id}`,
        onClick: () => { setOpenSections((s) => ({ ...s, [id]: !s[id] })) },
      }, [
        h('span', { key: 'l', className: 'gp-cfg__section-left' }, [
          h('span', {
            key: 'i',
            className: `gp-cfg__section-ic gp-cfg__section-ic--${SECTION_TONE[id]}`,
            'aria-hidden': 'true',
          }, h(SECTION_GLYPH[id], { size: 14 })),
          h('span', { key: 't', className: 'gp-cfg__section-title' }, title),
        ]),
        h(ChevronIcon, { key: 'c', size: 16, open: openSections[id] }),
      ]),
      h('div', {
        key: 'body',
        id: `gp-cfg-sec-${id}`,
        className: 'gp-cfg__section-body',
        hidden: openSections[id] ? undefined : true,
      }, body),
    ])
  // One setting: its title / control / hint grouped, so the gap between fields
  // reads wider than the gap inside one.
  const field = (key: string, children: readonly (JSX.Element | null)[]): JSX.Element =>
    h('div', { key, className: 'gp-cfg__field' }, children)

  const basicBody = [
    field('place', [
      h('h3', { key: 'placetitle', className: 'gp-cfg__title' }, t('cfg.placementTitle')),
      h('div', { key: 'placeseg', className: 'gp-seg gp-cfg__seg', role: 'group', 'aria-label': t('cfg.placementTitle') },
        segButtons<GitPanelPlacement>(['all', 'tab', 'sidebar'], placement, (v) => { void setPlacement(v) },
          (v) => t(v === 'all' ? 'cfg.placementAll' : v === 'tab' ? 'cfg.placementTab' : 'cfg.placementSidebar'), busy || snap?.writable === false)),
      h('p', { key: 'placehint', className: 'gp-cfg__hint' }, t('cfg.placementHint')),
    ]),
    field('pill', [
      h('h3', { key: 'title', className: 'gp-cfg__title' }, t('cfg.title')),
      h('label', { key: 'row', className: 'gp-cfg__row' }, [
        h('input', {
          key: 'switch', type: 'checkbox', role: 'switch', className: 'gp-cfg__switch',
          checked, disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { void toggle(e.currentTarget.checked) },
        }),
        h('span', { key: 'text', className: 'gp-cfg__text' }, t('cfg.toggle')),
      ]),
      h('p', { key: 'hint', className: 'gp-cfg__hint' }, t('cfg.hint')),
    ]),
    field('edit', [
      h('h3', { key: 'edittitle', className: 'gp-cfg__title' }, t('cfg.fileEditTitle')),
      h('label', { key: 'editrow', className: 'gp-cfg__row' }, [
        h('input', {
          key: 'switch', type: 'checkbox', role: 'switch', className: 'gp-cfg__switch',
          checked: allowFileEdit, disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { void toggleFileEdit(e.currentTarget.checked) },
        }),
        h('span', { key: 'text', className: 'gp-cfg__text' }, t('cfg.fileEditToggle')),
      ]),
      h('p', { key: 'edithint', className: 'gp-cfg__hint' }, t('cfg.fileEditHint', { exts: EDITABLE_EXTENSIONS.join(', '), names: EDITABLE_FILENAMES.join(', ') })),
    ]),
  ]
  const viewBody = [
    field('diff', [
      h('h3', { key: 'difftitle', className: 'gp-cfg__title' }, t('cfg.diffTitle')),
      h('div', { key: 'diffseg', className: 'gp-seg gp-cfg__seg' },
        segButtons<DiffView>(['unified', 'split'], diffView, (v) => { void setView(v) },
          (v) => t(v === 'unified' ? 'cfg.diffUnified' : 'cfg.diffSplit'), busy || snap?.writable === false)),
      h('p', { key: 'diffhint', className: 'gp-cfg__hint' }, t('cfg.diffHint')),
    ]),
    field('changesview', [
      h('h3', { key: 'cvtitle', className: 'gp-cfg__title' }, t('changes.view')),
      h('div', { key: 'cvseg', className: 'gp-seg gp-cfg__seg' },
        segButtons<ChangesViewMode>(['flat', 'tree'], changesView, (v) => { void setChangesView(v) },
          (v) => t(v === 'flat' ? 'changes.viewFlat' : 'changes.viewTree'), busy || snap?.writable === false)),
      h('p', { key: 'cvhint', className: 'gp-cfg__hint' }, t('cfg.changesViewHint')),
    ]),
    field('packages', [
      h('label', { key: 'pkgrow', className: 'gp-cfg__row' }, [
        h('input', {
          key: 'switch', type: 'checkbox', role: 'switch', className: 'gp-cfg__switch',
          checked: compactPackages, disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { void togglePackages(e.currentTarget.checked) },
        }),
        h('span', { key: 'text', className: 'gp-cfg__text' }, t('cfg.packagesToggle')),
      ]),
      h('p', { key: 'pkghint', className: 'gp-cfg__hint' }, t('cfg.packagesHint')),
    ]),
    field('graph', [
      h('h3', { key: 'graphtitle', className: 'gp-cfg__title' }, t('cfg.graphTitle')),
      h('div', { key: 'graphseg', className: 'gp-seg gp-cfg__seg' },
        segButtons<GraphStyle>(['parallel', 'compact'], graphStyle, (v) => { void setGraph(v) },
          (v) => t(v === 'parallel' ? 'cfg.graphParallel' : 'cfg.graphCompact'), busy || snap?.writable === false)),
      h('p', { key: 'graphhint', className: 'gp-cfg__hint' }, t('cfg.graphHint')),
    ]),
    field('font', [
      h('h3', { key: 'fonttitle', className: 'gp-cfg__title' }, t('cfg.fontTitle')),
      h('div', { key: 'fontseg', className: 'gp-seg gp-cfg__seg' },
        segButtons<'smaller' | 'default' | 'larger'>(
          ['smaller', 'default', 'larger'],
          fontDelta === -1 ? 'smaller' : fontDelta === 1 ? 'larger' : 'default',
          (v) => { void setFont(v === 'smaller' ? -1 : v === 'larger' ? 1 : 0) },
          (v) => t(v === 'smaller' ? 'cfg.fontSmaller' : v === 'larger' ? 'cfg.fontLarger' : 'cfg.fontDefault'),
          busy || snap?.writable === false)),
      h('p', { key: 'fonthint', className: 'gp-cfg__hint' }, t('cfg.fontHint')),
    ]),
  ]
  const suggestBody = [
    field('sgon', [
      h('label', { key: 'sgrow', className: 'gp-cfg__row' }, [
        h('input', {
          key: 'switch', type: 'checkbox', role: 'switch', className: 'gp-cfg__switch',
          checked: suggestEnabled, disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { void toggleSuggest(e.currentTarget.checked) },
        }),
        h('span', { key: 'text', className: 'gp-cfg__text' }, t('cfg.suggestToggle')),
      ]),
    ]),
    field('sglang', [
      h('p', { key: 'sglangtitle', className: 'gp-cfg__seglabel' }, t('cfg.suggestLangLabel')),
      h('div', { key: 'sglang', className: 'gp-seg gp-cfg__seg', role: 'group', 'aria-label': t('cfg.suggestLangLabel') },
        segButtons<SuggestLanguage>([...SUGGEST_LANGUAGES], suggestLanguage, (v) => { void setLanguage(v) },
          (v) => t(v === 'auto' ? 'cfg.suggestLangAuto' : v === 'zh' ? 'cfg.suggestLangZh' : 'cfg.suggestLangEn'), busy || snap?.writable === false)),
      h('p', { key: 'sglanghint', className: 'gp-cfg__rangehint' }, t('cfg.suggestLangHint')),
    ]),
    field('numax', [
      h('div', { key: 'numax', className: 'gp-cfg__numrow' }, [
        h('label', { key: 'lab', className: 'gp-cfg__numlabel', htmlFor: 'gp-cfg-maxkib' }, t('cfg.suggestMaxBytesLabel')),
        h('input', {
          key: 'input', id: 'gp-cfg-maxkib', type: 'number', className: 'gp-cfg__numinput',
          inputMode: 'numeric', min: MAX_KIB.min, max: MAX_KIB.max, 'aria-describedby': 'gp-cfg-maxkib-hint',
          value: draftMaxKib ?? String(suggestMaxKib),
          disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { setDraftMaxKib(e.currentTarget.value) },
          onBlur: () => { void commitMaxKib(draftMaxKib) },
          onKeyDown: (e) => { if (e.key === 'Enter') { e.currentTarget.blur() } },
        }),
        h('span', { key: 'unit', className: 'gp-cfg__numunit' }, t('cfg.suggestMaxBytesUnit')),
      ]),
      h('p', { key: 'numaxhint', id: 'gp-cfg-maxkib-hint', className: 'gp-cfg__rangehint' }, t('cfg.suggestMaxBytesHint')),
    ]),
    field('nuout', [
      h('div', { key: 'nuout', className: 'gp-cfg__numrow' }, [
        h('label', { key: 'lab', className: 'gp-cfg__numlabel', htmlFor: 'gp-cfg-outtok' }, t('cfg.suggestOutputLabel')),
        h('input', {
          key: 'input', id: 'gp-cfg-outtok', type: 'number', className: 'gp-cfg__numinput',
          inputMode: 'numeric', min: SUGGEST_LIMITS.maxOutputTokens.min, max: SUGGEST_LIMITS.maxOutputTokens.max, 'aria-describedby': 'gp-cfg-outtok-hint',
          value: draftOutputTokens ?? String(suggestOutputTokens),
          disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { setDraftOutputTokens(e.currentTarget.value) },
          onBlur: () => { void commitOutputTokens(draftOutputTokens) },
          onKeyDown: (e) => { if (e.key === 'Enter') { e.currentTarget.blur() } },
        }),
        h('span', { key: 'unit', className: 'gp-cfg__numunit' }, t('cfg.suggestOutputUnit')),
      ]),
      h('p', { key: 'nuouthint', id: 'gp-cfg-outtok-hint', className: 'gp-cfg__rangehint' }, t('cfg.suggestOutputHint')),
    ]),
    field('nuto', [
      h('div', { key: 'nuto', className: 'gp-cfg__numrow' }, [
        h('label', { key: 'lab', className: 'gp-cfg__numlabel', htmlFor: 'gp-cfg-timeout' }, t('cfg.suggestTimeoutLabel')),
        h('input', {
          key: 'input', id: 'gp-cfg-timeout', type: 'number', className: 'gp-cfg__numinput',
          inputMode: 'numeric', min: TIMEOUT_S.min, max: TIMEOUT_S.max, 'aria-describedby': 'gp-cfg-timeout-hint',
          value: draftTimeout ?? String(suggestTimeoutS),
          disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { setDraftTimeout(e.currentTarget.value) },
          onBlur: () => { void commitTimeout(draftTimeout) },
          onKeyDown: (e) => { if (e.key === 'Enter') { e.currentTarget.blur() } },
        }),
        h('span', { key: 'unit', className: 'gp-cfg__numunit' }, t('cfg.suggestTimeoutUnit')),
      ]),
      h('p', { key: 'nutohint', id: 'gp-cfg-timeout-hint', className: 'gp-cfg__rangehint' }, t('cfg.suggestTimeoutHint')),
    ]),
    field('sgmodel', [
      h('div', { key: 'sgmodel', className: 'gp-cfg__menur' }, [
        h('span', { key: 'lab', className: 'gp-cfg__menulabel' }, t('cfg.suggestModelLabel')),
        providerMenu,
      ]),
      uiProvider !== ''
        ? h('div', { key: 'sgmodel2', className: 'gp-cfg__menur' }, [
          h('span', { key: 'lab', className: 'gp-cfg__menulabel' }, t('cfg.suggestProviderLabel')),
          modelMenu,
        ])
        : null,
      uiProvider !== '' && uiModel !== '' && efforts !== undefined && efforts.length > 0
        ? h('div', { key: 'sgeffort', className: 'gp-cfg__menur' }, [
          h('span', { key: 'lab', className: 'gp-cfg__menulabel' }, t('cfg.suggestEffortLabel')),
          effortMenu,
        ])
        : null,
      catalogStatus === 'loading'
        ? h('p', { key: 'sgload', className: 'gp-cfg__rangehint' }, t('cfg.suggestModelLoading'))
        : catalogStatus === 'error'
          ? h('p', { key: 'sgerr', className: 'gp-cfg__err', role: 'alert' }, [
            t('cfg.suggestModelFailed'),
            ' ',
            h('button', {
              key: 'retry', type: 'button', className: 'gp-cfg__retry',
              onClick: () => { loadCatalog() },
            }, t('cfg.suggestModelRetry')),
          ])
          // Failures win over the empty hint: a fully failed catalog is an
          // adapter error, not proof that the host has no models.
          : catalogFailures.length > 0
            ? h('p', { key: 'sgfail', className: 'gp-cfg__rangehint' },
              `${t('cfg.suggestModelFailed')}: ${catalogFailures.map((f) => f.name).join(', ')}`)
            : catalog.length === 0
              ? h('p', { key: 'sgempty', className: 'gp-cfg__rangehint' }, t('cfg.suggestModelEmpty'))
              : null,
      h('p', { key: 'sghint2', className: 'gp-cfg__hint' }, t('cfg.suggestHint')),
    ]),
  ]
  const reposBody = [
    field('detect', [
      h('label', { key: 'detrow', className: 'gp-cfg__row' }, [
        h('input', {
          key: 'switch', type: 'checkbox', role: 'switch', className: 'gp-cfg__switch',
          checked: detectCheckouts, disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { void toggleDetect(e.currentTarget.checked) },
        }),
        h('span', { key: 'text', className: 'gp-cfg__text' }, t('cfg.detectToggle')),
      ]),
      h('p', { key: 'dethint', className: 'gp-cfg__hint' }, t('cfg.detectHint')),
    ]),
    field('repolimit', [
      h('div', { key: 'repolimit', className: 'gp-cfg__numrow' }, [
        h('label', { key: 'lab', className: 'gp-cfg__numlabel', htmlFor: 'gp-cfg-repolimit' }, t('cfg.repoLimitLabel')),
        h('input', {
          key: 'input', id: 'gp-cfg-repolimit', type: 'number', className: 'gp-cfg__numinput',
          inputMode: 'numeric', min: REPO_LIMITS.min, max: REPO_LIMITS.max, 'aria-describedby': 'gp-cfg-repolimit-hint',
          value: draftRepoLimit ?? String(repoLimit),
          disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { setDraftRepoLimit(e.currentTarget.value) },
          onBlur: () => { void commitRepoLimit(draftRepoLimit) },
          onKeyDown: (e) => { if (e.key === 'Enter') { e.currentTarget.blur() } },
        }),
        h('span', { key: 'unit', className: 'gp-cfg__numunit' }, t('cfg.repoLimitUnit')),
      ]),
      h('p', { key: 'repolimithint', id: 'gp-cfg-repolimit-hint', className: 'gp-cfg__rangehint' }, t('cfg.repoLimitHint')),
    ]),
    field('codews', [
      h('h3', { key: 'cwtitle', className: 'gp-cfg__title' }, t('cfg.cwTitle')),
      h('div', {
        key: 'cwseg',
        className: 'gp-seg gp-cfg__seg',
        role: 'group',
        'aria-label': t('cfg.cwTitle'),
        // Runs before the box's blur (focus moves on mousedown): the press is
        // the newer intent, so the pending name is dropped rather than written
        // and immediately overwritten by the mode write that follows.
        onPointerDownCapture: () => {
          skipNameCommit.current = true
          setTimeout(() => { skipNameCommit.current = false }, 0)
        },
      },
        segButtons<'off' | 'auto' | 'custom'>(['off', 'auto', 'custom'], showWorkspaceName ? 'custom' : workspaceMode, (v) => { setWorkspaceMode(v) },
          (v) => t(v === 'off' ? 'cfg.cwOff' : v === 'auto' ? 'cfg.cwAuto' : 'cfg.cwCustom'), busy || snap?.writable === false)),
      showWorkspaceName
        ? h('input', {
          key: 'cwname', type: 'text', className: `gp-cfg__textinput${workspaceNameInvalid ? ' gp-cfg__textinput--err' : ''}`,
          placeholder: t('cfg.cwNamePlaceholder'),
          value: workspaceName,
          disabled: busy || snap?.writable === false,
          'aria-invalid': workspaceNameInvalid || undefined,
          onChange: (e: ChangeEvent<HTMLInputElement>) => {
            setDraftName(e.currentTarget.value)
            if (workspaceNameInvalid) setWorkspaceNameInvalid(false)
          },
          onKeyDown: (e) => { if (e.key === 'Enter') commitWorkspaceName() },
          onBlur: () => { commitWorkspaceName() },
        })
        : null,
      workspaceNameInvalid
        ? h('p', { key: 'cwerr', className: 'gp-cfg__err', role: 'alert' }, t('cfg.cwNameInvalid'))
        : null,
      h('p', { key: 'cwhint', className: 'gp-cfg__hint' }, t('cfg.cwHint')),
    ]),
    field('follow', [
      h('label', { key: 'followrow', className: 'gp-cfg__row' }, [
        h('input', {
          key: 'switch', type: 'checkbox', role: 'switch', className: 'gp-cfg__switch',
          checked: filesFollowRepo, disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { void toggleFilesFollow(e.currentTarget.checked) },
        }),
        h('span', { key: 'text', className: 'gp-cfg__text' }, t('cfg.filesFollowToggle')),
      ]),
      h('p', { key: 'followhint', className: 'gp-cfg__hint' }, t('cfg.filesFollowHint')),
    ]),
    field('fold', [
      h('label', { key: 'foldrow', className: 'gp-cfg__row' }, [
        h('input', {
          key: 'switch', type: 'checkbox', role: 'switch', className: 'gp-cfg__switch',
          checked: collapseReposOnPick, disabled: busy || snap?.writable === false,
          onChange: (e: ChangeEvent<HTMLInputElement>) => { void toggleFoldOnPick(e.currentTarget.checked) },
        }),
        h('span', { key: 'text', className: 'gp-cfg__text' }, t('cfg.foldOnPickToggle')),
      ]),
      h('p', { key: 'foldhint', className: 'gp-cfg__hint' }, t('cfg.foldOnPickHint')),
    ]),
  ]

  return h('div', { className: 'gp-cfg' }, [
    section('basic', t('cfg.sectionBasic'), basicBody),
    section('view', t('cfg.sectionView'), viewBody),
    section('suggest', t('cfg.suggestTitle'), suggestBody),
    section('repos', t('cfg.sectionRepos'), reposBody),
    failed ? h('p', { key: 'error', className: 'gp-cfg__err', role: 'alert' }, t('cfg.saveFailed')) : null,
  ])
}
