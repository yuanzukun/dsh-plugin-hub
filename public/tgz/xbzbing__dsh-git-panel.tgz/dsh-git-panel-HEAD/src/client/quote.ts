/**
 * Putting a reference into the session's composer.
 *
 * "Reference this" is the one menu outcome that does not belong to this plugin:
 * the text lands in the conversation's draft, where the agent can act on it.
 * The face belongs to `@deepseek-ai/dsh-client-ui-conversation`, whose layout is
 * not ours to import — so the path is declared structurally and probed at use
 * time, the way `sidebar-types.ts` treats the right sidebar:
 *
 *   ctx.sessions.scope(sessionId)?.get('conversation')?.input.for(scope).insertQuote(text)
 *
 * Every hop is optional (an older host, a session that is not retained, a
 * composer that never mounted), and the platform's resolver throws when the
 * scope is not retained. So the probe reports whether it landed, and the caller
 * falls back to the clipboard instead of offering an entry that does nothing.
 */
import type { ClientCtx } from './rpc.js'

/** The session-scope face this module reads (a Cordis scope's `get`). */
interface SessionScopeFace {
  get(key: string): unknown
}

/** The composer's display of a quote instead of its text (the platform's
 * `QuoteSummary`, dsh 0.2.3+). An older composer ignores the argument. */
export interface QuoteSummary {
  readonly label: string
  readonly title: string
  readonly detail?: string
  readonly body: string
}

/** The composer's quote entry point, as far as this plugin uses it. */
interface InputQuoteFace {
  readonly insertQuote: (text: string, summary?: QuoteSummary) => boolean
  readonly focus: () => void
  /** The draft store; read only to number review comments (optional). */
  readonly state?: { getSnapshot(): { readonly draft?: unknown } }
}

/** The conversation service's input registry. */
interface ConversationFace {
  readonly input?: { for(scope: unknown): InputQuoteFace }
}

/** The `sessions` client service. */
interface SessionsFace {
  scope(sessionId: string): SessionScopeFace | undefined
}

function isQuoteFace(value: unknown): value is InputQuoteFace {
  if (typeof value !== 'object' || value === null) return false
  const face = value as { insertQuote?: unknown; focus?: unknown }
  return typeof face.insertQuote === 'function' && typeof face.focus === 'function'
}

/** The session's composer, or undefined when any hop is missing. Throws only
 * what the platform throws for an unretained scope; callers catch. */
function composerOf(ctx: ClientCtx, sessionId: string): InputQuoteFace | undefined {
  const sessions = ctx.get('sessions') as SessionsFace | undefined
  if (sessions === undefined || typeof sessions.scope !== 'function') return undefined
  const scope = sessions.scope(sessionId)
  if (scope === undefined || typeof scope.get !== 'function') return undefined
  const conversation = scope.get('conversation') as ConversationFace | undefined
  const resolver = conversation?.input
  if (resolver === undefined || typeof resolver.for !== 'function') return undefined
  const input = resolver.for(scope)
  return isQuoteFace(input) ? input : undefined
}

/**
 * Insert one quote into a session's composer.
 * @param ctx - client context (the services are read per call; they may arrive
 *   after this plugin).
 * @param sessionId - the session whose composer should take the text.
 * @param text - non-blank quote text.
 * @param summary - optional composer display (file, range, comment).
 * @returns whether the composer accepted it — false means "nothing was
 *   written", never "maybe".
 */
export function insertSessionQuote(ctx: ClientCtx, sessionId: string | undefined, text: string, summary?: QuoteSummary): boolean {
  if (sessionId === undefined || sessionId === '' || text.trim() === '') return false
  try {
    const input = composerOf(ctx, sessionId)
    if (input === undefined) return false
    if (!(summary === undefined ? input.insertQuote(text) : input.insertQuote(text, summary))) return false
    // The platform's own insertQuote focuses the composer when it succeeds; the
    // call is repeated here because the face is declared structurally and an
    // older or stricter implementation may not — and an unfocused draft reads as
    // a silent write behind a dismissed menu.
    input.focus()
    return true
  } catch {
    // An unretained session scope throws by contract; there is nothing to
    // report beyond "the composer is not there".
    return false
  }
}

/**
 * Whether a session has a composer to quote into. Probed before the entries are
 * offered, so a menu never shows "reference this" on a host (or a session) that
 * would drop the text.
 * @param ctx - client context.
 * @param sessionId - the session to ask about.
 */
export function quoteAvailable(ctx: ClientCtx, sessionId: string | undefined): boolean {
  if (sessionId === undefined || sessionId === '') return false
  const sessions = ctx.get('sessions') as SessionsFace | undefined
  if (sessions === undefined || typeof sessions.scope !== 'function') return false
  try {
    const scope = sessions.scope(sessionId)
    if (scope === undefined || typeof scope.get !== 'function') return false
    const conversation = scope.get('conversation') as ConversationFace | undefined
    return conversation?.input !== undefined && typeof conversation.input.for === 'function'
  } catch {
    return false
  }
}

/**
 * The session's current draft text (chips expanded to their clipboard form),
 * or undefined when the composer or its store cannot be read.
 * @param ctx - client context.
 * @param sessionId - the session to read.
 */
export function sessionDraft(ctx: ClientCtx, sessionId: string | undefined): string | undefined {
  if (sessionId === undefined || sessionId === '') return undefined
  try {
    const store = composerOf(ctx, sessionId)?.state
    if (store === undefined || typeof store.getSnapshot !== 'function') return undefined
    const draft = store.getSnapshot().draft
    return typeof draft === 'string' ? draft : undefined
  } catch {
    return undefined
  }
}

/** What a commit row quotes: its short hash followed by the subject, so the
 * agent can find the commit from the text alone. */
export function commitQuote(shortHash: string, subject: string): string {
  const text = subject.trim()
  return text === '' ? shortHash : `${shortHash} ${text}`
}
