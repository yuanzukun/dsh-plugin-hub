/**
 * Client-side re-export of the host wire types. The host is the authoritative
 * source (src/host/types.ts); this file mirrors the type surface so client
 * modules import from one place without reaching across into host code.
 */
export type {
  GitSnapshot, GitSnapshotResult, GitSnapshotRequest, GitFailure, GitCommit, GraphCommit, GitGraphNode, GitRef,
  GitChange, GitChangeStatus, GitAction, GitActionRequest, GitActionResult, GitErrorCode,
  GitQuery, GitQueryRequest, GitQueryResponse, GitQueryResult, GitBranch, GitFileStat, WorktreeStats, StashEntry,
  GitVersionRequest, GitVersionInfo, DiffViewMode, ChangesViewMode, GraphStyle, FontDelta, DirEntry, ResetMode, GitPanelPlacement,
  GitOpenFileRequest, GitOpenFileResult, GitRepoEntry, GitRepoList,
  GitWriteFileRequest, GitWriteFileResult, FileEditInfo, FileEditBlock,
  GitSuggestRequest, GitSuggestResult, GitRemote, RemoteHostKind, SuggestLanguage, TruncationReason,
  ModelCatalogGroup, ModelCatalogModel, ModelCatalogEffort, ModelCatalogFailure, RemoteMethod,
} from '../host/types.js'

export { imageMimeFor, isEditablePath, EDIT_MAX_BYTES, EDITABLE_EXTENSIONS, EDITABLE_FILENAMES, isHistoryFiltered, HISTORY_PATH_SEARCH_MAX_LENGTH, SUGGEST_LIMITS, DIFF_EXPAND_CONTEXT, FILE_COPY_MAX_BYTES, FILE_LINES_MAX_LINES, SUGGEST_LANGUAGES, SUGGEST_LANGUAGE_DEFAULT } from '../host/types.js'
import type { GitQueryResult } from '../host/types.js'

/**
 * The diff query's payload as the views carry it: text and new-side line count
 * travel together (they come from one query and are cleared together), so the
 * projection is derived from the wire type instead of being respelled per view.
 */
export type GitDiffPayload = Pick<Extract<GitQueryResult, { kind: 'diff' }>, 'text' | 'newLines' | 'truncated'>
