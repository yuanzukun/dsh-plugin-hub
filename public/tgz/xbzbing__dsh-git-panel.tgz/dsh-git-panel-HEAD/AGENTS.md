# AGENTS.md

本文件是 `dsh-git-panel` 仓库的 agent 工作指南。任何在此仓库工作的 AI agent 或贡献者，动手前先读完本文件，并遵守其中的架构边界、构建流程与代码约定。

## 项目定位

`dsh-git-panel` 是 DeepSeek Harness（dsh）的一个插件，在 Web GUI 里提供 Git 面板能力：

- 工作区新增常驻面板 tab「Git」，位于「对话」「轨迹」之后，内部含三个子 tab：
  - **Git 总览**：左=分支列表，中=提交历史图（支持 commit id 等字段搜索），右=提交详情 + comment。提交详情顶部有变更汇总行（文件数 + 该提交的 +增/−删行数，口径与右侧文件树一致：二进制计入文件数但不计行、合并提交文件树为空时统计清零），其下的变更文件树目录可点击折叠/展开（默认全展开，切换选中提交时重置为全展开）。分支列表的本地 / 远程行 hover 时行尾出现「切换」按钮（`gp-branch-row__switch`，`stopPropagation` 不触发行点击的历史筛选；当前分支、解析到当前分支的远程行、标签无按钮；窄面板在「筛选分支」底部弹层的行上，`hover:none` 触屏常显），点击直接进确认框（`branch-switch.tsx`），目标由 `branch-options.ts` 的 `buildBranchOptions` 按行 key `local:<名>` / `remote:<引用>` 解析；远程引用自动落下为同名本地分支（不存在时 `git checkout -b <名> --track <远程>/<名>`），绝不直接检出远程引用（会游离 HEAD）；有未提交变更时确认框给出「直接切换 / 先贮藏再切换」，后者 `git stash push -u` 后切换且不自动恢复。切换成功除刷新各列表外，还会广播「工作区世代」使文件浏览的目录缓存与选中失效。再下有「提交操作」区：还原此提交（revert）、重置到此提交（reset：软 / 混合 / 硬，硬重置列出将丢失的改动并需额外勾选确认）、为该提交创建标签（轻量 / 附注），已有标签以可删除标签片呈现（创建 / 删除 / 还原 / 重置均走 modal + 二次确认，底部恒显「信任 AI」提示）。
  - **变更记录**：左=变更统计（文件数 / 增删行数 / 最近变更时间）+ 本地未提交变更列表（勾选、手动提交、Amend）+ 贮藏入口与贮藏列表（应用 / 弹出 / 丢弃），右=选中文件差异对比（图片走 `image-diff` 新旧双图对照）。
  - **文件浏览**：直接打开 Git tab 时，非 Git 目录默认进入此页、干净仓库默认 Git 总览、有未提交变更默认变更记录；输入框标记的显式跳转仍优先。非 Git 目录仅显示文件浏览，以 cwd 为根。系统未安装 git 时同样退化为文件浏览：在 git 目录（文件系统探测到 `.git`）会额外提示「未安装 Git」，非 git 目录则静默退化，两种情况输入框标记与状态圆点均不显示。左=按需加载目录树（`.git` 不可浏览，Git 忽略项半透明），右=文件预览（按类型显示 dsh 官方 `FileTypeIcon`，可复制相对路径；代码/文本用官方 `useCodeHighlighter` 语法高亮，Markdown 可切换官方 `MarkdownText` 渲染并默认渲染，HTML 可切换预览但默认源码、渲染走 `allow-scripts` 隔离源 iframe 不自动执行，图片内联并支持缩放/全屏（`ImageZoom.tsx`），其余二进制占位）。Git 面板保留默认字号，可在顶部调节并记住选择。
- inputBar 一个 zsh 风格 Git 标记：`<仓库名> (<分支>)`，绿色=已同步、橙色=有待提交；hover 显示完整路径；点击跳转面板（有未提交→变更记录，已提交→Git 总览）。非 Git 目录不显示此标记或状态圆点；插件详情页可隐藏 Git 仓库的标记，隐藏时改为在「Git」标签旁显示同色状态圆点（`tab-dot.ts`），两者互斥。
- 插件详情页配置区：「显示输入框标记」开关 = host `static Config` volatile 字段 + client 注册 `plugins.bundle.config` 表单（`PillConfig.tsx`），经 `configForms` 热写；写入被接受后客户端立即 `resyncAll()`，不等轮询。「AI 生成提交信息」独立 card 区（开关 + 输入预算/输出上限/生成超时三项数值配置，KiB/tokens/秒 显示单位 ×1024/×1/×1000 换算写入，UI 层先 clamp 到显示范围、host `normalizeConfig` 对三个 suggest 数值字段再 clamp 到 16–512 KiB / 256–16384 tokens / 5–120 s 兜底）。

许可：MIT。

## 架构总览

插件分 host / client 两半，经 typert Remote 通信。

```
Client 半 (React bundle, lib/client.js)
  - conversation.view (order 30)  → Panel 主面板（内部子 tab 路由）
  - conversation.input.left       → GitPill（zsh 风格标记）
  - plugins.bundle.config         → PillConfig（详情页配置表单）
  - GitController                 → 每 session 轮询 snapshot，pill/变更页/统计共享
        │ RPC (typert)
        ▼
Host 半 (Cordis + typert, lib/host)
  - GitPanelService（命名空间 gitPanel）
        - snapshot / run / query / suggest / version 五个 @Remote 端点
        │ subprocess 服务（argv 数组、无 shell、cwd 锁仓库根、超时+输出上限）
        │ suggest 端点另经宿主 llm 服务（ctx.get 可选获取）一次性生成提交信息
        ▼
  git CLI
```

### Host（`src/host/`）

- `types.ts` 是 wire 数据模型的**唯一权威源**，client 侧的 RPC 类型直接从它复用。
- `index.ts`：`GitPanelService extends TypertRemoteService`，`inject = ['subprocess','sessions','sessionPersistence']`，仅做端点委托与生命周期接线。
- `git.ts`：把 `subprocess` 服务适配成带超时的 `GitRunner`；对每条命令注入 `GIT_TERMINAL_PROMPT=0`，使 fetch/pull 等网络命令遇到凭据/主机密钥交互时快速失败而非挂到超时（stdin 已 ignore）。
- `remote.ts`：把 `git remote -v` 的 fetch URL 解析成可浏览的 `https://<host>/<path>` 页面链接 + 主机分类（`github`/`gitlab`/`gitee`/`bitbucket`/`other`），覆盖 scp（`git@host:owner/repo.git`）/ssh://​/https://​/git:// 各形态，并剥除内嵌凭据（`user:token@`）以免 token 泄进 href；`parsePrimaryRemote`（在 `core.ts`）优先取 `origin`、否则第一个远程。
- `core.ts`：workspace（cwd→仓库根 realpath）解析 + `snapshotForSession`（含远程 `remote` 与是否跟踪上游 `hasUpstream`——由 `@{upstream}...HEAD` 的 rev-list 退出码判定，`ahead`/`behind` 仅在有上游时有意义）；文件浏览使用 `resolveBrowseRoot`，非 Git 目录回退到 cwd realpath。统计用的两个逐文件 fan-out（未跟踪文件行数的 `git diff --no-index` 每文件一进程、最近变更 mtime 的每文件一次 `stat`）在变更数超过 `STATS_FANOUT_LIMIT`（200）时整体跳过，`stats.partial` 置真、`insertions` 不计未跟踪行、`lastChangeAt` 为 null（issue #16：数千变更时这两处会在每次轮询刷出几百个 git 进程拖死面板）；计数（fileCount/staged/modified/untracked）与已跟踪增删行始终精确。
- `actions.ts`：`GitAction` → git 命令序列构造（含 `commit --amend`、按路径提交的两步 `add + commit`；分支切换 `branch-checkout`（可选 `createFrom` → `checkout -b <名> --track <远程>/<名>`，可选 `stashMessage` → 两步 `stash push -u` + checkout）；标签 `tag-create`（`-a -m` 为附注，否则轻量）/ `tag-delete`；贮藏 `stash-push`（可带 `-m`）/ `stash-apply` / `stash-pop` / `stash-drop`（`stash@{N}` 由校验过的整数 index 拼成）；回撤 `revert`（`--no-edit`）/ `reset`（`--soft|--mixed|--hard`，mode 另在此校验）；同步 `fetch`（`--all --prune`）/ `pull-ff`（`git pull --ff-only`，仅能快进、分叉时拒绝不动工作区）/ `push`（纯 `git push`，绝不 `--force`，仅在严格领先时提供，分叉由远程拒绝）/ `publish`（无上游分支的 `git push -u <remote> HEAD`，remote 名取自主远程、经 `isSafeRemoteName` 复校，`HEAD` 为固定字面量））。错误映射分级：先判冲突（`CONFLICT`，贮藏/还原条目保留）、`index.lock` 繁忙（自动重试一次后报 `index-busy`）、`not-found`（含 `Could not parse object` 等坏 ref、checkout 目标的 `did not match any file(s) known to git`）、`branch-in-use`（目标分支已被其他工作树检出；贮藏后切换失败另报 `stash-switch-failed`，因为此时变更已进贮藏、状态已变）、`auth-failed`（凭据不可用；`GIT_TERMINAL_PROMPT=0` 下交互提示直接失败）、`push-rejected`（推送非快进被远程拒绝）、`not-ff`（`--ff-only` 遇分叉的洁净拒绝），再落通用 `git-error`。
- `queries.ts`：`history / diff / file-lines / image-diff / dir-list / file-content / show / branches / tags / stash-list / authors / last-commit-message / worktree-stats / pull-preview / push-preview`。`diff` 除统一 diff 文本外回报新侧总行数 `newLines`：git 把末 hunk 的尾部上下文截到 `-U`，故 `run == U` 时文本无法区分「hunk 在文件中段」与「文件恰好在此结束」，只有这个行数能判定下方是否真有隐藏行（0 = 不可信/不适用，视图据此不渲染尾部展开控件：该侧不存在、读取失败或被 runner 输出上限截断、diff 没有 hunk、或工作区文件超过 `DIFF_COUNT_READ_MAX`（8 MiB，只约束这个计数读，展开路径不设上限））。`context` 的钳制上限是 `DIFF_CONTEXT_MAX`（100000），而「展开全部」实际请求的是 `DIFF_EXPAND_CONTEXT`（2000）——**故意有界**：窗口宽到覆盖整个大文件会让 host 把一个文件整块吐成一个 hunk（数 MB 文本），窗口够不到的上下文继续以 gap 形式留在视图里按需展开。**截断不再静默**：runner 在 collect/spill 上限丢过输出时（`stdoutLossy`）`diff` 照常返回（残缺 hunk 仍可读），但结果带 `truncated: true`，视图据此显示 `diff.truncated` 提示——那种前缀能解析成合法 diff，行号与增删统计却已失真；同一次读的 `readNewSide` 独立拒收，故 `newLines` 降级为 0、不再提供尾部展开控件。`file-lines` 供 diff 视图按需展开隐藏上下文，它与 `newLines` 共用 `readNewSide` 单处判定新侧来源——worktree 读工作区文件（**symlink 取链接目标文本**，即 git 的 120000 blob；跟随链接会把目标文件的行当成 diff 的右栏，且 CRLF 归一化成 LF 以对齐 git 的 blob 视图）、staged 读 index blob、commit 读 `<commit>:<path>`（worktree 曾误读 index，会揭示与 diff 右栏不符的行）；非零退出一律先用 stderr 区分「该版本没有这个路径」（空侧）与真实失败（坏 ref/坏对象报 `git-error`，不再伪装成空文件）。`pull-preview` 给拉取确认框预览「将引入的快进范围」：`rev-list --count HEAD..@{upstream}`（提交数）+ `git diff --numstat HEAD @{upstream}`（文件数 + 增删行），全本地（`behind>0` 时对象已 fetch）、无网络、`@{upstream}` 为固定字面量；无上游时 `hasUpstream:false` 且计数清零。`dir-list` 列单个工作区目录（懒加载、跳过 `.git`、条目上限）、`file-content` 读单个工作区文件（文本切片 / 图片 data URL / 二进制标记，超上限降级）；两者的 path 经 `isSafePath` + realpath 逃逸守卫（软链指仓库外一律拒），是插件唯一直接读 git 未跟踪文件的信任边界。`stash-list` 走 `git stash list -z --format` 经 `parseStashList` 解析；贮藏列表按需查询、不进常驻快照。`show` 并行取 meta（`show -s`）+ 变更文件（`--name-status -z`）+ 行数（`--numstat`，经 `sumNumstat` 求和得该提交 +增/−删），numstat 对合并提交会退回首父差，故汇总行数以 name-status 文件列表为准——文件列表为空（如洁净合并）时行数清零，二进制计入文件数但不计行。
- `validate.ts`：host 信任边界的输入校验（`isSafePath` / `isSafeRev` / `isSafeBranchName`）。经 RPC 到来的 path/ref/分支名/标签名是唯一不可信 argv 素材；凡会把它们放进选项位的 git 命令都在此拦截，并额外用 `--end-of-options` 殿后（拒 `-` 开头的 `--output=<file>` 任意写向量）。贮藏 index 另在 `actions.ts` 校验为非负整数。
- `suggest.ts`：AI 生成提交信息端点——`git status -z` 文件清单 + `git diff HEAD`（unborn 退化为 `--cached` + worktree，`paths` 全过 `isSafePath`），untracked 新文件再按 `git diff --no-index` 折入 diff（`suggestMaxBytes` 预算内、`UNTRACKED_FILE_CAP` 封顶），JSON framing 组 prompt；经 `llm` 面（`ctx.llm.stream`）一次性生成，手写 deadline 超时、finish→错误映射（读真实 chunk 的 `reason` 信封）、`suggestEnabled=false` 入口兜底为 `suggest-disabled`。diff 两级截断都置 `truncated`：`suggestMaxBytes` 输入预算超限截断、runner 每命令 stdout 上限（`maxBytes`）的 lossy 截断同样标记（不静默）。`llm`/`agentDefaultModel` 走 `getLlm`/`getAgentDefaultModel` **按请求解析**（不构造期冻结、**不进 `static inject`**）；模型路由为 config 覆盖对（provider/model 必须成对）优先，否则 `agentDefaultModel.currentSelection()`；`llm-face.ts` 用 `@deepseek-ai/dsh-llm` 的 type-only 官方类型钉住 wire 契约（零运行时依赖）。
- `parser.ts`：`git status --porcelain` / `--numstat` / `log` 输出解析为结构化数据。
- `version.ts`：读本包 `package.json` 版本 + 查 GitHub release 做更新检查，失败降级。

### Client（`src/client/`）

- `rpc.ts`：`gitPanel` @Remote 端点的 client 面，走 `/api` 通道调 `gitPanel/<method>`；逐读加守卫，连接缺失或异常降级为类型化 failure。
- `controller.ts`：`GitController`，每 session 的快照控制器（单航刷新 + `refreshIntervalMs` 轮询 + turn 完成边沿刷新 + `connection/reset` 重拉）。
- `registry.ts`：per-session `GitController` 复用池 + 组件订阅入口。
- `index.ts`：Cordis `apply` —— 挂 RPC 面、注册三个 slot（`conversation.view` / `conversation.input.left` / `plugins.bundle.config`）、注册 i18n。
- `Panel.tsx`：主面板壳，内部子 tab 路由 + 焦点消费 + 版本条；用 `layout.ts` 的 `usePanelLayout` 观测面板宽度，≤620px 时在根节点标 `data-layout="compact"` 并把 `compact` 下发给三个子 tab，触发单栏「钻取」布局。
- `layout.ts`：`usePanelLayout`——ResizeObserver 观测面板宽（`COMPACT_BP=620`，与 GitPill 的 `COMPACT_WIDTH` 同值），返回是否进入 compact 单栏布局。compact 的所有样式挂在 `.gp-panel[data-layout="compact"]` 下，宽布局行为不变（e2e 断言覆盖）；portaled 的 modal / bottom sheet 在 `.gp-panel` 之外，分别用自身 class / viewport media query 适配。窄视口（`max-width:640px`）下弹窗有独立尺寸契约：`.gp-modal`（大弹窗，含 commit 文件 diff）高 `min(90dvh,calc(100dvh-48px))`，近全屏但留出可点边距；`.gp-modal--sm`（确认框 / 标签 / 贮藏 / 重置）在媒体查询内**只重申 `height:auto`**，不让 90vh 流进来——其 max-height 基规则 `min(560px,86vh)` 已装得进 viewport-48px，重申只会把内容上限放宽到 796px。backdrop 上下 padding 24px 保证可点空白。compact 的 diff 工具栏与 commit 对比 modal 工具栏同样拆两行：`.gp-diff__toolbar-row` / `.gp-modal__bar-row`（第二行 `--controls` 收模式 seg + 展开/关闭，seg 与按钮等宽分摊），因为单行在手机宽度放不下「返回 + 路径 + 统计 + 展开 + 模式 seg」而会把 seg 挤成竖叠。这两处 class 不挂在 `data-layout` 下，故宽视口 + 窄面板也成立。
- `OverviewTab.tsx`：Git 总览三栏（分支列表 / 提交历史图 / 提交详情 + comment）的组合层，含 hover 卡；取数状态拆进 `overview-hooks.ts`。提交详情顶部「提交操作」区：还原（`revert`）/ 重置（`ResetModal`，软 / 混合 / 硬 + 硬重置丢失清单与额外确认）走 `onAction`（经控制器喂回新快照 → refreshKey 前进 → 历史图刷新），创建标签（`TagCreateModal`）/ 删除标签（标签片 ×）走 `run` 的 `tag-create` / `tag-delete`、以本地 `opBump` 刷新历史图与分支/标签列表（标签不动工作区，不会 bump 快照）。compact 时折叠为单栏：历史列表 ↔ 提交详情按 `pane` 钻取（带返回条），分支筛选走 bottom sheet，提交行两行式、graph svg 高度随行高拉伸以保证连线，禁用 hover 卡。左列底部有固定状态栏（`renderStatusBar`，拆在 `overview-statusbar.tsx`，wide 下在滚动分支列表 `gp-col-left__scroll` 之下、compact 下在总览底部）：左=远程仓库链接（仅 GitHub 项目显示：`remote.hostKind==='github'` 时用 GitHub 标，非 GitHub 远程不显示链接；`webUrl` 新标签页打开、仓库路径与「打开」提示在 hover title，无 webUrl 的本地路径远程只显图标、URL 进 title），右=分支同步态（已同步 / 领先 / 落后 / 分叉 / 无上游）+「检查同步」（`fetch` 经 `onAction` 回灌新快照刷新 ahead/behind）+ 仅在「严格落后（behind>0 且 ahead===0）」时出现的「拉取同步」（`pull-ff`，走 confirm modal + 「信任 AI」提示，预览将引入的快进范围）+ 仅在「严格领先（ahead>0 且 behind===0）」时出现的「推送同步」（`push`，confirm modal 预览待推送范围）+ 无上游分支出现的「发布分支」（`publish` = `git push -u`，二次确认 modal）。分叉时推送/拉取都不提供。`snapshot.remote`/`hasUpstream` 缺失（旧快照）时降级为「无远程/无上游」而非崩溃。
- `overview-hooks.ts`：`useBranchTree` / `useHistory`（分页 + 分代守卫 + `total:-1`）/ `useCommitDetail`（`show` LRU 缓存 + 文件 diff overlay + hover）三个数据 hook，`OverviewTab` 只做组合与渲染。
- `ChangesTab.tsx` / `ChangeStats.tsx` / `DiffView.tsx`：变更记录页、统计条（读快照上的 `stats`，不再单发查询；`stats.partial` 为真时追加「统计已简化」提示）、差异视图（`DiffView` 已 `memo`；支持统一（`unified`，单栏行内）/ 并排（`split`，左右分栏）两种布局，默认视图由快照上的 `defaultDiffView` 决定，可在工具栏临时切换）。未提交变更列表按行虚拟化（分组头 + 文件行扁平成一个列表，前缀和算偏移，只挂视口窗口内的行，固定行高 `VROW_H`/`VHEAD_H` 由样式钉死；issue #16 数千变更不再一次性铺 DOM）。虚拟化窗口数学抽在纯模块 `virtual-list.ts`（`buildTops`/`lowerBound`/`windowRange`/`findWindowRange`，吃任意高度数组，有单测），视口跟踪抽在 `use-viewport.ts` 的 `useViewportTracker`（callback-ref + 滚动/ResizeObserver，重挂自动重连、同尺寸不重渲染）；变更列表、文件浏览源码视图（`FilesTab.tsx`）与差异视图（`DiffView`）三处复用。**`findWindowRange`**：Find 的活动命中若已在窗口内，只按 overscan 扩边；若在窗口外，则把窗口**吸附**到命中邻域，绝不取「视口到命中」的连续区间——那种跨度会在一次 commit 里挂载中间所有行，正是虚拟化要消除的冻结（实测 547 行文件冷缓存下跳转到末尾命中：改前峰值 540 行 / 单帧长任务 231ms，改后 51 行）。**`DiffView` 行虚拟化**：「展开全部」= 带 `context: DIFF_EXPAND_CONTEXT`（2000，有界）重发 diff，大文件仍会留下按需展开的 gap，故 diff 视图只挂视口窗口内的行——行高「已测值优先，否则按行种类估算（code 20 / hunk 27 / gap 29）」，`useLayoutEffect` 每帧读已挂行的 `data-r` 真实高度回填（差值 >0.5px 才写，一次收敛），前后各一段 `grid-column:1/-1` 的 `.gp-diff__spacer` 撑出滚动条；长行仍 `pre-wrap` 换行，高度可变，所以必须实测而非固定行高。`DiffView` **自己拥有滚动容器**（`.gp-diff__wrap` flex 填满 → `.gp-diff__scroll` 滚动 → body），因为窗口数学在首帧就需要视口高度，调用方提供的容器给不出；Find 仍扫全部行（计数与导航完整），活动命中经 `findWindowRange` 挂载后 rAF `scrollIntoView` 居中（cell key 的数字后缀即行号）。**两处提示都由 DiffView 渲染**（`expanded`/`truncated` 两个普通值 prop，不破坏 `memo`）：`diff.expandCapped` 的门是 `expanded && rows.some(r => r.kind === 'gap')`——读**实际剩下的 gap 行**而非请求的 context 大小，因为 git 在相邻改动把 hunk 合并时能用 2000 行上下文覆盖整个文件，也可能在 hunk 贴着文件一端时留下不足 4000 行的 gap；最后一个 gap 被消费后提示自动消失。**高亮按行缓存**：`highlight-cache.ts` 的 `memoizeHighlighter` 包住平台 `useCodeHighlighter`（`Map<行文本, spans>`，到 `HL_CACHE_MAX` 后整体丢弃；随 highlighter 身份变化自动失效），因为行会随窗口移动与祖先重渲染反复渲染，而 shiki 每行一次 `codeToTokens` 是这里最贵的操作（实测 JS 正则引擎中位数 0.22ms/行，313 字符的 JSX 行 13ms）。`DiffView` 的 `base`/`commit` 是**普通值而非对象**：此前每次渲染新建 `imageSpec` 对象字面量，`memo` 的浅比较永远不相等，任何祖先重渲染都会重跑整套高亮。变更页还含贮藏：工具栏「贮藏」按钮（`StashPushModal`）、`stash-list` 查询出的可折叠贮藏列表（应用 / 弹出 / 丢弃，丢弃走确认 modal），操作经 `onAction`（失败也 `resync` 以反映冲突后的工作区）。
- `ops-modals.tsx`：写操作共享的 portaled 弹窗原语——`renderModalShell`（小弹窗统一外壳：backdrop 点击外部关闭 + Escape + `createPortal` + `.gp-modal--sm` 框 + bar(图标/标题/短哈希/关闭)，确认框 / 标签 / 贮藏 / 重置四类对话框都只提供 body+footer 经它渲染，关闭契约单处收口）、`renderConfirmModal`（纯文本确认框）、`renderModalFooter`（取消/确认按钮，`confirmBusy` 可在途禁用）、`renderAiHint`（底部恒显 `ops.aiHint`）、`opErrorText`（错误码→文案）。
- `PillConfig.tsx`：插件详情页配置表单（`configForms` 读写 + 写后即时 resync）——「显示输入框标记」开关 + 「差异对比默认视图」统一/并排切换 + 「提交历史图线条样式」平行线（VSCode）/ 紧凑（git log）切换 + 「AI 生成提交信息」独立 card（开关 + 输入预算/输出上限/生成超时三项数值配置；范围与回退从 `host/types.ts` 的 `SUGGEST_LIMITS` 单源派生，client 经 `types.ts` 转出与 `imageMimeFor` 同路径；数值输入草稿态打字不阻塞、失焦/回车提交、显示值 clamp 到与 host 执行一致的范围、提交后乐观保持至写入落地）。
- `tab-dot.ts`：Git 标签状态圆点（pill 隐藏时注入 / 恢复标记时清除）。
- `ImageCompare.tsx`：图片新旧双栏对照（渲染 `image-diff` 查询结果，每栏内嵌 `ZoomableImage`）。
- `ImageZoom.tsx`：图片缩放交互（文件浏览预览与 `ImageCompare` 两栏、灯箱内层共用同一组件）。`ZoomableImage` = 触摸板捏合/cursor 锚点缩放（10%–800%）+ 原生滚动平移 + **鼠标左键拖拽平移**（`grab`/`grabbing` 光标，`data-zoomed`/`data-dragging` 驱动）+ 浮动缩放条（− / 百分比 / + / 适应窗口 / 全屏）+ 双击 fit↔100%。**全屏入口只在工具栏**：图片单击不触发（内联「点击进全屏」与双击切换在物理上互斥——第一次单击就会进灯箱、双击永远切不成），灯箱内保留双击与捏合。灯箱 `ZoomLightbox`（portal、Esc/关闭钮/空白区 mousedown 关闭、焦点还原、Tab 在对话框内循环）契约对齐官方 `ImageLightbox`，但官方组件无缩放扩展点，故灯箱自研。
- `ImageZoom.tsx` / `zoom.ts` 实现约束：缩放态只写 inline `width` 参与布局，`.gp-zoom__img` 必须 `flex:none`——flex item 的 replaced element 自动最小尺寸=自然宽度，缺它时 flex-shrink 会把渲染尺寸钉在 `max(自然宽, 视口宽)`，放大超过 100% 只剩标签在涨（e2e 曾因断言 `style.width` 而漏检）。居中用 `margin:auto`+视口 `flex-start`（`justify-content:center` 会让超宽图溢出侧拖不到）；`pointermove/pointerup` 挂 window 且**不捕获指针**（`setPointerCapture` 会把 `click` 目标改成捕获容器）——与 `resizable.ts` 同约定，仅 `pointerType==='mouse'` 接管、`DRAG_THRESHOLD`(3px) 才算拖拽，拖拽结束打时间戳避免「拖拽 + 快点击」被当成双击，`e.buttons===0` 兜丢失的 pointerup，滚动条槽位不接管。缩放比例一律读 DOM 真值；「适应百分比」只在 fit 态测量（RO 按 mode 门控、进 fit 时重测），换 `src` 复位缩放态。纯数学（delta 归一化 / 非对称因子 / 钳制 / 锚点滚动 / 拖拽阈值与平移换算）在 `zoom.ts`，经 testkit 单测。
- `jump.ts`：面板/子 tab 一次性焦点中继（模块级 per-session Map）。
- `git-graph.ts` / `file-tree.ts` / `diff.ts`：自研纯算法（提交图车道布局、路径折树、unified diff 拆行 → 并排行 + 块间隐藏上下文折叠为可展开 gap + 改动行前缀/后缀词级 diff）。gap 的 `count` 一律精确（尾部 gap 取 `newLines - rightNo + 1`），不存在「行数未知」的空 gap：数量非正就不渲染，`buildSideBySide` 对非有限计数按 0 处理，故控件不会因自身推导而「点了没反应然后自己消失」——计数过期（文件在两次查询之间变化）时仍可能一次拉回 0 行，此时 gap 直接消费、不再重复弹出同一个控件（`spliceGap` 的 'up' 分支），`retargetTrailingGap` 让同一文本下的新计数只重算尾部 gap、不重置已展开的行；`DiffView` 的 `newLines` 是必填 prop、与取数同源。提交图按车道（而非逐 commit）配色——一条连续线单色；车道续接跟随第一父，使主线钉在最左。线条样式由快照上的 `graphStyle` 决定：`parallel`（默认，VSCode 风格——合并的第一父各占一列，共享祖先以并行线表示、仅在祖先节点汇聚）/ `compact`（git log 风格——共享祖先提前合并为一列）。
- `locales.ts` / `icons.tsx` / `time.ts` / `types.ts`：中英文案、图标、时间格式化、client 侧类型别名。

## 数据流铁律

- **快照单一来源**：pill、变更记录页、统计条共用同一 `GitController` 快照，禁止各自发起独立 snapshot，避免重复 git 命令。
- **按需查询**：总览页 history/branches/show、图片 image-diff 走 `query` 端点，带分页、首页缓存、分代防竞态（新过滤请求接管、旧响应按代丢弃）。
- **双层信封**：RPC 返回 `{ ok, value }` 是传输层结果，业务结果 `{ ok, value|error }` 在 `value` 内，两层都要判。
- **选择集随快照修剪**：变更列表勾选的路径，若在新快照中消失必须移除，否则提交序列会中止。

## 依赖策略

MIT 协议下优先复用 dsh 官方能力，不为相同功能重复打包依赖。

- 代码/差异高亮调用平台 `@deepseek-ai/dsh-client-ui-primitives` 的 `languageForPath` 与 `useCodeHighlighter`；返回逐行 `HighlightSpan`，语法色采用宿主 `--shiki-*` 主题变量。语法资源由宿主按需加载；加载期间展示纯文本。词级高亮用 `code-spans.ts` 把完整代码行的 token 按改动区间切开，保留 token 样式。
- Markdown 渲染使用同一平台模块的 `MarkdownText`，不额外引入 marked/dompurify。
- 平台模块（`react` / `react-dom` / `@deepseek-ai/*`）一律 external，由宿主提供，不打包。只有 dsh 平台专有逻辑（slot / typert 契约、提交图车道布局、路径折树、diff 拆行）才自研。
- 引入新依赖前先确认宿主未提供；确需引入时 pin 精确版本写入 `package.json`。

## 构建

`build.mjs` 用 esbuild 出产物 + tsc 出类型声明：

1. `tsc -p tsconfig.build.json` 仅出 `lib/host/*.d.ts`（`emitDeclarationOnly`）。
2. esbuild 把 `src/host/*.ts` **逐文件**转译成 `lib/host/*.js`（`bundle: false`，输出结构与 `src/host/` 一一对应，读栈追踪直接落在出问题的模块；ESM 裸导入 `@deepseek-ai/*` 不打包，由宿主解析；**绝不压缩**——typert 靠方法参数名反射校验参数，重命名会破坏 wire 契约）。
3. esbuild 把 `src/client/index.ts` 打成 `lib/client.js`（cjs + banner/footer 包成 `window.__ModuleLoader__.load({id,factory})`；平台模块 external；client 可 minify）。

`lib/testkit.mjs` 由 esbuild 从 `src/client/testkit.ts` 单独打出，供单测消费；已 gitignore，`npm run test:unit` 会重建。

命令：

```bash
node build.mjs        # 全量构建 host + client + testkit
npx tsc --noEmit      # 类型检查
```

构建只作为显式脚本手动执行，**不挂 `prepare` 等安装期生命周期钩子**：`lib/` 已提交入库即为发布产物，DSH STORE 上架契约会拦截「安装期执行 install lifecycle script」的插件（`plugin-contract.test.mjs` 有回归测试守住这条不变量）。改动 `src/` 后手动 `node build.mjs` 并把 `lib/` 一起提交。

## 验证

- host 改动：`tsc --noEmit` 通过 + 端点逻辑单测。
- client 改动：`node build.mjs` 产出 `lib/client.js` 成功，然后**刷新** `http://127.0.0.1:3082` 验证（当前无 dev:web watcher，client 改动不会热重载，必须重建 + 刷新页面）。
- 测试放在 `test/` 下：`test/unit/*.test.mjs`（`node --test`，纯算法 + host 端点），`test/e2e/*.mjs`（隔离的 file:// 无头浏览器，绝不碰运行中的实例）。命令：`npm run test:unit` / `npm run test:e2e` / `npm test`。
- 提交前跑一次完整 `node build.mjs`，确保 host 与 client 均无错。
- 一键门禁 `npm run check`（`typecheck` + `test` + `git diff --exit-code -- lib/`）：类型、单测/e2e、以及「`lib/` 与 `src/` 一致（构建产物已提交且新鲜）」三道一起过。

## 代码约定

- TypeScript 严格模式，无隐式 any。
- 相对导入一律写 `./x.js` 后缀（不写 `./x.ts`）：`src/` 是 TypeScript、`lib/` 是 JS，同一份源码要同时产出可运行的 `lib/host/*.js` 和能解析到真实文件的 `lib/host/*.d.ts`，两种产物都与 `src/host/` 同名同构。
- 数据模型改动从 `host/types.ts` 起，client 侧的 RPC 类型直接从它复用——单一权威源，不存在需要手工同步的第二份定义。
- 注释精简，只写最终实现意图，不写演进历史。
- git 命令一律用 argv 数组经 subprocess 执行，禁止拼接 shell 字符串（注入防护 + cwd 锁定）。
- 面向未提交变更的操作（commit / discard / stage）属破坏性或写操作，UI 需二次确认或明确入口，host 侧校验路径安全（拒绝仓库外路径、`..` 穿越）。
- 样式用 dsh 主题 CSS 变量（`--dsw-alias-*`），不硬编码颜色，保证深浅色主题一致。
- 安装身份三处必须一致且等于实际安装的包名 `@xbzbing/dsh-git-panel`：`package.json.name`、`cordis.patch.yml` 的 row `name`、`build.mjs` 产出的 ModuleLoader 注册 `id`。任一不一致，DSH 会以 `patch: name mismatch ... skipping` 跳过该行，或浏览器端注册 id 对不上 graph 行，两者都表现为面板整个消失（`plugin-contract.test.mjs` 有回归测试）。

## 目录与提交

- `docs/local/` 是本地设计稿目录，已在 `.gitignore` 忽略，**不提交**。
- `lib/` **提交入库**：这样 `dsh plugin add github:xbzbing/dsh-git-panel` 能直接安装已构建的树，无需在安装端跑构建。只有测试期生成的 `lib/testkit.mjs` 忽略（`npm run test:unit` 会重建）。`node_modules/` 不提交。
- 只在用户明确要求时创建 commit；优先暂存具体文件而非 `git add .`。
