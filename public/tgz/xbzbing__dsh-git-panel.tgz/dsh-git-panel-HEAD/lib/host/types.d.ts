/**
 * dsh-git-panel host wire data model — the authoritative type source.
 * The client half (src/client/rpc.ts) reuses these types directly, so the
 * wire contract has a single definition and cannot drift.
 */
/** Diff layout: `unified` = single inline column, `split` = side-by-side. */
export type DiffViewMode = 'unified' | 'split';
/** Commit-graph line style: `compact` = converge a shared ancestor into one
 * lane (git log --graph); `parallel` = keep each merge's first parent in its
 * own lane, converging only at the ancestor (VSCode / GUI tools). */
export type GraphStyle = 'compact' | 'parallel';
/**
 * Diff context (-U) values shared by both halves. `DEFAULT` matches git's own
 * default and is what the host applies when a request omits `context`.
 * `MAX` is the host's clamp ceiling. `EXPAND` is what the "expand all" button
 * asks for: deliberately bounded, because a -U window wide enough to cover a
 * huge file makes the host emit that whole file as one hunk — megabytes of
 * text, and past the runner's stdout cap a silently truncated diff. Whatever
 * the window does not reach stays a collapsed gap the view reveals on demand.
 */
export declare const DIFF_CONTEXT_DEFAULT = 3;
export declare const DIFF_CONTEXT_MAX = 100000;
export declare const DIFF_EXPAND_CONTEXT = 2000;
/**
 * Ceiling for the working-file read taken only to count the diff's new-side
 * lines. That count decides whether hidden context follows the last hunk, so it
 * is read on every diff query — including the changes tab's poll while a diff is
 * open — while `file-lines` (the on-demand expansion) stays uncapped. Above this
 * size the count reports 0 (unknown) and no trailing control is offered.
 */
export declare const DIFF_COUNT_READ_MAX: number;
/** Wire request: the browser sends only session identity, never a path. */
export interface GitSnapshotRequest {
    readonly sessionId: string;
}
export type GitSnapshotResult = {
    readonly ok: true;
    readonly value: GitSnapshot;
} | {
    readonly ok: false;
    readonly error: GitFailure;
};
export type GitFailure = {
    readonly code: 'cwd-unavailable';
    readonly sessionId: string;
} | {
    readonly code: 'not-a-git-repo';
    readonly cwd?: string;
    readonly showInputPill?: boolean;
} | {
    readonly code: 'git-unavailable';
    readonly detail: string;
    readonly cwd?: string;
    readonly isGitRepo?: boolean;
} | {
    readonly code: 'timeout';
} | {
    readonly code: 'cancelled';
};
/** Host classification for a remote URL (drives the status-bar icon). */
export type RemoteHostKind = 'github' | 'gitlab' | 'gitee' | 'bitbucket' | 'other';
/** The repository's primary remote (origin, else the first remote). */
export interface GitRemote {
    /** Remote name (`origin`, or the first configured remote). */
    readonly name: string;
    /** The configured fetch URL, verbatim (ssh/scp/https/git form). */
    readonly url: string;
    /** A browsable https URL for the repo page; null when unparseable. */
    readonly webUrl: string | null;
    /** The remote hostname (e.g. `github.com`); null when unparseable. */
    readonly host: string | null;
    /** Known-host classification, for the status-bar icon. */
    readonly hostKind: RemoteHostKind;
}
/** Immutable snapshot of one repository's status at `checkedAt`. */
export interface GitSnapshot {
    /** Realpath of the repository root (work tree top). */
    readonly root: string;
    /** Current branch name; null when detached. */
    readonly branch: string | null;
    /** Short HEAD hash; null when the repository has no commits (unborn). */
    readonly head: string | null;
    /** True when the repository has no commits yet. */
    readonly unborn: boolean;
    /** staged + modified + untracked > 0. */
    readonly dirty: boolean;
    readonly staged: number;
    readonly modified: number;
    readonly untracked: number;
    readonly ahead: number;
    readonly behind: number;
    /** True when the current branch tracks an upstream (@{upstream} resolves). */
    readonly hasUpstream: boolean;
    /** The repository's primary remote; null when none is configured. */
    readonly remote: GitRemote | null;
    readonly lastCommit: GitCommit | null;
    readonly changes: readonly GitChange[];
    /** Working-tree statistics for the changes-page header (single source). */
    readonly stats: WorktreeStats;
    /** True when the change list was capped at maxChanges. */
    readonly truncated: boolean;
    /** Polling interval the client should use after this snapshot (0 = off). */
    readonly refreshIntervalMs: number;
    /** Whether the input-bar git marker pill should render (user preference). */
    readonly showInputPill: boolean;
    /** Default diff layout the views open with (user preference). */
    readonly defaultDiffView: DiffViewMode;
    /** Commit-graph line style (user preference). */
    readonly graphStyle: GraphStyle;
    /** Whether the commit box shows the AI-suggest button (user preference). */
    readonly suggestEnabled: boolean;
    /** Epoch millis of the snapshot. */
    readonly checkedAt: number;
}
export interface GitCommit {
    readonly hash: string;
    readonly shortHash: string;
    readonly subject: string;
    readonly author: string;
    readonly dateIso: string;
}
/** A commit with parent links and ref decorations (graph rendering). */
export interface GraphCommit extends GitCommit {
    readonly parents: readonly string[];
    readonly refs: readonly GitRef[];
}
export interface GitRef {
    readonly kind: 'branch' | 'remote' | 'tag';
    readonly name: string;
    /** True for the `HEAD -> name` current branch. */
    readonly head: boolean;
}
export type GitChangeStatus = 'added' | 'modified' | 'deleted' | 'renamed' | 'untracked' | 'conflicted' | 'typechange';
/**
 * One changed-file entry. A mixed porcelain XY (e.g. MM/AM) is split into two
 * entries: a `staged: true` side (X column) and a `staged: false` side (Y
 * column), so the UI can list "Staged" vs "Changes" IDE-style.
 */
export interface GitChange {
    readonly path: string;
    readonly status: GitChangeStatus;
    readonly staged: boolean;
    readonly isDirectory: boolean;
}
export type GitAction = {
    readonly kind: 'stage';
    readonly paths: readonly string[];
} | {
    readonly kind: 'stage-all';
} | {
    readonly kind: 'unstage';
    readonly paths: readonly string[];
} | {
    readonly kind: 'unstage-all';
} | {
    readonly kind: 'discard';
    readonly paths: readonly string[];
} | {
    readonly kind: 'commit';
    readonly message: string;
    /** Commit only these paths; absent/empty commits everything staged. */
    readonly paths?: readonly string[];
    /** True → git commit --amend (replace the previous commit). */
    readonly amend?: boolean;
} | {
    readonly kind: 'branch-checkout';
    readonly name: string;
    readonly createFrom?: string;
    readonly stashMessage?: string;
} | {
    readonly kind: 'fetch';
} | {
    readonly kind: 'pull-ff';
} | {
    readonly kind: 'push';
} | {
    readonly kind: 'publish';
    readonly remote: string;
} | {
    readonly kind: 'tag-create';
    readonly name: string;
    readonly commit: string;
    readonly message?: string;
} | {
    readonly kind: 'tag-delete';
    readonly name: string;
} | {
    readonly kind: 'stash-push';
    readonly message?: string;
} | {
    readonly kind: 'stash-apply';
    readonly index: number;
    readonly sha: string;
} | {
    readonly kind: 'stash-pop';
    readonly index: number;
    readonly sha: string;
} | {
    readonly kind: 'stash-drop';
    readonly index: number;
    readonly sha: string;
} | {
    readonly kind: 'revert';
    readonly commit: string;
} | {
    readonly kind: 'reset';
    readonly commit: string;
    readonly mode: ResetMode;
};
/** `git reset` modes, from least to most destructive. Single source so the
 * client dialog and the command builder cannot drift. */
export type ResetMode = 'soft' | 'mixed' | 'hard';
export type GitErrorCode = 'cwd-unavailable' | 'not-a-git-repo' | 'git-unavailable' | 'invalid-path' | 'invalid-name' | 'invalid-index' | 'git-error' | 'timeout' | 'cancelled' | 'empty-message' | 'local-changes-block' | 'not-ff' | 'push-rejected' | 'auth-failed' | 'conflict' | 'revert-conflict' | 'revert-stuck' | 'revert-merge' | 'not-found' | 'branch-in-use' | 'stash-switch-failed' | 'index-busy' | 'empty-diff' | 'llm-unavailable' | 'llm-error' | 'llm-output' | 'suggest-disabled';
export type GitActionResult = {
    readonly ok: true;
    readonly snapshot: GitSnapshot;
    readonly output?: string;
} | {
    readonly ok: false;
    readonly error: {
        readonly code: GitErrorCode;
        readonly message?: string;
    };
};
export interface GitActionRequest {
    readonly sessionId: string;
    readonly action: GitAction;
}
export type GitQuery = {
    readonly kind: 'history';
    readonly limit: number;
    readonly skip: number;
    /** Optional ref filter (branch/remote/tag); absent = --all. */
    readonly ref?: string;
    /** Text search: 7+ hex chars = hash prefix jump; else message regex (-i -E). */
    readonly search?: string;
    /** Author filter (--author). */
    readonly author?: string;
    /** Date lower bound (--since). */
    readonly since?: string;
} | {
    readonly kind: 'diff';
    readonly path: string;
    readonly base: 'worktree' | 'staged';
    readonly context?: number;
} | {
    readonly kind: 'diff';
    readonly path: string;
    readonly base: 'commit';
    readonly commit: string;
    readonly context?: number;
} | {
    readonly kind: 'file-lines';
    readonly path: string;
    readonly base: 'worktree' | 'staged';
    readonly start: number;
    readonly end: number;
} | {
    readonly kind: 'file-lines';
    readonly path: string;
    readonly base: 'commit';
    readonly commit: string;
    readonly start: number;
    readonly end: number;
} | {
    readonly kind: 'image-diff';
    readonly path: string;
    readonly base: 'worktree' | 'staged';
} | {
    readonly kind: 'image-diff';
    readonly path: string;
    readonly base: 'commit';
    readonly commit: string;
} | {
    readonly kind: 'dir-list';
    readonly path: string;
} | {
    readonly kind: 'file-content';
    readonly path: string;
} | {
    readonly kind: 'show';
    readonly ref: string;
} | {
    readonly kind: 'branches';
} | {
    readonly kind: 'tags';
} | {
    readonly kind: 'stash-list';
} | {
    readonly kind: 'authors';
} | {
    readonly kind: 'last-commit-message';
} | {
    readonly kind: 'worktree-stats';
} | {
    readonly kind: 'pull-preview';
} | {
    readonly kind: 'push-preview';
};
/** One entry in a `dir-list` result. */
export interface DirEntry {
    readonly name: string;
    readonly dir: boolean;
    /** File byte size; absent for directories. */
    readonly size?: number;
    /** True when Git excludes an untracked item; absent outside a repository. */
    readonly ignored?: boolean;
}
/** One commit's changed-file line (from --name-status). */
export interface GitFileStat {
    readonly path: string;
    readonly status: GitChangeStatus;
}
export interface GitBranch {
    readonly name: string;
    readonly shortHash: string | null;
    readonly ahead?: number;
    readonly behind?: number;
}
/** One entry in the stash stack (`git stash list`). */
export interface StashEntry {
    /** Stack position (0 = most recent). */
    readonly index: number;
    /** The stash commit SHA — a stable id the index position is not (see run). */
    readonly sha: string;
    /** The stash message (custom `-m` text, or the auto "WIP on …" subject). */
    readonly message: string;
    /** Branch the stash was taken on; null when it could not be parsed. */
    readonly branch: string | null;
    /** Human relative time (e.g. "2 hours ago"). */
    readonly relTime: string;
}
/** Working-tree statistics for the changes page header. */
export interface WorktreeStats {
    /** Distinct changed-file paths (staged ∪ modified ∪ untracked). */
    readonly fileCount: number;
    readonly staged: number;
    readonly modified: number;
    readonly untracked: number;
    /** Summed added lines across worktree + index diff (binary skipped). */
    readonly insertions: number;
    /** Summed deleted lines. */
    readonly deletions: number;
    /** Max mtime (epoch ms) among changed files; null when none/unavailable. */
    readonly lastChangeAt: number | null;
    /** HEAD commit time ISO; null when unborn. */
    readonly headCommittedAt: string | null;
    /**
     * True when the per-file fan-outs were skipped because the change set was too
     * large (issue #16): `insertions` then omits untracked lines and
     * `lastChangeAt` is null. Counts (fileCount/staged/modified/untracked) and
     * tracked insertions/deletions stay exact.
     */
    readonly partial: boolean;
}
export type GitQueryResult = {
    readonly kind: 'history';
    readonly commits: readonly GraphCommit[];
    readonly total: number;
}
/**
 * Unified diff text plus the new-side line count. The count is the fact the
 * view needs to decide whether hidden context can follow the LAST hunk: git
 * caps trailing context at -U, so a full trailing run is ambiguous from the
 * text alone (it may be mid-file, or the file may end exactly there), while
 * `newLines` makes it provable.
 *
 * 0 means "no trailing control is possible, or the count is not trustworthy":
 * the side does not exist (a deleted file), the read failed or was truncated,
 * the diff has no hunk at all, or the working file is above
 * DIFF_COUNT_READ_MAX. The view treats all of those the same way — no
 * trailing gap rather than a speculative one.
 *
 * `truncated` marks the one case where the text itself is incomplete: the
 * runner dropped output at its collect/spill ceiling, so `text` is a prefix
 * that still parses like a real diff. It is flagged rather than refused —
 * the partial hunks stay readable — but the view must say so, because line
 * numbers and +/- counts past the cut are simply wrong.
 */
 | {
    readonly kind: 'diff';
    readonly path: string;
    readonly text: string;
    readonly newLines: number;
    readonly truncated?: true;
} | {
    readonly kind: 'file-lines';
    readonly path: string;
    readonly start: number;
    readonly lines: readonly string[];
    readonly eof: boolean;
} | {
    /**
     * Old/new images for a binary image diff, as data URLs. The sides mirror
     * what the text diff compares: worktree rows read index vs working file,
     * staged rows read HEAD vs index, commit rows read parent vs commit.
     */
    readonly kind: 'image-diff';
    readonly path: string;
    /** null → the extension is not a browser-renderable image. */
    readonly mime: string | null;
    /** Pre-change image; absent when that side does not exist (added/untracked/root). */
    readonly old?: string;
    /** Post-change image; absent when that side does not exist (deleted). */
    readonly new?: string;
    /** A side exceeded the byte cap, so no URLs are returned. */
    readonly tooLarge?: true;
} | {
    readonly kind: 'show';
    readonly ref: string;
    readonly commit: GitCommit | null;
    /** Full commit body (without the subject line); right-pane comment. */
    readonly body: string;
    readonly stats: readonly GitFileStat[];
    /**
     * Aggregate line counts for this commit (`git show --numstat` summed).
     * Binary files contribute 0 lines (numstat emits `-`), matching the
     * sync-preview convention. Bound to the name-status file list: an empty
     * list (e.g. a clean merge, whose combined diff lists no files) forces
     * 0/0, so the summary stays consistent with the file tree.
     */
    readonly insertions: number;
    readonly deletions: number;
} | {
    readonly kind: 'branches';
    readonly current: string | null;
    readonly defaultBranch: string | null;
    readonly local: readonly GitBranch[];
    readonly remote: readonly GitBranch[];
} | {
    readonly kind: 'tags';
    readonly tags: readonly GitBranch[];
} | {
    readonly kind: 'stash-list';
    readonly entries: readonly StashEntry[];
} | {
    readonly kind: 'authors';
    readonly authors: readonly string[];
} | {
    readonly kind: 'last-commit-message';
    readonly message: string;
} | {
    readonly kind: 'worktree-stats';
    readonly stats: WorktreeStats;
} | {
    readonly kind: 'pull-preview';
    readonly hasUpstream: boolean;
    readonly commits: number;
    readonly files: number;
    readonly insertions: number;
    readonly deletions: number;
} | {
    readonly kind: 'push-preview';
    readonly hasUpstream: boolean;
    readonly commits: number;
    readonly files: number;
    readonly insertions: number;
    readonly deletions: number;
} | {
    readonly kind: 'dir-list';
    readonly path: string;
    readonly entries: readonly DirEntry[];
    readonly truncated: boolean;
} | {
    readonly kind: 'file-content';
    readonly path: string;
    readonly variant: 'text' | 'image' | 'binary';
    /** text variant: the file's full UTF-8 content. */
    readonly content?: string;
    /** text variant: total line count. */
    readonly lines?: number;
    /** image variant: a `data:<mime>;base64,…` URL. */
    readonly dataUrl?: string;
    /** The file exceeded the byte cap, so no content is returned. */
    readonly tooLarge?: true;
};
export type GitQueryResponse = {
    readonly ok: true;
    readonly value: GitQueryResult;
} | {
    readonly ok: false;
    readonly error: {
        readonly code: GitErrorCode;
        readonly message?: string;
    };
};
export interface GitQueryRequest {
    readonly sessionId: string;
    readonly query: GitQuery;
}
/**
 * Suggest-limit ranges and defaults, in host storage units (bytes / tokens /
 * ms) — the single source shared by both plugin halves (the client bundle
 * imports this value, like imageMimeFor below): the host's DEFAULT_CONFIG and
 * normalizeConfig clamp every read into [min, max], and the detail-page form
 * derives its display units from it (the /1024 and /1000 divisions are exact
 * and guarded by test).
 */
export declare const SUGGEST_LIMITS: {
    readonly maxBytes: {
        readonly min: number;
        readonly max: number;
        readonly default: number;
    };
    readonly maxOutputTokens: {
        readonly min: 256;
        readonly max: 16384;
        readonly default: 4096;
    };
    readonly timeoutMs: {
        readonly min: 5000;
        readonly max: 120000;
        readonly default: 15000;
    };
};
/**
 * Wire request for the suggest endpoint: ask the configured model to write a
 * commit message from the repository's uncommitted changes. `paths` restricts
 * the diff to the user's selection (bare repo-relative paths); absent means
 * all uncommitted changes.
 */
export interface GitSuggestRequest {
    readonly sessionId: string;
    readonly paths?: readonly string[];
}
export type GitSuggestResult = {
    readonly ok: true;
    readonly value: {
        /** The generated message, ready for the user to edit and commit. */
        readonly message: string;
        /** Actual provider/model route used (display only). */
        readonly provider?: string;
        readonly model?: string;
        /** The diff reached the model truncated: over the input cap, or cut
         * by the per-command runner stdout cap before it. */
        readonly truncated?: boolean;
    };
} | {
    readonly ok: false;
    readonly error: {
        readonly code: GitErrorCode;
        readonly message?: string;
    };
};
/**
 * Extensions the image-diff query serves, mapped to MIME types. Part of the
 * query's contract, so both halves gate on this one list and cannot drift.
 */
export declare const IMAGE_MIME: Readonly<Record<string, string>>;
/** MIME for a path's extension; null when it is not a served image type. */
export declare function imageMimeFor(path: string): string | null;
export interface GitVersionRequest {
    /** True → query the GitHub releases API; false/absent → local view only. */
    readonly check?: boolean;
}
export interface GitVersionInfo {
    readonly current: string;
    readonly repositoryUrl?: string;
    readonly latest?: string;
    readonly updateAvailable: boolean;
    readonly releaseUrl?: string;
    readonly checkedRemote: boolean;
    readonly error?: string;
}
