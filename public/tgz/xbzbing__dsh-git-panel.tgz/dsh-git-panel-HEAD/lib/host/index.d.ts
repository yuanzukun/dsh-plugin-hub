/**
 * dsh-git-panel host half: Cordis + typert Remote service.
 *
 * `GitPanelService` binds the `gitPanel` namespace and exposes three @Remote
 * endpoints (snapshot / run / query) that delegate to the framework-neutral
 * command layer. Host services (subprocess / sessions / sessionPersistence)
 * are adapted into a structural `SnapshotDeps` face.
 */
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import type { GitActionRequest, GitActionResult, GitQueryRequest, GitQueryResponse, GitSnapshotRequest, GitSnapshotResult, GitSuggestRequest, GitSuggestResult, GitVersionInfo, GitVersionRequest } from './types.js';
export type { GitSnapshot, GitSnapshotResult, GitSnapshotRequest, GitFailure, GitCommit, GraphCommit, GitRef, GitChange, GitChangeStatus, GitAction, GitActionRequest, GitActionResult, GitErrorCode, GitQuery, GitQueryRequest, GitQueryResponse, GitQueryResult, GitBranch, GitFileStat, WorktreeStats, StashEntry, GitVersionRequest, GitVersionInfo, DiffViewMode, GraphStyle, DirEntry, ResetMode, GitSuggestRequest, GitSuggestResult, GitRemote, RemoteHostKind, SuggestLanguage, ResolvedLanguage, } from './types.js';
export { normalizeConfig, DEFAULT_CONFIG, snapshotForSession, resolveWorkspace, parsePrimaryRemote, readSuggestLanguage } from './core.js';
export { createGitRunner } from './git.js';
export { parseStatus, parseGraphLog, parseBranches, parseNameStatus, parseStashList, parseTags, sumNumstat } from './parser.js';
export { parseRemote, classifyHost } from './remote.js';
export { isSafePath, planAction, runAction, classifyActionFailure } from './actions.js';
export { runQuery } from './queries.js';
export { runSuggest, resolveSuggestLanguage, parseStyleHistory, isCjkText } from './suggest.js';
export { readVersionInfo, checkLatestVersion, compareVersions, parseRepository } from './version.js';
export declare class GitPanelService extends TypertRemoteService {
    static inject: string[];
    /**
     * Config schema surfaced on the plugin detail page. `showInputPill`,
     * `defaultDiffView`, `graphStyle` and the suggest fields are `.volatile()`,
     * so the settings host renders them as live-editable controls; the
     * operational limits stay profile-only and out of the UI form.
     */
    static Config: Schema<Schemastery.ObjectS<NoInfer<{
        showInputPill: Schema<boolean, boolean, "volatile-defined">;
        defaultDiffView: Schema<"split" | "unified", "split" | "unified", "volatile-defined">;
        graphStyle: Schema<"compact" | "parallel", "compact" | "parallel", "volatile-defined">;
        suggestEnabled: Schema<boolean, boolean, "volatile-defined">;
        suggestLanguage: Schema<"auto" | "zh" | "en", "auto" | "zh" | "en", "volatile-defined">;
        suggestMaxBytes: Schema<number, number, "volatile-defined">;
        suggestMaxOutputTokens: Schema<number, number, "volatile-defined">;
        suggestTimeoutMs: Schema<number, number, "volatile-defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        showInputPill: Schema<boolean, boolean, "volatile-defined">;
        defaultDiffView: Schema<"split" | "unified", "split" | "unified", "volatile-defined">;
        graphStyle: Schema<"compact" | "parallel", "compact" | "parallel", "volatile-defined">;
        suggestEnabled: Schema<boolean, boolean, "volatile-defined">;
        suggestLanguage: Schema<"auto" | "zh" | "en", "auto" | "zh" | "en", "volatile-defined">;
        suggestMaxBytes: Schema<number, number, "volatile-defined">;
        suggestMaxOutputTokens: Schema<number, number, "volatile-defined">;
        suggestTimeoutMs: Schema<number, number, "volatile-defined">;
    }>>, "plain">;
    private readonly deps;
    private config;
    private readonly rawConfig;
    constructor(ctx: Context, config: unknown);
    private buildDeps;
    snapshot(request: GitSnapshotRequest, signal?: AbortSignal): Promise<GitSnapshotResult>;
    run(request: GitActionRequest, signal?: AbortSignal): Promise<GitActionResult>;
    query(request: GitQueryRequest, signal?: AbortSignal): Promise<GitQueryResponse>;
    suggest(request: GitSuggestRequest, signal?: AbortSignal): Promise<GitSuggestResult>;
    version(request: GitVersionRequest): Promise<GitVersionInfo>;
    /** Re-read config so a live-edited volatile field (showInputPill) is current. */
    private liveConfig;
    private withSignal;
}
export default GitPanelService;
