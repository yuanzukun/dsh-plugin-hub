#!/usr/bin/env node
/**
 * dsh-stall-guard verification:
 *  1. `node --check` on the plugin entry.
 *  2. Mock-ctx tests:
 *       - settings namespace registered, default config (enabled, 120s, nudge)
 *       - activity tracking via agent/status + session/event
 *       - stall detection fires the configured policy
 *       - nudge policy injects a user/message and records STALL/NUDGED events
 *       - report policy records without injecting
 *       - terminate policy injects the stop directive + records TERMINATED
 *       - status route registered
 *  3. Privacy scan (no tokens/emails/absolute paths).
 */
import { execFileSync } from "node:child_process";
import { existsSync, readFileSync, readdirSync, statSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, relative } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const HOST = join(ROOT, "lib", "index.js");

let failures = 0;
function check(label, ok, detail = "") {
  if (!ok) failures += 1;
  console.log(`${ok ? "PASS" : "FAIL"}  ${label}${detail ? `  (${detail})` : ""}`);
}

// 1. Syntax
try {
  execFileSync(process.execPath, ["--check", HOST], { stdio: "pipe" });
  check("plugin syntax (node --check)", true);
} catch (error) {
  check("plugin syntax (node --check)", false, String(error.stderr ?? error));
}

// 2. Mock tests — isolate the event log into a temp DSH_HOME.
const tempHome = mkdtempSync(join(tmpdir(), "stall-guard-test-"));
process.env.DSH_HOME = tempHome;

const host = await import(pathToFileURL(HOST).href);

function makeHarness(overrides = {}) {
  const appends = [];
  const session = {
    id: "test-session",
    append(type, data) {
      appends.push({ type, data });
      return { seq: appends.length };
    }
  };
  const agent = { id: "test-session", session };
  const listeners = {};
  const routes = [];
  const settingsRegistered = { ns: null };
  let timerCb = null;
  const defaults = {
    enabled: true,
    stallThresholdMs: 120000,
    checkIntervalMs: 5000,
    busyTimeoutMs: 600000,
    stallRecordIntervalMs: 60000,
    policy: "auto",
    nudgeCooldownMs: 30000,
    diagnoseMessage: "[stall-guard] diagnose",
    fixMessage: "[stall-guard] fix",
    redirectMessage: "[stall-guard] redirect"
  };
  const scope = {
    get: () => ({ ...defaults, ...overrides.settings }),
    watch: () => () => {}
  };
  const ctx = {
    agents: {
      get: () => agent,
      list: () => [agent]
    },
    on(event, handler) {
      (listeners[event] ??= []).push(handler);
    },
    inject(services, cb) {
      cb({
        settings: {
          register(ns, schema, options) {
            settingsRegistered.ns = ns;
            return scope;
          }
        },
        webServer: {
          register(route) {
            routes.push(route.path);
            return () => {};
          }
        },
        effect: (fn) => { const d = fn(); return () => {}; }
      });
    },
    setInterval(cb, ms) {
      timerCb = cb;
      return () => {};
    },
    logger: { info: () => {}, warn: () => {} }
  };
  const dispatch = (event, subject, payload) => {
    for (const handler of listeners[event] ?? []) handler(subject, payload);
  };
  return {
    ctx,
    appends,
    session,
    agent,
    dispatch,
    routes,
    settingsRegistered,
    runTick: () => { if (timerCb) timerCb(); },
    setConfig(partial) { Object.assign(defaults, partial); }
  };
}

// Fake clock so stall detection can be exercised deterministically.
const realNow = Date.now;
let fakeNow = Date.now();
Date.now = () => fakeNow;
try {
  // 2a. apply + defaults
  const h = makeHarness();
  host.apply(h.ctx, {});
  check("settings namespace is stall-guard", h.settingsRegistered.ns === "stall-guard");
  check("status route registered", h.routes.includes("/api/dsh-stall-guard/status"));
  check("no stall before running + timeout", h.appends.length === 0);

  // 2b. running + activity
  h.dispatch("agent/status", h.agent, { status: "running" });
  h.dispatch("session/event", h.session, { type: "step/start", data: { turn: 1, step: 1 } });
  h.runTick();
  check("no stall while active", h.appends.length === 0);

  // 2c. advance past threshold -> stage 1 DIAGNOSE (with diagnosis context)
  fakeNow += 130000;
  h.runTick();
  check("stall detected -> user/message injected", h.appends.length === 1 && h.appends[0].type === "user/message");
  check("stage 1 uses diagnose message", String(h.appends[0]?.data?.content?.[0]?.text).includes("diagnose"));
  check("injected message carries watchdog diagnosis", String(h.appends[0]?.data?.content?.[0]?.text).includes("[看门狗诊断]") && String(h.appends[0]?.data?.content?.[0]?.text).includes("已静默"));
  check("event log written", existsSync(join(tempHome, "stall-guard", "events.jsonl")));
  const logText = readFileSync(join(tempHome, "stall-guard", "events.jsonl"), "utf8");
  check("log contains STALL + DIAGNOSED", logText.includes('"kind":"STALL"') && logText.includes('"kind":"DIAGNOSED"'));

  // 2d. report policy: no injection
  const h2 = makeHarness({ settings: { policy: "report" } });
  host.apply(h2.ctx, {});
  h2.dispatch("agent/status", h2.agent, { status: "running" });
  fakeNow += 130000;
  h2.runTick();
  check("report policy records without injecting", h2.appends.length === 0);

  // 2e. the ladder never terminates: diagnose -> fix -> redirect -> redirect...
  const h3 = makeHarness();
  host.apply(h3.ctx, {});
  h3.dispatch("agent/status", h3.agent, { status: "running" });
  fakeNow += 130000;
  h3.runTick();
  check("ladder stage 1: diagnose", h3.appends.length === 1 && String(h3.appends[0]?.data?.content?.[0]?.text).includes("diagnose"));
  fakeNow += 31000;
  h3.runTick();
  check("ladder stage 2: fix", h3.appends.length === 2 && String(h3.appends[1]?.data?.content?.[0]?.text).includes("fix"));
  fakeNow += 31000;
  h3.runTick();
  check("ladder stage 3: redirect", h3.appends.length === 3 && String(h3.appends[2]?.data?.content?.[0]?.text).includes("redirect"));
  fakeNow += 31000;
  h3.runTick();
  check("redirect repeats (no terminate)", h3.appends.length === 4 && String(h3.appends[3]?.data?.content?.[0]?.text).includes("redirect"));
  fakeNow += 31000;
  h3.runTick();
  check("still no terminate after many rounds", h3.appends.length === 5 && !String(h3.appends.map((a) => a.data.content[0].text).join(" ")).includes("看门狗终止"));
  const log3 = readFileSync(join(tempHome, "stall-guard", "events.jsonl"), "utf8");
  check("no TERMINATED event ever written", !log3.includes('"kind":"TERMINATED"'));

  // 2f. IN-FLIGHT EXEMPTION: a long-running tool call is progress, never a stall.
  const h4 = makeHarness();
  host.apply(h4.ctx, {});
  h4.dispatch("agent/status", h4.agent, { status: "running" });
  h4.dispatch("session/event", h4.session, { type: "tool/call", data: { turn: 1, step: 1 } });
  fakeNow += 130000; // past stallThresholdMs
  h4.runTick();
  check("in-flight tool: no injection (progress respected)", h4.appends.length === 0);
  // even past the busy window it only RECORDS (never steers)
  h4.setConfig({ busyTimeoutMs: 60000 });
  fakeNow += 130000;
  h4.runTick();
  check("in-flight tool past busy window: still no injection", h4.appends.length === 0);
  const log4 = readFileSync(join(tempHome, "stall-guard", "events.jsonl"), "utf8");
  check("in-flight tool records LONG_RUNNING notice", log4.includes('"kind":"LONG_RUNNING"'));
  // flood guard: next tick records nothing new until cooldown
  fakeNow += 5000;
  h4.runTick();
  const log4b = readFileSync(join(tempHome, "stall-guard", "events.jsonl"), "utf8");
  check("LONG_RUNNING has cooldown (no flood)", (log4b.match(/LONG_RUNNING/g) ?? []).length === (log4.match(/LONG_RUNNING/g) ?? []).length);
  // tool resolves -> back to normal stall semantics
  h4.dispatch("session/event", h4.session, { type: "tool/result", data: { turn: 1, step: 1 } });
  h4.dispatch("session/event", h4.session, { type: "step/end", data: { turn: 1, step: 1 } });
  fakeNow += 130000;
  h4.runTick();
  check("after tool resolves, stall detection resumes", h4.appends.length === 1);

  // 2g. in-flight op: never steered no matter how long
  const h5 = makeHarness({ settings: { busyTimeoutMs: 30000 } });
  host.apply(h5.ctx, {});
  h5.dispatch("agent/status", h5.agent, { status: "running" });
  h5.dispatch("session/event", h5.session, { type: "request/header", data: {} });
  fakeNow += 600000; // far past every threshold, but LLM request in flight
  h5.runTick();
  check("in-flight LLM: never steered", h5.appends.length === 0);

  // 2h. activity resets the escalation episode (back to stage 1)
  const h7 = makeHarness();
  host.apply(h7.ctx, {});
  h7.dispatch("agent/status", h7.agent, { status: "running" });
  fakeNow += 130000;
  h7.runTick(); // stage 1 diagnose
  h7.dispatch("session/event", h7.session, { type: "llm/stream", data: {} }); // activity resumes
  fakeNow += 130000;
  h7.runTick();
  check("activity resets ladder to stage 1", h7.appends.length === 2 && String(h7.appends[1]?.data?.content?.[0]?.text).includes("diagnose"));

  // 2i. turn/start marks running without any agent/status event
  const h8 = makeHarness();
  host.apply(h8.ctx, {});
  h8.dispatch("session/event", h8.session, { type: "turn/start", data: { turn: 1 } }); // no agent/status emitted
  fakeNow += 130000;
  h8.runTick();
  check("turn/start alone is enough to start watching", h8.appends.length === 1);
} finally {
  Date.now = realNow;
}

// 3. Privacy scan
const PATTERNS = [
  { re: /github_pat_|ghp_|gho_|ghs_|ghu_/, label: "GitHub token" },
  { re: /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/, label: "email address" },
  { re: /[A-Za-z]:\\/, label: "Windows absolute path" },
  { re: /Bearer\s+[A-Za-z0-9_\-.]{12,}/, label: "Bearer token" }
];
function walk(dir, out = []) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (entry === ".git" || entry === "node_modules") continue;
    if (statSync(full).isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}
for (const file of walk(ROOT)) {
  const rel = relative(ROOT, file);
  if (rel === "LICENSE") continue;
  if (rel.replaceAll("\\", "/") === "scripts/verify.mjs") continue;
  const text = readFileSync(file, "utf8");
  for (const { re, label } of PATTERNS) {
    if (re.test(text)) check(`privacy: no ${label} in ${rel}`, false, "leak detected");
  }
}

console.log(failures === 0 ? "\nAll checks passed." : `\n${failures} check(s) FAILED.`);
process.exit(failures === 0 ? 0 : 1);
